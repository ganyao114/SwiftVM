000078e5533ce69b  nop [rax+rax*1], eax
000078e5533ce6a0  vmovaps xmm1, [0x000078E552FFE010]
000078e5533ce6a8  movq xmm1, xmm1
000078e5533ce6ac  movaps [r15+0x110], xmm1
000078e5533ce6b4  vmovaps xmm1, [0x000078E552FFE020]
000078e5533ce6bc  movq xmm1, xmm1
000078e5533ce6c0  movaps [r15+0x120], xmm1
000078e5533ce6c8  mov eax, 0x4204C0
000078e5533ce6cd  mov r14, [r13+rax*1]
000078e5533ce6d2  movq xmm1, r14
000078e5533ce6d7  movaps [r15+0x130], xmm1
000078e5533ce6df  vmovaps xmm1, [0x000078E552FFE030]
000078e5533ce6e7  vpbroadcastq xmm1, xmm1
000078e5533ce6ec  movaps [r15+0x140], xmm1
000078e5533ce6f4  mov qword ptr [r15+0x40], 0x02
000078e5533ce6fc  vmovaps xmm15, [0x000078E552FFE040]
000078e5533ce704  movq xmm15, xmm15
000078e5533ce709  movaps [r15+0x150], xmm15
000078e5533ce711  mov qword ptr [r15+0x58], 0x420000
000078e5533ce719  vmovaps xmm15, [0x000078E552FFE050]
000078e5533ce721  vpbroadcastq xmm15, xmm15
000078e5533ce726  movaps [r15+0x160], xmm15
000078e5533ce72e  mov rax, [r15+0x40]
000078e5533ce732  vmovq xmm14, rax
000078e5533ce737  vpbroadcastq xmm14, xmm14
000078e5533ce73c  movaps [r15+0x170], xmm14
000078e5533ce744  mov eax, 0x4204D0
000078e5533ce749  movups xmm13, [r13+rax*1]
000078e5533ce74f  mov qword ptr [r15+0x40], 0x430518
000078e5533ce757  mov qword ptr [r15+0x50], 0x430720
000078e5533ce75f  vpmovqd xmm12, xmm13
000078e5533ce765  pxor xmm11, xmm11
000078e5533ce76a  punpcklqdq xmm12, xmm11
000078e5533ce76f  movaps [r15+0x210], xmm12
000078e5533ce777  movq xmm12, qword ptr [r15+0x120]
000078e5533ce780  movq xmm11, qword ptr [r15+0x130]
000078e5533ce789  psubd xmm12, xmm11
000078e5533ce78e  movq xmm12, xmm12
000078e5533ce793  paddq xmm13, xmm14
000078e5533ce798  movaps [r15+0x180], xmm13
000078e5533ce7a0  movq xmm14, qword ptr [r15+0x150]
000078e5533ce7a9  paddd xmm11, xmm14
000078e5533ce7ae  movq xmm11, xmm11
000078e5533ce7b3  movq xmm11, xmm11
000078e5533ce7b8  movaps [r15+0x130], xmm11
000078e5533ce7c0  pmovzxdq xmm12, xmm12
000078e5533ce7c6  psllq xmm12, 0x00
000078e5533ce7cc  movq xmm14, qword ptr [r15+0x210]
000078e5533ce7d5  movq xmm13, qword ptr [r15+0x110]
000078e5533ce7de  paddd xmm14, xmm13
000078e5533ce7e3  movq xmm14, xmm14
000078e5533ce7e8  vcvtuqq2pd xmm12, xmm12
000078e5533ce7ee  pmovzxdq xmm14, xmm14
000078e5533ce7f4  psllq xmm14, 0x00
000078e5533ce7fa  vcvtuqq2pd xmm14, xmm14
000078e5533ce800  movaps xmm13, xmm12
000078e5533ce804  mulpd xmm13, xmm1
000078e5533ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000078e5533ce80f  ptest xmm11, xmm11
000078e5533ce815  jnz 0x000078E5533CE8FF
000078e5533ce81b  movaps [r15+0x220], xmm13
000078e5533ce823  mov eax, 0x430720
000078e5533ce828  movups [r13+rax*1], xmm13
000078e5533ce82e  movaps xmm1, xmm14
000078e5533ce832  mulpd xmm1, xmm15
000078e5533ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000078e5533ce83c  ptest xmm13, xmm13
000078e5533ce842  jnz 0x000078E5533CEA4C
000078e5533ce848  movaps [r15+0x210], xmm1
000078e5533ce850  mov eax, 0x430518
000078e5533ce855  movups [r13+rax*1], xmm1
000078e5533ce85b  mov qword ptr [r15+0x48], 0x10
000078e5533ce863  xor eax, eax
000078e5533ce865  mov r14d, 0x10
000078e5533ce86b  mov r12d, 0x200
000078e5533ce871  cmp r14, r12
000078e5533ce874  cmc
000078e5533ce875  lahf
000078e5533ce876  seto al
000078e5533ce879  mov [r15+0x108], eax
000078e5533ce880  mov eax, [r15+0x108]
000078e5533ce887  sahf
000078e5533ce888  jnz 0x000078E5533CE8BA
000078e5533ce88a  cmp dword ptr [r15+0x318], 0x00
000078e5533ce892  jz 0x000078E5533CEFF0
000078e5533ce898  nop [rax+rax*1], ax
000078e5533ce8a1  nop [rax+rax*1], eax
000078e5533ce8a9  mov eax, 0x4101EC
000078e5533ce8ae  mov [r15+0x100], rax
000078e5533ce8b5  jmp 0x000078E5531FE110
000078e5533ce8ba  cmp dword ptr [r15+0x318], 0x00
000078e5533ce8c2  jz 0x000078E5533CEBA0
000078e5533ce8c8  nop [rax+rax*1], ax
000078e5533ce8d1  nop [rax+rax*1], eax
000078e5533ce8d9  mov eax, 0x4101AC
000078e5533ce8de  mov [r15+0x100], rax
000078e5533ce8e5  jmp 0x000078E5531FE110
000078e5533ce8ea  int3
000078e5533ce8eb  call 0x000078E55320DC20
000078e5533ce8f0  jmp 0x000078E5533CE6D2
000078e5533ce8f5  call 0x000078E55320C260
000078e5533ce8fa  jmp 0x000078E5533CE74F
000078e5533ce8ff  sub rsp, 0x08
000078e5533ce903  push rax
000078e5533ce904  push rcx
000078e5533ce905  push rdx
000078e5533ce906  push rdi
000078e5533ce907  push rsi
000078e5533ce908  push r8
000078e5533ce90a  push r9
000078e5533ce90c  push r10
000078e5533ce90e  push r11
000078e5533ce910  sub rsp, 0xF0
000078e5533ce917  vmovaps [rsp], xmm0
000078e5533ce91c  vmovaps [rsp+0x10], xmm1
000078e5533ce922  vmovaps [rsp+0x20], xmm2
000078e5533ce928  vmovaps [rsp+0x30], xmm3
000078e5533ce92e  vmovaps [rsp+0x40], xmm4
000078e5533ce934  vmovaps [rsp+0x50], xmm5
000078e5533ce93a  vmovaps [rsp+0x60], xmm6
000078e5533ce940  vmovaps [rsp+0x70], xmm7
000078e5533ce946  vmovaps [rsp+0x80], xmm8
000078e5533ce94f  vmovaps [rsp+0x90], xmm9
000078e5533ce958  vmovaps [rsp+0xA0], xmm10
000078e5533ce961  vmovaps [rsp+0xB0], xmm11
000078e5533ce96a  vmovaps [rsp+0xC0], xmm12
000078e5533ce973  vmovaps [rsp+0xD0], xmm14
000078e5533ce97c  vmovaps [rsp+0xE0], xmm15
000078e5533ce985  sub rsp, 0x30
000078e5533ce989  movaps [rsp], xmm13
000078e5533ce98e  movaps [rsp+0x10], xmm12
000078e5533ce994  movaps [rsp+0x20], xmm1
000078e5533ce999  lea rdi, [rsp]
000078e5533ce99d  mov esi, 0x00
000078e5533ce9a2  mov rax, 0x5F83D5E17530
000078e5533ce9ac  call rax
000078e5533ce9ae  movaps xmm13, [rsp]
000078e5533ce9b3  add rsp, 0x30
000078e5533ce9b7  vmovaps xmm0, [rsp]
000078e5533ce9bc  vmovaps xmm1, [rsp+0x10]
000078e5533ce9c2  vmovaps xmm2, [rsp+0x20]
000078e5533ce9c8  vmovaps xmm3, [rsp+0x30]
000078e5533ce9ce  vmovaps xmm4, [rsp+0x40]
000078e5533ce9d4  vmovaps xmm5, [rsp+0x50]
000078e5533ce9da  vmovaps xmm6, [rsp+0x60]
000078e5533ce9e0  vmovaps xmm7, [rsp+0x70]
000078e5533ce9e6  vmovaps xmm8, [rsp+0x80]
000078e5533ce9ef  vmovaps xmm9, [rsp+0x90]
000078e5533ce9f8  vmovaps xmm10, [rsp+0xA0]
000078e5533cea01  vmovaps xmm11, [rsp+0xB0]
000078e5533cea0a  vmovaps xmm12, [rsp+0xC0]
000078e5533cea13  vmovaps xmm14, [rsp+0xD0]
000078e5533cea1c  vmovaps xmm15, [rsp+0xE0]
000078e5533cea25  add rsp, 0xF0
000078e5533cea2c  pop r11
000078e5533cea2e  pop r10
000078e5533cea30  pop r9
000078e5533cea32  pop r8
000078e5533cea34  pop rsi
000078e5533cea35  pop rdi
000078e5533cea36  pop rdx
000078e5533cea37  pop rcx
000078e5533cea38  pop rax
000078e5533cea39  add rsp, 0x08
000078e5533cea3d  jmp 0x000078E5533CE81B
000078e5533cea42  call 0x000078E55320C380
000078e5533cea47  jmp 0x000078E5533CE82E
000078e5533cea4c  sub rsp, 0x08
000078e5533cea50  push rax
000078e5533cea51  push rcx
000078e5533cea52  push rdx
000078e5533cea53  push rdi
000078e5533cea54  push rsi
000078e5533cea55  push r8
000078e5533cea57  push r9
000078e5533cea59  push r10
000078e5533cea5b  push r11
000078e5533cea5d  sub rsp, 0xF0
000078e5533cea64  vmovaps [rsp], xmm0
000078e5533cea69  vmovaps [rsp+0x10], xmm2
000078e5533cea6f  vmovaps [rsp+0x20], xmm3
000078e5533cea75  vmovaps [rsp+0x30], xmm4
000078e5533cea7b  vmovaps [rsp+0x40], xmm5
000078e5533cea81  vmovaps [rsp+0x50], xmm6
000078e5533cea87  vmovaps [rsp+0x60], xmm7
000078e5533cea8d  vmovaps [rsp+0x70], xmm8
000078e5533cea93  vmovaps [rsp+0x80], xmm9
000078e5533cea9c  vmovaps [rsp+0x90], xmm10
000078e5533ceaa5  vmovaps [rsp+0xA0], xmm11
000078e5533ceaae  vmovaps [rsp+0xB0], xmm12
000078e5533ceab7  vmovaps [rsp+0xC0], xmm13
000078e5533ceac0  vmovaps [rsp+0xD0], xmm14
000078e5533ceac9  vmovaps [rsp+0xE0], xmm15
000078e5533cead2  sub rsp, 0x30
000078e5533cead6  movaps [rsp], xmm1
000078e5533ceada  movaps [rsp+0x10], xmm14
000078e5533ceae0  movaps [rsp+0x20], xmm15
000078e5533ceae6  lea rdi, [rsp]
000078e5533ceaea  mov esi, 0x00
000078e5533ceaef  mov rax, 0x5F83D5E17530
000078e5533ceaf9  call rax
000078e5533ceafb  movaps xmm1, [rsp]
000078e5533ceaff  add rsp, 0x30
000078e5533ceb03  vmovaps xmm0, [rsp]
000078e5533ceb08  vmovaps xmm2, [rsp+0x10]
000078e5533ceb0e  vmovaps xmm3, [rsp+0x20]
000078e5533ceb14  vmovaps xmm4, [rsp+0x30]
000078e5533ceb1a  vmovaps xmm5, [rsp+0x40]
000078e5533ceb20  vmovaps xmm6, [rsp+0x50]
000078e5533ceb26  vmovaps xmm7, [rsp+0x60]
000078e5533ceb2c  vmovaps xmm8, [rsp+0x70]
000078e5533ceb32  vmovaps xmm9, [rsp+0x80]
000078e5533ceb3b  vmovaps xmm10, [rsp+0x90]
000078e5533ceb44  vmovaps xmm11, [rsp+0xA0]
000078e5533ceb4d  vmovaps xmm12, [rsp+0xB0]
000078e5533ceb56  vmovaps xmm13, [rsp+0xC0]
000078e5533ceb5f  vmovaps xmm14, [rsp+0xD0]
000078e5533ceb68  vmovaps xmm15, [rsp+0xE0]
000078e5533ceb71  add rsp, 0xF0
000078e5533ceb78  pop r11
000078e5533ceb7a  pop r10
000078e5533ceb7c  pop r9
000078e5533ceb7e  pop r8
000078e5533ceb80  pop rsi
000078e5533ceb81  pop rdi
000078e5533ceb82  pop rdx
000078e5533ceb83  pop rcx
000078e5533ceb84  pop rax
000078e5533ceb85  add rsp, 0x08
000078e5533ceb89  jmp 0x000078E5533CE848
000078e5533ceb8e  call 0x000078E5531FF540
000078e5533ceb93  jmp 0x000078E5533CE85B
000078e5533ceb98  int3
000078e5533ceb99  nop [rax], eax
000078e5533ceba0  movaps xmm1, [r15+0x180]
000078e5533ceba8  vpmovqd xmm15, xmm1
000078e5533cebae  pxor xmm14, xmm14
000078e5533cebb3  punpcklqdq xmm15, xmm14
000078e5533cebb8  movaps [r15+0x210], xmm15
000078e5533cebc0  movq xmm15, qword ptr [r15+0x120]
000078e5533cebc9  movq xmm14, qword ptr [r15+0x130]
000078e5533cebd2  psubd xmm15, xmm14
000078e5533cebd7  movq xmm15, xmm15
000078e5533cebdc  movaps xmm13, [r15+0x170]
000078e5533cebe4  paddq xmm1, xmm13
000078e5533cebe9  movaps [r15+0x180], xmm1
000078e5533cebf1  movq xmm1, qword ptr [r15+0x150]
000078e5533cebfa  paddd xmm14, xmm1
000078e5533cebff  movq xmm14, xmm14
000078e5533cec04  movq xmm14, xmm14
000078e5533cec09  movaps [r15+0x130], xmm14
000078e5533cec11  pmovzxdq xmm15, xmm15
000078e5533cec17  psllq xmm15, 0x00
000078e5533cec1d  movq xmm1, qword ptr [r15+0x210]
000078e5533cec26  movq xmm14, qword ptr [r15+0x110]
000078e5533cec2f  paddd xmm1, xmm14
000078e5533cec34  movq xmm1, xmm1
000078e5533cec38  vcvtuqq2pd xmm15, xmm15
000078e5533cec3e  pmovzxdq xmm1, xmm1
000078e5533cec43  psllq xmm1, 0x00
000078e5533cec48  vcvtuqq2pd xmm1, xmm1
000078e5533cec4e  movaps xmm14, [r15+0x140]
000078e5533cec56  movaps xmm13, xmm15
000078e5533cec5a  mulpd xmm13, xmm14
000078e5533cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000078e5533cec65  ptest xmm12, xmm12
000078e5533cec6b  jnz 0x000078E5533CED4E
000078e5533cec71  movaps [r15+0x220], xmm13
000078e5533cec79  mov rax, [r15+0x48]
000078e5533cec7d  mov r14, [r15+0x50]
000078e5533cec81  lea r12, [r14+rax*1]
000078e5533cec85  movups [r13+r12*1], xmm13
000078e5533cec8b  movaps xmm15, [r15+0x160]
000078e5533cec93  movaps xmm14, xmm1
000078e5533cec97  mulpd xmm14, xmm15
000078e5533cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000078e5533ceca2  ptest xmm13, xmm13
000078e5533ceca8  jnz 0x000078E5533CEE9C
000078e5533cecae  movaps [r15+0x210], xmm14
000078e5533cecb6  mov r14, [r15+0x40]
000078e5533cecba  lea r12, [r14+rax*1]
000078e5533cecbe  movups [r13+r12*1], xmm14
000078e5533cecc4  lea r14, [rax+0x10]
000078e5533cecc8  mov [r15+0x48], r14
000078e5533ceccc  xor eax, eax
000078e5533cecce  mov r12d, 0x200
000078e5533cecd4  cmp r14, r12
000078e5533cecd7  cmc
000078e5533cecd8  lahf
000078e5533cecd9  seto al
000078e5533cecdc  mov [r15+0x108], eax
000078e5533cece3  mov eax, [r15+0x108]
000078e5533cecea  sahf
000078e5533ceceb  jnz 0x000078E5533CED1D
000078e5533ceced  cmp dword ptr [r15+0x318], 0x00
000078e5533cecf5  jz 0x000078E5533CEFF0
000078e5533cecfb  nop [rax+rax*1], ax
000078e5533ced04  nop [rax+rax*1], eax
000078e5533ced0c  mov eax, 0x4101EC
000078e5533ced11  mov [r15+0x100], rax
000078e5533ced18  jmp 0x000078E5531FE110
000078e5533ced1d  cmp dword ptr [r15+0x318], 0x00
000078e5533ced25  jz 0x000078E5533CEBA0
000078e5533ced2b  nop [rax+rax*1], ax
000078e5533ced34  nop [rax+rax*1], eax
000078e5533ced3c  mov eax, 0x4101AC
000078e5533ced41  mov [r15+0x100], rax
000078e5533ced48  jmp 0x000078E5531FE110
000078e5533ced4d  int3
000078e5533ced4e  sub rsp, 0x08
000078e5533ced52  push rax
000078e5533ced53  push rcx
000078e5533ced54  push rdx
000078e5533ced55  push rdi
000078e5533ced56  push rsi
000078e5533ced57  push r8
000078e5533ced59  push r9
000078e5533ced5b  push r10
000078e5533ced5d  push r11
000078e5533ced5f  sub rsp, 0xF0
000078e5533ced66  vmovaps [rsp], xmm0
000078e5533ced6b  vmovaps [rsp+0x10], xmm1
000078e5533ced71  vmovaps [rsp+0x20], xmm2
000078e5533ced77  vmovaps [rsp+0x30], xmm3
000078e5533ced7d  vmovaps [rsp+0x40], xmm4
000078e5533ced83  vmovaps [rsp+0x50], xmm5
000078e5533ced89  vmovaps [rsp+0x60], xmm6
000078e5533ced8f  vmovaps [rsp+0x70], xmm7
000078e5533ced95  vmovaps [rsp+0x80], xmm8
000078e5533ced9e  vmovaps [rsp+0x90], xmm9
000078e5533ceda7  vmovaps [rsp+0xA0], xmm10
000078e5533cedb0  vmovaps [rsp+0xB0], xmm11
000078e5533cedb9  vmovaps [rsp+0xC0], xmm12
000078e5533cedc2  vmovaps [rsp+0xD0], xmm14
000078e5533cedcb  vmovaps [rsp+0xE0], xmm15
000078e5533cedd4  sub rsp, 0x30
000078e5533cedd8  movaps [rsp], xmm13
000078e5533ceddd  movaps [rsp+0x10], xmm15
000078e5533cede3  movaps [rsp+0x20], xmm14
000078e5533cede9  lea rdi, [rsp]
000078e5533ceded  mov esi, 0x00
000078e5533cedf2  mov rax, 0x5F83D5E17530
000078e5533cedfc  call rax
000078e5533cedfe  movaps xmm13, [rsp]
000078e5533cee03  add rsp, 0x30
000078e5533cee07  vmovaps xmm0, [rsp]
000078e5533cee0c  vmovaps xmm1, [rsp+0x10]
000078e5533cee12  vmovaps xmm2, [rsp+0x20]
000078e5533cee18  vmovaps xmm3, [rsp+0x30]
000078e5533cee1e  vmovaps xmm4, [rsp+0x40]
000078e5533cee24  vmovaps xmm5, [rsp+0x50]
000078e5533cee2a  vmovaps xmm6, [rsp+0x60]
000078e5533cee30  vmovaps xmm7, [rsp+0x70]
000078e5533cee36  vmovaps xmm8, [rsp+0x80]
000078e5533cee3f  vmovaps xmm9, [rsp+0x90]
000078e5533cee48  vmovaps xmm10, [rsp+0xA0]
000078e5533cee51  vmovaps xmm11, [rsp+0xB0]
000078e5533cee5a  vmovaps xmm12, [rsp+0xC0]
000078e5533cee63  vmovaps xmm14, [rsp+0xD0]
000078e5533cee6c  vmovaps xmm15, [rsp+0xE0]
000078e5533cee75  add rsp, 0xF0
000078e5533cee7c  pop r11
000078e5533cee7e  pop r10
000078e5533cee80  pop r9
000078e5533cee82  pop r8
000078e5533cee84  pop rsi
000078e5533cee85  pop rdi
000078e5533cee86  pop rdx
000078e5533cee87  pop rcx
000078e5533cee88  pop rax
000078e5533cee89  add rsp, 0x08
000078e5533cee8d  jmp 0x000078E5533CEC71
000078e5533cee92  call 0x000078E5532C2240
000078e5533cee97  jmp 0x000078E5533CEC8B
000078e5533cee9c  sub rsp, 0x08
000078e5533ceea0  push rax
000078e5533ceea1  push rcx
000078e5533ceea2  push rdx
000078e5533ceea3  push rdi
000078e5533ceea4  push rsi
000078e5533ceea5  push r8
000078e5533ceea7  push r9
000078e5533ceea9  push r10
000078e5533ceeab  push r11
000078e5533ceead  sub rsp, 0xF0
000078e5533ceeb4  vmovaps [rsp], xmm0
000078e5533ceeb9  vmovaps [rsp+0x10], xmm1
000078e5533ceebf  vmovaps [rsp+0x20], xmm2
000078e5533ceec5  vmovaps [rsp+0x30], xmm3
000078e5533ceecb  vmovaps [rsp+0x40], xmm4
000078e5533ceed1  vmovaps [rsp+0x50], xmm5
000078e5533ceed7  vmovaps [rsp+0x60], xmm6
000078e5533ceedd  vmovaps [rsp+0x70], xmm7
000078e5533ceee3  vmovaps [rsp+0x80], xmm8
000078e5533ceeec  vmovaps [rsp+0x90], xmm9
000078e5533ceef5  vmovaps [rsp+0xA0], xmm10
000078e5533ceefe  vmovaps [rsp+0xB0], xmm11
000078e5533cef07  vmovaps [rsp+0xC0], xmm12
000078e5533cef10  vmovaps [rsp+0xD0], xmm13
000078e5533cef19  vmovaps [rsp+0xE0], xmm15
000078e5533cef22  sub rsp, 0x30
000078e5533cef26  movaps [rsp], xmm14
000078e5533cef2b  movaps [rsp+0x10], xmm1
000078e5533cef30  movaps [rsp+0x20], xmm15
000078e5533cef36  lea rdi, [rsp]
000078e5533cef3a  mov esi, 0x00
000078e5533cef3f  mov rax, 0x5F83D5E17530
000078e5533cef49  call rax
000078e5533cef4b  movaps xmm14, [rsp]
000078e5533cef50  add rsp, 0x30
000078e5533cef54  vmovaps xmm0, [rsp]
000078e5533cef59  vmovaps xmm1, [rsp+0x10]
000078e5533cef5f  vmovaps xmm2, [rsp+0x20]
000078e5533cef65  vmovaps xmm3, [rsp+0x30]
000078e5533cef6b  vmovaps xmm4, [rsp+0x40]
000078e5533cef71  vmovaps xmm5, [rsp+0x50]
000078e5533cef77  vmovaps xmm6, [rsp+0x60]
000078e5533cef7d  vmovaps xmm7, [rsp+0x70]
000078e5533cef83  vmovaps xmm8, [rsp+0x80]
000078e5533cef8c  vmovaps xmm9, [rsp+0x90]
000078e5533cef95  vmovaps xmm10, [rsp+0xA0]
000078e5533cef9e  vmovaps xmm11, [rsp+0xB0]
000078e5533cefa7  vmovaps xmm12, [rsp+0xC0]
000078e5533cefb0  vmovaps xmm13, [rsp+0xD0]
000078e5533cefb9  vmovaps xmm15, [rsp+0xE0]
000078e5533cefc2  add rsp, 0xF0
000078e5533cefc9  pop r11
000078e5533cefcb  pop r10
000078e5533cefcd  pop r9
000078e5533cefcf  pop r8
000078e5533cefd1  pop rsi
000078e5533cefd2  pop rdi
000078e5533cefd3  pop rdx
000078e5533cefd4  pop rcx
000078e5533cefd5  pop rax
000078e5533cefd6  add rsp, 0x08
000078e5533cefda  jmp 0x000078E5533CECAE
000078e5533cefdf  call 0x000078E5532C34C0
000078e5533cefe4  jmp 0x000078E5533CECC4
000078e5533cefe9  int3
000078e5533cefea  nop [rax+rax*1], ax
000078e5533ceff0  mov rax, [r15+0xF8]
000078e5533ceff7  lea r14, [rax-0x150]
000078e5533ceffe  mov [r15+0xF8], r14
000078e5533cf005  mov rax, [r15+0x50]
000078e5533cf009  lea r12, [rax+0x80]
000078e5533cf010  movups xmm1, [r13+r12*1]
000078e5533cf016  lea r12, [rax+0x90]
000078e5533cf01d  movups xmm15, [r13+r12*1]
000078e5533cf023  mov qword ptr [r15+0x48], 0x00
000078e5533cf02b  lea r12, [rax+0x40]
000078e5533cf02f  movups xmm14, [r13+r12*1]
000078e5533cf035  lea r12, [rax+0x50]
000078e5533cf039  movups xmm13, [r13+r12*1]
000078e5533cf03f  lea r12, [r14+0x120]
000078e5533cf046  movq xmm12, qword ptr [r15+0x1C0]
000078e5533cf04f  movq xmm11, qword ptr [r15+0x1B0]
000078e5533cf058  movq r11, xmm12
000078e5533cf05d  movq r10, xmm11
000078e5533cf062  mov [r13+r12*1], r11
000078e5533cf067  lea r12, [r14+0x128]
000078e5533cf06e  mov [r13+r12*1], r10
000078e5533cf073  vxorps xmm12, xmm12, xmm12
000078e5533cf078  vpbroadcastq xmm12, xmm12
000078e5533cf07d  lea r12, [r14+0x100]
000078e5533cf084  movq xmm11, qword ptr [r15+0x200]
000078e5533cf08d  movq xmm10, qword ptr [r15+0x1F0]
000078e5533cf096  movq r11, xmm11
000078e5533cf09b  movq r10, xmm10
000078e5533cf0a0  mov [r13+r12*1], r11
000078e5533cf0a5  lea r12, [r14+0x108]
000078e5533cf0ac  mov [r13+r12*1], r10
000078e5533cf0b1  lea r12, [r14+0xE0]
000078e5533cf0b8  movups [r13+r12*1], xmm15
000078e5533cf0be  lea r12, [r14+0xF0]
000078e5533cf0c5  movups [r13+r12*1], xmm1
000078e5533cf0cb  lea r12, [rax+0xC0]
000078e5533cf0d2  movups xmm1, [r13+r12*1]
000078e5533cf0d8  lea r12, [rax+0xD0]
000078e5533cf0df  movups xmm15, [r13+r12*1]
000078e5533cf0e5  lea r12, [r14+0x110]
000078e5533cf0ec  movq xmm11, qword ptr [r15+0x1E0]
000078e5533cf0f5  movq xmm10, qword ptr [r15+0x1D0]
000078e5533cf0fe  movq r11, xmm11
000078e5533cf103  movq r10, xmm10
000078e5533cf108  mov [r13+r12*1], r11
000078e5533cf10d  lea r12, [r14+0x118]
000078e5533cf114  mov [r13+r12*1], r10
000078e5533cf119  movups xmm11, [r13+rax*1]
000078e5533cf11f  lea r12, [rax+0x10]
000078e5533cf123  movups xmm10, [r13+r12*1]
000078e5533cf129  lea r12, [r14+0x130]
000078e5533cf130  movq xmm9, qword ptr [r15+0x1A0]
000078e5533cf139  movq xmm8, qword ptr [r15+0x190]
000078e5533cf142  movq r11, xmm9
000078e5533cf147  movq r10, xmm8
000078e5533cf14c  mov [r13+r12*1], r11
000078e5533cf151  lea r12, [r14+0x138]
000078e5533cf158  mov [r13+r12*1], r10
000078e5533cf15d  lea r12, [rax+0x140]
000078e5533cf164  movups xmm9, [r13+r12*1]
000078e5533cf16a  lea r12, [rax+0x150]
000078e5533cf171  movups xmm8, [r13+r12*1]
000078e5533cf177  lea r12, [r14+0xC0]
000078e5533cf17e  movups [r13+r12*1], xmm15
000078e5533cf184  lea r12, [r14+0xD0]
000078e5533cf18b  movups [r13+r12*1], xmm1
000078e5533cf191  lea r12, [rax+0x100]
000078e5533cf198  movups xmm1, [r13+r12*1]
000078e5533cf19e  lea r12, [rax+0x110]
000078e5533cf1a5  movups xmm15, [r13+r12*1]
000078e5533cf1ab  lea r12, [r14+0x140]
000078e5533cf1b2  mov r11, [r15+0xE8]
000078e5533cf1b9  mov [r13+r12*1], r11
000078e5533cf1be  lea r12, [rax+0x180]
000078e5533cf1c5  movups xmm7, [r13+r12*1]
000078e5533cf1cb  lea r12, [rax+0x190]
000078e5533cf1d2  movups xmm6, [r13+r12*1]
000078e5533cf1d8  lea r12, [rax+0x1C0]
000078e5533cf1df  movups xmm5, [r13+r12*1]
000078e5533cf1e5  lea r12, [rax+0x1D0]
000078e5533cf1ec  movups xmm4, [r13+r12*1]
000078e5533cf1f2  lea r12, [r14+0x20]
000078e5533cf1f6  movups [r13+r12*1], xmm1
000078e5533cf1fc  lea r12, [r14+0x30]
000078e5533cf200  movups [r13+r12*1], xmm13
000078e5533cf206  lea r12, [rax+0x60]
000078e5533cf20a  movups xmm1, [r13+r12*1]
000078e5533cf210  lea r12, [rax+0x70]
000078e5533cf214  movups xmm13, [r13+r12*1]
000078e5533cf21a  lea r12, [rax+0x20]
000078e5533cf21e  movups xmm3, [r13+r12*1]
000078e5533cf224  lea r12, [rax+0x30]
000078e5533cf228  movups xmm2, [r13+r12*1]
000078e5533cf22e  movaps [r15+0x1F0], xmm2
000078e5533cf236  lea r12, [r14+0x60]
000078e5533cf23a  movups [r13+r12*1], xmm11
000078e5533cf240  lea r12, [r14+0x70]
000078e5533cf244  movups [r13+r12*1], xmm5
000078e5533cf24a  lea r12, [rax+0xE0]
000078e5533cf251  movups xmm11, [r13+r12*1]
000078e5533cf257  lea r12, [rax+0xF0]
000078e5533cf25e  movups xmm5, [r13+r12*1]
000078e5533cf264  lea r12, [r14+0xA0]
000078e5533cf26b  movups [r13+r12*1], xmm13
000078e5533cf271  lea r12, [r14+0xB0]
000078e5533cf278  movups [r13+r12*1], xmm1
000078e5533cf27e  lea r12, [rax+0xA0]
000078e5533cf285  movups xmm1, [r13+r12*1]
000078e5533cf28b  lea r12, [rax+0xB0]
000078e5533cf292  movups xmm13, [r13+r12*1]
000078e5533cf298  lea r12, [rax+0x120]
000078e5533cf29f  vmovaps [rsp+0x10], xmm1
000078e5533cf2a5  movups xmm1, [r13+r12*1]
000078e5533cf2ab  lea r12, [rax+0x130]
000078e5533cf2b2  vmovaps [rsp+0x20], xmm1
000078e5533cf2b8  movups xmm1, [r13+r12*1]
000078e5533cf2be  lea r12, [rax+0x160]
000078e5533cf2c5  vmovaps [rsp+0x30], xmm1
000078e5533cf2cb  movups xmm1, [r13+r12*1]
000078e5533cf2d1  lea r12, [rax+0x170]
000078e5533cf2d8  vmovaps [rsp+0x40], xmm1
000078e5533cf2de  movups xmm1, [r13+r12*1]
000078e5533cf2e4  movaps [r15+0x2B0], xmm1
000078e5533cf2ec  lea r12, [r14+0x80]
000078e5533cf2f3  movups [r13+r12*1], xmm13
000078e5533cf2f9  lea r12, [r14+0x90]
000078e5533cf300  vmovaps xmm13, [rsp+0x10]
000078e5533cf306  movups [r13+r12*1], xmm13
000078e5533cf30c  lea r12, [rax+0x1A0]
000078e5533cf313  movups xmm13, [r13+r12*1]
000078e5533cf319  lea r12, [rax+0x1B0]
000078e5533cf320  vmovaps [rsp+0x10], xmm1
000078e5533cf326  movups xmm1, [r13+r12*1]
000078e5533cf32c  movaps [r15+0x290], xmm13
000078e5533cf334  movaps [r15+0x1E0], xmm1
000078e5533cf33c  lea r12, [rax+0x1E0]
000078e5533cf343  vmovaps [rsp+0x50], xmm1
000078e5533cf349  movups xmm1, [r13+r12*1]
000078e5533cf34f  lea r12, [rax+0x1F0]
000078e5533cf356  vmovaps [rsp+0x60], xmm1
000078e5533cf35c  movups xmm1, [r13+r12*1]
000078e5533cf362  mov qword ptr [r15+0x50], 0x430920
000078e5533cf36a  lea rax, [r14+0x40]
000078e5533cf36e  vmovaps [rsp+0x70], xmm1
000078e5533cf374  vmovaps xmm1, [rsp+0x40]
000078e5533cf37a  movups [r13+rax*1], xmm1
000078e5533cf380  lea rax, [r14+0x50]
000078e5533cf384  movups [r13+rax*1], xmm10
000078e5533cf38a  vmovaps xmm1, [rsp+0x70]
000078e5533cf390  movups [r13+r14*1], xmm1
000078e5533cf396  lea rax, [r14+0x10]
000078e5533cf39a  vmovaps xmm1, [rsp+0x60]
000078e5533cf3a0  movups [r13+rax*1], xmm1
000078e5533cf3a6  mov rax, [r15+0x40]
000078e5533cf3aa  vmovaps [rsp+0x40], xmm3
000078e5533cf3b0  vmovaps xmm1, [rsp+0x40]
000078e5533cf3b6  por xmm3, xmm1
000078e5533cf3ba  vmovaps [rsp+0x40], xmm6
000078e5533cf3c0  vmovaps xmm10, [rsp+0x40]
000078e5533cf3c6  por xmm6, xmm10
000078e5533cf3cb  lea r12, [rax+0x30]
000078e5533cf3cf  mov r11, [r13+r12*1]
000078e5533cf3d4  lea r12, [rax+0x38]
000078e5533cf3d8  mov r10, [r13+r12*1]
000078e5533cf3dd  movq xmm10, r11
000078e5533cf3e2  vmovaps [rsp+0x40], xmm1
000078e5533cf3e8  movq xmm1, r10
000078e5533cf3ed  movq xmm10, xmm10
000078e5533cf3f2  vmovaps [rsp+0x60], xmm10
000078e5533cf3f8  movq xmm10, xmm10
000078e5533cf3fd  movaps [r15+0x130], xmm10
000078e5533cf405  movq xmm1, xmm1
000078e5533cf409  vmovaps [rsp+0x70], xmm1
000078e5533cf40f  movq xmm1, xmm1
000078e5533cf413  movaps [r15+0x280], xmm1
000078e5533cf41b  vmovaps [rsp+0x80], xmm9
000078e5533cf424  vmovaps xmm1, [rsp+0x80]
000078e5533cf42d  por xmm9, xmm1
000078e5533cf432  lea r12, [rax+0x20]
000078e5533cf436  mov r11, [r13+r12*1]
000078e5533cf43b  lea r12, [rax+0x28]
000078e5533cf43f  mov r10, [r13+r12*1]
000078e5533cf444  movq xmm1, r11
000078e5533cf449  movq xmm10, r10
000078e5533cf44e  movq xmm1, xmm1
000078e5533cf452  vmovaps [rsp+0x80], xmm1
000078e5533cf45b  movq xmm1, xmm1
000078e5533cf45f  movaps [r15+0x150], xmm1
000078e5533cf467  movq xmm10, xmm10
000078e5533cf46c  vmovaps [rsp+0x90], xmm10
000078e5533cf475  movq xmm10, xmm10
000078e5533cf47a  movaps [r15+0x140], xmm10
000078e5533cf482  lea r12, [rax+0x10]
000078e5533cf486  mov r11, [r13+r12*1]
000078e5533cf48b  lea r12, [rax+0x18]
000078e5533cf48f  mov r10, [r13+r12*1]
000078e5533cf494  movq xmm1, r11
000078e5533cf499  movq xmm10, r10
000078e5533cf49e  movq xmm1, xmm1
000078e5533cf4a2  vmovaps [rsp+0xA0], xmm1
000078e5533cf4ab  movq xmm1, xmm1
000078e5533cf4af  movaps [r15+0x170], xmm1
000078e5533cf4b7  movq xmm10, xmm10
000078e5533cf4bc  vmovaps [rsp+0xB0], xmm10
000078e5533cf4c5  movq xmm10, xmm10
000078e5533cf4ca  movaps [r15+0x160], xmm10
000078e5533cf4d2  mov r12, [r13+rax*1]
000078e5533cf4d7  vmovq xmm1, r12
000078e5533cf4dc  vpbroadcastq xmm1, xmm1
000078e5533cf4e1  lea r12, [rax+0x08]
000078e5533cf4e5  mov rax, [r13+r12*1]
000078e5533cf4ea  movq xmm10, rax
000078e5533cf4ef  movaps [r15+0x230], xmm10
000078e5533cf4f7  lea rax, [r14+0x50]
000078e5533cf4fb  movups xmm10, [r13+rax*1]
000078e5533cf501  lea rax, [r14+0x60]
000078e5533cf505  vmovaps [rsp+0xC0], xmm1
000078e5533cf50e  movups xmm1, [r13+rax*1]
000078e5533cf514  lea rax, [r14+0x30]
000078e5533cf518  vmovaps [rsp+0xD0], xmm1
000078e5533cf521  movups xmm1, [r13+rax*1]
000078e5533cf527  mov qword ptr [r15+0x60], 0x430920
000078e5533cf52f  mov qword ptr [r15+0x58], 0x40
000078e5533cf537  vmovaps [rsp+0xE0], xmm1
000078e5533cf540  vmovaps [rsp+0xF0], xmm15
000078e5533cf549  vmovaps xmm15, [rsp+0xC0]
000078e5533cf552  vmovaps [rsp+0xC0], xmm14
000078e5533cf55b  vmovaps xmm14, [rsp+0x40]
000078e5533cf561  vmovaps [rsp+0x40], xmm13
000078e5533cf567  movaps xmm1, xmm15
000078e5533cf56b  mulpd xmm1, xmm14
000078e5533cf570  vcmppd xmm13, xmm1, xmm1, 0x03
000078e5533cf575  ptest xmm13, xmm13
000078e5533cf57b  jnz 0x000078E5533D0682
000078e5533cf581  movq xmm14, qword ptr [r15+0x230]
000078e5533cf58a  vmovaps [rsp+0x100], xmm14
000078e5533cf593  vpermilpd xmm14, xmm14, 0x00
000078e5533cf599  vmovaps [rsp+0x110], xmm1
000078e5533cf5a2  vmovaps xmm1, [rsp+0xE0]
000078e5533cf5ab  vmovaps [rsp+0xE0], xmm15
000078e5533cf5b4  movaps xmm13, xmm1
000078e5533cf5b8  mulpd xmm13, xmm14
000078e5533cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000078e5533cf5c3  ptest xmm15, xmm15
000078e5533cf5c9  jnz 0x000078E5533D07C4
000078e5533cf5cf  vxorps xmm1, xmm1, xmm1
000078e5533cf5d3  vpbroadcastq xmm1, xmm1
000078e5533cf5d8  vmovaps xmm14, [rsp+0xE0]
000078e5533cf5e1  vmovaps [rsp+0xE0], xmm1
000078e5533cf5ea  vmovaps xmm1, [rsp+0xD0]
000078e5533cf5f3  vmovaps [rsp+0xD0], xmm13
000078e5533cf5fc  movaps xmm15, xmm14
000078e5533cf600  mulpd xmm15, xmm1
000078e5533cf605  vcmppd xmm13, xmm15, xmm15, 0x03
000078e5533cf60b  ptest xmm13, xmm13
000078e5533cf611  jnz 0x000078E5533D0907
000078e5533cf617  movaps xmm1, xmm14
000078e5533cf61b  mulpd xmm1, xmm10
000078e5533cf620  vcmppd xmm13, xmm1, xmm1, 0x03
000078e5533cf625  ptest xmm13, xmm13
000078e5533cf62b  jnz 0x000078E5533D0A4A
000078e5533cf631  movaps xmm13, xmm14
000078e5533cf635  mulpd xmm13, xmm2
000078e5533cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000078e5533cf640  ptest xmm10, xmm10
000078e5533cf646  jnz 0x000078E5533D0B8C
000078e5533cf64c  vmovaps [rsp+0x120], xmm7
000078e5533cf655  vmovaps xmm14, [rsp+0x120]
000078e5533cf65e  por xmm7, xmm14
000078e5533cf663  vmovaps xmm14, [rsp+0xC0]
000078e5533cf66c  vmovaps xmm10, [rsp+0xC0]
000078e5533cf675  por xmm14, xmm10
000078e5533cf67a  vmovaps xmm2, [rsp+0x100]
000078e5533cf683  vpermilpd xmm2, xmm2, 0x00
000078e5533cf689  vmovaps [rsp+0xC0], xmm1
000078e5533cf692  vmovaps [rsp+0x120], xmm15
000078e5533cf69b  movaps xmm1, xmm10
000078e5533cf69f  mulpd xmm1, xmm2
000078e5533cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000078e5533cf6a8  ptest xmm15, xmm15
000078e5533cf6ae  jnz 0x000078E5533D0CCF
000078e5533cf6b4  xor eax, eax
000078e5533cf6b6  mov r12d, 0x40
000078e5533cf6bc  mov r11d, 0x200
000078e5533cf6c2  cmp r12, r11
000078e5533cf6c5  cmc
000078e5533cf6c6  lahf
000078e5533cf6c7  seto al
000078e5533cf6ca  mov [r15+0x108], eax
000078e5533cf6d1  vmovaps xmm10, [rsp+0x110]
000078e5533cf6da  vmovaps xmm2, [rsp+0xE0]
000078e5533cf6e3  vmovaps [rsp+0xE0], xmm1
000078e5533cf6ec  movaps xmm15, xmm10
000078e5533cf6f0  addpd xmm15, xmm2
000078e5533cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000078e5533cf6fb  ptest xmm1, xmm1
000078e5533cf700  jnz 0x000078E5533D0E10
000078e5533cf706  vmovaps xmm10, [rsp+0x120]
000078e5533cf70f  vmovaps [rsp+0x110], xmm15
000078e5533cf718  movaps xmm1, xmm10
000078e5533cf71c  addpd xmm1, xmm12
000078e5533cf721  vcmppd xmm15, xmm1, xmm1, 0x03
000078e5533cf726  ptest xmm15, xmm15
000078e5533cf72c  jnz 0x000078E5533D0F53
000078e5533cf732  vmovaps xmm10, [rsp+0xC0]
000078e5533cf73b  vmovaps [rsp+0xC0], xmm1
000078e5533cf744  movaps xmm15, xmm10
000078e5533cf748  addpd xmm15, xmm12
000078e5533cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000078e5533cf753  ptest xmm1, xmm1
000078e5533cf758  jnz 0x000078E5533D1095
000078e5533cf75e  vmovaps xmm1, [rsp+0x30]
000078e5533cf764  vmovaps xmm12, [rsp+0x30]
000078e5533cf76a  por xmm1, xmm12
000078e5533cf76f  vmovaps xmm12, [rsp+0x20]
000078e5533cf775  vmovaps xmm10, [rsp+0x20]
000078e5533cf77b  por xmm12, xmm10
000078e5533cf780  vmovaps [rsp+0x20], xmm5
000078e5533cf786  vmovaps xmm10, [rsp+0x20]
000078e5533cf78c  por xmm5, xmm10
000078e5533cf791  vmovaps [rsp+0x20], xmm11
000078e5533cf797  vmovaps xmm10, [rsp+0x20]
000078e5533cf79d  por xmm11, xmm10
000078e5533cf7a2  vmovaps [rsp+0x20], xmm4
000078e5533cf7a8  vmovaps xmm10, [rsp+0x20]
000078e5533cf7ae  por xmm4, xmm10
000078e5533cf7b3  vmovaps [rsp+0x20], xmm8
000078e5533cf7b9  vmovaps xmm10, [rsp+0x20]
000078e5533cf7bf  por xmm8, xmm10
000078e5533cf7c4  vmovaps xmm10, [rsp+0xF0]
000078e5533cf7cd  vmovaps [rsp+0x20], xmm1
000078e5533cf7d3  vmovaps xmm1, [rsp+0xF0]
000078e5533cf7dc  por xmm10, xmm1
000078e5533cf7e1  lea rax, [r14+0xA0]
000078e5533cf7e8  movups xmm1, [r13+rax*1]
000078e5533cf7ee  lea rax, [r14+0xB0]
000078e5533cf7f5  vmovaps [rsp+0x30], xmm1
000078e5533cf7fb  movups xmm1, [r13+rax*1]
000078e5533cf801  vmovaps [rsp+0xF0], xmm1
000078e5533cf80a  vmovaps [rsp+0x120], xmm15
000078e5533cf813  movaps xmm1, xmm13
000078e5533cf817  addpd xmm1, xmm2
000078e5533cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000078e5533cf820  ptest xmm15, xmm15
000078e5533cf826  jnz 0x000078E5533D11ED
000078e5533cf82c  lea rax, [r14+0xF0]
000078e5533cf833  movups xmm15, [r13+rax*1]
000078e5533cf839  vmovaps xmm2, [rsp+0xC0]
000078e5533cf842  vmovaps [rsp+0xC0], xmm1
000078e5533cf84b  vmovaps xmm1, [rsp+0xE0]
000078e5533cf854  vmovaps [rsp+0xE0], xmm15
000078e5533cf85d  movaps xmm13, xmm2
000078e5533cf861  addpd xmm13, xmm1
000078e5533cf866  vcmppd xmm15, xmm13, xmm13, 0x03
000078e5533cf86c  ptest xmm15, xmm15
000078e5533cf872  jnz 0x000078E5533D1338
000078e5533cf878  vmovaps xmm15, [rsp+0x120]
000078e5533cf881  vmovaps xmm2, [rsp+0xD0]
000078e5533cf88a  vmovaps [rsp+0xD0], xmm14
000078e5533cf893  movaps xmm1, xmm15
000078e5533cf897  addpd xmm1, xmm2
000078e5533cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000078e5533cf8a0  ptest xmm14, xmm14
000078e5533cf8a6  jnz 0x000078E5533D147A
000078e5533cf8ac  vmovaps xmm15, [rsp+0x100]
000078e5533cf8b5  vpermilpd xmm15, xmm15, 0x00
000078e5533cf8bb  vmovaps xmm2, [rsp+0xF0]
000078e5533cf8c4  vmovaps [rsp+0xF0], xmm1
000078e5533cf8cd  movaps xmm14, xmm2
000078e5533cf8d1  mulpd xmm14, xmm15
000078e5533cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000078e5533cf8dc  ptest xmm1, xmm1
000078e5533cf8e1  jnz 0x000078E5533D15BB
000078e5533cf8e7  vmovaps xmm1, [rsp+0xA0]
000078e5533cf8f0  vpermilpd xmm1, xmm1, 0x00
000078e5533cf8f6  vmovaps xmm2, [rsp+0xE0]
000078e5533cf8ff  vmovaps [rsp+0xE0], xmm14
000078e5533cf908  movaps xmm15, xmm2
000078e5533cf90c  mulpd xmm15, xmm1
000078e5533cf911  vcmppd xmm14, xmm15, xmm15, 0x03
000078e5533cf917  ptest xmm14, xmm14
000078e5533cf91d  jnz 0x000078E5533D16FE
000078e5533cf923  lea rax, [r14+0xE0]
000078e5533cf92a  movups xmm1, [r13+rax*1]
000078e5533cf930  vmovaps xmm14, [rsp+0x100]
000078e5533cf939  vpermilpd xmm14, xmm14, 0x00
000078e5533cf93f  vmovaps [rsp+0x100], xmm1
000078e5533cf948  vmovaps xmm1, [rsp+0x30]
000078e5533cf94e  vmovaps [rsp+0x30], xmm15
000078e5533cf954  movaps xmm2, xmm1
000078e5533cf957  mulpd xmm2, xmm14
000078e5533cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000078e5533cf961  ptest xmm15, xmm15
000078e5533cf967  jnz 0x000078E5533D184A
000078e5533cf96d  vmovaps [rsp+0x120], xmm10
000078e5533cf976  vmovaps xmm1, [rsp+0x120]
000078e5533cf97f  por xmm10, xmm1
000078e5533cf984  movaps [r15+0x300], xmm10
000078e5533cf98c  vmovaps [rsp+0x120], xmm8
000078e5533cf995  vmovaps xmm1, [rsp+0x120]
000078e5533cf99e  por xmm8, xmm1
000078e5533cf9a3  movaps [r15+0x190], xmm8
000078e5533cf9ab  vmovaps xmm1, [rsp+0xA0]
000078e5533cf9b4  vpermilpd xmm1, xmm1, 0x00
000078e5533cf9ba  vmovaps xmm14, [rsp+0x100]
000078e5533cf9c3  vmovaps [rsp+0x100], xmm13
000078e5533cf9cc  movaps xmm15, xmm14
000078e5533cf9d0  mulpd xmm15, xmm1
000078e5533cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000078e5533cf9db  ptest xmm13, xmm13
000078e5533cf9e1  jnz 0x000078E5533D198B
000078e5533cf9e7  lea rax, [r14+0x90]
000078e5533cf9ee  movups xmm1, [r13+rax*1]
000078e5533cf9f4  vmovaps [rsp+0x120], xmm4
000078e5533cf9fd  vmovaps xmm14, [rsp+0x120]
000078e5533cfa06  por xmm4, xmm14
000078e5533cfa0b  movaps [r15+0x1C0], xmm4
000078e5533cfa13  vmovaps [rsp+0x120], xmm11
000078e5533cfa1c  vmovaps xmm14, [rsp+0x120]
000078e5533cfa25  por xmm11, xmm14
000078e5533cfa2a  movaps [r15+0x200], xmm11
000078e5533cfa32  vmovaps [rsp+0x120], xmm5
000078e5533cfa3b  vmovaps xmm14, [rsp+0x120]
000078e5533cfa44  por xmm5, xmm14
000078e5533cfa49  movaps [r15+0x2D0], xmm5
000078e5533cfa51  vmovaps [rsp+0x120], xmm12
000078e5533cfa5a  vmovaps xmm14, [rsp+0x120]
000078e5533cfa63  por xmm12, xmm14
000078e5533cfa68  movaps [r15+0x2E0], xmm12
000078e5533cfa70  vmovaps xmm13, [rsp+0x110]
000078e5533cfa79  vmovaps [rsp+0x110], xmm1
000078e5533cfa82  vmovaps xmm1, [rsp+0xE0]
000078e5533cfa8b  vmovaps [rsp+0xE0], xmm15
000078e5533cfa94  movaps xmm14, xmm13
000078e5533cfa98  addpd xmm14, xmm1
000078e5533cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000078e5533cfaa3  ptest xmm15, xmm15
000078e5533cfaa9  jnz 0x000078E5533D1AD8
000078e5533cfaaf  vmovaps xmm1, [rsp+0xA0]
000078e5533cfab8  vpermilpd xmm1, xmm1, 0x00
000078e5533cfabe  vmovaps xmm13, [rsp+0x110]
000078e5533cfac7  vmovaps [rsp+0x110], xmm14
000078e5533cfad0  movaps xmm15, xmm13
000078e5533cfad4  mulpd xmm15, xmm1
000078e5533cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000078e5533cfadf  ptest xmm14, xmm14
000078e5533cfae5  jnz 0x000078E5533D1C1B
000078e5533cfaeb  lea rax, [r14+0x80]
000078e5533cfaf2  movups xmm1, [r13+rax*1]
000078e5533cfaf8  vmovaps xmm13, [rsp+0xC0]
000078e5533cfb01  vmovaps [rsp+0xC0], xmm1
000078e5533cfb0a  movaps xmm14, xmm13
000078e5533cfb0e  addpd xmm14, xmm2
000078e5533cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000078e5533cfb19  ptest xmm1, xmm1
000078e5533cfb1e  jnz 0x000078E5533D1D68
000078e5533cfb24  vmovaps xmm13, [rsp+0x100]
000078e5533cfb2d  vmovaps xmm2, [rsp+0x30]
000078e5533cfb33  vmovaps [rsp+0x30], xmm15
000078e5533cfb39  movaps xmm1, xmm13
000078e5533cfb3d  addpd xmm1, xmm2
000078e5533cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000078e5533cfb46  ptest xmm15, xmm15
000078e5533cfb4c  jnz 0x000078E5533D1EAB
000078e5533cfb52  vmovaps xmm15, [rsp+0x20]
000078e5533cfb58  vmovaps xmm13, [rsp+0x20]
000078e5533cfb5e  por xmm15, xmm13
000078e5533cfb63  movaps [r15+0x2F0], xmm15
000078e5533cfb6b  vmovaps xmm13, [rsp+0xA0]
000078e5533cfb74  vpermilpd xmm13, xmm13, 0x00
000078e5533cfb7a  vmovaps [rsp+0x20], xmm1
000078e5533cfb80  vmovaps xmm1, [rsp+0xC0]
000078e5533cfb89  vmovaps [rsp+0xA0], xmm15
000078e5533cfb92  movaps xmm2, xmm1
000078e5533cfb95  mulpd xmm2, xmm13
000078e5533cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000078e5533cfb9f  ptest xmm15, xmm15
000078e5533cfba5  jnz 0x000078E5533D1FEC
000078e5533cfbab  lea rax, [r14+0xD0]
000078e5533cfbb2  movups xmm1, [r13+rax*1]
000078e5533cfbb8  vmovaps xmm13, [rsp+0xF0]
000078e5533cfbc1  vmovaps [rsp+0xC0], xmm1
000078e5533cfbca  vmovaps xmm1, [rsp+0xE0]
000078e5533cfbd3  vmovaps [rsp+0xE0], xmm14
000078e5533cfbdc  movaps xmm15, xmm13
000078e5533cfbe0  addpd xmm15, xmm1
000078e5533cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000078e5533cfbeb  ptest xmm14, xmm14
000078e5533cfbf1  jnz 0x000078E5533D2137
000078e5533cfbf7  vmovaps xmm1, [rsp+0xB0]
000078e5533cfc00  vpermilpd xmm1, xmm1, 0x00
000078e5533cfc06  movaps xmm14, xmm11
000078e5533cfc0a  mulpd xmm14, xmm1
000078e5533cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000078e5533cfc15  ptest xmm13, xmm13
000078e5533cfc1b  jnz 0x000078E5533D227A
000078e5533cfc21  movaps [r15+0x260], xmm14
000078e5533cfc29  vxorps xmm1, xmm1, xmm1
000078e5533cfc2d  vpbroadcastq xmm1, xmm1
000078e5533cfc32  movaps [r15+0x1B0], xmm1
000078e5533cfc3a  vmovaps xmm1, [rsp+0xB0]
000078e5533cfc43  vpermilpd xmm1, xmm1, 0x00
000078e5533cfc49  vmovaps xmm11, [rsp+0xC0]
000078e5533cfc52  vmovaps [rsp+0xC0], xmm15
000078e5533cfc5b  movaps xmm13, xmm11
000078e5533cfc5f  mulpd xmm13, xmm1
000078e5533cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000078e5533cfc6a  ptest xmm15, xmm15
000078e5533cfc70  jnz 0x000078E5533D23BD
000078e5533cfc76  lea rax, [r14+0xC0]
000078e5533cfc7d  movups xmm1, [r13+rax*1]
000078e5533cfc83  vmovaps xmm11, [rsp+0x110]
000078e5533cfc8c  vmovaps [rsp+0xF0], xmm1
000078e5533cfc95  vmovaps xmm1, [rsp+0x30]
000078e5533cfc9b  vmovaps [rsp+0x30], xmm14
000078e5533cfca1  movaps xmm15, xmm11
000078e5533cfca5  addpd xmm15, xmm1
000078e5533cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000078e5533cfcb0  ptest xmm14, xmm14
000078e5533cfcb6  jnz 0x000078E5533D250A
000078e5533cfcbc  vmovaps [rsp+0x100], xmm9
000078e5533cfcc5  vmovaps xmm1, [rsp+0x100]
000078e5533cfcce  por xmm9, xmm1
000078e5533cfcd3  movaps [r15+0x270], xmm9
000078e5533cfcdb  vmovaps [rsp+0x100], xmm6
000078e5533cfce4  vmovaps xmm1, [rsp+0x100]
000078e5533cfced  por xmm6, xmm1
000078e5533cfcf1  movaps [r15+0x1A0], xmm6
000078e5533cfcf9  vmovaps xmm14, [rsp+0xB0]
000078e5533cfd02  vpermilpd xmm14, xmm14, 0x00
000078e5533cfd08  vmovaps xmm6, [rsp+0xF0]
000078e5533cfd11  vmovaps [rsp+0xF0], xmm1
000078e5533cfd1a  movaps xmm11, xmm6
000078e5533cfd1e  mulpd xmm11, xmm14
000078e5533cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000078e5533cfd29  ptest xmm1, xmm1
000078e5533cfd2e  jnz 0x000078E5533D264D
000078e5533cfd34  lea rax, [r14+0x20]
000078e5533cfd38  movups xmm1, [r13+rax*1]
000078e5533cfd3e  movaps [r15+0x110], xmm1
000078e5533cfd46  vmovaps xmm6, [rsp+0xE0]
000078e5533cfd4f  vmovaps [rsp+0xE0], xmm1
000078e5533cfd58  movaps xmm14, xmm6
000078e5533cfd5c  addpd xmm14, xmm2
000078e5533cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000078e5533cfd67  ptest xmm1, xmm1
000078e5533cfd6c  jnz 0x000078E5533D279A
000078e5533cfd72  vmovaps xmm1, [rsp+0xB0]
000078e5533cfd7b  vpermilpd xmm1, xmm1, 0x00
000078e5533cfd81  movaps xmm6, xmm5
000078e5533cfd84  mulpd xmm6, xmm1
000078e5533cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000078e5533cfd8d  ptest xmm2, xmm2
000078e5533cfd92  jnz 0x000078E5533D28DC
000078e5533cfd98  vmovaps xmm5, [rsp+0x20]
000078e5533cfd9e  movaps xmm1, xmm5
000078e5533cfda1  addpd xmm1, xmm13
000078e5533cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000078e5533cfdab  ptest xmm2, xmm2
000078e5533cfdb0  jnz 0x000078E5533D2A1C
000078e5533cfdb6  vmovaps xmm13, [rsp+0x80]
000078e5533cfdbf  vpermilpd xmm13, xmm13, 0x00
000078e5533cfdc5  vmovaps xmm2, [rsp+0xE0]
000078e5533cfdce  vmovaps [rsp+0x20], xmm1
000078e5533cfdd4  movaps xmm5, xmm2
000078e5533cfdd7  mulpd xmm5, xmm13
000078e5533cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000078e5533cfde1  ptest xmm1, xmm1
000078e5533cfde6  jnz 0x000078E5533D2B5D
000078e5533cfdec  vmovaps xmm1, [rsp+0x80]
000078e5533cfdf5  vpermilpd xmm1, xmm1, 0x00
000078e5533cfdfb  movaps xmm13, xmm10
000078e5533cfdff  mulpd xmm13, xmm1
000078e5533cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000078e5533cfe0a  ptest xmm2, xmm2
000078e5533cfe0f  jnz 0x000078E5533D2C9E
000078e5533cfe15  vmovaps xmm10, [rsp+0x30]
000078e5533cfe1b  movaps xmm1, xmm15
000078e5533cfe1f  addpd xmm1, xmm10
000078e5533cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000078e5533cfe29  ptest xmm2, xmm2
000078e5533cfe2e  jnz 0x000078E5533D2DE1
000078e5533cfe34  vmovaps xmm10, [rsp+0xC0]
000078e5533cfe3d  movaps xmm15, xmm10
000078e5533cfe41  addpd xmm15, xmm11
000078e5533cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000078e5533cfe4c  ptest xmm2, xmm2
000078e5533cfe51  jnz 0x000078E5533D2F23
000078e5533cfe57  vmovaps xmm11, [rsp+0x80]
000078e5533cfe60  vpermilpd xmm11, xmm11, 0x00
000078e5533cfe66  movaps xmm10, xmm12
000078e5533cfe6a  mulpd xmm10, xmm11
000078e5533cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000078e5533cfe75  ptest xmm2, xmm2
000078e5533cfe7a  jnz 0x000078E5533D3067
000078e5533cfe80  vmovaps xmm12, [rsp+0x80]
000078e5533cfe89  vpermilpd xmm12, xmm12, 0x00
000078e5533cfe8f  vmovaps xmm2, [rsp+0xA0]
000078e5533cfe98  vmovaps [rsp+0x30], xmm1
000078e5533cfe9e  movaps xmm11, xmm2
000078e5533cfea2  mulpd xmm11, xmm12
000078e5533cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000078e5533cfead  ptest xmm1, xmm1
000078e5533cfeb2  jnz 0x000078E5533D31AB
000078e5533cfeb8  movaps xmm1, xmm14
000078e5533cfebc  addpd xmm1, xmm6
000078e5533cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000078e5533cfec5  ptest xmm12, xmm12
000078e5533cfecb  jnz 0x000078E5533D32EE
000078e5533cfed1  vmovaps xmm12, [rsp+0x20]
000078e5533cfed7  movaps xmm14, xmm12
000078e5533cfedb  addpd xmm14, xmm5
000078e5533cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000078e5533cfee6  ptest xmm6, xmm6
000078e5533cfeeb  jnz 0x000078E5533D342F
000078e5533cfef1  vmovaps xmm12, [rsp+0x90]
000078e5533cfefa  vpermilpd xmm12, xmm12, 0x00
000078e5533cff00  movaps xmm6, xmm9
000078e5533cff04  mulpd xmm6, xmm12
000078e5533cff09  vcmppd xmm5, xmm6, xmm6, 0x03
000078e5533cff0e  ptest xmm5, xmm5
000078e5533cff13  jnz 0x000078E5533D3572
000078e5533cff19  movaps xmm12, xmm15
000078e5533cff1d  addpd xmm12, xmm13
000078e5533cff22  vcmppd xmm9, xmm12, xmm12, 0x03
000078e5533cff28  ptest xmm9, xmm9
000078e5533cff2e  jnz 0x000078E5533D36B4
000078e5533cff34  vmovaps xmm13, [rsp+0x30]
000078e5533cff3a  movaps xmm15, xmm13
000078e5533cff3e  addpd xmm15, xmm10
000078e5533cff43  vcmppd xmm9, xmm15, xmm15, 0x03
000078e5533cff49  ptest xmm9, xmm9
000078e5533cff4f  jnz 0x000078E5533D37F8
000078e5533cff55  vmovaps xmm13, [rsp+0xD0]
000078e5533cff5e  vmovaps xmm10, [rsp+0xD0]
000078e5533cff67  por xmm13, xmm10
000078e5533cff6c  movaps [r15+0x250], xmm13
000078e5533cff74  vmovaps [rsp+0x20], xmm7
000078e5533cff7a  vmovaps xmm13, [rsp+0x20]
000078e5533cff80  por xmm7, xmm13
000078e5533cff85  movaps [r15+0x2A0], xmm7
000078e5533cff8d  vmovaps [rsp+0x20], xmm3
000078e5533cff93  vmovaps xmm13, [rsp+0x20]
000078e5533cff99  por xmm3, xmm13
000078e5533cff9e  movaps [r15+0x1D0], xmm3
000078e5533cffa6  lea rax, [r14+0x40]
000078e5533cffaa  movups xmm13, [r13+rax*1]
000078e5533cffb0  movaps [r15+0x2C0], xmm13
000078e5533cffb8  vmovaps xmm10, [rsp+0x90]
000078e5533cffc1  vpermilpd xmm10, xmm10, 0x00
000078e5533cffc7  movaps xmm9, xmm8
000078e5533cffcb  mulpd xmm9, xmm10
000078e5533cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000078e5533cffd6  ptest xmm5, xmm5
000078e5533cffdb  jnz 0x000078E5533D3946
000078e5533cffe1  movaps xmm10, xmm1
000078e5533cffe5  addpd xmm10, xmm11
000078e5533cffea  vcmppd xmm8, xmm10, xmm10, 0x03
000078e5533cfff0  ptest xmm8, xmm8
000078e5533cfff6  jnz 0x000078E5533D3A8A
000078e5533cfffc  movaps xmm1, xmm14
000078e5533d0000  addpd xmm1, xmm6
000078e5533d0004  vcmppd xmm11, xmm1, xmm1, 0x03
000078e5533d0009  ptest xmm11, xmm11
000078e5533d000f  jnz 0x000078E5533D3BCD
000078e5533d0015  vmovaps xmm14, [rsp+0x90]
000078e5533d001e  vpermilpd xmm14, xmm14, 0x00
000078e5533d0024  movaps xmm11, xmm13
000078e5533d0028  mulpd xmm11, xmm14
000078e5533d002d  vcmppd xmm8, xmm11, xmm11, 0x03
000078e5533d0033  ptest xmm8, xmm8
000078e5533d0039  jnz 0x000078E5533D3D0E
000078e5533d003f  vmovaps xmm14, [rsp+0x90]
000078e5533d0048  vpermilpd xmm14, xmm14, 0x00
000078e5533d004e  vmovaps xmm8, [rsp+0x10]
000078e5533d0054  movaps xmm13, xmm8
000078e5533d0058  mulpd xmm13, xmm14
000078e5533d005d  vcmppd xmm6, xmm13, xmm13, 0x03
000078e5533d0063  ptest xmm6, xmm6
000078e5533d0068  jnz 0x000078E5533D3E52
000078e5533d006e  vmovaps xmm14, [rsp+0x60]
000078e5533d0074  vpermilpd xmm14, xmm14, 0x00
000078e5533d007a  movaps xmm8, xmm7
000078e5533d007e  mulpd xmm8, xmm14
000078e5533d0083  vcmppd xmm6, xmm8, xmm8, 0x03
000078e5533d0089  ptest xmm6, xmm6
000078e5533d008e  jnz 0x000078E5533D3F96
000078e5533d0094  movaps xmm14, xmm12
000078e5533d0098  addpd xmm14, xmm9
000078e5533d009d  vcmppd xmm7, xmm14, xmm14, 0x03
000078e5533d00a3  ptest xmm7, xmm7
000078e5533d00a8  jnz 0x000078E5533D40D9
000078e5533d00ae  vmovaps xmm12, [rsp+0x60]
000078e5533d00b4  vpermilpd xmm12, xmm12, 0x00
000078e5533d00ba  vmovaps xmm7, [rsp+0xF0]
000078e5533d00c3  movaps xmm9, xmm7
000078e5533d00c7  mulpd xmm9, xmm12
000078e5533d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000078e5533d00d2  ptest xmm6, xmm6
000078e5533d00d7  jnz 0x000078E5533D421D
000078e5533d00dd  movaps xmm12, xmm15
000078e5533d00e1  addpd xmm12, xmm11
000078e5533d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000078e5533d00ec  ptest xmm7, xmm7
000078e5533d00f1  jnz 0x000078E5533D4360
000078e5533d00f7  vmovaps xmm15, [rsp+0x60]
000078e5533d00fd  vpermilpd xmm15, xmm15, 0x00
000078e5533d0103  vmovaps xmm7, [rsp+0x40]
000078e5533d0109  movaps xmm11, xmm7
000078e5533d010d  mulpd xmm11, xmm15
000078e5533d0112  vcmppd xmm6, xmm11, xmm11, 0x03
000078e5533d0118  ptest xmm6, xmm6
000078e5533d011d  jnz 0x000078E5533D44A4
000078e5533d0123  movaps xmm15, xmm10
000078e5533d0127  addpd xmm15, xmm13
000078e5533d012c  vcmppd xmm7, xmm15, xmm15, 0x03
000078e5533d0132  ptest xmm7, xmm7
000078e5533d0137  jnz 0x000078E5533D45E7
000078e5533d013d  vmovaps xmm13, [rsp+0x60]
000078e5533d0143  vpermilpd xmm13, xmm13, 0x00
000078e5533d0149  vmovaps xmm7, [rsp+0x50]
000078e5533d014f  movaps xmm10, xmm7
000078e5533d0153  mulpd xmm10, xmm13
000078e5533d0158  vcmppd xmm6, xmm10, xmm10, 0x03
000078e5533d015e  ptest xmm6, xmm6
000078e5533d0163  jnz 0x000078E5533D472B
000078e5533d0169  movaps xmm13, xmm1
000078e5533d016d  addpd xmm13, xmm8
000078e5533d0172  vcmppd xmm7, xmm13, xmm13, 0x03
000078e5533d0178  ptest xmm7, xmm7
000078e5533d017d  jnz 0x000078E5533D486E
000078e5533d0183  lea rax, [r14+0x70]
000078e5533d0187  movups xmm1, [r13+rax*1]
000078e5533d018d  movaps [r15+0x240], xmm1
000078e5533d0195  movaps xmm8, xmm14
000078e5533d0199  addpd xmm8, xmm9
000078e5533d019e  vcmppd xmm7, xmm8, xmm8, 0x03
000078e5533d01a4  ptest xmm7, xmm7
000078e5533d01a9  jnz 0x000078E5533D49BB
000078e5533d01af  movaps [r15+0x170], xmm8
000078e5533d01b7  vmovaps xmm14, [rsp+0x70]
000078e5533d01bd  vpermilpd xmm14, xmm14, 0x00
000078e5533d01c3  movaps xmm9, xmm1
000078e5533d01c7  mulpd xmm9, xmm14
000078e5533d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000078e5533d01d2  ptest xmm7, xmm7
000078e5533d01d7  jnz 0x000078E5533D4AFF
000078e5533d01dd  vmovaps xmm1, [rsp+0x70]
000078e5533d01e3  vpermilpd xmm1, xmm1, 0x00
000078e5533d01e9  movaps xmm14, xmm4
000078e5533d01ed  mulpd xmm14, xmm1
000078e5533d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000078e5533d01f8  ptest xmm7, xmm7
000078e5533d01fd  jnz 0x000078E5533D4C42
000078e5533d0203  movaps [r15+0x180], xmm14
000078e5533d020b  movaps xmm1, xmm12
000078e5533d020f  addpd xmm1, xmm11
000078e5533d0214  vcmppd xmm7, xmm1, xmm1, 0x03
000078e5533d0219  ptest xmm7, xmm7
000078e5533d021e  jnz 0x000078E5533D4D84
000078e5533d0224  movaps [r15+0x210], xmm1
000078e5533d022c  movups xmm12, [r13+r14*1]
000078e5533d0232  lea rax, [r14+0x10]
000078e5533d0236  movups xmm11, [r13+rax*1]
000078e5533d023c  movaps [r15+0x230], xmm11
000078e5533d0244  movaps xmm7, xmm15
000078e5533d0248  addpd xmm7, xmm10
000078e5533d024d  vcmppd xmm6, xmm7, xmm7, 0x03
000078e5533d0252  ptest xmm6, xmm6
000078e5533d0257  jnz 0x000078E5533D4EDA
000078e5533d025d  movaps [r15+0x130], xmm7
000078e5533d0265  vmovaps xmm15, [rsp+0x70]
000078e5533d026b  vpermilpd xmm15, xmm15, 0x00
000078e5533d0271  movaps xmm10, xmm11
000078e5533d0275  mulpd xmm10, xmm15
000078e5533d027a  vcmppd xmm6, xmm10, xmm10, 0x03
000078e5533d0280  ptest xmm6, xmm6
000078e5533d0285  jnz 0x000078E5533D501C
000078e5533d028b  movaps [r15+0x220], xmm10
000078e5533d0293  vmovaps xmm15, [rsp+0x70]
000078e5533d0299  vpermilpd xmm15, xmm15, 0x00
000078e5533d029f  movaps xmm11, xmm12
000078e5533d02a3  mulpd xmm11, xmm15
000078e5533d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000078e5533d02ae  ptest xmm6, xmm6
000078e5533d02b3  jnz 0x000078E5533D5160
000078e5533d02b9  movaps xmm15, xmm13
000078e5533d02bd  addpd xmm15, xmm9
000078e5533d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000078e5533d02c8  ptest xmm12, xmm12
000078e5533d02ce  jnz 0x000078E5533D52A4
000078e5533d02d4  movaps [r15+0x140], xmm15
000078e5533d02dc  movaps xmm13, xmm8
000078e5533d02e0  addpd xmm13, xmm14
000078e5533d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000078e5533d02eb  ptest xmm12, xmm12
000078e5533d02f1  jnz 0x000078E5533D53E8
000078e5533d02f7  movaps [r15+0x150], xmm13
000078e5533d02ff  movaps xmm14, xmm1
000078e5533d0303  addpd xmm14, xmm10
000078e5533d0308  vcmppd xmm12, xmm14, xmm14, 0x03
000078e5533d030e  ptest xmm12, xmm12
000078e5533d0314  jnz 0x000078E5533D552C
000078e5533d031a  movaps [r15+0x160], xmm14
000078e5533d0322  movaps xmm1, xmm7
000078e5533d0325  addpd xmm1, xmm11
000078e5533d032a  vcmppd xmm12, xmm1, xmm1, 0x03
000078e5533d032f  ptest xmm12, xmm12
000078e5533d0335  jnz 0x000078E5533D566F
000078e5533d033b  movaps [r15+0x120], xmm1
000078e5533d0343  mov eax, 0x430920
000078e5533d0348  movups [r13+rax*1], xmm15
000078e5533d034e  mov eax, 0x430930
000078e5533d0353  movups [r13+rax*1], xmm13
000078e5533d0359  mov eax, 0x430940
000078e5533d035e  movups [r13+rax*1], xmm14
000078e5533d0364  mov eax, 0x430950
000078e5533d0369  movups [r13+rax*1], xmm1
000078e5533d036f  mov eax, [r15+0x108]
000078e5533d0376  sahf
000078e5533d0377  jnz 0x000078E5533D03A9
000078e5533d0379  cmp dword ptr [r15+0x318], 0x00
000078e5533d0381  jz 0x000078E5533DB900
000078e5533d0387  nop [rax+rax*1], ax
000078e5533d0390  nop [rax+rax*1], eax
000078e5533d0398  mov eax, 0x410444
000078e5533d039d  mov [r15+0x100], rax
000078e5533d03a4  jmp 0x000078E5531FE110
000078e5533d03a9  cmp dword ptr [r15+0x318], 0x00
000078e5533d03b1  jz 0x000078E5533D57E0
000078e5533d03b7  nop [rax+rax*1], ax
000078e5533d03c0  nop [rax+rax*1], eax
000078e5533d03c8  mov eax, 0x410278
000078e5533d03cd  mov [r15+0x100], rax
000078e5533d03d4  jmp 0x000078E5531FE110
000078e5533d03d9  int3
000078e5533d03da  call 0x000078E5532B52F0
000078e5533d03df  jmp 0x000078E5533CF016
000078e5533d03e4  call 0x000078E5532C4620
000078e5533d03e9  jmp 0x000078E5533CF023
000078e5533d03ee  call 0x000078E5532C33A0
000078e5533d03f3  jmp 0x000078E5533CF035
000078e5533d03f8  call 0x000078E5532C2120
000078e5533d03fd  jmp 0x000078E5533CF03F
000078e5533d0402  call 0x000078E5532C0860
000078e5533d0407  jmp 0x000078E5533CF067
000078e5533d040c  call 0x000078E5532BF5F0
000078e5533d0411  jmp 0x000078E5533CF073
000078e5533d0416  call 0x000078E5532C0860
000078e5533d041b  jmp 0x000078E5533CF0A5
000078e5533d0420  call 0x000078E5532BF5F0
000078e5533d0425  jmp 0x000078E5533CF0B1
000078e5533d042a  call 0x000078E5532C4740
000078e5533d042f  jmp 0x000078E5533CF0BE
000078e5533d0434  call 0x000078E5532B5400
000078e5533d0439  jmp 0x000078E5533CF0CB
000078e5533d043e  call 0x000078E5532B52F0
000078e5533d0443  jmp 0x000078E5533CF0D8
000078e5533d0448  call 0x000078E5532C4620
000078e5533d044d  jmp 0x000078E5533CF0E5
000078e5533d0452  call 0x000078E5532C0860
000078e5533d0457  jmp 0x000078E5533CF10D
000078e5533d045c  call 0x000078E5532BF5F0
000078e5533d0461  jmp 0x000078E5533CF119
000078e5533d0466  call 0x000078E553209D70
000078e5533d046b  jmp 0x000078E5533CF11F
000078e5533d0470  call 0x000078E5532BE9C0
000078e5533d0475  jmp 0x000078E5533CF129
000078e5533d047a  call 0x000078E5532C0860
000078e5533d047f  jmp 0x000078E5533CF151
000078e5533d0484  call 0x000078E5532BF5F0
000078e5533d0489  jmp 0x000078E5533CF15D
000078e5533d048e  call 0x000078E5532BD750
000078e5533d0493  jmp 0x000078E5533CF16A
000078e5533d0498  call 0x000078E5532BC4E0
000078e5533d049d  jmp 0x000078E5533CF177
000078e5533d04a2  call 0x000078E5532C4740
000078e5533d04a7  jmp 0x000078E5533CF184
000078e5533d04ac  call 0x000078E5532B5400
000078e5533d04b1  jmp 0x000078E5533CF191
000078e5533d04b6  call 0x000078E5532B52F0
000078e5533d04bb  jmp 0x000078E5533CF19E
000078e5533d04c0  call 0x000078E5532C4620
000078e5533d04c5  jmp 0x000078E5533CF1AB
000078e5533d04ca  call 0x000078E5532C0860
000078e5533d04cf  jmp 0x000078E5533CF1BE
000078e5533d04d4  call 0x000078E5532BB270
000078e5533d04d9  jmp 0x000078E5533CF1CB
000078e5533d04de  call 0x000078E5532BA000
000078e5533d04e3  jmp 0x000078E5533CF1D8
000078e5533d04e8  call 0x000078E5532B8D90
000078e5533d04ed  jmp 0x000078E5533CF1E5
000078e5533d04f2  call 0x000078E5532B8A20
000078e5533d04f7  jmp 0x000078E5533CF1F2
000078e5533d04fc  call 0x000078E5532B5400
000078e5533d0501  jmp 0x000078E5533CF1FC
000078e5533d0506  call 0x000078E5532C2240
000078e5533d050b  jmp 0x000078E5533CF206
000078e5533d0510  call 0x000078E5532B52F0
000078e5533d0515  jmp 0x000078E5533CF210
000078e5533d051a  call 0x000078E5532C2120
000078e5533d051f  jmp 0x000078E5533CF21A
000078e5533d0524  call 0x000078E5532B77B0
000078e5533d0529  jmp 0x000078E5533CF224
000078e5533d052e  call 0x000078E5532B6550
000078e5533d0533  jmp 0x000078E5533CF22E
000078e5533d0538  call 0x000078E5532BFD50
000078e5533d053d  jmp 0x000078E5533CF240
000078e5533d0542  call 0x000078E5532B8EA0
000078e5533d0547  jmp 0x000078E5533CF24A
000078e5533d054c  call 0x000078E5532BFC30
000078e5533d0551  jmp 0x000078E5533CF257
000078e5533d0556  call 0x000078E5532B8D90
000078e5533d055b  jmp 0x000078E5533CF264
000078e5533d0560  call 0x000078E5532C2240
000078e5533d0565  jmp 0x000078E5533CF271
000078e5533d056a  call 0x000078E5532B5400
000078e5533d056f  jmp 0x000078E5533CF27E
000078e5533d0574  call 0x000078E5532B52F0
000078e5533d0579  jmp 0x000078E5533CF28B
000078e5533d057e  call 0x000078E5532C2120
000078e5533d0583  jmp 0x000078E5533CF298
000078e5533d0588  call 0x000078E5532B52F0
000078e5533d058d  jmp 0x000078E5533CF2AB
000078e5533d0592  call 0x000078E5532B52F0
000078e5533d0597  jmp 0x000078E5533CF2BE
000078e5533d059c  call 0x000078E5532B52F0
000078e5533d05a1  jmp 0x000078E5533CF2D1
000078e5533d05a6  call 0x000078E5532B52F0
000078e5533d05ab  jmp 0x000078E5533CF2E4
000078e5533d05b0  call 0x000078E5532C2240
000078e5533d05b5  jmp 0x000078E5533CF2F9
000078e5533d05ba  call 0x000078E5532C2240
000078e5533d05bf  jmp 0x000078E5533CF30C
000078e5533d05c4  call 0x000078E5532C2120
000078e5533d05c9  jmp 0x000078E5533CF319
000078e5533d05ce  call 0x000078E5532B52F0
000078e5533d05d3  jmp 0x000078E5533CF32C
000078e5533d05d8  call 0x000078E5532B52F0
000078e5533d05dd  jmp 0x000078E5533CF34F
000078e5533d05e2  call 0x000078E5532B52F0
000078e5533d05e7  jmp 0x000078E5533CF362
000078e5533d05ec  call 0x000078E5531FF540
000078e5533d05f1  jmp 0x000078E5533CF380
000078e5533d05f6  call 0x000078E553208C20
000078e5533d05fb  jmp 0x000078E5533CF38A
000078e5533d0600  call 0x000078E5532D6600
000078e5533d0605  jmp 0x000078E5533CF396
000078e5533d060a  call 0x000078E5531FF540
000078e5533d060f  jmp 0x000078E5533CF3A6
000078e5533d0614  call 0x000078E5532C0370
000078e5533d0619  jmp 0x000078E5533CF3D4
000078e5533d061e  call 0x000078E5532BF100
000078e5533d0623  jmp 0x000078E5533CF3DD
000078e5533d0628  call 0x000078E5532C0370
000078e5533d062d  jmp 0x000078E5533CF43B
000078e5533d0632  call 0x000078E5532BF100
000078e5533d0637  jmp 0x000078E5533CF444
000078e5533d063c  call 0x000078E5532C0370
000078e5533d0641  jmp 0x000078E5533CF48B
000078e5533d0646  call 0x000078E5532BF100
000078e5533d064b  jmp 0x000078E5533CF494
000078e5533d0650  call 0x000078E55320B720
000078e5533d0655  jmp 0x000078E5533CF4D7
000078e5533d065a  call 0x000078E5532B47C0
000078e5533d065f  jmp 0x000078E5533CF4EA
000078e5533d0664  call 0x000078E553208B00
000078e5533d0669  jmp 0x000078E5533CF501
000078e5533d066e  call 0x000078E5531FF430
000078e5533d0673  jmp 0x000078E5533CF514
000078e5533d0678  call 0x000078E5531FF430
000078e5533d067d  jmp 0x000078E5533CF527
000078e5533d0682  sub rsp, 0x08
000078e5533d0686  push rax
000078e5533d0687  push rcx
000078e5533d0688  push rdx
000078e5533d0689  push rdi
000078e5533d068a  push rsi
000078e5533d068b  push r8
000078e5533d068d  push r9
000078e5533d068f  push r10
000078e5533d0691  push r11
000078e5533d0693  sub rsp, 0xF0
000078e5533d069a  vmovaps [rsp], xmm0
000078e5533d069f  vmovaps [rsp+0x10], xmm2
000078e5533d06a5  vmovaps [rsp+0x20], xmm3
000078e5533d06ab  vmovaps [rsp+0x30], xmm4
000078e5533d06b1  vmovaps [rsp+0x40], xmm5
000078e5533d06b7  vmovaps [rsp+0x50], xmm6
000078e5533d06bd  vmovaps [rsp+0x60], xmm7
000078e5533d06c3  vmovaps [rsp+0x70], xmm8
000078e5533d06c9  vmovaps [rsp+0x80], xmm9
000078e5533d06d2  vmovaps [rsp+0x90], xmm10
000078e5533d06db  vmovaps [rsp+0xA0], xmm11
000078e5533d06e4  vmovaps [rsp+0xB0], xmm12
000078e5533d06ed  vmovaps [rsp+0xC0], xmm13
000078e5533d06f6  vmovaps [rsp+0xD0], xmm14
000078e5533d06ff  vmovaps [rsp+0xE0], xmm15
000078e5533d0708  sub rsp, 0x30
000078e5533d070c  movaps [rsp], xmm1
000078e5533d0710  movaps [rsp+0x10], xmm15
000078e5533d0716  movaps [rsp+0x20], xmm14
000078e5533d071c  lea rdi, [rsp]
000078e5533d0720  mov esi, 0x00
000078e5533d0725  mov rax, 0x5F83D5E17530
000078e5533d072f  call rax
000078e5533d0731  movaps xmm1, [rsp]
000078e5533d0735  add rsp, 0x30
000078e5533d0739  vmovaps xmm0, [rsp]
000078e5533d073e  vmovaps xmm2, [rsp+0x10]
000078e5533d0744  vmovaps xmm3, [rsp+0x20]
000078e5533d074a  vmovaps xmm4, [rsp+0x30]
000078e5533d0750  vmovaps xmm5, [rsp+0x40]
000078e5533d0756  vmovaps xmm6, [rsp+0x50]
000078e5533d075c  vmovaps xmm7, [rsp+0x60]
000078e5533d0762  vmovaps xmm8, [rsp+0x70]
000078e5533d0768  vmovaps xmm9, [rsp+0x80]
000078e5533d0771  vmovaps xmm10, [rsp+0x90]
000078e5533d077a  vmovaps xmm11, [rsp+0xA0]
000078e5533d0783  vmovaps xmm12, [rsp+0xB0]
000078e5533d078c  vmovaps xmm13, [rsp+0xC0]
000078e5533d0795  vmovaps xmm14, [rsp+0xD0]
000078e5533d079e  vmovaps xmm15, [rsp+0xE0]
000078e5533d07a7  add rsp, 0xF0
000078e5533d07ae  pop r11
000078e5533d07b0  pop r10
000078e5533d07b2  pop r9
000078e5533d07b4  pop r8
000078e5533d07b6  pop rsi
000078e5533d07b7  pop rdi
000078e5533d07b8  pop rdx
000078e5533d07b9  pop rcx
000078e5533d07ba  pop rax
000078e5533d07bb  add rsp, 0x08
000078e5533d07bf  jmp 0x000078E5533CF581
000078e5533d07c4  sub rsp, 0x08
000078e5533d07c8  push rax
000078e5533d07c9  push rcx
000078e5533d07ca  push rdx
000078e5533d07cb  push rdi
000078e5533d07cc  push rsi
000078e5533d07cd  push r8
000078e5533d07cf  push r9
000078e5533d07d1  push r10
000078e5533d07d3  push r11
000078e5533d07d5  sub rsp, 0xF0
000078e5533d07dc  vmovaps [rsp], xmm0
000078e5533d07e1  vmovaps [rsp+0x10], xmm1
000078e5533d07e7  vmovaps [rsp+0x20], xmm2
000078e5533d07ed  vmovaps [rsp+0x30], xmm3
000078e5533d07f3  vmovaps [rsp+0x40], xmm4
000078e5533d07f9  vmovaps [rsp+0x50], xmm5
000078e5533d07ff  vmovaps [rsp+0x60], xmm6
000078e5533d0805  vmovaps [rsp+0x70], xmm7
000078e5533d080b  vmovaps [rsp+0x80], xmm8
000078e5533d0814  vmovaps [rsp+0x90], xmm9
000078e5533d081d  vmovaps [rsp+0xA0], xmm10
000078e5533d0826  vmovaps [rsp+0xB0], xmm11
000078e5533d082f  vmovaps [rsp+0xC0], xmm12
000078e5533d0838  vmovaps [rsp+0xD0], xmm14
000078e5533d0841  vmovaps [rsp+0xE0], xmm15
000078e5533d084a  sub rsp, 0x30
000078e5533d084e  movaps [rsp], xmm13
000078e5533d0853  movaps [rsp+0x10], xmm1
000078e5533d0858  movaps [rsp+0x20], xmm14
000078e5533d085e  lea rdi, [rsp]
000078e5533d0862  mov esi, 0x00
000078e5533d0867  mov rax, 0x5F83D5E17530
000078e5533d0871  call rax
000078e5533d0873  movaps xmm13, [rsp]
000078e5533d0878  add rsp, 0x30
000078e5533d087c  vmovaps xmm0, [rsp]
000078e5533d0881  vmovaps xmm1, [rsp+0x10]
000078e5533d0887  vmovaps xmm2, [rsp+0x20]
000078e5533d088d  vmovaps xmm3, [rsp+0x30]
000078e5533d0893  vmovaps xmm4, [rsp+0x40]
000078e5533d0899  vmovaps xmm5, [rsp+0x50]
000078e5533d089f  vmovaps xmm6, [rsp+0x60]
000078e5533d08a5  vmovaps xmm7, [rsp+0x70]
000078e5533d08ab  vmovaps xmm8, [rsp+0x80]
000078e5533d08b4  vmovaps xmm9, [rsp+0x90]
000078e5533d08bd  vmovaps xmm10, [rsp+0xA0]
000078e5533d08c6  vmovaps xmm11, [rsp+0xB0]
000078e5533d08cf  vmovaps xmm12, [rsp+0xC0]
000078e5533d08d8  vmovaps xmm14, [rsp+0xD0]
000078e5533d08e1  vmovaps xmm15, [rsp+0xE0]
000078e5533d08ea  add rsp, 0xF0
000078e5533d08f1  pop r11
000078e5533d08f3  pop r10
000078e5533d08f5  pop r9
000078e5533d08f7  pop r8
000078e5533d08f9  pop rsi
000078e5533d08fa  pop rdi
000078e5533d08fb  pop rdx
000078e5533d08fc  pop rcx
000078e5533d08fd  pop rax
000078e5533d08fe  add rsp, 0x08
000078e5533d0902  jmp 0x000078E5533CF5CF
000078e5533d0907  sub rsp, 0x08
000078e5533d090b  push rax
000078e5533d090c  push rcx
000078e5533d090d  push rdx
000078e5533d090e  push rdi
000078e5533d090f  push rsi
000078e5533d0910  push r8
000078e5533d0912  push r9
000078e5533d0914  push r10
000078e5533d0916  push r11
000078e5533d0918  sub rsp, 0xF0
000078e5533d091f  vmovaps [rsp], xmm0
000078e5533d0924  vmovaps [rsp+0x10], xmm1
000078e5533d092a  vmovaps [rsp+0x20], xmm2
000078e5533d0930  vmovaps [rsp+0x30], xmm3
000078e5533d0936  vmovaps [rsp+0x40], xmm4
000078e5533d093c  vmovaps [rsp+0x50], xmm5
000078e5533d0942  vmovaps [rsp+0x60], xmm6
000078e5533d0948  vmovaps [rsp+0x70], xmm7
000078e5533d094e  vmovaps [rsp+0x80], xmm8
000078e5533d0957  vmovaps [rsp+0x90], xmm9
000078e5533d0960  vmovaps [rsp+0xA0], xmm10
000078e5533d0969  vmovaps [rsp+0xB0], xmm11
000078e5533d0972  vmovaps [rsp+0xC0], xmm12
000078e5533d097b  vmovaps [rsp+0xD0], xmm13
000078e5533d0984  vmovaps [rsp+0xE0], xmm14
000078e5533d098d  sub rsp, 0x30
000078e5533d0991  movaps [rsp], xmm15
000078e5533d0996  movaps [rsp+0x10], xmm14
000078e5533d099c  movaps [rsp+0x20], xmm1
000078e5533d09a1  lea rdi, [rsp]
000078e5533d09a5  mov esi, 0x00
000078e5533d09aa  mov rax, 0x5F83D5E17530
000078e5533d09b4  call rax
000078e5533d09b6  movaps xmm15, [rsp]
000078e5533d09bb  add rsp, 0x30
000078e5533d09bf  vmovaps xmm0, [rsp]
000078e5533d09c4  vmovaps xmm1, [rsp+0x10]
000078e5533d09ca  vmovaps xmm2, [rsp+0x20]
000078e5533d09d0  vmovaps xmm3, [rsp+0x30]
000078e5533d09d6  vmovaps xmm4, [rsp+0x40]
000078e5533d09dc  vmovaps xmm5, [rsp+0x50]
000078e5533d09e2  vmovaps xmm6, [rsp+0x60]
000078e5533d09e8  vmovaps xmm7, [rsp+0x70]
000078e5533d09ee  vmovaps xmm8, [rsp+0x80]
000078e5533d09f7  vmovaps xmm9, [rsp+0x90]
000078e5533d0a00  vmovaps xmm10, [rsp+0xA0]
000078e5533d0a09  vmovaps xmm11, [rsp+0xB0]
000078e5533d0a12  vmovaps xmm12, [rsp+0xC0]
000078e5533d0a1b  vmovaps xmm13, [rsp+0xD0]
000078e5533d0a24  vmovaps xmm14, [rsp+0xE0]
000078e5533d0a2d  add rsp, 0xF0
000078e5533d0a34  pop r11
000078e5533d0a36  pop r10
000078e5533d0a38  pop r9
000078e5533d0a3a  pop r8
000078e5533d0a3c  pop rsi
000078e5533d0a3d  pop rdi
000078e5533d0a3e  pop rdx
000078e5533d0a3f  pop rcx
000078e5533d0a40  pop rax
000078e5533d0a41  add rsp, 0x08
000078e5533d0a45  jmp 0x000078E5533CF617
000078e5533d0a4a  sub rsp, 0x08
000078e5533d0a4e  push rax
000078e5533d0a4f  push rcx
000078e5533d0a50  push rdx
000078e5533d0a51  push rdi
000078e5533d0a52  push rsi
000078e5533d0a53  push r8
000078e5533d0a55  push r9
000078e5533d0a57  push r10
000078e5533d0a59  push r11
000078e5533d0a5b  sub rsp, 0xF0
000078e5533d0a62  vmovaps [rsp], xmm0
000078e5533d0a67  vmovaps [rsp+0x10], xmm2
000078e5533d0a6d  vmovaps [rsp+0x20], xmm3
000078e5533d0a73  vmovaps [rsp+0x30], xmm4
000078e5533d0a79  vmovaps [rsp+0x40], xmm5
000078e5533d0a7f  vmovaps [rsp+0x50], xmm6
000078e5533d0a85  vmovaps [rsp+0x60], xmm7
000078e5533d0a8b  vmovaps [rsp+0x70], xmm8
000078e5533d0a91  vmovaps [rsp+0x80], xmm9
000078e5533d0a9a  vmovaps [rsp+0x90], xmm10
000078e5533d0aa3  vmovaps [rsp+0xA0], xmm11
000078e5533d0aac  vmovaps [rsp+0xB0], xmm12
000078e5533d0ab5  vmovaps [rsp+0xC0], xmm13
000078e5533d0abe  vmovaps [rsp+0xD0], xmm14
000078e5533d0ac7  vmovaps [rsp+0xE0], xmm15
000078e5533d0ad0  sub rsp, 0x30
000078e5533d0ad4  movaps [rsp], xmm1
000078e5533d0ad8  movaps [rsp+0x10], xmm14
000078e5533d0ade  movaps [rsp+0x20], xmm10
000078e5533d0ae4  lea rdi, [rsp]
000078e5533d0ae8  mov esi, 0x00
000078e5533d0aed  mov rax, 0x5F83D5E17530
000078e5533d0af7  call rax
000078e5533d0af9  movaps xmm1, [rsp]
000078e5533d0afd  add rsp, 0x30
000078e5533d0b01  vmovaps xmm0, [rsp]
000078e5533d0b06  vmovaps xmm2, [rsp+0x10]
000078e5533d0b0c  vmovaps xmm3, [rsp+0x20]
000078e5533d0b12  vmovaps xmm4, [rsp+0x30]
000078e5533d0b18  vmovaps xmm5, [rsp+0x40]
000078e5533d0b1e  vmovaps xmm6, [rsp+0x50]
000078e5533d0b24  vmovaps xmm7, [rsp+0x60]
000078e5533d0b2a  vmovaps xmm8, [rsp+0x70]
000078e5533d0b30  vmovaps xmm9, [rsp+0x80]
000078e5533d0b39  vmovaps xmm10, [rsp+0x90]
000078e5533d0b42  vmovaps xmm11, [rsp+0xA0]
000078e5533d0b4b  vmovaps xmm12, [rsp+0xB0]
000078e5533d0b54  vmovaps xmm13, [rsp+0xC0]
000078e5533d0b5d  vmovaps xmm14, [rsp+0xD0]
000078e5533d0b66  vmovaps xmm15, [rsp+0xE0]
000078e5533d0b6f  add rsp, 0xF0
000078e5533d0b76  pop r11
000078e5533d0b78  pop r10
000078e5533d0b7a  pop r9
000078e5533d0b7c  pop r8
000078e5533d0b7e  pop rsi
000078e5533d0b7f  pop rdi
000078e5533d0b80  pop rdx
000078e5533d0b81  pop rcx
000078e5533d0b82  pop rax
000078e5533d0b83  add rsp, 0x08
000078e5533d0b87  jmp 0x000078E5533CF631
000078e5533d0b8c  sub rsp, 0x08
000078e5533d0b90  push rax
000078e5533d0b91  push rcx
000078e5533d0b92  push rdx
000078e5533d0b93  push rdi
000078e5533d0b94  push rsi
000078e5533d0b95  push r8
000078e5533d0b97  push r9
000078e5533d0b99  push r10
000078e5533d0b9b  push r11
000078e5533d0b9d  sub rsp, 0xF0
000078e5533d0ba4  vmovaps [rsp], xmm0
000078e5533d0ba9  vmovaps [rsp+0x10], xmm1
000078e5533d0baf  vmovaps [rsp+0x20], xmm2
000078e5533d0bb5  vmovaps [rsp+0x30], xmm3
000078e5533d0bbb  vmovaps [rsp+0x40], xmm4
000078e5533d0bc1  vmovaps [rsp+0x50], xmm5
000078e5533d0bc7  vmovaps [rsp+0x60], xmm6
000078e5533d0bcd  vmovaps [rsp+0x70], xmm7
000078e5533d0bd3  vmovaps [rsp+0x80], xmm8
000078e5533d0bdc  vmovaps [rsp+0x90], xmm9
000078e5533d0be5  vmovaps [rsp+0xA0], xmm10
000078e5533d0bee  vmovaps [rsp+0xB0], xmm11
000078e5533d0bf7  vmovaps [rsp+0xC0], xmm12
000078e5533d0c00  vmovaps [rsp+0xD0], xmm14
000078e5533d0c09  vmovaps [rsp+0xE0], xmm15
000078e5533d0c12  sub rsp, 0x30
000078e5533d0c16  movaps [rsp], xmm13
000078e5533d0c1b  movaps [rsp+0x10], xmm14
000078e5533d0c21  movaps [rsp+0x20], xmm2
000078e5533d0c26  lea rdi, [rsp]
000078e5533d0c2a  mov esi, 0x00
000078e5533d0c2f  mov rax, 0x5F83D5E17530
000078e5533d0c39  call rax
000078e5533d0c3b  movaps xmm13, [rsp]
000078e5533d0c40  add rsp, 0x30
000078e5533d0c44  vmovaps xmm0, [rsp]
000078e5533d0c49  vmovaps xmm1, [rsp+0x10]
000078e5533d0c4f  vmovaps xmm2, [rsp+0x20]
000078e5533d0c55  vmovaps xmm3, [rsp+0x30]
000078e5533d0c5b  vmovaps xmm4, [rsp+0x40]
000078e5533d0c61  vmovaps xmm5, [rsp+0x50]
000078e5533d0c67  vmovaps xmm6, [rsp+0x60]
000078e5533d0c6d  vmovaps xmm7, [rsp+0x70]
000078e5533d0c73  vmovaps xmm8, [rsp+0x80]
000078e5533d0c7c  vmovaps xmm9, [rsp+0x90]
000078e5533d0c85  vmovaps xmm10, [rsp+0xA0]
000078e5533d0c8e  vmovaps xmm11, [rsp+0xB0]
000078e5533d0c97  vmovaps xmm12, [rsp+0xC0]
000078e5533d0ca0  vmovaps xmm14, [rsp+0xD0]
000078e5533d0ca9  vmovaps xmm15, [rsp+0xE0]
000078e5533d0cb2  add rsp, 0xF0
000078e5533d0cb9  pop r11
000078e5533d0cbb  pop r10
000078e5533d0cbd  pop r9
000078e5533d0cbf  pop r8
000078e5533d0cc1  pop rsi
000078e5533d0cc2  pop rdi
000078e5533d0cc3  pop rdx
000078e5533d0cc4  pop rcx
000078e5533d0cc5  pop rax
000078e5533d0cc6  add rsp, 0x08
000078e5533d0cca  jmp 0x000078E5533CF64C
000078e5533d0ccf  sub rsp, 0x08
000078e5533d0cd3  push rax
000078e5533d0cd4  push rcx
000078e5533d0cd5  push rdx
000078e5533d0cd6  push rdi
000078e5533d0cd7  push rsi
000078e5533d0cd8  push r8
000078e5533d0cda  push r9
000078e5533d0cdc  push r10
000078e5533d0cde  push r11
000078e5533d0ce0  sub rsp, 0xF0
000078e5533d0ce7  vmovaps [rsp], xmm0
000078e5533d0cec  vmovaps [rsp+0x10], xmm2
000078e5533d0cf2  vmovaps [rsp+0x20], xmm3
000078e5533d0cf8  vmovaps [rsp+0x30], xmm4
000078e5533d0cfe  vmovaps [rsp+0x40], xmm5
000078e5533d0d04  vmovaps [rsp+0x50], xmm6
000078e5533d0d0a  vmovaps [rsp+0x60], xmm7
000078e5533d0d10  vmovaps [rsp+0x70], xmm8
000078e5533d0d16  vmovaps [rsp+0x80], xmm9
000078e5533d0d1f  vmovaps [rsp+0x90], xmm10
000078e5533d0d28  vmovaps [rsp+0xA0], xmm11
000078e5533d0d31  vmovaps [rsp+0xB0], xmm12
000078e5533d0d3a  vmovaps [rsp+0xC0], xmm13
000078e5533d0d43  vmovaps [rsp+0xD0], xmm14
000078e5533d0d4c  vmovaps [rsp+0xE0], xmm15
000078e5533d0d55  sub rsp, 0x30
000078e5533d0d59  movaps [rsp], xmm1
000078e5533d0d5d  movaps [rsp+0x10], xmm10
000078e5533d0d63  movaps [rsp+0x20], xmm2
000078e5533d0d68  lea rdi, [rsp]
000078e5533d0d6c  mov esi, 0x00
000078e5533d0d71  mov rax, 0x5F83D5E17530
000078e5533d0d7b  call rax
000078e5533d0d7d  movaps xmm1, [rsp]
000078e5533d0d81  add rsp, 0x30
000078e5533d0d85  vmovaps xmm0, [rsp]
000078e5533d0d8a  vmovaps xmm2, [rsp+0x10]
000078e5533d0d90  vmovaps xmm3, [rsp+0x20]
000078e5533d0d96  vmovaps xmm4, [rsp+0x30]
000078e5533d0d9c  vmovaps xmm5, [rsp+0x40]
000078e5533d0da2  vmovaps xmm6, [rsp+0x50]
000078e5533d0da8  vmovaps xmm7, [rsp+0x60]
000078e5533d0dae  vmovaps xmm8, [rsp+0x70]
000078e5533d0db4  vmovaps xmm9, [rsp+0x80]
000078e5533d0dbd  vmovaps xmm10, [rsp+0x90]
000078e5533d0dc6  vmovaps xmm11, [rsp+0xA0]
000078e5533d0dcf  vmovaps xmm12, [rsp+0xB0]
000078e5533d0dd8  vmovaps xmm13, [rsp+0xC0]
000078e5533d0de1  vmovaps xmm14, [rsp+0xD0]
000078e5533d0dea  vmovaps xmm15, [rsp+0xE0]
000078e5533d0df3  add rsp, 0xF0
000078e5533d0dfa  pop r11
000078e5533d0dfc  pop r10
000078e5533d0dfe  pop r9
000078e5533d0e00  pop r8
000078e5533d0e02  pop rsi
000078e5533d0e03  pop rdi
000078e5533d0e04  pop rdx
000078e5533d0e05  pop rcx
000078e5533d0e06  pop rax
000078e5533d0e07  add rsp, 0x08
000078e5533d0e0b  jmp 0x000078E5533CF6B4
000078e5533d0e10  sub rsp, 0x08
000078e5533d0e14  push rax
000078e5533d0e15  push rcx
000078e5533d0e16  push rdx
000078e5533d0e17  push rdi
000078e5533d0e18  push rsi
000078e5533d0e19  push r8
000078e5533d0e1b  push r9
000078e5533d0e1d  push r10
000078e5533d0e1f  push r11
000078e5533d0e21  sub rsp, 0xF0
000078e5533d0e28  vmovaps [rsp], xmm0
000078e5533d0e2d  vmovaps [rsp+0x10], xmm1
000078e5533d0e33  vmovaps [rsp+0x20], xmm2
000078e5533d0e39  vmovaps [rsp+0x30], xmm3
000078e5533d0e3f  vmovaps [rsp+0x40], xmm4
000078e5533d0e45  vmovaps [rsp+0x50], xmm5
000078e5533d0e4b  vmovaps [rsp+0x60], xmm6
000078e5533d0e51  vmovaps [rsp+0x70], xmm7
000078e5533d0e57  vmovaps [rsp+0x80], xmm8
000078e5533d0e60  vmovaps [rsp+0x90], xmm9
000078e5533d0e69  vmovaps [rsp+0xA0], xmm10
000078e5533d0e72  vmovaps [rsp+0xB0], xmm11
000078e5533d0e7b  vmovaps [rsp+0xC0], xmm12
000078e5533d0e84  vmovaps [rsp+0xD0], xmm13
000078e5533d0e8d  vmovaps [rsp+0xE0], xmm14
000078e5533d0e96  sub rsp, 0x30
000078e5533d0e9a  movaps [rsp], xmm15
000078e5533d0e9f  movaps [rsp+0x10], xmm10
000078e5533d0ea5  movaps [rsp+0x20], xmm2
000078e5533d0eaa  lea rdi, [rsp]
000078e5533d0eae  mov esi, 0x00
000078e5533d0eb3  mov rax, 0x5F83D5E17530
000078e5533d0ebd  call rax
000078e5533d0ebf  movaps xmm15, [rsp]
000078e5533d0ec4  add rsp, 0x30
000078e5533d0ec8  vmovaps xmm0, [rsp]
000078e5533d0ecd  vmovaps xmm1, [rsp+0x10]
000078e5533d0ed3  vmovaps xmm2, [rsp+0x20]
000078e5533d0ed9  vmovaps xmm3, [rsp+0x30]
000078e5533d0edf  vmovaps xmm4, [rsp+0x40]
000078e5533d0ee5  vmovaps xmm5, [rsp+0x50]
000078e5533d0eeb  vmovaps xmm6, [rsp+0x60]
000078e5533d0ef1  vmovaps xmm7, [rsp+0x70]
000078e5533d0ef7  vmovaps xmm8, [rsp+0x80]
000078e5533d0f00  vmovaps xmm9, [rsp+0x90]
000078e5533d0f09  vmovaps xmm10, [rsp+0xA0]
000078e5533d0f12  vmovaps xmm11, [rsp+0xB0]
000078e5533d0f1b  vmovaps xmm12, [rsp+0xC0]
000078e5533d0f24  vmovaps xmm13, [rsp+0xD0]
000078e5533d0f2d  vmovaps xmm14, [rsp+0xE0]
000078e5533d0f36  add rsp, 0xF0
000078e5533d0f3d  pop r11
000078e5533d0f3f  pop r10
000078e5533d0f41  pop r9
000078e5533d0f43  pop r8
000078e5533d0f45  pop rsi
000078e5533d0f46  pop rdi
000078e5533d0f47  pop rdx
000078e5533d0f48  pop rcx
000078e5533d0f49  pop rax
000078e5533d0f4a  add rsp, 0x08
000078e5533d0f4e  jmp 0x000078E5533CF706
000078e5533d0f53  sub rsp, 0x08
000078e5533d0f57  push rax
000078e5533d0f58  push rcx
000078e5533d0f59  push rdx
000078e5533d0f5a  push rdi
000078e5533d0f5b  push rsi
000078e5533d0f5c  push r8
000078e5533d0f5e  push r9
000078e5533d0f60  push r10
000078e5533d0f62  push r11
000078e5533d0f64  sub rsp, 0xF0
000078e5533d0f6b  vmovaps [rsp], xmm0
000078e5533d0f70  vmovaps [rsp+0x10], xmm2
000078e5533d0f76  vmovaps [rsp+0x20], xmm3
000078e5533d0f7c  vmovaps [rsp+0x30], xmm4
000078e5533d0f82  vmovaps [rsp+0x40], xmm5
000078e5533d0f88  vmovaps [rsp+0x50], xmm6
000078e5533d0f8e  vmovaps [rsp+0x60], xmm7
000078e5533d0f94  vmovaps [rsp+0x70], xmm8
000078e5533d0f9a  vmovaps [rsp+0x80], xmm9
000078e5533d0fa3  vmovaps [rsp+0x90], xmm10
000078e5533d0fac  vmovaps [rsp+0xA0], xmm11
000078e5533d0fb5  vmovaps [rsp+0xB0], xmm12
000078e5533d0fbe  vmovaps [rsp+0xC0], xmm13
000078e5533d0fc7  vmovaps [rsp+0xD0], xmm14
000078e5533d0fd0  vmovaps [rsp+0xE0], xmm15
000078e5533d0fd9  sub rsp, 0x30
000078e5533d0fdd  movaps [rsp], xmm1
000078e5533d0fe1  movaps [rsp+0x10], xmm10
000078e5533d0fe7  movaps [rsp+0x20], xmm12
000078e5533d0fed  lea rdi, [rsp]
000078e5533d0ff1  mov esi, 0x00
000078e5533d0ff6  mov rax, 0x5F83D5E17530
000078e5533d1000  call rax
000078e5533d1002  movaps xmm1, [rsp]
000078e5533d1006  add rsp, 0x30
000078e5533d100a  vmovaps xmm0, [rsp]
000078e5533d100f  vmovaps xmm2, [rsp+0x10]
000078e5533d1015  vmovaps xmm3, [rsp+0x20]
000078e5533d101b  vmovaps xmm4, [rsp+0x30]
000078e5533d1021  vmovaps xmm5, [rsp+0x40]
000078e5533d1027  vmovaps xmm6, [rsp+0x50]
000078e5533d102d  vmovaps xmm7, [rsp+0x60]
000078e5533d1033  vmovaps xmm8, [rsp+0x70]
000078e5533d1039  vmovaps xmm9, [rsp+0x80]
000078e5533d1042  vmovaps xmm10, [rsp+0x90]
000078e5533d104b  vmovaps xmm11, [rsp+0xA0]
000078e5533d1054  vmovaps xmm12, [rsp+0xB0]
000078e5533d105d  vmovaps xmm13, [rsp+0xC0]
000078e5533d1066  vmovaps xmm14, [rsp+0xD0]
000078e5533d106f  vmovaps xmm15, [rsp+0xE0]
000078e5533d1078  add rsp, 0xF0
000078e5533d107f  pop r11
000078e5533d1081  pop r10
000078e5533d1083  pop r9
000078e5533d1085  pop r8
000078e5533d1087  pop rsi
000078e5533d1088  pop rdi
000078e5533d1089  pop rdx
000078e5533d108a  pop rcx
000078e5533d108b  pop rax
000078e5533d108c  add rsp, 0x08
000078e5533d1090  jmp 0x000078E5533CF732
000078e5533d1095  sub rsp, 0x08
000078e5533d1099  push rax
000078e5533d109a  push rcx
000078e5533d109b  push rdx
000078e5533d109c  push rdi
000078e5533d109d  push rsi
000078e5533d109e  push r8
000078e5533d10a0  push r9
000078e5533d10a2  push r10
000078e5533d10a4  push r11
000078e5533d10a6  sub rsp, 0xF0
000078e5533d10ad  vmovaps [rsp], xmm0
000078e5533d10b2  vmovaps [rsp+0x10], xmm1
000078e5533d10b8  vmovaps [rsp+0x20], xmm2
000078e5533d10be  vmovaps [rsp+0x30], xmm3
000078e5533d10c4  vmovaps [rsp+0x40], xmm4
000078e5533d10ca  vmovaps [rsp+0x50], xmm5
000078e5533d10d0  vmovaps [rsp+0x60], xmm6
000078e5533d10d6  vmovaps [rsp+0x70], xmm7
000078e5533d10dc  vmovaps [rsp+0x80], xmm8
000078e5533d10e5  vmovaps [rsp+0x90], xmm9
000078e5533d10ee  vmovaps [rsp+0xA0], xmm10
000078e5533d10f7  vmovaps [rsp+0xB0], xmm11
000078e5533d1100  vmovaps [rsp+0xC0], xmm12
000078e5533d1109  vmovaps [rsp+0xD0], xmm13
000078e5533d1112  vmovaps [rsp+0xE0], xmm14
000078e5533d111b  sub rsp, 0x30
000078e5533d111f  movaps [rsp], xmm15
000078e5533d1124  movaps [rsp+0x10], xmm10
000078e5533d112a  movaps [rsp+0x20], xmm12
000078e5533d1130  lea rdi, [rsp]
000078e5533d1134  mov esi, 0x00
000078e5533d1139  mov rax, 0x5F83D5E17530
000078e5533d1143  call rax
000078e5533d1145  movaps xmm15, [rsp]
000078e5533d114a  add rsp, 0x30
000078e5533d114e  vmovaps xmm0, [rsp]
000078e5533d1153  vmovaps xmm1, [rsp+0x10]
000078e5533d1159  vmovaps xmm2, [rsp+0x20]
000078e5533d115f  vmovaps xmm3, [rsp+0x30]
000078e5533d1165  vmovaps xmm4, [rsp+0x40]
000078e5533d116b  vmovaps xmm5, [rsp+0x50]
000078e5533d1171  vmovaps xmm6, [rsp+0x60]
000078e5533d1177  vmovaps xmm7, [rsp+0x70]
000078e5533d117d  vmovaps xmm8, [rsp+0x80]
000078e5533d1186  vmovaps xmm9, [rsp+0x90]
000078e5533d118f  vmovaps xmm10, [rsp+0xA0]
000078e5533d1198  vmovaps xmm11, [rsp+0xB0]
000078e5533d11a1  vmovaps xmm12, [rsp+0xC0]
000078e5533d11aa  vmovaps xmm13, [rsp+0xD0]
000078e5533d11b3  vmovaps xmm14, [rsp+0xE0]
000078e5533d11bc  add rsp, 0xF0
000078e5533d11c3  pop r11
000078e5533d11c5  pop r10
000078e5533d11c7  pop r9
000078e5533d11c9  pop r8
000078e5533d11cb  pop rsi
000078e5533d11cc  pop rdi
000078e5533d11cd  pop rdx
000078e5533d11ce  pop rcx
000078e5533d11cf  pop rax
000078e5533d11d0  add rsp, 0x08
000078e5533d11d4  jmp 0x000078E5533CF75E
000078e5533d11d9  call 0x000078E5531FF430
000078e5533d11de  jmp 0x000078E5533CF7EE
000078e5533d11e3  call 0x000078E5531FF430
000078e5533d11e8  jmp 0x000078E5533CF801
000078e5533d11ed  sub rsp, 0x08
000078e5533d11f1  push rax
000078e5533d11f2  push rcx
000078e5533d11f3  push rdx
000078e5533d11f4  push rdi
000078e5533d11f5  push rsi
000078e5533d11f6  push r8
000078e5533d11f8  push r9
000078e5533d11fa  push r10
000078e5533d11fc  push r11
000078e5533d11fe  sub rsp, 0xF0
000078e5533d1205  vmovaps [rsp], xmm0
000078e5533d120a  vmovaps [rsp+0x10], xmm2
000078e5533d1210  vmovaps [rsp+0x20], xmm3
000078e5533d1216  vmovaps [rsp+0x30], xmm4
000078e5533d121c  vmovaps [rsp+0x40], xmm5
000078e5533d1222  vmovaps [rsp+0x50], xmm6
000078e5533d1228  vmovaps [rsp+0x60], xmm7
000078e5533d122e  vmovaps [rsp+0x70], xmm8
000078e5533d1234  vmovaps [rsp+0x80], xmm9
000078e5533d123d  vmovaps [rsp+0x90], xmm10
000078e5533d1246  vmovaps [rsp+0xA0], xmm11
000078e5533d124f  vmovaps [rsp+0xB0], xmm12
000078e5533d1258  vmovaps [rsp+0xC0], xmm13
000078e5533d1261  vmovaps [rsp+0xD0], xmm14
000078e5533d126a  vmovaps [rsp+0xE0], xmm15
000078e5533d1273  sub rsp, 0x30
000078e5533d1277  movaps [rsp], xmm1
000078e5533d127b  movaps [rsp+0x10], xmm13
000078e5533d1281  movaps [rsp+0x20], xmm2
000078e5533d1286  lea rdi, [rsp]
000078e5533d128a  mov esi, 0x00
000078e5533d128f  mov rax, 0x5F83D5E17530
000078e5533d1299  call rax
000078e5533d129b  movaps xmm1, [rsp]
000078e5533d129f  add rsp, 0x30
000078e5533d12a3  vmovaps xmm0, [rsp]
000078e5533d12a8  vmovaps xmm2, [rsp+0x10]
000078e5533d12ae  vmovaps xmm3, [rsp+0x20]
000078e5533d12b4  vmovaps xmm4, [rsp+0x30]
000078e5533d12ba  vmovaps xmm5, [rsp+0x40]
000078e5533d12c0  vmovaps xmm6, [rsp+0x50]
000078e5533d12c6  vmovaps xmm7, [rsp+0x60]
000078e5533d12cc  vmovaps xmm8, [rsp+0x70]
000078e5533d12d2  vmovaps xmm9, [rsp+0x80]
000078e5533d12db  vmovaps xmm10, [rsp+0x90]
000078e5533d12e4  vmovaps xmm11, [rsp+0xA0]
000078e5533d12ed  vmovaps xmm12, [rsp+0xB0]
000078e5533d12f6  vmovaps xmm13, [rsp+0xC0]
000078e5533d12ff  vmovaps xmm14, [rsp+0xD0]
000078e5533d1308  vmovaps xmm15, [rsp+0xE0]
000078e5533d1311  add rsp, 0xF0
000078e5533d1318  pop r11
000078e5533d131a  pop r10
000078e5533d131c  pop r9
000078e5533d131e  pop r8
000078e5533d1320  pop rsi
000078e5533d1321  pop rdi
000078e5533d1322  pop rdx
000078e5533d1323  pop rcx
000078e5533d1324  pop rax
000078e5533d1325  add rsp, 0x08
000078e5533d1329  jmp 0x000078E5533CF82C
000078e5533d132e  call 0x000078E55320E760
000078e5533d1333  jmp 0x000078E5533CF839
000078e5533d1338  sub rsp, 0x08
000078e5533d133c  push rax
000078e5533d133d  push rcx
000078e5533d133e  push rdx
000078e5533d133f  push rdi
000078e5533d1340  push rsi
000078e5533d1341  push r8
000078e5533d1343  push r9
000078e5533d1345  push r10
000078e5533d1347  push r11
000078e5533d1349  sub rsp, 0xF0
000078e5533d1350  vmovaps [rsp], xmm0
000078e5533d1355  vmovaps [rsp+0x10], xmm1
000078e5533d135b  vmovaps [rsp+0x20], xmm2
000078e5533d1361  vmovaps [rsp+0x30], xmm3
000078e5533d1367  vmovaps [rsp+0x40], xmm4
000078e5533d136d  vmovaps [rsp+0x50], xmm5
000078e5533d1373  vmovaps [rsp+0x60], xmm6
000078e5533d1379  vmovaps [rsp+0x70], xmm7
000078e5533d137f  vmovaps [rsp+0x80], xmm8
000078e5533d1388  vmovaps [rsp+0x90], xmm9
000078e5533d1391  vmovaps [rsp+0xA0], xmm10
000078e5533d139a  vmovaps [rsp+0xB0], xmm11
000078e5533d13a3  vmovaps [rsp+0xC0], xmm12
000078e5533d13ac  vmovaps [rsp+0xD0], xmm14
000078e5533d13b5  vmovaps [rsp+0xE0], xmm15
000078e5533d13be  sub rsp, 0x30
000078e5533d13c2  movaps [rsp], xmm13
000078e5533d13c7  movaps [rsp+0x10], xmm2
000078e5533d13cc  movaps [rsp+0x20], xmm1
000078e5533d13d1  lea rdi, [rsp]
000078e5533d13d5  mov esi, 0x00
000078e5533d13da  mov rax, 0x5F83D5E17530
000078e5533d13e4  call rax
000078e5533d13e6  movaps xmm13, [rsp]
000078e5533d13eb  add rsp, 0x30
000078e5533d13ef  vmovaps xmm0, [rsp]
000078e5533d13f4  vmovaps xmm1, [rsp+0x10]
000078e5533d13fa  vmovaps xmm2, [rsp+0x20]
000078e5533d1400  vmovaps xmm3, [rsp+0x30]
000078e5533d1406  vmovaps xmm4, [rsp+0x40]
000078e5533d140c  vmovaps xmm5, [rsp+0x50]
000078e5533d1412  vmovaps xmm6, [rsp+0x60]
000078e5533d1418  vmovaps xmm7, [rsp+0x70]
000078e5533d141e  vmovaps xmm8, [rsp+0x80]
000078e5533d1427  vmovaps xmm9, [rsp+0x90]
000078e5533d1430  vmovaps xmm10, [rsp+0xA0]
000078e5533d1439  vmovaps xmm11, [rsp+0xB0]
000078e5533d1442  vmovaps xmm12, [rsp+0xC0]
000078e5533d144b  vmovaps xmm14, [rsp+0xD0]
000078e5533d1454  vmovaps xmm15, [rsp+0xE0]
000078e5533d145d  add rsp, 0xF0
000078e5533d1464  pop r11
000078e5533d1466  pop r10
000078e5533d1468  pop r9
000078e5533d146a  pop r8
000078e5533d146c  pop rsi
000078e5533d146d  pop rdi
000078e5533d146e  pop rdx
000078e5533d146f  pop rcx
000078e5533d1470  pop rax
000078e5533d1471  add rsp, 0x08
000078e5533d1475  jmp 0x000078E5533CF878
000078e5533d147a  sub rsp, 0x08
000078e5533d147e  push rax
000078e5533d147f  push rcx
000078e5533d1480  push rdx
000078e5533d1481  push rdi
000078e5533d1482  push rsi
000078e5533d1483  push r8
000078e5533d1485  push r9
000078e5533d1487  push r10
000078e5533d1489  push r11
000078e5533d148b  sub rsp, 0xF0
000078e5533d1492  vmovaps [rsp], xmm0
000078e5533d1497  vmovaps [rsp+0x10], xmm2
000078e5533d149d  vmovaps [rsp+0x20], xmm3
000078e5533d14a3  vmovaps [rsp+0x30], xmm4
000078e5533d14a9  vmovaps [rsp+0x40], xmm5
000078e5533d14af  vmovaps [rsp+0x50], xmm6
000078e5533d14b5  vmovaps [rsp+0x60], xmm7
000078e5533d14bb  vmovaps [rsp+0x70], xmm8
000078e5533d14c1  vmovaps [rsp+0x80], xmm9
000078e5533d14ca  vmovaps [rsp+0x90], xmm10
000078e5533d14d3  vmovaps [rsp+0xA0], xmm11
000078e5533d14dc  vmovaps [rsp+0xB0], xmm12
000078e5533d14e5  vmovaps [rsp+0xC0], xmm13
000078e5533d14ee  vmovaps [rsp+0xD0], xmm14
000078e5533d14f7  vmovaps [rsp+0xE0], xmm15
000078e5533d1500  sub rsp, 0x30
000078e5533d1504  movaps [rsp], xmm1
000078e5533d1508  movaps [rsp+0x10], xmm15
000078e5533d150e  movaps [rsp+0x20], xmm2
000078e5533d1513  lea rdi, [rsp]
000078e5533d1517  mov esi, 0x00
000078e5533d151c  mov rax, 0x5F83D5E17530
000078e5533d1526  call rax
000078e5533d1528  movaps xmm1, [rsp]
000078e5533d152c  add rsp, 0x30
000078e5533d1530  vmovaps xmm0, [rsp]
000078e5533d1535  vmovaps xmm2, [rsp+0x10]
000078e5533d153b  vmovaps xmm3, [rsp+0x20]
000078e5533d1541  vmovaps xmm4, [rsp+0x30]
000078e5533d1547  vmovaps xmm5, [rsp+0x40]
000078e5533d154d  vmovaps xmm6, [rsp+0x50]
000078e5533d1553  vmovaps xmm7, [rsp+0x60]
000078e5533d1559  vmovaps xmm8, [rsp+0x70]
000078e5533d155f  vmovaps xmm9, [rsp+0x80]
000078e5533d1568  vmovaps xmm10, [rsp+0x90]
000078e5533d1571  vmovaps xmm11, [rsp+0xA0]
000078e5533d157a  vmovaps xmm12, [rsp+0xB0]
000078e5533d1583  vmovaps xmm13, [rsp+0xC0]
000078e5533d158c  vmovaps xmm14, [rsp+0xD0]
000078e5533d1595  vmovaps xmm15, [rsp+0xE0]
000078e5533d159e  add rsp, 0xF0
000078e5533d15a5  pop r11
000078e5533d15a7  pop r10
000078e5533d15a9  pop r9
000078e5533d15ab  pop r8
000078e5533d15ad  pop rsi
000078e5533d15ae  pop rdi
000078e5533d15af  pop rdx
000078e5533d15b0  pop rcx
000078e5533d15b1  pop rax
000078e5533d15b2  add rsp, 0x08
000078e5533d15b6  jmp 0x000078E5533CF8AC
000078e5533d15bb  sub rsp, 0x08
000078e5533d15bf  push rax
000078e5533d15c0  push rcx
000078e5533d15c1  push rdx
000078e5533d15c2  push rdi
000078e5533d15c3  push rsi
000078e5533d15c4  push r8
000078e5533d15c6  push r9
000078e5533d15c8  push r10
000078e5533d15ca  push r11
000078e5533d15cc  sub rsp, 0xF0
000078e5533d15d3  vmovaps [rsp], xmm0
000078e5533d15d8  vmovaps [rsp+0x10], xmm1
000078e5533d15de  vmovaps [rsp+0x20], xmm2
000078e5533d15e4  vmovaps [rsp+0x30], xmm3
000078e5533d15ea  vmovaps [rsp+0x40], xmm4
000078e5533d15f0  vmovaps [rsp+0x50], xmm5
000078e5533d15f6  vmovaps [rsp+0x60], xmm6
000078e5533d15fc  vmovaps [rsp+0x70], xmm7
000078e5533d1602  vmovaps [rsp+0x80], xmm8
000078e5533d160b  vmovaps [rsp+0x90], xmm9
000078e5533d1614  vmovaps [rsp+0xA0], xmm10
000078e5533d161d  vmovaps [rsp+0xB0], xmm11
000078e5533d1626  vmovaps [rsp+0xC0], xmm12
000078e5533d162f  vmovaps [rsp+0xD0], xmm13
000078e5533d1638  vmovaps [rsp+0xE0], xmm15
000078e5533d1641  sub rsp, 0x30
000078e5533d1645  movaps [rsp], xmm14
000078e5533d164a  movaps [rsp+0x10], xmm2
000078e5533d164f  movaps [rsp+0x20], xmm15
000078e5533d1655  lea rdi, [rsp]
000078e5533d1659  mov esi, 0x00
000078e5533d165e  mov rax, 0x5F83D5E17530
000078e5533d1668  call rax
000078e5533d166a  movaps xmm14, [rsp]
000078e5533d166f  add rsp, 0x30
000078e5533d1673  vmovaps xmm0, [rsp]
000078e5533d1678  vmovaps xmm1, [rsp+0x10]
000078e5533d167e  vmovaps xmm2, [rsp+0x20]
000078e5533d1684  vmovaps xmm3, [rsp+0x30]
000078e5533d168a  vmovaps xmm4, [rsp+0x40]
000078e5533d1690  vmovaps xmm5, [rsp+0x50]
000078e5533d1696  vmovaps xmm6, [rsp+0x60]
000078e5533d169c  vmovaps xmm7, [rsp+0x70]
000078e5533d16a2  vmovaps xmm8, [rsp+0x80]
000078e5533d16ab  vmovaps xmm9, [rsp+0x90]
000078e5533d16b4  vmovaps xmm10, [rsp+0xA0]
000078e5533d16bd  vmovaps xmm11, [rsp+0xB0]
000078e5533d16c6  vmovaps xmm12, [rsp+0xC0]
000078e5533d16cf  vmovaps xmm13, [rsp+0xD0]
000078e5533d16d8  vmovaps xmm15, [rsp+0xE0]
000078e5533d16e1  add rsp, 0xF0
000078e5533d16e8  pop r11
000078e5533d16ea  pop r10
000078e5533d16ec  pop r9
000078e5533d16ee  pop r8
000078e5533d16f0  pop rsi
000078e5533d16f1  pop rdi
000078e5533d16f2  pop rdx
000078e5533d16f3  pop rcx
000078e5533d16f4  pop rax
000078e5533d16f5  add rsp, 0x08
000078e5533d16f9  jmp 0x000078E5533CF8E7
000078e5533d16fe  sub rsp, 0x08
000078e5533d1702  push rax
000078e5533d1703  push rcx
000078e5533d1704  push rdx
000078e5533d1705  push rdi
000078e5533d1706  push rsi
000078e5533d1707  push r8
000078e5533d1709  push r9
000078e5533d170b  push r10
000078e5533d170d  push r11
000078e5533d170f  sub rsp, 0xF0
000078e5533d1716  vmovaps [rsp], xmm0
000078e5533d171b  vmovaps [rsp+0x10], xmm1
000078e5533d1721  vmovaps [rsp+0x20], xmm2
000078e5533d1727  vmovaps [rsp+0x30], xmm3
000078e5533d172d  vmovaps [rsp+0x40], xmm4
000078e5533d1733  vmovaps [rsp+0x50], xmm5
000078e5533d1739  vmovaps [rsp+0x60], xmm6
000078e5533d173f  vmovaps [rsp+0x70], xmm7
000078e5533d1745  vmovaps [rsp+0x80], xmm8
000078e5533d174e  vmovaps [rsp+0x90], xmm9
000078e5533d1757  vmovaps [rsp+0xA0], xmm10
000078e5533d1760  vmovaps [rsp+0xB0], xmm11
000078e5533d1769  vmovaps [rsp+0xC0], xmm12
000078e5533d1772  vmovaps [rsp+0xD0], xmm13
000078e5533d177b  vmovaps [rsp+0xE0], xmm14
000078e5533d1784  sub rsp, 0x30
000078e5533d1788  movaps [rsp], xmm15
000078e5533d178d  movaps [rsp+0x10], xmm2
000078e5533d1792  movaps [rsp+0x20], xmm1
000078e5533d1797  lea rdi, [rsp]
000078e5533d179b  mov esi, 0x00
000078e5533d17a0  mov rax, 0x5F83D5E17530
000078e5533d17aa  call rax
000078e5533d17ac  movaps xmm15, [rsp]
000078e5533d17b1  add rsp, 0x30
000078e5533d17b5  vmovaps xmm0, [rsp]
000078e5533d17ba  vmovaps xmm1, [rsp+0x10]
000078e5533d17c0  vmovaps xmm2, [rsp+0x20]
000078e5533d17c6  vmovaps xmm3, [rsp+0x30]
000078e5533d17cc  vmovaps xmm4, [rsp+0x40]
000078e5533d17d2  vmovaps xmm5, [rsp+0x50]
000078e5533d17d8  vmovaps xmm6, [rsp+0x60]
000078e5533d17de  vmovaps xmm7, [rsp+0x70]
000078e5533d17e4  vmovaps xmm8, [rsp+0x80]
000078e5533d17ed  vmovaps xmm9, [rsp+0x90]
000078e5533d17f6  vmovaps xmm10, [rsp+0xA0]
000078e5533d17ff  vmovaps xmm11, [rsp+0xB0]
000078e5533d1808  vmovaps xmm12, [rsp+0xC0]
000078e5533d1811  vmovaps xmm13, [rsp+0xD0]
000078e5533d181a  vmovaps xmm14, [rsp+0xE0]
000078e5533d1823  add rsp, 0xF0
000078e5533d182a  pop r11
000078e5533d182c  pop r10
000078e5533d182e  pop r9
000078e5533d1830  pop r8
000078e5533d1832  pop rsi
000078e5533d1833  pop rdi
000078e5533d1834  pop rdx
000078e5533d1835  pop rcx
000078e5533d1836  pop rax
000078e5533d1837  add rsp, 0x08
000078e5533d183b  jmp 0x000078E5533CF923
000078e5533d1840  call 0x000078E5531FF430
000078e5533d1845  jmp 0x000078E5533CF930
000078e5533d184a  sub rsp, 0x08
000078e5533d184e  push rax
000078e5533d184f  push rcx
000078e5533d1850  push rdx
000078e5533d1851  push rdi
000078e5533d1852  push rsi
000078e5533d1853  push r8
000078e5533d1855  push r9
000078e5533d1857  push r10
000078e5533d1859  push r11
000078e5533d185b  sub rsp, 0xF0
000078e5533d1862  vmovaps [rsp], xmm0
000078e5533d1867  vmovaps [rsp+0x10], xmm1
000078e5533d186d  vmovaps [rsp+0x20], xmm3
000078e5533d1873  vmovaps [rsp+0x30], xmm4
000078e5533d1879  vmovaps [rsp+0x40], xmm5
000078e5533d187f  vmovaps [rsp+0x50], xmm6
000078e5533d1885  vmovaps [rsp+0x60], xmm7
000078e5533d188b  vmovaps [rsp+0x70], xmm8
000078e5533d1891  vmovaps [rsp+0x80], xmm9
000078e5533d189a  vmovaps [rsp+0x90], xmm10
000078e5533d18a3  vmovaps [rsp+0xA0], xmm11
000078e5533d18ac  vmovaps [rsp+0xB0], xmm12
000078e5533d18b5  vmovaps [rsp+0xC0], xmm13
000078e5533d18be  vmovaps [rsp+0xD0], xmm14
000078e5533d18c7  vmovaps [rsp+0xE0], xmm15
000078e5533d18d0  sub rsp, 0x30
000078e5533d18d4  movaps [rsp], xmm2
000078e5533d18d8  movaps [rsp+0x10], xmm1
000078e5533d18dd  movaps [rsp+0x20], xmm14
000078e5533d18e3  lea rdi, [rsp]
000078e5533d18e7  mov esi, 0x00
000078e5533d18ec  mov rax, 0x5F83D5E17530
000078e5533d18f6  call rax
000078e5533d18f8  movaps xmm2, [rsp]
000078e5533d18fc  add rsp, 0x30
000078e5533d1900  vmovaps xmm0, [rsp]
000078e5533d1905  vmovaps xmm1, [rsp+0x10]
000078e5533d190b  vmovaps xmm3, [rsp+0x20]
000078e5533d1911  vmovaps xmm4, [rsp+0x30]
000078e5533d1917  vmovaps xmm5, [rsp+0x40]
000078e5533d191d  vmovaps xmm6, [rsp+0x50]
000078e5533d1923  vmovaps xmm7, [rsp+0x60]
000078e5533d1929  vmovaps xmm8, [rsp+0x70]
000078e5533d192f  vmovaps xmm9, [rsp+0x80]
000078e5533d1938  vmovaps xmm10, [rsp+0x90]
000078e5533d1941  vmovaps xmm11, [rsp+0xA0]
000078e5533d194a  vmovaps xmm12, [rsp+0xB0]
000078e5533d1953  vmovaps xmm13, [rsp+0xC0]
000078e5533d195c  vmovaps xmm14, [rsp+0xD0]
000078e5533d1965  vmovaps xmm15, [rsp+0xE0]
000078e5533d196e  add rsp, 0xF0
000078e5533d1975  pop r11
000078e5533d1977  pop r10
000078e5533d1979  pop r9
000078e5533d197b  pop r8
000078e5533d197d  pop rsi
000078e5533d197e  pop rdi
000078e5533d197f  pop rdx
000078e5533d1980  pop rcx
000078e5533d1981  pop rax
000078e5533d1982  add rsp, 0x08
000078e5533d1986  jmp 0x000078E5533CF96D
000078e5533d198b  sub rsp, 0x08
000078e5533d198f  push rax
000078e5533d1990  push rcx
000078e5533d1991  push rdx
000078e5533d1992  push rdi
000078e5533d1993  push rsi
000078e5533d1994  push r8
000078e5533d1996  push r9
000078e5533d1998  push r10
000078e5533d199a  push r11
000078e5533d199c  sub rsp, 0xF0
000078e5533d19a3  vmovaps [rsp], xmm0
000078e5533d19a8  vmovaps [rsp+0x10], xmm1
000078e5533d19ae  vmovaps [rsp+0x20], xmm2
000078e5533d19b4  vmovaps [rsp+0x30], xmm3
000078e5533d19ba  vmovaps [rsp+0x40], xmm4
000078e5533d19c0  vmovaps [rsp+0x50], xmm5
000078e5533d19c6  vmovaps [rsp+0x60], xmm6
000078e5533d19cc  vmovaps [rsp+0x70], xmm7
000078e5533d19d2  vmovaps [rsp+0x80], xmm8
000078e5533d19db  vmovaps [rsp+0x90], xmm9
000078e5533d19e4  vmovaps [rsp+0xA0], xmm10
000078e5533d19ed  vmovaps [rsp+0xB0], xmm11
000078e5533d19f6  vmovaps [rsp+0xC0], xmm12
000078e5533d19ff  vmovaps [rsp+0xD0], xmm13
000078e5533d1a08  vmovaps [rsp+0xE0], xmm14
000078e5533d1a11  sub rsp, 0x30
000078e5533d1a15  movaps [rsp], xmm15
000078e5533d1a1a  movaps [rsp+0x10], xmm14
000078e5533d1a20  movaps [rsp+0x20], xmm1
000078e5533d1a25  lea rdi, [rsp]
000078e5533d1a29  mov esi, 0x00
000078e5533d1a2e  mov rax, 0x5F83D5E17530
000078e5533d1a38  call rax
000078e5533d1a3a  movaps xmm15, [rsp]
000078e5533d1a3f  add rsp, 0x30
000078e5533d1a43  vmovaps xmm0, [rsp]
000078e5533d1a48  vmovaps xmm1, [rsp+0x10]
000078e5533d1a4e  vmovaps xmm2, [rsp+0x20]
000078e5533d1a54  vmovaps xmm3, [rsp+0x30]
000078e5533d1a5a  vmovaps xmm4, [rsp+0x40]
000078e5533d1a60  vmovaps xmm5, [rsp+0x50]
000078e5533d1a66  vmovaps xmm6, [rsp+0x60]
000078e5533d1a6c  vmovaps xmm7, [rsp+0x70]
000078e5533d1a72  vmovaps xmm8, [rsp+0x80]
000078e5533d1a7b  vmovaps xmm9, [rsp+0x90]
000078e5533d1a84  vmovaps xmm10, [rsp+0xA0]
000078e5533d1a8d  vmovaps xmm11, [rsp+0xB0]
000078e5533d1a96  vmovaps xmm12, [rsp+0xC0]
000078e5533d1a9f  vmovaps xmm13, [rsp+0xD0]
000078e5533d1aa8  vmovaps xmm14, [rsp+0xE0]
000078e5533d1ab1  add rsp, 0xF0
000078e5533d1ab8  pop r11
000078e5533d1aba  pop r10
000078e5533d1abc  pop r9
000078e5533d1abe  pop r8
000078e5533d1ac0  pop rsi
000078e5533d1ac1  pop rdi
000078e5533d1ac2  pop rdx
000078e5533d1ac3  pop rcx
000078e5533d1ac4  pop rax
000078e5533d1ac5  add rsp, 0x08
000078e5533d1ac9  jmp 0x000078E5533CF9E7
000078e5533d1ace  call 0x000078E5531FF430
000078e5533d1ad3  jmp 0x000078E5533CF9F4
000078e5533d1ad8  sub rsp, 0x08
000078e5533d1adc  push rax
000078e5533d1add  push rcx
000078e5533d1ade  push rdx
000078e5533d1adf  push rdi
000078e5533d1ae0  push rsi
000078e5533d1ae1  push r8
000078e5533d1ae3  push r9
000078e5533d1ae5  push r10
000078e5533d1ae7  push r11
000078e5533d1ae9  sub rsp, 0xF0
000078e5533d1af0  vmovaps [rsp], xmm0
000078e5533d1af5  vmovaps [rsp+0x10], xmm1
000078e5533d1afb  vmovaps [rsp+0x20], xmm2
000078e5533d1b01  vmovaps [rsp+0x30], xmm3
000078e5533d1b07  vmovaps [rsp+0x40], xmm4
000078e5533d1b0d  vmovaps [rsp+0x50], xmm5
000078e5533d1b13  vmovaps [rsp+0x60], xmm6
000078e5533d1b19  vmovaps [rsp+0x70], xmm7
000078e5533d1b1f  vmovaps [rsp+0x80], xmm8
000078e5533d1b28  vmovaps [rsp+0x90], xmm9
000078e5533d1b31  vmovaps [rsp+0xA0], xmm10
000078e5533d1b3a  vmovaps [rsp+0xB0], xmm11
000078e5533d1b43  vmovaps [rsp+0xC0], xmm12
000078e5533d1b4c  vmovaps [rsp+0xD0], xmm13
000078e5533d1b55  vmovaps [rsp+0xE0], xmm15
000078e5533d1b5e  sub rsp, 0x30
000078e5533d1b62  movaps [rsp], xmm14
000078e5533d1b67  movaps [rsp+0x10], xmm13
000078e5533d1b6d  movaps [rsp+0x20], xmm1
000078e5533d1b72  lea rdi, [rsp]
000078e5533d1b76  mov esi, 0x00
000078e5533d1b7b  mov rax, 0x5F83D5E17530
000078e5533d1b85  call rax
000078e5533d1b87  movaps xmm14, [rsp]
000078e5533d1b8c  add rsp, 0x30
000078e5533d1b90  vmovaps xmm0, [rsp]
000078e5533d1b95  vmovaps xmm1, [rsp+0x10]
000078e5533d1b9b  vmovaps xmm2, [rsp+0x20]
000078e5533d1ba1  vmovaps xmm3, [rsp+0x30]
000078e5533d1ba7  vmovaps xmm4, [rsp+0x40]
000078e5533d1bad  vmovaps xmm5, [rsp+0x50]
000078e5533d1bb3  vmovaps xmm6, [rsp+0x60]
000078e5533d1bb9  vmovaps xmm7, [rsp+0x70]
000078e5533d1bbf  vmovaps xmm8, [rsp+0x80]
000078e5533d1bc8  vmovaps xmm9, [rsp+0x90]
000078e5533d1bd1  vmovaps xmm10, [rsp+0xA0]
000078e5533d1bda  vmovaps xmm11, [rsp+0xB0]
000078e5533d1be3  vmovaps xmm12, [rsp+0xC0]
000078e5533d1bec  vmovaps xmm13, [rsp+0xD0]
000078e5533d1bf5  vmovaps xmm15, [rsp+0xE0]
000078e5533d1bfe  add rsp, 0xF0
000078e5533d1c05  pop r11
000078e5533d1c07  pop r10
000078e5533d1c09  pop r9
000078e5533d1c0b  pop r8
000078e5533d1c0d  pop rsi
000078e5533d1c0e  pop rdi
000078e5533d1c0f  pop rdx
000078e5533d1c10  pop rcx
000078e5533d1c11  pop rax
000078e5533d1c12  add rsp, 0x08
000078e5533d1c16  jmp 0x000078E5533CFAAF
000078e5533d1c1b  sub rsp, 0x08
000078e5533d1c1f  push rax
000078e5533d1c20  push rcx
000078e5533d1c21  push rdx
000078e5533d1c22  push rdi
000078e5533d1c23  push rsi
000078e5533d1c24  push r8
000078e5533d1c26  push r9
000078e5533d1c28  push r10
000078e5533d1c2a  push r11
000078e5533d1c2c  sub rsp, 0xF0
000078e5533d1c33  vmovaps [rsp], xmm0
000078e5533d1c38  vmovaps [rsp+0x10], xmm1
000078e5533d1c3e  vmovaps [rsp+0x20], xmm2
000078e5533d1c44  vmovaps [rsp+0x30], xmm3
000078e5533d1c4a  vmovaps [rsp+0x40], xmm4
000078e5533d1c50  vmovaps [rsp+0x50], xmm5
000078e5533d1c56  vmovaps [rsp+0x60], xmm6
000078e5533d1c5c  vmovaps [rsp+0x70], xmm7
000078e5533d1c62  vmovaps [rsp+0x80], xmm8
000078e5533d1c6b  vmovaps [rsp+0x90], xmm9
000078e5533d1c74  vmovaps [rsp+0xA0], xmm10
000078e5533d1c7d  vmovaps [rsp+0xB0], xmm11
000078e5533d1c86  vmovaps [rsp+0xC0], xmm12
000078e5533d1c8f  vmovaps [rsp+0xD0], xmm13
000078e5533d1c98  vmovaps [rsp+0xE0], xmm14
000078e5533d1ca1  sub rsp, 0x30
000078e5533d1ca5  movaps [rsp], xmm15
000078e5533d1caa  movaps [rsp+0x10], xmm13
000078e5533d1cb0  movaps [rsp+0x20], xmm1
000078e5533d1cb5  lea rdi, [rsp]
000078e5533d1cb9  mov esi, 0x00
000078e5533d1cbe  mov rax, 0x5F83D5E17530
000078e5533d1cc8  call rax
000078e5533d1cca  movaps xmm15, [rsp]
000078e5533d1ccf  add rsp, 0x30
000078e5533d1cd3  vmovaps xmm0, [rsp]
000078e5533d1cd8  vmovaps xmm1, [rsp+0x10]
000078e5533d1cde  vmovaps xmm2, [rsp+0x20]
000078e5533d1ce4  vmovaps xmm3, [rsp+0x30]
000078e5533d1cea  vmovaps xmm4, [rsp+0x40]
000078e5533d1cf0  vmovaps xmm5, [rsp+0x50]
000078e5533d1cf6  vmovaps xmm6, [rsp+0x60]
000078e5533d1cfc  vmovaps xmm7, [rsp+0x70]
000078e5533d1d02  vmovaps xmm8, [rsp+0x80]
000078e5533d1d0b  vmovaps xmm9, [rsp+0x90]
000078e5533d1d14  vmovaps xmm10, [rsp+0xA0]
000078e5533d1d1d  vmovaps xmm11, [rsp+0xB0]
000078e5533d1d26  vmovaps xmm12, [rsp+0xC0]
000078e5533d1d2f  vmovaps xmm13, [rsp+0xD0]
000078e5533d1d38  vmovaps xmm14, [rsp+0xE0]
000078e5533d1d41  add rsp, 0xF0
000078e5533d1d48  pop r11
000078e5533d1d4a  pop r10
000078e5533d1d4c  pop r9
000078e5533d1d4e  pop r8
000078e5533d1d50  pop rsi
000078e5533d1d51  pop rdi
000078e5533d1d52  pop rdx
000078e5533d1d53  pop rcx
000078e5533d1d54  pop rax
000078e5533d1d55  add rsp, 0x08
000078e5533d1d59  jmp 0x000078E5533CFAEB
000078e5533d1d5e  call 0x000078E5531FF430
000078e5533d1d63  jmp 0x000078E5533CFAF8
000078e5533d1d68  sub rsp, 0x08
000078e5533d1d6c  push rax
000078e5533d1d6d  push rcx
000078e5533d1d6e  push rdx
000078e5533d1d6f  push rdi
000078e5533d1d70  push rsi
000078e5533d1d71  push r8
000078e5533d1d73  push r9
000078e5533d1d75  push r10
000078e5533d1d77  push r11
000078e5533d1d79  sub rsp, 0xF0
000078e5533d1d80  vmovaps [rsp], xmm0
000078e5533d1d85  vmovaps [rsp+0x10], xmm1
000078e5533d1d8b  vmovaps [rsp+0x20], xmm2
000078e5533d1d91  vmovaps [rsp+0x30], xmm3
000078e5533d1d97  vmovaps [rsp+0x40], xmm4
000078e5533d1d9d  vmovaps [rsp+0x50], xmm5
000078e5533d1da3  vmovaps [rsp+0x60], xmm6
000078e5533d1da9  vmovaps [rsp+0x70], xmm7
000078e5533d1daf  vmovaps [rsp+0x80], xmm8
000078e5533d1db8  vmovaps [rsp+0x90], xmm9
000078e5533d1dc1  vmovaps [rsp+0xA0], xmm10
000078e5533d1dca  vmovaps [rsp+0xB0], xmm11
000078e5533d1dd3  vmovaps [rsp+0xC0], xmm12
000078e5533d1ddc  vmovaps [rsp+0xD0], xmm13
000078e5533d1de5  vmovaps [rsp+0xE0], xmm15
000078e5533d1dee  sub rsp, 0x30
000078e5533d1df2  movaps [rsp], xmm14
000078e5533d1df7  movaps [rsp+0x10], xmm13
000078e5533d1dfd  movaps [rsp+0x20], xmm2
000078e5533d1e02  lea rdi, [rsp]
000078e5533d1e06  mov esi, 0x00
000078e5533d1e0b  mov rax, 0x5F83D5E17530
000078e5533d1e15  call rax
000078e5533d1e17  movaps xmm14, [rsp]
000078e5533d1e1c  add rsp, 0x30
000078e5533d1e20  vmovaps xmm0, [rsp]
000078e5533d1e25  vmovaps xmm1, [rsp+0x10]
000078e5533d1e2b  vmovaps xmm2, [rsp+0x20]
000078e5533d1e31  vmovaps xmm3, [rsp+0x30]
000078e5533d1e37  vmovaps xmm4, [rsp+0x40]
000078e5533d1e3d  vmovaps xmm5, [rsp+0x50]
000078e5533d1e43  vmovaps xmm6, [rsp+0x60]
000078e5533d1e49  vmovaps xmm7, [rsp+0x70]
000078e5533d1e4f  vmovaps xmm8, [rsp+0x80]
000078e5533d1e58  vmovaps xmm9, [rsp+0x90]
000078e5533d1e61  vmovaps xmm10, [rsp+0xA0]
000078e5533d1e6a  vmovaps xmm11, [rsp+0xB0]
000078e5533d1e73  vmovaps xmm12, [rsp+0xC0]
000078e5533d1e7c  vmovaps xmm13, [rsp+0xD0]
000078e5533d1e85  vmovaps xmm15, [rsp+0xE0]
000078e5533d1e8e  add rsp, 0xF0
000078e5533d1e95  pop r11
000078e5533d1e97  pop r10
000078e5533d1e99  pop r9
000078e5533d1e9b  pop r8
000078e5533d1e9d  pop rsi
000078e5533d1e9e  pop rdi
000078e5533d1e9f  pop rdx
000078e5533d1ea0  pop rcx
000078e5533d1ea1  pop rax
000078e5533d1ea2  add rsp, 0x08
000078e5533d1ea6  jmp 0x000078E5533CFB24
000078e5533d1eab  sub rsp, 0x08
000078e5533d1eaf  push rax
000078e5533d1eb0  push rcx
000078e5533d1eb1  push rdx
000078e5533d1eb2  push rdi
000078e5533d1eb3  push rsi
000078e5533d1eb4  push r8
000078e5533d1eb6  push r9
000078e5533d1eb8  push r10
000078e5533d1eba  push r11
000078e5533d1ebc  sub rsp, 0xF0
000078e5533d1ec3  vmovaps [rsp], xmm0
000078e5533d1ec8  vmovaps [rsp+0x10], xmm2
000078e5533d1ece  vmovaps [rsp+0x20], xmm3
000078e5533d1ed4  vmovaps [rsp+0x30], xmm4
000078e5533d1eda  vmovaps [rsp+0x40], xmm5
000078e5533d1ee0  vmovaps [rsp+0x50], xmm6
000078e5533d1ee6  vmovaps [rsp+0x60], xmm7
000078e5533d1eec  vmovaps [rsp+0x70], xmm8
000078e5533d1ef2  vmovaps [rsp+0x80], xmm9
000078e5533d1efb  vmovaps [rsp+0x90], xmm10
000078e5533d1f04  vmovaps [rsp+0xA0], xmm11
000078e5533d1f0d  vmovaps [rsp+0xB0], xmm12
000078e5533d1f16  vmovaps [rsp+0xC0], xmm13
000078e5533d1f1f  vmovaps [rsp+0xD0], xmm14
000078e5533d1f28  vmovaps [rsp+0xE0], xmm15
000078e5533d1f31  sub rsp, 0x30
000078e5533d1f35  movaps [rsp], xmm1
000078e5533d1f39  movaps [rsp+0x10], xmm13
000078e5533d1f3f  movaps [rsp+0x20], xmm2
000078e5533d1f44  lea rdi, [rsp]
000078e5533d1f48  mov esi, 0x00
000078e5533d1f4d  mov rax, 0x5F83D5E17530
000078e5533d1f57  call rax
000078e5533d1f59  movaps xmm1, [rsp]
000078e5533d1f5d  add rsp, 0x30
000078e5533d1f61  vmovaps xmm0, [rsp]
000078e5533d1f66  vmovaps xmm2, [rsp+0x10]
000078e5533d1f6c  vmovaps xmm3, [rsp+0x20]
000078e5533d1f72  vmovaps xmm4, [rsp+0x30]
000078e5533d1f78  vmovaps xmm5, [rsp+0x40]
000078e5533d1f7e  vmovaps xmm6, [rsp+0x50]
000078e5533d1f84  vmovaps xmm7, [rsp+0x60]
000078e5533d1f8a  vmovaps xmm8, [rsp+0x70]
000078e5533d1f90  vmovaps xmm9, [rsp+0x80]
000078e5533d1f99  vmovaps xmm10, [rsp+0x90]
000078e5533d1fa2  vmovaps xmm11, [rsp+0xA0]
000078e5533d1fab  vmovaps xmm12, [rsp+0xB0]
000078e5533d1fb4  vmovaps xmm13, [rsp+0xC0]
000078e5533d1fbd  vmovaps xmm14, [rsp+0xD0]
000078e5533d1fc6  vmovaps xmm15, [rsp+0xE0]
000078e5533d1fcf  add rsp, 0xF0
000078e5533d1fd6  pop r11
000078e5533d1fd8  pop r10
000078e5533d1fda  pop r9
000078e5533d1fdc  pop r8
000078e5533d1fde  pop rsi
000078e5533d1fdf  pop rdi
000078e5533d1fe0  pop rdx
000078e5533d1fe1  pop rcx
000078e5533d1fe2  pop rax
000078e5533d1fe3  add rsp, 0x08
000078e5533d1fe7  jmp 0x000078E5533CFB52
000078e5533d1fec  sub rsp, 0x08
000078e5533d1ff0  push rax
000078e5533d1ff1  push rcx
000078e5533d1ff2  push rdx
000078e5533d1ff3  push rdi
000078e5533d1ff4  push rsi
000078e5533d1ff5  push r8
000078e5533d1ff7  push r9
000078e5533d1ff9  push r10
000078e5533d1ffb  push r11
000078e5533d1ffd  sub rsp, 0xF0
000078e5533d2004  vmovaps [rsp], xmm0
000078e5533d2009  vmovaps [rsp+0x10], xmm1
000078e5533d200f  vmovaps [rsp+0x20], xmm3
000078e5533d2015  vmovaps [rsp+0x30], xmm4
000078e5533d201b  vmovaps [rsp+0x40], xmm5
000078e5533d2021  vmovaps [rsp+0x50], xmm6
000078e5533d2027  vmovaps [rsp+0x60], xmm7
000078e5533d202d  vmovaps [rsp+0x70], xmm8
000078e5533d2033  vmovaps [rsp+0x80], xmm9
000078e5533d203c  vmovaps [rsp+0x90], xmm10
000078e5533d2045  vmovaps [rsp+0xA0], xmm11
000078e5533d204e  vmovaps [rsp+0xB0], xmm12
000078e5533d2057  vmovaps [rsp+0xC0], xmm13
000078e5533d2060  vmovaps [rsp+0xD0], xmm14
000078e5533d2069  vmovaps [rsp+0xE0], xmm15
000078e5533d2072  sub rsp, 0x30
000078e5533d2076  movaps [rsp], xmm2
000078e5533d207a  movaps [rsp+0x10], xmm1
000078e5533d207f  movaps [rsp+0x20], xmm13
000078e5533d2085  lea rdi, [rsp]
000078e5533d2089  mov esi, 0x00
000078e5533d208e  mov rax, 0x5F83D5E17530
000078e5533d2098  call rax
000078e5533d209a  movaps xmm2, [rsp]
000078e5533d209e  add rsp, 0x30
000078e5533d20a2  vmovaps xmm0, [rsp]
000078e5533d20a7  vmovaps xmm1, [rsp+0x10]
000078e5533d20ad  vmovaps xmm3, [rsp+0x20]
000078e5533d20b3  vmovaps xmm4, [rsp+0x30]
000078e5533d20b9  vmovaps xmm5, [rsp+0x40]
000078e5533d20bf  vmovaps xmm6, [rsp+0x50]
000078e5533d20c5  vmovaps xmm7, [rsp+0x60]
000078e5533d20cb  vmovaps xmm8, [rsp+0x70]
000078e5533d20d1  vmovaps xmm9, [rsp+0x80]
000078e5533d20da  vmovaps xmm10, [rsp+0x90]
000078e5533d20e3  vmovaps xmm11, [rsp+0xA0]
000078e5533d20ec  vmovaps xmm12, [rsp+0xB0]
000078e5533d20f5  vmovaps xmm13, [rsp+0xC0]
000078e5533d20fe  vmovaps xmm14, [rsp+0xD0]
000078e5533d2107  vmovaps xmm15, [rsp+0xE0]
000078e5533d2110  add rsp, 0xF0
000078e5533d2117  pop r11
000078e5533d2119  pop r10
000078e5533d211b  pop r9
000078e5533d211d  pop r8
000078e5533d211f  pop rsi
000078e5533d2120  pop rdi
000078e5533d2121  pop rdx
000078e5533d2122  pop rcx
000078e5533d2123  pop rax
000078e5533d2124  add rsp, 0x08
000078e5533d2128  jmp 0x000078E5533CFBAB
000078e5533d212d  call 0x000078E5531FF430
000078e5533d2132  jmp 0x000078E5533CFBB8
000078e5533d2137  sub rsp, 0x08
000078e5533d213b  push rax
000078e5533d213c  push rcx
000078e5533d213d  push rdx
000078e5533d213e  push rdi
000078e5533d213f  push rsi
000078e5533d2140  push r8
000078e5533d2142  push r9
000078e5533d2144  push r10
000078e5533d2146  push r11
000078e5533d2148  sub rsp, 0xF0
000078e5533d214f  vmovaps [rsp], xmm0
000078e5533d2154  vmovaps [rsp+0x10], xmm1
000078e5533d215a  vmovaps [rsp+0x20], xmm2
000078e5533d2160  vmovaps [rsp+0x30], xmm3
000078e5533d2166  vmovaps [rsp+0x40], xmm4
000078e5533d216c  vmovaps [rsp+0x50], xmm5
000078e5533d2172  vmovaps [rsp+0x60], xmm6
000078e5533d2178  vmovaps [rsp+0x70], xmm7
000078e5533d217e  vmovaps [rsp+0x80], xmm8
000078e5533d2187  vmovaps [rsp+0x90], xmm9
000078e5533d2190  vmovaps [rsp+0xA0], xmm10
000078e5533d2199  vmovaps [rsp+0xB0], xmm11
000078e5533d21a2  vmovaps [rsp+0xC0], xmm12
000078e5533d21ab  vmovaps [rsp+0xD0], xmm13
000078e5533d21b4  vmovaps [rsp+0xE0], xmm14
000078e5533d21bd  sub rsp, 0x30
000078e5533d21c1  movaps [rsp], xmm15
000078e5533d21c6  movaps [rsp+0x10], xmm13
000078e5533d21cc  movaps [rsp+0x20], xmm1
000078e5533d21d1  lea rdi, [rsp]
000078e5533d21d5  mov esi, 0x00
000078e5533d21da  mov rax, 0x5F83D5E17530
000078e5533d21e4  call rax
000078e5533d21e6  movaps xmm15, [rsp]
000078e5533d21eb  add rsp, 0x30
000078e5533d21ef  vmovaps xmm0, [rsp]
000078e5533d21f4  vmovaps xmm1, [rsp+0x10]
000078e5533d21fa  vmovaps xmm2, [rsp+0x20]
000078e5533d2200  vmovaps xmm3, [rsp+0x30]
000078e5533d2206  vmovaps xmm4, [rsp+0x40]
000078e5533d220c  vmovaps xmm5, [rsp+0x50]
000078e5533d2212  vmovaps xmm6, [rsp+0x60]
000078e5533d2218  vmovaps xmm7, [rsp+0x70]
000078e5533d221e  vmovaps xmm8, [rsp+0x80]
000078e5533d2227  vmovaps xmm9, [rsp+0x90]
000078e5533d2230  vmovaps xmm10, [rsp+0xA0]
000078e5533d2239  vmovaps xmm11, [rsp+0xB0]
000078e5533d2242  vmovaps xmm12, [rsp+0xC0]
000078e5533d224b  vmovaps xmm13, [rsp+0xD0]
000078e5533d2254  vmovaps xmm14, [rsp+0xE0]
000078e5533d225d  add rsp, 0xF0
000078e5533d2264  pop r11
000078e5533d2266  pop r10
000078e5533d2268  pop r9
000078e5533d226a  pop r8
000078e5533d226c  pop rsi
000078e5533d226d  pop rdi
000078e5533d226e  pop rdx
000078e5533d226f  pop rcx
000078e5533d2270  pop rax
000078e5533d2271  add rsp, 0x08
000078e5533d2275  jmp 0x000078E5533CFBF7
000078e5533d227a  sub rsp, 0x08
000078e5533d227e  push rax
000078e5533d227f  push rcx
000078e5533d2280  push rdx
000078e5533d2281  push rdi
000078e5533d2282  push rsi
000078e5533d2283  push r8
000078e5533d2285  push r9
000078e5533d2287  push r10
000078e5533d2289  push r11
000078e5533d228b  sub rsp, 0xF0
000078e5533d2292  vmovaps [rsp], xmm0
000078e5533d2297  vmovaps [rsp+0x10], xmm1
000078e5533d229d  vmovaps [rsp+0x20], xmm2
000078e5533d22a3  vmovaps [rsp+0x30], xmm3
000078e5533d22a9  vmovaps [rsp+0x40], xmm4
000078e5533d22af  vmovaps [rsp+0x50], xmm5
000078e5533d22b5  vmovaps [rsp+0x60], xmm6
000078e5533d22bb  vmovaps [rsp+0x70], xmm7
000078e5533d22c1  vmovaps [rsp+0x80], xmm8
000078e5533d22ca  vmovaps [rsp+0x90], xmm9
000078e5533d22d3  vmovaps [rsp+0xA0], xmm10
000078e5533d22dc  vmovaps [rsp+0xB0], xmm11
000078e5533d22e5  vmovaps [rsp+0xC0], xmm12
000078e5533d22ee  vmovaps [rsp+0xD0], xmm13
000078e5533d22f7  vmovaps [rsp+0xE0], xmm15
000078e5533d2300  sub rsp, 0x30
000078e5533d2304  movaps [rsp], xmm14
000078e5533d2309  movaps [rsp+0x10], xmm11
000078e5533d230f  movaps [rsp+0x20], xmm1
000078e5533d2314  lea rdi, [rsp]
000078e5533d2318  mov esi, 0x00
000078e5533d231d  mov rax, 0x5F83D5E17530
000078e5533d2327  call rax
000078e5533d2329  movaps xmm14, [rsp]
000078e5533d232e  add rsp, 0x30
000078e5533d2332  vmovaps xmm0, [rsp]
000078e5533d2337  vmovaps xmm1, [rsp+0x10]
000078e5533d233d  vmovaps xmm2, [rsp+0x20]
000078e5533d2343  vmovaps xmm3, [rsp+0x30]
000078e5533d2349  vmovaps xmm4, [rsp+0x40]
000078e5533d234f  vmovaps xmm5, [rsp+0x50]
000078e5533d2355  vmovaps xmm6, [rsp+0x60]
000078e5533d235b  vmovaps xmm7, [rsp+0x70]
000078e5533d2361  vmovaps xmm8, [rsp+0x80]
000078e5533d236a  vmovaps xmm9, [rsp+0x90]
000078e5533d2373  vmovaps xmm10, [rsp+0xA0]
000078e5533d237c  vmovaps xmm11, [rsp+0xB0]
000078e5533d2385  vmovaps xmm12, [rsp+0xC0]
000078e5533d238e  vmovaps xmm13, [rsp+0xD0]
000078e5533d2397  vmovaps xmm15, [rsp+0xE0]
000078e5533d23a0  add rsp, 0xF0
000078e5533d23a7  pop r11
000078e5533d23a9  pop r10
000078e5533d23ab  pop r9
000078e5533d23ad  pop r8
000078e5533d23af  pop rsi
000078e5533d23b0  pop rdi
000078e5533d23b1  pop rdx
000078e5533d23b2  pop rcx
000078e5533d23b3  pop rax
000078e5533d23b4  add rsp, 0x08
000078e5533d23b8  jmp 0x000078E5533CFC21
000078e5533d23bd  sub rsp, 0x08
000078e5533d23c1  push rax
000078e5533d23c2  push rcx
000078e5533d23c3  push rdx
000078e5533d23c4  push rdi
000078e5533d23c5  push rsi
000078e5533d23c6  push r8
000078e5533d23c8  push r9
000078e5533d23ca  push r10
000078e5533d23cc  push r11
000078e5533d23ce  sub rsp, 0xF0
000078e5533d23d5  vmovaps [rsp], xmm0
000078e5533d23da  vmovaps [rsp+0x10], xmm1
000078e5533d23e0  vmovaps [rsp+0x20], xmm2
000078e5533d23e6  vmovaps [rsp+0x30], xmm3
000078e5533d23ec  vmovaps [rsp+0x40], xmm4
000078e5533d23f2  vmovaps [rsp+0x50], xmm5
000078e5533d23f8  vmovaps [rsp+0x60], xmm6
000078e5533d23fe  vmovaps [rsp+0x70], xmm7
000078e5533d2404  vmovaps [rsp+0x80], xmm8
000078e5533d240d  vmovaps [rsp+0x90], xmm9
000078e5533d2416  vmovaps [rsp+0xA0], xmm10
000078e5533d241f  vmovaps [rsp+0xB0], xmm11
000078e5533d2428  vmovaps [rsp+0xC0], xmm12
000078e5533d2431  vmovaps [rsp+0xD0], xmm14
000078e5533d243a  vmovaps [rsp+0xE0], xmm15
000078e5533d2443  sub rsp, 0x30
000078e5533d2447  movaps [rsp], xmm13
000078e5533d244c  movaps [rsp+0x10], xmm11
000078e5533d2452  movaps [rsp+0x20], xmm1
000078e5533d2457  lea rdi, [rsp]
000078e5533d245b  mov esi, 0x00
000078e5533d2460  mov rax, 0x5F83D5E17530
000078e5533d246a  call rax
000078e5533d246c  movaps xmm13, [rsp]
000078e5533d2471  add rsp, 0x30
000078e5533d2475  vmovaps xmm0, [rsp]
000078e5533d247a  vmovaps xmm1, [rsp+0x10]
000078e5533d2480  vmovaps xmm2, [rsp+0x20]
000078e5533d2486  vmovaps xmm3, [rsp+0x30]
000078e5533d248c  vmovaps xmm4, [rsp+0x40]
000078e5533d2492  vmovaps xmm5, [rsp+0x50]
000078e5533d2498  vmovaps xmm6, [rsp+0x60]
000078e5533d249e  vmovaps xmm7, [rsp+0x70]
000078e5533d24a4  vmovaps xmm8, [rsp+0x80]
000078e5533d24ad  vmovaps xmm9, [rsp+0x90]
000078e5533d24b6  vmovaps xmm10, [rsp+0xA0]
000078e5533d24bf  vmovaps xmm11, [rsp+0xB0]
000078e5533d24c8  vmovaps xmm12, [rsp+0xC0]
000078e5533d24d1  vmovaps xmm14, [rsp+0xD0]
000078e5533d24da  vmovaps xmm15, [rsp+0xE0]
000078e5533d24e3  add rsp, 0xF0
000078e5533d24ea  pop r11
000078e5533d24ec  pop r10
000078e5533d24ee  pop r9
000078e5533d24f0  pop r8
000078e5533d24f2  pop rsi
000078e5533d24f3  pop rdi
000078e5533d24f4  pop rdx
000078e5533d24f5  pop rcx
000078e5533d24f6  pop rax
000078e5533d24f7  add rsp, 0x08
000078e5533d24fb  jmp 0x000078E5533CFC76
000078e5533d2500  call 0x000078E5531FF430
000078e5533d2505  jmp 0x000078E5533CFC83
000078e5533d250a  sub rsp, 0x08
000078e5533d250e  push rax
000078e5533d250f  push rcx
000078e5533d2510  push rdx
000078e5533d2511  push rdi
000078e5533d2512  push rsi
000078e5533d2513  push r8
000078e5533d2515  push r9
000078e5533d2517  push r10
000078e5533d2519  push r11
000078e5533d251b  sub rsp, 0xF0
000078e5533d2522  vmovaps [rsp], xmm0
000078e5533d2527  vmovaps [rsp+0x10], xmm1
000078e5533d252d  vmovaps [rsp+0x20], xmm2
000078e5533d2533  vmovaps [rsp+0x30], xmm3
000078e5533d2539  vmovaps [rsp+0x40], xmm4
000078e5533d253f  vmovaps [rsp+0x50], xmm5
000078e5533d2545  vmovaps [rsp+0x60], xmm6
000078e5533d254b  vmovaps [rsp+0x70], xmm7
000078e5533d2551  vmovaps [rsp+0x80], xmm8
000078e5533d255a  vmovaps [rsp+0x90], xmm9
000078e5533d2563  vmovaps [rsp+0xA0], xmm10
000078e5533d256c  vmovaps [rsp+0xB0], xmm11
000078e5533d2575  vmovaps [rsp+0xC0], xmm12
000078e5533d257e  vmovaps [rsp+0xD0], xmm13
000078e5533d2587  vmovaps [rsp+0xE0], xmm14
000078e5533d2590  sub rsp, 0x30
000078e5533d2594  movaps [rsp], xmm15
000078e5533d2599  movaps [rsp+0x10], xmm11
000078e5533d259f  movaps [rsp+0x20], xmm1
000078e5533d25a4  lea rdi, [rsp]
000078e5533d25a8  mov esi, 0x00
000078e5533d25ad  mov rax, 0x5F83D5E17530
000078e5533d25b7  call rax
000078e5533d25b9  movaps xmm15, [rsp]
000078e5533d25be  add rsp, 0x30
000078e5533d25c2  vmovaps xmm0, [rsp]
000078e5533d25c7  vmovaps xmm1, [rsp+0x10]
000078e5533d25cd  vmovaps xmm2, [rsp+0x20]
000078e5533d25d3  vmovaps xmm3, [rsp+0x30]
000078e5533d25d9  vmovaps xmm4, [rsp+0x40]
000078e5533d25df  vmovaps xmm5, [rsp+0x50]
000078e5533d25e5  vmovaps xmm6, [rsp+0x60]
000078e5533d25eb  vmovaps xmm7, [rsp+0x70]
000078e5533d25f1  vmovaps xmm8, [rsp+0x80]
000078e5533d25fa  vmovaps xmm9, [rsp+0x90]
000078e5533d2603  vmovaps xmm10, [rsp+0xA0]
000078e5533d260c  vmovaps xmm11, [rsp+0xB0]
000078e5533d2615  vmovaps xmm12, [rsp+0xC0]
000078e5533d261e  vmovaps xmm13, [rsp+0xD0]
000078e5533d2627  vmovaps xmm14, [rsp+0xE0]
000078e5533d2630  add rsp, 0xF0
000078e5533d2637  pop r11
000078e5533d2639  pop r10
000078e5533d263b  pop r9
000078e5533d263d  pop r8
000078e5533d263f  pop rsi
000078e5533d2640  pop rdi
000078e5533d2641  pop rdx
000078e5533d2642  pop rcx
000078e5533d2643  pop rax
000078e5533d2644  add rsp, 0x08
000078e5533d2648  jmp 0x000078E5533CFCBC
000078e5533d264d  sub rsp, 0x08
000078e5533d2651  push rax
000078e5533d2652  push rcx
000078e5533d2653  push rdx
000078e5533d2654  push rdi
000078e5533d2655  push rsi
000078e5533d2656  push r8
000078e5533d2658  push r9
000078e5533d265a  push r10
000078e5533d265c  push r11
000078e5533d265e  sub rsp, 0xF0
000078e5533d2665  vmovaps [rsp], xmm0
000078e5533d266a  vmovaps [rsp+0x10], xmm1
000078e5533d2670  vmovaps [rsp+0x20], xmm2
000078e5533d2676  vmovaps [rsp+0x30], xmm3
000078e5533d267c  vmovaps [rsp+0x40], xmm4
000078e5533d2682  vmovaps [rsp+0x50], xmm5
000078e5533d2688  vmovaps [rsp+0x60], xmm6
000078e5533d268e  vmovaps [rsp+0x70], xmm7
000078e5533d2694  vmovaps [rsp+0x80], xmm8
000078e5533d269d  vmovaps [rsp+0x90], xmm9
000078e5533d26a6  vmovaps [rsp+0xA0], xmm10
000078e5533d26af  vmovaps [rsp+0xB0], xmm12
000078e5533d26b8  vmovaps [rsp+0xC0], xmm13
000078e5533d26c1  vmovaps [rsp+0xD0], xmm14
000078e5533d26ca  vmovaps [rsp+0xE0], xmm15
000078e5533d26d3  sub rsp, 0x30
000078e5533d26d7  movaps [rsp], xmm11
000078e5533d26dc  movaps [rsp+0x10], xmm6
000078e5533d26e1  movaps [rsp+0x20], xmm14
000078e5533d26e7  lea rdi, [rsp]
000078e5533d26eb  mov esi, 0x00
000078e5533d26f0  mov rax, 0x5F83D5E17530
000078e5533d26fa  call rax
000078e5533d26fc  movaps xmm11, [rsp]
000078e5533d2701  add rsp, 0x30
000078e5533d2705  vmovaps xmm0, [rsp]
000078e5533d270a  vmovaps xmm1, [rsp+0x10]
000078e5533d2710  vmovaps xmm2, [rsp+0x20]
000078e5533d2716  vmovaps xmm3, [rsp+0x30]
000078e5533d271c  vmovaps xmm4, [rsp+0x40]
000078e5533d2722  vmovaps xmm5, [rsp+0x50]
000078e5533d2728  vmovaps xmm6, [rsp+0x60]
000078e5533d272e  vmovaps xmm7, [rsp+0x70]
000078e5533d2734  vmovaps xmm8, [rsp+0x80]
000078e5533d273d  vmovaps xmm9, [rsp+0x90]
000078e5533d2746  vmovaps xmm10, [rsp+0xA0]
000078e5533d274f  vmovaps xmm12, [rsp+0xB0]
000078e5533d2758  vmovaps xmm13, [rsp+0xC0]
000078e5533d2761  vmovaps xmm14, [rsp+0xD0]
000078e5533d276a  vmovaps xmm15, [rsp+0xE0]
000078e5533d2773  add rsp, 0xF0
000078e5533d277a  pop r11
000078e5533d277c  pop r10
000078e5533d277e  pop r9
000078e5533d2780  pop r8
000078e5533d2782  pop rsi
000078e5533d2783  pop rdi
000078e5533d2784  pop rdx
000078e5533d2785  pop rcx
000078e5533d2786  pop rax
000078e5533d2787  add rsp, 0x08
000078e5533d278b  jmp 0x000078E5533CFD34
000078e5533d2790  call 0x000078E5531FF430
000078e5533d2795  jmp 0x000078E5533CFD3E
000078e5533d279a  sub rsp, 0x08
000078e5533d279e  push rax
000078e5533d279f  push rcx
000078e5533d27a0  push rdx
000078e5533d27a1  push rdi
000078e5533d27a2  push rsi
000078e5533d27a3  push r8
000078e5533d27a5  push r9
000078e5533d27a7  push r10
000078e5533d27a9  push r11
000078e5533d27ab  sub rsp, 0xF0
000078e5533d27b2  vmovaps [rsp], xmm0
000078e5533d27b7  vmovaps [rsp+0x10], xmm1
000078e5533d27bd  vmovaps [rsp+0x20], xmm2
000078e5533d27c3  vmovaps [rsp+0x30], xmm3
000078e5533d27c9  vmovaps [rsp+0x40], xmm4
000078e5533d27cf  vmovaps [rsp+0x50], xmm5
000078e5533d27d5  vmovaps [rsp+0x60], xmm6
000078e5533d27db  vmovaps [rsp+0x70], xmm7
000078e5533d27e1  vmovaps [rsp+0x80], xmm8
000078e5533d27ea  vmovaps [rsp+0x90], xmm9
000078e5533d27f3  vmovaps [rsp+0xA0], xmm10
000078e5533d27fc  vmovaps [rsp+0xB0], xmm11
000078e5533d2805  vmovaps [rsp+0xC0], xmm12
000078e5533d280e  vmovaps [rsp+0xD0], xmm13
000078e5533d2817  vmovaps [rsp+0xE0], xmm15
000078e5533d2820  sub rsp, 0x30
000078e5533d2824  movaps [rsp], xmm14
000078e5533d2829  movaps [rsp+0x10], xmm6
000078e5533d282e  movaps [rsp+0x20], xmm2
000078e5533d2833  lea rdi, [rsp]
000078e5533d2837  mov esi, 0x00
000078e5533d283c  mov rax, 0x5F83D5E17530
000078e5533d2846  call rax
000078e5533d2848  movaps xmm14, [rsp]
000078e5533d284d  add rsp, 0x30
000078e5533d2851  vmovaps xmm0, [rsp]
000078e5533d2856  vmovaps xmm1, [rsp+0x10]
000078e5533d285c  vmovaps xmm2, [rsp+0x20]
000078e5533d2862  vmovaps xmm3, [rsp+0x30]
000078e5533d2868  vmovaps xmm4, [rsp+0x40]
000078e5533d286e  vmovaps xmm5, [rsp+0x50]
000078e5533d2874  vmovaps xmm6, [rsp+0x60]
000078e5533d287a  vmovaps xmm7, [rsp+0x70]
000078e5533d2880  vmovaps xmm8, [rsp+0x80]
000078e5533d2889  vmovaps xmm9, [rsp+0x90]
000078e5533d2892  vmovaps xmm10, [rsp+0xA0]
000078e5533d289b  vmovaps xmm11, [rsp+0xB0]
000078e5533d28a4  vmovaps xmm12, [rsp+0xC0]
000078e5533d28ad  vmovaps xmm13, [rsp+0xD0]
000078e5533d28b6  vmovaps xmm15, [rsp+0xE0]
000078e5533d28bf  add rsp, 0xF0
000078e5533d28c6  pop r11
000078e5533d28c8  pop r10
000078e5533d28ca  pop r9
000078e5533d28cc  pop r8
000078e5533d28ce  pop rsi
000078e5533d28cf  pop rdi
000078e5533d28d0  pop rdx
000078e5533d28d1  pop rcx
000078e5533d28d2  pop rax
000078e5533d28d3  add rsp, 0x08
000078e5533d28d7  jmp 0x000078E5533CFD72
000078e5533d28dc  sub rsp, 0x08
000078e5533d28e0  push rax
000078e5533d28e1  push rcx
000078e5533d28e2  push rdx
000078e5533d28e3  push rdi
000078e5533d28e4  push rsi
000078e5533d28e5  push r8
000078e5533d28e7  push r9
000078e5533d28e9  push r10
000078e5533d28eb  push r11
000078e5533d28ed  sub rsp, 0xF0
000078e5533d28f4  vmovaps [rsp], xmm0
000078e5533d28f9  vmovaps [rsp+0x10], xmm1
000078e5533d28ff  vmovaps [rsp+0x20], xmm2
000078e5533d2905  vmovaps [rsp+0x30], xmm3
000078e5533d290b  vmovaps [rsp+0x40], xmm4
000078e5533d2911  vmovaps [rsp+0x50], xmm5
000078e5533d2917  vmovaps [rsp+0x60], xmm7
000078e5533d291d  vmovaps [rsp+0x70], xmm8
000078e5533d2923  vmovaps [rsp+0x80], xmm9
000078e5533d292c  vmovaps [rsp+0x90], xmm10
000078e5533d2935  vmovaps [rsp+0xA0], xmm11
000078e5533d293e  vmovaps [rsp+0xB0], xmm12
000078e5533d2947  vmovaps [rsp+0xC0], xmm13
000078e5533d2950  vmovaps [rsp+0xD0], xmm14
000078e5533d2959  vmovaps [rsp+0xE0], xmm15
000078e5533d2962  sub rsp, 0x30
000078e5533d2966  movaps [rsp], xmm6
000078e5533d296a  movaps [rsp+0x10], xmm5
000078e5533d296f  movaps [rsp+0x20], xmm1
000078e5533d2974  lea rdi, [rsp]
000078e5533d2978  mov esi, 0x00
000078e5533d297d  mov rax, 0x5F83D5E17530
000078e5533d2987  call rax
000078e5533d2989  movaps xmm6, [rsp]
000078e5533d298d  add rsp, 0x30
000078e5533d2991  vmovaps xmm0, [rsp]
000078e5533d2996  vmovaps xmm1, [rsp+0x10]
000078e5533d299c  vmovaps xmm2, [rsp+0x20]
000078e5533d29a2  vmovaps xmm3, [rsp+0x30]
000078e5533d29a8  vmovaps xmm4, [rsp+0x40]
000078e5533d29ae  vmovaps xmm5, [rsp+0x50]
000078e5533d29b4  vmovaps xmm7, [rsp+0x60]
000078e5533d29ba  vmovaps xmm8, [rsp+0x70]
000078e5533d29c0  vmovaps xmm9, [rsp+0x80]
000078e5533d29c9  vmovaps xmm10, [rsp+0x90]
000078e5533d29d2  vmovaps xmm11, [rsp+0xA0]
000078e5533d29db  vmovaps xmm12, [rsp+0xB0]
000078e5533d29e4  vmovaps xmm13, [rsp+0xC0]
000078e5533d29ed  vmovaps xmm14, [rsp+0xD0]
000078e5533d29f6  vmovaps xmm15, [rsp+0xE0]
000078e5533d29ff  add rsp, 0xF0
000078e5533d2a06  pop r11
000078e5533d2a08  pop r10
000078e5533d2a0a  pop r9
000078e5533d2a0c  pop r8
000078e5533d2a0e  pop rsi
000078e5533d2a0f  pop rdi
000078e5533d2a10  pop rdx
000078e5533d2a11  pop rcx
000078e5533d2a12  pop rax
000078e5533d2a13  add rsp, 0x08
000078e5533d2a17  jmp 0x000078E5533CFD98
000078e5533d2a1c  sub rsp, 0x08
000078e5533d2a20  push rax
000078e5533d2a21  push rcx
000078e5533d2a22  push rdx
000078e5533d2a23  push rdi
000078e5533d2a24  push rsi
000078e5533d2a25  push r8
000078e5533d2a27  push r9
000078e5533d2a29  push r10
000078e5533d2a2b  push r11
000078e5533d2a2d  sub rsp, 0xF0
000078e5533d2a34  vmovaps [rsp], xmm0
000078e5533d2a39  vmovaps [rsp+0x10], xmm2
000078e5533d2a3f  vmovaps [rsp+0x20], xmm3
000078e5533d2a45  vmovaps [rsp+0x30], xmm4
000078e5533d2a4b  vmovaps [rsp+0x40], xmm5
000078e5533d2a51  vmovaps [rsp+0x50], xmm6
000078e5533d2a57  vmovaps [rsp+0x60], xmm7
000078e5533d2a5d  vmovaps [rsp+0x70], xmm8
000078e5533d2a63  vmovaps [rsp+0x80], xmm9
000078e5533d2a6c  vmovaps [rsp+0x90], xmm10
000078e5533d2a75  vmovaps [rsp+0xA0], xmm11
000078e5533d2a7e  vmovaps [rsp+0xB0], xmm12
000078e5533d2a87  vmovaps [rsp+0xC0], xmm13
000078e5533d2a90  vmovaps [rsp+0xD0], xmm14
000078e5533d2a99  vmovaps [rsp+0xE0], xmm15
000078e5533d2aa2  sub rsp, 0x30
000078e5533d2aa6  movaps [rsp], xmm1
000078e5533d2aaa  movaps [rsp+0x10], xmm5
000078e5533d2aaf  movaps [rsp+0x20], xmm13
000078e5533d2ab5  lea rdi, [rsp]
000078e5533d2ab9  mov esi, 0x00
000078e5533d2abe  mov rax, 0x5F83D5E17530
000078e5533d2ac8  call rax
000078e5533d2aca  movaps xmm1, [rsp]
000078e5533d2ace  add rsp, 0x30
000078e5533d2ad2  vmovaps xmm0, [rsp]
000078e5533d2ad7  vmovaps xmm2, [rsp+0x10]
000078e5533d2add  vmovaps xmm3, [rsp+0x20]
000078e5533d2ae3  vmovaps xmm4, [rsp+0x30]
000078e5533d2ae9  vmovaps xmm5, [rsp+0x40]
000078e5533d2aef  vmovaps xmm6, [rsp+0x50]
000078e5533d2af5  vmovaps xmm7, [rsp+0x60]
000078e5533d2afb  vmovaps xmm8, [rsp+0x70]
000078e5533d2b01  vmovaps xmm9, [rsp+0x80]
000078e5533d2b0a  vmovaps xmm10, [rsp+0x90]
000078e5533d2b13  vmovaps xmm11, [rsp+0xA0]
000078e5533d2b1c  vmovaps xmm12, [rsp+0xB0]
000078e5533d2b25  vmovaps xmm13, [rsp+0xC0]
000078e5533d2b2e  vmovaps xmm14, [rsp+0xD0]
000078e5533d2b37  vmovaps xmm15, [rsp+0xE0]
000078e5533d2b40  add rsp, 0xF0
000078e5533d2b47  pop r11
000078e5533d2b49  pop r10
000078e5533d2b4b  pop r9
000078e5533d2b4d  pop r8
000078e5533d2b4f  pop rsi
000078e5533d2b50  pop rdi
000078e5533d2b51  pop rdx
000078e5533d2b52  pop rcx
000078e5533d2b53  pop rax
000078e5533d2b54  add rsp, 0x08
000078e5533d2b58  jmp 0x000078E5533CFDB6
000078e5533d2b5d  sub rsp, 0x08
000078e5533d2b61  push rax
000078e5533d2b62  push rcx
000078e5533d2b63  push rdx
000078e5533d2b64  push rdi
000078e5533d2b65  push rsi
000078e5533d2b66  push r8
000078e5533d2b68  push r9
000078e5533d2b6a  push r10
000078e5533d2b6c  push r11
000078e5533d2b6e  sub rsp, 0xF0
000078e5533d2b75  vmovaps [rsp], xmm0
000078e5533d2b7a  vmovaps [rsp+0x10], xmm1
000078e5533d2b80  vmovaps [rsp+0x20], xmm2
000078e5533d2b86  vmovaps [rsp+0x30], xmm3
000078e5533d2b8c  vmovaps [rsp+0x40], xmm4
000078e5533d2b92  vmovaps [rsp+0x50], xmm6
000078e5533d2b98  vmovaps [rsp+0x60], xmm7
000078e5533d2b9e  vmovaps [rsp+0x70], xmm8
000078e5533d2ba4  vmovaps [rsp+0x80], xmm9
000078e5533d2bad  vmovaps [rsp+0x90], xmm10
000078e5533d2bb6  vmovaps [rsp+0xA0], xmm11
000078e5533d2bbf  vmovaps [rsp+0xB0], xmm12
000078e5533d2bc8  vmovaps [rsp+0xC0], xmm13
000078e5533d2bd1  vmovaps [rsp+0xD0], xmm14
000078e5533d2bda  vmovaps [rsp+0xE0], xmm15
000078e5533d2be3  sub rsp, 0x30
000078e5533d2be7  movaps [rsp], xmm5
000078e5533d2beb  movaps [rsp+0x10], xmm2
000078e5533d2bf0  movaps [rsp+0x20], xmm13
000078e5533d2bf6  lea rdi, [rsp]
000078e5533d2bfa  mov esi, 0x00
000078e5533d2bff  mov rax, 0x5F83D5E17530
000078e5533d2c09  call rax
000078e5533d2c0b  movaps xmm5, [rsp]
000078e5533d2c0f  add rsp, 0x30
000078e5533d2c13  vmovaps xmm0, [rsp]
000078e5533d2c18  vmovaps xmm1, [rsp+0x10]
000078e5533d2c1e  vmovaps xmm2, [rsp+0x20]
000078e5533d2c24  vmovaps xmm3, [rsp+0x30]
000078e5533d2c2a  vmovaps xmm4, [rsp+0x40]
000078e5533d2c30  vmovaps xmm6, [rsp+0x50]
000078e5533d2c36  vmovaps xmm7, [rsp+0x60]
000078e5533d2c3c  vmovaps xmm8, [rsp+0x70]
000078e5533d2c42  vmovaps xmm9, [rsp+0x80]
000078e5533d2c4b  vmovaps xmm10, [rsp+0x90]
000078e5533d2c54  vmovaps xmm11, [rsp+0xA0]
000078e5533d2c5d  vmovaps xmm12, [rsp+0xB0]
000078e5533d2c66  vmovaps xmm13, [rsp+0xC0]
000078e5533d2c6f  vmovaps xmm14, [rsp+0xD0]
000078e5533d2c78  vmovaps xmm15, [rsp+0xE0]
000078e5533d2c81  add rsp, 0xF0
000078e5533d2c88  pop r11
000078e5533d2c8a  pop r10
000078e5533d2c8c  pop r9
000078e5533d2c8e  pop r8
000078e5533d2c90  pop rsi
000078e5533d2c91  pop rdi
000078e5533d2c92  pop rdx
000078e5533d2c93  pop rcx
000078e5533d2c94  pop rax
000078e5533d2c95  add rsp, 0x08
000078e5533d2c99  jmp 0x000078E5533CFDEC
000078e5533d2c9e  sub rsp, 0x08
000078e5533d2ca2  push rax
000078e5533d2ca3  push rcx
000078e5533d2ca4  push rdx
000078e5533d2ca5  push rdi
000078e5533d2ca6  push rsi
000078e5533d2ca7  push r8
000078e5533d2ca9  push r9
000078e5533d2cab  push r10
000078e5533d2cad  push r11
000078e5533d2caf  sub rsp, 0xF0
000078e5533d2cb6  vmovaps [rsp], xmm0
000078e5533d2cbb  vmovaps [rsp+0x10], xmm1
000078e5533d2cc1  vmovaps [rsp+0x20], xmm2
000078e5533d2cc7  vmovaps [rsp+0x30], xmm3
000078e5533d2ccd  vmovaps [rsp+0x40], xmm4
000078e5533d2cd3  vmovaps [rsp+0x50], xmm5
000078e5533d2cd9  vmovaps [rsp+0x60], xmm6
000078e5533d2cdf  vmovaps [rsp+0x70], xmm7
000078e5533d2ce5  vmovaps [rsp+0x80], xmm8
000078e5533d2cee  vmovaps [rsp+0x90], xmm9
000078e5533d2cf7  vmovaps [rsp+0xA0], xmm10
000078e5533d2d00  vmovaps [rsp+0xB0], xmm11
000078e5533d2d09  vmovaps [rsp+0xC0], xmm12
000078e5533d2d12  vmovaps [rsp+0xD0], xmm14
000078e5533d2d1b  vmovaps [rsp+0xE0], xmm15
000078e5533d2d24  sub rsp, 0x30
000078e5533d2d28  movaps [rsp], xmm13
000078e5533d2d2d  movaps [rsp+0x10], xmm10
000078e5533d2d33  movaps [rsp+0x20], xmm1
000078e5533d2d38  lea rdi, [rsp]
000078e5533d2d3c  mov esi, 0x00
000078e5533d2d41  mov rax, 0x5F83D5E17530
000078e5533d2d4b  call rax
000078e5533d2d4d  movaps xmm13, [rsp]
000078e5533d2d52  add rsp, 0x30
000078e5533d2d56  vmovaps xmm0, [rsp]
000078e5533d2d5b  vmovaps xmm1, [rsp+0x10]
000078e5533d2d61  vmovaps xmm2, [rsp+0x20]
000078e5533d2d67  vmovaps xmm3, [rsp+0x30]
000078e5533d2d6d  vmovaps xmm4, [rsp+0x40]
000078e5533d2d73  vmovaps xmm5, [rsp+0x50]
000078e5533d2d79  vmovaps xmm6, [rsp+0x60]
000078e5533d2d7f  vmovaps xmm7, [rsp+0x70]
000078e5533d2d85  vmovaps xmm8, [rsp+0x80]
000078e5533d2d8e  vmovaps xmm9, [rsp+0x90]
000078e5533d2d97  vmovaps xmm10, [rsp+0xA0]
000078e5533d2da0  vmovaps xmm11, [rsp+0xB0]
000078e5533d2da9  vmovaps xmm12, [rsp+0xC0]
000078e5533d2db2  vmovaps xmm14, [rsp+0xD0]
000078e5533d2dbb  vmovaps xmm15, [rsp+0xE0]
000078e5533d2dc4  add rsp, 0xF0
000078e5533d2dcb  pop r11
000078e5533d2dcd  pop r10
000078e5533d2dcf  pop r9
000078e5533d2dd1  pop r8
000078e5533d2dd3  pop rsi
000078e5533d2dd4  pop rdi
000078e5533d2dd5  pop rdx
000078e5533d2dd6  pop rcx
000078e5533d2dd7  pop rax
000078e5533d2dd8  add rsp, 0x08
000078e5533d2ddc  jmp 0x000078E5533CFE15
000078e5533d2de1  sub rsp, 0x08
000078e5533d2de5  push rax
000078e5533d2de6  push rcx
000078e5533d2de7  push rdx
000078e5533d2de8  push rdi
000078e5533d2de9  push rsi
000078e5533d2dea  push r8
000078e5533d2dec  push r9
000078e5533d2dee  push r10
000078e5533d2df0  push r11
000078e5533d2df2  sub rsp, 0xF0
000078e5533d2df9  vmovaps [rsp], xmm0
000078e5533d2dfe  vmovaps [rsp+0x10], xmm2
000078e5533d2e04  vmovaps [rsp+0x20], xmm3
000078e5533d2e0a  vmovaps [rsp+0x30], xmm4
000078e5533d2e10  vmovaps [rsp+0x40], xmm5
000078e5533d2e16  vmovaps [rsp+0x50], xmm6
000078e5533d2e1c  vmovaps [rsp+0x60], xmm7
000078e5533d2e22  vmovaps [rsp+0x70], xmm8
000078e5533d2e28  vmovaps [rsp+0x80], xmm9
000078e5533d2e31  vmovaps [rsp+0x90], xmm10
000078e5533d2e3a  vmovaps [rsp+0xA0], xmm11
000078e5533d2e43  vmovaps [rsp+0xB0], xmm12
000078e5533d2e4c  vmovaps [rsp+0xC0], xmm13
000078e5533d2e55  vmovaps [rsp+0xD0], xmm14
000078e5533d2e5e  vmovaps [rsp+0xE0], xmm15
000078e5533d2e67  sub rsp, 0x30
000078e5533d2e6b  movaps [rsp], xmm1
000078e5533d2e6f  movaps [rsp+0x10], xmm15
000078e5533d2e75  movaps [rsp+0x20], xmm10
000078e5533d2e7b  lea rdi, [rsp]
000078e5533d2e7f  mov esi, 0x00
000078e5533d2e84  mov rax, 0x5F83D5E17530
000078e5533d2e8e  call rax
000078e5533d2e90  movaps xmm1, [rsp]
000078e5533d2e94  add rsp, 0x30
000078e5533d2e98  vmovaps xmm0, [rsp]
000078e5533d2e9d  vmovaps xmm2, [rsp+0x10]
000078e5533d2ea3  vmovaps xmm3, [rsp+0x20]
000078e5533d2ea9  vmovaps xmm4, [rsp+0x30]
000078e5533d2eaf  vmovaps xmm5, [rsp+0x40]
000078e5533d2eb5  vmovaps xmm6, [rsp+0x50]
000078e5533d2ebb  vmovaps xmm7, [rsp+0x60]
000078e5533d2ec1  vmovaps xmm8, [rsp+0x70]
000078e5533d2ec7  vmovaps xmm9, [rsp+0x80]
000078e5533d2ed0  vmovaps xmm10, [rsp+0x90]
000078e5533d2ed9  vmovaps xmm11, [rsp+0xA0]
000078e5533d2ee2  vmovaps xmm12, [rsp+0xB0]
000078e5533d2eeb  vmovaps xmm13, [rsp+0xC0]
000078e5533d2ef4  vmovaps xmm14, [rsp+0xD0]
000078e5533d2efd  vmovaps xmm15, [rsp+0xE0]
000078e5533d2f06  add rsp, 0xF0
000078e5533d2f0d  pop r11
000078e5533d2f0f  pop r10
000078e5533d2f11  pop r9
000078e5533d2f13  pop r8
000078e5533d2f15  pop rsi
000078e5533d2f16  pop rdi
000078e5533d2f17  pop rdx
000078e5533d2f18  pop rcx
000078e5533d2f19  pop rax
000078e5533d2f1a  add rsp, 0x08
000078e5533d2f1e  jmp 0x000078E5533CFE34
000078e5533d2f23  sub rsp, 0x08
000078e5533d2f27  push rax
000078e5533d2f28  push rcx
000078e5533d2f29  push rdx
000078e5533d2f2a  push rdi
000078e5533d2f2b  push rsi
000078e5533d2f2c  push r8
000078e5533d2f2e  push r9
000078e5533d2f30  push r10
000078e5533d2f32  push r11
000078e5533d2f34  sub rsp, 0xF0
000078e5533d2f3b  vmovaps [rsp], xmm0
000078e5533d2f40  vmovaps [rsp+0x10], xmm1
000078e5533d2f46  vmovaps [rsp+0x20], xmm2
000078e5533d2f4c  vmovaps [rsp+0x30], xmm3
000078e5533d2f52  vmovaps [rsp+0x40], xmm4
000078e5533d2f58  vmovaps [rsp+0x50], xmm5
000078e5533d2f5e  vmovaps [rsp+0x60], xmm6
000078e5533d2f64  vmovaps [rsp+0x70], xmm7
000078e5533d2f6a  vmovaps [rsp+0x80], xmm8
000078e5533d2f73  vmovaps [rsp+0x90], xmm9
000078e5533d2f7c  vmovaps [rsp+0xA0], xmm10
000078e5533d2f85  vmovaps [rsp+0xB0], xmm11
000078e5533d2f8e  vmovaps [rsp+0xC0], xmm12
000078e5533d2f97  vmovaps [rsp+0xD0], xmm13
000078e5533d2fa0  vmovaps [rsp+0xE0], xmm14
000078e5533d2fa9  sub rsp, 0x30
000078e5533d2fad  movaps [rsp], xmm15
000078e5533d2fb2  movaps [rsp+0x10], xmm10
000078e5533d2fb8  movaps [rsp+0x20], xmm11
000078e5533d2fbe  lea rdi, [rsp]
000078e5533d2fc2  mov esi, 0x00
000078e5533d2fc7  mov rax, 0x5F83D5E17530
000078e5533d2fd1  call rax
000078e5533d2fd3  movaps xmm15, [rsp]
000078e5533d2fd8  add rsp, 0x30
000078e5533d2fdc  vmovaps xmm0, [rsp]
000078e5533d2fe1  vmovaps xmm1, [rsp+0x10]
000078e5533d2fe7  vmovaps xmm2, [rsp+0x20]
000078e5533d2fed  vmovaps xmm3, [rsp+0x30]
000078e5533d2ff3  vmovaps xmm4, [rsp+0x40]
000078e5533d2ff9  vmovaps xmm5, [rsp+0x50]
000078e5533d2fff  vmovaps xmm6, [rsp+0x60]
000078e5533d3005  vmovaps xmm7, [rsp+0x70]
000078e5533d300b  vmovaps xmm8, [rsp+0x80]
000078e5533d3014  vmovaps xmm9, [rsp+0x90]
000078e5533d301d  vmovaps xmm10, [rsp+0xA0]
000078e5533d3026  vmovaps xmm11, [rsp+0xB0]
000078e5533d302f  vmovaps xmm12, [rsp+0xC0]
000078e5533d3038  vmovaps xmm13, [rsp+0xD0]
000078e5533d3041  vmovaps xmm14, [rsp+0xE0]
000078e5533d304a  add rsp, 0xF0
000078e5533d3051  pop r11
000078e5533d3053  pop r10
000078e5533d3055  pop r9
000078e5533d3057  pop r8
000078e5533d3059  pop rsi
000078e5533d305a  pop rdi
000078e5533d305b  pop rdx
000078e5533d305c  pop rcx
000078e5533d305d  pop rax
000078e5533d305e  add rsp, 0x08
000078e5533d3062  jmp 0x000078E5533CFE57
000078e5533d3067  sub rsp, 0x08
000078e5533d306b  push rax
000078e5533d306c  push rcx
000078e5533d306d  push rdx
000078e5533d306e  push rdi
000078e5533d306f  push rsi
000078e5533d3070  push r8
000078e5533d3072  push r9
000078e5533d3074  push r10
000078e5533d3076  push r11
000078e5533d3078  sub rsp, 0xF0
000078e5533d307f  vmovaps [rsp], xmm0
000078e5533d3084  vmovaps [rsp+0x10], xmm1
000078e5533d308a  vmovaps [rsp+0x20], xmm2
000078e5533d3090  vmovaps [rsp+0x30], xmm3
000078e5533d3096  vmovaps [rsp+0x40], xmm4
000078e5533d309c  vmovaps [rsp+0x50], xmm5
000078e5533d30a2  vmovaps [rsp+0x60], xmm6
000078e5533d30a8  vmovaps [rsp+0x70], xmm7
000078e5533d30ae  vmovaps [rsp+0x80], xmm8
000078e5533d30b7  vmovaps [rsp+0x90], xmm9
000078e5533d30c0  vmovaps [rsp+0xA0], xmm11
000078e5533d30c9  vmovaps [rsp+0xB0], xmm12
000078e5533d30d2  vmovaps [rsp+0xC0], xmm13
000078e5533d30db  vmovaps [rsp+0xD0], xmm14
000078e5533d30e4  vmovaps [rsp+0xE0], xmm15
000078e5533d30ed  sub rsp, 0x30
000078e5533d30f1  movaps [rsp], xmm10
000078e5533d30f6  movaps [rsp+0x10], xmm12
000078e5533d30fc  movaps [rsp+0x20], xmm11
000078e5533d3102  lea rdi, [rsp]
000078e5533d3106  mov esi, 0x00
000078e5533d310b  mov rax, 0x5F83D5E17530
000078e5533d3115  call rax
000078e5533d3117  movaps xmm10, [rsp]
000078e5533d311c  add rsp, 0x30
000078e5533d3120  vmovaps xmm0, [rsp]
000078e5533d3125  vmovaps xmm1, [rsp+0x10]
000078e5533d312b  vmovaps xmm2, [rsp+0x20]
000078e5533d3131  vmovaps xmm3, [rsp+0x30]
000078e5533d3137  vmovaps xmm4, [rsp+0x40]
000078e5533d313d  vmovaps xmm5, [rsp+0x50]
000078e5533d3143  vmovaps xmm6, [rsp+0x60]
000078e5533d3149  vmovaps xmm7, [rsp+0x70]
000078e5533d314f  vmovaps xmm8, [rsp+0x80]
000078e5533d3158  vmovaps xmm9, [rsp+0x90]
000078e5533d3161  vmovaps xmm11, [rsp+0xA0]
000078e5533d316a  vmovaps xmm12, [rsp+0xB0]
000078e5533d3173  vmovaps xmm13, [rsp+0xC0]
000078e5533d317c  vmovaps xmm14, [rsp+0xD0]
000078e5533d3185  vmovaps xmm15, [rsp+0xE0]
000078e5533d318e  add rsp, 0xF0
000078e5533d3195  pop r11
000078e5533d3197  pop r10
000078e5533d3199  pop r9
000078e5533d319b  pop r8
000078e5533d319d  pop rsi
000078e5533d319e  pop rdi
000078e5533d319f  pop rdx
000078e5533d31a0  pop rcx
000078e5533d31a1  pop rax
000078e5533d31a2  add rsp, 0x08
000078e5533d31a6  jmp 0x000078E5533CFE80
000078e5533d31ab  sub rsp, 0x08
000078e5533d31af  push rax
000078e5533d31b0  push rcx
000078e5533d31b1  push rdx
000078e5533d31b2  push rdi
000078e5533d31b3  push rsi
000078e5533d31b4  push r8
000078e5533d31b6  push r9
000078e5533d31b8  push r10
000078e5533d31ba  push r11
000078e5533d31bc  sub rsp, 0xF0
000078e5533d31c3  vmovaps [rsp], xmm0
000078e5533d31c8  vmovaps [rsp+0x10], xmm1
000078e5533d31ce  vmovaps [rsp+0x20], xmm2
000078e5533d31d4  vmovaps [rsp+0x30], xmm3
000078e5533d31da  vmovaps [rsp+0x40], xmm4
000078e5533d31e0  vmovaps [rsp+0x50], xmm5
000078e5533d31e6  vmovaps [rsp+0x60], xmm6
000078e5533d31ec  vmovaps [rsp+0x70], xmm7
000078e5533d31f2  vmovaps [rsp+0x80], xmm8
000078e5533d31fb  vmovaps [rsp+0x90], xmm9
000078e5533d3204  vmovaps [rsp+0xA0], xmm10
000078e5533d320d  vmovaps [rsp+0xB0], xmm12
000078e5533d3216  vmovaps [rsp+0xC0], xmm13
000078e5533d321f  vmovaps [rsp+0xD0], xmm14
000078e5533d3228  vmovaps [rsp+0xE0], xmm15
000078e5533d3231  sub rsp, 0x30
000078e5533d3235  movaps [rsp], xmm11
000078e5533d323a  movaps [rsp+0x10], xmm2
000078e5533d323f  movaps [rsp+0x20], xmm12
000078e5533d3245  lea rdi, [rsp]
000078e5533d3249  mov esi, 0x00
000078e5533d324e  mov rax, 0x5F83D5E17530
000078e5533d3258  call rax
000078e5533d325a  movaps xmm11, [rsp]
000078e5533d325f  add rsp, 0x30
000078e5533d3263  vmovaps xmm0, [rsp]
000078e5533d3268  vmovaps xmm1, [rsp+0x10]
000078e5533d326e  vmovaps xmm2, [rsp+0x20]
000078e5533d3274  vmovaps xmm3, [rsp+0x30]
000078e5533d327a  vmovaps xmm4, [rsp+0x40]
000078e5533d3280  vmovaps xmm5, [rsp+0x50]
000078e5533d3286  vmovaps xmm6, [rsp+0x60]
000078e5533d328c  vmovaps xmm7, [rsp+0x70]
000078e5533d3292  vmovaps xmm8, [rsp+0x80]
000078e5533d329b  vmovaps xmm9, [rsp+0x90]
000078e5533d32a4  vmovaps xmm10, [rsp+0xA0]
000078e5533d32ad  vmovaps xmm12, [rsp+0xB0]
000078e5533d32b6  vmovaps xmm13, [rsp+0xC0]
000078e5533d32bf  vmovaps xmm14, [rsp+0xD0]
000078e5533d32c8  vmovaps xmm15, [rsp+0xE0]
000078e5533d32d1  add rsp, 0xF0
000078e5533d32d8  pop r11
000078e5533d32da  pop r10
000078e5533d32dc  pop r9
000078e5533d32de  pop r8
000078e5533d32e0  pop rsi
000078e5533d32e1  pop rdi
000078e5533d32e2  pop rdx
000078e5533d32e3  pop rcx
000078e5533d32e4  pop rax
000078e5533d32e5  add rsp, 0x08
000078e5533d32e9  jmp 0x000078E5533CFEB8
000078e5533d32ee  sub rsp, 0x08
000078e5533d32f2  push rax
000078e5533d32f3  push rcx
000078e5533d32f4  push rdx
000078e5533d32f5  push rdi
000078e5533d32f6  push rsi
000078e5533d32f7  push r8
000078e5533d32f9  push r9
000078e5533d32fb  push r10
000078e5533d32fd  push r11
000078e5533d32ff  sub rsp, 0xF0
000078e5533d3306  vmovaps [rsp], xmm0
000078e5533d330b  vmovaps [rsp+0x10], xmm2
000078e5533d3311  vmovaps [rsp+0x20], xmm3
000078e5533d3317  vmovaps [rsp+0x30], xmm4
000078e5533d331d  vmovaps [rsp+0x40], xmm5
000078e5533d3323  vmovaps [rsp+0x50], xmm6
000078e5533d3329  vmovaps [rsp+0x60], xmm7
000078e5533d332f  vmovaps [rsp+0x70], xmm8
000078e5533d3335  vmovaps [rsp+0x80], xmm9
000078e5533d333e  vmovaps [rsp+0x90], xmm10
000078e5533d3347  vmovaps [rsp+0xA0], xmm11
000078e5533d3350  vmovaps [rsp+0xB0], xmm12
000078e5533d3359  vmovaps [rsp+0xC0], xmm13
000078e5533d3362  vmovaps [rsp+0xD0], xmm14
000078e5533d336b  vmovaps [rsp+0xE0], xmm15
000078e5533d3374  sub rsp, 0x30
000078e5533d3378  movaps [rsp], xmm1
000078e5533d337c  movaps [rsp+0x10], xmm14
000078e5533d3382  movaps [rsp+0x20], xmm6
000078e5533d3387  lea rdi, [rsp]
000078e5533d338b  mov esi, 0x00
000078e5533d3390  mov rax, 0x5F83D5E17530
000078e5533d339a  call rax
000078e5533d339c  movaps xmm1, [rsp]
000078e5533d33a0  add rsp, 0x30
000078e5533d33a4  vmovaps xmm0, [rsp]
000078e5533d33a9  vmovaps xmm2, [rsp+0x10]
000078e5533d33af  vmovaps xmm3, [rsp+0x20]
000078e5533d33b5  vmovaps xmm4, [rsp+0x30]
000078e5533d33bb  vmovaps xmm5, [rsp+0x40]
000078e5533d33c1  vmovaps xmm6, [rsp+0x50]
000078e5533d33c7  vmovaps xmm7, [rsp+0x60]
000078e5533d33cd  vmovaps xmm8, [rsp+0x70]
000078e5533d33d3  vmovaps xmm9, [rsp+0x80]
000078e5533d33dc  vmovaps xmm10, [rsp+0x90]
000078e5533d33e5  vmovaps xmm11, [rsp+0xA0]
000078e5533d33ee  vmovaps xmm12, [rsp+0xB0]
000078e5533d33f7  vmovaps xmm13, [rsp+0xC0]
000078e5533d3400  vmovaps xmm14, [rsp+0xD0]
000078e5533d3409  vmovaps xmm15, [rsp+0xE0]
000078e5533d3412  add rsp, 0xF0
000078e5533d3419  pop r11
000078e5533d341b  pop r10
000078e5533d341d  pop r9
000078e5533d341f  pop r8
000078e5533d3421  pop rsi
000078e5533d3422  pop rdi
000078e5533d3423  pop rdx
000078e5533d3424  pop rcx
000078e5533d3425  pop rax
000078e5533d3426  add rsp, 0x08
000078e5533d342a  jmp 0x000078E5533CFED1
000078e5533d342f  sub rsp, 0x08
000078e5533d3433  push rax
000078e5533d3434  push rcx
000078e5533d3435  push rdx
000078e5533d3436  push rdi
000078e5533d3437  push rsi
000078e5533d3438  push r8
000078e5533d343a  push r9
000078e5533d343c  push r10
000078e5533d343e  push r11
000078e5533d3440  sub rsp, 0xF0
000078e5533d3447  vmovaps [rsp], xmm0
000078e5533d344c  vmovaps [rsp+0x10], xmm1
000078e5533d3452  vmovaps [rsp+0x20], xmm2
000078e5533d3458  vmovaps [rsp+0x30], xmm3
000078e5533d345e  vmovaps [rsp+0x40], xmm4
000078e5533d3464  vmovaps [rsp+0x50], xmm5
000078e5533d346a  vmovaps [rsp+0x60], xmm6
000078e5533d3470  vmovaps [rsp+0x70], xmm7
000078e5533d3476  vmovaps [rsp+0x80], xmm8
000078e5533d347f  vmovaps [rsp+0x90], xmm9
000078e5533d3488  vmovaps [rsp+0xA0], xmm10
000078e5533d3491  vmovaps [rsp+0xB0], xmm11
000078e5533d349a  vmovaps [rsp+0xC0], xmm12
000078e5533d34a3  vmovaps [rsp+0xD0], xmm13
000078e5533d34ac  vmovaps [rsp+0xE0], xmm15
000078e5533d34b5  sub rsp, 0x30
000078e5533d34b9  movaps [rsp], xmm14
000078e5533d34be  movaps [rsp+0x10], xmm12
000078e5533d34c4  movaps [rsp+0x20], xmm5
000078e5533d34c9  lea rdi, [rsp]
000078e5533d34cd  mov esi, 0x00
000078e5533d34d2  mov rax, 0x5F83D5E17530
000078e5533d34dc  call rax
000078e5533d34de  movaps xmm14, [rsp]
000078e5533d34e3  add rsp, 0x30
000078e5533d34e7  vmovaps xmm0, [rsp]
000078e5533d34ec  vmovaps xmm1, [rsp+0x10]
000078e5533d34f2  vmovaps xmm2, [rsp+0x20]
000078e5533d34f8  vmovaps xmm3, [rsp+0x30]
000078e5533d34fe  vmovaps xmm4, [rsp+0x40]
000078e5533d3504  vmovaps xmm5, [rsp+0x50]
000078e5533d350a  vmovaps xmm6, [rsp+0x60]
000078e5533d3510  vmovaps xmm7, [rsp+0x70]
000078e5533d3516  vmovaps xmm8, [rsp+0x80]
000078e5533d351f  vmovaps xmm9, [rsp+0x90]
000078e5533d3528  vmovaps xmm10, [rsp+0xA0]
000078e5533d3531  vmovaps xmm11, [rsp+0xB0]
000078e5533d353a  vmovaps xmm12, [rsp+0xC0]
000078e5533d3543  vmovaps xmm13, [rsp+0xD0]
000078e5533d354c  vmovaps xmm15, [rsp+0xE0]
000078e5533d3555  add rsp, 0xF0
000078e5533d355c  pop r11
000078e5533d355e  pop r10
000078e5533d3560  pop r9
000078e5533d3562  pop r8
000078e5533d3564  pop rsi
000078e5533d3565  pop rdi
000078e5533d3566  pop rdx
000078e5533d3567  pop rcx
000078e5533d3568  pop rax
000078e5533d3569  add rsp, 0x08
000078e5533d356d  jmp 0x000078E5533CFEF1
000078e5533d3572  sub rsp, 0x08
000078e5533d3576  push rax
000078e5533d3577  push rcx
000078e5533d3578  push rdx
000078e5533d3579  push rdi
000078e5533d357a  push rsi
000078e5533d357b  push r8
000078e5533d357d  push r9
000078e5533d357f  push r10
000078e5533d3581  push r11
000078e5533d3583  sub rsp, 0xF0
000078e5533d358a  vmovaps [rsp], xmm0
000078e5533d358f  vmovaps [rsp+0x10], xmm1
000078e5533d3595  vmovaps [rsp+0x20], xmm2
000078e5533d359b  vmovaps [rsp+0x30], xmm3
000078e5533d35a1  vmovaps [rsp+0x40], xmm4
000078e5533d35a7  vmovaps [rsp+0x50], xmm5
000078e5533d35ad  vmovaps [rsp+0x60], xmm7
000078e5533d35b3  vmovaps [rsp+0x70], xmm8
000078e5533d35b9  vmovaps [rsp+0x80], xmm9
000078e5533d35c2  vmovaps [rsp+0x90], xmm10
000078e5533d35cb  vmovaps [rsp+0xA0], xmm11
000078e5533d35d4  vmovaps [rsp+0xB0], xmm12
000078e5533d35dd  vmovaps [rsp+0xC0], xmm13
000078e5533d35e6  vmovaps [rsp+0xD0], xmm14
000078e5533d35ef  vmovaps [rsp+0xE0], xmm15
000078e5533d35f8  sub rsp, 0x30
000078e5533d35fc  movaps [rsp], xmm6
000078e5533d3600  movaps [rsp+0x10], xmm9
000078e5533d3606  movaps [rsp+0x20], xmm12
000078e5533d360c  lea rdi, [rsp]
000078e5533d3610  mov esi, 0x00
000078e5533d3615  mov rax, 0x5F83D5E17530
000078e5533d361f  call rax
000078e5533d3621  movaps xmm6, [rsp]
000078e5533d3625  add rsp, 0x30
000078e5533d3629  vmovaps xmm0, [rsp]
000078e5533d362e  vmovaps xmm1, [rsp+0x10]
000078e5533d3634  vmovaps xmm2, [rsp+0x20]
000078e5533d363a  vmovaps xmm3, [rsp+0x30]
000078e5533d3640  vmovaps xmm4, [rsp+0x40]
000078e5533d3646  vmovaps xmm5, [rsp+0x50]
000078e5533d364c  vmovaps xmm7, [rsp+0x60]
000078e5533d3652  vmovaps xmm8, [rsp+0x70]
000078e5533d3658  vmovaps xmm9, [rsp+0x80]
000078e5533d3661  vmovaps xmm10, [rsp+0x90]
000078e5533d366a  vmovaps xmm11, [rsp+0xA0]
000078e5533d3673  vmovaps xmm12, [rsp+0xB0]
000078e5533d367c  vmovaps xmm13, [rsp+0xC0]
000078e5533d3685  vmovaps xmm14, [rsp+0xD0]
000078e5533d368e  vmovaps xmm15, [rsp+0xE0]
000078e5533d3697  add rsp, 0xF0
000078e5533d369e  pop r11
000078e5533d36a0  pop r10
000078e5533d36a2  pop r9
000078e5533d36a4  pop r8
000078e5533d36a6  pop rsi
000078e5533d36a7  pop rdi
000078e5533d36a8  pop rdx
000078e5533d36a9  pop rcx
000078e5533d36aa  pop rax
000078e5533d36ab  add rsp, 0x08
000078e5533d36af  jmp 0x000078E5533CFF19
000078e5533d36b4  sub rsp, 0x08
000078e5533d36b8  push rax
000078e5533d36b9  push rcx
000078e5533d36ba  push rdx
000078e5533d36bb  push rdi
000078e5533d36bc  push rsi
000078e5533d36bd  push r8
000078e5533d36bf  push r9
000078e5533d36c1  push r10
000078e5533d36c3  push r11
000078e5533d36c5  sub rsp, 0xF0
000078e5533d36cc  vmovaps [rsp], xmm0
000078e5533d36d1  vmovaps [rsp+0x10], xmm1
000078e5533d36d7  vmovaps [rsp+0x20], xmm2
000078e5533d36dd  vmovaps [rsp+0x30], xmm3
000078e5533d36e3  vmovaps [rsp+0x40], xmm4
000078e5533d36e9  vmovaps [rsp+0x50], xmm5
000078e5533d36ef  vmovaps [rsp+0x60], xmm6
000078e5533d36f5  vmovaps [rsp+0x70], xmm7
000078e5533d36fb  vmovaps [rsp+0x80], xmm8
000078e5533d3704  vmovaps [rsp+0x90], xmm9
000078e5533d370d  vmovaps [rsp+0xA0], xmm10
000078e5533d3716  vmovaps [rsp+0xB0], xmm11
000078e5533d371f  vmovaps [rsp+0xC0], xmm13
000078e5533d3728  vmovaps [rsp+0xD0], xmm14
000078e5533d3731  vmovaps [rsp+0xE0], xmm15
000078e5533d373a  sub rsp, 0x30
000078e5533d373e  movaps [rsp], xmm12
000078e5533d3743  movaps [rsp+0x10], xmm15
000078e5533d3749  movaps [rsp+0x20], xmm13
000078e5533d374f  lea rdi, [rsp]
000078e5533d3753  mov esi, 0x00
000078e5533d3758  mov rax, 0x5F83D5E17530
000078e5533d3762  call rax
000078e5533d3764  movaps xmm12, [rsp]
000078e5533d3769  add rsp, 0x30
000078e5533d376d  vmovaps xmm0, [rsp]
000078e5533d3772  vmovaps xmm1, [rsp+0x10]
000078e5533d3778  vmovaps xmm2, [rsp+0x20]
000078e5533d377e  vmovaps xmm3, [rsp+0x30]
000078e5533d3784  vmovaps xmm4, [rsp+0x40]
000078e5533d378a  vmovaps xmm5, [rsp+0x50]
000078e5533d3790  vmovaps xmm6, [rsp+0x60]
000078e5533d3796  vmovaps xmm7, [rsp+0x70]
000078e5533d379c  vmovaps xmm8, [rsp+0x80]
000078e5533d37a5  vmovaps xmm9, [rsp+0x90]
000078e5533d37ae  vmovaps xmm10, [rsp+0xA0]
000078e5533d37b7  vmovaps xmm11, [rsp+0xB0]
000078e5533d37c0  vmovaps xmm13, [rsp+0xC0]
000078e5533d37c9  vmovaps xmm14, [rsp+0xD0]
000078e5533d37d2  vmovaps xmm15, [rsp+0xE0]
000078e5533d37db  add rsp, 0xF0
000078e5533d37e2  pop r11
000078e5533d37e4  pop r10
000078e5533d37e6  pop r9
000078e5533d37e8  pop r8
000078e5533d37ea  pop rsi
000078e5533d37eb  pop rdi
000078e5533d37ec  pop rdx
000078e5533d37ed  pop rcx
000078e5533d37ee  pop rax
000078e5533d37ef  add rsp, 0x08
000078e5533d37f3  jmp 0x000078E5533CFF34
000078e5533d37f8  sub rsp, 0x08
000078e5533d37fc  push rax
000078e5533d37fd  push rcx
000078e5533d37fe  push rdx
000078e5533d37ff  push rdi
000078e5533d3800  push rsi
000078e5533d3801  push r8
000078e5533d3803  push r9
000078e5533d3805  push r10
000078e5533d3807  push r11
000078e5533d3809  sub rsp, 0xF0
000078e5533d3810  vmovaps [rsp], xmm0
000078e5533d3815  vmovaps [rsp+0x10], xmm1
000078e5533d381b  vmovaps [rsp+0x20], xmm2
000078e5533d3821  vmovaps [rsp+0x30], xmm3
000078e5533d3827  vmovaps [rsp+0x40], xmm4
000078e5533d382d  vmovaps [rsp+0x50], xmm5
000078e5533d3833  vmovaps [rsp+0x60], xmm6
000078e5533d3839  vmovaps [rsp+0x70], xmm7
000078e5533d383f  vmovaps [rsp+0x80], xmm8
000078e5533d3848  vmovaps [rsp+0x90], xmm9
000078e5533d3851  vmovaps [rsp+0xA0], xmm10
000078e5533d385a  vmovaps [rsp+0xB0], xmm11
000078e5533d3863  vmovaps [rsp+0xC0], xmm12
000078e5533d386c  vmovaps [rsp+0xD0], xmm13
000078e5533d3875  vmovaps [rsp+0xE0], xmm14
000078e5533d387e  sub rsp, 0x30
000078e5533d3882  movaps [rsp], xmm15
000078e5533d3887  movaps [rsp+0x10], xmm13
000078e5533d388d  movaps [rsp+0x20], xmm10
000078e5533d3893  lea rdi, [rsp]
000078e5533d3897  mov esi, 0x00
000078e5533d389c  mov rax, 0x5F83D5E17530
000078e5533d38a6  call rax
000078e5533d38a8  movaps xmm15, [rsp]
000078e5533d38ad  add rsp, 0x30
000078e5533d38b1  vmovaps xmm0, [rsp]
000078e5533d38b6  vmovaps xmm1, [rsp+0x10]
000078e5533d38bc  vmovaps xmm2, [rsp+0x20]
000078e5533d38c2  vmovaps xmm3, [rsp+0x30]
000078e5533d38c8  vmovaps xmm4, [rsp+0x40]
000078e5533d38ce  vmovaps xmm5, [rsp+0x50]
000078e5533d38d4  vmovaps xmm6, [rsp+0x60]
000078e5533d38da  vmovaps xmm7, [rsp+0x70]
000078e5533d38e0  vmovaps xmm8, [rsp+0x80]
000078e5533d38e9  vmovaps xmm9, [rsp+0x90]
000078e5533d38f2  vmovaps xmm10, [rsp+0xA0]
000078e5533d38fb  vmovaps xmm11, [rsp+0xB0]
000078e5533d3904  vmovaps xmm12, [rsp+0xC0]
000078e5533d390d  vmovaps xmm13, [rsp+0xD0]
000078e5533d3916  vmovaps xmm14, [rsp+0xE0]
000078e5533d391f  add rsp, 0xF0
000078e5533d3926  pop r11
000078e5533d3928  pop r10
000078e5533d392a  pop r9
000078e5533d392c  pop r8
000078e5533d392e  pop rsi
000078e5533d392f  pop rdi
000078e5533d3930  pop rdx
000078e5533d3931  pop rcx
000078e5533d3932  pop rax
000078e5533d3933  add rsp, 0x08
000078e5533d3937  jmp 0x000078E5533CFF55
000078e5533d393c  call 0x000078E55320C260
000078e5533d3941  jmp 0x000078E5533CFFB0
000078e5533d3946  sub rsp, 0x08
000078e5533d394a  push rax
000078e5533d394b  push rcx
000078e5533d394c  push rdx
000078e5533d394d  push rdi
000078e5533d394e  push rsi
000078e5533d394f  push r8
000078e5533d3951  push r9
000078e5533d3953  push r10
000078e5533d3955  push r11
000078e5533d3957  sub rsp, 0xF0
000078e5533d395e  vmovaps [rsp], xmm0
000078e5533d3963  vmovaps [rsp+0x10], xmm1
000078e5533d3969  vmovaps [rsp+0x20], xmm2
000078e5533d396f  vmovaps [rsp+0x30], xmm3
000078e5533d3975  vmovaps [rsp+0x40], xmm4
000078e5533d397b  vmovaps [rsp+0x50], xmm5
000078e5533d3981  vmovaps [rsp+0x60], xmm6
000078e5533d3987  vmovaps [rsp+0x70], xmm7
000078e5533d398d  vmovaps [rsp+0x80], xmm8
000078e5533d3996  vmovaps [rsp+0x90], xmm10
000078e5533d399f  vmovaps [rsp+0xA0], xmm11
000078e5533d39a8  vmovaps [rsp+0xB0], xmm12
000078e5533d39b1  vmovaps [rsp+0xC0], xmm13
000078e5533d39ba  vmovaps [rsp+0xD0], xmm14
000078e5533d39c3  vmovaps [rsp+0xE0], xmm15
000078e5533d39cc  sub rsp, 0x30
000078e5533d39d0  movaps [rsp], xmm9
000078e5533d39d5  movaps [rsp+0x10], xmm8
000078e5533d39db  movaps [rsp+0x20], xmm10
000078e5533d39e1  lea rdi, [rsp]
000078e5533d39e5  mov esi, 0x00
000078e5533d39ea  mov rax, 0x5F83D5E17530
000078e5533d39f4  call rax
000078e5533d39f6  movaps xmm9, [rsp]
000078e5533d39fb  add rsp, 0x30
000078e5533d39ff  vmovaps xmm0, [rsp]
000078e5533d3a04  vmovaps xmm1, [rsp+0x10]
000078e5533d3a0a  vmovaps xmm2, [rsp+0x20]
000078e5533d3a10  vmovaps xmm3, [rsp+0x30]
000078e5533d3a16  vmovaps xmm4, [rsp+0x40]
000078e5533d3a1c  vmovaps xmm5, [rsp+0x50]
000078e5533d3a22  vmovaps xmm6, [rsp+0x60]
000078e5533d3a28  vmovaps xmm7, [rsp+0x70]
000078e5533d3a2e  vmovaps xmm8, [rsp+0x80]
000078e5533d3a37  vmovaps xmm10, [rsp+0x90]
000078e5533d3a40  vmovaps xmm11, [rsp+0xA0]
000078e5533d3a49  vmovaps xmm12, [rsp+0xB0]
000078e5533d3a52  vmovaps xmm13, [rsp+0xC0]
000078e5533d3a5b  vmovaps xmm14, [rsp+0xD0]
000078e5533d3a64  vmovaps xmm15, [rsp+0xE0]
000078e5533d3a6d  add rsp, 0xF0
000078e5533d3a74  pop r11
000078e5533d3a76  pop r10
000078e5533d3a78  pop r9
000078e5533d3a7a  pop r8
000078e5533d3a7c  pop rsi
000078e5533d3a7d  pop rdi
000078e5533d3a7e  pop rdx
000078e5533d3a7f  pop rcx
000078e5533d3a80  pop rax
000078e5533d3a81  add rsp, 0x08
000078e5533d3a85  jmp 0x000078E5533CFFE1
000078e5533d3a8a  sub rsp, 0x08
000078e5533d3a8e  push rax
000078e5533d3a8f  push rcx
000078e5533d3a90  push rdx
000078e5533d3a91  push rdi
000078e5533d3a92  push rsi
000078e5533d3a93  push r8
000078e5533d3a95  push r9
000078e5533d3a97  push r10
000078e5533d3a99  push r11
000078e5533d3a9b  sub rsp, 0xF0
000078e5533d3aa2  vmovaps [rsp], xmm0
000078e5533d3aa7  vmovaps [rsp+0x10], xmm1
000078e5533d3aad  vmovaps [rsp+0x20], xmm2
000078e5533d3ab3  vmovaps [rsp+0x30], xmm3
000078e5533d3ab9  vmovaps [rsp+0x40], xmm4
000078e5533d3abf  vmovaps [rsp+0x50], xmm5
000078e5533d3ac5  vmovaps [rsp+0x60], xmm6
000078e5533d3acb  vmovaps [rsp+0x70], xmm7
000078e5533d3ad1  vmovaps [rsp+0x80], xmm8
000078e5533d3ada  vmovaps [rsp+0x90], xmm9
000078e5533d3ae3  vmovaps [rsp+0xA0], xmm11
000078e5533d3aec  vmovaps [rsp+0xB0], xmm12
000078e5533d3af5  vmovaps [rsp+0xC0], xmm13
000078e5533d3afe  vmovaps [rsp+0xD0], xmm14
000078e5533d3b07  vmovaps [rsp+0xE0], xmm15
000078e5533d3b10  sub rsp, 0x30
000078e5533d3b14  movaps [rsp], xmm10
000078e5533d3b19  movaps [rsp+0x10], xmm1
000078e5533d3b1e  movaps [rsp+0x20], xmm11
000078e5533d3b24  lea rdi, [rsp]
000078e5533d3b28  mov esi, 0x00
000078e5533d3b2d  mov rax, 0x5F83D5E17530
000078e5533d3b37  call rax
000078e5533d3b39  movaps xmm10, [rsp]
000078e5533d3b3e  add rsp, 0x30
000078e5533d3b42  vmovaps xmm0, [rsp]
000078e5533d3b47  vmovaps xmm1, [rsp+0x10]
000078e5533d3b4d  vmovaps xmm2, [rsp+0x20]
000078e5533d3b53  vmovaps xmm3, [rsp+0x30]
000078e5533d3b59  vmovaps xmm4, [rsp+0x40]
000078e5533d3b5f  vmovaps xmm5, [rsp+0x50]
000078e5533d3b65  vmovaps xmm6, [rsp+0x60]
000078e5533d3b6b  vmovaps xmm7, [rsp+0x70]
000078e5533d3b71  vmovaps xmm8, [rsp+0x80]
000078e5533d3b7a  vmovaps xmm9, [rsp+0x90]
000078e5533d3b83  vmovaps xmm11, [rsp+0xA0]
000078e5533d3b8c  vmovaps xmm12, [rsp+0xB0]
000078e5533d3b95  vmovaps xmm13, [rsp+0xC0]
000078e5533d3b9e  vmovaps xmm14, [rsp+0xD0]
000078e5533d3ba7  vmovaps xmm15, [rsp+0xE0]
000078e5533d3bb0  add rsp, 0xF0
000078e5533d3bb7  pop r11
000078e5533d3bb9  pop r10
000078e5533d3bbb  pop r9
000078e5533d3bbd  pop r8
000078e5533d3bbf  pop rsi
000078e5533d3bc0  pop rdi
000078e5533d3bc1  pop rdx
000078e5533d3bc2  pop rcx
000078e5533d3bc3  pop rax
000078e5533d3bc4  add rsp, 0x08
000078e5533d3bc8  jmp 0x000078E5533CFFFC
000078e5533d3bcd  sub rsp, 0x08
000078e5533d3bd1  push rax
000078e5533d3bd2  push rcx
000078e5533d3bd3  push rdx
000078e5533d3bd4  push rdi
000078e5533d3bd5  push rsi
000078e5533d3bd6  push r8
000078e5533d3bd8  push r9
000078e5533d3bda  push r10
000078e5533d3bdc  push r11
000078e5533d3bde  sub rsp, 0xF0
000078e5533d3be5  vmovaps [rsp], xmm0
000078e5533d3bea  vmovaps [rsp+0x10], xmm2
000078e5533d3bf0  vmovaps [rsp+0x20], xmm3
000078e5533d3bf6  vmovaps [rsp+0x30], xmm4
000078e5533d3bfc  vmovaps [rsp+0x40], xmm5
000078e5533d3c02  vmovaps [rsp+0x50], xmm6
000078e5533d3c08  vmovaps [rsp+0x60], xmm7
000078e5533d3c0e  vmovaps [rsp+0x70], xmm8
000078e5533d3c14  vmovaps [rsp+0x80], xmm9
000078e5533d3c1d  vmovaps [rsp+0x90], xmm10
000078e5533d3c26  vmovaps [rsp+0xA0], xmm11
000078e5533d3c2f  vmovaps [rsp+0xB0], xmm12
000078e5533d3c38  vmovaps [rsp+0xC0], xmm13
000078e5533d3c41  vmovaps [rsp+0xD0], xmm14
000078e5533d3c4a  vmovaps [rsp+0xE0], xmm15
000078e5533d3c53  sub rsp, 0x30
000078e5533d3c57  movaps [rsp], xmm1
000078e5533d3c5b  movaps [rsp+0x10], xmm14
000078e5533d3c61  movaps [rsp+0x20], xmm6
000078e5533d3c66  lea rdi, [rsp]
000078e5533d3c6a  mov esi, 0x00
000078e5533d3c6f  mov rax, 0x5F83D5E17530
000078e5533d3c79  call rax
000078e5533d3c7b  movaps xmm1, [rsp]
000078e5533d3c7f  add rsp, 0x30
000078e5533d3c83  vmovaps xmm0, [rsp]
000078e5533d3c88  vmovaps xmm2, [rsp+0x10]
000078e5533d3c8e  vmovaps xmm3, [rsp+0x20]
000078e5533d3c94  vmovaps xmm4, [rsp+0x30]
000078e5533d3c9a  vmovaps xmm5, [rsp+0x40]
000078e5533d3ca0  vmovaps xmm6, [rsp+0x50]
000078e5533d3ca6  vmovaps xmm7, [rsp+0x60]
000078e5533d3cac  vmovaps xmm8, [rsp+0x70]
000078e5533d3cb2  vmovaps xmm9, [rsp+0x80]
000078e5533d3cbb  vmovaps xmm10, [rsp+0x90]
000078e5533d3cc4  vmovaps xmm11, [rsp+0xA0]
000078e5533d3ccd  vmovaps xmm12, [rsp+0xB0]
000078e5533d3cd6  vmovaps xmm13, [rsp+0xC0]
000078e5533d3cdf  vmovaps xmm14, [rsp+0xD0]
000078e5533d3ce8  vmovaps xmm15, [rsp+0xE0]
000078e5533d3cf1  add rsp, 0xF0
000078e5533d3cf8  pop r11
000078e5533d3cfa  pop r10
000078e5533d3cfc  pop r9
000078e5533d3cfe  pop r8
000078e5533d3d00  pop rsi
000078e5533d3d01  pop rdi
000078e5533d3d02  pop rdx
000078e5533d3d03  pop rcx
000078e5533d3d04  pop rax
000078e5533d3d05  add rsp, 0x08
000078e5533d3d09  jmp 0x000078E5533D0015
000078e5533d3d0e  sub rsp, 0x08
000078e5533d3d12  push rax
000078e5533d3d13  push rcx
000078e5533d3d14  push rdx
000078e5533d3d15  push rdi
000078e5533d3d16  push rsi
000078e5533d3d17  push r8
000078e5533d3d19  push r9
000078e5533d3d1b  push r10
000078e5533d3d1d  push r11
000078e5533d3d1f  sub rsp, 0xF0
000078e5533d3d26  vmovaps [rsp], xmm0
000078e5533d3d2b  vmovaps [rsp+0x10], xmm1
000078e5533d3d31  vmovaps [rsp+0x20], xmm2
000078e5533d3d37  vmovaps [rsp+0x30], xmm3
000078e5533d3d3d  vmovaps [rsp+0x40], xmm4
000078e5533d3d43  vmovaps [rsp+0x50], xmm5
000078e5533d3d49  vmovaps [rsp+0x60], xmm6
000078e5533d3d4f  vmovaps [rsp+0x70], xmm7
000078e5533d3d55  vmovaps [rsp+0x80], xmm8
000078e5533d3d5e  vmovaps [rsp+0x90], xmm9
000078e5533d3d67  vmovaps [rsp+0xA0], xmm10
000078e5533d3d70  vmovaps [rsp+0xB0], xmm12
000078e5533d3d79  vmovaps [rsp+0xC0], xmm13
000078e5533d3d82  vmovaps [rsp+0xD0], xmm14
000078e5533d3d8b  vmovaps [rsp+0xE0], xmm15
000078e5533d3d94  sub rsp, 0x30
000078e5533d3d98  movaps [rsp], xmm11
000078e5533d3d9d  movaps [rsp+0x10], xmm13
000078e5533d3da3  movaps [rsp+0x20], xmm14
000078e5533d3da9  lea rdi, [rsp]
000078e5533d3dad  mov esi, 0x00
000078e5533d3db2  mov rax, 0x5F83D5E17530
000078e5533d3dbc  call rax
000078e5533d3dbe  movaps xmm11, [rsp]
000078e5533d3dc3  add rsp, 0x30
000078e5533d3dc7  vmovaps xmm0, [rsp]
000078e5533d3dcc  vmovaps xmm1, [rsp+0x10]
000078e5533d3dd2  vmovaps xmm2, [rsp+0x20]
000078e5533d3dd8  vmovaps xmm3, [rsp+0x30]
000078e5533d3dde  vmovaps xmm4, [rsp+0x40]
000078e5533d3de4  vmovaps xmm5, [rsp+0x50]
000078e5533d3dea  vmovaps xmm6, [rsp+0x60]
000078e5533d3df0  vmovaps xmm7, [rsp+0x70]
000078e5533d3df6  vmovaps xmm8, [rsp+0x80]
000078e5533d3dff  vmovaps xmm9, [rsp+0x90]
000078e5533d3e08  vmovaps xmm10, [rsp+0xA0]
000078e5533d3e11  vmovaps xmm12, [rsp+0xB0]
000078e5533d3e1a  vmovaps xmm13, [rsp+0xC0]
000078e5533d3e23  vmovaps xmm14, [rsp+0xD0]
000078e5533d3e2c  vmovaps xmm15, [rsp+0xE0]
000078e5533d3e35  add rsp, 0xF0
000078e5533d3e3c  pop r11
000078e5533d3e3e  pop r10
000078e5533d3e40  pop r9
000078e5533d3e42  pop r8
000078e5533d3e44  pop rsi
000078e5533d3e45  pop rdi
000078e5533d3e46  pop rdx
000078e5533d3e47  pop rcx
000078e5533d3e48  pop rax
000078e5533d3e49  add rsp, 0x08
000078e5533d3e4d  jmp 0x000078E5533D003F
000078e5533d3e52  sub rsp, 0x08
000078e5533d3e56  push rax
000078e5533d3e57  push rcx
000078e5533d3e58  push rdx
000078e5533d3e59  push rdi
000078e5533d3e5a  push rsi
000078e5533d3e5b  push r8
000078e5533d3e5d  push r9
000078e5533d3e5f  push r10
000078e5533d3e61  push r11
000078e5533d3e63  sub rsp, 0xF0
000078e5533d3e6a  vmovaps [rsp], xmm0
000078e5533d3e6f  vmovaps [rsp+0x10], xmm1
000078e5533d3e75  vmovaps [rsp+0x20], xmm2
000078e5533d3e7b  vmovaps [rsp+0x30], xmm3
000078e5533d3e81  vmovaps [rsp+0x40], xmm4
000078e5533d3e87  vmovaps [rsp+0x50], xmm5
000078e5533d3e8d  vmovaps [rsp+0x60], xmm6
000078e5533d3e93  vmovaps [rsp+0x70], xmm7
000078e5533d3e99  vmovaps [rsp+0x80], xmm8
000078e5533d3ea2  vmovaps [rsp+0x90], xmm9
000078e5533d3eab  vmovaps [rsp+0xA0], xmm10
000078e5533d3eb4  vmovaps [rsp+0xB0], xmm11
000078e5533d3ebd  vmovaps [rsp+0xC0], xmm12
000078e5533d3ec6  vmovaps [rsp+0xD0], xmm14
000078e5533d3ecf  vmovaps [rsp+0xE0], xmm15
000078e5533d3ed8  sub rsp, 0x30
000078e5533d3edc  movaps [rsp], xmm13
000078e5533d3ee1  movaps [rsp+0x10], xmm8
000078e5533d3ee7  movaps [rsp+0x20], xmm14
000078e5533d3eed  lea rdi, [rsp]
000078e5533d3ef1  mov esi, 0x00
000078e5533d3ef6  mov rax, 0x5F83D5E17530
000078e5533d3f00  call rax
000078e5533d3f02  movaps xmm13, [rsp]
000078e5533d3f07  add rsp, 0x30
000078e5533d3f0b  vmovaps xmm0, [rsp]
000078e5533d3f10  vmovaps xmm1, [rsp+0x10]
000078e5533d3f16  vmovaps xmm2, [rsp+0x20]
000078e5533d3f1c  vmovaps xmm3, [rsp+0x30]
000078e5533d3f22  vmovaps xmm4, [rsp+0x40]
000078e5533d3f28  vmovaps xmm5, [rsp+0x50]
000078e5533d3f2e  vmovaps xmm6, [rsp+0x60]
000078e5533d3f34  vmovaps xmm7, [rsp+0x70]
000078e5533d3f3a  vmovaps xmm8, [rsp+0x80]
000078e5533d3f43  vmovaps xmm9, [rsp+0x90]
000078e5533d3f4c  vmovaps xmm10, [rsp+0xA0]
000078e5533d3f55  vmovaps xmm11, [rsp+0xB0]
000078e5533d3f5e  vmovaps xmm12, [rsp+0xC0]
000078e5533d3f67  vmovaps xmm14, [rsp+0xD0]
000078e5533d3f70  vmovaps xmm15, [rsp+0xE0]
000078e5533d3f79  add rsp, 0xF0
000078e5533d3f80  pop r11
000078e5533d3f82  pop r10
000078e5533d3f84  pop r9
000078e5533d3f86  pop r8
000078e5533d3f88  pop rsi
000078e5533d3f89  pop rdi
000078e5533d3f8a  pop rdx
000078e5533d3f8b  pop rcx
000078e5533d3f8c  pop rax
000078e5533d3f8d  add rsp, 0x08
000078e5533d3f91  jmp 0x000078E5533D006E
000078e5533d3f96  sub rsp, 0x08
000078e5533d3f9a  push rax
000078e5533d3f9b  push rcx
000078e5533d3f9c  push rdx
000078e5533d3f9d  push rdi
000078e5533d3f9e  push rsi
000078e5533d3f9f  push r8
000078e5533d3fa1  push r9
000078e5533d3fa3  push r10
000078e5533d3fa5  push r11
000078e5533d3fa7  sub rsp, 0xF0
000078e5533d3fae  vmovaps [rsp], xmm0
000078e5533d3fb3  vmovaps [rsp+0x10], xmm1
000078e5533d3fb9  vmovaps [rsp+0x20], xmm2
000078e5533d3fbf  vmovaps [rsp+0x30], xmm3
000078e5533d3fc5  vmovaps [rsp+0x40], xmm4
000078e5533d3fcb  vmovaps [rsp+0x50], xmm5
000078e5533d3fd1  vmovaps [rsp+0x60], xmm6
000078e5533d3fd7  vmovaps [rsp+0x70], xmm7
000078e5533d3fdd  vmovaps [rsp+0x80], xmm9
000078e5533d3fe6  vmovaps [rsp+0x90], xmm10
000078e5533d3fef  vmovaps [rsp+0xA0], xmm11
000078e5533d3ff8  vmovaps [rsp+0xB0], xmm12
000078e5533d4001  vmovaps [rsp+0xC0], xmm13
000078e5533d400a  vmovaps [rsp+0xD0], xmm14
000078e5533d4013  vmovaps [rsp+0xE0], xmm15
000078e5533d401c  sub rsp, 0x30
000078e5533d4020  movaps [rsp], xmm8
000078e5533d4025  movaps [rsp+0x10], xmm7
000078e5533d402a  movaps [rsp+0x20], xmm14
000078e5533d4030  lea rdi, [rsp]
000078e5533d4034  mov esi, 0x00
000078e5533d4039  mov rax, 0x5F83D5E17530
000078e5533d4043  call rax
000078e5533d4045  movaps xmm8, [rsp]
000078e5533d404a  add rsp, 0x30
000078e5533d404e  vmovaps xmm0, [rsp]
000078e5533d4053  vmovaps xmm1, [rsp+0x10]
000078e5533d4059  vmovaps xmm2, [rsp+0x20]
000078e5533d405f  vmovaps xmm3, [rsp+0x30]
000078e5533d4065  vmovaps xmm4, [rsp+0x40]
000078e5533d406b  vmovaps xmm5, [rsp+0x50]
000078e5533d4071  vmovaps xmm6, [rsp+0x60]
000078e5533d4077  vmovaps xmm7, [rsp+0x70]
000078e5533d407d  vmovaps xmm9, [rsp+0x80]
000078e5533d4086  vmovaps xmm10, [rsp+0x90]
000078e5533d408f  vmovaps xmm11, [rsp+0xA0]
000078e5533d4098  vmovaps xmm12, [rsp+0xB0]
000078e5533d40a1  vmovaps xmm13, [rsp+0xC0]
000078e5533d40aa  vmovaps xmm14, [rsp+0xD0]
000078e5533d40b3  vmovaps xmm15, [rsp+0xE0]
000078e5533d40bc  add rsp, 0xF0
000078e5533d40c3  pop r11
000078e5533d40c5  pop r10
000078e5533d40c7  pop r9
000078e5533d40c9  pop r8
000078e5533d40cb  pop rsi
000078e5533d40cc  pop rdi
000078e5533d40cd  pop rdx
000078e5533d40ce  pop rcx
000078e5533d40cf  pop rax
000078e5533d40d0  add rsp, 0x08
000078e5533d40d4  jmp 0x000078E5533D0094
000078e5533d40d9  sub rsp, 0x08
000078e5533d40dd  push rax
000078e5533d40de  push rcx
000078e5533d40df  push rdx
000078e5533d40e0  push rdi
000078e5533d40e1  push rsi
000078e5533d40e2  push r8
000078e5533d40e4  push r9
000078e5533d40e6  push r10
000078e5533d40e8  push r11
000078e5533d40ea  sub rsp, 0xF0
000078e5533d40f1  vmovaps [rsp], xmm0
000078e5533d40f6  vmovaps [rsp+0x10], xmm1
000078e5533d40fc  vmovaps [rsp+0x20], xmm2
000078e5533d4102  vmovaps [rsp+0x30], xmm3
000078e5533d4108  vmovaps [rsp+0x40], xmm4
000078e5533d410e  vmovaps [rsp+0x50], xmm5
000078e5533d4114  vmovaps [rsp+0x60], xmm6
000078e5533d411a  vmovaps [rsp+0x70], xmm7
000078e5533d4120  vmovaps [rsp+0x80], xmm8
000078e5533d4129  vmovaps [rsp+0x90], xmm9
000078e5533d4132  vmovaps [rsp+0xA0], xmm10
000078e5533d413b  vmovaps [rsp+0xB0], xmm11
000078e5533d4144  vmovaps [rsp+0xC0], xmm12
000078e5533d414d  vmovaps [rsp+0xD0], xmm13
000078e5533d4156  vmovaps [rsp+0xE0], xmm15
000078e5533d415f  sub rsp, 0x30
000078e5533d4163  movaps [rsp], xmm14
000078e5533d4168  movaps [rsp+0x10], xmm12
000078e5533d416e  movaps [rsp+0x20], xmm9
000078e5533d4174  lea rdi, [rsp]
000078e5533d4178  mov esi, 0x00
000078e5533d417d  mov rax, 0x5F83D5E17530
000078e5533d4187  call rax
000078e5533d4189  movaps xmm14, [rsp]
000078e5533d418e  add rsp, 0x30
000078e5533d4192  vmovaps xmm0, [rsp]
000078e5533d4197  vmovaps xmm1, [rsp+0x10]
000078e5533d419d  vmovaps xmm2, [rsp+0x20]
000078e5533d41a3  vmovaps xmm3, [rsp+0x30]
000078e5533d41a9  vmovaps xmm4, [rsp+0x40]
000078e5533d41af  vmovaps xmm5, [rsp+0x50]
000078e5533d41b5  vmovaps xmm6, [rsp+0x60]
000078e5533d41bb  vmovaps xmm7, [rsp+0x70]
000078e5533d41c1  vmovaps xmm8, [rsp+0x80]
000078e5533d41ca  vmovaps xmm9, [rsp+0x90]
000078e5533d41d3  vmovaps xmm10, [rsp+0xA0]
000078e5533d41dc  vmovaps xmm11, [rsp+0xB0]
000078e5533d41e5  vmovaps xmm12, [rsp+0xC0]
000078e5533d41ee  vmovaps xmm13, [rsp+0xD0]
000078e5533d41f7  vmovaps xmm15, [rsp+0xE0]
000078e5533d4200  add rsp, 0xF0
000078e5533d4207  pop r11
000078e5533d4209  pop r10
000078e5533d420b  pop r9
000078e5533d420d  pop r8
000078e5533d420f  pop rsi
000078e5533d4210  pop rdi
000078e5533d4211  pop rdx
000078e5533d4212  pop rcx
000078e5533d4213  pop rax
000078e5533d4214  add rsp, 0x08
000078e5533d4218  jmp 0x000078E5533D00AE
000078e5533d421d  sub rsp, 0x08
000078e5533d4221  push rax
000078e5533d4222  push rcx
000078e5533d4223  push rdx
000078e5533d4224  push rdi
000078e5533d4225  push rsi
000078e5533d4226  push r8
000078e5533d4228  push r9
000078e5533d422a  push r10
000078e5533d422c  push r11
000078e5533d422e  sub rsp, 0xF0
000078e5533d4235  vmovaps [rsp], xmm0
000078e5533d423a  vmovaps [rsp+0x10], xmm1
000078e5533d4240  vmovaps [rsp+0x20], xmm2
000078e5533d4246  vmovaps [rsp+0x30], xmm3
000078e5533d424c  vmovaps [rsp+0x40], xmm4
000078e5533d4252  vmovaps [rsp+0x50], xmm5
000078e5533d4258  vmovaps [rsp+0x60], xmm6
000078e5533d425e  vmovaps [rsp+0x70], xmm7
000078e5533d4264  vmovaps [rsp+0x80], xmm8
000078e5533d426d  vmovaps [rsp+0x90], xmm10
000078e5533d4276  vmovaps [rsp+0xA0], xmm11
000078e5533d427f  vmovaps [rsp+0xB0], xmm12
000078e5533d4288  vmovaps [rsp+0xC0], xmm13
000078e5533d4291  vmovaps [rsp+0xD0], xmm14
000078e5533d429a  vmovaps [rsp+0xE0], xmm15
000078e5533d42a3  sub rsp, 0x30
000078e5533d42a7  movaps [rsp], xmm9
000078e5533d42ac  movaps [rsp+0x10], xmm7
000078e5533d42b1  movaps [rsp+0x20], xmm12
000078e5533d42b7  lea rdi, [rsp]
000078e5533d42bb  mov esi, 0x00
000078e5533d42c0  mov rax, 0x5F83D5E17530
000078e5533d42ca  call rax
000078e5533d42cc  movaps xmm9, [rsp]
000078e5533d42d1  add rsp, 0x30
000078e5533d42d5  vmovaps xmm0, [rsp]
000078e5533d42da  vmovaps xmm1, [rsp+0x10]
000078e5533d42e0  vmovaps xmm2, [rsp+0x20]
000078e5533d42e6  vmovaps xmm3, [rsp+0x30]
000078e5533d42ec  vmovaps xmm4, [rsp+0x40]
000078e5533d42f2  vmovaps xmm5, [rsp+0x50]
000078e5533d42f8  vmovaps xmm6, [rsp+0x60]
000078e5533d42fe  vmovaps xmm7, [rsp+0x70]
000078e5533d4304  vmovaps xmm8, [rsp+0x80]
000078e5533d430d  vmovaps xmm10, [rsp+0x90]
000078e5533d4316  vmovaps xmm11, [rsp+0xA0]
000078e5533d431f  vmovaps xmm12, [rsp+0xB0]
000078e5533d4328  vmovaps xmm13, [rsp+0xC0]
000078e5533d4331  vmovaps xmm14, [rsp+0xD0]
000078e5533d433a  vmovaps xmm15, [rsp+0xE0]
000078e5533d4343  add rsp, 0xF0
000078e5533d434a  pop r11
000078e5533d434c  pop r10
000078e5533d434e  pop r9
000078e5533d4350  pop r8
000078e5533d4352  pop rsi
000078e5533d4353  pop rdi
000078e5533d4354  pop rdx
000078e5533d4355  pop rcx
000078e5533d4356  pop rax
000078e5533d4357  add rsp, 0x08
000078e5533d435b  jmp 0x000078E5533D00DD
000078e5533d4360  sub rsp, 0x08
000078e5533d4364  push rax
000078e5533d4365  push rcx
000078e5533d4366  push rdx
000078e5533d4367  push rdi
000078e5533d4368  push rsi
000078e5533d4369  push r8
000078e5533d436b  push r9
000078e5533d436d  push r10
000078e5533d436f  push r11
000078e5533d4371  sub rsp, 0xF0
000078e5533d4378  vmovaps [rsp], xmm0
000078e5533d437d  vmovaps [rsp+0x10], xmm1
000078e5533d4383  vmovaps [rsp+0x20], xmm2
000078e5533d4389  vmovaps [rsp+0x30], xmm3
000078e5533d438f  vmovaps [rsp+0x40], xmm4
000078e5533d4395  vmovaps [rsp+0x50], xmm5
000078e5533d439b  vmovaps [rsp+0x60], xmm6
000078e5533d43a1  vmovaps [rsp+0x70], xmm7
000078e5533d43a7  vmovaps [rsp+0x80], xmm8
000078e5533d43b0  vmovaps [rsp+0x90], xmm9
000078e5533d43b9  vmovaps [rsp+0xA0], xmm10
000078e5533d43c2  vmovaps [rsp+0xB0], xmm11
000078e5533d43cb  vmovaps [rsp+0xC0], xmm13
000078e5533d43d4  vmovaps [rsp+0xD0], xmm14
000078e5533d43dd  vmovaps [rsp+0xE0], xmm15
000078e5533d43e6  sub rsp, 0x30
000078e5533d43ea  movaps [rsp], xmm12
000078e5533d43ef  movaps [rsp+0x10], xmm15
000078e5533d43f5  movaps [rsp+0x20], xmm11
000078e5533d43fb  lea rdi, [rsp]
000078e5533d43ff  mov esi, 0x00
000078e5533d4404  mov rax, 0x5F83D5E17530
000078e5533d440e  call rax
000078e5533d4410  movaps xmm12, [rsp]
000078e5533d4415  add rsp, 0x30
000078e5533d4419  vmovaps xmm0, [rsp]
000078e5533d441e  vmovaps xmm1, [rsp+0x10]
000078e5533d4424  vmovaps xmm2, [rsp+0x20]
000078e5533d442a  vmovaps xmm3, [rsp+0x30]
000078e5533d4430  vmovaps xmm4, [rsp+0x40]
000078e5533d4436  vmovaps xmm5, [rsp+0x50]
000078e5533d443c  vmovaps xmm6, [rsp+0x60]
000078e5533d4442  vmovaps xmm7, [rsp+0x70]
000078e5533d4448  vmovaps xmm8, [rsp+0x80]
000078e5533d4451  vmovaps xmm9, [rsp+0x90]
000078e5533d445a  vmovaps xmm10, [rsp+0xA0]
000078e5533d4463  vmovaps xmm11, [rsp+0xB0]
000078e5533d446c  vmovaps xmm13, [rsp+0xC0]
000078e5533d4475  vmovaps xmm14, [rsp+0xD0]
000078e5533d447e  vmovaps xmm15, [rsp+0xE0]
000078e5533d4487  add rsp, 0xF0
000078e5533d448e  pop r11
000078e5533d4490  pop r10
000078e5533d4492  pop r9
000078e5533d4494  pop r8
000078e5533d4496  pop rsi
000078e5533d4497  pop rdi
000078e5533d4498  pop rdx
000078e5533d4499  pop rcx
000078e5533d449a  pop rax
000078e5533d449b  add rsp, 0x08
000078e5533d449f  jmp 0x000078E5533D00F7
000078e5533d44a4  sub rsp, 0x08
000078e5533d44a8  push rax
000078e5533d44a9  push rcx
000078e5533d44aa  push rdx
000078e5533d44ab  push rdi
000078e5533d44ac  push rsi
000078e5533d44ad  push r8
000078e5533d44af  push r9
000078e5533d44b1  push r10
000078e5533d44b3  push r11
000078e5533d44b5  sub rsp, 0xF0
000078e5533d44bc  vmovaps [rsp], xmm0
000078e5533d44c1  vmovaps [rsp+0x10], xmm1
000078e5533d44c7  vmovaps [rsp+0x20], xmm2
000078e5533d44cd  vmovaps [rsp+0x30], xmm3
000078e5533d44d3  vmovaps [rsp+0x40], xmm4
000078e5533d44d9  vmovaps [rsp+0x50], xmm5
000078e5533d44df  vmovaps [rsp+0x60], xmm6
000078e5533d44e5  vmovaps [rsp+0x70], xmm7
000078e5533d44eb  vmovaps [rsp+0x80], xmm8
000078e5533d44f4  vmovaps [rsp+0x90], xmm9
000078e5533d44fd  vmovaps [rsp+0xA0], xmm10
000078e5533d4506  vmovaps [rsp+0xB0], xmm12
000078e5533d450f  vmovaps [rsp+0xC0], xmm13
000078e5533d4518  vmovaps [rsp+0xD0], xmm14
000078e5533d4521  vmovaps [rsp+0xE0], xmm15
000078e5533d452a  sub rsp, 0x30
000078e5533d452e  movaps [rsp], xmm11
000078e5533d4533  movaps [rsp+0x10], xmm7
000078e5533d4538  movaps [rsp+0x20], xmm15
000078e5533d453e  lea rdi, [rsp]
000078e5533d4542  mov esi, 0x00
000078e5533d4547  mov rax, 0x5F83D5E17530
000078e5533d4551  call rax
000078e5533d4553  movaps xmm11, [rsp]
000078e5533d4558  add rsp, 0x30
000078e5533d455c  vmovaps xmm0, [rsp]
000078e5533d4561  vmovaps xmm1, [rsp+0x10]
000078e5533d4567  vmovaps xmm2, [rsp+0x20]
000078e5533d456d  vmovaps xmm3, [rsp+0x30]
000078e5533d4573  vmovaps xmm4, [rsp+0x40]
000078e5533d4579  vmovaps xmm5, [rsp+0x50]
000078e5533d457f  vmovaps xmm6, [rsp+0x60]
000078e5533d4585  vmovaps xmm7, [rsp+0x70]
000078e5533d458b  vmovaps xmm8, [rsp+0x80]
000078e5533d4594  vmovaps xmm9, [rsp+0x90]
000078e5533d459d  vmovaps xmm10, [rsp+0xA0]
000078e5533d45a6  vmovaps xmm12, [rsp+0xB0]
000078e5533d45af  vmovaps xmm13, [rsp+0xC0]
000078e5533d45b8  vmovaps xmm14, [rsp+0xD0]
000078e5533d45c1  vmovaps xmm15, [rsp+0xE0]
000078e5533d45ca  add rsp, 0xF0
000078e5533d45d1  pop r11
000078e5533d45d3  pop r10
000078e5533d45d5  pop r9
000078e5533d45d7  pop r8
000078e5533d45d9  pop rsi
000078e5533d45da  pop rdi
000078e5533d45db  pop rdx
000078e5533d45dc  pop rcx
000078e5533d45dd  pop rax
000078e5533d45de  add rsp, 0x08
000078e5533d45e2  jmp 0x000078E5533D0123
000078e5533d45e7  sub rsp, 0x08
000078e5533d45eb  push rax
000078e5533d45ec  push rcx
000078e5533d45ed  push rdx
000078e5533d45ee  push rdi
000078e5533d45ef  push rsi
000078e5533d45f0  push r8
000078e5533d45f2  push r9
000078e5533d45f4  push r10
000078e5533d45f6  push r11
000078e5533d45f8  sub rsp, 0xF0
000078e5533d45ff  vmovaps [rsp], xmm0
000078e5533d4604  vmovaps [rsp+0x10], xmm1
000078e5533d460a  vmovaps [rsp+0x20], xmm2
000078e5533d4610  vmovaps [rsp+0x30], xmm3
000078e5533d4616  vmovaps [rsp+0x40], xmm4
000078e5533d461c  vmovaps [rsp+0x50], xmm5
000078e5533d4622  vmovaps [rsp+0x60], xmm6
000078e5533d4628  vmovaps [rsp+0x70], xmm7
000078e5533d462e  vmovaps [rsp+0x80], xmm8
000078e5533d4637  vmovaps [rsp+0x90], xmm9
000078e5533d4640  vmovaps [rsp+0xA0], xmm10
000078e5533d4649  vmovaps [rsp+0xB0], xmm11
000078e5533d4652  vmovaps [rsp+0xC0], xmm12
000078e5533d465b  vmovaps [rsp+0xD0], xmm13
000078e5533d4664  vmovaps [rsp+0xE0], xmm14
000078e5533d466d  sub rsp, 0x30
000078e5533d4671  movaps [rsp], xmm15
000078e5533d4676  movaps [rsp+0x10], xmm10
000078e5533d467c  movaps [rsp+0x20], xmm13
000078e5533d4682  lea rdi, [rsp]
000078e5533d4686  mov esi, 0x00
000078e5533d468b  mov rax, 0x5F83D5E17530
000078e5533d4695  call rax
000078e5533d4697  movaps xmm15, [rsp]
000078e5533d469c  add rsp, 0x30
000078e5533d46a0  vmovaps xmm0, [rsp]
000078e5533d46a5  vmovaps xmm1, [rsp+0x10]
000078e5533d46ab  vmovaps xmm2, [rsp+0x20]
000078e5533d46b1  vmovaps xmm3, [rsp+0x30]
000078e5533d46b7  vmovaps xmm4, [rsp+0x40]
000078e5533d46bd  vmovaps xmm5, [rsp+0x50]
000078e5533d46c3  vmovaps xmm6, [rsp+0x60]
000078e5533d46c9  vmovaps xmm7, [rsp+0x70]
000078e5533d46cf  vmovaps xmm8, [rsp+0x80]
000078e5533d46d8  vmovaps xmm9, [rsp+0x90]
000078e5533d46e1  vmovaps xmm10, [rsp+0xA0]
000078e5533d46ea  vmovaps xmm11, [rsp+0xB0]
000078e5533d46f3  vmovaps xmm12, [rsp+0xC0]
000078e5533d46fc  vmovaps xmm13, [rsp+0xD0]
000078e5533d4705  vmovaps xmm14, [rsp+0xE0]
000078e5533d470e  add rsp, 0xF0
000078e5533d4715  pop r11
000078e5533d4717  pop r10
000078e5533d4719  pop r9
000078e5533d471b  pop r8
000078e5533d471d  pop rsi
000078e5533d471e  pop rdi
000078e5533d471f  pop rdx
000078e5533d4720  pop rcx
000078e5533d4721  pop rax
000078e5533d4722  add rsp, 0x08
000078e5533d4726  jmp 0x000078E5533D013D
000078e5533d472b  sub rsp, 0x08
000078e5533d472f  push rax
000078e5533d4730  push rcx
000078e5533d4731  push rdx
000078e5533d4732  push rdi
000078e5533d4733  push rsi
000078e5533d4734  push r8
000078e5533d4736  push r9
000078e5533d4738  push r10
000078e5533d473a  push r11
000078e5533d473c  sub rsp, 0xF0
000078e5533d4743  vmovaps [rsp], xmm0
000078e5533d4748  vmovaps [rsp+0x10], xmm1
000078e5533d474e  vmovaps [rsp+0x20], xmm2
000078e5533d4754  vmovaps [rsp+0x30], xmm3
000078e5533d475a  vmovaps [rsp+0x40], xmm4
000078e5533d4760  vmovaps [rsp+0x50], xmm5
000078e5533d4766  vmovaps [rsp+0x60], xmm6
000078e5533d476c  vmovaps [rsp+0x70], xmm7
000078e5533d4772  vmovaps [rsp+0x80], xmm8
000078e5533d477b  vmovaps [rsp+0x90], xmm9
000078e5533d4784  vmovaps [rsp+0xA0], xmm11
000078e5533d478d  vmovaps [rsp+0xB0], xmm12
000078e5533d4796  vmovaps [rsp+0xC0], xmm13
000078e5533d479f  vmovaps [rsp+0xD0], xmm14
000078e5533d47a8  vmovaps [rsp+0xE0], xmm15
000078e5533d47b1  sub rsp, 0x30
000078e5533d47b5  movaps [rsp], xmm10
000078e5533d47ba  movaps [rsp+0x10], xmm7
000078e5533d47bf  movaps [rsp+0x20], xmm13
000078e5533d47c5  lea rdi, [rsp]
000078e5533d47c9  mov esi, 0x00
000078e5533d47ce  mov rax, 0x5F83D5E17530
000078e5533d47d8  call rax
000078e5533d47da  movaps xmm10, [rsp]
000078e5533d47df  add rsp, 0x30
000078e5533d47e3  vmovaps xmm0, [rsp]
000078e5533d47e8  vmovaps xmm1, [rsp+0x10]
000078e5533d47ee  vmovaps xmm2, [rsp+0x20]
000078e5533d47f4  vmovaps xmm3, [rsp+0x30]
000078e5533d47fa  vmovaps xmm4, [rsp+0x40]
000078e5533d4800  vmovaps xmm5, [rsp+0x50]
000078e5533d4806  vmovaps xmm6, [rsp+0x60]
000078e5533d480c  vmovaps xmm7, [rsp+0x70]
000078e5533d4812  vmovaps xmm8, [rsp+0x80]
000078e5533d481b  vmovaps xmm9, [rsp+0x90]
000078e5533d4824  vmovaps xmm11, [rsp+0xA0]
000078e5533d482d  vmovaps xmm12, [rsp+0xB0]
000078e5533d4836  vmovaps xmm13, [rsp+0xC0]
000078e5533d483f  vmovaps xmm14, [rsp+0xD0]
000078e5533d4848  vmovaps xmm15, [rsp+0xE0]
000078e5533d4851  add rsp, 0xF0
000078e5533d4858  pop r11
000078e5533d485a  pop r10
000078e5533d485c  pop r9
000078e5533d485e  pop r8
000078e5533d4860  pop rsi
000078e5533d4861  pop rdi
000078e5533d4862  pop rdx
000078e5533d4863  pop rcx
000078e5533d4864  pop rax
000078e5533d4865  add rsp, 0x08
000078e5533d4869  jmp 0x000078E5533D0169
000078e5533d486e  sub rsp, 0x08
000078e5533d4872  push rax
000078e5533d4873  push rcx
000078e5533d4874  push rdx
000078e5533d4875  push rdi
000078e5533d4876  push rsi
000078e5533d4877  push r8
000078e5533d4879  push r9
000078e5533d487b  push r10
000078e5533d487d  push r11
000078e5533d487f  sub rsp, 0xF0
000078e5533d4886  vmovaps [rsp], xmm0
000078e5533d488b  vmovaps [rsp+0x10], xmm1
000078e5533d4891  vmovaps [rsp+0x20], xmm2
000078e5533d4897  vmovaps [rsp+0x30], xmm3
000078e5533d489d  vmovaps [rsp+0x40], xmm4
000078e5533d48a3  vmovaps [rsp+0x50], xmm5
000078e5533d48a9  vmovaps [rsp+0x60], xmm6
000078e5533d48af  vmovaps [rsp+0x70], xmm7
000078e5533d48b5  vmovaps [rsp+0x80], xmm8
000078e5533d48be  vmovaps [rsp+0x90], xmm9
000078e5533d48c7  vmovaps [rsp+0xA0], xmm10
000078e5533d48d0  vmovaps [rsp+0xB0], xmm11
000078e5533d48d9  vmovaps [rsp+0xC0], xmm12
000078e5533d48e2  vmovaps [rsp+0xD0], xmm14
000078e5533d48eb  vmovaps [rsp+0xE0], xmm15
000078e5533d48f4  sub rsp, 0x30
000078e5533d48f8  movaps [rsp], xmm13
000078e5533d48fd  movaps [rsp+0x10], xmm1
000078e5533d4902  movaps [rsp+0x20], xmm8
000078e5533d4908  lea rdi, [rsp]
000078e5533d490c  mov esi, 0x00
000078e5533d4911  mov rax, 0x5F83D5E17530
000078e5533d491b  call rax
000078e5533d491d  movaps xmm13, [rsp]
000078e5533d4922  add rsp, 0x30
000078e5533d4926  vmovaps xmm0, [rsp]
000078e5533d492b  vmovaps xmm1, [rsp+0x10]
000078e5533d4931  vmovaps xmm2, [rsp+0x20]
000078e5533d4937  vmovaps xmm3, [rsp+0x30]
000078e5533d493d  vmovaps xmm4, [rsp+0x40]
000078e5533d4943  vmovaps xmm5, [rsp+0x50]
000078e5533d4949  vmovaps xmm6, [rsp+0x60]
000078e5533d494f  vmovaps xmm7, [rsp+0x70]
000078e5533d4955  vmovaps xmm8, [rsp+0x80]
000078e5533d495e  vmovaps xmm9, [rsp+0x90]
000078e5533d4967  vmovaps xmm10, [rsp+0xA0]
000078e5533d4970  vmovaps xmm11, [rsp+0xB0]
000078e5533d4979  vmovaps xmm12, [rsp+0xC0]
000078e5533d4982  vmovaps xmm14, [rsp+0xD0]
000078e5533d498b  vmovaps xmm15, [rsp+0xE0]
000078e5533d4994  add rsp, 0xF0
000078e5533d499b  pop r11
000078e5533d499d  pop r10
000078e5533d499f  pop r9
000078e5533d49a1  pop r8
000078e5533d49a3  pop rsi
000078e5533d49a4  pop rdi
000078e5533d49a5  pop rdx
000078e5533d49a6  pop rcx
000078e5533d49a7  pop rax
000078e5533d49a8  add rsp, 0x08
000078e5533d49ac  jmp 0x000078E5533D0183
000078e5533d49b1  call 0x000078E5531FF430
000078e5533d49b6  jmp 0x000078E5533D018D
000078e5533d49bb  sub rsp, 0x08
000078e5533d49bf  push rax
000078e5533d49c0  push rcx
000078e5533d49c1  push rdx
000078e5533d49c2  push rdi
000078e5533d49c3  push rsi
000078e5533d49c4  push r8
000078e5533d49c6  push r9
000078e5533d49c8  push r10
000078e5533d49ca  push r11
000078e5533d49cc  sub rsp, 0xF0
000078e5533d49d3  vmovaps [rsp], xmm0
000078e5533d49d8  vmovaps [rsp+0x10], xmm1
000078e5533d49de  vmovaps [rsp+0x20], xmm2
000078e5533d49e4  vmovaps [rsp+0x30], xmm3
000078e5533d49ea  vmovaps [rsp+0x40], xmm4
000078e5533d49f0  vmovaps [rsp+0x50], xmm5
000078e5533d49f6  vmovaps [rsp+0x60], xmm6
000078e5533d49fc  vmovaps [rsp+0x70], xmm7
000078e5533d4a02  vmovaps [rsp+0x80], xmm9
000078e5533d4a0b  vmovaps [rsp+0x90], xmm10
000078e5533d4a14  vmovaps [rsp+0xA0], xmm11
000078e5533d4a1d  vmovaps [rsp+0xB0], xmm12
000078e5533d4a26  vmovaps [rsp+0xC0], xmm13
000078e5533d4a2f  vmovaps [rsp+0xD0], xmm14
000078e5533d4a38  vmovaps [rsp+0xE0], xmm15
000078e5533d4a41  sub rsp, 0x30
000078e5533d4a45  movaps [rsp], xmm8
000078e5533d4a4a  movaps [rsp+0x10], xmm14
000078e5533d4a50  movaps [rsp+0x20], xmm9
000078e5533d4a56  lea rdi, [rsp]
000078e5533d4a5a  mov esi, 0x00
000078e5533d4a5f  mov rax, 0x5F83D5E17530
000078e5533d4a69  call rax
000078e5533d4a6b  movaps xmm8, [rsp]
000078e5533d4a70  add rsp, 0x30
000078e5533d4a74  vmovaps xmm0, [rsp]
000078e5533d4a79  vmovaps xmm1, [rsp+0x10]
000078e5533d4a7f  vmovaps xmm2, [rsp+0x20]
000078e5533d4a85  vmovaps xmm3, [rsp+0x30]
000078e5533d4a8b  vmovaps xmm4, [rsp+0x40]
000078e5533d4a91  vmovaps xmm5, [rsp+0x50]
000078e5533d4a97  vmovaps xmm6, [rsp+0x60]
000078e5533d4a9d  vmovaps xmm7, [rsp+0x70]
000078e5533d4aa3  vmovaps xmm9, [rsp+0x80]
000078e5533d4aac  vmovaps xmm10, [rsp+0x90]
000078e5533d4ab5  vmovaps xmm11, [rsp+0xA0]
000078e5533d4abe  vmovaps xmm12, [rsp+0xB0]
000078e5533d4ac7  vmovaps xmm13, [rsp+0xC0]
000078e5533d4ad0  vmovaps xmm14, [rsp+0xD0]
000078e5533d4ad9  vmovaps xmm15, [rsp+0xE0]
000078e5533d4ae2  add rsp, 0xF0
000078e5533d4ae9  pop r11
000078e5533d4aeb  pop r10
000078e5533d4aed  pop r9
000078e5533d4aef  pop r8
000078e5533d4af1  pop rsi
000078e5533d4af2  pop rdi
000078e5533d4af3  pop rdx
000078e5533d4af4  pop rcx
000078e5533d4af5  pop rax
000078e5533d4af6  add rsp, 0x08
000078e5533d4afa  jmp 0x000078E5533D01AF
000078e5533d4aff  sub rsp, 0x08
000078e5533d4b03  push rax
000078e5533d4b04  push rcx
000078e5533d4b05  push rdx
000078e5533d4b06  push rdi
000078e5533d4b07  push rsi
000078e5533d4b08  push r8
000078e5533d4b0a  push r9
000078e5533d4b0c  push r10
000078e5533d4b0e  push r11
000078e5533d4b10  sub rsp, 0xF0
000078e5533d4b17  vmovaps [rsp], xmm0
000078e5533d4b1c  vmovaps [rsp+0x10], xmm1
000078e5533d4b22  vmovaps [rsp+0x20], xmm2
000078e5533d4b28  vmovaps [rsp+0x30], xmm3
000078e5533d4b2e  vmovaps [rsp+0x40], xmm4
000078e5533d4b34  vmovaps [rsp+0x50], xmm5
000078e5533d4b3a  vmovaps [rsp+0x60], xmm6
000078e5533d4b40  vmovaps [rsp+0x70], xmm7
000078e5533d4b46  vmovaps [rsp+0x80], xmm8
000078e5533d4b4f  vmovaps [rsp+0x90], xmm10
000078e5533d4b58  vmovaps [rsp+0xA0], xmm11
000078e5533d4b61  vmovaps [rsp+0xB0], xmm12
000078e5533d4b6a  vmovaps [rsp+0xC0], xmm13
000078e5533d4b73  vmovaps [rsp+0xD0], xmm14
000078e5533d4b7c  vmovaps [rsp+0xE0], xmm15
000078e5533d4b85  sub rsp, 0x30
000078e5533d4b89  movaps [rsp], xmm9
000078e5533d4b8e  movaps [rsp+0x10], xmm1
000078e5533d4b93  movaps [rsp+0x20], xmm14
000078e5533d4b99  lea rdi, [rsp]
000078e5533d4b9d  mov esi, 0x00
000078e5533d4ba2  mov rax, 0x5F83D5E17530
000078e5533d4bac  call rax
000078e5533d4bae  movaps xmm9, [rsp]
000078e5533d4bb3  add rsp, 0x30
000078e5533d4bb7  vmovaps xmm0, [rsp]
000078e5533d4bbc  vmovaps xmm1, [rsp+0x10]
000078e5533d4bc2  vmovaps xmm2, [rsp+0x20]
000078e5533d4bc8  vmovaps xmm3, [rsp+0x30]
000078e5533d4bce  vmovaps xmm4, [rsp+0x40]
000078e5533d4bd4  vmovaps xmm5, [rsp+0x50]
000078e5533d4bda  vmovaps xmm6, [rsp+0x60]
000078e5533d4be0  vmovaps xmm7, [rsp+0x70]
000078e5533d4be6  vmovaps xmm8, [rsp+0x80]
000078e5533d4bef  vmovaps xmm10, [rsp+0x90]
000078e5533d4bf8  vmovaps xmm11, [rsp+0xA0]
000078e5533d4c01  vmovaps xmm12, [rsp+0xB0]
000078e5533d4c0a  vmovaps xmm13, [rsp+0xC0]
000078e5533d4c13  vmovaps xmm14, [rsp+0xD0]
000078e5533d4c1c  vmovaps xmm15, [rsp+0xE0]
000078e5533d4c25  add rsp, 0xF0
000078e5533d4c2c  pop r11
000078e5533d4c2e  pop r10
000078e5533d4c30  pop r9
000078e5533d4c32  pop r8
000078e5533d4c34  pop rsi
000078e5533d4c35  pop rdi
000078e5533d4c36  pop rdx
000078e5533d4c37  pop rcx
000078e5533d4c38  pop rax
000078e5533d4c39  add rsp, 0x08
000078e5533d4c3d  jmp 0x000078E5533D01DD
000078e5533d4c42  sub rsp, 0x08
000078e5533d4c46  push rax
000078e5533d4c47  push rcx
000078e5533d4c48  push rdx
000078e5533d4c49  push rdi
000078e5533d4c4a  push rsi
000078e5533d4c4b  push r8
000078e5533d4c4d  push r9
000078e5533d4c4f  push r10
000078e5533d4c51  push r11
000078e5533d4c53  sub rsp, 0xF0
000078e5533d4c5a  vmovaps [rsp], xmm0
000078e5533d4c5f  vmovaps [rsp+0x10], xmm1
000078e5533d4c65  vmovaps [rsp+0x20], xmm2
000078e5533d4c6b  vmovaps [rsp+0x30], xmm3
000078e5533d4c71  vmovaps [rsp+0x40], xmm4
000078e5533d4c77  vmovaps [rsp+0x50], xmm5
000078e5533d4c7d  vmovaps [rsp+0x60], xmm6
000078e5533d4c83  vmovaps [rsp+0x70], xmm7
000078e5533d4c89  vmovaps [rsp+0x80], xmm8
000078e5533d4c92  vmovaps [rsp+0x90], xmm9
000078e5533d4c9b  vmovaps [rsp+0xA0], xmm10
000078e5533d4ca4  vmovaps [rsp+0xB0], xmm11
000078e5533d4cad  vmovaps [rsp+0xC0], xmm12
000078e5533d4cb6  vmovaps [rsp+0xD0], xmm13
000078e5533d4cbf  vmovaps [rsp+0xE0], xmm15
000078e5533d4cc8  sub rsp, 0x30
000078e5533d4ccc  movaps [rsp], xmm14
000078e5533d4cd1  movaps [rsp+0x10], xmm4
000078e5533d4cd6  movaps [rsp+0x20], xmm1
000078e5533d4cdb  lea rdi, [rsp]
000078e5533d4cdf  mov esi, 0x00
000078e5533d4ce4  mov rax, 0x5F83D5E17530
000078e5533d4cee  call rax
000078e5533d4cf0  movaps xmm14, [rsp]
000078e5533d4cf5  add rsp, 0x30
000078e5533d4cf9  vmovaps xmm0, [rsp]
000078e5533d4cfe  vmovaps xmm1, [rsp+0x10]
000078e5533d4d04  vmovaps xmm2, [rsp+0x20]
000078e5533d4d0a  vmovaps xmm3, [rsp+0x30]
000078e5533d4d10  vmovaps xmm4, [rsp+0x40]
000078e5533d4d16  vmovaps xmm5, [rsp+0x50]
000078e5533d4d1c  vmovaps xmm6, [rsp+0x60]
000078e5533d4d22  vmovaps xmm7, [rsp+0x70]
000078e5533d4d28  vmovaps xmm8, [rsp+0x80]
000078e5533d4d31  vmovaps xmm9, [rsp+0x90]
000078e5533d4d3a  vmovaps xmm10, [rsp+0xA0]
000078e5533d4d43  vmovaps xmm11, [rsp+0xB0]
000078e5533d4d4c  vmovaps xmm12, [rsp+0xC0]
000078e5533d4d55  vmovaps xmm13, [rsp+0xD0]
000078e5533d4d5e  vmovaps xmm15, [rsp+0xE0]
000078e5533d4d67  add rsp, 0xF0
000078e5533d4d6e  pop r11
000078e5533d4d70  pop r10
000078e5533d4d72  pop r9
000078e5533d4d74  pop r8
000078e5533d4d76  pop rsi
000078e5533d4d77  pop rdi
000078e5533d4d78  pop rdx
000078e5533d4d79  pop rcx
000078e5533d4d7a  pop rax
000078e5533d4d7b  add rsp, 0x08
000078e5533d4d7f  jmp 0x000078E5533D0203
000078e5533d4d84  sub rsp, 0x08
000078e5533d4d88  push rax
000078e5533d4d89  push rcx
000078e5533d4d8a  push rdx
000078e5533d4d8b  push rdi
000078e5533d4d8c  push rsi
000078e5533d4d8d  push r8
000078e5533d4d8f  push r9
000078e5533d4d91  push r10
000078e5533d4d93  push r11
000078e5533d4d95  sub rsp, 0xF0
000078e5533d4d9c  vmovaps [rsp], xmm0
000078e5533d4da1  vmovaps [rsp+0x10], xmm2
000078e5533d4da7  vmovaps [rsp+0x20], xmm3
000078e5533d4dad  vmovaps [rsp+0x30], xmm4
000078e5533d4db3  vmovaps [rsp+0x40], xmm5
000078e5533d4db9  vmovaps [rsp+0x50], xmm6
000078e5533d4dbf  vmovaps [rsp+0x60], xmm7
000078e5533d4dc5  vmovaps [rsp+0x70], xmm8
000078e5533d4dcb  vmovaps [rsp+0x80], xmm9
000078e5533d4dd4  vmovaps [rsp+0x90], xmm10
000078e5533d4ddd  vmovaps [rsp+0xA0], xmm11
000078e5533d4de6  vmovaps [rsp+0xB0], xmm12
000078e5533d4def  vmovaps [rsp+0xC0], xmm13
000078e5533d4df8  vmovaps [rsp+0xD0], xmm14
000078e5533d4e01  vmovaps [rsp+0xE0], xmm15
000078e5533d4e0a  sub rsp, 0x30
000078e5533d4e0e  movaps [rsp], xmm1
000078e5533d4e12  movaps [rsp+0x10], xmm12
000078e5533d4e18  movaps [rsp+0x20], xmm11
000078e5533d4e1e  lea rdi, [rsp]
000078e5533d4e22  mov esi, 0x00
000078e5533d4e27  mov rax, 0x5F83D5E17530
000078e5533d4e31  call rax
000078e5533d4e33  movaps xmm1, [rsp]
000078e5533d4e37  add rsp, 0x30
000078e5533d4e3b  vmovaps xmm0, [rsp]
000078e5533d4e40  vmovaps xmm2, [rsp+0x10]
000078e5533d4e46  vmovaps xmm3, [rsp+0x20]
000078e5533d4e4c  vmovaps xmm4, [rsp+0x30]
000078e5533d4e52  vmovaps xmm5, [rsp+0x40]
000078e5533d4e58  vmovaps xmm6, [rsp+0x50]
000078e5533d4e5e  vmovaps xmm7, [rsp+0x60]
000078e5533d4e64  vmovaps xmm8, [rsp+0x70]
000078e5533d4e6a  vmovaps xmm9, [rsp+0x80]
000078e5533d4e73  vmovaps xmm10, [rsp+0x90]
000078e5533d4e7c  vmovaps xmm11, [rsp+0xA0]
000078e5533d4e85  vmovaps xmm12, [rsp+0xB0]
000078e5533d4e8e  vmovaps xmm13, [rsp+0xC0]
000078e5533d4e97  vmovaps xmm14, [rsp+0xD0]
000078e5533d4ea0  vmovaps xmm15, [rsp+0xE0]
000078e5533d4ea9  add rsp, 0xF0
000078e5533d4eb0  pop r11
000078e5533d4eb2  pop r10
000078e5533d4eb4  pop r9
000078e5533d4eb6  pop r8
000078e5533d4eb8  pop rsi
000078e5533d4eb9  pop rdi
000078e5533d4eba  pop rdx
000078e5533d4ebb  pop rcx
000078e5533d4ebc  pop rax
000078e5533d4ebd  add rsp, 0x08
000078e5533d4ec1  jmp 0x000078E5533D0224
000078e5533d4ec6  call 0x000078E5532E20A0
000078e5533d4ecb  jmp 0x000078E5533D0232
000078e5533d4ed0  call 0x000078E553209D70
000078e5533d4ed5  jmp 0x000078E5533D023C
000078e5533d4eda  sub rsp, 0x08
000078e5533d4ede  push rax
000078e5533d4edf  push rcx
000078e5533d4ee0  push rdx
000078e5533d4ee1  push rdi
000078e5533d4ee2  push rsi
000078e5533d4ee3  push r8
000078e5533d4ee5  push r9
000078e5533d4ee7  push r10
000078e5533d4ee9  push r11
000078e5533d4eeb  sub rsp, 0xF0
000078e5533d4ef2  vmovaps [rsp], xmm0
000078e5533d4ef7  vmovaps [rsp+0x10], xmm1
000078e5533d4efd  vmovaps [rsp+0x20], xmm2
000078e5533d4f03  vmovaps [rsp+0x30], xmm3
000078e5533d4f09  vmovaps [rsp+0x40], xmm4
000078e5533d4f0f  vmovaps [rsp+0x50], xmm5
000078e5533d4f15  vmovaps [rsp+0x60], xmm6
000078e5533d4f1b  vmovaps [rsp+0x70], xmm8
000078e5533d4f21  vmovaps [rsp+0x80], xmm9
000078e5533d4f2a  vmovaps [rsp+0x90], xmm10
000078e5533d4f33  vmovaps [rsp+0xA0], xmm11
000078e5533d4f3c  vmovaps [rsp+0xB0], xmm12
000078e5533d4f45  vmovaps [rsp+0xC0], xmm13
000078e5533d4f4e  vmovaps [rsp+0xD0], xmm14
000078e5533d4f57  vmovaps [rsp+0xE0], xmm15
000078e5533d4f60  sub rsp, 0x30
000078e5533d4f64  movaps [rsp], xmm7
000078e5533d4f68  movaps [rsp+0x10], xmm15
000078e5533d4f6e  movaps [rsp+0x20], xmm10
000078e5533d4f74  lea rdi, [rsp]
000078e5533d4f78  mov esi, 0x00
000078e5533d4f7d  mov rax, 0x5F83D5E17530
000078e5533d4f87  call rax
000078e5533d4f89  movaps xmm7, [rsp]
000078e5533d4f8d  add rsp, 0x30
000078e5533d4f91  vmovaps xmm0, [rsp]
000078e5533d4f96  vmovaps xmm1, [rsp+0x10]
000078e5533d4f9c  vmovaps xmm2, [rsp+0x20]
000078e5533d4fa2  vmovaps xmm3, [rsp+0x30]
000078e5533d4fa8  vmovaps xmm4, [rsp+0x40]
000078e5533d4fae  vmovaps xmm5, [rsp+0x50]
000078e5533d4fb4  vmovaps xmm6, [rsp+0x60]
000078e5533d4fba  vmovaps xmm8, [rsp+0x70]
000078e5533d4fc0  vmovaps xmm9, [rsp+0x80]
000078e5533d4fc9  vmovaps xmm10, [rsp+0x90]
000078e5533d4fd2  vmovaps xmm11, [rsp+0xA0]
000078e5533d4fdb  vmovaps xmm12, [rsp+0xB0]
000078e5533d4fe4  vmovaps xmm13, [rsp+0xC0]
000078e5533d4fed  vmovaps xmm14, [rsp+0xD0]
000078e5533d4ff6  vmovaps xmm15, [rsp+0xE0]
000078e5533d4fff  add rsp, 0xF0
000078e5533d5006  pop r11
000078e5533d5008  pop r10
000078e5533d500a  pop r9
000078e5533d500c  pop r8
000078e5533d500e  pop rsi
000078e5533d500f  pop rdi
000078e5533d5010  pop rdx
000078e5533d5011  pop rcx
000078e5533d5012  pop rax
000078e5533d5013  add rsp, 0x08
000078e5533d5017  jmp 0x000078E5533D025D
000078e5533d501c  sub rsp, 0x08
000078e5533d5020  push rax
000078e5533d5021  push rcx
000078e5533d5022  push rdx
000078e5533d5023  push rdi
000078e5533d5024  push rsi
000078e5533d5025  push r8
000078e5533d5027  push r9
000078e5533d5029  push r10
000078e5533d502b  push r11
000078e5533d502d  sub rsp, 0xF0
000078e5533d5034  vmovaps [rsp], xmm0
000078e5533d5039  vmovaps [rsp+0x10], xmm1
000078e5533d503f  vmovaps [rsp+0x20], xmm2
000078e5533d5045  vmovaps [rsp+0x30], xmm3
000078e5533d504b  vmovaps [rsp+0x40], xmm4
000078e5533d5051  vmovaps [rsp+0x50], xmm5
000078e5533d5057  vmovaps [rsp+0x60], xmm6
000078e5533d505d  vmovaps [rsp+0x70], xmm7
000078e5533d5063  vmovaps [rsp+0x80], xmm8
000078e5533d506c  vmovaps [rsp+0x90], xmm9
000078e5533d5075  vmovaps [rsp+0xA0], xmm11
000078e5533d507e  vmovaps [rsp+0xB0], xmm12
000078e5533d5087  vmovaps [rsp+0xC0], xmm13
000078e5533d5090  vmovaps [rsp+0xD0], xmm14
000078e5533d5099  vmovaps [rsp+0xE0], xmm15
000078e5533d50a2  sub rsp, 0x30
000078e5533d50a6  movaps [rsp], xmm10
000078e5533d50ab  movaps [rsp+0x10], xmm11
000078e5533d50b1  movaps [rsp+0x20], xmm15
000078e5533d50b7  lea rdi, [rsp]
000078e5533d50bb  mov esi, 0x00
000078e5533d50c0  mov rax, 0x5F83D5E17530
000078e5533d50ca  call rax
000078e5533d50cc  movaps xmm10, [rsp]
000078e5533d50d1  add rsp, 0x30
000078e5533d50d5  vmovaps xmm0, [rsp]
000078e5533d50da  vmovaps xmm1, [rsp+0x10]
000078e5533d50e0  vmovaps xmm2, [rsp+0x20]
000078e5533d50e6  vmovaps xmm3, [rsp+0x30]
000078e5533d50ec  vmovaps xmm4, [rsp+0x40]
000078e5533d50f2  vmovaps xmm5, [rsp+0x50]
000078e5533d50f8  vmovaps xmm6, [rsp+0x60]
000078e5533d50fe  vmovaps xmm7, [rsp+0x70]
000078e5533d5104  vmovaps xmm8, [rsp+0x80]
000078e5533d510d  vmovaps xmm9, [rsp+0x90]
000078e5533d5116  vmovaps xmm11, [rsp+0xA0]
000078e5533d511f  vmovaps xmm12, [rsp+0xB0]
000078e5533d5128  vmovaps xmm13, [rsp+0xC0]
000078e5533d5131  vmovaps xmm14, [rsp+0xD0]
000078e5533d513a  vmovaps xmm15, [rsp+0xE0]
000078e5533d5143  add rsp, 0xF0
000078e5533d514a  pop r11
000078e5533d514c  pop r10
000078e5533d514e  pop r9
000078e5533d5150  pop r8
000078e5533d5152  pop rsi
000078e5533d5153  pop rdi
000078e5533d5154  pop rdx
000078e5533d5155  pop rcx
000078e5533d5156  pop rax
000078e5533d5157  add rsp, 0x08
000078e5533d515b  jmp 0x000078E5533D028B
000078e5533d5160  sub rsp, 0x08
000078e5533d5164  push rax
000078e5533d5165  push rcx
000078e5533d5166  push rdx
000078e5533d5167  push rdi
000078e5533d5168  push rsi
000078e5533d5169  push r8
000078e5533d516b  push r9
000078e5533d516d  push r10
000078e5533d516f  push r11
000078e5533d5171  sub rsp, 0xF0
000078e5533d5178  vmovaps [rsp], xmm0
000078e5533d517d  vmovaps [rsp+0x10], xmm1
000078e5533d5183  vmovaps [rsp+0x20], xmm2
000078e5533d5189  vmovaps [rsp+0x30], xmm3
000078e5533d518f  vmovaps [rsp+0x40], xmm4
000078e5533d5195  vmovaps [rsp+0x50], xmm5
000078e5533d519b  vmovaps [rsp+0x60], xmm6
000078e5533d51a1  vmovaps [rsp+0x70], xmm7
000078e5533d51a7  vmovaps [rsp+0x80], xmm8
000078e5533d51b0  vmovaps [rsp+0x90], xmm9
000078e5533d51b9  vmovaps [rsp+0xA0], xmm10
000078e5533d51c2  vmovaps [rsp+0xB0], xmm12
000078e5533d51cb  vmovaps [rsp+0xC0], xmm13
000078e5533d51d4  vmovaps [rsp+0xD0], xmm14
000078e5533d51dd  vmovaps [rsp+0xE0], xmm15
000078e5533d51e6  sub rsp, 0x30
000078e5533d51ea  movaps [rsp], xmm11
000078e5533d51ef  movaps [rsp+0x10], xmm12
000078e5533d51f5  movaps [rsp+0x20], xmm15
000078e5533d51fb  lea rdi, [rsp]
000078e5533d51ff  mov esi, 0x00
000078e5533d5204  mov rax, 0x5F83D5E17530
000078e5533d520e  call rax
000078e5533d5210  movaps xmm11, [rsp]
000078e5533d5215  add rsp, 0x30
000078e5533d5219  vmovaps xmm0, [rsp]
000078e5533d521e  vmovaps xmm1, [rsp+0x10]
000078e5533d5224  vmovaps xmm2, [rsp+0x20]
000078e5533d522a  vmovaps xmm3, [rsp+0x30]
000078e5533d5230  vmovaps xmm4, [rsp+0x40]
000078e5533d5236  vmovaps xmm5, [rsp+0x50]
000078e5533d523c  vmovaps xmm6, [rsp+0x60]
000078e5533d5242  vmovaps xmm7, [rsp+0x70]
000078e5533d5248  vmovaps xmm8, [rsp+0x80]
000078e5533d5251  vmovaps xmm9, [rsp+0x90]
000078e5533d525a  vmovaps xmm10, [rsp+0xA0]
000078e5533d5263  vmovaps xmm12, [rsp+0xB0]
000078e5533d526c  vmovaps xmm13, [rsp+0xC0]
000078e5533d5275  vmovaps xmm14, [rsp+0xD0]
000078e5533d527e  vmovaps xmm15, [rsp+0xE0]
000078e5533d5287  add rsp, 0xF0
000078e5533d528e  pop r11
000078e5533d5290  pop r10
000078e5533d5292  pop r9
000078e5533d5294  pop r8
000078e5533d5296  pop rsi
000078e5533d5297  pop rdi
000078e5533d5298  pop rdx
000078e5533d5299  pop rcx
000078e5533d529a  pop rax
000078e5533d529b  add rsp, 0x08
000078e5533d529f  jmp 0x000078E5533D02B9
000078e5533d52a4  sub rsp, 0x08
000078e5533d52a8  push rax
000078e5533d52a9  push rcx
000078e5533d52aa  push rdx
000078e5533d52ab  push rdi
000078e5533d52ac  push rsi
000078e5533d52ad  push r8
000078e5533d52af  push r9
000078e5533d52b1  push r10
000078e5533d52b3  push r11
000078e5533d52b5  sub rsp, 0xF0
000078e5533d52bc  vmovaps [rsp], xmm0
000078e5533d52c1  vmovaps [rsp+0x10], xmm1
000078e5533d52c7  vmovaps [rsp+0x20], xmm2
000078e5533d52cd  vmovaps [rsp+0x30], xmm3
000078e5533d52d3  vmovaps [rsp+0x40], xmm4
000078e5533d52d9  vmovaps [rsp+0x50], xmm5
000078e5533d52df  vmovaps [rsp+0x60], xmm6
000078e5533d52e5  vmovaps [rsp+0x70], xmm7
000078e5533d52eb  vmovaps [rsp+0x80], xmm8
000078e5533d52f4  vmovaps [rsp+0x90], xmm9
000078e5533d52fd  vmovaps [rsp+0xA0], xmm10
000078e5533d5306  vmovaps [rsp+0xB0], xmm11
000078e5533d530f  vmovaps [rsp+0xC0], xmm12
000078e5533d5318  vmovaps [rsp+0xD0], xmm13
000078e5533d5321  vmovaps [rsp+0xE0], xmm14
000078e5533d532a  sub rsp, 0x30
000078e5533d532e  movaps [rsp], xmm15
000078e5533d5333  movaps [rsp+0x10], xmm13
000078e5533d5339  movaps [rsp+0x20], xmm9
000078e5533d533f  lea rdi, [rsp]
000078e5533d5343  mov esi, 0x00
000078e5533d5348  mov rax, 0x5F83D5E17530
000078e5533d5352  call rax
000078e5533d5354  movaps xmm15, [rsp]
000078e5533d5359  add rsp, 0x30
000078e5533d535d  vmovaps xmm0, [rsp]
000078e5533d5362  vmovaps xmm1, [rsp+0x10]
000078e5533d5368  vmovaps xmm2, [rsp+0x20]
000078e5533d536e  vmovaps xmm3, [rsp+0x30]
000078e5533d5374  vmovaps xmm4, [rsp+0x40]
000078e5533d537a  vmovaps xmm5, [rsp+0x50]
000078e5533d5380  vmovaps xmm6, [rsp+0x60]
000078e5533d5386  vmovaps xmm7, [rsp+0x70]
000078e5533d538c  vmovaps xmm8, [rsp+0x80]
000078e5533d5395  vmovaps xmm9, [rsp+0x90]
000078e5533d539e  vmovaps xmm10, [rsp+0xA0]
000078e5533d53a7  vmovaps xmm11, [rsp+0xB0]
000078e5533d53b0  vmovaps xmm12, [rsp+0xC0]
000078e5533d53b9  vmovaps xmm13, [rsp+0xD0]
000078e5533d53c2  vmovaps xmm14, [rsp+0xE0]
000078e5533d53cb  add rsp, 0xF0
000078e5533d53d2  pop r11
000078e5533d53d4  pop r10
000078e5533d53d6  pop r9
000078e5533d53d8  pop r8
000078e5533d53da  pop rsi
000078e5533d53db  pop rdi
000078e5533d53dc  pop rdx
000078e5533d53dd  pop rcx
000078e5533d53de  pop rax
000078e5533d53df  add rsp, 0x08
000078e5533d53e3  jmp 0x000078E5533D02D4
000078e5533d53e8  sub rsp, 0x08
000078e5533d53ec  push rax
000078e5533d53ed  push rcx
000078e5533d53ee  push rdx
000078e5533d53ef  push rdi
000078e5533d53f0  push rsi
000078e5533d53f1  push r8
000078e5533d53f3  push r9
000078e5533d53f5  push r10
000078e5533d53f7  push r11
000078e5533d53f9  sub rsp, 0xF0
000078e5533d5400  vmovaps [rsp], xmm0
000078e5533d5405  vmovaps [rsp+0x10], xmm1
000078e5533d540b  vmovaps [rsp+0x20], xmm2
000078e5533d5411  vmovaps [rsp+0x30], xmm3
000078e5533d5417  vmovaps [rsp+0x40], xmm4
000078e5533d541d  vmovaps [rsp+0x50], xmm5
000078e5533d5423  vmovaps [rsp+0x60], xmm6
000078e5533d5429  vmovaps [rsp+0x70], xmm7
000078e5533d542f  vmovaps [rsp+0x80], xmm8
000078e5533d5438  vmovaps [rsp+0x90], xmm9
000078e5533d5441  vmovaps [rsp+0xA0], xmm10
000078e5533d544a  vmovaps [rsp+0xB0], xmm11
000078e5533d5453  vmovaps [rsp+0xC0], xmm12
000078e5533d545c  vmovaps [rsp+0xD0], xmm14
000078e5533d5465  vmovaps [rsp+0xE0], xmm15
000078e5533d546e  sub rsp, 0x30
000078e5533d5472  movaps [rsp], xmm13
000078e5533d5477  movaps [rsp+0x10], xmm8
000078e5533d547d  movaps [rsp+0x20], xmm14
000078e5533d5483  lea rdi, [rsp]
000078e5533d5487  mov esi, 0x00
000078e5533d548c  mov rax, 0x5F83D5E17530
000078e5533d5496  call rax
000078e5533d5498  movaps xmm13, [rsp]
000078e5533d549d  add rsp, 0x30
000078e5533d54a1  vmovaps xmm0, [rsp]
000078e5533d54a6  vmovaps xmm1, [rsp+0x10]
000078e5533d54ac  vmovaps xmm2, [rsp+0x20]
000078e5533d54b2  vmovaps xmm3, [rsp+0x30]
000078e5533d54b8  vmovaps xmm4, [rsp+0x40]
000078e5533d54be  vmovaps xmm5, [rsp+0x50]
000078e5533d54c4  vmovaps xmm6, [rsp+0x60]
000078e5533d54ca  vmovaps xmm7, [rsp+0x70]
000078e5533d54d0  vmovaps xmm8, [rsp+0x80]
000078e5533d54d9  vmovaps xmm9, [rsp+0x90]
000078e5533d54e2  vmovaps xmm10, [rsp+0xA0]
000078e5533d54eb  vmovaps xmm11, [rsp+0xB0]
000078e5533d54f4  vmovaps xmm12, [rsp+0xC0]
000078e5533d54fd  vmovaps xmm14, [rsp+0xD0]
000078e5533d5506  vmovaps xmm15, [rsp+0xE0]
000078e5533d550f  add rsp, 0xF0
000078e5533d5516  pop r11
000078e5533d5518  pop r10
000078e5533d551a  pop r9
000078e5533d551c  pop r8
000078e5533d551e  pop rsi
000078e5533d551f  pop rdi
000078e5533d5520  pop rdx
000078e5533d5521  pop rcx
000078e5533d5522  pop rax
000078e5533d5523  add rsp, 0x08
000078e5533d5527  jmp 0x000078E5533D02F7
000078e5533d552c  sub rsp, 0x08
000078e5533d5530  push rax
000078e5533d5531  push rcx
000078e5533d5532  push rdx
000078e5533d5533  push rdi
000078e5533d5534  push rsi
000078e5533d5535  push r8
000078e5533d5537  push r9
000078e5533d5539  push r10
000078e5533d553b  push r11
000078e5533d553d  sub rsp, 0xF0
000078e5533d5544  vmovaps [rsp], xmm0
000078e5533d5549  vmovaps [rsp+0x10], xmm1
000078e5533d554f  vmovaps [rsp+0x20], xmm2
000078e5533d5555  vmovaps [rsp+0x30], xmm3
000078e5533d555b  vmovaps [rsp+0x40], xmm4
000078e5533d5561  vmovaps [rsp+0x50], xmm5
000078e5533d5567  vmovaps [rsp+0x60], xmm6
000078e5533d556d  vmovaps [rsp+0x70], xmm7
000078e5533d5573  vmovaps [rsp+0x80], xmm8
000078e5533d557c  vmovaps [rsp+0x90], xmm9
000078e5533d5585  vmovaps [rsp+0xA0], xmm10
000078e5533d558e  vmovaps [rsp+0xB0], xmm11
000078e5533d5597  vmovaps [rsp+0xC0], xmm12
000078e5533d55a0  vmovaps [rsp+0xD0], xmm13
000078e5533d55a9  vmovaps [rsp+0xE0], xmm15
000078e5533d55b2  sub rsp, 0x30
000078e5533d55b6  movaps [rsp], xmm14
000078e5533d55bb  movaps [rsp+0x10], xmm1
000078e5533d55c0  movaps [rsp+0x20], xmm10
000078e5533d55c6  lea rdi, [rsp]
000078e5533d55ca  mov esi, 0x00
000078e5533d55cf  mov rax, 0x5F83D5E17530
000078e5533d55d9  call rax
000078e5533d55db  movaps xmm14, [rsp]
000078e5533d55e0  add rsp, 0x30
000078e5533d55e4  vmovaps xmm0, [rsp]
000078e5533d55e9  vmovaps xmm1, [rsp+0x10]
000078e5533d55ef  vmovaps xmm2, [rsp+0x20]
000078e5533d55f5  vmovaps xmm3, [rsp+0x30]
000078e5533d55fb  vmovaps xmm4, [rsp+0x40]
000078e5533d5601  vmovaps xmm5, [rsp+0x50]
000078e5533d5607  vmovaps xmm6, [rsp+0x60]
000078e5533d560d  vmovaps xmm7, [rsp+0x70]
000078e5533d5613  vmovaps xmm8, [rsp+0x80]
000078e5533d561c  vmovaps xmm9, [rsp+0x90]
000078e5533d5625  vmovaps xmm10, [rsp+0xA0]
000078e5533d562e  vmovaps xmm11, [rsp+0xB0]
000078e5533d5637  vmovaps xmm12, [rsp+0xC0]
000078e5533d5640  vmovaps xmm13, [rsp+0xD0]
000078e5533d5649  vmovaps xmm15, [rsp+0xE0]
000078e5533d5652  add rsp, 0xF0
000078e5533d5659  pop r11
000078e5533d565b  pop r10
000078e5533d565d  pop r9
000078e5533d565f  pop r8
000078e5533d5661  pop rsi
000078e5533d5662  pop rdi
000078e5533d5663  pop rdx
000078e5533d5664  pop rcx
000078e5533d5665  pop rax
000078e5533d5666  add rsp, 0x08
000078e5533d566a  jmp 0x000078E5533D031A
000078e5533d566f  sub rsp, 0x08
000078e5533d5673  push rax
000078e5533d5674  push rcx
000078e5533d5675  push rdx
000078e5533d5676  push rdi
000078e5533d5677  push rsi
000078e5533d5678  push r8
000078e5533d567a  push r9
000078e5533d567c  push r10
000078e5533d567e  push r11
000078e5533d5680  sub rsp, 0xF0
000078e5533d5687  vmovaps [rsp], xmm0
000078e5533d568c  vmovaps [rsp+0x10], xmm2
000078e5533d5692  vmovaps [rsp+0x20], xmm3
000078e5533d5698  vmovaps [rsp+0x30], xmm4
000078e5533d569e  vmovaps [rsp+0x40], xmm5
000078e5533d56a4  vmovaps [rsp+0x50], xmm6
000078e5533d56aa  vmovaps [rsp+0x60], xmm7
000078e5533d56b0  vmovaps [rsp+0x70], xmm8
000078e5533d56b6  vmovaps [rsp+0x80], xmm9
000078e5533d56bf  vmovaps [rsp+0x90], xmm10
000078e5533d56c8  vmovaps [rsp+0xA0], xmm11
000078e5533d56d1  vmovaps [rsp+0xB0], xmm12
000078e5533d56da  vmovaps [rsp+0xC0], xmm13
000078e5533d56e3  vmovaps [rsp+0xD0], xmm14
000078e5533d56ec  vmovaps [rsp+0xE0], xmm15
000078e5533d56f5  sub rsp, 0x30
000078e5533d56f9  movaps [rsp], xmm1
000078e5533d56fd  movaps [rsp+0x10], xmm7
000078e5533d5702  movaps [rsp+0x20], xmm11
000078e5533d5708  lea rdi, [rsp]
000078e5533d570c  mov esi, 0x00
000078e5533d5711  mov rax, 0x5F83D5E17530
000078e5533d571b  call rax
000078e5533d571d  movaps xmm1, [rsp]
000078e5533d5721  add rsp, 0x30
000078e5533d5725  vmovaps xmm0, [rsp]
000078e5533d572a  vmovaps xmm2, [rsp+0x10]
000078e5533d5730  vmovaps xmm3, [rsp+0x20]
000078e5533d5736  vmovaps xmm4, [rsp+0x30]
000078e5533d573c  vmovaps xmm5, [rsp+0x40]
000078e5533d5742  vmovaps xmm6, [rsp+0x50]
000078e5533d5748  vmovaps xmm7, [rsp+0x60]
000078e5533d574e  vmovaps xmm8, [rsp+0x70]
000078e5533d5754  vmovaps xmm9, [rsp+0x80]
000078e5533d575d  vmovaps xmm10, [rsp+0x90]
000078e5533d5766  vmovaps xmm11, [rsp+0xA0]
000078e5533d576f  vmovaps xmm12, [rsp+0xB0]
000078e5533d5778  vmovaps xmm13, [rsp+0xC0]
000078e5533d5781  vmovaps xmm14, [rsp+0xD0]
000078e5533d578a  vmovaps xmm15, [rsp+0xE0]
000078e5533d5793  add rsp, 0xF0
000078e5533d579a  pop r11
000078e5533d579c  pop r10
000078e5533d579e  pop r9
000078e5533d57a0  pop r8
000078e5533d57a2  pop rsi
000078e5533d57a3  pop rdi
000078e5533d57a4  pop rdx
000078e5533d57a5  pop rcx
000078e5533d57a6  pop rax
000078e5533d57a7  add rsp, 0x08
000078e5533d57ab  jmp 0x000078E5533D033B
000078e5533d57b0  call 0x000078E55320E880
000078e5533d57b5  jmp 0x000078E5533D034E
000078e5533d57ba  call 0x000078E55320C380
000078e5533d57bf  jmp 0x000078E5533D0359
000078e5533d57c4  call 0x000078E55320D600
000078e5533d57c9  jmp 0x000078E5533D0364
000078e5533d57ce  call 0x000078E5531FF540
000078e5533d57d3  jmp 0x000078E5533D036F
000078e5533d57d8  int3
000078e5533d57d9  nop [rax], eax
000078e5533d57e0  mov rax, [r15+0x40]
000078e5533d57e4  mov r14, [r15+0x58]
000078e5533d57e8  lea r12, [rax+r14*1]
000078e5533d57ec  movaps xmm1, [r15+0x1D0]
000078e5533d57f4  vmovaps [rsp+0x10], xmm1
000078e5533d57fa  vmovaps xmm15, [rsp+0x10]
000078e5533d5800  por xmm1, xmm15
000078e5533d5805  movaps xmm14, [r15+0x1A0]
000078e5533d580d  vmovaps [rsp+0x10], xmm14
000078e5533d5813  vmovaps xmm13, [rsp+0x10]
000078e5533d5819  por xmm14, xmm13
000078e5533d581e  lea rax, [r12+0x30]
000078e5533d5823  mov r11, [r13+rax*1]
000078e5533d5828  lea rax, [r12+0x38]
000078e5533d582d  mov r10, [r13+rax*1]
000078e5533d5832  movq xmm13, r11
000078e5533d5837  movq xmm12, r10
000078e5533d583c  movq xmm13, xmm13
000078e5533d5841  vmovaps [rsp+0x10], xmm13
000078e5533d5847  movq xmm13, xmm13
000078e5533d584c  movaps [r15+0x130], xmm13
000078e5533d5854  movq xmm12, xmm12
000078e5533d5859  vmovaps [rsp+0x20], xmm12
000078e5533d585f  movq xmm12, xmm12
000078e5533d5864  movaps [r15+0x280], xmm12
000078e5533d586c  movaps xmm13, [r15+0x270]
000078e5533d5874  vmovaps [rsp+0x30], xmm13
000078e5533d587a  vmovaps xmm12, [rsp+0x30]
000078e5533d5880  por xmm13, xmm12
000078e5533d5885  lea rax, [r12+0x20]
000078e5533d588a  mov r11, [r13+rax*1]
000078e5533d588f  lea rax, [r12+0x28]
000078e5533d5894  mov r10, [r13+rax*1]
000078e5533d5899  movq xmm12, r11
000078e5533d589e  movq xmm11, r10
000078e5533d58a3  movq xmm12, xmm12
000078e5533d58a8  vmovaps [rsp+0x30], xmm12
000078e5533d58ae  movq xmm12, xmm12
000078e5533d58b3  movaps [r15+0x150], xmm12
000078e5533d58bb  movq xmm11, xmm11
000078e5533d58c0  vmovaps [rsp+0x40], xmm11
000078e5533d58c6  movq xmm11, xmm11
000078e5533d58cb  movaps [r15+0x140], xmm11
000078e5533d58d3  lea rax, [r12+0x10]
000078e5533d58d8  mov r11, [r13+rax*1]
000078e5533d58dd  lea rax, [r12+0x18]
000078e5533d58e2  mov r10, [r13+rax*1]
000078e5533d58e7  movq xmm12, r11
000078e5533d58ec  movq xmm11, r10
000078e5533d58f1  movq xmm12, xmm12
000078e5533d58f6  vmovaps [rsp+0x50], xmm12
000078e5533d58fc  movq xmm12, xmm12
000078e5533d5901  movaps [r15+0x170], xmm12
000078e5533d5909  movq xmm11, xmm11
000078e5533d590e  vmovaps [rsp+0x60], xmm11
000078e5533d5914  movq xmm11, xmm11
000078e5533d5919  movaps [r15+0x160], xmm11
000078e5533d5921  mov rax, [r13+r12*1]
000078e5533d5926  vmovq xmm12, rax
000078e5533d592b  vpbroadcastq xmm12, xmm12
000078e5533d5930  lea rax, [r12+0x08]
000078e5533d5935  mov r12, [r13+rax*1]
000078e5533d593a  movq xmm11, r12
000078e5533d593f  movaps [r15+0x230], xmm11
000078e5533d5947  mov rax, [r15+0xF8]
000078e5533d594e  lea r12, [rax+0x50]
000078e5533d5952  movups xmm11, [r13+r12*1]
000078e5533d5958  lea r12, [rax+0x60]
000078e5533d595c  movups xmm10, [r13+r12*1]
000078e5533d5962  lea r12, [rax+0x30]
000078e5533d5966  movups xmm9, [r13+r12*1]
000078e5533d596c  mov r12, [r15+0x50]
000078e5533d5970  lea r11, [r12+r14*1]
000078e5533d5974  mov [r15+0x60], r11
000078e5533d5978  lea r12, [r14+0x40]
000078e5533d597c  mov [r15+0x58], r12
000078e5533d5980  movaps xmm8, xmm12
000078e5533d5984  mulpd xmm8, xmm15
000078e5533d5989  vcmppd xmm7, xmm8, xmm8, 0x03
000078e5533d598f  ptest xmm7, xmm7
000078e5533d5994  jnz 0x000078E5533D67B7
000078e5533d599a  movq xmm15, qword ptr [r15+0x230]
000078e5533d59a3  vmovaps [rsp+0x70], xmm15
000078e5533d59a9  vpermilpd xmm15, xmm15, 0x00
000078e5533d59af  movaps xmm7, xmm9
000078e5533d59b3  mulpd xmm7, xmm15
000078e5533d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000078e5533d59bd  ptest xmm6, xmm6
000078e5533d59c2  jnz 0x000078E5533D68FB
000078e5533d59c8  vxorps xmm15, xmm15, xmm15
000078e5533d59cd  vpbroadcastq xmm15, xmm15
000078e5533d59d2  movaps xmm9, xmm12
000078e5533d59d6  mulpd xmm9, xmm10
000078e5533d59db  vcmppd xmm6, xmm9, xmm9, 0x03
000078e5533d59e1  ptest xmm6, xmm6
000078e5533d59e6  jnz 0x000078E5533D6A3D
000078e5533d59ec  movaps xmm10, xmm12
000078e5533d59f0  mulpd xmm10, xmm11
000078e5533d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000078e5533d59fb  ptest xmm6, xmm6
000078e5533d5a00  jnz 0x000078E5533D6B81
000078e5533d5a06  movaps xmm11, [r15+0x1F0]
000078e5533d5a0e  movaps xmm6, xmm12
000078e5533d5a12  mulpd xmm6, xmm11
000078e5533d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000078e5533d5a1c  ptest xmm5, xmm5
000078e5533d5a21  jnz 0x000078E5533D6CC5
000078e5533d5a27  movaps xmm12, [r15+0x2A0]
000078e5533d5a2f  vmovaps [rsp+0x80], xmm12
000078e5533d5a38  vmovaps xmm11, [rsp+0x80]
000078e5533d5a41  por xmm12, xmm11
000078e5533d5a46  movaps xmm11, [r15+0x250]
000078e5533d5a4e  vmovaps [rsp+0x80], xmm11
000078e5533d5a57  vmovaps xmm5, [rsp+0x80]
000078e5533d5a60  por xmm11, xmm5
000078e5533d5a65  vmovaps xmm4, [rsp+0x70]
000078e5533d5a6b  vpermilpd xmm4, xmm4, 0x00
000078e5533d5a71  movaps xmm3, xmm5
000078e5533d5a74  mulpd xmm3, xmm4
000078e5533d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000078e5533d5a7d  ptest xmm2, xmm2
000078e5533d5a82  jnz 0x000078E5533D6E07
000078e5533d5a88  mov [rsp+0x80], rax
000078e5533d5a90  xor eax, eax
000078e5533d5a92  mov r14d, 0x200
000078e5533d5a98  cmp r12, r14
000078e5533d5a9b  cmc
000078e5533d5a9c  lahf
000078e5533d5a9d  seto al
000078e5533d5aa0  mov [r15+0x108], eax
000078e5533d5aa7  movaps xmm5, xmm8
000078e5533d5aab  addpd xmm5, xmm15
000078e5533d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000078e5533d5ab5  ptest xmm4, xmm4
000078e5533d5aba  jnz 0x000078E5533D6F47
000078e5533d5ac0  movaps xmm8, [r15+0x1B0]
000078e5533d5ac8  movaps xmm4, xmm9
000078e5533d5acc  addpd xmm4, xmm8
000078e5533d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000078e5533d5ad6  ptest xmm2, xmm2
000078e5533d5adb  jnz 0x000078E5533D7089
000078e5533d5ae1  movaps xmm9, xmm10
000078e5533d5ae5  addpd xmm9, xmm8
000078e5533d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000078e5533d5af0  ptest xmm2, xmm2
000078e5533d5af5  jnz 0x000078E5533D71CB
000078e5533d5afb  movaps xmm10, [r15+0x2F0]
000078e5533d5b03  vmovaps [rsp+0x90], xmm10
000078e5533d5b0c  vmovaps xmm8, [rsp+0x90]
000078e5533d5b15  por xmm10, xmm8
000078e5533d5b1a  movaps xmm8, [r15+0x2E0]
000078e5533d5b22  vmovaps [rsp+0x90], xmm8
000078e5533d5b2b  vmovaps xmm2, [rsp+0x90]
000078e5533d5b34  por xmm8, xmm2
000078e5533d5b39  movaps xmm2, [r15+0x2D0]
000078e5533d5b41  vmovaps [rsp+0x90], xmm2
000078e5533d5b4a  vmovaps [rsp+0xA0], xmm1
000078e5533d5b53  vmovaps xmm1, [rsp+0x90]
000078e5533d5b5c  por xmm2, xmm1
000078e5533d5b60  movaps xmm1, [r15+0x200]
000078e5533d5b68  vmovaps [rsp+0x90], xmm1
000078e5533d5b71  vmovaps [rsp+0xB0], xmm15
000078e5533d5b7a  vmovaps xmm15, [rsp+0x90]
000078e5533d5b83  por xmm1, xmm15
000078e5533d5b88  movaps xmm15, [r15+0x1C0]
000078e5533d5b90  vmovaps [rsp+0x90], xmm15
000078e5533d5b99  vmovaps [rsp+0xC0], xmm1
000078e5533d5ba2  vmovaps xmm1, [rsp+0x90]
000078e5533d5bab  por xmm15, xmm1
000078e5533d5bb0  movaps xmm1, [r15+0x190]
000078e5533d5bb8  vmovaps [rsp+0x90], xmm1
000078e5533d5bc1  vmovaps [rsp+0xD0], xmm15
000078e5533d5bca  vmovaps xmm15, [rsp+0x90]
000078e5533d5bd3  por xmm1, xmm15
000078e5533d5bd8  movaps xmm15, [r15+0x300]
000078e5533d5be0  vmovaps [rsp+0x90], xmm15
000078e5533d5be9  vmovaps [rsp+0xE0], xmm1
000078e5533d5bf2  vmovaps xmm1, [rsp+0x90]
000078e5533d5bfb  por xmm15, xmm1
000078e5533d5c00  mov rax, [rsp+0x80]
000078e5533d5c08  lea r14, [rax+0xA0]
000078e5533d5c0f  movups xmm1, [r13+r14*1]
000078e5533d5c15  lea r14, [rax+0xB0]
000078e5533d5c1c  vmovaps [rsp+0x80], xmm1
000078e5533d5c25  movups xmm1, [r13+r14*1]
000078e5533d5c2b  vmovaps [rsp+0x90], xmm1
000078e5533d5c34  vmovaps [rsp+0xF0], xmm15
000078e5533d5c3d  vmovaps xmm15, [rsp+0xB0]
000078e5533d5c46  vmovaps [rsp+0xB0], xmm14
000078e5533d5c4f  movaps xmm1, xmm6
000078e5533d5c52  addpd xmm1, xmm15
000078e5533d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000078e5533d5c5c  ptest xmm14, xmm14
000078e5533d5c62  jnz 0x000078E5533D7323
000078e5533d5c68  lea r14, [rax+0xF0]
000078e5533d5c6f  movups xmm15, [r13+r14*1]
000078e5533d5c75  movaps xmm14, xmm4
000078e5533d5c79  addpd xmm14, xmm3
000078e5533d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000078e5533d5c84  ptest xmm6, xmm6
000078e5533d5c89  jnz 0x000078E5533D746E
000078e5533d5c8f  movaps xmm6, xmm9
000078e5533d5c93  addpd xmm6, xmm7
000078e5533d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000078e5533d5c9c  ptest xmm4, xmm4
000078e5533d5ca1  jnz 0x000078E5533D75B0
000078e5533d5ca7  vmovaps xmm9, [rsp+0x70]
000078e5533d5cad  vpermilpd xmm9, xmm9, 0x00
000078e5533d5cb3  vmovaps xmm4, [rsp+0x90]
000078e5533d5cbc  movaps xmm7, xmm4
000078e5533d5cbf  mulpd xmm7, xmm9
000078e5533d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000078e5533d5cc9  ptest xmm3, xmm3
000078e5533d5cce  jnz 0x000078E5533D76F1
000078e5533d5cd4  vmovaps xmm9, [rsp+0x50]
000078e5533d5cda  vpermilpd xmm9, xmm9, 0x00
000078e5533d5ce0  movaps xmm4, xmm15
000078e5533d5ce4  mulpd xmm4, xmm9
000078e5533d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000078e5533d5cee  ptest xmm3, xmm3
000078e5533d5cf3  jnz 0x000078E5533D7832
000078e5533d5cf9  lea r14, [rax+0xE0]
000078e5533d5d00  movups xmm15, [r13+r14*1]
000078e5533d5d06  vmovaps xmm9, [rsp+0x70]
000078e5533d5d0c  vpermilpd xmm9, xmm9, 0x00
000078e5533d5d12  vmovaps [rsp+0x70], xmm1
000078e5533d5d18  vmovaps xmm1, [rsp+0x80]
000078e5533d5d21  vmovaps [rsp+0x80], xmm15
000078e5533d5d2a  movaps xmm3, xmm1
000078e5533d5d2d  mulpd xmm3, xmm9
000078e5533d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000078e5533d5d37  ptest xmm15, xmm15
000078e5533d5d3d  jnz 0x000078E5533D797E
000078e5533d5d43  vmovaps xmm1, [rsp+0xF0]
000078e5533d5d4c  vmovaps xmm15, [rsp+0xF0]
000078e5533d5d55  por xmm1, xmm15
000078e5533d5d5a  movaps [r15+0x300], xmm1
000078e5533d5d62  vmovaps xmm15, [rsp+0xE0]
000078e5533d5d6b  vmovaps xmm9, [rsp+0xE0]
000078e5533d5d74  por xmm15, xmm9
000078e5533d5d79  movaps [r15+0x190], xmm15
000078e5533d5d81  vmovaps xmm9, [rsp+0x50]
000078e5533d5d87  vpermilpd xmm9, xmm9, 0x00
000078e5533d5d8d  vmovaps [rsp+0x90], xmm1
000078e5533d5d96  vmovaps [rsp+0xE0], xmm15
000078e5533d5d9f  vmovaps xmm15, [rsp+0x80]
000078e5533d5da8  vmovaps [rsp+0x80], xmm14
000078e5533d5db1  movaps xmm1, xmm15
000078e5533d5db5  mulpd xmm1, xmm9
000078e5533d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000078e5533d5dbf  ptest xmm14, xmm14
000078e5533d5dc5  jnz 0x000078E5533D7ABF
000078e5533d5dcb  lea r14, [rax+0x90]
000078e5533d5dd2  movups xmm15, [r13+r14*1]
000078e5533d5dd8  vmovaps xmm14, [rsp+0xD0]
000078e5533d5de1  vmovaps xmm9, [rsp+0xD0]
000078e5533d5dea  por xmm14, xmm9
000078e5533d5def  movaps [r15+0x1C0], xmm14
000078e5533d5df7  vmovaps xmm9, [rsp+0xC0]
000078e5533d5e00  vmovaps [rsp+0xD0], xmm1
000078e5533d5e09  vmovaps xmm1, [rsp+0xC0]
000078e5533d5e12  por xmm9, xmm1
000078e5533d5e17  movaps [r15+0x200], xmm9
000078e5533d5e1f  vmovaps [rsp+0xC0], xmm2
000078e5533d5e28  vmovaps xmm1, [rsp+0xC0]
000078e5533d5e31  por xmm2, xmm1
000078e5533d5e35  movaps [r15+0x2D0], xmm2
000078e5533d5e3d  vmovaps [rsp+0xC0], xmm8
000078e5533d5e46  vmovaps xmm1, [rsp+0xC0]
000078e5533d5e4f  por xmm8, xmm1
000078e5533d5e54  movaps [r15+0x2E0], xmm8
000078e5533d5e5c  vmovaps [rsp+0xC0], xmm15
000078e5533d5e65  movaps xmm1, xmm5
000078e5533d5e68  addpd xmm1, xmm7
000078e5533d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000078e5533d5e71  ptest xmm15, xmm15
000078e5533d5e77  jnz 0x000078E5533D7C0B
000078e5533d5e7d  vmovaps xmm15, [rsp+0x50]
000078e5533d5e83  vpermilpd xmm15, xmm15, 0x00
000078e5533d5e89  vmovaps xmm5, [rsp+0xC0]
000078e5533d5e92  vmovaps [rsp+0xC0], xmm1
000078e5533d5e9b  movaps xmm7, xmm5
000078e5533d5e9e  mulpd xmm7, xmm15
000078e5533d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000078e5533d5ea8  ptest xmm1, xmm1
000078e5533d5ead  jnz 0x000078E5533D7D4B
000078e5533d5eb3  lea r14, [rax+0x80]
000078e5533d5eba  movups xmm1, [r13+r14*1]
000078e5533d5ec0  vmovaps xmm5, [rsp+0x70]
000078e5533d5ec6  vmovaps [rsp+0x70], xmm1
000078e5533d5ecc  movaps xmm15, xmm5
000078e5533d5ed0  addpd xmm15, xmm3
000078e5533d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000078e5533d5edb  ptest xmm1, xmm1
000078e5533d5ee0  jnz 0x000078E5533D7E96
000078e5533d5ee6  vmovaps xmm5, [rsp+0x80]
000078e5533d5eef  movaps xmm1, xmm5
000078e5533d5ef2  addpd xmm1, xmm4
000078e5533d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000078e5533d5efb  ptest xmm3, xmm3
000078e5533d5f00  jnz 0x000078E5533D7FD8
000078e5533d5f06  vmovaps [rsp+0x80], xmm10
000078e5533d5f0f  vmovaps xmm5, [rsp+0x80]
000078e5533d5f18  por xmm10, xmm5
000078e5533d5f1d  movaps [r15+0x2F0], xmm10
000078e5533d5f25  vmovaps xmm5, [rsp+0x50]
000078e5533d5f2b  vpermilpd xmm5, xmm5, 0x00
000078e5533d5f31  vmovaps xmm3, [rsp+0x70]
000078e5533d5f37  vmovaps [rsp+0x50], xmm1
000078e5533d5f3d  movaps xmm4, xmm3
000078e5533d5f40  mulpd xmm4, xmm5
000078e5533d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000078e5533d5f49  ptest xmm1, xmm1
000078e5533d5f4e  jnz 0x000078E5533D8118
000078e5533d5f54  lea r14, [rax+0xD0]
000078e5533d5f5b  movups xmm1, [r13+r14*1]
000078e5533d5f61  vmovaps xmm3, [rsp+0xD0]
000078e5533d5f6a  vmovaps [rsp+0x70], xmm1
000078e5533d5f70  movaps xmm5, xmm6
000078e5533d5f73  addpd xmm5, xmm3
000078e5533d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000078e5533d5f7c  ptest xmm1, xmm1
000078e5533d5f81  jnz 0x000078E5533D8262
000078e5533d5f87  vmovaps xmm1, [rsp+0x60]
000078e5533d5f8d  vpermilpd xmm1, xmm1, 0x00
000078e5533d5f93  movaps xmm6, xmm9
000078e5533d5f97  mulpd xmm6, xmm1
000078e5533d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000078e5533d5fa0  ptest xmm3, xmm3
000078e5533d5fa5  jnz 0x000078E5533D83A2
000078e5533d5fab  movaps [r15+0x260], xmm6
000078e5533d5fb3  vxorps xmm1, xmm1, xmm1
000078e5533d5fb7  vpbroadcastq xmm1, xmm1
000078e5533d5fbc  movaps [r15+0x1B0], xmm1
000078e5533d5fc4  vmovaps xmm1, [rsp+0x60]
000078e5533d5fca  vpermilpd xmm1, xmm1, 0x00
000078e5533d5fd0  vmovaps xmm3, [rsp+0x70]
000078e5533d5fd6  vmovaps [rsp+0x70], xmm15
000078e5533d5fdc  movaps xmm9, xmm3
000078e5533d5fe0  mulpd xmm9, xmm1
000078e5533d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000078e5533d5feb  ptest xmm15, xmm15
000078e5533d5ff1  jnz 0x000078E5533D84E3
000078e5533d5ff7  lea r14, [rax+0xC0]
000078e5533d5ffe  movups xmm1, [r13+r14*1]
000078e5533d6004  vmovaps xmm3, [rsp+0xC0]
000078e5533d600d  vmovaps [rsp+0x80], xmm1
000078e5533d6016  movaps xmm15, xmm3
000078e5533d601a  addpd xmm15, xmm7
000078e5533d601f  vcmppd xmm1, xmm15, xmm15, 0x03
000078e5533d6025  ptest xmm1, xmm1
000078e5533d602a  jnz 0x000078E5533D862F
000078e5533d6030  vmovaps [rsp+0xC0], xmm13
000078e5533d6039  vmovaps xmm1, [rsp+0xC0]
000078e5533d6042  por xmm13, xmm1
000078e5533d6047  movaps [r15+0x270], xmm13
000078e5533d604f  vmovaps xmm1, [rsp+0xB0]
000078e5533d6058  vmovaps xmm7, [rsp+0xB0]
000078e5533d6061  por xmm1, xmm7
000078e5533d6065  movaps [r15+0x1A0], xmm1
000078e5533d606d  vmovaps xmm1, [rsp+0x60]
000078e5533d6073  vpermilpd xmm1, xmm1, 0x00
000078e5533d6079  vmovaps [rsp+0xB0], xmm1
000078e5533d6082  vmovaps xmm1, [rsp+0x80]
000078e5533d608b  vmovaps [rsp+0x80], xmm15
000078e5533d6094  vmovaps xmm15, [rsp+0xB0]
000078e5533d609d  vmovaps [rsp+0xB0], xmm14
000078e5533d60a6  movaps xmm3, xmm1
000078e5533d60a9  mulpd xmm3, xmm15
000078e5533d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000078e5533d60b3  ptest xmm14, xmm14
000078e5533d60b9  jnz 0x000078E5533D8771
000078e5533d60bf  lea r14, [rax+0x20]
000078e5533d60c3  movups xmm1, [r13+r14*1]
000078e5533d60c9  movaps [r15+0x110], xmm1
000078e5533d60d1  vmovaps xmm14, [rsp+0x70]
000078e5533d60d7  vmovaps [rsp+0x70], xmm1
000078e5533d60dd  movaps xmm15, xmm14
000078e5533d60e1  addpd xmm15, xmm4
000078e5533d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000078e5533d60ec  ptest xmm1, xmm1
000078e5533d60f1  jnz 0x000078E5533D88BC
000078e5533d60f7  vmovaps xmm1, [rsp+0x60]
000078e5533d60fd  vpermilpd xmm1, xmm1, 0x00
000078e5533d6103  movaps xmm14, xmm2
000078e5533d6107  mulpd xmm14, xmm1
000078e5533d610c  vcmppd xmm4, xmm14, xmm14, 0x03
000078e5533d6112  ptest xmm4, xmm4
000078e5533d6117  jnz 0x000078E5533D89FF
000078e5533d611d  vmovaps xmm4, [rsp+0x50]
000078e5533d6123  movaps xmm1, xmm4
000078e5533d6126  addpd xmm1, xmm9
000078e5533d612b  vcmppd xmm2, xmm1, xmm1, 0x03
000078e5533d6130  ptest xmm2, xmm2
000078e5533d6135  jnz 0x000078E5533D8B41
000078e5533d613b  vmovaps xmm9, [rsp+0x30]
000078e5533d6141  vpermilpd xmm9, xmm9, 0x00
000078e5533d6147  vmovaps xmm2, [rsp+0x70]
000078e5533d614d  vmovaps [rsp+0x50], xmm1
000078e5533d6153  movaps xmm4, xmm2
000078e5533d6156  mulpd xmm4, xmm9
000078e5533d615b  vcmppd xmm1, xmm4, xmm4, 0x03
000078e5533d6160  ptest xmm1, xmm1
000078e5533d6165  jnz 0x000078E5533D8C82
000078e5533d616b  vmovaps xmm1, [rsp+0x30]
000078e5533d6171  vpermilpd xmm1, xmm1, 0x00
000078e5533d6177  vmovaps xmm2, [rsp+0x90]
000078e5533d6180  vmovaps [rsp+0x60], xmm15
000078e5533d6186  movaps xmm9, xmm2
000078e5533d618a  mulpd xmm9, xmm1
000078e5533d618f  vcmppd xmm15, xmm9, xmm9, 0x03
000078e5533d6195  ptest xmm15, xmm15
000078e5533d619b  jnz 0x000078E5533D8DC3
000078e5533d61a1  vmovaps xmm15, [rsp+0x80]
000078e5533d61aa  movaps xmm1, xmm15
000078e5533d61ae  addpd xmm1, xmm6
000078e5533d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000078e5533d61b7  ptest xmm2, xmm2
000078e5533d61bc  jnz 0x000078E5533D8F05
000078e5533d61c2  movaps xmm15, xmm5
000078e5533d61c6  addpd xmm15, xmm3
000078e5533d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000078e5533d61d1  ptest xmm6, xmm6
000078e5533d61d6  jnz 0x000078E5533D9046
000078e5533d61dc  vmovaps xmm6, [rsp+0x30]
000078e5533d61e2  vpermilpd xmm6, xmm6, 0x00
000078e5533d61e8  movaps xmm5, xmm8
000078e5533d61ec  mulpd xmm5, xmm6
000078e5533d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000078e5533d61f5  ptest xmm3, xmm3
000078e5533d61fa  jnz 0x000078E5533D9188
000078e5533d6200  vmovaps xmm8, [rsp+0x30]
000078e5533d6206  vpermilpd xmm8, xmm8, 0x00
000078e5533d620c  movaps xmm6, xmm10
000078e5533d6210  mulpd xmm6, xmm8
000078e5533d6215  vcmppd xmm3, xmm6, xmm6, 0x03
000078e5533d621a  ptest xmm3, xmm3
000078e5533d621f  jnz 0x000078E5533D92C9
000078e5533d6225  vmovaps xmm8, [rsp+0x60]
000078e5533d622b  movaps xmm10, xmm8
000078e5533d622f  addpd xmm10, xmm14
000078e5533d6234  vcmppd xmm3, xmm10, xmm10, 0x03
000078e5533d623a  ptest xmm3, xmm3
000078e5533d623f  jnz 0x000078E5533D940B
000078e5533d6245  vmovaps xmm8, [rsp+0x50]
000078e5533d624b  movaps xmm14, xmm8
000078e5533d624f  addpd xmm14, xmm4
000078e5533d6254  vcmppd xmm3, xmm14, xmm14, 0x03
000078e5533d625a  ptest xmm3, xmm3
000078e5533d625f  jnz 0x000078E5533D954F
000078e5533d6265  vmovaps xmm8, [rsp+0x40]
000078e5533d626b  vpermilpd xmm8, xmm8, 0x00
000078e5533d6271  movaps xmm4, xmm13
000078e5533d6275  mulpd xmm4, xmm8
000078e5533d627a  vcmppd xmm3, xmm4, xmm4, 0x03
000078e5533d627f  ptest xmm3, xmm3
000078e5533d6284  jnz 0x000078E5533D9692
000078e5533d628a  movaps xmm13, xmm15
000078e5533d628e  addpd xmm13, xmm9
000078e5533d6293  vcmppd xmm8, xmm13, xmm13, 0x03
000078e5533d6299  ptest xmm8, xmm8
000078e5533d629f  jnz 0x000078E5533D97D4
000078e5533d62a5  movaps xmm15, xmm1
000078e5533d62a9  addpd xmm15, xmm5
000078e5533d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000078e5533d62b4  ptest xmm9, xmm9
000078e5533d62ba  jnz 0x000078E5533D9918
000078e5533d62c0  vmovaps [rsp+0x30], xmm11
000078e5533d62c6  vmovaps xmm1, [rsp+0x30]
000078e5533d62cc  por xmm11, xmm1
000078e5533d62d1  movaps [r15+0x250], xmm11
000078e5533d62d9  vmovaps [rsp+0x30], xmm12
000078e5533d62df  vmovaps xmm1, [rsp+0x30]
000078e5533d62e5  por xmm12, xmm1
000078e5533d62ea  movaps [r15+0x2A0], xmm12
000078e5533d62f2  vmovaps xmm1, [rsp+0xA0]
000078e5533d62fb  vmovaps xmm11, [rsp+0xA0]
000078e5533d6304  por xmm1, xmm11
000078e5533d6309  movaps [r15+0x1D0], xmm1
000078e5533d6311  lea r14, [rax+0x40]
000078e5533d6315  movups xmm1, [r13+r14*1]
000078e5533d631b  movaps [r15+0x2C0], xmm1
000078e5533d6323  vmovaps xmm11, [rsp+0x40]
000078e5533d6329  vpermilpd xmm11, xmm11, 0x00
000078e5533d632f  vmovaps xmm8, [rsp+0xE0]
000078e5533d6338  movaps xmm9, xmm8
000078e5533d633c  mulpd xmm9, xmm11
000078e5533d6341  vcmppd xmm5, xmm9, xmm9, 0x03
000078e5533d6347  ptest xmm5, xmm5
000078e5533d634c  jnz 0x000078E5533D9A64
000078e5533d6352  movaps xmm11, xmm10
000078e5533d6356  addpd xmm11, xmm6
000078e5533d635b  vcmppd xmm8, xmm11, xmm11, 0x03
000078e5533d6361  ptest xmm8, xmm8
000078e5533d6367  jnz 0x000078E5533D9BA8
000078e5533d636d  movaps xmm10, xmm14
000078e5533d6371  addpd xmm10, xmm4
000078e5533d6376  vcmppd xmm8, xmm10, xmm10, 0x03
000078e5533d637c  ptest xmm8, xmm8
000078e5533d6382  jnz 0x000078E5533D9CEB
000078e5533d6388  vmovaps xmm14, [rsp+0x40]
000078e5533d638e  vpermilpd xmm14, xmm14, 0x00
000078e5533d6394  movaps xmm8, xmm1
000078e5533d6398  mulpd xmm8, xmm14
000078e5533d639d  vcmppd xmm6, xmm8, xmm8, 0x03
000078e5533d63a3  ptest xmm6, xmm6
000078e5533d63a8  jnz 0x000078E5533D9E2E
000078e5533d63ae  movaps xmm1, [r15+0x2B0]
000078e5533d63b6  vmovaps xmm14, [rsp+0x40]
000078e5533d63bc  vpermilpd xmm14, xmm14, 0x00
000078e5533d63c2  movaps xmm6, xmm1
000078e5533d63c5  mulpd xmm6, xmm14
000078e5533d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000078e5533d63cf  ptest xmm5, xmm5
000078e5533d63d4  jnz 0x000078E5533D9F71
000078e5533d63da  vmovaps xmm1, [rsp+0x10]
000078e5533d63e0  vpermilpd xmm1, xmm1, 0x00
000078e5533d63e6  movaps xmm14, xmm12
000078e5533d63ea  mulpd xmm14, xmm1
000078e5533d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000078e5533d63f5  ptest xmm5, xmm5
000078e5533d63fa  jnz 0x000078E5533DA0B2
000078e5533d6400  movaps xmm1, xmm13
000078e5533d6404  addpd xmm1, xmm9
000078e5533d6409  vcmppd xmm12, xmm1, xmm1, 0x03
000078e5533d640e  ptest xmm12, xmm12
000078e5533d6414  jnz 0x000078E5533DA1F5
000078e5533d641a  vmovaps xmm13, [rsp+0x10]
000078e5533d6420  vpermilpd xmm13, xmm13, 0x00
000078e5533d6426  movaps xmm12, xmm7
000078e5533d642a  mulpd xmm12, xmm13
000078e5533d642f  vcmppd xmm9, xmm12, xmm12, 0x03
000078e5533d6435  ptest xmm9, xmm9
000078e5533d643b  jnz 0x000078E5533DA337
000078e5533d6441  movaps xmm13, xmm15
000078e5533d6445  addpd xmm13, xmm8
000078e5533d644a  vcmppd xmm9, xmm13, xmm13, 0x03
000078e5533d6450  ptest xmm9, xmm9
000078e5533d6456  jnz 0x000078E5533DA47A
000078e5533d645c  movaps xmm15, [r15+0x290]
000078e5533d6464  vmovaps xmm9, [rsp+0x10]
000078e5533d646a  vpermilpd xmm9, xmm9, 0x00
000078e5533d6470  movaps xmm8, xmm15
000078e5533d6474  mulpd xmm8, xmm9
000078e5533d6479  vcmppd xmm7, xmm8, xmm8, 0x03
000078e5533d647f  ptest xmm7, xmm7
000078e5533d6484  jnz 0x000078E5533DA5BE
000078e5533d648a  movaps xmm15, xmm11
000078e5533d648e  addpd xmm15, xmm6
000078e5533d6493  vcmppd xmm9, xmm15, xmm15, 0x03
000078e5533d6499  ptest xmm9, xmm9
000078e5533d649f  jnz 0x000078E5533DA702
000078e5533d64a5  movaps xmm11, [r15+0x1E0]
000078e5533d64ad  vmovaps xmm9, [rsp+0x10]
000078e5533d64b3  vpermilpd xmm9, xmm9, 0x00
000078e5533d64b9  movaps xmm7, xmm11
000078e5533d64bd  mulpd xmm7, xmm9
000078e5533d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000078e5533d64c7  ptest xmm6, xmm6
000078e5533d64cc  jnz 0x000078E5533DA845
000078e5533d64d2  movaps xmm11, xmm10
000078e5533d64d6  addpd xmm11, xmm14
000078e5533d64db  vcmppd xmm9, xmm11, xmm11, 0x03
000078e5533d64e1  ptest xmm9, xmm9
000078e5533d64e7  jnz 0x000078E5533DA987
000078e5533d64ed  lea r14, [rax+0x70]
000078e5533d64f1  movups xmm14, [r13+r14*1]
000078e5533d64f7  movaps [r15+0x240], xmm14
000078e5533d64ff  movaps xmm10, xmm1
000078e5533d6503  addpd xmm10, xmm12
000078e5533d6508  vcmppd xmm9, xmm10, xmm10, 0x03
000078e5533d650e  ptest xmm9, xmm9
000078e5533d6514  jnz 0x000078E5533DAAD5
000078e5533d651a  movaps [r15+0x170], xmm10
000078e5533d6522  vmovaps xmm1, [rsp+0x20]
000078e5533d6528  vpermilpd xmm1, xmm1, 0x00
000078e5533d652e  movaps xmm12, xmm14
000078e5533d6532  mulpd xmm12, xmm1
000078e5533d6537  vcmppd xmm9, xmm12, xmm12, 0x03
000078e5533d653d  ptest xmm9, xmm9
000078e5533d6543  jnz 0x000078E5533DAC18
000078e5533d6549  vmovaps xmm1, [rsp+0x20]
000078e5533d654f  vpermilpd xmm1, xmm1, 0x00
000078e5533d6555  vmovaps xmm9, [rsp+0xB0]
000078e5533d655e  movaps xmm14, xmm9
000078e5533d6562  mulpd xmm14, xmm1
000078e5533d6567  vcmppd xmm6, xmm14, xmm14, 0x03
000078e5533d656d  ptest xmm6, xmm6
000078e5533d6572  jnz 0x000078E5533DAD5B
000078e5533d6578  movaps [r15+0x180], xmm14
000078e5533d6580  movaps xmm1, xmm13
000078e5533d6584  addpd xmm1, xmm8
000078e5533d6589  vcmppd xmm9, xmm1, xmm1, 0x03
000078e5533d658e  ptest xmm9, xmm9
000078e5533d6594  jnz 0x000078E5533DAE9E
000078e5533d659a  movaps [r15+0x210], xmm1
000078e5533d65a2  movups xmm13, [r13+rax*1]
000078e5533d65a8  lea r14, [rax+0x10]
000078e5533d65ac  movups xmm9, [r13+r14*1]
000078e5533d65b2  movaps [r15+0x230], xmm9
000078e5533d65ba  movaps xmm8, xmm15
000078e5533d65be  addpd xmm8, xmm7
000078e5533d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000078e5533d65c9  ptest xmm6, xmm6
000078e5533d65ce  jnz 0x000078E5533DAFF4
000078e5533d65d4  movaps [r15+0x130], xmm8
000078e5533d65dc  vmovaps xmm15, [rsp+0x20]
000078e5533d65e2  vpermilpd xmm15, xmm15, 0x00
000078e5533d65e8  movaps xmm7, xmm9
000078e5533d65ec  mulpd xmm7, xmm15
000078e5533d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000078e5533d65f6  ptest xmm6, xmm6
000078e5533d65fb  jnz 0x000078E5533DB137
000078e5533d6601  movaps [r15+0x220], xmm7
000078e5533d6609  vmovaps xmm15, [rsp+0x20]
000078e5533d660f  vpermilpd xmm15, xmm15, 0x00
000078e5533d6615  movaps xmm9, xmm13
000078e5533d6619  mulpd xmm9, xmm15
000078e5533d661e  vcmppd xmm6, xmm9, xmm9, 0x03
000078e5533d6624  ptest xmm6, xmm6
000078e5533d6629  jnz 0x000078E5533DB279
000078e5533d662f  movaps xmm15, xmm11
000078e5533d6633  addpd xmm15, xmm12
000078e5533d6638  vcmppd xmm13, xmm15, xmm15, 0x03
000078e5533d663e  ptest xmm13, xmm13
000078e5533d6644  jnz 0x000078E5533DB3BD
000078e5533d664a  movaps [r15+0x140], xmm15
000078e5533d6652  movaps xmm13, xmm10
000078e5533d6656  addpd xmm13, xmm14
000078e5533d665b  vcmppd xmm12, xmm13, xmm13, 0x03
000078e5533d6661  ptest xmm12, xmm12
000078e5533d6667  jnz 0x000078E5533DB501
000078e5533d666d  movaps [r15+0x150], xmm13
000078e5533d6675  movaps xmm14, xmm1
000078e5533d6679  addpd xmm14, xmm7
000078e5533d667e  vcmppd xmm12, xmm14, xmm14, 0x03
000078e5533d6684  ptest xmm12, xmm12
000078e5533d668a  jnz 0x000078E5533DB645
000078e5533d6690  movaps [r15+0x160], xmm14
000078e5533d6698  movaps xmm1, xmm8
000078e5533d669c  addpd xmm1, xmm9
000078e5533d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000078e5533d66a6  ptest xmm12, xmm12
000078e5533d66ac  jnz 0x000078E5533DB787
000078e5533d66b2  movaps [r15+0x120], xmm1
000078e5533d66ba  movups [r13+r11*1], xmm15
000078e5533d66c0  lea rax, [r11+0x10]
000078e5533d66c4  movups [r13+rax*1], xmm13
000078e5533d66ca  lea rax, [r11+0x20]
000078e5533d66ce  movups [r13+rax*1], xmm14
000078e5533d66d4  lea rax, [r11+0x30]
000078e5533d66d8  movups [r13+rax*1], xmm1
000078e5533d66de  mov eax, [r15+0x108]
000078e5533d66e5  sahf
000078e5533d66e6  jnz 0x000078E5533D6718
000078e5533d66e8  cmp dword ptr [r15+0x318], 0x00
000078e5533d66f0  jz 0x000078E5533DB900
000078e5533d66f6  nop [rax+rax*1], ax
000078e5533d66ff  nop [rax+rax*1], eax
000078e5533d6707  mov eax, 0x410444
000078e5533d670c  mov [r15+0x100], rax
000078e5533d6713  jmp 0x000078E5531FE110
000078e5533d6718  cmp dword ptr [r15+0x318], 0x00
000078e5533d6720  jz 0x000078E5533D57E0
000078e5533d6726  nop [rax+rax*1], ax
000078e5533d672f  nop [rax+rax*1], eax
000078e5533d6737  mov eax, 0x410278
000078e5533d673c  mov [r15+0x100], rax
000078e5533d6743  jmp 0x000078E5531FE110
000078e5533d6748  int3
000078e5533d6749  call 0x000078E55320A4B0
000078e5533d674e  jmp 0x000078E5533D5828
000078e5533d6753  call 0x000078E553209240
000078e5533d6758  jmp 0x000078E5533D5832
000078e5533d675d  call 0x000078E55320A4B0
000078e5533d6762  jmp 0x000078E5533D588F
000078e5533d6767  call 0x000078E553209240
000078e5533d676c  jmp 0x000078E5533D5899
000078e5533d6771  call 0x000078E55320A4B0
000078e5533d6776  jmp 0x000078E5533D58DD
000078e5533d677b  call 0x000078E553209240
000078e5533d6780  jmp 0x000078E5533D58E7
000078e5533d6785  call 0x000078E5532B47C0
000078e5533d678a  jmp 0x000078E5533D5926
000078e5533d678f  call 0x000078E55320B720
000078e5533d6794  jmp 0x000078E5533D593A
000078e5533d6799  call 0x000078E5532BFC30
000078e5533d679e  jmp 0x000078E5533D5958
000078e5533d67a3  call 0x000078E5532BE9C0
000078e5533d67a8  jmp 0x000078E5533D5962
000078e5533d67ad  call 0x000078E5532BD750
000078e5533d67b2  jmp 0x000078E5533D596C
000078e5533d67b7  sub rsp, 0x08
000078e5533d67bb  push rax
000078e5533d67bc  push rcx
000078e5533d67bd  push rdx
000078e5533d67be  push rdi
000078e5533d67bf  push rsi
000078e5533d67c0  push r8
000078e5533d67c2  push r9
000078e5533d67c4  push r10
000078e5533d67c6  push r11
000078e5533d67c8  sub rsp, 0xF0
000078e5533d67cf  vmovaps [rsp], xmm0
000078e5533d67d4  vmovaps [rsp+0x10], xmm1
000078e5533d67da  vmovaps [rsp+0x20], xmm2
000078e5533d67e0  vmovaps [rsp+0x30], xmm3
000078e5533d67e6  vmovaps [rsp+0x40], xmm4
000078e5533d67ec  vmovaps [rsp+0x50], xmm5
000078e5533d67f2  vmovaps [rsp+0x60], xmm6
000078e5533d67f8  vmovaps [rsp+0x70], xmm7
000078e5533d67fe  vmovaps [rsp+0x80], xmm9
000078e5533d6807  vmovaps [rsp+0x90], xmm10
000078e5533d6810  vmovaps [rsp+0xA0], xmm11
000078e5533d6819  vmovaps [rsp+0xB0], xmm12
000078e5533d6822  vmovaps [rsp+0xC0], xmm13
000078e5533d682b  vmovaps [rsp+0xD0], xmm14
000078e5533d6834  vmovaps [rsp+0xE0], xmm15
000078e5533d683d  sub rsp, 0x30
000078e5533d6841  movaps [rsp], xmm8
000078e5533d6846  movaps [rsp+0x10], xmm12
000078e5533d684c  movaps [rsp+0x20], xmm15
000078e5533d6852  lea rdi, [rsp]
000078e5533d6856  mov esi, 0x00
000078e5533d685b  mov rax, 0x5F83D5E17530
000078e5533d6865  call rax
000078e5533d6867  movaps xmm8, [rsp]
000078e5533d686c  add rsp, 0x30
000078e5533d6870  vmovaps xmm0, [rsp]
000078e5533d6875  vmovaps xmm1, [rsp+0x10]
000078e5533d687b  vmovaps xmm2, [rsp+0x20]
000078e5533d6881  vmovaps xmm3, [rsp+0x30]
000078e5533d6887  vmovaps xmm4, [rsp+0x40]
000078e5533d688d  vmovaps xmm5, [rsp+0x50]
000078e5533d6893  vmovaps xmm6, [rsp+0x60]
000078e5533d6899  vmovaps xmm7, [rsp+0x70]
000078e5533d689f  vmovaps xmm9, [rsp+0x80]
000078e5533d68a8  vmovaps xmm10, [rsp+0x90]
000078e5533d68b1  vmovaps xmm11, [rsp+0xA0]
000078e5533d68ba  vmovaps xmm12, [rsp+0xB0]
000078e5533d68c3  vmovaps xmm13, [rsp+0xC0]
000078e5533d68cc  vmovaps xmm14, [rsp+0xD0]
000078e5533d68d5  vmovaps xmm15, [rsp+0xE0]
000078e5533d68de  add rsp, 0xF0
000078e5533d68e5  pop r11
000078e5533d68e7  pop r10
000078e5533d68e9  pop r9
000078e5533d68eb  pop r8
000078e5533d68ed  pop rsi
000078e5533d68ee  pop rdi
000078e5533d68ef  pop rdx
000078e5533d68f0  pop rcx
000078e5533d68f1  pop rax
000078e5533d68f2  add rsp, 0x08
000078e5533d68f6  jmp 0x000078E5533D599A
000078e5533d68fb  sub rsp, 0x08
000078e5533d68ff  push rax
000078e5533d6900  push rcx
000078e5533d6901  push rdx
000078e5533d6902  push rdi
000078e5533d6903  push rsi
000078e5533d6904  push r8
000078e5533d6906  push r9
000078e5533d6908  push r10
000078e5533d690a  push r11
000078e5533d690c  sub rsp, 0xF0
000078e5533d6913  vmovaps [rsp], xmm0
000078e5533d6918  vmovaps [rsp+0x10], xmm1
000078e5533d691e  vmovaps [rsp+0x20], xmm2
000078e5533d6924  vmovaps [rsp+0x30], xmm3
000078e5533d692a  vmovaps [rsp+0x40], xmm4
000078e5533d6930  vmovaps [rsp+0x50], xmm5
000078e5533d6936  vmovaps [rsp+0x60], xmm6
000078e5533d693c  vmovaps [rsp+0x70], xmm8
000078e5533d6942  vmovaps [rsp+0x80], xmm9
000078e5533d694b  vmovaps [rsp+0x90], xmm10
000078e5533d6954  vmovaps [rsp+0xA0], xmm11
000078e5533d695d  vmovaps [rsp+0xB0], xmm12
000078e5533d6966  vmovaps [rsp+0xC0], xmm13
000078e5533d696f  vmovaps [rsp+0xD0], xmm14
000078e5533d6978  vmovaps [rsp+0xE0], xmm15
000078e5533d6981  sub rsp, 0x30
000078e5533d6985  movaps [rsp], xmm7
000078e5533d6989  movaps [rsp+0x10], xmm9
000078e5533d698f  movaps [rsp+0x20], xmm15
000078e5533d6995  lea rdi, [rsp]
000078e5533d6999  mov esi, 0x00
000078e5533d699e  mov rax, 0x5F83D5E17530
000078e5533d69a8  call rax
000078e5533d69aa  movaps xmm7, [rsp]
000078e5533d69ae  add rsp, 0x30
000078e5533d69b2  vmovaps xmm0, [rsp]
000078e5533d69b7  vmovaps xmm1, [rsp+0x10]
000078e5533d69bd  vmovaps xmm2, [rsp+0x20]
000078e5533d69c3  vmovaps xmm3, [rsp+0x30]
000078e5533d69c9  vmovaps xmm4, [rsp+0x40]
000078e5533d69cf  vmovaps xmm5, [rsp+0x50]
000078e5533d69d5  vmovaps xmm6, [rsp+0x60]
000078e5533d69db  vmovaps xmm8, [rsp+0x70]
000078e5533d69e1  vmovaps xmm9, [rsp+0x80]
000078e5533d69ea  vmovaps xmm10, [rsp+0x90]
000078e5533d69f3  vmovaps xmm11, [rsp+0xA0]
000078e5533d69fc  vmovaps xmm12, [rsp+0xB0]
000078e5533d6a05  vmovaps xmm13, [rsp+0xC0]
000078e5533d6a0e  vmovaps xmm14, [rsp+0xD0]
000078e5533d6a17  vmovaps xmm15, [rsp+0xE0]
000078e5533d6a20  add rsp, 0xF0
000078e5533d6a27  pop r11
000078e5533d6a29  pop r10
000078e5533d6a2b  pop r9
000078e5533d6a2d  pop r8
000078e5533d6a2f  pop rsi
000078e5533d6a30  pop rdi
000078e5533d6a31  pop rdx
000078e5533d6a32  pop rcx
000078e5533d6a33  pop rax
000078e5533d6a34  add rsp, 0x08
000078e5533d6a38  jmp 0x000078E5533D59C8
000078e5533d6a3d  sub rsp, 0x08
000078e5533d6a41  push rax
000078e5533d6a42  push rcx
000078e5533d6a43  push rdx
000078e5533d6a44  push rdi
000078e5533d6a45  push rsi
000078e5533d6a46  push r8
000078e5533d6a48  push r9
000078e5533d6a4a  push r10
000078e5533d6a4c  push r11
000078e5533d6a4e  sub rsp, 0xF0
000078e5533d6a55  vmovaps [rsp], xmm0
000078e5533d6a5a  vmovaps [rsp+0x10], xmm1
000078e5533d6a60  vmovaps [rsp+0x20], xmm2
000078e5533d6a66  vmovaps [rsp+0x30], xmm3
000078e5533d6a6c  vmovaps [rsp+0x40], xmm4
000078e5533d6a72  vmovaps [rsp+0x50], xmm5
000078e5533d6a78  vmovaps [rsp+0x60], xmm6
000078e5533d6a7e  vmovaps [rsp+0x70], xmm7
000078e5533d6a84  vmovaps [rsp+0x80], xmm8
000078e5533d6a8d  vmovaps [rsp+0x90], xmm10
000078e5533d6a96  vmovaps [rsp+0xA0], xmm11
000078e5533d6a9f  vmovaps [rsp+0xB0], xmm12
000078e5533d6aa8  vmovaps [rsp+0xC0], xmm13
000078e5533d6ab1  vmovaps [rsp+0xD0], xmm14
000078e5533d6aba  vmovaps [rsp+0xE0], xmm15
000078e5533d6ac3  sub rsp, 0x30
000078e5533d6ac7  movaps [rsp], xmm9
000078e5533d6acc  movaps [rsp+0x10], xmm12
000078e5533d6ad2  movaps [rsp+0x20], xmm10
000078e5533d6ad8  lea rdi, [rsp]
000078e5533d6adc  mov esi, 0x00
000078e5533d6ae1  mov rax, 0x5F83D5E17530
000078e5533d6aeb  call rax
000078e5533d6aed  movaps xmm9, [rsp]
000078e5533d6af2  add rsp, 0x30
000078e5533d6af6  vmovaps xmm0, [rsp]
000078e5533d6afb  vmovaps xmm1, [rsp+0x10]
000078e5533d6b01  vmovaps xmm2, [rsp+0x20]
000078e5533d6b07  vmovaps xmm3, [rsp+0x30]
000078e5533d6b0d  vmovaps xmm4, [rsp+0x40]
000078e5533d6b13  vmovaps xmm5, [rsp+0x50]
000078e5533d6b19  vmovaps xmm6, [rsp+0x60]
000078e5533d6b1f  vmovaps xmm7, [rsp+0x70]
000078e5533d6b25  vmovaps xmm8, [rsp+0x80]
000078e5533d6b2e  vmovaps xmm10, [rsp+0x90]
000078e5533d6b37  vmovaps xmm11, [rsp+0xA0]
000078e5533d6b40  vmovaps xmm12, [rsp+0xB0]
000078e5533d6b49  vmovaps xmm13, [rsp+0xC0]
000078e5533d6b52  vmovaps xmm14, [rsp+0xD0]
000078e5533d6b5b  vmovaps xmm15, [rsp+0xE0]
000078e5533d6b64  add rsp, 0xF0
000078e5533d6b6b  pop r11
000078e5533d6b6d  pop r10
000078e5533d6b6f  pop r9
000078e5533d6b71  pop r8
000078e5533d6b73  pop rsi
000078e5533d6b74  pop rdi
000078e5533d6b75  pop rdx
000078e5533d6b76  pop rcx
000078e5533d6b77  pop rax
000078e5533d6b78  add rsp, 0x08
000078e5533d6b7c  jmp 0x000078E5533D59EC
000078e5533d6b81  sub rsp, 0x08
000078e5533d6b85  push rax
000078e5533d6b86  push rcx
000078e5533d6b87  push rdx
000078e5533d6b88  push rdi
000078e5533d6b89  push rsi
000078e5533d6b8a  push r8
000078e5533d6b8c  push r9
000078e5533d6b8e  push r10
000078e5533d6b90  push r11
000078e5533d6b92  sub rsp, 0xF0
000078e5533d6b99  vmovaps [rsp], xmm0
000078e5533d6b9e  vmovaps [rsp+0x10], xmm1
000078e5533d6ba4  vmovaps [rsp+0x20], xmm2
000078e5533d6baa  vmovaps [rsp+0x30], xmm3
000078e5533d6bb0  vmovaps [rsp+0x40], xmm4
000078e5533d6bb6  vmovaps [rsp+0x50], xmm5
000078e5533d6bbc  vmovaps [rsp+0x60], xmm6
000078e5533d6bc2  vmovaps [rsp+0x70], xmm7
000078e5533d6bc8  vmovaps [rsp+0x80], xmm8
000078e5533d6bd1  vmovaps [rsp+0x90], xmm9
000078e5533d6bda  vmovaps [rsp+0xA0], xmm11
000078e5533d6be3  vmovaps [rsp+0xB0], xmm12
000078e5533d6bec  vmovaps [rsp+0xC0], xmm13
000078e5533d6bf5  vmovaps [rsp+0xD0], xmm14
000078e5533d6bfe  vmovaps [rsp+0xE0], xmm15
000078e5533d6c07  sub rsp, 0x30
000078e5533d6c0b  movaps [rsp], xmm10
000078e5533d6c10  movaps [rsp+0x10], xmm12
000078e5533d6c16  movaps [rsp+0x20], xmm11
000078e5533d6c1c  lea rdi, [rsp]
000078e5533d6c20  mov esi, 0x00
000078e5533d6c25  mov rax, 0x5F83D5E17530
000078e5533d6c2f  call rax
000078e5533d6c31  movaps xmm10, [rsp]
000078e5533d6c36  add rsp, 0x30
000078e5533d6c3a  vmovaps xmm0, [rsp]
000078e5533d6c3f  vmovaps xmm1, [rsp+0x10]
000078e5533d6c45  vmovaps xmm2, [rsp+0x20]
000078e5533d6c4b  vmovaps xmm3, [rsp+0x30]
000078e5533d6c51  vmovaps xmm4, [rsp+0x40]
000078e5533d6c57  vmovaps xmm5, [rsp+0x50]
000078e5533d6c5d  vmovaps xmm6, [rsp+0x60]
000078e5533d6c63  vmovaps xmm7, [rsp+0x70]
000078e5533d6c69  vmovaps xmm8, [rsp+0x80]
000078e5533d6c72  vmovaps xmm9, [rsp+0x90]
000078e5533d6c7b  vmovaps xmm11, [rsp+0xA0]
000078e5533d6c84  vmovaps xmm12, [rsp+0xB0]
000078e5533d6c8d  vmovaps xmm13, [rsp+0xC0]
000078e5533d6c96  vmovaps xmm14, [rsp+0xD0]
000078e5533d6c9f  vmovaps xmm15, [rsp+0xE0]
000078e5533d6ca8  add rsp, 0xF0
000078e5533d6caf  pop r11
000078e5533d6cb1  pop r10
000078e5533d6cb3  pop r9
000078e5533d6cb5  pop r8
000078e5533d6cb7  pop rsi
000078e5533d6cb8  pop rdi
000078e5533d6cb9  pop rdx
000078e5533d6cba  pop rcx
000078e5533d6cbb  pop rax
000078e5533d6cbc  add rsp, 0x08
000078e5533d6cc0  jmp 0x000078E5533D5A06
000078e5533d6cc5  sub rsp, 0x08
000078e5533d6cc9  push rax
000078e5533d6cca  push rcx
000078e5533d6ccb  push rdx
000078e5533d6ccc  push rdi
000078e5533d6ccd  push rsi
000078e5533d6cce  push r8
000078e5533d6cd0  push r9
000078e5533d6cd2  push r10
000078e5533d6cd4  push r11
000078e5533d6cd6  sub rsp, 0xF0
000078e5533d6cdd  vmovaps [rsp], xmm0
000078e5533d6ce2  vmovaps [rsp+0x10], xmm1
000078e5533d6ce8  vmovaps [rsp+0x20], xmm2
000078e5533d6cee  vmovaps [rsp+0x30], xmm3
000078e5533d6cf4  vmovaps [rsp+0x40], xmm4
000078e5533d6cfa  vmovaps [rsp+0x50], xmm5
000078e5533d6d00  vmovaps [rsp+0x60], xmm7
000078e5533d6d06  vmovaps [rsp+0x70], xmm8
000078e5533d6d0c  vmovaps [rsp+0x80], xmm9
000078e5533d6d15  vmovaps [rsp+0x90], xmm10
000078e5533d6d1e  vmovaps [rsp+0xA0], xmm11
000078e5533d6d27  vmovaps [rsp+0xB0], xmm12
000078e5533d6d30  vmovaps [rsp+0xC0], xmm13
000078e5533d6d39  vmovaps [rsp+0xD0], xmm14
000078e5533d6d42  vmovaps [rsp+0xE0], xmm15
000078e5533d6d4b  sub rsp, 0x30
000078e5533d6d4f  movaps [rsp], xmm6
000078e5533d6d53  movaps [rsp+0x10], xmm12
000078e5533d6d59  movaps [rsp+0x20], xmm11
000078e5533d6d5f  lea rdi, [rsp]
000078e5533d6d63  mov esi, 0x00
000078e5533d6d68  mov rax, 0x5F83D5E17530
000078e5533d6d72  call rax
000078e5533d6d74  movaps xmm6, [rsp]
000078e5533d6d78  add rsp, 0x30
000078e5533d6d7c  vmovaps xmm0, [rsp]
000078e5533d6d81  vmovaps xmm1, [rsp+0x10]
000078e5533d6d87  vmovaps xmm2, [rsp+0x20]
000078e5533d6d8d  vmovaps xmm3, [rsp+0x30]
000078e5533d6d93  vmovaps xmm4, [rsp+0x40]
000078e5533d6d99  vmovaps xmm5, [rsp+0x50]
000078e5533d6d9f  vmovaps xmm7, [rsp+0x60]
000078e5533d6da5  vmovaps xmm8, [rsp+0x70]
000078e5533d6dab  vmovaps xmm9, [rsp+0x80]
000078e5533d6db4  vmovaps xmm10, [rsp+0x90]
000078e5533d6dbd  vmovaps xmm11, [rsp+0xA0]
000078e5533d6dc6  vmovaps xmm12, [rsp+0xB0]
000078e5533d6dcf  vmovaps xmm13, [rsp+0xC0]
000078e5533d6dd8  vmovaps xmm14, [rsp+0xD0]
000078e5533d6de1  vmovaps xmm15, [rsp+0xE0]
000078e5533d6dea  add rsp, 0xF0
000078e5533d6df1  pop r11
000078e5533d6df3  pop r10
000078e5533d6df5  pop r9
000078e5533d6df7  pop r8
000078e5533d6df9  pop rsi
000078e5533d6dfa  pop rdi
000078e5533d6dfb  pop rdx
000078e5533d6dfc  pop rcx
000078e5533d6dfd  pop rax
000078e5533d6dfe  add rsp, 0x08
000078e5533d6e02  jmp 0x000078E5533D5A27
000078e5533d6e07  sub rsp, 0x08
000078e5533d6e0b  push rax
000078e5533d6e0c  push rcx
000078e5533d6e0d  push rdx
000078e5533d6e0e  push rdi
000078e5533d6e0f  push rsi
000078e5533d6e10  push r8
000078e5533d6e12  push r9
000078e5533d6e14  push r10
000078e5533d6e16  push r11
000078e5533d6e18  sub rsp, 0xF0
000078e5533d6e1f  vmovaps [rsp], xmm0
000078e5533d6e24  vmovaps [rsp+0x10], xmm1
000078e5533d6e2a  vmovaps [rsp+0x20], xmm2
000078e5533d6e30  vmovaps [rsp+0x30], xmm4
000078e5533d6e36  vmovaps [rsp+0x40], xmm5
000078e5533d6e3c  vmovaps [rsp+0x50], xmm6
000078e5533d6e42  vmovaps [rsp+0x60], xmm7
000078e5533d6e48  vmovaps [rsp+0x70], xmm8
000078e5533d6e4e  vmovaps [rsp+0x80], xmm9
000078e5533d6e57  vmovaps [rsp+0x90], xmm10
000078e5533d6e60  vmovaps [rsp+0xA0], xmm11
000078e5533d6e69  vmovaps [rsp+0xB0], xmm12
000078e5533d6e72  vmovaps [rsp+0xC0], xmm13
000078e5533d6e7b  vmovaps [rsp+0xD0], xmm14
000078e5533d6e84  vmovaps [rsp+0xE0], xmm15
000078e5533d6e8d  sub rsp, 0x30
000078e5533d6e91  movaps [rsp], xmm3
000078e5533d6e95  movaps [rsp+0x10], xmm5
000078e5533d6e9a  movaps [rsp+0x20], xmm4
000078e5533d6e9f  lea rdi, [rsp]
000078e5533d6ea3  mov esi, 0x00
000078e5533d6ea8  mov rax, 0x5F83D5E17530
000078e5533d6eb2  call rax
000078e5533d6eb4  movaps xmm3, [rsp]
000078e5533d6eb8  add rsp, 0x30
000078e5533d6ebc  vmovaps xmm0, [rsp]
000078e5533d6ec1  vmovaps xmm1, [rsp+0x10]
000078e5533d6ec7  vmovaps xmm2, [rsp+0x20]
000078e5533d6ecd  vmovaps xmm4, [rsp+0x30]
000078e5533d6ed3  vmovaps xmm5, [rsp+0x40]
000078e5533d6ed9  vmovaps xmm6, [rsp+0x50]
000078e5533d6edf  vmovaps xmm7, [rsp+0x60]
000078e5533d6ee5  vmovaps xmm8, [rsp+0x70]
000078e5533d6eeb  vmovaps xmm9, [rsp+0x80]
000078e5533d6ef4  vmovaps xmm10, [rsp+0x90]
000078e5533d6efd  vmovaps xmm11, [rsp+0xA0]
000078e5533d6f06  vmovaps xmm12, [rsp+0xB0]
000078e5533d6f0f  vmovaps xmm13, [rsp+0xC0]
000078e5533d6f18  vmovaps xmm14, [rsp+0xD0]
000078e5533d6f21  vmovaps xmm15, [rsp+0xE0]
000078e5533d6f2a  add rsp, 0xF0
000078e5533d6f31  pop r11
000078e5533d6f33  pop r10
000078e5533d6f35  pop r9
000078e5533d6f37  pop r8
000078e5533d6f39  pop rsi
000078e5533d6f3a  pop rdi
000078e5533d6f3b  pop rdx
000078e5533d6f3c  pop rcx
000078e5533d6f3d  pop rax
000078e5533d6f3e  add rsp, 0x08
000078e5533d6f42  jmp 0x000078E5533D5A88
000078e5533d6f47  sub rsp, 0x08
000078e5533d6f4b  push rax
000078e5533d6f4c  push rcx
000078e5533d6f4d  push rdx
000078e5533d6f4e  push rdi
000078e5533d6f4f  push rsi
000078e5533d6f50  push r8
000078e5533d6f52  push r9
000078e5533d6f54  push r10
000078e5533d6f56  push r11
000078e5533d6f58  sub rsp, 0xF0
000078e5533d6f5f  vmovaps [rsp], xmm0
000078e5533d6f64  vmovaps [rsp+0x10], xmm1
000078e5533d6f6a  vmovaps [rsp+0x20], xmm2
000078e5533d6f70  vmovaps [rsp+0x30], xmm3
000078e5533d6f76  vmovaps [rsp+0x40], xmm4
000078e5533d6f7c  vmovaps [rsp+0x50], xmm6
000078e5533d6f82  vmovaps [rsp+0x60], xmm7
000078e5533d6f88  vmovaps [rsp+0x70], xmm8
000078e5533d6f8e  vmovaps [rsp+0x80], xmm9
000078e5533d6f97  vmovaps [rsp+0x90], xmm10
000078e5533d6fa0  vmovaps [rsp+0xA0], xmm11
000078e5533d6fa9  vmovaps [rsp+0xB0], xmm12
000078e5533d6fb2  vmovaps [rsp+0xC0], xmm13
000078e5533d6fbb  vmovaps [rsp+0xD0], xmm14
000078e5533d6fc4  vmovaps [rsp+0xE0], xmm15
000078e5533d6fcd  sub rsp, 0x30
000078e5533d6fd1  movaps [rsp], xmm5
000078e5533d6fd5  movaps [rsp+0x10], xmm8
000078e5533d6fdb  movaps [rsp+0x20], xmm15
000078e5533d6fe1  lea rdi, [rsp]
000078e5533d6fe5  mov esi, 0x00
000078e5533d6fea  mov rax, 0x5F83D5E17530
000078e5533d6ff4  call rax
000078e5533d6ff6  movaps xmm5, [rsp]
000078e5533d6ffa  add rsp, 0x30
000078e5533d6ffe  vmovaps xmm0, [rsp]
000078e5533d7003  vmovaps xmm1, [rsp+0x10]
000078e5533d7009  vmovaps xmm2, [rsp+0x20]
000078e5533d700f  vmovaps xmm3, [rsp+0x30]
000078e5533d7015  vmovaps xmm4, [rsp+0x40]
000078e5533d701b  vmovaps xmm6, [rsp+0x50]
000078e5533d7021  vmovaps xmm7, [rsp+0x60]
000078e5533d7027  vmovaps xmm8, [rsp+0x70]
000078e5533d702d  vmovaps xmm9, [rsp+0x80]
000078e5533d7036  vmovaps xmm10, [rsp+0x90]
000078e5533d703f  vmovaps xmm11, [rsp+0xA0]
000078e5533d7048  vmovaps xmm12, [rsp+0xB0]
000078e5533d7051  vmovaps xmm13, [rsp+0xC0]
000078e5533d705a  vmovaps xmm14, [rsp+0xD0]
000078e5533d7063  vmovaps xmm15, [rsp+0xE0]
000078e5533d706c  add rsp, 0xF0
000078e5533d7073  pop r11
000078e5533d7075  pop r10
000078e5533d7077  pop r9
000078e5533d7079  pop r8
000078e5533d707b  pop rsi
000078e5533d707c  pop rdi
000078e5533d707d  pop rdx
000078e5533d707e  pop rcx
000078e5533d707f  pop rax
000078e5533d7080  add rsp, 0x08
000078e5533d7084  jmp 0x000078E5533D5AC0
000078e5533d7089  sub rsp, 0x08
000078e5533d708d  push rax
000078e5533d708e  push rcx
000078e5533d708f  push rdx
000078e5533d7090  push rdi
000078e5533d7091  push rsi
000078e5533d7092  push r8
000078e5533d7094  push r9
000078e5533d7096  push r10
000078e5533d7098  push r11
000078e5533d709a  sub rsp, 0xF0
000078e5533d70a1  vmovaps [rsp], xmm0
000078e5533d70a6  vmovaps [rsp+0x10], xmm1
000078e5533d70ac  vmovaps [rsp+0x20], xmm2
000078e5533d70b2  vmovaps [rsp+0x30], xmm3
000078e5533d70b8  vmovaps [rsp+0x40], xmm5
000078e5533d70be  vmovaps [rsp+0x50], xmm6
000078e5533d70c4  vmovaps [rsp+0x60], xmm7
000078e5533d70ca  vmovaps [rsp+0x70], xmm8
000078e5533d70d0  vmovaps [rsp+0x80], xmm9
000078e5533d70d9  vmovaps [rsp+0x90], xmm10
000078e5533d70e2  vmovaps [rsp+0xA0], xmm11
000078e5533d70eb  vmovaps [rsp+0xB0], xmm12
000078e5533d70f4  vmovaps [rsp+0xC0], xmm13
000078e5533d70fd  vmovaps [rsp+0xD0], xmm14
000078e5533d7106  vmovaps [rsp+0xE0], xmm15
000078e5533d710f  sub rsp, 0x30
000078e5533d7113  movaps [rsp], xmm4
000078e5533d7117  movaps [rsp+0x10], xmm9
000078e5533d711d  movaps [rsp+0x20], xmm8
000078e5533d7123  lea rdi, [rsp]
000078e5533d7127  mov esi, 0x00
000078e5533d712c  mov rax, 0x5F83D5E17530
000078e5533d7136  call rax
000078e5533d7138  movaps xmm4, [rsp]
000078e5533d713c  add rsp, 0x30
000078e5533d7140  vmovaps xmm0, [rsp]
000078e5533d7145  vmovaps xmm1, [rsp+0x10]
000078e5533d714b  vmovaps xmm2, [rsp+0x20]
000078e5533d7151  vmovaps xmm3, [rsp+0x30]
000078e5533d7157  vmovaps xmm5, [rsp+0x40]
000078e5533d715d  vmovaps xmm6, [rsp+0x50]
000078e5533d7163  vmovaps xmm7, [rsp+0x60]
000078e5533d7169  vmovaps xmm8, [rsp+0x70]
000078e5533d716f  vmovaps xmm9, [rsp+0x80]
000078e5533d7178  vmovaps xmm10, [rsp+0x90]
000078e5533d7181  vmovaps xmm11, [rsp+0xA0]
000078e5533d718a  vmovaps xmm12, [rsp+0xB0]
000078e5533d7193  vmovaps xmm13, [rsp+0xC0]
000078e5533d719c  vmovaps xmm14, [rsp+0xD0]
000078e5533d71a5  vmovaps xmm15, [rsp+0xE0]
000078e5533d71ae  add rsp, 0xF0
000078e5533d71b5  pop r11
000078e5533d71b7  pop r10
000078e5533d71b9  pop r9
000078e5533d71bb  pop r8
000078e5533d71bd  pop rsi
000078e5533d71be  pop rdi
000078e5533d71bf  pop rdx
000078e5533d71c0  pop rcx
000078e5533d71c1  pop rax
000078e5533d71c2  add rsp, 0x08
000078e5533d71c6  jmp 0x000078E5533D5AE1
000078e5533d71cb  sub rsp, 0x08
000078e5533d71cf  push rax
000078e5533d71d0  push rcx
000078e5533d71d1  push rdx
000078e5533d71d2  push rdi
000078e5533d71d3  push rsi
000078e5533d71d4  push r8
000078e5533d71d6  push r9
000078e5533d71d8  push r10
000078e5533d71da  push r11
000078e5533d71dc  sub rsp, 0xF0
000078e5533d71e3  vmovaps [rsp], xmm0
000078e5533d71e8  vmovaps [rsp+0x10], xmm1
000078e5533d71ee  vmovaps [rsp+0x20], xmm2
000078e5533d71f4  vmovaps [rsp+0x30], xmm3
000078e5533d71fa  vmovaps [rsp+0x40], xmm4
000078e5533d7200  vmovaps [rsp+0x50], xmm5
000078e5533d7206  vmovaps [rsp+0x60], xmm6
000078e5533d720c  vmovaps [rsp+0x70], xmm7
000078e5533d7212  vmovaps [rsp+0x80], xmm8
000078e5533d721b  vmovaps [rsp+0x90], xmm10
000078e5533d7224  vmovaps [rsp+0xA0], xmm11
000078e5533d722d  vmovaps [rsp+0xB0], xmm12
000078e5533d7236  vmovaps [rsp+0xC0], xmm13
000078e5533d723f  vmovaps [rsp+0xD0], xmm14
000078e5533d7248  vmovaps [rsp+0xE0], xmm15
000078e5533d7251  sub rsp, 0x30
000078e5533d7255  movaps [rsp], xmm9
000078e5533d725a  movaps [rsp+0x10], xmm10
000078e5533d7260  movaps [rsp+0x20], xmm8
000078e5533d7266  lea rdi, [rsp]
000078e5533d726a  mov esi, 0x00
000078e5533d726f  mov rax, 0x5F83D5E17530
000078e5533d7279  call rax
000078e5533d727b  movaps xmm9, [rsp]
000078e5533d7280  add rsp, 0x30
000078e5533d7284  vmovaps xmm0, [rsp]
000078e5533d7289  vmovaps xmm1, [rsp+0x10]
000078e5533d728f  vmovaps xmm2, [rsp+0x20]
000078e5533d7295  vmovaps xmm3, [rsp+0x30]
000078e5533d729b  vmovaps xmm4, [rsp+0x40]
000078e5533d72a1  vmovaps xmm5, [rsp+0x50]
000078e5533d72a7  vmovaps xmm6, [rsp+0x60]
000078e5533d72ad  vmovaps xmm7, [rsp+0x70]
000078e5533d72b3  vmovaps xmm8, [rsp+0x80]
000078e5533d72bc  vmovaps xmm10, [rsp+0x90]
000078e5533d72c5  vmovaps xmm11, [rsp+0xA0]
000078e5533d72ce  vmovaps xmm12, [rsp+0xB0]
000078e5533d72d7  vmovaps xmm13, [rsp+0xC0]
000078e5533d72e0  vmovaps xmm14, [rsp+0xD0]
000078e5533d72e9  vmovaps xmm15, [rsp+0xE0]
000078e5533d72f2  add rsp, 0xF0
000078e5533d72f9  pop r11
000078e5533d72fb  pop r10
000078e5533d72fd  pop r9
000078e5533d72ff  pop r8
000078e5533d7301  pop rsi
000078e5533d7302  pop rdi
000078e5533d7303  pop rdx
000078e5533d7304  pop rcx
000078e5533d7305  pop rax
000078e5533d7306  add rsp, 0x08
000078e5533d730a  jmp 0x000078E5533D5AFB
000078e5533d730f  call 0x000078E5532D64F0
000078e5533d7314  jmp 0x000078E5533D5C15
000078e5533d7319  call 0x000078E5532D64F0
000078e5533d731e  jmp 0x000078E5533D5C2B
000078e5533d7323  sub rsp, 0x08
000078e5533d7327  push rax
000078e5533d7328  push rcx
000078e5533d7329  push rdx
000078e5533d732a  push rdi
000078e5533d732b  push rsi
000078e5533d732c  push r8
000078e5533d732e  push r9
000078e5533d7330  push r10
000078e5533d7332  push r11
000078e5533d7334  sub rsp, 0xF0
000078e5533d733b  vmovaps [rsp], xmm0
000078e5533d7340  vmovaps [rsp+0x10], xmm2
000078e5533d7346  vmovaps [rsp+0x20], xmm3
000078e5533d734c  vmovaps [rsp+0x30], xmm4
000078e5533d7352  vmovaps [rsp+0x40], xmm5
000078e5533d7358  vmovaps [rsp+0x50], xmm6
000078e5533d735e  vmovaps [rsp+0x60], xmm7
000078e5533d7364  vmovaps [rsp+0x70], xmm8
000078e5533d736a  vmovaps [rsp+0x80], xmm9
000078e5533d7373  vmovaps [rsp+0x90], xmm10
000078e5533d737c  vmovaps [rsp+0xA0], xmm11
000078e5533d7385  vmovaps [rsp+0xB0], xmm12
000078e5533d738e  vmovaps [rsp+0xC0], xmm13
000078e5533d7397  vmovaps [rsp+0xD0], xmm14
000078e5533d73a0  vmovaps [rsp+0xE0], xmm15
000078e5533d73a9  sub rsp, 0x30
000078e5533d73ad  movaps [rsp], xmm1
000078e5533d73b1  movaps [rsp+0x10], xmm6
000078e5533d73b6  movaps [rsp+0x20], xmm15
000078e5533d73bc  lea rdi, [rsp]
000078e5533d73c0  mov esi, 0x00
000078e5533d73c5  mov rax, 0x5F83D5E17530
000078e5533d73cf  call rax
000078e5533d73d1  movaps xmm1, [rsp]
000078e5533d73d5  add rsp, 0x30
000078e5533d73d9  vmovaps xmm0, [rsp]
000078e5533d73de  vmovaps xmm2, [rsp+0x10]
000078e5533d73e4  vmovaps xmm3, [rsp+0x20]
000078e5533d73ea  vmovaps xmm4, [rsp+0x30]
000078e5533d73f0  vmovaps xmm5, [rsp+0x40]
000078e5533d73f6  vmovaps xmm6, [rsp+0x50]
000078e5533d73fc  vmovaps xmm7, [rsp+0x60]
000078e5533d7402  vmovaps xmm8, [rsp+0x70]
000078e5533d7408  vmovaps xmm9, [rsp+0x80]
000078e5533d7411  vmovaps xmm10, [rsp+0x90]
000078e5533d741a  vmovaps xmm11, [rsp+0xA0]
000078e5533d7423  vmovaps xmm12, [rsp+0xB0]
000078e5533d742c  vmovaps xmm13, [rsp+0xC0]
000078e5533d7435  vmovaps xmm14, [rsp+0xD0]
000078e5533d743e  vmovaps xmm15, [rsp+0xE0]
000078e5533d7447  add rsp, 0xF0
000078e5533d744e  pop r11
000078e5533d7450  pop r10
000078e5533d7452  pop r9
000078e5533d7454  pop r8
000078e5533d7456  pop rsi
000078e5533d7457  pop rdi
000078e5533d7458  pop rdx
000078e5533d7459  pop rcx
000078e5533d745a  pop rax
000078e5533d745b  add rsp, 0x08
000078e5533d745f  jmp 0x000078E5533D5C68
000078e5533d7464  call 0x000078E5532E5820
000078e5533d7469  jmp 0x000078E5533D5C75
000078e5533d746e  sub rsp, 0x08
000078e5533d7472  push rax
000078e5533d7473  push rcx
000078e5533d7474  push rdx
000078e5533d7475  push rdi
000078e5533d7476  push rsi
000078e5533d7477  push r8
000078e5533d7479  push r9
000078e5533d747b  push r10
000078e5533d747d  push r11
000078e5533d747f  sub rsp, 0xF0
000078e5533d7486  vmovaps [rsp], xmm0
000078e5533d748b  vmovaps [rsp+0x10], xmm1
000078e5533d7491  vmovaps [rsp+0x20], xmm2
000078e5533d7497  vmovaps [rsp+0x30], xmm3
000078e5533d749d  vmovaps [rsp+0x40], xmm4
000078e5533d74a3  vmovaps [rsp+0x50], xmm5
000078e5533d74a9  vmovaps [rsp+0x60], xmm6
000078e5533d74af  vmovaps [rsp+0x70], xmm7
000078e5533d74b5  vmovaps [rsp+0x80], xmm8
000078e5533d74be  vmovaps [rsp+0x90], xmm9
000078e5533d74c7  vmovaps [rsp+0xA0], xmm10
000078e5533d74d0  vmovaps [rsp+0xB0], xmm11
000078e5533d74d9  vmovaps [rsp+0xC0], xmm12
000078e5533d74e2  vmovaps [rsp+0xD0], xmm13
000078e5533d74eb  vmovaps [rsp+0xE0], xmm15
000078e5533d74f4  sub rsp, 0x30
000078e5533d74f8  movaps [rsp], xmm14
000078e5533d74fd  movaps [rsp+0x10], xmm4
000078e5533d7502  movaps [rsp+0x20], xmm3
000078e5533d7507  lea rdi, [rsp]
000078e5533d750b  mov esi, 0x00
000078e5533d7510  mov rax, 0x5F83D5E17530
000078e5533d751a  call rax
000078e5533d751c  movaps xmm14, [rsp]
000078e5533d7521  add rsp, 0x30
000078e5533d7525  vmovaps xmm0, [rsp]
000078e5533d752a  vmovaps xmm1, [rsp+0x10]
000078e5533d7530  vmovaps xmm2, [rsp+0x20]
000078e5533d7536  vmovaps xmm3, [rsp+0x30]
000078e5533d753c  vmovaps xmm4, [rsp+0x40]
000078e5533d7542  vmovaps xmm5, [rsp+0x50]
000078e5533d7548  vmovaps xmm6, [rsp+0x60]
000078e5533d754e  vmovaps xmm7, [rsp+0x70]
000078e5533d7554  vmovaps xmm8, [rsp+0x80]
000078e5533d755d  vmovaps xmm9, [rsp+0x90]
000078e5533d7566  vmovaps xmm10, [rsp+0xA0]
000078e5533d756f  vmovaps xmm11, [rsp+0xB0]
000078e5533d7578  vmovaps xmm12, [rsp+0xC0]
000078e5533d7581  vmovaps xmm13, [rsp+0xD0]
000078e5533d758a  vmovaps xmm15, [rsp+0xE0]
000078e5533d7593  add rsp, 0xF0
000078e5533d759a  pop r11
000078e5533d759c  pop r10
000078e5533d759e  pop r9
000078e5533d75a0  pop r8
000078e5533d75a2  pop rsi
000078e5533d75a3  pop rdi
000078e5533d75a4  pop rdx
000078e5533d75a5  pop rcx
000078e5533d75a6  pop rax
000078e5533d75a7  add rsp, 0x08
000078e5533d75ab  jmp 0x000078E5533D5C8F
000078e5533d75b0  sub rsp, 0x08
000078e5533d75b4  push rax
000078e5533d75b5  push rcx
000078e5533d75b6  push rdx
000078e5533d75b7  push rdi
000078e5533d75b8  push rsi
000078e5533d75b9  push r8
000078e5533d75bb  push r9
000078e5533d75bd  push r10
000078e5533d75bf  push r11
000078e5533d75c1  sub rsp, 0xF0
000078e5533d75c8  vmovaps [rsp], xmm0
000078e5533d75cd  vmovaps [rsp+0x10], xmm1
000078e5533d75d3  vmovaps [rsp+0x20], xmm2
000078e5533d75d9  vmovaps [rsp+0x30], xmm3
000078e5533d75df  vmovaps [rsp+0x40], xmm4
000078e5533d75e5  vmovaps [rsp+0x50], xmm5
000078e5533d75eb  vmovaps [rsp+0x60], xmm7
000078e5533d75f1  vmovaps [rsp+0x70], xmm8
000078e5533d75f7  vmovaps [rsp+0x80], xmm9
000078e5533d7600  vmovaps [rsp+0x90], xmm10
000078e5533d7609  vmovaps [rsp+0xA0], xmm11
000078e5533d7612  vmovaps [rsp+0xB0], xmm12
000078e5533d761b  vmovaps [rsp+0xC0], xmm13
000078e5533d7624  vmovaps [rsp+0xD0], xmm14
000078e5533d762d  vmovaps [rsp+0xE0], xmm15
000078e5533d7636  sub rsp, 0x30
000078e5533d763a  movaps [rsp], xmm6
000078e5533d763e  movaps [rsp+0x10], xmm9
000078e5533d7644  movaps [rsp+0x20], xmm7
000078e5533d7649  lea rdi, [rsp]
000078e5533d764d  mov esi, 0x00
000078e5533d7652  mov rax, 0x5F83D5E17530
000078e5533d765c  call rax
000078e5533d765e  movaps xmm6, [rsp]
000078e5533d7662  add rsp, 0x30
000078e5533d7666  vmovaps xmm0, [rsp]
000078e5533d766b  vmovaps xmm1, [rsp+0x10]
000078e5533d7671  vmovaps xmm2, [rsp+0x20]
000078e5533d7677  vmovaps xmm3, [rsp+0x30]
000078e5533d767d  vmovaps xmm4, [rsp+0x40]
000078e5533d7683  vmovaps xmm5, [rsp+0x50]
000078e5533d7689  vmovaps xmm7, [rsp+0x60]
000078e5533d768f  vmovaps xmm8, [rsp+0x70]
000078e5533d7695  vmovaps xmm9, [rsp+0x80]
000078e5533d769e  vmovaps xmm10, [rsp+0x90]
000078e5533d76a7  vmovaps xmm11, [rsp+0xA0]
000078e5533d76b0  vmovaps xmm12, [rsp+0xB0]
000078e5533d76b9  vmovaps xmm13, [rsp+0xC0]
000078e5533d76c2  vmovaps xmm14, [rsp+0xD0]
000078e5533d76cb  vmovaps xmm15, [rsp+0xE0]
000078e5533d76d4  add rsp, 0xF0
000078e5533d76db  pop r11
000078e5533d76dd  pop r10
000078e5533d76df  pop r9
000078e5533d76e1  pop r8
000078e5533d76e3  pop rsi
000078e5533d76e4  pop rdi
000078e5533d76e5  pop rdx
000078e5533d76e6  pop rcx
000078e5533d76e7  pop rax
000078e5533d76e8  add rsp, 0x08
000078e5533d76ec  jmp 0x000078E5533D5CA7
000078e5533d76f1  sub rsp, 0x08
000078e5533d76f5  push rax
000078e5533d76f6  push rcx
000078e5533d76f7  push rdx
000078e5533d76f8  push rdi
000078e5533d76f9  push rsi
000078e5533d76fa  push r8
000078e5533d76fc  push r9
000078e5533d76fe  push r10
000078e5533d7700  push r11
000078e5533d7702  sub rsp, 0xF0
000078e5533d7709  vmovaps [rsp], xmm0
000078e5533d770e  vmovaps [rsp+0x10], xmm1
000078e5533d7714  vmovaps [rsp+0x20], xmm2
000078e5533d771a  vmovaps [rsp+0x30], xmm3
000078e5533d7720  vmovaps [rsp+0x40], xmm4
000078e5533d7726  vmovaps [rsp+0x50], xmm5
000078e5533d772c  vmovaps [rsp+0x60], xmm6
000078e5533d7732  vmovaps [rsp+0x70], xmm8
000078e5533d7738  vmovaps [rsp+0x80], xmm9
000078e5533d7741  vmovaps [rsp+0x90], xmm10
000078e5533d774a  vmovaps [rsp+0xA0], xmm11
000078e5533d7753  vmovaps [rsp+0xB0], xmm12
000078e5533d775c  vmovaps [rsp+0xC0], xmm13
000078e5533d7765  vmovaps [rsp+0xD0], xmm14
000078e5533d776e  vmovaps [rsp+0xE0], xmm15
000078e5533d7777  sub rsp, 0x30
000078e5533d777b  movaps [rsp], xmm7
000078e5533d777f  movaps [rsp+0x10], xmm4
000078e5533d7784  movaps [rsp+0x20], xmm9
000078e5533d778a  lea rdi, [rsp]
000078e5533d778e  mov esi, 0x00
000078e5533d7793  mov rax, 0x5F83D5E17530
000078e5533d779d  call rax
000078e5533d779f  movaps xmm7, [rsp]
000078e5533d77a3  add rsp, 0x30
000078e5533d77a7  vmovaps xmm0, [rsp]
000078e5533d77ac  vmovaps xmm1, [rsp+0x10]
000078e5533d77b2  vmovaps xmm2, [rsp+0x20]
000078e5533d77b8  vmovaps xmm3, [rsp+0x30]
000078e5533d77be  vmovaps xmm4, [rsp+0x40]
000078e5533d77c4  vmovaps xmm5, [rsp+0x50]
000078e5533d77ca  vmovaps xmm6, [rsp+0x60]
000078e5533d77d0  vmovaps xmm8, [rsp+0x70]
000078e5533d77d6  vmovaps xmm9, [rsp+0x80]
000078e5533d77df  vmovaps xmm10, [rsp+0x90]
000078e5533d77e8  vmovaps xmm11, [rsp+0xA0]
000078e5533d77f1  vmovaps xmm12, [rsp+0xB0]
000078e5533d77fa  vmovaps xmm13, [rsp+0xC0]
000078e5533d7803  vmovaps xmm14, [rsp+0xD0]
000078e5533d780c  vmovaps xmm15, [rsp+0xE0]
000078e5533d7815  add rsp, 0xF0
000078e5533d781c  pop r11
000078e5533d781e  pop r10
000078e5533d7820  pop r9
000078e5533d7822  pop r8
000078e5533d7824  pop rsi
000078e5533d7825  pop rdi
000078e5533d7826  pop rdx
000078e5533d7827  pop rcx
000078e5533d7828  pop rax
000078e5533d7829  add rsp, 0x08
000078e5533d782d  jmp 0x000078E5533D5CD4
000078e5533d7832  sub rsp, 0x08
000078e5533d7836  push rax
000078e5533d7837  push rcx
000078e5533d7838  push rdx
000078e5533d7839  push rdi
000078e5533d783a  push rsi
000078e5533d783b  push r8
000078e5533d783d  push r9
000078e5533d783f  push r10
000078e5533d7841  push r11
000078e5533d7843  sub rsp, 0xF0
000078e5533d784a  vmovaps [rsp], xmm0
000078e5533d784f  vmovaps [rsp+0x10], xmm1
000078e5533d7855  vmovaps [rsp+0x20], xmm2
000078e5533d785b  vmovaps [rsp+0x30], xmm3
000078e5533d7861  vmovaps [rsp+0x40], xmm5
000078e5533d7867  vmovaps [rsp+0x50], xmm6
000078e5533d786d  vmovaps [rsp+0x60], xmm7
000078e5533d7873  vmovaps [rsp+0x70], xmm8
000078e5533d7879  vmovaps [rsp+0x80], xmm9
000078e5533d7882  vmovaps [rsp+0x90], xmm10
000078e5533d788b  vmovaps [rsp+0xA0], xmm11
000078e5533d7894  vmovaps [rsp+0xB0], xmm12
000078e5533d789d  vmovaps [rsp+0xC0], xmm13
000078e5533d78a6  vmovaps [rsp+0xD0], xmm14
000078e5533d78af  vmovaps [rsp+0xE0], xmm15
000078e5533d78b8  sub rsp, 0x30
000078e5533d78bc  movaps [rsp], xmm4
000078e5533d78c0  movaps [rsp+0x10], xmm15
000078e5533d78c6  movaps [rsp+0x20], xmm9
000078e5533d78cc  lea rdi, [rsp]
000078e5533d78d0  mov esi, 0x00
000078e5533d78d5  mov rax, 0x5F83D5E17530
000078e5533d78df  call rax
000078e5533d78e1  movaps xmm4, [rsp]
000078e5533d78e5  add rsp, 0x30
000078e5533d78e9  vmovaps xmm0, [rsp]
000078e5533d78ee  vmovaps xmm1, [rsp+0x10]
000078e5533d78f4  vmovaps xmm2, [rsp+0x20]
000078e5533d78fa  vmovaps xmm3, [rsp+0x30]
000078e5533d7900  vmovaps xmm5, [rsp+0x40]
000078e5533d7906  vmovaps xmm6, [rsp+0x50]
000078e5533d790c  vmovaps xmm7, [rsp+0x60]
000078e5533d7912  vmovaps xmm8, [rsp+0x70]
000078e5533d7918  vmovaps xmm9, [rsp+0x80]
000078e5533d7921  vmovaps xmm10, [rsp+0x90]
000078e5533d792a  vmovaps xmm11, [rsp+0xA0]
000078e5533d7933  vmovaps xmm12, [rsp+0xB0]
000078e5533d793c  vmovaps xmm13, [rsp+0xC0]
000078e5533d7945  vmovaps xmm14, [rsp+0xD0]
000078e5533d794e  vmovaps xmm15, [rsp+0xE0]
000078e5533d7957  add rsp, 0xF0
000078e5533d795e  pop r11
000078e5533d7960  pop r10
000078e5533d7962  pop r9
000078e5533d7964  pop r8
000078e5533d7966  pop rsi
000078e5533d7967  pop rdi
000078e5533d7968  pop rdx
000078e5533d7969  pop rcx
000078e5533d796a  pop rax
000078e5533d796b  add rsp, 0x08
000078e5533d796f  jmp 0x000078E5533D5CF9
000078e5533d7974  call 0x000078E5532E5820
000078e5533d7979  jmp 0x000078E5533D5D06
000078e5533d797e  sub rsp, 0x08
000078e5533d7982  push rax
000078e5533d7983  push rcx
000078e5533d7984  push rdx
000078e5533d7985  push rdi
000078e5533d7986  push rsi
000078e5533d7987  push r8
000078e5533d7989  push r9
000078e5533d798b  push r10
000078e5533d798d  push r11
000078e5533d798f  sub rsp, 0xF0
000078e5533d7996  vmovaps [rsp], xmm0
000078e5533d799b  vmovaps [rsp+0x10], xmm1
000078e5533d79a1  vmovaps [rsp+0x20], xmm2
000078e5533d79a7  vmovaps [rsp+0x30], xmm4
000078e5533d79ad  vmovaps [rsp+0x40], xmm5
000078e5533d79b3  vmovaps [rsp+0x50], xmm6
000078e5533d79b9  vmovaps [rsp+0x60], xmm7
000078e5533d79bf  vmovaps [rsp+0x70], xmm8
000078e5533d79c5  vmovaps [rsp+0x80], xmm9
000078e5533d79ce  vmovaps [rsp+0x90], xmm10
000078e5533d79d7  vmovaps [rsp+0xA0], xmm11
000078e5533d79e0  vmovaps [rsp+0xB0], xmm12
000078e5533d79e9  vmovaps [rsp+0xC0], xmm13
000078e5533d79f2  vmovaps [rsp+0xD0], xmm14
000078e5533d79fb  vmovaps [rsp+0xE0], xmm15
000078e5533d7a04  sub rsp, 0x30
000078e5533d7a08  movaps [rsp], xmm3
000078e5533d7a0c  movaps [rsp+0x10], xmm1
000078e5533d7a11  movaps [rsp+0x20], xmm9
000078e5533d7a17  lea rdi, [rsp]
000078e5533d7a1b  mov esi, 0x00
000078e5533d7a20  mov rax, 0x5F83D5E17530
000078e5533d7a2a  call rax
000078e5533d7a2c  movaps xmm3, [rsp]
000078e5533d7a30  add rsp, 0x30
000078e5533d7a34  vmovaps xmm0, [rsp]
000078e5533d7a39  vmovaps xmm1, [rsp+0x10]
000078e5533d7a3f  vmovaps xmm2, [rsp+0x20]
000078e5533d7a45  vmovaps xmm4, [rsp+0x30]
000078e5533d7a4b  vmovaps xmm5, [rsp+0x40]
000078e5533d7a51  vmovaps xmm6, [rsp+0x50]
000078e5533d7a57  vmovaps xmm7, [rsp+0x60]
000078e5533d7a5d  vmovaps xmm8, [rsp+0x70]
000078e5533d7a63  vmovaps xmm9, [rsp+0x80]
000078e5533d7a6c  vmovaps xmm10, [rsp+0x90]
000078e5533d7a75  vmovaps xmm11, [rsp+0xA0]
000078e5533d7a7e  vmovaps xmm12, [rsp+0xB0]
000078e5533d7a87  vmovaps xmm13, [rsp+0xC0]
000078e5533d7a90  vmovaps xmm14, [rsp+0xD0]
000078e5533d7a99  vmovaps xmm15, [rsp+0xE0]
000078e5533d7aa2  add rsp, 0xF0
000078e5533d7aa9  pop r11
000078e5533d7aab  pop r10
000078e5533d7aad  pop r9
000078e5533d7aaf  pop r8
000078e5533d7ab1  pop rsi
000078e5533d7ab2  pop rdi
000078e5533d7ab3  pop rdx
000078e5533d7ab4  pop rcx
000078e5533d7ab5  pop rax
000078e5533d7ab6  add rsp, 0x08
000078e5533d7aba  jmp 0x000078E5533D5D43
000078e5533d7abf  sub rsp, 0x08
000078e5533d7ac3  push rax
000078e5533d7ac4  push rcx
000078e5533d7ac5  push rdx
000078e5533d7ac6  push rdi
000078e5533d7ac7  push rsi
000078e5533d7ac8  push r8
000078e5533d7aca  push r9
000078e5533d7acc  push r10
000078e5533d7ace  push r11
000078e5533d7ad0  sub rsp, 0xF0
000078e5533d7ad7  vmovaps [rsp], xmm0
000078e5533d7adc  vmovaps [rsp+0x10], xmm2
000078e5533d7ae2  vmovaps [rsp+0x20], xmm3
000078e5533d7ae8  vmovaps [rsp+0x30], xmm4
000078e5533d7aee  vmovaps [rsp+0x40], xmm5
000078e5533d7af4  vmovaps [rsp+0x50], xmm6
000078e5533d7afa  vmovaps [rsp+0x60], xmm7
000078e5533d7b00  vmovaps [rsp+0x70], xmm8
000078e5533d7b06  vmovaps [rsp+0x80], xmm9
000078e5533d7b0f  vmovaps [rsp+0x90], xmm10
000078e5533d7b18  vmovaps [rsp+0xA0], xmm11
000078e5533d7b21  vmovaps [rsp+0xB0], xmm12
000078e5533d7b2a  vmovaps [rsp+0xC0], xmm13
000078e5533d7b33  vmovaps [rsp+0xD0], xmm14
000078e5533d7b3c  vmovaps [rsp+0xE0], xmm15
000078e5533d7b45  sub rsp, 0x30
000078e5533d7b49  movaps [rsp], xmm1
000078e5533d7b4d  movaps [rsp+0x10], xmm15
000078e5533d7b53  movaps [rsp+0x20], xmm9
000078e5533d7b59  lea rdi, [rsp]
000078e5533d7b5d  mov esi, 0x00
000078e5533d7b62  mov rax, 0x5F83D5E17530
000078e5533d7b6c  call rax
000078e5533d7b6e  movaps xmm1, [rsp]
000078e5533d7b72  add rsp, 0x30
000078e5533d7b76  vmovaps xmm0, [rsp]
000078e5533d7b7b  vmovaps xmm2, [rsp+0x10]
000078e5533d7b81  vmovaps xmm3, [rsp+0x20]
000078e5533d7b87  vmovaps xmm4, [rsp+0x30]
000078e5533d7b8d  vmovaps xmm5, [rsp+0x40]
000078e5533d7b93  vmovaps xmm6, [rsp+0x50]
000078e5533d7b99  vmovaps xmm7, [rsp+0x60]
000078e5533d7b9f  vmovaps xmm8, [rsp+0x70]
000078e5533d7ba5  vmovaps xmm9, [rsp+0x80]
000078e5533d7bae  vmovaps xmm10, [rsp+0x90]
000078e5533d7bb7  vmovaps xmm11, [rsp+0xA0]
000078e5533d7bc0  vmovaps xmm12, [rsp+0xB0]
000078e5533d7bc9  vmovaps xmm13, [rsp+0xC0]
000078e5533d7bd2  vmovaps xmm14, [rsp+0xD0]
000078e5533d7bdb  vmovaps xmm15, [rsp+0xE0]
000078e5533d7be4  add rsp, 0xF0
000078e5533d7beb  pop r11
000078e5533d7bed  pop r10
000078e5533d7bef  pop r9
000078e5533d7bf1  pop r8
000078e5533d7bf3  pop rsi
000078e5533d7bf4  pop rdi
000078e5533d7bf5  pop rdx
000078e5533d7bf6  pop rcx
000078e5533d7bf7  pop rax
000078e5533d7bf8  add rsp, 0x08
000078e5533d7bfc  jmp 0x000078E5533D5DCB
000078e5533d7c01  call 0x000078E5532E5820
000078e5533d7c06  jmp 0x000078E5533D5DD8
000078e5533d7c0b  sub rsp, 0x08
000078e5533d7c0f  push rax
000078e5533d7c10  push rcx
000078e5533d7c11  push rdx
000078e5533d7c12  push rdi
000078e5533d7c13  push rsi
000078e5533d7c14  push r8
000078e5533d7c16  push r9
000078e5533d7c18  push r10
000078e5533d7c1a  push r11
000078e5533d7c1c  sub rsp, 0xF0
000078e5533d7c23  vmovaps [rsp], xmm0
000078e5533d7c28  vmovaps [rsp+0x10], xmm2
000078e5533d7c2e  vmovaps [rsp+0x20], xmm3
000078e5533d7c34  vmovaps [rsp+0x30], xmm4
000078e5533d7c3a  vmovaps [rsp+0x40], xmm5
000078e5533d7c40  vmovaps [rsp+0x50], xmm6
000078e5533d7c46  vmovaps [rsp+0x60], xmm7
000078e5533d7c4c  vmovaps [rsp+0x70], xmm8
000078e5533d7c52  vmovaps [rsp+0x80], xmm9
000078e5533d7c5b  vmovaps [rsp+0x90], xmm10
000078e5533d7c64  vmovaps [rsp+0xA0], xmm11
000078e5533d7c6d  vmovaps [rsp+0xB0], xmm12
000078e5533d7c76  vmovaps [rsp+0xC0], xmm13
000078e5533d7c7f  vmovaps [rsp+0xD0], xmm14
000078e5533d7c88  vmovaps [rsp+0xE0], xmm15
000078e5533d7c91  sub rsp, 0x30
000078e5533d7c95  movaps [rsp], xmm1
000078e5533d7c99  movaps [rsp+0x10], xmm5
000078e5533d7c9e  movaps [rsp+0x20], xmm7
000078e5533d7ca3  lea rdi, [rsp]
000078e5533d7ca7  mov esi, 0x00
000078e5533d7cac  mov rax, 0x5F83D5E17530
000078e5533d7cb6  call rax
000078e5533d7cb8  movaps xmm1, [rsp]
000078e5533d7cbc  add rsp, 0x30
000078e5533d7cc0  vmovaps xmm0, [rsp]
000078e5533d7cc5  vmovaps xmm2, [rsp+0x10]
000078e5533d7ccb  vmovaps xmm3, [rsp+0x20]
000078e5533d7cd1  vmovaps xmm4, [rsp+0x30]
000078e5533d7cd7  vmovaps xmm5, [rsp+0x40]
000078e5533d7cdd  vmovaps xmm6, [rsp+0x50]
000078e5533d7ce3  vmovaps xmm7, [rsp+0x60]
000078e5533d7ce9  vmovaps xmm8, [rsp+0x70]
000078e5533d7cef  vmovaps xmm9, [rsp+0x80]
000078e5533d7cf8  vmovaps xmm10, [rsp+0x90]
000078e5533d7d01  vmovaps xmm11, [rsp+0xA0]
000078e5533d7d0a  vmovaps xmm12, [rsp+0xB0]
000078e5533d7d13  vmovaps xmm13, [rsp+0xC0]
000078e5533d7d1c  vmovaps xmm14, [rsp+0xD0]
000078e5533d7d25  vmovaps xmm15, [rsp+0xE0]
000078e5533d7d2e  add rsp, 0xF0
000078e5533d7d35  pop r11
000078e5533d7d37  pop r10
000078e5533d7d39  pop r9
000078e5533d7d3b  pop r8
000078e5533d7d3d  pop rsi
000078e5533d7d3e  pop rdi
000078e5533d7d3f  pop rdx
000078e5533d7d40  pop rcx
000078e5533d7d41  pop rax
000078e5533d7d42  add rsp, 0x08
000078e5533d7d46  jmp 0x000078E5533D5E7D
000078e5533d7d4b  sub rsp, 0x08
000078e5533d7d4f  push rax
000078e5533d7d50  push rcx
000078e5533d7d51  push rdx
000078e5533d7d52  push rdi
000078e5533d7d53  push rsi
000078e5533d7d54  push r8
000078e5533d7d56  push r9
000078e5533d7d58  push r10
000078e5533d7d5a  push r11
000078e5533d7d5c  sub rsp, 0xF0
000078e5533d7d63  vmovaps [rsp], xmm0
000078e5533d7d68  vmovaps [rsp+0x10], xmm1
000078e5533d7d6e  vmovaps [rsp+0x20], xmm2
000078e5533d7d74  vmovaps [rsp+0x30], xmm3
000078e5533d7d7a  vmovaps [rsp+0x40], xmm4
000078e5533d7d80  vmovaps [rsp+0x50], xmm5
000078e5533d7d86  vmovaps [rsp+0x60], xmm6
000078e5533d7d8c  vmovaps [rsp+0x70], xmm8
000078e5533d7d92  vmovaps [rsp+0x80], xmm9
000078e5533d7d9b  vmovaps [rsp+0x90], xmm10
000078e5533d7da4  vmovaps [rsp+0xA0], xmm11
000078e5533d7dad  vmovaps [rsp+0xB0], xmm12
000078e5533d7db6  vmovaps [rsp+0xC0], xmm13
000078e5533d7dbf  vmovaps [rsp+0xD0], xmm14
000078e5533d7dc8  vmovaps [rsp+0xE0], xmm15
000078e5533d7dd1  sub rsp, 0x30
000078e5533d7dd5  movaps [rsp], xmm7
000078e5533d7dd9  movaps [rsp+0x10], xmm5
000078e5533d7dde  movaps [rsp+0x20], xmm15
000078e5533d7de4  lea rdi, [rsp]
000078e5533d7de8  mov esi, 0x00
000078e5533d7ded  mov rax, 0x5F83D5E17530
000078e5533d7df7  call rax
000078e5533d7df9  movaps xmm7, [rsp]
000078e5533d7dfd  add rsp, 0x30
000078e5533d7e01  vmovaps xmm0, [rsp]
000078e5533d7e06  vmovaps xmm1, [rsp+0x10]
000078e5533d7e0c  vmovaps xmm2, [rsp+0x20]
000078e5533d7e12  vmovaps xmm3, [rsp+0x30]
000078e5533d7e18  vmovaps xmm4, [rsp+0x40]
000078e5533d7e1e  vmovaps xmm5, [rsp+0x50]
000078e5533d7e24  vmovaps xmm6, [rsp+0x60]
000078e5533d7e2a  vmovaps xmm8, [rsp+0x70]
000078e5533d7e30  vmovaps xmm9, [rsp+0x80]
000078e5533d7e39  vmovaps xmm10, [rsp+0x90]
000078e5533d7e42  vmovaps xmm11, [rsp+0xA0]
000078e5533d7e4b  vmovaps xmm12, [rsp+0xB0]
000078e5533d7e54  vmovaps xmm13, [rsp+0xC0]
000078e5533d7e5d  vmovaps xmm14, [rsp+0xD0]
000078e5533d7e66  vmovaps xmm15, [rsp+0xE0]
000078e5533d7e6f  add rsp, 0xF0
000078e5533d7e76  pop r11
000078e5533d7e78  pop r10
000078e5533d7e7a  pop r9
000078e5533d7e7c  pop r8
000078e5533d7e7e  pop rsi
000078e5533d7e7f  pop rdi
000078e5533d7e80  pop rdx
000078e5533d7e81  pop rcx
000078e5533d7e82  pop rax
000078e5533d7e83  add rsp, 0x08
000078e5533d7e87  jmp 0x000078E5533D5EB3
000078e5533d7e8c  call 0x000078E5532D64F0
000078e5533d7e91  jmp 0x000078E5533D5EC0
000078e5533d7e96  sub rsp, 0x08
000078e5533d7e9a  push rax
000078e5533d7e9b  push rcx
000078e5533d7e9c  push rdx
000078e5533d7e9d  push rdi
000078e5533d7e9e  push rsi
000078e5533d7e9f  push r8
000078e5533d7ea1  push r9
000078e5533d7ea3  push r10
000078e5533d7ea5  push r11
000078e5533d7ea7  sub rsp, 0xF0
000078e5533d7eae  vmovaps [rsp], xmm0
000078e5533d7eb3  vmovaps [rsp+0x10], xmm1
000078e5533d7eb9  vmovaps [rsp+0x20], xmm2
000078e5533d7ebf  vmovaps [rsp+0x30], xmm3
000078e5533d7ec5  vmovaps [rsp+0x40], xmm4
000078e5533d7ecb  vmovaps [rsp+0x50], xmm5
000078e5533d7ed1  vmovaps [rsp+0x60], xmm6
000078e5533d7ed7  vmovaps [rsp+0x70], xmm7
000078e5533d7edd  vmovaps [rsp+0x80], xmm8
000078e5533d7ee6  vmovaps [rsp+0x90], xmm9
000078e5533d7eef  vmovaps [rsp+0xA0], xmm10
000078e5533d7ef8  vmovaps [rsp+0xB0], xmm11
000078e5533d7f01  vmovaps [rsp+0xC0], xmm12
000078e5533d7f0a  vmovaps [rsp+0xD0], xmm13
000078e5533d7f13  vmovaps [rsp+0xE0], xmm14
000078e5533d7f1c  sub rsp, 0x30
000078e5533d7f20  movaps [rsp], xmm15
000078e5533d7f25  movaps [rsp+0x10], xmm5
000078e5533d7f2a  movaps [rsp+0x20], xmm3
000078e5533d7f2f  lea rdi, [rsp]
000078e5533d7f33  mov esi, 0x00
000078e5533d7f38  mov rax, 0x5F83D5E17530
000078e5533d7f42  call rax
000078e5533d7f44  movaps xmm15, [rsp]
000078e5533d7f49  add rsp, 0x30
000078e5533d7f4d  vmovaps xmm0, [rsp]
000078e5533d7f52  vmovaps xmm1, [rsp+0x10]
000078e5533d7f58  vmovaps xmm2, [rsp+0x20]
000078e5533d7f5e  vmovaps xmm3, [rsp+0x30]
000078e5533d7f64  vmovaps xmm4, [rsp+0x40]
000078e5533d7f6a  vmovaps xmm5, [rsp+0x50]
000078e5533d7f70  vmovaps xmm6, [rsp+0x60]
000078e5533d7f76  vmovaps xmm7, [rsp+0x70]
000078e5533d7f7c  vmovaps xmm8, [rsp+0x80]
000078e5533d7f85  vmovaps xmm9, [rsp+0x90]
000078e5533d7f8e  vmovaps xmm10, [rsp+0xA0]
000078e5533d7f97  vmovaps xmm11, [rsp+0xB0]
000078e5533d7fa0  vmovaps xmm12, [rsp+0xC0]
000078e5533d7fa9  vmovaps xmm13, [rsp+0xD0]
000078e5533d7fb2  vmovaps xmm14, [rsp+0xE0]
000078e5533d7fbb  add rsp, 0xF0
000078e5533d7fc2  pop r11
000078e5533d7fc4  pop r10
000078e5533d7fc6  pop r9
000078e5533d7fc8  pop r8
000078e5533d7fca  pop rsi
000078e5533d7fcb  pop rdi
000078e5533d7fcc  pop rdx
000078e5533d7fcd  pop rcx
000078e5533d7fce  pop rax
000078e5533d7fcf  add rsp, 0x08
000078e5533d7fd3  jmp 0x000078E5533D5EE6
000078e5533d7fd8  sub rsp, 0x08
000078e5533d7fdc  push rax
000078e5533d7fdd  push rcx
000078e5533d7fde  push rdx
000078e5533d7fdf  push rdi
000078e5533d7fe0  push rsi
000078e5533d7fe1  push r8
000078e5533d7fe3  push r9
000078e5533d7fe5  push r10
000078e5533d7fe7  push r11
000078e5533d7fe9  sub rsp, 0xF0
000078e5533d7ff0  vmovaps [rsp], xmm0
000078e5533d7ff5  vmovaps [rsp+0x10], xmm2
000078e5533d7ffb  vmovaps [rsp+0x20], xmm3
000078e5533d8001  vmovaps [rsp+0x30], xmm4
000078e5533d8007  vmovaps [rsp+0x40], xmm5
000078e5533d800d  vmovaps [rsp+0x50], xmm6
000078e5533d8013  vmovaps [rsp+0x60], xmm7
000078e5533d8019  vmovaps [rsp+0x70], xmm8
000078e5533d801f  vmovaps [rsp+0x80], xmm9
000078e5533d8028  vmovaps [rsp+0x90], xmm10
000078e5533d8031  vmovaps [rsp+0xA0], xmm11
000078e5533d803a  vmovaps [rsp+0xB0], xmm12
000078e5533d8043  vmovaps [rsp+0xC0], xmm13
000078e5533d804c  vmovaps [rsp+0xD0], xmm14
000078e5533d8055  vmovaps [rsp+0xE0], xmm15
000078e5533d805e  sub rsp, 0x30
000078e5533d8062  movaps [rsp], xmm1
000078e5533d8066  movaps [rsp+0x10], xmm5
000078e5533d806b  movaps [rsp+0x20], xmm4
000078e5533d8070  lea rdi, [rsp]
000078e5533d8074  mov esi, 0x00
000078e5533d8079  mov rax, 0x5F83D5E17530
000078e5533d8083  call rax
000078e5533d8085  movaps xmm1, [rsp]
000078e5533d8089  add rsp, 0x30
000078e5533d808d  vmovaps xmm0, [rsp]
000078e5533d8092  vmovaps xmm2, [rsp+0x10]
000078e5533d8098  vmovaps xmm3, [rsp+0x20]
000078e5533d809e  vmovaps xmm4, [rsp+0x30]
000078e5533d80a4  vmovaps xmm5, [rsp+0x40]
000078e5533d80aa  vmovaps xmm6, [rsp+0x50]
000078e5533d80b0  vmovaps xmm7, [rsp+0x60]
000078e5533d80b6  vmovaps xmm8, [rsp+0x70]
000078e5533d80bc  vmovaps xmm9, [rsp+0x80]
000078e5533d80c5  vmovaps xmm10, [rsp+0x90]
000078e5533d80ce  vmovaps xmm11, [rsp+0xA0]
000078e5533d80d7  vmovaps xmm12, [rsp+0xB0]
000078e5533d80e0  vmovaps xmm13, [rsp+0xC0]
000078e5533d80e9  vmovaps xmm14, [rsp+0xD0]
000078e5533d80f2  vmovaps xmm15, [rsp+0xE0]
000078e5533d80fb  add rsp, 0xF0
000078e5533d8102  pop r11
000078e5533d8104  pop r10
000078e5533d8106  pop r9
000078e5533d8108  pop r8
000078e5533d810a  pop rsi
000078e5533d810b  pop rdi
000078e5533d810c  pop rdx
000078e5533d810d  pop rcx
000078e5533d810e  pop rax
000078e5533d810f  add rsp, 0x08
000078e5533d8113  jmp 0x000078E5533D5F06
000078e5533d8118  sub rsp, 0x08
000078e5533d811c  push rax
000078e5533d811d  push rcx
000078e5533d811e  push rdx
000078e5533d811f  push rdi
000078e5533d8120  push rsi
000078e5533d8121  push r8
000078e5533d8123  push r9
000078e5533d8125  push r10
000078e5533d8127  push r11
000078e5533d8129  sub rsp, 0xF0
000078e5533d8130  vmovaps [rsp], xmm0
000078e5533d8135  vmovaps [rsp+0x10], xmm1
000078e5533d813b  vmovaps [rsp+0x20], xmm2
000078e5533d8141  vmovaps [rsp+0x30], xmm3
000078e5533d8147  vmovaps [rsp+0x40], xmm5
000078e5533d814d  vmovaps [rsp+0x50], xmm6
000078e5533d8153  vmovaps [rsp+0x60], xmm7
000078e5533d8159  vmovaps [rsp+0x70], xmm8
000078e5533d815f  vmovaps [rsp+0x80], xmm9
000078e5533d8168  vmovaps [rsp+0x90], xmm10
000078e5533d8171  vmovaps [rsp+0xA0], xmm11
000078e5533d817a  vmovaps [rsp+0xB0], xmm12
000078e5533d8183  vmovaps [rsp+0xC0], xmm13
000078e5533d818c  vmovaps [rsp+0xD0], xmm14
000078e5533d8195  vmovaps [rsp+0xE0], xmm15
000078e5533d819e  sub rsp, 0x30
000078e5533d81a2  movaps [rsp], xmm4
000078e5533d81a6  movaps [rsp+0x10], xmm3
000078e5533d81ab  movaps [rsp+0x20], xmm5
000078e5533d81b0  lea rdi, [rsp]
000078e5533d81b4  mov esi, 0x00
000078e5533d81b9  mov rax, 0x5F83D5E17530
000078e5533d81c3  call rax
000078e5533d81c5  movaps xmm4, [rsp]
000078e5533d81c9  add rsp, 0x30
000078e5533d81cd  vmovaps xmm0, [rsp]
000078e5533d81d2  vmovaps xmm1, [rsp+0x10]
000078e5533d81d8  vmovaps xmm2, [rsp+0x20]
000078e5533d81de  vmovaps xmm3, [rsp+0x30]
000078e5533d81e4  vmovaps xmm5, [rsp+0x40]
000078e5533d81ea  vmovaps xmm6, [rsp+0x50]
000078e5533d81f0  vmovaps xmm7, [rsp+0x60]
000078e5533d81f6  vmovaps xmm8, [rsp+0x70]
000078e5533d81fc  vmovaps xmm9, [rsp+0x80]
000078e5533d8205  vmovaps xmm10, [rsp+0x90]
000078e5533d820e  vmovaps xmm11, [rsp+0xA0]
000078e5533d8217  vmovaps xmm12, [rsp+0xB0]
000078e5533d8220  vmovaps xmm13, [rsp+0xC0]
000078e5533d8229  vmovaps xmm14, [rsp+0xD0]
000078e5533d8232  vmovaps xmm15, [rsp+0xE0]
000078e5533d823b  add rsp, 0xF0
000078e5533d8242  pop r11
000078e5533d8244  pop r10
000078e5533d8246  pop r9
000078e5533d8248  pop r8
000078e5533d824a  pop rsi
000078e5533d824b  pop rdi
000078e5533d824c  pop rdx
000078e5533d824d  pop rcx
000078e5533d824e  pop rax
000078e5533d824f  add rsp, 0x08
000078e5533d8253  jmp 0x000078E5533D5F54
000078e5533d8258  call 0x000078E5532D64F0
000078e5533d825d  jmp 0x000078E5533D5F61
000078e5533d8262  sub rsp, 0x08
000078e5533d8266  push rax
000078e5533d8267  push rcx
000078e5533d8268  push rdx
000078e5533d8269  push rdi
000078e5533d826a  push rsi
000078e5533d826b  push r8
000078e5533d826d  push r9
000078e5533d826f  push r10
000078e5533d8271  push r11
000078e5533d8273  sub rsp, 0xF0
000078e5533d827a  vmovaps [rsp], xmm0
000078e5533d827f  vmovaps [rsp+0x10], xmm1
000078e5533d8285  vmovaps [rsp+0x20], xmm2
000078e5533d828b  vmovaps [rsp+0x30], xmm3
000078e5533d8291  vmovaps [rsp+0x40], xmm4
000078e5533d8297  vmovaps [rsp+0x50], xmm6
000078e5533d829d  vmovaps [rsp+0x60], xmm7
000078e5533d82a3  vmovaps [rsp+0x70], xmm8
000078e5533d82a9  vmovaps [rsp+0x80], xmm9
000078e5533d82b2  vmovaps [rsp+0x90], xmm10
000078e5533d82bb  vmovaps [rsp+0xA0], xmm11
000078e5533d82c4  vmovaps [rsp+0xB0], xmm12
000078e5533d82cd  vmovaps [rsp+0xC0], xmm13
000078e5533d82d6  vmovaps [rsp+0xD0], xmm14
000078e5533d82df  vmovaps [rsp+0xE0], xmm15
000078e5533d82e8  sub rsp, 0x30
000078e5533d82ec  movaps [rsp], xmm5
000078e5533d82f0  movaps [rsp+0x10], xmm6
000078e5533d82f5  movaps [rsp+0x20], xmm3
000078e5533d82fa  lea rdi, [rsp]
000078e5533d82fe  mov esi, 0x00
000078e5533d8303  mov rax, 0x5F83D5E17530
000078e5533d830d  call rax
000078e5533d830f  movaps xmm5, [rsp]
000078e5533d8313  add rsp, 0x30
000078e5533d8317  vmovaps xmm0, [rsp]
000078e5533d831c  vmovaps xmm1, [rsp+0x10]
000078e5533d8322  vmovaps xmm2, [rsp+0x20]
000078e5533d8328  vmovaps xmm3, [rsp+0x30]
000078e5533d832e  vmovaps xmm4, [rsp+0x40]
000078e5533d8334  vmovaps xmm6, [rsp+0x50]
000078e5533d833a  vmovaps xmm7, [rsp+0x60]
000078e5533d8340  vmovaps xmm8, [rsp+0x70]
000078e5533d8346  vmovaps xmm9, [rsp+0x80]
000078e5533d834f  vmovaps xmm10, [rsp+0x90]
000078e5533d8358  vmovaps xmm11, [rsp+0xA0]
000078e5533d8361  vmovaps xmm12, [rsp+0xB0]
000078e5533d836a  vmovaps xmm13, [rsp+0xC0]
000078e5533d8373  vmovaps xmm14, [rsp+0xD0]
000078e5533d837c  vmovaps xmm15, [rsp+0xE0]
000078e5533d8385  add rsp, 0xF0
000078e5533d838c  pop r11
000078e5533d838e  pop r10
000078e5533d8390  pop r9
000078e5533d8392  pop r8
000078e5533d8394  pop rsi
000078e5533d8395  pop rdi
000078e5533d8396  pop rdx
000078e5533d8397  pop rcx
000078e5533d8398  pop rax
000078e5533d8399  add rsp, 0x08
000078e5533d839d  jmp 0x000078E5533D5F87
000078e5533d83a2  sub rsp, 0x08
000078e5533d83a6  push rax
000078e5533d83a7  push rcx
000078e5533d83a8  push rdx
000078e5533d83a9  push rdi
000078e5533d83aa  push rsi
000078e5533d83ab  push r8
000078e5533d83ad  push r9
000078e5533d83af  push r10
000078e5533d83b1  push r11
000078e5533d83b3  sub rsp, 0xF0
000078e5533d83ba  vmovaps [rsp], xmm0
000078e5533d83bf  vmovaps [rsp+0x10], xmm1
000078e5533d83c5  vmovaps [rsp+0x20], xmm2
000078e5533d83cb  vmovaps [rsp+0x30], xmm3
000078e5533d83d1  vmovaps [rsp+0x40], xmm4
000078e5533d83d7  vmovaps [rsp+0x50], xmm5
000078e5533d83dd  vmovaps [rsp+0x60], xmm7
000078e5533d83e3  vmovaps [rsp+0x70], xmm8
000078e5533d83e9  vmovaps [rsp+0x80], xmm9
000078e5533d83f2  vmovaps [rsp+0x90], xmm10
000078e5533d83fb  vmovaps [rsp+0xA0], xmm11
000078e5533d8404  vmovaps [rsp+0xB0], xmm12
000078e5533d840d  vmovaps [rsp+0xC0], xmm13
000078e5533d8416  vmovaps [rsp+0xD0], xmm14
000078e5533d841f  vmovaps [rsp+0xE0], xmm15
000078e5533d8428  sub rsp, 0x30
000078e5533d842c  movaps [rsp], xmm6
000078e5533d8430  movaps [rsp+0x10], xmm9
000078e5533d8436  movaps [rsp+0x20], xmm1
000078e5533d843b  lea rdi, [rsp]
000078e5533d843f  mov esi, 0x00
000078e5533d8444  mov rax, 0x5F83D5E17530
000078e5533d844e  call rax
000078e5533d8450  movaps xmm6, [rsp]
000078e5533d8454  add rsp, 0x30
000078e5533d8458  vmovaps xmm0, [rsp]
000078e5533d845d  vmovaps xmm1, [rsp+0x10]
000078e5533d8463  vmovaps xmm2, [rsp+0x20]
000078e5533d8469  vmovaps xmm3, [rsp+0x30]
000078e5533d846f  vmovaps xmm4, [rsp+0x40]
000078e5533d8475  vmovaps xmm5, [rsp+0x50]
000078e5533d847b  vmovaps xmm7, [rsp+0x60]
000078e5533d8481  vmovaps xmm8, [rsp+0x70]
000078e5533d8487  vmovaps xmm9, [rsp+0x80]
000078e5533d8490  vmovaps xmm10, [rsp+0x90]
000078e5533d8499  vmovaps xmm11, [rsp+0xA0]
000078e5533d84a2  vmovaps xmm12, [rsp+0xB0]
000078e5533d84ab  vmovaps xmm13, [rsp+0xC0]
000078e5533d84b4  vmovaps xmm14, [rsp+0xD0]
000078e5533d84bd  vmovaps xmm15, [rsp+0xE0]
000078e5533d84c6  add rsp, 0xF0
000078e5533d84cd  pop r11
000078e5533d84cf  pop r10
000078e5533d84d1  pop r9
000078e5533d84d3  pop r8
000078e5533d84d5  pop rsi
000078e5533d84d6  pop rdi
000078e5533d84d7  pop rdx
000078e5533d84d8  pop rcx
000078e5533d84d9  pop rax
000078e5533d84da  add rsp, 0x08
000078e5533d84de  jmp 0x000078E5533D5FAB
000078e5533d84e3  sub rsp, 0x08
000078e5533d84e7  push rax
000078e5533d84e8  push rcx
000078e5533d84e9  push rdx
000078e5533d84ea  push rdi
000078e5533d84eb  push rsi
000078e5533d84ec  push r8
000078e5533d84ee  push r9
000078e5533d84f0  push r10
000078e5533d84f2  push r11
000078e5533d84f4  sub rsp, 0xF0
000078e5533d84fb  vmovaps [rsp], xmm0
000078e5533d8500  vmovaps [rsp+0x10], xmm1
000078e5533d8506  vmovaps [rsp+0x20], xmm2
000078e5533d850c  vmovaps [rsp+0x30], xmm3
000078e5533d8512  vmovaps [rsp+0x40], xmm4
000078e5533d8518  vmovaps [rsp+0x50], xmm5
000078e5533d851e  vmovaps [rsp+0x60], xmm6
000078e5533d8524  vmovaps [rsp+0x70], xmm7
000078e5533d852a  vmovaps [rsp+0x80], xmm8
000078e5533d8533  vmovaps [rsp+0x90], xmm10
000078e5533d853c  vmovaps [rsp+0xA0], xmm11
000078e5533d8545  vmovaps [rsp+0xB0], xmm12
000078e5533d854e  vmovaps [rsp+0xC0], xmm13
000078e5533d8557  vmovaps [rsp+0xD0], xmm14
000078e5533d8560  vmovaps [rsp+0xE0], xmm15
000078e5533d8569  sub rsp, 0x30
000078e5533d856d  movaps [rsp], xmm9
000078e5533d8572  movaps [rsp+0x10], xmm3
000078e5533d8577  movaps [rsp+0x20], xmm1
000078e5533d857c  lea rdi, [rsp]
000078e5533d8580  mov esi, 0x00
000078e5533d8585  mov rax, 0x5F83D5E17530
000078e5533d858f  call rax
000078e5533d8591  movaps xmm9, [rsp]
000078e5533d8596  add rsp, 0x30
000078e5533d859a  vmovaps xmm0, [rsp]
000078e5533d859f  vmovaps xmm1, [rsp+0x10]
000078e5533d85a5  vmovaps xmm2, [rsp+0x20]
000078e5533d85ab  vmovaps xmm3, [rsp+0x30]
000078e5533d85b1  vmovaps xmm4, [rsp+0x40]
000078e5533d85b7  vmovaps xmm5, [rsp+0x50]
000078e5533d85bd  vmovaps xmm6, [rsp+0x60]
000078e5533d85c3  vmovaps xmm7, [rsp+0x70]
000078e5533d85c9  vmovaps xmm8, [rsp+0x80]
000078e5533d85d2  vmovaps xmm10, [rsp+0x90]
000078e5533d85db  vmovaps xmm11, [rsp+0xA0]
000078e5533d85e4  vmovaps xmm12, [rsp+0xB0]
000078e5533d85ed  vmovaps xmm13, [rsp+0xC0]
000078e5533d85f6  vmovaps xmm14, [rsp+0xD0]
000078e5533d85ff  vmovaps xmm15, [rsp+0xE0]
000078e5533d8608  add rsp, 0xF0
000078e5533d860f  pop r11
000078e5533d8611  pop r10
000078e5533d8613  pop r9
000078e5533d8615  pop r8
000078e5533d8617  pop rsi
000078e5533d8618  pop rdi
000078e5533d8619  pop rdx
000078e5533d861a  pop rcx
000078e5533d861b  pop rax
000078e5533d861c  add rsp, 0x08
000078e5533d8620  jmp 0x000078E5533D5FF7
000078e5533d8625  call 0x000078E5532D64F0
000078e5533d862a  jmp 0x000078E5533D6004
000078e5533d862f  sub rsp, 0x08
000078e5533d8633  push rax
000078e5533d8634  push rcx
000078e5533d8635  push rdx
000078e5533d8636  push rdi
000078e5533d8637  push rsi
000078e5533d8638  push r8
000078e5533d863a  push r9
000078e5533d863c  push r10
000078e5533d863e  push r11
000078e5533d8640  sub rsp, 0xF0
000078e5533d8647  vmovaps [rsp], xmm0
000078e5533d864c  vmovaps [rsp+0x10], xmm1
000078e5533d8652  vmovaps [rsp+0x20], xmm2
000078e5533d8658  vmovaps [rsp+0x30], xmm3
000078e5533d865e  vmovaps [rsp+0x40], xmm4
000078e5533d8664  vmovaps [rsp+0x50], xmm5
000078e5533d866a  vmovaps [rsp+0x60], xmm6
000078e5533d8670  vmovaps [rsp+0x70], xmm7
000078e5533d8676  vmovaps [rsp+0x80], xmm8
000078e5533d867f  vmovaps [rsp+0x90], xmm9
000078e5533d8688  vmovaps [rsp+0xA0], xmm10
000078e5533d8691  vmovaps [rsp+0xB0], xmm11
000078e5533d869a  vmovaps [rsp+0xC0], xmm12
000078e5533d86a3  vmovaps [rsp+0xD0], xmm13
000078e5533d86ac  vmovaps [rsp+0xE0], xmm14
000078e5533d86b5  sub rsp, 0x30
000078e5533d86b9  movaps [rsp], xmm15
000078e5533d86be  movaps [rsp+0x10], xmm3
000078e5533d86c3  movaps [rsp+0x20], xmm7
000078e5533d86c8  lea rdi, [rsp]
000078e5533d86cc  mov esi, 0x00
000078e5533d86d1  mov rax, 0x5F83D5E17530
000078e5533d86db  call rax
000078e5533d86dd  movaps xmm15, [rsp]
000078e5533d86e2  add rsp, 0x30
000078e5533d86e6  vmovaps xmm0, [rsp]
000078e5533d86eb  vmovaps xmm1, [rsp+0x10]
000078e5533d86f1  vmovaps xmm2, [rsp+0x20]
000078e5533d86f7  vmovaps xmm3, [rsp+0x30]
000078e5533d86fd  vmovaps xmm4, [rsp+0x40]
000078e5533d8703  vmovaps xmm5, [rsp+0x50]
000078e5533d8709  vmovaps xmm6, [rsp+0x60]
000078e5533d870f  vmovaps xmm7, [rsp+0x70]
000078e5533d8715  vmovaps xmm8, [rsp+0x80]
000078e5533d871e  vmovaps xmm9, [rsp+0x90]
000078e5533d8727  vmovaps xmm10, [rsp+0xA0]
000078e5533d8730  vmovaps xmm11, [rsp+0xB0]
000078e5533d8739  vmovaps xmm12, [rsp+0xC0]
000078e5533d8742  vmovaps xmm13, [rsp+0xD0]
000078e5533d874b  vmovaps xmm14, [rsp+0xE0]
000078e5533d8754  add rsp, 0xF0
000078e5533d875b  pop r11
000078e5533d875d  pop r10
000078e5533d875f  pop r9
000078e5533d8761  pop r8
000078e5533d8763  pop rsi
000078e5533d8764  pop rdi
000078e5533d8765  pop rdx
000078e5533d8766  pop rcx
000078e5533d8767  pop rax
000078e5533d8768  add rsp, 0x08
000078e5533d876c  jmp 0x000078E5533D6030
000078e5533d8771  sub rsp, 0x08
000078e5533d8775  push rax
000078e5533d8776  push rcx
000078e5533d8777  push rdx
000078e5533d8778  push rdi
000078e5533d8779  push rsi
000078e5533d877a  push r8
000078e5533d877c  push r9
000078e5533d877e  push r10
000078e5533d8780  push r11
000078e5533d8782  sub rsp, 0xF0
000078e5533d8789  vmovaps [rsp], xmm0
000078e5533d878e  vmovaps [rsp+0x10], xmm1
000078e5533d8794  vmovaps [rsp+0x20], xmm2
000078e5533d879a  vmovaps [rsp+0x30], xmm4
000078e5533d87a0  vmovaps [rsp+0x40], xmm5
000078e5533d87a6  vmovaps [rsp+0x50], xmm6
000078e5533d87ac  vmovaps [rsp+0x60], xmm7
000078e5533d87b2  vmovaps [rsp+0x70], xmm8
000078e5533d87b8  vmovaps [rsp+0x80], xmm9
000078e5533d87c1  vmovaps [rsp+0x90], xmm10
000078e5533d87ca  vmovaps [rsp+0xA0], xmm11
000078e5533d87d3  vmovaps [rsp+0xB0], xmm12
000078e5533d87dc  vmovaps [rsp+0xC0], xmm13
000078e5533d87e5  vmovaps [rsp+0xD0], xmm14
000078e5533d87ee  vmovaps [rsp+0xE0], xmm15
000078e5533d87f7  sub rsp, 0x30
000078e5533d87fb  movaps [rsp], xmm3
000078e5533d87ff  movaps [rsp+0x10], xmm1
000078e5533d8804  movaps [rsp+0x20], xmm15
000078e5533d880a  lea rdi, [rsp]
000078e5533d880e  mov esi, 0x00
000078e5533d8813  mov rax, 0x5F83D5E17530
000078e5533d881d  call rax
000078e5533d881f  movaps xmm3, [rsp]
000078e5533d8823  add rsp, 0x30
000078e5533d8827  vmovaps xmm0, [rsp]
000078e5533d882c  vmovaps xmm1, [rsp+0x10]
000078e5533d8832  vmovaps xmm2, [rsp+0x20]
000078e5533d8838  vmovaps xmm4, [rsp+0x30]
000078e5533d883e  vmovaps xmm5, [rsp+0x40]
000078e5533d8844  vmovaps xmm6, [rsp+0x50]
000078e5533d884a  vmovaps xmm7, [rsp+0x60]
000078e5533d8850  vmovaps xmm8, [rsp+0x70]
000078e5533d8856  vmovaps xmm9, [rsp+0x80]
000078e5533d885f  vmovaps xmm10, [rsp+0x90]
000078e5533d8868  vmovaps xmm11, [rsp+0xA0]
000078e5533d8871  vmovaps xmm12, [rsp+0xB0]
000078e5533d887a  vmovaps xmm13, [rsp+0xC0]
000078e5533d8883  vmovaps xmm14, [rsp+0xD0]
000078e5533d888c  vmovaps xmm15, [rsp+0xE0]
000078e5533d8895  add rsp, 0xF0
000078e5533d889c  pop r11
000078e5533d889e  pop r10
000078e5533d88a0  pop r9
000078e5533d88a2  pop r8
000078e5533d88a4  pop rsi
000078e5533d88a5  pop rdi
000078e5533d88a6  pop rdx
000078e5533d88a7  pop rcx
000078e5533d88a8  pop rax
000078e5533d88a9  add rsp, 0x08
000078e5533d88ad  jmp 0x000078E5533D60BF
000078e5533d88b2  call 0x000078E5532D64F0
000078e5533d88b7  jmp 0x000078E5533D60C9
000078e5533d88bc  sub rsp, 0x08
000078e5533d88c0  push rax
000078e5533d88c1  push rcx
000078e5533d88c2  push rdx
000078e5533d88c3  push rdi
000078e5533d88c4  push rsi
000078e5533d88c5  push r8
000078e5533d88c7  push r9
000078e5533d88c9  push r10
000078e5533d88cb  push r11
000078e5533d88cd  sub rsp, 0xF0
000078e5533d88d4  vmovaps [rsp], xmm0
000078e5533d88d9  vmovaps [rsp+0x10], xmm1
000078e5533d88df  vmovaps [rsp+0x20], xmm2
000078e5533d88e5  vmovaps [rsp+0x30], xmm3
000078e5533d88eb  vmovaps [rsp+0x40], xmm4
000078e5533d88f1  vmovaps [rsp+0x50], xmm5
000078e5533d88f7  vmovaps [rsp+0x60], xmm6
000078e5533d88fd  vmovaps [rsp+0x70], xmm7
000078e5533d8903  vmovaps [rsp+0x80], xmm8
000078e5533d890c  vmovaps [rsp+0x90], xmm9
000078e5533d8915  vmovaps [rsp+0xA0], xmm10
000078e5533d891e  vmovaps [rsp+0xB0], xmm11
000078e5533d8927  vmovaps [rsp+0xC0], xmm12
000078e5533d8930  vmovaps [rsp+0xD0], xmm13
000078e5533d8939  vmovaps [rsp+0xE0], xmm14
000078e5533d8942  sub rsp, 0x30
000078e5533d8946  movaps [rsp], xmm15
000078e5533d894b  movaps [rsp+0x10], xmm14
000078e5533d8951  movaps [rsp+0x20], xmm4
000078e5533d8956  lea rdi, [rsp]
000078e5533d895a  mov esi, 0x00
000078e5533d895f  mov rax, 0x5F83D5E17530
000078e5533d8969  call rax
000078e5533d896b  movaps xmm15, [rsp]
000078e5533d8970  add rsp, 0x30
000078e5533d8974  vmovaps xmm0, [rsp]
000078e5533d8979  vmovaps xmm1, [rsp+0x10]
000078e5533d897f  vmovaps xmm2, [rsp+0x20]
000078e5533d8985  vmovaps xmm3, [rsp+0x30]
000078e5533d898b  vmovaps xmm4, [rsp+0x40]
000078e5533d8991  vmovaps xmm5, [rsp+0x50]
000078e5533d8997  vmovaps xmm6, [rsp+0x60]
000078e5533d899d  vmovaps xmm7, [rsp+0x70]
000078e5533d89a3  vmovaps xmm8, [rsp+0x80]
000078e5533d89ac  vmovaps xmm9, [rsp+0x90]
000078e5533d89b5  vmovaps xmm10, [rsp+0xA0]
000078e5533d89be  vmovaps xmm11, [rsp+0xB0]
000078e5533d89c7  vmovaps xmm12, [rsp+0xC0]
000078e5533d89d0  vmovaps xmm13, [rsp+0xD0]
000078e5533d89d9  vmovaps xmm14, [rsp+0xE0]
000078e5533d89e2  add rsp, 0xF0
000078e5533d89e9  pop r11
000078e5533d89eb  pop r10
000078e5533d89ed  pop r9
000078e5533d89ef  pop r8
000078e5533d89f1  pop rsi
000078e5533d89f2  pop rdi
000078e5533d89f3  pop rdx
000078e5533d89f4  pop rcx
000078e5533d89f5  pop rax
000078e5533d89f6  add rsp, 0x08
000078e5533d89fa  jmp 0x000078E5533D60F7
000078e5533d89ff  sub rsp, 0x08
000078e5533d8a03  push rax
000078e5533d8a04  push rcx
000078e5533d8a05  push rdx
000078e5533d8a06  push rdi
000078e5533d8a07  push rsi
000078e5533d8a08  push r8
000078e5533d8a0a  push r9
000078e5533d8a0c  push r10
000078e5533d8a0e  push r11
000078e5533d8a10  sub rsp, 0xF0
000078e5533d8a17  vmovaps [rsp], xmm0
000078e5533d8a1c  vmovaps [rsp+0x10], xmm1
000078e5533d8a22  vmovaps [rsp+0x20], xmm2
000078e5533d8a28  vmovaps [rsp+0x30], xmm3
000078e5533d8a2e  vmovaps [rsp+0x40], xmm4
000078e5533d8a34  vmovaps [rsp+0x50], xmm5
000078e5533d8a3a  vmovaps [rsp+0x60], xmm6
000078e5533d8a40  vmovaps [rsp+0x70], xmm7
000078e5533d8a46  vmovaps [rsp+0x80], xmm8
000078e5533d8a4f  vmovaps [rsp+0x90], xmm9
000078e5533d8a58  vmovaps [rsp+0xA0], xmm10
000078e5533d8a61  vmovaps [rsp+0xB0], xmm11
000078e5533d8a6a  vmovaps [rsp+0xC0], xmm12
000078e5533d8a73  vmovaps [rsp+0xD0], xmm13
000078e5533d8a7c  vmovaps [rsp+0xE0], xmm15
000078e5533d8a85  sub rsp, 0x30
000078e5533d8a89  movaps [rsp], xmm14
000078e5533d8a8e  movaps [rsp+0x10], xmm2
000078e5533d8a93  movaps [rsp+0x20], xmm1
000078e5533d8a98  lea rdi, [rsp]
000078e5533d8a9c  mov esi, 0x00
000078e5533d8aa1  mov rax, 0x5F83D5E17530
000078e5533d8aab  call rax
000078e5533d8aad  movaps xmm14, [rsp]
000078e5533d8ab2  add rsp, 0x30
000078e5533d8ab6  vmovaps xmm0, [rsp]
000078e5533d8abb  vmovaps xmm1, [rsp+0x10]
000078e5533d8ac1  vmovaps xmm2, [rsp+0x20]
000078e5533d8ac7  vmovaps xmm3, [rsp+0x30]
000078e5533d8acd  vmovaps xmm4, [rsp+0x40]
000078e5533d8ad3  vmovaps xmm5, [rsp+0x50]
000078e5533d8ad9  vmovaps xmm6, [rsp+0x60]
000078e5533d8adf  vmovaps xmm7, [rsp+0x70]
000078e5533d8ae5  vmovaps xmm8, [rsp+0x80]
000078e5533d8aee  vmovaps xmm9, [rsp+0x90]
000078e5533d8af7  vmovaps xmm10, [rsp+0xA0]
000078e5533d8b00  vmovaps xmm11, [rsp+0xB0]
000078e5533d8b09  vmovaps xmm12, [rsp+0xC0]
000078e5533d8b12  vmovaps xmm13, [rsp+0xD0]
000078e5533d8b1b  vmovaps xmm15, [rsp+0xE0]
000078e5533d8b24  add rsp, 0xF0
000078e5533d8b2b  pop r11
000078e5533d8b2d  pop r10
000078e5533d8b2f  pop r9
000078e5533d8b31  pop r8
000078e5533d8b33  pop rsi
000078e5533d8b34  pop rdi
000078e5533d8b35  pop rdx
000078e5533d8b36  pop rcx
000078e5533d8b37  pop rax
000078e5533d8b38  add rsp, 0x08
000078e5533d8b3c  jmp 0x000078E5533D611D
000078e5533d8b41  sub rsp, 0x08
000078e5533d8b45  push rax
000078e5533d8b46  push rcx
000078e5533d8b47  push rdx
000078e5533d8b48  push rdi
000078e5533d8b49  push rsi
000078e5533d8b4a  push r8
000078e5533d8b4c  push r9
000078e5533d8b4e  push r10
000078e5533d8b50  push r11
000078e5533d8b52  sub rsp, 0xF0
000078e5533d8b59  vmovaps [rsp], xmm0
000078e5533d8b5e  vmovaps [rsp+0x10], xmm2
000078e5533d8b64  vmovaps [rsp+0x20], xmm3
000078e5533d8b6a  vmovaps [rsp+0x30], xmm4
000078e5533d8b70  vmovaps [rsp+0x40], xmm5
000078e5533d8b76  vmovaps [rsp+0x50], xmm6
000078e5533d8b7c  vmovaps [rsp+0x60], xmm7
000078e5533d8b82  vmovaps [rsp+0x70], xmm8
000078e5533d8b88  vmovaps [rsp+0x80], xmm9
000078e5533d8b91  vmovaps [rsp+0x90], xmm10
000078e5533d8b9a  vmovaps [rsp+0xA0], xmm11
000078e5533d8ba3  vmovaps [rsp+0xB0], xmm12
000078e5533d8bac  vmovaps [rsp+0xC0], xmm13
000078e5533d8bb5  vmovaps [rsp+0xD0], xmm14
000078e5533d8bbe  vmovaps [rsp+0xE0], xmm15
000078e5533d8bc7  sub rsp, 0x30
000078e5533d8bcb  movaps [rsp], xmm1
000078e5533d8bcf  movaps [rsp+0x10], xmm4
000078e5533d8bd4  movaps [rsp+0x20], xmm9
000078e5533d8bda  lea rdi, [rsp]
000078e5533d8bde  mov esi, 0x00
000078e5533d8be3  mov rax, 0x5F83D5E17530
000078e5533d8bed  call rax
000078e5533d8bef  movaps xmm1, [rsp]
000078e5533d8bf3  add rsp, 0x30
000078e5533d8bf7  vmovaps xmm0, [rsp]
000078e5533d8bfc  vmovaps xmm2, [rsp+0x10]
000078e5533d8c02  vmovaps xmm3, [rsp+0x20]
000078e5533d8c08  vmovaps xmm4, [rsp+0x30]
000078e5533d8c0e  vmovaps xmm5, [rsp+0x40]
000078e5533d8c14  vmovaps xmm6, [rsp+0x50]
000078e5533d8c1a  vmovaps xmm7, [rsp+0x60]
000078e5533d8c20  vmovaps xmm8, [rsp+0x70]
000078e5533d8c26  vmovaps xmm9, [rsp+0x80]
000078e5533d8c2f  vmovaps xmm10, [rsp+0x90]
000078e5533d8c38  vmovaps xmm11, [rsp+0xA0]
000078e5533d8c41  vmovaps xmm12, [rsp+0xB0]
000078e5533d8c4a  vmovaps xmm13, [rsp+0xC0]
000078e5533d8c53  vmovaps xmm14, [rsp+0xD0]
000078e5533d8c5c  vmovaps xmm15, [rsp+0xE0]
000078e5533d8c65  add rsp, 0xF0
000078e5533d8c6c  pop r11
000078e5533d8c6e  pop r10
000078e5533d8c70  pop r9
000078e5533d8c72  pop r8
000078e5533d8c74  pop rsi
000078e5533d8c75  pop rdi
000078e5533d8c76  pop rdx
000078e5533d8c77  pop rcx
000078e5533d8c78  pop rax
000078e5533d8c79  add rsp, 0x08
000078e5533d8c7d  jmp 0x000078E5533D613B
000078e5533d8c82  sub rsp, 0x08
000078e5533d8c86  push rax
000078e5533d8c87  push rcx
000078e5533d8c88  push rdx
000078e5533d8c89  push rdi
000078e5533d8c8a  push rsi
000078e5533d8c8b  push r8
000078e5533d8c8d  push r9
000078e5533d8c8f  push r10
000078e5533d8c91  push r11
000078e5533d8c93  sub rsp, 0xF0
000078e5533d8c9a  vmovaps [rsp], xmm0
000078e5533d8c9f  vmovaps [rsp+0x10], xmm1
000078e5533d8ca5  vmovaps [rsp+0x20], xmm2
000078e5533d8cab  vmovaps [rsp+0x30], xmm3
000078e5533d8cb1  vmovaps [rsp+0x40], xmm5
000078e5533d8cb7  vmovaps [rsp+0x50], xmm6
000078e5533d8cbd  vmovaps [rsp+0x60], xmm7
000078e5533d8cc3  vmovaps [rsp+0x70], xmm8
000078e5533d8cc9  vmovaps [rsp+0x80], xmm9
000078e5533d8cd2  vmovaps [rsp+0x90], xmm10
000078e5533d8cdb  vmovaps [rsp+0xA0], xmm11
000078e5533d8ce4  vmovaps [rsp+0xB0], xmm12
000078e5533d8ced  vmovaps [rsp+0xC0], xmm13
000078e5533d8cf6  vmovaps [rsp+0xD0], xmm14
000078e5533d8cff  vmovaps [rsp+0xE0], xmm15
000078e5533d8d08  sub rsp, 0x30
000078e5533d8d0c  movaps [rsp], xmm4
000078e5533d8d10  movaps [rsp+0x10], xmm2
000078e5533d8d15  movaps [rsp+0x20], xmm9
000078e5533d8d1b  lea rdi, [rsp]
000078e5533d8d1f  mov esi, 0x00
000078e5533d8d24  mov rax, 0x5F83D5E17530
000078e5533d8d2e  call rax
000078e5533d8d30  movaps xmm4, [rsp]
000078e5533d8d34  add rsp, 0x30
000078e5533d8d38  vmovaps xmm0, [rsp]
000078e5533d8d3d  vmovaps xmm1, [rsp+0x10]
000078e5533d8d43  vmovaps xmm2, [rsp+0x20]
000078e5533d8d49  vmovaps xmm3, [rsp+0x30]
000078e5533d8d4f  vmovaps xmm5, [rsp+0x40]
000078e5533d8d55  vmovaps xmm6, [rsp+0x50]
000078e5533d8d5b  vmovaps xmm7, [rsp+0x60]
000078e5533d8d61  vmovaps xmm8, [rsp+0x70]
000078e5533d8d67  vmovaps xmm9, [rsp+0x80]
000078e5533d8d70  vmovaps xmm10, [rsp+0x90]
000078e5533d8d79  vmovaps xmm11, [rsp+0xA0]
000078e5533d8d82  vmovaps xmm12, [rsp+0xB0]
000078e5533d8d8b  vmovaps xmm13, [rsp+0xC0]
000078e5533d8d94  vmovaps xmm14, [rsp+0xD0]
000078e5533d8d9d  vmovaps xmm15, [rsp+0xE0]
000078e5533d8da6  add rsp, 0xF0
000078e5533d8dad  pop r11
000078e5533d8daf  pop r10
000078e5533d8db1  pop r9
000078e5533d8db3  pop r8
000078e5533d8db5  pop rsi
000078e5533d8db6  pop rdi
000078e5533d8db7  pop rdx
000078e5533d8db8  pop rcx
000078e5533d8db9  pop rax
000078e5533d8dba  add rsp, 0x08
000078e5533d8dbe  jmp 0x000078E5533D616B
000078e5533d8dc3  sub rsp, 0x08
000078e5533d8dc7  push rax
000078e5533d8dc8  push rcx
000078e5533d8dc9  push rdx
000078e5533d8dca  push rdi
000078e5533d8dcb  push rsi
000078e5533d8dcc  push r8
000078e5533d8dce  push r9
000078e5533d8dd0  push r10
000078e5533d8dd2  push r11
000078e5533d8dd4  sub rsp, 0xF0
000078e5533d8ddb  vmovaps [rsp], xmm0
000078e5533d8de0  vmovaps [rsp+0x10], xmm1
000078e5533d8de6  vmovaps [rsp+0x20], xmm2
000078e5533d8dec  vmovaps [rsp+0x30], xmm3
000078e5533d8df2  vmovaps [rsp+0x40], xmm4
000078e5533d8df8  vmovaps [rsp+0x50], xmm5
000078e5533d8dfe  vmovaps [rsp+0x60], xmm6
000078e5533d8e04  vmovaps [rsp+0x70], xmm7
000078e5533d8e0a  vmovaps [rsp+0x80], xmm8
000078e5533d8e13  vmovaps [rsp+0x90], xmm10
000078e5533d8e1c  vmovaps [rsp+0xA0], xmm11
000078e5533d8e25  vmovaps [rsp+0xB0], xmm12
000078e5533d8e2e  vmovaps [rsp+0xC0], xmm13
000078e5533d8e37  vmovaps [rsp+0xD0], xmm14
000078e5533d8e40  vmovaps [rsp+0xE0], xmm15
000078e5533d8e49  sub rsp, 0x30
000078e5533d8e4d  movaps [rsp], xmm9
000078e5533d8e52  movaps [rsp+0x10], xmm2
000078e5533d8e57  movaps [rsp+0x20], xmm1
000078e5533d8e5c  lea rdi, [rsp]
000078e5533d8e60  mov esi, 0x00
000078e5533d8e65  mov rax, 0x5F83D5E17530
000078e5533d8e6f  call rax
000078e5533d8e71  movaps xmm9, [rsp]
000078e5533d8e76  add rsp, 0x30
000078e5533d8e7a  vmovaps xmm0, [rsp]
000078e5533d8e7f  vmovaps xmm1, [rsp+0x10]
000078e5533d8e85  vmovaps xmm2, [rsp+0x20]
000078e5533d8e8b  vmovaps xmm3, [rsp+0x30]
000078e5533d8e91  vmovaps xmm4, [rsp+0x40]
000078e5533d8e97  vmovaps xmm5, [rsp+0x50]
000078e5533d8e9d  vmovaps xmm6, [rsp+0x60]
000078e5533d8ea3  vmovaps xmm7, [rsp+0x70]
000078e5533d8ea9  vmovaps xmm8, [rsp+0x80]
000078e5533d8eb2  vmovaps xmm10, [rsp+0x90]
000078e5533d8ebb  vmovaps xmm11, [rsp+0xA0]
000078e5533d8ec4  vmovaps xmm12, [rsp+0xB0]
000078e5533d8ecd  vmovaps xmm13, [rsp+0xC0]
000078e5533d8ed6  vmovaps xmm14, [rsp+0xD0]
000078e5533d8edf  vmovaps xmm15, [rsp+0xE0]
000078e5533d8ee8  add rsp, 0xF0
000078e5533d8eef  pop r11
000078e5533d8ef1  pop r10
000078e5533d8ef3  pop r9
000078e5533d8ef5  pop r8
000078e5533d8ef7  pop rsi
000078e5533d8ef8  pop rdi
000078e5533d8ef9  pop rdx
000078e5533d8efa  pop rcx
000078e5533d8efb  pop rax
000078e5533d8efc  add rsp, 0x08
000078e5533d8f00  jmp 0x000078E5533D61A1
000078e5533d8f05  sub rsp, 0x08
000078e5533d8f09  push rax
000078e5533d8f0a  push rcx
000078e5533d8f0b  push rdx
000078e5533d8f0c  push rdi
000078e5533d8f0d  push rsi
000078e5533d8f0e  push r8
000078e5533d8f10  push r9
000078e5533d8f12  push r10
000078e5533d8f14  push r11
000078e5533d8f16  sub rsp, 0xF0
000078e5533d8f1d  vmovaps [rsp], xmm0
000078e5533d8f22  vmovaps [rsp+0x10], xmm2
000078e5533d8f28  vmovaps [rsp+0x20], xmm3
000078e5533d8f2e  vmovaps [rsp+0x30], xmm4
000078e5533d8f34  vmovaps [rsp+0x40], xmm5
000078e5533d8f3a  vmovaps [rsp+0x50], xmm6
000078e5533d8f40  vmovaps [rsp+0x60], xmm7
000078e5533d8f46  vmovaps [rsp+0x70], xmm8
000078e5533d8f4c  vmovaps [rsp+0x80], xmm9
000078e5533d8f55  vmovaps [rsp+0x90], xmm10
000078e5533d8f5e  vmovaps [rsp+0xA0], xmm11
000078e5533d8f67  vmovaps [rsp+0xB0], xmm12
000078e5533d8f70  vmovaps [rsp+0xC0], xmm13
000078e5533d8f79  vmovaps [rsp+0xD0], xmm14
000078e5533d8f82  vmovaps [rsp+0xE0], xmm15
000078e5533d8f8b  sub rsp, 0x30
000078e5533d8f8f  movaps [rsp], xmm1
000078e5533d8f93  movaps [rsp+0x10], xmm15
000078e5533d8f99  movaps [rsp+0x20], xmm6
000078e5533d8f9e  lea rdi, [rsp]
000078e5533d8fa2  mov esi, 0x00
000078e5533d8fa7  mov rax, 0x5F83D5E17530
000078e5533d8fb1  call rax
000078e5533d8fb3  movaps xmm1, [rsp]
000078e5533d8fb7  add rsp, 0x30
000078e5533d8fbb  vmovaps xmm0, [rsp]
000078e5533d8fc0  vmovaps xmm2, [rsp+0x10]
000078e5533d8fc6  vmovaps xmm3, [rsp+0x20]
000078e5533d8fcc  vmovaps xmm4, [rsp+0x30]
000078e5533d8fd2  vmovaps xmm5, [rsp+0x40]
000078e5533d8fd8  vmovaps xmm6, [rsp+0x50]
000078e5533d8fde  vmovaps xmm7, [rsp+0x60]
000078e5533d8fe4  vmovaps xmm8, [rsp+0x70]
000078e5533d8fea  vmovaps xmm9, [rsp+0x80]
000078e5533d8ff3  vmovaps xmm10, [rsp+0x90]
000078e5533d8ffc  vmovaps xmm11, [rsp+0xA0]
000078e5533d9005  vmovaps xmm12, [rsp+0xB0]
000078e5533d900e  vmovaps xmm13, [rsp+0xC0]
000078e5533d9017  vmovaps xmm14, [rsp+0xD0]
000078e5533d9020  vmovaps xmm15, [rsp+0xE0]
000078e5533d9029  add rsp, 0xF0
000078e5533d9030  pop r11
000078e5533d9032  pop r10
000078e5533d9034  pop r9
000078e5533d9036  pop r8
000078e5533d9038  pop rsi
000078e5533d9039  pop rdi
000078e5533d903a  pop rdx
000078e5533d903b  pop rcx
000078e5533d903c  pop rax
000078e5533d903d  add rsp, 0x08
000078e5533d9041  jmp 0x000078E5533D61C2
000078e5533d9046  sub rsp, 0x08
000078e5533d904a  push rax
000078e5533d904b  push rcx
000078e5533d904c  push rdx
000078e5533d904d  push rdi
000078e5533d904e  push rsi
000078e5533d904f  push r8
000078e5533d9051  push r9
000078e5533d9053  push r10
000078e5533d9055  push r11
000078e5533d9057  sub rsp, 0xF0
000078e5533d905e  vmovaps [rsp], xmm0
000078e5533d9063  vmovaps [rsp+0x10], xmm1
000078e5533d9069  vmovaps [rsp+0x20], xmm2
000078e5533d906f  vmovaps [rsp+0x30], xmm3
000078e5533d9075  vmovaps [rsp+0x40], xmm4
000078e5533d907b  vmovaps [rsp+0x50], xmm5
000078e5533d9081  vmovaps [rsp+0x60], xmm6
000078e5533d9087  vmovaps [rsp+0x70], xmm7
000078e5533d908d  vmovaps [rsp+0x80], xmm8
000078e5533d9096  vmovaps [rsp+0x90], xmm9
000078e5533d909f  vmovaps [rsp+0xA0], xmm10
000078e5533d90a8  vmovaps [rsp+0xB0], xmm11
000078e5533d90b1  vmovaps [rsp+0xC0], xmm12
000078e5533d90ba  vmovaps [rsp+0xD0], xmm13
000078e5533d90c3  vmovaps [rsp+0xE0], xmm14
000078e5533d90cc  sub rsp, 0x30
000078e5533d90d0  movaps [rsp], xmm15
000078e5533d90d5  movaps [rsp+0x10], xmm5
000078e5533d90da  movaps [rsp+0x20], xmm3
000078e5533d90df  lea rdi, [rsp]
000078e5533d90e3  mov esi, 0x00
000078e5533d90e8  mov rax, 0x5F83D5E17530
000078e5533d90f2  call rax
000078e5533d90f4  movaps xmm15, [rsp]
000078e5533d90f9  add rsp, 0x30
000078e5533d90fd  vmovaps xmm0, [rsp]
000078e5533d9102  vmovaps xmm1, [rsp+0x10]
000078e5533d9108  vmovaps xmm2, [rsp+0x20]
000078e5533d910e  vmovaps xmm3, [rsp+0x30]
000078e5533d9114  vmovaps xmm4, [rsp+0x40]
000078e5533d911a  vmovaps xmm5, [rsp+0x50]
000078e5533d9120  vmovaps xmm6, [rsp+0x60]
000078e5533d9126  vmovaps xmm7, [rsp+0x70]
000078e5533d912c  vmovaps xmm8, [rsp+0x80]
000078e5533d9135  vmovaps xmm9, [rsp+0x90]
000078e5533d913e  vmovaps xmm10, [rsp+0xA0]
000078e5533d9147  vmovaps xmm11, [rsp+0xB0]
000078e5533d9150  vmovaps xmm12, [rsp+0xC0]
000078e5533d9159  vmovaps xmm13, [rsp+0xD0]
000078e5533d9162  vmovaps xmm14, [rsp+0xE0]
000078e5533d916b  add rsp, 0xF0
000078e5533d9172  pop r11
000078e5533d9174  pop r10
000078e5533d9176  pop r9
000078e5533d9178  pop r8
000078e5533d917a  pop rsi
000078e5533d917b  pop rdi
000078e5533d917c  pop rdx
000078e5533d917d  pop rcx
000078e5533d917e  pop rax
000078e5533d917f  add rsp, 0x08
000078e5533d9183  jmp 0x000078E5533D61DC
000078e5533d9188  sub rsp, 0x08
000078e5533d918c  push rax
000078e5533d918d  push rcx
000078e5533d918e  push rdx
000078e5533d918f  push rdi
000078e5533d9190  push rsi
000078e5533d9191  push r8
000078e5533d9193  push r9
000078e5533d9195  push r10
000078e5533d9197  push r11
000078e5533d9199  sub rsp, 0xF0
000078e5533d91a0  vmovaps [rsp], xmm0
000078e5533d91a5  vmovaps [rsp+0x10], xmm1
000078e5533d91ab  vmovaps [rsp+0x20], xmm2
000078e5533d91b1  vmovaps [rsp+0x30], xmm3
000078e5533d91b7  vmovaps [rsp+0x40], xmm4
000078e5533d91bd  vmovaps [rsp+0x50], xmm6
000078e5533d91c3  vmovaps [rsp+0x60], xmm7
000078e5533d91c9  vmovaps [rsp+0x70], xmm8
000078e5533d91cf  vmovaps [rsp+0x80], xmm9
000078e5533d91d8  vmovaps [rsp+0x90], xmm10
000078e5533d91e1  vmovaps [rsp+0xA0], xmm11
000078e5533d91ea  vmovaps [rsp+0xB0], xmm12
000078e5533d91f3  vmovaps [rsp+0xC0], xmm13
000078e5533d91fc  vmovaps [rsp+0xD0], xmm14
000078e5533d9205  vmovaps [rsp+0xE0], xmm15
000078e5533d920e  sub rsp, 0x30
000078e5533d9212  movaps [rsp], xmm5
000078e5533d9216  movaps [rsp+0x10], xmm8
000078e5533d921c  movaps [rsp+0x20], xmm6
000078e5533d9221  lea rdi, [rsp]
000078e5533d9225  mov esi, 0x00
000078e5533d922a  mov rax, 0x5F83D5E17530
000078e5533d9234  call rax
000078e5533d9236  movaps xmm5, [rsp]
000078e5533d923a  add rsp, 0x30
000078e5533d923e  vmovaps xmm0, [rsp]
000078e5533d9243  vmovaps xmm1, [rsp+0x10]
000078e5533d9249  vmovaps xmm2, [rsp+0x20]
000078e5533d924f  vmovaps xmm3, [rsp+0x30]
000078e5533d9255  vmovaps xmm4, [rsp+0x40]
000078e5533d925b  vmovaps xmm6, [rsp+0x50]
000078e5533d9261  vmovaps xmm7, [rsp+0x60]
000078e5533d9267  vmovaps xmm8, [rsp+0x70]
000078e5533d926d  vmovaps xmm9, [rsp+0x80]
000078e5533d9276  vmovaps xmm10, [rsp+0x90]
000078e5533d927f  vmovaps xmm11, [rsp+0xA0]
000078e5533d9288  vmovaps xmm12, [rsp+0xB0]
000078e5533d9291  vmovaps xmm13, [rsp+0xC0]
000078e5533d929a  vmovaps xmm14, [rsp+0xD0]
000078e5533d92a3  vmovaps xmm15, [rsp+0xE0]
000078e5533d92ac  add rsp, 0xF0
000078e5533d92b3  pop r11
000078e5533d92b5  pop r10
000078e5533d92b7  pop r9
000078e5533d92b9  pop r8
000078e5533d92bb  pop rsi
000078e5533d92bc  pop rdi
000078e5533d92bd  pop rdx
000078e5533d92be  pop rcx
000078e5533d92bf  pop rax
000078e5533d92c0  add rsp, 0x08
000078e5533d92c4  jmp 0x000078E5533D6200
000078e5533d92c9  sub rsp, 0x08
000078e5533d92cd  push rax
000078e5533d92ce  push rcx
000078e5533d92cf  push rdx
000078e5533d92d0  push rdi
000078e5533d92d1  push rsi
000078e5533d92d2  push r8
000078e5533d92d4  push r9
000078e5533d92d6  push r10
000078e5533d92d8  push r11
000078e5533d92da  sub rsp, 0xF0
000078e5533d92e1  vmovaps [rsp], xmm0
000078e5533d92e6  vmovaps [rsp+0x10], xmm1
000078e5533d92ec  vmovaps [rsp+0x20], xmm2
000078e5533d92f2  vmovaps [rsp+0x30], xmm3
000078e5533d92f8  vmovaps [rsp+0x40], xmm4
000078e5533d92fe  vmovaps [rsp+0x50], xmm5
000078e5533d9304  vmovaps [rsp+0x60], xmm7
000078e5533d930a  vmovaps [rsp+0x70], xmm8
000078e5533d9310  vmovaps [rsp+0x80], xmm9
000078e5533d9319  vmovaps [rsp+0x90], xmm10
000078e5533d9322  vmovaps [rsp+0xA0], xmm11
000078e5533d932b  vmovaps [rsp+0xB0], xmm12
000078e5533d9334  vmovaps [rsp+0xC0], xmm13
000078e5533d933d  vmovaps [rsp+0xD0], xmm14
000078e5533d9346  vmovaps [rsp+0xE0], xmm15
000078e5533d934f  sub rsp, 0x30
000078e5533d9353  movaps [rsp], xmm6
000078e5533d9357  movaps [rsp+0x10], xmm10
000078e5533d935d  movaps [rsp+0x20], xmm8
000078e5533d9363  lea rdi, [rsp]
000078e5533d9367  mov esi, 0x00
000078e5533d936c  mov rax, 0x5F83D5E17530
000078e5533d9376  call rax
000078e5533d9378  movaps xmm6, [rsp]
000078e5533d937c  add rsp, 0x30
000078e5533d9380  vmovaps xmm0, [rsp]
000078e5533d9385  vmovaps xmm1, [rsp+0x10]
000078e5533d938b  vmovaps xmm2, [rsp+0x20]
000078e5533d9391  vmovaps xmm3, [rsp+0x30]
000078e5533d9397  vmovaps xmm4, [rsp+0x40]
000078e5533d939d  vmovaps xmm5, [rsp+0x50]
000078e5533d93a3  vmovaps xmm7, [rsp+0x60]
000078e5533d93a9  vmovaps xmm8, [rsp+0x70]
000078e5533d93af  vmovaps xmm9, [rsp+0x80]
000078e5533d93b8  vmovaps xmm10, [rsp+0x90]
000078e5533d93c1  vmovaps xmm11, [rsp+0xA0]
000078e5533d93ca  vmovaps xmm12, [rsp+0xB0]
000078e5533d93d3  vmovaps xmm13, [rsp+0xC0]
000078e5533d93dc  vmovaps xmm14, [rsp+0xD0]
000078e5533d93e5  vmovaps xmm15, [rsp+0xE0]
000078e5533d93ee  add rsp, 0xF0
000078e5533d93f5  pop r11
000078e5533d93f7  pop r10
000078e5533d93f9  pop r9
000078e5533d93fb  pop r8
000078e5533d93fd  pop rsi
000078e5533d93fe  pop rdi
000078e5533d93ff  pop rdx
000078e5533d9400  pop rcx
000078e5533d9401  pop rax
000078e5533d9402  add rsp, 0x08
000078e5533d9406  jmp 0x000078E5533D6225
000078e5533d940b  sub rsp, 0x08
000078e5533d940f  push rax
000078e5533d9410  push rcx
000078e5533d9411  push rdx
000078e5533d9412  push rdi
000078e5533d9413  push rsi
000078e5533d9414  push r8
000078e5533d9416  push r9
000078e5533d9418  push r10
000078e5533d941a  push r11
000078e5533d941c  sub rsp, 0xF0
000078e5533d9423  vmovaps [rsp], xmm0
000078e5533d9428  vmovaps [rsp+0x10], xmm1
000078e5533d942e  vmovaps [rsp+0x20], xmm2
000078e5533d9434  vmovaps [rsp+0x30], xmm3
000078e5533d943a  vmovaps [rsp+0x40], xmm4
000078e5533d9440  vmovaps [rsp+0x50], xmm5
000078e5533d9446  vmovaps [rsp+0x60], xmm6
000078e5533d944c  vmovaps [rsp+0x70], xmm7
000078e5533d9452  vmovaps [rsp+0x80], xmm8
000078e5533d945b  vmovaps [rsp+0x90], xmm9
000078e5533d9464  vmovaps [rsp+0xA0], xmm11
000078e5533d946d  vmovaps [rsp+0xB0], xmm12
000078e5533d9476  vmovaps [rsp+0xC0], xmm13
000078e5533d947f  vmovaps [rsp+0xD0], xmm14
000078e5533d9488  vmovaps [rsp+0xE0], xmm15
000078e5533d9491  sub rsp, 0x30
000078e5533d9495  movaps [rsp], xmm10
000078e5533d949a  movaps [rsp+0x10], xmm8
000078e5533d94a0  movaps [rsp+0x20], xmm14
000078e5533d94a6  lea rdi, [rsp]
000078e5533d94aa  mov esi, 0x00
000078e5533d94af  mov rax, 0x5F83D5E17530
000078e5533d94b9  call rax
000078e5533d94bb  movaps xmm10, [rsp]
000078e5533d94c0  add rsp, 0x30
000078e5533d94c4  vmovaps xmm0, [rsp]
000078e5533d94c9  vmovaps xmm1, [rsp+0x10]
000078e5533d94cf  vmovaps xmm2, [rsp+0x20]
000078e5533d94d5  vmovaps xmm3, [rsp+0x30]
000078e5533d94db  vmovaps xmm4, [rsp+0x40]
000078e5533d94e1  vmovaps xmm5, [rsp+0x50]
000078e5533d94e7  vmovaps xmm6, [rsp+0x60]
000078e5533d94ed  vmovaps xmm7, [rsp+0x70]
000078e5533d94f3  vmovaps xmm8, [rsp+0x80]
000078e5533d94fc  vmovaps xmm9, [rsp+0x90]
000078e5533d9505  vmovaps xmm11, [rsp+0xA0]
000078e5533d950e  vmovaps xmm12, [rsp+0xB0]
000078e5533d9517  vmovaps xmm13, [rsp+0xC0]
000078e5533d9520  vmovaps xmm14, [rsp+0xD0]
000078e5533d9529  vmovaps xmm15, [rsp+0xE0]
000078e5533d9532  add rsp, 0xF0
000078e5533d9539  pop r11
000078e5533d953b  pop r10
000078e5533d953d  pop r9
000078e5533d953f  pop r8
000078e5533d9541  pop rsi
000078e5533d9542  pop rdi
000078e5533d9543  pop rdx
000078e5533d9544  pop rcx
000078e5533d9545  pop rax
000078e5533d9546  add rsp, 0x08
000078e5533d954a  jmp 0x000078E5533D6245
000078e5533d954f  sub rsp, 0x08
000078e5533d9553  push rax
000078e5533d9554  push rcx
000078e5533d9555  push rdx
000078e5533d9556  push rdi
000078e5533d9557  push rsi
000078e5533d9558  push r8
000078e5533d955a  push r9
000078e5533d955c  push r10
000078e5533d955e  push r11
000078e5533d9560  sub rsp, 0xF0
000078e5533d9567  vmovaps [rsp], xmm0
000078e5533d956c  vmovaps [rsp+0x10], xmm1
000078e5533d9572  vmovaps [rsp+0x20], xmm2
000078e5533d9578  vmovaps [rsp+0x30], xmm3
000078e5533d957e  vmovaps [rsp+0x40], xmm4
000078e5533d9584  vmovaps [rsp+0x50], xmm5
000078e5533d958a  vmovaps [rsp+0x60], xmm6
000078e5533d9590  vmovaps [rsp+0x70], xmm7
000078e5533d9596  vmovaps [rsp+0x80], xmm8
000078e5533d959f  vmovaps [rsp+0x90], xmm9
000078e5533d95a8  vmovaps [rsp+0xA0], xmm10
000078e5533d95b1  vmovaps [rsp+0xB0], xmm11
000078e5533d95ba  vmovaps [rsp+0xC0], xmm12
000078e5533d95c3  vmovaps [rsp+0xD0], xmm13
000078e5533d95cc  vmovaps [rsp+0xE0], xmm15
000078e5533d95d5  sub rsp, 0x30
000078e5533d95d9  movaps [rsp], xmm14
000078e5533d95de  movaps [rsp+0x10], xmm8
000078e5533d95e4  movaps [rsp+0x20], xmm4
000078e5533d95e9  lea rdi, [rsp]
000078e5533d95ed  mov esi, 0x00
000078e5533d95f2  mov rax, 0x5F83D5E17530
000078e5533d95fc  call rax
000078e5533d95fe  movaps xmm14, [rsp]
000078e5533d9603  add rsp, 0x30
000078e5533d9607  vmovaps xmm0, [rsp]
000078e5533d960c  vmovaps xmm1, [rsp+0x10]
000078e5533d9612  vmovaps xmm2, [rsp+0x20]
000078e5533d9618  vmovaps xmm3, [rsp+0x30]
000078e5533d961e  vmovaps xmm4, [rsp+0x40]
000078e5533d9624  vmovaps xmm5, [rsp+0x50]
000078e5533d962a  vmovaps xmm6, [rsp+0x60]
000078e5533d9630  vmovaps xmm7, [rsp+0x70]
000078e5533d9636  vmovaps xmm8, [rsp+0x80]
000078e5533d963f  vmovaps xmm9, [rsp+0x90]
000078e5533d9648  vmovaps xmm10, [rsp+0xA0]
000078e5533d9651  vmovaps xmm11, [rsp+0xB0]
000078e5533d965a  vmovaps xmm12, [rsp+0xC0]
000078e5533d9663  vmovaps xmm13, [rsp+0xD0]
000078e5533d966c  vmovaps xmm15, [rsp+0xE0]
000078e5533d9675  add rsp, 0xF0
000078e5533d967c  pop r11
000078e5533d967e  pop r10
000078e5533d9680  pop r9
000078e5533d9682  pop r8
000078e5533d9684  pop rsi
000078e5533d9685  pop rdi
000078e5533d9686  pop rdx
000078e5533d9687  pop rcx
000078e5533d9688  pop rax
000078e5533d9689  add rsp, 0x08
000078e5533d968d  jmp 0x000078E5533D6265
000078e5533d9692  sub rsp, 0x08
000078e5533d9696  push rax
000078e5533d9697  push rcx
000078e5533d9698  push rdx
000078e5533d9699  push rdi
000078e5533d969a  push rsi
000078e5533d969b  push r8
000078e5533d969d  push r9
000078e5533d969f  push r10
000078e5533d96a1  push r11
000078e5533d96a3  sub rsp, 0xF0
000078e5533d96aa  vmovaps [rsp], xmm0
000078e5533d96af  vmovaps [rsp+0x10], xmm1
000078e5533d96b5  vmovaps [rsp+0x20], xmm2
000078e5533d96bb  vmovaps [rsp+0x30], xmm3
000078e5533d96c1  vmovaps [rsp+0x40], xmm5
000078e5533d96c7  vmovaps [rsp+0x50], xmm6
000078e5533d96cd  vmovaps [rsp+0x60], xmm7
000078e5533d96d3  vmovaps [rsp+0x70], xmm8
000078e5533d96d9  vmovaps [rsp+0x80], xmm9
000078e5533d96e2  vmovaps [rsp+0x90], xmm10
000078e5533d96eb  vmovaps [rsp+0xA0], xmm11
000078e5533d96f4  vmovaps [rsp+0xB0], xmm12
000078e5533d96fd  vmovaps [rsp+0xC0], xmm13
000078e5533d9706  vmovaps [rsp+0xD0], xmm14
000078e5533d970f  vmovaps [rsp+0xE0], xmm15
000078e5533d9718  sub rsp, 0x30
000078e5533d971c  movaps [rsp], xmm4
000078e5533d9720  movaps [rsp+0x10], xmm13
000078e5533d9726  movaps [rsp+0x20], xmm8
000078e5533d972c  lea rdi, [rsp]
000078e5533d9730  mov esi, 0x00
000078e5533d9735  mov rax, 0x5F83D5E17530
000078e5533d973f  call rax
000078e5533d9741  movaps xmm4, [rsp]
000078e5533d9745  add rsp, 0x30
000078e5533d9749  vmovaps xmm0, [rsp]
000078e5533d974e  vmovaps xmm1, [rsp+0x10]
000078e5533d9754  vmovaps xmm2, [rsp+0x20]
000078e5533d975a  vmovaps xmm3, [rsp+0x30]
000078e5533d9760  vmovaps xmm5, [rsp+0x40]
000078e5533d9766  vmovaps xmm6, [rsp+0x50]
000078e5533d976c  vmovaps xmm7, [rsp+0x60]
000078e5533d9772  vmovaps xmm8, [rsp+0x70]
000078e5533d9778  vmovaps xmm9, [rsp+0x80]
000078e5533d9781  vmovaps xmm10, [rsp+0x90]
000078e5533d978a  vmovaps xmm11, [rsp+0xA0]
000078e5533d9793  vmovaps xmm12, [rsp+0xB0]
000078e5533d979c  vmovaps xmm13, [rsp+0xC0]
000078e5533d97a5  vmovaps xmm14, [rsp+0xD0]
000078e5533d97ae  vmovaps xmm15, [rsp+0xE0]
000078e5533d97b7  add rsp, 0xF0
000078e5533d97be  pop r11
000078e5533d97c0  pop r10
000078e5533d97c2  pop r9
000078e5533d97c4  pop r8
000078e5533d97c6  pop rsi
000078e5533d97c7  pop rdi
000078e5533d97c8  pop rdx
000078e5533d97c9  pop rcx
000078e5533d97ca  pop rax
000078e5533d97cb  add rsp, 0x08
000078e5533d97cf  jmp 0x000078E5533D628A
000078e5533d97d4  sub rsp, 0x08
000078e5533d97d8  push rax
000078e5533d97d9  push rcx
000078e5533d97da  push rdx
000078e5533d97db  push rdi
000078e5533d97dc  push rsi
000078e5533d97dd  push r8
000078e5533d97df  push r9
000078e5533d97e1  push r10
000078e5533d97e3  push r11
000078e5533d97e5  sub rsp, 0xF0
000078e5533d97ec  vmovaps [rsp], xmm0
000078e5533d97f1  vmovaps [rsp+0x10], xmm1
000078e5533d97f7  vmovaps [rsp+0x20], xmm2
000078e5533d97fd  vmovaps [rsp+0x30], xmm3
000078e5533d9803  vmovaps [rsp+0x40], xmm4
000078e5533d9809  vmovaps [rsp+0x50], xmm5
000078e5533d980f  vmovaps [rsp+0x60], xmm6
000078e5533d9815  vmovaps [rsp+0x70], xmm7
000078e5533d981b  vmovaps [rsp+0x80], xmm8
000078e5533d9824  vmovaps [rsp+0x90], xmm9
000078e5533d982d  vmovaps [rsp+0xA0], xmm10
000078e5533d9836  vmovaps [rsp+0xB0], xmm11
000078e5533d983f  vmovaps [rsp+0xC0], xmm12
000078e5533d9848  vmovaps [rsp+0xD0], xmm14
000078e5533d9851  vmovaps [rsp+0xE0], xmm15
000078e5533d985a  sub rsp, 0x30
000078e5533d985e  movaps [rsp], xmm13
000078e5533d9863  movaps [rsp+0x10], xmm15
000078e5533d9869  movaps [rsp+0x20], xmm9
000078e5533d986f  lea rdi, [rsp]
000078e5533d9873  mov esi, 0x00
000078e5533d9878  mov rax, 0x5F83D5E17530
000078e5533d9882  call rax
000078e5533d9884  movaps xmm13, [rsp]
000078e5533d9889  add rsp, 0x30
000078e5533d988d  vmovaps xmm0, [rsp]
000078e5533d9892  vmovaps xmm1, [rsp+0x10]
000078e5533d9898  vmovaps xmm2, [rsp+0x20]
000078e5533d989e  vmovaps xmm3, [rsp+0x30]
000078e5533d98a4  vmovaps xmm4, [rsp+0x40]
000078e5533d98aa  vmovaps xmm5, [rsp+0x50]
000078e5533d98b0  vmovaps xmm6, [rsp+0x60]
000078e5533d98b6  vmovaps xmm7, [rsp+0x70]
000078e5533d98bc  vmovaps xmm8, [rsp+0x80]
000078e5533d98c5  vmovaps xmm9, [rsp+0x90]
000078e5533d98ce  vmovaps xmm10, [rsp+0xA0]
000078e5533d98d7  vmovaps xmm11, [rsp+0xB0]
000078e5533d98e0  vmovaps xmm12, [rsp+0xC0]
000078e5533d98e9  vmovaps xmm14, [rsp+0xD0]
000078e5533d98f2  vmovaps xmm15, [rsp+0xE0]
000078e5533d98fb  add rsp, 0xF0
000078e5533d9902  pop r11
000078e5533d9904  pop r10
000078e5533d9906  pop r9
000078e5533d9908  pop r8
000078e5533d990a  pop rsi
000078e5533d990b  pop rdi
000078e5533d990c  pop rdx
000078e5533d990d  pop rcx
000078e5533d990e  pop rax
000078e5533d990f  add rsp, 0x08
000078e5533d9913  jmp 0x000078E5533D62A5
000078e5533d9918  sub rsp, 0x08
000078e5533d991c  push rax
000078e5533d991d  push rcx
000078e5533d991e  push rdx
000078e5533d991f  push rdi
000078e5533d9920  push rsi
000078e5533d9921  push r8
000078e5533d9923  push r9
000078e5533d9925  push r10
000078e5533d9927  push r11
000078e5533d9929  sub rsp, 0xF0
000078e5533d9930  vmovaps [rsp], xmm0
000078e5533d9935  vmovaps [rsp+0x10], xmm1
000078e5533d993b  vmovaps [rsp+0x20], xmm2
000078e5533d9941  vmovaps [rsp+0x30], xmm3
000078e5533d9947  vmovaps [rsp+0x40], xmm4
000078e5533d994d  vmovaps [rsp+0x50], xmm5
000078e5533d9953  vmovaps [rsp+0x60], xmm6
000078e5533d9959  vmovaps [rsp+0x70], xmm7
000078e5533d995f  vmovaps [rsp+0x80], xmm8
000078e5533d9968  vmovaps [rsp+0x90], xmm9
000078e5533d9971  vmovaps [rsp+0xA0], xmm10
000078e5533d997a  vmovaps [rsp+0xB0], xmm11
000078e5533d9983  vmovaps [rsp+0xC0], xmm12
000078e5533d998c  vmovaps [rsp+0xD0], xmm13
000078e5533d9995  vmovaps [rsp+0xE0], xmm14
000078e5533d999e  sub rsp, 0x30
000078e5533d99a2  movaps [rsp], xmm15
000078e5533d99a7  movaps [rsp+0x10], xmm1
000078e5533d99ac  movaps [rsp+0x20], xmm5
000078e5533d99b1  lea rdi, [rsp]
000078e5533d99b5  mov esi, 0x00
000078e5533d99ba  mov rax, 0x5F83D5E17530
000078e5533d99c4  call rax
000078e5533d99c6  movaps xmm15, [rsp]
000078e5533d99cb  add rsp, 0x30
000078e5533d99cf  vmovaps xmm0, [rsp]
000078e5533d99d4  vmovaps xmm1, [rsp+0x10]
000078e5533d99da  vmovaps xmm2, [rsp+0x20]
000078e5533d99e0  vmovaps xmm3, [rsp+0x30]
000078e5533d99e6  vmovaps xmm4, [rsp+0x40]
000078e5533d99ec  vmovaps xmm5, [rsp+0x50]
000078e5533d99f2  vmovaps xmm6, [rsp+0x60]
000078e5533d99f8  vmovaps xmm7, [rsp+0x70]
000078e5533d99fe  vmovaps xmm8, [rsp+0x80]
000078e5533d9a07  vmovaps xmm9, [rsp+0x90]
000078e5533d9a10  vmovaps xmm10, [rsp+0xA0]
000078e5533d9a19  vmovaps xmm11, [rsp+0xB0]
000078e5533d9a22  vmovaps xmm12, [rsp+0xC0]
000078e5533d9a2b  vmovaps xmm13, [rsp+0xD0]
000078e5533d9a34  vmovaps xmm14, [rsp+0xE0]
000078e5533d9a3d  add rsp, 0xF0
000078e5533d9a44  pop r11
000078e5533d9a46  pop r10
000078e5533d9a48  pop r9
000078e5533d9a4a  pop r8
000078e5533d9a4c  pop rsi
000078e5533d9a4d  pop rdi
000078e5533d9a4e  pop rdx
000078e5533d9a4f  pop rcx
000078e5533d9a50  pop rax
000078e5533d9a51  add rsp, 0x08
000078e5533d9a55  jmp 0x000078E5533D62C0
000078e5533d9a5a  call 0x000078E5532D64F0
000078e5533d9a5f  jmp 0x000078E5533D631B
000078e5533d9a64  sub rsp, 0x08
000078e5533d9a68  push rax
000078e5533d9a69  push rcx
000078e5533d9a6a  push rdx
000078e5533d9a6b  push rdi
000078e5533d9a6c  push rsi
000078e5533d9a6d  push r8
000078e5533d9a6f  push r9
000078e5533d9a71  push r10
000078e5533d9a73  push r11
000078e5533d9a75  sub rsp, 0xF0
000078e5533d9a7c  vmovaps [rsp], xmm0
000078e5533d9a81  vmovaps [rsp+0x10], xmm1
000078e5533d9a87  vmovaps [rsp+0x20], xmm2
000078e5533d9a8d  vmovaps [rsp+0x30], xmm3
000078e5533d9a93  vmovaps [rsp+0x40], xmm4
000078e5533d9a99  vmovaps [rsp+0x50], xmm5
000078e5533d9a9f  vmovaps [rsp+0x60], xmm6
000078e5533d9aa5  vmovaps [rsp+0x70], xmm7
000078e5533d9aab  vmovaps [rsp+0x80], xmm8
000078e5533d9ab4  vmovaps [rsp+0x90], xmm10
000078e5533d9abd  vmovaps [rsp+0xA0], xmm11
000078e5533d9ac6  vmovaps [rsp+0xB0], xmm12
000078e5533d9acf  vmovaps [rsp+0xC0], xmm13
000078e5533d9ad8  vmovaps [rsp+0xD0], xmm14
000078e5533d9ae1  vmovaps [rsp+0xE0], xmm15
000078e5533d9aea  sub rsp, 0x30
000078e5533d9aee  movaps [rsp], xmm9
000078e5533d9af3  movaps [rsp+0x10], xmm8
000078e5533d9af9  movaps [rsp+0x20], xmm11
000078e5533d9aff  lea rdi, [rsp]
000078e5533d9b03  mov esi, 0x00
000078e5533d9b08  mov rax, 0x5F83D5E17530
000078e5533d9b12  call rax
000078e5533d9b14  movaps xmm9, [rsp]
000078e5533d9b19  add rsp, 0x30
000078e5533d9b1d  vmovaps xmm0, [rsp]
000078e5533d9b22  vmovaps xmm1, [rsp+0x10]
000078e5533d9b28  vmovaps xmm2, [rsp+0x20]
000078e5533d9b2e  vmovaps xmm3, [rsp+0x30]
000078e5533d9b34  vmovaps xmm4, [rsp+0x40]
000078e5533d9b3a  vmovaps xmm5, [rsp+0x50]
000078e5533d9b40  vmovaps xmm6, [rsp+0x60]
000078e5533d9b46  vmovaps xmm7, [rsp+0x70]
000078e5533d9b4c  vmovaps xmm8, [rsp+0x80]
000078e5533d9b55  vmovaps xmm10, [rsp+0x90]
000078e5533d9b5e  vmovaps xmm11, [rsp+0xA0]
000078e5533d9b67  vmovaps xmm12, [rsp+0xB0]
000078e5533d9b70  vmovaps xmm13, [rsp+0xC0]
000078e5533d9b79  vmovaps xmm14, [rsp+0xD0]
000078e5533d9b82  vmovaps xmm15, [rsp+0xE0]
000078e5533d9b8b  add rsp, 0xF0
000078e5533d9b92  pop r11
000078e5533d9b94  pop r10
000078e5533d9b96  pop r9
000078e5533d9b98  pop r8
000078e5533d9b9a  pop rsi
000078e5533d9b9b  pop rdi
000078e5533d9b9c  pop rdx
000078e5533d9b9d  pop rcx
000078e5533d9b9e  pop rax
000078e5533d9b9f  add rsp, 0x08
000078e5533d9ba3  jmp 0x000078E5533D6352
000078e5533d9ba8  sub rsp, 0x08
000078e5533d9bac  push rax
000078e5533d9bad  push rcx
000078e5533d9bae  push rdx
000078e5533d9baf  push rdi
000078e5533d9bb0  push rsi
000078e5533d9bb1  push r8
000078e5533d9bb3  push r9
000078e5533d9bb5  push r10
000078e5533d9bb7  push r11
000078e5533d9bb9  sub rsp, 0xF0
000078e5533d9bc0  vmovaps [rsp], xmm0
000078e5533d9bc5  vmovaps [rsp+0x10], xmm1
000078e5533d9bcb  vmovaps [rsp+0x20], xmm2
000078e5533d9bd1  vmovaps [rsp+0x30], xmm3
000078e5533d9bd7  vmovaps [rsp+0x40], xmm4
000078e5533d9bdd  vmovaps [rsp+0x50], xmm5
000078e5533d9be3  vmovaps [rsp+0x60], xmm6
000078e5533d9be9  vmovaps [rsp+0x70], xmm7
000078e5533d9bef  vmovaps [rsp+0x80], xmm8
000078e5533d9bf8  vmovaps [rsp+0x90], xmm9
000078e5533d9c01  vmovaps [rsp+0xA0], xmm10
000078e5533d9c0a  vmovaps [rsp+0xB0], xmm12
000078e5533d9c13  vmovaps [rsp+0xC0], xmm13
000078e5533d9c1c  vmovaps [rsp+0xD0], xmm14
000078e5533d9c25  vmovaps [rsp+0xE0], xmm15
000078e5533d9c2e  sub rsp, 0x30
000078e5533d9c32  movaps [rsp], xmm11
000078e5533d9c37  movaps [rsp+0x10], xmm10
000078e5533d9c3d  movaps [rsp+0x20], xmm6
000078e5533d9c42  lea rdi, [rsp]
000078e5533d9c46  mov esi, 0x00
000078e5533d9c4b  mov rax, 0x5F83D5E17530
000078e5533d9c55  call rax
000078e5533d9c57  movaps xmm11, [rsp]
000078e5533d9c5c  add rsp, 0x30
000078e5533d9c60  vmovaps xmm0, [rsp]
000078e5533d9c65  vmovaps xmm1, [rsp+0x10]
000078e5533d9c6b  vmovaps xmm2, [rsp+0x20]
000078e5533d9c71  vmovaps xmm3, [rsp+0x30]
000078e5533d9c77  vmovaps xmm4, [rsp+0x40]
000078e5533d9c7d  vmovaps xmm5, [rsp+0x50]
000078e5533d9c83  vmovaps xmm6, [rsp+0x60]
000078e5533d9c89  vmovaps xmm7, [rsp+0x70]
000078e5533d9c8f  vmovaps xmm8, [rsp+0x80]
000078e5533d9c98  vmovaps xmm9, [rsp+0x90]
000078e5533d9ca1  vmovaps xmm10, [rsp+0xA0]
000078e5533d9caa  vmovaps xmm12, [rsp+0xB0]
000078e5533d9cb3  vmovaps xmm13, [rsp+0xC0]
000078e5533d9cbc  vmovaps xmm14, [rsp+0xD0]
000078e5533d9cc5  vmovaps xmm15, [rsp+0xE0]
000078e5533d9cce  add rsp, 0xF0
000078e5533d9cd5  pop r11
000078e5533d9cd7  pop r10
000078e5533d9cd9  pop r9
000078e5533d9cdb  pop r8
000078e5533d9cdd  pop rsi
000078e5533d9cde  pop rdi
000078e5533d9cdf  pop rdx
000078e5533d9ce0  pop rcx
000078e5533d9ce1  pop rax
000078e5533d9ce2  add rsp, 0x08
000078e5533d9ce6  jmp 0x000078E5533D636D
000078e5533d9ceb  sub rsp, 0x08
000078e5533d9cef  push rax
000078e5533d9cf0  push rcx
000078e5533d9cf1  push rdx
000078e5533d9cf2  push rdi
000078e5533d9cf3  push rsi
000078e5533d9cf4  push r8
000078e5533d9cf6  push r9
000078e5533d9cf8  push r10
000078e5533d9cfa  push r11
000078e5533d9cfc  sub rsp, 0xF0
000078e5533d9d03  vmovaps [rsp], xmm0
000078e5533d9d08  vmovaps [rsp+0x10], xmm1
000078e5533d9d0e  vmovaps [rsp+0x20], xmm2
000078e5533d9d14  vmovaps [rsp+0x30], xmm3
000078e5533d9d1a  vmovaps [rsp+0x40], xmm4
000078e5533d9d20  vmovaps [rsp+0x50], xmm5
000078e5533d9d26  vmovaps [rsp+0x60], xmm6
000078e5533d9d2c  vmovaps [rsp+0x70], xmm7
000078e5533d9d32  vmovaps [rsp+0x80], xmm8
000078e5533d9d3b  vmovaps [rsp+0x90], xmm9
000078e5533d9d44  vmovaps [rsp+0xA0], xmm11
000078e5533d9d4d  vmovaps [rsp+0xB0], xmm12
000078e5533d9d56  vmovaps [rsp+0xC0], xmm13
000078e5533d9d5f  vmovaps [rsp+0xD0], xmm14
000078e5533d9d68  vmovaps [rsp+0xE0], xmm15
000078e5533d9d71  sub rsp, 0x30
000078e5533d9d75  movaps [rsp], xmm10
000078e5533d9d7a  movaps [rsp+0x10], xmm14
000078e5533d9d80  movaps [rsp+0x20], xmm4
000078e5533d9d85  lea rdi, [rsp]
000078e5533d9d89  mov esi, 0x00
000078e5533d9d8e  mov rax, 0x5F83D5E17530
000078e5533d9d98  call rax
000078e5533d9d9a  movaps xmm10, [rsp]
000078e5533d9d9f  add rsp, 0x30
000078e5533d9da3  vmovaps xmm0, [rsp]
000078e5533d9da8  vmovaps xmm1, [rsp+0x10]
000078e5533d9dae  vmovaps xmm2, [rsp+0x20]
000078e5533d9db4  vmovaps xmm3, [rsp+0x30]
000078e5533d9dba  vmovaps xmm4, [rsp+0x40]
000078e5533d9dc0  vmovaps xmm5, [rsp+0x50]
000078e5533d9dc6  vmovaps xmm6, [rsp+0x60]
000078e5533d9dcc  vmovaps xmm7, [rsp+0x70]
000078e5533d9dd2  vmovaps xmm8, [rsp+0x80]
000078e5533d9ddb  vmovaps xmm9, [rsp+0x90]
000078e5533d9de4  vmovaps xmm11, [rsp+0xA0]
000078e5533d9ded  vmovaps xmm12, [rsp+0xB0]
000078e5533d9df6  vmovaps xmm13, [rsp+0xC0]
000078e5533d9dff  vmovaps xmm14, [rsp+0xD0]
000078e5533d9e08  vmovaps xmm15, [rsp+0xE0]
000078e5533d9e11  add rsp, 0xF0
000078e5533d9e18  pop r11
000078e5533d9e1a  pop r10
000078e5533d9e1c  pop r9
000078e5533d9e1e  pop r8
000078e5533d9e20  pop rsi
000078e5533d9e21  pop rdi
000078e5533d9e22  pop rdx
000078e5533d9e23  pop rcx
000078e5533d9e24  pop rax
000078e5533d9e25  add rsp, 0x08
000078e5533d9e29  jmp 0x000078E5533D6388
000078e5533d9e2e  sub rsp, 0x08
000078e5533d9e32  push rax
000078e5533d9e33  push rcx
000078e5533d9e34  push rdx
000078e5533d9e35  push rdi
000078e5533d9e36  push rsi
000078e5533d9e37  push r8
000078e5533d9e39  push r9
000078e5533d9e3b  push r10
000078e5533d9e3d  push r11
000078e5533d9e3f  sub rsp, 0xF0
000078e5533d9e46  vmovaps [rsp], xmm0
000078e5533d9e4b  vmovaps [rsp+0x10], xmm1
000078e5533d9e51  vmovaps [rsp+0x20], xmm2
000078e5533d9e57  vmovaps [rsp+0x30], xmm3
000078e5533d9e5d  vmovaps [rsp+0x40], xmm4
000078e5533d9e63  vmovaps [rsp+0x50], xmm5
000078e5533d9e69  vmovaps [rsp+0x60], xmm6
000078e5533d9e6f  vmovaps [rsp+0x70], xmm7
000078e5533d9e75  vmovaps [rsp+0x80], xmm9
000078e5533d9e7e  vmovaps [rsp+0x90], xmm10
000078e5533d9e87  vmovaps [rsp+0xA0], xmm11
000078e5533d9e90  vmovaps [rsp+0xB0], xmm12
000078e5533d9e99  vmovaps [rsp+0xC0], xmm13
000078e5533d9ea2  vmovaps [rsp+0xD0], xmm14
000078e5533d9eab  vmovaps [rsp+0xE0], xmm15
000078e5533d9eb4  sub rsp, 0x30
000078e5533d9eb8  movaps [rsp], xmm8
000078e5533d9ebd  movaps [rsp+0x10], xmm1
000078e5533d9ec2  movaps [rsp+0x20], xmm14
000078e5533d9ec8  lea rdi, [rsp]
000078e5533d9ecc  mov esi, 0x00
000078e5533d9ed1  mov rax, 0x5F83D5E17530
000078e5533d9edb  call rax
000078e5533d9edd  movaps xmm8, [rsp]
000078e5533d9ee2  add rsp, 0x30
000078e5533d9ee6  vmovaps xmm0, [rsp]
000078e5533d9eeb  vmovaps xmm1, [rsp+0x10]
000078e5533d9ef1  vmovaps xmm2, [rsp+0x20]
000078e5533d9ef7  vmovaps xmm3, [rsp+0x30]
000078e5533d9efd  vmovaps xmm4, [rsp+0x40]
000078e5533d9f03  vmovaps xmm5, [rsp+0x50]
000078e5533d9f09  vmovaps xmm6, [rsp+0x60]
000078e5533d9f0f  vmovaps xmm7, [rsp+0x70]
000078e5533d9f15  vmovaps xmm9, [rsp+0x80]
000078e5533d9f1e  vmovaps xmm10, [rsp+0x90]
000078e5533d9f27  vmovaps xmm11, [rsp+0xA0]
000078e5533d9f30  vmovaps xmm12, [rsp+0xB0]
000078e5533d9f39  vmovaps xmm13, [rsp+0xC0]
000078e5533d9f42  vmovaps xmm14, [rsp+0xD0]
000078e5533d9f4b  vmovaps xmm15, [rsp+0xE0]
000078e5533d9f54  add rsp, 0xF0
000078e5533d9f5b  pop r11
000078e5533d9f5d  pop r10
000078e5533d9f5f  pop r9
000078e5533d9f61  pop r8
000078e5533d9f63  pop rsi
000078e5533d9f64  pop rdi
000078e5533d9f65  pop rdx
000078e5533d9f66  pop rcx
000078e5533d9f67  pop rax
000078e5533d9f68  add rsp, 0x08
000078e5533d9f6c  jmp 0x000078E5533D63AE
000078e5533d9f71  sub rsp, 0x08
000078e5533d9f75  push rax
000078e5533d9f76  push rcx
000078e5533d9f77  push rdx
000078e5533d9f78  push rdi
000078e5533d9f79  push rsi
000078e5533d9f7a  push r8
000078e5533d9f7c  push r9
000078e5533d9f7e  push r10
000078e5533d9f80  push r11
000078e5533d9f82  sub rsp, 0xF0
000078e5533d9f89  vmovaps [rsp], xmm0
000078e5533d9f8e  vmovaps [rsp+0x10], xmm1
000078e5533d9f94  vmovaps [rsp+0x20], xmm2
000078e5533d9f9a  vmovaps [rsp+0x30], xmm3
000078e5533d9fa0  vmovaps [rsp+0x40], xmm4
000078e5533d9fa6  vmovaps [rsp+0x50], xmm5
000078e5533d9fac  vmovaps [rsp+0x60], xmm7
000078e5533d9fb2  vmovaps [rsp+0x70], xmm8
000078e5533d9fb8  vmovaps [rsp+0x80], xmm9
000078e5533d9fc1  vmovaps [rsp+0x90], xmm10
000078e5533d9fca  vmovaps [rsp+0xA0], xmm11
000078e5533d9fd3  vmovaps [rsp+0xB0], xmm12
000078e5533d9fdc  vmovaps [rsp+0xC0], xmm13
000078e5533d9fe5  vmovaps [rsp+0xD0], xmm14
000078e5533d9fee  vmovaps [rsp+0xE0], xmm15
000078e5533d9ff7  sub rsp, 0x30
000078e5533d9ffb  movaps [rsp], xmm6
000078e5533d9fff  movaps [rsp+0x10], xmm1
000078e5533da004  movaps [rsp+0x20], xmm14
000078e5533da00a  lea rdi, [rsp]
000078e5533da00e  mov esi, 0x00
000078e5533da013  mov rax, 0x5F83D5E17530
000078e5533da01d  call rax
000078e5533da01f  movaps xmm6, [rsp]
000078e5533da023  add rsp, 0x30
000078e5533da027  vmovaps xmm0, [rsp]
000078e5533da02c  vmovaps xmm1, [rsp+0x10]
000078e5533da032  vmovaps xmm2, [rsp+0x20]
000078e5533da038  vmovaps xmm3, [rsp+0x30]
000078e5533da03e  vmovaps xmm4, [rsp+0x40]
000078e5533da044  vmovaps xmm5, [rsp+0x50]
000078e5533da04a  vmovaps xmm7, [rsp+0x60]
000078e5533da050  vmovaps xmm8, [rsp+0x70]
000078e5533da056  vmovaps xmm9, [rsp+0x80]
000078e5533da05f  vmovaps xmm10, [rsp+0x90]
000078e5533da068  vmovaps xmm11, [rsp+0xA0]
000078e5533da071  vmovaps xmm12, [rsp+0xB0]
000078e5533da07a  vmovaps xmm13, [rsp+0xC0]
000078e5533da083  vmovaps xmm14, [rsp+0xD0]
000078e5533da08c  vmovaps xmm15, [rsp+0xE0]
000078e5533da095  add rsp, 0xF0
000078e5533da09c  pop r11
000078e5533da09e  pop r10
000078e5533da0a0  pop r9
000078e5533da0a2  pop r8
000078e5533da0a4  pop rsi
000078e5533da0a5  pop rdi
000078e5533da0a6  pop rdx
000078e5533da0a7  pop rcx
000078e5533da0a8  pop rax
000078e5533da0a9  add rsp, 0x08
000078e5533da0ad  jmp 0x000078E5533D63DA
000078e5533da0b2  sub rsp, 0x08
000078e5533da0b6  push rax
000078e5533da0b7  push rcx
000078e5533da0b8  push rdx
000078e5533da0b9  push rdi
000078e5533da0ba  push rsi
000078e5533da0bb  push r8
000078e5533da0bd  push r9
000078e5533da0bf  push r10
000078e5533da0c1  push r11
000078e5533da0c3  sub rsp, 0xF0
000078e5533da0ca  vmovaps [rsp], xmm0
000078e5533da0cf  vmovaps [rsp+0x10], xmm1
000078e5533da0d5  vmovaps [rsp+0x20], xmm2
000078e5533da0db  vmovaps [rsp+0x30], xmm3
000078e5533da0e1  vmovaps [rsp+0x40], xmm4
000078e5533da0e7  vmovaps [rsp+0x50], xmm5
000078e5533da0ed  vmovaps [rsp+0x60], xmm6
000078e5533da0f3  vmovaps [rsp+0x70], xmm7
000078e5533da0f9  vmovaps [rsp+0x80], xmm8
000078e5533da102  vmovaps [rsp+0x90], xmm9
000078e5533da10b  vmovaps [rsp+0xA0], xmm10
000078e5533da114  vmovaps [rsp+0xB0], xmm11
000078e5533da11d  vmovaps [rsp+0xC0], xmm12
000078e5533da126  vmovaps [rsp+0xD0], xmm13
000078e5533da12f  vmovaps [rsp+0xE0], xmm15
000078e5533da138  sub rsp, 0x30
000078e5533da13c  movaps [rsp], xmm14
000078e5533da141  movaps [rsp+0x10], xmm12
000078e5533da147  movaps [rsp+0x20], xmm1
000078e5533da14c  lea rdi, [rsp]
000078e5533da150  mov esi, 0x00
000078e5533da155  mov rax, 0x5F83D5E17530
000078e5533da15f  call rax
000078e5533da161  movaps xmm14, [rsp]
000078e5533da166  add rsp, 0x30
000078e5533da16a  vmovaps xmm0, [rsp]
000078e5533da16f  vmovaps xmm1, [rsp+0x10]
000078e5533da175  vmovaps xmm2, [rsp+0x20]
000078e5533da17b  vmovaps xmm3, [rsp+0x30]
000078e5533da181  vmovaps xmm4, [rsp+0x40]
000078e5533da187  vmovaps xmm5, [rsp+0x50]
000078e5533da18d  vmovaps xmm6, [rsp+0x60]
000078e5533da193  vmovaps xmm7, [rsp+0x70]
000078e5533da199  vmovaps xmm8, [rsp+0x80]
000078e5533da1a2  vmovaps xmm9, [rsp+0x90]
000078e5533da1ab  vmovaps xmm10, [rsp+0xA0]
000078e5533da1b4  vmovaps xmm11, [rsp+0xB0]
000078e5533da1bd  vmovaps xmm12, [rsp+0xC0]
000078e5533da1c6  vmovaps xmm13, [rsp+0xD0]
000078e5533da1cf  vmovaps xmm15, [rsp+0xE0]
000078e5533da1d8  add rsp, 0xF0
000078e5533da1df  pop r11
000078e5533da1e1  pop r10
000078e5533da1e3  pop r9
000078e5533da1e5  pop r8
000078e5533da1e7  pop rsi
000078e5533da1e8  pop rdi
000078e5533da1e9  pop rdx
000078e5533da1ea  pop rcx
000078e5533da1eb  pop rax
000078e5533da1ec  add rsp, 0x08
000078e5533da1f0  jmp 0x000078E5533D6400
000078e5533da1f5  sub rsp, 0x08
000078e5533da1f9  push rax
000078e5533da1fa  push rcx
000078e5533da1fb  push rdx
000078e5533da1fc  push rdi
000078e5533da1fd  push rsi
000078e5533da1fe  push r8
000078e5533da200  push r9
000078e5533da202  push r10
000078e5533da204  push r11
000078e5533da206  sub rsp, 0xF0
000078e5533da20d  vmovaps [rsp], xmm0
000078e5533da212  vmovaps [rsp+0x10], xmm2
000078e5533da218  vmovaps [rsp+0x20], xmm3
000078e5533da21e  vmovaps [rsp+0x30], xmm4
000078e5533da224  vmovaps [rsp+0x40], xmm5
000078e5533da22a  vmovaps [rsp+0x50], xmm6
000078e5533da230  vmovaps [rsp+0x60], xmm7
000078e5533da236  vmovaps [rsp+0x70], xmm8
000078e5533da23c  vmovaps [rsp+0x80], xmm9
000078e5533da245  vmovaps [rsp+0x90], xmm10
000078e5533da24e  vmovaps [rsp+0xA0], xmm11
000078e5533da257  vmovaps [rsp+0xB0], xmm12
000078e5533da260  vmovaps [rsp+0xC0], xmm13
000078e5533da269  vmovaps [rsp+0xD0], xmm14
000078e5533da272  vmovaps [rsp+0xE0], xmm15
000078e5533da27b  sub rsp, 0x30
000078e5533da27f  movaps [rsp], xmm1
000078e5533da283  movaps [rsp+0x10], xmm13
000078e5533da289  movaps [rsp+0x20], xmm9
000078e5533da28f  lea rdi, [rsp]
000078e5533da293  mov esi, 0x00
000078e5533da298  mov rax, 0x5F83D5E17530
000078e5533da2a2  call rax
000078e5533da2a4  movaps xmm1, [rsp]
000078e5533da2a8  add rsp, 0x30
000078e5533da2ac  vmovaps xmm0, [rsp]
000078e5533da2b1  vmovaps xmm2, [rsp+0x10]
000078e5533da2b7  vmovaps xmm3, [rsp+0x20]
000078e5533da2bd  vmovaps xmm4, [rsp+0x30]
000078e5533da2c3  vmovaps xmm5, [rsp+0x40]
000078e5533da2c9  vmovaps xmm6, [rsp+0x50]
000078e5533da2cf  vmovaps xmm7, [rsp+0x60]
000078e5533da2d5  vmovaps xmm8, [rsp+0x70]
000078e5533da2db  vmovaps xmm9, [rsp+0x80]
000078e5533da2e4  vmovaps xmm10, [rsp+0x90]
000078e5533da2ed  vmovaps xmm11, [rsp+0xA0]
000078e5533da2f6  vmovaps xmm12, [rsp+0xB0]
000078e5533da2ff  vmovaps xmm13, [rsp+0xC0]
000078e5533da308  vmovaps xmm14, [rsp+0xD0]
000078e5533da311  vmovaps xmm15, [rsp+0xE0]
000078e5533da31a  add rsp, 0xF0
000078e5533da321  pop r11
000078e5533da323  pop r10
000078e5533da325  pop r9
000078e5533da327  pop r8
000078e5533da329  pop rsi
000078e5533da32a  pop rdi
000078e5533da32b  pop rdx
000078e5533da32c  pop rcx
000078e5533da32d  pop rax
000078e5533da32e  add rsp, 0x08
000078e5533da332  jmp 0x000078E5533D641A
000078e5533da337  sub rsp, 0x08
000078e5533da33b  push rax
000078e5533da33c  push rcx
000078e5533da33d  push rdx
000078e5533da33e  push rdi
000078e5533da33f  push rsi
000078e5533da340  push r8
000078e5533da342  push r9
000078e5533da344  push r10
000078e5533da346  push r11
000078e5533da348  sub rsp, 0xF0
000078e5533da34f  vmovaps [rsp], xmm0
000078e5533da354  vmovaps [rsp+0x10], xmm1
000078e5533da35a  vmovaps [rsp+0x20], xmm2
000078e5533da360  vmovaps [rsp+0x30], xmm3
000078e5533da366  vmovaps [rsp+0x40], xmm4
000078e5533da36c  vmovaps [rsp+0x50], xmm5
000078e5533da372  vmovaps [rsp+0x60], xmm6
000078e5533da378  vmovaps [rsp+0x70], xmm7
000078e5533da37e  vmovaps [rsp+0x80], xmm8
000078e5533da387  vmovaps [rsp+0x90], xmm9
000078e5533da390  vmovaps [rsp+0xA0], xmm10
000078e5533da399  vmovaps [rsp+0xB0], xmm11
000078e5533da3a2  vmovaps [rsp+0xC0], xmm13
000078e5533da3ab  vmovaps [rsp+0xD0], xmm14
000078e5533da3b4  vmovaps [rsp+0xE0], xmm15
000078e5533da3bd  sub rsp, 0x30
000078e5533da3c1  movaps [rsp], xmm12
000078e5533da3c6  movaps [rsp+0x10], xmm7
000078e5533da3cb  movaps [rsp+0x20], xmm13
000078e5533da3d1  lea rdi, [rsp]
000078e5533da3d5  mov esi, 0x00
000078e5533da3da  mov rax, 0x5F83D5E17530
000078e5533da3e4  call rax
000078e5533da3e6  movaps xmm12, [rsp]
000078e5533da3eb  add rsp, 0x30
000078e5533da3ef  vmovaps xmm0, [rsp]
000078e5533da3f4  vmovaps xmm1, [rsp+0x10]
000078e5533da3fa  vmovaps xmm2, [rsp+0x20]
000078e5533da400  vmovaps xmm3, [rsp+0x30]
000078e5533da406  vmovaps xmm4, [rsp+0x40]
000078e5533da40c  vmovaps xmm5, [rsp+0x50]
000078e5533da412  vmovaps xmm6, [rsp+0x60]
000078e5533da418  vmovaps xmm7, [rsp+0x70]
000078e5533da41e  vmovaps xmm8, [rsp+0x80]
000078e5533da427  vmovaps xmm9, [rsp+0x90]
000078e5533da430  vmovaps xmm10, [rsp+0xA0]
000078e5533da439  vmovaps xmm11, [rsp+0xB0]
000078e5533da442  vmovaps xmm13, [rsp+0xC0]
000078e5533da44b  vmovaps xmm14, [rsp+0xD0]
000078e5533da454  vmovaps xmm15, [rsp+0xE0]
000078e5533da45d  add rsp, 0xF0
000078e5533da464  pop r11
000078e5533da466  pop r10
000078e5533da468  pop r9
000078e5533da46a  pop r8
000078e5533da46c  pop rsi
000078e5533da46d  pop rdi
000078e5533da46e  pop rdx
000078e5533da46f  pop rcx
000078e5533da470  pop rax
000078e5533da471  add rsp, 0x08
000078e5533da475  jmp 0x000078E5533D6441
000078e5533da47a  sub rsp, 0x08
000078e5533da47e  push rax
000078e5533da47f  push rcx
000078e5533da480  push rdx
000078e5533da481  push rdi
000078e5533da482  push rsi
000078e5533da483  push r8
000078e5533da485  push r9
000078e5533da487  push r10
000078e5533da489  push r11
000078e5533da48b  sub rsp, 0xF0
000078e5533da492  vmovaps [rsp], xmm0
000078e5533da497  vmovaps [rsp+0x10], xmm1
000078e5533da49d  vmovaps [rsp+0x20], xmm2
000078e5533da4a3  vmovaps [rsp+0x30], xmm3
000078e5533da4a9  vmovaps [rsp+0x40], xmm4
000078e5533da4af  vmovaps [rsp+0x50], xmm5
000078e5533da4b5  vmovaps [rsp+0x60], xmm6
000078e5533da4bb  vmovaps [rsp+0x70], xmm7
000078e5533da4c1  vmovaps [rsp+0x80], xmm8
000078e5533da4ca  vmovaps [rsp+0x90], xmm9
000078e5533da4d3  vmovaps [rsp+0xA0], xmm10
000078e5533da4dc  vmovaps [rsp+0xB0], xmm11
000078e5533da4e5  vmovaps [rsp+0xC0], xmm12
000078e5533da4ee  vmovaps [rsp+0xD0], xmm14
000078e5533da4f7  vmovaps [rsp+0xE0], xmm15
000078e5533da500  sub rsp, 0x30
000078e5533da504  movaps [rsp], xmm13
000078e5533da509  movaps [rsp+0x10], xmm15
000078e5533da50f  movaps [rsp+0x20], xmm8
000078e5533da515  lea rdi, [rsp]
000078e5533da519  mov esi, 0x00
000078e5533da51e  mov rax, 0x5F83D5E17530
000078e5533da528  call rax
000078e5533da52a  movaps xmm13, [rsp]
000078e5533da52f  add rsp, 0x30
000078e5533da533  vmovaps xmm0, [rsp]
000078e5533da538  vmovaps xmm1, [rsp+0x10]
000078e5533da53e  vmovaps xmm2, [rsp+0x20]
000078e5533da544  vmovaps xmm3, [rsp+0x30]
000078e5533da54a  vmovaps xmm4, [rsp+0x40]
000078e5533da550  vmovaps xmm5, [rsp+0x50]
000078e5533da556  vmovaps xmm6, [rsp+0x60]
000078e5533da55c  vmovaps xmm7, [rsp+0x70]
000078e5533da562  vmovaps xmm8, [rsp+0x80]
000078e5533da56b  vmovaps xmm9, [rsp+0x90]
000078e5533da574  vmovaps xmm10, [rsp+0xA0]
000078e5533da57d  vmovaps xmm11, [rsp+0xB0]
000078e5533da586  vmovaps xmm12, [rsp+0xC0]
000078e5533da58f  vmovaps xmm14, [rsp+0xD0]
000078e5533da598  vmovaps xmm15, [rsp+0xE0]
000078e5533da5a1  add rsp, 0xF0
000078e5533da5a8  pop r11
000078e5533da5aa  pop r10
000078e5533da5ac  pop r9
000078e5533da5ae  pop r8
000078e5533da5b0  pop rsi
000078e5533da5b1  pop rdi
000078e5533da5b2  pop rdx
000078e5533da5b3  pop rcx
000078e5533da5b4  pop rax
000078e5533da5b5  add rsp, 0x08
000078e5533da5b9  jmp 0x000078E5533D645C
000078e5533da5be  sub rsp, 0x08
000078e5533da5c2  push rax
000078e5533da5c3  push rcx
000078e5533da5c4  push rdx
000078e5533da5c5  push rdi
000078e5533da5c6  push rsi
000078e5533da5c7  push r8
000078e5533da5c9  push r9
000078e5533da5cb  push r10
000078e5533da5cd  push r11
000078e5533da5cf  sub rsp, 0xF0
000078e5533da5d6  vmovaps [rsp], xmm0
000078e5533da5db  vmovaps [rsp+0x10], xmm1
000078e5533da5e1  vmovaps [rsp+0x20], xmm2
000078e5533da5e7  vmovaps [rsp+0x30], xmm3
000078e5533da5ed  vmovaps [rsp+0x40], xmm4
000078e5533da5f3  vmovaps [rsp+0x50], xmm5
000078e5533da5f9  vmovaps [rsp+0x60], xmm6
000078e5533da5ff  vmovaps [rsp+0x70], xmm7
000078e5533da605  vmovaps [rsp+0x80], xmm9
000078e5533da60e  vmovaps [rsp+0x90], xmm10
000078e5533da617  vmovaps [rsp+0xA0], xmm11
000078e5533da620  vmovaps [rsp+0xB0], xmm12
000078e5533da629  vmovaps [rsp+0xC0], xmm13
000078e5533da632  vmovaps [rsp+0xD0], xmm14
000078e5533da63b  vmovaps [rsp+0xE0], xmm15
000078e5533da644  sub rsp, 0x30
000078e5533da648  movaps [rsp], xmm8
000078e5533da64d  movaps [rsp+0x10], xmm15
000078e5533da653  movaps [rsp+0x20], xmm9
000078e5533da659  lea rdi, [rsp]
000078e5533da65d  mov esi, 0x00
000078e5533da662  mov rax, 0x5F83D5E17530
000078e5533da66c  call rax
000078e5533da66e  movaps xmm8, [rsp]
000078e5533da673  add rsp, 0x30
000078e5533da677  vmovaps xmm0, [rsp]
000078e5533da67c  vmovaps xmm1, [rsp+0x10]
000078e5533da682  vmovaps xmm2, [rsp+0x20]
000078e5533da688  vmovaps xmm3, [rsp+0x30]
000078e5533da68e  vmovaps xmm4, [rsp+0x40]
000078e5533da694  vmovaps xmm5, [rsp+0x50]
000078e5533da69a  vmovaps xmm6, [rsp+0x60]
000078e5533da6a0  vmovaps xmm7, [rsp+0x70]
000078e5533da6a6  vmovaps xmm9, [rsp+0x80]
000078e5533da6af  vmovaps xmm10, [rsp+0x90]
000078e5533da6b8  vmovaps xmm11, [rsp+0xA0]
000078e5533da6c1  vmovaps xmm12, [rsp+0xB0]
000078e5533da6ca  vmovaps xmm13, [rsp+0xC0]
000078e5533da6d3  vmovaps xmm14, [rsp+0xD0]
000078e5533da6dc  vmovaps xmm15, [rsp+0xE0]
000078e5533da6e5  add rsp, 0xF0
000078e5533da6ec  pop r11
000078e5533da6ee  pop r10
000078e5533da6f0  pop r9
000078e5533da6f2  pop r8
000078e5533da6f4  pop rsi
000078e5533da6f5  pop rdi
000078e5533da6f6  pop rdx
000078e5533da6f7  pop rcx
000078e5533da6f8  pop rax
000078e5533da6f9  add rsp, 0x08
000078e5533da6fd  jmp 0x000078E5533D648A
000078e5533da702  sub rsp, 0x08
000078e5533da706  push rax
000078e5533da707  push rcx
000078e5533da708  push rdx
000078e5533da709  push rdi
000078e5533da70a  push rsi
000078e5533da70b  push r8
000078e5533da70d  push r9
000078e5533da70f  push r10
000078e5533da711  push r11
000078e5533da713  sub rsp, 0xF0
000078e5533da71a  vmovaps [rsp], xmm0
000078e5533da71f  vmovaps [rsp+0x10], xmm1
000078e5533da725  vmovaps [rsp+0x20], xmm2
000078e5533da72b  vmovaps [rsp+0x30], xmm3
000078e5533da731  vmovaps [rsp+0x40], xmm4
000078e5533da737  vmovaps [rsp+0x50], xmm5
000078e5533da73d  vmovaps [rsp+0x60], xmm6
000078e5533da743  vmovaps [rsp+0x70], xmm7
000078e5533da749  vmovaps [rsp+0x80], xmm8
000078e5533da752  vmovaps [rsp+0x90], xmm9
000078e5533da75b  vmovaps [rsp+0xA0], xmm10
000078e5533da764  vmovaps [rsp+0xB0], xmm11
000078e5533da76d  vmovaps [rsp+0xC0], xmm12
000078e5533da776  vmovaps [rsp+0xD0], xmm13
000078e5533da77f  vmovaps [rsp+0xE0], xmm14
000078e5533da788  sub rsp, 0x30
000078e5533da78c  movaps [rsp], xmm15
000078e5533da791  movaps [rsp+0x10], xmm11
000078e5533da797  movaps [rsp+0x20], xmm6
000078e5533da79c  lea rdi, [rsp]
000078e5533da7a0  mov esi, 0x00
000078e5533da7a5  mov rax, 0x5F83D5E17530
000078e5533da7af  call rax
000078e5533da7b1  movaps xmm15, [rsp]
000078e5533da7b6  add rsp, 0x30
000078e5533da7ba  vmovaps xmm0, [rsp]
000078e5533da7bf  vmovaps xmm1, [rsp+0x10]
000078e5533da7c5  vmovaps xmm2, [rsp+0x20]
000078e5533da7cb  vmovaps xmm3, [rsp+0x30]
000078e5533da7d1  vmovaps xmm4, [rsp+0x40]
000078e5533da7d7  vmovaps xmm5, [rsp+0x50]
000078e5533da7dd  vmovaps xmm6, [rsp+0x60]
000078e5533da7e3  vmovaps xmm7, [rsp+0x70]
000078e5533da7e9  vmovaps xmm8, [rsp+0x80]
000078e5533da7f2  vmovaps xmm9, [rsp+0x90]
000078e5533da7fb  vmovaps xmm10, [rsp+0xA0]
000078e5533da804  vmovaps xmm11, [rsp+0xB0]
000078e5533da80d  vmovaps xmm12, [rsp+0xC0]
000078e5533da816  vmovaps xmm13, [rsp+0xD0]
000078e5533da81f  vmovaps xmm14, [rsp+0xE0]
000078e5533da828  add rsp, 0xF0
000078e5533da82f  pop r11
000078e5533da831  pop r10
000078e5533da833  pop r9
000078e5533da835  pop r8
000078e5533da837  pop rsi
000078e5533da838  pop rdi
000078e5533da839  pop rdx
000078e5533da83a  pop rcx
000078e5533da83b  pop rax
000078e5533da83c  add rsp, 0x08
000078e5533da840  jmp 0x000078E5533D64A5
000078e5533da845  sub rsp, 0x08
000078e5533da849  push rax
000078e5533da84a  push rcx
000078e5533da84b  push rdx
000078e5533da84c  push rdi
000078e5533da84d  push rsi
000078e5533da84e  push r8
000078e5533da850  push r9
000078e5533da852  push r10
000078e5533da854  push r11
000078e5533da856  sub rsp, 0xF0
000078e5533da85d  vmovaps [rsp], xmm0
000078e5533da862  vmovaps [rsp+0x10], xmm1
000078e5533da868  vmovaps [rsp+0x20], xmm2
000078e5533da86e  vmovaps [rsp+0x30], xmm3
000078e5533da874  vmovaps [rsp+0x40], xmm4
000078e5533da87a  vmovaps [rsp+0x50], xmm5
000078e5533da880  vmovaps [rsp+0x60], xmm6
000078e5533da886  vmovaps [rsp+0x70], xmm8
000078e5533da88c  vmovaps [rsp+0x80], xmm9
000078e5533da895  vmovaps [rsp+0x90], xmm10
000078e5533da89e  vmovaps [rsp+0xA0], xmm11
000078e5533da8a7  vmovaps [rsp+0xB0], xmm12
000078e5533da8b0  vmovaps [rsp+0xC0], xmm13
000078e5533da8b9  vmovaps [rsp+0xD0], xmm14
000078e5533da8c2  vmovaps [rsp+0xE0], xmm15
000078e5533da8cb  sub rsp, 0x30
000078e5533da8cf  movaps [rsp], xmm7
000078e5533da8d3  movaps [rsp+0x10], xmm11
000078e5533da8d9  movaps [rsp+0x20], xmm9
000078e5533da8df  lea rdi, [rsp]
000078e5533da8e3  mov esi, 0x00
000078e5533da8e8  mov rax, 0x5F83D5E17530
000078e5533da8f2  call rax
000078e5533da8f4  movaps xmm7, [rsp]
000078e5533da8f8  add rsp, 0x30
000078e5533da8fc  vmovaps xmm0, [rsp]
000078e5533da901  vmovaps xmm1, [rsp+0x10]
000078e5533da907  vmovaps xmm2, [rsp+0x20]
000078e5533da90d  vmovaps xmm3, [rsp+0x30]
000078e5533da913  vmovaps xmm4, [rsp+0x40]
000078e5533da919  vmovaps xmm5, [rsp+0x50]
000078e5533da91f  vmovaps xmm6, [rsp+0x60]
000078e5533da925  vmovaps xmm8, [rsp+0x70]
000078e5533da92b  vmovaps xmm9, [rsp+0x80]
000078e5533da934  vmovaps xmm10, [rsp+0x90]
000078e5533da93d  vmovaps xmm11, [rsp+0xA0]
000078e5533da946  vmovaps xmm12, [rsp+0xB0]
000078e5533da94f  vmovaps xmm13, [rsp+0xC0]
000078e5533da958  vmovaps xmm14, [rsp+0xD0]
000078e5533da961  vmovaps xmm15, [rsp+0xE0]
000078e5533da96a  add rsp, 0xF0
000078e5533da971  pop r11
000078e5533da973  pop r10
000078e5533da975  pop r9
000078e5533da977  pop r8
000078e5533da979  pop rsi
000078e5533da97a  pop rdi
000078e5533da97b  pop rdx
000078e5533da97c  pop rcx
000078e5533da97d  pop rax
000078e5533da97e  add rsp, 0x08
000078e5533da982  jmp 0x000078E5533D64D2
000078e5533da987  sub rsp, 0x08
000078e5533da98b  push rax
000078e5533da98c  push rcx
000078e5533da98d  push rdx
000078e5533da98e  push rdi
000078e5533da98f  push rsi
000078e5533da990  push r8
000078e5533da992  push r9
000078e5533da994  push r10
000078e5533da996  push r11
000078e5533da998  sub rsp, 0xF0
000078e5533da99f  vmovaps [rsp], xmm0
000078e5533da9a4  vmovaps [rsp+0x10], xmm1
000078e5533da9aa  vmovaps [rsp+0x20], xmm2
000078e5533da9b0  vmovaps [rsp+0x30], xmm3
000078e5533da9b6  vmovaps [rsp+0x40], xmm4
000078e5533da9bc  vmovaps [rsp+0x50], xmm5
000078e5533da9c2  vmovaps [rsp+0x60], xmm6
000078e5533da9c8  vmovaps [rsp+0x70], xmm7
000078e5533da9ce  vmovaps [rsp+0x80], xmm8
000078e5533da9d7  vmovaps [rsp+0x90], xmm9
000078e5533da9e0  vmovaps [rsp+0xA0], xmm10
000078e5533da9e9  vmovaps [rsp+0xB0], xmm12
000078e5533da9f2  vmovaps [rsp+0xC0], xmm13
000078e5533da9fb  vmovaps [rsp+0xD0], xmm14
000078e5533daa04  vmovaps [rsp+0xE0], xmm15
000078e5533daa0d  sub rsp, 0x30
000078e5533daa11  movaps [rsp], xmm11
000078e5533daa16  movaps [rsp+0x10], xmm10
000078e5533daa1c  movaps [rsp+0x20], xmm14
000078e5533daa22  lea rdi, [rsp]
000078e5533daa26  mov esi, 0x00
000078e5533daa2b  mov rax, 0x5F83D5E17530
000078e5533daa35  call rax
000078e5533daa37  movaps xmm11, [rsp]
000078e5533daa3c  add rsp, 0x30
000078e5533daa40  vmovaps xmm0, [rsp]
000078e5533daa45  vmovaps xmm1, [rsp+0x10]
000078e5533daa4b  vmovaps xmm2, [rsp+0x20]
000078e5533daa51  vmovaps xmm3, [rsp+0x30]
000078e5533daa57  vmovaps xmm4, [rsp+0x40]
000078e5533daa5d  vmovaps xmm5, [rsp+0x50]
000078e5533daa63  vmovaps xmm6, [rsp+0x60]
000078e5533daa69  vmovaps xmm7, [rsp+0x70]
000078e5533daa6f  vmovaps xmm8, [rsp+0x80]
000078e5533daa78  vmovaps xmm9, [rsp+0x90]
000078e5533daa81  vmovaps xmm10, [rsp+0xA0]
000078e5533daa8a  vmovaps xmm12, [rsp+0xB0]
000078e5533daa93  vmovaps xmm13, [rsp+0xC0]
000078e5533daa9c  vmovaps xmm14, [rsp+0xD0]
000078e5533daaa5  vmovaps xmm15, [rsp+0xE0]
000078e5533daaae  add rsp, 0xF0
000078e5533daab5  pop r11
000078e5533daab7  pop r10
000078e5533daab9  pop r9
000078e5533daabb  pop r8
000078e5533daabd  pop rsi
000078e5533daabe  pop rdi
000078e5533daabf  pop rdx
000078e5533daac0  pop rcx
000078e5533daac1  pop rax
000078e5533daac2  add rsp, 0x08
000078e5533daac6  jmp 0x000078E5533D64ED
000078e5533daacb  call 0x000078E5532E45A0
000078e5533daad0  jmp 0x000078E5533D64F7
000078e5533daad5  sub rsp, 0x08
000078e5533daad9  push rax
000078e5533daada  push rcx
000078e5533daadb  push rdx
000078e5533daadc  push rdi
000078e5533daadd  push rsi
000078e5533daade  push r8
000078e5533daae0  push r9
000078e5533daae2  push r10
000078e5533daae4  push r11
000078e5533daae6  sub rsp, 0xF0
000078e5533daaed  vmovaps [rsp], xmm0
000078e5533daaf2  vmovaps [rsp+0x10], xmm1
000078e5533daaf8  vmovaps [rsp+0x20], xmm2
000078e5533daafe  vmovaps [rsp+0x30], xmm3
000078e5533dab04  vmovaps [rsp+0x40], xmm4
000078e5533dab0a  vmovaps [rsp+0x50], xmm5
000078e5533dab10  vmovaps [rsp+0x60], xmm6
000078e5533dab16  vmovaps [rsp+0x70], xmm7
000078e5533dab1c  vmovaps [rsp+0x80], xmm8
000078e5533dab25  vmovaps [rsp+0x90], xmm9
000078e5533dab2e  vmovaps [rsp+0xA0], xmm11
000078e5533dab37  vmovaps [rsp+0xB0], xmm12
000078e5533dab40  vmovaps [rsp+0xC0], xmm13
000078e5533dab49  vmovaps [rsp+0xD0], xmm14
000078e5533dab52  vmovaps [rsp+0xE0], xmm15
000078e5533dab5b  sub rsp, 0x30
000078e5533dab5f  movaps [rsp], xmm10
000078e5533dab64  movaps [rsp+0x10], xmm1
000078e5533dab69  movaps [rsp+0x20], xmm12
000078e5533dab6f  lea rdi, [rsp]
000078e5533dab73  mov esi, 0x00
000078e5533dab78  mov rax, 0x5F83D5E17530
000078e5533dab82  call rax
000078e5533dab84  movaps xmm10, [rsp]
000078e5533dab89  add rsp, 0x30
000078e5533dab8d  vmovaps xmm0, [rsp]
000078e5533dab92  vmovaps xmm1, [rsp+0x10]
000078e5533dab98  vmovaps xmm2, [rsp+0x20]
000078e5533dab9e  vmovaps xmm3, [rsp+0x30]
000078e5533daba4  vmovaps xmm4, [rsp+0x40]
000078e5533dabaa  vmovaps xmm5, [rsp+0x50]
000078e5533dabb0  vmovaps xmm6, [rsp+0x60]
000078e5533dabb6  vmovaps xmm7, [rsp+0x70]
000078e5533dabbc  vmovaps xmm8, [rsp+0x80]
000078e5533dabc5  vmovaps xmm9, [rsp+0x90]
000078e5533dabce  vmovaps xmm11, [rsp+0xA0]
000078e5533dabd7  vmovaps xmm12, [rsp+0xB0]
000078e5533dabe0  vmovaps xmm13, [rsp+0xC0]
000078e5533dabe9  vmovaps xmm14, [rsp+0xD0]
000078e5533dabf2  vmovaps xmm15, [rsp+0xE0]
000078e5533dabfb  add rsp, 0xF0
000078e5533dac02  pop r11
000078e5533dac04  pop r10
000078e5533dac06  pop r9
000078e5533dac08  pop r8
000078e5533dac0a  pop rsi
000078e5533dac0b  pop rdi
000078e5533dac0c  pop rdx
000078e5533dac0d  pop rcx
000078e5533dac0e  pop rax
000078e5533dac0f  add rsp, 0x08
000078e5533dac13  jmp 0x000078E5533D651A
000078e5533dac18  sub rsp, 0x08
000078e5533dac1c  push rax
000078e5533dac1d  push rcx
000078e5533dac1e  push rdx
000078e5533dac1f  push rdi
000078e5533dac20  push rsi
000078e5533dac21  push r8
000078e5533dac23  push r9
000078e5533dac25  push r10
000078e5533dac27  push r11
000078e5533dac29  sub rsp, 0xF0
000078e5533dac30  vmovaps [rsp], xmm0
000078e5533dac35  vmovaps [rsp+0x10], xmm1
000078e5533dac3b  vmovaps [rsp+0x20], xmm2
000078e5533dac41  vmovaps [rsp+0x30], xmm3
000078e5533dac47  vmovaps [rsp+0x40], xmm4
000078e5533dac4d  vmovaps [rsp+0x50], xmm5
000078e5533dac53  vmovaps [rsp+0x60], xmm6
000078e5533dac59  vmovaps [rsp+0x70], xmm7
000078e5533dac5f  vmovaps [rsp+0x80], xmm8
000078e5533dac68  vmovaps [rsp+0x90], xmm9
000078e5533dac71  vmovaps [rsp+0xA0], xmm10
000078e5533dac7a  vmovaps [rsp+0xB0], xmm11
000078e5533dac83  vmovaps [rsp+0xC0], xmm13
000078e5533dac8c  vmovaps [rsp+0xD0], xmm14
000078e5533dac95  vmovaps [rsp+0xE0], xmm15
000078e5533dac9e  sub rsp, 0x30
000078e5533daca2  movaps [rsp], xmm12
000078e5533daca7  movaps [rsp+0x10], xmm14
000078e5533dacad  movaps [rsp+0x20], xmm1
000078e5533dacb2  lea rdi, [rsp]
000078e5533dacb6  mov esi, 0x00
000078e5533dacbb  mov rax, 0x5F83D5E17530
000078e5533dacc5  call rax
000078e5533dacc7  movaps xmm12, [rsp]
000078e5533daccc  add rsp, 0x30
000078e5533dacd0  vmovaps xmm0, [rsp]
000078e5533dacd5  vmovaps xmm1, [rsp+0x10]
000078e5533dacdb  vmovaps xmm2, [rsp+0x20]
000078e5533dace1  vmovaps xmm3, [rsp+0x30]
000078e5533dace7  vmovaps xmm4, [rsp+0x40]
000078e5533daced  vmovaps xmm5, [rsp+0x50]
000078e5533dacf3  vmovaps xmm6, [rsp+0x60]
000078e5533dacf9  vmovaps xmm7, [rsp+0x70]
000078e5533dacff  vmovaps xmm8, [rsp+0x80]
000078e5533dad08  vmovaps xmm9, [rsp+0x90]
000078e5533dad11  vmovaps xmm10, [rsp+0xA0]
000078e5533dad1a  vmovaps xmm11, [rsp+0xB0]
000078e5533dad23  vmovaps xmm13, [rsp+0xC0]
000078e5533dad2c  vmovaps xmm14, [rsp+0xD0]
000078e5533dad35  vmovaps xmm15, [rsp+0xE0]
000078e5533dad3e  add rsp, 0xF0
000078e5533dad45  pop r11
000078e5533dad47  pop r10
000078e5533dad49  pop r9
000078e5533dad4b  pop r8
000078e5533dad4d  pop rsi
000078e5533dad4e  pop rdi
000078e5533dad4f  pop rdx
000078e5533dad50  pop rcx
000078e5533dad51  pop rax
000078e5533dad52  add rsp, 0x08
000078e5533dad56  jmp 0x000078E5533D6549
000078e5533dad5b  sub rsp, 0x08
000078e5533dad5f  push rax
000078e5533dad60  push rcx
000078e5533dad61  push rdx
000078e5533dad62  push rdi
000078e5533dad63  push rsi
000078e5533dad64  push r8
000078e5533dad66  push r9
000078e5533dad68  push r10
000078e5533dad6a  push r11
000078e5533dad6c  sub rsp, 0xF0
000078e5533dad73  vmovaps [rsp], xmm0
000078e5533dad78  vmovaps [rsp+0x10], xmm1
000078e5533dad7e  vmovaps [rsp+0x20], xmm2
000078e5533dad84  vmovaps [rsp+0x30], xmm3
000078e5533dad8a  vmovaps [rsp+0x40], xmm4
000078e5533dad90  vmovaps [rsp+0x50], xmm5
000078e5533dad96  vmovaps [rsp+0x60], xmm6
000078e5533dad9c  vmovaps [rsp+0x70], xmm7
000078e5533dada2  vmovaps [rsp+0x80], xmm8
000078e5533dadab  vmovaps [rsp+0x90], xmm9
000078e5533dadb4  vmovaps [rsp+0xA0], xmm10
000078e5533dadbd  vmovaps [rsp+0xB0], xmm11
000078e5533dadc6  vmovaps [rsp+0xC0], xmm12
000078e5533dadcf  vmovaps [rsp+0xD0], xmm13
000078e5533dadd8  vmovaps [rsp+0xE0], xmm15
000078e5533dade1  sub rsp, 0x30
000078e5533dade5  movaps [rsp], xmm14
000078e5533dadea  movaps [rsp+0x10], xmm9
000078e5533dadf0  movaps [rsp+0x20], xmm1
000078e5533dadf5  lea rdi, [rsp]
000078e5533dadf9  mov esi, 0x00
000078e5533dadfe  mov rax, 0x5F83D5E17530
000078e5533dae08  call rax
000078e5533dae0a  movaps xmm14, [rsp]
000078e5533dae0f  add rsp, 0x30
000078e5533dae13  vmovaps xmm0, [rsp]
000078e5533dae18  vmovaps xmm1, [rsp+0x10]
000078e5533dae1e  vmovaps xmm2, [rsp+0x20]
000078e5533dae24  vmovaps xmm3, [rsp+0x30]
000078e5533dae2a  vmovaps xmm4, [rsp+0x40]
000078e5533dae30  vmovaps xmm5, [rsp+0x50]
000078e5533dae36  vmovaps xmm6, [rsp+0x60]
000078e5533dae3c  vmovaps xmm7, [rsp+0x70]
000078e5533dae42  vmovaps xmm8, [rsp+0x80]
000078e5533dae4b  vmovaps xmm9, [rsp+0x90]
000078e5533dae54  vmovaps xmm10, [rsp+0xA0]
000078e5533dae5d  vmovaps xmm11, [rsp+0xB0]
000078e5533dae66  vmovaps xmm12, [rsp+0xC0]
000078e5533dae6f  vmovaps xmm13, [rsp+0xD0]
000078e5533dae78  vmovaps xmm15, [rsp+0xE0]
000078e5533dae81  add rsp, 0xF0
000078e5533dae88  pop r11
000078e5533dae8a  pop r10
000078e5533dae8c  pop r9
000078e5533dae8e  pop r8
000078e5533dae90  pop rsi
000078e5533dae91  pop rdi
000078e5533dae92  pop rdx
000078e5533dae93  pop rcx
000078e5533dae94  pop rax
000078e5533dae95  add rsp, 0x08
000078e5533dae99  jmp 0x000078E5533D6578
000078e5533dae9e  sub rsp, 0x08
000078e5533daea2  push rax
000078e5533daea3  push rcx
000078e5533daea4  push rdx
000078e5533daea5  push rdi
000078e5533daea6  push rsi
000078e5533daea7  push r8
000078e5533daea9  push r9
000078e5533daeab  push r10
000078e5533daead  push r11
000078e5533daeaf  sub rsp, 0xF0
000078e5533daeb6  vmovaps [rsp], xmm0
000078e5533daebb  vmovaps [rsp+0x10], xmm2
000078e5533daec1  vmovaps [rsp+0x20], xmm3
000078e5533daec7  vmovaps [rsp+0x30], xmm4
000078e5533daecd  vmovaps [rsp+0x40], xmm5
000078e5533daed3  vmovaps [rsp+0x50], xmm6
000078e5533daed9  vmovaps [rsp+0x60], xmm7
000078e5533daedf  vmovaps [rsp+0x70], xmm8
000078e5533daee5  vmovaps [rsp+0x80], xmm9
000078e5533daeee  vmovaps [rsp+0x90], xmm10
000078e5533daef7  vmovaps [rsp+0xA0], xmm11
000078e5533daf00  vmovaps [rsp+0xB0], xmm12
000078e5533daf09  vmovaps [rsp+0xC0], xmm13
000078e5533daf12  vmovaps [rsp+0xD0], xmm14
000078e5533daf1b  vmovaps [rsp+0xE0], xmm15
000078e5533daf24  sub rsp, 0x30
000078e5533daf28  movaps [rsp], xmm1
000078e5533daf2c  movaps [rsp+0x10], xmm13
000078e5533daf32  movaps [rsp+0x20], xmm8
000078e5533daf38  lea rdi, [rsp]
000078e5533daf3c  mov esi, 0x00
000078e5533daf41  mov rax, 0x5F83D5E17530
000078e5533daf4b  call rax
000078e5533daf4d  movaps xmm1, [rsp]
000078e5533daf51  add rsp, 0x30
000078e5533daf55  vmovaps xmm0, [rsp]
000078e5533daf5a  vmovaps xmm2, [rsp+0x10]
000078e5533daf60  vmovaps xmm3, [rsp+0x20]
000078e5533daf66  vmovaps xmm4, [rsp+0x30]
000078e5533daf6c  vmovaps xmm5, [rsp+0x40]
000078e5533daf72  vmovaps xmm6, [rsp+0x50]
000078e5533daf78  vmovaps xmm7, [rsp+0x60]
000078e5533daf7e  vmovaps xmm8, [rsp+0x70]
000078e5533daf84  vmovaps xmm9, [rsp+0x80]
000078e5533daf8d  vmovaps xmm10, [rsp+0x90]
000078e5533daf96  vmovaps xmm11, [rsp+0xA0]
000078e5533daf9f  vmovaps xmm12, [rsp+0xB0]
000078e5533dafa8  vmovaps xmm13, [rsp+0xC0]
000078e5533dafb1  vmovaps xmm14, [rsp+0xD0]
000078e5533dafba  vmovaps xmm15, [rsp+0xE0]
000078e5533dafc3  add rsp, 0xF0
000078e5533dafca  pop r11
000078e5533dafcc  pop r10
000078e5533dafce  pop r9
000078e5533dafd0  pop r8
000078e5533dafd2  pop rsi
000078e5533dafd3  pop rdi
000078e5533dafd4  pop rdx
000078e5533dafd5  pop rcx
000078e5533dafd6  pop rax
000078e5533dafd7  add rsp, 0x08
000078e5533dafdb  jmp 0x000078E5533D659A
000078e5533dafe0  call 0x000078E55320C260
000078e5533dafe5  jmp 0x000078E5533D65A8
000078e5533dafea  call 0x000078E5532DE950
000078e5533dafef  jmp 0x000078E5533D65B2
000078e5533daff4  sub rsp, 0x08
000078e5533daff8  push rax
000078e5533daff9  push rcx
000078e5533daffa  push rdx
000078e5533daffb  push rdi
000078e5533daffc  push rsi
000078e5533daffd  push r8
000078e5533dafff  push r9
000078e5533db001  push r10
000078e5533db003  push r11
000078e5533db005  sub rsp, 0xF0
000078e5533db00c  vmovaps [rsp], xmm0
000078e5533db011  vmovaps [rsp+0x10], xmm1
000078e5533db017  vmovaps [rsp+0x20], xmm2
000078e5533db01d  vmovaps [rsp+0x30], xmm3
000078e5533db023  vmovaps [rsp+0x40], xmm4
000078e5533db029  vmovaps [rsp+0x50], xmm5
000078e5533db02f  vmovaps [rsp+0x60], xmm6
000078e5533db035  vmovaps [rsp+0x70], xmm7
000078e5533db03b  vmovaps [rsp+0x80], xmm9
000078e5533db044  vmovaps [rsp+0x90], xmm10
000078e5533db04d  vmovaps [rsp+0xA0], xmm11
000078e5533db056  vmovaps [rsp+0xB0], xmm12
000078e5533db05f  vmovaps [rsp+0xC0], xmm13
000078e5533db068  vmovaps [rsp+0xD0], xmm14
000078e5533db071  vmovaps [rsp+0xE0], xmm15
000078e5533db07a  sub rsp, 0x30
000078e5533db07e  movaps [rsp], xmm8
000078e5533db083  movaps [rsp+0x10], xmm15
000078e5533db089  movaps [rsp+0x20], xmm7
000078e5533db08e  lea rdi, [rsp]
000078e5533db092  mov esi, 0x00
000078e5533db097  mov rax, 0x5F83D5E17530
000078e5533db0a1  call rax
000078e5533db0a3  movaps xmm8, [rsp]
000078e5533db0a8  add rsp, 0x30
000078e5533db0ac  vmovaps xmm0, [rsp]
000078e5533db0b1  vmovaps xmm1, [rsp+0x10]
000078e5533db0b7  vmovaps xmm2, [rsp+0x20]
000078e5533db0bd  vmovaps xmm3, [rsp+0x30]
000078e5533db0c3  vmovaps xmm4, [rsp+0x40]
000078e5533db0c9  vmovaps xmm5, [rsp+0x50]
000078e5533db0cf  vmovaps xmm6, [rsp+0x60]
000078e5533db0d5  vmovaps xmm7, [rsp+0x70]
000078e5533db0db  vmovaps xmm9, [rsp+0x80]
000078e5533db0e4  vmovaps xmm10, [rsp+0x90]
000078e5533db0ed  vmovaps xmm11, [rsp+0xA0]
000078e5533db0f6  vmovaps xmm12, [rsp+0xB0]
000078e5533db0ff  vmovaps xmm13, [rsp+0xC0]
000078e5533db108  vmovaps xmm14, [rsp+0xD0]
000078e5533db111  vmovaps xmm15, [rsp+0xE0]
000078e5533db11a  add rsp, 0xF0
000078e5533db121  pop r11
000078e5533db123  pop r10
000078e5533db125  pop r9
000078e5533db127  pop r8
000078e5533db129  pop rsi
000078e5533db12a  pop rdi
000078e5533db12b  pop rdx
000078e5533db12c  pop rcx
000078e5533db12d  pop rax
000078e5533db12e  add rsp, 0x08
000078e5533db132  jmp 0x000078E5533D65D4
000078e5533db137  sub rsp, 0x08
000078e5533db13b  push rax
000078e5533db13c  push rcx
000078e5533db13d  push rdx
000078e5533db13e  push rdi
000078e5533db13f  push rsi
000078e5533db140  push r8
000078e5533db142  push r9
000078e5533db144  push r10
000078e5533db146  push r11
000078e5533db148  sub rsp, 0xF0
000078e5533db14f  vmovaps [rsp], xmm0
000078e5533db154  vmovaps [rsp+0x10], xmm1
000078e5533db15a  vmovaps [rsp+0x20], xmm2
000078e5533db160  vmovaps [rsp+0x30], xmm3
000078e5533db166  vmovaps [rsp+0x40], xmm4
000078e5533db16c  vmovaps [rsp+0x50], xmm5
000078e5533db172  vmovaps [rsp+0x60], xmm6
000078e5533db178  vmovaps [rsp+0x70], xmm8
000078e5533db17e  vmovaps [rsp+0x80], xmm9
000078e5533db187  vmovaps [rsp+0x90], xmm10
000078e5533db190  vmovaps [rsp+0xA0], xmm11
000078e5533db199  vmovaps [rsp+0xB0], xmm12
000078e5533db1a2  vmovaps [rsp+0xC0], xmm13
000078e5533db1ab  vmovaps [rsp+0xD0], xmm14
000078e5533db1b4  vmovaps [rsp+0xE0], xmm15
000078e5533db1bd  sub rsp, 0x30
000078e5533db1c1  movaps [rsp], xmm7
000078e5533db1c5  movaps [rsp+0x10], xmm9
000078e5533db1cb  movaps [rsp+0x20], xmm15
000078e5533db1d1  lea rdi, [rsp]
000078e5533db1d5  mov esi, 0x00
000078e5533db1da  mov rax, 0x5F83D5E17530
000078e5533db1e4  call rax
000078e5533db1e6  movaps xmm7, [rsp]
000078e5533db1ea  add rsp, 0x30
000078e5533db1ee  vmovaps xmm0, [rsp]
000078e5533db1f3  vmovaps xmm1, [rsp+0x10]
000078e5533db1f9  vmovaps xmm2, [rsp+0x20]
000078e5533db1ff  vmovaps xmm3, [rsp+0x30]
000078e5533db205  vmovaps xmm4, [rsp+0x40]
000078e5533db20b  vmovaps xmm5, [rsp+0x50]
000078e5533db211  vmovaps xmm6, [rsp+0x60]
000078e5533db217  vmovaps xmm8, [rsp+0x70]
000078e5533db21d  vmovaps xmm9, [rsp+0x80]
000078e5533db226  vmovaps xmm10, [rsp+0x90]
000078e5533db22f  vmovaps xmm11, [rsp+0xA0]
000078e5533db238  vmovaps xmm12, [rsp+0xB0]
000078e5533db241  vmovaps xmm13, [rsp+0xC0]
000078e5533db24a  vmovaps xmm14, [rsp+0xD0]
000078e5533db253  vmovaps xmm15, [rsp+0xE0]
000078e5533db25c  add rsp, 0xF0
000078e5533db263  pop r11
000078e5533db265  pop r10
000078e5533db267  pop r9
000078e5533db269  pop r8
000078e5533db26b  pop rsi
000078e5533db26c  pop rdi
000078e5533db26d  pop rdx
000078e5533db26e  pop rcx
000078e5533db26f  pop rax
000078e5533db270  add rsp, 0x08
000078e5533db274  jmp 0x000078E5533D6601
000078e5533db279  sub rsp, 0x08
000078e5533db27d  push rax
000078e5533db27e  push rcx
000078e5533db27f  push rdx
000078e5533db280  push rdi
000078e5533db281  push rsi
000078e5533db282  push r8
000078e5533db284  push r9
000078e5533db286  push r10
000078e5533db288  push r11
000078e5533db28a  sub rsp, 0xF0
000078e5533db291  vmovaps [rsp], xmm0
000078e5533db296  vmovaps [rsp+0x10], xmm1
000078e5533db29c  vmovaps [rsp+0x20], xmm2
000078e5533db2a2  vmovaps [rsp+0x30], xmm3
000078e5533db2a8  vmovaps [rsp+0x40], xmm4
000078e5533db2ae  vmovaps [rsp+0x50], xmm5
000078e5533db2b4  vmovaps [rsp+0x60], xmm6
000078e5533db2ba  vmovaps [rsp+0x70], xmm7
000078e5533db2c0  vmovaps [rsp+0x80], xmm8
000078e5533db2c9  vmovaps [rsp+0x90], xmm10
000078e5533db2d2  vmovaps [rsp+0xA0], xmm11
000078e5533db2db  vmovaps [rsp+0xB0], xmm12
000078e5533db2e4  vmovaps [rsp+0xC0], xmm13
000078e5533db2ed  vmovaps [rsp+0xD0], xmm14
000078e5533db2f6  vmovaps [rsp+0xE0], xmm15
000078e5533db2ff  sub rsp, 0x30
000078e5533db303  movaps [rsp], xmm9
000078e5533db308  movaps [rsp+0x10], xmm13
000078e5533db30e  movaps [rsp+0x20], xmm15
000078e5533db314  lea rdi, [rsp]
000078e5533db318  mov esi, 0x00
000078e5533db31d  mov rax, 0x5F83D5E17530
000078e5533db327  call rax
000078e5533db329  movaps xmm9, [rsp]
000078e5533db32e  add rsp, 0x30
000078e5533db332  vmovaps xmm0, [rsp]
000078e5533db337  vmovaps xmm1, [rsp+0x10]
000078e5533db33d  vmovaps xmm2, [rsp+0x20]
000078e5533db343  vmovaps xmm3, [rsp+0x30]
000078e5533db349  vmovaps xmm4, [rsp+0x40]
000078e5533db34f  vmovaps xmm5, [rsp+0x50]
000078e5533db355  vmovaps xmm6, [rsp+0x60]
000078e5533db35b  vmovaps xmm7, [rsp+0x70]
000078e5533db361  vmovaps xmm8, [rsp+0x80]
000078e5533db36a  vmovaps xmm10, [rsp+0x90]
000078e5533db373  vmovaps xmm11, [rsp+0xA0]
000078e5533db37c  vmovaps xmm12, [rsp+0xB0]
000078e5533db385  vmovaps xmm13, [rsp+0xC0]
000078e5533db38e  vmovaps xmm14, [rsp+0xD0]
000078e5533db397  vmovaps xmm15, [rsp+0xE0]
000078e5533db3a0  add rsp, 0xF0
000078e5533db3a7  pop r11
000078e5533db3a9  pop r10
000078e5533db3ab  pop r9
000078e5533db3ad  pop r8
000078e5533db3af  pop rsi
000078e5533db3b0  pop rdi
000078e5533db3b1  pop rdx
000078e5533db3b2  pop rcx
000078e5533db3b3  pop rax
000078e5533db3b4  add rsp, 0x08
000078e5533db3b8  jmp 0x000078E5533D662F
000078e5533db3bd  sub rsp, 0x08
000078e5533db3c1  push rax
000078e5533db3c2  push rcx
000078e5533db3c3  push rdx
000078e5533db3c4  push rdi
000078e5533db3c5  push rsi
000078e5533db3c6  push r8
000078e5533db3c8  push r9
000078e5533db3ca  push r10
000078e5533db3cc  push r11
000078e5533db3ce  sub rsp, 0xF0
000078e5533db3d5  vmovaps [rsp], xmm0
000078e5533db3da  vmovaps [rsp+0x10], xmm1
000078e5533db3e0  vmovaps [rsp+0x20], xmm2
000078e5533db3e6  vmovaps [rsp+0x30], xmm3
000078e5533db3ec  vmovaps [rsp+0x40], xmm4
000078e5533db3f2  vmovaps [rsp+0x50], xmm5
000078e5533db3f8  vmovaps [rsp+0x60], xmm6
000078e5533db3fe  vmovaps [rsp+0x70], xmm7
000078e5533db404  vmovaps [rsp+0x80], xmm8
000078e5533db40d  vmovaps [rsp+0x90], xmm9
000078e5533db416  vmovaps [rsp+0xA0], xmm10
000078e5533db41f  vmovaps [rsp+0xB0], xmm11
000078e5533db428  vmovaps [rsp+0xC0], xmm12
000078e5533db431  vmovaps [rsp+0xD0], xmm13
000078e5533db43a  vmovaps [rsp+0xE0], xmm14
000078e5533db443  sub rsp, 0x30
000078e5533db447  movaps [rsp], xmm15
000078e5533db44c  movaps [rsp+0x10], xmm11
000078e5533db452  movaps [rsp+0x20], xmm12
000078e5533db458  lea rdi, [rsp]
000078e5533db45c  mov esi, 0x00
000078e5533db461  mov rax, 0x5F83D5E17530
000078e5533db46b  call rax
000078e5533db46d  movaps xmm15, [rsp]
000078e5533db472  add rsp, 0x30
000078e5533db476  vmovaps xmm0, [rsp]
000078e5533db47b  vmovaps xmm1, [rsp+0x10]
000078e5533db481  vmovaps xmm2, [rsp+0x20]
000078e5533db487  vmovaps xmm3, [rsp+0x30]
000078e5533db48d  vmovaps xmm4, [rsp+0x40]
000078e5533db493  vmovaps xmm5, [rsp+0x50]
000078e5533db499  vmovaps xmm6, [rsp+0x60]
000078e5533db49f  vmovaps xmm7, [rsp+0x70]
000078e5533db4a5  vmovaps xmm8, [rsp+0x80]
000078e5533db4ae  vmovaps xmm9, [rsp+0x90]
000078e5533db4b7  vmovaps xmm10, [rsp+0xA0]
000078e5533db4c0  vmovaps xmm11, [rsp+0xB0]
000078e5533db4c9  vmovaps xmm12, [rsp+0xC0]
000078e5533db4d2  vmovaps xmm13, [rsp+0xD0]
000078e5533db4db  vmovaps xmm14, [rsp+0xE0]
000078e5533db4e4  add rsp, 0xF0
000078e5533db4eb  pop r11
000078e5533db4ed  pop r10
000078e5533db4ef  pop r9
000078e5533db4f1  pop r8
000078e5533db4f3  pop rsi
000078e5533db4f4  pop rdi
000078e5533db4f5  pop rdx
000078e5533db4f6  pop rcx
000078e5533db4f7  pop rax
000078e5533db4f8  add rsp, 0x08
000078e5533db4fc  jmp 0x000078E5533D664A
000078e5533db501  sub rsp, 0x08
000078e5533db505  push rax
000078e5533db506  push rcx
000078e5533db507  push rdx
000078e5533db508  push rdi
000078e5533db509  push rsi
000078e5533db50a  push r8
000078e5533db50c  push r9
000078e5533db50e  push r10
000078e5533db510  push r11
000078e5533db512  sub rsp, 0xF0
000078e5533db519  vmovaps [rsp], xmm0
000078e5533db51e  vmovaps [rsp+0x10], xmm1
000078e5533db524  vmovaps [rsp+0x20], xmm2
000078e5533db52a  vmovaps [rsp+0x30], xmm3
000078e5533db530  vmovaps [rsp+0x40], xmm4
000078e5533db536  vmovaps [rsp+0x50], xmm5
000078e5533db53c  vmovaps [rsp+0x60], xmm6
000078e5533db542  vmovaps [rsp+0x70], xmm7
000078e5533db548  vmovaps [rsp+0x80], xmm8
000078e5533db551  vmovaps [rsp+0x90], xmm9
000078e5533db55a  vmovaps [rsp+0xA0], xmm10
000078e5533db563  vmovaps [rsp+0xB0], xmm11
000078e5533db56c  vmovaps [rsp+0xC0], xmm12
000078e5533db575  vmovaps [rsp+0xD0], xmm14
000078e5533db57e  vmovaps [rsp+0xE0], xmm15
000078e5533db587  sub rsp, 0x30
000078e5533db58b  movaps [rsp], xmm13
000078e5533db590  movaps [rsp+0x10], xmm10
000078e5533db596  movaps [rsp+0x20], xmm14
000078e5533db59c  lea rdi, [rsp]
000078e5533db5a0  mov esi, 0x00
000078e5533db5a5  mov rax, 0x5F83D5E17530
000078e5533db5af  call rax
000078e5533db5b1  movaps xmm13, [rsp]
000078e5533db5b6  add rsp, 0x30
000078e5533db5ba  vmovaps xmm0, [rsp]
000078e5533db5bf  vmovaps xmm1, [rsp+0x10]
000078e5533db5c5  vmovaps xmm2, [rsp+0x20]
000078e5533db5cb  vmovaps xmm3, [rsp+0x30]
000078e5533db5d1  vmovaps xmm4, [rsp+0x40]
000078e5533db5d7  vmovaps xmm5, [rsp+0x50]
000078e5533db5dd  vmovaps xmm6, [rsp+0x60]
000078e5533db5e3  vmovaps xmm7, [rsp+0x70]
000078e5533db5e9  vmovaps xmm8, [rsp+0x80]
000078e5533db5f2  vmovaps xmm9, [rsp+0x90]
000078e5533db5fb  vmovaps xmm10, [rsp+0xA0]
000078e5533db604  vmovaps xmm11, [rsp+0xB0]
000078e5533db60d  vmovaps xmm12, [rsp+0xC0]
000078e5533db616  vmovaps xmm14, [rsp+0xD0]
000078e5533db61f  vmovaps xmm15, [rsp+0xE0]
000078e5533db628  add rsp, 0xF0
000078e5533db62f  pop r11
000078e5533db631  pop r10
000078e5533db633  pop r9
000078e5533db635  pop r8
000078e5533db637  pop rsi
000078e5533db638  pop rdi
000078e5533db639  pop rdx
000078e5533db63a  pop rcx
000078e5533db63b  pop rax
000078e5533db63c  add rsp, 0x08
000078e5533db640  jmp 0x000078E5533D666D
000078e5533db645  sub rsp, 0x08
000078e5533db649  push rax
000078e5533db64a  push rcx
000078e5533db64b  push rdx
000078e5533db64c  push rdi
000078e5533db64d  push rsi
000078e5533db64e  push r8
000078e5533db650  push r9
000078e5533db652  push r10
000078e5533db654  push r11
000078e5533db656  sub rsp, 0xF0
000078e5533db65d  vmovaps [rsp], xmm0
000078e5533db662  vmovaps [rsp+0x10], xmm1
000078e5533db668  vmovaps [rsp+0x20], xmm2
000078e5533db66e  vmovaps [rsp+0x30], xmm3
000078e5533db674  vmovaps [rsp+0x40], xmm4
000078e5533db67a  vmovaps [rsp+0x50], xmm5
000078e5533db680  vmovaps [rsp+0x60], xmm6
000078e5533db686  vmovaps [rsp+0x70], xmm7
000078e5533db68c  vmovaps [rsp+0x80], xmm8
000078e5533db695  vmovaps [rsp+0x90], xmm9
000078e5533db69e  vmovaps [rsp+0xA0], xmm10
000078e5533db6a7  vmovaps [rsp+0xB0], xmm11
000078e5533db6b0  vmovaps [rsp+0xC0], xmm12
000078e5533db6b9  vmovaps [rsp+0xD0], xmm13
000078e5533db6c2  vmovaps [rsp+0xE0], xmm15
000078e5533db6cb  sub rsp, 0x30
000078e5533db6cf  movaps [rsp], xmm14
000078e5533db6d4  movaps [rsp+0x10], xmm1
000078e5533db6d9  movaps [rsp+0x20], xmm7
000078e5533db6de  lea rdi, [rsp]
000078e5533db6e2  mov esi, 0x00
000078e5533db6e7  mov rax, 0x5F83D5E17530
000078e5533db6f1  call rax
000078e5533db6f3  movaps xmm14, [rsp]
000078e5533db6f8  add rsp, 0x30
000078e5533db6fc  vmovaps xmm0, [rsp]
000078e5533db701  vmovaps xmm1, [rsp+0x10]
000078e5533db707  vmovaps xmm2, [rsp+0x20]
000078e5533db70d  vmovaps xmm3, [rsp+0x30]
000078e5533db713  vmovaps xmm4, [rsp+0x40]
000078e5533db719  vmovaps xmm5, [rsp+0x50]
000078e5533db71f  vmovaps xmm6, [rsp+0x60]
000078e5533db725  vmovaps xmm7, [rsp+0x70]
000078e5533db72b  vmovaps xmm8, [rsp+0x80]
000078e5533db734  vmovaps xmm9, [rsp+0x90]
000078e5533db73d  vmovaps xmm10, [rsp+0xA0]
000078e5533db746  vmovaps xmm11, [rsp+0xB0]
000078e5533db74f  vmovaps xmm12, [rsp+0xC0]
000078e5533db758  vmovaps xmm13, [rsp+0xD0]
000078e5533db761  vmovaps xmm15, [rsp+0xE0]
000078e5533db76a  add rsp, 0xF0
000078e5533db771  pop r11
000078e5533db773  pop r10
000078e5533db775  pop r9
000078e5533db777  pop r8
000078e5533db779  pop rsi
000078e5533db77a  pop rdi
000078e5533db77b  pop rdx
000078e5533db77c  pop rcx
000078e5533db77d  pop rax
000078e5533db77e  add rsp, 0x08
000078e5533db782  jmp 0x000078E5533D6690
000078e5533db787  sub rsp, 0x08
000078e5533db78b  push rax
000078e5533db78c  push rcx
000078e5533db78d  push rdx
000078e5533db78e  push rdi
000078e5533db78f  push rsi
000078e5533db790  push r8
000078e5533db792  push r9
000078e5533db794  push r10
000078e5533db796  push r11
000078e5533db798  sub rsp, 0xF0
000078e5533db79f  vmovaps [rsp], xmm0
000078e5533db7a4  vmovaps [rsp+0x10], xmm2
000078e5533db7aa  vmovaps [rsp+0x20], xmm3
000078e5533db7b0  vmovaps [rsp+0x30], xmm4
000078e5533db7b6  vmovaps [rsp+0x40], xmm5
000078e5533db7bc  vmovaps [rsp+0x50], xmm6
000078e5533db7c2  vmovaps [rsp+0x60], xmm7
000078e5533db7c8  vmovaps [rsp+0x70], xmm8
000078e5533db7ce  vmovaps [rsp+0x80], xmm9
000078e5533db7d7  vmovaps [rsp+0x90], xmm10
000078e5533db7e0  vmovaps [rsp+0xA0], xmm11
000078e5533db7e9  vmovaps [rsp+0xB0], xmm12
000078e5533db7f2  vmovaps [rsp+0xC0], xmm13
000078e5533db7fb  vmovaps [rsp+0xD0], xmm14
000078e5533db804  vmovaps [rsp+0xE0], xmm15
000078e5533db80d  sub rsp, 0x30
000078e5533db811  movaps [rsp], xmm1
000078e5533db815  movaps [rsp+0x10], xmm8
000078e5533db81b  movaps [rsp+0x20], xmm9
000078e5533db821  lea rdi, [rsp]
000078e5533db825  mov esi, 0x00
000078e5533db82a  mov rax, 0x5F83D5E17530
000078e5533db834  call rax
000078e5533db836  movaps xmm1, [rsp]
000078e5533db83a  add rsp, 0x30
000078e5533db83e  vmovaps xmm0, [rsp]
000078e5533db843  vmovaps xmm2, [rsp+0x10]
000078e5533db849  vmovaps xmm3, [rsp+0x20]
000078e5533db84f  vmovaps xmm4, [rsp+0x30]
000078e5533db855  vmovaps xmm5, [rsp+0x40]
000078e5533db85b  vmovaps xmm6, [rsp+0x50]
000078e5533db861  vmovaps xmm7, [rsp+0x60]
000078e5533db867  vmovaps xmm8, [rsp+0x70]
000078e5533db86d  vmovaps xmm9, [rsp+0x80]
000078e5533db876  vmovaps xmm10, [rsp+0x90]
000078e5533db87f  vmovaps xmm11, [rsp+0xA0]
000078e5533db888  vmovaps xmm12, [rsp+0xB0]
000078e5533db891  vmovaps xmm13, [rsp+0xC0]
000078e5533db89a  vmovaps xmm14, [rsp+0xD0]
000078e5533db8a3  vmovaps xmm15, [rsp+0xE0]
000078e5533db8ac  add rsp, 0xF0
000078e5533db8b3  pop r11
000078e5533db8b5  pop r10
000078e5533db8b7  pop r9
000078e5533db8b9  pop r8
000078e5533db8bb  pop rsi
000078e5533db8bc  pop rdi
000078e5533db8bd  pop rdx
000078e5533db8be  pop rcx
000078e5533db8bf  pop rax
000078e5533db8c0  add rsp, 0x08
000078e5533db8c4  jmp 0x000078E5533D66B2
000078e5533db8c9  call 0x000078E5532B3E40
000078e5533db8ce  jmp 0x000078E5533D66C0
000078e5533db8d3  call 0x000078E55320C380
000078e5533db8d8  jmp 0x000078E5533D66CA
000078e5533db8dd  call 0x000078E55320D600
000078e5533db8e2  jmp 0x000078E5533D66D4
000078e5533db8e7  call 0x000078E5531FF540
000078e5533db8ec  jmp 0x000078E5533D66DE
000078e5533db8f1  int3
000078e5533db8f2  nop [rax+rax*1], ax
000078e5533db8fb  nop [rax+rax*1], eax
000078e5533db900  mov eax, [r15+0x48]
000078e5533db904  lea r14d, [eax+0x01]
000078e5533db909  mov [rsp+0x10], r14d
000078e5533db90e  mov r14d, r14d
000078e5533db911  mov [r15+0x48], r14
000078e5533db915  xor eax, eax
000078e5533db917  mov r14d, [rsp+0x10]
000078e5533db91c  cmp r14d, 0x1F4
000078e5533db923  cmc
000078e5533db924  lahf
000078e5533db925  seto al
000078e5533db928  mov [r15+0x108], eax
000078e5533db92f  mov eax, [r15+0x108]
000078e5533db936  sahf
000078e5533db937  jnz 0x000078E5533DB969
000078e5533db939  cmp dword ptr [r15+0x318], 0x00
000078e5533db941  jz 0x000078E5533E1AB0
000078e5533db947  nop [rax+rax*1], ax
000078e5533db950  nop [rax+rax*1], eax
000078e5533db958  mov eax, 0x410450
000078e5533db95d  mov [r15+0x100], rax
000078e5533db964  jmp 0x000078E5531FE110
000078e5533db969  cmp dword ptr [r15+0x318], 0x00
000078e5533db971  jz 0x000078E5533DB9A0
000078e5533db977  nop [rax+rax*1], ax
000078e5533db980  nop [rax+rax*1], eax
000078e5533db988  mov eax, 0x410274
000078e5533db98d  mov [r15+0x100], rax
000078e5533db994  jmp 0x000078E5531FE110
000078e5533db999  int3
000078e5533db99a  int3
000078e5533db99b  nop [rax+rax*1], eax
000078e5533db9a0  mov rax, [r15+0x40]
000078e5533db9a4  movaps xmm1, [r15+0x1D0]
000078e5533db9ac  vmovaps [rsp+0x10], xmm1
000078e5533db9b2  vmovaps xmm15, [rsp+0x10]
000078e5533db9b8  por xmm1, xmm15
000078e5533db9bd  movaps xmm14, [r15+0x1A0]
000078e5533db9c5  vmovaps [rsp+0x10], xmm14
000078e5533db9cb  vmovaps xmm13, [rsp+0x10]
000078e5533db9d1  por xmm14, xmm13
000078e5533db9d6  lea r14, [rax+0x30]
000078e5533db9da  mov r12, [r13+r14*1]
000078e5533db9df  lea r14, [rax+0x38]
000078e5533db9e3  mov r11, [r13+r14*1]
000078e5533db9e8  movq xmm13, r12
000078e5533db9ed  movq xmm12, r11
000078e5533db9f2  movq xmm13, xmm13
000078e5533db9f7  vmovaps [rsp+0x10], xmm13
000078e5533db9fd  movq xmm13, xmm13
000078e5533dba02  movaps [r15+0x130], xmm13
000078e5533dba0a  movq xmm12, xmm12
000078e5533dba0f  vmovaps [rsp+0x20], xmm12
000078e5533dba15  movq xmm12, xmm12
000078e5533dba1a  movaps [r15+0x280], xmm12
000078e5533dba22  movaps xmm13, [r15+0x270]
000078e5533dba2a  vmovaps [rsp+0x30], xmm13
000078e5533dba30  vmovaps xmm12, [rsp+0x30]
000078e5533dba36  por xmm13, xmm12
000078e5533dba3b  lea r14, [rax+0x20]
000078e5533dba3f  mov r12, [r13+r14*1]
000078e5533dba44  lea r14, [rax+0x28]
000078e5533dba48  mov r11, [r13+r14*1]
000078e5533dba4d  movq xmm12, r12
000078e5533dba52  movq xmm11, r11
000078e5533dba57  movq xmm12, xmm12
000078e5533dba5c  vmovaps [rsp+0x30], xmm12
000078e5533dba62  movq xmm12, xmm12
000078e5533dba67  movaps [r15+0x150], xmm12
000078e5533dba6f  movq xmm11, xmm11
000078e5533dba74  vmovaps [rsp+0x40], xmm11
000078e5533dba7a  movq xmm11, xmm11
000078e5533dba7f  movaps [r15+0x140], xmm11
000078e5533dba87  lea r14, [rax+0x10]
000078e5533dba8b  mov r12, [r13+r14*1]
000078e5533dba90  lea r14, [rax+0x18]
000078e5533dba94  mov r11, [r13+r14*1]
000078e5533dba99  movq xmm12, r12
000078e5533dba9e  movq xmm11, r11
000078e5533dbaa3  movq xmm12, xmm12
000078e5533dbaa8  vmovaps [rsp+0x50], xmm12
000078e5533dbaae  movq xmm12, xmm12
000078e5533dbab3  movaps [r15+0x170], xmm12
000078e5533dbabb  movq xmm11, xmm11
000078e5533dbac0  vmovaps [rsp+0x60], xmm11
000078e5533dbac6  movq xmm11, xmm11
000078e5533dbacb  movaps [r15+0x160], xmm11
000078e5533dbad3  mov r14, [r13+rax*1]
000078e5533dbad8  vmovq xmm12, r14
000078e5533dbadd  vpbroadcastq xmm12, xmm12
000078e5533dbae2  lea r14, [rax+0x08]
000078e5533dbae6  mov rax, [r13+r14*1]
000078e5533dbaeb  movq xmm11, rax
000078e5533dbaf0  movaps [r15+0x230], xmm11
000078e5533dbaf8  mov rax, [r15+0xF8]
000078e5533dbaff  lea r14, [rax+0x50]
000078e5533dbb03  movups xmm11, [r13+r14*1]
000078e5533dbb09  lea r14, [rax+0x60]
000078e5533dbb0d  movups xmm10, [r13+r14*1]
000078e5533dbb13  lea r14, [rax+0x30]
000078e5533dbb17  movups xmm9, [r13+r14*1]
000078e5533dbb1d  mov r14, [r15+0x50]
000078e5533dbb21  mov [r15+0x60], r14
000078e5533dbb25  mov qword ptr [r15+0x58], 0x40
000078e5533dbb2d  movaps xmm8, xmm12
000078e5533dbb31  mulpd xmm8, xmm15
000078e5533dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000078e5533dbb3c  ptest xmm7, xmm7
000078e5533dbb41  jnz 0x000078E5533DC96A
000078e5533dbb47  movq xmm15, qword ptr [r15+0x230]
000078e5533dbb50  vmovaps [rsp+0x70], xmm15
000078e5533dbb56  vpermilpd xmm15, xmm15, 0x00
000078e5533dbb5c  movaps xmm7, xmm9
000078e5533dbb60  mulpd xmm7, xmm15
000078e5533dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000078e5533dbb6a  ptest xmm6, xmm6
000078e5533dbb6f  jnz 0x000078E5533DCAAE
000078e5533dbb75  vxorps xmm15, xmm15, xmm15
000078e5533dbb7a  vpbroadcastq xmm15, xmm15
000078e5533dbb7f  movaps xmm9, xmm12
000078e5533dbb83  mulpd xmm9, xmm10
000078e5533dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000078e5533dbb8e  ptest xmm6, xmm6
000078e5533dbb93  jnz 0x000078E5533DCBF0
000078e5533dbb99  movaps xmm10, xmm12
000078e5533dbb9d  mulpd xmm10, xmm11
000078e5533dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000078e5533dbba8  ptest xmm6, xmm6
000078e5533dbbad  jnz 0x000078E5533DCD34
000078e5533dbbb3  movaps xmm11, [r15+0x1F0]
000078e5533dbbbb  movaps xmm6, xmm12
000078e5533dbbbf  mulpd xmm6, xmm11
000078e5533dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000078e5533dbbc9  ptest xmm5, xmm5
000078e5533dbbce  jnz 0x000078E5533DCE78
000078e5533dbbd4  movaps xmm12, [r15+0x2A0]
000078e5533dbbdc  vmovaps [rsp+0x80], xmm12
000078e5533dbbe5  vmovaps xmm11, [rsp+0x80]
000078e5533dbbee  por xmm12, xmm11
000078e5533dbbf3  movaps xmm11, [r15+0x250]
000078e5533dbbfb  vmovaps [rsp+0x80], xmm11
000078e5533dbc04  vmovaps xmm5, [rsp+0x80]
000078e5533dbc0d  por xmm11, xmm5
000078e5533dbc12  vmovaps xmm4, [rsp+0x70]
000078e5533dbc18  vpermilpd xmm4, xmm4, 0x00
000078e5533dbc1e  movaps xmm3, xmm5
000078e5533dbc21  mulpd xmm3, xmm4
000078e5533dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000078e5533dbc2a  ptest xmm2, xmm2
000078e5533dbc2f  jnz 0x000078E5533DCFBA
000078e5533dbc35  mov [rsp+0x80], rax
000078e5533dbc3d  xor eax, eax
000078e5533dbc3f  mov r12d, 0x40
000078e5533dbc45  mov r11d, 0x200
000078e5533dbc4b  cmp r12, r11
000078e5533dbc4e  cmc
000078e5533dbc4f  lahf
000078e5533dbc50  seto al
000078e5533dbc53  mov [r15+0x108], eax
000078e5533dbc5a  movaps xmm5, xmm8
000078e5533dbc5e  addpd xmm5, xmm15
000078e5533dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000078e5533dbc68  ptest xmm4, xmm4
000078e5533dbc6d  jnz 0x000078E5533DD0FA
000078e5533dbc73  movaps xmm8, [r15+0x1B0]
000078e5533dbc7b  movaps xmm4, xmm9
000078e5533dbc7f  addpd xmm4, xmm8
000078e5533dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000078e5533dbc89  ptest xmm2, xmm2
000078e5533dbc8e  jnz 0x000078E5533DD23C
000078e5533dbc94  movaps xmm9, xmm10
000078e5533dbc98  addpd xmm9, xmm8
000078e5533dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000078e5533dbca3  ptest xmm2, xmm2
000078e5533dbca8  jnz 0x000078E5533DD37E
000078e5533dbcae  movaps xmm10, [r15+0x2F0]
000078e5533dbcb6  vmovaps [rsp+0x90], xmm10
000078e5533dbcbf  vmovaps xmm8, [rsp+0x90]
000078e5533dbcc8  por xmm10, xmm8
000078e5533dbccd  movaps xmm8, [r15+0x2E0]
000078e5533dbcd5  vmovaps [rsp+0x90], xmm8
000078e5533dbcde  vmovaps xmm2, [rsp+0x90]
000078e5533dbce7  por xmm8, xmm2
000078e5533dbcec  movaps xmm2, [r15+0x2D0]
000078e5533dbcf4  vmovaps [rsp+0x90], xmm2
000078e5533dbcfd  vmovaps [rsp+0xA0], xmm1
000078e5533dbd06  vmovaps xmm1, [rsp+0x90]
000078e5533dbd0f  por xmm2, xmm1
000078e5533dbd13  movaps xmm1, [r15+0x200]
000078e5533dbd1b  vmovaps [rsp+0x90], xmm1
000078e5533dbd24  vmovaps [rsp+0xB0], xmm15
000078e5533dbd2d  vmovaps xmm15, [rsp+0x90]
000078e5533dbd36  por xmm1, xmm15
000078e5533dbd3b  movaps xmm15, [r15+0x1C0]
000078e5533dbd43  vmovaps [rsp+0x90], xmm15
000078e5533dbd4c  vmovaps [rsp+0xC0], xmm1
000078e5533dbd55  vmovaps xmm1, [rsp+0x90]
000078e5533dbd5e  por xmm15, xmm1
000078e5533dbd63  movaps xmm1, [r15+0x190]
000078e5533dbd6b  vmovaps [rsp+0x90], xmm1
000078e5533dbd74  vmovaps [rsp+0xD0], xmm15
000078e5533dbd7d  vmovaps xmm15, [rsp+0x90]
000078e5533dbd86  por xmm1, xmm15
000078e5533dbd8b  movaps xmm15, [r15+0x300]
000078e5533dbd93  vmovaps [rsp+0x90], xmm15
000078e5533dbd9c  vmovaps [rsp+0xE0], xmm1
000078e5533dbda5  vmovaps xmm1, [rsp+0x90]
000078e5533dbdae  por xmm15, xmm1
000078e5533dbdb3  mov rax, [rsp+0x80]
000078e5533dbdbb  lea r12, [rax+0xA0]
000078e5533dbdc2  movups xmm1, [r13+r12*1]
000078e5533dbdc8  lea r12, [rax+0xB0]
000078e5533dbdcf  vmovaps [rsp+0x80], xmm1
000078e5533dbdd8  movups xmm1, [r13+r12*1]
000078e5533dbdde  vmovaps [rsp+0x90], xmm1
000078e5533dbde7  vmovaps [rsp+0xF0], xmm15
000078e5533dbdf0  vmovaps xmm15, [rsp+0xB0]
000078e5533dbdf9  vmovaps [rsp+0xB0], xmm14
000078e5533dbe02  movaps xmm1, xmm6
000078e5533dbe05  addpd xmm1, xmm15
000078e5533dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000078e5533dbe0f  ptest xmm14, xmm14
000078e5533dbe15  jnz 0x000078E5533DD4D6
000078e5533dbe1b  lea r12, [rax+0xF0]
000078e5533dbe22  movups xmm15, [r13+r12*1]
000078e5533dbe28  movaps xmm14, xmm4
000078e5533dbe2c  addpd xmm14, xmm3
000078e5533dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000078e5533dbe37  ptest xmm6, xmm6
000078e5533dbe3c  jnz 0x000078E5533DD621
000078e5533dbe42  movaps xmm6, xmm9
000078e5533dbe46  addpd xmm6, xmm7
000078e5533dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000078e5533dbe4f  ptest xmm4, xmm4
000078e5533dbe54  jnz 0x000078E5533DD763
000078e5533dbe5a  vmovaps xmm9, [rsp+0x70]
000078e5533dbe60  vpermilpd xmm9, xmm9, 0x00
000078e5533dbe66  vmovaps xmm4, [rsp+0x90]
000078e5533dbe6f  movaps xmm7, xmm4
000078e5533dbe72  mulpd xmm7, xmm9
000078e5533dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000078e5533dbe7c  ptest xmm3, xmm3
000078e5533dbe81  jnz 0x000078E5533DD8A4
000078e5533dbe87  vmovaps xmm9, [rsp+0x50]
000078e5533dbe8d  vpermilpd xmm9, xmm9, 0x00
000078e5533dbe93  movaps xmm4, xmm15
000078e5533dbe97  mulpd xmm4, xmm9
000078e5533dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000078e5533dbea1  ptest xmm3, xmm3
000078e5533dbea6  jnz 0x000078E5533DD9E5
000078e5533dbeac  lea r12, [rax+0xE0]
000078e5533dbeb3  movups xmm15, [r13+r12*1]
000078e5533dbeb9  vmovaps xmm9, [rsp+0x70]
000078e5533dbebf  vpermilpd xmm9, xmm9, 0x00
000078e5533dbec5  vmovaps [rsp+0x70], xmm1
000078e5533dbecb  vmovaps xmm1, [rsp+0x80]
000078e5533dbed4  vmovaps [rsp+0x80], xmm15
000078e5533dbedd  movaps xmm3, xmm1
000078e5533dbee0  mulpd xmm3, xmm9
000078e5533dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000078e5533dbeea  ptest xmm15, xmm15
000078e5533dbef0  jnz 0x000078E5533DDB31
000078e5533dbef6  vmovaps xmm1, [rsp+0xF0]
000078e5533dbeff  vmovaps xmm15, [rsp+0xF0]
000078e5533dbf08  por xmm1, xmm15
000078e5533dbf0d  movaps [r15+0x300], xmm1
000078e5533dbf15  vmovaps xmm15, [rsp+0xE0]
000078e5533dbf1e  vmovaps xmm9, [rsp+0xE0]
000078e5533dbf27  por xmm15, xmm9
000078e5533dbf2c  movaps [r15+0x190], xmm15
000078e5533dbf34  vmovaps xmm9, [rsp+0x50]
000078e5533dbf3a  vpermilpd xmm9, xmm9, 0x00
000078e5533dbf40  vmovaps [rsp+0x90], xmm1
000078e5533dbf49  vmovaps [rsp+0xE0], xmm15
000078e5533dbf52  vmovaps xmm15, [rsp+0x80]
000078e5533dbf5b  vmovaps [rsp+0x80], xmm14
000078e5533dbf64  movaps xmm1, xmm15
000078e5533dbf68  mulpd xmm1, xmm9
000078e5533dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000078e5533dbf72  ptest xmm14, xmm14
000078e5533dbf78  jnz 0x000078E5533DDC72
000078e5533dbf7e  lea r12, [rax+0x90]
000078e5533dbf85  movups xmm15, [r13+r12*1]
000078e5533dbf8b  vmovaps xmm14, [rsp+0xD0]
000078e5533dbf94  vmovaps xmm9, [rsp+0xD0]
000078e5533dbf9d  por xmm14, xmm9
000078e5533dbfa2  movaps [r15+0x1C0], xmm14
000078e5533dbfaa  vmovaps xmm9, [rsp+0xC0]
000078e5533dbfb3  vmovaps [rsp+0xD0], xmm1
000078e5533dbfbc  vmovaps xmm1, [rsp+0xC0]
000078e5533dbfc5  por xmm9, xmm1
000078e5533dbfca  movaps [r15+0x200], xmm9
000078e5533dbfd2  vmovaps [rsp+0xC0], xmm2
000078e5533dbfdb  vmovaps xmm1, [rsp+0xC0]
000078e5533dbfe4  por xmm2, xmm1
000078e5533dbfe8  movaps [r15+0x2D0], xmm2
000078e5533dbff0  vmovaps [rsp+0xC0], xmm8
000078e5533dbff9  vmovaps xmm1, [rsp+0xC0]
000078e5533dc002  por xmm8, xmm1
000078e5533dc007  movaps [r15+0x2E0], xmm8
000078e5533dc00f  vmovaps [rsp+0xC0], xmm15
000078e5533dc018  movaps xmm1, xmm5
000078e5533dc01b  addpd xmm1, xmm7
000078e5533dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000078e5533dc024  ptest xmm15, xmm15
000078e5533dc02a  jnz 0x000078E5533DDDBE
000078e5533dc030  vmovaps xmm15, [rsp+0x50]
000078e5533dc036  vpermilpd xmm15, xmm15, 0x00
000078e5533dc03c  vmovaps xmm5, [rsp+0xC0]
000078e5533dc045  vmovaps [rsp+0xC0], xmm1
000078e5533dc04e  movaps xmm7, xmm5
000078e5533dc051  mulpd xmm7, xmm15
000078e5533dc056  vcmppd xmm1, xmm7, xmm7, 0x03
000078e5533dc05b  ptest xmm1, xmm1
000078e5533dc060  jnz 0x000078E5533DDEFE
000078e5533dc066  lea r12, [rax+0x80]
000078e5533dc06d  movups xmm1, [r13+r12*1]
000078e5533dc073  vmovaps xmm5, [rsp+0x70]
000078e5533dc079  vmovaps [rsp+0x70], xmm1
000078e5533dc07f  movaps xmm15, xmm5
000078e5533dc083  addpd xmm15, xmm3
000078e5533dc088  vcmppd xmm1, xmm15, xmm15, 0x03
000078e5533dc08e  ptest xmm1, xmm1
000078e5533dc093  jnz 0x000078E5533DE049
000078e5533dc099  vmovaps xmm5, [rsp+0x80]
000078e5533dc0a2  movaps xmm1, xmm5
000078e5533dc0a5  addpd xmm1, xmm4
000078e5533dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000078e5533dc0ae  ptest xmm3, xmm3
000078e5533dc0b3  jnz 0x000078E5533DE18B
000078e5533dc0b9  vmovaps [rsp+0x80], xmm10
000078e5533dc0c2  vmovaps xmm5, [rsp+0x80]
000078e5533dc0cb  por xmm10, xmm5
000078e5533dc0d0  movaps [r15+0x2F0], xmm10
000078e5533dc0d8  vmovaps xmm5, [rsp+0x50]
000078e5533dc0de  vpermilpd xmm5, xmm5, 0x00
000078e5533dc0e4  vmovaps xmm3, [rsp+0x70]
000078e5533dc0ea  vmovaps [rsp+0x50], xmm1
000078e5533dc0f0  movaps xmm4, xmm3
000078e5533dc0f3  mulpd xmm4, xmm5
000078e5533dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000078e5533dc0fc  ptest xmm1, xmm1
000078e5533dc101  jnz 0x000078E5533DE2CB
000078e5533dc107  lea r12, [rax+0xD0]
000078e5533dc10e  movups xmm1, [r13+r12*1]
000078e5533dc114  vmovaps xmm3, [rsp+0xD0]
000078e5533dc11d  vmovaps [rsp+0x70], xmm1
000078e5533dc123  movaps xmm5, xmm6
000078e5533dc126  addpd xmm5, xmm3
000078e5533dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000078e5533dc12f  ptest xmm1, xmm1
000078e5533dc134  jnz 0x000078E5533DE415
000078e5533dc13a  vmovaps xmm1, [rsp+0x60]
000078e5533dc140  vpermilpd xmm1, xmm1, 0x00
000078e5533dc146  movaps xmm6, xmm9
000078e5533dc14a  mulpd xmm6, xmm1
000078e5533dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000078e5533dc153  ptest xmm3, xmm3
000078e5533dc158  jnz 0x000078E5533DE555
000078e5533dc15e  movaps [r15+0x260], xmm6
000078e5533dc166  vxorps xmm1, xmm1, xmm1
000078e5533dc16a  vpbroadcastq xmm1, xmm1
000078e5533dc16f  movaps [r15+0x1B0], xmm1
000078e5533dc177  vmovaps xmm1, [rsp+0x60]
000078e5533dc17d  vpermilpd xmm1, xmm1, 0x00
000078e5533dc183  vmovaps xmm3, [rsp+0x70]
000078e5533dc189  vmovaps [rsp+0x70], xmm15
000078e5533dc18f  movaps xmm9, xmm3
000078e5533dc193  mulpd xmm9, xmm1
000078e5533dc198  vcmppd xmm15, xmm9, xmm9, 0x03
000078e5533dc19e  ptest xmm15, xmm15
000078e5533dc1a4  jnz 0x000078E5533DE696
000078e5533dc1aa  lea r12, [rax+0xC0]
000078e5533dc1b1  movups xmm1, [r13+r12*1]
000078e5533dc1b7  vmovaps xmm3, [rsp+0xC0]
000078e5533dc1c0  vmovaps [rsp+0x80], xmm1
000078e5533dc1c9  movaps xmm15, xmm3
000078e5533dc1cd  addpd xmm15, xmm7
000078e5533dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000078e5533dc1d8  ptest xmm1, xmm1
000078e5533dc1dd  jnz 0x000078E5533DE7E2
000078e5533dc1e3  vmovaps [rsp+0xC0], xmm13
000078e5533dc1ec  vmovaps xmm1, [rsp+0xC0]
000078e5533dc1f5  por xmm13, xmm1
000078e5533dc1fa  movaps [r15+0x270], xmm13
000078e5533dc202  vmovaps xmm1, [rsp+0xB0]
000078e5533dc20b  vmovaps xmm7, [rsp+0xB0]
000078e5533dc214  por xmm1, xmm7
000078e5533dc218  movaps [r15+0x1A0], xmm1
000078e5533dc220  vmovaps xmm1, [rsp+0x60]
000078e5533dc226  vpermilpd xmm1, xmm1, 0x00
000078e5533dc22c  vmovaps [rsp+0xB0], xmm1
000078e5533dc235  vmovaps xmm1, [rsp+0x80]
000078e5533dc23e  vmovaps [rsp+0x80], xmm15
000078e5533dc247  vmovaps xmm15, [rsp+0xB0]
000078e5533dc250  vmovaps [rsp+0xB0], xmm14
000078e5533dc259  movaps xmm3, xmm1
000078e5533dc25c  mulpd xmm3, xmm15
000078e5533dc261  vcmppd xmm14, xmm3, xmm3, 0x03
000078e5533dc266  ptest xmm14, xmm14
000078e5533dc26c  jnz 0x000078E5533DE924
000078e5533dc272  lea r12, [rax+0x20]
000078e5533dc276  movups xmm1, [r13+r12*1]
000078e5533dc27c  movaps [r15+0x110], xmm1
000078e5533dc284  vmovaps xmm14, [rsp+0x70]
000078e5533dc28a  vmovaps [rsp+0x70], xmm1
000078e5533dc290  movaps xmm15, xmm14
000078e5533dc294  addpd xmm15, xmm4
000078e5533dc299  vcmppd xmm1, xmm15, xmm15, 0x03
000078e5533dc29f  ptest xmm1, xmm1
000078e5533dc2a4  jnz 0x000078E5533DEA6F
000078e5533dc2aa  vmovaps xmm1, [rsp+0x60]
000078e5533dc2b0  vpermilpd xmm1, xmm1, 0x00
000078e5533dc2b6  movaps xmm14, xmm2
000078e5533dc2ba  mulpd xmm14, xmm1
000078e5533dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000078e5533dc2c5  ptest xmm4, xmm4
000078e5533dc2ca  jnz 0x000078E5533DEBB2
000078e5533dc2d0  vmovaps xmm4, [rsp+0x50]
000078e5533dc2d6  movaps xmm1, xmm4
000078e5533dc2d9  addpd xmm1, xmm9
000078e5533dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000078e5533dc2e3  ptest xmm2, xmm2
000078e5533dc2e8  jnz 0x000078E5533DECF4
000078e5533dc2ee  vmovaps xmm9, [rsp+0x30]
000078e5533dc2f4  vpermilpd xmm9, xmm9, 0x00
000078e5533dc2fa  vmovaps xmm2, [rsp+0x70]
000078e5533dc300  vmovaps [rsp+0x50], xmm1
000078e5533dc306  movaps xmm4, xmm2
000078e5533dc309  mulpd xmm4, xmm9
000078e5533dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000078e5533dc313  ptest xmm1, xmm1
000078e5533dc318  jnz 0x000078E5533DEE35
000078e5533dc31e  vmovaps xmm1, [rsp+0x30]
000078e5533dc324  vpermilpd xmm1, xmm1, 0x00
000078e5533dc32a  vmovaps xmm2, [rsp+0x90]
000078e5533dc333  vmovaps [rsp+0x60], xmm15
000078e5533dc339  movaps xmm9, xmm2
000078e5533dc33d  mulpd xmm9, xmm1
000078e5533dc342  vcmppd xmm15, xmm9, xmm9, 0x03
000078e5533dc348  ptest xmm15, xmm15
000078e5533dc34e  jnz 0x000078E5533DEF76
000078e5533dc354  vmovaps xmm15, [rsp+0x80]
000078e5533dc35d  movaps xmm1, xmm15
000078e5533dc361  addpd xmm1, xmm6
000078e5533dc365  vcmppd xmm2, xmm1, xmm1, 0x03
000078e5533dc36a  ptest xmm2, xmm2
000078e5533dc36f  jnz 0x000078E5533DF0B8
000078e5533dc375  movaps xmm15, xmm5
000078e5533dc379  addpd xmm15, xmm3
000078e5533dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000078e5533dc384  ptest xmm6, xmm6
000078e5533dc389  jnz 0x000078E5533DF1F9
000078e5533dc38f  vmovaps xmm6, [rsp+0x30]
000078e5533dc395  vpermilpd xmm6, xmm6, 0x00
000078e5533dc39b  movaps xmm5, xmm8
000078e5533dc39f  mulpd xmm5, xmm6
000078e5533dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000078e5533dc3a8  ptest xmm3, xmm3
000078e5533dc3ad  jnz 0x000078E5533DF33B
000078e5533dc3b3  vmovaps xmm8, [rsp+0x30]
000078e5533dc3b9  vpermilpd xmm8, xmm8, 0x00
000078e5533dc3bf  movaps xmm6, xmm10
000078e5533dc3c3  mulpd xmm6, xmm8
000078e5533dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000078e5533dc3cd  ptest xmm3, xmm3
000078e5533dc3d2  jnz 0x000078E5533DF47C
000078e5533dc3d8  vmovaps xmm8, [rsp+0x60]
000078e5533dc3de  movaps xmm10, xmm8
000078e5533dc3e2  addpd xmm10, xmm14
000078e5533dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000078e5533dc3ed  ptest xmm3, xmm3
000078e5533dc3f2  jnz 0x000078E5533DF5BE
000078e5533dc3f8  vmovaps xmm8, [rsp+0x50]
000078e5533dc3fe  movaps xmm14, xmm8
000078e5533dc402  addpd xmm14, xmm4
000078e5533dc407  vcmppd xmm3, xmm14, xmm14, 0x03
000078e5533dc40d  ptest xmm3, xmm3
000078e5533dc412  jnz 0x000078E5533DF702
000078e5533dc418  vmovaps xmm8, [rsp+0x40]
000078e5533dc41e  vpermilpd xmm8, xmm8, 0x00
000078e5533dc424  movaps xmm4, xmm13
000078e5533dc428  mulpd xmm4, xmm8
000078e5533dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000078e5533dc432  ptest xmm3, xmm3
000078e5533dc437  jnz 0x000078E5533DF845
000078e5533dc43d  movaps xmm13, xmm15
000078e5533dc441  addpd xmm13, xmm9
000078e5533dc446  vcmppd xmm8, xmm13, xmm13, 0x03
000078e5533dc44c  ptest xmm8, xmm8
000078e5533dc452  jnz 0x000078E5533DF987
000078e5533dc458  movaps xmm15, xmm1
000078e5533dc45c  addpd xmm15, xmm5
000078e5533dc461  vcmppd xmm9, xmm15, xmm15, 0x03
000078e5533dc467  ptest xmm9, xmm9
000078e5533dc46d  jnz 0x000078E5533DFACB
000078e5533dc473  vmovaps [rsp+0x30], xmm11
000078e5533dc479  vmovaps xmm1, [rsp+0x30]
000078e5533dc47f  por xmm11, xmm1
000078e5533dc484  movaps [r15+0x250], xmm11
000078e5533dc48c  vmovaps [rsp+0x30], xmm12
000078e5533dc492  vmovaps xmm1, [rsp+0x30]
000078e5533dc498  por xmm12, xmm1
000078e5533dc49d  movaps [r15+0x2A0], xmm12
000078e5533dc4a5  vmovaps xmm1, [rsp+0xA0]
000078e5533dc4ae  vmovaps xmm11, [rsp+0xA0]
000078e5533dc4b7  por xmm1, xmm11
000078e5533dc4bc  movaps [r15+0x1D0], xmm1
000078e5533dc4c4  lea r12, [rax+0x40]
000078e5533dc4c8  movups xmm1, [r13+r12*1]
000078e5533dc4ce  movaps [r15+0x2C0], xmm1
000078e5533dc4d6  vmovaps xmm11, [rsp+0x40]
000078e5533dc4dc  vpermilpd xmm11, xmm11, 0x00
000078e5533dc4e2  vmovaps xmm8, [rsp+0xE0]
000078e5533dc4eb  movaps xmm9, xmm8
000078e5533dc4ef  mulpd xmm9, xmm11
000078e5533dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000078e5533dc4fa  ptest xmm5, xmm5
000078e5533dc4ff  jnz 0x000078E5533DFC17
000078e5533dc505  movaps xmm11, xmm10
000078e5533dc509  addpd xmm11, xmm6
000078e5533dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000078e5533dc514  ptest xmm8, xmm8
000078e5533dc51a  jnz 0x000078E5533DFD5B
000078e5533dc520  movaps xmm10, xmm14
000078e5533dc524  addpd xmm10, xmm4
000078e5533dc529  vcmppd xmm8, xmm10, xmm10, 0x03
000078e5533dc52f  ptest xmm8, xmm8
000078e5533dc535  jnz 0x000078E5533DFE9E
000078e5533dc53b  vmovaps xmm14, [rsp+0x40]
000078e5533dc541  vpermilpd xmm14, xmm14, 0x00
000078e5533dc547  movaps xmm8, xmm1
000078e5533dc54b  mulpd xmm8, xmm14
000078e5533dc550  vcmppd xmm6, xmm8, xmm8, 0x03
000078e5533dc556  ptest xmm6, xmm6
000078e5533dc55b  jnz 0x000078E5533DFFE1
000078e5533dc561  movaps xmm1, [r15+0x2B0]
000078e5533dc569  vmovaps xmm14, [rsp+0x40]
000078e5533dc56f  vpermilpd xmm14, xmm14, 0x00
000078e5533dc575  movaps xmm6, xmm1
000078e5533dc578  mulpd xmm6, xmm14
000078e5533dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000078e5533dc582  ptest xmm5, xmm5
000078e5533dc587  jnz 0x000078E5533E0124
000078e5533dc58d  vmovaps xmm1, [rsp+0x10]
000078e5533dc593  vpermilpd xmm1, xmm1, 0x00
000078e5533dc599  movaps xmm14, xmm12
000078e5533dc59d  mulpd xmm14, xmm1
000078e5533dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000078e5533dc5a8  ptest xmm5, xmm5
000078e5533dc5ad  jnz 0x000078E5533E0265
000078e5533dc5b3  movaps xmm1, xmm13
000078e5533dc5b7  addpd xmm1, xmm9
000078e5533dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000078e5533dc5c1  ptest xmm12, xmm12
000078e5533dc5c7  jnz 0x000078E5533E03A8
000078e5533dc5cd  vmovaps xmm13, [rsp+0x10]
000078e5533dc5d3  vpermilpd xmm13, xmm13, 0x00
000078e5533dc5d9  movaps xmm12, xmm7
000078e5533dc5dd  mulpd xmm12, xmm13
000078e5533dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000078e5533dc5e8  ptest xmm9, xmm9
000078e5533dc5ee  jnz 0x000078E5533E04EA
000078e5533dc5f4  movaps xmm13, xmm15
000078e5533dc5f8  addpd xmm13, xmm8
000078e5533dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000078e5533dc603  ptest xmm9, xmm9
000078e5533dc609  jnz 0x000078E5533E062D
000078e5533dc60f  movaps xmm15, [r15+0x290]
000078e5533dc617  vmovaps xmm9, [rsp+0x10]
000078e5533dc61d  vpermilpd xmm9, xmm9, 0x00
000078e5533dc623  movaps xmm8, xmm15
000078e5533dc627  mulpd xmm8, xmm9
000078e5533dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000078e5533dc632  ptest xmm7, xmm7
000078e5533dc637  jnz 0x000078E5533E0771
000078e5533dc63d  movaps xmm15, xmm11
000078e5533dc641  addpd xmm15, xmm6
000078e5533dc646  vcmppd xmm9, xmm15, xmm15, 0x03
000078e5533dc64c  ptest xmm9, xmm9
000078e5533dc652  jnz 0x000078E5533E08B5
000078e5533dc658  movaps xmm11, [r15+0x1E0]
000078e5533dc660  vmovaps xmm9, [rsp+0x10]
000078e5533dc666  vpermilpd xmm9, xmm9, 0x00
000078e5533dc66c  movaps xmm7, xmm11
000078e5533dc670  mulpd xmm7, xmm9
000078e5533dc675  vcmppd xmm6, xmm7, xmm7, 0x03
000078e5533dc67a  ptest xmm6, xmm6
000078e5533dc67f  jnz 0x000078E5533E09F8
000078e5533dc685  movaps xmm11, xmm10
000078e5533dc689  addpd xmm11, xmm14
000078e5533dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000078e5533dc694  ptest xmm9, xmm9
000078e5533dc69a  jnz 0x000078E5533E0B3A
000078e5533dc6a0  lea r12, [rax+0x70]
000078e5533dc6a4  movups xmm14, [r13+r12*1]
000078e5533dc6aa  movaps [r15+0x240], xmm14
000078e5533dc6b2  movaps xmm10, xmm1
000078e5533dc6b6  addpd xmm10, xmm12
000078e5533dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000078e5533dc6c1  ptest xmm9, xmm9
000078e5533dc6c7  jnz 0x000078E5533E0C88
000078e5533dc6cd  movaps [r15+0x170], xmm10
000078e5533dc6d5  vmovaps xmm1, [rsp+0x20]
000078e5533dc6db  vpermilpd xmm1, xmm1, 0x00
000078e5533dc6e1  movaps xmm12, xmm14
000078e5533dc6e5  mulpd xmm12, xmm1
000078e5533dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000078e5533dc6f0  ptest xmm9, xmm9
000078e5533dc6f6  jnz 0x000078E5533E0DCB
000078e5533dc6fc  vmovaps xmm1, [rsp+0x20]
000078e5533dc702  vpermilpd xmm1, xmm1, 0x00
000078e5533dc708  vmovaps xmm9, [rsp+0xB0]
000078e5533dc711  movaps xmm14, xmm9
000078e5533dc715  mulpd xmm14, xmm1
000078e5533dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000078e5533dc720  ptest xmm6, xmm6
000078e5533dc725  jnz 0x000078E5533E0F0E
000078e5533dc72b  movaps [r15+0x180], xmm14
000078e5533dc733  movaps xmm1, xmm13
000078e5533dc737  addpd xmm1, xmm8
000078e5533dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000078e5533dc741  ptest xmm9, xmm9
000078e5533dc747  jnz 0x000078E5533E1051
000078e5533dc74d  movaps [r15+0x210], xmm1
000078e5533dc755  movups xmm13, [r13+rax*1]
000078e5533dc75b  lea r12, [rax+0x10]
000078e5533dc75f  movups xmm9, [r13+r12*1]
000078e5533dc765  movaps [r15+0x230], xmm9
000078e5533dc76d  movaps xmm8, xmm15
000078e5533dc771  addpd xmm8, xmm7
000078e5533dc776  vcmppd xmm6, xmm8, xmm8, 0x03
000078e5533dc77c  ptest xmm6, xmm6
000078e5533dc781  jnz 0x000078E5533E11A7
000078e5533dc787  movaps [r15+0x130], xmm8
000078e5533dc78f  vmovaps xmm15, [rsp+0x20]
000078e5533dc795  vpermilpd xmm15, xmm15, 0x00
000078e5533dc79b  movaps xmm7, xmm9
000078e5533dc79f  mulpd xmm7, xmm15
000078e5533dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000078e5533dc7a9  ptest xmm6, xmm6
000078e5533dc7ae  jnz 0x000078E5533E12EA
000078e5533dc7b4  movaps [r15+0x220], xmm7
000078e5533dc7bc  vmovaps xmm15, [rsp+0x20]
000078e5533dc7c2  vpermilpd xmm15, xmm15, 0x00
000078e5533dc7c8  movaps xmm9, xmm13
000078e5533dc7cc  mulpd xmm9, xmm15
000078e5533dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000078e5533dc7d7  ptest xmm6, xmm6
000078e5533dc7dc  jnz 0x000078E5533E142C
000078e5533dc7e2  movaps xmm15, xmm11
000078e5533dc7e6  addpd xmm15, xmm12
000078e5533dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000078e5533dc7f1  ptest xmm13, xmm13
000078e5533dc7f7  jnz 0x000078E5533E1570
000078e5533dc7fd  movaps [r15+0x140], xmm15
000078e5533dc805  movaps xmm13, xmm10
000078e5533dc809  addpd xmm13, xmm14
000078e5533dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000078e5533dc814  ptest xmm12, xmm12
000078e5533dc81a  jnz 0x000078E5533E16B4
000078e5533dc820  movaps [r15+0x150], xmm13
000078e5533dc828  movaps xmm14, xmm1
000078e5533dc82c  addpd xmm14, xmm7
000078e5533dc831  vcmppd xmm12, xmm14, xmm14, 0x03
000078e5533dc837  ptest xmm12, xmm12
000078e5533dc83d  jnz 0x000078E5533E17F8
000078e5533dc843  movaps [r15+0x160], xmm14
000078e5533dc84b  movaps xmm1, xmm8
000078e5533dc84f  addpd xmm1, xmm9
000078e5533dc854  vcmppd xmm12, xmm1, xmm1, 0x03
000078e5533dc859  ptest xmm12, xmm12
000078e5533dc85f  jnz 0x000078E5533E193A
000078e5533dc865  movaps [r15+0x120], xmm1
000078e5533dc86d  movups [r13+r14*1], xmm15
000078e5533dc873  lea rax, [r14+0x10]
000078e5533dc877  movups [r13+rax*1], xmm13
000078e5533dc87d  lea rax, [r14+0x20]
000078e5533dc881  movups [r13+rax*1], xmm14
000078e5533dc887  lea rax, [r14+0x30]
000078e5533dc88b  movups [r13+rax*1], xmm1
000078e5533dc891  mov eax, [r15+0x108]
000078e5533dc898  sahf
000078e5533dc899  jnz 0x000078E5533DC8CB
000078e5533dc89b  cmp dword ptr [r15+0x318], 0x00
000078e5533dc8a3  jz 0x000078E5533DB900
000078e5533dc8a9  nop [rax+rax*1], ax
000078e5533dc8b2  nop [rax+rax*1], eax
000078e5533dc8ba  mov eax, 0x410444
000078e5533dc8bf  mov [r15+0x100], rax
000078e5533dc8c6  jmp 0x000078E5531FE110
000078e5533dc8cb  cmp dword ptr [r15+0x318], 0x00
000078e5533dc8d3  jz 0x000078E5533D57E0
000078e5533dc8d9  nop [rax+rax*1], ax
000078e5533dc8e2  nop [rax+rax*1], eax
000078e5533dc8ea  mov eax, 0x410278
000078e5533dc8ef  mov [r15+0x100], rax
000078e5533dc8f6  jmp 0x000078E5531FE110
000078e5533dc8fb  int3
000078e5533dc8fc  call 0x000078E5532E27E0
000078e5533dc901  jmp 0x000078E5533DB9DF
000078e5533dc906  call 0x000078E5532E1570
000078e5533dc90b  jmp 0x000078E5533DB9E8
000078e5533dc910  call 0x000078E5532E27E0
000078e5533dc915  jmp 0x000078E5533DBA44
000078e5533dc91a  call 0x000078E5532E1570
000078e5533dc91f  jmp 0x000078E5533DBA4D
000078e5533dc924  call 0x000078E5532E27E0
000078e5533dc929  jmp 0x000078E5533DBA90
000078e5533dc92e  call 0x000078E5532E1570
000078e5533dc933  jmp 0x000078E5533DBA99
000078e5533dc938  call 0x000078E55320DC20
000078e5533dc93d  jmp 0x000078E5533DBAD8
000078e5533dc942  call 0x000078E5532D59C0
000078e5533dc947  jmp 0x000078E5533DBAEB
000078e5533dc94c  call 0x000078E5532E0E30
000078e5533dc951  jmp 0x000078E5533DBB09
000078e5533dc956  call 0x000078E5532DFBC0
000078e5533dc95b  jmp 0x000078E5533DBB13
000078e5533dc960  call 0x000078E5532DE950
000078e5533dc965  jmp 0x000078E5533DBB1D
000078e5533dc96a  sub rsp, 0x08
000078e5533dc96e  push rax
000078e5533dc96f  push rcx
000078e5533dc970  push rdx
000078e5533dc971  push rdi
000078e5533dc972  push rsi
000078e5533dc973  push r8
000078e5533dc975  push r9
000078e5533dc977  push r10
000078e5533dc979  push r11
000078e5533dc97b  sub rsp, 0xF0
000078e5533dc982  vmovaps [rsp], xmm0
000078e5533dc987  vmovaps [rsp+0x10], xmm1
000078e5533dc98d  vmovaps [rsp+0x20], xmm2
000078e5533dc993  vmovaps [rsp+0x30], xmm3
000078e5533dc999  vmovaps [rsp+0x40], xmm4
000078e5533dc99f  vmovaps [rsp+0x50], xmm5
000078e5533dc9a5  vmovaps [rsp+0x60], xmm6
000078e5533dc9ab  vmovaps [rsp+0x70], xmm7
000078e5533dc9b1  vmovaps [rsp+0x80], xmm9
000078e5533dc9ba  vmovaps [rsp+0x90], xmm10
000078e5533dc9c3  vmovaps [rsp+0xA0], xmm11
000078e5533dc9cc  vmovaps [rsp+0xB0], xmm12
000078e5533dc9d5  vmovaps [rsp+0xC0], xmm13
000078e5533dc9de  vmovaps [rsp+0xD0], xmm14
000078e5533dc9e7  vmovaps [rsp+0xE0], xmm15
000078e5533dc9f0  sub rsp, 0x30
000078e5533dc9f4  movaps [rsp], xmm8
000078e5533dc9f9  movaps [rsp+0x10], xmm12
000078e5533dc9ff  movaps [rsp+0x20], xmm15
000078e5533dca05  lea rdi, [rsp]
000078e5533dca09  mov esi, 0x00
000078e5533dca0e  mov rax, 0x5F83D5E17530
000078e5533dca18  call rax
000078e5533dca1a  movaps xmm8, [rsp]
000078e5533dca1f  add rsp, 0x30
000078e5533dca23  vmovaps xmm0, [rsp]
000078e5533dca28  vmovaps xmm1, [rsp+0x10]
000078e5533dca2e  vmovaps xmm2, [rsp+0x20]
000078e5533dca34  vmovaps xmm3, [rsp+0x30]
000078e5533dca3a  vmovaps xmm4, [rsp+0x40]
000078e5533dca40  vmovaps xmm5, [rsp+0x50]
000078e5533dca46  vmovaps xmm6, [rsp+0x60]
000078e5533dca4c  vmovaps xmm7, [rsp+0x70]
000078e5533dca52  vmovaps xmm9, [rsp+0x80]
000078e5533dca5b  vmovaps xmm10, [rsp+0x90]
000078e5533dca64  vmovaps xmm11, [rsp+0xA0]
000078e5533dca6d  vmovaps xmm12, [rsp+0xB0]
000078e5533dca76  vmovaps xmm13, [rsp+0xC0]
000078e5533dca7f  vmovaps xmm14, [rsp+0xD0]
000078e5533dca88  vmovaps xmm15, [rsp+0xE0]
000078e5533dca91  add rsp, 0xF0
000078e5533dca98  pop r11
000078e5533dca9a  pop r10
000078e5533dca9c  pop r9
000078e5533dca9e  pop r8
000078e5533dcaa0  pop rsi
000078e5533dcaa1  pop rdi
000078e5533dcaa2  pop rdx
000078e5533dcaa3  pop rcx
000078e5533dcaa4  pop rax
000078e5533dcaa5  add rsp, 0x08
000078e5533dcaa9  jmp 0x000078E5533DBB47
000078e5533dcaae  sub rsp, 0x08
000078e5533dcab2  push rax
000078e5533dcab3  push rcx
000078e5533dcab4  push rdx
000078e5533dcab5  push rdi
000078e5533dcab6  push rsi
000078e5533dcab7  push r8
000078e5533dcab9  push r9
000078e5533dcabb  push r10
000078e5533dcabd  push r11
000078e5533dcabf  sub rsp, 0xF0
000078e5533dcac6  vmovaps [rsp], xmm0
000078e5533dcacb  vmovaps [rsp+0x10], xmm1
000078e5533dcad1  vmovaps [rsp+0x20], xmm2
000078e5533dcad7  vmovaps [rsp+0x30], xmm3
000078e5533dcadd  vmovaps [rsp+0x40], xmm4
000078e5533dcae3  vmovaps [rsp+0x50], xmm5
000078e5533dcae9  vmovaps [rsp+0x60], xmm6
000078e5533dcaef  vmovaps [rsp+0x70], xmm8
000078e5533dcaf5  vmovaps [rsp+0x80], xmm9
000078e5533dcafe  vmovaps [rsp+0x90], xmm10
000078e5533dcb07  vmovaps [rsp+0xA0], xmm11
000078e5533dcb10  vmovaps [rsp+0xB0], xmm12
000078e5533dcb19  vmovaps [rsp+0xC0], xmm13
000078e5533dcb22  vmovaps [rsp+0xD0], xmm14
000078e5533dcb2b  vmovaps [rsp+0xE0], xmm15
000078e5533dcb34  sub rsp, 0x30
000078e5533dcb38  movaps [rsp], xmm7
000078e5533dcb3c  movaps [rsp+0x10], xmm9
000078e5533dcb42  movaps [rsp+0x20], xmm15
000078e5533dcb48  lea rdi, [rsp]
000078e5533dcb4c  mov esi, 0x00
000078e5533dcb51  mov rax, 0x5F83D5E17530
000078e5533dcb5b  call rax
000078e5533dcb5d  movaps xmm7, [rsp]
000078e5533dcb61  add rsp, 0x30
000078e5533dcb65  vmovaps xmm0, [rsp]
000078e5533dcb6a  vmovaps xmm1, [rsp+0x10]
000078e5533dcb70  vmovaps xmm2, [rsp+0x20]
000078e5533dcb76  vmovaps xmm3, [rsp+0x30]
000078e5533dcb7c  vmovaps xmm4, [rsp+0x40]
000078e5533dcb82  vmovaps xmm5, [rsp+0x50]
000078e5533dcb88  vmovaps xmm6, [rsp+0x60]
000078e5533dcb8e  vmovaps xmm8, [rsp+0x70]
000078e5533dcb94  vmovaps xmm9, [rsp+0x80]
000078e5533dcb9d  vmovaps xmm10, [rsp+0x90]
000078e5533dcba6  vmovaps xmm11, [rsp+0xA0]
000078e5533dcbaf  vmovaps xmm12, [rsp+0xB0]
000078e5533dcbb8  vmovaps xmm13, [rsp+0xC0]
000078e5533dcbc1  vmovaps xmm14, [rsp+0xD0]
000078e5533dcbca  vmovaps xmm15, [rsp+0xE0]
000078e5533dcbd3  add rsp, 0xF0
000078e5533dcbda  pop r11
000078e5533dcbdc  pop r10
000078e5533dcbde  pop r9
000078e5533dcbe0  pop r8
000078e5533dcbe2  pop rsi
000078e5533dcbe3  pop rdi
000078e5533dcbe4  pop rdx
000078e5533dcbe5  pop rcx
000078e5533dcbe6  pop rax
000078e5533dcbe7  add rsp, 0x08
000078e5533dcbeb  jmp 0x000078E5533DBB75
000078e5533dcbf0  sub rsp, 0x08
000078e5533dcbf4  push rax
000078e5533dcbf5  push rcx
000078e5533dcbf6  push rdx
000078e5533dcbf7  push rdi
000078e5533dcbf8  push rsi
000078e5533dcbf9  push r8
000078e5533dcbfb  push r9
000078e5533dcbfd  push r10
000078e5533dcbff  push r11
000078e5533dcc01  sub rsp, 0xF0
000078e5533dcc08  vmovaps [rsp], xmm0
000078e5533dcc0d  vmovaps [rsp+0x10], xmm1
000078e5533dcc13  vmovaps [rsp+0x20], xmm2
000078e5533dcc19  vmovaps [rsp+0x30], xmm3
000078e5533dcc1f  vmovaps [rsp+0x40], xmm4
000078e5533dcc25  vmovaps [rsp+0x50], xmm5
000078e5533dcc2b  vmovaps [rsp+0x60], xmm6
000078e5533dcc31  vmovaps [rsp+0x70], xmm7
000078e5533dcc37  vmovaps [rsp+0x80], xmm8
000078e5533dcc40  vmovaps [rsp+0x90], xmm10
000078e5533dcc49  vmovaps [rsp+0xA0], xmm11
000078e5533dcc52  vmovaps [rsp+0xB0], xmm12
000078e5533dcc5b  vmovaps [rsp+0xC0], xmm13
000078e5533dcc64  vmovaps [rsp+0xD0], xmm14
000078e5533dcc6d  vmovaps [rsp+0xE0], xmm15
000078e5533dcc76  sub rsp, 0x30
000078e5533dcc7a  movaps [rsp], xmm9
000078e5533dcc7f  movaps [rsp+0x10], xmm12
000078e5533dcc85  movaps [rsp+0x20], xmm10
000078e5533dcc8b  lea rdi, [rsp]
000078e5533dcc8f  mov esi, 0x00
000078e5533dcc94  mov rax, 0x5F83D5E17530
000078e5533dcc9e  call rax
000078e5533dcca0  movaps xmm9, [rsp]
000078e5533dcca5  add rsp, 0x30
000078e5533dcca9  vmovaps xmm0, [rsp]
000078e5533dccae  vmovaps xmm1, [rsp+0x10]
000078e5533dccb4  vmovaps xmm2, [rsp+0x20]
000078e5533dccba  vmovaps xmm3, [rsp+0x30]
000078e5533dccc0  vmovaps xmm4, [rsp+0x40]
000078e5533dccc6  vmovaps xmm5, [rsp+0x50]
000078e5533dcccc  vmovaps xmm6, [rsp+0x60]
000078e5533dccd2  vmovaps xmm7, [rsp+0x70]
000078e5533dccd8  vmovaps xmm8, [rsp+0x80]
000078e5533dcce1  vmovaps xmm10, [rsp+0x90]
000078e5533dccea  vmovaps xmm11, [rsp+0xA0]
000078e5533dccf3  vmovaps xmm12, [rsp+0xB0]
000078e5533dccfc  vmovaps xmm13, [rsp+0xC0]
000078e5533dcd05  vmovaps xmm14, [rsp+0xD0]
000078e5533dcd0e  vmovaps xmm15, [rsp+0xE0]
000078e5533dcd17  add rsp, 0xF0
000078e5533dcd1e  pop r11
000078e5533dcd20  pop r10
000078e5533dcd22  pop r9
000078e5533dcd24  pop r8
000078e5533dcd26  pop rsi
000078e5533dcd27  pop rdi
000078e5533dcd28  pop rdx
000078e5533dcd29  pop rcx
000078e5533dcd2a  pop rax
000078e5533dcd2b  add rsp, 0x08
000078e5533dcd2f  jmp 0x000078E5533DBB99
000078e5533dcd34  sub rsp, 0x08
000078e5533dcd38  push rax
000078e5533dcd39  push rcx
000078e5533dcd3a  push rdx
000078e5533dcd3b  push rdi
000078e5533dcd3c  push rsi
000078e5533dcd3d  push r8
000078e5533dcd3f  push r9
000078e5533dcd41  push r10
000078e5533dcd43  push r11
000078e5533dcd45  sub rsp, 0xF0
000078e5533dcd4c  vmovaps [rsp], xmm0
000078e5533dcd51  vmovaps [rsp+0x10], xmm1
000078e5533dcd57  vmovaps [rsp+0x20], xmm2
000078e5533dcd5d  vmovaps [rsp+0x30], xmm3
000078e5533dcd63  vmovaps [rsp+0x40], xmm4
000078e5533dcd69  vmovaps [rsp+0x50], xmm5
000078e5533dcd6f  vmovaps [rsp+0x60], xmm6
000078e5533dcd75  vmovaps [rsp+0x70], xmm7
000078e5533dcd7b  vmovaps [rsp+0x80], xmm8
000078e5533dcd84  vmovaps [rsp+0x90], xmm9
000078e5533dcd8d  vmovaps [rsp+0xA0], xmm11
000078e5533dcd96  vmovaps [rsp+0xB0], xmm12
000078e5533dcd9f  vmovaps [rsp+0xC0], xmm13
000078e5533dcda8  vmovaps [rsp+0xD0], xmm14
000078e5533dcdb1  vmovaps [rsp+0xE0], xmm15
000078e5533dcdba  sub rsp, 0x30
000078e5533dcdbe  movaps [rsp], xmm10
000078e5533dcdc3  movaps [rsp+0x10], xmm12
000078e5533dcdc9  movaps [rsp+0x20], xmm11
000078e5533dcdcf  lea rdi, [rsp]
000078e5533dcdd3  mov esi, 0x00
000078e5533dcdd8  mov rax, 0x5F83D5E17530
000078e5533dcde2  call rax
000078e5533dcde4  movaps xmm10, [rsp]
000078e5533dcde9  add rsp, 0x30
000078e5533dcded  vmovaps xmm0, [rsp]
000078e5533dcdf2  vmovaps xmm1, [rsp+0x10]
000078e5533dcdf8  vmovaps xmm2, [rsp+0x20]
000078e5533dcdfe  vmovaps xmm3, [rsp+0x30]
000078e5533dce04  vmovaps xmm4, [rsp+0x40]
000078e5533dce0a  vmovaps xmm5, [rsp+0x50]
000078e5533dce10  vmovaps xmm6, [rsp+0x60]
000078e5533dce16  vmovaps xmm7, [rsp+0x70]
000078e5533dce1c  vmovaps xmm8, [rsp+0x80]
000078e5533dce25  vmovaps xmm9, [rsp+0x90]
000078e5533dce2e  vmovaps xmm11, [rsp+0xA0]
000078e5533dce37  vmovaps xmm12, [rsp+0xB0]
000078e5533dce40  vmovaps xmm13, [rsp+0xC0]
000078e5533dce49  vmovaps xmm14, [rsp+0xD0]
000078e5533dce52  vmovaps xmm15, [rsp+0xE0]
000078e5533dce5b  add rsp, 0xF0
000078e5533dce62  pop r11
000078e5533dce64  pop r10
000078e5533dce66  pop r9
000078e5533dce68  pop r8
000078e5533dce6a  pop rsi
000078e5533dce6b  pop rdi
000078e5533dce6c  pop rdx
000078e5533dce6d  pop rcx
000078e5533dce6e  pop rax
000078e5533dce6f  add rsp, 0x08
000078e5533dce73  jmp 0x000078E5533DBBB3
000078e5533dce78  sub rsp, 0x08
000078e5533dce7c  push rax
000078e5533dce7d  push rcx
000078e5533dce7e  push rdx
000078e5533dce7f  push rdi
000078e5533dce80  push rsi
000078e5533dce81  push r8
000078e5533dce83  push r9
000078e5533dce85  push r10
000078e5533dce87  push r11
000078e5533dce89  sub rsp, 0xF0
000078e5533dce90  vmovaps [rsp], xmm0
000078e5533dce95  vmovaps [rsp+0x10], xmm1
000078e5533dce9b  vmovaps [rsp+0x20], xmm2
000078e5533dcea1  vmovaps [rsp+0x30], xmm3
000078e5533dcea7  vmovaps [rsp+0x40], xmm4
000078e5533dcead  vmovaps [rsp+0x50], xmm5
000078e5533dceb3  vmovaps [rsp+0x60], xmm7
000078e5533dceb9  vmovaps [rsp+0x70], xmm8
000078e5533dcebf  vmovaps [rsp+0x80], xmm9
000078e5533dcec8  vmovaps [rsp+0x90], xmm10
000078e5533dced1  vmovaps [rsp+0xA0], xmm11
000078e5533dceda  vmovaps [rsp+0xB0], xmm12
000078e5533dcee3  vmovaps [rsp+0xC0], xmm13
000078e5533dceec  vmovaps [rsp+0xD0], xmm14
000078e5533dcef5  vmovaps [rsp+0xE0], xmm15
000078e5533dcefe  sub rsp, 0x30
000078e5533dcf02  movaps [rsp], xmm6
000078e5533dcf06  movaps [rsp+0x10], xmm12
000078e5533dcf0c  movaps [rsp+0x20], xmm11
000078e5533dcf12  lea rdi, [rsp]
000078e5533dcf16  mov esi, 0x00
000078e5533dcf1b  mov rax, 0x5F83D5E17530
000078e5533dcf25  call rax
000078e5533dcf27  movaps xmm6, [rsp]
000078e5533dcf2b  add rsp, 0x30
000078e5533dcf2f  vmovaps xmm0, [rsp]
000078e5533dcf34  vmovaps xmm1, [rsp+0x10]
000078e5533dcf3a  vmovaps xmm2, [rsp+0x20]
000078e5533dcf40  vmovaps xmm3, [rsp+0x30]
000078e5533dcf46  vmovaps xmm4, [rsp+0x40]
000078e5533dcf4c  vmovaps xmm5, [rsp+0x50]
000078e5533dcf52  vmovaps xmm7, [rsp+0x60]
000078e5533dcf58  vmovaps xmm8, [rsp+0x70]
000078e5533dcf5e  vmovaps xmm9, [rsp+0x80]
000078e5533dcf67  vmovaps xmm10, [rsp+0x90]
000078e5533dcf70  vmovaps xmm11, [rsp+0xA0]
000078e5533dcf79  vmovaps xmm12, [rsp+0xB0]
000078e5533dcf82  vmovaps xmm13, [rsp+0xC0]
000078e5533dcf8b  vmovaps xmm14, [rsp+0xD0]
000078e5533dcf94  vmovaps xmm15, [rsp+0xE0]
000078e5533dcf9d  add rsp, 0xF0
000078e5533dcfa4  pop r11
000078e5533dcfa6  pop r10
000078e5533dcfa8  pop r9
000078e5533dcfaa  pop r8
000078e5533dcfac  pop rsi
000078e5533dcfad  pop rdi
000078e5533dcfae  pop rdx
000078e5533dcfaf  pop rcx
000078e5533dcfb0  pop rax
000078e5533dcfb1  add rsp, 0x08
000078e5533dcfb5  jmp 0x000078E5533DBBD4
000078e5533dcfba  sub rsp, 0x08
000078e5533dcfbe  push rax
000078e5533dcfbf  push rcx
000078e5533dcfc0  push rdx
000078e5533dcfc1  push rdi
000078e5533dcfc2  push rsi
000078e5533dcfc3  push r8
000078e5533dcfc5  push r9
000078e5533dcfc7  push r10
000078e5533dcfc9  push r11
000078e5533dcfcb  sub rsp, 0xF0
000078e5533dcfd2  vmovaps [rsp], xmm0
000078e5533dcfd7  vmovaps [rsp+0x10], xmm1
000078e5533dcfdd  vmovaps [rsp+0x20], xmm2
000078e5533dcfe3  vmovaps [rsp+0x30], xmm4
000078e5533dcfe9  vmovaps [rsp+0x40], xmm5
000078e5533dcfef  vmovaps [rsp+0x50], xmm6
000078e5533dcff5  vmovaps [rsp+0x60], xmm7
000078e5533dcffb  vmovaps [rsp+0x70], xmm8
000078e5533dd001  vmovaps [rsp+0x80], xmm9
000078e5533dd00a  vmovaps [rsp+0x90], xmm10
000078e5533dd013  vmovaps [rsp+0xA0], xmm11
000078e5533dd01c  vmovaps [rsp+0xB0], xmm12
000078e5533dd025  vmovaps [rsp+0xC0], xmm13
000078e5533dd02e  vmovaps [rsp+0xD0], xmm14
000078e5533dd037  vmovaps [rsp+0xE0], xmm15
000078e5533dd040  sub rsp, 0x30
000078e5533dd044  movaps [rsp], xmm3
000078e5533dd048  movaps [rsp+0x10], xmm5
000078e5533dd04d  movaps [rsp+0x20], xmm4
000078e5533dd052  lea rdi, [rsp]
000078e5533dd056  mov esi, 0x00
000078e5533dd05b  mov rax, 0x5F83D5E17530
000078e5533dd065  call rax
000078e5533dd067  movaps xmm3, [rsp]
000078e5533dd06b  add rsp, 0x30
000078e5533dd06f  vmovaps xmm0, [rsp]
000078e5533dd074  vmovaps xmm1, [rsp+0x10]
000078e5533dd07a  vmovaps xmm2, [rsp+0x20]
000078e5533dd080  vmovaps xmm4, [rsp+0x30]
000078e5533dd086  vmovaps xmm5, [rsp+0x40]
000078e5533dd08c  vmovaps xmm6, [rsp+0x50]
000078e5533dd092  vmovaps xmm7, [rsp+0x60]
000078e5533dd098  vmovaps xmm8, [rsp+0x70]
000078e5533dd09e  vmovaps xmm9, [rsp+0x80]
000078e5533dd0a7  vmovaps xmm10, [rsp+0x90]
000078e5533dd0b0  vmovaps xmm11, [rsp+0xA0]
000078e5533dd0b9  vmovaps xmm12, [rsp+0xB0]
000078e5533dd0c2  vmovaps xmm13, [rsp+0xC0]
000078e5533dd0cb  vmovaps xmm14, [rsp+0xD0]
000078e5533dd0d4  vmovaps xmm15, [rsp+0xE0]
000078e5533dd0dd  add rsp, 0xF0
000078e5533dd0e4  pop r11
000078e5533dd0e6  pop r10
000078e5533dd0e8  pop r9
000078e5533dd0ea  pop r8
000078e5533dd0ec  pop rsi
000078e5533dd0ed  pop rdi
000078e5533dd0ee  pop rdx
000078e5533dd0ef  pop rcx
000078e5533dd0f0  pop rax
000078e5533dd0f1  add rsp, 0x08
000078e5533dd0f5  jmp 0x000078E5533DBC35
000078e5533dd0fa  sub rsp, 0x08
000078e5533dd0fe  push rax
000078e5533dd0ff  push rcx
000078e5533dd100  push rdx
000078e5533dd101  push rdi
000078e5533dd102  push rsi
000078e5533dd103  push r8
000078e5533dd105  push r9
000078e5533dd107  push r10
000078e5533dd109  push r11
000078e5533dd10b  sub rsp, 0xF0
000078e5533dd112  vmovaps [rsp], xmm0
000078e5533dd117  vmovaps [rsp+0x10], xmm1
000078e5533dd11d  vmovaps [rsp+0x20], xmm2
000078e5533dd123  vmovaps [rsp+0x30], xmm3
000078e5533dd129  vmovaps [rsp+0x40], xmm4
000078e5533dd12f  vmovaps [rsp+0x50], xmm6
000078e5533dd135  vmovaps [rsp+0x60], xmm7
000078e5533dd13b  vmovaps [rsp+0x70], xmm8
000078e5533dd141  vmovaps [rsp+0x80], xmm9
000078e5533dd14a  vmovaps [rsp+0x90], xmm10
000078e5533dd153  vmovaps [rsp+0xA0], xmm11
000078e5533dd15c  vmovaps [rsp+0xB0], xmm12
000078e5533dd165  vmovaps [rsp+0xC0], xmm13
000078e5533dd16e  vmovaps [rsp+0xD0], xmm14
000078e5533dd177  vmovaps [rsp+0xE0], xmm15
000078e5533dd180  sub rsp, 0x30
000078e5533dd184  movaps [rsp], xmm5
000078e5533dd188  movaps [rsp+0x10], xmm8
000078e5533dd18e  movaps [rsp+0x20], xmm15
000078e5533dd194  lea rdi, [rsp]
000078e5533dd198  mov esi, 0x00
000078e5533dd19d  mov rax, 0x5F83D5E17530
000078e5533dd1a7  call rax
000078e5533dd1a9  movaps xmm5, [rsp]
000078e5533dd1ad  add rsp, 0x30
000078e5533dd1b1  vmovaps xmm0, [rsp]
000078e5533dd1b6  vmovaps xmm1, [rsp+0x10]
000078e5533dd1bc  vmovaps xmm2, [rsp+0x20]
000078e5533dd1c2  vmovaps xmm3, [rsp+0x30]
000078e5533dd1c8  vmovaps xmm4, [rsp+0x40]
000078e5533dd1ce  vmovaps xmm6, [rsp+0x50]
000078e5533dd1d4  vmovaps xmm7, [rsp+0x60]
000078e5533dd1da  vmovaps xmm8, [rsp+0x70]
000078e5533dd1e0  vmovaps xmm9, [rsp+0x80]
000078e5533dd1e9  vmovaps xmm10, [rsp+0x90]
000078e5533dd1f2  vmovaps xmm11, [rsp+0xA0]
000078e5533dd1fb  vmovaps xmm12, [rsp+0xB0]
000078e5533dd204  vmovaps xmm13, [rsp+0xC0]
000078e5533dd20d  vmovaps xmm14, [rsp+0xD0]
000078e5533dd216  vmovaps xmm15, [rsp+0xE0]
000078e5533dd21f  add rsp, 0xF0
000078e5533dd226  pop r11
000078e5533dd228  pop r10
000078e5533dd22a  pop r9
000078e5533dd22c  pop r8
000078e5533dd22e  pop rsi
000078e5533dd22f  pop rdi
000078e5533dd230  pop rdx
000078e5533dd231  pop rcx
000078e5533dd232  pop rax
000078e5533dd233  add rsp, 0x08
000078e5533dd237  jmp 0x000078E5533DBC73
000078e5533dd23c  sub rsp, 0x08
000078e5533dd240  push rax
000078e5533dd241  push rcx
000078e5533dd242  push rdx
000078e5533dd243  push rdi
000078e5533dd244  push rsi
000078e5533dd245  push r8
000078e5533dd247  push r9
000078e5533dd249  push r10
000078e5533dd24b  push r11
000078e5533dd24d  sub rsp, 0xF0
000078e5533dd254  vmovaps [rsp], xmm0
000078e5533dd259  vmovaps [rsp+0x10], xmm1
000078e5533dd25f  vmovaps [rsp+0x20], xmm2
000078e5533dd265  vmovaps [rsp+0x30], xmm3
000078e5533dd26b  vmovaps [rsp+0x40], xmm5
000078e5533dd271  vmovaps [rsp+0x50], xmm6
000078e5533dd277  vmovaps [rsp+0x60], xmm7
000078e5533dd27d  vmovaps [rsp+0x70], xmm8
000078e5533dd283  vmovaps [rsp+0x80], xmm9
000078e5533dd28c  vmovaps [rsp+0x90], xmm10
000078e5533dd295  vmovaps [rsp+0xA0], xmm11
000078e5533dd29e  vmovaps [rsp+0xB0], xmm12
000078e5533dd2a7  vmovaps [rsp+0xC0], xmm13
000078e5533dd2b0  vmovaps [rsp+0xD0], xmm14
000078e5533dd2b9  vmovaps [rsp+0xE0], xmm15
000078e5533dd2c2  sub rsp, 0x30
000078e5533dd2c6  movaps [rsp], xmm4
000078e5533dd2ca  movaps [rsp+0x10], xmm9
000078e5533dd2d0  movaps [rsp+0x20], xmm8
000078e5533dd2d6  lea rdi, [rsp]
000078e5533dd2da  mov esi, 0x00
000078e5533dd2df  mov rax, 0x5F83D5E17530
000078e5533dd2e9  call rax
000078e5533dd2eb  movaps xmm4, [rsp]
000078e5533dd2ef  add rsp, 0x30
000078e5533dd2f3  vmovaps xmm0, [rsp]
000078e5533dd2f8  vmovaps xmm1, [rsp+0x10]
000078e5533dd2fe  vmovaps xmm2, [rsp+0x20]
000078e5533dd304  vmovaps xmm3, [rsp+0x30]
000078e5533dd30a  vmovaps xmm5, [rsp+0x40]
000078e5533dd310  vmovaps xmm6, [rsp+0x50]
000078e5533dd316  vmovaps xmm7, [rsp+0x60]
000078e5533dd31c  vmovaps xmm8, [rsp+0x70]
000078e5533dd322  vmovaps xmm9, [rsp+0x80]
000078e5533dd32b  vmovaps xmm10, [rsp+0x90]
000078e5533dd334  vmovaps xmm11, [rsp+0xA0]
000078e5533dd33d  vmovaps xmm12, [rsp+0xB0]
000078e5533dd346  vmovaps xmm13, [rsp+0xC0]
000078e5533dd34f  vmovaps xmm14, [rsp+0xD0]
000078e5533dd358  vmovaps xmm15, [rsp+0xE0]
000078e5533dd361  add rsp, 0xF0
000078e5533dd368  pop r11
000078e5533dd36a  pop r10
000078e5533dd36c  pop r9
000078e5533dd36e  pop r8
000078e5533dd370  pop rsi
000078e5533dd371  pop rdi
000078e5533dd372  pop rdx
000078e5533dd373  pop rcx
000078e5533dd374  pop rax
000078e5533dd375  add rsp, 0x08
000078e5533dd379  jmp 0x000078E5533DBC94
000078e5533dd37e  sub rsp, 0x08
000078e5533dd382  push rax
000078e5533dd383  push rcx
000078e5533dd384  push rdx
000078e5533dd385  push rdi
000078e5533dd386  push rsi
000078e5533dd387  push r8
000078e5533dd389  push r9
000078e5533dd38b  push r10
000078e5533dd38d  push r11
000078e5533dd38f  sub rsp, 0xF0
000078e5533dd396  vmovaps [rsp], xmm0
000078e5533dd39b  vmovaps [rsp+0x10], xmm1
000078e5533dd3a1  vmovaps [rsp+0x20], xmm2
000078e5533dd3a7  vmovaps [rsp+0x30], xmm3
000078e5533dd3ad  vmovaps [rsp+0x40], xmm4
000078e5533dd3b3  vmovaps [rsp+0x50], xmm5
000078e5533dd3b9  vmovaps [rsp+0x60], xmm6
000078e5533dd3bf  vmovaps [rsp+0x70], xmm7
000078e5533dd3c5  vmovaps [rsp+0x80], xmm8
000078e5533dd3ce  vmovaps [rsp+0x90], xmm10
000078e5533dd3d7  vmovaps [rsp+0xA0], xmm11
000078e5533dd3e0  vmovaps [rsp+0xB0], xmm12
000078e5533dd3e9  vmovaps [rsp+0xC0], xmm13
000078e5533dd3f2  vmovaps [rsp+0xD0], xmm14
000078e5533dd3fb  vmovaps [rsp+0xE0], xmm15
000078e5533dd404  sub rsp, 0x30
000078e5533dd408  movaps [rsp], xmm9
000078e5533dd40d  movaps [rsp+0x10], xmm10
000078e5533dd413  movaps [rsp+0x20], xmm8
000078e5533dd419  lea rdi, [rsp]
000078e5533dd41d  mov esi, 0x00
000078e5533dd422  mov rax, 0x5F83D5E17530
000078e5533dd42c  call rax
000078e5533dd42e  movaps xmm9, [rsp]
000078e5533dd433  add rsp, 0x30
000078e5533dd437  vmovaps xmm0, [rsp]
000078e5533dd43c  vmovaps xmm1, [rsp+0x10]
000078e5533dd442  vmovaps xmm2, [rsp+0x20]
000078e5533dd448  vmovaps xmm3, [rsp+0x30]
000078e5533dd44e  vmovaps xmm4, [rsp+0x40]
000078e5533dd454  vmovaps xmm5, [rsp+0x50]
000078e5533dd45a  vmovaps xmm6, [rsp+0x60]
000078e5533dd460  vmovaps xmm7, [rsp+0x70]
000078e5533dd466  vmovaps xmm8, [rsp+0x80]
000078e5533dd46f  vmovaps xmm10, [rsp+0x90]
000078e5533dd478  vmovaps xmm11, [rsp+0xA0]
000078e5533dd481  vmovaps xmm12, [rsp+0xB0]
000078e5533dd48a  vmovaps xmm13, [rsp+0xC0]
000078e5533dd493  vmovaps xmm14, [rsp+0xD0]
000078e5533dd49c  vmovaps xmm15, [rsp+0xE0]
000078e5533dd4a5  add rsp, 0xF0
000078e5533dd4ac  pop r11
000078e5533dd4ae  pop r10
000078e5533dd4b0  pop r9
000078e5533dd4b2  pop r8
000078e5533dd4b4  pop rsi
000078e5533dd4b5  pop rdi
000078e5533dd4b6  pop rdx
000078e5533dd4b7  pop rcx
000078e5533dd4b8  pop rax
000078e5533dd4b9  add rsp, 0x08
000078e5533dd4bd  jmp 0x000078E5533DBCAE
000078e5533dd4c2  call 0x000078E5532B52F0
000078e5533dd4c7  jmp 0x000078E5533DBDC8
000078e5533dd4cc  call 0x000078E5532B52F0
000078e5533dd4d1  jmp 0x000078E5533DBDDE
000078e5533dd4d6  sub rsp, 0x08
000078e5533dd4da  push rax
000078e5533dd4db  push rcx
000078e5533dd4dc  push rdx
000078e5533dd4dd  push rdi
000078e5533dd4de  push rsi
000078e5533dd4df  push r8
000078e5533dd4e1  push r9
000078e5533dd4e3  push r10
000078e5533dd4e5  push r11
000078e5533dd4e7  sub rsp, 0xF0
000078e5533dd4ee  vmovaps [rsp], xmm0
000078e5533dd4f3  vmovaps [rsp+0x10], xmm2
000078e5533dd4f9  vmovaps [rsp+0x20], xmm3
000078e5533dd4ff  vmovaps [rsp+0x30], xmm4
000078e5533dd505  vmovaps [rsp+0x40], xmm5
000078e5533dd50b  vmovaps [rsp+0x50], xmm6
000078e5533dd511  vmovaps [rsp+0x60], xmm7
000078e5533dd517  vmovaps [rsp+0x70], xmm8
000078e5533dd51d  vmovaps [rsp+0x80], xmm9
000078e5533dd526  vmovaps [rsp+0x90], xmm10
000078e5533dd52f  vmovaps [rsp+0xA0], xmm11
000078e5533dd538  vmovaps [rsp+0xB0], xmm12
000078e5533dd541  vmovaps [rsp+0xC0], xmm13
000078e5533dd54a  vmovaps [rsp+0xD0], xmm14
000078e5533dd553  vmovaps [rsp+0xE0], xmm15
000078e5533dd55c  sub rsp, 0x30
000078e5533dd560  movaps [rsp], xmm1
000078e5533dd564  movaps [rsp+0x10], xmm6
000078e5533dd569  movaps [rsp+0x20], xmm15
000078e5533dd56f  lea rdi, [rsp]
000078e5533dd573  mov esi, 0x00
000078e5533dd578  mov rax, 0x5F83D5E17530
000078e5533dd582  call rax
000078e5533dd584  movaps xmm1, [rsp]
000078e5533dd588  add rsp, 0x30
000078e5533dd58c  vmovaps xmm0, [rsp]
000078e5533dd591  vmovaps xmm2, [rsp+0x10]
000078e5533dd597  vmovaps xmm3, [rsp+0x20]
000078e5533dd59d  vmovaps xmm4, [rsp+0x30]
000078e5533dd5a3  vmovaps xmm5, [rsp+0x40]
000078e5533dd5a9  vmovaps xmm6, [rsp+0x50]
000078e5533dd5af  vmovaps xmm7, [rsp+0x60]
000078e5533dd5b5  vmovaps xmm8, [rsp+0x70]
000078e5533dd5bb  vmovaps xmm9, [rsp+0x80]
000078e5533dd5c4  vmovaps xmm10, [rsp+0x90]
000078e5533dd5cd  vmovaps xmm11, [rsp+0xA0]
000078e5533dd5d6  vmovaps xmm12, [rsp+0xB0]
000078e5533dd5df  vmovaps xmm13, [rsp+0xC0]
000078e5533dd5e8  vmovaps xmm14, [rsp+0xD0]
000078e5533dd5f1  vmovaps xmm15, [rsp+0xE0]
000078e5533dd5fa  add rsp, 0xF0
000078e5533dd601  pop r11
000078e5533dd603  pop r10
000078e5533dd605  pop r9
000078e5533dd607  pop r8
000078e5533dd609  pop rsi
000078e5533dd60a  pop rdi
000078e5533dd60b  pop rdx
000078e5533dd60c  pop rcx
000078e5533dd60d  pop rax
000078e5533dd60e  add rsp, 0x08
000078e5533dd612  jmp 0x000078E5533DBE1B
000078e5533dd617  call 0x000078E5532C4620
000078e5533dd61c  jmp 0x000078E5533DBE28
000078e5533dd621  sub rsp, 0x08
000078e5533dd625  push rax
000078e5533dd626  push rcx
000078e5533dd627  push rdx
000078e5533dd628  push rdi
000078e5533dd629  push rsi
000078e5533dd62a  push r8
000078e5533dd62c  push r9
000078e5533dd62e  push r10
000078e5533dd630  push r11
000078e5533dd632  sub rsp, 0xF0
000078e5533dd639  vmovaps [rsp], xmm0
000078e5533dd63e  vmovaps [rsp+0x10], xmm1
000078e5533dd644  vmovaps [rsp+0x20], xmm2
000078e5533dd64a  vmovaps [rsp+0x30], xmm3
000078e5533dd650  vmovaps [rsp+0x40], xmm4
000078e5533dd656  vmovaps [rsp+0x50], xmm5
000078e5533dd65c  vmovaps [rsp+0x60], xmm6
000078e5533dd662  vmovaps [rsp+0x70], xmm7
000078e5533dd668  vmovaps [rsp+0x80], xmm8
000078e5533dd671  vmovaps [rsp+0x90], xmm9
000078e5533dd67a  vmovaps [rsp+0xA0], xmm10
000078e5533dd683  vmovaps [rsp+0xB0], xmm11
000078e5533dd68c  vmovaps [rsp+0xC0], xmm12
000078e5533dd695  vmovaps [rsp+0xD0], xmm13
000078e5533dd69e  vmovaps [rsp+0xE0], xmm15
000078e5533dd6a7  sub rsp, 0x30
000078e5533dd6ab  movaps [rsp], xmm14
000078e5533dd6b0  movaps [rsp+0x10], xmm4
000078e5533dd6b5  movaps [rsp+0x20], xmm3
000078e5533dd6ba  lea rdi, [rsp]
000078e5533dd6be  mov esi, 0x00
000078e5533dd6c3  mov rax, 0x5F83D5E17530
000078e5533dd6cd  call rax
000078e5533dd6cf  movaps xmm14, [rsp]
000078e5533dd6d4  add rsp, 0x30
000078e5533dd6d8  vmovaps xmm0, [rsp]
000078e5533dd6dd  vmovaps xmm1, [rsp+0x10]
000078e5533dd6e3  vmovaps xmm2, [rsp+0x20]
000078e5533dd6e9  vmovaps xmm3, [rsp+0x30]
000078e5533dd6ef  vmovaps xmm4, [rsp+0x40]
000078e5533dd6f5  vmovaps xmm5, [rsp+0x50]
000078e5533dd6fb  vmovaps xmm6, [rsp+0x60]
000078e5533dd701  vmovaps xmm7, [rsp+0x70]
000078e5533dd707  vmovaps xmm8, [rsp+0x80]
000078e5533dd710  vmovaps xmm9, [rsp+0x90]
000078e5533dd719  vmovaps xmm10, [rsp+0xA0]
000078e5533dd722  vmovaps xmm11, [rsp+0xB0]
000078e5533dd72b  vmovaps xmm12, [rsp+0xC0]
000078e5533dd734  vmovaps xmm13, [rsp+0xD0]
000078e5533dd73d  vmovaps xmm15, [rsp+0xE0]
000078e5533dd746  add rsp, 0xF0
000078e5533dd74d  pop r11
000078e5533dd74f  pop r10
000078e5533dd751  pop r9
000078e5533dd753  pop r8
000078e5533dd755  pop rsi
000078e5533dd756  pop rdi
000078e5533dd757  pop rdx
000078e5533dd758  pop rcx
000078e5533dd759  pop rax
000078e5533dd75a  add rsp, 0x08
000078e5533dd75e  jmp 0x000078E5533DBE42
000078e5533dd763  sub rsp, 0x08
000078e5533dd767  push rax
000078e5533dd768  push rcx
000078e5533dd769  push rdx
000078e5533dd76a  push rdi
000078e5533dd76b  push rsi
000078e5533dd76c  push r8
000078e5533dd76e  push r9
000078e5533dd770  push r10
000078e5533dd772  push r11
000078e5533dd774  sub rsp, 0xF0
000078e5533dd77b  vmovaps [rsp], xmm0
000078e5533dd780  vmovaps [rsp+0x10], xmm1
000078e5533dd786  vmovaps [rsp+0x20], xmm2
000078e5533dd78c  vmovaps [rsp+0x30], xmm3
000078e5533dd792  vmovaps [rsp+0x40], xmm4
000078e5533dd798  vmovaps [rsp+0x50], xmm5
000078e5533dd79e  vmovaps [rsp+0x60], xmm7
000078e5533dd7a4  vmovaps [rsp+0x70], xmm8
000078e5533dd7aa  vmovaps [rsp+0x80], xmm9
000078e5533dd7b3  vmovaps [rsp+0x90], xmm10
000078e5533dd7bc  vmovaps [rsp+0xA0], xmm11
000078e5533dd7c5  vmovaps [rsp+0xB0], xmm12
000078e5533dd7ce  vmovaps [rsp+0xC0], xmm13
000078e5533dd7d7  vmovaps [rsp+0xD0], xmm14
000078e5533dd7e0  vmovaps [rsp+0xE0], xmm15
000078e5533dd7e9  sub rsp, 0x30
000078e5533dd7ed  movaps [rsp], xmm6
000078e5533dd7f1  movaps [rsp+0x10], xmm9
000078e5533dd7f7  movaps [rsp+0x20], xmm7
000078e5533dd7fc  lea rdi, [rsp]
000078e5533dd800  mov esi, 0x00
000078e5533dd805  mov rax, 0x5F83D5E17530
000078e5533dd80f  call rax
000078e5533dd811  movaps xmm6, [rsp]
000078e5533dd815  add rsp, 0x30
000078e5533dd819  vmovaps xmm0, [rsp]
000078e5533dd81e  vmovaps xmm1, [rsp+0x10]
000078e5533dd824  vmovaps xmm2, [rsp+0x20]
000078e5533dd82a  vmovaps xmm3, [rsp+0x30]
000078e5533dd830  vmovaps xmm4, [rsp+0x40]
000078e5533dd836  vmovaps xmm5, [rsp+0x50]
000078e5533dd83c  vmovaps xmm7, [rsp+0x60]
000078e5533dd842  vmovaps xmm8, [rsp+0x70]
000078e5533dd848  vmovaps xmm9, [rsp+0x80]
000078e5533dd851  vmovaps xmm10, [rsp+0x90]
000078e5533dd85a  vmovaps xmm11, [rsp+0xA0]
000078e5533dd863  vmovaps xmm12, [rsp+0xB0]
000078e5533dd86c  vmovaps xmm13, [rsp+0xC0]
000078e5533dd875  vmovaps xmm14, [rsp+0xD0]
000078e5533dd87e  vmovaps xmm15, [rsp+0xE0]
000078e5533dd887  add rsp, 0xF0
000078e5533dd88e  pop r11
000078e5533dd890  pop r10
000078e5533dd892  pop r9
000078e5533dd894  pop r8
000078e5533dd896  pop rsi
000078e5533dd897  pop rdi
000078e5533dd898  pop rdx
000078e5533dd899  pop rcx
000078e5533dd89a  pop rax
000078e5533dd89b  add rsp, 0x08
000078e5533dd89f  jmp 0x000078E5533DBE5A
000078e5533dd8a4  sub rsp, 0x08
000078e5533dd8a8  push rax
000078e5533dd8a9  push rcx
000078e5533dd8aa  push rdx
000078e5533dd8ab  push rdi
000078e5533dd8ac  push rsi
000078e5533dd8ad  push r8
000078e5533dd8af  push r9
000078e5533dd8b1  push r10
000078e5533dd8b3  push r11
000078e5533dd8b5  sub rsp, 0xF0
000078e5533dd8bc  vmovaps [rsp], xmm0
000078e5533dd8c1  vmovaps [rsp+0x10], xmm1
000078e5533dd8c7  vmovaps [rsp+0x20], xmm2
000078e5533dd8cd  vmovaps [rsp+0x30], xmm3
000078e5533dd8d3  vmovaps [rsp+0x40], xmm4
000078e5533dd8d9  vmovaps [rsp+0x50], xmm5
000078e5533dd8df  vmovaps [rsp+0x60], xmm6
000078e5533dd8e5  vmovaps [rsp+0x70], xmm8
000078e5533dd8eb  vmovaps [rsp+0x80], xmm9
000078e5533dd8f4  vmovaps [rsp+0x90], xmm10
000078e5533dd8fd  vmovaps [rsp+0xA0], xmm11
000078e5533dd906  vmovaps [rsp+0xB0], xmm12
000078e5533dd90f  vmovaps [rsp+0xC0], xmm13
000078e5533dd918  vmovaps [rsp+0xD0], xmm14
000078e5533dd921  vmovaps [rsp+0xE0], xmm15
000078e5533dd92a  sub rsp, 0x30
000078e5533dd92e  movaps [rsp], xmm7
000078e5533dd932  movaps [rsp+0x10], xmm4
000078e5533dd937  movaps [rsp+0x20], xmm9
000078e5533dd93d  lea rdi, [rsp]
000078e5533dd941  mov esi, 0x00
000078e5533dd946  mov rax, 0x5F83D5E17530
000078e5533dd950  call rax
000078e5533dd952  movaps xmm7, [rsp]
000078e5533dd956  add rsp, 0x30
000078e5533dd95a  vmovaps xmm0, [rsp]
000078e5533dd95f  vmovaps xmm1, [rsp+0x10]
000078e5533dd965  vmovaps xmm2, [rsp+0x20]
000078e5533dd96b  vmovaps xmm3, [rsp+0x30]
000078e5533dd971  vmovaps xmm4, [rsp+0x40]
000078e5533dd977  vmovaps xmm5, [rsp+0x50]
000078e5533dd97d  vmovaps xmm6, [rsp+0x60]
000078e5533dd983  vmovaps xmm8, [rsp+0x70]
000078e5533dd989  vmovaps xmm9, [rsp+0x80]
000078e5533dd992  vmovaps xmm10, [rsp+0x90]
000078e5533dd99b  vmovaps xmm11, [rsp+0xA0]
000078e5533dd9a4  vmovaps xmm12, [rsp+0xB0]
000078e5533dd9ad  vmovaps xmm13, [rsp+0xC0]
000078e5533dd9b6  vmovaps xmm14, [rsp+0xD0]
000078e5533dd9bf  vmovaps xmm15, [rsp+0xE0]
000078e5533dd9c8  add rsp, 0xF0
000078e5533dd9cf  pop r11
000078e5533dd9d1  pop r10
000078e5533dd9d3  pop r9
000078e5533dd9d5  pop r8
000078e5533dd9d7  pop rsi
000078e5533dd9d8  pop rdi
000078e5533dd9d9  pop rdx
000078e5533dd9da  pop rcx
000078e5533dd9db  pop rax
000078e5533dd9dc  add rsp, 0x08
000078e5533dd9e0  jmp 0x000078E5533DBE87
000078e5533dd9e5  sub rsp, 0x08
000078e5533dd9e9  push rax
000078e5533dd9ea  push rcx
000078e5533dd9eb  push rdx
000078e5533dd9ec  push rdi
000078e5533dd9ed  push rsi
000078e5533dd9ee  push r8
000078e5533dd9f0  push r9
000078e5533dd9f2  push r10
000078e5533dd9f4  push r11
000078e5533dd9f6  sub rsp, 0xF0
000078e5533dd9fd  vmovaps [rsp], xmm0
000078e5533dda02  vmovaps [rsp+0x10], xmm1
000078e5533dda08  vmovaps [rsp+0x20], xmm2
000078e5533dda0e  vmovaps [rsp+0x30], xmm3
000078e5533dda14  vmovaps [rsp+0x40], xmm5
000078e5533dda1a  vmovaps [rsp+0x50], xmm6
000078e5533dda20  vmovaps [rsp+0x60], xmm7
000078e5533dda26  vmovaps [rsp+0x70], xmm8
000078e5533dda2c  vmovaps [rsp+0x80], xmm9
000078e5533dda35  vmovaps [rsp+0x90], xmm10
000078e5533dda3e  vmovaps [rsp+0xA0], xmm11
000078e5533dda47  vmovaps [rsp+0xB0], xmm12
000078e5533dda50  vmovaps [rsp+0xC0], xmm13
000078e5533dda59  vmovaps [rsp+0xD0], xmm14
000078e5533dda62  vmovaps [rsp+0xE0], xmm15
000078e5533dda6b  sub rsp, 0x30
000078e5533dda6f  movaps [rsp], xmm4
000078e5533dda73  movaps [rsp+0x10], xmm15
000078e5533dda79  movaps [rsp+0x20], xmm9
000078e5533dda7f  lea rdi, [rsp]
000078e5533dda83  mov esi, 0x00
000078e5533dda88  mov rax, 0x5F83D5E17530
000078e5533dda92  call rax
000078e5533dda94  movaps xmm4, [rsp]
000078e5533dda98  add rsp, 0x30
000078e5533dda9c  vmovaps xmm0, [rsp]
000078e5533ddaa1  vmovaps xmm1, [rsp+0x10]
000078e5533ddaa7  vmovaps xmm2, [rsp+0x20]
000078e5533ddaad  vmovaps xmm3, [rsp+0x30]
000078e5533ddab3  vmovaps xmm5, [rsp+0x40]
000078e5533ddab9  vmovaps xmm6, [rsp+0x50]
000078e5533ddabf  vmovaps xmm7, [rsp+0x60]
000078e5533ddac5  vmovaps xmm8, [rsp+0x70]
000078e5533ddacb  vmovaps xmm9, [rsp+0x80]
000078e5533ddad4  vmovaps xmm10, [rsp+0x90]
000078e5533ddadd  vmovaps xmm11, [rsp+0xA0]
000078e5533ddae6  vmovaps xmm12, [rsp+0xB0]
000078e5533ddaef  vmovaps xmm13, [rsp+0xC0]
000078e5533ddaf8  vmovaps xmm14, [rsp+0xD0]
000078e5533ddb01  vmovaps xmm15, [rsp+0xE0]
000078e5533ddb0a  add rsp, 0xF0
000078e5533ddb11  pop r11
000078e5533ddb13  pop r10
000078e5533ddb15  pop r9
000078e5533ddb17  pop r8
000078e5533ddb19  pop rsi
000078e5533ddb1a  pop rdi
000078e5533ddb1b  pop rdx
000078e5533ddb1c  pop rcx
000078e5533ddb1d  pop rax
000078e5533ddb1e  add rsp, 0x08
000078e5533ddb22  jmp 0x000078E5533DBEAC
000078e5533ddb27  call 0x000078E5532C4620
000078e5533ddb2c  jmp 0x000078E5533DBEB9
000078e5533ddb31  sub rsp, 0x08
000078e5533ddb35  push rax
000078e5533ddb36  push rcx
000078e5533ddb37  push rdx
000078e5533ddb38  push rdi
000078e5533ddb39  push rsi
000078e5533ddb3a  push r8
000078e5533ddb3c  push r9
000078e5533ddb3e  push r10
000078e5533ddb40  push r11
000078e5533ddb42  sub rsp, 0xF0
000078e5533ddb49  vmovaps [rsp], xmm0
000078e5533ddb4e  vmovaps [rsp+0x10], xmm1
000078e5533ddb54  vmovaps [rsp+0x20], xmm2
000078e5533ddb5a  vmovaps [rsp+0x30], xmm4
000078e5533ddb60  vmovaps [rsp+0x40], xmm5
000078e5533ddb66  vmovaps [rsp+0x50], xmm6
000078e5533ddb6c  vmovaps [rsp+0x60], xmm7
000078e5533ddb72  vmovaps [rsp+0x70], xmm8
000078e5533ddb78  vmovaps [rsp+0x80], xmm9
000078e5533ddb81  vmovaps [rsp+0x90], xmm10
000078e5533ddb8a  vmovaps [rsp+0xA0], xmm11
000078e5533ddb93  vmovaps [rsp+0xB0], xmm12
000078e5533ddb9c  vmovaps [rsp+0xC0], xmm13
000078e5533ddba5  vmovaps [rsp+0xD0], xmm14
000078e5533ddbae  vmovaps [rsp+0xE0], xmm15
000078e5533ddbb7  sub rsp, 0x30
000078e5533ddbbb  movaps [rsp], xmm3
000078e5533ddbbf  movaps [rsp+0x10], xmm1
000078e5533ddbc4  movaps [rsp+0x20], xmm9
000078e5533ddbca  lea rdi, [rsp]
000078e5533ddbce  mov esi, 0x00
000078e5533ddbd3  mov rax, 0x5F83D5E17530
000078e5533ddbdd  call rax
000078e5533ddbdf  movaps xmm3, [rsp]
000078e5533ddbe3  add rsp, 0x30
000078e5533ddbe7  vmovaps xmm0, [rsp]
000078e5533ddbec  vmovaps xmm1, [rsp+0x10]
000078e5533ddbf2  vmovaps xmm2, [rsp+0x20]
000078e5533ddbf8  vmovaps xmm4, [rsp+0x30]
000078e5533ddbfe  vmovaps xmm5, [rsp+0x40]
000078e5533ddc04  vmovaps xmm6, [rsp+0x50]
000078e5533ddc0a  vmovaps xmm7, [rsp+0x60]
000078e5533ddc10  vmovaps xmm8, [rsp+0x70]
000078e5533ddc16  vmovaps xmm9, [rsp+0x80]
000078e5533ddc1f  vmovaps xmm10, [rsp+0x90]
000078e5533ddc28  vmovaps xmm11, [rsp+0xA0]
000078e5533ddc31  vmovaps xmm12, [rsp+0xB0]
000078e5533ddc3a  vmovaps xmm13, [rsp+0xC0]
000078e5533ddc43  vmovaps xmm14, [rsp+0xD0]
000078e5533ddc4c  vmovaps xmm15, [rsp+0xE0]
000078e5533ddc55  add rsp, 0xF0
000078e5533ddc5c  pop r11
000078e5533ddc5e  pop r10
000078e5533ddc60  pop r9
000078e5533ddc62  pop r8
000078e5533ddc64  pop rsi
000078e5533ddc65  pop rdi
000078e5533ddc66  pop rdx
000078e5533ddc67  pop rcx
000078e5533ddc68  pop rax
000078e5533ddc69  add rsp, 0x08
000078e5533ddc6d  jmp 0x000078E5533DBEF6
000078e5533ddc72  sub rsp, 0x08
000078e5533ddc76  push rax
000078e5533ddc77  push rcx
000078e5533ddc78  push rdx
000078e5533ddc79  push rdi
000078e5533ddc7a  push rsi
000078e5533ddc7b  push r8
000078e5533ddc7d  push r9
000078e5533ddc7f  push r10
000078e5533ddc81  push r11
000078e5533ddc83  sub rsp, 0xF0
000078e5533ddc8a  vmovaps [rsp], xmm0
000078e5533ddc8f  vmovaps [rsp+0x10], xmm2
000078e5533ddc95  vmovaps [rsp+0x20], xmm3
000078e5533ddc9b  vmovaps [rsp+0x30], xmm4
000078e5533ddca1  vmovaps [rsp+0x40], xmm5
000078e5533ddca7  vmovaps [rsp+0x50], xmm6
000078e5533ddcad  vmovaps [rsp+0x60], xmm7
000078e5533ddcb3  vmovaps [rsp+0x70], xmm8
000078e5533ddcb9  vmovaps [rsp+0x80], xmm9
000078e5533ddcc2  vmovaps [rsp+0x90], xmm10
000078e5533ddccb  vmovaps [rsp+0xA0], xmm11
000078e5533ddcd4  vmovaps [rsp+0xB0], xmm12
000078e5533ddcdd  vmovaps [rsp+0xC0], xmm13
000078e5533ddce6  vmovaps [rsp+0xD0], xmm14
000078e5533ddcef  vmovaps [rsp+0xE0], xmm15
000078e5533ddcf8  sub rsp, 0x30
000078e5533ddcfc  movaps [rsp], xmm1
000078e5533ddd00  movaps [rsp+0x10], xmm15
000078e5533ddd06  movaps [rsp+0x20], xmm9
000078e5533ddd0c  lea rdi, [rsp]
000078e5533ddd10  mov esi, 0x00
000078e5533ddd15  mov rax, 0x5F83D5E17530
000078e5533ddd1f  call rax
000078e5533ddd21  movaps xmm1, [rsp]
000078e5533ddd25  add rsp, 0x30
000078e5533ddd29  vmovaps xmm0, [rsp]
000078e5533ddd2e  vmovaps xmm2, [rsp+0x10]
000078e5533ddd34  vmovaps xmm3, [rsp+0x20]
000078e5533ddd3a  vmovaps xmm4, [rsp+0x30]
000078e5533ddd40  vmovaps xmm5, [rsp+0x40]
000078e5533ddd46  vmovaps xmm6, [rsp+0x50]
000078e5533ddd4c  vmovaps xmm7, [rsp+0x60]
000078e5533ddd52  vmovaps xmm8, [rsp+0x70]
000078e5533ddd58  vmovaps xmm9, [rsp+0x80]
000078e5533ddd61  vmovaps xmm10, [rsp+0x90]
000078e5533ddd6a  vmovaps xmm11, [rsp+0xA0]
000078e5533ddd73  vmovaps xmm12, [rsp+0xB0]
000078e5533ddd7c  vmovaps xmm13, [rsp+0xC0]
000078e5533ddd85  vmovaps xmm14, [rsp+0xD0]
000078e5533ddd8e  vmovaps xmm15, [rsp+0xE0]
000078e5533ddd97  add rsp, 0xF0
000078e5533ddd9e  pop r11
000078e5533ddda0  pop r10
000078e5533ddda2  pop r9
000078e5533ddda4  pop r8
000078e5533ddda6  pop rsi
000078e5533ddda7  pop rdi
000078e5533ddda8  pop rdx
000078e5533ddda9  pop rcx
000078e5533dddaa  pop rax
000078e5533dddab  add rsp, 0x08
000078e5533dddaf  jmp 0x000078E5533DBF7E
000078e5533dddb4  call 0x000078E5532C4620
000078e5533dddb9  jmp 0x000078E5533DBF8B
000078e5533dddbe  sub rsp, 0x08
000078e5533dddc2  push rax
000078e5533dddc3  push rcx
000078e5533dddc4  push rdx
000078e5533dddc5  push rdi
000078e5533dddc6  push rsi
000078e5533dddc7  push r8
000078e5533dddc9  push r9
000078e5533dddcb  push r10
000078e5533dddcd  push r11
000078e5533dddcf  sub rsp, 0xF0
000078e5533dddd6  vmovaps [rsp], xmm0
000078e5533ddddb  vmovaps [rsp+0x10], xmm2
000078e5533ddde1  vmovaps [rsp+0x20], xmm3
000078e5533ddde7  vmovaps [rsp+0x30], xmm4
000078e5533ddded  vmovaps [rsp+0x40], xmm5
000078e5533dddf3  vmovaps [rsp+0x50], xmm6
000078e5533dddf9  vmovaps [rsp+0x60], xmm7
000078e5533dddff  vmovaps [rsp+0x70], xmm8
000078e5533dde05  vmovaps [rsp+0x80], xmm9
000078e5533dde0e  vmovaps [rsp+0x90], xmm10
000078e5533dde17  vmovaps [rsp+0xA0], xmm11
000078e5533dde20  vmovaps [rsp+0xB0], xmm12
000078e5533dde29  vmovaps [rsp+0xC0], xmm13
000078e5533dde32  vmovaps [rsp+0xD0], xmm14
000078e5533dde3b  vmovaps [rsp+0xE0], xmm15
000078e5533dde44  sub rsp, 0x30
000078e5533dde48  movaps [rsp], xmm1
000078e5533dde4c  movaps [rsp+0x10], xmm5
000078e5533dde51  movaps [rsp+0x20], xmm7
000078e5533dde56  lea rdi, [rsp]
000078e5533dde5a  mov esi, 0x00
000078e5533dde5f  mov rax, 0x5F83D5E17530
000078e5533dde69  call rax
000078e5533dde6b  movaps xmm1, [rsp]
000078e5533dde6f  add rsp, 0x30
000078e5533dde73  vmovaps xmm0, [rsp]
000078e5533dde78  vmovaps xmm2, [rsp+0x10]
000078e5533dde7e  vmovaps xmm3, [rsp+0x20]
000078e5533dde84  vmovaps xmm4, [rsp+0x30]
000078e5533dde8a  vmovaps xmm5, [rsp+0x40]
000078e5533dde90  vmovaps xmm6, [rsp+0x50]
000078e5533dde96  vmovaps xmm7, [rsp+0x60]
000078e5533dde9c  vmovaps xmm8, [rsp+0x70]
000078e5533ddea2  vmovaps xmm9, [rsp+0x80]
000078e5533ddeab  vmovaps xmm10, [rsp+0x90]
000078e5533ddeb4  vmovaps xmm11, [rsp+0xA0]
000078e5533ddebd  vmovaps xmm12, [rsp+0xB0]
000078e5533ddec6  vmovaps xmm13, [rsp+0xC0]
000078e5533ddecf  vmovaps xmm14, [rsp+0xD0]
000078e5533dded8  vmovaps xmm15, [rsp+0xE0]
000078e5533ddee1  add rsp, 0xF0
000078e5533ddee8  pop r11
000078e5533ddeea  pop r10
000078e5533ddeec  pop r9
000078e5533ddeee  pop r8
000078e5533ddef0  pop rsi
000078e5533ddef1  pop rdi
000078e5533ddef2  pop rdx
000078e5533ddef3  pop rcx
000078e5533ddef4  pop rax
000078e5533ddef5  add rsp, 0x08
000078e5533ddef9  jmp 0x000078E5533DC030
000078e5533ddefe  sub rsp, 0x08
000078e5533ddf02  push rax
000078e5533ddf03  push rcx
000078e5533ddf04  push rdx
000078e5533ddf05  push rdi
000078e5533ddf06  push rsi
000078e5533ddf07  push r8
000078e5533ddf09  push r9
000078e5533ddf0b  push r10
000078e5533ddf0d  push r11
000078e5533ddf0f  sub rsp, 0xF0
000078e5533ddf16  vmovaps [rsp], xmm0
000078e5533ddf1b  vmovaps [rsp+0x10], xmm1
000078e5533ddf21  vmovaps [rsp+0x20], xmm2
000078e5533ddf27  vmovaps [rsp+0x30], xmm3
000078e5533ddf2d  vmovaps [rsp+0x40], xmm4
000078e5533ddf33  vmovaps [rsp+0x50], xmm5
000078e5533ddf39  vmovaps [rsp+0x60], xmm6
000078e5533ddf3f  vmovaps [rsp+0x70], xmm8
000078e5533ddf45  vmovaps [rsp+0x80], xmm9
000078e5533ddf4e  vmovaps [rsp+0x90], xmm10
000078e5533ddf57  vmovaps [rsp+0xA0], xmm11
000078e5533ddf60  vmovaps [rsp+0xB0], xmm12
000078e5533ddf69  vmovaps [rsp+0xC0], xmm13
000078e5533ddf72  vmovaps [rsp+0xD0], xmm14
000078e5533ddf7b  vmovaps [rsp+0xE0], xmm15
000078e5533ddf84  sub rsp, 0x30
000078e5533ddf88  movaps [rsp], xmm7
000078e5533ddf8c  movaps [rsp+0x10], xmm5
000078e5533ddf91  movaps [rsp+0x20], xmm15
000078e5533ddf97  lea rdi, [rsp]
000078e5533ddf9b  mov esi, 0x00
000078e5533ddfa0  mov rax, 0x5F83D5E17530
000078e5533ddfaa  call rax
000078e5533ddfac  movaps xmm7, [rsp]
000078e5533ddfb0  add rsp, 0x30
000078e5533ddfb4  vmovaps xmm0, [rsp]
000078e5533ddfb9  vmovaps xmm1, [rsp+0x10]
000078e5533ddfbf  vmovaps xmm2, [rsp+0x20]
000078e5533ddfc5  vmovaps xmm3, [rsp+0x30]
000078e5533ddfcb  vmovaps xmm4, [rsp+0x40]
000078e5533ddfd1  vmovaps xmm5, [rsp+0x50]
000078e5533ddfd7  vmovaps xmm6, [rsp+0x60]
000078e5533ddfdd  vmovaps xmm8, [rsp+0x70]
000078e5533ddfe3  vmovaps xmm9, [rsp+0x80]
000078e5533ddfec  vmovaps xmm10, [rsp+0x90]
000078e5533ddff5  vmovaps xmm11, [rsp+0xA0]
000078e5533ddffe  vmovaps xmm12, [rsp+0xB0]
000078e5533de007  vmovaps xmm13, [rsp+0xC0]
000078e5533de010  vmovaps xmm14, [rsp+0xD0]
000078e5533de019  vmovaps xmm15, [rsp+0xE0]
000078e5533de022  add rsp, 0xF0
000078e5533de029  pop r11
000078e5533de02b  pop r10
000078e5533de02d  pop r9
000078e5533de02f  pop r8
000078e5533de031  pop rsi
000078e5533de032  pop rdi
000078e5533de033  pop rdx
000078e5533de034  pop rcx
000078e5533de035  pop rax
000078e5533de036  add rsp, 0x08
000078e5533de03a  jmp 0x000078E5533DC066
000078e5533de03f  call 0x000078E5532B52F0
000078e5533de044  jmp 0x000078E5533DC073
000078e5533de049  sub rsp, 0x08
000078e5533de04d  push rax
000078e5533de04e  push rcx
000078e5533de04f  push rdx
000078e5533de050  push rdi
000078e5533de051  push rsi
000078e5533de052  push r8
000078e5533de054  push r9
000078e5533de056  push r10
000078e5533de058  push r11
000078e5533de05a  sub rsp, 0xF0
000078e5533de061  vmovaps [rsp], xmm0
000078e5533de066  vmovaps [rsp+0x10], xmm1
000078e5533de06c  vmovaps [rsp+0x20], xmm2
000078e5533de072  vmovaps [rsp+0x30], xmm3
000078e5533de078  vmovaps [rsp+0x40], xmm4
000078e5533de07e  vmovaps [rsp+0x50], xmm5
000078e5533de084  vmovaps [rsp+0x60], xmm6
000078e5533de08a  vmovaps [rsp+0x70], xmm7
000078e5533de090  vmovaps [rsp+0x80], xmm8
000078e5533de099  vmovaps [rsp+0x90], xmm9
000078e5533de0a2  vmovaps [rsp+0xA0], xmm10
000078e5533de0ab  vmovaps [rsp+0xB0], xmm11
000078e5533de0b4  vmovaps [rsp+0xC0], xmm12
000078e5533de0bd  vmovaps [rsp+0xD0], xmm13
000078e5533de0c6  vmovaps [rsp+0xE0], xmm14
000078e5533de0cf  sub rsp, 0x30
000078e5533de0d3  movaps [rsp], xmm15
000078e5533de0d8  movaps [rsp+0x10], xmm5
000078e5533de0dd  movaps [rsp+0x20], xmm3
000078e5533de0e2  lea rdi, [rsp]
000078e5533de0e6  mov esi, 0x00
000078e5533de0eb  mov rax, 0x5F83D5E17530
000078e5533de0f5  call rax
000078e5533de0f7  movaps xmm15, [rsp]
000078e5533de0fc  add rsp, 0x30
000078e5533de100  vmovaps xmm0, [rsp]
000078e5533de105  vmovaps xmm1, [rsp+0x10]
000078e5533de10b  vmovaps xmm2, [rsp+0x20]
000078e5533de111  vmovaps xmm3, [rsp+0x30]
000078e5533de117  vmovaps xmm4, [rsp+0x40]
000078e5533de11d  vmovaps xmm5, [rsp+0x50]
000078e5533de123  vmovaps xmm6, [rsp+0x60]
000078e5533de129  vmovaps xmm7, [rsp+0x70]
000078e5533de12f  vmovaps xmm8, [rsp+0x80]
000078e5533de138  vmovaps xmm9, [rsp+0x90]
000078e5533de141  vmovaps xmm10, [rsp+0xA0]
000078e5533de14a  vmovaps xmm11, [rsp+0xB0]
000078e5533de153  vmovaps xmm12, [rsp+0xC0]
000078e5533de15c  vmovaps xmm13, [rsp+0xD0]
000078e5533de165  vmovaps xmm14, [rsp+0xE0]
000078e5533de16e  add rsp, 0xF0
000078e5533de175  pop r11
000078e5533de177  pop r10
000078e5533de179  pop r9
000078e5533de17b  pop r8
000078e5533de17d  pop rsi
000078e5533de17e  pop rdi
000078e5533de17f  pop rdx
000078e5533de180  pop rcx
000078e5533de181  pop rax
000078e5533de182  add rsp, 0x08
000078e5533de186  jmp 0x000078E5533DC099
000078e5533de18b  sub rsp, 0x08
000078e5533de18f  push rax
000078e5533de190  push rcx
000078e5533de191  push rdx
000078e5533de192  push rdi
000078e5533de193  push rsi
000078e5533de194  push r8
000078e5533de196  push r9
000078e5533de198  push r10
000078e5533de19a  push r11
000078e5533de19c  sub rsp, 0xF0
000078e5533de1a3  vmovaps [rsp], xmm0
000078e5533de1a8  vmovaps [rsp+0x10], xmm2
000078e5533de1ae  vmovaps [rsp+0x20], xmm3
000078e5533de1b4  vmovaps [rsp+0x30], xmm4
000078e5533de1ba  vmovaps [rsp+0x40], xmm5
000078e5533de1c0  vmovaps [rsp+0x50], xmm6
000078e5533de1c6  vmovaps [rsp+0x60], xmm7
000078e5533de1cc  vmovaps [rsp+0x70], xmm8
000078e5533de1d2  vmovaps [rsp+0x80], xmm9
000078e5533de1db  vmovaps [rsp+0x90], xmm10
000078e5533de1e4  vmovaps [rsp+0xA0], xmm11
000078e5533de1ed  vmovaps [rsp+0xB0], xmm12
000078e5533de1f6  vmovaps [rsp+0xC0], xmm13
000078e5533de1ff  vmovaps [rsp+0xD0], xmm14
000078e5533de208  vmovaps [rsp+0xE0], xmm15
000078e5533de211  sub rsp, 0x30
000078e5533de215  movaps [rsp], xmm1
000078e5533de219  movaps [rsp+0x10], xmm5
000078e5533de21e  movaps [rsp+0x20], xmm4
000078e5533de223  lea rdi, [rsp]
000078e5533de227  mov esi, 0x00
000078e5533de22c  mov rax, 0x5F83D5E17530
000078e5533de236  call rax
000078e5533de238  movaps xmm1, [rsp]
000078e5533de23c  add rsp, 0x30
000078e5533de240  vmovaps xmm0, [rsp]
000078e5533de245  vmovaps xmm2, [rsp+0x10]
000078e5533de24b  vmovaps xmm3, [rsp+0x20]
000078e5533de251  vmovaps xmm4, [rsp+0x30]
000078e5533de257  vmovaps xmm5, [rsp+0x40]
000078e5533de25d  vmovaps xmm6, [rsp+0x50]
000078e5533de263  vmovaps xmm7, [rsp+0x60]
000078e5533de269  vmovaps xmm8, [rsp+0x70]
000078e5533de26f  vmovaps xmm9, [rsp+0x80]
000078e5533de278  vmovaps xmm10, [rsp+0x90]
000078e5533de281  vmovaps xmm11, [rsp+0xA0]
000078e5533de28a  vmovaps xmm12, [rsp+0xB0]
000078e5533de293  vmovaps xmm13, [rsp+0xC0]
000078e5533de29c  vmovaps xmm14, [rsp+0xD0]
000078e5533de2a5  vmovaps xmm15, [rsp+0xE0]
000078e5533de2ae  add rsp, 0xF0
000078e5533de2b5  pop r11
000078e5533de2b7  pop r10
000078e5533de2b9  pop r9
000078e5533de2bb  pop r8
000078e5533de2bd  pop rsi
000078e5533de2be  pop rdi
000078e5533de2bf  pop rdx
000078e5533de2c0  pop rcx
000078e5533de2c1  pop rax
000078e5533de2c2  add rsp, 0x08
000078e5533de2c6  jmp 0x000078E5533DC0B9
000078e5533de2cb  sub rsp, 0x08
000078e5533de2cf  push rax
000078e5533de2d0  push rcx
000078e5533de2d1  push rdx
000078e5533de2d2  push rdi
000078e5533de2d3  push rsi
000078e5533de2d4  push r8
000078e5533de2d6  push r9
000078e5533de2d8  push r10
000078e5533de2da  push r11
000078e5533de2dc  sub rsp, 0xF0
000078e5533de2e3  vmovaps [rsp], xmm0
000078e5533de2e8  vmovaps [rsp+0x10], xmm1
000078e5533de2ee  vmovaps [rsp+0x20], xmm2
000078e5533de2f4  vmovaps [rsp+0x30], xmm3
000078e5533de2fa  vmovaps [rsp+0x40], xmm5
000078e5533de300  vmovaps [rsp+0x50], xmm6
000078e5533de306  vmovaps [rsp+0x60], xmm7
000078e5533de30c  vmovaps [rsp+0x70], xmm8
000078e5533de312  vmovaps [rsp+0x80], xmm9
000078e5533de31b  vmovaps [rsp+0x90], xmm10
000078e5533de324  vmovaps [rsp+0xA0], xmm11
000078e5533de32d  vmovaps [rsp+0xB0], xmm12
000078e5533de336  vmovaps [rsp+0xC0], xmm13
000078e5533de33f  vmovaps [rsp+0xD0], xmm14
000078e5533de348  vmovaps [rsp+0xE0], xmm15
000078e5533de351  sub rsp, 0x30
000078e5533de355  movaps [rsp], xmm4
000078e5533de359  movaps [rsp+0x10], xmm3
000078e5533de35e  movaps [rsp+0x20], xmm5
000078e5533de363  lea rdi, [rsp]
000078e5533de367  mov esi, 0x00
000078e5533de36c  mov rax, 0x5F83D5E17530
000078e5533de376  call rax
000078e5533de378  movaps xmm4, [rsp]
000078e5533de37c  add rsp, 0x30
000078e5533de380  vmovaps xmm0, [rsp]
000078e5533de385  vmovaps xmm1, [rsp+0x10]
000078e5533de38b  vmovaps xmm2, [rsp+0x20]
000078e5533de391  vmovaps xmm3, [rsp+0x30]
000078e5533de397  vmovaps xmm5, [rsp+0x40]
000078e5533de39d  vmovaps xmm6, [rsp+0x50]
000078e5533de3a3  vmovaps xmm7, [rsp+0x60]
000078e5533de3a9  vmovaps xmm8, [rsp+0x70]
000078e5533de3af  vmovaps xmm9, [rsp+0x80]
000078e5533de3b8  vmovaps xmm10, [rsp+0x90]
000078e5533de3c1  vmovaps xmm11, [rsp+0xA0]
000078e5533de3ca  vmovaps xmm12, [rsp+0xB0]
000078e5533de3d3  vmovaps xmm13, [rsp+0xC0]
000078e5533de3dc  vmovaps xmm14, [rsp+0xD0]
000078e5533de3e5  vmovaps xmm15, [rsp+0xE0]
000078e5533de3ee  add rsp, 0xF0
000078e5533de3f5  pop r11
000078e5533de3f7  pop r10
000078e5533de3f9  pop r9
000078e5533de3fb  pop r8
000078e5533de3fd  pop rsi
000078e5533de3fe  pop rdi
000078e5533de3ff  pop rdx
000078e5533de400  pop rcx
000078e5533de401  pop rax
000078e5533de402  add rsp, 0x08
000078e5533de406  jmp 0x000078E5533DC107
000078e5533de40b  call 0x000078E5532B52F0
000078e5533de410  jmp 0x000078E5533DC114
000078e5533de415  sub rsp, 0x08
000078e5533de419  push rax
000078e5533de41a  push rcx
000078e5533de41b  push rdx
000078e5533de41c  push rdi
000078e5533de41d  push rsi
000078e5533de41e  push r8
000078e5533de420  push r9
000078e5533de422  push r10
000078e5533de424  push r11
000078e5533de426  sub rsp, 0xF0
000078e5533de42d  vmovaps [rsp], xmm0
000078e5533de432  vmovaps [rsp+0x10], xmm1
000078e5533de438  vmovaps [rsp+0x20], xmm2
000078e5533de43e  vmovaps [rsp+0x30], xmm3
000078e5533de444  vmovaps [rsp+0x40], xmm4
000078e5533de44a  vmovaps [rsp+0x50], xmm6
000078e5533de450  vmovaps [rsp+0x60], xmm7
000078e5533de456  vmovaps [rsp+0x70], xmm8
000078e5533de45c  vmovaps [rsp+0x80], xmm9
000078e5533de465  vmovaps [rsp+0x90], xmm10
000078e5533de46e  vmovaps [rsp+0xA0], xmm11
000078e5533de477  vmovaps [rsp+0xB0], xmm12
000078e5533de480  vmovaps [rsp+0xC0], xmm13
000078e5533de489  vmovaps [rsp+0xD0], xmm14
000078e5533de492  vmovaps [rsp+0xE0], xmm15
000078e5533de49b  sub rsp, 0x30
000078e5533de49f  movaps [rsp], xmm5
000078e5533de4a3  movaps [rsp+0x10], xmm6
000078e5533de4a8  movaps [rsp+0x20], xmm3
000078e5533de4ad  lea rdi, [rsp]
000078e5533de4b1  mov esi, 0x00
000078e5533de4b6  mov rax, 0x5F83D5E17530
000078e5533de4c0  call rax
000078e5533de4c2  movaps xmm5, [rsp]
000078e5533de4c6  add rsp, 0x30
000078e5533de4ca  vmovaps xmm0, [rsp]
000078e5533de4cf  vmovaps xmm1, [rsp+0x10]
000078e5533de4d5  vmovaps xmm2, [rsp+0x20]
000078e5533de4db  vmovaps xmm3, [rsp+0x30]
000078e5533de4e1  vmovaps xmm4, [rsp+0x40]
000078e5533de4e7  vmovaps xmm6, [rsp+0x50]
000078e5533de4ed  vmovaps xmm7, [rsp+0x60]
000078e5533de4f3  vmovaps xmm8, [rsp+0x70]
000078e5533de4f9  vmovaps xmm9, [rsp+0x80]
000078e5533de502  vmovaps xmm10, [rsp+0x90]
000078e5533de50b  vmovaps xmm11, [rsp+0xA0]
000078e5533de514  vmovaps xmm12, [rsp+0xB0]
000078e5533de51d  vmovaps xmm13, [rsp+0xC0]
000078e5533de526  vmovaps xmm14, [rsp+0xD0]
000078e5533de52f  vmovaps xmm15, [rsp+0xE0]
000078e5533de538  add rsp, 0xF0
000078e5533de53f  pop r11
000078e5533de541  pop r10
000078e5533de543  pop r9
000078e5533de545  pop r8
000078e5533de547  pop rsi
000078e5533de548  pop rdi
000078e5533de549  pop rdx
000078e5533de54a  pop rcx
000078e5533de54b  pop rax
000078e5533de54c  add rsp, 0x08
000078e5533de550  jmp 0x000078E5533DC13A
000078e5533de555  sub rsp, 0x08
000078e5533de559  push rax
000078e5533de55a  push rcx
000078e5533de55b  push rdx
000078e5533de55c  push rdi
000078e5533de55d  push rsi
000078e5533de55e  push r8
000078e5533de560  push r9
000078e5533de562  push r10
000078e5533de564  push r11
000078e5533de566  sub rsp, 0xF0
000078e5533de56d  vmovaps [rsp], xmm0
000078e5533de572  vmovaps [rsp+0x10], xmm1
000078e5533de578  vmovaps [rsp+0x20], xmm2
000078e5533de57e  vmovaps [rsp+0x30], xmm3
000078e5533de584  vmovaps [rsp+0x40], xmm4
000078e5533de58a  vmovaps [rsp+0x50], xmm5
000078e5533de590  vmovaps [rsp+0x60], xmm7
000078e5533de596  vmovaps [rsp+0x70], xmm8
000078e5533de59c  vmovaps [rsp+0x80], xmm9
000078e5533de5a5  vmovaps [rsp+0x90], xmm10
000078e5533de5ae  vmovaps [rsp+0xA0], xmm11
000078e5533de5b7  vmovaps [rsp+0xB0], xmm12
000078e5533de5c0  vmovaps [rsp+0xC0], xmm13
000078e5533de5c9  vmovaps [rsp+0xD0], xmm14
000078e5533de5d2  vmovaps [rsp+0xE0], xmm15
000078e5533de5db  sub rsp, 0x30
000078e5533de5df  movaps [rsp], xmm6
000078e5533de5e3  movaps [rsp+0x10], xmm9
000078e5533de5e9  movaps [rsp+0x20], xmm1
000078e5533de5ee  lea rdi, [rsp]
000078e5533de5f2  mov esi, 0x00
000078e5533de5f7  mov rax, 0x5F83D5E17530
000078e5533de601  call rax
000078e5533de603  movaps xmm6, [rsp]
000078e5533de607  add rsp, 0x30
000078e5533de60b  vmovaps xmm0, [rsp]
000078e5533de610  vmovaps xmm1, [rsp+0x10]
000078e5533de616  vmovaps xmm2, [rsp+0x20]
000078e5533de61c  vmovaps xmm3, [rsp+0x30]
000078e5533de622  vmovaps xmm4, [rsp+0x40]
000078e5533de628  vmovaps xmm5, [rsp+0x50]
000078e5533de62e  vmovaps xmm7, [rsp+0x60]
000078e5533de634  vmovaps xmm8, [rsp+0x70]
000078e5533de63a  vmovaps xmm9, [rsp+0x80]
000078e5533de643  vmovaps xmm10, [rsp+0x90]
000078e5533de64c  vmovaps xmm11, [rsp+0xA0]
000078e5533de655  vmovaps xmm12, [rsp+0xB0]
000078e5533de65e  vmovaps xmm13, [rsp+0xC0]
000078e5533de667  vmovaps xmm14, [rsp+0xD0]
000078e5533de670  vmovaps xmm15, [rsp+0xE0]
000078e5533de679  add rsp, 0xF0
000078e5533de680  pop r11
000078e5533de682  pop r10
000078e5533de684  pop r9
000078e5533de686  pop r8
000078e5533de688  pop rsi
000078e5533de689  pop rdi
000078e5533de68a  pop rdx
000078e5533de68b  pop rcx
000078e5533de68c  pop rax
000078e5533de68d  add rsp, 0x08
000078e5533de691  jmp 0x000078E5533DC15E
000078e5533de696  sub rsp, 0x08
000078e5533de69a  push rax
000078e5533de69b  push rcx
000078e5533de69c  push rdx
000078e5533de69d  push rdi
000078e5533de69e  push rsi
000078e5533de69f  push r8
000078e5533de6a1  push r9
000078e5533de6a3  push r10
000078e5533de6a5  push r11
000078e5533de6a7  sub rsp, 0xF0
000078e5533de6ae  vmovaps [rsp], xmm0
000078e5533de6b3  vmovaps [rsp+0x10], xmm1
000078e5533de6b9  vmovaps [rsp+0x20], xmm2
000078e5533de6bf  vmovaps [rsp+0x30], xmm3
000078e5533de6c5  vmovaps [rsp+0x40], xmm4
000078e5533de6cb  vmovaps [rsp+0x50], xmm5
000078e5533de6d1  vmovaps [rsp+0x60], xmm6
000078e5533de6d7  vmovaps [rsp+0x70], xmm7
000078e5533de6dd  vmovaps [rsp+0x80], xmm8
000078e5533de6e6  vmovaps [rsp+0x90], xmm10
000078e5533de6ef  vmovaps [rsp+0xA0], xmm11
000078e5533de6f8  vmovaps [rsp+0xB0], xmm12
000078e5533de701  vmovaps [rsp+0xC0], xmm13
000078e5533de70a  vmovaps [rsp+0xD0], xmm14
000078e5533de713  vmovaps [rsp+0xE0], xmm15
000078e5533de71c  sub rsp, 0x30
000078e5533de720  movaps [rsp], xmm9
000078e5533de725  movaps [rsp+0x10], xmm3
000078e5533de72a  movaps [rsp+0x20], xmm1
000078e5533de72f  lea rdi, [rsp]
000078e5533de733  mov esi, 0x00
000078e5533de738  mov rax, 0x5F83D5E17530
000078e5533de742  call rax
000078e5533de744  movaps xmm9, [rsp]
000078e5533de749  add rsp, 0x30
000078e5533de74d  vmovaps xmm0, [rsp]
000078e5533de752  vmovaps xmm1, [rsp+0x10]
000078e5533de758  vmovaps xmm2, [rsp+0x20]
000078e5533de75e  vmovaps xmm3, [rsp+0x30]
000078e5533de764  vmovaps xmm4, [rsp+0x40]
000078e5533de76a  vmovaps xmm5, [rsp+0x50]
000078e5533de770  vmovaps xmm6, [rsp+0x60]
000078e5533de776  vmovaps xmm7, [rsp+0x70]
000078e5533de77c  vmovaps xmm8, [rsp+0x80]
000078e5533de785  vmovaps xmm10, [rsp+0x90]
000078e5533de78e  vmovaps xmm11, [rsp+0xA0]
000078e5533de797  vmovaps xmm12, [rsp+0xB0]
000078e5533de7a0  vmovaps xmm13, [rsp+0xC0]
000078e5533de7a9  vmovaps xmm14, [rsp+0xD0]
000078e5533de7b2  vmovaps xmm15, [rsp+0xE0]
000078e5533de7bb  add rsp, 0xF0
000078e5533de7c2  pop r11
000078e5533de7c4  pop r10
000078e5533de7c6  pop r9
000078e5533de7c8  pop r8
000078e5533de7ca  pop rsi
000078e5533de7cb  pop rdi
000078e5533de7cc  pop rdx
000078e5533de7cd  pop rcx
000078e5533de7ce  pop rax
000078e5533de7cf  add rsp, 0x08
000078e5533de7d3  jmp 0x000078E5533DC1AA
000078e5533de7d8  call 0x000078E5532B52F0
000078e5533de7dd  jmp 0x000078E5533DC1B7
000078e5533de7e2  sub rsp, 0x08
000078e5533de7e6  push rax
000078e5533de7e7  push rcx
000078e5533de7e8  push rdx
000078e5533de7e9  push rdi
000078e5533de7ea  push rsi
000078e5533de7eb  push r8
000078e5533de7ed  push r9
000078e5533de7ef  push r10
000078e5533de7f1  push r11
000078e5533de7f3  sub rsp, 0xF0
000078e5533de7fa  vmovaps [rsp], xmm0
000078e5533de7ff  vmovaps [rsp+0x10], xmm1
000078e5533de805  vmovaps [rsp+0x20], xmm2
000078e5533de80b  vmovaps [rsp+0x30], xmm3
000078e5533de811  vmovaps [rsp+0x40], xmm4
000078e5533de817  vmovaps [rsp+0x50], xmm5
000078e5533de81d  vmovaps [rsp+0x60], xmm6
000078e5533de823  vmovaps [rsp+0x70], xmm7
000078e5533de829  vmovaps [rsp+0x80], xmm8
000078e5533de832  vmovaps [rsp+0x90], xmm9
000078e5533de83b  vmovaps [rsp+0xA0], xmm10
000078e5533de844  vmovaps [rsp+0xB0], xmm11
000078e5533de84d  vmovaps [rsp+0xC0], xmm12
000078e5533de856  vmovaps [rsp+0xD0], xmm13
000078e5533de85f  vmovaps [rsp+0xE0], xmm14
000078e5533de868  sub rsp, 0x30
000078e5533de86c  movaps [rsp], xmm15
000078e5533de871  movaps [rsp+0x10], xmm3
000078e5533de876  movaps [rsp+0x20], xmm7
000078e5533de87b  lea rdi, [rsp]
000078e5533de87f  mov esi, 0x00
000078e5533de884  mov rax, 0x5F83D5E17530
000078e5533de88e  call rax
000078e5533de890  movaps xmm15, [rsp]
000078e5533de895  add rsp, 0x30
000078e5533de899  vmovaps xmm0, [rsp]
000078e5533de89e  vmovaps xmm1, [rsp+0x10]
000078e5533de8a4  vmovaps xmm2, [rsp+0x20]
000078e5533de8aa  vmovaps xmm3, [rsp+0x30]
000078e5533de8b0  vmovaps xmm4, [rsp+0x40]
000078e5533de8b6  vmovaps xmm5, [rsp+0x50]
000078e5533de8bc  vmovaps xmm6, [rsp+0x60]
000078e5533de8c2  vmovaps xmm7, [rsp+0x70]
000078e5533de8c8  vmovaps xmm8, [rsp+0x80]
000078e5533de8d1  vmovaps xmm9, [rsp+0x90]
000078e5533de8da  vmovaps xmm10, [rsp+0xA0]
000078e5533de8e3  vmovaps xmm11, [rsp+0xB0]
000078e5533de8ec  vmovaps xmm12, [rsp+0xC0]
000078e5533de8f5  vmovaps xmm13, [rsp+0xD0]
000078e5533de8fe  vmovaps xmm14, [rsp+0xE0]
000078e5533de907  add rsp, 0xF0
000078e5533de90e  pop r11
000078e5533de910  pop r10
000078e5533de912  pop r9
000078e5533de914  pop r8
000078e5533de916  pop rsi
000078e5533de917  pop rdi
000078e5533de918  pop rdx
000078e5533de919  pop rcx
000078e5533de91a  pop rax
000078e5533de91b  add rsp, 0x08
000078e5533de91f  jmp 0x000078E5533DC1E3
000078e5533de924  sub rsp, 0x08
000078e5533de928  push rax
000078e5533de929  push rcx
000078e5533de92a  push rdx
000078e5533de92b  push rdi
000078e5533de92c  push rsi
000078e5533de92d  push r8
000078e5533de92f  push r9
000078e5533de931  push r10
000078e5533de933  push r11
000078e5533de935  sub rsp, 0xF0
000078e5533de93c  vmovaps [rsp], xmm0
000078e5533de941  vmovaps [rsp+0x10], xmm1
000078e5533de947  vmovaps [rsp+0x20], xmm2
000078e5533de94d  vmovaps [rsp+0x30], xmm4
000078e5533de953  vmovaps [rsp+0x40], xmm5
000078e5533de959  vmovaps [rsp+0x50], xmm6
000078e5533de95f  vmovaps [rsp+0x60], xmm7
000078e5533de965  vmovaps [rsp+0x70], xmm8
000078e5533de96b  vmovaps [rsp+0x80], xmm9
000078e5533de974  vmovaps [rsp+0x90], xmm10
000078e5533de97d  vmovaps [rsp+0xA0], xmm11
000078e5533de986  vmovaps [rsp+0xB0], xmm12
000078e5533de98f  vmovaps [rsp+0xC0], xmm13
000078e5533de998  vmovaps [rsp+0xD0], xmm14
000078e5533de9a1  vmovaps [rsp+0xE0], xmm15
000078e5533de9aa  sub rsp, 0x30
000078e5533de9ae  movaps [rsp], xmm3
000078e5533de9b2  movaps [rsp+0x10], xmm1
000078e5533de9b7  movaps [rsp+0x20], xmm15
000078e5533de9bd  lea rdi, [rsp]
000078e5533de9c1  mov esi, 0x00
000078e5533de9c6  mov rax, 0x5F83D5E17530
000078e5533de9d0  call rax
000078e5533de9d2  movaps xmm3, [rsp]
000078e5533de9d6  add rsp, 0x30
000078e5533de9da  vmovaps xmm0, [rsp]
000078e5533de9df  vmovaps xmm1, [rsp+0x10]
000078e5533de9e5  vmovaps xmm2, [rsp+0x20]
000078e5533de9eb  vmovaps xmm4, [rsp+0x30]
000078e5533de9f1  vmovaps xmm5, [rsp+0x40]
000078e5533de9f7  vmovaps xmm6, [rsp+0x50]
000078e5533de9fd  vmovaps xmm7, [rsp+0x60]
000078e5533dea03  vmovaps xmm8, [rsp+0x70]
000078e5533dea09  vmovaps xmm9, [rsp+0x80]
000078e5533dea12  vmovaps xmm10, [rsp+0x90]
000078e5533dea1b  vmovaps xmm11, [rsp+0xA0]
000078e5533dea24  vmovaps xmm12, [rsp+0xB0]
000078e5533dea2d  vmovaps xmm13, [rsp+0xC0]
000078e5533dea36  vmovaps xmm14, [rsp+0xD0]
000078e5533dea3f  vmovaps xmm15, [rsp+0xE0]
000078e5533dea48  add rsp, 0xF0
000078e5533dea4f  pop r11
000078e5533dea51  pop r10
000078e5533dea53  pop r9
000078e5533dea55  pop r8
000078e5533dea57  pop rsi
000078e5533dea58  pop rdi
000078e5533dea59  pop rdx
000078e5533dea5a  pop rcx
000078e5533dea5b  pop rax
000078e5533dea5c  add rsp, 0x08
000078e5533dea60  jmp 0x000078E5533DC272
000078e5533dea65  call 0x000078E5532B52F0
000078e5533dea6a  jmp 0x000078E5533DC27C
000078e5533dea6f  sub rsp, 0x08
000078e5533dea73  push rax
000078e5533dea74  push rcx
000078e5533dea75  push rdx
000078e5533dea76  push rdi
000078e5533dea77  push rsi
000078e5533dea78  push r8
000078e5533dea7a  push r9
000078e5533dea7c  push r10
000078e5533dea7e  push r11
000078e5533dea80  sub rsp, 0xF0
000078e5533dea87  vmovaps [rsp], xmm0
000078e5533dea8c  vmovaps [rsp+0x10], xmm1
000078e5533dea92  vmovaps [rsp+0x20], xmm2
000078e5533dea98  vmovaps [rsp+0x30], xmm3
000078e5533dea9e  vmovaps [rsp+0x40], xmm4
000078e5533deaa4  vmovaps [rsp+0x50], xmm5
000078e5533deaaa  vmovaps [rsp+0x60], xmm6
000078e5533deab0  vmovaps [rsp+0x70], xmm7
000078e5533deab6  vmovaps [rsp+0x80], xmm8
000078e5533deabf  vmovaps [rsp+0x90], xmm9
000078e5533deac8  vmovaps [rsp+0xA0], xmm10
000078e5533dead1  vmovaps [rsp+0xB0], xmm11
000078e5533deada  vmovaps [rsp+0xC0], xmm12
000078e5533deae3  vmovaps [rsp+0xD0], xmm13
000078e5533deaec  vmovaps [rsp+0xE0], xmm14
000078e5533deaf5  sub rsp, 0x30
000078e5533deaf9  movaps [rsp], xmm15
000078e5533deafe  movaps [rsp+0x10], xmm14
000078e5533deb04  movaps [rsp+0x20], xmm4
000078e5533deb09  lea rdi, [rsp]
000078e5533deb0d  mov esi, 0x00
000078e5533deb12  mov rax, 0x5F83D5E17530
000078e5533deb1c  call rax
000078e5533deb1e  movaps xmm15, [rsp]
000078e5533deb23  add rsp, 0x30
000078e5533deb27  vmovaps xmm0, [rsp]
000078e5533deb2c  vmovaps xmm1, [rsp+0x10]
000078e5533deb32  vmovaps xmm2, [rsp+0x20]
000078e5533deb38  vmovaps xmm3, [rsp+0x30]
000078e5533deb3e  vmovaps xmm4, [rsp+0x40]
000078e5533deb44  vmovaps xmm5, [rsp+0x50]
000078e5533deb4a  vmovaps xmm6, [rsp+0x60]
000078e5533deb50  vmovaps xmm7, [rsp+0x70]
000078e5533deb56  vmovaps xmm8, [rsp+0x80]
000078e5533deb5f  vmovaps xmm9, [rsp+0x90]
000078e5533deb68  vmovaps xmm10, [rsp+0xA0]
000078e5533deb71  vmovaps xmm11, [rsp+0xB0]
000078e5533deb7a  vmovaps xmm12, [rsp+0xC0]
000078e5533deb83  vmovaps xmm13, [rsp+0xD0]
000078e5533deb8c  vmovaps xmm14, [rsp+0xE0]
000078e5533deb95  add rsp, 0xF0
000078e5533deb9c  pop r11
000078e5533deb9e  pop r10
000078e5533deba0  pop r9
000078e5533deba2  pop r8
000078e5533deba4  pop rsi
000078e5533deba5  pop rdi
000078e5533deba6  pop rdx
000078e5533deba7  pop rcx
000078e5533deba8  pop rax
000078e5533deba9  add rsp, 0x08
000078e5533debad  jmp 0x000078E5533DC2AA
000078e5533debb2  sub rsp, 0x08
000078e5533debb6  push rax
000078e5533debb7  push rcx
000078e5533debb8  push rdx
000078e5533debb9  push rdi
000078e5533debba  push rsi
000078e5533debbb  push r8
000078e5533debbd  push r9
000078e5533debbf  push r10
000078e5533debc1  push r11
000078e5533debc3  sub rsp, 0xF0
000078e5533debca  vmovaps [rsp], xmm0
000078e5533debcf  vmovaps [rsp+0x10], xmm1
000078e5533debd5  vmovaps [rsp+0x20], xmm2
000078e5533debdb  vmovaps [rsp+0x30], xmm3
000078e5533debe1  vmovaps [rsp+0x40], xmm4
000078e5533debe7  vmovaps [rsp+0x50], xmm5
000078e5533debed  vmovaps [rsp+0x60], xmm6
000078e5533debf3  vmovaps [rsp+0x70], xmm7
000078e5533debf9  vmovaps [rsp+0x80], xmm8
000078e5533dec02  vmovaps [rsp+0x90], xmm9
000078e5533dec0b  vmovaps [rsp+0xA0], xmm10
000078e5533dec14  vmovaps [rsp+0xB0], xmm11
000078e5533dec1d  vmovaps [rsp+0xC0], xmm12
000078e5533dec26  vmovaps [rsp+0xD0], xmm13
000078e5533dec2f  vmovaps [rsp+0xE0], xmm15
000078e5533dec38  sub rsp, 0x30
000078e5533dec3c  movaps [rsp], xmm14
000078e5533dec41  movaps [rsp+0x10], xmm2
000078e5533dec46  movaps [rsp+0x20], xmm1
000078e5533dec4b  lea rdi, [rsp]
000078e5533dec4f  mov esi, 0x00
000078e5533dec54  mov rax, 0x5F83D5E17530
000078e5533dec5e  call rax
000078e5533dec60  movaps xmm14, [rsp]
000078e5533dec65  add rsp, 0x30
000078e5533dec69  vmovaps xmm0, [rsp]
000078e5533dec6e  vmovaps xmm1, [rsp+0x10]
000078e5533dec74  vmovaps xmm2, [rsp+0x20]
000078e5533dec7a  vmovaps xmm3, [rsp+0x30]
000078e5533dec80  vmovaps xmm4, [rsp+0x40]
000078e5533dec86  vmovaps xmm5, [rsp+0x50]
000078e5533dec8c  vmovaps xmm6, [rsp+0x60]
000078e5533dec92  vmovaps xmm7, [rsp+0x70]
000078e5533dec98  vmovaps xmm8, [rsp+0x80]
000078e5533deca1  vmovaps xmm9, [rsp+0x90]
000078e5533decaa  vmovaps xmm10, [rsp+0xA0]
000078e5533decb3  vmovaps xmm11, [rsp+0xB0]
000078e5533decbc  vmovaps xmm12, [rsp+0xC0]
000078e5533decc5  vmovaps xmm13, [rsp+0xD0]
000078e5533decce  vmovaps xmm15, [rsp+0xE0]
000078e5533decd7  add rsp, 0xF0
000078e5533decde  pop r11
000078e5533dece0  pop r10
000078e5533dece2  pop r9
000078e5533dece4  pop r8
000078e5533dece6  pop rsi
000078e5533dece7  pop rdi
000078e5533dece8  pop rdx
000078e5533dece9  pop rcx
000078e5533decea  pop rax
000078e5533deceb  add rsp, 0x08
000078e5533decef  jmp 0x000078E5533DC2D0
000078e5533decf4  sub rsp, 0x08
000078e5533decf8  push rax
000078e5533decf9  push rcx
000078e5533decfa  push rdx
000078e5533decfb  push rdi
000078e5533decfc  push rsi
000078e5533decfd  push r8
000078e5533decff  push r9
000078e5533ded01  push r10
000078e5533ded03  push r11
000078e5533ded05  sub rsp, 0xF0
000078e5533ded0c  vmovaps [rsp], xmm0
000078e5533ded11  vmovaps [rsp+0x10], xmm2
000078e5533ded17  vmovaps [rsp+0x20], xmm3
000078e5533ded1d  vmovaps [rsp+0x30], xmm4
000078e5533ded23  vmovaps [rsp+0x40], xmm5
000078e5533ded29  vmovaps [rsp+0x50], xmm6
000078e5533ded2f  vmovaps [rsp+0x60], xmm7
000078e5533ded35  vmovaps [rsp+0x70], xmm8
000078e5533ded3b  vmovaps [rsp+0x80], xmm9
000078e5533ded44  vmovaps [rsp+0x90], xmm10
000078e5533ded4d  vmovaps [rsp+0xA0], xmm11
000078e5533ded56  vmovaps [rsp+0xB0], xmm12
000078e5533ded5f  vmovaps [rsp+0xC0], xmm13
000078e5533ded68  vmovaps [rsp+0xD0], xmm14
000078e5533ded71  vmovaps [rsp+0xE0], xmm15
000078e5533ded7a  sub rsp, 0x30
000078e5533ded7e  movaps [rsp], xmm1
000078e5533ded82  movaps [rsp+0x10], xmm4
000078e5533ded87  movaps [rsp+0x20], xmm9
000078e5533ded8d  lea rdi, [rsp]
000078e5533ded91  mov esi, 0x00
000078e5533ded96  mov rax, 0x5F83D5E17530
000078e5533deda0  call rax
000078e5533deda2  movaps xmm1, [rsp]
000078e5533deda6  add rsp, 0x30
000078e5533dedaa  vmovaps xmm0, [rsp]
000078e5533dedaf  vmovaps xmm2, [rsp+0x10]
000078e5533dedb5  vmovaps xmm3, [rsp+0x20]
000078e5533dedbb  vmovaps xmm4, [rsp+0x30]
000078e5533dedc1  vmovaps xmm5, [rsp+0x40]
000078e5533dedc7  vmovaps xmm6, [rsp+0x50]
000078e5533dedcd  vmovaps xmm7, [rsp+0x60]
000078e5533dedd3  vmovaps xmm8, [rsp+0x70]
000078e5533dedd9  vmovaps xmm9, [rsp+0x80]
000078e5533dede2  vmovaps xmm10, [rsp+0x90]
000078e5533dedeb  vmovaps xmm11, [rsp+0xA0]
000078e5533dedf4  vmovaps xmm12, [rsp+0xB0]
000078e5533dedfd  vmovaps xmm13, [rsp+0xC0]
000078e5533dee06  vmovaps xmm14, [rsp+0xD0]
000078e5533dee0f  vmovaps xmm15, [rsp+0xE0]
000078e5533dee18  add rsp, 0xF0
000078e5533dee1f  pop r11
000078e5533dee21  pop r10
000078e5533dee23  pop r9
000078e5533dee25  pop r8
000078e5533dee27  pop rsi
000078e5533dee28  pop rdi
000078e5533dee29  pop rdx
000078e5533dee2a  pop rcx
000078e5533dee2b  pop rax
000078e5533dee2c  add rsp, 0x08
000078e5533dee30  jmp 0x000078E5533DC2EE
000078e5533dee35  sub rsp, 0x08
000078e5533dee39  push rax
000078e5533dee3a  push rcx
000078e5533dee3b  push rdx
000078e5533dee3c  push rdi
000078e5533dee3d  push rsi
000078e5533dee3e  push r8
000078e5533dee40  push r9
000078e5533dee42  push r10
000078e5533dee44  push r11
000078e5533dee46  sub rsp, 0xF0
000078e5533dee4d  vmovaps [rsp], xmm0
000078e5533dee52  vmovaps [rsp+0x10], xmm1
000078e5533dee58  vmovaps [rsp+0x20], xmm2
000078e5533dee5e  vmovaps [rsp+0x30], xmm3
000078e5533dee64  vmovaps [rsp+0x40], xmm5
000078e5533dee6a  vmovaps [rsp+0x50], xmm6
000078e5533dee70  vmovaps [rsp+0x60], xmm7
000078e5533dee76  vmovaps [rsp+0x70], xmm8
000078e5533dee7c  vmovaps [rsp+0x80], xmm9
000078e5533dee85  vmovaps [rsp+0x90], xmm10
000078e5533dee8e  vmovaps [rsp+0xA0], xmm11
000078e5533dee97  vmovaps [rsp+0xB0], xmm12
000078e5533deea0  vmovaps [rsp+0xC0], xmm13
000078e5533deea9  vmovaps [rsp+0xD0], xmm14
000078e5533deeb2  vmovaps [rsp+0xE0], xmm15
000078e5533deebb  sub rsp, 0x30
000078e5533deebf  movaps [rsp], xmm4
000078e5533deec3  movaps [rsp+0x10], xmm2
000078e5533deec8  movaps [rsp+0x20], xmm9
000078e5533deece  lea rdi, [rsp]
000078e5533deed2  mov esi, 0x00
000078e5533deed7  mov rax, 0x5F83D5E17530
000078e5533deee1  call rax
000078e5533deee3  movaps xmm4, [rsp]
000078e5533deee7  add rsp, 0x30
000078e5533deeeb  vmovaps xmm0, [rsp]
000078e5533deef0  vmovaps xmm1, [rsp+0x10]
000078e5533deef6  vmovaps xmm2, [rsp+0x20]
000078e5533deefc  vmovaps xmm3, [rsp+0x30]
000078e5533def02  vmovaps xmm5, [rsp+0x40]
000078e5533def08  vmovaps xmm6, [rsp+0x50]
000078e5533def0e  vmovaps xmm7, [rsp+0x60]
000078e5533def14  vmovaps xmm8, [rsp+0x70]
000078e5533def1a  vmovaps xmm9, [rsp+0x80]
000078e5533def23  vmovaps xmm10, [rsp+0x90]
000078e5533def2c  vmovaps xmm11, [rsp+0xA0]
000078e5533def35  vmovaps xmm12, [rsp+0xB0]
000078e5533def3e  vmovaps xmm13, [rsp+0xC0]
000078e5533def47  vmovaps xmm14, [rsp+0xD0]
000078e5533def50  vmovaps xmm15, [rsp+0xE0]
000078e5533def59  add rsp, 0xF0
000078e5533def60  pop r11
000078e5533def62  pop r10
000078e5533def64  pop r9
000078e5533def66  pop r8
000078e5533def68  pop rsi
000078e5533def69  pop rdi
000078e5533def6a  pop rdx
000078e5533def6b  pop rcx
000078e5533def6c  pop rax
000078e5533def6d  add rsp, 0x08
000078e5533def71  jmp 0x000078E5533DC31E
000078e5533def76  sub rsp, 0x08
000078e5533def7a  push rax
000078e5533def7b  push rcx
000078e5533def7c  push rdx
000078e5533def7d  push rdi
000078e5533def7e  push rsi
000078e5533def7f  push r8
000078e5533def81  push r9
000078e5533def83  push r10
000078e5533def85  push r11
000078e5533def87  sub rsp, 0xF0
000078e5533def8e  vmovaps [rsp], xmm0
000078e5533def93  vmovaps [rsp+0x10], xmm1
000078e5533def99  vmovaps [rsp+0x20], xmm2
000078e5533def9f  vmovaps [rsp+0x30], xmm3
000078e5533defa5  vmovaps [rsp+0x40], xmm4
000078e5533defab  vmovaps [rsp+0x50], xmm5
000078e5533defb1  vmovaps [rsp+0x60], xmm6
000078e5533defb7  vmovaps [rsp+0x70], xmm7
000078e5533defbd  vmovaps [rsp+0x80], xmm8
000078e5533defc6  vmovaps [rsp+0x90], xmm10
000078e5533defcf  vmovaps [rsp+0xA0], xmm11
000078e5533defd8  vmovaps [rsp+0xB0], xmm12
000078e5533defe1  vmovaps [rsp+0xC0], xmm13
000078e5533defea  vmovaps [rsp+0xD0], xmm14
000078e5533deff3  vmovaps [rsp+0xE0], xmm15
000078e5533deffc  sub rsp, 0x30
000078e5533df000  movaps [rsp], xmm9
000078e5533df005  movaps [rsp+0x10], xmm2
000078e5533df00a  movaps [rsp+0x20], xmm1
000078e5533df00f  lea rdi, [rsp]
000078e5533df013  mov esi, 0x00
000078e5533df018  mov rax, 0x5F83D5E17530
000078e5533df022  call rax
000078e5533df024  movaps xmm9, [rsp]
000078e5533df029  add rsp, 0x30
000078e5533df02d  vmovaps xmm0, [rsp]
000078e5533df032  vmovaps xmm1, [rsp+0x10]
000078e5533df038  vmovaps xmm2, [rsp+0x20]
000078e5533df03e  vmovaps xmm3, [rsp+0x30]
000078e5533df044  vmovaps xmm4, [rsp+0x40]
000078e5533df04a  vmovaps xmm5, [rsp+0x50]
000078e5533df050  vmovaps xmm6, [rsp+0x60]
000078e5533df056  vmovaps xmm7, [rsp+0x70]
000078e5533df05c  vmovaps xmm8, [rsp+0x80]
000078e5533df065  vmovaps xmm10, [rsp+0x90]
000078e5533df06e  vmovaps xmm11, [rsp+0xA0]
000078e5533df077  vmovaps xmm12, [rsp+0xB0]
000078e5533df080  vmovaps xmm13, [rsp+0xC0]
000078e5533df089  vmovaps xmm14, [rsp+0xD0]
000078e5533df092  vmovaps xmm15, [rsp+0xE0]
000078e5533df09b  add rsp, 0xF0
000078e5533df0a2  pop r11
000078e5533df0a4  pop r10
000078e5533df0a6  pop r9
000078e5533df0a8  pop r8
000078e5533df0aa  pop rsi
000078e5533df0ab  pop rdi
000078e5533df0ac  pop rdx
000078e5533df0ad  pop rcx
000078e5533df0ae  pop rax
000078e5533df0af  add rsp, 0x08
000078e5533df0b3  jmp 0x000078E5533DC354
000078e5533df0b8  sub rsp, 0x08
000078e5533df0bc  push rax
000078e5533df0bd  push rcx
000078e5533df0be  push rdx
000078e5533df0bf  push rdi
000078e5533df0c0  push rsi
000078e5533df0c1  push r8
000078e5533df0c3  push r9
000078e5533df0c5  push r10
000078e5533df0c7  push r11
000078e5533df0c9  sub rsp, 0xF0
000078e5533df0d0  vmovaps [rsp], xmm0
000078e5533df0d5  vmovaps [rsp+0x10], xmm2
000078e5533df0db  vmovaps [rsp+0x20], xmm3
000078e5533df0e1  vmovaps [rsp+0x30], xmm4
000078e5533df0e7  vmovaps [rsp+0x40], xmm5
000078e5533df0ed  vmovaps [rsp+0x50], xmm6
000078e5533df0f3  vmovaps [rsp+0x60], xmm7
000078e5533df0f9  vmovaps [rsp+0x70], xmm8
000078e5533df0ff  vmovaps [rsp+0x80], xmm9
000078e5533df108  vmovaps [rsp+0x90], xmm10
000078e5533df111  vmovaps [rsp+0xA0], xmm11
000078e5533df11a  vmovaps [rsp+0xB0], xmm12
000078e5533df123  vmovaps [rsp+0xC0], xmm13
000078e5533df12c  vmovaps [rsp+0xD0], xmm14
000078e5533df135  vmovaps [rsp+0xE0], xmm15
000078e5533df13e  sub rsp, 0x30
000078e5533df142  movaps [rsp], xmm1
000078e5533df146  movaps [rsp+0x10], xmm15
000078e5533df14c  movaps [rsp+0x20], xmm6
000078e5533df151  lea rdi, [rsp]
000078e5533df155  mov esi, 0x00
000078e5533df15a  mov rax, 0x5F83D5E17530
000078e5533df164  call rax
000078e5533df166  movaps xmm1, [rsp]
000078e5533df16a  add rsp, 0x30
000078e5533df16e  vmovaps xmm0, [rsp]
000078e5533df173  vmovaps xmm2, [rsp+0x10]
000078e5533df179  vmovaps xmm3, [rsp+0x20]
000078e5533df17f  vmovaps xmm4, [rsp+0x30]
000078e5533df185  vmovaps xmm5, [rsp+0x40]
000078e5533df18b  vmovaps xmm6, [rsp+0x50]
000078e5533df191  vmovaps xmm7, [rsp+0x60]
000078e5533df197  vmovaps xmm8, [rsp+0x70]
000078e5533df19d  vmovaps xmm9, [rsp+0x80]
000078e5533df1a6  vmovaps xmm10, [rsp+0x90]
000078e5533df1af  vmovaps xmm11, [rsp+0xA0]
000078e5533df1b8  vmovaps xmm12, [rsp+0xB0]
000078e5533df1c1  vmovaps xmm13, [rsp+0xC0]
000078e5533df1ca  vmovaps xmm14, [rsp+0xD0]
000078e5533df1d3  vmovaps xmm15, [rsp+0xE0]
000078e5533df1dc  add rsp, 0xF0
000078e5533df1e3  pop r11
000078e5533df1e5  pop r10
000078e5533df1e7  pop r9
000078e5533df1e9  pop r8
000078e5533df1eb  pop rsi
000078e5533df1ec  pop rdi
000078e5533df1ed  pop rdx
000078e5533df1ee  pop rcx
000078e5533df1ef  pop rax
000078e5533df1f0  add rsp, 0x08
000078e5533df1f4  jmp 0x000078E5533DC375
000078e5533df1f9  sub rsp, 0x08
000078e5533df1fd  push rax
000078e5533df1fe  push rcx
000078e5533df1ff  push rdx
000078e5533df200  push rdi
000078e5533df201  push rsi
000078e5533df202  push r8
000078e5533df204  push r9
000078e5533df206  push r10
000078e5533df208  push r11
000078e5533df20a  sub rsp, 0xF0
000078e5533df211  vmovaps [rsp], xmm0
000078e5533df216  vmovaps [rsp+0x10], xmm1
000078e5533df21c  vmovaps [rsp+0x20], xmm2
000078e5533df222  vmovaps [rsp+0x30], xmm3
000078e5533df228  vmovaps [rsp+0x40], xmm4
000078e5533df22e  vmovaps [rsp+0x50], xmm5
000078e5533df234  vmovaps [rsp+0x60], xmm6
000078e5533df23a  vmovaps [rsp+0x70], xmm7
000078e5533df240  vmovaps [rsp+0x80], xmm8
000078e5533df249  vmovaps [rsp+0x90], xmm9
000078e5533df252  vmovaps [rsp+0xA0], xmm10
000078e5533df25b  vmovaps [rsp+0xB0], xmm11
000078e5533df264  vmovaps [rsp+0xC0], xmm12
000078e5533df26d  vmovaps [rsp+0xD0], xmm13
000078e5533df276  vmovaps [rsp+0xE0], xmm14
000078e5533df27f  sub rsp, 0x30
000078e5533df283  movaps [rsp], xmm15
000078e5533df288  movaps [rsp+0x10], xmm5
000078e5533df28d  movaps [rsp+0x20], xmm3
000078e5533df292  lea rdi, [rsp]
000078e5533df296  mov esi, 0x00
000078e5533df29b  mov rax, 0x5F83D5E17530
000078e5533df2a5  call rax
000078e5533df2a7  movaps xmm15, [rsp]
000078e5533df2ac  add rsp, 0x30
000078e5533df2b0  vmovaps xmm0, [rsp]
000078e5533df2b5  vmovaps xmm1, [rsp+0x10]
000078e5533df2bb  vmovaps xmm2, [rsp+0x20]
000078e5533df2c1  vmovaps xmm3, [rsp+0x30]
000078e5533df2c7  vmovaps xmm4, [rsp+0x40]
000078e5533df2cd  vmovaps xmm5, [rsp+0x50]
000078e5533df2d3  vmovaps xmm6, [rsp+0x60]
000078e5533df2d9  vmovaps xmm7, [rsp+0x70]
000078e5533df2df  vmovaps xmm8, [rsp+0x80]
000078e5533df2e8  vmovaps xmm9, [rsp+0x90]
000078e5533df2f1  vmovaps xmm10, [rsp+0xA0]
000078e5533df2fa  vmovaps xmm11, [rsp+0xB0]
000078e5533df303  vmovaps xmm12, [rsp+0xC0]
000078e5533df30c  vmovaps xmm13, [rsp+0xD0]
000078e5533df315  vmovaps xmm14, [rsp+0xE0]
000078e5533df31e  add rsp, 0xF0
000078e5533df325  pop r11
000078e5533df327  pop r10
000078e5533df329  pop r9
000078e5533df32b  pop r8
000078e5533df32d  pop rsi
000078e5533df32e  pop rdi
000078e5533df32f  pop rdx
000078e5533df330  pop rcx
000078e5533df331  pop rax
000078e5533df332  add rsp, 0x08
000078e5533df336  jmp 0x000078E5533DC38F
000078e5533df33b  sub rsp, 0x08
000078e5533df33f  push rax
000078e5533df340  push rcx
000078e5533df341  push rdx
000078e5533df342  push rdi
000078e5533df343  push rsi
000078e5533df344  push r8
000078e5533df346  push r9
000078e5533df348  push r10
000078e5533df34a  push r11
000078e5533df34c  sub rsp, 0xF0
000078e5533df353  vmovaps [rsp], xmm0
000078e5533df358  vmovaps [rsp+0x10], xmm1
000078e5533df35e  vmovaps [rsp+0x20], xmm2
000078e5533df364  vmovaps [rsp+0x30], xmm3
000078e5533df36a  vmovaps [rsp+0x40], xmm4
000078e5533df370  vmovaps [rsp+0x50], xmm6
000078e5533df376  vmovaps [rsp+0x60], xmm7
000078e5533df37c  vmovaps [rsp+0x70], xmm8
000078e5533df382  vmovaps [rsp+0x80], xmm9
000078e5533df38b  vmovaps [rsp+0x90], xmm10
000078e5533df394  vmovaps [rsp+0xA0], xmm11
000078e5533df39d  vmovaps [rsp+0xB0], xmm12
000078e5533df3a6  vmovaps [rsp+0xC0], xmm13
000078e5533df3af  vmovaps [rsp+0xD0], xmm14
000078e5533df3b8  vmovaps [rsp+0xE0], xmm15
000078e5533df3c1  sub rsp, 0x30
000078e5533df3c5  movaps [rsp], xmm5
000078e5533df3c9  movaps [rsp+0x10], xmm8
000078e5533df3cf  movaps [rsp+0x20], xmm6
000078e5533df3d4  lea rdi, [rsp]
000078e5533df3d8  mov esi, 0x00
000078e5533df3dd  mov rax, 0x5F83D5E17530
000078e5533df3e7  call rax
000078e5533df3e9  movaps xmm5, [rsp]
000078e5533df3ed  add rsp, 0x30
000078e5533df3f1  vmovaps xmm0, [rsp]
000078e5533df3f6  vmovaps xmm1, [rsp+0x10]
000078e5533df3fc  vmovaps xmm2, [rsp+0x20]
000078e5533df402  vmovaps xmm3, [rsp+0x30]
000078e5533df408  vmovaps xmm4, [rsp+0x40]
000078e5533df40e  vmovaps xmm6, [rsp+0x50]
000078e5533df414  vmovaps xmm7, [rsp+0x60]
000078e5533df41a  vmovaps xmm8, [rsp+0x70]
000078e5533df420  vmovaps xmm9, [rsp+0x80]
000078e5533df429  vmovaps xmm10, [rsp+0x90]
000078e5533df432  vmovaps xmm11, [rsp+0xA0]
000078e5533df43b  vmovaps xmm12, [rsp+0xB0]
000078e5533df444  vmovaps xmm13, [rsp+0xC0]
000078e5533df44d  vmovaps xmm14, [rsp+0xD0]
000078e5533df456  vmovaps xmm15, [rsp+0xE0]
000078e5533df45f  add rsp, 0xF0
000078e5533df466  pop r11
000078e5533df468  pop r10
000078e5533df46a  pop r9
000078e5533df46c  pop r8
000078e5533df46e  pop rsi
000078e5533df46f  pop rdi
000078e5533df470  pop rdx
000078e5533df471  pop rcx
000078e5533df472  pop rax
000078e5533df473  add rsp, 0x08
000078e5533df477  jmp 0x000078E5533DC3B3
000078e5533df47c  sub rsp, 0x08
000078e5533df480  push rax
000078e5533df481  push rcx
000078e5533df482  push rdx
000078e5533df483  push rdi
000078e5533df484  push rsi
000078e5533df485  push r8
000078e5533df487  push r9
000078e5533df489  push r10
000078e5533df48b  push r11
000078e5533df48d  sub rsp, 0xF0
000078e5533df494  vmovaps [rsp], xmm0
000078e5533df499  vmovaps [rsp+0x10], xmm1
000078e5533df49f  vmovaps [rsp+0x20], xmm2
000078e5533df4a5  vmovaps [rsp+0x30], xmm3
000078e5533df4ab  vmovaps [rsp+0x40], xmm4
000078e5533df4b1  vmovaps [rsp+0x50], xmm5
000078e5533df4b7  vmovaps [rsp+0x60], xmm7
000078e5533df4bd  vmovaps [rsp+0x70], xmm8
000078e5533df4c3  vmovaps [rsp+0x80], xmm9
000078e5533df4cc  vmovaps [rsp+0x90], xmm10
000078e5533df4d5  vmovaps [rsp+0xA0], xmm11
000078e5533df4de  vmovaps [rsp+0xB0], xmm12
000078e5533df4e7  vmovaps [rsp+0xC0], xmm13
000078e5533df4f0  vmovaps [rsp+0xD0], xmm14
000078e5533df4f9  vmovaps [rsp+0xE0], xmm15
000078e5533df502  sub rsp, 0x30
000078e5533df506  movaps [rsp], xmm6
000078e5533df50a  movaps [rsp+0x10], xmm10
000078e5533df510  movaps [rsp+0x20], xmm8
000078e5533df516  lea rdi, [rsp]
000078e5533df51a  mov esi, 0x00
000078e5533df51f  mov rax, 0x5F83D5E17530
000078e5533df529  call rax
000078e5533df52b  movaps xmm6, [rsp]
000078e5533df52f  add rsp, 0x30
000078e5533df533  vmovaps xmm0, [rsp]
000078e5533df538  vmovaps xmm1, [rsp+0x10]
000078e5533df53e  vmovaps xmm2, [rsp+0x20]
000078e5533df544  vmovaps xmm3, [rsp+0x30]
000078e5533df54a  vmovaps xmm4, [rsp+0x40]
000078e5533df550  vmovaps xmm5, [rsp+0x50]
000078e5533df556  vmovaps xmm7, [rsp+0x60]
000078e5533df55c  vmovaps xmm8, [rsp+0x70]
000078e5533df562  vmovaps xmm9, [rsp+0x80]
000078e5533df56b  vmovaps xmm10, [rsp+0x90]
000078e5533df574  vmovaps xmm11, [rsp+0xA0]
000078e5533df57d  vmovaps xmm12, [rsp+0xB0]
000078e5533df586  vmovaps xmm13, [rsp+0xC0]
000078e5533df58f  vmovaps xmm14, [rsp+0xD0]
000078e5533df598  vmovaps xmm15, [rsp+0xE0]
000078e5533df5a1  add rsp, 0xF0
000078e5533df5a8  pop r11
000078e5533df5aa  pop r10
000078e5533df5ac  pop r9
000078e5533df5ae  pop r8
000078e5533df5b0  pop rsi
000078e5533df5b1  pop rdi
000078e5533df5b2  pop rdx
000078e5533df5b3  pop rcx
000078e5533df5b4  pop rax
000078e5533df5b5  add rsp, 0x08
000078e5533df5b9  jmp 0x000078E5533DC3D8
000078e5533df5be  sub rsp, 0x08
000078e5533df5c2  push rax
000078e5533df5c3  push rcx
000078e5533df5c4  push rdx
000078e5533df5c5  push rdi
000078e5533df5c6  push rsi
000078e5533df5c7  push r8
000078e5533df5c9  push r9
000078e5533df5cb  push r10
000078e5533df5cd  push r11
000078e5533df5cf  sub rsp, 0xF0
000078e5533df5d6  vmovaps [rsp], xmm0
000078e5533df5db  vmovaps [rsp+0x10], xmm1
000078e5533df5e1  vmovaps [rsp+0x20], xmm2
000078e5533df5e7  vmovaps [rsp+0x30], xmm3
000078e5533df5ed  vmovaps [rsp+0x40], xmm4
000078e5533df5f3  vmovaps [rsp+0x50], xmm5
000078e5533df5f9  vmovaps [rsp+0x60], xmm6
000078e5533df5ff  vmovaps [rsp+0x70], xmm7
000078e5533df605  vmovaps [rsp+0x80], xmm8
000078e5533df60e  vmovaps [rsp+0x90], xmm9
000078e5533df617  vmovaps [rsp+0xA0], xmm11
000078e5533df620  vmovaps [rsp+0xB0], xmm12
000078e5533df629  vmovaps [rsp+0xC0], xmm13
000078e5533df632  vmovaps [rsp+0xD0], xmm14
000078e5533df63b  vmovaps [rsp+0xE0], xmm15
000078e5533df644  sub rsp, 0x30
000078e5533df648  movaps [rsp], xmm10
000078e5533df64d  movaps [rsp+0x10], xmm8
000078e5533df653  movaps [rsp+0x20], xmm14
000078e5533df659  lea rdi, [rsp]
000078e5533df65d  mov esi, 0x00
000078e5533df662  mov rax, 0x5F83D5E17530
000078e5533df66c  call rax
000078e5533df66e  movaps xmm10, [rsp]
000078e5533df673  add rsp, 0x30
000078e5533df677  vmovaps xmm0, [rsp]
000078e5533df67c  vmovaps xmm1, [rsp+0x10]
000078e5533df682  vmovaps xmm2, [rsp+0x20]
000078e5533df688  vmovaps xmm3, [rsp+0x30]
000078e5533df68e  vmovaps xmm4, [rsp+0x40]
000078e5533df694  vmovaps xmm5, [rsp+0x50]
000078e5533df69a  vmovaps xmm6, [rsp+0x60]
000078e5533df6a0  vmovaps xmm7, [rsp+0x70]
000078e5533df6a6  vmovaps xmm8, [rsp+0x80]
000078e5533df6af  vmovaps xmm9, [rsp+0x90]
000078e5533df6b8  vmovaps xmm11, [rsp+0xA0]
000078e5533df6c1  vmovaps xmm12, [rsp+0xB0]
000078e5533df6ca  vmovaps xmm13, [rsp+0xC0]
000078e5533df6d3  vmovaps xmm14, [rsp+0xD0]
000078e5533df6dc  vmovaps xmm15, [rsp+0xE0]
000078e5533df6e5  add rsp, 0xF0
000078e5533df6ec  pop r11
000078e5533df6ee  pop r10
000078e5533df6f0  pop r9
000078e5533df6f2  pop r8
000078e5533df6f4  pop rsi
000078e5533df6f5  pop rdi
000078e5533df6f6  pop rdx
000078e5533df6f7  pop rcx
000078e5533df6f8  pop rax
000078e5533df6f9  add rsp, 0x08
000078e5533df6fd  jmp 0x000078E5533DC3F8
000078e5533df702  sub rsp, 0x08
000078e5533df706  push rax
000078e5533df707  push rcx
000078e5533df708  push rdx
000078e5533df709  push rdi
000078e5533df70a  push rsi
000078e5533df70b  push r8
000078e5533df70d  push r9
000078e5533df70f  push r10
000078e5533df711  push r11
000078e5533df713  sub rsp, 0xF0
000078e5533df71a  vmovaps [rsp], xmm0
000078e5533df71f  vmovaps [rsp+0x10], xmm1
000078e5533df725  vmovaps [rsp+0x20], xmm2
000078e5533df72b  vmovaps [rsp+0x30], xmm3
000078e5533df731  vmovaps [rsp+0x40], xmm4
000078e5533df737  vmovaps [rsp+0x50], xmm5
000078e5533df73d  vmovaps [rsp+0x60], xmm6
000078e5533df743  vmovaps [rsp+0x70], xmm7
000078e5533df749  vmovaps [rsp+0x80], xmm8
000078e5533df752  vmovaps [rsp+0x90], xmm9
000078e5533df75b  vmovaps [rsp+0xA0], xmm10
000078e5533df764  vmovaps [rsp+0xB0], xmm11
000078e5533df76d  vmovaps [rsp+0xC0], xmm12
000078e5533df776  vmovaps [rsp+0xD0], xmm13
000078e5533df77f  vmovaps [rsp+0xE0], xmm15
000078e5533df788  sub rsp, 0x30
000078e5533df78c  movaps [rsp], xmm14
000078e5533df791  movaps [rsp+0x10], xmm8
000078e5533df797  movaps [rsp+0x20], xmm4
000078e5533df79c  lea rdi, [rsp]
000078e5533df7a0  mov esi, 0x00
000078e5533df7a5  mov rax, 0x5F83D5E17530
000078e5533df7af  call rax
000078e5533df7b1  movaps xmm14, [rsp]
000078e5533df7b6  add rsp, 0x30
000078e5533df7ba  vmovaps xmm0, [rsp]
000078e5533df7bf  vmovaps xmm1, [rsp+0x10]
000078e5533df7c5  vmovaps xmm2, [rsp+0x20]
000078e5533df7cb  vmovaps xmm3, [rsp+0x30]
000078e5533df7d1  vmovaps xmm4, [rsp+0x40]
000078e5533df7d7  vmovaps xmm5, [rsp+0x50]
000078e5533df7dd  vmovaps xmm6, [rsp+0x60]
000078e5533df7e3  vmovaps xmm7, [rsp+0x70]
000078e5533df7e9  vmovaps xmm8, [rsp+0x80]
000078e5533df7f2  vmovaps xmm9, [rsp+0x90]
000078e5533df7fb  vmovaps xmm10, [rsp+0xA0]
000078e5533df804  vmovaps xmm11, [rsp+0xB0]
000078e5533df80d  vmovaps xmm12, [rsp+0xC0]
000078e5533df816  vmovaps xmm13, [rsp+0xD0]
000078e5533df81f  vmovaps xmm15, [rsp+0xE0]
000078e5533df828  add rsp, 0xF0
000078e5533df82f  pop r11
000078e5533df831  pop r10
000078e5533df833  pop r9
000078e5533df835  pop r8
000078e5533df837  pop rsi
000078e5533df838  pop rdi
000078e5533df839  pop rdx
000078e5533df83a  pop rcx
000078e5533df83b  pop rax
000078e5533df83c  add rsp, 0x08
000078e5533df840  jmp 0x000078E5533DC418
000078e5533df845  sub rsp, 0x08
000078e5533df849  push rax
000078e5533df84a  push rcx
000078e5533df84b  push rdx
000078e5533df84c  push rdi
000078e5533df84d  push rsi
000078e5533df84e  push r8
000078e5533df850  push r9
000078e5533df852  push r10
000078e5533df854  push r11
000078e5533df856  sub rsp, 0xF0
000078e5533df85d  vmovaps [rsp], xmm0
000078e5533df862  vmovaps [rsp+0x10], xmm1
000078e5533df868  vmovaps [rsp+0x20], xmm2
000078e5533df86e  vmovaps [rsp+0x30], xmm3
000078e5533df874  vmovaps [rsp+0x40], xmm5
000078e5533df87a  vmovaps [rsp+0x50], xmm6
000078e5533df880  vmovaps [rsp+0x60], xmm7
000078e5533df886  vmovaps [rsp+0x70], xmm8
000078e5533df88c  vmovaps [rsp+0x80], xmm9
000078e5533df895  vmovaps [rsp+0x90], xmm10
000078e5533df89e  vmovaps [rsp+0xA0], xmm11
000078e5533df8a7  vmovaps [rsp+0xB0], xmm12
000078e5533df8b0  vmovaps [rsp+0xC0], xmm13
000078e5533df8b9  vmovaps [rsp+0xD0], xmm14
000078e5533df8c2  vmovaps [rsp+0xE0], xmm15
000078e5533df8cb  sub rsp, 0x30
000078e5533df8cf  movaps [rsp], xmm4
000078e5533df8d3  movaps [rsp+0x10], xmm13
000078e5533df8d9  movaps [rsp+0x20], xmm8
000078e5533df8df  lea rdi, [rsp]
000078e5533df8e3  mov esi, 0x00
000078e5533df8e8  mov rax, 0x5F83D5E17530
000078e5533df8f2  call rax
000078e5533df8f4  movaps xmm4, [rsp]
000078e5533df8f8  add rsp, 0x30
000078e5533df8fc  vmovaps xmm0, [rsp]
000078e5533df901  vmovaps xmm1, [rsp+0x10]
000078e5533df907  vmovaps xmm2, [rsp+0x20]
000078e5533df90d  vmovaps xmm3, [rsp+0x30]
000078e5533df913  vmovaps xmm5, [rsp+0x40]
000078e5533df919  vmovaps xmm6, [rsp+0x50]
000078e5533df91f  vmovaps xmm7, [rsp+0x60]
000078e5533df925  vmovaps xmm8, [rsp+0x70]
000078e5533df92b  vmovaps xmm9, [rsp+0x80]
000078e5533df934  vmovaps xmm10, [rsp+0x90]
000078e5533df93d  vmovaps xmm11, [rsp+0xA0]
000078e5533df946  vmovaps xmm12, [rsp+0xB0]
000078e5533df94f  vmovaps xmm13, [rsp+0xC0]
000078e5533df958  vmovaps xmm14, [rsp+0xD0]
000078e5533df961  vmovaps xmm15, [rsp+0xE0]
000078e5533df96a  add rsp, 0xF0
000078e5533df971  pop r11
000078e5533df973  pop r10
000078e5533df975  pop r9
000078e5533df977  pop r8
000078e5533df979  pop rsi
000078e5533df97a  pop rdi
000078e5533df97b  pop rdx
000078e5533df97c  pop rcx
000078e5533df97d  pop rax
000078e5533df97e  add rsp, 0x08
000078e5533df982  jmp 0x000078E5533DC43D
000078e5533df987  sub rsp, 0x08
000078e5533df98b  push rax
000078e5533df98c  push rcx
000078e5533df98d  push rdx
000078e5533df98e  push rdi
000078e5533df98f  push rsi
000078e5533df990  push r8
000078e5533df992  push r9
000078e5533df994  push r10
000078e5533df996  push r11
000078e5533df998  sub rsp, 0xF0
000078e5533df99f  vmovaps [rsp], xmm0
000078e5533df9a4  vmovaps [rsp+0x10], xmm1
000078e5533df9aa  vmovaps [rsp+0x20], xmm2
000078e5533df9b0  vmovaps [rsp+0x30], xmm3
000078e5533df9b6  vmovaps [rsp+0x40], xmm4
000078e5533df9bc  vmovaps [rsp+0x50], xmm5
000078e5533df9c2  vmovaps [rsp+0x60], xmm6
000078e5533df9c8  vmovaps [rsp+0x70], xmm7
000078e5533df9ce  vmovaps [rsp+0x80], xmm8
000078e5533df9d7  vmovaps [rsp+0x90], xmm9
000078e5533df9e0  vmovaps [rsp+0xA0], xmm10
000078e5533df9e9  vmovaps [rsp+0xB0], xmm11
000078e5533df9f2  vmovaps [rsp+0xC0], xmm12
000078e5533df9fb  vmovaps [rsp+0xD0], xmm14
000078e5533dfa04  vmovaps [rsp+0xE0], xmm15
000078e5533dfa0d  sub rsp, 0x30
000078e5533dfa11  movaps [rsp], xmm13
000078e5533dfa16  movaps [rsp+0x10], xmm15
000078e5533dfa1c  movaps [rsp+0x20], xmm9
000078e5533dfa22  lea rdi, [rsp]
000078e5533dfa26  mov esi, 0x00
000078e5533dfa2b  mov rax, 0x5F83D5E17530
000078e5533dfa35  call rax
000078e5533dfa37  movaps xmm13, [rsp]
000078e5533dfa3c  add rsp, 0x30
000078e5533dfa40  vmovaps xmm0, [rsp]
000078e5533dfa45  vmovaps xmm1, [rsp+0x10]
000078e5533dfa4b  vmovaps xmm2, [rsp+0x20]
000078e5533dfa51  vmovaps xmm3, [rsp+0x30]
000078e5533dfa57  vmovaps xmm4, [rsp+0x40]
000078e5533dfa5d  vmovaps xmm5, [rsp+0x50]
000078e5533dfa63  vmovaps xmm6, [rsp+0x60]
000078e5533dfa69  vmovaps xmm7, [rsp+0x70]
000078e5533dfa6f  vmovaps xmm8, [rsp+0x80]
000078e5533dfa78  vmovaps xmm9, [rsp+0x90]
000078e5533dfa81  vmovaps xmm10, [rsp+0xA0]
000078e5533dfa8a  vmovaps xmm11, [rsp+0xB0]
000078e5533dfa93  vmovaps xmm12, [rsp+0xC0]
000078e5533dfa9c  vmovaps xmm14, [rsp+0xD0]
000078e5533dfaa5  vmovaps xmm15, [rsp+0xE0]
000078e5533dfaae  add rsp, 0xF0
000078e5533dfab5  pop r11
000078e5533dfab7  pop r10
000078e5533dfab9  pop r9
000078e5533dfabb  pop r8
000078e5533dfabd  pop rsi
000078e5533dfabe  pop rdi
000078e5533dfabf  pop rdx
000078e5533dfac0  pop rcx
000078e5533dfac1  pop rax
000078e5533dfac2  add rsp, 0x08
000078e5533dfac6  jmp 0x000078E5533DC458
000078e5533dfacb  sub rsp, 0x08
000078e5533dfacf  push rax
000078e5533dfad0  push rcx
000078e5533dfad1  push rdx
000078e5533dfad2  push rdi
000078e5533dfad3  push rsi
000078e5533dfad4  push r8
000078e5533dfad6  push r9
000078e5533dfad8  push r10
000078e5533dfada  push r11
000078e5533dfadc  sub rsp, 0xF0
000078e5533dfae3  vmovaps [rsp], xmm0
000078e5533dfae8  vmovaps [rsp+0x10], xmm1
000078e5533dfaee  vmovaps [rsp+0x20], xmm2
000078e5533dfaf4  vmovaps [rsp+0x30], xmm3
000078e5533dfafa  vmovaps [rsp+0x40], xmm4
000078e5533dfb00  vmovaps [rsp+0x50], xmm5
000078e5533dfb06  vmovaps [rsp+0x60], xmm6
000078e5533dfb0c  vmovaps [rsp+0x70], xmm7
000078e5533dfb12  vmovaps [rsp+0x80], xmm8
000078e5533dfb1b  vmovaps [rsp+0x90], xmm9
000078e5533dfb24  vmovaps [rsp+0xA0], xmm10
000078e5533dfb2d  vmovaps [rsp+0xB0], xmm11
000078e5533dfb36  vmovaps [rsp+0xC0], xmm12
000078e5533dfb3f  vmovaps [rsp+0xD0], xmm13
000078e5533dfb48  vmovaps [rsp+0xE0], xmm14
000078e5533dfb51  sub rsp, 0x30
000078e5533dfb55  movaps [rsp], xmm15
000078e5533dfb5a  movaps [rsp+0x10], xmm1
000078e5533dfb5f  movaps [rsp+0x20], xmm5
000078e5533dfb64  lea rdi, [rsp]
000078e5533dfb68  mov esi, 0x00
000078e5533dfb6d  mov rax, 0x5F83D5E17530
000078e5533dfb77  call rax
000078e5533dfb79  movaps xmm15, [rsp]
000078e5533dfb7e  add rsp, 0x30
000078e5533dfb82  vmovaps xmm0, [rsp]
000078e5533dfb87  vmovaps xmm1, [rsp+0x10]
000078e5533dfb8d  vmovaps xmm2, [rsp+0x20]
000078e5533dfb93  vmovaps xmm3, [rsp+0x30]
000078e5533dfb99  vmovaps xmm4, [rsp+0x40]
000078e5533dfb9f  vmovaps xmm5, [rsp+0x50]
000078e5533dfba5  vmovaps xmm6, [rsp+0x60]
000078e5533dfbab  vmovaps xmm7, [rsp+0x70]
000078e5533dfbb1  vmovaps xmm8, [rsp+0x80]
000078e5533dfbba  vmovaps xmm9, [rsp+0x90]
000078e5533dfbc3  vmovaps xmm10, [rsp+0xA0]
000078e5533dfbcc  vmovaps xmm11, [rsp+0xB0]
000078e5533dfbd5  vmovaps xmm12, [rsp+0xC0]
000078e5533dfbde  vmovaps xmm13, [rsp+0xD0]
000078e5533dfbe7  vmovaps xmm14, [rsp+0xE0]
000078e5533dfbf0  add rsp, 0xF0
000078e5533dfbf7  pop r11
000078e5533dfbf9  pop r10
000078e5533dfbfb  pop r9
000078e5533dfbfd  pop r8
000078e5533dfbff  pop rsi
000078e5533dfc00  pop rdi
000078e5533dfc01  pop rdx
000078e5533dfc02  pop rcx
000078e5533dfc03  pop rax
000078e5533dfc04  add rsp, 0x08
000078e5533dfc08  jmp 0x000078E5533DC473
000078e5533dfc0d  call 0x000078E5532B52F0
000078e5533dfc12  jmp 0x000078E5533DC4CE
000078e5533dfc17  sub rsp, 0x08
000078e5533dfc1b  push rax
000078e5533dfc1c  push rcx
000078e5533dfc1d  push rdx
000078e5533dfc1e  push rdi
000078e5533dfc1f  push rsi
000078e5533dfc20  push r8
000078e5533dfc22  push r9
000078e5533dfc24  push r10
000078e5533dfc26  push r11
000078e5533dfc28  sub rsp, 0xF0
000078e5533dfc2f  vmovaps [rsp], xmm0
000078e5533dfc34  vmovaps [rsp+0x10], xmm1
000078e5533dfc3a  vmovaps [rsp+0x20], xmm2
000078e5533dfc40  vmovaps [rsp+0x30], xmm3
000078e5533dfc46  vmovaps [rsp+0x40], xmm4
000078e5533dfc4c  vmovaps [rsp+0x50], xmm5
000078e5533dfc52  vmovaps [rsp+0x60], xmm6
000078e5533dfc58  vmovaps [rsp+0x70], xmm7
000078e5533dfc5e  vmovaps [rsp+0x80], xmm8
000078e5533dfc67  vmovaps [rsp+0x90], xmm10
000078e5533dfc70  vmovaps [rsp+0xA0], xmm11
000078e5533dfc79  vmovaps [rsp+0xB0], xmm12
000078e5533dfc82  vmovaps [rsp+0xC0], xmm13
000078e5533dfc8b  vmovaps [rsp+0xD0], xmm14
000078e5533dfc94  vmovaps [rsp+0xE0], xmm15
000078e5533dfc9d  sub rsp, 0x30
000078e5533dfca1  movaps [rsp], xmm9
000078e5533dfca6  movaps [rsp+0x10], xmm8
000078e5533dfcac  movaps [rsp+0x20], xmm11
000078e5533dfcb2  lea rdi, [rsp]
000078e5533dfcb6  mov esi, 0x00
000078e5533dfcbb  mov rax, 0x5F83D5E17530
000078e5533dfcc5  call rax
000078e5533dfcc7  movaps xmm9, [rsp]
000078e5533dfccc  add rsp, 0x30
000078e5533dfcd0  vmovaps xmm0, [rsp]
000078e5533dfcd5  vmovaps xmm1, [rsp+0x10]
000078e5533dfcdb  vmovaps xmm2, [rsp+0x20]
000078e5533dfce1  vmovaps xmm3, [rsp+0x30]
000078e5533dfce7  vmovaps xmm4, [rsp+0x40]
000078e5533dfced  vmovaps xmm5, [rsp+0x50]
000078e5533dfcf3  vmovaps xmm6, [rsp+0x60]
000078e5533dfcf9  vmovaps xmm7, [rsp+0x70]
000078e5533dfcff  vmovaps xmm8, [rsp+0x80]
000078e5533dfd08  vmovaps xmm10, [rsp+0x90]
000078e5533dfd11  vmovaps xmm11, [rsp+0xA0]
000078e5533dfd1a  vmovaps xmm12, [rsp+0xB0]
000078e5533dfd23  vmovaps xmm13, [rsp+0xC0]
000078e5533dfd2c  vmovaps xmm14, [rsp+0xD0]
000078e5533dfd35  vmovaps xmm15, [rsp+0xE0]
000078e5533dfd3e  add rsp, 0xF0
000078e5533dfd45  pop r11
000078e5533dfd47  pop r10
000078e5533dfd49  pop r9
000078e5533dfd4b  pop r8
000078e5533dfd4d  pop rsi
000078e5533dfd4e  pop rdi
000078e5533dfd4f  pop rdx
000078e5533dfd50  pop rcx
000078e5533dfd51  pop rax
000078e5533dfd52  add rsp, 0x08
000078e5533dfd56  jmp 0x000078E5533DC505
000078e5533dfd5b  sub rsp, 0x08
000078e5533dfd5f  push rax
000078e5533dfd60  push rcx
000078e5533dfd61  push rdx
000078e5533dfd62  push rdi
000078e5533dfd63  push rsi
000078e5533dfd64  push r8
000078e5533dfd66  push r9
000078e5533dfd68  push r10
000078e5533dfd6a  push r11
000078e5533dfd6c  sub rsp, 0xF0
000078e5533dfd73  vmovaps [rsp], xmm0
000078e5533dfd78  vmovaps [rsp+0x10], xmm1
000078e5533dfd7e  vmovaps [rsp+0x20], xmm2
000078e5533dfd84  vmovaps [rsp+0x30], xmm3
000078e5533dfd8a  vmovaps [rsp+0x40], xmm4
000078e5533dfd90  vmovaps [rsp+0x50], xmm5
000078e5533dfd96  vmovaps [rsp+0x60], xmm6
000078e5533dfd9c  vmovaps [rsp+0x70], xmm7
000078e5533dfda2  vmovaps [rsp+0x80], xmm8
000078e5533dfdab  vmovaps [rsp+0x90], xmm9
000078e5533dfdb4  vmovaps [rsp+0xA0], xmm10
000078e5533dfdbd  vmovaps [rsp+0xB0], xmm12
000078e5533dfdc6  vmovaps [rsp+0xC0], xmm13
000078e5533dfdcf  vmovaps [rsp+0xD0], xmm14
000078e5533dfdd8  vmovaps [rsp+0xE0], xmm15
000078e5533dfde1  sub rsp, 0x30
000078e5533dfde5  movaps [rsp], xmm11
000078e5533dfdea  movaps [rsp+0x10], xmm10
000078e5533dfdf0  movaps [rsp+0x20], xmm6
000078e5533dfdf5  lea rdi, [rsp]
000078e5533dfdf9  mov esi, 0x00
000078e5533dfdfe  mov rax, 0x5F83D5E17530
000078e5533dfe08  call rax
000078e5533dfe0a  movaps xmm11, [rsp]
000078e5533dfe0f  add rsp, 0x30
000078e5533dfe13  vmovaps xmm0, [rsp]
000078e5533dfe18  vmovaps xmm1, [rsp+0x10]
000078e5533dfe1e  vmovaps xmm2, [rsp+0x20]
000078e5533dfe24  vmovaps xmm3, [rsp+0x30]
000078e5533dfe2a  vmovaps xmm4, [rsp+0x40]
000078e5533dfe30  vmovaps xmm5, [rsp+0x50]
000078e5533dfe36  vmovaps xmm6, [rsp+0x60]
000078e5533dfe3c  vmovaps xmm7, [rsp+0x70]
000078e5533dfe42  vmovaps xmm8, [rsp+0x80]
000078e5533dfe4b  vmovaps xmm9, [rsp+0x90]
000078e5533dfe54  vmovaps xmm10, [rsp+0xA0]
000078e5533dfe5d  vmovaps xmm12, [rsp+0xB0]
000078e5533dfe66  vmovaps xmm13, [rsp+0xC0]
000078e5533dfe6f  vmovaps xmm14, [rsp+0xD0]
000078e5533dfe78  vmovaps xmm15, [rsp+0xE0]
000078e5533dfe81  add rsp, 0xF0
000078e5533dfe88  pop r11
000078e5533dfe8a  pop r10
000078e5533dfe8c  pop r9
000078e5533dfe8e  pop r8
000078e5533dfe90  pop rsi
000078e5533dfe91  pop rdi
000078e5533dfe92  pop rdx
000078e5533dfe93  pop rcx
000078e5533dfe94  pop rax
000078e5533dfe95  add rsp, 0x08
000078e5533dfe99  jmp 0x000078E5533DC520
000078e5533dfe9e  sub rsp, 0x08
000078e5533dfea2  push rax
000078e5533dfea3  push rcx
000078e5533dfea4  push rdx
000078e5533dfea5  push rdi
000078e5533dfea6  push rsi
000078e5533dfea7  push r8
000078e5533dfea9  push r9
000078e5533dfeab  push r10
000078e5533dfead  push r11
000078e5533dfeaf  sub rsp, 0xF0
000078e5533dfeb6  vmovaps [rsp], xmm0
000078e5533dfebb  vmovaps [rsp+0x10], xmm1
000078e5533dfec1  vmovaps [rsp+0x20], xmm2
000078e5533dfec7  vmovaps [rsp+0x30], xmm3
000078e5533dfecd  vmovaps [rsp+0x40], xmm4
000078e5533dfed3  vmovaps [rsp+0x50], xmm5
000078e5533dfed9  vmovaps [rsp+0x60], xmm6
000078e5533dfedf  vmovaps [rsp+0x70], xmm7
000078e5533dfee5  vmovaps [rsp+0x80], xmm8
000078e5533dfeee  vmovaps [rsp+0x90], xmm9
000078e5533dfef7  vmovaps [rsp+0xA0], xmm11
000078e5533dff00  vmovaps [rsp+0xB0], xmm12
000078e5533dff09  vmovaps [rsp+0xC0], xmm13
000078e5533dff12  vmovaps [rsp+0xD0], xmm14
000078e5533dff1b  vmovaps [rsp+0xE0], xmm15
000078e5533dff24  sub rsp, 0x30
000078e5533dff28  movaps [rsp], xmm10
000078e5533dff2d  movaps [rsp+0x10], xmm14
000078e5533dff33  movaps [rsp+0x20], xmm4
000078e5533dff38  lea rdi, [rsp]
000078e5533dff3c  mov esi, 0x00
000078e5533dff41  mov rax, 0x5F83D5E17530
000078e5533dff4b  call rax
000078e5533dff4d  movaps xmm10, [rsp]
000078e5533dff52  add rsp, 0x30
000078e5533dff56  vmovaps xmm0, [rsp]
000078e5533dff5b  vmovaps xmm1, [rsp+0x10]
000078e5533dff61  vmovaps xmm2, [rsp+0x20]
000078e5533dff67  vmovaps xmm3, [rsp+0x30]
000078e5533dff6d  vmovaps xmm4, [rsp+0x40]
000078e5533dff73  vmovaps xmm5, [rsp+0x50]
000078e5533dff79  vmovaps xmm6, [rsp+0x60]
000078e5533dff7f  vmovaps xmm7, [rsp+0x70]
000078e5533dff85  vmovaps xmm8, [rsp+0x80]
000078e5533dff8e  vmovaps xmm9, [rsp+0x90]
000078e5533dff97  vmovaps xmm11, [rsp+0xA0]
000078e5533dffa0  vmovaps xmm12, [rsp+0xB0]
000078e5533dffa9  vmovaps xmm13, [rsp+0xC0]
000078e5533dffb2  vmovaps xmm14, [rsp+0xD0]
000078e5533dffbb  vmovaps xmm15, [rsp+0xE0]
000078e5533dffc4  add rsp, 0xF0
000078e5533dffcb  pop r11
000078e5533dffcd  pop r10
000078e5533dffcf  pop r9
000078e5533dffd1  pop r8
000078e5533dffd3  pop rsi
000078e5533dffd4  pop rdi
000078e5533dffd5  pop rdx
000078e5533dffd6  pop rcx
000078e5533dffd7  pop rax
000078e5533dffd8  add rsp, 0x08
000078e5533dffdc  jmp 0x000078E5533DC53B
000078e5533dffe1  sub rsp, 0x08
000078e5533dffe5  push rax
000078e5533dffe6  push rcx
000078e5533dffe7  push rdx
000078e5533dffe8  push rdi
000078e5533dffe9  push rsi
000078e5533dffea  push r8
000078e5533dffec  push r9
000078e5533dffee  push r10
000078e5533dfff0  push r11
000078e5533dfff2  sub rsp, 0xF0
000078e5533dfff9  vmovaps [rsp], xmm0
000078e5533dfffe  vmovaps [rsp+0x10], xmm1
000078e5533e0004  vmovaps [rsp+0x20], xmm2
000078e5533e000a  vmovaps [rsp+0x30], xmm3
000078e5533e0010  vmovaps [rsp+0x40], xmm4
000078e5533e0016  vmovaps [rsp+0x50], xmm5
000078e5533e001c  vmovaps [rsp+0x60], xmm6
000078e5533e0022  vmovaps [rsp+0x70], xmm7
000078e5533e0028  vmovaps [rsp+0x80], xmm9
000078e5533e0031  vmovaps [rsp+0x90], xmm10
000078e5533e003a  vmovaps [rsp+0xA0], xmm11
000078e5533e0043  vmovaps [rsp+0xB0], xmm12
000078e5533e004c  vmovaps [rsp+0xC0], xmm13
000078e5533e0055  vmovaps [rsp+0xD0], xmm14
000078e5533e005e  vmovaps [rsp+0xE0], xmm15
000078e5533e0067  sub rsp, 0x30
000078e5533e006b  movaps [rsp], xmm8
000078e5533e0070  movaps [rsp+0x10], xmm1
000078e5533e0075  movaps [rsp+0x20], xmm14
000078e5533e007b  lea rdi, [rsp]
000078e5533e007f  mov esi, 0x00
000078e5533e0084  mov rax, 0x5F83D5E17530
000078e5533e008e  call rax
000078e5533e0090  movaps xmm8, [rsp]
000078e5533e0095  add rsp, 0x30
000078e5533e0099  vmovaps xmm0, [rsp]
000078e5533e009e  vmovaps xmm1, [rsp+0x10]
000078e5533e00a4  vmovaps xmm2, [rsp+0x20]
000078e5533e00aa  vmovaps xmm3, [rsp+0x30]
000078e5533e00b0  vmovaps xmm4, [rsp+0x40]
000078e5533e00b6  vmovaps xmm5, [rsp+0x50]
000078e5533e00bc  vmovaps xmm6, [rsp+0x60]
000078e5533e00c2  vmovaps xmm7, [rsp+0x70]
000078e5533e00c8  vmovaps xmm9, [rsp+0x80]
000078e5533e00d1  vmovaps xmm10, [rsp+0x90]
000078e5533e00da  vmovaps xmm11, [rsp+0xA0]
000078e5533e00e3  vmovaps xmm12, [rsp+0xB0]
000078e5533e00ec  vmovaps xmm13, [rsp+0xC0]
000078e5533e00f5  vmovaps xmm14, [rsp+0xD0]
000078e5533e00fe  vmovaps xmm15, [rsp+0xE0]
000078e5533e0107  add rsp, 0xF0
000078e5533e010e  pop r11
000078e5533e0110  pop r10
000078e5533e0112  pop r9
000078e5533e0114  pop r8
000078e5533e0116  pop rsi
000078e5533e0117  pop rdi
000078e5533e0118  pop rdx
000078e5533e0119  pop rcx
000078e5533e011a  pop rax
000078e5533e011b  add rsp, 0x08
000078e5533e011f  jmp 0x000078E5533DC561
000078e5533e0124  sub rsp, 0x08
000078e5533e0128  push rax
000078e5533e0129  push rcx
000078e5533e012a  push rdx
000078e5533e012b  push rdi
000078e5533e012c  push rsi
000078e5533e012d  push r8
000078e5533e012f  push r9
000078e5533e0131  push r10
000078e5533e0133  push r11
000078e5533e0135  sub rsp, 0xF0
000078e5533e013c  vmovaps [rsp], xmm0
000078e5533e0141  vmovaps [rsp+0x10], xmm1
000078e5533e0147  vmovaps [rsp+0x20], xmm2
000078e5533e014d  vmovaps [rsp+0x30], xmm3
000078e5533e0153  vmovaps [rsp+0x40], xmm4
000078e5533e0159  vmovaps [rsp+0x50], xmm5
000078e5533e015f  vmovaps [rsp+0x60], xmm7
000078e5533e0165  vmovaps [rsp+0x70], xmm8
000078e5533e016b  vmovaps [rsp+0x80], xmm9
000078e5533e0174  vmovaps [rsp+0x90], xmm10
000078e5533e017d  vmovaps [rsp+0xA0], xmm11
000078e5533e0186  vmovaps [rsp+0xB0], xmm12
000078e5533e018f  vmovaps [rsp+0xC0], xmm13
000078e5533e0198  vmovaps [rsp+0xD0], xmm14
000078e5533e01a1  vmovaps [rsp+0xE0], xmm15
000078e5533e01aa  sub rsp, 0x30
000078e5533e01ae  movaps [rsp], xmm6
000078e5533e01b2  movaps [rsp+0x10], xmm1
000078e5533e01b7  movaps [rsp+0x20], xmm14
000078e5533e01bd  lea rdi, [rsp]
000078e5533e01c1  mov esi, 0x00
000078e5533e01c6  mov rax, 0x5F83D5E17530
000078e5533e01d0  call rax
000078e5533e01d2  movaps xmm6, [rsp]
000078e5533e01d6  add rsp, 0x30
000078e5533e01da  vmovaps xmm0, [rsp]
000078e5533e01df  vmovaps xmm1, [rsp+0x10]
000078e5533e01e5  vmovaps xmm2, [rsp+0x20]
000078e5533e01eb  vmovaps xmm3, [rsp+0x30]
000078e5533e01f1  vmovaps xmm4, [rsp+0x40]
000078e5533e01f7  vmovaps xmm5, [rsp+0x50]
000078e5533e01fd  vmovaps xmm7, [rsp+0x60]
000078e5533e0203  vmovaps xmm8, [rsp+0x70]
000078e5533e0209  vmovaps xmm9, [rsp+0x80]
000078e5533e0212  vmovaps xmm10, [rsp+0x90]
000078e5533e021b  vmovaps xmm11, [rsp+0xA0]
000078e5533e0224  vmovaps xmm12, [rsp+0xB0]
000078e5533e022d  vmovaps xmm13, [rsp+0xC0]
000078e5533e0236  vmovaps xmm14, [rsp+0xD0]
000078e5533e023f  vmovaps xmm15, [rsp+0xE0]
000078e5533e0248  add rsp, 0xF0
000078e5533e024f  pop r11
000078e5533e0251  pop r10
000078e5533e0253  pop r9
000078e5533e0255  pop r8
000078e5533e0257  pop rsi
000078e5533e0258  pop rdi
000078e5533e0259  pop rdx
000078e5533e025a  pop rcx
000078e5533e025b  pop rax
000078e5533e025c  add rsp, 0x08
000078e5533e0260  jmp 0x000078E5533DC58D
000078e5533e0265  sub rsp, 0x08
000078e5533e0269  push rax
000078e5533e026a  push rcx
000078e5533e026b  push rdx
000078e5533e026c  push rdi
000078e5533e026d  push rsi
000078e5533e026e  push r8
000078e5533e0270  push r9
000078e5533e0272  push r10
000078e5533e0274  push r11
000078e5533e0276  sub rsp, 0xF0
000078e5533e027d  vmovaps [rsp], xmm0
000078e5533e0282  vmovaps [rsp+0x10], xmm1
000078e5533e0288  vmovaps [rsp+0x20], xmm2
000078e5533e028e  vmovaps [rsp+0x30], xmm3
000078e5533e0294  vmovaps [rsp+0x40], xmm4
000078e5533e029a  vmovaps [rsp+0x50], xmm5
000078e5533e02a0  vmovaps [rsp+0x60], xmm6
000078e5533e02a6  vmovaps [rsp+0x70], xmm7
000078e5533e02ac  vmovaps [rsp+0x80], xmm8
000078e5533e02b5  vmovaps [rsp+0x90], xmm9
000078e5533e02be  vmovaps [rsp+0xA0], xmm10
000078e5533e02c7  vmovaps [rsp+0xB0], xmm11
000078e5533e02d0  vmovaps [rsp+0xC0], xmm12
000078e5533e02d9  vmovaps [rsp+0xD0], xmm13
000078e5533e02e2  vmovaps [rsp+0xE0], xmm15
000078e5533e02eb  sub rsp, 0x30
000078e5533e02ef  movaps [rsp], xmm14
000078e5533e02f4  movaps [rsp+0x10], xmm12
000078e5533e02fa  movaps [rsp+0x20], xmm1
000078e5533e02ff  lea rdi, [rsp]
000078e5533e0303  mov esi, 0x00
000078e5533e0308  mov rax, 0x5F83D5E17530
000078e5533e0312  call rax
000078e5533e0314  movaps xmm14, [rsp]
000078e5533e0319  add rsp, 0x30
000078e5533e031d  vmovaps xmm0, [rsp]
000078e5533e0322  vmovaps xmm1, [rsp+0x10]
000078e5533e0328  vmovaps xmm2, [rsp+0x20]
000078e5533e032e  vmovaps xmm3, [rsp+0x30]
000078e5533e0334  vmovaps xmm4, [rsp+0x40]
000078e5533e033a  vmovaps xmm5, [rsp+0x50]
000078e5533e0340  vmovaps xmm6, [rsp+0x60]
000078e5533e0346  vmovaps xmm7, [rsp+0x70]
000078e5533e034c  vmovaps xmm8, [rsp+0x80]
000078e5533e0355  vmovaps xmm9, [rsp+0x90]
000078e5533e035e  vmovaps xmm10, [rsp+0xA0]
000078e5533e0367  vmovaps xmm11, [rsp+0xB0]
000078e5533e0370  vmovaps xmm12, [rsp+0xC0]
000078e5533e0379  vmovaps xmm13, [rsp+0xD0]
000078e5533e0382  vmovaps xmm15, [rsp+0xE0]
000078e5533e038b  add rsp, 0xF0
000078e5533e0392  pop r11
000078e5533e0394  pop r10
000078e5533e0396  pop r9
000078e5533e0398  pop r8
000078e5533e039a  pop rsi
000078e5533e039b  pop rdi
000078e5533e039c  pop rdx
000078e5533e039d  pop rcx
000078e5533e039e  pop rax
000078e5533e039f  add rsp, 0x08
000078e5533e03a3  jmp 0x000078E5533DC5B3
000078e5533e03a8  sub rsp, 0x08
000078e5533e03ac  push rax
000078e5533e03ad  push rcx
000078e5533e03ae  push rdx
000078e5533e03af  push rdi
000078e5533e03b0  push rsi
000078e5533e03b1  push r8
000078e5533e03b3  push r9
000078e5533e03b5  push r10
000078e5533e03b7  push r11
000078e5533e03b9  sub rsp, 0xF0
000078e5533e03c0  vmovaps [rsp], xmm0
000078e5533e03c5  vmovaps [rsp+0x10], xmm2
000078e5533e03cb  vmovaps [rsp+0x20], xmm3
000078e5533e03d1  vmovaps [rsp+0x30], xmm4
000078e5533e03d7  vmovaps [rsp+0x40], xmm5
000078e5533e03dd  vmovaps [rsp+0x50], xmm6
000078e5533e03e3  vmovaps [rsp+0x60], xmm7
000078e5533e03e9  vmovaps [rsp+0x70], xmm8
000078e5533e03ef  vmovaps [rsp+0x80], xmm9
000078e5533e03f8  vmovaps [rsp+0x90], xmm10
000078e5533e0401  vmovaps [rsp+0xA0], xmm11
000078e5533e040a  vmovaps [rsp+0xB0], xmm12
000078e5533e0413  vmovaps [rsp+0xC0], xmm13
000078e5533e041c  vmovaps [rsp+0xD0], xmm14
000078e5533e0425  vmovaps [rsp+0xE0], xmm15
000078e5533e042e  sub rsp, 0x30
000078e5533e0432  movaps [rsp], xmm1
000078e5533e0436  movaps [rsp+0x10], xmm13
000078e5533e043c  movaps [rsp+0x20], xmm9
000078e5533e0442  lea rdi, [rsp]
000078e5533e0446  mov esi, 0x00
000078e5533e044b  mov rax, 0x5F83D5E17530
000078e5533e0455  call rax
000078e5533e0457  movaps xmm1, [rsp]
000078e5533e045b  add rsp, 0x30
000078e5533e045f  vmovaps xmm0, [rsp]
000078e5533e0464  vmovaps xmm2, [rsp+0x10]
000078e5533e046a  vmovaps xmm3, [rsp+0x20]
000078e5533e0470  vmovaps xmm4, [rsp+0x30]
000078e5533e0476  vmovaps xmm5, [rsp+0x40]
000078e5533e047c  vmovaps xmm6, [rsp+0x50]
000078e5533e0482  vmovaps xmm7, [rsp+0x60]
000078e5533e0488  vmovaps xmm8, [rsp+0x70]
000078e5533e048e  vmovaps xmm9, [rsp+0x80]
000078e5533e0497  vmovaps xmm10, [rsp+0x90]
000078e5533e04a0  vmovaps xmm11, [rsp+0xA0]
000078e5533e04a9  vmovaps xmm12, [rsp+0xB0]
000078e5533e04b2  vmovaps xmm13, [rsp+0xC0]
000078e5533e04bb  vmovaps xmm14, [rsp+0xD0]
000078e5533e04c4  vmovaps xmm15, [rsp+0xE0]
000078e5533e04cd  add rsp, 0xF0
000078e5533e04d4  pop r11
000078e5533e04d6  pop r10
000078e5533e04d8  pop r9
000078e5533e04da  pop r8
000078e5533e04dc  pop rsi
000078e5533e04dd  pop rdi
000078e5533e04de  pop rdx
000078e5533e04df  pop rcx
000078e5533e04e0  pop rax
000078e5533e04e1  add rsp, 0x08
000078e5533e04e5  jmp 0x000078E5533DC5CD
000078e5533e04ea  sub rsp, 0x08
000078e5533e04ee  push rax
000078e5533e04ef  push rcx
000078e5533e04f0  push rdx
000078e5533e04f1  push rdi
000078e5533e04f2  push rsi
000078e5533e04f3  push r8
000078e5533e04f5  push r9
000078e5533e04f7  push r10
000078e5533e04f9  push r11
000078e5533e04fb  sub rsp, 0xF0
000078e5533e0502  vmovaps [rsp], xmm0
000078e5533e0507  vmovaps [rsp+0x10], xmm1
000078e5533e050d  vmovaps [rsp+0x20], xmm2
000078e5533e0513  vmovaps [rsp+0x30], xmm3
000078e5533e0519  vmovaps [rsp+0x40], xmm4
000078e5533e051f  vmovaps [rsp+0x50], xmm5
000078e5533e0525  vmovaps [rsp+0x60], xmm6
000078e5533e052b  vmovaps [rsp+0x70], xmm7
000078e5533e0531  vmovaps [rsp+0x80], xmm8
000078e5533e053a  vmovaps [rsp+0x90], xmm9
000078e5533e0543  vmovaps [rsp+0xA0], xmm10
000078e5533e054c  vmovaps [rsp+0xB0], xmm11
000078e5533e0555  vmovaps [rsp+0xC0], xmm13
000078e5533e055e  vmovaps [rsp+0xD0], xmm14
000078e5533e0567  vmovaps [rsp+0xE0], xmm15
000078e5533e0570  sub rsp, 0x30
000078e5533e0574  movaps [rsp], xmm12
000078e5533e0579  movaps [rsp+0x10], xmm7
000078e5533e057e  movaps [rsp+0x20], xmm13
000078e5533e0584  lea rdi, [rsp]
000078e5533e0588  mov esi, 0x00
000078e5533e058d  mov rax, 0x5F83D5E17530
000078e5533e0597  call rax
000078e5533e0599  movaps xmm12, [rsp]
000078e5533e059e  add rsp, 0x30
000078e5533e05a2  vmovaps xmm0, [rsp]
000078e5533e05a7  vmovaps xmm1, [rsp+0x10]
000078e5533e05ad  vmovaps xmm2, [rsp+0x20]
000078e5533e05b3  vmovaps xmm3, [rsp+0x30]
000078e5533e05b9  vmovaps xmm4, [rsp+0x40]
000078e5533e05bf  vmovaps xmm5, [rsp+0x50]
000078e5533e05c5  vmovaps xmm6, [rsp+0x60]
000078e5533e05cb  vmovaps xmm7, [rsp+0x70]
000078e5533e05d1  vmovaps xmm8, [rsp+0x80]
000078e5533e05da  vmovaps xmm9, [rsp+0x90]
000078e5533e05e3  vmovaps xmm10, [rsp+0xA0]
000078e5533e05ec  vmovaps xmm11, [rsp+0xB0]
000078e5533e05f5  vmovaps xmm13, [rsp+0xC0]
000078e5533e05fe  vmovaps xmm14, [rsp+0xD0]
000078e5533e0607  vmovaps xmm15, [rsp+0xE0]
000078e5533e0610  add rsp, 0xF0
000078e5533e0617  pop r11
000078e5533e0619  pop r10
000078e5533e061b  pop r9
000078e5533e061d  pop r8
000078e5533e061f  pop rsi
000078e5533e0620  pop rdi
000078e5533e0621  pop rdx
000078e5533e0622  pop rcx
000078e5533e0623  pop rax
000078e5533e0624  add rsp, 0x08
000078e5533e0628  jmp 0x000078E5533DC5F4
000078e5533e062d  sub rsp, 0x08
000078e5533e0631  push rax
000078e5533e0632  push rcx
000078e5533e0633  push rdx
000078e5533e0634  push rdi
000078e5533e0635  push rsi
000078e5533e0636  push r8
000078e5533e0638  push r9
000078e5533e063a  push r10
000078e5533e063c  push r11
000078e5533e063e  sub rsp, 0xF0
000078e5533e0645  vmovaps [rsp], xmm0
000078e5533e064a  vmovaps [rsp+0x10], xmm1
000078e5533e0650  vmovaps [rsp+0x20], xmm2
000078e5533e0656  vmovaps [rsp+0x30], xmm3
000078e5533e065c  vmovaps [rsp+0x40], xmm4
000078e5533e0662  vmovaps [rsp+0x50], xmm5
000078e5533e0668  vmovaps [rsp+0x60], xmm6
000078e5533e066e  vmovaps [rsp+0x70], xmm7
000078e5533e0674  vmovaps [rsp+0x80], xmm8
000078e5533e067d  vmovaps [rsp+0x90], xmm9
000078e5533e0686  vmovaps [rsp+0xA0], xmm10
000078e5533e068f  vmovaps [rsp+0xB0], xmm11
000078e5533e0698  vmovaps [rsp+0xC0], xmm12
000078e5533e06a1  vmovaps [rsp+0xD0], xmm14
000078e5533e06aa  vmovaps [rsp+0xE0], xmm15
000078e5533e06b3  sub rsp, 0x30
000078e5533e06b7  movaps [rsp], xmm13
000078e5533e06bc  movaps [rsp+0x10], xmm15
000078e5533e06c2  movaps [rsp+0x20], xmm8
000078e5533e06c8  lea rdi, [rsp]
000078e5533e06cc  mov esi, 0x00
000078e5533e06d1  mov rax, 0x5F83D5E17530
000078e5533e06db  call rax
000078e5533e06dd  movaps xmm13, [rsp]
000078e5533e06e2  add rsp, 0x30
000078e5533e06e6  vmovaps xmm0, [rsp]
000078e5533e06eb  vmovaps xmm1, [rsp+0x10]
000078e5533e06f1  vmovaps xmm2, [rsp+0x20]
000078e5533e06f7  vmovaps xmm3, [rsp+0x30]
000078e5533e06fd  vmovaps xmm4, [rsp+0x40]
000078e5533e0703  vmovaps xmm5, [rsp+0x50]
000078e5533e0709  vmovaps xmm6, [rsp+0x60]
000078e5533e070f  vmovaps xmm7, [rsp+0x70]
000078e5533e0715  vmovaps xmm8, [rsp+0x80]
000078e5533e071e  vmovaps xmm9, [rsp+0x90]
000078e5533e0727  vmovaps xmm10, [rsp+0xA0]
000078e5533e0730  vmovaps xmm11, [rsp+0xB0]
000078e5533e0739  vmovaps xmm12, [rsp+0xC0]
000078e5533e0742  vmovaps xmm14, [rsp+0xD0]
000078e5533e074b  vmovaps xmm15, [rsp+0xE0]
000078e5533e0754  add rsp, 0xF0
000078e5533e075b  pop r11
000078e5533e075d  pop r10
000078e5533e075f  pop r9
000078e5533e0761  pop r8
000078e5533e0763  pop rsi
000078e5533e0764  pop rdi
000078e5533e0765  pop rdx
000078e5533e0766  pop rcx
000078e5533e0767  pop rax
000078e5533e0768  add rsp, 0x08
000078e5533e076c  jmp 0x000078E5533DC60F
000078e5533e0771  sub rsp, 0x08
000078e5533e0775  push rax
000078e5533e0776  push rcx
000078e5533e0777  push rdx
000078e5533e0778  push rdi
000078e5533e0779  push rsi
000078e5533e077a  push r8
000078e5533e077c  push r9
000078e5533e077e  push r10
000078e5533e0780  push r11
000078e5533e0782  sub rsp, 0xF0
000078e5533e0789  vmovaps [rsp], xmm0
000078e5533e078e  vmovaps [rsp+0x10], xmm1
000078e5533e0794  vmovaps [rsp+0x20], xmm2
000078e5533e079a  vmovaps [rsp+0x30], xmm3
000078e5533e07a0  vmovaps [rsp+0x40], xmm4
000078e5533e07a6  vmovaps [rsp+0x50], xmm5
000078e5533e07ac  vmovaps [rsp+0x60], xmm6
000078e5533e07b2  vmovaps [rsp+0x70], xmm7
000078e5533e07b8  vmovaps [rsp+0x80], xmm9
000078e5533e07c1  vmovaps [rsp+0x90], xmm10
000078e5533e07ca  vmovaps [rsp+0xA0], xmm11
000078e5533e07d3  vmovaps [rsp+0xB0], xmm12
000078e5533e07dc  vmovaps [rsp+0xC0], xmm13
000078e5533e07e5  vmovaps [rsp+0xD0], xmm14
000078e5533e07ee  vmovaps [rsp+0xE0], xmm15
000078e5533e07f7  sub rsp, 0x30
000078e5533e07fb  movaps [rsp], xmm8
000078e5533e0800  movaps [rsp+0x10], xmm15
000078e5533e0806  movaps [rsp+0x20], xmm9
000078e5533e080c  lea rdi, [rsp]
000078e5533e0810  mov esi, 0x00
000078e5533e0815  mov rax, 0x5F83D5E17530
000078e5533e081f  call rax
000078e5533e0821  movaps xmm8, [rsp]
000078e5533e0826  add rsp, 0x30
000078e5533e082a  vmovaps xmm0, [rsp]
000078e5533e082f  vmovaps xmm1, [rsp+0x10]
000078e5533e0835  vmovaps xmm2, [rsp+0x20]
000078e5533e083b  vmovaps xmm3, [rsp+0x30]
000078e5533e0841  vmovaps xmm4, [rsp+0x40]
000078e5533e0847  vmovaps xmm5, [rsp+0x50]
000078e5533e084d  vmovaps xmm6, [rsp+0x60]
000078e5533e0853  vmovaps xmm7, [rsp+0x70]
000078e5533e0859  vmovaps xmm9, [rsp+0x80]
000078e5533e0862  vmovaps xmm10, [rsp+0x90]
000078e5533e086b  vmovaps xmm11, [rsp+0xA0]
000078e5533e0874  vmovaps xmm12, [rsp+0xB0]
000078e5533e087d  vmovaps xmm13, [rsp+0xC0]
000078e5533e0886  vmovaps xmm14, [rsp+0xD0]
000078e5533e088f  vmovaps xmm15, [rsp+0xE0]
000078e5533e0898  add rsp, 0xF0
000078e5533e089f  pop r11
000078e5533e08a1  pop r10
000078e5533e08a3  pop r9
000078e5533e08a5  pop r8
000078e5533e08a7  pop rsi
000078e5533e08a8  pop rdi
000078e5533e08a9  pop rdx
000078e5533e08aa  pop rcx
000078e5533e08ab  pop rax
000078e5533e08ac  add rsp, 0x08
000078e5533e08b0  jmp 0x000078E5533DC63D
000078e5533e08b5  sub rsp, 0x08
000078e5533e08b9  push rax
000078e5533e08ba  push rcx
000078e5533e08bb  push rdx
000078e5533e08bc  push rdi
000078e5533e08bd  push rsi
000078e5533e08be  push r8
000078e5533e08c0  push r9
000078e5533e08c2  push r10
000078e5533e08c4  push r11
000078e5533e08c6  sub rsp, 0xF0
000078e5533e08cd  vmovaps [rsp], xmm0
000078e5533e08d2  vmovaps [rsp+0x10], xmm1
000078e5533e08d8  vmovaps [rsp+0x20], xmm2
000078e5533e08de  vmovaps [rsp+0x30], xmm3
000078e5533e08e4  vmovaps [rsp+0x40], xmm4
000078e5533e08ea  vmovaps [rsp+0x50], xmm5
000078e5533e08f0  vmovaps [rsp+0x60], xmm6
000078e5533e08f6  vmovaps [rsp+0x70], xmm7
000078e5533e08fc  vmovaps [rsp+0x80], xmm8
000078e5533e0905  vmovaps [rsp+0x90], xmm9
000078e5533e090e  vmovaps [rsp+0xA0], xmm10
000078e5533e0917  vmovaps [rsp+0xB0], xmm11
000078e5533e0920  vmovaps [rsp+0xC0], xmm12
000078e5533e0929  vmovaps [rsp+0xD0], xmm13
000078e5533e0932  vmovaps [rsp+0xE0], xmm14
000078e5533e093b  sub rsp, 0x30
000078e5533e093f  movaps [rsp], xmm15
000078e5533e0944  movaps [rsp+0x10], xmm11
000078e5533e094a  movaps [rsp+0x20], xmm6
000078e5533e094f  lea rdi, [rsp]
000078e5533e0953  mov esi, 0x00
000078e5533e0958  mov rax, 0x5F83D5E17530
000078e5533e0962  call rax
000078e5533e0964  movaps xmm15, [rsp]
000078e5533e0969  add rsp, 0x30
000078e5533e096d  vmovaps xmm0, [rsp]
000078e5533e0972  vmovaps xmm1, [rsp+0x10]
000078e5533e0978  vmovaps xmm2, [rsp+0x20]
000078e5533e097e  vmovaps xmm3, [rsp+0x30]
000078e5533e0984  vmovaps xmm4, [rsp+0x40]
000078e5533e098a  vmovaps xmm5, [rsp+0x50]
000078e5533e0990  vmovaps xmm6, [rsp+0x60]
000078e5533e0996  vmovaps xmm7, [rsp+0x70]
000078e5533e099c  vmovaps xmm8, [rsp+0x80]
000078e5533e09a5  vmovaps xmm9, [rsp+0x90]
000078e5533e09ae  vmovaps xmm10, [rsp+0xA0]
000078e5533e09b7  vmovaps xmm11, [rsp+0xB0]
000078e5533e09c0  vmovaps xmm12, [rsp+0xC0]
000078e5533e09c9  vmovaps xmm13, [rsp+0xD0]
000078e5533e09d2  vmovaps xmm14, [rsp+0xE0]
000078e5533e09db  add rsp, 0xF0
000078e5533e09e2  pop r11
000078e5533e09e4  pop r10
000078e5533e09e6  pop r9
000078e5533e09e8  pop r8
000078e5533e09ea  pop rsi
000078e5533e09eb  pop rdi
000078e5533e09ec  pop rdx
000078e5533e09ed  pop rcx
000078e5533e09ee  pop rax
000078e5533e09ef  add rsp, 0x08
000078e5533e09f3  jmp 0x000078E5533DC658
000078e5533e09f8  sub rsp, 0x08
000078e5533e09fc  push rax
000078e5533e09fd  push rcx
000078e5533e09fe  push rdx
000078e5533e09ff  push rdi
000078e5533e0a00  push rsi
000078e5533e0a01  push r8
000078e5533e0a03  push r9
000078e5533e0a05  push r10
000078e5533e0a07  push r11
000078e5533e0a09  sub rsp, 0xF0
000078e5533e0a10  vmovaps [rsp], xmm0
000078e5533e0a15  vmovaps [rsp+0x10], xmm1
000078e5533e0a1b  vmovaps [rsp+0x20], xmm2
000078e5533e0a21  vmovaps [rsp+0x30], xmm3
000078e5533e0a27  vmovaps [rsp+0x40], xmm4
000078e5533e0a2d  vmovaps [rsp+0x50], xmm5
000078e5533e0a33  vmovaps [rsp+0x60], xmm6
000078e5533e0a39  vmovaps [rsp+0x70], xmm8
000078e5533e0a3f  vmovaps [rsp+0x80], xmm9
000078e5533e0a48  vmovaps [rsp+0x90], xmm10
000078e5533e0a51  vmovaps [rsp+0xA0], xmm11
000078e5533e0a5a  vmovaps [rsp+0xB0], xmm12
000078e5533e0a63  vmovaps [rsp+0xC0], xmm13
000078e5533e0a6c  vmovaps [rsp+0xD0], xmm14
000078e5533e0a75  vmovaps [rsp+0xE0], xmm15
000078e5533e0a7e  sub rsp, 0x30
000078e5533e0a82  movaps [rsp], xmm7
000078e5533e0a86  movaps [rsp+0x10], xmm11
000078e5533e0a8c  movaps [rsp+0x20], xmm9
000078e5533e0a92  lea rdi, [rsp]
000078e5533e0a96  mov esi, 0x00
000078e5533e0a9b  mov rax, 0x5F83D5E17530
000078e5533e0aa5  call rax
000078e5533e0aa7  movaps xmm7, [rsp]
000078e5533e0aab  add rsp, 0x30
000078e5533e0aaf  vmovaps xmm0, [rsp]
000078e5533e0ab4  vmovaps xmm1, [rsp+0x10]
000078e5533e0aba  vmovaps xmm2, [rsp+0x20]
000078e5533e0ac0  vmovaps xmm3, [rsp+0x30]
000078e5533e0ac6  vmovaps xmm4, [rsp+0x40]
000078e5533e0acc  vmovaps xmm5, [rsp+0x50]
000078e5533e0ad2  vmovaps xmm6, [rsp+0x60]
000078e5533e0ad8  vmovaps xmm8, [rsp+0x70]
000078e5533e0ade  vmovaps xmm9, [rsp+0x80]
000078e5533e0ae7  vmovaps xmm10, [rsp+0x90]
000078e5533e0af0  vmovaps xmm11, [rsp+0xA0]
000078e5533e0af9  vmovaps xmm12, [rsp+0xB0]
000078e5533e0b02  vmovaps xmm13, [rsp+0xC0]
000078e5533e0b0b  vmovaps xmm14, [rsp+0xD0]
000078e5533e0b14  vmovaps xmm15, [rsp+0xE0]
000078e5533e0b1d  add rsp, 0xF0
000078e5533e0b24  pop r11
000078e5533e0b26  pop r10
000078e5533e0b28  pop r9
000078e5533e0b2a  pop r8
000078e5533e0b2c  pop rsi
000078e5533e0b2d  pop rdi
000078e5533e0b2e  pop rdx
000078e5533e0b2f  pop rcx
000078e5533e0b30  pop rax
000078e5533e0b31  add rsp, 0x08
000078e5533e0b35  jmp 0x000078E5533DC685
000078e5533e0b3a  sub rsp, 0x08
000078e5533e0b3e  push rax
000078e5533e0b3f  push rcx
000078e5533e0b40  push rdx
000078e5533e0b41  push rdi
000078e5533e0b42  push rsi
000078e5533e0b43  push r8
000078e5533e0b45  push r9
000078e5533e0b47  push r10
000078e5533e0b49  push r11
000078e5533e0b4b  sub rsp, 0xF0
000078e5533e0b52  vmovaps [rsp], xmm0
000078e5533e0b57  vmovaps [rsp+0x10], xmm1
000078e5533e0b5d  vmovaps [rsp+0x20], xmm2
000078e5533e0b63  vmovaps [rsp+0x30], xmm3
000078e5533e0b69  vmovaps [rsp+0x40], xmm4
000078e5533e0b6f  vmovaps [rsp+0x50], xmm5
000078e5533e0b75  vmovaps [rsp+0x60], xmm6
000078e5533e0b7b  vmovaps [rsp+0x70], xmm7
000078e5533e0b81  vmovaps [rsp+0x80], xmm8
000078e5533e0b8a  vmovaps [rsp+0x90], xmm9
000078e5533e0b93  vmovaps [rsp+0xA0], xmm10
000078e5533e0b9c  vmovaps [rsp+0xB0], xmm12
000078e5533e0ba5  vmovaps [rsp+0xC0], xmm13
000078e5533e0bae  vmovaps [rsp+0xD0], xmm14
000078e5533e0bb7  vmovaps [rsp+0xE0], xmm15
000078e5533e0bc0  sub rsp, 0x30
000078e5533e0bc4  movaps [rsp], xmm11
000078e5533e0bc9  movaps [rsp+0x10], xmm10
000078e5533e0bcf  movaps [rsp+0x20], xmm14
000078e5533e0bd5  lea rdi, [rsp]
000078e5533e0bd9  mov esi, 0x00
000078e5533e0bde  mov rax, 0x5F83D5E17530
000078e5533e0be8  call rax
000078e5533e0bea  movaps xmm11, [rsp]
000078e5533e0bef  add rsp, 0x30
000078e5533e0bf3  vmovaps xmm0, [rsp]
000078e5533e0bf8  vmovaps xmm1, [rsp+0x10]
000078e5533e0bfe  vmovaps xmm2, [rsp+0x20]
000078e5533e0c04  vmovaps xmm3, [rsp+0x30]
000078e5533e0c0a  vmovaps xmm4, [rsp+0x40]
000078e5533e0c10  vmovaps xmm5, [rsp+0x50]
000078e5533e0c16  vmovaps xmm6, [rsp+0x60]
000078e5533e0c1c  vmovaps xmm7, [rsp+0x70]
000078e5533e0c22  vmovaps xmm8, [rsp+0x80]
000078e5533e0c2b  vmovaps xmm9, [rsp+0x90]
000078e5533e0c34  vmovaps xmm10, [rsp+0xA0]
000078e5533e0c3d  vmovaps xmm12, [rsp+0xB0]
000078e5533e0c46  vmovaps xmm13, [rsp+0xC0]
000078e5533e0c4f  vmovaps xmm14, [rsp+0xD0]
000078e5533e0c58  vmovaps xmm15, [rsp+0xE0]
000078e5533e0c61  add rsp, 0xF0
000078e5533e0c68  pop r11
000078e5533e0c6a  pop r10
000078e5533e0c6c  pop r9
000078e5533e0c6e  pop r8
000078e5533e0c70  pop rsi
000078e5533e0c71  pop rdi
000078e5533e0c72  pop rdx
000078e5533e0c73  pop rcx
000078e5533e0c74  pop rax
000078e5533e0c75  add rsp, 0x08
000078e5533e0c79  jmp 0x000078E5533DC6A0
000078e5533e0c7e  call 0x000078E5532C33A0
000078e5533e0c83  jmp 0x000078E5533DC6AA
000078e5533e0c88  sub rsp, 0x08
000078e5533e0c8c  push rax
000078e5533e0c8d  push rcx
000078e5533e0c8e  push rdx
000078e5533e0c8f  push rdi
000078e5533e0c90  push rsi
000078e5533e0c91  push r8
000078e5533e0c93  push r9
000078e5533e0c95  push r10
000078e5533e0c97  push r11
000078e5533e0c99  sub rsp, 0xF0
000078e5533e0ca0  vmovaps [rsp], xmm0
000078e5533e0ca5  vmovaps [rsp+0x10], xmm1
000078e5533e0cab  vmovaps [rsp+0x20], xmm2
000078e5533e0cb1  vmovaps [rsp+0x30], xmm3
000078e5533e0cb7  vmovaps [rsp+0x40], xmm4
000078e5533e0cbd  vmovaps [rsp+0x50], xmm5
000078e5533e0cc3  vmovaps [rsp+0x60], xmm6
000078e5533e0cc9  vmovaps [rsp+0x70], xmm7
000078e5533e0ccf  vmovaps [rsp+0x80], xmm8
000078e5533e0cd8  vmovaps [rsp+0x90], xmm9
000078e5533e0ce1  vmovaps [rsp+0xA0], xmm11
000078e5533e0cea  vmovaps [rsp+0xB0], xmm12
000078e5533e0cf3  vmovaps [rsp+0xC0], xmm13
000078e5533e0cfc  vmovaps [rsp+0xD0], xmm14
000078e5533e0d05  vmovaps [rsp+0xE0], xmm15
000078e5533e0d0e  sub rsp, 0x30
000078e5533e0d12  movaps [rsp], xmm10
000078e5533e0d17  movaps [rsp+0x10], xmm1
000078e5533e0d1c  movaps [rsp+0x20], xmm12
000078e5533e0d22  lea rdi, [rsp]
000078e5533e0d26  mov esi, 0x00
000078e5533e0d2b  mov rax, 0x5F83D5E17530
000078e5533e0d35  call rax
000078e5533e0d37  movaps xmm10, [rsp]
000078e5533e0d3c  add rsp, 0x30
000078e5533e0d40  vmovaps xmm0, [rsp]
000078e5533e0d45  vmovaps xmm1, [rsp+0x10]
000078e5533e0d4b  vmovaps xmm2, [rsp+0x20]
000078e5533e0d51  vmovaps xmm3, [rsp+0x30]
000078e5533e0d57  vmovaps xmm4, [rsp+0x40]
000078e5533e0d5d  vmovaps xmm5, [rsp+0x50]
000078e5533e0d63  vmovaps xmm6, [rsp+0x60]
000078e5533e0d69  vmovaps xmm7, [rsp+0x70]
000078e5533e0d6f  vmovaps xmm8, [rsp+0x80]
000078e5533e0d78  vmovaps xmm9, [rsp+0x90]
000078e5533e0d81  vmovaps xmm11, [rsp+0xA0]
000078e5533e0d8a  vmovaps xmm12, [rsp+0xB0]
000078e5533e0d93  vmovaps xmm13, [rsp+0xC0]
000078e5533e0d9c  vmovaps xmm14, [rsp+0xD0]
000078e5533e0da5  vmovaps xmm15, [rsp+0xE0]
000078e5533e0dae  add rsp, 0xF0
000078e5533e0db5  pop r11
000078e5533e0db7  pop r10
000078e5533e0db9  pop r9
000078e5533e0dbb  pop r8
000078e5533e0dbd  pop rsi
000078e5533e0dbe  pop rdi
000078e5533e0dbf  pop rdx
000078e5533e0dc0  pop rcx
000078e5533e0dc1  pop rax
000078e5533e0dc2  add rsp, 0x08
000078e5533e0dc6  jmp 0x000078E5533DC6CD
000078e5533e0dcb  sub rsp, 0x08
000078e5533e0dcf  push rax
000078e5533e0dd0  push rcx
000078e5533e0dd1  push rdx
000078e5533e0dd2  push rdi
000078e5533e0dd3  push rsi
000078e5533e0dd4  push r8
000078e5533e0dd6  push r9
000078e5533e0dd8  push r10
000078e5533e0dda  push r11
000078e5533e0ddc  sub rsp, 0xF0
000078e5533e0de3  vmovaps [rsp], xmm0
000078e5533e0de8  vmovaps [rsp+0x10], xmm1
000078e5533e0dee  vmovaps [rsp+0x20], xmm2
000078e5533e0df4  vmovaps [rsp+0x30], xmm3
000078e5533e0dfa  vmovaps [rsp+0x40], xmm4
000078e5533e0e00  vmovaps [rsp+0x50], xmm5
000078e5533e0e06  vmovaps [rsp+0x60], xmm6
000078e5533e0e0c  vmovaps [rsp+0x70], xmm7
000078e5533e0e12  vmovaps [rsp+0x80], xmm8
000078e5533e0e1b  vmovaps [rsp+0x90], xmm9
000078e5533e0e24  vmovaps [rsp+0xA0], xmm10
000078e5533e0e2d  vmovaps [rsp+0xB0], xmm11
000078e5533e0e36  vmovaps [rsp+0xC0], xmm13
000078e5533e0e3f  vmovaps [rsp+0xD0], xmm14
000078e5533e0e48  vmovaps [rsp+0xE0], xmm15
000078e5533e0e51  sub rsp, 0x30
000078e5533e0e55  movaps [rsp], xmm12
000078e5533e0e5a  movaps [rsp+0x10], xmm14
000078e5533e0e60  movaps [rsp+0x20], xmm1
000078e5533e0e65  lea rdi, [rsp]
000078e5533e0e69  mov esi, 0x00
000078e5533e0e6e  mov rax, 0x5F83D5E17530
000078e5533e0e78  call rax
000078e5533e0e7a  movaps xmm12, [rsp]
000078e5533e0e7f  add rsp, 0x30
000078e5533e0e83  vmovaps xmm0, [rsp]
000078e5533e0e88  vmovaps xmm1, [rsp+0x10]
000078e5533e0e8e  vmovaps xmm2, [rsp+0x20]
000078e5533e0e94  vmovaps xmm3, [rsp+0x30]
000078e5533e0e9a  vmovaps xmm4, [rsp+0x40]
000078e5533e0ea0  vmovaps xmm5, [rsp+0x50]
000078e5533e0ea6  vmovaps xmm6, [rsp+0x60]
000078e5533e0eac  vmovaps xmm7, [rsp+0x70]
000078e5533e0eb2  vmovaps xmm8, [rsp+0x80]
000078e5533e0ebb  vmovaps xmm9, [rsp+0x90]
000078e5533e0ec4  vmovaps xmm10, [rsp+0xA0]
000078e5533e0ecd  vmovaps xmm11, [rsp+0xB0]
000078e5533e0ed6  vmovaps xmm13, [rsp+0xC0]
000078e5533e0edf  vmovaps xmm14, [rsp+0xD0]
000078e5533e0ee8  vmovaps xmm15, [rsp+0xE0]
000078e5533e0ef1  add rsp, 0xF0
000078e5533e0ef8  pop r11
000078e5533e0efa  pop r10
000078e5533e0efc  pop r9
000078e5533e0efe  pop r8
000078e5533e0f00  pop rsi
000078e5533e0f01  pop rdi
000078e5533e0f02  pop rdx
000078e5533e0f03  pop rcx
000078e5533e0f04  pop rax
000078e5533e0f05  add rsp, 0x08
000078e5533e0f09  jmp 0x000078E5533DC6FC
000078e5533e0f0e  sub rsp, 0x08
000078e5533e0f12  push rax
000078e5533e0f13  push rcx
000078e5533e0f14  push rdx
000078e5533e0f15  push rdi
000078e5533e0f16  push rsi
000078e5533e0f17  push r8
000078e5533e0f19  push r9
000078e5533e0f1b  push r10
000078e5533e0f1d  push r11
000078e5533e0f1f  sub rsp, 0xF0
000078e5533e0f26  vmovaps [rsp], xmm0
000078e5533e0f2b  vmovaps [rsp+0x10], xmm1
000078e5533e0f31  vmovaps [rsp+0x20], xmm2
000078e5533e0f37  vmovaps [rsp+0x30], xmm3
000078e5533e0f3d  vmovaps [rsp+0x40], xmm4
000078e5533e0f43  vmovaps [rsp+0x50], xmm5
000078e5533e0f49  vmovaps [rsp+0x60], xmm6
000078e5533e0f4f  vmovaps [rsp+0x70], xmm7
000078e5533e0f55  vmovaps [rsp+0x80], xmm8
000078e5533e0f5e  vmovaps [rsp+0x90], xmm9
000078e5533e0f67  vmovaps [rsp+0xA0], xmm10
000078e5533e0f70  vmovaps [rsp+0xB0], xmm11
000078e5533e0f79  vmovaps [rsp+0xC0], xmm12
000078e5533e0f82  vmovaps [rsp+0xD0], xmm13
000078e5533e0f8b  vmovaps [rsp+0xE0], xmm15
000078e5533e0f94  sub rsp, 0x30
000078e5533e0f98  movaps [rsp], xmm14
000078e5533e0f9d  movaps [rsp+0x10], xmm9
000078e5533e0fa3  movaps [rsp+0x20], xmm1
000078e5533e0fa8  lea rdi, [rsp]
000078e5533e0fac  mov esi, 0x00
000078e5533e0fb1  mov rax, 0x5F83D5E17530
000078e5533e0fbb  call rax
000078e5533e0fbd  movaps xmm14, [rsp]
000078e5533e0fc2  add rsp, 0x30
000078e5533e0fc6  vmovaps xmm0, [rsp]
000078e5533e0fcb  vmovaps xmm1, [rsp+0x10]
000078e5533e0fd1  vmovaps xmm2, [rsp+0x20]
000078e5533e0fd7  vmovaps xmm3, [rsp+0x30]
000078e5533e0fdd  vmovaps xmm4, [rsp+0x40]
000078e5533e0fe3  vmovaps xmm5, [rsp+0x50]
000078e5533e0fe9  vmovaps xmm6, [rsp+0x60]
000078e5533e0fef  vmovaps xmm7, [rsp+0x70]
000078e5533e0ff5  vmovaps xmm8, [rsp+0x80]
000078e5533e0ffe  vmovaps xmm9, [rsp+0x90]
000078e5533e1007  vmovaps xmm10, [rsp+0xA0]
000078e5533e1010  vmovaps xmm11, [rsp+0xB0]
000078e5533e1019  vmovaps xmm12, [rsp+0xC0]
000078e5533e1022  vmovaps xmm13, [rsp+0xD0]
000078e5533e102b  vmovaps xmm15, [rsp+0xE0]
000078e5533e1034  add rsp, 0xF0
000078e5533e103b  pop r11
000078e5533e103d  pop r10
000078e5533e103f  pop r9
000078e5533e1041  pop r8
000078e5533e1043  pop rsi
000078e5533e1044  pop rdi
000078e5533e1045  pop rdx
000078e5533e1046  pop rcx
000078e5533e1047  pop rax
000078e5533e1048  add rsp, 0x08
000078e5533e104c  jmp 0x000078E5533DC72B
000078e5533e1051  sub rsp, 0x08
000078e5533e1055  push rax
000078e5533e1056  push rcx
000078e5533e1057  push rdx
000078e5533e1058  push rdi
000078e5533e1059  push rsi
000078e5533e105a  push r8
000078e5533e105c  push r9
000078e5533e105e  push r10
000078e5533e1060  push r11
000078e5533e1062  sub rsp, 0xF0
000078e5533e1069  vmovaps [rsp], xmm0
000078e5533e106e  vmovaps [rsp+0x10], xmm2
000078e5533e1074  vmovaps [rsp+0x20], xmm3
000078e5533e107a  vmovaps [rsp+0x30], xmm4
000078e5533e1080  vmovaps [rsp+0x40], xmm5
000078e5533e1086  vmovaps [rsp+0x50], xmm6
000078e5533e108c  vmovaps [rsp+0x60], xmm7
000078e5533e1092  vmovaps [rsp+0x70], xmm8
000078e5533e1098  vmovaps [rsp+0x80], xmm9
000078e5533e10a1  vmovaps [rsp+0x90], xmm10
000078e5533e10aa  vmovaps [rsp+0xA0], xmm11
000078e5533e10b3  vmovaps [rsp+0xB0], xmm12
000078e5533e10bc  vmovaps [rsp+0xC0], xmm13
000078e5533e10c5  vmovaps [rsp+0xD0], xmm14
000078e5533e10ce  vmovaps [rsp+0xE0], xmm15
000078e5533e10d7  sub rsp, 0x30
000078e5533e10db  movaps [rsp], xmm1
000078e5533e10df  movaps [rsp+0x10], xmm13
000078e5533e10e5  movaps [rsp+0x20], xmm8
000078e5533e10eb  lea rdi, [rsp]
000078e5533e10ef  mov esi, 0x00
000078e5533e10f4  mov rax, 0x5F83D5E17530
000078e5533e10fe  call rax
000078e5533e1100  movaps xmm1, [rsp]
000078e5533e1104  add rsp, 0x30
000078e5533e1108  vmovaps xmm0, [rsp]
000078e5533e110d  vmovaps xmm2, [rsp+0x10]
000078e5533e1113  vmovaps xmm3, [rsp+0x20]
000078e5533e1119  vmovaps xmm4, [rsp+0x30]
000078e5533e111f  vmovaps xmm5, [rsp+0x40]
000078e5533e1125  vmovaps xmm6, [rsp+0x50]
000078e5533e112b  vmovaps xmm7, [rsp+0x60]
000078e5533e1131  vmovaps xmm8, [rsp+0x70]
000078e5533e1137  vmovaps xmm9, [rsp+0x80]
000078e5533e1140  vmovaps xmm10, [rsp+0x90]
000078e5533e1149  vmovaps xmm11, [rsp+0xA0]
000078e5533e1152  vmovaps xmm12, [rsp+0xB0]
000078e5533e115b  vmovaps xmm13, [rsp+0xC0]
000078e5533e1164  vmovaps xmm14, [rsp+0xD0]
000078e5533e116d  vmovaps xmm15, [rsp+0xE0]
000078e5533e1176  add rsp, 0xF0
000078e5533e117d  pop r11
000078e5533e117f  pop r10
000078e5533e1181  pop r9
000078e5533e1183  pop r8
000078e5533e1185  pop rsi
000078e5533e1186  pop rdi
000078e5533e1187  pop rdx
000078e5533e1188  pop rcx
000078e5533e1189  pop rax
000078e5533e118a  add rsp, 0x08
000078e5533e118e  jmp 0x000078E5533DC74D
000078e5533e1193  call 0x000078E55320C260
000078e5533e1198  jmp 0x000078E5533DC75B
000078e5533e119d  call 0x000078E5532BD750
000078e5533e11a2  jmp 0x000078E5533DC765
000078e5533e11a7  sub rsp, 0x08
000078e5533e11ab  push rax
000078e5533e11ac  push rcx
000078e5533e11ad  push rdx
000078e5533e11ae  push rdi
000078e5533e11af  push rsi
000078e5533e11b0  push r8
000078e5533e11b2  push r9
000078e5533e11b4  push r10
000078e5533e11b6  push r11
000078e5533e11b8  sub rsp, 0xF0
000078e5533e11bf  vmovaps [rsp], xmm0
000078e5533e11c4  vmovaps [rsp+0x10], xmm1
000078e5533e11ca  vmovaps [rsp+0x20], xmm2
000078e5533e11d0  vmovaps [rsp+0x30], xmm3
000078e5533e11d6  vmovaps [rsp+0x40], xmm4
000078e5533e11dc  vmovaps [rsp+0x50], xmm5
000078e5533e11e2  vmovaps [rsp+0x60], xmm6
000078e5533e11e8  vmovaps [rsp+0x70], xmm7
000078e5533e11ee  vmovaps [rsp+0x80], xmm9
000078e5533e11f7  vmovaps [rsp+0x90], xmm10
000078e5533e1200  vmovaps [rsp+0xA0], xmm11
000078e5533e1209  vmovaps [rsp+0xB0], xmm12
000078e5533e1212  vmovaps [rsp+0xC0], xmm13
000078e5533e121b  vmovaps [rsp+0xD0], xmm14
000078e5533e1224  vmovaps [rsp+0xE0], xmm15
000078e5533e122d  sub rsp, 0x30
000078e5533e1231  movaps [rsp], xmm8
000078e5533e1236  movaps [rsp+0x10], xmm15
000078e5533e123c  movaps [rsp+0x20], xmm7
000078e5533e1241  lea rdi, [rsp]
000078e5533e1245  mov esi, 0x00
000078e5533e124a  mov rax, 0x5F83D5E17530
000078e5533e1254  call rax
000078e5533e1256  movaps xmm8, [rsp]
000078e5533e125b  add rsp, 0x30
000078e5533e125f  vmovaps xmm0, [rsp]
000078e5533e1264  vmovaps xmm1, [rsp+0x10]
000078e5533e126a  vmovaps xmm2, [rsp+0x20]
000078e5533e1270  vmovaps xmm3, [rsp+0x30]
000078e5533e1276  vmovaps xmm4, [rsp+0x40]
000078e5533e127c  vmovaps xmm5, [rsp+0x50]
000078e5533e1282  vmovaps xmm6, [rsp+0x60]
000078e5533e1288  vmovaps xmm7, [rsp+0x70]
000078e5533e128e  vmovaps xmm9, [rsp+0x80]
000078e5533e1297  vmovaps xmm10, [rsp+0x90]
000078e5533e12a0  vmovaps xmm11, [rsp+0xA0]
000078e5533e12a9  vmovaps xmm12, [rsp+0xB0]
000078e5533e12b2  vmovaps xmm13, [rsp+0xC0]
000078e5533e12bb  vmovaps xmm14, [rsp+0xD0]
000078e5533e12c4  vmovaps xmm15, [rsp+0xE0]
000078e5533e12cd  add rsp, 0xF0
000078e5533e12d4  pop r11
000078e5533e12d6  pop r10
000078e5533e12d8  pop r9
000078e5533e12da  pop r8
000078e5533e12dc  pop rsi
000078e5533e12dd  pop rdi
000078e5533e12de  pop rdx
000078e5533e12df  pop rcx
000078e5533e12e0  pop rax
000078e5533e12e1  add rsp, 0x08
000078e5533e12e5  jmp 0x000078E5533DC787
000078e5533e12ea  sub rsp, 0x08
000078e5533e12ee  push rax
000078e5533e12ef  push rcx
000078e5533e12f0  push rdx
000078e5533e12f1  push rdi
000078e5533e12f2  push rsi
000078e5533e12f3  push r8
000078e5533e12f5  push r9
000078e5533e12f7  push r10
000078e5533e12f9  push r11
000078e5533e12fb  sub rsp, 0xF0
000078e5533e1302  vmovaps [rsp], xmm0
000078e5533e1307  vmovaps [rsp+0x10], xmm1
000078e5533e130d  vmovaps [rsp+0x20], xmm2
000078e5533e1313  vmovaps [rsp+0x30], xmm3
000078e5533e1319  vmovaps [rsp+0x40], xmm4
000078e5533e131f  vmovaps [rsp+0x50], xmm5
000078e5533e1325  vmovaps [rsp+0x60], xmm6
000078e5533e132b  vmovaps [rsp+0x70], xmm8
000078e5533e1331  vmovaps [rsp+0x80], xmm9
000078e5533e133a  vmovaps [rsp+0x90], xmm10
000078e5533e1343  vmovaps [rsp+0xA0], xmm11
000078e5533e134c  vmovaps [rsp+0xB0], xmm12
000078e5533e1355  vmovaps [rsp+0xC0], xmm13
000078e5533e135e  vmovaps [rsp+0xD0], xmm14
000078e5533e1367  vmovaps [rsp+0xE0], xmm15
000078e5533e1370  sub rsp, 0x30
000078e5533e1374  movaps [rsp], xmm7
000078e5533e1378  movaps [rsp+0x10], xmm9
000078e5533e137e  movaps [rsp+0x20], xmm15
000078e5533e1384  lea rdi, [rsp]
000078e5533e1388  mov esi, 0x00
000078e5533e138d  mov rax, 0x5F83D5E17530
000078e5533e1397  call rax
000078e5533e1399  movaps xmm7, [rsp]
000078e5533e139d  add rsp, 0x30
000078e5533e13a1  vmovaps xmm0, [rsp]
000078e5533e13a6  vmovaps xmm1, [rsp+0x10]
000078e5533e13ac  vmovaps xmm2, [rsp+0x20]
000078e5533e13b2  vmovaps xmm3, [rsp+0x30]
000078e5533e13b8  vmovaps xmm4, [rsp+0x40]
000078e5533e13be  vmovaps xmm5, [rsp+0x50]
000078e5533e13c4  vmovaps xmm6, [rsp+0x60]
000078e5533e13ca  vmovaps xmm8, [rsp+0x70]
000078e5533e13d0  vmovaps xmm9, [rsp+0x80]
000078e5533e13d9  vmovaps xmm10, [rsp+0x90]
000078e5533e13e2  vmovaps xmm11, [rsp+0xA0]
000078e5533e13eb  vmovaps xmm12, [rsp+0xB0]
000078e5533e13f4  vmovaps xmm13, [rsp+0xC0]
000078e5533e13fd  vmovaps xmm14, [rsp+0xD0]
000078e5533e1406  vmovaps xmm15, [rsp+0xE0]
000078e5533e140f  add rsp, 0xF0
000078e5533e1416  pop r11
000078e5533e1418  pop r10
000078e5533e141a  pop r9
000078e5533e141c  pop r8
000078e5533e141e  pop rsi
000078e5533e141f  pop rdi
000078e5533e1420  pop rdx
000078e5533e1421  pop rcx
000078e5533e1422  pop rax
000078e5533e1423  add rsp, 0x08
000078e5533e1427  jmp 0x000078E5533DC7B4
000078e5533e142c  sub rsp, 0x08
000078e5533e1430  push rax
000078e5533e1431  push rcx
000078e5533e1432  push rdx
000078e5533e1433  push rdi
000078e5533e1434  push rsi
000078e5533e1435  push r8
000078e5533e1437  push r9
000078e5533e1439  push r10
000078e5533e143b  push r11
000078e5533e143d  sub rsp, 0xF0
000078e5533e1444  vmovaps [rsp], xmm0
000078e5533e1449  vmovaps [rsp+0x10], xmm1
000078e5533e144f  vmovaps [rsp+0x20], xmm2
000078e5533e1455  vmovaps [rsp+0x30], xmm3
000078e5533e145b  vmovaps [rsp+0x40], xmm4
000078e5533e1461  vmovaps [rsp+0x50], xmm5
000078e5533e1467  vmovaps [rsp+0x60], xmm6
000078e5533e146d  vmovaps [rsp+0x70], xmm7
000078e5533e1473  vmovaps [rsp+0x80], xmm8
000078e5533e147c  vmovaps [rsp+0x90], xmm10
000078e5533e1485  vmovaps [rsp+0xA0], xmm11
000078e5533e148e  vmovaps [rsp+0xB0], xmm12
000078e5533e1497  vmovaps [rsp+0xC0], xmm13
000078e5533e14a0  vmovaps [rsp+0xD0], xmm14
000078e5533e14a9  vmovaps [rsp+0xE0], xmm15
000078e5533e14b2  sub rsp, 0x30
000078e5533e14b6  movaps [rsp], xmm9
000078e5533e14bb  movaps [rsp+0x10], xmm13
000078e5533e14c1  movaps [rsp+0x20], xmm15
000078e5533e14c7  lea rdi, [rsp]
000078e5533e14cb  mov esi, 0x00
000078e5533e14d0  mov rax, 0x5F83D5E17530
000078e5533e14da  call rax
000078e5533e14dc  movaps xmm9, [rsp]
000078e5533e14e1  add rsp, 0x30
000078e5533e14e5  vmovaps xmm0, [rsp]
000078e5533e14ea  vmovaps xmm1, [rsp+0x10]
000078e5533e14f0  vmovaps xmm2, [rsp+0x20]
000078e5533e14f6  vmovaps xmm3, [rsp+0x30]
000078e5533e14fc  vmovaps xmm4, [rsp+0x40]
000078e5533e1502  vmovaps xmm5, [rsp+0x50]
000078e5533e1508  vmovaps xmm6, [rsp+0x60]
000078e5533e150e  vmovaps xmm7, [rsp+0x70]
000078e5533e1514  vmovaps xmm8, [rsp+0x80]
000078e5533e151d  vmovaps xmm10, [rsp+0x90]
000078e5533e1526  vmovaps xmm11, [rsp+0xA0]
000078e5533e152f  vmovaps xmm12, [rsp+0xB0]
000078e5533e1538  vmovaps xmm13, [rsp+0xC0]
000078e5533e1541  vmovaps xmm14, [rsp+0xD0]
000078e5533e154a  vmovaps xmm15, [rsp+0xE0]
000078e5533e1553  add rsp, 0xF0
000078e5533e155a  pop r11
000078e5533e155c  pop r10
000078e5533e155e  pop r9
000078e5533e1560  pop r8
000078e5533e1562  pop rsi
000078e5533e1563  pop rdi
000078e5533e1564  pop rdx
000078e5533e1565  pop rcx
000078e5533e1566  pop rax
000078e5533e1567  add rsp, 0x08
000078e5533e156b  jmp 0x000078E5533DC7E2
000078e5533e1570  sub rsp, 0x08
000078e5533e1574  push rax
000078e5533e1575  push rcx
000078e5533e1576  push rdx
000078e5533e1577  push rdi
000078e5533e1578  push rsi
000078e5533e1579  push r8
000078e5533e157b  push r9
000078e5533e157d  push r10
000078e5533e157f  push r11
000078e5533e1581  sub rsp, 0xF0
000078e5533e1588  vmovaps [rsp], xmm0
000078e5533e158d  vmovaps [rsp+0x10], xmm1
000078e5533e1593  vmovaps [rsp+0x20], xmm2
000078e5533e1599  vmovaps [rsp+0x30], xmm3
000078e5533e159f  vmovaps [rsp+0x40], xmm4
000078e5533e15a5  vmovaps [rsp+0x50], xmm5
000078e5533e15ab  vmovaps [rsp+0x60], xmm6
000078e5533e15b1  vmovaps [rsp+0x70], xmm7
000078e5533e15b7  vmovaps [rsp+0x80], xmm8
000078e5533e15c0  vmovaps [rsp+0x90], xmm9
000078e5533e15c9  vmovaps [rsp+0xA0], xmm10
000078e5533e15d2  vmovaps [rsp+0xB0], xmm11
000078e5533e15db  vmovaps [rsp+0xC0], xmm12
000078e5533e15e4  vmovaps [rsp+0xD0], xmm13
000078e5533e15ed  vmovaps [rsp+0xE0], xmm14
000078e5533e15f6  sub rsp, 0x30
000078e5533e15fa  movaps [rsp], xmm15
000078e5533e15ff  movaps [rsp+0x10], xmm11
000078e5533e1605  movaps [rsp+0x20], xmm12
000078e5533e160b  lea rdi, [rsp]
000078e5533e160f  mov esi, 0x00
000078e5533e1614  mov rax, 0x5F83D5E17530
000078e5533e161e  call rax
000078e5533e1620  movaps xmm15, [rsp]
000078e5533e1625  add rsp, 0x30
000078e5533e1629  vmovaps xmm0, [rsp]
000078e5533e162e  vmovaps xmm1, [rsp+0x10]
000078e5533e1634  vmovaps xmm2, [rsp+0x20]
000078e5533e163a  vmovaps xmm3, [rsp+0x30]
000078e5533e1640  vmovaps xmm4, [rsp+0x40]
000078e5533e1646  vmovaps xmm5, [rsp+0x50]
000078e5533e164c  vmovaps xmm6, [rsp+0x60]
000078e5533e1652  vmovaps xmm7, [rsp+0x70]
000078e5533e1658  vmovaps xmm8, [rsp+0x80]
000078e5533e1661  vmovaps xmm9, [rsp+0x90]
000078e5533e166a  vmovaps xmm10, [rsp+0xA0]
000078e5533e1673  vmovaps xmm11, [rsp+0xB0]
000078e5533e167c  vmovaps xmm12, [rsp+0xC0]
000078e5533e1685  vmovaps xmm13, [rsp+0xD0]
000078e5533e168e  vmovaps xmm14, [rsp+0xE0]
000078e5533e1697  add rsp, 0xF0
000078e5533e169e  pop r11
000078e5533e16a0  pop r10
000078e5533e16a2  pop r9
000078e5533e16a4  pop r8
000078e5533e16a6  pop rsi
000078e5533e16a7  pop rdi
000078e5533e16a8  pop rdx
000078e5533e16a9  pop rcx
000078e5533e16aa  pop rax
000078e5533e16ab  add rsp, 0x08
000078e5533e16af  jmp 0x000078E5533DC7FD
000078e5533e16b4  sub rsp, 0x08
000078e5533e16b8  push rax
000078e5533e16b9  push rcx
000078e5533e16ba  push rdx
000078e5533e16bb  push rdi
000078e5533e16bc  push rsi
000078e5533e16bd  push r8
000078e5533e16bf  push r9
000078e5533e16c1  push r10
000078e5533e16c3  push r11
000078e5533e16c5  sub rsp, 0xF0
000078e5533e16cc  vmovaps [rsp], xmm0
000078e5533e16d1  vmovaps [rsp+0x10], xmm1
000078e5533e16d7  vmovaps [rsp+0x20], xmm2
000078e5533e16dd  vmovaps [rsp+0x30], xmm3
000078e5533e16e3  vmovaps [rsp+0x40], xmm4
000078e5533e16e9  vmovaps [rsp+0x50], xmm5
000078e5533e16ef  vmovaps [rsp+0x60], xmm6
000078e5533e16f5  vmovaps [rsp+0x70], xmm7
000078e5533e16fb  vmovaps [rsp+0x80], xmm8
000078e5533e1704  vmovaps [rsp+0x90], xmm9
000078e5533e170d  vmovaps [rsp+0xA0], xmm10
000078e5533e1716  vmovaps [rsp+0xB0], xmm11
000078e5533e171f  vmovaps [rsp+0xC0], xmm12
000078e5533e1728  vmovaps [rsp+0xD0], xmm14
000078e5533e1731  vmovaps [rsp+0xE0], xmm15
000078e5533e173a  sub rsp, 0x30
000078e5533e173e  movaps [rsp], xmm13
000078e5533e1743  movaps [rsp+0x10], xmm10
000078e5533e1749  movaps [rsp+0x20], xmm14
000078e5533e174f  lea rdi, [rsp]
000078e5533e1753  mov esi, 0x00
000078e5533e1758  mov rax, 0x5F83D5E17530
000078e5533e1762  call rax
000078e5533e1764  movaps xmm13, [rsp]
000078e5533e1769  add rsp, 0x30
000078e5533e176d  vmovaps xmm0, [rsp]
000078e5533e1772  vmovaps xmm1, [rsp+0x10]
000078e5533e1778  vmovaps xmm2, [rsp+0x20]
000078e5533e177e  vmovaps xmm3, [rsp+0x30]
000078e5533e1784  vmovaps xmm4, [rsp+0x40]
000078e5533e178a  vmovaps xmm5, [rsp+0x50]
000078e5533e1790  vmovaps xmm6, [rsp+0x60]
000078e5533e1796  vmovaps xmm7, [rsp+0x70]
000078e5533e179c  vmovaps xmm8, [rsp+0x80]
000078e5533e17a5  vmovaps xmm9, [rsp+0x90]
000078e5533e17ae  vmovaps xmm10, [rsp+0xA0]
000078e5533e17b7  vmovaps xmm11, [rsp+0xB0]
000078e5533e17c0  vmovaps xmm12, [rsp+0xC0]
000078e5533e17c9  vmovaps xmm14, [rsp+0xD0]
000078e5533e17d2  vmovaps xmm15, [rsp+0xE0]
000078e5533e17db  add rsp, 0xF0
000078e5533e17e2  pop r11
000078e5533e17e4  pop r10
000078e5533e17e6  pop r9
000078e5533e17e8  pop r8
000078e5533e17ea  pop rsi
000078e5533e17eb  pop rdi
000078e5533e17ec  pop rdx
000078e5533e17ed  pop rcx
000078e5533e17ee  pop rax
000078e5533e17ef  add rsp, 0x08
000078e5533e17f3  jmp 0x000078E5533DC820
000078e5533e17f8  sub rsp, 0x08
000078e5533e17fc  push rax
000078e5533e17fd  push rcx
000078e5533e17fe  push rdx
000078e5533e17ff  push rdi
000078e5533e1800  push rsi
000078e5533e1801  push r8
000078e5533e1803  push r9
000078e5533e1805  push r10
000078e5533e1807  push r11
000078e5533e1809  sub rsp, 0xF0
000078e5533e1810  vmovaps [rsp], xmm0
000078e5533e1815  vmovaps [rsp+0x10], xmm1
000078e5533e181b  vmovaps [rsp+0x20], xmm2
000078e5533e1821  vmovaps [rsp+0x30], xmm3
000078e5533e1827  vmovaps [rsp+0x40], xmm4
000078e5533e182d  vmovaps [rsp+0x50], xmm5
000078e5533e1833  vmovaps [rsp+0x60], xmm6
000078e5533e1839  vmovaps [rsp+0x70], xmm7
000078e5533e183f  vmovaps [rsp+0x80], xmm8
000078e5533e1848  vmovaps [rsp+0x90], xmm9
000078e5533e1851  vmovaps [rsp+0xA0], xmm10
000078e5533e185a  vmovaps [rsp+0xB0], xmm11
000078e5533e1863  vmovaps [rsp+0xC0], xmm12
000078e5533e186c  vmovaps [rsp+0xD0], xmm13
000078e5533e1875  vmovaps [rsp+0xE0], xmm15
000078e5533e187e  sub rsp, 0x30
000078e5533e1882  movaps [rsp], xmm14
000078e5533e1887  movaps [rsp+0x10], xmm1
000078e5533e188c  movaps [rsp+0x20], xmm7
000078e5533e1891  lea rdi, [rsp]
000078e5533e1895  mov esi, 0x00
000078e5533e189a  mov rax, 0x5F83D5E17530
000078e5533e18a4  call rax
000078e5533e18a6  movaps xmm14, [rsp]
000078e5533e18ab  add rsp, 0x30
000078e5533e18af  vmovaps xmm0, [rsp]
000078e5533e18b4  vmovaps xmm1, [rsp+0x10]
000078e5533e18ba  vmovaps xmm2, [rsp+0x20]
000078e5533e18c0  vmovaps xmm3, [rsp+0x30]
000078e5533e18c6  vmovaps xmm4, [rsp+0x40]
000078e5533e18cc  vmovaps xmm5, [rsp+0x50]
000078e5533e18d2  vmovaps xmm6, [rsp+0x60]
000078e5533e18d8  vmovaps xmm7, [rsp+0x70]
000078e5533e18de  vmovaps xmm8, [rsp+0x80]
000078e5533e18e7  vmovaps xmm9, [rsp+0x90]
000078e5533e18f0  vmovaps xmm10, [rsp+0xA0]
000078e5533e18f9  vmovaps xmm11, [rsp+0xB0]
000078e5533e1902  vmovaps xmm12, [rsp+0xC0]
000078e5533e190b  vmovaps xmm13, [rsp+0xD0]
000078e5533e1914  vmovaps xmm15, [rsp+0xE0]
000078e5533e191d  add rsp, 0xF0
000078e5533e1924  pop r11
000078e5533e1926  pop r10
000078e5533e1928  pop r9
000078e5533e192a  pop r8
000078e5533e192c  pop rsi
000078e5533e192d  pop rdi
000078e5533e192e  pop rdx
000078e5533e192f  pop rcx
000078e5533e1930  pop rax
000078e5533e1931  add rsp, 0x08
000078e5533e1935  jmp 0x000078E5533DC843
000078e5533e193a  sub rsp, 0x08
000078e5533e193e  push rax
000078e5533e193f  push rcx
000078e5533e1940  push rdx
000078e5533e1941  push rdi
000078e5533e1942  push rsi
000078e5533e1943  push r8
000078e5533e1945  push r9
000078e5533e1947  push r10
000078e5533e1949  push r11
000078e5533e194b  sub rsp, 0xF0
000078e5533e1952  vmovaps [rsp], xmm0
000078e5533e1957  vmovaps [rsp+0x10], xmm2
000078e5533e195d  vmovaps [rsp+0x20], xmm3
000078e5533e1963  vmovaps [rsp+0x30], xmm4
000078e5533e1969  vmovaps [rsp+0x40], xmm5
000078e5533e196f  vmovaps [rsp+0x50], xmm6
000078e5533e1975  vmovaps [rsp+0x60], xmm7
000078e5533e197b  vmovaps [rsp+0x70], xmm8
000078e5533e1981  vmovaps [rsp+0x80], xmm9
000078e5533e198a  vmovaps [rsp+0x90], xmm10
000078e5533e1993  vmovaps [rsp+0xA0], xmm11
000078e5533e199c  vmovaps [rsp+0xB0], xmm12
000078e5533e19a5  vmovaps [rsp+0xC0], xmm13
000078e5533e19ae  vmovaps [rsp+0xD0], xmm14
000078e5533e19b7  vmovaps [rsp+0xE0], xmm15
000078e5533e19c0  sub rsp, 0x30
000078e5533e19c4  movaps [rsp], xmm1
000078e5533e19c8  movaps [rsp+0x10], xmm8
000078e5533e19ce  movaps [rsp+0x20], xmm9
000078e5533e19d4  lea rdi, [rsp]
000078e5533e19d8  mov esi, 0x00
000078e5533e19dd  mov rax, 0x5F83D5E17530
000078e5533e19e7  call rax
000078e5533e19e9  movaps xmm1, [rsp]
000078e5533e19ed  add rsp, 0x30
000078e5533e19f1  vmovaps xmm0, [rsp]
000078e5533e19f6  vmovaps xmm2, [rsp+0x10]
000078e5533e19fc  vmovaps xmm3, [rsp+0x20]
000078e5533e1a02  vmovaps xmm4, [rsp+0x30]
000078e5533e1a08  vmovaps xmm5, [rsp+0x40]
000078e5533e1a0e  vmovaps xmm6, [rsp+0x50]
000078e5533e1a14  vmovaps xmm7, [rsp+0x60]
000078e5533e1a1a  vmovaps xmm8, [rsp+0x70]
000078e5533e1a20  vmovaps xmm9, [rsp+0x80]
000078e5533e1a29  vmovaps xmm10, [rsp+0x90]
000078e5533e1a32  vmovaps xmm11, [rsp+0xA0]
000078e5533e1a3b  vmovaps xmm12, [rsp+0xB0]
000078e5533e1a44  vmovaps xmm13, [rsp+0xC0]
000078e5533e1a4d  vmovaps xmm14, [rsp+0xD0]
000078e5533e1a56  vmovaps xmm15, [rsp+0xE0]
000078e5533e1a5f  add rsp, 0xF0
000078e5533e1a66  pop r11
000078e5533e1a68  pop r10
000078e5533e1a6a  pop r9
000078e5533e1a6c  pop r8
000078e5533e1a6e  pop rsi
000078e5533e1a6f  pop rdi
000078e5533e1a70  pop rdx
000078e5533e1a71  pop rcx
000078e5533e1a72  pop rax
000078e5533e1a73  add rsp, 0x08
000078e5533e1a77  jmp 0x000078E5533DC865
000078e5533e1a7c  call 0x000078E5532E5940
000078e5533e1a81  jmp 0x000078E5533DC873
000078e5533e1a86  call 0x000078E55320C380
000078e5533e1a8b  jmp 0x000078E5533DC87D
000078e5533e1a90  call 0x000078E55320D600
000078e5533e1a95  jmp 0x000078E5533DC887
000078e5533e1a9a  call 0x000078E5531FF540
000078e5533e1a9f  jmp 0x000078E5533DC891
000078e5533e1aa4  int3
000078e5533e1aa5  nop [rax+rax*1], ax
000078e5533e1aae  nop
000078e5533e1ab0  mov rax, [r15+0xF8]
000078e5533e1ab7  lea r14, [rax+0x140]
000078e5533e1abe  mov r12, [r13+r14*1]
000078e5533e1ac3  mov [r15+0xE8], r12
000078e5533e1aca  lea r14, [rax+0x130]
000078e5533e1ad1  mov r12, [r13+r14*1]
000078e5533e1ad6  lea r14, [rax+0x138]
000078e5533e1add  mov r11, [r13+r14*1]
000078e5533e1ae2  movq xmm1, r12
000078e5533e1ae7  movq xmm15, r11
000078e5533e1aec  movq xmm1, xmm1
000078e5533e1af0  movq xmm1, xmm1
000078e5533e1af4  movaps [r15+0x1A0], xmm1
000078e5533e1afc  movq xmm15, xmm15
000078e5533e1b01  movq xmm15, xmm15
000078e5533e1b06  movaps [r15+0x190], xmm15
000078e5533e1b0e  lea r14, [rax+0x120]
000078e5533e1b15  mov r12, [r13+r14*1]
000078e5533e1b1a  lea r14, [rax+0x128]
000078e5533e1b21  mov r11, [r13+r14*1]
000078e5533e1b26  movq xmm1, r12
000078e5533e1b2b  movq xmm15, r11
000078e5533e1b30  movq xmm1, xmm1
000078e5533e1b34  movq xmm1, xmm1
000078e5533e1b38  movaps [r15+0x1C0], xmm1
000078e5533e1b40  movq xmm15, xmm15
000078e5533e1b45  movq xmm15, xmm15
000078e5533e1b4a  movaps [r15+0x1B0], xmm15
000078e5533e1b52  lea r14, [rax+0x110]
000078e5533e1b59  mov r12, [r13+r14*1]
000078e5533e1b5e  lea r14, [rax+0x118]
000078e5533e1b65  mov r11, [r13+r14*1]
000078e5533e1b6a  movq xmm1, r12
000078e5533e1b6f  movq xmm15, r11
000078e5533e1b74  movq xmm1, xmm1
000078e5533e1b78  movq xmm1, xmm1
000078e5533e1b7c  movaps [r15+0x1E0], xmm1
000078e5533e1b84  movq xmm15, xmm15
000078e5533e1b89  movq xmm15, xmm15
000078e5533e1b8e  movaps [r15+0x1D0], xmm15
000078e5533e1b96  lea r14, [rax+0x100]
000078e5533e1b9d  mov r12, [r13+r14*1]
000078e5533e1ba2  lea r14, [rax+0x108]
000078e5533e1ba9  mov r11, [r13+r14*1]
000078e5533e1bae  movq xmm1, r12
000078e5533e1bb3  movq xmm15, r11
000078e5533e1bb8  movq xmm1, xmm1
000078e5533e1bbc  movq xmm1, xmm1
000078e5533e1bc0  movaps [r15+0x200], xmm1
000078e5533e1bc8  movq xmm15, xmm15
000078e5533e1bcd  movq xmm15, xmm15
000078e5533e1bd2  movaps [r15+0x1F0], xmm15
000078e5533e1bda  mov qword ptr [r15+0x40], 0x430000
000078e5533e1be2  mov r14d, 0x430510
000078e5533e1be8  mov r12, [r13+r14*1]
000078e5533e1bed  movq xmm1, r12
000078e5533e1bf2  lea r14, [rax+0x150]
000078e5533e1bf9  mov [r15+0xF8], r14
000078e5533e1c00  mov rax, [r15+0x50]
000078e5533e1c04  movups xmm15, [r13+rax*1]
000078e5533e1c0a  movaps [r15+0x120], xmm15
000078e5533e1c12  mov qword ptr [r15+0x48], 0x10
000078e5533e1c1a  xor eax, eax
000078e5533e1c1c  mov r14d, 0x10
000078e5533e1c22  mov r12d, 0x200
000078e5533e1c28  cmp r14, r12
000078e5533e1c2b  cmc
000078e5533e1c2c  lahf
000078e5533e1c2d  seto al
000078e5533e1c30  mov [r15+0x108], eax
000078e5533e1c37  pextrq rax, xmm15, 0x01
000078e5533e1c3e  movq xmm14, rax
000078e5533e1c43  movaps [r15+0x130], xmm14
000078e5533e1c4b  movq rax, xmm1
000078e5533e1c50  movq r14, xmm15
000078e5533e1c55  vmovq xmm1, rax
000078e5533e1c5a  vmovq xmm15, r14
000078e5533e1c5f  movaps xmm13, xmm1
000078e5533e1c63  addsd xmm13, xmm15
000078e5533e1c68  ucomisd xmm13, xmm13
000078e5533e1c6d  jp 0x000078E5533E1D86
000078e5533e1c73  movq xmm13, xmm13
000078e5533e1c78  movq rax, xmm13
000078e5533e1c7d  movq r14, xmm14
000078e5533e1c82  vmovq xmm1, rax
000078e5533e1c87  vmovq xmm15, r14
000078e5533e1c8c  movaps xmm14, xmm1
000078e5533e1c90  addsd xmm14, xmm15
000078e5533e1c95  ucomisd xmm14, xmm14
000078e5533e1c9a  jp 0x000078E5533E1DCE
000078e5533e1ca0  movq xmm14, xmm14
000078e5533e1ca5  movaps [r15+0x110], xmm14
000078e5533e1cad  mov eax, [r15+0x108]
000078e5533e1cb4  sahf
000078e5533e1cb5  jnz 0x000078E5533E1CE7
000078e5533e1cb7  cmp dword ptr [r15+0x318], 0x00
000078e5533e1cbf  jz 0x000078E5533E1FE0
000078e5533e1cc5  nop [rax+rax*1], ax
000078e5533e1cce  nop [rax+rax*1], eax
000078e5533e1cd6  mov eax, 0x410490
000078e5533e1cdb  mov [r15+0x100], rax
000078e5533e1ce2  jmp 0x000078E5531FE110
000078e5533e1ce7  cmp dword ptr [r15+0x318], 0x00
000078e5533e1cef  jz 0x000078E5533E1E20
000078e5533e1cf5  nop [rax+rax*1], ax
000078e5533e1cfe  nop [rax+rax*1], eax
000078e5533e1d06  mov eax, 0x410474
000078e5533e1d0b  mov [r15+0x100], rax
000078e5533e1d12  jmp 0x000078E5531FE110
000078e5533e1d17  int3
000078e5533e1d18  call 0x000078E5532E27E0
000078e5533e1d1d  jmp 0x000078E5533E1AC3
000078e5533e1d22  call 0x000078E5532E27E0
000078e5533e1d27  jmp 0x000078E5533E1AD6
000078e5533e1d2c  call 0x000078E5532E1570
000078e5533e1d31  jmp 0x000078E5533E1AE2
000078e5533e1d36  call 0x000078E5532E27E0
000078e5533e1d3b  jmp 0x000078E5533E1B1A
000078e5533e1d40  call 0x000078E5532E1570
000078e5533e1d45  jmp 0x000078E5533E1B26
000078e5533e1d4a  call 0x000078E5532E27E0
000078e5533e1d4f  jmp 0x000078E5533E1B5E
000078e5533e1d54  call 0x000078E5532E1570
000078e5533e1d59  jmp 0x000078E5533E1B6A
000078e5533e1d5e  call 0x000078E5532E27E0
000078e5533e1d63  jmp 0x000078E5533E1BA2
000078e5533e1d68  call 0x000078E5532E1570
000078e5533e1d6d  jmp 0x000078E5533E1BAE
000078e5533e1d72  call 0x000078E5532E27E0
000078e5533e1d77  jmp 0x000078E5533E1BED
000078e5533e1d7c  call 0x000078E55320E760
000078e5533e1d81  jmp 0x000078E5533E1C0A
000078e5533e1d86  ucomisd xmm1, xmm15
000078e5533e1d8b  jp 0x000078E5533E1D9A
000078e5533e1d8d  movaps xmm13, [0x000078E552FFE060]
000078e5533e1d95  jmp 0x000078E5533E1C73
000078e5533e1d9a  vxorps xmm0, xmm1, xmm15
000078e5533e1d9f  pextrw eax, xmm0, 0x03
000078e5533e1da4  and eax, 0x7FF8
000078e5533e1da9  cmp eax, 0x08
000078e5533e1dac  jnz 0x000078E5533E1C73
000078e5533e1db2  movq rax, xmm15
000078e5533e1db7  shl rax, 0x0D
000078e5533e1dbb  jbe 0x000078E5533E1C73
000078e5533e1dc1  vorps xmm13, xmm15, [0x000078E552FFE070]
000078e5533e1dc9  jmp 0x000078E5533E1C73
000078e5533e1dce  ucomisd xmm1, xmm15
000078e5533e1dd3  jp 0x000078E5533E1DE2
000078e5533e1dd5  movaps xmm14, [0x000078E552FFE060]
000078e5533e1ddd  jmp 0x000078E5533E1CA0
000078e5533e1de2  vxorps xmm0, xmm1, xmm15
000078e5533e1de7  pextrw eax, xmm0, 0x03
000078e5533e1dec  and eax, 0x7FF8
000078e5533e1df1  cmp eax, 0x08
000078e5533e1df4  jnz 0x000078E5533E1CA0
000078e5533e1dfa  movq rax, xmm15
000078e5533e1dff  shl rax, 0x0D
000078e5533e1e03  jbe 0x000078E5533E1CA0
000078e5533e1e09  vorps xmm14, xmm15, [0x000078E552FFE070]
000078e5533e1e11  jmp 0x000078E5533E1CA0
000078e5533e1e16  int3
000078e5533e1e17  nop [rax+rax*1], ax
000078e5533e1e20  mov rax, [r15+0x48]
000078e5533e1e24  mov r14, [r15+0x50]
000078e5533e1e28  lea r12, [r14+rax*1]
000078e5533e1e2c  movups xmm1, [r13+r12*1]
000078e5533e1e32  movaps [r15+0x120], xmm1
000078e5533e1e3a  lea r14, [rax+0x10]
000078e5533e1e3e  mov [r15+0x48], r14
000078e5533e1e42  xor eax, eax
000078e5533e1e44  mov r12d, 0x200
000078e5533e1e4a  cmp r14, r12
000078e5533e1e4d  cmc
000078e5533e1e4e  lahf
000078e5533e1e4f  seto al
000078e5533e1e52  mov [r15+0x108], eax
000078e5533e1e59  pextrq rax, xmm1, 0x01
000078e5533e1e60  movq xmm15, rax
000078e5533e1e65  movaps [r15+0x130], xmm15
000078e5533e1e6d  movaps xmm14, [r15+0x110]
000078e5533e1e75  movq rax, xmm14
000078e5533e1e7a  movq r14, xmm1
000078e5533e1e7f  vmovq xmm1, rax
000078e5533e1e84  vmovq xmm14, r14
000078e5533e1e89  movaps xmm13, xmm1
000078e5533e1e8d  addsd xmm13, xmm14
000078e5533e1e92  ucomisd xmm13, xmm13
000078e5533e1e97  jp 0x000078E5533E1F4C
000078e5533e1e9d  movq xmm13, xmm13
000078e5533e1ea2  movq rax, xmm13
000078e5533e1ea7  movq r14, xmm15
000078e5533e1eac  vmovq xmm1, rax
000078e5533e1eb1  vmovq xmm15, r14
000078e5533e1eb6  movaps xmm14, xmm1
000078e5533e1eba  addsd xmm14, xmm15
000078e5533e1ebf  ucomisd xmm14, xmm14
000078e5533e1ec4  jp 0x000078E5533E1F94
000078e5533e1eca  movq xmm14, xmm14
000078e5533e1ecf  movaps [r15+0x110], xmm14
000078e5533e1ed7  mov eax, [r15+0x108]
000078e5533e1ede  sahf
000078e5533e1edf  jnz 0x000078E5533E1F11
000078e5533e1ee1  cmp dword ptr [r15+0x318], 0x00
000078e5533e1ee9  jz 0x000078E5533E1FE0
000078e5533e1eef  nop [rax+rax*1], ax
000078e5533e1ef8  nop [rax+rax*1], eax
000078e5533e1f00  mov eax, 0x410490
000078e5533e1f05  mov [r15+0x100], rax
000078e5533e1f0c  jmp 0x000078E5531FE110
000078e5533e1f11  cmp dword ptr [r15+0x318], 0x00
000078e5533e1f19  jz 0x000078E5533E1E20
000078e5533e1f1f  nop [rax+rax*1], ax
000078e5533e1f28  nop [rax+rax*1], eax
000078e5533e1f30  mov eax, 0x410474
000078e5533e1f35  mov [r15+0x100], rax
000078e5533e1f3c  jmp 0x000078E5531FE110
000078e5533e1f41  int3
000078e5533e1f42  call 0x000078E5532B52F0
000078e5533e1f47  jmp 0x000078E5533E1E32
000078e5533e1f4c  ucomisd xmm1, xmm14
000078e5533e1f51  jp 0x000078E5533E1F60
000078e5533e1f53  movaps xmm13, [0x000078E552FFE060]
000078e5533e1f5b  jmp 0x000078E5533E1E9D
000078e5533e1f60  vxorps xmm0, xmm1, xmm14
000078e5533e1f65  pextrw eax, xmm0, 0x03
000078e5533e1f6a  and eax, 0x7FF8
000078e5533e1f6f  cmp eax, 0x08
000078e5533e1f72  jnz 0x000078E5533E1E9D
000078e5533e1f78  movq rax, xmm14
000078e5533e1f7d  shl rax, 0x0D
000078e5533e1f81  jbe 0x000078E5533E1E9D
000078e5533e1f87  vorps xmm13, xmm14, [0x000078E552FFE070]
000078e5533e1f8f  jmp 0x000078E5533E1E9D
000078e5533e1f94  ucomisd xmm1, xmm15
000078e5533e1f99  jp 0x000078E5533E1FA8
000078e5533e1f9b  movaps xmm14, [0x000078E552FFE060]
000078e5533e1fa3  jmp 0x000078E5533E1ECA
000078e5533e1fa8  vxorps xmm0, xmm1, xmm15
000078e5533e1fad  pextrw eax, xmm0, 0x03
000078e5533e1fb2  and eax, 0x7FF8
000078e5533e1fb7  cmp eax, 0x08
000078e5533e1fba  jnz 0x000078E5533E1ECA
000078e5533e1fc0  movq rax, xmm15
000078e5533e1fc5  shl rax, 0x0D
000078e5533e1fc9  jbe 0x000078E5533E1ECA
000078e5533e1fcf  vorps xmm14, xmm15, [0x000078E552FFE070]
000078e5533e1fd7  jmp 0x000078E5533E1ECA
000078e5533e1fdc  int3
000078e5533e1fdd  nop [rax], eax
000078e5533e1fe0  mov rax, [r15+0x40]
000078e5533e1fe4  lea r14, [rax+0x510]
000078e5533e1feb  movaps xmm1, [r15+0x110]
000078e5533e1ff3  movq rax, xmm1
000078e5533e1ff8  mov [r13+r14*1], rax
000078e5533e1ffd  mov rax, [r15+0xF0]
000078e5533e2004  mov [r15+0x100], rax
000078e5533e200b  jmp 0x000078E5533CE5C0
000078e5533e2010  int3
000078e5533e2011  call 0x000078E5532D5EB0
000078e5533e2016  jmp 0x000078E5533E1FFD
000078e5533e201b  int3
000078e5533e201c  nop [rax], eax
000078e5533e2020  mov qword ptr [r15+0x100], 0x04
000078e5533e202b  mov esi, 0x00
000078e5533e2030  mov edx, 0x09
000078e5533e2035  mov rdi, 0x7FFD30F00B40
000078e5533e203f  mov rax, 0x5F83D5CAA970
000078e5533e2049  call rax
000078e5533e204b  cmp dword ptr [r15+0x318], 0x00
000078e5533e2053  jnz 0x000078E5531FE110
000078e5533e2059  jmp 0x000078E5531FE0A0
000078e5533e205e  int3
000078e5533e205f  int3
