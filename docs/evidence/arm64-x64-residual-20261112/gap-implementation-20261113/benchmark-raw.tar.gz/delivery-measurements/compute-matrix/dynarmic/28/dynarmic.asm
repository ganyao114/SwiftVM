00007e4af17ce69b  nop [rax+rax*1], eax
00007e4af17ce6a0  vmovaps xmm1, [0x00007E4AF13FE010]
00007e4af17ce6a8  movq xmm1, xmm1
00007e4af17ce6ac  movaps [r15+0x110], xmm1
00007e4af17ce6b4  vmovaps xmm1, [0x00007E4AF13FE020]
00007e4af17ce6bc  movq xmm1, xmm1
00007e4af17ce6c0  movaps [r15+0x120], xmm1
00007e4af17ce6c8  mov eax, 0x4204C0
00007e4af17ce6cd  mov r14, [r13+rax*1]
00007e4af17ce6d2  movq xmm1, r14
00007e4af17ce6d7  movaps [r15+0x130], xmm1
00007e4af17ce6df  vmovaps xmm1, [0x00007E4AF13FE030]
00007e4af17ce6e7  vpbroadcastq xmm1, xmm1
00007e4af17ce6ec  movaps [r15+0x140], xmm1
00007e4af17ce6f4  mov qword ptr [r15+0x40], 0x02
00007e4af17ce6fc  vmovaps xmm15, [0x00007E4AF13FE040]
00007e4af17ce704  movq xmm15, xmm15
00007e4af17ce709  movaps [r15+0x150], xmm15
00007e4af17ce711  mov qword ptr [r15+0x58], 0x420000
00007e4af17ce719  vmovaps xmm15, [0x00007E4AF13FE050]
00007e4af17ce721  vpbroadcastq xmm15, xmm15
00007e4af17ce726  movaps [r15+0x160], xmm15
00007e4af17ce72e  mov rax, [r15+0x40]
00007e4af17ce732  vmovq xmm14, rax
00007e4af17ce737  vpbroadcastq xmm14, xmm14
00007e4af17ce73c  movaps [r15+0x170], xmm14
00007e4af17ce744  mov eax, 0x4204D0
00007e4af17ce749  movups xmm13, [r13+rax*1]
00007e4af17ce74f  mov qword ptr [r15+0x40], 0x430518
00007e4af17ce757  mov qword ptr [r15+0x50], 0x430720
00007e4af17ce75f  vpmovqd xmm12, xmm13
00007e4af17ce765  pxor xmm11, xmm11
00007e4af17ce76a  punpcklqdq xmm12, xmm11
00007e4af17ce76f  movaps [r15+0x210], xmm12
00007e4af17ce777  movq xmm12, qword ptr [r15+0x120]
00007e4af17ce780  movq xmm11, qword ptr [r15+0x130]
00007e4af17ce789  psubd xmm12, xmm11
00007e4af17ce78e  movq xmm12, xmm12
00007e4af17ce793  paddq xmm13, xmm14
00007e4af17ce798  movaps [r15+0x180], xmm13
00007e4af17ce7a0  movq xmm14, qword ptr [r15+0x150]
00007e4af17ce7a9  paddd xmm11, xmm14
00007e4af17ce7ae  movq xmm11, xmm11
00007e4af17ce7b3  movq xmm11, xmm11
00007e4af17ce7b8  movaps [r15+0x130], xmm11
00007e4af17ce7c0  pmovzxdq xmm12, xmm12
00007e4af17ce7c6  psllq xmm12, 0x00
00007e4af17ce7cc  movq xmm14, qword ptr [r15+0x210]
00007e4af17ce7d5  movq xmm13, qword ptr [r15+0x110]
00007e4af17ce7de  paddd xmm14, xmm13
00007e4af17ce7e3  movq xmm14, xmm14
00007e4af17ce7e8  vcvtuqq2pd xmm12, xmm12
00007e4af17ce7ee  pmovzxdq xmm14, xmm14
00007e4af17ce7f4  psllq xmm14, 0x00
00007e4af17ce7fa  vcvtuqq2pd xmm14, xmm14
00007e4af17ce800  movaps xmm13, xmm12
00007e4af17ce804  mulpd xmm13, xmm1
00007e4af17ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007e4af17ce80f  ptest xmm11, xmm11
00007e4af17ce815  jnz 0x00007E4AF17CE8FF
00007e4af17ce81b  movaps [r15+0x220], xmm13
00007e4af17ce823  mov eax, 0x430720
00007e4af17ce828  movups [r13+rax*1], xmm13
00007e4af17ce82e  movaps xmm1, xmm14
00007e4af17ce832  mulpd xmm1, xmm15
00007e4af17ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007e4af17ce83c  ptest xmm13, xmm13
00007e4af17ce842  jnz 0x00007E4AF17CEA4C
00007e4af17ce848  movaps [r15+0x210], xmm1
00007e4af17ce850  mov eax, 0x430518
00007e4af17ce855  movups [r13+rax*1], xmm1
00007e4af17ce85b  mov qword ptr [r15+0x48], 0x10
00007e4af17ce863  xor eax, eax
00007e4af17ce865  mov r14d, 0x10
00007e4af17ce86b  mov r12d, 0x200
00007e4af17ce871  cmp r14, r12
00007e4af17ce874  cmc
00007e4af17ce875  lahf
00007e4af17ce876  seto al
00007e4af17ce879  mov [r15+0x108], eax
00007e4af17ce880  mov eax, [r15+0x108]
00007e4af17ce887  sahf
00007e4af17ce888  jnz 0x00007E4AF17CE8BA
00007e4af17ce88a  cmp dword ptr [r15+0x318], 0x00
00007e4af17ce892  jz 0x00007E4AF17CEFF0
00007e4af17ce898  nop [rax+rax*1], ax
00007e4af17ce8a1  nop [rax+rax*1], eax
00007e4af17ce8a9  mov eax, 0x4101EC
00007e4af17ce8ae  mov [r15+0x100], rax
00007e4af17ce8b5  jmp 0x00007E4AF15FE110
00007e4af17ce8ba  cmp dword ptr [r15+0x318], 0x00
00007e4af17ce8c2  jz 0x00007E4AF17CEBA0
00007e4af17ce8c8  nop [rax+rax*1], ax
00007e4af17ce8d1  nop [rax+rax*1], eax
00007e4af17ce8d9  mov eax, 0x4101AC
00007e4af17ce8de  mov [r15+0x100], rax
00007e4af17ce8e5  jmp 0x00007E4AF15FE110
00007e4af17ce8ea  int3
00007e4af17ce8eb  call 0x00007E4AF160DC20
00007e4af17ce8f0  jmp 0x00007E4AF17CE6D2
00007e4af17ce8f5  call 0x00007E4AF160C260
00007e4af17ce8fa  jmp 0x00007E4AF17CE74F
00007e4af17ce8ff  sub rsp, 0x08
00007e4af17ce903  push rax
00007e4af17ce904  push rcx
00007e4af17ce905  push rdx
00007e4af17ce906  push rdi
00007e4af17ce907  push rsi
00007e4af17ce908  push r8
00007e4af17ce90a  push r9
00007e4af17ce90c  push r10
00007e4af17ce90e  push r11
00007e4af17ce910  sub rsp, 0xF0
00007e4af17ce917  vmovaps [rsp], xmm0
00007e4af17ce91c  vmovaps [rsp+0x10], xmm1
00007e4af17ce922  vmovaps [rsp+0x20], xmm2
00007e4af17ce928  vmovaps [rsp+0x30], xmm3
00007e4af17ce92e  vmovaps [rsp+0x40], xmm4
00007e4af17ce934  vmovaps [rsp+0x50], xmm5
00007e4af17ce93a  vmovaps [rsp+0x60], xmm6
00007e4af17ce940  vmovaps [rsp+0x70], xmm7
00007e4af17ce946  vmovaps [rsp+0x80], xmm8
00007e4af17ce94f  vmovaps [rsp+0x90], xmm9
00007e4af17ce958  vmovaps [rsp+0xA0], xmm10
00007e4af17ce961  vmovaps [rsp+0xB0], xmm11
00007e4af17ce96a  vmovaps [rsp+0xC0], xmm12
00007e4af17ce973  vmovaps [rsp+0xD0], xmm14
00007e4af17ce97c  vmovaps [rsp+0xE0], xmm15
00007e4af17ce985  sub rsp, 0x30
00007e4af17ce989  movaps [rsp], xmm13
00007e4af17ce98e  movaps [rsp+0x10], xmm12
00007e4af17ce994  movaps [rsp+0x20], xmm1
00007e4af17ce999  lea rdi, [rsp]
00007e4af17ce99d  mov esi, 0x00
00007e4af17ce9a2  mov rax, 0x6256754A7530
00007e4af17ce9ac  call rax
00007e4af17ce9ae  movaps xmm13, [rsp]
00007e4af17ce9b3  add rsp, 0x30
00007e4af17ce9b7  vmovaps xmm0, [rsp]
00007e4af17ce9bc  vmovaps xmm1, [rsp+0x10]
00007e4af17ce9c2  vmovaps xmm2, [rsp+0x20]
00007e4af17ce9c8  vmovaps xmm3, [rsp+0x30]
00007e4af17ce9ce  vmovaps xmm4, [rsp+0x40]
00007e4af17ce9d4  vmovaps xmm5, [rsp+0x50]
00007e4af17ce9da  vmovaps xmm6, [rsp+0x60]
00007e4af17ce9e0  vmovaps xmm7, [rsp+0x70]
00007e4af17ce9e6  vmovaps xmm8, [rsp+0x80]
00007e4af17ce9ef  vmovaps xmm9, [rsp+0x90]
00007e4af17ce9f8  vmovaps xmm10, [rsp+0xA0]
00007e4af17cea01  vmovaps xmm11, [rsp+0xB0]
00007e4af17cea0a  vmovaps xmm12, [rsp+0xC0]
00007e4af17cea13  vmovaps xmm14, [rsp+0xD0]
00007e4af17cea1c  vmovaps xmm15, [rsp+0xE0]
00007e4af17cea25  add rsp, 0xF0
00007e4af17cea2c  pop r11
00007e4af17cea2e  pop r10
00007e4af17cea30  pop r9
00007e4af17cea32  pop r8
00007e4af17cea34  pop rsi
00007e4af17cea35  pop rdi
00007e4af17cea36  pop rdx
00007e4af17cea37  pop rcx
00007e4af17cea38  pop rax
00007e4af17cea39  add rsp, 0x08
00007e4af17cea3d  jmp 0x00007E4AF17CE81B
00007e4af17cea42  call 0x00007E4AF160C380
00007e4af17cea47  jmp 0x00007E4AF17CE82E
00007e4af17cea4c  sub rsp, 0x08
00007e4af17cea50  push rax
00007e4af17cea51  push rcx
00007e4af17cea52  push rdx
00007e4af17cea53  push rdi
00007e4af17cea54  push rsi
00007e4af17cea55  push r8
00007e4af17cea57  push r9
00007e4af17cea59  push r10
00007e4af17cea5b  push r11
00007e4af17cea5d  sub rsp, 0xF0
00007e4af17cea64  vmovaps [rsp], xmm0
00007e4af17cea69  vmovaps [rsp+0x10], xmm2
00007e4af17cea6f  vmovaps [rsp+0x20], xmm3
00007e4af17cea75  vmovaps [rsp+0x30], xmm4
00007e4af17cea7b  vmovaps [rsp+0x40], xmm5
00007e4af17cea81  vmovaps [rsp+0x50], xmm6
00007e4af17cea87  vmovaps [rsp+0x60], xmm7
00007e4af17cea8d  vmovaps [rsp+0x70], xmm8
00007e4af17cea93  vmovaps [rsp+0x80], xmm9
00007e4af17cea9c  vmovaps [rsp+0x90], xmm10
00007e4af17ceaa5  vmovaps [rsp+0xA0], xmm11
00007e4af17ceaae  vmovaps [rsp+0xB0], xmm12
00007e4af17ceab7  vmovaps [rsp+0xC0], xmm13
00007e4af17ceac0  vmovaps [rsp+0xD0], xmm14
00007e4af17ceac9  vmovaps [rsp+0xE0], xmm15
00007e4af17cead2  sub rsp, 0x30
00007e4af17cead6  movaps [rsp], xmm1
00007e4af17ceada  movaps [rsp+0x10], xmm14
00007e4af17ceae0  movaps [rsp+0x20], xmm15
00007e4af17ceae6  lea rdi, [rsp]
00007e4af17ceaea  mov esi, 0x00
00007e4af17ceaef  mov rax, 0x6256754A7530
00007e4af17ceaf9  call rax
00007e4af17ceafb  movaps xmm1, [rsp]
00007e4af17ceaff  add rsp, 0x30
00007e4af17ceb03  vmovaps xmm0, [rsp]
00007e4af17ceb08  vmovaps xmm2, [rsp+0x10]
00007e4af17ceb0e  vmovaps xmm3, [rsp+0x20]
00007e4af17ceb14  vmovaps xmm4, [rsp+0x30]
00007e4af17ceb1a  vmovaps xmm5, [rsp+0x40]
00007e4af17ceb20  vmovaps xmm6, [rsp+0x50]
00007e4af17ceb26  vmovaps xmm7, [rsp+0x60]
00007e4af17ceb2c  vmovaps xmm8, [rsp+0x70]
00007e4af17ceb32  vmovaps xmm9, [rsp+0x80]
00007e4af17ceb3b  vmovaps xmm10, [rsp+0x90]
00007e4af17ceb44  vmovaps xmm11, [rsp+0xA0]
00007e4af17ceb4d  vmovaps xmm12, [rsp+0xB0]
00007e4af17ceb56  vmovaps xmm13, [rsp+0xC0]
00007e4af17ceb5f  vmovaps xmm14, [rsp+0xD0]
00007e4af17ceb68  vmovaps xmm15, [rsp+0xE0]
00007e4af17ceb71  add rsp, 0xF0
00007e4af17ceb78  pop r11
00007e4af17ceb7a  pop r10
00007e4af17ceb7c  pop r9
00007e4af17ceb7e  pop r8
00007e4af17ceb80  pop rsi
00007e4af17ceb81  pop rdi
00007e4af17ceb82  pop rdx
00007e4af17ceb83  pop rcx
00007e4af17ceb84  pop rax
00007e4af17ceb85  add rsp, 0x08
00007e4af17ceb89  jmp 0x00007E4AF17CE848
00007e4af17ceb8e  call 0x00007E4AF15FF540
00007e4af17ceb93  jmp 0x00007E4AF17CE85B
00007e4af17ceb98  int3
00007e4af17ceb99  nop [rax], eax
00007e4af17ceba0  movaps xmm1, [r15+0x180]
00007e4af17ceba8  vpmovqd xmm15, xmm1
00007e4af17cebae  pxor xmm14, xmm14
00007e4af17cebb3  punpcklqdq xmm15, xmm14
00007e4af17cebb8  movaps [r15+0x210], xmm15
00007e4af17cebc0  movq xmm15, qword ptr [r15+0x120]
00007e4af17cebc9  movq xmm14, qword ptr [r15+0x130]
00007e4af17cebd2  psubd xmm15, xmm14
00007e4af17cebd7  movq xmm15, xmm15
00007e4af17cebdc  movaps xmm13, [r15+0x170]
00007e4af17cebe4  paddq xmm1, xmm13
00007e4af17cebe9  movaps [r15+0x180], xmm1
00007e4af17cebf1  movq xmm1, qword ptr [r15+0x150]
00007e4af17cebfa  paddd xmm14, xmm1
00007e4af17cebff  movq xmm14, xmm14
00007e4af17cec04  movq xmm14, xmm14
00007e4af17cec09  movaps [r15+0x130], xmm14
00007e4af17cec11  pmovzxdq xmm15, xmm15
00007e4af17cec17  psllq xmm15, 0x00
00007e4af17cec1d  movq xmm1, qword ptr [r15+0x210]
00007e4af17cec26  movq xmm14, qword ptr [r15+0x110]
00007e4af17cec2f  paddd xmm1, xmm14
00007e4af17cec34  movq xmm1, xmm1
00007e4af17cec38  vcvtuqq2pd xmm15, xmm15
00007e4af17cec3e  pmovzxdq xmm1, xmm1
00007e4af17cec43  psllq xmm1, 0x00
00007e4af17cec48  vcvtuqq2pd xmm1, xmm1
00007e4af17cec4e  movaps xmm14, [r15+0x140]
00007e4af17cec56  movaps xmm13, xmm15
00007e4af17cec5a  mulpd xmm13, xmm14
00007e4af17cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007e4af17cec65  ptest xmm12, xmm12
00007e4af17cec6b  jnz 0x00007E4AF17CED4E
00007e4af17cec71  movaps [r15+0x220], xmm13
00007e4af17cec79  mov rax, [r15+0x48]
00007e4af17cec7d  mov r14, [r15+0x50]
00007e4af17cec81  lea r12, [r14+rax*1]
00007e4af17cec85  movups [r13+r12*1], xmm13
00007e4af17cec8b  movaps xmm15, [r15+0x160]
00007e4af17cec93  movaps xmm14, xmm1
00007e4af17cec97  mulpd xmm14, xmm15
00007e4af17cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007e4af17ceca2  ptest xmm13, xmm13
00007e4af17ceca8  jnz 0x00007E4AF17CEE9C
00007e4af17cecae  movaps [r15+0x210], xmm14
00007e4af17cecb6  mov r14, [r15+0x40]
00007e4af17cecba  lea r12, [r14+rax*1]
00007e4af17cecbe  movups [r13+r12*1], xmm14
00007e4af17cecc4  lea r14, [rax+0x10]
00007e4af17cecc8  mov [r15+0x48], r14
00007e4af17ceccc  xor eax, eax
00007e4af17cecce  mov r12d, 0x200
00007e4af17cecd4  cmp r14, r12
00007e4af17cecd7  cmc
00007e4af17cecd8  lahf
00007e4af17cecd9  seto al
00007e4af17cecdc  mov [r15+0x108], eax
00007e4af17cece3  mov eax, [r15+0x108]
00007e4af17cecea  sahf
00007e4af17ceceb  jnz 0x00007E4AF17CED1D
00007e4af17ceced  cmp dword ptr [r15+0x318], 0x00
00007e4af17cecf5  jz 0x00007E4AF17CEFF0
00007e4af17cecfb  nop [rax+rax*1], ax
00007e4af17ced04  nop [rax+rax*1], eax
00007e4af17ced0c  mov eax, 0x4101EC
00007e4af17ced11  mov [r15+0x100], rax
00007e4af17ced18  jmp 0x00007E4AF15FE110
00007e4af17ced1d  cmp dword ptr [r15+0x318], 0x00
00007e4af17ced25  jz 0x00007E4AF17CEBA0
00007e4af17ced2b  nop [rax+rax*1], ax
00007e4af17ced34  nop [rax+rax*1], eax
00007e4af17ced3c  mov eax, 0x4101AC
00007e4af17ced41  mov [r15+0x100], rax
00007e4af17ced48  jmp 0x00007E4AF15FE110
00007e4af17ced4d  int3
00007e4af17ced4e  sub rsp, 0x08
00007e4af17ced52  push rax
00007e4af17ced53  push rcx
00007e4af17ced54  push rdx
00007e4af17ced55  push rdi
00007e4af17ced56  push rsi
00007e4af17ced57  push r8
00007e4af17ced59  push r9
00007e4af17ced5b  push r10
00007e4af17ced5d  push r11
00007e4af17ced5f  sub rsp, 0xF0
00007e4af17ced66  vmovaps [rsp], xmm0
00007e4af17ced6b  vmovaps [rsp+0x10], xmm1
00007e4af17ced71  vmovaps [rsp+0x20], xmm2
00007e4af17ced77  vmovaps [rsp+0x30], xmm3
00007e4af17ced7d  vmovaps [rsp+0x40], xmm4
00007e4af17ced83  vmovaps [rsp+0x50], xmm5
00007e4af17ced89  vmovaps [rsp+0x60], xmm6
00007e4af17ced8f  vmovaps [rsp+0x70], xmm7
00007e4af17ced95  vmovaps [rsp+0x80], xmm8
00007e4af17ced9e  vmovaps [rsp+0x90], xmm9
00007e4af17ceda7  vmovaps [rsp+0xA0], xmm10
00007e4af17cedb0  vmovaps [rsp+0xB0], xmm11
00007e4af17cedb9  vmovaps [rsp+0xC0], xmm12
00007e4af17cedc2  vmovaps [rsp+0xD0], xmm14
00007e4af17cedcb  vmovaps [rsp+0xE0], xmm15
00007e4af17cedd4  sub rsp, 0x30
00007e4af17cedd8  movaps [rsp], xmm13
00007e4af17ceddd  movaps [rsp+0x10], xmm15
00007e4af17cede3  movaps [rsp+0x20], xmm14
00007e4af17cede9  lea rdi, [rsp]
00007e4af17ceded  mov esi, 0x00
00007e4af17cedf2  mov rax, 0x6256754A7530
00007e4af17cedfc  call rax
00007e4af17cedfe  movaps xmm13, [rsp]
00007e4af17cee03  add rsp, 0x30
00007e4af17cee07  vmovaps xmm0, [rsp]
00007e4af17cee0c  vmovaps xmm1, [rsp+0x10]
00007e4af17cee12  vmovaps xmm2, [rsp+0x20]
00007e4af17cee18  vmovaps xmm3, [rsp+0x30]
00007e4af17cee1e  vmovaps xmm4, [rsp+0x40]
00007e4af17cee24  vmovaps xmm5, [rsp+0x50]
00007e4af17cee2a  vmovaps xmm6, [rsp+0x60]
00007e4af17cee30  vmovaps xmm7, [rsp+0x70]
00007e4af17cee36  vmovaps xmm8, [rsp+0x80]
00007e4af17cee3f  vmovaps xmm9, [rsp+0x90]
00007e4af17cee48  vmovaps xmm10, [rsp+0xA0]
00007e4af17cee51  vmovaps xmm11, [rsp+0xB0]
00007e4af17cee5a  vmovaps xmm12, [rsp+0xC0]
00007e4af17cee63  vmovaps xmm14, [rsp+0xD0]
00007e4af17cee6c  vmovaps xmm15, [rsp+0xE0]
00007e4af17cee75  add rsp, 0xF0
00007e4af17cee7c  pop r11
00007e4af17cee7e  pop r10
00007e4af17cee80  pop r9
00007e4af17cee82  pop r8
00007e4af17cee84  pop rsi
00007e4af17cee85  pop rdi
00007e4af17cee86  pop rdx
00007e4af17cee87  pop rcx
00007e4af17cee88  pop rax
00007e4af17cee89  add rsp, 0x08
00007e4af17cee8d  jmp 0x00007E4AF17CEC71
00007e4af17cee92  call 0x00007E4AF16C2240
00007e4af17cee97  jmp 0x00007E4AF17CEC8B
00007e4af17cee9c  sub rsp, 0x08
00007e4af17ceea0  push rax
00007e4af17ceea1  push rcx
00007e4af17ceea2  push rdx
00007e4af17ceea3  push rdi
00007e4af17ceea4  push rsi
00007e4af17ceea5  push r8
00007e4af17ceea7  push r9
00007e4af17ceea9  push r10
00007e4af17ceeab  push r11
00007e4af17ceead  sub rsp, 0xF0
00007e4af17ceeb4  vmovaps [rsp], xmm0
00007e4af17ceeb9  vmovaps [rsp+0x10], xmm1
00007e4af17ceebf  vmovaps [rsp+0x20], xmm2
00007e4af17ceec5  vmovaps [rsp+0x30], xmm3
00007e4af17ceecb  vmovaps [rsp+0x40], xmm4
00007e4af17ceed1  vmovaps [rsp+0x50], xmm5
00007e4af17ceed7  vmovaps [rsp+0x60], xmm6
00007e4af17ceedd  vmovaps [rsp+0x70], xmm7
00007e4af17ceee3  vmovaps [rsp+0x80], xmm8
00007e4af17ceeec  vmovaps [rsp+0x90], xmm9
00007e4af17ceef5  vmovaps [rsp+0xA0], xmm10
00007e4af17ceefe  vmovaps [rsp+0xB0], xmm11
00007e4af17cef07  vmovaps [rsp+0xC0], xmm12
00007e4af17cef10  vmovaps [rsp+0xD0], xmm13
00007e4af17cef19  vmovaps [rsp+0xE0], xmm15
00007e4af17cef22  sub rsp, 0x30
00007e4af17cef26  movaps [rsp], xmm14
00007e4af17cef2b  movaps [rsp+0x10], xmm1
00007e4af17cef30  movaps [rsp+0x20], xmm15
00007e4af17cef36  lea rdi, [rsp]
00007e4af17cef3a  mov esi, 0x00
00007e4af17cef3f  mov rax, 0x6256754A7530
00007e4af17cef49  call rax
00007e4af17cef4b  movaps xmm14, [rsp]
00007e4af17cef50  add rsp, 0x30
00007e4af17cef54  vmovaps xmm0, [rsp]
00007e4af17cef59  vmovaps xmm1, [rsp+0x10]
00007e4af17cef5f  vmovaps xmm2, [rsp+0x20]
00007e4af17cef65  vmovaps xmm3, [rsp+0x30]
00007e4af17cef6b  vmovaps xmm4, [rsp+0x40]
00007e4af17cef71  vmovaps xmm5, [rsp+0x50]
00007e4af17cef77  vmovaps xmm6, [rsp+0x60]
00007e4af17cef7d  vmovaps xmm7, [rsp+0x70]
00007e4af17cef83  vmovaps xmm8, [rsp+0x80]
00007e4af17cef8c  vmovaps xmm9, [rsp+0x90]
00007e4af17cef95  vmovaps xmm10, [rsp+0xA0]
00007e4af17cef9e  vmovaps xmm11, [rsp+0xB0]
00007e4af17cefa7  vmovaps xmm12, [rsp+0xC0]
00007e4af17cefb0  vmovaps xmm13, [rsp+0xD0]
00007e4af17cefb9  vmovaps xmm15, [rsp+0xE0]
00007e4af17cefc2  add rsp, 0xF0
00007e4af17cefc9  pop r11
00007e4af17cefcb  pop r10
00007e4af17cefcd  pop r9
00007e4af17cefcf  pop r8
00007e4af17cefd1  pop rsi
00007e4af17cefd2  pop rdi
00007e4af17cefd3  pop rdx
00007e4af17cefd4  pop rcx
00007e4af17cefd5  pop rax
00007e4af17cefd6  add rsp, 0x08
00007e4af17cefda  jmp 0x00007E4AF17CECAE
00007e4af17cefdf  call 0x00007E4AF16C34C0
00007e4af17cefe4  jmp 0x00007E4AF17CECC4
00007e4af17cefe9  int3
00007e4af17cefea  nop [rax+rax*1], ax
00007e4af17ceff0  mov rax, [r15+0xF8]
00007e4af17ceff7  lea r14, [rax-0x150]
00007e4af17ceffe  mov [r15+0xF8], r14
00007e4af17cf005  mov rax, [r15+0x50]
00007e4af17cf009  lea r12, [rax+0x80]
00007e4af17cf010  movups xmm1, [r13+r12*1]
00007e4af17cf016  lea r12, [rax+0x90]
00007e4af17cf01d  movups xmm15, [r13+r12*1]
00007e4af17cf023  mov qword ptr [r15+0x48], 0x00
00007e4af17cf02b  lea r12, [rax+0x40]
00007e4af17cf02f  movups xmm14, [r13+r12*1]
00007e4af17cf035  lea r12, [rax+0x50]
00007e4af17cf039  movups xmm13, [r13+r12*1]
00007e4af17cf03f  lea r12, [r14+0x120]
00007e4af17cf046  movq xmm12, qword ptr [r15+0x1C0]
00007e4af17cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007e4af17cf058  movq r11, xmm12
00007e4af17cf05d  movq r10, xmm11
00007e4af17cf062  mov [r13+r12*1], r11
00007e4af17cf067  lea r12, [r14+0x128]
00007e4af17cf06e  mov [r13+r12*1], r10
00007e4af17cf073  vxorps xmm12, xmm12, xmm12
00007e4af17cf078  vpbroadcastq xmm12, xmm12
00007e4af17cf07d  lea r12, [r14+0x100]
00007e4af17cf084  movq xmm11, qword ptr [r15+0x200]
00007e4af17cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007e4af17cf096  movq r11, xmm11
00007e4af17cf09b  movq r10, xmm10
00007e4af17cf0a0  mov [r13+r12*1], r11
00007e4af17cf0a5  lea r12, [r14+0x108]
00007e4af17cf0ac  mov [r13+r12*1], r10
00007e4af17cf0b1  lea r12, [r14+0xE0]
00007e4af17cf0b8  movups [r13+r12*1], xmm15
00007e4af17cf0be  lea r12, [r14+0xF0]
00007e4af17cf0c5  movups [r13+r12*1], xmm1
00007e4af17cf0cb  lea r12, [rax+0xC0]
00007e4af17cf0d2  movups xmm1, [r13+r12*1]
00007e4af17cf0d8  lea r12, [rax+0xD0]
00007e4af17cf0df  movups xmm15, [r13+r12*1]
00007e4af17cf0e5  lea r12, [r14+0x110]
00007e4af17cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007e4af17cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007e4af17cf0fe  movq r11, xmm11
00007e4af17cf103  movq r10, xmm10
00007e4af17cf108  mov [r13+r12*1], r11
00007e4af17cf10d  lea r12, [r14+0x118]
00007e4af17cf114  mov [r13+r12*1], r10
00007e4af17cf119  movups xmm11, [r13+rax*1]
00007e4af17cf11f  lea r12, [rax+0x10]
00007e4af17cf123  movups xmm10, [r13+r12*1]
00007e4af17cf129  lea r12, [r14+0x130]
00007e4af17cf130  movq xmm9, qword ptr [r15+0x1A0]
00007e4af17cf139  movq xmm8, qword ptr [r15+0x190]
00007e4af17cf142  movq r11, xmm9
00007e4af17cf147  movq r10, xmm8
00007e4af17cf14c  mov [r13+r12*1], r11
00007e4af17cf151  lea r12, [r14+0x138]
00007e4af17cf158  mov [r13+r12*1], r10
00007e4af17cf15d  lea r12, [rax+0x140]
00007e4af17cf164  movups xmm9, [r13+r12*1]
00007e4af17cf16a  lea r12, [rax+0x150]
00007e4af17cf171  movups xmm8, [r13+r12*1]
00007e4af17cf177  lea r12, [r14+0xC0]
00007e4af17cf17e  movups [r13+r12*1], xmm15
00007e4af17cf184  lea r12, [r14+0xD0]
00007e4af17cf18b  movups [r13+r12*1], xmm1
00007e4af17cf191  lea r12, [rax+0x100]
00007e4af17cf198  movups xmm1, [r13+r12*1]
00007e4af17cf19e  lea r12, [rax+0x110]
00007e4af17cf1a5  movups xmm15, [r13+r12*1]
00007e4af17cf1ab  lea r12, [r14+0x140]
00007e4af17cf1b2  mov r11, [r15+0xE8]
00007e4af17cf1b9  mov [r13+r12*1], r11
00007e4af17cf1be  lea r12, [rax+0x180]
00007e4af17cf1c5  movups xmm7, [r13+r12*1]
00007e4af17cf1cb  lea r12, [rax+0x190]
00007e4af17cf1d2  movups xmm6, [r13+r12*1]
00007e4af17cf1d8  lea r12, [rax+0x1C0]
00007e4af17cf1df  movups xmm5, [r13+r12*1]
00007e4af17cf1e5  lea r12, [rax+0x1D0]
00007e4af17cf1ec  movups xmm4, [r13+r12*1]
00007e4af17cf1f2  lea r12, [r14+0x20]
00007e4af17cf1f6  movups [r13+r12*1], xmm1
00007e4af17cf1fc  lea r12, [r14+0x30]
00007e4af17cf200  movups [r13+r12*1], xmm13
00007e4af17cf206  lea r12, [rax+0x60]
00007e4af17cf20a  movups xmm1, [r13+r12*1]
00007e4af17cf210  lea r12, [rax+0x70]
00007e4af17cf214  movups xmm13, [r13+r12*1]
00007e4af17cf21a  lea r12, [rax+0x20]
00007e4af17cf21e  movups xmm3, [r13+r12*1]
00007e4af17cf224  lea r12, [rax+0x30]
00007e4af17cf228  movups xmm2, [r13+r12*1]
00007e4af17cf22e  movaps [r15+0x1F0], xmm2
00007e4af17cf236  lea r12, [r14+0x60]
00007e4af17cf23a  movups [r13+r12*1], xmm11
00007e4af17cf240  lea r12, [r14+0x70]
00007e4af17cf244  movups [r13+r12*1], xmm5
00007e4af17cf24a  lea r12, [rax+0xE0]
00007e4af17cf251  movups xmm11, [r13+r12*1]
00007e4af17cf257  lea r12, [rax+0xF0]
00007e4af17cf25e  movups xmm5, [r13+r12*1]
00007e4af17cf264  lea r12, [r14+0xA0]
00007e4af17cf26b  movups [r13+r12*1], xmm13
00007e4af17cf271  lea r12, [r14+0xB0]
00007e4af17cf278  movups [r13+r12*1], xmm1
00007e4af17cf27e  lea r12, [rax+0xA0]
00007e4af17cf285  movups xmm1, [r13+r12*1]
00007e4af17cf28b  lea r12, [rax+0xB0]
00007e4af17cf292  movups xmm13, [r13+r12*1]
00007e4af17cf298  lea r12, [rax+0x120]
00007e4af17cf29f  vmovaps [rsp+0x10], xmm1
00007e4af17cf2a5  movups xmm1, [r13+r12*1]
00007e4af17cf2ab  lea r12, [rax+0x130]
00007e4af17cf2b2  vmovaps [rsp+0x20], xmm1
00007e4af17cf2b8  movups xmm1, [r13+r12*1]
00007e4af17cf2be  lea r12, [rax+0x160]
00007e4af17cf2c5  vmovaps [rsp+0x30], xmm1
00007e4af17cf2cb  movups xmm1, [r13+r12*1]
00007e4af17cf2d1  lea r12, [rax+0x170]
00007e4af17cf2d8  vmovaps [rsp+0x40], xmm1
00007e4af17cf2de  movups xmm1, [r13+r12*1]
00007e4af17cf2e4  movaps [r15+0x2B0], xmm1
00007e4af17cf2ec  lea r12, [r14+0x80]
00007e4af17cf2f3  movups [r13+r12*1], xmm13
00007e4af17cf2f9  lea r12, [r14+0x90]
00007e4af17cf300  vmovaps xmm13, [rsp+0x10]
00007e4af17cf306  movups [r13+r12*1], xmm13
00007e4af17cf30c  lea r12, [rax+0x1A0]
00007e4af17cf313  movups xmm13, [r13+r12*1]
00007e4af17cf319  lea r12, [rax+0x1B0]
00007e4af17cf320  vmovaps [rsp+0x10], xmm1
00007e4af17cf326  movups xmm1, [r13+r12*1]
00007e4af17cf32c  movaps [r15+0x290], xmm13
00007e4af17cf334  movaps [r15+0x1E0], xmm1
00007e4af17cf33c  lea r12, [rax+0x1E0]
00007e4af17cf343  vmovaps [rsp+0x50], xmm1
00007e4af17cf349  movups xmm1, [r13+r12*1]
00007e4af17cf34f  lea r12, [rax+0x1F0]
00007e4af17cf356  vmovaps [rsp+0x60], xmm1
00007e4af17cf35c  movups xmm1, [r13+r12*1]
00007e4af17cf362  mov qword ptr [r15+0x50], 0x430920
00007e4af17cf36a  lea rax, [r14+0x40]
00007e4af17cf36e  vmovaps [rsp+0x70], xmm1
00007e4af17cf374  vmovaps xmm1, [rsp+0x40]
00007e4af17cf37a  movups [r13+rax*1], xmm1
00007e4af17cf380  lea rax, [r14+0x50]
00007e4af17cf384  movups [r13+rax*1], xmm10
00007e4af17cf38a  vmovaps xmm1, [rsp+0x70]
00007e4af17cf390  movups [r13+r14*1], xmm1
00007e4af17cf396  lea rax, [r14+0x10]
00007e4af17cf39a  vmovaps xmm1, [rsp+0x60]
00007e4af17cf3a0  movups [r13+rax*1], xmm1
00007e4af17cf3a6  mov rax, [r15+0x40]
00007e4af17cf3aa  vmovaps [rsp+0x40], xmm3
00007e4af17cf3b0  vmovaps xmm1, [rsp+0x40]
00007e4af17cf3b6  por xmm3, xmm1
00007e4af17cf3ba  vmovaps [rsp+0x40], xmm6
00007e4af17cf3c0  vmovaps xmm10, [rsp+0x40]
00007e4af17cf3c6  por xmm6, xmm10
00007e4af17cf3cb  lea r12, [rax+0x30]
00007e4af17cf3cf  mov r11, [r13+r12*1]
00007e4af17cf3d4  lea r12, [rax+0x38]
00007e4af17cf3d8  mov r10, [r13+r12*1]
00007e4af17cf3dd  movq xmm10, r11
00007e4af17cf3e2  vmovaps [rsp+0x40], xmm1
00007e4af17cf3e8  movq xmm1, r10
00007e4af17cf3ed  movq xmm10, xmm10
00007e4af17cf3f2  vmovaps [rsp+0x60], xmm10
00007e4af17cf3f8  movq xmm10, xmm10
00007e4af17cf3fd  movaps [r15+0x130], xmm10
00007e4af17cf405  movq xmm1, xmm1
00007e4af17cf409  vmovaps [rsp+0x70], xmm1
00007e4af17cf40f  movq xmm1, xmm1
00007e4af17cf413  movaps [r15+0x280], xmm1
00007e4af17cf41b  vmovaps [rsp+0x80], xmm9
00007e4af17cf424  vmovaps xmm1, [rsp+0x80]
00007e4af17cf42d  por xmm9, xmm1
00007e4af17cf432  lea r12, [rax+0x20]
00007e4af17cf436  mov r11, [r13+r12*1]
00007e4af17cf43b  lea r12, [rax+0x28]
00007e4af17cf43f  mov r10, [r13+r12*1]
00007e4af17cf444  movq xmm1, r11
00007e4af17cf449  movq xmm10, r10
00007e4af17cf44e  movq xmm1, xmm1
00007e4af17cf452  vmovaps [rsp+0x80], xmm1
00007e4af17cf45b  movq xmm1, xmm1
00007e4af17cf45f  movaps [r15+0x150], xmm1
00007e4af17cf467  movq xmm10, xmm10
00007e4af17cf46c  vmovaps [rsp+0x90], xmm10
00007e4af17cf475  movq xmm10, xmm10
00007e4af17cf47a  movaps [r15+0x140], xmm10
00007e4af17cf482  lea r12, [rax+0x10]
00007e4af17cf486  mov r11, [r13+r12*1]
00007e4af17cf48b  lea r12, [rax+0x18]
00007e4af17cf48f  mov r10, [r13+r12*1]
00007e4af17cf494  movq xmm1, r11
00007e4af17cf499  movq xmm10, r10
00007e4af17cf49e  movq xmm1, xmm1
00007e4af17cf4a2  vmovaps [rsp+0xA0], xmm1
00007e4af17cf4ab  movq xmm1, xmm1
00007e4af17cf4af  movaps [r15+0x170], xmm1
00007e4af17cf4b7  movq xmm10, xmm10
00007e4af17cf4bc  vmovaps [rsp+0xB0], xmm10
00007e4af17cf4c5  movq xmm10, xmm10
00007e4af17cf4ca  movaps [r15+0x160], xmm10
00007e4af17cf4d2  mov r12, [r13+rax*1]
00007e4af17cf4d7  vmovq xmm1, r12
00007e4af17cf4dc  vpbroadcastq xmm1, xmm1
00007e4af17cf4e1  lea r12, [rax+0x08]
00007e4af17cf4e5  mov rax, [r13+r12*1]
00007e4af17cf4ea  movq xmm10, rax
00007e4af17cf4ef  movaps [r15+0x230], xmm10
00007e4af17cf4f7  lea rax, [r14+0x50]
00007e4af17cf4fb  movups xmm10, [r13+rax*1]
00007e4af17cf501  lea rax, [r14+0x60]
00007e4af17cf505  vmovaps [rsp+0xC0], xmm1
00007e4af17cf50e  movups xmm1, [r13+rax*1]
00007e4af17cf514  lea rax, [r14+0x30]
00007e4af17cf518  vmovaps [rsp+0xD0], xmm1
00007e4af17cf521  movups xmm1, [r13+rax*1]
00007e4af17cf527  mov qword ptr [r15+0x60], 0x430920
00007e4af17cf52f  mov qword ptr [r15+0x58], 0x40
00007e4af17cf537  vmovaps [rsp+0xE0], xmm1
00007e4af17cf540  vmovaps [rsp+0xF0], xmm15
00007e4af17cf549  vmovaps xmm15, [rsp+0xC0]
00007e4af17cf552  vmovaps [rsp+0xC0], xmm14
00007e4af17cf55b  vmovaps xmm14, [rsp+0x40]
00007e4af17cf561  vmovaps [rsp+0x40], xmm13
00007e4af17cf567  movaps xmm1, xmm15
00007e4af17cf56b  mulpd xmm1, xmm14
00007e4af17cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007e4af17cf575  ptest xmm13, xmm13
00007e4af17cf57b  jnz 0x00007E4AF17D0682
00007e4af17cf581  movq xmm14, qword ptr [r15+0x230]
00007e4af17cf58a  vmovaps [rsp+0x100], xmm14
00007e4af17cf593  vpermilpd xmm14, xmm14, 0x00
00007e4af17cf599  vmovaps [rsp+0x110], xmm1
00007e4af17cf5a2  vmovaps xmm1, [rsp+0xE0]
00007e4af17cf5ab  vmovaps [rsp+0xE0], xmm15
00007e4af17cf5b4  movaps xmm13, xmm1
00007e4af17cf5b8  mulpd xmm13, xmm14
00007e4af17cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007e4af17cf5c3  ptest xmm15, xmm15
00007e4af17cf5c9  jnz 0x00007E4AF17D07C4
00007e4af17cf5cf  vxorps xmm1, xmm1, xmm1
00007e4af17cf5d3  vpbroadcastq xmm1, xmm1
00007e4af17cf5d8  vmovaps xmm14, [rsp+0xE0]
00007e4af17cf5e1  vmovaps [rsp+0xE0], xmm1
00007e4af17cf5ea  vmovaps xmm1, [rsp+0xD0]
00007e4af17cf5f3  vmovaps [rsp+0xD0], xmm13
00007e4af17cf5fc  movaps xmm15, xmm14
00007e4af17cf600  mulpd xmm15, xmm1
00007e4af17cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007e4af17cf60b  ptest xmm13, xmm13
00007e4af17cf611  jnz 0x00007E4AF17D0907
00007e4af17cf617  movaps xmm1, xmm14
00007e4af17cf61b  mulpd xmm1, xmm10
00007e4af17cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007e4af17cf625  ptest xmm13, xmm13
00007e4af17cf62b  jnz 0x00007E4AF17D0A4A
00007e4af17cf631  movaps xmm13, xmm14
00007e4af17cf635  mulpd xmm13, xmm2
00007e4af17cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007e4af17cf640  ptest xmm10, xmm10
00007e4af17cf646  jnz 0x00007E4AF17D0B8C
00007e4af17cf64c  vmovaps [rsp+0x120], xmm7
00007e4af17cf655  vmovaps xmm14, [rsp+0x120]
00007e4af17cf65e  por xmm7, xmm14
00007e4af17cf663  vmovaps xmm14, [rsp+0xC0]
00007e4af17cf66c  vmovaps xmm10, [rsp+0xC0]
00007e4af17cf675  por xmm14, xmm10
00007e4af17cf67a  vmovaps xmm2, [rsp+0x100]
00007e4af17cf683  vpermilpd xmm2, xmm2, 0x00
00007e4af17cf689  vmovaps [rsp+0xC0], xmm1
00007e4af17cf692  vmovaps [rsp+0x120], xmm15
00007e4af17cf69b  movaps xmm1, xmm10
00007e4af17cf69f  mulpd xmm1, xmm2
00007e4af17cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007e4af17cf6a8  ptest xmm15, xmm15
00007e4af17cf6ae  jnz 0x00007E4AF17D0CCF
00007e4af17cf6b4  xor eax, eax
00007e4af17cf6b6  mov r12d, 0x40
00007e4af17cf6bc  mov r11d, 0x200
00007e4af17cf6c2  cmp r12, r11
00007e4af17cf6c5  cmc
00007e4af17cf6c6  lahf
00007e4af17cf6c7  seto al
00007e4af17cf6ca  mov [r15+0x108], eax
00007e4af17cf6d1  vmovaps xmm10, [rsp+0x110]
00007e4af17cf6da  vmovaps xmm2, [rsp+0xE0]
00007e4af17cf6e3  vmovaps [rsp+0xE0], xmm1
00007e4af17cf6ec  movaps xmm15, xmm10
00007e4af17cf6f0  addpd xmm15, xmm2
00007e4af17cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007e4af17cf6fb  ptest xmm1, xmm1
00007e4af17cf700  jnz 0x00007E4AF17D0E10
00007e4af17cf706  vmovaps xmm10, [rsp+0x120]
00007e4af17cf70f  vmovaps [rsp+0x110], xmm15
00007e4af17cf718  movaps xmm1, xmm10
00007e4af17cf71c  addpd xmm1, xmm12
00007e4af17cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007e4af17cf726  ptest xmm15, xmm15
00007e4af17cf72c  jnz 0x00007E4AF17D0F53
00007e4af17cf732  vmovaps xmm10, [rsp+0xC0]
00007e4af17cf73b  vmovaps [rsp+0xC0], xmm1
00007e4af17cf744  movaps xmm15, xmm10
00007e4af17cf748  addpd xmm15, xmm12
00007e4af17cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007e4af17cf753  ptest xmm1, xmm1
00007e4af17cf758  jnz 0x00007E4AF17D1095
00007e4af17cf75e  vmovaps xmm1, [rsp+0x30]
00007e4af17cf764  vmovaps xmm12, [rsp+0x30]
00007e4af17cf76a  por xmm1, xmm12
00007e4af17cf76f  vmovaps xmm12, [rsp+0x20]
00007e4af17cf775  vmovaps xmm10, [rsp+0x20]
00007e4af17cf77b  por xmm12, xmm10
00007e4af17cf780  vmovaps [rsp+0x20], xmm5
00007e4af17cf786  vmovaps xmm10, [rsp+0x20]
00007e4af17cf78c  por xmm5, xmm10
00007e4af17cf791  vmovaps [rsp+0x20], xmm11
00007e4af17cf797  vmovaps xmm10, [rsp+0x20]
00007e4af17cf79d  por xmm11, xmm10
00007e4af17cf7a2  vmovaps [rsp+0x20], xmm4
00007e4af17cf7a8  vmovaps xmm10, [rsp+0x20]
00007e4af17cf7ae  por xmm4, xmm10
00007e4af17cf7b3  vmovaps [rsp+0x20], xmm8
00007e4af17cf7b9  vmovaps xmm10, [rsp+0x20]
00007e4af17cf7bf  por xmm8, xmm10
00007e4af17cf7c4  vmovaps xmm10, [rsp+0xF0]
00007e4af17cf7cd  vmovaps [rsp+0x20], xmm1
00007e4af17cf7d3  vmovaps xmm1, [rsp+0xF0]
00007e4af17cf7dc  por xmm10, xmm1
00007e4af17cf7e1  lea rax, [r14+0xA0]
00007e4af17cf7e8  movups xmm1, [r13+rax*1]
00007e4af17cf7ee  lea rax, [r14+0xB0]
00007e4af17cf7f5  vmovaps [rsp+0x30], xmm1
00007e4af17cf7fb  movups xmm1, [r13+rax*1]
00007e4af17cf801  vmovaps [rsp+0xF0], xmm1
00007e4af17cf80a  vmovaps [rsp+0x120], xmm15
00007e4af17cf813  movaps xmm1, xmm13
00007e4af17cf817  addpd xmm1, xmm2
00007e4af17cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007e4af17cf820  ptest xmm15, xmm15
00007e4af17cf826  jnz 0x00007E4AF17D11ED
00007e4af17cf82c  lea rax, [r14+0xF0]
00007e4af17cf833  movups xmm15, [r13+rax*1]
00007e4af17cf839  vmovaps xmm2, [rsp+0xC0]
00007e4af17cf842  vmovaps [rsp+0xC0], xmm1
00007e4af17cf84b  vmovaps xmm1, [rsp+0xE0]
00007e4af17cf854  vmovaps [rsp+0xE0], xmm15
00007e4af17cf85d  movaps xmm13, xmm2
00007e4af17cf861  addpd xmm13, xmm1
00007e4af17cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007e4af17cf86c  ptest xmm15, xmm15
00007e4af17cf872  jnz 0x00007E4AF17D1338
00007e4af17cf878  vmovaps xmm15, [rsp+0x120]
00007e4af17cf881  vmovaps xmm2, [rsp+0xD0]
00007e4af17cf88a  vmovaps [rsp+0xD0], xmm14
00007e4af17cf893  movaps xmm1, xmm15
00007e4af17cf897  addpd xmm1, xmm2
00007e4af17cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007e4af17cf8a0  ptest xmm14, xmm14
00007e4af17cf8a6  jnz 0x00007E4AF17D147A
00007e4af17cf8ac  vmovaps xmm15, [rsp+0x100]
00007e4af17cf8b5  vpermilpd xmm15, xmm15, 0x00
00007e4af17cf8bb  vmovaps xmm2, [rsp+0xF0]
00007e4af17cf8c4  vmovaps [rsp+0xF0], xmm1
00007e4af17cf8cd  movaps xmm14, xmm2
00007e4af17cf8d1  mulpd xmm14, xmm15
00007e4af17cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007e4af17cf8dc  ptest xmm1, xmm1
00007e4af17cf8e1  jnz 0x00007E4AF17D15BB
00007e4af17cf8e7  vmovaps xmm1, [rsp+0xA0]
00007e4af17cf8f0  vpermilpd xmm1, xmm1, 0x00
00007e4af17cf8f6  vmovaps xmm2, [rsp+0xE0]
00007e4af17cf8ff  vmovaps [rsp+0xE0], xmm14
00007e4af17cf908  movaps xmm15, xmm2
00007e4af17cf90c  mulpd xmm15, xmm1
00007e4af17cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007e4af17cf917  ptest xmm14, xmm14
00007e4af17cf91d  jnz 0x00007E4AF17D16FE
00007e4af17cf923  lea rax, [r14+0xE0]
00007e4af17cf92a  movups xmm1, [r13+rax*1]
00007e4af17cf930  vmovaps xmm14, [rsp+0x100]
00007e4af17cf939  vpermilpd xmm14, xmm14, 0x00
00007e4af17cf93f  vmovaps [rsp+0x100], xmm1
00007e4af17cf948  vmovaps xmm1, [rsp+0x30]
00007e4af17cf94e  vmovaps [rsp+0x30], xmm15
00007e4af17cf954  movaps xmm2, xmm1
00007e4af17cf957  mulpd xmm2, xmm14
00007e4af17cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007e4af17cf961  ptest xmm15, xmm15
00007e4af17cf967  jnz 0x00007E4AF17D184A
00007e4af17cf96d  vmovaps [rsp+0x120], xmm10
00007e4af17cf976  vmovaps xmm1, [rsp+0x120]
00007e4af17cf97f  por xmm10, xmm1
00007e4af17cf984  movaps [r15+0x300], xmm10
00007e4af17cf98c  vmovaps [rsp+0x120], xmm8
00007e4af17cf995  vmovaps xmm1, [rsp+0x120]
00007e4af17cf99e  por xmm8, xmm1
00007e4af17cf9a3  movaps [r15+0x190], xmm8
00007e4af17cf9ab  vmovaps xmm1, [rsp+0xA0]
00007e4af17cf9b4  vpermilpd xmm1, xmm1, 0x00
00007e4af17cf9ba  vmovaps xmm14, [rsp+0x100]
00007e4af17cf9c3  vmovaps [rsp+0x100], xmm13
00007e4af17cf9cc  movaps xmm15, xmm14
00007e4af17cf9d0  mulpd xmm15, xmm1
00007e4af17cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007e4af17cf9db  ptest xmm13, xmm13
00007e4af17cf9e1  jnz 0x00007E4AF17D198B
00007e4af17cf9e7  lea rax, [r14+0x90]
00007e4af17cf9ee  movups xmm1, [r13+rax*1]
00007e4af17cf9f4  vmovaps [rsp+0x120], xmm4
00007e4af17cf9fd  vmovaps xmm14, [rsp+0x120]
00007e4af17cfa06  por xmm4, xmm14
00007e4af17cfa0b  movaps [r15+0x1C0], xmm4
00007e4af17cfa13  vmovaps [rsp+0x120], xmm11
00007e4af17cfa1c  vmovaps xmm14, [rsp+0x120]
00007e4af17cfa25  por xmm11, xmm14
00007e4af17cfa2a  movaps [r15+0x200], xmm11
00007e4af17cfa32  vmovaps [rsp+0x120], xmm5
00007e4af17cfa3b  vmovaps xmm14, [rsp+0x120]
00007e4af17cfa44  por xmm5, xmm14
00007e4af17cfa49  movaps [r15+0x2D0], xmm5
00007e4af17cfa51  vmovaps [rsp+0x120], xmm12
00007e4af17cfa5a  vmovaps xmm14, [rsp+0x120]
00007e4af17cfa63  por xmm12, xmm14
00007e4af17cfa68  movaps [r15+0x2E0], xmm12
00007e4af17cfa70  vmovaps xmm13, [rsp+0x110]
00007e4af17cfa79  vmovaps [rsp+0x110], xmm1
00007e4af17cfa82  vmovaps xmm1, [rsp+0xE0]
00007e4af17cfa8b  vmovaps [rsp+0xE0], xmm15
00007e4af17cfa94  movaps xmm14, xmm13
00007e4af17cfa98  addpd xmm14, xmm1
00007e4af17cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007e4af17cfaa3  ptest xmm15, xmm15
00007e4af17cfaa9  jnz 0x00007E4AF17D1AD8
00007e4af17cfaaf  vmovaps xmm1, [rsp+0xA0]
00007e4af17cfab8  vpermilpd xmm1, xmm1, 0x00
00007e4af17cfabe  vmovaps xmm13, [rsp+0x110]
00007e4af17cfac7  vmovaps [rsp+0x110], xmm14
00007e4af17cfad0  movaps xmm15, xmm13
00007e4af17cfad4  mulpd xmm15, xmm1
00007e4af17cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007e4af17cfadf  ptest xmm14, xmm14
00007e4af17cfae5  jnz 0x00007E4AF17D1C1B
00007e4af17cfaeb  lea rax, [r14+0x80]
00007e4af17cfaf2  movups xmm1, [r13+rax*1]
00007e4af17cfaf8  vmovaps xmm13, [rsp+0xC0]
00007e4af17cfb01  vmovaps [rsp+0xC0], xmm1
00007e4af17cfb0a  movaps xmm14, xmm13
00007e4af17cfb0e  addpd xmm14, xmm2
00007e4af17cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007e4af17cfb19  ptest xmm1, xmm1
00007e4af17cfb1e  jnz 0x00007E4AF17D1D68
00007e4af17cfb24  vmovaps xmm13, [rsp+0x100]
00007e4af17cfb2d  vmovaps xmm2, [rsp+0x30]
00007e4af17cfb33  vmovaps [rsp+0x30], xmm15
00007e4af17cfb39  movaps xmm1, xmm13
00007e4af17cfb3d  addpd xmm1, xmm2
00007e4af17cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007e4af17cfb46  ptest xmm15, xmm15
00007e4af17cfb4c  jnz 0x00007E4AF17D1EAB
00007e4af17cfb52  vmovaps xmm15, [rsp+0x20]
00007e4af17cfb58  vmovaps xmm13, [rsp+0x20]
00007e4af17cfb5e  por xmm15, xmm13
00007e4af17cfb63  movaps [r15+0x2F0], xmm15
00007e4af17cfb6b  vmovaps xmm13, [rsp+0xA0]
00007e4af17cfb74  vpermilpd xmm13, xmm13, 0x00
00007e4af17cfb7a  vmovaps [rsp+0x20], xmm1
00007e4af17cfb80  vmovaps xmm1, [rsp+0xC0]
00007e4af17cfb89  vmovaps [rsp+0xA0], xmm15
00007e4af17cfb92  movaps xmm2, xmm1
00007e4af17cfb95  mulpd xmm2, xmm13
00007e4af17cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007e4af17cfb9f  ptest xmm15, xmm15
00007e4af17cfba5  jnz 0x00007E4AF17D1FEC
00007e4af17cfbab  lea rax, [r14+0xD0]
00007e4af17cfbb2  movups xmm1, [r13+rax*1]
00007e4af17cfbb8  vmovaps xmm13, [rsp+0xF0]
00007e4af17cfbc1  vmovaps [rsp+0xC0], xmm1
00007e4af17cfbca  vmovaps xmm1, [rsp+0xE0]
00007e4af17cfbd3  vmovaps [rsp+0xE0], xmm14
00007e4af17cfbdc  movaps xmm15, xmm13
00007e4af17cfbe0  addpd xmm15, xmm1
00007e4af17cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007e4af17cfbeb  ptest xmm14, xmm14
00007e4af17cfbf1  jnz 0x00007E4AF17D2137
00007e4af17cfbf7  vmovaps xmm1, [rsp+0xB0]
00007e4af17cfc00  vpermilpd xmm1, xmm1, 0x00
00007e4af17cfc06  movaps xmm14, xmm11
00007e4af17cfc0a  mulpd xmm14, xmm1
00007e4af17cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007e4af17cfc15  ptest xmm13, xmm13
00007e4af17cfc1b  jnz 0x00007E4AF17D227A
00007e4af17cfc21  movaps [r15+0x260], xmm14
00007e4af17cfc29  vxorps xmm1, xmm1, xmm1
00007e4af17cfc2d  vpbroadcastq xmm1, xmm1
00007e4af17cfc32  movaps [r15+0x1B0], xmm1
00007e4af17cfc3a  vmovaps xmm1, [rsp+0xB0]
00007e4af17cfc43  vpermilpd xmm1, xmm1, 0x00
00007e4af17cfc49  vmovaps xmm11, [rsp+0xC0]
00007e4af17cfc52  vmovaps [rsp+0xC0], xmm15
00007e4af17cfc5b  movaps xmm13, xmm11
00007e4af17cfc5f  mulpd xmm13, xmm1
00007e4af17cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007e4af17cfc6a  ptest xmm15, xmm15
00007e4af17cfc70  jnz 0x00007E4AF17D23BD
00007e4af17cfc76  lea rax, [r14+0xC0]
00007e4af17cfc7d  movups xmm1, [r13+rax*1]
00007e4af17cfc83  vmovaps xmm11, [rsp+0x110]
00007e4af17cfc8c  vmovaps [rsp+0xF0], xmm1
00007e4af17cfc95  vmovaps xmm1, [rsp+0x30]
00007e4af17cfc9b  vmovaps [rsp+0x30], xmm14
00007e4af17cfca1  movaps xmm15, xmm11
00007e4af17cfca5  addpd xmm15, xmm1
00007e4af17cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007e4af17cfcb0  ptest xmm14, xmm14
00007e4af17cfcb6  jnz 0x00007E4AF17D250A
00007e4af17cfcbc  vmovaps [rsp+0x100], xmm9
00007e4af17cfcc5  vmovaps xmm1, [rsp+0x100]
00007e4af17cfcce  por xmm9, xmm1
00007e4af17cfcd3  movaps [r15+0x270], xmm9
00007e4af17cfcdb  vmovaps [rsp+0x100], xmm6
00007e4af17cfce4  vmovaps xmm1, [rsp+0x100]
00007e4af17cfced  por xmm6, xmm1
00007e4af17cfcf1  movaps [r15+0x1A0], xmm6
00007e4af17cfcf9  vmovaps xmm14, [rsp+0xB0]
00007e4af17cfd02  vpermilpd xmm14, xmm14, 0x00
00007e4af17cfd08  vmovaps xmm6, [rsp+0xF0]
00007e4af17cfd11  vmovaps [rsp+0xF0], xmm1
00007e4af17cfd1a  movaps xmm11, xmm6
00007e4af17cfd1e  mulpd xmm11, xmm14
00007e4af17cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007e4af17cfd29  ptest xmm1, xmm1
00007e4af17cfd2e  jnz 0x00007E4AF17D264D
00007e4af17cfd34  lea rax, [r14+0x20]
00007e4af17cfd38  movups xmm1, [r13+rax*1]
00007e4af17cfd3e  movaps [r15+0x110], xmm1
00007e4af17cfd46  vmovaps xmm6, [rsp+0xE0]
00007e4af17cfd4f  vmovaps [rsp+0xE0], xmm1
00007e4af17cfd58  movaps xmm14, xmm6
00007e4af17cfd5c  addpd xmm14, xmm2
00007e4af17cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007e4af17cfd67  ptest xmm1, xmm1
00007e4af17cfd6c  jnz 0x00007E4AF17D279A
00007e4af17cfd72  vmovaps xmm1, [rsp+0xB0]
00007e4af17cfd7b  vpermilpd xmm1, xmm1, 0x00
00007e4af17cfd81  movaps xmm6, xmm5
00007e4af17cfd84  mulpd xmm6, xmm1
00007e4af17cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007e4af17cfd8d  ptest xmm2, xmm2
00007e4af17cfd92  jnz 0x00007E4AF17D28DC
00007e4af17cfd98  vmovaps xmm5, [rsp+0x20]
00007e4af17cfd9e  movaps xmm1, xmm5
00007e4af17cfda1  addpd xmm1, xmm13
00007e4af17cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007e4af17cfdab  ptest xmm2, xmm2
00007e4af17cfdb0  jnz 0x00007E4AF17D2A1C
00007e4af17cfdb6  vmovaps xmm13, [rsp+0x80]
00007e4af17cfdbf  vpermilpd xmm13, xmm13, 0x00
00007e4af17cfdc5  vmovaps xmm2, [rsp+0xE0]
00007e4af17cfdce  vmovaps [rsp+0x20], xmm1
00007e4af17cfdd4  movaps xmm5, xmm2
00007e4af17cfdd7  mulpd xmm5, xmm13
00007e4af17cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007e4af17cfde1  ptest xmm1, xmm1
00007e4af17cfde6  jnz 0x00007E4AF17D2B5D
00007e4af17cfdec  vmovaps xmm1, [rsp+0x80]
00007e4af17cfdf5  vpermilpd xmm1, xmm1, 0x00
00007e4af17cfdfb  movaps xmm13, xmm10
00007e4af17cfdff  mulpd xmm13, xmm1
00007e4af17cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007e4af17cfe0a  ptest xmm2, xmm2
00007e4af17cfe0f  jnz 0x00007E4AF17D2C9E
00007e4af17cfe15  vmovaps xmm10, [rsp+0x30]
00007e4af17cfe1b  movaps xmm1, xmm15
00007e4af17cfe1f  addpd xmm1, xmm10
00007e4af17cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007e4af17cfe29  ptest xmm2, xmm2
00007e4af17cfe2e  jnz 0x00007E4AF17D2DE1
00007e4af17cfe34  vmovaps xmm10, [rsp+0xC0]
00007e4af17cfe3d  movaps xmm15, xmm10
00007e4af17cfe41  addpd xmm15, xmm11
00007e4af17cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007e4af17cfe4c  ptest xmm2, xmm2
00007e4af17cfe51  jnz 0x00007E4AF17D2F23
00007e4af17cfe57  vmovaps xmm11, [rsp+0x80]
00007e4af17cfe60  vpermilpd xmm11, xmm11, 0x00
00007e4af17cfe66  movaps xmm10, xmm12
00007e4af17cfe6a  mulpd xmm10, xmm11
00007e4af17cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007e4af17cfe75  ptest xmm2, xmm2
00007e4af17cfe7a  jnz 0x00007E4AF17D3067
00007e4af17cfe80  vmovaps xmm12, [rsp+0x80]
00007e4af17cfe89  vpermilpd xmm12, xmm12, 0x00
00007e4af17cfe8f  vmovaps xmm2, [rsp+0xA0]
00007e4af17cfe98  vmovaps [rsp+0x30], xmm1
00007e4af17cfe9e  movaps xmm11, xmm2
00007e4af17cfea2  mulpd xmm11, xmm12
00007e4af17cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007e4af17cfead  ptest xmm1, xmm1
00007e4af17cfeb2  jnz 0x00007E4AF17D31AB
00007e4af17cfeb8  movaps xmm1, xmm14
00007e4af17cfebc  addpd xmm1, xmm6
00007e4af17cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007e4af17cfec5  ptest xmm12, xmm12
00007e4af17cfecb  jnz 0x00007E4AF17D32EE
00007e4af17cfed1  vmovaps xmm12, [rsp+0x20]
00007e4af17cfed7  movaps xmm14, xmm12
00007e4af17cfedb  addpd xmm14, xmm5
00007e4af17cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007e4af17cfee6  ptest xmm6, xmm6
00007e4af17cfeeb  jnz 0x00007E4AF17D342F
00007e4af17cfef1  vmovaps xmm12, [rsp+0x90]
00007e4af17cfefa  vpermilpd xmm12, xmm12, 0x00
00007e4af17cff00  movaps xmm6, xmm9
00007e4af17cff04  mulpd xmm6, xmm12
00007e4af17cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007e4af17cff0e  ptest xmm5, xmm5
00007e4af17cff13  jnz 0x00007E4AF17D3572
00007e4af17cff19  movaps xmm12, xmm15
00007e4af17cff1d  addpd xmm12, xmm13
00007e4af17cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007e4af17cff28  ptest xmm9, xmm9
00007e4af17cff2e  jnz 0x00007E4AF17D36B4
00007e4af17cff34  vmovaps xmm13, [rsp+0x30]
00007e4af17cff3a  movaps xmm15, xmm13
00007e4af17cff3e  addpd xmm15, xmm10
00007e4af17cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007e4af17cff49  ptest xmm9, xmm9
00007e4af17cff4f  jnz 0x00007E4AF17D37F8
00007e4af17cff55  vmovaps xmm13, [rsp+0xD0]
00007e4af17cff5e  vmovaps xmm10, [rsp+0xD0]
00007e4af17cff67  por xmm13, xmm10
00007e4af17cff6c  movaps [r15+0x250], xmm13
00007e4af17cff74  vmovaps [rsp+0x20], xmm7
00007e4af17cff7a  vmovaps xmm13, [rsp+0x20]
00007e4af17cff80  por xmm7, xmm13
00007e4af17cff85  movaps [r15+0x2A0], xmm7
00007e4af17cff8d  vmovaps [rsp+0x20], xmm3
00007e4af17cff93  vmovaps xmm13, [rsp+0x20]
00007e4af17cff99  por xmm3, xmm13
00007e4af17cff9e  movaps [r15+0x1D0], xmm3
00007e4af17cffa6  lea rax, [r14+0x40]
00007e4af17cffaa  movups xmm13, [r13+rax*1]
00007e4af17cffb0  movaps [r15+0x2C0], xmm13
00007e4af17cffb8  vmovaps xmm10, [rsp+0x90]
00007e4af17cffc1  vpermilpd xmm10, xmm10, 0x00
00007e4af17cffc7  movaps xmm9, xmm8
00007e4af17cffcb  mulpd xmm9, xmm10
00007e4af17cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007e4af17cffd6  ptest xmm5, xmm5
00007e4af17cffdb  jnz 0x00007E4AF17D3946
00007e4af17cffe1  movaps xmm10, xmm1
00007e4af17cffe5  addpd xmm10, xmm11
00007e4af17cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007e4af17cfff0  ptest xmm8, xmm8
00007e4af17cfff6  jnz 0x00007E4AF17D3A8A
00007e4af17cfffc  movaps xmm1, xmm14
00007e4af17d0000  addpd xmm1, xmm6
00007e4af17d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007e4af17d0009  ptest xmm11, xmm11
00007e4af17d000f  jnz 0x00007E4AF17D3BCD
00007e4af17d0015  vmovaps xmm14, [rsp+0x90]
00007e4af17d001e  vpermilpd xmm14, xmm14, 0x00
00007e4af17d0024  movaps xmm11, xmm13
00007e4af17d0028  mulpd xmm11, xmm14
00007e4af17d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007e4af17d0033  ptest xmm8, xmm8
00007e4af17d0039  jnz 0x00007E4AF17D3D0E
00007e4af17d003f  vmovaps xmm14, [rsp+0x90]
00007e4af17d0048  vpermilpd xmm14, xmm14, 0x00
00007e4af17d004e  vmovaps xmm8, [rsp+0x10]
00007e4af17d0054  movaps xmm13, xmm8
00007e4af17d0058  mulpd xmm13, xmm14
00007e4af17d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007e4af17d0063  ptest xmm6, xmm6
00007e4af17d0068  jnz 0x00007E4AF17D3E52
00007e4af17d006e  vmovaps xmm14, [rsp+0x60]
00007e4af17d0074  vpermilpd xmm14, xmm14, 0x00
00007e4af17d007a  movaps xmm8, xmm7
00007e4af17d007e  mulpd xmm8, xmm14
00007e4af17d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007e4af17d0089  ptest xmm6, xmm6
00007e4af17d008e  jnz 0x00007E4AF17D3F96
00007e4af17d0094  movaps xmm14, xmm12
00007e4af17d0098  addpd xmm14, xmm9
00007e4af17d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007e4af17d00a3  ptest xmm7, xmm7
00007e4af17d00a8  jnz 0x00007E4AF17D40D9
00007e4af17d00ae  vmovaps xmm12, [rsp+0x60]
00007e4af17d00b4  vpermilpd xmm12, xmm12, 0x00
00007e4af17d00ba  vmovaps xmm7, [rsp+0xF0]
00007e4af17d00c3  movaps xmm9, xmm7
00007e4af17d00c7  mulpd xmm9, xmm12
00007e4af17d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007e4af17d00d2  ptest xmm6, xmm6
00007e4af17d00d7  jnz 0x00007E4AF17D421D
00007e4af17d00dd  movaps xmm12, xmm15
00007e4af17d00e1  addpd xmm12, xmm11
00007e4af17d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007e4af17d00ec  ptest xmm7, xmm7
00007e4af17d00f1  jnz 0x00007E4AF17D4360
00007e4af17d00f7  vmovaps xmm15, [rsp+0x60]
00007e4af17d00fd  vpermilpd xmm15, xmm15, 0x00
00007e4af17d0103  vmovaps xmm7, [rsp+0x40]
00007e4af17d0109  movaps xmm11, xmm7
00007e4af17d010d  mulpd xmm11, xmm15
00007e4af17d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007e4af17d0118  ptest xmm6, xmm6
00007e4af17d011d  jnz 0x00007E4AF17D44A4
00007e4af17d0123  movaps xmm15, xmm10
00007e4af17d0127  addpd xmm15, xmm13
00007e4af17d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007e4af17d0132  ptest xmm7, xmm7
00007e4af17d0137  jnz 0x00007E4AF17D45E7
00007e4af17d013d  vmovaps xmm13, [rsp+0x60]
00007e4af17d0143  vpermilpd xmm13, xmm13, 0x00
00007e4af17d0149  vmovaps xmm7, [rsp+0x50]
00007e4af17d014f  movaps xmm10, xmm7
00007e4af17d0153  mulpd xmm10, xmm13
00007e4af17d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007e4af17d015e  ptest xmm6, xmm6
00007e4af17d0163  jnz 0x00007E4AF17D472B
00007e4af17d0169  movaps xmm13, xmm1
00007e4af17d016d  addpd xmm13, xmm8
00007e4af17d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007e4af17d0178  ptest xmm7, xmm7
00007e4af17d017d  jnz 0x00007E4AF17D486E
00007e4af17d0183  lea rax, [r14+0x70]
00007e4af17d0187  movups xmm1, [r13+rax*1]
00007e4af17d018d  movaps [r15+0x240], xmm1
00007e4af17d0195  movaps xmm8, xmm14
00007e4af17d0199  addpd xmm8, xmm9
00007e4af17d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007e4af17d01a4  ptest xmm7, xmm7
00007e4af17d01a9  jnz 0x00007E4AF17D49BB
00007e4af17d01af  movaps [r15+0x170], xmm8
00007e4af17d01b7  vmovaps xmm14, [rsp+0x70]
00007e4af17d01bd  vpermilpd xmm14, xmm14, 0x00
00007e4af17d01c3  movaps xmm9, xmm1
00007e4af17d01c7  mulpd xmm9, xmm14
00007e4af17d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007e4af17d01d2  ptest xmm7, xmm7
00007e4af17d01d7  jnz 0x00007E4AF17D4AFF
00007e4af17d01dd  vmovaps xmm1, [rsp+0x70]
00007e4af17d01e3  vpermilpd xmm1, xmm1, 0x00
00007e4af17d01e9  movaps xmm14, xmm4
00007e4af17d01ed  mulpd xmm14, xmm1
00007e4af17d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007e4af17d01f8  ptest xmm7, xmm7
00007e4af17d01fd  jnz 0x00007E4AF17D4C42
00007e4af17d0203  movaps [r15+0x180], xmm14
00007e4af17d020b  movaps xmm1, xmm12
00007e4af17d020f  addpd xmm1, xmm11
00007e4af17d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007e4af17d0219  ptest xmm7, xmm7
00007e4af17d021e  jnz 0x00007E4AF17D4D84
00007e4af17d0224  movaps [r15+0x210], xmm1
00007e4af17d022c  movups xmm12, [r13+r14*1]
00007e4af17d0232  lea rax, [r14+0x10]
00007e4af17d0236  movups xmm11, [r13+rax*1]
00007e4af17d023c  movaps [r15+0x230], xmm11
00007e4af17d0244  movaps xmm7, xmm15
00007e4af17d0248  addpd xmm7, xmm10
00007e4af17d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007e4af17d0252  ptest xmm6, xmm6
00007e4af17d0257  jnz 0x00007E4AF17D4EDA
00007e4af17d025d  movaps [r15+0x130], xmm7
00007e4af17d0265  vmovaps xmm15, [rsp+0x70]
00007e4af17d026b  vpermilpd xmm15, xmm15, 0x00
00007e4af17d0271  movaps xmm10, xmm11
00007e4af17d0275  mulpd xmm10, xmm15
00007e4af17d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007e4af17d0280  ptest xmm6, xmm6
00007e4af17d0285  jnz 0x00007E4AF17D501C
00007e4af17d028b  movaps [r15+0x220], xmm10
00007e4af17d0293  vmovaps xmm15, [rsp+0x70]
00007e4af17d0299  vpermilpd xmm15, xmm15, 0x00
00007e4af17d029f  movaps xmm11, xmm12
00007e4af17d02a3  mulpd xmm11, xmm15
00007e4af17d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007e4af17d02ae  ptest xmm6, xmm6
00007e4af17d02b3  jnz 0x00007E4AF17D5160
00007e4af17d02b9  movaps xmm15, xmm13
00007e4af17d02bd  addpd xmm15, xmm9
00007e4af17d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007e4af17d02c8  ptest xmm12, xmm12
00007e4af17d02ce  jnz 0x00007E4AF17D52A4
00007e4af17d02d4  movaps [r15+0x140], xmm15
00007e4af17d02dc  movaps xmm13, xmm8
00007e4af17d02e0  addpd xmm13, xmm14
00007e4af17d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007e4af17d02eb  ptest xmm12, xmm12
00007e4af17d02f1  jnz 0x00007E4AF17D53E8
00007e4af17d02f7  movaps [r15+0x150], xmm13
00007e4af17d02ff  movaps xmm14, xmm1
00007e4af17d0303  addpd xmm14, xmm10
00007e4af17d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007e4af17d030e  ptest xmm12, xmm12
00007e4af17d0314  jnz 0x00007E4AF17D552C
00007e4af17d031a  movaps [r15+0x160], xmm14
00007e4af17d0322  movaps xmm1, xmm7
00007e4af17d0325  addpd xmm1, xmm11
00007e4af17d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007e4af17d032f  ptest xmm12, xmm12
00007e4af17d0335  jnz 0x00007E4AF17D566F
00007e4af17d033b  movaps [r15+0x120], xmm1
00007e4af17d0343  mov eax, 0x430920
00007e4af17d0348  movups [r13+rax*1], xmm15
00007e4af17d034e  mov eax, 0x430930
00007e4af17d0353  movups [r13+rax*1], xmm13
00007e4af17d0359  mov eax, 0x430940
00007e4af17d035e  movups [r13+rax*1], xmm14
00007e4af17d0364  mov eax, 0x430950
00007e4af17d0369  movups [r13+rax*1], xmm1
00007e4af17d036f  mov eax, [r15+0x108]
00007e4af17d0376  sahf
00007e4af17d0377  jnz 0x00007E4AF17D03A9
00007e4af17d0379  cmp dword ptr [r15+0x318], 0x00
00007e4af17d0381  jz 0x00007E4AF17DB900
00007e4af17d0387  nop [rax+rax*1], ax
00007e4af17d0390  nop [rax+rax*1], eax
00007e4af17d0398  mov eax, 0x410444
00007e4af17d039d  mov [r15+0x100], rax
00007e4af17d03a4  jmp 0x00007E4AF15FE110
00007e4af17d03a9  cmp dword ptr [r15+0x318], 0x00
00007e4af17d03b1  jz 0x00007E4AF17D57E0
00007e4af17d03b7  nop [rax+rax*1], ax
00007e4af17d03c0  nop [rax+rax*1], eax
00007e4af17d03c8  mov eax, 0x410278
00007e4af17d03cd  mov [r15+0x100], rax
00007e4af17d03d4  jmp 0x00007E4AF15FE110
00007e4af17d03d9  int3
00007e4af17d03da  call 0x00007E4AF16B52F0
00007e4af17d03df  jmp 0x00007E4AF17CF016
00007e4af17d03e4  call 0x00007E4AF16C4620
00007e4af17d03e9  jmp 0x00007E4AF17CF023
00007e4af17d03ee  call 0x00007E4AF16C33A0
00007e4af17d03f3  jmp 0x00007E4AF17CF035
00007e4af17d03f8  call 0x00007E4AF16C2120
00007e4af17d03fd  jmp 0x00007E4AF17CF03F
00007e4af17d0402  call 0x00007E4AF16C0860
00007e4af17d0407  jmp 0x00007E4AF17CF067
00007e4af17d040c  call 0x00007E4AF16BF5F0
00007e4af17d0411  jmp 0x00007E4AF17CF073
00007e4af17d0416  call 0x00007E4AF16C0860
00007e4af17d041b  jmp 0x00007E4AF17CF0A5
00007e4af17d0420  call 0x00007E4AF16BF5F0
00007e4af17d0425  jmp 0x00007E4AF17CF0B1
00007e4af17d042a  call 0x00007E4AF16C4740
00007e4af17d042f  jmp 0x00007E4AF17CF0BE
00007e4af17d0434  call 0x00007E4AF16B5400
00007e4af17d0439  jmp 0x00007E4AF17CF0CB
00007e4af17d043e  call 0x00007E4AF16B52F0
00007e4af17d0443  jmp 0x00007E4AF17CF0D8
00007e4af17d0448  call 0x00007E4AF16C4620
00007e4af17d044d  jmp 0x00007E4AF17CF0E5
00007e4af17d0452  call 0x00007E4AF16C0860
00007e4af17d0457  jmp 0x00007E4AF17CF10D
00007e4af17d045c  call 0x00007E4AF16BF5F0
00007e4af17d0461  jmp 0x00007E4AF17CF119
00007e4af17d0466  call 0x00007E4AF1609D70
00007e4af17d046b  jmp 0x00007E4AF17CF11F
00007e4af17d0470  call 0x00007E4AF16BE9C0
00007e4af17d0475  jmp 0x00007E4AF17CF129
00007e4af17d047a  call 0x00007E4AF16C0860
00007e4af17d047f  jmp 0x00007E4AF17CF151
00007e4af17d0484  call 0x00007E4AF16BF5F0
00007e4af17d0489  jmp 0x00007E4AF17CF15D
00007e4af17d048e  call 0x00007E4AF16BD750
00007e4af17d0493  jmp 0x00007E4AF17CF16A
00007e4af17d0498  call 0x00007E4AF16BC4E0
00007e4af17d049d  jmp 0x00007E4AF17CF177
00007e4af17d04a2  call 0x00007E4AF16C4740
00007e4af17d04a7  jmp 0x00007E4AF17CF184
00007e4af17d04ac  call 0x00007E4AF16B5400
00007e4af17d04b1  jmp 0x00007E4AF17CF191
00007e4af17d04b6  call 0x00007E4AF16B52F0
00007e4af17d04bb  jmp 0x00007E4AF17CF19E
00007e4af17d04c0  call 0x00007E4AF16C4620
00007e4af17d04c5  jmp 0x00007E4AF17CF1AB
00007e4af17d04ca  call 0x00007E4AF16C0860
00007e4af17d04cf  jmp 0x00007E4AF17CF1BE
00007e4af17d04d4  call 0x00007E4AF16BB270
00007e4af17d04d9  jmp 0x00007E4AF17CF1CB
00007e4af17d04de  call 0x00007E4AF16BA000
00007e4af17d04e3  jmp 0x00007E4AF17CF1D8
00007e4af17d04e8  call 0x00007E4AF16B8D90
00007e4af17d04ed  jmp 0x00007E4AF17CF1E5
00007e4af17d04f2  call 0x00007E4AF16B8A20
00007e4af17d04f7  jmp 0x00007E4AF17CF1F2
00007e4af17d04fc  call 0x00007E4AF16B5400
00007e4af17d0501  jmp 0x00007E4AF17CF1FC
00007e4af17d0506  call 0x00007E4AF16C2240
00007e4af17d050b  jmp 0x00007E4AF17CF206
00007e4af17d0510  call 0x00007E4AF16B52F0
00007e4af17d0515  jmp 0x00007E4AF17CF210
00007e4af17d051a  call 0x00007E4AF16C2120
00007e4af17d051f  jmp 0x00007E4AF17CF21A
00007e4af17d0524  call 0x00007E4AF16B77B0
00007e4af17d0529  jmp 0x00007E4AF17CF224
00007e4af17d052e  call 0x00007E4AF16B6550
00007e4af17d0533  jmp 0x00007E4AF17CF22E
00007e4af17d0538  call 0x00007E4AF16BFD50
00007e4af17d053d  jmp 0x00007E4AF17CF240
00007e4af17d0542  call 0x00007E4AF16B8EA0
00007e4af17d0547  jmp 0x00007E4AF17CF24A
00007e4af17d054c  call 0x00007E4AF16BFC30
00007e4af17d0551  jmp 0x00007E4AF17CF257
00007e4af17d0556  call 0x00007E4AF16B8D90
00007e4af17d055b  jmp 0x00007E4AF17CF264
00007e4af17d0560  call 0x00007E4AF16C2240
00007e4af17d0565  jmp 0x00007E4AF17CF271
00007e4af17d056a  call 0x00007E4AF16B5400
00007e4af17d056f  jmp 0x00007E4AF17CF27E
00007e4af17d0574  call 0x00007E4AF16B52F0
00007e4af17d0579  jmp 0x00007E4AF17CF28B
00007e4af17d057e  call 0x00007E4AF16C2120
00007e4af17d0583  jmp 0x00007E4AF17CF298
00007e4af17d0588  call 0x00007E4AF16B52F0
00007e4af17d058d  jmp 0x00007E4AF17CF2AB
00007e4af17d0592  call 0x00007E4AF16B52F0
00007e4af17d0597  jmp 0x00007E4AF17CF2BE
00007e4af17d059c  call 0x00007E4AF16B52F0
00007e4af17d05a1  jmp 0x00007E4AF17CF2D1
00007e4af17d05a6  call 0x00007E4AF16B52F0
00007e4af17d05ab  jmp 0x00007E4AF17CF2E4
00007e4af17d05b0  call 0x00007E4AF16C2240
00007e4af17d05b5  jmp 0x00007E4AF17CF2F9
00007e4af17d05ba  call 0x00007E4AF16C2240
00007e4af17d05bf  jmp 0x00007E4AF17CF30C
00007e4af17d05c4  call 0x00007E4AF16C2120
00007e4af17d05c9  jmp 0x00007E4AF17CF319
00007e4af17d05ce  call 0x00007E4AF16B52F0
00007e4af17d05d3  jmp 0x00007E4AF17CF32C
00007e4af17d05d8  call 0x00007E4AF16B52F0
00007e4af17d05dd  jmp 0x00007E4AF17CF34F
00007e4af17d05e2  call 0x00007E4AF16B52F0
00007e4af17d05e7  jmp 0x00007E4AF17CF362
00007e4af17d05ec  call 0x00007E4AF15FF540
00007e4af17d05f1  jmp 0x00007E4AF17CF380
00007e4af17d05f6  call 0x00007E4AF1608C20
00007e4af17d05fb  jmp 0x00007E4AF17CF38A
00007e4af17d0600  call 0x00007E4AF16D6600
00007e4af17d0605  jmp 0x00007E4AF17CF396
00007e4af17d060a  call 0x00007E4AF15FF540
00007e4af17d060f  jmp 0x00007E4AF17CF3A6
00007e4af17d0614  call 0x00007E4AF16C0370
00007e4af17d0619  jmp 0x00007E4AF17CF3D4
00007e4af17d061e  call 0x00007E4AF16BF100
00007e4af17d0623  jmp 0x00007E4AF17CF3DD
00007e4af17d0628  call 0x00007E4AF16C0370
00007e4af17d062d  jmp 0x00007E4AF17CF43B
00007e4af17d0632  call 0x00007E4AF16BF100
00007e4af17d0637  jmp 0x00007E4AF17CF444
00007e4af17d063c  call 0x00007E4AF16C0370
00007e4af17d0641  jmp 0x00007E4AF17CF48B
00007e4af17d0646  call 0x00007E4AF16BF100
00007e4af17d064b  jmp 0x00007E4AF17CF494
00007e4af17d0650  call 0x00007E4AF160B720
00007e4af17d0655  jmp 0x00007E4AF17CF4D7
00007e4af17d065a  call 0x00007E4AF16B47C0
00007e4af17d065f  jmp 0x00007E4AF17CF4EA
00007e4af17d0664  call 0x00007E4AF1608B00
00007e4af17d0669  jmp 0x00007E4AF17CF501
00007e4af17d066e  call 0x00007E4AF15FF430
00007e4af17d0673  jmp 0x00007E4AF17CF514
00007e4af17d0678  call 0x00007E4AF15FF430
00007e4af17d067d  jmp 0x00007E4AF17CF527
00007e4af17d0682  sub rsp, 0x08
00007e4af17d0686  push rax
00007e4af17d0687  push rcx
00007e4af17d0688  push rdx
00007e4af17d0689  push rdi
00007e4af17d068a  push rsi
00007e4af17d068b  push r8
00007e4af17d068d  push r9
00007e4af17d068f  push r10
00007e4af17d0691  push r11
00007e4af17d0693  sub rsp, 0xF0
00007e4af17d069a  vmovaps [rsp], xmm0
00007e4af17d069f  vmovaps [rsp+0x10], xmm2
00007e4af17d06a5  vmovaps [rsp+0x20], xmm3
00007e4af17d06ab  vmovaps [rsp+0x30], xmm4
00007e4af17d06b1  vmovaps [rsp+0x40], xmm5
00007e4af17d06b7  vmovaps [rsp+0x50], xmm6
00007e4af17d06bd  vmovaps [rsp+0x60], xmm7
00007e4af17d06c3  vmovaps [rsp+0x70], xmm8
00007e4af17d06c9  vmovaps [rsp+0x80], xmm9
00007e4af17d06d2  vmovaps [rsp+0x90], xmm10
00007e4af17d06db  vmovaps [rsp+0xA0], xmm11
00007e4af17d06e4  vmovaps [rsp+0xB0], xmm12
00007e4af17d06ed  vmovaps [rsp+0xC0], xmm13
00007e4af17d06f6  vmovaps [rsp+0xD0], xmm14
00007e4af17d06ff  vmovaps [rsp+0xE0], xmm15
00007e4af17d0708  sub rsp, 0x30
00007e4af17d070c  movaps [rsp], xmm1
00007e4af17d0710  movaps [rsp+0x10], xmm15
00007e4af17d0716  movaps [rsp+0x20], xmm14
00007e4af17d071c  lea rdi, [rsp]
00007e4af17d0720  mov esi, 0x00
00007e4af17d0725  mov rax, 0x6256754A7530
00007e4af17d072f  call rax
00007e4af17d0731  movaps xmm1, [rsp]
00007e4af17d0735  add rsp, 0x30
00007e4af17d0739  vmovaps xmm0, [rsp]
00007e4af17d073e  vmovaps xmm2, [rsp+0x10]
00007e4af17d0744  vmovaps xmm3, [rsp+0x20]
00007e4af17d074a  vmovaps xmm4, [rsp+0x30]
00007e4af17d0750  vmovaps xmm5, [rsp+0x40]
00007e4af17d0756  vmovaps xmm6, [rsp+0x50]
00007e4af17d075c  vmovaps xmm7, [rsp+0x60]
00007e4af17d0762  vmovaps xmm8, [rsp+0x70]
00007e4af17d0768  vmovaps xmm9, [rsp+0x80]
00007e4af17d0771  vmovaps xmm10, [rsp+0x90]
00007e4af17d077a  vmovaps xmm11, [rsp+0xA0]
00007e4af17d0783  vmovaps xmm12, [rsp+0xB0]
00007e4af17d078c  vmovaps xmm13, [rsp+0xC0]
00007e4af17d0795  vmovaps xmm14, [rsp+0xD0]
00007e4af17d079e  vmovaps xmm15, [rsp+0xE0]
00007e4af17d07a7  add rsp, 0xF0
00007e4af17d07ae  pop r11
00007e4af17d07b0  pop r10
00007e4af17d07b2  pop r9
00007e4af17d07b4  pop r8
00007e4af17d07b6  pop rsi
00007e4af17d07b7  pop rdi
00007e4af17d07b8  pop rdx
00007e4af17d07b9  pop rcx
00007e4af17d07ba  pop rax
00007e4af17d07bb  add rsp, 0x08
00007e4af17d07bf  jmp 0x00007E4AF17CF581
00007e4af17d07c4  sub rsp, 0x08
00007e4af17d07c8  push rax
00007e4af17d07c9  push rcx
00007e4af17d07ca  push rdx
00007e4af17d07cb  push rdi
00007e4af17d07cc  push rsi
00007e4af17d07cd  push r8
00007e4af17d07cf  push r9
00007e4af17d07d1  push r10
00007e4af17d07d3  push r11
00007e4af17d07d5  sub rsp, 0xF0
00007e4af17d07dc  vmovaps [rsp], xmm0
00007e4af17d07e1  vmovaps [rsp+0x10], xmm1
00007e4af17d07e7  vmovaps [rsp+0x20], xmm2
00007e4af17d07ed  vmovaps [rsp+0x30], xmm3
00007e4af17d07f3  vmovaps [rsp+0x40], xmm4
00007e4af17d07f9  vmovaps [rsp+0x50], xmm5
00007e4af17d07ff  vmovaps [rsp+0x60], xmm6
00007e4af17d0805  vmovaps [rsp+0x70], xmm7
00007e4af17d080b  vmovaps [rsp+0x80], xmm8
00007e4af17d0814  vmovaps [rsp+0x90], xmm9
00007e4af17d081d  vmovaps [rsp+0xA0], xmm10
00007e4af17d0826  vmovaps [rsp+0xB0], xmm11
00007e4af17d082f  vmovaps [rsp+0xC0], xmm12
00007e4af17d0838  vmovaps [rsp+0xD0], xmm14
00007e4af17d0841  vmovaps [rsp+0xE0], xmm15
00007e4af17d084a  sub rsp, 0x30
00007e4af17d084e  movaps [rsp], xmm13
00007e4af17d0853  movaps [rsp+0x10], xmm1
00007e4af17d0858  movaps [rsp+0x20], xmm14
00007e4af17d085e  lea rdi, [rsp]
00007e4af17d0862  mov esi, 0x00
00007e4af17d0867  mov rax, 0x6256754A7530
00007e4af17d0871  call rax
00007e4af17d0873  movaps xmm13, [rsp]
00007e4af17d0878  add rsp, 0x30
00007e4af17d087c  vmovaps xmm0, [rsp]
00007e4af17d0881  vmovaps xmm1, [rsp+0x10]
00007e4af17d0887  vmovaps xmm2, [rsp+0x20]
00007e4af17d088d  vmovaps xmm3, [rsp+0x30]
00007e4af17d0893  vmovaps xmm4, [rsp+0x40]
00007e4af17d0899  vmovaps xmm5, [rsp+0x50]
00007e4af17d089f  vmovaps xmm6, [rsp+0x60]
00007e4af17d08a5  vmovaps xmm7, [rsp+0x70]
00007e4af17d08ab  vmovaps xmm8, [rsp+0x80]
00007e4af17d08b4  vmovaps xmm9, [rsp+0x90]
00007e4af17d08bd  vmovaps xmm10, [rsp+0xA0]
00007e4af17d08c6  vmovaps xmm11, [rsp+0xB0]
00007e4af17d08cf  vmovaps xmm12, [rsp+0xC0]
00007e4af17d08d8  vmovaps xmm14, [rsp+0xD0]
00007e4af17d08e1  vmovaps xmm15, [rsp+0xE0]
00007e4af17d08ea  add rsp, 0xF0
00007e4af17d08f1  pop r11
00007e4af17d08f3  pop r10
00007e4af17d08f5  pop r9
00007e4af17d08f7  pop r8
00007e4af17d08f9  pop rsi
00007e4af17d08fa  pop rdi
00007e4af17d08fb  pop rdx
00007e4af17d08fc  pop rcx
00007e4af17d08fd  pop rax
00007e4af17d08fe  add rsp, 0x08
00007e4af17d0902  jmp 0x00007E4AF17CF5CF
00007e4af17d0907  sub rsp, 0x08
00007e4af17d090b  push rax
00007e4af17d090c  push rcx
00007e4af17d090d  push rdx
00007e4af17d090e  push rdi
00007e4af17d090f  push rsi
00007e4af17d0910  push r8
00007e4af17d0912  push r9
00007e4af17d0914  push r10
00007e4af17d0916  push r11
00007e4af17d0918  sub rsp, 0xF0
00007e4af17d091f  vmovaps [rsp], xmm0
00007e4af17d0924  vmovaps [rsp+0x10], xmm1
00007e4af17d092a  vmovaps [rsp+0x20], xmm2
00007e4af17d0930  vmovaps [rsp+0x30], xmm3
00007e4af17d0936  vmovaps [rsp+0x40], xmm4
00007e4af17d093c  vmovaps [rsp+0x50], xmm5
00007e4af17d0942  vmovaps [rsp+0x60], xmm6
00007e4af17d0948  vmovaps [rsp+0x70], xmm7
00007e4af17d094e  vmovaps [rsp+0x80], xmm8
00007e4af17d0957  vmovaps [rsp+0x90], xmm9
00007e4af17d0960  vmovaps [rsp+0xA0], xmm10
00007e4af17d0969  vmovaps [rsp+0xB0], xmm11
00007e4af17d0972  vmovaps [rsp+0xC0], xmm12
00007e4af17d097b  vmovaps [rsp+0xD0], xmm13
00007e4af17d0984  vmovaps [rsp+0xE0], xmm14
00007e4af17d098d  sub rsp, 0x30
00007e4af17d0991  movaps [rsp], xmm15
00007e4af17d0996  movaps [rsp+0x10], xmm14
00007e4af17d099c  movaps [rsp+0x20], xmm1
00007e4af17d09a1  lea rdi, [rsp]
00007e4af17d09a5  mov esi, 0x00
00007e4af17d09aa  mov rax, 0x6256754A7530
00007e4af17d09b4  call rax
00007e4af17d09b6  movaps xmm15, [rsp]
00007e4af17d09bb  add rsp, 0x30
00007e4af17d09bf  vmovaps xmm0, [rsp]
00007e4af17d09c4  vmovaps xmm1, [rsp+0x10]
00007e4af17d09ca  vmovaps xmm2, [rsp+0x20]
00007e4af17d09d0  vmovaps xmm3, [rsp+0x30]
00007e4af17d09d6  vmovaps xmm4, [rsp+0x40]
00007e4af17d09dc  vmovaps xmm5, [rsp+0x50]
00007e4af17d09e2  vmovaps xmm6, [rsp+0x60]
00007e4af17d09e8  vmovaps xmm7, [rsp+0x70]
00007e4af17d09ee  vmovaps xmm8, [rsp+0x80]
00007e4af17d09f7  vmovaps xmm9, [rsp+0x90]
00007e4af17d0a00  vmovaps xmm10, [rsp+0xA0]
00007e4af17d0a09  vmovaps xmm11, [rsp+0xB0]
00007e4af17d0a12  vmovaps xmm12, [rsp+0xC0]
00007e4af17d0a1b  vmovaps xmm13, [rsp+0xD0]
00007e4af17d0a24  vmovaps xmm14, [rsp+0xE0]
00007e4af17d0a2d  add rsp, 0xF0
00007e4af17d0a34  pop r11
00007e4af17d0a36  pop r10
00007e4af17d0a38  pop r9
00007e4af17d0a3a  pop r8
00007e4af17d0a3c  pop rsi
00007e4af17d0a3d  pop rdi
00007e4af17d0a3e  pop rdx
00007e4af17d0a3f  pop rcx
00007e4af17d0a40  pop rax
00007e4af17d0a41  add rsp, 0x08
00007e4af17d0a45  jmp 0x00007E4AF17CF617
00007e4af17d0a4a  sub rsp, 0x08
00007e4af17d0a4e  push rax
00007e4af17d0a4f  push rcx
00007e4af17d0a50  push rdx
00007e4af17d0a51  push rdi
00007e4af17d0a52  push rsi
00007e4af17d0a53  push r8
00007e4af17d0a55  push r9
00007e4af17d0a57  push r10
00007e4af17d0a59  push r11
00007e4af17d0a5b  sub rsp, 0xF0
00007e4af17d0a62  vmovaps [rsp], xmm0
00007e4af17d0a67  vmovaps [rsp+0x10], xmm2
00007e4af17d0a6d  vmovaps [rsp+0x20], xmm3
00007e4af17d0a73  vmovaps [rsp+0x30], xmm4
00007e4af17d0a79  vmovaps [rsp+0x40], xmm5
00007e4af17d0a7f  vmovaps [rsp+0x50], xmm6
00007e4af17d0a85  vmovaps [rsp+0x60], xmm7
00007e4af17d0a8b  vmovaps [rsp+0x70], xmm8
00007e4af17d0a91  vmovaps [rsp+0x80], xmm9
00007e4af17d0a9a  vmovaps [rsp+0x90], xmm10
00007e4af17d0aa3  vmovaps [rsp+0xA0], xmm11
00007e4af17d0aac  vmovaps [rsp+0xB0], xmm12
00007e4af17d0ab5  vmovaps [rsp+0xC0], xmm13
00007e4af17d0abe  vmovaps [rsp+0xD0], xmm14
00007e4af17d0ac7  vmovaps [rsp+0xE0], xmm15
00007e4af17d0ad0  sub rsp, 0x30
00007e4af17d0ad4  movaps [rsp], xmm1
00007e4af17d0ad8  movaps [rsp+0x10], xmm14
00007e4af17d0ade  movaps [rsp+0x20], xmm10
00007e4af17d0ae4  lea rdi, [rsp]
00007e4af17d0ae8  mov esi, 0x00
00007e4af17d0aed  mov rax, 0x6256754A7530
00007e4af17d0af7  call rax
00007e4af17d0af9  movaps xmm1, [rsp]
00007e4af17d0afd  add rsp, 0x30
00007e4af17d0b01  vmovaps xmm0, [rsp]
00007e4af17d0b06  vmovaps xmm2, [rsp+0x10]
00007e4af17d0b0c  vmovaps xmm3, [rsp+0x20]
00007e4af17d0b12  vmovaps xmm4, [rsp+0x30]
00007e4af17d0b18  vmovaps xmm5, [rsp+0x40]
00007e4af17d0b1e  vmovaps xmm6, [rsp+0x50]
00007e4af17d0b24  vmovaps xmm7, [rsp+0x60]
00007e4af17d0b2a  vmovaps xmm8, [rsp+0x70]
00007e4af17d0b30  vmovaps xmm9, [rsp+0x80]
00007e4af17d0b39  vmovaps xmm10, [rsp+0x90]
00007e4af17d0b42  vmovaps xmm11, [rsp+0xA0]
00007e4af17d0b4b  vmovaps xmm12, [rsp+0xB0]
00007e4af17d0b54  vmovaps xmm13, [rsp+0xC0]
00007e4af17d0b5d  vmovaps xmm14, [rsp+0xD0]
00007e4af17d0b66  vmovaps xmm15, [rsp+0xE0]
00007e4af17d0b6f  add rsp, 0xF0
00007e4af17d0b76  pop r11
00007e4af17d0b78  pop r10
00007e4af17d0b7a  pop r9
00007e4af17d0b7c  pop r8
00007e4af17d0b7e  pop rsi
00007e4af17d0b7f  pop rdi
00007e4af17d0b80  pop rdx
00007e4af17d0b81  pop rcx
00007e4af17d0b82  pop rax
00007e4af17d0b83  add rsp, 0x08
00007e4af17d0b87  jmp 0x00007E4AF17CF631
00007e4af17d0b8c  sub rsp, 0x08
00007e4af17d0b90  push rax
00007e4af17d0b91  push rcx
00007e4af17d0b92  push rdx
00007e4af17d0b93  push rdi
00007e4af17d0b94  push rsi
00007e4af17d0b95  push r8
00007e4af17d0b97  push r9
00007e4af17d0b99  push r10
00007e4af17d0b9b  push r11
00007e4af17d0b9d  sub rsp, 0xF0
00007e4af17d0ba4  vmovaps [rsp], xmm0
00007e4af17d0ba9  vmovaps [rsp+0x10], xmm1
00007e4af17d0baf  vmovaps [rsp+0x20], xmm2
00007e4af17d0bb5  vmovaps [rsp+0x30], xmm3
00007e4af17d0bbb  vmovaps [rsp+0x40], xmm4
00007e4af17d0bc1  vmovaps [rsp+0x50], xmm5
00007e4af17d0bc7  vmovaps [rsp+0x60], xmm6
00007e4af17d0bcd  vmovaps [rsp+0x70], xmm7
00007e4af17d0bd3  vmovaps [rsp+0x80], xmm8
00007e4af17d0bdc  vmovaps [rsp+0x90], xmm9
00007e4af17d0be5  vmovaps [rsp+0xA0], xmm10
00007e4af17d0bee  vmovaps [rsp+0xB0], xmm11
00007e4af17d0bf7  vmovaps [rsp+0xC0], xmm12
00007e4af17d0c00  vmovaps [rsp+0xD0], xmm14
00007e4af17d0c09  vmovaps [rsp+0xE0], xmm15
00007e4af17d0c12  sub rsp, 0x30
00007e4af17d0c16  movaps [rsp], xmm13
00007e4af17d0c1b  movaps [rsp+0x10], xmm14
00007e4af17d0c21  movaps [rsp+0x20], xmm2
00007e4af17d0c26  lea rdi, [rsp]
00007e4af17d0c2a  mov esi, 0x00
00007e4af17d0c2f  mov rax, 0x6256754A7530
00007e4af17d0c39  call rax
00007e4af17d0c3b  movaps xmm13, [rsp]
00007e4af17d0c40  add rsp, 0x30
00007e4af17d0c44  vmovaps xmm0, [rsp]
00007e4af17d0c49  vmovaps xmm1, [rsp+0x10]
00007e4af17d0c4f  vmovaps xmm2, [rsp+0x20]
00007e4af17d0c55  vmovaps xmm3, [rsp+0x30]
00007e4af17d0c5b  vmovaps xmm4, [rsp+0x40]
00007e4af17d0c61  vmovaps xmm5, [rsp+0x50]
00007e4af17d0c67  vmovaps xmm6, [rsp+0x60]
00007e4af17d0c6d  vmovaps xmm7, [rsp+0x70]
00007e4af17d0c73  vmovaps xmm8, [rsp+0x80]
00007e4af17d0c7c  vmovaps xmm9, [rsp+0x90]
00007e4af17d0c85  vmovaps xmm10, [rsp+0xA0]
00007e4af17d0c8e  vmovaps xmm11, [rsp+0xB0]
00007e4af17d0c97  vmovaps xmm12, [rsp+0xC0]
00007e4af17d0ca0  vmovaps xmm14, [rsp+0xD0]
00007e4af17d0ca9  vmovaps xmm15, [rsp+0xE0]
00007e4af17d0cb2  add rsp, 0xF0
00007e4af17d0cb9  pop r11
00007e4af17d0cbb  pop r10
00007e4af17d0cbd  pop r9
00007e4af17d0cbf  pop r8
00007e4af17d0cc1  pop rsi
00007e4af17d0cc2  pop rdi
00007e4af17d0cc3  pop rdx
00007e4af17d0cc4  pop rcx
00007e4af17d0cc5  pop rax
00007e4af17d0cc6  add rsp, 0x08
00007e4af17d0cca  jmp 0x00007E4AF17CF64C
00007e4af17d0ccf  sub rsp, 0x08
00007e4af17d0cd3  push rax
00007e4af17d0cd4  push rcx
00007e4af17d0cd5  push rdx
00007e4af17d0cd6  push rdi
00007e4af17d0cd7  push rsi
00007e4af17d0cd8  push r8
00007e4af17d0cda  push r9
00007e4af17d0cdc  push r10
00007e4af17d0cde  push r11
00007e4af17d0ce0  sub rsp, 0xF0
00007e4af17d0ce7  vmovaps [rsp], xmm0
00007e4af17d0cec  vmovaps [rsp+0x10], xmm2
00007e4af17d0cf2  vmovaps [rsp+0x20], xmm3
00007e4af17d0cf8  vmovaps [rsp+0x30], xmm4
00007e4af17d0cfe  vmovaps [rsp+0x40], xmm5
00007e4af17d0d04  vmovaps [rsp+0x50], xmm6
00007e4af17d0d0a  vmovaps [rsp+0x60], xmm7
00007e4af17d0d10  vmovaps [rsp+0x70], xmm8
00007e4af17d0d16  vmovaps [rsp+0x80], xmm9
00007e4af17d0d1f  vmovaps [rsp+0x90], xmm10
00007e4af17d0d28  vmovaps [rsp+0xA0], xmm11
00007e4af17d0d31  vmovaps [rsp+0xB0], xmm12
00007e4af17d0d3a  vmovaps [rsp+0xC0], xmm13
00007e4af17d0d43  vmovaps [rsp+0xD0], xmm14
00007e4af17d0d4c  vmovaps [rsp+0xE0], xmm15
00007e4af17d0d55  sub rsp, 0x30
00007e4af17d0d59  movaps [rsp], xmm1
00007e4af17d0d5d  movaps [rsp+0x10], xmm10
00007e4af17d0d63  movaps [rsp+0x20], xmm2
00007e4af17d0d68  lea rdi, [rsp]
00007e4af17d0d6c  mov esi, 0x00
00007e4af17d0d71  mov rax, 0x6256754A7530
00007e4af17d0d7b  call rax
00007e4af17d0d7d  movaps xmm1, [rsp]
00007e4af17d0d81  add rsp, 0x30
00007e4af17d0d85  vmovaps xmm0, [rsp]
00007e4af17d0d8a  vmovaps xmm2, [rsp+0x10]
00007e4af17d0d90  vmovaps xmm3, [rsp+0x20]
00007e4af17d0d96  vmovaps xmm4, [rsp+0x30]
00007e4af17d0d9c  vmovaps xmm5, [rsp+0x40]
00007e4af17d0da2  vmovaps xmm6, [rsp+0x50]
00007e4af17d0da8  vmovaps xmm7, [rsp+0x60]
00007e4af17d0dae  vmovaps xmm8, [rsp+0x70]
00007e4af17d0db4  vmovaps xmm9, [rsp+0x80]
00007e4af17d0dbd  vmovaps xmm10, [rsp+0x90]
00007e4af17d0dc6  vmovaps xmm11, [rsp+0xA0]
00007e4af17d0dcf  vmovaps xmm12, [rsp+0xB0]
00007e4af17d0dd8  vmovaps xmm13, [rsp+0xC0]
00007e4af17d0de1  vmovaps xmm14, [rsp+0xD0]
00007e4af17d0dea  vmovaps xmm15, [rsp+0xE0]
00007e4af17d0df3  add rsp, 0xF0
00007e4af17d0dfa  pop r11
00007e4af17d0dfc  pop r10
00007e4af17d0dfe  pop r9
00007e4af17d0e00  pop r8
00007e4af17d0e02  pop rsi
00007e4af17d0e03  pop rdi
00007e4af17d0e04  pop rdx
00007e4af17d0e05  pop rcx
00007e4af17d0e06  pop rax
00007e4af17d0e07  add rsp, 0x08
00007e4af17d0e0b  jmp 0x00007E4AF17CF6B4
00007e4af17d0e10  sub rsp, 0x08
00007e4af17d0e14  push rax
00007e4af17d0e15  push rcx
00007e4af17d0e16  push rdx
00007e4af17d0e17  push rdi
00007e4af17d0e18  push rsi
00007e4af17d0e19  push r8
00007e4af17d0e1b  push r9
00007e4af17d0e1d  push r10
00007e4af17d0e1f  push r11
00007e4af17d0e21  sub rsp, 0xF0
00007e4af17d0e28  vmovaps [rsp], xmm0
00007e4af17d0e2d  vmovaps [rsp+0x10], xmm1
00007e4af17d0e33  vmovaps [rsp+0x20], xmm2
00007e4af17d0e39  vmovaps [rsp+0x30], xmm3
00007e4af17d0e3f  vmovaps [rsp+0x40], xmm4
00007e4af17d0e45  vmovaps [rsp+0x50], xmm5
00007e4af17d0e4b  vmovaps [rsp+0x60], xmm6
00007e4af17d0e51  vmovaps [rsp+0x70], xmm7
00007e4af17d0e57  vmovaps [rsp+0x80], xmm8
00007e4af17d0e60  vmovaps [rsp+0x90], xmm9
00007e4af17d0e69  vmovaps [rsp+0xA0], xmm10
00007e4af17d0e72  vmovaps [rsp+0xB0], xmm11
00007e4af17d0e7b  vmovaps [rsp+0xC0], xmm12
00007e4af17d0e84  vmovaps [rsp+0xD0], xmm13
00007e4af17d0e8d  vmovaps [rsp+0xE0], xmm14
00007e4af17d0e96  sub rsp, 0x30
00007e4af17d0e9a  movaps [rsp], xmm15
00007e4af17d0e9f  movaps [rsp+0x10], xmm10
00007e4af17d0ea5  movaps [rsp+0x20], xmm2
00007e4af17d0eaa  lea rdi, [rsp]
00007e4af17d0eae  mov esi, 0x00
00007e4af17d0eb3  mov rax, 0x6256754A7530
00007e4af17d0ebd  call rax
00007e4af17d0ebf  movaps xmm15, [rsp]
00007e4af17d0ec4  add rsp, 0x30
00007e4af17d0ec8  vmovaps xmm0, [rsp]
00007e4af17d0ecd  vmovaps xmm1, [rsp+0x10]
00007e4af17d0ed3  vmovaps xmm2, [rsp+0x20]
00007e4af17d0ed9  vmovaps xmm3, [rsp+0x30]
00007e4af17d0edf  vmovaps xmm4, [rsp+0x40]
00007e4af17d0ee5  vmovaps xmm5, [rsp+0x50]
00007e4af17d0eeb  vmovaps xmm6, [rsp+0x60]
00007e4af17d0ef1  vmovaps xmm7, [rsp+0x70]
00007e4af17d0ef7  vmovaps xmm8, [rsp+0x80]
00007e4af17d0f00  vmovaps xmm9, [rsp+0x90]
00007e4af17d0f09  vmovaps xmm10, [rsp+0xA0]
00007e4af17d0f12  vmovaps xmm11, [rsp+0xB0]
00007e4af17d0f1b  vmovaps xmm12, [rsp+0xC0]
00007e4af17d0f24  vmovaps xmm13, [rsp+0xD0]
00007e4af17d0f2d  vmovaps xmm14, [rsp+0xE0]
00007e4af17d0f36  add rsp, 0xF0
00007e4af17d0f3d  pop r11
00007e4af17d0f3f  pop r10
00007e4af17d0f41  pop r9
00007e4af17d0f43  pop r8
00007e4af17d0f45  pop rsi
00007e4af17d0f46  pop rdi
00007e4af17d0f47  pop rdx
00007e4af17d0f48  pop rcx
00007e4af17d0f49  pop rax
00007e4af17d0f4a  add rsp, 0x08
00007e4af17d0f4e  jmp 0x00007E4AF17CF706
00007e4af17d0f53  sub rsp, 0x08
00007e4af17d0f57  push rax
00007e4af17d0f58  push rcx
00007e4af17d0f59  push rdx
00007e4af17d0f5a  push rdi
00007e4af17d0f5b  push rsi
00007e4af17d0f5c  push r8
00007e4af17d0f5e  push r9
00007e4af17d0f60  push r10
00007e4af17d0f62  push r11
00007e4af17d0f64  sub rsp, 0xF0
00007e4af17d0f6b  vmovaps [rsp], xmm0
00007e4af17d0f70  vmovaps [rsp+0x10], xmm2
00007e4af17d0f76  vmovaps [rsp+0x20], xmm3
00007e4af17d0f7c  vmovaps [rsp+0x30], xmm4
00007e4af17d0f82  vmovaps [rsp+0x40], xmm5
00007e4af17d0f88  vmovaps [rsp+0x50], xmm6
00007e4af17d0f8e  vmovaps [rsp+0x60], xmm7
00007e4af17d0f94  vmovaps [rsp+0x70], xmm8
00007e4af17d0f9a  vmovaps [rsp+0x80], xmm9
00007e4af17d0fa3  vmovaps [rsp+0x90], xmm10
00007e4af17d0fac  vmovaps [rsp+0xA0], xmm11
00007e4af17d0fb5  vmovaps [rsp+0xB0], xmm12
00007e4af17d0fbe  vmovaps [rsp+0xC0], xmm13
00007e4af17d0fc7  vmovaps [rsp+0xD0], xmm14
00007e4af17d0fd0  vmovaps [rsp+0xE0], xmm15
00007e4af17d0fd9  sub rsp, 0x30
00007e4af17d0fdd  movaps [rsp], xmm1
00007e4af17d0fe1  movaps [rsp+0x10], xmm10
00007e4af17d0fe7  movaps [rsp+0x20], xmm12
00007e4af17d0fed  lea rdi, [rsp]
00007e4af17d0ff1  mov esi, 0x00
00007e4af17d0ff6  mov rax, 0x6256754A7530
00007e4af17d1000  call rax
00007e4af17d1002  movaps xmm1, [rsp]
00007e4af17d1006  add rsp, 0x30
00007e4af17d100a  vmovaps xmm0, [rsp]
00007e4af17d100f  vmovaps xmm2, [rsp+0x10]
00007e4af17d1015  vmovaps xmm3, [rsp+0x20]
00007e4af17d101b  vmovaps xmm4, [rsp+0x30]
00007e4af17d1021  vmovaps xmm5, [rsp+0x40]
00007e4af17d1027  vmovaps xmm6, [rsp+0x50]
00007e4af17d102d  vmovaps xmm7, [rsp+0x60]
00007e4af17d1033  vmovaps xmm8, [rsp+0x70]
00007e4af17d1039  vmovaps xmm9, [rsp+0x80]
00007e4af17d1042  vmovaps xmm10, [rsp+0x90]
00007e4af17d104b  vmovaps xmm11, [rsp+0xA0]
00007e4af17d1054  vmovaps xmm12, [rsp+0xB0]
00007e4af17d105d  vmovaps xmm13, [rsp+0xC0]
00007e4af17d1066  vmovaps xmm14, [rsp+0xD0]
00007e4af17d106f  vmovaps xmm15, [rsp+0xE0]
00007e4af17d1078  add rsp, 0xF0
00007e4af17d107f  pop r11
00007e4af17d1081  pop r10
00007e4af17d1083  pop r9
00007e4af17d1085  pop r8
00007e4af17d1087  pop rsi
00007e4af17d1088  pop rdi
00007e4af17d1089  pop rdx
00007e4af17d108a  pop rcx
00007e4af17d108b  pop rax
00007e4af17d108c  add rsp, 0x08
00007e4af17d1090  jmp 0x00007E4AF17CF732
00007e4af17d1095  sub rsp, 0x08
00007e4af17d1099  push rax
00007e4af17d109a  push rcx
00007e4af17d109b  push rdx
00007e4af17d109c  push rdi
00007e4af17d109d  push rsi
00007e4af17d109e  push r8
00007e4af17d10a0  push r9
00007e4af17d10a2  push r10
00007e4af17d10a4  push r11
00007e4af17d10a6  sub rsp, 0xF0
00007e4af17d10ad  vmovaps [rsp], xmm0
00007e4af17d10b2  vmovaps [rsp+0x10], xmm1
00007e4af17d10b8  vmovaps [rsp+0x20], xmm2
00007e4af17d10be  vmovaps [rsp+0x30], xmm3
00007e4af17d10c4  vmovaps [rsp+0x40], xmm4
00007e4af17d10ca  vmovaps [rsp+0x50], xmm5
00007e4af17d10d0  vmovaps [rsp+0x60], xmm6
00007e4af17d10d6  vmovaps [rsp+0x70], xmm7
00007e4af17d10dc  vmovaps [rsp+0x80], xmm8
00007e4af17d10e5  vmovaps [rsp+0x90], xmm9
00007e4af17d10ee  vmovaps [rsp+0xA0], xmm10
00007e4af17d10f7  vmovaps [rsp+0xB0], xmm11
00007e4af17d1100  vmovaps [rsp+0xC0], xmm12
00007e4af17d1109  vmovaps [rsp+0xD0], xmm13
00007e4af17d1112  vmovaps [rsp+0xE0], xmm14
00007e4af17d111b  sub rsp, 0x30
00007e4af17d111f  movaps [rsp], xmm15
00007e4af17d1124  movaps [rsp+0x10], xmm10
00007e4af17d112a  movaps [rsp+0x20], xmm12
00007e4af17d1130  lea rdi, [rsp]
00007e4af17d1134  mov esi, 0x00
00007e4af17d1139  mov rax, 0x6256754A7530
00007e4af17d1143  call rax
00007e4af17d1145  movaps xmm15, [rsp]
00007e4af17d114a  add rsp, 0x30
00007e4af17d114e  vmovaps xmm0, [rsp]
00007e4af17d1153  vmovaps xmm1, [rsp+0x10]
00007e4af17d1159  vmovaps xmm2, [rsp+0x20]
00007e4af17d115f  vmovaps xmm3, [rsp+0x30]
00007e4af17d1165  vmovaps xmm4, [rsp+0x40]
00007e4af17d116b  vmovaps xmm5, [rsp+0x50]
00007e4af17d1171  vmovaps xmm6, [rsp+0x60]
00007e4af17d1177  vmovaps xmm7, [rsp+0x70]
00007e4af17d117d  vmovaps xmm8, [rsp+0x80]
00007e4af17d1186  vmovaps xmm9, [rsp+0x90]
00007e4af17d118f  vmovaps xmm10, [rsp+0xA0]
00007e4af17d1198  vmovaps xmm11, [rsp+0xB0]
00007e4af17d11a1  vmovaps xmm12, [rsp+0xC0]
00007e4af17d11aa  vmovaps xmm13, [rsp+0xD0]
00007e4af17d11b3  vmovaps xmm14, [rsp+0xE0]
00007e4af17d11bc  add rsp, 0xF0
00007e4af17d11c3  pop r11
00007e4af17d11c5  pop r10
00007e4af17d11c7  pop r9
00007e4af17d11c9  pop r8
00007e4af17d11cb  pop rsi
00007e4af17d11cc  pop rdi
00007e4af17d11cd  pop rdx
00007e4af17d11ce  pop rcx
00007e4af17d11cf  pop rax
00007e4af17d11d0  add rsp, 0x08
00007e4af17d11d4  jmp 0x00007E4AF17CF75E
00007e4af17d11d9  call 0x00007E4AF15FF430
00007e4af17d11de  jmp 0x00007E4AF17CF7EE
00007e4af17d11e3  call 0x00007E4AF15FF430
00007e4af17d11e8  jmp 0x00007E4AF17CF801
00007e4af17d11ed  sub rsp, 0x08
00007e4af17d11f1  push rax
00007e4af17d11f2  push rcx
00007e4af17d11f3  push rdx
00007e4af17d11f4  push rdi
00007e4af17d11f5  push rsi
00007e4af17d11f6  push r8
00007e4af17d11f8  push r9
00007e4af17d11fa  push r10
00007e4af17d11fc  push r11
00007e4af17d11fe  sub rsp, 0xF0
00007e4af17d1205  vmovaps [rsp], xmm0
00007e4af17d120a  vmovaps [rsp+0x10], xmm2
00007e4af17d1210  vmovaps [rsp+0x20], xmm3
00007e4af17d1216  vmovaps [rsp+0x30], xmm4
00007e4af17d121c  vmovaps [rsp+0x40], xmm5
00007e4af17d1222  vmovaps [rsp+0x50], xmm6
00007e4af17d1228  vmovaps [rsp+0x60], xmm7
00007e4af17d122e  vmovaps [rsp+0x70], xmm8
00007e4af17d1234  vmovaps [rsp+0x80], xmm9
00007e4af17d123d  vmovaps [rsp+0x90], xmm10
00007e4af17d1246  vmovaps [rsp+0xA0], xmm11
00007e4af17d124f  vmovaps [rsp+0xB0], xmm12
00007e4af17d1258  vmovaps [rsp+0xC0], xmm13
00007e4af17d1261  vmovaps [rsp+0xD0], xmm14
00007e4af17d126a  vmovaps [rsp+0xE0], xmm15
00007e4af17d1273  sub rsp, 0x30
00007e4af17d1277  movaps [rsp], xmm1
00007e4af17d127b  movaps [rsp+0x10], xmm13
00007e4af17d1281  movaps [rsp+0x20], xmm2
00007e4af17d1286  lea rdi, [rsp]
00007e4af17d128a  mov esi, 0x00
00007e4af17d128f  mov rax, 0x6256754A7530
00007e4af17d1299  call rax
00007e4af17d129b  movaps xmm1, [rsp]
00007e4af17d129f  add rsp, 0x30
00007e4af17d12a3  vmovaps xmm0, [rsp]
00007e4af17d12a8  vmovaps xmm2, [rsp+0x10]
00007e4af17d12ae  vmovaps xmm3, [rsp+0x20]
00007e4af17d12b4  vmovaps xmm4, [rsp+0x30]
00007e4af17d12ba  vmovaps xmm5, [rsp+0x40]
00007e4af17d12c0  vmovaps xmm6, [rsp+0x50]
00007e4af17d12c6  vmovaps xmm7, [rsp+0x60]
00007e4af17d12cc  vmovaps xmm8, [rsp+0x70]
00007e4af17d12d2  vmovaps xmm9, [rsp+0x80]
00007e4af17d12db  vmovaps xmm10, [rsp+0x90]
00007e4af17d12e4  vmovaps xmm11, [rsp+0xA0]
00007e4af17d12ed  vmovaps xmm12, [rsp+0xB0]
00007e4af17d12f6  vmovaps xmm13, [rsp+0xC0]
00007e4af17d12ff  vmovaps xmm14, [rsp+0xD0]
00007e4af17d1308  vmovaps xmm15, [rsp+0xE0]
00007e4af17d1311  add rsp, 0xF0
00007e4af17d1318  pop r11
00007e4af17d131a  pop r10
00007e4af17d131c  pop r9
00007e4af17d131e  pop r8
00007e4af17d1320  pop rsi
00007e4af17d1321  pop rdi
00007e4af17d1322  pop rdx
00007e4af17d1323  pop rcx
00007e4af17d1324  pop rax
00007e4af17d1325  add rsp, 0x08
00007e4af17d1329  jmp 0x00007E4AF17CF82C
00007e4af17d132e  call 0x00007E4AF160E760
00007e4af17d1333  jmp 0x00007E4AF17CF839
00007e4af17d1338  sub rsp, 0x08
00007e4af17d133c  push rax
00007e4af17d133d  push rcx
00007e4af17d133e  push rdx
00007e4af17d133f  push rdi
00007e4af17d1340  push rsi
00007e4af17d1341  push r8
00007e4af17d1343  push r9
00007e4af17d1345  push r10
00007e4af17d1347  push r11
00007e4af17d1349  sub rsp, 0xF0
00007e4af17d1350  vmovaps [rsp], xmm0
00007e4af17d1355  vmovaps [rsp+0x10], xmm1
00007e4af17d135b  vmovaps [rsp+0x20], xmm2
00007e4af17d1361  vmovaps [rsp+0x30], xmm3
00007e4af17d1367  vmovaps [rsp+0x40], xmm4
00007e4af17d136d  vmovaps [rsp+0x50], xmm5
00007e4af17d1373  vmovaps [rsp+0x60], xmm6
00007e4af17d1379  vmovaps [rsp+0x70], xmm7
00007e4af17d137f  vmovaps [rsp+0x80], xmm8
00007e4af17d1388  vmovaps [rsp+0x90], xmm9
00007e4af17d1391  vmovaps [rsp+0xA0], xmm10
00007e4af17d139a  vmovaps [rsp+0xB0], xmm11
00007e4af17d13a3  vmovaps [rsp+0xC0], xmm12
00007e4af17d13ac  vmovaps [rsp+0xD0], xmm14
00007e4af17d13b5  vmovaps [rsp+0xE0], xmm15
00007e4af17d13be  sub rsp, 0x30
00007e4af17d13c2  movaps [rsp], xmm13
00007e4af17d13c7  movaps [rsp+0x10], xmm2
00007e4af17d13cc  movaps [rsp+0x20], xmm1
00007e4af17d13d1  lea rdi, [rsp]
00007e4af17d13d5  mov esi, 0x00
00007e4af17d13da  mov rax, 0x6256754A7530
00007e4af17d13e4  call rax
00007e4af17d13e6  movaps xmm13, [rsp]
00007e4af17d13eb  add rsp, 0x30
00007e4af17d13ef  vmovaps xmm0, [rsp]
00007e4af17d13f4  vmovaps xmm1, [rsp+0x10]
00007e4af17d13fa  vmovaps xmm2, [rsp+0x20]
00007e4af17d1400  vmovaps xmm3, [rsp+0x30]
00007e4af17d1406  vmovaps xmm4, [rsp+0x40]
00007e4af17d140c  vmovaps xmm5, [rsp+0x50]
00007e4af17d1412  vmovaps xmm6, [rsp+0x60]
00007e4af17d1418  vmovaps xmm7, [rsp+0x70]
00007e4af17d141e  vmovaps xmm8, [rsp+0x80]
00007e4af17d1427  vmovaps xmm9, [rsp+0x90]
00007e4af17d1430  vmovaps xmm10, [rsp+0xA0]
00007e4af17d1439  vmovaps xmm11, [rsp+0xB0]
00007e4af17d1442  vmovaps xmm12, [rsp+0xC0]
00007e4af17d144b  vmovaps xmm14, [rsp+0xD0]
00007e4af17d1454  vmovaps xmm15, [rsp+0xE0]
00007e4af17d145d  add rsp, 0xF0
00007e4af17d1464  pop r11
00007e4af17d1466  pop r10
00007e4af17d1468  pop r9
00007e4af17d146a  pop r8
00007e4af17d146c  pop rsi
00007e4af17d146d  pop rdi
00007e4af17d146e  pop rdx
00007e4af17d146f  pop rcx
00007e4af17d1470  pop rax
00007e4af17d1471  add rsp, 0x08
00007e4af17d1475  jmp 0x00007E4AF17CF878
00007e4af17d147a  sub rsp, 0x08
00007e4af17d147e  push rax
00007e4af17d147f  push rcx
00007e4af17d1480  push rdx
00007e4af17d1481  push rdi
00007e4af17d1482  push rsi
00007e4af17d1483  push r8
00007e4af17d1485  push r9
00007e4af17d1487  push r10
00007e4af17d1489  push r11
00007e4af17d148b  sub rsp, 0xF0
00007e4af17d1492  vmovaps [rsp], xmm0
00007e4af17d1497  vmovaps [rsp+0x10], xmm2
00007e4af17d149d  vmovaps [rsp+0x20], xmm3
00007e4af17d14a3  vmovaps [rsp+0x30], xmm4
00007e4af17d14a9  vmovaps [rsp+0x40], xmm5
00007e4af17d14af  vmovaps [rsp+0x50], xmm6
00007e4af17d14b5  vmovaps [rsp+0x60], xmm7
00007e4af17d14bb  vmovaps [rsp+0x70], xmm8
00007e4af17d14c1  vmovaps [rsp+0x80], xmm9
00007e4af17d14ca  vmovaps [rsp+0x90], xmm10
00007e4af17d14d3  vmovaps [rsp+0xA0], xmm11
00007e4af17d14dc  vmovaps [rsp+0xB0], xmm12
00007e4af17d14e5  vmovaps [rsp+0xC0], xmm13
00007e4af17d14ee  vmovaps [rsp+0xD0], xmm14
00007e4af17d14f7  vmovaps [rsp+0xE0], xmm15
00007e4af17d1500  sub rsp, 0x30
00007e4af17d1504  movaps [rsp], xmm1
00007e4af17d1508  movaps [rsp+0x10], xmm15
00007e4af17d150e  movaps [rsp+0x20], xmm2
00007e4af17d1513  lea rdi, [rsp]
00007e4af17d1517  mov esi, 0x00
00007e4af17d151c  mov rax, 0x6256754A7530
00007e4af17d1526  call rax
00007e4af17d1528  movaps xmm1, [rsp]
00007e4af17d152c  add rsp, 0x30
00007e4af17d1530  vmovaps xmm0, [rsp]
00007e4af17d1535  vmovaps xmm2, [rsp+0x10]
00007e4af17d153b  vmovaps xmm3, [rsp+0x20]
00007e4af17d1541  vmovaps xmm4, [rsp+0x30]
00007e4af17d1547  vmovaps xmm5, [rsp+0x40]
00007e4af17d154d  vmovaps xmm6, [rsp+0x50]
00007e4af17d1553  vmovaps xmm7, [rsp+0x60]
00007e4af17d1559  vmovaps xmm8, [rsp+0x70]
00007e4af17d155f  vmovaps xmm9, [rsp+0x80]
00007e4af17d1568  vmovaps xmm10, [rsp+0x90]
00007e4af17d1571  vmovaps xmm11, [rsp+0xA0]
00007e4af17d157a  vmovaps xmm12, [rsp+0xB0]
00007e4af17d1583  vmovaps xmm13, [rsp+0xC0]
00007e4af17d158c  vmovaps xmm14, [rsp+0xD0]
00007e4af17d1595  vmovaps xmm15, [rsp+0xE0]
00007e4af17d159e  add rsp, 0xF0
00007e4af17d15a5  pop r11
00007e4af17d15a7  pop r10
00007e4af17d15a9  pop r9
00007e4af17d15ab  pop r8
00007e4af17d15ad  pop rsi
00007e4af17d15ae  pop rdi
00007e4af17d15af  pop rdx
00007e4af17d15b0  pop rcx
00007e4af17d15b1  pop rax
00007e4af17d15b2  add rsp, 0x08
00007e4af17d15b6  jmp 0x00007E4AF17CF8AC
00007e4af17d15bb  sub rsp, 0x08
00007e4af17d15bf  push rax
00007e4af17d15c0  push rcx
00007e4af17d15c1  push rdx
00007e4af17d15c2  push rdi
00007e4af17d15c3  push rsi
00007e4af17d15c4  push r8
00007e4af17d15c6  push r9
00007e4af17d15c8  push r10
00007e4af17d15ca  push r11
00007e4af17d15cc  sub rsp, 0xF0
00007e4af17d15d3  vmovaps [rsp], xmm0
00007e4af17d15d8  vmovaps [rsp+0x10], xmm1
00007e4af17d15de  vmovaps [rsp+0x20], xmm2
00007e4af17d15e4  vmovaps [rsp+0x30], xmm3
00007e4af17d15ea  vmovaps [rsp+0x40], xmm4
00007e4af17d15f0  vmovaps [rsp+0x50], xmm5
00007e4af17d15f6  vmovaps [rsp+0x60], xmm6
00007e4af17d15fc  vmovaps [rsp+0x70], xmm7
00007e4af17d1602  vmovaps [rsp+0x80], xmm8
00007e4af17d160b  vmovaps [rsp+0x90], xmm9
00007e4af17d1614  vmovaps [rsp+0xA0], xmm10
00007e4af17d161d  vmovaps [rsp+0xB0], xmm11
00007e4af17d1626  vmovaps [rsp+0xC0], xmm12
00007e4af17d162f  vmovaps [rsp+0xD0], xmm13
00007e4af17d1638  vmovaps [rsp+0xE0], xmm15
00007e4af17d1641  sub rsp, 0x30
00007e4af17d1645  movaps [rsp], xmm14
00007e4af17d164a  movaps [rsp+0x10], xmm2
00007e4af17d164f  movaps [rsp+0x20], xmm15
00007e4af17d1655  lea rdi, [rsp]
00007e4af17d1659  mov esi, 0x00
00007e4af17d165e  mov rax, 0x6256754A7530
00007e4af17d1668  call rax
00007e4af17d166a  movaps xmm14, [rsp]
00007e4af17d166f  add rsp, 0x30
00007e4af17d1673  vmovaps xmm0, [rsp]
00007e4af17d1678  vmovaps xmm1, [rsp+0x10]
00007e4af17d167e  vmovaps xmm2, [rsp+0x20]
00007e4af17d1684  vmovaps xmm3, [rsp+0x30]
00007e4af17d168a  vmovaps xmm4, [rsp+0x40]
00007e4af17d1690  vmovaps xmm5, [rsp+0x50]
00007e4af17d1696  vmovaps xmm6, [rsp+0x60]
00007e4af17d169c  vmovaps xmm7, [rsp+0x70]
00007e4af17d16a2  vmovaps xmm8, [rsp+0x80]
00007e4af17d16ab  vmovaps xmm9, [rsp+0x90]
00007e4af17d16b4  vmovaps xmm10, [rsp+0xA0]
00007e4af17d16bd  vmovaps xmm11, [rsp+0xB0]
00007e4af17d16c6  vmovaps xmm12, [rsp+0xC0]
00007e4af17d16cf  vmovaps xmm13, [rsp+0xD0]
00007e4af17d16d8  vmovaps xmm15, [rsp+0xE0]
00007e4af17d16e1  add rsp, 0xF0
00007e4af17d16e8  pop r11
00007e4af17d16ea  pop r10
00007e4af17d16ec  pop r9
00007e4af17d16ee  pop r8
00007e4af17d16f0  pop rsi
00007e4af17d16f1  pop rdi
00007e4af17d16f2  pop rdx
00007e4af17d16f3  pop rcx
00007e4af17d16f4  pop rax
00007e4af17d16f5  add rsp, 0x08
00007e4af17d16f9  jmp 0x00007E4AF17CF8E7
00007e4af17d16fe  sub rsp, 0x08
00007e4af17d1702  push rax
00007e4af17d1703  push rcx
00007e4af17d1704  push rdx
00007e4af17d1705  push rdi
00007e4af17d1706  push rsi
00007e4af17d1707  push r8
00007e4af17d1709  push r9
00007e4af17d170b  push r10
00007e4af17d170d  push r11
00007e4af17d170f  sub rsp, 0xF0
00007e4af17d1716  vmovaps [rsp], xmm0
00007e4af17d171b  vmovaps [rsp+0x10], xmm1
00007e4af17d1721  vmovaps [rsp+0x20], xmm2
00007e4af17d1727  vmovaps [rsp+0x30], xmm3
00007e4af17d172d  vmovaps [rsp+0x40], xmm4
00007e4af17d1733  vmovaps [rsp+0x50], xmm5
00007e4af17d1739  vmovaps [rsp+0x60], xmm6
00007e4af17d173f  vmovaps [rsp+0x70], xmm7
00007e4af17d1745  vmovaps [rsp+0x80], xmm8
00007e4af17d174e  vmovaps [rsp+0x90], xmm9
00007e4af17d1757  vmovaps [rsp+0xA0], xmm10
00007e4af17d1760  vmovaps [rsp+0xB0], xmm11
00007e4af17d1769  vmovaps [rsp+0xC0], xmm12
00007e4af17d1772  vmovaps [rsp+0xD0], xmm13
00007e4af17d177b  vmovaps [rsp+0xE0], xmm14
00007e4af17d1784  sub rsp, 0x30
00007e4af17d1788  movaps [rsp], xmm15
00007e4af17d178d  movaps [rsp+0x10], xmm2
00007e4af17d1792  movaps [rsp+0x20], xmm1
00007e4af17d1797  lea rdi, [rsp]
00007e4af17d179b  mov esi, 0x00
00007e4af17d17a0  mov rax, 0x6256754A7530
00007e4af17d17aa  call rax
00007e4af17d17ac  movaps xmm15, [rsp]
00007e4af17d17b1  add rsp, 0x30
00007e4af17d17b5  vmovaps xmm0, [rsp]
00007e4af17d17ba  vmovaps xmm1, [rsp+0x10]
00007e4af17d17c0  vmovaps xmm2, [rsp+0x20]
00007e4af17d17c6  vmovaps xmm3, [rsp+0x30]
00007e4af17d17cc  vmovaps xmm4, [rsp+0x40]
00007e4af17d17d2  vmovaps xmm5, [rsp+0x50]
00007e4af17d17d8  vmovaps xmm6, [rsp+0x60]
00007e4af17d17de  vmovaps xmm7, [rsp+0x70]
00007e4af17d17e4  vmovaps xmm8, [rsp+0x80]
00007e4af17d17ed  vmovaps xmm9, [rsp+0x90]
00007e4af17d17f6  vmovaps xmm10, [rsp+0xA0]
00007e4af17d17ff  vmovaps xmm11, [rsp+0xB0]
00007e4af17d1808  vmovaps xmm12, [rsp+0xC0]
00007e4af17d1811  vmovaps xmm13, [rsp+0xD0]
00007e4af17d181a  vmovaps xmm14, [rsp+0xE0]
00007e4af17d1823  add rsp, 0xF0
00007e4af17d182a  pop r11
00007e4af17d182c  pop r10
00007e4af17d182e  pop r9
00007e4af17d1830  pop r8
00007e4af17d1832  pop rsi
00007e4af17d1833  pop rdi
00007e4af17d1834  pop rdx
00007e4af17d1835  pop rcx
00007e4af17d1836  pop rax
00007e4af17d1837  add rsp, 0x08
00007e4af17d183b  jmp 0x00007E4AF17CF923
00007e4af17d1840  call 0x00007E4AF15FF430
00007e4af17d1845  jmp 0x00007E4AF17CF930
00007e4af17d184a  sub rsp, 0x08
00007e4af17d184e  push rax
00007e4af17d184f  push rcx
00007e4af17d1850  push rdx
00007e4af17d1851  push rdi
00007e4af17d1852  push rsi
00007e4af17d1853  push r8
00007e4af17d1855  push r9
00007e4af17d1857  push r10
00007e4af17d1859  push r11
00007e4af17d185b  sub rsp, 0xF0
00007e4af17d1862  vmovaps [rsp], xmm0
00007e4af17d1867  vmovaps [rsp+0x10], xmm1
00007e4af17d186d  vmovaps [rsp+0x20], xmm3
00007e4af17d1873  vmovaps [rsp+0x30], xmm4
00007e4af17d1879  vmovaps [rsp+0x40], xmm5
00007e4af17d187f  vmovaps [rsp+0x50], xmm6
00007e4af17d1885  vmovaps [rsp+0x60], xmm7
00007e4af17d188b  vmovaps [rsp+0x70], xmm8
00007e4af17d1891  vmovaps [rsp+0x80], xmm9
00007e4af17d189a  vmovaps [rsp+0x90], xmm10
00007e4af17d18a3  vmovaps [rsp+0xA0], xmm11
00007e4af17d18ac  vmovaps [rsp+0xB0], xmm12
00007e4af17d18b5  vmovaps [rsp+0xC0], xmm13
00007e4af17d18be  vmovaps [rsp+0xD0], xmm14
00007e4af17d18c7  vmovaps [rsp+0xE0], xmm15
00007e4af17d18d0  sub rsp, 0x30
00007e4af17d18d4  movaps [rsp], xmm2
00007e4af17d18d8  movaps [rsp+0x10], xmm1
00007e4af17d18dd  movaps [rsp+0x20], xmm14
00007e4af17d18e3  lea rdi, [rsp]
00007e4af17d18e7  mov esi, 0x00
00007e4af17d18ec  mov rax, 0x6256754A7530
00007e4af17d18f6  call rax
00007e4af17d18f8  movaps xmm2, [rsp]
00007e4af17d18fc  add rsp, 0x30
00007e4af17d1900  vmovaps xmm0, [rsp]
00007e4af17d1905  vmovaps xmm1, [rsp+0x10]
00007e4af17d190b  vmovaps xmm3, [rsp+0x20]
00007e4af17d1911  vmovaps xmm4, [rsp+0x30]
00007e4af17d1917  vmovaps xmm5, [rsp+0x40]
00007e4af17d191d  vmovaps xmm6, [rsp+0x50]
00007e4af17d1923  vmovaps xmm7, [rsp+0x60]
00007e4af17d1929  vmovaps xmm8, [rsp+0x70]
00007e4af17d192f  vmovaps xmm9, [rsp+0x80]
00007e4af17d1938  vmovaps xmm10, [rsp+0x90]
00007e4af17d1941  vmovaps xmm11, [rsp+0xA0]
00007e4af17d194a  vmovaps xmm12, [rsp+0xB0]
00007e4af17d1953  vmovaps xmm13, [rsp+0xC0]
00007e4af17d195c  vmovaps xmm14, [rsp+0xD0]
00007e4af17d1965  vmovaps xmm15, [rsp+0xE0]
00007e4af17d196e  add rsp, 0xF0
00007e4af17d1975  pop r11
00007e4af17d1977  pop r10
00007e4af17d1979  pop r9
00007e4af17d197b  pop r8
00007e4af17d197d  pop rsi
00007e4af17d197e  pop rdi
00007e4af17d197f  pop rdx
00007e4af17d1980  pop rcx
00007e4af17d1981  pop rax
00007e4af17d1982  add rsp, 0x08
00007e4af17d1986  jmp 0x00007E4AF17CF96D
00007e4af17d198b  sub rsp, 0x08
00007e4af17d198f  push rax
00007e4af17d1990  push rcx
00007e4af17d1991  push rdx
00007e4af17d1992  push rdi
00007e4af17d1993  push rsi
00007e4af17d1994  push r8
00007e4af17d1996  push r9
00007e4af17d1998  push r10
00007e4af17d199a  push r11
00007e4af17d199c  sub rsp, 0xF0
00007e4af17d19a3  vmovaps [rsp], xmm0
00007e4af17d19a8  vmovaps [rsp+0x10], xmm1
00007e4af17d19ae  vmovaps [rsp+0x20], xmm2
00007e4af17d19b4  vmovaps [rsp+0x30], xmm3
00007e4af17d19ba  vmovaps [rsp+0x40], xmm4
00007e4af17d19c0  vmovaps [rsp+0x50], xmm5
00007e4af17d19c6  vmovaps [rsp+0x60], xmm6
00007e4af17d19cc  vmovaps [rsp+0x70], xmm7
00007e4af17d19d2  vmovaps [rsp+0x80], xmm8
00007e4af17d19db  vmovaps [rsp+0x90], xmm9
00007e4af17d19e4  vmovaps [rsp+0xA0], xmm10
00007e4af17d19ed  vmovaps [rsp+0xB0], xmm11
00007e4af17d19f6  vmovaps [rsp+0xC0], xmm12
00007e4af17d19ff  vmovaps [rsp+0xD0], xmm13
00007e4af17d1a08  vmovaps [rsp+0xE0], xmm14
00007e4af17d1a11  sub rsp, 0x30
00007e4af17d1a15  movaps [rsp], xmm15
00007e4af17d1a1a  movaps [rsp+0x10], xmm14
00007e4af17d1a20  movaps [rsp+0x20], xmm1
00007e4af17d1a25  lea rdi, [rsp]
00007e4af17d1a29  mov esi, 0x00
00007e4af17d1a2e  mov rax, 0x6256754A7530
00007e4af17d1a38  call rax
00007e4af17d1a3a  movaps xmm15, [rsp]
00007e4af17d1a3f  add rsp, 0x30
00007e4af17d1a43  vmovaps xmm0, [rsp]
00007e4af17d1a48  vmovaps xmm1, [rsp+0x10]
00007e4af17d1a4e  vmovaps xmm2, [rsp+0x20]
00007e4af17d1a54  vmovaps xmm3, [rsp+0x30]
00007e4af17d1a5a  vmovaps xmm4, [rsp+0x40]
00007e4af17d1a60  vmovaps xmm5, [rsp+0x50]
00007e4af17d1a66  vmovaps xmm6, [rsp+0x60]
00007e4af17d1a6c  vmovaps xmm7, [rsp+0x70]
00007e4af17d1a72  vmovaps xmm8, [rsp+0x80]
00007e4af17d1a7b  vmovaps xmm9, [rsp+0x90]
00007e4af17d1a84  vmovaps xmm10, [rsp+0xA0]
00007e4af17d1a8d  vmovaps xmm11, [rsp+0xB0]
00007e4af17d1a96  vmovaps xmm12, [rsp+0xC0]
00007e4af17d1a9f  vmovaps xmm13, [rsp+0xD0]
00007e4af17d1aa8  vmovaps xmm14, [rsp+0xE0]
00007e4af17d1ab1  add rsp, 0xF0
00007e4af17d1ab8  pop r11
00007e4af17d1aba  pop r10
00007e4af17d1abc  pop r9
00007e4af17d1abe  pop r8
00007e4af17d1ac0  pop rsi
00007e4af17d1ac1  pop rdi
00007e4af17d1ac2  pop rdx
00007e4af17d1ac3  pop rcx
00007e4af17d1ac4  pop rax
00007e4af17d1ac5  add rsp, 0x08
00007e4af17d1ac9  jmp 0x00007E4AF17CF9E7
00007e4af17d1ace  call 0x00007E4AF15FF430
00007e4af17d1ad3  jmp 0x00007E4AF17CF9F4
00007e4af17d1ad8  sub rsp, 0x08
00007e4af17d1adc  push rax
00007e4af17d1add  push rcx
00007e4af17d1ade  push rdx
00007e4af17d1adf  push rdi
00007e4af17d1ae0  push rsi
00007e4af17d1ae1  push r8
00007e4af17d1ae3  push r9
00007e4af17d1ae5  push r10
00007e4af17d1ae7  push r11
00007e4af17d1ae9  sub rsp, 0xF0
00007e4af17d1af0  vmovaps [rsp], xmm0
00007e4af17d1af5  vmovaps [rsp+0x10], xmm1
00007e4af17d1afb  vmovaps [rsp+0x20], xmm2
00007e4af17d1b01  vmovaps [rsp+0x30], xmm3
00007e4af17d1b07  vmovaps [rsp+0x40], xmm4
00007e4af17d1b0d  vmovaps [rsp+0x50], xmm5
00007e4af17d1b13  vmovaps [rsp+0x60], xmm6
00007e4af17d1b19  vmovaps [rsp+0x70], xmm7
00007e4af17d1b1f  vmovaps [rsp+0x80], xmm8
00007e4af17d1b28  vmovaps [rsp+0x90], xmm9
00007e4af17d1b31  vmovaps [rsp+0xA0], xmm10
00007e4af17d1b3a  vmovaps [rsp+0xB0], xmm11
00007e4af17d1b43  vmovaps [rsp+0xC0], xmm12
00007e4af17d1b4c  vmovaps [rsp+0xD0], xmm13
00007e4af17d1b55  vmovaps [rsp+0xE0], xmm15
00007e4af17d1b5e  sub rsp, 0x30
00007e4af17d1b62  movaps [rsp], xmm14
00007e4af17d1b67  movaps [rsp+0x10], xmm13
00007e4af17d1b6d  movaps [rsp+0x20], xmm1
00007e4af17d1b72  lea rdi, [rsp]
00007e4af17d1b76  mov esi, 0x00
00007e4af17d1b7b  mov rax, 0x6256754A7530
00007e4af17d1b85  call rax
00007e4af17d1b87  movaps xmm14, [rsp]
00007e4af17d1b8c  add rsp, 0x30
00007e4af17d1b90  vmovaps xmm0, [rsp]
00007e4af17d1b95  vmovaps xmm1, [rsp+0x10]
00007e4af17d1b9b  vmovaps xmm2, [rsp+0x20]
00007e4af17d1ba1  vmovaps xmm3, [rsp+0x30]
00007e4af17d1ba7  vmovaps xmm4, [rsp+0x40]
00007e4af17d1bad  vmovaps xmm5, [rsp+0x50]
00007e4af17d1bb3  vmovaps xmm6, [rsp+0x60]
00007e4af17d1bb9  vmovaps xmm7, [rsp+0x70]
00007e4af17d1bbf  vmovaps xmm8, [rsp+0x80]
00007e4af17d1bc8  vmovaps xmm9, [rsp+0x90]
00007e4af17d1bd1  vmovaps xmm10, [rsp+0xA0]
00007e4af17d1bda  vmovaps xmm11, [rsp+0xB0]
00007e4af17d1be3  vmovaps xmm12, [rsp+0xC0]
00007e4af17d1bec  vmovaps xmm13, [rsp+0xD0]
00007e4af17d1bf5  vmovaps xmm15, [rsp+0xE0]
00007e4af17d1bfe  add rsp, 0xF0
00007e4af17d1c05  pop r11
00007e4af17d1c07  pop r10
00007e4af17d1c09  pop r9
00007e4af17d1c0b  pop r8
00007e4af17d1c0d  pop rsi
00007e4af17d1c0e  pop rdi
00007e4af17d1c0f  pop rdx
00007e4af17d1c10  pop rcx
00007e4af17d1c11  pop rax
00007e4af17d1c12  add rsp, 0x08
00007e4af17d1c16  jmp 0x00007E4AF17CFAAF
00007e4af17d1c1b  sub rsp, 0x08
00007e4af17d1c1f  push rax
00007e4af17d1c20  push rcx
00007e4af17d1c21  push rdx
00007e4af17d1c22  push rdi
00007e4af17d1c23  push rsi
00007e4af17d1c24  push r8
00007e4af17d1c26  push r9
00007e4af17d1c28  push r10
00007e4af17d1c2a  push r11
00007e4af17d1c2c  sub rsp, 0xF0
00007e4af17d1c33  vmovaps [rsp], xmm0
00007e4af17d1c38  vmovaps [rsp+0x10], xmm1
00007e4af17d1c3e  vmovaps [rsp+0x20], xmm2
00007e4af17d1c44  vmovaps [rsp+0x30], xmm3
00007e4af17d1c4a  vmovaps [rsp+0x40], xmm4
00007e4af17d1c50  vmovaps [rsp+0x50], xmm5
00007e4af17d1c56  vmovaps [rsp+0x60], xmm6
00007e4af17d1c5c  vmovaps [rsp+0x70], xmm7
00007e4af17d1c62  vmovaps [rsp+0x80], xmm8
00007e4af17d1c6b  vmovaps [rsp+0x90], xmm9
00007e4af17d1c74  vmovaps [rsp+0xA0], xmm10
00007e4af17d1c7d  vmovaps [rsp+0xB0], xmm11
00007e4af17d1c86  vmovaps [rsp+0xC0], xmm12
00007e4af17d1c8f  vmovaps [rsp+0xD0], xmm13
00007e4af17d1c98  vmovaps [rsp+0xE0], xmm14
00007e4af17d1ca1  sub rsp, 0x30
00007e4af17d1ca5  movaps [rsp], xmm15
00007e4af17d1caa  movaps [rsp+0x10], xmm13
00007e4af17d1cb0  movaps [rsp+0x20], xmm1
00007e4af17d1cb5  lea rdi, [rsp]
00007e4af17d1cb9  mov esi, 0x00
00007e4af17d1cbe  mov rax, 0x6256754A7530
00007e4af17d1cc8  call rax
00007e4af17d1cca  movaps xmm15, [rsp]
00007e4af17d1ccf  add rsp, 0x30
00007e4af17d1cd3  vmovaps xmm0, [rsp]
00007e4af17d1cd8  vmovaps xmm1, [rsp+0x10]
00007e4af17d1cde  vmovaps xmm2, [rsp+0x20]
00007e4af17d1ce4  vmovaps xmm3, [rsp+0x30]
00007e4af17d1cea  vmovaps xmm4, [rsp+0x40]
00007e4af17d1cf0  vmovaps xmm5, [rsp+0x50]
00007e4af17d1cf6  vmovaps xmm6, [rsp+0x60]
00007e4af17d1cfc  vmovaps xmm7, [rsp+0x70]
00007e4af17d1d02  vmovaps xmm8, [rsp+0x80]
00007e4af17d1d0b  vmovaps xmm9, [rsp+0x90]
00007e4af17d1d14  vmovaps xmm10, [rsp+0xA0]
00007e4af17d1d1d  vmovaps xmm11, [rsp+0xB0]
00007e4af17d1d26  vmovaps xmm12, [rsp+0xC0]
00007e4af17d1d2f  vmovaps xmm13, [rsp+0xD0]
00007e4af17d1d38  vmovaps xmm14, [rsp+0xE0]
00007e4af17d1d41  add rsp, 0xF0
00007e4af17d1d48  pop r11
00007e4af17d1d4a  pop r10
00007e4af17d1d4c  pop r9
00007e4af17d1d4e  pop r8
00007e4af17d1d50  pop rsi
00007e4af17d1d51  pop rdi
00007e4af17d1d52  pop rdx
00007e4af17d1d53  pop rcx
00007e4af17d1d54  pop rax
00007e4af17d1d55  add rsp, 0x08
00007e4af17d1d59  jmp 0x00007E4AF17CFAEB
00007e4af17d1d5e  call 0x00007E4AF15FF430
00007e4af17d1d63  jmp 0x00007E4AF17CFAF8
00007e4af17d1d68  sub rsp, 0x08
00007e4af17d1d6c  push rax
00007e4af17d1d6d  push rcx
00007e4af17d1d6e  push rdx
00007e4af17d1d6f  push rdi
00007e4af17d1d70  push rsi
00007e4af17d1d71  push r8
00007e4af17d1d73  push r9
00007e4af17d1d75  push r10
00007e4af17d1d77  push r11
00007e4af17d1d79  sub rsp, 0xF0
00007e4af17d1d80  vmovaps [rsp], xmm0
00007e4af17d1d85  vmovaps [rsp+0x10], xmm1
00007e4af17d1d8b  vmovaps [rsp+0x20], xmm2
00007e4af17d1d91  vmovaps [rsp+0x30], xmm3
00007e4af17d1d97  vmovaps [rsp+0x40], xmm4
00007e4af17d1d9d  vmovaps [rsp+0x50], xmm5
00007e4af17d1da3  vmovaps [rsp+0x60], xmm6
00007e4af17d1da9  vmovaps [rsp+0x70], xmm7
00007e4af17d1daf  vmovaps [rsp+0x80], xmm8
00007e4af17d1db8  vmovaps [rsp+0x90], xmm9
00007e4af17d1dc1  vmovaps [rsp+0xA0], xmm10
00007e4af17d1dca  vmovaps [rsp+0xB0], xmm11
00007e4af17d1dd3  vmovaps [rsp+0xC0], xmm12
00007e4af17d1ddc  vmovaps [rsp+0xD0], xmm13
00007e4af17d1de5  vmovaps [rsp+0xE0], xmm15
00007e4af17d1dee  sub rsp, 0x30
00007e4af17d1df2  movaps [rsp], xmm14
00007e4af17d1df7  movaps [rsp+0x10], xmm13
00007e4af17d1dfd  movaps [rsp+0x20], xmm2
00007e4af17d1e02  lea rdi, [rsp]
00007e4af17d1e06  mov esi, 0x00
00007e4af17d1e0b  mov rax, 0x6256754A7530
00007e4af17d1e15  call rax
00007e4af17d1e17  movaps xmm14, [rsp]
00007e4af17d1e1c  add rsp, 0x30
00007e4af17d1e20  vmovaps xmm0, [rsp]
00007e4af17d1e25  vmovaps xmm1, [rsp+0x10]
00007e4af17d1e2b  vmovaps xmm2, [rsp+0x20]
00007e4af17d1e31  vmovaps xmm3, [rsp+0x30]
00007e4af17d1e37  vmovaps xmm4, [rsp+0x40]
00007e4af17d1e3d  vmovaps xmm5, [rsp+0x50]
00007e4af17d1e43  vmovaps xmm6, [rsp+0x60]
00007e4af17d1e49  vmovaps xmm7, [rsp+0x70]
00007e4af17d1e4f  vmovaps xmm8, [rsp+0x80]
00007e4af17d1e58  vmovaps xmm9, [rsp+0x90]
00007e4af17d1e61  vmovaps xmm10, [rsp+0xA0]
00007e4af17d1e6a  vmovaps xmm11, [rsp+0xB0]
00007e4af17d1e73  vmovaps xmm12, [rsp+0xC0]
00007e4af17d1e7c  vmovaps xmm13, [rsp+0xD0]
00007e4af17d1e85  vmovaps xmm15, [rsp+0xE0]
00007e4af17d1e8e  add rsp, 0xF0
00007e4af17d1e95  pop r11
00007e4af17d1e97  pop r10
00007e4af17d1e99  pop r9
00007e4af17d1e9b  pop r8
00007e4af17d1e9d  pop rsi
00007e4af17d1e9e  pop rdi
00007e4af17d1e9f  pop rdx
00007e4af17d1ea0  pop rcx
00007e4af17d1ea1  pop rax
00007e4af17d1ea2  add rsp, 0x08
00007e4af17d1ea6  jmp 0x00007E4AF17CFB24
00007e4af17d1eab  sub rsp, 0x08
00007e4af17d1eaf  push rax
00007e4af17d1eb0  push rcx
00007e4af17d1eb1  push rdx
00007e4af17d1eb2  push rdi
00007e4af17d1eb3  push rsi
00007e4af17d1eb4  push r8
00007e4af17d1eb6  push r9
00007e4af17d1eb8  push r10
00007e4af17d1eba  push r11
00007e4af17d1ebc  sub rsp, 0xF0
00007e4af17d1ec3  vmovaps [rsp], xmm0
00007e4af17d1ec8  vmovaps [rsp+0x10], xmm2
00007e4af17d1ece  vmovaps [rsp+0x20], xmm3
00007e4af17d1ed4  vmovaps [rsp+0x30], xmm4
00007e4af17d1eda  vmovaps [rsp+0x40], xmm5
00007e4af17d1ee0  vmovaps [rsp+0x50], xmm6
00007e4af17d1ee6  vmovaps [rsp+0x60], xmm7
00007e4af17d1eec  vmovaps [rsp+0x70], xmm8
00007e4af17d1ef2  vmovaps [rsp+0x80], xmm9
00007e4af17d1efb  vmovaps [rsp+0x90], xmm10
00007e4af17d1f04  vmovaps [rsp+0xA0], xmm11
00007e4af17d1f0d  vmovaps [rsp+0xB0], xmm12
00007e4af17d1f16  vmovaps [rsp+0xC0], xmm13
00007e4af17d1f1f  vmovaps [rsp+0xD0], xmm14
00007e4af17d1f28  vmovaps [rsp+0xE0], xmm15
00007e4af17d1f31  sub rsp, 0x30
00007e4af17d1f35  movaps [rsp], xmm1
00007e4af17d1f39  movaps [rsp+0x10], xmm13
00007e4af17d1f3f  movaps [rsp+0x20], xmm2
00007e4af17d1f44  lea rdi, [rsp]
00007e4af17d1f48  mov esi, 0x00
00007e4af17d1f4d  mov rax, 0x6256754A7530
00007e4af17d1f57  call rax
00007e4af17d1f59  movaps xmm1, [rsp]
00007e4af17d1f5d  add rsp, 0x30
00007e4af17d1f61  vmovaps xmm0, [rsp]
00007e4af17d1f66  vmovaps xmm2, [rsp+0x10]
00007e4af17d1f6c  vmovaps xmm3, [rsp+0x20]
00007e4af17d1f72  vmovaps xmm4, [rsp+0x30]
00007e4af17d1f78  vmovaps xmm5, [rsp+0x40]
00007e4af17d1f7e  vmovaps xmm6, [rsp+0x50]
00007e4af17d1f84  vmovaps xmm7, [rsp+0x60]
00007e4af17d1f8a  vmovaps xmm8, [rsp+0x70]
00007e4af17d1f90  vmovaps xmm9, [rsp+0x80]
00007e4af17d1f99  vmovaps xmm10, [rsp+0x90]
00007e4af17d1fa2  vmovaps xmm11, [rsp+0xA0]
00007e4af17d1fab  vmovaps xmm12, [rsp+0xB0]
00007e4af17d1fb4  vmovaps xmm13, [rsp+0xC0]
00007e4af17d1fbd  vmovaps xmm14, [rsp+0xD0]
00007e4af17d1fc6  vmovaps xmm15, [rsp+0xE0]
00007e4af17d1fcf  add rsp, 0xF0
00007e4af17d1fd6  pop r11
00007e4af17d1fd8  pop r10
00007e4af17d1fda  pop r9
00007e4af17d1fdc  pop r8
00007e4af17d1fde  pop rsi
00007e4af17d1fdf  pop rdi
00007e4af17d1fe0  pop rdx
00007e4af17d1fe1  pop rcx
00007e4af17d1fe2  pop rax
00007e4af17d1fe3  add rsp, 0x08
00007e4af17d1fe7  jmp 0x00007E4AF17CFB52
00007e4af17d1fec  sub rsp, 0x08
00007e4af17d1ff0  push rax
00007e4af17d1ff1  push rcx
00007e4af17d1ff2  push rdx
00007e4af17d1ff3  push rdi
00007e4af17d1ff4  push rsi
00007e4af17d1ff5  push r8
00007e4af17d1ff7  push r9
00007e4af17d1ff9  push r10
00007e4af17d1ffb  push r11
00007e4af17d1ffd  sub rsp, 0xF0
00007e4af17d2004  vmovaps [rsp], xmm0
00007e4af17d2009  vmovaps [rsp+0x10], xmm1
00007e4af17d200f  vmovaps [rsp+0x20], xmm3
00007e4af17d2015  vmovaps [rsp+0x30], xmm4
00007e4af17d201b  vmovaps [rsp+0x40], xmm5
00007e4af17d2021  vmovaps [rsp+0x50], xmm6
00007e4af17d2027  vmovaps [rsp+0x60], xmm7
00007e4af17d202d  vmovaps [rsp+0x70], xmm8
00007e4af17d2033  vmovaps [rsp+0x80], xmm9
00007e4af17d203c  vmovaps [rsp+0x90], xmm10
00007e4af17d2045  vmovaps [rsp+0xA0], xmm11
00007e4af17d204e  vmovaps [rsp+0xB0], xmm12
00007e4af17d2057  vmovaps [rsp+0xC0], xmm13
00007e4af17d2060  vmovaps [rsp+0xD0], xmm14
00007e4af17d2069  vmovaps [rsp+0xE0], xmm15
00007e4af17d2072  sub rsp, 0x30
00007e4af17d2076  movaps [rsp], xmm2
00007e4af17d207a  movaps [rsp+0x10], xmm1
00007e4af17d207f  movaps [rsp+0x20], xmm13
00007e4af17d2085  lea rdi, [rsp]
00007e4af17d2089  mov esi, 0x00
00007e4af17d208e  mov rax, 0x6256754A7530
00007e4af17d2098  call rax
00007e4af17d209a  movaps xmm2, [rsp]
00007e4af17d209e  add rsp, 0x30
00007e4af17d20a2  vmovaps xmm0, [rsp]
00007e4af17d20a7  vmovaps xmm1, [rsp+0x10]
00007e4af17d20ad  vmovaps xmm3, [rsp+0x20]
00007e4af17d20b3  vmovaps xmm4, [rsp+0x30]
00007e4af17d20b9  vmovaps xmm5, [rsp+0x40]
00007e4af17d20bf  vmovaps xmm6, [rsp+0x50]
00007e4af17d20c5  vmovaps xmm7, [rsp+0x60]
00007e4af17d20cb  vmovaps xmm8, [rsp+0x70]
00007e4af17d20d1  vmovaps xmm9, [rsp+0x80]
00007e4af17d20da  vmovaps xmm10, [rsp+0x90]
00007e4af17d20e3  vmovaps xmm11, [rsp+0xA0]
00007e4af17d20ec  vmovaps xmm12, [rsp+0xB0]
00007e4af17d20f5  vmovaps xmm13, [rsp+0xC0]
00007e4af17d20fe  vmovaps xmm14, [rsp+0xD0]
00007e4af17d2107  vmovaps xmm15, [rsp+0xE0]
00007e4af17d2110  add rsp, 0xF0
00007e4af17d2117  pop r11
00007e4af17d2119  pop r10
00007e4af17d211b  pop r9
00007e4af17d211d  pop r8
00007e4af17d211f  pop rsi
00007e4af17d2120  pop rdi
00007e4af17d2121  pop rdx
00007e4af17d2122  pop rcx
00007e4af17d2123  pop rax
00007e4af17d2124  add rsp, 0x08
00007e4af17d2128  jmp 0x00007E4AF17CFBAB
00007e4af17d212d  call 0x00007E4AF15FF430
00007e4af17d2132  jmp 0x00007E4AF17CFBB8
00007e4af17d2137  sub rsp, 0x08
00007e4af17d213b  push rax
00007e4af17d213c  push rcx
00007e4af17d213d  push rdx
00007e4af17d213e  push rdi
00007e4af17d213f  push rsi
00007e4af17d2140  push r8
00007e4af17d2142  push r9
00007e4af17d2144  push r10
00007e4af17d2146  push r11
00007e4af17d2148  sub rsp, 0xF0
00007e4af17d214f  vmovaps [rsp], xmm0
00007e4af17d2154  vmovaps [rsp+0x10], xmm1
00007e4af17d215a  vmovaps [rsp+0x20], xmm2
00007e4af17d2160  vmovaps [rsp+0x30], xmm3
00007e4af17d2166  vmovaps [rsp+0x40], xmm4
00007e4af17d216c  vmovaps [rsp+0x50], xmm5
00007e4af17d2172  vmovaps [rsp+0x60], xmm6
00007e4af17d2178  vmovaps [rsp+0x70], xmm7
00007e4af17d217e  vmovaps [rsp+0x80], xmm8
00007e4af17d2187  vmovaps [rsp+0x90], xmm9
00007e4af17d2190  vmovaps [rsp+0xA0], xmm10
00007e4af17d2199  vmovaps [rsp+0xB0], xmm11
00007e4af17d21a2  vmovaps [rsp+0xC0], xmm12
00007e4af17d21ab  vmovaps [rsp+0xD0], xmm13
00007e4af17d21b4  vmovaps [rsp+0xE0], xmm14
00007e4af17d21bd  sub rsp, 0x30
00007e4af17d21c1  movaps [rsp], xmm15
00007e4af17d21c6  movaps [rsp+0x10], xmm13
00007e4af17d21cc  movaps [rsp+0x20], xmm1
00007e4af17d21d1  lea rdi, [rsp]
00007e4af17d21d5  mov esi, 0x00
00007e4af17d21da  mov rax, 0x6256754A7530
00007e4af17d21e4  call rax
00007e4af17d21e6  movaps xmm15, [rsp]
00007e4af17d21eb  add rsp, 0x30
00007e4af17d21ef  vmovaps xmm0, [rsp]
00007e4af17d21f4  vmovaps xmm1, [rsp+0x10]
00007e4af17d21fa  vmovaps xmm2, [rsp+0x20]
00007e4af17d2200  vmovaps xmm3, [rsp+0x30]
00007e4af17d2206  vmovaps xmm4, [rsp+0x40]
00007e4af17d220c  vmovaps xmm5, [rsp+0x50]
00007e4af17d2212  vmovaps xmm6, [rsp+0x60]
00007e4af17d2218  vmovaps xmm7, [rsp+0x70]
00007e4af17d221e  vmovaps xmm8, [rsp+0x80]
00007e4af17d2227  vmovaps xmm9, [rsp+0x90]
00007e4af17d2230  vmovaps xmm10, [rsp+0xA0]
00007e4af17d2239  vmovaps xmm11, [rsp+0xB0]
00007e4af17d2242  vmovaps xmm12, [rsp+0xC0]
00007e4af17d224b  vmovaps xmm13, [rsp+0xD0]
00007e4af17d2254  vmovaps xmm14, [rsp+0xE0]
00007e4af17d225d  add rsp, 0xF0
00007e4af17d2264  pop r11
00007e4af17d2266  pop r10
00007e4af17d2268  pop r9
00007e4af17d226a  pop r8
00007e4af17d226c  pop rsi
00007e4af17d226d  pop rdi
00007e4af17d226e  pop rdx
00007e4af17d226f  pop rcx
00007e4af17d2270  pop rax
00007e4af17d2271  add rsp, 0x08
00007e4af17d2275  jmp 0x00007E4AF17CFBF7
00007e4af17d227a  sub rsp, 0x08
00007e4af17d227e  push rax
00007e4af17d227f  push rcx
00007e4af17d2280  push rdx
00007e4af17d2281  push rdi
00007e4af17d2282  push rsi
00007e4af17d2283  push r8
00007e4af17d2285  push r9
00007e4af17d2287  push r10
00007e4af17d2289  push r11
00007e4af17d228b  sub rsp, 0xF0
00007e4af17d2292  vmovaps [rsp], xmm0
00007e4af17d2297  vmovaps [rsp+0x10], xmm1
00007e4af17d229d  vmovaps [rsp+0x20], xmm2
00007e4af17d22a3  vmovaps [rsp+0x30], xmm3
00007e4af17d22a9  vmovaps [rsp+0x40], xmm4
00007e4af17d22af  vmovaps [rsp+0x50], xmm5
00007e4af17d22b5  vmovaps [rsp+0x60], xmm6
00007e4af17d22bb  vmovaps [rsp+0x70], xmm7
00007e4af17d22c1  vmovaps [rsp+0x80], xmm8
00007e4af17d22ca  vmovaps [rsp+0x90], xmm9
00007e4af17d22d3  vmovaps [rsp+0xA0], xmm10
00007e4af17d22dc  vmovaps [rsp+0xB0], xmm11
00007e4af17d22e5  vmovaps [rsp+0xC0], xmm12
00007e4af17d22ee  vmovaps [rsp+0xD0], xmm13
00007e4af17d22f7  vmovaps [rsp+0xE0], xmm15
00007e4af17d2300  sub rsp, 0x30
00007e4af17d2304  movaps [rsp], xmm14
00007e4af17d2309  movaps [rsp+0x10], xmm11
00007e4af17d230f  movaps [rsp+0x20], xmm1
00007e4af17d2314  lea rdi, [rsp]
00007e4af17d2318  mov esi, 0x00
00007e4af17d231d  mov rax, 0x6256754A7530
00007e4af17d2327  call rax
00007e4af17d2329  movaps xmm14, [rsp]
00007e4af17d232e  add rsp, 0x30
00007e4af17d2332  vmovaps xmm0, [rsp]
00007e4af17d2337  vmovaps xmm1, [rsp+0x10]
00007e4af17d233d  vmovaps xmm2, [rsp+0x20]
00007e4af17d2343  vmovaps xmm3, [rsp+0x30]
00007e4af17d2349  vmovaps xmm4, [rsp+0x40]
00007e4af17d234f  vmovaps xmm5, [rsp+0x50]
00007e4af17d2355  vmovaps xmm6, [rsp+0x60]
00007e4af17d235b  vmovaps xmm7, [rsp+0x70]
00007e4af17d2361  vmovaps xmm8, [rsp+0x80]
00007e4af17d236a  vmovaps xmm9, [rsp+0x90]
00007e4af17d2373  vmovaps xmm10, [rsp+0xA0]
00007e4af17d237c  vmovaps xmm11, [rsp+0xB0]
00007e4af17d2385  vmovaps xmm12, [rsp+0xC0]
00007e4af17d238e  vmovaps xmm13, [rsp+0xD0]
00007e4af17d2397  vmovaps xmm15, [rsp+0xE0]
00007e4af17d23a0  add rsp, 0xF0
00007e4af17d23a7  pop r11
00007e4af17d23a9  pop r10
00007e4af17d23ab  pop r9
00007e4af17d23ad  pop r8
00007e4af17d23af  pop rsi
00007e4af17d23b0  pop rdi
00007e4af17d23b1  pop rdx
00007e4af17d23b2  pop rcx
00007e4af17d23b3  pop rax
00007e4af17d23b4  add rsp, 0x08
00007e4af17d23b8  jmp 0x00007E4AF17CFC21
00007e4af17d23bd  sub rsp, 0x08
00007e4af17d23c1  push rax
00007e4af17d23c2  push rcx
00007e4af17d23c3  push rdx
00007e4af17d23c4  push rdi
00007e4af17d23c5  push rsi
00007e4af17d23c6  push r8
00007e4af17d23c8  push r9
00007e4af17d23ca  push r10
00007e4af17d23cc  push r11
00007e4af17d23ce  sub rsp, 0xF0
00007e4af17d23d5  vmovaps [rsp], xmm0
00007e4af17d23da  vmovaps [rsp+0x10], xmm1
00007e4af17d23e0  vmovaps [rsp+0x20], xmm2
00007e4af17d23e6  vmovaps [rsp+0x30], xmm3
00007e4af17d23ec  vmovaps [rsp+0x40], xmm4
00007e4af17d23f2  vmovaps [rsp+0x50], xmm5
00007e4af17d23f8  vmovaps [rsp+0x60], xmm6
00007e4af17d23fe  vmovaps [rsp+0x70], xmm7
00007e4af17d2404  vmovaps [rsp+0x80], xmm8
00007e4af17d240d  vmovaps [rsp+0x90], xmm9
00007e4af17d2416  vmovaps [rsp+0xA0], xmm10
00007e4af17d241f  vmovaps [rsp+0xB0], xmm11
00007e4af17d2428  vmovaps [rsp+0xC0], xmm12
00007e4af17d2431  vmovaps [rsp+0xD0], xmm14
00007e4af17d243a  vmovaps [rsp+0xE0], xmm15
00007e4af17d2443  sub rsp, 0x30
00007e4af17d2447  movaps [rsp], xmm13
00007e4af17d244c  movaps [rsp+0x10], xmm11
00007e4af17d2452  movaps [rsp+0x20], xmm1
00007e4af17d2457  lea rdi, [rsp]
00007e4af17d245b  mov esi, 0x00
00007e4af17d2460  mov rax, 0x6256754A7530
00007e4af17d246a  call rax
00007e4af17d246c  movaps xmm13, [rsp]
00007e4af17d2471  add rsp, 0x30
00007e4af17d2475  vmovaps xmm0, [rsp]
00007e4af17d247a  vmovaps xmm1, [rsp+0x10]
00007e4af17d2480  vmovaps xmm2, [rsp+0x20]
00007e4af17d2486  vmovaps xmm3, [rsp+0x30]
00007e4af17d248c  vmovaps xmm4, [rsp+0x40]
00007e4af17d2492  vmovaps xmm5, [rsp+0x50]
00007e4af17d2498  vmovaps xmm6, [rsp+0x60]
00007e4af17d249e  vmovaps xmm7, [rsp+0x70]
00007e4af17d24a4  vmovaps xmm8, [rsp+0x80]
00007e4af17d24ad  vmovaps xmm9, [rsp+0x90]
00007e4af17d24b6  vmovaps xmm10, [rsp+0xA0]
00007e4af17d24bf  vmovaps xmm11, [rsp+0xB0]
00007e4af17d24c8  vmovaps xmm12, [rsp+0xC0]
00007e4af17d24d1  vmovaps xmm14, [rsp+0xD0]
00007e4af17d24da  vmovaps xmm15, [rsp+0xE0]
00007e4af17d24e3  add rsp, 0xF0
00007e4af17d24ea  pop r11
00007e4af17d24ec  pop r10
00007e4af17d24ee  pop r9
00007e4af17d24f0  pop r8
00007e4af17d24f2  pop rsi
00007e4af17d24f3  pop rdi
00007e4af17d24f4  pop rdx
00007e4af17d24f5  pop rcx
00007e4af17d24f6  pop rax
00007e4af17d24f7  add rsp, 0x08
00007e4af17d24fb  jmp 0x00007E4AF17CFC76
00007e4af17d2500  call 0x00007E4AF15FF430
00007e4af17d2505  jmp 0x00007E4AF17CFC83
00007e4af17d250a  sub rsp, 0x08
00007e4af17d250e  push rax
00007e4af17d250f  push rcx
00007e4af17d2510  push rdx
00007e4af17d2511  push rdi
00007e4af17d2512  push rsi
00007e4af17d2513  push r8
00007e4af17d2515  push r9
00007e4af17d2517  push r10
00007e4af17d2519  push r11
00007e4af17d251b  sub rsp, 0xF0
00007e4af17d2522  vmovaps [rsp], xmm0
00007e4af17d2527  vmovaps [rsp+0x10], xmm1
00007e4af17d252d  vmovaps [rsp+0x20], xmm2
00007e4af17d2533  vmovaps [rsp+0x30], xmm3
00007e4af17d2539  vmovaps [rsp+0x40], xmm4
00007e4af17d253f  vmovaps [rsp+0x50], xmm5
00007e4af17d2545  vmovaps [rsp+0x60], xmm6
00007e4af17d254b  vmovaps [rsp+0x70], xmm7
00007e4af17d2551  vmovaps [rsp+0x80], xmm8
00007e4af17d255a  vmovaps [rsp+0x90], xmm9
00007e4af17d2563  vmovaps [rsp+0xA0], xmm10
00007e4af17d256c  vmovaps [rsp+0xB0], xmm11
00007e4af17d2575  vmovaps [rsp+0xC0], xmm12
00007e4af17d257e  vmovaps [rsp+0xD0], xmm13
00007e4af17d2587  vmovaps [rsp+0xE0], xmm14
00007e4af17d2590  sub rsp, 0x30
00007e4af17d2594  movaps [rsp], xmm15
00007e4af17d2599  movaps [rsp+0x10], xmm11
00007e4af17d259f  movaps [rsp+0x20], xmm1
00007e4af17d25a4  lea rdi, [rsp]
00007e4af17d25a8  mov esi, 0x00
00007e4af17d25ad  mov rax, 0x6256754A7530
00007e4af17d25b7  call rax
00007e4af17d25b9  movaps xmm15, [rsp]
00007e4af17d25be  add rsp, 0x30
00007e4af17d25c2  vmovaps xmm0, [rsp]
00007e4af17d25c7  vmovaps xmm1, [rsp+0x10]
00007e4af17d25cd  vmovaps xmm2, [rsp+0x20]
00007e4af17d25d3  vmovaps xmm3, [rsp+0x30]
00007e4af17d25d9  vmovaps xmm4, [rsp+0x40]
00007e4af17d25df  vmovaps xmm5, [rsp+0x50]
00007e4af17d25e5  vmovaps xmm6, [rsp+0x60]
00007e4af17d25eb  vmovaps xmm7, [rsp+0x70]
00007e4af17d25f1  vmovaps xmm8, [rsp+0x80]
00007e4af17d25fa  vmovaps xmm9, [rsp+0x90]
00007e4af17d2603  vmovaps xmm10, [rsp+0xA0]
00007e4af17d260c  vmovaps xmm11, [rsp+0xB0]
00007e4af17d2615  vmovaps xmm12, [rsp+0xC0]
00007e4af17d261e  vmovaps xmm13, [rsp+0xD0]
00007e4af17d2627  vmovaps xmm14, [rsp+0xE0]
00007e4af17d2630  add rsp, 0xF0
00007e4af17d2637  pop r11
00007e4af17d2639  pop r10
00007e4af17d263b  pop r9
00007e4af17d263d  pop r8
00007e4af17d263f  pop rsi
00007e4af17d2640  pop rdi
00007e4af17d2641  pop rdx
00007e4af17d2642  pop rcx
00007e4af17d2643  pop rax
00007e4af17d2644  add rsp, 0x08
00007e4af17d2648  jmp 0x00007E4AF17CFCBC
00007e4af17d264d  sub rsp, 0x08
00007e4af17d2651  push rax
00007e4af17d2652  push rcx
00007e4af17d2653  push rdx
00007e4af17d2654  push rdi
00007e4af17d2655  push rsi
00007e4af17d2656  push r8
00007e4af17d2658  push r9
00007e4af17d265a  push r10
00007e4af17d265c  push r11
00007e4af17d265e  sub rsp, 0xF0
00007e4af17d2665  vmovaps [rsp], xmm0
00007e4af17d266a  vmovaps [rsp+0x10], xmm1
00007e4af17d2670  vmovaps [rsp+0x20], xmm2
00007e4af17d2676  vmovaps [rsp+0x30], xmm3
00007e4af17d267c  vmovaps [rsp+0x40], xmm4
00007e4af17d2682  vmovaps [rsp+0x50], xmm5
00007e4af17d2688  vmovaps [rsp+0x60], xmm6
00007e4af17d268e  vmovaps [rsp+0x70], xmm7
00007e4af17d2694  vmovaps [rsp+0x80], xmm8
00007e4af17d269d  vmovaps [rsp+0x90], xmm9
00007e4af17d26a6  vmovaps [rsp+0xA0], xmm10
00007e4af17d26af  vmovaps [rsp+0xB0], xmm12
00007e4af17d26b8  vmovaps [rsp+0xC0], xmm13
00007e4af17d26c1  vmovaps [rsp+0xD0], xmm14
00007e4af17d26ca  vmovaps [rsp+0xE0], xmm15
00007e4af17d26d3  sub rsp, 0x30
00007e4af17d26d7  movaps [rsp], xmm11
00007e4af17d26dc  movaps [rsp+0x10], xmm6
00007e4af17d26e1  movaps [rsp+0x20], xmm14
00007e4af17d26e7  lea rdi, [rsp]
00007e4af17d26eb  mov esi, 0x00
00007e4af17d26f0  mov rax, 0x6256754A7530
00007e4af17d26fa  call rax
00007e4af17d26fc  movaps xmm11, [rsp]
00007e4af17d2701  add rsp, 0x30
00007e4af17d2705  vmovaps xmm0, [rsp]
00007e4af17d270a  vmovaps xmm1, [rsp+0x10]
00007e4af17d2710  vmovaps xmm2, [rsp+0x20]
00007e4af17d2716  vmovaps xmm3, [rsp+0x30]
00007e4af17d271c  vmovaps xmm4, [rsp+0x40]
00007e4af17d2722  vmovaps xmm5, [rsp+0x50]
00007e4af17d2728  vmovaps xmm6, [rsp+0x60]
00007e4af17d272e  vmovaps xmm7, [rsp+0x70]
00007e4af17d2734  vmovaps xmm8, [rsp+0x80]
00007e4af17d273d  vmovaps xmm9, [rsp+0x90]
00007e4af17d2746  vmovaps xmm10, [rsp+0xA0]
00007e4af17d274f  vmovaps xmm12, [rsp+0xB0]
00007e4af17d2758  vmovaps xmm13, [rsp+0xC0]
00007e4af17d2761  vmovaps xmm14, [rsp+0xD0]
00007e4af17d276a  vmovaps xmm15, [rsp+0xE0]
00007e4af17d2773  add rsp, 0xF0
00007e4af17d277a  pop r11
00007e4af17d277c  pop r10
00007e4af17d277e  pop r9
00007e4af17d2780  pop r8
00007e4af17d2782  pop rsi
00007e4af17d2783  pop rdi
00007e4af17d2784  pop rdx
00007e4af17d2785  pop rcx
00007e4af17d2786  pop rax
00007e4af17d2787  add rsp, 0x08
00007e4af17d278b  jmp 0x00007E4AF17CFD34
00007e4af17d2790  call 0x00007E4AF15FF430
00007e4af17d2795  jmp 0x00007E4AF17CFD3E
00007e4af17d279a  sub rsp, 0x08
00007e4af17d279e  push rax
00007e4af17d279f  push rcx
00007e4af17d27a0  push rdx
00007e4af17d27a1  push rdi
00007e4af17d27a2  push rsi
00007e4af17d27a3  push r8
00007e4af17d27a5  push r9
00007e4af17d27a7  push r10
00007e4af17d27a9  push r11
00007e4af17d27ab  sub rsp, 0xF0
00007e4af17d27b2  vmovaps [rsp], xmm0
00007e4af17d27b7  vmovaps [rsp+0x10], xmm1
00007e4af17d27bd  vmovaps [rsp+0x20], xmm2
00007e4af17d27c3  vmovaps [rsp+0x30], xmm3
00007e4af17d27c9  vmovaps [rsp+0x40], xmm4
00007e4af17d27cf  vmovaps [rsp+0x50], xmm5
00007e4af17d27d5  vmovaps [rsp+0x60], xmm6
00007e4af17d27db  vmovaps [rsp+0x70], xmm7
00007e4af17d27e1  vmovaps [rsp+0x80], xmm8
00007e4af17d27ea  vmovaps [rsp+0x90], xmm9
00007e4af17d27f3  vmovaps [rsp+0xA0], xmm10
00007e4af17d27fc  vmovaps [rsp+0xB0], xmm11
00007e4af17d2805  vmovaps [rsp+0xC0], xmm12
00007e4af17d280e  vmovaps [rsp+0xD0], xmm13
00007e4af17d2817  vmovaps [rsp+0xE0], xmm15
00007e4af17d2820  sub rsp, 0x30
00007e4af17d2824  movaps [rsp], xmm14
00007e4af17d2829  movaps [rsp+0x10], xmm6
00007e4af17d282e  movaps [rsp+0x20], xmm2
00007e4af17d2833  lea rdi, [rsp]
00007e4af17d2837  mov esi, 0x00
00007e4af17d283c  mov rax, 0x6256754A7530
00007e4af17d2846  call rax
00007e4af17d2848  movaps xmm14, [rsp]
00007e4af17d284d  add rsp, 0x30
00007e4af17d2851  vmovaps xmm0, [rsp]
00007e4af17d2856  vmovaps xmm1, [rsp+0x10]
00007e4af17d285c  vmovaps xmm2, [rsp+0x20]
00007e4af17d2862  vmovaps xmm3, [rsp+0x30]
00007e4af17d2868  vmovaps xmm4, [rsp+0x40]
00007e4af17d286e  vmovaps xmm5, [rsp+0x50]
00007e4af17d2874  vmovaps xmm6, [rsp+0x60]
00007e4af17d287a  vmovaps xmm7, [rsp+0x70]
00007e4af17d2880  vmovaps xmm8, [rsp+0x80]
00007e4af17d2889  vmovaps xmm9, [rsp+0x90]
00007e4af17d2892  vmovaps xmm10, [rsp+0xA0]
00007e4af17d289b  vmovaps xmm11, [rsp+0xB0]
00007e4af17d28a4  vmovaps xmm12, [rsp+0xC0]
00007e4af17d28ad  vmovaps xmm13, [rsp+0xD0]
00007e4af17d28b6  vmovaps xmm15, [rsp+0xE0]
00007e4af17d28bf  add rsp, 0xF0
00007e4af17d28c6  pop r11
00007e4af17d28c8  pop r10
00007e4af17d28ca  pop r9
00007e4af17d28cc  pop r8
00007e4af17d28ce  pop rsi
00007e4af17d28cf  pop rdi
00007e4af17d28d0  pop rdx
00007e4af17d28d1  pop rcx
00007e4af17d28d2  pop rax
00007e4af17d28d3  add rsp, 0x08
00007e4af17d28d7  jmp 0x00007E4AF17CFD72
00007e4af17d28dc  sub rsp, 0x08
00007e4af17d28e0  push rax
00007e4af17d28e1  push rcx
00007e4af17d28e2  push rdx
00007e4af17d28e3  push rdi
00007e4af17d28e4  push rsi
00007e4af17d28e5  push r8
00007e4af17d28e7  push r9
00007e4af17d28e9  push r10
00007e4af17d28eb  push r11
00007e4af17d28ed  sub rsp, 0xF0
00007e4af17d28f4  vmovaps [rsp], xmm0
00007e4af17d28f9  vmovaps [rsp+0x10], xmm1
00007e4af17d28ff  vmovaps [rsp+0x20], xmm2
00007e4af17d2905  vmovaps [rsp+0x30], xmm3
00007e4af17d290b  vmovaps [rsp+0x40], xmm4
00007e4af17d2911  vmovaps [rsp+0x50], xmm5
00007e4af17d2917  vmovaps [rsp+0x60], xmm7
00007e4af17d291d  vmovaps [rsp+0x70], xmm8
00007e4af17d2923  vmovaps [rsp+0x80], xmm9
00007e4af17d292c  vmovaps [rsp+0x90], xmm10
00007e4af17d2935  vmovaps [rsp+0xA0], xmm11
00007e4af17d293e  vmovaps [rsp+0xB0], xmm12
00007e4af17d2947  vmovaps [rsp+0xC0], xmm13
00007e4af17d2950  vmovaps [rsp+0xD0], xmm14
00007e4af17d2959  vmovaps [rsp+0xE0], xmm15
00007e4af17d2962  sub rsp, 0x30
00007e4af17d2966  movaps [rsp], xmm6
00007e4af17d296a  movaps [rsp+0x10], xmm5
00007e4af17d296f  movaps [rsp+0x20], xmm1
00007e4af17d2974  lea rdi, [rsp]
00007e4af17d2978  mov esi, 0x00
00007e4af17d297d  mov rax, 0x6256754A7530
00007e4af17d2987  call rax
00007e4af17d2989  movaps xmm6, [rsp]
00007e4af17d298d  add rsp, 0x30
00007e4af17d2991  vmovaps xmm0, [rsp]
00007e4af17d2996  vmovaps xmm1, [rsp+0x10]
00007e4af17d299c  vmovaps xmm2, [rsp+0x20]
00007e4af17d29a2  vmovaps xmm3, [rsp+0x30]
00007e4af17d29a8  vmovaps xmm4, [rsp+0x40]
00007e4af17d29ae  vmovaps xmm5, [rsp+0x50]
00007e4af17d29b4  vmovaps xmm7, [rsp+0x60]
00007e4af17d29ba  vmovaps xmm8, [rsp+0x70]
00007e4af17d29c0  vmovaps xmm9, [rsp+0x80]
00007e4af17d29c9  vmovaps xmm10, [rsp+0x90]
00007e4af17d29d2  vmovaps xmm11, [rsp+0xA0]
00007e4af17d29db  vmovaps xmm12, [rsp+0xB0]
00007e4af17d29e4  vmovaps xmm13, [rsp+0xC0]
00007e4af17d29ed  vmovaps xmm14, [rsp+0xD0]
00007e4af17d29f6  vmovaps xmm15, [rsp+0xE0]
00007e4af17d29ff  add rsp, 0xF0
00007e4af17d2a06  pop r11
00007e4af17d2a08  pop r10
00007e4af17d2a0a  pop r9
00007e4af17d2a0c  pop r8
00007e4af17d2a0e  pop rsi
00007e4af17d2a0f  pop rdi
00007e4af17d2a10  pop rdx
00007e4af17d2a11  pop rcx
00007e4af17d2a12  pop rax
00007e4af17d2a13  add rsp, 0x08
00007e4af17d2a17  jmp 0x00007E4AF17CFD98
00007e4af17d2a1c  sub rsp, 0x08
00007e4af17d2a20  push rax
00007e4af17d2a21  push rcx
00007e4af17d2a22  push rdx
00007e4af17d2a23  push rdi
00007e4af17d2a24  push rsi
00007e4af17d2a25  push r8
00007e4af17d2a27  push r9
00007e4af17d2a29  push r10
00007e4af17d2a2b  push r11
00007e4af17d2a2d  sub rsp, 0xF0
00007e4af17d2a34  vmovaps [rsp], xmm0
00007e4af17d2a39  vmovaps [rsp+0x10], xmm2
00007e4af17d2a3f  vmovaps [rsp+0x20], xmm3
00007e4af17d2a45  vmovaps [rsp+0x30], xmm4
00007e4af17d2a4b  vmovaps [rsp+0x40], xmm5
00007e4af17d2a51  vmovaps [rsp+0x50], xmm6
00007e4af17d2a57  vmovaps [rsp+0x60], xmm7
00007e4af17d2a5d  vmovaps [rsp+0x70], xmm8
00007e4af17d2a63  vmovaps [rsp+0x80], xmm9
00007e4af17d2a6c  vmovaps [rsp+0x90], xmm10
00007e4af17d2a75  vmovaps [rsp+0xA0], xmm11
00007e4af17d2a7e  vmovaps [rsp+0xB0], xmm12
00007e4af17d2a87  vmovaps [rsp+0xC0], xmm13
00007e4af17d2a90  vmovaps [rsp+0xD0], xmm14
00007e4af17d2a99  vmovaps [rsp+0xE0], xmm15
00007e4af17d2aa2  sub rsp, 0x30
00007e4af17d2aa6  movaps [rsp], xmm1
00007e4af17d2aaa  movaps [rsp+0x10], xmm5
00007e4af17d2aaf  movaps [rsp+0x20], xmm13
00007e4af17d2ab5  lea rdi, [rsp]
00007e4af17d2ab9  mov esi, 0x00
00007e4af17d2abe  mov rax, 0x6256754A7530
00007e4af17d2ac8  call rax
00007e4af17d2aca  movaps xmm1, [rsp]
00007e4af17d2ace  add rsp, 0x30
00007e4af17d2ad2  vmovaps xmm0, [rsp]
00007e4af17d2ad7  vmovaps xmm2, [rsp+0x10]
00007e4af17d2add  vmovaps xmm3, [rsp+0x20]
00007e4af17d2ae3  vmovaps xmm4, [rsp+0x30]
00007e4af17d2ae9  vmovaps xmm5, [rsp+0x40]
00007e4af17d2aef  vmovaps xmm6, [rsp+0x50]
00007e4af17d2af5  vmovaps xmm7, [rsp+0x60]
00007e4af17d2afb  vmovaps xmm8, [rsp+0x70]
00007e4af17d2b01  vmovaps xmm9, [rsp+0x80]
00007e4af17d2b0a  vmovaps xmm10, [rsp+0x90]
00007e4af17d2b13  vmovaps xmm11, [rsp+0xA0]
00007e4af17d2b1c  vmovaps xmm12, [rsp+0xB0]
00007e4af17d2b25  vmovaps xmm13, [rsp+0xC0]
00007e4af17d2b2e  vmovaps xmm14, [rsp+0xD0]
00007e4af17d2b37  vmovaps xmm15, [rsp+0xE0]
00007e4af17d2b40  add rsp, 0xF0
00007e4af17d2b47  pop r11
00007e4af17d2b49  pop r10
00007e4af17d2b4b  pop r9
00007e4af17d2b4d  pop r8
00007e4af17d2b4f  pop rsi
00007e4af17d2b50  pop rdi
00007e4af17d2b51  pop rdx
00007e4af17d2b52  pop rcx
00007e4af17d2b53  pop rax
00007e4af17d2b54  add rsp, 0x08
00007e4af17d2b58  jmp 0x00007E4AF17CFDB6
00007e4af17d2b5d  sub rsp, 0x08
00007e4af17d2b61  push rax
00007e4af17d2b62  push rcx
00007e4af17d2b63  push rdx
00007e4af17d2b64  push rdi
00007e4af17d2b65  push rsi
00007e4af17d2b66  push r8
00007e4af17d2b68  push r9
00007e4af17d2b6a  push r10
00007e4af17d2b6c  push r11
00007e4af17d2b6e  sub rsp, 0xF0
00007e4af17d2b75  vmovaps [rsp], xmm0
00007e4af17d2b7a  vmovaps [rsp+0x10], xmm1
00007e4af17d2b80  vmovaps [rsp+0x20], xmm2
00007e4af17d2b86  vmovaps [rsp+0x30], xmm3
00007e4af17d2b8c  vmovaps [rsp+0x40], xmm4
00007e4af17d2b92  vmovaps [rsp+0x50], xmm6
00007e4af17d2b98  vmovaps [rsp+0x60], xmm7
00007e4af17d2b9e  vmovaps [rsp+0x70], xmm8
00007e4af17d2ba4  vmovaps [rsp+0x80], xmm9
00007e4af17d2bad  vmovaps [rsp+0x90], xmm10
00007e4af17d2bb6  vmovaps [rsp+0xA0], xmm11
00007e4af17d2bbf  vmovaps [rsp+0xB0], xmm12
00007e4af17d2bc8  vmovaps [rsp+0xC0], xmm13
00007e4af17d2bd1  vmovaps [rsp+0xD0], xmm14
00007e4af17d2bda  vmovaps [rsp+0xE0], xmm15
00007e4af17d2be3  sub rsp, 0x30
00007e4af17d2be7  movaps [rsp], xmm5
00007e4af17d2beb  movaps [rsp+0x10], xmm2
00007e4af17d2bf0  movaps [rsp+0x20], xmm13
00007e4af17d2bf6  lea rdi, [rsp]
00007e4af17d2bfa  mov esi, 0x00
00007e4af17d2bff  mov rax, 0x6256754A7530
00007e4af17d2c09  call rax
00007e4af17d2c0b  movaps xmm5, [rsp]
00007e4af17d2c0f  add rsp, 0x30
00007e4af17d2c13  vmovaps xmm0, [rsp]
00007e4af17d2c18  vmovaps xmm1, [rsp+0x10]
00007e4af17d2c1e  vmovaps xmm2, [rsp+0x20]
00007e4af17d2c24  vmovaps xmm3, [rsp+0x30]
00007e4af17d2c2a  vmovaps xmm4, [rsp+0x40]
00007e4af17d2c30  vmovaps xmm6, [rsp+0x50]
00007e4af17d2c36  vmovaps xmm7, [rsp+0x60]
00007e4af17d2c3c  vmovaps xmm8, [rsp+0x70]
00007e4af17d2c42  vmovaps xmm9, [rsp+0x80]
00007e4af17d2c4b  vmovaps xmm10, [rsp+0x90]
00007e4af17d2c54  vmovaps xmm11, [rsp+0xA0]
00007e4af17d2c5d  vmovaps xmm12, [rsp+0xB0]
00007e4af17d2c66  vmovaps xmm13, [rsp+0xC0]
00007e4af17d2c6f  vmovaps xmm14, [rsp+0xD0]
00007e4af17d2c78  vmovaps xmm15, [rsp+0xE0]
00007e4af17d2c81  add rsp, 0xF0
00007e4af17d2c88  pop r11
00007e4af17d2c8a  pop r10
00007e4af17d2c8c  pop r9
00007e4af17d2c8e  pop r8
00007e4af17d2c90  pop rsi
00007e4af17d2c91  pop rdi
00007e4af17d2c92  pop rdx
00007e4af17d2c93  pop rcx
00007e4af17d2c94  pop rax
00007e4af17d2c95  add rsp, 0x08
00007e4af17d2c99  jmp 0x00007E4AF17CFDEC
00007e4af17d2c9e  sub rsp, 0x08
00007e4af17d2ca2  push rax
00007e4af17d2ca3  push rcx
00007e4af17d2ca4  push rdx
00007e4af17d2ca5  push rdi
00007e4af17d2ca6  push rsi
00007e4af17d2ca7  push r8
00007e4af17d2ca9  push r9
00007e4af17d2cab  push r10
00007e4af17d2cad  push r11
00007e4af17d2caf  sub rsp, 0xF0
00007e4af17d2cb6  vmovaps [rsp], xmm0
00007e4af17d2cbb  vmovaps [rsp+0x10], xmm1
00007e4af17d2cc1  vmovaps [rsp+0x20], xmm2
00007e4af17d2cc7  vmovaps [rsp+0x30], xmm3
00007e4af17d2ccd  vmovaps [rsp+0x40], xmm4
00007e4af17d2cd3  vmovaps [rsp+0x50], xmm5
00007e4af17d2cd9  vmovaps [rsp+0x60], xmm6
00007e4af17d2cdf  vmovaps [rsp+0x70], xmm7
00007e4af17d2ce5  vmovaps [rsp+0x80], xmm8
00007e4af17d2cee  vmovaps [rsp+0x90], xmm9
00007e4af17d2cf7  vmovaps [rsp+0xA0], xmm10
00007e4af17d2d00  vmovaps [rsp+0xB0], xmm11
00007e4af17d2d09  vmovaps [rsp+0xC0], xmm12
00007e4af17d2d12  vmovaps [rsp+0xD0], xmm14
00007e4af17d2d1b  vmovaps [rsp+0xE0], xmm15
00007e4af17d2d24  sub rsp, 0x30
00007e4af17d2d28  movaps [rsp], xmm13
00007e4af17d2d2d  movaps [rsp+0x10], xmm10
00007e4af17d2d33  movaps [rsp+0x20], xmm1
00007e4af17d2d38  lea rdi, [rsp]
00007e4af17d2d3c  mov esi, 0x00
00007e4af17d2d41  mov rax, 0x6256754A7530
00007e4af17d2d4b  call rax
00007e4af17d2d4d  movaps xmm13, [rsp]
00007e4af17d2d52  add rsp, 0x30
00007e4af17d2d56  vmovaps xmm0, [rsp]
00007e4af17d2d5b  vmovaps xmm1, [rsp+0x10]
00007e4af17d2d61  vmovaps xmm2, [rsp+0x20]
00007e4af17d2d67  vmovaps xmm3, [rsp+0x30]
00007e4af17d2d6d  vmovaps xmm4, [rsp+0x40]
00007e4af17d2d73  vmovaps xmm5, [rsp+0x50]
00007e4af17d2d79  vmovaps xmm6, [rsp+0x60]
00007e4af17d2d7f  vmovaps xmm7, [rsp+0x70]
00007e4af17d2d85  vmovaps xmm8, [rsp+0x80]
00007e4af17d2d8e  vmovaps xmm9, [rsp+0x90]
00007e4af17d2d97  vmovaps xmm10, [rsp+0xA0]
00007e4af17d2da0  vmovaps xmm11, [rsp+0xB0]
00007e4af17d2da9  vmovaps xmm12, [rsp+0xC0]
00007e4af17d2db2  vmovaps xmm14, [rsp+0xD0]
00007e4af17d2dbb  vmovaps xmm15, [rsp+0xE0]
00007e4af17d2dc4  add rsp, 0xF0
00007e4af17d2dcb  pop r11
00007e4af17d2dcd  pop r10
00007e4af17d2dcf  pop r9
00007e4af17d2dd1  pop r8
00007e4af17d2dd3  pop rsi
00007e4af17d2dd4  pop rdi
00007e4af17d2dd5  pop rdx
00007e4af17d2dd6  pop rcx
00007e4af17d2dd7  pop rax
00007e4af17d2dd8  add rsp, 0x08
00007e4af17d2ddc  jmp 0x00007E4AF17CFE15
00007e4af17d2de1  sub rsp, 0x08
00007e4af17d2de5  push rax
00007e4af17d2de6  push rcx
00007e4af17d2de7  push rdx
00007e4af17d2de8  push rdi
00007e4af17d2de9  push rsi
00007e4af17d2dea  push r8
00007e4af17d2dec  push r9
00007e4af17d2dee  push r10
00007e4af17d2df0  push r11
00007e4af17d2df2  sub rsp, 0xF0
00007e4af17d2df9  vmovaps [rsp], xmm0
00007e4af17d2dfe  vmovaps [rsp+0x10], xmm2
00007e4af17d2e04  vmovaps [rsp+0x20], xmm3
00007e4af17d2e0a  vmovaps [rsp+0x30], xmm4
00007e4af17d2e10  vmovaps [rsp+0x40], xmm5
00007e4af17d2e16  vmovaps [rsp+0x50], xmm6
00007e4af17d2e1c  vmovaps [rsp+0x60], xmm7
00007e4af17d2e22  vmovaps [rsp+0x70], xmm8
00007e4af17d2e28  vmovaps [rsp+0x80], xmm9
00007e4af17d2e31  vmovaps [rsp+0x90], xmm10
00007e4af17d2e3a  vmovaps [rsp+0xA0], xmm11
00007e4af17d2e43  vmovaps [rsp+0xB0], xmm12
00007e4af17d2e4c  vmovaps [rsp+0xC0], xmm13
00007e4af17d2e55  vmovaps [rsp+0xD0], xmm14
00007e4af17d2e5e  vmovaps [rsp+0xE0], xmm15
00007e4af17d2e67  sub rsp, 0x30
00007e4af17d2e6b  movaps [rsp], xmm1
00007e4af17d2e6f  movaps [rsp+0x10], xmm15
00007e4af17d2e75  movaps [rsp+0x20], xmm10
00007e4af17d2e7b  lea rdi, [rsp]
00007e4af17d2e7f  mov esi, 0x00
00007e4af17d2e84  mov rax, 0x6256754A7530
00007e4af17d2e8e  call rax
00007e4af17d2e90  movaps xmm1, [rsp]
00007e4af17d2e94  add rsp, 0x30
00007e4af17d2e98  vmovaps xmm0, [rsp]
00007e4af17d2e9d  vmovaps xmm2, [rsp+0x10]
00007e4af17d2ea3  vmovaps xmm3, [rsp+0x20]
00007e4af17d2ea9  vmovaps xmm4, [rsp+0x30]
00007e4af17d2eaf  vmovaps xmm5, [rsp+0x40]
00007e4af17d2eb5  vmovaps xmm6, [rsp+0x50]
00007e4af17d2ebb  vmovaps xmm7, [rsp+0x60]
00007e4af17d2ec1  vmovaps xmm8, [rsp+0x70]
00007e4af17d2ec7  vmovaps xmm9, [rsp+0x80]
00007e4af17d2ed0  vmovaps xmm10, [rsp+0x90]
00007e4af17d2ed9  vmovaps xmm11, [rsp+0xA0]
00007e4af17d2ee2  vmovaps xmm12, [rsp+0xB0]
00007e4af17d2eeb  vmovaps xmm13, [rsp+0xC0]
00007e4af17d2ef4  vmovaps xmm14, [rsp+0xD0]
00007e4af17d2efd  vmovaps xmm15, [rsp+0xE0]
00007e4af17d2f06  add rsp, 0xF0
00007e4af17d2f0d  pop r11
00007e4af17d2f0f  pop r10
00007e4af17d2f11  pop r9
00007e4af17d2f13  pop r8
00007e4af17d2f15  pop rsi
00007e4af17d2f16  pop rdi
00007e4af17d2f17  pop rdx
00007e4af17d2f18  pop rcx
00007e4af17d2f19  pop rax
00007e4af17d2f1a  add rsp, 0x08
00007e4af17d2f1e  jmp 0x00007E4AF17CFE34
00007e4af17d2f23  sub rsp, 0x08
00007e4af17d2f27  push rax
00007e4af17d2f28  push rcx
00007e4af17d2f29  push rdx
00007e4af17d2f2a  push rdi
00007e4af17d2f2b  push rsi
00007e4af17d2f2c  push r8
00007e4af17d2f2e  push r9
00007e4af17d2f30  push r10
00007e4af17d2f32  push r11
00007e4af17d2f34  sub rsp, 0xF0
00007e4af17d2f3b  vmovaps [rsp], xmm0
00007e4af17d2f40  vmovaps [rsp+0x10], xmm1
00007e4af17d2f46  vmovaps [rsp+0x20], xmm2
00007e4af17d2f4c  vmovaps [rsp+0x30], xmm3
00007e4af17d2f52  vmovaps [rsp+0x40], xmm4
00007e4af17d2f58  vmovaps [rsp+0x50], xmm5
00007e4af17d2f5e  vmovaps [rsp+0x60], xmm6
00007e4af17d2f64  vmovaps [rsp+0x70], xmm7
00007e4af17d2f6a  vmovaps [rsp+0x80], xmm8
00007e4af17d2f73  vmovaps [rsp+0x90], xmm9
00007e4af17d2f7c  vmovaps [rsp+0xA0], xmm10
00007e4af17d2f85  vmovaps [rsp+0xB0], xmm11
00007e4af17d2f8e  vmovaps [rsp+0xC0], xmm12
00007e4af17d2f97  vmovaps [rsp+0xD0], xmm13
00007e4af17d2fa0  vmovaps [rsp+0xE0], xmm14
00007e4af17d2fa9  sub rsp, 0x30
00007e4af17d2fad  movaps [rsp], xmm15
00007e4af17d2fb2  movaps [rsp+0x10], xmm10
00007e4af17d2fb8  movaps [rsp+0x20], xmm11
00007e4af17d2fbe  lea rdi, [rsp]
00007e4af17d2fc2  mov esi, 0x00
00007e4af17d2fc7  mov rax, 0x6256754A7530
00007e4af17d2fd1  call rax
00007e4af17d2fd3  movaps xmm15, [rsp]
00007e4af17d2fd8  add rsp, 0x30
00007e4af17d2fdc  vmovaps xmm0, [rsp]
00007e4af17d2fe1  vmovaps xmm1, [rsp+0x10]
00007e4af17d2fe7  vmovaps xmm2, [rsp+0x20]
00007e4af17d2fed  vmovaps xmm3, [rsp+0x30]
00007e4af17d2ff3  vmovaps xmm4, [rsp+0x40]
00007e4af17d2ff9  vmovaps xmm5, [rsp+0x50]
00007e4af17d2fff  vmovaps xmm6, [rsp+0x60]
00007e4af17d3005  vmovaps xmm7, [rsp+0x70]
00007e4af17d300b  vmovaps xmm8, [rsp+0x80]
00007e4af17d3014  vmovaps xmm9, [rsp+0x90]
00007e4af17d301d  vmovaps xmm10, [rsp+0xA0]
00007e4af17d3026  vmovaps xmm11, [rsp+0xB0]
00007e4af17d302f  vmovaps xmm12, [rsp+0xC0]
00007e4af17d3038  vmovaps xmm13, [rsp+0xD0]
00007e4af17d3041  vmovaps xmm14, [rsp+0xE0]
00007e4af17d304a  add rsp, 0xF0
00007e4af17d3051  pop r11
00007e4af17d3053  pop r10
00007e4af17d3055  pop r9
00007e4af17d3057  pop r8
00007e4af17d3059  pop rsi
00007e4af17d305a  pop rdi
00007e4af17d305b  pop rdx
00007e4af17d305c  pop rcx
00007e4af17d305d  pop rax
00007e4af17d305e  add rsp, 0x08
00007e4af17d3062  jmp 0x00007E4AF17CFE57
00007e4af17d3067  sub rsp, 0x08
00007e4af17d306b  push rax
00007e4af17d306c  push rcx
00007e4af17d306d  push rdx
00007e4af17d306e  push rdi
00007e4af17d306f  push rsi
00007e4af17d3070  push r8
00007e4af17d3072  push r9
00007e4af17d3074  push r10
00007e4af17d3076  push r11
00007e4af17d3078  sub rsp, 0xF0
00007e4af17d307f  vmovaps [rsp], xmm0
00007e4af17d3084  vmovaps [rsp+0x10], xmm1
00007e4af17d308a  vmovaps [rsp+0x20], xmm2
00007e4af17d3090  vmovaps [rsp+0x30], xmm3
00007e4af17d3096  vmovaps [rsp+0x40], xmm4
00007e4af17d309c  vmovaps [rsp+0x50], xmm5
00007e4af17d30a2  vmovaps [rsp+0x60], xmm6
00007e4af17d30a8  vmovaps [rsp+0x70], xmm7
00007e4af17d30ae  vmovaps [rsp+0x80], xmm8
00007e4af17d30b7  vmovaps [rsp+0x90], xmm9
00007e4af17d30c0  vmovaps [rsp+0xA0], xmm11
00007e4af17d30c9  vmovaps [rsp+0xB0], xmm12
00007e4af17d30d2  vmovaps [rsp+0xC0], xmm13
00007e4af17d30db  vmovaps [rsp+0xD0], xmm14
00007e4af17d30e4  vmovaps [rsp+0xE0], xmm15
00007e4af17d30ed  sub rsp, 0x30
00007e4af17d30f1  movaps [rsp], xmm10
00007e4af17d30f6  movaps [rsp+0x10], xmm12
00007e4af17d30fc  movaps [rsp+0x20], xmm11
00007e4af17d3102  lea rdi, [rsp]
00007e4af17d3106  mov esi, 0x00
00007e4af17d310b  mov rax, 0x6256754A7530
00007e4af17d3115  call rax
00007e4af17d3117  movaps xmm10, [rsp]
00007e4af17d311c  add rsp, 0x30
00007e4af17d3120  vmovaps xmm0, [rsp]
00007e4af17d3125  vmovaps xmm1, [rsp+0x10]
00007e4af17d312b  vmovaps xmm2, [rsp+0x20]
00007e4af17d3131  vmovaps xmm3, [rsp+0x30]
00007e4af17d3137  vmovaps xmm4, [rsp+0x40]
00007e4af17d313d  vmovaps xmm5, [rsp+0x50]
00007e4af17d3143  vmovaps xmm6, [rsp+0x60]
00007e4af17d3149  vmovaps xmm7, [rsp+0x70]
00007e4af17d314f  vmovaps xmm8, [rsp+0x80]
00007e4af17d3158  vmovaps xmm9, [rsp+0x90]
00007e4af17d3161  vmovaps xmm11, [rsp+0xA0]
00007e4af17d316a  vmovaps xmm12, [rsp+0xB0]
00007e4af17d3173  vmovaps xmm13, [rsp+0xC0]
00007e4af17d317c  vmovaps xmm14, [rsp+0xD0]
00007e4af17d3185  vmovaps xmm15, [rsp+0xE0]
00007e4af17d318e  add rsp, 0xF0
00007e4af17d3195  pop r11
00007e4af17d3197  pop r10
00007e4af17d3199  pop r9
00007e4af17d319b  pop r8
00007e4af17d319d  pop rsi
00007e4af17d319e  pop rdi
00007e4af17d319f  pop rdx
00007e4af17d31a0  pop rcx
00007e4af17d31a1  pop rax
00007e4af17d31a2  add rsp, 0x08
00007e4af17d31a6  jmp 0x00007E4AF17CFE80
00007e4af17d31ab  sub rsp, 0x08
00007e4af17d31af  push rax
00007e4af17d31b0  push rcx
00007e4af17d31b1  push rdx
00007e4af17d31b2  push rdi
00007e4af17d31b3  push rsi
00007e4af17d31b4  push r8
00007e4af17d31b6  push r9
00007e4af17d31b8  push r10
00007e4af17d31ba  push r11
00007e4af17d31bc  sub rsp, 0xF0
00007e4af17d31c3  vmovaps [rsp], xmm0
00007e4af17d31c8  vmovaps [rsp+0x10], xmm1
00007e4af17d31ce  vmovaps [rsp+0x20], xmm2
00007e4af17d31d4  vmovaps [rsp+0x30], xmm3
00007e4af17d31da  vmovaps [rsp+0x40], xmm4
00007e4af17d31e0  vmovaps [rsp+0x50], xmm5
00007e4af17d31e6  vmovaps [rsp+0x60], xmm6
00007e4af17d31ec  vmovaps [rsp+0x70], xmm7
00007e4af17d31f2  vmovaps [rsp+0x80], xmm8
00007e4af17d31fb  vmovaps [rsp+0x90], xmm9
00007e4af17d3204  vmovaps [rsp+0xA0], xmm10
00007e4af17d320d  vmovaps [rsp+0xB0], xmm12
00007e4af17d3216  vmovaps [rsp+0xC0], xmm13
00007e4af17d321f  vmovaps [rsp+0xD0], xmm14
00007e4af17d3228  vmovaps [rsp+0xE0], xmm15
00007e4af17d3231  sub rsp, 0x30
00007e4af17d3235  movaps [rsp], xmm11
00007e4af17d323a  movaps [rsp+0x10], xmm2
00007e4af17d323f  movaps [rsp+0x20], xmm12
00007e4af17d3245  lea rdi, [rsp]
00007e4af17d3249  mov esi, 0x00
00007e4af17d324e  mov rax, 0x6256754A7530
00007e4af17d3258  call rax
00007e4af17d325a  movaps xmm11, [rsp]
00007e4af17d325f  add rsp, 0x30
00007e4af17d3263  vmovaps xmm0, [rsp]
00007e4af17d3268  vmovaps xmm1, [rsp+0x10]
00007e4af17d326e  vmovaps xmm2, [rsp+0x20]
00007e4af17d3274  vmovaps xmm3, [rsp+0x30]
00007e4af17d327a  vmovaps xmm4, [rsp+0x40]
00007e4af17d3280  vmovaps xmm5, [rsp+0x50]
00007e4af17d3286  vmovaps xmm6, [rsp+0x60]
00007e4af17d328c  vmovaps xmm7, [rsp+0x70]
00007e4af17d3292  vmovaps xmm8, [rsp+0x80]
00007e4af17d329b  vmovaps xmm9, [rsp+0x90]
00007e4af17d32a4  vmovaps xmm10, [rsp+0xA0]
00007e4af17d32ad  vmovaps xmm12, [rsp+0xB0]
00007e4af17d32b6  vmovaps xmm13, [rsp+0xC0]
00007e4af17d32bf  vmovaps xmm14, [rsp+0xD0]
00007e4af17d32c8  vmovaps xmm15, [rsp+0xE0]
00007e4af17d32d1  add rsp, 0xF0
00007e4af17d32d8  pop r11
00007e4af17d32da  pop r10
00007e4af17d32dc  pop r9
00007e4af17d32de  pop r8
00007e4af17d32e0  pop rsi
00007e4af17d32e1  pop rdi
00007e4af17d32e2  pop rdx
00007e4af17d32e3  pop rcx
00007e4af17d32e4  pop rax
00007e4af17d32e5  add rsp, 0x08
00007e4af17d32e9  jmp 0x00007E4AF17CFEB8
00007e4af17d32ee  sub rsp, 0x08
00007e4af17d32f2  push rax
00007e4af17d32f3  push rcx
00007e4af17d32f4  push rdx
00007e4af17d32f5  push rdi
00007e4af17d32f6  push rsi
00007e4af17d32f7  push r8
00007e4af17d32f9  push r9
00007e4af17d32fb  push r10
00007e4af17d32fd  push r11
00007e4af17d32ff  sub rsp, 0xF0
00007e4af17d3306  vmovaps [rsp], xmm0
00007e4af17d330b  vmovaps [rsp+0x10], xmm2
00007e4af17d3311  vmovaps [rsp+0x20], xmm3
00007e4af17d3317  vmovaps [rsp+0x30], xmm4
00007e4af17d331d  vmovaps [rsp+0x40], xmm5
00007e4af17d3323  vmovaps [rsp+0x50], xmm6
00007e4af17d3329  vmovaps [rsp+0x60], xmm7
00007e4af17d332f  vmovaps [rsp+0x70], xmm8
00007e4af17d3335  vmovaps [rsp+0x80], xmm9
00007e4af17d333e  vmovaps [rsp+0x90], xmm10
00007e4af17d3347  vmovaps [rsp+0xA0], xmm11
00007e4af17d3350  vmovaps [rsp+0xB0], xmm12
00007e4af17d3359  vmovaps [rsp+0xC0], xmm13
00007e4af17d3362  vmovaps [rsp+0xD0], xmm14
00007e4af17d336b  vmovaps [rsp+0xE0], xmm15
00007e4af17d3374  sub rsp, 0x30
00007e4af17d3378  movaps [rsp], xmm1
00007e4af17d337c  movaps [rsp+0x10], xmm14
00007e4af17d3382  movaps [rsp+0x20], xmm6
00007e4af17d3387  lea rdi, [rsp]
00007e4af17d338b  mov esi, 0x00
00007e4af17d3390  mov rax, 0x6256754A7530
00007e4af17d339a  call rax
00007e4af17d339c  movaps xmm1, [rsp]
00007e4af17d33a0  add rsp, 0x30
00007e4af17d33a4  vmovaps xmm0, [rsp]
00007e4af17d33a9  vmovaps xmm2, [rsp+0x10]
00007e4af17d33af  vmovaps xmm3, [rsp+0x20]
00007e4af17d33b5  vmovaps xmm4, [rsp+0x30]
00007e4af17d33bb  vmovaps xmm5, [rsp+0x40]
00007e4af17d33c1  vmovaps xmm6, [rsp+0x50]
00007e4af17d33c7  vmovaps xmm7, [rsp+0x60]
00007e4af17d33cd  vmovaps xmm8, [rsp+0x70]
00007e4af17d33d3  vmovaps xmm9, [rsp+0x80]
00007e4af17d33dc  vmovaps xmm10, [rsp+0x90]
00007e4af17d33e5  vmovaps xmm11, [rsp+0xA0]
00007e4af17d33ee  vmovaps xmm12, [rsp+0xB0]
00007e4af17d33f7  vmovaps xmm13, [rsp+0xC0]
00007e4af17d3400  vmovaps xmm14, [rsp+0xD0]
00007e4af17d3409  vmovaps xmm15, [rsp+0xE0]
00007e4af17d3412  add rsp, 0xF0
00007e4af17d3419  pop r11
00007e4af17d341b  pop r10
00007e4af17d341d  pop r9
00007e4af17d341f  pop r8
00007e4af17d3421  pop rsi
00007e4af17d3422  pop rdi
00007e4af17d3423  pop rdx
00007e4af17d3424  pop rcx
00007e4af17d3425  pop rax
00007e4af17d3426  add rsp, 0x08
00007e4af17d342a  jmp 0x00007E4AF17CFED1
00007e4af17d342f  sub rsp, 0x08
00007e4af17d3433  push rax
00007e4af17d3434  push rcx
00007e4af17d3435  push rdx
00007e4af17d3436  push rdi
00007e4af17d3437  push rsi
00007e4af17d3438  push r8
00007e4af17d343a  push r9
00007e4af17d343c  push r10
00007e4af17d343e  push r11
00007e4af17d3440  sub rsp, 0xF0
00007e4af17d3447  vmovaps [rsp], xmm0
00007e4af17d344c  vmovaps [rsp+0x10], xmm1
00007e4af17d3452  vmovaps [rsp+0x20], xmm2
00007e4af17d3458  vmovaps [rsp+0x30], xmm3
00007e4af17d345e  vmovaps [rsp+0x40], xmm4
00007e4af17d3464  vmovaps [rsp+0x50], xmm5
00007e4af17d346a  vmovaps [rsp+0x60], xmm6
00007e4af17d3470  vmovaps [rsp+0x70], xmm7
00007e4af17d3476  vmovaps [rsp+0x80], xmm8
00007e4af17d347f  vmovaps [rsp+0x90], xmm9
00007e4af17d3488  vmovaps [rsp+0xA0], xmm10
00007e4af17d3491  vmovaps [rsp+0xB0], xmm11
00007e4af17d349a  vmovaps [rsp+0xC0], xmm12
00007e4af17d34a3  vmovaps [rsp+0xD0], xmm13
00007e4af17d34ac  vmovaps [rsp+0xE0], xmm15
00007e4af17d34b5  sub rsp, 0x30
00007e4af17d34b9  movaps [rsp], xmm14
00007e4af17d34be  movaps [rsp+0x10], xmm12
00007e4af17d34c4  movaps [rsp+0x20], xmm5
00007e4af17d34c9  lea rdi, [rsp]
00007e4af17d34cd  mov esi, 0x00
00007e4af17d34d2  mov rax, 0x6256754A7530
00007e4af17d34dc  call rax
00007e4af17d34de  movaps xmm14, [rsp]
00007e4af17d34e3  add rsp, 0x30
00007e4af17d34e7  vmovaps xmm0, [rsp]
00007e4af17d34ec  vmovaps xmm1, [rsp+0x10]
00007e4af17d34f2  vmovaps xmm2, [rsp+0x20]
00007e4af17d34f8  vmovaps xmm3, [rsp+0x30]
00007e4af17d34fe  vmovaps xmm4, [rsp+0x40]
00007e4af17d3504  vmovaps xmm5, [rsp+0x50]
00007e4af17d350a  vmovaps xmm6, [rsp+0x60]
00007e4af17d3510  vmovaps xmm7, [rsp+0x70]
00007e4af17d3516  vmovaps xmm8, [rsp+0x80]
00007e4af17d351f  vmovaps xmm9, [rsp+0x90]
00007e4af17d3528  vmovaps xmm10, [rsp+0xA0]
00007e4af17d3531  vmovaps xmm11, [rsp+0xB0]
00007e4af17d353a  vmovaps xmm12, [rsp+0xC0]
00007e4af17d3543  vmovaps xmm13, [rsp+0xD0]
00007e4af17d354c  vmovaps xmm15, [rsp+0xE0]
00007e4af17d3555  add rsp, 0xF0
00007e4af17d355c  pop r11
00007e4af17d355e  pop r10
00007e4af17d3560  pop r9
00007e4af17d3562  pop r8
00007e4af17d3564  pop rsi
00007e4af17d3565  pop rdi
00007e4af17d3566  pop rdx
00007e4af17d3567  pop rcx
00007e4af17d3568  pop rax
00007e4af17d3569  add rsp, 0x08
00007e4af17d356d  jmp 0x00007E4AF17CFEF1
00007e4af17d3572  sub rsp, 0x08
00007e4af17d3576  push rax
00007e4af17d3577  push rcx
00007e4af17d3578  push rdx
00007e4af17d3579  push rdi
00007e4af17d357a  push rsi
00007e4af17d357b  push r8
00007e4af17d357d  push r9
00007e4af17d357f  push r10
00007e4af17d3581  push r11
00007e4af17d3583  sub rsp, 0xF0
00007e4af17d358a  vmovaps [rsp], xmm0
00007e4af17d358f  vmovaps [rsp+0x10], xmm1
00007e4af17d3595  vmovaps [rsp+0x20], xmm2
00007e4af17d359b  vmovaps [rsp+0x30], xmm3
00007e4af17d35a1  vmovaps [rsp+0x40], xmm4
00007e4af17d35a7  vmovaps [rsp+0x50], xmm5
00007e4af17d35ad  vmovaps [rsp+0x60], xmm7
00007e4af17d35b3  vmovaps [rsp+0x70], xmm8
00007e4af17d35b9  vmovaps [rsp+0x80], xmm9
00007e4af17d35c2  vmovaps [rsp+0x90], xmm10
00007e4af17d35cb  vmovaps [rsp+0xA0], xmm11
00007e4af17d35d4  vmovaps [rsp+0xB0], xmm12
00007e4af17d35dd  vmovaps [rsp+0xC0], xmm13
00007e4af17d35e6  vmovaps [rsp+0xD0], xmm14
00007e4af17d35ef  vmovaps [rsp+0xE0], xmm15
00007e4af17d35f8  sub rsp, 0x30
00007e4af17d35fc  movaps [rsp], xmm6
00007e4af17d3600  movaps [rsp+0x10], xmm9
00007e4af17d3606  movaps [rsp+0x20], xmm12
00007e4af17d360c  lea rdi, [rsp]
00007e4af17d3610  mov esi, 0x00
00007e4af17d3615  mov rax, 0x6256754A7530
00007e4af17d361f  call rax
00007e4af17d3621  movaps xmm6, [rsp]
00007e4af17d3625  add rsp, 0x30
00007e4af17d3629  vmovaps xmm0, [rsp]
00007e4af17d362e  vmovaps xmm1, [rsp+0x10]
00007e4af17d3634  vmovaps xmm2, [rsp+0x20]
00007e4af17d363a  vmovaps xmm3, [rsp+0x30]
00007e4af17d3640  vmovaps xmm4, [rsp+0x40]
00007e4af17d3646  vmovaps xmm5, [rsp+0x50]
00007e4af17d364c  vmovaps xmm7, [rsp+0x60]
00007e4af17d3652  vmovaps xmm8, [rsp+0x70]
00007e4af17d3658  vmovaps xmm9, [rsp+0x80]
00007e4af17d3661  vmovaps xmm10, [rsp+0x90]
00007e4af17d366a  vmovaps xmm11, [rsp+0xA0]
00007e4af17d3673  vmovaps xmm12, [rsp+0xB0]
00007e4af17d367c  vmovaps xmm13, [rsp+0xC0]
00007e4af17d3685  vmovaps xmm14, [rsp+0xD0]
00007e4af17d368e  vmovaps xmm15, [rsp+0xE0]
00007e4af17d3697  add rsp, 0xF0
00007e4af17d369e  pop r11
00007e4af17d36a0  pop r10
00007e4af17d36a2  pop r9
00007e4af17d36a4  pop r8
00007e4af17d36a6  pop rsi
00007e4af17d36a7  pop rdi
00007e4af17d36a8  pop rdx
00007e4af17d36a9  pop rcx
00007e4af17d36aa  pop rax
00007e4af17d36ab  add rsp, 0x08
00007e4af17d36af  jmp 0x00007E4AF17CFF19
00007e4af17d36b4  sub rsp, 0x08
00007e4af17d36b8  push rax
00007e4af17d36b9  push rcx
00007e4af17d36ba  push rdx
00007e4af17d36bb  push rdi
00007e4af17d36bc  push rsi
00007e4af17d36bd  push r8
00007e4af17d36bf  push r9
00007e4af17d36c1  push r10
00007e4af17d36c3  push r11
00007e4af17d36c5  sub rsp, 0xF0
00007e4af17d36cc  vmovaps [rsp], xmm0
00007e4af17d36d1  vmovaps [rsp+0x10], xmm1
00007e4af17d36d7  vmovaps [rsp+0x20], xmm2
00007e4af17d36dd  vmovaps [rsp+0x30], xmm3
00007e4af17d36e3  vmovaps [rsp+0x40], xmm4
00007e4af17d36e9  vmovaps [rsp+0x50], xmm5
00007e4af17d36ef  vmovaps [rsp+0x60], xmm6
00007e4af17d36f5  vmovaps [rsp+0x70], xmm7
00007e4af17d36fb  vmovaps [rsp+0x80], xmm8
00007e4af17d3704  vmovaps [rsp+0x90], xmm9
00007e4af17d370d  vmovaps [rsp+0xA0], xmm10
00007e4af17d3716  vmovaps [rsp+0xB0], xmm11
00007e4af17d371f  vmovaps [rsp+0xC0], xmm13
00007e4af17d3728  vmovaps [rsp+0xD0], xmm14
00007e4af17d3731  vmovaps [rsp+0xE0], xmm15
00007e4af17d373a  sub rsp, 0x30
00007e4af17d373e  movaps [rsp], xmm12
00007e4af17d3743  movaps [rsp+0x10], xmm15
00007e4af17d3749  movaps [rsp+0x20], xmm13
00007e4af17d374f  lea rdi, [rsp]
00007e4af17d3753  mov esi, 0x00
00007e4af17d3758  mov rax, 0x6256754A7530
00007e4af17d3762  call rax
00007e4af17d3764  movaps xmm12, [rsp]
00007e4af17d3769  add rsp, 0x30
00007e4af17d376d  vmovaps xmm0, [rsp]
00007e4af17d3772  vmovaps xmm1, [rsp+0x10]
00007e4af17d3778  vmovaps xmm2, [rsp+0x20]
00007e4af17d377e  vmovaps xmm3, [rsp+0x30]
00007e4af17d3784  vmovaps xmm4, [rsp+0x40]
00007e4af17d378a  vmovaps xmm5, [rsp+0x50]
00007e4af17d3790  vmovaps xmm6, [rsp+0x60]
00007e4af17d3796  vmovaps xmm7, [rsp+0x70]
00007e4af17d379c  vmovaps xmm8, [rsp+0x80]
00007e4af17d37a5  vmovaps xmm9, [rsp+0x90]
00007e4af17d37ae  vmovaps xmm10, [rsp+0xA0]
00007e4af17d37b7  vmovaps xmm11, [rsp+0xB0]
00007e4af17d37c0  vmovaps xmm13, [rsp+0xC0]
00007e4af17d37c9  vmovaps xmm14, [rsp+0xD0]
00007e4af17d37d2  vmovaps xmm15, [rsp+0xE0]
00007e4af17d37db  add rsp, 0xF0
00007e4af17d37e2  pop r11
00007e4af17d37e4  pop r10
00007e4af17d37e6  pop r9
00007e4af17d37e8  pop r8
00007e4af17d37ea  pop rsi
00007e4af17d37eb  pop rdi
00007e4af17d37ec  pop rdx
00007e4af17d37ed  pop rcx
00007e4af17d37ee  pop rax
00007e4af17d37ef  add rsp, 0x08
00007e4af17d37f3  jmp 0x00007E4AF17CFF34
00007e4af17d37f8  sub rsp, 0x08
00007e4af17d37fc  push rax
00007e4af17d37fd  push rcx
00007e4af17d37fe  push rdx
00007e4af17d37ff  push rdi
00007e4af17d3800  push rsi
00007e4af17d3801  push r8
00007e4af17d3803  push r9
00007e4af17d3805  push r10
00007e4af17d3807  push r11
00007e4af17d3809  sub rsp, 0xF0
00007e4af17d3810  vmovaps [rsp], xmm0
00007e4af17d3815  vmovaps [rsp+0x10], xmm1
00007e4af17d381b  vmovaps [rsp+0x20], xmm2
00007e4af17d3821  vmovaps [rsp+0x30], xmm3
00007e4af17d3827  vmovaps [rsp+0x40], xmm4
00007e4af17d382d  vmovaps [rsp+0x50], xmm5
00007e4af17d3833  vmovaps [rsp+0x60], xmm6
00007e4af17d3839  vmovaps [rsp+0x70], xmm7
00007e4af17d383f  vmovaps [rsp+0x80], xmm8
00007e4af17d3848  vmovaps [rsp+0x90], xmm9
00007e4af17d3851  vmovaps [rsp+0xA0], xmm10
00007e4af17d385a  vmovaps [rsp+0xB0], xmm11
00007e4af17d3863  vmovaps [rsp+0xC0], xmm12
00007e4af17d386c  vmovaps [rsp+0xD0], xmm13
00007e4af17d3875  vmovaps [rsp+0xE0], xmm14
00007e4af17d387e  sub rsp, 0x30
00007e4af17d3882  movaps [rsp], xmm15
00007e4af17d3887  movaps [rsp+0x10], xmm13
00007e4af17d388d  movaps [rsp+0x20], xmm10
00007e4af17d3893  lea rdi, [rsp]
00007e4af17d3897  mov esi, 0x00
00007e4af17d389c  mov rax, 0x6256754A7530
00007e4af17d38a6  call rax
00007e4af17d38a8  movaps xmm15, [rsp]
00007e4af17d38ad  add rsp, 0x30
00007e4af17d38b1  vmovaps xmm0, [rsp]
00007e4af17d38b6  vmovaps xmm1, [rsp+0x10]
00007e4af17d38bc  vmovaps xmm2, [rsp+0x20]
00007e4af17d38c2  vmovaps xmm3, [rsp+0x30]
00007e4af17d38c8  vmovaps xmm4, [rsp+0x40]
00007e4af17d38ce  vmovaps xmm5, [rsp+0x50]
00007e4af17d38d4  vmovaps xmm6, [rsp+0x60]
00007e4af17d38da  vmovaps xmm7, [rsp+0x70]
00007e4af17d38e0  vmovaps xmm8, [rsp+0x80]
00007e4af17d38e9  vmovaps xmm9, [rsp+0x90]
00007e4af17d38f2  vmovaps xmm10, [rsp+0xA0]
00007e4af17d38fb  vmovaps xmm11, [rsp+0xB0]
00007e4af17d3904  vmovaps xmm12, [rsp+0xC0]
00007e4af17d390d  vmovaps xmm13, [rsp+0xD0]
00007e4af17d3916  vmovaps xmm14, [rsp+0xE0]
00007e4af17d391f  add rsp, 0xF0
00007e4af17d3926  pop r11
00007e4af17d3928  pop r10
00007e4af17d392a  pop r9
00007e4af17d392c  pop r8
00007e4af17d392e  pop rsi
00007e4af17d392f  pop rdi
00007e4af17d3930  pop rdx
00007e4af17d3931  pop rcx
00007e4af17d3932  pop rax
00007e4af17d3933  add rsp, 0x08
00007e4af17d3937  jmp 0x00007E4AF17CFF55
00007e4af17d393c  call 0x00007E4AF160C260
00007e4af17d3941  jmp 0x00007E4AF17CFFB0
00007e4af17d3946  sub rsp, 0x08
00007e4af17d394a  push rax
00007e4af17d394b  push rcx
00007e4af17d394c  push rdx
00007e4af17d394d  push rdi
00007e4af17d394e  push rsi
00007e4af17d394f  push r8
00007e4af17d3951  push r9
00007e4af17d3953  push r10
00007e4af17d3955  push r11
00007e4af17d3957  sub rsp, 0xF0
00007e4af17d395e  vmovaps [rsp], xmm0
00007e4af17d3963  vmovaps [rsp+0x10], xmm1
00007e4af17d3969  vmovaps [rsp+0x20], xmm2
00007e4af17d396f  vmovaps [rsp+0x30], xmm3
00007e4af17d3975  vmovaps [rsp+0x40], xmm4
00007e4af17d397b  vmovaps [rsp+0x50], xmm5
00007e4af17d3981  vmovaps [rsp+0x60], xmm6
00007e4af17d3987  vmovaps [rsp+0x70], xmm7
00007e4af17d398d  vmovaps [rsp+0x80], xmm8
00007e4af17d3996  vmovaps [rsp+0x90], xmm10
00007e4af17d399f  vmovaps [rsp+0xA0], xmm11
00007e4af17d39a8  vmovaps [rsp+0xB0], xmm12
00007e4af17d39b1  vmovaps [rsp+0xC0], xmm13
00007e4af17d39ba  vmovaps [rsp+0xD0], xmm14
00007e4af17d39c3  vmovaps [rsp+0xE0], xmm15
00007e4af17d39cc  sub rsp, 0x30
00007e4af17d39d0  movaps [rsp], xmm9
00007e4af17d39d5  movaps [rsp+0x10], xmm8
00007e4af17d39db  movaps [rsp+0x20], xmm10
00007e4af17d39e1  lea rdi, [rsp]
00007e4af17d39e5  mov esi, 0x00
00007e4af17d39ea  mov rax, 0x6256754A7530
00007e4af17d39f4  call rax
00007e4af17d39f6  movaps xmm9, [rsp]
00007e4af17d39fb  add rsp, 0x30
00007e4af17d39ff  vmovaps xmm0, [rsp]
00007e4af17d3a04  vmovaps xmm1, [rsp+0x10]
00007e4af17d3a0a  vmovaps xmm2, [rsp+0x20]
00007e4af17d3a10  vmovaps xmm3, [rsp+0x30]
00007e4af17d3a16  vmovaps xmm4, [rsp+0x40]
00007e4af17d3a1c  vmovaps xmm5, [rsp+0x50]
00007e4af17d3a22  vmovaps xmm6, [rsp+0x60]
00007e4af17d3a28  vmovaps xmm7, [rsp+0x70]
00007e4af17d3a2e  vmovaps xmm8, [rsp+0x80]
00007e4af17d3a37  vmovaps xmm10, [rsp+0x90]
00007e4af17d3a40  vmovaps xmm11, [rsp+0xA0]
00007e4af17d3a49  vmovaps xmm12, [rsp+0xB0]
00007e4af17d3a52  vmovaps xmm13, [rsp+0xC0]
00007e4af17d3a5b  vmovaps xmm14, [rsp+0xD0]
00007e4af17d3a64  vmovaps xmm15, [rsp+0xE0]
00007e4af17d3a6d  add rsp, 0xF0
00007e4af17d3a74  pop r11
00007e4af17d3a76  pop r10
00007e4af17d3a78  pop r9
00007e4af17d3a7a  pop r8
00007e4af17d3a7c  pop rsi
00007e4af17d3a7d  pop rdi
00007e4af17d3a7e  pop rdx
00007e4af17d3a7f  pop rcx
00007e4af17d3a80  pop rax
00007e4af17d3a81  add rsp, 0x08
00007e4af17d3a85  jmp 0x00007E4AF17CFFE1
00007e4af17d3a8a  sub rsp, 0x08
00007e4af17d3a8e  push rax
00007e4af17d3a8f  push rcx
00007e4af17d3a90  push rdx
00007e4af17d3a91  push rdi
00007e4af17d3a92  push rsi
00007e4af17d3a93  push r8
00007e4af17d3a95  push r9
00007e4af17d3a97  push r10
00007e4af17d3a99  push r11
00007e4af17d3a9b  sub rsp, 0xF0
00007e4af17d3aa2  vmovaps [rsp], xmm0
00007e4af17d3aa7  vmovaps [rsp+0x10], xmm1
00007e4af17d3aad  vmovaps [rsp+0x20], xmm2
00007e4af17d3ab3  vmovaps [rsp+0x30], xmm3
00007e4af17d3ab9  vmovaps [rsp+0x40], xmm4
00007e4af17d3abf  vmovaps [rsp+0x50], xmm5
00007e4af17d3ac5  vmovaps [rsp+0x60], xmm6
00007e4af17d3acb  vmovaps [rsp+0x70], xmm7
00007e4af17d3ad1  vmovaps [rsp+0x80], xmm8
00007e4af17d3ada  vmovaps [rsp+0x90], xmm9
00007e4af17d3ae3  vmovaps [rsp+0xA0], xmm11
00007e4af17d3aec  vmovaps [rsp+0xB0], xmm12
00007e4af17d3af5  vmovaps [rsp+0xC0], xmm13
00007e4af17d3afe  vmovaps [rsp+0xD0], xmm14
00007e4af17d3b07  vmovaps [rsp+0xE0], xmm15
00007e4af17d3b10  sub rsp, 0x30
00007e4af17d3b14  movaps [rsp], xmm10
00007e4af17d3b19  movaps [rsp+0x10], xmm1
00007e4af17d3b1e  movaps [rsp+0x20], xmm11
00007e4af17d3b24  lea rdi, [rsp]
00007e4af17d3b28  mov esi, 0x00
00007e4af17d3b2d  mov rax, 0x6256754A7530
00007e4af17d3b37  call rax
00007e4af17d3b39  movaps xmm10, [rsp]
00007e4af17d3b3e  add rsp, 0x30
00007e4af17d3b42  vmovaps xmm0, [rsp]
00007e4af17d3b47  vmovaps xmm1, [rsp+0x10]
00007e4af17d3b4d  vmovaps xmm2, [rsp+0x20]
00007e4af17d3b53  vmovaps xmm3, [rsp+0x30]
00007e4af17d3b59  vmovaps xmm4, [rsp+0x40]
00007e4af17d3b5f  vmovaps xmm5, [rsp+0x50]
00007e4af17d3b65  vmovaps xmm6, [rsp+0x60]
00007e4af17d3b6b  vmovaps xmm7, [rsp+0x70]
00007e4af17d3b71  vmovaps xmm8, [rsp+0x80]
00007e4af17d3b7a  vmovaps xmm9, [rsp+0x90]
00007e4af17d3b83  vmovaps xmm11, [rsp+0xA0]
00007e4af17d3b8c  vmovaps xmm12, [rsp+0xB0]
00007e4af17d3b95  vmovaps xmm13, [rsp+0xC0]
00007e4af17d3b9e  vmovaps xmm14, [rsp+0xD0]
00007e4af17d3ba7  vmovaps xmm15, [rsp+0xE0]
00007e4af17d3bb0  add rsp, 0xF0
00007e4af17d3bb7  pop r11
00007e4af17d3bb9  pop r10
00007e4af17d3bbb  pop r9
00007e4af17d3bbd  pop r8
00007e4af17d3bbf  pop rsi
00007e4af17d3bc0  pop rdi
00007e4af17d3bc1  pop rdx
00007e4af17d3bc2  pop rcx
00007e4af17d3bc3  pop rax
00007e4af17d3bc4  add rsp, 0x08
00007e4af17d3bc8  jmp 0x00007E4AF17CFFFC
00007e4af17d3bcd  sub rsp, 0x08
00007e4af17d3bd1  push rax
00007e4af17d3bd2  push rcx
00007e4af17d3bd3  push rdx
00007e4af17d3bd4  push rdi
00007e4af17d3bd5  push rsi
00007e4af17d3bd6  push r8
00007e4af17d3bd8  push r9
00007e4af17d3bda  push r10
00007e4af17d3bdc  push r11
00007e4af17d3bde  sub rsp, 0xF0
00007e4af17d3be5  vmovaps [rsp], xmm0
00007e4af17d3bea  vmovaps [rsp+0x10], xmm2
00007e4af17d3bf0  vmovaps [rsp+0x20], xmm3
00007e4af17d3bf6  vmovaps [rsp+0x30], xmm4
00007e4af17d3bfc  vmovaps [rsp+0x40], xmm5
00007e4af17d3c02  vmovaps [rsp+0x50], xmm6
00007e4af17d3c08  vmovaps [rsp+0x60], xmm7
00007e4af17d3c0e  vmovaps [rsp+0x70], xmm8
00007e4af17d3c14  vmovaps [rsp+0x80], xmm9
00007e4af17d3c1d  vmovaps [rsp+0x90], xmm10
00007e4af17d3c26  vmovaps [rsp+0xA0], xmm11
00007e4af17d3c2f  vmovaps [rsp+0xB0], xmm12
00007e4af17d3c38  vmovaps [rsp+0xC0], xmm13
00007e4af17d3c41  vmovaps [rsp+0xD0], xmm14
00007e4af17d3c4a  vmovaps [rsp+0xE0], xmm15
00007e4af17d3c53  sub rsp, 0x30
00007e4af17d3c57  movaps [rsp], xmm1
00007e4af17d3c5b  movaps [rsp+0x10], xmm14
00007e4af17d3c61  movaps [rsp+0x20], xmm6
00007e4af17d3c66  lea rdi, [rsp]
00007e4af17d3c6a  mov esi, 0x00
00007e4af17d3c6f  mov rax, 0x6256754A7530
00007e4af17d3c79  call rax
00007e4af17d3c7b  movaps xmm1, [rsp]
00007e4af17d3c7f  add rsp, 0x30
00007e4af17d3c83  vmovaps xmm0, [rsp]
00007e4af17d3c88  vmovaps xmm2, [rsp+0x10]
00007e4af17d3c8e  vmovaps xmm3, [rsp+0x20]
00007e4af17d3c94  vmovaps xmm4, [rsp+0x30]
00007e4af17d3c9a  vmovaps xmm5, [rsp+0x40]
00007e4af17d3ca0  vmovaps xmm6, [rsp+0x50]
00007e4af17d3ca6  vmovaps xmm7, [rsp+0x60]
00007e4af17d3cac  vmovaps xmm8, [rsp+0x70]
00007e4af17d3cb2  vmovaps xmm9, [rsp+0x80]
00007e4af17d3cbb  vmovaps xmm10, [rsp+0x90]
00007e4af17d3cc4  vmovaps xmm11, [rsp+0xA0]
00007e4af17d3ccd  vmovaps xmm12, [rsp+0xB0]
00007e4af17d3cd6  vmovaps xmm13, [rsp+0xC0]
00007e4af17d3cdf  vmovaps xmm14, [rsp+0xD0]
00007e4af17d3ce8  vmovaps xmm15, [rsp+0xE0]
00007e4af17d3cf1  add rsp, 0xF0
00007e4af17d3cf8  pop r11
00007e4af17d3cfa  pop r10
00007e4af17d3cfc  pop r9
00007e4af17d3cfe  pop r8
00007e4af17d3d00  pop rsi
00007e4af17d3d01  pop rdi
00007e4af17d3d02  pop rdx
00007e4af17d3d03  pop rcx
00007e4af17d3d04  pop rax
00007e4af17d3d05  add rsp, 0x08
00007e4af17d3d09  jmp 0x00007E4AF17D0015
00007e4af17d3d0e  sub rsp, 0x08
00007e4af17d3d12  push rax
00007e4af17d3d13  push rcx
00007e4af17d3d14  push rdx
00007e4af17d3d15  push rdi
00007e4af17d3d16  push rsi
00007e4af17d3d17  push r8
00007e4af17d3d19  push r9
00007e4af17d3d1b  push r10
00007e4af17d3d1d  push r11
00007e4af17d3d1f  sub rsp, 0xF0
00007e4af17d3d26  vmovaps [rsp], xmm0
00007e4af17d3d2b  vmovaps [rsp+0x10], xmm1
00007e4af17d3d31  vmovaps [rsp+0x20], xmm2
00007e4af17d3d37  vmovaps [rsp+0x30], xmm3
00007e4af17d3d3d  vmovaps [rsp+0x40], xmm4
00007e4af17d3d43  vmovaps [rsp+0x50], xmm5
00007e4af17d3d49  vmovaps [rsp+0x60], xmm6
00007e4af17d3d4f  vmovaps [rsp+0x70], xmm7
00007e4af17d3d55  vmovaps [rsp+0x80], xmm8
00007e4af17d3d5e  vmovaps [rsp+0x90], xmm9
00007e4af17d3d67  vmovaps [rsp+0xA0], xmm10
00007e4af17d3d70  vmovaps [rsp+0xB0], xmm12
00007e4af17d3d79  vmovaps [rsp+0xC0], xmm13
00007e4af17d3d82  vmovaps [rsp+0xD0], xmm14
00007e4af17d3d8b  vmovaps [rsp+0xE0], xmm15
00007e4af17d3d94  sub rsp, 0x30
00007e4af17d3d98  movaps [rsp], xmm11
00007e4af17d3d9d  movaps [rsp+0x10], xmm13
00007e4af17d3da3  movaps [rsp+0x20], xmm14
00007e4af17d3da9  lea rdi, [rsp]
00007e4af17d3dad  mov esi, 0x00
00007e4af17d3db2  mov rax, 0x6256754A7530
00007e4af17d3dbc  call rax
00007e4af17d3dbe  movaps xmm11, [rsp]
00007e4af17d3dc3  add rsp, 0x30
00007e4af17d3dc7  vmovaps xmm0, [rsp]
00007e4af17d3dcc  vmovaps xmm1, [rsp+0x10]
00007e4af17d3dd2  vmovaps xmm2, [rsp+0x20]
00007e4af17d3dd8  vmovaps xmm3, [rsp+0x30]
00007e4af17d3dde  vmovaps xmm4, [rsp+0x40]
00007e4af17d3de4  vmovaps xmm5, [rsp+0x50]
00007e4af17d3dea  vmovaps xmm6, [rsp+0x60]
00007e4af17d3df0  vmovaps xmm7, [rsp+0x70]
00007e4af17d3df6  vmovaps xmm8, [rsp+0x80]
00007e4af17d3dff  vmovaps xmm9, [rsp+0x90]
00007e4af17d3e08  vmovaps xmm10, [rsp+0xA0]
00007e4af17d3e11  vmovaps xmm12, [rsp+0xB0]
00007e4af17d3e1a  vmovaps xmm13, [rsp+0xC0]
00007e4af17d3e23  vmovaps xmm14, [rsp+0xD0]
00007e4af17d3e2c  vmovaps xmm15, [rsp+0xE0]
00007e4af17d3e35  add rsp, 0xF0
00007e4af17d3e3c  pop r11
00007e4af17d3e3e  pop r10
00007e4af17d3e40  pop r9
00007e4af17d3e42  pop r8
00007e4af17d3e44  pop rsi
00007e4af17d3e45  pop rdi
00007e4af17d3e46  pop rdx
00007e4af17d3e47  pop rcx
00007e4af17d3e48  pop rax
00007e4af17d3e49  add rsp, 0x08
00007e4af17d3e4d  jmp 0x00007E4AF17D003F
00007e4af17d3e52  sub rsp, 0x08
00007e4af17d3e56  push rax
00007e4af17d3e57  push rcx
00007e4af17d3e58  push rdx
00007e4af17d3e59  push rdi
00007e4af17d3e5a  push rsi
00007e4af17d3e5b  push r8
00007e4af17d3e5d  push r9
00007e4af17d3e5f  push r10
00007e4af17d3e61  push r11
00007e4af17d3e63  sub rsp, 0xF0
00007e4af17d3e6a  vmovaps [rsp], xmm0
00007e4af17d3e6f  vmovaps [rsp+0x10], xmm1
00007e4af17d3e75  vmovaps [rsp+0x20], xmm2
00007e4af17d3e7b  vmovaps [rsp+0x30], xmm3
00007e4af17d3e81  vmovaps [rsp+0x40], xmm4
00007e4af17d3e87  vmovaps [rsp+0x50], xmm5
00007e4af17d3e8d  vmovaps [rsp+0x60], xmm6
00007e4af17d3e93  vmovaps [rsp+0x70], xmm7
00007e4af17d3e99  vmovaps [rsp+0x80], xmm8
00007e4af17d3ea2  vmovaps [rsp+0x90], xmm9
00007e4af17d3eab  vmovaps [rsp+0xA0], xmm10
00007e4af17d3eb4  vmovaps [rsp+0xB0], xmm11
00007e4af17d3ebd  vmovaps [rsp+0xC0], xmm12
00007e4af17d3ec6  vmovaps [rsp+0xD0], xmm14
00007e4af17d3ecf  vmovaps [rsp+0xE0], xmm15
00007e4af17d3ed8  sub rsp, 0x30
00007e4af17d3edc  movaps [rsp], xmm13
00007e4af17d3ee1  movaps [rsp+0x10], xmm8
00007e4af17d3ee7  movaps [rsp+0x20], xmm14
00007e4af17d3eed  lea rdi, [rsp]
00007e4af17d3ef1  mov esi, 0x00
00007e4af17d3ef6  mov rax, 0x6256754A7530
00007e4af17d3f00  call rax
00007e4af17d3f02  movaps xmm13, [rsp]
00007e4af17d3f07  add rsp, 0x30
00007e4af17d3f0b  vmovaps xmm0, [rsp]
00007e4af17d3f10  vmovaps xmm1, [rsp+0x10]
00007e4af17d3f16  vmovaps xmm2, [rsp+0x20]
00007e4af17d3f1c  vmovaps xmm3, [rsp+0x30]
00007e4af17d3f22  vmovaps xmm4, [rsp+0x40]
00007e4af17d3f28  vmovaps xmm5, [rsp+0x50]
00007e4af17d3f2e  vmovaps xmm6, [rsp+0x60]
00007e4af17d3f34  vmovaps xmm7, [rsp+0x70]
00007e4af17d3f3a  vmovaps xmm8, [rsp+0x80]
00007e4af17d3f43  vmovaps xmm9, [rsp+0x90]
00007e4af17d3f4c  vmovaps xmm10, [rsp+0xA0]
00007e4af17d3f55  vmovaps xmm11, [rsp+0xB0]
00007e4af17d3f5e  vmovaps xmm12, [rsp+0xC0]
00007e4af17d3f67  vmovaps xmm14, [rsp+0xD0]
00007e4af17d3f70  vmovaps xmm15, [rsp+0xE0]
00007e4af17d3f79  add rsp, 0xF0
00007e4af17d3f80  pop r11
00007e4af17d3f82  pop r10
00007e4af17d3f84  pop r9
00007e4af17d3f86  pop r8
00007e4af17d3f88  pop rsi
00007e4af17d3f89  pop rdi
00007e4af17d3f8a  pop rdx
00007e4af17d3f8b  pop rcx
00007e4af17d3f8c  pop rax
00007e4af17d3f8d  add rsp, 0x08
00007e4af17d3f91  jmp 0x00007E4AF17D006E
00007e4af17d3f96  sub rsp, 0x08
00007e4af17d3f9a  push rax
00007e4af17d3f9b  push rcx
00007e4af17d3f9c  push rdx
00007e4af17d3f9d  push rdi
00007e4af17d3f9e  push rsi
00007e4af17d3f9f  push r8
00007e4af17d3fa1  push r9
00007e4af17d3fa3  push r10
00007e4af17d3fa5  push r11
00007e4af17d3fa7  sub rsp, 0xF0
00007e4af17d3fae  vmovaps [rsp], xmm0
00007e4af17d3fb3  vmovaps [rsp+0x10], xmm1
00007e4af17d3fb9  vmovaps [rsp+0x20], xmm2
00007e4af17d3fbf  vmovaps [rsp+0x30], xmm3
00007e4af17d3fc5  vmovaps [rsp+0x40], xmm4
00007e4af17d3fcb  vmovaps [rsp+0x50], xmm5
00007e4af17d3fd1  vmovaps [rsp+0x60], xmm6
00007e4af17d3fd7  vmovaps [rsp+0x70], xmm7
00007e4af17d3fdd  vmovaps [rsp+0x80], xmm9
00007e4af17d3fe6  vmovaps [rsp+0x90], xmm10
00007e4af17d3fef  vmovaps [rsp+0xA0], xmm11
00007e4af17d3ff8  vmovaps [rsp+0xB0], xmm12
00007e4af17d4001  vmovaps [rsp+0xC0], xmm13
00007e4af17d400a  vmovaps [rsp+0xD0], xmm14
00007e4af17d4013  vmovaps [rsp+0xE0], xmm15
00007e4af17d401c  sub rsp, 0x30
00007e4af17d4020  movaps [rsp], xmm8
00007e4af17d4025  movaps [rsp+0x10], xmm7
00007e4af17d402a  movaps [rsp+0x20], xmm14
00007e4af17d4030  lea rdi, [rsp]
00007e4af17d4034  mov esi, 0x00
00007e4af17d4039  mov rax, 0x6256754A7530
00007e4af17d4043  call rax
00007e4af17d4045  movaps xmm8, [rsp]
00007e4af17d404a  add rsp, 0x30
00007e4af17d404e  vmovaps xmm0, [rsp]
00007e4af17d4053  vmovaps xmm1, [rsp+0x10]
00007e4af17d4059  vmovaps xmm2, [rsp+0x20]
00007e4af17d405f  vmovaps xmm3, [rsp+0x30]
00007e4af17d4065  vmovaps xmm4, [rsp+0x40]
00007e4af17d406b  vmovaps xmm5, [rsp+0x50]
00007e4af17d4071  vmovaps xmm6, [rsp+0x60]
00007e4af17d4077  vmovaps xmm7, [rsp+0x70]
00007e4af17d407d  vmovaps xmm9, [rsp+0x80]
00007e4af17d4086  vmovaps xmm10, [rsp+0x90]
00007e4af17d408f  vmovaps xmm11, [rsp+0xA0]
00007e4af17d4098  vmovaps xmm12, [rsp+0xB0]
00007e4af17d40a1  vmovaps xmm13, [rsp+0xC0]
00007e4af17d40aa  vmovaps xmm14, [rsp+0xD0]
00007e4af17d40b3  vmovaps xmm15, [rsp+0xE0]
00007e4af17d40bc  add rsp, 0xF0
00007e4af17d40c3  pop r11
00007e4af17d40c5  pop r10
00007e4af17d40c7  pop r9
00007e4af17d40c9  pop r8
00007e4af17d40cb  pop rsi
00007e4af17d40cc  pop rdi
00007e4af17d40cd  pop rdx
00007e4af17d40ce  pop rcx
00007e4af17d40cf  pop rax
00007e4af17d40d0  add rsp, 0x08
00007e4af17d40d4  jmp 0x00007E4AF17D0094
00007e4af17d40d9  sub rsp, 0x08
00007e4af17d40dd  push rax
00007e4af17d40de  push rcx
00007e4af17d40df  push rdx
00007e4af17d40e0  push rdi
00007e4af17d40e1  push rsi
00007e4af17d40e2  push r8
00007e4af17d40e4  push r9
00007e4af17d40e6  push r10
00007e4af17d40e8  push r11
00007e4af17d40ea  sub rsp, 0xF0
00007e4af17d40f1  vmovaps [rsp], xmm0
00007e4af17d40f6  vmovaps [rsp+0x10], xmm1
00007e4af17d40fc  vmovaps [rsp+0x20], xmm2
00007e4af17d4102  vmovaps [rsp+0x30], xmm3
00007e4af17d4108  vmovaps [rsp+0x40], xmm4
00007e4af17d410e  vmovaps [rsp+0x50], xmm5
00007e4af17d4114  vmovaps [rsp+0x60], xmm6
00007e4af17d411a  vmovaps [rsp+0x70], xmm7
00007e4af17d4120  vmovaps [rsp+0x80], xmm8
00007e4af17d4129  vmovaps [rsp+0x90], xmm9
00007e4af17d4132  vmovaps [rsp+0xA0], xmm10
00007e4af17d413b  vmovaps [rsp+0xB0], xmm11
00007e4af17d4144  vmovaps [rsp+0xC0], xmm12
00007e4af17d414d  vmovaps [rsp+0xD0], xmm13
00007e4af17d4156  vmovaps [rsp+0xE0], xmm15
00007e4af17d415f  sub rsp, 0x30
00007e4af17d4163  movaps [rsp], xmm14
00007e4af17d4168  movaps [rsp+0x10], xmm12
00007e4af17d416e  movaps [rsp+0x20], xmm9
00007e4af17d4174  lea rdi, [rsp]
00007e4af17d4178  mov esi, 0x00
00007e4af17d417d  mov rax, 0x6256754A7530
00007e4af17d4187  call rax
00007e4af17d4189  movaps xmm14, [rsp]
00007e4af17d418e  add rsp, 0x30
00007e4af17d4192  vmovaps xmm0, [rsp]
00007e4af17d4197  vmovaps xmm1, [rsp+0x10]
00007e4af17d419d  vmovaps xmm2, [rsp+0x20]
00007e4af17d41a3  vmovaps xmm3, [rsp+0x30]
00007e4af17d41a9  vmovaps xmm4, [rsp+0x40]
00007e4af17d41af  vmovaps xmm5, [rsp+0x50]
00007e4af17d41b5  vmovaps xmm6, [rsp+0x60]
00007e4af17d41bb  vmovaps xmm7, [rsp+0x70]
00007e4af17d41c1  vmovaps xmm8, [rsp+0x80]
00007e4af17d41ca  vmovaps xmm9, [rsp+0x90]
00007e4af17d41d3  vmovaps xmm10, [rsp+0xA0]
00007e4af17d41dc  vmovaps xmm11, [rsp+0xB0]
00007e4af17d41e5  vmovaps xmm12, [rsp+0xC0]
00007e4af17d41ee  vmovaps xmm13, [rsp+0xD0]
00007e4af17d41f7  vmovaps xmm15, [rsp+0xE0]
00007e4af17d4200  add rsp, 0xF0
00007e4af17d4207  pop r11
00007e4af17d4209  pop r10
00007e4af17d420b  pop r9
00007e4af17d420d  pop r8
00007e4af17d420f  pop rsi
00007e4af17d4210  pop rdi
00007e4af17d4211  pop rdx
00007e4af17d4212  pop rcx
00007e4af17d4213  pop rax
00007e4af17d4214  add rsp, 0x08
00007e4af17d4218  jmp 0x00007E4AF17D00AE
00007e4af17d421d  sub rsp, 0x08
00007e4af17d4221  push rax
00007e4af17d4222  push rcx
00007e4af17d4223  push rdx
00007e4af17d4224  push rdi
00007e4af17d4225  push rsi
00007e4af17d4226  push r8
00007e4af17d4228  push r9
00007e4af17d422a  push r10
00007e4af17d422c  push r11
00007e4af17d422e  sub rsp, 0xF0
00007e4af17d4235  vmovaps [rsp], xmm0
00007e4af17d423a  vmovaps [rsp+0x10], xmm1
00007e4af17d4240  vmovaps [rsp+0x20], xmm2
00007e4af17d4246  vmovaps [rsp+0x30], xmm3
00007e4af17d424c  vmovaps [rsp+0x40], xmm4
00007e4af17d4252  vmovaps [rsp+0x50], xmm5
00007e4af17d4258  vmovaps [rsp+0x60], xmm6
00007e4af17d425e  vmovaps [rsp+0x70], xmm7
00007e4af17d4264  vmovaps [rsp+0x80], xmm8
00007e4af17d426d  vmovaps [rsp+0x90], xmm10
00007e4af17d4276  vmovaps [rsp+0xA0], xmm11
00007e4af17d427f  vmovaps [rsp+0xB0], xmm12
00007e4af17d4288  vmovaps [rsp+0xC0], xmm13
00007e4af17d4291  vmovaps [rsp+0xD0], xmm14
00007e4af17d429a  vmovaps [rsp+0xE0], xmm15
00007e4af17d42a3  sub rsp, 0x30
00007e4af17d42a7  movaps [rsp], xmm9
00007e4af17d42ac  movaps [rsp+0x10], xmm7
00007e4af17d42b1  movaps [rsp+0x20], xmm12
00007e4af17d42b7  lea rdi, [rsp]
00007e4af17d42bb  mov esi, 0x00
00007e4af17d42c0  mov rax, 0x6256754A7530
00007e4af17d42ca  call rax
00007e4af17d42cc  movaps xmm9, [rsp]
00007e4af17d42d1  add rsp, 0x30
00007e4af17d42d5  vmovaps xmm0, [rsp]
00007e4af17d42da  vmovaps xmm1, [rsp+0x10]
00007e4af17d42e0  vmovaps xmm2, [rsp+0x20]
00007e4af17d42e6  vmovaps xmm3, [rsp+0x30]
00007e4af17d42ec  vmovaps xmm4, [rsp+0x40]
00007e4af17d42f2  vmovaps xmm5, [rsp+0x50]
00007e4af17d42f8  vmovaps xmm6, [rsp+0x60]
00007e4af17d42fe  vmovaps xmm7, [rsp+0x70]
00007e4af17d4304  vmovaps xmm8, [rsp+0x80]
00007e4af17d430d  vmovaps xmm10, [rsp+0x90]
00007e4af17d4316  vmovaps xmm11, [rsp+0xA0]
00007e4af17d431f  vmovaps xmm12, [rsp+0xB0]
00007e4af17d4328  vmovaps xmm13, [rsp+0xC0]
00007e4af17d4331  vmovaps xmm14, [rsp+0xD0]
00007e4af17d433a  vmovaps xmm15, [rsp+0xE0]
00007e4af17d4343  add rsp, 0xF0
00007e4af17d434a  pop r11
00007e4af17d434c  pop r10
00007e4af17d434e  pop r9
00007e4af17d4350  pop r8
00007e4af17d4352  pop rsi
00007e4af17d4353  pop rdi
00007e4af17d4354  pop rdx
00007e4af17d4355  pop rcx
00007e4af17d4356  pop rax
00007e4af17d4357  add rsp, 0x08
00007e4af17d435b  jmp 0x00007E4AF17D00DD
00007e4af17d4360  sub rsp, 0x08
00007e4af17d4364  push rax
00007e4af17d4365  push rcx
00007e4af17d4366  push rdx
00007e4af17d4367  push rdi
00007e4af17d4368  push rsi
00007e4af17d4369  push r8
00007e4af17d436b  push r9
00007e4af17d436d  push r10
00007e4af17d436f  push r11
00007e4af17d4371  sub rsp, 0xF0
00007e4af17d4378  vmovaps [rsp], xmm0
00007e4af17d437d  vmovaps [rsp+0x10], xmm1
00007e4af17d4383  vmovaps [rsp+0x20], xmm2
00007e4af17d4389  vmovaps [rsp+0x30], xmm3
00007e4af17d438f  vmovaps [rsp+0x40], xmm4
00007e4af17d4395  vmovaps [rsp+0x50], xmm5
00007e4af17d439b  vmovaps [rsp+0x60], xmm6
00007e4af17d43a1  vmovaps [rsp+0x70], xmm7
00007e4af17d43a7  vmovaps [rsp+0x80], xmm8
00007e4af17d43b0  vmovaps [rsp+0x90], xmm9
00007e4af17d43b9  vmovaps [rsp+0xA0], xmm10
00007e4af17d43c2  vmovaps [rsp+0xB0], xmm11
00007e4af17d43cb  vmovaps [rsp+0xC0], xmm13
00007e4af17d43d4  vmovaps [rsp+0xD0], xmm14
00007e4af17d43dd  vmovaps [rsp+0xE0], xmm15
00007e4af17d43e6  sub rsp, 0x30
00007e4af17d43ea  movaps [rsp], xmm12
00007e4af17d43ef  movaps [rsp+0x10], xmm15
00007e4af17d43f5  movaps [rsp+0x20], xmm11
00007e4af17d43fb  lea rdi, [rsp]
00007e4af17d43ff  mov esi, 0x00
00007e4af17d4404  mov rax, 0x6256754A7530
00007e4af17d440e  call rax
00007e4af17d4410  movaps xmm12, [rsp]
00007e4af17d4415  add rsp, 0x30
00007e4af17d4419  vmovaps xmm0, [rsp]
00007e4af17d441e  vmovaps xmm1, [rsp+0x10]
00007e4af17d4424  vmovaps xmm2, [rsp+0x20]
00007e4af17d442a  vmovaps xmm3, [rsp+0x30]
00007e4af17d4430  vmovaps xmm4, [rsp+0x40]
00007e4af17d4436  vmovaps xmm5, [rsp+0x50]
00007e4af17d443c  vmovaps xmm6, [rsp+0x60]
00007e4af17d4442  vmovaps xmm7, [rsp+0x70]
00007e4af17d4448  vmovaps xmm8, [rsp+0x80]
00007e4af17d4451  vmovaps xmm9, [rsp+0x90]
00007e4af17d445a  vmovaps xmm10, [rsp+0xA0]
00007e4af17d4463  vmovaps xmm11, [rsp+0xB0]
00007e4af17d446c  vmovaps xmm13, [rsp+0xC0]
00007e4af17d4475  vmovaps xmm14, [rsp+0xD0]
00007e4af17d447e  vmovaps xmm15, [rsp+0xE0]
00007e4af17d4487  add rsp, 0xF0
00007e4af17d448e  pop r11
00007e4af17d4490  pop r10
00007e4af17d4492  pop r9
00007e4af17d4494  pop r8
00007e4af17d4496  pop rsi
00007e4af17d4497  pop rdi
00007e4af17d4498  pop rdx
00007e4af17d4499  pop rcx
00007e4af17d449a  pop rax
00007e4af17d449b  add rsp, 0x08
00007e4af17d449f  jmp 0x00007E4AF17D00F7
00007e4af17d44a4  sub rsp, 0x08
00007e4af17d44a8  push rax
00007e4af17d44a9  push rcx
00007e4af17d44aa  push rdx
00007e4af17d44ab  push rdi
00007e4af17d44ac  push rsi
00007e4af17d44ad  push r8
00007e4af17d44af  push r9
00007e4af17d44b1  push r10
00007e4af17d44b3  push r11
00007e4af17d44b5  sub rsp, 0xF0
00007e4af17d44bc  vmovaps [rsp], xmm0
00007e4af17d44c1  vmovaps [rsp+0x10], xmm1
00007e4af17d44c7  vmovaps [rsp+0x20], xmm2
00007e4af17d44cd  vmovaps [rsp+0x30], xmm3
00007e4af17d44d3  vmovaps [rsp+0x40], xmm4
00007e4af17d44d9  vmovaps [rsp+0x50], xmm5
00007e4af17d44df  vmovaps [rsp+0x60], xmm6
00007e4af17d44e5  vmovaps [rsp+0x70], xmm7
00007e4af17d44eb  vmovaps [rsp+0x80], xmm8
00007e4af17d44f4  vmovaps [rsp+0x90], xmm9
00007e4af17d44fd  vmovaps [rsp+0xA0], xmm10
00007e4af17d4506  vmovaps [rsp+0xB0], xmm12
00007e4af17d450f  vmovaps [rsp+0xC0], xmm13
00007e4af17d4518  vmovaps [rsp+0xD0], xmm14
00007e4af17d4521  vmovaps [rsp+0xE0], xmm15
00007e4af17d452a  sub rsp, 0x30
00007e4af17d452e  movaps [rsp], xmm11
00007e4af17d4533  movaps [rsp+0x10], xmm7
00007e4af17d4538  movaps [rsp+0x20], xmm15
00007e4af17d453e  lea rdi, [rsp]
00007e4af17d4542  mov esi, 0x00
00007e4af17d4547  mov rax, 0x6256754A7530
00007e4af17d4551  call rax
00007e4af17d4553  movaps xmm11, [rsp]
00007e4af17d4558  add rsp, 0x30
00007e4af17d455c  vmovaps xmm0, [rsp]
00007e4af17d4561  vmovaps xmm1, [rsp+0x10]
00007e4af17d4567  vmovaps xmm2, [rsp+0x20]
00007e4af17d456d  vmovaps xmm3, [rsp+0x30]
00007e4af17d4573  vmovaps xmm4, [rsp+0x40]
00007e4af17d4579  vmovaps xmm5, [rsp+0x50]
00007e4af17d457f  vmovaps xmm6, [rsp+0x60]
00007e4af17d4585  vmovaps xmm7, [rsp+0x70]
00007e4af17d458b  vmovaps xmm8, [rsp+0x80]
00007e4af17d4594  vmovaps xmm9, [rsp+0x90]
00007e4af17d459d  vmovaps xmm10, [rsp+0xA0]
00007e4af17d45a6  vmovaps xmm12, [rsp+0xB0]
00007e4af17d45af  vmovaps xmm13, [rsp+0xC0]
00007e4af17d45b8  vmovaps xmm14, [rsp+0xD0]
00007e4af17d45c1  vmovaps xmm15, [rsp+0xE0]
00007e4af17d45ca  add rsp, 0xF0
00007e4af17d45d1  pop r11
00007e4af17d45d3  pop r10
00007e4af17d45d5  pop r9
00007e4af17d45d7  pop r8
00007e4af17d45d9  pop rsi
00007e4af17d45da  pop rdi
00007e4af17d45db  pop rdx
00007e4af17d45dc  pop rcx
00007e4af17d45dd  pop rax
00007e4af17d45de  add rsp, 0x08
00007e4af17d45e2  jmp 0x00007E4AF17D0123
00007e4af17d45e7  sub rsp, 0x08
00007e4af17d45eb  push rax
00007e4af17d45ec  push rcx
00007e4af17d45ed  push rdx
00007e4af17d45ee  push rdi
00007e4af17d45ef  push rsi
00007e4af17d45f0  push r8
00007e4af17d45f2  push r9
00007e4af17d45f4  push r10
00007e4af17d45f6  push r11
00007e4af17d45f8  sub rsp, 0xF0
00007e4af17d45ff  vmovaps [rsp], xmm0
00007e4af17d4604  vmovaps [rsp+0x10], xmm1
00007e4af17d460a  vmovaps [rsp+0x20], xmm2
00007e4af17d4610  vmovaps [rsp+0x30], xmm3
00007e4af17d4616  vmovaps [rsp+0x40], xmm4
00007e4af17d461c  vmovaps [rsp+0x50], xmm5
00007e4af17d4622  vmovaps [rsp+0x60], xmm6
00007e4af17d4628  vmovaps [rsp+0x70], xmm7
00007e4af17d462e  vmovaps [rsp+0x80], xmm8
00007e4af17d4637  vmovaps [rsp+0x90], xmm9
00007e4af17d4640  vmovaps [rsp+0xA0], xmm10
00007e4af17d4649  vmovaps [rsp+0xB0], xmm11
00007e4af17d4652  vmovaps [rsp+0xC0], xmm12
00007e4af17d465b  vmovaps [rsp+0xD0], xmm13
00007e4af17d4664  vmovaps [rsp+0xE0], xmm14
00007e4af17d466d  sub rsp, 0x30
00007e4af17d4671  movaps [rsp], xmm15
00007e4af17d4676  movaps [rsp+0x10], xmm10
00007e4af17d467c  movaps [rsp+0x20], xmm13
00007e4af17d4682  lea rdi, [rsp]
00007e4af17d4686  mov esi, 0x00
00007e4af17d468b  mov rax, 0x6256754A7530
00007e4af17d4695  call rax
00007e4af17d4697  movaps xmm15, [rsp]
00007e4af17d469c  add rsp, 0x30
00007e4af17d46a0  vmovaps xmm0, [rsp]
00007e4af17d46a5  vmovaps xmm1, [rsp+0x10]
00007e4af17d46ab  vmovaps xmm2, [rsp+0x20]
00007e4af17d46b1  vmovaps xmm3, [rsp+0x30]
00007e4af17d46b7  vmovaps xmm4, [rsp+0x40]
00007e4af17d46bd  vmovaps xmm5, [rsp+0x50]
00007e4af17d46c3  vmovaps xmm6, [rsp+0x60]
00007e4af17d46c9  vmovaps xmm7, [rsp+0x70]
00007e4af17d46cf  vmovaps xmm8, [rsp+0x80]
00007e4af17d46d8  vmovaps xmm9, [rsp+0x90]
00007e4af17d46e1  vmovaps xmm10, [rsp+0xA0]
00007e4af17d46ea  vmovaps xmm11, [rsp+0xB0]
00007e4af17d46f3  vmovaps xmm12, [rsp+0xC0]
00007e4af17d46fc  vmovaps xmm13, [rsp+0xD0]
00007e4af17d4705  vmovaps xmm14, [rsp+0xE0]
00007e4af17d470e  add rsp, 0xF0
00007e4af17d4715  pop r11
00007e4af17d4717  pop r10
00007e4af17d4719  pop r9
00007e4af17d471b  pop r8
00007e4af17d471d  pop rsi
00007e4af17d471e  pop rdi
00007e4af17d471f  pop rdx
00007e4af17d4720  pop rcx
00007e4af17d4721  pop rax
00007e4af17d4722  add rsp, 0x08
00007e4af17d4726  jmp 0x00007E4AF17D013D
00007e4af17d472b  sub rsp, 0x08
00007e4af17d472f  push rax
00007e4af17d4730  push rcx
00007e4af17d4731  push rdx
00007e4af17d4732  push rdi
00007e4af17d4733  push rsi
00007e4af17d4734  push r8
00007e4af17d4736  push r9
00007e4af17d4738  push r10
00007e4af17d473a  push r11
00007e4af17d473c  sub rsp, 0xF0
00007e4af17d4743  vmovaps [rsp], xmm0
00007e4af17d4748  vmovaps [rsp+0x10], xmm1
00007e4af17d474e  vmovaps [rsp+0x20], xmm2
00007e4af17d4754  vmovaps [rsp+0x30], xmm3
00007e4af17d475a  vmovaps [rsp+0x40], xmm4
00007e4af17d4760  vmovaps [rsp+0x50], xmm5
00007e4af17d4766  vmovaps [rsp+0x60], xmm6
00007e4af17d476c  vmovaps [rsp+0x70], xmm7
00007e4af17d4772  vmovaps [rsp+0x80], xmm8
00007e4af17d477b  vmovaps [rsp+0x90], xmm9
00007e4af17d4784  vmovaps [rsp+0xA0], xmm11
00007e4af17d478d  vmovaps [rsp+0xB0], xmm12
00007e4af17d4796  vmovaps [rsp+0xC0], xmm13
00007e4af17d479f  vmovaps [rsp+0xD0], xmm14
00007e4af17d47a8  vmovaps [rsp+0xE0], xmm15
00007e4af17d47b1  sub rsp, 0x30
00007e4af17d47b5  movaps [rsp], xmm10
00007e4af17d47ba  movaps [rsp+0x10], xmm7
00007e4af17d47bf  movaps [rsp+0x20], xmm13
00007e4af17d47c5  lea rdi, [rsp]
00007e4af17d47c9  mov esi, 0x00
00007e4af17d47ce  mov rax, 0x6256754A7530
00007e4af17d47d8  call rax
00007e4af17d47da  movaps xmm10, [rsp]
00007e4af17d47df  add rsp, 0x30
00007e4af17d47e3  vmovaps xmm0, [rsp]
00007e4af17d47e8  vmovaps xmm1, [rsp+0x10]
00007e4af17d47ee  vmovaps xmm2, [rsp+0x20]
00007e4af17d47f4  vmovaps xmm3, [rsp+0x30]
00007e4af17d47fa  vmovaps xmm4, [rsp+0x40]
00007e4af17d4800  vmovaps xmm5, [rsp+0x50]
00007e4af17d4806  vmovaps xmm6, [rsp+0x60]
00007e4af17d480c  vmovaps xmm7, [rsp+0x70]
00007e4af17d4812  vmovaps xmm8, [rsp+0x80]
00007e4af17d481b  vmovaps xmm9, [rsp+0x90]
00007e4af17d4824  vmovaps xmm11, [rsp+0xA0]
00007e4af17d482d  vmovaps xmm12, [rsp+0xB0]
00007e4af17d4836  vmovaps xmm13, [rsp+0xC0]
00007e4af17d483f  vmovaps xmm14, [rsp+0xD0]
00007e4af17d4848  vmovaps xmm15, [rsp+0xE0]
00007e4af17d4851  add rsp, 0xF0
00007e4af17d4858  pop r11
00007e4af17d485a  pop r10
00007e4af17d485c  pop r9
00007e4af17d485e  pop r8
00007e4af17d4860  pop rsi
00007e4af17d4861  pop rdi
00007e4af17d4862  pop rdx
00007e4af17d4863  pop rcx
00007e4af17d4864  pop rax
00007e4af17d4865  add rsp, 0x08
00007e4af17d4869  jmp 0x00007E4AF17D0169
00007e4af17d486e  sub rsp, 0x08
00007e4af17d4872  push rax
00007e4af17d4873  push rcx
00007e4af17d4874  push rdx
00007e4af17d4875  push rdi
00007e4af17d4876  push rsi
00007e4af17d4877  push r8
00007e4af17d4879  push r9
00007e4af17d487b  push r10
00007e4af17d487d  push r11
00007e4af17d487f  sub rsp, 0xF0
00007e4af17d4886  vmovaps [rsp], xmm0
00007e4af17d488b  vmovaps [rsp+0x10], xmm1
00007e4af17d4891  vmovaps [rsp+0x20], xmm2
00007e4af17d4897  vmovaps [rsp+0x30], xmm3
00007e4af17d489d  vmovaps [rsp+0x40], xmm4
00007e4af17d48a3  vmovaps [rsp+0x50], xmm5
00007e4af17d48a9  vmovaps [rsp+0x60], xmm6
00007e4af17d48af  vmovaps [rsp+0x70], xmm7
00007e4af17d48b5  vmovaps [rsp+0x80], xmm8
00007e4af17d48be  vmovaps [rsp+0x90], xmm9
00007e4af17d48c7  vmovaps [rsp+0xA0], xmm10
00007e4af17d48d0  vmovaps [rsp+0xB0], xmm11
00007e4af17d48d9  vmovaps [rsp+0xC0], xmm12
00007e4af17d48e2  vmovaps [rsp+0xD0], xmm14
00007e4af17d48eb  vmovaps [rsp+0xE0], xmm15
00007e4af17d48f4  sub rsp, 0x30
00007e4af17d48f8  movaps [rsp], xmm13
00007e4af17d48fd  movaps [rsp+0x10], xmm1
00007e4af17d4902  movaps [rsp+0x20], xmm8
00007e4af17d4908  lea rdi, [rsp]
00007e4af17d490c  mov esi, 0x00
00007e4af17d4911  mov rax, 0x6256754A7530
00007e4af17d491b  call rax
00007e4af17d491d  movaps xmm13, [rsp]
00007e4af17d4922  add rsp, 0x30
00007e4af17d4926  vmovaps xmm0, [rsp]
00007e4af17d492b  vmovaps xmm1, [rsp+0x10]
00007e4af17d4931  vmovaps xmm2, [rsp+0x20]
00007e4af17d4937  vmovaps xmm3, [rsp+0x30]
00007e4af17d493d  vmovaps xmm4, [rsp+0x40]
00007e4af17d4943  vmovaps xmm5, [rsp+0x50]
00007e4af17d4949  vmovaps xmm6, [rsp+0x60]
00007e4af17d494f  vmovaps xmm7, [rsp+0x70]
00007e4af17d4955  vmovaps xmm8, [rsp+0x80]
00007e4af17d495e  vmovaps xmm9, [rsp+0x90]
00007e4af17d4967  vmovaps xmm10, [rsp+0xA0]
00007e4af17d4970  vmovaps xmm11, [rsp+0xB0]
00007e4af17d4979  vmovaps xmm12, [rsp+0xC0]
00007e4af17d4982  vmovaps xmm14, [rsp+0xD0]
00007e4af17d498b  vmovaps xmm15, [rsp+0xE0]
00007e4af17d4994  add rsp, 0xF0
00007e4af17d499b  pop r11
00007e4af17d499d  pop r10
00007e4af17d499f  pop r9
00007e4af17d49a1  pop r8
00007e4af17d49a3  pop rsi
00007e4af17d49a4  pop rdi
00007e4af17d49a5  pop rdx
00007e4af17d49a6  pop rcx
00007e4af17d49a7  pop rax
00007e4af17d49a8  add rsp, 0x08
00007e4af17d49ac  jmp 0x00007E4AF17D0183
00007e4af17d49b1  call 0x00007E4AF15FF430
00007e4af17d49b6  jmp 0x00007E4AF17D018D
00007e4af17d49bb  sub rsp, 0x08
00007e4af17d49bf  push rax
00007e4af17d49c0  push rcx
00007e4af17d49c1  push rdx
00007e4af17d49c2  push rdi
00007e4af17d49c3  push rsi
00007e4af17d49c4  push r8
00007e4af17d49c6  push r9
00007e4af17d49c8  push r10
00007e4af17d49ca  push r11
00007e4af17d49cc  sub rsp, 0xF0
00007e4af17d49d3  vmovaps [rsp], xmm0
00007e4af17d49d8  vmovaps [rsp+0x10], xmm1
00007e4af17d49de  vmovaps [rsp+0x20], xmm2
00007e4af17d49e4  vmovaps [rsp+0x30], xmm3
00007e4af17d49ea  vmovaps [rsp+0x40], xmm4
00007e4af17d49f0  vmovaps [rsp+0x50], xmm5
00007e4af17d49f6  vmovaps [rsp+0x60], xmm6
00007e4af17d49fc  vmovaps [rsp+0x70], xmm7
00007e4af17d4a02  vmovaps [rsp+0x80], xmm9
00007e4af17d4a0b  vmovaps [rsp+0x90], xmm10
00007e4af17d4a14  vmovaps [rsp+0xA0], xmm11
00007e4af17d4a1d  vmovaps [rsp+0xB0], xmm12
00007e4af17d4a26  vmovaps [rsp+0xC0], xmm13
00007e4af17d4a2f  vmovaps [rsp+0xD0], xmm14
00007e4af17d4a38  vmovaps [rsp+0xE0], xmm15
00007e4af17d4a41  sub rsp, 0x30
00007e4af17d4a45  movaps [rsp], xmm8
00007e4af17d4a4a  movaps [rsp+0x10], xmm14
00007e4af17d4a50  movaps [rsp+0x20], xmm9
00007e4af17d4a56  lea rdi, [rsp]
00007e4af17d4a5a  mov esi, 0x00
00007e4af17d4a5f  mov rax, 0x6256754A7530
00007e4af17d4a69  call rax
00007e4af17d4a6b  movaps xmm8, [rsp]
00007e4af17d4a70  add rsp, 0x30
00007e4af17d4a74  vmovaps xmm0, [rsp]
00007e4af17d4a79  vmovaps xmm1, [rsp+0x10]
00007e4af17d4a7f  vmovaps xmm2, [rsp+0x20]
00007e4af17d4a85  vmovaps xmm3, [rsp+0x30]
00007e4af17d4a8b  vmovaps xmm4, [rsp+0x40]
00007e4af17d4a91  vmovaps xmm5, [rsp+0x50]
00007e4af17d4a97  vmovaps xmm6, [rsp+0x60]
00007e4af17d4a9d  vmovaps xmm7, [rsp+0x70]
00007e4af17d4aa3  vmovaps xmm9, [rsp+0x80]
00007e4af17d4aac  vmovaps xmm10, [rsp+0x90]
00007e4af17d4ab5  vmovaps xmm11, [rsp+0xA0]
00007e4af17d4abe  vmovaps xmm12, [rsp+0xB0]
00007e4af17d4ac7  vmovaps xmm13, [rsp+0xC0]
00007e4af17d4ad0  vmovaps xmm14, [rsp+0xD0]
00007e4af17d4ad9  vmovaps xmm15, [rsp+0xE0]
00007e4af17d4ae2  add rsp, 0xF0
00007e4af17d4ae9  pop r11
00007e4af17d4aeb  pop r10
00007e4af17d4aed  pop r9
00007e4af17d4aef  pop r8
00007e4af17d4af1  pop rsi
00007e4af17d4af2  pop rdi
00007e4af17d4af3  pop rdx
00007e4af17d4af4  pop rcx
00007e4af17d4af5  pop rax
00007e4af17d4af6  add rsp, 0x08
00007e4af17d4afa  jmp 0x00007E4AF17D01AF
00007e4af17d4aff  sub rsp, 0x08
00007e4af17d4b03  push rax
00007e4af17d4b04  push rcx
00007e4af17d4b05  push rdx
00007e4af17d4b06  push rdi
00007e4af17d4b07  push rsi
00007e4af17d4b08  push r8
00007e4af17d4b0a  push r9
00007e4af17d4b0c  push r10
00007e4af17d4b0e  push r11
00007e4af17d4b10  sub rsp, 0xF0
00007e4af17d4b17  vmovaps [rsp], xmm0
00007e4af17d4b1c  vmovaps [rsp+0x10], xmm1
00007e4af17d4b22  vmovaps [rsp+0x20], xmm2
00007e4af17d4b28  vmovaps [rsp+0x30], xmm3
00007e4af17d4b2e  vmovaps [rsp+0x40], xmm4
00007e4af17d4b34  vmovaps [rsp+0x50], xmm5
00007e4af17d4b3a  vmovaps [rsp+0x60], xmm6
00007e4af17d4b40  vmovaps [rsp+0x70], xmm7
00007e4af17d4b46  vmovaps [rsp+0x80], xmm8
00007e4af17d4b4f  vmovaps [rsp+0x90], xmm10
00007e4af17d4b58  vmovaps [rsp+0xA0], xmm11
00007e4af17d4b61  vmovaps [rsp+0xB0], xmm12
00007e4af17d4b6a  vmovaps [rsp+0xC0], xmm13
00007e4af17d4b73  vmovaps [rsp+0xD0], xmm14
00007e4af17d4b7c  vmovaps [rsp+0xE0], xmm15
00007e4af17d4b85  sub rsp, 0x30
00007e4af17d4b89  movaps [rsp], xmm9
00007e4af17d4b8e  movaps [rsp+0x10], xmm1
00007e4af17d4b93  movaps [rsp+0x20], xmm14
00007e4af17d4b99  lea rdi, [rsp]
00007e4af17d4b9d  mov esi, 0x00
00007e4af17d4ba2  mov rax, 0x6256754A7530
00007e4af17d4bac  call rax
00007e4af17d4bae  movaps xmm9, [rsp]
00007e4af17d4bb3  add rsp, 0x30
00007e4af17d4bb7  vmovaps xmm0, [rsp]
00007e4af17d4bbc  vmovaps xmm1, [rsp+0x10]
00007e4af17d4bc2  vmovaps xmm2, [rsp+0x20]
00007e4af17d4bc8  vmovaps xmm3, [rsp+0x30]
00007e4af17d4bce  vmovaps xmm4, [rsp+0x40]
00007e4af17d4bd4  vmovaps xmm5, [rsp+0x50]
00007e4af17d4bda  vmovaps xmm6, [rsp+0x60]
00007e4af17d4be0  vmovaps xmm7, [rsp+0x70]
00007e4af17d4be6  vmovaps xmm8, [rsp+0x80]
00007e4af17d4bef  vmovaps xmm10, [rsp+0x90]
00007e4af17d4bf8  vmovaps xmm11, [rsp+0xA0]
00007e4af17d4c01  vmovaps xmm12, [rsp+0xB0]
00007e4af17d4c0a  vmovaps xmm13, [rsp+0xC0]
00007e4af17d4c13  vmovaps xmm14, [rsp+0xD0]
00007e4af17d4c1c  vmovaps xmm15, [rsp+0xE0]
00007e4af17d4c25  add rsp, 0xF0
00007e4af17d4c2c  pop r11
00007e4af17d4c2e  pop r10
00007e4af17d4c30  pop r9
00007e4af17d4c32  pop r8
00007e4af17d4c34  pop rsi
00007e4af17d4c35  pop rdi
00007e4af17d4c36  pop rdx
00007e4af17d4c37  pop rcx
00007e4af17d4c38  pop rax
00007e4af17d4c39  add rsp, 0x08
00007e4af17d4c3d  jmp 0x00007E4AF17D01DD
00007e4af17d4c42  sub rsp, 0x08
00007e4af17d4c46  push rax
00007e4af17d4c47  push rcx
00007e4af17d4c48  push rdx
00007e4af17d4c49  push rdi
00007e4af17d4c4a  push rsi
00007e4af17d4c4b  push r8
00007e4af17d4c4d  push r9
00007e4af17d4c4f  push r10
00007e4af17d4c51  push r11
00007e4af17d4c53  sub rsp, 0xF0
00007e4af17d4c5a  vmovaps [rsp], xmm0
00007e4af17d4c5f  vmovaps [rsp+0x10], xmm1
00007e4af17d4c65  vmovaps [rsp+0x20], xmm2
00007e4af17d4c6b  vmovaps [rsp+0x30], xmm3
00007e4af17d4c71  vmovaps [rsp+0x40], xmm4
00007e4af17d4c77  vmovaps [rsp+0x50], xmm5
00007e4af17d4c7d  vmovaps [rsp+0x60], xmm6
00007e4af17d4c83  vmovaps [rsp+0x70], xmm7
00007e4af17d4c89  vmovaps [rsp+0x80], xmm8
00007e4af17d4c92  vmovaps [rsp+0x90], xmm9
00007e4af17d4c9b  vmovaps [rsp+0xA0], xmm10
00007e4af17d4ca4  vmovaps [rsp+0xB0], xmm11
00007e4af17d4cad  vmovaps [rsp+0xC0], xmm12
00007e4af17d4cb6  vmovaps [rsp+0xD0], xmm13
00007e4af17d4cbf  vmovaps [rsp+0xE0], xmm15
00007e4af17d4cc8  sub rsp, 0x30
00007e4af17d4ccc  movaps [rsp], xmm14
00007e4af17d4cd1  movaps [rsp+0x10], xmm4
00007e4af17d4cd6  movaps [rsp+0x20], xmm1
00007e4af17d4cdb  lea rdi, [rsp]
00007e4af17d4cdf  mov esi, 0x00
00007e4af17d4ce4  mov rax, 0x6256754A7530
00007e4af17d4cee  call rax
00007e4af17d4cf0  movaps xmm14, [rsp]
00007e4af17d4cf5  add rsp, 0x30
00007e4af17d4cf9  vmovaps xmm0, [rsp]
00007e4af17d4cfe  vmovaps xmm1, [rsp+0x10]
00007e4af17d4d04  vmovaps xmm2, [rsp+0x20]
00007e4af17d4d0a  vmovaps xmm3, [rsp+0x30]
00007e4af17d4d10  vmovaps xmm4, [rsp+0x40]
00007e4af17d4d16  vmovaps xmm5, [rsp+0x50]
00007e4af17d4d1c  vmovaps xmm6, [rsp+0x60]
00007e4af17d4d22  vmovaps xmm7, [rsp+0x70]
00007e4af17d4d28  vmovaps xmm8, [rsp+0x80]
00007e4af17d4d31  vmovaps xmm9, [rsp+0x90]
00007e4af17d4d3a  vmovaps xmm10, [rsp+0xA0]
00007e4af17d4d43  vmovaps xmm11, [rsp+0xB0]
00007e4af17d4d4c  vmovaps xmm12, [rsp+0xC0]
00007e4af17d4d55  vmovaps xmm13, [rsp+0xD0]
00007e4af17d4d5e  vmovaps xmm15, [rsp+0xE0]
00007e4af17d4d67  add rsp, 0xF0
00007e4af17d4d6e  pop r11
00007e4af17d4d70  pop r10
00007e4af17d4d72  pop r9
00007e4af17d4d74  pop r8
00007e4af17d4d76  pop rsi
00007e4af17d4d77  pop rdi
00007e4af17d4d78  pop rdx
00007e4af17d4d79  pop rcx
00007e4af17d4d7a  pop rax
00007e4af17d4d7b  add rsp, 0x08
00007e4af17d4d7f  jmp 0x00007E4AF17D0203
00007e4af17d4d84  sub rsp, 0x08
00007e4af17d4d88  push rax
00007e4af17d4d89  push rcx
00007e4af17d4d8a  push rdx
00007e4af17d4d8b  push rdi
00007e4af17d4d8c  push rsi
00007e4af17d4d8d  push r8
00007e4af17d4d8f  push r9
00007e4af17d4d91  push r10
00007e4af17d4d93  push r11
00007e4af17d4d95  sub rsp, 0xF0
00007e4af17d4d9c  vmovaps [rsp], xmm0
00007e4af17d4da1  vmovaps [rsp+0x10], xmm2
00007e4af17d4da7  vmovaps [rsp+0x20], xmm3
00007e4af17d4dad  vmovaps [rsp+0x30], xmm4
00007e4af17d4db3  vmovaps [rsp+0x40], xmm5
00007e4af17d4db9  vmovaps [rsp+0x50], xmm6
00007e4af17d4dbf  vmovaps [rsp+0x60], xmm7
00007e4af17d4dc5  vmovaps [rsp+0x70], xmm8
00007e4af17d4dcb  vmovaps [rsp+0x80], xmm9
00007e4af17d4dd4  vmovaps [rsp+0x90], xmm10
00007e4af17d4ddd  vmovaps [rsp+0xA0], xmm11
00007e4af17d4de6  vmovaps [rsp+0xB0], xmm12
00007e4af17d4def  vmovaps [rsp+0xC0], xmm13
00007e4af17d4df8  vmovaps [rsp+0xD0], xmm14
00007e4af17d4e01  vmovaps [rsp+0xE0], xmm15
00007e4af17d4e0a  sub rsp, 0x30
00007e4af17d4e0e  movaps [rsp], xmm1
00007e4af17d4e12  movaps [rsp+0x10], xmm12
00007e4af17d4e18  movaps [rsp+0x20], xmm11
00007e4af17d4e1e  lea rdi, [rsp]
00007e4af17d4e22  mov esi, 0x00
00007e4af17d4e27  mov rax, 0x6256754A7530
00007e4af17d4e31  call rax
00007e4af17d4e33  movaps xmm1, [rsp]
00007e4af17d4e37  add rsp, 0x30
00007e4af17d4e3b  vmovaps xmm0, [rsp]
00007e4af17d4e40  vmovaps xmm2, [rsp+0x10]
00007e4af17d4e46  vmovaps xmm3, [rsp+0x20]
00007e4af17d4e4c  vmovaps xmm4, [rsp+0x30]
00007e4af17d4e52  vmovaps xmm5, [rsp+0x40]
00007e4af17d4e58  vmovaps xmm6, [rsp+0x50]
00007e4af17d4e5e  vmovaps xmm7, [rsp+0x60]
00007e4af17d4e64  vmovaps xmm8, [rsp+0x70]
00007e4af17d4e6a  vmovaps xmm9, [rsp+0x80]
00007e4af17d4e73  vmovaps xmm10, [rsp+0x90]
00007e4af17d4e7c  vmovaps xmm11, [rsp+0xA0]
00007e4af17d4e85  vmovaps xmm12, [rsp+0xB0]
00007e4af17d4e8e  vmovaps xmm13, [rsp+0xC0]
00007e4af17d4e97  vmovaps xmm14, [rsp+0xD0]
00007e4af17d4ea0  vmovaps xmm15, [rsp+0xE0]
00007e4af17d4ea9  add rsp, 0xF0
00007e4af17d4eb0  pop r11
00007e4af17d4eb2  pop r10
00007e4af17d4eb4  pop r9
00007e4af17d4eb6  pop r8
00007e4af17d4eb8  pop rsi
00007e4af17d4eb9  pop rdi
00007e4af17d4eba  pop rdx
00007e4af17d4ebb  pop rcx
00007e4af17d4ebc  pop rax
00007e4af17d4ebd  add rsp, 0x08
00007e4af17d4ec1  jmp 0x00007E4AF17D0224
00007e4af17d4ec6  call 0x00007E4AF16E20A0
00007e4af17d4ecb  jmp 0x00007E4AF17D0232
00007e4af17d4ed0  call 0x00007E4AF1609D70
00007e4af17d4ed5  jmp 0x00007E4AF17D023C
00007e4af17d4eda  sub rsp, 0x08
00007e4af17d4ede  push rax
00007e4af17d4edf  push rcx
00007e4af17d4ee0  push rdx
00007e4af17d4ee1  push rdi
00007e4af17d4ee2  push rsi
00007e4af17d4ee3  push r8
00007e4af17d4ee5  push r9
00007e4af17d4ee7  push r10
00007e4af17d4ee9  push r11
00007e4af17d4eeb  sub rsp, 0xF0
00007e4af17d4ef2  vmovaps [rsp], xmm0
00007e4af17d4ef7  vmovaps [rsp+0x10], xmm1
00007e4af17d4efd  vmovaps [rsp+0x20], xmm2
00007e4af17d4f03  vmovaps [rsp+0x30], xmm3
00007e4af17d4f09  vmovaps [rsp+0x40], xmm4
00007e4af17d4f0f  vmovaps [rsp+0x50], xmm5
00007e4af17d4f15  vmovaps [rsp+0x60], xmm6
00007e4af17d4f1b  vmovaps [rsp+0x70], xmm8
00007e4af17d4f21  vmovaps [rsp+0x80], xmm9
00007e4af17d4f2a  vmovaps [rsp+0x90], xmm10
00007e4af17d4f33  vmovaps [rsp+0xA0], xmm11
00007e4af17d4f3c  vmovaps [rsp+0xB0], xmm12
00007e4af17d4f45  vmovaps [rsp+0xC0], xmm13
00007e4af17d4f4e  vmovaps [rsp+0xD0], xmm14
00007e4af17d4f57  vmovaps [rsp+0xE0], xmm15
00007e4af17d4f60  sub rsp, 0x30
00007e4af17d4f64  movaps [rsp], xmm7
00007e4af17d4f68  movaps [rsp+0x10], xmm15
00007e4af17d4f6e  movaps [rsp+0x20], xmm10
00007e4af17d4f74  lea rdi, [rsp]
00007e4af17d4f78  mov esi, 0x00
00007e4af17d4f7d  mov rax, 0x6256754A7530
00007e4af17d4f87  call rax
00007e4af17d4f89  movaps xmm7, [rsp]
00007e4af17d4f8d  add rsp, 0x30
00007e4af17d4f91  vmovaps xmm0, [rsp]
00007e4af17d4f96  vmovaps xmm1, [rsp+0x10]
00007e4af17d4f9c  vmovaps xmm2, [rsp+0x20]
00007e4af17d4fa2  vmovaps xmm3, [rsp+0x30]
00007e4af17d4fa8  vmovaps xmm4, [rsp+0x40]
00007e4af17d4fae  vmovaps xmm5, [rsp+0x50]
00007e4af17d4fb4  vmovaps xmm6, [rsp+0x60]
00007e4af17d4fba  vmovaps xmm8, [rsp+0x70]
00007e4af17d4fc0  vmovaps xmm9, [rsp+0x80]
00007e4af17d4fc9  vmovaps xmm10, [rsp+0x90]
00007e4af17d4fd2  vmovaps xmm11, [rsp+0xA0]
00007e4af17d4fdb  vmovaps xmm12, [rsp+0xB0]
00007e4af17d4fe4  vmovaps xmm13, [rsp+0xC0]
00007e4af17d4fed  vmovaps xmm14, [rsp+0xD0]
00007e4af17d4ff6  vmovaps xmm15, [rsp+0xE0]
00007e4af17d4fff  add rsp, 0xF0
00007e4af17d5006  pop r11
00007e4af17d5008  pop r10
00007e4af17d500a  pop r9
00007e4af17d500c  pop r8
00007e4af17d500e  pop rsi
00007e4af17d500f  pop rdi
00007e4af17d5010  pop rdx
00007e4af17d5011  pop rcx
00007e4af17d5012  pop rax
00007e4af17d5013  add rsp, 0x08
00007e4af17d5017  jmp 0x00007E4AF17D025D
00007e4af17d501c  sub rsp, 0x08
00007e4af17d5020  push rax
00007e4af17d5021  push rcx
00007e4af17d5022  push rdx
00007e4af17d5023  push rdi
00007e4af17d5024  push rsi
00007e4af17d5025  push r8
00007e4af17d5027  push r9
00007e4af17d5029  push r10
00007e4af17d502b  push r11
00007e4af17d502d  sub rsp, 0xF0
00007e4af17d5034  vmovaps [rsp], xmm0
00007e4af17d5039  vmovaps [rsp+0x10], xmm1
00007e4af17d503f  vmovaps [rsp+0x20], xmm2
00007e4af17d5045  vmovaps [rsp+0x30], xmm3
00007e4af17d504b  vmovaps [rsp+0x40], xmm4
00007e4af17d5051  vmovaps [rsp+0x50], xmm5
00007e4af17d5057  vmovaps [rsp+0x60], xmm6
00007e4af17d505d  vmovaps [rsp+0x70], xmm7
00007e4af17d5063  vmovaps [rsp+0x80], xmm8
00007e4af17d506c  vmovaps [rsp+0x90], xmm9
00007e4af17d5075  vmovaps [rsp+0xA0], xmm11
00007e4af17d507e  vmovaps [rsp+0xB0], xmm12
00007e4af17d5087  vmovaps [rsp+0xC0], xmm13
00007e4af17d5090  vmovaps [rsp+0xD0], xmm14
00007e4af17d5099  vmovaps [rsp+0xE0], xmm15
00007e4af17d50a2  sub rsp, 0x30
00007e4af17d50a6  movaps [rsp], xmm10
00007e4af17d50ab  movaps [rsp+0x10], xmm11
00007e4af17d50b1  movaps [rsp+0x20], xmm15
00007e4af17d50b7  lea rdi, [rsp]
00007e4af17d50bb  mov esi, 0x00
00007e4af17d50c0  mov rax, 0x6256754A7530
00007e4af17d50ca  call rax
00007e4af17d50cc  movaps xmm10, [rsp]
00007e4af17d50d1  add rsp, 0x30
00007e4af17d50d5  vmovaps xmm0, [rsp]
00007e4af17d50da  vmovaps xmm1, [rsp+0x10]
00007e4af17d50e0  vmovaps xmm2, [rsp+0x20]
00007e4af17d50e6  vmovaps xmm3, [rsp+0x30]
00007e4af17d50ec  vmovaps xmm4, [rsp+0x40]
00007e4af17d50f2  vmovaps xmm5, [rsp+0x50]
00007e4af17d50f8  vmovaps xmm6, [rsp+0x60]
00007e4af17d50fe  vmovaps xmm7, [rsp+0x70]
00007e4af17d5104  vmovaps xmm8, [rsp+0x80]
00007e4af17d510d  vmovaps xmm9, [rsp+0x90]
00007e4af17d5116  vmovaps xmm11, [rsp+0xA0]
00007e4af17d511f  vmovaps xmm12, [rsp+0xB0]
00007e4af17d5128  vmovaps xmm13, [rsp+0xC0]
00007e4af17d5131  vmovaps xmm14, [rsp+0xD0]
00007e4af17d513a  vmovaps xmm15, [rsp+0xE0]
00007e4af17d5143  add rsp, 0xF0
00007e4af17d514a  pop r11
00007e4af17d514c  pop r10
00007e4af17d514e  pop r9
00007e4af17d5150  pop r8
00007e4af17d5152  pop rsi
00007e4af17d5153  pop rdi
00007e4af17d5154  pop rdx
00007e4af17d5155  pop rcx
00007e4af17d5156  pop rax
00007e4af17d5157  add rsp, 0x08
00007e4af17d515b  jmp 0x00007E4AF17D028B
00007e4af17d5160  sub rsp, 0x08
00007e4af17d5164  push rax
00007e4af17d5165  push rcx
00007e4af17d5166  push rdx
00007e4af17d5167  push rdi
00007e4af17d5168  push rsi
00007e4af17d5169  push r8
00007e4af17d516b  push r9
00007e4af17d516d  push r10
00007e4af17d516f  push r11
00007e4af17d5171  sub rsp, 0xF0
00007e4af17d5178  vmovaps [rsp], xmm0
00007e4af17d517d  vmovaps [rsp+0x10], xmm1
00007e4af17d5183  vmovaps [rsp+0x20], xmm2
00007e4af17d5189  vmovaps [rsp+0x30], xmm3
00007e4af17d518f  vmovaps [rsp+0x40], xmm4
00007e4af17d5195  vmovaps [rsp+0x50], xmm5
00007e4af17d519b  vmovaps [rsp+0x60], xmm6
00007e4af17d51a1  vmovaps [rsp+0x70], xmm7
00007e4af17d51a7  vmovaps [rsp+0x80], xmm8
00007e4af17d51b0  vmovaps [rsp+0x90], xmm9
00007e4af17d51b9  vmovaps [rsp+0xA0], xmm10
00007e4af17d51c2  vmovaps [rsp+0xB0], xmm12
00007e4af17d51cb  vmovaps [rsp+0xC0], xmm13
00007e4af17d51d4  vmovaps [rsp+0xD0], xmm14
00007e4af17d51dd  vmovaps [rsp+0xE0], xmm15
00007e4af17d51e6  sub rsp, 0x30
00007e4af17d51ea  movaps [rsp], xmm11
00007e4af17d51ef  movaps [rsp+0x10], xmm12
00007e4af17d51f5  movaps [rsp+0x20], xmm15
00007e4af17d51fb  lea rdi, [rsp]
00007e4af17d51ff  mov esi, 0x00
00007e4af17d5204  mov rax, 0x6256754A7530
00007e4af17d520e  call rax
00007e4af17d5210  movaps xmm11, [rsp]
00007e4af17d5215  add rsp, 0x30
00007e4af17d5219  vmovaps xmm0, [rsp]
00007e4af17d521e  vmovaps xmm1, [rsp+0x10]
00007e4af17d5224  vmovaps xmm2, [rsp+0x20]
00007e4af17d522a  vmovaps xmm3, [rsp+0x30]
00007e4af17d5230  vmovaps xmm4, [rsp+0x40]
00007e4af17d5236  vmovaps xmm5, [rsp+0x50]
00007e4af17d523c  vmovaps xmm6, [rsp+0x60]
00007e4af17d5242  vmovaps xmm7, [rsp+0x70]
00007e4af17d5248  vmovaps xmm8, [rsp+0x80]
00007e4af17d5251  vmovaps xmm9, [rsp+0x90]
00007e4af17d525a  vmovaps xmm10, [rsp+0xA0]
00007e4af17d5263  vmovaps xmm12, [rsp+0xB0]
00007e4af17d526c  vmovaps xmm13, [rsp+0xC0]
00007e4af17d5275  vmovaps xmm14, [rsp+0xD0]
00007e4af17d527e  vmovaps xmm15, [rsp+0xE0]
00007e4af17d5287  add rsp, 0xF0
00007e4af17d528e  pop r11
00007e4af17d5290  pop r10
00007e4af17d5292  pop r9
00007e4af17d5294  pop r8
00007e4af17d5296  pop rsi
00007e4af17d5297  pop rdi
00007e4af17d5298  pop rdx
00007e4af17d5299  pop rcx
00007e4af17d529a  pop rax
00007e4af17d529b  add rsp, 0x08
00007e4af17d529f  jmp 0x00007E4AF17D02B9
00007e4af17d52a4  sub rsp, 0x08
00007e4af17d52a8  push rax
00007e4af17d52a9  push rcx
00007e4af17d52aa  push rdx
00007e4af17d52ab  push rdi
00007e4af17d52ac  push rsi
00007e4af17d52ad  push r8
00007e4af17d52af  push r9
00007e4af17d52b1  push r10
00007e4af17d52b3  push r11
00007e4af17d52b5  sub rsp, 0xF0
00007e4af17d52bc  vmovaps [rsp], xmm0
00007e4af17d52c1  vmovaps [rsp+0x10], xmm1
00007e4af17d52c7  vmovaps [rsp+0x20], xmm2
00007e4af17d52cd  vmovaps [rsp+0x30], xmm3
00007e4af17d52d3  vmovaps [rsp+0x40], xmm4
00007e4af17d52d9  vmovaps [rsp+0x50], xmm5
00007e4af17d52df  vmovaps [rsp+0x60], xmm6
00007e4af17d52e5  vmovaps [rsp+0x70], xmm7
00007e4af17d52eb  vmovaps [rsp+0x80], xmm8
00007e4af17d52f4  vmovaps [rsp+0x90], xmm9
00007e4af17d52fd  vmovaps [rsp+0xA0], xmm10
00007e4af17d5306  vmovaps [rsp+0xB0], xmm11
00007e4af17d530f  vmovaps [rsp+0xC0], xmm12
00007e4af17d5318  vmovaps [rsp+0xD0], xmm13
00007e4af17d5321  vmovaps [rsp+0xE0], xmm14
00007e4af17d532a  sub rsp, 0x30
00007e4af17d532e  movaps [rsp], xmm15
00007e4af17d5333  movaps [rsp+0x10], xmm13
00007e4af17d5339  movaps [rsp+0x20], xmm9
00007e4af17d533f  lea rdi, [rsp]
00007e4af17d5343  mov esi, 0x00
00007e4af17d5348  mov rax, 0x6256754A7530
00007e4af17d5352  call rax
00007e4af17d5354  movaps xmm15, [rsp]
00007e4af17d5359  add rsp, 0x30
00007e4af17d535d  vmovaps xmm0, [rsp]
00007e4af17d5362  vmovaps xmm1, [rsp+0x10]
00007e4af17d5368  vmovaps xmm2, [rsp+0x20]
00007e4af17d536e  vmovaps xmm3, [rsp+0x30]
00007e4af17d5374  vmovaps xmm4, [rsp+0x40]
00007e4af17d537a  vmovaps xmm5, [rsp+0x50]
00007e4af17d5380  vmovaps xmm6, [rsp+0x60]
00007e4af17d5386  vmovaps xmm7, [rsp+0x70]
00007e4af17d538c  vmovaps xmm8, [rsp+0x80]
00007e4af17d5395  vmovaps xmm9, [rsp+0x90]
00007e4af17d539e  vmovaps xmm10, [rsp+0xA0]
00007e4af17d53a7  vmovaps xmm11, [rsp+0xB0]
00007e4af17d53b0  vmovaps xmm12, [rsp+0xC0]
00007e4af17d53b9  vmovaps xmm13, [rsp+0xD0]
00007e4af17d53c2  vmovaps xmm14, [rsp+0xE0]
00007e4af17d53cb  add rsp, 0xF0
00007e4af17d53d2  pop r11
00007e4af17d53d4  pop r10
00007e4af17d53d6  pop r9
00007e4af17d53d8  pop r8
00007e4af17d53da  pop rsi
00007e4af17d53db  pop rdi
00007e4af17d53dc  pop rdx
00007e4af17d53dd  pop rcx
00007e4af17d53de  pop rax
00007e4af17d53df  add rsp, 0x08
00007e4af17d53e3  jmp 0x00007E4AF17D02D4
00007e4af17d53e8  sub rsp, 0x08
00007e4af17d53ec  push rax
00007e4af17d53ed  push rcx
00007e4af17d53ee  push rdx
00007e4af17d53ef  push rdi
00007e4af17d53f0  push rsi
00007e4af17d53f1  push r8
00007e4af17d53f3  push r9
00007e4af17d53f5  push r10
00007e4af17d53f7  push r11
00007e4af17d53f9  sub rsp, 0xF0
00007e4af17d5400  vmovaps [rsp], xmm0
00007e4af17d5405  vmovaps [rsp+0x10], xmm1
00007e4af17d540b  vmovaps [rsp+0x20], xmm2
00007e4af17d5411  vmovaps [rsp+0x30], xmm3
00007e4af17d5417  vmovaps [rsp+0x40], xmm4
00007e4af17d541d  vmovaps [rsp+0x50], xmm5
00007e4af17d5423  vmovaps [rsp+0x60], xmm6
00007e4af17d5429  vmovaps [rsp+0x70], xmm7
00007e4af17d542f  vmovaps [rsp+0x80], xmm8
00007e4af17d5438  vmovaps [rsp+0x90], xmm9
00007e4af17d5441  vmovaps [rsp+0xA0], xmm10
00007e4af17d544a  vmovaps [rsp+0xB0], xmm11
00007e4af17d5453  vmovaps [rsp+0xC0], xmm12
00007e4af17d545c  vmovaps [rsp+0xD0], xmm14
00007e4af17d5465  vmovaps [rsp+0xE0], xmm15
00007e4af17d546e  sub rsp, 0x30
00007e4af17d5472  movaps [rsp], xmm13
00007e4af17d5477  movaps [rsp+0x10], xmm8
00007e4af17d547d  movaps [rsp+0x20], xmm14
00007e4af17d5483  lea rdi, [rsp]
00007e4af17d5487  mov esi, 0x00
00007e4af17d548c  mov rax, 0x6256754A7530
00007e4af17d5496  call rax
00007e4af17d5498  movaps xmm13, [rsp]
00007e4af17d549d  add rsp, 0x30
00007e4af17d54a1  vmovaps xmm0, [rsp]
00007e4af17d54a6  vmovaps xmm1, [rsp+0x10]
00007e4af17d54ac  vmovaps xmm2, [rsp+0x20]
00007e4af17d54b2  vmovaps xmm3, [rsp+0x30]
00007e4af17d54b8  vmovaps xmm4, [rsp+0x40]
00007e4af17d54be  vmovaps xmm5, [rsp+0x50]
00007e4af17d54c4  vmovaps xmm6, [rsp+0x60]
00007e4af17d54ca  vmovaps xmm7, [rsp+0x70]
00007e4af17d54d0  vmovaps xmm8, [rsp+0x80]
00007e4af17d54d9  vmovaps xmm9, [rsp+0x90]
00007e4af17d54e2  vmovaps xmm10, [rsp+0xA0]
00007e4af17d54eb  vmovaps xmm11, [rsp+0xB0]
00007e4af17d54f4  vmovaps xmm12, [rsp+0xC0]
00007e4af17d54fd  vmovaps xmm14, [rsp+0xD0]
00007e4af17d5506  vmovaps xmm15, [rsp+0xE0]
00007e4af17d550f  add rsp, 0xF0
00007e4af17d5516  pop r11
00007e4af17d5518  pop r10
00007e4af17d551a  pop r9
00007e4af17d551c  pop r8
00007e4af17d551e  pop rsi
00007e4af17d551f  pop rdi
00007e4af17d5520  pop rdx
00007e4af17d5521  pop rcx
00007e4af17d5522  pop rax
00007e4af17d5523  add rsp, 0x08
00007e4af17d5527  jmp 0x00007E4AF17D02F7
00007e4af17d552c  sub rsp, 0x08
00007e4af17d5530  push rax
00007e4af17d5531  push rcx
00007e4af17d5532  push rdx
00007e4af17d5533  push rdi
00007e4af17d5534  push rsi
00007e4af17d5535  push r8
00007e4af17d5537  push r9
00007e4af17d5539  push r10
00007e4af17d553b  push r11
00007e4af17d553d  sub rsp, 0xF0
00007e4af17d5544  vmovaps [rsp], xmm0
00007e4af17d5549  vmovaps [rsp+0x10], xmm1
00007e4af17d554f  vmovaps [rsp+0x20], xmm2
00007e4af17d5555  vmovaps [rsp+0x30], xmm3
00007e4af17d555b  vmovaps [rsp+0x40], xmm4
00007e4af17d5561  vmovaps [rsp+0x50], xmm5
00007e4af17d5567  vmovaps [rsp+0x60], xmm6
00007e4af17d556d  vmovaps [rsp+0x70], xmm7
00007e4af17d5573  vmovaps [rsp+0x80], xmm8
00007e4af17d557c  vmovaps [rsp+0x90], xmm9
00007e4af17d5585  vmovaps [rsp+0xA0], xmm10
00007e4af17d558e  vmovaps [rsp+0xB0], xmm11
00007e4af17d5597  vmovaps [rsp+0xC0], xmm12
00007e4af17d55a0  vmovaps [rsp+0xD0], xmm13
00007e4af17d55a9  vmovaps [rsp+0xE0], xmm15
00007e4af17d55b2  sub rsp, 0x30
00007e4af17d55b6  movaps [rsp], xmm14
00007e4af17d55bb  movaps [rsp+0x10], xmm1
00007e4af17d55c0  movaps [rsp+0x20], xmm10
00007e4af17d55c6  lea rdi, [rsp]
00007e4af17d55ca  mov esi, 0x00
00007e4af17d55cf  mov rax, 0x6256754A7530
00007e4af17d55d9  call rax
00007e4af17d55db  movaps xmm14, [rsp]
00007e4af17d55e0  add rsp, 0x30
00007e4af17d55e4  vmovaps xmm0, [rsp]
00007e4af17d55e9  vmovaps xmm1, [rsp+0x10]
00007e4af17d55ef  vmovaps xmm2, [rsp+0x20]
00007e4af17d55f5  vmovaps xmm3, [rsp+0x30]
00007e4af17d55fb  vmovaps xmm4, [rsp+0x40]
00007e4af17d5601  vmovaps xmm5, [rsp+0x50]
00007e4af17d5607  vmovaps xmm6, [rsp+0x60]
00007e4af17d560d  vmovaps xmm7, [rsp+0x70]
00007e4af17d5613  vmovaps xmm8, [rsp+0x80]
00007e4af17d561c  vmovaps xmm9, [rsp+0x90]
00007e4af17d5625  vmovaps xmm10, [rsp+0xA0]
00007e4af17d562e  vmovaps xmm11, [rsp+0xB0]
00007e4af17d5637  vmovaps xmm12, [rsp+0xC0]
00007e4af17d5640  vmovaps xmm13, [rsp+0xD0]
00007e4af17d5649  vmovaps xmm15, [rsp+0xE0]
00007e4af17d5652  add rsp, 0xF0
00007e4af17d5659  pop r11
00007e4af17d565b  pop r10
00007e4af17d565d  pop r9
00007e4af17d565f  pop r8
00007e4af17d5661  pop rsi
00007e4af17d5662  pop rdi
00007e4af17d5663  pop rdx
00007e4af17d5664  pop rcx
00007e4af17d5665  pop rax
00007e4af17d5666  add rsp, 0x08
00007e4af17d566a  jmp 0x00007E4AF17D031A
00007e4af17d566f  sub rsp, 0x08
00007e4af17d5673  push rax
00007e4af17d5674  push rcx
00007e4af17d5675  push rdx
00007e4af17d5676  push rdi
00007e4af17d5677  push rsi
00007e4af17d5678  push r8
00007e4af17d567a  push r9
00007e4af17d567c  push r10
00007e4af17d567e  push r11
00007e4af17d5680  sub rsp, 0xF0
00007e4af17d5687  vmovaps [rsp], xmm0
00007e4af17d568c  vmovaps [rsp+0x10], xmm2
00007e4af17d5692  vmovaps [rsp+0x20], xmm3
00007e4af17d5698  vmovaps [rsp+0x30], xmm4
00007e4af17d569e  vmovaps [rsp+0x40], xmm5
00007e4af17d56a4  vmovaps [rsp+0x50], xmm6
00007e4af17d56aa  vmovaps [rsp+0x60], xmm7
00007e4af17d56b0  vmovaps [rsp+0x70], xmm8
00007e4af17d56b6  vmovaps [rsp+0x80], xmm9
00007e4af17d56bf  vmovaps [rsp+0x90], xmm10
00007e4af17d56c8  vmovaps [rsp+0xA0], xmm11
00007e4af17d56d1  vmovaps [rsp+0xB0], xmm12
00007e4af17d56da  vmovaps [rsp+0xC0], xmm13
00007e4af17d56e3  vmovaps [rsp+0xD0], xmm14
00007e4af17d56ec  vmovaps [rsp+0xE0], xmm15
00007e4af17d56f5  sub rsp, 0x30
00007e4af17d56f9  movaps [rsp], xmm1
00007e4af17d56fd  movaps [rsp+0x10], xmm7
00007e4af17d5702  movaps [rsp+0x20], xmm11
00007e4af17d5708  lea rdi, [rsp]
00007e4af17d570c  mov esi, 0x00
00007e4af17d5711  mov rax, 0x6256754A7530
00007e4af17d571b  call rax
00007e4af17d571d  movaps xmm1, [rsp]
00007e4af17d5721  add rsp, 0x30
00007e4af17d5725  vmovaps xmm0, [rsp]
00007e4af17d572a  vmovaps xmm2, [rsp+0x10]
00007e4af17d5730  vmovaps xmm3, [rsp+0x20]
00007e4af17d5736  vmovaps xmm4, [rsp+0x30]
00007e4af17d573c  vmovaps xmm5, [rsp+0x40]
00007e4af17d5742  vmovaps xmm6, [rsp+0x50]
00007e4af17d5748  vmovaps xmm7, [rsp+0x60]
00007e4af17d574e  vmovaps xmm8, [rsp+0x70]
00007e4af17d5754  vmovaps xmm9, [rsp+0x80]
00007e4af17d575d  vmovaps xmm10, [rsp+0x90]
00007e4af17d5766  vmovaps xmm11, [rsp+0xA0]
00007e4af17d576f  vmovaps xmm12, [rsp+0xB0]
00007e4af17d5778  vmovaps xmm13, [rsp+0xC0]
00007e4af17d5781  vmovaps xmm14, [rsp+0xD0]
00007e4af17d578a  vmovaps xmm15, [rsp+0xE0]
00007e4af17d5793  add rsp, 0xF0
00007e4af17d579a  pop r11
00007e4af17d579c  pop r10
00007e4af17d579e  pop r9
00007e4af17d57a0  pop r8
00007e4af17d57a2  pop rsi
00007e4af17d57a3  pop rdi
00007e4af17d57a4  pop rdx
00007e4af17d57a5  pop rcx
00007e4af17d57a6  pop rax
00007e4af17d57a7  add rsp, 0x08
00007e4af17d57ab  jmp 0x00007E4AF17D033B
00007e4af17d57b0  call 0x00007E4AF160E880
00007e4af17d57b5  jmp 0x00007E4AF17D034E
00007e4af17d57ba  call 0x00007E4AF160C380
00007e4af17d57bf  jmp 0x00007E4AF17D0359
00007e4af17d57c4  call 0x00007E4AF160D600
00007e4af17d57c9  jmp 0x00007E4AF17D0364
00007e4af17d57ce  call 0x00007E4AF15FF540
00007e4af17d57d3  jmp 0x00007E4AF17D036F
00007e4af17d57d8  int3
00007e4af17d57d9  nop [rax], eax
00007e4af17d57e0  mov rax, [r15+0x40]
00007e4af17d57e4  mov r14, [r15+0x58]
00007e4af17d57e8  lea r12, [rax+r14*1]
00007e4af17d57ec  movaps xmm1, [r15+0x1D0]
00007e4af17d57f4  vmovaps [rsp+0x10], xmm1
00007e4af17d57fa  vmovaps xmm15, [rsp+0x10]
00007e4af17d5800  por xmm1, xmm15
00007e4af17d5805  movaps xmm14, [r15+0x1A0]
00007e4af17d580d  vmovaps [rsp+0x10], xmm14
00007e4af17d5813  vmovaps xmm13, [rsp+0x10]
00007e4af17d5819  por xmm14, xmm13
00007e4af17d581e  lea rax, [r12+0x30]
00007e4af17d5823  mov r11, [r13+rax*1]
00007e4af17d5828  lea rax, [r12+0x38]
00007e4af17d582d  mov r10, [r13+rax*1]
00007e4af17d5832  movq xmm13, r11
00007e4af17d5837  movq xmm12, r10
00007e4af17d583c  movq xmm13, xmm13
00007e4af17d5841  vmovaps [rsp+0x10], xmm13
00007e4af17d5847  movq xmm13, xmm13
00007e4af17d584c  movaps [r15+0x130], xmm13
00007e4af17d5854  movq xmm12, xmm12
00007e4af17d5859  vmovaps [rsp+0x20], xmm12
00007e4af17d585f  movq xmm12, xmm12
00007e4af17d5864  movaps [r15+0x280], xmm12
00007e4af17d586c  movaps xmm13, [r15+0x270]
00007e4af17d5874  vmovaps [rsp+0x30], xmm13
00007e4af17d587a  vmovaps xmm12, [rsp+0x30]
00007e4af17d5880  por xmm13, xmm12
00007e4af17d5885  lea rax, [r12+0x20]
00007e4af17d588a  mov r11, [r13+rax*1]
00007e4af17d588f  lea rax, [r12+0x28]
00007e4af17d5894  mov r10, [r13+rax*1]
00007e4af17d5899  movq xmm12, r11
00007e4af17d589e  movq xmm11, r10
00007e4af17d58a3  movq xmm12, xmm12
00007e4af17d58a8  vmovaps [rsp+0x30], xmm12
00007e4af17d58ae  movq xmm12, xmm12
00007e4af17d58b3  movaps [r15+0x150], xmm12
00007e4af17d58bb  movq xmm11, xmm11
00007e4af17d58c0  vmovaps [rsp+0x40], xmm11
00007e4af17d58c6  movq xmm11, xmm11
00007e4af17d58cb  movaps [r15+0x140], xmm11
00007e4af17d58d3  lea rax, [r12+0x10]
00007e4af17d58d8  mov r11, [r13+rax*1]
00007e4af17d58dd  lea rax, [r12+0x18]
00007e4af17d58e2  mov r10, [r13+rax*1]
00007e4af17d58e7  movq xmm12, r11
00007e4af17d58ec  movq xmm11, r10
00007e4af17d58f1  movq xmm12, xmm12
00007e4af17d58f6  vmovaps [rsp+0x50], xmm12
00007e4af17d58fc  movq xmm12, xmm12
00007e4af17d5901  movaps [r15+0x170], xmm12
00007e4af17d5909  movq xmm11, xmm11
00007e4af17d590e  vmovaps [rsp+0x60], xmm11
00007e4af17d5914  movq xmm11, xmm11
00007e4af17d5919  movaps [r15+0x160], xmm11
00007e4af17d5921  mov rax, [r13+r12*1]
00007e4af17d5926  vmovq xmm12, rax
00007e4af17d592b  vpbroadcastq xmm12, xmm12
00007e4af17d5930  lea rax, [r12+0x08]
00007e4af17d5935  mov r12, [r13+rax*1]
00007e4af17d593a  movq xmm11, r12
00007e4af17d593f  movaps [r15+0x230], xmm11
00007e4af17d5947  mov rax, [r15+0xF8]
00007e4af17d594e  lea r12, [rax+0x50]
00007e4af17d5952  movups xmm11, [r13+r12*1]
00007e4af17d5958  lea r12, [rax+0x60]
00007e4af17d595c  movups xmm10, [r13+r12*1]
00007e4af17d5962  lea r12, [rax+0x30]
00007e4af17d5966  movups xmm9, [r13+r12*1]
00007e4af17d596c  mov r12, [r15+0x50]
00007e4af17d5970  lea r11, [r12+r14*1]
00007e4af17d5974  mov [r15+0x60], r11
00007e4af17d5978  lea r12, [r14+0x40]
00007e4af17d597c  mov [r15+0x58], r12
00007e4af17d5980  movaps xmm8, xmm12
00007e4af17d5984  mulpd xmm8, xmm15
00007e4af17d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007e4af17d598f  ptest xmm7, xmm7
00007e4af17d5994  jnz 0x00007E4AF17D67B7
00007e4af17d599a  movq xmm15, qword ptr [r15+0x230]
00007e4af17d59a3  vmovaps [rsp+0x70], xmm15
00007e4af17d59a9  vpermilpd xmm15, xmm15, 0x00
00007e4af17d59af  movaps xmm7, xmm9
00007e4af17d59b3  mulpd xmm7, xmm15
00007e4af17d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007e4af17d59bd  ptest xmm6, xmm6
00007e4af17d59c2  jnz 0x00007E4AF17D68FB
00007e4af17d59c8  vxorps xmm15, xmm15, xmm15
00007e4af17d59cd  vpbroadcastq xmm15, xmm15
00007e4af17d59d2  movaps xmm9, xmm12
00007e4af17d59d6  mulpd xmm9, xmm10
00007e4af17d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007e4af17d59e1  ptest xmm6, xmm6
00007e4af17d59e6  jnz 0x00007E4AF17D6A3D
00007e4af17d59ec  movaps xmm10, xmm12
00007e4af17d59f0  mulpd xmm10, xmm11
00007e4af17d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007e4af17d59fb  ptest xmm6, xmm6
00007e4af17d5a00  jnz 0x00007E4AF17D6B81
00007e4af17d5a06  movaps xmm11, [r15+0x1F0]
00007e4af17d5a0e  movaps xmm6, xmm12
00007e4af17d5a12  mulpd xmm6, xmm11
00007e4af17d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007e4af17d5a1c  ptest xmm5, xmm5
00007e4af17d5a21  jnz 0x00007E4AF17D6CC5
00007e4af17d5a27  movaps xmm12, [r15+0x2A0]
00007e4af17d5a2f  vmovaps [rsp+0x80], xmm12
00007e4af17d5a38  vmovaps xmm11, [rsp+0x80]
00007e4af17d5a41  por xmm12, xmm11
00007e4af17d5a46  movaps xmm11, [r15+0x250]
00007e4af17d5a4e  vmovaps [rsp+0x80], xmm11
00007e4af17d5a57  vmovaps xmm5, [rsp+0x80]
00007e4af17d5a60  por xmm11, xmm5
00007e4af17d5a65  vmovaps xmm4, [rsp+0x70]
00007e4af17d5a6b  vpermilpd xmm4, xmm4, 0x00
00007e4af17d5a71  movaps xmm3, xmm5
00007e4af17d5a74  mulpd xmm3, xmm4
00007e4af17d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007e4af17d5a7d  ptest xmm2, xmm2
00007e4af17d5a82  jnz 0x00007E4AF17D6E07
00007e4af17d5a88  mov [rsp+0x80], rax
00007e4af17d5a90  xor eax, eax
00007e4af17d5a92  mov r14d, 0x200
00007e4af17d5a98  cmp r12, r14
00007e4af17d5a9b  cmc
00007e4af17d5a9c  lahf
00007e4af17d5a9d  seto al
00007e4af17d5aa0  mov [r15+0x108], eax
00007e4af17d5aa7  movaps xmm5, xmm8
00007e4af17d5aab  addpd xmm5, xmm15
00007e4af17d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007e4af17d5ab5  ptest xmm4, xmm4
00007e4af17d5aba  jnz 0x00007E4AF17D6F47
00007e4af17d5ac0  movaps xmm8, [r15+0x1B0]
00007e4af17d5ac8  movaps xmm4, xmm9
00007e4af17d5acc  addpd xmm4, xmm8
00007e4af17d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007e4af17d5ad6  ptest xmm2, xmm2
00007e4af17d5adb  jnz 0x00007E4AF17D7089
00007e4af17d5ae1  movaps xmm9, xmm10
00007e4af17d5ae5  addpd xmm9, xmm8
00007e4af17d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007e4af17d5af0  ptest xmm2, xmm2
00007e4af17d5af5  jnz 0x00007E4AF17D71CB
00007e4af17d5afb  movaps xmm10, [r15+0x2F0]
00007e4af17d5b03  vmovaps [rsp+0x90], xmm10
00007e4af17d5b0c  vmovaps xmm8, [rsp+0x90]
00007e4af17d5b15  por xmm10, xmm8
00007e4af17d5b1a  movaps xmm8, [r15+0x2E0]
00007e4af17d5b22  vmovaps [rsp+0x90], xmm8
00007e4af17d5b2b  vmovaps xmm2, [rsp+0x90]
00007e4af17d5b34  por xmm8, xmm2
00007e4af17d5b39  movaps xmm2, [r15+0x2D0]
00007e4af17d5b41  vmovaps [rsp+0x90], xmm2
00007e4af17d5b4a  vmovaps [rsp+0xA0], xmm1
00007e4af17d5b53  vmovaps xmm1, [rsp+0x90]
00007e4af17d5b5c  por xmm2, xmm1
00007e4af17d5b60  movaps xmm1, [r15+0x200]
00007e4af17d5b68  vmovaps [rsp+0x90], xmm1
00007e4af17d5b71  vmovaps [rsp+0xB0], xmm15
00007e4af17d5b7a  vmovaps xmm15, [rsp+0x90]
00007e4af17d5b83  por xmm1, xmm15
00007e4af17d5b88  movaps xmm15, [r15+0x1C0]
00007e4af17d5b90  vmovaps [rsp+0x90], xmm15
00007e4af17d5b99  vmovaps [rsp+0xC0], xmm1
00007e4af17d5ba2  vmovaps xmm1, [rsp+0x90]
00007e4af17d5bab  por xmm15, xmm1
00007e4af17d5bb0  movaps xmm1, [r15+0x190]
00007e4af17d5bb8  vmovaps [rsp+0x90], xmm1
00007e4af17d5bc1  vmovaps [rsp+0xD0], xmm15
00007e4af17d5bca  vmovaps xmm15, [rsp+0x90]
00007e4af17d5bd3  por xmm1, xmm15
00007e4af17d5bd8  movaps xmm15, [r15+0x300]
00007e4af17d5be0  vmovaps [rsp+0x90], xmm15
00007e4af17d5be9  vmovaps [rsp+0xE0], xmm1
00007e4af17d5bf2  vmovaps xmm1, [rsp+0x90]
00007e4af17d5bfb  por xmm15, xmm1
00007e4af17d5c00  mov rax, [rsp+0x80]
00007e4af17d5c08  lea r14, [rax+0xA0]
00007e4af17d5c0f  movups xmm1, [r13+r14*1]
00007e4af17d5c15  lea r14, [rax+0xB0]
00007e4af17d5c1c  vmovaps [rsp+0x80], xmm1
00007e4af17d5c25  movups xmm1, [r13+r14*1]
00007e4af17d5c2b  vmovaps [rsp+0x90], xmm1
00007e4af17d5c34  vmovaps [rsp+0xF0], xmm15
00007e4af17d5c3d  vmovaps xmm15, [rsp+0xB0]
00007e4af17d5c46  vmovaps [rsp+0xB0], xmm14
00007e4af17d5c4f  movaps xmm1, xmm6
00007e4af17d5c52  addpd xmm1, xmm15
00007e4af17d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007e4af17d5c5c  ptest xmm14, xmm14
00007e4af17d5c62  jnz 0x00007E4AF17D7323
00007e4af17d5c68  lea r14, [rax+0xF0]
00007e4af17d5c6f  movups xmm15, [r13+r14*1]
00007e4af17d5c75  movaps xmm14, xmm4
00007e4af17d5c79  addpd xmm14, xmm3
00007e4af17d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007e4af17d5c84  ptest xmm6, xmm6
00007e4af17d5c89  jnz 0x00007E4AF17D746E
00007e4af17d5c8f  movaps xmm6, xmm9
00007e4af17d5c93  addpd xmm6, xmm7
00007e4af17d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007e4af17d5c9c  ptest xmm4, xmm4
00007e4af17d5ca1  jnz 0x00007E4AF17D75B0
00007e4af17d5ca7  vmovaps xmm9, [rsp+0x70]
00007e4af17d5cad  vpermilpd xmm9, xmm9, 0x00
00007e4af17d5cb3  vmovaps xmm4, [rsp+0x90]
00007e4af17d5cbc  movaps xmm7, xmm4
00007e4af17d5cbf  mulpd xmm7, xmm9
00007e4af17d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007e4af17d5cc9  ptest xmm3, xmm3
00007e4af17d5cce  jnz 0x00007E4AF17D76F1
00007e4af17d5cd4  vmovaps xmm9, [rsp+0x50]
00007e4af17d5cda  vpermilpd xmm9, xmm9, 0x00
00007e4af17d5ce0  movaps xmm4, xmm15
00007e4af17d5ce4  mulpd xmm4, xmm9
00007e4af17d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007e4af17d5cee  ptest xmm3, xmm3
00007e4af17d5cf3  jnz 0x00007E4AF17D7832
00007e4af17d5cf9  lea r14, [rax+0xE0]
00007e4af17d5d00  movups xmm15, [r13+r14*1]
00007e4af17d5d06  vmovaps xmm9, [rsp+0x70]
00007e4af17d5d0c  vpermilpd xmm9, xmm9, 0x00
00007e4af17d5d12  vmovaps [rsp+0x70], xmm1
00007e4af17d5d18  vmovaps xmm1, [rsp+0x80]
00007e4af17d5d21  vmovaps [rsp+0x80], xmm15
00007e4af17d5d2a  movaps xmm3, xmm1
00007e4af17d5d2d  mulpd xmm3, xmm9
00007e4af17d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007e4af17d5d37  ptest xmm15, xmm15
00007e4af17d5d3d  jnz 0x00007E4AF17D797E
00007e4af17d5d43  vmovaps xmm1, [rsp+0xF0]
00007e4af17d5d4c  vmovaps xmm15, [rsp+0xF0]
00007e4af17d5d55  por xmm1, xmm15
00007e4af17d5d5a  movaps [r15+0x300], xmm1
00007e4af17d5d62  vmovaps xmm15, [rsp+0xE0]
00007e4af17d5d6b  vmovaps xmm9, [rsp+0xE0]
00007e4af17d5d74  por xmm15, xmm9
00007e4af17d5d79  movaps [r15+0x190], xmm15
00007e4af17d5d81  vmovaps xmm9, [rsp+0x50]
00007e4af17d5d87  vpermilpd xmm9, xmm9, 0x00
00007e4af17d5d8d  vmovaps [rsp+0x90], xmm1
00007e4af17d5d96  vmovaps [rsp+0xE0], xmm15
00007e4af17d5d9f  vmovaps xmm15, [rsp+0x80]
00007e4af17d5da8  vmovaps [rsp+0x80], xmm14
00007e4af17d5db1  movaps xmm1, xmm15
00007e4af17d5db5  mulpd xmm1, xmm9
00007e4af17d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007e4af17d5dbf  ptest xmm14, xmm14
00007e4af17d5dc5  jnz 0x00007E4AF17D7ABF
00007e4af17d5dcb  lea r14, [rax+0x90]
00007e4af17d5dd2  movups xmm15, [r13+r14*1]
00007e4af17d5dd8  vmovaps xmm14, [rsp+0xD0]
00007e4af17d5de1  vmovaps xmm9, [rsp+0xD0]
00007e4af17d5dea  por xmm14, xmm9
00007e4af17d5def  movaps [r15+0x1C0], xmm14
00007e4af17d5df7  vmovaps xmm9, [rsp+0xC0]
00007e4af17d5e00  vmovaps [rsp+0xD0], xmm1
00007e4af17d5e09  vmovaps xmm1, [rsp+0xC0]
00007e4af17d5e12  por xmm9, xmm1
00007e4af17d5e17  movaps [r15+0x200], xmm9
00007e4af17d5e1f  vmovaps [rsp+0xC0], xmm2
00007e4af17d5e28  vmovaps xmm1, [rsp+0xC0]
00007e4af17d5e31  por xmm2, xmm1
00007e4af17d5e35  movaps [r15+0x2D0], xmm2
00007e4af17d5e3d  vmovaps [rsp+0xC0], xmm8
00007e4af17d5e46  vmovaps xmm1, [rsp+0xC0]
00007e4af17d5e4f  por xmm8, xmm1
00007e4af17d5e54  movaps [r15+0x2E0], xmm8
00007e4af17d5e5c  vmovaps [rsp+0xC0], xmm15
00007e4af17d5e65  movaps xmm1, xmm5
00007e4af17d5e68  addpd xmm1, xmm7
00007e4af17d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007e4af17d5e71  ptest xmm15, xmm15
00007e4af17d5e77  jnz 0x00007E4AF17D7C0B
00007e4af17d5e7d  vmovaps xmm15, [rsp+0x50]
00007e4af17d5e83  vpermilpd xmm15, xmm15, 0x00
00007e4af17d5e89  vmovaps xmm5, [rsp+0xC0]
00007e4af17d5e92  vmovaps [rsp+0xC0], xmm1
00007e4af17d5e9b  movaps xmm7, xmm5
00007e4af17d5e9e  mulpd xmm7, xmm15
00007e4af17d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007e4af17d5ea8  ptest xmm1, xmm1
00007e4af17d5ead  jnz 0x00007E4AF17D7D4B
00007e4af17d5eb3  lea r14, [rax+0x80]
00007e4af17d5eba  movups xmm1, [r13+r14*1]
00007e4af17d5ec0  vmovaps xmm5, [rsp+0x70]
00007e4af17d5ec6  vmovaps [rsp+0x70], xmm1
00007e4af17d5ecc  movaps xmm15, xmm5
00007e4af17d5ed0  addpd xmm15, xmm3
00007e4af17d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007e4af17d5edb  ptest xmm1, xmm1
00007e4af17d5ee0  jnz 0x00007E4AF17D7E96
00007e4af17d5ee6  vmovaps xmm5, [rsp+0x80]
00007e4af17d5eef  movaps xmm1, xmm5
00007e4af17d5ef2  addpd xmm1, xmm4
00007e4af17d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007e4af17d5efb  ptest xmm3, xmm3
00007e4af17d5f00  jnz 0x00007E4AF17D7FD8
00007e4af17d5f06  vmovaps [rsp+0x80], xmm10
00007e4af17d5f0f  vmovaps xmm5, [rsp+0x80]
00007e4af17d5f18  por xmm10, xmm5
00007e4af17d5f1d  movaps [r15+0x2F0], xmm10
00007e4af17d5f25  vmovaps xmm5, [rsp+0x50]
00007e4af17d5f2b  vpermilpd xmm5, xmm5, 0x00
00007e4af17d5f31  vmovaps xmm3, [rsp+0x70]
00007e4af17d5f37  vmovaps [rsp+0x50], xmm1
00007e4af17d5f3d  movaps xmm4, xmm3
00007e4af17d5f40  mulpd xmm4, xmm5
00007e4af17d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007e4af17d5f49  ptest xmm1, xmm1
00007e4af17d5f4e  jnz 0x00007E4AF17D8118
00007e4af17d5f54  lea r14, [rax+0xD0]
00007e4af17d5f5b  movups xmm1, [r13+r14*1]
00007e4af17d5f61  vmovaps xmm3, [rsp+0xD0]
00007e4af17d5f6a  vmovaps [rsp+0x70], xmm1
00007e4af17d5f70  movaps xmm5, xmm6
00007e4af17d5f73  addpd xmm5, xmm3
00007e4af17d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007e4af17d5f7c  ptest xmm1, xmm1
00007e4af17d5f81  jnz 0x00007E4AF17D8262
00007e4af17d5f87  vmovaps xmm1, [rsp+0x60]
00007e4af17d5f8d  vpermilpd xmm1, xmm1, 0x00
00007e4af17d5f93  movaps xmm6, xmm9
00007e4af17d5f97  mulpd xmm6, xmm1
00007e4af17d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007e4af17d5fa0  ptest xmm3, xmm3
00007e4af17d5fa5  jnz 0x00007E4AF17D83A2
00007e4af17d5fab  movaps [r15+0x260], xmm6
00007e4af17d5fb3  vxorps xmm1, xmm1, xmm1
00007e4af17d5fb7  vpbroadcastq xmm1, xmm1
00007e4af17d5fbc  movaps [r15+0x1B0], xmm1
00007e4af17d5fc4  vmovaps xmm1, [rsp+0x60]
00007e4af17d5fca  vpermilpd xmm1, xmm1, 0x00
00007e4af17d5fd0  vmovaps xmm3, [rsp+0x70]
00007e4af17d5fd6  vmovaps [rsp+0x70], xmm15
00007e4af17d5fdc  movaps xmm9, xmm3
00007e4af17d5fe0  mulpd xmm9, xmm1
00007e4af17d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007e4af17d5feb  ptest xmm15, xmm15
00007e4af17d5ff1  jnz 0x00007E4AF17D84E3
00007e4af17d5ff7  lea r14, [rax+0xC0]
00007e4af17d5ffe  movups xmm1, [r13+r14*1]
00007e4af17d6004  vmovaps xmm3, [rsp+0xC0]
00007e4af17d600d  vmovaps [rsp+0x80], xmm1
00007e4af17d6016  movaps xmm15, xmm3
00007e4af17d601a  addpd xmm15, xmm7
00007e4af17d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007e4af17d6025  ptest xmm1, xmm1
00007e4af17d602a  jnz 0x00007E4AF17D862F
00007e4af17d6030  vmovaps [rsp+0xC0], xmm13
00007e4af17d6039  vmovaps xmm1, [rsp+0xC0]
00007e4af17d6042  por xmm13, xmm1
00007e4af17d6047  movaps [r15+0x270], xmm13
00007e4af17d604f  vmovaps xmm1, [rsp+0xB0]
00007e4af17d6058  vmovaps xmm7, [rsp+0xB0]
00007e4af17d6061  por xmm1, xmm7
00007e4af17d6065  movaps [r15+0x1A0], xmm1
00007e4af17d606d  vmovaps xmm1, [rsp+0x60]
00007e4af17d6073  vpermilpd xmm1, xmm1, 0x00
00007e4af17d6079  vmovaps [rsp+0xB0], xmm1
00007e4af17d6082  vmovaps xmm1, [rsp+0x80]
00007e4af17d608b  vmovaps [rsp+0x80], xmm15
00007e4af17d6094  vmovaps xmm15, [rsp+0xB0]
00007e4af17d609d  vmovaps [rsp+0xB0], xmm14
00007e4af17d60a6  movaps xmm3, xmm1
00007e4af17d60a9  mulpd xmm3, xmm15
00007e4af17d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007e4af17d60b3  ptest xmm14, xmm14
00007e4af17d60b9  jnz 0x00007E4AF17D8771
00007e4af17d60bf  lea r14, [rax+0x20]
00007e4af17d60c3  movups xmm1, [r13+r14*1]
00007e4af17d60c9  movaps [r15+0x110], xmm1
00007e4af17d60d1  vmovaps xmm14, [rsp+0x70]
00007e4af17d60d7  vmovaps [rsp+0x70], xmm1
00007e4af17d60dd  movaps xmm15, xmm14
00007e4af17d60e1  addpd xmm15, xmm4
00007e4af17d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007e4af17d60ec  ptest xmm1, xmm1
00007e4af17d60f1  jnz 0x00007E4AF17D88BC
00007e4af17d60f7  vmovaps xmm1, [rsp+0x60]
00007e4af17d60fd  vpermilpd xmm1, xmm1, 0x00
00007e4af17d6103  movaps xmm14, xmm2
00007e4af17d6107  mulpd xmm14, xmm1
00007e4af17d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007e4af17d6112  ptest xmm4, xmm4
00007e4af17d6117  jnz 0x00007E4AF17D89FF
00007e4af17d611d  vmovaps xmm4, [rsp+0x50]
00007e4af17d6123  movaps xmm1, xmm4
00007e4af17d6126  addpd xmm1, xmm9
00007e4af17d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007e4af17d6130  ptest xmm2, xmm2
00007e4af17d6135  jnz 0x00007E4AF17D8B41
00007e4af17d613b  vmovaps xmm9, [rsp+0x30]
00007e4af17d6141  vpermilpd xmm9, xmm9, 0x00
00007e4af17d6147  vmovaps xmm2, [rsp+0x70]
00007e4af17d614d  vmovaps [rsp+0x50], xmm1
00007e4af17d6153  movaps xmm4, xmm2
00007e4af17d6156  mulpd xmm4, xmm9
00007e4af17d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007e4af17d6160  ptest xmm1, xmm1
00007e4af17d6165  jnz 0x00007E4AF17D8C82
00007e4af17d616b  vmovaps xmm1, [rsp+0x30]
00007e4af17d6171  vpermilpd xmm1, xmm1, 0x00
00007e4af17d6177  vmovaps xmm2, [rsp+0x90]
00007e4af17d6180  vmovaps [rsp+0x60], xmm15
00007e4af17d6186  movaps xmm9, xmm2
00007e4af17d618a  mulpd xmm9, xmm1
00007e4af17d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007e4af17d6195  ptest xmm15, xmm15
00007e4af17d619b  jnz 0x00007E4AF17D8DC3
00007e4af17d61a1  vmovaps xmm15, [rsp+0x80]
00007e4af17d61aa  movaps xmm1, xmm15
00007e4af17d61ae  addpd xmm1, xmm6
00007e4af17d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007e4af17d61b7  ptest xmm2, xmm2
00007e4af17d61bc  jnz 0x00007E4AF17D8F05
00007e4af17d61c2  movaps xmm15, xmm5
00007e4af17d61c6  addpd xmm15, xmm3
00007e4af17d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007e4af17d61d1  ptest xmm6, xmm6
00007e4af17d61d6  jnz 0x00007E4AF17D9046
00007e4af17d61dc  vmovaps xmm6, [rsp+0x30]
00007e4af17d61e2  vpermilpd xmm6, xmm6, 0x00
00007e4af17d61e8  movaps xmm5, xmm8
00007e4af17d61ec  mulpd xmm5, xmm6
00007e4af17d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007e4af17d61f5  ptest xmm3, xmm3
00007e4af17d61fa  jnz 0x00007E4AF17D9188
00007e4af17d6200  vmovaps xmm8, [rsp+0x30]
00007e4af17d6206  vpermilpd xmm8, xmm8, 0x00
00007e4af17d620c  movaps xmm6, xmm10
00007e4af17d6210  mulpd xmm6, xmm8
00007e4af17d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007e4af17d621a  ptest xmm3, xmm3
00007e4af17d621f  jnz 0x00007E4AF17D92C9
00007e4af17d6225  vmovaps xmm8, [rsp+0x60]
00007e4af17d622b  movaps xmm10, xmm8
00007e4af17d622f  addpd xmm10, xmm14
00007e4af17d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007e4af17d623a  ptest xmm3, xmm3
00007e4af17d623f  jnz 0x00007E4AF17D940B
00007e4af17d6245  vmovaps xmm8, [rsp+0x50]
00007e4af17d624b  movaps xmm14, xmm8
00007e4af17d624f  addpd xmm14, xmm4
00007e4af17d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007e4af17d625a  ptest xmm3, xmm3
00007e4af17d625f  jnz 0x00007E4AF17D954F
00007e4af17d6265  vmovaps xmm8, [rsp+0x40]
00007e4af17d626b  vpermilpd xmm8, xmm8, 0x00
00007e4af17d6271  movaps xmm4, xmm13
00007e4af17d6275  mulpd xmm4, xmm8
00007e4af17d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007e4af17d627f  ptest xmm3, xmm3
00007e4af17d6284  jnz 0x00007E4AF17D9692
00007e4af17d628a  movaps xmm13, xmm15
00007e4af17d628e  addpd xmm13, xmm9
00007e4af17d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007e4af17d6299  ptest xmm8, xmm8
00007e4af17d629f  jnz 0x00007E4AF17D97D4
00007e4af17d62a5  movaps xmm15, xmm1
00007e4af17d62a9  addpd xmm15, xmm5
00007e4af17d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007e4af17d62b4  ptest xmm9, xmm9
00007e4af17d62ba  jnz 0x00007E4AF17D9918
00007e4af17d62c0  vmovaps [rsp+0x30], xmm11
00007e4af17d62c6  vmovaps xmm1, [rsp+0x30]
00007e4af17d62cc  por xmm11, xmm1
00007e4af17d62d1  movaps [r15+0x250], xmm11
00007e4af17d62d9  vmovaps [rsp+0x30], xmm12
00007e4af17d62df  vmovaps xmm1, [rsp+0x30]
00007e4af17d62e5  por xmm12, xmm1
00007e4af17d62ea  movaps [r15+0x2A0], xmm12
00007e4af17d62f2  vmovaps xmm1, [rsp+0xA0]
00007e4af17d62fb  vmovaps xmm11, [rsp+0xA0]
00007e4af17d6304  por xmm1, xmm11
00007e4af17d6309  movaps [r15+0x1D0], xmm1
00007e4af17d6311  lea r14, [rax+0x40]
00007e4af17d6315  movups xmm1, [r13+r14*1]
00007e4af17d631b  movaps [r15+0x2C0], xmm1
00007e4af17d6323  vmovaps xmm11, [rsp+0x40]
00007e4af17d6329  vpermilpd xmm11, xmm11, 0x00
00007e4af17d632f  vmovaps xmm8, [rsp+0xE0]
00007e4af17d6338  movaps xmm9, xmm8
00007e4af17d633c  mulpd xmm9, xmm11
00007e4af17d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007e4af17d6347  ptest xmm5, xmm5
00007e4af17d634c  jnz 0x00007E4AF17D9A64
00007e4af17d6352  movaps xmm11, xmm10
00007e4af17d6356  addpd xmm11, xmm6
00007e4af17d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007e4af17d6361  ptest xmm8, xmm8
00007e4af17d6367  jnz 0x00007E4AF17D9BA8
00007e4af17d636d  movaps xmm10, xmm14
00007e4af17d6371  addpd xmm10, xmm4
00007e4af17d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007e4af17d637c  ptest xmm8, xmm8
00007e4af17d6382  jnz 0x00007E4AF17D9CEB
00007e4af17d6388  vmovaps xmm14, [rsp+0x40]
00007e4af17d638e  vpermilpd xmm14, xmm14, 0x00
00007e4af17d6394  movaps xmm8, xmm1
00007e4af17d6398  mulpd xmm8, xmm14
00007e4af17d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007e4af17d63a3  ptest xmm6, xmm6
00007e4af17d63a8  jnz 0x00007E4AF17D9E2E
00007e4af17d63ae  movaps xmm1, [r15+0x2B0]
00007e4af17d63b6  vmovaps xmm14, [rsp+0x40]
00007e4af17d63bc  vpermilpd xmm14, xmm14, 0x00
00007e4af17d63c2  movaps xmm6, xmm1
00007e4af17d63c5  mulpd xmm6, xmm14
00007e4af17d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007e4af17d63cf  ptest xmm5, xmm5
00007e4af17d63d4  jnz 0x00007E4AF17D9F71
00007e4af17d63da  vmovaps xmm1, [rsp+0x10]
00007e4af17d63e0  vpermilpd xmm1, xmm1, 0x00
00007e4af17d63e6  movaps xmm14, xmm12
00007e4af17d63ea  mulpd xmm14, xmm1
00007e4af17d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007e4af17d63f5  ptest xmm5, xmm5
00007e4af17d63fa  jnz 0x00007E4AF17DA0B2
00007e4af17d6400  movaps xmm1, xmm13
00007e4af17d6404  addpd xmm1, xmm9
00007e4af17d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007e4af17d640e  ptest xmm12, xmm12
00007e4af17d6414  jnz 0x00007E4AF17DA1F5
00007e4af17d641a  vmovaps xmm13, [rsp+0x10]
00007e4af17d6420  vpermilpd xmm13, xmm13, 0x00
00007e4af17d6426  movaps xmm12, xmm7
00007e4af17d642a  mulpd xmm12, xmm13
00007e4af17d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007e4af17d6435  ptest xmm9, xmm9
00007e4af17d643b  jnz 0x00007E4AF17DA337
00007e4af17d6441  movaps xmm13, xmm15
00007e4af17d6445  addpd xmm13, xmm8
00007e4af17d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007e4af17d6450  ptest xmm9, xmm9
00007e4af17d6456  jnz 0x00007E4AF17DA47A
00007e4af17d645c  movaps xmm15, [r15+0x290]
00007e4af17d6464  vmovaps xmm9, [rsp+0x10]
00007e4af17d646a  vpermilpd xmm9, xmm9, 0x00
00007e4af17d6470  movaps xmm8, xmm15
00007e4af17d6474  mulpd xmm8, xmm9
00007e4af17d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007e4af17d647f  ptest xmm7, xmm7
00007e4af17d6484  jnz 0x00007E4AF17DA5BE
00007e4af17d648a  movaps xmm15, xmm11
00007e4af17d648e  addpd xmm15, xmm6
00007e4af17d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007e4af17d6499  ptest xmm9, xmm9
00007e4af17d649f  jnz 0x00007E4AF17DA702
00007e4af17d64a5  movaps xmm11, [r15+0x1E0]
00007e4af17d64ad  vmovaps xmm9, [rsp+0x10]
00007e4af17d64b3  vpermilpd xmm9, xmm9, 0x00
00007e4af17d64b9  movaps xmm7, xmm11
00007e4af17d64bd  mulpd xmm7, xmm9
00007e4af17d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007e4af17d64c7  ptest xmm6, xmm6
00007e4af17d64cc  jnz 0x00007E4AF17DA845
00007e4af17d64d2  movaps xmm11, xmm10
00007e4af17d64d6  addpd xmm11, xmm14
00007e4af17d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007e4af17d64e1  ptest xmm9, xmm9
00007e4af17d64e7  jnz 0x00007E4AF17DA987
00007e4af17d64ed  lea r14, [rax+0x70]
00007e4af17d64f1  movups xmm14, [r13+r14*1]
00007e4af17d64f7  movaps [r15+0x240], xmm14
00007e4af17d64ff  movaps xmm10, xmm1
00007e4af17d6503  addpd xmm10, xmm12
00007e4af17d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007e4af17d650e  ptest xmm9, xmm9
00007e4af17d6514  jnz 0x00007E4AF17DAAD5
00007e4af17d651a  movaps [r15+0x170], xmm10
00007e4af17d6522  vmovaps xmm1, [rsp+0x20]
00007e4af17d6528  vpermilpd xmm1, xmm1, 0x00
00007e4af17d652e  movaps xmm12, xmm14
00007e4af17d6532  mulpd xmm12, xmm1
00007e4af17d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007e4af17d653d  ptest xmm9, xmm9
00007e4af17d6543  jnz 0x00007E4AF17DAC18
00007e4af17d6549  vmovaps xmm1, [rsp+0x20]
00007e4af17d654f  vpermilpd xmm1, xmm1, 0x00
00007e4af17d6555  vmovaps xmm9, [rsp+0xB0]
00007e4af17d655e  movaps xmm14, xmm9
00007e4af17d6562  mulpd xmm14, xmm1
00007e4af17d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007e4af17d656d  ptest xmm6, xmm6
00007e4af17d6572  jnz 0x00007E4AF17DAD5B
00007e4af17d6578  movaps [r15+0x180], xmm14
00007e4af17d6580  movaps xmm1, xmm13
00007e4af17d6584  addpd xmm1, xmm8
00007e4af17d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007e4af17d658e  ptest xmm9, xmm9
00007e4af17d6594  jnz 0x00007E4AF17DAE9E
00007e4af17d659a  movaps [r15+0x210], xmm1
00007e4af17d65a2  movups xmm13, [r13+rax*1]
00007e4af17d65a8  lea r14, [rax+0x10]
00007e4af17d65ac  movups xmm9, [r13+r14*1]
00007e4af17d65b2  movaps [r15+0x230], xmm9
00007e4af17d65ba  movaps xmm8, xmm15
00007e4af17d65be  addpd xmm8, xmm7
00007e4af17d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007e4af17d65c9  ptest xmm6, xmm6
00007e4af17d65ce  jnz 0x00007E4AF17DAFF4
00007e4af17d65d4  movaps [r15+0x130], xmm8
00007e4af17d65dc  vmovaps xmm15, [rsp+0x20]
00007e4af17d65e2  vpermilpd xmm15, xmm15, 0x00
00007e4af17d65e8  movaps xmm7, xmm9
00007e4af17d65ec  mulpd xmm7, xmm15
00007e4af17d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007e4af17d65f6  ptest xmm6, xmm6
00007e4af17d65fb  jnz 0x00007E4AF17DB137
00007e4af17d6601  movaps [r15+0x220], xmm7
00007e4af17d6609  vmovaps xmm15, [rsp+0x20]
00007e4af17d660f  vpermilpd xmm15, xmm15, 0x00
00007e4af17d6615  movaps xmm9, xmm13
00007e4af17d6619  mulpd xmm9, xmm15
00007e4af17d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007e4af17d6624  ptest xmm6, xmm6
00007e4af17d6629  jnz 0x00007E4AF17DB279
00007e4af17d662f  movaps xmm15, xmm11
00007e4af17d6633  addpd xmm15, xmm12
00007e4af17d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007e4af17d663e  ptest xmm13, xmm13
00007e4af17d6644  jnz 0x00007E4AF17DB3BD
00007e4af17d664a  movaps [r15+0x140], xmm15
00007e4af17d6652  movaps xmm13, xmm10
00007e4af17d6656  addpd xmm13, xmm14
00007e4af17d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007e4af17d6661  ptest xmm12, xmm12
00007e4af17d6667  jnz 0x00007E4AF17DB501
00007e4af17d666d  movaps [r15+0x150], xmm13
00007e4af17d6675  movaps xmm14, xmm1
00007e4af17d6679  addpd xmm14, xmm7
00007e4af17d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007e4af17d6684  ptest xmm12, xmm12
00007e4af17d668a  jnz 0x00007E4AF17DB645
00007e4af17d6690  movaps [r15+0x160], xmm14
00007e4af17d6698  movaps xmm1, xmm8
00007e4af17d669c  addpd xmm1, xmm9
00007e4af17d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007e4af17d66a6  ptest xmm12, xmm12
00007e4af17d66ac  jnz 0x00007E4AF17DB787
00007e4af17d66b2  movaps [r15+0x120], xmm1
00007e4af17d66ba  movups [r13+r11*1], xmm15
00007e4af17d66c0  lea rax, [r11+0x10]
00007e4af17d66c4  movups [r13+rax*1], xmm13
00007e4af17d66ca  lea rax, [r11+0x20]
00007e4af17d66ce  movups [r13+rax*1], xmm14
00007e4af17d66d4  lea rax, [r11+0x30]
00007e4af17d66d8  movups [r13+rax*1], xmm1
00007e4af17d66de  mov eax, [r15+0x108]
00007e4af17d66e5  sahf
00007e4af17d66e6  jnz 0x00007E4AF17D6718
00007e4af17d66e8  cmp dword ptr [r15+0x318], 0x00
00007e4af17d66f0  jz 0x00007E4AF17DB900
00007e4af17d66f6  nop [rax+rax*1], ax
00007e4af17d66ff  nop [rax+rax*1], eax
00007e4af17d6707  mov eax, 0x410444
00007e4af17d670c  mov [r15+0x100], rax
00007e4af17d6713  jmp 0x00007E4AF15FE110
00007e4af17d6718  cmp dword ptr [r15+0x318], 0x00
00007e4af17d6720  jz 0x00007E4AF17D57E0
00007e4af17d6726  nop [rax+rax*1], ax
00007e4af17d672f  nop [rax+rax*1], eax
00007e4af17d6737  mov eax, 0x410278
00007e4af17d673c  mov [r15+0x100], rax
00007e4af17d6743  jmp 0x00007E4AF15FE110
00007e4af17d6748  int3
00007e4af17d6749  call 0x00007E4AF160A4B0
00007e4af17d674e  jmp 0x00007E4AF17D5828
00007e4af17d6753  call 0x00007E4AF1609240
00007e4af17d6758  jmp 0x00007E4AF17D5832
00007e4af17d675d  call 0x00007E4AF160A4B0
00007e4af17d6762  jmp 0x00007E4AF17D588F
00007e4af17d6767  call 0x00007E4AF1609240
00007e4af17d676c  jmp 0x00007E4AF17D5899
00007e4af17d6771  call 0x00007E4AF160A4B0
00007e4af17d6776  jmp 0x00007E4AF17D58DD
00007e4af17d677b  call 0x00007E4AF1609240
00007e4af17d6780  jmp 0x00007E4AF17D58E7
00007e4af17d6785  call 0x00007E4AF16B47C0
00007e4af17d678a  jmp 0x00007E4AF17D5926
00007e4af17d678f  call 0x00007E4AF160B720
00007e4af17d6794  jmp 0x00007E4AF17D593A
00007e4af17d6799  call 0x00007E4AF16BFC30
00007e4af17d679e  jmp 0x00007E4AF17D5958
00007e4af17d67a3  call 0x00007E4AF16BE9C0
00007e4af17d67a8  jmp 0x00007E4AF17D5962
00007e4af17d67ad  call 0x00007E4AF16BD750
00007e4af17d67b2  jmp 0x00007E4AF17D596C
00007e4af17d67b7  sub rsp, 0x08
00007e4af17d67bb  push rax
00007e4af17d67bc  push rcx
00007e4af17d67bd  push rdx
00007e4af17d67be  push rdi
00007e4af17d67bf  push rsi
00007e4af17d67c0  push r8
00007e4af17d67c2  push r9
00007e4af17d67c4  push r10
00007e4af17d67c6  push r11
00007e4af17d67c8  sub rsp, 0xF0
00007e4af17d67cf  vmovaps [rsp], xmm0
00007e4af17d67d4  vmovaps [rsp+0x10], xmm1
00007e4af17d67da  vmovaps [rsp+0x20], xmm2
00007e4af17d67e0  vmovaps [rsp+0x30], xmm3
00007e4af17d67e6  vmovaps [rsp+0x40], xmm4
00007e4af17d67ec  vmovaps [rsp+0x50], xmm5
00007e4af17d67f2  vmovaps [rsp+0x60], xmm6
00007e4af17d67f8  vmovaps [rsp+0x70], xmm7
00007e4af17d67fe  vmovaps [rsp+0x80], xmm9
00007e4af17d6807  vmovaps [rsp+0x90], xmm10
00007e4af17d6810  vmovaps [rsp+0xA0], xmm11
00007e4af17d6819  vmovaps [rsp+0xB0], xmm12
00007e4af17d6822  vmovaps [rsp+0xC0], xmm13
00007e4af17d682b  vmovaps [rsp+0xD0], xmm14
00007e4af17d6834  vmovaps [rsp+0xE0], xmm15
00007e4af17d683d  sub rsp, 0x30
00007e4af17d6841  movaps [rsp], xmm8
00007e4af17d6846  movaps [rsp+0x10], xmm12
00007e4af17d684c  movaps [rsp+0x20], xmm15
00007e4af17d6852  lea rdi, [rsp]
00007e4af17d6856  mov esi, 0x00
00007e4af17d685b  mov rax, 0x6256754A7530
00007e4af17d6865  call rax
00007e4af17d6867  movaps xmm8, [rsp]
00007e4af17d686c  add rsp, 0x30
00007e4af17d6870  vmovaps xmm0, [rsp]
00007e4af17d6875  vmovaps xmm1, [rsp+0x10]
00007e4af17d687b  vmovaps xmm2, [rsp+0x20]
00007e4af17d6881  vmovaps xmm3, [rsp+0x30]
00007e4af17d6887  vmovaps xmm4, [rsp+0x40]
00007e4af17d688d  vmovaps xmm5, [rsp+0x50]
00007e4af17d6893  vmovaps xmm6, [rsp+0x60]
00007e4af17d6899  vmovaps xmm7, [rsp+0x70]
00007e4af17d689f  vmovaps xmm9, [rsp+0x80]
00007e4af17d68a8  vmovaps xmm10, [rsp+0x90]
00007e4af17d68b1  vmovaps xmm11, [rsp+0xA0]
00007e4af17d68ba  vmovaps xmm12, [rsp+0xB0]
00007e4af17d68c3  vmovaps xmm13, [rsp+0xC0]
00007e4af17d68cc  vmovaps xmm14, [rsp+0xD0]
00007e4af17d68d5  vmovaps xmm15, [rsp+0xE0]
00007e4af17d68de  add rsp, 0xF0
00007e4af17d68e5  pop r11
00007e4af17d68e7  pop r10
00007e4af17d68e9  pop r9
00007e4af17d68eb  pop r8
00007e4af17d68ed  pop rsi
00007e4af17d68ee  pop rdi
00007e4af17d68ef  pop rdx
00007e4af17d68f0  pop rcx
00007e4af17d68f1  pop rax
00007e4af17d68f2  add rsp, 0x08
00007e4af17d68f6  jmp 0x00007E4AF17D599A
00007e4af17d68fb  sub rsp, 0x08
00007e4af17d68ff  push rax
00007e4af17d6900  push rcx
00007e4af17d6901  push rdx
00007e4af17d6902  push rdi
00007e4af17d6903  push rsi
00007e4af17d6904  push r8
00007e4af17d6906  push r9
00007e4af17d6908  push r10
00007e4af17d690a  push r11
00007e4af17d690c  sub rsp, 0xF0
00007e4af17d6913  vmovaps [rsp], xmm0
00007e4af17d6918  vmovaps [rsp+0x10], xmm1
00007e4af17d691e  vmovaps [rsp+0x20], xmm2
00007e4af17d6924  vmovaps [rsp+0x30], xmm3
00007e4af17d692a  vmovaps [rsp+0x40], xmm4
00007e4af17d6930  vmovaps [rsp+0x50], xmm5
00007e4af17d6936  vmovaps [rsp+0x60], xmm6
00007e4af17d693c  vmovaps [rsp+0x70], xmm8
00007e4af17d6942  vmovaps [rsp+0x80], xmm9
00007e4af17d694b  vmovaps [rsp+0x90], xmm10
00007e4af17d6954  vmovaps [rsp+0xA0], xmm11
00007e4af17d695d  vmovaps [rsp+0xB0], xmm12
00007e4af17d6966  vmovaps [rsp+0xC0], xmm13
00007e4af17d696f  vmovaps [rsp+0xD0], xmm14
00007e4af17d6978  vmovaps [rsp+0xE0], xmm15
00007e4af17d6981  sub rsp, 0x30
00007e4af17d6985  movaps [rsp], xmm7
00007e4af17d6989  movaps [rsp+0x10], xmm9
00007e4af17d698f  movaps [rsp+0x20], xmm15
00007e4af17d6995  lea rdi, [rsp]
00007e4af17d6999  mov esi, 0x00
00007e4af17d699e  mov rax, 0x6256754A7530
00007e4af17d69a8  call rax
00007e4af17d69aa  movaps xmm7, [rsp]
00007e4af17d69ae  add rsp, 0x30
00007e4af17d69b2  vmovaps xmm0, [rsp]
00007e4af17d69b7  vmovaps xmm1, [rsp+0x10]
00007e4af17d69bd  vmovaps xmm2, [rsp+0x20]
00007e4af17d69c3  vmovaps xmm3, [rsp+0x30]
00007e4af17d69c9  vmovaps xmm4, [rsp+0x40]
00007e4af17d69cf  vmovaps xmm5, [rsp+0x50]
00007e4af17d69d5  vmovaps xmm6, [rsp+0x60]
00007e4af17d69db  vmovaps xmm8, [rsp+0x70]
00007e4af17d69e1  vmovaps xmm9, [rsp+0x80]
00007e4af17d69ea  vmovaps xmm10, [rsp+0x90]
00007e4af17d69f3  vmovaps xmm11, [rsp+0xA0]
00007e4af17d69fc  vmovaps xmm12, [rsp+0xB0]
00007e4af17d6a05  vmovaps xmm13, [rsp+0xC0]
00007e4af17d6a0e  vmovaps xmm14, [rsp+0xD0]
00007e4af17d6a17  vmovaps xmm15, [rsp+0xE0]
00007e4af17d6a20  add rsp, 0xF0
00007e4af17d6a27  pop r11
00007e4af17d6a29  pop r10
00007e4af17d6a2b  pop r9
00007e4af17d6a2d  pop r8
00007e4af17d6a2f  pop rsi
00007e4af17d6a30  pop rdi
00007e4af17d6a31  pop rdx
00007e4af17d6a32  pop rcx
00007e4af17d6a33  pop rax
00007e4af17d6a34  add rsp, 0x08
00007e4af17d6a38  jmp 0x00007E4AF17D59C8
00007e4af17d6a3d  sub rsp, 0x08
00007e4af17d6a41  push rax
00007e4af17d6a42  push rcx
00007e4af17d6a43  push rdx
00007e4af17d6a44  push rdi
00007e4af17d6a45  push rsi
00007e4af17d6a46  push r8
00007e4af17d6a48  push r9
00007e4af17d6a4a  push r10
00007e4af17d6a4c  push r11
00007e4af17d6a4e  sub rsp, 0xF0
00007e4af17d6a55  vmovaps [rsp], xmm0
00007e4af17d6a5a  vmovaps [rsp+0x10], xmm1
00007e4af17d6a60  vmovaps [rsp+0x20], xmm2
00007e4af17d6a66  vmovaps [rsp+0x30], xmm3
00007e4af17d6a6c  vmovaps [rsp+0x40], xmm4
00007e4af17d6a72  vmovaps [rsp+0x50], xmm5
00007e4af17d6a78  vmovaps [rsp+0x60], xmm6
00007e4af17d6a7e  vmovaps [rsp+0x70], xmm7
00007e4af17d6a84  vmovaps [rsp+0x80], xmm8
00007e4af17d6a8d  vmovaps [rsp+0x90], xmm10
00007e4af17d6a96  vmovaps [rsp+0xA0], xmm11
00007e4af17d6a9f  vmovaps [rsp+0xB0], xmm12
00007e4af17d6aa8  vmovaps [rsp+0xC0], xmm13
00007e4af17d6ab1  vmovaps [rsp+0xD0], xmm14
00007e4af17d6aba  vmovaps [rsp+0xE0], xmm15
00007e4af17d6ac3  sub rsp, 0x30
00007e4af17d6ac7  movaps [rsp], xmm9
00007e4af17d6acc  movaps [rsp+0x10], xmm12
00007e4af17d6ad2  movaps [rsp+0x20], xmm10
00007e4af17d6ad8  lea rdi, [rsp]
00007e4af17d6adc  mov esi, 0x00
00007e4af17d6ae1  mov rax, 0x6256754A7530
00007e4af17d6aeb  call rax
00007e4af17d6aed  movaps xmm9, [rsp]
00007e4af17d6af2  add rsp, 0x30
00007e4af17d6af6  vmovaps xmm0, [rsp]
00007e4af17d6afb  vmovaps xmm1, [rsp+0x10]
00007e4af17d6b01  vmovaps xmm2, [rsp+0x20]
00007e4af17d6b07  vmovaps xmm3, [rsp+0x30]
00007e4af17d6b0d  vmovaps xmm4, [rsp+0x40]
00007e4af17d6b13  vmovaps xmm5, [rsp+0x50]
00007e4af17d6b19  vmovaps xmm6, [rsp+0x60]
00007e4af17d6b1f  vmovaps xmm7, [rsp+0x70]
00007e4af17d6b25  vmovaps xmm8, [rsp+0x80]
00007e4af17d6b2e  vmovaps xmm10, [rsp+0x90]
00007e4af17d6b37  vmovaps xmm11, [rsp+0xA0]
00007e4af17d6b40  vmovaps xmm12, [rsp+0xB0]
00007e4af17d6b49  vmovaps xmm13, [rsp+0xC0]
00007e4af17d6b52  vmovaps xmm14, [rsp+0xD0]
00007e4af17d6b5b  vmovaps xmm15, [rsp+0xE0]
00007e4af17d6b64  add rsp, 0xF0
00007e4af17d6b6b  pop r11
00007e4af17d6b6d  pop r10
00007e4af17d6b6f  pop r9
00007e4af17d6b71  pop r8
00007e4af17d6b73  pop rsi
00007e4af17d6b74  pop rdi
00007e4af17d6b75  pop rdx
00007e4af17d6b76  pop rcx
00007e4af17d6b77  pop rax
00007e4af17d6b78  add rsp, 0x08
00007e4af17d6b7c  jmp 0x00007E4AF17D59EC
00007e4af17d6b81  sub rsp, 0x08
00007e4af17d6b85  push rax
00007e4af17d6b86  push rcx
00007e4af17d6b87  push rdx
00007e4af17d6b88  push rdi
00007e4af17d6b89  push rsi
00007e4af17d6b8a  push r8
00007e4af17d6b8c  push r9
00007e4af17d6b8e  push r10
00007e4af17d6b90  push r11
00007e4af17d6b92  sub rsp, 0xF0
00007e4af17d6b99  vmovaps [rsp], xmm0
00007e4af17d6b9e  vmovaps [rsp+0x10], xmm1
00007e4af17d6ba4  vmovaps [rsp+0x20], xmm2
00007e4af17d6baa  vmovaps [rsp+0x30], xmm3
00007e4af17d6bb0  vmovaps [rsp+0x40], xmm4
00007e4af17d6bb6  vmovaps [rsp+0x50], xmm5
00007e4af17d6bbc  vmovaps [rsp+0x60], xmm6
00007e4af17d6bc2  vmovaps [rsp+0x70], xmm7
00007e4af17d6bc8  vmovaps [rsp+0x80], xmm8
00007e4af17d6bd1  vmovaps [rsp+0x90], xmm9
00007e4af17d6bda  vmovaps [rsp+0xA0], xmm11
00007e4af17d6be3  vmovaps [rsp+0xB0], xmm12
00007e4af17d6bec  vmovaps [rsp+0xC0], xmm13
00007e4af17d6bf5  vmovaps [rsp+0xD0], xmm14
00007e4af17d6bfe  vmovaps [rsp+0xE0], xmm15
00007e4af17d6c07  sub rsp, 0x30
00007e4af17d6c0b  movaps [rsp], xmm10
00007e4af17d6c10  movaps [rsp+0x10], xmm12
00007e4af17d6c16  movaps [rsp+0x20], xmm11
00007e4af17d6c1c  lea rdi, [rsp]
00007e4af17d6c20  mov esi, 0x00
00007e4af17d6c25  mov rax, 0x6256754A7530
00007e4af17d6c2f  call rax
00007e4af17d6c31  movaps xmm10, [rsp]
00007e4af17d6c36  add rsp, 0x30
00007e4af17d6c3a  vmovaps xmm0, [rsp]
00007e4af17d6c3f  vmovaps xmm1, [rsp+0x10]
00007e4af17d6c45  vmovaps xmm2, [rsp+0x20]
00007e4af17d6c4b  vmovaps xmm3, [rsp+0x30]
00007e4af17d6c51  vmovaps xmm4, [rsp+0x40]
00007e4af17d6c57  vmovaps xmm5, [rsp+0x50]
00007e4af17d6c5d  vmovaps xmm6, [rsp+0x60]
00007e4af17d6c63  vmovaps xmm7, [rsp+0x70]
00007e4af17d6c69  vmovaps xmm8, [rsp+0x80]
00007e4af17d6c72  vmovaps xmm9, [rsp+0x90]
00007e4af17d6c7b  vmovaps xmm11, [rsp+0xA0]
00007e4af17d6c84  vmovaps xmm12, [rsp+0xB0]
00007e4af17d6c8d  vmovaps xmm13, [rsp+0xC0]
00007e4af17d6c96  vmovaps xmm14, [rsp+0xD0]
00007e4af17d6c9f  vmovaps xmm15, [rsp+0xE0]
00007e4af17d6ca8  add rsp, 0xF0
00007e4af17d6caf  pop r11
00007e4af17d6cb1  pop r10
00007e4af17d6cb3  pop r9
00007e4af17d6cb5  pop r8
00007e4af17d6cb7  pop rsi
00007e4af17d6cb8  pop rdi
00007e4af17d6cb9  pop rdx
00007e4af17d6cba  pop rcx
00007e4af17d6cbb  pop rax
00007e4af17d6cbc  add rsp, 0x08
00007e4af17d6cc0  jmp 0x00007E4AF17D5A06
00007e4af17d6cc5  sub rsp, 0x08
00007e4af17d6cc9  push rax
00007e4af17d6cca  push rcx
00007e4af17d6ccb  push rdx
00007e4af17d6ccc  push rdi
00007e4af17d6ccd  push rsi
00007e4af17d6cce  push r8
00007e4af17d6cd0  push r9
00007e4af17d6cd2  push r10
00007e4af17d6cd4  push r11
00007e4af17d6cd6  sub rsp, 0xF0
00007e4af17d6cdd  vmovaps [rsp], xmm0
00007e4af17d6ce2  vmovaps [rsp+0x10], xmm1
00007e4af17d6ce8  vmovaps [rsp+0x20], xmm2
00007e4af17d6cee  vmovaps [rsp+0x30], xmm3
00007e4af17d6cf4  vmovaps [rsp+0x40], xmm4
00007e4af17d6cfa  vmovaps [rsp+0x50], xmm5
00007e4af17d6d00  vmovaps [rsp+0x60], xmm7
00007e4af17d6d06  vmovaps [rsp+0x70], xmm8
00007e4af17d6d0c  vmovaps [rsp+0x80], xmm9
00007e4af17d6d15  vmovaps [rsp+0x90], xmm10
00007e4af17d6d1e  vmovaps [rsp+0xA0], xmm11
00007e4af17d6d27  vmovaps [rsp+0xB0], xmm12
00007e4af17d6d30  vmovaps [rsp+0xC0], xmm13
00007e4af17d6d39  vmovaps [rsp+0xD0], xmm14
00007e4af17d6d42  vmovaps [rsp+0xE0], xmm15
00007e4af17d6d4b  sub rsp, 0x30
00007e4af17d6d4f  movaps [rsp], xmm6
00007e4af17d6d53  movaps [rsp+0x10], xmm12
00007e4af17d6d59  movaps [rsp+0x20], xmm11
00007e4af17d6d5f  lea rdi, [rsp]
00007e4af17d6d63  mov esi, 0x00
00007e4af17d6d68  mov rax, 0x6256754A7530
00007e4af17d6d72  call rax
00007e4af17d6d74  movaps xmm6, [rsp]
00007e4af17d6d78  add rsp, 0x30
00007e4af17d6d7c  vmovaps xmm0, [rsp]
00007e4af17d6d81  vmovaps xmm1, [rsp+0x10]
00007e4af17d6d87  vmovaps xmm2, [rsp+0x20]
00007e4af17d6d8d  vmovaps xmm3, [rsp+0x30]
00007e4af17d6d93  vmovaps xmm4, [rsp+0x40]
00007e4af17d6d99  vmovaps xmm5, [rsp+0x50]
00007e4af17d6d9f  vmovaps xmm7, [rsp+0x60]
00007e4af17d6da5  vmovaps xmm8, [rsp+0x70]
00007e4af17d6dab  vmovaps xmm9, [rsp+0x80]
00007e4af17d6db4  vmovaps xmm10, [rsp+0x90]
00007e4af17d6dbd  vmovaps xmm11, [rsp+0xA0]
00007e4af17d6dc6  vmovaps xmm12, [rsp+0xB0]
00007e4af17d6dcf  vmovaps xmm13, [rsp+0xC0]
00007e4af17d6dd8  vmovaps xmm14, [rsp+0xD0]
00007e4af17d6de1  vmovaps xmm15, [rsp+0xE0]
00007e4af17d6dea  add rsp, 0xF0
00007e4af17d6df1  pop r11
00007e4af17d6df3  pop r10
00007e4af17d6df5  pop r9
00007e4af17d6df7  pop r8
00007e4af17d6df9  pop rsi
00007e4af17d6dfa  pop rdi
00007e4af17d6dfb  pop rdx
00007e4af17d6dfc  pop rcx
00007e4af17d6dfd  pop rax
00007e4af17d6dfe  add rsp, 0x08
00007e4af17d6e02  jmp 0x00007E4AF17D5A27
00007e4af17d6e07  sub rsp, 0x08
00007e4af17d6e0b  push rax
00007e4af17d6e0c  push rcx
00007e4af17d6e0d  push rdx
00007e4af17d6e0e  push rdi
00007e4af17d6e0f  push rsi
00007e4af17d6e10  push r8
00007e4af17d6e12  push r9
00007e4af17d6e14  push r10
00007e4af17d6e16  push r11
00007e4af17d6e18  sub rsp, 0xF0
00007e4af17d6e1f  vmovaps [rsp], xmm0
00007e4af17d6e24  vmovaps [rsp+0x10], xmm1
00007e4af17d6e2a  vmovaps [rsp+0x20], xmm2
00007e4af17d6e30  vmovaps [rsp+0x30], xmm4
00007e4af17d6e36  vmovaps [rsp+0x40], xmm5
00007e4af17d6e3c  vmovaps [rsp+0x50], xmm6
00007e4af17d6e42  vmovaps [rsp+0x60], xmm7
00007e4af17d6e48  vmovaps [rsp+0x70], xmm8
00007e4af17d6e4e  vmovaps [rsp+0x80], xmm9
00007e4af17d6e57  vmovaps [rsp+0x90], xmm10
00007e4af17d6e60  vmovaps [rsp+0xA0], xmm11
00007e4af17d6e69  vmovaps [rsp+0xB0], xmm12
00007e4af17d6e72  vmovaps [rsp+0xC0], xmm13
00007e4af17d6e7b  vmovaps [rsp+0xD0], xmm14
00007e4af17d6e84  vmovaps [rsp+0xE0], xmm15
00007e4af17d6e8d  sub rsp, 0x30
00007e4af17d6e91  movaps [rsp], xmm3
00007e4af17d6e95  movaps [rsp+0x10], xmm5
00007e4af17d6e9a  movaps [rsp+0x20], xmm4
00007e4af17d6e9f  lea rdi, [rsp]
00007e4af17d6ea3  mov esi, 0x00
00007e4af17d6ea8  mov rax, 0x6256754A7530
00007e4af17d6eb2  call rax
00007e4af17d6eb4  movaps xmm3, [rsp]
00007e4af17d6eb8  add rsp, 0x30
00007e4af17d6ebc  vmovaps xmm0, [rsp]
00007e4af17d6ec1  vmovaps xmm1, [rsp+0x10]
00007e4af17d6ec7  vmovaps xmm2, [rsp+0x20]
00007e4af17d6ecd  vmovaps xmm4, [rsp+0x30]
00007e4af17d6ed3  vmovaps xmm5, [rsp+0x40]
00007e4af17d6ed9  vmovaps xmm6, [rsp+0x50]
00007e4af17d6edf  vmovaps xmm7, [rsp+0x60]
00007e4af17d6ee5  vmovaps xmm8, [rsp+0x70]
00007e4af17d6eeb  vmovaps xmm9, [rsp+0x80]
00007e4af17d6ef4  vmovaps xmm10, [rsp+0x90]
00007e4af17d6efd  vmovaps xmm11, [rsp+0xA0]
00007e4af17d6f06  vmovaps xmm12, [rsp+0xB0]
00007e4af17d6f0f  vmovaps xmm13, [rsp+0xC0]
00007e4af17d6f18  vmovaps xmm14, [rsp+0xD0]
00007e4af17d6f21  vmovaps xmm15, [rsp+0xE0]
00007e4af17d6f2a  add rsp, 0xF0
00007e4af17d6f31  pop r11
00007e4af17d6f33  pop r10
00007e4af17d6f35  pop r9
00007e4af17d6f37  pop r8
00007e4af17d6f39  pop rsi
00007e4af17d6f3a  pop rdi
00007e4af17d6f3b  pop rdx
00007e4af17d6f3c  pop rcx
00007e4af17d6f3d  pop rax
00007e4af17d6f3e  add rsp, 0x08
00007e4af17d6f42  jmp 0x00007E4AF17D5A88
00007e4af17d6f47  sub rsp, 0x08
00007e4af17d6f4b  push rax
00007e4af17d6f4c  push rcx
00007e4af17d6f4d  push rdx
00007e4af17d6f4e  push rdi
00007e4af17d6f4f  push rsi
00007e4af17d6f50  push r8
00007e4af17d6f52  push r9
00007e4af17d6f54  push r10
00007e4af17d6f56  push r11
00007e4af17d6f58  sub rsp, 0xF0
00007e4af17d6f5f  vmovaps [rsp], xmm0
00007e4af17d6f64  vmovaps [rsp+0x10], xmm1
00007e4af17d6f6a  vmovaps [rsp+0x20], xmm2
00007e4af17d6f70  vmovaps [rsp+0x30], xmm3
00007e4af17d6f76  vmovaps [rsp+0x40], xmm4
00007e4af17d6f7c  vmovaps [rsp+0x50], xmm6
00007e4af17d6f82  vmovaps [rsp+0x60], xmm7
00007e4af17d6f88  vmovaps [rsp+0x70], xmm8
00007e4af17d6f8e  vmovaps [rsp+0x80], xmm9
00007e4af17d6f97  vmovaps [rsp+0x90], xmm10
00007e4af17d6fa0  vmovaps [rsp+0xA0], xmm11
00007e4af17d6fa9  vmovaps [rsp+0xB0], xmm12
00007e4af17d6fb2  vmovaps [rsp+0xC0], xmm13
00007e4af17d6fbb  vmovaps [rsp+0xD0], xmm14
00007e4af17d6fc4  vmovaps [rsp+0xE0], xmm15
00007e4af17d6fcd  sub rsp, 0x30
00007e4af17d6fd1  movaps [rsp], xmm5
00007e4af17d6fd5  movaps [rsp+0x10], xmm8
00007e4af17d6fdb  movaps [rsp+0x20], xmm15
00007e4af17d6fe1  lea rdi, [rsp]
00007e4af17d6fe5  mov esi, 0x00
00007e4af17d6fea  mov rax, 0x6256754A7530
00007e4af17d6ff4  call rax
00007e4af17d6ff6  movaps xmm5, [rsp]
00007e4af17d6ffa  add rsp, 0x30
00007e4af17d6ffe  vmovaps xmm0, [rsp]
00007e4af17d7003  vmovaps xmm1, [rsp+0x10]
00007e4af17d7009  vmovaps xmm2, [rsp+0x20]
00007e4af17d700f  vmovaps xmm3, [rsp+0x30]
00007e4af17d7015  vmovaps xmm4, [rsp+0x40]
00007e4af17d701b  vmovaps xmm6, [rsp+0x50]
00007e4af17d7021  vmovaps xmm7, [rsp+0x60]
00007e4af17d7027  vmovaps xmm8, [rsp+0x70]
00007e4af17d702d  vmovaps xmm9, [rsp+0x80]
00007e4af17d7036  vmovaps xmm10, [rsp+0x90]
00007e4af17d703f  vmovaps xmm11, [rsp+0xA0]
00007e4af17d7048  vmovaps xmm12, [rsp+0xB0]
00007e4af17d7051  vmovaps xmm13, [rsp+0xC0]
00007e4af17d705a  vmovaps xmm14, [rsp+0xD0]
00007e4af17d7063  vmovaps xmm15, [rsp+0xE0]
00007e4af17d706c  add rsp, 0xF0
00007e4af17d7073  pop r11
00007e4af17d7075  pop r10
00007e4af17d7077  pop r9
00007e4af17d7079  pop r8
00007e4af17d707b  pop rsi
00007e4af17d707c  pop rdi
00007e4af17d707d  pop rdx
00007e4af17d707e  pop rcx
00007e4af17d707f  pop rax
00007e4af17d7080  add rsp, 0x08
00007e4af17d7084  jmp 0x00007E4AF17D5AC0
00007e4af17d7089  sub rsp, 0x08
00007e4af17d708d  push rax
00007e4af17d708e  push rcx
00007e4af17d708f  push rdx
00007e4af17d7090  push rdi
00007e4af17d7091  push rsi
00007e4af17d7092  push r8
00007e4af17d7094  push r9
00007e4af17d7096  push r10
00007e4af17d7098  push r11
00007e4af17d709a  sub rsp, 0xF0
00007e4af17d70a1  vmovaps [rsp], xmm0
00007e4af17d70a6  vmovaps [rsp+0x10], xmm1
00007e4af17d70ac  vmovaps [rsp+0x20], xmm2
00007e4af17d70b2  vmovaps [rsp+0x30], xmm3
00007e4af17d70b8  vmovaps [rsp+0x40], xmm5
00007e4af17d70be  vmovaps [rsp+0x50], xmm6
00007e4af17d70c4  vmovaps [rsp+0x60], xmm7
00007e4af17d70ca  vmovaps [rsp+0x70], xmm8
00007e4af17d70d0  vmovaps [rsp+0x80], xmm9
00007e4af17d70d9  vmovaps [rsp+0x90], xmm10
00007e4af17d70e2  vmovaps [rsp+0xA0], xmm11
00007e4af17d70eb  vmovaps [rsp+0xB0], xmm12
00007e4af17d70f4  vmovaps [rsp+0xC0], xmm13
00007e4af17d70fd  vmovaps [rsp+0xD0], xmm14
00007e4af17d7106  vmovaps [rsp+0xE0], xmm15
00007e4af17d710f  sub rsp, 0x30
00007e4af17d7113  movaps [rsp], xmm4
00007e4af17d7117  movaps [rsp+0x10], xmm9
00007e4af17d711d  movaps [rsp+0x20], xmm8
00007e4af17d7123  lea rdi, [rsp]
00007e4af17d7127  mov esi, 0x00
00007e4af17d712c  mov rax, 0x6256754A7530
00007e4af17d7136  call rax
00007e4af17d7138  movaps xmm4, [rsp]
00007e4af17d713c  add rsp, 0x30
00007e4af17d7140  vmovaps xmm0, [rsp]
00007e4af17d7145  vmovaps xmm1, [rsp+0x10]
00007e4af17d714b  vmovaps xmm2, [rsp+0x20]
00007e4af17d7151  vmovaps xmm3, [rsp+0x30]
00007e4af17d7157  vmovaps xmm5, [rsp+0x40]
00007e4af17d715d  vmovaps xmm6, [rsp+0x50]
00007e4af17d7163  vmovaps xmm7, [rsp+0x60]
00007e4af17d7169  vmovaps xmm8, [rsp+0x70]
00007e4af17d716f  vmovaps xmm9, [rsp+0x80]
00007e4af17d7178  vmovaps xmm10, [rsp+0x90]
00007e4af17d7181  vmovaps xmm11, [rsp+0xA0]
00007e4af17d718a  vmovaps xmm12, [rsp+0xB0]
00007e4af17d7193  vmovaps xmm13, [rsp+0xC0]
00007e4af17d719c  vmovaps xmm14, [rsp+0xD0]
00007e4af17d71a5  vmovaps xmm15, [rsp+0xE0]
00007e4af17d71ae  add rsp, 0xF0
00007e4af17d71b5  pop r11
00007e4af17d71b7  pop r10
00007e4af17d71b9  pop r9
00007e4af17d71bb  pop r8
00007e4af17d71bd  pop rsi
00007e4af17d71be  pop rdi
00007e4af17d71bf  pop rdx
00007e4af17d71c0  pop rcx
00007e4af17d71c1  pop rax
00007e4af17d71c2  add rsp, 0x08
00007e4af17d71c6  jmp 0x00007E4AF17D5AE1
00007e4af17d71cb  sub rsp, 0x08
00007e4af17d71cf  push rax
00007e4af17d71d0  push rcx
00007e4af17d71d1  push rdx
00007e4af17d71d2  push rdi
00007e4af17d71d3  push rsi
00007e4af17d71d4  push r8
00007e4af17d71d6  push r9
00007e4af17d71d8  push r10
00007e4af17d71da  push r11
00007e4af17d71dc  sub rsp, 0xF0
00007e4af17d71e3  vmovaps [rsp], xmm0
00007e4af17d71e8  vmovaps [rsp+0x10], xmm1
00007e4af17d71ee  vmovaps [rsp+0x20], xmm2
00007e4af17d71f4  vmovaps [rsp+0x30], xmm3
00007e4af17d71fa  vmovaps [rsp+0x40], xmm4
00007e4af17d7200  vmovaps [rsp+0x50], xmm5
00007e4af17d7206  vmovaps [rsp+0x60], xmm6
00007e4af17d720c  vmovaps [rsp+0x70], xmm7
00007e4af17d7212  vmovaps [rsp+0x80], xmm8
00007e4af17d721b  vmovaps [rsp+0x90], xmm10
00007e4af17d7224  vmovaps [rsp+0xA0], xmm11
00007e4af17d722d  vmovaps [rsp+0xB0], xmm12
00007e4af17d7236  vmovaps [rsp+0xC0], xmm13
00007e4af17d723f  vmovaps [rsp+0xD0], xmm14
00007e4af17d7248  vmovaps [rsp+0xE0], xmm15
00007e4af17d7251  sub rsp, 0x30
00007e4af17d7255  movaps [rsp], xmm9
00007e4af17d725a  movaps [rsp+0x10], xmm10
00007e4af17d7260  movaps [rsp+0x20], xmm8
00007e4af17d7266  lea rdi, [rsp]
00007e4af17d726a  mov esi, 0x00
00007e4af17d726f  mov rax, 0x6256754A7530
00007e4af17d7279  call rax
00007e4af17d727b  movaps xmm9, [rsp]
00007e4af17d7280  add rsp, 0x30
00007e4af17d7284  vmovaps xmm0, [rsp]
00007e4af17d7289  vmovaps xmm1, [rsp+0x10]
00007e4af17d728f  vmovaps xmm2, [rsp+0x20]
00007e4af17d7295  vmovaps xmm3, [rsp+0x30]
00007e4af17d729b  vmovaps xmm4, [rsp+0x40]
00007e4af17d72a1  vmovaps xmm5, [rsp+0x50]
00007e4af17d72a7  vmovaps xmm6, [rsp+0x60]
00007e4af17d72ad  vmovaps xmm7, [rsp+0x70]
00007e4af17d72b3  vmovaps xmm8, [rsp+0x80]
00007e4af17d72bc  vmovaps xmm10, [rsp+0x90]
00007e4af17d72c5  vmovaps xmm11, [rsp+0xA0]
00007e4af17d72ce  vmovaps xmm12, [rsp+0xB0]
00007e4af17d72d7  vmovaps xmm13, [rsp+0xC0]
00007e4af17d72e0  vmovaps xmm14, [rsp+0xD0]
00007e4af17d72e9  vmovaps xmm15, [rsp+0xE0]
00007e4af17d72f2  add rsp, 0xF0
00007e4af17d72f9  pop r11
00007e4af17d72fb  pop r10
00007e4af17d72fd  pop r9
00007e4af17d72ff  pop r8
00007e4af17d7301  pop rsi
00007e4af17d7302  pop rdi
00007e4af17d7303  pop rdx
00007e4af17d7304  pop rcx
00007e4af17d7305  pop rax
00007e4af17d7306  add rsp, 0x08
00007e4af17d730a  jmp 0x00007E4AF17D5AFB
00007e4af17d730f  call 0x00007E4AF16D64F0
00007e4af17d7314  jmp 0x00007E4AF17D5C15
00007e4af17d7319  call 0x00007E4AF16D64F0
00007e4af17d731e  jmp 0x00007E4AF17D5C2B
00007e4af17d7323  sub rsp, 0x08
00007e4af17d7327  push rax
00007e4af17d7328  push rcx
00007e4af17d7329  push rdx
00007e4af17d732a  push rdi
00007e4af17d732b  push rsi
00007e4af17d732c  push r8
00007e4af17d732e  push r9
00007e4af17d7330  push r10
00007e4af17d7332  push r11
00007e4af17d7334  sub rsp, 0xF0
00007e4af17d733b  vmovaps [rsp], xmm0
00007e4af17d7340  vmovaps [rsp+0x10], xmm2
00007e4af17d7346  vmovaps [rsp+0x20], xmm3
00007e4af17d734c  vmovaps [rsp+0x30], xmm4
00007e4af17d7352  vmovaps [rsp+0x40], xmm5
00007e4af17d7358  vmovaps [rsp+0x50], xmm6
00007e4af17d735e  vmovaps [rsp+0x60], xmm7
00007e4af17d7364  vmovaps [rsp+0x70], xmm8
00007e4af17d736a  vmovaps [rsp+0x80], xmm9
00007e4af17d7373  vmovaps [rsp+0x90], xmm10
00007e4af17d737c  vmovaps [rsp+0xA0], xmm11
00007e4af17d7385  vmovaps [rsp+0xB0], xmm12
00007e4af17d738e  vmovaps [rsp+0xC0], xmm13
00007e4af17d7397  vmovaps [rsp+0xD0], xmm14
00007e4af17d73a0  vmovaps [rsp+0xE0], xmm15
00007e4af17d73a9  sub rsp, 0x30
00007e4af17d73ad  movaps [rsp], xmm1
00007e4af17d73b1  movaps [rsp+0x10], xmm6
00007e4af17d73b6  movaps [rsp+0x20], xmm15
00007e4af17d73bc  lea rdi, [rsp]
00007e4af17d73c0  mov esi, 0x00
00007e4af17d73c5  mov rax, 0x6256754A7530
00007e4af17d73cf  call rax
00007e4af17d73d1  movaps xmm1, [rsp]
00007e4af17d73d5  add rsp, 0x30
00007e4af17d73d9  vmovaps xmm0, [rsp]
00007e4af17d73de  vmovaps xmm2, [rsp+0x10]
00007e4af17d73e4  vmovaps xmm3, [rsp+0x20]
00007e4af17d73ea  vmovaps xmm4, [rsp+0x30]
00007e4af17d73f0  vmovaps xmm5, [rsp+0x40]
00007e4af17d73f6  vmovaps xmm6, [rsp+0x50]
00007e4af17d73fc  vmovaps xmm7, [rsp+0x60]
00007e4af17d7402  vmovaps xmm8, [rsp+0x70]
00007e4af17d7408  vmovaps xmm9, [rsp+0x80]
00007e4af17d7411  vmovaps xmm10, [rsp+0x90]
00007e4af17d741a  vmovaps xmm11, [rsp+0xA0]
00007e4af17d7423  vmovaps xmm12, [rsp+0xB0]
00007e4af17d742c  vmovaps xmm13, [rsp+0xC0]
00007e4af17d7435  vmovaps xmm14, [rsp+0xD0]
00007e4af17d743e  vmovaps xmm15, [rsp+0xE0]
00007e4af17d7447  add rsp, 0xF0
00007e4af17d744e  pop r11
00007e4af17d7450  pop r10
00007e4af17d7452  pop r9
00007e4af17d7454  pop r8
00007e4af17d7456  pop rsi
00007e4af17d7457  pop rdi
00007e4af17d7458  pop rdx
00007e4af17d7459  pop rcx
00007e4af17d745a  pop rax
00007e4af17d745b  add rsp, 0x08
00007e4af17d745f  jmp 0x00007E4AF17D5C68
00007e4af17d7464  call 0x00007E4AF16E5820
00007e4af17d7469  jmp 0x00007E4AF17D5C75
00007e4af17d746e  sub rsp, 0x08
00007e4af17d7472  push rax
00007e4af17d7473  push rcx
00007e4af17d7474  push rdx
00007e4af17d7475  push rdi
00007e4af17d7476  push rsi
00007e4af17d7477  push r8
00007e4af17d7479  push r9
00007e4af17d747b  push r10
00007e4af17d747d  push r11
00007e4af17d747f  sub rsp, 0xF0
00007e4af17d7486  vmovaps [rsp], xmm0
00007e4af17d748b  vmovaps [rsp+0x10], xmm1
00007e4af17d7491  vmovaps [rsp+0x20], xmm2
00007e4af17d7497  vmovaps [rsp+0x30], xmm3
00007e4af17d749d  vmovaps [rsp+0x40], xmm4
00007e4af17d74a3  vmovaps [rsp+0x50], xmm5
00007e4af17d74a9  vmovaps [rsp+0x60], xmm6
00007e4af17d74af  vmovaps [rsp+0x70], xmm7
00007e4af17d74b5  vmovaps [rsp+0x80], xmm8
00007e4af17d74be  vmovaps [rsp+0x90], xmm9
00007e4af17d74c7  vmovaps [rsp+0xA0], xmm10
00007e4af17d74d0  vmovaps [rsp+0xB0], xmm11
00007e4af17d74d9  vmovaps [rsp+0xC0], xmm12
00007e4af17d74e2  vmovaps [rsp+0xD0], xmm13
00007e4af17d74eb  vmovaps [rsp+0xE0], xmm15
00007e4af17d74f4  sub rsp, 0x30
00007e4af17d74f8  movaps [rsp], xmm14
00007e4af17d74fd  movaps [rsp+0x10], xmm4
00007e4af17d7502  movaps [rsp+0x20], xmm3
00007e4af17d7507  lea rdi, [rsp]
00007e4af17d750b  mov esi, 0x00
00007e4af17d7510  mov rax, 0x6256754A7530
00007e4af17d751a  call rax
00007e4af17d751c  movaps xmm14, [rsp]
00007e4af17d7521  add rsp, 0x30
00007e4af17d7525  vmovaps xmm0, [rsp]
00007e4af17d752a  vmovaps xmm1, [rsp+0x10]
00007e4af17d7530  vmovaps xmm2, [rsp+0x20]
00007e4af17d7536  vmovaps xmm3, [rsp+0x30]
00007e4af17d753c  vmovaps xmm4, [rsp+0x40]
00007e4af17d7542  vmovaps xmm5, [rsp+0x50]
00007e4af17d7548  vmovaps xmm6, [rsp+0x60]
00007e4af17d754e  vmovaps xmm7, [rsp+0x70]
00007e4af17d7554  vmovaps xmm8, [rsp+0x80]
00007e4af17d755d  vmovaps xmm9, [rsp+0x90]
00007e4af17d7566  vmovaps xmm10, [rsp+0xA0]
00007e4af17d756f  vmovaps xmm11, [rsp+0xB0]
00007e4af17d7578  vmovaps xmm12, [rsp+0xC0]
00007e4af17d7581  vmovaps xmm13, [rsp+0xD0]
00007e4af17d758a  vmovaps xmm15, [rsp+0xE0]
00007e4af17d7593  add rsp, 0xF0
00007e4af17d759a  pop r11
00007e4af17d759c  pop r10
00007e4af17d759e  pop r9
00007e4af17d75a0  pop r8
00007e4af17d75a2  pop rsi
00007e4af17d75a3  pop rdi
00007e4af17d75a4  pop rdx
00007e4af17d75a5  pop rcx
00007e4af17d75a6  pop rax
00007e4af17d75a7  add rsp, 0x08
00007e4af17d75ab  jmp 0x00007E4AF17D5C8F
00007e4af17d75b0  sub rsp, 0x08
00007e4af17d75b4  push rax
00007e4af17d75b5  push rcx
00007e4af17d75b6  push rdx
00007e4af17d75b7  push rdi
00007e4af17d75b8  push rsi
00007e4af17d75b9  push r8
00007e4af17d75bb  push r9
00007e4af17d75bd  push r10
00007e4af17d75bf  push r11
00007e4af17d75c1  sub rsp, 0xF0
00007e4af17d75c8  vmovaps [rsp], xmm0
00007e4af17d75cd  vmovaps [rsp+0x10], xmm1
00007e4af17d75d3  vmovaps [rsp+0x20], xmm2
00007e4af17d75d9  vmovaps [rsp+0x30], xmm3
00007e4af17d75df  vmovaps [rsp+0x40], xmm4
00007e4af17d75e5  vmovaps [rsp+0x50], xmm5
00007e4af17d75eb  vmovaps [rsp+0x60], xmm7
00007e4af17d75f1  vmovaps [rsp+0x70], xmm8
00007e4af17d75f7  vmovaps [rsp+0x80], xmm9
00007e4af17d7600  vmovaps [rsp+0x90], xmm10
00007e4af17d7609  vmovaps [rsp+0xA0], xmm11
00007e4af17d7612  vmovaps [rsp+0xB0], xmm12
00007e4af17d761b  vmovaps [rsp+0xC0], xmm13
00007e4af17d7624  vmovaps [rsp+0xD0], xmm14
00007e4af17d762d  vmovaps [rsp+0xE0], xmm15
00007e4af17d7636  sub rsp, 0x30
00007e4af17d763a  movaps [rsp], xmm6
00007e4af17d763e  movaps [rsp+0x10], xmm9
00007e4af17d7644  movaps [rsp+0x20], xmm7
00007e4af17d7649  lea rdi, [rsp]
00007e4af17d764d  mov esi, 0x00
00007e4af17d7652  mov rax, 0x6256754A7530
00007e4af17d765c  call rax
00007e4af17d765e  movaps xmm6, [rsp]
00007e4af17d7662  add rsp, 0x30
00007e4af17d7666  vmovaps xmm0, [rsp]
00007e4af17d766b  vmovaps xmm1, [rsp+0x10]
00007e4af17d7671  vmovaps xmm2, [rsp+0x20]
00007e4af17d7677  vmovaps xmm3, [rsp+0x30]
00007e4af17d767d  vmovaps xmm4, [rsp+0x40]
00007e4af17d7683  vmovaps xmm5, [rsp+0x50]
00007e4af17d7689  vmovaps xmm7, [rsp+0x60]
00007e4af17d768f  vmovaps xmm8, [rsp+0x70]
00007e4af17d7695  vmovaps xmm9, [rsp+0x80]
00007e4af17d769e  vmovaps xmm10, [rsp+0x90]
00007e4af17d76a7  vmovaps xmm11, [rsp+0xA0]
00007e4af17d76b0  vmovaps xmm12, [rsp+0xB0]
00007e4af17d76b9  vmovaps xmm13, [rsp+0xC0]
00007e4af17d76c2  vmovaps xmm14, [rsp+0xD0]
00007e4af17d76cb  vmovaps xmm15, [rsp+0xE0]
00007e4af17d76d4  add rsp, 0xF0
00007e4af17d76db  pop r11
00007e4af17d76dd  pop r10
00007e4af17d76df  pop r9
00007e4af17d76e1  pop r8
00007e4af17d76e3  pop rsi
00007e4af17d76e4  pop rdi
00007e4af17d76e5  pop rdx
00007e4af17d76e6  pop rcx
00007e4af17d76e7  pop rax
00007e4af17d76e8  add rsp, 0x08
00007e4af17d76ec  jmp 0x00007E4AF17D5CA7
00007e4af17d76f1  sub rsp, 0x08
00007e4af17d76f5  push rax
00007e4af17d76f6  push rcx
00007e4af17d76f7  push rdx
00007e4af17d76f8  push rdi
00007e4af17d76f9  push rsi
00007e4af17d76fa  push r8
00007e4af17d76fc  push r9
00007e4af17d76fe  push r10
00007e4af17d7700  push r11
00007e4af17d7702  sub rsp, 0xF0
00007e4af17d7709  vmovaps [rsp], xmm0
00007e4af17d770e  vmovaps [rsp+0x10], xmm1
00007e4af17d7714  vmovaps [rsp+0x20], xmm2
00007e4af17d771a  vmovaps [rsp+0x30], xmm3
00007e4af17d7720  vmovaps [rsp+0x40], xmm4
00007e4af17d7726  vmovaps [rsp+0x50], xmm5
00007e4af17d772c  vmovaps [rsp+0x60], xmm6
00007e4af17d7732  vmovaps [rsp+0x70], xmm8
00007e4af17d7738  vmovaps [rsp+0x80], xmm9
00007e4af17d7741  vmovaps [rsp+0x90], xmm10
00007e4af17d774a  vmovaps [rsp+0xA0], xmm11
00007e4af17d7753  vmovaps [rsp+0xB0], xmm12
00007e4af17d775c  vmovaps [rsp+0xC0], xmm13
00007e4af17d7765  vmovaps [rsp+0xD0], xmm14
00007e4af17d776e  vmovaps [rsp+0xE0], xmm15
00007e4af17d7777  sub rsp, 0x30
00007e4af17d777b  movaps [rsp], xmm7
00007e4af17d777f  movaps [rsp+0x10], xmm4
00007e4af17d7784  movaps [rsp+0x20], xmm9
00007e4af17d778a  lea rdi, [rsp]
00007e4af17d778e  mov esi, 0x00
00007e4af17d7793  mov rax, 0x6256754A7530
00007e4af17d779d  call rax
00007e4af17d779f  movaps xmm7, [rsp]
00007e4af17d77a3  add rsp, 0x30
00007e4af17d77a7  vmovaps xmm0, [rsp]
00007e4af17d77ac  vmovaps xmm1, [rsp+0x10]
00007e4af17d77b2  vmovaps xmm2, [rsp+0x20]
00007e4af17d77b8  vmovaps xmm3, [rsp+0x30]
00007e4af17d77be  vmovaps xmm4, [rsp+0x40]
00007e4af17d77c4  vmovaps xmm5, [rsp+0x50]
00007e4af17d77ca  vmovaps xmm6, [rsp+0x60]
00007e4af17d77d0  vmovaps xmm8, [rsp+0x70]
00007e4af17d77d6  vmovaps xmm9, [rsp+0x80]
00007e4af17d77df  vmovaps xmm10, [rsp+0x90]
00007e4af17d77e8  vmovaps xmm11, [rsp+0xA0]
00007e4af17d77f1  vmovaps xmm12, [rsp+0xB0]
00007e4af17d77fa  vmovaps xmm13, [rsp+0xC0]
00007e4af17d7803  vmovaps xmm14, [rsp+0xD0]
00007e4af17d780c  vmovaps xmm15, [rsp+0xE0]
00007e4af17d7815  add rsp, 0xF0
00007e4af17d781c  pop r11
00007e4af17d781e  pop r10
00007e4af17d7820  pop r9
00007e4af17d7822  pop r8
00007e4af17d7824  pop rsi
00007e4af17d7825  pop rdi
00007e4af17d7826  pop rdx
00007e4af17d7827  pop rcx
00007e4af17d7828  pop rax
00007e4af17d7829  add rsp, 0x08
00007e4af17d782d  jmp 0x00007E4AF17D5CD4
00007e4af17d7832  sub rsp, 0x08
00007e4af17d7836  push rax
00007e4af17d7837  push rcx
00007e4af17d7838  push rdx
00007e4af17d7839  push rdi
00007e4af17d783a  push rsi
00007e4af17d783b  push r8
00007e4af17d783d  push r9
00007e4af17d783f  push r10
00007e4af17d7841  push r11
00007e4af17d7843  sub rsp, 0xF0
00007e4af17d784a  vmovaps [rsp], xmm0
00007e4af17d784f  vmovaps [rsp+0x10], xmm1
00007e4af17d7855  vmovaps [rsp+0x20], xmm2
00007e4af17d785b  vmovaps [rsp+0x30], xmm3
00007e4af17d7861  vmovaps [rsp+0x40], xmm5
00007e4af17d7867  vmovaps [rsp+0x50], xmm6
00007e4af17d786d  vmovaps [rsp+0x60], xmm7
00007e4af17d7873  vmovaps [rsp+0x70], xmm8
00007e4af17d7879  vmovaps [rsp+0x80], xmm9
00007e4af17d7882  vmovaps [rsp+0x90], xmm10
00007e4af17d788b  vmovaps [rsp+0xA0], xmm11
00007e4af17d7894  vmovaps [rsp+0xB0], xmm12
00007e4af17d789d  vmovaps [rsp+0xC0], xmm13
00007e4af17d78a6  vmovaps [rsp+0xD0], xmm14
00007e4af17d78af  vmovaps [rsp+0xE0], xmm15
00007e4af17d78b8  sub rsp, 0x30
00007e4af17d78bc  movaps [rsp], xmm4
00007e4af17d78c0  movaps [rsp+0x10], xmm15
00007e4af17d78c6  movaps [rsp+0x20], xmm9
00007e4af17d78cc  lea rdi, [rsp]
00007e4af17d78d0  mov esi, 0x00
00007e4af17d78d5  mov rax, 0x6256754A7530
00007e4af17d78df  call rax
00007e4af17d78e1  movaps xmm4, [rsp]
00007e4af17d78e5  add rsp, 0x30
00007e4af17d78e9  vmovaps xmm0, [rsp]
00007e4af17d78ee  vmovaps xmm1, [rsp+0x10]
00007e4af17d78f4  vmovaps xmm2, [rsp+0x20]
00007e4af17d78fa  vmovaps xmm3, [rsp+0x30]
00007e4af17d7900  vmovaps xmm5, [rsp+0x40]
00007e4af17d7906  vmovaps xmm6, [rsp+0x50]
00007e4af17d790c  vmovaps xmm7, [rsp+0x60]
00007e4af17d7912  vmovaps xmm8, [rsp+0x70]
00007e4af17d7918  vmovaps xmm9, [rsp+0x80]
00007e4af17d7921  vmovaps xmm10, [rsp+0x90]
00007e4af17d792a  vmovaps xmm11, [rsp+0xA0]
00007e4af17d7933  vmovaps xmm12, [rsp+0xB0]
00007e4af17d793c  vmovaps xmm13, [rsp+0xC0]
00007e4af17d7945  vmovaps xmm14, [rsp+0xD0]
00007e4af17d794e  vmovaps xmm15, [rsp+0xE0]
00007e4af17d7957  add rsp, 0xF0
00007e4af17d795e  pop r11
00007e4af17d7960  pop r10
00007e4af17d7962  pop r9
00007e4af17d7964  pop r8
00007e4af17d7966  pop rsi
00007e4af17d7967  pop rdi
00007e4af17d7968  pop rdx
00007e4af17d7969  pop rcx
00007e4af17d796a  pop rax
00007e4af17d796b  add rsp, 0x08
00007e4af17d796f  jmp 0x00007E4AF17D5CF9
00007e4af17d7974  call 0x00007E4AF16E5820
00007e4af17d7979  jmp 0x00007E4AF17D5D06
00007e4af17d797e  sub rsp, 0x08
00007e4af17d7982  push rax
00007e4af17d7983  push rcx
00007e4af17d7984  push rdx
00007e4af17d7985  push rdi
00007e4af17d7986  push rsi
00007e4af17d7987  push r8
00007e4af17d7989  push r9
00007e4af17d798b  push r10
00007e4af17d798d  push r11
00007e4af17d798f  sub rsp, 0xF0
00007e4af17d7996  vmovaps [rsp], xmm0
00007e4af17d799b  vmovaps [rsp+0x10], xmm1
00007e4af17d79a1  vmovaps [rsp+0x20], xmm2
00007e4af17d79a7  vmovaps [rsp+0x30], xmm4
00007e4af17d79ad  vmovaps [rsp+0x40], xmm5
00007e4af17d79b3  vmovaps [rsp+0x50], xmm6
00007e4af17d79b9  vmovaps [rsp+0x60], xmm7
00007e4af17d79bf  vmovaps [rsp+0x70], xmm8
00007e4af17d79c5  vmovaps [rsp+0x80], xmm9
00007e4af17d79ce  vmovaps [rsp+0x90], xmm10
00007e4af17d79d7  vmovaps [rsp+0xA0], xmm11
00007e4af17d79e0  vmovaps [rsp+0xB0], xmm12
00007e4af17d79e9  vmovaps [rsp+0xC0], xmm13
00007e4af17d79f2  vmovaps [rsp+0xD0], xmm14
00007e4af17d79fb  vmovaps [rsp+0xE0], xmm15
00007e4af17d7a04  sub rsp, 0x30
00007e4af17d7a08  movaps [rsp], xmm3
00007e4af17d7a0c  movaps [rsp+0x10], xmm1
00007e4af17d7a11  movaps [rsp+0x20], xmm9
00007e4af17d7a17  lea rdi, [rsp]
00007e4af17d7a1b  mov esi, 0x00
00007e4af17d7a20  mov rax, 0x6256754A7530
00007e4af17d7a2a  call rax
00007e4af17d7a2c  movaps xmm3, [rsp]
00007e4af17d7a30  add rsp, 0x30
00007e4af17d7a34  vmovaps xmm0, [rsp]
00007e4af17d7a39  vmovaps xmm1, [rsp+0x10]
00007e4af17d7a3f  vmovaps xmm2, [rsp+0x20]
00007e4af17d7a45  vmovaps xmm4, [rsp+0x30]
00007e4af17d7a4b  vmovaps xmm5, [rsp+0x40]
00007e4af17d7a51  vmovaps xmm6, [rsp+0x50]
00007e4af17d7a57  vmovaps xmm7, [rsp+0x60]
00007e4af17d7a5d  vmovaps xmm8, [rsp+0x70]
00007e4af17d7a63  vmovaps xmm9, [rsp+0x80]
00007e4af17d7a6c  vmovaps xmm10, [rsp+0x90]
00007e4af17d7a75  vmovaps xmm11, [rsp+0xA0]
00007e4af17d7a7e  vmovaps xmm12, [rsp+0xB0]
00007e4af17d7a87  vmovaps xmm13, [rsp+0xC0]
00007e4af17d7a90  vmovaps xmm14, [rsp+0xD0]
00007e4af17d7a99  vmovaps xmm15, [rsp+0xE0]
00007e4af17d7aa2  add rsp, 0xF0
00007e4af17d7aa9  pop r11
00007e4af17d7aab  pop r10
00007e4af17d7aad  pop r9
00007e4af17d7aaf  pop r8
00007e4af17d7ab1  pop rsi
00007e4af17d7ab2  pop rdi
00007e4af17d7ab3  pop rdx
00007e4af17d7ab4  pop rcx
00007e4af17d7ab5  pop rax
00007e4af17d7ab6  add rsp, 0x08
00007e4af17d7aba  jmp 0x00007E4AF17D5D43
00007e4af17d7abf  sub rsp, 0x08
00007e4af17d7ac3  push rax
00007e4af17d7ac4  push rcx
00007e4af17d7ac5  push rdx
00007e4af17d7ac6  push rdi
00007e4af17d7ac7  push rsi
00007e4af17d7ac8  push r8
00007e4af17d7aca  push r9
00007e4af17d7acc  push r10
00007e4af17d7ace  push r11
00007e4af17d7ad0  sub rsp, 0xF0
00007e4af17d7ad7  vmovaps [rsp], xmm0
00007e4af17d7adc  vmovaps [rsp+0x10], xmm2
00007e4af17d7ae2  vmovaps [rsp+0x20], xmm3
00007e4af17d7ae8  vmovaps [rsp+0x30], xmm4
00007e4af17d7aee  vmovaps [rsp+0x40], xmm5
00007e4af17d7af4  vmovaps [rsp+0x50], xmm6
00007e4af17d7afa  vmovaps [rsp+0x60], xmm7
00007e4af17d7b00  vmovaps [rsp+0x70], xmm8
00007e4af17d7b06  vmovaps [rsp+0x80], xmm9
00007e4af17d7b0f  vmovaps [rsp+0x90], xmm10
00007e4af17d7b18  vmovaps [rsp+0xA0], xmm11
00007e4af17d7b21  vmovaps [rsp+0xB0], xmm12
00007e4af17d7b2a  vmovaps [rsp+0xC0], xmm13
00007e4af17d7b33  vmovaps [rsp+0xD0], xmm14
00007e4af17d7b3c  vmovaps [rsp+0xE0], xmm15
00007e4af17d7b45  sub rsp, 0x30
00007e4af17d7b49  movaps [rsp], xmm1
00007e4af17d7b4d  movaps [rsp+0x10], xmm15
00007e4af17d7b53  movaps [rsp+0x20], xmm9
00007e4af17d7b59  lea rdi, [rsp]
00007e4af17d7b5d  mov esi, 0x00
00007e4af17d7b62  mov rax, 0x6256754A7530
00007e4af17d7b6c  call rax
00007e4af17d7b6e  movaps xmm1, [rsp]
00007e4af17d7b72  add rsp, 0x30
00007e4af17d7b76  vmovaps xmm0, [rsp]
00007e4af17d7b7b  vmovaps xmm2, [rsp+0x10]
00007e4af17d7b81  vmovaps xmm3, [rsp+0x20]
00007e4af17d7b87  vmovaps xmm4, [rsp+0x30]
00007e4af17d7b8d  vmovaps xmm5, [rsp+0x40]
00007e4af17d7b93  vmovaps xmm6, [rsp+0x50]
00007e4af17d7b99  vmovaps xmm7, [rsp+0x60]
00007e4af17d7b9f  vmovaps xmm8, [rsp+0x70]
00007e4af17d7ba5  vmovaps xmm9, [rsp+0x80]
00007e4af17d7bae  vmovaps xmm10, [rsp+0x90]
00007e4af17d7bb7  vmovaps xmm11, [rsp+0xA0]
00007e4af17d7bc0  vmovaps xmm12, [rsp+0xB0]
00007e4af17d7bc9  vmovaps xmm13, [rsp+0xC0]
00007e4af17d7bd2  vmovaps xmm14, [rsp+0xD0]
00007e4af17d7bdb  vmovaps xmm15, [rsp+0xE0]
00007e4af17d7be4  add rsp, 0xF0
00007e4af17d7beb  pop r11
00007e4af17d7bed  pop r10
00007e4af17d7bef  pop r9
00007e4af17d7bf1  pop r8
00007e4af17d7bf3  pop rsi
00007e4af17d7bf4  pop rdi
00007e4af17d7bf5  pop rdx
00007e4af17d7bf6  pop rcx
00007e4af17d7bf7  pop rax
00007e4af17d7bf8  add rsp, 0x08
00007e4af17d7bfc  jmp 0x00007E4AF17D5DCB
00007e4af17d7c01  call 0x00007E4AF16E5820
00007e4af17d7c06  jmp 0x00007E4AF17D5DD8
00007e4af17d7c0b  sub rsp, 0x08
00007e4af17d7c0f  push rax
00007e4af17d7c10  push rcx
00007e4af17d7c11  push rdx
00007e4af17d7c12  push rdi
00007e4af17d7c13  push rsi
00007e4af17d7c14  push r8
00007e4af17d7c16  push r9
00007e4af17d7c18  push r10
00007e4af17d7c1a  push r11
00007e4af17d7c1c  sub rsp, 0xF0
00007e4af17d7c23  vmovaps [rsp], xmm0
00007e4af17d7c28  vmovaps [rsp+0x10], xmm2
00007e4af17d7c2e  vmovaps [rsp+0x20], xmm3
00007e4af17d7c34  vmovaps [rsp+0x30], xmm4
00007e4af17d7c3a  vmovaps [rsp+0x40], xmm5
00007e4af17d7c40  vmovaps [rsp+0x50], xmm6
00007e4af17d7c46  vmovaps [rsp+0x60], xmm7
00007e4af17d7c4c  vmovaps [rsp+0x70], xmm8
00007e4af17d7c52  vmovaps [rsp+0x80], xmm9
00007e4af17d7c5b  vmovaps [rsp+0x90], xmm10
00007e4af17d7c64  vmovaps [rsp+0xA0], xmm11
00007e4af17d7c6d  vmovaps [rsp+0xB0], xmm12
00007e4af17d7c76  vmovaps [rsp+0xC0], xmm13
00007e4af17d7c7f  vmovaps [rsp+0xD0], xmm14
00007e4af17d7c88  vmovaps [rsp+0xE0], xmm15
00007e4af17d7c91  sub rsp, 0x30
00007e4af17d7c95  movaps [rsp], xmm1
00007e4af17d7c99  movaps [rsp+0x10], xmm5
00007e4af17d7c9e  movaps [rsp+0x20], xmm7
00007e4af17d7ca3  lea rdi, [rsp]
00007e4af17d7ca7  mov esi, 0x00
00007e4af17d7cac  mov rax, 0x6256754A7530
00007e4af17d7cb6  call rax
00007e4af17d7cb8  movaps xmm1, [rsp]
00007e4af17d7cbc  add rsp, 0x30
00007e4af17d7cc0  vmovaps xmm0, [rsp]
00007e4af17d7cc5  vmovaps xmm2, [rsp+0x10]
00007e4af17d7ccb  vmovaps xmm3, [rsp+0x20]
00007e4af17d7cd1  vmovaps xmm4, [rsp+0x30]
00007e4af17d7cd7  vmovaps xmm5, [rsp+0x40]
00007e4af17d7cdd  vmovaps xmm6, [rsp+0x50]
00007e4af17d7ce3  vmovaps xmm7, [rsp+0x60]
00007e4af17d7ce9  vmovaps xmm8, [rsp+0x70]
00007e4af17d7cef  vmovaps xmm9, [rsp+0x80]
00007e4af17d7cf8  vmovaps xmm10, [rsp+0x90]
00007e4af17d7d01  vmovaps xmm11, [rsp+0xA0]
00007e4af17d7d0a  vmovaps xmm12, [rsp+0xB0]
00007e4af17d7d13  vmovaps xmm13, [rsp+0xC0]
00007e4af17d7d1c  vmovaps xmm14, [rsp+0xD0]
00007e4af17d7d25  vmovaps xmm15, [rsp+0xE0]
00007e4af17d7d2e  add rsp, 0xF0
00007e4af17d7d35  pop r11
00007e4af17d7d37  pop r10
00007e4af17d7d39  pop r9
00007e4af17d7d3b  pop r8
00007e4af17d7d3d  pop rsi
00007e4af17d7d3e  pop rdi
00007e4af17d7d3f  pop rdx
00007e4af17d7d40  pop rcx
00007e4af17d7d41  pop rax
00007e4af17d7d42  add rsp, 0x08
00007e4af17d7d46  jmp 0x00007E4AF17D5E7D
00007e4af17d7d4b  sub rsp, 0x08
00007e4af17d7d4f  push rax
00007e4af17d7d50  push rcx
00007e4af17d7d51  push rdx
00007e4af17d7d52  push rdi
00007e4af17d7d53  push rsi
00007e4af17d7d54  push r8
00007e4af17d7d56  push r9
00007e4af17d7d58  push r10
00007e4af17d7d5a  push r11
00007e4af17d7d5c  sub rsp, 0xF0
00007e4af17d7d63  vmovaps [rsp], xmm0
00007e4af17d7d68  vmovaps [rsp+0x10], xmm1
00007e4af17d7d6e  vmovaps [rsp+0x20], xmm2
00007e4af17d7d74  vmovaps [rsp+0x30], xmm3
00007e4af17d7d7a  vmovaps [rsp+0x40], xmm4
00007e4af17d7d80  vmovaps [rsp+0x50], xmm5
00007e4af17d7d86  vmovaps [rsp+0x60], xmm6
00007e4af17d7d8c  vmovaps [rsp+0x70], xmm8
00007e4af17d7d92  vmovaps [rsp+0x80], xmm9
00007e4af17d7d9b  vmovaps [rsp+0x90], xmm10
00007e4af17d7da4  vmovaps [rsp+0xA0], xmm11
00007e4af17d7dad  vmovaps [rsp+0xB0], xmm12
00007e4af17d7db6  vmovaps [rsp+0xC0], xmm13
00007e4af17d7dbf  vmovaps [rsp+0xD0], xmm14
00007e4af17d7dc8  vmovaps [rsp+0xE0], xmm15
00007e4af17d7dd1  sub rsp, 0x30
00007e4af17d7dd5  movaps [rsp], xmm7
00007e4af17d7dd9  movaps [rsp+0x10], xmm5
00007e4af17d7dde  movaps [rsp+0x20], xmm15
00007e4af17d7de4  lea rdi, [rsp]
00007e4af17d7de8  mov esi, 0x00
00007e4af17d7ded  mov rax, 0x6256754A7530
00007e4af17d7df7  call rax
00007e4af17d7df9  movaps xmm7, [rsp]
00007e4af17d7dfd  add rsp, 0x30
00007e4af17d7e01  vmovaps xmm0, [rsp]
00007e4af17d7e06  vmovaps xmm1, [rsp+0x10]
00007e4af17d7e0c  vmovaps xmm2, [rsp+0x20]
00007e4af17d7e12  vmovaps xmm3, [rsp+0x30]
00007e4af17d7e18  vmovaps xmm4, [rsp+0x40]
00007e4af17d7e1e  vmovaps xmm5, [rsp+0x50]
00007e4af17d7e24  vmovaps xmm6, [rsp+0x60]
00007e4af17d7e2a  vmovaps xmm8, [rsp+0x70]
00007e4af17d7e30  vmovaps xmm9, [rsp+0x80]
00007e4af17d7e39  vmovaps xmm10, [rsp+0x90]
00007e4af17d7e42  vmovaps xmm11, [rsp+0xA0]
00007e4af17d7e4b  vmovaps xmm12, [rsp+0xB0]
00007e4af17d7e54  vmovaps xmm13, [rsp+0xC0]
00007e4af17d7e5d  vmovaps xmm14, [rsp+0xD0]
00007e4af17d7e66  vmovaps xmm15, [rsp+0xE0]
00007e4af17d7e6f  add rsp, 0xF0
00007e4af17d7e76  pop r11
00007e4af17d7e78  pop r10
00007e4af17d7e7a  pop r9
00007e4af17d7e7c  pop r8
00007e4af17d7e7e  pop rsi
00007e4af17d7e7f  pop rdi
00007e4af17d7e80  pop rdx
00007e4af17d7e81  pop rcx
00007e4af17d7e82  pop rax
00007e4af17d7e83  add rsp, 0x08
00007e4af17d7e87  jmp 0x00007E4AF17D5EB3
00007e4af17d7e8c  call 0x00007E4AF16D64F0
00007e4af17d7e91  jmp 0x00007E4AF17D5EC0
00007e4af17d7e96  sub rsp, 0x08
00007e4af17d7e9a  push rax
00007e4af17d7e9b  push rcx
00007e4af17d7e9c  push rdx
00007e4af17d7e9d  push rdi
00007e4af17d7e9e  push rsi
00007e4af17d7e9f  push r8
00007e4af17d7ea1  push r9
00007e4af17d7ea3  push r10
00007e4af17d7ea5  push r11
00007e4af17d7ea7  sub rsp, 0xF0
00007e4af17d7eae  vmovaps [rsp], xmm0
00007e4af17d7eb3  vmovaps [rsp+0x10], xmm1
00007e4af17d7eb9  vmovaps [rsp+0x20], xmm2
00007e4af17d7ebf  vmovaps [rsp+0x30], xmm3
00007e4af17d7ec5  vmovaps [rsp+0x40], xmm4
00007e4af17d7ecb  vmovaps [rsp+0x50], xmm5
00007e4af17d7ed1  vmovaps [rsp+0x60], xmm6
00007e4af17d7ed7  vmovaps [rsp+0x70], xmm7
00007e4af17d7edd  vmovaps [rsp+0x80], xmm8
00007e4af17d7ee6  vmovaps [rsp+0x90], xmm9
00007e4af17d7eef  vmovaps [rsp+0xA0], xmm10
00007e4af17d7ef8  vmovaps [rsp+0xB0], xmm11
00007e4af17d7f01  vmovaps [rsp+0xC0], xmm12
00007e4af17d7f0a  vmovaps [rsp+0xD0], xmm13
00007e4af17d7f13  vmovaps [rsp+0xE0], xmm14
00007e4af17d7f1c  sub rsp, 0x30
00007e4af17d7f20  movaps [rsp], xmm15
00007e4af17d7f25  movaps [rsp+0x10], xmm5
00007e4af17d7f2a  movaps [rsp+0x20], xmm3
00007e4af17d7f2f  lea rdi, [rsp]
00007e4af17d7f33  mov esi, 0x00
00007e4af17d7f38  mov rax, 0x6256754A7530
00007e4af17d7f42  call rax
00007e4af17d7f44  movaps xmm15, [rsp]
00007e4af17d7f49  add rsp, 0x30
00007e4af17d7f4d  vmovaps xmm0, [rsp]
00007e4af17d7f52  vmovaps xmm1, [rsp+0x10]
00007e4af17d7f58  vmovaps xmm2, [rsp+0x20]
00007e4af17d7f5e  vmovaps xmm3, [rsp+0x30]
00007e4af17d7f64  vmovaps xmm4, [rsp+0x40]
00007e4af17d7f6a  vmovaps xmm5, [rsp+0x50]
00007e4af17d7f70  vmovaps xmm6, [rsp+0x60]
00007e4af17d7f76  vmovaps xmm7, [rsp+0x70]
00007e4af17d7f7c  vmovaps xmm8, [rsp+0x80]
00007e4af17d7f85  vmovaps xmm9, [rsp+0x90]
00007e4af17d7f8e  vmovaps xmm10, [rsp+0xA0]
00007e4af17d7f97  vmovaps xmm11, [rsp+0xB0]
00007e4af17d7fa0  vmovaps xmm12, [rsp+0xC0]
00007e4af17d7fa9  vmovaps xmm13, [rsp+0xD0]
00007e4af17d7fb2  vmovaps xmm14, [rsp+0xE0]
00007e4af17d7fbb  add rsp, 0xF0
00007e4af17d7fc2  pop r11
00007e4af17d7fc4  pop r10
00007e4af17d7fc6  pop r9
00007e4af17d7fc8  pop r8
00007e4af17d7fca  pop rsi
00007e4af17d7fcb  pop rdi
00007e4af17d7fcc  pop rdx
00007e4af17d7fcd  pop rcx
00007e4af17d7fce  pop rax
00007e4af17d7fcf  add rsp, 0x08
00007e4af17d7fd3  jmp 0x00007E4AF17D5EE6
00007e4af17d7fd8  sub rsp, 0x08
00007e4af17d7fdc  push rax
00007e4af17d7fdd  push rcx
00007e4af17d7fde  push rdx
00007e4af17d7fdf  push rdi
00007e4af17d7fe0  push rsi
00007e4af17d7fe1  push r8
00007e4af17d7fe3  push r9
00007e4af17d7fe5  push r10
00007e4af17d7fe7  push r11
00007e4af17d7fe9  sub rsp, 0xF0
00007e4af17d7ff0  vmovaps [rsp], xmm0
00007e4af17d7ff5  vmovaps [rsp+0x10], xmm2
00007e4af17d7ffb  vmovaps [rsp+0x20], xmm3
00007e4af17d8001  vmovaps [rsp+0x30], xmm4
00007e4af17d8007  vmovaps [rsp+0x40], xmm5
00007e4af17d800d  vmovaps [rsp+0x50], xmm6
00007e4af17d8013  vmovaps [rsp+0x60], xmm7
00007e4af17d8019  vmovaps [rsp+0x70], xmm8
00007e4af17d801f  vmovaps [rsp+0x80], xmm9
00007e4af17d8028  vmovaps [rsp+0x90], xmm10
00007e4af17d8031  vmovaps [rsp+0xA0], xmm11
00007e4af17d803a  vmovaps [rsp+0xB0], xmm12
00007e4af17d8043  vmovaps [rsp+0xC0], xmm13
00007e4af17d804c  vmovaps [rsp+0xD0], xmm14
00007e4af17d8055  vmovaps [rsp+0xE0], xmm15
00007e4af17d805e  sub rsp, 0x30
00007e4af17d8062  movaps [rsp], xmm1
00007e4af17d8066  movaps [rsp+0x10], xmm5
00007e4af17d806b  movaps [rsp+0x20], xmm4
00007e4af17d8070  lea rdi, [rsp]
00007e4af17d8074  mov esi, 0x00
00007e4af17d8079  mov rax, 0x6256754A7530
00007e4af17d8083  call rax
00007e4af17d8085  movaps xmm1, [rsp]
00007e4af17d8089  add rsp, 0x30
00007e4af17d808d  vmovaps xmm0, [rsp]
00007e4af17d8092  vmovaps xmm2, [rsp+0x10]
00007e4af17d8098  vmovaps xmm3, [rsp+0x20]
00007e4af17d809e  vmovaps xmm4, [rsp+0x30]
00007e4af17d80a4  vmovaps xmm5, [rsp+0x40]
00007e4af17d80aa  vmovaps xmm6, [rsp+0x50]
00007e4af17d80b0  vmovaps xmm7, [rsp+0x60]
00007e4af17d80b6  vmovaps xmm8, [rsp+0x70]
00007e4af17d80bc  vmovaps xmm9, [rsp+0x80]
00007e4af17d80c5  vmovaps xmm10, [rsp+0x90]
00007e4af17d80ce  vmovaps xmm11, [rsp+0xA0]
00007e4af17d80d7  vmovaps xmm12, [rsp+0xB0]
00007e4af17d80e0  vmovaps xmm13, [rsp+0xC0]
00007e4af17d80e9  vmovaps xmm14, [rsp+0xD0]
00007e4af17d80f2  vmovaps xmm15, [rsp+0xE0]
00007e4af17d80fb  add rsp, 0xF0
00007e4af17d8102  pop r11
00007e4af17d8104  pop r10
00007e4af17d8106  pop r9
00007e4af17d8108  pop r8
00007e4af17d810a  pop rsi
00007e4af17d810b  pop rdi
00007e4af17d810c  pop rdx
00007e4af17d810d  pop rcx
00007e4af17d810e  pop rax
00007e4af17d810f  add rsp, 0x08
00007e4af17d8113  jmp 0x00007E4AF17D5F06
00007e4af17d8118  sub rsp, 0x08
00007e4af17d811c  push rax
00007e4af17d811d  push rcx
00007e4af17d811e  push rdx
00007e4af17d811f  push rdi
00007e4af17d8120  push rsi
00007e4af17d8121  push r8
00007e4af17d8123  push r9
00007e4af17d8125  push r10
00007e4af17d8127  push r11
00007e4af17d8129  sub rsp, 0xF0
00007e4af17d8130  vmovaps [rsp], xmm0
00007e4af17d8135  vmovaps [rsp+0x10], xmm1
00007e4af17d813b  vmovaps [rsp+0x20], xmm2
00007e4af17d8141  vmovaps [rsp+0x30], xmm3
00007e4af17d8147  vmovaps [rsp+0x40], xmm5
00007e4af17d814d  vmovaps [rsp+0x50], xmm6
00007e4af17d8153  vmovaps [rsp+0x60], xmm7
00007e4af17d8159  vmovaps [rsp+0x70], xmm8
00007e4af17d815f  vmovaps [rsp+0x80], xmm9
00007e4af17d8168  vmovaps [rsp+0x90], xmm10
00007e4af17d8171  vmovaps [rsp+0xA0], xmm11
00007e4af17d817a  vmovaps [rsp+0xB0], xmm12
00007e4af17d8183  vmovaps [rsp+0xC0], xmm13
00007e4af17d818c  vmovaps [rsp+0xD0], xmm14
00007e4af17d8195  vmovaps [rsp+0xE0], xmm15
00007e4af17d819e  sub rsp, 0x30
00007e4af17d81a2  movaps [rsp], xmm4
00007e4af17d81a6  movaps [rsp+0x10], xmm3
00007e4af17d81ab  movaps [rsp+0x20], xmm5
00007e4af17d81b0  lea rdi, [rsp]
00007e4af17d81b4  mov esi, 0x00
00007e4af17d81b9  mov rax, 0x6256754A7530
00007e4af17d81c3  call rax
00007e4af17d81c5  movaps xmm4, [rsp]
00007e4af17d81c9  add rsp, 0x30
00007e4af17d81cd  vmovaps xmm0, [rsp]
00007e4af17d81d2  vmovaps xmm1, [rsp+0x10]
00007e4af17d81d8  vmovaps xmm2, [rsp+0x20]
00007e4af17d81de  vmovaps xmm3, [rsp+0x30]
00007e4af17d81e4  vmovaps xmm5, [rsp+0x40]
00007e4af17d81ea  vmovaps xmm6, [rsp+0x50]
00007e4af17d81f0  vmovaps xmm7, [rsp+0x60]
00007e4af17d81f6  vmovaps xmm8, [rsp+0x70]
00007e4af17d81fc  vmovaps xmm9, [rsp+0x80]
00007e4af17d8205  vmovaps xmm10, [rsp+0x90]
00007e4af17d820e  vmovaps xmm11, [rsp+0xA0]
00007e4af17d8217  vmovaps xmm12, [rsp+0xB0]
00007e4af17d8220  vmovaps xmm13, [rsp+0xC0]
00007e4af17d8229  vmovaps xmm14, [rsp+0xD0]
00007e4af17d8232  vmovaps xmm15, [rsp+0xE0]
00007e4af17d823b  add rsp, 0xF0
00007e4af17d8242  pop r11
00007e4af17d8244  pop r10
00007e4af17d8246  pop r9
00007e4af17d8248  pop r8
00007e4af17d824a  pop rsi
00007e4af17d824b  pop rdi
00007e4af17d824c  pop rdx
00007e4af17d824d  pop rcx
00007e4af17d824e  pop rax
00007e4af17d824f  add rsp, 0x08
00007e4af17d8253  jmp 0x00007E4AF17D5F54
00007e4af17d8258  call 0x00007E4AF16D64F0
00007e4af17d825d  jmp 0x00007E4AF17D5F61
00007e4af17d8262  sub rsp, 0x08
00007e4af17d8266  push rax
00007e4af17d8267  push rcx
00007e4af17d8268  push rdx
00007e4af17d8269  push rdi
00007e4af17d826a  push rsi
00007e4af17d826b  push r8
00007e4af17d826d  push r9
00007e4af17d826f  push r10
00007e4af17d8271  push r11
00007e4af17d8273  sub rsp, 0xF0
00007e4af17d827a  vmovaps [rsp], xmm0
00007e4af17d827f  vmovaps [rsp+0x10], xmm1
00007e4af17d8285  vmovaps [rsp+0x20], xmm2
00007e4af17d828b  vmovaps [rsp+0x30], xmm3
00007e4af17d8291  vmovaps [rsp+0x40], xmm4
00007e4af17d8297  vmovaps [rsp+0x50], xmm6
00007e4af17d829d  vmovaps [rsp+0x60], xmm7
00007e4af17d82a3  vmovaps [rsp+0x70], xmm8
00007e4af17d82a9  vmovaps [rsp+0x80], xmm9
00007e4af17d82b2  vmovaps [rsp+0x90], xmm10
00007e4af17d82bb  vmovaps [rsp+0xA0], xmm11
00007e4af17d82c4  vmovaps [rsp+0xB0], xmm12
00007e4af17d82cd  vmovaps [rsp+0xC0], xmm13
00007e4af17d82d6  vmovaps [rsp+0xD0], xmm14
00007e4af17d82df  vmovaps [rsp+0xE0], xmm15
00007e4af17d82e8  sub rsp, 0x30
00007e4af17d82ec  movaps [rsp], xmm5
00007e4af17d82f0  movaps [rsp+0x10], xmm6
00007e4af17d82f5  movaps [rsp+0x20], xmm3
00007e4af17d82fa  lea rdi, [rsp]
00007e4af17d82fe  mov esi, 0x00
00007e4af17d8303  mov rax, 0x6256754A7530
00007e4af17d830d  call rax
00007e4af17d830f  movaps xmm5, [rsp]
00007e4af17d8313  add rsp, 0x30
00007e4af17d8317  vmovaps xmm0, [rsp]
00007e4af17d831c  vmovaps xmm1, [rsp+0x10]
00007e4af17d8322  vmovaps xmm2, [rsp+0x20]
00007e4af17d8328  vmovaps xmm3, [rsp+0x30]
00007e4af17d832e  vmovaps xmm4, [rsp+0x40]
00007e4af17d8334  vmovaps xmm6, [rsp+0x50]
00007e4af17d833a  vmovaps xmm7, [rsp+0x60]
00007e4af17d8340  vmovaps xmm8, [rsp+0x70]
00007e4af17d8346  vmovaps xmm9, [rsp+0x80]
00007e4af17d834f  vmovaps xmm10, [rsp+0x90]
00007e4af17d8358  vmovaps xmm11, [rsp+0xA0]
00007e4af17d8361  vmovaps xmm12, [rsp+0xB0]
00007e4af17d836a  vmovaps xmm13, [rsp+0xC0]
00007e4af17d8373  vmovaps xmm14, [rsp+0xD0]
00007e4af17d837c  vmovaps xmm15, [rsp+0xE0]
00007e4af17d8385  add rsp, 0xF0
00007e4af17d838c  pop r11
00007e4af17d838e  pop r10
00007e4af17d8390  pop r9
00007e4af17d8392  pop r8
00007e4af17d8394  pop rsi
00007e4af17d8395  pop rdi
00007e4af17d8396  pop rdx
00007e4af17d8397  pop rcx
00007e4af17d8398  pop rax
00007e4af17d8399  add rsp, 0x08
00007e4af17d839d  jmp 0x00007E4AF17D5F87
00007e4af17d83a2  sub rsp, 0x08
00007e4af17d83a6  push rax
00007e4af17d83a7  push rcx
00007e4af17d83a8  push rdx
00007e4af17d83a9  push rdi
00007e4af17d83aa  push rsi
00007e4af17d83ab  push r8
00007e4af17d83ad  push r9
00007e4af17d83af  push r10
00007e4af17d83b1  push r11
00007e4af17d83b3  sub rsp, 0xF0
00007e4af17d83ba  vmovaps [rsp], xmm0
00007e4af17d83bf  vmovaps [rsp+0x10], xmm1
00007e4af17d83c5  vmovaps [rsp+0x20], xmm2
00007e4af17d83cb  vmovaps [rsp+0x30], xmm3
00007e4af17d83d1  vmovaps [rsp+0x40], xmm4
00007e4af17d83d7  vmovaps [rsp+0x50], xmm5
00007e4af17d83dd  vmovaps [rsp+0x60], xmm7
00007e4af17d83e3  vmovaps [rsp+0x70], xmm8
00007e4af17d83e9  vmovaps [rsp+0x80], xmm9
00007e4af17d83f2  vmovaps [rsp+0x90], xmm10
00007e4af17d83fb  vmovaps [rsp+0xA0], xmm11
00007e4af17d8404  vmovaps [rsp+0xB0], xmm12
00007e4af17d840d  vmovaps [rsp+0xC0], xmm13
00007e4af17d8416  vmovaps [rsp+0xD0], xmm14
00007e4af17d841f  vmovaps [rsp+0xE0], xmm15
00007e4af17d8428  sub rsp, 0x30
00007e4af17d842c  movaps [rsp], xmm6
00007e4af17d8430  movaps [rsp+0x10], xmm9
00007e4af17d8436  movaps [rsp+0x20], xmm1
00007e4af17d843b  lea rdi, [rsp]
00007e4af17d843f  mov esi, 0x00
00007e4af17d8444  mov rax, 0x6256754A7530
00007e4af17d844e  call rax
00007e4af17d8450  movaps xmm6, [rsp]
00007e4af17d8454  add rsp, 0x30
00007e4af17d8458  vmovaps xmm0, [rsp]
00007e4af17d845d  vmovaps xmm1, [rsp+0x10]
00007e4af17d8463  vmovaps xmm2, [rsp+0x20]
00007e4af17d8469  vmovaps xmm3, [rsp+0x30]
00007e4af17d846f  vmovaps xmm4, [rsp+0x40]
00007e4af17d8475  vmovaps xmm5, [rsp+0x50]
00007e4af17d847b  vmovaps xmm7, [rsp+0x60]
00007e4af17d8481  vmovaps xmm8, [rsp+0x70]
00007e4af17d8487  vmovaps xmm9, [rsp+0x80]
00007e4af17d8490  vmovaps xmm10, [rsp+0x90]
00007e4af17d8499  vmovaps xmm11, [rsp+0xA0]
00007e4af17d84a2  vmovaps xmm12, [rsp+0xB0]
00007e4af17d84ab  vmovaps xmm13, [rsp+0xC0]
00007e4af17d84b4  vmovaps xmm14, [rsp+0xD0]
00007e4af17d84bd  vmovaps xmm15, [rsp+0xE0]
00007e4af17d84c6  add rsp, 0xF0
00007e4af17d84cd  pop r11
00007e4af17d84cf  pop r10
00007e4af17d84d1  pop r9
00007e4af17d84d3  pop r8
00007e4af17d84d5  pop rsi
00007e4af17d84d6  pop rdi
00007e4af17d84d7  pop rdx
00007e4af17d84d8  pop rcx
00007e4af17d84d9  pop rax
00007e4af17d84da  add rsp, 0x08
00007e4af17d84de  jmp 0x00007E4AF17D5FAB
00007e4af17d84e3  sub rsp, 0x08
00007e4af17d84e7  push rax
00007e4af17d84e8  push rcx
00007e4af17d84e9  push rdx
00007e4af17d84ea  push rdi
00007e4af17d84eb  push rsi
00007e4af17d84ec  push r8
00007e4af17d84ee  push r9
00007e4af17d84f0  push r10
00007e4af17d84f2  push r11
00007e4af17d84f4  sub rsp, 0xF0
00007e4af17d84fb  vmovaps [rsp], xmm0
00007e4af17d8500  vmovaps [rsp+0x10], xmm1
00007e4af17d8506  vmovaps [rsp+0x20], xmm2
00007e4af17d850c  vmovaps [rsp+0x30], xmm3
00007e4af17d8512  vmovaps [rsp+0x40], xmm4
00007e4af17d8518  vmovaps [rsp+0x50], xmm5
00007e4af17d851e  vmovaps [rsp+0x60], xmm6
00007e4af17d8524  vmovaps [rsp+0x70], xmm7
00007e4af17d852a  vmovaps [rsp+0x80], xmm8
00007e4af17d8533  vmovaps [rsp+0x90], xmm10
00007e4af17d853c  vmovaps [rsp+0xA0], xmm11
00007e4af17d8545  vmovaps [rsp+0xB0], xmm12
00007e4af17d854e  vmovaps [rsp+0xC0], xmm13
00007e4af17d8557  vmovaps [rsp+0xD0], xmm14
00007e4af17d8560  vmovaps [rsp+0xE0], xmm15
00007e4af17d8569  sub rsp, 0x30
00007e4af17d856d  movaps [rsp], xmm9
00007e4af17d8572  movaps [rsp+0x10], xmm3
00007e4af17d8577  movaps [rsp+0x20], xmm1
00007e4af17d857c  lea rdi, [rsp]
00007e4af17d8580  mov esi, 0x00
00007e4af17d8585  mov rax, 0x6256754A7530
00007e4af17d858f  call rax
00007e4af17d8591  movaps xmm9, [rsp]
00007e4af17d8596  add rsp, 0x30
00007e4af17d859a  vmovaps xmm0, [rsp]
00007e4af17d859f  vmovaps xmm1, [rsp+0x10]
00007e4af17d85a5  vmovaps xmm2, [rsp+0x20]
00007e4af17d85ab  vmovaps xmm3, [rsp+0x30]
00007e4af17d85b1  vmovaps xmm4, [rsp+0x40]
00007e4af17d85b7  vmovaps xmm5, [rsp+0x50]
00007e4af17d85bd  vmovaps xmm6, [rsp+0x60]
00007e4af17d85c3  vmovaps xmm7, [rsp+0x70]
00007e4af17d85c9  vmovaps xmm8, [rsp+0x80]
00007e4af17d85d2  vmovaps xmm10, [rsp+0x90]
00007e4af17d85db  vmovaps xmm11, [rsp+0xA0]
00007e4af17d85e4  vmovaps xmm12, [rsp+0xB0]
00007e4af17d85ed  vmovaps xmm13, [rsp+0xC0]
00007e4af17d85f6  vmovaps xmm14, [rsp+0xD0]
00007e4af17d85ff  vmovaps xmm15, [rsp+0xE0]
00007e4af17d8608  add rsp, 0xF0
00007e4af17d860f  pop r11
00007e4af17d8611  pop r10
00007e4af17d8613  pop r9
00007e4af17d8615  pop r8
00007e4af17d8617  pop rsi
00007e4af17d8618  pop rdi
00007e4af17d8619  pop rdx
00007e4af17d861a  pop rcx
00007e4af17d861b  pop rax
00007e4af17d861c  add rsp, 0x08
00007e4af17d8620  jmp 0x00007E4AF17D5FF7
00007e4af17d8625  call 0x00007E4AF16D64F0
00007e4af17d862a  jmp 0x00007E4AF17D6004
00007e4af17d862f  sub rsp, 0x08
00007e4af17d8633  push rax
00007e4af17d8634  push rcx
00007e4af17d8635  push rdx
00007e4af17d8636  push rdi
00007e4af17d8637  push rsi
00007e4af17d8638  push r8
00007e4af17d863a  push r9
00007e4af17d863c  push r10
00007e4af17d863e  push r11
00007e4af17d8640  sub rsp, 0xF0
00007e4af17d8647  vmovaps [rsp], xmm0
00007e4af17d864c  vmovaps [rsp+0x10], xmm1
00007e4af17d8652  vmovaps [rsp+0x20], xmm2
00007e4af17d8658  vmovaps [rsp+0x30], xmm3
00007e4af17d865e  vmovaps [rsp+0x40], xmm4
00007e4af17d8664  vmovaps [rsp+0x50], xmm5
00007e4af17d866a  vmovaps [rsp+0x60], xmm6
00007e4af17d8670  vmovaps [rsp+0x70], xmm7
00007e4af17d8676  vmovaps [rsp+0x80], xmm8
00007e4af17d867f  vmovaps [rsp+0x90], xmm9
00007e4af17d8688  vmovaps [rsp+0xA0], xmm10
00007e4af17d8691  vmovaps [rsp+0xB0], xmm11
00007e4af17d869a  vmovaps [rsp+0xC0], xmm12
00007e4af17d86a3  vmovaps [rsp+0xD0], xmm13
00007e4af17d86ac  vmovaps [rsp+0xE0], xmm14
00007e4af17d86b5  sub rsp, 0x30
00007e4af17d86b9  movaps [rsp], xmm15
00007e4af17d86be  movaps [rsp+0x10], xmm3
00007e4af17d86c3  movaps [rsp+0x20], xmm7
00007e4af17d86c8  lea rdi, [rsp]
00007e4af17d86cc  mov esi, 0x00
00007e4af17d86d1  mov rax, 0x6256754A7530
00007e4af17d86db  call rax
00007e4af17d86dd  movaps xmm15, [rsp]
00007e4af17d86e2  add rsp, 0x30
00007e4af17d86e6  vmovaps xmm0, [rsp]
00007e4af17d86eb  vmovaps xmm1, [rsp+0x10]
00007e4af17d86f1  vmovaps xmm2, [rsp+0x20]
00007e4af17d86f7  vmovaps xmm3, [rsp+0x30]
00007e4af17d86fd  vmovaps xmm4, [rsp+0x40]
00007e4af17d8703  vmovaps xmm5, [rsp+0x50]
00007e4af17d8709  vmovaps xmm6, [rsp+0x60]
00007e4af17d870f  vmovaps xmm7, [rsp+0x70]
00007e4af17d8715  vmovaps xmm8, [rsp+0x80]
00007e4af17d871e  vmovaps xmm9, [rsp+0x90]
00007e4af17d8727  vmovaps xmm10, [rsp+0xA0]
00007e4af17d8730  vmovaps xmm11, [rsp+0xB0]
00007e4af17d8739  vmovaps xmm12, [rsp+0xC0]
00007e4af17d8742  vmovaps xmm13, [rsp+0xD0]
00007e4af17d874b  vmovaps xmm14, [rsp+0xE0]
00007e4af17d8754  add rsp, 0xF0
00007e4af17d875b  pop r11
00007e4af17d875d  pop r10
00007e4af17d875f  pop r9
00007e4af17d8761  pop r8
00007e4af17d8763  pop rsi
00007e4af17d8764  pop rdi
00007e4af17d8765  pop rdx
00007e4af17d8766  pop rcx
00007e4af17d8767  pop rax
00007e4af17d8768  add rsp, 0x08
00007e4af17d876c  jmp 0x00007E4AF17D6030
00007e4af17d8771  sub rsp, 0x08
00007e4af17d8775  push rax
00007e4af17d8776  push rcx
00007e4af17d8777  push rdx
00007e4af17d8778  push rdi
00007e4af17d8779  push rsi
00007e4af17d877a  push r8
00007e4af17d877c  push r9
00007e4af17d877e  push r10
00007e4af17d8780  push r11
00007e4af17d8782  sub rsp, 0xF0
00007e4af17d8789  vmovaps [rsp], xmm0
00007e4af17d878e  vmovaps [rsp+0x10], xmm1
00007e4af17d8794  vmovaps [rsp+0x20], xmm2
00007e4af17d879a  vmovaps [rsp+0x30], xmm4
00007e4af17d87a0  vmovaps [rsp+0x40], xmm5
00007e4af17d87a6  vmovaps [rsp+0x50], xmm6
00007e4af17d87ac  vmovaps [rsp+0x60], xmm7
00007e4af17d87b2  vmovaps [rsp+0x70], xmm8
00007e4af17d87b8  vmovaps [rsp+0x80], xmm9
00007e4af17d87c1  vmovaps [rsp+0x90], xmm10
00007e4af17d87ca  vmovaps [rsp+0xA0], xmm11
00007e4af17d87d3  vmovaps [rsp+0xB0], xmm12
00007e4af17d87dc  vmovaps [rsp+0xC0], xmm13
00007e4af17d87e5  vmovaps [rsp+0xD0], xmm14
00007e4af17d87ee  vmovaps [rsp+0xE0], xmm15
00007e4af17d87f7  sub rsp, 0x30
00007e4af17d87fb  movaps [rsp], xmm3
00007e4af17d87ff  movaps [rsp+0x10], xmm1
00007e4af17d8804  movaps [rsp+0x20], xmm15
00007e4af17d880a  lea rdi, [rsp]
00007e4af17d880e  mov esi, 0x00
00007e4af17d8813  mov rax, 0x6256754A7530
00007e4af17d881d  call rax
00007e4af17d881f  movaps xmm3, [rsp]
00007e4af17d8823  add rsp, 0x30
00007e4af17d8827  vmovaps xmm0, [rsp]
00007e4af17d882c  vmovaps xmm1, [rsp+0x10]
00007e4af17d8832  vmovaps xmm2, [rsp+0x20]
00007e4af17d8838  vmovaps xmm4, [rsp+0x30]
00007e4af17d883e  vmovaps xmm5, [rsp+0x40]
00007e4af17d8844  vmovaps xmm6, [rsp+0x50]
00007e4af17d884a  vmovaps xmm7, [rsp+0x60]
00007e4af17d8850  vmovaps xmm8, [rsp+0x70]
00007e4af17d8856  vmovaps xmm9, [rsp+0x80]
00007e4af17d885f  vmovaps xmm10, [rsp+0x90]
00007e4af17d8868  vmovaps xmm11, [rsp+0xA0]
00007e4af17d8871  vmovaps xmm12, [rsp+0xB0]
00007e4af17d887a  vmovaps xmm13, [rsp+0xC0]
00007e4af17d8883  vmovaps xmm14, [rsp+0xD0]
00007e4af17d888c  vmovaps xmm15, [rsp+0xE0]
00007e4af17d8895  add rsp, 0xF0
00007e4af17d889c  pop r11
00007e4af17d889e  pop r10
00007e4af17d88a0  pop r9
00007e4af17d88a2  pop r8
00007e4af17d88a4  pop rsi
00007e4af17d88a5  pop rdi
00007e4af17d88a6  pop rdx
00007e4af17d88a7  pop rcx
00007e4af17d88a8  pop rax
00007e4af17d88a9  add rsp, 0x08
00007e4af17d88ad  jmp 0x00007E4AF17D60BF
00007e4af17d88b2  call 0x00007E4AF16D64F0
00007e4af17d88b7  jmp 0x00007E4AF17D60C9
00007e4af17d88bc  sub rsp, 0x08
00007e4af17d88c0  push rax
00007e4af17d88c1  push rcx
00007e4af17d88c2  push rdx
00007e4af17d88c3  push rdi
00007e4af17d88c4  push rsi
00007e4af17d88c5  push r8
00007e4af17d88c7  push r9
00007e4af17d88c9  push r10
00007e4af17d88cb  push r11
00007e4af17d88cd  sub rsp, 0xF0
00007e4af17d88d4  vmovaps [rsp], xmm0
00007e4af17d88d9  vmovaps [rsp+0x10], xmm1
00007e4af17d88df  vmovaps [rsp+0x20], xmm2
00007e4af17d88e5  vmovaps [rsp+0x30], xmm3
00007e4af17d88eb  vmovaps [rsp+0x40], xmm4
00007e4af17d88f1  vmovaps [rsp+0x50], xmm5
00007e4af17d88f7  vmovaps [rsp+0x60], xmm6
00007e4af17d88fd  vmovaps [rsp+0x70], xmm7
00007e4af17d8903  vmovaps [rsp+0x80], xmm8
00007e4af17d890c  vmovaps [rsp+0x90], xmm9
00007e4af17d8915  vmovaps [rsp+0xA0], xmm10
00007e4af17d891e  vmovaps [rsp+0xB0], xmm11
00007e4af17d8927  vmovaps [rsp+0xC0], xmm12
00007e4af17d8930  vmovaps [rsp+0xD0], xmm13
00007e4af17d8939  vmovaps [rsp+0xE0], xmm14
00007e4af17d8942  sub rsp, 0x30
00007e4af17d8946  movaps [rsp], xmm15
00007e4af17d894b  movaps [rsp+0x10], xmm14
00007e4af17d8951  movaps [rsp+0x20], xmm4
00007e4af17d8956  lea rdi, [rsp]
00007e4af17d895a  mov esi, 0x00
00007e4af17d895f  mov rax, 0x6256754A7530
00007e4af17d8969  call rax
00007e4af17d896b  movaps xmm15, [rsp]
00007e4af17d8970  add rsp, 0x30
00007e4af17d8974  vmovaps xmm0, [rsp]
00007e4af17d8979  vmovaps xmm1, [rsp+0x10]
00007e4af17d897f  vmovaps xmm2, [rsp+0x20]
00007e4af17d8985  vmovaps xmm3, [rsp+0x30]
00007e4af17d898b  vmovaps xmm4, [rsp+0x40]
00007e4af17d8991  vmovaps xmm5, [rsp+0x50]
00007e4af17d8997  vmovaps xmm6, [rsp+0x60]
00007e4af17d899d  vmovaps xmm7, [rsp+0x70]
00007e4af17d89a3  vmovaps xmm8, [rsp+0x80]
00007e4af17d89ac  vmovaps xmm9, [rsp+0x90]
00007e4af17d89b5  vmovaps xmm10, [rsp+0xA0]
00007e4af17d89be  vmovaps xmm11, [rsp+0xB0]
00007e4af17d89c7  vmovaps xmm12, [rsp+0xC0]
00007e4af17d89d0  vmovaps xmm13, [rsp+0xD0]
00007e4af17d89d9  vmovaps xmm14, [rsp+0xE0]
00007e4af17d89e2  add rsp, 0xF0
00007e4af17d89e9  pop r11
00007e4af17d89eb  pop r10
00007e4af17d89ed  pop r9
00007e4af17d89ef  pop r8
00007e4af17d89f1  pop rsi
00007e4af17d89f2  pop rdi
00007e4af17d89f3  pop rdx
00007e4af17d89f4  pop rcx
00007e4af17d89f5  pop rax
00007e4af17d89f6  add rsp, 0x08
00007e4af17d89fa  jmp 0x00007E4AF17D60F7
00007e4af17d89ff  sub rsp, 0x08
00007e4af17d8a03  push rax
00007e4af17d8a04  push rcx
00007e4af17d8a05  push rdx
00007e4af17d8a06  push rdi
00007e4af17d8a07  push rsi
00007e4af17d8a08  push r8
00007e4af17d8a0a  push r9
00007e4af17d8a0c  push r10
00007e4af17d8a0e  push r11
00007e4af17d8a10  sub rsp, 0xF0
00007e4af17d8a17  vmovaps [rsp], xmm0
00007e4af17d8a1c  vmovaps [rsp+0x10], xmm1
00007e4af17d8a22  vmovaps [rsp+0x20], xmm2
00007e4af17d8a28  vmovaps [rsp+0x30], xmm3
00007e4af17d8a2e  vmovaps [rsp+0x40], xmm4
00007e4af17d8a34  vmovaps [rsp+0x50], xmm5
00007e4af17d8a3a  vmovaps [rsp+0x60], xmm6
00007e4af17d8a40  vmovaps [rsp+0x70], xmm7
00007e4af17d8a46  vmovaps [rsp+0x80], xmm8
00007e4af17d8a4f  vmovaps [rsp+0x90], xmm9
00007e4af17d8a58  vmovaps [rsp+0xA0], xmm10
00007e4af17d8a61  vmovaps [rsp+0xB0], xmm11
00007e4af17d8a6a  vmovaps [rsp+0xC0], xmm12
00007e4af17d8a73  vmovaps [rsp+0xD0], xmm13
00007e4af17d8a7c  vmovaps [rsp+0xE0], xmm15
00007e4af17d8a85  sub rsp, 0x30
00007e4af17d8a89  movaps [rsp], xmm14
00007e4af17d8a8e  movaps [rsp+0x10], xmm2
00007e4af17d8a93  movaps [rsp+0x20], xmm1
00007e4af17d8a98  lea rdi, [rsp]
00007e4af17d8a9c  mov esi, 0x00
00007e4af17d8aa1  mov rax, 0x6256754A7530
00007e4af17d8aab  call rax
00007e4af17d8aad  movaps xmm14, [rsp]
00007e4af17d8ab2  add rsp, 0x30
00007e4af17d8ab6  vmovaps xmm0, [rsp]
00007e4af17d8abb  vmovaps xmm1, [rsp+0x10]
00007e4af17d8ac1  vmovaps xmm2, [rsp+0x20]
00007e4af17d8ac7  vmovaps xmm3, [rsp+0x30]
00007e4af17d8acd  vmovaps xmm4, [rsp+0x40]
00007e4af17d8ad3  vmovaps xmm5, [rsp+0x50]
00007e4af17d8ad9  vmovaps xmm6, [rsp+0x60]
00007e4af17d8adf  vmovaps xmm7, [rsp+0x70]
00007e4af17d8ae5  vmovaps xmm8, [rsp+0x80]
00007e4af17d8aee  vmovaps xmm9, [rsp+0x90]
00007e4af17d8af7  vmovaps xmm10, [rsp+0xA0]
00007e4af17d8b00  vmovaps xmm11, [rsp+0xB0]
00007e4af17d8b09  vmovaps xmm12, [rsp+0xC0]
00007e4af17d8b12  vmovaps xmm13, [rsp+0xD0]
00007e4af17d8b1b  vmovaps xmm15, [rsp+0xE0]
00007e4af17d8b24  add rsp, 0xF0
00007e4af17d8b2b  pop r11
00007e4af17d8b2d  pop r10
00007e4af17d8b2f  pop r9
00007e4af17d8b31  pop r8
00007e4af17d8b33  pop rsi
00007e4af17d8b34  pop rdi
00007e4af17d8b35  pop rdx
00007e4af17d8b36  pop rcx
00007e4af17d8b37  pop rax
00007e4af17d8b38  add rsp, 0x08
00007e4af17d8b3c  jmp 0x00007E4AF17D611D
00007e4af17d8b41  sub rsp, 0x08
00007e4af17d8b45  push rax
00007e4af17d8b46  push rcx
00007e4af17d8b47  push rdx
00007e4af17d8b48  push rdi
00007e4af17d8b49  push rsi
00007e4af17d8b4a  push r8
00007e4af17d8b4c  push r9
00007e4af17d8b4e  push r10
00007e4af17d8b50  push r11
00007e4af17d8b52  sub rsp, 0xF0
00007e4af17d8b59  vmovaps [rsp], xmm0
00007e4af17d8b5e  vmovaps [rsp+0x10], xmm2
00007e4af17d8b64  vmovaps [rsp+0x20], xmm3
00007e4af17d8b6a  vmovaps [rsp+0x30], xmm4
00007e4af17d8b70  vmovaps [rsp+0x40], xmm5
00007e4af17d8b76  vmovaps [rsp+0x50], xmm6
00007e4af17d8b7c  vmovaps [rsp+0x60], xmm7
00007e4af17d8b82  vmovaps [rsp+0x70], xmm8
00007e4af17d8b88  vmovaps [rsp+0x80], xmm9
00007e4af17d8b91  vmovaps [rsp+0x90], xmm10
00007e4af17d8b9a  vmovaps [rsp+0xA0], xmm11
00007e4af17d8ba3  vmovaps [rsp+0xB0], xmm12
00007e4af17d8bac  vmovaps [rsp+0xC0], xmm13
00007e4af17d8bb5  vmovaps [rsp+0xD0], xmm14
00007e4af17d8bbe  vmovaps [rsp+0xE0], xmm15
00007e4af17d8bc7  sub rsp, 0x30
00007e4af17d8bcb  movaps [rsp], xmm1
00007e4af17d8bcf  movaps [rsp+0x10], xmm4
00007e4af17d8bd4  movaps [rsp+0x20], xmm9
00007e4af17d8bda  lea rdi, [rsp]
00007e4af17d8bde  mov esi, 0x00
00007e4af17d8be3  mov rax, 0x6256754A7530
00007e4af17d8bed  call rax
00007e4af17d8bef  movaps xmm1, [rsp]
00007e4af17d8bf3  add rsp, 0x30
00007e4af17d8bf7  vmovaps xmm0, [rsp]
00007e4af17d8bfc  vmovaps xmm2, [rsp+0x10]
00007e4af17d8c02  vmovaps xmm3, [rsp+0x20]
00007e4af17d8c08  vmovaps xmm4, [rsp+0x30]
00007e4af17d8c0e  vmovaps xmm5, [rsp+0x40]
00007e4af17d8c14  vmovaps xmm6, [rsp+0x50]
00007e4af17d8c1a  vmovaps xmm7, [rsp+0x60]
00007e4af17d8c20  vmovaps xmm8, [rsp+0x70]
00007e4af17d8c26  vmovaps xmm9, [rsp+0x80]
00007e4af17d8c2f  vmovaps xmm10, [rsp+0x90]
00007e4af17d8c38  vmovaps xmm11, [rsp+0xA0]
00007e4af17d8c41  vmovaps xmm12, [rsp+0xB0]
00007e4af17d8c4a  vmovaps xmm13, [rsp+0xC0]
00007e4af17d8c53  vmovaps xmm14, [rsp+0xD0]
00007e4af17d8c5c  vmovaps xmm15, [rsp+0xE0]
00007e4af17d8c65  add rsp, 0xF0
00007e4af17d8c6c  pop r11
00007e4af17d8c6e  pop r10
00007e4af17d8c70  pop r9
00007e4af17d8c72  pop r8
00007e4af17d8c74  pop rsi
00007e4af17d8c75  pop rdi
00007e4af17d8c76  pop rdx
00007e4af17d8c77  pop rcx
00007e4af17d8c78  pop rax
00007e4af17d8c79  add rsp, 0x08
00007e4af17d8c7d  jmp 0x00007E4AF17D613B
00007e4af17d8c82  sub rsp, 0x08
00007e4af17d8c86  push rax
00007e4af17d8c87  push rcx
00007e4af17d8c88  push rdx
00007e4af17d8c89  push rdi
00007e4af17d8c8a  push rsi
00007e4af17d8c8b  push r8
00007e4af17d8c8d  push r9
00007e4af17d8c8f  push r10
00007e4af17d8c91  push r11
00007e4af17d8c93  sub rsp, 0xF0
00007e4af17d8c9a  vmovaps [rsp], xmm0
00007e4af17d8c9f  vmovaps [rsp+0x10], xmm1
00007e4af17d8ca5  vmovaps [rsp+0x20], xmm2
00007e4af17d8cab  vmovaps [rsp+0x30], xmm3
00007e4af17d8cb1  vmovaps [rsp+0x40], xmm5
00007e4af17d8cb7  vmovaps [rsp+0x50], xmm6
00007e4af17d8cbd  vmovaps [rsp+0x60], xmm7
00007e4af17d8cc3  vmovaps [rsp+0x70], xmm8
00007e4af17d8cc9  vmovaps [rsp+0x80], xmm9
00007e4af17d8cd2  vmovaps [rsp+0x90], xmm10
00007e4af17d8cdb  vmovaps [rsp+0xA0], xmm11
00007e4af17d8ce4  vmovaps [rsp+0xB0], xmm12
00007e4af17d8ced  vmovaps [rsp+0xC0], xmm13
00007e4af17d8cf6  vmovaps [rsp+0xD0], xmm14
00007e4af17d8cff  vmovaps [rsp+0xE0], xmm15
00007e4af17d8d08  sub rsp, 0x30
00007e4af17d8d0c  movaps [rsp], xmm4
00007e4af17d8d10  movaps [rsp+0x10], xmm2
00007e4af17d8d15  movaps [rsp+0x20], xmm9
00007e4af17d8d1b  lea rdi, [rsp]
00007e4af17d8d1f  mov esi, 0x00
00007e4af17d8d24  mov rax, 0x6256754A7530
00007e4af17d8d2e  call rax
00007e4af17d8d30  movaps xmm4, [rsp]
00007e4af17d8d34  add rsp, 0x30
00007e4af17d8d38  vmovaps xmm0, [rsp]
00007e4af17d8d3d  vmovaps xmm1, [rsp+0x10]
00007e4af17d8d43  vmovaps xmm2, [rsp+0x20]
00007e4af17d8d49  vmovaps xmm3, [rsp+0x30]
00007e4af17d8d4f  vmovaps xmm5, [rsp+0x40]
00007e4af17d8d55  vmovaps xmm6, [rsp+0x50]
00007e4af17d8d5b  vmovaps xmm7, [rsp+0x60]
00007e4af17d8d61  vmovaps xmm8, [rsp+0x70]
00007e4af17d8d67  vmovaps xmm9, [rsp+0x80]
00007e4af17d8d70  vmovaps xmm10, [rsp+0x90]
00007e4af17d8d79  vmovaps xmm11, [rsp+0xA0]
00007e4af17d8d82  vmovaps xmm12, [rsp+0xB0]
00007e4af17d8d8b  vmovaps xmm13, [rsp+0xC0]
00007e4af17d8d94  vmovaps xmm14, [rsp+0xD0]
00007e4af17d8d9d  vmovaps xmm15, [rsp+0xE0]
00007e4af17d8da6  add rsp, 0xF0
00007e4af17d8dad  pop r11
00007e4af17d8daf  pop r10
00007e4af17d8db1  pop r9
00007e4af17d8db3  pop r8
00007e4af17d8db5  pop rsi
00007e4af17d8db6  pop rdi
00007e4af17d8db7  pop rdx
00007e4af17d8db8  pop rcx
00007e4af17d8db9  pop rax
00007e4af17d8dba  add rsp, 0x08
00007e4af17d8dbe  jmp 0x00007E4AF17D616B
00007e4af17d8dc3  sub rsp, 0x08
00007e4af17d8dc7  push rax
00007e4af17d8dc8  push rcx
00007e4af17d8dc9  push rdx
00007e4af17d8dca  push rdi
00007e4af17d8dcb  push rsi
00007e4af17d8dcc  push r8
00007e4af17d8dce  push r9
00007e4af17d8dd0  push r10
00007e4af17d8dd2  push r11
00007e4af17d8dd4  sub rsp, 0xF0
00007e4af17d8ddb  vmovaps [rsp], xmm0
00007e4af17d8de0  vmovaps [rsp+0x10], xmm1
00007e4af17d8de6  vmovaps [rsp+0x20], xmm2
00007e4af17d8dec  vmovaps [rsp+0x30], xmm3
00007e4af17d8df2  vmovaps [rsp+0x40], xmm4
00007e4af17d8df8  vmovaps [rsp+0x50], xmm5
00007e4af17d8dfe  vmovaps [rsp+0x60], xmm6
00007e4af17d8e04  vmovaps [rsp+0x70], xmm7
00007e4af17d8e0a  vmovaps [rsp+0x80], xmm8
00007e4af17d8e13  vmovaps [rsp+0x90], xmm10
00007e4af17d8e1c  vmovaps [rsp+0xA0], xmm11
00007e4af17d8e25  vmovaps [rsp+0xB0], xmm12
00007e4af17d8e2e  vmovaps [rsp+0xC0], xmm13
00007e4af17d8e37  vmovaps [rsp+0xD0], xmm14
00007e4af17d8e40  vmovaps [rsp+0xE0], xmm15
00007e4af17d8e49  sub rsp, 0x30
00007e4af17d8e4d  movaps [rsp], xmm9
00007e4af17d8e52  movaps [rsp+0x10], xmm2
00007e4af17d8e57  movaps [rsp+0x20], xmm1
00007e4af17d8e5c  lea rdi, [rsp]
00007e4af17d8e60  mov esi, 0x00
00007e4af17d8e65  mov rax, 0x6256754A7530
00007e4af17d8e6f  call rax
00007e4af17d8e71  movaps xmm9, [rsp]
00007e4af17d8e76  add rsp, 0x30
00007e4af17d8e7a  vmovaps xmm0, [rsp]
00007e4af17d8e7f  vmovaps xmm1, [rsp+0x10]
00007e4af17d8e85  vmovaps xmm2, [rsp+0x20]
00007e4af17d8e8b  vmovaps xmm3, [rsp+0x30]
00007e4af17d8e91  vmovaps xmm4, [rsp+0x40]
00007e4af17d8e97  vmovaps xmm5, [rsp+0x50]
00007e4af17d8e9d  vmovaps xmm6, [rsp+0x60]
00007e4af17d8ea3  vmovaps xmm7, [rsp+0x70]
00007e4af17d8ea9  vmovaps xmm8, [rsp+0x80]
00007e4af17d8eb2  vmovaps xmm10, [rsp+0x90]
00007e4af17d8ebb  vmovaps xmm11, [rsp+0xA0]
00007e4af17d8ec4  vmovaps xmm12, [rsp+0xB0]
00007e4af17d8ecd  vmovaps xmm13, [rsp+0xC0]
00007e4af17d8ed6  vmovaps xmm14, [rsp+0xD0]
00007e4af17d8edf  vmovaps xmm15, [rsp+0xE0]
00007e4af17d8ee8  add rsp, 0xF0
00007e4af17d8eef  pop r11
00007e4af17d8ef1  pop r10
00007e4af17d8ef3  pop r9
00007e4af17d8ef5  pop r8
00007e4af17d8ef7  pop rsi
00007e4af17d8ef8  pop rdi
00007e4af17d8ef9  pop rdx
00007e4af17d8efa  pop rcx
00007e4af17d8efb  pop rax
00007e4af17d8efc  add rsp, 0x08
00007e4af17d8f00  jmp 0x00007E4AF17D61A1
00007e4af17d8f05  sub rsp, 0x08
00007e4af17d8f09  push rax
00007e4af17d8f0a  push rcx
00007e4af17d8f0b  push rdx
00007e4af17d8f0c  push rdi
00007e4af17d8f0d  push rsi
00007e4af17d8f0e  push r8
00007e4af17d8f10  push r9
00007e4af17d8f12  push r10
00007e4af17d8f14  push r11
00007e4af17d8f16  sub rsp, 0xF0
00007e4af17d8f1d  vmovaps [rsp], xmm0
00007e4af17d8f22  vmovaps [rsp+0x10], xmm2
00007e4af17d8f28  vmovaps [rsp+0x20], xmm3
00007e4af17d8f2e  vmovaps [rsp+0x30], xmm4
00007e4af17d8f34  vmovaps [rsp+0x40], xmm5
00007e4af17d8f3a  vmovaps [rsp+0x50], xmm6
00007e4af17d8f40  vmovaps [rsp+0x60], xmm7
00007e4af17d8f46  vmovaps [rsp+0x70], xmm8
00007e4af17d8f4c  vmovaps [rsp+0x80], xmm9
00007e4af17d8f55  vmovaps [rsp+0x90], xmm10
00007e4af17d8f5e  vmovaps [rsp+0xA0], xmm11
00007e4af17d8f67  vmovaps [rsp+0xB0], xmm12
00007e4af17d8f70  vmovaps [rsp+0xC0], xmm13
00007e4af17d8f79  vmovaps [rsp+0xD0], xmm14
00007e4af17d8f82  vmovaps [rsp+0xE0], xmm15
00007e4af17d8f8b  sub rsp, 0x30
00007e4af17d8f8f  movaps [rsp], xmm1
00007e4af17d8f93  movaps [rsp+0x10], xmm15
00007e4af17d8f99  movaps [rsp+0x20], xmm6
00007e4af17d8f9e  lea rdi, [rsp]
00007e4af17d8fa2  mov esi, 0x00
00007e4af17d8fa7  mov rax, 0x6256754A7530
00007e4af17d8fb1  call rax
00007e4af17d8fb3  movaps xmm1, [rsp]
00007e4af17d8fb7  add rsp, 0x30
00007e4af17d8fbb  vmovaps xmm0, [rsp]
00007e4af17d8fc0  vmovaps xmm2, [rsp+0x10]
00007e4af17d8fc6  vmovaps xmm3, [rsp+0x20]
00007e4af17d8fcc  vmovaps xmm4, [rsp+0x30]
00007e4af17d8fd2  vmovaps xmm5, [rsp+0x40]
00007e4af17d8fd8  vmovaps xmm6, [rsp+0x50]
00007e4af17d8fde  vmovaps xmm7, [rsp+0x60]
00007e4af17d8fe4  vmovaps xmm8, [rsp+0x70]
00007e4af17d8fea  vmovaps xmm9, [rsp+0x80]
00007e4af17d8ff3  vmovaps xmm10, [rsp+0x90]
00007e4af17d8ffc  vmovaps xmm11, [rsp+0xA0]
00007e4af17d9005  vmovaps xmm12, [rsp+0xB0]
00007e4af17d900e  vmovaps xmm13, [rsp+0xC0]
00007e4af17d9017  vmovaps xmm14, [rsp+0xD0]
00007e4af17d9020  vmovaps xmm15, [rsp+0xE0]
00007e4af17d9029  add rsp, 0xF0
00007e4af17d9030  pop r11
00007e4af17d9032  pop r10
00007e4af17d9034  pop r9
00007e4af17d9036  pop r8
00007e4af17d9038  pop rsi
00007e4af17d9039  pop rdi
00007e4af17d903a  pop rdx
00007e4af17d903b  pop rcx
00007e4af17d903c  pop rax
00007e4af17d903d  add rsp, 0x08
00007e4af17d9041  jmp 0x00007E4AF17D61C2
00007e4af17d9046  sub rsp, 0x08
00007e4af17d904a  push rax
00007e4af17d904b  push rcx
00007e4af17d904c  push rdx
00007e4af17d904d  push rdi
00007e4af17d904e  push rsi
00007e4af17d904f  push r8
00007e4af17d9051  push r9
00007e4af17d9053  push r10
00007e4af17d9055  push r11
00007e4af17d9057  sub rsp, 0xF0
00007e4af17d905e  vmovaps [rsp], xmm0
00007e4af17d9063  vmovaps [rsp+0x10], xmm1
00007e4af17d9069  vmovaps [rsp+0x20], xmm2
00007e4af17d906f  vmovaps [rsp+0x30], xmm3
00007e4af17d9075  vmovaps [rsp+0x40], xmm4
00007e4af17d907b  vmovaps [rsp+0x50], xmm5
00007e4af17d9081  vmovaps [rsp+0x60], xmm6
00007e4af17d9087  vmovaps [rsp+0x70], xmm7
00007e4af17d908d  vmovaps [rsp+0x80], xmm8
00007e4af17d9096  vmovaps [rsp+0x90], xmm9
00007e4af17d909f  vmovaps [rsp+0xA0], xmm10
00007e4af17d90a8  vmovaps [rsp+0xB0], xmm11
00007e4af17d90b1  vmovaps [rsp+0xC0], xmm12
00007e4af17d90ba  vmovaps [rsp+0xD0], xmm13
00007e4af17d90c3  vmovaps [rsp+0xE0], xmm14
00007e4af17d90cc  sub rsp, 0x30
00007e4af17d90d0  movaps [rsp], xmm15
00007e4af17d90d5  movaps [rsp+0x10], xmm5
00007e4af17d90da  movaps [rsp+0x20], xmm3
00007e4af17d90df  lea rdi, [rsp]
00007e4af17d90e3  mov esi, 0x00
00007e4af17d90e8  mov rax, 0x6256754A7530
00007e4af17d90f2  call rax
00007e4af17d90f4  movaps xmm15, [rsp]
00007e4af17d90f9  add rsp, 0x30
00007e4af17d90fd  vmovaps xmm0, [rsp]
00007e4af17d9102  vmovaps xmm1, [rsp+0x10]
00007e4af17d9108  vmovaps xmm2, [rsp+0x20]
00007e4af17d910e  vmovaps xmm3, [rsp+0x30]
00007e4af17d9114  vmovaps xmm4, [rsp+0x40]
00007e4af17d911a  vmovaps xmm5, [rsp+0x50]
00007e4af17d9120  vmovaps xmm6, [rsp+0x60]
00007e4af17d9126  vmovaps xmm7, [rsp+0x70]
00007e4af17d912c  vmovaps xmm8, [rsp+0x80]
00007e4af17d9135  vmovaps xmm9, [rsp+0x90]
00007e4af17d913e  vmovaps xmm10, [rsp+0xA0]
00007e4af17d9147  vmovaps xmm11, [rsp+0xB0]
00007e4af17d9150  vmovaps xmm12, [rsp+0xC0]
00007e4af17d9159  vmovaps xmm13, [rsp+0xD0]
00007e4af17d9162  vmovaps xmm14, [rsp+0xE0]
00007e4af17d916b  add rsp, 0xF0
00007e4af17d9172  pop r11
00007e4af17d9174  pop r10
00007e4af17d9176  pop r9
00007e4af17d9178  pop r8
00007e4af17d917a  pop rsi
00007e4af17d917b  pop rdi
00007e4af17d917c  pop rdx
00007e4af17d917d  pop rcx
00007e4af17d917e  pop rax
00007e4af17d917f  add rsp, 0x08
00007e4af17d9183  jmp 0x00007E4AF17D61DC
00007e4af17d9188  sub rsp, 0x08
00007e4af17d918c  push rax
00007e4af17d918d  push rcx
00007e4af17d918e  push rdx
00007e4af17d918f  push rdi
00007e4af17d9190  push rsi
00007e4af17d9191  push r8
00007e4af17d9193  push r9
00007e4af17d9195  push r10
00007e4af17d9197  push r11
00007e4af17d9199  sub rsp, 0xF0
00007e4af17d91a0  vmovaps [rsp], xmm0
00007e4af17d91a5  vmovaps [rsp+0x10], xmm1
00007e4af17d91ab  vmovaps [rsp+0x20], xmm2
00007e4af17d91b1  vmovaps [rsp+0x30], xmm3
00007e4af17d91b7  vmovaps [rsp+0x40], xmm4
00007e4af17d91bd  vmovaps [rsp+0x50], xmm6
00007e4af17d91c3  vmovaps [rsp+0x60], xmm7
00007e4af17d91c9  vmovaps [rsp+0x70], xmm8
00007e4af17d91cf  vmovaps [rsp+0x80], xmm9
00007e4af17d91d8  vmovaps [rsp+0x90], xmm10
00007e4af17d91e1  vmovaps [rsp+0xA0], xmm11
00007e4af17d91ea  vmovaps [rsp+0xB0], xmm12
00007e4af17d91f3  vmovaps [rsp+0xC0], xmm13
00007e4af17d91fc  vmovaps [rsp+0xD0], xmm14
00007e4af17d9205  vmovaps [rsp+0xE0], xmm15
00007e4af17d920e  sub rsp, 0x30
00007e4af17d9212  movaps [rsp], xmm5
00007e4af17d9216  movaps [rsp+0x10], xmm8
00007e4af17d921c  movaps [rsp+0x20], xmm6
00007e4af17d9221  lea rdi, [rsp]
00007e4af17d9225  mov esi, 0x00
00007e4af17d922a  mov rax, 0x6256754A7530
00007e4af17d9234  call rax
00007e4af17d9236  movaps xmm5, [rsp]
00007e4af17d923a  add rsp, 0x30
00007e4af17d923e  vmovaps xmm0, [rsp]
00007e4af17d9243  vmovaps xmm1, [rsp+0x10]
00007e4af17d9249  vmovaps xmm2, [rsp+0x20]
00007e4af17d924f  vmovaps xmm3, [rsp+0x30]
00007e4af17d9255  vmovaps xmm4, [rsp+0x40]
00007e4af17d925b  vmovaps xmm6, [rsp+0x50]
00007e4af17d9261  vmovaps xmm7, [rsp+0x60]
00007e4af17d9267  vmovaps xmm8, [rsp+0x70]
00007e4af17d926d  vmovaps xmm9, [rsp+0x80]
00007e4af17d9276  vmovaps xmm10, [rsp+0x90]
00007e4af17d927f  vmovaps xmm11, [rsp+0xA0]
00007e4af17d9288  vmovaps xmm12, [rsp+0xB0]
00007e4af17d9291  vmovaps xmm13, [rsp+0xC0]
00007e4af17d929a  vmovaps xmm14, [rsp+0xD0]
00007e4af17d92a3  vmovaps xmm15, [rsp+0xE0]
00007e4af17d92ac  add rsp, 0xF0
00007e4af17d92b3  pop r11
00007e4af17d92b5  pop r10
00007e4af17d92b7  pop r9
00007e4af17d92b9  pop r8
00007e4af17d92bb  pop rsi
00007e4af17d92bc  pop rdi
00007e4af17d92bd  pop rdx
00007e4af17d92be  pop rcx
00007e4af17d92bf  pop rax
00007e4af17d92c0  add rsp, 0x08
00007e4af17d92c4  jmp 0x00007E4AF17D6200
00007e4af17d92c9  sub rsp, 0x08
00007e4af17d92cd  push rax
00007e4af17d92ce  push rcx
00007e4af17d92cf  push rdx
00007e4af17d92d0  push rdi
00007e4af17d92d1  push rsi
00007e4af17d92d2  push r8
00007e4af17d92d4  push r9
00007e4af17d92d6  push r10
00007e4af17d92d8  push r11
00007e4af17d92da  sub rsp, 0xF0
00007e4af17d92e1  vmovaps [rsp], xmm0
00007e4af17d92e6  vmovaps [rsp+0x10], xmm1
00007e4af17d92ec  vmovaps [rsp+0x20], xmm2
00007e4af17d92f2  vmovaps [rsp+0x30], xmm3
00007e4af17d92f8  vmovaps [rsp+0x40], xmm4
00007e4af17d92fe  vmovaps [rsp+0x50], xmm5
00007e4af17d9304  vmovaps [rsp+0x60], xmm7
00007e4af17d930a  vmovaps [rsp+0x70], xmm8
00007e4af17d9310  vmovaps [rsp+0x80], xmm9
00007e4af17d9319  vmovaps [rsp+0x90], xmm10
00007e4af17d9322  vmovaps [rsp+0xA0], xmm11
00007e4af17d932b  vmovaps [rsp+0xB0], xmm12
00007e4af17d9334  vmovaps [rsp+0xC0], xmm13
00007e4af17d933d  vmovaps [rsp+0xD0], xmm14
00007e4af17d9346  vmovaps [rsp+0xE0], xmm15
00007e4af17d934f  sub rsp, 0x30
00007e4af17d9353  movaps [rsp], xmm6
00007e4af17d9357  movaps [rsp+0x10], xmm10
00007e4af17d935d  movaps [rsp+0x20], xmm8
00007e4af17d9363  lea rdi, [rsp]
00007e4af17d9367  mov esi, 0x00
00007e4af17d936c  mov rax, 0x6256754A7530
00007e4af17d9376  call rax
00007e4af17d9378  movaps xmm6, [rsp]
00007e4af17d937c  add rsp, 0x30
00007e4af17d9380  vmovaps xmm0, [rsp]
00007e4af17d9385  vmovaps xmm1, [rsp+0x10]
00007e4af17d938b  vmovaps xmm2, [rsp+0x20]
00007e4af17d9391  vmovaps xmm3, [rsp+0x30]
00007e4af17d9397  vmovaps xmm4, [rsp+0x40]
00007e4af17d939d  vmovaps xmm5, [rsp+0x50]
00007e4af17d93a3  vmovaps xmm7, [rsp+0x60]
00007e4af17d93a9  vmovaps xmm8, [rsp+0x70]
00007e4af17d93af  vmovaps xmm9, [rsp+0x80]
00007e4af17d93b8  vmovaps xmm10, [rsp+0x90]
00007e4af17d93c1  vmovaps xmm11, [rsp+0xA0]
00007e4af17d93ca  vmovaps xmm12, [rsp+0xB0]
00007e4af17d93d3  vmovaps xmm13, [rsp+0xC0]
00007e4af17d93dc  vmovaps xmm14, [rsp+0xD0]
00007e4af17d93e5  vmovaps xmm15, [rsp+0xE0]
00007e4af17d93ee  add rsp, 0xF0
00007e4af17d93f5  pop r11
00007e4af17d93f7  pop r10
00007e4af17d93f9  pop r9
00007e4af17d93fb  pop r8
00007e4af17d93fd  pop rsi
00007e4af17d93fe  pop rdi
00007e4af17d93ff  pop rdx
00007e4af17d9400  pop rcx
00007e4af17d9401  pop rax
00007e4af17d9402  add rsp, 0x08
00007e4af17d9406  jmp 0x00007E4AF17D6225
00007e4af17d940b  sub rsp, 0x08
00007e4af17d940f  push rax
00007e4af17d9410  push rcx
00007e4af17d9411  push rdx
00007e4af17d9412  push rdi
00007e4af17d9413  push rsi
00007e4af17d9414  push r8
00007e4af17d9416  push r9
00007e4af17d9418  push r10
00007e4af17d941a  push r11
00007e4af17d941c  sub rsp, 0xF0
00007e4af17d9423  vmovaps [rsp], xmm0
00007e4af17d9428  vmovaps [rsp+0x10], xmm1
00007e4af17d942e  vmovaps [rsp+0x20], xmm2
00007e4af17d9434  vmovaps [rsp+0x30], xmm3
00007e4af17d943a  vmovaps [rsp+0x40], xmm4
00007e4af17d9440  vmovaps [rsp+0x50], xmm5
00007e4af17d9446  vmovaps [rsp+0x60], xmm6
00007e4af17d944c  vmovaps [rsp+0x70], xmm7
00007e4af17d9452  vmovaps [rsp+0x80], xmm8
00007e4af17d945b  vmovaps [rsp+0x90], xmm9
00007e4af17d9464  vmovaps [rsp+0xA0], xmm11
00007e4af17d946d  vmovaps [rsp+0xB0], xmm12
00007e4af17d9476  vmovaps [rsp+0xC0], xmm13
00007e4af17d947f  vmovaps [rsp+0xD0], xmm14
00007e4af17d9488  vmovaps [rsp+0xE0], xmm15
00007e4af17d9491  sub rsp, 0x30
00007e4af17d9495  movaps [rsp], xmm10
00007e4af17d949a  movaps [rsp+0x10], xmm8
00007e4af17d94a0  movaps [rsp+0x20], xmm14
00007e4af17d94a6  lea rdi, [rsp]
00007e4af17d94aa  mov esi, 0x00
00007e4af17d94af  mov rax, 0x6256754A7530
00007e4af17d94b9  call rax
00007e4af17d94bb  movaps xmm10, [rsp]
00007e4af17d94c0  add rsp, 0x30
00007e4af17d94c4  vmovaps xmm0, [rsp]
00007e4af17d94c9  vmovaps xmm1, [rsp+0x10]
00007e4af17d94cf  vmovaps xmm2, [rsp+0x20]
00007e4af17d94d5  vmovaps xmm3, [rsp+0x30]
00007e4af17d94db  vmovaps xmm4, [rsp+0x40]
00007e4af17d94e1  vmovaps xmm5, [rsp+0x50]
00007e4af17d94e7  vmovaps xmm6, [rsp+0x60]
00007e4af17d94ed  vmovaps xmm7, [rsp+0x70]
00007e4af17d94f3  vmovaps xmm8, [rsp+0x80]
00007e4af17d94fc  vmovaps xmm9, [rsp+0x90]
00007e4af17d9505  vmovaps xmm11, [rsp+0xA0]
00007e4af17d950e  vmovaps xmm12, [rsp+0xB0]
00007e4af17d9517  vmovaps xmm13, [rsp+0xC0]
00007e4af17d9520  vmovaps xmm14, [rsp+0xD0]
00007e4af17d9529  vmovaps xmm15, [rsp+0xE0]
00007e4af17d9532  add rsp, 0xF0
00007e4af17d9539  pop r11
00007e4af17d953b  pop r10
00007e4af17d953d  pop r9
00007e4af17d953f  pop r8
00007e4af17d9541  pop rsi
00007e4af17d9542  pop rdi
00007e4af17d9543  pop rdx
00007e4af17d9544  pop rcx
00007e4af17d9545  pop rax
00007e4af17d9546  add rsp, 0x08
00007e4af17d954a  jmp 0x00007E4AF17D6245
00007e4af17d954f  sub rsp, 0x08
00007e4af17d9553  push rax
00007e4af17d9554  push rcx
00007e4af17d9555  push rdx
00007e4af17d9556  push rdi
00007e4af17d9557  push rsi
00007e4af17d9558  push r8
00007e4af17d955a  push r9
00007e4af17d955c  push r10
00007e4af17d955e  push r11
00007e4af17d9560  sub rsp, 0xF0
00007e4af17d9567  vmovaps [rsp], xmm0
00007e4af17d956c  vmovaps [rsp+0x10], xmm1
00007e4af17d9572  vmovaps [rsp+0x20], xmm2
00007e4af17d9578  vmovaps [rsp+0x30], xmm3
00007e4af17d957e  vmovaps [rsp+0x40], xmm4
00007e4af17d9584  vmovaps [rsp+0x50], xmm5
00007e4af17d958a  vmovaps [rsp+0x60], xmm6
00007e4af17d9590  vmovaps [rsp+0x70], xmm7
00007e4af17d9596  vmovaps [rsp+0x80], xmm8
00007e4af17d959f  vmovaps [rsp+0x90], xmm9
00007e4af17d95a8  vmovaps [rsp+0xA0], xmm10
00007e4af17d95b1  vmovaps [rsp+0xB0], xmm11
00007e4af17d95ba  vmovaps [rsp+0xC0], xmm12
00007e4af17d95c3  vmovaps [rsp+0xD0], xmm13
00007e4af17d95cc  vmovaps [rsp+0xE0], xmm15
00007e4af17d95d5  sub rsp, 0x30
00007e4af17d95d9  movaps [rsp], xmm14
00007e4af17d95de  movaps [rsp+0x10], xmm8
00007e4af17d95e4  movaps [rsp+0x20], xmm4
00007e4af17d95e9  lea rdi, [rsp]
00007e4af17d95ed  mov esi, 0x00
00007e4af17d95f2  mov rax, 0x6256754A7530
00007e4af17d95fc  call rax
00007e4af17d95fe  movaps xmm14, [rsp]
00007e4af17d9603  add rsp, 0x30
00007e4af17d9607  vmovaps xmm0, [rsp]
00007e4af17d960c  vmovaps xmm1, [rsp+0x10]
00007e4af17d9612  vmovaps xmm2, [rsp+0x20]
00007e4af17d9618  vmovaps xmm3, [rsp+0x30]
00007e4af17d961e  vmovaps xmm4, [rsp+0x40]
00007e4af17d9624  vmovaps xmm5, [rsp+0x50]
00007e4af17d962a  vmovaps xmm6, [rsp+0x60]
00007e4af17d9630  vmovaps xmm7, [rsp+0x70]
00007e4af17d9636  vmovaps xmm8, [rsp+0x80]
00007e4af17d963f  vmovaps xmm9, [rsp+0x90]
00007e4af17d9648  vmovaps xmm10, [rsp+0xA0]
00007e4af17d9651  vmovaps xmm11, [rsp+0xB0]
00007e4af17d965a  vmovaps xmm12, [rsp+0xC0]
00007e4af17d9663  vmovaps xmm13, [rsp+0xD0]
00007e4af17d966c  vmovaps xmm15, [rsp+0xE0]
00007e4af17d9675  add rsp, 0xF0
00007e4af17d967c  pop r11
00007e4af17d967e  pop r10
00007e4af17d9680  pop r9
00007e4af17d9682  pop r8
00007e4af17d9684  pop rsi
00007e4af17d9685  pop rdi
00007e4af17d9686  pop rdx
00007e4af17d9687  pop rcx
00007e4af17d9688  pop rax
00007e4af17d9689  add rsp, 0x08
00007e4af17d968d  jmp 0x00007E4AF17D6265
00007e4af17d9692  sub rsp, 0x08
00007e4af17d9696  push rax
00007e4af17d9697  push rcx
00007e4af17d9698  push rdx
00007e4af17d9699  push rdi
00007e4af17d969a  push rsi
00007e4af17d969b  push r8
00007e4af17d969d  push r9
00007e4af17d969f  push r10
00007e4af17d96a1  push r11
00007e4af17d96a3  sub rsp, 0xF0
00007e4af17d96aa  vmovaps [rsp], xmm0
00007e4af17d96af  vmovaps [rsp+0x10], xmm1
00007e4af17d96b5  vmovaps [rsp+0x20], xmm2
00007e4af17d96bb  vmovaps [rsp+0x30], xmm3
00007e4af17d96c1  vmovaps [rsp+0x40], xmm5
00007e4af17d96c7  vmovaps [rsp+0x50], xmm6
00007e4af17d96cd  vmovaps [rsp+0x60], xmm7
00007e4af17d96d3  vmovaps [rsp+0x70], xmm8
00007e4af17d96d9  vmovaps [rsp+0x80], xmm9
00007e4af17d96e2  vmovaps [rsp+0x90], xmm10
00007e4af17d96eb  vmovaps [rsp+0xA0], xmm11
00007e4af17d96f4  vmovaps [rsp+0xB0], xmm12
00007e4af17d96fd  vmovaps [rsp+0xC0], xmm13
00007e4af17d9706  vmovaps [rsp+0xD0], xmm14
00007e4af17d970f  vmovaps [rsp+0xE0], xmm15
00007e4af17d9718  sub rsp, 0x30
00007e4af17d971c  movaps [rsp], xmm4
00007e4af17d9720  movaps [rsp+0x10], xmm13
00007e4af17d9726  movaps [rsp+0x20], xmm8
00007e4af17d972c  lea rdi, [rsp]
00007e4af17d9730  mov esi, 0x00
00007e4af17d9735  mov rax, 0x6256754A7530
00007e4af17d973f  call rax
00007e4af17d9741  movaps xmm4, [rsp]
00007e4af17d9745  add rsp, 0x30
00007e4af17d9749  vmovaps xmm0, [rsp]
00007e4af17d974e  vmovaps xmm1, [rsp+0x10]
00007e4af17d9754  vmovaps xmm2, [rsp+0x20]
00007e4af17d975a  vmovaps xmm3, [rsp+0x30]
00007e4af17d9760  vmovaps xmm5, [rsp+0x40]
00007e4af17d9766  vmovaps xmm6, [rsp+0x50]
00007e4af17d976c  vmovaps xmm7, [rsp+0x60]
00007e4af17d9772  vmovaps xmm8, [rsp+0x70]
00007e4af17d9778  vmovaps xmm9, [rsp+0x80]
00007e4af17d9781  vmovaps xmm10, [rsp+0x90]
00007e4af17d978a  vmovaps xmm11, [rsp+0xA0]
00007e4af17d9793  vmovaps xmm12, [rsp+0xB0]
00007e4af17d979c  vmovaps xmm13, [rsp+0xC0]
00007e4af17d97a5  vmovaps xmm14, [rsp+0xD0]
00007e4af17d97ae  vmovaps xmm15, [rsp+0xE0]
00007e4af17d97b7  add rsp, 0xF0
00007e4af17d97be  pop r11
00007e4af17d97c0  pop r10
00007e4af17d97c2  pop r9
00007e4af17d97c4  pop r8
00007e4af17d97c6  pop rsi
00007e4af17d97c7  pop rdi
00007e4af17d97c8  pop rdx
00007e4af17d97c9  pop rcx
00007e4af17d97ca  pop rax
00007e4af17d97cb  add rsp, 0x08
00007e4af17d97cf  jmp 0x00007E4AF17D628A
00007e4af17d97d4  sub rsp, 0x08
00007e4af17d97d8  push rax
00007e4af17d97d9  push rcx
00007e4af17d97da  push rdx
00007e4af17d97db  push rdi
00007e4af17d97dc  push rsi
00007e4af17d97dd  push r8
00007e4af17d97df  push r9
00007e4af17d97e1  push r10
00007e4af17d97e3  push r11
00007e4af17d97e5  sub rsp, 0xF0
00007e4af17d97ec  vmovaps [rsp], xmm0
00007e4af17d97f1  vmovaps [rsp+0x10], xmm1
00007e4af17d97f7  vmovaps [rsp+0x20], xmm2
00007e4af17d97fd  vmovaps [rsp+0x30], xmm3
00007e4af17d9803  vmovaps [rsp+0x40], xmm4
00007e4af17d9809  vmovaps [rsp+0x50], xmm5
00007e4af17d980f  vmovaps [rsp+0x60], xmm6
00007e4af17d9815  vmovaps [rsp+0x70], xmm7
00007e4af17d981b  vmovaps [rsp+0x80], xmm8
00007e4af17d9824  vmovaps [rsp+0x90], xmm9
00007e4af17d982d  vmovaps [rsp+0xA0], xmm10
00007e4af17d9836  vmovaps [rsp+0xB0], xmm11
00007e4af17d983f  vmovaps [rsp+0xC0], xmm12
00007e4af17d9848  vmovaps [rsp+0xD0], xmm14
00007e4af17d9851  vmovaps [rsp+0xE0], xmm15
00007e4af17d985a  sub rsp, 0x30
00007e4af17d985e  movaps [rsp], xmm13
00007e4af17d9863  movaps [rsp+0x10], xmm15
00007e4af17d9869  movaps [rsp+0x20], xmm9
00007e4af17d986f  lea rdi, [rsp]
00007e4af17d9873  mov esi, 0x00
00007e4af17d9878  mov rax, 0x6256754A7530
00007e4af17d9882  call rax
00007e4af17d9884  movaps xmm13, [rsp]
00007e4af17d9889  add rsp, 0x30
00007e4af17d988d  vmovaps xmm0, [rsp]
00007e4af17d9892  vmovaps xmm1, [rsp+0x10]
00007e4af17d9898  vmovaps xmm2, [rsp+0x20]
00007e4af17d989e  vmovaps xmm3, [rsp+0x30]
00007e4af17d98a4  vmovaps xmm4, [rsp+0x40]
00007e4af17d98aa  vmovaps xmm5, [rsp+0x50]
00007e4af17d98b0  vmovaps xmm6, [rsp+0x60]
00007e4af17d98b6  vmovaps xmm7, [rsp+0x70]
00007e4af17d98bc  vmovaps xmm8, [rsp+0x80]
00007e4af17d98c5  vmovaps xmm9, [rsp+0x90]
00007e4af17d98ce  vmovaps xmm10, [rsp+0xA0]
00007e4af17d98d7  vmovaps xmm11, [rsp+0xB0]
00007e4af17d98e0  vmovaps xmm12, [rsp+0xC0]
00007e4af17d98e9  vmovaps xmm14, [rsp+0xD0]
00007e4af17d98f2  vmovaps xmm15, [rsp+0xE0]
00007e4af17d98fb  add rsp, 0xF0
00007e4af17d9902  pop r11
00007e4af17d9904  pop r10
00007e4af17d9906  pop r9
00007e4af17d9908  pop r8
00007e4af17d990a  pop rsi
00007e4af17d990b  pop rdi
00007e4af17d990c  pop rdx
00007e4af17d990d  pop rcx
00007e4af17d990e  pop rax
00007e4af17d990f  add rsp, 0x08
00007e4af17d9913  jmp 0x00007E4AF17D62A5
00007e4af17d9918  sub rsp, 0x08
00007e4af17d991c  push rax
00007e4af17d991d  push rcx
00007e4af17d991e  push rdx
00007e4af17d991f  push rdi
00007e4af17d9920  push rsi
00007e4af17d9921  push r8
00007e4af17d9923  push r9
00007e4af17d9925  push r10
00007e4af17d9927  push r11
00007e4af17d9929  sub rsp, 0xF0
00007e4af17d9930  vmovaps [rsp], xmm0
00007e4af17d9935  vmovaps [rsp+0x10], xmm1
00007e4af17d993b  vmovaps [rsp+0x20], xmm2
00007e4af17d9941  vmovaps [rsp+0x30], xmm3
00007e4af17d9947  vmovaps [rsp+0x40], xmm4
00007e4af17d994d  vmovaps [rsp+0x50], xmm5
00007e4af17d9953  vmovaps [rsp+0x60], xmm6
00007e4af17d9959  vmovaps [rsp+0x70], xmm7
00007e4af17d995f  vmovaps [rsp+0x80], xmm8
00007e4af17d9968  vmovaps [rsp+0x90], xmm9
00007e4af17d9971  vmovaps [rsp+0xA0], xmm10
00007e4af17d997a  vmovaps [rsp+0xB0], xmm11
00007e4af17d9983  vmovaps [rsp+0xC0], xmm12
00007e4af17d998c  vmovaps [rsp+0xD0], xmm13
00007e4af17d9995  vmovaps [rsp+0xE0], xmm14
00007e4af17d999e  sub rsp, 0x30
00007e4af17d99a2  movaps [rsp], xmm15
00007e4af17d99a7  movaps [rsp+0x10], xmm1
00007e4af17d99ac  movaps [rsp+0x20], xmm5
00007e4af17d99b1  lea rdi, [rsp]
00007e4af17d99b5  mov esi, 0x00
00007e4af17d99ba  mov rax, 0x6256754A7530
00007e4af17d99c4  call rax
00007e4af17d99c6  movaps xmm15, [rsp]
00007e4af17d99cb  add rsp, 0x30
00007e4af17d99cf  vmovaps xmm0, [rsp]
00007e4af17d99d4  vmovaps xmm1, [rsp+0x10]
00007e4af17d99da  vmovaps xmm2, [rsp+0x20]
00007e4af17d99e0  vmovaps xmm3, [rsp+0x30]
00007e4af17d99e6  vmovaps xmm4, [rsp+0x40]
00007e4af17d99ec  vmovaps xmm5, [rsp+0x50]
00007e4af17d99f2  vmovaps xmm6, [rsp+0x60]
00007e4af17d99f8  vmovaps xmm7, [rsp+0x70]
00007e4af17d99fe  vmovaps xmm8, [rsp+0x80]
00007e4af17d9a07  vmovaps xmm9, [rsp+0x90]
00007e4af17d9a10  vmovaps xmm10, [rsp+0xA0]
00007e4af17d9a19  vmovaps xmm11, [rsp+0xB0]
00007e4af17d9a22  vmovaps xmm12, [rsp+0xC0]
00007e4af17d9a2b  vmovaps xmm13, [rsp+0xD0]
00007e4af17d9a34  vmovaps xmm14, [rsp+0xE0]
00007e4af17d9a3d  add rsp, 0xF0
00007e4af17d9a44  pop r11
00007e4af17d9a46  pop r10
00007e4af17d9a48  pop r9
00007e4af17d9a4a  pop r8
00007e4af17d9a4c  pop rsi
00007e4af17d9a4d  pop rdi
00007e4af17d9a4e  pop rdx
00007e4af17d9a4f  pop rcx
00007e4af17d9a50  pop rax
00007e4af17d9a51  add rsp, 0x08
00007e4af17d9a55  jmp 0x00007E4AF17D62C0
00007e4af17d9a5a  call 0x00007E4AF16D64F0
00007e4af17d9a5f  jmp 0x00007E4AF17D631B
00007e4af17d9a64  sub rsp, 0x08
00007e4af17d9a68  push rax
00007e4af17d9a69  push rcx
00007e4af17d9a6a  push rdx
00007e4af17d9a6b  push rdi
00007e4af17d9a6c  push rsi
00007e4af17d9a6d  push r8
00007e4af17d9a6f  push r9
00007e4af17d9a71  push r10
00007e4af17d9a73  push r11
00007e4af17d9a75  sub rsp, 0xF0
00007e4af17d9a7c  vmovaps [rsp], xmm0
00007e4af17d9a81  vmovaps [rsp+0x10], xmm1
00007e4af17d9a87  vmovaps [rsp+0x20], xmm2
00007e4af17d9a8d  vmovaps [rsp+0x30], xmm3
00007e4af17d9a93  vmovaps [rsp+0x40], xmm4
00007e4af17d9a99  vmovaps [rsp+0x50], xmm5
00007e4af17d9a9f  vmovaps [rsp+0x60], xmm6
00007e4af17d9aa5  vmovaps [rsp+0x70], xmm7
00007e4af17d9aab  vmovaps [rsp+0x80], xmm8
00007e4af17d9ab4  vmovaps [rsp+0x90], xmm10
00007e4af17d9abd  vmovaps [rsp+0xA0], xmm11
00007e4af17d9ac6  vmovaps [rsp+0xB0], xmm12
00007e4af17d9acf  vmovaps [rsp+0xC0], xmm13
00007e4af17d9ad8  vmovaps [rsp+0xD0], xmm14
00007e4af17d9ae1  vmovaps [rsp+0xE0], xmm15
00007e4af17d9aea  sub rsp, 0x30
00007e4af17d9aee  movaps [rsp], xmm9
00007e4af17d9af3  movaps [rsp+0x10], xmm8
00007e4af17d9af9  movaps [rsp+0x20], xmm11
00007e4af17d9aff  lea rdi, [rsp]
00007e4af17d9b03  mov esi, 0x00
00007e4af17d9b08  mov rax, 0x6256754A7530
00007e4af17d9b12  call rax
00007e4af17d9b14  movaps xmm9, [rsp]
00007e4af17d9b19  add rsp, 0x30
00007e4af17d9b1d  vmovaps xmm0, [rsp]
00007e4af17d9b22  vmovaps xmm1, [rsp+0x10]
00007e4af17d9b28  vmovaps xmm2, [rsp+0x20]
00007e4af17d9b2e  vmovaps xmm3, [rsp+0x30]
00007e4af17d9b34  vmovaps xmm4, [rsp+0x40]
00007e4af17d9b3a  vmovaps xmm5, [rsp+0x50]
00007e4af17d9b40  vmovaps xmm6, [rsp+0x60]
00007e4af17d9b46  vmovaps xmm7, [rsp+0x70]
00007e4af17d9b4c  vmovaps xmm8, [rsp+0x80]
00007e4af17d9b55  vmovaps xmm10, [rsp+0x90]
00007e4af17d9b5e  vmovaps xmm11, [rsp+0xA0]
00007e4af17d9b67  vmovaps xmm12, [rsp+0xB0]
00007e4af17d9b70  vmovaps xmm13, [rsp+0xC0]
00007e4af17d9b79  vmovaps xmm14, [rsp+0xD0]
00007e4af17d9b82  vmovaps xmm15, [rsp+0xE0]
00007e4af17d9b8b  add rsp, 0xF0
00007e4af17d9b92  pop r11
00007e4af17d9b94  pop r10
00007e4af17d9b96  pop r9
00007e4af17d9b98  pop r8
00007e4af17d9b9a  pop rsi
00007e4af17d9b9b  pop rdi
00007e4af17d9b9c  pop rdx
00007e4af17d9b9d  pop rcx
00007e4af17d9b9e  pop rax
00007e4af17d9b9f  add rsp, 0x08
00007e4af17d9ba3  jmp 0x00007E4AF17D6352
00007e4af17d9ba8  sub rsp, 0x08
00007e4af17d9bac  push rax
00007e4af17d9bad  push rcx
00007e4af17d9bae  push rdx
00007e4af17d9baf  push rdi
00007e4af17d9bb0  push rsi
00007e4af17d9bb1  push r8
00007e4af17d9bb3  push r9
00007e4af17d9bb5  push r10
00007e4af17d9bb7  push r11
00007e4af17d9bb9  sub rsp, 0xF0
00007e4af17d9bc0  vmovaps [rsp], xmm0
00007e4af17d9bc5  vmovaps [rsp+0x10], xmm1
00007e4af17d9bcb  vmovaps [rsp+0x20], xmm2
00007e4af17d9bd1  vmovaps [rsp+0x30], xmm3
00007e4af17d9bd7  vmovaps [rsp+0x40], xmm4
00007e4af17d9bdd  vmovaps [rsp+0x50], xmm5
00007e4af17d9be3  vmovaps [rsp+0x60], xmm6
00007e4af17d9be9  vmovaps [rsp+0x70], xmm7
00007e4af17d9bef  vmovaps [rsp+0x80], xmm8
00007e4af17d9bf8  vmovaps [rsp+0x90], xmm9
00007e4af17d9c01  vmovaps [rsp+0xA0], xmm10
00007e4af17d9c0a  vmovaps [rsp+0xB0], xmm12
00007e4af17d9c13  vmovaps [rsp+0xC0], xmm13
00007e4af17d9c1c  vmovaps [rsp+0xD0], xmm14
00007e4af17d9c25  vmovaps [rsp+0xE0], xmm15
00007e4af17d9c2e  sub rsp, 0x30
00007e4af17d9c32  movaps [rsp], xmm11
00007e4af17d9c37  movaps [rsp+0x10], xmm10
00007e4af17d9c3d  movaps [rsp+0x20], xmm6
00007e4af17d9c42  lea rdi, [rsp]
00007e4af17d9c46  mov esi, 0x00
00007e4af17d9c4b  mov rax, 0x6256754A7530
00007e4af17d9c55  call rax
00007e4af17d9c57  movaps xmm11, [rsp]
00007e4af17d9c5c  add rsp, 0x30
00007e4af17d9c60  vmovaps xmm0, [rsp]
00007e4af17d9c65  vmovaps xmm1, [rsp+0x10]
00007e4af17d9c6b  vmovaps xmm2, [rsp+0x20]
00007e4af17d9c71  vmovaps xmm3, [rsp+0x30]
00007e4af17d9c77  vmovaps xmm4, [rsp+0x40]
00007e4af17d9c7d  vmovaps xmm5, [rsp+0x50]
00007e4af17d9c83  vmovaps xmm6, [rsp+0x60]
00007e4af17d9c89  vmovaps xmm7, [rsp+0x70]
00007e4af17d9c8f  vmovaps xmm8, [rsp+0x80]
00007e4af17d9c98  vmovaps xmm9, [rsp+0x90]
00007e4af17d9ca1  vmovaps xmm10, [rsp+0xA0]
00007e4af17d9caa  vmovaps xmm12, [rsp+0xB0]
00007e4af17d9cb3  vmovaps xmm13, [rsp+0xC0]
00007e4af17d9cbc  vmovaps xmm14, [rsp+0xD0]
00007e4af17d9cc5  vmovaps xmm15, [rsp+0xE0]
00007e4af17d9cce  add rsp, 0xF0
00007e4af17d9cd5  pop r11
00007e4af17d9cd7  pop r10
00007e4af17d9cd9  pop r9
00007e4af17d9cdb  pop r8
00007e4af17d9cdd  pop rsi
00007e4af17d9cde  pop rdi
00007e4af17d9cdf  pop rdx
00007e4af17d9ce0  pop rcx
00007e4af17d9ce1  pop rax
00007e4af17d9ce2  add rsp, 0x08
00007e4af17d9ce6  jmp 0x00007E4AF17D636D
00007e4af17d9ceb  sub rsp, 0x08
00007e4af17d9cef  push rax
00007e4af17d9cf0  push rcx
00007e4af17d9cf1  push rdx
00007e4af17d9cf2  push rdi
00007e4af17d9cf3  push rsi
00007e4af17d9cf4  push r8
00007e4af17d9cf6  push r9
00007e4af17d9cf8  push r10
00007e4af17d9cfa  push r11
00007e4af17d9cfc  sub rsp, 0xF0
00007e4af17d9d03  vmovaps [rsp], xmm0
00007e4af17d9d08  vmovaps [rsp+0x10], xmm1
00007e4af17d9d0e  vmovaps [rsp+0x20], xmm2
00007e4af17d9d14  vmovaps [rsp+0x30], xmm3
00007e4af17d9d1a  vmovaps [rsp+0x40], xmm4
00007e4af17d9d20  vmovaps [rsp+0x50], xmm5
00007e4af17d9d26  vmovaps [rsp+0x60], xmm6
00007e4af17d9d2c  vmovaps [rsp+0x70], xmm7
00007e4af17d9d32  vmovaps [rsp+0x80], xmm8
00007e4af17d9d3b  vmovaps [rsp+0x90], xmm9
00007e4af17d9d44  vmovaps [rsp+0xA0], xmm11
00007e4af17d9d4d  vmovaps [rsp+0xB0], xmm12
00007e4af17d9d56  vmovaps [rsp+0xC0], xmm13
00007e4af17d9d5f  vmovaps [rsp+0xD0], xmm14
00007e4af17d9d68  vmovaps [rsp+0xE0], xmm15
00007e4af17d9d71  sub rsp, 0x30
00007e4af17d9d75  movaps [rsp], xmm10
00007e4af17d9d7a  movaps [rsp+0x10], xmm14
00007e4af17d9d80  movaps [rsp+0x20], xmm4
00007e4af17d9d85  lea rdi, [rsp]
00007e4af17d9d89  mov esi, 0x00
00007e4af17d9d8e  mov rax, 0x6256754A7530
00007e4af17d9d98  call rax
00007e4af17d9d9a  movaps xmm10, [rsp]
00007e4af17d9d9f  add rsp, 0x30
00007e4af17d9da3  vmovaps xmm0, [rsp]
00007e4af17d9da8  vmovaps xmm1, [rsp+0x10]
00007e4af17d9dae  vmovaps xmm2, [rsp+0x20]
00007e4af17d9db4  vmovaps xmm3, [rsp+0x30]
00007e4af17d9dba  vmovaps xmm4, [rsp+0x40]
00007e4af17d9dc0  vmovaps xmm5, [rsp+0x50]
00007e4af17d9dc6  vmovaps xmm6, [rsp+0x60]
00007e4af17d9dcc  vmovaps xmm7, [rsp+0x70]
00007e4af17d9dd2  vmovaps xmm8, [rsp+0x80]
00007e4af17d9ddb  vmovaps xmm9, [rsp+0x90]
00007e4af17d9de4  vmovaps xmm11, [rsp+0xA0]
00007e4af17d9ded  vmovaps xmm12, [rsp+0xB0]
00007e4af17d9df6  vmovaps xmm13, [rsp+0xC0]
00007e4af17d9dff  vmovaps xmm14, [rsp+0xD0]
00007e4af17d9e08  vmovaps xmm15, [rsp+0xE0]
00007e4af17d9e11  add rsp, 0xF0
00007e4af17d9e18  pop r11
00007e4af17d9e1a  pop r10
00007e4af17d9e1c  pop r9
00007e4af17d9e1e  pop r8
00007e4af17d9e20  pop rsi
00007e4af17d9e21  pop rdi
00007e4af17d9e22  pop rdx
00007e4af17d9e23  pop rcx
00007e4af17d9e24  pop rax
00007e4af17d9e25  add rsp, 0x08
00007e4af17d9e29  jmp 0x00007E4AF17D6388
00007e4af17d9e2e  sub rsp, 0x08
00007e4af17d9e32  push rax
00007e4af17d9e33  push rcx
00007e4af17d9e34  push rdx
00007e4af17d9e35  push rdi
00007e4af17d9e36  push rsi
00007e4af17d9e37  push r8
00007e4af17d9e39  push r9
00007e4af17d9e3b  push r10
00007e4af17d9e3d  push r11
00007e4af17d9e3f  sub rsp, 0xF0
00007e4af17d9e46  vmovaps [rsp], xmm0
00007e4af17d9e4b  vmovaps [rsp+0x10], xmm1
00007e4af17d9e51  vmovaps [rsp+0x20], xmm2
00007e4af17d9e57  vmovaps [rsp+0x30], xmm3
00007e4af17d9e5d  vmovaps [rsp+0x40], xmm4
00007e4af17d9e63  vmovaps [rsp+0x50], xmm5
00007e4af17d9e69  vmovaps [rsp+0x60], xmm6
00007e4af17d9e6f  vmovaps [rsp+0x70], xmm7
00007e4af17d9e75  vmovaps [rsp+0x80], xmm9
00007e4af17d9e7e  vmovaps [rsp+0x90], xmm10
00007e4af17d9e87  vmovaps [rsp+0xA0], xmm11
00007e4af17d9e90  vmovaps [rsp+0xB0], xmm12
00007e4af17d9e99  vmovaps [rsp+0xC0], xmm13
00007e4af17d9ea2  vmovaps [rsp+0xD0], xmm14
00007e4af17d9eab  vmovaps [rsp+0xE0], xmm15
00007e4af17d9eb4  sub rsp, 0x30
00007e4af17d9eb8  movaps [rsp], xmm8
00007e4af17d9ebd  movaps [rsp+0x10], xmm1
00007e4af17d9ec2  movaps [rsp+0x20], xmm14
00007e4af17d9ec8  lea rdi, [rsp]
00007e4af17d9ecc  mov esi, 0x00
00007e4af17d9ed1  mov rax, 0x6256754A7530
00007e4af17d9edb  call rax
00007e4af17d9edd  movaps xmm8, [rsp]
00007e4af17d9ee2  add rsp, 0x30
00007e4af17d9ee6  vmovaps xmm0, [rsp]
00007e4af17d9eeb  vmovaps xmm1, [rsp+0x10]
00007e4af17d9ef1  vmovaps xmm2, [rsp+0x20]
00007e4af17d9ef7  vmovaps xmm3, [rsp+0x30]
00007e4af17d9efd  vmovaps xmm4, [rsp+0x40]
00007e4af17d9f03  vmovaps xmm5, [rsp+0x50]
00007e4af17d9f09  vmovaps xmm6, [rsp+0x60]
00007e4af17d9f0f  vmovaps xmm7, [rsp+0x70]
00007e4af17d9f15  vmovaps xmm9, [rsp+0x80]
00007e4af17d9f1e  vmovaps xmm10, [rsp+0x90]
00007e4af17d9f27  vmovaps xmm11, [rsp+0xA0]
00007e4af17d9f30  vmovaps xmm12, [rsp+0xB0]
00007e4af17d9f39  vmovaps xmm13, [rsp+0xC0]
00007e4af17d9f42  vmovaps xmm14, [rsp+0xD0]
00007e4af17d9f4b  vmovaps xmm15, [rsp+0xE0]
00007e4af17d9f54  add rsp, 0xF0
00007e4af17d9f5b  pop r11
00007e4af17d9f5d  pop r10
00007e4af17d9f5f  pop r9
00007e4af17d9f61  pop r8
00007e4af17d9f63  pop rsi
00007e4af17d9f64  pop rdi
00007e4af17d9f65  pop rdx
00007e4af17d9f66  pop rcx
00007e4af17d9f67  pop rax
00007e4af17d9f68  add rsp, 0x08
00007e4af17d9f6c  jmp 0x00007E4AF17D63AE
00007e4af17d9f71  sub rsp, 0x08
00007e4af17d9f75  push rax
00007e4af17d9f76  push rcx
00007e4af17d9f77  push rdx
00007e4af17d9f78  push rdi
00007e4af17d9f79  push rsi
00007e4af17d9f7a  push r8
00007e4af17d9f7c  push r9
00007e4af17d9f7e  push r10
00007e4af17d9f80  push r11
00007e4af17d9f82  sub rsp, 0xF0
00007e4af17d9f89  vmovaps [rsp], xmm0
00007e4af17d9f8e  vmovaps [rsp+0x10], xmm1
00007e4af17d9f94  vmovaps [rsp+0x20], xmm2
00007e4af17d9f9a  vmovaps [rsp+0x30], xmm3
00007e4af17d9fa0  vmovaps [rsp+0x40], xmm4
00007e4af17d9fa6  vmovaps [rsp+0x50], xmm5
00007e4af17d9fac  vmovaps [rsp+0x60], xmm7
00007e4af17d9fb2  vmovaps [rsp+0x70], xmm8
00007e4af17d9fb8  vmovaps [rsp+0x80], xmm9
00007e4af17d9fc1  vmovaps [rsp+0x90], xmm10
00007e4af17d9fca  vmovaps [rsp+0xA0], xmm11
00007e4af17d9fd3  vmovaps [rsp+0xB0], xmm12
00007e4af17d9fdc  vmovaps [rsp+0xC0], xmm13
00007e4af17d9fe5  vmovaps [rsp+0xD0], xmm14
00007e4af17d9fee  vmovaps [rsp+0xE0], xmm15
00007e4af17d9ff7  sub rsp, 0x30
00007e4af17d9ffb  movaps [rsp], xmm6
00007e4af17d9fff  movaps [rsp+0x10], xmm1
00007e4af17da004  movaps [rsp+0x20], xmm14
00007e4af17da00a  lea rdi, [rsp]
00007e4af17da00e  mov esi, 0x00
00007e4af17da013  mov rax, 0x6256754A7530
00007e4af17da01d  call rax
00007e4af17da01f  movaps xmm6, [rsp]
00007e4af17da023  add rsp, 0x30
00007e4af17da027  vmovaps xmm0, [rsp]
00007e4af17da02c  vmovaps xmm1, [rsp+0x10]
00007e4af17da032  vmovaps xmm2, [rsp+0x20]
00007e4af17da038  vmovaps xmm3, [rsp+0x30]
00007e4af17da03e  vmovaps xmm4, [rsp+0x40]
00007e4af17da044  vmovaps xmm5, [rsp+0x50]
00007e4af17da04a  vmovaps xmm7, [rsp+0x60]
00007e4af17da050  vmovaps xmm8, [rsp+0x70]
00007e4af17da056  vmovaps xmm9, [rsp+0x80]
00007e4af17da05f  vmovaps xmm10, [rsp+0x90]
00007e4af17da068  vmovaps xmm11, [rsp+0xA0]
00007e4af17da071  vmovaps xmm12, [rsp+0xB0]
00007e4af17da07a  vmovaps xmm13, [rsp+0xC0]
00007e4af17da083  vmovaps xmm14, [rsp+0xD0]
00007e4af17da08c  vmovaps xmm15, [rsp+0xE0]
00007e4af17da095  add rsp, 0xF0
00007e4af17da09c  pop r11
00007e4af17da09e  pop r10
00007e4af17da0a0  pop r9
00007e4af17da0a2  pop r8
00007e4af17da0a4  pop rsi
00007e4af17da0a5  pop rdi
00007e4af17da0a6  pop rdx
00007e4af17da0a7  pop rcx
00007e4af17da0a8  pop rax
00007e4af17da0a9  add rsp, 0x08
00007e4af17da0ad  jmp 0x00007E4AF17D63DA
00007e4af17da0b2  sub rsp, 0x08
00007e4af17da0b6  push rax
00007e4af17da0b7  push rcx
00007e4af17da0b8  push rdx
00007e4af17da0b9  push rdi
00007e4af17da0ba  push rsi
00007e4af17da0bb  push r8
00007e4af17da0bd  push r9
00007e4af17da0bf  push r10
00007e4af17da0c1  push r11
00007e4af17da0c3  sub rsp, 0xF0
00007e4af17da0ca  vmovaps [rsp], xmm0
00007e4af17da0cf  vmovaps [rsp+0x10], xmm1
00007e4af17da0d5  vmovaps [rsp+0x20], xmm2
00007e4af17da0db  vmovaps [rsp+0x30], xmm3
00007e4af17da0e1  vmovaps [rsp+0x40], xmm4
00007e4af17da0e7  vmovaps [rsp+0x50], xmm5
00007e4af17da0ed  vmovaps [rsp+0x60], xmm6
00007e4af17da0f3  vmovaps [rsp+0x70], xmm7
00007e4af17da0f9  vmovaps [rsp+0x80], xmm8
00007e4af17da102  vmovaps [rsp+0x90], xmm9
00007e4af17da10b  vmovaps [rsp+0xA0], xmm10
00007e4af17da114  vmovaps [rsp+0xB0], xmm11
00007e4af17da11d  vmovaps [rsp+0xC0], xmm12
00007e4af17da126  vmovaps [rsp+0xD0], xmm13
00007e4af17da12f  vmovaps [rsp+0xE0], xmm15
00007e4af17da138  sub rsp, 0x30
00007e4af17da13c  movaps [rsp], xmm14
00007e4af17da141  movaps [rsp+0x10], xmm12
00007e4af17da147  movaps [rsp+0x20], xmm1
00007e4af17da14c  lea rdi, [rsp]
00007e4af17da150  mov esi, 0x00
00007e4af17da155  mov rax, 0x6256754A7530
00007e4af17da15f  call rax
00007e4af17da161  movaps xmm14, [rsp]
00007e4af17da166  add rsp, 0x30
00007e4af17da16a  vmovaps xmm0, [rsp]
00007e4af17da16f  vmovaps xmm1, [rsp+0x10]
00007e4af17da175  vmovaps xmm2, [rsp+0x20]
00007e4af17da17b  vmovaps xmm3, [rsp+0x30]
00007e4af17da181  vmovaps xmm4, [rsp+0x40]
00007e4af17da187  vmovaps xmm5, [rsp+0x50]
00007e4af17da18d  vmovaps xmm6, [rsp+0x60]
00007e4af17da193  vmovaps xmm7, [rsp+0x70]
00007e4af17da199  vmovaps xmm8, [rsp+0x80]
00007e4af17da1a2  vmovaps xmm9, [rsp+0x90]
00007e4af17da1ab  vmovaps xmm10, [rsp+0xA0]
00007e4af17da1b4  vmovaps xmm11, [rsp+0xB0]
00007e4af17da1bd  vmovaps xmm12, [rsp+0xC0]
00007e4af17da1c6  vmovaps xmm13, [rsp+0xD0]
00007e4af17da1cf  vmovaps xmm15, [rsp+0xE0]
00007e4af17da1d8  add rsp, 0xF0
00007e4af17da1df  pop r11
00007e4af17da1e1  pop r10
00007e4af17da1e3  pop r9
00007e4af17da1e5  pop r8
00007e4af17da1e7  pop rsi
00007e4af17da1e8  pop rdi
00007e4af17da1e9  pop rdx
00007e4af17da1ea  pop rcx
00007e4af17da1eb  pop rax
00007e4af17da1ec  add rsp, 0x08
00007e4af17da1f0  jmp 0x00007E4AF17D6400
00007e4af17da1f5  sub rsp, 0x08
00007e4af17da1f9  push rax
00007e4af17da1fa  push rcx
00007e4af17da1fb  push rdx
00007e4af17da1fc  push rdi
00007e4af17da1fd  push rsi
00007e4af17da1fe  push r8
00007e4af17da200  push r9
00007e4af17da202  push r10
00007e4af17da204  push r11
00007e4af17da206  sub rsp, 0xF0
00007e4af17da20d  vmovaps [rsp], xmm0
00007e4af17da212  vmovaps [rsp+0x10], xmm2
00007e4af17da218  vmovaps [rsp+0x20], xmm3
00007e4af17da21e  vmovaps [rsp+0x30], xmm4
00007e4af17da224  vmovaps [rsp+0x40], xmm5
00007e4af17da22a  vmovaps [rsp+0x50], xmm6
00007e4af17da230  vmovaps [rsp+0x60], xmm7
00007e4af17da236  vmovaps [rsp+0x70], xmm8
00007e4af17da23c  vmovaps [rsp+0x80], xmm9
00007e4af17da245  vmovaps [rsp+0x90], xmm10
00007e4af17da24e  vmovaps [rsp+0xA0], xmm11
00007e4af17da257  vmovaps [rsp+0xB0], xmm12
00007e4af17da260  vmovaps [rsp+0xC0], xmm13
00007e4af17da269  vmovaps [rsp+0xD0], xmm14
00007e4af17da272  vmovaps [rsp+0xE0], xmm15
00007e4af17da27b  sub rsp, 0x30
00007e4af17da27f  movaps [rsp], xmm1
00007e4af17da283  movaps [rsp+0x10], xmm13
00007e4af17da289  movaps [rsp+0x20], xmm9
00007e4af17da28f  lea rdi, [rsp]
00007e4af17da293  mov esi, 0x00
00007e4af17da298  mov rax, 0x6256754A7530
00007e4af17da2a2  call rax
00007e4af17da2a4  movaps xmm1, [rsp]
00007e4af17da2a8  add rsp, 0x30
00007e4af17da2ac  vmovaps xmm0, [rsp]
00007e4af17da2b1  vmovaps xmm2, [rsp+0x10]
00007e4af17da2b7  vmovaps xmm3, [rsp+0x20]
00007e4af17da2bd  vmovaps xmm4, [rsp+0x30]
00007e4af17da2c3  vmovaps xmm5, [rsp+0x40]
00007e4af17da2c9  vmovaps xmm6, [rsp+0x50]
00007e4af17da2cf  vmovaps xmm7, [rsp+0x60]
00007e4af17da2d5  vmovaps xmm8, [rsp+0x70]
00007e4af17da2db  vmovaps xmm9, [rsp+0x80]
00007e4af17da2e4  vmovaps xmm10, [rsp+0x90]
00007e4af17da2ed  vmovaps xmm11, [rsp+0xA0]
00007e4af17da2f6  vmovaps xmm12, [rsp+0xB0]
00007e4af17da2ff  vmovaps xmm13, [rsp+0xC0]
00007e4af17da308  vmovaps xmm14, [rsp+0xD0]
00007e4af17da311  vmovaps xmm15, [rsp+0xE0]
00007e4af17da31a  add rsp, 0xF0
00007e4af17da321  pop r11
00007e4af17da323  pop r10
00007e4af17da325  pop r9
00007e4af17da327  pop r8
00007e4af17da329  pop rsi
00007e4af17da32a  pop rdi
00007e4af17da32b  pop rdx
00007e4af17da32c  pop rcx
00007e4af17da32d  pop rax
00007e4af17da32e  add rsp, 0x08
00007e4af17da332  jmp 0x00007E4AF17D641A
00007e4af17da337  sub rsp, 0x08
00007e4af17da33b  push rax
00007e4af17da33c  push rcx
00007e4af17da33d  push rdx
00007e4af17da33e  push rdi
00007e4af17da33f  push rsi
00007e4af17da340  push r8
00007e4af17da342  push r9
00007e4af17da344  push r10
00007e4af17da346  push r11
00007e4af17da348  sub rsp, 0xF0
00007e4af17da34f  vmovaps [rsp], xmm0
00007e4af17da354  vmovaps [rsp+0x10], xmm1
00007e4af17da35a  vmovaps [rsp+0x20], xmm2
00007e4af17da360  vmovaps [rsp+0x30], xmm3
00007e4af17da366  vmovaps [rsp+0x40], xmm4
00007e4af17da36c  vmovaps [rsp+0x50], xmm5
00007e4af17da372  vmovaps [rsp+0x60], xmm6
00007e4af17da378  vmovaps [rsp+0x70], xmm7
00007e4af17da37e  vmovaps [rsp+0x80], xmm8
00007e4af17da387  vmovaps [rsp+0x90], xmm9
00007e4af17da390  vmovaps [rsp+0xA0], xmm10
00007e4af17da399  vmovaps [rsp+0xB0], xmm11
00007e4af17da3a2  vmovaps [rsp+0xC0], xmm13
00007e4af17da3ab  vmovaps [rsp+0xD0], xmm14
00007e4af17da3b4  vmovaps [rsp+0xE0], xmm15
00007e4af17da3bd  sub rsp, 0x30
00007e4af17da3c1  movaps [rsp], xmm12
00007e4af17da3c6  movaps [rsp+0x10], xmm7
00007e4af17da3cb  movaps [rsp+0x20], xmm13
00007e4af17da3d1  lea rdi, [rsp]
00007e4af17da3d5  mov esi, 0x00
00007e4af17da3da  mov rax, 0x6256754A7530
00007e4af17da3e4  call rax
00007e4af17da3e6  movaps xmm12, [rsp]
00007e4af17da3eb  add rsp, 0x30
00007e4af17da3ef  vmovaps xmm0, [rsp]
00007e4af17da3f4  vmovaps xmm1, [rsp+0x10]
00007e4af17da3fa  vmovaps xmm2, [rsp+0x20]
00007e4af17da400  vmovaps xmm3, [rsp+0x30]
00007e4af17da406  vmovaps xmm4, [rsp+0x40]
00007e4af17da40c  vmovaps xmm5, [rsp+0x50]
00007e4af17da412  vmovaps xmm6, [rsp+0x60]
00007e4af17da418  vmovaps xmm7, [rsp+0x70]
00007e4af17da41e  vmovaps xmm8, [rsp+0x80]
00007e4af17da427  vmovaps xmm9, [rsp+0x90]
00007e4af17da430  vmovaps xmm10, [rsp+0xA0]
00007e4af17da439  vmovaps xmm11, [rsp+0xB0]
00007e4af17da442  vmovaps xmm13, [rsp+0xC0]
00007e4af17da44b  vmovaps xmm14, [rsp+0xD0]
00007e4af17da454  vmovaps xmm15, [rsp+0xE0]
00007e4af17da45d  add rsp, 0xF0
00007e4af17da464  pop r11
00007e4af17da466  pop r10
00007e4af17da468  pop r9
00007e4af17da46a  pop r8
00007e4af17da46c  pop rsi
00007e4af17da46d  pop rdi
00007e4af17da46e  pop rdx
00007e4af17da46f  pop rcx
00007e4af17da470  pop rax
00007e4af17da471  add rsp, 0x08
00007e4af17da475  jmp 0x00007E4AF17D6441
00007e4af17da47a  sub rsp, 0x08
00007e4af17da47e  push rax
00007e4af17da47f  push rcx
00007e4af17da480  push rdx
00007e4af17da481  push rdi
00007e4af17da482  push rsi
00007e4af17da483  push r8
00007e4af17da485  push r9
00007e4af17da487  push r10
00007e4af17da489  push r11
00007e4af17da48b  sub rsp, 0xF0
00007e4af17da492  vmovaps [rsp], xmm0
00007e4af17da497  vmovaps [rsp+0x10], xmm1
00007e4af17da49d  vmovaps [rsp+0x20], xmm2
00007e4af17da4a3  vmovaps [rsp+0x30], xmm3
00007e4af17da4a9  vmovaps [rsp+0x40], xmm4
00007e4af17da4af  vmovaps [rsp+0x50], xmm5
00007e4af17da4b5  vmovaps [rsp+0x60], xmm6
00007e4af17da4bb  vmovaps [rsp+0x70], xmm7
00007e4af17da4c1  vmovaps [rsp+0x80], xmm8
00007e4af17da4ca  vmovaps [rsp+0x90], xmm9
00007e4af17da4d3  vmovaps [rsp+0xA0], xmm10
00007e4af17da4dc  vmovaps [rsp+0xB0], xmm11
00007e4af17da4e5  vmovaps [rsp+0xC0], xmm12
00007e4af17da4ee  vmovaps [rsp+0xD0], xmm14
00007e4af17da4f7  vmovaps [rsp+0xE0], xmm15
00007e4af17da500  sub rsp, 0x30
00007e4af17da504  movaps [rsp], xmm13
00007e4af17da509  movaps [rsp+0x10], xmm15
00007e4af17da50f  movaps [rsp+0x20], xmm8
00007e4af17da515  lea rdi, [rsp]
00007e4af17da519  mov esi, 0x00
00007e4af17da51e  mov rax, 0x6256754A7530
00007e4af17da528  call rax
00007e4af17da52a  movaps xmm13, [rsp]
00007e4af17da52f  add rsp, 0x30
00007e4af17da533  vmovaps xmm0, [rsp]
00007e4af17da538  vmovaps xmm1, [rsp+0x10]
00007e4af17da53e  vmovaps xmm2, [rsp+0x20]
00007e4af17da544  vmovaps xmm3, [rsp+0x30]
00007e4af17da54a  vmovaps xmm4, [rsp+0x40]
00007e4af17da550  vmovaps xmm5, [rsp+0x50]
00007e4af17da556  vmovaps xmm6, [rsp+0x60]
00007e4af17da55c  vmovaps xmm7, [rsp+0x70]
00007e4af17da562  vmovaps xmm8, [rsp+0x80]
00007e4af17da56b  vmovaps xmm9, [rsp+0x90]
00007e4af17da574  vmovaps xmm10, [rsp+0xA0]
00007e4af17da57d  vmovaps xmm11, [rsp+0xB0]
00007e4af17da586  vmovaps xmm12, [rsp+0xC0]
00007e4af17da58f  vmovaps xmm14, [rsp+0xD0]
00007e4af17da598  vmovaps xmm15, [rsp+0xE0]
00007e4af17da5a1  add rsp, 0xF0
00007e4af17da5a8  pop r11
00007e4af17da5aa  pop r10
00007e4af17da5ac  pop r9
00007e4af17da5ae  pop r8
00007e4af17da5b0  pop rsi
00007e4af17da5b1  pop rdi
00007e4af17da5b2  pop rdx
00007e4af17da5b3  pop rcx
00007e4af17da5b4  pop rax
00007e4af17da5b5  add rsp, 0x08
00007e4af17da5b9  jmp 0x00007E4AF17D645C
00007e4af17da5be  sub rsp, 0x08
00007e4af17da5c2  push rax
00007e4af17da5c3  push rcx
00007e4af17da5c4  push rdx
00007e4af17da5c5  push rdi
00007e4af17da5c6  push rsi
00007e4af17da5c7  push r8
00007e4af17da5c9  push r9
00007e4af17da5cb  push r10
00007e4af17da5cd  push r11
00007e4af17da5cf  sub rsp, 0xF0
00007e4af17da5d6  vmovaps [rsp], xmm0
00007e4af17da5db  vmovaps [rsp+0x10], xmm1
00007e4af17da5e1  vmovaps [rsp+0x20], xmm2
00007e4af17da5e7  vmovaps [rsp+0x30], xmm3
00007e4af17da5ed  vmovaps [rsp+0x40], xmm4
00007e4af17da5f3  vmovaps [rsp+0x50], xmm5
00007e4af17da5f9  vmovaps [rsp+0x60], xmm6
00007e4af17da5ff  vmovaps [rsp+0x70], xmm7
00007e4af17da605  vmovaps [rsp+0x80], xmm9
00007e4af17da60e  vmovaps [rsp+0x90], xmm10
00007e4af17da617  vmovaps [rsp+0xA0], xmm11
00007e4af17da620  vmovaps [rsp+0xB0], xmm12
00007e4af17da629  vmovaps [rsp+0xC0], xmm13
00007e4af17da632  vmovaps [rsp+0xD0], xmm14
00007e4af17da63b  vmovaps [rsp+0xE0], xmm15
00007e4af17da644  sub rsp, 0x30
00007e4af17da648  movaps [rsp], xmm8
00007e4af17da64d  movaps [rsp+0x10], xmm15
00007e4af17da653  movaps [rsp+0x20], xmm9
00007e4af17da659  lea rdi, [rsp]
00007e4af17da65d  mov esi, 0x00
00007e4af17da662  mov rax, 0x6256754A7530
00007e4af17da66c  call rax
00007e4af17da66e  movaps xmm8, [rsp]
00007e4af17da673  add rsp, 0x30
00007e4af17da677  vmovaps xmm0, [rsp]
00007e4af17da67c  vmovaps xmm1, [rsp+0x10]
00007e4af17da682  vmovaps xmm2, [rsp+0x20]
00007e4af17da688  vmovaps xmm3, [rsp+0x30]
00007e4af17da68e  vmovaps xmm4, [rsp+0x40]
00007e4af17da694  vmovaps xmm5, [rsp+0x50]
00007e4af17da69a  vmovaps xmm6, [rsp+0x60]
00007e4af17da6a0  vmovaps xmm7, [rsp+0x70]
00007e4af17da6a6  vmovaps xmm9, [rsp+0x80]
00007e4af17da6af  vmovaps xmm10, [rsp+0x90]
00007e4af17da6b8  vmovaps xmm11, [rsp+0xA0]
00007e4af17da6c1  vmovaps xmm12, [rsp+0xB0]
00007e4af17da6ca  vmovaps xmm13, [rsp+0xC0]
00007e4af17da6d3  vmovaps xmm14, [rsp+0xD0]
00007e4af17da6dc  vmovaps xmm15, [rsp+0xE0]
00007e4af17da6e5  add rsp, 0xF0
00007e4af17da6ec  pop r11
00007e4af17da6ee  pop r10
00007e4af17da6f0  pop r9
00007e4af17da6f2  pop r8
00007e4af17da6f4  pop rsi
00007e4af17da6f5  pop rdi
00007e4af17da6f6  pop rdx
00007e4af17da6f7  pop rcx
00007e4af17da6f8  pop rax
00007e4af17da6f9  add rsp, 0x08
00007e4af17da6fd  jmp 0x00007E4AF17D648A
00007e4af17da702  sub rsp, 0x08
00007e4af17da706  push rax
00007e4af17da707  push rcx
00007e4af17da708  push rdx
00007e4af17da709  push rdi
00007e4af17da70a  push rsi
00007e4af17da70b  push r8
00007e4af17da70d  push r9
00007e4af17da70f  push r10
00007e4af17da711  push r11
00007e4af17da713  sub rsp, 0xF0
00007e4af17da71a  vmovaps [rsp], xmm0
00007e4af17da71f  vmovaps [rsp+0x10], xmm1
00007e4af17da725  vmovaps [rsp+0x20], xmm2
00007e4af17da72b  vmovaps [rsp+0x30], xmm3
00007e4af17da731  vmovaps [rsp+0x40], xmm4
00007e4af17da737  vmovaps [rsp+0x50], xmm5
00007e4af17da73d  vmovaps [rsp+0x60], xmm6
00007e4af17da743  vmovaps [rsp+0x70], xmm7
00007e4af17da749  vmovaps [rsp+0x80], xmm8
00007e4af17da752  vmovaps [rsp+0x90], xmm9
00007e4af17da75b  vmovaps [rsp+0xA0], xmm10
00007e4af17da764  vmovaps [rsp+0xB0], xmm11
00007e4af17da76d  vmovaps [rsp+0xC0], xmm12
00007e4af17da776  vmovaps [rsp+0xD0], xmm13
00007e4af17da77f  vmovaps [rsp+0xE0], xmm14
00007e4af17da788  sub rsp, 0x30
00007e4af17da78c  movaps [rsp], xmm15
00007e4af17da791  movaps [rsp+0x10], xmm11
00007e4af17da797  movaps [rsp+0x20], xmm6
00007e4af17da79c  lea rdi, [rsp]
00007e4af17da7a0  mov esi, 0x00
00007e4af17da7a5  mov rax, 0x6256754A7530
00007e4af17da7af  call rax
00007e4af17da7b1  movaps xmm15, [rsp]
00007e4af17da7b6  add rsp, 0x30
00007e4af17da7ba  vmovaps xmm0, [rsp]
00007e4af17da7bf  vmovaps xmm1, [rsp+0x10]
00007e4af17da7c5  vmovaps xmm2, [rsp+0x20]
00007e4af17da7cb  vmovaps xmm3, [rsp+0x30]
00007e4af17da7d1  vmovaps xmm4, [rsp+0x40]
00007e4af17da7d7  vmovaps xmm5, [rsp+0x50]
00007e4af17da7dd  vmovaps xmm6, [rsp+0x60]
00007e4af17da7e3  vmovaps xmm7, [rsp+0x70]
00007e4af17da7e9  vmovaps xmm8, [rsp+0x80]
00007e4af17da7f2  vmovaps xmm9, [rsp+0x90]
00007e4af17da7fb  vmovaps xmm10, [rsp+0xA0]
00007e4af17da804  vmovaps xmm11, [rsp+0xB0]
00007e4af17da80d  vmovaps xmm12, [rsp+0xC0]
00007e4af17da816  vmovaps xmm13, [rsp+0xD0]
00007e4af17da81f  vmovaps xmm14, [rsp+0xE0]
00007e4af17da828  add rsp, 0xF0
00007e4af17da82f  pop r11
00007e4af17da831  pop r10
00007e4af17da833  pop r9
00007e4af17da835  pop r8
00007e4af17da837  pop rsi
00007e4af17da838  pop rdi
00007e4af17da839  pop rdx
00007e4af17da83a  pop rcx
00007e4af17da83b  pop rax
00007e4af17da83c  add rsp, 0x08
00007e4af17da840  jmp 0x00007E4AF17D64A5
00007e4af17da845  sub rsp, 0x08
00007e4af17da849  push rax
00007e4af17da84a  push rcx
00007e4af17da84b  push rdx
00007e4af17da84c  push rdi
00007e4af17da84d  push rsi
00007e4af17da84e  push r8
00007e4af17da850  push r9
00007e4af17da852  push r10
00007e4af17da854  push r11
00007e4af17da856  sub rsp, 0xF0
00007e4af17da85d  vmovaps [rsp], xmm0
00007e4af17da862  vmovaps [rsp+0x10], xmm1
00007e4af17da868  vmovaps [rsp+0x20], xmm2
00007e4af17da86e  vmovaps [rsp+0x30], xmm3
00007e4af17da874  vmovaps [rsp+0x40], xmm4
00007e4af17da87a  vmovaps [rsp+0x50], xmm5
00007e4af17da880  vmovaps [rsp+0x60], xmm6
00007e4af17da886  vmovaps [rsp+0x70], xmm8
00007e4af17da88c  vmovaps [rsp+0x80], xmm9
00007e4af17da895  vmovaps [rsp+0x90], xmm10
00007e4af17da89e  vmovaps [rsp+0xA0], xmm11
00007e4af17da8a7  vmovaps [rsp+0xB0], xmm12
00007e4af17da8b0  vmovaps [rsp+0xC0], xmm13
00007e4af17da8b9  vmovaps [rsp+0xD0], xmm14
00007e4af17da8c2  vmovaps [rsp+0xE0], xmm15
00007e4af17da8cb  sub rsp, 0x30
00007e4af17da8cf  movaps [rsp], xmm7
00007e4af17da8d3  movaps [rsp+0x10], xmm11
00007e4af17da8d9  movaps [rsp+0x20], xmm9
00007e4af17da8df  lea rdi, [rsp]
00007e4af17da8e3  mov esi, 0x00
00007e4af17da8e8  mov rax, 0x6256754A7530
00007e4af17da8f2  call rax
00007e4af17da8f4  movaps xmm7, [rsp]
00007e4af17da8f8  add rsp, 0x30
00007e4af17da8fc  vmovaps xmm0, [rsp]
00007e4af17da901  vmovaps xmm1, [rsp+0x10]
00007e4af17da907  vmovaps xmm2, [rsp+0x20]
00007e4af17da90d  vmovaps xmm3, [rsp+0x30]
00007e4af17da913  vmovaps xmm4, [rsp+0x40]
00007e4af17da919  vmovaps xmm5, [rsp+0x50]
00007e4af17da91f  vmovaps xmm6, [rsp+0x60]
00007e4af17da925  vmovaps xmm8, [rsp+0x70]
00007e4af17da92b  vmovaps xmm9, [rsp+0x80]
00007e4af17da934  vmovaps xmm10, [rsp+0x90]
00007e4af17da93d  vmovaps xmm11, [rsp+0xA0]
00007e4af17da946  vmovaps xmm12, [rsp+0xB0]
00007e4af17da94f  vmovaps xmm13, [rsp+0xC0]
00007e4af17da958  vmovaps xmm14, [rsp+0xD0]
00007e4af17da961  vmovaps xmm15, [rsp+0xE0]
00007e4af17da96a  add rsp, 0xF0
00007e4af17da971  pop r11
00007e4af17da973  pop r10
00007e4af17da975  pop r9
00007e4af17da977  pop r8
00007e4af17da979  pop rsi
00007e4af17da97a  pop rdi
00007e4af17da97b  pop rdx
00007e4af17da97c  pop rcx
00007e4af17da97d  pop rax
00007e4af17da97e  add rsp, 0x08
00007e4af17da982  jmp 0x00007E4AF17D64D2
00007e4af17da987  sub rsp, 0x08
00007e4af17da98b  push rax
00007e4af17da98c  push rcx
00007e4af17da98d  push rdx
00007e4af17da98e  push rdi
00007e4af17da98f  push rsi
00007e4af17da990  push r8
00007e4af17da992  push r9
00007e4af17da994  push r10
00007e4af17da996  push r11
00007e4af17da998  sub rsp, 0xF0
00007e4af17da99f  vmovaps [rsp], xmm0
00007e4af17da9a4  vmovaps [rsp+0x10], xmm1
00007e4af17da9aa  vmovaps [rsp+0x20], xmm2
00007e4af17da9b0  vmovaps [rsp+0x30], xmm3
00007e4af17da9b6  vmovaps [rsp+0x40], xmm4
00007e4af17da9bc  vmovaps [rsp+0x50], xmm5
00007e4af17da9c2  vmovaps [rsp+0x60], xmm6
00007e4af17da9c8  vmovaps [rsp+0x70], xmm7
00007e4af17da9ce  vmovaps [rsp+0x80], xmm8
00007e4af17da9d7  vmovaps [rsp+0x90], xmm9
00007e4af17da9e0  vmovaps [rsp+0xA0], xmm10
00007e4af17da9e9  vmovaps [rsp+0xB0], xmm12
00007e4af17da9f2  vmovaps [rsp+0xC0], xmm13
00007e4af17da9fb  vmovaps [rsp+0xD0], xmm14
00007e4af17daa04  vmovaps [rsp+0xE0], xmm15
00007e4af17daa0d  sub rsp, 0x30
00007e4af17daa11  movaps [rsp], xmm11
00007e4af17daa16  movaps [rsp+0x10], xmm10
00007e4af17daa1c  movaps [rsp+0x20], xmm14
00007e4af17daa22  lea rdi, [rsp]
00007e4af17daa26  mov esi, 0x00
00007e4af17daa2b  mov rax, 0x6256754A7530
00007e4af17daa35  call rax
00007e4af17daa37  movaps xmm11, [rsp]
00007e4af17daa3c  add rsp, 0x30
00007e4af17daa40  vmovaps xmm0, [rsp]
00007e4af17daa45  vmovaps xmm1, [rsp+0x10]
00007e4af17daa4b  vmovaps xmm2, [rsp+0x20]
00007e4af17daa51  vmovaps xmm3, [rsp+0x30]
00007e4af17daa57  vmovaps xmm4, [rsp+0x40]
00007e4af17daa5d  vmovaps xmm5, [rsp+0x50]
00007e4af17daa63  vmovaps xmm6, [rsp+0x60]
00007e4af17daa69  vmovaps xmm7, [rsp+0x70]
00007e4af17daa6f  vmovaps xmm8, [rsp+0x80]
00007e4af17daa78  vmovaps xmm9, [rsp+0x90]
00007e4af17daa81  vmovaps xmm10, [rsp+0xA0]
00007e4af17daa8a  vmovaps xmm12, [rsp+0xB0]
00007e4af17daa93  vmovaps xmm13, [rsp+0xC0]
00007e4af17daa9c  vmovaps xmm14, [rsp+0xD0]
00007e4af17daaa5  vmovaps xmm15, [rsp+0xE0]
00007e4af17daaae  add rsp, 0xF0
00007e4af17daab5  pop r11
00007e4af17daab7  pop r10
00007e4af17daab9  pop r9
00007e4af17daabb  pop r8
00007e4af17daabd  pop rsi
00007e4af17daabe  pop rdi
00007e4af17daabf  pop rdx
00007e4af17daac0  pop rcx
00007e4af17daac1  pop rax
00007e4af17daac2  add rsp, 0x08
00007e4af17daac6  jmp 0x00007E4AF17D64ED
00007e4af17daacb  call 0x00007E4AF16E45A0
00007e4af17daad0  jmp 0x00007E4AF17D64F7
00007e4af17daad5  sub rsp, 0x08
00007e4af17daad9  push rax
00007e4af17daada  push rcx
00007e4af17daadb  push rdx
00007e4af17daadc  push rdi
00007e4af17daadd  push rsi
00007e4af17daade  push r8
00007e4af17daae0  push r9
00007e4af17daae2  push r10
00007e4af17daae4  push r11
00007e4af17daae6  sub rsp, 0xF0
00007e4af17daaed  vmovaps [rsp], xmm0
00007e4af17daaf2  vmovaps [rsp+0x10], xmm1
00007e4af17daaf8  vmovaps [rsp+0x20], xmm2
00007e4af17daafe  vmovaps [rsp+0x30], xmm3
00007e4af17dab04  vmovaps [rsp+0x40], xmm4
00007e4af17dab0a  vmovaps [rsp+0x50], xmm5
00007e4af17dab10  vmovaps [rsp+0x60], xmm6
00007e4af17dab16  vmovaps [rsp+0x70], xmm7
00007e4af17dab1c  vmovaps [rsp+0x80], xmm8
00007e4af17dab25  vmovaps [rsp+0x90], xmm9
00007e4af17dab2e  vmovaps [rsp+0xA0], xmm11
00007e4af17dab37  vmovaps [rsp+0xB0], xmm12
00007e4af17dab40  vmovaps [rsp+0xC0], xmm13
00007e4af17dab49  vmovaps [rsp+0xD0], xmm14
00007e4af17dab52  vmovaps [rsp+0xE0], xmm15
00007e4af17dab5b  sub rsp, 0x30
00007e4af17dab5f  movaps [rsp], xmm10
00007e4af17dab64  movaps [rsp+0x10], xmm1
00007e4af17dab69  movaps [rsp+0x20], xmm12
00007e4af17dab6f  lea rdi, [rsp]
00007e4af17dab73  mov esi, 0x00
00007e4af17dab78  mov rax, 0x6256754A7530
00007e4af17dab82  call rax
00007e4af17dab84  movaps xmm10, [rsp]
00007e4af17dab89  add rsp, 0x30
00007e4af17dab8d  vmovaps xmm0, [rsp]
00007e4af17dab92  vmovaps xmm1, [rsp+0x10]
00007e4af17dab98  vmovaps xmm2, [rsp+0x20]
00007e4af17dab9e  vmovaps xmm3, [rsp+0x30]
00007e4af17daba4  vmovaps xmm4, [rsp+0x40]
00007e4af17dabaa  vmovaps xmm5, [rsp+0x50]
00007e4af17dabb0  vmovaps xmm6, [rsp+0x60]
00007e4af17dabb6  vmovaps xmm7, [rsp+0x70]
00007e4af17dabbc  vmovaps xmm8, [rsp+0x80]
00007e4af17dabc5  vmovaps xmm9, [rsp+0x90]
00007e4af17dabce  vmovaps xmm11, [rsp+0xA0]
00007e4af17dabd7  vmovaps xmm12, [rsp+0xB0]
00007e4af17dabe0  vmovaps xmm13, [rsp+0xC0]
00007e4af17dabe9  vmovaps xmm14, [rsp+0xD0]
00007e4af17dabf2  vmovaps xmm15, [rsp+0xE0]
00007e4af17dabfb  add rsp, 0xF0
00007e4af17dac02  pop r11
00007e4af17dac04  pop r10
00007e4af17dac06  pop r9
00007e4af17dac08  pop r8
00007e4af17dac0a  pop rsi
00007e4af17dac0b  pop rdi
00007e4af17dac0c  pop rdx
00007e4af17dac0d  pop rcx
00007e4af17dac0e  pop rax
00007e4af17dac0f  add rsp, 0x08
00007e4af17dac13  jmp 0x00007E4AF17D651A
00007e4af17dac18  sub rsp, 0x08
00007e4af17dac1c  push rax
00007e4af17dac1d  push rcx
00007e4af17dac1e  push rdx
00007e4af17dac1f  push rdi
00007e4af17dac20  push rsi
00007e4af17dac21  push r8
00007e4af17dac23  push r9
00007e4af17dac25  push r10
00007e4af17dac27  push r11
00007e4af17dac29  sub rsp, 0xF0
00007e4af17dac30  vmovaps [rsp], xmm0
00007e4af17dac35  vmovaps [rsp+0x10], xmm1
00007e4af17dac3b  vmovaps [rsp+0x20], xmm2
00007e4af17dac41  vmovaps [rsp+0x30], xmm3
00007e4af17dac47  vmovaps [rsp+0x40], xmm4
00007e4af17dac4d  vmovaps [rsp+0x50], xmm5
00007e4af17dac53  vmovaps [rsp+0x60], xmm6
00007e4af17dac59  vmovaps [rsp+0x70], xmm7
00007e4af17dac5f  vmovaps [rsp+0x80], xmm8
00007e4af17dac68  vmovaps [rsp+0x90], xmm9
00007e4af17dac71  vmovaps [rsp+0xA0], xmm10
00007e4af17dac7a  vmovaps [rsp+0xB0], xmm11
00007e4af17dac83  vmovaps [rsp+0xC0], xmm13
00007e4af17dac8c  vmovaps [rsp+0xD0], xmm14
00007e4af17dac95  vmovaps [rsp+0xE0], xmm15
00007e4af17dac9e  sub rsp, 0x30
00007e4af17daca2  movaps [rsp], xmm12
00007e4af17daca7  movaps [rsp+0x10], xmm14
00007e4af17dacad  movaps [rsp+0x20], xmm1
00007e4af17dacb2  lea rdi, [rsp]
00007e4af17dacb6  mov esi, 0x00
00007e4af17dacbb  mov rax, 0x6256754A7530
00007e4af17dacc5  call rax
00007e4af17dacc7  movaps xmm12, [rsp]
00007e4af17daccc  add rsp, 0x30
00007e4af17dacd0  vmovaps xmm0, [rsp]
00007e4af17dacd5  vmovaps xmm1, [rsp+0x10]
00007e4af17dacdb  vmovaps xmm2, [rsp+0x20]
00007e4af17dace1  vmovaps xmm3, [rsp+0x30]
00007e4af17dace7  vmovaps xmm4, [rsp+0x40]
00007e4af17daced  vmovaps xmm5, [rsp+0x50]
00007e4af17dacf3  vmovaps xmm6, [rsp+0x60]
00007e4af17dacf9  vmovaps xmm7, [rsp+0x70]
00007e4af17dacff  vmovaps xmm8, [rsp+0x80]
00007e4af17dad08  vmovaps xmm9, [rsp+0x90]
00007e4af17dad11  vmovaps xmm10, [rsp+0xA0]
00007e4af17dad1a  vmovaps xmm11, [rsp+0xB0]
00007e4af17dad23  vmovaps xmm13, [rsp+0xC0]
00007e4af17dad2c  vmovaps xmm14, [rsp+0xD0]
00007e4af17dad35  vmovaps xmm15, [rsp+0xE0]
00007e4af17dad3e  add rsp, 0xF0
00007e4af17dad45  pop r11
00007e4af17dad47  pop r10
00007e4af17dad49  pop r9
00007e4af17dad4b  pop r8
00007e4af17dad4d  pop rsi
00007e4af17dad4e  pop rdi
00007e4af17dad4f  pop rdx
00007e4af17dad50  pop rcx
00007e4af17dad51  pop rax
00007e4af17dad52  add rsp, 0x08
00007e4af17dad56  jmp 0x00007E4AF17D6549
00007e4af17dad5b  sub rsp, 0x08
00007e4af17dad5f  push rax
00007e4af17dad60  push rcx
00007e4af17dad61  push rdx
00007e4af17dad62  push rdi
00007e4af17dad63  push rsi
00007e4af17dad64  push r8
00007e4af17dad66  push r9
00007e4af17dad68  push r10
00007e4af17dad6a  push r11
00007e4af17dad6c  sub rsp, 0xF0
00007e4af17dad73  vmovaps [rsp], xmm0
00007e4af17dad78  vmovaps [rsp+0x10], xmm1
00007e4af17dad7e  vmovaps [rsp+0x20], xmm2
00007e4af17dad84  vmovaps [rsp+0x30], xmm3
00007e4af17dad8a  vmovaps [rsp+0x40], xmm4
00007e4af17dad90  vmovaps [rsp+0x50], xmm5
00007e4af17dad96  vmovaps [rsp+0x60], xmm6
00007e4af17dad9c  vmovaps [rsp+0x70], xmm7
00007e4af17dada2  vmovaps [rsp+0x80], xmm8
00007e4af17dadab  vmovaps [rsp+0x90], xmm9
00007e4af17dadb4  vmovaps [rsp+0xA0], xmm10
00007e4af17dadbd  vmovaps [rsp+0xB0], xmm11
00007e4af17dadc6  vmovaps [rsp+0xC0], xmm12
00007e4af17dadcf  vmovaps [rsp+0xD0], xmm13
00007e4af17dadd8  vmovaps [rsp+0xE0], xmm15
00007e4af17dade1  sub rsp, 0x30
00007e4af17dade5  movaps [rsp], xmm14
00007e4af17dadea  movaps [rsp+0x10], xmm9
00007e4af17dadf0  movaps [rsp+0x20], xmm1
00007e4af17dadf5  lea rdi, [rsp]
00007e4af17dadf9  mov esi, 0x00
00007e4af17dadfe  mov rax, 0x6256754A7530
00007e4af17dae08  call rax
00007e4af17dae0a  movaps xmm14, [rsp]
00007e4af17dae0f  add rsp, 0x30
00007e4af17dae13  vmovaps xmm0, [rsp]
00007e4af17dae18  vmovaps xmm1, [rsp+0x10]
00007e4af17dae1e  vmovaps xmm2, [rsp+0x20]
00007e4af17dae24  vmovaps xmm3, [rsp+0x30]
00007e4af17dae2a  vmovaps xmm4, [rsp+0x40]
00007e4af17dae30  vmovaps xmm5, [rsp+0x50]
00007e4af17dae36  vmovaps xmm6, [rsp+0x60]
00007e4af17dae3c  vmovaps xmm7, [rsp+0x70]
00007e4af17dae42  vmovaps xmm8, [rsp+0x80]
00007e4af17dae4b  vmovaps xmm9, [rsp+0x90]
00007e4af17dae54  vmovaps xmm10, [rsp+0xA0]
00007e4af17dae5d  vmovaps xmm11, [rsp+0xB0]
00007e4af17dae66  vmovaps xmm12, [rsp+0xC0]
00007e4af17dae6f  vmovaps xmm13, [rsp+0xD0]
00007e4af17dae78  vmovaps xmm15, [rsp+0xE0]
00007e4af17dae81  add rsp, 0xF0
00007e4af17dae88  pop r11
00007e4af17dae8a  pop r10
00007e4af17dae8c  pop r9
00007e4af17dae8e  pop r8
00007e4af17dae90  pop rsi
00007e4af17dae91  pop rdi
00007e4af17dae92  pop rdx
00007e4af17dae93  pop rcx
00007e4af17dae94  pop rax
00007e4af17dae95  add rsp, 0x08
00007e4af17dae99  jmp 0x00007E4AF17D6578
00007e4af17dae9e  sub rsp, 0x08
00007e4af17daea2  push rax
00007e4af17daea3  push rcx
00007e4af17daea4  push rdx
00007e4af17daea5  push rdi
00007e4af17daea6  push rsi
00007e4af17daea7  push r8
00007e4af17daea9  push r9
00007e4af17daeab  push r10
00007e4af17daead  push r11
00007e4af17daeaf  sub rsp, 0xF0
00007e4af17daeb6  vmovaps [rsp], xmm0
00007e4af17daebb  vmovaps [rsp+0x10], xmm2
00007e4af17daec1  vmovaps [rsp+0x20], xmm3
00007e4af17daec7  vmovaps [rsp+0x30], xmm4
00007e4af17daecd  vmovaps [rsp+0x40], xmm5
00007e4af17daed3  vmovaps [rsp+0x50], xmm6
00007e4af17daed9  vmovaps [rsp+0x60], xmm7
00007e4af17daedf  vmovaps [rsp+0x70], xmm8
00007e4af17daee5  vmovaps [rsp+0x80], xmm9
00007e4af17daeee  vmovaps [rsp+0x90], xmm10
00007e4af17daef7  vmovaps [rsp+0xA0], xmm11
00007e4af17daf00  vmovaps [rsp+0xB0], xmm12
00007e4af17daf09  vmovaps [rsp+0xC0], xmm13
00007e4af17daf12  vmovaps [rsp+0xD0], xmm14
00007e4af17daf1b  vmovaps [rsp+0xE0], xmm15
00007e4af17daf24  sub rsp, 0x30
00007e4af17daf28  movaps [rsp], xmm1
00007e4af17daf2c  movaps [rsp+0x10], xmm13
00007e4af17daf32  movaps [rsp+0x20], xmm8
00007e4af17daf38  lea rdi, [rsp]
00007e4af17daf3c  mov esi, 0x00
00007e4af17daf41  mov rax, 0x6256754A7530
00007e4af17daf4b  call rax
00007e4af17daf4d  movaps xmm1, [rsp]
00007e4af17daf51  add rsp, 0x30
00007e4af17daf55  vmovaps xmm0, [rsp]
00007e4af17daf5a  vmovaps xmm2, [rsp+0x10]
00007e4af17daf60  vmovaps xmm3, [rsp+0x20]
00007e4af17daf66  vmovaps xmm4, [rsp+0x30]
00007e4af17daf6c  vmovaps xmm5, [rsp+0x40]
00007e4af17daf72  vmovaps xmm6, [rsp+0x50]
00007e4af17daf78  vmovaps xmm7, [rsp+0x60]
00007e4af17daf7e  vmovaps xmm8, [rsp+0x70]
00007e4af17daf84  vmovaps xmm9, [rsp+0x80]
00007e4af17daf8d  vmovaps xmm10, [rsp+0x90]
00007e4af17daf96  vmovaps xmm11, [rsp+0xA0]
00007e4af17daf9f  vmovaps xmm12, [rsp+0xB0]
00007e4af17dafa8  vmovaps xmm13, [rsp+0xC0]
00007e4af17dafb1  vmovaps xmm14, [rsp+0xD0]
00007e4af17dafba  vmovaps xmm15, [rsp+0xE0]
00007e4af17dafc3  add rsp, 0xF0
00007e4af17dafca  pop r11
00007e4af17dafcc  pop r10
00007e4af17dafce  pop r9
00007e4af17dafd0  pop r8
00007e4af17dafd2  pop rsi
00007e4af17dafd3  pop rdi
00007e4af17dafd4  pop rdx
00007e4af17dafd5  pop rcx
00007e4af17dafd6  pop rax
00007e4af17dafd7  add rsp, 0x08
00007e4af17dafdb  jmp 0x00007E4AF17D659A
00007e4af17dafe0  call 0x00007E4AF160C260
00007e4af17dafe5  jmp 0x00007E4AF17D65A8
00007e4af17dafea  call 0x00007E4AF16DE950
00007e4af17dafef  jmp 0x00007E4AF17D65B2
00007e4af17daff4  sub rsp, 0x08
00007e4af17daff8  push rax
00007e4af17daff9  push rcx
00007e4af17daffa  push rdx
00007e4af17daffb  push rdi
00007e4af17daffc  push rsi
00007e4af17daffd  push r8
00007e4af17dafff  push r9
00007e4af17db001  push r10
00007e4af17db003  push r11
00007e4af17db005  sub rsp, 0xF0
00007e4af17db00c  vmovaps [rsp], xmm0
00007e4af17db011  vmovaps [rsp+0x10], xmm1
00007e4af17db017  vmovaps [rsp+0x20], xmm2
00007e4af17db01d  vmovaps [rsp+0x30], xmm3
00007e4af17db023  vmovaps [rsp+0x40], xmm4
00007e4af17db029  vmovaps [rsp+0x50], xmm5
00007e4af17db02f  vmovaps [rsp+0x60], xmm6
00007e4af17db035  vmovaps [rsp+0x70], xmm7
00007e4af17db03b  vmovaps [rsp+0x80], xmm9
00007e4af17db044  vmovaps [rsp+0x90], xmm10
00007e4af17db04d  vmovaps [rsp+0xA0], xmm11
00007e4af17db056  vmovaps [rsp+0xB0], xmm12
00007e4af17db05f  vmovaps [rsp+0xC0], xmm13
00007e4af17db068  vmovaps [rsp+0xD0], xmm14
00007e4af17db071  vmovaps [rsp+0xE0], xmm15
00007e4af17db07a  sub rsp, 0x30
00007e4af17db07e  movaps [rsp], xmm8
00007e4af17db083  movaps [rsp+0x10], xmm15
00007e4af17db089  movaps [rsp+0x20], xmm7
00007e4af17db08e  lea rdi, [rsp]
00007e4af17db092  mov esi, 0x00
00007e4af17db097  mov rax, 0x6256754A7530
00007e4af17db0a1  call rax
00007e4af17db0a3  movaps xmm8, [rsp]
00007e4af17db0a8  add rsp, 0x30
00007e4af17db0ac  vmovaps xmm0, [rsp]
00007e4af17db0b1  vmovaps xmm1, [rsp+0x10]
00007e4af17db0b7  vmovaps xmm2, [rsp+0x20]
00007e4af17db0bd  vmovaps xmm3, [rsp+0x30]
00007e4af17db0c3  vmovaps xmm4, [rsp+0x40]
00007e4af17db0c9  vmovaps xmm5, [rsp+0x50]
00007e4af17db0cf  vmovaps xmm6, [rsp+0x60]
00007e4af17db0d5  vmovaps xmm7, [rsp+0x70]
00007e4af17db0db  vmovaps xmm9, [rsp+0x80]
00007e4af17db0e4  vmovaps xmm10, [rsp+0x90]
00007e4af17db0ed  vmovaps xmm11, [rsp+0xA0]
00007e4af17db0f6  vmovaps xmm12, [rsp+0xB0]
00007e4af17db0ff  vmovaps xmm13, [rsp+0xC0]
00007e4af17db108  vmovaps xmm14, [rsp+0xD0]
00007e4af17db111  vmovaps xmm15, [rsp+0xE0]
00007e4af17db11a  add rsp, 0xF0
00007e4af17db121  pop r11
00007e4af17db123  pop r10
00007e4af17db125  pop r9
00007e4af17db127  pop r8
00007e4af17db129  pop rsi
00007e4af17db12a  pop rdi
00007e4af17db12b  pop rdx
00007e4af17db12c  pop rcx
00007e4af17db12d  pop rax
00007e4af17db12e  add rsp, 0x08
00007e4af17db132  jmp 0x00007E4AF17D65D4
00007e4af17db137  sub rsp, 0x08
00007e4af17db13b  push rax
00007e4af17db13c  push rcx
00007e4af17db13d  push rdx
00007e4af17db13e  push rdi
00007e4af17db13f  push rsi
00007e4af17db140  push r8
00007e4af17db142  push r9
00007e4af17db144  push r10
00007e4af17db146  push r11
00007e4af17db148  sub rsp, 0xF0
00007e4af17db14f  vmovaps [rsp], xmm0
00007e4af17db154  vmovaps [rsp+0x10], xmm1
00007e4af17db15a  vmovaps [rsp+0x20], xmm2
00007e4af17db160  vmovaps [rsp+0x30], xmm3
00007e4af17db166  vmovaps [rsp+0x40], xmm4
00007e4af17db16c  vmovaps [rsp+0x50], xmm5
00007e4af17db172  vmovaps [rsp+0x60], xmm6
00007e4af17db178  vmovaps [rsp+0x70], xmm8
00007e4af17db17e  vmovaps [rsp+0x80], xmm9
00007e4af17db187  vmovaps [rsp+0x90], xmm10
00007e4af17db190  vmovaps [rsp+0xA0], xmm11
00007e4af17db199  vmovaps [rsp+0xB0], xmm12
00007e4af17db1a2  vmovaps [rsp+0xC0], xmm13
00007e4af17db1ab  vmovaps [rsp+0xD0], xmm14
00007e4af17db1b4  vmovaps [rsp+0xE0], xmm15
00007e4af17db1bd  sub rsp, 0x30
00007e4af17db1c1  movaps [rsp], xmm7
00007e4af17db1c5  movaps [rsp+0x10], xmm9
00007e4af17db1cb  movaps [rsp+0x20], xmm15
00007e4af17db1d1  lea rdi, [rsp]
00007e4af17db1d5  mov esi, 0x00
00007e4af17db1da  mov rax, 0x6256754A7530
00007e4af17db1e4  call rax
00007e4af17db1e6  movaps xmm7, [rsp]
00007e4af17db1ea  add rsp, 0x30
00007e4af17db1ee  vmovaps xmm0, [rsp]
00007e4af17db1f3  vmovaps xmm1, [rsp+0x10]
00007e4af17db1f9  vmovaps xmm2, [rsp+0x20]
00007e4af17db1ff  vmovaps xmm3, [rsp+0x30]
00007e4af17db205  vmovaps xmm4, [rsp+0x40]
00007e4af17db20b  vmovaps xmm5, [rsp+0x50]
00007e4af17db211  vmovaps xmm6, [rsp+0x60]
00007e4af17db217  vmovaps xmm8, [rsp+0x70]
00007e4af17db21d  vmovaps xmm9, [rsp+0x80]
00007e4af17db226  vmovaps xmm10, [rsp+0x90]
00007e4af17db22f  vmovaps xmm11, [rsp+0xA0]
00007e4af17db238  vmovaps xmm12, [rsp+0xB0]
00007e4af17db241  vmovaps xmm13, [rsp+0xC0]
00007e4af17db24a  vmovaps xmm14, [rsp+0xD0]
00007e4af17db253  vmovaps xmm15, [rsp+0xE0]
00007e4af17db25c  add rsp, 0xF0
00007e4af17db263  pop r11
00007e4af17db265  pop r10
00007e4af17db267  pop r9
00007e4af17db269  pop r8
00007e4af17db26b  pop rsi
00007e4af17db26c  pop rdi
00007e4af17db26d  pop rdx
00007e4af17db26e  pop rcx
00007e4af17db26f  pop rax
00007e4af17db270  add rsp, 0x08
00007e4af17db274  jmp 0x00007E4AF17D6601
00007e4af17db279  sub rsp, 0x08
00007e4af17db27d  push rax
00007e4af17db27e  push rcx
00007e4af17db27f  push rdx
00007e4af17db280  push rdi
00007e4af17db281  push rsi
00007e4af17db282  push r8
00007e4af17db284  push r9
00007e4af17db286  push r10
00007e4af17db288  push r11
00007e4af17db28a  sub rsp, 0xF0
00007e4af17db291  vmovaps [rsp], xmm0
00007e4af17db296  vmovaps [rsp+0x10], xmm1
00007e4af17db29c  vmovaps [rsp+0x20], xmm2
00007e4af17db2a2  vmovaps [rsp+0x30], xmm3
00007e4af17db2a8  vmovaps [rsp+0x40], xmm4
00007e4af17db2ae  vmovaps [rsp+0x50], xmm5
00007e4af17db2b4  vmovaps [rsp+0x60], xmm6
00007e4af17db2ba  vmovaps [rsp+0x70], xmm7
00007e4af17db2c0  vmovaps [rsp+0x80], xmm8
00007e4af17db2c9  vmovaps [rsp+0x90], xmm10
00007e4af17db2d2  vmovaps [rsp+0xA0], xmm11
00007e4af17db2db  vmovaps [rsp+0xB0], xmm12
00007e4af17db2e4  vmovaps [rsp+0xC0], xmm13
00007e4af17db2ed  vmovaps [rsp+0xD0], xmm14
00007e4af17db2f6  vmovaps [rsp+0xE0], xmm15
00007e4af17db2ff  sub rsp, 0x30
00007e4af17db303  movaps [rsp], xmm9
00007e4af17db308  movaps [rsp+0x10], xmm13
00007e4af17db30e  movaps [rsp+0x20], xmm15
00007e4af17db314  lea rdi, [rsp]
00007e4af17db318  mov esi, 0x00
00007e4af17db31d  mov rax, 0x6256754A7530
00007e4af17db327  call rax
00007e4af17db329  movaps xmm9, [rsp]
00007e4af17db32e  add rsp, 0x30
00007e4af17db332  vmovaps xmm0, [rsp]
00007e4af17db337  vmovaps xmm1, [rsp+0x10]
00007e4af17db33d  vmovaps xmm2, [rsp+0x20]
00007e4af17db343  vmovaps xmm3, [rsp+0x30]
00007e4af17db349  vmovaps xmm4, [rsp+0x40]
00007e4af17db34f  vmovaps xmm5, [rsp+0x50]
00007e4af17db355  vmovaps xmm6, [rsp+0x60]
00007e4af17db35b  vmovaps xmm7, [rsp+0x70]
00007e4af17db361  vmovaps xmm8, [rsp+0x80]
00007e4af17db36a  vmovaps xmm10, [rsp+0x90]
00007e4af17db373  vmovaps xmm11, [rsp+0xA0]
00007e4af17db37c  vmovaps xmm12, [rsp+0xB0]
00007e4af17db385  vmovaps xmm13, [rsp+0xC0]
00007e4af17db38e  vmovaps xmm14, [rsp+0xD0]
00007e4af17db397  vmovaps xmm15, [rsp+0xE0]
00007e4af17db3a0  add rsp, 0xF0
00007e4af17db3a7  pop r11
00007e4af17db3a9  pop r10
00007e4af17db3ab  pop r9
00007e4af17db3ad  pop r8
00007e4af17db3af  pop rsi
00007e4af17db3b0  pop rdi
00007e4af17db3b1  pop rdx
00007e4af17db3b2  pop rcx
00007e4af17db3b3  pop rax
00007e4af17db3b4  add rsp, 0x08
00007e4af17db3b8  jmp 0x00007E4AF17D662F
00007e4af17db3bd  sub rsp, 0x08
00007e4af17db3c1  push rax
00007e4af17db3c2  push rcx
00007e4af17db3c3  push rdx
00007e4af17db3c4  push rdi
00007e4af17db3c5  push rsi
00007e4af17db3c6  push r8
00007e4af17db3c8  push r9
00007e4af17db3ca  push r10
00007e4af17db3cc  push r11
00007e4af17db3ce  sub rsp, 0xF0
00007e4af17db3d5  vmovaps [rsp], xmm0
00007e4af17db3da  vmovaps [rsp+0x10], xmm1
00007e4af17db3e0  vmovaps [rsp+0x20], xmm2
00007e4af17db3e6  vmovaps [rsp+0x30], xmm3
00007e4af17db3ec  vmovaps [rsp+0x40], xmm4
00007e4af17db3f2  vmovaps [rsp+0x50], xmm5
00007e4af17db3f8  vmovaps [rsp+0x60], xmm6
00007e4af17db3fe  vmovaps [rsp+0x70], xmm7
00007e4af17db404  vmovaps [rsp+0x80], xmm8
00007e4af17db40d  vmovaps [rsp+0x90], xmm9
00007e4af17db416  vmovaps [rsp+0xA0], xmm10
00007e4af17db41f  vmovaps [rsp+0xB0], xmm11
00007e4af17db428  vmovaps [rsp+0xC0], xmm12
00007e4af17db431  vmovaps [rsp+0xD0], xmm13
00007e4af17db43a  vmovaps [rsp+0xE0], xmm14
00007e4af17db443  sub rsp, 0x30
00007e4af17db447  movaps [rsp], xmm15
00007e4af17db44c  movaps [rsp+0x10], xmm11
00007e4af17db452  movaps [rsp+0x20], xmm12
00007e4af17db458  lea rdi, [rsp]
00007e4af17db45c  mov esi, 0x00
00007e4af17db461  mov rax, 0x6256754A7530
00007e4af17db46b  call rax
00007e4af17db46d  movaps xmm15, [rsp]
00007e4af17db472  add rsp, 0x30
00007e4af17db476  vmovaps xmm0, [rsp]
00007e4af17db47b  vmovaps xmm1, [rsp+0x10]
00007e4af17db481  vmovaps xmm2, [rsp+0x20]
00007e4af17db487  vmovaps xmm3, [rsp+0x30]
00007e4af17db48d  vmovaps xmm4, [rsp+0x40]
00007e4af17db493  vmovaps xmm5, [rsp+0x50]
00007e4af17db499  vmovaps xmm6, [rsp+0x60]
00007e4af17db49f  vmovaps xmm7, [rsp+0x70]
00007e4af17db4a5  vmovaps xmm8, [rsp+0x80]
00007e4af17db4ae  vmovaps xmm9, [rsp+0x90]
00007e4af17db4b7  vmovaps xmm10, [rsp+0xA0]
00007e4af17db4c0  vmovaps xmm11, [rsp+0xB0]
00007e4af17db4c9  vmovaps xmm12, [rsp+0xC0]
00007e4af17db4d2  vmovaps xmm13, [rsp+0xD0]
00007e4af17db4db  vmovaps xmm14, [rsp+0xE0]
00007e4af17db4e4  add rsp, 0xF0
00007e4af17db4eb  pop r11
00007e4af17db4ed  pop r10
00007e4af17db4ef  pop r9
00007e4af17db4f1  pop r8
00007e4af17db4f3  pop rsi
00007e4af17db4f4  pop rdi
00007e4af17db4f5  pop rdx
00007e4af17db4f6  pop rcx
00007e4af17db4f7  pop rax
00007e4af17db4f8  add rsp, 0x08
00007e4af17db4fc  jmp 0x00007E4AF17D664A
00007e4af17db501  sub rsp, 0x08
00007e4af17db505  push rax
00007e4af17db506  push rcx
00007e4af17db507  push rdx
00007e4af17db508  push rdi
00007e4af17db509  push rsi
00007e4af17db50a  push r8
00007e4af17db50c  push r9
00007e4af17db50e  push r10
00007e4af17db510  push r11
00007e4af17db512  sub rsp, 0xF0
00007e4af17db519  vmovaps [rsp], xmm0
00007e4af17db51e  vmovaps [rsp+0x10], xmm1
00007e4af17db524  vmovaps [rsp+0x20], xmm2
00007e4af17db52a  vmovaps [rsp+0x30], xmm3
00007e4af17db530  vmovaps [rsp+0x40], xmm4
00007e4af17db536  vmovaps [rsp+0x50], xmm5
00007e4af17db53c  vmovaps [rsp+0x60], xmm6
00007e4af17db542  vmovaps [rsp+0x70], xmm7
00007e4af17db548  vmovaps [rsp+0x80], xmm8
00007e4af17db551  vmovaps [rsp+0x90], xmm9
00007e4af17db55a  vmovaps [rsp+0xA0], xmm10
00007e4af17db563  vmovaps [rsp+0xB0], xmm11
00007e4af17db56c  vmovaps [rsp+0xC0], xmm12
00007e4af17db575  vmovaps [rsp+0xD0], xmm14
00007e4af17db57e  vmovaps [rsp+0xE0], xmm15
00007e4af17db587  sub rsp, 0x30
00007e4af17db58b  movaps [rsp], xmm13
00007e4af17db590  movaps [rsp+0x10], xmm10
00007e4af17db596  movaps [rsp+0x20], xmm14
00007e4af17db59c  lea rdi, [rsp]
00007e4af17db5a0  mov esi, 0x00
00007e4af17db5a5  mov rax, 0x6256754A7530
00007e4af17db5af  call rax
00007e4af17db5b1  movaps xmm13, [rsp]
00007e4af17db5b6  add rsp, 0x30
00007e4af17db5ba  vmovaps xmm0, [rsp]
00007e4af17db5bf  vmovaps xmm1, [rsp+0x10]
00007e4af17db5c5  vmovaps xmm2, [rsp+0x20]
00007e4af17db5cb  vmovaps xmm3, [rsp+0x30]
00007e4af17db5d1  vmovaps xmm4, [rsp+0x40]
00007e4af17db5d7  vmovaps xmm5, [rsp+0x50]
00007e4af17db5dd  vmovaps xmm6, [rsp+0x60]
00007e4af17db5e3  vmovaps xmm7, [rsp+0x70]
00007e4af17db5e9  vmovaps xmm8, [rsp+0x80]
00007e4af17db5f2  vmovaps xmm9, [rsp+0x90]
00007e4af17db5fb  vmovaps xmm10, [rsp+0xA0]
00007e4af17db604  vmovaps xmm11, [rsp+0xB0]
00007e4af17db60d  vmovaps xmm12, [rsp+0xC0]
00007e4af17db616  vmovaps xmm14, [rsp+0xD0]
00007e4af17db61f  vmovaps xmm15, [rsp+0xE0]
00007e4af17db628  add rsp, 0xF0
00007e4af17db62f  pop r11
00007e4af17db631  pop r10
00007e4af17db633  pop r9
00007e4af17db635  pop r8
00007e4af17db637  pop rsi
00007e4af17db638  pop rdi
00007e4af17db639  pop rdx
00007e4af17db63a  pop rcx
00007e4af17db63b  pop rax
00007e4af17db63c  add rsp, 0x08
00007e4af17db640  jmp 0x00007E4AF17D666D
00007e4af17db645  sub rsp, 0x08
00007e4af17db649  push rax
00007e4af17db64a  push rcx
00007e4af17db64b  push rdx
00007e4af17db64c  push rdi
00007e4af17db64d  push rsi
00007e4af17db64e  push r8
00007e4af17db650  push r9
00007e4af17db652  push r10
00007e4af17db654  push r11
00007e4af17db656  sub rsp, 0xF0
00007e4af17db65d  vmovaps [rsp], xmm0
00007e4af17db662  vmovaps [rsp+0x10], xmm1
00007e4af17db668  vmovaps [rsp+0x20], xmm2
00007e4af17db66e  vmovaps [rsp+0x30], xmm3
00007e4af17db674  vmovaps [rsp+0x40], xmm4
00007e4af17db67a  vmovaps [rsp+0x50], xmm5
00007e4af17db680  vmovaps [rsp+0x60], xmm6
00007e4af17db686  vmovaps [rsp+0x70], xmm7
00007e4af17db68c  vmovaps [rsp+0x80], xmm8
00007e4af17db695  vmovaps [rsp+0x90], xmm9
00007e4af17db69e  vmovaps [rsp+0xA0], xmm10
00007e4af17db6a7  vmovaps [rsp+0xB0], xmm11
00007e4af17db6b0  vmovaps [rsp+0xC0], xmm12
00007e4af17db6b9  vmovaps [rsp+0xD0], xmm13
00007e4af17db6c2  vmovaps [rsp+0xE0], xmm15
00007e4af17db6cb  sub rsp, 0x30
00007e4af17db6cf  movaps [rsp], xmm14
00007e4af17db6d4  movaps [rsp+0x10], xmm1
00007e4af17db6d9  movaps [rsp+0x20], xmm7
00007e4af17db6de  lea rdi, [rsp]
00007e4af17db6e2  mov esi, 0x00
00007e4af17db6e7  mov rax, 0x6256754A7530
00007e4af17db6f1  call rax
00007e4af17db6f3  movaps xmm14, [rsp]
00007e4af17db6f8  add rsp, 0x30
00007e4af17db6fc  vmovaps xmm0, [rsp]
00007e4af17db701  vmovaps xmm1, [rsp+0x10]
00007e4af17db707  vmovaps xmm2, [rsp+0x20]
00007e4af17db70d  vmovaps xmm3, [rsp+0x30]
00007e4af17db713  vmovaps xmm4, [rsp+0x40]
00007e4af17db719  vmovaps xmm5, [rsp+0x50]
00007e4af17db71f  vmovaps xmm6, [rsp+0x60]
00007e4af17db725  vmovaps xmm7, [rsp+0x70]
00007e4af17db72b  vmovaps xmm8, [rsp+0x80]
00007e4af17db734  vmovaps xmm9, [rsp+0x90]
00007e4af17db73d  vmovaps xmm10, [rsp+0xA0]
00007e4af17db746  vmovaps xmm11, [rsp+0xB0]
00007e4af17db74f  vmovaps xmm12, [rsp+0xC0]
00007e4af17db758  vmovaps xmm13, [rsp+0xD0]
00007e4af17db761  vmovaps xmm15, [rsp+0xE0]
00007e4af17db76a  add rsp, 0xF0
00007e4af17db771  pop r11
00007e4af17db773  pop r10
00007e4af17db775  pop r9
00007e4af17db777  pop r8
00007e4af17db779  pop rsi
00007e4af17db77a  pop rdi
00007e4af17db77b  pop rdx
00007e4af17db77c  pop rcx
00007e4af17db77d  pop rax
00007e4af17db77e  add rsp, 0x08
00007e4af17db782  jmp 0x00007E4AF17D6690
00007e4af17db787  sub rsp, 0x08
00007e4af17db78b  push rax
00007e4af17db78c  push rcx
00007e4af17db78d  push rdx
00007e4af17db78e  push rdi
00007e4af17db78f  push rsi
00007e4af17db790  push r8
00007e4af17db792  push r9
00007e4af17db794  push r10
00007e4af17db796  push r11
00007e4af17db798  sub rsp, 0xF0
00007e4af17db79f  vmovaps [rsp], xmm0
00007e4af17db7a4  vmovaps [rsp+0x10], xmm2
00007e4af17db7aa  vmovaps [rsp+0x20], xmm3
00007e4af17db7b0  vmovaps [rsp+0x30], xmm4
00007e4af17db7b6  vmovaps [rsp+0x40], xmm5
00007e4af17db7bc  vmovaps [rsp+0x50], xmm6
00007e4af17db7c2  vmovaps [rsp+0x60], xmm7
00007e4af17db7c8  vmovaps [rsp+0x70], xmm8
00007e4af17db7ce  vmovaps [rsp+0x80], xmm9
00007e4af17db7d7  vmovaps [rsp+0x90], xmm10
00007e4af17db7e0  vmovaps [rsp+0xA0], xmm11
00007e4af17db7e9  vmovaps [rsp+0xB0], xmm12
00007e4af17db7f2  vmovaps [rsp+0xC0], xmm13
00007e4af17db7fb  vmovaps [rsp+0xD0], xmm14
00007e4af17db804  vmovaps [rsp+0xE0], xmm15
00007e4af17db80d  sub rsp, 0x30
00007e4af17db811  movaps [rsp], xmm1
00007e4af17db815  movaps [rsp+0x10], xmm8
00007e4af17db81b  movaps [rsp+0x20], xmm9
00007e4af17db821  lea rdi, [rsp]
00007e4af17db825  mov esi, 0x00
00007e4af17db82a  mov rax, 0x6256754A7530
00007e4af17db834  call rax
00007e4af17db836  movaps xmm1, [rsp]
00007e4af17db83a  add rsp, 0x30
00007e4af17db83e  vmovaps xmm0, [rsp]
00007e4af17db843  vmovaps xmm2, [rsp+0x10]
00007e4af17db849  vmovaps xmm3, [rsp+0x20]
00007e4af17db84f  vmovaps xmm4, [rsp+0x30]
00007e4af17db855  vmovaps xmm5, [rsp+0x40]
00007e4af17db85b  vmovaps xmm6, [rsp+0x50]
00007e4af17db861  vmovaps xmm7, [rsp+0x60]
00007e4af17db867  vmovaps xmm8, [rsp+0x70]
00007e4af17db86d  vmovaps xmm9, [rsp+0x80]
00007e4af17db876  vmovaps xmm10, [rsp+0x90]
00007e4af17db87f  vmovaps xmm11, [rsp+0xA0]
00007e4af17db888  vmovaps xmm12, [rsp+0xB0]
00007e4af17db891  vmovaps xmm13, [rsp+0xC0]
00007e4af17db89a  vmovaps xmm14, [rsp+0xD0]
00007e4af17db8a3  vmovaps xmm15, [rsp+0xE0]
00007e4af17db8ac  add rsp, 0xF0
00007e4af17db8b3  pop r11
00007e4af17db8b5  pop r10
00007e4af17db8b7  pop r9
00007e4af17db8b9  pop r8
00007e4af17db8bb  pop rsi
00007e4af17db8bc  pop rdi
00007e4af17db8bd  pop rdx
00007e4af17db8be  pop rcx
00007e4af17db8bf  pop rax
00007e4af17db8c0  add rsp, 0x08
00007e4af17db8c4  jmp 0x00007E4AF17D66B2
00007e4af17db8c9  call 0x00007E4AF16B3E40
00007e4af17db8ce  jmp 0x00007E4AF17D66C0
00007e4af17db8d3  call 0x00007E4AF160C380
00007e4af17db8d8  jmp 0x00007E4AF17D66CA
00007e4af17db8dd  call 0x00007E4AF160D600
00007e4af17db8e2  jmp 0x00007E4AF17D66D4
00007e4af17db8e7  call 0x00007E4AF15FF540
00007e4af17db8ec  jmp 0x00007E4AF17D66DE
00007e4af17db8f1  int3
00007e4af17db8f2  nop [rax+rax*1], ax
00007e4af17db8fb  nop [rax+rax*1], eax
00007e4af17db900  mov eax, [r15+0x48]
00007e4af17db904  lea r14d, [eax+0x01]
00007e4af17db909  mov [rsp+0x10], r14d
00007e4af17db90e  mov r14d, r14d
00007e4af17db911  mov [r15+0x48], r14
00007e4af17db915  xor eax, eax
00007e4af17db917  mov r14d, [rsp+0x10]
00007e4af17db91c  cmp r14d, 0x1F4
00007e4af17db923  cmc
00007e4af17db924  lahf
00007e4af17db925  seto al
00007e4af17db928  mov [r15+0x108], eax
00007e4af17db92f  mov eax, [r15+0x108]
00007e4af17db936  sahf
00007e4af17db937  jnz 0x00007E4AF17DB969
00007e4af17db939  cmp dword ptr [r15+0x318], 0x00
00007e4af17db941  jz 0x00007E4AF17E1AB0
00007e4af17db947  nop [rax+rax*1], ax
00007e4af17db950  nop [rax+rax*1], eax
00007e4af17db958  mov eax, 0x410450
00007e4af17db95d  mov [r15+0x100], rax
00007e4af17db964  jmp 0x00007E4AF15FE110
00007e4af17db969  cmp dword ptr [r15+0x318], 0x00
00007e4af17db971  jz 0x00007E4AF17DB9A0
00007e4af17db977  nop [rax+rax*1], ax
00007e4af17db980  nop [rax+rax*1], eax
00007e4af17db988  mov eax, 0x410274
00007e4af17db98d  mov [r15+0x100], rax
00007e4af17db994  jmp 0x00007E4AF15FE110
00007e4af17db999  int3
00007e4af17db99a  int3
00007e4af17db99b  nop [rax+rax*1], eax
00007e4af17db9a0  mov rax, [r15+0x40]
00007e4af17db9a4  movaps xmm1, [r15+0x1D0]
00007e4af17db9ac  vmovaps [rsp+0x10], xmm1
00007e4af17db9b2  vmovaps xmm15, [rsp+0x10]
00007e4af17db9b8  por xmm1, xmm15
00007e4af17db9bd  movaps xmm14, [r15+0x1A0]
00007e4af17db9c5  vmovaps [rsp+0x10], xmm14
00007e4af17db9cb  vmovaps xmm13, [rsp+0x10]
00007e4af17db9d1  por xmm14, xmm13
00007e4af17db9d6  lea r14, [rax+0x30]
00007e4af17db9da  mov r12, [r13+r14*1]
00007e4af17db9df  lea r14, [rax+0x38]
00007e4af17db9e3  mov r11, [r13+r14*1]
00007e4af17db9e8  movq xmm13, r12
00007e4af17db9ed  movq xmm12, r11
00007e4af17db9f2  movq xmm13, xmm13
00007e4af17db9f7  vmovaps [rsp+0x10], xmm13
00007e4af17db9fd  movq xmm13, xmm13
00007e4af17dba02  movaps [r15+0x130], xmm13
00007e4af17dba0a  movq xmm12, xmm12
00007e4af17dba0f  vmovaps [rsp+0x20], xmm12
00007e4af17dba15  movq xmm12, xmm12
00007e4af17dba1a  movaps [r15+0x280], xmm12
00007e4af17dba22  movaps xmm13, [r15+0x270]
00007e4af17dba2a  vmovaps [rsp+0x30], xmm13
00007e4af17dba30  vmovaps xmm12, [rsp+0x30]
00007e4af17dba36  por xmm13, xmm12
00007e4af17dba3b  lea r14, [rax+0x20]
00007e4af17dba3f  mov r12, [r13+r14*1]
00007e4af17dba44  lea r14, [rax+0x28]
00007e4af17dba48  mov r11, [r13+r14*1]
00007e4af17dba4d  movq xmm12, r12
00007e4af17dba52  movq xmm11, r11
00007e4af17dba57  movq xmm12, xmm12
00007e4af17dba5c  vmovaps [rsp+0x30], xmm12
00007e4af17dba62  movq xmm12, xmm12
00007e4af17dba67  movaps [r15+0x150], xmm12
00007e4af17dba6f  movq xmm11, xmm11
00007e4af17dba74  vmovaps [rsp+0x40], xmm11
00007e4af17dba7a  movq xmm11, xmm11
00007e4af17dba7f  movaps [r15+0x140], xmm11
00007e4af17dba87  lea r14, [rax+0x10]
00007e4af17dba8b  mov r12, [r13+r14*1]
00007e4af17dba90  lea r14, [rax+0x18]
00007e4af17dba94  mov r11, [r13+r14*1]
00007e4af17dba99  movq xmm12, r12
00007e4af17dba9e  movq xmm11, r11
00007e4af17dbaa3  movq xmm12, xmm12
00007e4af17dbaa8  vmovaps [rsp+0x50], xmm12
00007e4af17dbaae  movq xmm12, xmm12
00007e4af17dbab3  movaps [r15+0x170], xmm12
00007e4af17dbabb  movq xmm11, xmm11
00007e4af17dbac0  vmovaps [rsp+0x60], xmm11
00007e4af17dbac6  movq xmm11, xmm11
00007e4af17dbacb  movaps [r15+0x160], xmm11
00007e4af17dbad3  mov r14, [r13+rax*1]
00007e4af17dbad8  vmovq xmm12, r14
00007e4af17dbadd  vpbroadcastq xmm12, xmm12
00007e4af17dbae2  lea r14, [rax+0x08]
00007e4af17dbae6  mov rax, [r13+r14*1]
00007e4af17dbaeb  movq xmm11, rax
00007e4af17dbaf0  movaps [r15+0x230], xmm11
00007e4af17dbaf8  mov rax, [r15+0xF8]
00007e4af17dbaff  lea r14, [rax+0x50]
00007e4af17dbb03  movups xmm11, [r13+r14*1]
00007e4af17dbb09  lea r14, [rax+0x60]
00007e4af17dbb0d  movups xmm10, [r13+r14*1]
00007e4af17dbb13  lea r14, [rax+0x30]
00007e4af17dbb17  movups xmm9, [r13+r14*1]
00007e4af17dbb1d  mov r14, [r15+0x50]
00007e4af17dbb21  mov [r15+0x60], r14
00007e4af17dbb25  mov qword ptr [r15+0x58], 0x40
00007e4af17dbb2d  movaps xmm8, xmm12
00007e4af17dbb31  mulpd xmm8, xmm15
00007e4af17dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007e4af17dbb3c  ptest xmm7, xmm7
00007e4af17dbb41  jnz 0x00007E4AF17DC96A
00007e4af17dbb47  movq xmm15, qword ptr [r15+0x230]
00007e4af17dbb50  vmovaps [rsp+0x70], xmm15
00007e4af17dbb56  vpermilpd xmm15, xmm15, 0x00
00007e4af17dbb5c  movaps xmm7, xmm9
00007e4af17dbb60  mulpd xmm7, xmm15
00007e4af17dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007e4af17dbb6a  ptest xmm6, xmm6
00007e4af17dbb6f  jnz 0x00007E4AF17DCAAE
00007e4af17dbb75  vxorps xmm15, xmm15, xmm15
00007e4af17dbb7a  vpbroadcastq xmm15, xmm15
00007e4af17dbb7f  movaps xmm9, xmm12
00007e4af17dbb83  mulpd xmm9, xmm10
00007e4af17dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007e4af17dbb8e  ptest xmm6, xmm6
00007e4af17dbb93  jnz 0x00007E4AF17DCBF0
00007e4af17dbb99  movaps xmm10, xmm12
00007e4af17dbb9d  mulpd xmm10, xmm11
00007e4af17dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007e4af17dbba8  ptest xmm6, xmm6
00007e4af17dbbad  jnz 0x00007E4AF17DCD34
00007e4af17dbbb3  movaps xmm11, [r15+0x1F0]
00007e4af17dbbbb  movaps xmm6, xmm12
00007e4af17dbbbf  mulpd xmm6, xmm11
00007e4af17dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007e4af17dbbc9  ptest xmm5, xmm5
00007e4af17dbbce  jnz 0x00007E4AF17DCE78
00007e4af17dbbd4  movaps xmm12, [r15+0x2A0]
00007e4af17dbbdc  vmovaps [rsp+0x80], xmm12
00007e4af17dbbe5  vmovaps xmm11, [rsp+0x80]
00007e4af17dbbee  por xmm12, xmm11
00007e4af17dbbf3  movaps xmm11, [r15+0x250]
00007e4af17dbbfb  vmovaps [rsp+0x80], xmm11
00007e4af17dbc04  vmovaps xmm5, [rsp+0x80]
00007e4af17dbc0d  por xmm11, xmm5
00007e4af17dbc12  vmovaps xmm4, [rsp+0x70]
00007e4af17dbc18  vpermilpd xmm4, xmm4, 0x00
00007e4af17dbc1e  movaps xmm3, xmm5
00007e4af17dbc21  mulpd xmm3, xmm4
00007e4af17dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007e4af17dbc2a  ptest xmm2, xmm2
00007e4af17dbc2f  jnz 0x00007E4AF17DCFBA
00007e4af17dbc35  mov [rsp+0x80], rax
00007e4af17dbc3d  xor eax, eax
00007e4af17dbc3f  mov r12d, 0x40
00007e4af17dbc45  mov r11d, 0x200
00007e4af17dbc4b  cmp r12, r11
00007e4af17dbc4e  cmc
00007e4af17dbc4f  lahf
00007e4af17dbc50  seto al
00007e4af17dbc53  mov [r15+0x108], eax
00007e4af17dbc5a  movaps xmm5, xmm8
00007e4af17dbc5e  addpd xmm5, xmm15
00007e4af17dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007e4af17dbc68  ptest xmm4, xmm4
00007e4af17dbc6d  jnz 0x00007E4AF17DD0FA
00007e4af17dbc73  movaps xmm8, [r15+0x1B0]
00007e4af17dbc7b  movaps xmm4, xmm9
00007e4af17dbc7f  addpd xmm4, xmm8
00007e4af17dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007e4af17dbc89  ptest xmm2, xmm2
00007e4af17dbc8e  jnz 0x00007E4AF17DD23C
00007e4af17dbc94  movaps xmm9, xmm10
00007e4af17dbc98  addpd xmm9, xmm8
00007e4af17dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007e4af17dbca3  ptest xmm2, xmm2
00007e4af17dbca8  jnz 0x00007E4AF17DD37E
00007e4af17dbcae  movaps xmm10, [r15+0x2F0]
00007e4af17dbcb6  vmovaps [rsp+0x90], xmm10
00007e4af17dbcbf  vmovaps xmm8, [rsp+0x90]
00007e4af17dbcc8  por xmm10, xmm8
00007e4af17dbccd  movaps xmm8, [r15+0x2E0]
00007e4af17dbcd5  vmovaps [rsp+0x90], xmm8
00007e4af17dbcde  vmovaps xmm2, [rsp+0x90]
00007e4af17dbce7  por xmm8, xmm2
00007e4af17dbcec  movaps xmm2, [r15+0x2D0]
00007e4af17dbcf4  vmovaps [rsp+0x90], xmm2
00007e4af17dbcfd  vmovaps [rsp+0xA0], xmm1
00007e4af17dbd06  vmovaps xmm1, [rsp+0x90]
00007e4af17dbd0f  por xmm2, xmm1
00007e4af17dbd13  movaps xmm1, [r15+0x200]
00007e4af17dbd1b  vmovaps [rsp+0x90], xmm1
00007e4af17dbd24  vmovaps [rsp+0xB0], xmm15
00007e4af17dbd2d  vmovaps xmm15, [rsp+0x90]
00007e4af17dbd36  por xmm1, xmm15
00007e4af17dbd3b  movaps xmm15, [r15+0x1C0]
00007e4af17dbd43  vmovaps [rsp+0x90], xmm15
00007e4af17dbd4c  vmovaps [rsp+0xC0], xmm1
00007e4af17dbd55  vmovaps xmm1, [rsp+0x90]
00007e4af17dbd5e  por xmm15, xmm1
00007e4af17dbd63  movaps xmm1, [r15+0x190]
00007e4af17dbd6b  vmovaps [rsp+0x90], xmm1
00007e4af17dbd74  vmovaps [rsp+0xD0], xmm15
00007e4af17dbd7d  vmovaps xmm15, [rsp+0x90]
00007e4af17dbd86  por xmm1, xmm15
00007e4af17dbd8b  movaps xmm15, [r15+0x300]
00007e4af17dbd93  vmovaps [rsp+0x90], xmm15
00007e4af17dbd9c  vmovaps [rsp+0xE0], xmm1
00007e4af17dbda5  vmovaps xmm1, [rsp+0x90]
00007e4af17dbdae  por xmm15, xmm1
00007e4af17dbdb3  mov rax, [rsp+0x80]
00007e4af17dbdbb  lea r12, [rax+0xA0]
00007e4af17dbdc2  movups xmm1, [r13+r12*1]
00007e4af17dbdc8  lea r12, [rax+0xB0]
00007e4af17dbdcf  vmovaps [rsp+0x80], xmm1
00007e4af17dbdd8  movups xmm1, [r13+r12*1]
00007e4af17dbdde  vmovaps [rsp+0x90], xmm1
00007e4af17dbde7  vmovaps [rsp+0xF0], xmm15
00007e4af17dbdf0  vmovaps xmm15, [rsp+0xB0]
00007e4af17dbdf9  vmovaps [rsp+0xB0], xmm14
00007e4af17dbe02  movaps xmm1, xmm6
00007e4af17dbe05  addpd xmm1, xmm15
00007e4af17dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007e4af17dbe0f  ptest xmm14, xmm14
00007e4af17dbe15  jnz 0x00007E4AF17DD4D6
00007e4af17dbe1b  lea r12, [rax+0xF0]
00007e4af17dbe22  movups xmm15, [r13+r12*1]
00007e4af17dbe28  movaps xmm14, xmm4
00007e4af17dbe2c  addpd xmm14, xmm3
00007e4af17dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007e4af17dbe37  ptest xmm6, xmm6
00007e4af17dbe3c  jnz 0x00007E4AF17DD621
00007e4af17dbe42  movaps xmm6, xmm9
00007e4af17dbe46  addpd xmm6, xmm7
00007e4af17dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007e4af17dbe4f  ptest xmm4, xmm4
00007e4af17dbe54  jnz 0x00007E4AF17DD763
00007e4af17dbe5a  vmovaps xmm9, [rsp+0x70]
00007e4af17dbe60  vpermilpd xmm9, xmm9, 0x00
00007e4af17dbe66  vmovaps xmm4, [rsp+0x90]
00007e4af17dbe6f  movaps xmm7, xmm4
00007e4af17dbe72  mulpd xmm7, xmm9
00007e4af17dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007e4af17dbe7c  ptest xmm3, xmm3
00007e4af17dbe81  jnz 0x00007E4AF17DD8A4
00007e4af17dbe87  vmovaps xmm9, [rsp+0x50]
00007e4af17dbe8d  vpermilpd xmm9, xmm9, 0x00
00007e4af17dbe93  movaps xmm4, xmm15
00007e4af17dbe97  mulpd xmm4, xmm9
00007e4af17dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007e4af17dbea1  ptest xmm3, xmm3
00007e4af17dbea6  jnz 0x00007E4AF17DD9E5
00007e4af17dbeac  lea r12, [rax+0xE0]
00007e4af17dbeb3  movups xmm15, [r13+r12*1]
00007e4af17dbeb9  vmovaps xmm9, [rsp+0x70]
00007e4af17dbebf  vpermilpd xmm9, xmm9, 0x00
00007e4af17dbec5  vmovaps [rsp+0x70], xmm1
00007e4af17dbecb  vmovaps xmm1, [rsp+0x80]
00007e4af17dbed4  vmovaps [rsp+0x80], xmm15
00007e4af17dbedd  movaps xmm3, xmm1
00007e4af17dbee0  mulpd xmm3, xmm9
00007e4af17dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007e4af17dbeea  ptest xmm15, xmm15
00007e4af17dbef0  jnz 0x00007E4AF17DDB31
00007e4af17dbef6  vmovaps xmm1, [rsp+0xF0]
00007e4af17dbeff  vmovaps xmm15, [rsp+0xF0]
00007e4af17dbf08  por xmm1, xmm15
00007e4af17dbf0d  movaps [r15+0x300], xmm1
00007e4af17dbf15  vmovaps xmm15, [rsp+0xE0]
00007e4af17dbf1e  vmovaps xmm9, [rsp+0xE0]
00007e4af17dbf27  por xmm15, xmm9
00007e4af17dbf2c  movaps [r15+0x190], xmm15
00007e4af17dbf34  vmovaps xmm9, [rsp+0x50]
00007e4af17dbf3a  vpermilpd xmm9, xmm9, 0x00
00007e4af17dbf40  vmovaps [rsp+0x90], xmm1
00007e4af17dbf49  vmovaps [rsp+0xE0], xmm15
00007e4af17dbf52  vmovaps xmm15, [rsp+0x80]
00007e4af17dbf5b  vmovaps [rsp+0x80], xmm14
00007e4af17dbf64  movaps xmm1, xmm15
00007e4af17dbf68  mulpd xmm1, xmm9
00007e4af17dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007e4af17dbf72  ptest xmm14, xmm14
00007e4af17dbf78  jnz 0x00007E4AF17DDC72
00007e4af17dbf7e  lea r12, [rax+0x90]
00007e4af17dbf85  movups xmm15, [r13+r12*1]
00007e4af17dbf8b  vmovaps xmm14, [rsp+0xD0]
00007e4af17dbf94  vmovaps xmm9, [rsp+0xD0]
00007e4af17dbf9d  por xmm14, xmm9
00007e4af17dbfa2  movaps [r15+0x1C0], xmm14
00007e4af17dbfaa  vmovaps xmm9, [rsp+0xC0]
00007e4af17dbfb3  vmovaps [rsp+0xD0], xmm1
00007e4af17dbfbc  vmovaps xmm1, [rsp+0xC0]
00007e4af17dbfc5  por xmm9, xmm1
00007e4af17dbfca  movaps [r15+0x200], xmm9
00007e4af17dbfd2  vmovaps [rsp+0xC0], xmm2
00007e4af17dbfdb  vmovaps xmm1, [rsp+0xC0]
00007e4af17dbfe4  por xmm2, xmm1
00007e4af17dbfe8  movaps [r15+0x2D0], xmm2
00007e4af17dbff0  vmovaps [rsp+0xC0], xmm8
00007e4af17dbff9  vmovaps xmm1, [rsp+0xC0]
00007e4af17dc002  por xmm8, xmm1
00007e4af17dc007  movaps [r15+0x2E0], xmm8
00007e4af17dc00f  vmovaps [rsp+0xC0], xmm15
00007e4af17dc018  movaps xmm1, xmm5
00007e4af17dc01b  addpd xmm1, xmm7
00007e4af17dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007e4af17dc024  ptest xmm15, xmm15
00007e4af17dc02a  jnz 0x00007E4AF17DDDBE
00007e4af17dc030  vmovaps xmm15, [rsp+0x50]
00007e4af17dc036  vpermilpd xmm15, xmm15, 0x00
00007e4af17dc03c  vmovaps xmm5, [rsp+0xC0]
00007e4af17dc045  vmovaps [rsp+0xC0], xmm1
00007e4af17dc04e  movaps xmm7, xmm5
00007e4af17dc051  mulpd xmm7, xmm15
00007e4af17dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007e4af17dc05b  ptest xmm1, xmm1
00007e4af17dc060  jnz 0x00007E4AF17DDEFE
00007e4af17dc066  lea r12, [rax+0x80]
00007e4af17dc06d  movups xmm1, [r13+r12*1]
00007e4af17dc073  vmovaps xmm5, [rsp+0x70]
00007e4af17dc079  vmovaps [rsp+0x70], xmm1
00007e4af17dc07f  movaps xmm15, xmm5
00007e4af17dc083  addpd xmm15, xmm3
00007e4af17dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007e4af17dc08e  ptest xmm1, xmm1
00007e4af17dc093  jnz 0x00007E4AF17DE049
00007e4af17dc099  vmovaps xmm5, [rsp+0x80]
00007e4af17dc0a2  movaps xmm1, xmm5
00007e4af17dc0a5  addpd xmm1, xmm4
00007e4af17dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007e4af17dc0ae  ptest xmm3, xmm3
00007e4af17dc0b3  jnz 0x00007E4AF17DE18B
00007e4af17dc0b9  vmovaps [rsp+0x80], xmm10
00007e4af17dc0c2  vmovaps xmm5, [rsp+0x80]
00007e4af17dc0cb  por xmm10, xmm5
00007e4af17dc0d0  movaps [r15+0x2F0], xmm10
00007e4af17dc0d8  vmovaps xmm5, [rsp+0x50]
00007e4af17dc0de  vpermilpd xmm5, xmm5, 0x00
00007e4af17dc0e4  vmovaps xmm3, [rsp+0x70]
00007e4af17dc0ea  vmovaps [rsp+0x50], xmm1
00007e4af17dc0f0  movaps xmm4, xmm3
00007e4af17dc0f3  mulpd xmm4, xmm5
00007e4af17dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007e4af17dc0fc  ptest xmm1, xmm1
00007e4af17dc101  jnz 0x00007E4AF17DE2CB
00007e4af17dc107  lea r12, [rax+0xD0]
00007e4af17dc10e  movups xmm1, [r13+r12*1]
00007e4af17dc114  vmovaps xmm3, [rsp+0xD0]
00007e4af17dc11d  vmovaps [rsp+0x70], xmm1
00007e4af17dc123  movaps xmm5, xmm6
00007e4af17dc126  addpd xmm5, xmm3
00007e4af17dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007e4af17dc12f  ptest xmm1, xmm1
00007e4af17dc134  jnz 0x00007E4AF17DE415
00007e4af17dc13a  vmovaps xmm1, [rsp+0x60]
00007e4af17dc140  vpermilpd xmm1, xmm1, 0x00
00007e4af17dc146  movaps xmm6, xmm9
00007e4af17dc14a  mulpd xmm6, xmm1
00007e4af17dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007e4af17dc153  ptest xmm3, xmm3
00007e4af17dc158  jnz 0x00007E4AF17DE555
00007e4af17dc15e  movaps [r15+0x260], xmm6
00007e4af17dc166  vxorps xmm1, xmm1, xmm1
00007e4af17dc16a  vpbroadcastq xmm1, xmm1
00007e4af17dc16f  movaps [r15+0x1B0], xmm1
00007e4af17dc177  vmovaps xmm1, [rsp+0x60]
00007e4af17dc17d  vpermilpd xmm1, xmm1, 0x00
00007e4af17dc183  vmovaps xmm3, [rsp+0x70]
00007e4af17dc189  vmovaps [rsp+0x70], xmm15
00007e4af17dc18f  movaps xmm9, xmm3
00007e4af17dc193  mulpd xmm9, xmm1
00007e4af17dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007e4af17dc19e  ptest xmm15, xmm15
00007e4af17dc1a4  jnz 0x00007E4AF17DE696
00007e4af17dc1aa  lea r12, [rax+0xC0]
00007e4af17dc1b1  movups xmm1, [r13+r12*1]
00007e4af17dc1b7  vmovaps xmm3, [rsp+0xC0]
00007e4af17dc1c0  vmovaps [rsp+0x80], xmm1
00007e4af17dc1c9  movaps xmm15, xmm3
00007e4af17dc1cd  addpd xmm15, xmm7
00007e4af17dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007e4af17dc1d8  ptest xmm1, xmm1
00007e4af17dc1dd  jnz 0x00007E4AF17DE7E2
00007e4af17dc1e3  vmovaps [rsp+0xC0], xmm13
00007e4af17dc1ec  vmovaps xmm1, [rsp+0xC0]
00007e4af17dc1f5  por xmm13, xmm1
00007e4af17dc1fa  movaps [r15+0x270], xmm13
00007e4af17dc202  vmovaps xmm1, [rsp+0xB0]
00007e4af17dc20b  vmovaps xmm7, [rsp+0xB0]
00007e4af17dc214  por xmm1, xmm7
00007e4af17dc218  movaps [r15+0x1A0], xmm1
00007e4af17dc220  vmovaps xmm1, [rsp+0x60]
00007e4af17dc226  vpermilpd xmm1, xmm1, 0x00
00007e4af17dc22c  vmovaps [rsp+0xB0], xmm1
00007e4af17dc235  vmovaps xmm1, [rsp+0x80]
00007e4af17dc23e  vmovaps [rsp+0x80], xmm15
00007e4af17dc247  vmovaps xmm15, [rsp+0xB0]
00007e4af17dc250  vmovaps [rsp+0xB0], xmm14
00007e4af17dc259  movaps xmm3, xmm1
00007e4af17dc25c  mulpd xmm3, xmm15
00007e4af17dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007e4af17dc266  ptest xmm14, xmm14
00007e4af17dc26c  jnz 0x00007E4AF17DE924
00007e4af17dc272  lea r12, [rax+0x20]
00007e4af17dc276  movups xmm1, [r13+r12*1]
00007e4af17dc27c  movaps [r15+0x110], xmm1
00007e4af17dc284  vmovaps xmm14, [rsp+0x70]
00007e4af17dc28a  vmovaps [rsp+0x70], xmm1
00007e4af17dc290  movaps xmm15, xmm14
00007e4af17dc294  addpd xmm15, xmm4
00007e4af17dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007e4af17dc29f  ptest xmm1, xmm1
00007e4af17dc2a4  jnz 0x00007E4AF17DEA6F
00007e4af17dc2aa  vmovaps xmm1, [rsp+0x60]
00007e4af17dc2b0  vpermilpd xmm1, xmm1, 0x00
00007e4af17dc2b6  movaps xmm14, xmm2
00007e4af17dc2ba  mulpd xmm14, xmm1
00007e4af17dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007e4af17dc2c5  ptest xmm4, xmm4
00007e4af17dc2ca  jnz 0x00007E4AF17DEBB2
00007e4af17dc2d0  vmovaps xmm4, [rsp+0x50]
00007e4af17dc2d6  movaps xmm1, xmm4
00007e4af17dc2d9  addpd xmm1, xmm9
00007e4af17dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007e4af17dc2e3  ptest xmm2, xmm2
00007e4af17dc2e8  jnz 0x00007E4AF17DECF4
00007e4af17dc2ee  vmovaps xmm9, [rsp+0x30]
00007e4af17dc2f4  vpermilpd xmm9, xmm9, 0x00
00007e4af17dc2fa  vmovaps xmm2, [rsp+0x70]
00007e4af17dc300  vmovaps [rsp+0x50], xmm1
00007e4af17dc306  movaps xmm4, xmm2
00007e4af17dc309  mulpd xmm4, xmm9
00007e4af17dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007e4af17dc313  ptest xmm1, xmm1
00007e4af17dc318  jnz 0x00007E4AF17DEE35
00007e4af17dc31e  vmovaps xmm1, [rsp+0x30]
00007e4af17dc324  vpermilpd xmm1, xmm1, 0x00
00007e4af17dc32a  vmovaps xmm2, [rsp+0x90]
00007e4af17dc333  vmovaps [rsp+0x60], xmm15
00007e4af17dc339  movaps xmm9, xmm2
00007e4af17dc33d  mulpd xmm9, xmm1
00007e4af17dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007e4af17dc348  ptest xmm15, xmm15
00007e4af17dc34e  jnz 0x00007E4AF17DEF76
00007e4af17dc354  vmovaps xmm15, [rsp+0x80]
00007e4af17dc35d  movaps xmm1, xmm15
00007e4af17dc361  addpd xmm1, xmm6
00007e4af17dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007e4af17dc36a  ptest xmm2, xmm2
00007e4af17dc36f  jnz 0x00007E4AF17DF0B8
00007e4af17dc375  movaps xmm15, xmm5
00007e4af17dc379  addpd xmm15, xmm3
00007e4af17dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007e4af17dc384  ptest xmm6, xmm6
00007e4af17dc389  jnz 0x00007E4AF17DF1F9
00007e4af17dc38f  vmovaps xmm6, [rsp+0x30]
00007e4af17dc395  vpermilpd xmm6, xmm6, 0x00
00007e4af17dc39b  movaps xmm5, xmm8
00007e4af17dc39f  mulpd xmm5, xmm6
00007e4af17dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007e4af17dc3a8  ptest xmm3, xmm3
00007e4af17dc3ad  jnz 0x00007E4AF17DF33B
00007e4af17dc3b3  vmovaps xmm8, [rsp+0x30]
00007e4af17dc3b9  vpermilpd xmm8, xmm8, 0x00
00007e4af17dc3bf  movaps xmm6, xmm10
00007e4af17dc3c3  mulpd xmm6, xmm8
00007e4af17dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007e4af17dc3cd  ptest xmm3, xmm3
00007e4af17dc3d2  jnz 0x00007E4AF17DF47C
00007e4af17dc3d8  vmovaps xmm8, [rsp+0x60]
00007e4af17dc3de  movaps xmm10, xmm8
00007e4af17dc3e2  addpd xmm10, xmm14
00007e4af17dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007e4af17dc3ed  ptest xmm3, xmm3
00007e4af17dc3f2  jnz 0x00007E4AF17DF5BE
00007e4af17dc3f8  vmovaps xmm8, [rsp+0x50]
00007e4af17dc3fe  movaps xmm14, xmm8
00007e4af17dc402  addpd xmm14, xmm4
00007e4af17dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007e4af17dc40d  ptest xmm3, xmm3
00007e4af17dc412  jnz 0x00007E4AF17DF702
00007e4af17dc418  vmovaps xmm8, [rsp+0x40]
00007e4af17dc41e  vpermilpd xmm8, xmm8, 0x00
00007e4af17dc424  movaps xmm4, xmm13
00007e4af17dc428  mulpd xmm4, xmm8
00007e4af17dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007e4af17dc432  ptest xmm3, xmm3
00007e4af17dc437  jnz 0x00007E4AF17DF845
00007e4af17dc43d  movaps xmm13, xmm15
00007e4af17dc441  addpd xmm13, xmm9
00007e4af17dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007e4af17dc44c  ptest xmm8, xmm8
00007e4af17dc452  jnz 0x00007E4AF17DF987
00007e4af17dc458  movaps xmm15, xmm1
00007e4af17dc45c  addpd xmm15, xmm5
00007e4af17dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007e4af17dc467  ptest xmm9, xmm9
00007e4af17dc46d  jnz 0x00007E4AF17DFACB
00007e4af17dc473  vmovaps [rsp+0x30], xmm11
00007e4af17dc479  vmovaps xmm1, [rsp+0x30]
00007e4af17dc47f  por xmm11, xmm1
00007e4af17dc484  movaps [r15+0x250], xmm11
00007e4af17dc48c  vmovaps [rsp+0x30], xmm12
00007e4af17dc492  vmovaps xmm1, [rsp+0x30]
00007e4af17dc498  por xmm12, xmm1
00007e4af17dc49d  movaps [r15+0x2A0], xmm12
00007e4af17dc4a5  vmovaps xmm1, [rsp+0xA0]
00007e4af17dc4ae  vmovaps xmm11, [rsp+0xA0]
00007e4af17dc4b7  por xmm1, xmm11
00007e4af17dc4bc  movaps [r15+0x1D0], xmm1
00007e4af17dc4c4  lea r12, [rax+0x40]
00007e4af17dc4c8  movups xmm1, [r13+r12*1]
00007e4af17dc4ce  movaps [r15+0x2C0], xmm1
00007e4af17dc4d6  vmovaps xmm11, [rsp+0x40]
00007e4af17dc4dc  vpermilpd xmm11, xmm11, 0x00
00007e4af17dc4e2  vmovaps xmm8, [rsp+0xE0]
00007e4af17dc4eb  movaps xmm9, xmm8
00007e4af17dc4ef  mulpd xmm9, xmm11
00007e4af17dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007e4af17dc4fa  ptest xmm5, xmm5
00007e4af17dc4ff  jnz 0x00007E4AF17DFC17
00007e4af17dc505  movaps xmm11, xmm10
00007e4af17dc509  addpd xmm11, xmm6
00007e4af17dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007e4af17dc514  ptest xmm8, xmm8
00007e4af17dc51a  jnz 0x00007E4AF17DFD5B
00007e4af17dc520  movaps xmm10, xmm14
00007e4af17dc524  addpd xmm10, xmm4
00007e4af17dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007e4af17dc52f  ptest xmm8, xmm8
00007e4af17dc535  jnz 0x00007E4AF17DFE9E
00007e4af17dc53b  vmovaps xmm14, [rsp+0x40]
00007e4af17dc541  vpermilpd xmm14, xmm14, 0x00
00007e4af17dc547  movaps xmm8, xmm1
00007e4af17dc54b  mulpd xmm8, xmm14
00007e4af17dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007e4af17dc556  ptest xmm6, xmm6
00007e4af17dc55b  jnz 0x00007E4AF17DFFE1
00007e4af17dc561  movaps xmm1, [r15+0x2B0]
00007e4af17dc569  vmovaps xmm14, [rsp+0x40]
00007e4af17dc56f  vpermilpd xmm14, xmm14, 0x00
00007e4af17dc575  movaps xmm6, xmm1
00007e4af17dc578  mulpd xmm6, xmm14
00007e4af17dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007e4af17dc582  ptest xmm5, xmm5
00007e4af17dc587  jnz 0x00007E4AF17E0124
00007e4af17dc58d  vmovaps xmm1, [rsp+0x10]
00007e4af17dc593  vpermilpd xmm1, xmm1, 0x00
00007e4af17dc599  movaps xmm14, xmm12
00007e4af17dc59d  mulpd xmm14, xmm1
00007e4af17dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007e4af17dc5a8  ptest xmm5, xmm5
00007e4af17dc5ad  jnz 0x00007E4AF17E0265
00007e4af17dc5b3  movaps xmm1, xmm13
00007e4af17dc5b7  addpd xmm1, xmm9
00007e4af17dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007e4af17dc5c1  ptest xmm12, xmm12
00007e4af17dc5c7  jnz 0x00007E4AF17E03A8
00007e4af17dc5cd  vmovaps xmm13, [rsp+0x10]
00007e4af17dc5d3  vpermilpd xmm13, xmm13, 0x00
00007e4af17dc5d9  movaps xmm12, xmm7
00007e4af17dc5dd  mulpd xmm12, xmm13
00007e4af17dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007e4af17dc5e8  ptest xmm9, xmm9
00007e4af17dc5ee  jnz 0x00007E4AF17E04EA
00007e4af17dc5f4  movaps xmm13, xmm15
00007e4af17dc5f8  addpd xmm13, xmm8
00007e4af17dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007e4af17dc603  ptest xmm9, xmm9
00007e4af17dc609  jnz 0x00007E4AF17E062D
00007e4af17dc60f  movaps xmm15, [r15+0x290]
00007e4af17dc617  vmovaps xmm9, [rsp+0x10]
00007e4af17dc61d  vpermilpd xmm9, xmm9, 0x00
00007e4af17dc623  movaps xmm8, xmm15
00007e4af17dc627  mulpd xmm8, xmm9
00007e4af17dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007e4af17dc632  ptest xmm7, xmm7
00007e4af17dc637  jnz 0x00007E4AF17E0771
00007e4af17dc63d  movaps xmm15, xmm11
00007e4af17dc641  addpd xmm15, xmm6
00007e4af17dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007e4af17dc64c  ptest xmm9, xmm9
00007e4af17dc652  jnz 0x00007E4AF17E08B5
00007e4af17dc658  movaps xmm11, [r15+0x1E0]
00007e4af17dc660  vmovaps xmm9, [rsp+0x10]
00007e4af17dc666  vpermilpd xmm9, xmm9, 0x00
00007e4af17dc66c  movaps xmm7, xmm11
00007e4af17dc670  mulpd xmm7, xmm9
00007e4af17dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007e4af17dc67a  ptest xmm6, xmm6
00007e4af17dc67f  jnz 0x00007E4AF17E09F8
00007e4af17dc685  movaps xmm11, xmm10
00007e4af17dc689  addpd xmm11, xmm14
00007e4af17dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007e4af17dc694  ptest xmm9, xmm9
00007e4af17dc69a  jnz 0x00007E4AF17E0B3A
00007e4af17dc6a0  lea r12, [rax+0x70]
00007e4af17dc6a4  movups xmm14, [r13+r12*1]
00007e4af17dc6aa  movaps [r15+0x240], xmm14
00007e4af17dc6b2  movaps xmm10, xmm1
00007e4af17dc6b6  addpd xmm10, xmm12
00007e4af17dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007e4af17dc6c1  ptest xmm9, xmm9
00007e4af17dc6c7  jnz 0x00007E4AF17E0C88
00007e4af17dc6cd  movaps [r15+0x170], xmm10
00007e4af17dc6d5  vmovaps xmm1, [rsp+0x20]
00007e4af17dc6db  vpermilpd xmm1, xmm1, 0x00
00007e4af17dc6e1  movaps xmm12, xmm14
00007e4af17dc6e5  mulpd xmm12, xmm1
00007e4af17dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007e4af17dc6f0  ptest xmm9, xmm9
00007e4af17dc6f6  jnz 0x00007E4AF17E0DCB
00007e4af17dc6fc  vmovaps xmm1, [rsp+0x20]
00007e4af17dc702  vpermilpd xmm1, xmm1, 0x00
00007e4af17dc708  vmovaps xmm9, [rsp+0xB0]
00007e4af17dc711  movaps xmm14, xmm9
00007e4af17dc715  mulpd xmm14, xmm1
00007e4af17dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007e4af17dc720  ptest xmm6, xmm6
00007e4af17dc725  jnz 0x00007E4AF17E0F0E
00007e4af17dc72b  movaps [r15+0x180], xmm14
00007e4af17dc733  movaps xmm1, xmm13
00007e4af17dc737  addpd xmm1, xmm8
00007e4af17dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007e4af17dc741  ptest xmm9, xmm9
00007e4af17dc747  jnz 0x00007E4AF17E1051
00007e4af17dc74d  movaps [r15+0x210], xmm1
00007e4af17dc755  movups xmm13, [r13+rax*1]
00007e4af17dc75b  lea r12, [rax+0x10]
00007e4af17dc75f  movups xmm9, [r13+r12*1]
00007e4af17dc765  movaps [r15+0x230], xmm9
00007e4af17dc76d  movaps xmm8, xmm15
00007e4af17dc771  addpd xmm8, xmm7
00007e4af17dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007e4af17dc77c  ptest xmm6, xmm6
00007e4af17dc781  jnz 0x00007E4AF17E11A7
00007e4af17dc787  movaps [r15+0x130], xmm8
00007e4af17dc78f  vmovaps xmm15, [rsp+0x20]
00007e4af17dc795  vpermilpd xmm15, xmm15, 0x00
00007e4af17dc79b  movaps xmm7, xmm9
00007e4af17dc79f  mulpd xmm7, xmm15
00007e4af17dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007e4af17dc7a9  ptest xmm6, xmm6
00007e4af17dc7ae  jnz 0x00007E4AF17E12EA
00007e4af17dc7b4  movaps [r15+0x220], xmm7
00007e4af17dc7bc  vmovaps xmm15, [rsp+0x20]
00007e4af17dc7c2  vpermilpd xmm15, xmm15, 0x00
00007e4af17dc7c8  movaps xmm9, xmm13
00007e4af17dc7cc  mulpd xmm9, xmm15
00007e4af17dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007e4af17dc7d7  ptest xmm6, xmm6
00007e4af17dc7dc  jnz 0x00007E4AF17E142C
00007e4af17dc7e2  movaps xmm15, xmm11
00007e4af17dc7e6  addpd xmm15, xmm12
00007e4af17dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007e4af17dc7f1  ptest xmm13, xmm13
00007e4af17dc7f7  jnz 0x00007E4AF17E1570
00007e4af17dc7fd  movaps [r15+0x140], xmm15
00007e4af17dc805  movaps xmm13, xmm10
00007e4af17dc809  addpd xmm13, xmm14
00007e4af17dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007e4af17dc814  ptest xmm12, xmm12
00007e4af17dc81a  jnz 0x00007E4AF17E16B4
00007e4af17dc820  movaps [r15+0x150], xmm13
00007e4af17dc828  movaps xmm14, xmm1
00007e4af17dc82c  addpd xmm14, xmm7
00007e4af17dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007e4af17dc837  ptest xmm12, xmm12
00007e4af17dc83d  jnz 0x00007E4AF17E17F8
00007e4af17dc843  movaps [r15+0x160], xmm14
00007e4af17dc84b  movaps xmm1, xmm8
00007e4af17dc84f  addpd xmm1, xmm9
00007e4af17dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007e4af17dc859  ptest xmm12, xmm12
00007e4af17dc85f  jnz 0x00007E4AF17E193A
00007e4af17dc865  movaps [r15+0x120], xmm1
00007e4af17dc86d  movups [r13+r14*1], xmm15
00007e4af17dc873  lea rax, [r14+0x10]
00007e4af17dc877  movups [r13+rax*1], xmm13
00007e4af17dc87d  lea rax, [r14+0x20]
00007e4af17dc881  movups [r13+rax*1], xmm14
00007e4af17dc887  lea rax, [r14+0x30]
00007e4af17dc88b  movups [r13+rax*1], xmm1
00007e4af17dc891  mov eax, [r15+0x108]
00007e4af17dc898  sahf
00007e4af17dc899  jnz 0x00007E4AF17DC8CB
00007e4af17dc89b  cmp dword ptr [r15+0x318], 0x00
00007e4af17dc8a3  jz 0x00007E4AF17DB900
00007e4af17dc8a9  nop [rax+rax*1], ax
00007e4af17dc8b2  nop [rax+rax*1], eax
00007e4af17dc8ba  mov eax, 0x410444
00007e4af17dc8bf  mov [r15+0x100], rax
00007e4af17dc8c6  jmp 0x00007E4AF15FE110
00007e4af17dc8cb  cmp dword ptr [r15+0x318], 0x00
00007e4af17dc8d3  jz 0x00007E4AF17D57E0
00007e4af17dc8d9  nop [rax+rax*1], ax
00007e4af17dc8e2  nop [rax+rax*1], eax
00007e4af17dc8ea  mov eax, 0x410278
00007e4af17dc8ef  mov [r15+0x100], rax
00007e4af17dc8f6  jmp 0x00007E4AF15FE110
00007e4af17dc8fb  int3
00007e4af17dc8fc  call 0x00007E4AF16E27E0
00007e4af17dc901  jmp 0x00007E4AF17DB9DF
00007e4af17dc906  call 0x00007E4AF16E1570
00007e4af17dc90b  jmp 0x00007E4AF17DB9E8
00007e4af17dc910  call 0x00007E4AF16E27E0
00007e4af17dc915  jmp 0x00007E4AF17DBA44
00007e4af17dc91a  call 0x00007E4AF16E1570
00007e4af17dc91f  jmp 0x00007E4AF17DBA4D
00007e4af17dc924  call 0x00007E4AF16E27E0
00007e4af17dc929  jmp 0x00007E4AF17DBA90
00007e4af17dc92e  call 0x00007E4AF16E1570
00007e4af17dc933  jmp 0x00007E4AF17DBA99
00007e4af17dc938  call 0x00007E4AF160DC20
00007e4af17dc93d  jmp 0x00007E4AF17DBAD8
00007e4af17dc942  call 0x00007E4AF16D59C0
00007e4af17dc947  jmp 0x00007E4AF17DBAEB
00007e4af17dc94c  call 0x00007E4AF16E0E30
00007e4af17dc951  jmp 0x00007E4AF17DBB09
00007e4af17dc956  call 0x00007E4AF16DFBC0
00007e4af17dc95b  jmp 0x00007E4AF17DBB13
00007e4af17dc960  call 0x00007E4AF16DE950
00007e4af17dc965  jmp 0x00007E4AF17DBB1D
00007e4af17dc96a  sub rsp, 0x08
00007e4af17dc96e  push rax
00007e4af17dc96f  push rcx
00007e4af17dc970  push rdx
00007e4af17dc971  push rdi
00007e4af17dc972  push rsi
00007e4af17dc973  push r8
00007e4af17dc975  push r9
00007e4af17dc977  push r10
00007e4af17dc979  push r11
00007e4af17dc97b  sub rsp, 0xF0
00007e4af17dc982  vmovaps [rsp], xmm0
00007e4af17dc987  vmovaps [rsp+0x10], xmm1
00007e4af17dc98d  vmovaps [rsp+0x20], xmm2
00007e4af17dc993  vmovaps [rsp+0x30], xmm3
00007e4af17dc999  vmovaps [rsp+0x40], xmm4
00007e4af17dc99f  vmovaps [rsp+0x50], xmm5
00007e4af17dc9a5  vmovaps [rsp+0x60], xmm6
00007e4af17dc9ab  vmovaps [rsp+0x70], xmm7
00007e4af17dc9b1  vmovaps [rsp+0x80], xmm9
00007e4af17dc9ba  vmovaps [rsp+0x90], xmm10
00007e4af17dc9c3  vmovaps [rsp+0xA0], xmm11
00007e4af17dc9cc  vmovaps [rsp+0xB0], xmm12
00007e4af17dc9d5  vmovaps [rsp+0xC0], xmm13
00007e4af17dc9de  vmovaps [rsp+0xD0], xmm14
00007e4af17dc9e7  vmovaps [rsp+0xE0], xmm15
00007e4af17dc9f0  sub rsp, 0x30
00007e4af17dc9f4  movaps [rsp], xmm8
00007e4af17dc9f9  movaps [rsp+0x10], xmm12
00007e4af17dc9ff  movaps [rsp+0x20], xmm15
00007e4af17dca05  lea rdi, [rsp]
00007e4af17dca09  mov esi, 0x00
00007e4af17dca0e  mov rax, 0x6256754A7530
00007e4af17dca18  call rax
00007e4af17dca1a  movaps xmm8, [rsp]
00007e4af17dca1f  add rsp, 0x30
00007e4af17dca23  vmovaps xmm0, [rsp]
00007e4af17dca28  vmovaps xmm1, [rsp+0x10]
00007e4af17dca2e  vmovaps xmm2, [rsp+0x20]
00007e4af17dca34  vmovaps xmm3, [rsp+0x30]
00007e4af17dca3a  vmovaps xmm4, [rsp+0x40]
00007e4af17dca40  vmovaps xmm5, [rsp+0x50]
00007e4af17dca46  vmovaps xmm6, [rsp+0x60]
00007e4af17dca4c  vmovaps xmm7, [rsp+0x70]
00007e4af17dca52  vmovaps xmm9, [rsp+0x80]
00007e4af17dca5b  vmovaps xmm10, [rsp+0x90]
00007e4af17dca64  vmovaps xmm11, [rsp+0xA0]
00007e4af17dca6d  vmovaps xmm12, [rsp+0xB0]
00007e4af17dca76  vmovaps xmm13, [rsp+0xC0]
00007e4af17dca7f  vmovaps xmm14, [rsp+0xD0]
00007e4af17dca88  vmovaps xmm15, [rsp+0xE0]
00007e4af17dca91  add rsp, 0xF0
00007e4af17dca98  pop r11
00007e4af17dca9a  pop r10
00007e4af17dca9c  pop r9
00007e4af17dca9e  pop r8
00007e4af17dcaa0  pop rsi
00007e4af17dcaa1  pop rdi
00007e4af17dcaa2  pop rdx
00007e4af17dcaa3  pop rcx
00007e4af17dcaa4  pop rax
00007e4af17dcaa5  add rsp, 0x08
00007e4af17dcaa9  jmp 0x00007E4AF17DBB47
00007e4af17dcaae  sub rsp, 0x08
00007e4af17dcab2  push rax
00007e4af17dcab3  push rcx
00007e4af17dcab4  push rdx
00007e4af17dcab5  push rdi
00007e4af17dcab6  push rsi
00007e4af17dcab7  push r8
00007e4af17dcab9  push r9
00007e4af17dcabb  push r10
00007e4af17dcabd  push r11
00007e4af17dcabf  sub rsp, 0xF0
00007e4af17dcac6  vmovaps [rsp], xmm0
00007e4af17dcacb  vmovaps [rsp+0x10], xmm1
00007e4af17dcad1  vmovaps [rsp+0x20], xmm2
00007e4af17dcad7  vmovaps [rsp+0x30], xmm3
00007e4af17dcadd  vmovaps [rsp+0x40], xmm4
00007e4af17dcae3  vmovaps [rsp+0x50], xmm5
00007e4af17dcae9  vmovaps [rsp+0x60], xmm6
00007e4af17dcaef  vmovaps [rsp+0x70], xmm8
00007e4af17dcaf5  vmovaps [rsp+0x80], xmm9
00007e4af17dcafe  vmovaps [rsp+0x90], xmm10
00007e4af17dcb07  vmovaps [rsp+0xA0], xmm11
00007e4af17dcb10  vmovaps [rsp+0xB0], xmm12
00007e4af17dcb19  vmovaps [rsp+0xC0], xmm13
00007e4af17dcb22  vmovaps [rsp+0xD0], xmm14
00007e4af17dcb2b  vmovaps [rsp+0xE0], xmm15
00007e4af17dcb34  sub rsp, 0x30
00007e4af17dcb38  movaps [rsp], xmm7
00007e4af17dcb3c  movaps [rsp+0x10], xmm9
00007e4af17dcb42  movaps [rsp+0x20], xmm15
00007e4af17dcb48  lea rdi, [rsp]
00007e4af17dcb4c  mov esi, 0x00
00007e4af17dcb51  mov rax, 0x6256754A7530
00007e4af17dcb5b  call rax
00007e4af17dcb5d  movaps xmm7, [rsp]
00007e4af17dcb61  add rsp, 0x30
00007e4af17dcb65  vmovaps xmm0, [rsp]
00007e4af17dcb6a  vmovaps xmm1, [rsp+0x10]
00007e4af17dcb70  vmovaps xmm2, [rsp+0x20]
00007e4af17dcb76  vmovaps xmm3, [rsp+0x30]
00007e4af17dcb7c  vmovaps xmm4, [rsp+0x40]
00007e4af17dcb82  vmovaps xmm5, [rsp+0x50]
00007e4af17dcb88  vmovaps xmm6, [rsp+0x60]
00007e4af17dcb8e  vmovaps xmm8, [rsp+0x70]
00007e4af17dcb94  vmovaps xmm9, [rsp+0x80]
00007e4af17dcb9d  vmovaps xmm10, [rsp+0x90]
00007e4af17dcba6  vmovaps xmm11, [rsp+0xA0]
00007e4af17dcbaf  vmovaps xmm12, [rsp+0xB0]
00007e4af17dcbb8  vmovaps xmm13, [rsp+0xC0]
00007e4af17dcbc1  vmovaps xmm14, [rsp+0xD0]
00007e4af17dcbca  vmovaps xmm15, [rsp+0xE0]
00007e4af17dcbd3  add rsp, 0xF0
00007e4af17dcbda  pop r11
00007e4af17dcbdc  pop r10
00007e4af17dcbde  pop r9
00007e4af17dcbe0  pop r8
00007e4af17dcbe2  pop rsi
00007e4af17dcbe3  pop rdi
00007e4af17dcbe4  pop rdx
00007e4af17dcbe5  pop rcx
00007e4af17dcbe6  pop rax
00007e4af17dcbe7  add rsp, 0x08
00007e4af17dcbeb  jmp 0x00007E4AF17DBB75
00007e4af17dcbf0  sub rsp, 0x08
00007e4af17dcbf4  push rax
00007e4af17dcbf5  push rcx
00007e4af17dcbf6  push rdx
00007e4af17dcbf7  push rdi
00007e4af17dcbf8  push rsi
00007e4af17dcbf9  push r8
00007e4af17dcbfb  push r9
00007e4af17dcbfd  push r10
00007e4af17dcbff  push r11
00007e4af17dcc01  sub rsp, 0xF0
00007e4af17dcc08  vmovaps [rsp], xmm0
00007e4af17dcc0d  vmovaps [rsp+0x10], xmm1
00007e4af17dcc13  vmovaps [rsp+0x20], xmm2
00007e4af17dcc19  vmovaps [rsp+0x30], xmm3
00007e4af17dcc1f  vmovaps [rsp+0x40], xmm4
00007e4af17dcc25  vmovaps [rsp+0x50], xmm5
00007e4af17dcc2b  vmovaps [rsp+0x60], xmm6
00007e4af17dcc31  vmovaps [rsp+0x70], xmm7
00007e4af17dcc37  vmovaps [rsp+0x80], xmm8
00007e4af17dcc40  vmovaps [rsp+0x90], xmm10
00007e4af17dcc49  vmovaps [rsp+0xA0], xmm11
00007e4af17dcc52  vmovaps [rsp+0xB0], xmm12
00007e4af17dcc5b  vmovaps [rsp+0xC0], xmm13
00007e4af17dcc64  vmovaps [rsp+0xD0], xmm14
00007e4af17dcc6d  vmovaps [rsp+0xE0], xmm15
00007e4af17dcc76  sub rsp, 0x30
00007e4af17dcc7a  movaps [rsp], xmm9
00007e4af17dcc7f  movaps [rsp+0x10], xmm12
00007e4af17dcc85  movaps [rsp+0x20], xmm10
00007e4af17dcc8b  lea rdi, [rsp]
00007e4af17dcc8f  mov esi, 0x00
00007e4af17dcc94  mov rax, 0x6256754A7530
00007e4af17dcc9e  call rax
00007e4af17dcca0  movaps xmm9, [rsp]
00007e4af17dcca5  add rsp, 0x30
00007e4af17dcca9  vmovaps xmm0, [rsp]
00007e4af17dccae  vmovaps xmm1, [rsp+0x10]
00007e4af17dccb4  vmovaps xmm2, [rsp+0x20]
00007e4af17dccba  vmovaps xmm3, [rsp+0x30]
00007e4af17dccc0  vmovaps xmm4, [rsp+0x40]
00007e4af17dccc6  vmovaps xmm5, [rsp+0x50]
00007e4af17dcccc  vmovaps xmm6, [rsp+0x60]
00007e4af17dccd2  vmovaps xmm7, [rsp+0x70]
00007e4af17dccd8  vmovaps xmm8, [rsp+0x80]
00007e4af17dcce1  vmovaps xmm10, [rsp+0x90]
00007e4af17dccea  vmovaps xmm11, [rsp+0xA0]
00007e4af17dccf3  vmovaps xmm12, [rsp+0xB0]
00007e4af17dccfc  vmovaps xmm13, [rsp+0xC0]
00007e4af17dcd05  vmovaps xmm14, [rsp+0xD0]
00007e4af17dcd0e  vmovaps xmm15, [rsp+0xE0]
00007e4af17dcd17  add rsp, 0xF0
00007e4af17dcd1e  pop r11
00007e4af17dcd20  pop r10
00007e4af17dcd22  pop r9
00007e4af17dcd24  pop r8
00007e4af17dcd26  pop rsi
00007e4af17dcd27  pop rdi
00007e4af17dcd28  pop rdx
00007e4af17dcd29  pop rcx
00007e4af17dcd2a  pop rax
00007e4af17dcd2b  add rsp, 0x08
00007e4af17dcd2f  jmp 0x00007E4AF17DBB99
00007e4af17dcd34  sub rsp, 0x08
00007e4af17dcd38  push rax
00007e4af17dcd39  push rcx
00007e4af17dcd3a  push rdx
00007e4af17dcd3b  push rdi
00007e4af17dcd3c  push rsi
00007e4af17dcd3d  push r8
00007e4af17dcd3f  push r9
00007e4af17dcd41  push r10
00007e4af17dcd43  push r11
00007e4af17dcd45  sub rsp, 0xF0
00007e4af17dcd4c  vmovaps [rsp], xmm0
00007e4af17dcd51  vmovaps [rsp+0x10], xmm1
00007e4af17dcd57  vmovaps [rsp+0x20], xmm2
00007e4af17dcd5d  vmovaps [rsp+0x30], xmm3
00007e4af17dcd63  vmovaps [rsp+0x40], xmm4
00007e4af17dcd69  vmovaps [rsp+0x50], xmm5
00007e4af17dcd6f  vmovaps [rsp+0x60], xmm6
00007e4af17dcd75  vmovaps [rsp+0x70], xmm7
00007e4af17dcd7b  vmovaps [rsp+0x80], xmm8
00007e4af17dcd84  vmovaps [rsp+0x90], xmm9
00007e4af17dcd8d  vmovaps [rsp+0xA0], xmm11
00007e4af17dcd96  vmovaps [rsp+0xB0], xmm12
00007e4af17dcd9f  vmovaps [rsp+0xC0], xmm13
00007e4af17dcda8  vmovaps [rsp+0xD0], xmm14
00007e4af17dcdb1  vmovaps [rsp+0xE0], xmm15
00007e4af17dcdba  sub rsp, 0x30
00007e4af17dcdbe  movaps [rsp], xmm10
00007e4af17dcdc3  movaps [rsp+0x10], xmm12
00007e4af17dcdc9  movaps [rsp+0x20], xmm11
00007e4af17dcdcf  lea rdi, [rsp]
00007e4af17dcdd3  mov esi, 0x00
00007e4af17dcdd8  mov rax, 0x6256754A7530
00007e4af17dcde2  call rax
00007e4af17dcde4  movaps xmm10, [rsp]
00007e4af17dcde9  add rsp, 0x30
00007e4af17dcded  vmovaps xmm0, [rsp]
00007e4af17dcdf2  vmovaps xmm1, [rsp+0x10]
00007e4af17dcdf8  vmovaps xmm2, [rsp+0x20]
00007e4af17dcdfe  vmovaps xmm3, [rsp+0x30]
00007e4af17dce04  vmovaps xmm4, [rsp+0x40]
00007e4af17dce0a  vmovaps xmm5, [rsp+0x50]
00007e4af17dce10  vmovaps xmm6, [rsp+0x60]
00007e4af17dce16  vmovaps xmm7, [rsp+0x70]
00007e4af17dce1c  vmovaps xmm8, [rsp+0x80]
00007e4af17dce25  vmovaps xmm9, [rsp+0x90]
00007e4af17dce2e  vmovaps xmm11, [rsp+0xA0]
00007e4af17dce37  vmovaps xmm12, [rsp+0xB0]
00007e4af17dce40  vmovaps xmm13, [rsp+0xC0]
00007e4af17dce49  vmovaps xmm14, [rsp+0xD0]
00007e4af17dce52  vmovaps xmm15, [rsp+0xE0]
00007e4af17dce5b  add rsp, 0xF0
00007e4af17dce62  pop r11
00007e4af17dce64  pop r10
00007e4af17dce66  pop r9
00007e4af17dce68  pop r8
00007e4af17dce6a  pop rsi
00007e4af17dce6b  pop rdi
00007e4af17dce6c  pop rdx
00007e4af17dce6d  pop rcx
00007e4af17dce6e  pop rax
00007e4af17dce6f  add rsp, 0x08
00007e4af17dce73  jmp 0x00007E4AF17DBBB3
00007e4af17dce78  sub rsp, 0x08
00007e4af17dce7c  push rax
00007e4af17dce7d  push rcx
00007e4af17dce7e  push rdx
00007e4af17dce7f  push rdi
00007e4af17dce80  push rsi
00007e4af17dce81  push r8
00007e4af17dce83  push r9
00007e4af17dce85  push r10
00007e4af17dce87  push r11
00007e4af17dce89  sub rsp, 0xF0
00007e4af17dce90  vmovaps [rsp], xmm0
00007e4af17dce95  vmovaps [rsp+0x10], xmm1
00007e4af17dce9b  vmovaps [rsp+0x20], xmm2
00007e4af17dcea1  vmovaps [rsp+0x30], xmm3
00007e4af17dcea7  vmovaps [rsp+0x40], xmm4
00007e4af17dcead  vmovaps [rsp+0x50], xmm5
00007e4af17dceb3  vmovaps [rsp+0x60], xmm7
00007e4af17dceb9  vmovaps [rsp+0x70], xmm8
00007e4af17dcebf  vmovaps [rsp+0x80], xmm9
00007e4af17dcec8  vmovaps [rsp+0x90], xmm10
00007e4af17dced1  vmovaps [rsp+0xA0], xmm11
00007e4af17dceda  vmovaps [rsp+0xB0], xmm12
00007e4af17dcee3  vmovaps [rsp+0xC0], xmm13
00007e4af17dceec  vmovaps [rsp+0xD0], xmm14
00007e4af17dcef5  vmovaps [rsp+0xE0], xmm15
00007e4af17dcefe  sub rsp, 0x30
00007e4af17dcf02  movaps [rsp], xmm6
00007e4af17dcf06  movaps [rsp+0x10], xmm12
00007e4af17dcf0c  movaps [rsp+0x20], xmm11
00007e4af17dcf12  lea rdi, [rsp]
00007e4af17dcf16  mov esi, 0x00
00007e4af17dcf1b  mov rax, 0x6256754A7530
00007e4af17dcf25  call rax
00007e4af17dcf27  movaps xmm6, [rsp]
00007e4af17dcf2b  add rsp, 0x30
00007e4af17dcf2f  vmovaps xmm0, [rsp]
00007e4af17dcf34  vmovaps xmm1, [rsp+0x10]
00007e4af17dcf3a  vmovaps xmm2, [rsp+0x20]
00007e4af17dcf40  vmovaps xmm3, [rsp+0x30]
00007e4af17dcf46  vmovaps xmm4, [rsp+0x40]
00007e4af17dcf4c  vmovaps xmm5, [rsp+0x50]
00007e4af17dcf52  vmovaps xmm7, [rsp+0x60]
00007e4af17dcf58  vmovaps xmm8, [rsp+0x70]
00007e4af17dcf5e  vmovaps xmm9, [rsp+0x80]
00007e4af17dcf67  vmovaps xmm10, [rsp+0x90]
00007e4af17dcf70  vmovaps xmm11, [rsp+0xA0]
00007e4af17dcf79  vmovaps xmm12, [rsp+0xB0]
00007e4af17dcf82  vmovaps xmm13, [rsp+0xC0]
00007e4af17dcf8b  vmovaps xmm14, [rsp+0xD0]
00007e4af17dcf94  vmovaps xmm15, [rsp+0xE0]
00007e4af17dcf9d  add rsp, 0xF0
00007e4af17dcfa4  pop r11
00007e4af17dcfa6  pop r10
00007e4af17dcfa8  pop r9
00007e4af17dcfaa  pop r8
00007e4af17dcfac  pop rsi
00007e4af17dcfad  pop rdi
00007e4af17dcfae  pop rdx
00007e4af17dcfaf  pop rcx
00007e4af17dcfb0  pop rax
00007e4af17dcfb1  add rsp, 0x08
00007e4af17dcfb5  jmp 0x00007E4AF17DBBD4
00007e4af17dcfba  sub rsp, 0x08
00007e4af17dcfbe  push rax
00007e4af17dcfbf  push rcx
00007e4af17dcfc0  push rdx
00007e4af17dcfc1  push rdi
00007e4af17dcfc2  push rsi
00007e4af17dcfc3  push r8
00007e4af17dcfc5  push r9
00007e4af17dcfc7  push r10
00007e4af17dcfc9  push r11
00007e4af17dcfcb  sub rsp, 0xF0
00007e4af17dcfd2  vmovaps [rsp], xmm0
00007e4af17dcfd7  vmovaps [rsp+0x10], xmm1
00007e4af17dcfdd  vmovaps [rsp+0x20], xmm2
00007e4af17dcfe3  vmovaps [rsp+0x30], xmm4
00007e4af17dcfe9  vmovaps [rsp+0x40], xmm5
00007e4af17dcfef  vmovaps [rsp+0x50], xmm6
00007e4af17dcff5  vmovaps [rsp+0x60], xmm7
00007e4af17dcffb  vmovaps [rsp+0x70], xmm8
00007e4af17dd001  vmovaps [rsp+0x80], xmm9
00007e4af17dd00a  vmovaps [rsp+0x90], xmm10
00007e4af17dd013  vmovaps [rsp+0xA0], xmm11
00007e4af17dd01c  vmovaps [rsp+0xB0], xmm12
00007e4af17dd025  vmovaps [rsp+0xC0], xmm13
00007e4af17dd02e  vmovaps [rsp+0xD0], xmm14
00007e4af17dd037  vmovaps [rsp+0xE0], xmm15
00007e4af17dd040  sub rsp, 0x30
00007e4af17dd044  movaps [rsp], xmm3
00007e4af17dd048  movaps [rsp+0x10], xmm5
00007e4af17dd04d  movaps [rsp+0x20], xmm4
00007e4af17dd052  lea rdi, [rsp]
00007e4af17dd056  mov esi, 0x00
00007e4af17dd05b  mov rax, 0x6256754A7530
00007e4af17dd065  call rax
00007e4af17dd067  movaps xmm3, [rsp]
00007e4af17dd06b  add rsp, 0x30
00007e4af17dd06f  vmovaps xmm0, [rsp]
00007e4af17dd074  vmovaps xmm1, [rsp+0x10]
00007e4af17dd07a  vmovaps xmm2, [rsp+0x20]
00007e4af17dd080  vmovaps xmm4, [rsp+0x30]
00007e4af17dd086  vmovaps xmm5, [rsp+0x40]
00007e4af17dd08c  vmovaps xmm6, [rsp+0x50]
00007e4af17dd092  vmovaps xmm7, [rsp+0x60]
00007e4af17dd098  vmovaps xmm8, [rsp+0x70]
00007e4af17dd09e  vmovaps xmm9, [rsp+0x80]
00007e4af17dd0a7  vmovaps xmm10, [rsp+0x90]
00007e4af17dd0b0  vmovaps xmm11, [rsp+0xA0]
00007e4af17dd0b9  vmovaps xmm12, [rsp+0xB0]
00007e4af17dd0c2  vmovaps xmm13, [rsp+0xC0]
00007e4af17dd0cb  vmovaps xmm14, [rsp+0xD0]
00007e4af17dd0d4  vmovaps xmm15, [rsp+0xE0]
00007e4af17dd0dd  add rsp, 0xF0
00007e4af17dd0e4  pop r11
00007e4af17dd0e6  pop r10
00007e4af17dd0e8  pop r9
00007e4af17dd0ea  pop r8
00007e4af17dd0ec  pop rsi
00007e4af17dd0ed  pop rdi
00007e4af17dd0ee  pop rdx
00007e4af17dd0ef  pop rcx
00007e4af17dd0f0  pop rax
00007e4af17dd0f1  add rsp, 0x08
00007e4af17dd0f5  jmp 0x00007E4AF17DBC35
00007e4af17dd0fa  sub rsp, 0x08
00007e4af17dd0fe  push rax
00007e4af17dd0ff  push rcx
00007e4af17dd100  push rdx
00007e4af17dd101  push rdi
00007e4af17dd102  push rsi
00007e4af17dd103  push r8
00007e4af17dd105  push r9
00007e4af17dd107  push r10
00007e4af17dd109  push r11
00007e4af17dd10b  sub rsp, 0xF0
00007e4af17dd112  vmovaps [rsp], xmm0
00007e4af17dd117  vmovaps [rsp+0x10], xmm1
00007e4af17dd11d  vmovaps [rsp+0x20], xmm2
00007e4af17dd123  vmovaps [rsp+0x30], xmm3
00007e4af17dd129  vmovaps [rsp+0x40], xmm4
00007e4af17dd12f  vmovaps [rsp+0x50], xmm6
00007e4af17dd135  vmovaps [rsp+0x60], xmm7
00007e4af17dd13b  vmovaps [rsp+0x70], xmm8
00007e4af17dd141  vmovaps [rsp+0x80], xmm9
00007e4af17dd14a  vmovaps [rsp+0x90], xmm10
00007e4af17dd153  vmovaps [rsp+0xA0], xmm11
00007e4af17dd15c  vmovaps [rsp+0xB0], xmm12
00007e4af17dd165  vmovaps [rsp+0xC0], xmm13
00007e4af17dd16e  vmovaps [rsp+0xD0], xmm14
00007e4af17dd177  vmovaps [rsp+0xE0], xmm15
00007e4af17dd180  sub rsp, 0x30
00007e4af17dd184  movaps [rsp], xmm5
00007e4af17dd188  movaps [rsp+0x10], xmm8
00007e4af17dd18e  movaps [rsp+0x20], xmm15
00007e4af17dd194  lea rdi, [rsp]
00007e4af17dd198  mov esi, 0x00
00007e4af17dd19d  mov rax, 0x6256754A7530
00007e4af17dd1a7  call rax
00007e4af17dd1a9  movaps xmm5, [rsp]
00007e4af17dd1ad  add rsp, 0x30
00007e4af17dd1b1  vmovaps xmm0, [rsp]
00007e4af17dd1b6  vmovaps xmm1, [rsp+0x10]
00007e4af17dd1bc  vmovaps xmm2, [rsp+0x20]
00007e4af17dd1c2  vmovaps xmm3, [rsp+0x30]
00007e4af17dd1c8  vmovaps xmm4, [rsp+0x40]
00007e4af17dd1ce  vmovaps xmm6, [rsp+0x50]
00007e4af17dd1d4  vmovaps xmm7, [rsp+0x60]
00007e4af17dd1da  vmovaps xmm8, [rsp+0x70]
00007e4af17dd1e0  vmovaps xmm9, [rsp+0x80]
00007e4af17dd1e9  vmovaps xmm10, [rsp+0x90]
00007e4af17dd1f2  vmovaps xmm11, [rsp+0xA0]
00007e4af17dd1fb  vmovaps xmm12, [rsp+0xB0]
00007e4af17dd204  vmovaps xmm13, [rsp+0xC0]
00007e4af17dd20d  vmovaps xmm14, [rsp+0xD0]
00007e4af17dd216  vmovaps xmm15, [rsp+0xE0]
00007e4af17dd21f  add rsp, 0xF0
00007e4af17dd226  pop r11
00007e4af17dd228  pop r10
00007e4af17dd22a  pop r9
00007e4af17dd22c  pop r8
00007e4af17dd22e  pop rsi
00007e4af17dd22f  pop rdi
00007e4af17dd230  pop rdx
00007e4af17dd231  pop rcx
00007e4af17dd232  pop rax
00007e4af17dd233  add rsp, 0x08
00007e4af17dd237  jmp 0x00007E4AF17DBC73
00007e4af17dd23c  sub rsp, 0x08
00007e4af17dd240  push rax
00007e4af17dd241  push rcx
00007e4af17dd242  push rdx
00007e4af17dd243  push rdi
00007e4af17dd244  push rsi
00007e4af17dd245  push r8
00007e4af17dd247  push r9
00007e4af17dd249  push r10
00007e4af17dd24b  push r11
00007e4af17dd24d  sub rsp, 0xF0
00007e4af17dd254  vmovaps [rsp], xmm0
00007e4af17dd259  vmovaps [rsp+0x10], xmm1
00007e4af17dd25f  vmovaps [rsp+0x20], xmm2
00007e4af17dd265  vmovaps [rsp+0x30], xmm3
00007e4af17dd26b  vmovaps [rsp+0x40], xmm5
00007e4af17dd271  vmovaps [rsp+0x50], xmm6
00007e4af17dd277  vmovaps [rsp+0x60], xmm7
00007e4af17dd27d  vmovaps [rsp+0x70], xmm8
00007e4af17dd283  vmovaps [rsp+0x80], xmm9
00007e4af17dd28c  vmovaps [rsp+0x90], xmm10
00007e4af17dd295  vmovaps [rsp+0xA0], xmm11
00007e4af17dd29e  vmovaps [rsp+0xB0], xmm12
00007e4af17dd2a7  vmovaps [rsp+0xC0], xmm13
00007e4af17dd2b0  vmovaps [rsp+0xD0], xmm14
00007e4af17dd2b9  vmovaps [rsp+0xE0], xmm15
00007e4af17dd2c2  sub rsp, 0x30
00007e4af17dd2c6  movaps [rsp], xmm4
00007e4af17dd2ca  movaps [rsp+0x10], xmm9
00007e4af17dd2d0  movaps [rsp+0x20], xmm8
00007e4af17dd2d6  lea rdi, [rsp]
00007e4af17dd2da  mov esi, 0x00
00007e4af17dd2df  mov rax, 0x6256754A7530
00007e4af17dd2e9  call rax
00007e4af17dd2eb  movaps xmm4, [rsp]
00007e4af17dd2ef  add rsp, 0x30
00007e4af17dd2f3  vmovaps xmm0, [rsp]
00007e4af17dd2f8  vmovaps xmm1, [rsp+0x10]
00007e4af17dd2fe  vmovaps xmm2, [rsp+0x20]
00007e4af17dd304  vmovaps xmm3, [rsp+0x30]
00007e4af17dd30a  vmovaps xmm5, [rsp+0x40]
00007e4af17dd310  vmovaps xmm6, [rsp+0x50]
00007e4af17dd316  vmovaps xmm7, [rsp+0x60]
00007e4af17dd31c  vmovaps xmm8, [rsp+0x70]
00007e4af17dd322  vmovaps xmm9, [rsp+0x80]
00007e4af17dd32b  vmovaps xmm10, [rsp+0x90]
00007e4af17dd334  vmovaps xmm11, [rsp+0xA0]
00007e4af17dd33d  vmovaps xmm12, [rsp+0xB0]
00007e4af17dd346  vmovaps xmm13, [rsp+0xC0]
00007e4af17dd34f  vmovaps xmm14, [rsp+0xD0]
00007e4af17dd358  vmovaps xmm15, [rsp+0xE0]
00007e4af17dd361  add rsp, 0xF0
00007e4af17dd368  pop r11
00007e4af17dd36a  pop r10
00007e4af17dd36c  pop r9
00007e4af17dd36e  pop r8
00007e4af17dd370  pop rsi
00007e4af17dd371  pop rdi
00007e4af17dd372  pop rdx
00007e4af17dd373  pop rcx
00007e4af17dd374  pop rax
00007e4af17dd375  add rsp, 0x08
00007e4af17dd379  jmp 0x00007E4AF17DBC94
00007e4af17dd37e  sub rsp, 0x08
00007e4af17dd382  push rax
00007e4af17dd383  push rcx
00007e4af17dd384  push rdx
00007e4af17dd385  push rdi
00007e4af17dd386  push rsi
00007e4af17dd387  push r8
00007e4af17dd389  push r9
00007e4af17dd38b  push r10
00007e4af17dd38d  push r11
00007e4af17dd38f  sub rsp, 0xF0
00007e4af17dd396  vmovaps [rsp], xmm0
00007e4af17dd39b  vmovaps [rsp+0x10], xmm1
00007e4af17dd3a1  vmovaps [rsp+0x20], xmm2
00007e4af17dd3a7  vmovaps [rsp+0x30], xmm3
00007e4af17dd3ad  vmovaps [rsp+0x40], xmm4
00007e4af17dd3b3  vmovaps [rsp+0x50], xmm5
00007e4af17dd3b9  vmovaps [rsp+0x60], xmm6
00007e4af17dd3bf  vmovaps [rsp+0x70], xmm7
00007e4af17dd3c5  vmovaps [rsp+0x80], xmm8
00007e4af17dd3ce  vmovaps [rsp+0x90], xmm10
00007e4af17dd3d7  vmovaps [rsp+0xA0], xmm11
00007e4af17dd3e0  vmovaps [rsp+0xB0], xmm12
00007e4af17dd3e9  vmovaps [rsp+0xC0], xmm13
00007e4af17dd3f2  vmovaps [rsp+0xD0], xmm14
00007e4af17dd3fb  vmovaps [rsp+0xE0], xmm15
00007e4af17dd404  sub rsp, 0x30
00007e4af17dd408  movaps [rsp], xmm9
00007e4af17dd40d  movaps [rsp+0x10], xmm10
00007e4af17dd413  movaps [rsp+0x20], xmm8
00007e4af17dd419  lea rdi, [rsp]
00007e4af17dd41d  mov esi, 0x00
00007e4af17dd422  mov rax, 0x6256754A7530
00007e4af17dd42c  call rax
00007e4af17dd42e  movaps xmm9, [rsp]
00007e4af17dd433  add rsp, 0x30
00007e4af17dd437  vmovaps xmm0, [rsp]
00007e4af17dd43c  vmovaps xmm1, [rsp+0x10]
00007e4af17dd442  vmovaps xmm2, [rsp+0x20]
00007e4af17dd448  vmovaps xmm3, [rsp+0x30]
00007e4af17dd44e  vmovaps xmm4, [rsp+0x40]
00007e4af17dd454  vmovaps xmm5, [rsp+0x50]
00007e4af17dd45a  vmovaps xmm6, [rsp+0x60]
00007e4af17dd460  vmovaps xmm7, [rsp+0x70]
00007e4af17dd466  vmovaps xmm8, [rsp+0x80]
00007e4af17dd46f  vmovaps xmm10, [rsp+0x90]
00007e4af17dd478  vmovaps xmm11, [rsp+0xA0]
00007e4af17dd481  vmovaps xmm12, [rsp+0xB0]
00007e4af17dd48a  vmovaps xmm13, [rsp+0xC0]
00007e4af17dd493  vmovaps xmm14, [rsp+0xD0]
00007e4af17dd49c  vmovaps xmm15, [rsp+0xE0]
00007e4af17dd4a5  add rsp, 0xF0
00007e4af17dd4ac  pop r11
00007e4af17dd4ae  pop r10
00007e4af17dd4b0  pop r9
00007e4af17dd4b2  pop r8
00007e4af17dd4b4  pop rsi
00007e4af17dd4b5  pop rdi
00007e4af17dd4b6  pop rdx
00007e4af17dd4b7  pop rcx
00007e4af17dd4b8  pop rax
00007e4af17dd4b9  add rsp, 0x08
00007e4af17dd4bd  jmp 0x00007E4AF17DBCAE
00007e4af17dd4c2  call 0x00007E4AF16B52F0
00007e4af17dd4c7  jmp 0x00007E4AF17DBDC8
00007e4af17dd4cc  call 0x00007E4AF16B52F0
00007e4af17dd4d1  jmp 0x00007E4AF17DBDDE
00007e4af17dd4d6  sub rsp, 0x08
00007e4af17dd4da  push rax
00007e4af17dd4db  push rcx
00007e4af17dd4dc  push rdx
00007e4af17dd4dd  push rdi
00007e4af17dd4de  push rsi
00007e4af17dd4df  push r8
00007e4af17dd4e1  push r9
00007e4af17dd4e3  push r10
00007e4af17dd4e5  push r11
00007e4af17dd4e7  sub rsp, 0xF0
00007e4af17dd4ee  vmovaps [rsp], xmm0
00007e4af17dd4f3  vmovaps [rsp+0x10], xmm2
00007e4af17dd4f9  vmovaps [rsp+0x20], xmm3
00007e4af17dd4ff  vmovaps [rsp+0x30], xmm4
00007e4af17dd505  vmovaps [rsp+0x40], xmm5
00007e4af17dd50b  vmovaps [rsp+0x50], xmm6
00007e4af17dd511  vmovaps [rsp+0x60], xmm7
00007e4af17dd517  vmovaps [rsp+0x70], xmm8
00007e4af17dd51d  vmovaps [rsp+0x80], xmm9
00007e4af17dd526  vmovaps [rsp+0x90], xmm10
00007e4af17dd52f  vmovaps [rsp+0xA0], xmm11
00007e4af17dd538  vmovaps [rsp+0xB0], xmm12
00007e4af17dd541  vmovaps [rsp+0xC0], xmm13
00007e4af17dd54a  vmovaps [rsp+0xD0], xmm14
00007e4af17dd553  vmovaps [rsp+0xE0], xmm15
00007e4af17dd55c  sub rsp, 0x30
00007e4af17dd560  movaps [rsp], xmm1
00007e4af17dd564  movaps [rsp+0x10], xmm6
00007e4af17dd569  movaps [rsp+0x20], xmm15
00007e4af17dd56f  lea rdi, [rsp]
00007e4af17dd573  mov esi, 0x00
00007e4af17dd578  mov rax, 0x6256754A7530
00007e4af17dd582  call rax
00007e4af17dd584  movaps xmm1, [rsp]
00007e4af17dd588  add rsp, 0x30
00007e4af17dd58c  vmovaps xmm0, [rsp]
00007e4af17dd591  vmovaps xmm2, [rsp+0x10]
00007e4af17dd597  vmovaps xmm3, [rsp+0x20]
00007e4af17dd59d  vmovaps xmm4, [rsp+0x30]
00007e4af17dd5a3  vmovaps xmm5, [rsp+0x40]
00007e4af17dd5a9  vmovaps xmm6, [rsp+0x50]
00007e4af17dd5af  vmovaps xmm7, [rsp+0x60]
00007e4af17dd5b5  vmovaps xmm8, [rsp+0x70]
00007e4af17dd5bb  vmovaps xmm9, [rsp+0x80]
00007e4af17dd5c4  vmovaps xmm10, [rsp+0x90]
00007e4af17dd5cd  vmovaps xmm11, [rsp+0xA0]
00007e4af17dd5d6  vmovaps xmm12, [rsp+0xB0]
00007e4af17dd5df  vmovaps xmm13, [rsp+0xC0]
00007e4af17dd5e8  vmovaps xmm14, [rsp+0xD0]
00007e4af17dd5f1  vmovaps xmm15, [rsp+0xE0]
00007e4af17dd5fa  add rsp, 0xF0
00007e4af17dd601  pop r11
00007e4af17dd603  pop r10
00007e4af17dd605  pop r9
00007e4af17dd607  pop r8
00007e4af17dd609  pop rsi
00007e4af17dd60a  pop rdi
00007e4af17dd60b  pop rdx
00007e4af17dd60c  pop rcx
00007e4af17dd60d  pop rax
00007e4af17dd60e  add rsp, 0x08
00007e4af17dd612  jmp 0x00007E4AF17DBE1B
00007e4af17dd617  call 0x00007E4AF16C4620
00007e4af17dd61c  jmp 0x00007E4AF17DBE28
00007e4af17dd621  sub rsp, 0x08
00007e4af17dd625  push rax
00007e4af17dd626  push rcx
00007e4af17dd627  push rdx
00007e4af17dd628  push rdi
00007e4af17dd629  push rsi
00007e4af17dd62a  push r8
00007e4af17dd62c  push r9
00007e4af17dd62e  push r10
00007e4af17dd630  push r11
00007e4af17dd632  sub rsp, 0xF0
00007e4af17dd639  vmovaps [rsp], xmm0
00007e4af17dd63e  vmovaps [rsp+0x10], xmm1
00007e4af17dd644  vmovaps [rsp+0x20], xmm2
00007e4af17dd64a  vmovaps [rsp+0x30], xmm3
00007e4af17dd650  vmovaps [rsp+0x40], xmm4
00007e4af17dd656  vmovaps [rsp+0x50], xmm5
00007e4af17dd65c  vmovaps [rsp+0x60], xmm6
00007e4af17dd662  vmovaps [rsp+0x70], xmm7
00007e4af17dd668  vmovaps [rsp+0x80], xmm8
00007e4af17dd671  vmovaps [rsp+0x90], xmm9
00007e4af17dd67a  vmovaps [rsp+0xA0], xmm10
00007e4af17dd683  vmovaps [rsp+0xB0], xmm11
00007e4af17dd68c  vmovaps [rsp+0xC0], xmm12
00007e4af17dd695  vmovaps [rsp+0xD0], xmm13
00007e4af17dd69e  vmovaps [rsp+0xE0], xmm15
00007e4af17dd6a7  sub rsp, 0x30
00007e4af17dd6ab  movaps [rsp], xmm14
00007e4af17dd6b0  movaps [rsp+0x10], xmm4
00007e4af17dd6b5  movaps [rsp+0x20], xmm3
00007e4af17dd6ba  lea rdi, [rsp]
00007e4af17dd6be  mov esi, 0x00
00007e4af17dd6c3  mov rax, 0x6256754A7530
00007e4af17dd6cd  call rax
00007e4af17dd6cf  movaps xmm14, [rsp]
00007e4af17dd6d4  add rsp, 0x30
00007e4af17dd6d8  vmovaps xmm0, [rsp]
00007e4af17dd6dd  vmovaps xmm1, [rsp+0x10]
00007e4af17dd6e3  vmovaps xmm2, [rsp+0x20]
00007e4af17dd6e9  vmovaps xmm3, [rsp+0x30]
00007e4af17dd6ef  vmovaps xmm4, [rsp+0x40]
00007e4af17dd6f5  vmovaps xmm5, [rsp+0x50]
00007e4af17dd6fb  vmovaps xmm6, [rsp+0x60]
00007e4af17dd701  vmovaps xmm7, [rsp+0x70]
00007e4af17dd707  vmovaps xmm8, [rsp+0x80]
00007e4af17dd710  vmovaps xmm9, [rsp+0x90]
00007e4af17dd719  vmovaps xmm10, [rsp+0xA0]
00007e4af17dd722  vmovaps xmm11, [rsp+0xB0]
00007e4af17dd72b  vmovaps xmm12, [rsp+0xC0]
00007e4af17dd734  vmovaps xmm13, [rsp+0xD0]
00007e4af17dd73d  vmovaps xmm15, [rsp+0xE0]
00007e4af17dd746  add rsp, 0xF0
00007e4af17dd74d  pop r11
00007e4af17dd74f  pop r10
00007e4af17dd751  pop r9
00007e4af17dd753  pop r8
00007e4af17dd755  pop rsi
00007e4af17dd756  pop rdi
00007e4af17dd757  pop rdx
00007e4af17dd758  pop rcx
00007e4af17dd759  pop rax
00007e4af17dd75a  add rsp, 0x08
00007e4af17dd75e  jmp 0x00007E4AF17DBE42
00007e4af17dd763  sub rsp, 0x08
00007e4af17dd767  push rax
00007e4af17dd768  push rcx
00007e4af17dd769  push rdx
00007e4af17dd76a  push rdi
00007e4af17dd76b  push rsi
00007e4af17dd76c  push r8
00007e4af17dd76e  push r9
00007e4af17dd770  push r10
00007e4af17dd772  push r11
00007e4af17dd774  sub rsp, 0xF0
00007e4af17dd77b  vmovaps [rsp], xmm0
00007e4af17dd780  vmovaps [rsp+0x10], xmm1
00007e4af17dd786  vmovaps [rsp+0x20], xmm2
00007e4af17dd78c  vmovaps [rsp+0x30], xmm3
00007e4af17dd792  vmovaps [rsp+0x40], xmm4
00007e4af17dd798  vmovaps [rsp+0x50], xmm5
00007e4af17dd79e  vmovaps [rsp+0x60], xmm7
00007e4af17dd7a4  vmovaps [rsp+0x70], xmm8
00007e4af17dd7aa  vmovaps [rsp+0x80], xmm9
00007e4af17dd7b3  vmovaps [rsp+0x90], xmm10
00007e4af17dd7bc  vmovaps [rsp+0xA0], xmm11
00007e4af17dd7c5  vmovaps [rsp+0xB0], xmm12
00007e4af17dd7ce  vmovaps [rsp+0xC0], xmm13
00007e4af17dd7d7  vmovaps [rsp+0xD0], xmm14
00007e4af17dd7e0  vmovaps [rsp+0xE0], xmm15
00007e4af17dd7e9  sub rsp, 0x30
00007e4af17dd7ed  movaps [rsp], xmm6
00007e4af17dd7f1  movaps [rsp+0x10], xmm9
00007e4af17dd7f7  movaps [rsp+0x20], xmm7
00007e4af17dd7fc  lea rdi, [rsp]
00007e4af17dd800  mov esi, 0x00
00007e4af17dd805  mov rax, 0x6256754A7530
00007e4af17dd80f  call rax
00007e4af17dd811  movaps xmm6, [rsp]
00007e4af17dd815  add rsp, 0x30
00007e4af17dd819  vmovaps xmm0, [rsp]
00007e4af17dd81e  vmovaps xmm1, [rsp+0x10]
00007e4af17dd824  vmovaps xmm2, [rsp+0x20]
00007e4af17dd82a  vmovaps xmm3, [rsp+0x30]
00007e4af17dd830  vmovaps xmm4, [rsp+0x40]
00007e4af17dd836  vmovaps xmm5, [rsp+0x50]
00007e4af17dd83c  vmovaps xmm7, [rsp+0x60]
00007e4af17dd842  vmovaps xmm8, [rsp+0x70]
00007e4af17dd848  vmovaps xmm9, [rsp+0x80]
00007e4af17dd851  vmovaps xmm10, [rsp+0x90]
00007e4af17dd85a  vmovaps xmm11, [rsp+0xA0]
00007e4af17dd863  vmovaps xmm12, [rsp+0xB0]
00007e4af17dd86c  vmovaps xmm13, [rsp+0xC0]
00007e4af17dd875  vmovaps xmm14, [rsp+0xD0]
00007e4af17dd87e  vmovaps xmm15, [rsp+0xE0]
00007e4af17dd887  add rsp, 0xF0
00007e4af17dd88e  pop r11
00007e4af17dd890  pop r10
00007e4af17dd892  pop r9
00007e4af17dd894  pop r8
00007e4af17dd896  pop rsi
00007e4af17dd897  pop rdi
00007e4af17dd898  pop rdx
00007e4af17dd899  pop rcx
00007e4af17dd89a  pop rax
00007e4af17dd89b  add rsp, 0x08
00007e4af17dd89f  jmp 0x00007E4AF17DBE5A
00007e4af17dd8a4  sub rsp, 0x08
00007e4af17dd8a8  push rax
00007e4af17dd8a9  push rcx
00007e4af17dd8aa  push rdx
00007e4af17dd8ab  push rdi
00007e4af17dd8ac  push rsi
00007e4af17dd8ad  push r8
00007e4af17dd8af  push r9
00007e4af17dd8b1  push r10
00007e4af17dd8b3  push r11
00007e4af17dd8b5  sub rsp, 0xF0
00007e4af17dd8bc  vmovaps [rsp], xmm0
00007e4af17dd8c1  vmovaps [rsp+0x10], xmm1
00007e4af17dd8c7  vmovaps [rsp+0x20], xmm2
00007e4af17dd8cd  vmovaps [rsp+0x30], xmm3
00007e4af17dd8d3  vmovaps [rsp+0x40], xmm4
00007e4af17dd8d9  vmovaps [rsp+0x50], xmm5
00007e4af17dd8df  vmovaps [rsp+0x60], xmm6
00007e4af17dd8e5  vmovaps [rsp+0x70], xmm8
00007e4af17dd8eb  vmovaps [rsp+0x80], xmm9
00007e4af17dd8f4  vmovaps [rsp+0x90], xmm10
00007e4af17dd8fd  vmovaps [rsp+0xA0], xmm11
00007e4af17dd906  vmovaps [rsp+0xB0], xmm12
00007e4af17dd90f  vmovaps [rsp+0xC0], xmm13
00007e4af17dd918  vmovaps [rsp+0xD0], xmm14
00007e4af17dd921  vmovaps [rsp+0xE0], xmm15
00007e4af17dd92a  sub rsp, 0x30
00007e4af17dd92e  movaps [rsp], xmm7
00007e4af17dd932  movaps [rsp+0x10], xmm4
00007e4af17dd937  movaps [rsp+0x20], xmm9
00007e4af17dd93d  lea rdi, [rsp]
00007e4af17dd941  mov esi, 0x00
00007e4af17dd946  mov rax, 0x6256754A7530
00007e4af17dd950  call rax
00007e4af17dd952  movaps xmm7, [rsp]
00007e4af17dd956  add rsp, 0x30
00007e4af17dd95a  vmovaps xmm0, [rsp]
00007e4af17dd95f  vmovaps xmm1, [rsp+0x10]
00007e4af17dd965  vmovaps xmm2, [rsp+0x20]
00007e4af17dd96b  vmovaps xmm3, [rsp+0x30]
00007e4af17dd971  vmovaps xmm4, [rsp+0x40]
00007e4af17dd977  vmovaps xmm5, [rsp+0x50]
00007e4af17dd97d  vmovaps xmm6, [rsp+0x60]
00007e4af17dd983  vmovaps xmm8, [rsp+0x70]
00007e4af17dd989  vmovaps xmm9, [rsp+0x80]
00007e4af17dd992  vmovaps xmm10, [rsp+0x90]
00007e4af17dd99b  vmovaps xmm11, [rsp+0xA0]
00007e4af17dd9a4  vmovaps xmm12, [rsp+0xB0]
00007e4af17dd9ad  vmovaps xmm13, [rsp+0xC0]
00007e4af17dd9b6  vmovaps xmm14, [rsp+0xD0]
00007e4af17dd9bf  vmovaps xmm15, [rsp+0xE0]
00007e4af17dd9c8  add rsp, 0xF0
00007e4af17dd9cf  pop r11
00007e4af17dd9d1  pop r10
00007e4af17dd9d3  pop r9
00007e4af17dd9d5  pop r8
00007e4af17dd9d7  pop rsi
00007e4af17dd9d8  pop rdi
00007e4af17dd9d9  pop rdx
00007e4af17dd9da  pop rcx
00007e4af17dd9db  pop rax
00007e4af17dd9dc  add rsp, 0x08
00007e4af17dd9e0  jmp 0x00007E4AF17DBE87
00007e4af17dd9e5  sub rsp, 0x08
00007e4af17dd9e9  push rax
00007e4af17dd9ea  push rcx
00007e4af17dd9eb  push rdx
00007e4af17dd9ec  push rdi
00007e4af17dd9ed  push rsi
00007e4af17dd9ee  push r8
00007e4af17dd9f0  push r9
00007e4af17dd9f2  push r10
00007e4af17dd9f4  push r11
00007e4af17dd9f6  sub rsp, 0xF0
00007e4af17dd9fd  vmovaps [rsp], xmm0
00007e4af17dda02  vmovaps [rsp+0x10], xmm1
00007e4af17dda08  vmovaps [rsp+0x20], xmm2
00007e4af17dda0e  vmovaps [rsp+0x30], xmm3
00007e4af17dda14  vmovaps [rsp+0x40], xmm5
00007e4af17dda1a  vmovaps [rsp+0x50], xmm6
00007e4af17dda20  vmovaps [rsp+0x60], xmm7
00007e4af17dda26  vmovaps [rsp+0x70], xmm8
00007e4af17dda2c  vmovaps [rsp+0x80], xmm9
00007e4af17dda35  vmovaps [rsp+0x90], xmm10
00007e4af17dda3e  vmovaps [rsp+0xA0], xmm11
00007e4af17dda47  vmovaps [rsp+0xB0], xmm12
00007e4af17dda50  vmovaps [rsp+0xC0], xmm13
00007e4af17dda59  vmovaps [rsp+0xD0], xmm14
00007e4af17dda62  vmovaps [rsp+0xE0], xmm15
00007e4af17dda6b  sub rsp, 0x30
00007e4af17dda6f  movaps [rsp], xmm4
00007e4af17dda73  movaps [rsp+0x10], xmm15
00007e4af17dda79  movaps [rsp+0x20], xmm9
00007e4af17dda7f  lea rdi, [rsp]
00007e4af17dda83  mov esi, 0x00
00007e4af17dda88  mov rax, 0x6256754A7530
00007e4af17dda92  call rax
00007e4af17dda94  movaps xmm4, [rsp]
00007e4af17dda98  add rsp, 0x30
00007e4af17dda9c  vmovaps xmm0, [rsp]
00007e4af17ddaa1  vmovaps xmm1, [rsp+0x10]
00007e4af17ddaa7  vmovaps xmm2, [rsp+0x20]
00007e4af17ddaad  vmovaps xmm3, [rsp+0x30]
00007e4af17ddab3  vmovaps xmm5, [rsp+0x40]
00007e4af17ddab9  vmovaps xmm6, [rsp+0x50]
00007e4af17ddabf  vmovaps xmm7, [rsp+0x60]
00007e4af17ddac5  vmovaps xmm8, [rsp+0x70]
00007e4af17ddacb  vmovaps xmm9, [rsp+0x80]
00007e4af17ddad4  vmovaps xmm10, [rsp+0x90]
00007e4af17ddadd  vmovaps xmm11, [rsp+0xA0]
00007e4af17ddae6  vmovaps xmm12, [rsp+0xB0]
00007e4af17ddaef  vmovaps xmm13, [rsp+0xC0]
00007e4af17ddaf8  vmovaps xmm14, [rsp+0xD0]
00007e4af17ddb01  vmovaps xmm15, [rsp+0xE0]
00007e4af17ddb0a  add rsp, 0xF0
00007e4af17ddb11  pop r11
00007e4af17ddb13  pop r10
00007e4af17ddb15  pop r9
00007e4af17ddb17  pop r8
00007e4af17ddb19  pop rsi
00007e4af17ddb1a  pop rdi
00007e4af17ddb1b  pop rdx
00007e4af17ddb1c  pop rcx
00007e4af17ddb1d  pop rax
00007e4af17ddb1e  add rsp, 0x08
00007e4af17ddb22  jmp 0x00007E4AF17DBEAC
00007e4af17ddb27  call 0x00007E4AF16C4620
00007e4af17ddb2c  jmp 0x00007E4AF17DBEB9
00007e4af17ddb31  sub rsp, 0x08
00007e4af17ddb35  push rax
00007e4af17ddb36  push rcx
00007e4af17ddb37  push rdx
00007e4af17ddb38  push rdi
00007e4af17ddb39  push rsi
00007e4af17ddb3a  push r8
00007e4af17ddb3c  push r9
00007e4af17ddb3e  push r10
00007e4af17ddb40  push r11
00007e4af17ddb42  sub rsp, 0xF0
00007e4af17ddb49  vmovaps [rsp], xmm0
00007e4af17ddb4e  vmovaps [rsp+0x10], xmm1
00007e4af17ddb54  vmovaps [rsp+0x20], xmm2
00007e4af17ddb5a  vmovaps [rsp+0x30], xmm4
00007e4af17ddb60  vmovaps [rsp+0x40], xmm5
00007e4af17ddb66  vmovaps [rsp+0x50], xmm6
00007e4af17ddb6c  vmovaps [rsp+0x60], xmm7
00007e4af17ddb72  vmovaps [rsp+0x70], xmm8
00007e4af17ddb78  vmovaps [rsp+0x80], xmm9
00007e4af17ddb81  vmovaps [rsp+0x90], xmm10
00007e4af17ddb8a  vmovaps [rsp+0xA0], xmm11
00007e4af17ddb93  vmovaps [rsp+0xB0], xmm12
00007e4af17ddb9c  vmovaps [rsp+0xC0], xmm13
00007e4af17ddba5  vmovaps [rsp+0xD0], xmm14
00007e4af17ddbae  vmovaps [rsp+0xE0], xmm15
00007e4af17ddbb7  sub rsp, 0x30
00007e4af17ddbbb  movaps [rsp], xmm3
00007e4af17ddbbf  movaps [rsp+0x10], xmm1
00007e4af17ddbc4  movaps [rsp+0x20], xmm9
00007e4af17ddbca  lea rdi, [rsp]
00007e4af17ddbce  mov esi, 0x00
00007e4af17ddbd3  mov rax, 0x6256754A7530
00007e4af17ddbdd  call rax
00007e4af17ddbdf  movaps xmm3, [rsp]
00007e4af17ddbe3  add rsp, 0x30
00007e4af17ddbe7  vmovaps xmm0, [rsp]
00007e4af17ddbec  vmovaps xmm1, [rsp+0x10]
00007e4af17ddbf2  vmovaps xmm2, [rsp+0x20]
00007e4af17ddbf8  vmovaps xmm4, [rsp+0x30]
00007e4af17ddbfe  vmovaps xmm5, [rsp+0x40]
00007e4af17ddc04  vmovaps xmm6, [rsp+0x50]
00007e4af17ddc0a  vmovaps xmm7, [rsp+0x60]
00007e4af17ddc10  vmovaps xmm8, [rsp+0x70]
00007e4af17ddc16  vmovaps xmm9, [rsp+0x80]
00007e4af17ddc1f  vmovaps xmm10, [rsp+0x90]
00007e4af17ddc28  vmovaps xmm11, [rsp+0xA0]
00007e4af17ddc31  vmovaps xmm12, [rsp+0xB0]
00007e4af17ddc3a  vmovaps xmm13, [rsp+0xC0]
00007e4af17ddc43  vmovaps xmm14, [rsp+0xD0]
00007e4af17ddc4c  vmovaps xmm15, [rsp+0xE0]
00007e4af17ddc55  add rsp, 0xF0
00007e4af17ddc5c  pop r11
00007e4af17ddc5e  pop r10
00007e4af17ddc60  pop r9
00007e4af17ddc62  pop r8
00007e4af17ddc64  pop rsi
00007e4af17ddc65  pop rdi
00007e4af17ddc66  pop rdx
00007e4af17ddc67  pop rcx
00007e4af17ddc68  pop rax
00007e4af17ddc69  add rsp, 0x08
00007e4af17ddc6d  jmp 0x00007E4AF17DBEF6
00007e4af17ddc72  sub rsp, 0x08
00007e4af17ddc76  push rax
00007e4af17ddc77  push rcx
00007e4af17ddc78  push rdx
00007e4af17ddc79  push rdi
00007e4af17ddc7a  push rsi
00007e4af17ddc7b  push r8
00007e4af17ddc7d  push r9
00007e4af17ddc7f  push r10
00007e4af17ddc81  push r11
00007e4af17ddc83  sub rsp, 0xF0
00007e4af17ddc8a  vmovaps [rsp], xmm0
00007e4af17ddc8f  vmovaps [rsp+0x10], xmm2
00007e4af17ddc95  vmovaps [rsp+0x20], xmm3
00007e4af17ddc9b  vmovaps [rsp+0x30], xmm4
00007e4af17ddca1  vmovaps [rsp+0x40], xmm5
00007e4af17ddca7  vmovaps [rsp+0x50], xmm6
00007e4af17ddcad  vmovaps [rsp+0x60], xmm7
00007e4af17ddcb3  vmovaps [rsp+0x70], xmm8
00007e4af17ddcb9  vmovaps [rsp+0x80], xmm9
00007e4af17ddcc2  vmovaps [rsp+0x90], xmm10
00007e4af17ddccb  vmovaps [rsp+0xA0], xmm11
00007e4af17ddcd4  vmovaps [rsp+0xB0], xmm12
00007e4af17ddcdd  vmovaps [rsp+0xC0], xmm13
00007e4af17ddce6  vmovaps [rsp+0xD0], xmm14
00007e4af17ddcef  vmovaps [rsp+0xE0], xmm15
00007e4af17ddcf8  sub rsp, 0x30
00007e4af17ddcfc  movaps [rsp], xmm1
00007e4af17ddd00  movaps [rsp+0x10], xmm15
00007e4af17ddd06  movaps [rsp+0x20], xmm9
00007e4af17ddd0c  lea rdi, [rsp]
00007e4af17ddd10  mov esi, 0x00
00007e4af17ddd15  mov rax, 0x6256754A7530
00007e4af17ddd1f  call rax
00007e4af17ddd21  movaps xmm1, [rsp]
00007e4af17ddd25  add rsp, 0x30
00007e4af17ddd29  vmovaps xmm0, [rsp]
00007e4af17ddd2e  vmovaps xmm2, [rsp+0x10]
00007e4af17ddd34  vmovaps xmm3, [rsp+0x20]
00007e4af17ddd3a  vmovaps xmm4, [rsp+0x30]
00007e4af17ddd40  vmovaps xmm5, [rsp+0x40]
00007e4af17ddd46  vmovaps xmm6, [rsp+0x50]
00007e4af17ddd4c  vmovaps xmm7, [rsp+0x60]
00007e4af17ddd52  vmovaps xmm8, [rsp+0x70]
00007e4af17ddd58  vmovaps xmm9, [rsp+0x80]
00007e4af17ddd61  vmovaps xmm10, [rsp+0x90]
00007e4af17ddd6a  vmovaps xmm11, [rsp+0xA0]
00007e4af17ddd73  vmovaps xmm12, [rsp+0xB0]
00007e4af17ddd7c  vmovaps xmm13, [rsp+0xC0]
00007e4af17ddd85  vmovaps xmm14, [rsp+0xD0]
00007e4af17ddd8e  vmovaps xmm15, [rsp+0xE0]
00007e4af17ddd97  add rsp, 0xF0
00007e4af17ddd9e  pop r11
00007e4af17ddda0  pop r10
00007e4af17ddda2  pop r9
00007e4af17ddda4  pop r8
00007e4af17ddda6  pop rsi
00007e4af17ddda7  pop rdi
00007e4af17ddda8  pop rdx
00007e4af17ddda9  pop rcx
00007e4af17dddaa  pop rax
00007e4af17dddab  add rsp, 0x08
00007e4af17dddaf  jmp 0x00007E4AF17DBF7E
00007e4af17dddb4  call 0x00007E4AF16C4620
00007e4af17dddb9  jmp 0x00007E4AF17DBF8B
00007e4af17dddbe  sub rsp, 0x08
00007e4af17dddc2  push rax
00007e4af17dddc3  push rcx
00007e4af17dddc4  push rdx
00007e4af17dddc5  push rdi
00007e4af17dddc6  push rsi
00007e4af17dddc7  push r8
00007e4af17dddc9  push r9
00007e4af17dddcb  push r10
00007e4af17dddcd  push r11
00007e4af17dddcf  sub rsp, 0xF0
00007e4af17dddd6  vmovaps [rsp], xmm0
00007e4af17ddddb  vmovaps [rsp+0x10], xmm2
00007e4af17ddde1  vmovaps [rsp+0x20], xmm3
00007e4af17ddde7  vmovaps [rsp+0x30], xmm4
00007e4af17ddded  vmovaps [rsp+0x40], xmm5
00007e4af17dddf3  vmovaps [rsp+0x50], xmm6
00007e4af17dddf9  vmovaps [rsp+0x60], xmm7
00007e4af17dddff  vmovaps [rsp+0x70], xmm8
00007e4af17dde05  vmovaps [rsp+0x80], xmm9
00007e4af17dde0e  vmovaps [rsp+0x90], xmm10
00007e4af17dde17  vmovaps [rsp+0xA0], xmm11
00007e4af17dde20  vmovaps [rsp+0xB0], xmm12
00007e4af17dde29  vmovaps [rsp+0xC0], xmm13
00007e4af17dde32  vmovaps [rsp+0xD0], xmm14
00007e4af17dde3b  vmovaps [rsp+0xE0], xmm15
00007e4af17dde44  sub rsp, 0x30
00007e4af17dde48  movaps [rsp], xmm1
00007e4af17dde4c  movaps [rsp+0x10], xmm5
00007e4af17dde51  movaps [rsp+0x20], xmm7
00007e4af17dde56  lea rdi, [rsp]
00007e4af17dde5a  mov esi, 0x00
00007e4af17dde5f  mov rax, 0x6256754A7530
00007e4af17dde69  call rax
00007e4af17dde6b  movaps xmm1, [rsp]
00007e4af17dde6f  add rsp, 0x30
00007e4af17dde73  vmovaps xmm0, [rsp]
00007e4af17dde78  vmovaps xmm2, [rsp+0x10]
00007e4af17dde7e  vmovaps xmm3, [rsp+0x20]
00007e4af17dde84  vmovaps xmm4, [rsp+0x30]
00007e4af17dde8a  vmovaps xmm5, [rsp+0x40]
00007e4af17dde90  vmovaps xmm6, [rsp+0x50]
00007e4af17dde96  vmovaps xmm7, [rsp+0x60]
00007e4af17dde9c  vmovaps xmm8, [rsp+0x70]
00007e4af17ddea2  vmovaps xmm9, [rsp+0x80]
00007e4af17ddeab  vmovaps xmm10, [rsp+0x90]
00007e4af17ddeb4  vmovaps xmm11, [rsp+0xA0]
00007e4af17ddebd  vmovaps xmm12, [rsp+0xB0]
00007e4af17ddec6  vmovaps xmm13, [rsp+0xC0]
00007e4af17ddecf  vmovaps xmm14, [rsp+0xD0]
00007e4af17dded8  vmovaps xmm15, [rsp+0xE0]
00007e4af17ddee1  add rsp, 0xF0
00007e4af17ddee8  pop r11
00007e4af17ddeea  pop r10
00007e4af17ddeec  pop r9
00007e4af17ddeee  pop r8
00007e4af17ddef0  pop rsi
00007e4af17ddef1  pop rdi
00007e4af17ddef2  pop rdx
00007e4af17ddef3  pop rcx
00007e4af17ddef4  pop rax
00007e4af17ddef5  add rsp, 0x08
00007e4af17ddef9  jmp 0x00007E4AF17DC030
00007e4af17ddefe  sub rsp, 0x08
00007e4af17ddf02  push rax
00007e4af17ddf03  push rcx
00007e4af17ddf04  push rdx
00007e4af17ddf05  push rdi
00007e4af17ddf06  push rsi
00007e4af17ddf07  push r8
00007e4af17ddf09  push r9
00007e4af17ddf0b  push r10
00007e4af17ddf0d  push r11
00007e4af17ddf0f  sub rsp, 0xF0
00007e4af17ddf16  vmovaps [rsp], xmm0
00007e4af17ddf1b  vmovaps [rsp+0x10], xmm1
00007e4af17ddf21  vmovaps [rsp+0x20], xmm2
00007e4af17ddf27  vmovaps [rsp+0x30], xmm3
00007e4af17ddf2d  vmovaps [rsp+0x40], xmm4
00007e4af17ddf33  vmovaps [rsp+0x50], xmm5
00007e4af17ddf39  vmovaps [rsp+0x60], xmm6
00007e4af17ddf3f  vmovaps [rsp+0x70], xmm8
00007e4af17ddf45  vmovaps [rsp+0x80], xmm9
00007e4af17ddf4e  vmovaps [rsp+0x90], xmm10
00007e4af17ddf57  vmovaps [rsp+0xA0], xmm11
00007e4af17ddf60  vmovaps [rsp+0xB0], xmm12
00007e4af17ddf69  vmovaps [rsp+0xC0], xmm13
00007e4af17ddf72  vmovaps [rsp+0xD0], xmm14
00007e4af17ddf7b  vmovaps [rsp+0xE0], xmm15
00007e4af17ddf84  sub rsp, 0x30
00007e4af17ddf88  movaps [rsp], xmm7
00007e4af17ddf8c  movaps [rsp+0x10], xmm5
00007e4af17ddf91  movaps [rsp+0x20], xmm15
00007e4af17ddf97  lea rdi, [rsp]
00007e4af17ddf9b  mov esi, 0x00
00007e4af17ddfa0  mov rax, 0x6256754A7530
00007e4af17ddfaa  call rax
00007e4af17ddfac  movaps xmm7, [rsp]
00007e4af17ddfb0  add rsp, 0x30
00007e4af17ddfb4  vmovaps xmm0, [rsp]
00007e4af17ddfb9  vmovaps xmm1, [rsp+0x10]
00007e4af17ddfbf  vmovaps xmm2, [rsp+0x20]
00007e4af17ddfc5  vmovaps xmm3, [rsp+0x30]
00007e4af17ddfcb  vmovaps xmm4, [rsp+0x40]
00007e4af17ddfd1  vmovaps xmm5, [rsp+0x50]
00007e4af17ddfd7  vmovaps xmm6, [rsp+0x60]
00007e4af17ddfdd  vmovaps xmm8, [rsp+0x70]
00007e4af17ddfe3  vmovaps xmm9, [rsp+0x80]
00007e4af17ddfec  vmovaps xmm10, [rsp+0x90]
00007e4af17ddff5  vmovaps xmm11, [rsp+0xA0]
00007e4af17ddffe  vmovaps xmm12, [rsp+0xB0]
00007e4af17de007  vmovaps xmm13, [rsp+0xC0]
00007e4af17de010  vmovaps xmm14, [rsp+0xD0]
00007e4af17de019  vmovaps xmm15, [rsp+0xE0]
00007e4af17de022  add rsp, 0xF0
00007e4af17de029  pop r11
00007e4af17de02b  pop r10
00007e4af17de02d  pop r9
00007e4af17de02f  pop r8
00007e4af17de031  pop rsi
00007e4af17de032  pop rdi
00007e4af17de033  pop rdx
00007e4af17de034  pop rcx
00007e4af17de035  pop rax
00007e4af17de036  add rsp, 0x08
00007e4af17de03a  jmp 0x00007E4AF17DC066
00007e4af17de03f  call 0x00007E4AF16B52F0
00007e4af17de044  jmp 0x00007E4AF17DC073
00007e4af17de049  sub rsp, 0x08
00007e4af17de04d  push rax
00007e4af17de04e  push rcx
00007e4af17de04f  push rdx
00007e4af17de050  push rdi
00007e4af17de051  push rsi
00007e4af17de052  push r8
00007e4af17de054  push r9
00007e4af17de056  push r10
00007e4af17de058  push r11
00007e4af17de05a  sub rsp, 0xF0
00007e4af17de061  vmovaps [rsp], xmm0
00007e4af17de066  vmovaps [rsp+0x10], xmm1
00007e4af17de06c  vmovaps [rsp+0x20], xmm2
00007e4af17de072  vmovaps [rsp+0x30], xmm3
00007e4af17de078  vmovaps [rsp+0x40], xmm4
00007e4af17de07e  vmovaps [rsp+0x50], xmm5
00007e4af17de084  vmovaps [rsp+0x60], xmm6
00007e4af17de08a  vmovaps [rsp+0x70], xmm7
00007e4af17de090  vmovaps [rsp+0x80], xmm8
00007e4af17de099  vmovaps [rsp+0x90], xmm9
00007e4af17de0a2  vmovaps [rsp+0xA0], xmm10
00007e4af17de0ab  vmovaps [rsp+0xB0], xmm11
00007e4af17de0b4  vmovaps [rsp+0xC0], xmm12
00007e4af17de0bd  vmovaps [rsp+0xD0], xmm13
00007e4af17de0c6  vmovaps [rsp+0xE0], xmm14
00007e4af17de0cf  sub rsp, 0x30
00007e4af17de0d3  movaps [rsp], xmm15
00007e4af17de0d8  movaps [rsp+0x10], xmm5
00007e4af17de0dd  movaps [rsp+0x20], xmm3
00007e4af17de0e2  lea rdi, [rsp]
00007e4af17de0e6  mov esi, 0x00
00007e4af17de0eb  mov rax, 0x6256754A7530
00007e4af17de0f5  call rax
00007e4af17de0f7  movaps xmm15, [rsp]
00007e4af17de0fc  add rsp, 0x30
00007e4af17de100  vmovaps xmm0, [rsp]
00007e4af17de105  vmovaps xmm1, [rsp+0x10]
00007e4af17de10b  vmovaps xmm2, [rsp+0x20]
00007e4af17de111  vmovaps xmm3, [rsp+0x30]
00007e4af17de117  vmovaps xmm4, [rsp+0x40]
00007e4af17de11d  vmovaps xmm5, [rsp+0x50]
00007e4af17de123  vmovaps xmm6, [rsp+0x60]
00007e4af17de129  vmovaps xmm7, [rsp+0x70]
00007e4af17de12f  vmovaps xmm8, [rsp+0x80]
00007e4af17de138  vmovaps xmm9, [rsp+0x90]
00007e4af17de141  vmovaps xmm10, [rsp+0xA0]
00007e4af17de14a  vmovaps xmm11, [rsp+0xB0]
00007e4af17de153  vmovaps xmm12, [rsp+0xC0]
00007e4af17de15c  vmovaps xmm13, [rsp+0xD0]
00007e4af17de165  vmovaps xmm14, [rsp+0xE0]
00007e4af17de16e  add rsp, 0xF0
00007e4af17de175  pop r11
00007e4af17de177  pop r10
00007e4af17de179  pop r9
00007e4af17de17b  pop r8
00007e4af17de17d  pop rsi
00007e4af17de17e  pop rdi
00007e4af17de17f  pop rdx
00007e4af17de180  pop rcx
00007e4af17de181  pop rax
00007e4af17de182  add rsp, 0x08
00007e4af17de186  jmp 0x00007E4AF17DC099
00007e4af17de18b  sub rsp, 0x08
00007e4af17de18f  push rax
00007e4af17de190  push rcx
00007e4af17de191  push rdx
00007e4af17de192  push rdi
00007e4af17de193  push rsi
00007e4af17de194  push r8
00007e4af17de196  push r9
00007e4af17de198  push r10
00007e4af17de19a  push r11
00007e4af17de19c  sub rsp, 0xF0
00007e4af17de1a3  vmovaps [rsp], xmm0
00007e4af17de1a8  vmovaps [rsp+0x10], xmm2
00007e4af17de1ae  vmovaps [rsp+0x20], xmm3
00007e4af17de1b4  vmovaps [rsp+0x30], xmm4
00007e4af17de1ba  vmovaps [rsp+0x40], xmm5
00007e4af17de1c0  vmovaps [rsp+0x50], xmm6
00007e4af17de1c6  vmovaps [rsp+0x60], xmm7
00007e4af17de1cc  vmovaps [rsp+0x70], xmm8
00007e4af17de1d2  vmovaps [rsp+0x80], xmm9
00007e4af17de1db  vmovaps [rsp+0x90], xmm10
00007e4af17de1e4  vmovaps [rsp+0xA0], xmm11
00007e4af17de1ed  vmovaps [rsp+0xB0], xmm12
00007e4af17de1f6  vmovaps [rsp+0xC0], xmm13
00007e4af17de1ff  vmovaps [rsp+0xD0], xmm14
00007e4af17de208  vmovaps [rsp+0xE0], xmm15
00007e4af17de211  sub rsp, 0x30
00007e4af17de215  movaps [rsp], xmm1
00007e4af17de219  movaps [rsp+0x10], xmm5
00007e4af17de21e  movaps [rsp+0x20], xmm4
00007e4af17de223  lea rdi, [rsp]
00007e4af17de227  mov esi, 0x00
00007e4af17de22c  mov rax, 0x6256754A7530
00007e4af17de236  call rax
00007e4af17de238  movaps xmm1, [rsp]
00007e4af17de23c  add rsp, 0x30
00007e4af17de240  vmovaps xmm0, [rsp]
00007e4af17de245  vmovaps xmm2, [rsp+0x10]
00007e4af17de24b  vmovaps xmm3, [rsp+0x20]
00007e4af17de251  vmovaps xmm4, [rsp+0x30]
00007e4af17de257  vmovaps xmm5, [rsp+0x40]
00007e4af17de25d  vmovaps xmm6, [rsp+0x50]
00007e4af17de263  vmovaps xmm7, [rsp+0x60]
00007e4af17de269  vmovaps xmm8, [rsp+0x70]
00007e4af17de26f  vmovaps xmm9, [rsp+0x80]
00007e4af17de278  vmovaps xmm10, [rsp+0x90]
00007e4af17de281  vmovaps xmm11, [rsp+0xA0]
00007e4af17de28a  vmovaps xmm12, [rsp+0xB0]
00007e4af17de293  vmovaps xmm13, [rsp+0xC0]
00007e4af17de29c  vmovaps xmm14, [rsp+0xD0]
00007e4af17de2a5  vmovaps xmm15, [rsp+0xE0]
00007e4af17de2ae  add rsp, 0xF0
00007e4af17de2b5  pop r11
00007e4af17de2b7  pop r10
00007e4af17de2b9  pop r9
00007e4af17de2bb  pop r8
00007e4af17de2bd  pop rsi
00007e4af17de2be  pop rdi
00007e4af17de2bf  pop rdx
00007e4af17de2c0  pop rcx
00007e4af17de2c1  pop rax
00007e4af17de2c2  add rsp, 0x08
00007e4af17de2c6  jmp 0x00007E4AF17DC0B9
00007e4af17de2cb  sub rsp, 0x08
00007e4af17de2cf  push rax
00007e4af17de2d0  push rcx
00007e4af17de2d1  push rdx
00007e4af17de2d2  push rdi
00007e4af17de2d3  push rsi
00007e4af17de2d4  push r8
00007e4af17de2d6  push r9
00007e4af17de2d8  push r10
00007e4af17de2da  push r11
00007e4af17de2dc  sub rsp, 0xF0
00007e4af17de2e3  vmovaps [rsp], xmm0
00007e4af17de2e8  vmovaps [rsp+0x10], xmm1
00007e4af17de2ee  vmovaps [rsp+0x20], xmm2
00007e4af17de2f4  vmovaps [rsp+0x30], xmm3
00007e4af17de2fa  vmovaps [rsp+0x40], xmm5
00007e4af17de300  vmovaps [rsp+0x50], xmm6
00007e4af17de306  vmovaps [rsp+0x60], xmm7
00007e4af17de30c  vmovaps [rsp+0x70], xmm8
00007e4af17de312  vmovaps [rsp+0x80], xmm9
00007e4af17de31b  vmovaps [rsp+0x90], xmm10
00007e4af17de324  vmovaps [rsp+0xA0], xmm11
00007e4af17de32d  vmovaps [rsp+0xB0], xmm12
00007e4af17de336  vmovaps [rsp+0xC0], xmm13
00007e4af17de33f  vmovaps [rsp+0xD0], xmm14
00007e4af17de348  vmovaps [rsp+0xE0], xmm15
00007e4af17de351  sub rsp, 0x30
00007e4af17de355  movaps [rsp], xmm4
00007e4af17de359  movaps [rsp+0x10], xmm3
00007e4af17de35e  movaps [rsp+0x20], xmm5
00007e4af17de363  lea rdi, [rsp]
00007e4af17de367  mov esi, 0x00
00007e4af17de36c  mov rax, 0x6256754A7530
00007e4af17de376  call rax
00007e4af17de378  movaps xmm4, [rsp]
00007e4af17de37c  add rsp, 0x30
00007e4af17de380  vmovaps xmm0, [rsp]
00007e4af17de385  vmovaps xmm1, [rsp+0x10]
00007e4af17de38b  vmovaps xmm2, [rsp+0x20]
00007e4af17de391  vmovaps xmm3, [rsp+0x30]
00007e4af17de397  vmovaps xmm5, [rsp+0x40]
00007e4af17de39d  vmovaps xmm6, [rsp+0x50]
00007e4af17de3a3  vmovaps xmm7, [rsp+0x60]
00007e4af17de3a9  vmovaps xmm8, [rsp+0x70]
00007e4af17de3af  vmovaps xmm9, [rsp+0x80]
00007e4af17de3b8  vmovaps xmm10, [rsp+0x90]
00007e4af17de3c1  vmovaps xmm11, [rsp+0xA0]
00007e4af17de3ca  vmovaps xmm12, [rsp+0xB0]
00007e4af17de3d3  vmovaps xmm13, [rsp+0xC0]
00007e4af17de3dc  vmovaps xmm14, [rsp+0xD0]
00007e4af17de3e5  vmovaps xmm15, [rsp+0xE0]
00007e4af17de3ee  add rsp, 0xF0
00007e4af17de3f5  pop r11
00007e4af17de3f7  pop r10
00007e4af17de3f9  pop r9
00007e4af17de3fb  pop r8
00007e4af17de3fd  pop rsi
00007e4af17de3fe  pop rdi
00007e4af17de3ff  pop rdx
00007e4af17de400  pop rcx
00007e4af17de401  pop rax
00007e4af17de402  add rsp, 0x08
00007e4af17de406  jmp 0x00007E4AF17DC107
00007e4af17de40b  call 0x00007E4AF16B52F0
00007e4af17de410  jmp 0x00007E4AF17DC114
00007e4af17de415  sub rsp, 0x08
00007e4af17de419  push rax
00007e4af17de41a  push rcx
00007e4af17de41b  push rdx
00007e4af17de41c  push rdi
00007e4af17de41d  push rsi
00007e4af17de41e  push r8
00007e4af17de420  push r9
00007e4af17de422  push r10
00007e4af17de424  push r11
00007e4af17de426  sub rsp, 0xF0
00007e4af17de42d  vmovaps [rsp], xmm0
00007e4af17de432  vmovaps [rsp+0x10], xmm1
00007e4af17de438  vmovaps [rsp+0x20], xmm2
00007e4af17de43e  vmovaps [rsp+0x30], xmm3
00007e4af17de444  vmovaps [rsp+0x40], xmm4
00007e4af17de44a  vmovaps [rsp+0x50], xmm6
00007e4af17de450  vmovaps [rsp+0x60], xmm7
00007e4af17de456  vmovaps [rsp+0x70], xmm8
00007e4af17de45c  vmovaps [rsp+0x80], xmm9
00007e4af17de465  vmovaps [rsp+0x90], xmm10
00007e4af17de46e  vmovaps [rsp+0xA0], xmm11
00007e4af17de477  vmovaps [rsp+0xB0], xmm12
00007e4af17de480  vmovaps [rsp+0xC0], xmm13
00007e4af17de489  vmovaps [rsp+0xD0], xmm14
00007e4af17de492  vmovaps [rsp+0xE0], xmm15
00007e4af17de49b  sub rsp, 0x30
00007e4af17de49f  movaps [rsp], xmm5
00007e4af17de4a3  movaps [rsp+0x10], xmm6
00007e4af17de4a8  movaps [rsp+0x20], xmm3
00007e4af17de4ad  lea rdi, [rsp]
00007e4af17de4b1  mov esi, 0x00
00007e4af17de4b6  mov rax, 0x6256754A7530
00007e4af17de4c0  call rax
00007e4af17de4c2  movaps xmm5, [rsp]
00007e4af17de4c6  add rsp, 0x30
00007e4af17de4ca  vmovaps xmm0, [rsp]
00007e4af17de4cf  vmovaps xmm1, [rsp+0x10]
00007e4af17de4d5  vmovaps xmm2, [rsp+0x20]
00007e4af17de4db  vmovaps xmm3, [rsp+0x30]
00007e4af17de4e1  vmovaps xmm4, [rsp+0x40]
00007e4af17de4e7  vmovaps xmm6, [rsp+0x50]
00007e4af17de4ed  vmovaps xmm7, [rsp+0x60]
00007e4af17de4f3  vmovaps xmm8, [rsp+0x70]
00007e4af17de4f9  vmovaps xmm9, [rsp+0x80]
00007e4af17de502  vmovaps xmm10, [rsp+0x90]
00007e4af17de50b  vmovaps xmm11, [rsp+0xA0]
00007e4af17de514  vmovaps xmm12, [rsp+0xB0]
00007e4af17de51d  vmovaps xmm13, [rsp+0xC0]
00007e4af17de526  vmovaps xmm14, [rsp+0xD0]
00007e4af17de52f  vmovaps xmm15, [rsp+0xE0]
00007e4af17de538  add rsp, 0xF0
00007e4af17de53f  pop r11
00007e4af17de541  pop r10
00007e4af17de543  pop r9
00007e4af17de545  pop r8
00007e4af17de547  pop rsi
00007e4af17de548  pop rdi
00007e4af17de549  pop rdx
00007e4af17de54a  pop rcx
00007e4af17de54b  pop rax
00007e4af17de54c  add rsp, 0x08
00007e4af17de550  jmp 0x00007E4AF17DC13A
00007e4af17de555  sub rsp, 0x08
00007e4af17de559  push rax
00007e4af17de55a  push rcx
00007e4af17de55b  push rdx
00007e4af17de55c  push rdi
00007e4af17de55d  push rsi
00007e4af17de55e  push r8
00007e4af17de560  push r9
00007e4af17de562  push r10
00007e4af17de564  push r11
00007e4af17de566  sub rsp, 0xF0
00007e4af17de56d  vmovaps [rsp], xmm0
00007e4af17de572  vmovaps [rsp+0x10], xmm1
00007e4af17de578  vmovaps [rsp+0x20], xmm2
00007e4af17de57e  vmovaps [rsp+0x30], xmm3
00007e4af17de584  vmovaps [rsp+0x40], xmm4
00007e4af17de58a  vmovaps [rsp+0x50], xmm5
00007e4af17de590  vmovaps [rsp+0x60], xmm7
00007e4af17de596  vmovaps [rsp+0x70], xmm8
00007e4af17de59c  vmovaps [rsp+0x80], xmm9
00007e4af17de5a5  vmovaps [rsp+0x90], xmm10
00007e4af17de5ae  vmovaps [rsp+0xA0], xmm11
00007e4af17de5b7  vmovaps [rsp+0xB0], xmm12
00007e4af17de5c0  vmovaps [rsp+0xC0], xmm13
00007e4af17de5c9  vmovaps [rsp+0xD0], xmm14
00007e4af17de5d2  vmovaps [rsp+0xE0], xmm15
00007e4af17de5db  sub rsp, 0x30
00007e4af17de5df  movaps [rsp], xmm6
00007e4af17de5e3  movaps [rsp+0x10], xmm9
00007e4af17de5e9  movaps [rsp+0x20], xmm1
00007e4af17de5ee  lea rdi, [rsp]
00007e4af17de5f2  mov esi, 0x00
00007e4af17de5f7  mov rax, 0x6256754A7530
00007e4af17de601  call rax
00007e4af17de603  movaps xmm6, [rsp]
00007e4af17de607  add rsp, 0x30
00007e4af17de60b  vmovaps xmm0, [rsp]
00007e4af17de610  vmovaps xmm1, [rsp+0x10]
00007e4af17de616  vmovaps xmm2, [rsp+0x20]
00007e4af17de61c  vmovaps xmm3, [rsp+0x30]
00007e4af17de622  vmovaps xmm4, [rsp+0x40]
00007e4af17de628  vmovaps xmm5, [rsp+0x50]
00007e4af17de62e  vmovaps xmm7, [rsp+0x60]
00007e4af17de634  vmovaps xmm8, [rsp+0x70]
00007e4af17de63a  vmovaps xmm9, [rsp+0x80]
00007e4af17de643  vmovaps xmm10, [rsp+0x90]
00007e4af17de64c  vmovaps xmm11, [rsp+0xA0]
00007e4af17de655  vmovaps xmm12, [rsp+0xB0]
00007e4af17de65e  vmovaps xmm13, [rsp+0xC0]
00007e4af17de667  vmovaps xmm14, [rsp+0xD0]
00007e4af17de670  vmovaps xmm15, [rsp+0xE0]
00007e4af17de679  add rsp, 0xF0
00007e4af17de680  pop r11
00007e4af17de682  pop r10
00007e4af17de684  pop r9
00007e4af17de686  pop r8
00007e4af17de688  pop rsi
00007e4af17de689  pop rdi
00007e4af17de68a  pop rdx
00007e4af17de68b  pop rcx
00007e4af17de68c  pop rax
00007e4af17de68d  add rsp, 0x08
00007e4af17de691  jmp 0x00007E4AF17DC15E
00007e4af17de696  sub rsp, 0x08
00007e4af17de69a  push rax
00007e4af17de69b  push rcx
00007e4af17de69c  push rdx
00007e4af17de69d  push rdi
00007e4af17de69e  push rsi
00007e4af17de69f  push r8
00007e4af17de6a1  push r9
00007e4af17de6a3  push r10
00007e4af17de6a5  push r11
00007e4af17de6a7  sub rsp, 0xF0
00007e4af17de6ae  vmovaps [rsp], xmm0
00007e4af17de6b3  vmovaps [rsp+0x10], xmm1
00007e4af17de6b9  vmovaps [rsp+0x20], xmm2
00007e4af17de6bf  vmovaps [rsp+0x30], xmm3
00007e4af17de6c5  vmovaps [rsp+0x40], xmm4
00007e4af17de6cb  vmovaps [rsp+0x50], xmm5
00007e4af17de6d1  vmovaps [rsp+0x60], xmm6
00007e4af17de6d7  vmovaps [rsp+0x70], xmm7
00007e4af17de6dd  vmovaps [rsp+0x80], xmm8
00007e4af17de6e6  vmovaps [rsp+0x90], xmm10
00007e4af17de6ef  vmovaps [rsp+0xA0], xmm11
00007e4af17de6f8  vmovaps [rsp+0xB0], xmm12
00007e4af17de701  vmovaps [rsp+0xC0], xmm13
00007e4af17de70a  vmovaps [rsp+0xD0], xmm14
00007e4af17de713  vmovaps [rsp+0xE0], xmm15
00007e4af17de71c  sub rsp, 0x30
00007e4af17de720  movaps [rsp], xmm9
00007e4af17de725  movaps [rsp+0x10], xmm3
00007e4af17de72a  movaps [rsp+0x20], xmm1
00007e4af17de72f  lea rdi, [rsp]
00007e4af17de733  mov esi, 0x00
00007e4af17de738  mov rax, 0x6256754A7530
00007e4af17de742  call rax
00007e4af17de744  movaps xmm9, [rsp]
00007e4af17de749  add rsp, 0x30
00007e4af17de74d  vmovaps xmm0, [rsp]
00007e4af17de752  vmovaps xmm1, [rsp+0x10]
00007e4af17de758  vmovaps xmm2, [rsp+0x20]
00007e4af17de75e  vmovaps xmm3, [rsp+0x30]
00007e4af17de764  vmovaps xmm4, [rsp+0x40]
00007e4af17de76a  vmovaps xmm5, [rsp+0x50]
00007e4af17de770  vmovaps xmm6, [rsp+0x60]
00007e4af17de776  vmovaps xmm7, [rsp+0x70]
00007e4af17de77c  vmovaps xmm8, [rsp+0x80]
00007e4af17de785  vmovaps xmm10, [rsp+0x90]
00007e4af17de78e  vmovaps xmm11, [rsp+0xA0]
00007e4af17de797  vmovaps xmm12, [rsp+0xB0]
00007e4af17de7a0  vmovaps xmm13, [rsp+0xC0]
00007e4af17de7a9  vmovaps xmm14, [rsp+0xD0]
00007e4af17de7b2  vmovaps xmm15, [rsp+0xE0]
00007e4af17de7bb  add rsp, 0xF0
00007e4af17de7c2  pop r11
00007e4af17de7c4  pop r10
00007e4af17de7c6  pop r9
00007e4af17de7c8  pop r8
00007e4af17de7ca  pop rsi
00007e4af17de7cb  pop rdi
00007e4af17de7cc  pop rdx
00007e4af17de7cd  pop rcx
00007e4af17de7ce  pop rax
00007e4af17de7cf  add rsp, 0x08
00007e4af17de7d3  jmp 0x00007E4AF17DC1AA
00007e4af17de7d8  call 0x00007E4AF16B52F0
00007e4af17de7dd  jmp 0x00007E4AF17DC1B7
00007e4af17de7e2  sub rsp, 0x08
00007e4af17de7e6  push rax
00007e4af17de7e7  push rcx
00007e4af17de7e8  push rdx
00007e4af17de7e9  push rdi
00007e4af17de7ea  push rsi
00007e4af17de7eb  push r8
00007e4af17de7ed  push r9
00007e4af17de7ef  push r10
00007e4af17de7f1  push r11
00007e4af17de7f3  sub rsp, 0xF0
00007e4af17de7fa  vmovaps [rsp], xmm0
00007e4af17de7ff  vmovaps [rsp+0x10], xmm1
00007e4af17de805  vmovaps [rsp+0x20], xmm2
00007e4af17de80b  vmovaps [rsp+0x30], xmm3
00007e4af17de811  vmovaps [rsp+0x40], xmm4
00007e4af17de817  vmovaps [rsp+0x50], xmm5
00007e4af17de81d  vmovaps [rsp+0x60], xmm6
00007e4af17de823  vmovaps [rsp+0x70], xmm7
00007e4af17de829  vmovaps [rsp+0x80], xmm8
00007e4af17de832  vmovaps [rsp+0x90], xmm9
00007e4af17de83b  vmovaps [rsp+0xA0], xmm10
00007e4af17de844  vmovaps [rsp+0xB0], xmm11
00007e4af17de84d  vmovaps [rsp+0xC0], xmm12
00007e4af17de856  vmovaps [rsp+0xD0], xmm13
00007e4af17de85f  vmovaps [rsp+0xE0], xmm14
00007e4af17de868  sub rsp, 0x30
00007e4af17de86c  movaps [rsp], xmm15
00007e4af17de871  movaps [rsp+0x10], xmm3
00007e4af17de876  movaps [rsp+0x20], xmm7
00007e4af17de87b  lea rdi, [rsp]
00007e4af17de87f  mov esi, 0x00
00007e4af17de884  mov rax, 0x6256754A7530
00007e4af17de88e  call rax
00007e4af17de890  movaps xmm15, [rsp]
00007e4af17de895  add rsp, 0x30
00007e4af17de899  vmovaps xmm0, [rsp]
00007e4af17de89e  vmovaps xmm1, [rsp+0x10]
00007e4af17de8a4  vmovaps xmm2, [rsp+0x20]
00007e4af17de8aa  vmovaps xmm3, [rsp+0x30]
00007e4af17de8b0  vmovaps xmm4, [rsp+0x40]
00007e4af17de8b6  vmovaps xmm5, [rsp+0x50]
00007e4af17de8bc  vmovaps xmm6, [rsp+0x60]
00007e4af17de8c2  vmovaps xmm7, [rsp+0x70]
00007e4af17de8c8  vmovaps xmm8, [rsp+0x80]
00007e4af17de8d1  vmovaps xmm9, [rsp+0x90]
00007e4af17de8da  vmovaps xmm10, [rsp+0xA0]
00007e4af17de8e3  vmovaps xmm11, [rsp+0xB0]
00007e4af17de8ec  vmovaps xmm12, [rsp+0xC0]
00007e4af17de8f5  vmovaps xmm13, [rsp+0xD0]
00007e4af17de8fe  vmovaps xmm14, [rsp+0xE0]
00007e4af17de907  add rsp, 0xF0
00007e4af17de90e  pop r11
00007e4af17de910  pop r10
00007e4af17de912  pop r9
00007e4af17de914  pop r8
00007e4af17de916  pop rsi
00007e4af17de917  pop rdi
00007e4af17de918  pop rdx
00007e4af17de919  pop rcx
00007e4af17de91a  pop rax
00007e4af17de91b  add rsp, 0x08
00007e4af17de91f  jmp 0x00007E4AF17DC1E3
00007e4af17de924  sub rsp, 0x08
00007e4af17de928  push rax
00007e4af17de929  push rcx
00007e4af17de92a  push rdx
00007e4af17de92b  push rdi
00007e4af17de92c  push rsi
00007e4af17de92d  push r8
00007e4af17de92f  push r9
00007e4af17de931  push r10
00007e4af17de933  push r11
00007e4af17de935  sub rsp, 0xF0
00007e4af17de93c  vmovaps [rsp], xmm0
00007e4af17de941  vmovaps [rsp+0x10], xmm1
00007e4af17de947  vmovaps [rsp+0x20], xmm2
00007e4af17de94d  vmovaps [rsp+0x30], xmm4
00007e4af17de953  vmovaps [rsp+0x40], xmm5
00007e4af17de959  vmovaps [rsp+0x50], xmm6
00007e4af17de95f  vmovaps [rsp+0x60], xmm7
00007e4af17de965  vmovaps [rsp+0x70], xmm8
00007e4af17de96b  vmovaps [rsp+0x80], xmm9
00007e4af17de974  vmovaps [rsp+0x90], xmm10
00007e4af17de97d  vmovaps [rsp+0xA0], xmm11
00007e4af17de986  vmovaps [rsp+0xB0], xmm12
00007e4af17de98f  vmovaps [rsp+0xC0], xmm13
00007e4af17de998  vmovaps [rsp+0xD0], xmm14
00007e4af17de9a1  vmovaps [rsp+0xE0], xmm15
00007e4af17de9aa  sub rsp, 0x30
00007e4af17de9ae  movaps [rsp], xmm3
00007e4af17de9b2  movaps [rsp+0x10], xmm1
00007e4af17de9b7  movaps [rsp+0x20], xmm15
00007e4af17de9bd  lea rdi, [rsp]
00007e4af17de9c1  mov esi, 0x00
00007e4af17de9c6  mov rax, 0x6256754A7530
00007e4af17de9d0  call rax
00007e4af17de9d2  movaps xmm3, [rsp]
00007e4af17de9d6  add rsp, 0x30
00007e4af17de9da  vmovaps xmm0, [rsp]
00007e4af17de9df  vmovaps xmm1, [rsp+0x10]
00007e4af17de9e5  vmovaps xmm2, [rsp+0x20]
00007e4af17de9eb  vmovaps xmm4, [rsp+0x30]
00007e4af17de9f1  vmovaps xmm5, [rsp+0x40]
00007e4af17de9f7  vmovaps xmm6, [rsp+0x50]
00007e4af17de9fd  vmovaps xmm7, [rsp+0x60]
00007e4af17dea03  vmovaps xmm8, [rsp+0x70]
00007e4af17dea09  vmovaps xmm9, [rsp+0x80]
00007e4af17dea12  vmovaps xmm10, [rsp+0x90]
00007e4af17dea1b  vmovaps xmm11, [rsp+0xA0]
00007e4af17dea24  vmovaps xmm12, [rsp+0xB0]
00007e4af17dea2d  vmovaps xmm13, [rsp+0xC0]
00007e4af17dea36  vmovaps xmm14, [rsp+0xD0]
00007e4af17dea3f  vmovaps xmm15, [rsp+0xE0]
00007e4af17dea48  add rsp, 0xF0
00007e4af17dea4f  pop r11
00007e4af17dea51  pop r10
00007e4af17dea53  pop r9
00007e4af17dea55  pop r8
00007e4af17dea57  pop rsi
00007e4af17dea58  pop rdi
00007e4af17dea59  pop rdx
00007e4af17dea5a  pop rcx
00007e4af17dea5b  pop rax
00007e4af17dea5c  add rsp, 0x08
00007e4af17dea60  jmp 0x00007E4AF17DC272
00007e4af17dea65  call 0x00007E4AF16B52F0
00007e4af17dea6a  jmp 0x00007E4AF17DC27C
00007e4af17dea6f  sub rsp, 0x08
00007e4af17dea73  push rax
00007e4af17dea74  push rcx
00007e4af17dea75  push rdx
00007e4af17dea76  push rdi
00007e4af17dea77  push rsi
00007e4af17dea78  push r8
00007e4af17dea7a  push r9
00007e4af17dea7c  push r10
00007e4af17dea7e  push r11
00007e4af17dea80  sub rsp, 0xF0
00007e4af17dea87  vmovaps [rsp], xmm0
00007e4af17dea8c  vmovaps [rsp+0x10], xmm1
00007e4af17dea92  vmovaps [rsp+0x20], xmm2
00007e4af17dea98  vmovaps [rsp+0x30], xmm3
00007e4af17dea9e  vmovaps [rsp+0x40], xmm4
00007e4af17deaa4  vmovaps [rsp+0x50], xmm5
00007e4af17deaaa  vmovaps [rsp+0x60], xmm6
00007e4af17deab0  vmovaps [rsp+0x70], xmm7
00007e4af17deab6  vmovaps [rsp+0x80], xmm8
00007e4af17deabf  vmovaps [rsp+0x90], xmm9
00007e4af17deac8  vmovaps [rsp+0xA0], xmm10
00007e4af17dead1  vmovaps [rsp+0xB0], xmm11
00007e4af17deada  vmovaps [rsp+0xC0], xmm12
00007e4af17deae3  vmovaps [rsp+0xD0], xmm13
00007e4af17deaec  vmovaps [rsp+0xE0], xmm14
00007e4af17deaf5  sub rsp, 0x30
00007e4af17deaf9  movaps [rsp], xmm15
00007e4af17deafe  movaps [rsp+0x10], xmm14
00007e4af17deb04  movaps [rsp+0x20], xmm4
00007e4af17deb09  lea rdi, [rsp]
00007e4af17deb0d  mov esi, 0x00
00007e4af17deb12  mov rax, 0x6256754A7530
00007e4af17deb1c  call rax
00007e4af17deb1e  movaps xmm15, [rsp]
00007e4af17deb23  add rsp, 0x30
00007e4af17deb27  vmovaps xmm0, [rsp]
00007e4af17deb2c  vmovaps xmm1, [rsp+0x10]
00007e4af17deb32  vmovaps xmm2, [rsp+0x20]
00007e4af17deb38  vmovaps xmm3, [rsp+0x30]
00007e4af17deb3e  vmovaps xmm4, [rsp+0x40]
00007e4af17deb44  vmovaps xmm5, [rsp+0x50]
00007e4af17deb4a  vmovaps xmm6, [rsp+0x60]
00007e4af17deb50  vmovaps xmm7, [rsp+0x70]
00007e4af17deb56  vmovaps xmm8, [rsp+0x80]
00007e4af17deb5f  vmovaps xmm9, [rsp+0x90]
00007e4af17deb68  vmovaps xmm10, [rsp+0xA0]
00007e4af17deb71  vmovaps xmm11, [rsp+0xB0]
00007e4af17deb7a  vmovaps xmm12, [rsp+0xC0]
00007e4af17deb83  vmovaps xmm13, [rsp+0xD0]
00007e4af17deb8c  vmovaps xmm14, [rsp+0xE0]
00007e4af17deb95  add rsp, 0xF0
00007e4af17deb9c  pop r11
00007e4af17deb9e  pop r10
00007e4af17deba0  pop r9
00007e4af17deba2  pop r8
00007e4af17deba4  pop rsi
00007e4af17deba5  pop rdi
00007e4af17deba6  pop rdx
00007e4af17deba7  pop rcx
00007e4af17deba8  pop rax
00007e4af17deba9  add rsp, 0x08
00007e4af17debad  jmp 0x00007E4AF17DC2AA
00007e4af17debb2  sub rsp, 0x08
00007e4af17debb6  push rax
00007e4af17debb7  push rcx
00007e4af17debb8  push rdx
00007e4af17debb9  push rdi
00007e4af17debba  push rsi
00007e4af17debbb  push r8
00007e4af17debbd  push r9
00007e4af17debbf  push r10
00007e4af17debc1  push r11
00007e4af17debc3  sub rsp, 0xF0
00007e4af17debca  vmovaps [rsp], xmm0
00007e4af17debcf  vmovaps [rsp+0x10], xmm1
00007e4af17debd5  vmovaps [rsp+0x20], xmm2
00007e4af17debdb  vmovaps [rsp+0x30], xmm3
00007e4af17debe1  vmovaps [rsp+0x40], xmm4
00007e4af17debe7  vmovaps [rsp+0x50], xmm5
00007e4af17debed  vmovaps [rsp+0x60], xmm6
00007e4af17debf3  vmovaps [rsp+0x70], xmm7
00007e4af17debf9  vmovaps [rsp+0x80], xmm8
00007e4af17dec02  vmovaps [rsp+0x90], xmm9
00007e4af17dec0b  vmovaps [rsp+0xA0], xmm10
00007e4af17dec14  vmovaps [rsp+0xB0], xmm11
00007e4af17dec1d  vmovaps [rsp+0xC0], xmm12
00007e4af17dec26  vmovaps [rsp+0xD0], xmm13
00007e4af17dec2f  vmovaps [rsp+0xE0], xmm15
00007e4af17dec38  sub rsp, 0x30
00007e4af17dec3c  movaps [rsp], xmm14
00007e4af17dec41  movaps [rsp+0x10], xmm2
00007e4af17dec46  movaps [rsp+0x20], xmm1
00007e4af17dec4b  lea rdi, [rsp]
00007e4af17dec4f  mov esi, 0x00
00007e4af17dec54  mov rax, 0x6256754A7530
00007e4af17dec5e  call rax
00007e4af17dec60  movaps xmm14, [rsp]
00007e4af17dec65  add rsp, 0x30
00007e4af17dec69  vmovaps xmm0, [rsp]
00007e4af17dec6e  vmovaps xmm1, [rsp+0x10]
00007e4af17dec74  vmovaps xmm2, [rsp+0x20]
00007e4af17dec7a  vmovaps xmm3, [rsp+0x30]
00007e4af17dec80  vmovaps xmm4, [rsp+0x40]
00007e4af17dec86  vmovaps xmm5, [rsp+0x50]
00007e4af17dec8c  vmovaps xmm6, [rsp+0x60]
00007e4af17dec92  vmovaps xmm7, [rsp+0x70]
00007e4af17dec98  vmovaps xmm8, [rsp+0x80]
00007e4af17deca1  vmovaps xmm9, [rsp+0x90]
00007e4af17decaa  vmovaps xmm10, [rsp+0xA0]
00007e4af17decb3  vmovaps xmm11, [rsp+0xB0]
00007e4af17decbc  vmovaps xmm12, [rsp+0xC0]
00007e4af17decc5  vmovaps xmm13, [rsp+0xD0]
00007e4af17decce  vmovaps xmm15, [rsp+0xE0]
00007e4af17decd7  add rsp, 0xF0
00007e4af17decde  pop r11
00007e4af17dece0  pop r10
00007e4af17dece2  pop r9
00007e4af17dece4  pop r8
00007e4af17dece6  pop rsi
00007e4af17dece7  pop rdi
00007e4af17dece8  pop rdx
00007e4af17dece9  pop rcx
00007e4af17decea  pop rax
00007e4af17deceb  add rsp, 0x08
00007e4af17decef  jmp 0x00007E4AF17DC2D0
00007e4af17decf4  sub rsp, 0x08
00007e4af17decf8  push rax
00007e4af17decf9  push rcx
00007e4af17decfa  push rdx
00007e4af17decfb  push rdi
00007e4af17decfc  push rsi
00007e4af17decfd  push r8
00007e4af17decff  push r9
00007e4af17ded01  push r10
00007e4af17ded03  push r11
00007e4af17ded05  sub rsp, 0xF0
00007e4af17ded0c  vmovaps [rsp], xmm0
00007e4af17ded11  vmovaps [rsp+0x10], xmm2
00007e4af17ded17  vmovaps [rsp+0x20], xmm3
00007e4af17ded1d  vmovaps [rsp+0x30], xmm4
00007e4af17ded23  vmovaps [rsp+0x40], xmm5
00007e4af17ded29  vmovaps [rsp+0x50], xmm6
00007e4af17ded2f  vmovaps [rsp+0x60], xmm7
00007e4af17ded35  vmovaps [rsp+0x70], xmm8
00007e4af17ded3b  vmovaps [rsp+0x80], xmm9
00007e4af17ded44  vmovaps [rsp+0x90], xmm10
00007e4af17ded4d  vmovaps [rsp+0xA0], xmm11
00007e4af17ded56  vmovaps [rsp+0xB0], xmm12
00007e4af17ded5f  vmovaps [rsp+0xC0], xmm13
00007e4af17ded68  vmovaps [rsp+0xD0], xmm14
00007e4af17ded71  vmovaps [rsp+0xE0], xmm15
00007e4af17ded7a  sub rsp, 0x30
00007e4af17ded7e  movaps [rsp], xmm1
00007e4af17ded82  movaps [rsp+0x10], xmm4
00007e4af17ded87  movaps [rsp+0x20], xmm9
00007e4af17ded8d  lea rdi, [rsp]
00007e4af17ded91  mov esi, 0x00
00007e4af17ded96  mov rax, 0x6256754A7530
00007e4af17deda0  call rax
00007e4af17deda2  movaps xmm1, [rsp]
00007e4af17deda6  add rsp, 0x30
00007e4af17dedaa  vmovaps xmm0, [rsp]
00007e4af17dedaf  vmovaps xmm2, [rsp+0x10]
00007e4af17dedb5  vmovaps xmm3, [rsp+0x20]
00007e4af17dedbb  vmovaps xmm4, [rsp+0x30]
00007e4af17dedc1  vmovaps xmm5, [rsp+0x40]
00007e4af17dedc7  vmovaps xmm6, [rsp+0x50]
00007e4af17dedcd  vmovaps xmm7, [rsp+0x60]
00007e4af17dedd3  vmovaps xmm8, [rsp+0x70]
00007e4af17dedd9  vmovaps xmm9, [rsp+0x80]
00007e4af17dede2  vmovaps xmm10, [rsp+0x90]
00007e4af17dedeb  vmovaps xmm11, [rsp+0xA0]
00007e4af17dedf4  vmovaps xmm12, [rsp+0xB0]
00007e4af17dedfd  vmovaps xmm13, [rsp+0xC0]
00007e4af17dee06  vmovaps xmm14, [rsp+0xD0]
00007e4af17dee0f  vmovaps xmm15, [rsp+0xE0]
00007e4af17dee18  add rsp, 0xF0
00007e4af17dee1f  pop r11
00007e4af17dee21  pop r10
00007e4af17dee23  pop r9
00007e4af17dee25  pop r8
00007e4af17dee27  pop rsi
00007e4af17dee28  pop rdi
00007e4af17dee29  pop rdx
00007e4af17dee2a  pop rcx
00007e4af17dee2b  pop rax
00007e4af17dee2c  add rsp, 0x08
00007e4af17dee30  jmp 0x00007E4AF17DC2EE
00007e4af17dee35  sub rsp, 0x08
00007e4af17dee39  push rax
00007e4af17dee3a  push rcx
00007e4af17dee3b  push rdx
00007e4af17dee3c  push rdi
00007e4af17dee3d  push rsi
00007e4af17dee3e  push r8
00007e4af17dee40  push r9
00007e4af17dee42  push r10
00007e4af17dee44  push r11
00007e4af17dee46  sub rsp, 0xF0
00007e4af17dee4d  vmovaps [rsp], xmm0
00007e4af17dee52  vmovaps [rsp+0x10], xmm1
00007e4af17dee58  vmovaps [rsp+0x20], xmm2
00007e4af17dee5e  vmovaps [rsp+0x30], xmm3
00007e4af17dee64  vmovaps [rsp+0x40], xmm5
00007e4af17dee6a  vmovaps [rsp+0x50], xmm6
00007e4af17dee70  vmovaps [rsp+0x60], xmm7
00007e4af17dee76  vmovaps [rsp+0x70], xmm8
00007e4af17dee7c  vmovaps [rsp+0x80], xmm9
00007e4af17dee85  vmovaps [rsp+0x90], xmm10
00007e4af17dee8e  vmovaps [rsp+0xA0], xmm11
00007e4af17dee97  vmovaps [rsp+0xB0], xmm12
00007e4af17deea0  vmovaps [rsp+0xC0], xmm13
00007e4af17deea9  vmovaps [rsp+0xD0], xmm14
00007e4af17deeb2  vmovaps [rsp+0xE0], xmm15
00007e4af17deebb  sub rsp, 0x30
00007e4af17deebf  movaps [rsp], xmm4
00007e4af17deec3  movaps [rsp+0x10], xmm2
00007e4af17deec8  movaps [rsp+0x20], xmm9
00007e4af17deece  lea rdi, [rsp]
00007e4af17deed2  mov esi, 0x00
00007e4af17deed7  mov rax, 0x6256754A7530
00007e4af17deee1  call rax
00007e4af17deee3  movaps xmm4, [rsp]
00007e4af17deee7  add rsp, 0x30
00007e4af17deeeb  vmovaps xmm0, [rsp]
00007e4af17deef0  vmovaps xmm1, [rsp+0x10]
00007e4af17deef6  vmovaps xmm2, [rsp+0x20]
00007e4af17deefc  vmovaps xmm3, [rsp+0x30]
00007e4af17def02  vmovaps xmm5, [rsp+0x40]
00007e4af17def08  vmovaps xmm6, [rsp+0x50]
00007e4af17def0e  vmovaps xmm7, [rsp+0x60]
00007e4af17def14  vmovaps xmm8, [rsp+0x70]
00007e4af17def1a  vmovaps xmm9, [rsp+0x80]
00007e4af17def23  vmovaps xmm10, [rsp+0x90]
00007e4af17def2c  vmovaps xmm11, [rsp+0xA0]
00007e4af17def35  vmovaps xmm12, [rsp+0xB0]
00007e4af17def3e  vmovaps xmm13, [rsp+0xC0]
00007e4af17def47  vmovaps xmm14, [rsp+0xD0]
00007e4af17def50  vmovaps xmm15, [rsp+0xE0]
00007e4af17def59  add rsp, 0xF0
00007e4af17def60  pop r11
00007e4af17def62  pop r10
00007e4af17def64  pop r9
00007e4af17def66  pop r8
00007e4af17def68  pop rsi
00007e4af17def69  pop rdi
00007e4af17def6a  pop rdx
00007e4af17def6b  pop rcx
00007e4af17def6c  pop rax
00007e4af17def6d  add rsp, 0x08
00007e4af17def71  jmp 0x00007E4AF17DC31E
00007e4af17def76  sub rsp, 0x08
00007e4af17def7a  push rax
00007e4af17def7b  push rcx
00007e4af17def7c  push rdx
00007e4af17def7d  push rdi
00007e4af17def7e  push rsi
00007e4af17def7f  push r8
00007e4af17def81  push r9
00007e4af17def83  push r10
00007e4af17def85  push r11
00007e4af17def87  sub rsp, 0xF0
00007e4af17def8e  vmovaps [rsp], xmm0
00007e4af17def93  vmovaps [rsp+0x10], xmm1
00007e4af17def99  vmovaps [rsp+0x20], xmm2
00007e4af17def9f  vmovaps [rsp+0x30], xmm3
00007e4af17defa5  vmovaps [rsp+0x40], xmm4
00007e4af17defab  vmovaps [rsp+0x50], xmm5
00007e4af17defb1  vmovaps [rsp+0x60], xmm6
00007e4af17defb7  vmovaps [rsp+0x70], xmm7
00007e4af17defbd  vmovaps [rsp+0x80], xmm8
00007e4af17defc6  vmovaps [rsp+0x90], xmm10
00007e4af17defcf  vmovaps [rsp+0xA0], xmm11
00007e4af17defd8  vmovaps [rsp+0xB0], xmm12
00007e4af17defe1  vmovaps [rsp+0xC0], xmm13
00007e4af17defea  vmovaps [rsp+0xD0], xmm14
00007e4af17deff3  vmovaps [rsp+0xE0], xmm15
00007e4af17deffc  sub rsp, 0x30
00007e4af17df000  movaps [rsp], xmm9
00007e4af17df005  movaps [rsp+0x10], xmm2
00007e4af17df00a  movaps [rsp+0x20], xmm1
00007e4af17df00f  lea rdi, [rsp]
00007e4af17df013  mov esi, 0x00
00007e4af17df018  mov rax, 0x6256754A7530
00007e4af17df022  call rax
00007e4af17df024  movaps xmm9, [rsp]
00007e4af17df029  add rsp, 0x30
00007e4af17df02d  vmovaps xmm0, [rsp]
00007e4af17df032  vmovaps xmm1, [rsp+0x10]
00007e4af17df038  vmovaps xmm2, [rsp+0x20]
00007e4af17df03e  vmovaps xmm3, [rsp+0x30]
00007e4af17df044  vmovaps xmm4, [rsp+0x40]
00007e4af17df04a  vmovaps xmm5, [rsp+0x50]
00007e4af17df050  vmovaps xmm6, [rsp+0x60]
00007e4af17df056  vmovaps xmm7, [rsp+0x70]
00007e4af17df05c  vmovaps xmm8, [rsp+0x80]
00007e4af17df065  vmovaps xmm10, [rsp+0x90]
00007e4af17df06e  vmovaps xmm11, [rsp+0xA0]
00007e4af17df077  vmovaps xmm12, [rsp+0xB0]
00007e4af17df080  vmovaps xmm13, [rsp+0xC0]
00007e4af17df089  vmovaps xmm14, [rsp+0xD0]
00007e4af17df092  vmovaps xmm15, [rsp+0xE0]
00007e4af17df09b  add rsp, 0xF0
00007e4af17df0a2  pop r11
00007e4af17df0a4  pop r10
00007e4af17df0a6  pop r9
00007e4af17df0a8  pop r8
00007e4af17df0aa  pop rsi
00007e4af17df0ab  pop rdi
00007e4af17df0ac  pop rdx
00007e4af17df0ad  pop rcx
00007e4af17df0ae  pop rax
00007e4af17df0af  add rsp, 0x08
00007e4af17df0b3  jmp 0x00007E4AF17DC354
00007e4af17df0b8  sub rsp, 0x08
00007e4af17df0bc  push rax
00007e4af17df0bd  push rcx
00007e4af17df0be  push rdx
00007e4af17df0bf  push rdi
00007e4af17df0c0  push rsi
00007e4af17df0c1  push r8
00007e4af17df0c3  push r9
00007e4af17df0c5  push r10
00007e4af17df0c7  push r11
00007e4af17df0c9  sub rsp, 0xF0
00007e4af17df0d0  vmovaps [rsp], xmm0
00007e4af17df0d5  vmovaps [rsp+0x10], xmm2
00007e4af17df0db  vmovaps [rsp+0x20], xmm3
00007e4af17df0e1  vmovaps [rsp+0x30], xmm4
00007e4af17df0e7  vmovaps [rsp+0x40], xmm5
00007e4af17df0ed  vmovaps [rsp+0x50], xmm6
00007e4af17df0f3  vmovaps [rsp+0x60], xmm7
00007e4af17df0f9  vmovaps [rsp+0x70], xmm8
00007e4af17df0ff  vmovaps [rsp+0x80], xmm9
00007e4af17df108  vmovaps [rsp+0x90], xmm10
00007e4af17df111  vmovaps [rsp+0xA0], xmm11
00007e4af17df11a  vmovaps [rsp+0xB0], xmm12
00007e4af17df123  vmovaps [rsp+0xC0], xmm13
00007e4af17df12c  vmovaps [rsp+0xD0], xmm14
00007e4af17df135  vmovaps [rsp+0xE0], xmm15
00007e4af17df13e  sub rsp, 0x30
00007e4af17df142  movaps [rsp], xmm1
00007e4af17df146  movaps [rsp+0x10], xmm15
00007e4af17df14c  movaps [rsp+0x20], xmm6
00007e4af17df151  lea rdi, [rsp]
00007e4af17df155  mov esi, 0x00
00007e4af17df15a  mov rax, 0x6256754A7530
00007e4af17df164  call rax
00007e4af17df166  movaps xmm1, [rsp]
00007e4af17df16a  add rsp, 0x30
00007e4af17df16e  vmovaps xmm0, [rsp]
00007e4af17df173  vmovaps xmm2, [rsp+0x10]
00007e4af17df179  vmovaps xmm3, [rsp+0x20]
00007e4af17df17f  vmovaps xmm4, [rsp+0x30]
00007e4af17df185  vmovaps xmm5, [rsp+0x40]
00007e4af17df18b  vmovaps xmm6, [rsp+0x50]
00007e4af17df191  vmovaps xmm7, [rsp+0x60]
00007e4af17df197  vmovaps xmm8, [rsp+0x70]
00007e4af17df19d  vmovaps xmm9, [rsp+0x80]
00007e4af17df1a6  vmovaps xmm10, [rsp+0x90]
00007e4af17df1af  vmovaps xmm11, [rsp+0xA0]
00007e4af17df1b8  vmovaps xmm12, [rsp+0xB0]
00007e4af17df1c1  vmovaps xmm13, [rsp+0xC0]
00007e4af17df1ca  vmovaps xmm14, [rsp+0xD0]
00007e4af17df1d3  vmovaps xmm15, [rsp+0xE0]
00007e4af17df1dc  add rsp, 0xF0
00007e4af17df1e3  pop r11
00007e4af17df1e5  pop r10
00007e4af17df1e7  pop r9
00007e4af17df1e9  pop r8
00007e4af17df1eb  pop rsi
00007e4af17df1ec  pop rdi
00007e4af17df1ed  pop rdx
00007e4af17df1ee  pop rcx
00007e4af17df1ef  pop rax
00007e4af17df1f0  add rsp, 0x08
00007e4af17df1f4  jmp 0x00007E4AF17DC375
00007e4af17df1f9  sub rsp, 0x08
00007e4af17df1fd  push rax
00007e4af17df1fe  push rcx
00007e4af17df1ff  push rdx
00007e4af17df200  push rdi
00007e4af17df201  push rsi
00007e4af17df202  push r8
00007e4af17df204  push r9
00007e4af17df206  push r10
00007e4af17df208  push r11
00007e4af17df20a  sub rsp, 0xF0
00007e4af17df211  vmovaps [rsp], xmm0
00007e4af17df216  vmovaps [rsp+0x10], xmm1
00007e4af17df21c  vmovaps [rsp+0x20], xmm2
00007e4af17df222  vmovaps [rsp+0x30], xmm3
00007e4af17df228  vmovaps [rsp+0x40], xmm4
00007e4af17df22e  vmovaps [rsp+0x50], xmm5
00007e4af17df234  vmovaps [rsp+0x60], xmm6
00007e4af17df23a  vmovaps [rsp+0x70], xmm7
00007e4af17df240  vmovaps [rsp+0x80], xmm8
00007e4af17df249  vmovaps [rsp+0x90], xmm9
00007e4af17df252  vmovaps [rsp+0xA0], xmm10
00007e4af17df25b  vmovaps [rsp+0xB0], xmm11
00007e4af17df264  vmovaps [rsp+0xC0], xmm12
00007e4af17df26d  vmovaps [rsp+0xD0], xmm13
00007e4af17df276  vmovaps [rsp+0xE0], xmm14
00007e4af17df27f  sub rsp, 0x30
00007e4af17df283  movaps [rsp], xmm15
00007e4af17df288  movaps [rsp+0x10], xmm5
00007e4af17df28d  movaps [rsp+0x20], xmm3
00007e4af17df292  lea rdi, [rsp]
00007e4af17df296  mov esi, 0x00
00007e4af17df29b  mov rax, 0x6256754A7530
00007e4af17df2a5  call rax
00007e4af17df2a7  movaps xmm15, [rsp]
00007e4af17df2ac  add rsp, 0x30
00007e4af17df2b0  vmovaps xmm0, [rsp]
00007e4af17df2b5  vmovaps xmm1, [rsp+0x10]
00007e4af17df2bb  vmovaps xmm2, [rsp+0x20]
00007e4af17df2c1  vmovaps xmm3, [rsp+0x30]
00007e4af17df2c7  vmovaps xmm4, [rsp+0x40]
00007e4af17df2cd  vmovaps xmm5, [rsp+0x50]
00007e4af17df2d3  vmovaps xmm6, [rsp+0x60]
00007e4af17df2d9  vmovaps xmm7, [rsp+0x70]
00007e4af17df2df  vmovaps xmm8, [rsp+0x80]
00007e4af17df2e8  vmovaps xmm9, [rsp+0x90]
00007e4af17df2f1  vmovaps xmm10, [rsp+0xA0]
00007e4af17df2fa  vmovaps xmm11, [rsp+0xB0]
00007e4af17df303  vmovaps xmm12, [rsp+0xC0]
00007e4af17df30c  vmovaps xmm13, [rsp+0xD0]
00007e4af17df315  vmovaps xmm14, [rsp+0xE0]
00007e4af17df31e  add rsp, 0xF0
00007e4af17df325  pop r11
00007e4af17df327  pop r10
00007e4af17df329  pop r9
00007e4af17df32b  pop r8
00007e4af17df32d  pop rsi
00007e4af17df32e  pop rdi
00007e4af17df32f  pop rdx
00007e4af17df330  pop rcx
00007e4af17df331  pop rax
00007e4af17df332  add rsp, 0x08
00007e4af17df336  jmp 0x00007E4AF17DC38F
00007e4af17df33b  sub rsp, 0x08
00007e4af17df33f  push rax
00007e4af17df340  push rcx
00007e4af17df341  push rdx
00007e4af17df342  push rdi
00007e4af17df343  push rsi
00007e4af17df344  push r8
00007e4af17df346  push r9
00007e4af17df348  push r10
00007e4af17df34a  push r11
00007e4af17df34c  sub rsp, 0xF0
00007e4af17df353  vmovaps [rsp], xmm0
00007e4af17df358  vmovaps [rsp+0x10], xmm1
00007e4af17df35e  vmovaps [rsp+0x20], xmm2
00007e4af17df364  vmovaps [rsp+0x30], xmm3
00007e4af17df36a  vmovaps [rsp+0x40], xmm4
00007e4af17df370  vmovaps [rsp+0x50], xmm6
00007e4af17df376  vmovaps [rsp+0x60], xmm7
00007e4af17df37c  vmovaps [rsp+0x70], xmm8
00007e4af17df382  vmovaps [rsp+0x80], xmm9
00007e4af17df38b  vmovaps [rsp+0x90], xmm10
00007e4af17df394  vmovaps [rsp+0xA0], xmm11
00007e4af17df39d  vmovaps [rsp+0xB0], xmm12
00007e4af17df3a6  vmovaps [rsp+0xC0], xmm13
00007e4af17df3af  vmovaps [rsp+0xD0], xmm14
00007e4af17df3b8  vmovaps [rsp+0xE0], xmm15
00007e4af17df3c1  sub rsp, 0x30
00007e4af17df3c5  movaps [rsp], xmm5
00007e4af17df3c9  movaps [rsp+0x10], xmm8
00007e4af17df3cf  movaps [rsp+0x20], xmm6
00007e4af17df3d4  lea rdi, [rsp]
00007e4af17df3d8  mov esi, 0x00
00007e4af17df3dd  mov rax, 0x6256754A7530
00007e4af17df3e7  call rax
00007e4af17df3e9  movaps xmm5, [rsp]
00007e4af17df3ed  add rsp, 0x30
00007e4af17df3f1  vmovaps xmm0, [rsp]
00007e4af17df3f6  vmovaps xmm1, [rsp+0x10]
00007e4af17df3fc  vmovaps xmm2, [rsp+0x20]
00007e4af17df402  vmovaps xmm3, [rsp+0x30]
00007e4af17df408  vmovaps xmm4, [rsp+0x40]
00007e4af17df40e  vmovaps xmm6, [rsp+0x50]
00007e4af17df414  vmovaps xmm7, [rsp+0x60]
00007e4af17df41a  vmovaps xmm8, [rsp+0x70]
00007e4af17df420  vmovaps xmm9, [rsp+0x80]
00007e4af17df429  vmovaps xmm10, [rsp+0x90]
00007e4af17df432  vmovaps xmm11, [rsp+0xA0]
00007e4af17df43b  vmovaps xmm12, [rsp+0xB0]
00007e4af17df444  vmovaps xmm13, [rsp+0xC0]
00007e4af17df44d  vmovaps xmm14, [rsp+0xD0]
00007e4af17df456  vmovaps xmm15, [rsp+0xE0]
00007e4af17df45f  add rsp, 0xF0
00007e4af17df466  pop r11
00007e4af17df468  pop r10
00007e4af17df46a  pop r9
00007e4af17df46c  pop r8
00007e4af17df46e  pop rsi
00007e4af17df46f  pop rdi
00007e4af17df470  pop rdx
00007e4af17df471  pop rcx
00007e4af17df472  pop rax
00007e4af17df473  add rsp, 0x08
00007e4af17df477  jmp 0x00007E4AF17DC3B3
00007e4af17df47c  sub rsp, 0x08
00007e4af17df480  push rax
00007e4af17df481  push rcx
00007e4af17df482  push rdx
00007e4af17df483  push rdi
00007e4af17df484  push rsi
00007e4af17df485  push r8
00007e4af17df487  push r9
00007e4af17df489  push r10
00007e4af17df48b  push r11
00007e4af17df48d  sub rsp, 0xF0
00007e4af17df494  vmovaps [rsp], xmm0
00007e4af17df499  vmovaps [rsp+0x10], xmm1
00007e4af17df49f  vmovaps [rsp+0x20], xmm2
00007e4af17df4a5  vmovaps [rsp+0x30], xmm3
00007e4af17df4ab  vmovaps [rsp+0x40], xmm4
00007e4af17df4b1  vmovaps [rsp+0x50], xmm5
00007e4af17df4b7  vmovaps [rsp+0x60], xmm7
00007e4af17df4bd  vmovaps [rsp+0x70], xmm8
00007e4af17df4c3  vmovaps [rsp+0x80], xmm9
00007e4af17df4cc  vmovaps [rsp+0x90], xmm10
00007e4af17df4d5  vmovaps [rsp+0xA0], xmm11
00007e4af17df4de  vmovaps [rsp+0xB0], xmm12
00007e4af17df4e7  vmovaps [rsp+0xC0], xmm13
00007e4af17df4f0  vmovaps [rsp+0xD0], xmm14
00007e4af17df4f9  vmovaps [rsp+0xE0], xmm15
00007e4af17df502  sub rsp, 0x30
00007e4af17df506  movaps [rsp], xmm6
00007e4af17df50a  movaps [rsp+0x10], xmm10
00007e4af17df510  movaps [rsp+0x20], xmm8
00007e4af17df516  lea rdi, [rsp]
00007e4af17df51a  mov esi, 0x00
00007e4af17df51f  mov rax, 0x6256754A7530
00007e4af17df529  call rax
00007e4af17df52b  movaps xmm6, [rsp]
00007e4af17df52f  add rsp, 0x30
00007e4af17df533  vmovaps xmm0, [rsp]
00007e4af17df538  vmovaps xmm1, [rsp+0x10]
00007e4af17df53e  vmovaps xmm2, [rsp+0x20]
00007e4af17df544  vmovaps xmm3, [rsp+0x30]
00007e4af17df54a  vmovaps xmm4, [rsp+0x40]
00007e4af17df550  vmovaps xmm5, [rsp+0x50]
00007e4af17df556  vmovaps xmm7, [rsp+0x60]
00007e4af17df55c  vmovaps xmm8, [rsp+0x70]
00007e4af17df562  vmovaps xmm9, [rsp+0x80]
00007e4af17df56b  vmovaps xmm10, [rsp+0x90]
00007e4af17df574  vmovaps xmm11, [rsp+0xA0]
00007e4af17df57d  vmovaps xmm12, [rsp+0xB0]
00007e4af17df586  vmovaps xmm13, [rsp+0xC0]
00007e4af17df58f  vmovaps xmm14, [rsp+0xD0]
00007e4af17df598  vmovaps xmm15, [rsp+0xE0]
00007e4af17df5a1  add rsp, 0xF0
00007e4af17df5a8  pop r11
00007e4af17df5aa  pop r10
00007e4af17df5ac  pop r9
00007e4af17df5ae  pop r8
00007e4af17df5b0  pop rsi
00007e4af17df5b1  pop rdi
00007e4af17df5b2  pop rdx
00007e4af17df5b3  pop rcx
00007e4af17df5b4  pop rax
00007e4af17df5b5  add rsp, 0x08
00007e4af17df5b9  jmp 0x00007E4AF17DC3D8
00007e4af17df5be  sub rsp, 0x08
00007e4af17df5c2  push rax
00007e4af17df5c3  push rcx
00007e4af17df5c4  push rdx
00007e4af17df5c5  push rdi
00007e4af17df5c6  push rsi
00007e4af17df5c7  push r8
00007e4af17df5c9  push r9
00007e4af17df5cb  push r10
00007e4af17df5cd  push r11
00007e4af17df5cf  sub rsp, 0xF0
00007e4af17df5d6  vmovaps [rsp], xmm0
00007e4af17df5db  vmovaps [rsp+0x10], xmm1
00007e4af17df5e1  vmovaps [rsp+0x20], xmm2
00007e4af17df5e7  vmovaps [rsp+0x30], xmm3
00007e4af17df5ed  vmovaps [rsp+0x40], xmm4
00007e4af17df5f3  vmovaps [rsp+0x50], xmm5
00007e4af17df5f9  vmovaps [rsp+0x60], xmm6
00007e4af17df5ff  vmovaps [rsp+0x70], xmm7
00007e4af17df605  vmovaps [rsp+0x80], xmm8
00007e4af17df60e  vmovaps [rsp+0x90], xmm9
00007e4af17df617  vmovaps [rsp+0xA0], xmm11
00007e4af17df620  vmovaps [rsp+0xB0], xmm12
00007e4af17df629  vmovaps [rsp+0xC0], xmm13
00007e4af17df632  vmovaps [rsp+0xD0], xmm14
00007e4af17df63b  vmovaps [rsp+0xE0], xmm15
00007e4af17df644  sub rsp, 0x30
00007e4af17df648  movaps [rsp], xmm10
00007e4af17df64d  movaps [rsp+0x10], xmm8
00007e4af17df653  movaps [rsp+0x20], xmm14
00007e4af17df659  lea rdi, [rsp]
00007e4af17df65d  mov esi, 0x00
00007e4af17df662  mov rax, 0x6256754A7530
00007e4af17df66c  call rax
00007e4af17df66e  movaps xmm10, [rsp]
00007e4af17df673  add rsp, 0x30
00007e4af17df677  vmovaps xmm0, [rsp]
00007e4af17df67c  vmovaps xmm1, [rsp+0x10]
00007e4af17df682  vmovaps xmm2, [rsp+0x20]
00007e4af17df688  vmovaps xmm3, [rsp+0x30]
00007e4af17df68e  vmovaps xmm4, [rsp+0x40]
00007e4af17df694  vmovaps xmm5, [rsp+0x50]
00007e4af17df69a  vmovaps xmm6, [rsp+0x60]
00007e4af17df6a0  vmovaps xmm7, [rsp+0x70]
00007e4af17df6a6  vmovaps xmm8, [rsp+0x80]
00007e4af17df6af  vmovaps xmm9, [rsp+0x90]
00007e4af17df6b8  vmovaps xmm11, [rsp+0xA0]
00007e4af17df6c1  vmovaps xmm12, [rsp+0xB0]
00007e4af17df6ca  vmovaps xmm13, [rsp+0xC0]
00007e4af17df6d3  vmovaps xmm14, [rsp+0xD0]
00007e4af17df6dc  vmovaps xmm15, [rsp+0xE0]
00007e4af17df6e5  add rsp, 0xF0
00007e4af17df6ec  pop r11
00007e4af17df6ee  pop r10
00007e4af17df6f0  pop r9
00007e4af17df6f2  pop r8
00007e4af17df6f4  pop rsi
00007e4af17df6f5  pop rdi
00007e4af17df6f6  pop rdx
00007e4af17df6f7  pop rcx
00007e4af17df6f8  pop rax
00007e4af17df6f9  add rsp, 0x08
00007e4af17df6fd  jmp 0x00007E4AF17DC3F8
00007e4af17df702  sub rsp, 0x08
00007e4af17df706  push rax
00007e4af17df707  push rcx
00007e4af17df708  push rdx
00007e4af17df709  push rdi
00007e4af17df70a  push rsi
00007e4af17df70b  push r8
00007e4af17df70d  push r9
00007e4af17df70f  push r10
00007e4af17df711  push r11
00007e4af17df713  sub rsp, 0xF0
00007e4af17df71a  vmovaps [rsp], xmm0
00007e4af17df71f  vmovaps [rsp+0x10], xmm1
00007e4af17df725  vmovaps [rsp+0x20], xmm2
00007e4af17df72b  vmovaps [rsp+0x30], xmm3
00007e4af17df731  vmovaps [rsp+0x40], xmm4
00007e4af17df737  vmovaps [rsp+0x50], xmm5
00007e4af17df73d  vmovaps [rsp+0x60], xmm6
00007e4af17df743  vmovaps [rsp+0x70], xmm7
00007e4af17df749  vmovaps [rsp+0x80], xmm8
00007e4af17df752  vmovaps [rsp+0x90], xmm9
00007e4af17df75b  vmovaps [rsp+0xA0], xmm10
00007e4af17df764  vmovaps [rsp+0xB0], xmm11
00007e4af17df76d  vmovaps [rsp+0xC0], xmm12
00007e4af17df776  vmovaps [rsp+0xD0], xmm13
00007e4af17df77f  vmovaps [rsp+0xE0], xmm15
00007e4af17df788  sub rsp, 0x30
00007e4af17df78c  movaps [rsp], xmm14
00007e4af17df791  movaps [rsp+0x10], xmm8
00007e4af17df797  movaps [rsp+0x20], xmm4
00007e4af17df79c  lea rdi, [rsp]
00007e4af17df7a0  mov esi, 0x00
00007e4af17df7a5  mov rax, 0x6256754A7530
00007e4af17df7af  call rax
00007e4af17df7b1  movaps xmm14, [rsp]
00007e4af17df7b6  add rsp, 0x30
00007e4af17df7ba  vmovaps xmm0, [rsp]
00007e4af17df7bf  vmovaps xmm1, [rsp+0x10]
00007e4af17df7c5  vmovaps xmm2, [rsp+0x20]
00007e4af17df7cb  vmovaps xmm3, [rsp+0x30]
00007e4af17df7d1  vmovaps xmm4, [rsp+0x40]
00007e4af17df7d7  vmovaps xmm5, [rsp+0x50]
00007e4af17df7dd  vmovaps xmm6, [rsp+0x60]
00007e4af17df7e3  vmovaps xmm7, [rsp+0x70]
00007e4af17df7e9  vmovaps xmm8, [rsp+0x80]
00007e4af17df7f2  vmovaps xmm9, [rsp+0x90]
00007e4af17df7fb  vmovaps xmm10, [rsp+0xA0]
00007e4af17df804  vmovaps xmm11, [rsp+0xB0]
00007e4af17df80d  vmovaps xmm12, [rsp+0xC0]
00007e4af17df816  vmovaps xmm13, [rsp+0xD0]
00007e4af17df81f  vmovaps xmm15, [rsp+0xE0]
00007e4af17df828  add rsp, 0xF0
00007e4af17df82f  pop r11
00007e4af17df831  pop r10
00007e4af17df833  pop r9
00007e4af17df835  pop r8
00007e4af17df837  pop rsi
00007e4af17df838  pop rdi
00007e4af17df839  pop rdx
00007e4af17df83a  pop rcx
00007e4af17df83b  pop rax
00007e4af17df83c  add rsp, 0x08
00007e4af17df840  jmp 0x00007E4AF17DC418
00007e4af17df845  sub rsp, 0x08
00007e4af17df849  push rax
00007e4af17df84a  push rcx
00007e4af17df84b  push rdx
00007e4af17df84c  push rdi
00007e4af17df84d  push rsi
00007e4af17df84e  push r8
00007e4af17df850  push r9
00007e4af17df852  push r10
00007e4af17df854  push r11
00007e4af17df856  sub rsp, 0xF0
00007e4af17df85d  vmovaps [rsp], xmm0
00007e4af17df862  vmovaps [rsp+0x10], xmm1
00007e4af17df868  vmovaps [rsp+0x20], xmm2
00007e4af17df86e  vmovaps [rsp+0x30], xmm3
00007e4af17df874  vmovaps [rsp+0x40], xmm5
00007e4af17df87a  vmovaps [rsp+0x50], xmm6
00007e4af17df880  vmovaps [rsp+0x60], xmm7
00007e4af17df886  vmovaps [rsp+0x70], xmm8
00007e4af17df88c  vmovaps [rsp+0x80], xmm9
00007e4af17df895  vmovaps [rsp+0x90], xmm10
00007e4af17df89e  vmovaps [rsp+0xA0], xmm11
00007e4af17df8a7  vmovaps [rsp+0xB0], xmm12
00007e4af17df8b0  vmovaps [rsp+0xC0], xmm13
00007e4af17df8b9  vmovaps [rsp+0xD0], xmm14
00007e4af17df8c2  vmovaps [rsp+0xE0], xmm15
00007e4af17df8cb  sub rsp, 0x30
00007e4af17df8cf  movaps [rsp], xmm4
00007e4af17df8d3  movaps [rsp+0x10], xmm13
00007e4af17df8d9  movaps [rsp+0x20], xmm8
00007e4af17df8df  lea rdi, [rsp]
00007e4af17df8e3  mov esi, 0x00
00007e4af17df8e8  mov rax, 0x6256754A7530
00007e4af17df8f2  call rax
00007e4af17df8f4  movaps xmm4, [rsp]
00007e4af17df8f8  add rsp, 0x30
00007e4af17df8fc  vmovaps xmm0, [rsp]
00007e4af17df901  vmovaps xmm1, [rsp+0x10]
00007e4af17df907  vmovaps xmm2, [rsp+0x20]
00007e4af17df90d  vmovaps xmm3, [rsp+0x30]
00007e4af17df913  vmovaps xmm5, [rsp+0x40]
00007e4af17df919  vmovaps xmm6, [rsp+0x50]
00007e4af17df91f  vmovaps xmm7, [rsp+0x60]
00007e4af17df925  vmovaps xmm8, [rsp+0x70]
00007e4af17df92b  vmovaps xmm9, [rsp+0x80]
00007e4af17df934  vmovaps xmm10, [rsp+0x90]
00007e4af17df93d  vmovaps xmm11, [rsp+0xA0]
00007e4af17df946  vmovaps xmm12, [rsp+0xB0]
00007e4af17df94f  vmovaps xmm13, [rsp+0xC0]
00007e4af17df958  vmovaps xmm14, [rsp+0xD0]
00007e4af17df961  vmovaps xmm15, [rsp+0xE0]
00007e4af17df96a  add rsp, 0xF0
00007e4af17df971  pop r11
00007e4af17df973  pop r10
00007e4af17df975  pop r9
00007e4af17df977  pop r8
00007e4af17df979  pop rsi
00007e4af17df97a  pop rdi
00007e4af17df97b  pop rdx
00007e4af17df97c  pop rcx
00007e4af17df97d  pop rax
00007e4af17df97e  add rsp, 0x08
00007e4af17df982  jmp 0x00007E4AF17DC43D
00007e4af17df987  sub rsp, 0x08
00007e4af17df98b  push rax
00007e4af17df98c  push rcx
00007e4af17df98d  push rdx
00007e4af17df98e  push rdi
00007e4af17df98f  push rsi
00007e4af17df990  push r8
00007e4af17df992  push r9
00007e4af17df994  push r10
00007e4af17df996  push r11
00007e4af17df998  sub rsp, 0xF0
00007e4af17df99f  vmovaps [rsp], xmm0
00007e4af17df9a4  vmovaps [rsp+0x10], xmm1
00007e4af17df9aa  vmovaps [rsp+0x20], xmm2
00007e4af17df9b0  vmovaps [rsp+0x30], xmm3
00007e4af17df9b6  vmovaps [rsp+0x40], xmm4
00007e4af17df9bc  vmovaps [rsp+0x50], xmm5
00007e4af17df9c2  vmovaps [rsp+0x60], xmm6
00007e4af17df9c8  vmovaps [rsp+0x70], xmm7
00007e4af17df9ce  vmovaps [rsp+0x80], xmm8
00007e4af17df9d7  vmovaps [rsp+0x90], xmm9
00007e4af17df9e0  vmovaps [rsp+0xA0], xmm10
00007e4af17df9e9  vmovaps [rsp+0xB0], xmm11
00007e4af17df9f2  vmovaps [rsp+0xC0], xmm12
00007e4af17df9fb  vmovaps [rsp+0xD0], xmm14
00007e4af17dfa04  vmovaps [rsp+0xE0], xmm15
00007e4af17dfa0d  sub rsp, 0x30
00007e4af17dfa11  movaps [rsp], xmm13
00007e4af17dfa16  movaps [rsp+0x10], xmm15
00007e4af17dfa1c  movaps [rsp+0x20], xmm9
00007e4af17dfa22  lea rdi, [rsp]
00007e4af17dfa26  mov esi, 0x00
00007e4af17dfa2b  mov rax, 0x6256754A7530
00007e4af17dfa35  call rax
00007e4af17dfa37  movaps xmm13, [rsp]
00007e4af17dfa3c  add rsp, 0x30
00007e4af17dfa40  vmovaps xmm0, [rsp]
00007e4af17dfa45  vmovaps xmm1, [rsp+0x10]
00007e4af17dfa4b  vmovaps xmm2, [rsp+0x20]
00007e4af17dfa51  vmovaps xmm3, [rsp+0x30]
00007e4af17dfa57  vmovaps xmm4, [rsp+0x40]
00007e4af17dfa5d  vmovaps xmm5, [rsp+0x50]
00007e4af17dfa63  vmovaps xmm6, [rsp+0x60]
00007e4af17dfa69  vmovaps xmm7, [rsp+0x70]
00007e4af17dfa6f  vmovaps xmm8, [rsp+0x80]
00007e4af17dfa78  vmovaps xmm9, [rsp+0x90]
00007e4af17dfa81  vmovaps xmm10, [rsp+0xA0]
00007e4af17dfa8a  vmovaps xmm11, [rsp+0xB0]
00007e4af17dfa93  vmovaps xmm12, [rsp+0xC0]
00007e4af17dfa9c  vmovaps xmm14, [rsp+0xD0]
00007e4af17dfaa5  vmovaps xmm15, [rsp+0xE0]
00007e4af17dfaae  add rsp, 0xF0
00007e4af17dfab5  pop r11
00007e4af17dfab7  pop r10
00007e4af17dfab9  pop r9
00007e4af17dfabb  pop r8
00007e4af17dfabd  pop rsi
00007e4af17dfabe  pop rdi
00007e4af17dfabf  pop rdx
00007e4af17dfac0  pop rcx
00007e4af17dfac1  pop rax
00007e4af17dfac2  add rsp, 0x08
00007e4af17dfac6  jmp 0x00007E4AF17DC458
00007e4af17dfacb  sub rsp, 0x08
00007e4af17dfacf  push rax
00007e4af17dfad0  push rcx
00007e4af17dfad1  push rdx
00007e4af17dfad2  push rdi
00007e4af17dfad3  push rsi
00007e4af17dfad4  push r8
00007e4af17dfad6  push r9
00007e4af17dfad8  push r10
00007e4af17dfada  push r11
00007e4af17dfadc  sub rsp, 0xF0
00007e4af17dfae3  vmovaps [rsp], xmm0
00007e4af17dfae8  vmovaps [rsp+0x10], xmm1
00007e4af17dfaee  vmovaps [rsp+0x20], xmm2
00007e4af17dfaf4  vmovaps [rsp+0x30], xmm3
00007e4af17dfafa  vmovaps [rsp+0x40], xmm4
00007e4af17dfb00  vmovaps [rsp+0x50], xmm5
00007e4af17dfb06  vmovaps [rsp+0x60], xmm6
00007e4af17dfb0c  vmovaps [rsp+0x70], xmm7
00007e4af17dfb12  vmovaps [rsp+0x80], xmm8
00007e4af17dfb1b  vmovaps [rsp+0x90], xmm9
00007e4af17dfb24  vmovaps [rsp+0xA0], xmm10
00007e4af17dfb2d  vmovaps [rsp+0xB0], xmm11
00007e4af17dfb36  vmovaps [rsp+0xC0], xmm12
00007e4af17dfb3f  vmovaps [rsp+0xD0], xmm13
00007e4af17dfb48  vmovaps [rsp+0xE0], xmm14
00007e4af17dfb51  sub rsp, 0x30
00007e4af17dfb55  movaps [rsp], xmm15
00007e4af17dfb5a  movaps [rsp+0x10], xmm1
00007e4af17dfb5f  movaps [rsp+0x20], xmm5
00007e4af17dfb64  lea rdi, [rsp]
00007e4af17dfb68  mov esi, 0x00
00007e4af17dfb6d  mov rax, 0x6256754A7530
00007e4af17dfb77  call rax
00007e4af17dfb79  movaps xmm15, [rsp]
00007e4af17dfb7e  add rsp, 0x30
00007e4af17dfb82  vmovaps xmm0, [rsp]
00007e4af17dfb87  vmovaps xmm1, [rsp+0x10]
00007e4af17dfb8d  vmovaps xmm2, [rsp+0x20]
00007e4af17dfb93  vmovaps xmm3, [rsp+0x30]
00007e4af17dfb99  vmovaps xmm4, [rsp+0x40]
00007e4af17dfb9f  vmovaps xmm5, [rsp+0x50]
00007e4af17dfba5  vmovaps xmm6, [rsp+0x60]
00007e4af17dfbab  vmovaps xmm7, [rsp+0x70]
00007e4af17dfbb1  vmovaps xmm8, [rsp+0x80]
00007e4af17dfbba  vmovaps xmm9, [rsp+0x90]
00007e4af17dfbc3  vmovaps xmm10, [rsp+0xA0]
00007e4af17dfbcc  vmovaps xmm11, [rsp+0xB0]
00007e4af17dfbd5  vmovaps xmm12, [rsp+0xC0]
00007e4af17dfbde  vmovaps xmm13, [rsp+0xD0]
00007e4af17dfbe7  vmovaps xmm14, [rsp+0xE0]
00007e4af17dfbf0  add rsp, 0xF0
00007e4af17dfbf7  pop r11
00007e4af17dfbf9  pop r10
00007e4af17dfbfb  pop r9
00007e4af17dfbfd  pop r8
00007e4af17dfbff  pop rsi
00007e4af17dfc00  pop rdi
00007e4af17dfc01  pop rdx
00007e4af17dfc02  pop rcx
00007e4af17dfc03  pop rax
00007e4af17dfc04  add rsp, 0x08
00007e4af17dfc08  jmp 0x00007E4AF17DC473
00007e4af17dfc0d  call 0x00007E4AF16B52F0
00007e4af17dfc12  jmp 0x00007E4AF17DC4CE
00007e4af17dfc17  sub rsp, 0x08
00007e4af17dfc1b  push rax
00007e4af17dfc1c  push rcx
00007e4af17dfc1d  push rdx
00007e4af17dfc1e  push rdi
00007e4af17dfc1f  push rsi
00007e4af17dfc20  push r8
00007e4af17dfc22  push r9
00007e4af17dfc24  push r10
00007e4af17dfc26  push r11
00007e4af17dfc28  sub rsp, 0xF0
00007e4af17dfc2f  vmovaps [rsp], xmm0
00007e4af17dfc34  vmovaps [rsp+0x10], xmm1
00007e4af17dfc3a  vmovaps [rsp+0x20], xmm2
00007e4af17dfc40  vmovaps [rsp+0x30], xmm3
00007e4af17dfc46  vmovaps [rsp+0x40], xmm4
00007e4af17dfc4c  vmovaps [rsp+0x50], xmm5
00007e4af17dfc52  vmovaps [rsp+0x60], xmm6
00007e4af17dfc58  vmovaps [rsp+0x70], xmm7
00007e4af17dfc5e  vmovaps [rsp+0x80], xmm8
00007e4af17dfc67  vmovaps [rsp+0x90], xmm10
00007e4af17dfc70  vmovaps [rsp+0xA0], xmm11
00007e4af17dfc79  vmovaps [rsp+0xB0], xmm12
00007e4af17dfc82  vmovaps [rsp+0xC0], xmm13
00007e4af17dfc8b  vmovaps [rsp+0xD0], xmm14
00007e4af17dfc94  vmovaps [rsp+0xE0], xmm15
00007e4af17dfc9d  sub rsp, 0x30
00007e4af17dfca1  movaps [rsp], xmm9
00007e4af17dfca6  movaps [rsp+0x10], xmm8
00007e4af17dfcac  movaps [rsp+0x20], xmm11
00007e4af17dfcb2  lea rdi, [rsp]
00007e4af17dfcb6  mov esi, 0x00
00007e4af17dfcbb  mov rax, 0x6256754A7530
00007e4af17dfcc5  call rax
00007e4af17dfcc7  movaps xmm9, [rsp]
00007e4af17dfccc  add rsp, 0x30
00007e4af17dfcd0  vmovaps xmm0, [rsp]
00007e4af17dfcd5  vmovaps xmm1, [rsp+0x10]
00007e4af17dfcdb  vmovaps xmm2, [rsp+0x20]
00007e4af17dfce1  vmovaps xmm3, [rsp+0x30]
00007e4af17dfce7  vmovaps xmm4, [rsp+0x40]
00007e4af17dfced  vmovaps xmm5, [rsp+0x50]
00007e4af17dfcf3  vmovaps xmm6, [rsp+0x60]
00007e4af17dfcf9  vmovaps xmm7, [rsp+0x70]
00007e4af17dfcff  vmovaps xmm8, [rsp+0x80]
00007e4af17dfd08  vmovaps xmm10, [rsp+0x90]
00007e4af17dfd11  vmovaps xmm11, [rsp+0xA0]
00007e4af17dfd1a  vmovaps xmm12, [rsp+0xB0]
00007e4af17dfd23  vmovaps xmm13, [rsp+0xC0]
00007e4af17dfd2c  vmovaps xmm14, [rsp+0xD0]
00007e4af17dfd35  vmovaps xmm15, [rsp+0xE0]
00007e4af17dfd3e  add rsp, 0xF0
00007e4af17dfd45  pop r11
00007e4af17dfd47  pop r10
00007e4af17dfd49  pop r9
00007e4af17dfd4b  pop r8
00007e4af17dfd4d  pop rsi
00007e4af17dfd4e  pop rdi
00007e4af17dfd4f  pop rdx
00007e4af17dfd50  pop rcx
00007e4af17dfd51  pop rax
00007e4af17dfd52  add rsp, 0x08
00007e4af17dfd56  jmp 0x00007E4AF17DC505
00007e4af17dfd5b  sub rsp, 0x08
00007e4af17dfd5f  push rax
00007e4af17dfd60  push rcx
00007e4af17dfd61  push rdx
00007e4af17dfd62  push rdi
00007e4af17dfd63  push rsi
00007e4af17dfd64  push r8
00007e4af17dfd66  push r9
00007e4af17dfd68  push r10
00007e4af17dfd6a  push r11
00007e4af17dfd6c  sub rsp, 0xF0
00007e4af17dfd73  vmovaps [rsp], xmm0
00007e4af17dfd78  vmovaps [rsp+0x10], xmm1
00007e4af17dfd7e  vmovaps [rsp+0x20], xmm2
00007e4af17dfd84  vmovaps [rsp+0x30], xmm3
00007e4af17dfd8a  vmovaps [rsp+0x40], xmm4
00007e4af17dfd90  vmovaps [rsp+0x50], xmm5
00007e4af17dfd96  vmovaps [rsp+0x60], xmm6
00007e4af17dfd9c  vmovaps [rsp+0x70], xmm7
00007e4af17dfda2  vmovaps [rsp+0x80], xmm8
00007e4af17dfdab  vmovaps [rsp+0x90], xmm9
00007e4af17dfdb4  vmovaps [rsp+0xA0], xmm10
00007e4af17dfdbd  vmovaps [rsp+0xB0], xmm12
00007e4af17dfdc6  vmovaps [rsp+0xC0], xmm13
00007e4af17dfdcf  vmovaps [rsp+0xD0], xmm14
00007e4af17dfdd8  vmovaps [rsp+0xE0], xmm15
00007e4af17dfde1  sub rsp, 0x30
00007e4af17dfde5  movaps [rsp], xmm11
00007e4af17dfdea  movaps [rsp+0x10], xmm10
00007e4af17dfdf0  movaps [rsp+0x20], xmm6
00007e4af17dfdf5  lea rdi, [rsp]
00007e4af17dfdf9  mov esi, 0x00
00007e4af17dfdfe  mov rax, 0x6256754A7530
00007e4af17dfe08  call rax
00007e4af17dfe0a  movaps xmm11, [rsp]
00007e4af17dfe0f  add rsp, 0x30
00007e4af17dfe13  vmovaps xmm0, [rsp]
00007e4af17dfe18  vmovaps xmm1, [rsp+0x10]
00007e4af17dfe1e  vmovaps xmm2, [rsp+0x20]
00007e4af17dfe24  vmovaps xmm3, [rsp+0x30]
00007e4af17dfe2a  vmovaps xmm4, [rsp+0x40]
00007e4af17dfe30  vmovaps xmm5, [rsp+0x50]
00007e4af17dfe36  vmovaps xmm6, [rsp+0x60]
00007e4af17dfe3c  vmovaps xmm7, [rsp+0x70]
00007e4af17dfe42  vmovaps xmm8, [rsp+0x80]
00007e4af17dfe4b  vmovaps xmm9, [rsp+0x90]
00007e4af17dfe54  vmovaps xmm10, [rsp+0xA0]
00007e4af17dfe5d  vmovaps xmm12, [rsp+0xB0]
00007e4af17dfe66  vmovaps xmm13, [rsp+0xC0]
00007e4af17dfe6f  vmovaps xmm14, [rsp+0xD0]
00007e4af17dfe78  vmovaps xmm15, [rsp+0xE0]
00007e4af17dfe81  add rsp, 0xF0
00007e4af17dfe88  pop r11
00007e4af17dfe8a  pop r10
00007e4af17dfe8c  pop r9
00007e4af17dfe8e  pop r8
00007e4af17dfe90  pop rsi
00007e4af17dfe91  pop rdi
00007e4af17dfe92  pop rdx
00007e4af17dfe93  pop rcx
00007e4af17dfe94  pop rax
00007e4af17dfe95  add rsp, 0x08
00007e4af17dfe99  jmp 0x00007E4AF17DC520
00007e4af17dfe9e  sub rsp, 0x08
00007e4af17dfea2  push rax
00007e4af17dfea3  push rcx
00007e4af17dfea4  push rdx
00007e4af17dfea5  push rdi
00007e4af17dfea6  push rsi
00007e4af17dfea7  push r8
00007e4af17dfea9  push r9
00007e4af17dfeab  push r10
00007e4af17dfead  push r11
00007e4af17dfeaf  sub rsp, 0xF0
00007e4af17dfeb6  vmovaps [rsp], xmm0
00007e4af17dfebb  vmovaps [rsp+0x10], xmm1
00007e4af17dfec1  vmovaps [rsp+0x20], xmm2
00007e4af17dfec7  vmovaps [rsp+0x30], xmm3
00007e4af17dfecd  vmovaps [rsp+0x40], xmm4
00007e4af17dfed3  vmovaps [rsp+0x50], xmm5
00007e4af17dfed9  vmovaps [rsp+0x60], xmm6
00007e4af17dfedf  vmovaps [rsp+0x70], xmm7
00007e4af17dfee5  vmovaps [rsp+0x80], xmm8
00007e4af17dfeee  vmovaps [rsp+0x90], xmm9
00007e4af17dfef7  vmovaps [rsp+0xA0], xmm11
00007e4af17dff00  vmovaps [rsp+0xB0], xmm12
00007e4af17dff09  vmovaps [rsp+0xC0], xmm13
00007e4af17dff12  vmovaps [rsp+0xD0], xmm14
00007e4af17dff1b  vmovaps [rsp+0xE0], xmm15
00007e4af17dff24  sub rsp, 0x30
00007e4af17dff28  movaps [rsp], xmm10
00007e4af17dff2d  movaps [rsp+0x10], xmm14
00007e4af17dff33  movaps [rsp+0x20], xmm4
00007e4af17dff38  lea rdi, [rsp]
00007e4af17dff3c  mov esi, 0x00
00007e4af17dff41  mov rax, 0x6256754A7530
00007e4af17dff4b  call rax
00007e4af17dff4d  movaps xmm10, [rsp]
00007e4af17dff52  add rsp, 0x30
00007e4af17dff56  vmovaps xmm0, [rsp]
00007e4af17dff5b  vmovaps xmm1, [rsp+0x10]
00007e4af17dff61  vmovaps xmm2, [rsp+0x20]
00007e4af17dff67  vmovaps xmm3, [rsp+0x30]
00007e4af17dff6d  vmovaps xmm4, [rsp+0x40]
00007e4af17dff73  vmovaps xmm5, [rsp+0x50]
00007e4af17dff79  vmovaps xmm6, [rsp+0x60]
00007e4af17dff7f  vmovaps xmm7, [rsp+0x70]
00007e4af17dff85  vmovaps xmm8, [rsp+0x80]
00007e4af17dff8e  vmovaps xmm9, [rsp+0x90]
00007e4af17dff97  vmovaps xmm11, [rsp+0xA0]
00007e4af17dffa0  vmovaps xmm12, [rsp+0xB0]
00007e4af17dffa9  vmovaps xmm13, [rsp+0xC0]
00007e4af17dffb2  vmovaps xmm14, [rsp+0xD0]
00007e4af17dffbb  vmovaps xmm15, [rsp+0xE0]
00007e4af17dffc4  add rsp, 0xF0
00007e4af17dffcb  pop r11
00007e4af17dffcd  pop r10
00007e4af17dffcf  pop r9
00007e4af17dffd1  pop r8
00007e4af17dffd3  pop rsi
00007e4af17dffd4  pop rdi
00007e4af17dffd5  pop rdx
00007e4af17dffd6  pop rcx
00007e4af17dffd7  pop rax
00007e4af17dffd8  add rsp, 0x08
00007e4af17dffdc  jmp 0x00007E4AF17DC53B
00007e4af17dffe1  sub rsp, 0x08
00007e4af17dffe5  push rax
00007e4af17dffe6  push rcx
00007e4af17dffe7  push rdx
00007e4af17dffe8  push rdi
00007e4af17dffe9  push rsi
00007e4af17dffea  push r8
00007e4af17dffec  push r9
00007e4af17dffee  push r10
00007e4af17dfff0  push r11
00007e4af17dfff2  sub rsp, 0xF0
00007e4af17dfff9  vmovaps [rsp], xmm0
00007e4af17dfffe  vmovaps [rsp+0x10], xmm1
00007e4af17e0004  vmovaps [rsp+0x20], xmm2
00007e4af17e000a  vmovaps [rsp+0x30], xmm3
00007e4af17e0010  vmovaps [rsp+0x40], xmm4
00007e4af17e0016  vmovaps [rsp+0x50], xmm5
00007e4af17e001c  vmovaps [rsp+0x60], xmm6
00007e4af17e0022  vmovaps [rsp+0x70], xmm7
00007e4af17e0028  vmovaps [rsp+0x80], xmm9
00007e4af17e0031  vmovaps [rsp+0x90], xmm10
00007e4af17e003a  vmovaps [rsp+0xA0], xmm11
00007e4af17e0043  vmovaps [rsp+0xB0], xmm12
00007e4af17e004c  vmovaps [rsp+0xC0], xmm13
00007e4af17e0055  vmovaps [rsp+0xD0], xmm14
00007e4af17e005e  vmovaps [rsp+0xE0], xmm15
00007e4af17e0067  sub rsp, 0x30
00007e4af17e006b  movaps [rsp], xmm8
00007e4af17e0070  movaps [rsp+0x10], xmm1
00007e4af17e0075  movaps [rsp+0x20], xmm14
00007e4af17e007b  lea rdi, [rsp]
00007e4af17e007f  mov esi, 0x00
00007e4af17e0084  mov rax, 0x6256754A7530
00007e4af17e008e  call rax
00007e4af17e0090  movaps xmm8, [rsp]
00007e4af17e0095  add rsp, 0x30
00007e4af17e0099  vmovaps xmm0, [rsp]
00007e4af17e009e  vmovaps xmm1, [rsp+0x10]
00007e4af17e00a4  vmovaps xmm2, [rsp+0x20]
00007e4af17e00aa  vmovaps xmm3, [rsp+0x30]
00007e4af17e00b0  vmovaps xmm4, [rsp+0x40]
00007e4af17e00b6  vmovaps xmm5, [rsp+0x50]
00007e4af17e00bc  vmovaps xmm6, [rsp+0x60]
00007e4af17e00c2  vmovaps xmm7, [rsp+0x70]
00007e4af17e00c8  vmovaps xmm9, [rsp+0x80]
00007e4af17e00d1  vmovaps xmm10, [rsp+0x90]
00007e4af17e00da  vmovaps xmm11, [rsp+0xA0]
00007e4af17e00e3  vmovaps xmm12, [rsp+0xB0]
00007e4af17e00ec  vmovaps xmm13, [rsp+0xC0]
00007e4af17e00f5  vmovaps xmm14, [rsp+0xD0]
00007e4af17e00fe  vmovaps xmm15, [rsp+0xE0]
00007e4af17e0107  add rsp, 0xF0
00007e4af17e010e  pop r11
00007e4af17e0110  pop r10
00007e4af17e0112  pop r9
00007e4af17e0114  pop r8
00007e4af17e0116  pop rsi
00007e4af17e0117  pop rdi
00007e4af17e0118  pop rdx
00007e4af17e0119  pop rcx
00007e4af17e011a  pop rax
00007e4af17e011b  add rsp, 0x08
00007e4af17e011f  jmp 0x00007E4AF17DC561
00007e4af17e0124  sub rsp, 0x08
00007e4af17e0128  push rax
00007e4af17e0129  push rcx
00007e4af17e012a  push rdx
00007e4af17e012b  push rdi
00007e4af17e012c  push rsi
00007e4af17e012d  push r8
00007e4af17e012f  push r9
00007e4af17e0131  push r10
00007e4af17e0133  push r11
00007e4af17e0135  sub rsp, 0xF0
00007e4af17e013c  vmovaps [rsp], xmm0
00007e4af17e0141  vmovaps [rsp+0x10], xmm1
00007e4af17e0147  vmovaps [rsp+0x20], xmm2
00007e4af17e014d  vmovaps [rsp+0x30], xmm3
00007e4af17e0153  vmovaps [rsp+0x40], xmm4
00007e4af17e0159  vmovaps [rsp+0x50], xmm5
00007e4af17e015f  vmovaps [rsp+0x60], xmm7
00007e4af17e0165  vmovaps [rsp+0x70], xmm8
00007e4af17e016b  vmovaps [rsp+0x80], xmm9
00007e4af17e0174  vmovaps [rsp+0x90], xmm10
00007e4af17e017d  vmovaps [rsp+0xA0], xmm11
00007e4af17e0186  vmovaps [rsp+0xB0], xmm12
00007e4af17e018f  vmovaps [rsp+0xC0], xmm13
00007e4af17e0198  vmovaps [rsp+0xD0], xmm14
00007e4af17e01a1  vmovaps [rsp+0xE0], xmm15
00007e4af17e01aa  sub rsp, 0x30
00007e4af17e01ae  movaps [rsp], xmm6
00007e4af17e01b2  movaps [rsp+0x10], xmm1
00007e4af17e01b7  movaps [rsp+0x20], xmm14
00007e4af17e01bd  lea rdi, [rsp]
00007e4af17e01c1  mov esi, 0x00
00007e4af17e01c6  mov rax, 0x6256754A7530
00007e4af17e01d0  call rax
00007e4af17e01d2  movaps xmm6, [rsp]
00007e4af17e01d6  add rsp, 0x30
00007e4af17e01da  vmovaps xmm0, [rsp]
00007e4af17e01df  vmovaps xmm1, [rsp+0x10]
00007e4af17e01e5  vmovaps xmm2, [rsp+0x20]
00007e4af17e01eb  vmovaps xmm3, [rsp+0x30]
00007e4af17e01f1  vmovaps xmm4, [rsp+0x40]
00007e4af17e01f7  vmovaps xmm5, [rsp+0x50]
00007e4af17e01fd  vmovaps xmm7, [rsp+0x60]
00007e4af17e0203  vmovaps xmm8, [rsp+0x70]
00007e4af17e0209  vmovaps xmm9, [rsp+0x80]
00007e4af17e0212  vmovaps xmm10, [rsp+0x90]
00007e4af17e021b  vmovaps xmm11, [rsp+0xA0]
00007e4af17e0224  vmovaps xmm12, [rsp+0xB0]
00007e4af17e022d  vmovaps xmm13, [rsp+0xC0]
00007e4af17e0236  vmovaps xmm14, [rsp+0xD0]
00007e4af17e023f  vmovaps xmm15, [rsp+0xE0]
00007e4af17e0248  add rsp, 0xF0
00007e4af17e024f  pop r11
00007e4af17e0251  pop r10
00007e4af17e0253  pop r9
00007e4af17e0255  pop r8
00007e4af17e0257  pop rsi
00007e4af17e0258  pop rdi
00007e4af17e0259  pop rdx
00007e4af17e025a  pop rcx
00007e4af17e025b  pop rax
00007e4af17e025c  add rsp, 0x08
00007e4af17e0260  jmp 0x00007E4AF17DC58D
00007e4af17e0265  sub rsp, 0x08
00007e4af17e0269  push rax
00007e4af17e026a  push rcx
00007e4af17e026b  push rdx
00007e4af17e026c  push rdi
00007e4af17e026d  push rsi
00007e4af17e026e  push r8
00007e4af17e0270  push r9
00007e4af17e0272  push r10
00007e4af17e0274  push r11
00007e4af17e0276  sub rsp, 0xF0
00007e4af17e027d  vmovaps [rsp], xmm0
00007e4af17e0282  vmovaps [rsp+0x10], xmm1
00007e4af17e0288  vmovaps [rsp+0x20], xmm2
00007e4af17e028e  vmovaps [rsp+0x30], xmm3
00007e4af17e0294  vmovaps [rsp+0x40], xmm4
00007e4af17e029a  vmovaps [rsp+0x50], xmm5
00007e4af17e02a0  vmovaps [rsp+0x60], xmm6
00007e4af17e02a6  vmovaps [rsp+0x70], xmm7
00007e4af17e02ac  vmovaps [rsp+0x80], xmm8
00007e4af17e02b5  vmovaps [rsp+0x90], xmm9
00007e4af17e02be  vmovaps [rsp+0xA0], xmm10
00007e4af17e02c7  vmovaps [rsp+0xB0], xmm11
00007e4af17e02d0  vmovaps [rsp+0xC0], xmm12
00007e4af17e02d9  vmovaps [rsp+0xD0], xmm13
00007e4af17e02e2  vmovaps [rsp+0xE0], xmm15
00007e4af17e02eb  sub rsp, 0x30
00007e4af17e02ef  movaps [rsp], xmm14
00007e4af17e02f4  movaps [rsp+0x10], xmm12
00007e4af17e02fa  movaps [rsp+0x20], xmm1
00007e4af17e02ff  lea rdi, [rsp]
00007e4af17e0303  mov esi, 0x00
00007e4af17e0308  mov rax, 0x6256754A7530
00007e4af17e0312  call rax
00007e4af17e0314  movaps xmm14, [rsp]
00007e4af17e0319  add rsp, 0x30
00007e4af17e031d  vmovaps xmm0, [rsp]
00007e4af17e0322  vmovaps xmm1, [rsp+0x10]
00007e4af17e0328  vmovaps xmm2, [rsp+0x20]
00007e4af17e032e  vmovaps xmm3, [rsp+0x30]
00007e4af17e0334  vmovaps xmm4, [rsp+0x40]
00007e4af17e033a  vmovaps xmm5, [rsp+0x50]
00007e4af17e0340  vmovaps xmm6, [rsp+0x60]
00007e4af17e0346  vmovaps xmm7, [rsp+0x70]
00007e4af17e034c  vmovaps xmm8, [rsp+0x80]
00007e4af17e0355  vmovaps xmm9, [rsp+0x90]
00007e4af17e035e  vmovaps xmm10, [rsp+0xA0]
00007e4af17e0367  vmovaps xmm11, [rsp+0xB0]
00007e4af17e0370  vmovaps xmm12, [rsp+0xC0]
00007e4af17e0379  vmovaps xmm13, [rsp+0xD0]
00007e4af17e0382  vmovaps xmm15, [rsp+0xE0]
00007e4af17e038b  add rsp, 0xF0
00007e4af17e0392  pop r11
00007e4af17e0394  pop r10
00007e4af17e0396  pop r9
00007e4af17e0398  pop r8
00007e4af17e039a  pop rsi
00007e4af17e039b  pop rdi
00007e4af17e039c  pop rdx
00007e4af17e039d  pop rcx
00007e4af17e039e  pop rax
00007e4af17e039f  add rsp, 0x08
00007e4af17e03a3  jmp 0x00007E4AF17DC5B3
00007e4af17e03a8  sub rsp, 0x08
00007e4af17e03ac  push rax
00007e4af17e03ad  push rcx
00007e4af17e03ae  push rdx
00007e4af17e03af  push rdi
00007e4af17e03b0  push rsi
00007e4af17e03b1  push r8
00007e4af17e03b3  push r9
00007e4af17e03b5  push r10
00007e4af17e03b7  push r11
00007e4af17e03b9  sub rsp, 0xF0
00007e4af17e03c0  vmovaps [rsp], xmm0
00007e4af17e03c5  vmovaps [rsp+0x10], xmm2
00007e4af17e03cb  vmovaps [rsp+0x20], xmm3
00007e4af17e03d1  vmovaps [rsp+0x30], xmm4
00007e4af17e03d7  vmovaps [rsp+0x40], xmm5
00007e4af17e03dd  vmovaps [rsp+0x50], xmm6
00007e4af17e03e3  vmovaps [rsp+0x60], xmm7
00007e4af17e03e9  vmovaps [rsp+0x70], xmm8
00007e4af17e03ef  vmovaps [rsp+0x80], xmm9
00007e4af17e03f8  vmovaps [rsp+0x90], xmm10
00007e4af17e0401  vmovaps [rsp+0xA0], xmm11
00007e4af17e040a  vmovaps [rsp+0xB0], xmm12
00007e4af17e0413  vmovaps [rsp+0xC0], xmm13
00007e4af17e041c  vmovaps [rsp+0xD0], xmm14
00007e4af17e0425  vmovaps [rsp+0xE0], xmm15
00007e4af17e042e  sub rsp, 0x30
00007e4af17e0432  movaps [rsp], xmm1
00007e4af17e0436  movaps [rsp+0x10], xmm13
00007e4af17e043c  movaps [rsp+0x20], xmm9
00007e4af17e0442  lea rdi, [rsp]
00007e4af17e0446  mov esi, 0x00
00007e4af17e044b  mov rax, 0x6256754A7530
00007e4af17e0455  call rax
00007e4af17e0457  movaps xmm1, [rsp]
00007e4af17e045b  add rsp, 0x30
00007e4af17e045f  vmovaps xmm0, [rsp]
00007e4af17e0464  vmovaps xmm2, [rsp+0x10]
00007e4af17e046a  vmovaps xmm3, [rsp+0x20]
00007e4af17e0470  vmovaps xmm4, [rsp+0x30]
00007e4af17e0476  vmovaps xmm5, [rsp+0x40]
00007e4af17e047c  vmovaps xmm6, [rsp+0x50]
00007e4af17e0482  vmovaps xmm7, [rsp+0x60]
00007e4af17e0488  vmovaps xmm8, [rsp+0x70]
00007e4af17e048e  vmovaps xmm9, [rsp+0x80]
00007e4af17e0497  vmovaps xmm10, [rsp+0x90]
00007e4af17e04a0  vmovaps xmm11, [rsp+0xA0]
00007e4af17e04a9  vmovaps xmm12, [rsp+0xB0]
00007e4af17e04b2  vmovaps xmm13, [rsp+0xC0]
00007e4af17e04bb  vmovaps xmm14, [rsp+0xD0]
00007e4af17e04c4  vmovaps xmm15, [rsp+0xE0]
00007e4af17e04cd  add rsp, 0xF0
00007e4af17e04d4  pop r11
00007e4af17e04d6  pop r10
00007e4af17e04d8  pop r9
00007e4af17e04da  pop r8
00007e4af17e04dc  pop rsi
00007e4af17e04dd  pop rdi
00007e4af17e04de  pop rdx
00007e4af17e04df  pop rcx
00007e4af17e04e0  pop rax
00007e4af17e04e1  add rsp, 0x08
00007e4af17e04e5  jmp 0x00007E4AF17DC5CD
00007e4af17e04ea  sub rsp, 0x08
00007e4af17e04ee  push rax
00007e4af17e04ef  push rcx
00007e4af17e04f0  push rdx
00007e4af17e04f1  push rdi
00007e4af17e04f2  push rsi
00007e4af17e04f3  push r8
00007e4af17e04f5  push r9
00007e4af17e04f7  push r10
00007e4af17e04f9  push r11
00007e4af17e04fb  sub rsp, 0xF0
00007e4af17e0502  vmovaps [rsp], xmm0
00007e4af17e0507  vmovaps [rsp+0x10], xmm1
00007e4af17e050d  vmovaps [rsp+0x20], xmm2
00007e4af17e0513  vmovaps [rsp+0x30], xmm3
00007e4af17e0519  vmovaps [rsp+0x40], xmm4
00007e4af17e051f  vmovaps [rsp+0x50], xmm5
00007e4af17e0525  vmovaps [rsp+0x60], xmm6
00007e4af17e052b  vmovaps [rsp+0x70], xmm7
00007e4af17e0531  vmovaps [rsp+0x80], xmm8
00007e4af17e053a  vmovaps [rsp+0x90], xmm9
00007e4af17e0543  vmovaps [rsp+0xA0], xmm10
00007e4af17e054c  vmovaps [rsp+0xB0], xmm11
00007e4af17e0555  vmovaps [rsp+0xC0], xmm13
00007e4af17e055e  vmovaps [rsp+0xD0], xmm14
00007e4af17e0567  vmovaps [rsp+0xE0], xmm15
00007e4af17e0570  sub rsp, 0x30
00007e4af17e0574  movaps [rsp], xmm12
00007e4af17e0579  movaps [rsp+0x10], xmm7
00007e4af17e057e  movaps [rsp+0x20], xmm13
00007e4af17e0584  lea rdi, [rsp]
00007e4af17e0588  mov esi, 0x00
00007e4af17e058d  mov rax, 0x6256754A7530
00007e4af17e0597  call rax
00007e4af17e0599  movaps xmm12, [rsp]
00007e4af17e059e  add rsp, 0x30
00007e4af17e05a2  vmovaps xmm0, [rsp]
00007e4af17e05a7  vmovaps xmm1, [rsp+0x10]
00007e4af17e05ad  vmovaps xmm2, [rsp+0x20]
00007e4af17e05b3  vmovaps xmm3, [rsp+0x30]
00007e4af17e05b9  vmovaps xmm4, [rsp+0x40]
00007e4af17e05bf  vmovaps xmm5, [rsp+0x50]
00007e4af17e05c5  vmovaps xmm6, [rsp+0x60]
00007e4af17e05cb  vmovaps xmm7, [rsp+0x70]
00007e4af17e05d1  vmovaps xmm8, [rsp+0x80]
00007e4af17e05da  vmovaps xmm9, [rsp+0x90]
00007e4af17e05e3  vmovaps xmm10, [rsp+0xA0]
00007e4af17e05ec  vmovaps xmm11, [rsp+0xB0]
00007e4af17e05f5  vmovaps xmm13, [rsp+0xC0]
00007e4af17e05fe  vmovaps xmm14, [rsp+0xD0]
00007e4af17e0607  vmovaps xmm15, [rsp+0xE0]
00007e4af17e0610  add rsp, 0xF0
00007e4af17e0617  pop r11
00007e4af17e0619  pop r10
00007e4af17e061b  pop r9
00007e4af17e061d  pop r8
00007e4af17e061f  pop rsi
00007e4af17e0620  pop rdi
00007e4af17e0621  pop rdx
00007e4af17e0622  pop rcx
00007e4af17e0623  pop rax
00007e4af17e0624  add rsp, 0x08
00007e4af17e0628  jmp 0x00007E4AF17DC5F4
00007e4af17e062d  sub rsp, 0x08
00007e4af17e0631  push rax
00007e4af17e0632  push rcx
00007e4af17e0633  push rdx
00007e4af17e0634  push rdi
00007e4af17e0635  push rsi
00007e4af17e0636  push r8
00007e4af17e0638  push r9
00007e4af17e063a  push r10
00007e4af17e063c  push r11
00007e4af17e063e  sub rsp, 0xF0
00007e4af17e0645  vmovaps [rsp], xmm0
00007e4af17e064a  vmovaps [rsp+0x10], xmm1
00007e4af17e0650  vmovaps [rsp+0x20], xmm2
00007e4af17e0656  vmovaps [rsp+0x30], xmm3
00007e4af17e065c  vmovaps [rsp+0x40], xmm4
00007e4af17e0662  vmovaps [rsp+0x50], xmm5
00007e4af17e0668  vmovaps [rsp+0x60], xmm6
00007e4af17e066e  vmovaps [rsp+0x70], xmm7
00007e4af17e0674  vmovaps [rsp+0x80], xmm8
00007e4af17e067d  vmovaps [rsp+0x90], xmm9
00007e4af17e0686  vmovaps [rsp+0xA0], xmm10
00007e4af17e068f  vmovaps [rsp+0xB0], xmm11
00007e4af17e0698  vmovaps [rsp+0xC0], xmm12
00007e4af17e06a1  vmovaps [rsp+0xD0], xmm14
00007e4af17e06aa  vmovaps [rsp+0xE0], xmm15
00007e4af17e06b3  sub rsp, 0x30
00007e4af17e06b7  movaps [rsp], xmm13
00007e4af17e06bc  movaps [rsp+0x10], xmm15
00007e4af17e06c2  movaps [rsp+0x20], xmm8
00007e4af17e06c8  lea rdi, [rsp]
00007e4af17e06cc  mov esi, 0x00
00007e4af17e06d1  mov rax, 0x6256754A7530
00007e4af17e06db  call rax
00007e4af17e06dd  movaps xmm13, [rsp]
00007e4af17e06e2  add rsp, 0x30
00007e4af17e06e6  vmovaps xmm0, [rsp]
00007e4af17e06eb  vmovaps xmm1, [rsp+0x10]
00007e4af17e06f1  vmovaps xmm2, [rsp+0x20]
00007e4af17e06f7  vmovaps xmm3, [rsp+0x30]
00007e4af17e06fd  vmovaps xmm4, [rsp+0x40]
00007e4af17e0703  vmovaps xmm5, [rsp+0x50]
00007e4af17e0709  vmovaps xmm6, [rsp+0x60]
00007e4af17e070f  vmovaps xmm7, [rsp+0x70]
00007e4af17e0715  vmovaps xmm8, [rsp+0x80]
00007e4af17e071e  vmovaps xmm9, [rsp+0x90]
00007e4af17e0727  vmovaps xmm10, [rsp+0xA0]
00007e4af17e0730  vmovaps xmm11, [rsp+0xB0]
00007e4af17e0739  vmovaps xmm12, [rsp+0xC0]
00007e4af17e0742  vmovaps xmm14, [rsp+0xD0]
00007e4af17e074b  vmovaps xmm15, [rsp+0xE0]
00007e4af17e0754  add rsp, 0xF0
00007e4af17e075b  pop r11
00007e4af17e075d  pop r10
00007e4af17e075f  pop r9
00007e4af17e0761  pop r8
00007e4af17e0763  pop rsi
00007e4af17e0764  pop rdi
00007e4af17e0765  pop rdx
00007e4af17e0766  pop rcx
00007e4af17e0767  pop rax
00007e4af17e0768  add rsp, 0x08
00007e4af17e076c  jmp 0x00007E4AF17DC60F
00007e4af17e0771  sub rsp, 0x08
00007e4af17e0775  push rax
00007e4af17e0776  push rcx
00007e4af17e0777  push rdx
00007e4af17e0778  push rdi
00007e4af17e0779  push rsi
00007e4af17e077a  push r8
00007e4af17e077c  push r9
00007e4af17e077e  push r10
00007e4af17e0780  push r11
00007e4af17e0782  sub rsp, 0xF0
00007e4af17e0789  vmovaps [rsp], xmm0
00007e4af17e078e  vmovaps [rsp+0x10], xmm1
00007e4af17e0794  vmovaps [rsp+0x20], xmm2
00007e4af17e079a  vmovaps [rsp+0x30], xmm3
00007e4af17e07a0  vmovaps [rsp+0x40], xmm4
00007e4af17e07a6  vmovaps [rsp+0x50], xmm5
00007e4af17e07ac  vmovaps [rsp+0x60], xmm6
00007e4af17e07b2  vmovaps [rsp+0x70], xmm7
00007e4af17e07b8  vmovaps [rsp+0x80], xmm9
00007e4af17e07c1  vmovaps [rsp+0x90], xmm10
00007e4af17e07ca  vmovaps [rsp+0xA0], xmm11
00007e4af17e07d3  vmovaps [rsp+0xB0], xmm12
00007e4af17e07dc  vmovaps [rsp+0xC0], xmm13
00007e4af17e07e5  vmovaps [rsp+0xD0], xmm14
00007e4af17e07ee  vmovaps [rsp+0xE0], xmm15
00007e4af17e07f7  sub rsp, 0x30
00007e4af17e07fb  movaps [rsp], xmm8
00007e4af17e0800  movaps [rsp+0x10], xmm15
00007e4af17e0806  movaps [rsp+0x20], xmm9
00007e4af17e080c  lea rdi, [rsp]
00007e4af17e0810  mov esi, 0x00
00007e4af17e0815  mov rax, 0x6256754A7530
00007e4af17e081f  call rax
00007e4af17e0821  movaps xmm8, [rsp]
00007e4af17e0826  add rsp, 0x30
00007e4af17e082a  vmovaps xmm0, [rsp]
00007e4af17e082f  vmovaps xmm1, [rsp+0x10]
00007e4af17e0835  vmovaps xmm2, [rsp+0x20]
00007e4af17e083b  vmovaps xmm3, [rsp+0x30]
00007e4af17e0841  vmovaps xmm4, [rsp+0x40]
00007e4af17e0847  vmovaps xmm5, [rsp+0x50]
00007e4af17e084d  vmovaps xmm6, [rsp+0x60]
00007e4af17e0853  vmovaps xmm7, [rsp+0x70]
00007e4af17e0859  vmovaps xmm9, [rsp+0x80]
00007e4af17e0862  vmovaps xmm10, [rsp+0x90]
00007e4af17e086b  vmovaps xmm11, [rsp+0xA0]
00007e4af17e0874  vmovaps xmm12, [rsp+0xB0]
00007e4af17e087d  vmovaps xmm13, [rsp+0xC0]
00007e4af17e0886  vmovaps xmm14, [rsp+0xD0]
00007e4af17e088f  vmovaps xmm15, [rsp+0xE0]
00007e4af17e0898  add rsp, 0xF0
00007e4af17e089f  pop r11
00007e4af17e08a1  pop r10
00007e4af17e08a3  pop r9
00007e4af17e08a5  pop r8
00007e4af17e08a7  pop rsi
00007e4af17e08a8  pop rdi
00007e4af17e08a9  pop rdx
00007e4af17e08aa  pop rcx
00007e4af17e08ab  pop rax
00007e4af17e08ac  add rsp, 0x08
00007e4af17e08b0  jmp 0x00007E4AF17DC63D
00007e4af17e08b5  sub rsp, 0x08
00007e4af17e08b9  push rax
00007e4af17e08ba  push rcx
00007e4af17e08bb  push rdx
00007e4af17e08bc  push rdi
00007e4af17e08bd  push rsi
00007e4af17e08be  push r8
00007e4af17e08c0  push r9
00007e4af17e08c2  push r10
00007e4af17e08c4  push r11
00007e4af17e08c6  sub rsp, 0xF0
00007e4af17e08cd  vmovaps [rsp], xmm0
00007e4af17e08d2  vmovaps [rsp+0x10], xmm1
00007e4af17e08d8  vmovaps [rsp+0x20], xmm2
00007e4af17e08de  vmovaps [rsp+0x30], xmm3
00007e4af17e08e4  vmovaps [rsp+0x40], xmm4
00007e4af17e08ea  vmovaps [rsp+0x50], xmm5
00007e4af17e08f0  vmovaps [rsp+0x60], xmm6
00007e4af17e08f6  vmovaps [rsp+0x70], xmm7
00007e4af17e08fc  vmovaps [rsp+0x80], xmm8
00007e4af17e0905  vmovaps [rsp+0x90], xmm9
00007e4af17e090e  vmovaps [rsp+0xA0], xmm10
00007e4af17e0917  vmovaps [rsp+0xB0], xmm11
00007e4af17e0920  vmovaps [rsp+0xC0], xmm12
00007e4af17e0929  vmovaps [rsp+0xD0], xmm13
00007e4af17e0932  vmovaps [rsp+0xE0], xmm14
00007e4af17e093b  sub rsp, 0x30
00007e4af17e093f  movaps [rsp], xmm15
00007e4af17e0944  movaps [rsp+0x10], xmm11
00007e4af17e094a  movaps [rsp+0x20], xmm6
00007e4af17e094f  lea rdi, [rsp]
00007e4af17e0953  mov esi, 0x00
00007e4af17e0958  mov rax, 0x6256754A7530
00007e4af17e0962  call rax
00007e4af17e0964  movaps xmm15, [rsp]
00007e4af17e0969  add rsp, 0x30
00007e4af17e096d  vmovaps xmm0, [rsp]
00007e4af17e0972  vmovaps xmm1, [rsp+0x10]
00007e4af17e0978  vmovaps xmm2, [rsp+0x20]
00007e4af17e097e  vmovaps xmm3, [rsp+0x30]
00007e4af17e0984  vmovaps xmm4, [rsp+0x40]
00007e4af17e098a  vmovaps xmm5, [rsp+0x50]
00007e4af17e0990  vmovaps xmm6, [rsp+0x60]
00007e4af17e0996  vmovaps xmm7, [rsp+0x70]
00007e4af17e099c  vmovaps xmm8, [rsp+0x80]
00007e4af17e09a5  vmovaps xmm9, [rsp+0x90]
00007e4af17e09ae  vmovaps xmm10, [rsp+0xA0]
00007e4af17e09b7  vmovaps xmm11, [rsp+0xB0]
00007e4af17e09c0  vmovaps xmm12, [rsp+0xC0]
00007e4af17e09c9  vmovaps xmm13, [rsp+0xD0]
00007e4af17e09d2  vmovaps xmm14, [rsp+0xE0]
00007e4af17e09db  add rsp, 0xF0
00007e4af17e09e2  pop r11
00007e4af17e09e4  pop r10
00007e4af17e09e6  pop r9
00007e4af17e09e8  pop r8
00007e4af17e09ea  pop rsi
00007e4af17e09eb  pop rdi
00007e4af17e09ec  pop rdx
00007e4af17e09ed  pop rcx
00007e4af17e09ee  pop rax
00007e4af17e09ef  add rsp, 0x08
00007e4af17e09f3  jmp 0x00007E4AF17DC658
00007e4af17e09f8  sub rsp, 0x08
00007e4af17e09fc  push rax
00007e4af17e09fd  push rcx
00007e4af17e09fe  push rdx
00007e4af17e09ff  push rdi
00007e4af17e0a00  push rsi
00007e4af17e0a01  push r8
00007e4af17e0a03  push r9
00007e4af17e0a05  push r10
00007e4af17e0a07  push r11
00007e4af17e0a09  sub rsp, 0xF0
00007e4af17e0a10  vmovaps [rsp], xmm0
00007e4af17e0a15  vmovaps [rsp+0x10], xmm1
00007e4af17e0a1b  vmovaps [rsp+0x20], xmm2
00007e4af17e0a21  vmovaps [rsp+0x30], xmm3
00007e4af17e0a27  vmovaps [rsp+0x40], xmm4
00007e4af17e0a2d  vmovaps [rsp+0x50], xmm5
00007e4af17e0a33  vmovaps [rsp+0x60], xmm6
00007e4af17e0a39  vmovaps [rsp+0x70], xmm8
00007e4af17e0a3f  vmovaps [rsp+0x80], xmm9
00007e4af17e0a48  vmovaps [rsp+0x90], xmm10
00007e4af17e0a51  vmovaps [rsp+0xA0], xmm11
00007e4af17e0a5a  vmovaps [rsp+0xB0], xmm12
00007e4af17e0a63  vmovaps [rsp+0xC0], xmm13
00007e4af17e0a6c  vmovaps [rsp+0xD0], xmm14
00007e4af17e0a75  vmovaps [rsp+0xE0], xmm15
00007e4af17e0a7e  sub rsp, 0x30
00007e4af17e0a82  movaps [rsp], xmm7
00007e4af17e0a86  movaps [rsp+0x10], xmm11
00007e4af17e0a8c  movaps [rsp+0x20], xmm9
00007e4af17e0a92  lea rdi, [rsp]
00007e4af17e0a96  mov esi, 0x00
00007e4af17e0a9b  mov rax, 0x6256754A7530
00007e4af17e0aa5  call rax
00007e4af17e0aa7  movaps xmm7, [rsp]
00007e4af17e0aab  add rsp, 0x30
00007e4af17e0aaf  vmovaps xmm0, [rsp]
00007e4af17e0ab4  vmovaps xmm1, [rsp+0x10]
00007e4af17e0aba  vmovaps xmm2, [rsp+0x20]
00007e4af17e0ac0  vmovaps xmm3, [rsp+0x30]
00007e4af17e0ac6  vmovaps xmm4, [rsp+0x40]
00007e4af17e0acc  vmovaps xmm5, [rsp+0x50]
00007e4af17e0ad2  vmovaps xmm6, [rsp+0x60]
00007e4af17e0ad8  vmovaps xmm8, [rsp+0x70]
00007e4af17e0ade  vmovaps xmm9, [rsp+0x80]
00007e4af17e0ae7  vmovaps xmm10, [rsp+0x90]
00007e4af17e0af0  vmovaps xmm11, [rsp+0xA0]
00007e4af17e0af9  vmovaps xmm12, [rsp+0xB0]
00007e4af17e0b02  vmovaps xmm13, [rsp+0xC0]
00007e4af17e0b0b  vmovaps xmm14, [rsp+0xD0]
00007e4af17e0b14  vmovaps xmm15, [rsp+0xE0]
00007e4af17e0b1d  add rsp, 0xF0
00007e4af17e0b24  pop r11
00007e4af17e0b26  pop r10
00007e4af17e0b28  pop r9
00007e4af17e0b2a  pop r8
00007e4af17e0b2c  pop rsi
00007e4af17e0b2d  pop rdi
00007e4af17e0b2e  pop rdx
00007e4af17e0b2f  pop rcx
00007e4af17e0b30  pop rax
00007e4af17e0b31  add rsp, 0x08
00007e4af17e0b35  jmp 0x00007E4AF17DC685
00007e4af17e0b3a  sub rsp, 0x08
00007e4af17e0b3e  push rax
00007e4af17e0b3f  push rcx
00007e4af17e0b40  push rdx
00007e4af17e0b41  push rdi
00007e4af17e0b42  push rsi
00007e4af17e0b43  push r8
00007e4af17e0b45  push r9
00007e4af17e0b47  push r10
00007e4af17e0b49  push r11
00007e4af17e0b4b  sub rsp, 0xF0
00007e4af17e0b52  vmovaps [rsp], xmm0
00007e4af17e0b57  vmovaps [rsp+0x10], xmm1
00007e4af17e0b5d  vmovaps [rsp+0x20], xmm2
00007e4af17e0b63  vmovaps [rsp+0x30], xmm3
00007e4af17e0b69  vmovaps [rsp+0x40], xmm4
00007e4af17e0b6f  vmovaps [rsp+0x50], xmm5
00007e4af17e0b75  vmovaps [rsp+0x60], xmm6
00007e4af17e0b7b  vmovaps [rsp+0x70], xmm7
00007e4af17e0b81  vmovaps [rsp+0x80], xmm8
00007e4af17e0b8a  vmovaps [rsp+0x90], xmm9
00007e4af17e0b93  vmovaps [rsp+0xA0], xmm10
00007e4af17e0b9c  vmovaps [rsp+0xB0], xmm12
00007e4af17e0ba5  vmovaps [rsp+0xC0], xmm13
00007e4af17e0bae  vmovaps [rsp+0xD0], xmm14
00007e4af17e0bb7  vmovaps [rsp+0xE0], xmm15
00007e4af17e0bc0  sub rsp, 0x30
00007e4af17e0bc4  movaps [rsp], xmm11
00007e4af17e0bc9  movaps [rsp+0x10], xmm10
00007e4af17e0bcf  movaps [rsp+0x20], xmm14
00007e4af17e0bd5  lea rdi, [rsp]
00007e4af17e0bd9  mov esi, 0x00
00007e4af17e0bde  mov rax, 0x6256754A7530
00007e4af17e0be8  call rax
00007e4af17e0bea  movaps xmm11, [rsp]
00007e4af17e0bef  add rsp, 0x30
00007e4af17e0bf3  vmovaps xmm0, [rsp]
00007e4af17e0bf8  vmovaps xmm1, [rsp+0x10]
00007e4af17e0bfe  vmovaps xmm2, [rsp+0x20]
00007e4af17e0c04  vmovaps xmm3, [rsp+0x30]
00007e4af17e0c0a  vmovaps xmm4, [rsp+0x40]
00007e4af17e0c10  vmovaps xmm5, [rsp+0x50]
00007e4af17e0c16  vmovaps xmm6, [rsp+0x60]
00007e4af17e0c1c  vmovaps xmm7, [rsp+0x70]
00007e4af17e0c22  vmovaps xmm8, [rsp+0x80]
00007e4af17e0c2b  vmovaps xmm9, [rsp+0x90]
00007e4af17e0c34  vmovaps xmm10, [rsp+0xA0]
00007e4af17e0c3d  vmovaps xmm12, [rsp+0xB0]
00007e4af17e0c46  vmovaps xmm13, [rsp+0xC0]
00007e4af17e0c4f  vmovaps xmm14, [rsp+0xD0]
00007e4af17e0c58  vmovaps xmm15, [rsp+0xE0]
00007e4af17e0c61  add rsp, 0xF0
00007e4af17e0c68  pop r11
00007e4af17e0c6a  pop r10
00007e4af17e0c6c  pop r9
00007e4af17e0c6e  pop r8
00007e4af17e0c70  pop rsi
00007e4af17e0c71  pop rdi
00007e4af17e0c72  pop rdx
00007e4af17e0c73  pop rcx
00007e4af17e0c74  pop rax
00007e4af17e0c75  add rsp, 0x08
00007e4af17e0c79  jmp 0x00007E4AF17DC6A0
00007e4af17e0c7e  call 0x00007E4AF16C33A0
00007e4af17e0c83  jmp 0x00007E4AF17DC6AA
00007e4af17e0c88  sub rsp, 0x08
00007e4af17e0c8c  push rax
00007e4af17e0c8d  push rcx
00007e4af17e0c8e  push rdx
00007e4af17e0c8f  push rdi
00007e4af17e0c90  push rsi
00007e4af17e0c91  push r8
00007e4af17e0c93  push r9
00007e4af17e0c95  push r10
00007e4af17e0c97  push r11
00007e4af17e0c99  sub rsp, 0xF0
00007e4af17e0ca0  vmovaps [rsp], xmm0
00007e4af17e0ca5  vmovaps [rsp+0x10], xmm1
00007e4af17e0cab  vmovaps [rsp+0x20], xmm2
00007e4af17e0cb1  vmovaps [rsp+0x30], xmm3
00007e4af17e0cb7  vmovaps [rsp+0x40], xmm4
00007e4af17e0cbd  vmovaps [rsp+0x50], xmm5
00007e4af17e0cc3  vmovaps [rsp+0x60], xmm6
00007e4af17e0cc9  vmovaps [rsp+0x70], xmm7
00007e4af17e0ccf  vmovaps [rsp+0x80], xmm8
00007e4af17e0cd8  vmovaps [rsp+0x90], xmm9
00007e4af17e0ce1  vmovaps [rsp+0xA0], xmm11
00007e4af17e0cea  vmovaps [rsp+0xB0], xmm12
00007e4af17e0cf3  vmovaps [rsp+0xC0], xmm13
00007e4af17e0cfc  vmovaps [rsp+0xD0], xmm14
00007e4af17e0d05  vmovaps [rsp+0xE0], xmm15
00007e4af17e0d0e  sub rsp, 0x30
00007e4af17e0d12  movaps [rsp], xmm10
00007e4af17e0d17  movaps [rsp+0x10], xmm1
00007e4af17e0d1c  movaps [rsp+0x20], xmm12
00007e4af17e0d22  lea rdi, [rsp]
00007e4af17e0d26  mov esi, 0x00
00007e4af17e0d2b  mov rax, 0x6256754A7530
00007e4af17e0d35  call rax
00007e4af17e0d37  movaps xmm10, [rsp]
00007e4af17e0d3c  add rsp, 0x30
00007e4af17e0d40  vmovaps xmm0, [rsp]
00007e4af17e0d45  vmovaps xmm1, [rsp+0x10]
00007e4af17e0d4b  vmovaps xmm2, [rsp+0x20]
00007e4af17e0d51  vmovaps xmm3, [rsp+0x30]
00007e4af17e0d57  vmovaps xmm4, [rsp+0x40]
00007e4af17e0d5d  vmovaps xmm5, [rsp+0x50]
00007e4af17e0d63  vmovaps xmm6, [rsp+0x60]
00007e4af17e0d69  vmovaps xmm7, [rsp+0x70]
00007e4af17e0d6f  vmovaps xmm8, [rsp+0x80]
00007e4af17e0d78  vmovaps xmm9, [rsp+0x90]
00007e4af17e0d81  vmovaps xmm11, [rsp+0xA0]
00007e4af17e0d8a  vmovaps xmm12, [rsp+0xB0]
00007e4af17e0d93  vmovaps xmm13, [rsp+0xC0]
00007e4af17e0d9c  vmovaps xmm14, [rsp+0xD0]
00007e4af17e0da5  vmovaps xmm15, [rsp+0xE0]
00007e4af17e0dae  add rsp, 0xF0
00007e4af17e0db5  pop r11
00007e4af17e0db7  pop r10
00007e4af17e0db9  pop r9
00007e4af17e0dbb  pop r8
00007e4af17e0dbd  pop rsi
00007e4af17e0dbe  pop rdi
00007e4af17e0dbf  pop rdx
00007e4af17e0dc0  pop rcx
00007e4af17e0dc1  pop rax
00007e4af17e0dc2  add rsp, 0x08
00007e4af17e0dc6  jmp 0x00007E4AF17DC6CD
00007e4af17e0dcb  sub rsp, 0x08
00007e4af17e0dcf  push rax
00007e4af17e0dd0  push rcx
00007e4af17e0dd1  push rdx
00007e4af17e0dd2  push rdi
00007e4af17e0dd3  push rsi
00007e4af17e0dd4  push r8
00007e4af17e0dd6  push r9
00007e4af17e0dd8  push r10
00007e4af17e0dda  push r11
00007e4af17e0ddc  sub rsp, 0xF0
00007e4af17e0de3  vmovaps [rsp], xmm0
00007e4af17e0de8  vmovaps [rsp+0x10], xmm1
00007e4af17e0dee  vmovaps [rsp+0x20], xmm2
00007e4af17e0df4  vmovaps [rsp+0x30], xmm3
00007e4af17e0dfa  vmovaps [rsp+0x40], xmm4
00007e4af17e0e00  vmovaps [rsp+0x50], xmm5
00007e4af17e0e06  vmovaps [rsp+0x60], xmm6
00007e4af17e0e0c  vmovaps [rsp+0x70], xmm7
00007e4af17e0e12  vmovaps [rsp+0x80], xmm8
00007e4af17e0e1b  vmovaps [rsp+0x90], xmm9
00007e4af17e0e24  vmovaps [rsp+0xA0], xmm10
00007e4af17e0e2d  vmovaps [rsp+0xB0], xmm11
00007e4af17e0e36  vmovaps [rsp+0xC0], xmm13
00007e4af17e0e3f  vmovaps [rsp+0xD0], xmm14
00007e4af17e0e48  vmovaps [rsp+0xE0], xmm15
00007e4af17e0e51  sub rsp, 0x30
00007e4af17e0e55  movaps [rsp], xmm12
00007e4af17e0e5a  movaps [rsp+0x10], xmm14
00007e4af17e0e60  movaps [rsp+0x20], xmm1
00007e4af17e0e65  lea rdi, [rsp]
00007e4af17e0e69  mov esi, 0x00
00007e4af17e0e6e  mov rax, 0x6256754A7530
00007e4af17e0e78  call rax
00007e4af17e0e7a  movaps xmm12, [rsp]
00007e4af17e0e7f  add rsp, 0x30
00007e4af17e0e83  vmovaps xmm0, [rsp]
00007e4af17e0e88  vmovaps xmm1, [rsp+0x10]
00007e4af17e0e8e  vmovaps xmm2, [rsp+0x20]
00007e4af17e0e94  vmovaps xmm3, [rsp+0x30]
00007e4af17e0e9a  vmovaps xmm4, [rsp+0x40]
00007e4af17e0ea0  vmovaps xmm5, [rsp+0x50]
00007e4af17e0ea6  vmovaps xmm6, [rsp+0x60]
00007e4af17e0eac  vmovaps xmm7, [rsp+0x70]
00007e4af17e0eb2  vmovaps xmm8, [rsp+0x80]
00007e4af17e0ebb  vmovaps xmm9, [rsp+0x90]
00007e4af17e0ec4  vmovaps xmm10, [rsp+0xA0]
00007e4af17e0ecd  vmovaps xmm11, [rsp+0xB0]
00007e4af17e0ed6  vmovaps xmm13, [rsp+0xC0]
00007e4af17e0edf  vmovaps xmm14, [rsp+0xD0]
00007e4af17e0ee8  vmovaps xmm15, [rsp+0xE0]
00007e4af17e0ef1  add rsp, 0xF0
00007e4af17e0ef8  pop r11
00007e4af17e0efa  pop r10
00007e4af17e0efc  pop r9
00007e4af17e0efe  pop r8
00007e4af17e0f00  pop rsi
00007e4af17e0f01  pop rdi
00007e4af17e0f02  pop rdx
00007e4af17e0f03  pop rcx
00007e4af17e0f04  pop rax
00007e4af17e0f05  add rsp, 0x08
00007e4af17e0f09  jmp 0x00007E4AF17DC6FC
00007e4af17e0f0e  sub rsp, 0x08
00007e4af17e0f12  push rax
00007e4af17e0f13  push rcx
00007e4af17e0f14  push rdx
00007e4af17e0f15  push rdi
00007e4af17e0f16  push rsi
00007e4af17e0f17  push r8
00007e4af17e0f19  push r9
00007e4af17e0f1b  push r10
00007e4af17e0f1d  push r11
00007e4af17e0f1f  sub rsp, 0xF0
00007e4af17e0f26  vmovaps [rsp], xmm0
00007e4af17e0f2b  vmovaps [rsp+0x10], xmm1
00007e4af17e0f31  vmovaps [rsp+0x20], xmm2
00007e4af17e0f37  vmovaps [rsp+0x30], xmm3
00007e4af17e0f3d  vmovaps [rsp+0x40], xmm4
00007e4af17e0f43  vmovaps [rsp+0x50], xmm5
00007e4af17e0f49  vmovaps [rsp+0x60], xmm6
00007e4af17e0f4f  vmovaps [rsp+0x70], xmm7
00007e4af17e0f55  vmovaps [rsp+0x80], xmm8
00007e4af17e0f5e  vmovaps [rsp+0x90], xmm9
00007e4af17e0f67  vmovaps [rsp+0xA0], xmm10
00007e4af17e0f70  vmovaps [rsp+0xB0], xmm11
00007e4af17e0f79  vmovaps [rsp+0xC0], xmm12
00007e4af17e0f82  vmovaps [rsp+0xD0], xmm13
00007e4af17e0f8b  vmovaps [rsp+0xE0], xmm15
00007e4af17e0f94  sub rsp, 0x30
00007e4af17e0f98  movaps [rsp], xmm14
00007e4af17e0f9d  movaps [rsp+0x10], xmm9
00007e4af17e0fa3  movaps [rsp+0x20], xmm1
00007e4af17e0fa8  lea rdi, [rsp]
00007e4af17e0fac  mov esi, 0x00
00007e4af17e0fb1  mov rax, 0x6256754A7530
00007e4af17e0fbb  call rax
00007e4af17e0fbd  movaps xmm14, [rsp]
00007e4af17e0fc2  add rsp, 0x30
00007e4af17e0fc6  vmovaps xmm0, [rsp]
00007e4af17e0fcb  vmovaps xmm1, [rsp+0x10]
00007e4af17e0fd1  vmovaps xmm2, [rsp+0x20]
00007e4af17e0fd7  vmovaps xmm3, [rsp+0x30]
00007e4af17e0fdd  vmovaps xmm4, [rsp+0x40]
00007e4af17e0fe3  vmovaps xmm5, [rsp+0x50]
00007e4af17e0fe9  vmovaps xmm6, [rsp+0x60]
00007e4af17e0fef  vmovaps xmm7, [rsp+0x70]
00007e4af17e0ff5  vmovaps xmm8, [rsp+0x80]
00007e4af17e0ffe  vmovaps xmm9, [rsp+0x90]
00007e4af17e1007  vmovaps xmm10, [rsp+0xA0]
00007e4af17e1010  vmovaps xmm11, [rsp+0xB0]
00007e4af17e1019  vmovaps xmm12, [rsp+0xC0]
00007e4af17e1022  vmovaps xmm13, [rsp+0xD0]
00007e4af17e102b  vmovaps xmm15, [rsp+0xE0]
00007e4af17e1034  add rsp, 0xF0
00007e4af17e103b  pop r11
00007e4af17e103d  pop r10
00007e4af17e103f  pop r9
00007e4af17e1041  pop r8
00007e4af17e1043  pop rsi
00007e4af17e1044  pop rdi
00007e4af17e1045  pop rdx
00007e4af17e1046  pop rcx
00007e4af17e1047  pop rax
00007e4af17e1048  add rsp, 0x08
00007e4af17e104c  jmp 0x00007E4AF17DC72B
00007e4af17e1051  sub rsp, 0x08
00007e4af17e1055  push rax
00007e4af17e1056  push rcx
00007e4af17e1057  push rdx
00007e4af17e1058  push rdi
00007e4af17e1059  push rsi
00007e4af17e105a  push r8
00007e4af17e105c  push r9
00007e4af17e105e  push r10
00007e4af17e1060  push r11
00007e4af17e1062  sub rsp, 0xF0
00007e4af17e1069  vmovaps [rsp], xmm0
00007e4af17e106e  vmovaps [rsp+0x10], xmm2
00007e4af17e1074  vmovaps [rsp+0x20], xmm3
00007e4af17e107a  vmovaps [rsp+0x30], xmm4
00007e4af17e1080  vmovaps [rsp+0x40], xmm5
00007e4af17e1086  vmovaps [rsp+0x50], xmm6
00007e4af17e108c  vmovaps [rsp+0x60], xmm7
00007e4af17e1092  vmovaps [rsp+0x70], xmm8
00007e4af17e1098  vmovaps [rsp+0x80], xmm9
00007e4af17e10a1  vmovaps [rsp+0x90], xmm10
00007e4af17e10aa  vmovaps [rsp+0xA0], xmm11
00007e4af17e10b3  vmovaps [rsp+0xB0], xmm12
00007e4af17e10bc  vmovaps [rsp+0xC0], xmm13
00007e4af17e10c5  vmovaps [rsp+0xD0], xmm14
00007e4af17e10ce  vmovaps [rsp+0xE0], xmm15
00007e4af17e10d7  sub rsp, 0x30
00007e4af17e10db  movaps [rsp], xmm1
00007e4af17e10df  movaps [rsp+0x10], xmm13
00007e4af17e10e5  movaps [rsp+0x20], xmm8
00007e4af17e10eb  lea rdi, [rsp]
00007e4af17e10ef  mov esi, 0x00
00007e4af17e10f4  mov rax, 0x6256754A7530
00007e4af17e10fe  call rax
00007e4af17e1100  movaps xmm1, [rsp]
00007e4af17e1104  add rsp, 0x30
00007e4af17e1108  vmovaps xmm0, [rsp]
00007e4af17e110d  vmovaps xmm2, [rsp+0x10]
00007e4af17e1113  vmovaps xmm3, [rsp+0x20]
00007e4af17e1119  vmovaps xmm4, [rsp+0x30]
00007e4af17e111f  vmovaps xmm5, [rsp+0x40]
00007e4af17e1125  vmovaps xmm6, [rsp+0x50]
00007e4af17e112b  vmovaps xmm7, [rsp+0x60]
00007e4af17e1131  vmovaps xmm8, [rsp+0x70]
00007e4af17e1137  vmovaps xmm9, [rsp+0x80]
00007e4af17e1140  vmovaps xmm10, [rsp+0x90]
00007e4af17e1149  vmovaps xmm11, [rsp+0xA0]
00007e4af17e1152  vmovaps xmm12, [rsp+0xB0]
00007e4af17e115b  vmovaps xmm13, [rsp+0xC0]
00007e4af17e1164  vmovaps xmm14, [rsp+0xD0]
00007e4af17e116d  vmovaps xmm15, [rsp+0xE0]
00007e4af17e1176  add rsp, 0xF0
00007e4af17e117d  pop r11
00007e4af17e117f  pop r10
00007e4af17e1181  pop r9
00007e4af17e1183  pop r8
00007e4af17e1185  pop rsi
00007e4af17e1186  pop rdi
00007e4af17e1187  pop rdx
00007e4af17e1188  pop rcx
00007e4af17e1189  pop rax
00007e4af17e118a  add rsp, 0x08
00007e4af17e118e  jmp 0x00007E4AF17DC74D
00007e4af17e1193  call 0x00007E4AF160C260
00007e4af17e1198  jmp 0x00007E4AF17DC75B
00007e4af17e119d  call 0x00007E4AF16BD750
00007e4af17e11a2  jmp 0x00007E4AF17DC765
00007e4af17e11a7  sub rsp, 0x08
00007e4af17e11ab  push rax
00007e4af17e11ac  push rcx
00007e4af17e11ad  push rdx
00007e4af17e11ae  push rdi
00007e4af17e11af  push rsi
00007e4af17e11b0  push r8
00007e4af17e11b2  push r9
00007e4af17e11b4  push r10
00007e4af17e11b6  push r11
00007e4af17e11b8  sub rsp, 0xF0
00007e4af17e11bf  vmovaps [rsp], xmm0
00007e4af17e11c4  vmovaps [rsp+0x10], xmm1
00007e4af17e11ca  vmovaps [rsp+0x20], xmm2
00007e4af17e11d0  vmovaps [rsp+0x30], xmm3
00007e4af17e11d6  vmovaps [rsp+0x40], xmm4
00007e4af17e11dc  vmovaps [rsp+0x50], xmm5
00007e4af17e11e2  vmovaps [rsp+0x60], xmm6
00007e4af17e11e8  vmovaps [rsp+0x70], xmm7
00007e4af17e11ee  vmovaps [rsp+0x80], xmm9
00007e4af17e11f7  vmovaps [rsp+0x90], xmm10
00007e4af17e1200  vmovaps [rsp+0xA0], xmm11
00007e4af17e1209  vmovaps [rsp+0xB0], xmm12
00007e4af17e1212  vmovaps [rsp+0xC0], xmm13
00007e4af17e121b  vmovaps [rsp+0xD0], xmm14
00007e4af17e1224  vmovaps [rsp+0xE0], xmm15
00007e4af17e122d  sub rsp, 0x30
00007e4af17e1231  movaps [rsp], xmm8
00007e4af17e1236  movaps [rsp+0x10], xmm15
00007e4af17e123c  movaps [rsp+0x20], xmm7
00007e4af17e1241  lea rdi, [rsp]
00007e4af17e1245  mov esi, 0x00
00007e4af17e124a  mov rax, 0x6256754A7530
00007e4af17e1254  call rax
00007e4af17e1256  movaps xmm8, [rsp]
00007e4af17e125b  add rsp, 0x30
00007e4af17e125f  vmovaps xmm0, [rsp]
00007e4af17e1264  vmovaps xmm1, [rsp+0x10]
00007e4af17e126a  vmovaps xmm2, [rsp+0x20]
00007e4af17e1270  vmovaps xmm3, [rsp+0x30]
00007e4af17e1276  vmovaps xmm4, [rsp+0x40]
00007e4af17e127c  vmovaps xmm5, [rsp+0x50]
00007e4af17e1282  vmovaps xmm6, [rsp+0x60]
00007e4af17e1288  vmovaps xmm7, [rsp+0x70]
00007e4af17e128e  vmovaps xmm9, [rsp+0x80]
00007e4af17e1297  vmovaps xmm10, [rsp+0x90]
00007e4af17e12a0  vmovaps xmm11, [rsp+0xA0]
00007e4af17e12a9  vmovaps xmm12, [rsp+0xB0]
00007e4af17e12b2  vmovaps xmm13, [rsp+0xC0]
00007e4af17e12bb  vmovaps xmm14, [rsp+0xD0]
00007e4af17e12c4  vmovaps xmm15, [rsp+0xE0]
00007e4af17e12cd  add rsp, 0xF0
00007e4af17e12d4  pop r11
00007e4af17e12d6  pop r10
00007e4af17e12d8  pop r9
00007e4af17e12da  pop r8
00007e4af17e12dc  pop rsi
00007e4af17e12dd  pop rdi
00007e4af17e12de  pop rdx
00007e4af17e12df  pop rcx
00007e4af17e12e0  pop rax
00007e4af17e12e1  add rsp, 0x08
00007e4af17e12e5  jmp 0x00007E4AF17DC787
00007e4af17e12ea  sub rsp, 0x08
00007e4af17e12ee  push rax
00007e4af17e12ef  push rcx
00007e4af17e12f0  push rdx
00007e4af17e12f1  push rdi
00007e4af17e12f2  push rsi
00007e4af17e12f3  push r8
00007e4af17e12f5  push r9
00007e4af17e12f7  push r10
00007e4af17e12f9  push r11
00007e4af17e12fb  sub rsp, 0xF0
00007e4af17e1302  vmovaps [rsp], xmm0
00007e4af17e1307  vmovaps [rsp+0x10], xmm1
00007e4af17e130d  vmovaps [rsp+0x20], xmm2
00007e4af17e1313  vmovaps [rsp+0x30], xmm3
00007e4af17e1319  vmovaps [rsp+0x40], xmm4
00007e4af17e131f  vmovaps [rsp+0x50], xmm5
00007e4af17e1325  vmovaps [rsp+0x60], xmm6
00007e4af17e132b  vmovaps [rsp+0x70], xmm8
00007e4af17e1331  vmovaps [rsp+0x80], xmm9
00007e4af17e133a  vmovaps [rsp+0x90], xmm10
00007e4af17e1343  vmovaps [rsp+0xA0], xmm11
00007e4af17e134c  vmovaps [rsp+0xB0], xmm12
00007e4af17e1355  vmovaps [rsp+0xC0], xmm13
00007e4af17e135e  vmovaps [rsp+0xD0], xmm14
00007e4af17e1367  vmovaps [rsp+0xE0], xmm15
00007e4af17e1370  sub rsp, 0x30
00007e4af17e1374  movaps [rsp], xmm7
00007e4af17e1378  movaps [rsp+0x10], xmm9
00007e4af17e137e  movaps [rsp+0x20], xmm15
00007e4af17e1384  lea rdi, [rsp]
00007e4af17e1388  mov esi, 0x00
00007e4af17e138d  mov rax, 0x6256754A7530
00007e4af17e1397  call rax
00007e4af17e1399  movaps xmm7, [rsp]
00007e4af17e139d  add rsp, 0x30
00007e4af17e13a1  vmovaps xmm0, [rsp]
00007e4af17e13a6  vmovaps xmm1, [rsp+0x10]
00007e4af17e13ac  vmovaps xmm2, [rsp+0x20]
00007e4af17e13b2  vmovaps xmm3, [rsp+0x30]
00007e4af17e13b8  vmovaps xmm4, [rsp+0x40]
00007e4af17e13be  vmovaps xmm5, [rsp+0x50]
00007e4af17e13c4  vmovaps xmm6, [rsp+0x60]
00007e4af17e13ca  vmovaps xmm8, [rsp+0x70]
00007e4af17e13d0  vmovaps xmm9, [rsp+0x80]
00007e4af17e13d9  vmovaps xmm10, [rsp+0x90]
00007e4af17e13e2  vmovaps xmm11, [rsp+0xA0]
00007e4af17e13eb  vmovaps xmm12, [rsp+0xB0]
00007e4af17e13f4  vmovaps xmm13, [rsp+0xC0]
00007e4af17e13fd  vmovaps xmm14, [rsp+0xD0]
00007e4af17e1406  vmovaps xmm15, [rsp+0xE0]
00007e4af17e140f  add rsp, 0xF0
00007e4af17e1416  pop r11
00007e4af17e1418  pop r10
00007e4af17e141a  pop r9
00007e4af17e141c  pop r8
00007e4af17e141e  pop rsi
00007e4af17e141f  pop rdi
00007e4af17e1420  pop rdx
00007e4af17e1421  pop rcx
00007e4af17e1422  pop rax
00007e4af17e1423  add rsp, 0x08
00007e4af17e1427  jmp 0x00007E4AF17DC7B4
00007e4af17e142c  sub rsp, 0x08
00007e4af17e1430  push rax
00007e4af17e1431  push rcx
00007e4af17e1432  push rdx
00007e4af17e1433  push rdi
00007e4af17e1434  push rsi
00007e4af17e1435  push r8
00007e4af17e1437  push r9
00007e4af17e1439  push r10
00007e4af17e143b  push r11
00007e4af17e143d  sub rsp, 0xF0
00007e4af17e1444  vmovaps [rsp], xmm0
00007e4af17e1449  vmovaps [rsp+0x10], xmm1
00007e4af17e144f  vmovaps [rsp+0x20], xmm2
00007e4af17e1455  vmovaps [rsp+0x30], xmm3
00007e4af17e145b  vmovaps [rsp+0x40], xmm4
00007e4af17e1461  vmovaps [rsp+0x50], xmm5
00007e4af17e1467  vmovaps [rsp+0x60], xmm6
00007e4af17e146d  vmovaps [rsp+0x70], xmm7
00007e4af17e1473  vmovaps [rsp+0x80], xmm8
00007e4af17e147c  vmovaps [rsp+0x90], xmm10
00007e4af17e1485  vmovaps [rsp+0xA0], xmm11
00007e4af17e148e  vmovaps [rsp+0xB0], xmm12
00007e4af17e1497  vmovaps [rsp+0xC0], xmm13
00007e4af17e14a0  vmovaps [rsp+0xD0], xmm14
00007e4af17e14a9  vmovaps [rsp+0xE0], xmm15
00007e4af17e14b2  sub rsp, 0x30
00007e4af17e14b6  movaps [rsp], xmm9
00007e4af17e14bb  movaps [rsp+0x10], xmm13
00007e4af17e14c1  movaps [rsp+0x20], xmm15
00007e4af17e14c7  lea rdi, [rsp]
00007e4af17e14cb  mov esi, 0x00
00007e4af17e14d0  mov rax, 0x6256754A7530
00007e4af17e14da  call rax
00007e4af17e14dc  movaps xmm9, [rsp]
00007e4af17e14e1  add rsp, 0x30
00007e4af17e14e5  vmovaps xmm0, [rsp]
00007e4af17e14ea  vmovaps xmm1, [rsp+0x10]
00007e4af17e14f0  vmovaps xmm2, [rsp+0x20]
00007e4af17e14f6  vmovaps xmm3, [rsp+0x30]
00007e4af17e14fc  vmovaps xmm4, [rsp+0x40]
00007e4af17e1502  vmovaps xmm5, [rsp+0x50]
00007e4af17e1508  vmovaps xmm6, [rsp+0x60]
00007e4af17e150e  vmovaps xmm7, [rsp+0x70]
00007e4af17e1514  vmovaps xmm8, [rsp+0x80]
00007e4af17e151d  vmovaps xmm10, [rsp+0x90]
00007e4af17e1526  vmovaps xmm11, [rsp+0xA0]
00007e4af17e152f  vmovaps xmm12, [rsp+0xB0]
00007e4af17e1538  vmovaps xmm13, [rsp+0xC0]
00007e4af17e1541  vmovaps xmm14, [rsp+0xD0]
00007e4af17e154a  vmovaps xmm15, [rsp+0xE0]
00007e4af17e1553  add rsp, 0xF0
00007e4af17e155a  pop r11
00007e4af17e155c  pop r10
00007e4af17e155e  pop r9
00007e4af17e1560  pop r8
00007e4af17e1562  pop rsi
00007e4af17e1563  pop rdi
00007e4af17e1564  pop rdx
00007e4af17e1565  pop rcx
00007e4af17e1566  pop rax
00007e4af17e1567  add rsp, 0x08
00007e4af17e156b  jmp 0x00007E4AF17DC7E2
00007e4af17e1570  sub rsp, 0x08
00007e4af17e1574  push rax
00007e4af17e1575  push rcx
00007e4af17e1576  push rdx
00007e4af17e1577  push rdi
00007e4af17e1578  push rsi
00007e4af17e1579  push r8
00007e4af17e157b  push r9
00007e4af17e157d  push r10
00007e4af17e157f  push r11
00007e4af17e1581  sub rsp, 0xF0
00007e4af17e1588  vmovaps [rsp], xmm0
00007e4af17e158d  vmovaps [rsp+0x10], xmm1
00007e4af17e1593  vmovaps [rsp+0x20], xmm2
00007e4af17e1599  vmovaps [rsp+0x30], xmm3
00007e4af17e159f  vmovaps [rsp+0x40], xmm4
00007e4af17e15a5  vmovaps [rsp+0x50], xmm5
00007e4af17e15ab  vmovaps [rsp+0x60], xmm6
00007e4af17e15b1  vmovaps [rsp+0x70], xmm7
00007e4af17e15b7  vmovaps [rsp+0x80], xmm8
00007e4af17e15c0  vmovaps [rsp+0x90], xmm9
00007e4af17e15c9  vmovaps [rsp+0xA0], xmm10
00007e4af17e15d2  vmovaps [rsp+0xB0], xmm11
00007e4af17e15db  vmovaps [rsp+0xC0], xmm12
00007e4af17e15e4  vmovaps [rsp+0xD0], xmm13
00007e4af17e15ed  vmovaps [rsp+0xE0], xmm14
00007e4af17e15f6  sub rsp, 0x30
00007e4af17e15fa  movaps [rsp], xmm15
00007e4af17e15ff  movaps [rsp+0x10], xmm11
00007e4af17e1605  movaps [rsp+0x20], xmm12
00007e4af17e160b  lea rdi, [rsp]
00007e4af17e160f  mov esi, 0x00
00007e4af17e1614  mov rax, 0x6256754A7530
00007e4af17e161e  call rax
00007e4af17e1620  movaps xmm15, [rsp]
00007e4af17e1625  add rsp, 0x30
00007e4af17e1629  vmovaps xmm0, [rsp]
00007e4af17e162e  vmovaps xmm1, [rsp+0x10]
00007e4af17e1634  vmovaps xmm2, [rsp+0x20]
00007e4af17e163a  vmovaps xmm3, [rsp+0x30]
00007e4af17e1640  vmovaps xmm4, [rsp+0x40]
00007e4af17e1646  vmovaps xmm5, [rsp+0x50]
00007e4af17e164c  vmovaps xmm6, [rsp+0x60]
00007e4af17e1652  vmovaps xmm7, [rsp+0x70]
00007e4af17e1658  vmovaps xmm8, [rsp+0x80]
00007e4af17e1661  vmovaps xmm9, [rsp+0x90]
00007e4af17e166a  vmovaps xmm10, [rsp+0xA0]
00007e4af17e1673  vmovaps xmm11, [rsp+0xB0]
00007e4af17e167c  vmovaps xmm12, [rsp+0xC0]
00007e4af17e1685  vmovaps xmm13, [rsp+0xD0]
00007e4af17e168e  vmovaps xmm14, [rsp+0xE0]
00007e4af17e1697  add rsp, 0xF0
00007e4af17e169e  pop r11
00007e4af17e16a0  pop r10
00007e4af17e16a2  pop r9
00007e4af17e16a4  pop r8
00007e4af17e16a6  pop rsi
00007e4af17e16a7  pop rdi
00007e4af17e16a8  pop rdx
00007e4af17e16a9  pop rcx
00007e4af17e16aa  pop rax
00007e4af17e16ab  add rsp, 0x08
00007e4af17e16af  jmp 0x00007E4AF17DC7FD
00007e4af17e16b4  sub rsp, 0x08
00007e4af17e16b8  push rax
00007e4af17e16b9  push rcx
00007e4af17e16ba  push rdx
00007e4af17e16bb  push rdi
00007e4af17e16bc  push rsi
00007e4af17e16bd  push r8
00007e4af17e16bf  push r9
00007e4af17e16c1  push r10
00007e4af17e16c3  push r11
00007e4af17e16c5  sub rsp, 0xF0
00007e4af17e16cc  vmovaps [rsp], xmm0
00007e4af17e16d1  vmovaps [rsp+0x10], xmm1
00007e4af17e16d7  vmovaps [rsp+0x20], xmm2
00007e4af17e16dd  vmovaps [rsp+0x30], xmm3
00007e4af17e16e3  vmovaps [rsp+0x40], xmm4
00007e4af17e16e9  vmovaps [rsp+0x50], xmm5
00007e4af17e16ef  vmovaps [rsp+0x60], xmm6
00007e4af17e16f5  vmovaps [rsp+0x70], xmm7
00007e4af17e16fb  vmovaps [rsp+0x80], xmm8
00007e4af17e1704  vmovaps [rsp+0x90], xmm9
00007e4af17e170d  vmovaps [rsp+0xA0], xmm10
00007e4af17e1716  vmovaps [rsp+0xB0], xmm11
00007e4af17e171f  vmovaps [rsp+0xC0], xmm12
00007e4af17e1728  vmovaps [rsp+0xD0], xmm14
00007e4af17e1731  vmovaps [rsp+0xE0], xmm15
00007e4af17e173a  sub rsp, 0x30
00007e4af17e173e  movaps [rsp], xmm13
00007e4af17e1743  movaps [rsp+0x10], xmm10
00007e4af17e1749  movaps [rsp+0x20], xmm14
00007e4af17e174f  lea rdi, [rsp]
00007e4af17e1753  mov esi, 0x00
00007e4af17e1758  mov rax, 0x6256754A7530
00007e4af17e1762  call rax
00007e4af17e1764  movaps xmm13, [rsp]
00007e4af17e1769  add rsp, 0x30
00007e4af17e176d  vmovaps xmm0, [rsp]
00007e4af17e1772  vmovaps xmm1, [rsp+0x10]
00007e4af17e1778  vmovaps xmm2, [rsp+0x20]
00007e4af17e177e  vmovaps xmm3, [rsp+0x30]
00007e4af17e1784  vmovaps xmm4, [rsp+0x40]
00007e4af17e178a  vmovaps xmm5, [rsp+0x50]
00007e4af17e1790  vmovaps xmm6, [rsp+0x60]
00007e4af17e1796  vmovaps xmm7, [rsp+0x70]
00007e4af17e179c  vmovaps xmm8, [rsp+0x80]
00007e4af17e17a5  vmovaps xmm9, [rsp+0x90]
00007e4af17e17ae  vmovaps xmm10, [rsp+0xA0]
00007e4af17e17b7  vmovaps xmm11, [rsp+0xB0]
00007e4af17e17c0  vmovaps xmm12, [rsp+0xC0]
00007e4af17e17c9  vmovaps xmm14, [rsp+0xD0]
00007e4af17e17d2  vmovaps xmm15, [rsp+0xE0]
00007e4af17e17db  add rsp, 0xF0
00007e4af17e17e2  pop r11
00007e4af17e17e4  pop r10
00007e4af17e17e6  pop r9
00007e4af17e17e8  pop r8
00007e4af17e17ea  pop rsi
00007e4af17e17eb  pop rdi
00007e4af17e17ec  pop rdx
00007e4af17e17ed  pop rcx
00007e4af17e17ee  pop rax
00007e4af17e17ef  add rsp, 0x08
00007e4af17e17f3  jmp 0x00007E4AF17DC820
00007e4af17e17f8  sub rsp, 0x08
00007e4af17e17fc  push rax
00007e4af17e17fd  push rcx
00007e4af17e17fe  push rdx
00007e4af17e17ff  push rdi
00007e4af17e1800  push rsi
00007e4af17e1801  push r8
00007e4af17e1803  push r9
00007e4af17e1805  push r10
00007e4af17e1807  push r11
00007e4af17e1809  sub rsp, 0xF0
00007e4af17e1810  vmovaps [rsp], xmm0
00007e4af17e1815  vmovaps [rsp+0x10], xmm1
00007e4af17e181b  vmovaps [rsp+0x20], xmm2
00007e4af17e1821  vmovaps [rsp+0x30], xmm3
00007e4af17e1827  vmovaps [rsp+0x40], xmm4
00007e4af17e182d  vmovaps [rsp+0x50], xmm5
00007e4af17e1833  vmovaps [rsp+0x60], xmm6
00007e4af17e1839  vmovaps [rsp+0x70], xmm7
00007e4af17e183f  vmovaps [rsp+0x80], xmm8
00007e4af17e1848  vmovaps [rsp+0x90], xmm9
00007e4af17e1851  vmovaps [rsp+0xA0], xmm10
00007e4af17e185a  vmovaps [rsp+0xB0], xmm11
00007e4af17e1863  vmovaps [rsp+0xC0], xmm12
00007e4af17e186c  vmovaps [rsp+0xD0], xmm13
00007e4af17e1875  vmovaps [rsp+0xE0], xmm15
00007e4af17e187e  sub rsp, 0x30
00007e4af17e1882  movaps [rsp], xmm14
00007e4af17e1887  movaps [rsp+0x10], xmm1
00007e4af17e188c  movaps [rsp+0x20], xmm7
00007e4af17e1891  lea rdi, [rsp]
00007e4af17e1895  mov esi, 0x00
00007e4af17e189a  mov rax, 0x6256754A7530
00007e4af17e18a4  call rax
00007e4af17e18a6  movaps xmm14, [rsp]
00007e4af17e18ab  add rsp, 0x30
00007e4af17e18af  vmovaps xmm0, [rsp]
00007e4af17e18b4  vmovaps xmm1, [rsp+0x10]
00007e4af17e18ba  vmovaps xmm2, [rsp+0x20]
00007e4af17e18c0  vmovaps xmm3, [rsp+0x30]
00007e4af17e18c6  vmovaps xmm4, [rsp+0x40]
00007e4af17e18cc  vmovaps xmm5, [rsp+0x50]
00007e4af17e18d2  vmovaps xmm6, [rsp+0x60]
00007e4af17e18d8  vmovaps xmm7, [rsp+0x70]
00007e4af17e18de  vmovaps xmm8, [rsp+0x80]
00007e4af17e18e7  vmovaps xmm9, [rsp+0x90]
00007e4af17e18f0  vmovaps xmm10, [rsp+0xA0]
00007e4af17e18f9  vmovaps xmm11, [rsp+0xB0]
00007e4af17e1902  vmovaps xmm12, [rsp+0xC0]
00007e4af17e190b  vmovaps xmm13, [rsp+0xD0]
00007e4af17e1914  vmovaps xmm15, [rsp+0xE0]
00007e4af17e191d  add rsp, 0xF0
00007e4af17e1924  pop r11
00007e4af17e1926  pop r10
00007e4af17e1928  pop r9
00007e4af17e192a  pop r8
00007e4af17e192c  pop rsi
00007e4af17e192d  pop rdi
00007e4af17e192e  pop rdx
00007e4af17e192f  pop rcx
00007e4af17e1930  pop rax
00007e4af17e1931  add rsp, 0x08
00007e4af17e1935  jmp 0x00007E4AF17DC843
00007e4af17e193a  sub rsp, 0x08
00007e4af17e193e  push rax
00007e4af17e193f  push rcx
00007e4af17e1940  push rdx
00007e4af17e1941  push rdi
00007e4af17e1942  push rsi
00007e4af17e1943  push r8
00007e4af17e1945  push r9
00007e4af17e1947  push r10
00007e4af17e1949  push r11
00007e4af17e194b  sub rsp, 0xF0
00007e4af17e1952  vmovaps [rsp], xmm0
00007e4af17e1957  vmovaps [rsp+0x10], xmm2
00007e4af17e195d  vmovaps [rsp+0x20], xmm3
00007e4af17e1963  vmovaps [rsp+0x30], xmm4
00007e4af17e1969  vmovaps [rsp+0x40], xmm5
00007e4af17e196f  vmovaps [rsp+0x50], xmm6
00007e4af17e1975  vmovaps [rsp+0x60], xmm7
00007e4af17e197b  vmovaps [rsp+0x70], xmm8
00007e4af17e1981  vmovaps [rsp+0x80], xmm9
00007e4af17e198a  vmovaps [rsp+0x90], xmm10
00007e4af17e1993  vmovaps [rsp+0xA0], xmm11
00007e4af17e199c  vmovaps [rsp+0xB0], xmm12
00007e4af17e19a5  vmovaps [rsp+0xC0], xmm13
00007e4af17e19ae  vmovaps [rsp+0xD0], xmm14
00007e4af17e19b7  vmovaps [rsp+0xE0], xmm15
00007e4af17e19c0  sub rsp, 0x30
00007e4af17e19c4  movaps [rsp], xmm1
00007e4af17e19c8  movaps [rsp+0x10], xmm8
00007e4af17e19ce  movaps [rsp+0x20], xmm9
00007e4af17e19d4  lea rdi, [rsp]
00007e4af17e19d8  mov esi, 0x00
00007e4af17e19dd  mov rax, 0x6256754A7530
00007e4af17e19e7  call rax
00007e4af17e19e9  movaps xmm1, [rsp]
00007e4af17e19ed  add rsp, 0x30
00007e4af17e19f1  vmovaps xmm0, [rsp]
00007e4af17e19f6  vmovaps xmm2, [rsp+0x10]
00007e4af17e19fc  vmovaps xmm3, [rsp+0x20]
00007e4af17e1a02  vmovaps xmm4, [rsp+0x30]
00007e4af17e1a08  vmovaps xmm5, [rsp+0x40]
00007e4af17e1a0e  vmovaps xmm6, [rsp+0x50]
00007e4af17e1a14  vmovaps xmm7, [rsp+0x60]
00007e4af17e1a1a  vmovaps xmm8, [rsp+0x70]
00007e4af17e1a20  vmovaps xmm9, [rsp+0x80]
00007e4af17e1a29  vmovaps xmm10, [rsp+0x90]
00007e4af17e1a32  vmovaps xmm11, [rsp+0xA0]
00007e4af17e1a3b  vmovaps xmm12, [rsp+0xB0]
00007e4af17e1a44  vmovaps xmm13, [rsp+0xC0]
00007e4af17e1a4d  vmovaps xmm14, [rsp+0xD0]
00007e4af17e1a56  vmovaps xmm15, [rsp+0xE0]
00007e4af17e1a5f  add rsp, 0xF0
00007e4af17e1a66  pop r11
00007e4af17e1a68  pop r10
00007e4af17e1a6a  pop r9
00007e4af17e1a6c  pop r8
00007e4af17e1a6e  pop rsi
00007e4af17e1a6f  pop rdi
00007e4af17e1a70  pop rdx
00007e4af17e1a71  pop rcx
00007e4af17e1a72  pop rax
00007e4af17e1a73  add rsp, 0x08
00007e4af17e1a77  jmp 0x00007E4AF17DC865
00007e4af17e1a7c  call 0x00007E4AF16E5940
00007e4af17e1a81  jmp 0x00007E4AF17DC873
00007e4af17e1a86  call 0x00007E4AF160C380
00007e4af17e1a8b  jmp 0x00007E4AF17DC87D
00007e4af17e1a90  call 0x00007E4AF160D600
00007e4af17e1a95  jmp 0x00007E4AF17DC887
00007e4af17e1a9a  call 0x00007E4AF15FF540
00007e4af17e1a9f  jmp 0x00007E4AF17DC891
00007e4af17e1aa4  int3
00007e4af17e1aa5  nop [rax+rax*1], ax
00007e4af17e1aae  nop
00007e4af17e1ab0  mov rax, [r15+0xF8]
00007e4af17e1ab7  lea r14, [rax+0x140]
00007e4af17e1abe  mov r12, [r13+r14*1]
00007e4af17e1ac3  mov [r15+0xE8], r12
00007e4af17e1aca  lea r14, [rax+0x130]
00007e4af17e1ad1  mov r12, [r13+r14*1]
00007e4af17e1ad6  lea r14, [rax+0x138]
00007e4af17e1add  mov r11, [r13+r14*1]
00007e4af17e1ae2  movq xmm1, r12
00007e4af17e1ae7  movq xmm15, r11
00007e4af17e1aec  movq xmm1, xmm1
00007e4af17e1af0  movq xmm1, xmm1
00007e4af17e1af4  movaps [r15+0x1A0], xmm1
00007e4af17e1afc  movq xmm15, xmm15
00007e4af17e1b01  movq xmm15, xmm15
00007e4af17e1b06  movaps [r15+0x190], xmm15
00007e4af17e1b0e  lea r14, [rax+0x120]
00007e4af17e1b15  mov r12, [r13+r14*1]
00007e4af17e1b1a  lea r14, [rax+0x128]
00007e4af17e1b21  mov r11, [r13+r14*1]
00007e4af17e1b26  movq xmm1, r12
00007e4af17e1b2b  movq xmm15, r11
00007e4af17e1b30  movq xmm1, xmm1
00007e4af17e1b34  movq xmm1, xmm1
00007e4af17e1b38  movaps [r15+0x1C0], xmm1
00007e4af17e1b40  movq xmm15, xmm15
00007e4af17e1b45  movq xmm15, xmm15
00007e4af17e1b4a  movaps [r15+0x1B0], xmm15
00007e4af17e1b52  lea r14, [rax+0x110]
00007e4af17e1b59  mov r12, [r13+r14*1]
00007e4af17e1b5e  lea r14, [rax+0x118]
00007e4af17e1b65  mov r11, [r13+r14*1]
00007e4af17e1b6a  movq xmm1, r12
00007e4af17e1b6f  movq xmm15, r11
00007e4af17e1b74  movq xmm1, xmm1
00007e4af17e1b78  movq xmm1, xmm1
00007e4af17e1b7c  movaps [r15+0x1E0], xmm1
00007e4af17e1b84  movq xmm15, xmm15
00007e4af17e1b89  movq xmm15, xmm15
00007e4af17e1b8e  movaps [r15+0x1D0], xmm15
00007e4af17e1b96  lea r14, [rax+0x100]
00007e4af17e1b9d  mov r12, [r13+r14*1]
00007e4af17e1ba2  lea r14, [rax+0x108]
00007e4af17e1ba9  mov r11, [r13+r14*1]
00007e4af17e1bae  movq xmm1, r12
00007e4af17e1bb3  movq xmm15, r11
00007e4af17e1bb8  movq xmm1, xmm1
00007e4af17e1bbc  movq xmm1, xmm1
00007e4af17e1bc0  movaps [r15+0x200], xmm1
00007e4af17e1bc8  movq xmm15, xmm15
00007e4af17e1bcd  movq xmm15, xmm15
00007e4af17e1bd2  movaps [r15+0x1F0], xmm15
00007e4af17e1bda  mov qword ptr [r15+0x40], 0x430000
00007e4af17e1be2  mov r14d, 0x430510
00007e4af17e1be8  mov r12, [r13+r14*1]
00007e4af17e1bed  movq xmm1, r12
00007e4af17e1bf2  lea r14, [rax+0x150]
00007e4af17e1bf9  mov [r15+0xF8], r14
00007e4af17e1c00  mov rax, [r15+0x50]
00007e4af17e1c04  movups xmm15, [r13+rax*1]
00007e4af17e1c0a  movaps [r15+0x120], xmm15
00007e4af17e1c12  mov qword ptr [r15+0x48], 0x10
00007e4af17e1c1a  xor eax, eax
00007e4af17e1c1c  mov r14d, 0x10
00007e4af17e1c22  mov r12d, 0x200
00007e4af17e1c28  cmp r14, r12
00007e4af17e1c2b  cmc
00007e4af17e1c2c  lahf
00007e4af17e1c2d  seto al
00007e4af17e1c30  mov [r15+0x108], eax
00007e4af17e1c37  pextrq rax, xmm15, 0x01
00007e4af17e1c3e  movq xmm14, rax
00007e4af17e1c43  movaps [r15+0x130], xmm14
00007e4af17e1c4b  movq rax, xmm1
00007e4af17e1c50  movq r14, xmm15
00007e4af17e1c55  vmovq xmm1, rax
00007e4af17e1c5a  vmovq xmm15, r14
00007e4af17e1c5f  movaps xmm13, xmm1
00007e4af17e1c63  addsd xmm13, xmm15
00007e4af17e1c68  ucomisd xmm13, xmm13
00007e4af17e1c6d  jp 0x00007E4AF17E1D86
00007e4af17e1c73  movq xmm13, xmm13
00007e4af17e1c78  movq rax, xmm13
00007e4af17e1c7d  movq r14, xmm14
00007e4af17e1c82  vmovq xmm1, rax
00007e4af17e1c87  vmovq xmm15, r14
00007e4af17e1c8c  movaps xmm14, xmm1
00007e4af17e1c90  addsd xmm14, xmm15
00007e4af17e1c95  ucomisd xmm14, xmm14
00007e4af17e1c9a  jp 0x00007E4AF17E1DCE
00007e4af17e1ca0  movq xmm14, xmm14
00007e4af17e1ca5  movaps [r15+0x110], xmm14
00007e4af17e1cad  mov eax, [r15+0x108]
00007e4af17e1cb4  sahf
00007e4af17e1cb5  jnz 0x00007E4AF17E1CE7
00007e4af17e1cb7  cmp dword ptr [r15+0x318], 0x00
00007e4af17e1cbf  jz 0x00007E4AF17E1FE0
00007e4af17e1cc5  nop [rax+rax*1], ax
00007e4af17e1cce  nop [rax+rax*1], eax
00007e4af17e1cd6  mov eax, 0x410490
00007e4af17e1cdb  mov [r15+0x100], rax
00007e4af17e1ce2  jmp 0x00007E4AF15FE110
00007e4af17e1ce7  cmp dword ptr [r15+0x318], 0x00
00007e4af17e1cef  jz 0x00007E4AF17E1E20
00007e4af17e1cf5  nop [rax+rax*1], ax
00007e4af17e1cfe  nop [rax+rax*1], eax
00007e4af17e1d06  mov eax, 0x410474
00007e4af17e1d0b  mov [r15+0x100], rax
00007e4af17e1d12  jmp 0x00007E4AF15FE110
00007e4af17e1d17  int3
00007e4af17e1d18  call 0x00007E4AF16E27E0
00007e4af17e1d1d  jmp 0x00007E4AF17E1AC3
00007e4af17e1d22  call 0x00007E4AF16E27E0
00007e4af17e1d27  jmp 0x00007E4AF17E1AD6
00007e4af17e1d2c  call 0x00007E4AF16E1570
00007e4af17e1d31  jmp 0x00007E4AF17E1AE2
00007e4af17e1d36  call 0x00007E4AF16E27E0
00007e4af17e1d3b  jmp 0x00007E4AF17E1B1A
00007e4af17e1d40  call 0x00007E4AF16E1570
00007e4af17e1d45  jmp 0x00007E4AF17E1B26
00007e4af17e1d4a  call 0x00007E4AF16E27E0
00007e4af17e1d4f  jmp 0x00007E4AF17E1B5E
00007e4af17e1d54  call 0x00007E4AF16E1570
00007e4af17e1d59  jmp 0x00007E4AF17E1B6A
00007e4af17e1d5e  call 0x00007E4AF16E27E0
00007e4af17e1d63  jmp 0x00007E4AF17E1BA2
00007e4af17e1d68  call 0x00007E4AF16E1570
00007e4af17e1d6d  jmp 0x00007E4AF17E1BAE
00007e4af17e1d72  call 0x00007E4AF16E27E0
00007e4af17e1d77  jmp 0x00007E4AF17E1BED
00007e4af17e1d7c  call 0x00007E4AF160E760
00007e4af17e1d81  jmp 0x00007E4AF17E1C0A
00007e4af17e1d86  ucomisd xmm1, xmm15
00007e4af17e1d8b  jp 0x00007E4AF17E1D9A
00007e4af17e1d8d  movaps xmm13, [0x00007E4AF13FE060]
00007e4af17e1d95  jmp 0x00007E4AF17E1C73
00007e4af17e1d9a  vxorps xmm0, xmm1, xmm15
00007e4af17e1d9f  pextrw eax, xmm0, 0x03
00007e4af17e1da4  and eax, 0x7FF8
00007e4af17e1da9  cmp eax, 0x08
00007e4af17e1dac  jnz 0x00007E4AF17E1C73
00007e4af17e1db2  movq rax, xmm15
00007e4af17e1db7  shl rax, 0x0D
00007e4af17e1dbb  jbe 0x00007E4AF17E1C73
00007e4af17e1dc1  vorps xmm13, xmm15, [0x00007E4AF13FE070]
00007e4af17e1dc9  jmp 0x00007E4AF17E1C73
00007e4af17e1dce  ucomisd xmm1, xmm15
00007e4af17e1dd3  jp 0x00007E4AF17E1DE2
00007e4af17e1dd5  movaps xmm14, [0x00007E4AF13FE060]
00007e4af17e1ddd  jmp 0x00007E4AF17E1CA0
00007e4af17e1de2  vxorps xmm0, xmm1, xmm15
00007e4af17e1de7  pextrw eax, xmm0, 0x03
00007e4af17e1dec  and eax, 0x7FF8
00007e4af17e1df1  cmp eax, 0x08
00007e4af17e1df4  jnz 0x00007E4AF17E1CA0
00007e4af17e1dfa  movq rax, xmm15
00007e4af17e1dff  shl rax, 0x0D
00007e4af17e1e03  jbe 0x00007E4AF17E1CA0
00007e4af17e1e09  vorps xmm14, xmm15, [0x00007E4AF13FE070]
00007e4af17e1e11  jmp 0x00007E4AF17E1CA0
00007e4af17e1e16  int3
00007e4af17e1e17  nop [rax+rax*1], ax
00007e4af17e1e20  mov rax, [r15+0x48]
00007e4af17e1e24  mov r14, [r15+0x50]
00007e4af17e1e28  lea r12, [r14+rax*1]
00007e4af17e1e2c  movups xmm1, [r13+r12*1]
00007e4af17e1e32  movaps [r15+0x120], xmm1
00007e4af17e1e3a  lea r14, [rax+0x10]
00007e4af17e1e3e  mov [r15+0x48], r14
00007e4af17e1e42  xor eax, eax
00007e4af17e1e44  mov r12d, 0x200
00007e4af17e1e4a  cmp r14, r12
00007e4af17e1e4d  cmc
00007e4af17e1e4e  lahf
00007e4af17e1e4f  seto al
00007e4af17e1e52  mov [r15+0x108], eax
00007e4af17e1e59  pextrq rax, xmm1, 0x01
00007e4af17e1e60  movq xmm15, rax
00007e4af17e1e65  movaps [r15+0x130], xmm15
00007e4af17e1e6d  movaps xmm14, [r15+0x110]
00007e4af17e1e75  movq rax, xmm14
00007e4af17e1e7a  movq r14, xmm1
00007e4af17e1e7f  vmovq xmm1, rax
00007e4af17e1e84  vmovq xmm14, r14
00007e4af17e1e89  movaps xmm13, xmm1
00007e4af17e1e8d  addsd xmm13, xmm14
00007e4af17e1e92  ucomisd xmm13, xmm13
00007e4af17e1e97  jp 0x00007E4AF17E1F4C
00007e4af17e1e9d  movq xmm13, xmm13
00007e4af17e1ea2  movq rax, xmm13
00007e4af17e1ea7  movq r14, xmm15
00007e4af17e1eac  vmovq xmm1, rax
00007e4af17e1eb1  vmovq xmm15, r14
00007e4af17e1eb6  movaps xmm14, xmm1
00007e4af17e1eba  addsd xmm14, xmm15
00007e4af17e1ebf  ucomisd xmm14, xmm14
00007e4af17e1ec4  jp 0x00007E4AF17E1F94
00007e4af17e1eca  movq xmm14, xmm14
00007e4af17e1ecf  movaps [r15+0x110], xmm14
00007e4af17e1ed7  mov eax, [r15+0x108]
00007e4af17e1ede  sahf
00007e4af17e1edf  jnz 0x00007E4AF17E1F11
00007e4af17e1ee1  cmp dword ptr [r15+0x318], 0x00
00007e4af17e1ee9  jz 0x00007E4AF17E1FE0
00007e4af17e1eef  nop [rax+rax*1], ax
00007e4af17e1ef8  nop [rax+rax*1], eax
00007e4af17e1f00  mov eax, 0x410490
00007e4af17e1f05  mov [r15+0x100], rax
00007e4af17e1f0c  jmp 0x00007E4AF15FE110
00007e4af17e1f11  cmp dword ptr [r15+0x318], 0x00
00007e4af17e1f19  jz 0x00007E4AF17E1E20
00007e4af17e1f1f  nop [rax+rax*1], ax
00007e4af17e1f28  nop [rax+rax*1], eax
00007e4af17e1f30  mov eax, 0x410474
00007e4af17e1f35  mov [r15+0x100], rax
00007e4af17e1f3c  jmp 0x00007E4AF15FE110
00007e4af17e1f41  int3
00007e4af17e1f42  call 0x00007E4AF16B52F0
00007e4af17e1f47  jmp 0x00007E4AF17E1E32
00007e4af17e1f4c  ucomisd xmm1, xmm14
00007e4af17e1f51  jp 0x00007E4AF17E1F60
00007e4af17e1f53  movaps xmm13, [0x00007E4AF13FE060]
00007e4af17e1f5b  jmp 0x00007E4AF17E1E9D
00007e4af17e1f60  vxorps xmm0, xmm1, xmm14
00007e4af17e1f65  pextrw eax, xmm0, 0x03
00007e4af17e1f6a  and eax, 0x7FF8
00007e4af17e1f6f  cmp eax, 0x08
00007e4af17e1f72  jnz 0x00007E4AF17E1E9D
00007e4af17e1f78  movq rax, xmm14
00007e4af17e1f7d  shl rax, 0x0D
00007e4af17e1f81  jbe 0x00007E4AF17E1E9D
00007e4af17e1f87  vorps xmm13, xmm14, [0x00007E4AF13FE070]
00007e4af17e1f8f  jmp 0x00007E4AF17E1E9D
00007e4af17e1f94  ucomisd xmm1, xmm15
00007e4af17e1f99  jp 0x00007E4AF17E1FA8
00007e4af17e1f9b  movaps xmm14, [0x00007E4AF13FE060]
00007e4af17e1fa3  jmp 0x00007E4AF17E1ECA
00007e4af17e1fa8  vxorps xmm0, xmm1, xmm15
00007e4af17e1fad  pextrw eax, xmm0, 0x03
00007e4af17e1fb2  and eax, 0x7FF8
00007e4af17e1fb7  cmp eax, 0x08
00007e4af17e1fba  jnz 0x00007E4AF17E1ECA
00007e4af17e1fc0  movq rax, xmm15
00007e4af17e1fc5  shl rax, 0x0D
00007e4af17e1fc9  jbe 0x00007E4AF17E1ECA
00007e4af17e1fcf  vorps xmm14, xmm15, [0x00007E4AF13FE070]
00007e4af17e1fd7  jmp 0x00007E4AF17E1ECA
00007e4af17e1fdc  int3
00007e4af17e1fdd  nop [rax], eax
00007e4af17e1fe0  mov rax, [r15+0x40]
00007e4af17e1fe4  lea r14, [rax+0x510]
00007e4af17e1feb  movaps xmm1, [r15+0x110]
00007e4af17e1ff3  movq rax, xmm1
00007e4af17e1ff8  mov [r13+r14*1], rax
00007e4af17e1ffd  mov rax, [r15+0xF0]
00007e4af17e2004  mov [r15+0x100], rax
00007e4af17e200b  jmp 0x00007E4AF17CE5C0
00007e4af17e2010  int3
00007e4af17e2011  call 0x00007E4AF16D5EB0
00007e4af17e2016  jmp 0x00007E4AF17E1FFD
00007e4af17e201b  int3
00007e4af17e201c  nop [rax], eax
00007e4af17e2020  mov qword ptr [r15+0x100], 0x04
00007e4af17e202b  mov esi, 0x00
00007e4af17e2030  mov edx, 0x09
00007e4af17e2035  mov rdi, 0x7FFDA4FA5100
00007e4af17e203f  mov rax, 0x62567533A970
00007e4af17e2049  call rax
00007e4af17e204b  cmp dword ptr [r15+0x318], 0x00
00007e4af17e2053  jnz 0x00007E4AF15FE110
00007e4af17e2059  jmp 0x00007E4AF15FE0A0
00007e4af17e205e  int3
00007e4af17e205f  int3
