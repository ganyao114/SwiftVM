0000740ecffce69b  nop [rax+rax*1], eax
0000740ecffce6a0  vmovaps xmm1, [0x0000740ECFBFE010]
0000740ecffce6a8  movq xmm1, xmm1
0000740ecffce6ac  movaps [r15+0x110], xmm1
0000740ecffce6b4  vmovaps xmm1, [0x0000740ECFBFE020]
0000740ecffce6bc  movq xmm1, xmm1
0000740ecffce6c0  movaps [r15+0x120], xmm1
0000740ecffce6c8  mov eax, 0x4204C0
0000740ecffce6cd  mov r14, [r13+rax*1]
0000740ecffce6d2  movq xmm1, r14
0000740ecffce6d7  movaps [r15+0x130], xmm1
0000740ecffce6df  vmovaps xmm1, [0x0000740ECFBFE030]
0000740ecffce6e7  vpbroadcastq xmm1, xmm1
0000740ecffce6ec  movaps [r15+0x140], xmm1
0000740ecffce6f4  mov qword ptr [r15+0x40], 0x02
0000740ecffce6fc  vmovaps xmm15, [0x0000740ECFBFE040]
0000740ecffce704  movq xmm15, xmm15
0000740ecffce709  movaps [r15+0x150], xmm15
0000740ecffce711  mov qword ptr [r15+0x58], 0x420000
0000740ecffce719  vmovaps xmm15, [0x0000740ECFBFE050]
0000740ecffce721  vpbroadcastq xmm15, xmm15
0000740ecffce726  movaps [r15+0x160], xmm15
0000740ecffce72e  mov rax, [r15+0x40]
0000740ecffce732  vmovq xmm14, rax
0000740ecffce737  vpbroadcastq xmm14, xmm14
0000740ecffce73c  movaps [r15+0x170], xmm14
0000740ecffce744  mov eax, 0x4204D0
0000740ecffce749  movups xmm13, [r13+rax*1]
0000740ecffce74f  mov qword ptr [r15+0x40], 0x430518
0000740ecffce757  mov qword ptr [r15+0x50], 0x430720
0000740ecffce75f  vpmovqd xmm12, xmm13
0000740ecffce765  pxor xmm11, xmm11
0000740ecffce76a  punpcklqdq xmm12, xmm11
0000740ecffce76f  movaps [r15+0x210], xmm12
0000740ecffce777  movq xmm12, qword ptr [r15+0x120]
0000740ecffce780  movq xmm11, qword ptr [r15+0x130]
0000740ecffce789  psubd xmm12, xmm11
0000740ecffce78e  movq xmm12, xmm12
0000740ecffce793  paddq xmm13, xmm14
0000740ecffce798  movaps [r15+0x180], xmm13
0000740ecffce7a0  movq xmm14, qword ptr [r15+0x150]
0000740ecffce7a9  paddd xmm11, xmm14
0000740ecffce7ae  movq xmm11, xmm11
0000740ecffce7b3  movq xmm11, xmm11
0000740ecffce7b8  movaps [r15+0x130], xmm11
0000740ecffce7c0  pmovzxdq xmm12, xmm12
0000740ecffce7c6  psllq xmm12, 0x00
0000740ecffce7cc  movq xmm14, qword ptr [r15+0x210]
0000740ecffce7d5  movq xmm13, qword ptr [r15+0x110]
0000740ecffce7de  paddd xmm14, xmm13
0000740ecffce7e3  movq xmm14, xmm14
0000740ecffce7e8  vcvtuqq2pd xmm12, xmm12
0000740ecffce7ee  pmovzxdq xmm14, xmm14
0000740ecffce7f4  psllq xmm14, 0x00
0000740ecffce7fa  vcvtuqq2pd xmm14, xmm14
0000740ecffce800  movaps xmm13, xmm12
0000740ecffce804  mulpd xmm13, xmm1
0000740ecffce809  vcmppd xmm11, xmm13, xmm13, 0x03
0000740ecffce80f  ptest xmm11, xmm11
0000740ecffce815  jnz 0x0000740ECFFCE8FF
0000740ecffce81b  movaps [r15+0x220], xmm13
0000740ecffce823  mov eax, 0x430720
0000740ecffce828  movups [r13+rax*1], xmm13
0000740ecffce82e  movaps xmm1, xmm14
0000740ecffce832  mulpd xmm1, xmm15
0000740ecffce837  vcmppd xmm13, xmm1, xmm1, 0x03
0000740ecffce83c  ptest xmm13, xmm13
0000740ecffce842  jnz 0x0000740ECFFCEA4C
0000740ecffce848  movaps [r15+0x210], xmm1
0000740ecffce850  mov eax, 0x430518
0000740ecffce855  movups [r13+rax*1], xmm1
0000740ecffce85b  mov qword ptr [r15+0x48], 0x10
0000740ecffce863  xor eax, eax
0000740ecffce865  mov r14d, 0x10
0000740ecffce86b  mov r12d, 0x200
0000740ecffce871  cmp r14, r12
0000740ecffce874  cmc
0000740ecffce875  lahf
0000740ecffce876  seto al
0000740ecffce879  mov [r15+0x108], eax
0000740ecffce880  mov eax, [r15+0x108]
0000740ecffce887  sahf
0000740ecffce888  jnz 0x0000740ECFFCE8BA
0000740ecffce88a  cmp dword ptr [r15+0x318], 0x00
0000740ecffce892  jz 0x0000740ECFFCEFF0
0000740ecffce898  nop [rax+rax*1], ax
0000740ecffce8a1  nop [rax+rax*1], eax
0000740ecffce8a9  mov eax, 0x4101EC
0000740ecffce8ae  mov [r15+0x100], rax
0000740ecffce8b5  jmp 0x0000740ECFDFE110
0000740ecffce8ba  cmp dword ptr [r15+0x318], 0x00
0000740ecffce8c2  jz 0x0000740ECFFCEBA0
0000740ecffce8c8  nop [rax+rax*1], ax
0000740ecffce8d1  nop [rax+rax*1], eax
0000740ecffce8d9  mov eax, 0x4101AC
0000740ecffce8de  mov [r15+0x100], rax
0000740ecffce8e5  jmp 0x0000740ECFDFE110
0000740ecffce8ea  int3
0000740ecffce8eb  call 0x0000740ECFE0DC20
0000740ecffce8f0  jmp 0x0000740ECFFCE6D2
0000740ecffce8f5  call 0x0000740ECFE0C260
0000740ecffce8fa  jmp 0x0000740ECFFCE74F
0000740ecffce8ff  sub rsp, 0x08
0000740ecffce903  push rax
0000740ecffce904  push rcx
0000740ecffce905  push rdx
0000740ecffce906  push rdi
0000740ecffce907  push rsi
0000740ecffce908  push r8
0000740ecffce90a  push r9
0000740ecffce90c  push r10
0000740ecffce90e  push r11
0000740ecffce910  sub rsp, 0xF0
0000740ecffce917  vmovaps [rsp], xmm0
0000740ecffce91c  vmovaps [rsp+0x10], xmm1
0000740ecffce922  vmovaps [rsp+0x20], xmm2
0000740ecffce928  vmovaps [rsp+0x30], xmm3
0000740ecffce92e  vmovaps [rsp+0x40], xmm4
0000740ecffce934  vmovaps [rsp+0x50], xmm5
0000740ecffce93a  vmovaps [rsp+0x60], xmm6
0000740ecffce940  vmovaps [rsp+0x70], xmm7
0000740ecffce946  vmovaps [rsp+0x80], xmm8
0000740ecffce94f  vmovaps [rsp+0x90], xmm9
0000740ecffce958  vmovaps [rsp+0xA0], xmm10
0000740ecffce961  vmovaps [rsp+0xB0], xmm11
0000740ecffce96a  vmovaps [rsp+0xC0], xmm12
0000740ecffce973  vmovaps [rsp+0xD0], xmm14
0000740ecffce97c  vmovaps [rsp+0xE0], xmm15
0000740ecffce985  sub rsp, 0x30
0000740ecffce989  movaps [rsp], xmm13
0000740ecffce98e  movaps [rsp+0x10], xmm12
0000740ecffce994  movaps [rsp+0x20], xmm1
0000740ecffce999  lea rdi, [rsp]
0000740ecffce99d  mov esi, 0x00
0000740ecffce9a2  mov rax, 0x5E8249CF1530
0000740ecffce9ac  call rax
0000740ecffce9ae  movaps xmm13, [rsp]
0000740ecffce9b3  add rsp, 0x30
0000740ecffce9b7  vmovaps xmm0, [rsp]
0000740ecffce9bc  vmovaps xmm1, [rsp+0x10]
0000740ecffce9c2  vmovaps xmm2, [rsp+0x20]
0000740ecffce9c8  vmovaps xmm3, [rsp+0x30]
0000740ecffce9ce  vmovaps xmm4, [rsp+0x40]
0000740ecffce9d4  vmovaps xmm5, [rsp+0x50]
0000740ecffce9da  vmovaps xmm6, [rsp+0x60]
0000740ecffce9e0  vmovaps xmm7, [rsp+0x70]
0000740ecffce9e6  vmovaps xmm8, [rsp+0x80]
0000740ecffce9ef  vmovaps xmm9, [rsp+0x90]
0000740ecffce9f8  vmovaps xmm10, [rsp+0xA0]
0000740ecffcea01  vmovaps xmm11, [rsp+0xB0]
0000740ecffcea0a  vmovaps xmm12, [rsp+0xC0]
0000740ecffcea13  vmovaps xmm14, [rsp+0xD0]
0000740ecffcea1c  vmovaps xmm15, [rsp+0xE0]
0000740ecffcea25  add rsp, 0xF0
0000740ecffcea2c  pop r11
0000740ecffcea2e  pop r10
0000740ecffcea30  pop r9
0000740ecffcea32  pop r8
0000740ecffcea34  pop rsi
0000740ecffcea35  pop rdi
0000740ecffcea36  pop rdx
0000740ecffcea37  pop rcx
0000740ecffcea38  pop rax
0000740ecffcea39  add rsp, 0x08
0000740ecffcea3d  jmp 0x0000740ECFFCE81B
0000740ecffcea42  call 0x0000740ECFE0C380
0000740ecffcea47  jmp 0x0000740ECFFCE82E
0000740ecffcea4c  sub rsp, 0x08
0000740ecffcea50  push rax
0000740ecffcea51  push rcx
0000740ecffcea52  push rdx
0000740ecffcea53  push rdi
0000740ecffcea54  push rsi
0000740ecffcea55  push r8
0000740ecffcea57  push r9
0000740ecffcea59  push r10
0000740ecffcea5b  push r11
0000740ecffcea5d  sub rsp, 0xF0
0000740ecffcea64  vmovaps [rsp], xmm0
0000740ecffcea69  vmovaps [rsp+0x10], xmm2
0000740ecffcea6f  vmovaps [rsp+0x20], xmm3
0000740ecffcea75  vmovaps [rsp+0x30], xmm4
0000740ecffcea7b  vmovaps [rsp+0x40], xmm5
0000740ecffcea81  vmovaps [rsp+0x50], xmm6
0000740ecffcea87  vmovaps [rsp+0x60], xmm7
0000740ecffcea8d  vmovaps [rsp+0x70], xmm8
0000740ecffcea93  vmovaps [rsp+0x80], xmm9
0000740ecffcea9c  vmovaps [rsp+0x90], xmm10
0000740ecffceaa5  vmovaps [rsp+0xA0], xmm11
0000740ecffceaae  vmovaps [rsp+0xB0], xmm12
0000740ecffceab7  vmovaps [rsp+0xC0], xmm13
0000740ecffceac0  vmovaps [rsp+0xD0], xmm14
0000740ecffceac9  vmovaps [rsp+0xE0], xmm15
0000740ecffcead2  sub rsp, 0x30
0000740ecffcead6  movaps [rsp], xmm1
0000740ecffceada  movaps [rsp+0x10], xmm14
0000740ecffceae0  movaps [rsp+0x20], xmm15
0000740ecffceae6  lea rdi, [rsp]
0000740ecffceaea  mov esi, 0x00
0000740ecffceaef  mov rax, 0x5E8249CF1530
0000740ecffceaf9  call rax
0000740ecffceafb  movaps xmm1, [rsp]
0000740ecffceaff  add rsp, 0x30
0000740ecffceb03  vmovaps xmm0, [rsp]
0000740ecffceb08  vmovaps xmm2, [rsp+0x10]
0000740ecffceb0e  vmovaps xmm3, [rsp+0x20]
0000740ecffceb14  vmovaps xmm4, [rsp+0x30]
0000740ecffceb1a  vmovaps xmm5, [rsp+0x40]
0000740ecffceb20  vmovaps xmm6, [rsp+0x50]
0000740ecffceb26  vmovaps xmm7, [rsp+0x60]
0000740ecffceb2c  vmovaps xmm8, [rsp+0x70]
0000740ecffceb32  vmovaps xmm9, [rsp+0x80]
0000740ecffceb3b  vmovaps xmm10, [rsp+0x90]
0000740ecffceb44  vmovaps xmm11, [rsp+0xA0]
0000740ecffceb4d  vmovaps xmm12, [rsp+0xB0]
0000740ecffceb56  vmovaps xmm13, [rsp+0xC0]
0000740ecffceb5f  vmovaps xmm14, [rsp+0xD0]
0000740ecffceb68  vmovaps xmm15, [rsp+0xE0]
0000740ecffceb71  add rsp, 0xF0
0000740ecffceb78  pop r11
0000740ecffceb7a  pop r10
0000740ecffceb7c  pop r9
0000740ecffceb7e  pop r8
0000740ecffceb80  pop rsi
0000740ecffceb81  pop rdi
0000740ecffceb82  pop rdx
0000740ecffceb83  pop rcx
0000740ecffceb84  pop rax
0000740ecffceb85  add rsp, 0x08
0000740ecffceb89  jmp 0x0000740ECFFCE848
0000740ecffceb8e  call 0x0000740ECFDFF540
0000740ecffceb93  jmp 0x0000740ECFFCE85B
0000740ecffceb98  int3
0000740ecffceb99  nop [rax], eax
0000740ecffceba0  movaps xmm1, [r15+0x180]
0000740ecffceba8  vpmovqd xmm15, xmm1
0000740ecffcebae  pxor xmm14, xmm14
0000740ecffcebb3  punpcklqdq xmm15, xmm14
0000740ecffcebb8  movaps [r15+0x210], xmm15
0000740ecffcebc0  movq xmm15, qword ptr [r15+0x120]
0000740ecffcebc9  movq xmm14, qword ptr [r15+0x130]
0000740ecffcebd2  psubd xmm15, xmm14
0000740ecffcebd7  movq xmm15, xmm15
0000740ecffcebdc  movaps xmm13, [r15+0x170]
0000740ecffcebe4  paddq xmm1, xmm13
0000740ecffcebe9  movaps [r15+0x180], xmm1
0000740ecffcebf1  movq xmm1, qword ptr [r15+0x150]
0000740ecffcebfa  paddd xmm14, xmm1
0000740ecffcebff  movq xmm14, xmm14
0000740ecffcec04  movq xmm14, xmm14
0000740ecffcec09  movaps [r15+0x130], xmm14
0000740ecffcec11  pmovzxdq xmm15, xmm15
0000740ecffcec17  psllq xmm15, 0x00
0000740ecffcec1d  movq xmm1, qword ptr [r15+0x210]
0000740ecffcec26  movq xmm14, qword ptr [r15+0x110]
0000740ecffcec2f  paddd xmm1, xmm14
0000740ecffcec34  movq xmm1, xmm1
0000740ecffcec38  vcvtuqq2pd xmm15, xmm15
0000740ecffcec3e  pmovzxdq xmm1, xmm1
0000740ecffcec43  psllq xmm1, 0x00
0000740ecffcec48  vcvtuqq2pd xmm1, xmm1
0000740ecffcec4e  movaps xmm14, [r15+0x140]
0000740ecffcec56  movaps xmm13, xmm15
0000740ecffcec5a  mulpd xmm13, xmm14
0000740ecffcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
0000740ecffcec65  ptest xmm12, xmm12
0000740ecffcec6b  jnz 0x0000740ECFFCED4E
0000740ecffcec71  movaps [r15+0x220], xmm13
0000740ecffcec79  mov rax, [r15+0x48]
0000740ecffcec7d  mov r14, [r15+0x50]
0000740ecffcec81  lea r12, [r14+rax*1]
0000740ecffcec85  movups [r13+r12*1], xmm13
0000740ecffcec8b  movaps xmm15, [r15+0x160]
0000740ecffcec93  movaps xmm14, xmm1
0000740ecffcec97  mulpd xmm14, xmm15
0000740ecffcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
0000740ecffceca2  ptest xmm13, xmm13
0000740ecffceca8  jnz 0x0000740ECFFCEE9C
0000740ecffcecae  movaps [r15+0x210], xmm14
0000740ecffcecb6  mov r14, [r15+0x40]
0000740ecffcecba  lea r12, [r14+rax*1]
0000740ecffcecbe  movups [r13+r12*1], xmm14
0000740ecffcecc4  lea r14, [rax+0x10]
0000740ecffcecc8  mov [r15+0x48], r14
0000740ecffceccc  xor eax, eax
0000740ecffcecce  mov r12d, 0x200
0000740ecffcecd4  cmp r14, r12
0000740ecffcecd7  cmc
0000740ecffcecd8  lahf
0000740ecffcecd9  seto al
0000740ecffcecdc  mov [r15+0x108], eax
0000740ecffcece3  mov eax, [r15+0x108]
0000740ecffcecea  sahf
0000740ecffceceb  jnz 0x0000740ECFFCED1D
0000740ecffceced  cmp dword ptr [r15+0x318], 0x00
0000740ecffcecf5  jz 0x0000740ECFFCEFF0
0000740ecffcecfb  nop [rax+rax*1], ax
0000740ecffced04  nop [rax+rax*1], eax
0000740ecffced0c  mov eax, 0x4101EC
0000740ecffced11  mov [r15+0x100], rax
0000740ecffced18  jmp 0x0000740ECFDFE110
0000740ecffced1d  cmp dword ptr [r15+0x318], 0x00
0000740ecffced25  jz 0x0000740ECFFCEBA0
0000740ecffced2b  nop [rax+rax*1], ax
0000740ecffced34  nop [rax+rax*1], eax
0000740ecffced3c  mov eax, 0x4101AC
0000740ecffced41  mov [r15+0x100], rax
0000740ecffced48  jmp 0x0000740ECFDFE110
0000740ecffced4d  int3
0000740ecffced4e  sub rsp, 0x08
0000740ecffced52  push rax
0000740ecffced53  push rcx
0000740ecffced54  push rdx
0000740ecffced55  push rdi
0000740ecffced56  push rsi
0000740ecffced57  push r8
0000740ecffced59  push r9
0000740ecffced5b  push r10
0000740ecffced5d  push r11
0000740ecffced5f  sub rsp, 0xF0
0000740ecffced66  vmovaps [rsp], xmm0
0000740ecffced6b  vmovaps [rsp+0x10], xmm1
0000740ecffced71  vmovaps [rsp+0x20], xmm2
0000740ecffced77  vmovaps [rsp+0x30], xmm3
0000740ecffced7d  vmovaps [rsp+0x40], xmm4
0000740ecffced83  vmovaps [rsp+0x50], xmm5
0000740ecffced89  vmovaps [rsp+0x60], xmm6
0000740ecffced8f  vmovaps [rsp+0x70], xmm7
0000740ecffced95  vmovaps [rsp+0x80], xmm8
0000740ecffced9e  vmovaps [rsp+0x90], xmm9
0000740ecffceda7  vmovaps [rsp+0xA0], xmm10
0000740ecffcedb0  vmovaps [rsp+0xB0], xmm11
0000740ecffcedb9  vmovaps [rsp+0xC0], xmm12
0000740ecffcedc2  vmovaps [rsp+0xD0], xmm14
0000740ecffcedcb  vmovaps [rsp+0xE0], xmm15
0000740ecffcedd4  sub rsp, 0x30
0000740ecffcedd8  movaps [rsp], xmm13
0000740ecffceddd  movaps [rsp+0x10], xmm15
0000740ecffcede3  movaps [rsp+0x20], xmm14
0000740ecffcede9  lea rdi, [rsp]
0000740ecffceded  mov esi, 0x00
0000740ecffcedf2  mov rax, 0x5E8249CF1530
0000740ecffcedfc  call rax
0000740ecffcedfe  movaps xmm13, [rsp]
0000740ecffcee03  add rsp, 0x30
0000740ecffcee07  vmovaps xmm0, [rsp]
0000740ecffcee0c  vmovaps xmm1, [rsp+0x10]
0000740ecffcee12  vmovaps xmm2, [rsp+0x20]
0000740ecffcee18  vmovaps xmm3, [rsp+0x30]
0000740ecffcee1e  vmovaps xmm4, [rsp+0x40]
0000740ecffcee24  vmovaps xmm5, [rsp+0x50]
0000740ecffcee2a  vmovaps xmm6, [rsp+0x60]
0000740ecffcee30  vmovaps xmm7, [rsp+0x70]
0000740ecffcee36  vmovaps xmm8, [rsp+0x80]
0000740ecffcee3f  vmovaps xmm9, [rsp+0x90]
0000740ecffcee48  vmovaps xmm10, [rsp+0xA0]
0000740ecffcee51  vmovaps xmm11, [rsp+0xB0]
0000740ecffcee5a  vmovaps xmm12, [rsp+0xC0]
0000740ecffcee63  vmovaps xmm14, [rsp+0xD0]
0000740ecffcee6c  vmovaps xmm15, [rsp+0xE0]
0000740ecffcee75  add rsp, 0xF0
0000740ecffcee7c  pop r11
0000740ecffcee7e  pop r10
0000740ecffcee80  pop r9
0000740ecffcee82  pop r8
0000740ecffcee84  pop rsi
0000740ecffcee85  pop rdi
0000740ecffcee86  pop rdx
0000740ecffcee87  pop rcx
0000740ecffcee88  pop rax
0000740ecffcee89  add rsp, 0x08
0000740ecffcee8d  jmp 0x0000740ECFFCEC71
0000740ecffcee92  call 0x0000740ECFEC2240
0000740ecffcee97  jmp 0x0000740ECFFCEC8B
0000740ecffcee9c  sub rsp, 0x08
0000740ecffceea0  push rax
0000740ecffceea1  push rcx
0000740ecffceea2  push rdx
0000740ecffceea3  push rdi
0000740ecffceea4  push rsi
0000740ecffceea5  push r8
0000740ecffceea7  push r9
0000740ecffceea9  push r10
0000740ecffceeab  push r11
0000740ecffceead  sub rsp, 0xF0
0000740ecffceeb4  vmovaps [rsp], xmm0
0000740ecffceeb9  vmovaps [rsp+0x10], xmm1
0000740ecffceebf  vmovaps [rsp+0x20], xmm2
0000740ecffceec5  vmovaps [rsp+0x30], xmm3
0000740ecffceecb  vmovaps [rsp+0x40], xmm4
0000740ecffceed1  vmovaps [rsp+0x50], xmm5
0000740ecffceed7  vmovaps [rsp+0x60], xmm6
0000740ecffceedd  vmovaps [rsp+0x70], xmm7
0000740ecffceee3  vmovaps [rsp+0x80], xmm8
0000740ecffceeec  vmovaps [rsp+0x90], xmm9
0000740ecffceef5  vmovaps [rsp+0xA0], xmm10
0000740ecffceefe  vmovaps [rsp+0xB0], xmm11
0000740ecffcef07  vmovaps [rsp+0xC0], xmm12
0000740ecffcef10  vmovaps [rsp+0xD0], xmm13
0000740ecffcef19  vmovaps [rsp+0xE0], xmm15
0000740ecffcef22  sub rsp, 0x30
0000740ecffcef26  movaps [rsp], xmm14
0000740ecffcef2b  movaps [rsp+0x10], xmm1
0000740ecffcef30  movaps [rsp+0x20], xmm15
0000740ecffcef36  lea rdi, [rsp]
0000740ecffcef3a  mov esi, 0x00
0000740ecffcef3f  mov rax, 0x5E8249CF1530
0000740ecffcef49  call rax
0000740ecffcef4b  movaps xmm14, [rsp]
0000740ecffcef50  add rsp, 0x30
0000740ecffcef54  vmovaps xmm0, [rsp]
0000740ecffcef59  vmovaps xmm1, [rsp+0x10]
0000740ecffcef5f  vmovaps xmm2, [rsp+0x20]
0000740ecffcef65  vmovaps xmm3, [rsp+0x30]
0000740ecffcef6b  vmovaps xmm4, [rsp+0x40]
0000740ecffcef71  vmovaps xmm5, [rsp+0x50]
0000740ecffcef77  vmovaps xmm6, [rsp+0x60]
0000740ecffcef7d  vmovaps xmm7, [rsp+0x70]
0000740ecffcef83  vmovaps xmm8, [rsp+0x80]
0000740ecffcef8c  vmovaps xmm9, [rsp+0x90]
0000740ecffcef95  vmovaps xmm10, [rsp+0xA0]
0000740ecffcef9e  vmovaps xmm11, [rsp+0xB0]
0000740ecffcefa7  vmovaps xmm12, [rsp+0xC0]
0000740ecffcefb0  vmovaps xmm13, [rsp+0xD0]
0000740ecffcefb9  vmovaps xmm15, [rsp+0xE0]
0000740ecffcefc2  add rsp, 0xF0
0000740ecffcefc9  pop r11
0000740ecffcefcb  pop r10
0000740ecffcefcd  pop r9
0000740ecffcefcf  pop r8
0000740ecffcefd1  pop rsi
0000740ecffcefd2  pop rdi
0000740ecffcefd3  pop rdx
0000740ecffcefd4  pop rcx
0000740ecffcefd5  pop rax
0000740ecffcefd6  add rsp, 0x08
0000740ecffcefda  jmp 0x0000740ECFFCECAE
0000740ecffcefdf  call 0x0000740ECFEC34C0
0000740ecffcefe4  jmp 0x0000740ECFFCECC4
0000740ecffcefe9  int3
0000740ecffcefea  nop [rax+rax*1], ax
0000740ecffceff0  mov rax, [r15+0xF8]
0000740ecffceff7  lea r14, [rax-0x150]
0000740ecffceffe  mov [r15+0xF8], r14
0000740ecffcf005  mov rax, [r15+0x50]
0000740ecffcf009  lea r12, [rax+0x80]
0000740ecffcf010  movups xmm1, [r13+r12*1]
0000740ecffcf016  lea r12, [rax+0x90]
0000740ecffcf01d  movups xmm15, [r13+r12*1]
0000740ecffcf023  mov qword ptr [r15+0x48], 0x00
0000740ecffcf02b  lea r12, [rax+0x40]
0000740ecffcf02f  movups xmm14, [r13+r12*1]
0000740ecffcf035  lea r12, [rax+0x50]
0000740ecffcf039  movups xmm13, [r13+r12*1]
0000740ecffcf03f  lea r12, [r14+0x120]
0000740ecffcf046  movq xmm12, qword ptr [r15+0x1C0]
0000740ecffcf04f  movq xmm11, qword ptr [r15+0x1B0]
0000740ecffcf058  movq r11, xmm12
0000740ecffcf05d  movq r10, xmm11
0000740ecffcf062  mov [r13+r12*1], r11
0000740ecffcf067  lea r12, [r14+0x128]
0000740ecffcf06e  mov [r13+r12*1], r10
0000740ecffcf073  vxorps xmm12, xmm12, xmm12
0000740ecffcf078  vpbroadcastq xmm12, xmm12
0000740ecffcf07d  lea r12, [r14+0x100]
0000740ecffcf084  movq xmm11, qword ptr [r15+0x200]
0000740ecffcf08d  movq xmm10, qword ptr [r15+0x1F0]
0000740ecffcf096  movq r11, xmm11
0000740ecffcf09b  movq r10, xmm10
0000740ecffcf0a0  mov [r13+r12*1], r11
0000740ecffcf0a5  lea r12, [r14+0x108]
0000740ecffcf0ac  mov [r13+r12*1], r10
0000740ecffcf0b1  lea r12, [r14+0xE0]
0000740ecffcf0b8  movups [r13+r12*1], xmm15
0000740ecffcf0be  lea r12, [r14+0xF0]
0000740ecffcf0c5  movups [r13+r12*1], xmm1
0000740ecffcf0cb  lea r12, [rax+0xC0]
0000740ecffcf0d2  movups xmm1, [r13+r12*1]
0000740ecffcf0d8  lea r12, [rax+0xD0]
0000740ecffcf0df  movups xmm15, [r13+r12*1]
0000740ecffcf0e5  lea r12, [r14+0x110]
0000740ecffcf0ec  movq xmm11, qword ptr [r15+0x1E0]
0000740ecffcf0f5  movq xmm10, qword ptr [r15+0x1D0]
0000740ecffcf0fe  movq r11, xmm11
0000740ecffcf103  movq r10, xmm10
0000740ecffcf108  mov [r13+r12*1], r11
0000740ecffcf10d  lea r12, [r14+0x118]
0000740ecffcf114  mov [r13+r12*1], r10
0000740ecffcf119  movups xmm11, [r13+rax*1]
0000740ecffcf11f  lea r12, [rax+0x10]
0000740ecffcf123  movups xmm10, [r13+r12*1]
0000740ecffcf129  lea r12, [r14+0x130]
0000740ecffcf130  movq xmm9, qword ptr [r15+0x1A0]
0000740ecffcf139  movq xmm8, qword ptr [r15+0x190]
0000740ecffcf142  movq r11, xmm9
0000740ecffcf147  movq r10, xmm8
0000740ecffcf14c  mov [r13+r12*1], r11
0000740ecffcf151  lea r12, [r14+0x138]
0000740ecffcf158  mov [r13+r12*1], r10
0000740ecffcf15d  lea r12, [rax+0x140]
0000740ecffcf164  movups xmm9, [r13+r12*1]
0000740ecffcf16a  lea r12, [rax+0x150]
0000740ecffcf171  movups xmm8, [r13+r12*1]
0000740ecffcf177  lea r12, [r14+0xC0]
0000740ecffcf17e  movups [r13+r12*1], xmm15
0000740ecffcf184  lea r12, [r14+0xD0]
0000740ecffcf18b  movups [r13+r12*1], xmm1
0000740ecffcf191  lea r12, [rax+0x100]
0000740ecffcf198  movups xmm1, [r13+r12*1]
0000740ecffcf19e  lea r12, [rax+0x110]
0000740ecffcf1a5  movups xmm15, [r13+r12*1]
0000740ecffcf1ab  lea r12, [r14+0x140]
0000740ecffcf1b2  mov r11, [r15+0xE8]
0000740ecffcf1b9  mov [r13+r12*1], r11
0000740ecffcf1be  lea r12, [rax+0x180]
0000740ecffcf1c5  movups xmm7, [r13+r12*1]
0000740ecffcf1cb  lea r12, [rax+0x190]
0000740ecffcf1d2  movups xmm6, [r13+r12*1]
0000740ecffcf1d8  lea r12, [rax+0x1C0]
0000740ecffcf1df  movups xmm5, [r13+r12*1]
0000740ecffcf1e5  lea r12, [rax+0x1D0]
0000740ecffcf1ec  movups xmm4, [r13+r12*1]
0000740ecffcf1f2  lea r12, [r14+0x20]
0000740ecffcf1f6  movups [r13+r12*1], xmm1
0000740ecffcf1fc  lea r12, [r14+0x30]
0000740ecffcf200  movups [r13+r12*1], xmm13
0000740ecffcf206  lea r12, [rax+0x60]
0000740ecffcf20a  movups xmm1, [r13+r12*1]
0000740ecffcf210  lea r12, [rax+0x70]
0000740ecffcf214  movups xmm13, [r13+r12*1]
0000740ecffcf21a  lea r12, [rax+0x20]
0000740ecffcf21e  movups xmm3, [r13+r12*1]
0000740ecffcf224  lea r12, [rax+0x30]
0000740ecffcf228  movups xmm2, [r13+r12*1]
0000740ecffcf22e  movaps [r15+0x1F0], xmm2
0000740ecffcf236  lea r12, [r14+0x60]
0000740ecffcf23a  movups [r13+r12*1], xmm11
0000740ecffcf240  lea r12, [r14+0x70]
0000740ecffcf244  movups [r13+r12*1], xmm5
0000740ecffcf24a  lea r12, [rax+0xE0]
0000740ecffcf251  movups xmm11, [r13+r12*1]
0000740ecffcf257  lea r12, [rax+0xF0]
0000740ecffcf25e  movups xmm5, [r13+r12*1]
0000740ecffcf264  lea r12, [r14+0xA0]
0000740ecffcf26b  movups [r13+r12*1], xmm13
0000740ecffcf271  lea r12, [r14+0xB0]
0000740ecffcf278  movups [r13+r12*1], xmm1
0000740ecffcf27e  lea r12, [rax+0xA0]
0000740ecffcf285  movups xmm1, [r13+r12*1]
0000740ecffcf28b  lea r12, [rax+0xB0]
0000740ecffcf292  movups xmm13, [r13+r12*1]
0000740ecffcf298  lea r12, [rax+0x120]
0000740ecffcf29f  vmovaps [rsp+0x10], xmm1
0000740ecffcf2a5  movups xmm1, [r13+r12*1]
0000740ecffcf2ab  lea r12, [rax+0x130]
0000740ecffcf2b2  vmovaps [rsp+0x20], xmm1
0000740ecffcf2b8  movups xmm1, [r13+r12*1]
0000740ecffcf2be  lea r12, [rax+0x160]
0000740ecffcf2c5  vmovaps [rsp+0x30], xmm1
0000740ecffcf2cb  movups xmm1, [r13+r12*1]
0000740ecffcf2d1  lea r12, [rax+0x170]
0000740ecffcf2d8  vmovaps [rsp+0x40], xmm1
0000740ecffcf2de  movups xmm1, [r13+r12*1]
0000740ecffcf2e4  movaps [r15+0x2B0], xmm1
0000740ecffcf2ec  lea r12, [r14+0x80]
0000740ecffcf2f3  movups [r13+r12*1], xmm13
0000740ecffcf2f9  lea r12, [r14+0x90]
0000740ecffcf300  vmovaps xmm13, [rsp+0x10]
0000740ecffcf306  movups [r13+r12*1], xmm13
0000740ecffcf30c  lea r12, [rax+0x1A0]
0000740ecffcf313  movups xmm13, [r13+r12*1]
0000740ecffcf319  lea r12, [rax+0x1B0]
0000740ecffcf320  vmovaps [rsp+0x10], xmm1
0000740ecffcf326  movups xmm1, [r13+r12*1]
0000740ecffcf32c  movaps [r15+0x290], xmm13
0000740ecffcf334  movaps [r15+0x1E0], xmm1
0000740ecffcf33c  lea r12, [rax+0x1E0]
0000740ecffcf343  vmovaps [rsp+0x50], xmm1
0000740ecffcf349  movups xmm1, [r13+r12*1]
0000740ecffcf34f  lea r12, [rax+0x1F0]
0000740ecffcf356  vmovaps [rsp+0x60], xmm1
0000740ecffcf35c  movups xmm1, [r13+r12*1]
0000740ecffcf362  mov qword ptr [r15+0x50], 0x430920
0000740ecffcf36a  lea rax, [r14+0x40]
0000740ecffcf36e  vmovaps [rsp+0x70], xmm1
0000740ecffcf374  vmovaps xmm1, [rsp+0x40]
0000740ecffcf37a  movups [r13+rax*1], xmm1
0000740ecffcf380  lea rax, [r14+0x50]
0000740ecffcf384  movups [r13+rax*1], xmm10
0000740ecffcf38a  vmovaps xmm1, [rsp+0x70]
0000740ecffcf390  movups [r13+r14*1], xmm1
0000740ecffcf396  lea rax, [r14+0x10]
0000740ecffcf39a  vmovaps xmm1, [rsp+0x60]
0000740ecffcf3a0  movups [r13+rax*1], xmm1
0000740ecffcf3a6  mov rax, [r15+0x40]
0000740ecffcf3aa  vmovaps [rsp+0x40], xmm3
0000740ecffcf3b0  vmovaps xmm1, [rsp+0x40]
0000740ecffcf3b6  por xmm3, xmm1
0000740ecffcf3ba  vmovaps [rsp+0x40], xmm6
0000740ecffcf3c0  vmovaps xmm10, [rsp+0x40]
0000740ecffcf3c6  por xmm6, xmm10
0000740ecffcf3cb  lea r12, [rax+0x30]
0000740ecffcf3cf  mov r11, [r13+r12*1]
0000740ecffcf3d4  lea r12, [rax+0x38]
0000740ecffcf3d8  mov r10, [r13+r12*1]
0000740ecffcf3dd  movq xmm10, r11
0000740ecffcf3e2  vmovaps [rsp+0x40], xmm1
0000740ecffcf3e8  movq xmm1, r10
0000740ecffcf3ed  movq xmm10, xmm10
0000740ecffcf3f2  vmovaps [rsp+0x60], xmm10
0000740ecffcf3f8  movq xmm10, xmm10
0000740ecffcf3fd  movaps [r15+0x130], xmm10
0000740ecffcf405  movq xmm1, xmm1
0000740ecffcf409  vmovaps [rsp+0x70], xmm1
0000740ecffcf40f  movq xmm1, xmm1
0000740ecffcf413  movaps [r15+0x280], xmm1
0000740ecffcf41b  vmovaps [rsp+0x80], xmm9
0000740ecffcf424  vmovaps xmm1, [rsp+0x80]
0000740ecffcf42d  por xmm9, xmm1
0000740ecffcf432  lea r12, [rax+0x20]
0000740ecffcf436  mov r11, [r13+r12*1]
0000740ecffcf43b  lea r12, [rax+0x28]
0000740ecffcf43f  mov r10, [r13+r12*1]
0000740ecffcf444  movq xmm1, r11
0000740ecffcf449  movq xmm10, r10
0000740ecffcf44e  movq xmm1, xmm1
0000740ecffcf452  vmovaps [rsp+0x80], xmm1
0000740ecffcf45b  movq xmm1, xmm1
0000740ecffcf45f  movaps [r15+0x150], xmm1
0000740ecffcf467  movq xmm10, xmm10
0000740ecffcf46c  vmovaps [rsp+0x90], xmm10
0000740ecffcf475  movq xmm10, xmm10
0000740ecffcf47a  movaps [r15+0x140], xmm10
0000740ecffcf482  lea r12, [rax+0x10]
0000740ecffcf486  mov r11, [r13+r12*1]
0000740ecffcf48b  lea r12, [rax+0x18]
0000740ecffcf48f  mov r10, [r13+r12*1]
0000740ecffcf494  movq xmm1, r11
0000740ecffcf499  movq xmm10, r10
0000740ecffcf49e  movq xmm1, xmm1
0000740ecffcf4a2  vmovaps [rsp+0xA0], xmm1
0000740ecffcf4ab  movq xmm1, xmm1
0000740ecffcf4af  movaps [r15+0x170], xmm1
0000740ecffcf4b7  movq xmm10, xmm10
0000740ecffcf4bc  vmovaps [rsp+0xB0], xmm10
0000740ecffcf4c5  movq xmm10, xmm10
0000740ecffcf4ca  movaps [r15+0x160], xmm10
0000740ecffcf4d2  mov r12, [r13+rax*1]
0000740ecffcf4d7  vmovq xmm1, r12
0000740ecffcf4dc  vpbroadcastq xmm1, xmm1
0000740ecffcf4e1  lea r12, [rax+0x08]
0000740ecffcf4e5  mov rax, [r13+r12*1]
0000740ecffcf4ea  movq xmm10, rax
0000740ecffcf4ef  movaps [r15+0x230], xmm10
0000740ecffcf4f7  lea rax, [r14+0x50]
0000740ecffcf4fb  movups xmm10, [r13+rax*1]
0000740ecffcf501  lea rax, [r14+0x60]
0000740ecffcf505  vmovaps [rsp+0xC0], xmm1
0000740ecffcf50e  movups xmm1, [r13+rax*1]
0000740ecffcf514  lea rax, [r14+0x30]
0000740ecffcf518  vmovaps [rsp+0xD0], xmm1
0000740ecffcf521  movups xmm1, [r13+rax*1]
0000740ecffcf527  mov qword ptr [r15+0x60], 0x430920
0000740ecffcf52f  mov qword ptr [r15+0x58], 0x40
0000740ecffcf537  vmovaps [rsp+0xE0], xmm1
0000740ecffcf540  vmovaps [rsp+0xF0], xmm15
0000740ecffcf549  vmovaps xmm15, [rsp+0xC0]
0000740ecffcf552  vmovaps [rsp+0xC0], xmm14
0000740ecffcf55b  vmovaps xmm14, [rsp+0x40]
0000740ecffcf561  vmovaps [rsp+0x40], xmm13
0000740ecffcf567  movaps xmm1, xmm15
0000740ecffcf56b  mulpd xmm1, xmm14
0000740ecffcf570  vcmppd xmm13, xmm1, xmm1, 0x03
0000740ecffcf575  ptest xmm13, xmm13
0000740ecffcf57b  jnz 0x0000740ECFFD0682
0000740ecffcf581  movq xmm14, qword ptr [r15+0x230]
0000740ecffcf58a  vmovaps [rsp+0x100], xmm14
0000740ecffcf593  vpermilpd xmm14, xmm14, 0x00
0000740ecffcf599  vmovaps [rsp+0x110], xmm1
0000740ecffcf5a2  vmovaps xmm1, [rsp+0xE0]
0000740ecffcf5ab  vmovaps [rsp+0xE0], xmm15
0000740ecffcf5b4  movaps xmm13, xmm1
0000740ecffcf5b8  mulpd xmm13, xmm14
0000740ecffcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
0000740ecffcf5c3  ptest xmm15, xmm15
0000740ecffcf5c9  jnz 0x0000740ECFFD07C4
0000740ecffcf5cf  vxorps xmm1, xmm1, xmm1
0000740ecffcf5d3  vpbroadcastq xmm1, xmm1
0000740ecffcf5d8  vmovaps xmm14, [rsp+0xE0]
0000740ecffcf5e1  vmovaps [rsp+0xE0], xmm1
0000740ecffcf5ea  vmovaps xmm1, [rsp+0xD0]
0000740ecffcf5f3  vmovaps [rsp+0xD0], xmm13
0000740ecffcf5fc  movaps xmm15, xmm14
0000740ecffcf600  mulpd xmm15, xmm1
0000740ecffcf605  vcmppd xmm13, xmm15, xmm15, 0x03
0000740ecffcf60b  ptest xmm13, xmm13
0000740ecffcf611  jnz 0x0000740ECFFD0907
0000740ecffcf617  movaps xmm1, xmm14
0000740ecffcf61b  mulpd xmm1, xmm10
0000740ecffcf620  vcmppd xmm13, xmm1, xmm1, 0x03
0000740ecffcf625  ptest xmm13, xmm13
0000740ecffcf62b  jnz 0x0000740ECFFD0A4A
0000740ecffcf631  movaps xmm13, xmm14
0000740ecffcf635  mulpd xmm13, xmm2
0000740ecffcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
0000740ecffcf640  ptest xmm10, xmm10
0000740ecffcf646  jnz 0x0000740ECFFD0B8C
0000740ecffcf64c  vmovaps [rsp+0x120], xmm7
0000740ecffcf655  vmovaps xmm14, [rsp+0x120]
0000740ecffcf65e  por xmm7, xmm14
0000740ecffcf663  vmovaps xmm14, [rsp+0xC0]
0000740ecffcf66c  vmovaps xmm10, [rsp+0xC0]
0000740ecffcf675  por xmm14, xmm10
0000740ecffcf67a  vmovaps xmm2, [rsp+0x100]
0000740ecffcf683  vpermilpd xmm2, xmm2, 0x00
0000740ecffcf689  vmovaps [rsp+0xC0], xmm1
0000740ecffcf692  vmovaps [rsp+0x120], xmm15
0000740ecffcf69b  movaps xmm1, xmm10
0000740ecffcf69f  mulpd xmm1, xmm2
0000740ecffcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
0000740ecffcf6a8  ptest xmm15, xmm15
0000740ecffcf6ae  jnz 0x0000740ECFFD0CCF
0000740ecffcf6b4  xor eax, eax
0000740ecffcf6b6  mov r12d, 0x40
0000740ecffcf6bc  mov r11d, 0x200
0000740ecffcf6c2  cmp r12, r11
0000740ecffcf6c5  cmc
0000740ecffcf6c6  lahf
0000740ecffcf6c7  seto al
0000740ecffcf6ca  mov [r15+0x108], eax
0000740ecffcf6d1  vmovaps xmm10, [rsp+0x110]
0000740ecffcf6da  vmovaps xmm2, [rsp+0xE0]
0000740ecffcf6e3  vmovaps [rsp+0xE0], xmm1
0000740ecffcf6ec  movaps xmm15, xmm10
0000740ecffcf6f0  addpd xmm15, xmm2
0000740ecffcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
0000740ecffcf6fb  ptest xmm1, xmm1
0000740ecffcf700  jnz 0x0000740ECFFD0E10
0000740ecffcf706  vmovaps xmm10, [rsp+0x120]
0000740ecffcf70f  vmovaps [rsp+0x110], xmm15
0000740ecffcf718  movaps xmm1, xmm10
0000740ecffcf71c  addpd xmm1, xmm12
0000740ecffcf721  vcmppd xmm15, xmm1, xmm1, 0x03
0000740ecffcf726  ptest xmm15, xmm15
0000740ecffcf72c  jnz 0x0000740ECFFD0F53
0000740ecffcf732  vmovaps xmm10, [rsp+0xC0]
0000740ecffcf73b  vmovaps [rsp+0xC0], xmm1
0000740ecffcf744  movaps xmm15, xmm10
0000740ecffcf748  addpd xmm15, xmm12
0000740ecffcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
0000740ecffcf753  ptest xmm1, xmm1
0000740ecffcf758  jnz 0x0000740ECFFD1095
0000740ecffcf75e  vmovaps xmm1, [rsp+0x30]
0000740ecffcf764  vmovaps xmm12, [rsp+0x30]
0000740ecffcf76a  por xmm1, xmm12
0000740ecffcf76f  vmovaps xmm12, [rsp+0x20]
0000740ecffcf775  vmovaps xmm10, [rsp+0x20]
0000740ecffcf77b  por xmm12, xmm10
0000740ecffcf780  vmovaps [rsp+0x20], xmm5
0000740ecffcf786  vmovaps xmm10, [rsp+0x20]
0000740ecffcf78c  por xmm5, xmm10
0000740ecffcf791  vmovaps [rsp+0x20], xmm11
0000740ecffcf797  vmovaps xmm10, [rsp+0x20]
0000740ecffcf79d  por xmm11, xmm10
0000740ecffcf7a2  vmovaps [rsp+0x20], xmm4
0000740ecffcf7a8  vmovaps xmm10, [rsp+0x20]
0000740ecffcf7ae  por xmm4, xmm10
0000740ecffcf7b3  vmovaps [rsp+0x20], xmm8
0000740ecffcf7b9  vmovaps xmm10, [rsp+0x20]
0000740ecffcf7bf  por xmm8, xmm10
0000740ecffcf7c4  vmovaps xmm10, [rsp+0xF0]
0000740ecffcf7cd  vmovaps [rsp+0x20], xmm1
0000740ecffcf7d3  vmovaps xmm1, [rsp+0xF0]
0000740ecffcf7dc  por xmm10, xmm1
0000740ecffcf7e1  lea rax, [r14+0xA0]
0000740ecffcf7e8  movups xmm1, [r13+rax*1]
0000740ecffcf7ee  lea rax, [r14+0xB0]
0000740ecffcf7f5  vmovaps [rsp+0x30], xmm1
0000740ecffcf7fb  movups xmm1, [r13+rax*1]
0000740ecffcf801  vmovaps [rsp+0xF0], xmm1
0000740ecffcf80a  vmovaps [rsp+0x120], xmm15
0000740ecffcf813  movaps xmm1, xmm13
0000740ecffcf817  addpd xmm1, xmm2
0000740ecffcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
0000740ecffcf820  ptest xmm15, xmm15
0000740ecffcf826  jnz 0x0000740ECFFD11ED
0000740ecffcf82c  lea rax, [r14+0xF0]
0000740ecffcf833  movups xmm15, [r13+rax*1]
0000740ecffcf839  vmovaps xmm2, [rsp+0xC0]
0000740ecffcf842  vmovaps [rsp+0xC0], xmm1
0000740ecffcf84b  vmovaps xmm1, [rsp+0xE0]
0000740ecffcf854  vmovaps [rsp+0xE0], xmm15
0000740ecffcf85d  movaps xmm13, xmm2
0000740ecffcf861  addpd xmm13, xmm1
0000740ecffcf866  vcmppd xmm15, xmm13, xmm13, 0x03
0000740ecffcf86c  ptest xmm15, xmm15
0000740ecffcf872  jnz 0x0000740ECFFD1338
0000740ecffcf878  vmovaps xmm15, [rsp+0x120]
0000740ecffcf881  vmovaps xmm2, [rsp+0xD0]
0000740ecffcf88a  vmovaps [rsp+0xD0], xmm14
0000740ecffcf893  movaps xmm1, xmm15
0000740ecffcf897  addpd xmm1, xmm2
0000740ecffcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
0000740ecffcf8a0  ptest xmm14, xmm14
0000740ecffcf8a6  jnz 0x0000740ECFFD147A
0000740ecffcf8ac  vmovaps xmm15, [rsp+0x100]
0000740ecffcf8b5  vpermilpd xmm15, xmm15, 0x00
0000740ecffcf8bb  vmovaps xmm2, [rsp+0xF0]
0000740ecffcf8c4  vmovaps [rsp+0xF0], xmm1
0000740ecffcf8cd  movaps xmm14, xmm2
0000740ecffcf8d1  mulpd xmm14, xmm15
0000740ecffcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
0000740ecffcf8dc  ptest xmm1, xmm1
0000740ecffcf8e1  jnz 0x0000740ECFFD15BB
0000740ecffcf8e7  vmovaps xmm1, [rsp+0xA0]
0000740ecffcf8f0  vpermilpd xmm1, xmm1, 0x00
0000740ecffcf8f6  vmovaps xmm2, [rsp+0xE0]
0000740ecffcf8ff  vmovaps [rsp+0xE0], xmm14
0000740ecffcf908  movaps xmm15, xmm2
0000740ecffcf90c  mulpd xmm15, xmm1
0000740ecffcf911  vcmppd xmm14, xmm15, xmm15, 0x03
0000740ecffcf917  ptest xmm14, xmm14
0000740ecffcf91d  jnz 0x0000740ECFFD16FE
0000740ecffcf923  lea rax, [r14+0xE0]
0000740ecffcf92a  movups xmm1, [r13+rax*1]
0000740ecffcf930  vmovaps xmm14, [rsp+0x100]
0000740ecffcf939  vpermilpd xmm14, xmm14, 0x00
0000740ecffcf93f  vmovaps [rsp+0x100], xmm1
0000740ecffcf948  vmovaps xmm1, [rsp+0x30]
0000740ecffcf94e  vmovaps [rsp+0x30], xmm15
0000740ecffcf954  movaps xmm2, xmm1
0000740ecffcf957  mulpd xmm2, xmm14
0000740ecffcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
0000740ecffcf961  ptest xmm15, xmm15
0000740ecffcf967  jnz 0x0000740ECFFD184A
0000740ecffcf96d  vmovaps [rsp+0x120], xmm10
0000740ecffcf976  vmovaps xmm1, [rsp+0x120]
0000740ecffcf97f  por xmm10, xmm1
0000740ecffcf984  movaps [r15+0x300], xmm10
0000740ecffcf98c  vmovaps [rsp+0x120], xmm8
0000740ecffcf995  vmovaps xmm1, [rsp+0x120]
0000740ecffcf99e  por xmm8, xmm1
0000740ecffcf9a3  movaps [r15+0x190], xmm8
0000740ecffcf9ab  vmovaps xmm1, [rsp+0xA0]
0000740ecffcf9b4  vpermilpd xmm1, xmm1, 0x00
0000740ecffcf9ba  vmovaps xmm14, [rsp+0x100]
0000740ecffcf9c3  vmovaps [rsp+0x100], xmm13
0000740ecffcf9cc  movaps xmm15, xmm14
0000740ecffcf9d0  mulpd xmm15, xmm1
0000740ecffcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
0000740ecffcf9db  ptest xmm13, xmm13
0000740ecffcf9e1  jnz 0x0000740ECFFD198B
0000740ecffcf9e7  lea rax, [r14+0x90]
0000740ecffcf9ee  movups xmm1, [r13+rax*1]
0000740ecffcf9f4  vmovaps [rsp+0x120], xmm4
0000740ecffcf9fd  vmovaps xmm14, [rsp+0x120]
0000740ecffcfa06  por xmm4, xmm14
0000740ecffcfa0b  movaps [r15+0x1C0], xmm4
0000740ecffcfa13  vmovaps [rsp+0x120], xmm11
0000740ecffcfa1c  vmovaps xmm14, [rsp+0x120]
0000740ecffcfa25  por xmm11, xmm14
0000740ecffcfa2a  movaps [r15+0x200], xmm11
0000740ecffcfa32  vmovaps [rsp+0x120], xmm5
0000740ecffcfa3b  vmovaps xmm14, [rsp+0x120]
0000740ecffcfa44  por xmm5, xmm14
0000740ecffcfa49  movaps [r15+0x2D0], xmm5
0000740ecffcfa51  vmovaps [rsp+0x120], xmm12
0000740ecffcfa5a  vmovaps xmm14, [rsp+0x120]
0000740ecffcfa63  por xmm12, xmm14
0000740ecffcfa68  movaps [r15+0x2E0], xmm12
0000740ecffcfa70  vmovaps xmm13, [rsp+0x110]
0000740ecffcfa79  vmovaps [rsp+0x110], xmm1
0000740ecffcfa82  vmovaps xmm1, [rsp+0xE0]
0000740ecffcfa8b  vmovaps [rsp+0xE0], xmm15
0000740ecffcfa94  movaps xmm14, xmm13
0000740ecffcfa98  addpd xmm14, xmm1
0000740ecffcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
0000740ecffcfaa3  ptest xmm15, xmm15
0000740ecffcfaa9  jnz 0x0000740ECFFD1AD8
0000740ecffcfaaf  vmovaps xmm1, [rsp+0xA0]
0000740ecffcfab8  vpermilpd xmm1, xmm1, 0x00
0000740ecffcfabe  vmovaps xmm13, [rsp+0x110]
0000740ecffcfac7  vmovaps [rsp+0x110], xmm14
0000740ecffcfad0  movaps xmm15, xmm13
0000740ecffcfad4  mulpd xmm15, xmm1
0000740ecffcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
0000740ecffcfadf  ptest xmm14, xmm14
0000740ecffcfae5  jnz 0x0000740ECFFD1C1B
0000740ecffcfaeb  lea rax, [r14+0x80]
0000740ecffcfaf2  movups xmm1, [r13+rax*1]
0000740ecffcfaf8  vmovaps xmm13, [rsp+0xC0]
0000740ecffcfb01  vmovaps [rsp+0xC0], xmm1
0000740ecffcfb0a  movaps xmm14, xmm13
0000740ecffcfb0e  addpd xmm14, xmm2
0000740ecffcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
0000740ecffcfb19  ptest xmm1, xmm1
0000740ecffcfb1e  jnz 0x0000740ECFFD1D68
0000740ecffcfb24  vmovaps xmm13, [rsp+0x100]
0000740ecffcfb2d  vmovaps xmm2, [rsp+0x30]
0000740ecffcfb33  vmovaps [rsp+0x30], xmm15
0000740ecffcfb39  movaps xmm1, xmm13
0000740ecffcfb3d  addpd xmm1, xmm2
0000740ecffcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
0000740ecffcfb46  ptest xmm15, xmm15
0000740ecffcfb4c  jnz 0x0000740ECFFD1EAB
0000740ecffcfb52  vmovaps xmm15, [rsp+0x20]
0000740ecffcfb58  vmovaps xmm13, [rsp+0x20]
0000740ecffcfb5e  por xmm15, xmm13
0000740ecffcfb63  movaps [r15+0x2F0], xmm15
0000740ecffcfb6b  vmovaps xmm13, [rsp+0xA0]
0000740ecffcfb74  vpermilpd xmm13, xmm13, 0x00
0000740ecffcfb7a  vmovaps [rsp+0x20], xmm1
0000740ecffcfb80  vmovaps xmm1, [rsp+0xC0]
0000740ecffcfb89  vmovaps [rsp+0xA0], xmm15
0000740ecffcfb92  movaps xmm2, xmm1
0000740ecffcfb95  mulpd xmm2, xmm13
0000740ecffcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
0000740ecffcfb9f  ptest xmm15, xmm15
0000740ecffcfba5  jnz 0x0000740ECFFD1FEC
0000740ecffcfbab  lea rax, [r14+0xD0]
0000740ecffcfbb2  movups xmm1, [r13+rax*1]
0000740ecffcfbb8  vmovaps xmm13, [rsp+0xF0]
0000740ecffcfbc1  vmovaps [rsp+0xC0], xmm1
0000740ecffcfbca  vmovaps xmm1, [rsp+0xE0]
0000740ecffcfbd3  vmovaps [rsp+0xE0], xmm14
0000740ecffcfbdc  movaps xmm15, xmm13
0000740ecffcfbe0  addpd xmm15, xmm1
0000740ecffcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
0000740ecffcfbeb  ptest xmm14, xmm14
0000740ecffcfbf1  jnz 0x0000740ECFFD2137
0000740ecffcfbf7  vmovaps xmm1, [rsp+0xB0]
0000740ecffcfc00  vpermilpd xmm1, xmm1, 0x00
0000740ecffcfc06  movaps xmm14, xmm11
0000740ecffcfc0a  mulpd xmm14, xmm1
0000740ecffcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
0000740ecffcfc15  ptest xmm13, xmm13
0000740ecffcfc1b  jnz 0x0000740ECFFD227A
0000740ecffcfc21  movaps [r15+0x260], xmm14
0000740ecffcfc29  vxorps xmm1, xmm1, xmm1
0000740ecffcfc2d  vpbroadcastq xmm1, xmm1
0000740ecffcfc32  movaps [r15+0x1B0], xmm1
0000740ecffcfc3a  vmovaps xmm1, [rsp+0xB0]
0000740ecffcfc43  vpermilpd xmm1, xmm1, 0x00
0000740ecffcfc49  vmovaps xmm11, [rsp+0xC0]
0000740ecffcfc52  vmovaps [rsp+0xC0], xmm15
0000740ecffcfc5b  movaps xmm13, xmm11
0000740ecffcfc5f  mulpd xmm13, xmm1
0000740ecffcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
0000740ecffcfc6a  ptest xmm15, xmm15
0000740ecffcfc70  jnz 0x0000740ECFFD23BD
0000740ecffcfc76  lea rax, [r14+0xC0]
0000740ecffcfc7d  movups xmm1, [r13+rax*1]
0000740ecffcfc83  vmovaps xmm11, [rsp+0x110]
0000740ecffcfc8c  vmovaps [rsp+0xF0], xmm1
0000740ecffcfc95  vmovaps xmm1, [rsp+0x30]
0000740ecffcfc9b  vmovaps [rsp+0x30], xmm14
0000740ecffcfca1  movaps xmm15, xmm11
0000740ecffcfca5  addpd xmm15, xmm1
0000740ecffcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
0000740ecffcfcb0  ptest xmm14, xmm14
0000740ecffcfcb6  jnz 0x0000740ECFFD250A
0000740ecffcfcbc  vmovaps [rsp+0x100], xmm9
0000740ecffcfcc5  vmovaps xmm1, [rsp+0x100]
0000740ecffcfcce  por xmm9, xmm1
0000740ecffcfcd3  movaps [r15+0x270], xmm9
0000740ecffcfcdb  vmovaps [rsp+0x100], xmm6
0000740ecffcfce4  vmovaps xmm1, [rsp+0x100]
0000740ecffcfced  por xmm6, xmm1
0000740ecffcfcf1  movaps [r15+0x1A0], xmm6
0000740ecffcfcf9  vmovaps xmm14, [rsp+0xB0]
0000740ecffcfd02  vpermilpd xmm14, xmm14, 0x00
0000740ecffcfd08  vmovaps xmm6, [rsp+0xF0]
0000740ecffcfd11  vmovaps [rsp+0xF0], xmm1
0000740ecffcfd1a  movaps xmm11, xmm6
0000740ecffcfd1e  mulpd xmm11, xmm14
0000740ecffcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
0000740ecffcfd29  ptest xmm1, xmm1
0000740ecffcfd2e  jnz 0x0000740ECFFD264D
0000740ecffcfd34  lea rax, [r14+0x20]
0000740ecffcfd38  movups xmm1, [r13+rax*1]
0000740ecffcfd3e  movaps [r15+0x110], xmm1
0000740ecffcfd46  vmovaps xmm6, [rsp+0xE0]
0000740ecffcfd4f  vmovaps [rsp+0xE0], xmm1
0000740ecffcfd58  movaps xmm14, xmm6
0000740ecffcfd5c  addpd xmm14, xmm2
0000740ecffcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
0000740ecffcfd67  ptest xmm1, xmm1
0000740ecffcfd6c  jnz 0x0000740ECFFD279A
0000740ecffcfd72  vmovaps xmm1, [rsp+0xB0]
0000740ecffcfd7b  vpermilpd xmm1, xmm1, 0x00
0000740ecffcfd81  movaps xmm6, xmm5
0000740ecffcfd84  mulpd xmm6, xmm1
0000740ecffcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
0000740ecffcfd8d  ptest xmm2, xmm2
0000740ecffcfd92  jnz 0x0000740ECFFD28DC
0000740ecffcfd98  vmovaps xmm5, [rsp+0x20]
0000740ecffcfd9e  movaps xmm1, xmm5
0000740ecffcfda1  addpd xmm1, xmm13
0000740ecffcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
0000740ecffcfdab  ptest xmm2, xmm2
0000740ecffcfdb0  jnz 0x0000740ECFFD2A1C
0000740ecffcfdb6  vmovaps xmm13, [rsp+0x80]
0000740ecffcfdbf  vpermilpd xmm13, xmm13, 0x00
0000740ecffcfdc5  vmovaps xmm2, [rsp+0xE0]
0000740ecffcfdce  vmovaps [rsp+0x20], xmm1
0000740ecffcfdd4  movaps xmm5, xmm2
0000740ecffcfdd7  mulpd xmm5, xmm13
0000740ecffcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
0000740ecffcfde1  ptest xmm1, xmm1
0000740ecffcfde6  jnz 0x0000740ECFFD2B5D
0000740ecffcfdec  vmovaps xmm1, [rsp+0x80]
0000740ecffcfdf5  vpermilpd xmm1, xmm1, 0x00
0000740ecffcfdfb  movaps xmm13, xmm10
0000740ecffcfdff  mulpd xmm13, xmm1
0000740ecffcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
0000740ecffcfe0a  ptest xmm2, xmm2
0000740ecffcfe0f  jnz 0x0000740ECFFD2C9E
0000740ecffcfe15  vmovaps xmm10, [rsp+0x30]
0000740ecffcfe1b  movaps xmm1, xmm15
0000740ecffcfe1f  addpd xmm1, xmm10
0000740ecffcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
0000740ecffcfe29  ptest xmm2, xmm2
0000740ecffcfe2e  jnz 0x0000740ECFFD2DE1
0000740ecffcfe34  vmovaps xmm10, [rsp+0xC0]
0000740ecffcfe3d  movaps xmm15, xmm10
0000740ecffcfe41  addpd xmm15, xmm11
0000740ecffcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
0000740ecffcfe4c  ptest xmm2, xmm2
0000740ecffcfe51  jnz 0x0000740ECFFD2F23
0000740ecffcfe57  vmovaps xmm11, [rsp+0x80]
0000740ecffcfe60  vpermilpd xmm11, xmm11, 0x00
0000740ecffcfe66  movaps xmm10, xmm12
0000740ecffcfe6a  mulpd xmm10, xmm11
0000740ecffcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
0000740ecffcfe75  ptest xmm2, xmm2
0000740ecffcfe7a  jnz 0x0000740ECFFD3067
0000740ecffcfe80  vmovaps xmm12, [rsp+0x80]
0000740ecffcfe89  vpermilpd xmm12, xmm12, 0x00
0000740ecffcfe8f  vmovaps xmm2, [rsp+0xA0]
0000740ecffcfe98  vmovaps [rsp+0x30], xmm1
0000740ecffcfe9e  movaps xmm11, xmm2
0000740ecffcfea2  mulpd xmm11, xmm12
0000740ecffcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
0000740ecffcfead  ptest xmm1, xmm1
0000740ecffcfeb2  jnz 0x0000740ECFFD31AB
0000740ecffcfeb8  movaps xmm1, xmm14
0000740ecffcfebc  addpd xmm1, xmm6
0000740ecffcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
0000740ecffcfec5  ptest xmm12, xmm12
0000740ecffcfecb  jnz 0x0000740ECFFD32EE
0000740ecffcfed1  vmovaps xmm12, [rsp+0x20]
0000740ecffcfed7  movaps xmm14, xmm12
0000740ecffcfedb  addpd xmm14, xmm5
0000740ecffcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
0000740ecffcfee6  ptest xmm6, xmm6
0000740ecffcfeeb  jnz 0x0000740ECFFD342F
0000740ecffcfef1  vmovaps xmm12, [rsp+0x90]
0000740ecffcfefa  vpermilpd xmm12, xmm12, 0x00
0000740ecffcff00  movaps xmm6, xmm9
0000740ecffcff04  mulpd xmm6, xmm12
0000740ecffcff09  vcmppd xmm5, xmm6, xmm6, 0x03
0000740ecffcff0e  ptest xmm5, xmm5
0000740ecffcff13  jnz 0x0000740ECFFD3572
0000740ecffcff19  movaps xmm12, xmm15
0000740ecffcff1d  addpd xmm12, xmm13
0000740ecffcff22  vcmppd xmm9, xmm12, xmm12, 0x03
0000740ecffcff28  ptest xmm9, xmm9
0000740ecffcff2e  jnz 0x0000740ECFFD36B4
0000740ecffcff34  vmovaps xmm13, [rsp+0x30]
0000740ecffcff3a  movaps xmm15, xmm13
0000740ecffcff3e  addpd xmm15, xmm10
0000740ecffcff43  vcmppd xmm9, xmm15, xmm15, 0x03
0000740ecffcff49  ptest xmm9, xmm9
0000740ecffcff4f  jnz 0x0000740ECFFD37F8
0000740ecffcff55  vmovaps xmm13, [rsp+0xD0]
0000740ecffcff5e  vmovaps xmm10, [rsp+0xD0]
0000740ecffcff67  por xmm13, xmm10
0000740ecffcff6c  movaps [r15+0x250], xmm13
0000740ecffcff74  vmovaps [rsp+0x20], xmm7
0000740ecffcff7a  vmovaps xmm13, [rsp+0x20]
0000740ecffcff80  por xmm7, xmm13
0000740ecffcff85  movaps [r15+0x2A0], xmm7
0000740ecffcff8d  vmovaps [rsp+0x20], xmm3
0000740ecffcff93  vmovaps xmm13, [rsp+0x20]
0000740ecffcff99  por xmm3, xmm13
0000740ecffcff9e  movaps [r15+0x1D0], xmm3
0000740ecffcffa6  lea rax, [r14+0x40]
0000740ecffcffaa  movups xmm13, [r13+rax*1]
0000740ecffcffb0  movaps [r15+0x2C0], xmm13
0000740ecffcffb8  vmovaps xmm10, [rsp+0x90]
0000740ecffcffc1  vpermilpd xmm10, xmm10, 0x00
0000740ecffcffc7  movaps xmm9, xmm8
0000740ecffcffcb  mulpd xmm9, xmm10
0000740ecffcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
0000740ecffcffd6  ptest xmm5, xmm5
0000740ecffcffdb  jnz 0x0000740ECFFD3946
0000740ecffcffe1  movaps xmm10, xmm1
0000740ecffcffe5  addpd xmm10, xmm11
0000740ecffcffea  vcmppd xmm8, xmm10, xmm10, 0x03
0000740ecffcfff0  ptest xmm8, xmm8
0000740ecffcfff6  jnz 0x0000740ECFFD3A8A
0000740ecffcfffc  movaps xmm1, xmm14
0000740ecffd0000  addpd xmm1, xmm6
0000740ecffd0004  vcmppd xmm11, xmm1, xmm1, 0x03
0000740ecffd0009  ptest xmm11, xmm11
0000740ecffd000f  jnz 0x0000740ECFFD3BCD
0000740ecffd0015  vmovaps xmm14, [rsp+0x90]
0000740ecffd001e  vpermilpd xmm14, xmm14, 0x00
0000740ecffd0024  movaps xmm11, xmm13
0000740ecffd0028  mulpd xmm11, xmm14
0000740ecffd002d  vcmppd xmm8, xmm11, xmm11, 0x03
0000740ecffd0033  ptest xmm8, xmm8
0000740ecffd0039  jnz 0x0000740ECFFD3D0E
0000740ecffd003f  vmovaps xmm14, [rsp+0x90]
0000740ecffd0048  vpermilpd xmm14, xmm14, 0x00
0000740ecffd004e  vmovaps xmm8, [rsp+0x10]
0000740ecffd0054  movaps xmm13, xmm8
0000740ecffd0058  mulpd xmm13, xmm14
0000740ecffd005d  vcmppd xmm6, xmm13, xmm13, 0x03
0000740ecffd0063  ptest xmm6, xmm6
0000740ecffd0068  jnz 0x0000740ECFFD3E52
0000740ecffd006e  vmovaps xmm14, [rsp+0x60]
0000740ecffd0074  vpermilpd xmm14, xmm14, 0x00
0000740ecffd007a  movaps xmm8, xmm7
0000740ecffd007e  mulpd xmm8, xmm14
0000740ecffd0083  vcmppd xmm6, xmm8, xmm8, 0x03
0000740ecffd0089  ptest xmm6, xmm6
0000740ecffd008e  jnz 0x0000740ECFFD3F96
0000740ecffd0094  movaps xmm14, xmm12
0000740ecffd0098  addpd xmm14, xmm9
0000740ecffd009d  vcmppd xmm7, xmm14, xmm14, 0x03
0000740ecffd00a3  ptest xmm7, xmm7
0000740ecffd00a8  jnz 0x0000740ECFFD40D9
0000740ecffd00ae  vmovaps xmm12, [rsp+0x60]
0000740ecffd00b4  vpermilpd xmm12, xmm12, 0x00
0000740ecffd00ba  vmovaps xmm7, [rsp+0xF0]
0000740ecffd00c3  movaps xmm9, xmm7
0000740ecffd00c7  mulpd xmm9, xmm12
0000740ecffd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
0000740ecffd00d2  ptest xmm6, xmm6
0000740ecffd00d7  jnz 0x0000740ECFFD421D
0000740ecffd00dd  movaps xmm12, xmm15
0000740ecffd00e1  addpd xmm12, xmm11
0000740ecffd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
0000740ecffd00ec  ptest xmm7, xmm7
0000740ecffd00f1  jnz 0x0000740ECFFD4360
0000740ecffd00f7  vmovaps xmm15, [rsp+0x60]
0000740ecffd00fd  vpermilpd xmm15, xmm15, 0x00
0000740ecffd0103  vmovaps xmm7, [rsp+0x40]
0000740ecffd0109  movaps xmm11, xmm7
0000740ecffd010d  mulpd xmm11, xmm15
0000740ecffd0112  vcmppd xmm6, xmm11, xmm11, 0x03
0000740ecffd0118  ptest xmm6, xmm6
0000740ecffd011d  jnz 0x0000740ECFFD44A4
0000740ecffd0123  movaps xmm15, xmm10
0000740ecffd0127  addpd xmm15, xmm13
0000740ecffd012c  vcmppd xmm7, xmm15, xmm15, 0x03
0000740ecffd0132  ptest xmm7, xmm7
0000740ecffd0137  jnz 0x0000740ECFFD45E7
0000740ecffd013d  vmovaps xmm13, [rsp+0x60]
0000740ecffd0143  vpermilpd xmm13, xmm13, 0x00
0000740ecffd0149  vmovaps xmm7, [rsp+0x50]
0000740ecffd014f  movaps xmm10, xmm7
0000740ecffd0153  mulpd xmm10, xmm13
0000740ecffd0158  vcmppd xmm6, xmm10, xmm10, 0x03
0000740ecffd015e  ptest xmm6, xmm6
0000740ecffd0163  jnz 0x0000740ECFFD472B
0000740ecffd0169  movaps xmm13, xmm1
0000740ecffd016d  addpd xmm13, xmm8
0000740ecffd0172  vcmppd xmm7, xmm13, xmm13, 0x03
0000740ecffd0178  ptest xmm7, xmm7
0000740ecffd017d  jnz 0x0000740ECFFD486E
0000740ecffd0183  lea rax, [r14+0x70]
0000740ecffd0187  movups xmm1, [r13+rax*1]
0000740ecffd018d  movaps [r15+0x240], xmm1
0000740ecffd0195  movaps xmm8, xmm14
0000740ecffd0199  addpd xmm8, xmm9
0000740ecffd019e  vcmppd xmm7, xmm8, xmm8, 0x03
0000740ecffd01a4  ptest xmm7, xmm7
0000740ecffd01a9  jnz 0x0000740ECFFD49BB
0000740ecffd01af  movaps [r15+0x170], xmm8
0000740ecffd01b7  vmovaps xmm14, [rsp+0x70]
0000740ecffd01bd  vpermilpd xmm14, xmm14, 0x00
0000740ecffd01c3  movaps xmm9, xmm1
0000740ecffd01c7  mulpd xmm9, xmm14
0000740ecffd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
0000740ecffd01d2  ptest xmm7, xmm7
0000740ecffd01d7  jnz 0x0000740ECFFD4AFF
0000740ecffd01dd  vmovaps xmm1, [rsp+0x70]
0000740ecffd01e3  vpermilpd xmm1, xmm1, 0x00
0000740ecffd01e9  movaps xmm14, xmm4
0000740ecffd01ed  mulpd xmm14, xmm1
0000740ecffd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
0000740ecffd01f8  ptest xmm7, xmm7
0000740ecffd01fd  jnz 0x0000740ECFFD4C42
0000740ecffd0203  movaps [r15+0x180], xmm14
0000740ecffd020b  movaps xmm1, xmm12
0000740ecffd020f  addpd xmm1, xmm11
0000740ecffd0214  vcmppd xmm7, xmm1, xmm1, 0x03
0000740ecffd0219  ptest xmm7, xmm7
0000740ecffd021e  jnz 0x0000740ECFFD4D84
0000740ecffd0224  movaps [r15+0x210], xmm1
0000740ecffd022c  movups xmm12, [r13+r14*1]
0000740ecffd0232  lea rax, [r14+0x10]
0000740ecffd0236  movups xmm11, [r13+rax*1]
0000740ecffd023c  movaps [r15+0x230], xmm11
0000740ecffd0244  movaps xmm7, xmm15
0000740ecffd0248  addpd xmm7, xmm10
0000740ecffd024d  vcmppd xmm6, xmm7, xmm7, 0x03
0000740ecffd0252  ptest xmm6, xmm6
0000740ecffd0257  jnz 0x0000740ECFFD4EDA
0000740ecffd025d  movaps [r15+0x130], xmm7
0000740ecffd0265  vmovaps xmm15, [rsp+0x70]
0000740ecffd026b  vpermilpd xmm15, xmm15, 0x00
0000740ecffd0271  movaps xmm10, xmm11
0000740ecffd0275  mulpd xmm10, xmm15
0000740ecffd027a  vcmppd xmm6, xmm10, xmm10, 0x03
0000740ecffd0280  ptest xmm6, xmm6
0000740ecffd0285  jnz 0x0000740ECFFD501C
0000740ecffd028b  movaps [r15+0x220], xmm10
0000740ecffd0293  vmovaps xmm15, [rsp+0x70]
0000740ecffd0299  vpermilpd xmm15, xmm15, 0x00
0000740ecffd029f  movaps xmm11, xmm12
0000740ecffd02a3  mulpd xmm11, xmm15
0000740ecffd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
0000740ecffd02ae  ptest xmm6, xmm6
0000740ecffd02b3  jnz 0x0000740ECFFD5160
0000740ecffd02b9  movaps xmm15, xmm13
0000740ecffd02bd  addpd xmm15, xmm9
0000740ecffd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
0000740ecffd02c8  ptest xmm12, xmm12
0000740ecffd02ce  jnz 0x0000740ECFFD52A4
0000740ecffd02d4  movaps [r15+0x140], xmm15
0000740ecffd02dc  movaps xmm13, xmm8
0000740ecffd02e0  addpd xmm13, xmm14
0000740ecffd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
0000740ecffd02eb  ptest xmm12, xmm12
0000740ecffd02f1  jnz 0x0000740ECFFD53E8
0000740ecffd02f7  movaps [r15+0x150], xmm13
0000740ecffd02ff  movaps xmm14, xmm1
0000740ecffd0303  addpd xmm14, xmm10
0000740ecffd0308  vcmppd xmm12, xmm14, xmm14, 0x03
0000740ecffd030e  ptest xmm12, xmm12
0000740ecffd0314  jnz 0x0000740ECFFD552C
0000740ecffd031a  movaps [r15+0x160], xmm14
0000740ecffd0322  movaps xmm1, xmm7
0000740ecffd0325  addpd xmm1, xmm11
0000740ecffd032a  vcmppd xmm12, xmm1, xmm1, 0x03
0000740ecffd032f  ptest xmm12, xmm12
0000740ecffd0335  jnz 0x0000740ECFFD566F
0000740ecffd033b  movaps [r15+0x120], xmm1
0000740ecffd0343  mov eax, 0x430920
0000740ecffd0348  movups [r13+rax*1], xmm15
0000740ecffd034e  mov eax, 0x430930
0000740ecffd0353  movups [r13+rax*1], xmm13
0000740ecffd0359  mov eax, 0x430940
0000740ecffd035e  movups [r13+rax*1], xmm14
0000740ecffd0364  mov eax, 0x430950
0000740ecffd0369  movups [r13+rax*1], xmm1
0000740ecffd036f  mov eax, [r15+0x108]
0000740ecffd0376  sahf
0000740ecffd0377  jnz 0x0000740ECFFD03A9
0000740ecffd0379  cmp dword ptr [r15+0x318], 0x00
0000740ecffd0381  jz 0x0000740ECFFDB900
0000740ecffd0387  nop [rax+rax*1], ax
0000740ecffd0390  nop [rax+rax*1], eax
0000740ecffd0398  mov eax, 0x410444
0000740ecffd039d  mov [r15+0x100], rax
0000740ecffd03a4  jmp 0x0000740ECFDFE110
0000740ecffd03a9  cmp dword ptr [r15+0x318], 0x00
0000740ecffd03b1  jz 0x0000740ECFFD57E0
0000740ecffd03b7  nop [rax+rax*1], ax
0000740ecffd03c0  nop [rax+rax*1], eax
0000740ecffd03c8  mov eax, 0x410278
0000740ecffd03cd  mov [r15+0x100], rax
0000740ecffd03d4  jmp 0x0000740ECFDFE110
0000740ecffd03d9  int3
0000740ecffd03da  call 0x0000740ECFEB52F0
0000740ecffd03df  jmp 0x0000740ECFFCF016
0000740ecffd03e4  call 0x0000740ECFEC4620
0000740ecffd03e9  jmp 0x0000740ECFFCF023
0000740ecffd03ee  call 0x0000740ECFEC33A0
0000740ecffd03f3  jmp 0x0000740ECFFCF035
0000740ecffd03f8  call 0x0000740ECFEC2120
0000740ecffd03fd  jmp 0x0000740ECFFCF03F
0000740ecffd0402  call 0x0000740ECFEC0860
0000740ecffd0407  jmp 0x0000740ECFFCF067
0000740ecffd040c  call 0x0000740ECFEBF5F0
0000740ecffd0411  jmp 0x0000740ECFFCF073
0000740ecffd0416  call 0x0000740ECFEC0860
0000740ecffd041b  jmp 0x0000740ECFFCF0A5
0000740ecffd0420  call 0x0000740ECFEBF5F0
0000740ecffd0425  jmp 0x0000740ECFFCF0B1
0000740ecffd042a  call 0x0000740ECFEC4740
0000740ecffd042f  jmp 0x0000740ECFFCF0BE
0000740ecffd0434  call 0x0000740ECFEB5400
0000740ecffd0439  jmp 0x0000740ECFFCF0CB
0000740ecffd043e  call 0x0000740ECFEB52F0
0000740ecffd0443  jmp 0x0000740ECFFCF0D8
0000740ecffd0448  call 0x0000740ECFEC4620
0000740ecffd044d  jmp 0x0000740ECFFCF0E5
0000740ecffd0452  call 0x0000740ECFEC0860
0000740ecffd0457  jmp 0x0000740ECFFCF10D
0000740ecffd045c  call 0x0000740ECFEBF5F0
0000740ecffd0461  jmp 0x0000740ECFFCF119
0000740ecffd0466  call 0x0000740ECFE09D70
0000740ecffd046b  jmp 0x0000740ECFFCF11F
0000740ecffd0470  call 0x0000740ECFEBE9C0
0000740ecffd0475  jmp 0x0000740ECFFCF129
0000740ecffd047a  call 0x0000740ECFEC0860
0000740ecffd047f  jmp 0x0000740ECFFCF151
0000740ecffd0484  call 0x0000740ECFEBF5F0
0000740ecffd0489  jmp 0x0000740ECFFCF15D
0000740ecffd048e  call 0x0000740ECFEBD750
0000740ecffd0493  jmp 0x0000740ECFFCF16A
0000740ecffd0498  call 0x0000740ECFEBC4E0
0000740ecffd049d  jmp 0x0000740ECFFCF177
0000740ecffd04a2  call 0x0000740ECFEC4740
0000740ecffd04a7  jmp 0x0000740ECFFCF184
0000740ecffd04ac  call 0x0000740ECFEB5400
0000740ecffd04b1  jmp 0x0000740ECFFCF191
0000740ecffd04b6  call 0x0000740ECFEB52F0
0000740ecffd04bb  jmp 0x0000740ECFFCF19E
0000740ecffd04c0  call 0x0000740ECFEC4620
0000740ecffd04c5  jmp 0x0000740ECFFCF1AB
0000740ecffd04ca  call 0x0000740ECFEC0860
0000740ecffd04cf  jmp 0x0000740ECFFCF1BE
0000740ecffd04d4  call 0x0000740ECFEBB270
0000740ecffd04d9  jmp 0x0000740ECFFCF1CB
0000740ecffd04de  call 0x0000740ECFEBA000
0000740ecffd04e3  jmp 0x0000740ECFFCF1D8
0000740ecffd04e8  call 0x0000740ECFEB8D90
0000740ecffd04ed  jmp 0x0000740ECFFCF1E5
0000740ecffd04f2  call 0x0000740ECFEB8A20
0000740ecffd04f7  jmp 0x0000740ECFFCF1F2
0000740ecffd04fc  call 0x0000740ECFEB5400
0000740ecffd0501  jmp 0x0000740ECFFCF1FC
0000740ecffd0506  call 0x0000740ECFEC2240
0000740ecffd050b  jmp 0x0000740ECFFCF206
0000740ecffd0510  call 0x0000740ECFEB52F0
0000740ecffd0515  jmp 0x0000740ECFFCF210
0000740ecffd051a  call 0x0000740ECFEC2120
0000740ecffd051f  jmp 0x0000740ECFFCF21A
0000740ecffd0524  call 0x0000740ECFEB77B0
0000740ecffd0529  jmp 0x0000740ECFFCF224
0000740ecffd052e  call 0x0000740ECFEB6550
0000740ecffd0533  jmp 0x0000740ECFFCF22E
0000740ecffd0538  call 0x0000740ECFEBFD50
0000740ecffd053d  jmp 0x0000740ECFFCF240
0000740ecffd0542  call 0x0000740ECFEB8EA0
0000740ecffd0547  jmp 0x0000740ECFFCF24A
0000740ecffd054c  call 0x0000740ECFEBFC30
0000740ecffd0551  jmp 0x0000740ECFFCF257
0000740ecffd0556  call 0x0000740ECFEB8D90
0000740ecffd055b  jmp 0x0000740ECFFCF264
0000740ecffd0560  call 0x0000740ECFEC2240
0000740ecffd0565  jmp 0x0000740ECFFCF271
0000740ecffd056a  call 0x0000740ECFEB5400
0000740ecffd056f  jmp 0x0000740ECFFCF27E
0000740ecffd0574  call 0x0000740ECFEB52F0
0000740ecffd0579  jmp 0x0000740ECFFCF28B
0000740ecffd057e  call 0x0000740ECFEC2120
0000740ecffd0583  jmp 0x0000740ECFFCF298
0000740ecffd0588  call 0x0000740ECFEB52F0
0000740ecffd058d  jmp 0x0000740ECFFCF2AB
0000740ecffd0592  call 0x0000740ECFEB52F0
0000740ecffd0597  jmp 0x0000740ECFFCF2BE
0000740ecffd059c  call 0x0000740ECFEB52F0
0000740ecffd05a1  jmp 0x0000740ECFFCF2D1
0000740ecffd05a6  call 0x0000740ECFEB52F0
0000740ecffd05ab  jmp 0x0000740ECFFCF2E4
0000740ecffd05b0  call 0x0000740ECFEC2240
0000740ecffd05b5  jmp 0x0000740ECFFCF2F9
0000740ecffd05ba  call 0x0000740ECFEC2240
0000740ecffd05bf  jmp 0x0000740ECFFCF30C
0000740ecffd05c4  call 0x0000740ECFEC2120
0000740ecffd05c9  jmp 0x0000740ECFFCF319
0000740ecffd05ce  call 0x0000740ECFEB52F0
0000740ecffd05d3  jmp 0x0000740ECFFCF32C
0000740ecffd05d8  call 0x0000740ECFEB52F0
0000740ecffd05dd  jmp 0x0000740ECFFCF34F
0000740ecffd05e2  call 0x0000740ECFEB52F0
0000740ecffd05e7  jmp 0x0000740ECFFCF362
0000740ecffd05ec  call 0x0000740ECFDFF540
0000740ecffd05f1  jmp 0x0000740ECFFCF380
0000740ecffd05f6  call 0x0000740ECFE08C20
0000740ecffd05fb  jmp 0x0000740ECFFCF38A
0000740ecffd0600  call 0x0000740ECFED6600
0000740ecffd0605  jmp 0x0000740ECFFCF396
0000740ecffd060a  call 0x0000740ECFDFF540
0000740ecffd060f  jmp 0x0000740ECFFCF3A6
0000740ecffd0614  call 0x0000740ECFEC0370
0000740ecffd0619  jmp 0x0000740ECFFCF3D4
0000740ecffd061e  call 0x0000740ECFEBF100
0000740ecffd0623  jmp 0x0000740ECFFCF3DD
0000740ecffd0628  call 0x0000740ECFEC0370
0000740ecffd062d  jmp 0x0000740ECFFCF43B
0000740ecffd0632  call 0x0000740ECFEBF100
0000740ecffd0637  jmp 0x0000740ECFFCF444
0000740ecffd063c  call 0x0000740ECFEC0370
0000740ecffd0641  jmp 0x0000740ECFFCF48B
0000740ecffd0646  call 0x0000740ECFEBF100
0000740ecffd064b  jmp 0x0000740ECFFCF494
0000740ecffd0650  call 0x0000740ECFE0B720
0000740ecffd0655  jmp 0x0000740ECFFCF4D7
0000740ecffd065a  call 0x0000740ECFEB47C0
0000740ecffd065f  jmp 0x0000740ECFFCF4EA
0000740ecffd0664  call 0x0000740ECFE08B00
0000740ecffd0669  jmp 0x0000740ECFFCF501
0000740ecffd066e  call 0x0000740ECFDFF430
0000740ecffd0673  jmp 0x0000740ECFFCF514
0000740ecffd0678  call 0x0000740ECFDFF430
0000740ecffd067d  jmp 0x0000740ECFFCF527
0000740ecffd0682  sub rsp, 0x08
0000740ecffd0686  push rax
0000740ecffd0687  push rcx
0000740ecffd0688  push rdx
0000740ecffd0689  push rdi
0000740ecffd068a  push rsi
0000740ecffd068b  push r8
0000740ecffd068d  push r9
0000740ecffd068f  push r10
0000740ecffd0691  push r11
0000740ecffd0693  sub rsp, 0xF0
0000740ecffd069a  vmovaps [rsp], xmm0
0000740ecffd069f  vmovaps [rsp+0x10], xmm2
0000740ecffd06a5  vmovaps [rsp+0x20], xmm3
0000740ecffd06ab  vmovaps [rsp+0x30], xmm4
0000740ecffd06b1  vmovaps [rsp+0x40], xmm5
0000740ecffd06b7  vmovaps [rsp+0x50], xmm6
0000740ecffd06bd  vmovaps [rsp+0x60], xmm7
0000740ecffd06c3  vmovaps [rsp+0x70], xmm8
0000740ecffd06c9  vmovaps [rsp+0x80], xmm9
0000740ecffd06d2  vmovaps [rsp+0x90], xmm10
0000740ecffd06db  vmovaps [rsp+0xA0], xmm11
0000740ecffd06e4  vmovaps [rsp+0xB0], xmm12
0000740ecffd06ed  vmovaps [rsp+0xC0], xmm13
0000740ecffd06f6  vmovaps [rsp+0xD0], xmm14
0000740ecffd06ff  vmovaps [rsp+0xE0], xmm15
0000740ecffd0708  sub rsp, 0x30
0000740ecffd070c  movaps [rsp], xmm1
0000740ecffd0710  movaps [rsp+0x10], xmm15
0000740ecffd0716  movaps [rsp+0x20], xmm14
0000740ecffd071c  lea rdi, [rsp]
0000740ecffd0720  mov esi, 0x00
0000740ecffd0725  mov rax, 0x5E8249CF1530
0000740ecffd072f  call rax
0000740ecffd0731  movaps xmm1, [rsp]
0000740ecffd0735  add rsp, 0x30
0000740ecffd0739  vmovaps xmm0, [rsp]
0000740ecffd073e  vmovaps xmm2, [rsp+0x10]
0000740ecffd0744  vmovaps xmm3, [rsp+0x20]
0000740ecffd074a  vmovaps xmm4, [rsp+0x30]
0000740ecffd0750  vmovaps xmm5, [rsp+0x40]
0000740ecffd0756  vmovaps xmm6, [rsp+0x50]
0000740ecffd075c  vmovaps xmm7, [rsp+0x60]
0000740ecffd0762  vmovaps xmm8, [rsp+0x70]
0000740ecffd0768  vmovaps xmm9, [rsp+0x80]
0000740ecffd0771  vmovaps xmm10, [rsp+0x90]
0000740ecffd077a  vmovaps xmm11, [rsp+0xA0]
0000740ecffd0783  vmovaps xmm12, [rsp+0xB0]
0000740ecffd078c  vmovaps xmm13, [rsp+0xC0]
0000740ecffd0795  vmovaps xmm14, [rsp+0xD0]
0000740ecffd079e  vmovaps xmm15, [rsp+0xE0]
0000740ecffd07a7  add rsp, 0xF0
0000740ecffd07ae  pop r11
0000740ecffd07b0  pop r10
0000740ecffd07b2  pop r9
0000740ecffd07b4  pop r8
0000740ecffd07b6  pop rsi
0000740ecffd07b7  pop rdi
0000740ecffd07b8  pop rdx
0000740ecffd07b9  pop rcx
0000740ecffd07ba  pop rax
0000740ecffd07bb  add rsp, 0x08
0000740ecffd07bf  jmp 0x0000740ECFFCF581
0000740ecffd07c4  sub rsp, 0x08
0000740ecffd07c8  push rax
0000740ecffd07c9  push rcx
0000740ecffd07ca  push rdx
0000740ecffd07cb  push rdi
0000740ecffd07cc  push rsi
0000740ecffd07cd  push r8
0000740ecffd07cf  push r9
0000740ecffd07d1  push r10
0000740ecffd07d3  push r11
0000740ecffd07d5  sub rsp, 0xF0
0000740ecffd07dc  vmovaps [rsp], xmm0
0000740ecffd07e1  vmovaps [rsp+0x10], xmm1
0000740ecffd07e7  vmovaps [rsp+0x20], xmm2
0000740ecffd07ed  vmovaps [rsp+0x30], xmm3
0000740ecffd07f3  vmovaps [rsp+0x40], xmm4
0000740ecffd07f9  vmovaps [rsp+0x50], xmm5
0000740ecffd07ff  vmovaps [rsp+0x60], xmm6
0000740ecffd0805  vmovaps [rsp+0x70], xmm7
0000740ecffd080b  vmovaps [rsp+0x80], xmm8
0000740ecffd0814  vmovaps [rsp+0x90], xmm9
0000740ecffd081d  vmovaps [rsp+0xA0], xmm10
0000740ecffd0826  vmovaps [rsp+0xB0], xmm11
0000740ecffd082f  vmovaps [rsp+0xC0], xmm12
0000740ecffd0838  vmovaps [rsp+0xD0], xmm14
0000740ecffd0841  vmovaps [rsp+0xE0], xmm15
0000740ecffd084a  sub rsp, 0x30
0000740ecffd084e  movaps [rsp], xmm13
0000740ecffd0853  movaps [rsp+0x10], xmm1
0000740ecffd0858  movaps [rsp+0x20], xmm14
0000740ecffd085e  lea rdi, [rsp]
0000740ecffd0862  mov esi, 0x00
0000740ecffd0867  mov rax, 0x5E8249CF1530
0000740ecffd0871  call rax
0000740ecffd0873  movaps xmm13, [rsp]
0000740ecffd0878  add rsp, 0x30
0000740ecffd087c  vmovaps xmm0, [rsp]
0000740ecffd0881  vmovaps xmm1, [rsp+0x10]
0000740ecffd0887  vmovaps xmm2, [rsp+0x20]
0000740ecffd088d  vmovaps xmm3, [rsp+0x30]
0000740ecffd0893  vmovaps xmm4, [rsp+0x40]
0000740ecffd0899  vmovaps xmm5, [rsp+0x50]
0000740ecffd089f  vmovaps xmm6, [rsp+0x60]
0000740ecffd08a5  vmovaps xmm7, [rsp+0x70]
0000740ecffd08ab  vmovaps xmm8, [rsp+0x80]
0000740ecffd08b4  vmovaps xmm9, [rsp+0x90]
0000740ecffd08bd  vmovaps xmm10, [rsp+0xA0]
0000740ecffd08c6  vmovaps xmm11, [rsp+0xB0]
0000740ecffd08cf  vmovaps xmm12, [rsp+0xC0]
0000740ecffd08d8  vmovaps xmm14, [rsp+0xD0]
0000740ecffd08e1  vmovaps xmm15, [rsp+0xE0]
0000740ecffd08ea  add rsp, 0xF0
0000740ecffd08f1  pop r11
0000740ecffd08f3  pop r10
0000740ecffd08f5  pop r9
0000740ecffd08f7  pop r8
0000740ecffd08f9  pop rsi
0000740ecffd08fa  pop rdi
0000740ecffd08fb  pop rdx
0000740ecffd08fc  pop rcx
0000740ecffd08fd  pop rax
0000740ecffd08fe  add rsp, 0x08
0000740ecffd0902  jmp 0x0000740ECFFCF5CF
0000740ecffd0907  sub rsp, 0x08
0000740ecffd090b  push rax
0000740ecffd090c  push rcx
0000740ecffd090d  push rdx
0000740ecffd090e  push rdi
0000740ecffd090f  push rsi
0000740ecffd0910  push r8
0000740ecffd0912  push r9
0000740ecffd0914  push r10
0000740ecffd0916  push r11
0000740ecffd0918  sub rsp, 0xF0
0000740ecffd091f  vmovaps [rsp], xmm0
0000740ecffd0924  vmovaps [rsp+0x10], xmm1
0000740ecffd092a  vmovaps [rsp+0x20], xmm2
0000740ecffd0930  vmovaps [rsp+0x30], xmm3
0000740ecffd0936  vmovaps [rsp+0x40], xmm4
0000740ecffd093c  vmovaps [rsp+0x50], xmm5
0000740ecffd0942  vmovaps [rsp+0x60], xmm6
0000740ecffd0948  vmovaps [rsp+0x70], xmm7
0000740ecffd094e  vmovaps [rsp+0x80], xmm8
0000740ecffd0957  vmovaps [rsp+0x90], xmm9
0000740ecffd0960  vmovaps [rsp+0xA0], xmm10
0000740ecffd0969  vmovaps [rsp+0xB0], xmm11
0000740ecffd0972  vmovaps [rsp+0xC0], xmm12
0000740ecffd097b  vmovaps [rsp+0xD0], xmm13
0000740ecffd0984  vmovaps [rsp+0xE0], xmm14
0000740ecffd098d  sub rsp, 0x30
0000740ecffd0991  movaps [rsp], xmm15
0000740ecffd0996  movaps [rsp+0x10], xmm14
0000740ecffd099c  movaps [rsp+0x20], xmm1
0000740ecffd09a1  lea rdi, [rsp]
0000740ecffd09a5  mov esi, 0x00
0000740ecffd09aa  mov rax, 0x5E8249CF1530
0000740ecffd09b4  call rax
0000740ecffd09b6  movaps xmm15, [rsp]
0000740ecffd09bb  add rsp, 0x30
0000740ecffd09bf  vmovaps xmm0, [rsp]
0000740ecffd09c4  vmovaps xmm1, [rsp+0x10]
0000740ecffd09ca  vmovaps xmm2, [rsp+0x20]
0000740ecffd09d0  vmovaps xmm3, [rsp+0x30]
0000740ecffd09d6  vmovaps xmm4, [rsp+0x40]
0000740ecffd09dc  vmovaps xmm5, [rsp+0x50]
0000740ecffd09e2  vmovaps xmm6, [rsp+0x60]
0000740ecffd09e8  vmovaps xmm7, [rsp+0x70]
0000740ecffd09ee  vmovaps xmm8, [rsp+0x80]
0000740ecffd09f7  vmovaps xmm9, [rsp+0x90]
0000740ecffd0a00  vmovaps xmm10, [rsp+0xA0]
0000740ecffd0a09  vmovaps xmm11, [rsp+0xB0]
0000740ecffd0a12  vmovaps xmm12, [rsp+0xC0]
0000740ecffd0a1b  vmovaps xmm13, [rsp+0xD0]
0000740ecffd0a24  vmovaps xmm14, [rsp+0xE0]
0000740ecffd0a2d  add rsp, 0xF0
0000740ecffd0a34  pop r11
0000740ecffd0a36  pop r10
0000740ecffd0a38  pop r9
0000740ecffd0a3a  pop r8
0000740ecffd0a3c  pop rsi
0000740ecffd0a3d  pop rdi
0000740ecffd0a3e  pop rdx
0000740ecffd0a3f  pop rcx
0000740ecffd0a40  pop rax
0000740ecffd0a41  add rsp, 0x08
0000740ecffd0a45  jmp 0x0000740ECFFCF617
0000740ecffd0a4a  sub rsp, 0x08
0000740ecffd0a4e  push rax
0000740ecffd0a4f  push rcx
0000740ecffd0a50  push rdx
0000740ecffd0a51  push rdi
0000740ecffd0a52  push rsi
0000740ecffd0a53  push r8
0000740ecffd0a55  push r9
0000740ecffd0a57  push r10
0000740ecffd0a59  push r11
0000740ecffd0a5b  sub rsp, 0xF0
0000740ecffd0a62  vmovaps [rsp], xmm0
0000740ecffd0a67  vmovaps [rsp+0x10], xmm2
0000740ecffd0a6d  vmovaps [rsp+0x20], xmm3
0000740ecffd0a73  vmovaps [rsp+0x30], xmm4
0000740ecffd0a79  vmovaps [rsp+0x40], xmm5
0000740ecffd0a7f  vmovaps [rsp+0x50], xmm6
0000740ecffd0a85  vmovaps [rsp+0x60], xmm7
0000740ecffd0a8b  vmovaps [rsp+0x70], xmm8
0000740ecffd0a91  vmovaps [rsp+0x80], xmm9
0000740ecffd0a9a  vmovaps [rsp+0x90], xmm10
0000740ecffd0aa3  vmovaps [rsp+0xA0], xmm11
0000740ecffd0aac  vmovaps [rsp+0xB0], xmm12
0000740ecffd0ab5  vmovaps [rsp+0xC0], xmm13
0000740ecffd0abe  vmovaps [rsp+0xD0], xmm14
0000740ecffd0ac7  vmovaps [rsp+0xE0], xmm15
0000740ecffd0ad0  sub rsp, 0x30
0000740ecffd0ad4  movaps [rsp], xmm1
0000740ecffd0ad8  movaps [rsp+0x10], xmm14
0000740ecffd0ade  movaps [rsp+0x20], xmm10
0000740ecffd0ae4  lea rdi, [rsp]
0000740ecffd0ae8  mov esi, 0x00
0000740ecffd0aed  mov rax, 0x5E8249CF1530
0000740ecffd0af7  call rax
0000740ecffd0af9  movaps xmm1, [rsp]
0000740ecffd0afd  add rsp, 0x30
0000740ecffd0b01  vmovaps xmm0, [rsp]
0000740ecffd0b06  vmovaps xmm2, [rsp+0x10]
0000740ecffd0b0c  vmovaps xmm3, [rsp+0x20]
0000740ecffd0b12  vmovaps xmm4, [rsp+0x30]
0000740ecffd0b18  vmovaps xmm5, [rsp+0x40]
0000740ecffd0b1e  vmovaps xmm6, [rsp+0x50]
0000740ecffd0b24  vmovaps xmm7, [rsp+0x60]
0000740ecffd0b2a  vmovaps xmm8, [rsp+0x70]
0000740ecffd0b30  vmovaps xmm9, [rsp+0x80]
0000740ecffd0b39  vmovaps xmm10, [rsp+0x90]
0000740ecffd0b42  vmovaps xmm11, [rsp+0xA0]
0000740ecffd0b4b  vmovaps xmm12, [rsp+0xB0]
0000740ecffd0b54  vmovaps xmm13, [rsp+0xC0]
0000740ecffd0b5d  vmovaps xmm14, [rsp+0xD0]
0000740ecffd0b66  vmovaps xmm15, [rsp+0xE0]
0000740ecffd0b6f  add rsp, 0xF0
0000740ecffd0b76  pop r11
0000740ecffd0b78  pop r10
0000740ecffd0b7a  pop r9
0000740ecffd0b7c  pop r8
0000740ecffd0b7e  pop rsi
0000740ecffd0b7f  pop rdi
0000740ecffd0b80  pop rdx
0000740ecffd0b81  pop rcx
0000740ecffd0b82  pop rax
0000740ecffd0b83  add rsp, 0x08
0000740ecffd0b87  jmp 0x0000740ECFFCF631
0000740ecffd0b8c  sub rsp, 0x08
0000740ecffd0b90  push rax
0000740ecffd0b91  push rcx
0000740ecffd0b92  push rdx
0000740ecffd0b93  push rdi
0000740ecffd0b94  push rsi
0000740ecffd0b95  push r8
0000740ecffd0b97  push r9
0000740ecffd0b99  push r10
0000740ecffd0b9b  push r11
0000740ecffd0b9d  sub rsp, 0xF0
0000740ecffd0ba4  vmovaps [rsp], xmm0
0000740ecffd0ba9  vmovaps [rsp+0x10], xmm1
0000740ecffd0baf  vmovaps [rsp+0x20], xmm2
0000740ecffd0bb5  vmovaps [rsp+0x30], xmm3
0000740ecffd0bbb  vmovaps [rsp+0x40], xmm4
0000740ecffd0bc1  vmovaps [rsp+0x50], xmm5
0000740ecffd0bc7  vmovaps [rsp+0x60], xmm6
0000740ecffd0bcd  vmovaps [rsp+0x70], xmm7
0000740ecffd0bd3  vmovaps [rsp+0x80], xmm8
0000740ecffd0bdc  vmovaps [rsp+0x90], xmm9
0000740ecffd0be5  vmovaps [rsp+0xA0], xmm10
0000740ecffd0bee  vmovaps [rsp+0xB0], xmm11
0000740ecffd0bf7  vmovaps [rsp+0xC0], xmm12
0000740ecffd0c00  vmovaps [rsp+0xD0], xmm14
0000740ecffd0c09  vmovaps [rsp+0xE0], xmm15
0000740ecffd0c12  sub rsp, 0x30
0000740ecffd0c16  movaps [rsp], xmm13
0000740ecffd0c1b  movaps [rsp+0x10], xmm14
0000740ecffd0c21  movaps [rsp+0x20], xmm2
0000740ecffd0c26  lea rdi, [rsp]
0000740ecffd0c2a  mov esi, 0x00
0000740ecffd0c2f  mov rax, 0x5E8249CF1530
0000740ecffd0c39  call rax
0000740ecffd0c3b  movaps xmm13, [rsp]
0000740ecffd0c40  add rsp, 0x30
0000740ecffd0c44  vmovaps xmm0, [rsp]
0000740ecffd0c49  vmovaps xmm1, [rsp+0x10]
0000740ecffd0c4f  vmovaps xmm2, [rsp+0x20]
0000740ecffd0c55  vmovaps xmm3, [rsp+0x30]
0000740ecffd0c5b  vmovaps xmm4, [rsp+0x40]
0000740ecffd0c61  vmovaps xmm5, [rsp+0x50]
0000740ecffd0c67  vmovaps xmm6, [rsp+0x60]
0000740ecffd0c6d  vmovaps xmm7, [rsp+0x70]
0000740ecffd0c73  vmovaps xmm8, [rsp+0x80]
0000740ecffd0c7c  vmovaps xmm9, [rsp+0x90]
0000740ecffd0c85  vmovaps xmm10, [rsp+0xA0]
0000740ecffd0c8e  vmovaps xmm11, [rsp+0xB0]
0000740ecffd0c97  vmovaps xmm12, [rsp+0xC0]
0000740ecffd0ca0  vmovaps xmm14, [rsp+0xD0]
0000740ecffd0ca9  vmovaps xmm15, [rsp+0xE0]
0000740ecffd0cb2  add rsp, 0xF0
0000740ecffd0cb9  pop r11
0000740ecffd0cbb  pop r10
0000740ecffd0cbd  pop r9
0000740ecffd0cbf  pop r8
0000740ecffd0cc1  pop rsi
0000740ecffd0cc2  pop rdi
0000740ecffd0cc3  pop rdx
0000740ecffd0cc4  pop rcx
0000740ecffd0cc5  pop rax
0000740ecffd0cc6  add rsp, 0x08
0000740ecffd0cca  jmp 0x0000740ECFFCF64C
0000740ecffd0ccf  sub rsp, 0x08
0000740ecffd0cd3  push rax
0000740ecffd0cd4  push rcx
0000740ecffd0cd5  push rdx
0000740ecffd0cd6  push rdi
0000740ecffd0cd7  push rsi
0000740ecffd0cd8  push r8
0000740ecffd0cda  push r9
0000740ecffd0cdc  push r10
0000740ecffd0cde  push r11
0000740ecffd0ce0  sub rsp, 0xF0
0000740ecffd0ce7  vmovaps [rsp], xmm0
0000740ecffd0cec  vmovaps [rsp+0x10], xmm2
0000740ecffd0cf2  vmovaps [rsp+0x20], xmm3
0000740ecffd0cf8  vmovaps [rsp+0x30], xmm4
0000740ecffd0cfe  vmovaps [rsp+0x40], xmm5
0000740ecffd0d04  vmovaps [rsp+0x50], xmm6
0000740ecffd0d0a  vmovaps [rsp+0x60], xmm7
0000740ecffd0d10  vmovaps [rsp+0x70], xmm8
0000740ecffd0d16  vmovaps [rsp+0x80], xmm9
0000740ecffd0d1f  vmovaps [rsp+0x90], xmm10
0000740ecffd0d28  vmovaps [rsp+0xA0], xmm11
0000740ecffd0d31  vmovaps [rsp+0xB0], xmm12
0000740ecffd0d3a  vmovaps [rsp+0xC0], xmm13
0000740ecffd0d43  vmovaps [rsp+0xD0], xmm14
0000740ecffd0d4c  vmovaps [rsp+0xE0], xmm15
0000740ecffd0d55  sub rsp, 0x30
0000740ecffd0d59  movaps [rsp], xmm1
0000740ecffd0d5d  movaps [rsp+0x10], xmm10
0000740ecffd0d63  movaps [rsp+0x20], xmm2
0000740ecffd0d68  lea rdi, [rsp]
0000740ecffd0d6c  mov esi, 0x00
0000740ecffd0d71  mov rax, 0x5E8249CF1530
0000740ecffd0d7b  call rax
0000740ecffd0d7d  movaps xmm1, [rsp]
0000740ecffd0d81  add rsp, 0x30
0000740ecffd0d85  vmovaps xmm0, [rsp]
0000740ecffd0d8a  vmovaps xmm2, [rsp+0x10]
0000740ecffd0d90  vmovaps xmm3, [rsp+0x20]
0000740ecffd0d96  vmovaps xmm4, [rsp+0x30]
0000740ecffd0d9c  vmovaps xmm5, [rsp+0x40]
0000740ecffd0da2  vmovaps xmm6, [rsp+0x50]
0000740ecffd0da8  vmovaps xmm7, [rsp+0x60]
0000740ecffd0dae  vmovaps xmm8, [rsp+0x70]
0000740ecffd0db4  vmovaps xmm9, [rsp+0x80]
0000740ecffd0dbd  vmovaps xmm10, [rsp+0x90]
0000740ecffd0dc6  vmovaps xmm11, [rsp+0xA0]
0000740ecffd0dcf  vmovaps xmm12, [rsp+0xB0]
0000740ecffd0dd8  vmovaps xmm13, [rsp+0xC0]
0000740ecffd0de1  vmovaps xmm14, [rsp+0xD0]
0000740ecffd0dea  vmovaps xmm15, [rsp+0xE0]
0000740ecffd0df3  add rsp, 0xF0
0000740ecffd0dfa  pop r11
0000740ecffd0dfc  pop r10
0000740ecffd0dfe  pop r9
0000740ecffd0e00  pop r8
0000740ecffd0e02  pop rsi
0000740ecffd0e03  pop rdi
0000740ecffd0e04  pop rdx
0000740ecffd0e05  pop rcx
0000740ecffd0e06  pop rax
0000740ecffd0e07  add rsp, 0x08
0000740ecffd0e0b  jmp 0x0000740ECFFCF6B4
0000740ecffd0e10  sub rsp, 0x08
0000740ecffd0e14  push rax
0000740ecffd0e15  push rcx
0000740ecffd0e16  push rdx
0000740ecffd0e17  push rdi
0000740ecffd0e18  push rsi
0000740ecffd0e19  push r8
0000740ecffd0e1b  push r9
0000740ecffd0e1d  push r10
0000740ecffd0e1f  push r11
0000740ecffd0e21  sub rsp, 0xF0
0000740ecffd0e28  vmovaps [rsp], xmm0
0000740ecffd0e2d  vmovaps [rsp+0x10], xmm1
0000740ecffd0e33  vmovaps [rsp+0x20], xmm2
0000740ecffd0e39  vmovaps [rsp+0x30], xmm3
0000740ecffd0e3f  vmovaps [rsp+0x40], xmm4
0000740ecffd0e45  vmovaps [rsp+0x50], xmm5
0000740ecffd0e4b  vmovaps [rsp+0x60], xmm6
0000740ecffd0e51  vmovaps [rsp+0x70], xmm7
0000740ecffd0e57  vmovaps [rsp+0x80], xmm8
0000740ecffd0e60  vmovaps [rsp+0x90], xmm9
0000740ecffd0e69  vmovaps [rsp+0xA0], xmm10
0000740ecffd0e72  vmovaps [rsp+0xB0], xmm11
0000740ecffd0e7b  vmovaps [rsp+0xC0], xmm12
0000740ecffd0e84  vmovaps [rsp+0xD0], xmm13
0000740ecffd0e8d  vmovaps [rsp+0xE0], xmm14
0000740ecffd0e96  sub rsp, 0x30
0000740ecffd0e9a  movaps [rsp], xmm15
0000740ecffd0e9f  movaps [rsp+0x10], xmm10
0000740ecffd0ea5  movaps [rsp+0x20], xmm2
0000740ecffd0eaa  lea rdi, [rsp]
0000740ecffd0eae  mov esi, 0x00
0000740ecffd0eb3  mov rax, 0x5E8249CF1530
0000740ecffd0ebd  call rax
0000740ecffd0ebf  movaps xmm15, [rsp]
0000740ecffd0ec4  add rsp, 0x30
0000740ecffd0ec8  vmovaps xmm0, [rsp]
0000740ecffd0ecd  vmovaps xmm1, [rsp+0x10]
0000740ecffd0ed3  vmovaps xmm2, [rsp+0x20]
0000740ecffd0ed9  vmovaps xmm3, [rsp+0x30]
0000740ecffd0edf  vmovaps xmm4, [rsp+0x40]
0000740ecffd0ee5  vmovaps xmm5, [rsp+0x50]
0000740ecffd0eeb  vmovaps xmm6, [rsp+0x60]
0000740ecffd0ef1  vmovaps xmm7, [rsp+0x70]
0000740ecffd0ef7  vmovaps xmm8, [rsp+0x80]
0000740ecffd0f00  vmovaps xmm9, [rsp+0x90]
0000740ecffd0f09  vmovaps xmm10, [rsp+0xA0]
0000740ecffd0f12  vmovaps xmm11, [rsp+0xB0]
0000740ecffd0f1b  vmovaps xmm12, [rsp+0xC0]
0000740ecffd0f24  vmovaps xmm13, [rsp+0xD0]
0000740ecffd0f2d  vmovaps xmm14, [rsp+0xE0]
0000740ecffd0f36  add rsp, 0xF0
0000740ecffd0f3d  pop r11
0000740ecffd0f3f  pop r10
0000740ecffd0f41  pop r9
0000740ecffd0f43  pop r8
0000740ecffd0f45  pop rsi
0000740ecffd0f46  pop rdi
0000740ecffd0f47  pop rdx
0000740ecffd0f48  pop rcx
0000740ecffd0f49  pop rax
0000740ecffd0f4a  add rsp, 0x08
0000740ecffd0f4e  jmp 0x0000740ECFFCF706
0000740ecffd0f53  sub rsp, 0x08
0000740ecffd0f57  push rax
0000740ecffd0f58  push rcx
0000740ecffd0f59  push rdx
0000740ecffd0f5a  push rdi
0000740ecffd0f5b  push rsi
0000740ecffd0f5c  push r8
0000740ecffd0f5e  push r9
0000740ecffd0f60  push r10
0000740ecffd0f62  push r11
0000740ecffd0f64  sub rsp, 0xF0
0000740ecffd0f6b  vmovaps [rsp], xmm0
0000740ecffd0f70  vmovaps [rsp+0x10], xmm2
0000740ecffd0f76  vmovaps [rsp+0x20], xmm3
0000740ecffd0f7c  vmovaps [rsp+0x30], xmm4
0000740ecffd0f82  vmovaps [rsp+0x40], xmm5
0000740ecffd0f88  vmovaps [rsp+0x50], xmm6
0000740ecffd0f8e  vmovaps [rsp+0x60], xmm7
0000740ecffd0f94  vmovaps [rsp+0x70], xmm8
0000740ecffd0f9a  vmovaps [rsp+0x80], xmm9
0000740ecffd0fa3  vmovaps [rsp+0x90], xmm10
0000740ecffd0fac  vmovaps [rsp+0xA0], xmm11
0000740ecffd0fb5  vmovaps [rsp+0xB0], xmm12
0000740ecffd0fbe  vmovaps [rsp+0xC0], xmm13
0000740ecffd0fc7  vmovaps [rsp+0xD0], xmm14
0000740ecffd0fd0  vmovaps [rsp+0xE0], xmm15
0000740ecffd0fd9  sub rsp, 0x30
0000740ecffd0fdd  movaps [rsp], xmm1
0000740ecffd0fe1  movaps [rsp+0x10], xmm10
0000740ecffd0fe7  movaps [rsp+0x20], xmm12
0000740ecffd0fed  lea rdi, [rsp]
0000740ecffd0ff1  mov esi, 0x00
0000740ecffd0ff6  mov rax, 0x5E8249CF1530
0000740ecffd1000  call rax
0000740ecffd1002  movaps xmm1, [rsp]
0000740ecffd1006  add rsp, 0x30
0000740ecffd100a  vmovaps xmm0, [rsp]
0000740ecffd100f  vmovaps xmm2, [rsp+0x10]
0000740ecffd1015  vmovaps xmm3, [rsp+0x20]
0000740ecffd101b  vmovaps xmm4, [rsp+0x30]
0000740ecffd1021  vmovaps xmm5, [rsp+0x40]
0000740ecffd1027  vmovaps xmm6, [rsp+0x50]
0000740ecffd102d  vmovaps xmm7, [rsp+0x60]
0000740ecffd1033  vmovaps xmm8, [rsp+0x70]
0000740ecffd1039  vmovaps xmm9, [rsp+0x80]
0000740ecffd1042  vmovaps xmm10, [rsp+0x90]
0000740ecffd104b  vmovaps xmm11, [rsp+0xA0]
0000740ecffd1054  vmovaps xmm12, [rsp+0xB0]
0000740ecffd105d  vmovaps xmm13, [rsp+0xC0]
0000740ecffd1066  vmovaps xmm14, [rsp+0xD0]
0000740ecffd106f  vmovaps xmm15, [rsp+0xE0]
0000740ecffd1078  add rsp, 0xF0
0000740ecffd107f  pop r11
0000740ecffd1081  pop r10
0000740ecffd1083  pop r9
0000740ecffd1085  pop r8
0000740ecffd1087  pop rsi
0000740ecffd1088  pop rdi
0000740ecffd1089  pop rdx
0000740ecffd108a  pop rcx
0000740ecffd108b  pop rax
0000740ecffd108c  add rsp, 0x08
0000740ecffd1090  jmp 0x0000740ECFFCF732
0000740ecffd1095  sub rsp, 0x08
0000740ecffd1099  push rax
0000740ecffd109a  push rcx
0000740ecffd109b  push rdx
0000740ecffd109c  push rdi
0000740ecffd109d  push rsi
0000740ecffd109e  push r8
0000740ecffd10a0  push r9
0000740ecffd10a2  push r10
0000740ecffd10a4  push r11
0000740ecffd10a6  sub rsp, 0xF0
0000740ecffd10ad  vmovaps [rsp], xmm0
0000740ecffd10b2  vmovaps [rsp+0x10], xmm1
0000740ecffd10b8  vmovaps [rsp+0x20], xmm2
0000740ecffd10be  vmovaps [rsp+0x30], xmm3
0000740ecffd10c4  vmovaps [rsp+0x40], xmm4
0000740ecffd10ca  vmovaps [rsp+0x50], xmm5
0000740ecffd10d0  vmovaps [rsp+0x60], xmm6
0000740ecffd10d6  vmovaps [rsp+0x70], xmm7
0000740ecffd10dc  vmovaps [rsp+0x80], xmm8
0000740ecffd10e5  vmovaps [rsp+0x90], xmm9
0000740ecffd10ee  vmovaps [rsp+0xA0], xmm10
0000740ecffd10f7  vmovaps [rsp+0xB0], xmm11
0000740ecffd1100  vmovaps [rsp+0xC0], xmm12
0000740ecffd1109  vmovaps [rsp+0xD0], xmm13
0000740ecffd1112  vmovaps [rsp+0xE0], xmm14
0000740ecffd111b  sub rsp, 0x30
0000740ecffd111f  movaps [rsp], xmm15
0000740ecffd1124  movaps [rsp+0x10], xmm10
0000740ecffd112a  movaps [rsp+0x20], xmm12
0000740ecffd1130  lea rdi, [rsp]
0000740ecffd1134  mov esi, 0x00
0000740ecffd1139  mov rax, 0x5E8249CF1530
0000740ecffd1143  call rax
0000740ecffd1145  movaps xmm15, [rsp]
0000740ecffd114a  add rsp, 0x30
0000740ecffd114e  vmovaps xmm0, [rsp]
0000740ecffd1153  vmovaps xmm1, [rsp+0x10]
0000740ecffd1159  vmovaps xmm2, [rsp+0x20]
0000740ecffd115f  vmovaps xmm3, [rsp+0x30]
0000740ecffd1165  vmovaps xmm4, [rsp+0x40]
0000740ecffd116b  vmovaps xmm5, [rsp+0x50]
0000740ecffd1171  vmovaps xmm6, [rsp+0x60]
0000740ecffd1177  vmovaps xmm7, [rsp+0x70]
0000740ecffd117d  vmovaps xmm8, [rsp+0x80]
0000740ecffd1186  vmovaps xmm9, [rsp+0x90]
0000740ecffd118f  vmovaps xmm10, [rsp+0xA0]
0000740ecffd1198  vmovaps xmm11, [rsp+0xB0]
0000740ecffd11a1  vmovaps xmm12, [rsp+0xC0]
0000740ecffd11aa  vmovaps xmm13, [rsp+0xD0]
0000740ecffd11b3  vmovaps xmm14, [rsp+0xE0]
0000740ecffd11bc  add rsp, 0xF0
0000740ecffd11c3  pop r11
0000740ecffd11c5  pop r10
0000740ecffd11c7  pop r9
0000740ecffd11c9  pop r8
0000740ecffd11cb  pop rsi
0000740ecffd11cc  pop rdi
0000740ecffd11cd  pop rdx
0000740ecffd11ce  pop rcx
0000740ecffd11cf  pop rax
0000740ecffd11d0  add rsp, 0x08
0000740ecffd11d4  jmp 0x0000740ECFFCF75E
0000740ecffd11d9  call 0x0000740ECFDFF430
0000740ecffd11de  jmp 0x0000740ECFFCF7EE
0000740ecffd11e3  call 0x0000740ECFDFF430
0000740ecffd11e8  jmp 0x0000740ECFFCF801
0000740ecffd11ed  sub rsp, 0x08
0000740ecffd11f1  push rax
0000740ecffd11f2  push rcx
0000740ecffd11f3  push rdx
0000740ecffd11f4  push rdi
0000740ecffd11f5  push rsi
0000740ecffd11f6  push r8
0000740ecffd11f8  push r9
0000740ecffd11fa  push r10
0000740ecffd11fc  push r11
0000740ecffd11fe  sub rsp, 0xF0
0000740ecffd1205  vmovaps [rsp], xmm0
0000740ecffd120a  vmovaps [rsp+0x10], xmm2
0000740ecffd1210  vmovaps [rsp+0x20], xmm3
0000740ecffd1216  vmovaps [rsp+0x30], xmm4
0000740ecffd121c  vmovaps [rsp+0x40], xmm5
0000740ecffd1222  vmovaps [rsp+0x50], xmm6
0000740ecffd1228  vmovaps [rsp+0x60], xmm7
0000740ecffd122e  vmovaps [rsp+0x70], xmm8
0000740ecffd1234  vmovaps [rsp+0x80], xmm9
0000740ecffd123d  vmovaps [rsp+0x90], xmm10
0000740ecffd1246  vmovaps [rsp+0xA0], xmm11
0000740ecffd124f  vmovaps [rsp+0xB0], xmm12
0000740ecffd1258  vmovaps [rsp+0xC0], xmm13
0000740ecffd1261  vmovaps [rsp+0xD0], xmm14
0000740ecffd126a  vmovaps [rsp+0xE0], xmm15
0000740ecffd1273  sub rsp, 0x30
0000740ecffd1277  movaps [rsp], xmm1
0000740ecffd127b  movaps [rsp+0x10], xmm13
0000740ecffd1281  movaps [rsp+0x20], xmm2
0000740ecffd1286  lea rdi, [rsp]
0000740ecffd128a  mov esi, 0x00
0000740ecffd128f  mov rax, 0x5E8249CF1530
0000740ecffd1299  call rax
0000740ecffd129b  movaps xmm1, [rsp]
0000740ecffd129f  add rsp, 0x30
0000740ecffd12a3  vmovaps xmm0, [rsp]
0000740ecffd12a8  vmovaps xmm2, [rsp+0x10]
0000740ecffd12ae  vmovaps xmm3, [rsp+0x20]
0000740ecffd12b4  vmovaps xmm4, [rsp+0x30]
0000740ecffd12ba  vmovaps xmm5, [rsp+0x40]
0000740ecffd12c0  vmovaps xmm6, [rsp+0x50]
0000740ecffd12c6  vmovaps xmm7, [rsp+0x60]
0000740ecffd12cc  vmovaps xmm8, [rsp+0x70]
0000740ecffd12d2  vmovaps xmm9, [rsp+0x80]
0000740ecffd12db  vmovaps xmm10, [rsp+0x90]
0000740ecffd12e4  vmovaps xmm11, [rsp+0xA0]
0000740ecffd12ed  vmovaps xmm12, [rsp+0xB0]
0000740ecffd12f6  vmovaps xmm13, [rsp+0xC0]
0000740ecffd12ff  vmovaps xmm14, [rsp+0xD0]
0000740ecffd1308  vmovaps xmm15, [rsp+0xE0]
0000740ecffd1311  add rsp, 0xF0
0000740ecffd1318  pop r11
0000740ecffd131a  pop r10
0000740ecffd131c  pop r9
0000740ecffd131e  pop r8
0000740ecffd1320  pop rsi
0000740ecffd1321  pop rdi
0000740ecffd1322  pop rdx
0000740ecffd1323  pop rcx
0000740ecffd1324  pop rax
0000740ecffd1325  add rsp, 0x08
0000740ecffd1329  jmp 0x0000740ECFFCF82C
0000740ecffd132e  call 0x0000740ECFE0E760
0000740ecffd1333  jmp 0x0000740ECFFCF839
0000740ecffd1338  sub rsp, 0x08
0000740ecffd133c  push rax
0000740ecffd133d  push rcx
0000740ecffd133e  push rdx
0000740ecffd133f  push rdi
0000740ecffd1340  push rsi
0000740ecffd1341  push r8
0000740ecffd1343  push r9
0000740ecffd1345  push r10
0000740ecffd1347  push r11
0000740ecffd1349  sub rsp, 0xF0
0000740ecffd1350  vmovaps [rsp], xmm0
0000740ecffd1355  vmovaps [rsp+0x10], xmm1
0000740ecffd135b  vmovaps [rsp+0x20], xmm2
0000740ecffd1361  vmovaps [rsp+0x30], xmm3
0000740ecffd1367  vmovaps [rsp+0x40], xmm4
0000740ecffd136d  vmovaps [rsp+0x50], xmm5
0000740ecffd1373  vmovaps [rsp+0x60], xmm6
0000740ecffd1379  vmovaps [rsp+0x70], xmm7
0000740ecffd137f  vmovaps [rsp+0x80], xmm8
0000740ecffd1388  vmovaps [rsp+0x90], xmm9
0000740ecffd1391  vmovaps [rsp+0xA0], xmm10
0000740ecffd139a  vmovaps [rsp+0xB0], xmm11
0000740ecffd13a3  vmovaps [rsp+0xC0], xmm12
0000740ecffd13ac  vmovaps [rsp+0xD0], xmm14
0000740ecffd13b5  vmovaps [rsp+0xE0], xmm15
0000740ecffd13be  sub rsp, 0x30
0000740ecffd13c2  movaps [rsp], xmm13
0000740ecffd13c7  movaps [rsp+0x10], xmm2
0000740ecffd13cc  movaps [rsp+0x20], xmm1
0000740ecffd13d1  lea rdi, [rsp]
0000740ecffd13d5  mov esi, 0x00
0000740ecffd13da  mov rax, 0x5E8249CF1530
0000740ecffd13e4  call rax
0000740ecffd13e6  movaps xmm13, [rsp]
0000740ecffd13eb  add rsp, 0x30
0000740ecffd13ef  vmovaps xmm0, [rsp]
0000740ecffd13f4  vmovaps xmm1, [rsp+0x10]
0000740ecffd13fa  vmovaps xmm2, [rsp+0x20]
0000740ecffd1400  vmovaps xmm3, [rsp+0x30]
0000740ecffd1406  vmovaps xmm4, [rsp+0x40]
0000740ecffd140c  vmovaps xmm5, [rsp+0x50]
0000740ecffd1412  vmovaps xmm6, [rsp+0x60]
0000740ecffd1418  vmovaps xmm7, [rsp+0x70]
0000740ecffd141e  vmovaps xmm8, [rsp+0x80]
0000740ecffd1427  vmovaps xmm9, [rsp+0x90]
0000740ecffd1430  vmovaps xmm10, [rsp+0xA0]
0000740ecffd1439  vmovaps xmm11, [rsp+0xB0]
0000740ecffd1442  vmovaps xmm12, [rsp+0xC0]
0000740ecffd144b  vmovaps xmm14, [rsp+0xD0]
0000740ecffd1454  vmovaps xmm15, [rsp+0xE0]
0000740ecffd145d  add rsp, 0xF0
0000740ecffd1464  pop r11
0000740ecffd1466  pop r10
0000740ecffd1468  pop r9
0000740ecffd146a  pop r8
0000740ecffd146c  pop rsi
0000740ecffd146d  pop rdi
0000740ecffd146e  pop rdx
0000740ecffd146f  pop rcx
0000740ecffd1470  pop rax
0000740ecffd1471  add rsp, 0x08
0000740ecffd1475  jmp 0x0000740ECFFCF878
0000740ecffd147a  sub rsp, 0x08
0000740ecffd147e  push rax
0000740ecffd147f  push rcx
0000740ecffd1480  push rdx
0000740ecffd1481  push rdi
0000740ecffd1482  push rsi
0000740ecffd1483  push r8
0000740ecffd1485  push r9
0000740ecffd1487  push r10
0000740ecffd1489  push r11
0000740ecffd148b  sub rsp, 0xF0
0000740ecffd1492  vmovaps [rsp], xmm0
0000740ecffd1497  vmovaps [rsp+0x10], xmm2
0000740ecffd149d  vmovaps [rsp+0x20], xmm3
0000740ecffd14a3  vmovaps [rsp+0x30], xmm4
0000740ecffd14a9  vmovaps [rsp+0x40], xmm5
0000740ecffd14af  vmovaps [rsp+0x50], xmm6
0000740ecffd14b5  vmovaps [rsp+0x60], xmm7
0000740ecffd14bb  vmovaps [rsp+0x70], xmm8
0000740ecffd14c1  vmovaps [rsp+0x80], xmm9
0000740ecffd14ca  vmovaps [rsp+0x90], xmm10
0000740ecffd14d3  vmovaps [rsp+0xA0], xmm11
0000740ecffd14dc  vmovaps [rsp+0xB0], xmm12
0000740ecffd14e5  vmovaps [rsp+0xC0], xmm13
0000740ecffd14ee  vmovaps [rsp+0xD0], xmm14
0000740ecffd14f7  vmovaps [rsp+0xE0], xmm15
0000740ecffd1500  sub rsp, 0x30
0000740ecffd1504  movaps [rsp], xmm1
0000740ecffd1508  movaps [rsp+0x10], xmm15
0000740ecffd150e  movaps [rsp+0x20], xmm2
0000740ecffd1513  lea rdi, [rsp]
0000740ecffd1517  mov esi, 0x00
0000740ecffd151c  mov rax, 0x5E8249CF1530
0000740ecffd1526  call rax
0000740ecffd1528  movaps xmm1, [rsp]
0000740ecffd152c  add rsp, 0x30
0000740ecffd1530  vmovaps xmm0, [rsp]
0000740ecffd1535  vmovaps xmm2, [rsp+0x10]
0000740ecffd153b  vmovaps xmm3, [rsp+0x20]
0000740ecffd1541  vmovaps xmm4, [rsp+0x30]
0000740ecffd1547  vmovaps xmm5, [rsp+0x40]
0000740ecffd154d  vmovaps xmm6, [rsp+0x50]
0000740ecffd1553  vmovaps xmm7, [rsp+0x60]
0000740ecffd1559  vmovaps xmm8, [rsp+0x70]
0000740ecffd155f  vmovaps xmm9, [rsp+0x80]
0000740ecffd1568  vmovaps xmm10, [rsp+0x90]
0000740ecffd1571  vmovaps xmm11, [rsp+0xA0]
0000740ecffd157a  vmovaps xmm12, [rsp+0xB0]
0000740ecffd1583  vmovaps xmm13, [rsp+0xC0]
0000740ecffd158c  vmovaps xmm14, [rsp+0xD0]
0000740ecffd1595  vmovaps xmm15, [rsp+0xE0]
0000740ecffd159e  add rsp, 0xF0
0000740ecffd15a5  pop r11
0000740ecffd15a7  pop r10
0000740ecffd15a9  pop r9
0000740ecffd15ab  pop r8
0000740ecffd15ad  pop rsi
0000740ecffd15ae  pop rdi
0000740ecffd15af  pop rdx
0000740ecffd15b0  pop rcx
0000740ecffd15b1  pop rax
0000740ecffd15b2  add rsp, 0x08
0000740ecffd15b6  jmp 0x0000740ECFFCF8AC
0000740ecffd15bb  sub rsp, 0x08
0000740ecffd15bf  push rax
0000740ecffd15c0  push rcx
0000740ecffd15c1  push rdx
0000740ecffd15c2  push rdi
0000740ecffd15c3  push rsi
0000740ecffd15c4  push r8
0000740ecffd15c6  push r9
0000740ecffd15c8  push r10
0000740ecffd15ca  push r11
0000740ecffd15cc  sub rsp, 0xF0
0000740ecffd15d3  vmovaps [rsp], xmm0
0000740ecffd15d8  vmovaps [rsp+0x10], xmm1
0000740ecffd15de  vmovaps [rsp+0x20], xmm2
0000740ecffd15e4  vmovaps [rsp+0x30], xmm3
0000740ecffd15ea  vmovaps [rsp+0x40], xmm4
0000740ecffd15f0  vmovaps [rsp+0x50], xmm5
0000740ecffd15f6  vmovaps [rsp+0x60], xmm6
0000740ecffd15fc  vmovaps [rsp+0x70], xmm7
0000740ecffd1602  vmovaps [rsp+0x80], xmm8
0000740ecffd160b  vmovaps [rsp+0x90], xmm9
0000740ecffd1614  vmovaps [rsp+0xA0], xmm10
0000740ecffd161d  vmovaps [rsp+0xB0], xmm11
0000740ecffd1626  vmovaps [rsp+0xC0], xmm12
0000740ecffd162f  vmovaps [rsp+0xD0], xmm13
0000740ecffd1638  vmovaps [rsp+0xE0], xmm15
0000740ecffd1641  sub rsp, 0x30
0000740ecffd1645  movaps [rsp], xmm14
0000740ecffd164a  movaps [rsp+0x10], xmm2
0000740ecffd164f  movaps [rsp+0x20], xmm15
0000740ecffd1655  lea rdi, [rsp]
0000740ecffd1659  mov esi, 0x00
0000740ecffd165e  mov rax, 0x5E8249CF1530
0000740ecffd1668  call rax
0000740ecffd166a  movaps xmm14, [rsp]
0000740ecffd166f  add rsp, 0x30
0000740ecffd1673  vmovaps xmm0, [rsp]
0000740ecffd1678  vmovaps xmm1, [rsp+0x10]
0000740ecffd167e  vmovaps xmm2, [rsp+0x20]
0000740ecffd1684  vmovaps xmm3, [rsp+0x30]
0000740ecffd168a  vmovaps xmm4, [rsp+0x40]
0000740ecffd1690  vmovaps xmm5, [rsp+0x50]
0000740ecffd1696  vmovaps xmm6, [rsp+0x60]
0000740ecffd169c  vmovaps xmm7, [rsp+0x70]
0000740ecffd16a2  vmovaps xmm8, [rsp+0x80]
0000740ecffd16ab  vmovaps xmm9, [rsp+0x90]
0000740ecffd16b4  vmovaps xmm10, [rsp+0xA0]
0000740ecffd16bd  vmovaps xmm11, [rsp+0xB0]
0000740ecffd16c6  vmovaps xmm12, [rsp+0xC0]
0000740ecffd16cf  vmovaps xmm13, [rsp+0xD0]
0000740ecffd16d8  vmovaps xmm15, [rsp+0xE0]
0000740ecffd16e1  add rsp, 0xF0
0000740ecffd16e8  pop r11
0000740ecffd16ea  pop r10
0000740ecffd16ec  pop r9
0000740ecffd16ee  pop r8
0000740ecffd16f0  pop rsi
0000740ecffd16f1  pop rdi
0000740ecffd16f2  pop rdx
0000740ecffd16f3  pop rcx
0000740ecffd16f4  pop rax
0000740ecffd16f5  add rsp, 0x08
0000740ecffd16f9  jmp 0x0000740ECFFCF8E7
0000740ecffd16fe  sub rsp, 0x08
0000740ecffd1702  push rax
0000740ecffd1703  push rcx
0000740ecffd1704  push rdx
0000740ecffd1705  push rdi
0000740ecffd1706  push rsi
0000740ecffd1707  push r8
0000740ecffd1709  push r9
0000740ecffd170b  push r10
0000740ecffd170d  push r11
0000740ecffd170f  sub rsp, 0xF0
0000740ecffd1716  vmovaps [rsp], xmm0
0000740ecffd171b  vmovaps [rsp+0x10], xmm1
0000740ecffd1721  vmovaps [rsp+0x20], xmm2
0000740ecffd1727  vmovaps [rsp+0x30], xmm3
0000740ecffd172d  vmovaps [rsp+0x40], xmm4
0000740ecffd1733  vmovaps [rsp+0x50], xmm5
0000740ecffd1739  vmovaps [rsp+0x60], xmm6
0000740ecffd173f  vmovaps [rsp+0x70], xmm7
0000740ecffd1745  vmovaps [rsp+0x80], xmm8
0000740ecffd174e  vmovaps [rsp+0x90], xmm9
0000740ecffd1757  vmovaps [rsp+0xA0], xmm10
0000740ecffd1760  vmovaps [rsp+0xB0], xmm11
0000740ecffd1769  vmovaps [rsp+0xC0], xmm12
0000740ecffd1772  vmovaps [rsp+0xD0], xmm13
0000740ecffd177b  vmovaps [rsp+0xE0], xmm14
0000740ecffd1784  sub rsp, 0x30
0000740ecffd1788  movaps [rsp], xmm15
0000740ecffd178d  movaps [rsp+0x10], xmm2
0000740ecffd1792  movaps [rsp+0x20], xmm1
0000740ecffd1797  lea rdi, [rsp]
0000740ecffd179b  mov esi, 0x00
0000740ecffd17a0  mov rax, 0x5E8249CF1530
0000740ecffd17aa  call rax
0000740ecffd17ac  movaps xmm15, [rsp]
0000740ecffd17b1  add rsp, 0x30
0000740ecffd17b5  vmovaps xmm0, [rsp]
0000740ecffd17ba  vmovaps xmm1, [rsp+0x10]
0000740ecffd17c0  vmovaps xmm2, [rsp+0x20]
0000740ecffd17c6  vmovaps xmm3, [rsp+0x30]
0000740ecffd17cc  vmovaps xmm4, [rsp+0x40]
0000740ecffd17d2  vmovaps xmm5, [rsp+0x50]
0000740ecffd17d8  vmovaps xmm6, [rsp+0x60]
0000740ecffd17de  vmovaps xmm7, [rsp+0x70]
0000740ecffd17e4  vmovaps xmm8, [rsp+0x80]
0000740ecffd17ed  vmovaps xmm9, [rsp+0x90]
0000740ecffd17f6  vmovaps xmm10, [rsp+0xA0]
0000740ecffd17ff  vmovaps xmm11, [rsp+0xB0]
0000740ecffd1808  vmovaps xmm12, [rsp+0xC0]
0000740ecffd1811  vmovaps xmm13, [rsp+0xD0]
0000740ecffd181a  vmovaps xmm14, [rsp+0xE0]
0000740ecffd1823  add rsp, 0xF0
0000740ecffd182a  pop r11
0000740ecffd182c  pop r10
0000740ecffd182e  pop r9
0000740ecffd1830  pop r8
0000740ecffd1832  pop rsi
0000740ecffd1833  pop rdi
0000740ecffd1834  pop rdx
0000740ecffd1835  pop rcx
0000740ecffd1836  pop rax
0000740ecffd1837  add rsp, 0x08
0000740ecffd183b  jmp 0x0000740ECFFCF923
0000740ecffd1840  call 0x0000740ECFDFF430
0000740ecffd1845  jmp 0x0000740ECFFCF930
0000740ecffd184a  sub rsp, 0x08
0000740ecffd184e  push rax
0000740ecffd184f  push rcx
0000740ecffd1850  push rdx
0000740ecffd1851  push rdi
0000740ecffd1852  push rsi
0000740ecffd1853  push r8
0000740ecffd1855  push r9
0000740ecffd1857  push r10
0000740ecffd1859  push r11
0000740ecffd185b  sub rsp, 0xF0
0000740ecffd1862  vmovaps [rsp], xmm0
0000740ecffd1867  vmovaps [rsp+0x10], xmm1
0000740ecffd186d  vmovaps [rsp+0x20], xmm3
0000740ecffd1873  vmovaps [rsp+0x30], xmm4
0000740ecffd1879  vmovaps [rsp+0x40], xmm5
0000740ecffd187f  vmovaps [rsp+0x50], xmm6
0000740ecffd1885  vmovaps [rsp+0x60], xmm7
0000740ecffd188b  vmovaps [rsp+0x70], xmm8
0000740ecffd1891  vmovaps [rsp+0x80], xmm9
0000740ecffd189a  vmovaps [rsp+0x90], xmm10
0000740ecffd18a3  vmovaps [rsp+0xA0], xmm11
0000740ecffd18ac  vmovaps [rsp+0xB0], xmm12
0000740ecffd18b5  vmovaps [rsp+0xC0], xmm13
0000740ecffd18be  vmovaps [rsp+0xD0], xmm14
0000740ecffd18c7  vmovaps [rsp+0xE0], xmm15
0000740ecffd18d0  sub rsp, 0x30
0000740ecffd18d4  movaps [rsp], xmm2
0000740ecffd18d8  movaps [rsp+0x10], xmm1
0000740ecffd18dd  movaps [rsp+0x20], xmm14
0000740ecffd18e3  lea rdi, [rsp]
0000740ecffd18e7  mov esi, 0x00
0000740ecffd18ec  mov rax, 0x5E8249CF1530
0000740ecffd18f6  call rax
0000740ecffd18f8  movaps xmm2, [rsp]
0000740ecffd18fc  add rsp, 0x30
0000740ecffd1900  vmovaps xmm0, [rsp]
0000740ecffd1905  vmovaps xmm1, [rsp+0x10]
0000740ecffd190b  vmovaps xmm3, [rsp+0x20]
0000740ecffd1911  vmovaps xmm4, [rsp+0x30]
0000740ecffd1917  vmovaps xmm5, [rsp+0x40]
0000740ecffd191d  vmovaps xmm6, [rsp+0x50]
0000740ecffd1923  vmovaps xmm7, [rsp+0x60]
0000740ecffd1929  vmovaps xmm8, [rsp+0x70]
0000740ecffd192f  vmovaps xmm9, [rsp+0x80]
0000740ecffd1938  vmovaps xmm10, [rsp+0x90]
0000740ecffd1941  vmovaps xmm11, [rsp+0xA0]
0000740ecffd194a  vmovaps xmm12, [rsp+0xB0]
0000740ecffd1953  vmovaps xmm13, [rsp+0xC0]
0000740ecffd195c  vmovaps xmm14, [rsp+0xD0]
0000740ecffd1965  vmovaps xmm15, [rsp+0xE0]
0000740ecffd196e  add rsp, 0xF0
0000740ecffd1975  pop r11
0000740ecffd1977  pop r10
0000740ecffd1979  pop r9
0000740ecffd197b  pop r8
0000740ecffd197d  pop rsi
0000740ecffd197e  pop rdi
0000740ecffd197f  pop rdx
0000740ecffd1980  pop rcx
0000740ecffd1981  pop rax
0000740ecffd1982  add rsp, 0x08
0000740ecffd1986  jmp 0x0000740ECFFCF96D
0000740ecffd198b  sub rsp, 0x08
0000740ecffd198f  push rax
0000740ecffd1990  push rcx
0000740ecffd1991  push rdx
0000740ecffd1992  push rdi
0000740ecffd1993  push rsi
0000740ecffd1994  push r8
0000740ecffd1996  push r9
0000740ecffd1998  push r10
0000740ecffd199a  push r11
0000740ecffd199c  sub rsp, 0xF0
0000740ecffd19a3  vmovaps [rsp], xmm0
0000740ecffd19a8  vmovaps [rsp+0x10], xmm1
0000740ecffd19ae  vmovaps [rsp+0x20], xmm2
0000740ecffd19b4  vmovaps [rsp+0x30], xmm3
0000740ecffd19ba  vmovaps [rsp+0x40], xmm4
0000740ecffd19c0  vmovaps [rsp+0x50], xmm5
0000740ecffd19c6  vmovaps [rsp+0x60], xmm6
0000740ecffd19cc  vmovaps [rsp+0x70], xmm7
0000740ecffd19d2  vmovaps [rsp+0x80], xmm8
0000740ecffd19db  vmovaps [rsp+0x90], xmm9
0000740ecffd19e4  vmovaps [rsp+0xA0], xmm10
0000740ecffd19ed  vmovaps [rsp+0xB0], xmm11
0000740ecffd19f6  vmovaps [rsp+0xC0], xmm12
0000740ecffd19ff  vmovaps [rsp+0xD0], xmm13
0000740ecffd1a08  vmovaps [rsp+0xE0], xmm14
0000740ecffd1a11  sub rsp, 0x30
0000740ecffd1a15  movaps [rsp], xmm15
0000740ecffd1a1a  movaps [rsp+0x10], xmm14
0000740ecffd1a20  movaps [rsp+0x20], xmm1
0000740ecffd1a25  lea rdi, [rsp]
0000740ecffd1a29  mov esi, 0x00
0000740ecffd1a2e  mov rax, 0x5E8249CF1530
0000740ecffd1a38  call rax
0000740ecffd1a3a  movaps xmm15, [rsp]
0000740ecffd1a3f  add rsp, 0x30
0000740ecffd1a43  vmovaps xmm0, [rsp]
0000740ecffd1a48  vmovaps xmm1, [rsp+0x10]
0000740ecffd1a4e  vmovaps xmm2, [rsp+0x20]
0000740ecffd1a54  vmovaps xmm3, [rsp+0x30]
0000740ecffd1a5a  vmovaps xmm4, [rsp+0x40]
0000740ecffd1a60  vmovaps xmm5, [rsp+0x50]
0000740ecffd1a66  vmovaps xmm6, [rsp+0x60]
0000740ecffd1a6c  vmovaps xmm7, [rsp+0x70]
0000740ecffd1a72  vmovaps xmm8, [rsp+0x80]
0000740ecffd1a7b  vmovaps xmm9, [rsp+0x90]
0000740ecffd1a84  vmovaps xmm10, [rsp+0xA0]
0000740ecffd1a8d  vmovaps xmm11, [rsp+0xB0]
0000740ecffd1a96  vmovaps xmm12, [rsp+0xC0]
0000740ecffd1a9f  vmovaps xmm13, [rsp+0xD0]
0000740ecffd1aa8  vmovaps xmm14, [rsp+0xE0]
0000740ecffd1ab1  add rsp, 0xF0
0000740ecffd1ab8  pop r11
0000740ecffd1aba  pop r10
0000740ecffd1abc  pop r9
0000740ecffd1abe  pop r8
0000740ecffd1ac0  pop rsi
0000740ecffd1ac1  pop rdi
0000740ecffd1ac2  pop rdx
0000740ecffd1ac3  pop rcx
0000740ecffd1ac4  pop rax
0000740ecffd1ac5  add rsp, 0x08
0000740ecffd1ac9  jmp 0x0000740ECFFCF9E7
0000740ecffd1ace  call 0x0000740ECFDFF430
0000740ecffd1ad3  jmp 0x0000740ECFFCF9F4
0000740ecffd1ad8  sub rsp, 0x08
0000740ecffd1adc  push rax
0000740ecffd1add  push rcx
0000740ecffd1ade  push rdx
0000740ecffd1adf  push rdi
0000740ecffd1ae0  push rsi
0000740ecffd1ae1  push r8
0000740ecffd1ae3  push r9
0000740ecffd1ae5  push r10
0000740ecffd1ae7  push r11
0000740ecffd1ae9  sub rsp, 0xF0
0000740ecffd1af0  vmovaps [rsp], xmm0
0000740ecffd1af5  vmovaps [rsp+0x10], xmm1
0000740ecffd1afb  vmovaps [rsp+0x20], xmm2
0000740ecffd1b01  vmovaps [rsp+0x30], xmm3
0000740ecffd1b07  vmovaps [rsp+0x40], xmm4
0000740ecffd1b0d  vmovaps [rsp+0x50], xmm5
0000740ecffd1b13  vmovaps [rsp+0x60], xmm6
0000740ecffd1b19  vmovaps [rsp+0x70], xmm7
0000740ecffd1b1f  vmovaps [rsp+0x80], xmm8
0000740ecffd1b28  vmovaps [rsp+0x90], xmm9
0000740ecffd1b31  vmovaps [rsp+0xA0], xmm10
0000740ecffd1b3a  vmovaps [rsp+0xB0], xmm11
0000740ecffd1b43  vmovaps [rsp+0xC0], xmm12
0000740ecffd1b4c  vmovaps [rsp+0xD0], xmm13
0000740ecffd1b55  vmovaps [rsp+0xE0], xmm15
0000740ecffd1b5e  sub rsp, 0x30
0000740ecffd1b62  movaps [rsp], xmm14
0000740ecffd1b67  movaps [rsp+0x10], xmm13
0000740ecffd1b6d  movaps [rsp+0x20], xmm1
0000740ecffd1b72  lea rdi, [rsp]
0000740ecffd1b76  mov esi, 0x00
0000740ecffd1b7b  mov rax, 0x5E8249CF1530
0000740ecffd1b85  call rax
0000740ecffd1b87  movaps xmm14, [rsp]
0000740ecffd1b8c  add rsp, 0x30
0000740ecffd1b90  vmovaps xmm0, [rsp]
0000740ecffd1b95  vmovaps xmm1, [rsp+0x10]
0000740ecffd1b9b  vmovaps xmm2, [rsp+0x20]
0000740ecffd1ba1  vmovaps xmm3, [rsp+0x30]
0000740ecffd1ba7  vmovaps xmm4, [rsp+0x40]
0000740ecffd1bad  vmovaps xmm5, [rsp+0x50]
0000740ecffd1bb3  vmovaps xmm6, [rsp+0x60]
0000740ecffd1bb9  vmovaps xmm7, [rsp+0x70]
0000740ecffd1bbf  vmovaps xmm8, [rsp+0x80]
0000740ecffd1bc8  vmovaps xmm9, [rsp+0x90]
0000740ecffd1bd1  vmovaps xmm10, [rsp+0xA0]
0000740ecffd1bda  vmovaps xmm11, [rsp+0xB0]
0000740ecffd1be3  vmovaps xmm12, [rsp+0xC0]
0000740ecffd1bec  vmovaps xmm13, [rsp+0xD0]
0000740ecffd1bf5  vmovaps xmm15, [rsp+0xE0]
0000740ecffd1bfe  add rsp, 0xF0
0000740ecffd1c05  pop r11
0000740ecffd1c07  pop r10
0000740ecffd1c09  pop r9
0000740ecffd1c0b  pop r8
0000740ecffd1c0d  pop rsi
0000740ecffd1c0e  pop rdi
0000740ecffd1c0f  pop rdx
0000740ecffd1c10  pop rcx
0000740ecffd1c11  pop rax
0000740ecffd1c12  add rsp, 0x08
0000740ecffd1c16  jmp 0x0000740ECFFCFAAF
0000740ecffd1c1b  sub rsp, 0x08
0000740ecffd1c1f  push rax
0000740ecffd1c20  push rcx
0000740ecffd1c21  push rdx
0000740ecffd1c22  push rdi
0000740ecffd1c23  push rsi
0000740ecffd1c24  push r8
0000740ecffd1c26  push r9
0000740ecffd1c28  push r10
0000740ecffd1c2a  push r11
0000740ecffd1c2c  sub rsp, 0xF0
0000740ecffd1c33  vmovaps [rsp], xmm0
0000740ecffd1c38  vmovaps [rsp+0x10], xmm1
0000740ecffd1c3e  vmovaps [rsp+0x20], xmm2
0000740ecffd1c44  vmovaps [rsp+0x30], xmm3
0000740ecffd1c4a  vmovaps [rsp+0x40], xmm4
0000740ecffd1c50  vmovaps [rsp+0x50], xmm5
0000740ecffd1c56  vmovaps [rsp+0x60], xmm6
0000740ecffd1c5c  vmovaps [rsp+0x70], xmm7
0000740ecffd1c62  vmovaps [rsp+0x80], xmm8
0000740ecffd1c6b  vmovaps [rsp+0x90], xmm9
0000740ecffd1c74  vmovaps [rsp+0xA0], xmm10
0000740ecffd1c7d  vmovaps [rsp+0xB0], xmm11
0000740ecffd1c86  vmovaps [rsp+0xC0], xmm12
0000740ecffd1c8f  vmovaps [rsp+0xD0], xmm13
0000740ecffd1c98  vmovaps [rsp+0xE0], xmm14
0000740ecffd1ca1  sub rsp, 0x30
0000740ecffd1ca5  movaps [rsp], xmm15
0000740ecffd1caa  movaps [rsp+0x10], xmm13
0000740ecffd1cb0  movaps [rsp+0x20], xmm1
0000740ecffd1cb5  lea rdi, [rsp]
0000740ecffd1cb9  mov esi, 0x00
0000740ecffd1cbe  mov rax, 0x5E8249CF1530
0000740ecffd1cc8  call rax
0000740ecffd1cca  movaps xmm15, [rsp]
0000740ecffd1ccf  add rsp, 0x30
0000740ecffd1cd3  vmovaps xmm0, [rsp]
0000740ecffd1cd8  vmovaps xmm1, [rsp+0x10]
0000740ecffd1cde  vmovaps xmm2, [rsp+0x20]
0000740ecffd1ce4  vmovaps xmm3, [rsp+0x30]
0000740ecffd1cea  vmovaps xmm4, [rsp+0x40]
0000740ecffd1cf0  vmovaps xmm5, [rsp+0x50]
0000740ecffd1cf6  vmovaps xmm6, [rsp+0x60]
0000740ecffd1cfc  vmovaps xmm7, [rsp+0x70]
0000740ecffd1d02  vmovaps xmm8, [rsp+0x80]
0000740ecffd1d0b  vmovaps xmm9, [rsp+0x90]
0000740ecffd1d14  vmovaps xmm10, [rsp+0xA0]
0000740ecffd1d1d  vmovaps xmm11, [rsp+0xB0]
0000740ecffd1d26  vmovaps xmm12, [rsp+0xC0]
0000740ecffd1d2f  vmovaps xmm13, [rsp+0xD0]
0000740ecffd1d38  vmovaps xmm14, [rsp+0xE0]
0000740ecffd1d41  add rsp, 0xF0
0000740ecffd1d48  pop r11
0000740ecffd1d4a  pop r10
0000740ecffd1d4c  pop r9
0000740ecffd1d4e  pop r8
0000740ecffd1d50  pop rsi
0000740ecffd1d51  pop rdi
0000740ecffd1d52  pop rdx
0000740ecffd1d53  pop rcx
0000740ecffd1d54  pop rax
0000740ecffd1d55  add rsp, 0x08
0000740ecffd1d59  jmp 0x0000740ECFFCFAEB
0000740ecffd1d5e  call 0x0000740ECFDFF430
0000740ecffd1d63  jmp 0x0000740ECFFCFAF8
0000740ecffd1d68  sub rsp, 0x08
0000740ecffd1d6c  push rax
0000740ecffd1d6d  push rcx
0000740ecffd1d6e  push rdx
0000740ecffd1d6f  push rdi
0000740ecffd1d70  push rsi
0000740ecffd1d71  push r8
0000740ecffd1d73  push r9
0000740ecffd1d75  push r10
0000740ecffd1d77  push r11
0000740ecffd1d79  sub rsp, 0xF0
0000740ecffd1d80  vmovaps [rsp], xmm0
0000740ecffd1d85  vmovaps [rsp+0x10], xmm1
0000740ecffd1d8b  vmovaps [rsp+0x20], xmm2
0000740ecffd1d91  vmovaps [rsp+0x30], xmm3
0000740ecffd1d97  vmovaps [rsp+0x40], xmm4
0000740ecffd1d9d  vmovaps [rsp+0x50], xmm5
0000740ecffd1da3  vmovaps [rsp+0x60], xmm6
0000740ecffd1da9  vmovaps [rsp+0x70], xmm7
0000740ecffd1daf  vmovaps [rsp+0x80], xmm8
0000740ecffd1db8  vmovaps [rsp+0x90], xmm9
0000740ecffd1dc1  vmovaps [rsp+0xA0], xmm10
0000740ecffd1dca  vmovaps [rsp+0xB0], xmm11
0000740ecffd1dd3  vmovaps [rsp+0xC0], xmm12
0000740ecffd1ddc  vmovaps [rsp+0xD0], xmm13
0000740ecffd1de5  vmovaps [rsp+0xE0], xmm15
0000740ecffd1dee  sub rsp, 0x30
0000740ecffd1df2  movaps [rsp], xmm14
0000740ecffd1df7  movaps [rsp+0x10], xmm13
0000740ecffd1dfd  movaps [rsp+0x20], xmm2
0000740ecffd1e02  lea rdi, [rsp]
0000740ecffd1e06  mov esi, 0x00
0000740ecffd1e0b  mov rax, 0x5E8249CF1530
0000740ecffd1e15  call rax
0000740ecffd1e17  movaps xmm14, [rsp]
0000740ecffd1e1c  add rsp, 0x30
0000740ecffd1e20  vmovaps xmm0, [rsp]
0000740ecffd1e25  vmovaps xmm1, [rsp+0x10]
0000740ecffd1e2b  vmovaps xmm2, [rsp+0x20]
0000740ecffd1e31  vmovaps xmm3, [rsp+0x30]
0000740ecffd1e37  vmovaps xmm4, [rsp+0x40]
0000740ecffd1e3d  vmovaps xmm5, [rsp+0x50]
0000740ecffd1e43  vmovaps xmm6, [rsp+0x60]
0000740ecffd1e49  vmovaps xmm7, [rsp+0x70]
0000740ecffd1e4f  vmovaps xmm8, [rsp+0x80]
0000740ecffd1e58  vmovaps xmm9, [rsp+0x90]
0000740ecffd1e61  vmovaps xmm10, [rsp+0xA0]
0000740ecffd1e6a  vmovaps xmm11, [rsp+0xB0]
0000740ecffd1e73  vmovaps xmm12, [rsp+0xC0]
0000740ecffd1e7c  vmovaps xmm13, [rsp+0xD0]
0000740ecffd1e85  vmovaps xmm15, [rsp+0xE0]
0000740ecffd1e8e  add rsp, 0xF0
0000740ecffd1e95  pop r11
0000740ecffd1e97  pop r10
0000740ecffd1e99  pop r9
0000740ecffd1e9b  pop r8
0000740ecffd1e9d  pop rsi
0000740ecffd1e9e  pop rdi
0000740ecffd1e9f  pop rdx
0000740ecffd1ea0  pop rcx
0000740ecffd1ea1  pop rax
0000740ecffd1ea2  add rsp, 0x08
0000740ecffd1ea6  jmp 0x0000740ECFFCFB24
0000740ecffd1eab  sub rsp, 0x08
0000740ecffd1eaf  push rax
0000740ecffd1eb0  push rcx
0000740ecffd1eb1  push rdx
0000740ecffd1eb2  push rdi
0000740ecffd1eb3  push rsi
0000740ecffd1eb4  push r8
0000740ecffd1eb6  push r9
0000740ecffd1eb8  push r10
0000740ecffd1eba  push r11
0000740ecffd1ebc  sub rsp, 0xF0
0000740ecffd1ec3  vmovaps [rsp], xmm0
0000740ecffd1ec8  vmovaps [rsp+0x10], xmm2
0000740ecffd1ece  vmovaps [rsp+0x20], xmm3
0000740ecffd1ed4  vmovaps [rsp+0x30], xmm4
0000740ecffd1eda  vmovaps [rsp+0x40], xmm5
0000740ecffd1ee0  vmovaps [rsp+0x50], xmm6
0000740ecffd1ee6  vmovaps [rsp+0x60], xmm7
0000740ecffd1eec  vmovaps [rsp+0x70], xmm8
0000740ecffd1ef2  vmovaps [rsp+0x80], xmm9
0000740ecffd1efb  vmovaps [rsp+0x90], xmm10
0000740ecffd1f04  vmovaps [rsp+0xA0], xmm11
0000740ecffd1f0d  vmovaps [rsp+0xB0], xmm12
0000740ecffd1f16  vmovaps [rsp+0xC0], xmm13
0000740ecffd1f1f  vmovaps [rsp+0xD0], xmm14
0000740ecffd1f28  vmovaps [rsp+0xE0], xmm15
0000740ecffd1f31  sub rsp, 0x30
0000740ecffd1f35  movaps [rsp], xmm1
0000740ecffd1f39  movaps [rsp+0x10], xmm13
0000740ecffd1f3f  movaps [rsp+0x20], xmm2
0000740ecffd1f44  lea rdi, [rsp]
0000740ecffd1f48  mov esi, 0x00
0000740ecffd1f4d  mov rax, 0x5E8249CF1530
0000740ecffd1f57  call rax
0000740ecffd1f59  movaps xmm1, [rsp]
0000740ecffd1f5d  add rsp, 0x30
0000740ecffd1f61  vmovaps xmm0, [rsp]
0000740ecffd1f66  vmovaps xmm2, [rsp+0x10]
0000740ecffd1f6c  vmovaps xmm3, [rsp+0x20]
0000740ecffd1f72  vmovaps xmm4, [rsp+0x30]
0000740ecffd1f78  vmovaps xmm5, [rsp+0x40]
0000740ecffd1f7e  vmovaps xmm6, [rsp+0x50]
0000740ecffd1f84  vmovaps xmm7, [rsp+0x60]
0000740ecffd1f8a  vmovaps xmm8, [rsp+0x70]
0000740ecffd1f90  vmovaps xmm9, [rsp+0x80]
0000740ecffd1f99  vmovaps xmm10, [rsp+0x90]
0000740ecffd1fa2  vmovaps xmm11, [rsp+0xA0]
0000740ecffd1fab  vmovaps xmm12, [rsp+0xB0]
0000740ecffd1fb4  vmovaps xmm13, [rsp+0xC0]
0000740ecffd1fbd  vmovaps xmm14, [rsp+0xD0]
0000740ecffd1fc6  vmovaps xmm15, [rsp+0xE0]
0000740ecffd1fcf  add rsp, 0xF0
0000740ecffd1fd6  pop r11
0000740ecffd1fd8  pop r10
0000740ecffd1fda  pop r9
0000740ecffd1fdc  pop r8
0000740ecffd1fde  pop rsi
0000740ecffd1fdf  pop rdi
0000740ecffd1fe0  pop rdx
0000740ecffd1fe1  pop rcx
0000740ecffd1fe2  pop rax
0000740ecffd1fe3  add rsp, 0x08
0000740ecffd1fe7  jmp 0x0000740ECFFCFB52
0000740ecffd1fec  sub rsp, 0x08
0000740ecffd1ff0  push rax
0000740ecffd1ff1  push rcx
0000740ecffd1ff2  push rdx
0000740ecffd1ff3  push rdi
0000740ecffd1ff4  push rsi
0000740ecffd1ff5  push r8
0000740ecffd1ff7  push r9
0000740ecffd1ff9  push r10
0000740ecffd1ffb  push r11
0000740ecffd1ffd  sub rsp, 0xF0
0000740ecffd2004  vmovaps [rsp], xmm0
0000740ecffd2009  vmovaps [rsp+0x10], xmm1
0000740ecffd200f  vmovaps [rsp+0x20], xmm3
0000740ecffd2015  vmovaps [rsp+0x30], xmm4
0000740ecffd201b  vmovaps [rsp+0x40], xmm5
0000740ecffd2021  vmovaps [rsp+0x50], xmm6
0000740ecffd2027  vmovaps [rsp+0x60], xmm7
0000740ecffd202d  vmovaps [rsp+0x70], xmm8
0000740ecffd2033  vmovaps [rsp+0x80], xmm9
0000740ecffd203c  vmovaps [rsp+0x90], xmm10
0000740ecffd2045  vmovaps [rsp+0xA0], xmm11
0000740ecffd204e  vmovaps [rsp+0xB0], xmm12
0000740ecffd2057  vmovaps [rsp+0xC0], xmm13
0000740ecffd2060  vmovaps [rsp+0xD0], xmm14
0000740ecffd2069  vmovaps [rsp+0xE0], xmm15
0000740ecffd2072  sub rsp, 0x30
0000740ecffd2076  movaps [rsp], xmm2
0000740ecffd207a  movaps [rsp+0x10], xmm1
0000740ecffd207f  movaps [rsp+0x20], xmm13
0000740ecffd2085  lea rdi, [rsp]
0000740ecffd2089  mov esi, 0x00
0000740ecffd208e  mov rax, 0x5E8249CF1530
0000740ecffd2098  call rax
0000740ecffd209a  movaps xmm2, [rsp]
0000740ecffd209e  add rsp, 0x30
0000740ecffd20a2  vmovaps xmm0, [rsp]
0000740ecffd20a7  vmovaps xmm1, [rsp+0x10]
0000740ecffd20ad  vmovaps xmm3, [rsp+0x20]
0000740ecffd20b3  vmovaps xmm4, [rsp+0x30]
0000740ecffd20b9  vmovaps xmm5, [rsp+0x40]
0000740ecffd20bf  vmovaps xmm6, [rsp+0x50]
0000740ecffd20c5  vmovaps xmm7, [rsp+0x60]
0000740ecffd20cb  vmovaps xmm8, [rsp+0x70]
0000740ecffd20d1  vmovaps xmm9, [rsp+0x80]
0000740ecffd20da  vmovaps xmm10, [rsp+0x90]
0000740ecffd20e3  vmovaps xmm11, [rsp+0xA0]
0000740ecffd20ec  vmovaps xmm12, [rsp+0xB0]
0000740ecffd20f5  vmovaps xmm13, [rsp+0xC0]
0000740ecffd20fe  vmovaps xmm14, [rsp+0xD0]
0000740ecffd2107  vmovaps xmm15, [rsp+0xE0]
0000740ecffd2110  add rsp, 0xF0
0000740ecffd2117  pop r11
0000740ecffd2119  pop r10
0000740ecffd211b  pop r9
0000740ecffd211d  pop r8
0000740ecffd211f  pop rsi
0000740ecffd2120  pop rdi
0000740ecffd2121  pop rdx
0000740ecffd2122  pop rcx
0000740ecffd2123  pop rax
0000740ecffd2124  add rsp, 0x08
0000740ecffd2128  jmp 0x0000740ECFFCFBAB
0000740ecffd212d  call 0x0000740ECFDFF430
0000740ecffd2132  jmp 0x0000740ECFFCFBB8
0000740ecffd2137  sub rsp, 0x08
0000740ecffd213b  push rax
0000740ecffd213c  push rcx
0000740ecffd213d  push rdx
0000740ecffd213e  push rdi
0000740ecffd213f  push rsi
0000740ecffd2140  push r8
0000740ecffd2142  push r9
0000740ecffd2144  push r10
0000740ecffd2146  push r11
0000740ecffd2148  sub rsp, 0xF0
0000740ecffd214f  vmovaps [rsp], xmm0
0000740ecffd2154  vmovaps [rsp+0x10], xmm1
0000740ecffd215a  vmovaps [rsp+0x20], xmm2
0000740ecffd2160  vmovaps [rsp+0x30], xmm3
0000740ecffd2166  vmovaps [rsp+0x40], xmm4
0000740ecffd216c  vmovaps [rsp+0x50], xmm5
0000740ecffd2172  vmovaps [rsp+0x60], xmm6
0000740ecffd2178  vmovaps [rsp+0x70], xmm7
0000740ecffd217e  vmovaps [rsp+0x80], xmm8
0000740ecffd2187  vmovaps [rsp+0x90], xmm9
0000740ecffd2190  vmovaps [rsp+0xA0], xmm10
0000740ecffd2199  vmovaps [rsp+0xB0], xmm11
0000740ecffd21a2  vmovaps [rsp+0xC0], xmm12
0000740ecffd21ab  vmovaps [rsp+0xD0], xmm13
0000740ecffd21b4  vmovaps [rsp+0xE0], xmm14
0000740ecffd21bd  sub rsp, 0x30
0000740ecffd21c1  movaps [rsp], xmm15
0000740ecffd21c6  movaps [rsp+0x10], xmm13
0000740ecffd21cc  movaps [rsp+0x20], xmm1
0000740ecffd21d1  lea rdi, [rsp]
0000740ecffd21d5  mov esi, 0x00
0000740ecffd21da  mov rax, 0x5E8249CF1530
0000740ecffd21e4  call rax
0000740ecffd21e6  movaps xmm15, [rsp]
0000740ecffd21eb  add rsp, 0x30
0000740ecffd21ef  vmovaps xmm0, [rsp]
0000740ecffd21f4  vmovaps xmm1, [rsp+0x10]
0000740ecffd21fa  vmovaps xmm2, [rsp+0x20]
0000740ecffd2200  vmovaps xmm3, [rsp+0x30]
0000740ecffd2206  vmovaps xmm4, [rsp+0x40]
0000740ecffd220c  vmovaps xmm5, [rsp+0x50]
0000740ecffd2212  vmovaps xmm6, [rsp+0x60]
0000740ecffd2218  vmovaps xmm7, [rsp+0x70]
0000740ecffd221e  vmovaps xmm8, [rsp+0x80]
0000740ecffd2227  vmovaps xmm9, [rsp+0x90]
0000740ecffd2230  vmovaps xmm10, [rsp+0xA0]
0000740ecffd2239  vmovaps xmm11, [rsp+0xB0]
0000740ecffd2242  vmovaps xmm12, [rsp+0xC0]
0000740ecffd224b  vmovaps xmm13, [rsp+0xD0]
0000740ecffd2254  vmovaps xmm14, [rsp+0xE0]
0000740ecffd225d  add rsp, 0xF0
0000740ecffd2264  pop r11
0000740ecffd2266  pop r10
0000740ecffd2268  pop r9
0000740ecffd226a  pop r8
0000740ecffd226c  pop rsi
0000740ecffd226d  pop rdi
0000740ecffd226e  pop rdx
0000740ecffd226f  pop rcx
0000740ecffd2270  pop rax
0000740ecffd2271  add rsp, 0x08
0000740ecffd2275  jmp 0x0000740ECFFCFBF7
0000740ecffd227a  sub rsp, 0x08
0000740ecffd227e  push rax
0000740ecffd227f  push rcx
0000740ecffd2280  push rdx
0000740ecffd2281  push rdi
0000740ecffd2282  push rsi
0000740ecffd2283  push r8
0000740ecffd2285  push r9
0000740ecffd2287  push r10
0000740ecffd2289  push r11
0000740ecffd228b  sub rsp, 0xF0
0000740ecffd2292  vmovaps [rsp], xmm0
0000740ecffd2297  vmovaps [rsp+0x10], xmm1
0000740ecffd229d  vmovaps [rsp+0x20], xmm2
0000740ecffd22a3  vmovaps [rsp+0x30], xmm3
0000740ecffd22a9  vmovaps [rsp+0x40], xmm4
0000740ecffd22af  vmovaps [rsp+0x50], xmm5
0000740ecffd22b5  vmovaps [rsp+0x60], xmm6
0000740ecffd22bb  vmovaps [rsp+0x70], xmm7
0000740ecffd22c1  vmovaps [rsp+0x80], xmm8
0000740ecffd22ca  vmovaps [rsp+0x90], xmm9
0000740ecffd22d3  vmovaps [rsp+0xA0], xmm10
0000740ecffd22dc  vmovaps [rsp+0xB0], xmm11
0000740ecffd22e5  vmovaps [rsp+0xC0], xmm12
0000740ecffd22ee  vmovaps [rsp+0xD0], xmm13
0000740ecffd22f7  vmovaps [rsp+0xE0], xmm15
0000740ecffd2300  sub rsp, 0x30
0000740ecffd2304  movaps [rsp], xmm14
0000740ecffd2309  movaps [rsp+0x10], xmm11
0000740ecffd230f  movaps [rsp+0x20], xmm1
0000740ecffd2314  lea rdi, [rsp]
0000740ecffd2318  mov esi, 0x00
0000740ecffd231d  mov rax, 0x5E8249CF1530
0000740ecffd2327  call rax
0000740ecffd2329  movaps xmm14, [rsp]
0000740ecffd232e  add rsp, 0x30
0000740ecffd2332  vmovaps xmm0, [rsp]
0000740ecffd2337  vmovaps xmm1, [rsp+0x10]
0000740ecffd233d  vmovaps xmm2, [rsp+0x20]
0000740ecffd2343  vmovaps xmm3, [rsp+0x30]
0000740ecffd2349  vmovaps xmm4, [rsp+0x40]
0000740ecffd234f  vmovaps xmm5, [rsp+0x50]
0000740ecffd2355  vmovaps xmm6, [rsp+0x60]
0000740ecffd235b  vmovaps xmm7, [rsp+0x70]
0000740ecffd2361  vmovaps xmm8, [rsp+0x80]
0000740ecffd236a  vmovaps xmm9, [rsp+0x90]
0000740ecffd2373  vmovaps xmm10, [rsp+0xA0]
0000740ecffd237c  vmovaps xmm11, [rsp+0xB0]
0000740ecffd2385  vmovaps xmm12, [rsp+0xC0]
0000740ecffd238e  vmovaps xmm13, [rsp+0xD0]
0000740ecffd2397  vmovaps xmm15, [rsp+0xE0]
0000740ecffd23a0  add rsp, 0xF0
0000740ecffd23a7  pop r11
0000740ecffd23a9  pop r10
0000740ecffd23ab  pop r9
0000740ecffd23ad  pop r8
0000740ecffd23af  pop rsi
0000740ecffd23b0  pop rdi
0000740ecffd23b1  pop rdx
0000740ecffd23b2  pop rcx
0000740ecffd23b3  pop rax
0000740ecffd23b4  add rsp, 0x08
0000740ecffd23b8  jmp 0x0000740ECFFCFC21
0000740ecffd23bd  sub rsp, 0x08
0000740ecffd23c1  push rax
0000740ecffd23c2  push rcx
0000740ecffd23c3  push rdx
0000740ecffd23c4  push rdi
0000740ecffd23c5  push rsi
0000740ecffd23c6  push r8
0000740ecffd23c8  push r9
0000740ecffd23ca  push r10
0000740ecffd23cc  push r11
0000740ecffd23ce  sub rsp, 0xF0
0000740ecffd23d5  vmovaps [rsp], xmm0
0000740ecffd23da  vmovaps [rsp+0x10], xmm1
0000740ecffd23e0  vmovaps [rsp+0x20], xmm2
0000740ecffd23e6  vmovaps [rsp+0x30], xmm3
0000740ecffd23ec  vmovaps [rsp+0x40], xmm4
0000740ecffd23f2  vmovaps [rsp+0x50], xmm5
0000740ecffd23f8  vmovaps [rsp+0x60], xmm6
0000740ecffd23fe  vmovaps [rsp+0x70], xmm7
0000740ecffd2404  vmovaps [rsp+0x80], xmm8
0000740ecffd240d  vmovaps [rsp+0x90], xmm9
0000740ecffd2416  vmovaps [rsp+0xA0], xmm10
0000740ecffd241f  vmovaps [rsp+0xB0], xmm11
0000740ecffd2428  vmovaps [rsp+0xC0], xmm12
0000740ecffd2431  vmovaps [rsp+0xD0], xmm14
0000740ecffd243a  vmovaps [rsp+0xE0], xmm15
0000740ecffd2443  sub rsp, 0x30
0000740ecffd2447  movaps [rsp], xmm13
0000740ecffd244c  movaps [rsp+0x10], xmm11
0000740ecffd2452  movaps [rsp+0x20], xmm1
0000740ecffd2457  lea rdi, [rsp]
0000740ecffd245b  mov esi, 0x00
0000740ecffd2460  mov rax, 0x5E8249CF1530
0000740ecffd246a  call rax
0000740ecffd246c  movaps xmm13, [rsp]
0000740ecffd2471  add rsp, 0x30
0000740ecffd2475  vmovaps xmm0, [rsp]
0000740ecffd247a  vmovaps xmm1, [rsp+0x10]
0000740ecffd2480  vmovaps xmm2, [rsp+0x20]
0000740ecffd2486  vmovaps xmm3, [rsp+0x30]
0000740ecffd248c  vmovaps xmm4, [rsp+0x40]
0000740ecffd2492  vmovaps xmm5, [rsp+0x50]
0000740ecffd2498  vmovaps xmm6, [rsp+0x60]
0000740ecffd249e  vmovaps xmm7, [rsp+0x70]
0000740ecffd24a4  vmovaps xmm8, [rsp+0x80]
0000740ecffd24ad  vmovaps xmm9, [rsp+0x90]
0000740ecffd24b6  vmovaps xmm10, [rsp+0xA0]
0000740ecffd24bf  vmovaps xmm11, [rsp+0xB0]
0000740ecffd24c8  vmovaps xmm12, [rsp+0xC0]
0000740ecffd24d1  vmovaps xmm14, [rsp+0xD0]
0000740ecffd24da  vmovaps xmm15, [rsp+0xE0]
0000740ecffd24e3  add rsp, 0xF0
0000740ecffd24ea  pop r11
0000740ecffd24ec  pop r10
0000740ecffd24ee  pop r9
0000740ecffd24f0  pop r8
0000740ecffd24f2  pop rsi
0000740ecffd24f3  pop rdi
0000740ecffd24f4  pop rdx
0000740ecffd24f5  pop rcx
0000740ecffd24f6  pop rax
0000740ecffd24f7  add rsp, 0x08
0000740ecffd24fb  jmp 0x0000740ECFFCFC76
0000740ecffd2500  call 0x0000740ECFDFF430
0000740ecffd2505  jmp 0x0000740ECFFCFC83
0000740ecffd250a  sub rsp, 0x08
0000740ecffd250e  push rax
0000740ecffd250f  push rcx
0000740ecffd2510  push rdx
0000740ecffd2511  push rdi
0000740ecffd2512  push rsi
0000740ecffd2513  push r8
0000740ecffd2515  push r9
0000740ecffd2517  push r10
0000740ecffd2519  push r11
0000740ecffd251b  sub rsp, 0xF0
0000740ecffd2522  vmovaps [rsp], xmm0
0000740ecffd2527  vmovaps [rsp+0x10], xmm1
0000740ecffd252d  vmovaps [rsp+0x20], xmm2
0000740ecffd2533  vmovaps [rsp+0x30], xmm3
0000740ecffd2539  vmovaps [rsp+0x40], xmm4
0000740ecffd253f  vmovaps [rsp+0x50], xmm5
0000740ecffd2545  vmovaps [rsp+0x60], xmm6
0000740ecffd254b  vmovaps [rsp+0x70], xmm7
0000740ecffd2551  vmovaps [rsp+0x80], xmm8
0000740ecffd255a  vmovaps [rsp+0x90], xmm9
0000740ecffd2563  vmovaps [rsp+0xA0], xmm10
0000740ecffd256c  vmovaps [rsp+0xB0], xmm11
0000740ecffd2575  vmovaps [rsp+0xC0], xmm12
0000740ecffd257e  vmovaps [rsp+0xD0], xmm13
0000740ecffd2587  vmovaps [rsp+0xE0], xmm14
0000740ecffd2590  sub rsp, 0x30
0000740ecffd2594  movaps [rsp], xmm15
0000740ecffd2599  movaps [rsp+0x10], xmm11
0000740ecffd259f  movaps [rsp+0x20], xmm1
0000740ecffd25a4  lea rdi, [rsp]
0000740ecffd25a8  mov esi, 0x00
0000740ecffd25ad  mov rax, 0x5E8249CF1530
0000740ecffd25b7  call rax
0000740ecffd25b9  movaps xmm15, [rsp]
0000740ecffd25be  add rsp, 0x30
0000740ecffd25c2  vmovaps xmm0, [rsp]
0000740ecffd25c7  vmovaps xmm1, [rsp+0x10]
0000740ecffd25cd  vmovaps xmm2, [rsp+0x20]
0000740ecffd25d3  vmovaps xmm3, [rsp+0x30]
0000740ecffd25d9  vmovaps xmm4, [rsp+0x40]
0000740ecffd25df  vmovaps xmm5, [rsp+0x50]
0000740ecffd25e5  vmovaps xmm6, [rsp+0x60]
0000740ecffd25eb  vmovaps xmm7, [rsp+0x70]
0000740ecffd25f1  vmovaps xmm8, [rsp+0x80]
0000740ecffd25fa  vmovaps xmm9, [rsp+0x90]
0000740ecffd2603  vmovaps xmm10, [rsp+0xA0]
0000740ecffd260c  vmovaps xmm11, [rsp+0xB0]
0000740ecffd2615  vmovaps xmm12, [rsp+0xC0]
0000740ecffd261e  vmovaps xmm13, [rsp+0xD0]
0000740ecffd2627  vmovaps xmm14, [rsp+0xE0]
0000740ecffd2630  add rsp, 0xF0
0000740ecffd2637  pop r11
0000740ecffd2639  pop r10
0000740ecffd263b  pop r9
0000740ecffd263d  pop r8
0000740ecffd263f  pop rsi
0000740ecffd2640  pop rdi
0000740ecffd2641  pop rdx
0000740ecffd2642  pop rcx
0000740ecffd2643  pop rax
0000740ecffd2644  add rsp, 0x08
0000740ecffd2648  jmp 0x0000740ECFFCFCBC
0000740ecffd264d  sub rsp, 0x08
0000740ecffd2651  push rax
0000740ecffd2652  push rcx
0000740ecffd2653  push rdx
0000740ecffd2654  push rdi
0000740ecffd2655  push rsi
0000740ecffd2656  push r8
0000740ecffd2658  push r9
0000740ecffd265a  push r10
0000740ecffd265c  push r11
0000740ecffd265e  sub rsp, 0xF0
0000740ecffd2665  vmovaps [rsp], xmm0
0000740ecffd266a  vmovaps [rsp+0x10], xmm1
0000740ecffd2670  vmovaps [rsp+0x20], xmm2
0000740ecffd2676  vmovaps [rsp+0x30], xmm3
0000740ecffd267c  vmovaps [rsp+0x40], xmm4
0000740ecffd2682  vmovaps [rsp+0x50], xmm5
0000740ecffd2688  vmovaps [rsp+0x60], xmm6
0000740ecffd268e  vmovaps [rsp+0x70], xmm7
0000740ecffd2694  vmovaps [rsp+0x80], xmm8
0000740ecffd269d  vmovaps [rsp+0x90], xmm9
0000740ecffd26a6  vmovaps [rsp+0xA0], xmm10
0000740ecffd26af  vmovaps [rsp+0xB0], xmm12
0000740ecffd26b8  vmovaps [rsp+0xC0], xmm13
0000740ecffd26c1  vmovaps [rsp+0xD0], xmm14
0000740ecffd26ca  vmovaps [rsp+0xE0], xmm15
0000740ecffd26d3  sub rsp, 0x30
0000740ecffd26d7  movaps [rsp], xmm11
0000740ecffd26dc  movaps [rsp+0x10], xmm6
0000740ecffd26e1  movaps [rsp+0x20], xmm14
0000740ecffd26e7  lea rdi, [rsp]
0000740ecffd26eb  mov esi, 0x00
0000740ecffd26f0  mov rax, 0x5E8249CF1530
0000740ecffd26fa  call rax
0000740ecffd26fc  movaps xmm11, [rsp]
0000740ecffd2701  add rsp, 0x30
0000740ecffd2705  vmovaps xmm0, [rsp]
0000740ecffd270a  vmovaps xmm1, [rsp+0x10]
0000740ecffd2710  vmovaps xmm2, [rsp+0x20]
0000740ecffd2716  vmovaps xmm3, [rsp+0x30]
0000740ecffd271c  vmovaps xmm4, [rsp+0x40]
0000740ecffd2722  vmovaps xmm5, [rsp+0x50]
0000740ecffd2728  vmovaps xmm6, [rsp+0x60]
0000740ecffd272e  vmovaps xmm7, [rsp+0x70]
0000740ecffd2734  vmovaps xmm8, [rsp+0x80]
0000740ecffd273d  vmovaps xmm9, [rsp+0x90]
0000740ecffd2746  vmovaps xmm10, [rsp+0xA0]
0000740ecffd274f  vmovaps xmm12, [rsp+0xB0]
0000740ecffd2758  vmovaps xmm13, [rsp+0xC0]
0000740ecffd2761  vmovaps xmm14, [rsp+0xD0]
0000740ecffd276a  vmovaps xmm15, [rsp+0xE0]
0000740ecffd2773  add rsp, 0xF0
0000740ecffd277a  pop r11
0000740ecffd277c  pop r10
0000740ecffd277e  pop r9
0000740ecffd2780  pop r8
0000740ecffd2782  pop rsi
0000740ecffd2783  pop rdi
0000740ecffd2784  pop rdx
0000740ecffd2785  pop rcx
0000740ecffd2786  pop rax
0000740ecffd2787  add rsp, 0x08
0000740ecffd278b  jmp 0x0000740ECFFCFD34
0000740ecffd2790  call 0x0000740ECFDFF430
0000740ecffd2795  jmp 0x0000740ECFFCFD3E
0000740ecffd279a  sub rsp, 0x08
0000740ecffd279e  push rax
0000740ecffd279f  push rcx
0000740ecffd27a0  push rdx
0000740ecffd27a1  push rdi
0000740ecffd27a2  push rsi
0000740ecffd27a3  push r8
0000740ecffd27a5  push r9
0000740ecffd27a7  push r10
0000740ecffd27a9  push r11
0000740ecffd27ab  sub rsp, 0xF0
0000740ecffd27b2  vmovaps [rsp], xmm0
0000740ecffd27b7  vmovaps [rsp+0x10], xmm1
0000740ecffd27bd  vmovaps [rsp+0x20], xmm2
0000740ecffd27c3  vmovaps [rsp+0x30], xmm3
0000740ecffd27c9  vmovaps [rsp+0x40], xmm4
0000740ecffd27cf  vmovaps [rsp+0x50], xmm5
0000740ecffd27d5  vmovaps [rsp+0x60], xmm6
0000740ecffd27db  vmovaps [rsp+0x70], xmm7
0000740ecffd27e1  vmovaps [rsp+0x80], xmm8
0000740ecffd27ea  vmovaps [rsp+0x90], xmm9
0000740ecffd27f3  vmovaps [rsp+0xA0], xmm10
0000740ecffd27fc  vmovaps [rsp+0xB0], xmm11
0000740ecffd2805  vmovaps [rsp+0xC0], xmm12
0000740ecffd280e  vmovaps [rsp+0xD0], xmm13
0000740ecffd2817  vmovaps [rsp+0xE0], xmm15
0000740ecffd2820  sub rsp, 0x30
0000740ecffd2824  movaps [rsp], xmm14
0000740ecffd2829  movaps [rsp+0x10], xmm6
0000740ecffd282e  movaps [rsp+0x20], xmm2
0000740ecffd2833  lea rdi, [rsp]
0000740ecffd2837  mov esi, 0x00
0000740ecffd283c  mov rax, 0x5E8249CF1530
0000740ecffd2846  call rax
0000740ecffd2848  movaps xmm14, [rsp]
0000740ecffd284d  add rsp, 0x30
0000740ecffd2851  vmovaps xmm0, [rsp]
0000740ecffd2856  vmovaps xmm1, [rsp+0x10]
0000740ecffd285c  vmovaps xmm2, [rsp+0x20]
0000740ecffd2862  vmovaps xmm3, [rsp+0x30]
0000740ecffd2868  vmovaps xmm4, [rsp+0x40]
0000740ecffd286e  vmovaps xmm5, [rsp+0x50]
0000740ecffd2874  vmovaps xmm6, [rsp+0x60]
0000740ecffd287a  vmovaps xmm7, [rsp+0x70]
0000740ecffd2880  vmovaps xmm8, [rsp+0x80]
0000740ecffd2889  vmovaps xmm9, [rsp+0x90]
0000740ecffd2892  vmovaps xmm10, [rsp+0xA0]
0000740ecffd289b  vmovaps xmm11, [rsp+0xB0]
0000740ecffd28a4  vmovaps xmm12, [rsp+0xC0]
0000740ecffd28ad  vmovaps xmm13, [rsp+0xD0]
0000740ecffd28b6  vmovaps xmm15, [rsp+0xE0]
0000740ecffd28bf  add rsp, 0xF0
0000740ecffd28c6  pop r11
0000740ecffd28c8  pop r10
0000740ecffd28ca  pop r9
0000740ecffd28cc  pop r8
0000740ecffd28ce  pop rsi
0000740ecffd28cf  pop rdi
0000740ecffd28d0  pop rdx
0000740ecffd28d1  pop rcx
0000740ecffd28d2  pop rax
0000740ecffd28d3  add rsp, 0x08
0000740ecffd28d7  jmp 0x0000740ECFFCFD72
0000740ecffd28dc  sub rsp, 0x08
0000740ecffd28e0  push rax
0000740ecffd28e1  push rcx
0000740ecffd28e2  push rdx
0000740ecffd28e3  push rdi
0000740ecffd28e4  push rsi
0000740ecffd28e5  push r8
0000740ecffd28e7  push r9
0000740ecffd28e9  push r10
0000740ecffd28eb  push r11
0000740ecffd28ed  sub rsp, 0xF0
0000740ecffd28f4  vmovaps [rsp], xmm0
0000740ecffd28f9  vmovaps [rsp+0x10], xmm1
0000740ecffd28ff  vmovaps [rsp+0x20], xmm2
0000740ecffd2905  vmovaps [rsp+0x30], xmm3
0000740ecffd290b  vmovaps [rsp+0x40], xmm4
0000740ecffd2911  vmovaps [rsp+0x50], xmm5
0000740ecffd2917  vmovaps [rsp+0x60], xmm7
0000740ecffd291d  vmovaps [rsp+0x70], xmm8
0000740ecffd2923  vmovaps [rsp+0x80], xmm9
0000740ecffd292c  vmovaps [rsp+0x90], xmm10
0000740ecffd2935  vmovaps [rsp+0xA0], xmm11
0000740ecffd293e  vmovaps [rsp+0xB0], xmm12
0000740ecffd2947  vmovaps [rsp+0xC0], xmm13
0000740ecffd2950  vmovaps [rsp+0xD0], xmm14
0000740ecffd2959  vmovaps [rsp+0xE0], xmm15
0000740ecffd2962  sub rsp, 0x30
0000740ecffd2966  movaps [rsp], xmm6
0000740ecffd296a  movaps [rsp+0x10], xmm5
0000740ecffd296f  movaps [rsp+0x20], xmm1
0000740ecffd2974  lea rdi, [rsp]
0000740ecffd2978  mov esi, 0x00
0000740ecffd297d  mov rax, 0x5E8249CF1530
0000740ecffd2987  call rax
0000740ecffd2989  movaps xmm6, [rsp]
0000740ecffd298d  add rsp, 0x30
0000740ecffd2991  vmovaps xmm0, [rsp]
0000740ecffd2996  vmovaps xmm1, [rsp+0x10]
0000740ecffd299c  vmovaps xmm2, [rsp+0x20]
0000740ecffd29a2  vmovaps xmm3, [rsp+0x30]
0000740ecffd29a8  vmovaps xmm4, [rsp+0x40]
0000740ecffd29ae  vmovaps xmm5, [rsp+0x50]
0000740ecffd29b4  vmovaps xmm7, [rsp+0x60]
0000740ecffd29ba  vmovaps xmm8, [rsp+0x70]
0000740ecffd29c0  vmovaps xmm9, [rsp+0x80]
0000740ecffd29c9  vmovaps xmm10, [rsp+0x90]
0000740ecffd29d2  vmovaps xmm11, [rsp+0xA0]
0000740ecffd29db  vmovaps xmm12, [rsp+0xB0]
0000740ecffd29e4  vmovaps xmm13, [rsp+0xC0]
0000740ecffd29ed  vmovaps xmm14, [rsp+0xD0]
0000740ecffd29f6  vmovaps xmm15, [rsp+0xE0]
0000740ecffd29ff  add rsp, 0xF0
0000740ecffd2a06  pop r11
0000740ecffd2a08  pop r10
0000740ecffd2a0a  pop r9
0000740ecffd2a0c  pop r8
0000740ecffd2a0e  pop rsi
0000740ecffd2a0f  pop rdi
0000740ecffd2a10  pop rdx
0000740ecffd2a11  pop rcx
0000740ecffd2a12  pop rax
0000740ecffd2a13  add rsp, 0x08
0000740ecffd2a17  jmp 0x0000740ECFFCFD98
0000740ecffd2a1c  sub rsp, 0x08
0000740ecffd2a20  push rax
0000740ecffd2a21  push rcx
0000740ecffd2a22  push rdx
0000740ecffd2a23  push rdi
0000740ecffd2a24  push rsi
0000740ecffd2a25  push r8
0000740ecffd2a27  push r9
0000740ecffd2a29  push r10
0000740ecffd2a2b  push r11
0000740ecffd2a2d  sub rsp, 0xF0
0000740ecffd2a34  vmovaps [rsp], xmm0
0000740ecffd2a39  vmovaps [rsp+0x10], xmm2
0000740ecffd2a3f  vmovaps [rsp+0x20], xmm3
0000740ecffd2a45  vmovaps [rsp+0x30], xmm4
0000740ecffd2a4b  vmovaps [rsp+0x40], xmm5
0000740ecffd2a51  vmovaps [rsp+0x50], xmm6
0000740ecffd2a57  vmovaps [rsp+0x60], xmm7
0000740ecffd2a5d  vmovaps [rsp+0x70], xmm8
0000740ecffd2a63  vmovaps [rsp+0x80], xmm9
0000740ecffd2a6c  vmovaps [rsp+0x90], xmm10
0000740ecffd2a75  vmovaps [rsp+0xA0], xmm11
0000740ecffd2a7e  vmovaps [rsp+0xB0], xmm12
0000740ecffd2a87  vmovaps [rsp+0xC0], xmm13
0000740ecffd2a90  vmovaps [rsp+0xD0], xmm14
0000740ecffd2a99  vmovaps [rsp+0xE0], xmm15
0000740ecffd2aa2  sub rsp, 0x30
0000740ecffd2aa6  movaps [rsp], xmm1
0000740ecffd2aaa  movaps [rsp+0x10], xmm5
0000740ecffd2aaf  movaps [rsp+0x20], xmm13
0000740ecffd2ab5  lea rdi, [rsp]
0000740ecffd2ab9  mov esi, 0x00
0000740ecffd2abe  mov rax, 0x5E8249CF1530
0000740ecffd2ac8  call rax
0000740ecffd2aca  movaps xmm1, [rsp]
0000740ecffd2ace  add rsp, 0x30
0000740ecffd2ad2  vmovaps xmm0, [rsp]
0000740ecffd2ad7  vmovaps xmm2, [rsp+0x10]
0000740ecffd2add  vmovaps xmm3, [rsp+0x20]
0000740ecffd2ae3  vmovaps xmm4, [rsp+0x30]
0000740ecffd2ae9  vmovaps xmm5, [rsp+0x40]
0000740ecffd2aef  vmovaps xmm6, [rsp+0x50]
0000740ecffd2af5  vmovaps xmm7, [rsp+0x60]
0000740ecffd2afb  vmovaps xmm8, [rsp+0x70]
0000740ecffd2b01  vmovaps xmm9, [rsp+0x80]
0000740ecffd2b0a  vmovaps xmm10, [rsp+0x90]
0000740ecffd2b13  vmovaps xmm11, [rsp+0xA0]
0000740ecffd2b1c  vmovaps xmm12, [rsp+0xB0]
0000740ecffd2b25  vmovaps xmm13, [rsp+0xC0]
0000740ecffd2b2e  vmovaps xmm14, [rsp+0xD0]
0000740ecffd2b37  vmovaps xmm15, [rsp+0xE0]
0000740ecffd2b40  add rsp, 0xF0
0000740ecffd2b47  pop r11
0000740ecffd2b49  pop r10
0000740ecffd2b4b  pop r9
0000740ecffd2b4d  pop r8
0000740ecffd2b4f  pop rsi
0000740ecffd2b50  pop rdi
0000740ecffd2b51  pop rdx
0000740ecffd2b52  pop rcx
0000740ecffd2b53  pop rax
0000740ecffd2b54  add rsp, 0x08
0000740ecffd2b58  jmp 0x0000740ECFFCFDB6
0000740ecffd2b5d  sub rsp, 0x08
0000740ecffd2b61  push rax
0000740ecffd2b62  push rcx
0000740ecffd2b63  push rdx
0000740ecffd2b64  push rdi
0000740ecffd2b65  push rsi
0000740ecffd2b66  push r8
0000740ecffd2b68  push r9
0000740ecffd2b6a  push r10
0000740ecffd2b6c  push r11
0000740ecffd2b6e  sub rsp, 0xF0
0000740ecffd2b75  vmovaps [rsp], xmm0
0000740ecffd2b7a  vmovaps [rsp+0x10], xmm1
0000740ecffd2b80  vmovaps [rsp+0x20], xmm2
0000740ecffd2b86  vmovaps [rsp+0x30], xmm3
0000740ecffd2b8c  vmovaps [rsp+0x40], xmm4
0000740ecffd2b92  vmovaps [rsp+0x50], xmm6
0000740ecffd2b98  vmovaps [rsp+0x60], xmm7
0000740ecffd2b9e  vmovaps [rsp+0x70], xmm8
0000740ecffd2ba4  vmovaps [rsp+0x80], xmm9
0000740ecffd2bad  vmovaps [rsp+0x90], xmm10
0000740ecffd2bb6  vmovaps [rsp+0xA0], xmm11
0000740ecffd2bbf  vmovaps [rsp+0xB0], xmm12
0000740ecffd2bc8  vmovaps [rsp+0xC0], xmm13
0000740ecffd2bd1  vmovaps [rsp+0xD0], xmm14
0000740ecffd2bda  vmovaps [rsp+0xE0], xmm15
0000740ecffd2be3  sub rsp, 0x30
0000740ecffd2be7  movaps [rsp], xmm5
0000740ecffd2beb  movaps [rsp+0x10], xmm2
0000740ecffd2bf0  movaps [rsp+0x20], xmm13
0000740ecffd2bf6  lea rdi, [rsp]
0000740ecffd2bfa  mov esi, 0x00
0000740ecffd2bff  mov rax, 0x5E8249CF1530
0000740ecffd2c09  call rax
0000740ecffd2c0b  movaps xmm5, [rsp]
0000740ecffd2c0f  add rsp, 0x30
0000740ecffd2c13  vmovaps xmm0, [rsp]
0000740ecffd2c18  vmovaps xmm1, [rsp+0x10]
0000740ecffd2c1e  vmovaps xmm2, [rsp+0x20]
0000740ecffd2c24  vmovaps xmm3, [rsp+0x30]
0000740ecffd2c2a  vmovaps xmm4, [rsp+0x40]
0000740ecffd2c30  vmovaps xmm6, [rsp+0x50]
0000740ecffd2c36  vmovaps xmm7, [rsp+0x60]
0000740ecffd2c3c  vmovaps xmm8, [rsp+0x70]
0000740ecffd2c42  vmovaps xmm9, [rsp+0x80]
0000740ecffd2c4b  vmovaps xmm10, [rsp+0x90]
0000740ecffd2c54  vmovaps xmm11, [rsp+0xA0]
0000740ecffd2c5d  vmovaps xmm12, [rsp+0xB0]
0000740ecffd2c66  vmovaps xmm13, [rsp+0xC0]
0000740ecffd2c6f  vmovaps xmm14, [rsp+0xD0]
0000740ecffd2c78  vmovaps xmm15, [rsp+0xE0]
0000740ecffd2c81  add rsp, 0xF0
0000740ecffd2c88  pop r11
0000740ecffd2c8a  pop r10
0000740ecffd2c8c  pop r9
0000740ecffd2c8e  pop r8
0000740ecffd2c90  pop rsi
0000740ecffd2c91  pop rdi
0000740ecffd2c92  pop rdx
0000740ecffd2c93  pop rcx
0000740ecffd2c94  pop rax
0000740ecffd2c95  add rsp, 0x08
0000740ecffd2c99  jmp 0x0000740ECFFCFDEC
0000740ecffd2c9e  sub rsp, 0x08
0000740ecffd2ca2  push rax
0000740ecffd2ca3  push rcx
0000740ecffd2ca4  push rdx
0000740ecffd2ca5  push rdi
0000740ecffd2ca6  push rsi
0000740ecffd2ca7  push r8
0000740ecffd2ca9  push r9
0000740ecffd2cab  push r10
0000740ecffd2cad  push r11
0000740ecffd2caf  sub rsp, 0xF0
0000740ecffd2cb6  vmovaps [rsp], xmm0
0000740ecffd2cbb  vmovaps [rsp+0x10], xmm1
0000740ecffd2cc1  vmovaps [rsp+0x20], xmm2
0000740ecffd2cc7  vmovaps [rsp+0x30], xmm3
0000740ecffd2ccd  vmovaps [rsp+0x40], xmm4
0000740ecffd2cd3  vmovaps [rsp+0x50], xmm5
0000740ecffd2cd9  vmovaps [rsp+0x60], xmm6
0000740ecffd2cdf  vmovaps [rsp+0x70], xmm7
0000740ecffd2ce5  vmovaps [rsp+0x80], xmm8
0000740ecffd2cee  vmovaps [rsp+0x90], xmm9
0000740ecffd2cf7  vmovaps [rsp+0xA0], xmm10
0000740ecffd2d00  vmovaps [rsp+0xB0], xmm11
0000740ecffd2d09  vmovaps [rsp+0xC0], xmm12
0000740ecffd2d12  vmovaps [rsp+0xD0], xmm14
0000740ecffd2d1b  vmovaps [rsp+0xE0], xmm15
0000740ecffd2d24  sub rsp, 0x30
0000740ecffd2d28  movaps [rsp], xmm13
0000740ecffd2d2d  movaps [rsp+0x10], xmm10
0000740ecffd2d33  movaps [rsp+0x20], xmm1
0000740ecffd2d38  lea rdi, [rsp]
0000740ecffd2d3c  mov esi, 0x00
0000740ecffd2d41  mov rax, 0x5E8249CF1530
0000740ecffd2d4b  call rax
0000740ecffd2d4d  movaps xmm13, [rsp]
0000740ecffd2d52  add rsp, 0x30
0000740ecffd2d56  vmovaps xmm0, [rsp]
0000740ecffd2d5b  vmovaps xmm1, [rsp+0x10]
0000740ecffd2d61  vmovaps xmm2, [rsp+0x20]
0000740ecffd2d67  vmovaps xmm3, [rsp+0x30]
0000740ecffd2d6d  vmovaps xmm4, [rsp+0x40]
0000740ecffd2d73  vmovaps xmm5, [rsp+0x50]
0000740ecffd2d79  vmovaps xmm6, [rsp+0x60]
0000740ecffd2d7f  vmovaps xmm7, [rsp+0x70]
0000740ecffd2d85  vmovaps xmm8, [rsp+0x80]
0000740ecffd2d8e  vmovaps xmm9, [rsp+0x90]
0000740ecffd2d97  vmovaps xmm10, [rsp+0xA0]
0000740ecffd2da0  vmovaps xmm11, [rsp+0xB0]
0000740ecffd2da9  vmovaps xmm12, [rsp+0xC0]
0000740ecffd2db2  vmovaps xmm14, [rsp+0xD0]
0000740ecffd2dbb  vmovaps xmm15, [rsp+0xE0]
0000740ecffd2dc4  add rsp, 0xF0
0000740ecffd2dcb  pop r11
0000740ecffd2dcd  pop r10
0000740ecffd2dcf  pop r9
0000740ecffd2dd1  pop r8
0000740ecffd2dd3  pop rsi
0000740ecffd2dd4  pop rdi
0000740ecffd2dd5  pop rdx
0000740ecffd2dd6  pop rcx
0000740ecffd2dd7  pop rax
0000740ecffd2dd8  add rsp, 0x08
0000740ecffd2ddc  jmp 0x0000740ECFFCFE15
0000740ecffd2de1  sub rsp, 0x08
0000740ecffd2de5  push rax
0000740ecffd2de6  push rcx
0000740ecffd2de7  push rdx
0000740ecffd2de8  push rdi
0000740ecffd2de9  push rsi
0000740ecffd2dea  push r8
0000740ecffd2dec  push r9
0000740ecffd2dee  push r10
0000740ecffd2df0  push r11
0000740ecffd2df2  sub rsp, 0xF0
0000740ecffd2df9  vmovaps [rsp], xmm0
0000740ecffd2dfe  vmovaps [rsp+0x10], xmm2
0000740ecffd2e04  vmovaps [rsp+0x20], xmm3
0000740ecffd2e0a  vmovaps [rsp+0x30], xmm4
0000740ecffd2e10  vmovaps [rsp+0x40], xmm5
0000740ecffd2e16  vmovaps [rsp+0x50], xmm6
0000740ecffd2e1c  vmovaps [rsp+0x60], xmm7
0000740ecffd2e22  vmovaps [rsp+0x70], xmm8
0000740ecffd2e28  vmovaps [rsp+0x80], xmm9
0000740ecffd2e31  vmovaps [rsp+0x90], xmm10
0000740ecffd2e3a  vmovaps [rsp+0xA0], xmm11
0000740ecffd2e43  vmovaps [rsp+0xB0], xmm12
0000740ecffd2e4c  vmovaps [rsp+0xC0], xmm13
0000740ecffd2e55  vmovaps [rsp+0xD0], xmm14
0000740ecffd2e5e  vmovaps [rsp+0xE0], xmm15
0000740ecffd2e67  sub rsp, 0x30
0000740ecffd2e6b  movaps [rsp], xmm1
0000740ecffd2e6f  movaps [rsp+0x10], xmm15
0000740ecffd2e75  movaps [rsp+0x20], xmm10
0000740ecffd2e7b  lea rdi, [rsp]
0000740ecffd2e7f  mov esi, 0x00
0000740ecffd2e84  mov rax, 0x5E8249CF1530
0000740ecffd2e8e  call rax
0000740ecffd2e90  movaps xmm1, [rsp]
0000740ecffd2e94  add rsp, 0x30
0000740ecffd2e98  vmovaps xmm0, [rsp]
0000740ecffd2e9d  vmovaps xmm2, [rsp+0x10]
0000740ecffd2ea3  vmovaps xmm3, [rsp+0x20]
0000740ecffd2ea9  vmovaps xmm4, [rsp+0x30]
0000740ecffd2eaf  vmovaps xmm5, [rsp+0x40]
0000740ecffd2eb5  vmovaps xmm6, [rsp+0x50]
0000740ecffd2ebb  vmovaps xmm7, [rsp+0x60]
0000740ecffd2ec1  vmovaps xmm8, [rsp+0x70]
0000740ecffd2ec7  vmovaps xmm9, [rsp+0x80]
0000740ecffd2ed0  vmovaps xmm10, [rsp+0x90]
0000740ecffd2ed9  vmovaps xmm11, [rsp+0xA0]
0000740ecffd2ee2  vmovaps xmm12, [rsp+0xB0]
0000740ecffd2eeb  vmovaps xmm13, [rsp+0xC0]
0000740ecffd2ef4  vmovaps xmm14, [rsp+0xD0]
0000740ecffd2efd  vmovaps xmm15, [rsp+0xE0]
0000740ecffd2f06  add rsp, 0xF0
0000740ecffd2f0d  pop r11
0000740ecffd2f0f  pop r10
0000740ecffd2f11  pop r9
0000740ecffd2f13  pop r8
0000740ecffd2f15  pop rsi
0000740ecffd2f16  pop rdi
0000740ecffd2f17  pop rdx
0000740ecffd2f18  pop rcx
0000740ecffd2f19  pop rax
0000740ecffd2f1a  add rsp, 0x08
0000740ecffd2f1e  jmp 0x0000740ECFFCFE34
0000740ecffd2f23  sub rsp, 0x08
0000740ecffd2f27  push rax
0000740ecffd2f28  push rcx
0000740ecffd2f29  push rdx
0000740ecffd2f2a  push rdi
0000740ecffd2f2b  push rsi
0000740ecffd2f2c  push r8
0000740ecffd2f2e  push r9
0000740ecffd2f30  push r10
0000740ecffd2f32  push r11
0000740ecffd2f34  sub rsp, 0xF0
0000740ecffd2f3b  vmovaps [rsp], xmm0
0000740ecffd2f40  vmovaps [rsp+0x10], xmm1
0000740ecffd2f46  vmovaps [rsp+0x20], xmm2
0000740ecffd2f4c  vmovaps [rsp+0x30], xmm3
0000740ecffd2f52  vmovaps [rsp+0x40], xmm4
0000740ecffd2f58  vmovaps [rsp+0x50], xmm5
0000740ecffd2f5e  vmovaps [rsp+0x60], xmm6
0000740ecffd2f64  vmovaps [rsp+0x70], xmm7
0000740ecffd2f6a  vmovaps [rsp+0x80], xmm8
0000740ecffd2f73  vmovaps [rsp+0x90], xmm9
0000740ecffd2f7c  vmovaps [rsp+0xA0], xmm10
0000740ecffd2f85  vmovaps [rsp+0xB0], xmm11
0000740ecffd2f8e  vmovaps [rsp+0xC0], xmm12
0000740ecffd2f97  vmovaps [rsp+0xD0], xmm13
0000740ecffd2fa0  vmovaps [rsp+0xE0], xmm14
0000740ecffd2fa9  sub rsp, 0x30
0000740ecffd2fad  movaps [rsp], xmm15
0000740ecffd2fb2  movaps [rsp+0x10], xmm10
0000740ecffd2fb8  movaps [rsp+0x20], xmm11
0000740ecffd2fbe  lea rdi, [rsp]
0000740ecffd2fc2  mov esi, 0x00
0000740ecffd2fc7  mov rax, 0x5E8249CF1530
0000740ecffd2fd1  call rax
0000740ecffd2fd3  movaps xmm15, [rsp]
0000740ecffd2fd8  add rsp, 0x30
0000740ecffd2fdc  vmovaps xmm0, [rsp]
0000740ecffd2fe1  vmovaps xmm1, [rsp+0x10]
0000740ecffd2fe7  vmovaps xmm2, [rsp+0x20]
0000740ecffd2fed  vmovaps xmm3, [rsp+0x30]
0000740ecffd2ff3  vmovaps xmm4, [rsp+0x40]
0000740ecffd2ff9  vmovaps xmm5, [rsp+0x50]
0000740ecffd2fff  vmovaps xmm6, [rsp+0x60]
0000740ecffd3005  vmovaps xmm7, [rsp+0x70]
0000740ecffd300b  vmovaps xmm8, [rsp+0x80]
0000740ecffd3014  vmovaps xmm9, [rsp+0x90]
0000740ecffd301d  vmovaps xmm10, [rsp+0xA0]
0000740ecffd3026  vmovaps xmm11, [rsp+0xB0]
0000740ecffd302f  vmovaps xmm12, [rsp+0xC0]
0000740ecffd3038  vmovaps xmm13, [rsp+0xD0]
0000740ecffd3041  vmovaps xmm14, [rsp+0xE0]
0000740ecffd304a  add rsp, 0xF0
0000740ecffd3051  pop r11
0000740ecffd3053  pop r10
0000740ecffd3055  pop r9
0000740ecffd3057  pop r8
0000740ecffd3059  pop rsi
0000740ecffd305a  pop rdi
0000740ecffd305b  pop rdx
0000740ecffd305c  pop rcx
0000740ecffd305d  pop rax
0000740ecffd305e  add rsp, 0x08
0000740ecffd3062  jmp 0x0000740ECFFCFE57
0000740ecffd3067  sub rsp, 0x08
0000740ecffd306b  push rax
0000740ecffd306c  push rcx
0000740ecffd306d  push rdx
0000740ecffd306e  push rdi
0000740ecffd306f  push rsi
0000740ecffd3070  push r8
0000740ecffd3072  push r9
0000740ecffd3074  push r10
0000740ecffd3076  push r11
0000740ecffd3078  sub rsp, 0xF0
0000740ecffd307f  vmovaps [rsp], xmm0
0000740ecffd3084  vmovaps [rsp+0x10], xmm1
0000740ecffd308a  vmovaps [rsp+0x20], xmm2
0000740ecffd3090  vmovaps [rsp+0x30], xmm3
0000740ecffd3096  vmovaps [rsp+0x40], xmm4
0000740ecffd309c  vmovaps [rsp+0x50], xmm5
0000740ecffd30a2  vmovaps [rsp+0x60], xmm6
0000740ecffd30a8  vmovaps [rsp+0x70], xmm7
0000740ecffd30ae  vmovaps [rsp+0x80], xmm8
0000740ecffd30b7  vmovaps [rsp+0x90], xmm9
0000740ecffd30c0  vmovaps [rsp+0xA0], xmm11
0000740ecffd30c9  vmovaps [rsp+0xB0], xmm12
0000740ecffd30d2  vmovaps [rsp+0xC0], xmm13
0000740ecffd30db  vmovaps [rsp+0xD0], xmm14
0000740ecffd30e4  vmovaps [rsp+0xE0], xmm15
0000740ecffd30ed  sub rsp, 0x30
0000740ecffd30f1  movaps [rsp], xmm10
0000740ecffd30f6  movaps [rsp+0x10], xmm12
0000740ecffd30fc  movaps [rsp+0x20], xmm11
0000740ecffd3102  lea rdi, [rsp]
0000740ecffd3106  mov esi, 0x00
0000740ecffd310b  mov rax, 0x5E8249CF1530
0000740ecffd3115  call rax
0000740ecffd3117  movaps xmm10, [rsp]
0000740ecffd311c  add rsp, 0x30
0000740ecffd3120  vmovaps xmm0, [rsp]
0000740ecffd3125  vmovaps xmm1, [rsp+0x10]
0000740ecffd312b  vmovaps xmm2, [rsp+0x20]
0000740ecffd3131  vmovaps xmm3, [rsp+0x30]
0000740ecffd3137  vmovaps xmm4, [rsp+0x40]
0000740ecffd313d  vmovaps xmm5, [rsp+0x50]
0000740ecffd3143  vmovaps xmm6, [rsp+0x60]
0000740ecffd3149  vmovaps xmm7, [rsp+0x70]
0000740ecffd314f  vmovaps xmm8, [rsp+0x80]
0000740ecffd3158  vmovaps xmm9, [rsp+0x90]
0000740ecffd3161  vmovaps xmm11, [rsp+0xA0]
0000740ecffd316a  vmovaps xmm12, [rsp+0xB0]
0000740ecffd3173  vmovaps xmm13, [rsp+0xC0]
0000740ecffd317c  vmovaps xmm14, [rsp+0xD0]
0000740ecffd3185  vmovaps xmm15, [rsp+0xE0]
0000740ecffd318e  add rsp, 0xF0
0000740ecffd3195  pop r11
0000740ecffd3197  pop r10
0000740ecffd3199  pop r9
0000740ecffd319b  pop r8
0000740ecffd319d  pop rsi
0000740ecffd319e  pop rdi
0000740ecffd319f  pop rdx
0000740ecffd31a0  pop rcx
0000740ecffd31a1  pop rax
0000740ecffd31a2  add rsp, 0x08
0000740ecffd31a6  jmp 0x0000740ECFFCFE80
0000740ecffd31ab  sub rsp, 0x08
0000740ecffd31af  push rax
0000740ecffd31b0  push rcx
0000740ecffd31b1  push rdx
0000740ecffd31b2  push rdi
0000740ecffd31b3  push rsi
0000740ecffd31b4  push r8
0000740ecffd31b6  push r9
0000740ecffd31b8  push r10
0000740ecffd31ba  push r11
0000740ecffd31bc  sub rsp, 0xF0
0000740ecffd31c3  vmovaps [rsp], xmm0
0000740ecffd31c8  vmovaps [rsp+0x10], xmm1
0000740ecffd31ce  vmovaps [rsp+0x20], xmm2
0000740ecffd31d4  vmovaps [rsp+0x30], xmm3
0000740ecffd31da  vmovaps [rsp+0x40], xmm4
0000740ecffd31e0  vmovaps [rsp+0x50], xmm5
0000740ecffd31e6  vmovaps [rsp+0x60], xmm6
0000740ecffd31ec  vmovaps [rsp+0x70], xmm7
0000740ecffd31f2  vmovaps [rsp+0x80], xmm8
0000740ecffd31fb  vmovaps [rsp+0x90], xmm9
0000740ecffd3204  vmovaps [rsp+0xA0], xmm10
0000740ecffd320d  vmovaps [rsp+0xB0], xmm12
0000740ecffd3216  vmovaps [rsp+0xC0], xmm13
0000740ecffd321f  vmovaps [rsp+0xD0], xmm14
0000740ecffd3228  vmovaps [rsp+0xE0], xmm15
0000740ecffd3231  sub rsp, 0x30
0000740ecffd3235  movaps [rsp], xmm11
0000740ecffd323a  movaps [rsp+0x10], xmm2
0000740ecffd323f  movaps [rsp+0x20], xmm12
0000740ecffd3245  lea rdi, [rsp]
0000740ecffd3249  mov esi, 0x00
0000740ecffd324e  mov rax, 0x5E8249CF1530
0000740ecffd3258  call rax
0000740ecffd325a  movaps xmm11, [rsp]
0000740ecffd325f  add rsp, 0x30
0000740ecffd3263  vmovaps xmm0, [rsp]
0000740ecffd3268  vmovaps xmm1, [rsp+0x10]
0000740ecffd326e  vmovaps xmm2, [rsp+0x20]
0000740ecffd3274  vmovaps xmm3, [rsp+0x30]
0000740ecffd327a  vmovaps xmm4, [rsp+0x40]
0000740ecffd3280  vmovaps xmm5, [rsp+0x50]
0000740ecffd3286  vmovaps xmm6, [rsp+0x60]
0000740ecffd328c  vmovaps xmm7, [rsp+0x70]
0000740ecffd3292  vmovaps xmm8, [rsp+0x80]
0000740ecffd329b  vmovaps xmm9, [rsp+0x90]
0000740ecffd32a4  vmovaps xmm10, [rsp+0xA0]
0000740ecffd32ad  vmovaps xmm12, [rsp+0xB0]
0000740ecffd32b6  vmovaps xmm13, [rsp+0xC0]
0000740ecffd32bf  vmovaps xmm14, [rsp+0xD0]
0000740ecffd32c8  vmovaps xmm15, [rsp+0xE0]
0000740ecffd32d1  add rsp, 0xF0
0000740ecffd32d8  pop r11
0000740ecffd32da  pop r10
0000740ecffd32dc  pop r9
0000740ecffd32de  pop r8
0000740ecffd32e0  pop rsi
0000740ecffd32e1  pop rdi
0000740ecffd32e2  pop rdx
0000740ecffd32e3  pop rcx
0000740ecffd32e4  pop rax
0000740ecffd32e5  add rsp, 0x08
0000740ecffd32e9  jmp 0x0000740ECFFCFEB8
0000740ecffd32ee  sub rsp, 0x08
0000740ecffd32f2  push rax
0000740ecffd32f3  push rcx
0000740ecffd32f4  push rdx
0000740ecffd32f5  push rdi
0000740ecffd32f6  push rsi
0000740ecffd32f7  push r8
0000740ecffd32f9  push r9
0000740ecffd32fb  push r10
0000740ecffd32fd  push r11
0000740ecffd32ff  sub rsp, 0xF0
0000740ecffd3306  vmovaps [rsp], xmm0
0000740ecffd330b  vmovaps [rsp+0x10], xmm2
0000740ecffd3311  vmovaps [rsp+0x20], xmm3
0000740ecffd3317  vmovaps [rsp+0x30], xmm4
0000740ecffd331d  vmovaps [rsp+0x40], xmm5
0000740ecffd3323  vmovaps [rsp+0x50], xmm6
0000740ecffd3329  vmovaps [rsp+0x60], xmm7
0000740ecffd332f  vmovaps [rsp+0x70], xmm8
0000740ecffd3335  vmovaps [rsp+0x80], xmm9
0000740ecffd333e  vmovaps [rsp+0x90], xmm10
0000740ecffd3347  vmovaps [rsp+0xA0], xmm11
0000740ecffd3350  vmovaps [rsp+0xB0], xmm12
0000740ecffd3359  vmovaps [rsp+0xC0], xmm13
0000740ecffd3362  vmovaps [rsp+0xD0], xmm14
0000740ecffd336b  vmovaps [rsp+0xE0], xmm15
0000740ecffd3374  sub rsp, 0x30
0000740ecffd3378  movaps [rsp], xmm1
0000740ecffd337c  movaps [rsp+0x10], xmm14
0000740ecffd3382  movaps [rsp+0x20], xmm6
0000740ecffd3387  lea rdi, [rsp]
0000740ecffd338b  mov esi, 0x00
0000740ecffd3390  mov rax, 0x5E8249CF1530
0000740ecffd339a  call rax
0000740ecffd339c  movaps xmm1, [rsp]
0000740ecffd33a0  add rsp, 0x30
0000740ecffd33a4  vmovaps xmm0, [rsp]
0000740ecffd33a9  vmovaps xmm2, [rsp+0x10]
0000740ecffd33af  vmovaps xmm3, [rsp+0x20]
0000740ecffd33b5  vmovaps xmm4, [rsp+0x30]
0000740ecffd33bb  vmovaps xmm5, [rsp+0x40]
0000740ecffd33c1  vmovaps xmm6, [rsp+0x50]
0000740ecffd33c7  vmovaps xmm7, [rsp+0x60]
0000740ecffd33cd  vmovaps xmm8, [rsp+0x70]
0000740ecffd33d3  vmovaps xmm9, [rsp+0x80]
0000740ecffd33dc  vmovaps xmm10, [rsp+0x90]
0000740ecffd33e5  vmovaps xmm11, [rsp+0xA0]
0000740ecffd33ee  vmovaps xmm12, [rsp+0xB0]
0000740ecffd33f7  vmovaps xmm13, [rsp+0xC0]
0000740ecffd3400  vmovaps xmm14, [rsp+0xD0]
0000740ecffd3409  vmovaps xmm15, [rsp+0xE0]
0000740ecffd3412  add rsp, 0xF0
0000740ecffd3419  pop r11
0000740ecffd341b  pop r10
0000740ecffd341d  pop r9
0000740ecffd341f  pop r8
0000740ecffd3421  pop rsi
0000740ecffd3422  pop rdi
0000740ecffd3423  pop rdx
0000740ecffd3424  pop rcx
0000740ecffd3425  pop rax
0000740ecffd3426  add rsp, 0x08
0000740ecffd342a  jmp 0x0000740ECFFCFED1
0000740ecffd342f  sub rsp, 0x08
0000740ecffd3433  push rax
0000740ecffd3434  push rcx
0000740ecffd3435  push rdx
0000740ecffd3436  push rdi
0000740ecffd3437  push rsi
0000740ecffd3438  push r8
0000740ecffd343a  push r9
0000740ecffd343c  push r10
0000740ecffd343e  push r11
0000740ecffd3440  sub rsp, 0xF0
0000740ecffd3447  vmovaps [rsp], xmm0
0000740ecffd344c  vmovaps [rsp+0x10], xmm1
0000740ecffd3452  vmovaps [rsp+0x20], xmm2
0000740ecffd3458  vmovaps [rsp+0x30], xmm3
0000740ecffd345e  vmovaps [rsp+0x40], xmm4
0000740ecffd3464  vmovaps [rsp+0x50], xmm5
0000740ecffd346a  vmovaps [rsp+0x60], xmm6
0000740ecffd3470  vmovaps [rsp+0x70], xmm7
0000740ecffd3476  vmovaps [rsp+0x80], xmm8
0000740ecffd347f  vmovaps [rsp+0x90], xmm9
0000740ecffd3488  vmovaps [rsp+0xA0], xmm10
0000740ecffd3491  vmovaps [rsp+0xB0], xmm11
0000740ecffd349a  vmovaps [rsp+0xC0], xmm12
0000740ecffd34a3  vmovaps [rsp+0xD0], xmm13
0000740ecffd34ac  vmovaps [rsp+0xE0], xmm15
0000740ecffd34b5  sub rsp, 0x30
0000740ecffd34b9  movaps [rsp], xmm14
0000740ecffd34be  movaps [rsp+0x10], xmm12
0000740ecffd34c4  movaps [rsp+0x20], xmm5
0000740ecffd34c9  lea rdi, [rsp]
0000740ecffd34cd  mov esi, 0x00
0000740ecffd34d2  mov rax, 0x5E8249CF1530
0000740ecffd34dc  call rax
0000740ecffd34de  movaps xmm14, [rsp]
0000740ecffd34e3  add rsp, 0x30
0000740ecffd34e7  vmovaps xmm0, [rsp]
0000740ecffd34ec  vmovaps xmm1, [rsp+0x10]
0000740ecffd34f2  vmovaps xmm2, [rsp+0x20]
0000740ecffd34f8  vmovaps xmm3, [rsp+0x30]
0000740ecffd34fe  vmovaps xmm4, [rsp+0x40]
0000740ecffd3504  vmovaps xmm5, [rsp+0x50]
0000740ecffd350a  vmovaps xmm6, [rsp+0x60]
0000740ecffd3510  vmovaps xmm7, [rsp+0x70]
0000740ecffd3516  vmovaps xmm8, [rsp+0x80]
0000740ecffd351f  vmovaps xmm9, [rsp+0x90]
0000740ecffd3528  vmovaps xmm10, [rsp+0xA0]
0000740ecffd3531  vmovaps xmm11, [rsp+0xB0]
0000740ecffd353a  vmovaps xmm12, [rsp+0xC0]
0000740ecffd3543  vmovaps xmm13, [rsp+0xD0]
0000740ecffd354c  vmovaps xmm15, [rsp+0xE0]
0000740ecffd3555  add rsp, 0xF0
0000740ecffd355c  pop r11
0000740ecffd355e  pop r10
0000740ecffd3560  pop r9
0000740ecffd3562  pop r8
0000740ecffd3564  pop rsi
0000740ecffd3565  pop rdi
0000740ecffd3566  pop rdx
0000740ecffd3567  pop rcx
0000740ecffd3568  pop rax
0000740ecffd3569  add rsp, 0x08
0000740ecffd356d  jmp 0x0000740ECFFCFEF1
0000740ecffd3572  sub rsp, 0x08
0000740ecffd3576  push rax
0000740ecffd3577  push rcx
0000740ecffd3578  push rdx
0000740ecffd3579  push rdi
0000740ecffd357a  push rsi
0000740ecffd357b  push r8
0000740ecffd357d  push r9
0000740ecffd357f  push r10
0000740ecffd3581  push r11
0000740ecffd3583  sub rsp, 0xF0
0000740ecffd358a  vmovaps [rsp], xmm0
0000740ecffd358f  vmovaps [rsp+0x10], xmm1
0000740ecffd3595  vmovaps [rsp+0x20], xmm2
0000740ecffd359b  vmovaps [rsp+0x30], xmm3
0000740ecffd35a1  vmovaps [rsp+0x40], xmm4
0000740ecffd35a7  vmovaps [rsp+0x50], xmm5
0000740ecffd35ad  vmovaps [rsp+0x60], xmm7
0000740ecffd35b3  vmovaps [rsp+0x70], xmm8
0000740ecffd35b9  vmovaps [rsp+0x80], xmm9
0000740ecffd35c2  vmovaps [rsp+0x90], xmm10
0000740ecffd35cb  vmovaps [rsp+0xA0], xmm11
0000740ecffd35d4  vmovaps [rsp+0xB0], xmm12
0000740ecffd35dd  vmovaps [rsp+0xC0], xmm13
0000740ecffd35e6  vmovaps [rsp+0xD0], xmm14
0000740ecffd35ef  vmovaps [rsp+0xE0], xmm15
0000740ecffd35f8  sub rsp, 0x30
0000740ecffd35fc  movaps [rsp], xmm6
0000740ecffd3600  movaps [rsp+0x10], xmm9
0000740ecffd3606  movaps [rsp+0x20], xmm12
0000740ecffd360c  lea rdi, [rsp]
0000740ecffd3610  mov esi, 0x00
0000740ecffd3615  mov rax, 0x5E8249CF1530
0000740ecffd361f  call rax
0000740ecffd3621  movaps xmm6, [rsp]
0000740ecffd3625  add rsp, 0x30
0000740ecffd3629  vmovaps xmm0, [rsp]
0000740ecffd362e  vmovaps xmm1, [rsp+0x10]
0000740ecffd3634  vmovaps xmm2, [rsp+0x20]
0000740ecffd363a  vmovaps xmm3, [rsp+0x30]
0000740ecffd3640  vmovaps xmm4, [rsp+0x40]
0000740ecffd3646  vmovaps xmm5, [rsp+0x50]
0000740ecffd364c  vmovaps xmm7, [rsp+0x60]
0000740ecffd3652  vmovaps xmm8, [rsp+0x70]
0000740ecffd3658  vmovaps xmm9, [rsp+0x80]
0000740ecffd3661  vmovaps xmm10, [rsp+0x90]
0000740ecffd366a  vmovaps xmm11, [rsp+0xA0]
0000740ecffd3673  vmovaps xmm12, [rsp+0xB0]
0000740ecffd367c  vmovaps xmm13, [rsp+0xC0]
0000740ecffd3685  vmovaps xmm14, [rsp+0xD0]
0000740ecffd368e  vmovaps xmm15, [rsp+0xE0]
0000740ecffd3697  add rsp, 0xF0
0000740ecffd369e  pop r11
0000740ecffd36a0  pop r10
0000740ecffd36a2  pop r9
0000740ecffd36a4  pop r8
0000740ecffd36a6  pop rsi
0000740ecffd36a7  pop rdi
0000740ecffd36a8  pop rdx
0000740ecffd36a9  pop rcx
0000740ecffd36aa  pop rax
0000740ecffd36ab  add rsp, 0x08
0000740ecffd36af  jmp 0x0000740ECFFCFF19
0000740ecffd36b4  sub rsp, 0x08
0000740ecffd36b8  push rax
0000740ecffd36b9  push rcx
0000740ecffd36ba  push rdx
0000740ecffd36bb  push rdi
0000740ecffd36bc  push rsi
0000740ecffd36bd  push r8
0000740ecffd36bf  push r9
0000740ecffd36c1  push r10
0000740ecffd36c3  push r11
0000740ecffd36c5  sub rsp, 0xF0
0000740ecffd36cc  vmovaps [rsp], xmm0
0000740ecffd36d1  vmovaps [rsp+0x10], xmm1
0000740ecffd36d7  vmovaps [rsp+0x20], xmm2
0000740ecffd36dd  vmovaps [rsp+0x30], xmm3
0000740ecffd36e3  vmovaps [rsp+0x40], xmm4
0000740ecffd36e9  vmovaps [rsp+0x50], xmm5
0000740ecffd36ef  vmovaps [rsp+0x60], xmm6
0000740ecffd36f5  vmovaps [rsp+0x70], xmm7
0000740ecffd36fb  vmovaps [rsp+0x80], xmm8
0000740ecffd3704  vmovaps [rsp+0x90], xmm9
0000740ecffd370d  vmovaps [rsp+0xA0], xmm10
0000740ecffd3716  vmovaps [rsp+0xB0], xmm11
0000740ecffd371f  vmovaps [rsp+0xC0], xmm13
0000740ecffd3728  vmovaps [rsp+0xD0], xmm14
0000740ecffd3731  vmovaps [rsp+0xE0], xmm15
0000740ecffd373a  sub rsp, 0x30
0000740ecffd373e  movaps [rsp], xmm12
0000740ecffd3743  movaps [rsp+0x10], xmm15
0000740ecffd3749  movaps [rsp+0x20], xmm13
0000740ecffd374f  lea rdi, [rsp]
0000740ecffd3753  mov esi, 0x00
0000740ecffd3758  mov rax, 0x5E8249CF1530
0000740ecffd3762  call rax
0000740ecffd3764  movaps xmm12, [rsp]
0000740ecffd3769  add rsp, 0x30
0000740ecffd376d  vmovaps xmm0, [rsp]
0000740ecffd3772  vmovaps xmm1, [rsp+0x10]
0000740ecffd3778  vmovaps xmm2, [rsp+0x20]
0000740ecffd377e  vmovaps xmm3, [rsp+0x30]
0000740ecffd3784  vmovaps xmm4, [rsp+0x40]
0000740ecffd378a  vmovaps xmm5, [rsp+0x50]
0000740ecffd3790  vmovaps xmm6, [rsp+0x60]
0000740ecffd3796  vmovaps xmm7, [rsp+0x70]
0000740ecffd379c  vmovaps xmm8, [rsp+0x80]
0000740ecffd37a5  vmovaps xmm9, [rsp+0x90]
0000740ecffd37ae  vmovaps xmm10, [rsp+0xA0]
0000740ecffd37b7  vmovaps xmm11, [rsp+0xB0]
0000740ecffd37c0  vmovaps xmm13, [rsp+0xC0]
0000740ecffd37c9  vmovaps xmm14, [rsp+0xD0]
0000740ecffd37d2  vmovaps xmm15, [rsp+0xE0]
0000740ecffd37db  add rsp, 0xF0
0000740ecffd37e2  pop r11
0000740ecffd37e4  pop r10
0000740ecffd37e6  pop r9
0000740ecffd37e8  pop r8
0000740ecffd37ea  pop rsi
0000740ecffd37eb  pop rdi
0000740ecffd37ec  pop rdx
0000740ecffd37ed  pop rcx
0000740ecffd37ee  pop rax
0000740ecffd37ef  add rsp, 0x08
0000740ecffd37f3  jmp 0x0000740ECFFCFF34
0000740ecffd37f8  sub rsp, 0x08
0000740ecffd37fc  push rax
0000740ecffd37fd  push rcx
0000740ecffd37fe  push rdx
0000740ecffd37ff  push rdi
0000740ecffd3800  push rsi
0000740ecffd3801  push r8
0000740ecffd3803  push r9
0000740ecffd3805  push r10
0000740ecffd3807  push r11
0000740ecffd3809  sub rsp, 0xF0
0000740ecffd3810  vmovaps [rsp], xmm0
0000740ecffd3815  vmovaps [rsp+0x10], xmm1
0000740ecffd381b  vmovaps [rsp+0x20], xmm2
0000740ecffd3821  vmovaps [rsp+0x30], xmm3
0000740ecffd3827  vmovaps [rsp+0x40], xmm4
0000740ecffd382d  vmovaps [rsp+0x50], xmm5
0000740ecffd3833  vmovaps [rsp+0x60], xmm6
0000740ecffd3839  vmovaps [rsp+0x70], xmm7
0000740ecffd383f  vmovaps [rsp+0x80], xmm8
0000740ecffd3848  vmovaps [rsp+0x90], xmm9
0000740ecffd3851  vmovaps [rsp+0xA0], xmm10
0000740ecffd385a  vmovaps [rsp+0xB0], xmm11
0000740ecffd3863  vmovaps [rsp+0xC0], xmm12
0000740ecffd386c  vmovaps [rsp+0xD0], xmm13
0000740ecffd3875  vmovaps [rsp+0xE0], xmm14
0000740ecffd387e  sub rsp, 0x30
0000740ecffd3882  movaps [rsp], xmm15
0000740ecffd3887  movaps [rsp+0x10], xmm13
0000740ecffd388d  movaps [rsp+0x20], xmm10
0000740ecffd3893  lea rdi, [rsp]
0000740ecffd3897  mov esi, 0x00
0000740ecffd389c  mov rax, 0x5E8249CF1530
0000740ecffd38a6  call rax
0000740ecffd38a8  movaps xmm15, [rsp]
0000740ecffd38ad  add rsp, 0x30
0000740ecffd38b1  vmovaps xmm0, [rsp]
0000740ecffd38b6  vmovaps xmm1, [rsp+0x10]
0000740ecffd38bc  vmovaps xmm2, [rsp+0x20]
0000740ecffd38c2  vmovaps xmm3, [rsp+0x30]
0000740ecffd38c8  vmovaps xmm4, [rsp+0x40]
0000740ecffd38ce  vmovaps xmm5, [rsp+0x50]
0000740ecffd38d4  vmovaps xmm6, [rsp+0x60]
0000740ecffd38da  vmovaps xmm7, [rsp+0x70]
0000740ecffd38e0  vmovaps xmm8, [rsp+0x80]
0000740ecffd38e9  vmovaps xmm9, [rsp+0x90]
0000740ecffd38f2  vmovaps xmm10, [rsp+0xA0]
0000740ecffd38fb  vmovaps xmm11, [rsp+0xB0]
0000740ecffd3904  vmovaps xmm12, [rsp+0xC0]
0000740ecffd390d  vmovaps xmm13, [rsp+0xD0]
0000740ecffd3916  vmovaps xmm14, [rsp+0xE0]
0000740ecffd391f  add rsp, 0xF0
0000740ecffd3926  pop r11
0000740ecffd3928  pop r10
0000740ecffd392a  pop r9
0000740ecffd392c  pop r8
0000740ecffd392e  pop rsi
0000740ecffd392f  pop rdi
0000740ecffd3930  pop rdx
0000740ecffd3931  pop rcx
0000740ecffd3932  pop rax
0000740ecffd3933  add rsp, 0x08
0000740ecffd3937  jmp 0x0000740ECFFCFF55
0000740ecffd393c  call 0x0000740ECFE0C260
0000740ecffd3941  jmp 0x0000740ECFFCFFB0
0000740ecffd3946  sub rsp, 0x08
0000740ecffd394a  push rax
0000740ecffd394b  push rcx
0000740ecffd394c  push rdx
0000740ecffd394d  push rdi
0000740ecffd394e  push rsi
0000740ecffd394f  push r8
0000740ecffd3951  push r9
0000740ecffd3953  push r10
0000740ecffd3955  push r11
0000740ecffd3957  sub rsp, 0xF0
0000740ecffd395e  vmovaps [rsp], xmm0
0000740ecffd3963  vmovaps [rsp+0x10], xmm1
0000740ecffd3969  vmovaps [rsp+0x20], xmm2
0000740ecffd396f  vmovaps [rsp+0x30], xmm3
0000740ecffd3975  vmovaps [rsp+0x40], xmm4
0000740ecffd397b  vmovaps [rsp+0x50], xmm5
0000740ecffd3981  vmovaps [rsp+0x60], xmm6
0000740ecffd3987  vmovaps [rsp+0x70], xmm7
0000740ecffd398d  vmovaps [rsp+0x80], xmm8
0000740ecffd3996  vmovaps [rsp+0x90], xmm10
0000740ecffd399f  vmovaps [rsp+0xA0], xmm11
0000740ecffd39a8  vmovaps [rsp+0xB0], xmm12
0000740ecffd39b1  vmovaps [rsp+0xC0], xmm13
0000740ecffd39ba  vmovaps [rsp+0xD0], xmm14
0000740ecffd39c3  vmovaps [rsp+0xE0], xmm15
0000740ecffd39cc  sub rsp, 0x30
0000740ecffd39d0  movaps [rsp], xmm9
0000740ecffd39d5  movaps [rsp+0x10], xmm8
0000740ecffd39db  movaps [rsp+0x20], xmm10
0000740ecffd39e1  lea rdi, [rsp]
0000740ecffd39e5  mov esi, 0x00
0000740ecffd39ea  mov rax, 0x5E8249CF1530
0000740ecffd39f4  call rax
0000740ecffd39f6  movaps xmm9, [rsp]
0000740ecffd39fb  add rsp, 0x30
0000740ecffd39ff  vmovaps xmm0, [rsp]
0000740ecffd3a04  vmovaps xmm1, [rsp+0x10]
0000740ecffd3a0a  vmovaps xmm2, [rsp+0x20]
0000740ecffd3a10  vmovaps xmm3, [rsp+0x30]
0000740ecffd3a16  vmovaps xmm4, [rsp+0x40]
0000740ecffd3a1c  vmovaps xmm5, [rsp+0x50]
0000740ecffd3a22  vmovaps xmm6, [rsp+0x60]
0000740ecffd3a28  vmovaps xmm7, [rsp+0x70]
0000740ecffd3a2e  vmovaps xmm8, [rsp+0x80]
0000740ecffd3a37  vmovaps xmm10, [rsp+0x90]
0000740ecffd3a40  vmovaps xmm11, [rsp+0xA0]
0000740ecffd3a49  vmovaps xmm12, [rsp+0xB0]
0000740ecffd3a52  vmovaps xmm13, [rsp+0xC0]
0000740ecffd3a5b  vmovaps xmm14, [rsp+0xD0]
0000740ecffd3a64  vmovaps xmm15, [rsp+0xE0]
0000740ecffd3a6d  add rsp, 0xF0
0000740ecffd3a74  pop r11
0000740ecffd3a76  pop r10
0000740ecffd3a78  pop r9
0000740ecffd3a7a  pop r8
0000740ecffd3a7c  pop rsi
0000740ecffd3a7d  pop rdi
0000740ecffd3a7e  pop rdx
0000740ecffd3a7f  pop rcx
0000740ecffd3a80  pop rax
0000740ecffd3a81  add rsp, 0x08
0000740ecffd3a85  jmp 0x0000740ECFFCFFE1
0000740ecffd3a8a  sub rsp, 0x08
0000740ecffd3a8e  push rax
0000740ecffd3a8f  push rcx
0000740ecffd3a90  push rdx
0000740ecffd3a91  push rdi
0000740ecffd3a92  push rsi
0000740ecffd3a93  push r8
0000740ecffd3a95  push r9
0000740ecffd3a97  push r10
0000740ecffd3a99  push r11
0000740ecffd3a9b  sub rsp, 0xF0
0000740ecffd3aa2  vmovaps [rsp], xmm0
0000740ecffd3aa7  vmovaps [rsp+0x10], xmm1
0000740ecffd3aad  vmovaps [rsp+0x20], xmm2
0000740ecffd3ab3  vmovaps [rsp+0x30], xmm3
0000740ecffd3ab9  vmovaps [rsp+0x40], xmm4
0000740ecffd3abf  vmovaps [rsp+0x50], xmm5
0000740ecffd3ac5  vmovaps [rsp+0x60], xmm6
0000740ecffd3acb  vmovaps [rsp+0x70], xmm7
0000740ecffd3ad1  vmovaps [rsp+0x80], xmm8
0000740ecffd3ada  vmovaps [rsp+0x90], xmm9
0000740ecffd3ae3  vmovaps [rsp+0xA0], xmm11
0000740ecffd3aec  vmovaps [rsp+0xB0], xmm12
0000740ecffd3af5  vmovaps [rsp+0xC0], xmm13
0000740ecffd3afe  vmovaps [rsp+0xD0], xmm14
0000740ecffd3b07  vmovaps [rsp+0xE0], xmm15
0000740ecffd3b10  sub rsp, 0x30
0000740ecffd3b14  movaps [rsp], xmm10
0000740ecffd3b19  movaps [rsp+0x10], xmm1
0000740ecffd3b1e  movaps [rsp+0x20], xmm11
0000740ecffd3b24  lea rdi, [rsp]
0000740ecffd3b28  mov esi, 0x00
0000740ecffd3b2d  mov rax, 0x5E8249CF1530
0000740ecffd3b37  call rax
0000740ecffd3b39  movaps xmm10, [rsp]
0000740ecffd3b3e  add rsp, 0x30
0000740ecffd3b42  vmovaps xmm0, [rsp]
0000740ecffd3b47  vmovaps xmm1, [rsp+0x10]
0000740ecffd3b4d  vmovaps xmm2, [rsp+0x20]
0000740ecffd3b53  vmovaps xmm3, [rsp+0x30]
0000740ecffd3b59  vmovaps xmm4, [rsp+0x40]
0000740ecffd3b5f  vmovaps xmm5, [rsp+0x50]
0000740ecffd3b65  vmovaps xmm6, [rsp+0x60]
0000740ecffd3b6b  vmovaps xmm7, [rsp+0x70]
0000740ecffd3b71  vmovaps xmm8, [rsp+0x80]
0000740ecffd3b7a  vmovaps xmm9, [rsp+0x90]
0000740ecffd3b83  vmovaps xmm11, [rsp+0xA0]
0000740ecffd3b8c  vmovaps xmm12, [rsp+0xB0]
0000740ecffd3b95  vmovaps xmm13, [rsp+0xC0]
0000740ecffd3b9e  vmovaps xmm14, [rsp+0xD0]
0000740ecffd3ba7  vmovaps xmm15, [rsp+0xE0]
0000740ecffd3bb0  add rsp, 0xF0
0000740ecffd3bb7  pop r11
0000740ecffd3bb9  pop r10
0000740ecffd3bbb  pop r9
0000740ecffd3bbd  pop r8
0000740ecffd3bbf  pop rsi
0000740ecffd3bc0  pop rdi
0000740ecffd3bc1  pop rdx
0000740ecffd3bc2  pop rcx
0000740ecffd3bc3  pop rax
0000740ecffd3bc4  add rsp, 0x08
0000740ecffd3bc8  jmp 0x0000740ECFFCFFFC
0000740ecffd3bcd  sub rsp, 0x08
0000740ecffd3bd1  push rax
0000740ecffd3bd2  push rcx
0000740ecffd3bd3  push rdx
0000740ecffd3bd4  push rdi
0000740ecffd3bd5  push rsi
0000740ecffd3bd6  push r8
0000740ecffd3bd8  push r9
0000740ecffd3bda  push r10
0000740ecffd3bdc  push r11
0000740ecffd3bde  sub rsp, 0xF0
0000740ecffd3be5  vmovaps [rsp], xmm0
0000740ecffd3bea  vmovaps [rsp+0x10], xmm2
0000740ecffd3bf0  vmovaps [rsp+0x20], xmm3
0000740ecffd3bf6  vmovaps [rsp+0x30], xmm4
0000740ecffd3bfc  vmovaps [rsp+0x40], xmm5
0000740ecffd3c02  vmovaps [rsp+0x50], xmm6
0000740ecffd3c08  vmovaps [rsp+0x60], xmm7
0000740ecffd3c0e  vmovaps [rsp+0x70], xmm8
0000740ecffd3c14  vmovaps [rsp+0x80], xmm9
0000740ecffd3c1d  vmovaps [rsp+0x90], xmm10
0000740ecffd3c26  vmovaps [rsp+0xA0], xmm11
0000740ecffd3c2f  vmovaps [rsp+0xB0], xmm12
0000740ecffd3c38  vmovaps [rsp+0xC0], xmm13
0000740ecffd3c41  vmovaps [rsp+0xD0], xmm14
0000740ecffd3c4a  vmovaps [rsp+0xE0], xmm15
0000740ecffd3c53  sub rsp, 0x30
0000740ecffd3c57  movaps [rsp], xmm1
0000740ecffd3c5b  movaps [rsp+0x10], xmm14
0000740ecffd3c61  movaps [rsp+0x20], xmm6
0000740ecffd3c66  lea rdi, [rsp]
0000740ecffd3c6a  mov esi, 0x00
0000740ecffd3c6f  mov rax, 0x5E8249CF1530
0000740ecffd3c79  call rax
0000740ecffd3c7b  movaps xmm1, [rsp]
0000740ecffd3c7f  add rsp, 0x30
0000740ecffd3c83  vmovaps xmm0, [rsp]
0000740ecffd3c88  vmovaps xmm2, [rsp+0x10]
0000740ecffd3c8e  vmovaps xmm3, [rsp+0x20]
0000740ecffd3c94  vmovaps xmm4, [rsp+0x30]
0000740ecffd3c9a  vmovaps xmm5, [rsp+0x40]
0000740ecffd3ca0  vmovaps xmm6, [rsp+0x50]
0000740ecffd3ca6  vmovaps xmm7, [rsp+0x60]
0000740ecffd3cac  vmovaps xmm8, [rsp+0x70]
0000740ecffd3cb2  vmovaps xmm9, [rsp+0x80]
0000740ecffd3cbb  vmovaps xmm10, [rsp+0x90]
0000740ecffd3cc4  vmovaps xmm11, [rsp+0xA0]
0000740ecffd3ccd  vmovaps xmm12, [rsp+0xB0]
0000740ecffd3cd6  vmovaps xmm13, [rsp+0xC0]
0000740ecffd3cdf  vmovaps xmm14, [rsp+0xD0]
0000740ecffd3ce8  vmovaps xmm15, [rsp+0xE0]
0000740ecffd3cf1  add rsp, 0xF0
0000740ecffd3cf8  pop r11
0000740ecffd3cfa  pop r10
0000740ecffd3cfc  pop r9
0000740ecffd3cfe  pop r8
0000740ecffd3d00  pop rsi
0000740ecffd3d01  pop rdi
0000740ecffd3d02  pop rdx
0000740ecffd3d03  pop rcx
0000740ecffd3d04  pop rax
0000740ecffd3d05  add rsp, 0x08
0000740ecffd3d09  jmp 0x0000740ECFFD0015
0000740ecffd3d0e  sub rsp, 0x08
0000740ecffd3d12  push rax
0000740ecffd3d13  push rcx
0000740ecffd3d14  push rdx
0000740ecffd3d15  push rdi
0000740ecffd3d16  push rsi
0000740ecffd3d17  push r8
0000740ecffd3d19  push r9
0000740ecffd3d1b  push r10
0000740ecffd3d1d  push r11
0000740ecffd3d1f  sub rsp, 0xF0
0000740ecffd3d26  vmovaps [rsp], xmm0
0000740ecffd3d2b  vmovaps [rsp+0x10], xmm1
0000740ecffd3d31  vmovaps [rsp+0x20], xmm2
0000740ecffd3d37  vmovaps [rsp+0x30], xmm3
0000740ecffd3d3d  vmovaps [rsp+0x40], xmm4
0000740ecffd3d43  vmovaps [rsp+0x50], xmm5
0000740ecffd3d49  vmovaps [rsp+0x60], xmm6
0000740ecffd3d4f  vmovaps [rsp+0x70], xmm7
0000740ecffd3d55  vmovaps [rsp+0x80], xmm8
0000740ecffd3d5e  vmovaps [rsp+0x90], xmm9
0000740ecffd3d67  vmovaps [rsp+0xA0], xmm10
0000740ecffd3d70  vmovaps [rsp+0xB0], xmm12
0000740ecffd3d79  vmovaps [rsp+0xC0], xmm13
0000740ecffd3d82  vmovaps [rsp+0xD0], xmm14
0000740ecffd3d8b  vmovaps [rsp+0xE0], xmm15
0000740ecffd3d94  sub rsp, 0x30
0000740ecffd3d98  movaps [rsp], xmm11
0000740ecffd3d9d  movaps [rsp+0x10], xmm13
0000740ecffd3da3  movaps [rsp+0x20], xmm14
0000740ecffd3da9  lea rdi, [rsp]
0000740ecffd3dad  mov esi, 0x00
0000740ecffd3db2  mov rax, 0x5E8249CF1530
0000740ecffd3dbc  call rax
0000740ecffd3dbe  movaps xmm11, [rsp]
0000740ecffd3dc3  add rsp, 0x30
0000740ecffd3dc7  vmovaps xmm0, [rsp]
0000740ecffd3dcc  vmovaps xmm1, [rsp+0x10]
0000740ecffd3dd2  vmovaps xmm2, [rsp+0x20]
0000740ecffd3dd8  vmovaps xmm3, [rsp+0x30]
0000740ecffd3dde  vmovaps xmm4, [rsp+0x40]
0000740ecffd3de4  vmovaps xmm5, [rsp+0x50]
0000740ecffd3dea  vmovaps xmm6, [rsp+0x60]
0000740ecffd3df0  vmovaps xmm7, [rsp+0x70]
0000740ecffd3df6  vmovaps xmm8, [rsp+0x80]
0000740ecffd3dff  vmovaps xmm9, [rsp+0x90]
0000740ecffd3e08  vmovaps xmm10, [rsp+0xA0]
0000740ecffd3e11  vmovaps xmm12, [rsp+0xB0]
0000740ecffd3e1a  vmovaps xmm13, [rsp+0xC0]
0000740ecffd3e23  vmovaps xmm14, [rsp+0xD0]
0000740ecffd3e2c  vmovaps xmm15, [rsp+0xE0]
0000740ecffd3e35  add rsp, 0xF0
0000740ecffd3e3c  pop r11
0000740ecffd3e3e  pop r10
0000740ecffd3e40  pop r9
0000740ecffd3e42  pop r8
0000740ecffd3e44  pop rsi
0000740ecffd3e45  pop rdi
0000740ecffd3e46  pop rdx
0000740ecffd3e47  pop rcx
0000740ecffd3e48  pop rax
0000740ecffd3e49  add rsp, 0x08
0000740ecffd3e4d  jmp 0x0000740ECFFD003F
0000740ecffd3e52  sub rsp, 0x08
0000740ecffd3e56  push rax
0000740ecffd3e57  push rcx
0000740ecffd3e58  push rdx
0000740ecffd3e59  push rdi
0000740ecffd3e5a  push rsi
0000740ecffd3e5b  push r8
0000740ecffd3e5d  push r9
0000740ecffd3e5f  push r10
0000740ecffd3e61  push r11
0000740ecffd3e63  sub rsp, 0xF0
0000740ecffd3e6a  vmovaps [rsp], xmm0
0000740ecffd3e6f  vmovaps [rsp+0x10], xmm1
0000740ecffd3e75  vmovaps [rsp+0x20], xmm2
0000740ecffd3e7b  vmovaps [rsp+0x30], xmm3
0000740ecffd3e81  vmovaps [rsp+0x40], xmm4
0000740ecffd3e87  vmovaps [rsp+0x50], xmm5
0000740ecffd3e8d  vmovaps [rsp+0x60], xmm6
0000740ecffd3e93  vmovaps [rsp+0x70], xmm7
0000740ecffd3e99  vmovaps [rsp+0x80], xmm8
0000740ecffd3ea2  vmovaps [rsp+0x90], xmm9
0000740ecffd3eab  vmovaps [rsp+0xA0], xmm10
0000740ecffd3eb4  vmovaps [rsp+0xB0], xmm11
0000740ecffd3ebd  vmovaps [rsp+0xC0], xmm12
0000740ecffd3ec6  vmovaps [rsp+0xD0], xmm14
0000740ecffd3ecf  vmovaps [rsp+0xE0], xmm15
0000740ecffd3ed8  sub rsp, 0x30
0000740ecffd3edc  movaps [rsp], xmm13
0000740ecffd3ee1  movaps [rsp+0x10], xmm8
0000740ecffd3ee7  movaps [rsp+0x20], xmm14
0000740ecffd3eed  lea rdi, [rsp]
0000740ecffd3ef1  mov esi, 0x00
0000740ecffd3ef6  mov rax, 0x5E8249CF1530
0000740ecffd3f00  call rax
0000740ecffd3f02  movaps xmm13, [rsp]
0000740ecffd3f07  add rsp, 0x30
0000740ecffd3f0b  vmovaps xmm0, [rsp]
0000740ecffd3f10  vmovaps xmm1, [rsp+0x10]
0000740ecffd3f16  vmovaps xmm2, [rsp+0x20]
0000740ecffd3f1c  vmovaps xmm3, [rsp+0x30]
0000740ecffd3f22  vmovaps xmm4, [rsp+0x40]
0000740ecffd3f28  vmovaps xmm5, [rsp+0x50]
0000740ecffd3f2e  vmovaps xmm6, [rsp+0x60]
0000740ecffd3f34  vmovaps xmm7, [rsp+0x70]
0000740ecffd3f3a  vmovaps xmm8, [rsp+0x80]
0000740ecffd3f43  vmovaps xmm9, [rsp+0x90]
0000740ecffd3f4c  vmovaps xmm10, [rsp+0xA0]
0000740ecffd3f55  vmovaps xmm11, [rsp+0xB0]
0000740ecffd3f5e  vmovaps xmm12, [rsp+0xC0]
0000740ecffd3f67  vmovaps xmm14, [rsp+0xD0]
0000740ecffd3f70  vmovaps xmm15, [rsp+0xE0]
0000740ecffd3f79  add rsp, 0xF0
0000740ecffd3f80  pop r11
0000740ecffd3f82  pop r10
0000740ecffd3f84  pop r9
0000740ecffd3f86  pop r8
0000740ecffd3f88  pop rsi
0000740ecffd3f89  pop rdi
0000740ecffd3f8a  pop rdx
0000740ecffd3f8b  pop rcx
0000740ecffd3f8c  pop rax
0000740ecffd3f8d  add rsp, 0x08
0000740ecffd3f91  jmp 0x0000740ECFFD006E
0000740ecffd3f96  sub rsp, 0x08
0000740ecffd3f9a  push rax
0000740ecffd3f9b  push rcx
0000740ecffd3f9c  push rdx
0000740ecffd3f9d  push rdi
0000740ecffd3f9e  push rsi
0000740ecffd3f9f  push r8
0000740ecffd3fa1  push r9
0000740ecffd3fa3  push r10
0000740ecffd3fa5  push r11
0000740ecffd3fa7  sub rsp, 0xF0
0000740ecffd3fae  vmovaps [rsp], xmm0
0000740ecffd3fb3  vmovaps [rsp+0x10], xmm1
0000740ecffd3fb9  vmovaps [rsp+0x20], xmm2
0000740ecffd3fbf  vmovaps [rsp+0x30], xmm3
0000740ecffd3fc5  vmovaps [rsp+0x40], xmm4
0000740ecffd3fcb  vmovaps [rsp+0x50], xmm5
0000740ecffd3fd1  vmovaps [rsp+0x60], xmm6
0000740ecffd3fd7  vmovaps [rsp+0x70], xmm7
0000740ecffd3fdd  vmovaps [rsp+0x80], xmm9
0000740ecffd3fe6  vmovaps [rsp+0x90], xmm10
0000740ecffd3fef  vmovaps [rsp+0xA0], xmm11
0000740ecffd3ff8  vmovaps [rsp+0xB0], xmm12
0000740ecffd4001  vmovaps [rsp+0xC0], xmm13
0000740ecffd400a  vmovaps [rsp+0xD0], xmm14
0000740ecffd4013  vmovaps [rsp+0xE0], xmm15
0000740ecffd401c  sub rsp, 0x30
0000740ecffd4020  movaps [rsp], xmm8
0000740ecffd4025  movaps [rsp+0x10], xmm7
0000740ecffd402a  movaps [rsp+0x20], xmm14
0000740ecffd4030  lea rdi, [rsp]
0000740ecffd4034  mov esi, 0x00
0000740ecffd4039  mov rax, 0x5E8249CF1530
0000740ecffd4043  call rax
0000740ecffd4045  movaps xmm8, [rsp]
0000740ecffd404a  add rsp, 0x30
0000740ecffd404e  vmovaps xmm0, [rsp]
0000740ecffd4053  vmovaps xmm1, [rsp+0x10]
0000740ecffd4059  vmovaps xmm2, [rsp+0x20]
0000740ecffd405f  vmovaps xmm3, [rsp+0x30]
0000740ecffd4065  vmovaps xmm4, [rsp+0x40]
0000740ecffd406b  vmovaps xmm5, [rsp+0x50]
0000740ecffd4071  vmovaps xmm6, [rsp+0x60]
0000740ecffd4077  vmovaps xmm7, [rsp+0x70]
0000740ecffd407d  vmovaps xmm9, [rsp+0x80]
0000740ecffd4086  vmovaps xmm10, [rsp+0x90]
0000740ecffd408f  vmovaps xmm11, [rsp+0xA0]
0000740ecffd4098  vmovaps xmm12, [rsp+0xB0]
0000740ecffd40a1  vmovaps xmm13, [rsp+0xC0]
0000740ecffd40aa  vmovaps xmm14, [rsp+0xD0]
0000740ecffd40b3  vmovaps xmm15, [rsp+0xE0]
0000740ecffd40bc  add rsp, 0xF0
0000740ecffd40c3  pop r11
0000740ecffd40c5  pop r10
0000740ecffd40c7  pop r9
0000740ecffd40c9  pop r8
0000740ecffd40cb  pop rsi
0000740ecffd40cc  pop rdi
0000740ecffd40cd  pop rdx
0000740ecffd40ce  pop rcx
0000740ecffd40cf  pop rax
0000740ecffd40d0  add rsp, 0x08
0000740ecffd40d4  jmp 0x0000740ECFFD0094
0000740ecffd40d9  sub rsp, 0x08
0000740ecffd40dd  push rax
0000740ecffd40de  push rcx
0000740ecffd40df  push rdx
0000740ecffd40e0  push rdi
0000740ecffd40e1  push rsi
0000740ecffd40e2  push r8
0000740ecffd40e4  push r9
0000740ecffd40e6  push r10
0000740ecffd40e8  push r11
0000740ecffd40ea  sub rsp, 0xF0
0000740ecffd40f1  vmovaps [rsp], xmm0
0000740ecffd40f6  vmovaps [rsp+0x10], xmm1
0000740ecffd40fc  vmovaps [rsp+0x20], xmm2
0000740ecffd4102  vmovaps [rsp+0x30], xmm3
0000740ecffd4108  vmovaps [rsp+0x40], xmm4
0000740ecffd410e  vmovaps [rsp+0x50], xmm5
0000740ecffd4114  vmovaps [rsp+0x60], xmm6
0000740ecffd411a  vmovaps [rsp+0x70], xmm7
0000740ecffd4120  vmovaps [rsp+0x80], xmm8
0000740ecffd4129  vmovaps [rsp+0x90], xmm9
0000740ecffd4132  vmovaps [rsp+0xA0], xmm10
0000740ecffd413b  vmovaps [rsp+0xB0], xmm11
0000740ecffd4144  vmovaps [rsp+0xC0], xmm12
0000740ecffd414d  vmovaps [rsp+0xD0], xmm13
0000740ecffd4156  vmovaps [rsp+0xE0], xmm15
0000740ecffd415f  sub rsp, 0x30
0000740ecffd4163  movaps [rsp], xmm14
0000740ecffd4168  movaps [rsp+0x10], xmm12
0000740ecffd416e  movaps [rsp+0x20], xmm9
0000740ecffd4174  lea rdi, [rsp]
0000740ecffd4178  mov esi, 0x00
0000740ecffd417d  mov rax, 0x5E8249CF1530
0000740ecffd4187  call rax
0000740ecffd4189  movaps xmm14, [rsp]
0000740ecffd418e  add rsp, 0x30
0000740ecffd4192  vmovaps xmm0, [rsp]
0000740ecffd4197  vmovaps xmm1, [rsp+0x10]
0000740ecffd419d  vmovaps xmm2, [rsp+0x20]
0000740ecffd41a3  vmovaps xmm3, [rsp+0x30]
0000740ecffd41a9  vmovaps xmm4, [rsp+0x40]
0000740ecffd41af  vmovaps xmm5, [rsp+0x50]
0000740ecffd41b5  vmovaps xmm6, [rsp+0x60]
0000740ecffd41bb  vmovaps xmm7, [rsp+0x70]
0000740ecffd41c1  vmovaps xmm8, [rsp+0x80]
0000740ecffd41ca  vmovaps xmm9, [rsp+0x90]
0000740ecffd41d3  vmovaps xmm10, [rsp+0xA0]
0000740ecffd41dc  vmovaps xmm11, [rsp+0xB0]
0000740ecffd41e5  vmovaps xmm12, [rsp+0xC0]
0000740ecffd41ee  vmovaps xmm13, [rsp+0xD0]
0000740ecffd41f7  vmovaps xmm15, [rsp+0xE0]
0000740ecffd4200  add rsp, 0xF0
0000740ecffd4207  pop r11
0000740ecffd4209  pop r10
0000740ecffd420b  pop r9
0000740ecffd420d  pop r8
0000740ecffd420f  pop rsi
0000740ecffd4210  pop rdi
0000740ecffd4211  pop rdx
0000740ecffd4212  pop rcx
0000740ecffd4213  pop rax
0000740ecffd4214  add rsp, 0x08
0000740ecffd4218  jmp 0x0000740ECFFD00AE
0000740ecffd421d  sub rsp, 0x08
0000740ecffd4221  push rax
0000740ecffd4222  push rcx
0000740ecffd4223  push rdx
0000740ecffd4224  push rdi
0000740ecffd4225  push rsi
0000740ecffd4226  push r8
0000740ecffd4228  push r9
0000740ecffd422a  push r10
0000740ecffd422c  push r11
0000740ecffd422e  sub rsp, 0xF0
0000740ecffd4235  vmovaps [rsp], xmm0
0000740ecffd423a  vmovaps [rsp+0x10], xmm1
0000740ecffd4240  vmovaps [rsp+0x20], xmm2
0000740ecffd4246  vmovaps [rsp+0x30], xmm3
0000740ecffd424c  vmovaps [rsp+0x40], xmm4
0000740ecffd4252  vmovaps [rsp+0x50], xmm5
0000740ecffd4258  vmovaps [rsp+0x60], xmm6
0000740ecffd425e  vmovaps [rsp+0x70], xmm7
0000740ecffd4264  vmovaps [rsp+0x80], xmm8
0000740ecffd426d  vmovaps [rsp+0x90], xmm10
0000740ecffd4276  vmovaps [rsp+0xA0], xmm11
0000740ecffd427f  vmovaps [rsp+0xB0], xmm12
0000740ecffd4288  vmovaps [rsp+0xC0], xmm13
0000740ecffd4291  vmovaps [rsp+0xD0], xmm14
0000740ecffd429a  vmovaps [rsp+0xE0], xmm15
0000740ecffd42a3  sub rsp, 0x30
0000740ecffd42a7  movaps [rsp], xmm9
0000740ecffd42ac  movaps [rsp+0x10], xmm7
0000740ecffd42b1  movaps [rsp+0x20], xmm12
0000740ecffd42b7  lea rdi, [rsp]
0000740ecffd42bb  mov esi, 0x00
0000740ecffd42c0  mov rax, 0x5E8249CF1530
0000740ecffd42ca  call rax
0000740ecffd42cc  movaps xmm9, [rsp]
0000740ecffd42d1  add rsp, 0x30
0000740ecffd42d5  vmovaps xmm0, [rsp]
0000740ecffd42da  vmovaps xmm1, [rsp+0x10]
0000740ecffd42e0  vmovaps xmm2, [rsp+0x20]
0000740ecffd42e6  vmovaps xmm3, [rsp+0x30]
0000740ecffd42ec  vmovaps xmm4, [rsp+0x40]
0000740ecffd42f2  vmovaps xmm5, [rsp+0x50]
0000740ecffd42f8  vmovaps xmm6, [rsp+0x60]
0000740ecffd42fe  vmovaps xmm7, [rsp+0x70]
0000740ecffd4304  vmovaps xmm8, [rsp+0x80]
0000740ecffd430d  vmovaps xmm10, [rsp+0x90]
0000740ecffd4316  vmovaps xmm11, [rsp+0xA0]
0000740ecffd431f  vmovaps xmm12, [rsp+0xB0]
0000740ecffd4328  vmovaps xmm13, [rsp+0xC0]
0000740ecffd4331  vmovaps xmm14, [rsp+0xD0]
0000740ecffd433a  vmovaps xmm15, [rsp+0xE0]
0000740ecffd4343  add rsp, 0xF0
0000740ecffd434a  pop r11
0000740ecffd434c  pop r10
0000740ecffd434e  pop r9
0000740ecffd4350  pop r8
0000740ecffd4352  pop rsi
0000740ecffd4353  pop rdi
0000740ecffd4354  pop rdx
0000740ecffd4355  pop rcx
0000740ecffd4356  pop rax
0000740ecffd4357  add rsp, 0x08
0000740ecffd435b  jmp 0x0000740ECFFD00DD
0000740ecffd4360  sub rsp, 0x08
0000740ecffd4364  push rax
0000740ecffd4365  push rcx
0000740ecffd4366  push rdx
0000740ecffd4367  push rdi
0000740ecffd4368  push rsi
0000740ecffd4369  push r8
0000740ecffd436b  push r9
0000740ecffd436d  push r10
0000740ecffd436f  push r11
0000740ecffd4371  sub rsp, 0xF0
0000740ecffd4378  vmovaps [rsp], xmm0
0000740ecffd437d  vmovaps [rsp+0x10], xmm1
0000740ecffd4383  vmovaps [rsp+0x20], xmm2
0000740ecffd4389  vmovaps [rsp+0x30], xmm3
0000740ecffd438f  vmovaps [rsp+0x40], xmm4
0000740ecffd4395  vmovaps [rsp+0x50], xmm5
0000740ecffd439b  vmovaps [rsp+0x60], xmm6
0000740ecffd43a1  vmovaps [rsp+0x70], xmm7
0000740ecffd43a7  vmovaps [rsp+0x80], xmm8
0000740ecffd43b0  vmovaps [rsp+0x90], xmm9
0000740ecffd43b9  vmovaps [rsp+0xA0], xmm10
0000740ecffd43c2  vmovaps [rsp+0xB0], xmm11
0000740ecffd43cb  vmovaps [rsp+0xC0], xmm13
0000740ecffd43d4  vmovaps [rsp+0xD0], xmm14
0000740ecffd43dd  vmovaps [rsp+0xE0], xmm15
0000740ecffd43e6  sub rsp, 0x30
0000740ecffd43ea  movaps [rsp], xmm12
0000740ecffd43ef  movaps [rsp+0x10], xmm15
0000740ecffd43f5  movaps [rsp+0x20], xmm11
0000740ecffd43fb  lea rdi, [rsp]
0000740ecffd43ff  mov esi, 0x00
0000740ecffd4404  mov rax, 0x5E8249CF1530
0000740ecffd440e  call rax
0000740ecffd4410  movaps xmm12, [rsp]
0000740ecffd4415  add rsp, 0x30
0000740ecffd4419  vmovaps xmm0, [rsp]
0000740ecffd441e  vmovaps xmm1, [rsp+0x10]
0000740ecffd4424  vmovaps xmm2, [rsp+0x20]
0000740ecffd442a  vmovaps xmm3, [rsp+0x30]
0000740ecffd4430  vmovaps xmm4, [rsp+0x40]
0000740ecffd4436  vmovaps xmm5, [rsp+0x50]
0000740ecffd443c  vmovaps xmm6, [rsp+0x60]
0000740ecffd4442  vmovaps xmm7, [rsp+0x70]
0000740ecffd4448  vmovaps xmm8, [rsp+0x80]
0000740ecffd4451  vmovaps xmm9, [rsp+0x90]
0000740ecffd445a  vmovaps xmm10, [rsp+0xA0]
0000740ecffd4463  vmovaps xmm11, [rsp+0xB0]
0000740ecffd446c  vmovaps xmm13, [rsp+0xC0]
0000740ecffd4475  vmovaps xmm14, [rsp+0xD0]
0000740ecffd447e  vmovaps xmm15, [rsp+0xE0]
0000740ecffd4487  add rsp, 0xF0
0000740ecffd448e  pop r11
0000740ecffd4490  pop r10
0000740ecffd4492  pop r9
0000740ecffd4494  pop r8
0000740ecffd4496  pop rsi
0000740ecffd4497  pop rdi
0000740ecffd4498  pop rdx
0000740ecffd4499  pop rcx
0000740ecffd449a  pop rax
0000740ecffd449b  add rsp, 0x08
0000740ecffd449f  jmp 0x0000740ECFFD00F7
0000740ecffd44a4  sub rsp, 0x08
0000740ecffd44a8  push rax
0000740ecffd44a9  push rcx
0000740ecffd44aa  push rdx
0000740ecffd44ab  push rdi
0000740ecffd44ac  push rsi
0000740ecffd44ad  push r8
0000740ecffd44af  push r9
0000740ecffd44b1  push r10
0000740ecffd44b3  push r11
0000740ecffd44b5  sub rsp, 0xF0
0000740ecffd44bc  vmovaps [rsp], xmm0
0000740ecffd44c1  vmovaps [rsp+0x10], xmm1
0000740ecffd44c7  vmovaps [rsp+0x20], xmm2
0000740ecffd44cd  vmovaps [rsp+0x30], xmm3
0000740ecffd44d3  vmovaps [rsp+0x40], xmm4
0000740ecffd44d9  vmovaps [rsp+0x50], xmm5
0000740ecffd44df  vmovaps [rsp+0x60], xmm6
0000740ecffd44e5  vmovaps [rsp+0x70], xmm7
0000740ecffd44eb  vmovaps [rsp+0x80], xmm8
0000740ecffd44f4  vmovaps [rsp+0x90], xmm9
0000740ecffd44fd  vmovaps [rsp+0xA0], xmm10
0000740ecffd4506  vmovaps [rsp+0xB0], xmm12
0000740ecffd450f  vmovaps [rsp+0xC0], xmm13
0000740ecffd4518  vmovaps [rsp+0xD0], xmm14
0000740ecffd4521  vmovaps [rsp+0xE0], xmm15
0000740ecffd452a  sub rsp, 0x30
0000740ecffd452e  movaps [rsp], xmm11
0000740ecffd4533  movaps [rsp+0x10], xmm7
0000740ecffd4538  movaps [rsp+0x20], xmm15
0000740ecffd453e  lea rdi, [rsp]
0000740ecffd4542  mov esi, 0x00
0000740ecffd4547  mov rax, 0x5E8249CF1530
0000740ecffd4551  call rax
0000740ecffd4553  movaps xmm11, [rsp]
0000740ecffd4558  add rsp, 0x30
0000740ecffd455c  vmovaps xmm0, [rsp]
0000740ecffd4561  vmovaps xmm1, [rsp+0x10]
0000740ecffd4567  vmovaps xmm2, [rsp+0x20]
0000740ecffd456d  vmovaps xmm3, [rsp+0x30]
0000740ecffd4573  vmovaps xmm4, [rsp+0x40]
0000740ecffd4579  vmovaps xmm5, [rsp+0x50]
0000740ecffd457f  vmovaps xmm6, [rsp+0x60]
0000740ecffd4585  vmovaps xmm7, [rsp+0x70]
0000740ecffd458b  vmovaps xmm8, [rsp+0x80]
0000740ecffd4594  vmovaps xmm9, [rsp+0x90]
0000740ecffd459d  vmovaps xmm10, [rsp+0xA0]
0000740ecffd45a6  vmovaps xmm12, [rsp+0xB0]
0000740ecffd45af  vmovaps xmm13, [rsp+0xC0]
0000740ecffd45b8  vmovaps xmm14, [rsp+0xD0]
0000740ecffd45c1  vmovaps xmm15, [rsp+0xE0]
0000740ecffd45ca  add rsp, 0xF0
0000740ecffd45d1  pop r11
0000740ecffd45d3  pop r10
0000740ecffd45d5  pop r9
0000740ecffd45d7  pop r8
0000740ecffd45d9  pop rsi
0000740ecffd45da  pop rdi
0000740ecffd45db  pop rdx
0000740ecffd45dc  pop rcx
0000740ecffd45dd  pop rax
0000740ecffd45de  add rsp, 0x08
0000740ecffd45e2  jmp 0x0000740ECFFD0123
0000740ecffd45e7  sub rsp, 0x08
0000740ecffd45eb  push rax
0000740ecffd45ec  push rcx
0000740ecffd45ed  push rdx
0000740ecffd45ee  push rdi
0000740ecffd45ef  push rsi
0000740ecffd45f0  push r8
0000740ecffd45f2  push r9
0000740ecffd45f4  push r10
0000740ecffd45f6  push r11
0000740ecffd45f8  sub rsp, 0xF0
0000740ecffd45ff  vmovaps [rsp], xmm0
0000740ecffd4604  vmovaps [rsp+0x10], xmm1
0000740ecffd460a  vmovaps [rsp+0x20], xmm2
0000740ecffd4610  vmovaps [rsp+0x30], xmm3
0000740ecffd4616  vmovaps [rsp+0x40], xmm4
0000740ecffd461c  vmovaps [rsp+0x50], xmm5
0000740ecffd4622  vmovaps [rsp+0x60], xmm6
0000740ecffd4628  vmovaps [rsp+0x70], xmm7
0000740ecffd462e  vmovaps [rsp+0x80], xmm8
0000740ecffd4637  vmovaps [rsp+0x90], xmm9
0000740ecffd4640  vmovaps [rsp+0xA0], xmm10
0000740ecffd4649  vmovaps [rsp+0xB0], xmm11
0000740ecffd4652  vmovaps [rsp+0xC0], xmm12
0000740ecffd465b  vmovaps [rsp+0xD0], xmm13
0000740ecffd4664  vmovaps [rsp+0xE0], xmm14
0000740ecffd466d  sub rsp, 0x30
0000740ecffd4671  movaps [rsp], xmm15
0000740ecffd4676  movaps [rsp+0x10], xmm10
0000740ecffd467c  movaps [rsp+0x20], xmm13
0000740ecffd4682  lea rdi, [rsp]
0000740ecffd4686  mov esi, 0x00
0000740ecffd468b  mov rax, 0x5E8249CF1530
0000740ecffd4695  call rax
0000740ecffd4697  movaps xmm15, [rsp]
0000740ecffd469c  add rsp, 0x30
0000740ecffd46a0  vmovaps xmm0, [rsp]
0000740ecffd46a5  vmovaps xmm1, [rsp+0x10]
0000740ecffd46ab  vmovaps xmm2, [rsp+0x20]
0000740ecffd46b1  vmovaps xmm3, [rsp+0x30]
0000740ecffd46b7  vmovaps xmm4, [rsp+0x40]
0000740ecffd46bd  vmovaps xmm5, [rsp+0x50]
0000740ecffd46c3  vmovaps xmm6, [rsp+0x60]
0000740ecffd46c9  vmovaps xmm7, [rsp+0x70]
0000740ecffd46cf  vmovaps xmm8, [rsp+0x80]
0000740ecffd46d8  vmovaps xmm9, [rsp+0x90]
0000740ecffd46e1  vmovaps xmm10, [rsp+0xA0]
0000740ecffd46ea  vmovaps xmm11, [rsp+0xB0]
0000740ecffd46f3  vmovaps xmm12, [rsp+0xC0]
0000740ecffd46fc  vmovaps xmm13, [rsp+0xD0]
0000740ecffd4705  vmovaps xmm14, [rsp+0xE0]
0000740ecffd470e  add rsp, 0xF0
0000740ecffd4715  pop r11
0000740ecffd4717  pop r10
0000740ecffd4719  pop r9
0000740ecffd471b  pop r8
0000740ecffd471d  pop rsi
0000740ecffd471e  pop rdi
0000740ecffd471f  pop rdx
0000740ecffd4720  pop rcx
0000740ecffd4721  pop rax
0000740ecffd4722  add rsp, 0x08
0000740ecffd4726  jmp 0x0000740ECFFD013D
0000740ecffd472b  sub rsp, 0x08
0000740ecffd472f  push rax
0000740ecffd4730  push rcx
0000740ecffd4731  push rdx
0000740ecffd4732  push rdi
0000740ecffd4733  push rsi
0000740ecffd4734  push r8
0000740ecffd4736  push r9
0000740ecffd4738  push r10
0000740ecffd473a  push r11
0000740ecffd473c  sub rsp, 0xF0
0000740ecffd4743  vmovaps [rsp], xmm0
0000740ecffd4748  vmovaps [rsp+0x10], xmm1
0000740ecffd474e  vmovaps [rsp+0x20], xmm2
0000740ecffd4754  vmovaps [rsp+0x30], xmm3
0000740ecffd475a  vmovaps [rsp+0x40], xmm4
0000740ecffd4760  vmovaps [rsp+0x50], xmm5
0000740ecffd4766  vmovaps [rsp+0x60], xmm6
0000740ecffd476c  vmovaps [rsp+0x70], xmm7
0000740ecffd4772  vmovaps [rsp+0x80], xmm8
0000740ecffd477b  vmovaps [rsp+0x90], xmm9
0000740ecffd4784  vmovaps [rsp+0xA0], xmm11
0000740ecffd478d  vmovaps [rsp+0xB0], xmm12
0000740ecffd4796  vmovaps [rsp+0xC0], xmm13
0000740ecffd479f  vmovaps [rsp+0xD0], xmm14
0000740ecffd47a8  vmovaps [rsp+0xE0], xmm15
0000740ecffd47b1  sub rsp, 0x30
0000740ecffd47b5  movaps [rsp], xmm10
0000740ecffd47ba  movaps [rsp+0x10], xmm7
0000740ecffd47bf  movaps [rsp+0x20], xmm13
0000740ecffd47c5  lea rdi, [rsp]
0000740ecffd47c9  mov esi, 0x00
0000740ecffd47ce  mov rax, 0x5E8249CF1530
0000740ecffd47d8  call rax
0000740ecffd47da  movaps xmm10, [rsp]
0000740ecffd47df  add rsp, 0x30
0000740ecffd47e3  vmovaps xmm0, [rsp]
0000740ecffd47e8  vmovaps xmm1, [rsp+0x10]
0000740ecffd47ee  vmovaps xmm2, [rsp+0x20]
0000740ecffd47f4  vmovaps xmm3, [rsp+0x30]
0000740ecffd47fa  vmovaps xmm4, [rsp+0x40]
0000740ecffd4800  vmovaps xmm5, [rsp+0x50]
0000740ecffd4806  vmovaps xmm6, [rsp+0x60]
0000740ecffd480c  vmovaps xmm7, [rsp+0x70]
0000740ecffd4812  vmovaps xmm8, [rsp+0x80]
0000740ecffd481b  vmovaps xmm9, [rsp+0x90]
0000740ecffd4824  vmovaps xmm11, [rsp+0xA0]
0000740ecffd482d  vmovaps xmm12, [rsp+0xB0]
0000740ecffd4836  vmovaps xmm13, [rsp+0xC0]
0000740ecffd483f  vmovaps xmm14, [rsp+0xD0]
0000740ecffd4848  vmovaps xmm15, [rsp+0xE0]
0000740ecffd4851  add rsp, 0xF0
0000740ecffd4858  pop r11
0000740ecffd485a  pop r10
0000740ecffd485c  pop r9
0000740ecffd485e  pop r8
0000740ecffd4860  pop rsi
0000740ecffd4861  pop rdi
0000740ecffd4862  pop rdx
0000740ecffd4863  pop rcx
0000740ecffd4864  pop rax
0000740ecffd4865  add rsp, 0x08
0000740ecffd4869  jmp 0x0000740ECFFD0169
0000740ecffd486e  sub rsp, 0x08
0000740ecffd4872  push rax
0000740ecffd4873  push rcx
0000740ecffd4874  push rdx
0000740ecffd4875  push rdi
0000740ecffd4876  push rsi
0000740ecffd4877  push r8
0000740ecffd4879  push r9
0000740ecffd487b  push r10
0000740ecffd487d  push r11
0000740ecffd487f  sub rsp, 0xF0
0000740ecffd4886  vmovaps [rsp], xmm0
0000740ecffd488b  vmovaps [rsp+0x10], xmm1
0000740ecffd4891  vmovaps [rsp+0x20], xmm2
0000740ecffd4897  vmovaps [rsp+0x30], xmm3
0000740ecffd489d  vmovaps [rsp+0x40], xmm4
0000740ecffd48a3  vmovaps [rsp+0x50], xmm5
0000740ecffd48a9  vmovaps [rsp+0x60], xmm6
0000740ecffd48af  vmovaps [rsp+0x70], xmm7
0000740ecffd48b5  vmovaps [rsp+0x80], xmm8
0000740ecffd48be  vmovaps [rsp+0x90], xmm9
0000740ecffd48c7  vmovaps [rsp+0xA0], xmm10
0000740ecffd48d0  vmovaps [rsp+0xB0], xmm11
0000740ecffd48d9  vmovaps [rsp+0xC0], xmm12
0000740ecffd48e2  vmovaps [rsp+0xD0], xmm14
0000740ecffd48eb  vmovaps [rsp+0xE0], xmm15
0000740ecffd48f4  sub rsp, 0x30
0000740ecffd48f8  movaps [rsp], xmm13
0000740ecffd48fd  movaps [rsp+0x10], xmm1
0000740ecffd4902  movaps [rsp+0x20], xmm8
0000740ecffd4908  lea rdi, [rsp]
0000740ecffd490c  mov esi, 0x00
0000740ecffd4911  mov rax, 0x5E8249CF1530
0000740ecffd491b  call rax
0000740ecffd491d  movaps xmm13, [rsp]
0000740ecffd4922  add rsp, 0x30
0000740ecffd4926  vmovaps xmm0, [rsp]
0000740ecffd492b  vmovaps xmm1, [rsp+0x10]
0000740ecffd4931  vmovaps xmm2, [rsp+0x20]
0000740ecffd4937  vmovaps xmm3, [rsp+0x30]
0000740ecffd493d  vmovaps xmm4, [rsp+0x40]
0000740ecffd4943  vmovaps xmm5, [rsp+0x50]
0000740ecffd4949  vmovaps xmm6, [rsp+0x60]
0000740ecffd494f  vmovaps xmm7, [rsp+0x70]
0000740ecffd4955  vmovaps xmm8, [rsp+0x80]
0000740ecffd495e  vmovaps xmm9, [rsp+0x90]
0000740ecffd4967  vmovaps xmm10, [rsp+0xA0]
0000740ecffd4970  vmovaps xmm11, [rsp+0xB0]
0000740ecffd4979  vmovaps xmm12, [rsp+0xC0]
0000740ecffd4982  vmovaps xmm14, [rsp+0xD0]
0000740ecffd498b  vmovaps xmm15, [rsp+0xE0]
0000740ecffd4994  add rsp, 0xF0
0000740ecffd499b  pop r11
0000740ecffd499d  pop r10
0000740ecffd499f  pop r9
0000740ecffd49a1  pop r8
0000740ecffd49a3  pop rsi
0000740ecffd49a4  pop rdi
0000740ecffd49a5  pop rdx
0000740ecffd49a6  pop rcx
0000740ecffd49a7  pop rax
0000740ecffd49a8  add rsp, 0x08
0000740ecffd49ac  jmp 0x0000740ECFFD0183
0000740ecffd49b1  call 0x0000740ECFDFF430
0000740ecffd49b6  jmp 0x0000740ECFFD018D
0000740ecffd49bb  sub rsp, 0x08
0000740ecffd49bf  push rax
0000740ecffd49c0  push rcx
0000740ecffd49c1  push rdx
0000740ecffd49c2  push rdi
0000740ecffd49c3  push rsi
0000740ecffd49c4  push r8
0000740ecffd49c6  push r9
0000740ecffd49c8  push r10
0000740ecffd49ca  push r11
0000740ecffd49cc  sub rsp, 0xF0
0000740ecffd49d3  vmovaps [rsp], xmm0
0000740ecffd49d8  vmovaps [rsp+0x10], xmm1
0000740ecffd49de  vmovaps [rsp+0x20], xmm2
0000740ecffd49e4  vmovaps [rsp+0x30], xmm3
0000740ecffd49ea  vmovaps [rsp+0x40], xmm4
0000740ecffd49f0  vmovaps [rsp+0x50], xmm5
0000740ecffd49f6  vmovaps [rsp+0x60], xmm6
0000740ecffd49fc  vmovaps [rsp+0x70], xmm7
0000740ecffd4a02  vmovaps [rsp+0x80], xmm9
0000740ecffd4a0b  vmovaps [rsp+0x90], xmm10
0000740ecffd4a14  vmovaps [rsp+0xA0], xmm11
0000740ecffd4a1d  vmovaps [rsp+0xB0], xmm12
0000740ecffd4a26  vmovaps [rsp+0xC0], xmm13
0000740ecffd4a2f  vmovaps [rsp+0xD0], xmm14
0000740ecffd4a38  vmovaps [rsp+0xE0], xmm15
0000740ecffd4a41  sub rsp, 0x30
0000740ecffd4a45  movaps [rsp], xmm8
0000740ecffd4a4a  movaps [rsp+0x10], xmm14
0000740ecffd4a50  movaps [rsp+0x20], xmm9
0000740ecffd4a56  lea rdi, [rsp]
0000740ecffd4a5a  mov esi, 0x00
0000740ecffd4a5f  mov rax, 0x5E8249CF1530
0000740ecffd4a69  call rax
0000740ecffd4a6b  movaps xmm8, [rsp]
0000740ecffd4a70  add rsp, 0x30
0000740ecffd4a74  vmovaps xmm0, [rsp]
0000740ecffd4a79  vmovaps xmm1, [rsp+0x10]
0000740ecffd4a7f  vmovaps xmm2, [rsp+0x20]
0000740ecffd4a85  vmovaps xmm3, [rsp+0x30]
0000740ecffd4a8b  vmovaps xmm4, [rsp+0x40]
0000740ecffd4a91  vmovaps xmm5, [rsp+0x50]
0000740ecffd4a97  vmovaps xmm6, [rsp+0x60]
0000740ecffd4a9d  vmovaps xmm7, [rsp+0x70]
0000740ecffd4aa3  vmovaps xmm9, [rsp+0x80]
0000740ecffd4aac  vmovaps xmm10, [rsp+0x90]
0000740ecffd4ab5  vmovaps xmm11, [rsp+0xA0]
0000740ecffd4abe  vmovaps xmm12, [rsp+0xB0]
0000740ecffd4ac7  vmovaps xmm13, [rsp+0xC0]
0000740ecffd4ad0  vmovaps xmm14, [rsp+0xD0]
0000740ecffd4ad9  vmovaps xmm15, [rsp+0xE0]
0000740ecffd4ae2  add rsp, 0xF0
0000740ecffd4ae9  pop r11
0000740ecffd4aeb  pop r10
0000740ecffd4aed  pop r9
0000740ecffd4aef  pop r8
0000740ecffd4af1  pop rsi
0000740ecffd4af2  pop rdi
0000740ecffd4af3  pop rdx
0000740ecffd4af4  pop rcx
0000740ecffd4af5  pop rax
0000740ecffd4af6  add rsp, 0x08
0000740ecffd4afa  jmp 0x0000740ECFFD01AF
0000740ecffd4aff  sub rsp, 0x08
0000740ecffd4b03  push rax
0000740ecffd4b04  push rcx
0000740ecffd4b05  push rdx
0000740ecffd4b06  push rdi
0000740ecffd4b07  push rsi
0000740ecffd4b08  push r8
0000740ecffd4b0a  push r9
0000740ecffd4b0c  push r10
0000740ecffd4b0e  push r11
0000740ecffd4b10  sub rsp, 0xF0
0000740ecffd4b17  vmovaps [rsp], xmm0
0000740ecffd4b1c  vmovaps [rsp+0x10], xmm1
0000740ecffd4b22  vmovaps [rsp+0x20], xmm2
0000740ecffd4b28  vmovaps [rsp+0x30], xmm3
0000740ecffd4b2e  vmovaps [rsp+0x40], xmm4
0000740ecffd4b34  vmovaps [rsp+0x50], xmm5
0000740ecffd4b3a  vmovaps [rsp+0x60], xmm6
0000740ecffd4b40  vmovaps [rsp+0x70], xmm7
0000740ecffd4b46  vmovaps [rsp+0x80], xmm8
0000740ecffd4b4f  vmovaps [rsp+0x90], xmm10
0000740ecffd4b58  vmovaps [rsp+0xA0], xmm11
0000740ecffd4b61  vmovaps [rsp+0xB0], xmm12
0000740ecffd4b6a  vmovaps [rsp+0xC0], xmm13
0000740ecffd4b73  vmovaps [rsp+0xD0], xmm14
0000740ecffd4b7c  vmovaps [rsp+0xE0], xmm15
0000740ecffd4b85  sub rsp, 0x30
0000740ecffd4b89  movaps [rsp], xmm9
0000740ecffd4b8e  movaps [rsp+0x10], xmm1
0000740ecffd4b93  movaps [rsp+0x20], xmm14
0000740ecffd4b99  lea rdi, [rsp]
0000740ecffd4b9d  mov esi, 0x00
0000740ecffd4ba2  mov rax, 0x5E8249CF1530
0000740ecffd4bac  call rax
0000740ecffd4bae  movaps xmm9, [rsp]
0000740ecffd4bb3  add rsp, 0x30
0000740ecffd4bb7  vmovaps xmm0, [rsp]
0000740ecffd4bbc  vmovaps xmm1, [rsp+0x10]
0000740ecffd4bc2  vmovaps xmm2, [rsp+0x20]
0000740ecffd4bc8  vmovaps xmm3, [rsp+0x30]
0000740ecffd4bce  vmovaps xmm4, [rsp+0x40]
0000740ecffd4bd4  vmovaps xmm5, [rsp+0x50]
0000740ecffd4bda  vmovaps xmm6, [rsp+0x60]
0000740ecffd4be0  vmovaps xmm7, [rsp+0x70]
0000740ecffd4be6  vmovaps xmm8, [rsp+0x80]
0000740ecffd4bef  vmovaps xmm10, [rsp+0x90]
0000740ecffd4bf8  vmovaps xmm11, [rsp+0xA0]
0000740ecffd4c01  vmovaps xmm12, [rsp+0xB0]
0000740ecffd4c0a  vmovaps xmm13, [rsp+0xC0]
0000740ecffd4c13  vmovaps xmm14, [rsp+0xD0]
0000740ecffd4c1c  vmovaps xmm15, [rsp+0xE0]
0000740ecffd4c25  add rsp, 0xF0
0000740ecffd4c2c  pop r11
0000740ecffd4c2e  pop r10
0000740ecffd4c30  pop r9
0000740ecffd4c32  pop r8
0000740ecffd4c34  pop rsi
0000740ecffd4c35  pop rdi
0000740ecffd4c36  pop rdx
0000740ecffd4c37  pop rcx
0000740ecffd4c38  pop rax
0000740ecffd4c39  add rsp, 0x08
0000740ecffd4c3d  jmp 0x0000740ECFFD01DD
0000740ecffd4c42  sub rsp, 0x08
0000740ecffd4c46  push rax
0000740ecffd4c47  push rcx
0000740ecffd4c48  push rdx
0000740ecffd4c49  push rdi
0000740ecffd4c4a  push rsi
0000740ecffd4c4b  push r8
0000740ecffd4c4d  push r9
0000740ecffd4c4f  push r10
0000740ecffd4c51  push r11
0000740ecffd4c53  sub rsp, 0xF0
0000740ecffd4c5a  vmovaps [rsp], xmm0
0000740ecffd4c5f  vmovaps [rsp+0x10], xmm1
0000740ecffd4c65  vmovaps [rsp+0x20], xmm2
0000740ecffd4c6b  vmovaps [rsp+0x30], xmm3
0000740ecffd4c71  vmovaps [rsp+0x40], xmm4
0000740ecffd4c77  vmovaps [rsp+0x50], xmm5
0000740ecffd4c7d  vmovaps [rsp+0x60], xmm6
0000740ecffd4c83  vmovaps [rsp+0x70], xmm7
0000740ecffd4c89  vmovaps [rsp+0x80], xmm8
0000740ecffd4c92  vmovaps [rsp+0x90], xmm9
0000740ecffd4c9b  vmovaps [rsp+0xA0], xmm10
0000740ecffd4ca4  vmovaps [rsp+0xB0], xmm11
0000740ecffd4cad  vmovaps [rsp+0xC0], xmm12
0000740ecffd4cb6  vmovaps [rsp+0xD0], xmm13
0000740ecffd4cbf  vmovaps [rsp+0xE0], xmm15
0000740ecffd4cc8  sub rsp, 0x30
0000740ecffd4ccc  movaps [rsp], xmm14
0000740ecffd4cd1  movaps [rsp+0x10], xmm4
0000740ecffd4cd6  movaps [rsp+0x20], xmm1
0000740ecffd4cdb  lea rdi, [rsp]
0000740ecffd4cdf  mov esi, 0x00
0000740ecffd4ce4  mov rax, 0x5E8249CF1530
0000740ecffd4cee  call rax
0000740ecffd4cf0  movaps xmm14, [rsp]
0000740ecffd4cf5  add rsp, 0x30
0000740ecffd4cf9  vmovaps xmm0, [rsp]
0000740ecffd4cfe  vmovaps xmm1, [rsp+0x10]
0000740ecffd4d04  vmovaps xmm2, [rsp+0x20]
0000740ecffd4d0a  vmovaps xmm3, [rsp+0x30]
0000740ecffd4d10  vmovaps xmm4, [rsp+0x40]
0000740ecffd4d16  vmovaps xmm5, [rsp+0x50]
0000740ecffd4d1c  vmovaps xmm6, [rsp+0x60]
0000740ecffd4d22  vmovaps xmm7, [rsp+0x70]
0000740ecffd4d28  vmovaps xmm8, [rsp+0x80]
0000740ecffd4d31  vmovaps xmm9, [rsp+0x90]
0000740ecffd4d3a  vmovaps xmm10, [rsp+0xA0]
0000740ecffd4d43  vmovaps xmm11, [rsp+0xB0]
0000740ecffd4d4c  vmovaps xmm12, [rsp+0xC0]
0000740ecffd4d55  vmovaps xmm13, [rsp+0xD0]
0000740ecffd4d5e  vmovaps xmm15, [rsp+0xE0]
0000740ecffd4d67  add rsp, 0xF0
0000740ecffd4d6e  pop r11
0000740ecffd4d70  pop r10
0000740ecffd4d72  pop r9
0000740ecffd4d74  pop r8
0000740ecffd4d76  pop rsi
0000740ecffd4d77  pop rdi
0000740ecffd4d78  pop rdx
0000740ecffd4d79  pop rcx
0000740ecffd4d7a  pop rax
0000740ecffd4d7b  add rsp, 0x08
0000740ecffd4d7f  jmp 0x0000740ECFFD0203
0000740ecffd4d84  sub rsp, 0x08
0000740ecffd4d88  push rax
0000740ecffd4d89  push rcx
0000740ecffd4d8a  push rdx
0000740ecffd4d8b  push rdi
0000740ecffd4d8c  push rsi
0000740ecffd4d8d  push r8
0000740ecffd4d8f  push r9
0000740ecffd4d91  push r10
0000740ecffd4d93  push r11
0000740ecffd4d95  sub rsp, 0xF0
0000740ecffd4d9c  vmovaps [rsp], xmm0
0000740ecffd4da1  vmovaps [rsp+0x10], xmm2
0000740ecffd4da7  vmovaps [rsp+0x20], xmm3
0000740ecffd4dad  vmovaps [rsp+0x30], xmm4
0000740ecffd4db3  vmovaps [rsp+0x40], xmm5
0000740ecffd4db9  vmovaps [rsp+0x50], xmm6
0000740ecffd4dbf  vmovaps [rsp+0x60], xmm7
0000740ecffd4dc5  vmovaps [rsp+0x70], xmm8
0000740ecffd4dcb  vmovaps [rsp+0x80], xmm9
0000740ecffd4dd4  vmovaps [rsp+0x90], xmm10
0000740ecffd4ddd  vmovaps [rsp+0xA0], xmm11
0000740ecffd4de6  vmovaps [rsp+0xB0], xmm12
0000740ecffd4def  vmovaps [rsp+0xC0], xmm13
0000740ecffd4df8  vmovaps [rsp+0xD0], xmm14
0000740ecffd4e01  vmovaps [rsp+0xE0], xmm15
0000740ecffd4e0a  sub rsp, 0x30
0000740ecffd4e0e  movaps [rsp], xmm1
0000740ecffd4e12  movaps [rsp+0x10], xmm12
0000740ecffd4e18  movaps [rsp+0x20], xmm11
0000740ecffd4e1e  lea rdi, [rsp]
0000740ecffd4e22  mov esi, 0x00
0000740ecffd4e27  mov rax, 0x5E8249CF1530
0000740ecffd4e31  call rax
0000740ecffd4e33  movaps xmm1, [rsp]
0000740ecffd4e37  add rsp, 0x30
0000740ecffd4e3b  vmovaps xmm0, [rsp]
0000740ecffd4e40  vmovaps xmm2, [rsp+0x10]
0000740ecffd4e46  vmovaps xmm3, [rsp+0x20]
0000740ecffd4e4c  vmovaps xmm4, [rsp+0x30]
0000740ecffd4e52  vmovaps xmm5, [rsp+0x40]
0000740ecffd4e58  vmovaps xmm6, [rsp+0x50]
0000740ecffd4e5e  vmovaps xmm7, [rsp+0x60]
0000740ecffd4e64  vmovaps xmm8, [rsp+0x70]
0000740ecffd4e6a  vmovaps xmm9, [rsp+0x80]
0000740ecffd4e73  vmovaps xmm10, [rsp+0x90]
0000740ecffd4e7c  vmovaps xmm11, [rsp+0xA0]
0000740ecffd4e85  vmovaps xmm12, [rsp+0xB0]
0000740ecffd4e8e  vmovaps xmm13, [rsp+0xC0]
0000740ecffd4e97  vmovaps xmm14, [rsp+0xD0]
0000740ecffd4ea0  vmovaps xmm15, [rsp+0xE0]
0000740ecffd4ea9  add rsp, 0xF0
0000740ecffd4eb0  pop r11
0000740ecffd4eb2  pop r10
0000740ecffd4eb4  pop r9
0000740ecffd4eb6  pop r8
0000740ecffd4eb8  pop rsi
0000740ecffd4eb9  pop rdi
0000740ecffd4eba  pop rdx
0000740ecffd4ebb  pop rcx
0000740ecffd4ebc  pop rax
0000740ecffd4ebd  add rsp, 0x08
0000740ecffd4ec1  jmp 0x0000740ECFFD0224
0000740ecffd4ec6  call 0x0000740ECFEE20A0
0000740ecffd4ecb  jmp 0x0000740ECFFD0232
0000740ecffd4ed0  call 0x0000740ECFE09D70
0000740ecffd4ed5  jmp 0x0000740ECFFD023C
0000740ecffd4eda  sub rsp, 0x08
0000740ecffd4ede  push rax
0000740ecffd4edf  push rcx
0000740ecffd4ee0  push rdx
0000740ecffd4ee1  push rdi
0000740ecffd4ee2  push rsi
0000740ecffd4ee3  push r8
0000740ecffd4ee5  push r9
0000740ecffd4ee7  push r10
0000740ecffd4ee9  push r11
0000740ecffd4eeb  sub rsp, 0xF0
0000740ecffd4ef2  vmovaps [rsp], xmm0
0000740ecffd4ef7  vmovaps [rsp+0x10], xmm1
0000740ecffd4efd  vmovaps [rsp+0x20], xmm2
0000740ecffd4f03  vmovaps [rsp+0x30], xmm3
0000740ecffd4f09  vmovaps [rsp+0x40], xmm4
0000740ecffd4f0f  vmovaps [rsp+0x50], xmm5
0000740ecffd4f15  vmovaps [rsp+0x60], xmm6
0000740ecffd4f1b  vmovaps [rsp+0x70], xmm8
0000740ecffd4f21  vmovaps [rsp+0x80], xmm9
0000740ecffd4f2a  vmovaps [rsp+0x90], xmm10
0000740ecffd4f33  vmovaps [rsp+0xA0], xmm11
0000740ecffd4f3c  vmovaps [rsp+0xB0], xmm12
0000740ecffd4f45  vmovaps [rsp+0xC0], xmm13
0000740ecffd4f4e  vmovaps [rsp+0xD0], xmm14
0000740ecffd4f57  vmovaps [rsp+0xE0], xmm15
0000740ecffd4f60  sub rsp, 0x30
0000740ecffd4f64  movaps [rsp], xmm7
0000740ecffd4f68  movaps [rsp+0x10], xmm15
0000740ecffd4f6e  movaps [rsp+0x20], xmm10
0000740ecffd4f74  lea rdi, [rsp]
0000740ecffd4f78  mov esi, 0x00
0000740ecffd4f7d  mov rax, 0x5E8249CF1530
0000740ecffd4f87  call rax
0000740ecffd4f89  movaps xmm7, [rsp]
0000740ecffd4f8d  add rsp, 0x30
0000740ecffd4f91  vmovaps xmm0, [rsp]
0000740ecffd4f96  vmovaps xmm1, [rsp+0x10]
0000740ecffd4f9c  vmovaps xmm2, [rsp+0x20]
0000740ecffd4fa2  vmovaps xmm3, [rsp+0x30]
0000740ecffd4fa8  vmovaps xmm4, [rsp+0x40]
0000740ecffd4fae  vmovaps xmm5, [rsp+0x50]
0000740ecffd4fb4  vmovaps xmm6, [rsp+0x60]
0000740ecffd4fba  vmovaps xmm8, [rsp+0x70]
0000740ecffd4fc0  vmovaps xmm9, [rsp+0x80]
0000740ecffd4fc9  vmovaps xmm10, [rsp+0x90]
0000740ecffd4fd2  vmovaps xmm11, [rsp+0xA0]
0000740ecffd4fdb  vmovaps xmm12, [rsp+0xB0]
0000740ecffd4fe4  vmovaps xmm13, [rsp+0xC0]
0000740ecffd4fed  vmovaps xmm14, [rsp+0xD0]
0000740ecffd4ff6  vmovaps xmm15, [rsp+0xE0]
0000740ecffd4fff  add rsp, 0xF0
0000740ecffd5006  pop r11
0000740ecffd5008  pop r10
0000740ecffd500a  pop r9
0000740ecffd500c  pop r8
0000740ecffd500e  pop rsi
0000740ecffd500f  pop rdi
0000740ecffd5010  pop rdx
0000740ecffd5011  pop rcx
0000740ecffd5012  pop rax
0000740ecffd5013  add rsp, 0x08
0000740ecffd5017  jmp 0x0000740ECFFD025D
0000740ecffd501c  sub rsp, 0x08
0000740ecffd5020  push rax
0000740ecffd5021  push rcx
0000740ecffd5022  push rdx
0000740ecffd5023  push rdi
0000740ecffd5024  push rsi
0000740ecffd5025  push r8
0000740ecffd5027  push r9
0000740ecffd5029  push r10
0000740ecffd502b  push r11
0000740ecffd502d  sub rsp, 0xF0
0000740ecffd5034  vmovaps [rsp], xmm0
0000740ecffd5039  vmovaps [rsp+0x10], xmm1
0000740ecffd503f  vmovaps [rsp+0x20], xmm2
0000740ecffd5045  vmovaps [rsp+0x30], xmm3
0000740ecffd504b  vmovaps [rsp+0x40], xmm4
0000740ecffd5051  vmovaps [rsp+0x50], xmm5
0000740ecffd5057  vmovaps [rsp+0x60], xmm6
0000740ecffd505d  vmovaps [rsp+0x70], xmm7
0000740ecffd5063  vmovaps [rsp+0x80], xmm8
0000740ecffd506c  vmovaps [rsp+0x90], xmm9
0000740ecffd5075  vmovaps [rsp+0xA0], xmm11
0000740ecffd507e  vmovaps [rsp+0xB0], xmm12
0000740ecffd5087  vmovaps [rsp+0xC0], xmm13
0000740ecffd5090  vmovaps [rsp+0xD0], xmm14
0000740ecffd5099  vmovaps [rsp+0xE0], xmm15
0000740ecffd50a2  sub rsp, 0x30
0000740ecffd50a6  movaps [rsp], xmm10
0000740ecffd50ab  movaps [rsp+0x10], xmm11
0000740ecffd50b1  movaps [rsp+0x20], xmm15
0000740ecffd50b7  lea rdi, [rsp]
0000740ecffd50bb  mov esi, 0x00
0000740ecffd50c0  mov rax, 0x5E8249CF1530
0000740ecffd50ca  call rax
0000740ecffd50cc  movaps xmm10, [rsp]
0000740ecffd50d1  add rsp, 0x30
0000740ecffd50d5  vmovaps xmm0, [rsp]
0000740ecffd50da  vmovaps xmm1, [rsp+0x10]
0000740ecffd50e0  vmovaps xmm2, [rsp+0x20]
0000740ecffd50e6  vmovaps xmm3, [rsp+0x30]
0000740ecffd50ec  vmovaps xmm4, [rsp+0x40]
0000740ecffd50f2  vmovaps xmm5, [rsp+0x50]
0000740ecffd50f8  vmovaps xmm6, [rsp+0x60]
0000740ecffd50fe  vmovaps xmm7, [rsp+0x70]
0000740ecffd5104  vmovaps xmm8, [rsp+0x80]
0000740ecffd510d  vmovaps xmm9, [rsp+0x90]
0000740ecffd5116  vmovaps xmm11, [rsp+0xA0]
0000740ecffd511f  vmovaps xmm12, [rsp+0xB0]
0000740ecffd5128  vmovaps xmm13, [rsp+0xC0]
0000740ecffd5131  vmovaps xmm14, [rsp+0xD0]
0000740ecffd513a  vmovaps xmm15, [rsp+0xE0]
0000740ecffd5143  add rsp, 0xF0
0000740ecffd514a  pop r11
0000740ecffd514c  pop r10
0000740ecffd514e  pop r9
0000740ecffd5150  pop r8
0000740ecffd5152  pop rsi
0000740ecffd5153  pop rdi
0000740ecffd5154  pop rdx
0000740ecffd5155  pop rcx
0000740ecffd5156  pop rax
0000740ecffd5157  add rsp, 0x08
0000740ecffd515b  jmp 0x0000740ECFFD028B
0000740ecffd5160  sub rsp, 0x08
0000740ecffd5164  push rax
0000740ecffd5165  push rcx
0000740ecffd5166  push rdx
0000740ecffd5167  push rdi
0000740ecffd5168  push rsi
0000740ecffd5169  push r8
0000740ecffd516b  push r9
0000740ecffd516d  push r10
0000740ecffd516f  push r11
0000740ecffd5171  sub rsp, 0xF0
0000740ecffd5178  vmovaps [rsp], xmm0
0000740ecffd517d  vmovaps [rsp+0x10], xmm1
0000740ecffd5183  vmovaps [rsp+0x20], xmm2
0000740ecffd5189  vmovaps [rsp+0x30], xmm3
0000740ecffd518f  vmovaps [rsp+0x40], xmm4
0000740ecffd5195  vmovaps [rsp+0x50], xmm5
0000740ecffd519b  vmovaps [rsp+0x60], xmm6
0000740ecffd51a1  vmovaps [rsp+0x70], xmm7
0000740ecffd51a7  vmovaps [rsp+0x80], xmm8
0000740ecffd51b0  vmovaps [rsp+0x90], xmm9
0000740ecffd51b9  vmovaps [rsp+0xA0], xmm10
0000740ecffd51c2  vmovaps [rsp+0xB0], xmm12
0000740ecffd51cb  vmovaps [rsp+0xC0], xmm13
0000740ecffd51d4  vmovaps [rsp+0xD0], xmm14
0000740ecffd51dd  vmovaps [rsp+0xE0], xmm15
0000740ecffd51e6  sub rsp, 0x30
0000740ecffd51ea  movaps [rsp], xmm11
0000740ecffd51ef  movaps [rsp+0x10], xmm12
0000740ecffd51f5  movaps [rsp+0x20], xmm15
0000740ecffd51fb  lea rdi, [rsp]
0000740ecffd51ff  mov esi, 0x00
0000740ecffd5204  mov rax, 0x5E8249CF1530
0000740ecffd520e  call rax
0000740ecffd5210  movaps xmm11, [rsp]
0000740ecffd5215  add rsp, 0x30
0000740ecffd5219  vmovaps xmm0, [rsp]
0000740ecffd521e  vmovaps xmm1, [rsp+0x10]
0000740ecffd5224  vmovaps xmm2, [rsp+0x20]
0000740ecffd522a  vmovaps xmm3, [rsp+0x30]
0000740ecffd5230  vmovaps xmm4, [rsp+0x40]
0000740ecffd5236  vmovaps xmm5, [rsp+0x50]
0000740ecffd523c  vmovaps xmm6, [rsp+0x60]
0000740ecffd5242  vmovaps xmm7, [rsp+0x70]
0000740ecffd5248  vmovaps xmm8, [rsp+0x80]
0000740ecffd5251  vmovaps xmm9, [rsp+0x90]
0000740ecffd525a  vmovaps xmm10, [rsp+0xA0]
0000740ecffd5263  vmovaps xmm12, [rsp+0xB0]
0000740ecffd526c  vmovaps xmm13, [rsp+0xC0]
0000740ecffd5275  vmovaps xmm14, [rsp+0xD0]
0000740ecffd527e  vmovaps xmm15, [rsp+0xE0]
0000740ecffd5287  add rsp, 0xF0
0000740ecffd528e  pop r11
0000740ecffd5290  pop r10
0000740ecffd5292  pop r9
0000740ecffd5294  pop r8
0000740ecffd5296  pop rsi
0000740ecffd5297  pop rdi
0000740ecffd5298  pop rdx
0000740ecffd5299  pop rcx
0000740ecffd529a  pop rax
0000740ecffd529b  add rsp, 0x08
0000740ecffd529f  jmp 0x0000740ECFFD02B9
0000740ecffd52a4  sub rsp, 0x08
0000740ecffd52a8  push rax
0000740ecffd52a9  push rcx
0000740ecffd52aa  push rdx
0000740ecffd52ab  push rdi
0000740ecffd52ac  push rsi
0000740ecffd52ad  push r8
0000740ecffd52af  push r9
0000740ecffd52b1  push r10
0000740ecffd52b3  push r11
0000740ecffd52b5  sub rsp, 0xF0
0000740ecffd52bc  vmovaps [rsp], xmm0
0000740ecffd52c1  vmovaps [rsp+0x10], xmm1
0000740ecffd52c7  vmovaps [rsp+0x20], xmm2
0000740ecffd52cd  vmovaps [rsp+0x30], xmm3
0000740ecffd52d3  vmovaps [rsp+0x40], xmm4
0000740ecffd52d9  vmovaps [rsp+0x50], xmm5
0000740ecffd52df  vmovaps [rsp+0x60], xmm6
0000740ecffd52e5  vmovaps [rsp+0x70], xmm7
0000740ecffd52eb  vmovaps [rsp+0x80], xmm8
0000740ecffd52f4  vmovaps [rsp+0x90], xmm9
0000740ecffd52fd  vmovaps [rsp+0xA0], xmm10
0000740ecffd5306  vmovaps [rsp+0xB0], xmm11
0000740ecffd530f  vmovaps [rsp+0xC0], xmm12
0000740ecffd5318  vmovaps [rsp+0xD0], xmm13
0000740ecffd5321  vmovaps [rsp+0xE0], xmm14
0000740ecffd532a  sub rsp, 0x30
0000740ecffd532e  movaps [rsp], xmm15
0000740ecffd5333  movaps [rsp+0x10], xmm13
0000740ecffd5339  movaps [rsp+0x20], xmm9
0000740ecffd533f  lea rdi, [rsp]
0000740ecffd5343  mov esi, 0x00
0000740ecffd5348  mov rax, 0x5E8249CF1530
0000740ecffd5352  call rax
0000740ecffd5354  movaps xmm15, [rsp]
0000740ecffd5359  add rsp, 0x30
0000740ecffd535d  vmovaps xmm0, [rsp]
0000740ecffd5362  vmovaps xmm1, [rsp+0x10]
0000740ecffd5368  vmovaps xmm2, [rsp+0x20]
0000740ecffd536e  vmovaps xmm3, [rsp+0x30]
0000740ecffd5374  vmovaps xmm4, [rsp+0x40]
0000740ecffd537a  vmovaps xmm5, [rsp+0x50]
0000740ecffd5380  vmovaps xmm6, [rsp+0x60]
0000740ecffd5386  vmovaps xmm7, [rsp+0x70]
0000740ecffd538c  vmovaps xmm8, [rsp+0x80]
0000740ecffd5395  vmovaps xmm9, [rsp+0x90]
0000740ecffd539e  vmovaps xmm10, [rsp+0xA0]
0000740ecffd53a7  vmovaps xmm11, [rsp+0xB0]
0000740ecffd53b0  vmovaps xmm12, [rsp+0xC0]
0000740ecffd53b9  vmovaps xmm13, [rsp+0xD0]
0000740ecffd53c2  vmovaps xmm14, [rsp+0xE0]
0000740ecffd53cb  add rsp, 0xF0
0000740ecffd53d2  pop r11
0000740ecffd53d4  pop r10
0000740ecffd53d6  pop r9
0000740ecffd53d8  pop r8
0000740ecffd53da  pop rsi
0000740ecffd53db  pop rdi
0000740ecffd53dc  pop rdx
0000740ecffd53dd  pop rcx
0000740ecffd53de  pop rax
0000740ecffd53df  add rsp, 0x08
0000740ecffd53e3  jmp 0x0000740ECFFD02D4
0000740ecffd53e8  sub rsp, 0x08
0000740ecffd53ec  push rax
0000740ecffd53ed  push rcx
0000740ecffd53ee  push rdx
0000740ecffd53ef  push rdi
0000740ecffd53f0  push rsi
0000740ecffd53f1  push r8
0000740ecffd53f3  push r9
0000740ecffd53f5  push r10
0000740ecffd53f7  push r11
0000740ecffd53f9  sub rsp, 0xF0
0000740ecffd5400  vmovaps [rsp], xmm0
0000740ecffd5405  vmovaps [rsp+0x10], xmm1
0000740ecffd540b  vmovaps [rsp+0x20], xmm2
0000740ecffd5411  vmovaps [rsp+0x30], xmm3
0000740ecffd5417  vmovaps [rsp+0x40], xmm4
0000740ecffd541d  vmovaps [rsp+0x50], xmm5
0000740ecffd5423  vmovaps [rsp+0x60], xmm6
0000740ecffd5429  vmovaps [rsp+0x70], xmm7
0000740ecffd542f  vmovaps [rsp+0x80], xmm8
0000740ecffd5438  vmovaps [rsp+0x90], xmm9
0000740ecffd5441  vmovaps [rsp+0xA0], xmm10
0000740ecffd544a  vmovaps [rsp+0xB0], xmm11
0000740ecffd5453  vmovaps [rsp+0xC0], xmm12
0000740ecffd545c  vmovaps [rsp+0xD0], xmm14
0000740ecffd5465  vmovaps [rsp+0xE0], xmm15
0000740ecffd546e  sub rsp, 0x30
0000740ecffd5472  movaps [rsp], xmm13
0000740ecffd5477  movaps [rsp+0x10], xmm8
0000740ecffd547d  movaps [rsp+0x20], xmm14
0000740ecffd5483  lea rdi, [rsp]
0000740ecffd5487  mov esi, 0x00
0000740ecffd548c  mov rax, 0x5E8249CF1530
0000740ecffd5496  call rax
0000740ecffd5498  movaps xmm13, [rsp]
0000740ecffd549d  add rsp, 0x30
0000740ecffd54a1  vmovaps xmm0, [rsp]
0000740ecffd54a6  vmovaps xmm1, [rsp+0x10]
0000740ecffd54ac  vmovaps xmm2, [rsp+0x20]
0000740ecffd54b2  vmovaps xmm3, [rsp+0x30]
0000740ecffd54b8  vmovaps xmm4, [rsp+0x40]
0000740ecffd54be  vmovaps xmm5, [rsp+0x50]
0000740ecffd54c4  vmovaps xmm6, [rsp+0x60]
0000740ecffd54ca  vmovaps xmm7, [rsp+0x70]
0000740ecffd54d0  vmovaps xmm8, [rsp+0x80]
0000740ecffd54d9  vmovaps xmm9, [rsp+0x90]
0000740ecffd54e2  vmovaps xmm10, [rsp+0xA0]
0000740ecffd54eb  vmovaps xmm11, [rsp+0xB0]
0000740ecffd54f4  vmovaps xmm12, [rsp+0xC0]
0000740ecffd54fd  vmovaps xmm14, [rsp+0xD0]
0000740ecffd5506  vmovaps xmm15, [rsp+0xE0]
0000740ecffd550f  add rsp, 0xF0
0000740ecffd5516  pop r11
0000740ecffd5518  pop r10
0000740ecffd551a  pop r9
0000740ecffd551c  pop r8
0000740ecffd551e  pop rsi
0000740ecffd551f  pop rdi
0000740ecffd5520  pop rdx
0000740ecffd5521  pop rcx
0000740ecffd5522  pop rax
0000740ecffd5523  add rsp, 0x08
0000740ecffd5527  jmp 0x0000740ECFFD02F7
0000740ecffd552c  sub rsp, 0x08
0000740ecffd5530  push rax
0000740ecffd5531  push rcx
0000740ecffd5532  push rdx
0000740ecffd5533  push rdi
0000740ecffd5534  push rsi
0000740ecffd5535  push r8
0000740ecffd5537  push r9
0000740ecffd5539  push r10
0000740ecffd553b  push r11
0000740ecffd553d  sub rsp, 0xF0
0000740ecffd5544  vmovaps [rsp], xmm0
0000740ecffd5549  vmovaps [rsp+0x10], xmm1
0000740ecffd554f  vmovaps [rsp+0x20], xmm2
0000740ecffd5555  vmovaps [rsp+0x30], xmm3
0000740ecffd555b  vmovaps [rsp+0x40], xmm4
0000740ecffd5561  vmovaps [rsp+0x50], xmm5
0000740ecffd5567  vmovaps [rsp+0x60], xmm6
0000740ecffd556d  vmovaps [rsp+0x70], xmm7
0000740ecffd5573  vmovaps [rsp+0x80], xmm8
0000740ecffd557c  vmovaps [rsp+0x90], xmm9
0000740ecffd5585  vmovaps [rsp+0xA0], xmm10
0000740ecffd558e  vmovaps [rsp+0xB0], xmm11
0000740ecffd5597  vmovaps [rsp+0xC0], xmm12
0000740ecffd55a0  vmovaps [rsp+0xD0], xmm13
0000740ecffd55a9  vmovaps [rsp+0xE0], xmm15
0000740ecffd55b2  sub rsp, 0x30
0000740ecffd55b6  movaps [rsp], xmm14
0000740ecffd55bb  movaps [rsp+0x10], xmm1
0000740ecffd55c0  movaps [rsp+0x20], xmm10
0000740ecffd55c6  lea rdi, [rsp]
0000740ecffd55ca  mov esi, 0x00
0000740ecffd55cf  mov rax, 0x5E8249CF1530
0000740ecffd55d9  call rax
0000740ecffd55db  movaps xmm14, [rsp]
0000740ecffd55e0  add rsp, 0x30
0000740ecffd55e4  vmovaps xmm0, [rsp]
0000740ecffd55e9  vmovaps xmm1, [rsp+0x10]
0000740ecffd55ef  vmovaps xmm2, [rsp+0x20]
0000740ecffd55f5  vmovaps xmm3, [rsp+0x30]
0000740ecffd55fb  vmovaps xmm4, [rsp+0x40]
0000740ecffd5601  vmovaps xmm5, [rsp+0x50]
0000740ecffd5607  vmovaps xmm6, [rsp+0x60]
0000740ecffd560d  vmovaps xmm7, [rsp+0x70]
0000740ecffd5613  vmovaps xmm8, [rsp+0x80]
0000740ecffd561c  vmovaps xmm9, [rsp+0x90]
0000740ecffd5625  vmovaps xmm10, [rsp+0xA0]
0000740ecffd562e  vmovaps xmm11, [rsp+0xB0]
0000740ecffd5637  vmovaps xmm12, [rsp+0xC0]
0000740ecffd5640  vmovaps xmm13, [rsp+0xD0]
0000740ecffd5649  vmovaps xmm15, [rsp+0xE0]
0000740ecffd5652  add rsp, 0xF0
0000740ecffd5659  pop r11
0000740ecffd565b  pop r10
0000740ecffd565d  pop r9
0000740ecffd565f  pop r8
0000740ecffd5661  pop rsi
0000740ecffd5662  pop rdi
0000740ecffd5663  pop rdx
0000740ecffd5664  pop rcx
0000740ecffd5665  pop rax
0000740ecffd5666  add rsp, 0x08
0000740ecffd566a  jmp 0x0000740ECFFD031A
0000740ecffd566f  sub rsp, 0x08
0000740ecffd5673  push rax
0000740ecffd5674  push rcx
0000740ecffd5675  push rdx
0000740ecffd5676  push rdi
0000740ecffd5677  push rsi
0000740ecffd5678  push r8
0000740ecffd567a  push r9
0000740ecffd567c  push r10
0000740ecffd567e  push r11
0000740ecffd5680  sub rsp, 0xF0
0000740ecffd5687  vmovaps [rsp], xmm0
0000740ecffd568c  vmovaps [rsp+0x10], xmm2
0000740ecffd5692  vmovaps [rsp+0x20], xmm3
0000740ecffd5698  vmovaps [rsp+0x30], xmm4
0000740ecffd569e  vmovaps [rsp+0x40], xmm5
0000740ecffd56a4  vmovaps [rsp+0x50], xmm6
0000740ecffd56aa  vmovaps [rsp+0x60], xmm7
0000740ecffd56b0  vmovaps [rsp+0x70], xmm8
0000740ecffd56b6  vmovaps [rsp+0x80], xmm9
0000740ecffd56bf  vmovaps [rsp+0x90], xmm10
0000740ecffd56c8  vmovaps [rsp+0xA0], xmm11
0000740ecffd56d1  vmovaps [rsp+0xB0], xmm12
0000740ecffd56da  vmovaps [rsp+0xC0], xmm13
0000740ecffd56e3  vmovaps [rsp+0xD0], xmm14
0000740ecffd56ec  vmovaps [rsp+0xE0], xmm15
0000740ecffd56f5  sub rsp, 0x30
0000740ecffd56f9  movaps [rsp], xmm1
0000740ecffd56fd  movaps [rsp+0x10], xmm7
0000740ecffd5702  movaps [rsp+0x20], xmm11
0000740ecffd5708  lea rdi, [rsp]
0000740ecffd570c  mov esi, 0x00
0000740ecffd5711  mov rax, 0x5E8249CF1530
0000740ecffd571b  call rax
0000740ecffd571d  movaps xmm1, [rsp]
0000740ecffd5721  add rsp, 0x30
0000740ecffd5725  vmovaps xmm0, [rsp]
0000740ecffd572a  vmovaps xmm2, [rsp+0x10]
0000740ecffd5730  vmovaps xmm3, [rsp+0x20]
0000740ecffd5736  vmovaps xmm4, [rsp+0x30]
0000740ecffd573c  vmovaps xmm5, [rsp+0x40]
0000740ecffd5742  vmovaps xmm6, [rsp+0x50]
0000740ecffd5748  vmovaps xmm7, [rsp+0x60]
0000740ecffd574e  vmovaps xmm8, [rsp+0x70]
0000740ecffd5754  vmovaps xmm9, [rsp+0x80]
0000740ecffd575d  vmovaps xmm10, [rsp+0x90]
0000740ecffd5766  vmovaps xmm11, [rsp+0xA0]
0000740ecffd576f  vmovaps xmm12, [rsp+0xB0]
0000740ecffd5778  vmovaps xmm13, [rsp+0xC0]
0000740ecffd5781  vmovaps xmm14, [rsp+0xD0]
0000740ecffd578a  vmovaps xmm15, [rsp+0xE0]
0000740ecffd5793  add rsp, 0xF0
0000740ecffd579a  pop r11
0000740ecffd579c  pop r10
0000740ecffd579e  pop r9
0000740ecffd57a0  pop r8
0000740ecffd57a2  pop rsi
0000740ecffd57a3  pop rdi
0000740ecffd57a4  pop rdx
0000740ecffd57a5  pop rcx
0000740ecffd57a6  pop rax
0000740ecffd57a7  add rsp, 0x08
0000740ecffd57ab  jmp 0x0000740ECFFD033B
0000740ecffd57b0  call 0x0000740ECFE0E880
0000740ecffd57b5  jmp 0x0000740ECFFD034E
0000740ecffd57ba  call 0x0000740ECFE0C380
0000740ecffd57bf  jmp 0x0000740ECFFD0359
0000740ecffd57c4  call 0x0000740ECFE0D600
0000740ecffd57c9  jmp 0x0000740ECFFD0364
0000740ecffd57ce  call 0x0000740ECFDFF540
0000740ecffd57d3  jmp 0x0000740ECFFD036F
0000740ecffd57d8  int3
0000740ecffd57d9  nop [rax], eax
0000740ecffd57e0  mov rax, [r15+0x40]
0000740ecffd57e4  mov r14, [r15+0x58]
0000740ecffd57e8  lea r12, [rax+r14*1]
0000740ecffd57ec  movaps xmm1, [r15+0x1D0]
0000740ecffd57f4  vmovaps [rsp+0x10], xmm1
0000740ecffd57fa  vmovaps xmm15, [rsp+0x10]
0000740ecffd5800  por xmm1, xmm15
0000740ecffd5805  movaps xmm14, [r15+0x1A0]
0000740ecffd580d  vmovaps [rsp+0x10], xmm14
0000740ecffd5813  vmovaps xmm13, [rsp+0x10]
0000740ecffd5819  por xmm14, xmm13
0000740ecffd581e  lea rax, [r12+0x30]
0000740ecffd5823  mov r11, [r13+rax*1]
0000740ecffd5828  lea rax, [r12+0x38]
0000740ecffd582d  mov r10, [r13+rax*1]
0000740ecffd5832  movq xmm13, r11
0000740ecffd5837  movq xmm12, r10
0000740ecffd583c  movq xmm13, xmm13
0000740ecffd5841  vmovaps [rsp+0x10], xmm13
0000740ecffd5847  movq xmm13, xmm13
0000740ecffd584c  movaps [r15+0x130], xmm13
0000740ecffd5854  movq xmm12, xmm12
0000740ecffd5859  vmovaps [rsp+0x20], xmm12
0000740ecffd585f  movq xmm12, xmm12
0000740ecffd5864  movaps [r15+0x280], xmm12
0000740ecffd586c  movaps xmm13, [r15+0x270]
0000740ecffd5874  vmovaps [rsp+0x30], xmm13
0000740ecffd587a  vmovaps xmm12, [rsp+0x30]
0000740ecffd5880  por xmm13, xmm12
0000740ecffd5885  lea rax, [r12+0x20]
0000740ecffd588a  mov r11, [r13+rax*1]
0000740ecffd588f  lea rax, [r12+0x28]
0000740ecffd5894  mov r10, [r13+rax*1]
0000740ecffd5899  movq xmm12, r11
0000740ecffd589e  movq xmm11, r10
0000740ecffd58a3  movq xmm12, xmm12
0000740ecffd58a8  vmovaps [rsp+0x30], xmm12
0000740ecffd58ae  movq xmm12, xmm12
0000740ecffd58b3  movaps [r15+0x150], xmm12
0000740ecffd58bb  movq xmm11, xmm11
0000740ecffd58c0  vmovaps [rsp+0x40], xmm11
0000740ecffd58c6  movq xmm11, xmm11
0000740ecffd58cb  movaps [r15+0x140], xmm11
0000740ecffd58d3  lea rax, [r12+0x10]
0000740ecffd58d8  mov r11, [r13+rax*1]
0000740ecffd58dd  lea rax, [r12+0x18]
0000740ecffd58e2  mov r10, [r13+rax*1]
0000740ecffd58e7  movq xmm12, r11
0000740ecffd58ec  movq xmm11, r10
0000740ecffd58f1  movq xmm12, xmm12
0000740ecffd58f6  vmovaps [rsp+0x50], xmm12
0000740ecffd58fc  movq xmm12, xmm12
0000740ecffd5901  movaps [r15+0x170], xmm12
0000740ecffd5909  movq xmm11, xmm11
0000740ecffd590e  vmovaps [rsp+0x60], xmm11
0000740ecffd5914  movq xmm11, xmm11
0000740ecffd5919  movaps [r15+0x160], xmm11
0000740ecffd5921  mov rax, [r13+r12*1]
0000740ecffd5926  vmovq xmm12, rax
0000740ecffd592b  vpbroadcastq xmm12, xmm12
0000740ecffd5930  lea rax, [r12+0x08]
0000740ecffd5935  mov r12, [r13+rax*1]
0000740ecffd593a  movq xmm11, r12
0000740ecffd593f  movaps [r15+0x230], xmm11
0000740ecffd5947  mov rax, [r15+0xF8]
0000740ecffd594e  lea r12, [rax+0x50]
0000740ecffd5952  movups xmm11, [r13+r12*1]
0000740ecffd5958  lea r12, [rax+0x60]
0000740ecffd595c  movups xmm10, [r13+r12*1]
0000740ecffd5962  lea r12, [rax+0x30]
0000740ecffd5966  movups xmm9, [r13+r12*1]
0000740ecffd596c  mov r12, [r15+0x50]
0000740ecffd5970  lea r11, [r12+r14*1]
0000740ecffd5974  mov [r15+0x60], r11
0000740ecffd5978  lea r12, [r14+0x40]
0000740ecffd597c  mov [r15+0x58], r12
0000740ecffd5980  movaps xmm8, xmm12
0000740ecffd5984  mulpd xmm8, xmm15
0000740ecffd5989  vcmppd xmm7, xmm8, xmm8, 0x03
0000740ecffd598f  ptest xmm7, xmm7
0000740ecffd5994  jnz 0x0000740ECFFD67B7
0000740ecffd599a  movq xmm15, qword ptr [r15+0x230]
0000740ecffd59a3  vmovaps [rsp+0x70], xmm15
0000740ecffd59a9  vpermilpd xmm15, xmm15, 0x00
0000740ecffd59af  movaps xmm7, xmm9
0000740ecffd59b3  mulpd xmm7, xmm15
0000740ecffd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
0000740ecffd59bd  ptest xmm6, xmm6
0000740ecffd59c2  jnz 0x0000740ECFFD68FB
0000740ecffd59c8  vxorps xmm15, xmm15, xmm15
0000740ecffd59cd  vpbroadcastq xmm15, xmm15
0000740ecffd59d2  movaps xmm9, xmm12
0000740ecffd59d6  mulpd xmm9, xmm10
0000740ecffd59db  vcmppd xmm6, xmm9, xmm9, 0x03
0000740ecffd59e1  ptest xmm6, xmm6
0000740ecffd59e6  jnz 0x0000740ECFFD6A3D
0000740ecffd59ec  movaps xmm10, xmm12
0000740ecffd59f0  mulpd xmm10, xmm11
0000740ecffd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
0000740ecffd59fb  ptest xmm6, xmm6
0000740ecffd5a00  jnz 0x0000740ECFFD6B81
0000740ecffd5a06  movaps xmm11, [r15+0x1F0]
0000740ecffd5a0e  movaps xmm6, xmm12
0000740ecffd5a12  mulpd xmm6, xmm11
0000740ecffd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
0000740ecffd5a1c  ptest xmm5, xmm5
0000740ecffd5a21  jnz 0x0000740ECFFD6CC5
0000740ecffd5a27  movaps xmm12, [r15+0x2A0]
0000740ecffd5a2f  vmovaps [rsp+0x80], xmm12
0000740ecffd5a38  vmovaps xmm11, [rsp+0x80]
0000740ecffd5a41  por xmm12, xmm11
0000740ecffd5a46  movaps xmm11, [r15+0x250]
0000740ecffd5a4e  vmovaps [rsp+0x80], xmm11
0000740ecffd5a57  vmovaps xmm5, [rsp+0x80]
0000740ecffd5a60  por xmm11, xmm5
0000740ecffd5a65  vmovaps xmm4, [rsp+0x70]
0000740ecffd5a6b  vpermilpd xmm4, xmm4, 0x00
0000740ecffd5a71  movaps xmm3, xmm5
0000740ecffd5a74  mulpd xmm3, xmm4
0000740ecffd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
0000740ecffd5a7d  ptest xmm2, xmm2
0000740ecffd5a82  jnz 0x0000740ECFFD6E07
0000740ecffd5a88  mov [rsp+0x80], rax
0000740ecffd5a90  xor eax, eax
0000740ecffd5a92  mov r14d, 0x200
0000740ecffd5a98  cmp r12, r14
0000740ecffd5a9b  cmc
0000740ecffd5a9c  lahf
0000740ecffd5a9d  seto al
0000740ecffd5aa0  mov [r15+0x108], eax
0000740ecffd5aa7  movaps xmm5, xmm8
0000740ecffd5aab  addpd xmm5, xmm15
0000740ecffd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
0000740ecffd5ab5  ptest xmm4, xmm4
0000740ecffd5aba  jnz 0x0000740ECFFD6F47
0000740ecffd5ac0  movaps xmm8, [r15+0x1B0]
0000740ecffd5ac8  movaps xmm4, xmm9
0000740ecffd5acc  addpd xmm4, xmm8
0000740ecffd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
0000740ecffd5ad6  ptest xmm2, xmm2
0000740ecffd5adb  jnz 0x0000740ECFFD7089
0000740ecffd5ae1  movaps xmm9, xmm10
0000740ecffd5ae5  addpd xmm9, xmm8
0000740ecffd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
0000740ecffd5af0  ptest xmm2, xmm2
0000740ecffd5af5  jnz 0x0000740ECFFD71CB
0000740ecffd5afb  movaps xmm10, [r15+0x2F0]
0000740ecffd5b03  vmovaps [rsp+0x90], xmm10
0000740ecffd5b0c  vmovaps xmm8, [rsp+0x90]
0000740ecffd5b15  por xmm10, xmm8
0000740ecffd5b1a  movaps xmm8, [r15+0x2E0]
0000740ecffd5b22  vmovaps [rsp+0x90], xmm8
0000740ecffd5b2b  vmovaps xmm2, [rsp+0x90]
0000740ecffd5b34  por xmm8, xmm2
0000740ecffd5b39  movaps xmm2, [r15+0x2D0]
0000740ecffd5b41  vmovaps [rsp+0x90], xmm2
0000740ecffd5b4a  vmovaps [rsp+0xA0], xmm1
0000740ecffd5b53  vmovaps xmm1, [rsp+0x90]
0000740ecffd5b5c  por xmm2, xmm1
0000740ecffd5b60  movaps xmm1, [r15+0x200]
0000740ecffd5b68  vmovaps [rsp+0x90], xmm1
0000740ecffd5b71  vmovaps [rsp+0xB0], xmm15
0000740ecffd5b7a  vmovaps xmm15, [rsp+0x90]
0000740ecffd5b83  por xmm1, xmm15
0000740ecffd5b88  movaps xmm15, [r15+0x1C0]
0000740ecffd5b90  vmovaps [rsp+0x90], xmm15
0000740ecffd5b99  vmovaps [rsp+0xC0], xmm1
0000740ecffd5ba2  vmovaps xmm1, [rsp+0x90]
0000740ecffd5bab  por xmm15, xmm1
0000740ecffd5bb0  movaps xmm1, [r15+0x190]
0000740ecffd5bb8  vmovaps [rsp+0x90], xmm1
0000740ecffd5bc1  vmovaps [rsp+0xD0], xmm15
0000740ecffd5bca  vmovaps xmm15, [rsp+0x90]
0000740ecffd5bd3  por xmm1, xmm15
0000740ecffd5bd8  movaps xmm15, [r15+0x300]
0000740ecffd5be0  vmovaps [rsp+0x90], xmm15
0000740ecffd5be9  vmovaps [rsp+0xE0], xmm1
0000740ecffd5bf2  vmovaps xmm1, [rsp+0x90]
0000740ecffd5bfb  por xmm15, xmm1
0000740ecffd5c00  mov rax, [rsp+0x80]
0000740ecffd5c08  lea r14, [rax+0xA0]
0000740ecffd5c0f  movups xmm1, [r13+r14*1]
0000740ecffd5c15  lea r14, [rax+0xB0]
0000740ecffd5c1c  vmovaps [rsp+0x80], xmm1
0000740ecffd5c25  movups xmm1, [r13+r14*1]
0000740ecffd5c2b  vmovaps [rsp+0x90], xmm1
0000740ecffd5c34  vmovaps [rsp+0xF0], xmm15
0000740ecffd5c3d  vmovaps xmm15, [rsp+0xB0]
0000740ecffd5c46  vmovaps [rsp+0xB0], xmm14
0000740ecffd5c4f  movaps xmm1, xmm6
0000740ecffd5c52  addpd xmm1, xmm15
0000740ecffd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
0000740ecffd5c5c  ptest xmm14, xmm14
0000740ecffd5c62  jnz 0x0000740ECFFD7323
0000740ecffd5c68  lea r14, [rax+0xF0]
0000740ecffd5c6f  movups xmm15, [r13+r14*1]
0000740ecffd5c75  movaps xmm14, xmm4
0000740ecffd5c79  addpd xmm14, xmm3
0000740ecffd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
0000740ecffd5c84  ptest xmm6, xmm6
0000740ecffd5c89  jnz 0x0000740ECFFD746E
0000740ecffd5c8f  movaps xmm6, xmm9
0000740ecffd5c93  addpd xmm6, xmm7
0000740ecffd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
0000740ecffd5c9c  ptest xmm4, xmm4
0000740ecffd5ca1  jnz 0x0000740ECFFD75B0
0000740ecffd5ca7  vmovaps xmm9, [rsp+0x70]
0000740ecffd5cad  vpermilpd xmm9, xmm9, 0x00
0000740ecffd5cb3  vmovaps xmm4, [rsp+0x90]
0000740ecffd5cbc  movaps xmm7, xmm4
0000740ecffd5cbf  mulpd xmm7, xmm9
0000740ecffd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
0000740ecffd5cc9  ptest xmm3, xmm3
0000740ecffd5cce  jnz 0x0000740ECFFD76F1
0000740ecffd5cd4  vmovaps xmm9, [rsp+0x50]
0000740ecffd5cda  vpermilpd xmm9, xmm9, 0x00
0000740ecffd5ce0  movaps xmm4, xmm15
0000740ecffd5ce4  mulpd xmm4, xmm9
0000740ecffd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
0000740ecffd5cee  ptest xmm3, xmm3
0000740ecffd5cf3  jnz 0x0000740ECFFD7832
0000740ecffd5cf9  lea r14, [rax+0xE0]
0000740ecffd5d00  movups xmm15, [r13+r14*1]
0000740ecffd5d06  vmovaps xmm9, [rsp+0x70]
0000740ecffd5d0c  vpermilpd xmm9, xmm9, 0x00
0000740ecffd5d12  vmovaps [rsp+0x70], xmm1
0000740ecffd5d18  vmovaps xmm1, [rsp+0x80]
0000740ecffd5d21  vmovaps [rsp+0x80], xmm15
0000740ecffd5d2a  movaps xmm3, xmm1
0000740ecffd5d2d  mulpd xmm3, xmm9
0000740ecffd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
0000740ecffd5d37  ptest xmm15, xmm15
0000740ecffd5d3d  jnz 0x0000740ECFFD797E
0000740ecffd5d43  vmovaps xmm1, [rsp+0xF0]
0000740ecffd5d4c  vmovaps xmm15, [rsp+0xF0]
0000740ecffd5d55  por xmm1, xmm15
0000740ecffd5d5a  movaps [r15+0x300], xmm1
0000740ecffd5d62  vmovaps xmm15, [rsp+0xE0]
0000740ecffd5d6b  vmovaps xmm9, [rsp+0xE0]
0000740ecffd5d74  por xmm15, xmm9
0000740ecffd5d79  movaps [r15+0x190], xmm15
0000740ecffd5d81  vmovaps xmm9, [rsp+0x50]
0000740ecffd5d87  vpermilpd xmm9, xmm9, 0x00
0000740ecffd5d8d  vmovaps [rsp+0x90], xmm1
0000740ecffd5d96  vmovaps [rsp+0xE0], xmm15
0000740ecffd5d9f  vmovaps xmm15, [rsp+0x80]
0000740ecffd5da8  vmovaps [rsp+0x80], xmm14
0000740ecffd5db1  movaps xmm1, xmm15
0000740ecffd5db5  mulpd xmm1, xmm9
0000740ecffd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
0000740ecffd5dbf  ptest xmm14, xmm14
0000740ecffd5dc5  jnz 0x0000740ECFFD7ABF
0000740ecffd5dcb  lea r14, [rax+0x90]
0000740ecffd5dd2  movups xmm15, [r13+r14*1]
0000740ecffd5dd8  vmovaps xmm14, [rsp+0xD0]
0000740ecffd5de1  vmovaps xmm9, [rsp+0xD0]
0000740ecffd5dea  por xmm14, xmm9
0000740ecffd5def  movaps [r15+0x1C0], xmm14
0000740ecffd5df7  vmovaps xmm9, [rsp+0xC0]
0000740ecffd5e00  vmovaps [rsp+0xD0], xmm1
0000740ecffd5e09  vmovaps xmm1, [rsp+0xC0]
0000740ecffd5e12  por xmm9, xmm1
0000740ecffd5e17  movaps [r15+0x200], xmm9
0000740ecffd5e1f  vmovaps [rsp+0xC0], xmm2
0000740ecffd5e28  vmovaps xmm1, [rsp+0xC0]
0000740ecffd5e31  por xmm2, xmm1
0000740ecffd5e35  movaps [r15+0x2D0], xmm2
0000740ecffd5e3d  vmovaps [rsp+0xC0], xmm8
0000740ecffd5e46  vmovaps xmm1, [rsp+0xC0]
0000740ecffd5e4f  por xmm8, xmm1
0000740ecffd5e54  movaps [r15+0x2E0], xmm8
0000740ecffd5e5c  vmovaps [rsp+0xC0], xmm15
0000740ecffd5e65  movaps xmm1, xmm5
0000740ecffd5e68  addpd xmm1, xmm7
0000740ecffd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
0000740ecffd5e71  ptest xmm15, xmm15
0000740ecffd5e77  jnz 0x0000740ECFFD7C0B
0000740ecffd5e7d  vmovaps xmm15, [rsp+0x50]
0000740ecffd5e83  vpermilpd xmm15, xmm15, 0x00
0000740ecffd5e89  vmovaps xmm5, [rsp+0xC0]
0000740ecffd5e92  vmovaps [rsp+0xC0], xmm1
0000740ecffd5e9b  movaps xmm7, xmm5
0000740ecffd5e9e  mulpd xmm7, xmm15
0000740ecffd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
0000740ecffd5ea8  ptest xmm1, xmm1
0000740ecffd5ead  jnz 0x0000740ECFFD7D4B
0000740ecffd5eb3  lea r14, [rax+0x80]
0000740ecffd5eba  movups xmm1, [r13+r14*1]
0000740ecffd5ec0  vmovaps xmm5, [rsp+0x70]
0000740ecffd5ec6  vmovaps [rsp+0x70], xmm1
0000740ecffd5ecc  movaps xmm15, xmm5
0000740ecffd5ed0  addpd xmm15, xmm3
0000740ecffd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
0000740ecffd5edb  ptest xmm1, xmm1
0000740ecffd5ee0  jnz 0x0000740ECFFD7E96
0000740ecffd5ee6  vmovaps xmm5, [rsp+0x80]
0000740ecffd5eef  movaps xmm1, xmm5
0000740ecffd5ef2  addpd xmm1, xmm4
0000740ecffd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
0000740ecffd5efb  ptest xmm3, xmm3
0000740ecffd5f00  jnz 0x0000740ECFFD7FD8
0000740ecffd5f06  vmovaps [rsp+0x80], xmm10
0000740ecffd5f0f  vmovaps xmm5, [rsp+0x80]
0000740ecffd5f18  por xmm10, xmm5
0000740ecffd5f1d  movaps [r15+0x2F0], xmm10
0000740ecffd5f25  vmovaps xmm5, [rsp+0x50]
0000740ecffd5f2b  vpermilpd xmm5, xmm5, 0x00
0000740ecffd5f31  vmovaps xmm3, [rsp+0x70]
0000740ecffd5f37  vmovaps [rsp+0x50], xmm1
0000740ecffd5f3d  movaps xmm4, xmm3
0000740ecffd5f40  mulpd xmm4, xmm5
0000740ecffd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
0000740ecffd5f49  ptest xmm1, xmm1
0000740ecffd5f4e  jnz 0x0000740ECFFD8118
0000740ecffd5f54  lea r14, [rax+0xD0]
0000740ecffd5f5b  movups xmm1, [r13+r14*1]
0000740ecffd5f61  vmovaps xmm3, [rsp+0xD0]
0000740ecffd5f6a  vmovaps [rsp+0x70], xmm1
0000740ecffd5f70  movaps xmm5, xmm6
0000740ecffd5f73  addpd xmm5, xmm3
0000740ecffd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
0000740ecffd5f7c  ptest xmm1, xmm1
0000740ecffd5f81  jnz 0x0000740ECFFD8262
0000740ecffd5f87  vmovaps xmm1, [rsp+0x60]
0000740ecffd5f8d  vpermilpd xmm1, xmm1, 0x00
0000740ecffd5f93  movaps xmm6, xmm9
0000740ecffd5f97  mulpd xmm6, xmm1
0000740ecffd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
0000740ecffd5fa0  ptest xmm3, xmm3
0000740ecffd5fa5  jnz 0x0000740ECFFD83A2
0000740ecffd5fab  movaps [r15+0x260], xmm6
0000740ecffd5fb3  vxorps xmm1, xmm1, xmm1
0000740ecffd5fb7  vpbroadcastq xmm1, xmm1
0000740ecffd5fbc  movaps [r15+0x1B0], xmm1
0000740ecffd5fc4  vmovaps xmm1, [rsp+0x60]
0000740ecffd5fca  vpermilpd xmm1, xmm1, 0x00
0000740ecffd5fd0  vmovaps xmm3, [rsp+0x70]
0000740ecffd5fd6  vmovaps [rsp+0x70], xmm15
0000740ecffd5fdc  movaps xmm9, xmm3
0000740ecffd5fe0  mulpd xmm9, xmm1
0000740ecffd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
0000740ecffd5feb  ptest xmm15, xmm15
0000740ecffd5ff1  jnz 0x0000740ECFFD84E3
0000740ecffd5ff7  lea r14, [rax+0xC0]
0000740ecffd5ffe  movups xmm1, [r13+r14*1]
0000740ecffd6004  vmovaps xmm3, [rsp+0xC0]
0000740ecffd600d  vmovaps [rsp+0x80], xmm1
0000740ecffd6016  movaps xmm15, xmm3
0000740ecffd601a  addpd xmm15, xmm7
0000740ecffd601f  vcmppd xmm1, xmm15, xmm15, 0x03
0000740ecffd6025  ptest xmm1, xmm1
0000740ecffd602a  jnz 0x0000740ECFFD862F
0000740ecffd6030  vmovaps [rsp+0xC0], xmm13
0000740ecffd6039  vmovaps xmm1, [rsp+0xC0]
0000740ecffd6042  por xmm13, xmm1
0000740ecffd6047  movaps [r15+0x270], xmm13
0000740ecffd604f  vmovaps xmm1, [rsp+0xB0]
0000740ecffd6058  vmovaps xmm7, [rsp+0xB0]
0000740ecffd6061  por xmm1, xmm7
0000740ecffd6065  movaps [r15+0x1A0], xmm1
0000740ecffd606d  vmovaps xmm1, [rsp+0x60]
0000740ecffd6073  vpermilpd xmm1, xmm1, 0x00
0000740ecffd6079  vmovaps [rsp+0xB0], xmm1
0000740ecffd6082  vmovaps xmm1, [rsp+0x80]
0000740ecffd608b  vmovaps [rsp+0x80], xmm15
0000740ecffd6094  vmovaps xmm15, [rsp+0xB0]
0000740ecffd609d  vmovaps [rsp+0xB0], xmm14
0000740ecffd60a6  movaps xmm3, xmm1
0000740ecffd60a9  mulpd xmm3, xmm15
0000740ecffd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
0000740ecffd60b3  ptest xmm14, xmm14
0000740ecffd60b9  jnz 0x0000740ECFFD8771
0000740ecffd60bf  lea r14, [rax+0x20]
0000740ecffd60c3  movups xmm1, [r13+r14*1]
0000740ecffd60c9  movaps [r15+0x110], xmm1
0000740ecffd60d1  vmovaps xmm14, [rsp+0x70]
0000740ecffd60d7  vmovaps [rsp+0x70], xmm1
0000740ecffd60dd  movaps xmm15, xmm14
0000740ecffd60e1  addpd xmm15, xmm4
0000740ecffd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
0000740ecffd60ec  ptest xmm1, xmm1
0000740ecffd60f1  jnz 0x0000740ECFFD88BC
0000740ecffd60f7  vmovaps xmm1, [rsp+0x60]
0000740ecffd60fd  vpermilpd xmm1, xmm1, 0x00
0000740ecffd6103  movaps xmm14, xmm2
0000740ecffd6107  mulpd xmm14, xmm1
0000740ecffd610c  vcmppd xmm4, xmm14, xmm14, 0x03
0000740ecffd6112  ptest xmm4, xmm4
0000740ecffd6117  jnz 0x0000740ECFFD89FF
0000740ecffd611d  vmovaps xmm4, [rsp+0x50]
0000740ecffd6123  movaps xmm1, xmm4
0000740ecffd6126  addpd xmm1, xmm9
0000740ecffd612b  vcmppd xmm2, xmm1, xmm1, 0x03
0000740ecffd6130  ptest xmm2, xmm2
0000740ecffd6135  jnz 0x0000740ECFFD8B41
0000740ecffd613b  vmovaps xmm9, [rsp+0x30]
0000740ecffd6141  vpermilpd xmm9, xmm9, 0x00
0000740ecffd6147  vmovaps xmm2, [rsp+0x70]
0000740ecffd614d  vmovaps [rsp+0x50], xmm1
0000740ecffd6153  movaps xmm4, xmm2
0000740ecffd6156  mulpd xmm4, xmm9
0000740ecffd615b  vcmppd xmm1, xmm4, xmm4, 0x03
0000740ecffd6160  ptest xmm1, xmm1
0000740ecffd6165  jnz 0x0000740ECFFD8C82
0000740ecffd616b  vmovaps xmm1, [rsp+0x30]
0000740ecffd6171  vpermilpd xmm1, xmm1, 0x00
0000740ecffd6177  vmovaps xmm2, [rsp+0x90]
0000740ecffd6180  vmovaps [rsp+0x60], xmm15
0000740ecffd6186  movaps xmm9, xmm2
0000740ecffd618a  mulpd xmm9, xmm1
0000740ecffd618f  vcmppd xmm15, xmm9, xmm9, 0x03
0000740ecffd6195  ptest xmm15, xmm15
0000740ecffd619b  jnz 0x0000740ECFFD8DC3
0000740ecffd61a1  vmovaps xmm15, [rsp+0x80]
0000740ecffd61aa  movaps xmm1, xmm15
0000740ecffd61ae  addpd xmm1, xmm6
0000740ecffd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
0000740ecffd61b7  ptest xmm2, xmm2
0000740ecffd61bc  jnz 0x0000740ECFFD8F05
0000740ecffd61c2  movaps xmm15, xmm5
0000740ecffd61c6  addpd xmm15, xmm3
0000740ecffd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
0000740ecffd61d1  ptest xmm6, xmm6
0000740ecffd61d6  jnz 0x0000740ECFFD9046
0000740ecffd61dc  vmovaps xmm6, [rsp+0x30]
0000740ecffd61e2  vpermilpd xmm6, xmm6, 0x00
0000740ecffd61e8  movaps xmm5, xmm8
0000740ecffd61ec  mulpd xmm5, xmm6
0000740ecffd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
0000740ecffd61f5  ptest xmm3, xmm3
0000740ecffd61fa  jnz 0x0000740ECFFD9188
0000740ecffd6200  vmovaps xmm8, [rsp+0x30]
0000740ecffd6206  vpermilpd xmm8, xmm8, 0x00
0000740ecffd620c  movaps xmm6, xmm10
0000740ecffd6210  mulpd xmm6, xmm8
0000740ecffd6215  vcmppd xmm3, xmm6, xmm6, 0x03
0000740ecffd621a  ptest xmm3, xmm3
0000740ecffd621f  jnz 0x0000740ECFFD92C9
0000740ecffd6225  vmovaps xmm8, [rsp+0x60]
0000740ecffd622b  movaps xmm10, xmm8
0000740ecffd622f  addpd xmm10, xmm14
0000740ecffd6234  vcmppd xmm3, xmm10, xmm10, 0x03
0000740ecffd623a  ptest xmm3, xmm3
0000740ecffd623f  jnz 0x0000740ECFFD940B
0000740ecffd6245  vmovaps xmm8, [rsp+0x50]
0000740ecffd624b  movaps xmm14, xmm8
0000740ecffd624f  addpd xmm14, xmm4
0000740ecffd6254  vcmppd xmm3, xmm14, xmm14, 0x03
0000740ecffd625a  ptest xmm3, xmm3
0000740ecffd625f  jnz 0x0000740ECFFD954F
0000740ecffd6265  vmovaps xmm8, [rsp+0x40]
0000740ecffd626b  vpermilpd xmm8, xmm8, 0x00
0000740ecffd6271  movaps xmm4, xmm13
0000740ecffd6275  mulpd xmm4, xmm8
0000740ecffd627a  vcmppd xmm3, xmm4, xmm4, 0x03
0000740ecffd627f  ptest xmm3, xmm3
0000740ecffd6284  jnz 0x0000740ECFFD9692
0000740ecffd628a  movaps xmm13, xmm15
0000740ecffd628e  addpd xmm13, xmm9
0000740ecffd6293  vcmppd xmm8, xmm13, xmm13, 0x03
0000740ecffd6299  ptest xmm8, xmm8
0000740ecffd629f  jnz 0x0000740ECFFD97D4
0000740ecffd62a5  movaps xmm15, xmm1
0000740ecffd62a9  addpd xmm15, xmm5
0000740ecffd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
0000740ecffd62b4  ptest xmm9, xmm9
0000740ecffd62ba  jnz 0x0000740ECFFD9918
0000740ecffd62c0  vmovaps [rsp+0x30], xmm11
0000740ecffd62c6  vmovaps xmm1, [rsp+0x30]
0000740ecffd62cc  por xmm11, xmm1
0000740ecffd62d1  movaps [r15+0x250], xmm11
0000740ecffd62d9  vmovaps [rsp+0x30], xmm12
0000740ecffd62df  vmovaps xmm1, [rsp+0x30]
0000740ecffd62e5  por xmm12, xmm1
0000740ecffd62ea  movaps [r15+0x2A0], xmm12
0000740ecffd62f2  vmovaps xmm1, [rsp+0xA0]
0000740ecffd62fb  vmovaps xmm11, [rsp+0xA0]
0000740ecffd6304  por xmm1, xmm11
0000740ecffd6309  movaps [r15+0x1D0], xmm1
0000740ecffd6311  lea r14, [rax+0x40]
0000740ecffd6315  movups xmm1, [r13+r14*1]
0000740ecffd631b  movaps [r15+0x2C0], xmm1
0000740ecffd6323  vmovaps xmm11, [rsp+0x40]
0000740ecffd6329  vpermilpd xmm11, xmm11, 0x00
0000740ecffd632f  vmovaps xmm8, [rsp+0xE0]
0000740ecffd6338  movaps xmm9, xmm8
0000740ecffd633c  mulpd xmm9, xmm11
0000740ecffd6341  vcmppd xmm5, xmm9, xmm9, 0x03
0000740ecffd6347  ptest xmm5, xmm5
0000740ecffd634c  jnz 0x0000740ECFFD9A64
0000740ecffd6352  movaps xmm11, xmm10
0000740ecffd6356  addpd xmm11, xmm6
0000740ecffd635b  vcmppd xmm8, xmm11, xmm11, 0x03
0000740ecffd6361  ptest xmm8, xmm8
0000740ecffd6367  jnz 0x0000740ECFFD9BA8
0000740ecffd636d  movaps xmm10, xmm14
0000740ecffd6371  addpd xmm10, xmm4
0000740ecffd6376  vcmppd xmm8, xmm10, xmm10, 0x03
0000740ecffd637c  ptest xmm8, xmm8
0000740ecffd6382  jnz 0x0000740ECFFD9CEB
0000740ecffd6388  vmovaps xmm14, [rsp+0x40]
0000740ecffd638e  vpermilpd xmm14, xmm14, 0x00
0000740ecffd6394  movaps xmm8, xmm1
0000740ecffd6398  mulpd xmm8, xmm14
0000740ecffd639d  vcmppd xmm6, xmm8, xmm8, 0x03
0000740ecffd63a3  ptest xmm6, xmm6
0000740ecffd63a8  jnz 0x0000740ECFFD9E2E
0000740ecffd63ae  movaps xmm1, [r15+0x2B0]
0000740ecffd63b6  vmovaps xmm14, [rsp+0x40]
0000740ecffd63bc  vpermilpd xmm14, xmm14, 0x00
0000740ecffd63c2  movaps xmm6, xmm1
0000740ecffd63c5  mulpd xmm6, xmm14
0000740ecffd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
0000740ecffd63cf  ptest xmm5, xmm5
0000740ecffd63d4  jnz 0x0000740ECFFD9F71
0000740ecffd63da  vmovaps xmm1, [rsp+0x10]
0000740ecffd63e0  vpermilpd xmm1, xmm1, 0x00
0000740ecffd63e6  movaps xmm14, xmm12
0000740ecffd63ea  mulpd xmm14, xmm1
0000740ecffd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
0000740ecffd63f5  ptest xmm5, xmm5
0000740ecffd63fa  jnz 0x0000740ECFFDA0B2
0000740ecffd6400  movaps xmm1, xmm13
0000740ecffd6404  addpd xmm1, xmm9
0000740ecffd6409  vcmppd xmm12, xmm1, xmm1, 0x03
0000740ecffd640e  ptest xmm12, xmm12
0000740ecffd6414  jnz 0x0000740ECFFDA1F5
0000740ecffd641a  vmovaps xmm13, [rsp+0x10]
0000740ecffd6420  vpermilpd xmm13, xmm13, 0x00
0000740ecffd6426  movaps xmm12, xmm7
0000740ecffd642a  mulpd xmm12, xmm13
0000740ecffd642f  vcmppd xmm9, xmm12, xmm12, 0x03
0000740ecffd6435  ptest xmm9, xmm9
0000740ecffd643b  jnz 0x0000740ECFFDA337
0000740ecffd6441  movaps xmm13, xmm15
0000740ecffd6445  addpd xmm13, xmm8
0000740ecffd644a  vcmppd xmm9, xmm13, xmm13, 0x03
0000740ecffd6450  ptest xmm9, xmm9
0000740ecffd6456  jnz 0x0000740ECFFDA47A
0000740ecffd645c  movaps xmm15, [r15+0x290]
0000740ecffd6464  vmovaps xmm9, [rsp+0x10]
0000740ecffd646a  vpermilpd xmm9, xmm9, 0x00
0000740ecffd6470  movaps xmm8, xmm15
0000740ecffd6474  mulpd xmm8, xmm9
0000740ecffd6479  vcmppd xmm7, xmm8, xmm8, 0x03
0000740ecffd647f  ptest xmm7, xmm7
0000740ecffd6484  jnz 0x0000740ECFFDA5BE
0000740ecffd648a  movaps xmm15, xmm11
0000740ecffd648e  addpd xmm15, xmm6
0000740ecffd6493  vcmppd xmm9, xmm15, xmm15, 0x03
0000740ecffd6499  ptest xmm9, xmm9
0000740ecffd649f  jnz 0x0000740ECFFDA702
0000740ecffd64a5  movaps xmm11, [r15+0x1E0]
0000740ecffd64ad  vmovaps xmm9, [rsp+0x10]
0000740ecffd64b3  vpermilpd xmm9, xmm9, 0x00
0000740ecffd64b9  movaps xmm7, xmm11
0000740ecffd64bd  mulpd xmm7, xmm9
0000740ecffd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
0000740ecffd64c7  ptest xmm6, xmm6
0000740ecffd64cc  jnz 0x0000740ECFFDA845
0000740ecffd64d2  movaps xmm11, xmm10
0000740ecffd64d6  addpd xmm11, xmm14
0000740ecffd64db  vcmppd xmm9, xmm11, xmm11, 0x03
0000740ecffd64e1  ptest xmm9, xmm9
0000740ecffd64e7  jnz 0x0000740ECFFDA987
0000740ecffd64ed  lea r14, [rax+0x70]
0000740ecffd64f1  movups xmm14, [r13+r14*1]
0000740ecffd64f7  movaps [r15+0x240], xmm14
0000740ecffd64ff  movaps xmm10, xmm1
0000740ecffd6503  addpd xmm10, xmm12
0000740ecffd6508  vcmppd xmm9, xmm10, xmm10, 0x03
0000740ecffd650e  ptest xmm9, xmm9
0000740ecffd6514  jnz 0x0000740ECFFDAAD5
0000740ecffd651a  movaps [r15+0x170], xmm10
0000740ecffd6522  vmovaps xmm1, [rsp+0x20]
0000740ecffd6528  vpermilpd xmm1, xmm1, 0x00
0000740ecffd652e  movaps xmm12, xmm14
0000740ecffd6532  mulpd xmm12, xmm1
0000740ecffd6537  vcmppd xmm9, xmm12, xmm12, 0x03
0000740ecffd653d  ptest xmm9, xmm9
0000740ecffd6543  jnz 0x0000740ECFFDAC18
0000740ecffd6549  vmovaps xmm1, [rsp+0x20]
0000740ecffd654f  vpermilpd xmm1, xmm1, 0x00
0000740ecffd6555  vmovaps xmm9, [rsp+0xB0]
0000740ecffd655e  movaps xmm14, xmm9
0000740ecffd6562  mulpd xmm14, xmm1
0000740ecffd6567  vcmppd xmm6, xmm14, xmm14, 0x03
0000740ecffd656d  ptest xmm6, xmm6
0000740ecffd6572  jnz 0x0000740ECFFDAD5B
0000740ecffd6578  movaps [r15+0x180], xmm14
0000740ecffd6580  movaps xmm1, xmm13
0000740ecffd6584  addpd xmm1, xmm8
0000740ecffd6589  vcmppd xmm9, xmm1, xmm1, 0x03
0000740ecffd658e  ptest xmm9, xmm9
0000740ecffd6594  jnz 0x0000740ECFFDAE9E
0000740ecffd659a  movaps [r15+0x210], xmm1
0000740ecffd65a2  movups xmm13, [r13+rax*1]
0000740ecffd65a8  lea r14, [rax+0x10]
0000740ecffd65ac  movups xmm9, [r13+r14*1]
0000740ecffd65b2  movaps [r15+0x230], xmm9
0000740ecffd65ba  movaps xmm8, xmm15
0000740ecffd65be  addpd xmm8, xmm7
0000740ecffd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
0000740ecffd65c9  ptest xmm6, xmm6
0000740ecffd65ce  jnz 0x0000740ECFFDAFF4
0000740ecffd65d4  movaps [r15+0x130], xmm8
0000740ecffd65dc  vmovaps xmm15, [rsp+0x20]
0000740ecffd65e2  vpermilpd xmm15, xmm15, 0x00
0000740ecffd65e8  movaps xmm7, xmm9
0000740ecffd65ec  mulpd xmm7, xmm15
0000740ecffd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
0000740ecffd65f6  ptest xmm6, xmm6
0000740ecffd65fb  jnz 0x0000740ECFFDB137
0000740ecffd6601  movaps [r15+0x220], xmm7
0000740ecffd6609  vmovaps xmm15, [rsp+0x20]
0000740ecffd660f  vpermilpd xmm15, xmm15, 0x00
0000740ecffd6615  movaps xmm9, xmm13
0000740ecffd6619  mulpd xmm9, xmm15
0000740ecffd661e  vcmppd xmm6, xmm9, xmm9, 0x03
0000740ecffd6624  ptest xmm6, xmm6
0000740ecffd6629  jnz 0x0000740ECFFDB279
0000740ecffd662f  movaps xmm15, xmm11
0000740ecffd6633  addpd xmm15, xmm12
0000740ecffd6638  vcmppd xmm13, xmm15, xmm15, 0x03
0000740ecffd663e  ptest xmm13, xmm13
0000740ecffd6644  jnz 0x0000740ECFFDB3BD
0000740ecffd664a  movaps [r15+0x140], xmm15
0000740ecffd6652  movaps xmm13, xmm10
0000740ecffd6656  addpd xmm13, xmm14
0000740ecffd665b  vcmppd xmm12, xmm13, xmm13, 0x03
0000740ecffd6661  ptest xmm12, xmm12
0000740ecffd6667  jnz 0x0000740ECFFDB501
0000740ecffd666d  movaps [r15+0x150], xmm13
0000740ecffd6675  movaps xmm14, xmm1
0000740ecffd6679  addpd xmm14, xmm7
0000740ecffd667e  vcmppd xmm12, xmm14, xmm14, 0x03
0000740ecffd6684  ptest xmm12, xmm12
0000740ecffd668a  jnz 0x0000740ECFFDB645
0000740ecffd6690  movaps [r15+0x160], xmm14
0000740ecffd6698  movaps xmm1, xmm8
0000740ecffd669c  addpd xmm1, xmm9
0000740ecffd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
0000740ecffd66a6  ptest xmm12, xmm12
0000740ecffd66ac  jnz 0x0000740ECFFDB787
0000740ecffd66b2  movaps [r15+0x120], xmm1
0000740ecffd66ba  movups [r13+r11*1], xmm15
0000740ecffd66c0  lea rax, [r11+0x10]
0000740ecffd66c4  movups [r13+rax*1], xmm13
0000740ecffd66ca  lea rax, [r11+0x20]
0000740ecffd66ce  movups [r13+rax*1], xmm14
0000740ecffd66d4  lea rax, [r11+0x30]
0000740ecffd66d8  movups [r13+rax*1], xmm1
0000740ecffd66de  mov eax, [r15+0x108]
0000740ecffd66e5  sahf
0000740ecffd66e6  jnz 0x0000740ECFFD6718
0000740ecffd66e8  cmp dword ptr [r15+0x318], 0x00
0000740ecffd66f0  jz 0x0000740ECFFDB900
0000740ecffd66f6  nop [rax+rax*1], ax
0000740ecffd66ff  nop [rax+rax*1], eax
0000740ecffd6707  mov eax, 0x410444
0000740ecffd670c  mov [r15+0x100], rax
0000740ecffd6713  jmp 0x0000740ECFDFE110
0000740ecffd6718  cmp dword ptr [r15+0x318], 0x00
0000740ecffd6720  jz 0x0000740ECFFD57E0
0000740ecffd6726  nop [rax+rax*1], ax
0000740ecffd672f  nop [rax+rax*1], eax
0000740ecffd6737  mov eax, 0x410278
0000740ecffd673c  mov [r15+0x100], rax
0000740ecffd6743  jmp 0x0000740ECFDFE110
0000740ecffd6748  int3
0000740ecffd6749  call 0x0000740ECFE0A4B0
0000740ecffd674e  jmp 0x0000740ECFFD5828
0000740ecffd6753  call 0x0000740ECFE09240
0000740ecffd6758  jmp 0x0000740ECFFD5832
0000740ecffd675d  call 0x0000740ECFE0A4B0
0000740ecffd6762  jmp 0x0000740ECFFD588F
0000740ecffd6767  call 0x0000740ECFE09240
0000740ecffd676c  jmp 0x0000740ECFFD5899
0000740ecffd6771  call 0x0000740ECFE0A4B0
0000740ecffd6776  jmp 0x0000740ECFFD58DD
0000740ecffd677b  call 0x0000740ECFE09240
0000740ecffd6780  jmp 0x0000740ECFFD58E7
0000740ecffd6785  call 0x0000740ECFEB47C0
0000740ecffd678a  jmp 0x0000740ECFFD5926
0000740ecffd678f  call 0x0000740ECFE0B720
0000740ecffd6794  jmp 0x0000740ECFFD593A
0000740ecffd6799  call 0x0000740ECFEBFC30
0000740ecffd679e  jmp 0x0000740ECFFD5958
0000740ecffd67a3  call 0x0000740ECFEBE9C0
0000740ecffd67a8  jmp 0x0000740ECFFD5962
0000740ecffd67ad  call 0x0000740ECFEBD750
0000740ecffd67b2  jmp 0x0000740ECFFD596C
0000740ecffd67b7  sub rsp, 0x08
0000740ecffd67bb  push rax
0000740ecffd67bc  push rcx
0000740ecffd67bd  push rdx
0000740ecffd67be  push rdi
0000740ecffd67bf  push rsi
0000740ecffd67c0  push r8
0000740ecffd67c2  push r9
0000740ecffd67c4  push r10
0000740ecffd67c6  push r11
0000740ecffd67c8  sub rsp, 0xF0
0000740ecffd67cf  vmovaps [rsp], xmm0
0000740ecffd67d4  vmovaps [rsp+0x10], xmm1
0000740ecffd67da  vmovaps [rsp+0x20], xmm2
0000740ecffd67e0  vmovaps [rsp+0x30], xmm3
0000740ecffd67e6  vmovaps [rsp+0x40], xmm4
0000740ecffd67ec  vmovaps [rsp+0x50], xmm5
0000740ecffd67f2  vmovaps [rsp+0x60], xmm6
0000740ecffd67f8  vmovaps [rsp+0x70], xmm7
0000740ecffd67fe  vmovaps [rsp+0x80], xmm9
0000740ecffd6807  vmovaps [rsp+0x90], xmm10
0000740ecffd6810  vmovaps [rsp+0xA0], xmm11
0000740ecffd6819  vmovaps [rsp+0xB0], xmm12
0000740ecffd6822  vmovaps [rsp+0xC0], xmm13
0000740ecffd682b  vmovaps [rsp+0xD0], xmm14
0000740ecffd6834  vmovaps [rsp+0xE0], xmm15
0000740ecffd683d  sub rsp, 0x30
0000740ecffd6841  movaps [rsp], xmm8
0000740ecffd6846  movaps [rsp+0x10], xmm12
0000740ecffd684c  movaps [rsp+0x20], xmm15
0000740ecffd6852  lea rdi, [rsp]
0000740ecffd6856  mov esi, 0x00
0000740ecffd685b  mov rax, 0x5E8249CF1530
0000740ecffd6865  call rax
0000740ecffd6867  movaps xmm8, [rsp]
0000740ecffd686c  add rsp, 0x30
0000740ecffd6870  vmovaps xmm0, [rsp]
0000740ecffd6875  vmovaps xmm1, [rsp+0x10]
0000740ecffd687b  vmovaps xmm2, [rsp+0x20]
0000740ecffd6881  vmovaps xmm3, [rsp+0x30]
0000740ecffd6887  vmovaps xmm4, [rsp+0x40]
0000740ecffd688d  vmovaps xmm5, [rsp+0x50]
0000740ecffd6893  vmovaps xmm6, [rsp+0x60]
0000740ecffd6899  vmovaps xmm7, [rsp+0x70]
0000740ecffd689f  vmovaps xmm9, [rsp+0x80]
0000740ecffd68a8  vmovaps xmm10, [rsp+0x90]
0000740ecffd68b1  vmovaps xmm11, [rsp+0xA0]
0000740ecffd68ba  vmovaps xmm12, [rsp+0xB0]
0000740ecffd68c3  vmovaps xmm13, [rsp+0xC0]
0000740ecffd68cc  vmovaps xmm14, [rsp+0xD0]
0000740ecffd68d5  vmovaps xmm15, [rsp+0xE0]
0000740ecffd68de  add rsp, 0xF0
0000740ecffd68e5  pop r11
0000740ecffd68e7  pop r10
0000740ecffd68e9  pop r9
0000740ecffd68eb  pop r8
0000740ecffd68ed  pop rsi
0000740ecffd68ee  pop rdi
0000740ecffd68ef  pop rdx
0000740ecffd68f0  pop rcx
0000740ecffd68f1  pop rax
0000740ecffd68f2  add rsp, 0x08
0000740ecffd68f6  jmp 0x0000740ECFFD599A
0000740ecffd68fb  sub rsp, 0x08
0000740ecffd68ff  push rax
0000740ecffd6900  push rcx
0000740ecffd6901  push rdx
0000740ecffd6902  push rdi
0000740ecffd6903  push rsi
0000740ecffd6904  push r8
0000740ecffd6906  push r9
0000740ecffd6908  push r10
0000740ecffd690a  push r11
0000740ecffd690c  sub rsp, 0xF0
0000740ecffd6913  vmovaps [rsp], xmm0
0000740ecffd6918  vmovaps [rsp+0x10], xmm1
0000740ecffd691e  vmovaps [rsp+0x20], xmm2
0000740ecffd6924  vmovaps [rsp+0x30], xmm3
0000740ecffd692a  vmovaps [rsp+0x40], xmm4
0000740ecffd6930  vmovaps [rsp+0x50], xmm5
0000740ecffd6936  vmovaps [rsp+0x60], xmm6
0000740ecffd693c  vmovaps [rsp+0x70], xmm8
0000740ecffd6942  vmovaps [rsp+0x80], xmm9
0000740ecffd694b  vmovaps [rsp+0x90], xmm10
0000740ecffd6954  vmovaps [rsp+0xA0], xmm11
0000740ecffd695d  vmovaps [rsp+0xB0], xmm12
0000740ecffd6966  vmovaps [rsp+0xC0], xmm13
0000740ecffd696f  vmovaps [rsp+0xD0], xmm14
0000740ecffd6978  vmovaps [rsp+0xE0], xmm15
0000740ecffd6981  sub rsp, 0x30
0000740ecffd6985  movaps [rsp], xmm7
0000740ecffd6989  movaps [rsp+0x10], xmm9
0000740ecffd698f  movaps [rsp+0x20], xmm15
0000740ecffd6995  lea rdi, [rsp]
0000740ecffd6999  mov esi, 0x00
0000740ecffd699e  mov rax, 0x5E8249CF1530
0000740ecffd69a8  call rax
0000740ecffd69aa  movaps xmm7, [rsp]
0000740ecffd69ae  add rsp, 0x30
0000740ecffd69b2  vmovaps xmm0, [rsp]
0000740ecffd69b7  vmovaps xmm1, [rsp+0x10]
0000740ecffd69bd  vmovaps xmm2, [rsp+0x20]
0000740ecffd69c3  vmovaps xmm3, [rsp+0x30]
0000740ecffd69c9  vmovaps xmm4, [rsp+0x40]
0000740ecffd69cf  vmovaps xmm5, [rsp+0x50]
0000740ecffd69d5  vmovaps xmm6, [rsp+0x60]
0000740ecffd69db  vmovaps xmm8, [rsp+0x70]
0000740ecffd69e1  vmovaps xmm9, [rsp+0x80]
0000740ecffd69ea  vmovaps xmm10, [rsp+0x90]
0000740ecffd69f3  vmovaps xmm11, [rsp+0xA0]
0000740ecffd69fc  vmovaps xmm12, [rsp+0xB0]
0000740ecffd6a05  vmovaps xmm13, [rsp+0xC0]
0000740ecffd6a0e  vmovaps xmm14, [rsp+0xD0]
0000740ecffd6a17  vmovaps xmm15, [rsp+0xE0]
0000740ecffd6a20  add rsp, 0xF0
0000740ecffd6a27  pop r11
0000740ecffd6a29  pop r10
0000740ecffd6a2b  pop r9
0000740ecffd6a2d  pop r8
0000740ecffd6a2f  pop rsi
0000740ecffd6a30  pop rdi
0000740ecffd6a31  pop rdx
0000740ecffd6a32  pop rcx
0000740ecffd6a33  pop rax
0000740ecffd6a34  add rsp, 0x08
0000740ecffd6a38  jmp 0x0000740ECFFD59C8
0000740ecffd6a3d  sub rsp, 0x08
0000740ecffd6a41  push rax
0000740ecffd6a42  push rcx
0000740ecffd6a43  push rdx
0000740ecffd6a44  push rdi
0000740ecffd6a45  push rsi
0000740ecffd6a46  push r8
0000740ecffd6a48  push r9
0000740ecffd6a4a  push r10
0000740ecffd6a4c  push r11
0000740ecffd6a4e  sub rsp, 0xF0
0000740ecffd6a55  vmovaps [rsp], xmm0
0000740ecffd6a5a  vmovaps [rsp+0x10], xmm1
0000740ecffd6a60  vmovaps [rsp+0x20], xmm2
0000740ecffd6a66  vmovaps [rsp+0x30], xmm3
0000740ecffd6a6c  vmovaps [rsp+0x40], xmm4
0000740ecffd6a72  vmovaps [rsp+0x50], xmm5
0000740ecffd6a78  vmovaps [rsp+0x60], xmm6
0000740ecffd6a7e  vmovaps [rsp+0x70], xmm7
0000740ecffd6a84  vmovaps [rsp+0x80], xmm8
0000740ecffd6a8d  vmovaps [rsp+0x90], xmm10
0000740ecffd6a96  vmovaps [rsp+0xA0], xmm11
0000740ecffd6a9f  vmovaps [rsp+0xB0], xmm12
0000740ecffd6aa8  vmovaps [rsp+0xC0], xmm13
0000740ecffd6ab1  vmovaps [rsp+0xD0], xmm14
0000740ecffd6aba  vmovaps [rsp+0xE0], xmm15
0000740ecffd6ac3  sub rsp, 0x30
0000740ecffd6ac7  movaps [rsp], xmm9
0000740ecffd6acc  movaps [rsp+0x10], xmm12
0000740ecffd6ad2  movaps [rsp+0x20], xmm10
0000740ecffd6ad8  lea rdi, [rsp]
0000740ecffd6adc  mov esi, 0x00
0000740ecffd6ae1  mov rax, 0x5E8249CF1530
0000740ecffd6aeb  call rax
0000740ecffd6aed  movaps xmm9, [rsp]
0000740ecffd6af2  add rsp, 0x30
0000740ecffd6af6  vmovaps xmm0, [rsp]
0000740ecffd6afb  vmovaps xmm1, [rsp+0x10]
0000740ecffd6b01  vmovaps xmm2, [rsp+0x20]
0000740ecffd6b07  vmovaps xmm3, [rsp+0x30]
0000740ecffd6b0d  vmovaps xmm4, [rsp+0x40]
0000740ecffd6b13  vmovaps xmm5, [rsp+0x50]
0000740ecffd6b19  vmovaps xmm6, [rsp+0x60]
0000740ecffd6b1f  vmovaps xmm7, [rsp+0x70]
0000740ecffd6b25  vmovaps xmm8, [rsp+0x80]
0000740ecffd6b2e  vmovaps xmm10, [rsp+0x90]
0000740ecffd6b37  vmovaps xmm11, [rsp+0xA0]
0000740ecffd6b40  vmovaps xmm12, [rsp+0xB0]
0000740ecffd6b49  vmovaps xmm13, [rsp+0xC0]
0000740ecffd6b52  vmovaps xmm14, [rsp+0xD0]
0000740ecffd6b5b  vmovaps xmm15, [rsp+0xE0]
0000740ecffd6b64  add rsp, 0xF0
0000740ecffd6b6b  pop r11
0000740ecffd6b6d  pop r10
0000740ecffd6b6f  pop r9
0000740ecffd6b71  pop r8
0000740ecffd6b73  pop rsi
0000740ecffd6b74  pop rdi
0000740ecffd6b75  pop rdx
0000740ecffd6b76  pop rcx
0000740ecffd6b77  pop rax
0000740ecffd6b78  add rsp, 0x08
0000740ecffd6b7c  jmp 0x0000740ECFFD59EC
0000740ecffd6b81  sub rsp, 0x08
0000740ecffd6b85  push rax
0000740ecffd6b86  push rcx
0000740ecffd6b87  push rdx
0000740ecffd6b88  push rdi
0000740ecffd6b89  push rsi
0000740ecffd6b8a  push r8
0000740ecffd6b8c  push r9
0000740ecffd6b8e  push r10
0000740ecffd6b90  push r11
0000740ecffd6b92  sub rsp, 0xF0
0000740ecffd6b99  vmovaps [rsp], xmm0
0000740ecffd6b9e  vmovaps [rsp+0x10], xmm1
0000740ecffd6ba4  vmovaps [rsp+0x20], xmm2
0000740ecffd6baa  vmovaps [rsp+0x30], xmm3
0000740ecffd6bb0  vmovaps [rsp+0x40], xmm4
0000740ecffd6bb6  vmovaps [rsp+0x50], xmm5
0000740ecffd6bbc  vmovaps [rsp+0x60], xmm6
0000740ecffd6bc2  vmovaps [rsp+0x70], xmm7
0000740ecffd6bc8  vmovaps [rsp+0x80], xmm8
0000740ecffd6bd1  vmovaps [rsp+0x90], xmm9
0000740ecffd6bda  vmovaps [rsp+0xA0], xmm11
0000740ecffd6be3  vmovaps [rsp+0xB0], xmm12
0000740ecffd6bec  vmovaps [rsp+0xC0], xmm13
0000740ecffd6bf5  vmovaps [rsp+0xD0], xmm14
0000740ecffd6bfe  vmovaps [rsp+0xE0], xmm15
0000740ecffd6c07  sub rsp, 0x30
0000740ecffd6c0b  movaps [rsp], xmm10
0000740ecffd6c10  movaps [rsp+0x10], xmm12
0000740ecffd6c16  movaps [rsp+0x20], xmm11
0000740ecffd6c1c  lea rdi, [rsp]
0000740ecffd6c20  mov esi, 0x00
0000740ecffd6c25  mov rax, 0x5E8249CF1530
0000740ecffd6c2f  call rax
0000740ecffd6c31  movaps xmm10, [rsp]
0000740ecffd6c36  add rsp, 0x30
0000740ecffd6c3a  vmovaps xmm0, [rsp]
0000740ecffd6c3f  vmovaps xmm1, [rsp+0x10]
0000740ecffd6c45  vmovaps xmm2, [rsp+0x20]
0000740ecffd6c4b  vmovaps xmm3, [rsp+0x30]
0000740ecffd6c51  vmovaps xmm4, [rsp+0x40]
0000740ecffd6c57  vmovaps xmm5, [rsp+0x50]
0000740ecffd6c5d  vmovaps xmm6, [rsp+0x60]
0000740ecffd6c63  vmovaps xmm7, [rsp+0x70]
0000740ecffd6c69  vmovaps xmm8, [rsp+0x80]
0000740ecffd6c72  vmovaps xmm9, [rsp+0x90]
0000740ecffd6c7b  vmovaps xmm11, [rsp+0xA0]
0000740ecffd6c84  vmovaps xmm12, [rsp+0xB0]
0000740ecffd6c8d  vmovaps xmm13, [rsp+0xC0]
0000740ecffd6c96  vmovaps xmm14, [rsp+0xD0]
0000740ecffd6c9f  vmovaps xmm15, [rsp+0xE0]
0000740ecffd6ca8  add rsp, 0xF0
0000740ecffd6caf  pop r11
0000740ecffd6cb1  pop r10
0000740ecffd6cb3  pop r9
0000740ecffd6cb5  pop r8
0000740ecffd6cb7  pop rsi
0000740ecffd6cb8  pop rdi
0000740ecffd6cb9  pop rdx
0000740ecffd6cba  pop rcx
0000740ecffd6cbb  pop rax
0000740ecffd6cbc  add rsp, 0x08
0000740ecffd6cc0  jmp 0x0000740ECFFD5A06
0000740ecffd6cc5  sub rsp, 0x08
0000740ecffd6cc9  push rax
0000740ecffd6cca  push rcx
0000740ecffd6ccb  push rdx
0000740ecffd6ccc  push rdi
0000740ecffd6ccd  push rsi
0000740ecffd6cce  push r8
0000740ecffd6cd0  push r9
0000740ecffd6cd2  push r10
0000740ecffd6cd4  push r11
0000740ecffd6cd6  sub rsp, 0xF0
0000740ecffd6cdd  vmovaps [rsp], xmm0
0000740ecffd6ce2  vmovaps [rsp+0x10], xmm1
0000740ecffd6ce8  vmovaps [rsp+0x20], xmm2
0000740ecffd6cee  vmovaps [rsp+0x30], xmm3
0000740ecffd6cf4  vmovaps [rsp+0x40], xmm4
0000740ecffd6cfa  vmovaps [rsp+0x50], xmm5
0000740ecffd6d00  vmovaps [rsp+0x60], xmm7
0000740ecffd6d06  vmovaps [rsp+0x70], xmm8
0000740ecffd6d0c  vmovaps [rsp+0x80], xmm9
0000740ecffd6d15  vmovaps [rsp+0x90], xmm10
0000740ecffd6d1e  vmovaps [rsp+0xA0], xmm11
0000740ecffd6d27  vmovaps [rsp+0xB0], xmm12
0000740ecffd6d30  vmovaps [rsp+0xC0], xmm13
0000740ecffd6d39  vmovaps [rsp+0xD0], xmm14
0000740ecffd6d42  vmovaps [rsp+0xE0], xmm15
0000740ecffd6d4b  sub rsp, 0x30
0000740ecffd6d4f  movaps [rsp], xmm6
0000740ecffd6d53  movaps [rsp+0x10], xmm12
0000740ecffd6d59  movaps [rsp+0x20], xmm11
0000740ecffd6d5f  lea rdi, [rsp]
0000740ecffd6d63  mov esi, 0x00
0000740ecffd6d68  mov rax, 0x5E8249CF1530
0000740ecffd6d72  call rax
0000740ecffd6d74  movaps xmm6, [rsp]
0000740ecffd6d78  add rsp, 0x30
0000740ecffd6d7c  vmovaps xmm0, [rsp]
0000740ecffd6d81  vmovaps xmm1, [rsp+0x10]
0000740ecffd6d87  vmovaps xmm2, [rsp+0x20]
0000740ecffd6d8d  vmovaps xmm3, [rsp+0x30]
0000740ecffd6d93  vmovaps xmm4, [rsp+0x40]
0000740ecffd6d99  vmovaps xmm5, [rsp+0x50]
0000740ecffd6d9f  vmovaps xmm7, [rsp+0x60]
0000740ecffd6da5  vmovaps xmm8, [rsp+0x70]
0000740ecffd6dab  vmovaps xmm9, [rsp+0x80]
0000740ecffd6db4  vmovaps xmm10, [rsp+0x90]
0000740ecffd6dbd  vmovaps xmm11, [rsp+0xA0]
0000740ecffd6dc6  vmovaps xmm12, [rsp+0xB0]
0000740ecffd6dcf  vmovaps xmm13, [rsp+0xC0]
0000740ecffd6dd8  vmovaps xmm14, [rsp+0xD0]
0000740ecffd6de1  vmovaps xmm15, [rsp+0xE0]
0000740ecffd6dea  add rsp, 0xF0
0000740ecffd6df1  pop r11
0000740ecffd6df3  pop r10
0000740ecffd6df5  pop r9
0000740ecffd6df7  pop r8
0000740ecffd6df9  pop rsi
0000740ecffd6dfa  pop rdi
0000740ecffd6dfb  pop rdx
0000740ecffd6dfc  pop rcx
0000740ecffd6dfd  pop rax
0000740ecffd6dfe  add rsp, 0x08
0000740ecffd6e02  jmp 0x0000740ECFFD5A27
0000740ecffd6e07  sub rsp, 0x08
0000740ecffd6e0b  push rax
0000740ecffd6e0c  push rcx
0000740ecffd6e0d  push rdx
0000740ecffd6e0e  push rdi
0000740ecffd6e0f  push rsi
0000740ecffd6e10  push r8
0000740ecffd6e12  push r9
0000740ecffd6e14  push r10
0000740ecffd6e16  push r11
0000740ecffd6e18  sub rsp, 0xF0
0000740ecffd6e1f  vmovaps [rsp], xmm0
0000740ecffd6e24  vmovaps [rsp+0x10], xmm1
0000740ecffd6e2a  vmovaps [rsp+0x20], xmm2
0000740ecffd6e30  vmovaps [rsp+0x30], xmm4
0000740ecffd6e36  vmovaps [rsp+0x40], xmm5
0000740ecffd6e3c  vmovaps [rsp+0x50], xmm6
0000740ecffd6e42  vmovaps [rsp+0x60], xmm7
0000740ecffd6e48  vmovaps [rsp+0x70], xmm8
0000740ecffd6e4e  vmovaps [rsp+0x80], xmm9
0000740ecffd6e57  vmovaps [rsp+0x90], xmm10
0000740ecffd6e60  vmovaps [rsp+0xA0], xmm11
0000740ecffd6e69  vmovaps [rsp+0xB0], xmm12
0000740ecffd6e72  vmovaps [rsp+0xC0], xmm13
0000740ecffd6e7b  vmovaps [rsp+0xD0], xmm14
0000740ecffd6e84  vmovaps [rsp+0xE0], xmm15
0000740ecffd6e8d  sub rsp, 0x30
0000740ecffd6e91  movaps [rsp], xmm3
0000740ecffd6e95  movaps [rsp+0x10], xmm5
0000740ecffd6e9a  movaps [rsp+0x20], xmm4
0000740ecffd6e9f  lea rdi, [rsp]
0000740ecffd6ea3  mov esi, 0x00
0000740ecffd6ea8  mov rax, 0x5E8249CF1530
0000740ecffd6eb2  call rax
0000740ecffd6eb4  movaps xmm3, [rsp]
0000740ecffd6eb8  add rsp, 0x30
0000740ecffd6ebc  vmovaps xmm0, [rsp]
0000740ecffd6ec1  vmovaps xmm1, [rsp+0x10]
0000740ecffd6ec7  vmovaps xmm2, [rsp+0x20]
0000740ecffd6ecd  vmovaps xmm4, [rsp+0x30]
0000740ecffd6ed3  vmovaps xmm5, [rsp+0x40]
0000740ecffd6ed9  vmovaps xmm6, [rsp+0x50]
0000740ecffd6edf  vmovaps xmm7, [rsp+0x60]
0000740ecffd6ee5  vmovaps xmm8, [rsp+0x70]
0000740ecffd6eeb  vmovaps xmm9, [rsp+0x80]
0000740ecffd6ef4  vmovaps xmm10, [rsp+0x90]
0000740ecffd6efd  vmovaps xmm11, [rsp+0xA0]
0000740ecffd6f06  vmovaps xmm12, [rsp+0xB0]
0000740ecffd6f0f  vmovaps xmm13, [rsp+0xC0]
0000740ecffd6f18  vmovaps xmm14, [rsp+0xD0]
0000740ecffd6f21  vmovaps xmm15, [rsp+0xE0]
0000740ecffd6f2a  add rsp, 0xF0
0000740ecffd6f31  pop r11
0000740ecffd6f33  pop r10
0000740ecffd6f35  pop r9
0000740ecffd6f37  pop r8
0000740ecffd6f39  pop rsi
0000740ecffd6f3a  pop rdi
0000740ecffd6f3b  pop rdx
0000740ecffd6f3c  pop rcx
0000740ecffd6f3d  pop rax
0000740ecffd6f3e  add rsp, 0x08
0000740ecffd6f42  jmp 0x0000740ECFFD5A88
0000740ecffd6f47  sub rsp, 0x08
0000740ecffd6f4b  push rax
0000740ecffd6f4c  push rcx
0000740ecffd6f4d  push rdx
0000740ecffd6f4e  push rdi
0000740ecffd6f4f  push rsi
0000740ecffd6f50  push r8
0000740ecffd6f52  push r9
0000740ecffd6f54  push r10
0000740ecffd6f56  push r11
0000740ecffd6f58  sub rsp, 0xF0
0000740ecffd6f5f  vmovaps [rsp], xmm0
0000740ecffd6f64  vmovaps [rsp+0x10], xmm1
0000740ecffd6f6a  vmovaps [rsp+0x20], xmm2
0000740ecffd6f70  vmovaps [rsp+0x30], xmm3
0000740ecffd6f76  vmovaps [rsp+0x40], xmm4
0000740ecffd6f7c  vmovaps [rsp+0x50], xmm6
0000740ecffd6f82  vmovaps [rsp+0x60], xmm7
0000740ecffd6f88  vmovaps [rsp+0x70], xmm8
0000740ecffd6f8e  vmovaps [rsp+0x80], xmm9
0000740ecffd6f97  vmovaps [rsp+0x90], xmm10
0000740ecffd6fa0  vmovaps [rsp+0xA0], xmm11
0000740ecffd6fa9  vmovaps [rsp+0xB0], xmm12
0000740ecffd6fb2  vmovaps [rsp+0xC0], xmm13
0000740ecffd6fbb  vmovaps [rsp+0xD0], xmm14
0000740ecffd6fc4  vmovaps [rsp+0xE0], xmm15
0000740ecffd6fcd  sub rsp, 0x30
0000740ecffd6fd1  movaps [rsp], xmm5
0000740ecffd6fd5  movaps [rsp+0x10], xmm8
0000740ecffd6fdb  movaps [rsp+0x20], xmm15
0000740ecffd6fe1  lea rdi, [rsp]
0000740ecffd6fe5  mov esi, 0x00
0000740ecffd6fea  mov rax, 0x5E8249CF1530
0000740ecffd6ff4  call rax
0000740ecffd6ff6  movaps xmm5, [rsp]
0000740ecffd6ffa  add rsp, 0x30
0000740ecffd6ffe  vmovaps xmm0, [rsp]
0000740ecffd7003  vmovaps xmm1, [rsp+0x10]
0000740ecffd7009  vmovaps xmm2, [rsp+0x20]
0000740ecffd700f  vmovaps xmm3, [rsp+0x30]
0000740ecffd7015  vmovaps xmm4, [rsp+0x40]
0000740ecffd701b  vmovaps xmm6, [rsp+0x50]
0000740ecffd7021  vmovaps xmm7, [rsp+0x60]
0000740ecffd7027  vmovaps xmm8, [rsp+0x70]
0000740ecffd702d  vmovaps xmm9, [rsp+0x80]
0000740ecffd7036  vmovaps xmm10, [rsp+0x90]
0000740ecffd703f  vmovaps xmm11, [rsp+0xA0]
0000740ecffd7048  vmovaps xmm12, [rsp+0xB0]
0000740ecffd7051  vmovaps xmm13, [rsp+0xC0]
0000740ecffd705a  vmovaps xmm14, [rsp+0xD0]
0000740ecffd7063  vmovaps xmm15, [rsp+0xE0]
0000740ecffd706c  add rsp, 0xF0
0000740ecffd7073  pop r11
0000740ecffd7075  pop r10
0000740ecffd7077  pop r9
0000740ecffd7079  pop r8
0000740ecffd707b  pop rsi
0000740ecffd707c  pop rdi
0000740ecffd707d  pop rdx
0000740ecffd707e  pop rcx
0000740ecffd707f  pop rax
0000740ecffd7080  add rsp, 0x08
0000740ecffd7084  jmp 0x0000740ECFFD5AC0
0000740ecffd7089  sub rsp, 0x08
0000740ecffd708d  push rax
0000740ecffd708e  push rcx
0000740ecffd708f  push rdx
0000740ecffd7090  push rdi
0000740ecffd7091  push rsi
0000740ecffd7092  push r8
0000740ecffd7094  push r9
0000740ecffd7096  push r10
0000740ecffd7098  push r11
0000740ecffd709a  sub rsp, 0xF0
0000740ecffd70a1  vmovaps [rsp], xmm0
0000740ecffd70a6  vmovaps [rsp+0x10], xmm1
0000740ecffd70ac  vmovaps [rsp+0x20], xmm2
0000740ecffd70b2  vmovaps [rsp+0x30], xmm3
0000740ecffd70b8  vmovaps [rsp+0x40], xmm5
0000740ecffd70be  vmovaps [rsp+0x50], xmm6
0000740ecffd70c4  vmovaps [rsp+0x60], xmm7
0000740ecffd70ca  vmovaps [rsp+0x70], xmm8
0000740ecffd70d0  vmovaps [rsp+0x80], xmm9
0000740ecffd70d9  vmovaps [rsp+0x90], xmm10
0000740ecffd70e2  vmovaps [rsp+0xA0], xmm11
0000740ecffd70eb  vmovaps [rsp+0xB0], xmm12
0000740ecffd70f4  vmovaps [rsp+0xC0], xmm13
0000740ecffd70fd  vmovaps [rsp+0xD0], xmm14
0000740ecffd7106  vmovaps [rsp+0xE0], xmm15
0000740ecffd710f  sub rsp, 0x30
0000740ecffd7113  movaps [rsp], xmm4
0000740ecffd7117  movaps [rsp+0x10], xmm9
0000740ecffd711d  movaps [rsp+0x20], xmm8
0000740ecffd7123  lea rdi, [rsp]
0000740ecffd7127  mov esi, 0x00
0000740ecffd712c  mov rax, 0x5E8249CF1530
0000740ecffd7136  call rax
0000740ecffd7138  movaps xmm4, [rsp]
0000740ecffd713c  add rsp, 0x30
0000740ecffd7140  vmovaps xmm0, [rsp]
0000740ecffd7145  vmovaps xmm1, [rsp+0x10]
0000740ecffd714b  vmovaps xmm2, [rsp+0x20]
0000740ecffd7151  vmovaps xmm3, [rsp+0x30]
0000740ecffd7157  vmovaps xmm5, [rsp+0x40]
0000740ecffd715d  vmovaps xmm6, [rsp+0x50]
0000740ecffd7163  vmovaps xmm7, [rsp+0x60]
0000740ecffd7169  vmovaps xmm8, [rsp+0x70]
0000740ecffd716f  vmovaps xmm9, [rsp+0x80]
0000740ecffd7178  vmovaps xmm10, [rsp+0x90]
0000740ecffd7181  vmovaps xmm11, [rsp+0xA0]
0000740ecffd718a  vmovaps xmm12, [rsp+0xB0]
0000740ecffd7193  vmovaps xmm13, [rsp+0xC0]
0000740ecffd719c  vmovaps xmm14, [rsp+0xD0]
0000740ecffd71a5  vmovaps xmm15, [rsp+0xE0]
0000740ecffd71ae  add rsp, 0xF0
0000740ecffd71b5  pop r11
0000740ecffd71b7  pop r10
0000740ecffd71b9  pop r9
0000740ecffd71bb  pop r8
0000740ecffd71bd  pop rsi
0000740ecffd71be  pop rdi
0000740ecffd71bf  pop rdx
0000740ecffd71c0  pop rcx
0000740ecffd71c1  pop rax
0000740ecffd71c2  add rsp, 0x08
0000740ecffd71c6  jmp 0x0000740ECFFD5AE1
0000740ecffd71cb  sub rsp, 0x08
0000740ecffd71cf  push rax
0000740ecffd71d0  push rcx
0000740ecffd71d1  push rdx
0000740ecffd71d2  push rdi
0000740ecffd71d3  push rsi
0000740ecffd71d4  push r8
0000740ecffd71d6  push r9
0000740ecffd71d8  push r10
0000740ecffd71da  push r11
0000740ecffd71dc  sub rsp, 0xF0
0000740ecffd71e3  vmovaps [rsp], xmm0
0000740ecffd71e8  vmovaps [rsp+0x10], xmm1
0000740ecffd71ee  vmovaps [rsp+0x20], xmm2
0000740ecffd71f4  vmovaps [rsp+0x30], xmm3
0000740ecffd71fa  vmovaps [rsp+0x40], xmm4
0000740ecffd7200  vmovaps [rsp+0x50], xmm5
0000740ecffd7206  vmovaps [rsp+0x60], xmm6
0000740ecffd720c  vmovaps [rsp+0x70], xmm7
0000740ecffd7212  vmovaps [rsp+0x80], xmm8
0000740ecffd721b  vmovaps [rsp+0x90], xmm10
0000740ecffd7224  vmovaps [rsp+0xA0], xmm11
0000740ecffd722d  vmovaps [rsp+0xB0], xmm12
0000740ecffd7236  vmovaps [rsp+0xC0], xmm13
0000740ecffd723f  vmovaps [rsp+0xD0], xmm14
0000740ecffd7248  vmovaps [rsp+0xE0], xmm15
0000740ecffd7251  sub rsp, 0x30
0000740ecffd7255  movaps [rsp], xmm9
0000740ecffd725a  movaps [rsp+0x10], xmm10
0000740ecffd7260  movaps [rsp+0x20], xmm8
0000740ecffd7266  lea rdi, [rsp]
0000740ecffd726a  mov esi, 0x00
0000740ecffd726f  mov rax, 0x5E8249CF1530
0000740ecffd7279  call rax
0000740ecffd727b  movaps xmm9, [rsp]
0000740ecffd7280  add rsp, 0x30
0000740ecffd7284  vmovaps xmm0, [rsp]
0000740ecffd7289  vmovaps xmm1, [rsp+0x10]
0000740ecffd728f  vmovaps xmm2, [rsp+0x20]
0000740ecffd7295  vmovaps xmm3, [rsp+0x30]
0000740ecffd729b  vmovaps xmm4, [rsp+0x40]
0000740ecffd72a1  vmovaps xmm5, [rsp+0x50]
0000740ecffd72a7  vmovaps xmm6, [rsp+0x60]
0000740ecffd72ad  vmovaps xmm7, [rsp+0x70]
0000740ecffd72b3  vmovaps xmm8, [rsp+0x80]
0000740ecffd72bc  vmovaps xmm10, [rsp+0x90]
0000740ecffd72c5  vmovaps xmm11, [rsp+0xA0]
0000740ecffd72ce  vmovaps xmm12, [rsp+0xB0]
0000740ecffd72d7  vmovaps xmm13, [rsp+0xC0]
0000740ecffd72e0  vmovaps xmm14, [rsp+0xD0]
0000740ecffd72e9  vmovaps xmm15, [rsp+0xE0]
0000740ecffd72f2  add rsp, 0xF0
0000740ecffd72f9  pop r11
0000740ecffd72fb  pop r10
0000740ecffd72fd  pop r9
0000740ecffd72ff  pop r8
0000740ecffd7301  pop rsi
0000740ecffd7302  pop rdi
0000740ecffd7303  pop rdx
0000740ecffd7304  pop rcx
0000740ecffd7305  pop rax
0000740ecffd7306  add rsp, 0x08
0000740ecffd730a  jmp 0x0000740ECFFD5AFB
0000740ecffd730f  call 0x0000740ECFED64F0
0000740ecffd7314  jmp 0x0000740ECFFD5C15
0000740ecffd7319  call 0x0000740ECFED64F0
0000740ecffd731e  jmp 0x0000740ECFFD5C2B
0000740ecffd7323  sub rsp, 0x08
0000740ecffd7327  push rax
0000740ecffd7328  push rcx
0000740ecffd7329  push rdx
0000740ecffd732a  push rdi
0000740ecffd732b  push rsi
0000740ecffd732c  push r8
0000740ecffd732e  push r9
0000740ecffd7330  push r10
0000740ecffd7332  push r11
0000740ecffd7334  sub rsp, 0xF0
0000740ecffd733b  vmovaps [rsp], xmm0
0000740ecffd7340  vmovaps [rsp+0x10], xmm2
0000740ecffd7346  vmovaps [rsp+0x20], xmm3
0000740ecffd734c  vmovaps [rsp+0x30], xmm4
0000740ecffd7352  vmovaps [rsp+0x40], xmm5
0000740ecffd7358  vmovaps [rsp+0x50], xmm6
0000740ecffd735e  vmovaps [rsp+0x60], xmm7
0000740ecffd7364  vmovaps [rsp+0x70], xmm8
0000740ecffd736a  vmovaps [rsp+0x80], xmm9
0000740ecffd7373  vmovaps [rsp+0x90], xmm10
0000740ecffd737c  vmovaps [rsp+0xA0], xmm11
0000740ecffd7385  vmovaps [rsp+0xB0], xmm12
0000740ecffd738e  vmovaps [rsp+0xC0], xmm13
0000740ecffd7397  vmovaps [rsp+0xD0], xmm14
0000740ecffd73a0  vmovaps [rsp+0xE0], xmm15
0000740ecffd73a9  sub rsp, 0x30
0000740ecffd73ad  movaps [rsp], xmm1
0000740ecffd73b1  movaps [rsp+0x10], xmm6
0000740ecffd73b6  movaps [rsp+0x20], xmm15
0000740ecffd73bc  lea rdi, [rsp]
0000740ecffd73c0  mov esi, 0x00
0000740ecffd73c5  mov rax, 0x5E8249CF1530
0000740ecffd73cf  call rax
0000740ecffd73d1  movaps xmm1, [rsp]
0000740ecffd73d5  add rsp, 0x30
0000740ecffd73d9  vmovaps xmm0, [rsp]
0000740ecffd73de  vmovaps xmm2, [rsp+0x10]
0000740ecffd73e4  vmovaps xmm3, [rsp+0x20]
0000740ecffd73ea  vmovaps xmm4, [rsp+0x30]
0000740ecffd73f0  vmovaps xmm5, [rsp+0x40]
0000740ecffd73f6  vmovaps xmm6, [rsp+0x50]
0000740ecffd73fc  vmovaps xmm7, [rsp+0x60]
0000740ecffd7402  vmovaps xmm8, [rsp+0x70]
0000740ecffd7408  vmovaps xmm9, [rsp+0x80]
0000740ecffd7411  vmovaps xmm10, [rsp+0x90]
0000740ecffd741a  vmovaps xmm11, [rsp+0xA0]
0000740ecffd7423  vmovaps xmm12, [rsp+0xB0]
0000740ecffd742c  vmovaps xmm13, [rsp+0xC0]
0000740ecffd7435  vmovaps xmm14, [rsp+0xD0]
0000740ecffd743e  vmovaps xmm15, [rsp+0xE0]
0000740ecffd7447  add rsp, 0xF0
0000740ecffd744e  pop r11
0000740ecffd7450  pop r10
0000740ecffd7452  pop r9
0000740ecffd7454  pop r8
0000740ecffd7456  pop rsi
0000740ecffd7457  pop rdi
0000740ecffd7458  pop rdx
0000740ecffd7459  pop rcx
0000740ecffd745a  pop rax
0000740ecffd745b  add rsp, 0x08
0000740ecffd745f  jmp 0x0000740ECFFD5C68
0000740ecffd7464  call 0x0000740ECFEE5820
0000740ecffd7469  jmp 0x0000740ECFFD5C75
0000740ecffd746e  sub rsp, 0x08
0000740ecffd7472  push rax
0000740ecffd7473  push rcx
0000740ecffd7474  push rdx
0000740ecffd7475  push rdi
0000740ecffd7476  push rsi
0000740ecffd7477  push r8
0000740ecffd7479  push r9
0000740ecffd747b  push r10
0000740ecffd747d  push r11
0000740ecffd747f  sub rsp, 0xF0
0000740ecffd7486  vmovaps [rsp], xmm0
0000740ecffd748b  vmovaps [rsp+0x10], xmm1
0000740ecffd7491  vmovaps [rsp+0x20], xmm2
0000740ecffd7497  vmovaps [rsp+0x30], xmm3
0000740ecffd749d  vmovaps [rsp+0x40], xmm4
0000740ecffd74a3  vmovaps [rsp+0x50], xmm5
0000740ecffd74a9  vmovaps [rsp+0x60], xmm6
0000740ecffd74af  vmovaps [rsp+0x70], xmm7
0000740ecffd74b5  vmovaps [rsp+0x80], xmm8
0000740ecffd74be  vmovaps [rsp+0x90], xmm9
0000740ecffd74c7  vmovaps [rsp+0xA0], xmm10
0000740ecffd74d0  vmovaps [rsp+0xB0], xmm11
0000740ecffd74d9  vmovaps [rsp+0xC0], xmm12
0000740ecffd74e2  vmovaps [rsp+0xD0], xmm13
0000740ecffd74eb  vmovaps [rsp+0xE0], xmm15
0000740ecffd74f4  sub rsp, 0x30
0000740ecffd74f8  movaps [rsp], xmm14
0000740ecffd74fd  movaps [rsp+0x10], xmm4
0000740ecffd7502  movaps [rsp+0x20], xmm3
0000740ecffd7507  lea rdi, [rsp]
0000740ecffd750b  mov esi, 0x00
0000740ecffd7510  mov rax, 0x5E8249CF1530
0000740ecffd751a  call rax
0000740ecffd751c  movaps xmm14, [rsp]
0000740ecffd7521  add rsp, 0x30
0000740ecffd7525  vmovaps xmm0, [rsp]
0000740ecffd752a  vmovaps xmm1, [rsp+0x10]
0000740ecffd7530  vmovaps xmm2, [rsp+0x20]
0000740ecffd7536  vmovaps xmm3, [rsp+0x30]
0000740ecffd753c  vmovaps xmm4, [rsp+0x40]
0000740ecffd7542  vmovaps xmm5, [rsp+0x50]
0000740ecffd7548  vmovaps xmm6, [rsp+0x60]
0000740ecffd754e  vmovaps xmm7, [rsp+0x70]
0000740ecffd7554  vmovaps xmm8, [rsp+0x80]
0000740ecffd755d  vmovaps xmm9, [rsp+0x90]
0000740ecffd7566  vmovaps xmm10, [rsp+0xA0]
0000740ecffd756f  vmovaps xmm11, [rsp+0xB0]
0000740ecffd7578  vmovaps xmm12, [rsp+0xC0]
0000740ecffd7581  vmovaps xmm13, [rsp+0xD0]
0000740ecffd758a  vmovaps xmm15, [rsp+0xE0]
0000740ecffd7593  add rsp, 0xF0
0000740ecffd759a  pop r11
0000740ecffd759c  pop r10
0000740ecffd759e  pop r9
0000740ecffd75a0  pop r8
0000740ecffd75a2  pop rsi
0000740ecffd75a3  pop rdi
0000740ecffd75a4  pop rdx
0000740ecffd75a5  pop rcx
0000740ecffd75a6  pop rax
0000740ecffd75a7  add rsp, 0x08
0000740ecffd75ab  jmp 0x0000740ECFFD5C8F
0000740ecffd75b0  sub rsp, 0x08
0000740ecffd75b4  push rax
0000740ecffd75b5  push rcx
0000740ecffd75b6  push rdx
0000740ecffd75b7  push rdi
0000740ecffd75b8  push rsi
0000740ecffd75b9  push r8
0000740ecffd75bb  push r9
0000740ecffd75bd  push r10
0000740ecffd75bf  push r11
0000740ecffd75c1  sub rsp, 0xF0
0000740ecffd75c8  vmovaps [rsp], xmm0
0000740ecffd75cd  vmovaps [rsp+0x10], xmm1
0000740ecffd75d3  vmovaps [rsp+0x20], xmm2
0000740ecffd75d9  vmovaps [rsp+0x30], xmm3
0000740ecffd75df  vmovaps [rsp+0x40], xmm4
0000740ecffd75e5  vmovaps [rsp+0x50], xmm5
0000740ecffd75eb  vmovaps [rsp+0x60], xmm7
0000740ecffd75f1  vmovaps [rsp+0x70], xmm8
0000740ecffd75f7  vmovaps [rsp+0x80], xmm9
0000740ecffd7600  vmovaps [rsp+0x90], xmm10
0000740ecffd7609  vmovaps [rsp+0xA0], xmm11
0000740ecffd7612  vmovaps [rsp+0xB0], xmm12
0000740ecffd761b  vmovaps [rsp+0xC0], xmm13
0000740ecffd7624  vmovaps [rsp+0xD0], xmm14
0000740ecffd762d  vmovaps [rsp+0xE0], xmm15
0000740ecffd7636  sub rsp, 0x30
0000740ecffd763a  movaps [rsp], xmm6
0000740ecffd763e  movaps [rsp+0x10], xmm9
0000740ecffd7644  movaps [rsp+0x20], xmm7
0000740ecffd7649  lea rdi, [rsp]
0000740ecffd764d  mov esi, 0x00
0000740ecffd7652  mov rax, 0x5E8249CF1530
0000740ecffd765c  call rax
0000740ecffd765e  movaps xmm6, [rsp]
0000740ecffd7662  add rsp, 0x30
0000740ecffd7666  vmovaps xmm0, [rsp]
0000740ecffd766b  vmovaps xmm1, [rsp+0x10]
0000740ecffd7671  vmovaps xmm2, [rsp+0x20]
0000740ecffd7677  vmovaps xmm3, [rsp+0x30]
0000740ecffd767d  vmovaps xmm4, [rsp+0x40]
0000740ecffd7683  vmovaps xmm5, [rsp+0x50]
0000740ecffd7689  vmovaps xmm7, [rsp+0x60]
0000740ecffd768f  vmovaps xmm8, [rsp+0x70]
0000740ecffd7695  vmovaps xmm9, [rsp+0x80]
0000740ecffd769e  vmovaps xmm10, [rsp+0x90]
0000740ecffd76a7  vmovaps xmm11, [rsp+0xA0]
0000740ecffd76b0  vmovaps xmm12, [rsp+0xB0]
0000740ecffd76b9  vmovaps xmm13, [rsp+0xC0]
0000740ecffd76c2  vmovaps xmm14, [rsp+0xD0]
0000740ecffd76cb  vmovaps xmm15, [rsp+0xE0]
0000740ecffd76d4  add rsp, 0xF0
0000740ecffd76db  pop r11
0000740ecffd76dd  pop r10
0000740ecffd76df  pop r9
0000740ecffd76e1  pop r8
0000740ecffd76e3  pop rsi
0000740ecffd76e4  pop rdi
0000740ecffd76e5  pop rdx
0000740ecffd76e6  pop rcx
0000740ecffd76e7  pop rax
0000740ecffd76e8  add rsp, 0x08
0000740ecffd76ec  jmp 0x0000740ECFFD5CA7
0000740ecffd76f1  sub rsp, 0x08
0000740ecffd76f5  push rax
0000740ecffd76f6  push rcx
0000740ecffd76f7  push rdx
0000740ecffd76f8  push rdi
0000740ecffd76f9  push rsi
0000740ecffd76fa  push r8
0000740ecffd76fc  push r9
0000740ecffd76fe  push r10
0000740ecffd7700  push r11
0000740ecffd7702  sub rsp, 0xF0
0000740ecffd7709  vmovaps [rsp], xmm0
0000740ecffd770e  vmovaps [rsp+0x10], xmm1
0000740ecffd7714  vmovaps [rsp+0x20], xmm2
0000740ecffd771a  vmovaps [rsp+0x30], xmm3
0000740ecffd7720  vmovaps [rsp+0x40], xmm4
0000740ecffd7726  vmovaps [rsp+0x50], xmm5
0000740ecffd772c  vmovaps [rsp+0x60], xmm6
0000740ecffd7732  vmovaps [rsp+0x70], xmm8
0000740ecffd7738  vmovaps [rsp+0x80], xmm9
0000740ecffd7741  vmovaps [rsp+0x90], xmm10
0000740ecffd774a  vmovaps [rsp+0xA0], xmm11
0000740ecffd7753  vmovaps [rsp+0xB0], xmm12
0000740ecffd775c  vmovaps [rsp+0xC0], xmm13
0000740ecffd7765  vmovaps [rsp+0xD0], xmm14
0000740ecffd776e  vmovaps [rsp+0xE0], xmm15
0000740ecffd7777  sub rsp, 0x30
0000740ecffd777b  movaps [rsp], xmm7
0000740ecffd777f  movaps [rsp+0x10], xmm4
0000740ecffd7784  movaps [rsp+0x20], xmm9
0000740ecffd778a  lea rdi, [rsp]
0000740ecffd778e  mov esi, 0x00
0000740ecffd7793  mov rax, 0x5E8249CF1530
0000740ecffd779d  call rax
0000740ecffd779f  movaps xmm7, [rsp]
0000740ecffd77a3  add rsp, 0x30
0000740ecffd77a7  vmovaps xmm0, [rsp]
0000740ecffd77ac  vmovaps xmm1, [rsp+0x10]
0000740ecffd77b2  vmovaps xmm2, [rsp+0x20]
0000740ecffd77b8  vmovaps xmm3, [rsp+0x30]
0000740ecffd77be  vmovaps xmm4, [rsp+0x40]
0000740ecffd77c4  vmovaps xmm5, [rsp+0x50]
0000740ecffd77ca  vmovaps xmm6, [rsp+0x60]
0000740ecffd77d0  vmovaps xmm8, [rsp+0x70]
0000740ecffd77d6  vmovaps xmm9, [rsp+0x80]
0000740ecffd77df  vmovaps xmm10, [rsp+0x90]
0000740ecffd77e8  vmovaps xmm11, [rsp+0xA0]
0000740ecffd77f1  vmovaps xmm12, [rsp+0xB0]
0000740ecffd77fa  vmovaps xmm13, [rsp+0xC0]
0000740ecffd7803  vmovaps xmm14, [rsp+0xD0]
0000740ecffd780c  vmovaps xmm15, [rsp+0xE0]
0000740ecffd7815  add rsp, 0xF0
0000740ecffd781c  pop r11
0000740ecffd781e  pop r10
0000740ecffd7820  pop r9
0000740ecffd7822  pop r8
0000740ecffd7824  pop rsi
0000740ecffd7825  pop rdi
0000740ecffd7826  pop rdx
0000740ecffd7827  pop rcx
0000740ecffd7828  pop rax
0000740ecffd7829  add rsp, 0x08
0000740ecffd782d  jmp 0x0000740ECFFD5CD4
0000740ecffd7832  sub rsp, 0x08
0000740ecffd7836  push rax
0000740ecffd7837  push rcx
0000740ecffd7838  push rdx
0000740ecffd7839  push rdi
0000740ecffd783a  push rsi
0000740ecffd783b  push r8
0000740ecffd783d  push r9
0000740ecffd783f  push r10
0000740ecffd7841  push r11
0000740ecffd7843  sub rsp, 0xF0
0000740ecffd784a  vmovaps [rsp], xmm0
0000740ecffd784f  vmovaps [rsp+0x10], xmm1
0000740ecffd7855  vmovaps [rsp+0x20], xmm2
0000740ecffd785b  vmovaps [rsp+0x30], xmm3
0000740ecffd7861  vmovaps [rsp+0x40], xmm5
0000740ecffd7867  vmovaps [rsp+0x50], xmm6
0000740ecffd786d  vmovaps [rsp+0x60], xmm7
0000740ecffd7873  vmovaps [rsp+0x70], xmm8
0000740ecffd7879  vmovaps [rsp+0x80], xmm9
0000740ecffd7882  vmovaps [rsp+0x90], xmm10
0000740ecffd788b  vmovaps [rsp+0xA0], xmm11
0000740ecffd7894  vmovaps [rsp+0xB0], xmm12
0000740ecffd789d  vmovaps [rsp+0xC0], xmm13
0000740ecffd78a6  vmovaps [rsp+0xD0], xmm14
0000740ecffd78af  vmovaps [rsp+0xE0], xmm15
0000740ecffd78b8  sub rsp, 0x30
0000740ecffd78bc  movaps [rsp], xmm4
0000740ecffd78c0  movaps [rsp+0x10], xmm15
0000740ecffd78c6  movaps [rsp+0x20], xmm9
0000740ecffd78cc  lea rdi, [rsp]
0000740ecffd78d0  mov esi, 0x00
0000740ecffd78d5  mov rax, 0x5E8249CF1530
0000740ecffd78df  call rax
0000740ecffd78e1  movaps xmm4, [rsp]
0000740ecffd78e5  add rsp, 0x30
0000740ecffd78e9  vmovaps xmm0, [rsp]
0000740ecffd78ee  vmovaps xmm1, [rsp+0x10]
0000740ecffd78f4  vmovaps xmm2, [rsp+0x20]
0000740ecffd78fa  vmovaps xmm3, [rsp+0x30]
0000740ecffd7900  vmovaps xmm5, [rsp+0x40]
0000740ecffd7906  vmovaps xmm6, [rsp+0x50]
0000740ecffd790c  vmovaps xmm7, [rsp+0x60]
0000740ecffd7912  vmovaps xmm8, [rsp+0x70]
0000740ecffd7918  vmovaps xmm9, [rsp+0x80]
0000740ecffd7921  vmovaps xmm10, [rsp+0x90]
0000740ecffd792a  vmovaps xmm11, [rsp+0xA0]
0000740ecffd7933  vmovaps xmm12, [rsp+0xB0]
0000740ecffd793c  vmovaps xmm13, [rsp+0xC0]
0000740ecffd7945  vmovaps xmm14, [rsp+0xD0]
0000740ecffd794e  vmovaps xmm15, [rsp+0xE0]
0000740ecffd7957  add rsp, 0xF0
0000740ecffd795e  pop r11
0000740ecffd7960  pop r10
0000740ecffd7962  pop r9
0000740ecffd7964  pop r8
0000740ecffd7966  pop rsi
0000740ecffd7967  pop rdi
0000740ecffd7968  pop rdx
0000740ecffd7969  pop rcx
0000740ecffd796a  pop rax
0000740ecffd796b  add rsp, 0x08
0000740ecffd796f  jmp 0x0000740ECFFD5CF9
0000740ecffd7974  call 0x0000740ECFEE5820
0000740ecffd7979  jmp 0x0000740ECFFD5D06
0000740ecffd797e  sub rsp, 0x08
0000740ecffd7982  push rax
0000740ecffd7983  push rcx
0000740ecffd7984  push rdx
0000740ecffd7985  push rdi
0000740ecffd7986  push rsi
0000740ecffd7987  push r8
0000740ecffd7989  push r9
0000740ecffd798b  push r10
0000740ecffd798d  push r11
0000740ecffd798f  sub rsp, 0xF0
0000740ecffd7996  vmovaps [rsp], xmm0
0000740ecffd799b  vmovaps [rsp+0x10], xmm1
0000740ecffd79a1  vmovaps [rsp+0x20], xmm2
0000740ecffd79a7  vmovaps [rsp+0x30], xmm4
0000740ecffd79ad  vmovaps [rsp+0x40], xmm5
0000740ecffd79b3  vmovaps [rsp+0x50], xmm6
0000740ecffd79b9  vmovaps [rsp+0x60], xmm7
0000740ecffd79bf  vmovaps [rsp+0x70], xmm8
0000740ecffd79c5  vmovaps [rsp+0x80], xmm9
0000740ecffd79ce  vmovaps [rsp+0x90], xmm10
0000740ecffd79d7  vmovaps [rsp+0xA0], xmm11
0000740ecffd79e0  vmovaps [rsp+0xB0], xmm12
0000740ecffd79e9  vmovaps [rsp+0xC0], xmm13
0000740ecffd79f2  vmovaps [rsp+0xD0], xmm14
0000740ecffd79fb  vmovaps [rsp+0xE0], xmm15
0000740ecffd7a04  sub rsp, 0x30
0000740ecffd7a08  movaps [rsp], xmm3
0000740ecffd7a0c  movaps [rsp+0x10], xmm1
0000740ecffd7a11  movaps [rsp+0x20], xmm9
0000740ecffd7a17  lea rdi, [rsp]
0000740ecffd7a1b  mov esi, 0x00
0000740ecffd7a20  mov rax, 0x5E8249CF1530
0000740ecffd7a2a  call rax
0000740ecffd7a2c  movaps xmm3, [rsp]
0000740ecffd7a30  add rsp, 0x30
0000740ecffd7a34  vmovaps xmm0, [rsp]
0000740ecffd7a39  vmovaps xmm1, [rsp+0x10]
0000740ecffd7a3f  vmovaps xmm2, [rsp+0x20]
0000740ecffd7a45  vmovaps xmm4, [rsp+0x30]
0000740ecffd7a4b  vmovaps xmm5, [rsp+0x40]
0000740ecffd7a51  vmovaps xmm6, [rsp+0x50]
0000740ecffd7a57  vmovaps xmm7, [rsp+0x60]
0000740ecffd7a5d  vmovaps xmm8, [rsp+0x70]
0000740ecffd7a63  vmovaps xmm9, [rsp+0x80]
0000740ecffd7a6c  vmovaps xmm10, [rsp+0x90]
0000740ecffd7a75  vmovaps xmm11, [rsp+0xA0]
0000740ecffd7a7e  vmovaps xmm12, [rsp+0xB0]
0000740ecffd7a87  vmovaps xmm13, [rsp+0xC0]
0000740ecffd7a90  vmovaps xmm14, [rsp+0xD0]
0000740ecffd7a99  vmovaps xmm15, [rsp+0xE0]
0000740ecffd7aa2  add rsp, 0xF0
0000740ecffd7aa9  pop r11
0000740ecffd7aab  pop r10
0000740ecffd7aad  pop r9
0000740ecffd7aaf  pop r8
0000740ecffd7ab1  pop rsi
0000740ecffd7ab2  pop rdi
0000740ecffd7ab3  pop rdx
0000740ecffd7ab4  pop rcx
0000740ecffd7ab5  pop rax
0000740ecffd7ab6  add rsp, 0x08
0000740ecffd7aba  jmp 0x0000740ECFFD5D43
0000740ecffd7abf  sub rsp, 0x08
0000740ecffd7ac3  push rax
0000740ecffd7ac4  push rcx
0000740ecffd7ac5  push rdx
0000740ecffd7ac6  push rdi
0000740ecffd7ac7  push rsi
0000740ecffd7ac8  push r8
0000740ecffd7aca  push r9
0000740ecffd7acc  push r10
0000740ecffd7ace  push r11
0000740ecffd7ad0  sub rsp, 0xF0
0000740ecffd7ad7  vmovaps [rsp], xmm0
0000740ecffd7adc  vmovaps [rsp+0x10], xmm2
0000740ecffd7ae2  vmovaps [rsp+0x20], xmm3
0000740ecffd7ae8  vmovaps [rsp+0x30], xmm4
0000740ecffd7aee  vmovaps [rsp+0x40], xmm5
0000740ecffd7af4  vmovaps [rsp+0x50], xmm6
0000740ecffd7afa  vmovaps [rsp+0x60], xmm7
0000740ecffd7b00  vmovaps [rsp+0x70], xmm8
0000740ecffd7b06  vmovaps [rsp+0x80], xmm9
0000740ecffd7b0f  vmovaps [rsp+0x90], xmm10
0000740ecffd7b18  vmovaps [rsp+0xA0], xmm11
0000740ecffd7b21  vmovaps [rsp+0xB0], xmm12
0000740ecffd7b2a  vmovaps [rsp+0xC0], xmm13
0000740ecffd7b33  vmovaps [rsp+0xD0], xmm14
0000740ecffd7b3c  vmovaps [rsp+0xE0], xmm15
0000740ecffd7b45  sub rsp, 0x30
0000740ecffd7b49  movaps [rsp], xmm1
0000740ecffd7b4d  movaps [rsp+0x10], xmm15
0000740ecffd7b53  movaps [rsp+0x20], xmm9
0000740ecffd7b59  lea rdi, [rsp]
0000740ecffd7b5d  mov esi, 0x00
0000740ecffd7b62  mov rax, 0x5E8249CF1530
0000740ecffd7b6c  call rax
0000740ecffd7b6e  movaps xmm1, [rsp]
0000740ecffd7b72  add rsp, 0x30
0000740ecffd7b76  vmovaps xmm0, [rsp]
0000740ecffd7b7b  vmovaps xmm2, [rsp+0x10]
0000740ecffd7b81  vmovaps xmm3, [rsp+0x20]
0000740ecffd7b87  vmovaps xmm4, [rsp+0x30]
0000740ecffd7b8d  vmovaps xmm5, [rsp+0x40]
0000740ecffd7b93  vmovaps xmm6, [rsp+0x50]
0000740ecffd7b99  vmovaps xmm7, [rsp+0x60]
0000740ecffd7b9f  vmovaps xmm8, [rsp+0x70]
0000740ecffd7ba5  vmovaps xmm9, [rsp+0x80]
0000740ecffd7bae  vmovaps xmm10, [rsp+0x90]
0000740ecffd7bb7  vmovaps xmm11, [rsp+0xA0]
0000740ecffd7bc0  vmovaps xmm12, [rsp+0xB0]
0000740ecffd7bc9  vmovaps xmm13, [rsp+0xC0]
0000740ecffd7bd2  vmovaps xmm14, [rsp+0xD0]
0000740ecffd7bdb  vmovaps xmm15, [rsp+0xE0]
0000740ecffd7be4  add rsp, 0xF0
0000740ecffd7beb  pop r11
0000740ecffd7bed  pop r10
0000740ecffd7bef  pop r9
0000740ecffd7bf1  pop r8
0000740ecffd7bf3  pop rsi
0000740ecffd7bf4  pop rdi
0000740ecffd7bf5  pop rdx
0000740ecffd7bf6  pop rcx
0000740ecffd7bf7  pop rax
0000740ecffd7bf8  add rsp, 0x08
0000740ecffd7bfc  jmp 0x0000740ECFFD5DCB
0000740ecffd7c01  call 0x0000740ECFEE5820
0000740ecffd7c06  jmp 0x0000740ECFFD5DD8
0000740ecffd7c0b  sub rsp, 0x08
0000740ecffd7c0f  push rax
0000740ecffd7c10  push rcx
0000740ecffd7c11  push rdx
0000740ecffd7c12  push rdi
0000740ecffd7c13  push rsi
0000740ecffd7c14  push r8
0000740ecffd7c16  push r9
0000740ecffd7c18  push r10
0000740ecffd7c1a  push r11
0000740ecffd7c1c  sub rsp, 0xF0
0000740ecffd7c23  vmovaps [rsp], xmm0
0000740ecffd7c28  vmovaps [rsp+0x10], xmm2
0000740ecffd7c2e  vmovaps [rsp+0x20], xmm3
0000740ecffd7c34  vmovaps [rsp+0x30], xmm4
0000740ecffd7c3a  vmovaps [rsp+0x40], xmm5
0000740ecffd7c40  vmovaps [rsp+0x50], xmm6
0000740ecffd7c46  vmovaps [rsp+0x60], xmm7
0000740ecffd7c4c  vmovaps [rsp+0x70], xmm8
0000740ecffd7c52  vmovaps [rsp+0x80], xmm9
0000740ecffd7c5b  vmovaps [rsp+0x90], xmm10
0000740ecffd7c64  vmovaps [rsp+0xA0], xmm11
0000740ecffd7c6d  vmovaps [rsp+0xB0], xmm12
0000740ecffd7c76  vmovaps [rsp+0xC0], xmm13
0000740ecffd7c7f  vmovaps [rsp+0xD0], xmm14
0000740ecffd7c88  vmovaps [rsp+0xE0], xmm15
0000740ecffd7c91  sub rsp, 0x30
0000740ecffd7c95  movaps [rsp], xmm1
0000740ecffd7c99  movaps [rsp+0x10], xmm5
0000740ecffd7c9e  movaps [rsp+0x20], xmm7
0000740ecffd7ca3  lea rdi, [rsp]
0000740ecffd7ca7  mov esi, 0x00
0000740ecffd7cac  mov rax, 0x5E8249CF1530
0000740ecffd7cb6  call rax
0000740ecffd7cb8  movaps xmm1, [rsp]
0000740ecffd7cbc  add rsp, 0x30
0000740ecffd7cc0  vmovaps xmm0, [rsp]
0000740ecffd7cc5  vmovaps xmm2, [rsp+0x10]
0000740ecffd7ccb  vmovaps xmm3, [rsp+0x20]
0000740ecffd7cd1  vmovaps xmm4, [rsp+0x30]
0000740ecffd7cd7  vmovaps xmm5, [rsp+0x40]
0000740ecffd7cdd  vmovaps xmm6, [rsp+0x50]
0000740ecffd7ce3  vmovaps xmm7, [rsp+0x60]
0000740ecffd7ce9  vmovaps xmm8, [rsp+0x70]
0000740ecffd7cef  vmovaps xmm9, [rsp+0x80]
0000740ecffd7cf8  vmovaps xmm10, [rsp+0x90]
0000740ecffd7d01  vmovaps xmm11, [rsp+0xA0]
0000740ecffd7d0a  vmovaps xmm12, [rsp+0xB0]
0000740ecffd7d13  vmovaps xmm13, [rsp+0xC0]
0000740ecffd7d1c  vmovaps xmm14, [rsp+0xD0]
0000740ecffd7d25  vmovaps xmm15, [rsp+0xE0]
0000740ecffd7d2e  add rsp, 0xF0
0000740ecffd7d35  pop r11
0000740ecffd7d37  pop r10
0000740ecffd7d39  pop r9
0000740ecffd7d3b  pop r8
0000740ecffd7d3d  pop rsi
0000740ecffd7d3e  pop rdi
0000740ecffd7d3f  pop rdx
0000740ecffd7d40  pop rcx
0000740ecffd7d41  pop rax
0000740ecffd7d42  add rsp, 0x08
0000740ecffd7d46  jmp 0x0000740ECFFD5E7D
0000740ecffd7d4b  sub rsp, 0x08
0000740ecffd7d4f  push rax
0000740ecffd7d50  push rcx
0000740ecffd7d51  push rdx
0000740ecffd7d52  push rdi
0000740ecffd7d53  push rsi
0000740ecffd7d54  push r8
0000740ecffd7d56  push r9
0000740ecffd7d58  push r10
0000740ecffd7d5a  push r11
0000740ecffd7d5c  sub rsp, 0xF0
0000740ecffd7d63  vmovaps [rsp], xmm0
0000740ecffd7d68  vmovaps [rsp+0x10], xmm1
0000740ecffd7d6e  vmovaps [rsp+0x20], xmm2
0000740ecffd7d74  vmovaps [rsp+0x30], xmm3
0000740ecffd7d7a  vmovaps [rsp+0x40], xmm4
0000740ecffd7d80  vmovaps [rsp+0x50], xmm5
0000740ecffd7d86  vmovaps [rsp+0x60], xmm6
0000740ecffd7d8c  vmovaps [rsp+0x70], xmm8
0000740ecffd7d92  vmovaps [rsp+0x80], xmm9
0000740ecffd7d9b  vmovaps [rsp+0x90], xmm10
0000740ecffd7da4  vmovaps [rsp+0xA0], xmm11
0000740ecffd7dad  vmovaps [rsp+0xB0], xmm12
0000740ecffd7db6  vmovaps [rsp+0xC0], xmm13
0000740ecffd7dbf  vmovaps [rsp+0xD0], xmm14
0000740ecffd7dc8  vmovaps [rsp+0xE0], xmm15
0000740ecffd7dd1  sub rsp, 0x30
0000740ecffd7dd5  movaps [rsp], xmm7
0000740ecffd7dd9  movaps [rsp+0x10], xmm5
0000740ecffd7dde  movaps [rsp+0x20], xmm15
0000740ecffd7de4  lea rdi, [rsp]
0000740ecffd7de8  mov esi, 0x00
0000740ecffd7ded  mov rax, 0x5E8249CF1530
0000740ecffd7df7  call rax
0000740ecffd7df9  movaps xmm7, [rsp]
0000740ecffd7dfd  add rsp, 0x30
0000740ecffd7e01  vmovaps xmm0, [rsp]
0000740ecffd7e06  vmovaps xmm1, [rsp+0x10]
0000740ecffd7e0c  vmovaps xmm2, [rsp+0x20]
0000740ecffd7e12  vmovaps xmm3, [rsp+0x30]
0000740ecffd7e18  vmovaps xmm4, [rsp+0x40]
0000740ecffd7e1e  vmovaps xmm5, [rsp+0x50]
0000740ecffd7e24  vmovaps xmm6, [rsp+0x60]
0000740ecffd7e2a  vmovaps xmm8, [rsp+0x70]
0000740ecffd7e30  vmovaps xmm9, [rsp+0x80]
0000740ecffd7e39  vmovaps xmm10, [rsp+0x90]
0000740ecffd7e42  vmovaps xmm11, [rsp+0xA0]
0000740ecffd7e4b  vmovaps xmm12, [rsp+0xB0]
0000740ecffd7e54  vmovaps xmm13, [rsp+0xC0]
0000740ecffd7e5d  vmovaps xmm14, [rsp+0xD0]
0000740ecffd7e66  vmovaps xmm15, [rsp+0xE0]
0000740ecffd7e6f  add rsp, 0xF0
0000740ecffd7e76  pop r11
0000740ecffd7e78  pop r10
0000740ecffd7e7a  pop r9
0000740ecffd7e7c  pop r8
0000740ecffd7e7e  pop rsi
0000740ecffd7e7f  pop rdi
0000740ecffd7e80  pop rdx
0000740ecffd7e81  pop rcx
0000740ecffd7e82  pop rax
0000740ecffd7e83  add rsp, 0x08
0000740ecffd7e87  jmp 0x0000740ECFFD5EB3
0000740ecffd7e8c  call 0x0000740ECFED64F0
0000740ecffd7e91  jmp 0x0000740ECFFD5EC0
0000740ecffd7e96  sub rsp, 0x08
0000740ecffd7e9a  push rax
0000740ecffd7e9b  push rcx
0000740ecffd7e9c  push rdx
0000740ecffd7e9d  push rdi
0000740ecffd7e9e  push rsi
0000740ecffd7e9f  push r8
0000740ecffd7ea1  push r9
0000740ecffd7ea3  push r10
0000740ecffd7ea5  push r11
0000740ecffd7ea7  sub rsp, 0xF0
0000740ecffd7eae  vmovaps [rsp], xmm0
0000740ecffd7eb3  vmovaps [rsp+0x10], xmm1
0000740ecffd7eb9  vmovaps [rsp+0x20], xmm2
0000740ecffd7ebf  vmovaps [rsp+0x30], xmm3
0000740ecffd7ec5  vmovaps [rsp+0x40], xmm4
0000740ecffd7ecb  vmovaps [rsp+0x50], xmm5
0000740ecffd7ed1  vmovaps [rsp+0x60], xmm6
0000740ecffd7ed7  vmovaps [rsp+0x70], xmm7
0000740ecffd7edd  vmovaps [rsp+0x80], xmm8
0000740ecffd7ee6  vmovaps [rsp+0x90], xmm9
0000740ecffd7eef  vmovaps [rsp+0xA0], xmm10
0000740ecffd7ef8  vmovaps [rsp+0xB0], xmm11
0000740ecffd7f01  vmovaps [rsp+0xC0], xmm12
0000740ecffd7f0a  vmovaps [rsp+0xD0], xmm13
0000740ecffd7f13  vmovaps [rsp+0xE0], xmm14
0000740ecffd7f1c  sub rsp, 0x30
0000740ecffd7f20  movaps [rsp], xmm15
0000740ecffd7f25  movaps [rsp+0x10], xmm5
0000740ecffd7f2a  movaps [rsp+0x20], xmm3
0000740ecffd7f2f  lea rdi, [rsp]
0000740ecffd7f33  mov esi, 0x00
0000740ecffd7f38  mov rax, 0x5E8249CF1530
0000740ecffd7f42  call rax
0000740ecffd7f44  movaps xmm15, [rsp]
0000740ecffd7f49  add rsp, 0x30
0000740ecffd7f4d  vmovaps xmm0, [rsp]
0000740ecffd7f52  vmovaps xmm1, [rsp+0x10]
0000740ecffd7f58  vmovaps xmm2, [rsp+0x20]
0000740ecffd7f5e  vmovaps xmm3, [rsp+0x30]
0000740ecffd7f64  vmovaps xmm4, [rsp+0x40]
0000740ecffd7f6a  vmovaps xmm5, [rsp+0x50]
0000740ecffd7f70  vmovaps xmm6, [rsp+0x60]
0000740ecffd7f76  vmovaps xmm7, [rsp+0x70]
0000740ecffd7f7c  vmovaps xmm8, [rsp+0x80]
0000740ecffd7f85  vmovaps xmm9, [rsp+0x90]
0000740ecffd7f8e  vmovaps xmm10, [rsp+0xA0]
0000740ecffd7f97  vmovaps xmm11, [rsp+0xB0]
0000740ecffd7fa0  vmovaps xmm12, [rsp+0xC0]
0000740ecffd7fa9  vmovaps xmm13, [rsp+0xD0]
0000740ecffd7fb2  vmovaps xmm14, [rsp+0xE0]
0000740ecffd7fbb  add rsp, 0xF0
0000740ecffd7fc2  pop r11
0000740ecffd7fc4  pop r10
0000740ecffd7fc6  pop r9
0000740ecffd7fc8  pop r8
0000740ecffd7fca  pop rsi
0000740ecffd7fcb  pop rdi
0000740ecffd7fcc  pop rdx
0000740ecffd7fcd  pop rcx
0000740ecffd7fce  pop rax
0000740ecffd7fcf  add rsp, 0x08
0000740ecffd7fd3  jmp 0x0000740ECFFD5EE6
0000740ecffd7fd8  sub rsp, 0x08
0000740ecffd7fdc  push rax
0000740ecffd7fdd  push rcx
0000740ecffd7fde  push rdx
0000740ecffd7fdf  push rdi
0000740ecffd7fe0  push rsi
0000740ecffd7fe1  push r8
0000740ecffd7fe3  push r9
0000740ecffd7fe5  push r10
0000740ecffd7fe7  push r11
0000740ecffd7fe9  sub rsp, 0xF0
0000740ecffd7ff0  vmovaps [rsp], xmm0
0000740ecffd7ff5  vmovaps [rsp+0x10], xmm2
0000740ecffd7ffb  vmovaps [rsp+0x20], xmm3
0000740ecffd8001  vmovaps [rsp+0x30], xmm4
0000740ecffd8007  vmovaps [rsp+0x40], xmm5
0000740ecffd800d  vmovaps [rsp+0x50], xmm6
0000740ecffd8013  vmovaps [rsp+0x60], xmm7
0000740ecffd8019  vmovaps [rsp+0x70], xmm8
0000740ecffd801f  vmovaps [rsp+0x80], xmm9
0000740ecffd8028  vmovaps [rsp+0x90], xmm10
0000740ecffd8031  vmovaps [rsp+0xA0], xmm11
0000740ecffd803a  vmovaps [rsp+0xB0], xmm12
0000740ecffd8043  vmovaps [rsp+0xC0], xmm13
0000740ecffd804c  vmovaps [rsp+0xD0], xmm14
0000740ecffd8055  vmovaps [rsp+0xE0], xmm15
0000740ecffd805e  sub rsp, 0x30
0000740ecffd8062  movaps [rsp], xmm1
0000740ecffd8066  movaps [rsp+0x10], xmm5
0000740ecffd806b  movaps [rsp+0x20], xmm4
0000740ecffd8070  lea rdi, [rsp]
0000740ecffd8074  mov esi, 0x00
0000740ecffd8079  mov rax, 0x5E8249CF1530
0000740ecffd8083  call rax
0000740ecffd8085  movaps xmm1, [rsp]
0000740ecffd8089  add rsp, 0x30
0000740ecffd808d  vmovaps xmm0, [rsp]
0000740ecffd8092  vmovaps xmm2, [rsp+0x10]
0000740ecffd8098  vmovaps xmm3, [rsp+0x20]
0000740ecffd809e  vmovaps xmm4, [rsp+0x30]
0000740ecffd80a4  vmovaps xmm5, [rsp+0x40]
0000740ecffd80aa  vmovaps xmm6, [rsp+0x50]
0000740ecffd80b0  vmovaps xmm7, [rsp+0x60]
0000740ecffd80b6  vmovaps xmm8, [rsp+0x70]
0000740ecffd80bc  vmovaps xmm9, [rsp+0x80]
0000740ecffd80c5  vmovaps xmm10, [rsp+0x90]
0000740ecffd80ce  vmovaps xmm11, [rsp+0xA0]
0000740ecffd80d7  vmovaps xmm12, [rsp+0xB0]
0000740ecffd80e0  vmovaps xmm13, [rsp+0xC0]
0000740ecffd80e9  vmovaps xmm14, [rsp+0xD0]
0000740ecffd80f2  vmovaps xmm15, [rsp+0xE0]
0000740ecffd80fb  add rsp, 0xF0
0000740ecffd8102  pop r11
0000740ecffd8104  pop r10
0000740ecffd8106  pop r9
0000740ecffd8108  pop r8
0000740ecffd810a  pop rsi
0000740ecffd810b  pop rdi
0000740ecffd810c  pop rdx
0000740ecffd810d  pop rcx
0000740ecffd810e  pop rax
0000740ecffd810f  add rsp, 0x08
0000740ecffd8113  jmp 0x0000740ECFFD5F06
0000740ecffd8118  sub rsp, 0x08
0000740ecffd811c  push rax
0000740ecffd811d  push rcx
0000740ecffd811e  push rdx
0000740ecffd811f  push rdi
0000740ecffd8120  push rsi
0000740ecffd8121  push r8
0000740ecffd8123  push r9
0000740ecffd8125  push r10
0000740ecffd8127  push r11
0000740ecffd8129  sub rsp, 0xF0
0000740ecffd8130  vmovaps [rsp], xmm0
0000740ecffd8135  vmovaps [rsp+0x10], xmm1
0000740ecffd813b  vmovaps [rsp+0x20], xmm2
0000740ecffd8141  vmovaps [rsp+0x30], xmm3
0000740ecffd8147  vmovaps [rsp+0x40], xmm5
0000740ecffd814d  vmovaps [rsp+0x50], xmm6
0000740ecffd8153  vmovaps [rsp+0x60], xmm7
0000740ecffd8159  vmovaps [rsp+0x70], xmm8
0000740ecffd815f  vmovaps [rsp+0x80], xmm9
0000740ecffd8168  vmovaps [rsp+0x90], xmm10
0000740ecffd8171  vmovaps [rsp+0xA0], xmm11
0000740ecffd817a  vmovaps [rsp+0xB0], xmm12
0000740ecffd8183  vmovaps [rsp+0xC0], xmm13
0000740ecffd818c  vmovaps [rsp+0xD0], xmm14
0000740ecffd8195  vmovaps [rsp+0xE0], xmm15
0000740ecffd819e  sub rsp, 0x30
0000740ecffd81a2  movaps [rsp], xmm4
0000740ecffd81a6  movaps [rsp+0x10], xmm3
0000740ecffd81ab  movaps [rsp+0x20], xmm5
0000740ecffd81b0  lea rdi, [rsp]
0000740ecffd81b4  mov esi, 0x00
0000740ecffd81b9  mov rax, 0x5E8249CF1530
0000740ecffd81c3  call rax
0000740ecffd81c5  movaps xmm4, [rsp]
0000740ecffd81c9  add rsp, 0x30
0000740ecffd81cd  vmovaps xmm0, [rsp]
0000740ecffd81d2  vmovaps xmm1, [rsp+0x10]
0000740ecffd81d8  vmovaps xmm2, [rsp+0x20]
0000740ecffd81de  vmovaps xmm3, [rsp+0x30]
0000740ecffd81e4  vmovaps xmm5, [rsp+0x40]
0000740ecffd81ea  vmovaps xmm6, [rsp+0x50]
0000740ecffd81f0  vmovaps xmm7, [rsp+0x60]
0000740ecffd81f6  vmovaps xmm8, [rsp+0x70]
0000740ecffd81fc  vmovaps xmm9, [rsp+0x80]
0000740ecffd8205  vmovaps xmm10, [rsp+0x90]
0000740ecffd820e  vmovaps xmm11, [rsp+0xA0]
0000740ecffd8217  vmovaps xmm12, [rsp+0xB0]
0000740ecffd8220  vmovaps xmm13, [rsp+0xC0]
0000740ecffd8229  vmovaps xmm14, [rsp+0xD0]
0000740ecffd8232  vmovaps xmm15, [rsp+0xE0]
0000740ecffd823b  add rsp, 0xF0
0000740ecffd8242  pop r11
0000740ecffd8244  pop r10
0000740ecffd8246  pop r9
0000740ecffd8248  pop r8
0000740ecffd824a  pop rsi
0000740ecffd824b  pop rdi
0000740ecffd824c  pop rdx
0000740ecffd824d  pop rcx
0000740ecffd824e  pop rax
0000740ecffd824f  add rsp, 0x08
0000740ecffd8253  jmp 0x0000740ECFFD5F54
0000740ecffd8258  call 0x0000740ECFED64F0
0000740ecffd825d  jmp 0x0000740ECFFD5F61
0000740ecffd8262  sub rsp, 0x08
0000740ecffd8266  push rax
0000740ecffd8267  push rcx
0000740ecffd8268  push rdx
0000740ecffd8269  push rdi
0000740ecffd826a  push rsi
0000740ecffd826b  push r8
0000740ecffd826d  push r9
0000740ecffd826f  push r10
0000740ecffd8271  push r11
0000740ecffd8273  sub rsp, 0xF0
0000740ecffd827a  vmovaps [rsp], xmm0
0000740ecffd827f  vmovaps [rsp+0x10], xmm1
0000740ecffd8285  vmovaps [rsp+0x20], xmm2
0000740ecffd828b  vmovaps [rsp+0x30], xmm3
0000740ecffd8291  vmovaps [rsp+0x40], xmm4
0000740ecffd8297  vmovaps [rsp+0x50], xmm6
0000740ecffd829d  vmovaps [rsp+0x60], xmm7
0000740ecffd82a3  vmovaps [rsp+0x70], xmm8
0000740ecffd82a9  vmovaps [rsp+0x80], xmm9
0000740ecffd82b2  vmovaps [rsp+0x90], xmm10
0000740ecffd82bb  vmovaps [rsp+0xA0], xmm11
0000740ecffd82c4  vmovaps [rsp+0xB0], xmm12
0000740ecffd82cd  vmovaps [rsp+0xC0], xmm13
0000740ecffd82d6  vmovaps [rsp+0xD0], xmm14
0000740ecffd82df  vmovaps [rsp+0xE0], xmm15
0000740ecffd82e8  sub rsp, 0x30
0000740ecffd82ec  movaps [rsp], xmm5
0000740ecffd82f0  movaps [rsp+0x10], xmm6
0000740ecffd82f5  movaps [rsp+0x20], xmm3
0000740ecffd82fa  lea rdi, [rsp]
0000740ecffd82fe  mov esi, 0x00
0000740ecffd8303  mov rax, 0x5E8249CF1530
0000740ecffd830d  call rax
0000740ecffd830f  movaps xmm5, [rsp]
0000740ecffd8313  add rsp, 0x30
0000740ecffd8317  vmovaps xmm0, [rsp]
0000740ecffd831c  vmovaps xmm1, [rsp+0x10]
0000740ecffd8322  vmovaps xmm2, [rsp+0x20]
0000740ecffd8328  vmovaps xmm3, [rsp+0x30]
0000740ecffd832e  vmovaps xmm4, [rsp+0x40]
0000740ecffd8334  vmovaps xmm6, [rsp+0x50]
0000740ecffd833a  vmovaps xmm7, [rsp+0x60]
0000740ecffd8340  vmovaps xmm8, [rsp+0x70]
0000740ecffd8346  vmovaps xmm9, [rsp+0x80]
0000740ecffd834f  vmovaps xmm10, [rsp+0x90]
0000740ecffd8358  vmovaps xmm11, [rsp+0xA0]
0000740ecffd8361  vmovaps xmm12, [rsp+0xB0]
0000740ecffd836a  vmovaps xmm13, [rsp+0xC0]
0000740ecffd8373  vmovaps xmm14, [rsp+0xD0]
0000740ecffd837c  vmovaps xmm15, [rsp+0xE0]
0000740ecffd8385  add rsp, 0xF0
0000740ecffd838c  pop r11
0000740ecffd838e  pop r10
0000740ecffd8390  pop r9
0000740ecffd8392  pop r8
0000740ecffd8394  pop rsi
0000740ecffd8395  pop rdi
0000740ecffd8396  pop rdx
0000740ecffd8397  pop rcx
0000740ecffd8398  pop rax
0000740ecffd8399  add rsp, 0x08
0000740ecffd839d  jmp 0x0000740ECFFD5F87
0000740ecffd83a2  sub rsp, 0x08
0000740ecffd83a6  push rax
0000740ecffd83a7  push rcx
0000740ecffd83a8  push rdx
0000740ecffd83a9  push rdi
0000740ecffd83aa  push rsi
0000740ecffd83ab  push r8
0000740ecffd83ad  push r9
0000740ecffd83af  push r10
0000740ecffd83b1  push r11
0000740ecffd83b3  sub rsp, 0xF0
0000740ecffd83ba  vmovaps [rsp], xmm0
0000740ecffd83bf  vmovaps [rsp+0x10], xmm1
0000740ecffd83c5  vmovaps [rsp+0x20], xmm2
0000740ecffd83cb  vmovaps [rsp+0x30], xmm3
0000740ecffd83d1  vmovaps [rsp+0x40], xmm4
0000740ecffd83d7  vmovaps [rsp+0x50], xmm5
0000740ecffd83dd  vmovaps [rsp+0x60], xmm7
0000740ecffd83e3  vmovaps [rsp+0x70], xmm8
0000740ecffd83e9  vmovaps [rsp+0x80], xmm9
0000740ecffd83f2  vmovaps [rsp+0x90], xmm10
0000740ecffd83fb  vmovaps [rsp+0xA0], xmm11
0000740ecffd8404  vmovaps [rsp+0xB0], xmm12
0000740ecffd840d  vmovaps [rsp+0xC0], xmm13
0000740ecffd8416  vmovaps [rsp+0xD0], xmm14
0000740ecffd841f  vmovaps [rsp+0xE0], xmm15
0000740ecffd8428  sub rsp, 0x30
0000740ecffd842c  movaps [rsp], xmm6
0000740ecffd8430  movaps [rsp+0x10], xmm9
0000740ecffd8436  movaps [rsp+0x20], xmm1
0000740ecffd843b  lea rdi, [rsp]
0000740ecffd843f  mov esi, 0x00
0000740ecffd8444  mov rax, 0x5E8249CF1530
0000740ecffd844e  call rax
0000740ecffd8450  movaps xmm6, [rsp]
0000740ecffd8454  add rsp, 0x30
0000740ecffd8458  vmovaps xmm0, [rsp]
0000740ecffd845d  vmovaps xmm1, [rsp+0x10]
0000740ecffd8463  vmovaps xmm2, [rsp+0x20]
0000740ecffd8469  vmovaps xmm3, [rsp+0x30]
0000740ecffd846f  vmovaps xmm4, [rsp+0x40]
0000740ecffd8475  vmovaps xmm5, [rsp+0x50]
0000740ecffd847b  vmovaps xmm7, [rsp+0x60]
0000740ecffd8481  vmovaps xmm8, [rsp+0x70]
0000740ecffd8487  vmovaps xmm9, [rsp+0x80]
0000740ecffd8490  vmovaps xmm10, [rsp+0x90]
0000740ecffd8499  vmovaps xmm11, [rsp+0xA0]
0000740ecffd84a2  vmovaps xmm12, [rsp+0xB0]
0000740ecffd84ab  vmovaps xmm13, [rsp+0xC0]
0000740ecffd84b4  vmovaps xmm14, [rsp+0xD0]
0000740ecffd84bd  vmovaps xmm15, [rsp+0xE0]
0000740ecffd84c6  add rsp, 0xF0
0000740ecffd84cd  pop r11
0000740ecffd84cf  pop r10
0000740ecffd84d1  pop r9
0000740ecffd84d3  pop r8
0000740ecffd84d5  pop rsi
0000740ecffd84d6  pop rdi
0000740ecffd84d7  pop rdx
0000740ecffd84d8  pop rcx
0000740ecffd84d9  pop rax
0000740ecffd84da  add rsp, 0x08
0000740ecffd84de  jmp 0x0000740ECFFD5FAB
0000740ecffd84e3  sub rsp, 0x08
0000740ecffd84e7  push rax
0000740ecffd84e8  push rcx
0000740ecffd84e9  push rdx
0000740ecffd84ea  push rdi
0000740ecffd84eb  push rsi
0000740ecffd84ec  push r8
0000740ecffd84ee  push r9
0000740ecffd84f0  push r10
0000740ecffd84f2  push r11
0000740ecffd84f4  sub rsp, 0xF0
0000740ecffd84fb  vmovaps [rsp], xmm0
0000740ecffd8500  vmovaps [rsp+0x10], xmm1
0000740ecffd8506  vmovaps [rsp+0x20], xmm2
0000740ecffd850c  vmovaps [rsp+0x30], xmm3
0000740ecffd8512  vmovaps [rsp+0x40], xmm4
0000740ecffd8518  vmovaps [rsp+0x50], xmm5
0000740ecffd851e  vmovaps [rsp+0x60], xmm6
0000740ecffd8524  vmovaps [rsp+0x70], xmm7
0000740ecffd852a  vmovaps [rsp+0x80], xmm8
0000740ecffd8533  vmovaps [rsp+0x90], xmm10
0000740ecffd853c  vmovaps [rsp+0xA0], xmm11
0000740ecffd8545  vmovaps [rsp+0xB0], xmm12
0000740ecffd854e  vmovaps [rsp+0xC0], xmm13
0000740ecffd8557  vmovaps [rsp+0xD0], xmm14
0000740ecffd8560  vmovaps [rsp+0xE0], xmm15
0000740ecffd8569  sub rsp, 0x30
0000740ecffd856d  movaps [rsp], xmm9
0000740ecffd8572  movaps [rsp+0x10], xmm3
0000740ecffd8577  movaps [rsp+0x20], xmm1
0000740ecffd857c  lea rdi, [rsp]
0000740ecffd8580  mov esi, 0x00
0000740ecffd8585  mov rax, 0x5E8249CF1530
0000740ecffd858f  call rax
0000740ecffd8591  movaps xmm9, [rsp]
0000740ecffd8596  add rsp, 0x30
0000740ecffd859a  vmovaps xmm0, [rsp]
0000740ecffd859f  vmovaps xmm1, [rsp+0x10]
0000740ecffd85a5  vmovaps xmm2, [rsp+0x20]
0000740ecffd85ab  vmovaps xmm3, [rsp+0x30]
0000740ecffd85b1  vmovaps xmm4, [rsp+0x40]
0000740ecffd85b7  vmovaps xmm5, [rsp+0x50]
0000740ecffd85bd  vmovaps xmm6, [rsp+0x60]
0000740ecffd85c3  vmovaps xmm7, [rsp+0x70]
0000740ecffd85c9  vmovaps xmm8, [rsp+0x80]
0000740ecffd85d2  vmovaps xmm10, [rsp+0x90]
0000740ecffd85db  vmovaps xmm11, [rsp+0xA0]
0000740ecffd85e4  vmovaps xmm12, [rsp+0xB0]
0000740ecffd85ed  vmovaps xmm13, [rsp+0xC0]
0000740ecffd85f6  vmovaps xmm14, [rsp+0xD0]
0000740ecffd85ff  vmovaps xmm15, [rsp+0xE0]
0000740ecffd8608  add rsp, 0xF0
0000740ecffd860f  pop r11
0000740ecffd8611  pop r10
0000740ecffd8613  pop r9
0000740ecffd8615  pop r8
0000740ecffd8617  pop rsi
0000740ecffd8618  pop rdi
0000740ecffd8619  pop rdx
0000740ecffd861a  pop rcx
0000740ecffd861b  pop rax
0000740ecffd861c  add rsp, 0x08
0000740ecffd8620  jmp 0x0000740ECFFD5FF7
0000740ecffd8625  call 0x0000740ECFED64F0
0000740ecffd862a  jmp 0x0000740ECFFD6004
0000740ecffd862f  sub rsp, 0x08
0000740ecffd8633  push rax
0000740ecffd8634  push rcx
0000740ecffd8635  push rdx
0000740ecffd8636  push rdi
0000740ecffd8637  push rsi
0000740ecffd8638  push r8
0000740ecffd863a  push r9
0000740ecffd863c  push r10
0000740ecffd863e  push r11
0000740ecffd8640  sub rsp, 0xF0
0000740ecffd8647  vmovaps [rsp], xmm0
0000740ecffd864c  vmovaps [rsp+0x10], xmm1
0000740ecffd8652  vmovaps [rsp+0x20], xmm2
0000740ecffd8658  vmovaps [rsp+0x30], xmm3
0000740ecffd865e  vmovaps [rsp+0x40], xmm4
0000740ecffd8664  vmovaps [rsp+0x50], xmm5
0000740ecffd866a  vmovaps [rsp+0x60], xmm6
0000740ecffd8670  vmovaps [rsp+0x70], xmm7
0000740ecffd8676  vmovaps [rsp+0x80], xmm8
0000740ecffd867f  vmovaps [rsp+0x90], xmm9
0000740ecffd8688  vmovaps [rsp+0xA0], xmm10
0000740ecffd8691  vmovaps [rsp+0xB0], xmm11
0000740ecffd869a  vmovaps [rsp+0xC0], xmm12
0000740ecffd86a3  vmovaps [rsp+0xD0], xmm13
0000740ecffd86ac  vmovaps [rsp+0xE0], xmm14
0000740ecffd86b5  sub rsp, 0x30
0000740ecffd86b9  movaps [rsp], xmm15
0000740ecffd86be  movaps [rsp+0x10], xmm3
0000740ecffd86c3  movaps [rsp+0x20], xmm7
0000740ecffd86c8  lea rdi, [rsp]
0000740ecffd86cc  mov esi, 0x00
0000740ecffd86d1  mov rax, 0x5E8249CF1530
0000740ecffd86db  call rax
0000740ecffd86dd  movaps xmm15, [rsp]
0000740ecffd86e2  add rsp, 0x30
0000740ecffd86e6  vmovaps xmm0, [rsp]
0000740ecffd86eb  vmovaps xmm1, [rsp+0x10]
0000740ecffd86f1  vmovaps xmm2, [rsp+0x20]
0000740ecffd86f7  vmovaps xmm3, [rsp+0x30]
0000740ecffd86fd  vmovaps xmm4, [rsp+0x40]
0000740ecffd8703  vmovaps xmm5, [rsp+0x50]
0000740ecffd8709  vmovaps xmm6, [rsp+0x60]
0000740ecffd870f  vmovaps xmm7, [rsp+0x70]
0000740ecffd8715  vmovaps xmm8, [rsp+0x80]
0000740ecffd871e  vmovaps xmm9, [rsp+0x90]
0000740ecffd8727  vmovaps xmm10, [rsp+0xA0]
0000740ecffd8730  vmovaps xmm11, [rsp+0xB0]
0000740ecffd8739  vmovaps xmm12, [rsp+0xC0]
0000740ecffd8742  vmovaps xmm13, [rsp+0xD0]
0000740ecffd874b  vmovaps xmm14, [rsp+0xE0]
0000740ecffd8754  add rsp, 0xF0
0000740ecffd875b  pop r11
0000740ecffd875d  pop r10
0000740ecffd875f  pop r9
0000740ecffd8761  pop r8
0000740ecffd8763  pop rsi
0000740ecffd8764  pop rdi
0000740ecffd8765  pop rdx
0000740ecffd8766  pop rcx
0000740ecffd8767  pop rax
0000740ecffd8768  add rsp, 0x08
0000740ecffd876c  jmp 0x0000740ECFFD6030
0000740ecffd8771  sub rsp, 0x08
0000740ecffd8775  push rax
0000740ecffd8776  push rcx
0000740ecffd8777  push rdx
0000740ecffd8778  push rdi
0000740ecffd8779  push rsi
0000740ecffd877a  push r8
0000740ecffd877c  push r9
0000740ecffd877e  push r10
0000740ecffd8780  push r11
0000740ecffd8782  sub rsp, 0xF0
0000740ecffd8789  vmovaps [rsp], xmm0
0000740ecffd878e  vmovaps [rsp+0x10], xmm1
0000740ecffd8794  vmovaps [rsp+0x20], xmm2
0000740ecffd879a  vmovaps [rsp+0x30], xmm4
0000740ecffd87a0  vmovaps [rsp+0x40], xmm5
0000740ecffd87a6  vmovaps [rsp+0x50], xmm6
0000740ecffd87ac  vmovaps [rsp+0x60], xmm7
0000740ecffd87b2  vmovaps [rsp+0x70], xmm8
0000740ecffd87b8  vmovaps [rsp+0x80], xmm9
0000740ecffd87c1  vmovaps [rsp+0x90], xmm10
0000740ecffd87ca  vmovaps [rsp+0xA0], xmm11
0000740ecffd87d3  vmovaps [rsp+0xB0], xmm12
0000740ecffd87dc  vmovaps [rsp+0xC0], xmm13
0000740ecffd87e5  vmovaps [rsp+0xD0], xmm14
0000740ecffd87ee  vmovaps [rsp+0xE0], xmm15
0000740ecffd87f7  sub rsp, 0x30
0000740ecffd87fb  movaps [rsp], xmm3
0000740ecffd87ff  movaps [rsp+0x10], xmm1
0000740ecffd8804  movaps [rsp+0x20], xmm15
0000740ecffd880a  lea rdi, [rsp]
0000740ecffd880e  mov esi, 0x00
0000740ecffd8813  mov rax, 0x5E8249CF1530
0000740ecffd881d  call rax
0000740ecffd881f  movaps xmm3, [rsp]
0000740ecffd8823  add rsp, 0x30
0000740ecffd8827  vmovaps xmm0, [rsp]
0000740ecffd882c  vmovaps xmm1, [rsp+0x10]
0000740ecffd8832  vmovaps xmm2, [rsp+0x20]
0000740ecffd8838  vmovaps xmm4, [rsp+0x30]
0000740ecffd883e  vmovaps xmm5, [rsp+0x40]
0000740ecffd8844  vmovaps xmm6, [rsp+0x50]
0000740ecffd884a  vmovaps xmm7, [rsp+0x60]
0000740ecffd8850  vmovaps xmm8, [rsp+0x70]
0000740ecffd8856  vmovaps xmm9, [rsp+0x80]
0000740ecffd885f  vmovaps xmm10, [rsp+0x90]
0000740ecffd8868  vmovaps xmm11, [rsp+0xA0]
0000740ecffd8871  vmovaps xmm12, [rsp+0xB0]
0000740ecffd887a  vmovaps xmm13, [rsp+0xC0]
0000740ecffd8883  vmovaps xmm14, [rsp+0xD0]
0000740ecffd888c  vmovaps xmm15, [rsp+0xE0]
0000740ecffd8895  add rsp, 0xF0
0000740ecffd889c  pop r11
0000740ecffd889e  pop r10
0000740ecffd88a0  pop r9
0000740ecffd88a2  pop r8
0000740ecffd88a4  pop rsi
0000740ecffd88a5  pop rdi
0000740ecffd88a6  pop rdx
0000740ecffd88a7  pop rcx
0000740ecffd88a8  pop rax
0000740ecffd88a9  add rsp, 0x08
0000740ecffd88ad  jmp 0x0000740ECFFD60BF
0000740ecffd88b2  call 0x0000740ECFED64F0
0000740ecffd88b7  jmp 0x0000740ECFFD60C9
0000740ecffd88bc  sub rsp, 0x08
0000740ecffd88c0  push rax
0000740ecffd88c1  push rcx
0000740ecffd88c2  push rdx
0000740ecffd88c3  push rdi
0000740ecffd88c4  push rsi
0000740ecffd88c5  push r8
0000740ecffd88c7  push r9
0000740ecffd88c9  push r10
0000740ecffd88cb  push r11
0000740ecffd88cd  sub rsp, 0xF0
0000740ecffd88d4  vmovaps [rsp], xmm0
0000740ecffd88d9  vmovaps [rsp+0x10], xmm1
0000740ecffd88df  vmovaps [rsp+0x20], xmm2
0000740ecffd88e5  vmovaps [rsp+0x30], xmm3
0000740ecffd88eb  vmovaps [rsp+0x40], xmm4
0000740ecffd88f1  vmovaps [rsp+0x50], xmm5
0000740ecffd88f7  vmovaps [rsp+0x60], xmm6
0000740ecffd88fd  vmovaps [rsp+0x70], xmm7
0000740ecffd8903  vmovaps [rsp+0x80], xmm8
0000740ecffd890c  vmovaps [rsp+0x90], xmm9
0000740ecffd8915  vmovaps [rsp+0xA0], xmm10
0000740ecffd891e  vmovaps [rsp+0xB0], xmm11
0000740ecffd8927  vmovaps [rsp+0xC0], xmm12
0000740ecffd8930  vmovaps [rsp+0xD0], xmm13
0000740ecffd8939  vmovaps [rsp+0xE0], xmm14
0000740ecffd8942  sub rsp, 0x30
0000740ecffd8946  movaps [rsp], xmm15
0000740ecffd894b  movaps [rsp+0x10], xmm14
0000740ecffd8951  movaps [rsp+0x20], xmm4
0000740ecffd8956  lea rdi, [rsp]
0000740ecffd895a  mov esi, 0x00
0000740ecffd895f  mov rax, 0x5E8249CF1530
0000740ecffd8969  call rax
0000740ecffd896b  movaps xmm15, [rsp]
0000740ecffd8970  add rsp, 0x30
0000740ecffd8974  vmovaps xmm0, [rsp]
0000740ecffd8979  vmovaps xmm1, [rsp+0x10]
0000740ecffd897f  vmovaps xmm2, [rsp+0x20]
0000740ecffd8985  vmovaps xmm3, [rsp+0x30]
0000740ecffd898b  vmovaps xmm4, [rsp+0x40]
0000740ecffd8991  vmovaps xmm5, [rsp+0x50]
0000740ecffd8997  vmovaps xmm6, [rsp+0x60]
0000740ecffd899d  vmovaps xmm7, [rsp+0x70]
0000740ecffd89a3  vmovaps xmm8, [rsp+0x80]
0000740ecffd89ac  vmovaps xmm9, [rsp+0x90]
0000740ecffd89b5  vmovaps xmm10, [rsp+0xA0]
0000740ecffd89be  vmovaps xmm11, [rsp+0xB0]
0000740ecffd89c7  vmovaps xmm12, [rsp+0xC0]
0000740ecffd89d0  vmovaps xmm13, [rsp+0xD0]
0000740ecffd89d9  vmovaps xmm14, [rsp+0xE0]
0000740ecffd89e2  add rsp, 0xF0
0000740ecffd89e9  pop r11
0000740ecffd89eb  pop r10
0000740ecffd89ed  pop r9
0000740ecffd89ef  pop r8
0000740ecffd89f1  pop rsi
0000740ecffd89f2  pop rdi
0000740ecffd89f3  pop rdx
0000740ecffd89f4  pop rcx
0000740ecffd89f5  pop rax
0000740ecffd89f6  add rsp, 0x08
0000740ecffd89fa  jmp 0x0000740ECFFD60F7
0000740ecffd89ff  sub rsp, 0x08
0000740ecffd8a03  push rax
0000740ecffd8a04  push rcx
0000740ecffd8a05  push rdx
0000740ecffd8a06  push rdi
0000740ecffd8a07  push rsi
0000740ecffd8a08  push r8
0000740ecffd8a0a  push r9
0000740ecffd8a0c  push r10
0000740ecffd8a0e  push r11
0000740ecffd8a10  sub rsp, 0xF0
0000740ecffd8a17  vmovaps [rsp], xmm0
0000740ecffd8a1c  vmovaps [rsp+0x10], xmm1
0000740ecffd8a22  vmovaps [rsp+0x20], xmm2
0000740ecffd8a28  vmovaps [rsp+0x30], xmm3
0000740ecffd8a2e  vmovaps [rsp+0x40], xmm4
0000740ecffd8a34  vmovaps [rsp+0x50], xmm5
0000740ecffd8a3a  vmovaps [rsp+0x60], xmm6
0000740ecffd8a40  vmovaps [rsp+0x70], xmm7
0000740ecffd8a46  vmovaps [rsp+0x80], xmm8
0000740ecffd8a4f  vmovaps [rsp+0x90], xmm9
0000740ecffd8a58  vmovaps [rsp+0xA0], xmm10
0000740ecffd8a61  vmovaps [rsp+0xB0], xmm11
0000740ecffd8a6a  vmovaps [rsp+0xC0], xmm12
0000740ecffd8a73  vmovaps [rsp+0xD0], xmm13
0000740ecffd8a7c  vmovaps [rsp+0xE0], xmm15
0000740ecffd8a85  sub rsp, 0x30
0000740ecffd8a89  movaps [rsp], xmm14
0000740ecffd8a8e  movaps [rsp+0x10], xmm2
0000740ecffd8a93  movaps [rsp+0x20], xmm1
0000740ecffd8a98  lea rdi, [rsp]
0000740ecffd8a9c  mov esi, 0x00
0000740ecffd8aa1  mov rax, 0x5E8249CF1530
0000740ecffd8aab  call rax
0000740ecffd8aad  movaps xmm14, [rsp]
0000740ecffd8ab2  add rsp, 0x30
0000740ecffd8ab6  vmovaps xmm0, [rsp]
0000740ecffd8abb  vmovaps xmm1, [rsp+0x10]
0000740ecffd8ac1  vmovaps xmm2, [rsp+0x20]
0000740ecffd8ac7  vmovaps xmm3, [rsp+0x30]
0000740ecffd8acd  vmovaps xmm4, [rsp+0x40]
0000740ecffd8ad3  vmovaps xmm5, [rsp+0x50]
0000740ecffd8ad9  vmovaps xmm6, [rsp+0x60]
0000740ecffd8adf  vmovaps xmm7, [rsp+0x70]
0000740ecffd8ae5  vmovaps xmm8, [rsp+0x80]
0000740ecffd8aee  vmovaps xmm9, [rsp+0x90]
0000740ecffd8af7  vmovaps xmm10, [rsp+0xA0]
0000740ecffd8b00  vmovaps xmm11, [rsp+0xB0]
0000740ecffd8b09  vmovaps xmm12, [rsp+0xC0]
0000740ecffd8b12  vmovaps xmm13, [rsp+0xD0]
0000740ecffd8b1b  vmovaps xmm15, [rsp+0xE0]
0000740ecffd8b24  add rsp, 0xF0
0000740ecffd8b2b  pop r11
0000740ecffd8b2d  pop r10
0000740ecffd8b2f  pop r9
0000740ecffd8b31  pop r8
0000740ecffd8b33  pop rsi
0000740ecffd8b34  pop rdi
0000740ecffd8b35  pop rdx
0000740ecffd8b36  pop rcx
0000740ecffd8b37  pop rax
0000740ecffd8b38  add rsp, 0x08
0000740ecffd8b3c  jmp 0x0000740ECFFD611D
0000740ecffd8b41  sub rsp, 0x08
0000740ecffd8b45  push rax
0000740ecffd8b46  push rcx
0000740ecffd8b47  push rdx
0000740ecffd8b48  push rdi
0000740ecffd8b49  push rsi
0000740ecffd8b4a  push r8
0000740ecffd8b4c  push r9
0000740ecffd8b4e  push r10
0000740ecffd8b50  push r11
0000740ecffd8b52  sub rsp, 0xF0
0000740ecffd8b59  vmovaps [rsp], xmm0
0000740ecffd8b5e  vmovaps [rsp+0x10], xmm2
0000740ecffd8b64  vmovaps [rsp+0x20], xmm3
0000740ecffd8b6a  vmovaps [rsp+0x30], xmm4
0000740ecffd8b70  vmovaps [rsp+0x40], xmm5
0000740ecffd8b76  vmovaps [rsp+0x50], xmm6
0000740ecffd8b7c  vmovaps [rsp+0x60], xmm7
0000740ecffd8b82  vmovaps [rsp+0x70], xmm8
0000740ecffd8b88  vmovaps [rsp+0x80], xmm9
0000740ecffd8b91  vmovaps [rsp+0x90], xmm10
0000740ecffd8b9a  vmovaps [rsp+0xA0], xmm11
0000740ecffd8ba3  vmovaps [rsp+0xB0], xmm12
0000740ecffd8bac  vmovaps [rsp+0xC0], xmm13
0000740ecffd8bb5  vmovaps [rsp+0xD0], xmm14
0000740ecffd8bbe  vmovaps [rsp+0xE0], xmm15
0000740ecffd8bc7  sub rsp, 0x30
0000740ecffd8bcb  movaps [rsp], xmm1
0000740ecffd8bcf  movaps [rsp+0x10], xmm4
0000740ecffd8bd4  movaps [rsp+0x20], xmm9
0000740ecffd8bda  lea rdi, [rsp]
0000740ecffd8bde  mov esi, 0x00
0000740ecffd8be3  mov rax, 0x5E8249CF1530
0000740ecffd8bed  call rax
0000740ecffd8bef  movaps xmm1, [rsp]
0000740ecffd8bf3  add rsp, 0x30
0000740ecffd8bf7  vmovaps xmm0, [rsp]
0000740ecffd8bfc  vmovaps xmm2, [rsp+0x10]
0000740ecffd8c02  vmovaps xmm3, [rsp+0x20]
0000740ecffd8c08  vmovaps xmm4, [rsp+0x30]
0000740ecffd8c0e  vmovaps xmm5, [rsp+0x40]
0000740ecffd8c14  vmovaps xmm6, [rsp+0x50]
0000740ecffd8c1a  vmovaps xmm7, [rsp+0x60]
0000740ecffd8c20  vmovaps xmm8, [rsp+0x70]
0000740ecffd8c26  vmovaps xmm9, [rsp+0x80]
0000740ecffd8c2f  vmovaps xmm10, [rsp+0x90]
0000740ecffd8c38  vmovaps xmm11, [rsp+0xA0]
0000740ecffd8c41  vmovaps xmm12, [rsp+0xB0]
0000740ecffd8c4a  vmovaps xmm13, [rsp+0xC0]
0000740ecffd8c53  vmovaps xmm14, [rsp+0xD0]
0000740ecffd8c5c  vmovaps xmm15, [rsp+0xE0]
0000740ecffd8c65  add rsp, 0xF0
0000740ecffd8c6c  pop r11
0000740ecffd8c6e  pop r10
0000740ecffd8c70  pop r9
0000740ecffd8c72  pop r8
0000740ecffd8c74  pop rsi
0000740ecffd8c75  pop rdi
0000740ecffd8c76  pop rdx
0000740ecffd8c77  pop rcx
0000740ecffd8c78  pop rax
0000740ecffd8c79  add rsp, 0x08
0000740ecffd8c7d  jmp 0x0000740ECFFD613B
0000740ecffd8c82  sub rsp, 0x08
0000740ecffd8c86  push rax
0000740ecffd8c87  push rcx
0000740ecffd8c88  push rdx
0000740ecffd8c89  push rdi
0000740ecffd8c8a  push rsi
0000740ecffd8c8b  push r8
0000740ecffd8c8d  push r9
0000740ecffd8c8f  push r10
0000740ecffd8c91  push r11
0000740ecffd8c93  sub rsp, 0xF0
0000740ecffd8c9a  vmovaps [rsp], xmm0
0000740ecffd8c9f  vmovaps [rsp+0x10], xmm1
0000740ecffd8ca5  vmovaps [rsp+0x20], xmm2
0000740ecffd8cab  vmovaps [rsp+0x30], xmm3
0000740ecffd8cb1  vmovaps [rsp+0x40], xmm5
0000740ecffd8cb7  vmovaps [rsp+0x50], xmm6
0000740ecffd8cbd  vmovaps [rsp+0x60], xmm7
0000740ecffd8cc3  vmovaps [rsp+0x70], xmm8
0000740ecffd8cc9  vmovaps [rsp+0x80], xmm9
0000740ecffd8cd2  vmovaps [rsp+0x90], xmm10
0000740ecffd8cdb  vmovaps [rsp+0xA0], xmm11
0000740ecffd8ce4  vmovaps [rsp+0xB0], xmm12
0000740ecffd8ced  vmovaps [rsp+0xC0], xmm13
0000740ecffd8cf6  vmovaps [rsp+0xD0], xmm14
0000740ecffd8cff  vmovaps [rsp+0xE0], xmm15
0000740ecffd8d08  sub rsp, 0x30
0000740ecffd8d0c  movaps [rsp], xmm4
0000740ecffd8d10  movaps [rsp+0x10], xmm2
0000740ecffd8d15  movaps [rsp+0x20], xmm9
0000740ecffd8d1b  lea rdi, [rsp]
0000740ecffd8d1f  mov esi, 0x00
0000740ecffd8d24  mov rax, 0x5E8249CF1530
0000740ecffd8d2e  call rax
0000740ecffd8d30  movaps xmm4, [rsp]
0000740ecffd8d34  add rsp, 0x30
0000740ecffd8d38  vmovaps xmm0, [rsp]
0000740ecffd8d3d  vmovaps xmm1, [rsp+0x10]
0000740ecffd8d43  vmovaps xmm2, [rsp+0x20]
0000740ecffd8d49  vmovaps xmm3, [rsp+0x30]
0000740ecffd8d4f  vmovaps xmm5, [rsp+0x40]
0000740ecffd8d55  vmovaps xmm6, [rsp+0x50]
0000740ecffd8d5b  vmovaps xmm7, [rsp+0x60]
0000740ecffd8d61  vmovaps xmm8, [rsp+0x70]
0000740ecffd8d67  vmovaps xmm9, [rsp+0x80]
0000740ecffd8d70  vmovaps xmm10, [rsp+0x90]
0000740ecffd8d79  vmovaps xmm11, [rsp+0xA0]
0000740ecffd8d82  vmovaps xmm12, [rsp+0xB0]
0000740ecffd8d8b  vmovaps xmm13, [rsp+0xC0]
0000740ecffd8d94  vmovaps xmm14, [rsp+0xD0]
0000740ecffd8d9d  vmovaps xmm15, [rsp+0xE0]
0000740ecffd8da6  add rsp, 0xF0
0000740ecffd8dad  pop r11
0000740ecffd8daf  pop r10
0000740ecffd8db1  pop r9
0000740ecffd8db3  pop r8
0000740ecffd8db5  pop rsi
0000740ecffd8db6  pop rdi
0000740ecffd8db7  pop rdx
0000740ecffd8db8  pop rcx
0000740ecffd8db9  pop rax
0000740ecffd8dba  add rsp, 0x08
0000740ecffd8dbe  jmp 0x0000740ECFFD616B
0000740ecffd8dc3  sub rsp, 0x08
0000740ecffd8dc7  push rax
0000740ecffd8dc8  push rcx
0000740ecffd8dc9  push rdx
0000740ecffd8dca  push rdi
0000740ecffd8dcb  push rsi
0000740ecffd8dcc  push r8
0000740ecffd8dce  push r9
0000740ecffd8dd0  push r10
0000740ecffd8dd2  push r11
0000740ecffd8dd4  sub rsp, 0xF0
0000740ecffd8ddb  vmovaps [rsp], xmm0
0000740ecffd8de0  vmovaps [rsp+0x10], xmm1
0000740ecffd8de6  vmovaps [rsp+0x20], xmm2
0000740ecffd8dec  vmovaps [rsp+0x30], xmm3
0000740ecffd8df2  vmovaps [rsp+0x40], xmm4
0000740ecffd8df8  vmovaps [rsp+0x50], xmm5
0000740ecffd8dfe  vmovaps [rsp+0x60], xmm6
0000740ecffd8e04  vmovaps [rsp+0x70], xmm7
0000740ecffd8e0a  vmovaps [rsp+0x80], xmm8
0000740ecffd8e13  vmovaps [rsp+0x90], xmm10
0000740ecffd8e1c  vmovaps [rsp+0xA0], xmm11
0000740ecffd8e25  vmovaps [rsp+0xB0], xmm12
0000740ecffd8e2e  vmovaps [rsp+0xC0], xmm13
0000740ecffd8e37  vmovaps [rsp+0xD0], xmm14
0000740ecffd8e40  vmovaps [rsp+0xE0], xmm15
0000740ecffd8e49  sub rsp, 0x30
0000740ecffd8e4d  movaps [rsp], xmm9
0000740ecffd8e52  movaps [rsp+0x10], xmm2
0000740ecffd8e57  movaps [rsp+0x20], xmm1
0000740ecffd8e5c  lea rdi, [rsp]
0000740ecffd8e60  mov esi, 0x00
0000740ecffd8e65  mov rax, 0x5E8249CF1530
0000740ecffd8e6f  call rax
0000740ecffd8e71  movaps xmm9, [rsp]
0000740ecffd8e76  add rsp, 0x30
0000740ecffd8e7a  vmovaps xmm0, [rsp]
0000740ecffd8e7f  vmovaps xmm1, [rsp+0x10]
0000740ecffd8e85  vmovaps xmm2, [rsp+0x20]
0000740ecffd8e8b  vmovaps xmm3, [rsp+0x30]
0000740ecffd8e91  vmovaps xmm4, [rsp+0x40]
0000740ecffd8e97  vmovaps xmm5, [rsp+0x50]
0000740ecffd8e9d  vmovaps xmm6, [rsp+0x60]
0000740ecffd8ea3  vmovaps xmm7, [rsp+0x70]
0000740ecffd8ea9  vmovaps xmm8, [rsp+0x80]
0000740ecffd8eb2  vmovaps xmm10, [rsp+0x90]
0000740ecffd8ebb  vmovaps xmm11, [rsp+0xA0]
0000740ecffd8ec4  vmovaps xmm12, [rsp+0xB0]
0000740ecffd8ecd  vmovaps xmm13, [rsp+0xC0]
0000740ecffd8ed6  vmovaps xmm14, [rsp+0xD0]
0000740ecffd8edf  vmovaps xmm15, [rsp+0xE0]
0000740ecffd8ee8  add rsp, 0xF0
0000740ecffd8eef  pop r11
0000740ecffd8ef1  pop r10
0000740ecffd8ef3  pop r9
0000740ecffd8ef5  pop r8
0000740ecffd8ef7  pop rsi
0000740ecffd8ef8  pop rdi
0000740ecffd8ef9  pop rdx
0000740ecffd8efa  pop rcx
0000740ecffd8efb  pop rax
0000740ecffd8efc  add rsp, 0x08
0000740ecffd8f00  jmp 0x0000740ECFFD61A1
0000740ecffd8f05  sub rsp, 0x08
0000740ecffd8f09  push rax
0000740ecffd8f0a  push rcx
0000740ecffd8f0b  push rdx
0000740ecffd8f0c  push rdi
0000740ecffd8f0d  push rsi
0000740ecffd8f0e  push r8
0000740ecffd8f10  push r9
0000740ecffd8f12  push r10
0000740ecffd8f14  push r11
0000740ecffd8f16  sub rsp, 0xF0
0000740ecffd8f1d  vmovaps [rsp], xmm0
0000740ecffd8f22  vmovaps [rsp+0x10], xmm2
0000740ecffd8f28  vmovaps [rsp+0x20], xmm3
0000740ecffd8f2e  vmovaps [rsp+0x30], xmm4
0000740ecffd8f34  vmovaps [rsp+0x40], xmm5
0000740ecffd8f3a  vmovaps [rsp+0x50], xmm6
0000740ecffd8f40  vmovaps [rsp+0x60], xmm7
0000740ecffd8f46  vmovaps [rsp+0x70], xmm8
0000740ecffd8f4c  vmovaps [rsp+0x80], xmm9
0000740ecffd8f55  vmovaps [rsp+0x90], xmm10
0000740ecffd8f5e  vmovaps [rsp+0xA0], xmm11
0000740ecffd8f67  vmovaps [rsp+0xB0], xmm12
0000740ecffd8f70  vmovaps [rsp+0xC0], xmm13
0000740ecffd8f79  vmovaps [rsp+0xD0], xmm14
0000740ecffd8f82  vmovaps [rsp+0xE0], xmm15
0000740ecffd8f8b  sub rsp, 0x30
0000740ecffd8f8f  movaps [rsp], xmm1
0000740ecffd8f93  movaps [rsp+0x10], xmm15
0000740ecffd8f99  movaps [rsp+0x20], xmm6
0000740ecffd8f9e  lea rdi, [rsp]
0000740ecffd8fa2  mov esi, 0x00
0000740ecffd8fa7  mov rax, 0x5E8249CF1530
0000740ecffd8fb1  call rax
0000740ecffd8fb3  movaps xmm1, [rsp]
0000740ecffd8fb7  add rsp, 0x30
0000740ecffd8fbb  vmovaps xmm0, [rsp]
0000740ecffd8fc0  vmovaps xmm2, [rsp+0x10]
0000740ecffd8fc6  vmovaps xmm3, [rsp+0x20]
0000740ecffd8fcc  vmovaps xmm4, [rsp+0x30]
0000740ecffd8fd2  vmovaps xmm5, [rsp+0x40]
0000740ecffd8fd8  vmovaps xmm6, [rsp+0x50]
0000740ecffd8fde  vmovaps xmm7, [rsp+0x60]
0000740ecffd8fe4  vmovaps xmm8, [rsp+0x70]
0000740ecffd8fea  vmovaps xmm9, [rsp+0x80]
0000740ecffd8ff3  vmovaps xmm10, [rsp+0x90]
0000740ecffd8ffc  vmovaps xmm11, [rsp+0xA0]
0000740ecffd9005  vmovaps xmm12, [rsp+0xB0]
0000740ecffd900e  vmovaps xmm13, [rsp+0xC0]
0000740ecffd9017  vmovaps xmm14, [rsp+0xD0]
0000740ecffd9020  vmovaps xmm15, [rsp+0xE0]
0000740ecffd9029  add rsp, 0xF0
0000740ecffd9030  pop r11
0000740ecffd9032  pop r10
0000740ecffd9034  pop r9
0000740ecffd9036  pop r8
0000740ecffd9038  pop rsi
0000740ecffd9039  pop rdi
0000740ecffd903a  pop rdx
0000740ecffd903b  pop rcx
0000740ecffd903c  pop rax
0000740ecffd903d  add rsp, 0x08
0000740ecffd9041  jmp 0x0000740ECFFD61C2
0000740ecffd9046  sub rsp, 0x08
0000740ecffd904a  push rax
0000740ecffd904b  push rcx
0000740ecffd904c  push rdx
0000740ecffd904d  push rdi
0000740ecffd904e  push rsi
0000740ecffd904f  push r8
0000740ecffd9051  push r9
0000740ecffd9053  push r10
0000740ecffd9055  push r11
0000740ecffd9057  sub rsp, 0xF0
0000740ecffd905e  vmovaps [rsp], xmm0
0000740ecffd9063  vmovaps [rsp+0x10], xmm1
0000740ecffd9069  vmovaps [rsp+0x20], xmm2
0000740ecffd906f  vmovaps [rsp+0x30], xmm3
0000740ecffd9075  vmovaps [rsp+0x40], xmm4
0000740ecffd907b  vmovaps [rsp+0x50], xmm5
0000740ecffd9081  vmovaps [rsp+0x60], xmm6
0000740ecffd9087  vmovaps [rsp+0x70], xmm7
0000740ecffd908d  vmovaps [rsp+0x80], xmm8
0000740ecffd9096  vmovaps [rsp+0x90], xmm9
0000740ecffd909f  vmovaps [rsp+0xA0], xmm10
0000740ecffd90a8  vmovaps [rsp+0xB0], xmm11
0000740ecffd90b1  vmovaps [rsp+0xC0], xmm12
0000740ecffd90ba  vmovaps [rsp+0xD0], xmm13
0000740ecffd90c3  vmovaps [rsp+0xE0], xmm14
0000740ecffd90cc  sub rsp, 0x30
0000740ecffd90d0  movaps [rsp], xmm15
0000740ecffd90d5  movaps [rsp+0x10], xmm5
0000740ecffd90da  movaps [rsp+0x20], xmm3
0000740ecffd90df  lea rdi, [rsp]
0000740ecffd90e3  mov esi, 0x00
0000740ecffd90e8  mov rax, 0x5E8249CF1530
0000740ecffd90f2  call rax
0000740ecffd90f4  movaps xmm15, [rsp]
0000740ecffd90f9  add rsp, 0x30
0000740ecffd90fd  vmovaps xmm0, [rsp]
0000740ecffd9102  vmovaps xmm1, [rsp+0x10]
0000740ecffd9108  vmovaps xmm2, [rsp+0x20]
0000740ecffd910e  vmovaps xmm3, [rsp+0x30]
0000740ecffd9114  vmovaps xmm4, [rsp+0x40]
0000740ecffd911a  vmovaps xmm5, [rsp+0x50]
0000740ecffd9120  vmovaps xmm6, [rsp+0x60]
0000740ecffd9126  vmovaps xmm7, [rsp+0x70]
0000740ecffd912c  vmovaps xmm8, [rsp+0x80]
0000740ecffd9135  vmovaps xmm9, [rsp+0x90]
0000740ecffd913e  vmovaps xmm10, [rsp+0xA0]
0000740ecffd9147  vmovaps xmm11, [rsp+0xB0]
0000740ecffd9150  vmovaps xmm12, [rsp+0xC0]
0000740ecffd9159  vmovaps xmm13, [rsp+0xD0]
0000740ecffd9162  vmovaps xmm14, [rsp+0xE0]
0000740ecffd916b  add rsp, 0xF0
0000740ecffd9172  pop r11
0000740ecffd9174  pop r10
0000740ecffd9176  pop r9
0000740ecffd9178  pop r8
0000740ecffd917a  pop rsi
0000740ecffd917b  pop rdi
0000740ecffd917c  pop rdx
0000740ecffd917d  pop rcx
0000740ecffd917e  pop rax
0000740ecffd917f  add rsp, 0x08
0000740ecffd9183  jmp 0x0000740ECFFD61DC
0000740ecffd9188  sub rsp, 0x08
0000740ecffd918c  push rax
0000740ecffd918d  push rcx
0000740ecffd918e  push rdx
0000740ecffd918f  push rdi
0000740ecffd9190  push rsi
0000740ecffd9191  push r8
0000740ecffd9193  push r9
0000740ecffd9195  push r10
0000740ecffd9197  push r11
0000740ecffd9199  sub rsp, 0xF0
0000740ecffd91a0  vmovaps [rsp], xmm0
0000740ecffd91a5  vmovaps [rsp+0x10], xmm1
0000740ecffd91ab  vmovaps [rsp+0x20], xmm2
0000740ecffd91b1  vmovaps [rsp+0x30], xmm3
0000740ecffd91b7  vmovaps [rsp+0x40], xmm4
0000740ecffd91bd  vmovaps [rsp+0x50], xmm6
0000740ecffd91c3  vmovaps [rsp+0x60], xmm7
0000740ecffd91c9  vmovaps [rsp+0x70], xmm8
0000740ecffd91cf  vmovaps [rsp+0x80], xmm9
0000740ecffd91d8  vmovaps [rsp+0x90], xmm10
0000740ecffd91e1  vmovaps [rsp+0xA0], xmm11
0000740ecffd91ea  vmovaps [rsp+0xB0], xmm12
0000740ecffd91f3  vmovaps [rsp+0xC0], xmm13
0000740ecffd91fc  vmovaps [rsp+0xD0], xmm14
0000740ecffd9205  vmovaps [rsp+0xE0], xmm15
0000740ecffd920e  sub rsp, 0x30
0000740ecffd9212  movaps [rsp], xmm5
0000740ecffd9216  movaps [rsp+0x10], xmm8
0000740ecffd921c  movaps [rsp+0x20], xmm6
0000740ecffd9221  lea rdi, [rsp]
0000740ecffd9225  mov esi, 0x00
0000740ecffd922a  mov rax, 0x5E8249CF1530
0000740ecffd9234  call rax
0000740ecffd9236  movaps xmm5, [rsp]
0000740ecffd923a  add rsp, 0x30
0000740ecffd923e  vmovaps xmm0, [rsp]
0000740ecffd9243  vmovaps xmm1, [rsp+0x10]
0000740ecffd9249  vmovaps xmm2, [rsp+0x20]
0000740ecffd924f  vmovaps xmm3, [rsp+0x30]
0000740ecffd9255  vmovaps xmm4, [rsp+0x40]
0000740ecffd925b  vmovaps xmm6, [rsp+0x50]
0000740ecffd9261  vmovaps xmm7, [rsp+0x60]
0000740ecffd9267  vmovaps xmm8, [rsp+0x70]
0000740ecffd926d  vmovaps xmm9, [rsp+0x80]
0000740ecffd9276  vmovaps xmm10, [rsp+0x90]
0000740ecffd927f  vmovaps xmm11, [rsp+0xA0]
0000740ecffd9288  vmovaps xmm12, [rsp+0xB0]
0000740ecffd9291  vmovaps xmm13, [rsp+0xC0]
0000740ecffd929a  vmovaps xmm14, [rsp+0xD0]
0000740ecffd92a3  vmovaps xmm15, [rsp+0xE0]
0000740ecffd92ac  add rsp, 0xF0
0000740ecffd92b3  pop r11
0000740ecffd92b5  pop r10
0000740ecffd92b7  pop r9
0000740ecffd92b9  pop r8
0000740ecffd92bb  pop rsi
0000740ecffd92bc  pop rdi
0000740ecffd92bd  pop rdx
0000740ecffd92be  pop rcx
0000740ecffd92bf  pop rax
0000740ecffd92c0  add rsp, 0x08
0000740ecffd92c4  jmp 0x0000740ECFFD6200
0000740ecffd92c9  sub rsp, 0x08
0000740ecffd92cd  push rax
0000740ecffd92ce  push rcx
0000740ecffd92cf  push rdx
0000740ecffd92d0  push rdi
0000740ecffd92d1  push rsi
0000740ecffd92d2  push r8
0000740ecffd92d4  push r9
0000740ecffd92d6  push r10
0000740ecffd92d8  push r11
0000740ecffd92da  sub rsp, 0xF0
0000740ecffd92e1  vmovaps [rsp], xmm0
0000740ecffd92e6  vmovaps [rsp+0x10], xmm1
0000740ecffd92ec  vmovaps [rsp+0x20], xmm2
0000740ecffd92f2  vmovaps [rsp+0x30], xmm3
0000740ecffd92f8  vmovaps [rsp+0x40], xmm4
0000740ecffd92fe  vmovaps [rsp+0x50], xmm5
0000740ecffd9304  vmovaps [rsp+0x60], xmm7
0000740ecffd930a  vmovaps [rsp+0x70], xmm8
0000740ecffd9310  vmovaps [rsp+0x80], xmm9
0000740ecffd9319  vmovaps [rsp+0x90], xmm10
0000740ecffd9322  vmovaps [rsp+0xA0], xmm11
0000740ecffd932b  vmovaps [rsp+0xB0], xmm12
0000740ecffd9334  vmovaps [rsp+0xC0], xmm13
0000740ecffd933d  vmovaps [rsp+0xD0], xmm14
0000740ecffd9346  vmovaps [rsp+0xE0], xmm15
0000740ecffd934f  sub rsp, 0x30
0000740ecffd9353  movaps [rsp], xmm6
0000740ecffd9357  movaps [rsp+0x10], xmm10
0000740ecffd935d  movaps [rsp+0x20], xmm8
0000740ecffd9363  lea rdi, [rsp]
0000740ecffd9367  mov esi, 0x00
0000740ecffd936c  mov rax, 0x5E8249CF1530
0000740ecffd9376  call rax
0000740ecffd9378  movaps xmm6, [rsp]
0000740ecffd937c  add rsp, 0x30
0000740ecffd9380  vmovaps xmm0, [rsp]
0000740ecffd9385  vmovaps xmm1, [rsp+0x10]
0000740ecffd938b  vmovaps xmm2, [rsp+0x20]
0000740ecffd9391  vmovaps xmm3, [rsp+0x30]
0000740ecffd9397  vmovaps xmm4, [rsp+0x40]
0000740ecffd939d  vmovaps xmm5, [rsp+0x50]
0000740ecffd93a3  vmovaps xmm7, [rsp+0x60]
0000740ecffd93a9  vmovaps xmm8, [rsp+0x70]
0000740ecffd93af  vmovaps xmm9, [rsp+0x80]
0000740ecffd93b8  vmovaps xmm10, [rsp+0x90]
0000740ecffd93c1  vmovaps xmm11, [rsp+0xA0]
0000740ecffd93ca  vmovaps xmm12, [rsp+0xB0]
0000740ecffd93d3  vmovaps xmm13, [rsp+0xC0]
0000740ecffd93dc  vmovaps xmm14, [rsp+0xD0]
0000740ecffd93e5  vmovaps xmm15, [rsp+0xE0]
0000740ecffd93ee  add rsp, 0xF0
0000740ecffd93f5  pop r11
0000740ecffd93f7  pop r10
0000740ecffd93f9  pop r9
0000740ecffd93fb  pop r8
0000740ecffd93fd  pop rsi
0000740ecffd93fe  pop rdi
0000740ecffd93ff  pop rdx
0000740ecffd9400  pop rcx
0000740ecffd9401  pop rax
0000740ecffd9402  add rsp, 0x08
0000740ecffd9406  jmp 0x0000740ECFFD6225
0000740ecffd940b  sub rsp, 0x08
0000740ecffd940f  push rax
0000740ecffd9410  push rcx
0000740ecffd9411  push rdx
0000740ecffd9412  push rdi
0000740ecffd9413  push rsi
0000740ecffd9414  push r8
0000740ecffd9416  push r9
0000740ecffd9418  push r10
0000740ecffd941a  push r11
0000740ecffd941c  sub rsp, 0xF0
0000740ecffd9423  vmovaps [rsp], xmm0
0000740ecffd9428  vmovaps [rsp+0x10], xmm1
0000740ecffd942e  vmovaps [rsp+0x20], xmm2
0000740ecffd9434  vmovaps [rsp+0x30], xmm3
0000740ecffd943a  vmovaps [rsp+0x40], xmm4
0000740ecffd9440  vmovaps [rsp+0x50], xmm5
0000740ecffd9446  vmovaps [rsp+0x60], xmm6
0000740ecffd944c  vmovaps [rsp+0x70], xmm7
0000740ecffd9452  vmovaps [rsp+0x80], xmm8
0000740ecffd945b  vmovaps [rsp+0x90], xmm9
0000740ecffd9464  vmovaps [rsp+0xA0], xmm11
0000740ecffd946d  vmovaps [rsp+0xB0], xmm12
0000740ecffd9476  vmovaps [rsp+0xC0], xmm13
0000740ecffd947f  vmovaps [rsp+0xD0], xmm14
0000740ecffd9488  vmovaps [rsp+0xE0], xmm15
0000740ecffd9491  sub rsp, 0x30
0000740ecffd9495  movaps [rsp], xmm10
0000740ecffd949a  movaps [rsp+0x10], xmm8
0000740ecffd94a0  movaps [rsp+0x20], xmm14
0000740ecffd94a6  lea rdi, [rsp]
0000740ecffd94aa  mov esi, 0x00
0000740ecffd94af  mov rax, 0x5E8249CF1530
0000740ecffd94b9  call rax
0000740ecffd94bb  movaps xmm10, [rsp]
0000740ecffd94c0  add rsp, 0x30
0000740ecffd94c4  vmovaps xmm0, [rsp]
0000740ecffd94c9  vmovaps xmm1, [rsp+0x10]
0000740ecffd94cf  vmovaps xmm2, [rsp+0x20]
0000740ecffd94d5  vmovaps xmm3, [rsp+0x30]
0000740ecffd94db  vmovaps xmm4, [rsp+0x40]
0000740ecffd94e1  vmovaps xmm5, [rsp+0x50]
0000740ecffd94e7  vmovaps xmm6, [rsp+0x60]
0000740ecffd94ed  vmovaps xmm7, [rsp+0x70]
0000740ecffd94f3  vmovaps xmm8, [rsp+0x80]
0000740ecffd94fc  vmovaps xmm9, [rsp+0x90]
0000740ecffd9505  vmovaps xmm11, [rsp+0xA0]
0000740ecffd950e  vmovaps xmm12, [rsp+0xB0]
0000740ecffd9517  vmovaps xmm13, [rsp+0xC0]
0000740ecffd9520  vmovaps xmm14, [rsp+0xD0]
0000740ecffd9529  vmovaps xmm15, [rsp+0xE0]
0000740ecffd9532  add rsp, 0xF0
0000740ecffd9539  pop r11
0000740ecffd953b  pop r10
0000740ecffd953d  pop r9
0000740ecffd953f  pop r8
0000740ecffd9541  pop rsi
0000740ecffd9542  pop rdi
0000740ecffd9543  pop rdx
0000740ecffd9544  pop rcx
0000740ecffd9545  pop rax
0000740ecffd9546  add rsp, 0x08
0000740ecffd954a  jmp 0x0000740ECFFD6245
0000740ecffd954f  sub rsp, 0x08
0000740ecffd9553  push rax
0000740ecffd9554  push rcx
0000740ecffd9555  push rdx
0000740ecffd9556  push rdi
0000740ecffd9557  push rsi
0000740ecffd9558  push r8
0000740ecffd955a  push r9
0000740ecffd955c  push r10
0000740ecffd955e  push r11
0000740ecffd9560  sub rsp, 0xF0
0000740ecffd9567  vmovaps [rsp], xmm0
0000740ecffd956c  vmovaps [rsp+0x10], xmm1
0000740ecffd9572  vmovaps [rsp+0x20], xmm2
0000740ecffd9578  vmovaps [rsp+0x30], xmm3
0000740ecffd957e  vmovaps [rsp+0x40], xmm4
0000740ecffd9584  vmovaps [rsp+0x50], xmm5
0000740ecffd958a  vmovaps [rsp+0x60], xmm6
0000740ecffd9590  vmovaps [rsp+0x70], xmm7
0000740ecffd9596  vmovaps [rsp+0x80], xmm8
0000740ecffd959f  vmovaps [rsp+0x90], xmm9
0000740ecffd95a8  vmovaps [rsp+0xA0], xmm10
0000740ecffd95b1  vmovaps [rsp+0xB0], xmm11
0000740ecffd95ba  vmovaps [rsp+0xC0], xmm12
0000740ecffd95c3  vmovaps [rsp+0xD0], xmm13
0000740ecffd95cc  vmovaps [rsp+0xE0], xmm15
0000740ecffd95d5  sub rsp, 0x30
0000740ecffd95d9  movaps [rsp], xmm14
0000740ecffd95de  movaps [rsp+0x10], xmm8
0000740ecffd95e4  movaps [rsp+0x20], xmm4
0000740ecffd95e9  lea rdi, [rsp]
0000740ecffd95ed  mov esi, 0x00
0000740ecffd95f2  mov rax, 0x5E8249CF1530
0000740ecffd95fc  call rax
0000740ecffd95fe  movaps xmm14, [rsp]
0000740ecffd9603  add rsp, 0x30
0000740ecffd9607  vmovaps xmm0, [rsp]
0000740ecffd960c  vmovaps xmm1, [rsp+0x10]
0000740ecffd9612  vmovaps xmm2, [rsp+0x20]
0000740ecffd9618  vmovaps xmm3, [rsp+0x30]
0000740ecffd961e  vmovaps xmm4, [rsp+0x40]
0000740ecffd9624  vmovaps xmm5, [rsp+0x50]
0000740ecffd962a  vmovaps xmm6, [rsp+0x60]
0000740ecffd9630  vmovaps xmm7, [rsp+0x70]
0000740ecffd9636  vmovaps xmm8, [rsp+0x80]
0000740ecffd963f  vmovaps xmm9, [rsp+0x90]
0000740ecffd9648  vmovaps xmm10, [rsp+0xA0]
0000740ecffd9651  vmovaps xmm11, [rsp+0xB0]
0000740ecffd965a  vmovaps xmm12, [rsp+0xC0]
0000740ecffd9663  vmovaps xmm13, [rsp+0xD0]
0000740ecffd966c  vmovaps xmm15, [rsp+0xE0]
0000740ecffd9675  add rsp, 0xF0
0000740ecffd967c  pop r11
0000740ecffd967e  pop r10
0000740ecffd9680  pop r9
0000740ecffd9682  pop r8
0000740ecffd9684  pop rsi
0000740ecffd9685  pop rdi
0000740ecffd9686  pop rdx
0000740ecffd9687  pop rcx
0000740ecffd9688  pop rax
0000740ecffd9689  add rsp, 0x08
0000740ecffd968d  jmp 0x0000740ECFFD6265
0000740ecffd9692  sub rsp, 0x08
0000740ecffd9696  push rax
0000740ecffd9697  push rcx
0000740ecffd9698  push rdx
0000740ecffd9699  push rdi
0000740ecffd969a  push rsi
0000740ecffd969b  push r8
0000740ecffd969d  push r9
0000740ecffd969f  push r10
0000740ecffd96a1  push r11
0000740ecffd96a3  sub rsp, 0xF0
0000740ecffd96aa  vmovaps [rsp], xmm0
0000740ecffd96af  vmovaps [rsp+0x10], xmm1
0000740ecffd96b5  vmovaps [rsp+0x20], xmm2
0000740ecffd96bb  vmovaps [rsp+0x30], xmm3
0000740ecffd96c1  vmovaps [rsp+0x40], xmm5
0000740ecffd96c7  vmovaps [rsp+0x50], xmm6
0000740ecffd96cd  vmovaps [rsp+0x60], xmm7
0000740ecffd96d3  vmovaps [rsp+0x70], xmm8
0000740ecffd96d9  vmovaps [rsp+0x80], xmm9
0000740ecffd96e2  vmovaps [rsp+0x90], xmm10
0000740ecffd96eb  vmovaps [rsp+0xA0], xmm11
0000740ecffd96f4  vmovaps [rsp+0xB0], xmm12
0000740ecffd96fd  vmovaps [rsp+0xC0], xmm13
0000740ecffd9706  vmovaps [rsp+0xD0], xmm14
0000740ecffd970f  vmovaps [rsp+0xE0], xmm15
0000740ecffd9718  sub rsp, 0x30
0000740ecffd971c  movaps [rsp], xmm4
0000740ecffd9720  movaps [rsp+0x10], xmm13
0000740ecffd9726  movaps [rsp+0x20], xmm8
0000740ecffd972c  lea rdi, [rsp]
0000740ecffd9730  mov esi, 0x00
0000740ecffd9735  mov rax, 0x5E8249CF1530
0000740ecffd973f  call rax
0000740ecffd9741  movaps xmm4, [rsp]
0000740ecffd9745  add rsp, 0x30
0000740ecffd9749  vmovaps xmm0, [rsp]
0000740ecffd974e  vmovaps xmm1, [rsp+0x10]
0000740ecffd9754  vmovaps xmm2, [rsp+0x20]
0000740ecffd975a  vmovaps xmm3, [rsp+0x30]
0000740ecffd9760  vmovaps xmm5, [rsp+0x40]
0000740ecffd9766  vmovaps xmm6, [rsp+0x50]
0000740ecffd976c  vmovaps xmm7, [rsp+0x60]
0000740ecffd9772  vmovaps xmm8, [rsp+0x70]
0000740ecffd9778  vmovaps xmm9, [rsp+0x80]
0000740ecffd9781  vmovaps xmm10, [rsp+0x90]
0000740ecffd978a  vmovaps xmm11, [rsp+0xA0]
0000740ecffd9793  vmovaps xmm12, [rsp+0xB0]
0000740ecffd979c  vmovaps xmm13, [rsp+0xC0]
0000740ecffd97a5  vmovaps xmm14, [rsp+0xD0]
0000740ecffd97ae  vmovaps xmm15, [rsp+0xE0]
0000740ecffd97b7  add rsp, 0xF0
0000740ecffd97be  pop r11
0000740ecffd97c0  pop r10
0000740ecffd97c2  pop r9
0000740ecffd97c4  pop r8
0000740ecffd97c6  pop rsi
0000740ecffd97c7  pop rdi
0000740ecffd97c8  pop rdx
0000740ecffd97c9  pop rcx
0000740ecffd97ca  pop rax
0000740ecffd97cb  add rsp, 0x08
0000740ecffd97cf  jmp 0x0000740ECFFD628A
0000740ecffd97d4  sub rsp, 0x08
0000740ecffd97d8  push rax
0000740ecffd97d9  push rcx
0000740ecffd97da  push rdx
0000740ecffd97db  push rdi
0000740ecffd97dc  push rsi
0000740ecffd97dd  push r8
0000740ecffd97df  push r9
0000740ecffd97e1  push r10
0000740ecffd97e3  push r11
0000740ecffd97e5  sub rsp, 0xF0
0000740ecffd97ec  vmovaps [rsp], xmm0
0000740ecffd97f1  vmovaps [rsp+0x10], xmm1
0000740ecffd97f7  vmovaps [rsp+0x20], xmm2
0000740ecffd97fd  vmovaps [rsp+0x30], xmm3
0000740ecffd9803  vmovaps [rsp+0x40], xmm4
0000740ecffd9809  vmovaps [rsp+0x50], xmm5
0000740ecffd980f  vmovaps [rsp+0x60], xmm6
0000740ecffd9815  vmovaps [rsp+0x70], xmm7
0000740ecffd981b  vmovaps [rsp+0x80], xmm8
0000740ecffd9824  vmovaps [rsp+0x90], xmm9
0000740ecffd982d  vmovaps [rsp+0xA0], xmm10
0000740ecffd9836  vmovaps [rsp+0xB0], xmm11
0000740ecffd983f  vmovaps [rsp+0xC0], xmm12
0000740ecffd9848  vmovaps [rsp+0xD0], xmm14
0000740ecffd9851  vmovaps [rsp+0xE0], xmm15
0000740ecffd985a  sub rsp, 0x30
0000740ecffd985e  movaps [rsp], xmm13
0000740ecffd9863  movaps [rsp+0x10], xmm15
0000740ecffd9869  movaps [rsp+0x20], xmm9
0000740ecffd986f  lea rdi, [rsp]
0000740ecffd9873  mov esi, 0x00
0000740ecffd9878  mov rax, 0x5E8249CF1530
0000740ecffd9882  call rax
0000740ecffd9884  movaps xmm13, [rsp]
0000740ecffd9889  add rsp, 0x30
0000740ecffd988d  vmovaps xmm0, [rsp]
0000740ecffd9892  vmovaps xmm1, [rsp+0x10]
0000740ecffd9898  vmovaps xmm2, [rsp+0x20]
0000740ecffd989e  vmovaps xmm3, [rsp+0x30]
0000740ecffd98a4  vmovaps xmm4, [rsp+0x40]
0000740ecffd98aa  vmovaps xmm5, [rsp+0x50]
0000740ecffd98b0  vmovaps xmm6, [rsp+0x60]
0000740ecffd98b6  vmovaps xmm7, [rsp+0x70]
0000740ecffd98bc  vmovaps xmm8, [rsp+0x80]
0000740ecffd98c5  vmovaps xmm9, [rsp+0x90]
0000740ecffd98ce  vmovaps xmm10, [rsp+0xA0]
0000740ecffd98d7  vmovaps xmm11, [rsp+0xB0]
0000740ecffd98e0  vmovaps xmm12, [rsp+0xC0]
0000740ecffd98e9  vmovaps xmm14, [rsp+0xD0]
0000740ecffd98f2  vmovaps xmm15, [rsp+0xE0]
0000740ecffd98fb  add rsp, 0xF0
0000740ecffd9902  pop r11
0000740ecffd9904  pop r10
0000740ecffd9906  pop r9
0000740ecffd9908  pop r8
0000740ecffd990a  pop rsi
0000740ecffd990b  pop rdi
0000740ecffd990c  pop rdx
0000740ecffd990d  pop rcx
0000740ecffd990e  pop rax
0000740ecffd990f  add rsp, 0x08
0000740ecffd9913  jmp 0x0000740ECFFD62A5
0000740ecffd9918  sub rsp, 0x08
0000740ecffd991c  push rax
0000740ecffd991d  push rcx
0000740ecffd991e  push rdx
0000740ecffd991f  push rdi
0000740ecffd9920  push rsi
0000740ecffd9921  push r8
0000740ecffd9923  push r9
0000740ecffd9925  push r10
0000740ecffd9927  push r11
0000740ecffd9929  sub rsp, 0xF0
0000740ecffd9930  vmovaps [rsp], xmm0
0000740ecffd9935  vmovaps [rsp+0x10], xmm1
0000740ecffd993b  vmovaps [rsp+0x20], xmm2
0000740ecffd9941  vmovaps [rsp+0x30], xmm3
0000740ecffd9947  vmovaps [rsp+0x40], xmm4
0000740ecffd994d  vmovaps [rsp+0x50], xmm5
0000740ecffd9953  vmovaps [rsp+0x60], xmm6
0000740ecffd9959  vmovaps [rsp+0x70], xmm7
0000740ecffd995f  vmovaps [rsp+0x80], xmm8
0000740ecffd9968  vmovaps [rsp+0x90], xmm9
0000740ecffd9971  vmovaps [rsp+0xA0], xmm10
0000740ecffd997a  vmovaps [rsp+0xB0], xmm11
0000740ecffd9983  vmovaps [rsp+0xC0], xmm12
0000740ecffd998c  vmovaps [rsp+0xD0], xmm13
0000740ecffd9995  vmovaps [rsp+0xE0], xmm14
0000740ecffd999e  sub rsp, 0x30
0000740ecffd99a2  movaps [rsp], xmm15
0000740ecffd99a7  movaps [rsp+0x10], xmm1
0000740ecffd99ac  movaps [rsp+0x20], xmm5
0000740ecffd99b1  lea rdi, [rsp]
0000740ecffd99b5  mov esi, 0x00
0000740ecffd99ba  mov rax, 0x5E8249CF1530
0000740ecffd99c4  call rax
0000740ecffd99c6  movaps xmm15, [rsp]
0000740ecffd99cb  add rsp, 0x30
0000740ecffd99cf  vmovaps xmm0, [rsp]
0000740ecffd99d4  vmovaps xmm1, [rsp+0x10]
0000740ecffd99da  vmovaps xmm2, [rsp+0x20]
0000740ecffd99e0  vmovaps xmm3, [rsp+0x30]
0000740ecffd99e6  vmovaps xmm4, [rsp+0x40]
0000740ecffd99ec  vmovaps xmm5, [rsp+0x50]
0000740ecffd99f2  vmovaps xmm6, [rsp+0x60]
0000740ecffd99f8  vmovaps xmm7, [rsp+0x70]
0000740ecffd99fe  vmovaps xmm8, [rsp+0x80]
0000740ecffd9a07  vmovaps xmm9, [rsp+0x90]
0000740ecffd9a10  vmovaps xmm10, [rsp+0xA0]
0000740ecffd9a19  vmovaps xmm11, [rsp+0xB0]
0000740ecffd9a22  vmovaps xmm12, [rsp+0xC0]
0000740ecffd9a2b  vmovaps xmm13, [rsp+0xD0]
0000740ecffd9a34  vmovaps xmm14, [rsp+0xE0]
0000740ecffd9a3d  add rsp, 0xF0
0000740ecffd9a44  pop r11
0000740ecffd9a46  pop r10
0000740ecffd9a48  pop r9
0000740ecffd9a4a  pop r8
0000740ecffd9a4c  pop rsi
0000740ecffd9a4d  pop rdi
0000740ecffd9a4e  pop rdx
0000740ecffd9a4f  pop rcx
0000740ecffd9a50  pop rax
0000740ecffd9a51  add rsp, 0x08
0000740ecffd9a55  jmp 0x0000740ECFFD62C0
0000740ecffd9a5a  call 0x0000740ECFED64F0
0000740ecffd9a5f  jmp 0x0000740ECFFD631B
0000740ecffd9a64  sub rsp, 0x08
0000740ecffd9a68  push rax
0000740ecffd9a69  push rcx
0000740ecffd9a6a  push rdx
0000740ecffd9a6b  push rdi
0000740ecffd9a6c  push rsi
0000740ecffd9a6d  push r8
0000740ecffd9a6f  push r9
0000740ecffd9a71  push r10
0000740ecffd9a73  push r11
0000740ecffd9a75  sub rsp, 0xF0
0000740ecffd9a7c  vmovaps [rsp], xmm0
0000740ecffd9a81  vmovaps [rsp+0x10], xmm1
0000740ecffd9a87  vmovaps [rsp+0x20], xmm2
0000740ecffd9a8d  vmovaps [rsp+0x30], xmm3
0000740ecffd9a93  vmovaps [rsp+0x40], xmm4
0000740ecffd9a99  vmovaps [rsp+0x50], xmm5
0000740ecffd9a9f  vmovaps [rsp+0x60], xmm6
0000740ecffd9aa5  vmovaps [rsp+0x70], xmm7
0000740ecffd9aab  vmovaps [rsp+0x80], xmm8
0000740ecffd9ab4  vmovaps [rsp+0x90], xmm10
0000740ecffd9abd  vmovaps [rsp+0xA0], xmm11
0000740ecffd9ac6  vmovaps [rsp+0xB0], xmm12
0000740ecffd9acf  vmovaps [rsp+0xC0], xmm13
0000740ecffd9ad8  vmovaps [rsp+0xD0], xmm14
0000740ecffd9ae1  vmovaps [rsp+0xE0], xmm15
0000740ecffd9aea  sub rsp, 0x30
0000740ecffd9aee  movaps [rsp], xmm9
0000740ecffd9af3  movaps [rsp+0x10], xmm8
0000740ecffd9af9  movaps [rsp+0x20], xmm11
0000740ecffd9aff  lea rdi, [rsp]
0000740ecffd9b03  mov esi, 0x00
0000740ecffd9b08  mov rax, 0x5E8249CF1530
0000740ecffd9b12  call rax
0000740ecffd9b14  movaps xmm9, [rsp]
0000740ecffd9b19  add rsp, 0x30
0000740ecffd9b1d  vmovaps xmm0, [rsp]
0000740ecffd9b22  vmovaps xmm1, [rsp+0x10]
0000740ecffd9b28  vmovaps xmm2, [rsp+0x20]
0000740ecffd9b2e  vmovaps xmm3, [rsp+0x30]
0000740ecffd9b34  vmovaps xmm4, [rsp+0x40]
0000740ecffd9b3a  vmovaps xmm5, [rsp+0x50]
0000740ecffd9b40  vmovaps xmm6, [rsp+0x60]
0000740ecffd9b46  vmovaps xmm7, [rsp+0x70]
0000740ecffd9b4c  vmovaps xmm8, [rsp+0x80]
0000740ecffd9b55  vmovaps xmm10, [rsp+0x90]
0000740ecffd9b5e  vmovaps xmm11, [rsp+0xA0]
0000740ecffd9b67  vmovaps xmm12, [rsp+0xB0]
0000740ecffd9b70  vmovaps xmm13, [rsp+0xC0]
0000740ecffd9b79  vmovaps xmm14, [rsp+0xD0]
0000740ecffd9b82  vmovaps xmm15, [rsp+0xE0]
0000740ecffd9b8b  add rsp, 0xF0
0000740ecffd9b92  pop r11
0000740ecffd9b94  pop r10
0000740ecffd9b96  pop r9
0000740ecffd9b98  pop r8
0000740ecffd9b9a  pop rsi
0000740ecffd9b9b  pop rdi
0000740ecffd9b9c  pop rdx
0000740ecffd9b9d  pop rcx
0000740ecffd9b9e  pop rax
0000740ecffd9b9f  add rsp, 0x08
0000740ecffd9ba3  jmp 0x0000740ECFFD6352
0000740ecffd9ba8  sub rsp, 0x08
0000740ecffd9bac  push rax
0000740ecffd9bad  push rcx
0000740ecffd9bae  push rdx
0000740ecffd9baf  push rdi
0000740ecffd9bb0  push rsi
0000740ecffd9bb1  push r8
0000740ecffd9bb3  push r9
0000740ecffd9bb5  push r10
0000740ecffd9bb7  push r11
0000740ecffd9bb9  sub rsp, 0xF0
0000740ecffd9bc0  vmovaps [rsp], xmm0
0000740ecffd9bc5  vmovaps [rsp+0x10], xmm1
0000740ecffd9bcb  vmovaps [rsp+0x20], xmm2
0000740ecffd9bd1  vmovaps [rsp+0x30], xmm3
0000740ecffd9bd7  vmovaps [rsp+0x40], xmm4
0000740ecffd9bdd  vmovaps [rsp+0x50], xmm5
0000740ecffd9be3  vmovaps [rsp+0x60], xmm6
0000740ecffd9be9  vmovaps [rsp+0x70], xmm7
0000740ecffd9bef  vmovaps [rsp+0x80], xmm8
0000740ecffd9bf8  vmovaps [rsp+0x90], xmm9
0000740ecffd9c01  vmovaps [rsp+0xA0], xmm10
0000740ecffd9c0a  vmovaps [rsp+0xB0], xmm12
0000740ecffd9c13  vmovaps [rsp+0xC0], xmm13
0000740ecffd9c1c  vmovaps [rsp+0xD0], xmm14
0000740ecffd9c25  vmovaps [rsp+0xE0], xmm15
0000740ecffd9c2e  sub rsp, 0x30
0000740ecffd9c32  movaps [rsp], xmm11
0000740ecffd9c37  movaps [rsp+0x10], xmm10
0000740ecffd9c3d  movaps [rsp+0x20], xmm6
0000740ecffd9c42  lea rdi, [rsp]
0000740ecffd9c46  mov esi, 0x00
0000740ecffd9c4b  mov rax, 0x5E8249CF1530
0000740ecffd9c55  call rax
0000740ecffd9c57  movaps xmm11, [rsp]
0000740ecffd9c5c  add rsp, 0x30
0000740ecffd9c60  vmovaps xmm0, [rsp]
0000740ecffd9c65  vmovaps xmm1, [rsp+0x10]
0000740ecffd9c6b  vmovaps xmm2, [rsp+0x20]
0000740ecffd9c71  vmovaps xmm3, [rsp+0x30]
0000740ecffd9c77  vmovaps xmm4, [rsp+0x40]
0000740ecffd9c7d  vmovaps xmm5, [rsp+0x50]
0000740ecffd9c83  vmovaps xmm6, [rsp+0x60]
0000740ecffd9c89  vmovaps xmm7, [rsp+0x70]
0000740ecffd9c8f  vmovaps xmm8, [rsp+0x80]
0000740ecffd9c98  vmovaps xmm9, [rsp+0x90]
0000740ecffd9ca1  vmovaps xmm10, [rsp+0xA0]
0000740ecffd9caa  vmovaps xmm12, [rsp+0xB0]
0000740ecffd9cb3  vmovaps xmm13, [rsp+0xC0]
0000740ecffd9cbc  vmovaps xmm14, [rsp+0xD0]
0000740ecffd9cc5  vmovaps xmm15, [rsp+0xE0]
0000740ecffd9cce  add rsp, 0xF0
0000740ecffd9cd5  pop r11
0000740ecffd9cd7  pop r10
0000740ecffd9cd9  pop r9
0000740ecffd9cdb  pop r8
0000740ecffd9cdd  pop rsi
0000740ecffd9cde  pop rdi
0000740ecffd9cdf  pop rdx
0000740ecffd9ce0  pop rcx
0000740ecffd9ce1  pop rax
0000740ecffd9ce2  add rsp, 0x08
0000740ecffd9ce6  jmp 0x0000740ECFFD636D
0000740ecffd9ceb  sub rsp, 0x08
0000740ecffd9cef  push rax
0000740ecffd9cf0  push rcx
0000740ecffd9cf1  push rdx
0000740ecffd9cf2  push rdi
0000740ecffd9cf3  push rsi
0000740ecffd9cf4  push r8
0000740ecffd9cf6  push r9
0000740ecffd9cf8  push r10
0000740ecffd9cfa  push r11
0000740ecffd9cfc  sub rsp, 0xF0
0000740ecffd9d03  vmovaps [rsp], xmm0
0000740ecffd9d08  vmovaps [rsp+0x10], xmm1
0000740ecffd9d0e  vmovaps [rsp+0x20], xmm2
0000740ecffd9d14  vmovaps [rsp+0x30], xmm3
0000740ecffd9d1a  vmovaps [rsp+0x40], xmm4
0000740ecffd9d20  vmovaps [rsp+0x50], xmm5
0000740ecffd9d26  vmovaps [rsp+0x60], xmm6
0000740ecffd9d2c  vmovaps [rsp+0x70], xmm7
0000740ecffd9d32  vmovaps [rsp+0x80], xmm8
0000740ecffd9d3b  vmovaps [rsp+0x90], xmm9
0000740ecffd9d44  vmovaps [rsp+0xA0], xmm11
0000740ecffd9d4d  vmovaps [rsp+0xB0], xmm12
0000740ecffd9d56  vmovaps [rsp+0xC0], xmm13
0000740ecffd9d5f  vmovaps [rsp+0xD0], xmm14
0000740ecffd9d68  vmovaps [rsp+0xE0], xmm15
0000740ecffd9d71  sub rsp, 0x30
0000740ecffd9d75  movaps [rsp], xmm10
0000740ecffd9d7a  movaps [rsp+0x10], xmm14
0000740ecffd9d80  movaps [rsp+0x20], xmm4
0000740ecffd9d85  lea rdi, [rsp]
0000740ecffd9d89  mov esi, 0x00
0000740ecffd9d8e  mov rax, 0x5E8249CF1530
0000740ecffd9d98  call rax
0000740ecffd9d9a  movaps xmm10, [rsp]
0000740ecffd9d9f  add rsp, 0x30
0000740ecffd9da3  vmovaps xmm0, [rsp]
0000740ecffd9da8  vmovaps xmm1, [rsp+0x10]
0000740ecffd9dae  vmovaps xmm2, [rsp+0x20]
0000740ecffd9db4  vmovaps xmm3, [rsp+0x30]
0000740ecffd9dba  vmovaps xmm4, [rsp+0x40]
0000740ecffd9dc0  vmovaps xmm5, [rsp+0x50]
0000740ecffd9dc6  vmovaps xmm6, [rsp+0x60]
0000740ecffd9dcc  vmovaps xmm7, [rsp+0x70]
0000740ecffd9dd2  vmovaps xmm8, [rsp+0x80]
0000740ecffd9ddb  vmovaps xmm9, [rsp+0x90]
0000740ecffd9de4  vmovaps xmm11, [rsp+0xA0]
0000740ecffd9ded  vmovaps xmm12, [rsp+0xB0]
0000740ecffd9df6  vmovaps xmm13, [rsp+0xC0]
0000740ecffd9dff  vmovaps xmm14, [rsp+0xD0]
0000740ecffd9e08  vmovaps xmm15, [rsp+0xE0]
0000740ecffd9e11  add rsp, 0xF0
0000740ecffd9e18  pop r11
0000740ecffd9e1a  pop r10
0000740ecffd9e1c  pop r9
0000740ecffd9e1e  pop r8
0000740ecffd9e20  pop rsi
0000740ecffd9e21  pop rdi
0000740ecffd9e22  pop rdx
0000740ecffd9e23  pop rcx
0000740ecffd9e24  pop rax
0000740ecffd9e25  add rsp, 0x08
0000740ecffd9e29  jmp 0x0000740ECFFD6388
0000740ecffd9e2e  sub rsp, 0x08
0000740ecffd9e32  push rax
0000740ecffd9e33  push rcx
0000740ecffd9e34  push rdx
0000740ecffd9e35  push rdi
0000740ecffd9e36  push rsi
0000740ecffd9e37  push r8
0000740ecffd9e39  push r9
0000740ecffd9e3b  push r10
0000740ecffd9e3d  push r11
0000740ecffd9e3f  sub rsp, 0xF0
0000740ecffd9e46  vmovaps [rsp], xmm0
0000740ecffd9e4b  vmovaps [rsp+0x10], xmm1
0000740ecffd9e51  vmovaps [rsp+0x20], xmm2
0000740ecffd9e57  vmovaps [rsp+0x30], xmm3
0000740ecffd9e5d  vmovaps [rsp+0x40], xmm4
0000740ecffd9e63  vmovaps [rsp+0x50], xmm5
0000740ecffd9e69  vmovaps [rsp+0x60], xmm6
0000740ecffd9e6f  vmovaps [rsp+0x70], xmm7
0000740ecffd9e75  vmovaps [rsp+0x80], xmm9
0000740ecffd9e7e  vmovaps [rsp+0x90], xmm10
0000740ecffd9e87  vmovaps [rsp+0xA0], xmm11
0000740ecffd9e90  vmovaps [rsp+0xB0], xmm12
0000740ecffd9e99  vmovaps [rsp+0xC0], xmm13
0000740ecffd9ea2  vmovaps [rsp+0xD0], xmm14
0000740ecffd9eab  vmovaps [rsp+0xE0], xmm15
0000740ecffd9eb4  sub rsp, 0x30
0000740ecffd9eb8  movaps [rsp], xmm8
0000740ecffd9ebd  movaps [rsp+0x10], xmm1
0000740ecffd9ec2  movaps [rsp+0x20], xmm14
0000740ecffd9ec8  lea rdi, [rsp]
0000740ecffd9ecc  mov esi, 0x00
0000740ecffd9ed1  mov rax, 0x5E8249CF1530
0000740ecffd9edb  call rax
0000740ecffd9edd  movaps xmm8, [rsp]
0000740ecffd9ee2  add rsp, 0x30
0000740ecffd9ee6  vmovaps xmm0, [rsp]
0000740ecffd9eeb  vmovaps xmm1, [rsp+0x10]
0000740ecffd9ef1  vmovaps xmm2, [rsp+0x20]
0000740ecffd9ef7  vmovaps xmm3, [rsp+0x30]
0000740ecffd9efd  vmovaps xmm4, [rsp+0x40]
0000740ecffd9f03  vmovaps xmm5, [rsp+0x50]
0000740ecffd9f09  vmovaps xmm6, [rsp+0x60]
0000740ecffd9f0f  vmovaps xmm7, [rsp+0x70]
0000740ecffd9f15  vmovaps xmm9, [rsp+0x80]
0000740ecffd9f1e  vmovaps xmm10, [rsp+0x90]
0000740ecffd9f27  vmovaps xmm11, [rsp+0xA0]
0000740ecffd9f30  vmovaps xmm12, [rsp+0xB0]
0000740ecffd9f39  vmovaps xmm13, [rsp+0xC0]
0000740ecffd9f42  vmovaps xmm14, [rsp+0xD0]
0000740ecffd9f4b  vmovaps xmm15, [rsp+0xE0]
0000740ecffd9f54  add rsp, 0xF0
0000740ecffd9f5b  pop r11
0000740ecffd9f5d  pop r10
0000740ecffd9f5f  pop r9
0000740ecffd9f61  pop r8
0000740ecffd9f63  pop rsi
0000740ecffd9f64  pop rdi
0000740ecffd9f65  pop rdx
0000740ecffd9f66  pop rcx
0000740ecffd9f67  pop rax
0000740ecffd9f68  add rsp, 0x08
0000740ecffd9f6c  jmp 0x0000740ECFFD63AE
0000740ecffd9f71  sub rsp, 0x08
0000740ecffd9f75  push rax
0000740ecffd9f76  push rcx
0000740ecffd9f77  push rdx
0000740ecffd9f78  push rdi
0000740ecffd9f79  push rsi
0000740ecffd9f7a  push r8
0000740ecffd9f7c  push r9
0000740ecffd9f7e  push r10
0000740ecffd9f80  push r11
0000740ecffd9f82  sub rsp, 0xF0
0000740ecffd9f89  vmovaps [rsp], xmm0
0000740ecffd9f8e  vmovaps [rsp+0x10], xmm1
0000740ecffd9f94  vmovaps [rsp+0x20], xmm2
0000740ecffd9f9a  vmovaps [rsp+0x30], xmm3
0000740ecffd9fa0  vmovaps [rsp+0x40], xmm4
0000740ecffd9fa6  vmovaps [rsp+0x50], xmm5
0000740ecffd9fac  vmovaps [rsp+0x60], xmm7
0000740ecffd9fb2  vmovaps [rsp+0x70], xmm8
0000740ecffd9fb8  vmovaps [rsp+0x80], xmm9
0000740ecffd9fc1  vmovaps [rsp+0x90], xmm10
0000740ecffd9fca  vmovaps [rsp+0xA0], xmm11
0000740ecffd9fd3  vmovaps [rsp+0xB0], xmm12
0000740ecffd9fdc  vmovaps [rsp+0xC0], xmm13
0000740ecffd9fe5  vmovaps [rsp+0xD0], xmm14
0000740ecffd9fee  vmovaps [rsp+0xE0], xmm15
0000740ecffd9ff7  sub rsp, 0x30
0000740ecffd9ffb  movaps [rsp], xmm6
0000740ecffd9fff  movaps [rsp+0x10], xmm1
0000740ecffda004  movaps [rsp+0x20], xmm14
0000740ecffda00a  lea rdi, [rsp]
0000740ecffda00e  mov esi, 0x00
0000740ecffda013  mov rax, 0x5E8249CF1530
0000740ecffda01d  call rax
0000740ecffda01f  movaps xmm6, [rsp]
0000740ecffda023  add rsp, 0x30
0000740ecffda027  vmovaps xmm0, [rsp]
0000740ecffda02c  vmovaps xmm1, [rsp+0x10]
0000740ecffda032  vmovaps xmm2, [rsp+0x20]
0000740ecffda038  vmovaps xmm3, [rsp+0x30]
0000740ecffda03e  vmovaps xmm4, [rsp+0x40]
0000740ecffda044  vmovaps xmm5, [rsp+0x50]
0000740ecffda04a  vmovaps xmm7, [rsp+0x60]
0000740ecffda050  vmovaps xmm8, [rsp+0x70]
0000740ecffda056  vmovaps xmm9, [rsp+0x80]
0000740ecffda05f  vmovaps xmm10, [rsp+0x90]
0000740ecffda068  vmovaps xmm11, [rsp+0xA0]
0000740ecffda071  vmovaps xmm12, [rsp+0xB0]
0000740ecffda07a  vmovaps xmm13, [rsp+0xC0]
0000740ecffda083  vmovaps xmm14, [rsp+0xD0]
0000740ecffda08c  vmovaps xmm15, [rsp+0xE0]
0000740ecffda095  add rsp, 0xF0
0000740ecffda09c  pop r11
0000740ecffda09e  pop r10
0000740ecffda0a0  pop r9
0000740ecffda0a2  pop r8
0000740ecffda0a4  pop rsi
0000740ecffda0a5  pop rdi
0000740ecffda0a6  pop rdx
0000740ecffda0a7  pop rcx
0000740ecffda0a8  pop rax
0000740ecffda0a9  add rsp, 0x08
0000740ecffda0ad  jmp 0x0000740ECFFD63DA
0000740ecffda0b2  sub rsp, 0x08
0000740ecffda0b6  push rax
0000740ecffda0b7  push rcx
0000740ecffda0b8  push rdx
0000740ecffda0b9  push rdi
0000740ecffda0ba  push rsi
0000740ecffda0bb  push r8
0000740ecffda0bd  push r9
0000740ecffda0bf  push r10
0000740ecffda0c1  push r11
0000740ecffda0c3  sub rsp, 0xF0
0000740ecffda0ca  vmovaps [rsp], xmm0
0000740ecffda0cf  vmovaps [rsp+0x10], xmm1
0000740ecffda0d5  vmovaps [rsp+0x20], xmm2
0000740ecffda0db  vmovaps [rsp+0x30], xmm3
0000740ecffda0e1  vmovaps [rsp+0x40], xmm4
0000740ecffda0e7  vmovaps [rsp+0x50], xmm5
0000740ecffda0ed  vmovaps [rsp+0x60], xmm6
0000740ecffda0f3  vmovaps [rsp+0x70], xmm7
0000740ecffda0f9  vmovaps [rsp+0x80], xmm8
0000740ecffda102  vmovaps [rsp+0x90], xmm9
0000740ecffda10b  vmovaps [rsp+0xA0], xmm10
0000740ecffda114  vmovaps [rsp+0xB0], xmm11
0000740ecffda11d  vmovaps [rsp+0xC0], xmm12
0000740ecffda126  vmovaps [rsp+0xD0], xmm13
0000740ecffda12f  vmovaps [rsp+0xE0], xmm15
0000740ecffda138  sub rsp, 0x30
0000740ecffda13c  movaps [rsp], xmm14
0000740ecffda141  movaps [rsp+0x10], xmm12
0000740ecffda147  movaps [rsp+0x20], xmm1
0000740ecffda14c  lea rdi, [rsp]
0000740ecffda150  mov esi, 0x00
0000740ecffda155  mov rax, 0x5E8249CF1530
0000740ecffda15f  call rax
0000740ecffda161  movaps xmm14, [rsp]
0000740ecffda166  add rsp, 0x30
0000740ecffda16a  vmovaps xmm0, [rsp]
0000740ecffda16f  vmovaps xmm1, [rsp+0x10]
0000740ecffda175  vmovaps xmm2, [rsp+0x20]
0000740ecffda17b  vmovaps xmm3, [rsp+0x30]
0000740ecffda181  vmovaps xmm4, [rsp+0x40]
0000740ecffda187  vmovaps xmm5, [rsp+0x50]
0000740ecffda18d  vmovaps xmm6, [rsp+0x60]
0000740ecffda193  vmovaps xmm7, [rsp+0x70]
0000740ecffda199  vmovaps xmm8, [rsp+0x80]
0000740ecffda1a2  vmovaps xmm9, [rsp+0x90]
0000740ecffda1ab  vmovaps xmm10, [rsp+0xA0]
0000740ecffda1b4  vmovaps xmm11, [rsp+0xB0]
0000740ecffda1bd  vmovaps xmm12, [rsp+0xC0]
0000740ecffda1c6  vmovaps xmm13, [rsp+0xD0]
0000740ecffda1cf  vmovaps xmm15, [rsp+0xE0]
0000740ecffda1d8  add rsp, 0xF0
0000740ecffda1df  pop r11
0000740ecffda1e1  pop r10
0000740ecffda1e3  pop r9
0000740ecffda1e5  pop r8
0000740ecffda1e7  pop rsi
0000740ecffda1e8  pop rdi
0000740ecffda1e9  pop rdx
0000740ecffda1ea  pop rcx
0000740ecffda1eb  pop rax
0000740ecffda1ec  add rsp, 0x08
0000740ecffda1f0  jmp 0x0000740ECFFD6400
0000740ecffda1f5  sub rsp, 0x08
0000740ecffda1f9  push rax
0000740ecffda1fa  push rcx
0000740ecffda1fb  push rdx
0000740ecffda1fc  push rdi
0000740ecffda1fd  push rsi
0000740ecffda1fe  push r8
0000740ecffda200  push r9
0000740ecffda202  push r10
0000740ecffda204  push r11
0000740ecffda206  sub rsp, 0xF0
0000740ecffda20d  vmovaps [rsp], xmm0
0000740ecffda212  vmovaps [rsp+0x10], xmm2
0000740ecffda218  vmovaps [rsp+0x20], xmm3
0000740ecffda21e  vmovaps [rsp+0x30], xmm4
0000740ecffda224  vmovaps [rsp+0x40], xmm5
0000740ecffda22a  vmovaps [rsp+0x50], xmm6
0000740ecffda230  vmovaps [rsp+0x60], xmm7
0000740ecffda236  vmovaps [rsp+0x70], xmm8
0000740ecffda23c  vmovaps [rsp+0x80], xmm9
0000740ecffda245  vmovaps [rsp+0x90], xmm10
0000740ecffda24e  vmovaps [rsp+0xA0], xmm11
0000740ecffda257  vmovaps [rsp+0xB0], xmm12
0000740ecffda260  vmovaps [rsp+0xC0], xmm13
0000740ecffda269  vmovaps [rsp+0xD0], xmm14
0000740ecffda272  vmovaps [rsp+0xE0], xmm15
0000740ecffda27b  sub rsp, 0x30
0000740ecffda27f  movaps [rsp], xmm1
0000740ecffda283  movaps [rsp+0x10], xmm13
0000740ecffda289  movaps [rsp+0x20], xmm9
0000740ecffda28f  lea rdi, [rsp]
0000740ecffda293  mov esi, 0x00
0000740ecffda298  mov rax, 0x5E8249CF1530
0000740ecffda2a2  call rax
0000740ecffda2a4  movaps xmm1, [rsp]
0000740ecffda2a8  add rsp, 0x30
0000740ecffda2ac  vmovaps xmm0, [rsp]
0000740ecffda2b1  vmovaps xmm2, [rsp+0x10]
0000740ecffda2b7  vmovaps xmm3, [rsp+0x20]
0000740ecffda2bd  vmovaps xmm4, [rsp+0x30]
0000740ecffda2c3  vmovaps xmm5, [rsp+0x40]
0000740ecffda2c9  vmovaps xmm6, [rsp+0x50]
0000740ecffda2cf  vmovaps xmm7, [rsp+0x60]
0000740ecffda2d5  vmovaps xmm8, [rsp+0x70]
0000740ecffda2db  vmovaps xmm9, [rsp+0x80]
0000740ecffda2e4  vmovaps xmm10, [rsp+0x90]
0000740ecffda2ed  vmovaps xmm11, [rsp+0xA0]
0000740ecffda2f6  vmovaps xmm12, [rsp+0xB0]
0000740ecffda2ff  vmovaps xmm13, [rsp+0xC0]
0000740ecffda308  vmovaps xmm14, [rsp+0xD0]
0000740ecffda311  vmovaps xmm15, [rsp+0xE0]
0000740ecffda31a  add rsp, 0xF0
0000740ecffda321  pop r11
0000740ecffda323  pop r10
0000740ecffda325  pop r9
0000740ecffda327  pop r8
0000740ecffda329  pop rsi
0000740ecffda32a  pop rdi
0000740ecffda32b  pop rdx
0000740ecffda32c  pop rcx
0000740ecffda32d  pop rax
0000740ecffda32e  add rsp, 0x08
0000740ecffda332  jmp 0x0000740ECFFD641A
0000740ecffda337  sub rsp, 0x08
0000740ecffda33b  push rax
0000740ecffda33c  push rcx
0000740ecffda33d  push rdx
0000740ecffda33e  push rdi
0000740ecffda33f  push rsi
0000740ecffda340  push r8
0000740ecffda342  push r9
0000740ecffda344  push r10
0000740ecffda346  push r11
0000740ecffda348  sub rsp, 0xF0
0000740ecffda34f  vmovaps [rsp], xmm0
0000740ecffda354  vmovaps [rsp+0x10], xmm1
0000740ecffda35a  vmovaps [rsp+0x20], xmm2
0000740ecffda360  vmovaps [rsp+0x30], xmm3
0000740ecffda366  vmovaps [rsp+0x40], xmm4
0000740ecffda36c  vmovaps [rsp+0x50], xmm5
0000740ecffda372  vmovaps [rsp+0x60], xmm6
0000740ecffda378  vmovaps [rsp+0x70], xmm7
0000740ecffda37e  vmovaps [rsp+0x80], xmm8
0000740ecffda387  vmovaps [rsp+0x90], xmm9
0000740ecffda390  vmovaps [rsp+0xA0], xmm10
0000740ecffda399  vmovaps [rsp+0xB0], xmm11
0000740ecffda3a2  vmovaps [rsp+0xC0], xmm13
0000740ecffda3ab  vmovaps [rsp+0xD0], xmm14
0000740ecffda3b4  vmovaps [rsp+0xE0], xmm15
0000740ecffda3bd  sub rsp, 0x30
0000740ecffda3c1  movaps [rsp], xmm12
0000740ecffda3c6  movaps [rsp+0x10], xmm7
0000740ecffda3cb  movaps [rsp+0x20], xmm13
0000740ecffda3d1  lea rdi, [rsp]
0000740ecffda3d5  mov esi, 0x00
0000740ecffda3da  mov rax, 0x5E8249CF1530
0000740ecffda3e4  call rax
0000740ecffda3e6  movaps xmm12, [rsp]
0000740ecffda3eb  add rsp, 0x30
0000740ecffda3ef  vmovaps xmm0, [rsp]
0000740ecffda3f4  vmovaps xmm1, [rsp+0x10]
0000740ecffda3fa  vmovaps xmm2, [rsp+0x20]
0000740ecffda400  vmovaps xmm3, [rsp+0x30]
0000740ecffda406  vmovaps xmm4, [rsp+0x40]
0000740ecffda40c  vmovaps xmm5, [rsp+0x50]
0000740ecffda412  vmovaps xmm6, [rsp+0x60]
0000740ecffda418  vmovaps xmm7, [rsp+0x70]
0000740ecffda41e  vmovaps xmm8, [rsp+0x80]
0000740ecffda427  vmovaps xmm9, [rsp+0x90]
0000740ecffda430  vmovaps xmm10, [rsp+0xA0]
0000740ecffda439  vmovaps xmm11, [rsp+0xB0]
0000740ecffda442  vmovaps xmm13, [rsp+0xC0]
0000740ecffda44b  vmovaps xmm14, [rsp+0xD0]
0000740ecffda454  vmovaps xmm15, [rsp+0xE0]
0000740ecffda45d  add rsp, 0xF0
0000740ecffda464  pop r11
0000740ecffda466  pop r10
0000740ecffda468  pop r9
0000740ecffda46a  pop r8
0000740ecffda46c  pop rsi
0000740ecffda46d  pop rdi
0000740ecffda46e  pop rdx
0000740ecffda46f  pop rcx
0000740ecffda470  pop rax
0000740ecffda471  add rsp, 0x08
0000740ecffda475  jmp 0x0000740ECFFD6441
0000740ecffda47a  sub rsp, 0x08
0000740ecffda47e  push rax
0000740ecffda47f  push rcx
0000740ecffda480  push rdx
0000740ecffda481  push rdi
0000740ecffda482  push rsi
0000740ecffda483  push r8
0000740ecffda485  push r9
0000740ecffda487  push r10
0000740ecffda489  push r11
0000740ecffda48b  sub rsp, 0xF0
0000740ecffda492  vmovaps [rsp], xmm0
0000740ecffda497  vmovaps [rsp+0x10], xmm1
0000740ecffda49d  vmovaps [rsp+0x20], xmm2
0000740ecffda4a3  vmovaps [rsp+0x30], xmm3
0000740ecffda4a9  vmovaps [rsp+0x40], xmm4
0000740ecffda4af  vmovaps [rsp+0x50], xmm5
0000740ecffda4b5  vmovaps [rsp+0x60], xmm6
0000740ecffda4bb  vmovaps [rsp+0x70], xmm7
0000740ecffda4c1  vmovaps [rsp+0x80], xmm8
0000740ecffda4ca  vmovaps [rsp+0x90], xmm9
0000740ecffda4d3  vmovaps [rsp+0xA0], xmm10
0000740ecffda4dc  vmovaps [rsp+0xB0], xmm11
0000740ecffda4e5  vmovaps [rsp+0xC0], xmm12
0000740ecffda4ee  vmovaps [rsp+0xD0], xmm14
0000740ecffda4f7  vmovaps [rsp+0xE0], xmm15
0000740ecffda500  sub rsp, 0x30
0000740ecffda504  movaps [rsp], xmm13
0000740ecffda509  movaps [rsp+0x10], xmm15
0000740ecffda50f  movaps [rsp+0x20], xmm8
0000740ecffda515  lea rdi, [rsp]
0000740ecffda519  mov esi, 0x00
0000740ecffda51e  mov rax, 0x5E8249CF1530
0000740ecffda528  call rax
0000740ecffda52a  movaps xmm13, [rsp]
0000740ecffda52f  add rsp, 0x30
0000740ecffda533  vmovaps xmm0, [rsp]
0000740ecffda538  vmovaps xmm1, [rsp+0x10]
0000740ecffda53e  vmovaps xmm2, [rsp+0x20]
0000740ecffda544  vmovaps xmm3, [rsp+0x30]
0000740ecffda54a  vmovaps xmm4, [rsp+0x40]
0000740ecffda550  vmovaps xmm5, [rsp+0x50]
0000740ecffda556  vmovaps xmm6, [rsp+0x60]
0000740ecffda55c  vmovaps xmm7, [rsp+0x70]
0000740ecffda562  vmovaps xmm8, [rsp+0x80]
0000740ecffda56b  vmovaps xmm9, [rsp+0x90]
0000740ecffda574  vmovaps xmm10, [rsp+0xA0]
0000740ecffda57d  vmovaps xmm11, [rsp+0xB0]
0000740ecffda586  vmovaps xmm12, [rsp+0xC0]
0000740ecffda58f  vmovaps xmm14, [rsp+0xD0]
0000740ecffda598  vmovaps xmm15, [rsp+0xE0]
0000740ecffda5a1  add rsp, 0xF0
0000740ecffda5a8  pop r11
0000740ecffda5aa  pop r10
0000740ecffda5ac  pop r9
0000740ecffda5ae  pop r8
0000740ecffda5b0  pop rsi
0000740ecffda5b1  pop rdi
0000740ecffda5b2  pop rdx
0000740ecffda5b3  pop rcx
0000740ecffda5b4  pop rax
0000740ecffda5b5  add rsp, 0x08
0000740ecffda5b9  jmp 0x0000740ECFFD645C
0000740ecffda5be  sub rsp, 0x08
0000740ecffda5c2  push rax
0000740ecffda5c3  push rcx
0000740ecffda5c4  push rdx
0000740ecffda5c5  push rdi
0000740ecffda5c6  push rsi
0000740ecffda5c7  push r8
0000740ecffda5c9  push r9
0000740ecffda5cb  push r10
0000740ecffda5cd  push r11
0000740ecffda5cf  sub rsp, 0xF0
0000740ecffda5d6  vmovaps [rsp], xmm0
0000740ecffda5db  vmovaps [rsp+0x10], xmm1
0000740ecffda5e1  vmovaps [rsp+0x20], xmm2
0000740ecffda5e7  vmovaps [rsp+0x30], xmm3
0000740ecffda5ed  vmovaps [rsp+0x40], xmm4
0000740ecffda5f3  vmovaps [rsp+0x50], xmm5
0000740ecffda5f9  vmovaps [rsp+0x60], xmm6
0000740ecffda5ff  vmovaps [rsp+0x70], xmm7
0000740ecffda605  vmovaps [rsp+0x80], xmm9
0000740ecffda60e  vmovaps [rsp+0x90], xmm10
0000740ecffda617  vmovaps [rsp+0xA0], xmm11
0000740ecffda620  vmovaps [rsp+0xB0], xmm12
0000740ecffda629  vmovaps [rsp+0xC0], xmm13
0000740ecffda632  vmovaps [rsp+0xD0], xmm14
0000740ecffda63b  vmovaps [rsp+0xE0], xmm15
0000740ecffda644  sub rsp, 0x30
0000740ecffda648  movaps [rsp], xmm8
0000740ecffda64d  movaps [rsp+0x10], xmm15
0000740ecffda653  movaps [rsp+0x20], xmm9
0000740ecffda659  lea rdi, [rsp]
0000740ecffda65d  mov esi, 0x00
0000740ecffda662  mov rax, 0x5E8249CF1530
0000740ecffda66c  call rax
0000740ecffda66e  movaps xmm8, [rsp]
0000740ecffda673  add rsp, 0x30
0000740ecffda677  vmovaps xmm0, [rsp]
0000740ecffda67c  vmovaps xmm1, [rsp+0x10]
0000740ecffda682  vmovaps xmm2, [rsp+0x20]
0000740ecffda688  vmovaps xmm3, [rsp+0x30]
0000740ecffda68e  vmovaps xmm4, [rsp+0x40]
0000740ecffda694  vmovaps xmm5, [rsp+0x50]
0000740ecffda69a  vmovaps xmm6, [rsp+0x60]
0000740ecffda6a0  vmovaps xmm7, [rsp+0x70]
0000740ecffda6a6  vmovaps xmm9, [rsp+0x80]
0000740ecffda6af  vmovaps xmm10, [rsp+0x90]
0000740ecffda6b8  vmovaps xmm11, [rsp+0xA0]
0000740ecffda6c1  vmovaps xmm12, [rsp+0xB0]
0000740ecffda6ca  vmovaps xmm13, [rsp+0xC0]
0000740ecffda6d3  vmovaps xmm14, [rsp+0xD0]
0000740ecffda6dc  vmovaps xmm15, [rsp+0xE0]
0000740ecffda6e5  add rsp, 0xF0
0000740ecffda6ec  pop r11
0000740ecffda6ee  pop r10
0000740ecffda6f0  pop r9
0000740ecffda6f2  pop r8
0000740ecffda6f4  pop rsi
0000740ecffda6f5  pop rdi
0000740ecffda6f6  pop rdx
0000740ecffda6f7  pop rcx
0000740ecffda6f8  pop rax
0000740ecffda6f9  add rsp, 0x08
0000740ecffda6fd  jmp 0x0000740ECFFD648A
0000740ecffda702  sub rsp, 0x08
0000740ecffda706  push rax
0000740ecffda707  push rcx
0000740ecffda708  push rdx
0000740ecffda709  push rdi
0000740ecffda70a  push rsi
0000740ecffda70b  push r8
0000740ecffda70d  push r9
0000740ecffda70f  push r10
0000740ecffda711  push r11
0000740ecffda713  sub rsp, 0xF0
0000740ecffda71a  vmovaps [rsp], xmm0
0000740ecffda71f  vmovaps [rsp+0x10], xmm1
0000740ecffda725  vmovaps [rsp+0x20], xmm2
0000740ecffda72b  vmovaps [rsp+0x30], xmm3
0000740ecffda731  vmovaps [rsp+0x40], xmm4
0000740ecffda737  vmovaps [rsp+0x50], xmm5
0000740ecffda73d  vmovaps [rsp+0x60], xmm6
0000740ecffda743  vmovaps [rsp+0x70], xmm7
0000740ecffda749  vmovaps [rsp+0x80], xmm8
0000740ecffda752  vmovaps [rsp+0x90], xmm9
0000740ecffda75b  vmovaps [rsp+0xA0], xmm10
0000740ecffda764  vmovaps [rsp+0xB0], xmm11
0000740ecffda76d  vmovaps [rsp+0xC0], xmm12
0000740ecffda776  vmovaps [rsp+0xD0], xmm13
0000740ecffda77f  vmovaps [rsp+0xE0], xmm14
0000740ecffda788  sub rsp, 0x30
0000740ecffda78c  movaps [rsp], xmm15
0000740ecffda791  movaps [rsp+0x10], xmm11
0000740ecffda797  movaps [rsp+0x20], xmm6
0000740ecffda79c  lea rdi, [rsp]
0000740ecffda7a0  mov esi, 0x00
0000740ecffda7a5  mov rax, 0x5E8249CF1530
0000740ecffda7af  call rax
0000740ecffda7b1  movaps xmm15, [rsp]
0000740ecffda7b6  add rsp, 0x30
0000740ecffda7ba  vmovaps xmm0, [rsp]
0000740ecffda7bf  vmovaps xmm1, [rsp+0x10]
0000740ecffda7c5  vmovaps xmm2, [rsp+0x20]
0000740ecffda7cb  vmovaps xmm3, [rsp+0x30]
0000740ecffda7d1  vmovaps xmm4, [rsp+0x40]
0000740ecffda7d7  vmovaps xmm5, [rsp+0x50]
0000740ecffda7dd  vmovaps xmm6, [rsp+0x60]
0000740ecffda7e3  vmovaps xmm7, [rsp+0x70]
0000740ecffda7e9  vmovaps xmm8, [rsp+0x80]
0000740ecffda7f2  vmovaps xmm9, [rsp+0x90]
0000740ecffda7fb  vmovaps xmm10, [rsp+0xA0]
0000740ecffda804  vmovaps xmm11, [rsp+0xB0]
0000740ecffda80d  vmovaps xmm12, [rsp+0xC0]
0000740ecffda816  vmovaps xmm13, [rsp+0xD0]
0000740ecffda81f  vmovaps xmm14, [rsp+0xE0]
0000740ecffda828  add rsp, 0xF0
0000740ecffda82f  pop r11
0000740ecffda831  pop r10
0000740ecffda833  pop r9
0000740ecffda835  pop r8
0000740ecffda837  pop rsi
0000740ecffda838  pop rdi
0000740ecffda839  pop rdx
0000740ecffda83a  pop rcx
0000740ecffda83b  pop rax
0000740ecffda83c  add rsp, 0x08
0000740ecffda840  jmp 0x0000740ECFFD64A5
0000740ecffda845  sub rsp, 0x08
0000740ecffda849  push rax
0000740ecffda84a  push rcx
0000740ecffda84b  push rdx
0000740ecffda84c  push rdi
0000740ecffda84d  push rsi
0000740ecffda84e  push r8
0000740ecffda850  push r9
0000740ecffda852  push r10
0000740ecffda854  push r11
0000740ecffda856  sub rsp, 0xF0
0000740ecffda85d  vmovaps [rsp], xmm0
0000740ecffda862  vmovaps [rsp+0x10], xmm1
0000740ecffda868  vmovaps [rsp+0x20], xmm2
0000740ecffda86e  vmovaps [rsp+0x30], xmm3
0000740ecffda874  vmovaps [rsp+0x40], xmm4
0000740ecffda87a  vmovaps [rsp+0x50], xmm5
0000740ecffda880  vmovaps [rsp+0x60], xmm6
0000740ecffda886  vmovaps [rsp+0x70], xmm8
0000740ecffda88c  vmovaps [rsp+0x80], xmm9
0000740ecffda895  vmovaps [rsp+0x90], xmm10
0000740ecffda89e  vmovaps [rsp+0xA0], xmm11
0000740ecffda8a7  vmovaps [rsp+0xB0], xmm12
0000740ecffda8b0  vmovaps [rsp+0xC0], xmm13
0000740ecffda8b9  vmovaps [rsp+0xD0], xmm14
0000740ecffda8c2  vmovaps [rsp+0xE0], xmm15
0000740ecffda8cb  sub rsp, 0x30
0000740ecffda8cf  movaps [rsp], xmm7
0000740ecffda8d3  movaps [rsp+0x10], xmm11
0000740ecffda8d9  movaps [rsp+0x20], xmm9
0000740ecffda8df  lea rdi, [rsp]
0000740ecffda8e3  mov esi, 0x00
0000740ecffda8e8  mov rax, 0x5E8249CF1530
0000740ecffda8f2  call rax
0000740ecffda8f4  movaps xmm7, [rsp]
0000740ecffda8f8  add rsp, 0x30
0000740ecffda8fc  vmovaps xmm0, [rsp]
0000740ecffda901  vmovaps xmm1, [rsp+0x10]
0000740ecffda907  vmovaps xmm2, [rsp+0x20]
0000740ecffda90d  vmovaps xmm3, [rsp+0x30]
0000740ecffda913  vmovaps xmm4, [rsp+0x40]
0000740ecffda919  vmovaps xmm5, [rsp+0x50]
0000740ecffda91f  vmovaps xmm6, [rsp+0x60]
0000740ecffda925  vmovaps xmm8, [rsp+0x70]
0000740ecffda92b  vmovaps xmm9, [rsp+0x80]
0000740ecffda934  vmovaps xmm10, [rsp+0x90]
0000740ecffda93d  vmovaps xmm11, [rsp+0xA0]
0000740ecffda946  vmovaps xmm12, [rsp+0xB0]
0000740ecffda94f  vmovaps xmm13, [rsp+0xC0]
0000740ecffda958  vmovaps xmm14, [rsp+0xD0]
0000740ecffda961  vmovaps xmm15, [rsp+0xE0]
0000740ecffda96a  add rsp, 0xF0
0000740ecffda971  pop r11
0000740ecffda973  pop r10
0000740ecffda975  pop r9
0000740ecffda977  pop r8
0000740ecffda979  pop rsi
0000740ecffda97a  pop rdi
0000740ecffda97b  pop rdx
0000740ecffda97c  pop rcx
0000740ecffda97d  pop rax
0000740ecffda97e  add rsp, 0x08
0000740ecffda982  jmp 0x0000740ECFFD64D2
0000740ecffda987  sub rsp, 0x08
0000740ecffda98b  push rax
0000740ecffda98c  push rcx
0000740ecffda98d  push rdx
0000740ecffda98e  push rdi
0000740ecffda98f  push rsi
0000740ecffda990  push r8
0000740ecffda992  push r9
0000740ecffda994  push r10
0000740ecffda996  push r11
0000740ecffda998  sub rsp, 0xF0
0000740ecffda99f  vmovaps [rsp], xmm0
0000740ecffda9a4  vmovaps [rsp+0x10], xmm1
0000740ecffda9aa  vmovaps [rsp+0x20], xmm2
0000740ecffda9b0  vmovaps [rsp+0x30], xmm3
0000740ecffda9b6  vmovaps [rsp+0x40], xmm4
0000740ecffda9bc  vmovaps [rsp+0x50], xmm5
0000740ecffda9c2  vmovaps [rsp+0x60], xmm6
0000740ecffda9c8  vmovaps [rsp+0x70], xmm7
0000740ecffda9ce  vmovaps [rsp+0x80], xmm8
0000740ecffda9d7  vmovaps [rsp+0x90], xmm9
0000740ecffda9e0  vmovaps [rsp+0xA0], xmm10
0000740ecffda9e9  vmovaps [rsp+0xB0], xmm12
0000740ecffda9f2  vmovaps [rsp+0xC0], xmm13
0000740ecffda9fb  vmovaps [rsp+0xD0], xmm14
0000740ecffdaa04  vmovaps [rsp+0xE0], xmm15
0000740ecffdaa0d  sub rsp, 0x30
0000740ecffdaa11  movaps [rsp], xmm11
0000740ecffdaa16  movaps [rsp+0x10], xmm10
0000740ecffdaa1c  movaps [rsp+0x20], xmm14
0000740ecffdaa22  lea rdi, [rsp]
0000740ecffdaa26  mov esi, 0x00
0000740ecffdaa2b  mov rax, 0x5E8249CF1530
0000740ecffdaa35  call rax
0000740ecffdaa37  movaps xmm11, [rsp]
0000740ecffdaa3c  add rsp, 0x30
0000740ecffdaa40  vmovaps xmm0, [rsp]
0000740ecffdaa45  vmovaps xmm1, [rsp+0x10]
0000740ecffdaa4b  vmovaps xmm2, [rsp+0x20]
0000740ecffdaa51  vmovaps xmm3, [rsp+0x30]
0000740ecffdaa57  vmovaps xmm4, [rsp+0x40]
0000740ecffdaa5d  vmovaps xmm5, [rsp+0x50]
0000740ecffdaa63  vmovaps xmm6, [rsp+0x60]
0000740ecffdaa69  vmovaps xmm7, [rsp+0x70]
0000740ecffdaa6f  vmovaps xmm8, [rsp+0x80]
0000740ecffdaa78  vmovaps xmm9, [rsp+0x90]
0000740ecffdaa81  vmovaps xmm10, [rsp+0xA0]
0000740ecffdaa8a  vmovaps xmm12, [rsp+0xB0]
0000740ecffdaa93  vmovaps xmm13, [rsp+0xC0]
0000740ecffdaa9c  vmovaps xmm14, [rsp+0xD0]
0000740ecffdaaa5  vmovaps xmm15, [rsp+0xE0]
0000740ecffdaaae  add rsp, 0xF0
0000740ecffdaab5  pop r11
0000740ecffdaab7  pop r10
0000740ecffdaab9  pop r9
0000740ecffdaabb  pop r8
0000740ecffdaabd  pop rsi
0000740ecffdaabe  pop rdi
0000740ecffdaabf  pop rdx
0000740ecffdaac0  pop rcx
0000740ecffdaac1  pop rax
0000740ecffdaac2  add rsp, 0x08
0000740ecffdaac6  jmp 0x0000740ECFFD64ED
0000740ecffdaacb  call 0x0000740ECFEE45A0
0000740ecffdaad0  jmp 0x0000740ECFFD64F7
0000740ecffdaad5  sub rsp, 0x08
0000740ecffdaad9  push rax
0000740ecffdaada  push rcx
0000740ecffdaadb  push rdx
0000740ecffdaadc  push rdi
0000740ecffdaadd  push rsi
0000740ecffdaade  push r8
0000740ecffdaae0  push r9
0000740ecffdaae2  push r10
0000740ecffdaae4  push r11
0000740ecffdaae6  sub rsp, 0xF0
0000740ecffdaaed  vmovaps [rsp], xmm0
0000740ecffdaaf2  vmovaps [rsp+0x10], xmm1
0000740ecffdaaf8  vmovaps [rsp+0x20], xmm2
0000740ecffdaafe  vmovaps [rsp+0x30], xmm3
0000740ecffdab04  vmovaps [rsp+0x40], xmm4
0000740ecffdab0a  vmovaps [rsp+0x50], xmm5
0000740ecffdab10  vmovaps [rsp+0x60], xmm6
0000740ecffdab16  vmovaps [rsp+0x70], xmm7
0000740ecffdab1c  vmovaps [rsp+0x80], xmm8
0000740ecffdab25  vmovaps [rsp+0x90], xmm9
0000740ecffdab2e  vmovaps [rsp+0xA0], xmm11
0000740ecffdab37  vmovaps [rsp+0xB0], xmm12
0000740ecffdab40  vmovaps [rsp+0xC0], xmm13
0000740ecffdab49  vmovaps [rsp+0xD0], xmm14
0000740ecffdab52  vmovaps [rsp+0xE0], xmm15
0000740ecffdab5b  sub rsp, 0x30
0000740ecffdab5f  movaps [rsp], xmm10
0000740ecffdab64  movaps [rsp+0x10], xmm1
0000740ecffdab69  movaps [rsp+0x20], xmm12
0000740ecffdab6f  lea rdi, [rsp]
0000740ecffdab73  mov esi, 0x00
0000740ecffdab78  mov rax, 0x5E8249CF1530
0000740ecffdab82  call rax
0000740ecffdab84  movaps xmm10, [rsp]
0000740ecffdab89  add rsp, 0x30
0000740ecffdab8d  vmovaps xmm0, [rsp]
0000740ecffdab92  vmovaps xmm1, [rsp+0x10]
0000740ecffdab98  vmovaps xmm2, [rsp+0x20]
0000740ecffdab9e  vmovaps xmm3, [rsp+0x30]
0000740ecffdaba4  vmovaps xmm4, [rsp+0x40]
0000740ecffdabaa  vmovaps xmm5, [rsp+0x50]
0000740ecffdabb0  vmovaps xmm6, [rsp+0x60]
0000740ecffdabb6  vmovaps xmm7, [rsp+0x70]
0000740ecffdabbc  vmovaps xmm8, [rsp+0x80]
0000740ecffdabc5  vmovaps xmm9, [rsp+0x90]
0000740ecffdabce  vmovaps xmm11, [rsp+0xA0]
0000740ecffdabd7  vmovaps xmm12, [rsp+0xB0]
0000740ecffdabe0  vmovaps xmm13, [rsp+0xC0]
0000740ecffdabe9  vmovaps xmm14, [rsp+0xD0]
0000740ecffdabf2  vmovaps xmm15, [rsp+0xE0]
0000740ecffdabfb  add rsp, 0xF0
0000740ecffdac02  pop r11
0000740ecffdac04  pop r10
0000740ecffdac06  pop r9
0000740ecffdac08  pop r8
0000740ecffdac0a  pop rsi
0000740ecffdac0b  pop rdi
0000740ecffdac0c  pop rdx
0000740ecffdac0d  pop rcx
0000740ecffdac0e  pop rax
0000740ecffdac0f  add rsp, 0x08
0000740ecffdac13  jmp 0x0000740ECFFD651A
0000740ecffdac18  sub rsp, 0x08
0000740ecffdac1c  push rax
0000740ecffdac1d  push rcx
0000740ecffdac1e  push rdx
0000740ecffdac1f  push rdi
0000740ecffdac20  push rsi
0000740ecffdac21  push r8
0000740ecffdac23  push r9
0000740ecffdac25  push r10
0000740ecffdac27  push r11
0000740ecffdac29  sub rsp, 0xF0
0000740ecffdac30  vmovaps [rsp], xmm0
0000740ecffdac35  vmovaps [rsp+0x10], xmm1
0000740ecffdac3b  vmovaps [rsp+0x20], xmm2
0000740ecffdac41  vmovaps [rsp+0x30], xmm3
0000740ecffdac47  vmovaps [rsp+0x40], xmm4
0000740ecffdac4d  vmovaps [rsp+0x50], xmm5
0000740ecffdac53  vmovaps [rsp+0x60], xmm6
0000740ecffdac59  vmovaps [rsp+0x70], xmm7
0000740ecffdac5f  vmovaps [rsp+0x80], xmm8
0000740ecffdac68  vmovaps [rsp+0x90], xmm9
0000740ecffdac71  vmovaps [rsp+0xA0], xmm10
0000740ecffdac7a  vmovaps [rsp+0xB0], xmm11
0000740ecffdac83  vmovaps [rsp+0xC0], xmm13
0000740ecffdac8c  vmovaps [rsp+0xD0], xmm14
0000740ecffdac95  vmovaps [rsp+0xE0], xmm15
0000740ecffdac9e  sub rsp, 0x30
0000740ecffdaca2  movaps [rsp], xmm12
0000740ecffdaca7  movaps [rsp+0x10], xmm14
0000740ecffdacad  movaps [rsp+0x20], xmm1
0000740ecffdacb2  lea rdi, [rsp]
0000740ecffdacb6  mov esi, 0x00
0000740ecffdacbb  mov rax, 0x5E8249CF1530
0000740ecffdacc5  call rax
0000740ecffdacc7  movaps xmm12, [rsp]
0000740ecffdaccc  add rsp, 0x30
0000740ecffdacd0  vmovaps xmm0, [rsp]
0000740ecffdacd5  vmovaps xmm1, [rsp+0x10]
0000740ecffdacdb  vmovaps xmm2, [rsp+0x20]
0000740ecffdace1  vmovaps xmm3, [rsp+0x30]
0000740ecffdace7  vmovaps xmm4, [rsp+0x40]
0000740ecffdaced  vmovaps xmm5, [rsp+0x50]
0000740ecffdacf3  vmovaps xmm6, [rsp+0x60]
0000740ecffdacf9  vmovaps xmm7, [rsp+0x70]
0000740ecffdacff  vmovaps xmm8, [rsp+0x80]
0000740ecffdad08  vmovaps xmm9, [rsp+0x90]
0000740ecffdad11  vmovaps xmm10, [rsp+0xA0]
0000740ecffdad1a  vmovaps xmm11, [rsp+0xB0]
0000740ecffdad23  vmovaps xmm13, [rsp+0xC0]
0000740ecffdad2c  vmovaps xmm14, [rsp+0xD0]
0000740ecffdad35  vmovaps xmm15, [rsp+0xE0]
0000740ecffdad3e  add rsp, 0xF0
0000740ecffdad45  pop r11
0000740ecffdad47  pop r10
0000740ecffdad49  pop r9
0000740ecffdad4b  pop r8
0000740ecffdad4d  pop rsi
0000740ecffdad4e  pop rdi
0000740ecffdad4f  pop rdx
0000740ecffdad50  pop rcx
0000740ecffdad51  pop rax
0000740ecffdad52  add rsp, 0x08
0000740ecffdad56  jmp 0x0000740ECFFD6549
0000740ecffdad5b  sub rsp, 0x08
0000740ecffdad5f  push rax
0000740ecffdad60  push rcx
0000740ecffdad61  push rdx
0000740ecffdad62  push rdi
0000740ecffdad63  push rsi
0000740ecffdad64  push r8
0000740ecffdad66  push r9
0000740ecffdad68  push r10
0000740ecffdad6a  push r11
0000740ecffdad6c  sub rsp, 0xF0
0000740ecffdad73  vmovaps [rsp], xmm0
0000740ecffdad78  vmovaps [rsp+0x10], xmm1
0000740ecffdad7e  vmovaps [rsp+0x20], xmm2
0000740ecffdad84  vmovaps [rsp+0x30], xmm3
0000740ecffdad8a  vmovaps [rsp+0x40], xmm4
0000740ecffdad90  vmovaps [rsp+0x50], xmm5
0000740ecffdad96  vmovaps [rsp+0x60], xmm6
0000740ecffdad9c  vmovaps [rsp+0x70], xmm7
0000740ecffdada2  vmovaps [rsp+0x80], xmm8
0000740ecffdadab  vmovaps [rsp+0x90], xmm9
0000740ecffdadb4  vmovaps [rsp+0xA0], xmm10
0000740ecffdadbd  vmovaps [rsp+0xB0], xmm11
0000740ecffdadc6  vmovaps [rsp+0xC0], xmm12
0000740ecffdadcf  vmovaps [rsp+0xD0], xmm13
0000740ecffdadd8  vmovaps [rsp+0xE0], xmm15
0000740ecffdade1  sub rsp, 0x30
0000740ecffdade5  movaps [rsp], xmm14
0000740ecffdadea  movaps [rsp+0x10], xmm9
0000740ecffdadf0  movaps [rsp+0x20], xmm1
0000740ecffdadf5  lea rdi, [rsp]
0000740ecffdadf9  mov esi, 0x00
0000740ecffdadfe  mov rax, 0x5E8249CF1530
0000740ecffdae08  call rax
0000740ecffdae0a  movaps xmm14, [rsp]
0000740ecffdae0f  add rsp, 0x30
0000740ecffdae13  vmovaps xmm0, [rsp]
0000740ecffdae18  vmovaps xmm1, [rsp+0x10]
0000740ecffdae1e  vmovaps xmm2, [rsp+0x20]
0000740ecffdae24  vmovaps xmm3, [rsp+0x30]
0000740ecffdae2a  vmovaps xmm4, [rsp+0x40]
0000740ecffdae30  vmovaps xmm5, [rsp+0x50]
0000740ecffdae36  vmovaps xmm6, [rsp+0x60]
0000740ecffdae3c  vmovaps xmm7, [rsp+0x70]
0000740ecffdae42  vmovaps xmm8, [rsp+0x80]
0000740ecffdae4b  vmovaps xmm9, [rsp+0x90]
0000740ecffdae54  vmovaps xmm10, [rsp+0xA0]
0000740ecffdae5d  vmovaps xmm11, [rsp+0xB0]
0000740ecffdae66  vmovaps xmm12, [rsp+0xC0]
0000740ecffdae6f  vmovaps xmm13, [rsp+0xD0]
0000740ecffdae78  vmovaps xmm15, [rsp+0xE0]
0000740ecffdae81  add rsp, 0xF0
0000740ecffdae88  pop r11
0000740ecffdae8a  pop r10
0000740ecffdae8c  pop r9
0000740ecffdae8e  pop r8
0000740ecffdae90  pop rsi
0000740ecffdae91  pop rdi
0000740ecffdae92  pop rdx
0000740ecffdae93  pop rcx
0000740ecffdae94  pop rax
0000740ecffdae95  add rsp, 0x08
0000740ecffdae99  jmp 0x0000740ECFFD6578
0000740ecffdae9e  sub rsp, 0x08
0000740ecffdaea2  push rax
0000740ecffdaea3  push rcx
0000740ecffdaea4  push rdx
0000740ecffdaea5  push rdi
0000740ecffdaea6  push rsi
0000740ecffdaea7  push r8
0000740ecffdaea9  push r9
0000740ecffdaeab  push r10
0000740ecffdaead  push r11
0000740ecffdaeaf  sub rsp, 0xF0
0000740ecffdaeb6  vmovaps [rsp], xmm0
0000740ecffdaebb  vmovaps [rsp+0x10], xmm2
0000740ecffdaec1  vmovaps [rsp+0x20], xmm3
0000740ecffdaec7  vmovaps [rsp+0x30], xmm4
0000740ecffdaecd  vmovaps [rsp+0x40], xmm5
0000740ecffdaed3  vmovaps [rsp+0x50], xmm6
0000740ecffdaed9  vmovaps [rsp+0x60], xmm7
0000740ecffdaedf  vmovaps [rsp+0x70], xmm8
0000740ecffdaee5  vmovaps [rsp+0x80], xmm9
0000740ecffdaeee  vmovaps [rsp+0x90], xmm10
0000740ecffdaef7  vmovaps [rsp+0xA0], xmm11
0000740ecffdaf00  vmovaps [rsp+0xB0], xmm12
0000740ecffdaf09  vmovaps [rsp+0xC0], xmm13
0000740ecffdaf12  vmovaps [rsp+0xD0], xmm14
0000740ecffdaf1b  vmovaps [rsp+0xE0], xmm15
0000740ecffdaf24  sub rsp, 0x30
0000740ecffdaf28  movaps [rsp], xmm1
0000740ecffdaf2c  movaps [rsp+0x10], xmm13
0000740ecffdaf32  movaps [rsp+0x20], xmm8
0000740ecffdaf38  lea rdi, [rsp]
0000740ecffdaf3c  mov esi, 0x00
0000740ecffdaf41  mov rax, 0x5E8249CF1530
0000740ecffdaf4b  call rax
0000740ecffdaf4d  movaps xmm1, [rsp]
0000740ecffdaf51  add rsp, 0x30
0000740ecffdaf55  vmovaps xmm0, [rsp]
0000740ecffdaf5a  vmovaps xmm2, [rsp+0x10]
0000740ecffdaf60  vmovaps xmm3, [rsp+0x20]
0000740ecffdaf66  vmovaps xmm4, [rsp+0x30]
0000740ecffdaf6c  vmovaps xmm5, [rsp+0x40]
0000740ecffdaf72  vmovaps xmm6, [rsp+0x50]
0000740ecffdaf78  vmovaps xmm7, [rsp+0x60]
0000740ecffdaf7e  vmovaps xmm8, [rsp+0x70]
0000740ecffdaf84  vmovaps xmm9, [rsp+0x80]
0000740ecffdaf8d  vmovaps xmm10, [rsp+0x90]
0000740ecffdaf96  vmovaps xmm11, [rsp+0xA0]
0000740ecffdaf9f  vmovaps xmm12, [rsp+0xB0]
0000740ecffdafa8  vmovaps xmm13, [rsp+0xC0]
0000740ecffdafb1  vmovaps xmm14, [rsp+0xD0]
0000740ecffdafba  vmovaps xmm15, [rsp+0xE0]
0000740ecffdafc3  add rsp, 0xF0
0000740ecffdafca  pop r11
0000740ecffdafcc  pop r10
0000740ecffdafce  pop r9
0000740ecffdafd0  pop r8
0000740ecffdafd2  pop rsi
0000740ecffdafd3  pop rdi
0000740ecffdafd4  pop rdx
0000740ecffdafd5  pop rcx
0000740ecffdafd6  pop rax
0000740ecffdafd7  add rsp, 0x08
0000740ecffdafdb  jmp 0x0000740ECFFD659A
0000740ecffdafe0  call 0x0000740ECFE0C260
0000740ecffdafe5  jmp 0x0000740ECFFD65A8
0000740ecffdafea  call 0x0000740ECFEDE950
0000740ecffdafef  jmp 0x0000740ECFFD65B2
0000740ecffdaff4  sub rsp, 0x08
0000740ecffdaff8  push rax
0000740ecffdaff9  push rcx
0000740ecffdaffa  push rdx
0000740ecffdaffb  push rdi
0000740ecffdaffc  push rsi
0000740ecffdaffd  push r8
0000740ecffdafff  push r9
0000740ecffdb001  push r10
0000740ecffdb003  push r11
0000740ecffdb005  sub rsp, 0xF0
0000740ecffdb00c  vmovaps [rsp], xmm0
0000740ecffdb011  vmovaps [rsp+0x10], xmm1
0000740ecffdb017  vmovaps [rsp+0x20], xmm2
0000740ecffdb01d  vmovaps [rsp+0x30], xmm3
0000740ecffdb023  vmovaps [rsp+0x40], xmm4
0000740ecffdb029  vmovaps [rsp+0x50], xmm5
0000740ecffdb02f  vmovaps [rsp+0x60], xmm6
0000740ecffdb035  vmovaps [rsp+0x70], xmm7
0000740ecffdb03b  vmovaps [rsp+0x80], xmm9
0000740ecffdb044  vmovaps [rsp+0x90], xmm10
0000740ecffdb04d  vmovaps [rsp+0xA0], xmm11
0000740ecffdb056  vmovaps [rsp+0xB0], xmm12
0000740ecffdb05f  vmovaps [rsp+0xC0], xmm13
0000740ecffdb068  vmovaps [rsp+0xD0], xmm14
0000740ecffdb071  vmovaps [rsp+0xE0], xmm15
0000740ecffdb07a  sub rsp, 0x30
0000740ecffdb07e  movaps [rsp], xmm8
0000740ecffdb083  movaps [rsp+0x10], xmm15
0000740ecffdb089  movaps [rsp+0x20], xmm7
0000740ecffdb08e  lea rdi, [rsp]
0000740ecffdb092  mov esi, 0x00
0000740ecffdb097  mov rax, 0x5E8249CF1530
0000740ecffdb0a1  call rax
0000740ecffdb0a3  movaps xmm8, [rsp]
0000740ecffdb0a8  add rsp, 0x30
0000740ecffdb0ac  vmovaps xmm0, [rsp]
0000740ecffdb0b1  vmovaps xmm1, [rsp+0x10]
0000740ecffdb0b7  vmovaps xmm2, [rsp+0x20]
0000740ecffdb0bd  vmovaps xmm3, [rsp+0x30]
0000740ecffdb0c3  vmovaps xmm4, [rsp+0x40]
0000740ecffdb0c9  vmovaps xmm5, [rsp+0x50]
0000740ecffdb0cf  vmovaps xmm6, [rsp+0x60]
0000740ecffdb0d5  vmovaps xmm7, [rsp+0x70]
0000740ecffdb0db  vmovaps xmm9, [rsp+0x80]
0000740ecffdb0e4  vmovaps xmm10, [rsp+0x90]
0000740ecffdb0ed  vmovaps xmm11, [rsp+0xA0]
0000740ecffdb0f6  vmovaps xmm12, [rsp+0xB0]
0000740ecffdb0ff  vmovaps xmm13, [rsp+0xC0]
0000740ecffdb108  vmovaps xmm14, [rsp+0xD0]
0000740ecffdb111  vmovaps xmm15, [rsp+0xE0]
0000740ecffdb11a  add rsp, 0xF0
0000740ecffdb121  pop r11
0000740ecffdb123  pop r10
0000740ecffdb125  pop r9
0000740ecffdb127  pop r8
0000740ecffdb129  pop rsi
0000740ecffdb12a  pop rdi
0000740ecffdb12b  pop rdx
0000740ecffdb12c  pop rcx
0000740ecffdb12d  pop rax
0000740ecffdb12e  add rsp, 0x08
0000740ecffdb132  jmp 0x0000740ECFFD65D4
0000740ecffdb137  sub rsp, 0x08
0000740ecffdb13b  push rax
0000740ecffdb13c  push rcx
0000740ecffdb13d  push rdx
0000740ecffdb13e  push rdi
0000740ecffdb13f  push rsi
0000740ecffdb140  push r8
0000740ecffdb142  push r9
0000740ecffdb144  push r10
0000740ecffdb146  push r11
0000740ecffdb148  sub rsp, 0xF0
0000740ecffdb14f  vmovaps [rsp], xmm0
0000740ecffdb154  vmovaps [rsp+0x10], xmm1
0000740ecffdb15a  vmovaps [rsp+0x20], xmm2
0000740ecffdb160  vmovaps [rsp+0x30], xmm3
0000740ecffdb166  vmovaps [rsp+0x40], xmm4
0000740ecffdb16c  vmovaps [rsp+0x50], xmm5
0000740ecffdb172  vmovaps [rsp+0x60], xmm6
0000740ecffdb178  vmovaps [rsp+0x70], xmm8
0000740ecffdb17e  vmovaps [rsp+0x80], xmm9
0000740ecffdb187  vmovaps [rsp+0x90], xmm10
0000740ecffdb190  vmovaps [rsp+0xA0], xmm11
0000740ecffdb199  vmovaps [rsp+0xB0], xmm12
0000740ecffdb1a2  vmovaps [rsp+0xC0], xmm13
0000740ecffdb1ab  vmovaps [rsp+0xD0], xmm14
0000740ecffdb1b4  vmovaps [rsp+0xE0], xmm15
0000740ecffdb1bd  sub rsp, 0x30
0000740ecffdb1c1  movaps [rsp], xmm7
0000740ecffdb1c5  movaps [rsp+0x10], xmm9
0000740ecffdb1cb  movaps [rsp+0x20], xmm15
0000740ecffdb1d1  lea rdi, [rsp]
0000740ecffdb1d5  mov esi, 0x00
0000740ecffdb1da  mov rax, 0x5E8249CF1530
0000740ecffdb1e4  call rax
0000740ecffdb1e6  movaps xmm7, [rsp]
0000740ecffdb1ea  add rsp, 0x30
0000740ecffdb1ee  vmovaps xmm0, [rsp]
0000740ecffdb1f3  vmovaps xmm1, [rsp+0x10]
0000740ecffdb1f9  vmovaps xmm2, [rsp+0x20]
0000740ecffdb1ff  vmovaps xmm3, [rsp+0x30]
0000740ecffdb205  vmovaps xmm4, [rsp+0x40]
0000740ecffdb20b  vmovaps xmm5, [rsp+0x50]
0000740ecffdb211  vmovaps xmm6, [rsp+0x60]
0000740ecffdb217  vmovaps xmm8, [rsp+0x70]
0000740ecffdb21d  vmovaps xmm9, [rsp+0x80]
0000740ecffdb226  vmovaps xmm10, [rsp+0x90]
0000740ecffdb22f  vmovaps xmm11, [rsp+0xA0]
0000740ecffdb238  vmovaps xmm12, [rsp+0xB0]
0000740ecffdb241  vmovaps xmm13, [rsp+0xC0]
0000740ecffdb24a  vmovaps xmm14, [rsp+0xD0]
0000740ecffdb253  vmovaps xmm15, [rsp+0xE0]
0000740ecffdb25c  add rsp, 0xF0
0000740ecffdb263  pop r11
0000740ecffdb265  pop r10
0000740ecffdb267  pop r9
0000740ecffdb269  pop r8
0000740ecffdb26b  pop rsi
0000740ecffdb26c  pop rdi
0000740ecffdb26d  pop rdx
0000740ecffdb26e  pop rcx
0000740ecffdb26f  pop rax
0000740ecffdb270  add rsp, 0x08
0000740ecffdb274  jmp 0x0000740ECFFD6601
0000740ecffdb279  sub rsp, 0x08
0000740ecffdb27d  push rax
0000740ecffdb27e  push rcx
0000740ecffdb27f  push rdx
0000740ecffdb280  push rdi
0000740ecffdb281  push rsi
0000740ecffdb282  push r8
0000740ecffdb284  push r9
0000740ecffdb286  push r10
0000740ecffdb288  push r11
0000740ecffdb28a  sub rsp, 0xF0
0000740ecffdb291  vmovaps [rsp], xmm0
0000740ecffdb296  vmovaps [rsp+0x10], xmm1
0000740ecffdb29c  vmovaps [rsp+0x20], xmm2
0000740ecffdb2a2  vmovaps [rsp+0x30], xmm3
0000740ecffdb2a8  vmovaps [rsp+0x40], xmm4
0000740ecffdb2ae  vmovaps [rsp+0x50], xmm5
0000740ecffdb2b4  vmovaps [rsp+0x60], xmm6
0000740ecffdb2ba  vmovaps [rsp+0x70], xmm7
0000740ecffdb2c0  vmovaps [rsp+0x80], xmm8
0000740ecffdb2c9  vmovaps [rsp+0x90], xmm10
0000740ecffdb2d2  vmovaps [rsp+0xA0], xmm11
0000740ecffdb2db  vmovaps [rsp+0xB0], xmm12
0000740ecffdb2e4  vmovaps [rsp+0xC0], xmm13
0000740ecffdb2ed  vmovaps [rsp+0xD0], xmm14
0000740ecffdb2f6  vmovaps [rsp+0xE0], xmm15
0000740ecffdb2ff  sub rsp, 0x30
0000740ecffdb303  movaps [rsp], xmm9
0000740ecffdb308  movaps [rsp+0x10], xmm13
0000740ecffdb30e  movaps [rsp+0x20], xmm15
0000740ecffdb314  lea rdi, [rsp]
0000740ecffdb318  mov esi, 0x00
0000740ecffdb31d  mov rax, 0x5E8249CF1530
0000740ecffdb327  call rax
0000740ecffdb329  movaps xmm9, [rsp]
0000740ecffdb32e  add rsp, 0x30
0000740ecffdb332  vmovaps xmm0, [rsp]
0000740ecffdb337  vmovaps xmm1, [rsp+0x10]
0000740ecffdb33d  vmovaps xmm2, [rsp+0x20]
0000740ecffdb343  vmovaps xmm3, [rsp+0x30]
0000740ecffdb349  vmovaps xmm4, [rsp+0x40]
0000740ecffdb34f  vmovaps xmm5, [rsp+0x50]
0000740ecffdb355  vmovaps xmm6, [rsp+0x60]
0000740ecffdb35b  vmovaps xmm7, [rsp+0x70]
0000740ecffdb361  vmovaps xmm8, [rsp+0x80]
0000740ecffdb36a  vmovaps xmm10, [rsp+0x90]
0000740ecffdb373  vmovaps xmm11, [rsp+0xA0]
0000740ecffdb37c  vmovaps xmm12, [rsp+0xB0]
0000740ecffdb385  vmovaps xmm13, [rsp+0xC0]
0000740ecffdb38e  vmovaps xmm14, [rsp+0xD0]
0000740ecffdb397  vmovaps xmm15, [rsp+0xE0]
0000740ecffdb3a0  add rsp, 0xF0
0000740ecffdb3a7  pop r11
0000740ecffdb3a9  pop r10
0000740ecffdb3ab  pop r9
0000740ecffdb3ad  pop r8
0000740ecffdb3af  pop rsi
0000740ecffdb3b0  pop rdi
0000740ecffdb3b1  pop rdx
0000740ecffdb3b2  pop rcx
0000740ecffdb3b3  pop rax
0000740ecffdb3b4  add rsp, 0x08
0000740ecffdb3b8  jmp 0x0000740ECFFD662F
0000740ecffdb3bd  sub rsp, 0x08
0000740ecffdb3c1  push rax
0000740ecffdb3c2  push rcx
0000740ecffdb3c3  push rdx
0000740ecffdb3c4  push rdi
0000740ecffdb3c5  push rsi
0000740ecffdb3c6  push r8
0000740ecffdb3c8  push r9
0000740ecffdb3ca  push r10
0000740ecffdb3cc  push r11
0000740ecffdb3ce  sub rsp, 0xF0
0000740ecffdb3d5  vmovaps [rsp], xmm0
0000740ecffdb3da  vmovaps [rsp+0x10], xmm1
0000740ecffdb3e0  vmovaps [rsp+0x20], xmm2
0000740ecffdb3e6  vmovaps [rsp+0x30], xmm3
0000740ecffdb3ec  vmovaps [rsp+0x40], xmm4
0000740ecffdb3f2  vmovaps [rsp+0x50], xmm5
0000740ecffdb3f8  vmovaps [rsp+0x60], xmm6
0000740ecffdb3fe  vmovaps [rsp+0x70], xmm7
0000740ecffdb404  vmovaps [rsp+0x80], xmm8
0000740ecffdb40d  vmovaps [rsp+0x90], xmm9
0000740ecffdb416  vmovaps [rsp+0xA0], xmm10
0000740ecffdb41f  vmovaps [rsp+0xB0], xmm11
0000740ecffdb428  vmovaps [rsp+0xC0], xmm12
0000740ecffdb431  vmovaps [rsp+0xD0], xmm13
0000740ecffdb43a  vmovaps [rsp+0xE0], xmm14
0000740ecffdb443  sub rsp, 0x30
0000740ecffdb447  movaps [rsp], xmm15
0000740ecffdb44c  movaps [rsp+0x10], xmm11
0000740ecffdb452  movaps [rsp+0x20], xmm12
0000740ecffdb458  lea rdi, [rsp]
0000740ecffdb45c  mov esi, 0x00
0000740ecffdb461  mov rax, 0x5E8249CF1530
0000740ecffdb46b  call rax
0000740ecffdb46d  movaps xmm15, [rsp]
0000740ecffdb472  add rsp, 0x30
0000740ecffdb476  vmovaps xmm0, [rsp]
0000740ecffdb47b  vmovaps xmm1, [rsp+0x10]
0000740ecffdb481  vmovaps xmm2, [rsp+0x20]
0000740ecffdb487  vmovaps xmm3, [rsp+0x30]
0000740ecffdb48d  vmovaps xmm4, [rsp+0x40]
0000740ecffdb493  vmovaps xmm5, [rsp+0x50]
0000740ecffdb499  vmovaps xmm6, [rsp+0x60]
0000740ecffdb49f  vmovaps xmm7, [rsp+0x70]
0000740ecffdb4a5  vmovaps xmm8, [rsp+0x80]
0000740ecffdb4ae  vmovaps xmm9, [rsp+0x90]
0000740ecffdb4b7  vmovaps xmm10, [rsp+0xA0]
0000740ecffdb4c0  vmovaps xmm11, [rsp+0xB0]
0000740ecffdb4c9  vmovaps xmm12, [rsp+0xC0]
0000740ecffdb4d2  vmovaps xmm13, [rsp+0xD0]
0000740ecffdb4db  vmovaps xmm14, [rsp+0xE0]
0000740ecffdb4e4  add rsp, 0xF0
0000740ecffdb4eb  pop r11
0000740ecffdb4ed  pop r10
0000740ecffdb4ef  pop r9
0000740ecffdb4f1  pop r8
0000740ecffdb4f3  pop rsi
0000740ecffdb4f4  pop rdi
0000740ecffdb4f5  pop rdx
0000740ecffdb4f6  pop rcx
0000740ecffdb4f7  pop rax
0000740ecffdb4f8  add rsp, 0x08
0000740ecffdb4fc  jmp 0x0000740ECFFD664A
0000740ecffdb501  sub rsp, 0x08
0000740ecffdb505  push rax
0000740ecffdb506  push rcx
0000740ecffdb507  push rdx
0000740ecffdb508  push rdi
0000740ecffdb509  push rsi
0000740ecffdb50a  push r8
0000740ecffdb50c  push r9
0000740ecffdb50e  push r10
0000740ecffdb510  push r11
0000740ecffdb512  sub rsp, 0xF0
0000740ecffdb519  vmovaps [rsp], xmm0
0000740ecffdb51e  vmovaps [rsp+0x10], xmm1
0000740ecffdb524  vmovaps [rsp+0x20], xmm2
0000740ecffdb52a  vmovaps [rsp+0x30], xmm3
0000740ecffdb530  vmovaps [rsp+0x40], xmm4
0000740ecffdb536  vmovaps [rsp+0x50], xmm5
0000740ecffdb53c  vmovaps [rsp+0x60], xmm6
0000740ecffdb542  vmovaps [rsp+0x70], xmm7
0000740ecffdb548  vmovaps [rsp+0x80], xmm8
0000740ecffdb551  vmovaps [rsp+0x90], xmm9
0000740ecffdb55a  vmovaps [rsp+0xA0], xmm10
0000740ecffdb563  vmovaps [rsp+0xB0], xmm11
0000740ecffdb56c  vmovaps [rsp+0xC0], xmm12
0000740ecffdb575  vmovaps [rsp+0xD0], xmm14
0000740ecffdb57e  vmovaps [rsp+0xE0], xmm15
0000740ecffdb587  sub rsp, 0x30
0000740ecffdb58b  movaps [rsp], xmm13
0000740ecffdb590  movaps [rsp+0x10], xmm10
0000740ecffdb596  movaps [rsp+0x20], xmm14
0000740ecffdb59c  lea rdi, [rsp]
0000740ecffdb5a0  mov esi, 0x00
0000740ecffdb5a5  mov rax, 0x5E8249CF1530
0000740ecffdb5af  call rax
0000740ecffdb5b1  movaps xmm13, [rsp]
0000740ecffdb5b6  add rsp, 0x30
0000740ecffdb5ba  vmovaps xmm0, [rsp]
0000740ecffdb5bf  vmovaps xmm1, [rsp+0x10]
0000740ecffdb5c5  vmovaps xmm2, [rsp+0x20]
0000740ecffdb5cb  vmovaps xmm3, [rsp+0x30]
0000740ecffdb5d1  vmovaps xmm4, [rsp+0x40]
0000740ecffdb5d7  vmovaps xmm5, [rsp+0x50]
0000740ecffdb5dd  vmovaps xmm6, [rsp+0x60]
0000740ecffdb5e3  vmovaps xmm7, [rsp+0x70]
0000740ecffdb5e9  vmovaps xmm8, [rsp+0x80]
0000740ecffdb5f2  vmovaps xmm9, [rsp+0x90]
0000740ecffdb5fb  vmovaps xmm10, [rsp+0xA0]
0000740ecffdb604  vmovaps xmm11, [rsp+0xB0]
0000740ecffdb60d  vmovaps xmm12, [rsp+0xC0]
0000740ecffdb616  vmovaps xmm14, [rsp+0xD0]
0000740ecffdb61f  vmovaps xmm15, [rsp+0xE0]
0000740ecffdb628  add rsp, 0xF0
0000740ecffdb62f  pop r11
0000740ecffdb631  pop r10
0000740ecffdb633  pop r9
0000740ecffdb635  pop r8
0000740ecffdb637  pop rsi
0000740ecffdb638  pop rdi
0000740ecffdb639  pop rdx
0000740ecffdb63a  pop rcx
0000740ecffdb63b  pop rax
0000740ecffdb63c  add rsp, 0x08
0000740ecffdb640  jmp 0x0000740ECFFD666D
0000740ecffdb645  sub rsp, 0x08
0000740ecffdb649  push rax
0000740ecffdb64a  push rcx
0000740ecffdb64b  push rdx
0000740ecffdb64c  push rdi
0000740ecffdb64d  push rsi
0000740ecffdb64e  push r8
0000740ecffdb650  push r9
0000740ecffdb652  push r10
0000740ecffdb654  push r11
0000740ecffdb656  sub rsp, 0xF0
0000740ecffdb65d  vmovaps [rsp], xmm0
0000740ecffdb662  vmovaps [rsp+0x10], xmm1
0000740ecffdb668  vmovaps [rsp+0x20], xmm2
0000740ecffdb66e  vmovaps [rsp+0x30], xmm3
0000740ecffdb674  vmovaps [rsp+0x40], xmm4
0000740ecffdb67a  vmovaps [rsp+0x50], xmm5
0000740ecffdb680  vmovaps [rsp+0x60], xmm6
0000740ecffdb686  vmovaps [rsp+0x70], xmm7
0000740ecffdb68c  vmovaps [rsp+0x80], xmm8
0000740ecffdb695  vmovaps [rsp+0x90], xmm9
0000740ecffdb69e  vmovaps [rsp+0xA0], xmm10
0000740ecffdb6a7  vmovaps [rsp+0xB0], xmm11
0000740ecffdb6b0  vmovaps [rsp+0xC0], xmm12
0000740ecffdb6b9  vmovaps [rsp+0xD0], xmm13
0000740ecffdb6c2  vmovaps [rsp+0xE0], xmm15
0000740ecffdb6cb  sub rsp, 0x30
0000740ecffdb6cf  movaps [rsp], xmm14
0000740ecffdb6d4  movaps [rsp+0x10], xmm1
0000740ecffdb6d9  movaps [rsp+0x20], xmm7
0000740ecffdb6de  lea rdi, [rsp]
0000740ecffdb6e2  mov esi, 0x00
0000740ecffdb6e7  mov rax, 0x5E8249CF1530
0000740ecffdb6f1  call rax
0000740ecffdb6f3  movaps xmm14, [rsp]
0000740ecffdb6f8  add rsp, 0x30
0000740ecffdb6fc  vmovaps xmm0, [rsp]
0000740ecffdb701  vmovaps xmm1, [rsp+0x10]
0000740ecffdb707  vmovaps xmm2, [rsp+0x20]
0000740ecffdb70d  vmovaps xmm3, [rsp+0x30]
0000740ecffdb713  vmovaps xmm4, [rsp+0x40]
0000740ecffdb719  vmovaps xmm5, [rsp+0x50]
0000740ecffdb71f  vmovaps xmm6, [rsp+0x60]
0000740ecffdb725  vmovaps xmm7, [rsp+0x70]
0000740ecffdb72b  vmovaps xmm8, [rsp+0x80]
0000740ecffdb734  vmovaps xmm9, [rsp+0x90]
0000740ecffdb73d  vmovaps xmm10, [rsp+0xA0]
0000740ecffdb746  vmovaps xmm11, [rsp+0xB0]
0000740ecffdb74f  vmovaps xmm12, [rsp+0xC0]
0000740ecffdb758  vmovaps xmm13, [rsp+0xD0]
0000740ecffdb761  vmovaps xmm15, [rsp+0xE0]
0000740ecffdb76a  add rsp, 0xF0
0000740ecffdb771  pop r11
0000740ecffdb773  pop r10
0000740ecffdb775  pop r9
0000740ecffdb777  pop r8
0000740ecffdb779  pop rsi
0000740ecffdb77a  pop rdi
0000740ecffdb77b  pop rdx
0000740ecffdb77c  pop rcx
0000740ecffdb77d  pop rax
0000740ecffdb77e  add rsp, 0x08
0000740ecffdb782  jmp 0x0000740ECFFD6690
0000740ecffdb787  sub rsp, 0x08
0000740ecffdb78b  push rax
0000740ecffdb78c  push rcx
0000740ecffdb78d  push rdx
0000740ecffdb78e  push rdi
0000740ecffdb78f  push rsi
0000740ecffdb790  push r8
0000740ecffdb792  push r9
0000740ecffdb794  push r10
0000740ecffdb796  push r11
0000740ecffdb798  sub rsp, 0xF0
0000740ecffdb79f  vmovaps [rsp], xmm0
0000740ecffdb7a4  vmovaps [rsp+0x10], xmm2
0000740ecffdb7aa  vmovaps [rsp+0x20], xmm3
0000740ecffdb7b0  vmovaps [rsp+0x30], xmm4
0000740ecffdb7b6  vmovaps [rsp+0x40], xmm5
0000740ecffdb7bc  vmovaps [rsp+0x50], xmm6
0000740ecffdb7c2  vmovaps [rsp+0x60], xmm7
0000740ecffdb7c8  vmovaps [rsp+0x70], xmm8
0000740ecffdb7ce  vmovaps [rsp+0x80], xmm9
0000740ecffdb7d7  vmovaps [rsp+0x90], xmm10
0000740ecffdb7e0  vmovaps [rsp+0xA0], xmm11
0000740ecffdb7e9  vmovaps [rsp+0xB0], xmm12
0000740ecffdb7f2  vmovaps [rsp+0xC0], xmm13
0000740ecffdb7fb  vmovaps [rsp+0xD0], xmm14
0000740ecffdb804  vmovaps [rsp+0xE0], xmm15
0000740ecffdb80d  sub rsp, 0x30
0000740ecffdb811  movaps [rsp], xmm1
0000740ecffdb815  movaps [rsp+0x10], xmm8
0000740ecffdb81b  movaps [rsp+0x20], xmm9
0000740ecffdb821  lea rdi, [rsp]
0000740ecffdb825  mov esi, 0x00
0000740ecffdb82a  mov rax, 0x5E8249CF1530
0000740ecffdb834  call rax
0000740ecffdb836  movaps xmm1, [rsp]
0000740ecffdb83a  add rsp, 0x30
0000740ecffdb83e  vmovaps xmm0, [rsp]
0000740ecffdb843  vmovaps xmm2, [rsp+0x10]
0000740ecffdb849  vmovaps xmm3, [rsp+0x20]
0000740ecffdb84f  vmovaps xmm4, [rsp+0x30]
0000740ecffdb855  vmovaps xmm5, [rsp+0x40]
0000740ecffdb85b  vmovaps xmm6, [rsp+0x50]
0000740ecffdb861  vmovaps xmm7, [rsp+0x60]
0000740ecffdb867  vmovaps xmm8, [rsp+0x70]
0000740ecffdb86d  vmovaps xmm9, [rsp+0x80]
0000740ecffdb876  vmovaps xmm10, [rsp+0x90]
0000740ecffdb87f  vmovaps xmm11, [rsp+0xA0]
0000740ecffdb888  vmovaps xmm12, [rsp+0xB0]
0000740ecffdb891  vmovaps xmm13, [rsp+0xC0]
0000740ecffdb89a  vmovaps xmm14, [rsp+0xD0]
0000740ecffdb8a3  vmovaps xmm15, [rsp+0xE0]
0000740ecffdb8ac  add rsp, 0xF0
0000740ecffdb8b3  pop r11
0000740ecffdb8b5  pop r10
0000740ecffdb8b7  pop r9
0000740ecffdb8b9  pop r8
0000740ecffdb8bb  pop rsi
0000740ecffdb8bc  pop rdi
0000740ecffdb8bd  pop rdx
0000740ecffdb8be  pop rcx
0000740ecffdb8bf  pop rax
0000740ecffdb8c0  add rsp, 0x08
0000740ecffdb8c4  jmp 0x0000740ECFFD66B2
0000740ecffdb8c9  call 0x0000740ECFEB3E40
0000740ecffdb8ce  jmp 0x0000740ECFFD66C0
0000740ecffdb8d3  call 0x0000740ECFE0C380
0000740ecffdb8d8  jmp 0x0000740ECFFD66CA
0000740ecffdb8dd  call 0x0000740ECFE0D600
0000740ecffdb8e2  jmp 0x0000740ECFFD66D4
0000740ecffdb8e7  call 0x0000740ECFDFF540
0000740ecffdb8ec  jmp 0x0000740ECFFD66DE
0000740ecffdb8f1  int3
0000740ecffdb8f2  nop [rax+rax*1], ax
0000740ecffdb8fb  nop [rax+rax*1], eax
0000740ecffdb900  mov eax, [r15+0x48]
0000740ecffdb904  lea r14d, [eax+0x01]
0000740ecffdb909  mov [rsp+0x10], r14d
0000740ecffdb90e  mov r14d, r14d
0000740ecffdb911  mov [r15+0x48], r14
0000740ecffdb915  xor eax, eax
0000740ecffdb917  mov r14d, [rsp+0x10]
0000740ecffdb91c  cmp r14d, 0x1F4
0000740ecffdb923  cmc
0000740ecffdb924  lahf
0000740ecffdb925  seto al
0000740ecffdb928  mov [r15+0x108], eax
0000740ecffdb92f  mov eax, [r15+0x108]
0000740ecffdb936  sahf
0000740ecffdb937  jnz 0x0000740ECFFDB969
0000740ecffdb939  cmp dword ptr [r15+0x318], 0x00
0000740ecffdb941  jz 0x0000740ECFFE1AB0
0000740ecffdb947  nop [rax+rax*1], ax
0000740ecffdb950  nop [rax+rax*1], eax
0000740ecffdb958  mov eax, 0x410450
0000740ecffdb95d  mov [r15+0x100], rax
0000740ecffdb964  jmp 0x0000740ECFDFE110
0000740ecffdb969  cmp dword ptr [r15+0x318], 0x00
0000740ecffdb971  jz 0x0000740ECFFDB9A0
0000740ecffdb977  nop [rax+rax*1], ax
0000740ecffdb980  nop [rax+rax*1], eax
0000740ecffdb988  mov eax, 0x410274
0000740ecffdb98d  mov [r15+0x100], rax
0000740ecffdb994  jmp 0x0000740ECFDFE110
0000740ecffdb999  int3
0000740ecffdb99a  int3
0000740ecffdb99b  nop [rax+rax*1], eax
0000740ecffdb9a0  mov rax, [r15+0x40]
0000740ecffdb9a4  movaps xmm1, [r15+0x1D0]
0000740ecffdb9ac  vmovaps [rsp+0x10], xmm1
0000740ecffdb9b2  vmovaps xmm15, [rsp+0x10]
0000740ecffdb9b8  por xmm1, xmm15
0000740ecffdb9bd  movaps xmm14, [r15+0x1A0]
0000740ecffdb9c5  vmovaps [rsp+0x10], xmm14
0000740ecffdb9cb  vmovaps xmm13, [rsp+0x10]
0000740ecffdb9d1  por xmm14, xmm13
0000740ecffdb9d6  lea r14, [rax+0x30]
0000740ecffdb9da  mov r12, [r13+r14*1]
0000740ecffdb9df  lea r14, [rax+0x38]
0000740ecffdb9e3  mov r11, [r13+r14*1]
0000740ecffdb9e8  movq xmm13, r12
0000740ecffdb9ed  movq xmm12, r11
0000740ecffdb9f2  movq xmm13, xmm13
0000740ecffdb9f7  vmovaps [rsp+0x10], xmm13
0000740ecffdb9fd  movq xmm13, xmm13
0000740ecffdba02  movaps [r15+0x130], xmm13
0000740ecffdba0a  movq xmm12, xmm12
0000740ecffdba0f  vmovaps [rsp+0x20], xmm12
0000740ecffdba15  movq xmm12, xmm12
0000740ecffdba1a  movaps [r15+0x280], xmm12
0000740ecffdba22  movaps xmm13, [r15+0x270]
0000740ecffdba2a  vmovaps [rsp+0x30], xmm13
0000740ecffdba30  vmovaps xmm12, [rsp+0x30]
0000740ecffdba36  por xmm13, xmm12
0000740ecffdba3b  lea r14, [rax+0x20]
0000740ecffdba3f  mov r12, [r13+r14*1]
0000740ecffdba44  lea r14, [rax+0x28]
0000740ecffdba48  mov r11, [r13+r14*1]
0000740ecffdba4d  movq xmm12, r12
0000740ecffdba52  movq xmm11, r11
0000740ecffdba57  movq xmm12, xmm12
0000740ecffdba5c  vmovaps [rsp+0x30], xmm12
0000740ecffdba62  movq xmm12, xmm12
0000740ecffdba67  movaps [r15+0x150], xmm12
0000740ecffdba6f  movq xmm11, xmm11
0000740ecffdba74  vmovaps [rsp+0x40], xmm11
0000740ecffdba7a  movq xmm11, xmm11
0000740ecffdba7f  movaps [r15+0x140], xmm11
0000740ecffdba87  lea r14, [rax+0x10]
0000740ecffdba8b  mov r12, [r13+r14*1]
0000740ecffdba90  lea r14, [rax+0x18]
0000740ecffdba94  mov r11, [r13+r14*1]
0000740ecffdba99  movq xmm12, r12
0000740ecffdba9e  movq xmm11, r11
0000740ecffdbaa3  movq xmm12, xmm12
0000740ecffdbaa8  vmovaps [rsp+0x50], xmm12
0000740ecffdbaae  movq xmm12, xmm12
0000740ecffdbab3  movaps [r15+0x170], xmm12
0000740ecffdbabb  movq xmm11, xmm11
0000740ecffdbac0  vmovaps [rsp+0x60], xmm11
0000740ecffdbac6  movq xmm11, xmm11
0000740ecffdbacb  movaps [r15+0x160], xmm11
0000740ecffdbad3  mov r14, [r13+rax*1]
0000740ecffdbad8  vmovq xmm12, r14
0000740ecffdbadd  vpbroadcastq xmm12, xmm12
0000740ecffdbae2  lea r14, [rax+0x08]
0000740ecffdbae6  mov rax, [r13+r14*1]
0000740ecffdbaeb  movq xmm11, rax
0000740ecffdbaf0  movaps [r15+0x230], xmm11
0000740ecffdbaf8  mov rax, [r15+0xF8]
0000740ecffdbaff  lea r14, [rax+0x50]
0000740ecffdbb03  movups xmm11, [r13+r14*1]
0000740ecffdbb09  lea r14, [rax+0x60]
0000740ecffdbb0d  movups xmm10, [r13+r14*1]
0000740ecffdbb13  lea r14, [rax+0x30]
0000740ecffdbb17  movups xmm9, [r13+r14*1]
0000740ecffdbb1d  mov r14, [r15+0x50]
0000740ecffdbb21  mov [r15+0x60], r14
0000740ecffdbb25  mov qword ptr [r15+0x58], 0x40
0000740ecffdbb2d  movaps xmm8, xmm12
0000740ecffdbb31  mulpd xmm8, xmm15
0000740ecffdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
0000740ecffdbb3c  ptest xmm7, xmm7
0000740ecffdbb41  jnz 0x0000740ECFFDC96A
0000740ecffdbb47  movq xmm15, qword ptr [r15+0x230]
0000740ecffdbb50  vmovaps [rsp+0x70], xmm15
0000740ecffdbb56  vpermilpd xmm15, xmm15, 0x00
0000740ecffdbb5c  movaps xmm7, xmm9
0000740ecffdbb60  mulpd xmm7, xmm15
0000740ecffdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
0000740ecffdbb6a  ptest xmm6, xmm6
0000740ecffdbb6f  jnz 0x0000740ECFFDCAAE
0000740ecffdbb75  vxorps xmm15, xmm15, xmm15
0000740ecffdbb7a  vpbroadcastq xmm15, xmm15
0000740ecffdbb7f  movaps xmm9, xmm12
0000740ecffdbb83  mulpd xmm9, xmm10
0000740ecffdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
0000740ecffdbb8e  ptest xmm6, xmm6
0000740ecffdbb93  jnz 0x0000740ECFFDCBF0
0000740ecffdbb99  movaps xmm10, xmm12
0000740ecffdbb9d  mulpd xmm10, xmm11
0000740ecffdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
0000740ecffdbba8  ptest xmm6, xmm6
0000740ecffdbbad  jnz 0x0000740ECFFDCD34
0000740ecffdbbb3  movaps xmm11, [r15+0x1F0]
0000740ecffdbbbb  movaps xmm6, xmm12
0000740ecffdbbbf  mulpd xmm6, xmm11
0000740ecffdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
0000740ecffdbbc9  ptest xmm5, xmm5
0000740ecffdbbce  jnz 0x0000740ECFFDCE78
0000740ecffdbbd4  movaps xmm12, [r15+0x2A0]
0000740ecffdbbdc  vmovaps [rsp+0x80], xmm12
0000740ecffdbbe5  vmovaps xmm11, [rsp+0x80]
0000740ecffdbbee  por xmm12, xmm11
0000740ecffdbbf3  movaps xmm11, [r15+0x250]
0000740ecffdbbfb  vmovaps [rsp+0x80], xmm11
0000740ecffdbc04  vmovaps xmm5, [rsp+0x80]
0000740ecffdbc0d  por xmm11, xmm5
0000740ecffdbc12  vmovaps xmm4, [rsp+0x70]
0000740ecffdbc18  vpermilpd xmm4, xmm4, 0x00
0000740ecffdbc1e  movaps xmm3, xmm5
0000740ecffdbc21  mulpd xmm3, xmm4
0000740ecffdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
0000740ecffdbc2a  ptest xmm2, xmm2
0000740ecffdbc2f  jnz 0x0000740ECFFDCFBA
0000740ecffdbc35  mov [rsp+0x80], rax
0000740ecffdbc3d  xor eax, eax
0000740ecffdbc3f  mov r12d, 0x40
0000740ecffdbc45  mov r11d, 0x200
0000740ecffdbc4b  cmp r12, r11
0000740ecffdbc4e  cmc
0000740ecffdbc4f  lahf
0000740ecffdbc50  seto al
0000740ecffdbc53  mov [r15+0x108], eax
0000740ecffdbc5a  movaps xmm5, xmm8
0000740ecffdbc5e  addpd xmm5, xmm15
0000740ecffdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
0000740ecffdbc68  ptest xmm4, xmm4
0000740ecffdbc6d  jnz 0x0000740ECFFDD0FA
0000740ecffdbc73  movaps xmm8, [r15+0x1B0]
0000740ecffdbc7b  movaps xmm4, xmm9
0000740ecffdbc7f  addpd xmm4, xmm8
0000740ecffdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
0000740ecffdbc89  ptest xmm2, xmm2
0000740ecffdbc8e  jnz 0x0000740ECFFDD23C
0000740ecffdbc94  movaps xmm9, xmm10
0000740ecffdbc98  addpd xmm9, xmm8
0000740ecffdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
0000740ecffdbca3  ptest xmm2, xmm2
0000740ecffdbca8  jnz 0x0000740ECFFDD37E
0000740ecffdbcae  movaps xmm10, [r15+0x2F0]
0000740ecffdbcb6  vmovaps [rsp+0x90], xmm10
0000740ecffdbcbf  vmovaps xmm8, [rsp+0x90]
0000740ecffdbcc8  por xmm10, xmm8
0000740ecffdbccd  movaps xmm8, [r15+0x2E0]
0000740ecffdbcd5  vmovaps [rsp+0x90], xmm8
0000740ecffdbcde  vmovaps xmm2, [rsp+0x90]
0000740ecffdbce7  por xmm8, xmm2
0000740ecffdbcec  movaps xmm2, [r15+0x2D0]
0000740ecffdbcf4  vmovaps [rsp+0x90], xmm2
0000740ecffdbcfd  vmovaps [rsp+0xA0], xmm1
0000740ecffdbd06  vmovaps xmm1, [rsp+0x90]
0000740ecffdbd0f  por xmm2, xmm1
0000740ecffdbd13  movaps xmm1, [r15+0x200]
0000740ecffdbd1b  vmovaps [rsp+0x90], xmm1
0000740ecffdbd24  vmovaps [rsp+0xB0], xmm15
0000740ecffdbd2d  vmovaps xmm15, [rsp+0x90]
0000740ecffdbd36  por xmm1, xmm15
0000740ecffdbd3b  movaps xmm15, [r15+0x1C0]
0000740ecffdbd43  vmovaps [rsp+0x90], xmm15
0000740ecffdbd4c  vmovaps [rsp+0xC0], xmm1
0000740ecffdbd55  vmovaps xmm1, [rsp+0x90]
0000740ecffdbd5e  por xmm15, xmm1
0000740ecffdbd63  movaps xmm1, [r15+0x190]
0000740ecffdbd6b  vmovaps [rsp+0x90], xmm1
0000740ecffdbd74  vmovaps [rsp+0xD0], xmm15
0000740ecffdbd7d  vmovaps xmm15, [rsp+0x90]
0000740ecffdbd86  por xmm1, xmm15
0000740ecffdbd8b  movaps xmm15, [r15+0x300]
0000740ecffdbd93  vmovaps [rsp+0x90], xmm15
0000740ecffdbd9c  vmovaps [rsp+0xE0], xmm1
0000740ecffdbda5  vmovaps xmm1, [rsp+0x90]
0000740ecffdbdae  por xmm15, xmm1
0000740ecffdbdb3  mov rax, [rsp+0x80]
0000740ecffdbdbb  lea r12, [rax+0xA0]
0000740ecffdbdc2  movups xmm1, [r13+r12*1]
0000740ecffdbdc8  lea r12, [rax+0xB0]
0000740ecffdbdcf  vmovaps [rsp+0x80], xmm1
0000740ecffdbdd8  movups xmm1, [r13+r12*1]
0000740ecffdbdde  vmovaps [rsp+0x90], xmm1
0000740ecffdbde7  vmovaps [rsp+0xF0], xmm15
0000740ecffdbdf0  vmovaps xmm15, [rsp+0xB0]
0000740ecffdbdf9  vmovaps [rsp+0xB0], xmm14
0000740ecffdbe02  movaps xmm1, xmm6
0000740ecffdbe05  addpd xmm1, xmm15
0000740ecffdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
0000740ecffdbe0f  ptest xmm14, xmm14
0000740ecffdbe15  jnz 0x0000740ECFFDD4D6
0000740ecffdbe1b  lea r12, [rax+0xF0]
0000740ecffdbe22  movups xmm15, [r13+r12*1]
0000740ecffdbe28  movaps xmm14, xmm4
0000740ecffdbe2c  addpd xmm14, xmm3
0000740ecffdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
0000740ecffdbe37  ptest xmm6, xmm6
0000740ecffdbe3c  jnz 0x0000740ECFFDD621
0000740ecffdbe42  movaps xmm6, xmm9
0000740ecffdbe46  addpd xmm6, xmm7
0000740ecffdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
0000740ecffdbe4f  ptest xmm4, xmm4
0000740ecffdbe54  jnz 0x0000740ECFFDD763
0000740ecffdbe5a  vmovaps xmm9, [rsp+0x70]
0000740ecffdbe60  vpermilpd xmm9, xmm9, 0x00
0000740ecffdbe66  vmovaps xmm4, [rsp+0x90]
0000740ecffdbe6f  movaps xmm7, xmm4
0000740ecffdbe72  mulpd xmm7, xmm9
0000740ecffdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
0000740ecffdbe7c  ptest xmm3, xmm3
0000740ecffdbe81  jnz 0x0000740ECFFDD8A4
0000740ecffdbe87  vmovaps xmm9, [rsp+0x50]
0000740ecffdbe8d  vpermilpd xmm9, xmm9, 0x00
0000740ecffdbe93  movaps xmm4, xmm15
0000740ecffdbe97  mulpd xmm4, xmm9
0000740ecffdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
0000740ecffdbea1  ptest xmm3, xmm3
0000740ecffdbea6  jnz 0x0000740ECFFDD9E5
0000740ecffdbeac  lea r12, [rax+0xE0]
0000740ecffdbeb3  movups xmm15, [r13+r12*1]
0000740ecffdbeb9  vmovaps xmm9, [rsp+0x70]
0000740ecffdbebf  vpermilpd xmm9, xmm9, 0x00
0000740ecffdbec5  vmovaps [rsp+0x70], xmm1
0000740ecffdbecb  vmovaps xmm1, [rsp+0x80]
0000740ecffdbed4  vmovaps [rsp+0x80], xmm15
0000740ecffdbedd  movaps xmm3, xmm1
0000740ecffdbee0  mulpd xmm3, xmm9
0000740ecffdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
0000740ecffdbeea  ptest xmm15, xmm15
0000740ecffdbef0  jnz 0x0000740ECFFDDB31
0000740ecffdbef6  vmovaps xmm1, [rsp+0xF0]
0000740ecffdbeff  vmovaps xmm15, [rsp+0xF0]
0000740ecffdbf08  por xmm1, xmm15
0000740ecffdbf0d  movaps [r15+0x300], xmm1
0000740ecffdbf15  vmovaps xmm15, [rsp+0xE0]
0000740ecffdbf1e  vmovaps xmm9, [rsp+0xE0]
0000740ecffdbf27  por xmm15, xmm9
0000740ecffdbf2c  movaps [r15+0x190], xmm15
0000740ecffdbf34  vmovaps xmm9, [rsp+0x50]
0000740ecffdbf3a  vpermilpd xmm9, xmm9, 0x00
0000740ecffdbf40  vmovaps [rsp+0x90], xmm1
0000740ecffdbf49  vmovaps [rsp+0xE0], xmm15
0000740ecffdbf52  vmovaps xmm15, [rsp+0x80]
0000740ecffdbf5b  vmovaps [rsp+0x80], xmm14
0000740ecffdbf64  movaps xmm1, xmm15
0000740ecffdbf68  mulpd xmm1, xmm9
0000740ecffdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
0000740ecffdbf72  ptest xmm14, xmm14
0000740ecffdbf78  jnz 0x0000740ECFFDDC72
0000740ecffdbf7e  lea r12, [rax+0x90]
0000740ecffdbf85  movups xmm15, [r13+r12*1]
0000740ecffdbf8b  vmovaps xmm14, [rsp+0xD0]
0000740ecffdbf94  vmovaps xmm9, [rsp+0xD0]
0000740ecffdbf9d  por xmm14, xmm9
0000740ecffdbfa2  movaps [r15+0x1C0], xmm14
0000740ecffdbfaa  vmovaps xmm9, [rsp+0xC0]
0000740ecffdbfb3  vmovaps [rsp+0xD0], xmm1
0000740ecffdbfbc  vmovaps xmm1, [rsp+0xC0]
0000740ecffdbfc5  por xmm9, xmm1
0000740ecffdbfca  movaps [r15+0x200], xmm9
0000740ecffdbfd2  vmovaps [rsp+0xC0], xmm2
0000740ecffdbfdb  vmovaps xmm1, [rsp+0xC0]
0000740ecffdbfe4  por xmm2, xmm1
0000740ecffdbfe8  movaps [r15+0x2D0], xmm2
0000740ecffdbff0  vmovaps [rsp+0xC0], xmm8
0000740ecffdbff9  vmovaps xmm1, [rsp+0xC0]
0000740ecffdc002  por xmm8, xmm1
0000740ecffdc007  movaps [r15+0x2E0], xmm8
0000740ecffdc00f  vmovaps [rsp+0xC0], xmm15
0000740ecffdc018  movaps xmm1, xmm5
0000740ecffdc01b  addpd xmm1, xmm7
0000740ecffdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
0000740ecffdc024  ptest xmm15, xmm15
0000740ecffdc02a  jnz 0x0000740ECFFDDDBE
0000740ecffdc030  vmovaps xmm15, [rsp+0x50]
0000740ecffdc036  vpermilpd xmm15, xmm15, 0x00
0000740ecffdc03c  vmovaps xmm5, [rsp+0xC0]
0000740ecffdc045  vmovaps [rsp+0xC0], xmm1
0000740ecffdc04e  movaps xmm7, xmm5
0000740ecffdc051  mulpd xmm7, xmm15
0000740ecffdc056  vcmppd xmm1, xmm7, xmm7, 0x03
0000740ecffdc05b  ptest xmm1, xmm1
0000740ecffdc060  jnz 0x0000740ECFFDDEFE
0000740ecffdc066  lea r12, [rax+0x80]
0000740ecffdc06d  movups xmm1, [r13+r12*1]
0000740ecffdc073  vmovaps xmm5, [rsp+0x70]
0000740ecffdc079  vmovaps [rsp+0x70], xmm1
0000740ecffdc07f  movaps xmm15, xmm5
0000740ecffdc083  addpd xmm15, xmm3
0000740ecffdc088  vcmppd xmm1, xmm15, xmm15, 0x03
0000740ecffdc08e  ptest xmm1, xmm1
0000740ecffdc093  jnz 0x0000740ECFFDE049
0000740ecffdc099  vmovaps xmm5, [rsp+0x80]
0000740ecffdc0a2  movaps xmm1, xmm5
0000740ecffdc0a5  addpd xmm1, xmm4
0000740ecffdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
0000740ecffdc0ae  ptest xmm3, xmm3
0000740ecffdc0b3  jnz 0x0000740ECFFDE18B
0000740ecffdc0b9  vmovaps [rsp+0x80], xmm10
0000740ecffdc0c2  vmovaps xmm5, [rsp+0x80]
0000740ecffdc0cb  por xmm10, xmm5
0000740ecffdc0d0  movaps [r15+0x2F0], xmm10
0000740ecffdc0d8  vmovaps xmm5, [rsp+0x50]
0000740ecffdc0de  vpermilpd xmm5, xmm5, 0x00
0000740ecffdc0e4  vmovaps xmm3, [rsp+0x70]
0000740ecffdc0ea  vmovaps [rsp+0x50], xmm1
0000740ecffdc0f0  movaps xmm4, xmm3
0000740ecffdc0f3  mulpd xmm4, xmm5
0000740ecffdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
0000740ecffdc0fc  ptest xmm1, xmm1
0000740ecffdc101  jnz 0x0000740ECFFDE2CB
0000740ecffdc107  lea r12, [rax+0xD0]
0000740ecffdc10e  movups xmm1, [r13+r12*1]
0000740ecffdc114  vmovaps xmm3, [rsp+0xD0]
0000740ecffdc11d  vmovaps [rsp+0x70], xmm1
0000740ecffdc123  movaps xmm5, xmm6
0000740ecffdc126  addpd xmm5, xmm3
0000740ecffdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
0000740ecffdc12f  ptest xmm1, xmm1
0000740ecffdc134  jnz 0x0000740ECFFDE415
0000740ecffdc13a  vmovaps xmm1, [rsp+0x60]
0000740ecffdc140  vpermilpd xmm1, xmm1, 0x00
0000740ecffdc146  movaps xmm6, xmm9
0000740ecffdc14a  mulpd xmm6, xmm1
0000740ecffdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
0000740ecffdc153  ptest xmm3, xmm3
0000740ecffdc158  jnz 0x0000740ECFFDE555
0000740ecffdc15e  movaps [r15+0x260], xmm6
0000740ecffdc166  vxorps xmm1, xmm1, xmm1
0000740ecffdc16a  vpbroadcastq xmm1, xmm1
0000740ecffdc16f  movaps [r15+0x1B0], xmm1
0000740ecffdc177  vmovaps xmm1, [rsp+0x60]
0000740ecffdc17d  vpermilpd xmm1, xmm1, 0x00
0000740ecffdc183  vmovaps xmm3, [rsp+0x70]
0000740ecffdc189  vmovaps [rsp+0x70], xmm15
0000740ecffdc18f  movaps xmm9, xmm3
0000740ecffdc193  mulpd xmm9, xmm1
0000740ecffdc198  vcmppd xmm15, xmm9, xmm9, 0x03
0000740ecffdc19e  ptest xmm15, xmm15
0000740ecffdc1a4  jnz 0x0000740ECFFDE696
0000740ecffdc1aa  lea r12, [rax+0xC0]
0000740ecffdc1b1  movups xmm1, [r13+r12*1]
0000740ecffdc1b7  vmovaps xmm3, [rsp+0xC0]
0000740ecffdc1c0  vmovaps [rsp+0x80], xmm1
0000740ecffdc1c9  movaps xmm15, xmm3
0000740ecffdc1cd  addpd xmm15, xmm7
0000740ecffdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
0000740ecffdc1d8  ptest xmm1, xmm1
0000740ecffdc1dd  jnz 0x0000740ECFFDE7E2
0000740ecffdc1e3  vmovaps [rsp+0xC0], xmm13
0000740ecffdc1ec  vmovaps xmm1, [rsp+0xC0]
0000740ecffdc1f5  por xmm13, xmm1
0000740ecffdc1fa  movaps [r15+0x270], xmm13
0000740ecffdc202  vmovaps xmm1, [rsp+0xB0]
0000740ecffdc20b  vmovaps xmm7, [rsp+0xB0]
0000740ecffdc214  por xmm1, xmm7
0000740ecffdc218  movaps [r15+0x1A0], xmm1
0000740ecffdc220  vmovaps xmm1, [rsp+0x60]
0000740ecffdc226  vpermilpd xmm1, xmm1, 0x00
0000740ecffdc22c  vmovaps [rsp+0xB0], xmm1
0000740ecffdc235  vmovaps xmm1, [rsp+0x80]
0000740ecffdc23e  vmovaps [rsp+0x80], xmm15
0000740ecffdc247  vmovaps xmm15, [rsp+0xB0]
0000740ecffdc250  vmovaps [rsp+0xB0], xmm14
0000740ecffdc259  movaps xmm3, xmm1
0000740ecffdc25c  mulpd xmm3, xmm15
0000740ecffdc261  vcmppd xmm14, xmm3, xmm3, 0x03
0000740ecffdc266  ptest xmm14, xmm14
0000740ecffdc26c  jnz 0x0000740ECFFDE924
0000740ecffdc272  lea r12, [rax+0x20]
0000740ecffdc276  movups xmm1, [r13+r12*1]
0000740ecffdc27c  movaps [r15+0x110], xmm1
0000740ecffdc284  vmovaps xmm14, [rsp+0x70]
0000740ecffdc28a  vmovaps [rsp+0x70], xmm1
0000740ecffdc290  movaps xmm15, xmm14
0000740ecffdc294  addpd xmm15, xmm4
0000740ecffdc299  vcmppd xmm1, xmm15, xmm15, 0x03
0000740ecffdc29f  ptest xmm1, xmm1
0000740ecffdc2a4  jnz 0x0000740ECFFDEA6F
0000740ecffdc2aa  vmovaps xmm1, [rsp+0x60]
0000740ecffdc2b0  vpermilpd xmm1, xmm1, 0x00
0000740ecffdc2b6  movaps xmm14, xmm2
0000740ecffdc2ba  mulpd xmm14, xmm1
0000740ecffdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
0000740ecffdc2c5  ptest xmm4, xmm4
0000740ecffdc2ca  jnz 0x0000740ECFFDEBB2
0000740ecffdc2d0  vmovaps xmm4, [rsp+0x50]
0000740ecffdc2d6  movaps xmm1, xmm4
0000740ecffdc2d9  addpd xmm1, xmm9
0000740ecffdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
0000740ecffdc2e3  ptest xmm2, xmm2
0000740ecffdc2e8  jnz 0x0000740ECFFDECF4
0000740ecffdc2ee  vmovaps xmm9, [rsp+0x30]
0000740ecffdc2f4  vpermilpd xmm9, xmm9, 0x00
0000740ecffdc2fa  vmovaps xmm2, [rsp+0x70]
0000740ecffdc300  vmovaps [rsp+0x50], xmm1
0000740ecffdc306  movaps xmm4, xmm2
0000740ecffdc309  mulpd xmm4, xmm9
0000740ecffdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
0000740ecffdc313  ptest xmm1, xmm1
0000740ecffdc318  jnz 0x0000740ECFFDEE35
0000740ecffdc31e  vmovaps xmm1, [rsp+0x30]
0000740ecffdc324  vpermilpd xmm1, xmm1, 0x00
0000740ecffdc32a  vmovaps xmm2, [rsp+0x90]
0000740ecffdc333  vmovaps [rsp+0x60], xmm15
0000740ecffdc339  movaps xmm9, xmm2
0000740ecffdc33d  mulpd xmm9, xmm1
0000740ecffdc342  vcmppd xmm15, xmm9, xmm9, 0x03
0000740ecffdc348  ptest xmm15, xmm15
0000740ecffdc34e  jnz 0x0000740ECFFDEF76
0000740ecffdc354  vmovaps xmm15, [rsp+0x80]
0000740ecffdc35d  movaps xmm1, xmm15
0000740ecffdc361  addpd xmm1, xmm6
0000740ecffdc365  vcmppd xmm2, xmm1, xmm1, 0x03
0000740ecffdc36a  ptest xmm2, xmm2
0000740ecffdc36f  jnz 0x0000740ECFFDF0B8
0000740ecffdc375  movaps xmm15, xmm5
0000740ecffdc379  addpd xmm15, xmm3
0000740ecffdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
0000740ecffdc384  ptest xmm6, xmm6
0000740ecffdc389  jnz 0x0000740ECFFDF1F9
0000740ecffdc38f  vmovaps xmm6, [rsp+0x30]
0000740ecffdc395  vpermilpd xmm6, xmm6, 0x00
0000740ecffdc39b  movaps xmm5, xmm8
0000740ecffdc39f  mulpd xmm5, xmm6
0000740ecffdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
0000740ecffdc3a8  ptest xmm3, xmm3
0000740ecffdc3ad  jnz 0x0000740ECFFDF33B
0000740ecffdc3b3  vmovaps xmm8, [rsp+0x30]
0000740ecffdc3b9  vpermilpd xmm8, xmm8, 0x00
0000740ecffdc3bf  movaps xmm6, xmm10
0000740ecffdc3c3  mulpd xmm6, xmm8
0000740ecffdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
0000740ecffdc3cd  ptest xmm3, xmm3
0000740ecffdc3d2  jnz 0x0000740ECFFDF47C
0000740ecffdc3d8  vmovaps xmm8, [rsp+0x60]
0000740ecffdc3de  movaps xmm10, xmm8
0000740ecffdc3e2  addpd xmm10, xmm14
0000740ecffdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
0000740ecffdc3ed  ptest xmm3, xmm3
0000740ecffdc3f2  jnz 0x0000740ECFFDF5BE
0000740ecffdc3f8  vmovaps xmm8, [rsp+0x50]
0000740ecffdc3fe  movaps xmm14, xmm8
0000740ecffdc402  addpd xmm14, xmm4
0000740ecffdc407  vcmppd xmm3, xmm14, xmm14, 0x03
0000740ecffdc40d  ptest xmm3, xmm3
0000740ecffdc412  jnz 0x0000740ECFFDF702
0000740ecffdc418  vmovaps xmm8, [rsp+0x40]
0000740ecffdc41e  vpermilpd xmm8, xmm8, 0x00
0000740ecffdc424  movaps xmm4, xmm13
0000740ecffdc428  mulpd xmm4, xmm8
0000740ecffdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
0000740ecffdc432  ptest xmm3, xmm3
0000740ecffdc437  jnz 0x0000740ECFFDF845
0000740ecffdc43d  movaps xmm13, xmm15
0000740ecffdc441  addpd xmm13, xmm9
0000740ecffdc446  vcmppd xmm8, xmm13, xmm13, 0x03
0000740ecffdc44c  ptest xmm8, xmm8
0000740ecffdc452  jnz 0x0000740ECFFDF987
0000740ecffdc458  movaps xmm15, xmm1
0000740ecffdc45c  addpd xmm15, xmm5
0000740ecffdc461  vcmppd xmm9, xmm15, xmm15, 0x03
0000740ecffdc467  ptest xmm9, xmm9
0000740ecffdc46d  jnz 0x0000740ECFFDFACB
0000740ecffdc473  vmovaps [rsp+0x30], xmm11
0000740ecffdc479  vmovaps xmm1, [rsp+0x30]
0000740ecffdc47f  por xmm11, xmm1
0000740ecffdc484  movaps [r15+0x250], xmm11
0000740ecffdc48c  vmovaps [rsp+0x30], xmm12
0000740ecffdc492  vmovaps xmm1, [rsp+0x30]
0000740ecffdc498  por xmm12, xmm1
0000740ecffdc49d  movaps [r15+0x2A0], xmm12
0000740ecffdc4a5  vmovaps xmm1, [rsp+0xA0]
0000740ecffdc4ae  vmovaps xmm11, [rsp+0xA0]
0000740ecffdc4b7  por xmm1, xmm11
0000740ecffdc4bc  movaps [r15+0x1D0], xmm1
0000740ecffdc4c4  lea r12, [rax+0x40]
0000740ecffdc4c8  movups xmm1, [r13+r12*1]
0000740ecffdc4ce  movaps [r15+0x2C0], xmm1
0000740ecffdc4d6  vmovaps xmm11, [rsp+0x40]
0000740ecffdc4dc  vpermilpd xmm11, xmm11, 0x00
0000740ecffdc4e2  vmovaps xmm8, [rsp+0xE0]
0000740ecffdc4eb  movaps xmm9, xmm8
0000740ecffdc4ef  mulpd xmm9, xmm11
0000740ecffdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
0000740ecffdc4fa  ptest xmm5, xmm5
0000740ecffdc4ff  jnz 0x0000740ECFFDFC17
0000740ecffdc505  movaps xmm11, xmm10
0000740ecffdc509  addpd xmm11, xmm6
0000740ecffdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
0000740ecffdc514  ptest xmm8, xmm8
0000740ecffdc51a  jnz 0x0000740ECFFDFD5B
0000740ecffdc520  movaps xmm10, xmm14
0000740ecffdc524  addpd xmm10, xmm4
0000740ecffdc529  vcmppd xmm8, xmm10, xmm10, 0x03
0000740ecffdc52f  ptest xmm8, xmm8
0000740ecffdc535  jnz 0x0000740ECFFDFE9E
0000740ecffdc53b  vmovaps xmm14, [rsp+0x40]
0000740ecffdc541  vpermilpd xmm14, xmm14, 0x00
0000740ecffdc547  movaps xmm8, xmm1
0000740ecffdc54b  mulpd xmm8, xmm14
0000740ecffdc550  vcmppd xmm6, xmm8, xmm8, 0x03
0000740ecffdc556  ptest xmm6, xmm6
0000740ecffdc55b  jnz 0x0000740ECFFDFFE1
0000740ecffdc561  movaps xmm1, [r15+0x2B0]
0000740ecffdc569  vmovaps xmm14, [rsp+0x40]
0000740ecffdc56f  vpermilpd xmm14, xmm14, 0x00
0000740ecffdc575  movaps xmm6, xmm1
0000740ecffdc578  mulpd xmm6, xmm14
0000740ecffdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
0000740ecffdc582  ptest xmm5, xmm5
0000740ecffdc587  jnz 0x0000740ECFFE0124
0000740ecffdc58d  vmovaps xmm1, [rsp+0x10]
0000740ecffdc593  vpermilpd xmm1, xmm1, 0x00
0000740ecffdc599  movaps xmm14, xmm12
0000740ecffdc59d  mulpd xmm14, xmm1
0000740ecffdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
0000740ecffdc5a8  ptest xmm5, xmm5
0000740ecffdc5ad  jnz 0x0000740ECFFE0265
0000740ecffdc5b3  movaps xmm1, xmm13
0000740ecffdc5b7  addpd xmm1, xmm9
0000740ecffdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
0000740ecffdc5c1  ptest xmm12, xmm12
0000740ecffdc5c7  jnz 0x0000740ECFFE03A8
0000740ecffdc5cd  vmovaps xmm13, [rsp+0x10]
0000740ecffdc5d3  vpermilpd xmm13, xmm13, 0x00
0000740ecffdc5d9  movaps xmm12, xmm7
0000740ecffdc5dd  mulpd xmm12, xmm13
0000740ecffdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
0000740ecffdc5e8  ptest xmm9, xmm9
0000740ecffdc5ee  jnz 0x0000740ECFFE04EA
0000740ecffdc5f4  movaps xmm13, xmm15
0000740ecffdc5f8  addpd xmm13, xmm8
0000740ecffdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
0000740ecffdc603  ptest xmm9, xmm9
0000740ecffdc609  jnz 0x0000740ECFFE062D
0000740ecffdc60f  movaps xmm15, [r15+0x290]
0000740ecffdc617  vmovaps xmm9, [rsp+0x10]
0000740ecffdc61d  vpermilpd xmm9, xmm9, 0x00
0000740ecffdc623  movaps xmm8, xmm15
0000740ecffdc627  mulpd xmm8, xmm9
0000740ecffdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
0000740ecffdc632  ptest xmm7, xmm7
0000740ecffdc637  jnz 0x0000740ECFFE0771
0000740ecffdc63d  movaps xmm15, xmm11
0000740ecffdc641  addpd xmm15, xmm6
0000740ecffdc646  vcmppd xmm9, xmm15, xmm15, 0x03
0000740ecffdc64c  ptest xmm9, xmm9
0000740ecffdc652  jnz 0x0000740ECFFE08B5
0000740ecffdc658  movaps xmm11, [r15+0x1E0]
0000740ecffdc660  vmovaps xmm9, [rsp+0x10]
0000740ecffdc666  vpermilpd xmm9, xmm9, 0x00
0000740ecffdc66c  movaps xmm7, xmm11
0000740ecffdc670  mulpd xmm7, xmm9
0000740ecffdc675  vcmppd xmm6, xmm7, xmm7, 0x03
0000740ecffdc67a  ptest xmm6, xmm6
0000740ecffdc67f  jnz 0x0000740ECFFE09F8
0000740ecffdc685  movaps xmm11, xmm10
0000740ecffdc689  addpd xmm11, xmm14
0000740ecffdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
0000740ecffdc694  ptest xmm9, xmm9
0000740ecffdc69a  jnz 0x0000740ECFFE0B3A
0000740ecffdc6a0  lea r12, [rax+0x70]
0000740ecffdc6a4  movups xmm14, [r13+r12*1]
0000740ecffdc6aa  movaps [r15+0x240], xmm14
0000740ecffdc6b2  movaps xmm10, xmm1
0000740ecffdc6b6  addpd xmm10, xmm12
0000740ecffdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
0000740ecffdc6c1  ptest xmm9, xmm9
0000740ecffdc6c7  jnz 0x0000740ECFFE0C88
0000740ecffdc6cd  movaps [r15+0x170], xmm10
0000740ecffdc6d5  vmovaps xmm1, [rsp+0x20]
0000740ecffdc6db  vpermilpd xmm1, xmm1, 0x00
0000740ecffdc6e1  movaps xmm12, xmm14
0000740ecffdc6e5  mulpd xmm12, xmm1
0000740ecffdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
0000740ecffdc6f0  ptest xmm9, xmm9
0000740ecffdc6f6  jnz 0x0000740ECFFE0DCB
0000740ecffdc6fc  vmovaps xmm1, [rsp+0x20]
0000740ecffdc702  vpermilpd xmm1, xmm1, 0x00
0000740ecffdc708  vmovaps xmm9, [rsp+0xB0]
0000740ecffdc711  movaps xmm14, xmm9
0000740ecffdc715  mulpd xmm14, xmm1
0000740ecffdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
0000740ecffdc720  ptest xmm6, xmm6
0000740ecffdc725  jnz 0x0000740ECFFE0F0E
0000740ecffdc72b  movaps [r15+0x180], xmm14
0000740ecffdc733  movaps xmm1, xmm13
0000740ecffdc737  addpd xmm1, xmm8
0000740ecffdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
0000740ecffdc741  ptest xmm9, xmm9
0000740ecffdc747  jnz 0x0000740ECFFE1051
0000740ecffdc74d  movaps [r15+0x210], xmm1
0000740ecffdc755  movups xmm13, [r13+rax*1]
0000740ecffdc75b  lea r12, [rax+0x10]
0000740ecffdc75f  movups xmm9, [r13+r12*1]
0000740ecffdc765  movaps [r15+0x230], xmm9
0000740ecffdc76d  movaps xmm8, xmm15
0000740ecffdc771  addpd xmm8, xmm7
0000740ecffdc776  vcmppd xmm6, xmm8, xmm8, 0x03
0000740ecffdc77c  ptest xmm6, xmm6
0000740ecffdc781  jnz 0x0000740ECFFE11A7
0000740ecffdc787  movaps [r15+0x130], xmm8
0000740ecffdc78f  vmovaps xmm15, [rsp+0x20]
0000740ecffdc795  vpermilpd xmm15, xmm15, 0x00
0000740ecffdc79b  movaps xmm7, xmm9
0000740ecffdc79f  mulpd xmm7, xmm15
0000740ecffdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
0000740ecffdc7a9  ptest xmm6, xmm6
0000740ecffdc7ae  jnz 0x0000740ECFFE12EA
0000740ecffdc7b4  movaps [r15+0x220], xmm7
0000740ecffdc7bc  vmovaps xmm15, [rsp+0x20]
0000740ecffdc7c2  vpermilpd xmm15, xmm15, 0x00
0000740ecffdc7c8  movaps xmm9, xmm13
0000740ecffdc7cc  mulpd xmm9, xmm15
0000740ecffdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
0000740ecffdc7d7  ptest xmm6, xmm6
0000740ecffdc7dc  jnz 0x0000740ECFFE142C
0000740ecffdc7e2  movaps xmm15, xmm11
0000740ecffdc7e6  addpd xmm15, xmm12
0000740ecffdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
0000740ecffdc7f1  ptest xmm13, xmm13
0000740ecffdc7f7  jnz 0x0000740ECFFE1570
0000740ecffdc7fd  movaps [r15+0x140], xmm15
0000740ecffdc805  movaps xmm13, xmm10
0000740ecffdc809  addpd xmm13, xmm14
0000740ecffdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
0000740ecffdc814  ptest xmm12, xmm12
0000740ecffdc81a  jnz 0x0000740ECFFE16B4
0000740ecffdc820  movaps [r15+0x150], xmm13
0000740ecffdc828  movaps xmm14, xmm1
0000740ecffdc82c  addpd xmm14, xmm7
0000740ecffdc831  vcmppd xmm12, xmm14, xmm14, 0x03
0000740ecffdc837  ptest xmm12, xmm12
0000740ecffdc83d  jnz 0x0000740ECFFE17F8
0000740ecffdc843  movaps [r15+0x160], xmm14
0000740ecffdc84b  movaps xmm1, xmm8
0000740ecffdc84f  addpd xmm1, xmm9
0000740ecffdc854  vcmppd xmm12, xmm1, xmm1, 0x03
0000740ecffdc859  ptest xmm12, xmm12
0000740ecffdc85f  jnz 0x0000740ECFFE193A
0000740ecffdc865  movaps [r15+0x120], xmm1
0000740ecffdc86d  movups [r13+r14*1], xmm15
0000740ecffdc873  lea rax, [r14+0x10]
0000740ecffdc877  movups [r13+rax*1], xmm13
0000740ecffdc87d  lea rax, [r14+0x20]
0000740ecffdc881  movups [r13+rax*1], xmm14
0000740ecffdc887  lea rax, [r14+0x30]
0000740ecffdc88b  movups [r13+rax*1], xmm1
0000740ecffdc891  mov eax, [r15+0x108]
0000740ecffdc898  sahf
0000740ecffdc899  jnz 0x0000740ECFFDC8CB
0000740ecffdc89b  cmp dword ptr [r15+0x318], 0x00
0000740ecffdc8a3  jz 0x0000740ECFFDB900
0000740ecffdc8a9  nop [rax+rax*1], ax
0000740ecffdc8b2  nop [rax+rax*1], eax
0000740ecffdc8ba  mov eax, 0x410444
0000740ecffdc8bf  mov [r15+0x100], rax
0000740ecffdc8c6  jmp 0x0000740ECFDFE110
0000740ecffdc8cb  cmp dword ptr [r15+0x318], 0x00
0000740ecffdc8d3  jz 0x0000740ECFFD57E0
0000740ecffdc8d9  nop [rax+rax*1], ax
0000740ecffdc8e2  nop [rax+rax*1], eax
0000740ecffdc8ea  mov eax, 0x410278
0000740ecffdc8ef  mov [r15+0x100], rax
0000740ecffdc8f6  jmp 0x0000740ECFDFE110
0000740ecffdc8fb  int3
0000740ecffdc8fc  call 0x0000740ECFEE27E0
0000740ecffdc901  jmp 0x0000740ECFFDB9DF
0000740ecffdc906  call 0x0000740ECFEE1570
0000740ecffdc90b  jmp 0x0000740ECFFDB9E8
0000740ecffdc910  call 0x0000740ECFEE27E0
0000740ecffdc915  jmp 0x0000740ECFFDBA44
0000740ecffdc91a  call 0x0000740ECFEE1570
0000740ecffdc91f  jmp 0x0000740ECFFDBA4D
0000740ecffdc924  call 0x0000740ECFEE27E0
0000740ecffdc929  jmp 0x0000740ECFFDBA90
0000740ecffdc92e  call 0x0000740ECFEE1570
0000740ecffdc933  jmp 0x0000740ECFFDBA99
0000740ecffdc938  call 0x0000740ECFE0DC20
0000740ecffdc93d  jmp 0x0000740ECFFDBAD8
0000740ecffdc942  call 0x0000740ECFED59C0
0000740ecffdc947  jmp 0x0000740ECFFDBAEB
0000740ecffdc94c  call 0x0000740ECFEE0E30
0000740ecffdc951  jmp 0x0000740ECFFDBB09
0000740ecffdc956  call 0x0000740ECFEDFBC0
0000740ecffdc95b  jmp 0x0000740ECFFDBB13
0000740ecffdc960  call 0x0000740ECFEDE950
0000740ecffdc965  jmp 0x0000740ECFFDBB1D
0000740ecffdc96a  sub rsp, 0x08
0000740ecffdc96e  push rax
0000740ecffdc96f  push rcx
0000740ecffdc970  push rdx
0000740ecffdc971  push rdi
0000740ecffdc972  push rsi
0000740ecffdc973  push r8
0000740ecffdc975  push r9
0000740ecffdc977  push r10
0000740ecffdc979  push r11
0000740ecffdc97b  sub rsp, 0xF0
0000740ecffdc982  vmovaps [rsp], xmm0
0000740ecffdc987  vmovaps [rsp+0x10], xmm1
0000740ecffdc98d  vmovaps [rsp+0x20], xmm2
0000740ecffdc993  vmovaps [rsp+0x30], xmm3
0000740ecffdc999  vmovaps [rsp+0x40], xmm4
0000740ecffdc99f  vmovaps [rsp+0x50], xmm5
0000740ecffdc9a5  vmovaps [rsp+0x60], xmm6
0000740ecffdc9ab  vmovaps [rsp+0x70], xmm7
0000740ecffdc9b1  vmovaps [rsp+0x80], xmm9
0000740ecffdc9ba  vmovaps [rsp+0x90], xmm10
0000740ecffdc9c3  vmovaps [rsp+0xA0], xmm11
0000740ecffdc9cc  vmovaps [rsp+0xB0], xmm12
0000740ecffdc9d5  vmovaps [rsp+0xC0], xmm13
0000740ecffdc9de  vmovaps [rsp+0xD0], xmm14
0000740ecffdc9e7  vmovaps [rsp+0xE0], xmm15
0000740ecffdc9f0  sub rsp, 0x30
0000740ecffdc9f4  movaps [rsp], xmm8
0000740ecffdc9f9  movaps [rsp+0x10], xmm12
0000740ecffdc9ff  movaps [rsp+0x20], xmm15
0000740ecffdca05  lea rdi, [rsp]
0000740ecffdca09  mov esi, 0x00
0000740ecffdca0e  mov rax, 0x5E8249CF1530
0000740ecffdca18  call rax
0000740ecffdca1a  movaps xmm8, [rsp]
0000740ecffdca1f  add rsp, 0x30
0000740ecffdca23  vmovaps xmm0, [rsp]
0000740ecffdca28  vmovaps xmm1, [rsp+0x10]
0000740ecffdca2e  vmovaps xmm2, [rsp+0x20]
0000740ecffdca34  vmovaps xmm3, [rsp+0x30]
0000740ecffdca3a  vmovaps xmm4, [rsp+0x40]
0000740ecffdca40  vmovaps xmm5, [rsp+0x50]
0000740ecffdca46  vmovaps xmm6, [rsp+0x60]
0000740ecffdca4c  vmovaps xmm7, [rsp+0x70]
0000740ecffdca52  vmovaps xmm9, [rsp+0x80]
0000740ecffdca5b  vmovaps xmm10, [rsp+0x90]
0000740ecffdca64  vmovaps xmm11, [rsp+0xA0]
0000740ecffdca6d  vmovaps xmm12, [rsp+0xB0]
0000740ecffdca76  vmovaps xmm13, [rsp+0xC0]
0000740ecffdca7f  vmovaps xmm14, [rsp+0xD0]
0000740ecffdca88  vmovaps xmm15, [rsp+0xE0]
0000740ecffdca91  add rsp, 0xF0
0000740ecffdca98  pop r11
0000740ecffdca9a  pop r10
0000740ecffdca9c  pop r9
0000740ecffdca9e  pop r8
0000740ecffdcaa0  pop rsi
0000740ecffdcaa1  pop rdi
0000740ecffdcaa2  pop rdx
0000740ecffdcaa3  pop rcx
0000740ecffdcaa4  pop rax
0000740ecffdcaa5  add rsp, 0x08
0000740ecffdcaa9  jmp 0x0000740ECFFDBB47
0000740ecffdcaae  sub rsp, 0x08
0000740ecffdcab2  push rax
0000740ecffdcab3  push rcx
0000740ecffdcab4  push rdx
0000740ecffdcab5  push rdi
0000740ecffdcab6  push rsi
0000740ecffdcab7  push r8
0000740ecffdcab9  push r9
0000740ecffdcabb  push r10
0000740ecffdcabd  push r11
0000740ecffdcabf  sub rsp, 0xF0
0000740ecffdcac6  vmovaps [rsp], xmm0
0000740ecffdcacb  vmovaps [rsp+0x10], xmm1
0000740ecffdcad1  vmovaps [rsp+0x20], xmm2
0000740ecffdcad7  vmovaps [rsp+0x30], xmm3
0000740ecffdcadd  vmovaps [rsp+0x40], xmm4
0000740ecffdcae3  vmovaps [rsp+0x50], xmm5
0000740ecffdcae9  vmovaps [rsp+0x60], xmm6
0000740ecffdcaef  vmovaps [rsp+0x70], xmm8
0000740ecffdcaf5  vmovaps [rsp+0x80], xmm9
0000740ecffdcafe  vmovaps [rsp+0x90], xmm10
0000740ecffdcb07  vmovaps [rsp+0xA0], xmm11
0000740ecffdcb10  vmovaps [rsp+0xB0], xmm12
0000740ecffdcb19  vmovaps [rsp+0xC0], xmm13
0000740ecffdcb22  vmovaps [rsp+0xD0], xmm14
0000740ecffdcb2b  vmovaps [rsp+0xE0], xmm15
0000740ecffdcb34  sub rsp, 0x30
0000740ecffdcb38  movaps [rsp], xmm7
0000740ecffdcb3c  movaps [rsp+0x10], xmm9
0000740ecffdcb42  movaps [rsp+0x20], xmm15
0000740ecffdcb48  lea rdi, [rsp]
0000740ecffdcb4c  mov esi, 0x00
0000740ecffdcb51  mov rax, 0x5E8249CF1530
0000740ecffdcb5b  call rax
0000740ecffdcb5d  movaps xmm7, [rsp]
0000740ecffdcb61  add rsp, 0x30
0000740ecffdcb65  vmovaps xmm0, [rsp]
0000740ecffdcb6a  vmovaps xmm1, [rsp+0x10]
0000740ecffdcb70  vmovaps xmm2, [rsp+0x20]
0000740ecffdcb76  vmovaps xmm3, [rsp+0x30]
0000740ecffdcb7c  vmovaps xmm4, [rsp+0x40]
0000740ecffdcb82  vmovaps xmm5, [rsp+0x50]
0000740ecffdcb88  vmovaps xmm6, [rsp+0x60]
0000740ecffdcb8e  vmovaps xmm8, [rsp+0x70]
0000740ecffdcb94  vmovaps xmm9, [rsp+0x80]
0000740ecffdcb9d  vmovaps xmm10, [rsp+0x90]
0000740ecffdcba6  vmovaps xmm11, [rsp+0xA0]
0000740ecffdcbaf  vmovaps xmm12, [rsp+0xB0]
0000740ecffdcbb8  vmovaps xmm13, [rsp+0xC0]
0000740ecffdcbc1  vmovaps xmm14, [rsp+0xD0]
0000740ecffdcbca  vmovaps xmm15, [rsp+0xE0]
0000740ecffdcbd3  add rsp, 0xF0
0000740ecffdcbda  pop r11
0000740ecffdcbdc  pop r10
0000740ecffdcbde  pop r9
0000740ecffdcbe0  pop r8
0000740ecffdcbe2  pop rsi
0000740ecffdcbe3  pop rdi
0000740ecffdcbe4  pop rdx
0000740ecffdcbe5  pop rcx
0000740ecffdcbe6  pop rax
0000740ecffdcbe7  add rsp, 0x08
0000740ecffdcbeb  jmp 0x0000740ECFFDBB75
0000740ecffdcbf0  sub rsp, 0x08
0000740ecffdcbf4  push rax
0000740ecffdcbf5  push rcx
0000740ecffdcbf6  push rdx
0000740ecffdcbf7  push rdi
0000740ecffdcbf8  push rsi
0000740ecffdcbf9  push r8
0000740ecffdcbfb  push r9
0000740ecffdcbfd  push r10
0000740ecffdcbff  push r11
0000740ecffdcc01  sub rsp, 0xF0
0000740ecffdcc08  vmovaps [rsp], xmm0
0000740ecffdcc0d  vmovaps [rsp+0x10], xmm1
0000740ecffdcc13  vmovaps [rsp+0x20], xmm2
0000740ecffdcc19  vmovaps [rsp+0x30], xmm3
0000740ecffdcc1f  vmovaps [rsp+0x40], xmm4
0000740ecffdcc25  vmovaps [rsp+0x50], xmm5
0000740ecffdcc2b  vmovaps [rsp+0x60], xmm6
0000740ecffdcc31  vmovaps [rsp+0x70], xmm7
0000740ecffdcc37  vmovaps [rsp+0x80], xmm8
0000740ecffdcc40  vmovaps [rsp+0x90], xmm10
0000740ecffdcc49  vmovaps [rsp+0xA0], xmm11
0000740ecffdcc52  vmovaps [rsp+0xB0], xmm12
0000740ecffdcc5b  vmovaps [rsp+0xC0], xmm13
0000740ecffdcc64  vmovaps [rsp+0xD0], xmm14
0000740ecffdcc6d  vmovaps [rsp+0xE0], xmm15
0000740ecffdcc76  sub rsp, 0x30
0000740ecffdcc7a  movaps [rsp], xmm9
0000740ecffdcc7f  movaps [rsp+0x10], xmm12
0000740ecffdcc85  movaps [rsp+0x20], xmm10
0000740ecffdcc8b  lea rdi, [rsp]
0000740ecffdcc8f  mov esi, 0x00
0000740ecffdcc94  mov rax, 0x5E8249CF1530
0000740ecffdcc9e  call rax
0000740ecffdcca0  movaps xmm9, [rsp]
0000740ecffdcca5  add rsp, 0x30
0000740ecffdcca9  vmovaps xmm0, [rsp]
0000740ecffdccae  vmovaps xmm1, [rsp+0x10]
0000740ecffdccb4  vmovaps xmm2, [rsp+0x20]
0000740ecffdccba  vmovaps xmm3, [rsp+0x30]
0000740ecffdccc0  vmovaps xmm4, [rsp+0x40]
0000740ecffdccc6  vmovaps xmm5, [rsp+0x50]
0000740ecffdcccc  vmovaps xmm6, [rsp+0x60]
0000740ecffdccd2  vmovaps xmm7, [rsp+0x70]
0000740ecffdccd8  vmovaps xmm8, [rsp+0x80]
0000740ecffdcce1  vmovaps xmm10, [rsp+0x90]
0000740ecffdccea  vmovaps xmm11, [rsp+0xA0]
0000740ecffdccf3  vmovaps xmm12, [rsp+0xB0]
0000740ecffdccfc  vmovaps xmm13, [rsp+0xC0]
0000740ecffdcd05  vmovaps xmm14, [rsp+0xD0]
0000740ecffdcd0e  vmovaps xmm15, [rsp+0xE0]
0000740ecffdcd17  add rsp, 0xF0
0000740ecffdcd1e  pop r11
0000740ecffdcd20  pop r10
0000740ecffdcd22  pop r9
0000740ecffdcd24  pop r8
0000740ecffdcd26  pop rsi
0000740ecffdcd27  pop rdi
0000740ecffdcd28  pop rdx
0000740ecffdcd29  pop rcx
0000740ecffdcd2a  pop rax
0000740ecffdcd2b  add rsp, 0x08
0000740ecffdcd2f  jmp 0x0000740ECFFDBB99
0000740ecffdcd34  sub rsp, 0x08
0000740ecffdcd38  push rax
0000740ecffdcd39  push rcx
0000740ecffdcd3a  push rdx
0000740ecffdcd3b  push rdi
0000740ecffdcd3c  push rsi
0000740ecffdcd3d  push r8
0000740ecffdcd3f  push r9
0000740ecffdcd41  push r10
0000740ecffdcd43  push r11
0000740ecffdcd45  sub rsp, 0xF0
0000740ecffdcd4c  vmovaps [rsp], xmm0
0000740ecffdcd51  vmovaps [rsp+0x10], xmm1
0000740ecffdcd57  vmovaps [rsp+0x20], xmm2
0000740ecffdcd5d  vmovaps [rsp+0x30], xmm3
0000740ecffdcd63  vmovaps [rsp+0x40], xmm4
0000740ecffdcd69  vmovaps [rsp+0x50], xmm5
0000740ecffdcd6f  vmovaps [rsp+0x60], xmm6
0000740ecffdcd75  vmovaps [rsp+0x70], xmm7
0000740ecffdcd7b  vmovaps [rsp+0x80], xmm8
0000740ecffdcd84  vmovaps [rsp+0x90], xmm9
0000740ecffdcd8d  vmovaps [rsp+0xA0], xmm11
0000740ecffdcd96  vmovaps [rsp+0xB0], xmm12
0000740ecffdcd9f  vmovaps [rsp+0xC0], xmm13
0000740ecffdcda8  vmovaps [rsp+0xD0], xmm14
0000740ecffdcdb1  vmovaps [rsp+0xE0], xmm15
0000740ecffdcdba  sub rsp, 0x30
0000740ecffdcdbe  movaps [rsp], xmm10
0000740ecffdcdc3  movaps [rsp+0x10], xmm12
0000740ecffdcdc9  movaps [rsp+0x20], xmm11
0000740ecffdcdcf  lea rdi, [rsp]
0000740ecffdcdd3  mov esi, 0x00
0000740ecffdcdd8  mov rax, 0x5E8249CF1530
0000740ecffdcde2  call rax
0000740ecffdcde4  movaps xmm10, [rsp]
0000740ecffdcde9  add rsp, 0x30
0000740ecffdcded  vmovaps xmm0, [rsp]
0000740ecffdcdf2  vmovaps xmm1, [rsp+0x10]
0000740ecffdcdf8  vmovaps xmm2, [rsp+0x20]
0000740ecffdcdfe  vmovaps xmm3, [rsp+0x30]
0000740ecffdce04  vmovaps xmm4, [rsp+0x40]
0000740ecffdce0a  vmovaps xmm5, [rsp+0x50]
0000740ecffdce10  vmovaps xmm6, [rsp+0x60]
0000740ecffdce16  vmovaps xmm7, [rsp+0x70]
0000740ecffdce1c  vmovaps xmm8, [rsp+0x80]
0000740ecffdce25  vmovaps xmm9, [rsp+0x90]
0000740ecffdce2e  vmovaps xmm11, [rsp+0xA0]
0000740ecffdce37  vmovaps xmm12, [rsp+0xB0]
0000740ecffdce40  vmovaps xmm13, [rsp+0xC0]
0000740ecffdce49  vmovaps xmm14, [rsp+0xD0]
0000740ecffdce52  vmovaps xmm15, [rsp+0xE0]
0000740ecffdce5b  add rsp, 0xF0
0000740ecffdce62  pop r11
0000740ecffdce64  pop r10
0000740ecffdce66  pop r9
0000740ecffdce68  pop r8
0000740ecffdce6a  pop rsi
0000740ecffdce6b  pop rdi
0000740ecffdce6c  pop rdx
0000740ecffdce6d  pop rcx
0000740ecffdce6e  pop rax
0000740ecffdce6f  add rsp, 0x08
0000740ecffdce73  jmp 0x0000740ECFFDBBB3
0000740ecffdce78  sub rsp, 0x08
0000740ecffdce7c  push rax
0000740ecffdce7d  push rcx
0000740ecffdce7e  push rdx
0000740ecffdce7f  push rdi
0000740ecffdce80  push rsi
0000740ecffdce81  push r8
0000740ecffdce83  push r9
0000740ecffdce85  push r10
0000740ecffdce87  push r11
0000740ecffdce89  sub rsp, 0xF0
0000740ecffdce90  vmovaps [rsp], xmm0
0000740ecffdce95  vmovaps [rsp+0x10], xmm1
0000740ecffdce9b  vmovaps [rsp+0x20], xmm2
0000740ecffdcea1  vmovaps [rsp+0x30], xmm3
0000740ecffdcea7  vmovaps [rsp+0x40], xmm4
0000740ecffdcead  vmovaps [rsp+0x50], xmm5
0000740ecffdceb3  vmovaps [rsp+0x60], xmm7
0000740ecffdceb9  vmovaps [rsp+0x70], xmm8
0000740ecffdcebf  vmovaps [rsp+0x80], xmm9
0000740ecffdcec8  vmovaps [rsp+0x90], xmm10
0000740ecffdced1  vmovaps [rsp+0xA0], xmm11
0000740ecffdceda  vmovaps [rsp+0xB0], xmm12
0000740ecffdcee3  vmovaps [rsp+0xC0], xmm13
0000740ecffdceec  vmovaps [rsp+0xD0], xmm14
0000740ecffdcef5  vmovaps [rsp+0xE0], xmm15
0000740ecffdcefe  sub rsp, 0x30
0000740ecffdcf02  movaps [rsp], xmm6
0000740ecffdcf06  movaps [rsp+0x10], xmm12
0000740ecffdcf0c  movaps [rsp+0x20], xmm11
0000740ecffdcf12  lea rdi, [rsp]
0000740ecffdcf16  mov esi, 0x00
0000740ecffdcf1b  mov rax, 0x5E8249CF1530
0000740ecffdcf25  call rax
0000740ecffdcf27  movaps xmm6, [rsp]
0000740ecffdcf2b  add rsp, 0x30
0000740ecffdcf2f  vmovaps xmm0, [rsp]
0000740ecffdcf34  vmovaps xmm1, [rsp+0x10]
0000740ecffdcf3a  vmovaps xmm2, [rsp+0x20]
0000740ecffdcf40  vmovaps xmm3, [rsp+0x30]
0000740ecffdcf46  vmovaps xmm4, [rsp+0x40]
0000740ecffdcf4c  vmovaps xmm5, [rsp+0x50]
0000740ecffdcf52  vmovaps xmm7, [rsp+0x60]
0000740ecffdcf58  vmovaps xmm8, [rsp+0x70]
0000740ecffdcf5e  vmovaps xmm9, [rsp+0x80]
0000740ecffdcf67  vmovaps xmm10, [rsp+0x90]
0000740ecffdcf70  vmovaps xmm11, [rsp+0xA0]
0000740ecffdcf79  vmovaps xmm12, [rsp+0xB0]
0000740ecffdcf82  vmovaps xmm13, [rsp+0xC0]
0000740ecffdcf8b  vmovaps xmm14, [rsp+0xD0]
0000740ecffdcf94  vmovaps xmm15, [rsp+0xE0]
0000740ecffdcf9d  add rsp, 0xF0
0000740ecffdcfa4  pop r11
0000740ecffdcfa6  pop r10
0000740ecffdcfa8  pop r9
0000740ecffdcfaa  pop r8
0000740ecffdcfac  pop rsi
0000740ecffdcfad  pop rdi
0000740ecffdcfae  pop rdx
0000740ecffdcfaf  pop rcx
0000740ecffdcfb0  pop rax
0000740ecffdcfb1  add rsp, 0x08
0000740ecffdcfb5  jmp 0x0000740ECFFDBBD4
0000740ecffdcfba  sub rsp, 0x08
0000740ecffdcfbe  push rax
0000740ecffdcfbf  push rcx
0000740ecffdcfc0  push rdx
0000740ecffdcfc1  push rdi
0000740ecffdcfc2  push rsi
0000740ecffdcfc3  push r8
0000740ecffdcfc5  push r9
0000740ecffdcfc7  push r10
0000740ecffdcfc9  push r11
0000740ecffdcfcb  sub rsp, 0xF0
0000740ecffdcfd2  vmovaps [rsp], xmm0
0000740ecffdcfd7  vmovaps [rsp+0x10], xmm1
0000740ecffdcfdd  vmovaps [rsp+0x20], xmm2
0000740ecffdcfe3  vmovaps [rsp+0x30], xmm4
0000740ecffdcfe9  vmovaps [rsp+0x40], xmm5
0000740ecffdcfef  vmovaps [rsp+0x50], xmm6
0000740ecffdcff5  vmovaps [rsp+0x60], xmm7
0000740ecffdcffb  vmovaps [rsp+0x70], xmm8
0000740ecffdd001  vmovaps [rsp+0x80], xmm9
0000740ecffdd00a  vmovaps [rsp+0x90], xmm10
0000740ecffdd013  vmovaps [rsp+0xA0], xmm11
0000740ecffdd01c  vmovaps [rsp+0xB0], xmm12
0000740ecffdd025  vmovaps [rsp+0xC0], xmm13
0000740ecffdd02e  vmovaps [rsp+0xD0], xmm14
0000740ecffdd037  vmovaps [rsp+0xE0], xmm15
0000740ecffdd040  sub rsp, 0x30
0000740ecffdd044  movaps [rsp], xmm3
0000740ecffdd048  movaps [rsp+0x10], xmm5
0000740ecffdd04d  movaps [rsp+0x20], xmm4
0000740ecffdd052  lea rdi, [rsp]
0000740ecffdd056  mov esi, 0x00
0000740ecffdd05b  mov rax, 0x5E8249CF1530
0000740ecffdd065  call rax
0000740ecffdd067  movaps xmm3, [rsp]
0000740ecffdd06b  add rsp, 0x30
0000740ecffdd06f  vmovaps xmm0, [rsp]
0000740ecffdd074  vmovaps xmm1, [rsp+0x10]
0000740ecffdd07a  vmovaps xmm2, [rsp+0x20]
0000740ecffdd080  vmovaps xmm4, [rsp+0x30]
0000740ecffdd086  vmovaps xmm5, [rsp+0x40]
0000740ecffdd08c  vmovaps xmm6, [rsp+0x50]
0000740ecffdd092  vmovaps xmm7, [rsp+0x60]
0000740ecffdd098  vmovaps xmm8, [rsp+0x70]
0000740ecffdd09e  vmovaps xmm9, [rsp+0x80]
0000740ecffdd0a7  vmovaps xmm10, [rsp+0x90]
0000740ecffdd0b0  vmovaps xmm11, [rsp+0xA0]
0000740ecffdd0b9  vmovaps xmm12, [rsp+0xB0]
0000740ecffdd0c2  vmovaps xmm13, [rsp+0xC0]
0000740ecffdd0cb  vmovaps xmm14, [rsp+0xD0]
0000740ecffdd0d4  vmovaps xmm15, [rsp+0xE0]
0000740ecffdd0dd  add rsp, 0xF0
0000740ecffdd0e4  pop r11
0000740ecffdd0e6  pop r10
0000740ecffdd0e8  pop r9
0000740ecffdd0ea  pop r8
0000740ecffdd0ec  pop rsi
0000740ecffdd0ed  pop rdi
0000740ecffdd0ee  pop rdx
0000740ecffdd0ef  pop rcx
0000740ecffdd0f0  pop rax
0000740ecffdd0f1  add rsp, 0x08
0000740ecffdd0f5  jmp 0x0000740ECFFDBC35
0000740ecffdd0fa  sub rsp, 0x08
0000740ecffdd0fe  push rax
0000740ecffdd0ff  push rcx
0000740ecffdd100  push rdx
0000740ecffdd101  push rdi
0000740ecffdd102  push rsi
0000740ecffdd103  push r8
0000740ecffdd105  push r9
0000740ecffdd107  push r10
0000740ecffdd109  push r11
0000740ecffdd10b  sub rsp, 0xF0
0000740ecffdd112  vmovaps [rsp], xmm0
0000740ecffdd117  vmovaps [rsp+0x10], xmm1
0000740ecffdd11d  vmovaps [rsp+0x20], xmm2
0000740ecffdd123  vmovaps [rsp+0x30], xmm3
0000740ecffdd129  vmovaps [rsp+0x40], xmm4
0000740ecffdd12f  vmovaps [rsp+0x50], xmm6
0000740ecffdd135  vmovaps [rsp+0x60], xmm7
0000740ecffdd13b  vmovaps [rsp+0x70], xmm8
0000740ecffdd141  vmovaps [rsp+0x80], xmm9
0000740ecffdd14a  vmovaps [rsp+0x90], xmm10
0000740ecffdd153  vmovaps [rsp+0xA0], xmm11
0000740ecffdd15c  vmovaps [rsp+0xB0], xmm12
0000740ecffdd165  vmovaps [rsp+0xC0], xmm13
0000740ecffdd16e  vmovaps [rsp+0xD0], xmm14
0000740ecffdd177  vmovaps [rsp+0xE0], xmm15
0000740ecffdd180  sub rsp, 0x30
0000740ecffdd184  movaps [rsp], xmm5
0000740ecffdd188  movaps [rsp+0x10], xmm8
0000740ecffdd18e  movaps [rsp+0x20], xmm15
0000740ecffdd194  lea rdi, [rsp]
0000740ecffdd198  mov esi, 0x00
0000740ecffdd19d  mov rax, 0x5E8249CF1530
0000740ecffdd1a7  call rax
0000740ecffdd1a9  movaps xmm5, [rsp]
0000740ecffdd1ad  add rsp, 0x30
0000740ecffdd1b1  vmovaps xmm0, [rsp]
0000740ecffdd1b6  vmovaps xmm1, [rsp+0x10]
0000740ecffdd1bc  vmovaps xmm2, [rsp+0x20]
0000740ecffdd1c2  vmovaps xmm3, [rsp+0x30]
0000740ecffdd1c8  vmovaps xmm4, [rsp+0x40]
0000740ecffdd1ce  vmovaps xmm6, [rsp+0x50]
0000740ecffdd1d4  vmovaps xmm7, [rsp+0x60]
0000740ecffdd1da  vmovaps xmm8, [rsp+0x70]
0000740ecffdd1e0  vmovaps xmm9, [rsp+0x80]
0000740ecffdd1e9  vmovaps xmm10, [rsp+0x90]
0000740ecffdd1f2  vmovaps xmm11, [rsp+0xA0]
0000740ecffdd1fb  vmovaps xmm12, [rsp+0xB0]
0000740ecffdd204  vmovaps xmm13, [rsp+0xC0]
0000740ecffdd20d  vmovaps xmm14, [rsp+0xD0]
0000740ecffdd216  vmovaps xmm15, [rsp+0xE0]
0000740ecffdd21f  add rsp, 0xF0
0000740ecffdd226  pop r11
0000740ecffdd228  pop r10
0000740ecffdd22a  pop r9
0000740ecffdd22c  pop r8
0000740ecffdd22e  pop rsi
0000740ecffdd22f  pop rdi
0000740ecffdd230  pop rdx
0000740ecffdd231  pop rcx
0000740ecffdd232  pop rax
0000740ecffdd233  add rsp, 0x08
0000740ecffdd237  jmp 0x0000740ECFFDBC73
0000740ecffdd23c  sub rsp, 0x08
0000740ecffdd240  push rax
0000740ecffdd241  push rcx
0000740ecffdd242  push rdx
0000740ecffdd243  push rdi
0000740ecffdd244  push rsi
0000740ecffdd245  push r8
0000740ecffdd247  push r9
0000740ecffdd249  push r10
0000740ecffdd24b  push r11
0000740ecffdd24d  sub rsp, 0xF0
0000740ecffdd254  vmovaps [rsp], xmm0
0000740ecffdd259  vmovaps [rsp+0x10], xmm1
0000740ecffdd25f  vmovaps [rsp+0x20], xmm2
0000740ecffdd265  vmovaps [rsp+0x30], xmm3
0000740ecffdd26b  vmovaps [rsp+0x40], xmm5
0000740ecffdd271  vmovaps [rsp+0x50], xmm6
0000740ecffdd277  vmovaps [rsp+0x60], xmm7
0000740ecffdd27d  vmovaps [rsp+0x70], xmm8
0000740ecffdd283  vmovaps [rsp+0x80], xmm9
0000740ecffdd28c  vmovaps [rsp+0x90], xmm10
0000740ecffdd295  vmovaps [rsp+0xA0], xmm11
0000740ecffdd29e  vmovaps [rsp+0xB0], xmm12
0000740ecffdd2a7  vmovaps [rsp+0xC0], xmm13
0000740ecffdd2b0  vmovaps [rsp+0xD0], xmm14
0000740ecffdd2b9  vmovaps [rsp+0xE0], xmm15
0000740ecffdd2c2  sub rsp, 0x30
0000740ecffdd2c6  movaps [rsp], xmm4
0000740ecffdd2ca  movaps [rsp+0x10], xmm9
0000740ecffdd2d0  movaps [rsp+0x20], xmm8
0000740ecffdd2d6  lea rdi, [rsp]
0000740ecffdd2da  mov esi, 0x00
0000740ecffdd2df  mov rax, 0x5E8249CF1530
0000740ecffdd2e9  call rax
0000740ecffdd2eb  movaps xmm4, [rsp]
0000740ecffdd2ef  add rsp, 0x30
0000740ecffdd2f3  vmovaps xmm0, [rsp]
0000740ecffdd2f8  vmovaps xmm1, [rsp+0x10]
0000740ecffdd2fe  vmovaps xmm2, [rsp+0x20]
0000740ecffdd304  vmovaps xmm3, [rsp+0x30]
0000740ecffdd30a  vmovaps xmm5, [rsp+0x40]
0000740ecffdd310  vmovaps xmm6, [rsp+0x50]
0000740ecffdd316  vmovaps xmm7, [rsp+0x60]
0000740ecffdd31c  vmovaps xmm8, [rsp+0x70]
0000740ecffdd322  vmovaps xmm9, [rsp+0x80]
0000740ecffdd32b  vmovaps xmm10, [rsp+0x90]
0000740ecffdd334  vmovaps xmm11, [rsp+0xA0]
0000740ecffdd33d  vmovaps xmm12, [rsp+0xB0]
0000740ecffdd346  vmovaps xmm13, [rsp+0xC0]
0000740ecffdd34f  vmovaps xmm14, [rsp+0xD0]
0000740ecffdd358  vmovaps xmm15, [rsp+0xE0]
0000740ecffdd361  add rsp, 0xF0
0000740ecffdd368  pop r11
0000740ecffdd36a  pop r10
0000740ecffdd36c  pop r9
0000740ecffdd36e  pop r8
0000740ecffdd370  pop rsi
0000740ecffdd371  pop rdi
0000740ecffdd372  pop rdx
0000740ecffdd373  pop rcx
0000740ecffdd374  pop rax
0000740ecffdd375  add rsp, 0x08
0000740ecffdd379  jmp 0x0000740ECFFDBC94
0000740ecffdd37e  sub rsp, 0x08
0000740ecffdd382  push rax
0000740ecffdd383  push rcx
0000740ecffdd384  push rdx
0000740ecffdd385  push rdi
0000740ecffdd386  push rsi
0000740ecffdd387  push r8
0000740ecffdd389  push r9
0000740ecffdd38b  push r10
0000740ecffdd38d  push r11
0000740ecffdd38f  sub rsp, 0xF0
0000740ecffdd396  vmovaps [rsp], xmm0
0000740ecffdd39b  vmovaps [rsp+0x10], xmm1
0000740ecffdd3a1  vmovaps [rsp+0x20], xmm2
0000740ecffdd3a7  vmovaps [rsp+0x30], xmm3
0000740ecffdd3ad  vmovaps [rsp+0x40], xmm4
0000740ecffdd3b3  vmovaps [rsp+0x50], xmm5
0000740ecffdd3b9  vmovaps [rsp+0x60], xmm6
0000740ecffdd3bf  vmovaps [rsp+0x70], xmm7
0000740ecffdd3c5  vmovaps [rsp+0x80], xmm8
0000740ecffdd3ce  vmovaps [rsp+0x90], xmm10
0000740ecffdd3d7  vmovaps [rsp+0xA0], xmm11
0000740ecffdd3e0  vmovaps [rsp+0xB0], xmm12
0000740ecffdd3e9  vmovaps [rsp+0xC0], xmm13
0000740ecffdd3f2  vmovaps [rsp+0xD0], xmm14
0000740ecffdd3fb  vmovaps [rsp+0xE0], xmm15
0000740ecffdd404  sub rsp, 0x30
0000740ecffdd408  movaps [rsp], xmm9
0000740ecffdd40d  movaps [rsp+0x10], xmm10
0000740ecffdd413  movaps [rsp+0x20], xmm8
0000740ecffdd419  lea rdi, [rsp]
0000740ecffdd41d  mov esi, 0x00
0000740ecffdd422  mov rax, 0x5E8249CF1530
0000740ecffdd42c  call rax
0000740ecffdd42e  movaps xmm9, [rsp]
0000740ecffdd433  add rsp, 0x30
0000740ecffdd437  vmovaps xmm0, [rsp]
0000740ecffdd43c  vmovaps xmm1, [rsp+0x10]
0000740ecffdd442  vmovaps xmm2, [rsp+0x20]
0000740ecffdd448  vmovaps xmm3, [rsp+0x30]
0000740ecffdd44e  vmovaps xmm4, [rsp+0x40]
0000740ecffdd454  vmovaps xmm5, [rsp+0x50]
0000740ecffdd45a  vmovaps xmm6, [rsp+0x60]
0000740ecffdd460  vmovaps xmm7, [rsp+0x70]
0000740ecffdd466  vmovaps xmm8, [rsp+0x80]
0000740ecffdd46f  vmovaps xmm10, [rsp+0x90]
0000740ecffdd478  vmovaps xmm11, [rsp+0xA0]
0000740ecffdd481  vmovaps xmm12, [rsp+0xB0]
0000740ecffdd48a  vmovaps xmm13, [rsp+0xC0]
0000740ecffdd493  vmovaps xmm14, [rsp+0xD0]
0000740ecffdd49c  vmovaps xmm15, [rsp+0xE0]
0000740ecffdd4a5  add rsp, 0xF0
0000740ecffdd4ac  pop r11
0000740ecffdd4ae  pop r10
0000740ecffdd4b0  pop r9
0000740ecffdd4b2  pop r8
0000740ecffdd4b4  pop rsi
0000740ecffdd4b5  pop rdi
0000740ecffdd4b6  pop rdx
0000740ecffdd4b7  pop rcx
0000740ecffdd4b8  pop rax
0000740ecffdd4b9  add rsp, 0x08
0000740ecffdd4bd  jmp 0x0000740ECFFDBCAE
0000740ecffdd4c2  call 0x0000740ECFEB52F0
0000740ecffdd4c7  jmp 0x0000740ECFFDBDC8
0000740ecffdd4cc  call 0x0000740ECFEB52F0
0000740ecffdd4d1  jmp 0x0000740ECFFDBDDE
0000740ecffdd4d6  sub rsp, 0x08
0000740ecffdd4da  push rax
0000740ecffdd4db  push rcx
0000740ecffdd4dc  push rdx
0000740ecffdd4dd  push rdi
0000740ecffdd4de  push rsi
0000740ecffdd4df  push r8
0000740ecffdd4e1  push r9
0000740ecffdd4e3  push r10
0000740ecffdd4e5  push r11
0000740ecffdd4e7  sub rsp, 0xF0
0000740ecffdd4ee  vmovaps [rsp], xmm0
0000740ecffdd4f3  vmovaps [rsp+0x10], xmm2
0000740ecffdd4f9  vmovaps [rsp+0x20], xmm3
0000740ecffdd4ff  vmovaps [rsp+0x30], xmm4
0000740ecffdd505  vmovaps [rsp+0x40], xmm5
0000740ecffdd50b  vmovaps [rsp+0x50], xmm6
0000740ecffdd511  vmovaps [rsp+0x60], xmm7
0000740ecffdd517  vmovaps [rsp+0x70], xmm8
0000740ecffdd51d  vmovaps [rsp+0x80], xmm9
0000740ecffdd526  vmovaps [rsp+0x90], xmm10
0000740ecffdd52f  vmovaps [rsp+0xA0], xmm11
0000740ecffdd538  vmovaps [rsp+0xB0], xmm12
0000740ecffdd541  vmovaps [rsp+0xC0], xmm13
0000740ecffdd54a  vmovaps [rsp+0xD0], xmm14
0000740ecffdd553  vmovaps [rsp+0xE0], xmm15
0000740ecffdd55c  sub rsp, 0x30
0000740ecffdd560  movaps [rsp], xmm1
0000740ecffdd564  movaps [rsp+0x10], xmm6
0000740ecffdd569  movaps [rsp+0x20], xmm15
0000740ecffdd56f  lea rdi, [rsp]
0000740ecffdd573  mov esi, 0x00
0000740ecffdd578  mov rax, 0x5E8249CF1530
0000740ecffdd582  call rax
0000740ecffdd584  movaps xmm1, [rsp]
0000740ecffdd588  add rsp, 0x30
0000740ecffdd58c  vmovaps xmm0, [rsp]
0000740ecffdd591  vmovaps xmm2, [rsp+0x10]
0000740ecffdd597  vmovaps xmm3, [rsp+0x20]
0000740ecffdd59d  vmovaps xmm4, [rsp+0x30]
0000740ecffdd5a3  vmovaps xmm5, [rsp+0x40]
0000740ecffdd5a9  vmovaps xmm6, [rsp+0x50]
0000740ecffdd5af  vmovaps xmm7, [rsp+0x60]
0000740ecffdd5b5  vmovaps xmm8, [rsp+0x70]
0000740ecffdd5bb  vmovaps xmm9, [rsp+0x80]
0000740ecffdd5c4  vmovaps xmm10, [rsp+0x90]
0000740ecffdd5cd  vmovaps xmm11, [rsp+0xA0]
0000740ecffdd5d6  vmovaps xmm12, [rsp+0xB0]
0000740ecffdd5df  vmovaps xmm13, [rsp+0xC0]
0000740ecffdd5e8  vmovaps xmm14, [rsp+0xD0]
0000740ecffdd5f1  vmovaps xmm15, [rsp+0xE0]
0000740ecffdd5fa  add rsp, 0xF0
0000740ecffdd601  pop r11
0000740ecffdd603  pop r10
0000740ecffdd605  pop r9
0000740ecffdd607  pop r8
0000740ecffdd609  pop rsi
0000740ecffdd60a  pop rdi
0000740ecffdd60b  pop rdx
0000740ecffdd60c  pop rcx
0000740ecffdd60d  pop rax
0000740ecffdd60e  add rsp, 0x08
0000740ecffdd612  jmp 0x0000740ECFFDBE1B
0000740ecffdd617  call 0x0000740ECFEC4620
0000740ecffdd61c  jmp 0x0000740ECFFDBE28
0000740ecffdd621  sub rsp, 0x08
0000740ecffdd625  push rax
0000740ecffdd626  push rcx
0000740ecffdd627  push rdx
0000740ecffdd628  push rdi
0000740ecffdd629  push rsi
0000740ecffdd62a  push r8
0000740ecffdd62c  push r9
0000740ecffdd62e  push r10
0000740ecffdd630  push r11
0000740ecffdd632  sub rsp, 0xF0
0000740ecffdd639  vmovaps [rsp], xmm0
0000740ecffdd63e  vmovaps [rsp+0x10], xmm1
0000740ecffdd644  vmovaps [rsp+0x20], xmm2
0000740ecffdd64a  vmovaps [rsp+0x30], xmm3
0000740ecffdd650  vmovaps [rsp+0x40], xmm4
0000740ecffdd656  vmovaps [rsp+0x50], xmm5
0000740ecffdd65c  vmovaps [rsp+0x60], xmm6
0000740ecffdd662  vmovaps [rsp+0x70], xmm7
0000740ecffdd668  vmovaps [rsp+0x80], xmm8
0000740ecffdd671  vmovaps [rsp+0x90], xmm9
0000740ecffdd67a  vmovaps [rsp+0xA0], xmm10
0000740ecffdd683  vmovaps [rsp+0xB0], xmm11
0000740ecffdd68c  vmovaps [rsp+0xC0], xmm12
0000740ecffdd695  vmovaps [rsp+0xD0], xmm13
0000740ecffdd69e  vmovaps [rsp+0xE0], xmm15
0000740ecffdd6a7  sub rsp, 0x30
0000740ecffdd6ab  movaps [rsp], xmm14
0000740ecffdd6b0  movaps [rsp+0x10], xmm4
0000740ecffdd6b5  movaps [rsp+0x20], xmm3
0000740ecffdd6ba  lea rdi, [rsp]
0000740ecffdd6be  mov esi, 0x00
0000740ecffdd6c3  mov rax, 0x5E8249CF1530
0000740ecffdd6cd  call rax
0000740ecffdd6cf  movaps xmm14, [rsp]
0000740ecffdd6d4  add rsp, 0x30
0000740ecffdd6d8  vmovaps xmm0, [rsp]
0000740ecffdd6dd  vmovaps xmm1, [rsp+0x10]
0000740ecffdd6e3  vmovaps xmm2, [rsp+0x20]
0000740ecffdd6e9  vmovaps xmm3, [rsp+0x30]
0000740ecffdd6ef  vmovaps xmm4, [rsp+0x40]
0000740ecffdd6f5  vmovaps xmm5, [rsp+0x50]
0000740ecffdd6fb  vmovaps xmm6, [rsp+0x60]
0000740ecffdd701  vmovaps xmm7, [rsp+0x70]
0000740ecffdd707  vmovaps xmm8, [rsp+0x80]
0000740ecffdd710  vmovaps xmm9, [rsp+0x90]
0000740ecffdd719  vmovaps xmm10, [rsp+0xA0]
0000740ecffdd722  vmovaps xmm11, [rsp+0xB0]
0000740ecffdd72b  vmovaps xmm12, [rsp+0xC0]
0000740ecffdd734  vmovaps xmm13, [rsp+0xD0]
0000740ecffdd73d  vmovaps xmm15, [rsp+0xE0]
0000740ecffdd746  add rsp, 0xF0
0000740ecffdd74d  pop r11
0000740ecffdd74f  pop r10
0000740ecffdd751  pop r9
0000740ecffdd753  pop r8
0000740ecffdd755  pop rsi
0000740ecffdd756  pop rdi
0000740ecffdd757  pop rdx
0000740ecffdd758  pop rcx
0000740ecffdd759  pop rax
0000740ecffdd75a  add rsp, 0x08
0000740ecffdd75e  jmp 0x0000740ECFFDBE42
0000740ecffdd763  sub rsp, 0x08
0000740ecffdd767  push rax
0000740ecffdd768  push rcx
0000740ecffdd769  push rdx
0000740ecffdd76a  push rdi
0000740ecffdd76b  push rsi
0000740ecffdd76c  push r8
0000740ecffdd76e  push r9
0000740ecffdd770  push r10
0000740ecffdd772  push r11
0000740ecffdd774  sub rsp, 0xF0
0000740ecffdd77b  vmovaps [rsp], xmm0
0000740ecffdd780  vmovaps [rsp+0x10], xmm1
0000740ecffdd786  vmovaps [rsp+0x20], xmm2
0000740ecffdd78c  vmovaps [rsp+0x30], xmm3
0000740ecffdd792  vmovaps [rsp+0x40], xmm4
0000740ecffdd798  vmovaps [rsp+0x50], xmm5
0000740ecffdd79e  vmovaps [rsp+0x60], xmm7
0000740ecffdd7a4  vmovaps [rsp+0x70], xmm8
0000740ecffdd7aa  vmovaps [rsp+0x80], xmm9
0000740ecffdd7b3  vmovaps [rsp+0x90], xmm10
0000740ecffdd7bc  vmovaps [rsp+0xA0], xmm11
0000740ecffdd7c5  vmovaps [rsp+0xB0], xmm12
0000740ecffdd7ce  vmovaps [rsp+0xC0], xmm13
0000740ecffdd7d7  vmovaps [rsp+0xD0], xmm14
0000740ecffdd7e0  vmovaps [rsp+0xE0], xmm15
0000740ecffdd7e9  sub rsp, 0x30
0000740ecffdd7ed  movaps [rsp], xmm6
0000740ecffdd7f1  movaps [rsp+0x10], xmm9
0000740ecffdd7f7  movaps [rsp+0x20], xmm7
0000740ecffdd7fc  lea rdi, [rsp]
0000740ecffdd800  mov esi, 0x00
0000740ecffdd805  mov rax, 0x5E8249CF1530
0000740ecffdd80f  call rax
0000740ecffdd811  movaps xmm6, [rsp]
0000740ecffdd815  add rsp, 0x30
0000740ecffdd819  vmovaps xmm0, [rsp]
0000740ecffdd81e  vmovaps xmm1, [rsp+0x10]
0000740ecffdd824  vmovaps xmm2, [rsp+0x20]
0000740ecffdd82a  vmovaps xmm3, [rsp+0x30]
0000740ecffdd830  vmovaps xmm4, [rsp+0x40]
0000740ecffdd836  vmovaps xmm5, [rsp+0x50]
0000740ecffdd83c  vmovaps xmm7, [rsp+0x60]
0000740ecffdd842  vmovaps xmm8, [rsp+0x70]
0000740ecffdd848  vmovaps xmm9, [rsp+0x80]
0000740ecffdd851  vmovaps xmm10, [rsp+0x90]
0000740ecffdd85a  vmovaps xmm11, [rsp+0xA0]
0000740ecffdd863  vmovaps xmm12, [rsp+0xB0]
0000740ecffdd86c  vmovaps xmm13, [rsp+0xC0]
0000740ecffdd875  vmovaps xmm14, [rsp+0xD0]
0000740ecffdd87e  vmovaps xmm15, [rsp+0xE0]
0000740ecffdd887  add rsp, 0xF0
0000740ecffdd88e  pop r11
0000740ecffdd890  pop r10
0000740ecffdd892  pop r9
0000740ecffdd894  pop r8
0000740ecffdd896  pop rsi
0000740ecffdd897  pop rdi
0000740ecffdd898  pop rdx
0000740ecffdd899  pop rcx
0000740ecffdd89a  pop rax
0000740ecffdd89b  add rsp, 0x08
0000740ecffdd89f  jmp 0x0000740ECFFDBE5A
0000740ecffdd8a4  sub rsp, 0x08
0000740ecffdd8a8  push rax
0000740ecffdd8a9  push rcx
0000740ecffdd8aa  push rdx
0000740ecffdd8ab  push rdi
0000740ecffdd8ac  push rsi
0000740ecffdd8ad  push r8
0000740ecffdd8af  push r9
0000740ecffdd8b1  push r10
0000740ecffdd8b3  push r11
0000740ecffdd8b5  sub rsp, 0xF0
0000740ecffdd8bc  vmovaps [rsp], xmm0
0000740ecffdd8c1  vmovaps [rsp+0x10], xmm1
0000740ecffdd8c7  vmovaps [rsp+0x20], xmm2
0000740ecffdd8cd  vmovaps [rsp+0x30], xmm3
0000740ecffdd8d3  vmovaps [rsp+0x40], xmm4
0000740ecffdd8d9  vmovaps [rsp+0x50], xmm5
0000740ecffdd8df  vmovaps [rsp+0x60], xmm6
0000740ecffdd8e5  vmovaps [rsp+0x70], xmm8
0000740ecffdd8eb  vmovaps [rsp+0x80], xmm9
0000740ecffdd8f4  vmovaps [rsp+0x90], xmm10
0000740ecffdd8fd  vmovaps [rsp+0xA0], xmm11
0000740ecffdd906  vmovaps [rsp+0xB0], xmm12
0000740ecffdd90f  vmovaps [rsp+0xC0], xmm13
0000740ecffdd918  vmovaps [rsp+0xD0], xmm14
0000740ecffdd921  vmovaps [rsp+0xE0], xmm15
0000740ecffdd92a  sub rsp, 0x30
0000740ecffdd92e  movaps [rsp], xmm7
0000740ecffdd932  movaps [rsp+0x10], xmm4
0000740ecffdd937  movaps [rsp+0x20], xmm9
0000740ecffdd93d  lea rdi, [rsp]
0000740ecffdd941  mov esi, 0x00
0000740ecffdd946  mov rax, 0x5E8249CF1530
0000740ecffdd950  call rax
0000740ecffdd952  movaps xmm7, [rsp]
0000740ecffdd956  add rsp, 0x30
0000740ecffdd95a  vmovaps xmm0, [rsp]
0000740ecffdd95f  vmovaps xmm1, [rsp+0x10]
0000740ecffdd965  vmovaps xmm2, [rsp+0x20]
0000740ecffdd96b  vmovaps xmm3, [rsp+0x30]
0000740ecffdd971  vmovaps xmm4, [rsp+0x40]
0000740ecffdd977  vmovaps xmm5, [rsp+0x50]
0000740ecffdd97d  vmovaps xmm6, [rsp+0x60]
0000740ecffdd983  vmovaps xmm8, [rsp+0x70]
0000740ecffdd989  vmovaps xmm9, [rsp+0x80]
0000740ecffdd992  vmovaps xmm10, [rsp+0x90]
0000740ecffdd99b  vmovaps xmm11, [rsp+0xA0]
0000740ecffdd9a4  vmovaps xmm12, [rsp+0xB0]
0000740ecffdd9ad  vmovaps xmm13, [rsp+0xC0]
0000740ecffdd9b6  vmovaps xmm14, [rsp+0xD0]
0000740ecffdd9bf  vmovaps xmm15, [rsp+0xE0]
0000740ecffdd9c8  add rsp, 0xF0
0000740ecffdd9cf  pop r11
0000740ecffdd9d1  pop r10
0000740ecffdd9d3  pop r9
0000740ecffdd9d5  pop r8
0000740ecffdd9d7  pop rsi
0000740ecffdd9d8  pop rdi
0000740ecffdd9d9  pop rdx
0000740ecffdd9da  pop rcx
0000740ecffdd9db  pop rax
0000740ecffdd9dc  add rsp, 0x08
0000740ecffdd9e0  jmp 0x0000740ECFFDBE87
0000740ecffdd9e5  sub rsp, 0x08
0000740ecffdd9e9  push rax
0000740ecffdd9ea  push rcx
0000740ecffdd9eb  push rdx
0000740ecffdd9ec  push rdi
0000740ecffdd9ed  push rsi
0000740ecffdd9ee  push r8
0000740ecffdd9f0  push r9
0000740ecffdd9f2  push r10
0000740ecffdd9f4  push r11
0000740ecffdd9f6  sub rsp, 0xF0
0000740ecffdd9fd  vmovaps [rsp], xmm0
0000740ecffdda02  vmovaps [rsp+0x10], xmm1
0000740ecffdda08  vmovaps [rsp+0x20], xmm2
0000740ecffdda0e  vmovaps [rsp+0x30], xmm3
0000740ecffdda14  vmovaps [rsp+0x40], xmm5
0000740ecffdda1a  vmovaps [rsp+0x50], xmm6
0000740ecffdda20  vmovaps [rsp+0x60], xmm7
0000740ecffdda26  vmovaps [rsp+0x70], xmm8
0000740ecffdda2c  vmovaps [rsp+0x80], xmm9
0000740ecffdda35  vmovaps [rsp+0x90], xmm10
0000740ecffdda3e  vmovaps [rsp+0xA0], xmm11
0000740ecffdda47  vmovaps [rsp+0xB0], xmm12
0000740ecffdda50  vmovaps [rsp+0xC0], xmm13
0000740ecffdda59  vmovaps [rsp+0xD0], xmm14
0000740ecffdda62  vmovaps [rsp+0xE0], xmm15
0000740ecffdda6b  sub rsp, 0x30
0000740ecffdda6f  movaps [rsp], xmm4
0000740ecffdda73  movaps [rsp+0x10], xmm15
0000740ecffdda79  movaps [rsp+0x20], xmm9
0000740ecffdda7f  lea rdi, [rsp]
0000740ecffdda83  mov esi, 0x00
0000740ecffdda88  mov rax, 0x5E8249CF1530
0000740ecffdda92  call rax
0000740ecffdda94  movaps xmm4, [rsp]
0000740ecffdda98  add rsp, 0x30
0000740ecffdda9c  vmovaps xmm0, [rsp]
0000740ecffddaa1  vmovaps xmm1, [rsp+0x10]
0000740ecffddaa7  vmovaps xmm2, [rsp+0x20]
0000740ecffddaad  vmovaps xmm3, [rsp+0x30]
0000740ecffddab3  vmovaps xmm5, [rsp+0x40]
0000740ecffddab9  vmovaps xmm6, [rsp+0x50]
0000740ecffddabf  vmovaps xmm7, [rsp+0x60]
0000740ecffddac5  vmovaps xmm8, [rsp+0x70]
0000740ecffddacb  vmovaps xmm9, [rsp+0x80]
0000740ecffddad4  vmovaps xmm10, [rsp+0x90]
0000740ecffddadd  vmovaps xmm11, [rsp+0xA0]
0000740ecffddae6  vmovaps xmm12, [rsp+0xB0]
0000740ecffddaef  vmovaps xmm13, [rsp+0xC0]
0000740ecffddaf8  vmovaps xmm14, [rsp+0xD0]
0000740ecffddb01  vmovaps xmm15, [rsp+0xE0]
0000740ecffddb0a  add rsp, 0xF0
0000740ecffddb11  pop r11
0000740ecffddb13  pop r10
0000740ecffddb15  pop r9
0000740ecffddb17  pop r8
0000740ecffddb19  pop rsi
0000740ecffddb1a  pop rdi
0000740ecffddb1b  pop rdx
0000740ecffddb1c  pop rcx
0000740ecffddb1d  pop rax
0000740ecffddb1e  add rsp, 0x08
0000740ecffddb22  jmp 0x0000740ECFFDBEAC
0000740ecffddb27  call 0x0000740ECFEC4620
0000740ecffddb2c  jmp 0x0000740ECFFDBEB9
0000740ecffddb31  sub rsp, 0x08
0000740ecffddb35  push rax
0000740ecffddb36  push rcx
0000740ecffddb37  push rdx
0000740ecffddb38  push rdi
0000740ecffddb39  push rsi
0000740ecffddb3a  push r8
0000740ecffddb3c  push r9
0000740ecffddb3e  push r10
0000740ecffddb40  push r11
0000740ecffddb42  sub rsp, 0xF0
0000740ecffddb49  vmovaps [rsp], xmm0
0000740ecffddb4e  vmovaps [rsp+0x10], xmm1
0000740ecffddb54  vmovaps [rsp+0x20], xmm2
0000740ecffddb5a  vmovaps [rsp+0x30], xmm4
0000740ecffddb60  vmovaps [rsp+0x40], xmm5
0000740ecffddb66  vmovaps [rsp+0x50], xmm6
0000740ecffddb6c  vmovaps [rsp+0x60], xmm7
0000740ecffddb72  vmovaps [rsp+0x70], xmm8
0000740ecffddb78  vmovaps [rsp+0x80], xmm9
0000740ecffddb81  vmovaps [rsp+0x90], xmm10
0000740ecffddb8a  vmovaps [rsp+0xA0], xmm11
0000740ecffddb93  vmovaps [rsp+0xB0], xmm12
0000740ecffddb9c  vmovaps [rsp+0xC0], xmm13
0000740ecffddba5  vmovaps [rsp+0xD0], xmm14
0000740ecffddbae  vmovaps [rsp+0xE0], xmm15
0000740ecffddbb7  sub rsp, 0x30
0000740ecffddbbb  movaps [rsp], xmm3
0000740ecffddbbf  movaps [rsp+0x10], xmm1
0000740ecffddbc4  movaps [rsp+0x20], xmm9
0000740ecffddbca  lea rdi, [rsp]
0000740ecffddbce  mov esi, 0x00
0000740ecffddbd3  mov rax, 0x5E8249CF1530
0000740ecffddbdd  call rax
0000740ecffddbdf  movaps xmm3, [rsp]
0000740ecffddbe3  add rsp, 0x30
0000740ecffddbe7  vmovaps xmm0, [rsp]
0000740ecffddbec  vmovaps xmm1, [rsp+0x10]
0000740ecffddbf2  vmovaps xmm2, [rsp+0x20]
0000740ecffddbf8  vmovaps xmm4, [rsp+0x30]
0000740ecffddbfe  vmovaps xmm5, [rsp+0x40]
0000740ecffddc04  vmovaps xmm6, [rsp+0x50]
0000740ecffddc0a  vmovaps xmm7, [rsp+0x60]
0000740ecffddc10  vmovaps xmm8, [rsp+0x70]
0000740ecffddc16  vmovaps xmm9, [rsp+0x80]
0000740ecffddc1f  vmovaps xmm10, [rsp+0x90]
0000740ecffddc28  vmovaps xmm11, [rsp+0xA0]
0000740ecffddc31  vmovaps xmm12, [rsp+0xB0]
0000740ecffddc3a  vmovaps xmm13, [rsp+0xC0]
0000740ecffddc43  vmovaps xmm14, [rsp+0xD0]
0000740ecffddc4c  vmovaps xmm15, [rsp+0xE0]
0000740ecffddc55  add rsp, 0xF0
0000740ecffddc5c  pop r11
0000740ecffddc5e  pop r10
0000740ecffddc60  pop r9
0000740ecffddc62  pop r8
0000740ecffddc64  pop rsi
0000740ecffddc65  pop rdi
0000740ecffddc66  pop rdx
0000740ecffddc67  pop rcx
0000740ecffddc68  pop rax
0000740ecffddc69  add rsp, 0x08
0000740ecffddc6d  jmp 0x0000740ECFFDBEF6
0000740ecffddc72  sub rsp, 0x08
0000740ecffddc76  push rax
0000740ecffddc77  push rcx
0000740ecffddc78  push rdx
0000740ecffddc79  push rdi
0000740ecffddc7a  push rsi
0000740ecffddc7b  push r8
0000740ecffddc7d  push r9
0000740ecffddc7f  push r10
0000740ecffddc81  push r11
0000740ecffddc83  sub rsp, 0xF0
0000740ecffddc8a  vmovaps [rsp], xmm0
0000740ecffddc8f  vmovaps [rsp+0x10], xmm2
0000740ecffddc95  vmovaps [rsp+0x20], xmm3
0000740ecffddc9b  vmovaps [rsp+0x30], xmm4
0000740ecffddca1  vmovaps [rsp+0x40], xmm5
0000740ecffddca7  vmovaps [rsp+0x50], xmm6
0000740ecffddcad  vmovaps [rsp+0x60], xmm7
0000740ecffddcb3  vmovaps [rsp+0x70], xmm8
0000740ecffddcb9  vmovaps [rsp+0x80], xmm9
0000740ecffddcc2  vmovaps [rsp+0x90], xmm10
0000740ecffddccb  vmovaps [rsp+0xA0], xmm11
0000740ecffddcd4  vmovaps [rsp+0xB0], xmm12
0000740ecffddcdd  vmovaps [rsp+0xC0], xmm13
0000740ecffddce6  vmovaps [rsp+0xD0], xmm14
0000740ecffddcef  vmovaps [rsp+0xE0], xmm15
0000740ecffddcf8  sub rsp, 0x30
0000740ecffddcfc  movaps [rsp], xmm1
0000740ecffddd00  movaps [rsp+0x10], xmm15
0000740ecffddd06  movaps [rsp+0x20], xmm9
0000740ecffddd0c  lea rdi, [rsp]
0000740ecffddd10  mov esi, 0x00
0000740ecffddd15  mov rax, 0x5E8249CF1530
0000740ecffddd1f  call rax
0000740ecffddd21  movaps xmm1, [rsp]
0000740ecffddd25  add rsp, 0x30
0000740ecffddd29  vmovaps xmm0, [rsp]
0000740ecffddd2e  vmovaps xmm2, [rsp+0x10]
0000740ecffddd34  vmovaps xmm3, [rsp+0x20]
0000740ecffddd3a  vmovaps xmm4, [rsp+0x30]
0000740ecffddd40  vmovaps xmm5, [rsp+0x40]
0000740ecffddd46  vmovaps xmm6, [rsp+0x50]
0000740ecffddd4c  vmovaps xmm7, [rsp+0x60]
0000740ecffddd52  vmovaps xmm8, [rsp+0x70]
0000740ecffddd58  vmovaps xmm9, [rsp+0x80]
0000740ecffddd61  vmovaps xmm10, [rsp+0x90]
0000740ecffddd6a  vmovaps xmm11, [rsp+0xA0]
0000740ecffddd73  vmovaps xmm12, [rsp+0xB0]
0000740ecffddd7c  vmovaps xmm13, [rsp+0xC0]
0000740ecffddd85  vmovaps xmm14, [rsp+0xD0]
0000740ecffddd8e  vmovaps xmm15, [rsp+0xE0]
0000740ecffddd97  add rsp, 0xF0
0000740ecffddd9e  pop r11
0000740ecffddda0  pop r10
0000740ecffddda2  pop r9
0000740ecffddda4  pop r8
0000740ecffddda6  pop rsi
0000740ecffddda7  pop rdi
0000740ecffddda8  pop rdx
0000740ecffddda9  pop rcx
0000740ecffdddaa  pop rax
0000740ecffdddab  add rsp, 0x08
0000740ecffdddaf  jmp 0x0000740ECFFDBF7E
0000740ecffdddb4  call 0x0000740ECFEC4620
0000740ecffdddb9  jmp 0x0000740ECFFDBF8B
0000740ecffdddbe  sub rsp, 0x08
0000740ecffdddc2  push rax
0000740ecffdddc3  push rcx
0000740ecffdddc4  push rdx
0000740ecffdddc5  push rdi
0000740ecffdddc6  push rsi
0000740ecffdddc7  push r8
0000740ecffdddc9  push r9
0000740ecffdddcb  push r10
0000740ecffdddcd  push r11
0000740ecffdddcf  sub rsp, 0xF0
0000740ecffdddd6  vmovaps [rsp], xmm0
0000740ecffddddb  vmovaps [rsp+0x10], xmm2
0000740ecffddde1  vmovaps [rsp+0x20], xmm3
0000740ecffddde7  vmovaps [rsp+0x30], xmm4
0000740ecffddded  vmovaps [rsp+0x40], xmm5
0000740ecffdddf3  vmovaps [rsp+0x50], xmm6
0000740ecffdddf9  vmovaps [rsp+0x60], xmm7
0000740ecffdddff  vmovaps [rsp+0x70], xmm8
0000740ecffdde05  vmovaps [rsp+0x80], xmm9
0000740ecffdde0e  vmovaps [rsp+0x90], xmm10
0000740ecffdde17  vmovaps [rsp+0xA0], xmm11
0000740ecffdde20  vmovaps [rsp+0xB0], xmm12
0000740ecffdde29  vmovaps [rsp+0xC0], xmm13
0000740ecffdde32  vmovaps [rsp+0xD0], xmm14
0000740ecffdde3b  vmovaps [rsp+0xE0], xmm15
0000740ecffdde44  sub rsp, 0x30
0000740ecffdde48  movaps [rsp], xmm1
0000740ecffdde4c  movaps [rsp+0x10], xmm5
0000740ecffdde51  movaps [rsp+0x20], xmm7
0000740ecffdde56  lea rdi, [rsp]
0000740ecffdde5a  mov esi, 0x00
0000740ecffdde5f  mov rax, 0x5E8249CF1530
0000740ecffdde69  call rax
0000740ecffdde6b  movaps xmm1, [rsp]
0000740ecffdde6f  add rsp, 0x30
0000740ecffdde73  vmovaps xmm0, [rsp]
0000740ecffdde78  vmovaps xmm2, [rsp+0x10]
0000740ecffdde7e  vmovaps xmm3, [rsp+0x20]
0000740ecffdde84  vmovaps xmm4, [rsp+0x30]
0000740ecffdde8a  vmovaps xmm5, [rsp+0x40]
0000740ecffdde90  vmovaps xmm6, [rsp+0x50]
0000740ecffdde96  vmovaps xmm7, [rsp+0x60]
0000740ecffdde9c  vmovaps xmm8, [rsp+0x70]
0000740ecffddea2  vmovaps xmm9, [rsp+0x80]
0000740ecffddeab  vmovaps xmm10, [rsp+0x90]
0000740ecffddeb4  vmovaps xmm11, [rsp+0xA0]
0000740ecffddebd  vmovaps xmm12, [rsp+0xB0]
0000740ecffddec6  vmovaps xmm13, [rsp+0xC0]
0000740ecffddecf  vmovaps xmm14, [rsp+0xD0]
0000740ecffdded8  vmovaps xmm15, [rsp+0xE0]
0000740ecffddee1  add rsp, 0xF0
0000740ecffddee8  pop r11
0000740ecffddeea  pop r10
0000740ecffddeec  pop r9
0000740ecffddeee  pop r8
0000740ecffddef0  pop rsi
0000740ecffddef1  pop rdi
0000740ecffddef2  pop rdx
0000740ecffddef3  pop rcx
0000740ecffddef4  pop rax
0000740ecffddef5  add rsp, 0x08
0000740ecffddef9  jmp 0x0000740ECFFDC030
0000740ecffddefe  sub rsp, 0x08
0000740ecffddf02  push rax
0000740ecffddf03  push rcx
0000740ecffddf04  push rdx
0000740ecffddf05  push rdi
0000740ecffddf06  push rsi
0000740ecffddf07  push r8
0000740ecffddf09  push r9
0000740ecffddf0b  push r10
0000740ecffddf0d  push r11
0000740ecffddf0f  sub rsp, 0xF0
0000740ecffddf16  vmovaps [rsp], xmm0
0000740ecffddf1b  vmovaps [rsp+0x10], xmm1
0000740ecffddf21  vmovaps [rsp+0x20], xmm2
0000740ecffddf27  vmovaps [rsp+0x30], xmm3
0000740ecffddf2d  vmovaps [rsp+0x40], xmm4
0000740ecffddf33  vmovaps [rsp+0x50], xmm5
0000740ecffddf39  vmovaps [rsp+0x60], xmm6
0000740ecffddf3f  vmovaps [rsp+0x70], xmm8
0000740ecffddf45  vmovaps [rsp+0x80], xmm9
0000740ecffddf4e  vmovaps [rsp+0x90], xmm10
0000740ecffddf57  vmovaps [rsp+0xA0], xmm11
0000740ecffddf60  vmovaps [rsp+0xB0], xmm12
0000740ecffddf69  vmovaps [rsp+0xC0], xmm13
0000740ecffddf72  vmovaps [rsp+0xD0], xmm14
0000740ecffddf7b  vmovaps [rsp+0xE0], xmm15
0000740ecffddf84  sub rsp, 0x30
0000740ecffddf88  movaps [rsp], xmm7
0000740ecffddf8c  movaps [rsp+0x10], xmm5
0000740ecffddf91  movaps [rsp+0x20], xmm15
0000740ecffddf97  lea rdi, [rsp]
0000740ecffddf9b  mov esi, 0x00
0000740ecffddfa0  mov rax, 0x5E8249CF1530
0000740ecffddfaa  call rax
0000740ecffddfac  movaps xmm7, [rsp]
0000740ecffddfb0  add rsp, 0x30
0000740ecffddfb4  vmovaps xmm0, [rsp]
0000740ecffddfb9  vmovaps xmm1, [rsp+0x10]
0000740ecffddfbf  vmovaps xmm2, [rsp+0x20]
0000740ecffddfc5  vmovaps xmm3, [rsp+0x30]
0000740ecffddfcb  vmovaps xmm4, [rsp+0x40]
0000740ecffddfd1  vmovaps xmm5, [rsp+0x50]
0000740ecffddfd7  vmovaps xmm6, [rsp+0x60]
0000740ecffddfdd  vmovaps xmm8, [rsp+0x70]
0000740ecffddfe3  vmovaps xmm9, [rsp+0x80]
0000740ecffddfec  vmovaps xmm10, [rsp+0x90]
0000740ecffddff5  vmovaps xmm11, [rsp+0xA0]
0000740ecffddffe  vmovaps xmm12, [rsp+0xB0]
0000740ecffde007  vmovaps xmm13, [rsp+0xC0]
0000740ecffde010  vmovaps xmm14, [rsp+0xD0]
0000740ecffde019  vmovaps xmm15, [rsp+0xE0]
0000740ecffde022  add rsp, 0xF0
0000740ecffde029  pop r11
0000740ecffde02b  pop r10
0000740ecffde02d  pop r9
0000740ecffde02f  pop r8
0000740ecffde031  pop rsi
0000740ecffde032  pop rdi
0000740ecffde033  pop rdx
0000740ecffde034  pop rcx
0000740ecffde035  pop rax
0000740ecffde036  add rsp, 0x08
0000740ecffde03a  jmp 0x0000740ECFFDC066
0000740ecffde03f  call 0x0000740ECFEB52F0
0000740ecffde044  jmp 0x0000740ECFFDC073
0000740ecffde049  sub rsp, 0x08
0000740ecffde04d  push rax
0000740ecffde04e  push rcx
0000740ecffde04f  push rdx
0000740ecffde050  push rdi
0000740ecffde051  push rsi
0000740ecffde052  push r8
0000740ecffde054  push r9
0000740ecffde056  push r10
0000740ecffde058  push r11
0000740ecffde05a  sub rsp, 0xF0
0000740ecffde061  vmovaps [rsp], xmm0
0000740ecffde066  vmovaps [rsp+0x10], xmm1
0000740ecffde06c  vmovaps [rsp+0x20], xmm2
0000740ecffde072  vmovaps [rsp+0x30], xmm3
0000740ecffde078  vmovaps [rsp+0x40], xmm4
0000740ecffde07e  vmovaps [rsp+0x50], xmm5
0000740ecffde084  vmovaps [rsp+0x60], xmm6
0000740ecffde08a  vmovaps [rsp+0x70], xmm7
0000740ecffde090  vmovaps [rsp+0x80], xmm8
0000740ecffde099  vmovaps [rsp+0x90], xmm9
0000740ecffde0a2  vmovaps [rsp+0xA0], xmm10
0000740ecffde0ab  vmovaps [rsp+0xB0], xmm11
0000740ecffde0b4  vmovaps [rsp+0xC0], xmm12
0000740ecffde0bd  vmovaps [rsp+0xD0], xmm13
0000740ecffde0c6  vmovaps [rsp+0xE0], xmm14
0000740ecffde0cf  sub rsp, 0x30
0000740ecffde0d3  movaps [rsp], xmm15
0000740ecffde0d8  movaps [rsp+0x10], xmm5
0000740ecffde0dd  movaps [rsp+0x20], xmm3
0000740ecffde0e2  lea rdi, [rsp]
0000740ecffde0e6  mov esi, 0x00
0000740ecffde0eb  mov rax, 0x5E8249CF1530
0000740ecffde0f5  call rax
0000740ecffde0f7  movaps xmm15, [rsp]
0000740ecffde0fc  add rsp, 0x30
0000740ecffde100  vmovaps xmm0, [rsp]
0000740ecffde105  vmovaps xmm1, [rsp+0x10]
0000740ecffde10b  vmovaps xmm2, [rsp+0x20]
0000740ecffde111  vmovaps xmm3, [rsp+0x30]
0000740ecffde117  vmovaps xmm4, [rsp+0x40]
0000740ecffde11d  vmovaps xmm5, [rsp+0x50]
0000740ecffde123  vmovaps xmm6, [rsp+0x60]
0000740ecffde129  vmovaps xmm7, [rsp+0x70]
0000740ecffde12f  vmovaps xmm8, [rsp+0x80]
0000740ecffde138  vmovaps xmm9, [rsp+0x90]
0000740ecffde141  vmovaps xmm10, [rsp+0xA0]
0000740ecffde14a  vmovaps xmm11, [rsp+0xB0]
0000740ecffde153  vmovaps xmm12, [rsp+0xC0]
0000740ecffde15c  vmovaps xmm13, [rsp+0xD0]
0000740ecffde165  vmovaps xmm14, [rsp+0xE0]
0000740ecffde16e  add rsp, 0xF0
0000740ecffde175  pop r11
0000740ecffde177  pop r10
0000740ecffde179  pop r9
0000740ecffde17b  pop r8
0000740ecffde17d  pop rsi
0000740ecffde17e  pop rdi
0000740ecffde17f  pop rdx
0000740ecffde180  pop rcx
0000740ecffde181  pop rax
0000740ecffde182  add rsp, 0x08
0000740ecffde186  jmp 0x0000740ECFFDC099
0000740ecffde18b  sub rsp, 0x08
0000740ecffde18f  push rax
0000740ecffde190  push rcx
0000740ecffde191  push rdx
0000740ecffde192  push rdi
0000740ecffde193  push rsi
0000740ecffde194  push r8
0000740ecffde196  push r9
0000740ecffde198  push r10
0000740ecffde19a  push r11
0000740ecffde19c  sub rsp, 0xF0
0000740ecffde1a3  vmovaps [rsp], xmm0
0000740ecffde1a8  vmovaps [rsp+0x10], xmm2
0000740ecffde1ae  vmovaps [rsp+0x20], xmm3
0000740ecffde1b4  vmovaps [rsp+0x30], xmm4
0000740ecffde1ba  vmovaps [rsp+0x40], xmm5
0000740ecffde1c0  vmovaps [rsp+0x50], xmm6
0000740ecffde1c6  vmovaps [rsp+0x60], xmm7
0000740ecffde1cc  vmovaps [rsp+0x70], xmm8
0000740ecffde1d2  vmovaps [rsp+0x80], xmm9
0000740ecffde1db  vmovaps [rsp+0x90], xmm10
0000740ecffde1e4  vmovaps [rsp+0xA0], xmm11
0000740ecffde1ed  vmovaps [rsp+0xB0], xmm12
0000740ecffde1f6  vmovaps [rsp+0xC0], xmm13
0000740ecffde1ff  vmovaps [rsp+0xD0], xmm14
0000740ecffde208  vmovaps [rsp+0xE0], xmm15
0000740ecffde211  sub rsp, 0x30
0000740ecffde215  movaps [rsp], xmm1
0000740ecffde219  movaps [rsp+0x10], xmm5
0000740ecffde21e  movaps [rsp+0x20], xmm4
0000740ecffde223  lea rdi, [rsp]
0000740ecffde227  mov esi, 0x00
0000740ecffde22c  mov rax, 0x5E8249CF1530
0000740ecffde236  call rax
0000740ecffde238  movaps xmm1, [rsp]
0000740ecffde23c  add rsp, 0x30
0000740ecffde240  vmovaps xmm0, [rsp]
0000740ecffde245  vmovaps xmm2, [rsp+0x10]
0000740ecffde24b  vmovaps xmm3, [rsp+0x20]
0000740ecffde251  vmovaps xmm4, [rsp+0x30]
0000740ecffde257  vmovaps xmm5, [rsp+0x40]
0000740ecffde25d  vmovaps xmm6, [rsp+0x50]
0000740ecffde263  vmovaps xmm7, [rsp+0x60]
0000740ecffde269  vmovaps xmm8, [rsp+0x70]
0000740ecffde26f  vmovaps xmm9, [rsp+0x80]
0000740ecffde278  vmovaps xmm10, [rsp+0x90]
0000740ecffde281  vmovaps xmm11, [rsp+0xA0]
0000740ecffde28a  vmovaps xmm12, [rsp+0xB0]
0000740ecffde293  vmovaps xmm13, [rsp+0xC0]
0000740ecffde29c  vmovaps xmm14, [rsp+0xD0]
0000740ecffde2a5  vmovaps xmm15, [rsp+0xE0]
0000740ecffde2ae  add rsp, 0xF0
0000740ecffde2b5  pop r11
0000740ecffde2b7  pop r10
0000740ecffde2b9  pop r9
0000740ecffde2bb  pop r8
0000740ecffde2bd  pop rsi
0000740ecffde2be  pop rdi
0000740ecffde2bf  pop rdx
0000740ecffde2c0  pop rcx
0000740ecffde2c1  pop rax
0000740ecffde2c2  add rsp, 0x08
0000740ecffde2c6  jmp 0x0000740ECFFDC0B9
0000740ecffde2cb  sub rsp, 0x08
0000740ecffde2cf  push rax
0000740ecffde2d0  push rcx
0000740ecffde2d1  push rdx
0000740ecffde2d2  push rdi
0000740ecffde2d3  push rsi
0000740ecffde2d4  push r8
0000740ecffde2d6  push r9
0000740ecffde2d8  push r10
0000740ecffde2da  push r11
0000740ecffde2dc  sub rsp, 0xF0
0000740ecffde2e3  vmovaps [rsp], xmm0
0000740ecffde2e8  vmovaps [rsp+0x10], xmm1
0000740ecffde2ee  vmovaps [rsp+0x20], xmm2
0000740ecffde2f4  vmovaps [rsp+0x30], xmm3
0000740ecffde2fa  vmovaps [rsp+0x40], xmm5
0000740ecffde300  vmovaps [rsp+0x50], xmm6
0000740ecffde306  vmovaps [rsp+0x60], xmm7
0000740ecffde30c  vmovaps [rsp+0x70], xmm8
0000740ecffde312  vmovaps [rsp+0x80], xmm9
0000740ecffde31b  vmovaps [rsp+0x90], xmm10
0000740ecffde324  vmovaps [rsp+0xA0], xmm11
0000740ecffde32d  vmovaps [rsp+0xB0], xmm12
0000740ecffde336  vmovaps [rsp+0xC0], xmm13
0000740ecffde33f  vmovaps [rsp+0xD0], xmm14
0000740ecffde348  vmovaps [rsp+0xE0], xmm15
0000740ecffde351  sub rsp, 0x30
0000740ecffde355  movaps [rsp], xmm4
0000740ecffde359  movaps [rsp+0x10], xmm3
0000740ecffde35e  movaps [rsp+0x20], xmm5
0000740ecffde363  lea rdi, [rsp]
0000740ecffde367  mov esi, 0x00
0000740ecffde36c  mov rax, 0x5E8249CF1530
0000740ecffde376  call rax
0000740ecffde378  movaps xmm4, [rsp]
0000740ecffde37c  add rsp, 0x30
0000740ecffde380  vmovaps xmm0, [rsp]
0000740ecffde385  vmovaps xmm1, [rsp+0x10]
0000740ecffde38b  vmovaps xmm2, [rsp+0x20]
0000740ecffde391  vmovaps xmm3, [rsp+0x30]
0000740ecffde397  vmovaps xmm5, [rsp+0x40]
0000740ecffde39d  vmovaps xmm6, [rsp+0x50]
0000740ecffde3a3  vmovaps xmm7, [rsp+0x60]
0000740ecffde3a9  vmovaps xmm8, [rsp+0x70]
0000740ecffde3af  vmovaps xmm9, [rsp+0x80]
0000740ecffde3b8  vmovaps xmm10, [rsp+0x90]
0000740ecffde3c1  vmovaps xmm11, [rsp+0xA0]
0000740ecffde3ca  vmovaps xmm12, [rsp+0xB0]
0000740ecffde3d3  vmovaps xmm13, [rsp+0xC0]
0000740ecffde3dc  vmovaps xmm14, [rsp+0xD0]
0000740ecffde3e5  vmovaps xmm15, [rsp+0xE0]
0000740ecffde3ee  add rsp, 0xF0
0000740ecffde3f5  pop r11
0000740ecffde3f7  pop r10
0000740ecffde3f9  pop r9
0000740ecffde3fb  pop r8
0000740ecffde3fd  pop rsi
0000740ecffde3fe  pop rdi
0000740ecffde3ff  pop rdx
0000740ecffde400  pop rcx
0000740ecffde401  pop rax
0000740ecffde402  add rsp, 0x08
0000740ecffde406  jmp 0x0000740ECFFDC107
0000740ecffde40b  call 0x0000740ECFEB52F0
0000740ecffde410  jmp 0x0000740ECFFDC114
0000740ecffde415  sub rsp, 0x08
0000740ecffde419  push rax
0000740ecffde41a  push rcx
0000740ecffde41b  push rdx
0000740ecffde41c  push rdi
0000740ecffde41d  push rsi
0000740ecffde41e  push r8
0000740ecffde420  push r9
0000740ecffde422  push r10
0000740ecffde424  push r11
0000740ecffde426  sub rsp, 0xF0
0000740ecffde42d  vmovaps [rsp], xmm0
0000740ecffde432  vmovaps [rsp+0x10], xmm1
0000740ecffde438  vmovaps [rsp+0x20], xmm2
0000740ecffde43e  vmovaps [rsp+0x30], xmm3
0000740ecffde444  vmovaps [rsp+0x40], xmm4
0000740ecffde44a  vmovaps [rsp+0x50], xmm6
0000740ecffde450  vmovaps [rsp+0x60], xmm7
0000740ecffde456  vmovaps [rsp+0x70], xmm8
0000740ecffde45c  vmovaps [rsp+0x80], xmm9
0000740ecffde465  vmovaps [rsp+0x90], xmm10
0000740ecffde46e  vmovaps [rsp+0xA0], xmm11
0000740ecffde477  vmovaps [rsp+0xB0], xmm12
0000740ecffde480  vmovaps [rsp+0xC0], xmm13
0000740ecffde489  vmovaps [rsp+0xD0], xmm14
0000740ecffde492  vmovaps [rsp+0xE0], xmm15
0000740ecffde49b  sub rsp, 0x30
0000740ecffde49f  movaps [rsp], xmm5
0000740ecffde4a3  movaps [rsp+0x10], xmm6
0000740ecffde4a8  movaps [rsp+0x20], xmm3
0000740ecffde4ad  lea rdi, [rsp]
0000740ecffde4b1  mov esi, 0x00
0000740ecffde4b6  mov rax, 0x5E8249CF1530
0000740ecffde4c0  call rax
0000740ecffde4c2  movaps xmm5, [rsp]
0000740ecffde4c6  add rsp, 0x30
0000740ecffde4ca  vmovaps xmm0, [rsp]
0000740ecffde4cf  vmovaps xmm1, [rsp+0x10]
0000740ecffde4d5  vmovaps xmm2, [rsp+0x20]
0000740ecffde4db  vmovaps xmm3, [rsp+0x30]
0000740ecffde4e1  vmovaps xmm4, [rsp+0x40]
0000740ecffde4e7  vmovaps xmm6, [rsp+0x50]
0000740ecffde4ed  vmovaps xmm7, [rsp+0x60]
0000740ecffde4f3  vmovaps xmm8, [rsp+0x70]
0000740ecffde4f9  vmovaps xmm9, [rsp+0x80]
0000740ecffde502  vmovaps xmm10, [rsp+0x90]
0000740ecffde50b  vmovaps xmm11, [rsp+0xA0]
0000740ecffde514  vmovaps xmm12, [rsp+0xB0]
0000740ecffde51d  vmovaps xmm13, [rsp+0xC0]
0000740ecffde526  vmovaps xmm14, [rsp+0xD0]
0000740ecffde52f  vmovaps xmm15, [rsp+0xE0]
0000740ecffde538  add rsp, 0xF0
0000740ecffde53f  pop r11
0000740ecffde541  pop r10
0000740ecffde543  pop r9
0000740ecffde545  pop r8
0000740ecffde547  pop rsi
0000740ecffde548  pop rdi
0000740ecffde549  pop rdx
0000740ecffde54a  pop rcx
0000740ecffde54b  pop rax
0000740ecffde54c  add rsp, 0x08
0000740ecffde550  jmp 0x0000740ECFFDC13A
0000740ecffde555  sub rsp, 0x08
0000740ecffde559  push rax
0000740ecffde55a  push rcx
0000740ecffde55b  push rdx
0000740ecffde55c  push rdi
0000740ecffde55d  push rsi
0000740ecffde55e  push r8
0000740ecffde560  push r9
0000740ecffde562  push r10
0000740ecffde564  push r11
0000740ecffde566  sub rsp, 0xF0
0000740ecffde56d  vmovaps [rsp], xmm0
0000740ecffde572  vmovaps [rsp+0x10], xmm1
0000740ecffde578  vmovaps [rsp+0x20], xmm2
0000740ecffde57e  vmovaps [rsp+0x30], xmm3
0000740ecffde584  vmovaps [rsp+0x40], xmm4
0000740ecffde58a  vmovaps [rsp+0x50], xmm5
0000740ecffde590  vmovaps [rsp+0x60], xmm7
0000740ecffde596  vmovaps [rsp+0x70], xmm8
0000740ecffde59c  vmovaps [rsp+0x80], xmm9
0000740ecffde5a5  vmovaps [rsp+0x90], xmm10
0000740ecffde5ae  vmovaps [rsp+0xA0], xmm11
0000740ecffde5b7  vmovaps [rsp+0xB0], xmm12
0000740ecffde5c0  vmovaps [rsp+0xC0], xmm13
0000740ecffde5c9  vmovaps [rsp+0xD0], xmm14
0000740ecffde5d2  vmovaps [rsp+0xE0], xmm15
0000740ecffde5db  sub rsp, 0x30
0000740ecffde5df  movaps [rsp], xmm6
0000740ecffde5e3  movaps [rsp+0x10], xmm9
0000740ecffde5e9  movaps [rsp+0x20], xmm1
0000740ecffde5ee  lea rdi, [rsp]
0000740ecffde5f2  mov esi, 0x00
0000740ecffde5f7  mov rax, 0x5E8249CF1530
0000740ecffde601  call rax
0000740ecffde603  movaps xmm6, [rsp]
0000740ecffde607  add rsp, 0x30
0000740ecffde60b  vmovaps xmm0, [rsp]
0000740ecffde610  vmovaps xmm1, [rsp+0x10]
0000740ecffde616  vmovaps xmm2, [rsp+0x20]
0000740ecffde61c  vmovaps xmm3, [rsp+0x30]
0000740ecffde622  vmovaps xmm4, [rsp+0x40]
0000740ecffde628  vmovaps xmm5, [rsp+0x50]
0000740ecffde62e  vmovaps xmm7, [rsp+0x60]
0000740ecffde634  vmovaps xmm8, [rsp+0x70]
0000740ecffde63a  vmovaps xmm9, [rsp+0x80]
0000740ecffde643  vmovaps xmm10, [rsp+0x90]
0000740ecffde64c  vmovaps xmm11, [rsp+0xA0]
0000740ecffde655  vmovaps xmm12, [rsp+0xB0]
0000740ecffde65e  vmovaps xmm13, [rsp+0xC0]
0000740ecffde667  vmovaps xmm14, [rsp+0xD0]
0000740ecffde670  vmovaps xmm15, [rsp+0xE0]
0000740ecffde679  add rsp, 0xF0
0000740ecffde680  pop r11
0000740ecffde682  pop r10
0000740ecffde684  pop r9
0000740ecffde686  pop r8
0000740ecffde688  pop rsi
0000740ecffde689  pop rdi
0000740ecffde68a  pop rdx
0000740ecffde68b  pop rcx
0000740ecffde68c  pop rax
0000740ecffde68d  add rsp, 0x08
0000740ecffde691  jmp 0x0000740ECFFDC15E
0000740ecffde696  sub rsp, 0x08
0000740ecffde69a  push rax
0000740ecffde69b  push rcx
0000740ecffde69c  push rdx
0000740ecffde69d  push rdi
0000740ecffde69e  push rsi
0000740ecffde69f  push r8
0000740ecffde6a1  push r9
0000740ecffde6a3  push r10
0000740ecffde6a5  push r11
0000740ecffde6a7  sub rsp, 0xF0
0000740ecffde6ae  vmovaps [rsp], xmm0
0000740ecffde6b3  vmovaps [rsp+0x10], xmm1
0000740ecffde6b9  vmovaps [rsp+0x20], xmm2
0000740ecffde6bf  vmovaps [rsp+0x30], xmm3
0000740ecffde6c5  vmovaps [rsp+0x40], xmm4
0000740ecffde6cb  vmovaps [rsp+0x50], xmm5
0000740ecffde6d1  vmovaps [rsp+0x60], xmm6
0000740ecffde6d7  vmovaps [rsp+0x70], xmm7
0000740ecffde6dd  vmovaps [rsp+0x80], xmm8
0000740ecffde6e6  vmovaps [rsp+0x90], xmm10
0000740ecffde6ef  vmovaps [rsp+0xA0], xmm11
0000740ecffde6f8  vmovaps [rsp+0xB0], xmm12
0000740ecffde701  vmovaps [rsp+0xC0], xmm13
0000740ecffde70a  vmovaps [rsp+0xD0], xmm14
0000740ecffde713  vmovaps [rsp+0xE0], xmm15
0000740ecffde71c  sub rsp, 0x30
0000740ecffde720  movaps [rsp], xmm9
0000740ecffde725  movaps [rsp+0x10], xmm3
0000740ecffde72a  movaps [rsp+0x20], xmm1
0000740ecffde72f  lea rdi, [rsp]
0000740ecffde733  mov esi, 0x00
0000740ecffde738  mov rax, 0x5E8249CF1530
0000740ecffde742  call rax
0000740ecffde744  movaps xmm9, [rsp]
0000740ecffde749  add rsp, 0x30
0000740ecffde74d  vmovaps xmm0, [rsp]
0000740ecffde752  vmovaps xmm1, [rsp+0x10]
0000740ecffde758  vmovaps xmm2, [rsp+0x20]
0000740ecffde75e  vmovaps xmm3, [rsp+0x30]
0000740ecffde764  vmovaps xmm4, [rsp+0x40]
0000740ecffde76a  vmovaps xmm5, [rsp+0x50]
0000740ecffde770  vmovaps xmm6, [rsp+0x60]
0000740ecffde776  vmovaps xmm7, [rsp+0x70]
0000740ecffde77c  vmovaps xmm8, [rsp+0x80]
0000740ecffde785  vmovaps xmm10, [rsp+0x90]
0000740ecffde78e  vmovaps xmm11, [rsp+0xA0]
0000740ecffde797  vmovaps xmm12, [rsp+0xB0]
0000740ecffde7a0  vmovaps xmm13, [rsp+0xC0]
0000740ecffde7a9  vmovaps xmm14, [rsp+0xD0]
0000740ecffde7b2  vmovaps xmm15, [rsp+0xE0]
0000740ecffde7bb  add rsp, 0xF0
0000740ecffde7c2  pop r11
0000740ecffde7c4  pop r10
0000740ecffde7c6  pop r9
0000740ecffde7c8  pop r8
0000740ecffde7ca  pop rsi
0000740ecffde7cb  pop rdi
0000740ecffde7cc  pop rdx
0000740ecffde7cd  pop rcx
0000740ecffde7ce  pop rax
0000740ecffde7cf  add rsp, 0x08
0000740ecffde7d3  jmp 0x0000740ECFFDC1AA
0000740ecffde7d8  call 0x0000740ECFEB52F0
0000740ecffde7dd  jmp 0x0000740ECFFDC1B7
0000740ecffde7e2  sub rsp, 0x08
0000740ecffde7e6  push rax
0000740ecffde7e7  push rcx
0000740ecffde7e8  push rdx
0000740ecffde7e9  push rdi
0000740ecffde7ea  push rsi
0000740ecffde7eb  push r8
0000740ecffde7ed  push r9
0000740ecffde7ef  push r10
0000740ecffde7f1  push r11
0000740ecffde7f3  sub rsp, 0xF0
0000740ecffde7fa  vmovaps [rsp], xmm0
0000740ecffde7ff  vmovaps [rsp+0x10], xmm1
0000740ecffde805  vmovaps [rsp+0x20], xmm2
0000740ecffde80b  vmovaps [rsp+0x30], xmm3
0000740ecffde811  vmovaps [rsp+0x40], xmm4
0000740ecffde817  vmovaps [rsp+0x50], xmm5
0000740ecffde81d  vmovaps [rsp+0x60], xmm6
0000740ecffde823  vmovaps [rsp+0x70], xmm7
0000740ecffde829  vmovaps [rsp+0x80], xmm8
0000740ecffde832  vmovaps [rsp+0x90], xmm9
0000740ecffde83b  vmovaps [rsp+0xA0], xmm10
0000740ecffde844  vmovaps [rsp+0xB0], xmm11
0000740ecffde84d  vmovaps [rsp+0xC0], xmm12
0000740ecffde856  vmovaps [rsp+0xD0], xmm13
0000740ecffde85f  vmovaps [rsp+0xE0], xmm14
0000740ecffde868  sub rsp, 0x30
0000740ecffde86c  movaps [rsp], xmm15
0000740ecffde871  movaps [rsp+0x10], xmm3
0000740ecffde876  movaps [rsp+0x20], xmm7
0000740ecffde87b  lea rdi, [rsp]
0000740ecffde87f  mov esi, 0x00
0000740ecffde884  mov rax, 0x5E8249CF1530
0000740ecffde88e  call rax
0000740ecffde890  movaps xmm15, [rsp]
0000740ecffde895  add rsp, 0x30
0000740ecffde899  vmovaps xmm0, [rsp]
0000740ecffde89e  vmovaps xmm1, [rsp+0x10]
0000740ecffde8a4  vmovaps xmm2, [rsp+0x20]
0000740ecffde8aa  vmovaps xmm3, [rsp+0x30]
0000740ecffde8b0  vmovaps xmm4, [rsp+0x40]
0000740ecffde8b6  vmovaps xmm5, [rsp+0x50]
0000740ecffde8bc  vmovaps xmm6, [rsp+0x60]
0000740ecffde8c2  vmovaps xmm7, [rsp+0x70]
0000740ecffde8c8  vmovaps xmm8, [rsp+0x80]
0000740ecffde8d1  vmovaps xmm9, [rsp+0x90]
0000740ecffde8da  vmovaps xmm10, [rsp+0xA0]
0000740ecffde8e3  vmovaps xmm11, [rsp+0xB0]
0000740ecffde8ec  vmovaps xmm12, [rsp+0xC0]
0000740ecffde8f5  vmovaps xmm13, [rsp+0xD0]
0000740ecffde8fe  vmovaps xmm14, [rsp+0xE0]
0000740ecffde907  add rsp, 0xF0
0000740ecffde90e  pop r11
0000740ecffde910  pop r10
0000740ecffde912  pop r9
0000740ecffde914  pop r8
0000740ecffde916  pop rsi
0000740ecffde917  pop rdi
0000740ecffde918  pop rdx
0000740ecffde919  pop rcx
0000740ecffde91a  pop rax
0000740ecffde91b  add rsp, 0x08
0000740ecffde91f  jmp 0x0000740ECFFDC1E3
0000740ecffde924  sub rsp, 0x08
0000740ecffde928  push rax
0000740ecffde929  push rcx
0000740ecffde92a  push rdx
0000740ecffde92b  push rdi
0000740ecffde92c  push rsi
0000740ecffde92d  push r8
0000740ecffde92f  push r9
0000740ecffde931  push r10
0000740ecffde933  push r11
0000740ecffde935  sub rsp, 0xF0
0000740ecffde93c  vmovaps [rsp], xmm0
0000740ecffde941  vmovaps [rsp+0x10], xmm1
0000740ecffde947  vmovaps [rsp+0x20], xmm2
0000740ecffde94d  vmovaps [rsp+0x30], xmm4
0000740ecffde953  vmovaps [rsp+0x40], xmm5
0000740ecffde959  vmovaps [rsp+0x50], xmm6
0000740ecffde95f  vmovaps [rsp+0x60], xmm7
0000740ecffde965  vmovaps [rsp+0x70], xmm8
0000740ecffde96b  vmovaps [rsp+0x80], xmm9
0000740ecffde974  vmovaps [rsp+0x90], xmm10
0000740ecffde97d  vmovaps [rsp+0xA0], xmm11
0000740ecffde986  vmovaps [rsp+0xB0], xmm12
0000740ecffde98f  vmovaps [rsp+0xC0], xmm13
0000740ecffde998  vmovaps [rsp+0xD0], xmm14
0000740ecffde9a1  vmovaps [rsp+0xE0], xmm15
0000740ecffde9aa  sub rsp, 0x30
0000740ecffde9ae  movaps [rsp], xmm3
0000740ecffde9b2  movaps [rsp+0x10], xmm1
0000740ecffde9b7  movaps [rsp+0x20], xmm15
0000740ecffde9bd  lea rdi, [rsp]
0000740ecffde9c1  mov esi, 0x00
0000740ecffde9c6  mov rax, 0x5E8249CF1530
0000740ecffde9d0  call rax
0000740ecffde9d2  movaps xmm3, [rsp]
0000740ecffde9d6  add rsp, 0x30
0000740ecffde9da  vmovaps xmm0, [rsp]
0000740ecffde9df  vmovaps xmm1, [rsp+0x10]
0000740ecffde9e5  vmovaps xmm2, [rsp+0x20]
0000740ecffde9eb  vmovaps xmm4, [rsp+0x30]
0000740ecffde9f1  vmovaps xmm5, [rsp+0x40]
0000740ecffde9f7  vmovaps xmm6, [rsp+0x50]
0000740ecffde9fd  vmovaps xmm7, [rsp+0x60]
0000740ecffdea03  vmovaps xmm8, [rsp+0x70]
0000740ecffdea09  vmovaps xmm9, [rsp+0x80]
0000740ecffdea12  vmovaps xmm10, [rsp+0x90]
0000740ecffdea1b  vmovaps xmm11, [rsp+0xA0]
0000740ecffdea24  vmovaps xmm12, [rsp+0xB0]
0000740ecffdea2d  vmovaps xmm13, [rsp+0xC0]
0000740ecffdea36  vmovaps xmm14, [rsp+0xD0]
0000740ecffdea3f  vmovaps xmm15, [rsp+0xE0]
0000740ecffdea48  add rsp, 0xF0
0000740ecffdea4f  pop r11
0000740ecffdea51  pop r10
0000740ecffdea53  pop r9
0000740ecffdea55  pop r8
0000740ecffdea57  pop rsi
0000740ecffdea58  pop rdi
0000740ecffdea59  pop rdx
0000740ecffdea5a  pop rcx
0000740ecffdea5b  pop rax
0000740ecffdea5c  add rsp, 0x08
0000740ecffdea60  jmp 0x0000740ECFFDC272
0000740ecffdea65  call 0x0000740ECFEB52F0
0000740ecffdea6a  jmp 0x0000740ECFFDC27C
0000740ecffdea6f  sub rsp, 0x08
0000740ecffdea73  push rax
0000740ecffdea74  push rcx
0000740ecffdea75  push rdx
0000740ecffdea76  push rdi
0000740ecffdea77  push rsi
0000740ecffdea78  push r8
0000740ecffdea7a  push r9
0000740ecffdea7c  push r10
0000740ecffdea7e  push r11
0000740ecffdea80  sub rsp, 0xF0
0000740ecffdea87  vmovaps [rsp], xmm0
0000740ecffdea8c  vmovaps [rsp+0x10], xmm1
0000740ecffdea92  vmovaps [rsp+0x20], xmm2
0000740ecffdea98  vmovaps [rsp+0x30], xmm3
0000740ecffdea9e  vmovaps [rsp+0x40], xmm4
0000740ecffdeaa4  vmovaps [rsp+0x50], xmm5
0000740ecffdeaaa  vmovaps [rsp+0x60], xmm6
0000740ecffdeab0  vmovaps [rsp+0x70], xmm7
0000740ecffdeab6  vmovaps [rsp+0x80], xmm8
0000740ecffdeabf  vmovaps [rsp+0x90], xmm9
0000740ecffdeac8  vmovaps [rsp+0xA0], xmm10
0000740ecffdead1  vmovaps [rsp+0xB0], xmm11
0000740ecffdeada  vmovaps [rsp+0xC0], xmm12
0000740ecffdeae3  vmovaps [rsp+0xD0], xmm13
0000740ecffdeaec  vmovaps [rsp+0xE0], xmm14
0000740ecffdeaf5  sub rsp, 0x30
0000740ecffdeaf9  movaps [rsp], xmm15
0000740ecffdeafe  movaps [rsp+0x10], xmm14
0000740ecffdeb04  movaps [rsp+0x20], xmm4
0000740ecffdeb09  lea rdi, [rsp]
0000740ecffdeb0d  mov esi, 0x00
0000740ecffdeb12  mov rax, 0x5E8249CF1530
0000740ecffdeb1c  call rax
0000740ecffdeb1e  movaps xmm15, [rsp]
0000740ecffdeb23  add rsp, 0x30
0000740ecffdeb27  vmovaps xmm0, [rsp]
0000740ecffdeb2c  vmovaps xmm1, [rsp+0x10]
0000740ecffdeb32  vmovaps xmm2, [rsp+0x20]
0000740ecffdeb38  vmovaps xmm3, [rsp+0x30]
0000740ecffdeb3e  vmovaps xmm4, [rsp+0x40]
0000740ecffdeb44  vmovaps xmm5, [rsp+0x50]
0000740ecffdeb4a  vmovaps xmm6, [rsp+0x60]
0000740ecffdeb50  vmovaps xmm7, [rsp+0x70]
0000740ecffdeb56  vmovaps xmm8, [rsp+0x80]
0000740ecffdeb5f  vmovaps xmm9, [rsp+0x90]
0000740ecffdeb68  vmovaps xmm10, [rsp+0xA0]
0000740ecffdeb71  vmovaps xmm11, [rsp+0xB0]
0000740ecffdeb7a  vmovaps xmm12, [rsp+0xC0]
0000740ecffdeb83  vmovaps xmm13, [rsp+0xD0]
0000740ecffdeb8c  vmovaps xmm14, [rsp+0xE0]
0000740ecffdeb95  add rsp, 0xF0
0000740ecffdeb9c  pop r11
0000740ecffdeb9e  pop r10
0000740ecffdeba0  pop r9
0000740ecffdeba2  pop r8
0000740ecffdeba4  pop rsi
0000740ecffdeba5  pop rdi
0000740ecffdeba6  pop rdx
0000740ecffdeba7  pop rcx
0000740ecffdeba8  pop rax
0000740ecffdeba9  add rsp, 0x08
0000740ecffdebad  jmp 0x0000740ECFFDC2AA
0000740ecffdebb2  sub rsp, 0x08
0000740ecffdebb6  push rax
0000740ecffdebb7  push rcx
0000740ecffdebb8  push rdx
0000740ecffdebb9  push rdi
0000740ecffdebba  push rsi
0000740ecffdebbb  push r8
0000740ecffdebbd  push r9
0000740ecffdebbf  push r10
0000740ecffdebc1  push r11
0000740ecffdebc3  sub rsp, 0xF0
0000740ecffdebca  vmovaps [rsp], xmm0
0000740ecffdebcf  vmovaps [rsp+0x10], xmm1
0000740ecffdebd5  vmovaps [rsp+0x20], xmm2
0000740ecffdebdb  vmovaps [rsp+0x30], xmm3
0000740ecffdebe1  vmovaps [rsp+0x40], xmm4
0000740ecffdebe7  vmovaps [rsp+0x50], xmm5
0000740ecffdebed  vmovaps [rsp+0x60], xmm6
0000740ecffdebf3  vmovaps [rsp+0x70], xmm7
0000740ecffdebf9  vmovaps [rsp+0x80], xmm8
0000740ecffdec02  vmovaps [rsp+0x90], xmm9
0000740ecffdec0b  vmovaps [rsp+0xA0], xmm10
0000740ecffdec14  vmovaps [rsp+0xB0], xmm11
0000740ecffdec1d  vmovaps [rsp+0xC0], xmm12
0000740ecffdec26  vmovaps [rsp+0xD0], xmm13
0000740ecffdec2f  vmovaps [rsp+0xE0], xmm15
0000740ecffdec38  sub rsp, 0x30
0000740ecffdec3c  movaps [rsp], xmm14
0000740ecffdec41  movaps [rsp+0x10], xmm2
0000740ecffdec46  movaps [rsp+0x20], xmm1
0000740ecffdec4b  lea rdi, [rsp]
0000740ecffdec4f  mov esi, 0x00
0000740ecffdec54  mov rax, 0x5E8249CF1530
0000740ecffdec5e  call rax
0000740ecffdec60  movaps xmm14, [rsp]
0000740ecffdec65  add rsp, 0x30
0000740ecffdec69  vmovaps xmm0, [rsp]
0000740ecffdec6e  vmovaps xmm1, [rsp+0x10]
0000740ecffdec74  vmovaps xmm2, [rsp+0x20]
0000740ecffdec7a  vmovaps xmm3, [rsp+0x30]
0000740ecffdec80  vmovaps xmm4, [rsp+0x40]
0000740ecffdec86  vmovaps xmm5, [rsp+0x50]
0000740ecffdec8c  vmovaps xmm6, [rsp+0x60]
0000740ecffdec92  vmovaps xmm7, [rsp+0x70]
0000740ecffdec98  vmovaps xmm8, [rsp+0x80]
0000740ecffdeca1  vmovaps xmm9, [rsp+0x90]
0000740ecffdecaa  vmovaps xmm10, [rsp+0xA0]
0000740ecffdecb3  vmovaps xmm11, [rsp+0xB0]
0000740ecffdecbc  vmovaps xmm12, [rsp+0xC0]
0000740ecffdecc5  vmovaps xmm13, [rsp+0xD0]
0000740ecffdecce  vmovaps xmm15, [rsp+0xE0]
0000740ecffdecd7  add rsp, 0xF0
0000740ecffdecde  pop r11
0000740ecffdece0  pop r10
0000740ecffdece2  pop r9
0000740ecffdece4  pop r8
0000740ecffdece6  pop rsi
0000740ecffdece7  pop rdi
0000740ecffdece8  pop rdx
0000740ecffdece9  pop rcx
0000740ecffdecea  pop rax
0000740ecffdeceb  add rsp, 0x08
0000740ecffdecef  jmp 0x0000740ECFFDC2D0
0000740ecffdecf4  sub rsp, 0x08
0000740ecffdecf8  push rax
0000740ecffdecf9  push rcx
0000740ecffdecfa  push rdx
0000740ecffdecfb  push rdi
0000740ecffdecfc  push rsi
0000740ecffdecfd  push r8
0000740ecffdecff  push r9
0000740ecffded01  push r10
0000740ecffded03  push r11
0000740ecffded05  sub rsp, 0xF0
0000740ecffded0c  vmovaps [rsp], xmm0
0000740ecffded11  vmovaps [rsp+0x10], xmm2
0000740ecffded17  vmovaps [rsp+0x20], xmm3
0000740ecffded1d  vmovaps [rsp+0x30], xmm4
0000740ecffded23  vmovaps [rsp+0x40], xmm5
0000740ecffded29  vmovaps [rsp+0x50], xmm6
0000740ecffded2f  vmovaps [rsp+0x60], xmm7
0000740ecffded35  vmovaps [rsp+0x70], xmm8
0000740ecffded3b  vmovaps [rsp+0x80], xmm9
0000740ecffded44  vmovaps [rsp+0x90], xmm10
0000740ecffded4d  vmovaps [rsp+0xA0], xmm11
0000740ecffded56  vmovaps [rsp+0xB0], xmm12
0000740ecffded5f  vmovaps [rsp+0xC0], xmm13
0000740ecffded68  vmovaps [rsp+0xD0], xmm14
0000740ecffded71  vmovaps [rsp+0xE0], xmm15
0000740ecffded7a  sub rsp, 0x30
0000740ecffded7e  movaps [rsp], xmm1
0000740ecffded82  movaps [rsp+0x10], xmm4
0000740ecffded87  movaps [rsp+0x20], xmm9
0000740ecffded8d  lea rdi, [rsp]
0000740ecffded91  mov esi, 0x00
0000740ecffded96  mov rax, 0x5E8249CF1530
0000740ecffdeda0  call rax
0000740ecffdeda2  movaps xmm1, [rsp]
0000740ecffdeda6  add rsp, 0x30
0000740ecffdedaa  vmovaps xmm0, [rsp]
0000740ecffdedaf  vmovaps xmm2, [rsp+0x10]
0000740ecffdedb5  vmovaps xmm3, [rsp+0x20]
0000740ecffdedbb  vmovaps xmm4, [rsp+0x30]
0000740ecffdedc1  vmovaps xmm5, [rsp+0x40]
0000740ecffdedc7  vmovaps xmm6, [rsp+0x50]
0000740ecffdedcd  vmovaps xmm7, [rsp+0x60]
0000740ecffdedd3  vmovaps xmm8, [rsp+0x70]
0000740ecffdedd9  vmovaps xmm9, [rsp+0x80]
0000740ecffdede2  vmovaps xmm10, [rsp+0x90]
0000740ecffdedeb  vmovaps xmm11, [rsp+0xA0]
0000740ecffdedf4  vmovaps xmm12, [rsp+0xB0]
0000740ecffdedfd  vmovaps xmm13, [rsp+0xC0]
0000740ecffdee06  vmovaps xmm14, [rsp+0xD0]
0000740ecffdee0f  vmovaps xmm15, [rsp+0xE0]
0000740ecffdee18  add rsp, 0xF0
0000740ecffdee1f  pop r11
0000740ecffdee21  pop r10
0000740ecffdee23  pop r9
0000740ecffdee25  pop r8
0000740ecffdee27  pop rsi
0000740ecffdee28  pop rdi
0000740ecffdee29  pop rdx
0000740ecffdee2a  pop rcx
0000740ecffdee2b  pop rax
0000740ecffdee2c  add rsp, 0x08
0000740ecffdee30  jmp 0x0000740ECFFDC2EE
0000740ecffdee35  sub rsp, 0x08
0000740ecffdee39  push rax
0000740ecffdee3a  push rcx
0000740ecffdee3b  push rdx
0000740ecffdee3c  push rdi
0000740ecffdee3d  push rsi
0000740ecffdee3e  push r8
0000740ecffdee40  push r9
0000740ecffdee42  push r10
0000740ecffdee44  push r11
0000740ecffdee46  sub rsp, 0xF0
0000740ecffdee4d  vmovaps [rsp], xmm0
0000740ecffdee52  vmovaps [rsp+0x10], xmm1
0000740ecffdee58  vmovaps [rsp+0x20], xmm2
0000740ecffdee5e  vmovaps [rsp+0x30], xmm3
0000740ecffdee64  vmovaps [rsp+0x40], xmm5
0000740ecffdee6a  vmovaps [rsp+0x50], xmm6
0000740ecffdee70  vmovaps [rsp+0x60], xmm7
0000740ecffdee76  vmovaps [rsp+0x70], xmm8
0000740ecffdee7c  vmovaps [rsp+0x80], xmm9
0000740ecffdee85  vmovaps [rsp+0x90], xmm10
0000740ecffdee8e  vmovaps [rsp+0xA0], xmm11
0000740ecffdee97  vmovaps [rsp+0xB0], xmm12
0000740ecffdeea0  vmovaps [rsp+0xC0], xmm13
0000740ecffdeea9  vmovaps [rsp+0xD0], xmm14
0000740ecffdeeb2  vmovaps [rsp+0xE0], xmm15
0000740ecffdeebb  sub rsp, 0x30
0000740ecffdeebf  movaps [rsp], xmm4
0000740ecffdeec3  movaps [rsp+0x10], xmm2
0000740ecffdeec8  movaps [rsp+0x20], xmm9
0000740ecffdeece  lea rdi, [rsp]
0000740ecffdeed2  mov esi, 0x00
0000740ecffdeed7  mov rax, 0x5E8249CF1530
0000740ecffdeee1  call rax
0000740ecffdeee3  movaps xmm4, [rsp]
0000740ecffdeee7  add rsp, 0x30
0000740ecffdeeeb  vmovaps xmm0, [rsp]
0000740ecffdeef0  vmovaps xmm1, [rsp+0x10]
0000740ecffdeef6  vmovaps xmm2, [rsp+0x20]
0000740ecffdeefc  vmovaps xmm3, [rsp+0x30]
0000740ecffdef02  vmovaps xmm5, [rsp+0x40]
0000740ecffdef08  vmovaps xmm6, [rsp+0x50]
0000740ecffdef0e  vmovaps xmm7, [rsp+0x60]
0000740ecffdef14  vmovaps xmm8, [rsp+0x70]
0000740ecffdef1a  vmovaps xmm9, [rsp+0x80]
0000740ecffdef23  vmovaps xmm10, [rsp+0x90]
0000740ecffdef2c  vmovaps xmm11, [rsp+0xA0]
0000740ecffdef35  vmovaps xmm12, [rsp+0xB0]
0000740ecffdef3e  vmovaps xmm13, [rsp+0xC0]
0000740ecffdef47  vmovaps xmm14, [rsp+0xD0]
0000740ecffdef50  vmovaps xmm15, [rsp+0xE0]
0000740ecffdef59  add rsp, 0xF0
0000740ecffdef60  pop r11
0000740ecffdef62  pop r10
0000740ecffdef64  pop r9
0000740ecffdef66  pop r8
0000740ecffdef68  pop rsi
0000740ecffdef69  pop rdi
0000740ecffdef6a  pop rdx
0000740ecffdef6b  pop rcx
0000740ecffdef6c  pop rax
0000740ecffdef6d  add rsp, 0x08
0000740ecffdef71  jmp 0x0000740ECFFDC31E
0000740ecffdef76  sub rsp, 0x08
0000740ecffdef7a  push rax
0000740ecffdef7b  push rcx
0000740ecffdef7c  push rdx
0000740ecffdef7d  push rdi
0000740ecffdef7e  push rsi
0000740ecffdef7f  push r8
0000740ecffdef81  push r9
0000740ecffdef83  push r10
0000740ecffdef85  push r11
0000740ecffdef87  sub rsp, 0xF0
0000740ecffdef8e  vmovaps [rsp], xmm0
0000740ecffdef93  vmovaps [rsp+0x10], xmm1
0000740ecffdef99  vmovaps [rsp+0x20], xmm2
0000740ecffdef9f  vmovaps [rsp+0x30], xmm3
0000740ecffdefa5  vmovaps [rsp+0x40], xmm4
0000740ecffdefab  vmovaps [rsp+0x50], xmm5
0000740ecffdefb1  vmovaps [rsp+0x60], xmm6
0000740ecffdefb7  vmovaps [rsp+0x70], xmm7
0000740ecffdefbd  vmovaps [rsp+0x80], xmm8
0000740ecffdefc6  vmovaps [rsp+0x90], xmm10
0000740ecffdefcf  vmovaps [rsp+0xA0], xmm11
0000740ecffdefd8  vmovaps [rsp+0xB0], xmm12
0000740ecffdefe1  vmovaps [rsp+0xC0], xmm13
0000740ecffdefea  vmovaps [rsp+0xD0], xmm14
0000740ecffdeff3  vmovaps [rsp+0xE0], xmm15
0000740ecffdeffc  sub rsp, 0x30
0000740ecffdf000  movaps [rsp], xmm9
0000740ecffdf005  movaps [rsp+0x10], xmm2
0000740ecffdf00a  movaps [rsp+0x20], xmm1
0000740ecffdf00f  lea rdi, [rsp]
0000740ecffdf013  mov esi, 0x00
0000740ecffdf018  mov rax, 0x5E8249CF1530
0000740ecffdf022  call rax
0000740ecffdf024  movaps xmm9, [rsp]
0000740ecffdf029  add rsp, 0x30
0000740ecffdf02d  vmovaps xmm0, [rsp]
0000740ecffdf032  vmovaps xmm1, [rsp+0x10]
0000740ecffdf038  vmovaps xmm2, [rsp+0x20]
0000740ecffdf03e  vmovaps xmm3, [rsp+0x30]
0000740ecffdf044  vmovaps xmm4, [rsp+0x40]
0000740ecffdf04a  vmovaps xmm5, [rsp+0x50]
0000740ecffdf050  vmovaps xmm6, [rsp+0x60]
0000740ecffdf056  vmovaps xmm7, [rsp+0x70]
0000740ecffdf05c  vmovaps xmm8, [rsp+0x80]
0000740ecffdf065  vmovaps xmm10, [rsp+0x90]
0000740ecffdf06e  vmovaps xmm11, [rsp+0xA0]
0000740ecffdf077  vmovaps xmm12, [rsp+0xB0]
0000740ecffdf080  vmovaps xmm13, [rsp+0xC0]
0000740ecffdf089  vmovaps xmm14, [rsp+0xD0]
0000740ecffdf092  vmovaps xmm15, [rsp+0xE0]
0000740ecffdf09b  add rsp, 0xF0
0000740ecffdf0a2  pop r11
0000740ecffdf0a4  pop r10
0000740ecffdf0a6  pop r9
0000740ecffdf0a8  pop r8
0000740ecffdf0aa  pop rsi
0000740ecffdf0ab  pop rdi
0000740ecffdf0ac  pop rdx
0000740ecffdf0ad  pop rcx
0000740ecffdf0ae  pop rax
0000740ecffdf0af  add rsp, 0x08
0000740ecffdf0b3  jmp 0x0000740ECFFDC354
0000740ecffdf0b8  sub rsp, 0x08
0000740ecffdf0bc  push rax
0000740ecffdf0bd  push rcx
0000740ecffdf0be  push rdx
0000740ecffdf0bf  push rdi
0000740ecffdf0c0  push rsi
0000740ecffdf0c1  push r8
0000740ecffdf0c3  push r9
0000740ecffdf0c5  push r10
0000740ecffdf0c7  push r11
0000740ecffdf0c9  sub rsp, 0xF0
0000740ecffdf0d0  vmovaps [rsp], xmm0
0000740ecffdf0d5  vmovaps [rsp+0x10], xmm2
0000740ecffdf0db  vmovaps [rsp+0x20], xmm3
0000740ecffdf0e1  vmovaps [rsp+0x30], xmm4
0000740ecffdf0e7  vmovaps [rsp+0x40], xmm5
0000740ecffdf0ed  vmovaps [rsp+0x50], xmm6
0000740ecffdf0f3  vmovaps [rsp+0x60], xmm7
0000740ecffdf0f9  vmovaps [rsp+0x70], xmm8
0000740ecffdf0ff  vmovaps [rsp+0x80], xmm9
0000740ecffdf108  vmovaps [rsp+0x90], xmm10
0000740ecffdf111  vmovaps [rsp+0xA0], xmm11
0000740ecffdf11a  vmovaps [rsp+0xB0], xmm12
0000740ecffdf123  vmovaps [rsp+0xC0], xmm13
0000740ecffdf12c  vmovaps [rsp+0xD0], xmm14
0000740ecffdf135  vmovaps [rsp+0xE0], xmm15
0000740ecffdf13e  sub rsp, 0x30
0000740ecffdf142  movaps [rsp], xmm1
0000740ecffdf146  movaps [rsp+0x10], xmm15
0000740ecffdf14c  movaps [rsp+0x20], xmm6
0000740ecffdf151  lea rdi, [rsp]
0000740ecffdf155  mov esi, 0x00
0000740ecffdf15a  mov rax, 0x5E8249CF1530
0000740ecffdf164  call rax
0000740ecffdf166  movaps xmm1, [rsp]
0000740ecffdf16a  add rsp, 0x30
0000740ecffdf16e  vmovaps xmm0, [rsp]
0000740ecffdf173  vmovaps xmm2, [rsp+0x10]
0000740ecffdf179  vmovaps xmm3, [rsp+0x20]
0000740ecffdf17f  vmovaps xmm4, [rsp+0x30]
0000740ecffdf185  vmovaps xmm5, [rsp+0x40]
0000740ecffdf18b  vmovaps xmm6, [rsp+0x50]
0000740ecffdf191  vmovaps xmm7, [rsp+0x60]
0000740ecffdf197  vmovaps xmm8, [rsp+0x70]
0000740ecffdf19d  vmovaps xmm9, [rsp+0x80]
0000740ecffdf1a6  vmovaps xmm10, [rsp+0x90]
0000740ecffdf1af  vmovaps xmm11, [rsp+0xA0]
0000740ecffdf1b8  vmovaps xmm12, [rsp+0xB0]
0000740ecffdf1c1  vmovaps xmm13, [rsp+0xC0]
0000740ecffdf1ca  vmovaps xmm14, [rsp+0xD0]
0000740ecffdf1d3  vmovaps xmm15, [rsp+0xE0]
0000740ecffdf1dc  add rsp, 0xF0
0000740ecffdf1e3  pop r11
0000740ecffdf1e5  pop r10
0000740ecffdf1e7  pop r9
0000740ecffdf1e9  pop r8
0000740ecffdf1eb  pop rsi
0000740ecffdf1ec  pop rdi
0000740ecffdf1ed  pop rdx
0000740ecffdf1ee  pop rcx
0000740ecffdf1ef  pop rax
0000740ecffdf1f0  add rsp, 0x08
0000740ecffdf1f4  jmp 0x0000740ECFFDC375
0000740ecffdf1f9  sub rsp, 0x08
0000740ecffdf1fd  push rax
0000740ecffdf1fe  push rcx
0000740ecffdf1ff  push rdx
0000740ecffdf200  push rdi
0000740ecffdf201  push rsi
0000740ecffdf202  push r8
0000740ecffdf204  push r9
0000740ecffdf206  push r10
0000740ecffdf208  push r11
0000740ecffdf20a  sub rsp, 0xF0
0000740ecffdf211  vmovaps [rsp], xmm0
0000740ecffdf216  vmovaps [rsp+0x10], xmm1
0000740ecffdf21c  vmovaps [rsp+0x20], xmm2
0000740ecffdf222  vmovaps [rsp+0x30], xmm3
0000740ecffdf228  vmovaps [rsp+0x40], xmm4
0000740ecffdf22e  vmovaps [rsp+0x50], xmm5
0000740ecffdf234  vmovaps [rsp+0x60], xmm6
0000740ecffdf23a  vmovaps [rsp+0x70], xmm7
0000740ecffdf240  vmovaps [rsp+0x80], xmm8
0000740ecffdf249  vmovaps [rsp+0x90], xmm9
0000740ecffdf252  vmovaps [rsp+0xA0], xmm10
0000740ecffdf25b  vmovaps [rsp+0xB0], xmm11
0000740ecffdf264  vmovaps [rsp+0xC0], xmm12
0000740ecffdf26d  vmovaps [rsp+0xD0], xmm13
0000740ecffdf276  vmovaps [rsp+0xE0], xmm14
0000740ecffdf27f  sub rsp, 0x30
0000740ecffdf283  movaps [rsp], xmm15
0000740ecffdf288  movaps [rsp+0x10], xmm5
0000740ecffdf28d  movaps [rsp+0x20], xmm3
0000740ecffdf292  lea rdi, [rsp]
0000740ecffdf296  mov esi, 0x00
0000740ecffdf29b  mov rax, 0x5E8249CF1530
0000740ecffdf2a5  call rax
0000740ecffdf2a7  movaps xmm15, [rsp]
0000740ecffdf2ac  add rsp, 0x30
0000740ecffdf2b0  vmovaps xmm0, [rsp]
0000740ecffdf2b5  vmovaps xmm1, [rsp+0x10]
0000740ecffdf2bb  vmovaps xmm2, [rsp+0x20]
0000740ecffdf2c1  vmovaps xmm3, [rsp+0x30]
0000740ecffdf2c7  vmovaps xmm4, [rsp+0x40]
0000740ecffdf2cd  vmovaps xmm5, [rsp+0x50]
0000740ecffdf2d3  vmovaps xmm6, [rsp+0x60]
0000740ecffdf2d9  vmovaps xmm7, [rsp+0x70]
0000740ecffdf2df  vmovaps xmm8, [rsp+0x80]
0000740ecffdf2e8  vmovaps xmm9, [rsp+0x90]
0000740ecffdf2f1  vmovaps xmm10, [rsp+0xA0]
0000740ecffdf2fa  vmovaps xmm11, [rsp+0xB0]
0000740ecffdf303  vmovaps xmm12, [rsp+0xC0]
0000740ecffdf30c  vmovaps xmm13, [rsp+0xD0]
0000740ecffdf315  vmovaps xmm14, [rsp+0xE0]
0000740ecffdf31e  add rsp, 0xF0
0000740ecffdf325  pop r11
0000740ecffdf327  pop r10
0000740ecffdf329  pop r9
0000740ecffdf32b  pop r8
0000740ecffdf32d  pop rsi
0000740ecffdf32e  pop rdi
0000740ecffdf32f  pop rdx
0000740ecffdf330  pop rcx
0000740ecffdf331  pop rax
0000740ecffdf332  add rsp, 0x08
0000740ecffdf336  jmp 0x0000740ECFFDC38F
0000740ecffdf33b  sub rsp, 0x08
0000740ecffdf33f  push rax
0000740ecffdf340  push rcx
0000740ecffdf341  push rdx
0000740ecffdf342  push rdi
0000740ecffdf343  push rsi
0000740ecffdf344  push r8
0000740ecffdf346  push r9
0000740ecffdf348  push r10
0000740ecffdf34a  push r11
0000740ecffdf34c  sub rsp, 0xF0
0000740ecffdf353  vmovaps [rsp], xmm0
0000740ecffdf358  vmovaps [rsp+0x10], xmm1
0000740ecffdf35e  vmovaps [rsp+0x20], xmm2
0000740ecffdf364  vmovaps [rsp+0x30], xmm3
0000740ecffdf36a  vmovaps [rsp+0x40], xmm4
0000740ecffdf370  vmovaps [rsp+0x50], xmm6
0000740ecffdf376  vmovaps [rsp+0x60], xmm7
0000740ecffdf37c  vmovaps [rsp+0x70], xmm8
0000740ecffdf382  vmovaps [rsp+0x80], xmm9
0000740ecffdf38b  vmovaps [rsp+0x90], xmm10
0000740ecffdf394  vmovaps [rsp+0xA0], xmm11
0000740ecffdf39d  vmovaps [rsp+0xB0], xmm12
0000740ecffdf3a6  vmovaps [rsp+0xC0], xmm13
0000740ecffdf3af  vmovaps [rsp+0xD0], xmm14
0000740ecffdf3b8  vmovaps [rsp+0xE0], xmm15
0000740ecffdf3c1  sub rsp, 0x30
0000740ecffdf3c5  movaps [rsp], xmm5
0000740ecffdf3c9  movaps [rsp+0x10], xmm8
0000740ecffdf3cf  movaps [rsp+0x20], xmm6
0000740ecffdf3d4  lea rdi, [rsp]
0000740ecffdf3d8  mov esi, 0x00
0000740ecffdf3dd  mov rax, 0x5E8249CF1530
0000740ecffdf3e7  call rax
0000740ecffdf3e9  movaps xmm5, [rsp]
0000740ecffdf3ed  add rsp, 0x30
0000740ecffdf3f1  vmovaps xmm0, [rsp]
0000740ecffdf3f6  vmovaps xmm1, [rsp+0x10]
0000740ecffdf3fc  vmovaps xmm2, [rsp+0x20]
0000740ecffdf402  vmovaps xmm3, [rsp+0x30]
0000740ecffdf408  vmovaps xmm4, [rsp+0x40]
0000740ecffdf40e  vmovaps xmm6, [rsp+0x50]
0000740ecffdf414  vmovaps xmm7, [rsp+0x60]
0000740ecffdf41a  vmovaps xmm8, [rsp+0x70]
0000740ecffdf420  vmovaps xmm9, [rsp+0x80]
0000740ecffdf429  vmovaps xmm10, [rsp+0x90]
0000740ecffdf432  vmovaps xmm11, [rsp+0xA0]
0000740ecffdf43b  vmovaps xmm12, [rsp+0xB0]
0000740ecffdf444  vmovaps xmm13, [rsp+0xC0]
0000740ecffdf44d  vmovaps xmm14, [rsp+0xD0]
0000740ecffdf456  vmovaps xmm15, [rsp+0xE0]
0000740ecffdf45f  add rsp, 0xF0
0000740ecffdf466  pop r11
0000740ecffdf468  pop r10
0000740ecffdf46a  pop r9
0000740ecffdf46c  pop r8
0000740ecffdf46e  pop rsi
0000740ecffdf46f  pop rdi
0000740ecffdf470  pop rdx
0000740ecffdf471  pop rcx
0000740ecffdf472  pop rax
0000740ecffdf473  add rsp, 0x08
0000740ecffdf477  jmp 0x0000740ECFFDC3B3
0000740ecffdf47c  sub rsp, 0x08
0000740ecffdf480  push rax
0000740ecffdf481  push rcx
0000740ecffdf482  push rdx
0000740ecffdf483  push rdi
0000740ecffdf484  push rsi
0000740ecffdf485  push r8
0000740ecffdf487  push r9
0000740ecffdf489  push r10
0000740ecffdf48b  push r11
0000740ecffdf48d  sub rsp, 0xF0
0000740ecffdf494  vmovaps [rsp], xmm0
0000740ecffdf499  vmovaps [rsp+0x10], xmm1
0000740ecffdf49f  vmovaps [rsp+0x20], xmm2
0000740ecffdf4a5  vmovaps [rsp+0x30], xmm3
0000740ecffdf4ab  vmovaps [rsp+0x40], xmm4
0000740ecffdf4b1  vmovaps [rsp+0x50], xmm5
0000740ecffdf4b7  vmovaps [rsp+0x60], xmm7
0000740ecffdf4bd  vmovaps [rsp+0x70], xmm8
0000740ecffdf4c3  vmovaps [rsp+0x80], xmm9
0000740ecffdf4cc  vmovaps [rsp+0x90], xmm10
0000740ecffdf4d5  vmovaps [rsp+0xA0], xmm11
0000740ecffdf4de  vmovaps [rsp+0xB0], xmm12
0000740ecffdf4e7  vmovaps [rsp+0xC0], xmm13
0000740ecffdf4f0  vmovaps [rsp+0xD0], xmm14
0000740ecffdf4f9  vmovaps [rsp+0xE0], xmm15
0000740ecffdf502  sub rsp, 0x30
0000740ecffdf506  movaps [rsp], xmm6
0000740ecffdf50a  movaps [rsp+0x10], xmm10
0000740ecffdf510  movaps [rsp+0x20], xmm8
0000740ecffdf516  lea rdi, [rsp]
0000740ecffdf51a  mov esi, 0x00
0000740ecffdf51f  mov rax, 0x5E8249CF1530
0000740ecffdf529  call rax
0000740ecffdf52b  movaps xmm6, [rsp]
0000740ecffdf52f  add rsp, 0x30
0000740ecffdf533  vmovaps xmm0, [rsp]
0000740ecffdf538  vmovaps xmm1, [rsp+0x10]
0000740ecffdf53e  vmovaps xmm2, [rsp+0x20]
0000740ecffdf544  vmovaps xmm3, [rsp+0x30]
0000740ecffdf54a  vmovaps xmm4, [rsp+0x40]
0000740ecffdf550  vmovaps xmm5, [rsp+0x50]
0000740ecffdf556  vmovaps xmm7, [rsp+0x60]
0000740ecffdf55c  vmovaps xmm8, [rsp+0x70]
0000740ecffdf562  vmovaps xmm9, [rsp+0x80]
0000740ecffdf56b  vmovaps xmm10, [rsp+0x90]
0000740ecffdf574  vmovaps xmm11, [rsp+0xA0]
0000740ecffdf57d  vmovaps xmm12, [rsp+0xB0]
0000740ecffdf586  vmovaps xmm13, [rsp+0xC0]
0000740ecffdf58f  vmovaps xmm14, [rsp+0xD0]
0000740ecffdf598  vmovaps xmm15, [rsp+0xE0]
0000740ecffdf5a1  add rsp, 0xF0
0000740ecffdf5a8  pop r11
0000740ecffdf5aa  pop r10
0000740ecffdf5ac  pop r9
0000740ecffdf5ae  pop r8
0000740ecffdf5b0  pop rsi
0000740ecffdf5b1  pop rdi
0000740ecffdf5b2  pop rdx
0000740ecffdf5b3  pop rcx
0000740ecffdf5b4  pop rax
0000740ecffdf5b5  add rsp, 0x08
0000740ecffdf5b9  jmp 0x0000740ECFFDC3D8
0000740ecffdf5be  sub rsp, 0x08
0000740ecffdf5c2  push rax
0000740ecffdf5c3  push rcx
0000740ecffdf5c4  push rdx
0000740ecffdf5c5  push rdi
0000740ecffdf5c6  push rsi
0000740ecffdf5c7  push r8
0000740ecffdf5c9  push r9
0000740ecffdf5cb  push r10
0000740ecffdf5cd  push r11
0000740ecffdf5cf  sub rsp, 0xF0
0000740ecffdf5d6  vmovaps [rsp], xmm0
0000740ecffdf5db  vmovaps [rsp+0x10], xmm1
0000740ecffdf5e1  vmovaps [rsp+0x20], xmm2
0000740ecffdf5e7  vmovaps [rsp+0x30], xmm3
0000740ecffdf5ed  vmovaps [rsp+0x40], xmm4
0000740ecffdf5f3  vmovaps [rsp+0x50], xmm5
0000740ecffdf5f9  vmovaps [rsp+0x60], xmm6
0000740ecffdf5ff  vmovaps [rsp+0x70], xmm7
0000740ecffdf605  vmovaps [rsp+0x80], xmm8
0000740ecffdf60e  vmovaps [rsp+0x90], xmm9
0000740ecffdf617  vmovaps [rsp+0xA0], xmm11
0000740ecffdf620  vmovaps [rsp+0xB0], xmm12
0000740ecffdf629  vmovaps [rsp+0xC0], xmm13
0000740ecffdf632  vmovaps [rsp+0xD0], xmm14
0000740ecffdf63b  vmovaps [rsp+0xE0], xmm15
0000740ecffdf644  sub rsp, 0x30
0000740ecffdf648  movaps [rsp], xmm10
0000740ecffdf64d  movaps [rsp+0x10], xmm8
0000740ecffdf653  movaps [rsp+0x20], xmm14
0000740ecffdf659  lea rdi, [rsp]
0000740ecffdf65d  mov esi, 0x00
0000740ecffdf662  mov rax, 0x5E8249CF1530
0000740ecffdf66c  call rax
0000740ecffdf66e  movaps xmm10, [rsp]
0000740ecffdf673  add rsp, 0x30
0000740ecffdf677  vmovaps xmm0, [rsp]
0000740ecffdf67c  vmovaps xmm1, [rsp+0x10]
0000740ecffdf682  vmovaps xmm2, [rsp+0x20]
0000740ecffdf688  vmovaps xmm3, [rsp+0x30]
0000740ecffdf68e  vmovaps xmm4, [rsp+0x40]
0000740ecffdf694  vmovaps xmm5, [rsp+0x50]
0000740ecffdf69a  vmovaps xmm6, [rsp+0x60]
0000740ecffdf6a0  vmovaps xmm7, [rsp+0x70]
0000740ecffdf6a6  vmovaps xmm8, [rsp+0x80]
0000740ecffdf6af  vmovaps xmm9, [rsp+0x90]
0000740ecffdf6b8  vmovaps xmm11, [rsp+0xA0]
0000740ecffdf6c1  vmovaps xmm12, [rsp+0xB0]
0000740ecffdf6ca  vmovaps xmm13, [rsp+0xC0]
0000740ecffdf6d3  vmovaps xmm14, [rsp+0xD0]
0000740ecffdf6dc  vmovaps xmm15, [rsp+0xE0]
0000740ecffdf6e5  add rsp, 0xF0
0000740ecffdf6ec  pop r11
0000740ecffdf6ee  pop r10
0000740ecffdf6f0  pop r9
0000740ecffdf6f2  pop r8
0000740ecffdf6f4  pop rsi
0000740ecffdf6f5  pop rdi
0000740ecffdf6f6  pop rdx
0000740ecffdf6f7  pop rcx
0000740ecffdf6f8  pop rax
0000740ecffdf6f9  add rsp, 0x08
0000740ecffdf6fd  jmp 0x0000740ECFFDC3F8
0000740ecffdf702  sub rsp, 0x08
0000740ecffdf706  push rax
0000740ecffdf707  push rcx
0000740ecffdf708  push rdx
0000740ecffdf709  push rdi
0000740ecffdf70a  push rsi
0000740ecffdf70b  push r8
0000740ecffdf70d  push r9
0000740ecffdf70f  push r10
0000740ecffdf711  push r11
0000740ecffdf713  sub rsp, 0xF0
0000740ecffdf71a  vmovaps [rsp], xmm0
0000740ecffdf71f  vmovaps [rsp+0x10], xmm1
0000740ecffdf725  vmovaps [rsp+0x20], xmm2
0000740ecffdf72b  vmovaps [rsp+0x30], xmm3
0000740ecffdf731  vmovaps [rsp+0x40], xmm4
0000740ecffdf737  vmovaps [rsp+0x50], xmm5
0000740ecffdf73d  vmovaps [rsp+0x60], xmm6
0000740ecffdf743  vmovaps [rsp+0x70], xmm7
0000740ecffdf749  vmovaps [rsp+0x80], xmm8
0000740ecffdf752  vmovaps [rsp+0x90], xmm9
0000740ecffdf75b  vmovaps [rsp+0xA0], xmm10
0000740ecffdf764  vmovaps [rsp+0xB0], xmm11
0000740ecffdf76d  vmovaps [rsp+0xC0], xmm12
0000740ecffdf776  vmovaps [rsp+0xD0], xmm13
0000740ecffdf77f  vmovaps [rsp+0xE0], xmm15
0000740ecffdf788  sub rsp, 0x30
0000740ecffdf78c  movaps [rsp], xmm14
0000740ecffdf791  movaps [rsp+0x10], xmm8
0000740ecffdf797  movaps [rsp+0x20], xmm4
0000740ecffdf79c  lea rdi, [rsp]
0000740ecffdf7a0  mov esi, 0x00
0000740ecffdf7a5  mov rax, 0x5E8249CF1530
0000740ecffdf7af  call rax
0000740ecffdf7b1  movaps xmm14, [rsp]
0000740ecffdf7b6  add rsp, 0x30
0000740ecffdf7ba  vmovaps xmm0, [rsp]
0000740ecffdf7bf  vmovaps xmm1, [rsp+0x10]
0000740ecffdf7c5  vmovaps xmm2, [rsp+0x20]
0000740ecffdf7cb  vmovaps xmm3, [rsp+0x30]
0000740ecffdf7d1  vmovaps xmm4, [rsp+0x40]
0000740ecffdf7d7  vmovaps xmm5, [rsp+0x50]
0000740ecffdf7dd  vmovaps xmm6, [rsp+0x60]
0000740ecffdf7e3  vmovaps xmm7, [rsp+0x70]
0000740ecffdf7e9  vmovaps xmm8, [rsp+0x80]
0000740ecffdf7f2  vmovaps xmm9, [rsp+0x90]
0000740ecffdf7fb  vmovaps xmm10, [rsp+0xA0]
0000740ecffdf804  vmovaps xmm11, [rsp+0xB0]
0000740ecffdf80d  vmovaps xmm12, [rsp+0xC0]
0000740ecffdf816  vmovaps xmm13, [rsp+0xD0]
0000740ecffdf81f  vmovaps xmm15, [rsp+0xE0]
0000740ecffdf828  add rsp, 0xF0
0000740ecffdf82f  pop r11
0000740ecffdf831  pop r10
0000740ecffdf833  pop r9
0000740ecffdf835  pop r8
0000740ecffdf837  pop rsi
0000740ecffdf838  pop rdi
0000740ecffdf839  pop rdx
0000740ecffdf83a  pop rcx
0000740ecffdf83b  pop rax
0000740ecffdf83c  add rsp, 0x08
0000740ecffdf840  jmp 0x0000740ECFFDC418
0000740ecffdf845  sub rsp, 0x08
0000740ecffdf849  push rax
0000740ecffdf84a  push rcx
0000740ecffdf84b  push rdx
0000740ecffdf84c  push rdi
0000740ecffdf84d  push rsi
0000740ecffdf84e  push r8
0000740ecffdf850  push r9
0000740ecffdf852  push r10
0000740ecffdf854  push r11
0000740ecffdf856  sub rsp, 0xF0
0000740ecffdf85d  vmovaps [rsp], xmm0
0000740ecffdf862  vmovaps [rsp+0x10], xmm1
0000740ecffdf868  vmovaps [rsp+0x20], xmm2
0000740ecffdf86e  vmovaps [rsp+0x30], xmm3
0000740ecffdf874  vmovaps [rsp+0x40], xmm5
0000740ecffdf87a  vmovaps [rsp+0x50], xmm6
0000740ecffdf880  vmovaps [rsp+0x60], xmm7
0000740ecffdf886  vmovaps [rsp+0x70], xmm8
0000740ecffdf88c  vmovaps [rsp+0x80], xmm9
0000740ecffdf895  vmovaps [rsp+0x90], xmm10
0000740ecffdf89e  vmovaps [rsp+0xA0], xmm11
0000740ecffdf8a7  vmovaps [rsp+0xB0], xmm12
0000740ecffdf8b0  vmovaps [rsp+0xC0], xmm13
0000740ecffdf8b9  vmovaps [rsp+0xD0], xmm14
0000740ecffdf8c2  vmovaps [rsp+0xE0], xmm15
0000740ecffdf8cb  sub rsp, 0x30
0000740ecffdf8cf  movaps [rsp], xmm4
0000740ecffdf8d3  movaps [rsp+0x10], xmm13
0000740ecffdf8d9  movaps [rsp+0x20], xmm8
0000740ecffdf8df  lea rdi, [rsp]
0000740ecffdf8e3  mov esi, 0x00
0000740ecffdf8e8  mov rax, 0x5E8249CF1530
0000740ecffdf8f2  call rax
0000740ecffdf8f4  movaps xmm4, [rsp]
0000740ecffdf8f8  add rsp, 0x30
0000740ecffdf8fc  vmovaps xmm0, [rsp]
0000740ecffdf901  vmovaps xmm1, [rsp+0x10]
0000740ecffdf907  vmovaps xmm2, [rsp+0x20]
0000740ecffdf90d  vmovaps xmm3, [rsp+0x30]
0000740ecffdf913  vmovaps xmm5, [rsp+0x40]
0000740ecffdf919  vmovaps xmm6, [rsp+0x50]
0000740ecffdf91f  vmovaps xmm7, [rsp+0x60]
0000740ecffdf925  vmovaps xmm8, [rsp+0x70]
0000740ecffdf92b  vmovaps xmm9, [rsp+0x80]
0000740ecffdf934  vmovaps xmm10, [rsp+0x90]
0000740ecffdf93d  vmovaps xmm11, [rsp+0xA0]
0000740ecffdf946  vmovaps xmm12, [rsp+0xB0]
0000740ecffdf94f  vmovaps xmm13, [rsp+0xC0]
0000740ecffdf958  vmovaps xmm14, [rsp+0xD0]
0000740ecffdf961  vmovaps xmm15, [rsp+0xE0]
0000740ecffdf96a  add rsp, 0xF0
0000740ecffdf971  pop r11
0000740ecffdf973  pop r10
0000740ecffdf975  pop r9
0000740ecffdf977  pop r8
0000740ecffdf979  pop rsi
0000740ecffdf97a  pop rdi
0000740ecffdf97b  pop rdx
0000740ecffdf97c  pop rcx
0000740ecffdf97d  pop rax
0000740ecffdf97e  add rsp, 0x08
0000740ecffdf982  jmp 0x0000740ECFFDC43D
0000740ecffdf987  sub rsp, 0x08
0000740ecffdf98b  push rax
0000740ecffdf98c  push rcx
0000740ecffdf98d  push rdx
0000740ecffdf98e  push rdi
0000740ecffdf98f  push rsi
0000740ecffdf990  push r8
0000740ecffdf992  push r9
0000740ecffdf994  push r10
0000740ecffdf996  push r11
0000740ecffdf998  sub rsp, 0xF0
0000740ecffdf99f  vmovaps [rsp], xmm0
0000740ecffdf9a4  vmovaps [rsp+0x10], xmm1
0000740ecffdf9aa  vmovaps [rsp+0x20], xmm2
0000740ecffdf9b0  vmovaps [rsp+0x30], xmm3
0000740ecffdf9b6  vmovaps [rsp+0x40], xmm4
0000740ecffdf9bc  vmovaps [rsp+0x50], xmm5
0000740ecffdf9c2  vmovaps [rsp+0x60], xmm6
0000740ecffdf9c8  vmovaps [rsp+0x70], xmm7
0000740ecffdf9ce  vmovaps [rsp+0x80], xmm8
0000740ecffdf9d7  vmovaps [rsp+0x90], xmm9
0000740ecffdf9e0  vmovaps [rsp+0xA0], xmm10
0000740ecffdf9e9  vmovaps [rsp+0xB0], xmm11
0000740ecffdf9f2  vmovaps [rsp+0xC0], xmm12
0000740ecffdf9fb  vmovaps [rsp+0xD0], xmm14
0000740ecffdfa04  vmovaps [rsp+0xE0], xmm15
0000740ecffdfa0d  sub rsp, 0x30
0000740ecffdfa11  movaps [rsp], xmm13
0000740ecffdfa16  movaps [rsp+0x10], xmm15
0000740ecffdfa1c  movaps [rsp+0x20], xmm9
0000740ecffdfa22  lea rdi, [rsp]
0000740ecffdfa26  mov esi, 0x00
0000740ecffdfa2b  mov rax, 0x5E8249CF1530
0000740ecffdfa35  call rax
0000740ecffdfa37  movaps xmm13, [rsp]
0000740ecffdfa3c  add rsp, 0x30
0000740ecffdfa40  vmovaps xmm0, [rsp]
0000740ecffdfa45  vmovaps xmm1, [rsp+0x10]
0000740ecffdfa4b  vmovaps xmm2, [rsp+0x20]
0000740ecffdfa51  vmovaps xmm3, [rsp+0x30]
0000740ecffdfa57  vmovaps xmm4, [rsp+0x40]
0000740ecffdfa5d  vmovaps xmm5, [rsp+0x50]
0000740ecffdfa63  vmovaps xmm6, [rsp+0x60]
0000740ecffdfa69  vmovaps xmm7, [rsp+0x70]
0000740ecffdfa6f  vmovaps xmm8, [rsp+0x80]
0000740ecffdfa78  vmovaps xmm9, [rsp+0x90]
0000740ecffdfa81  vmovaps xmm10, [rsp+0xA0]
0000740ecffdfa8a  vmovaps xmm11, [rsp+0xB0]
0000740ecffdfa93  vmovaps xmm12, [rsp+0xC0]
0000740ecffdfa9c  vmovaps xmm14, [rsp+0xD0]
0000740ecffdfaa5  vmovaps xmm15, [rsp+0xE0]
0000740ecffdfaae  add rsp, 0xF0
0000740ecffdfab5  pop r11
0000740ecffdfab7  pop r10
0000740ecffdfab9  pop r9
0000740ecffdfabb  pop r8
0000740ecffdfabd  pop rsi
0000740ecffdfabe  pop rdi
0000740ecffdfabf  pop rdx
0000740ecffdfac0  pop rcx
0000740ecffdfac1  pop rax
0000740ecffdfac2  add rsp, 0x08
0000740ecffdfac6  jmp 0x0000740ECFFDC458
0000740ecffdfacb  sub rsp, 0x08
0000740ecffdfacf  push rax
0000740ecffdfad0  push rcx
0000740ecffdfad1  push rdx
0000740ecffdfad2  push rdi
0000740ecffdfad3  push rsi
0000740ecffdfad4  push r8
0000740ecffdfad6  push r9
0000740ecffdfad8  push r10
0000740ecffdfada  push r11
0000740ecffdfadc  sub rsp, 0xF0
0000740ecffdfae3  vmovaps [rsp], xmm0
0000740ecffdfae8  vmovaps [rsp+0x10], xmm1
0000740ecffdfaee  vmovaps [rsp+0x20], xmm2
0000740ecffdfaf4  vmovaps [rsp+0x30], xmm3
0000740ecffdfafa  vmovaps [rsp+0x40], xmm4
0000740ecffdfb00  vmovaps [rsp+0x50], xmm5
0000740ecffdfb06  vmovaps [rsp+0x60], xmm6
0000740ecffdfb0c  vmovaps [rsp+0x70], xmm7
0000740ecffdfb12  vmovaps [rsp+0x80], xmm8
0000740ecffdfb1b  vmovaps [rsp+0x90], xmm9
0000740ecffdfb24  vmovaps [rsp+0xA0], xmm10
0000740ecffdfb2d  vmovaps [rsp+0xB0], xmm11
0000740ecffdfb36  vmovaps [rsp+0xC0], xmm12
0000740ecffdfb3f  vmovaps [rsp+0xD0], xmm13
0000740ecffdfb48  vmovaps [rsp+0xE0], xmm14
0000740ecffdfb51  sub rsp, 0x30
0000740ecffdfb55  movaps [rsp], xmm15
0000740ecffdfb5a  movaps [rsp+0x10], xmm1
0000740ecffdfb5f  movaps [rsp+0x20], xmm5
0000740ecffdfb64  lea rdi, [rsp]
0000740ecffdfb68  mov esi, 0x00
0000740ecffdfb6d  mov rax, 0x5E8249CF1530
0000740ecffdfb77  call rax
0000740ecffdfb79  movaps xmm15, [rsp]
0000740ecffdfb7e  add rsp, 0x30
0000740ecffdfb82  vmovaps xmm0, [rsp]
0000740ecffdfb87  vmovaps xmm1, [rsp+0x10]
0000740ecffdfb8d  vmovaps xmm2, [rsp+0x20]
0000740ecffdfb93  vmovaps xmm3, [rsp+0x30]
0000740ecffdfb99  vmovaps xmm4, [rsp+0x40]
0000740ecffdfb9f  vmovaps xmm5, [rsp+0x50]
0000740ecffdfba5  vmovaps xmm6, [rsp+0x60]
0000740ecffdfbab  vmovaps xmm7, [rsp+0x70]
0000740ecffdfbb1  vmovaps xmm8, [rsp+0x80]
0000740ecffdfbba  vmovaps xmm9, [rsp+0x90]
0000740ecffdfbc3  vmovaps xmm10, [rsp+0xA0]
0000740ecffdfbcc  vmovaps xmm11, [rsp+0xB0]
0000740ecffdfbd5  vmovaps xmm12, [rsp+0xC0]
0000740ecffdfbde  vmovaps xmm13, [rsp+0xD0]
0000740ecffdfbe7  vmovaps xmm14, [rsp+0xE0]
0000740ecffdfbf0  add rsp, 0xF0
0000740ecffdfbf7  pop r11
0000740ecffdfbf9  pop r10
0000740ecffdfbfb  pop r9
0000740ecffdfbfd  pop r8
0000740ecffdfbff  pop rsi
0000740ecffdfc00  pop rdi
0000740ecffdfc01  pop rdx
0000740ecffdfc02  pop rcx
0000740ecffdfc03  pop rax
0000740ecffdfc04  add rsp, 0x08
0000740ecffdfc08  jmp 0x0000740ECFFDC473
0000740ecffdfc0d  call 0x0000740ECFEB52F0
0000740ecffdfc12  jmp 0x0000740ECFFDC4CE
0000740ecffdfc17  sub rsp, 0x08
0000740ecffdfc1b  push rax
0000740ecffdfc1c  push rcx
0000740ecffdfc1d  push rdx
0000740ecffdfc1e  push rdi
0000740ecffdfc1f  push rsi
0000740ecffdfc20  push r8
0000740ecffdfc22  push r9
0000740ecffdfc24  push r10
0000740ecffdfc26  push r11
0000740ecffdfc28  sub rsp, 0xF0
0000740ecffdfc2f  vmovaps [rsp], xmm0
0000740ecffdfc34  vmovaps [rsp+0x10], xmm1
0000740ecffdfc3a  vmovaps [rsp+0x20], xmm2
0000740ecffdfc40  vmovaps [rsp+0x30], xmm3
0000740ecffdfc46  vmovaps [rsp+0x40], xmm4
0000740ecffdfc4c  vmovaps [rsp+0x50], xmm5
0000740ecffdfc52  vmovaps [rsp+0x60], xmm6
0000740ecffdfc58  vmovaps [rsp+0x70], xmm7
0000740ecffdfc5e  vmovaps [rsp+0x80], xmm8
0000740ecffdfc67  vmovaps [rsp+0x90], xmm10
0000740ecffdfc70  vmovaps [rsp+0xA0], xmm11
0000740ecffdfc79  vmovaps [rsp+0xB0], xmm12
0000740ecffdfc82  vmovaps [rsp+0xC0], xmm13
0000740ecffdfc8b  vmovaps [rsp+0xD0], xmm14
0000740ecffdfc94  vmovaps [rsp+0xE0], xmm15
0000740ecffdfc9d  sub rsp, 0x30
0000740ecffdfca1  movaps [rsp], xmm9
0000740ecffdfca6  movaps [rsp+0x10], xmm8
0000740ecffdfcac  movaps [rsp+0x20], xmm11
0000740ecffdfcb2  lea rdi, [rsp]
0000740ecffdfcb6  mov esi, 0x00
0000740ecffdfcbb  mov rax, 0x5E8249CF1530
0000740ecffdfcc5  call rax
0000740ecffdfcc7  movaps xmm9, [rsp]
0000740ecffdfccc  add rsp, 0x30
0000740ecffdfcd0  vmovaps xmm0, [rsp]
0000740ecffdfcd5  vmovaps xmm1, [rsp+0x10]
0000740ecffdfcdb  vmovaps xmm2, [rsp+0x20]
0000740ecffdfce1  vmovaps xmm3, [rsp+0x30]
0000740ecffdfce7  vmovaps xmm4, [rsp+0x40]
0000740ecffdfced  vmovaps xmm5, [rsp+0x50]
0000740ecffdfcf3  vmovaps xmm6, [rsp+0x60]
0000740ecffdfcf9  vmovaps xmm7, [rsp+0x70]
0000740ecffdfcff  vmovaps xmm8, [rsp+0x80]
0000740ecffdfd08  vmovaps xmm10, [rsp+0x90]
0000740ecffdfd11  vmovaps xmm11, [rsp+0xA0]
0000740ecffdfd1a  vmovaps xmm12, [rsp+0xB0]
0000740ecffdfd23  vmovaps xmm13, [rsp+0xC0]
0000740ecffdfd2c  vmovaps xmm14, [rsp+0xD0]
0000740ecffdfd35  vmovaps xmm15, [rsp+0xE0]
0000740ecffdfd3e  add rsp, 0xF0
0000740ecffdfd45  pop r11
0000740ecffdfd47  pop r10
0000740ecffdfd49  pop r9
0000740ecffdfd4b  pop r8
0000740ecffdfd4d  pop rsi
0000740ecffdfd4e  pop rdi
0000740ecffdfd4f  pop rdx
0000740ecffdfd50  pop rcx
0000740ecffdfd51  pop rax
0000740ecffdfd52  add rsp, 0x08
0000740ecffdfd56  jmp 0x0000740ECFFDC505
0000740ecffdfd5b  sub rsp, 0x08
0000740ecffdfd5f  push rax
0000740ecffdfd60  push rcx
0000740ecffdfd61  push rdx
0000740ecffdfd62  push rdi
0000740ecffdfd63  push rsi
0000740ecffdfd64  push r8
0000740ecffdfd66  push r9
0000740ecffdfd68  push r10
0000740ecffdfd6a  push r11
0000740ecffdfd6c  sub rsp, 0xF0
0000740ecffdfd73  vmovaps [rsp], xmm0
0000740ecffdfd78  vmovaps [rsp+0x10], xmm1
0000740ecffdfd7e  vmovaps [rsp+0x20], xmm2
0000740ecffdfd84  vmovaps [rsp+0x30], xmm3
0000740ecffdfd8a  vmovaps [rsp+0x40], xmm4
0000740ecffdfd90  vmovaps [rsp+0x50], xmm5
0000740ecffdfd96  vmovaps [rsp+0x60], xmm6
0000740ecffdfd9c  vmovaps [rsp+0x70], xmm7
0000740ecffdfda2  vmovaps [rsp+0x80], xmm8
0000740ecffdfdab  vmovaps [rsp+0x90], xmm9
0000740ecffdfdb4  vmovaps [rsp+0xA0], xmm10
0000740ecffdfdbd  vmovaps [rsp+0xB0], xmm12
0000740ecffdfdc6  vmovaps [rsp+0xC0], xmm13
0000740ecffdfdcf  vmovaps [rsp+0xD0], xmm14
0000740ecffdfdd8  vmovaps [rsp+0xE0], xmm15
0000740ecffdfde1  sub rsp, 0x30
0000740ecffdfde5  movaps [rsp], xmm11
0000740ecffdfdea  movaps [rsp+0x10], xmm10
0000740ecffdfdf0  movaps [rsp+0x20], xmm6
0000740ecffdfdf5  lea rdi, [rsp]
0000740ecffdfdf9  mov esi, 0x00
0000740ecffdfdfe  mov rax, 0x5E8249CF1530
0000740ecffdfe08  call rax
0000740ecffdfe0a  movaps xmm11, [rsp]
0000740ecffdfe0f  add rsp, 0x30
0000740ecffdfe13  vmovaps xmm0, [rsp]
0000740ecffdfe18  vmovaps xmm1, [rsp+0x10]
0000740ecffdfe1e  vmovaps xmm2, [rsp+0x20]
0000740ecffdfe24  vmovaps xmm3, [rsp+0x30]
0000740ecffdfe2a  vmovaps xmm4, [rsp+0x40]
0000740ecffdfe30  vmovaps xmm5, [rsp+0x50]
0000740ecffdfe36  vmovaps xmm6, [rsp+0x60]
0000740ecffdfe3c  vmovaps xmm7, [rsp+0x70]
0000740ecffdfe42  vmovaps xmm8, [rsp+0x80]
0000740ecffdfe4b  vmovaps xmm9, [rsp+0x90]
0000740ecffdfe54  vmovaps xmm10, [rsp+0xA0]
0000740ecffdfe5d  vmovaps xmm12, [rsp+0xB0]
0000740ecffdfe66  vmovaps xmm13, [rsp+0xC0]
0000740ecffdfe6f  vmovaps xmm14, [rsp+0xD0]
0000740ecffdfe78  vmovaps xmm15, [rsp+0xE0]
0000740ecffdfe81  add rsp, 0xF0
0000740ecffdfe88  pop r11
0000740ecffdfe8a  pop r10
0000740ecffdfe8c  pop r9
0000740ecffdfe8e  pop r8
0000740ecffdfe90  pop rsi
0000740ecffdfe91  pop rdi
0000740ecffdfe92  pop rdx
0000740ecffdfe93  pop rcx
0000740ecffdfe94  pop rax
0000740ecffdfe95  add rsp, 0x08
0000740ecffdfe99  jmp 0x0000740ECFFDC520
0000740ecffdfe9e  sub rsp, 0x08
0000740ecffdfea2  push rax
0000740ecffdfea3  push rcx
0000740ecffdfea4  push rdx
0000740ecffdfea5  push rdi
0000740ecffdfea6  push rsi
0000740ecffdfea7  push r8
0000740ecffdfea9  push r9
0000740ecffdfeab  push r10
0000740ecffdfead  push r11
0000740ecffdfeaf  sub rsp, 0xF0
0000740ecffdfeb6  vmovaps [rsp], xmm0
0000740ecffdfebb  vmovaps [rsp+0x10], xmm1
0000740ecffdfec1  vmovaps [rsp+0x20], xmm2
0000740ecffdfec7  vmovaps [rsp+0x30], xmm3
0000740ecffdfecd  vmovaps [rsp+0x40], xmm4
0000740ecffdfed3  vmovaps [rsp+0x50], xmm5
0000740ecffdfed9  vmovaps [rsp+0x60], xmm6
0000740ecffdfedf  vmovaps [rsp+0x70], xmm7
0000740ecffdfee5  vmovaps [rsp+0x80], xmm8
0000740ecffdfeee  vmovaps [rsp+0x90], xmm9
0000740ecffdfef7  vmovaps [rsp+0xA0], xmm11
0000740ecffdff00  vmovaps [rsp+0xB0], xmm12
0000740ecffdff09  vmovaps [rsp+0xC0], xmm13
0000740ecffdff12  vmovaps [rsp+0xD0], xmm14
0000740ecffdff1b  vmovaps [rsp+0xE0], xmm15
0000740ecffdff24  sub rsp, 0x30
0000740ecffdff28  movaps [rsp], xmm10
0000740ecffdff2d  movaps [rsp+0x10], xmm14
0000740ecffdff33  movaps [rsp+0x20], xmm4
0000740ecffdff38  lea rdi, [rsp]
0000740ecffdff3c  mov esi, 0x00
0000740ecffdff41  mov rax, 0x5E8249CF1530
0000740ecffdff4b  call rax
0000740ecffdff4d  movaps xmm10, [rsp]
0000740ecffdff52  add rsp, 0x30
0000740ecffdff56  vmovaps xmm0, [rsp]
0000740ecffdff5b  vmovaps xmm1, [rsp+0x10]
0000740ecffdff61  vmovaps xmm2, [rsp+0x20]
0000740ecffdff67  vmovaps xmm3, [rsp+0x30]
0000740ecffdff6d  vmovaps xmm4, [rsp+0x40]
0000740ecffdff73  vmovaps xmm5, [rsp+0x50]
0000740ecffdff79  vmovaps xmm6, [rsp+0x60]
0000740ecffdff7f  vmovaps xmm7, [rsp+0x70]
0000740ecffdff85  vmovaps xmm8, [rsp+0x80]
0000740ecffdff8e  vmovaps xmm9, [rsp+0x90]
0000740ecffdff97  vmovaps xmm11, [rsp+0xA0]
0000740ecffdffa0  vmovaps xmm12, [rsp+0xB0]
0000740ecffdffa9  vmovaps xmm13, [rsp+0xC0]
0000740ecffdffb2  vmovaps xmm14, [rsp+0xD0]
0000740ecffdffbb  vmovaps xmm15, [rsp+0xE0]
0000740ecffdffc4  add rsp, 0xF0
0000740ecffdffcb  pop r11
0000740ecffdffcd  pop r10
0000740ecffdffcf  pop r9
0000740ecffdffd1  pop r8
0000740ecffdffd3  pop rsi
0000740ecffdffd4  pop rdi
0000740ecffdffd5  pop rdx
0000740ecffdffd6  pop rcx
0000740ecffdffd7  pop rax
0000740ecffdffd8  add rsp, 0x08
0000740ecffdffdc  jmp 0x0000740ECFFDC53B
0000740ecffdffe1  sub rsp, 0x08
0000740ecffdffe5  push rax
0000740ecffdffe6  push rcx
0000740ecffdffe7  push rdx
0000740ecffdffe8  push rdi
0000740ecffdffe9  push rsi
0000740ecffdffea  push r8
0000740ecffdffec  push r9
0000740ecffdffee  push r10
0000740ecffdfff0  push r11
0000740ecffdfff2  sub rsp, 0xF0
0000740ecffdfff9  vmovaps [rsp], xmm0
0000740ecffdfffe  vmovaps [rsp+0x10], xmm1
0000740ecffe0004  vmovaps [rsp+0x20], xmm2
0000740ecffe000a  vmovaps [rsp+0x30], xmm3
0000740ecffe0010  vmovaps [rsp+0x40], xmm4
0000740ecffe0016  vmovaps [rsp+0x50], xmm5
0000740ecffe001c  vmovaps [rsp+0x60], xmm6
0000740ecffe0022  vmovaps [rsp+0x70], xmm7
0000740ecffe0028  vmovaps [rsp+0x80], xmm9
0000740ecffe0031  vmovaps [rsp+0x90], xmm10
0000740ecffe003a  vmovaps [rsp+0xA0], xmm11
0000740ecffe0043  vmovaps [rsp+0xB0], xmm12
0000740ecffe004c  vmovaps [rsp+0xC0], xmm13
0000740ecffe0055  vmovaps [rsp+0xD0], xmm14
0000740ecffe005e  vmovaps [rsp+0xE0], xmm15
0000740ecffe0067  sub rsp, 0x30
0000740ecffe006b  movaps [rsp], xmm8
0000740ecffe0070  movaps [rsp+0x10], xmm1
0000740ecffe0075  movaps [rsp+0x20], xmm14
0000740ecffe007b  lea rdi, [rsp]
0000740ecffe007f  mov esi, 0x00
0000740ecffe0084  mov rax, 0x5E8249CF1530
0000740ecffe008e  call rax
0000740ecffe0090  movaps xmm8, [rsp]
0000740ecffe0095  add rsp, 0x30
0000740ecffe0099  vmovaps xmm0, [rsp]
0000740ecffe009e  vmovaps xmm1, [rsp+0x10]
0000740ecffe00a4  vmovaps xmm2, [rsp+0x20]
0000740ecffe00aa  vmovaps xmm3, [rsp+0x30]
0000740ecffe00b0  vmovaps xmm4, [rsp+0x40]
0000740ecffe00b6  vmovaps xmm5, [rsp+0x50]
0000740ecffe00bc  vmovaps xmm6, [rsp+0x60]
0000740ecffe00c2  vmovaps xmm7, [rsp+0x70]
0000740ecffe00c8  vmovaps xmm9, [rsp+0x80]
0000740ecffe00d1  vmovaps xmm10, [rsp+0x90]
0000740ecffe00da  vmovaps xmm11, [rsp+0xA0]
0000740ecffe00e3  vmovaps xmm12, [rsp+0xB0]
0000740ecffe00ec  vmovaps xmm13, [rsp+0xC0]
0000740ecffe00f5  vmovaps xmm14, [rsp+0xD0]
0000740ecffe00fe  vmovaps xmm15, [rsp+0xE0]
0000740ecffe0107  add rsp, 0xF0
0000740ecffe010e  pop r11
0000740ecffe0110  pop r10
0000740ecffe0112  pop r9
0000740ecffe0114  pop r8
0000740ecffe0116  pop rsi
0000740ecffe0117  pop rdi
0000740ecffe0118  pop rdx
0000740ecffe0119  pop rcx
0000740ecffe011a  pop rax
0000740ecffe011b  add rsp, 0x08
0000740ecffe011f  jmp 0x0000740ECFFDC561
0000740ecffe0124  sub rsp, 0x08
0000740ecffe0128  push rax
0000740ecffe0129  push rcx
0000740ecffe012a  push rdx
0000740ecffe012b  push rdi
0000740ecffe012c  push rsi
0000740ecffe012d  push r8
0000740ecffe012f  push r9
0000740ecffe0131  push r10
0000740ecffe0133  push r11
0000740ecffe0135  sub rsp, 0xF0
0000740ecffe013c  vmovaps [rsp], xmm0
0000740ecffe0141  vmovaps [rsp+0x10], xmm1
0000740ecffe0147  vmovaps [rsp+0x20], xmm2
0000740ecffe014d  vmovaps [rsp+0x30], xmm3
0000740ecffe0153  vmovaps [rsp+0x40], xmm4
0000740ecffe0159  vmovaps [rsp+0x50], xmm5
0000740ecffe015f  vmovaps [rsp+0x60], xmm7
0000740ecffe0165  vmovaps [rsp+0x70], xmm8
0000740ecffe016b  vmovaps [rsp+0x80], xmm9
0000740ecffe0174  vmovaps [rsp+0x90], xmm10
0000740ecffe017d  vmovaps [rsp+0xA0], xmm11
0000740ecffe0186  vmovaps [rsp+0xB0], xmm12
0000740ecffe018f  vmovaps [rsp+0xC0], xmm13
0000740ecffe0198  vmovaps [rsp+0xD0], xmm14
0000740ecffe01a1  vmovaps [rsp+0xE0], xmm15
0000740ecffe01aa  sub rsp, 0x30
0000740ecffe01ae  movaps [rsp], xmm6
0000740ecffe01b2  movaps [rsp+0x10], xmm1
0000740ecffe01b7  movaps [rsp+0x20], xmm14
0000740ecffe01bd  lea rdi, [rsp]
0000740ecffe01c1  mov esi, 0x00
0000740ecffe01c6  mov rax, 0x5E8249CF1530
0000740ecffe01d0  call rax
0000740ecffe01d2  movaps xmm6, [rsp]
0000740ecffe01d6  add rsp, 0x30
0000740ecffe01da  vmovaps xmm0, [rsp]
0000740ecffe01df  vmovaps xmm1, [rsp+0x10]
0000740ecffe01e5  vmovaps xmm2, [rsp+0x20]
0000740ecffe01eb  vmovaps xmm3, [rsp+0x30]
0000740ecffe01f1  vmovaps xmm4, [rsp+0x40]
0000740ecffe01f7  vmovaps xmm5, [rsp+0x50]
0000740ecffe01fd  vmovaps xmm7, [rsp+0x60]
0000740ecffe0203  vmovaps xmm8, [rsp+0x70]
0000740ecffe0209  vmovaps xmm9, [rsp+0x80]
0000740ecffe0212  vmovaps xmm10, [rsp+0x90]
0000740ecffe021b  vmovaps xmm11, [rsp+0xA0]
0000740ecffe0224  vmovaps xmm12, [rsp+0xB0]
0000740ecffe022d  vmovaps xmm13, [rsp+0xC0]
0000740ecffe0236  vmovaps xmm14, [rsp+0xD0]
0000740ecffe023f  vmovaps xmm15, [rsp+0xE0]
0000740ecffe0248  add rsp, 0xF0
0000740ecffe024f  pop r11
0000740ecffe0251  pop r10
0000740ecffe0253  pop r9
0000740ecffe0255  pop r8
0000740ecffe0257  pop rsi
0000740ecffe0258  pop rdi
0000740ecffe0259  pop rdx
0000740ecffe025a  pop rcx
0000740ecffe025b  pop rax
0000740ecffe025c  add rsp, 0x08
0000740ecffe0260  jmp 0x0000740ECFFDC58D
0000740ecffe0265  sub rsp, 0x08
0000740ecffe0269  push rax
0000740ecffe026a  push rcx
0000740ecffe026b  push rdx
0000740ecffe026c  push rdi
0000740ecffe026d  push rsi
0000740ecffe026e  push r8
0000740ecffe0270  push r9
0000740ecffe0272  push r10
0000740ecffe0274  push r11
0000740ecffe0276  sub rsp, 0xF0
0000740ecffe027d  vmovaps [rsp], xmm0
0000740ecffe0282  vmovaps [rsp+0x10], xmm1
0000740ecffe0288  vmovaps [rsp+0x20], xmm2
0000740ecffe028e  vmovaps [rsp+0x30], xmm3
0000740ecffe0294  vmovaps [rsp+0x40], xmm4
0000740ecffe029a  vmovaps [rsp+0x50], xmm5
0000740ecffe02a0  vmovaps [rsp+0x60], xmm6
0000740ecffe02a6  vmovaps [rsp+0x70], xmm7
0000740ecffe02ac  vmovaps [rsp+0x80], xmm8
0000740ecffe02b5  vmovaps [rsp+0x90], xmm9
0000740ecffe02be  vmovaps [rsp+0xA0], xmm10
0000740ecffe02c7  vmovaps [rsp+0xB0], xmm11
0000740ecffe02d0  vmovaps [rsp+0xC0], xmm12
0000740ecffe02d9  vmovaps [rsp+0xD0], xmm13
0000740ecffe02e2  vmovaps [rsp+0xE0], xmm15
0000740ecffe02eb  sub rsp, 0x30
0000740ecffe02ef  movaps [rsp], xmm14
0000740ecffe02f4  movaps [rsp+0x10], xmm12
0000740ecffe02fa  movaps [rsp+0x20], xmm1
0000740ecffe02ff  lea rdi, [rsp]
0000740ecffe0303  mov esi, 0x00
0000740ecffe0308  mov rax, 0x5E8249CF1530
0000740ecffe0312  call rax
0000740ecffe0314  movaps xmm14, [rsp]
0000740ecffe0319  add rsp, 0x30
0000740ecffe031d  vmovaps xmm0, [rsp]
0000740ecffe0322  vmovaps xmm1, [rsp+0x10]
0000740ecffe0328  vmovaps xmm2, [rsp+0x20]
0000740ecffe032e  vmovaps xmm3, [rsp+0x30]
0000740ecffe0334  vmovaps xmm4, [rsp+0x40]
0000740ecffe033a  vmovaps xmm5, [rsp+0x50]
0000740ecffe0340  vmovaps xmm6, [rsp+0x60]
0000740ecffe0346  vmovaps xmm7, [rsp+0x70]
0000740ecffe034c  vmovaps xmm8, [rsp+0x80]
0000740ecffe0355  vmovaps xmm9, [rsp+0x90]
0000740ecffe035e  vmovaps xmm10, [rsp+0xA0]
0000740ecffe0367  vmovaps xmm11, [rsp+0xB0]
0000740ecffe0370  vmovaps xmm12, [rsp+0xC0]
0000740ecffe0379  vmovaps xmm13, [rsp+0xD0]
0000740ecffe0382  vmovaps xmm15, [rsp+0xE0]
0000740ecffe038b  add rsp, 0xF0
0000740ecffe0392  pop r11
0000740ecffe0394  pop r10
0000740ecffe0396  pop r9
0000740ecffe0398  pop r8
0000740ecffe039a  pop rsi
0000740ecffe039b  pop rdi
0000740ecffe039c  pop rdx
0000740ecffe039d  pop rcx
0000740ecffe039e  pop rax
0000740ecffe039f  add rsp, 0x08
0000740ecffe03a3  jmp 0x0000740ECFFDC5B3
0000740ecffe03a8  sub rsp, 0x08
0000740ecffe03ac  push rax
0000740ecffe03ad  push rcx
0000740ecffe03ae  push rdx
0000740ecffe03af  push rdi
0000740ecffe03b0  push rsi
0000740ecffe03b1  push r8
0000740ecffe03b3  push r9
0000740ecffe03b5  push r10
0000740ecffe03b7  push r11
0000740ecffe03b9  sub rsp, 0xF0
0000740ecffe03c0  vmovaps [rsp], xmm0
0000740ecffe03c5  vmovaps [rsp+0x10], xmm2
0000740ecffe03cb  vmovaps [rsp+0x20], xmm3
0000740ecffe03d1  vmovaps [rsp+0x30], xmm4
0000740ecffe03d7  vmovaps [rsp+0x40], xmm5
0000740ecffe03dd  vmovaps [rsp+0x50], xmm6
0000740ecffe03e3  vmovaps [rsp+0x60], xmm7
0000740ecffe03e9  vmovaps [rsp+0x70], xmm8
0000740ecffe03ef  vmovaps [rsp+0x80], xmm9
0000740ecffe03f8  vmovaps [rsp+0x90], xmm10
0000740ecffe0401  vmovaps [rsp+0xA0], xmm11
0000740ecffe040a  vmovaps [rsp+0xB0], xmm12
0000740ecffe0413  vmovaps [rsp+0xC0], xmm13
0000740ecffe041c  vmovaps [rsp+0xD0], xmm14
0000740ecffe0425  vmovaps [rsp+0xE0], xmm15
0000740ecffe042e  sub rsp, 0x30
0000740ecffe0432  movaps [rsp], xmm1
0000740ecffe0436  movaps [rsp+0x10], xmm13
0000740ecffe043c  movaps [rsp+0x20], xmm9
0000740ecffe0442  lea rdi, [rsp]
0000740ecffe0446  mov esi, 0x00
0000740ecffe044b  mov rax, 0x5E8249CF1530
0000740ecffe0455  call rax
0000740ecffe0457  movaps xmm1, [rsp]
0000740ecffe045b  add rsp, 0x30
0000740ecffe045f  vmovaps xmm0, [rsp]
0000740ecffe0464  vmovaps xmm2, [rsp+0x10]
0000740ecffe046a  vmovaps xmm3, [rsp+0x20]
0000740ecffe0470  vmovaps xmm4, [rsp+0x30]
0000740ecffe0476  vmovaps xmm5, [rsp+0x40]
0000740ecffe047c  vmovaps xmm6, [rsp+0x50]
0000740ecffe0482  vmovaps xmm7, [rsp+0x60]
0000740ecffe0488  vmovaps xmm8, [rsp+0x70]
0000740ecffe048e  vmovaps xmm9, [rsp+0x80]
0000740ecffe0497  vmovaps xmm10, [rsp+0x90]
0000740ecffe04a0  vmovaps xmm11, [rsp+0xA0]
0000740ecffe04a9  vmovaps xmm12, [rsp+0xB0]
0000740ecffe04b2  vmovaps xmm13, [rsp+0xC0]
0000740ecffe04bb  vmovaps xmm14, [rsp+0xD0]
0000740ecffe04c4  vmovaps xmm15, [rsp+0xE0]
0000740ecffe04cd  add rsp, 0xF0
0000740ecffe04d4  pop r11
0000740ecffe04d6  pop r10
0000740ecffe04d8  pop r9
0000740ecffe04da  pop r8
0000740ecffe04dc  pop rsi
0000740ecffe04dd  pop rdi
0000740ecffe04de  pop rdx
0000740ecffe04df  pop rcx
0000740ecffe04e0  pop rax
0000740ecffe04e1  add rsp, 0x08
0000740ecffe04e5  jmp 0x0000740ECFFDC5CD
0000740ecffe04ea  sub rsp, 0x08
0000740ecffe04ee  push rax
0000740ecffe04ef  push rcx
0000740ecffe04f0  push rdx
0000740ecffe04f1  push rdi
0000740ecffe04f2  push rsi
0000740ecffe04f3  push r8
0000740ecffe04f5  push r9
0000740ecffe04f7  push r10
0000740ecffe04f9  push r11
0000740ecffe04fb  sub rsp, 0xF0
0000740ecffe0502  vmovaps [rsp], xmm0
0000740ecffe0507  vmovaps [rsp+0x10], xmm1
0000740ecffe050d  vmovaps [rsp+0x20], xmm2
0000740ecffe0513  vmovaps [rsp+0x30], xmm3
0000740ecffe0519  vmovaps [rsp+0x40], xmm4
0000740ecffe051f  vmovaps [rsp+0x50], xmm5
0000740ecffe0525  vmovaps [rsp+0x60], xmm6
0000740ecffe052b  vmovaps [rsp+0x70], xmm7
0000740ecffe0531  vmovaps [rsp+0x80], xmm8
0000740ecffe053a  vmovaps [rsp+0x90], xmm9
0000740ecffe0543  vmovaps [rsp+0xA0], xmm10
0000740ecffe054c  vmovaps [rsp+0xB0], xmm11
0000740ecffe0555  vmovaps [rsp+0xC0], xmm13
0000740ecffe055e  vmovaps [rsp+0xD0], xmm14
0000740ecffe0567  vmovaps [rsp+0xE0], xmm15
0000740ecffe0570  sub rsp, 0x30
0000740ecffe0574  movaps [rsp], xmm12
0000740ecffe0579  movaps [rsp+0x10], xmm7
0000740ecffe057e  movaps [rsp+0x20], xmm13
0000740ecffe0584  lea rdi, [rsp]
0000740ecffe0588  mov esi, 0x00
0000740ecffe058d  mov rax, 0x5E8249CF1530
0000740ecffe0597  call rax
0000740ecffe0599  movaps xmm12, [rsp]
0000740ecffe059e  add rsp, 0x30
0000740ecffe05a2  vmovaps xmm0, [rsp]
0000740ecffe05a7  vmovaps xmm1, [rsp+0x10]
0000740ecffe05ad  vmovaps xmm2, [rsp+0x20]
0000740ecffe05b3  vmovaps xmm3, [rsp+0x30]
0000740ecffe05b9  vmovaps xmm4, [rsp+0x40]
0000740ecffe05bf  vmovaps xmm5, [rsp+0x50]
0000740ecffe05c5  vmovaps xmm6, [rsp+0x60]
0000740ecffe05cb  vmovaps xmm7, [rsp+0x70]
0000740ecffe05d1  vmovaps xmm8, [rsp+0x80]
0000740ecffe05da  vmovaps xmm9, [rsp+0x90]
0000740ecffe05e3  vmovaps xmm10, [rsp+0xA0]
0000740ecffe05ec  vmovaps xmm11, [rsp+0xB0]
0000740ecffe05f5  vmovaps xmm13, [rsp+0xC0]
0000740ecffe05fe  vmovaps xmm14, [rsp+0xD0]
0000740ecffe0607  vmovaps xmm15, [rsp+0xE0]
0000740ecffe0610  add rsp, 0xF0
0000740ecffe0617  pop r11
0000740ecffe0619  pop r10
0000740ecffe061b  pop r9
0000740ecffe061d  pop r8
0000740ecffe061f  pop rsi
0000740ecffe0620  pop rdi
0000740ecffe0621  pop rdx
0000740ecffe0622  pop rcx
0000740ecffe0623  pop rax
0000740ecffe0624  add rsp, 0x08
0000740ecffe0628  jmp 0x0000740ECFFDC5F4
0000740ecffe062d  sub rsp, 0x08
0000740ecffe0631  push rax
0000740ecffe0632  push rcx
0000740ecffe0633  push rdx
0000740ecffe0634  push rdi
0000740ecffe0635  push rsi
0000740ecffe0636  push r8
0000740ecffe0638  push r9
0000740ecffe063a  push r10
0000740ecffe063c  push r11
0000740ecffe063e  sub rsp, 0xF0
0000740ecffe0645  vmovaps [rsp], xmm0
0000740ecffe064a  vmovaps [rsp+0x10], xmm1
0000740ecffe0650  vmovaps [rsp+0x20], xmm2
0000740ecffe0656  vmovaps [rsp+0x30], xmm3
0000740ecffe065c  vmovaps [rsp+0x40], xmm4
0000740ecffe0662  vmovaps [rsp+0x50], xmm5
0000740ecffe0668  vmovaps [rsp+0x60], xmm6
0000740ecffe066e  vmovaps [rsp+0x70], xmm7
0000740ecffe0674  vmovaps [rsp+0x80], xmm8
0000740ecffe067d  vmovaps [rsp+0x90], xmm9
0000740ecffe0686  vmovaps [rsp+0xA0], xmm10
0000740ecffe068f  vmovaps [rsp+0xB0], xmm11
0000740ecffe0698  vmovaps [rsp+0xC0], xmm12
0000740ecffe06a1  vmovaps [rsp+0xD0], xmm14
0000740ecffe06aa  vmovaps [rsp+0xE0], xmm15
0000740ecffe06b3  sub rsp, 0x30
0000740ecffe06b7  movaps [rsp], xmm13
0000740ecffe06bc  movaps [rsp+0x10], xmm15
0000740ecffe06c2  movaps [rsp+0x20], xmm8
0000740ecffe06c8  lea rdi, [rsp]
0000740ecffe06cc  mov esi, 0x00
0000740ecffe06d1  mov rax, 0x5E8249CF1530
0000740ecffe06db  call rax
0000740ecffe06dd  movaps xmm13, [rsp]
0000740ecffe06e2  add rsp, 0x30
0000740ecffe06e6  vmovaps xmm0, [rsp]
0000740ecffe06eb  vmovaps xmm1, [rsp+0x10]
0000740ecffe06f1  vmovaps xmm2, [rsp+0x20]
0000740ecffe06f7  vmovaps xmm3, [rsp+0x30]
0000740ecffe06fd  vmovaps xmm4, [rsp+0x40]
0000740ecffe0703  vmovaps xmm5, [rsp+0x50]
0000740ecffe0709  vmovaps xmm6, [rsp+0x60]
0000740ecffe070f  vmovaps xmm7, [rsp+0x70]
0000740ecffe0715  vmovaps xmm8, [rsp+0x80]
0000740ecffe071e  vmovaps xmm9, [rsp+0x90]
0000740ecffe0727  vmovaps xmm10, [rsp+0xA0]
0000740ecffe0730  vmovaps xmm11, [rsp+0xB0]
0000740ecffe0739  vmovaps xmm12, [rsp+0xC0]
0000740ecffe0742  vmovaps xmm14, [rsp+0xD0]
0000740ecffe074b  vmovaps xmm15, [rsp+0xE0]
0000740ecffe0754  add rsp, 0xF0
0000740ecffe075b  pop r11
0000740ecffe075d  pop r10
0000740ecffe075f  pop r9
0000740ecffe0761  pop r8
0000740ecffe0763  pop rsi
0000740ecffe0764  pop rdi
0000740ecffe0765  pop rdx
0000740ecffe0766  pop rcx
0000740ecffe0767  pop rax
0000740ecffe0768  add rsp, 0x08
0000740ecffe076c  jmp 0x0000740ECFFDC60F
0000740ecffe0771  sub rsp, 0x08
0000740ecffe0775  push rax
0000740ecffe0776  push rcx
0000740ecffe0777  push rdx
0000740ecffe0778  push rdi
0000740ecffe0779  push rsi
0000740ecffe077a  push r8
0000740ecffe077c  push r9
0000740ecffe077e  push r10
0000740ecffe0780  push r11
0000740ecffe0782  sub rsp, 0xF0
0000740ecffe0789  vmovaps [rsp], xmm0
0000740ecffe078e  vmovaps [rsp+0x10], xmm1
0000740ecffe0794  vmovaps [rsp+0x20], xmm2
0000740ecffe079a  vmovaps [rsp+0x30], xmm3
0000740ecffe07a0  vmovaps [rsp+0x40], xmm4
0000740ecffe07a6  vmovaps [rsp+0x50], xmm5
0000740ecffe07ac  vmovaps [rsp+0x60], xmm6
0000740ecffe07b2  vmovaps [rsp+0x70], xmm7
0000740ecffe07b8  vmovaps [rsp+0x80], xmm9
0000740ecffe07c1  vmovaps [rsp+0x90], xmm10
0000740ecffe07ca  vmovaps [rsp+0xA0], xmm11
0000740ecffe07d3  vmovaps [rsp+0xB0], xmm12
0000740ecffe07dc  vmovaps [rsp+0xC0], xmm13
0000740ecffe07e5  vmovaps [rsp+0xD0], xmm14
0000740ecffe07ee  vmovaps [rsp+0xE0], xmm15
0000740ecffe07f7  sub rsp, 0x30
0000740ecffe07fb  movaps [rsp], xmm8
0000740ecffe0800  movaps [rsp+0x10], xmm15
0000740ecffe0806  movaps [rsp+0x20], xmm9
0000740ecffe080c  lea rdi, [rsp]
0000740ecffe0810  mov esi, 0x00
0000740ecffe0815  mov rax, 0x5E8249CF1530
0000740ecffe081f  call rax
0000740ecffe0821  movaps xmm8, [rsp]
0000740ecffe0826  add rsp, 0x30
0000740ecffe082a  vmovaps xmm0, [rsp]
0000740ecffe082f  vmovaps xmm1, [rsp+0x10]
0000740ecffe0835  vmovaps xmm2, [rsp+0x20]
0000740ecffe083b  vmovaps xmm3, [rsp+0x30]
0000740ecffe0841  vmovaps xmm4, [rsp+0x40]
0000740ecffe0847  vmovaps xmm5, [rsp+0x50]
0000740ecffe084d  vmovaps xmm6, [rsp+0x60]
0000740ecffe0853  vmovaps xmm7, [rsp+0x70]
0000740ecffe0859  vmovaps xmm9, [rsp+0x80]
0000740ecffe0862  vmovaps xmm10, [rsp+0x90]
0000740ecffe086b  vmovaps xmm11, [rsp+0xA0]
0000740ecffe0874  vmovaps xmm12, [rsp+0xB0]
0000740ecffe087d  vmovaps xmm13, [rsp+0xC0]
0000740ecffe0886  vmovaps xmm14, [rsp+0xD0]
0000740ecffe088f  vmovaps xmm15, [rsp+0xE0]
0000740ecffe0898  add rsp, 0xF0
0000740ecffe089f  pop r11
0000740ecffe08a1  pop r10
0000740ecffe08a3  pop r9
0000740ecffe08a5  pop r8
0000740ecffe08a7  pop rsi
0000740ecffe08a8  pop rdi
0000740ecffe08a9  pop rdx
0000740ecffe08aa  pop rcx
0000740ecffe08ab  pop rax
0000740ecffe08ac  add rsp, 0x08
0000740ecffe08b0  jmp 0x0000740ECFFDC63D
0000740ecffe08b5  sub rsp, 0x08
0000740ecffe08b9  push rax
0000740ecffe08ba  push rcx
0000740ecffe08bb  push rdx
0000740ecffe08bc  push rdi
0000740ecffe08bd  push rsi
0000740ecffe08be  push r8
0000740ecffe08c0  push r9
0000740ecffe08c2  push r10
0000740ecffe08c4  push r11
0000740ecffe08c6  sub rsp, 0xF0
0000740ecffe08cd  vmovaps [rsp], xmm0
0000740ecffe08d2  vmovaps [rsp+0x10], xmm1
0000740ecffe08d8  vmovaps [rsp+0x20], xmm2
0000740ecffe08de  vmovaps [rsp+0x30], xmm3
0000740ecffe08e4  vmovaps [rsp+0x40], xmm4
0000740ecffe08ea  vmovaps [rsp+0x50], xmm5
0000740ecffe08f0  vmovaps [rsp+0x60], xmm6
0000740ecffe08f6  vmovaps [rsp+0x70], xmm7
0000740ecffe08fc  vmovaps [rsp+0x80], xmm8
0000740ecffe0905  vmovaps [rsp+0x90], xmm9
0000740ecffe090e  vmovaps [rsp+0xA0], xmm10
0000740ecffe0917  vmovaps [rsp+0xB0], xmm11
0000740ecffe0920  vmovaps [rsp+0xC0], xmm12
0000740ecffe0929  vmovaps [rsp+0xD0], xmm13
0000740ecffe0932  vmovaps [rsp+0xE0], xmm14
0000740ecffe093b  sub rsp, 0x30
0000740ecffe093f  movaps [rsp], xmm15
0000740ecffe0944  movaps [rsp+0x10], xmm11
0000740ecffe094a  movaps [rsp+0x20], xmm6
0000740ecffe094f  lea rdi, [rsp]
0000740ecffe0953  mov esi, 0x00
0000740ecffe0958  mov rax, 0x5E8249CF1530
0000740ecffe0962  call rax
0000740ecffe0964  movaps xmm15, [rsp]
0000740ecffe0969  add rsp, 0x30
0000740ecffe096d  vmovaps xmm0, [rsp]
0000740ecffe0972  vmovaps xmm1, [rsp+0x10]
0000740ecffe0978  vmovaps xmm2, [rsp+0x20]
0000740ecffe097e  vmovaps xmm3, [rsp+0x30]
0000740ecffe0984  vmovaps xmm4, [rsp+0x40]
0000740ecffe098a  vmovaps xmm5, [rsp+0x50]
0000740ecffe0990  vmovaps xmm6, [rsp+0x60]
0000740ecffe0996  vmovaps xmm7, [rsp+0x70]
0000740ecffe099c  vmovaps xmm8, [rsp+0x80]
0000740ecffe09a5  vmovaps xmm9, [rsp+0x90]
0000740ecffe09ae  vmovaps xmm10, [rsp+0xA0]
0000740ecffe09b7  vmovaps xmm11, [rsp+0xB0]
0000740ecffe09c0  vmovaps xmm12, [rsp+0xC0]
0000740ecffe09c9  vmovaps xmm13, [rsp+0xD0]
0000740ecffe09d2  vmovaps xmm14, [rsp+0xE0]
0000740ecffe09db  add rsp, 0xF0
0000740ecffe09e2  pop r11
0000740ecffe09e4  pop r10
0000740ecffe09e6  pop r9
0000740ecffe09e8  pop r8
0000740ecffe09ea  pop rsi
0000740ecffe09eb  pop rdi
0000740ecffe09ec  pop rdx
0000740ecffe09ed  pop rcx
0000740ecffe09ee  pop rax
0000740ecffe09ef  add rsp, 0x08
0000740ecffe09f3  jmp 0x0000740ECFFDC658
0000740ecffe09f8  sub rsp, 0x08
0000740ecffe09fc  push rax
0000740ecffe09fd  push rcx
0000740ecffe09fe  push rdx
0000740ecffe09ff  push rdi
0000740ecffe0a00  push rsi
0000740ecffe0a01  push r8
0000740ecffe0a03  push r9
0000740ecffe0a05  push r10
0000740ecffe0a07  push r11
0000740ecffe0a09  sub rsp, 0xF0
0000740ecffe0a10  vmovaps [rsp], xmm0
0000740ecffe0a15  vmovaps [rsp+0x10], xmm1
0000740ecffe0a1b  vmovaps [rsp+0x20], xmm2
0000740ecffe0a21  vmovaps [rsp+0x30], xmm3
0000740ecffe0a27  vmovaps [rsp+0x40], xmm4
0000740ecffe0a2d  vmovaps [rsp+0x50], xmm5
0000740ecffe0a33  vmovaps [rsp+0x60], xmm6
0000740ecffe0a39  vmovaps [rsp+0x70], xmm8
0000740ecffe0a3f  vmovaps [rsp+0x80], xmm9
0000740ecffe0a48  vmovaps [rsp+0x90], xmm10
0000740ecffe0a51  vmovaps [rsp+0xA0], xmm11
0000740ecffe0a5a  vmovaps [rsp+0xB0], xmm12
0000740ecffe0a63  vmovaps [rsp+0xC0], xmm13
0000740ecffe0a6c  vmovaps [rsp+0xD0], xmm14
0000740ecffe0a75  vmovaps [rsp+0xE0], xmm15
0000740ecffe0a7e  sub rsp, 0x30
0000740ecffe0a82  movaps [rsp], xmm7
0000740ecffe0a86  movaps [rsp+0x10], xmm11
0000740ecffe0a8c  movaps [rsp+0x20], xmm9
0000740ecffe0a92  lea rdi, [rsp]
0000740ecffe0a96  mov esi, 0x00
0000740ecffe0a9b  mov rax, 0x5E8249CF1530
0000740ecffe0aa5  call rax
0000740ecffe0aa7  movaps xmm7, [rsp]
0000740ecffe0aab  add rsp, 0x30
0000740ecffe0aaf  vmovaps xmm0, [rsp]
0000740ecffe0ab4  vmovaps xmm1, [rsp+0x10]
0000740ecffe0aba  vmovaps xmm2, [rsp+0x20]
0000740ecffe0ac0  vmovaps xmm3, [rsp+0x30]
0000740ecffe0ac6  vmovaps xmm4, [rsp+0x40]
0000740ecffe0acc  vmovaps xmm5, [rsp+0x50]
0000740ecffe0ad2  vmovaps xmm6, [rsp+0x60]
0000740ecffe0ad8  vmovaps xmm8, [rsp+0x70]
0000740ecffe0ade  vmovaps xmm9, [rsp+0x80]
0000740ecffe0ae7  vmovaps xmm10, [rsp+0x90]
0000740ecffe0af0  vmovaps xmm11, [rsp+0xA0]
0000740ecffe0af9  vmovaps xmm12, [rsp+0xB0]
0000740ecffe0b02  vmovaps xmm13, [rsp+0xC0]
0000740ecffe0b0b  vmovaps xmm14, [rsp+0xD0]
0000740ecffe0b14  vmovaps xmm15, [rsp+0xE0]
0000740ecffe0b1d  add rsp, 0xF0
0000740ecffe0b24  pop r11
0000740ecffe0b26  pop r10
0000740ecffe0b28  pop r9
0000740ecffe0b2a  pop r8
0000740ecffe0b2c  pop rsi
0000740ecffe0b2d  pop rdi
0000740ecffe0b2e  pop rdx
0000740ecffe0b2f  pop rcx
0000740ecffe0b30  pop rax
0000740ecffe0b31  add rsp, 0x08
0000740ecffe0b35  jmp 0x0000740ECFFDC685
0000740ecffe0b3a  sub rsp, 0x08
0000740ecffe0b3e  push rax
0000740ecffe0b3f  push rcx
0000740ecffe0b40  push rdx
0000740ecffe0b41  push rdi
0000740ecffe0b42  push rsi
0000740ecffe0b43  push r8
0000740ecffe0b45  push r9
0000740ecffe0b47  push r10
0000740ecffe0b49  push r11
0000740ecffe0b4b  sub rsp, 0xF0
0000740ecffe0b52  vmovaps [rsp], xmm0
0000740ecffe0b57  vmovaps [rsp+0x10], xmm1
0000740ecffe0b5d  vmovaps [rsp+0x20], xmm2
0000740ecffe0b63  vmovaps [rsp+0x30], xmm3
0000740ecffe0b69  vmovaps [rsp+0x40], xmm4
0000740ecffe0b6f  vmovaps [rsp+0x50], xmm5
0000740ecffe0b75  vmovaps [rsp+0x60], xmm6
0000740ecffe0b7b  vmovaps [rsp+0x70], xmm7
0000740ecffe0b81  vmovaps [rsp+0x80], xmm8
0000740ecffe0b8a  vmovaps [rsp+0x90], xmm9
0000740ecffe0b93  vmovaps [rsp+0xA0], xmm10
0000740ecffe0b9c  vmovaps [rsp+0xB0], xmm12
0000740ecffe0ba5  vmovaps [rsp+0xC0], xmm13
0000740ecffe0bae  vmovaps [rsp+0xD0], xmm14
0000740ecffe0bb7  vmovaps [rsp+0xE0], xmm15
0000740ecffe0bc0  sub rsp, 0x30
0000740ecffe0bc4  movaps [rsp], xmm11
0000740ecffe0bc9  movaps [rsp+0x10], xmm10
0000740ecffe0bcf  movaps [rsp+0x20], xmm14
0000740ecffe0bd5  lea rdi, [rsp]
0000740ecffe0bd9  mov esi, 0x00
0000740ecffe0bde  mov rax, 0x5E8249CF1530
0000740ecffe0be8  call rax
0000740ecffe0bea  movaps xmm11, [rsp]
0000740ecffe0bef  add rsp, 0x30
0000740ecffe0bf3  vmovaps xmm0, [rsp]
0000740ecffe0bf8  vmovaps xmm1, [rsp+0x10]
0000740ecffe0bfe  vmovaps xmm2, [rsp+0x20]
0000740ecffe0c04  vmovaps xmm3, [rsp+0x30]
0000740ecffe0c0a  vmovaps xmm4, [rsp+0x40]
0000740ecffe0c10  vmovaps xmm5, [rsp+0x50]
0000740ecffe0c16  vmovaps xmm6, [rsp+0x60]
0000740ecffe0c1c  vmovaps xmm7, [rsp+0x70]
0000740ecffe0c22  vmovaps xmm8, [rsp+0x80]
0000740ecffe0c2b  vmovaps xmm9, [rsp+0x90]
0000740ecffe0c34  vmovaps xmm10, [rsp+0xA0]
0000740ecffe0c3d  vmovaps xmm12, [rsp+0xB0]
0000740ecffe0c46  vmovaps xmm13, [rsp+0xC0]
0000740ecffe0c4f  vmovaps xmm14, [rsp+0xD0]
0000740ecffe0c58  vmovaps xmm15, [rsp+0xE0]
0000740ecffe0c61  add rsp, 0xF0
0000740ecffe0c68  pop r11
0000740ecffe0c6a  pop r10
0000740ecffe0c6c  pop r9
0000740ecffe0c6e  pop r8
0000740ecffe0c70  pop rsi
0000740ecffe0c71  pop rdi
0000740ecffe0c72  pop rdx
0000740ecffe0c73  pop rcx
0000740ecffe0c74  pop rax
0000740ecffe0c75  add rsp, 0x08
0000740ecffe0c79  jmp 0x0000740ECFFDC6A0
0000740ecffe0c7e  call 0x0000740ECFEC33A0
0000740ecffe0c83  jmp 0x0000740ECFFDC6AA
0000740ecffe0c88  sub rsp, 0x08
0000740ecffe0c8c  push rax
0000740ecffe0c8d  push rcx
0000740ecffe0c8e  push rdx
0000740ecffe0c8f  push rdi
0000740ecffe0c90  push rsi
0000740ecffe0c91  push r8
0000740ecffe0c93  push r9
0000740ecffe0c95  push r10
0000740ecffe0c97  push r11
0000740ecffe0c99  sub rsp, 0xF0
0000740ecffe0ca0  vmovaps [rsp], xmm0
0000740ecffe0ca5  vmovaps [rsp+0x10], xmm1
0000740ecffe0cab  vmovaps [rsp+0x20], xmm2
0000740ecffe0cb1  vmovaps [rsp+0x30], xmm3
0000740ecffe0cb7  vmovaps [rsp+0x40], xmm4
0000740ecffe0cbd  vmovaps [rsp+0x50], xmm5
0000740ecffe0cc3  vmovaps [rsp+0x60], xmm6
0000740ecffe0cc9  vmovaps [rsp+0x70], xmm7
0000740ecffe0ccf  vmovaps [rsp+0x80], xmm8
0000740ecffe0cd8  vmovaps [rsp+0x90], xmm9
0000740ecffe0ce1  vmovaps [rsp+0xA0], xmm11
0000740ecffe0cea  vmovaps [rsp+0xB0], xmm12
0000740ecffe0cf3  vmovaps [rsp+0xC0], xmm13
0000740ecffe0cfc  vmovaps [rsp+0xD0], xmm14
0000740ecffe0d05  vmovaps [rsp+0xE0], xmm15
0000740ecffe0d0e  sub rsp, 0x30
0000740ecffe0d12  movaps [rsp], xmm10
0000740ecffe0d17  movaps [rsp+0x10], xmm1
0000740ecffe0d1c  movaps [rsp+0x20], xmm12
0000740ecffe0d22  lea rdi, [rsp]
0000740ecffe0d26  mov esi, 0x00
0000740ecffe0d2b  mov rax, 0x5E8249CF1530
0000740ecffe0d35  call rax
0000740ecffe0d37  movaps xmm10, [rsp]
0000740ecffe0d3c  add rsp, 0x30
0000740ecffe0d40  vmovaps xmm0, [rsp]
0000740ecffe0d45  vmovaps xmm1, [rsp+0x10]
0000740ecffe0d4b  vmovaps xmm2, [rsp+0x20]
0000740ecffe0d51  vmovaps xmm3, [rsp+0x30]
0000740ecffe0d57  vmovaps xmm4, [rsp+0x40]
0000740ecffe0d5d  vmovaps xmm5, [rsp+0x50]
0000740ecffe0d63  vmovaps xmm6, [rsp+0x60]
0000740ecffe0d69  vmovaps xmm7, [rsp+0x70]
0000740ecffe0d6f  vmovaps xmm8, [rsp+0x80]
0000740ecffe0d78  vmovaps xmm9, [rsp+0x90]
0000740ecffe0d81  vmovaps xmm11, [rsp+0xA0]
0000740ecffe0d8a  vmovaps xmm12, [rsp+0xB0]
0000740ecffe0d93  vmovaps xmm13, [rsp+0xC0]
0000740ecffe0d9c  vmovaps xmm14, [rsp+0xD0]
0000740ecffe0da5  vmovaps xmm15, [rsp+0xE0]
0000740ecffe0dae  add rsp, 0xF0
0000740ecffe0db5  pop r11
0000740ecffe0db7  pop r10
0000740ecffe0db9  pop r9
0000740ecffe0dbb  pop r8
0000740ecffe0dbd  pop rsi
0000740ecffe0dbe  pop rdi
0000740ecffe0dbf  pop rdx
0000740ecffe0dc0  pop rcx
0000740ecffe0dc1  pop rax
0000740ecffe0dc2  add rsp, 0x08
0000740ecffe0dc6  jmp 0x0000740ECFFDC6CD
0000740ecffe0dcb  sub rsp, 0x08
0000740ecffe0dcf  push rax
0000740ecffe0dd0  push rcx
0000740ecffe0dd1  push rdx
0000740ecffe0dd2  push rdi
0000740ecffe0dd3  push rsi
0000740ecffe0dd4  push r8
0000740ecffe0dd6  push r9
0000740ecffe0dd8  push r10
0000740ecffe0dda  push r11
0000740ecffe0ddc  sub rsp, 0xF0
0000740ecffe0de3  vmovaps [rsp], xmm0
0000740ecffe0de8  vmovaps [rsp+0x10], xmm1
0000740ecffe0dee  vmovaps [rsp+0x20], xmm2
0000740ecffe0df4  vmovaps [rsp+0x30], xmm3
0000740ecffe0dfa  vmovaps [rsp+0x40], xmm4
0000740ecffe0e00  vmovaps [rsp+0x50], xmm5
0000740ecffe0e06  vmovaps [rsp+0x60], xmm6
0000740ecffe0e0c  vmovaps [rsp+0x70], xmm7
0000740ecffe0e12  vmovaps [rsp+0x80], xmm8
0000740ecffe0e1b  vmovaps [rsp+0x90], xmm9
0000740ecffe0e24  vmovaps [rsp+0xA0], xmm10
0000740ecffe0e2d  vmovaps [rsp+0xB0], xmm11
0000740ecffe0e36  vmovaps [rsp+0xC0], xmm13
0000740ecffe0e3f  vmovaps [rsp+0xD0], xmm14
0000740ecffe0e48  vmovaps [rsp+0xE0], xmm15
0000740ecffe0e51  sub rsp, 0x30
0000740ecffe0e55  movaps [rsp], xmm12
0000740ecffe0e5a  movaps [rsp+0x10], xmm14
0000740ecffe0e60  movaps [rsp+0x20], xmm1
0000740ecffe0e65  lea rdi, [rsp]
0000740ecffe0e69  mov esi, 0x00
0000740ecffe0e6e  mov rax, 0x5E8249CF1530
0000740ecffe0e78  call rax
0000740ecffe0e7a  movaps xmm12, [rsp]
0000740ecffe0e7f  add rsp, 0x30
0000740ecffe0e83  vmovaps xmm0, [rsp]
0000740ecffe0e88  vmovaps xmm1, [rsp+0x10]
0000740ecffe0e8e  vmovaps xmm2, [rsp+0x20]
0000740ecffe0e94  vmovaps xmm3, [rsp+0x30]
0000740ecffe0e9a  vmovaps xmm4, [rsp+0x40]
0000740ecffe0ea0  vmovaps xmm5, [rsp+0x50]
0000740ecffe0ea6  vmovaps xmm6, [rsp+0x60]
0000740ecffe0eac  vmovaps xmm7, [rsp+0x70]
0000740ecffe0eb2  vmovaps xmm8, [rsp+0x80]
0000740ecffe0ebb  vmovaps xmm9, [rsp+0x90]
0000740ecffe0ec4  vmovaps xmm10, [rsp+0xA0]
0000740ecffe0ecd  vmovaps xmm11, [rsp+0xB0]
0000740ecffe0ed6  vmovaps xmm13, [rsp+0xC0]
0000740ecffe0edf  vmovaps xmm14, [rsp+0xD0]
0000740ecffe0ee8  vmovaps xmm15, [rsp+0xE0]
0000740ecffe0ef1  add rsp, 0xF0
0000740ecffe0ef8  pop r11
0000740ecffe0efa  pop r10
0000740ecffe0efc  pop r9
0000740ecffe0efe  pop r8
0000740ecffe0f00  pop rsi
0000740ecffe0f01  pop rdi
0000740ecffe0f02  pop rdx
0000740ecffe0f03  pop rcx
0000740ecffe0f04  pop rax
0000740ecffe0f05  add rsp, 0x08
0000740ecffe0f09  jmp 0x0000740ECFFDC6FC
0000740ecffe0f0e  sub rsp, 0x08
0000740ecffe0f12  push rax
0000740ecffe0f13  push rcx
0000740ecffe0f14  push rdx
0000740ecffe0f15  push rdi
0000740ecffe0f16  push rsi
0000740ecffe0f17  push r8
0000740ecffe0f19  push r9
0000740ecffe0f1b  push r10
0000740ecffe0f1d  push r11
0000740ecffe0f1f  sub rsp, 0xF0
0000740ecffe0f26  vmovaps [rsp], xmm0
0000740ecffe0f2b  vmovaps [rsp+0x10], xmm1
0000740ecffe0f31  vmovaps [rsp+0x20], xmm2
0000740ecffe0f37  vmovaps [rsp+0x30], xmm3
0000740ecffe0f3d  vmovaps [rsp+0x40], xmm4
0000740ecffe0f43  vmovaps [rsp+0x50], xmm5
0000740ecffe0f49  vmovaps [rsp+0x60], xmm6
0000740ecffe0f4f  vmovaps [rsp+0x70], xmm7
0000740ecffe0f55  vmovaps [rsp+0x80], xmm8
0000740ecffe0f5e  vmovaps [rsp+0x90], xmm9
0000740ecffe0f67  vmovaps [rsp+0xA0], xmm10
0000740ecffe0f70  vmovaps [rsp+0xB0], xmm11
0000740ecffe0f79  vmovaps [rsp+0xC0], xmm12
0000740ecffe0f82  vmovaps [rsp+0xD0], xmm13
0000740ecffe0f8b  vmovaps [rsp+0xE0], xmm15
0000740ecffe0f94  sub rsp, 0x30
0000740ecffe0f98  movaps [rsp], xmm14
0000740ecffe0f9d  movaps [rsp+0x10], xmm9
0000740ecffe0fa3  movaps [rsp+0x20], xmm1
0000740ecffe0fa8  lea rdi, [rsp]
0000740ecffe0fac  mov esi, 0x00
0000740ecffe0fb1  mov rax, 0x5E8249CF1530
0000740ecffe0fbb  call rax
0000740ecffe0fbd  movaps xmm14, [rsp]
0000740ecffe0fc2  add rsp, 0x30
0000740ecffe0fc6  vmovaps xmm0, [rsp]
0000740ecffe0fcb  vmovaps xmm1, [rsp+0x10]
0000740ecffe0fd1  vmovaps xmm2, [rsp+0x20]
0000740ecffe0fd7  vmovaps xmm3, [rsp+0x30]
0000740ecffe0fdd  vmovaps xmm4, [rsp+0x40]
0000740ecffe0fe3  vmovaps xmm5, [rsp+0x50]
0000740ecffe0fe9  vmovaps xmm6, [rsp+0x60]
0000740ecffe0fef  vmovaps xmm7, [rsp+0x70]
0000740ecffe0ff5  vmovaps xmm8, [rsp+0x80]
0000740ecffe0ffe  vmovaps xmm9, [rsp+0x90]
0000740ecffe1007  vmovaps xmm10, [rsp+0xA0]
0000740ecffe1010  vmovaps xmm11, [rsp+0xB0]
0000740ecffe1019  vmovaps xmm12, [rsp+0xC0]
0000740ecffe1022  vmovaps xmm13, [rsp+0xD0]
0000740ecffe102b  vmovaps xmm15, [rsp+0xE0]
0000740ecffe1034  add rsp, 0xF0
0000740ecffe103b  pop r11
0000740ecffe103d  pop r10
0000740ecffe103f  pop r9
0000740ecffe1041  pop r8
0000740ecffe1043  pop rsi
0000740ecffe1044  pop rdi
0000740ecffe1045  pop rdx
0000740ecffe1046  pop rcx
0000740ecffe1047  pop rax
0000740ecffe1048  add rsp, 0x08
0000740ecffe104c  jmp 0x0000740ECFFDC72B
0000740ecffe1051  sub rsp, 0x08
0000740ecffe1055  push rax
0000740ecffe1056  push rcx
0000740ecffe1057  push rdx
0000740ecffe1058  push rdi
0000740ecffe1059  push rsi
0000740ecffe105a  push r8
0000740ecffe105c  push r9
0000740ecffe105e  push r10
0000740ecffe1060  push r11
0000740ecffe1062  sub rsp, 0xF0
0000740ecffe1069  vmovaps [rsp], xmm0
0000740ecffe106e  vmovaps [rsp+0x10], xmm2
0000740ecffe1074  vmovaps [rsp+0x20], xmm3
0000740ecffe107a  vmovaps [rsp+0x30], xmm4
0000740ecffe1080  vmovaps [rsp+0x40], xmm5
0000740ecffe1086  vmovaps [rsp+0x50], xmm6
0000740ecffe108c  vmovaps [rsp+0x60], xmm7
0000740ecffe1092  vmovaps [rsp+0x70], xmm8
0000740ecffe1098  vmovaps [rsp+0x80], xmm9
0000740ecffe10a1  vmovaps [rsp+0x90], xmm10
0000740ecffe10aa  vmovaps [rsp+0xA0], xmm11
0000740ecffe10b3  vmovaps [rsp+0xB0], xmm12
0000740ecffe10bc  vmovaps [rsp+0xC0], xmm13
0000740ecffe10c5  vmovaps [rsp+0xD0], xmm14
0000740ecffe10ce  vmovaps [rsp+0xE0], xmm15
0000740ecffe10d7  sub rsp, 0x30
0000740ecffe10db  movaps [rsp], xmm1
0000740ecffe10df  movaps [rsp+0x10], xmm13
0000740ecffe10e5  movaps [rsp+0x20], xmm8
0000740ecffe10eb  lea rdi, [rsp]
0000740ecffe10ef  mov esi, 0x00
0000740ecffe10f4  mov rax, 0x5E8249CF1530
0000740ecffe10fe  call rax
0000740ecffe1100  movaps xmm1, [rsp]
0000740ecffe1104  add rsp, 0x30
0000740ecffe1108  vmovaps xmm0, [rsp]
0000740ecffe110d  vmovaps xmm2, [rsp+0x10]
0000740ecffe1113  vmovaps xmm3, [rsp+0x20]
0000740ecffe1119  vmovaps xmm4, [rsp+0x30]
0000740ecffe111f  vmovaps xmm5, [rsp+0x40]
0000740ecffe1125  vmovaps xmm6, [rsp+0x50]
0000740ecffe112b  vmovaps xmm7, [rsp+0x60]
0000740ecffe1131  vmovaps xmm8, [rsp+0x70]
0000740ecffe1137  vmovaps xmm9, [rsp+0x80]
0000740ecffe1140  vmovaps xmm10, [rsp+0x90]
0000740ecffe1149  vmovaps xmm11, [rsp+0xA0]
0000740ecffe1152  vmovaps xmm12, [rsp+0xB0]
0000740ecffe115b  vmovaps xmm13, [rsp+0xC0]
0000740ecffe1164  vmovaps xmm14, [rsp+0xD0]
0000740ecffe116d  vmovaps xmm15, [rsp+0xE0]
0000740ecffe1176  add rsp, 0xF0
0000740ecffe117d  pop r11
0000740ecffe117f  pop r10
0000740ecffe1181  pop r9
0000740ecffe1183  pop r8
0000740ecffe1185  pop rsi
0000740ecffe1186  pop rdi
0000740ecffe1187  pop rdx
0000740ecffe1188  pop rcx
0000740ecffe1189  pop rax
0000740ecffe118a  add rsp, 0x08
0000740ecffe118e  jmp 0x0000740ECFFDC74D
0000740ecffe1193  call 0x0000740ECFE0C260
0000740ecffe1198  jmp 0x0000740ECFFDC75B
0000740ecffe119d  call 0x0000740ECFEBD750
0000740ecffe11a2  jmp 0x0000740ECFFDC765
0000740ecffe11a7  sub rsp, 0x08
0000740ecffe11ab  push rax
0000740ecffe11ac  push rcx
0000740ecffe11ad  push rdx
0000740ecffe11ae  push rdi
0000740ecffe11af  push rsi
0000740ecffe11b0  push r8
0000740ecffe11b2  push r9
0000740ecffe11b4  push r10
0000740ecffe11b6  push r11
0000740ecffe11b8  sub rsp, 0xF0
0000740ecffe11bf  vmovaps [rsp], xmm0
0000740ecffe11c4  vmovaps [rsp+0x10], xmm1
0000740ecffe11ca  vmovaps [rsp+0x20], xmm2
0000740ecffe11d0  vmovaps [rsp+0x30], xmm3
0000740ecffe11d6  vmovaps [rsp+0x40], xmm4
0000740ecffe11dc  vmovaps [rsp+0x50], xmm5
0000740ecffe11e2  vmovaps [rsp+0x60], xmm6
0000740ecffe11e8  vmovaps [rsp+0x70], xmm7
0000740ecffe11ee  vmovaps [rsp+0x80], xmm9
0000740ecffe11f7  vmovaps [rsp+0x90], xmm10
0000740ecffe1200  vmovaps [rsp+0xA0], xmm11
0000740ecffe1209  vmovaps [rsp+0xB0], xmm12
0000740ecffe1212  vmovaps [rsp+0xC0], xmm13
0000740ecffe121b  vmovaps [rsp+0xD0], xmm14
0000740ecffe1224  vmovaps [rsp+0xE0], xmm15
0000740ecffe122d  sub rsp, 0x30
0000740ecffe1231  movaps [rsp], xmm8
0000740ecffe1236  movaps [rsp+0x10], xmm15
0000740ecffe123c  movaps [rsp+0x20], xmm7
0000740ecffe1241  lea rdi, [rsp]
0000740ecffe1245  mov esi, 0x00
0000740ecffe124a  mov rax, 0x5E8249CF1530
0000740ecffe1254  call rax
0000740ecffe1256  movaps xmm8, [rsp]
0000740ecffe125b  add rsp, 0x30
0000740ecffe125f  vmovaps xmm0, [rsp]
0000740ecffe1264  vmovaps xmm1, [rsp+0x10]
0000740ecffe126a  vmovaps xmm2, [rsp+0x20]
0000740ecffe1270  vmovaps xmm3, [rsp+0x30]
0000740ecffe1276  vmovaps xmm4, [rsp+0x40]
0000740ecffe127c  vmovaps xmm5, [rsp+0x50]
0000740ecffe1282  vmovaps xmm6, [rsp+0x60]
0000740ecffe1288  vmovaps xmm7, [rsp+0x70]
0000740ecffe128e  vmovaps xmm9, [rsp+0x80]
0000740ecffe1297  vmovaps xmm10, [rsp+0x90]
0000740ecffe12a0  vmovaps xmm11, [rsp+0xA0]
0000740ecffe12a9  vmovaps xmm12, [rsp+0xB0]
0000740ecffe12b2  vmovaps xmm13, [rsp+0xC0]
0000740ecffe12bb  vmovaps xmm14, [rsp+0xD0]
0000740ecffe12c4  vmovaps xmm15, [rsp+0xE0]
0000740ecffe12cd  add rsp, 0xF0
0000740ecffe12d4  pop r11
0000740ecffe12d6  pop r10
0000740ecffe12d8  pop r9
0000740ecffe12da  pop r8
0000740ecffe12dc  pop rsi
0000740ecffe12dd  pop rdi
0000740ecffe12de  pop rdx
0000740ecffe12df  pop rcx
0000740ecffe12e0  pop rax
0000740ecffe12e1  add rsp, 0x08
0000740ecffe12e5  jmp 0x0000740ECFFDC787
0000740ecffe12ea  sub rsp, 0x08
0000740ecffe12ee  push rax
0000740ecffe12ef  push rcx
0000740ecffe12f0  push rdx
0000740ecffe12f1  push rdi
0000740ecffe12f2  push rsi
0000740ecffe12f3  push r8
0000740ecffe12f5  push r9
0000740ecffe12f7  push r10
0000740ecffe12f9  push r11
0000740ecffe12fb  sub rsp, 0xF0
0000740ecffe1302  vmovaps [rsp], xmm0
0000740ecffe1307  vmovaps [rsp+0x10], xmm1
0000740ecffe130d  vmovaps [rsp+0x20], xmm2
0000740ecffe1313  vmovaps [rsp+0x30], xmm3
0000740ecffe1319  vmovaps [rsp+0x40], xmm4
0000740ecffe131f  vmovaps [rsp+0x50], xmm5
0000740ecffe1325  vmovaps [rsp+0x60], xmm6
0000740ecffe132b  vmovaps [rsp+0x70], xmm8
0000740ecffe1331  vmovaps [rsp+0x80], xmm9
0000740ecffe133a  vmovaps [rsp+0x90], xmm10
0000740ecffe1343  vmovaps [rsp+0xA0], xmm11
0000740ecffe134c  vmovaps [rsp+0xB0], xmm12
0000740ecffe1355  vmovaps [rsp+0xC0], xmm13
0000740ecffe135e  vmovaps [rsp+0xD0], xmm14
0000740ecffe1367  vmovaps [rsp+0xE0], xmm15
0000740ecffe1370  sub rsp, 0x30
0000740ecffe1374  movaps [rsp], xmm7
0000740ecffe1378  movaps [rsp+0x10], xmm9
0000740ecffe137e  movaps [rsp+0x20], xmm15
0000740ecffe1384  lea rdi, [rsp]
0000740ecffe1388  mov esi, 0x00
0000740ecffe138d  mov rax, 0x5E8249CF1530
0000740ecffe1397  call rax
0000740ecffe1399  movaps xmm7, [rsp]
0000740ecffe139d  add rsp, 0x30
0000740ecffe13a1  vmovaps xmm0, [rsp]
0000740ecffe13a6  vmovaps xmm1, [rsp+0x10]
0000740ecffe13ac  vmovaps xmm2, [rsp+0x20]
0000740ecffe13b2  vmovaps xmm3, [rsp+0x30]
0000740ecffe13b8  vmovaps xmm4, [rsp+0x40]
0000740ecffe13be  vmovaps xmm5, [rsp+0x50]
0000740ecffe13c4  vmovaps xmm6, [rsp+0x60]
0000740ecffe13ca  vmovaps xmm8, [rsp+0x70]
0000740ecffe13d0  vmovaps xmm9, [rsp+0x80]
0000740ecffe13d9  vmovaps xmm10, [rsp+0x90]
0000740ecffe13e2  vmovaps xmm11, [rsp+0xA0]
0000740ecffe13eb  vmovaps xmm12, [rsp+0xB0]
0000740ecffe13f4  vmovaps xmm13, [rsp+0xC0]
0000740ecffe13fd  vmovaps xmm14, [rsp+0xD0]
0000740ecffe1406  vmovaps xmm15, [rsp+0xE0]
0000740ecffe140f  add rsp, 0xF0
0000740ecffe1416  pop r11
0000740ecffe1418  pop r10
0000740ecffe141a  pop r9
0000740ecffe141c  pop r8
0000740ecffe141e  pop rsi
0000740ecffe141f  pop rdi
0000740ecffe1420  pop rdx
0000740ecffe1421  pop rcx
0000740ecffe1422  pop rax
0000740ecffe1423  add rsp, 0x08
0000740ecffe1427  jmp 0x0000740ECFFDC7B4
0000740ecffe142c  sub rsp, 0x08
0000740ecffe1430  push rax
0000740ecffe1431  push rcx
0000740ecffe1432  push rdx
0000740ecffe1433  push rdi
0000740ecffe1434  push rsi
0000740ecffe1435  push r8
0000740ecffe1437  push r9
0000740ecffe1439  push r10
0000740ecffe143b  push r11
0000740ecffe143d  sub rsp, 0xF0
0000740ecffe1444  vmovaps [rsp], xmm0
0000740ecffe1449  vmovaps [rsp+0x10], xmm1
0000740ecffe144f  vmovaps [rsp+0x20], xmm2
0000740ecffe1455  vmovaps [rsp+0x30], xmm3
0000740ecffe145b  vmovaps [rsp+0x40], xmm4
0000740ecffe1461  vmovaps [rsp+0x50], xmm5
0000740ecffe1467  vmovaps [rsp+0x60], xmm6
0000740ecffe146d  vmovaps [rsp+0x70], xmm7
0000740ecffe1473  vmovaps [rsp+0x80], xmm8
0000740ecffe147c  vmovaps [rsp+0x90], xmm10
0000740ecffe1485  vmovaps [rsp+0xA0], xmm11
0000740ecffe148e  vmovaps [rsp+0xB0], xmm12
0000740ecffe1497  vmovaps [rsp+0xC0], xmm13
0000740ecffe14a0  vmovaps [rsp+0xD0], xmm14
0000740ecffe14a9  vmovaps [rsp+0xE0], xmm15
0000740ecffe14b2  sub rsp, 0x30
0000740ecffe14b6  movaps [rsp], xmm9
0000740ecffe14bb  movaps [rsp+0x10], xmm13
0000740ecffe14c1  movaps [rsp+0x20], xmm15
0000740ecffe14c7  lea rdi, [rsp]
0000740ecffe14cb  mov esi, 0x00
0000740ecffe14d0  mov rax, 0x5E8249CF1530
0000740ecffe14da  call rax
0000740ecffe14dc  movaps xmm9, [rsp]
0000740ecffe14e1  add rsp, 0x30
0000740ecffe14e5  vmovaps xmm0, [rsp]
0000740ecffe14ea  vmovaps xmm1, [rsp+0x10]
0000740ecffe14f0  vmovaps xmm2, [rsp+0x20]
0000740ecffe14f6  vmovaps xmm3, [rsp+0x30]
0000740ecffe14fc  vmovaps xmm4, [rsp+0x40]
0000740ecffe1502  vmovaps xmm5, [rsp+0x50]
0000740ecffe1508  vmovaps xmm6, [rsp+0x60]
0000740ecffe150e  vmovaps xmm7, [rsp+0x70]
0000740ecffe1514  vmovaps xmm8, [rsp+0x80]
0000740ecffe151d  vmovaps xmm10, [rsp+0x90]
0000740ecffe1526  vmovaps xmm11, [rsp+0xA0]
0000740ecffe152f  vmovaps xmm12, [rsp+0xB0]
0000740ecffe1538  vmovaps xmm13, [rsp+0xC0]
0000740ecffe1541  vmovaps xmm14, [rsp+0xD0]
0000740ecffe154a  vmovaps xmm15, [rsp+0xE0]
0000740ecffe1553  add rsp, 0xF0
0000740ecffe155a  pop r11
0000740ecffe155c  pop r10
0000740ecffe155e  pop r9
0000740ecffe1560  pop r8
0000740ecffe1562  pop rsi
0000740ecffe1563  pop rdi
0000740ecffe1564  pop rdx
0000740ecffe1565  pop rcx
0000740ecffe1566  pop rax
0000740ecffe1567  add rsp, 0x08
0000740ecffe156b  jmp 0x0000740ECFFDC7E2
0000740ecffe1570  sub rsp, 0x08
0000740ecffe1574  push rax
0000740ecffe1575  push rcx
0000740ecffe1576  push rdx
0000740ecffe1577  push rdi
0000740ecffe1578  push rsi
0000740ecffe1579  push r8
0000740ecffe157b  push r9
0000740ecffe157d  push r10
0000740ecffe157f  push r11
0000740ecffe1581  sub rsp, 0xF0
0000740ecffe1588  vmovaps [rsp], xmm0
0000740ecffe158d  vmovaps [rsp+0x10], xmm1
0000740ecffe1593  vmovaps [rsp+0x20], xmm2
0000740ecffe1599  vmovaps [rsp+0x30], xmm3
0000740ecffe159f  vmovaps [rsp+0x40], xmm4
0000740ecffe15a5  vmovaps [rsp+0x50], xmm5
0000740ecffe15ab  vmovaps [rsp+0x60], xmm6
0000740ecffe15b1  vmovaps [rsp+0x70], xmm7
0000740ecffe15b7  vmovaps [rsp+0x80], xmm8
0000740ecffe15c0  vmovaps [rsp+0x90], xmm9
0000740ecffe15c9  vmovaps [rsp+0xA0], xmm10
0000740ecffe15d2  vmovaps [rsp+0xB0], xmm11
0000740ecffe15db  vmovaps [rsp+0xC0], xmm12
0000740ecffe15e4  vmovaps [rsp+0xD0], xmm13
0000740ecffe15ed  vmovaps [rsp+0xE0], xmm14
0000740ecffe15f6  sub rsp, 0x30
0000740ecffe15fa  movaps [rsp], xmm15
0000740ecffe15ff  movaps [rsp+0x10], xmm11
0000740ecffe1605  movaps [rsp+0x20], xmm12
0000740ecffe160b  lea rdi, [rsp]
0000740ecffe160f  mov esi, 0x00
0000740ecffe1614  mov rax, 0x5E8249CF1530
0000740ecffe161e  call rax
0000740ecffe1620  movaps xmm15, [rsp]
0000740ecffe1625  add rsp, 0x30
0000740ecffe1629  vmovaps xmm0, [rsp]
0000740ecffe162e  vmovaps xmm1, [rsp+0x10]
0000740ecffe1634  vmovaps xmm2, [rsp+0x20]
0000740ecffe163a  vmovaps xmm3, [rsp+0x30]
0000740ecffe1640  vmovaps xmm4, [rsp+0x40]
0000740ecffe1646  vmovaps xmm5, [rsp+0x50]
0000740ecffe164c  vmovaps xmm6, [rsp+0x60]
0000740ecffe1652  vmovaps xmm7, [rsp+0x70]
0000740ecffe1658  vmovaps xmm8, [rsp+0x80]
0000740ecffe1661  vmovaps xmm9, [rsp+0x90]
0000740ecffe166a  vmovaps xmm10, [rsp+0xA0]
0000740ecffe1673  vmovaps xmm11, [rsp+0xB0]
0000740ecffe167c  vmovaps xmm12, [rsp+0xC0]
0000740ecffe1685  vmovaps xmm13, [rsp+0xD0]
0000740ecffe168e  vmovaps xmm14, [rsp+0xE0]
0000740ecffe1697  add rsp, 0xF0
0000740ecffe169e  pop r11
0000740ecffe16a0  pop r10
0000740ecffe16a2  pop r9
0000740ecffe16a4  pop r8
0000740ecffe16a6  pop rsi
0000740ecffe16a7  pop rdi
0000740ecffe16a8  pop rdx
0000740ecffe16a9  pop rcx
0000740ecffe16aa  pop rax
0000740ecffe16ab  add rsp, 0x08
0000740ecffe16af  jmp 0x0000740ECFFDC7FD
0000740ecffe16b4  sub rsp, 0x08
0000740ecffe16b8  push rax
0000740ecffe16b9  push rcx
0000740ecffe16ba  push rdx
0000740ecffe16bb  push rdi
0000740ecffe16bc  push rsi
0000740ecffe16bd  push r8
0000740ecffe16bf  push r9
0000740ecffe16c1  push r10
0000740ecffe16c3  push r11
0000740ecffe16c5  sub rsp, 0xF0
0000740ecffe16cc  vmovaps [rsp], xmm0
0000740ecffe16d1  vmovaps [rsp+0x10], xmm1
0000740ecffe16d7  vmovaps [rsp+0x20], xmm2
0000740ecffe16dd  vmovaps [rsp+0x30], xmm3
0000740ecffe16e3  vmovaps [rsp+0x40], xmm4
0000740ecffe16e9  vmovaps [rsp+0x50], xmm5
0000740ecffe16ef  vmovaps [rsp+0x60], xmm6
0000740ecffe16f5  vmovaps [rsp+0x70], xmm7
0000740ecffe16fb  vmovaps [rsp+0x80], xmm8
0000740ecffe1704  vmovaps [rsp+0x90], xmm9
0000740ecffe170d  vmovaps [rsp+0xA0], xmm10
0000740ecffe1716  vmovaps [rsp+0xB0], xmm11
0000740ecffe171f  vmovaps [rsp+0xC0], xmm12
0000740ecffe1728  vmovaps [rsp+0xD0], xmm14
0000740ecffe1731  vmovaps [rsp+0xE0], xmm15
0000740ecffe173a  sub rsp, 0x30
0000740ecffe173e  movaps [rsp], xmm13
0000740ecffe1743  movaps [rsp+0x10], xmm10
0000740ecffe1749  movaps [rsp+0x20], xmm14
0000740ecffe174f  lea rdi, [rsp]
0000740ecffe1753  mov esi, 0x00
0000740ecffe1758  mov rax, 0x5E8249CF1530
0000740ecffe1762  call rax
0000740ecffe1764  movaps xmm13, [rsp]
0000740ecffe1769  add rsp, 0x30
0000740ecffe176d  vmovaps xmm0, [rsp]
0000740ecffe1772  vmovaps xmm1, [rsp+0x10]
0000740ecffe1778  vmovaps xmm2, [rsp+0x20]
0000740ecffe177e  vmovaps xmm3, [rsp+0x30]
0000740ecffe1784  vmovaps xmm4, [rsp+0x40]
0000740ecffe178a  vmovaps xmm5, [rsp+0x50]
0000740ecffe1790  vmovaps xmm6, [rsp+0x60]
0000740ecffe1796  vmovaps xmm7, [rsp+0x70]
0000740ecffe179c  vmovaps xmm8, [rsp+0x80]
0000740ecffe17a5  vmovaps xmm9, [rsp+0x90]
0000740ecffe17ae  vmovaps xmm10, [rsp+0xA0]
0000740ecffe17b7  vmovaps xmm11, [rsp+0xB0]
0000740ecffe17c0  vmovaps xmm12, [rsp+0xC0]
0000740ecffe17c9  vmovaps xmm14, [rsp+0xD0]
0000740ecffe17d2  vmovaps xmm15, [rsp+0xE0]
0000740ecffe17db  add rsp, 0xF0
0000740ecffe17e2  pop r11
0000740ecffe17e4  pop r10
0000740ecffe17e6  pop r9
0000740ecffe17e8  pop r8
0000740ecffe17ea  pop rsi
0000740ecffe17eb  pop rdi
0000740ecffe17ec  pop rdx
0000740ecffe17ed  pop rcx
0000740ecffe17ee  pop rax
0000740ecffe17ef  add rsp, 0x08
0000740ecffe17f3  jmp 0x0000740ECFFDC820
0000740ecffe17f8  sub rsp, 0x08
0000740ecffe17fc  push rax
0000740ecffe17fd  push rcx
0000740ecffe17fe  push rdx
0000740ecffe17ff  push rdi
0000740ecffe1800  push rsi
0000740ecffe1801  push r8
0000740ecffe1803  push r9
0000740ecffe1805  push r10
0000740ecffe1807  push r11
0000740ecffe1809  sub rsp, 0xF0
0000740ecffe1810  vmovaps [rsp], xmm0
0000740ecffe1815  vmovaps [rsp+0x10], xmm1
0000740ecffe181b  vmovaps [rsp+0x20], xmm2
0000740ecffe1821  vmovaps [rsp+0x30], xmm3
0000740ecffe1827  vmovaps [rsp+0x40], xmm4
0000740ecffe182d  vmovaps [rsp+0x50], xmm5
0000740ecffe1833  vmovaps [rsp+0x60], xmm6
0000740ecffe1839  vmovaps [rsp+0x70], xmm7
0000740ecffe183f  vmovaps [rsp+0x80], xmm8
0000740ecffe1848  vmovaps [rsp+0x90], xmm9
0000740ecffe1851  vmovaps [rsp+0xA0], xmm10
0000740ecffe185a  vmovaps [rsp+0xB0], xmm11
0000740ecffe1863  vmovaps [rsp+0xC0], xmm12
0000740ecffe186c  vmovaps [rsp+0xD0], xmm13
0000740ecffe1875  vmovaps [rsp+0xE0], xmm15
0000740ecffe187e  sub rsp, 0x30
0000740ecffe1882  movaps [rsp], xmm14
0000740ecffe1887  movaps [rsp+0x10], xmm1
0000740ecffe188c  movaps [rsp+0x20], xmm7
0000740ecffe1891  lea rdi, [rsp]
0000740ecffe1895  mov esi, 0x00
0000740ecffe189a  mov rax, 0x5E8249CF1530
0000740ecffe18a4  call rax
0000740ecffe18a6  movaps xmm14, [rsp]
0000740ecffe18ab  add rsp, 0x30
0000740ecffe18af  vmovaps xmm0, [rsp]
0000740ecffe18b4  vmovaps xmm1, [rsp+0x10]
0000740ecffe18ba  vmovaps xmm2, [rsp+0x20]
0000740ecffe18c0  vmovaps xmm3, [rsp+0x30]
0000740ecffe18c6  vmovaps xmm4, [rsp+0x40]
0000740ecffe18cc  vmovaps xmm5, [rsp+0x50]
0000740ecffe18d2  vmovaps xmm6, [rsp+0x60]
0000740ecffe18d8  vmovaps xmm7, [rsp+0x70]
0000740ecffe18de  vmovaps xmm8, [rsp+0x80]
0000740ecffe18e7  vmovaps xmm9, [rsp+0x90]
0000740ecffe18f0  vmovaps xmm10, [rsp+0xA0]
0000740ecffe18f9  vmovaps xmm11, [rsp+0xB0]
0000740ecffe1902  vmovaps xmm12, [rsp+0xC0]
0000740ecffe190b  vmovaps xmm13, [rsp+0xD0]
0000740ecffe1914  vmovaps xmm15, [rsp+0xE0]
0000740ecffe191d  add rsp, 0xF0
0000740ecffe1924  pop r11
0000740ecffe1926  pop r10
0000740ecffe1928  pop r9
0000740ecffe192a  pop r8
0000740ecffe192c  pop rsi
0000740ecffe192d  pop rdi
0000740ecffe192e  pop rdx
0000740ecffe192f  pop rcx
0000740ecffe1930  pop rax
0000740ecffe1931  add rsp, 0x08
0000740ecffe1935  jmp 0x0000740ECFFDC843
0000740ecffe193a  sub rsp, 0x08
0000740ecffe193e  push rax
0000740ecffe193f  push rcx
0000740ecffe1940  push rdx
0000740ecffe1941  push rdi
0000740ecffe1942  push rsi
0000740ecffe1943  push r8
0000740ecffe1945  push r9
0000740ecffe1947  push r10
0000740ecffe1949  push r11
0000740ecffe194b  sub rsp, 0xF0
0000740ecffe1952  vmovaps [rsp], xmm0
0000740ecffe1957  vmovaps [rsp+0x10], xmm2
0000740ecffe195d  vmovaps [rsp+0x20], xmm3
0000740ecffe1963  vmovaps [rsp+0x30], xmm4
0000740ecffe1969  vmovaps [rsp+0x40], xmm5
0000740ecffe196f  vmovaps [rsp+0x50], xmm6
0000740ecffe1975  vmovaps [rsp+0x60], xmm7
0000740ecffe197b  vmovaps [rsp+0x70], xmm8
0000740ecffe1981  vmovaps [rsp+0x80], xmm9
0000740ecffe198a  vmovaps [rsp+0x90], xmm10
0000740ecffe1993  vmovaps [rsp+0xA0], xmm11
0000740ecffe199c  vmovaps [rsp+0xB0], xmm12
0000740ecffe19a5  vmovaps [rsp+0xC0], xmm13
0000740ecffe19ae  vmovaps [rsp+0xD0], xmm14
0000740ecffe19b7  vmovaps [rsp+0xE0], xmm15
0000740ecffe19c0  sub rsp, 0x30
0000740ecffe19c4  movaps [rsp], xmm1
0000740ecffe19c8  movaps [rsp+0x10], xmm8
0000740ecffe19ce  movaps [rsp+0x20], xmm9
0000740ecffe19d4  lea rdi, [rsp]
0000740ecffe19d8  mov esi, 0x00
0000740ecffe19dd  mov rax, 0x5E8249CF1530
0000740ecffe19e7  call rax
0000740ecffe19e9  movaps xmm1, [rsp]
0000740ecffe19ed  add rsp, 0x30
0000740ecffe19f1  vmovaps xmm0, [rsp]
0000740ecffe19f6  vmovaps xmm2, [rsp+0x10]
0000740ecffe19fc  vmovaps xmm3, [rsp+0x20]
0000740ecffe1a02  vmovaps xmm4, [rsp+0x30]
0000740ecffe1a08  vmovaps xmm5, [rsp+0x40]
0000740ecffe1a0e  vmovaps xmm6, [rsp+0x50]
0000740ecffe1a14  vmovaps xmm7, [rsp+0x60]
0000740ecffe1a1a  vmovaps xmm8, [rsp+0x70]
0000740ecffe1a20  vmovaps xmm9, [rsp+0x80]
0000740ecffe1a29  vmovaps xmm10, [rsp+0x90]
0000740ecffe1a32  vmovaps xmm11, [rsp+0xA0]
0000740ecffe1a3b  vmovaps xmm12, [rsp+0xB0]
0000740ecffe1a44  vmovaps xmm13, [rsp+0xC0]
0000740ecffe1a4d  vmovaps xmm14, [rsp+0xD0]
0000740ecffe1a56  vmovaps xmm15, [rsp+0xE0]
0000740ecffe1a5f  add rsp, 0xF0
0000740ecffe1a66  pop r11
0000740ecffe1a68  pop r10
0000740ecffe1a6a  pop r9
0000740ecffe1a6c  pop r8
0000740ecffe1a6e  pop rsi
0000740ecffe1a6f  pop rdi
0000740ecffe1a70  pop rdx
0000740ecffe1a71  pop rcx
0000740ecffe1a72  pop rax
0000740ecffe1a73  add rsp, 0x08
0000740ecffe1a77  jmp 0x0000740ECFFDC865
0000740ecffe1a7c  call 0x0000740ECFEE5940
0000740ecffe1a81  jmp 0x0000740ECFFDC873
0000740ecffe1a86  call 0x0000740ECFE0C380
0000740ecffe1a8b  jmp 0x0000740ECFFDC87D
0000740ecffe1a90  call 0x0000740ECFE0D600
0000740ecffe1a95  jmp 0x0000740ECFFDC887
0000740ecffe1a9a  call 0x0000740ECFDFF540
0000740ecffe1a9f  jmp 0x0000740ECFFDC891
0000740ecffe1aa4  int3
0000740ecffe1aa5  nop [rax+rax*1], ax
0000740ecffe1aae  nop
0000740ecffe1ab0  mov rax, [r15+0xF8]
0000740ecffe1ab7  lea r14, [rax+0x140]
0000740ecffe1abe  mov r12, [r13+r14*1]
0000740ecffe1ac3  mov [r15+0xE8], r12
0000740ecffe1aca  lea r14, [rax+0x130]
0000740ecffe1ad1  mov r12, [r13+r14*1]
0000740ecffe1ad6  lea r14, [rax+0x138]
0000740ecffe1add  mov r11, [r13+r14*1]
0000740ecffe1ae2  movq xmm1, r12
0000740ecffe1ae7  movq xmm15, r11
0000740ecffe1aec  movq xmm1, xmm1
0000740ecffe1af0  movq xmm1, xmm1
0000740ecffe1af4  movaps [r15+0x1A0], xmm1
0000740ecffe1afc  movq xmm15, xmm15
0000740ecffe1b01  movq xmm15, xmm15
0000740ecffe1b06  movaps [r15+0x190], xmm15
0000740ecffe1b0e  lea r14, [rax+0x120]
0000740ecffe1b15  mov r12, [r13+r14*1]
0000740ecffe1b1a  lea r14, [rax+0x128]
0000740ecffe1b21  mov r11, [r13+r14*1]
0000740ecffe1b26  movq xmm1, r12
0000740ecffe1b2b  movq xmm15, r11
0000740ecffe1b30  movq xmm1, xmm1
0000740ecffe1b34  movq xmm1, xmm1
0000740ecffe1b38  movaps [r15+0x1C0], xmm1
0000740ecffe1b40  movq xmm15, xmm15
0000740ecffe1b45  movq xmm15, xmm15
0000740ecffe1b4a  movaps [r15+0x1B0], xmm15
0000740ecffe1b52  lea r14, [rax+0x110]
0000740ecffe1b59  mov r12, [r13+r14*1]
0000740ecffe1b5e  lea r14, [rax+0x118]
0000740ecffe1b65  mov r11, [r13+r14*1]
0000740ecffe1b6a  movq xmm1, r12
0000740ecffe1b6f  movq xmm15, r11
0000740ecffe1b74  movq xmm1, xmm1
0000740ecffe1b78  movq xmm1, xmm1
0000740ecffe1b7c  movaps [r15+0x1E0], xmm1
0000740ecffe1b84  movq xmm15, xmm15
0000740ecffe1b89  movq xmm15, xmm15
0000740ecffe1b8e  movaps [r15+0x1D0], xmm15
0000740ecffe1b96  lea r14, [rax+0x100]
0000740ecffe1b9d  mov r12, [r13+r14*1]
0000740ecffe1ba2  lea r14, [rax+0x108]
0000740ecffe1ba9  mov r11, [r13+r14*1]
0000740ecffe1bae  movq xmm1, r12
0000740ecffe1bb3  movq xmm15, r11
0000740ecffe1bb8  movq xmm1, xmm1
0000740ecffe1bbc  movq xmm1, xmm1
0000740ecffe1bc0  movaps [r15+0x200], xmm1
0000740ecffe1bc8  movq xmm15, xmm15
0000740ecffe1bcd  movq xmm15, xmm15
0000740ecffe1bd2  movaps [r15+0x1F0], xmm15
0000740ecffe1bda  mov qword ptr [r15+0x40], 0x430000
0000740ecffe1be2  mov r14d, 0x430510
0000740ecffe1be8  mov r12, [r13+r14*1]
0000740ecffe1bed  movq xmm1, r12
0000740ecffe1bf2  lea r14, [rax+0x150]
0000740ecffe1bf9  mov [r15+0xF8], r14
0000740ecffe1c00  mov rax, [r15+0x50]
0000740ecffe1c04  movups xmm15, [r13+rax*1]
0000740ecffe1c0a  movaps [r15+0x120], xmm15
0000740ecffe1c12  mov qword ptr [r15+0x48], 0x10
0000740ecffe1c1a  xor eax, eax
0000740ecffe1c1c  mov r14d, 0x10
0000740ecffe1c22  mov r12d, 0x200
0000740ecffe1c28  cmp r14, r12
0000740ecffe1c2b  cmc
0000740ecffe1c2c  lahf
0000740ecffe1c2d  seto al
0000740ecffe1c30  mov [r15+0x108], eax
0000740ecffe1c37  pextrq rax, xmm15, 0x01
0000740ecffe1c3e  movq xmm14, rax
0000740ecffe1c43  movaps [r15+0x130], xmm14
0000740ecffe1c4b  movq rax, xmm1
0000740ecffe1c50  movq r14, xmm15
0000740ecffe1c55  vmovq xmm1, rax
0000740ecffe1c5a  vmovq xmm15, r14
0000740ecffe1c5f  movaps xmm13, xmm1
0000740ecffe1c63  addsd xmm13, xmm15
0000740ecffe1c68  ucomisd xmm13, xmm13
0000740ecffe1c6d  jp 0x0000740ECFFE1D86
0000740ecffe1c73  movq xmm13, xmm13
0000740ecffe1c78  movq rax, xmm13
0000740ecffe1c7d  movq r14, xmm14
0000740ecffe1c82  vmovq xmm1, rax
0000740ecffe1c87  vmovq xmm15, r14
0000740ecffe1c8c  movaps xmm14, xmm1
0000740ecffe1c90  addsd xmm14, xmm15
0000740ecffe1c95  ucomisd xmm14, xmm14
0000740ecffe1c9a  jp 0x0000740ECFFE1DCE
0000740ecffe1ca0  movq xmm14, xmm14
0000740ecffe1ca5  movaps [r15+0x110], xmm14
0000740ecffe1cad  mov eax, [r15+0x108]
0000740ecffe1cb4  sahf
0000740ecffe1cb5  jnz 0x0000740ECFFE1CE7
0000740ecffe1cb7  cmp dword ptr [r15+0x318], 0x00
0000740ecffe1cbf  jz 0x0000740ECFFE1FE0
0000740ecffe1cc5  nop [rax+rax*1], ax
0000740ecffe1cce  nop [rax+rax*1], eax
0000740ecffe1cd6  mov eax, 0x410490
0000740ecffe1cdb  mov [r15+0x100], rax
0000740ecffe1ce2  jmp 0x0000740ECFDFE110
0000740ecffe1ce7  cmp dword ptr [r15+0x318], 0x00
0000740ecffe1cef  jz 0x0000740ECFFE1E20
0000740ecffe1cf5  nop [rax+rax*1], ax
0000740ecffe1cfe  nop [rax+rax*1], eax
0000740ecffe1d06  mov eax, 0x410474
0000740ecffe1d0b  mov [r15+0x100], rax
0000740ecffe1d12  jmp 0x0000740ECFDFE110
0000740ecffe1d17  int3
0000740ecffe1d18  call 0x0000740ECFEE27E0
0000740ecffe1d1d  jmp 0x0000740ECFFE1AC3
0000740ecffe1d22  call 0x0000740ECFEE27E0
0000740ecffe1d27  jmp 0x0000740ECFFE1AD6
0000740ecffe1d2c  call 0x0000740ECFEE1570
0000740ecffe1d31  jmp 0x0000740ECFFE1AE2
0000740ecffe1d36  call 0x0000740ECFEE27E0
0000740ecffe1d3b  jmp 0x0000740ECFFE1B1A
0000740ecffe1d40  call 0x0000740ECFEE1570
0000740ecffe1d45  jmp 0x0000740ECFFE1B26
0000740ecffe1d4a  call 0x0000740ECFEE27E0
0000740ecffe1d4f  jmp 0x0000740ECFFE1B5E
0000740ecffe1d54  call 0x0000740ECFEE1570
0000740ecffe1d59  jmp 0x0000740ECFFE1B6A
0000740ecffe1d5e  call 0x0000740ECFEE27E0
0000740ecffe1d63  jmp 0x0000740ECFFE1BA2
0000740ecffe1d68  call 0x0000740ECFEE1570
0000740ecffe1d6d  jmp 0x0000740ECFFE1BAE
0000740ecffe1d72  call 0x0000740ECFEE27E0
0000740ecffe1d77  jmp 0x0000740ECFFE1BED
0000740ecffe1d7c  call 0x0000740ECFE0E760
0000740ecffe1d81  jmp 0x0000740ECFFE1C0A
0000740ecffe1d86  ucomisd xmm1, xmm15
0000740ecffe1d8b  jp 0x0000740ECFFE1D9A
0000740ecffe1d8d  movaps xmm13, [0x0000740ECFBFE060]
0000740ecffe1d95  jmp 0x0000740ECFFE1C73
0000740ecffe1d9a  vxorps xmm0, xmm1, xmm15
0000740ecffe1d9f  pextrw eax, xmm0, 0x03
0000740ecffe1da4  and eax, 0x7FF8
0000740ecffe1da9  cmp eax, 0x08
0000740ecffe1dac  jnz 0x0000740ECFFE1C73
0000740ecffe1db2  movq rax, xmm15
0000740ecffe1db7  shl rax, 0x0D
0000740ecffe1dbb  jbe 0x0000740ECFFE1C73
0000740ecffe1dc1  vorps xmm13, xmm15, [0x0000740ECFBFE070]
0000740ecffe1dc9  jmp 0x0000740ECFFE1C73
0000740ecffe1dce  ucomisd xmm1, xmm15
0000740ecffe1dd3  jp 0x0000740ECFFE1DE2
0000740ecffe1dd5  movaps xmm14, [0x0000740ECFBFE060]
0000740ecffe1ddd  jmp 0x0000740ECFFE1CA0
0000740ecffe1de2  vxorps xmm0, xmm1, xmm15
0000740ecffe1de7  pextrw eax, xmm0, 0x03
0000740ecffe1dec  and eax, 0x7FF8
0000740ecffe1df1  cmp eax, 0x08
0000740ecffe1df4  jnz 0x0000740ECFFE1CA0
0000740ecffe1dfa  movq rax, xmm15
0000740ecffe1dff  shl rax, 0x0D
0000740ecffe1e03  jbe 0x0000740ECFFE1CA0
0000740ecffe1e09  vorps xmm14, xmm15, [0x0000740ECFBFE070]
0000740ecffe1e11  jmp 0x0000740ECFFE1CA0
0000740ecffe1e16  int3
0000740ecffe1e17  nop [rax+rax*1], ax
0000740ecffe1e20  mov rax, [r15+0x48]
0000740ecffe1e24  mov r14, [r15+0x50]
0000740ecffe1e28  lea r12, [r14+rax*1]
0000740ecffe1e2c  movups xmm1, [r13+r12*1]
0000740ecffe1e32  movaps [r15+0x120], xmm1
0000740ecffe1e3a  lea r14, [rax+0x10]
0000740ecffe1e3e  mov [r15+0x48], r14
0000740ecffe1e42  xor eax, eax
0000740ecffe1e44  mov r12d, 0x200
0000740ecffe1e4a  cmp r14, r12
0000740ecffe1e4d  cmc
0000740ecffe1e4e  lahf
0000740ecffe1e4f  seto al
0000740ecffe1e52  mov [r15+0x108], eax
0000740ecffe1e59  pextrq rax, xmm1, 0x01
0000740ecffe1e60  movq xmm15, rax
0000740ecffe1e65  movaps [r15+0x130], xmm15
0000740ecffe1e6d  movaps xmm14, [r15+0x110]
0000740ecffe1e75  movq rax, xmm14
0000740ecffe1e7a  movq r14, xmm1
0000740ecffe1e7f  vmovq xmm1, rax
0000740ecffe1e84  vmovq xmm14, r14
0000740ecffe1e89  movaps xmm13, xmm1
0000740ecffe1e8d  addsd xmm13, xmm14
0000740ecffe1e92  ucomisd xmm13, xmm13
0000740ecffe1e97  jp 0x0000740ECFFE1F4C
0000740ecffe1e9d  movq xmm13, xmm13
0000740ecffe1ea2  movq rax, xmm13
0000740ecffe1ea7  movq r14, xmm15
0000740ecffe1eac  vmovq xmm1, rax
0000740ecffe1eb1  vmovq xmm15, r14
0000740ecffe1eb6  movaps xmm14, xmm1
0000740ecffe1eba  addsd xmm14, xmm15
0000740ecffe1ebf  ucomisd xmm14, xmm14
0000740ecffe1ec4  jp 0x0000740ECFFE1F94
0000740ecffe1eca  movq xmm14, xmm14
0000740ecffe1ecf  movaps [r15+0x110], xmm14
0000740ecffe1ed7  mov eax, [r15+0x108]
0000740ecffe1ede  sahf
0000740ecffe1edf  jnz 0x0000740ECFFE1F11
0000740ecffe1ee1  cmp dword ptr [r15+0x318], 0x00
0000740ecffe1ee9  jz 0x0000740ECFFE1FE0
0000740ecffe1eef  nop [rax+rax*1], ax
0000740ecffe1ef8  nop [rax+rax*1], eax
0000740ecffe1f00  mov eax, 0x410490
0000740ecffe1f05  mov [r15+0x100], rax
0000740ecffe1f0c  jmp 0x0000740ECFDFE110
0000740ecffe1f11  cmp dword ptr [r15+0x318], 0x00
0000740ecffe1f19  jz 0x0000740ECFFE1E20
0000740ecffe1f1f  nop [rax+rax*1], ax
0000740ecffe1f28  nop [rax+rax*1], eax
0000740ecffe1f30  mov eax, 0x410474
0000740ecffe1f35  mov [r15+0x100], rax
0000740ecffe1f3c  jmp 0x0000740ECFDFE110
0000740ecffe1f41  int3
0000740ecffe1f42  call 0x0000740ECFEB52F0
0000740ecffe1f47  jmp 0x0000740ECFFE1E32
0000740ecffe1f4c  ucomisd xmm1, xmm14
0000740ecffe1f51  jp 0x0000740ECFFE1F60
0000740ecffe1f53  movaps xmm13, [0x0000740ECFBFE060]
0000740ecffe1f5b  jmp 0x0000740ECFFE1E9D
0000740ecffe1f60  vxorps xmm0, xmm1, xmm14
0000740ecffe1f65  pextrw eax, xmm0, 0x03
0000740ecffe1f6a  and eax, 0x7FF8
0000740ecffe1f6f  cmp eax, 0x08
0000740ecffe1f72  jnz 0x0000740ECFFE1E9D
0000740ecffe1f78  movq rax, xmm14
0000740ecffe1f7d  shl rax, 0x0D
0000740ecffe1f81  jbe 0x0000740ECFFE1E9D
0000740ecffe1f87  vorps xmm13, xmm14, [0x0000740ECFBFE070]
0000740ecffe1f8f  jmp 0x0000740ECFFE1E9D
0000740ecffe1f94  ucomisd xmm1, xmm15
0000740ecffe1f99  jp 0x0000740ECFFE1FA8
0000740ecffe1f9b  movaps xmm14, [0x0000740ECFBFE060]
0000740ecffe1fa3  jmp 0x0000740ECFFE1ECA
0000740ecffe1fa8  vxorps xmm0, xmm1, xmm15
0000740ecffe1fad  pextrw eax, xmm0, 0x03
0000740ecffe1fb2  and eax, 0x7FF8
0000740ecffe1fb7  cmp eax, 0x08
0000740ecffe1fba  jnz 0x0000740ECFFE1ECA
0000740ecffe1fc0  movq rax, xmm15
0000740ecffe1fc5  shl rax, 0x0D
0000740ecffe1fc9  jbe 0x0000740ECFFE1ECA
0000740ecffe1fcf  vorps xmm14, xmm15, [0x0000740ECFBFE070]
0000740ecffe1fd7  jmp 0x0000740ECFFE1ECA
0000740ecffe1fdc  int3
0000740ecffe1fdd  nop [rax], eax
0000740ecffe1fe0  mov rax, [r15+0x40]
0000740ecffe1fe4  lea r14, [rax+0x510]
0000740ecffe1feb  movaps xmm1, [r15+0x110]
0000740ecffe1ff3  movq rax, xmm1
0000740ecffe1ff8  mov [r13+r14*1], rax
0000740ecffe1ffd  mov rax, [r15+0xF0]
0000740ecffe2004  mov [r15+0x100], rax
0000740ecffe200b  jmp 0x0000740ECFFCE5C0
0000740ecffe2010  int3
0000740ecffe2011  call 0x0000740ECFED5EB0
0000740ecffe2016  jmp 0x0000740ECFFE1FFD
0000740ecffe201b  int3
0000740ecffe201c  nop [rax], eax
0000740ecffe2020  mov qword ptr [r15+0x100], 0x04
0000740ecffe202b  mov esi, 0x00
0000740ecffe2030  mov edx, 0x09
0000740ecffe2035  mov rdi, 0x7FFC527DC810
0000740ecffe203f  mov rax, 0x5E8249B84970
0000740ecffe2049  call rax
0000740ecffe204b  cmp dword ptr [r15+0x318], 0x00
0000740ecffe2053  jnz 0x0000740ECFDFE110
0000740ecffe2059  jmp 0x0000740ECFDFE0A0
0000740ecffe205e  int3
0000740ecffe205f  int3
