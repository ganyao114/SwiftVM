000074c3551ce69b  nop [rax+rax*1], eax
000074c3551ce6a0  vmovaps xmm1, [0x000074C354DFE010]
000074c3551ce6a8  movq xmm1, xmm1
000074c3551ce6ac  movaps [r15+0x110], xmm1
000074c3551ce6b4  vmovaps xmm1, [0x000074C354DFE020]
000074c3551ce6bc  movq xmm1, xmm1
000074c3551ce6c0  movaps [r15+0x120], xmm1
000074c3551ce6c8  mov eax, 0x4204C0
000074c3551ce6cd  mov r14, [r13+rax*1]
000074c3551ce6d2  movq xmm1, r14
000074c3551ce6d7  movaps [r15+0x130], xmm1
000074c3551ce6df  vmovaps xmm1, [0x000074C354DFE030]
000074c3551ce6e7  vpbroadcastq xmm1, xmm1
000074c3551ce6ec  movaps [r15+0x140], xmm1
000074c3551ce6f4  mov qword ptr [r15+0x40], 0x02
000074c3551ce6fc  vmovaps xmm15, [0x000074C354DFE040]
000074c3551ce704  movq xmm15, xmm15
000074c3551ce709  movaps [r15+0x150], xmm15
000074c3551ce711  mov qword ptr [r15+0x58], 0x420000
000074c3551ce719  vmovaps xmm15, [0x000074C354DFE050]
000074c3551ce721  vpbroadcastq xmm15, xmm15
000074c3551ce726  movaps [r15+0x160], xmm15
000074c3551ce72e  mov rax, [r15+0x40]
000074c3551ce732  vmovq xmm14, rax
000074c3551ce737  vpbroadcastq xmm14, xmm14
000074c3551ce73c  movaps [r15+0x170], xmm14
000074c3551ce744  mov eax, 0x4204D0
000074c3551ce749  movups xmm13, [r13+rax*1]
000074c3551ce74f  mov qword ptr [r15+0x40], 0x430518
000074c3551ce757  mov qword ptr [r15+0x50], 0x430720
000074c3551ce75f  vpmovqd xmm12, xmm13
000074c3551ce765  pxor xmm11, xmm11
000074c3551ce76a  punpcklqdq xmm12, xmm11
000074c3551ce76f  movaps [r15+0x210], xmm12
000074c3551ce777  movq xmm12, qword ptr [r15+0x120]
000074c3551ce780  movq xmm11, qword ptr [r15+0x130]
000074c3551ce789  psubd xmm12, xmm11
000074c3551ce78e  movq xmm12, xmm12
000074c3551ce793  paddq xmm13, xmm14
000074c3551ce798  movaps [r15+0x180], xmm13
000074c3551ce7a0  movq xmm14, qword ptr [r15+0x150]
000074c3551ce7a9  paddd xmm11, xmm14
000074c3551ce7ae  movq xmm11, xmm11
000074c3551ce7b3  movq xmm11, xmm11
000074c3551ce7b8  movaps [r15+0x130], xmm11
000074c3551ce7c0  pmovzxdq xmm12, xmm12
000074c3551ce7c6  psllq xmm12, 0x00
000074c3551ce7cc  movq xmm14, qword ptr [r15+0x210]
000074c3551ce7d5  movq xmm13, qword ptr [r15+0x110]
000074c3551ce7de  paddd xmm14, xmm13
000074c3551ce7e3  movq xmm14, xmm14
000074c3551ce7e8  vcvtuqq2pd xmm12, xmm12
000074c3551ce7ee  pmovzxdq xmm14, xmm14
000074c3551ce7f4  psllq xmm14, 0x00
000074c3551ce7fa  vcvtuqq2pd xmm14, xmm14
000074c3551ce800  movaps xmm13, xmm12
000074c3551ce804  mulpd xmm13, xmm1
000074c3551ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000074c3551ce80f  ptest xmm11, xmm11
000074c3551ce815  jnz 0x000074C3551CE8FF
000074c3551ce81b  movaps [r15+0x220], xmm13
000074c3551ce823  mov eax, 0x430720
000074c3551ce828  movups [r13+rax*1], xmm13
000074c3551ce82e  movaps xmm1, xmm14
000074c3551ce832  mulpd xmm1, xmm15
000074c3551ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000074c3551ce83c  ptest xmm13, xmm13
000074c3551ce842  jnz 0x000074C3551CEA4C
000074c3551ce848  movaps [r15+0x210], xmm1
000074c3551ce850  mov eax, 0x430518
000074c3551ce855  movups [r13+rax*1], xmm1
000074c3551ce85b  mov qword ptr [r15+0x48], 0x10
000074c3551ce863  xor eax, eax
000074c3551ce865  mov r14d, 0x10
000074c3551ce86b  mov r12d, 0x200
000074c3551ce871  cmp r14, r12
000074c3551ce874  cmc
000074c3551ce875  lahf
000074c3551ce876  seto al
000074c3551ce879  mov [r15+0x108], eax
000074c3551ce880  mov eax, [r15+0x108]
000074c3551ce887  sahf
000074c3551ce888  jnz 0x000074C3551CE8BA
000074c3551ce88a  cmp dword ptr [r15+0x318], 0x00
000074c3551ce892  jz 0x000074C3551CEFF0
000074c3551ce898  nop [rax+rax*1], ax
000074c3551ce8a1  nop [rax+rax*1], eax
000074c3551ce8a9  mov eax, 0x4101EC
000074c3551ce8ae  mov [r15+0x100], rax
000074c3551ce8b5  jmp 0x000074C354FFE110
000074c3551ce8ba  cmp dword ptr [r15+0x318], 0x00
000074c3551ce8c2  jz 0x000074C3551CEBA0
000074c3551ce8c8  nop [rax+rax*1], ax
000074c3551ce8d1  nop [rax+rax*1], eax
000074c3551ce8d9  mov eax, 0x4101AC
000074c3551ce8de  mov [r15+0x100], rax
000074c3551ce8e5  jmp 0x000074C354FFE110
000074c3551ce8ea  int3
000074c3551ce8eb  call 0x000074C35500DC20
000074c3551ce8f0  jmp 0x000074C3551CE6D2
000074c3551ce8f5  call 0x000074C35500C260
000074c3551ce8fa  jmp 0x000074C3551CE74F
000074c3551ce8ff  sub rsp, 0x08
000074c3551ce903  push rax
000074c3551ce904  push rcx
000074c3551ce905  push rdx
000074c3551ce906  push rdi
000074c3551ce907  push rsi
000074c3551ce908  push r8
000074c3551ce90a  push r9
000074c3551ce90c  push r10
000074c3551ce90e  push r11
000074c3551ce910  sub rsp, 0xF0
000074c3551ce917  vmovaps [rsp], xmm0
000074c3551ce91c  vmovaps [rsp+0x10], xmm1
000074c3551ce922  vmovaps [rsp+0x20], xmm2
000074c3551ce928  vmovaps [rsp+0x30], xmm3
000074c3551ce92e  vmovaps [rsp+0x40], xmm4
000074c3551ce934  vmovaps [rsp+0x50], xmm5
000074c3551ce93a  vmovaps [rsp+0x60], xmm6
000074c3551ce940  vmovaps [rsp+0x70], xmm7
000074c3551ce946  vmovaps [rsp+0x80], xmm8
000074c3551ce94f  vmovaps [rsp+0x90], xmm9
000074c3551ce958  vmovaps [rsp+0xA0], xmm10
000074c3551ce961  vmovaps [rsp+0xB0], xmm11
000074c3551ce96a  vmovaps [rsp+0xC0], xmm12
000074c3551ce973  vmovaps [rsp+0xD0], xmm14
000074c3551ce97c  vmovaps [rsp+0xE0], xmm15
000074c3551ce985  sub rsp, 0x30
000074c3551ce989  movaps [rsp], xmm13
000074c3551ce98e  movaps [rsp+0x10], xmm12
000074c3551ce994  movaps [rsp+0x20], xmm1
000074c3551ce999  lea rdi, [rsp]
000074c3551ce99d  mov esi, 0x00
000074c3551ce9a2  mov rax, 0x5F9407FA9530
000074c3551ce9ac  call rax
000074c3551ce9ae  movaps xmm13, [rsp]
000074c3551ce9b3  add rsp, 0x30
000074c3551ce9b7  vmovaps xmm0, [rsp]
000074c3551ce9bc  vmovaps xmm1, [rsp+0x10]
000074c3551ce9c2  vmovaps xmm2, [rsp+0x20]
000074c3551ce9c8  vmovaps xmm3, [rsp+0x30]
000074c3551ce9ce  vmovaps xmm4, [rsp+0x40]
000074c3551ce9d4  vmovaps xmm5, [rsp+0x50]
000074c3551ce9da  vmovaps xmm6, [rsp+0x60]
000074c3551ce9e0  vmovaps xmm7, [rsp+0x70]
000074c3551ce9e6  vmovaps xmm8, [rsp+0x80]
000074c3551ce9ef  vmovaps xmm9, [rsp+0x90]
000074c3551ce9f8  vmovaps xmm10, [rsp+0xA0]
000074c3551cea01  vmovaps xmm11, [rsp+0xB0]
000074c3551cea0a  vmovaps xmm12, [rsp+0xC0]
000074c3551cea13  vmovaps xmm14, [rsp+0xD0]
000074c3551cea1c  vmovaps xmm15, [rsp+0xE0]
000074c3551cea25  add rsp, 0xF0
000074c3551cea2c  pop r11
000074c3551cea2e  pop r10
000074c3551cea30  pop r9
000074c3551cea32  pop r8
000074c3551cea34  pop rsi
000074c3551cea35  pop rdi
000074c3551cea36  pop rdx
000074c3551cea37  pop rcx
000074c3551cea38  pop rax
000074c3551cea39  add rsp, 0x08
000074c3551cea3d  jmp 0x000074C3551CE81B
000074c3551cea42  call 0x000074C35500C380
000074c3551cea47  jmp 0x000074C3551CE82E
000074c3551cea4c  sub rsp, 0x08
000074c3551cea50  push rax
000074c3551cea51  push rcx
000074c3551cea52  push rdx
000074c3551cea53  push rdi
000074c3551cea54  push rsi
000074c3551cea55  push r8
000074c3551cea57  push r9
000074c3551cea59  push r10
000074c3551cea5b  push r11
000074c3551cea5d  sub rsp, 0xF0
000074c3551cea64  vmovaps [rsp], xmm0
000074c3551cea69  vmovaps [rsp+0x10], xmm2
000074c3551cea6f  vmovaps [rsp+0x20], xmm3
000074c3551cea75  vmovaps [rsp+0x30], xmm4
000074c3551cea7b  vmovaps [rsp+0x40], xmm5
000074c3551cea81  vmovaps [rsp+0x50], xmm6
000074c3551cea87  vmovaps [rsp+0x60], xmm7
000074c3551cea8d  vmovaps [rsp+0x70], xmm8
000074c3551cea93  vmovaps [rsp+0x80], xmm9
000074c3551cea9c  vmovaps [rsp+0x90], xmm10
000074c3551ceaa5  vmovaps [rsp+0xA0], xmm11
000074c3551ceaae  vmovaps [rsp+0xB0], xmm12
000074c3551ceab7  vmovaps [rsp+0xC0], xmm13
000074c3551ceac0  vmovaps [rsp+0xD0], xmm14
000074c3551ceac9  vmovaps [rsp+0xE0], xmm15
000074c3551cead2  sub rsp, 0x30
000074c3551cead6  movaps [rsp], xmm1
000074c3551ceada  movaps [rsp+0x10], xmm14
000074c3551ceae0  movaps [rsp+0x20], xmm15
000074c3551ceae6  lea rdi, [rsp]
000074c3551ceaea  mov esi, 0x00
000074c3551ceaef  mov rax, 0x5F9407FA9530
000074c3551ceaf9  call rax
000074c3551ceafb  movaps xmm1, [rsp]
000074c3551ceaff  add rsp, 0x30
000074c3551ceb03  vmovaps xmm0, [rsp]
000074c3551ceb08  vmovaps xmm2, [rsp+0x10]
000074c3551ceb0e  vmovaps xmm3, [rsp+0x20]
000074c3551ceb14  vmovaps xmm4, [rsp+0x30]
000074c3551ceb1a  vmovaps xmm5, [rsp+0x40]
000074c3551ceb20  vmovaps xmm6, [rsp+0x50]
000074c3551ceb26  vmovaps xmm7, [rsp+0x60]
000074c3551ceb2c  vmovaps xmm8, [rsp+0x70]
000074c3551ceb32  vmovaps xmm9, [rsp+0x80]
000074c3551ceb3b  vmovaps xmm10, [rsp+0x90]
000074c3551ceb44  vmovaps xmm11, [rsp+0xA0]
000074c3551ceb4d  vmovaps xmm12, [rsp+0xB0]
000074c3551ceb56  vmovaps xmm13, [rsp+0xC0]
000074c3551ceb5f  vmovaps xmm14, [rsp+0xD0]
000074c3551ceb68  vmovaps xmm15, [rsp+0xE0]
000074c3551ceb71  add rsp, 0xF0
000074c3551ceb78  pop r11
000074c3551ceb7a  pop r10
000074c3551ceb7c  pop r9
000074c3551ceb7e  pop r8
000074c3551ceb80  pop rsi
000074c3551ceb81  pop rdi
000074c3551ceb82  pop rdx
000074c3551ceb83  pop rcx
000074c3551ceb84  pop rax
000074c3551ceb85  add rsp, 0x08
000074c3551ceb89  jmp 0x000074C3551CE848
000074c3551ceb8e  call 0x000074C354FFF540
000074c3551ceb93  jmp 0x000074C3551CE85B
000074c3551ceb98  int3
000074c3551ceb99  nop [rax], eax
000074c3551ceba0  movaps xmm1, [r15+0x180]
000074c3551ceba8  vpmovqd xmm15, xmm1
000074c3551cebae  pxor xmm14, xmm14
000074c3551cebb3  punpcklqdq xmm15, xmm14
000074c3551cebb8  movaps [r15+0x210], xmm15
000074c3551cebc0  movq xmm15, qword ptr [r15+0x120]
000074c3551cebc9  movq xmm14, qword ptr [r15+0x130]
000074c3551cebd2  psubd xmm15, xmm14
000074c3551cebd7  movq xmm15, xmm15
000074c3551cebdc  movaps xmm13, [r15+0x170]
000074c3551cebe4  paddq xmm1, xmm13
000074c3551cebe9  movaps [r15+0x180], xmm1
000074c3551cebf1  movq xmm1, qword ptr [r15+0x150]
000074c3551cebfa  paddd xmm14, xmm1
000074c3551cebff  movq xmm14, xmm14
000074c3551cec04  movq xmm14, xmm14
000074c3551cec09  movaps [r15+0x130], xmm14
000074c3551cec11  pmovzxdq xmm15, xmm15
000074c3551cec17  psllq xmm15, 0x00
000074c3551cec1d  movq xmm1, qword ptr [r15+0x210]
000074c3551cec26  movq xmm14, qword ptr [r15+0x110]
000074c3551cec2f  paddd xmm1, xmm14
000074c3551cec34  movq xmm1, xmm1
000074c3551cec38  vcvtuqq2pd xmm15, xmm15
000074c3551cec3e  pmovzxdq xmm1, xmm1
000074c3551cec43  psllq xmm1, 0x00
000074c3551cec48  vcvtuqq2pd xmm1, xmm1
000074c3551cec4e  movaps xmm14, [r15+0x140]
000074c3551cec56  movaps xmm13, xmm15
000074c3551cec5a  mulpd xmm13, xmm14
000074c3551cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000074c3551cec65  ptest xmm12, xmm12
000074c3551cec6b  jnz 0x000074C3551CED4E
000074c3551cec71  movaps [r15+0x220], xmm13
000074c3551cec79  mov rax, [r15+0x48]
000074c3551cec7d  mov r14, [r15+0x50]
000074c3551cec81  lea r12, [r14+rax*1]
000074c3551cec85  movups [r13+r12*1], xmm13
000074c3551cec8b  movaps xmm15, [r15+0x160]
000074c3551cec93  movaps xmm14, xmm1
000074c3551cec97  mulpd xmm14, xmm15
000074c3551cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000074c3551ceca2  ptest xmm13, xmm13
000074c3551ceca8  jnz 0x000074C3551CEE9C
000074c3551cecae  movaps [r15+0x210], xmm14
000074c3551cecb6  mov r14, [r15+0x40]
000074c3551cecba  lea r12, [r14+rax*1]
000074c3551cecbe  movups [r13+r12*1], xmm14
000074c3551cecc4  lea r14, [rax+0x10]
000074c3551cecc8  mov [r15+0x48], r14
000074c3551ceccc  xor eax, eax
000074c3551cecce  mov r12d, 0x200
000074c3551cecd4  cmp r14, r12
000074c3551cecd7  cmc
000074c3551cecd8  lahf
000074c3551cecd9  seto al
000074c3551cecdc  mov [r15+0x108], eax
000074c3551cece3  mov eax, [r15+0x108]
000074c3551cecea  sahf
000074c3551ceceb  jnz 0x000074C3551CED1D
000074c3551ceced  cmp dword ptr [r15+0x318], 0x00
000074c3551cecf5  jz 0x000074C3551CEFF0
000074c3551cecfb  nop [rax+rax*1], ax
000074c3551ced04  nop [rax+rax*1], eax
000074c3551ced0c  mov eax, 0x4101EC
000074c3551ced11  mov [r15+0x100], rax
000074c3551ced18  jmp 0x000074C354FFE110
000074c3551ced1d  cmp dword ptr [r15+0x318], 0x00
000074c3551ced25  jz 0x000074C3551CEBA0
000074c3551ced2b  nop [rax+rax*1], ax
000074c3551ced34  nop [rax+rax*1], eax
000074c3551ced3c  mov eax, 0x4101AC
000074c3551ced41  mov [r15+0x100], rax
000074c3551ced48  jmp 0x000074C354FFE110
000074c3551ced4d  int3
000074c3551ced4e  sub rsp, 0x08
000074c3551ced52  push rax
000074c3551ced53  push rcx
000074c3551ced54  push rdx
000074c3551ced55  push rdi
000074c3551ced56  push rsi
000074c3551ced57  push r8
000074c3551ced59  push r9
000074c3551ced5b  push r10
000074c3551ced5d  push r11
000074c3551ced5f  sub rsp, 0xF0
000074c3551ced66  vmovaps [rsp], xmm0
000074c3551ced6b  vmovaps [rsp+0x10], xmm1
000074c3551ced71  vmovaps [rsp+0x20], xmm2
000074c3551ced77  vmovaps [rsp+0x30], xmm3
000074c3551ced7d  vmovaps [rsp+0x40], xmm4
000074c3551ced83  vmovaps [rsp+0x50], xmm5
000074c3551ced89  vmovaps [rsp+0x60], xmm6
000074c3551ced8f  vmovaps [rsp+0x70], xmm7
000074c3551ced95  vmovaps [rsp+0x80], xmm8
000074c3551ced9e  vmovaps [rsp+0x90], xmm9
000074c3551ceda7  vmovaps [rsp+0xA0], xmm10
000074c3551cedb0  vmovaps [rsp+0xB0], xmm11
000074c3551cedb9  vmovaps [rsp+0xC0], xmm12
000074c3551cedc2  vmovaps [rsp+0xD0], xmm14
000074c3551cedcb  vmovaps [rsp+0xE0], xmm15
000074c3551cedd4  sub rsp, 0x30
000074c3551cedd8  movaps [rsp], xmm13
000074c3551ceddd  movaps [rsp+0x10], xmm15
000074c3551cede3  movaps [rsp+0x20], xmm14
000074c3551cede9  lea rdi, [rsp]
000074c3551ceded  mov esi, 0x00
000074c3551cedf2  mov rax, 0x5F9407FA9530
000074c3551cedfc  call rax
000074c3551cedfe  movaps xmm13, [rsp]
000074c3551cee03  add rsp, 0x30
000074c3551cee07  vmovaps xmm0, [rsp]
000074c3551cee0c  vmovaps xmm1, [rsp+0x10]
000074c3551cee12  vmovaps xmm2, [rsp+0x20]
000074c3551cee18  vmovaps xmm3, [rsp+0x30]
000074c3551cee1e  vmovaps xmm4, [rsp+0x40]
000074c3551cee24  vmovaps xmm5, [rsp+0x50]
000074c3551cee2a  vmovaps xmm6, [rsp+0x60]
000074c3551cee30  vmovaps xmm7, [rsp+0x70]
000074c3551cee36  vmovaps xmm8, [rsp+0x80]
000074c3551cee3f  vmovaps xmm9, [rsp+0x90]
000074c3551cee48  vmovaps xmm10, [rsp+0xA0]
000074c3551cee51  vmovaps xmm11, [rsp+0xB0]
000074c3551cee5a  vmovaps xmm12, [rsp+0xC0]
000074c3551cee63  vmovaps xmm14, [rsp+0xD0]
000074c3551cee6c  vmovaps xmm15, [rsp+0xE0]
000074c3551cee75  add rsp, 0xF0
000074c3551cee7c  pop r11
000074c3551cee7e  pop r10
000074c3551cee80  pop r9
000074c3551cee82  pop r8
000074c3551cee84  pop rsi
000074c3551cee85  pop rdi
000074c3551cee86  pop rdx
000074c3551cee87  pop rcx
000074c3551cee88  pop rax
000074c3551cee89  add rsp, 0x08
000074c3551cee8d  jmp 0x000074C3551CEC71
000074c3551cee92  call 0x000074C3550C2240
000074c3551cee97  jmp 0x000074C3551CEC8B
000074c3551cee9c  sub rsp, 0x08
000074c3551ceea0  push rax
000074c3551ceea1  push rcx
000074c3551ceea2  push rdx
000074c3551ceea3  push rdi
000074c3551ceea4  push rsi
000074c3551ceea5  push r8
000074c3551ceea7  push r9
000074c3551ceea9  push r10
000074c3551ceeab  push r11
000074c3551ceead  sub rsp, 0xF0
000074c3551ceeb4  vmovaps [rsp], xmm0
000074c3551ceeb9  vmovaps [rsp+0x10], xmm1
000074c3551ceebf  vmovaps [rsp+0x20], xmm2
000074c3551ceec5  vmovaps [rsp+0x30], xmm3
000074c3551ceecb  vmovaps [rsp+0x40], xmm4
000074c3551ceed1  vmovaps [rsp+0x50], xmm5
000074c3551ceed7  vmovaps [rsp+0x60], xmm6
000074c3551ceedd  vmovaps [rsp+0x70], xmm7
000074c3551ceee3  vmovaps [rsp+0x80], xmm8
000074c3551ceeec  vmovaps [rsp+0x90], xmm9
000074c3551ceef5  vmovaps [rsp+0xA0], xmm10
000074c3551ceefe  vmovaps [rsp+0xB0], xmm11
000074c3551cef07  vmovaps [rsp+0xC0], xmm12
000074c3551cef10  vmovaps [rsp+0xD0], xmm13
000074c3551cef19  vmovaps [rsp+0xE0], xmm15
000074c3551cef22  sub rsp, 0x30
000074c3551cef26  movaps [rsp], xmm14
000074c3551cef2b  movaps [rsp+0x10], xmm1
000074c3551cef30  movaps [rsp+0x20], xmm15
000074c3551cef36  lea rdi, [rsp]
000074c3551cef3a  mov esi, 0x00
000074c3551cef3f  mov rax, 0x5F9407FA9530
000074c3551cef49  call rax
000074c3551cef4b  movaps xmm14, [rsp]
000074c3551cef50  add rsp, 0x30
000074c3551cef54  vmovaps xmm0, [rsp]
000074c3551cef59  vmovaps xmm1, [rsp+0x10]
000074c3551cef5f  vmovaps xmm2, [rsp+0x20]
000074c3551cef65  vmovaps xmm3, [rsp+0x30]
000074c3551cef6b  vmovaps xmm4, [rsp+0x40]
000074c3551cef71  vmovaps xmm5, [rsp+0x50]
000074c3551cef77  vmovaps xmm6, [rsp+0x60]
000074c3551cef7d  vmovaps xmm7, [rsp+0x70]
000074c3551cef83  vmovaps xmm8, [rsp+0x80]
000074c3551cef8c  vmovaps xmm9, [rsp+0x90]
000074c3551cef95  vmovaps xmm10, [rsp+0xA0]
000074c3551cef9e  vmovaps xmm11, [rsp+0xB0]
000074c3551cefa7  vmovaps xmm12, [rsp+0xC0]
000074c3551cefb0  vmovaps xmm13, [rsp+0xD0]
000074c3551cefb9  vmovaps xmm15, [rsp+0xE0]
000074c3551cefc2  add rsp, 0xF0
000074c3551cefc9  pop r11
000074c3551cefcb  pop r10
000074c3551cefcd  pop r9
000074c3551cefcf  pop r8
000074c3551cefd1  pop rsi
000074c3551cefd2  pop rdi
000074c3551cefd3  pop rdx
000074c3551cefd4  pop rcx
000074c3551cefd5  pop rax
000074c3551cefd6  add rsp, 0x08
000074c3551cefda  jmp 0x000074C3551CECAE
000074c3551cefdf  call 0x000074C3550C34C0
000074c3551cefe4  jmp 0x000074C3551CECC4
000074c3551cefe9  int3
000074c3551cefea  nop [rax+rax*1], ax
000074c3551ceff0  mov rax, [r15+0xF8]
000074c3551ceff7  lea r14, [rax-0x150]
000074c3551ceffe  mov [r15+0xF8], r14
000074c3551cf005  mov rax, [r15+0x50]
000074c3551cf009  lea r12, [rax+0x80]
000074c3551cf010  movups xmm1, [r13+r12*1]
000074c3551cf016  lea r12, [rax+0x90]
000074c3551cf01d  movups xmm15, [r13+r12*1]
000074c3551cf023  mov qword ptr [r15+0x48], 0x00
000074c3551cf02b  lea r12, [rax+0x40]
000074c3551cf02f  movups xmm14, [r13+r12*1]
000074c3551cf035  lea r12, [rax+0x50]
000074c3551cf039  movups xmm13, [r13+r12*1]
000074c3551cf03f  lea r12, [r14+0x120]
000074c3551cf046  movq xmm12, qword ptr [r15+0x1C0]
000074c3551cf04f  movq xmm11, qword ptr [r15+0x1B0]
000074c3551cf058  movq r11, xmm12
000074c3551cf05d  movq r10, xmm11
000074c3551cf062  mov [r13+r12*1], r11
000074c3551cf067  lea r12, [r14+0x128]
000074c3551cf06e  mov [r13+r12*1], r10
000074c3551cf073  vxorps xmm12, xmm12, xmm12
000074c3551cf078  vpbroadcastq xmm12, xmm12
000074c3551cf07d  lea r12, [r14+0x100]
000074c3551cf084  movq xmm11, qword ptr [r15+0x200]
000074c3551cf08d  movq xmm10, qword ptr [r15+0x1F0]
000074c3551cf096  movq r11, xmm11
000074c3551cf09b  movq r10, xmm10
000074c3551cf0a0  mov [r13+r12*1], r11
000074c3551cf0a5  lea r12, [r14+0x108]
000074c3551cf0ac  mov [r13+r12*1], r10
000074c3551cf0b1  lea r12, [r14+0xE0]
000074c3551cf0b8  movups [r13+r12*1], xmm15
000074c3551cf0be  lea r12, [r14+0xF0]
000074c3551cf0c5  movups [r13+r12*1], xmm1
000074c3551cf0cb  lea r12, [rax+0xC0]
000074c3551cf0d2  movups xmm1, [r13+r12*1]
000074c3551cf0d8  lea r12, [rax+0xD0]
000074c3551cf0df  movups xmm15, [r13+r12*1]
000074c3551cf0e5  lea r12, [r14+0x110]
000074c3551cf0ec  movq xmm11, qword ptr [r15+0x1E0]
000074c3551cf0f5  movq xmm10, qword ptr [r15+0x1D0]
000074c3551cf0fe  movq r11, xmm11
000074c3551cf103  movq r10, xmm10
000074c3551cf108  mov [r13+r12*1], r11
000074c3551cf10d  lea r12, [r14+0x118]
000074c3551cf114  mov [r13+r12*1], r10
000074c3551cf119  movups xmm11, [r13+rax*1]
000074c3551cf11f  lea r12, [rax+0x10]
000074c3551cf123  movups xmm10, [r13+r12*1]
000074c3551cf129  lea r12, [r14+0x130]
000074c3551cf130  movq xmm9, qword ptr [r15+0x1A0]
000074c3551cf139  movq xmm8, qword ptr [r15+0x190]
000074c3551cf142  movq r11, xmm9
000074c3551cf147  movq r10, xmm8
000074c3551cf14c  mov [r13+r12*1], r11
000074c3551cf151  lea r12, [r14+0x138]
000074c3551cf158  mov [r13+r12*1], r10
000074c3551cf15d  lea r12, [rax+0x140]
000074c3551cf164  movups xmm9, [r13+r12*1]
000074c3551cf16a  lea r12, [rax+0x150]
000074c3551cf171  movups xmm8, [r13+r12*1]
000074c3551cf177  lea r12, [r14+0xC0]
000074c3551cf17e  movups [r13+r12*1], xmm15
000074c3551cf184  lea r12, [r14+0xD0]
000074c3551cf18b  movups [r13+r12*1], xmm1
000074c3551cf191  lea r12, [rax+0x100]
000074c3551cf198  movups xmm1, [r13+r12*1]
000074c3551cf19e  lea r12, [rax+0x110]
000074c3551cf1a5  movups xmm15, [r13+r12*1]
000074c3551cf1ab  lea r12, [r14+0x140]
000074c3551cf1b2  mov r11, [r15+0xE8]
000074c3551cf1b9  mov [r13+r12*1], r11
000074c3551cf1be  lea r12, [rax+0x180]
000074c3551cf1c5  movups xmm7, [r13+r12*1]
000074c3551cf1cb  lea r12, [rax+0x190]
000074c3551cf1d2  movups xmm6, [r13+r12*1]
000074c3551cf1d8  lea r12, [rax+0x1C0]
000074c3551cf1df  movups xmm5, [r13+r12*1]
000074c3551cf1e5  lea r12, [rax+0x1D0]
000074c3551cf1ec  movups xmm4, [r13+r12*1]
000074c3551cf1f2  lea r12, [r14+0x20]
000074c3551cf1f6  movups [r13+r12*1], xmm1
000074c3551cf1fc  lea r12, [r14+0x30]
000074c3551cf200  movups [r13+r12*1], xmm13
000074c3551cf206  lea r12, [rax+0x60]
000074c3551cf20a  movups xmm1, [r13+r12*1]
000074c3551cf210  lea r12, [rax+0x70]
000074c3551cf214  movups xmm13, [r13+r12*1]
000074c3551cf21a  lea r12, [rax+0x20]
000074c3551cf21e  movups xmm3, [r13+r12*1]
000074c3551cf224  lea r12, [rax+0x30]
000074c3551cf228  movups xmm2, [r13+r12*1]
000074c3551cf22e  movaps [r15+0x1F0], xmm2
000074c3551cf236  lea r12, [r14+0x60]
000074c3551cf23a  movups [r13+r12*1], xmm11
000074c3551cf240  lea r12, [r14+0x70]
000074c3551cf244  movups [r13+r12*1], xmm5
000074c3551cf24a  lea r12, [rax+0xE0]
000074c3551cf251  movups xmm11, [r13+r12*1]
000074c3551cf257  lea r12, [rax+0xF0]
000074c3551cf25e  movups xmm5, [r13+r12*1]
000074c3551cf264  lea r12, [r14+0xA0]
000074c3551cf26b  movups [r13+r12*1], xmm13
000074c3551cf271  lea r12, [r14+0xB0]
000074c3551cf278  movups [r13+r12*1], xmm1
000074c3551cf27e  lea r12, [rax+0xA0]
000074c3551cf285  movups xmm1, [r13+r12*1]
000074c3551cf28b  lea r12, [rax+0xB0]
000074c3551cf292  movups xmm13, [r13+r12*1]
000074c3551cf298  lea r12, [rax+0x120]
000074c3551cf29f  vmovaps [rsp+0x10], xmm1
000074c3551cf2a5  movups xmm1, [r13+r12*1]
000074c3551cf2ab  lea r12, [rax+0x130]
000074c3551cf2b2  vmovaps [rsp+0x20], xmm1
000074c3551cf2b8  movups xmm1, [r13+r12*1]
000074c3551cf2be  lea r12, [rax+0x160]
000074c3551cf2c5  vmovaps [rsp+0x30], xmm1
000074c3551cf2cb  movups xmm1, [r13+r12*1]
000074c3551cf2d1  lea r12, [rax+0x170]
000074c3551cf2d8  vmovaps [rsp+0x40], xmm1
000074c3551cf2de  movups xmm1, [r13+r12*1]
000074c3551cf2e4  movaps [r15+0x2B0], xmm1
000074c3551cf2ec  lea r12, [r14+0x80]
000074c3551cf2f3  movups [r13+r12*1], xmm13
000074c3551cf2f9  lea r12, [r14+0x90]
000074c3551cf300  vmovaps xmm13, [rsp+0x10]
000074c3551cf306  movups [r13+r12*1], xmm13
000074c3551cf30c  lea r12, [rax+0x1A0]
000074c3551cf313  movups xmm13, [r13+r12*1]
000074c3551cf319  lea r12, [rax+0x1B0]
000074c3551cf320  vmovaps [rsp+0x10], xmm1
000074c3551cf326  movups xmm1, [r13+r12*1]
000074c3551cf32c  movaps [r15+0x290], xmm13
000074c3551cf334  movaps [r15+0x1E0], xmm1
000074c3551cf33c  lea r12, [rax+0x1E0]
000074c3551cf343  vmovaps [rsp+0x50], xmm1
000074c3551cf349  movups xmm1, [r13+r12*1]
000074c3551cf34f  lea r12, [rax+0x1F0]
000074c3551cf356  vmovaps [rsp+0x60], xmm1
000074c3551cf35c  movups xmm1, [r13+r12*1]
000074c3551cf362  mov qword ptr [r15+0x50], 0x430920
000074c3551cf36a  lea rax, [r14+0x40]
000074c3551cf36e  vmovaps [rsp+0x70], xmm1
000074c3551cf374  vmovaps xmm1, [rsp+0x40]
000074c3551cf37a  movups [r13+rax*1], xmm1
000074c3551cf380  lea rax, [r14+0x50]
000074c3551cf384  movups [r13+rax*1], xmm10
000074c3551cf38a  vmovaps xmm1, [rsp+0x70]
000074c3551cf390  movups [r13+r14*1], xmm1
000074c3551cf396  lea rax, [r14+0x10]
000074c3551cf39a  vmovaps xmm1, [rsp+0x60]
000074c3551cf3a0  movups [r13+rax*1], xmm1
000074c3551cf3a6  mov rax, [r15+0x40]
000074c3551cf3aa  vmovaps [rsp+0x40], xmm3
000074c3551cf3b0  vmovaps xmm1, [rsp+0x40]
000074c3551cf3b6  por xmm3, xmm1
000074c3551cf3ba  vmovaps [rsp+0x40], xmm6
000074c3551cf3c0  vmovaps xmm10, [rsp+0x40]
000074c3551cf3c6  por xmm6, xmm10
000074c3551cf3cb  lea r12, [rax+0x30]
000074c3551cf3cf  mov r11, [r13+r12*1]
000074c3551cf3d4  lea r12, [rax+0x38]
000074c3551cf3d8  mov r10, [r13+r12*1]
000074c3551cf3dd  movq xmm10, r11
000074c3551cf3e2  vmovaps [rsp+0x40], xmm1
000074c3551cf3e8  movq xmm1, r10
000074c3551cf3ed  movq xmm10, xmm10
000074c3551cf3f2  vmovaps [rsp+0x60], xmm10
000074c3551cf3f8  movq xmm10, xmm10
000074c3551cf3fd  movaps [r15+0x130], xmm10
000074c3551cf405  movq xmm1, xmm1
000074c3551cf409  vmovaps [rsp+0x70], xmm1
000074c3551cf40f  movq xmm1, xmm1
000074c3551cf413  movaps [r15+0x280], xmm1
000074c3551cf41b  vmovaps [rsp+0x80], xmm9
000074c3551cf424  vmovaps xmm1, [rsp+0x80]
000074c3551cf42d  por xmm9, xmm1
000074c3551cf432  lea r12, [rax+0x20]
000074c3551cf436  mov r11, [r13+r12*1]
000074c3551cf43b  lea r12, [rax+0x28]
000074c3551cf43f  mov r10, [r13+r12*1]
000074c3551cf444  movq xmm1, r11
000074c3551cf449  movq xmm10, r10
000074c3551cf44e  movq xmm1, xmm1
000074c3551cf452  vmovaps [rsp+0x80], xmm1
000074c3551cf45b  movq xmm1, xmm1
000074c3551cf45f  movaps [r15+0x150], xmm1
000074c3551cf467  movq xmm10, xmm10
000074c3551cf46c  vmovaps [rsp+0x90], xmm10
000074c3551cf475  movq xmm10, xmm10
000074c3551cf47a  movaps [r15+0x140], xmm10
000074c3551cf482  lea r12, [rax+0x10]
000074c3551cf486  mov r11, [r13+r12*1]
000074c3551cf48b  lea r12, [rax+0x18]
000074c3551cf48f  mov r10, [r13+r12*1]
000074c3551cf494  movq xmm1, r11
000074c3551cf499  movq xmm10, r10
000074c3551cf49e  movq xmm1, xmm1
000074c3551cf4a2  vmovaps [rsp+0xA0], xmm1
000074c3551cf4ab  movq xmm1, xmm1
000074c3551cf4af  movaps [r15+0x170], xmm1
000074c3551cf4b7  movq xmm10, xmm10
000074c3551cf4bc  vmovaps [rsp+0xB0], xmm10
000074c3551cf4c5  movq xmm10, xmm10
000074c3551cf4ca  movaps [r15+0x160], xmm10
000074c3551cf4d2  mov r12, [r13+rax*1]
000074c3551cf4d7  vmovq xmm1, r12
000074c3551cf4dc  vpbroadcastq xmm1, xmm1
000074c3551cf4e1  lea r12, [rax+0x08]
000074c3551cf4e5  mov rax, [r13+r12*1]
000074c3551cf4ea  movq xmm10, rax
000074c3551cf4ef  movaps [r15+0x230], xmm10
000074c3551cf4f7  lea rax, [r14+0x50]
000074c3551cf4fb  movups xmm10, [r13+rax*1]
000074c3551cf501  lea rax, [r14+0x60]
000074c3551cf505  vmovaps [rsp+0xC0], xmm1
000074c3551cf50e  movups xmm1, [r13+rax*1]
000074c3551cf514  lea rax, [r14+0x30]
000074c3551cf518  vmovaps [rsp+0xD0], xmm1
000074c3551cf521  movups xmm1, [r13+rax*1]
000074c3551cf527  mov qword ptr [r15+0x60], 0x430920
000074c3551cf52f  mov qword ptr [r15+0x58], 0x40
000074c3551cf537  vmovaps [rsp+0xE0], xmm1
000074c3551cf540  vmovaps [rsp+0xF0], xmm15
000074c3551cf549  vmovaps xmm15, [rsp+0xC0]
000074c3551cf552  vmovaps [rsp+0xC0], xmm14
000074c3551cf55b  vmovaps xmm14, [rsp+0x40]
000074c3551cf561  vmovaps [rsp+0x40], xmm13
000074c3551cf567  movaps xmm1, xmm15
000074c3551cf56b  mulpd xmm1, xmm14
000074c3551cf570  vcmppd xmm13, xmm1, xmm1, 0x03
000074c3551cf575  ptest xmm13, xmm13
000074c3551cf57b  jnz 0x000074C3551D0682
000074c3551cf581  movq xmm14, qword ptr [r15+0x230]
000074c3551cf58a  vmovaps [rsp+0x100], xmm14
000074c3551cf593  vpermilpd xmm14, xmm14, 0x00
000074c3551cf599  vmovaps [rsp+0x110], xmm1
000074c3551cf5a2  vmovaps xmm1, [rsp+0xE0]
000074c3551cf5ab  vmovaps [rsp+0xE0], xmm15
000074c3551cf5b4  movaps xmm13, xmm1
000074c3551cf5b8  mulpd xmm13, xmm14
000074c3551cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000074c3551cf5c3  ptest xmm15, xmm15
000074c3551cf5c9  jnz 0x000074C3551D07C4
000074c3551cf5cf  vxorps xmm1, xmm1, xmm1
000074c3551cf5d3  vpbroadcastq xmm1, xmm1
000074c3551cf5d8  vmovaps xmm14, [rsp+0xE0]
000074c3551cf5e1  vmovaps [rsp+0xE0], xmm1
000074c3551cf5ea  vmovaps xmm1, [rsp+0xD0]
000074c3551cf5f3  vmovaps [rsp+0xD0], xmm13
000074c3551cf5fc  movaps xmm15, xmm14
000074c3551cf600  mulpd xmm15, xmm1
000074c3551cf605  vcmppd xmm13, xmm15, xmm15, 0x03
000074c3551cf60b  ptest xmm13, xmm13
000074c3551cf611  jnz 0x000074C3551D0907
000074c3551cf617  movaps xmm1, xmm14
000074c3551cf61b  mulpd xmm1, xmm10
000074c3551cf620  vcmppd xmm13, xmm1, xmm1, 0x03
000074c3551cf625  ptest xmm13, xmm13
000074c3551cf62b  jnz 0x000074C3551D0A4A
000074c3551cf631  movaps xmm13, xmm14
000074c3551cf635  mulpd xmm13, xmm2
000074c3551cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000074c3551cf640  ptest xmm10, xmm10
000074c3551cf646  jnz 0x000074C3551D0B8C
000074c3551cf64c  vmovaps [rsp+0x120], xmm7
000074c3551cf655  vmovaps xmm14, [rsp+0x120]
000074c3551cf65e  por xmm7, xmm14
000074c3551cf663  vmovaps xmm14, [rsp+0xC0]
000074c3551cf66c  vmovaps xmm10, [rsp+0xC0]
000074c3551cf675  por xmm14, xmm10
000074c3551cf67a  vmovaps xmm2, [rsp+0x100]
000074c3551cf683  vpermilpd xmm2, xmm2, 0x00
000074c3551cf689  vmovaps [rsp+0xC0], xmm1
000074c3551cf692  vmovaps [rsp+0x120], xmm15
000074c3551cf69b  movaps xmm1, xmm10
000074c3551cf69f  mulpd xmm1, xmm2
000074c3551cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000074c3551cf6a8  ptest xmm15, xmm15
000074c3551cf6ae  jnz 0x000074C3551D0CCF
000074c3551cf6b4  xor eax, eax
000074c3551cf6b6  mov r12d, 0x40
000074c3551cf6bc  mov r11d, 0x200
000074c3551cf6c2  cmp r12, r11
000074c3551cf6c5  cmc
000074c3551cf6c6  lahf
000074c3551cf6c7  seto al
000074c3551cf6ca  mov [r15+0x108], eax
000074c3551cf6d1  vmovaps xmm10, [rsp+0x110]
000074c3551cf6da  vmovaps xmm2, [rsp+0xE0]
000074c3551cf6e3  vmovaps [rsp+0xE0], xmm1
000074c3551cf6ec  movaps xmm15, xmm10
000074c3551cf6f0  addpd xmm15, xmm2
000074c3551cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000074c3551cf6fb  ptest xmm1, xmm1
000074c3551cf700  jnz 0x000074C3551D0E10
000074c3551cf706  vmovaps xmm10, [rsp+0x120]
000074c3551cf70f  vmovaps [rsp+0x110], xmm15
000074c3551cf718  movaps xmm1, xmm10
000074c3551cf71c  addpd xmm1, xmm12
000074c3551cf721  vcmppd xmm15, xmm1, xmm1, 0x03
000074c3551cf726  ptest xmm15, xmm15
000074c3551cf72c  jnz 0x000074C3551D0F53
000074c3551cf732  vmovaps xmm10, [rsp+0xC0]
000074c3551cf73b  vmovaps [rsp+0xC0], xmm1
000074c3551cf744  movaps xmm15, xmm10
000074c3551cf748  addpd xmm15, xmm12
000074c3551cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000074c3551cf753  ptest xmm1, xmm1
000074c3551cf758  jnz 0x000074C3551D1095
000074c3551cf75e  vmovaps xmm1, [rsp+0x30]
000074c3551cf764  vmovaps xmm12, [rsp+0x30]
000074c3551cf76a  por xmm1, xmm12
000074c3551cf76f  vmovaps xmm12, [rsp+0x20]
000074c3551cf775  vmovaps xmm10, [rsp+0x20]
000074c3551cf77b  por xmm12, xmm10
000074c3551cf780  vmovaps [rsp+0x20], xmm5
000074c3551cf786  vmovaps xmm10, [rsp+0x20]
000074c3551cf78c  por xmm5, xmm10
000074c3551cf791  vmovaps [rsp+0x20], xmm11
000074c3551cf797  vmovaps xmm10, [rsp+0x20]
000074c3551cf79d  por xmm11, xmm10
000074c3551cf7a2  vmovaps [rsp+0x20], xmm4
000074c3551cf7a8  vmovaps xmm10, [rsp+0x20]
000074c3551cf7ae  por xmm4, xmm10
000074c3551cf7b3  vmovaps [rsp+0x20], xmm8
000074c3551cf7b9  vmovaps xmm10, [rsp+0x20]
000074c3551cf7bf  por xmm8, xmm10
000074c3551cf7c4  vmovaps xmm10, [rsp+0xF0]
000074c3551cf7cd  vmovaps [rsp+0x20], xmm1
000074c3551cf7d3  vmovaps xmm1, [rsp+0xF0]
000074c3551cf7dc  por xmm10, xmm1
000074c3551cf7e1  lea rax, [r14+0xA0]
000074c3551cf7e8  movups xmm1, [r13+rax*1]
000074c3551cf7ee  lea rax, [r14+0xB0]
000074c3551cf7f5  vmovaps [rsp+0x30], xmm1
000074c3551cf7fb  movups xmm1, [r13+rax*1]
000074c3551cf801  vmovaps [rsp+0xF0], xmm1
000074c3551cf80a  vmovaps [rsp+0x120], xmm15
000074c3551cf813  movaps xmm1, xmm13
000074c3551cf817  addpd xmm1, xmm2
000074c3551cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000074c3551cf820  ptest xmm15, xmm15
000074c3551cf826  jnz 0x000074C3551D11ED
000074c3551cf82c  lea rax, [r14+0xF0]
000074c3551cf833  movups xmm15, [r13+rax*1]
000074c3551cf839  vmovaps xmm2, [rsp+0xC0]
000074c3551cf842  vmovaps [rsp+0xC0], xmm1
000074c3551cf84b  vmovaps xmm1, [rsp+0xE0]
000074c3551cf854  vmovaps [rsp+0xE0], xmm15
000074c3551cf85d  movaps xmm13, xmm2
000074c3551cf861  addpd xmm13, xmm1
000074c3551cf866  vcmppd xmm15, xmm13, xmm13, 0x03
000074c3551cf86c  ptest xmm15, xmm15
000074c3551cf872  jnz 0x000074C3551D1338
000074c3551cf878  vmovaps xmm15, [rsp+0x120]
000074c3551cf881  vmovaps xmm2, [rsp+0xD0]
000074c3551cf88a  vmovaps [rsp+0xD0], xmm14
000074c3551cf893  movaps xmm1, xmm15
000074c3551cf897  addpd xmm1, xmm2
000074c3551cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000074c3551cf8a0  ptest xmm14, xmm14
000074c3551cf8a6  jnz 0x000074C3551D147A
000074c3551cf8ac  vmovaps xmm15, [rsp+0x100]
000074c3551cf8b5  vpermilpd xmm15, xmm15, 0x00
000074c3551cf8bb  vmovaps xmm2, [rsp+0xF0]
000074c3551cf8c4  vmovaps [rsp+0xF0], xmm1
000074c3551cf8cd  movaps xmm14, xmm2
000074c3551cf8d1  mulpd xmm14, xmm15
000074c3551cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000074c3551cf8dc  ptest xmm1, xmm1
000074c3551cf8e1  jnz 0x000074C3551D15BB
000074c3551cf8e7  vmovaps xmm1, [rsp+0xA0]
000074c3551cf8f0  vpermilpd xmm1, xmm1, 0x00
000074c3551cf8f6  vmovaps xmm2, [rsp+0xE0]
000074c3551cf8ff  vmovaps [rsp+0xE0], xmm14
000074c3551cf908  movaps xmm15, xmm2
000074c3551cf90c  mulpd xmm15, xmm1
000074c3551cf911  vcmppd xmm14, xmm15, xmm15, 0x03
000074c3551cf917  ptest xmm14, xmm14
000074c3551cf91d  jnz 0x000074C3551D16FE
000074c3551cf923  lea rax, [r14+0xE0]
000074c3551cf92a  movups xmm1, [r13+rax*1]
000074c3551cf930  vmovaps xmm14, [rsp+0x100]
000074c3551cf939  vpermilpd xmm14, xmm14, 0x00
000074c3551cf93f  vmovaps [rsp+0x100], xmm1
000074c3551cf948  vmovaps xmm1, [rsp+0x30]
000074c3551cf94e  vmovaps [rsp+0x30], xmm15
000074c3551cf954  movaps xmm2, xmm1
000074c3551cf957  mulpd xmm2, xmm14
000074c3551cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000074c3551cf961  ptest xmm15, xmm15
000074c3551cf967  jnz 0x000074C3551D184A
000074c3551cf96d  vmovaps [rsp+0x120], xmm10
000074c3551cf976  vmovaps xmm1, [rsp+0x120]
000074c3551cf97f  por xmm10, xmm1
000074c3551cf984  movaps [r15+0x300], xmm10
000074c3551cf98c  vmovaps [rsp+0x120], xmm8
000074c3551cf995  vmovaps xmm1, [rsp+0x120]
000074c3551cf99e  por xmm8, xmm1
000074c3551cf9a3  movaps [r15+0x190], xmm8
000074c3551cf9ab  vmovaps xmm1, [rsp+0xA0]
000074c3551cf9b4  vpermilpd xmm1, xmm1, 0x00
000074c3551cf9ba  vmovaps xmm14, [rsp+0x100]
000074c3551cf9c3  vmovaps [rsp+0x100], xmm13
000074c3551cf9cc  movaps xmm15, xmm14
000074c3551cf9d0  mulpd xmm15, xmm1
000074c3551cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000074c3551cf9db  ptest xmm13, xmm13
000074c3551cf9e1  jnz 0x000074C3551D198B
000074c3551cf9e7  lea rax, [r14+0x90]
000074c3551cf9ee  movups xmm1, [r13+rax*1]
000074c3551cf9f4  vmovaps [rsp+0x120], xmm4
000074c3551cf9fd  vmovaps xmm14, [rsp+0x120]
000074c3551cfa06  por xmm4, xmm14
000074c3551cfa0b  movaps [r15+0x1C0], xmm4
000074c3551cfa13  vmovaps [rsp+0x120], xmm11
000074c3551cfa1c  vmovaps xmm14, [rsp+0x120]
000074c3551cfa25  por xmm11, xmm14
000074c3551cfa2a  movaps [r15+0x200], xmm11
000074c3551cfa32  vmovaps [rsp+0x120], xmm5
000074c3551cfa3b  vmovaps xmm14, [rsp+0x120]
000074c3551cfa44  por xmm5, xmm14
000074c3551cfa49  movaps [r15+0x2D0], xmm5
000074c3551cfa51  vmovaps [rsp+0x120], xmm12
000074c3551cfa5a  vmovaps xmm14, [rsp+0x120]
000074c3551cfa63  por xmm12, xmm14
000074c3551cfa68  movaps [r15+0x2E0], xmm12
000074c3551cfa70  vmovaps xmm13, [rsp+0x110]
000074c3551cfa79  vmovaps [rsp+0x110], xmm1
000074c3551cfa82  vmovaps xmm1, [rsp+0xE0]
000074c3551cfa8b  vmovaps [rsp+0xE0], xmm15
000074c3551cfa94  movaps xmm14, xmm13
000074c3551cfa98  addpd xmm14, xmm1
000074c3551cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000074c3551cfaa3  ptest xmm15, xmm15
000074c3551cfaa9  jnz 0x000074C3551D1AD8
000074c3551cfaaf  vmovaps xmm1, [rsp+0xA0]
000074c3551cfab8  vpermilpd xmm1, xmm1, 0x00
000074c3551cfabe  vmovaps xmm13, [rsp+0x110]
000074c3551cfac7  vmovaps [rsp+0x110], xmm14
000074c3551cfad0  movaps xmm15, xmm13
000074c3551cfad4  mulpd xmm15, xmm1
000074c3551cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000074c3551cfadf  ptest xmm14, xmm14
000074c3551cfae5  jnz 0x000074C3551D1C1B
000074c3551cfaeb  lea rax, [r14+0x80]
000074c3551cfaf2  movups xmm1, [r13+rax*1]
000074c3551cfaf8  vmovaps xmm13, [rsp+0xC0]
000074c3551cfb01  vmovaps [rsp+0xC0], xmm1
000074c3551cfb0a  movaps xmm14, xmm13
000074c3551cfb0e  addpd xmm14, xmm2
000074c3551cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000074c3551cfb19  ptest xmm1, xmm1
000074c3551cfb1e  jnz 0x000074C3551D1D68
000074c3551cfb24  vmovaps xmm13, [rsp+0x100]
000074c3551cfb2d  vmovaps xmm2, [rsp+0x30]
000074c3551cfb33  vmovaps [rsp+0x30], xmm15
000074c3551cfb39  movaps xmm1, xmm13
000074c3551cfb3d  addpd xmm1, xmm2
000074c3551cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000074c3551cfb46  ptest xmm15, xmm15
000074c3551cfb4c  jnz 0x000074C3551D1EAB
000074c3551cfb52  vmovaps xmm15, [rsp+0x20]
000074c3551cfb58  vmovaps xmm13, [rsp+0x20]
000074c3551cfb5e  por xmm15, xmm13
000074c3551cfb63  movaps [r15+0x2F0], xmm15
000074c3551cfb6b  vmovaps xmm13, [rsp+0xA0]
000074c3551cfb74  vpermilpd xmm13, xmm13, 0x00
000074c3551cfb7a  vmovaps [rsp+0x20], xmm1
000074c3551cfb80  vmovaps xmm1, [rsp+0xC0]
000074c3551cfb89  vmovaps [rsp+0xA0], xmm15
000074c3551cfb92  movaps xmm2, xmm1
000074c3551cfb95  mulpd xmm2, xmm13
000074c3551cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000074c3551cfb9f  ptest xmm15, xmm15
000074c3551cfba5  jnz 0x000074C3551D1FEC
000074c3551cfbab  lea rax, [r14+0xD0]
000074c3551cfbb2  movups xmm1, [r13+rax*1]
000074c3551cfbb8  vmovaps xmm13, [rsp+0xF0]
000074c3551cfbc1  vmovaps [rsp+0xC0], xmm1
000074c3551cfbca  vmovaps xmm1, [rsp+0xE0]
000074c3551cfbd3  vmovaps [rsp+0xE0], xmm14
000074c3551cfbdc  movaps xmm15, xmm13
000074c3551cfbe0  addpd xmm15, xmm1
000074c3551cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000074c3551cfbeb  ptest xmm14, xmm14
000074c3551cfbf1  jnz 0x000074C3551D2137
000074c3551cfbf7  vmovaps xmm1, [rsp+0xB0]
000074c3551cfc00  vpermilpd xmm1, xmm1, 0x00
000074c3551cfc06  movaps xmm14, xmm11
000074c3551cfc0a  mulpd xmm14, xmm1
000074c3551cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000074c3551cfc15  ptest xmm13, xmm13
000074c3551cfc1b  jnz 0x000074C3551D227A
000074c3551cfc21  movaps [r15+0x260], xmm14
000074c3551cfc29  vxorps xmm1, xmm1, xmm1
000074c3551cfc2d  vpbroadcastq xmm1, xmm1
000074c3551cfc32  movaps [r15+0x1B0], xmm1
000074c3551cfc3a  vmovaps xmm1, [rsp+0xB0]
000074c3551cfc43  vpermilpd xmm1, xmm1, 0x00
000074c3551cfc49  vmovaps xmm11, [rsp+0xC0]
000074c3551cfc52  vmovaps [rsp+0xC0], xmm15
000074c3551cfc5b  movaps xmm13, xmm11
000074c3551cfc5f  mulpd xmm13, xmm1
000074c3551cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000074c3551cfc6a  ptest xmm15, xmm15
000074c3551cfc70  jnz 0x000074C3551D23BD
000074c3551cfc76  lea rax, [r14+0xC0]
000074c3551cfc7d  movups xmm1, [r13+rax*1]
000074c3551cfc83  vmovaps xmm11, [rsp+0x110]
000074c3551cfc8c  vmovaps [rsp+0xF0], xmm1
000074c3551cfc95  vmovaps xmm1, [rsp+0x30]
000074c3551cfc9b  vmovaps [rsp+0x30], xmm14
000074c3551cfca1  movaps xmm15, xmm11
000074c3551cfca5  addpd xmm15, xmm1
000074c3551cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000074c3551cfcb0  ptest xmm14, xmm14
000074c3551cfcb6  jnz 0x000074C3551D250A
000074c3551cfcbc  vmovaps [rsp+0x100], xmm9
000074c3551cfcc5  vmovaps xmm1, [rsp+0x100]
000074c3551cfcce  por xmm9, xmm1
000074c3551cfcd3  movaps [r15+0x270], xmm9
000074c3551cfcdb  vmovaps [rsp+0x100], xmm6
000074c3551cfce4  vmovaps xmm1, [rsp+0x100]
000074c3551cfced  por xmm6, xmm1
000074c3551cfcf1  movaps [r15+0x1A0], xmm6
000074c3551cfcf9  vmovaps xmm14, [rsp+0xB0]
000074c3551cfd02  vpermilpd xmm14, xmm14, 0x00
000074c3551cfd08  vmovaps xmm6, [rsp+0xF0]
000074c3551cfd11  vmovaps [rsp+0xF0], xmm1
000074c3551cfd1a  movaps xmm11, xmm6
000074c3551cfd1e  mulpd xmm11, xmm14
000074c3551cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000074c3551cfd29  ptest xmm1, xmm1
000074c3551cfd2e  jnz 0x000074C3551D264D
000074c3551cfd34  lea rax, [r14+0x20]
000074c3551cfd38  movups xmm1, [r13+rax*1]
000074c3551cfd3e  movaps [r15+0x110], xmm1
000074c3551cfd46  vmovaps xmm6, [rsp+0xE0]
000074c3551cfd4f  vmovaps [rsp+0xE0], xmm1
000074c3551cfd58  movaps xmm14, xmm6
000074c3551cfd5c  addpd xmm14, xmm2
000074c3551cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000074c3551cfd67  ptest xmm1, xmm1
000074c3551cfd6c  jnz 0x000074C3551D279A
000074c3551cfd72  vmovaps xmm1, [rsp+0xB0]
000074c3551cfd7b  vpermilpd xmm1, xmm1, 0x00
000074c3551cfd81  movaps xmm6, xmm5
000074c3551cfd84  mulpd xmm6, xmm1
000074c3551cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000074c3551cfd8d  ptest xmm2, xmm2
000074c3551cfd92  jnz 0x000074C3551D28DC
000074c3551cfd98  vmovaps xmm5, [rsp+0x20]
000074c3551cfd9e  movaps xmm1, xmm5
000074c3551cfda1  addpd xmm1, xmm13
000074c3551cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000074c3551cfdab  ptest xmm2, xmm2
000074c3551cfdb0  jnz 0x000074C3551D2A1C
000074c3551cfdb6  vmovaps xmm13, [rsp+0x80]
000074c3551cfdbf  vpermilpd xmm13, xmm13, 0x00
000074c3551cfdc5  vmovaps xmm2, [rsp+0xE0]
000074c3551cfdce  vmovaps [rsp+0x20], xmm1
000074c3551cfdd4  movaps xmm5, xmm2
000074c3551cfdd7  mulpd xmm5, xmm13
000074c3551cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000074c3551cfde1  ptest xmm1, xmm1
000074c3551cfde6  jnz 0x000074C3551D2B5D
000074c3551cfdec  vmovaps xmm1, [rsp+0x80]
000074c3551cfdf5  vpermilpd xmm1, xmm1, 0x00
000074c3551cfdfb  movaps xmm13, xmm10
000074c3551cfdff  mulpd xmm13, xmm1
000074c3551cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000074c3551cfe0a  ptest xmm2, xmm2
000074c3551cfe0f  jnz 0x000074C3551D2C9E
000074c3551cfe15  vmovaps xmm10, [rsp+0x30]
000074c3551cfe1b  movaps xmm1, xmm15
000074c3551cfe1f  addpd xmm1, xmm10
000074c3551cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000074c3551cfe29  ptest xmm2, xmm2
000074c3551cfe2e  jnz 0x000074C3551D2DE1
000074c3551cfe34  vmovaps xmm10, [rsp+0xC0]
000074c3551cfe3d  movaps xmm15, xmm10
000074c3551cfe41  addpd xmm15, xmm11
000074c3551cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000074c3551cfe4c  ptest xmm2, xmm2
000074c3551cfe51  jnz 0x000074C3551D2F23
000074c3551cfe57  vmovaps xmm11, [rsp+0x80]
000074c3551cfe60  vpermilpd xmm11, xmm11, 0x00
000074c3551cfe66  movaps xmm10, xmm12
000074c3551cfe6a  mulpd xmm10, xmm11
000074c3551cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000074c3551cfe75  ptest xmm2, xmm2
000074c3551cfe7a  jnz 0x000074C3551D3067
000074c3551cfe80  vmovaps xmm12, [rsp+0x80]
000074c3551cfe89  vpermilpd xmm12, xmm12, 0x00
000074c3551cfe8f  vmovaps xmm2, [rsp+0xA0]
000074c3551cfe98  vmovaps [rsp+0x30], xmm1
000074c3551cfe9e  movaps xmm11, xmm2
000074c3551cfea2  mulpd xmm11, xmm12
000074c3551cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000074c3551cfead  ptest xmm1, xmm1
000074c3551cfeb2  jnz 0x000074C3551D31AB
000074c3551cfeb8  movaps xmm1, xmm14
000074c3551cfebc  addpd xmm1, xmm6
000074c3551cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000074c3551cfec5  ptest xmm12, xmm12
000074c3551cfecb  jnz 0x000074C3551D32EE
000074c3551cfed1  vmovaps xmm12, [rsp+0x20]
000074c3551cfed7  movaps xmm14, xmm12
000074c3551cfedb  addpd xmm14, xmm5
000074c3551cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000074c3551cfee6  ptest xmm6, xmm6
000074c3551cfeeb  jnz 0x000074C3551D342F
000074c3551cfef1  vmovaps xmm12, [rsp+0x90]
000074c3551cfefa  vpermilpd xmm12, xmm12, 0x00
000074c3551cff00  movaps xmm6, xmm9
000074c3551cff04  mulpd xmm6, xmm12
000074c3551cff09  vcmppd xmm5, xmm6, xmm6, 0x03
000074c3551cff0e  ptest xmm5, xmm5
000074c3551cff13  jnz 0x000074C3551D3572
000074c3551cff19  movaps xmm12, xmm15
000074c3551cff1d  addpd xmm12, xmm13
000074c3551cff22  vcmppd xmm9, xmm12, xmm12, 0x03
000074c3551cff28  ptest xmm9, xmm9
000074c3551cff2e  jnz 0x000074C3551D36B4
000074c3551cff34  vmovaps xmm13, [rsp+0x30]
000074c3551cff3a  movaps xmm15, xmm13
000074c3551cff3e  addpd xmm15, xmm10
000074c3551cff43  vcmppd xmm9, xmm15, xmm15, 0x03
000074c3551cff49  ptest xmm9, xmm9
000074c3551cff4f  jnz 0x000074C3551D37F8
000074c3551cff55  vmovaps xmm13, [rsp+0xD0]
000074c3551cff5e  vmovaps xmm10, [rsp+0xD0]
000074c3551cff67  por xmm13, xmm10
000074c3551cff6c  movaps [r15+0x250], xmm13
000074c3551cff74  vmovaps [rsp+0x20], xmm7
000074c3551cff7a  vmovaps xmm13, [rsp+0x20]
000074c3551cff80  por xmm7, xmm13
000074c3551cff85  movaps [r15+0x2A0], xmm7
000074c3551cff8d  vmovaps [rsp+0x20], xmm3
000074c3551cff93  vmovaps xmm13, [rsp+0x20]
000074c3551cff99  por xmm3, xmm13
000074c3551cff9e  movaps [r15+0x1D0], xmm3
000074c3551cffa6  lea rax, [r14+0x40]
000074c3551cffaa  movups xmm13, [r13+rax*1]
000074c3551cffb0  movaps [r15+0x2C0], xmm13
000074c3551cffb8  vmovaps xmm10, [rsp+0x90]
000074c3551cffc1  vpermilpd xmm10, xmm10, 0x00
000074c3551cffc7  movaps xmm9, xmm8
000074c3551cffcb  mulpd xmm9, xmm10
000074c3551cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000074c3551cffd6  ptest xmm5, xmm5
000074c3551cffdb  jnz 0x000074C3551D3946
000074c3551cffe1  movaps xmm10, xmm1
000074c3551cffe5  addpd xmm10, xmm11
000074c3551cffea  vcmppd xmm8, xmm10, xmm10, 0x03
000074c3551cfff0  ptest xmm8, xmm8
000074c3551cfff6  jnz 0x000074C3551D3A8A
000074c3551cfffc  movaps xmm1, xmm14
000074c3551d0000  addpd xmm1, xmm6
000074c3551d0004  vcmppd xmm11, xmm1, xmm1, 0x03
000074c3551d0009  ptest xmm11, xmm11
000074c3551d000f  jnz 0x000074C3551D3BCD
000074c3551d0015  vmovaps xmm14, [rsp+0x90]
000074c3551d001e  vpermilpd xmm14, xmm14, 0x00
000074c3551d0024  movaps xmm11, xmm13
000074c3551d0028  mulpd xmm11, xmm14
000074c3551d002d  vcmppd xmm8, xmm11, xmm11, 0x03
000074c3551d0033  ptest xmm8, xmm8
000074c3551d0039  jnz 0x000074C3551D3D0E
000074c3551d003f  vmovaps xmm14, [rsp+0x90]
000074c3551d0048  vpermilpd xmm14, xmm14, 0x00
000074c3551d004e  vmovaps xmm8, [rsp+0x10]
000074c3551d0054  movaps xmm13, xmm8
000074c3551d0058  mulpd xmm13, xmm14
000074c3551d005d  vcmppd xmm6, xmm13, xmm13, 0x03
000074c3551d0063  ptest xmm6, xmm6
000074c3551d0068  jnz 0x000074C3551D3E52
000074c3551d006e  vmovaps xmm14, [rsp+0x60]
000074c3551d0074  vpermilpd xmm14, xmm14, 0x00
000074c3551d007a  movaps xmm8, xmm7
000074c3551d007e  mulpd xmm8, xmm14
000074c3551d0083  vcmppd xmm6, xmm8, xmm8, 0x03
000074c3551d0089  ptest xmm6, xmm6
000074c3551d008e  jnz 0x000074C3551D3F96
000074c3551d0094  movaps xmm14, xmm12
000074c3551d0098  addpd xmm14, xmm9
000074c3551d009d  vcmppd xmm7, xmm14, xmm14, 0x03
000074c3551d00a3  ptest xmm7, xmm7
000074c3551d00a8  jnz 0x000074C3551D40D9
000074c3551d00ae  vmovaps xmm12, [rsp+0x60]
000074c3551d00b4  vpermilpd xmm12, xmm12, 0x00
000074c3551d00ba  vmovaps xmm7, [rsp+0xF0]
000074c3551d00c3  movaps xmm9, xmm7
000074c3551d00c7  mulpd xmm9, xmm12
000074c3551d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000074c3551d00d2  ptest xmm6, xmm6
000074c3551d00d7  jnz 0x000074C3551D421D
000074c3551d00dd  movaps xmm12, xmm15
000074c3551d00e1  addpd xmm12, xmm11
000074c3551d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000074c3551d00ec  ptest xmm7, xmm7
000074c3551d00f1  jnz 0x000074C3551D4360
000074c3551d00f7  vmovaps xmm15, [rsp+0x60]
000074c3551d00fd  vpermilpd xmm15, xmm15, 0x00
000074c3551d0103  vmovaps xmm7, [rsp+0x40]
000074c3551d0109  movaps xmm11, xmm7
000074c3551d010d  mulpd xmm11, xmm15
000074c3551d0112  vcmppd xmm6, xmm11, xmm11, 0x03
000074c3551d0118  ptest xmm6, xmm6
000074c3551d011d  jnz 0x000074C3551D44A4
000074c3551d0123  movaps xmm15, xmm10
000074c3551d0127  addpd xmm15, xmm13
000074c3551d012c  vcmppd xmm7, xmm15, xmm15, 0x03
000074c3551d0132  ptest xmm7, xmm7
000074c3551d0137  jnz 0x000074C3551D45E7
000074c3551d013d  vmovaps xmm13, [rsp+0x60]
000074c3551d0143  vpermilpd xmm13, xmm13, 0x00
000074c3551d0149  vmovaps xmm7, [rsp+0x50]
000074c3551d014f  movaps xmm10, xmm7
000074c3551d0153  mulpd xmm10, xmm13
000074c3551d0158  vcmppd xmm6, xmm10, xmm10, 0x03
000074c3551d015e  ptest xmm6, xmm6
000074c3551d0163  jnz 0x000074C3551D472B
000074c3551d0169  movaps xmm13, xmm1
000074c3551d016d  addpd xmm13, xmm8
000074c3551d0172  vcmppd xmm7, xmm13, xmm13, 0x03
000074c3551d0178  ptest xmm7, xmm7
000074c3551d017d  jnz 0x000074C3551D486E
000074c3551d0183  lea rax, [r14+0x70]
000074c3551d0187  movups xmm1, [r13+rax*1]
000074c3551d018d  movaps [r15+0x240], xmm1
000074c3551d0195  movaps xmm8, xmm14
000074c3551d0199  addpd xmm8, xmm9
000074c3551d019e  vcmppd xmm7, xmm8, xmm8, 0x03
000074c3551d01a4  ptest xmm7, xmm7
000074c3551d01a9  jnz 0x000074C3551D49BB
000074c3551d01af  movaps [r15+0x170], xmm8
000074c3551d01b7  vmovaps xmm14, [rsp+0x70]
000074c3551d01bd  vpermilpd xmm14, xmm14, 0x00
000074c3551d01c3  movaps xmm9, xmm1
000074c3551d01c7  mulpd xmm9, xmm14
000074c3551d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000074c3551d01d2  ptest xmm7, xmm7
000074c3551d01d7  jnz 0x000074C3551D4AFF
000074c3551d01dd  vmovaps xmm1, [rsp+0x70]
000074c3551d01e3  vpermilpd xmm1, xmm1, 0x00
000074c3551d01e9  movaps xmm14, xmm4
000074c3551d01ed  mulpd xmm14, xmm1
000074c3551d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000074c3551d01f8  ptest xmm7, xmm7
000074c3551d01fd  jnz 0x000074C3551D4C42
000074c3551d0203  movaps [r15+0x180], xmm14
000074c3551d020b  movaps xmm1, xmm12
000074c3551d020f  addpd xmm1, xmm11
000074c3551d0214  vcmppd xmm7, xmm1, xmm1, 0x03
000074c3551d0219  ptest xmm7, xmm7
000074c3551d021e  jnz 0x000074C3551D4D84
000074c3551d0224  movaps [r15+0x210], xmm1
000074c3551d022c  movups xmm12, [r13+r14*1]
000074c3551d0232  lea rax, [r14+0x10]
000074c3551d0236  movups xmm11, [r13+rax*1]
000074c3551d023c  movaps [r15+0x230], xmm11
000074c3551d0244  movaps xmm7, xmm15
000074c3551d0248  addpd xmm7, xmm10
000074c3551d024d  vcmppd xmm6, xmm7, xmm7, 0x03
000074c3551d0252  ptest xmm6, xmm6
000074c3551d0257  jnz 0x000074C3551D4EDA
000074c3551d025d  movaps [r15+0x130], xmm7
000074c3551d0265  vmovaps xmm15, [rsp+0x70]
000074c3551d026b  vpermilpd xmm15, xmm15, 0x00
000074c3551d0271  movaps xmm10, xmm11
000074c3551d0275  mulpd xmm10, xmm15
000074c3551d027a  vcmppd xmm6, xmm10, xmm10, 0x03
000074c3551d0280  ptest xmm6, xmm6
000074c3551d0285  jnz 0x000074C3551D501C
000074c3551d028b  movaps [r15+0x220], xmm10
000074c3551d0293  vmovaps xmm15, [rsp+0x70]
000074c3551d0299  vpermilpd xmm15, xmm15, 0x00
000074c3551d029f  movaps xmm11, xmm12
000074c3551d02a3  mulpd xmm11, xmm15
000074c3551d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000074c3551d02ae  ptest xmm6, xmm6
000074c3551d02b3  jnz 0x000074C3551D5160
000074c3551d02b9  movaps xmm15, xmm13
000074c3551d02bd  addpd xmm15, xmm9
000074c3551d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000074c3551d02c8  ptest xmm12, xmm12
000074c3551d02ce  jnz 0x000074C3551D52A4
000074c3551d02d4  movaps [r15+0x140], xmm15
000074c3551d02dc  movaps xmm13, xmm8
000074c3551d02e0  addpd xmm13, xmm14
000074c3551d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000074c3551d02eb  ptest xmm12, xmm12
000074c3551d02f1  jnz 0x000074C3551D53E8
000074c3551d02f7  movaps [r15+0x150], xmm13
000074c3551d02ff  movaps xmm14, xmm1
000074c3551d0303  addpd xmm14, xmm10
000074c3551d0308  vcmppd xmm12, xmm14, xmm14, 0x03
000074c3551d030e  ptest xmm12, xmm12
000074c3551d0314  jnz 0x000074C3551D552C
000074c3551d031a  movaps [r15+0x160], xmm14
000074c3551d0322  movaps xmm1, xmm7
000074c3551d0325  addpd xmm1, xmm11
000074c3551d032a  vcmppd xmm12, xmm1, xmm1, 0x03
000074c3551d032f  ptest xmm12, xmm12
000074c3551d0335  jnz 0x000074C3551D566F
000074c3551d033b  movaps [r15+0x120], xmm1
000074c3551d0343  mov eax, 0x430920
000074c3551d0348  movups [r13+rax*1], xmm15
000074c3551d034e  mov eax, 0x430930
000074c3551d0353  movups [r13+rax*1], xmm13
000074c3551d0359  mov eax, 0x430940
000074c3551d035e  movups [r13+rax*1], xmm14
000074c3551d0364  mov eax, 0x430950
000074c3551d0369  movups [r13+rax*1], xmm1
000074c3551d036f  mov eax, [r15+0x108]
000074c3551d0376  sahf
000074c3551d0377  jnz 0x000074C3551D03A9
000074c3551d0379  cmp dword ptr [r15+0x318], 0x00
000074c3551d0381  jz 0x000074C3551DB900
000074c3551d0387  nop [rax+rax*1], ax
000074c3551d0390  nop [rax+rax*1], eax
000074c3551d0398  mov eax, 0x410444
000074c3551d039d  mov [r15+0x100], rax
000074c3551d03a4  jmp 0x000074C354FFE110
000074c3551d03a9  cmp dword ptr [r15+0x318], 0x00
000074c3551d03b1  jz 0x000074C3551D57E0
000074c3551d03b7  nop [rax+rax*1], ax
000074c3551d03c0  nop [rax+rax*1], eax
000074c3551d03c8  mov eax, 0x410278
000074c3551d03cd  mov [r15+0x100], rax
000074c3551d03d4  jmp 0x000074C354FFE110
000074c3551d03d9  int3
000074c3551d03da  call 0x000074C3550B52F0
000074c3551d03df  jmp 0x000074C3551CF016
000074c3551d03e4  call 0x000074C3550C4620
000074c3551d03e9  jmp 0x000074C3551CF023
000074c3551d03ee  call 0x000074C3550C33A0
000074c3551d03f3  jmp 0x000074C3551CF035
000074c3551d03f8  call 0x000074C3550C2120
000074c3551d03fd  jmp 0x000074C3551CF03F
000074c3551d0402  call 0x000074C3550C0860
000074c3551d0407  jmp 0x000074C3551CF067
000074c3551d040c  call 0x000074C3550BF5F0
000074c3551d0411  jmp 0x000074C3551CF073
000074c3551d0416  call 0x000074C3550C0860
000074c3551d041b  jmp 0x000074C3551CF0A5
000074c3551d0420  call 0x000074C3550BF5F0
000074c3551d0425  jmp 0x000074C3551CF0B1
000074c3551d042a  call 0x000074C3550C4740
000074c3551d042f  jmp 0x000074C3551CF0BE
000074c3551d0434  call 0x000074C3550B5400
000074c3551d0439  jmp 0x000074C3551CF0CB
000074c3551d043e  call 0x000074C3550B52F0
000074c3551d0443  jmp 0x000074C3551CF0D8
000074c3551d0448  call 0x000074C3550C4620
000074c3551d044d  jmp 0x000074C3551CF0E5
000074c3551d0452  call 0x000074C3550C0860
000074c3551d0457  jmp 0x000074C3551CF10D
000074c3551d045c  call 0x000074C3550BF5F0
000074c3551d0461  jmp 0x000074C3551CF119
000074c3551d0466  call 0x000074C355009D70
000074c3551d046b  jmp 0x000074C3551CF11F
000074c3551d0470  call 0x000074C3550BE9C0
000074c3551d0475  jmp 0x000074C3551CF129
000074c3551d047a  call 0x000074C3550C0860
000074c3551d047f  jmp 0x000074C3551CF151
000074c3551d0484  call 0x000074C3550BF5F0
000074c3551d0489  jmp 0x000074C3551CF15D
000074c3551d048e  call 0x000074C3550BD750
000074c3551d0493  jmp 0x000074C3551CF16A
000074c3551d0498  call 0x000074C3550BC4E0
000074c3551d049d  jmp 0x000074C3551CF177
000074c3551d04a2  call 0x000074C3550C4740
000074c3551d04a7  jmp 0x000074C3551CF184
000074c3551d04ac  call 0x000074C3550B5400
000074c3551d04b1  jmp 0x000074C3551CF191
000074c3551d04b6  call 0x000074C3550B52F0
000074c3551d04bb  jmp 0x000074C3551CF19E
000074c3551d04c0  call 0x000074C3550C4620
000074c3551d04c5  jmp 0x000074C3551CF1AB
000074c3551d04ca  call 0x000074C3550C0860
000074c3551d04cf  jmp 0x000074C3551CF1BE
000074c3551d04d4  call 0x000074C3550BB270
000074c3551d04d9  jmp 0x000074C3551CF1CB
000074c3551d04de  call 0x000074C3550BA000
000074c3551d04e3  jmp 0x000074C3551CF1D8
000074c3551d04e8  call 0x000074C3550B8D90
000074c3551d04ed  jmp 0x000074C3551CF1E5
000074c3551d04f2  call 0x000074C3550B8A20
000074c3551d04f7  jmp 0x000074C3551CF1F2
000074c3551d04fc  call 0x000074C3550B5400
000074c3551d0501  jmp 0x000074C3551CF1FC
000074c3551d0506  call 0x000074C3550C2240
000074c3551d050b  jmp 0x000074C3551CF206
000074c3551d0510  call 0x000074C3550B52F0
000074c3551d0515  jmp 0x000074C3551CF210
000074c3551d051a  call 0x000074C3550C2120
000074c3551d051f  jmp 0x000074C3551CF21A
000074c3551d0524  call 0x000074C3550B77B0
000074c3551d0529  jmp 0x000074C3551CF224
000074c3551d052e  call 0x000074C3550B6550
000074c3551d0533  jmp 0x000074C3551CF22E
000074c3551d0538  call 0x000074C3550BFD50
000074c3551d053d  jmp 0x000074C3551CF240
000074c3551d0542  call 0x000074C3550B8EA0
000074c3551d0547  jmp 0x000074C3551CF24A
000074c3551d054c  call 0x000074C3550BFC30
000074c3551d0551  jmp 0x000074C3551CF257
000074c3551d0556  call 0x000074C3550B8D90
000074c3551d055b  jmp 0x000074C3551CF264
000074c3551d0560  call 0x000074C3550C2240
000074c3551d0565  jmp 0x000074C3551CF271
000074c3551d056a  call 0x000074C3550B5400
000074c3551d056f  jmp 0x000074C3551CF27E
000074c3551d0574  call 0x000074C3550B52F0
000074c3551d0579  jmp 0x000074C3551CF28B
000074c3551d057e  call 0x000074C3550C2120
000074c3551d0583  jmp 0x000074C3551CF298
000074c3551d0588  call 0x000074C3550B52F0
000074c3551d058d  jmp 0x000074C3551CF2AB
000074c3551d0592  call 0x000074C3550B52F0
000074c3551d0597  jmp 0x000074C3551CF2BE
000074c3551d059c  call 0x000074C3550B52F0
000074c3551d05a1  jmp 0x000074C3551CF2D1
000074c3551d05a6  call 0x000074C3550B52F0
000074c3551d05ab  jmp 0x000074C3551CF2E4
000074c3551d05b0  call 0x000074C3550C2240
000074c3551d05b5  jmp 0x000074C3551CF2F9
000074c3551d05ba  call 0x000074C3550C2240
000074c3551d05bf  jmp 0x000074C3551CF30C
000074c3551d05c4  call 0x000074C3550C2120
000074c3551d05c9  jmp 0x000074C3551CF319
000074c3551d05ce  call 0x000074C3550B52F0
000074c3551d05d3  jmp 0x000074C3551CF32C
000074c3551d05d8  call 0x000074C3550B52F0
000074c3551d05dd  jmp 0x000074C3551CF34F
000074c3551d05e2  call 0x000074C3550B52F0
000074c3551d05e7  jmp 0x000074C3551CF362
000074c3551d05ec  call 0x000074C354FFF540
000074c3551d05f1  jmp 0x000074C3551CF380
000074c3551d05f6  call 0x000074C355008C20
000074c3551d05fb  jmp 0x000074C3551CF38A
000074c3551d0600  call 0x000074C3550D6600
000074c3551d0605  jmp 0x000074C3551CF396
000074c3551d060a  call 0x000074C354FFF540
000074c3551d060f  jmp 0x000074C3551CF3A6
000074c3551d0614  call 0x000074C3550C0370
000074c3551d0619  jmp 0x000074C3551CF3D4
000074c3551d061e  call 0x000074C3550BF100
000074c3551d0623  jmp 0x000074C3551CF3DD
000074c3551d0628  call 0x000074C3550C0370
000074c3551d062d  jmp 0x000074C3551CF43B
000074c3551d0632  call 0x000074C3550BF100
000074c3551d0637  jmp 0x000074C3551CF444
000074c3551d063c  call 0x000074C3550C0370
000074c3551d0641  jmp 0x000074C3551CF48B
000074c3551d0646  call 0x000074C3550BF100
000074c3551d064b  jmp 0x000074C3551CF494
000074c3551d0650  call 0x000074C35500B720
000074c3551d0655  jmp 0x000074C3551CF4D7
000074c3551d065a  call 0x000074C3550B47C0
000074c3551d065f  jmp 0x000074C3551CF4EA
000074c3551d0664  call 0x000074C355008B00
000074c3551d0669  jmp 0x000074C3551CF501
000074c3551d066e  call 0x000074C354FFF430
000074c3551d0673  jmp 0x000074C3551CF514
000074c3551d0678  call 0x000074C354FFF430
000074c3551d067d  jmp 0x000074C3551CF527
000074c3551d0682  sub rsp, 0x08
000074c3551d0686  push rax
000074c3551d0687  push rcx
000074c3551d0688  push rdx
000074c3551d0689  push rdi
000074c3551d068a  push rsi
000074c3551d068b  push r8
000074c3551d068d  push r9
000074c3551d068f  push r10
000074c3551d0691  push r11
000074c3551d0693  sub rsp, 0xF0
000074c3551d069a  vmovaps [rsp], xmm0
000074c3551d069f  vmovaps [rsp+0x10], xmm2
000074c3551d06a5  vmovaps [rsp+0x20], xmm3
000074c3551d06ab  vmovaps [rsp+0x30], xmm4
000074c3551d06b1  vmovaps [rsp+0x40], xmm5
000074c3551d06b7  vmovaps [rsp+0x50], xmm6
000074c3551d06bd  vmovaps [rsp+0x60], xmm7
000074c3551d06c3  vmovaps [rsp+0x70], xmm8
000074c3551d06c9  vmovaps [rsp+0x80], xmm9
000074c3551d06d2  vmovaps [rsp+0x90], xmm10
000074c3551d06db  vmovaps [rsp+0xA0], xmm11
000074c3551d06e4  vmovaps [rsp+0xB0], xmm12
000074c3551d06ed  vmovaps [rsp+0xC0], xmm13
000074c3551d06f6  vmovaps [rsp+0xD0], xmm14
000074c3551d06ff  vmovaps [rsp+0xE0], xmm15
000074c3551d0708  sub rsp, 0x30
000074c3551d070c  movaps [rsp], xmm1
000074c3551d0710  movaps [rsp+0x10], xmm15
000074c3551d0716  movaps [rsp+0x20], xmm14
000074c3551d071c  lea rdi, [rsp]
000074c3551d0720  mov esi, 0x00
000074c3551d0725  mov rax, 0x5F9407FA9530
000074c3551d072f  call rax
000074c3551d0731  movaps xmm1, [rsp]
000074c3551d0735  add rsp, 0x30
000074c3551d0739  vmovaps xmm0, [rsp]
000074c3551d073e  vmovaps xmm2, [rsp+0x10]
000074c3551d0744  vmovaps xmm3, [rsp+0x20]
000074c3551d074a  vmovaps xmm4, [rsp+0x30]
000074c3551d0750  vmovaps xmm5, [rsp+0x40]
000074c3551d0756  vmovaps xmm6, [rsp+0x50]
000074c3551d075c  vmovaps xmm7, [rsp+0x60]
000074c3551d0762  vmovaps xmm8, [rsp+0x70]
000074c3551d0768  vmovaps xmm9, [rsp+0x80]
000074c3551d0771  vmovaps xmm10, [rsp+0x90]
000074c3551d077a  vmovaps xmm11, [rsp+0xA0]
000074c3551d0783  vmovaps xmm12, [rsp+0xB0]
000074c3551d078c  vmovaps xmm13, [rsp+0xC0]
000074c3551d0795  vmovaps xmm14, [rsp+0xD0]
000074c3551d079e  vmovaps xmm15, [rsp+0xE0]
000074c3551d07a7  add rsp, 0xF0
000074c3551d07ae  pop r11
000074c3551d07b0  pop r10
000074c3551d07b2  pop r9
000074c3551d07b4  pop r8
000074c3551d07b6  pop rsi
000074c3551d07b7  pop rdi
000074c3551d07b8  pop rdx
000074c3551d07b9  pop rcx
000074c3551d07ba  pop rax
000074c3551d07bb  add rsp, 0x08
000074c3551d07bf  jmp 0x000074C3551CF581
000074c3551d07c4  sub rsp, 0x08
000074c3551d07c8  push rax
000074c3551d07c9  push rcx
000074c3551d07ca  push rdx
000074c3551d07cb  push rdi
000074c3551d07cc  push rsi
000074c3551d07cd  push r8
000074c3551d07cf  push r9
000074c3551d07d1  push r10
000074c3551d07d3  push r11
000074c3551d07d5  sub rsp, 0xF0
000074c3551d07dc  vmovaps [rsp], xmm0
000074c3551d07e1  vmovaps [rsp+0x10], xmm1
000074c3551d07e7  vmovaps [rsp+0x20], xmm2
000074c3551d07ed  vmovaps [rsp+0x30], xmm3
000074c3551d07f3  vmovaps [rsp+0x40], xmm4
000074c3551d07f9  vmovaps [rsp+0x50], xmm5
000074c3551d07ff  vmovaps [rsp+0x60], xmm6
000074c3551d0805  vmovaps [rsp+0x70], xmm7
000074c3551d080b  vmovaps [rsp+0x80], xmm8
000074c3551d0814  vmovaps [rsp+0x90], xmm9
000074c3551d081d  vmovaps [rsp+0xA0], xmm10
000074c3551d0826  vmovaps [rsp+0xB0], xmm11
000074c3551d082f  vmovaps [rsp+0xC0], xmm12
000074c3551d0838  vmovaps [rsp+0xD0], xmm14
000074c3551d0841  vmovaps [rsp+0xE0], xmm15
000074c3551d084a  sub rsp, 0x30
000074c3551d084e  movaps [rsp], xmm13
000074c3551d0853  movaps [rsp+0x10], xmm1
000074c3551d0858  movaps [rsp+0x20], xmm14
000074c3551d085e  lea rdi, [rsp]
000074c3551d0862  mov esi, 0x00
000074c3551d0867  mov rax, 0x5F9407FA9530
000074c3551d0871  call rax
000074c3551d0873  movaps xmm13, [rsp]
000074c3551d0878  add rsp, 0x30
000074c3551d087c  vmovaps xmm0, [rsp]
000074c3551d0881  vmovaps xmm1, [rsp+0x10]
000074c3551d0887  vmovaps xmm2, [rsp+0x20]
000074c3551d088d  vmovaps xmm3, [rsp+0x30]
000074c3551d0893  vmovaps xmm4, [rsp+0x40]
000074c3551d0899  vmovaps xmm5, [rsp+0x50]
000074c3551d089f  vmovaps xmm6, [rsp+0x60]
000074c3551d08a5  vmovaps xmm7, [rsp+0x70]
000074c3551d08ab  vmovaps xmm8, [rsp+0x80]
000074c3551d08b4  vmovaps xmm9, [rsp+0x90]
000074c3551d08bd  vmovaps xmm10, [rsp+0xA0]
000074c3551d08c6  vmovaps xmm11, [rsp+0xB0]
000074c3551d08cf  vmovaps xmm12, [rsp+0xC0]
000074c3551d08d8  vmovaps xmm14, [rsp+0xD0]
000074c3551d08e1  vmovaps xmm15, [rsp+0xE0]
000074c3551d08ea  add rsp, 0xF0
000074c3551d08f1  pop r11
000074c3551d08f3  pop r10
000074c3551d08f5  pop r9
000074c3551d08f7  pop r8
000074c3551d08f9  pop rsi
000074c3551d08fa  pop rdi
000074c3551d08fb  pop rdx
000074c3551d08fc  pop rcx
000074c3551d08fd  pop rax
000074c3551d08fe  add rsp, 0x08
000074c3551d0902  jmp 0x000074C3551CF5CF
000074c3551d0907  sub rsp, 0x08
000074c3551d090b  push rax
000074c3551d090c  push rcx
000074c3551d090d  push rdx
000074c3551d090e  push rdi
000074c3551d090f  push rsi
000074c3551d0910  push r8
000074c3551d0912  push r9
000074c3551d0914  push r10
000074c3551d0916  push r11
000074c3551d0918  sub rsp, 0xF0
000074c3551d091f  vmovaps [rsp], xmm0
000074c3551d0924  vmovaps [rsp+0x10], xmm1
000074c3551d092a  vmovaps [rsp+0x20], xmm2
000074c3551d0930  vmovaps [rsp+0x30], xmm3
000074c3551d0936  vmovaps [rsp+0x40], xmm4
000074c3551d093c  vmovaps [rsp+0x50], xmm5
000074c3551d0942  vmovaps [rsp+0x60], xmm6
000074c3551d0948  vmovaps [rsp+0x70], xmm7
000074c3551d094e  vmovaps [rsp+0x80], xmm8
000074c3551d0957  vmovaps [rsp+0x90], xmm9
000074c3551d0960  vmovaps [rsp+0xA0], xmm10
000074c3551d0969  vmovaps [rsp+0xB0], xmm11
000074c3551d0972  vmovaps [rsp+0xC0], xmm12
000074c3551d097b  vmovaps [rsp+0xD0], xmm13
000074c3551d0984  vmovaps [rsp+0xE0], xmm14
000074c3551d098d  sub rsp, 0x30
000074c3551d0991  movaps [rsp], xmm15
000074c3551d0996  movaps [rsp+0x10], xmm14
000074c3551d099c  movaps [rsp+0x20], xmm1
000074c3551d09a1  lea rdi, [rsp]
000074c3551d09a5  mov esi, 0x00
000074c3551d09aa  mov rax, 0x5F9407FA9530
000074c3551d09b4  call rax
000074c3551d09b6  movaps xmm15, [rsp]
000074c3551d09bb  add rsp, 0x30
000074c3551d09bf  vmovaps xmm0, [rsp]
000074c3551d09c4  vmovaps xmm1, [rsp+0x10]
000074c3551d09ca  vmovaps xmm2, [rsp+0x20]
000074c3551d09d0  vmovaps xmm3, [rsp+0x30]
000074c3551d09d6  vmovaps xmm4, [rsp+0x40]
000074c3551d09dc  vmovaps xmm5, [rsp+0x50]
000074c3551d09e2  vmovaps xmm6, [rsp+0x60]
000074c3551d09e8  vmovaps xmm7, [rsp+0x70]
000074c3551d09ee  vmovaps xmm8, [rsp+0x80]
000074c3551d09f7  vmovaps xmm9, [rsp+0x90]
000074c3551d0a00  vmovaps xmm10, [rsp+0xA0]
000074c3551d0a09  vmovaps xmm11, [rsp+0xB0]
000074c3551d0a12  vmovaps xmm12, [rsp+0xC0]
000074c3551d0a1b  vmovaps xmm13, [rsp+0xD0]
000074c3551d0a24  vmovaps xmm14, [rsp+0xE0]
000074c3551d0a2d  add rsp, 0xF0
000074c3551d0a34  pop r11
000074c3551d0a36  pop r10
000074c3551d0a38  pop r9
000074c3551d0a3a  pop r8
000074c3551d0a3c  pop rsi
000074c3551d0a3d  pop rdi
000074c3551d0a3e  pop rdx
000074c3551d0a3f  pop rcx
000074c3551d0a40  pop rax
000074c3551d0a41  add rsp, 0x08
000074c3551d0a45  jmp 0x000074C3551CF617
000074c3551d0a4a  sub rsp, 0x08
000074c3551d0a4e  push rax
000074c3551d0a4f  push rcx
000074c3551d0a50  push rdx
000074c3551d0a51  push rdi
000074c3551d0a52  push rsi
000074c3551d0a53  push r8
000074c3551d0a55  push r9
000074c3551d0a57  push r10
000074c3551d0a59  push r11
000074c3551d0a5b  sub rsp, 0xF0
000074c3551d0a62  vmovaps [rsp], xmm0
000074c3551d0a67  vmovaps [rsp+0x10], xmm2
000074c3551d0a6d  vmovaps [rsp+0x20], xmm3
000074c3551d0a73  vmovaps [rsp+0x30], xmm4
000074c3551d0a79  vmovaps [rsp+0x40], xmm5
000074c3551d0a7f  vmovaps [rsp+0x50], xmm6
000074c3551d0a85  vmovaps [rsp+0x60], xmm7
000074c3551d0a8b  vmovaps [rsp+0x70], xmm8
000074c3551d0a91  vmovaps [rsp+0x80], xmm9
000074c3551d0a9a  vmovaps [rsp+0x90], xmm10
000074c3551d0aa3  vmovaps [rsp+0xA0], xmm11
000074c3551d0aac  vmovaps [rsp+0xB0], xmm12
000074c3551d0ab5  vmovaps [rsp+0xC0], xmm13
000074c3551d0abe  vmovaps [rsp+0xD0], xmm14
000074c3551d0ac7  vmovaps [rsp+0xE0], xmm15
000074c3551d0ad0  sub rsp, 0x30
000074c3551d0ad4  movaps [rsp], xmm1
000074c3551d0ad8  movaps [rsp+0x10], xmm14
000074c3551d0ade  movaps [rsp+0x20], xmm10
000074c3551d0ae4  lea rdi, [rsp]
000074c3551d0ae8  mov esi, 0x00
000074c3551d0aed  mov rax, 0x5F9407FA9530
000074c3551d0af7  call rax
000074c3551d0af9  movaps xmm1, [rsp]
000074c3551d0afd  add rsp, 0x30
000074c3551d0b01  vmovaps xmm0, [rsp]
000074c3551d0b06  vmovaps xmm2, [rsp+0x10]
000074c3551d0b0c  vmovaps xmm3, [rsp+0x20]
000074c3551d0b12  vmovaps xmm4, [rsp+0x30]
000074c3551d0b18  vmovaps xmm5, [rsp+0x40]
000074c3551d0b1e  vmovaps xmm6, [rsp+0x50]
000074c3551d0b24  vmovaps xmm7, [rsp+0x60]
000074c3551d0b2a  vmovaps xmm8, [rsp+0x70]
000074c3551d0b30  vmovaps xmm9, [rsp+0x80]
000074c3551d0b39  vmovaps xmm10, [rsp+0x90]
000074c3551d0b42  vmovaps xmm11, [rsp+0xA0]
000074c3551d0b4b  vmovaps xmm12, [rsp+0xB0]
000074c3551d0b54  vmovaps xmm13, [rsp+0xC0]
000074c3551d0b5d  vmovaps xmm14, [rsp+0xD0]
000074c3551d0b66  vmovaps xmm15, [rsp+0xE0]
000074c3551d0b6f  add rsp, 0xF0
000074c3551d0b76  pop r11
000074c3551d0b78  pop r10
000074c3551d0b7a  pop r9
000074c3551d0b7c  pop r8
000074c3551d0b7e  pop rsi
000074c3551d0b7f  pop rdi
000074c3551d0b80  pop rdx
000074c3551d0b81  pop rcx
000074c3551d0b82  pop rax
000074c3551d0b83  add rsp, 0x08
000074c3551d0b87  jmp 0x000074C3551CF631
000074c3551d0b8c  sub rsp, 0x08
000074c3551d0b90  push rax
000074c3551d0b91  push rcx
000074c3551d0b92  push rdx
000074c3551d0b93  push rdi
000074c3551d0b94  push rsi
000074c3551d0b95  push r8
000074c3551d0b97  push r9
000074c3551d0b99  push r10
000074c3551d0b9b  push r11
000074c3551d0b9d  sub rsp, 0xF0
000074c3551d0ba4  vmovaps [rsp], xmm0
000074c3551d0ba9  vmovaps [rsp+0x10], xmm1
000074c3551d0baf  vmovaps [rsp+0x20], xmm2
000074c3551d0bb5  vmovaps [rsp+0x30], xmm3
000074c3551d0bbb  vmovaps [rsp+0x40], xmm4
000074c3551d0bc1  vmovaps [rsp+0x50], xmm5
000074c3551d0bc7  vmovaps [rsp+0x60], xmm6
000074c3551d0bcd  vmovaps [rsp+0x70], xmm7
000074c3551d0bd3  vmovaps [rsp+0x80], xmm8
000074c3551d0bdc  vmovaps [rsp+0x90], xmm9
000074c3551d0be5  vmovaps [rsp+0xA0], xmm10
000074c3551d0bee  vmovaps [rsp+0xB0], xmm11
000074c3551d0bf7  vmovaps [rsp+0xC0], xmm12
000074c3551d0c00  vmovaps [rsp+0xD0], xmm14
000074c3551d0c09  vmovaps [rsp+0xE0], xmm15
000074c3551d0c12  sub rsp, 0x30
000074c3551d0c16  movaps [rsp], xmm13
000074c3551d0c1b  movaps [rsp+0x10], xmm14
000074c3551d0c21  movaps [rsp+0x20], xmm2
000074c3551d0c26  lea rdi, [rsp]
000074c3551d0c2a  mov esi, 0x00
000074c3551d0c2f  mov rax, 0x5F9407FA9530
000074c3551d0c39  call rax
000074c3551d0c3b  movaps xmm13, [rsp]
000074c3551d0c40  add rsp, 0x30
000074c3551d0c44  vmovaps xmm0, [rsp]
000074c3551d0c49  vmovaps xmm1, [rsp+0x10]
000074c3551d0c4f  vmovaps xmm2, [rsp+0x20]
000074c3551d0c55  vmovaps xmm3, [rsp+0x30]
000074c3551d0c5b  vmovaps xmm4, [rsp+0x40]
000074c3551d0c61  vmovaps xmm5, [rsp+0x50]
000074c3551d0c67  vmovaps xmm6, [rsp+0x60]
000074c3551d0c6d  vmovaps xmm7, [rsp+0x70]
000074c3551d0c73  vmovaps xmm8, [rsp+0x80]
000074c3551d0c7c  vmovaps xmm9, [rsp+0x90]
000074c3551d0c85  vmovaps xmm10, [rsp+0xA0]
000074c3551d0c8e  vmovaps xmm11, [rsp+0xB0]
000074c3551d0c97  vmovaps xmm12, [rsp+0xC0]
000074c3551d0ca0  vmovaps xmm14, [rsp+0xD0]
000074c3551d0ca9  vmovaps xmm15, [rsp+0xE0]
000074c3551d0cb2  add rsp, 0xF0
000074c3551d0cb9  pop r11
000074c3551d0cbb  pop r10
000074c3551d0cbd  pop r9
000074c3551d0cbf  pop r8
000074c3551d0cc1  pop rsi
000074c3551d0cc2  pop rdi
000074c3551d0cc3  pop rdx
000074c3551d0cc4  pop rcx
000074c3551d0cc5  pop rax
000074c3551d0cc6  add rsp, 0x08
000074c3551d0cca  jmp 0x000074C3551CF64C
000074c3551d0ccf  sub rsp, 0x08
000074c3551d0cd3  push rax
000074c3551d0cd4  push rcx
000074c3551d0cd5  push rdx
000074c3551d0cd6  push rdi
000074c3551d0cd7  push rsi
000074c3551d0cd8  push r8
000074c3551d0cda  push r9
000074c3551d0cdc  push r10
000074c3551d0cde  push r11
000074c3551d0ce0  sub rsp, 0xF0
000074c3551d0ce7  vmovaps [rsp], xmm0
000074c3551d0cec  vmovaps [rsp+0x10], xmm2
000074c3551d0cf2  vmovaps [rsp+0x20], xmm3
000074c3551d0cf8  vmovaps [rsp+0x30], xmm4
000074c3551d0cfe  vmovaps [rsp+0x40], xmm5
000074c3551d0d04  vmovaps [rsp+0x50], xmm6
000074c3551d0d0a  vmovaps [rsp+0x60], xmm7
000074c3551d0d10  vmovaps [rsp+0x70], xmm8
000074c3551d0d16  vmovaps [rsp+0x80], xmm9
000074c3551d0d1f  vmovaps [rsp+0x90], xmm10
000074c3551d0d28  vmovaps [rsp+0xA0], xmm11
000074c3551d0d31  vmovaps [rsp+0xB0], xmm12
000074c3551d0d3a  vmovaps [rsp+0xC0], xmm13
000074c3551d0d43  vmovaps [rsp+0xD0], xmm14
000074c3551d0d4c  vmovaps [rsp+0xE0], xmm15
000074c3551d0d55  sub rsp, 0x30
000074c3551d0d59  movaps [rsp], xmm1
000074c3551d0d5d  movaps [rsp+0x10], xmm10
000074c3551d0d63  movaps [rsp+0x20], xmm2
000074c3551d0d68  lea rdi, [rsp]
000074c3551d0d6c  mov esi, 0x00
000074c3551d0d71  mov rax, 0x5F9407FA9530
000074c3551d0d7b  call rax
000074c3551d0d7d  movaps xmm1, [rsp]
000074c3551d0d81  add rsp, 0x30
000074c3551d0d85  vmovaps xmm0, [rsp]
000074c3551d0d8a  vmovaps xmm2, [rsp+0x10]
000074c3551d0d90  vmovaps xmm3, [rsp+0x20]
000074c3551d0d96  vmovaps xmm4, [rsp+0x30]
000074c3551d0d9c  vmovaps xmm5, [rsp+0x40]
000074c3551d0da2  vmovaps xmm6, [rsp+0x50]
000074c3551d0da8  vmovaps xmm7, [rsp+0x60]
000074c3551d0dae  vmovaps xmm8, [rsp+0x70]
000074c3551d0db4  vmovaps xmm9, [rsp+0x80]
000074c3551d0dbd  vmovaps xmm10, [rsp+0x90]
000074c3551d0dc6  vmovaps xmm11, [rsp+0xA0]
000074c3551d0dcf  vmovaps xmm12, [rsp+0xB0]
000074c3551d0dd8  vmovaps xmm13, [rsp+0xC0]
000074c3551d0de1  vmovaps xmm14, [rsp+0xD0]
000074c3551d0dea  vmovaps xmm15, [rsp+0xE0]
000074c3551d0df3  add rsp, 0xF0
000074c3551d0dfa  pop r11
000074c3551d0dfc  pop r10
000074c3551d0dfe  pop r9
000074c3551d0e00  pop r8
000074c3551d0e02  pop rsi
000074c3551d0e03  pop rdi
000074c3551d0e04  pop rdx
000074c3551d0e05  pop rcx
000074c3551d0e06  pop rax
000074c3551d0e07  add rsp, 0x08
000074c3551d0e0b  jmp 0x000074C3551CF6B4
000074c3551d0e10  sub rsp, 0x08
000074c3551d0e14  push rax
000074c3551d0e15  push rcx
000074c3551d0e16  push rdx
000074c3551d0e17  push rdi
000074c3551d0e18  push rsi
000074c3551d0e19  push r8
000074c3551d0e1b  push r9
000074c3551d0e1d  push r10
000074c3551d0e1f  push r11
000074c3551d0e21  sub rsp, 0xF0
000074c3551d0e28  vmovaps [rsp], xmm0
000074c3551d0e2d  vmovaps [rsp+0x10], xmm1
000074c3551d0e33  vmovaps [rsp+0x20], xmm2
000074c3551d0e39  vmovaps [rsp+0x30], xmm3
000074c3551d0e3f  vmovaps [rsp+0x40], xmm4
000074c3551d0e45  vmovaps [rsp+0x50], xmm5
000074c3551d0e4b  vmovaps [rsp+0x60], xmm6
000074c3551d0e51  vmovaps [rsp+0x70], xmm7
000074c3551d0e57  vmovaps [rsp+0x80], xmm8
000074c3551d0e60  vmovaps [rsp+0x90], xmm9
000074c3551d0e69  vmovaps [rsp+0xA0], xmm10
000074c3551d0e72  vmovaps [rsp+0xB0], xmm11
000074c3551d0e7b  vmovaps [rsp+0xC0], xmm12
000074c3551d0e84  vmovaps [rsp+0xD0], xmm13
000074c3551d0e8d  vmovaps [rsp+0xE0], xmm14
000074c3551d0e96  sub rsp, 0x30
000074c3551d0e9a  movaps [rsp], xmm15
000074c3551d0e9f  movaps [rsp+0x10], xmm10
000074c3551d0ea5  movaps [rsp+0x20], xmm2
000074c3551d0eaa  lea rdi, [rsp]
000074c3551d0eae  mov esi, 0x00
000074c3551d0eb3  mov rax, 0x5F9407FA9530
000074c3551d0ebd  call rax
000074c3551d0ebf  movaps xmm15, [rsp]
000074c3551d0ec4  add rsp, 0x30
000074c3551d0ec8  vmovaps xmm0, [rsp]
000074c3551d0ecd  vmovaps xmm1, [rsp+0x10]
000074c3551d0ed3  vmovaps xmm2, [rsp+0x20]
000074c3551d0ed9  vmovaps xmm3, [rsp+0x30]
000074c3551d0edf  vmovaps xmm4, [rsp+0x40]
000074c3551d0ee5  vmovaps xmm5, [rsp+0x50]
000074c3551d0eeb  vmovaps xmm6, [rsp+0x60]
000074c3551d0ef1  vmovaps xmm7, [rsp+0x70]
000074c3551d0ef7  vmovaps xmm8, [rsp+0x80]
000074c3551d0f00  vmovaps xmm9, [rsp+0x90]
000074c3551d0f09  vmovaps xmm10, [rsp+0xA0]
000074c3551d0f12  vmovaps xmm11, [rsp+0xB0]
000074c3551d0f1b  vmovaps xmm12, [rsp+0xC0]
000074c3551d0f24  vmovaps xmm13, [rsp+0xD0]
000074c3551d0f2d  vmovaps xmm14, [rsp+0xE0]
000074c3551d0f36  add rsp, 0xF0
000074c3551d0f3d  pop r11
000074c3551d0f3f  pop r10
000074c3551d0f41  pop r9
000074c3551d0f43  pop r8
000074c3551d0f45  pop rsi
000074c3551d0f46  pop rdi
000074c3551d0f47  pop rdx
000074c3551d0f48  pop rcx
000074c3551d0f49  pop rax
000074c3551d0f4a  add rsp, 0x08
000074c3551d0f4e  jmp 0x000074C3551CF706
000074c3551d0f53  sub rsp, 0x08
000074c3551d0f57  push rax
000074c3551d0f58  push rcx
000074c3551d0f59  push rdx
000074c3551d0f5a  push rdi
000074c3551d0f5b  push rsi
000074c3551d0f5c  push r8
000074c3551d0f5e  push r9
000074c3551d0f60  push r10
000074c3551d0f62  push r11
000074c3551d0f64  sub rsp, 0xF0
000074c3551d0f6b  vmovaps [rsp], xmm0
000074c3551d0f70  vmovaps [rsp+0x10], xmm2
000074c3551d0f76  vmovaps [rsp+0x20], xmm3
000074c3551d0f7c  vmovaps [rsp+0x30], xmm4
000074c3551d0f82  vmovaps [rsp+0x40], xmm5
000074c3551d0f88  vmovaps [rsp+0x50], xmm6
000074c3551d0f8e  vmovaps [rsp+0x60], xmm7
000074c3551d0f94  vmovaps [rsp+0x70], xmm8
000074c3551d0f9a  vmovaps [rsp+0x80], xmm9
000074c3551d0fa3  vmovaps [rsp+0x90], xmm10
000074c3551d0fac  vmovaps [rsp+0xA0], xmm11
000074c3551d0fb5  vmovaps [rsp+0xB0], xmm12
000074c3551d0fbe  vmovaps [rsp+0xC0], xmm13
000074c3551d0fc7  vmovaps [rsp+0xD0], xmm14
000074c3551d0fd0  vmovaps [rsp+0xE0], xmm15
000074c3551d0fd9  sub rsp, 0x30
000074c3551d0fdd  movaps [rsp], xmm1
000074c3551d0fe1  movaps [rsp+0x10], xmm10
000074c3551d0fe7  movaps [rsp+0x20], xmm12
000074c3551d0fed  lea rdi, [rsp]
000074c3551d0ff1  mov esi, 0x00
000074c3551d0ff6  mov rax, 0x5F9407FA9530
000074c3551d1000  call rax
000074c3551d1002  movaps xmm1, [rsp]
000074c3551d1006  add rsp, 0x30
000074c3551d100a  vmovaps xmm0, [rsp]
000074c3551d100f  vmovaps xmm2, [rsp+0x10]
000074c3551d1015  vmovaps xmm3, [rsp+0x20]
000074c3551d101b  vmovaps xmm4, [rsp+0x30]
000074c3551d1021  vmovaps xmm5, [rsp+0x40]
000074c3551d1027  vmovaps xmm6, [rsp+0x50]
000074c3551d102d  vmovaps xmm7, [rsp+0x60]
000074c3551d1033  vmovaps xmm8, [rsp+0x70]
000074c3551d1039  vmovaps xmm9, [rsp+0x80]
000074c3551d1042  vmovaps xmm10, [rsp+0x90]
000074c3551d104b  vmovaps xmm11, [rsp+0xA0]
000074c3551d1054  vmovaps xmm12, [rsp+0xB0]
000074c3551d105d  vmovaps xmm13, [rsp+0xC0]
000074c3551d1066  vmovaps xmm14, [rsp+0xD0]
000074c3551d106f  vmovaps xmm15, [rsp+0xE0]
000074c3551d1078  add rsp, 0xF0
000074c3551d107f  pop r11
000074c3551d1081  pop r10
000074c3551d1083  pop r9
000074c3551d1085  pop r8
000074c3551d1087  pop rsi
000074c3551d1088  pop rdi
000074c3551d1089  pop rdx
000074c3551d108a  pop rcx
000074c3551d108b  pop rax
000074c3551d108c  add rsp, 0x08
000074c3551d1090  jmp 0x000074C3551CF732
000074c3551d1095  sub rsp, 0x08
000074c3551d1099  push rax
000074c3551d109a  push rcx
000074c3551d109b  push rdx
000074c3551d109c  push rdi
000074c3551d109d  push rsi
000074c3551d109e  push r8
000074c3551d10a0  push r9
000074c3551d10a2  push r10
000074c3551d10a4  push r11
000074c3551d10a6  sub rsp, 0xF0
000074c3551d10ad  vmovaps [rsp], xmm0
000074c3551d10b2  vmovaps [rsp+0x10], xmm1
000074c3551d10b8  vmovaps [rsp+0x20], xmm2
000074c3551d10be  vmovaps [rsp+0x30], xmm3
000074c3551d10c4  vmovaps [rsp+0x40], xmm4
000074c3551d10ca  vmovaps [rsp+0x50], xmm5
000074c3551d10d0  vmovaps [rsp+0x60], xmm6
000074c3551d10d6  vmovaps [rsp+0x70], xmm7
000074c3551d10dc  vmovaps [rsp+0x80], xmm8
000074c3551d10e5  vmovaps [rsp+0x90], xmm9
000074c3551d10ee  vmovaps [rsp+0xA0], xmm10
000074c3551d10f7  vmovaps [rsp+0xB0], xmm11
000074c3551d1100  vmovaps [rsp+0xC0], xmm12
000074c3551d1109  vmovaps [rsp+0xD0], xmm13
000074c3551d1112  vmovaps [rsp+0xE0], xmm14
000074c3551d111b  sub rsp, 0x30
000074c3551d111f  movaps [rsp], xmm15
000074c3551d1124  movaps [rsp+0x10], xmm10
000074c3551d112a  movaps [rsp+0x20], xmm12
000074c3551d1130  lea rdi, [rsp]
000074c3551d1134  mov esi, 0x00
000074c3551d1139  mov rax, 0x5F9407FA9530
000074c3551d1143  call rax
000074c3551d1145  movaps xmm15, [rsp]
000074c3551d114a  add rsp, 0x30
000074c3551d114e  vmovaps xmm0, [rsp]
000074c3551d1153  vmovaps xmm1, [rsp+0x10]
000074c3551d1159  vmovaps xmm2, [rsp+0x20]
000074c3551d115f  vmovaps xmm3, [rsp+0x30]
000074c3551d1165  vmovaps xmm4, [rsp+0x40]
000074c3551d116b  vmovaps xmm5, [rsp+0x50]
000074c3551d1171  vmovaps xmm6, [rsp+0x60]
000074c3551d1177  vmovaps xmm7, [rsp+0x70]
000074c3551d117d  vmovaps xmm8, [rsp+0x80]
000074c3551d1186  vmovaps xmm9, [rsp+0x90]
000074c3551d118f  vmovaps xmm10, [rsp+0xA0]
000074c3551d1198  vmovaps xmm11, [rsp+0xB0]
000074c3551d11a1  vmovaps xmm12, [rsp+0xC0]
000074c3551d11aa  vmovaps xmm13, [rsp+0xD0]
000074c3551d11b3  vmovaps xmm14, [rsp+0xE0]
000074c3551d11bc  add rsp, 0xF0
000074c3551d11c3  pop r11
000074c3551d11c5  pop r10
000074c3551d11c7  pop r9
000074c3551d11c9  pop r8
000074c3551d11cb  pop rsi
000074c3551d11cc  pop rdi
000074c3551d11cd  pop rdx
000074c3551d11ce  pop rcx
000074c3551d11cf  pop rax
000074c3551d11d0  add rsp, 0x08
000074c3551d11d4  jmp 0x000074C3551CF75E
000074c3551d11d9  call 0x000074C354FFF430
000074c3551d11de  jmp 0x000074C3551CF7EE
000074c3551d11e3  call 0x000074C354FFF430
000074c3551d11e8  jmp 0x000074C3551CF801
000074c3551d11ed  sub rsp, 0x08
000074c3551d11f1  push rax
000074c3551d11f2  push rcx
000074c3551d11f3  push rdx
000074c3551d11f4  push rdi
000074c3551d11f5  push rsi
000074c3551d11f6  push r8
000074c3551d11f8  push r9
000074c3551d11fa  push r10
000074c3551d11fc  push r11
000074c3551d11fe  sub rsp, 0xF0
000074c3551d1205  vmovaps [rsp], xmm0
000074c3551d120a  vmovaps [rsp+0x10], xmm2
000074c3551d1210  vmovaps [rsp+0x20], xmm3
000074c3551d1216  vmovaps [rsp+0x30], xmm4
000074c3551d121c  vmovaps [rsp+0x40], xmm5
000074c3551d1222  vmovaps [rsp+0x50], xmm6
000074c3551d1228  vmovaps [rsp+0x60], xmm7
000074c3551d122e  vmovaps [rsp+0x70], xmm8
000074c3551d1234  vmovaps [rsp+0x80], xmm9
000074c3551d123d  vmovaps [rsp+0x90], xmm10
000074c3551d1246  vmovaps [rsp+0xA0], xmm11
000074c3551d124f  vmovaps [rsp+0xB0], xmm12
000074c3551d1258  vmovaps [rsp+0xC0], xmm13
000074c3551d1261  vmovaps [rsp+0xD0], xmm14
000074c3551d126a  vmovaps [rsp+0xE0], xmm15
000074c3551d1273  sub rsp, 0x30
000074c3551d1277  movaps [rsp], xmm1
000074c3551d127b  movaps [rsp+0x10], xmm13
000074c3551d1281  movaps [rsp+0x20], xmm2
000074c3551d1286  lea rdi, [rsp]
000074c3551d128a  mov esi, 0x00
000074c3551d128f  mov rax, 0x5F9407FA9530
000074c3551d1299  call rax
000074c3551d129b  movaps xmm1, [rsp]
000074c3551d129f  add rsp, 0x30
000074c3551d12a3  vmovaps xmm0, [rsp]
000074c3551d12a8  vmovaps xmm2, [rsp+0x10]
000074c3551d12ae  vmovaps xmm3, [rsp+0x20]
000074c3551d12b4  vmovaps xmm4, [rsp+0x30]
000074c3551d12ba  vmovaps xmm5, [rsp+0x40]
000074c3551d12c0  vmovaps xmm6, [rsp+0x50]
000074c3551d12c6  vmovaps xmm7, [rsp+0x60]
000074c3551d12cc  vmovaps xmm8, [rsp+0x70]
000074c3551d12d2  vmovaps xmm9, [rsp+0x80]
000074c3551d12db  vmovaps xmm10, [rsp+0x90]
000074c3551d12e4  vmovaps xmm11, [rsp+0xA0]
000074c3551d12ed  vmovaps xmm12, [rsp+0xB0]
000074c3551d12f6  vmovaps xmm13, [rsp+0xC0]
000074c3551d12ff  vmovaps xmm14, [rsp+0xD0]
000074c3551d1308  vmovaps xmm15, [rsp+0xE0]
000074c3551d1311  add rsp, 0xF0
000074c3551d1318  pop r11
000074c3551d131a  pop r10
000074c3551d131c  pop r9
000074c3551d131e  pop r8
000074c3551d1320  pop rsi
000074c3551d1321  pop rdi
000074c3551d1322  pop rdx
000074c3551d1323  pop rcx
000074c3551d1324  pop rax
000074c3551d1325  add rsp, 0x08
000074c3551d1329  jmp 0x000074C3551CF82C
000074c3551d132e  call 0x000074C35500E760
000074c3551d1333  jmp 0x000074C3551CF839
000074c3551d1338  sub rsp, 0x08
000074c3551d133c  push rax
000074c3551d133d  push rcx
000074c3551d133e  push rdx
000074c3551d133f  push rdi
000074c3551d1340  push rsi
000074c3551d1341  push r8
000074c3551d1343  push r9
000074c3551d1345  push r10
000074c3551d1347  push r11
000074c3551d1349  sub rsp, 0xF0
000074c3551d1350  vmovaps [rsp], xmm0
000074c3551d1355  vmovaps [rsp+0x10], xmm1
000074c3551d135b  vmovaps [rsp+0x20], xmm2
000074c3551d1361  vmovaps [rsp+0x30], xmm3
000074c3551d1367  vmovaps [rsp+0x40], xmm4
000074c3551d136d  vmovaps [rsp+0x50], xmm5
000074c3551d1373  vmovaps [rsp+0x60], xmm6
000074c3551d1379  vmovaps [rsp+0x70], xmm7
000074c3551d137f  vmovaps [rsp+0x80], xmm8
000074c3551d1388  vmovaps [rsp+0x90], xmm9
000074c3551d1391  vmovaps [rsp+0xA0], xmm10
000074c3551d139a  vmovaps [rsp+0xB0], xmm11
000074c3551d13a3  vmovaps [rsp+0xC0], xmm12
000074c3551d13ac  vmovaps [rsp+0xD0], xmm14
000074c3551d13b5  vmovaps [rsp+0xE0], xmm15
000074c3551d13be  sub rsp, 0x30
000074c3551d13c2  movaps [rsp], xmm13
000074c3551d13c7  movaps [rsp+0x10], xmm2
000074c3551d13cc  movaps [rsp+0x20], xmm1
000074c3551d13d1  lea rdi, [rsp]
000074c3551d13d5  mov esi, 0x00
000074c3551d13da  mov rax, 0x5F9407FA9530
000074c3551d13e4  call rax
000074c3551d13e6  movaps xmm13, [rsp]
000074c3551d13eb  add rsp, 0x30
000074c3551d13ef  vmovaps xmm0, [rsp]
000074c3551d13f4  vmovaps xmm1, [rsp+0x10]
000074c3551d13fa  vmovaps xmm2, [rsp+0x20]
000074c3551d1400  vmovaps xmm3, [rsp+0x30]
000074c3551d1406  vmovaps xmm4, [rsp+0x40]
000074c3551d140c  vmovaps xmm5, [rsp+0x50]
000074c3551d1412  vmovaps xmm6, [rsp+0x60]
000074c3551d1418  vmovaps xmm7, [rsp+0x70]
000074c3551d141e  vmovaps xmm8, [rsp+0x80]
000074c3551d1427  vmovaps xmm9, [rsp+0x90]
000074c3551d1430  vmovaps xmm10, [rsp+0xA0]
000074c3551d1439  vmovaps xmm11, [rsp+0xB0]
000074c3551d1442  vmovaps xmm12, [rsp+0xC0]
000074c3551d144b  vmovaps xmm14, [rsp+0xD0]
000074c3551d1454  vmovaps xmm15, [rsp+0xE0]
000074c3551d145d  add rsp, 0xF0
000074c3551d1464  pop r11
000074c3551d1466  pop r10
000074c3551d1468  pop r9
000074c3551d146a  pop r8
000074c3551d146c  pop rsi
000074c3551d146d  pop rdi
000074c3551d146e  pop rdx
000074c3551d146f  pop rcx
000074c3551d1470  pop rax
000074c3551d1471  add rsp, 0x08
000074c3551d1475  jmp 0x000074C3551CF878
000074c3551d147a  sub rsp, 0x08
000074c3551d147e  push rax
000074c3551d147f  push rcx
000074c3551d1480  push rdx
000074c3551d1481  push rdi
000074c3551d1482  push rsi
000074c3551d1483  push r8
000074c3551d1485  push r9
000074c3551d1487  push r10
000074c3551d1489  push r11
000074c3551d148b  sub rsp, 0xF0
000074c3551d1492  vmovaps [rsp], xmm0
000074c3551d1497  vmovaps [rsp+0x10], xmm2
000074c3551d149d  vmovaps [rsp+0x20], xmm3
000074c3551d14a3  vmovaps [rsp+0x30], xmm4
000074c3551d14a9  vmovaps [rsp+0x40], xmm5
000074c3551d14af  vmovaps [rsp+0x50], xmm6
000074c3551d14b5  vmovaps [rsp+0x60], xmm7
000074c3551d14bb  vmovaps [rsp+0x70], xmm8
000074c3551d14c1  vmovaps [rsp+0x80], xmm9
000074c3551d14ca  vmovaps [rsp+0x90], xmm10
000074c3551d14d3  vmovaps [rsp+0xA0], xmm11
000074c3551d14dc  vmovaps [rsp+0xB0], xmm12
000074c3551d14e5  vmovaps [rsp+0xC0], xmm13
000074c3551d14ee  vmovaps [rsp+0xD0], xmm14
000074c3551d14f7  vmovaps [rsp+0xE0], xmm15
000074c3551d1500  sub rsp, 0x30
000074c3551d1504  movaps [rsp], xmm1
000074c3551d1508  movaps [rsp+0x10], xmm15
000074c3551d150e  movaps [rsp+0x20], xmm2
000074c3551d1513  lea rdi, [rsp]
000074c3551d1517  mov esi, 0x00
000074c3551d151c  mov rax, 0x5F9407FA9530
000074c3551d1526  call rax
000074c3551d1528  movaps xmm1, [rsp]
000074c3551d152c  add rsp, 0x30
000074c3551d1530  vmovaps xmm0, [rsp]
000074c3551d1535  vmovaps xmm2, [rsp+0x10]
000074c3551d153b  vmovaps xmm3, [rsp+0x20]
000074c3551d1541  vmovaps xmm4, [rsp+0x30]
000074c3551d1547  vmovaps xmm5, [rsp+0x40]
000074c3551d154d  vmovaps xmm6, [rsp+0x50]
000074c3551d1553  vmovaps xmm7, [rsp+0x60]
000074c3551d1559  vmovaps xmm8, [rsp+0x70]
000074c3551d155f  vmovaps xmm9, [rsp+0x80]
000074c3551d1568  vmovaps xmm10, [rsp+0x90]
000074c3551d1571  vmovaps xmm11, [rsp+0xA0]
000074c3551d157a  vmovaps xmm12, [rsp+0xB0]
000074c3551d1583  vmovaps xmm13, [rsp+0xC0]
000074c3551d158c  vmovaps xmm14, [rsp+0xD0]
000074c3551d1595  vmovaps xmm15, [rsp+0xE0]
000074c3551d159e  add rsp, 0xF0
000074c3551d15a5  pop r11
000074c3551d15a7  pop r10
000074c3551d15a9  pop r9
000074c3551d15ab  pop r8
000074c3551d15ad  pop rsi
000074c3551d15ae  pop rdi
000074c3551d15af  pop rdx
000074c3551d15b0  pop rcx
000074c3551d15b1  pop rax
000074c3551d15b2  add rsp, 0x08
000074c3551d15b6  jmp 0x000074C3551CF8AC
000074c3551d15bb  sub rsp, 0x08
000074c3551d15bf  push rax
000074c3551d15c0  push rcx
000074c3551d15c1  push rdx
000074c3551d15c2  push rdi
000074c3551d15c3  push rsi
000074c3551d15c4  push r8
000074c3551d15c6  push r9
000074c3551d15c8  push r10
000074c3551d15ca  push r11
000074c3551d15cc  sub rsp, 0xF0
000074c3551d15d3  vmovaps [rsp], xmm0
000074c3551d15d8  vmovaps [rsp+0x10], xmm1
000074c3551d15de  vmovaps [rsp+0x20], xmm2
000074c3551d15e4  vmovaps [rsp+0x30], xmm3
000074c3551d15ea  vmovaps [rsp+0x40], xmm4
000074c3551d15f0  vmovaps [rsp+0x50], xmm5
000074c3551d15f6  vmovaps [rsp+0x60], xmm6
000074c3551d15fc  vmovaps [rsp+0x70], xmm7
000074c3551d1602  vmovaps [rsp+0x80], xmm8
000074c3551d160b  vmovaps [rsp+0x90], xmm9
000074c3551d1614  vmovaps [rsp+0xA0], xmm10
000074c3551d161d  vmovaps [rsp+0xB0], xmm11
000074c3551d1626  vmovaps [rsp+0xC0], xmm12
000074c3551d162f  vmovaps [rsp+0xD0], xmm13
000074c3551d1638  vmovaps [rsp+0xE0], xmm15
000074c3551d1641  sub rsp, 0x30
000074c3551d1645  movaps [rsp], xmm14
000074c3551d164a  movaps [rsp+0x10], xmm2
000074c3551d164f  movaps [rsp+0x20], xmm15
000074c3551d1655  lea rdi, [rsp]
000074c3551d1659  mov esi, 0x00
000074c3551d165e  mov rax, 0x5F9407FA9530
000074c3551d1668  call rax
000074c3551d166a  movaps xmm14, [rsp]
000074c3551d166f  add rsp, 0x30
000074c3551d1673  vmovaps xmm0, [rsp]
000074c3551d1678  vmovaps xmm1, [rsp+0x10]
000074c3551d167e  vmovaps xmm2, [rsp+0x20]
000074c3551d1684  vmovaps xmm3, [rsp+0x30]
000074c3551d168a  vmovaps xmm4, [rsp+0x40]
000074c3551d1690  vmovaps xmm5, [rsp+0x50]
000074c3551d1696  vmovaps xmm6, [rsp+0x60]
000074c3551d169c  vmovaps xmm7, [rsp+0x70]
000074c3551d16a2  vmovaps xmm8, [rsp+0x80]
000074c3551d16ab  vmovaps xmm9, [rsp+0x90]
000074c3551d16b4  vmovaps xmm10, [rsp+0xA0]
000074c3551d16bd  vmovaps xmm11, [rsp+0xB0]
000074c3551d16c6  vmovaps xmm12, [rsp+0xC0]
000074c3551d16cf  vmovaps xmm13, [rsp+0xD0]
000074c3551d16d8  vmovaps xmm15, [rsp+0xE0]
000074c3551d16e1  add rsp, 0xF0
000074c3551d16e8  pop r11
000074c3551d16ea  pop r10
000074c3551d16ec  pop r9
000074c3551d16ee  pop r8
000074c3551d16f0  pop rsi
000074c3551d16f1  pop rdi
000074c3551d16f2  pop rdx
000074c3551d16f3  pop rcx
000074c3551d16f4  pop rax
000074c3551d16f5  add rsp, 0x08
000074c3551d16f9  jmp 0x000074C3551CF8E7
000074c3551d16fe  sub rsp, 0x08
000074c3551d1702  push rax
000074c3551d1703  push rcx
000074c3551d1704  push rdx
000074c3551d1705  push rdi
000074c3551d1706  push rsi
000074c3551d1707  push r8
000074c3551d1709  push r9
000074c3551d170b  push r10
000074c3551d170d  push r11
000074c3551d170f  sub rsp, 0xF0
000074c3551d1716  vmovaps [rsp], xmm0
000074c3551d171b  vmovaps [rsp+0x10], xmm1
000074c3551d1721  vmovaps [rsp+0x20], xmm2
000074c3551d1727  vmovaps [rsp+0x30], xmm3
000074c3551d172d  vmovaps [rsp+0x40], xmm4
000074c3551d1733  vmovaps [rsp+0x50], xmm5
000074c3551d1739  vmovaps [rsp+0x60], xmm6
000074c3551d173f  vmovaps [rsp+0x70], xmm7
000074c3551d1745  vmovaps [rsp+0x80], xmm8
000074c3551d174e  vmovaps [rsp+0x90], xmm9
000074c3551d1757  vmovaps [rsp+0xA0], xmm10
000074c3551d1760  vmovaps [rsp+0xB0], xmm11
000074c3551d1769  vmovaps [rsp+0xC0], xmm12
000074c3551d1772  vmovaps [rsp+0xD0], xmm13
000074c3551d177b  vmovaps [rsp+0xE0], xmm14
000074c3551d1784  sub rsp, 0x30
000074c3551d1788  movaps [rsp], xmm15
000074c3551d178d  movaps [rsp+0x10], xmm2
000074c3551d1792  movaps [rsp+0x20], xmm1
000074c3551d1797  lea rdi, [rsp]
000074c3551d179b  mov esi, 0x00
000074c3551d17a0  mov rax, 0x5F9407FA9530
000074c3551d17aa  call rax
000074c3551d17ac  movaps xmm15, [rsp]
000074c3551d17b1  add rsp, 0x30
000074c3551d17b5  vmovaps xmm0, [rsp]
000074c3551d17ba  vmovaps xmm1, [rsp+0x10]
000074c3551d17c0  vmovaps xmm2, [rsp+0x20]
000074c3551d17c6  vmovaps xmm3, [rsp+0x30]
000074c3551d17cc  vmovaps xmm4, [rsp+0x40]
000074c3551d17d2  vmovaps xmm5, [rsp+0x50]
000074c3551d17d8  vmovaps xmm6, [rsp+0x60]
000074c3551d17de  vmovaps xmm7, [rsp+0x70]
000074c3551d17e4  vmovaps xmm8, [rsp+0x80]
000074c3551d17ed  vmovaps xmm9, [rsp+0x90]
000074c3551d17f6  vmovaps xmm10, [rsp+0xA0]
000074c3551d17ff  vmovaps xmm11, [rsp+0xB0]
000074c3551d1808  vmovaps xmm12, [rsp+0xC0]
000074c3551d1811  vmovaps xmm13, [rsp+0xD0]
000074c3551d181a  vmovaps xmm14, [rsp+0xE0]
000074c3551d1823  add rsp, 0xF0
000074c3551d182a  pop r11
000074c3551d182c  pop r10
000074c3551d182e  pop r9
000074c3551d1830  pop r8
000074c3551d1832  pop rsi
000074c3551d1833  pop rdi
000074c3551d1834  pop rdx
000074c3551d1835  pop rcx
000074c3551d1836  pop rax
000074c3551d1837  add rsp, 0x08
000074c3551d183b  jmp 0x000074C3551CF923
000074c3551d1840  call 0x000074C354FFF430
000074c3551d1845  jmp 0x000074C3551CF930
000074c3551d184a  sub rsp, 0x08
000074c3551d184e  push rax
000074c3551d184f  push rcx
000074c3551d1850  push rdx
000074c3551d1851  push rdi
000074c3551d1852  push rsi
000074c3551d1853  push r8
000074c3551d1855  push r9
000074c3551d1857  push r10
000074c3551d1859  push r11
000074c3551d185b  sub rsp, 0xF0
000074c3551d1862  vmovaps [rsp], xmm0
000074c3551d1867  vmovaps [rsp+0x10], xmm1
000074c3551d186d  vmovaps [rsp+0x20], xmm3
000074c3551d1873  vmovaps [rsp+0x30], xmm4
000074c3551d1879  vmovaps [rsp+0x40], xmm5
000074c3551d187f  vmovaps [rsp+0x50], xmm6
000074c3551d1885  vmovaps [rsp+0x60], xmm7
000074c3551d188b  vmovaps [rsp+0x70], xmm8
000074c3551d1891  vmovaps [rsp+0x80], xmm9
000074c3551d189a  vmovaps [rsp+0x90], xmm10
000074c3551d18a3  vmovaps [rsp+0xA0], xmm11
000074c3551d18ac  vmovaps [rsp+0xB0], xmm12
000074c3551d18b5  vmovaps [rsp+0xC0], xmm13
000074c3551d18be  vmovaps [rsp+0xD0], xmm14
000074c3551d18c7  vmovaps [rsp+0xE0], xmm15
000074c3551d18d0  sub rsp, 0x30
000074c3551d18d4  movaps [rsp], xmm2
000074c3551d18d8  movaps [rsp+0x10], xmm1
000074c3551d18dd  movaps [rsp+0x20], xmm14
000074c3551d18e3  lea rdi, [rsp]
000074c3551d18e7  mov esi, 0x00
000074c3551d18ec  mov rax, 0x5F9407FA9530
000074c3551d18f6  call rax
000074c3551d18f8  movaps xmm2, [rsp]
000074c3551d18fc  add rsp, 0x30
000074c3551d1900  vmovaps xmm0, [rsp]
000074c3551d1905  vmovaps xmm1, [rsp+0x10]
000074c3551d190b  vmovaps xmm3, [rsp+0x20]
000074c3551d1911  vmovaps xmm4, [rsp+0x30]
000074c3551d1917  vmovaps xmm5, [rsp+0x40]
000074c3551d191d  vmovaps xmm6, [rsp+0x50]
000074c3551d1923  vmovaps xmm7, [rsp+0x60]
000074c3551d1929  vmovaps xmm8, [rsp+0x70]
000074c3551d192f  vmovaps xmm9, [rsp+0x80]
000074c3551d1938  vmovaps xmm10, [rsp+0x90]
000074c3551d1941  vmovaps xmm11, [rsp+0xA0]
000074c3551d194a  vmovaps xmm12, [rsp+0xB0]
000074c3551d1953  vmovaps xmm13, [rsp+0xC0]
000074c3551d195c  vmovaps xmm14, [rsp+0xD0]
000074c3551d1965  vmovaps xmm15, [rsp+0xE0]
000074c3551d196e  add rsp, 0xF0
000074c3551d1975  pop r11
000074c3551d1977  pop r10
000074c3551d1979  pop r9
000074c3551d197b  pop r8
000074c3551d197d  pop rsi
000074c3551d197e  pop rdi
000074c3551d197f  pop rdx
000074c3551d1980  pop rcx
000074c3551d1981  pop rax
000074c3551d1982  add rsp, 0x08
000074c3551d1986  jmp 0x000074C3551CF96D
000074c3551d198b  sub rsp, 0x08
000074c3551d198f  push rax
000074c3551d1990  push rcx
000074c3551d1991  push rdx
000074c3551d1992  push rdi
000074c3551d1993  push rsi
000074c3551d1994  push r8
000074c3551d1996  push r9
000074c3551d1998  push r10
000074c3551d199a  push r11
000074c3551d199c  sub rsp, 0xF0
000074c3551d19a3  vmovaps [rsp], xmm0
000074c3551d19a8  vmovaps [rsp+0x10], xmm1
000074c3551d19ae  vmovaps [rsp+0x20], xmm2
000074c3551d19b4  vmovaps [rsp+0x30], xmm3
000074c3551d19ba  vmovaps [rsp+0x40], xmm4
000074c3551d19c0  vmovaps [rsp+0x50], xmm5
000074c3551d19c6  vmovaps [rsp+0x60], xmm6
000074c3551d19cc  vmovaps [rsp+0x70], xmm7
000074c3551d19d2  vmovaps [rsp+0x80], xmm8
000074c3551d19db  vmovaps [rsp+0x90], xmm9
000074c3551d19e4  vmovaps [rsp+0xA0], xmm10
000074c3551d19ed  vmovaps [rsp+0xB0], xmm11
000074c3551d19f6  vmovaps [rsp+0xC0], xmm12
000074c3551d19ff  vmovaps [rsp+0xD0], xmm13
000074c3551d1a08  vmovaps [rsp+0xE0], xmm14
000074c3551d1a11  sub rsp, 0x30
000074c3551d1a15  movaps [rsp], xmm15
000074c3551d1a1a  movaps [rsp+0x10], xmm14
000074c3551d1a20  movaps [rsp+0x20], xmm1
000074c3551d1a25  lea rdi, [rsp]
000074c3551d1a29  mov esi, 0x00
000074c3551d1a2e  mov rax, 0x5F9407FA9530
000074c3551d1a38  call rax
000074c3551d1a3a  movaps xmm15, [rsp]
000074c3551d1a3f  add rsp, 0x30
000074c3551d1a43  vmovaps xmm0, [rsp]
000074c3551d1a48  vmovaps xmm1, [rsp+0x10]
000074c3551d1a4e  vmovaps xmm2, [rsp+0x20]
000074c3551d1a54  vmovaps xmm3, [rsp+0x30]
000074c3551d1a5a  vmovaps xmm4, [rsp+0x40]
000074c3551d1a60  vmovaps xmm5, [rsp+0x50]
000074c3551d1a66  vmovaps xmm6, [rsp+0x60]
000074c3551d1a6c  vmovaps xmm7, [rsp+0x70]
000074c3551d1a72  vmovaps xmm8, [rsp+0x80]
000074c3551d1a7b  vmovaps xmm9, [rsp+0x90]
000074c3551d1a84  vmovaps xmm10, [rsp+0xA0]
000074c3551d1a8d  vmovaps xmm11, [rsp+0xB0]
000074c3551d1a96  vmovaps xmm12, [rsp+0xC0]
000074c3551d1a9f  vmovaps xmm13, [rsp+0xD0]
000074c3551d1aa8  vmovaps xmm14, [rsp+0xE0]
000074c3551d1ab1  add rsp, 0xF0
000074c3551d1ab8  pop r11
000074c3551d1aba  pop r10
000074c3551d1abc  pop r9
000074c3551d1abe  pop r8
000074c3551d1ac0  pop rsi
000074c3551d1ac1  pop rdi
000074c3551d1ac2  pop rdx
000074c3551d1ac3  pop rcx
000074c3551d1ac4  pop rax
000074c3551d1ac5  add rsp, 0x08
000074c3551d1ac9  jmp 0x000074C3551CF9E7
000074c3551d1ace  call 0x000074C354FFF430
000074c3551d1ad3  jmp 0x000074C3551CF9F4
000074c3551d1ad8  sub rsp, 0x08
000074c3551d1adc  push rax
000074c3551d1add  push rcx
000074c3551d1ade  push rdx
000074c3551d1adf  push rdi
000074c3551d1ae0  push rsi
000074c3551d1ae1  push r8
000074c3551d1ae3  push r9
000074c3551d1ae5  push r10
000074c3551d1ae7  push r11
000074c3551d1ae9  sub rsp, 0xF0
000074c3551d1af0  vmovaps [rsp], xmm0
000074c3551d1af5  vmovaps [rsp+0x10], xmm1
000074c3551d1afb  vmovaps [rsp+0x20], xmm2
000074c3551d1b01  vmovaps [rsp+0x30], xmm3
000074c3551d1b07  vmovaps [rsp+0x40], xmm4
000074c3551d1b0d  vmovaps [rsp+0x50], xmm5
000074c3551d1b13  vmovaps [rsp+0x60], xmm6
000074c3551d1b19  vmovaps [rsp+0x70], xmm7
000074c3551d1b1f  vmovaps [rsp+0x80], xmm8
000074c3551d1b28  vmovaps [rsp+0x90], xmm9
000074c3551d1b31  vmovaps [rsp+0xA0], xmm10
000074c3551d1b3a  vmovaps [rsp+0xB0], xmm11
000074c3551d1b43  vmovaps [rsp+0xC0], xmm12
000074c3551d1b4c  vmovaps [rsp+0xD0], xmm13
000074c3551d1b55  vmovaps [rsp+0xE0], xmm15
000074c3551d1b5e  sub rsp, 0x30
000074c3551d1b62  movaps [rsp], xmm14
000074c3551d1b67  movaps [rsp+0x10], xmm13
000074c3551d1b6d  movaps [rsp+0x20], xmm1
000074c3551d1b72  lea rdi, [rsp]
000074c3551d1b76  mov esi, 0x00
000074c3551d1b7b  mov rax, 0x5F9407FA9530
000074c3551d1b85  call rax
000074c3551d1b87  movaps xmm14, [rsp]
000074c3551d1b8c  add rsp, 0x30
000074c3551d1b90  vmovaps xmm0, [rsp]
000074c3551d1b95  vmovaps xmm1, [rsp+0x10]
000074c3551d1b9b  vmovaps xmm2, [rsp+0x20]
000074c3551d1ba1  vmovaps xmm3, [rsp+0x30]
000074c3551d1ba7  vmovaps xmm4, [rsp+0x40]
000074c3551d1bad  vmovaps xmm5, [rsp+0x50]
000074c3551d1bb3  vmovaps xmm6, [rsp+0x60]
000074c3551d1bb9  vmovaps xmm7, [rsp+0x70]
000074c3551d1bbf  vmovaps xmm8, [rsp+0x80]
000074c3551d1bc8  vmovaps xmm9, [rsp+0x90]
000074c3551d1bd1  vmovaps xmm10, [rsp+0xA0]
000074c3551d1bda  vmovaps xmm11, [rsp+0xB0]
000074c3551d1be3  vmovaps xmm12, [rsp+0xC0]
000074c3551d1bec  vmovaps xmm13, [rsp+0xD0]
000074c3551d1bf5  vmovaps xmm15, [rsp+0xE0]
000074c3551d1bfe  add rsp, 0xF0
000074c3551d1c05  pop r11
000074c3551d1c07  pop r10
000074c3551d1c09  pop r9
000074c3551d1c0b  pop r8
000074c3551d1c0d  pop rsi
000074c3551d1c0e  pop rdi
000074c3551d1c0f  pop rdx
000074c3551d1c10  pop rcx
000074c3551d1c11  pop rax
000074c3551d1c12  add rsp, 0x08
000074c3551d1c16  jmp 0x000074C3551CFAAF
000074c3551d1c1b  sub rsp, 0x08
000074c3551d1c1f  push rax
000074c3551d1c20  push rcx
000074c3551d1c21  push rdx
000074c3551d1c22  push rdi
000074c3551d1c23  push rsi
000074c3551d1c24  push r8
000074c3551d1c26  push r9
000074c3551d1c28  push r10
000074c3551d1c2a  push r11
000074c3551d1c2c  sub rsp, 0xF0
000074c3551d1c33  vmovaps [rsp], xmm0
000074c3551d1c38  vmovaps [rsp+0x10], xmm1
000074c3551d1c3e  vmovaps [rsp+0x20], xmm2
000074c3551d1c44  vmovaps [rsp+0x30], xmm3
000074c3551d1c4a  vmovaps [rsp+0x40], xmm4
000074c3551d1c50  vmovaps [rsp+0x50], xmm5
000074c3551d1c56  vmovaps [rsp+0x60], xmm6
000074c3551d1c5c  vmovaps [rsp+0x70], xmm7
000074c3551d1c62  vmovaps [rsp+0x80], xmm8
000074c3551d1c6b  vmovaps [rsp+0x90], xmm9
000074c3551d1c74  vmovaps [rsp+0xA0], xmm10
000074c3551d1c7d  vmovaps [rsp+0xB0], xmm11
000074c3551d1c86  vmovaps [rsp+0xC0], xmm12
000074c3551d1c8f  vmovaps [rsp+0xD0], xmm13
000074c3551d1c98  vmovaps [rsp+0xE0], xmm14
000074c3551d1ca1  sub rsp, 0x30
000074c3551d1ca5  movaps [rsp], xmm15
000074c3551d1caa  movaps [rsp+0x10], xmm13
000074c3551d1cb0  movaps [rsp+0x20], xmm1
000074c3551d1cb5  lea rdi, [rsp]
000074c3551d1cb9  mov esi, 0x00
000074c3551d1cbe  mov rax, 0x5F9407FA9530
000074c3551d1cc8  call rax
000074c3551d1cca  movaps xmm15, [rsp]
000074c3551d1ccf  add rsp, 0x30
000074c3551d1cd3  vmovaps xmm0, [rsp]
000074c3551d1cd8  vmovaps xmm1, [rsp+0x10]
000074c3551d1cde  vmovaps xmm2, [rsp+0x20]
000074c3551d1ce4  vmovaps xmm3, [rsp+0x30]
000074c3551d1cea  vmovaps xmm4, [rsp+0x40]
000074c3551d1cf0  vmovaps xmm5, [rsp+0x50]
000074c3551d1cf6  vmovaps xmm6, [rsp+0x60]
000074c3551d1cfc  vmovaps xmm7, [rsp+0x70]
000074c3551d1d02  vmovaps xmm8, [rsp+0x80]
000074c3551d1d0b  vmovaps xmm9, [rsp+0x90]
000074c3551d1d14  vmovaps xmm10, [rsp+0xA0]
000074c3551d1d1d  vmovaps xmm11, [rsp+0xB0]
000074c3551d1d26  vmovaps xmm12, [rsp+0xC0]
000074c3551d1d2f  vmovaps xmm13, [rsp+0xD0]
000074c3551d1d38  vmovaps xmm14, [rsp+0xE0]
000074c3551d1d41  add rsp, 0xF0
000074c3551d1d48  pop r11
000074c3551d1d4a  pop r10
000074c3551d1d4c  pop r9
000074c3551d1d4e  pop r8
000074c3551d1d50  pop rsi
000074c3551d1d51  pop rdi
000074c3551d1d52  pop rdx
000074c3551d1d53  pop rcx
000074c3551d1d54  pop rax
000074c3551d1d55  add rsp, 0x08
000074c3551d1d59  jmp 0x000074C3551CFAEB
000074c3551d1d5e  call 0x000074C354FFF430
000074c3551d1d63  jmp 0x000074C3551CFAF8
000074c3551d1d68  sub rsp, 0x08
000074c3551d1d6c  push rax
000074c3551d1d6d  push rcx
000074c3551d1d6e  push rdx
000074c3551d1d6f  push rdi
000074c3551d1d70  push rsi
000074c3551d1d71  push r8
000074c3551d1d73  push r9
000074c3551d1d75  push r10
000074c3551d1d77  push r11
000074c3551d1d79  sub rsp, 0xF0
000074c3551d1d80  vmovaps [rsp], xmm0
000074c3551d1d85  vmovaps [rsp+0x10], xmm1
000074c3551d1d8b  vmovaps [rsp+0x20], xmm2
000074c3551d1d91  vmovaps [rsp+0x30], xmm3
000074c3551d1d97  vmovaps [rsp+0x40], xmm4
000074c3551d1d9d  vmovaps [rsp+0x50], xmm5
000074c3551d1da3  vmovaps [rsp+0x60], xmm6
000074c3551d1da9  vmovaps [rsp+0x70], xmm7
000074c3551d1daf  vmovaps [rsp+0x80], xmm8
000074c3551d1db8  vmovaps [rsp+0x90], xmm9
000074c3551d1dc1  vmovaps [rsp+0xA0], xmm10
000074c3551d1dca  vmovaps [rsp+0xB0], xmm11
000074c3551d1dd3  vmovaps [rsp+0xC0], xmm12
000074c3551d1ddc  vmovaps [rsp+0xD0], xmm13
000074c3551d1de5  vmovaps [rsp+0xE0], xmm15
000074c3551d1dee  sub rsp, 0x30
000074c3551d1df2  movaps [rsp], xmm14
000074c3551d1df7  movaps [rsp+0x10], xmm13
000074c3551d1dfd  movaps [rsp+0x20], xmm2
000074c3551d1e02  lea rdi, [rsp]
000074c3551d1e06  mov esi, 0x00
000074c3551d1e0b  mov rax, 0x5F9407FA9530
000074c3551d1e15  call rax
000074c3551d1e17  movaps xmm14, [rsp]
000074c3551d1e1c  add rsp, 0x30
000074c3551d1e20  vmovaps xmm0, [rsp]
000074c3551d1e25  vmovaps xmm1, [rsp+0x10]
000074c3551d1e2b  vmovaps xmm2, [rsp+0x20]
000074c3551d1e31  vmovaps xmm3, [rsp+0x30]
000074c3551d1e37  vmovaps xmm4, [rsp+0x40]
000074c3551d1e3d  vmovaps xmm5, [rsp+0x50]
000074c3551d1e43  vmovaps xmm6, [rsp+0x60]
000074c3551d1e49  vmovaps xmm7, [rsp+0x70]
000074c3551d1e4f  vmovaps xmm8, [rsp+0x80]
000074c3551d1e58  vmovaps xmm9, [rsp+0x90]
000074c3551d1e61  vmovaps xmm10, [rsp+0xA0]
000074c3551d1e6a  vmovaps xmm11, [rsp+0xB0]
000074c3551d1e73  vmovaps xmm12, [rsp+0xC0]
000074c3551d1e7c  vmovaps xmm13, [rsp+0xD0]
000074c3551d1e85  vmovaps xmm15, [rsp+0xE0]
000074c3551d1e8e  add rsp, 0xF0
000074c3551d1e95  pop r11
000074c3551d1e97  pop r10
000074c3551d1e99  pop r9
000074c3551d1e9b  pop r8
000074c3551d1e9d  pop rsi
000074c3551d1e9e  pop rdi
000074c3551d1e9f  pop rdx
000074c3551d1ea0  pop rcx
000074c3551d1ea1  pop rax
000074c3551d1ea2  add rsp, 0x08
000074c3551d1ea6  jmp 0x000074C3551CFB24
000074c3551d1eab  sub rsp, 0x08
000074c3551d1eaf  push rax
000074c3551d1eb0  push rcx
000074c3551d1eb1  push rdx
000074c3551d1eb2  push rdi
000074c3551d1eb3  push rsi
000074c3551d1eb4  push r8
000074c3551d1eb6  push r9
000074c3551d1eb8  push r10
000074c3551d1eba  push r11
000074c3551d1ebc  sub rsp, 0xF0
000074c3551d1ec3  vmovaps [rsp], xmm0
000074c3551d1ec8  vmovaps [rsp+0x10], xmm2
000074c3551d1ece  vmovaps [rsp+0x20], xmm3
000074c3551d1ed4  vmovaps [rsp+0x30], xmm4
000074c3551d1eda  vmovaps [rsp+0x40], xmm5
000074c3551d1ee0  vmovaps [rsp+0x50], xmm6
000074c3551d1ee6  vmovaps [rsp+0x60], xmm7
000074c3551d1eec  vmovaps [rsp+0x70], xmm8
000074c3551d1ef2  vmovaps [rsp+0x80], xmm9
000074c3551d1efb  vmovaps [rsp+0x90], xmm10
000074c3551d1f04  vmovaps [rsp+0xA0], xmm11
000074c3551d1f0d  vmovaps [rsp+0xB0], xmm12
000074c3551d1f16  vmovaps [rsp+0xC0], xmm13
000074c3551d1f1f  vmovaps [rsp+0xD0], xmm14
000074c3551d1f28  vmovaps [rsp+0xE0], xmm15
000074c3551d1f31  sub rsp, 0x30
000074c3551d1f35  movaps [rsp], xmm1
000074c3551d1f39  movaps [rsp+0x10], xmm13
000074c3551d1f3f  movaps [rsp+0x20], xmm2
000074c3551d1f44  lea rdi, [rsp]
000074c3551d1f48  mov esi, 0x00
000074c3551d1f4d  mov rax, 0x5F9407FA9530
000074c3551d1f57  call rax
000074c3551d1f59  movaps xmm1, [rsp]
000074c3551d1f5d  add rsp, 0x30
000074c3551d1f61  vmovaps xmm0, [rsp]
000074c3551d1f66  vmovaps xmm2, [rsp+0x10]
000074c3551d1f6c  vmovaps xmm3, [rsp+0x20]
000074c3551d1f72  vmovaps xmm4, [rsp+0x30]
000074c3551d1f78  vmovaps xmm5, [rsp+0x40]
000074c3551d1f7e  vmovaps xmm6, [rsp+0x50]
000074c3551d1f84  vmovaps xmm7, [rsp+0x60]
000074c3551d1f8a  vmovaps xmm8, [rsp+0x70]
000074c3551d1f90  vmovaps xmm9, [rsp+0x80]
000074c3551d1f99  vmovaps xmm10, [rsp+0x90]
000074c3551d1fa2  vmovaps xmm11, [rsp+0xA0]
000074c3551d1fab  vmovaps xmm12, [rsp+0xB0]
000074c3551d1fb4  vmovaps xmm13, [rsp+0xC0]
000074c3551d1fbd  vmovaps xmm14, [rsp+0xD0]
000074c3551d1fc6  vmovaps xmm15, [rsp+0xE0]
000074c3551d1fcf  add rsp, 0xF0
000074c3551d1fd6  pop r11
000074c3551d1fd8  pop r10
000074c3551d1fda  pop r9
000074c3551d1fdc  pop r8
000074c3551d1fde  pop rsi
000074c3551d1fdf  pop rdi
000074c3551d1fe0  pop rdx
000074c3551d1fe1  pop rcx
000074c3551d1fe2  pop rax
000074c3551d1fe3  add rsp, 0x08
000074c3551d1fe7  jmp 0x000074C3551CFB52
000074c3551d1fec  sub rsp, 0x08
000074c3551d1ff0  push rax
000074c3551d1ff1  push rcx
000074c3551d1ff2  push rdx
000074c3551d1ff3  push rdi
000074c3551d1ff4  push rsi
000074c3551d1ff5  push r8
000074c3551d1ff7  push r9
000074c3551d1ff9  push r10
000074c3551d1ffb  push r11
000074c3551d1ffd  sub rsp, 0xF0
000074c3551d2004  vmovaps [rsp], xmm0
000074c3551d2009  vmovaps [rsp+0x10], xmm1
000074c3551d200f  vmovaps [rsp+0x20], xmm3
000074c3551d2015  vmovaps [rsp+0x30], xmm4
000074c3551d201b  vmovaps [rsp+0x40], xmm5
000074c3551d2021  vmovaps [rsp+0x50], xmm6
000074c3551d2027  vmovaps [rsp+0x60], xmm7
000074c3551d202d  vmovaps [rsp+0x70], xmm8
000074c3551d2033  vmovaps [rsp+0x80], xmm9
000074c3551d203c  vmovaps [rsp+0x90], xmm10
000074c3551d2045  vmovaps [rsp+0xA0], xmm11
000074c3551d204e  vmovaps [rsp+0xB0], xmm12
000074c3551d2057  vmovaps [rsp+0xC0], xmm13
000074c3551d2060  vmovaps [rsp+0xD0], xmm14
000074c3551d2069  vmovaps [rsp+0xE0], xmm15
000074c3551d2072  sub rsp, 0x30
000074c3551d2076  movaps [rsp], xmm2
000074c3551d207a  movaps [rsp+0x10], xmm1
000074c3551d207f  movaps [rsp+0x20], xmm13
000074c3551d2085  lea rdi, [rsp]
000074c3551d2089  mov esi, 0x00
000074c3551d208e  mov rax, 0x5F9407FA9530
000074c3551d2098  call rax
000074c3551d209a  movaps xmm2, [rsp]
000074c3551d209e  add rsp, 0x30
000074c3551d20a2  vmovaps xmm0, [rsp]
000074c3551d20a7  vmovaps xmm1, [rsp+0x10]
000074c3551d20ad  vmovaps xmm3, [rsp+0x20]
000074c3551d20b3  vmovaps xmm4, [rsp+0x30]
000074c3551d20b9  vmovaps xmm5, [rsp+0x40]
000074c3551d20bf  vmovaps xmm6, [rsp+0x50]
000074c3551d20c5  vmovaps xmm7, [rsp+0x60]
000074c3551d20cb  vmovaps xmm8, [rsp+0x70]
000074c3551d20d1  vmovaps xmm9, [rsp+0x80]
000074c3551d20da  vmovaps xmm10, [rsp+0x90]
000074c3551d20e3  vmovaps xmm11, [rsp+0xA0]
000074c3551d20ec  vmovaps xmm12, [rsp+0xB0]
000074c3551d20f5  vmovaps xmm13, [rsp+0xC0]
000074c3551d20fe  vmovaps xmm14, [rsp+0xD0]
000074c3551d2107  vmovaps xmm15, [rsp+0xE0]
000074c3551d2110  add rsp, 0xF0
000074c3551d2117  pop r11
000074c3551d2119  pop r10
000074c3551d211b  pop r9
000074c3551d211d  pop r8
000074c3551d211f  pop rsi
000074c3551d2120  pop rdi
000074c3551d2121  pop rdx
000074c3551d2122  pop rcx
000074c3551d2123  pop rax
000074c3551d2124  add rsp, 0x08
000074c3551d2128  jmp 0x000074C3551CFBAB
000074c3551d212d  call 0x000074C354FFF430
000074c3551d2132  jmp 0x000074C3551CFBB8
000074c3551d2137  sub rsp, 0x08
000074c3551d213b  push rax
000074c3551d213c  push rcx
000074c3551d213d  push rdx
000074c3551d213e  push rdi
000074c3551d213f  push rsi
000074c3551d2140  push r8
000074c3551d2142  push r9
000074c3551d2144  push r10
000074c3551d2146  push r11
000074c3551d2148  sub rsp, 0xF0
000074c3551d214f  vmovaps [rsp], xmm0
000074c3551d2154  vmovaps [rsp+0x10], xmm1
000074c3551d215a  vmovaps [rsp+0x20], xmm2
000074c3551d2160  vmovaps [rsp+0x30], xmm3
000074c3551d2166  vmovaps [rsp+0x40], xmm4
000074c3551d216c  vmovaps [rsp+0x50], xmm5
000074c3551d2172  vmovaps [rsp+0x60], xmm6
000074c3551d2178  vmovaps [rsp+0x70], xmm7
000074c3551d217e  vmovaps [rsp+0x80], xmm8
000074c3551d2187  vmovaps [rsp+0x90], xmm9
000074c3551d2190  vmovaps [rsp+0xA0], xmm10
000074c3551d2199  vmovaps [rsp+0xB0], xmm11
000074c3551d21a2  vmovaps [rsp+0xC0], xmm12
000074c3551d21ab  vmovaps [rsp+0xD0], xmm13
000074c3551d21b4  vmovaps [rsp+0xE0], xmm14
000074c3551d21bd  sub rsp, 0x30
000074c3551d21c1  movaps [rsp], xmm15
000074c3551d21c6  movaps [rsp+0x10], xmm13
000074c3551d21cc  movaps [rsp+0x20], xmm1
000074c3551d21d1  lea rdi, [rsp]
000074c3551d21d5  mov esi, 0x00
000074c3551d21da  mov rax, 0x5F9407FA9530
000074c3551d21e4  call rax
000074c3551d21e6  movaps xmm15, [rsp]
000074c3551d21eb  add rsp, 0x30
000074c3551d21ef  vmovaps xmm0, [rsp]
000074c3551d21f4  vmovaps xmm1, [rsp+0x10]
000074c3551d21fa  vmovaps xmm2, [rsp+0x20]
000074c3551d2200  vmovaps xmm3, [rsp+0x30]
000074c3551d2206  vmovaps xmm4, [rsp+0x40]
000074c3551d220c  vmovaps xmm5, [rsp+0x50]
000074c3551d2212  vmovaps xmm6, [rsp+0x60]
000074c3551d2218  vmovaps xmm7, [rsp+0x70]
000074c3551d221e  vmovaps xmm8, [rsp+0x80]
000074c3551d2227  vmovaps xmm9, [rsp+0x90]
000074c3551d2230  vmovaps xmm10, [rsp+0xA0]
000074c3551d2239  vmovaps xmm11, [rsp+0xB0]
000074c3551d2242  vmovaps xmm12, [rsp+0xC0]
000074c3551d224b  vmovaps xmm13, [rsp+0xD0]
000074c3551d2254  vmovaps xmm14, [rsp+0xE0]
000074c3551d225d  add rsp, 0xF0
000074c3551d2264  pop r11
000074c3551d2266  pop r10
000074c3551d2268  pop r9
000074c3551d226a  pop r8
000074c3551d226c  pop rsi
000074c3551d226d  pop rdi
000074c3551d226e  pop rdx
000074c3551d226f  pop rcx
000074c3551d2270  pop rax
000074c3551d2271  add rsp, 0x08
000074c3551d2275  jmp 0x000074C3551CFBF7
000074c3551d227a  sub rsp, 0x08
000074c3551d227e  push rax
000074c3551d227f  push rcx
000074c3551d2280  push rdx
000074c3551d2281  push rdi
000074c3551d2282  push rsi
000074c3551d2283  push r8
000074c3551d2285  push r9
000074c3551d2287  push r10
000074c3551d2289  push r11
000074c3551d228b  sub rsp, 0xF0
000074c3551d2292  vmovaps [rsp], xmm0
000074c3551d2297  vmovaps [rsp+0x10], xmm1
000074c3551d229d  vmovaps [rsp+0x20], xmm2
000074c3551d22a3  vmovaps [rsp+0x30], xmm3
000074c3551d22a9  vmovaps [rsp+0x40], xmm4
000074c3551d22af  vmovaps [rsp+0x50], xmm5
000074c3551d22b5  vmovaps [rsp+0x60], xmm6
000074c3551d22bb  vmovaps [rsp+0x70], xmm7
000074c3551d22c1  vmovaps [rsp+0x80], xmm8
000074c3551d22ca  vmovaps [rsp+0x90], xmm9
000074c3551d22d3  vmovaps [rsp+0xA0], xmm10
000074c3551d22dc  vmovaps [rsp+0xB0], xmm11
000074c3551d22e5  vmovaps [rsp+0xC0], xmm12
000074c3551d22ee  vmovaps [rsp+0xD0], xmm13
000074c3551d22f7  vmovaps [rsp+0xE0], xmm15
000074c3551d2300  sub rsp, 0x30
000074c3551d2304  movaps [rsp], xmm14
000074c3551d2309  movaps [rsp+0x10], xmm11
000074c3551d230f  movaps [rsp+0x20], xmm1
000074c3551d2314  lea rdi, [rsp]
000074c3551d2318  mov esi, 0x00
000074c3551d231d  mov rax, 0x5F9407FA9530
000074c3551d2327  call rax
000074c3551d2329  movaps xmm14, [rsp]
000074c3551d232e  add rsp, 0x30
000074c3551d2332  vmovaps xmm0, [rsp]
000074c3551d2337  vmovaps xmm1, [rsp+0x10]
000074c3551d233d  vmovaps xmm2, [rsp+0x20]
000074c3551d2343  vmovaps xmm3, [rsp+0x30]
000074c3551d2349  vmovaps xmm4, [rsp+0x40]
000074c3551d234f  vmovaps xmm5, [rsp+0x50]
000074c3551d2355  vmovaps xmm6, [rsp+0x60]
000074c3551d235b  vmovaps xmm7, [rsp+0x70]
000074c3551d2361  vmovaps xmm8, [rsp+0x80]
000074c3551d236a  vmovaps xmm9, [rsp+0x90]
000074c3551d2373  vmovaps xmm10, [rsp+0xA0]
000074c3551d237c  vmovaps xmm11, [rsp+0xB0]
000074c3551d2385  vmovaps xmm12, [rsp+0xC0]
000074c3551d238e  vmovaps xmm13, [rsp+0xD0]
000074c3551d2397  vmovaps xmm15, [rsp+0xE0]
000074c3551d23a0  add rsp, 0xF0
000074c3551d23a7  pop r11
000074c3551d23a9  pop r10
000074c3551d23ab  pop r9
000074c3551d23ad  pop r8
000074c3551d23af  pop rsi
000074c3551d23b0  pop rdi
000074c3551d23b1  pop rdx
000074c3551d23b2  pop rcx
000074c3551d23b3  pop rax
000074c3551d23b4  add rsp, 0x08
000074c3551d23b8  jmp 0x000074C3551CFC21
000074c3551d23bd  sub rsp, 0x08
000074c3551d23c1  push rax
000074c3551d23c2  push rcx
000074c3551d23c3  push rdx
000074c3551d23c4  push rdi
000074c3551d23c5  push rsi
000074c3551d23c6  push r8
000074c3551d23c8  push r9
000074c3551d23ca  push r10
000074c3551d23cc  push r11
000074c3551d23ce  sub rsp, 0xF0
000074c3551d23d5  vmovaps [rsp], xmm0
000074c3551d23da  vmovaps [rsp+0x10], xmm1
000074c3551d23e0  vmovaps [rsp+0x20], xmm2
000074c3551d23e6  vmovaps [rsp+0x30], xmm3
000074c3551d23ec  vmovaps [rsp+0x40], xmm4
000074c3551d23f2  vmovaps [rsp+0x50], xmm5
000074c3551d23f8  vmovaps [rsp+0x60], xmm6
000074c3551d23fe  vmovaps [rsp+0x70], xmm7
000074c3551d2404  vmovaps [rsp+0x80], xmm8
000074c3551d240d  vmovaps [rsp+0x90], xmm9
000074c3551d2416  vmovaps [rsp+0xA0], xmm10
000074c3551d241f  vmovaps [rsp+0xB0], xmm11
000074c3551d2428  vmovaps [rsp+0xC0], xmm12
000074c3551d2431  vmovaps [rsp+0xD0], xmm14
000074c3551d243a  vmovaps [rsp+0xE0], xmm15
000074c3551d2443  sub rsp, 0x30
000074c3551d2447  movaps [rsp], xmm13
000074c3551d244c  movaps [rsp+0x10], xmm11
000074c3551d2452  movaps [rsp+0x20], xmm1
000074c3551d2457  lea rdi, [rsp]
000074c3551d245b  mov esi, 0x00
000074c3551d2460  mov rax, 0x5F9407FA9530
000074c3551d246a  call rax
000074c3551d246c  movaps xmm13, [rsp]
000074c3551d2471  add rsp, 0x30
000074c3551d2475  vmovaps xmm0, [rsp]
000074c3551d247a  vmovaps xmm1, [rsp+0x10]
000074c3551d2480  vmovaps xmm2, [rsp+0x20]
000074c3551d2486  vmovaps xmm3, [rsp+0x30]
000074c3551d248c  vmovaps xmm4, [rsp+0x40]
000074c3551d2492  vmovaps xmm5, [rsp+0x50]
000074c3551d2498  vmovaps xmm6, [rsp+0x60]
000074c3551d249e  vmovaps xmm7, [rsp+0x70]
000074c3551d24a4  vmovaps xmm8, [rsp+0x80]
000074c3551d24ad  vmovaps xmm9, [rsp+0x90]
000074c3551d24b6  vmovaps xmm10, [rsp+0xA0]
000074c3551d24bf  vmovaps xmm11, [rsp+0xB0]
000074c3551d24c8  vmovaps xmm12, [rsp+0xC0]
000074c3551d24d1  vmovaps xmm14, [rsp+0xD0]
000074c3551d24da  vmovaps xmm15, [rsp+0xE0]
000074c3551d24e3  add rsp, 0xF0
000074c3551d24ea  pop r11
000074c3551d24ec  pop r10
000074c3551d24ee  pop r9
000074c3551d24f0  pop r8
000074c3551d24f2  pop rsi
000074c3551d24f3  pop rdi
000074c3551d24f4  pop rdx
000074c3551d24f5  pop rcx
000074c3551d24f6  pop rax
000074c3551d24f7  add rsp, 0x08
000074c3551d24fb  jmp 0x000074C3551CFC76
000074c3551d2500  call 0x000074C354FFF430
000074c3551d2505  jmp 0x000074C3551CFC83
000074c3551d250a  sub rsp, 0x08
000074c3551d250e  push rax
000074c3551d250f  push rcx
000074c3551d2510  push rdx
000074c3551d2511  push rdi
000074c3551d2512  push rsi
000074c3551d2513  push r8
000074c3551d2515  push r9
000074c3551d2517  push r10
000074c3551d2519  push r11
000074c3551d251b  sub rsp, 0xF0
000074c3551d2522  vmovaps [rsp], xmm0
000074c3551d2527  vmovaps [rsp+0x10], xmm1
000074c3551d252d  vmovaps [rsp+0x20], xmm2
000074c3551d2533  vmovaps [rsp+0x30], xmm3
000074c3551d2539  vmovaps [rsp+0x40], xmm4
000074c3551d253f  vmovaps [rsp+0x50], xmm5
000074c3551d2545  vmovaps [rsp+0x60], xmm6
000074c3551d254b  vmovaps [rsp+0x70], xmm7
000074c3551d2551  vmovaps [rsp+0x80], xmm8
000074c3551d255a  vmovaps [rsp+0x90], xmm9
000074c3551d2563  vmovaps [rsp+0xA0], xmm10
000074c3551d256c  vmovaps [rsp+0xB0], xmm11
000074c3551d2575  vmovaps [rsp+0xC0], xmm12
000074c3551d257e  vmovaps [rsp+0xD0], xmm13
000074c3551d2587  vmovaps [rsp+0xE0], xmm14
000074c3551d2590  sub rsp, 0x30
000074c3551d2594  movaps [rsp], xmm15
000074c3551d2599  movaps [rsp+0x10], xmm11
000074c3551d259f  movaps [rsp+0x20], xmm1
000074c3551d25a4  lea rdi, [rsp]
000074c3551d25a8  mov esi, 0x00
000074c3551d25ad  mov rax, 0x5F9407FA9530
000074c3551d25b7  call rax
000074c3551d25b9  movaps xmm15, [rsp]
000074c3551d25be  add rsp, 0x30
000074c3551d25c2  vmovaps xmm0, [rsp]
000074c3551d25c7  vmovaps xmm1, [rsp+0x10]
000074c3551d25cd  vmovaps xmm2, [rsp+0x20]
000074c3551d25d3  vmovaps xmm3, [rsp+0x30]
000074c3551d25d9  vmovaps xmm4, [rsp+0x40]
000074c3551d25df  vmovaps xmm5, [rsp+0x50]
000074c3551d25e5  vmovaps xmm6, [rsp+0x60]
000074c3551d25eb  vmovaps xmm7, [rsp+0x70]
000074c3551d25f1  vmovaps xmm8, [rsp+0x80]
000074c3551d25fa  vmovaps xmm9, [rsp+0x90]
000074c3551d2603  vmovaps xmm10, [rsp+0xA0]
000074c3551d260c  vmovaps xmm11, [rsp+0xB0]
000074c3551d2615  vmovaps xmm12, [rsp+0xC0]
000074c3551d261e  vmovaps xmm13, [rsp+0xD0]
000074c3551d2627  vmovaps xmm14, [rsp+0xE0]
000074c3551d2630  add rsp, 0xF0
000074c3551d2637  pop r11
000074c3551d2639  pop r10
000074c3551d263b  pop r9
000074c3551d263d  pop r8
000074c3551d263f  pop rsi
000074c3551d2640  pop rdi
000074c3551d2641  pop rdx
000074c3551d2642  pop rcx
000074c3551d2643  pop rax
000074c3551d2644  add rsp, 0x08
000074c3551d2648  jmp 0x000074C3551CFCBC
000074c3551d264d  sub rsp, 0x08
000074c3551d2651  push rax
000074c3551d2652  push rcx
000074c3551d2653  push rdx
000074c3551d2654  push rdi
000074c3551d2655  push rsi
000074c3551d2656  push r8
000074c3551d2658  push r9
000074c3551d265a  push r10
000074c3551d265c  push r11
000074c3551d265e  sub rsp, 0xF0
000074c3551d2665  vmovaps [rsp], xmm0
000074c3551d266a  vmovaps [rsp+0x10], xmm1
000074c3551d2670  vmovaps [rsp+0x20], xmm2
000074c3551d2676  vmovaps [rsp+0x30], xmm3
000074c3551d267c  vmovaps [rsp+0x40], xmm4
000074c3551d2682  vmovaps [rsp+0x50], xmm5
000074c3551d2688  vmovaps [rsp+0x60], xmm6
000074c3551d268e  vmovaps [rsp+0x70], xmm7
000074c3551d2694  vmovaps [rsp+0x80], xmm8
000074c3551d269d  vmovaps [rsp+0x90], xmm9
000074c3551d26a6  vmovaps [rsp+0xA0], xmm10
000074c3551d26af  vmovaps [rsp+0xB0], xmm12
000074c3551d26b8  vmovaps [rsp+0xC0], xmm13
000074c3551d26c1  vmovaps [rsp+0xD0], xmm14
000074c3551d26ca  vmovaps [rsp+0xE0], xmm15
000074c3551d26d3  sub rsp, 0x30
000074c3551d26d7  movaps [rsp], xmm11
000074c3551d26dc  movaps [rsp+0x10], xmm6
000074c3551d26e1  movaps [rsp+0x20], xmm14
000074c3551d26e7  lea rdi, [rsp]
000074c3551d26eb  mov esi, 0x00
000074c3551d26f0  mov rax, 0x5F9407FA9530
000074c3551d26fa  call rax
000074c3551d26fc  movaps xmm11, [rsp]
000074c3551d2701  add rsp, 0x30
000074c3551d2705  vmovaps xmm0, [rsp]
000074c3551d270a  vmovaps xmm1, [rsp+0x10]
000074c3551d2710  vmovaps xmm2, [rsp+0x20]
000074c3551d2716  vmovaps xmm3, [rsp+0x30]
000074c3551d271c  vmovaps xmm4, [rsp+0x40]
000074c3551d2722  vmovaps xmm5, [rsp+0x50]
000074c3551d2728  vmovaps xmm6, [rsp+0x60]
000074c3551d272e  vmovaps xmm7, [rsp+0x70]
000074c3551d2734  vmovaps xmm8, [rsp+0x80]
000074c3551d273d  vmovaps xmm9, [rsp+0x90]
000074c3551d2746  vmovaps xmm10, [rsp+0xA0]
000074c3551d274f  vmovaps xmm12, [rsp+0xB0]
000074c3551d2758  vmovaps xmm13, [rsp+0xC0]
000074c3551d2761  vmovaps xmm14, [rsp+0xD0]
000074c3551d276a  vmovaps xmm15, [rsp+0xE0]
000074c3551d2773  add rsp, 0xF0
000074c3551d277a  pop r11
000074c3551d277c  pop r10
000074c3551d277e  pop r9
000074c3551d2780  pop r8
000074c3551d2782  pop rsi
000074c3551d2783  pop rdi
000074c3551d2784  pop rdx
000074c3551d2785  pop rcx
000074c3551d2786  pop rax
000074c3551d2787  add rsp, 0x08
000074c3551d278b  jmp 0x000074C3551CFD34
000074c3551d2790  call 0x000074C354FFF430
000074c3551d2795  jmp 0x000074C3551CFD3E
000074c3551d279a  sub rsp, 0x08
000074c3551d279e  push rax
000074c3551d279f  push rcx
000074c3551d27a0  push rdx
000074c3551d27a1  push rdi
000074c3551d27a2  push rsi
000074c3551d27a3  push r8
000074c3551d27a5  push r9
000074c3551d27a7  push r10
000074c3551d27a9  push r11
000074c3551d27ab  sub rsp, 0xF0
000074c3551d27b2  vmovaps [rsp], xmm0
000074c3551d27b7  vmovaps [rsp+0x10], xmm1
000074c3551d27bd  vmovaps [rsp+0x20], xmm2
000074c3551d27c3  vmovaps [rsp+0x30], xmm3
000074c3551d27c9  vmovaps [rsp+0x40], xmm4
000074c3551d27cf  vmovaps [rsp+0x50], xmm5
000074c3551d27d5  vmovaps [rsp+0x60], xmm6
000074c3551d27db  vmovaps [rsp+0x70], xmm7
000074c3551d27e1  vmovaps [rsp+0x80], xmm8
000074c3551d27ea  vmovaps [rsp+0x90], xmm9
000074c3551d27f3  vmovaps [rsp+0xA0], xmm10
000074c3551d27fc  vmovaps [rsp+0xB0], xmm11
000074c3551d2805  vmovaps [rsp+0xC0], xmm12
000074c3551d280e  vmovaps [rsp+0xD0], xmm13
000074c3551d2817  vmovaps [rsp+0xE0], xmm15
000074c3551d2820  sub rsp, 0x30
000074c3551d2824  movaps [rsp], xmm14
000074c3551d2829  movaps [rsp+0x10], xmm6
000074c3551d282e  movaps [rsp+0x20], xmm2
000074c3551d2833  lea rdi, [rsp]
000074c3551d2837  mov esi, 0x00
000074c3551d283c  mov rax, 0x5F9407FA9530
000074c3551d2846  call rax
000074c3551d2848  movaps xmm14, [rsp]
000074c3551d284d  add rsp, 0x30
000074c3551d2851  vmovaps xmm0, [rsp]
000074c3551d2856  vmovaps xmm1, [rsp+0x10]
000074c3551d285c  vmovaps xmm2, [rsp+0x20]
000074c3551d2862  vmovaps xmm3, [rsp+0x30]
000074c3551d2868  vmovaps xmm4, [rsp+0x40]
000074c3551d286e  vmovaps xmm5, [rsp+0x50]
000074c3551d2874  vmovaps xmm6, [rsp+0x60]
000074c3551d287a  vmovaps xmm7, [rsp+0x70]
000074c3551d2880  vmovaps xmm8, [rsp+0x80]
000074c3551d2889  vmovaps xmm9, [rsp+0x90]
000074c3551d2892  vmovaps xmm10, [rsp+0xA0]
000074c3551d289b  vmovaps xmm11, [rsp+0xB0]
000074c3551d28a4  vmovaps xmm12, [rsp+0xC0]
000074c3551d28ad  vmovaps xmm13, [rsp+0xD0]
000074c3551d28b6  vmovaps xmm15, [rsp+0xE0]
000074c3551d28bf  add rsp, 0xF0
000074c3551d28c6  pop r11
000074c3551d28c8  pop r10
000074c3551d28ca  pop r9
000074c3551d28cc  pop r8
000074c3551d28ce  pop rsi
000074c3551d28cf  pop rdi
000074c3551d28d0  pop rdx
000074c3551d28d1  pop rcx
000074c3551d28d2  pop rax
000074c3551d28d3  add rsp, 0x08
000074c3551d28d7  jmp 0x000074C3551CFD72
000074c3551d28dc  sub rsp, 0x08
000074c3551d28e0  push rax
000074c3551d28e1  push rcx
000074c3551d28e2  push rdx
000074c3551d28e3  push rdi
000074c3551d28e4  push rsi
000074c3551d28e5  push r8
000074c3551d28e7  push r9
000074c3551d28e9  push r10
000074c3551d28eb  push r11
000074c3551d28ed  sub rsp, 0xF0
000074c3551d28f4  vmovaps [rsp], xmm0
000074c3551d28f9  vmovaps [rsp+0x10], xmm1
000074c3551d28ff  vmovaps [rsp+0x20], xmm2
000074c3551d2905  vmovaps [rsp+0x30], xmm3
000074c3551d290b  vmovaps [rsp+0x40], xmm4
000074c3551d2911  vmovaps [rsp+0x50], xmm5
000074c3551d2917  vmovaps [rsp+0x60], xmm7
000074c3551d291d  vmovaps [rsp+0x70], xmm8
000074c3551d2923  vmovaps [rsp+0x80], xmm9
000074c3551d292c  vmovaps [rsp+0x90], xmm10
000074c3551d2935  vmovaps [rsp+0xA0], xmm11
000074c3551d293e  vmovaps [rsp+0xB0], xmm12
000074c3551d2947  vmovaps [rsp+0xC0], xmm13
000074c3551d2950  vmovaps [rsp+0xD0], xmm14
000074c3551d2959  vmovaps [rsp+0xE0], xmm15
000074c3551d2962  sub rsp, 0x30
000074c3551d2966  movaps [rsp], xmm6
000074c3551d296a  movaps [rsp+0x10], xmm5
000074c3551d296f  movaps [rsp+0x20], xmm1
000074c3551d2974  lea rdi, [rsp]
000074c3551d2978  mov esi, 0x00
000074c3551d297d  mov rax, 0x5F9407FA9530
000074c3551d2987  call rax
000074c3551d2989  movaps xmm6, [rsp]
000074c3551d298d  add rsp, 0x30
000074c3551d2991  vmovaps xmm0, [rsp]
000074c3551d2996  vmovaps xmm1, [rsp+0x10]
000074c3551d299c  vmovaps xmm2, [rsp+0x20]
000074c3551d29a2  vmovaps xmm3, [rsp+0x30]
000074c3551d29a8  vmovaps xmm4, [rsp+0x40]
000074c3551d29ae  vmovaps xmm5, [rsp+0x50]
000074c3551d29b4  vmovaps xmm7, [rsp+0x60]
000074c3551d29ba  vmovaps xmm8, [rsp+0x70]
000074c3551d29c0  vmovaps xmm9, [rsp+0x80]
000074c3551d29c9  vmovaps xmm10, [rsp+0x90]
000074c3551d29d2  vmovaps xmm11, [rsp+0xA0]
000074c3551d29db  vmovaps xmm12, [rsp+0xB0]
000074c3551d29e4  vmovaps xmm13, [rsp+0xC0]
000074c3551d29ed  vmovaps xmm14, [rsp+0xD0]
000074c3551d29f6  vmovaps xmm15, [rsp+0xE0]
000074c3551d29ff  add rsp, 0xF0
000074c3551d2a06  pop r11
000074c3551d2a08  pop r10
000074c3551d2a0a  pop r9
000074c3551d2a0c  pop r8
000074c3551d2a0e  pop rsi
000074c3551d2a0f  pop rdi
000074c3551d2a10  pop rdx
000074c3551d2a11  pop rcx
000074c3551d2a12  pop rax
000074c3551d2a13  add rsp, 0x08
000074c3551d2a17  jmp 0x000074C3551CFD98
000074c3551d2a1c  sub rsp, 0x08
000074c3551d2a20  push rax
000074c3551d2a21  push rcx
000074c3551d2a22  push rdx
000074c3551d2a23  push rdi
000074c3551d2a24  push rsi
000074c3551d2a25  push r8
000074c3551d2a27  push r9
000074c3551d2a29  push r10
000074c3551d2a2b  push r11
000074c3551d2a2d  sub rsp, 0xF0
000074c3551d2a34  vmovaps [rsp], xmm0
000074c3551d2a39  vmovaps [rsp+0x10], xmm2
000074c3551d2a3f  vmovaps [rsp+0x20], xmm3
000074c3551d2a45  vmovaps [rsp+0x30], xmm4
000074c3551d2a4b  vmovaps [rsp+0x40], xmm5
000074c3551d2a51  vmovaps [rsp+0x50], xmm6
000074c3551d2a57  vmovaps [rsp+0x60], xmm7
000074c3551d2a5d  vmovaps [rsp+0x70], xmm8
000074c3551d2a63  vmovaps [rsp+0x80], xmm9
000074c3551d2a6c  vmovaps [rsp+0x90], xmm10
000074c3551d2a75  vmovaps [rsp+0xA0], xmm11
000074c3551d2a7e  vmovaps [rsp+0xB0], xmm12
000074c3551d2a87  vmovaps [rsp+0xC0], xmm13
000074c3551d2a90  vmovaps [rsp+0xD0], xmm14
000074c3551d2a99  vmovaps [rsp+0xE0], xmm15
000074c3551d2aa2  sub rsp, 0x30
000074c3551d2aa6  movaps [rsp], xmm1
000074c3551d2aaa  movaps [rsp+0x10], xmm5
000074c3551d2aaf  movaps [rsp+0x20], xmm13
000074c3551d2ab5  lea rdi, [rsp]
000074c3551d2ab9  mov esi, 0x00
000074c3551d2abe  mov rax, 0x5F9407FA9530
000074c3551d2ac8  call rax
000074c3551d2aca  movaps xmm1, [rsp]
000074c3551d2ace  add rsp, 0x30
000074c3551d2ad2  vmovaps xmm0, [rsp]
000074c3551d2ad7  vmovaps xmm2, [rsp+0x10]
000074c3551d2add  vmovaps xmm3, [rsp+0x20]
000074c3551d2ae3  vmovaps xmm4, [rsp+0x30]
000074c3551d2ae9  vmovaps xmm5, [rsp+0x40]
000074c3551d2aef  vmovaps xmm6, [rsp+0x50]
000074c3551d2af5  vmovaps xmm7, [rsp+0x60]
000074c3551d2afb  vmovaps xmm8, [rsp+0x70]
000074c3551d2b01  vmovaps xmm9, [rsp+0x80]
000074c3551d2b0a  vmovaps xmm10, [rsp+0x90]
000074c3551d2b13  vmovaps xmm11, [rsp+0xA0]
000074c3551d2b1c  vmovaps xmm12, [rsp+0xB0]
000074c3551d2b25  vmovaps xmm13, [rsp+0xC0]
000074c3551d2b2e  vmovaps xmm14, [rsp+0xD0]
000074c3551d2b37  vmovaps xmm15, [rsp+0xE0]
000074c3551d2b40  add rsp, 0xF0
000074c3551d2b47  pop r11
000074c3551d2b49  pop r10
000074c3551d2b4b  pop r9
000074c3551d2b4d  pop r8
000074c3551d2b4f  pop rsi
000074c3551d2b50  pop rdi
000074c3551d2b51  pop rdx
000074c3551d2b52  pop rcx
000074c3551d2b53  pop rax
000074c3551d2b54  add rsp, 0x08
000074c3551d2b58  jmp 0x000074C3551CFDB6
000074c3551d2b5d  sub rsp, 0x08
000074c3551d2b61  push rax
000074c3551d2b62  push rcx
000074c3551d2b63  push rdx
000074c3551d2b64  push rdi
000074c3551d2b65  push rsi
000074c3551d2b66  push r8
000074c3551d2b68  push r9
000074c3551d2b6a  push r10
000074c3551d2b6c  push r11
000074c3551d2b6e  sub rsp, 0xF0
000074c3551d2b75  vmovaps [rsp], xmm0
000074c3551d2b7a  vmovaps [rsp+0x10], xmm1
000074c3551d2b80  vmovaps [rsp+0x20], xmm2
000074c3551d2b86  vmovaps [rsp+0x30], xmm3
000074c3551d2b8c  vmovaps [rsp+0x40], xmm4
000074c3551d2b92  vmovaps [rsp+0x50], xmm6
000074c3551d2b98  vmovaps [rsp+0x60], xmm7
000074c3551d2b9e  vmovaps [rsp+0x70], xmm8
000074c3551d2ba4  vmovaps [rsp+0x80], xmm9
000074c3551d2bad  vmovaps [rsp+0x90], xmm10
000074c3551d2bb6  vmovaps [rsp+0xA0], xmm11
000074c3551d2bbf  vmovaps [rsp+0xB0], xmm12
000074c3551d2bc8  vmovaps [rsp+0xC0], xmm13
000074c3551d2bd1  vmovaps [rsp+0xD0], xmm14
000074c3551d2bda  vmovaps [rsp+0xE0], xmm15
000074c3551d2be3  sub rsp, 0x30
000074c3551d2be7  movaps [rsp], xmm5
000074c3551d2beb  movaps [rsp+0x10], xmm2
000074c3551d2bf0  movaps [rsp+0x20], xmm13
000074c3551d2bf6  lea rdi, [rsp]
000074c3551d2bfa  mov esi, 0x00
000074c3551d2bff  mov rax, 0x5F9407FA9530
000074c3551d2c09  call rax
000074c3551d2c0b  movaps xmm5, [rsp]
000074c3551d2c0f  add rsp, 0x30
000074c3551d2c13  vmovaps xmm0, [rsp]
000074c3551d2c18  vmovaps xmm1, [rsp+0x10]
000074c3551d2c1e  vmovaps xmm2, [rsp+0x20]
000074c3551d2c24  vmovaps xmm3, [rsp+0x30]
000074c3551d2c2a  vmovaps xmm4, [rsp+0x40]
000074c3551d2c30  vmovaps xmm6, [rsp+0x50]
000074c3551d2c36  vmovaps xmm7, [rsp+0x60]
000074c3551d2c3c  vmovaps xmm8, [rsp+0x70]
000074c3551d2c42  vmovaps xmm9, [rsp+0x80]
000074c3551d2c4b  vmovaps xmm10, [rsp+0x90]
000074c3551d2c54  vmovaps xmm11, [rsp+0xA0]
000074c3551d2c5d  vmovaps xmm12, [rsp+0xB0]
000074c3551d2c66  vmovaps xmm13, [rsp+0xC0]
000074c3551d2c6f  vmovaps xmm14, [rsp+0xD0]
000074c3551d2c78  vmovaps xmm15, [rsp+0xE0]
000074c3551d2c81  add rsp, 0xF0
000074c3551d2c88  pop r11
000074c3551d2c8a  pop r10
000074c3551d2c8c  pop r9
000074c3551d2c8e  pop r8
000074c3551d2c90  pop rsi
000074c3551d2c91  pop rdi
000074c3551d2c92  pop rdx
000074c3551d2c93  pop rcx
000074c3551d2c94  pop rax
000074c3551d2c95  add rsp, 0x08
000074c3551d2c99  jmp 0x000074C3551CFDEC
000074c3551d2c9e  sub rsp, 0x08
000074c3551d2ca2  push rax
000074c3551d2ca3  push rcx
000074c3551d2ca4  push rdx
000074c3551d2ca5  push rdi
000074c3551d2ca6  push rsi
000074c3551d2ca7  push r8
000074c3551d2ca9  push r9
000074c3551d2cab  push r10
000074c3551d2cad  push r11
000074c3551d2caf  sub rsp, 0xF0
000074c3551d2cb6  vmovaps [rsp], xmm0
000074c3551d2cbb  vmovaps [rsp+0x10], xmm1
000074c3551d2cc1  vmovaps [rsp+0x20], xmm2
000074c3551d2cc7  vmovaps [rsp+0x30], xmm3
000074c3551d2ccd  vmovaps [rsp+0x40], xmm4
000074c3551d2cd3  vmovaps [rsp+0x50], xmm5
000074c3551d2cd9  vmovaps [rsp+0x60], xmm6
000074c3551d2cdf  vmovaps [rsp+0x70], xmm7
000074c3551d2ce5  vmovaps [rsp+0x80], xmm8
000074c3551d2cee  vmovaps [rsp+0x90], xmm9
000074c3551d2cf7  vmovaps [rsp+0xA0], xmm10
000074c3551d2d00  vmovaps [rsp+0xB0], xmm11
000074c3551d2d09  vmovaps [rsp+0xC0], xmm12
000074c3551d2d12  vmovaps [rsp+0xD0], xmm14
000074c3551d2d1b  vmovaps [rsp+0xE0], xmm15
000074c3551d2d24  sub rsp, 0x30
000074c3551d2d28  movaps [rsp], xmm13
000074c3551d2d2d  movaps [rsp+0x10], xmm10
000074c3551d2d33  movaps [rsp+0x20], xmm1
000074c3551d2d38  lea rdi, [rsp]
000074c3551d2d3c  mov esi, 0x00
000074c3551d2d41  mov rax, 0x5F9407FA9530
000074c3551d2d4b  call rax
000074c3551d2d4d  movaps xmm13, [rsp]
000074c3551d2d52  add rsp, 0x30
000074c3551d2d56  vmovaps xmm0, [rsp]
000074c3551d2d5b  vmovaps xmm1, [rsp+0x10]
000074c3551d2d61  vmovaps xmm2, [rsp+0x20]
000074c3551d2d67  vmovaps xmm3, [rsp+0x30]
000074c3551d2d6d  vmovaps xmm4, [rsp+0x40]
000074c3551d2d73  vmovaps xmm5, [rsp+0x50]
000074c3551d2d79  vmovaps xmm6, [rsp+0x60]
000074c3551d2d7f  vmovaps xmm7, [rsp+0x70]
000074c3551d2d85  vmovaps xmm8, [rsp+0x80]
000074c3551d2d8e  vmovaps xmm9, [rsp+0x90]
000074c3551d2d97  vmovaps xmm10, [rsp+0xA0]
000074c3551d2da0  vmovaps xmm11, [rsp+0xB0]
000074c3551d2da9  vmovaps xmm12, [rsp+0xC0]
000074c3551d2db2  vmovaps xmm14, [rsp+0xD0]
000074c3551d2dbb  vmovaps xmm15, [rsp+0xE0]
000074c3551d2dc4  add rsp, 0xF0
000074c3551d2dcb  pop r11
000074c3551d2dcd  pop r10
000074c3551d2dcf  pop r9
000074c3551d2dd1  pop r8
000074c3551d2dd3  pop rsi
000074c3551d2dd4  pop rdi
000074c3551d2dd5  pop rdx
000074c3551d2dd6  pop rcx
000074c3551d2dd7  pop rax
000074c3551d2dd8  add rsp, 0x08
000074c3551d2ddc  jmp 0x000074C3551CFE15
000074c3551d2de1  sub rsp, 0x08
000074c3551d2de5  push rax
000074c3551d2de6  push rcx
000074c3551d2de7  push rdx
000074c3551d2de8  push rdi
000074c3551d2de9  push rsi
000074c3551d2dea  push r8
000074c3551d2dec  push r9
000074c3551d2dee  push r10
000074c3551d2df0  push r11
000074c3551d2df2  sub rsp, 0xF0
000074c3551d2df9  vmovaps [rsp], xmm0
000074c3551d2dfe  vmovaps [rsp+0x10], xmm2
000074c3551d2e04  vmovaps [rsp+0x20], xmm3
000074c3551d2e0a  vmovaps [rsp+0x30], xmm4
000074c3551d2e10  vmovaps [rsp+0x40], xmm5
000074c3551d2e16  vmovaps [rsp+0x50], xmm6
000074c3551d2e1c  vmovaps [rsp+0x60], xmm7
000074c3551d2e22  vmovaps [rsp+0x70], xmm8
000074c3551d2e28  vmovaps [rsp+0x80], xmm9
000074c3551d2e31  vmovaps [rsp+0x90], xmm10
000074c3551d2e3a  vmovaps [rsp+0xA0], xmm11
000074c3551d2e43  vmovaps [rsp+0xB0], xmm12
000074c3551d2e4c  vmovaps [rsp+0xC0], xmm13
000074c3551d2e55  vmovaps [rsp+0xD0], xmm14
000074c3551d2e5e  vmovaps [rsp+0xE0], xmm15
000074c3551d2e67  sub rsp, 0x30
000074c3551d2e6b  movaps [rsp], xmm1
000074c3551d2e6f  movaps [rsp+0x10], xmm15
000074c3551d2e75  movaps [rsp+0x20], xmm10
000074c3551d2e7b  lea rdi, [rsp]
000074c3551d2e7f  mov esi, 0x00
000074c3551d2e84  mov rax, 0x5F9407FA9530
000074c3551d2e8e  call rax
000074c3551d2e90  movaps xmm1, [rsp]
000074c3551d2e94  add rsp, 0x30
000074c3551d2e98  vmovaps xmm0, [rsp]
000074c3551d2e9d  vmovaps xmm2, [rsp+0x10]
000074c3551d2ea3  vmovaps xmm3, [rsp+0x20]
000074c3551d2ea9  vmovaps xmm4, [rsp+0x30]
000074c3551d2eaf  vmovaps xmm5, [rsp+0x40]
000074c3551d2eb5  vmovaps xmm6, [rsp+0x50]
000074c3551d2ebb  vmovaps xmm7, [rsp+0x60]
000074c3551d2ec1  vmovaps xmm8, [rsp+0x70]
000074c3551d2ec7  vmovaps xmm9, [rsp+0x80]
000074c3551d2ed0  vmovaps xmm10, [rsp+0x90]
000074c3551d2ed9  vmovaps xmm11, [rsp+0xA0]
000074c3551d2ee2  vmovaps xmm12, [rsp+0xB0]
000074c3551d2eeb  vmovaps xmm13, [rsp+0xC0]
000074c3551d2ef4  vmovaps xmm14, [rsp+0xD0]
000074c3551d2efd  vmovaps xmm15, [rsp+0xE0]
000074c3551d2f06  add rsp, 0xF0
000074c3551d2f0d  pop r11
000074c3551d2f0f  pop r10
000074c3551d2f11  pop r9
000074c3551d2f13  pop r8
000074c3551d2f15  pop rsi
000074c3551d2f16  pop rdi
000074c3551d2f17  pop rdx
000074c3551d2f18  pop rcx
000074c3551d2f19  pop rax
000074c3551d2f1a  add rsp, 0x08
000074c3551d2f1e  jmp 0x000074C3551CFE34
000074c3551d2f23  sub rsp, 0x08
000074c3551d2f27  push rax
000074c3551d2f28  push rcx
000074c3551d2f29  push rdx
000074c3551d2f2a  push rdi
000074c3551d2f2b  push rsi
000074c3551d2f2c  push r8
000074c3551d2f2e  push r9
000074c3551d2f30  push r10
000074c3551d2f32  push r11
000074c3551d2f34  sub rsp, 0xF0
000074c3551d2f3b  vmovaps [rsp], xmm0
000074c3551d2f40  vmovaps [rsp+0x10], xmm1
000074c3551d2f46  vmovaps [rsp+0x20], xmm2
000074c3551d2f4c  vmovaps [rsp+0x30], xmm3
000074c3551d2f52  vmovaps [rsp+0x40], xmm4
000074c3551d2f58  vmovaps [rsp+0x50], xmm5
000074c3551d2f5e  vmovaps [rsp+0x60], xmm6
000074c3551d2f64  vmovaps [rsp+0x70], xmm7
000074c3551d2f6a  vmovaps [rsp+0x80], xmm8
000074c3551d2f73  vmovaps [rsp+0x90], xmm9
000074c3551d2f7c  vmovaps [rsp+0xA0], xmm10
000074c3551d2f85  vmovaps [rsp+0xB0], xmm11
000074c3551d2f8e  vmovaps [rsp+0xC0], xmm12
000074c3551d2f97  vmovaps [rsp+0xD0], xmm13
000074c3551d2fa0  vmovaps [rsp+0xE0], xmm14
000074c3551d2fa9  sub rsp, 0x30
000074c3551d2fad  movaps [rsp], xmm15
000074c3551d2fb2  movaps [rsp+0x10], xmm10
000074c3551d2fb8  movaps [rsp+0x20], xmm11
000074c3551d2fbe  lea rdi, [rsp]
000074c3551d2fc2  mov esi, 0x00
000074c3551d2fc7  mov rax, 0x5F9407FA9530
000074c3551d2fd1  call rax
000074c3551d2fd3  movaps xmm15, [rsp]
000074c3551d2fd8  add rsp, 0x30
000074c3551d2fdc  vmovaps xmm0, [rsp]
000074c3551d2fe1  vmovaps xmm1, [rsp+0x10]
000074c3551d2fe7  vmovaps xmm2, [rsp+0x20]
000074c3551d2fed  vmovaps xmm3, [rsp+0x30]
000074c3551d2ff3  vmovaps xmm4, [rsp+0x40]
000074c3551d2ff9  vmovaps xmm5, [rsp+0x50]
000074c3551d2fff  vmovaps xmm6, [rsp+0x60]
000074c3551d3005  vmovaps xmm7, [rsp+0x70]
000074c3551d300b  vmovaps xmm8, [rsp+0x80]
000074c3551d3014  vmovaps xmm9, [rsp+0x90]
000074c3551d301d  vmovaps xmm10, [rsp+0xA0]
000074c3551d3026  vmovaps xmm11, [rsp+0xB0]
000074c3551d302f  vmovaps xmm12, [rsp+0xC0]
000074c3551d3038  vmovaps xmm13, [rsp+0xD0]
000074c3551d3041  vmovaps xmm14, [rsp+0xE0]
000074c3551d304a  add rsp, 0xF0
000074c3551d3051  pop r11
000074c3551d3053  pop r10
000074c3551d3055  pop r9
000074c3551d3057  pop r8
000074c3551d3059  pop rsi
000074c3551d305a  pop rdi
000074c3551d305b  pop rdx
000074c3551d305c  pop rcx
000074c3551d305d  pop rax
000074c3551d305e  add rsp, 0x08
000074c3551d3062  jmp 0x000074C3551CFE57
000074c3551d3067  sub rsp, 0x08
000074c3551d306b  push rax
000074c3551d306c  push rcx
000074c3551d306d  push rdx
000074c3551d306e  push rdi
000074c3551d306f  push rsi
000074c3551d3070  push r8
000074c3551d3072  push r9
000074c3551d3074  push r10
000074c3551d3076  push r11
000074c3551d3078  sub rsp, 0xF0
000074c3551d307f  vmovaps [rsp], xmm0
000074c3551d3084  vmovaps [rsp+0x10], xmm1
000074c3551d308a  vmovaps [rsp+0x20], xmm2
000074c3551d3090  vmovaps [rsp+0x30], xmm3
000074c3551d3096  vmovaps [rsp+0x40], xmm4
000074c3551d309c  vmovaps [rsp+0x50], xmm5
000074c3551d30a2  vmovaps [rsp+0x60], xmm6
000074c3551d30a8  vmovaps [rsp+0x70], xmm7
000074c3551d30ae  vmovaps [rsp+0x80], xmm8
000074c3551d30b7  vmovaps [rsp+0x90], xmm9
000074c3551d30c0  vmovaps [rsp+0xA0], xmm11
000074c3551d30c9  vmovaps [rsp+0xB0], xmm12
000074c3551d30d2  vmovaps [rsp+0xC0], xmm13
000074c3551d30db  vmovaps [rsp+0xD0], xmm14
000074c3551d30e4  vmovaps [rsp+0xE0], xmm15
000074c3551d30ed  sub rsp, 0x30
000074c3551d30f1  movaps [rsp], xmm10
000074c3551d30f6  movaps [rsp+0x10], xmm12
000074c3551d30fc  movaps [rsp+0x20], xmm11
000074c3551d3102  lea rdi, [rsp]
000074c3551d3106  mov esi, 0x00
000074c3551d310b  mov rax, 0x5F9407FA9530
000074c3551d3115  call rax
000074c3551d3117  movaps xmm10, [rsp]
000074c3551d311c  add rsp, 0x30
000074c3551d3120  vmovaps xmm0, [rsp]
000074c3551d3125  vmovaps xmm1, [rsp+0x10]
000074c3551d312b  vmovaps xmm2, [rsp+0x20]
000074c3551d3131  vmovaps xmm3, [rsp+0x30]
000074c3551d3137  vmovaps xmm4, [rsp+0x40]
000074c3551d313d  vmovaps xmm5, [rsp+0x50]
000074c3551d3143  vmovaps xmm6, [rsp+0x60]
000074c3551d3149  vmovaps xmm7, [rsp+0x70]
000074c3551d314f  vmovaps xmm8, [rsp+0x80]
000074c3551d3158  vmovaps xmm9, [rsp+0x90]
000074c3551d3161  vmovaps xmm11, [rsp+0xA0]
000074c3551d316a  vmovaps xmm12, [rsp+0xB0]
000074c3551d3173  vmovaps xmm13, [rsp+0xC0]
000074c3551d317c  vmovaps xmm14, [rsp+0xD0]
000074c3551d3185  vmovaps xmm15, [rsp+0xE0]
000074c3551d318e  add rsp, 0xF0
000074c3551d3195  pop r11
000074c3551d3197  pop r10
000074c3551d3199  pop r9
000074c3551d319b  pop r8
000074c3551d319d  pop rsi
000074c3551d319e  pop rdi
000074c3551d319f  pop rdx
000074c3551d31a0  pop rcx
000074c3551d31a1  pop rax
000074c3551d31a2  add rsp, 0x08
000074c3551d31a6  jmp 0x000074C3551CFE80
000074c3551d31ab  sub rsp, 0x08
000074c3551d31af  push rax
000074c3551d31b0  push rcx
000074c3551d31b1  push rdx
000074c3551d31b2  push rdi
000074c3551d31b3  push rsi
000074c3551d31b4  push r8
000074c3551d31b6  push r9
000074c3551d31b8  push r10
000074c3551d31ba  push r11
000074c3551d31bc  sub rsp, 0xF0
000074c3551d31c3  vmovaps [rsp], xmm0
000074c3551d31c8  vmovaps [rsp+0x10], xmm1
000074c3551d31ce  vmovaps [rsp+0x20], xmm2
000074c3551d31d4  vmovaps [rsp+0x30], xmm3
000074c3551d31da  vmovaps [rsp+0x40], xmm4
000074c3551d31e0  vmovaps [rsp+0x50], xmm5
000074c3551d31e6  vmovaps [rsp+0x60], xmm6
000074c3551d31ec  vmovaps [rsp+0x70], xmm7
000074c3551d31f2  vmovaps [rsp+0x80], xmm8
000074c3551d31fb  vmovaps [rsp+0x90], xmm9
000074c3551d3204  vmovaps [rsp+0xA0], xmm10
000074c3551d320d  vmovaps [rsp+0xB0], xmm12
000074c3551d3216  vmovaps [rsp+0xC0], xmm13
000074c3551d321f  vmovaps [rsp+0xD0], xmm14
000074c3551d3228  vmovaps [rsp+0xE0], xmm15
000074c3551d3231  sub rsp, 0x30
000074c3551d3235  movaps [rsp], xmm11
000074c3551d323a  movaps [rsp+0x10], xmm2
000074c3551d323f  movaps [rsp+0x20], xmm12
000074c3551d3245  lea rdi, [rsp]
000074c3551d3249  mov esi, 0x00
000074c3551d324e  mov rax, 0x5F9407FA9530
000074c3551d3258  call rax
000074c3551d325a  movaps xmm11, [rsp]
000074c3551d325f  add rsp, 0x30
000074c3551d3263  vmovaps xmm0, [rsp]
000074c3551d3268  vmovaps xmm1, [rsp+0x10]
000074c3551d326e  vmovaps xmm2, [rsp+0x20]
000074c3551d3274  vmovaps xmm3, [rsp+0x30]
000074c3551d327a  vmovaps xmm4, [rsp+0x40]
000074c3551d3280  vmovaps xmm5, [rsp+0x50]
000074c3551d3286  vmovaps xmm6, [rsp+0x60]
000074c3551d328c  vmovaps xmm7, [rsp+0x70]
000074c3551d3292  vmovaps xmm8, [rsp+0x80]
000074c3551d329b  vmovaps xmm9, [rsp+0x90]
000074c3551d32a4  vmovaps xmm10, [rsp+0xA0]
000074c3551d32ad  vmovaps xmm12, [rsp+0xB0]
000074c3551d32b6  vmovaps xmm13, [rsp+0xC0]
000074c3551d32bf  vmovaps xmm14, [rsp+0xD0]
000074c3551d32c8  vmovaps xmm15, [rsp+0xE0]
000074c3551d32d1  add rsp, 0xF0
000074c3551d32d8  pop r11
000074c3551d32da  pop r10
000074c3551d32dc  pop r9
000074c3551d32de  pop r8
000074c3551d32e0  pop rsi
000074c3551d32e1  pop rdi
000074c3551d32e2  pop rdx
000074c3551d32e3  pop rcx
000074c3551d32e4  pop rax
000074c3551d32e5  add rsp, 0x08
000074c3551d32e9  jmp 0x000074C3551CFEB8
000074c3551d32ee  sub rsp, 0x08
000074c3551d32f2  push rax
000074c3551d32f3  push rcx
000074c3551d32f4  push rdx
000074c3551d32f5  push rdi
000074c3551d32f6  push rsi
000074c3551d32f7  push r8
000074c3551d32f9  push r9
000074c3551d32fb  push r10
000074c3551d32fd  push r11
000074c3551d32ff  sub rsp, 0xF0
000074c3551d3306  vmovaps [rsp], xmm0
000074c3551d330b  vmovaps [rsp+0x10], xmm2
000074c3551d3311  vmovaps [rsp+0x20], xmm3
000074c3551d3317  vmovaps [rsp+0x30], xmm4
000074c3551d331d  vmovaps [rsp+0x40], xmm5
000074c3551d3323  vmovaps [rsp+0x50], xmm6
000074c3551d3329  vmovaps [rsp+0x60], xmm7
000074c3551d332f  vmovaps [rsp+0x70], xmm8
000074c3551d3335  vmovaps [rsp+0x80], xmm9
000074c3551d333e  vmovaps [rsp+0x90], xmm10
000074c3551d3347  vmovaps [rsp+0xA0], xmm11
000074c3551d3350  vmovaps [rsp+0xB0], xmm12
000074c3551d3359  vmovaps [rsp+0xC0], xmm13
000074c3551d3362  vmovaps [rsp+0xD0], xmm14
000074c3551d336b  vmovaps [rsp+0xE0], xmm15
000074c3551d3374  sub rsp, 0x30
000074c3551d3378  movaps [rsp], xmm1
000074c3551d337c  movaps [rsp+0x10], xmm14
000074c3551d3382  movaps [rsp+0x20], xmm6
000074c3551d3387  lea rdi, [rsp]
000074c3551d338b  mov esi, 0x00
000074c3551d3390  mov rax, 0x5F9407FA9530
000074c3551d339a  call rax
000074c3551d339c  movaps xmm1, [rsp]
000074c3551d33a0  add rsp, 0x30
000074c3551d33a4  vmovaps xmm0, [rsp]
000074c3551d33a9  vmovaps xmm2, [rsp+0x10]
000074c3551d33af  vmovaps xmm3, [rsp+0x20]
000074c3551d33b5  vmovaps xmm4, [rsp+0x30]
000074c3551d33bb  vmovaps xmm5, [rsp+0x40]
000074c3551d33c1  vmovaps xmm6, [rsp+0x50]
000074c3551d33c7  vmovaps xmm7, [rsp+0x60]
000074c3551d33cd  vmovaps xmm8, [rsp+0x70]
000074c3551d33d3  vmovaps xmm9, [rsp+0x80]
000074c3551d33dc  vmovaps xmm10, [rsp+0x90]
000074c3551d33e5  vmovaps xmm11, [rsp+0xA0]
000074c3551d33ee  vmovaps xmm12, [rsp+0xB0]
000074c3551d33f7  vmovaps xmm13, [rsp+0xC0]
000074c3551d3400  vmovaps xmm14, [rsp+0xD0]
000074c3551d3409  vmovaps xmm15, [rsp+0xE0]
000074c3551d3412  add rsp, 0xF0
000074c3551d3419  pop r11
000074c3551d341b  pop r10
000074c3551d341d  pop r9
000074c3551d341f  pop r8
000074c3551d3421  pop rsi
000074c3551d3422  pop rdi
000074c3551d3423  pop rdx
000074c3551d3424  pop rcx
000074c3551d3425  pop rax
000074c3551d3426  add rsp, 0x08
000074c3551d342a  jmp 0x000074C3551CFED1
000074c3551d342f  sub rsp, 0x08
000074c3551d3433  push rax
000074c3551d3434  push rcx
000074c3551d3435  push rdx
000074c3551d3436  push rdi
000074c3551d3437  push rsi
000074c3551d3438  push r8
000074c3551d343a  push r9
000074c3551d343c  push r10
000074c3551d343e  push r11
000074c3551d3440  sub rsp, 0xF0
000074c3551d3447  vmovaps [rsp], xmm0
000074c3551d344c  vmovaps [rsp+0x10], xmm1
000074c3551d3452  vmovaps [rsp+0x20], xmm2
000074c3551d3458  vmovaps [rsp+0x30], xmm3
000074c3551d345e  vmovaps [rsp+0x40], xmm4
000074c3551d3464  vmovaps [rsp+0x50], xmm5
000074c3551d346a  vmovaps [rsp+0x60], xmm6
000074c3551d3470  vmovaps [rsp+0x70], xmm7
000074c3551d3476  vmovaps [rsp+0x80], xmm8
000074c3551d347f  vmovaps [rsp+0x90], xmm9
000074c3551d3488  vmovaps [rsp+0xA0], xmm10
000074c3551d3491  vmovaps [rsp+0xB0], xmm11
000074c3551d349a  vmovaps [rsp+0xC0], xmm12
000074c3551d34a3  vmovaps [rsp+0xD0], xmm13
000074c3551d34ac  vmovaps [rsp+0xE0], xmm15
000074c3551d34b5  sub rsp, 0x30
000074c3551d34b9  movaps [rsp], xmm14
000074c3551d34be  movaps [rsp+0x10], xmm12
000074c3551d34c4  movaps [rsp+0x20], xmm5
000074c3551d34c9  lea rdi, [rsp]
000074c3551d34cd  mov esi, 0x00
000074c3551d34d2  mov rax, 0x5F9407FA9530
000074c3551d34dc  call rax
000074c3551d34de  movaps xmm14, [rsp]
000074c3551d34e3  add rsp, 0x30
000074c3551d34e7  vmovaps xmm0, [rsp]
000074c3551d34ec  vmovaps xmm1, [rsp+0x10]
000074c3551d34f2  vmovaps xmm2, [rsp+0x20]
000074c3551d34f8  vmovaps xmm3, [rsp+0x30]
000074c3551d34fe  vmovaps xmm4, [rsp+0x40]
000074c3551d3504  vmovaps xmm5, [rsp+0x50]
000074c3551d350a  vmovaps xmm6, [rsp+0x60]
000074c3551d3510  vmovaps xmm7, [rsp+0x70]
000074c3551d3516  vmovaps xmm8, [rsp+0x80]
000074c3551d351f  vmovaps xmm9, [rsp+0x90]
000074c3551d3528  vmovaps xmm10, [rsp+0xA0]
000074c3551d3531  vmovaps xmm11, [rsp+0xB0]
000074c3551d353a  vmovaps xmm12, [rsp+0xC0]
000074c3551d3543  vmovaps xmm13, [rsp+0xD0]
000074c3551d354c  vmovaps xmm15, [rsp+0xE0]
000074c3551d3555  add rsp, 0xF0
000074c3551d355c  pop r11
000074c3551d355e  pop r10
000074c3551d3560  pop r9
000074c3551d3562  pop r8
000074c3551d3564  pop rsi
000074c3551d3565  pop rdi
000074c3551d3566  pop rdx
000074c3551d3567  pop rcx
000074c3551d3568  pop rax
000074c3551d3569  add rsp, 0x08
000074c3551d356d  jmp 0x000074C3551CFEF1
000074c3551d3572  sub rsp, 0x08
000074c3551d3576  push rax
000074c3551d3577  push rcx
000074c3551d3578  push rdx
000074c3551d3579  push rdi
000074c3551d357a  push rsi
000074c3551d357b  push r8
000074c3551d357d  push r9
000074c3551d357f  push r10
000074c3551d3581  push r11
000074c3551d3583  sub rsp, 0xF0
000074c3551d358a  vmovaps [rsp], xmm0
000074c3551d358f  vmovaps [rsp+0x10], xmm1
000074c3551d3595  vmovaps [rsp+0x20], xmm2
000074c3551d359b  vmovaps [rsp+0x30], xmm3
000074c3551d35a1  vmovaps [rsp+0x40], xmm4
000074c3551d35a7  vmovaps [rsp+0x50], xmm5
000074c3551d35ad  vmovaps [rsp+0x60], xmm7
000074c3551d35b3  vmovaps [rsp+0x70], xmm8
000074c3551d35b9  vmovaps [rsp+0x80], xmm9
000074c3551d35c2  vmovaps [rsp+0x90], xmm10
000074c3551d35cb  vmovaps [rsp+0xA0], xmm11
000074c3551d35d4  vmovaps [rsp+0xB0], xmm12
000074c3551d35dd  vmovaps [rsp+0xC0], xmm13
000074c3551d35e6  vmovaps [rsp+0xD0], xmm14
000074c3551d35ef  vmovaps [rsp+0xE0], xmm15
000074c3551d35f8  sub rsp, 0x30
000074c3551d35fc  movaps [rsp], xmm6
000074c3551d3600  movaps [rsp+0x10], xmm9
000074c3551d3606  movaps [rsp+0x20], xmm12
000074c3551d360c  lea rdi, [rsp]
000074c3551d3610  mov esi, 0x00
000074c3551d3615  mov rax, 0x5F9407FA9530
000074c3551d361f  call rax
000074c3551d3621  movaps xmm6, [rsp]
000074c3551d3625  add rsp, 0x30
000074c3551d3629  vmovaps xmm0, [rsp]
000074c3551d362e  vmovaps xmm1, [rsp+0x10]
000074c3551d3634  vmovaps xmm2, [rsp+0x20]
000074c3551d363a  vmovaps xmm3, [rsp+0x30]
000074c3551d3640  vmovaps xmm4, [rsp+0x40]
000074c3551d3646  vmovaps xmm5, [rsp+0x50]
000074c3551d364c  vmovaps xmm7, [rsp+0x60]
000074c3551d3652  vmovaps xmm8, [rsp+0x70]
000074c3551d3658  vmovaps xmm9, [rsp+0x80]
000074c3551d3661  vmovaps xmm10, [rsp+0x90]
000074c3551d366a  vmovaps xmm11, [rsp+0xA0]
000074c3551d3673  vmovaps xmm12, [rsp+0xB0]
000074c3551d367c  vmovaps xmm13, [rsp+0xC0]
000074c3551d3685  vmovaps xmm14, [rsp+0xD0]
000074c3551d368e  vmovaps xmm15, [rsp+0xE0]
000074c3551d3697  add rsp, 0xF0
000074c3551d369e  pop r11
000074c3551d36a0  pop r10
000074c3551d36a2  pop r9
000074c3551d36a4  pop r8
000074c3551d36a6  pop rsi
000074c3551d36a7  pop rdi
000074c3551d36a8  pop rdx
000074c3551d36a9  pop rcx
000074c3551d36aa  pop rax
000074c3551d36ab  add rsp, 0x08
000074c3551d36af  jmp 0x000074C3551CFF19
000074c3551d36b4  sub rsp, 0x08
000074c3551d36b8  push rax
000074c3551d36b9  push rcx
000074c3551d36ba  push rdx
000074c3551d36bb  push rdi
000074c3551d36bc  push rsi
000074c3551d36bd  push r8
000074c3551d36bf  push r9
000074c3551d36c1  push r10
000074c3551d36c3  push r11
000074c3551d36c5  sub rsp, 0xF0
000074c3551d36cc  vmovaps [rsp], xmm0
000074c3551d36d1  vmovaps [rsp+0x10], xmm1
000074c3551d36d7  vmovaps [rsp+0x20], xmm2
000074c3551d36dd  vmovaps [rsp+0x30], xmm3
000074c3551d36e3  vmovaps [rsp+0x40], xmm4
000074c3551d36e9  vmovaps [rsp+0x50], xmm5
000074c3551d36ef  vmovaps [rsp+0x60], xmm6
000074c3551d36f5  vmovaps [rsp+0x70], xmm7
000074c3551d36fb  vmovaps [rsp+0x80], xmm8
000074c3551d3704  vmovaps [rsp+0x90], xmm9
000074c3551d370d  vmovaps [rsp+0xA0], xmm10
000074c3551d3716  vmovaps [rsp+0xB0], xmm11
000074c3551d371f  vmovaps [rsp+0xC0], xmm13
000074c3551d3728  vmovaps [rsp+0xD0], xmm14
000074c3551d3731  vmovaps [rsp+0xE0], xmm15
000074c3551d373a  sub rsp, 0x30
000074c3551d373e  movaps [rsp], xmm12
000074c3551d3743  movaps [rsp+0x10], xmm15
000074c3551d3749  movaps [rsp+0x20], xmm13
000074c3551d374f  lea rdi, [rsp]
000074c3551d3753  mov esi, 0x00
000074c3551d3758  mov rax, 0x5F9407FA9530
000074c3551d3762  call rax
000074c3551d3764  movaps xmm12, [rsp]
000074c3551d3769  add rsp, 0x30
000074c3551d376d  vmovaps xmm0, [rsp]
000074c3551d3772  vmovaps xmm1, [rsp+0x10]
000074c3551d3778  vmovaps xmm2, [rsp+0x20]
000074c3551d377e  vmovaps xmm3, [rsp+0x30]
000074c3551d3784  vmovaps xmm4, [rsp+0x40]
000074c3551d378a  vmovaps xmm5, [rsp+0x50]
000074c3551d3790  vmovaps xmm6, [rsp+0x60]
000074c3551d3796  vmovaps xmm7, [rsp+0x70]
000074c3551d379c  vmovaps xmm8, [rsp+0x80]
000074c3551d37a5  vmovaps xmm9, [rsp+0x90]
000074c3551d37ae  vmovaps xmm10, [rsp+0xA0]
000074c3551d37b7  vmovaps xmm11, [rsp+0xB0]
000074c3551d37c0  vmovaps xmm13, [rsp+0xC0]
000074c3551d37c9  vmovaps xmm14, [rsp+0xD0]
000074c3551d37d2  vmovaps xmm15, [rsp+0xE0]
000074c3551d37db  add rsp, 0xF0
000074c3551d37e2  pop r11
000074c3551d37e4  pop r10
000074c3551d37e6  pop r9
000074c3551d37e8  pop r8
000074c3551d37ea  pop rsi
000074c3551d37eb  pop rdi
000074c3551d37ec  pop rdx
000074c3551d37ed  pop rcx
000074c3551d37ee  pop rax
000074c3551d37ef  add rsp, 0x08
000074c3551d37f3  jmp 0x000074C3551CFF34
000074c3551d37f8  sub rsp, 0x08
000074c3551d37fc  push rax
000074c3551d37fd  push rcx
000074c3551d37fe  push rdx
000074c3551d37ff  push rdi
000074c3551d3800  push rsi
000074c3551d3801  push r8
000074c3551d3803  push r9
000074c3551d3805  push r10
000074c3551d3807  push r11
000074c3551d3809  sub rsp, 0xF0
000074c3551d3810  vmovaps [rsp], xmm0
000074c3551d3815  vmovaps [rsp+0x10], xmm1
000074c3551d381b  vmovaps [rsp+0x20], xmm2
000074c3551d3821  vmovaps [rsp+0x30], xmm3
000074c3551d3827  vmovaps [rsp+0x40], xmm4
000074c3551d382d  vmovaps [rsp+0x50], xmm5
000074c3551d3833  vmovaps [rsp+0x60], xmm6
000074c3551d3839  vmovaps [rsp+0x70], xmm7
000074c3551d383f  vmovaps [rsp+0x80], xmm8
000074c3551d3848  vmovaps [rsp+0x90], xmm9
000074c3551d3851  vmovaps [rsp+0xA0], xmm10
000074c3551d385a  vmovaps [rsp+0xB0], xmm11
000074c3551d3863  vmovaps [rsp+0xC0], xmm12
000074c3551d386c  vmovaps [rsp+0xD0], xmm13
000074c3551d3875  vmovaps [rsp+0xE0], xmm14
000074c3551d387e  sub rsp, 0x30
000074c3551d3882  movaps [rsp], xmm15
000074c3551d3887  movaps [rsp+0x10], xmm13
000074c3551d388d  movaps [rsp+0x20], xmm10
000074c3551d3893  lea rdi, [rsp]
000074c3551d3897  mov esi, 0x00
000074c3551d389c  mov rax, 0x5F9407FA9530
000074c3551d38a6  call rax
000074c3551d38a8  movaps xmm15, [rsp]
000074c3551d38ad  add rsp, 0x30
000074c3551d38b1  vmovaps xmm0, [rsp]
000074c3551d38b6  vmovaps xmm1, [rsp+0x10]
000074c3551d38bc  vmovaps xmm2, [rsp+0x20]
000074c3551d38c2  vmovaps xmm3, [rsp+0x30]
000074c3551d38c8  vmovaps xmm4, [rsp+0x40]
000074c3551d38ce  vmovaps xmm5, [rsp+0x50]
000074c3551d38d4  vmovaps xmm6, [rsp+0x60]
000074c3551d38da  vmovaps xmm7, [rsp+0x70]
000074c3551d38e0  vmovaps xmm8, [rsp+0x80]
000074c3551d38e9  vmovaps xmm9, [rsp+0x90]
000074c3551d38f2  vmovaps xmm10, [rsp+0xA0]
000074c3551d38fb  vmovaps xmm11, [rsp+0xB0]
000074c3551d3904  vmovaps xmm12, [rsp+0xC0]
000074c3551d390d  vmovaps xmm13, [rsp+0xD0]
000074c3551d3916  vmovaps xmm14, [rsp+0xE0]
000074c3551d391f  add rsp, 0xF0
000074c3551d3926  pop r11
000074c3551d3928  pop r10
000074c3551d392a  pop r9
000074c3551d392c  pop r8
000074c3551d392e  pop rsi
000074c3551d392f  pop rdi
000074c3551d3930  pop rdx
000074c3551d3931  pop rcx
000074c3551d3932  pop rax
000074c3551d3933  add rsp, 0x08
000074c3551d3937  jmp 0x000074C3551CFF55
000074c3551d393c  call 0x000074C35500C260
000074c3551d3941  jmp 0x000074C3551CFFB0
000074c3551d3946  sub rsp, 0x08
000074c3551d394a  push rax
000074c3551d394b  push rcx
000074c3551d394c  push rdx
000074c3551d394d  push rdi
000074c3551d394e  push rsi
000074c3551d394f  push r8
000074c3551d3951  push r9
000074c3551d3953  push r10
000074c3551d3955  push r11
000074c3551d3957  sub rsp, 0xF0
000074c3551d395e  vmovaps [rsp], xmm0
000074c3551d3963  vmovaps [rsp+0x10], xmm1
000074c3551d3969  vmovaps [rsp+0x20], xmm2
000074c3551d396f  vmovaps [rsp+0x30], xmm3
000074c3551d3975  vmovaps [rsp+0x40], xmm4
000074c3551d397b  vmovaps [rsp+0x50], xmm5
000074c3551d3981  vmovaps [rsp+0x60], xmm6
000074c3551d3987  vmovaps [rsp+0x70], xmm7
000074c3551d398d  vmovaps [rsp+0x80], xmm8
000074c3551d3996  vmovaps [rsp+0x90], xmm10
000074c3551d399f  vmovaps [rsp+0xA0], xmm11
000074c3551d39a8  vmovaps [rsp+0xB0], xmm12
000074c3551d39b1  vmovaps [rsp+0xC0], xmm13
000074c3551d39ba  vmovaps [rsp+0xD0], xmm14
000074c3551d39c3  vmovaps [rsp+0xE0], xmm15
000074c3551d39cc  sub rsp, 0x30
000074c3551d39d0  movaps [rsp], xmm9
000074c3551d39d5  movaps [rsp+0x10], xmm8
000074c3551d39db  movaps [rsp+0x20], xmm10
000074c3551d39e1  lea rdi, [rsp]
000074c3551d39e5  mov esi, 0x00
000074c3551d39ea  mov rax, 0x5F9407FA9530
000074c3551d39f4  call rax
000074c3551d39f6  movaps xmm9, [rsp]
000074c3551d39fb  add rsp, 0x30
000074c3551d39ff  vmovaps xmm0, [rsp]
000074c3551d3a04  vmovaps xmm1, [rsp+0x10]
000074c3551d3a0a  vmovaps xmm2, [rsp+0x20]
000074c3551d3a10  vmovaps xmm3, [rsp+0x30]
000074c3551d3a16  vmovaps xmm4, [rsp+0x40]
000074c3551d3a1c  vmovaps xmm5, [rsp+0x50]
000074c3551d3a22  vmovaps xmm6, [rsp+0x60]
000074c3551d3a28  vmovaps xmm7, [rsp+0x70]
000074c3551d3a2e  vmovaps xmm8, [rsp+0x80]
000074c3551d3a37  vmovaps xmm10, [rsp+0x90]
000074c3551d3a40  vmovaps xmm11, [rsp+0xA0]
000074c3551d3a49  vmovaps xmm12, [rsp+0xB0]
000074c3551d3a52  vmovaps xmm13, [rsp+0xC0]
000074c3551d3a5b  vmovaps xmm14, [rsp+0xD0]
000074c3551d3a64  vmovaps xmm15, [rsp+0xE0]
000074c3551d3a6d  add rsp, 0xF0
000074c3551d3a74  pop r11
000074c3551d3a76  pop r10
000074c3551d3a78  pop r9
000074c3551d3a7a  pop r8
000074c3551d3a7c  pop rsi
000074c3551d3a7d  pop rdi
000074c3551d3a7e  pop rdx
000074c3551d3a7f  pop rcx
000074c3551d3a80  pop rax
000074c3551d3a81  add rsp, 0x08
000074c3551d3a85  jmp 0x000074C3551CFFE1
000074c3551d3a8a  sub rsp, 0x08
000074c3551d3a8e  push rax
000074c3551d3a8f  push rcx
000074c3551d3a90  push rdx
000074c3551d3a91  push rdi
000074c3551d3a92  push rsi
000074c3551d3a93  push r8
000074c3551d3a95  push r9
000074c3551d3a97  push r10
000074c3551d3a99  push r11
000074c3551d3a9b  sub rsp, 0xF0
000074c3551d3aa2  vmovaps [rsp], xmm0
000074c3551d3aa7  vmovaps [rsp+0x10], xmm1
000074c3551d3aad  vmovaps [rsp+0x20], xmm2
000074c3551d3ab3  vmovaps [rsp+0x30], xmm3
000074c3551d3ab9  vmovaps [rsp+0x40], xmm4
000074c3551d3abf  vmovaps [rsp+0x50], xmm5
000074c3551d3ac5  vmovaps [rsp+0x60], xmm6
000074c3551d3acb  vmovaps [rsp+0x70], xmm7
000074c3551d3ad1  vmovaps [rsp+0x80], xmm8
000074c3551d3ada  vmovaps [rsp+0x90], xmm9
000074c3551d3ae3  vmovaps [rsp+0xA0], xmm11
000074c3551d3aec  vmovaps [rsp+0xB0], xmm12
000074c3551d3af5  vmovaps [rsp+0xC0], xmm13
000074c3551d3afe  vmovaps [rsp+0xD0], xmm14
000074c3551d3b07  vmovaps [rsp+0xE0], xmm15
000074c3551d3b10  sub rsp, 0x30
000074c3551d3b14  movaps [rsp], xmm10
000074c3551d3b19  movaps [rsp+0x10], xmm1
000074c3551d3b1e  movaps [rsp+0x20], xmm11
000074c3551d3b24  lea rdi, [rsp]
000074c3551d3b28  mov esi, 0x00
000074c3551d3b2d  mov rax, 0x5F9407FA9530
000074c3551d3b37  call rax
000074c3551d3b39  movaps xmm10, [rsp]
000074c3551d3b3e  add rsp, 0x30
000074c3551d3b42  vmovaps xmm0, [rsp]
000074c3551d3b47  vmovaps xmm1, [rsp+0x10]
000074c3551d3b4d  vmovaps xmm2, [rsp+0x20]
000074c3551d3b53  vmovaps xmm3, [rsp+0x30]
000074c3551d3b59  vmovaps xmm4, [rsp+0x40]
000074c3551d3b5f  vmovaps xmm5, [rsp+0x50]
000074c3551d3b65  vmovaps xmm6, [rsp+0x60]
000074c3551d3b6b  vmovaps xmm7, [rsp+0x70]
000074c3551d3b71  vmovaps xmm8, [rsp+0x80]
000074c3551d3b7a  vmovaps xmm9, [rsp+0x90]
000074c3551d3b83  vmovaps xmm11, [rsp+0xA0]
000074c3551d3b8c  vmovaps xmm12, [rsp+0xB0]
000074c3551d3b95  vmovaps xmm13, [rsp+0xC0]
000074c3551d3b9e  vmovaps xmm14, [rsp+0xD0]
000074c3551d3ba7  vmovaps xmm15, [rsp+0xE0]
000074c3551d3bb0  add rsp, 0xF0
000074c3551d3bb7  pop r11
000074c3551d3bb9  pop r10
000074c3551d3bbb  pop r9
000074c3551d3bbd  pop r8
000074c3551d3bbf  pop rsi
000074c3551d3bc0  pop rdi
000074c3551d3bc1  pop rdx
000074c3551d3bc2  pop rcx
000074c3551d3bc3  pop rax
000074c3551d3bc4  add rsp, 0x08
000074c3551d3bc8  jmp 0x000074C3551CFFFC
000074c3551d3bcd  sub rsp, 0x08
000074c3551d3bd1  push rax
000074c3551d3bd2  push rcx
000074c3551d3bd3  push rdx
000074c3551d3bd4  push rdi
000074c3551d3bd5  push rsi
000074c3551d3bd6  push r8
000074c3551d3bd8  push r9
000074c3551d3bda  push r10
000074c3551d3bdc  push r11
000074c3551d3bde  sub rsp, 0xF0
000074c3551d3be5  vmovaps [rsp], xmm0
000074c3551d3bea  vmovaps [rsp+0x10], xmm2
000074c3551d3bf0  vmovaps [rsp+0x20], xmm3
000074c3551d3bf6  vmovaps [rsp+0x30], xmm4
000074c3551d3bfc  vmovaps [rsp+0x40], xmm5
000074c3551d3c02  vmovaps [rsp+0x50], xmm6
000074c3551d3c08  vmovaps [rsp+0x60], xmm7
000074c3551d3c0e  vmovaps [rsp+0x70], xmm8
000074c3551d3c14  vmovaps [rsp+0x80], xmm9
000074c3551d3c1d  vmovaps [rsp+0x90], xmm10
000074c3551d3c26  vmovaps [rsp+0xA0], xmm11
000074c3551d3c2f  vmovaps [rsp+0xB0], xmm12
000074c3551d3c38  vmovaps [rsp+0xC0], xmm13
000074c3551d3c41  vmovaps [rsp+0xD0], xmm14
000074c3551d3c4a  vmovaps [rsp+0xE0], xmm15
000074c3551d3c53  sub rsp, 0x30
000074c3551d3c57  movaps [rsp], xmm1
000074c3551d3c5b  movaps [rsp+0x10], xmm14
000074c3551d3c61  movaps [rsp+0x20], xmm6
000074c3551d3c66  lea rdi, [rsp]
000074c3551d3c6a  mov esi, 0x00
000074c3551d3c6f  mov rax, 0x5F9407FA9530
000074c3551d3c79  call rax
000074c3551d3c7b  movaps xmm1, [rsp]
000074c3551d3c7f  add rsp, 0x30
000074c3551d3c83  vmovaps xmm0, [rsp]
000074c3551d3c88  vmovaps xmm2, [rsp+0x10]
000074c3551d3c8e  vmovaps xmm3, [rsp+0x20]
000074c3551d3c94  vmovaps xmm4, [rsp+0x30]
000074c3551d3c9a  vmovaps xmm5, [rsp+0x40]
000074c3551d3ca0  vmovaps xmm6, [rsp+0x50]
000074c3551d3ca6  vmovaps xmm7, [rsp+0x60]
000074c3551d3cac  vmovaps xmm8, [rsp+0x70]
000074c3551d3cb2  vmovaps xmm9, [rsp+0x80]
000074c3551d3cbb  vmovaps xmm10, [rsp+0x90]
000074c3551d3cc4  vmovaps xmm11, [rsp+0xA0]
000074c3551d3ccd  vmovaps xmm12, [rsp+0xB0]
000074c3551d3cd6  vmovaps xmm13, [rsp+0xC0]
000074c3551d3cdf  vmovaps xmm14, [rsp+0xD0]
000074c3551d3ce8  vmovaps xmm15, [rsp+0xE0]
000074c3551d3cf1  add rsp, 0xF0
000074c3551d3cf8  pop r11
000074c3551d3cfa  pop r10
000074c3551d3cfc  pop r9
000074c3551d3cfe  pop r8
000074c3551d3d00  pop rsi
000074c3551d3d01  pop rdi
000074c3551d3d02  pop rdx
000074c3551d3d03  pop rcx
000074c3551d3d04  pop rax
000074c3551d3d05  add rsp, 0x08
000074c3551d3d09  jmp 0x000074C3551D0015
000074c3551d3d0e  sub rsp, 0x08
000074c3551d3d12  push rax
000074c3551d3d13  push rcx
000074c3551d3d14  push rdx
000074c3551d3d15  push rdi
000074c3551d3d16  push rsi
000074c3551d3d17  push r8
000074c3551d3d19  push r9
000074c3551d3d1b  push r10
000074c3551d3d1d  push r11
000074c3551d3d1f  sub rsp, 0xF0
000074c3551d3d26  vmovaps [rsp], xmm0
000074c3551d3d2b  vmovaps [rsp+0x10], xmm1
000074c3551d3d31  vmovaps [rsp+0x20], xmm2
000074c3551d3d37  vmovaps [rsp+0x30], xmm3
000074c3551d3d3d  vmovaps [rsp+0x40], xmm4
000074c3551d3d43  vmovaps [rsp+0x50], xmm5
000074c3551d3d49  vmovaps [rsp+0x60], xmm6
000074c3551d3d4f  vmovaps [rsp+0x70], xmm7
000074c3551d3d55  vmovaps [rsp+0x80], xmm8
000074c3551d3d5e  vmovaps [rsp+0x90], xmm9
000074c3551d3d67  vmovaps [rsp+0xA0], xmm10
000074c3551d3d70  vmovaps [rsp+0xB0], xmm12
000074c3551d3d79  vmovaps [rsp+0xC0], xmm13
000074c3551d3d82  vmovaps [rsp+0xD0], xmm14
000074c3551d3d8b  vmovaps [rsp+0xE0], xmm15
000074c3551d3d94  sub rsp, 0x30
000074c3551d3d98  movaps [rsp], xmm11
000074c3551d3d9d  movaps [rsp+0x10], xmm13
000074c3551d3da3  movaps [rsp+0x20], xmm14
000074c3551d3da9  lea rdi, [rsp]
000074c3551d3dad  mov esi, 0x00
000074c3551d3db2  mov rax, 0x5F9407FA9530
000074c3551d3dbc  call rax
000074c3551d3dbe  movaps xmm11, [rsp]
000074c3551d3dc3  add rsp, 0x30
000074c3551d3dc7  vmovaps xmm0, [rsp]
000074c3551d3dcc  vmovaps xmm1, [rsp+0x10]
000074c3551d3dd2  vmovaps xmm2, [rsp+0x20]
000074c3551d3dd8  vmovaps xmm3, [rsp+0x30]
000074c3551d3dde  vmovaps xmm4, [rsp+0x40]
000074c3551d3de4  vmovaps xmm5, [rsp+0x50]
000074c3551d3dea  vmovaps xmm6, [rsp+0x60]
000074c3551d3df0  vmovaps xmm7, [rsp+0x70]
000074c3551d3df6  vmovaps xmm8, [rsp+0x80]
000074c3551d3dff  vmovaps xmm9, [rsp+0x90]
000074c3551d3e08  vmovaps xmm10, [rsp+0xA0]
000074c3551d3e11  vmovaps xmm12, [rsp+0xB0]
000074c3551d3e1a  vmovaps xmm13, [rsp+0xC0]
000074c3551d3e23  vmovaps xmm14, [rsp+0xD0]
000074c3551d3e2c  vmovaps xmm15, [rsp+0xE0]
000074c3551d3e35  add rsp, 0xF0
000074c3551d3e3c  pop r11
000074c3551d3e3e  pop r10
000074c3551d3e40  pop r9
000074c3551d3e42  pop r8
000074c3551d3e44  pop rsi
000074c3551d3e45  pop rdi
000074c3551d3e46  pop rdx
000074c3551d3e47  pop rcx
000074c3551d3e48  pop rax
000074c3551d3e49  add rsp, 0x08
000074c3551d3e4d  jmp 0x000074C3551D003F
000074c3551d3e52  sub rsp, 0x08
000074c3551d3e56  push rax
000074c3551d3e57  push rcx
000074c3551d3e58  push rdx
000074c3551d3e59  push rdi
000074c3551d3e5a  push rsi
000074c3551d3e5b  push r8
000074c3551d3e5d  push r9
000074c3551d3e5f  push r10
000074c3551d3e61  push r11
000074c3551d3e63  sub rsp, 0xF0
000074c3551d3e6a  vmovaps [rsp], xmm0
000074c3551d3e6f  vmovaps [rsp+0x10], xmm1
000074c3551d3e75  vmovaps [rsp+0x20], xmm2
000074c3551d3e7b  vmovaps [rsp+0x30], xmm3
000074c3551d3e81  vmovaps [rsp+0x40], xmm4
000074c3551d3e87  vmovaps [rsp+0x50], xmm5
000074c3551d3e8d  vmovaps [rsp+0x60], xmm6
000074c3551d3e93  vmovaps [rsp+0x70], xmm7
000074c3551d3e99  vmovaps [rsp+0x80], xmm8
000074c3551d3ea2  vmovaps [rsp+0x90], xmm9
000074c3551d3eab  vmovaps [rsp+0xA0], xmm10
000074c3551d3eb4  vmovaps [rsp+0xB0], xmm11
000074c3551d3ebd  vmovaps [rsp+0xC0], xmm12
000074c3551d3ec6  vmovaps [rsp+0xD0], xmm14
000074c3551d3ecf  vmovaps [rsp+0xE0], xmm15
000074c3551d3ed8  sub rsp, 0x30
000074c3551d3edc  movaps [rsp], xmm13
000074c3551d3ee1  movaps [rsp+0x10], xmm8
000074c3551d3ee7  movaps [rsp+0x20], xmm14
000074c3551d3eed  lea rdi, [rsp]
000074c3551d3ef1  mov esi, 0x00
000074c3551d3ef6  mov rax, 0x5F9407FA9530
000074c3551d3f00  call rax
000074c3551d3f02  movaps xmm13, [rsp]
000074c3551d3f07  add rsp, 0x30
000074c3551d3f0b  vmovaps xmm0, [rsp]
000074c3551d3f10  vmovaps xmm1, [rsp+0x10]
000074c3551d3f16  vmovaps xmm2, [rsp+0x20]
000074c3551d3f1c  vmovaps xmm3, [rsp+0x30]
000074c3551d3f22  vmovaps xmm4, [rsp+0x40]
000074c3551d3f28  vmovaps xmm5, [rsp+0x50]
000074c3551d3f2e  vmovaps xmm6, [rsp+0x60]
000074c3551d3f34  vmovaps xmm7, [rsp+0x70]
000074c3551d3f3a  vmovaps xmm8, [rsp+0x80]
000074c3551d3f43  vmovaps xmm9, [rsp+0x90]
000074c3551d3f4c  vmovaps xmm10, [rsp+0xA0]
000074c3551d3f55  vmovaps xmm11, [rsp+0xB0]
000074c3551d3f5e  vmovaps xmm12, [rsp+0xC0]
000074c3551d3f67  vmovaps xmm14, [rsp+0xD0]
000074c3551d3f70  vmovaps xmm15, [rsp+0xE0]
000074c3551d3f79  add rsp, 0xF0
000074c3551d3f80  pop r11
000074c3551d3f82  pop r10
000074c3551d3f84  pop r9
000074c3551d3f86  pop r8
000074c3551d3f88  pop rsi
000074c3551d3f89  pop rdi
000074c3551d3f8a  pop rdx
000074c3551d3f8b  pop rcx
000074c3551d3f8c  pop rax
000074c3551d3f8d  add rsp, 0x08
000074c3551d3f91  jmp 0x000074C3551D006E
000074c3551d3f96  sub rsp, 0x08
000074c3551d3f9a  push rax
000074c3551d3f9b  push rcx
000074c3551d3f9c  push rdx
000074c3551d3f9d  push rdi
000074c3551d3f9e  push rsi
000074c3551d3f9f  push r8
000074c3551d3fa1  push r9
000074c3551d3fa3  push r10
000074c3551d3fa5  push r11
000074c3551d3fa7  sub rsp, 0xF0
000074c3551d3fae  vmovaps [rsp], xmm0
000074c3551d3fb3  vmovaps [rsp+0x10], xmm1
000074c3551d3fb9  vmovaps [rsp+0x20], xmm2
000074c3551d3fbf  vmovaps [rsp+0x30], xmm3
000074c3551d3fc5  vmovaps [rsp+0x40], xmm4
000074c3551d3fcb  vmovaps [rsp+0x50], xmm5
000074c3551d3fd1  vmovaps [rsp+0x60], xmm6
000074c3551d3fd7  vmovaps [rsp+0x70], xmm7
000074c3551d3fdd  vmovaps [rsp+0x80], xmm9
000074c3551d3fe6  vmovaps [rsp+0x90], xmm10
000074c3551d3fef  vmovaps [rsp+0xA0], xmm11
000074c3551d3ff8  vmovaps [rsp+0xB0], xmm12
000074c3551d4001  vmovaps [rsp+0xC0], xmm13
000074c3551d400a  vmovaps [rsp+0xD0], xmm14
000074c3551d4013  vmovaps [rsp+0xE0], xmm15
000074c3551d401c  sub rsp, 0x30
000074c3551d4020  movaps [rsp], xmm8
000074c3551d4025  movaps [rsp+0x10], xmm7
000074c3551d402a  movaps [rsp+0x20], xmm14
000074c3551d4030  lea rdi, [rsp]
000074c3551d4034  mov esi, 0x00
000074c3551d4039  mov rax, 0x5F9407FA9530
000074c3551d4043  call rax
000074c3551d4045  movaps xmm8, [rsp]
000074c3551d404a  add rsp, 0x30
000074c3551d404e  vmovaps xmm0, [rsp]
000074c3551d4053  vmovaps xmm1, [rsp+0x10]
000074c3551d4059  vmovaps xmm2, [rsp+0x20]
000074c3551d405f  vmovaps xmm3, [rsp+0x30]
000074c3551d4065  vmovaps xmm4, [rsp+0x40]
000074c3551d406b  vmovaps xmm5, [rsp+0x50]
000074c3551d4071  vmovaps xmm6, [rsp+0x60]
000074c3551d4077  vmovaps xmm7, [rsp+0x70]
000074c3551d407d  vmovaps xmm9, [rsp+0x80]
000074c3551d4086  vmovaps xmm10, [rsp+0x90]
000074c3551d408f  vmovaps xmm11, [rsp+0xA0]
000074c3551d4098  vmovaps xmm12, [rsp+0xB0]
000074c3551d40a1  vmovaps xmm13, [rsp+0xC0]
000074c3551d40aa  vmovaps xmm14, [rsp+0xD0]
000074c3551d40b3  vmovaps xmm15, [rsp+0xE0]
000074c3551d40bc  add rsp, 0xF0
000074c3551d40c3  pop r11
000074c3551d40c5  pop r10
000074c3551d40c7  pop r9
000074c3551d40c9  pop r8
000074c3551d40cb  pop rsi
000074c3551d40cc  pop rdi
000074c3551d40cd  pop rdx
000074c3551d40ce  pop rcx
000074c3551d40cf  pop rax
000074c3551d40d0  add rsp, 0x08
000074c3551d40d4  jmp 0x000074C3551D0094
000074c3551d40d9  sub rsp, 0x08
000074c3551d40dd  push rax
000074c3551d40de  push rcx
000074c3551d40df  push rdx
000074c3551d40e0  push rdi
000074c3551d40e1  push rsi
000074c3551d40e2  push r8
000074c3551d40e4  push r9
000074c3551d40e6  push r10
000074c3551d40e8  push r11
000074c3551d40ea  sub rsp, 0xF0
000074c3551d40f1  vmovaps [rsp], xmm0
000074c3551d40f6  vmovaps [rsp+0x10], xmm1
000074c3551d40fc  vmovaps [rsp+0x20], xmm2
000074c3551d4102  vmovaps [rsp+0x30], xmm3
000074c3551d4108  vmovaps [rsp+0x40], xmm4
000074c3551d410e  vmovaps [rsp+0x50], xmm5
000074c3551d4114  vmovaps [rsp+0x60], xmm6
000074c3551d411a  vmovaps [rsp+0x70], xmm7
000074c3551d4120  vmovaps [rsp+0x80], xmm8
000074c3551d4129  vmovaps [rsp+0x90], xmm9
000074c3551d4132  vmovaps [rsp+0xA0], xmm10
000074c3551d413b  vmovaps [rsp+0xB0], xmm11
000074c3551d4144  vmovaps [rsp+0xC0], xmm12
000074c3551d414d  vmovaps [rsp+0xD0], xmm13
000074c3551d4156  vmovaps [rsp+0xE0], xmm15
000074c3551d415f  sub rsp, 0x30
000074c3551d4163  movaps [rsp], xmm14
000074c3551d4168  movaps [rsp+0x10], xmm12
000074c3551d416e  movaps [rsp+0x20], xmm9
000074c3551d4174  lea rdi, [rsp]
000074c3551d4178  mov esi, 0x00
000074c3551d417d  mov rax, 0x5F9407FA9530
000074c3551d4187  call rax
000074c3551d4189  movaps xmm14, [rsp]
000074c3551d418e  add rsp, 0x30
000074c3551d4192  vmovaps xmm0, [rsp]
000074c3551d4197  vmovaps xmm1, [rsp+0x10]
000074c3551d419d  vmovaps xmm2, [rsp+0x20]
000074c3551d41a3  vmovaps xmm3, [rsp+0x30]
000074c3551d41a9  vmovaps xmm4, [rsp+0x40]
000074c3551d41af  vmovaps xmm5, [rsp+0x50]
000074c3551d41b5  vmovaps xmm6, [rsp+0x60]
000074c3551d41bb  vmovaps xmm7, [rsp+0x70]
000074c3551d41c1  vmovaps xmm8, [rsp+0x80]
000074c3551d41ca  vmovaps xmm9, [rsp+0x90]
000074c3551d41d3  vmovaps xmm10, [rsp+0xA0]
000074c3551d41dc  vmovaps xmm11, [rsp+0xB0]
000074c3551d41e5  vmovaps xmm12, [rsp+0xC0]
000074c3551d41ee  vmovaps xmm13, [rsp+0xD0]
000074c3551d41f7  vmovaps xmm15, [rsp+0xE0]
000074c3551d4200  add rsp, 0xF0
000074c3551d4207  pop r11
000074c3551d4209  pop r10
000074c3551d420b  pop r9
000074c3551d420d  pop r8
000074c3551d420f  pop rsi
000074c3551d4210  pop rdi
000074c3551d4211  pop rdx
000074c3551d4212  pop rcx
000074c3551d4213  pop rax
000074c3551d4214  add rsp, 0x08
000074c3551d4218  jmp 0x000074C3551D00AE
000074c3551d421d  sub rsp, 0x08
000074c3551d4221  push rax
000074c3551d4222  push rcx
000074c3551d4223  push rdx
000074c3551d4224  push rdi
000074c3551d4225  push rsi
000074c3551d4226  push r8
000074c3551d4228  push r9
000074c3551d422a  push r10
000074c3551d422c  push r11
000074c3551d422e  sub rsp, 0xF0
000074c3551d4235  vmovaps [rsp], xmm0
000074c3551d423a  vmovaps [rsp+0x10], xmm1
000074c3551d4240  vmovaps [rsp+0x20], xmm2
000074c3551d4246  vmovaps [rsp+0x30], xmm3
000074c3551d424c  vmovaps [rsp+0x40], xmm4
000074c3551d4252  vmovaps [rsp+0x50], xmm5
000074c3551d4258  vmovaps [rsp+0x60], xmm6
000074c3551d425e  vmovaps [rsp+0x70], xmm7
000074c3551d4264  vmovaps [rsp+0x80], xmm8
000074c3551d426d  vmovaps [rsp+0x90], xmm10
000074c3551d4276  vmovaps [rsp+0xA0], xmm11
000074c3551d427f  vmovaps [rsp+0xB0], xmm12
000074c3551d4288  vmovaps [rsp+0xC0], xmm13
000074c3551d4291  vmovaps [rsp+0xD0], xmm14
000074c3551d429a  vmovaps [rsp+0xE0], xmm15
000074c3551d42a3  sub rsp, 0x30
000074c3551d42a7  movaps [rsp], xmm9
000074c3551d42ac  movaps [rsp+0x10], xmm7
000074c3551d42b1  movaps [rsp+0x20], xmm12
000074c3551d42b7  lea rdi, [rsp]
000074c3551d42bb  mov esi, 0x00
000074c3551d42c0  mov rax, 0x5F9407FA9530
000074c3551d42ca  call rax
000074c3551d42cc  movaps xmm9, [rsp]
000074c3551d42d1  add rsp, 0x30
000074c3551d42d5  vmovaps xmm0, [rsp]
000074c3551d42da  vmovaps xmm1, [rsp+0x10]
000074c3551d42e0  vmovaps xmm2, [rsp+0x20]
000074c3551d42e6  vmovaps xmm3, [rsp+0x30]
000074c3551d42ec  vmovaps xmm4, [rsp+0x40]
000074c3551d42f2  vmovaps xmm5, [rsp+0x50]
000074c3551d42f8  vmovaps xmm6, [rsp+0x60]
000074c3551d42fe  vmovaps xmm7, [rsp+0x70]
000074c3551d4304  vmovaps xmm8, [rsp+0x80]
000074c3551d430d  vmovaps xmm10, [rsp+0x90]
000074c3551d4316  vmovaps xmm11, [rsp+0xA0]
000074c3551d431f  vmovaps xmm12, [rsp+0xB0]
000074c3551d4328  vmovaps xmm13, [rsp+0xC0]
000074c3551d4331  vmovaps xmm14, [rsp+0xD0]
000074c3551d433a  vmovaps xmm15, [rsp+0xE0]
000074c3551d4343  add rsp, 0xF0
000074c3551d434a  pop r11
000074c3551d434c  pop r10
000074c3551d434e  pop r9
000074c3551d4350  pop r8
000074c3551d4352  pop rsi
000074c3551d4353  pop rdi
000074c3551d4354  pop rdx
000074c3551d4355  pop rcx
000074c3551d4356  pop rax
000074c3551d4357  add rsp, 0x08
000074c3551d435b  jmp 0x000074C3551D00DD
000074c3551d4360  sub rsp, 0x08
000074c3551d4364  push rax
000074c3551d4365  push rcx
000074c3551d4366  push rdx
000074c3551d4367  push rdi
000074c3551d4368  push rsi
000074c3551d4369  push r8
000074c3551d436b  push r9
000074c3551d436d  push r10
000074c3551d436f  push r11
000074c3551d4371  sub rsp, 0xF0
000074c3551d4378  vmovaps [rsp], xmm0
000074c3551d437d  vmovaps [rsp+0x10], xmm1
000074c3551d4383  vmovaps [rsp+0x20], xmm2
000074c3551d4389  vmovaps [rsp+0x30], xmm3
000074c3551d438f  vmovaps [rsp+0x40], xmm4
000074c3551d4395  vmovaps [rsp+0x50], xmm5
000074c3551d439b  vmovaps [rsp+0x60], xmm6
000074c3551d43a1  vmovaps [rsp+0x70], xmm7
000074c3551d43a7  vmovaps [rsp+0x80], xmm8
000074c3551d43b0  vmovaps [rsp+0x90], xmm9
000074c3551d43b9  vmovaps [rsp+0xA0], xmm10
000074c3551d43c2  vmovaps [rsp+0xB0], xmm11
000074c3551d43cb  vmovaps [rsp+0xC0], xmm13
000074c3551d43d4  vmovaps [rsp+0xD0], xmm14
000074c3551d43dd  vmovaps [rsp+0xE0], xmm15
000074c3551d43e6  sub rsp, 0x30
000074c3551d43ea  movaps [rsp], xmm12
000074c3551d43ef  movaps [rsp+0x10], xmm15
000074c3551d43f5  movaps [rsp+0x20], xmm11
000074c3551d43fb  lea rdi, [rsp]
000074c3551d43ff  mov esi, 0x00
000074c3551d4404  mov rax, 0x5F9407FA9530
000074c3551d440e  call rax
000074c3551d4410  movaps xmm12, [rsp]
000074c3551d4415  add rsp, 0x30
000074c3551d4419  vmovaps xmm0, [rsp]
000074c3551d441e  vmovaps xmm1, [rsp+0x10]
000074c3551d4424  vmovaps xmm2, [rsp+0x20]
000074c3551d442a  vmovaps xmm3, [rsp+0x30]
000074c3551d4430  vmovaps xmm4, [rsp+0x40]
000074c3551d4436  vmovaps xmm5, [rsp+0x50]
000074c3551d443c  vmovaps xmm6, [rsp+0x60]
000074c3551d4442  vmovaps xmm7, [rsp+0x70]
000074c3551d4448  vmovaps xmm8, [rsp+0x80]
000074c3551d4451  vmovaps xmm9, [rsp+0x90]
000074c3551d445a  vmovaps xmm10, [rsp+0xA0]
000074c3551d4463  vmovaps xmm11, [rsp+0xB0]
000074c3551d446c  vmovaps xmm13, [rsp+0xC0]
000074c3551d4475  vmovaps xmm14, [rsp+0xD0]
000074c3551d447e  vmovaps xmm15, [rsp+0xE0]
000074c3551d4487  add rsp, 0xF0
000074c3551d448e  pop r11
000074c3551d4490  pop r10
000074c3551d4492  pop r9
000074c3551d4494  pop r8
000074c3551d4496  pop rsi
000074c3551d4497  pop rdi
000074c3551d4498  pop rdx
000074c3551d4499  pop rcx
000074c3551d449a  pop rax
000074c3551d449b  add rsp, 0x08
000074c3551d449f  jmp 0x000074C3551D00F7
000074c3551d44a4  sub rsp, 0x08
000074c3551d44a8  push rax
000074c3551d44a9  push rcx
000074c3551d44aa  push rdx
000074c3551d44ab  push rdi
000074c3551d44ac  push rsi
000074c3551d44ad  push r8
000074c3551d44af  push r9
000074c3551d44b1  push r10
000074c3551d44b3  push r11
000074c3551d44b5  sub rsp, 0xF0
000074c3551d44bc  vmovaps [rsp], xmm0
000074c3551d44c1  vmovaps [rsp+0x10], xmm1
000074c3551d44c7  vmovaps [rsp+0x20], xmm2
000074c3551d44cd  vmovaps [rsp+0x30], xmm3
000074c3551d44d3  vmovaps [rsp+0x40], xmm4
000074c3551d44d9  vmovaps [rsp+0x50], xmm5
000074c3551d44df  vmovaps [rsp+0x60], xmm6
000074c3551d44e5  vmovaps [rsp+0x70], xmm7
000074c3551d44eb  vmovaps [rsp+0x80], xmm8
000074c3551d44f4  vmovaps [rsp+0x90], xmm9
000074c3551d44fd  vmovaps [rsp+0xA0], xmm10
000074c3551d4506  vmovaps [rsp+0xB0], xmm12
000074c3551d450f  vmovaps [rsp+0xC0], xmm13
000074c3551d4518  vmovaps [rsp+0xD0], xmm14
000074c3551d4521  vmovaps [rsp+0xE0], xmm15
000074c3551d452a  sub rsp, 0x30
000074c3551d452e  movaps [rsp], xmm11
000074c3551d4533  movaps [rsp+0x10], xmm7
000074c3551d4538  movaps [rsp+0x20], xmm15
000074c3551d453e  lea rdi, [rsp]
000074c3551d4542  mov esi, 0x00
000074c3551d4547  mov rax, 0x5F9407FA9530
000074c3551d4551  call rax
000074c3551d4553  movaps xmm11, [rsp]
000074c3551d4558  add rsp, 0x30
000074c3551d455c  vmovaps xmm0, [rsp]
000074c3551d4561  vmovaps xmm1, [rsp+0x10]
000074c3551d4567  vmovaps xmm2, [rsp+0x20]
000074c3551d456d  vmovaps xmm3, [rsp+0x30]
000074c3551d4573  vmovaps xmm4, [rsp+0x40]
000074c3551d4579  vmovaps xmm5, [rsp+0x50]
000074c3551d457f  vmovaps xmm6, [rsp+0x60]
000074c3551d4585  vmovaps xmm7, [rsp+0x70]
000074c3551d458b  vmovaps xmm8, [rsp+0x80]
000074c3551d4594  vmovaps xmm9, [rsp+0x90]
000074c3551d459d  vmovaps xmm10, [rsp+0xA0]
000074c3551d45a6  vmovaps xmm12, [rsp+0xB0]
000074c3551d45af  vmovaps xmm13, [rsp+0xC0]
000074c3551d45b8  vmovaps xmm14, [rsp+0xD0]
000074c3551d45c1  vmovaps xmm15, [rsp+0xE0]
000074c3551d45ca  add rsp, 0xF0
000074c3551d45d1  pop r11
000074c3551d45d3  pop r10
000074c3551d45d5  pop r9
000074c3551d45d7  pop r8
000074c3551d45d9  pop rsi
000074c3551d45da  pop rdi
000074c3551d45db  pop rdx
000074c3551d45dc  pop rcx
000074c3551d45dd  pop rax
000074c3551d45de  add rsp, 0x08
000074c3551d45e2  jmp 0x000074C3551D0123
000074c3551d45e7  sub rsp, 0x08
000074c3551d45eb  push rax
000074c3551d45ec  push rcx
000074c3551d45ed  push rdx
000074c3551d45ee  push rdi
000074c3551d45ef  push rsi
000074c3551d45f0  push r8
000074c3551d45f2  push r9
000074c3551d45f4  push r10
000074c3551d45f6  push r11
000074c3551d45f8  sub rsp, 0xF0
000074c3551d45ff  vmovaps [rsp], xmm0
000074c3551d4604  vmovaps [rsp+0x10], xmm1
000074c3551d460a  vmovaps [rsp+0x20], xmm2
000074c3551d4610  vmovaps [rsp+0x30], xmm3
000074c3551d4616  vmovaps [rsp+0x40], xmm4
000074c3551d461c  vmovaps [rsp+0x50], xmm5
000074c3551d4622  vmovaps [rsp+0x60], xmm6
000074c3551d4628  vmovaps [rsp+0x70], xmm7
000074c3551d462e  vmovaps [rsp+0x80], xmm8
000074c3551d4637  vmovaps [rsp+0x90], xmm9
000074c3551d4640  vmovaps [rsp+0xA0], xmm10
000074c3551d4649  vmovaps [rsp+0xB0], xmm11
000074c3551d4652  vmovaps [rsp+0xC0], xmm12
000074c3551d465b  vmovaps [rsp+0xD0], xmm13
000074c3551d4664  vmovaps [rsp+0xE0], xmm14
000074c3551d466d  sub rsp, 0x30
000074c3551d4671  movaps [rsp], xmm15
000074c3551d4676  movaps [rsp+0x10], xmm10
000074c3551d467c  movaps [rsp+0x20], xmm13
000074c3551d4682  lea rdi, [rsp]
000074c3551d4686  mov esi, 0x00
000074c3551d468b  mov rax, 0x5F9407FA9530
000074c3551d4695  call rax
000074c3551d4697  movaps xmm15, [rsp]
000074c3551d469c  add rsp, 0x30
000074c3551d46a0  vmovaps xmm0, [rsp]
000074c3551d46a5  vmovaps xmm1, [rsp+0x10]
000074c3551d46ab  vmovaps xmm2, [rsp+0x20]
000074c3551d46b1  vmovaps xmm3, [rsp+0x30]
000074c3551d46b7  vmovaps xmm4, [rsp+0x40]
000074c3551d46bd  vmovaps xmm5, [rsp+0x50]
000074c3551d46c3  vmovaps xmm6, [rsp+0x60]
000074c3551d46c9  vmovaps xmm7, [rsp+0x70]
000074c3551d46cf  vmovaps xmm8, [rsp+0x80]
000074c3551d46d8  vmovaps xmm9, [rsp+0x90]
000074c3551d46e1  vmovaps xmm10, [rsp+0xA0]
000074c3551d46ea  vmovaps xmm11, [rsp+0xB0]
000074c3551d46f3  vmovaps xmm12, [rsp+0xC0]
000074c3551d46fc  vmovaps xmm13, [rsp+0xD0]
000074c3551d4705  vmovaps xmm14, [rsp+0xE0]
000074c3551d470e  add rsp, 0xF0
000074c3551d4715  pop r11
000074c3551d4717  pop r10
000074c3551d4719  pop r9
000074c3551d471b  pop r8
000074c3551d471d  pop rsi
000074c3551d471e  pop rdi
000074c3551d471f  pop rdx
000074c3551d4720  pop rcx
000074c3551d4721  pop rax
000074c3551d4722  add rsp, 0x08
000074c3551d4726  jmp 0x000074C3551D013D
000074c3551d472b  sub rsp, 0x08
000074c3551d472f  push rax
000074c3551d4730  push rcx
000074c3551d4731  push rdx
000074c3551d4732  push rdi
000074c3551d4733  push rsi
000074c3551d4734  push r8
000074c3551d4736  push r9
000074c3551d4738  push r10
000074c3551d473a  push r11
000074c3551d473c  sub rsp, 0xF0
000074c3551d4743  vmovaps [rsp], xmm0
000074c3551d4748  vmovaps [rsp+0x10], xmm1
000074c3551d474e  vmovaps [rsp+0x20], xmm2
000074c3551d4754  vmovaps [rsp+0x30], xmm3
000074c3551d475a  vmovaps [rsp+0x40], xmm4
000074c3551d4760  vmovaps [rsp+0x50], xmm5
000074c3551d4766  vmovaps [rsp+0x60], xmm6
000074c3551d476c  vmovaps [rsp+0x70], xmm7
000074c3551d4772  vmovaps [rsp+0x80], xmm8
000074c3551d477b  vmovaps [rsp+0x90], xmm9
000074c3551d4784  vmovaps [rsp+0xA0], xmm11
000074c3551d478d  vmovaps [rsp+0xB0], xmm12
000074c3551d4796  vmovaps [rsp+0xC0], xmm13
000074c3551d479f  vmovaps [rsp+0xD0], xmm14
000074c3551d47a8  vmovaps [rsp+0xE0], xmm15
000074c3551d47b1  sub rsp, 0x30
000074c3551d47b5  movaps [rsp], xmm10
000074c3551d47ba  movaps [rsp+0x10], xmm7
000074c3551d47bf  movaps [rsp+0x20], xmm13
000074c3551d47c5  lea rdi, [rsp]
000074c3551d47c9  mov esi, 0x00
000074c3551d47ce  mov rax, 0x5F9407FA9530
000074c3551d47d8  call rax
000074c3551d47da  movaps xmm10, [rsp]
000074c3551d47df  add rsp, 0x30
000074c3551d47e3  vmovaps xmm0, [rsp]
000074c3551d47e8  vmovaps xmm1, [rsp+0x10]
000074c3551d47ee  vmovaps xmm2, [rsp+0x20]
000074c3551d47f4  vmovaps xmm3, [rsp+0x30]
000074c3551d47fa  vmovaps xmm4, [rsp+0x40]
000074c3551d4800  vmovaps xmm5, [rsp+0x50]
000074c3551d4806  vmovaps xmm6, [rsp+0x60]
000074c3551d480c  vmovaps xmm7, [rsp+0x70]
000074c3551d4812  vmovaps xmm8, [rsp+0x80]
000074c3551d481b  vmovaps xmm9, [rsp+0x90]
000074c3551d4824  vmovaps xmm11, [rsp+0xA0]
000074c3551d482d  vmovaps xmm12, [rsp+0xB0]
000074c3551d4836  vmovaps xmm13, [rsp+0xC0]
000074c3551d483f  vmovaps xmm14, [rsp+0xD0]
000074c3551d4848  vmovaps xmm15, [rsp+0xE0]
000074c3551d4851  add rsp, 0xF0
000074c3551d4858  pop r11
000074c3551d485a  pop r10
000074c3551d485c  pop r9
000074c3551d485e  pop r8
000074c3551d4860  pop rsi
000074c3551d4861  pop rdi
000074c3551d4862  pop rdx
000074c3551d4863  pop rcx
000074c3551d4864  pop rax
000074c3551d4865  add rsp, 0x08
000074c3551d4869  jmp 0x000074C3551D0169
000074c3551d486e  sub rsp, 0x08
000074c3551d4872  push rax
000074c3551d4873  push rcx
000074c3551d4874  push rdx
000074c3551d4875  push rdi
000074c3551d4876  push rsi
000074c3551d4877  push r8
000074c3551d4879  push r9
000074c3551d487b  push r10
000074c3551d487d  push r11
000074c3551d487f  sub rsp, 0xF0
000074c3551d4886  vmovaps [rsp], xmm0
000074c3551d488b  vmovaps [rsp+0x10], xmm1
000074c3551d4891  vmovaps [rsp+0x20], xmm2
000074c3551d4897  vmovaps [rsp+0x30], xmm3
000074c3551d489d  vmovaps [rsp+0x40], xmm4
000074c3551d48a3  vmovaps [rsp+0x50], xmm5
000074c3551d48a9  vmovaps [rsp+0x60], xmm6
000074c3551d48af  vmovaps [rsp+0x70], xmm7
000074c3551d48b5  vmovaps [rsp+0x80], xmm8
000074c3551d48be  vmovaps [rsp+0x90], xmm9
000074c3551d48c7  vmovaps [rsp+0xA0], xmm10
000074c3551d48d0  vmovaps [rsp+0xB0], xmm11
000074c3551d48d9  vmovaps [rsp+0xC0], xmm12
000074c3551d48e2  vmovaps [rsp+0xD0], xmm14
000074c3551d48eb  vmovaps [rsp+0xE0], xmm15
000074c3551d48f4  sub rsp, 0x30
000074c3551d48f8  movaps [rsp], xmm13
000074c3551d48fd  movaps [rsp+0x10], xmm1
000074c3551d4902  movaps [rsp+0x20], xmm8
000074c3551d4908  lea rdi, [rsp]
000074c3551d490c  mov esi, 0x00
000074c3551d4911  mov rax, 0x5F9407FA9530
000074c3551d491b  call rax
000074c3551d491d  movaps xmm13, [rsp]
000074c3551d4922  add rsp, 0x30
000074c3551d4926  vmovaps xmm0, [rsp]
000074c3551d492b  vmovaps xmm1, [rsp+0x10]
000074c3551d4931  vmovaps xmm2, [rsp+0x20]
000074c3551d4937  vmovaps xmm3, [rsp+0x30]
000074c3551d493d  vmovaps xmm4, [rsp+0x40]
000074c3551d4943  vmovaps xmm5, [rsp+0x50]
000074c3551d4949  vmovaps xmm6, [rsp+0x60]
000074c3551d494f  vmovaps xmm7, [rsp+0x70]
000074c3551d4955  vmovaps xmm8, [rsp+0x80]
000074c3551d495e  vmovaps xmm9, [rsp+0x90]
000074c3551d4967  vmovaps xmm10, [rsp+0xA0]
000074c3551d4970  vmovaps xmm11, [rsp+0xB0]
000074c3551d4979  vmovaps xmm12, [rsp+0xC0]
000074c3551d4982  vmovaps xmm14, [rsp+0xD0]
000074c3551d498b  vmovaps xmm15, [rsp+0xE0]
000074c3551d4994  add rsp, 0xF0
000074c3551d499b  pop r11
000074c3551d499d  pop r10
000074c3551d499f  pop r9
000074c3551d49a1  pop r8
000074c3551d49a3  pop rsi
000074c3551d49a4  pop rdi
000074c3551d49a5  pop rdx
000074c3551d49a6  pop rcx
000074c3551d49a7  pop rax
000074c3551d49a8  add rsp, 0x08
000074c3551d49ac  jmp 0x000074C3551D0183
000074c3551d49b1  call 0x000074C354FFF430
000074c3551d49b6  jmp 0x000074C3551D018D
000074c3551d49bb  sub rsp, 0x08
000074c3551d49bf  push rax
000074c3551d49c0  push rcx
000074c3551d49c1  push rdx
000074c3551d49c2  push rdi
000074c3551d49c3  push rsi
000074c3551d49c4  push r8
000074c3551d49c6  push r9
000074c3551d49c8  push r10
000074c3551d49ca  push r11
000074c3551d49cc  sub rsp, 0xF0
000074c3551d49d3  vmovaps [rsp], xmm0
000074c3551d49d8  vmovaps [rsp+0x10], xmm1
000074c3551d49de  vmovaps [rsp+0x20], xmm2
000074c3551d49e4  vmovaps [rsp+0x30], xmm3
000074c3551d49ea  vmovaps [rsp+0x40], xmm4
000074c3551d49f0  vmovaps [rsp+0x50], xmm5
000074c3551d49f6  vmovaps [rsp+0x60], xmm6
000074c3551d49fc  vmovaps [rsp+0x70], xmm7
000074c3551d4a02  vmovaps [rsp+0x80], xmm9
000074c3551d4a0b  vmovaps [rsp+0x90], xmm10
000074c3551d4a14  vmovaps [rsp+0xA0], xmm11
000074c3551d4a1d  vmovaps [rsp+0xB0], xmm12
000074c3551d4a26  vmovaps [rsp+0xC0], xmm13
000074c3551d4a2f  vmovaps [rsp+0xD0], xmm14
000074c3551d4a38  vmovaps [rsp+0xE0], xmm15
000074c3551d4a41  sub rsp, 0x30
000074c3551d4a45  movaps [rsp], xmm8
000074c3551d4a4a  movaps [rsp+0x10], xmm14
000074c3551d4a50  movaps [rsp+0x20], xmm9
000074c3551d4a56  lea rdi, [rsp]
000074c3551d4a5a  mov esi, 0x00
000074c3551d4a5f  mov rax, 0x5F9407FA9530
000074c3551d4a69  call rax
000074c3551d4a6b  movaps xmm8, [rsp]
000074c3551d4a70  add rsp, 0x30
000074c3551d4a74  vmovaps xmm0, [rsp]
000074c3551d4a79  vmovaps xmm1, [rsp+0x10]
000074c3551d4a7f  vmovaps xmm2, [rsp+0x20]
000074c3551d4a85  vmovaps xmm3, [rsp+0x30]
000074c3551d4a8b  vmovaps xmm4, [rsp+0x40]
000074c3551d4a91  vmovaps xmm5, [rsp+0x50]
000074c3551d4a97  vmovaps xmm6, [rsp+0x60]
000074c3551d4a9d  vmovaps xmm7, [rsp+0x70]
000074c3551d4aa3  vmovaps xmm9, [rsp+0x80]
000074c3551d4aac  vmovaps xmm10, [rsp+0x90]
000074c3551d4ab5  vmovaps xmm11, [rsp+0xA0]
000074c3551d4abe  vmovaps xmm12, [rsp+0xB0]
000074c3551d4ac7  vmovaps xmm13, [rsp+0xC0]
000074c3551d4ad0  vmovaps xmm14, [rsp+0xD0]
000074c3551d4ad9  vmovaps xmm15, [rsp+0xE0]
000074c3551d4ae2  add rsp, 0xF0
000074c3551d4ae9  pop r11
000074c3551d4aeb  pop r10
000074c3551d4aed  pop r9
000074c3551d4aef  pop r8
000074c3551d4af1  pop rsi
000074c3551d4af2  pop rdi
000074c3551d4af3  pop rdx
000074c3551d4af4  pop rcx
000074c3551d4af5  pop rax
000074c3551d4af6  add rsp, 0x08
000074c3551d4afa  jmp 0x000074C3551D01AF
000074c3551d4aff  sub rsp, 0x08
000074c3551d4b03  push rax
000074c3551d4b04  push rcx
000074c3551d4b05  push rdx
000074c3551d4b06  push rdi
000074c3551d4b07  push rsi
000074c3551d4b08  push r8
000074c3551d4b0a  push r9
000074c3551d4b0c  push r10
000074c3551d4b0e  push r11
000074c3551d4b10  sub rsp, 0xF0
000074c3551d4b17  vmovaps [rsp], xmm0
000074c3551d4b1c  vmovaps [rsp+0x10], xmm1
000074c3551d4b22  vmovaps [rsp+0x20], xmm2
000074c3551d4b28  vmovaps [rsp+0x30], xmm3
000074c3551d4b2e  vmovaps [rsp+0x40], xmm4
000074c3551d4b34  vmovaps [rsp+0x50], xmm5
000074c3551d4b3a  vmovaps [rsp+0x60], xmm6
000074c3551d4b40  vmovaps [rsp+0x70], xmm7
000074c3551d4b46  vmovaps [rsp+0x80], xmm8
000074c3551d4b4f  vmovaps [rsp+0x90], xmm10
000074c3551d4b58  vmovaps [rsp+0xA0], xmm11
000074c3551d4b61  vmovaps [rsp+0xB0], xmm12
000074c3551d4b6a  vmovaps [rsp+0xC0], xmm13
000074c3551d4b73  vmovaps [rsp+0xD0], xmm14
000074c3551d4b7c  vmovaps [rsp+0xE0], xmm15
000074c3551d4b85  sub rsp, 0x30
000074c3551d4b89  movaps [rsp], xmm9
000074c3551d4b8e  movaps [rsp+0x10], xmm1
000074c3551d4b93  movaps [rsp+0x20], xmm14
000074c3551d4b99  lea rdi, [rsp]
000074c3551d4b9d  mov esi, 0x00
000074c3551d4ba2  mov rax, 0x5F9407FA9530
000074c3551d4bac  call rax
000074c3551d4bae  movaps xmm9, [rsp]
000074c3551d4bb3  add rsp, 0x30
000074c3551d4bb7  vmovaps xmm0, [rsp]
000074c3551d4bbc  vmovaps xmm1, [rsp+0x10]
000074c3551d4bc2  vmovaps xmm2, [rsp+0x20]
000074c3551d4bc8  vmovaps xmm3, [rsp+0x30]
000074c3551d4bce  vmovaps xmm4, [rsp+0x40]
000074c3551d4bd4  vmovaps xmm5, [rsp+0x50]
000074c3551d4bda  vmovaps xmm6, [rsp+0x60]
000074c3551d4be0  vmovaps xmm7, [rsp+0x70]
000074c3551d4be6  vmovaps xmm8, [rsp+0x80]
000074c3551d4bef  vmovaps xmm10, [rsp+0x90]
000074c3551d4bf8  vmovaps xmm11, [rsp+0xA0]
000074c3551d4c01  vmovaps xmm12, [rsp+0xB0]
000074c3551d4c0a  vmovaps xmm13, [rsp+0xC0]
000074c3551d4c13  vmovaps xmm14, [rsp+0xD0]
000074c3551d4c1c  vmovaps xmm15, [rsp+0xE0]
000074c3551d4c25  add rsp, 0xF0
000074c3551d4c2c  pop r11
000074c3551d4c2e  pop r10
000074c3551d4c30  pop r9
000074c3551d4c32  pop r8
000074c3551d4c34  pop rsi
000074c3551d4c35  pop rdi
000074c3551d4c36  pop rdx
000074c3551d4c37  pop rcx
000074c3551d4c38  pop rax
000074c3551d4c39  add rsp, 0x08
000074c3551d4c3d  jmp 0x000074C3551D01DD
000074c3551d4c42  sub rsp, 0x08
000074c3551d4c46  push rax
000074c3551d4c47  push rcx
000074c3551d4c48  push rdx
000074c3551d4c49  push rdi
000074c3551d4c4a  push rsi
000074c3551d4c4b  push r8
000074c3551d4c4d  push r9
000074c3551d4c4f  push r10
000074c3551d4c51  push r11
000074c3551d4c53  sub rsp, 0xF0
000074c3551d4c5a  vmovaps [rsp], xmm0
000074c3551d4c5f  vmovaps [rsp+0x10], xmm1
000074c3551d4c65  vmovaps [rsp+0x20], xmm2
000074c3551d4c6b  vmovaps [rsp+0x30], xmm3
000074c3551d4c71  vmovaps [rsp+0x40], xmm4
000074c3551d4c77  vmovaps [rsp+0x50], xmm5
000074c3551d4c7d  vmovaps [rsp+0x60], xmm6
000074c3551d4c83  vmovaps [rsp+0x70], xmm7
000074c3551d4c89  vmovaps [rsp+0x80], xmm8
000074c3551d4c92  vmovaps [rsp+0x90], xmm9
000074c3551d4c9b  vmovaps [rsp+0xA0], xmm10
000074c3551d4ca4  vmovaps [rsp+0xB0], xmm11
000074c3551d4cad  vmovaps [rsp+0xC0], xmm12
000074c3551d4cb6  vmovaps [rsp+0xD0], xmm13
000074c3551d4cbf  vmovaps [rsp+0xE0], xmm15
000074c3551d4cc8  sub rsp, 0x30
000074c3551d4ccc  movaps [rsp], xmm14
000074c3551d4cd1  movaps [rsp+0x10], xmm4
000074c3551d4cd6  movaps [rsp+0x20], xmm1
000074c3551d4cdb  lea rdi, [rsp]
000074c3551d4cdf  mov esi, 0x00
000074c3551d4ce4  mov rax, 0x5F9407FA9530
000074c3551d4cee  call rax
000074c3551d4cf0  movaps xmm14, [rsp]
000074c3551d4cf5  add rsp, 0x30
000074c3551d4cf9  vmovaps xmm0, [rsp]
000074c3551d4cfe  vmovaps xmm1, [rsp+0x10]
000074c3551d4d04  vmovaps xmm2, [rsp+0x20]
000074c3551d4d0a  vmovaps xmm3, [rsp+0x30]
000074c3551d4d10  vmovaps xmm4, [rsp+0x40]
000074c3551d4d16  vmovaps xmm5, [rsp+0x50]
000074c3551d4d1c  vmovaps xmm6, [rsp+0x60]
000074c3551d4d22  vmovaps xmm7, [rsp+0x70]
000074c3551d4d28  vmovaps xmm8, [rsp+0x80]
000074c3551d4d31  vmovaps xmm9, [rsp+0x90]
000074c3551d4d3a  vmovaps xmm10, [rsp+0xA0]
000074c3551d4d43  vmovaps xmm11, [rsp+0xB0]
000074c3551d4d4c  vmovaps xmm12, [rsp+0xC0]
000074c3551d4d55  vmovaps xmm13, [rsp+0xD0]
000074c3551d4d5e  vmovaps xmm15, [rsp+0xE0]
000074c3551d4d67  add rsp, 0xF0
000074c3551d4d6e  pop r11
000074c3551d4d70  pop r10
000074c3551d4d72  pop r9
000074c3551d4d74  pop r8
000074c3551d4d76  pop rsi
000074c3551d4d77  pop rdi
000074c3551d4d78  pop rdx
000074c3551d4d79  pop rcx
000074c3551d4d7a  pop rax
000074c3551d4d7b  add rsp, 0x08
000074c3551d4d7f  jmp 0x000074C3551D0203
000074c3551d4d84  sub rsp, 0x08
000074c3551d4d88  push rax
000074c3551d4d89  push rcx
000074c3551d4d8a  push rdx
000074c3551d4d8b  push rdi
000074c3551d4d8c  push rsi
000074c3551d4d8d  push r8
000074c3551d4d8f  push r9
000074c3551d4d91  push r10
000074c3551d4d93  push r11
000074c3551d4d95  sub rsp, 0xF0
000074c3551d4d9c  vmovaps [rsp], xmm0
000074c3551d4da1  vmovaps [rsp+0x10], xmm2
000074c3551d4da7  vmovaps [rsp+0x20], xmm3
000074c3551d4dad  vmovaps [rsp+0x30], xmm4
000074c3551d4db3  vmovaps [rsp+0x40], xmm5
000074c3551d4db9  vmovaps [rsp+0x50], xmm6
000074c3551d4dbf  vmovaps [rsp+0x60], xmm7
000074c3551d4dc5  vmovaps [rsp+0x70], xmm8
000074c3551d4dcb  vmovaps [rsp+0x80], xmm9
000074c3551d4dd4  vmovaps [rsp+0x90], xmm10
000074c3551d4ddd  vmovaps [rsp+0xA0], xmm11
000074c3551d4de6  vmovaps [rsp+0xB0], xmm12
000074c3551d4def  vmovaps [rsp+0xC0], xmm13
000074c3551d4df8  vmovaps [rsp+0xD0], xmm14
000074c3551d4e01  vmovaps [rsp+0xE0], xmm15
000074c3551d4e0a  sub rsp, 0x30
000074c3551d4e0e  movaps [rsp], xmm1
000074c3551d4e12  movaps [rsp+0x10], xmm12
000074c3551d4e18  movaps [rsp+0x20], xmm11
000074c3551d4e1e  lea rdi, [rsp]
000074c3551d4e22  mov esi, 0x00
000074c3551d4e27  mov rax, 0x5F9407FA9530
000074c3551d4e31  call rax
000074c3551d4e33  movaps xmm1, [rsp]
000074c3551d4e37  add rsp, 0x30
000074c3551d4e3b  vmovaps xmm0, [rsp]
000074c3551d4e40  vmovaps xmm2, [rsp+0x10]
000074c3551d4e46  vmovaps xmm3, [rsp+0x20]
000074c3551d4e4c  vmovaps xmm4, [rsp+0x30]
000074c3551d4e52  vmovaps xmm5, [rsp+0x40]
000074c3551d4e58  vmovaps xmm6, [rsp+0x50]
000074c3551d4e5e  vmovaps xmm7, [rsp+0x60]
000074c3551d4e64  vmovaps xmm8, [rsp+0x70]
000074c3551d4e6a  vmovaps xmm9, [rsp+0x80]
000074c3551d4e73  vmovaps xmm10, [rsp+0x90]
000074c3551d4e7c  vmovaps xmm11, [rsp+0xA0]
000074c3551d4e85  vmovaps xmm12, [rsp+0xB0]
000074c3551d4e8e  vmovaps xmm13, [rsp+0xC0]
000074c3551d4e97  vmovaps xmm14, [rsp+0xD0]
000074c3551d4ea0  vmovaps xmm15, [rsp+0xE0]
000074c3551d4ea9  add rsp, 0xF0
000074c3551d4eb0  pop r11
000074c3551d4eb2  pop r10
000074c3551d4eb4  pop r9
000074c3551d4eb6  pop r8
000074c3551d4eb8  pop rsi
000074c3551d4eb9  pop rdi
000074c3551d4eba  pop rdx
000074c3551d4ebb  pop rcx
000074c3551d4ebc  pop rax
000074c3551d4ebd  add rsp, 0x08
000074c3551d4ec1  jmp 0x000074C3551D0224
000074c3551d4ec6  call 0x000074C3550E20A0
000074c3551d4ecb  jmp 0x000074C3551D0232
000074c3551d4ed0  call 0x000074C355009D70
000074c3551d4ed5  jmp 0x000074C3551D023C
000074c3551d4eda  sub rsp, 0x08
000074c3551d4ede  push rax
000074c3551d4edf  push rcx
000074c3551d4ee0  push rdx
000074c3551d4ee1  push rdi
000074c3551d4ee2  push rsi
000074c3551d4ee3  push r8
000074c3551d4ee5  push r9
000074c3551d4ee7  push r10
000074c3551d4ee9  push r11
000074c3551d4eeb  sub rsp, 0xF0
000074c3551d4ef2  vmovaps [rsp], xmm0
000074c3551d4ef7  vmovaps [rsp+0x10], xmm1
000074c3551d4efd  vmovaps [rsp+0x20], xmm2
000074c3551d4f03  vmovaps [rsp+0x30], xmm3
000074c3551d4f09  vmovaps [rsp+0x40], xmm4
000074c3551d4f0f  vmovaps [rsp+0x50], xmm5
000074c3551d4f15  vmovaps [rsp+0x60], xmm6
000074c3551d4f1b  vmovaps [rsp+0x70], xmm8
000074c3551d4f21  vmovaps [rsp+0x80], xmm9
000074c3551d4f2a  vmovaps [rsp+0x90], xmm10
000074c3551d4f33  vmovaps [rsp+0xA0], xmm11
000074c3551d4f3c  vmovaps [rsp+0xB0], xmm12
000074c3551d4f45  vmovaps [rsp+0xC0], xmm13
000074c3551d4f4e  vmovaps [rsp+0xD0], xmm14
000074c3551d4f57  vmovaps [rsp+0xE0], xmm15
000074c3551d4f60  sub rsp, 0x30
000074c3551d4f64  movaps [rsp], xmm7
000074c3551d4f68  movaps [rsp+0x10], xmm15
000074c3551d4f6e  movaps [rsp+0x20], xmm10
000074c3551d4f74  lea rdi, [rsp]
000074c3551d4f78  mov esi, 0x00
000074c3551d4f7d  mov rax, 0x5F9407FA9530
000074c3551d4f87  call rax
000074c3551d4f89  movaps xmm7, [rsp]
000074c3551d4f8d  add rsp, 0x30
000074c3551d4f91  vmovaps xmm0, [rsp]
000074c3551d4f96  vmovaps xmm1, [rsp+0x10]
000074c3551d4f9c  vmovaps xmm2, [rsp+0x20]
000074c3551d4fa2  vmovaps xmm3, [rsp+0x30]
000074c3551d4fa8  vmovaps xmm4, [rsp+0x40]
000074c3551d4fae  vmovaps xmm5, [rsp+0x50]
000074c3551d4fb4  vmovaps xmm6, [rsp+0x60]
000074c3551d4fba  vmovaps xmm8, [rsp+0x70]
000074c3551d4fc0  vmovaps xmm9, [rsp+0x80]
000074c3551d4fc9  vmovaps xmm10, [rsp+0x90]
000074c3551d4fd2  vmovaps xmm11, [rsp+0xA0]
000074c3551d4fdb  vmovaps xmm12, [rsp+0xB0]
000074c3551d4fe4  vmovaps xmm13, [rsp+0xC0]
000074c3551d4fed  vmovaps xmm14, [rsp+0xD0]
000074c3551d4ff6  vmovaps xmm15, [rsp+0xE0]
000074c3551d4fff  add rsp, 0xF0
000074c3551d5006  pop r11
000074c3551d5008  pop r10
000074c3551d500a  pop r9
000074c3551d500c  pop r8
000074c3551d500e  pop rsi
000074c3551d500f  pop rdi
000074c3551d5010  pop rdx
000074c3551d5011  pop rcx
000074c3551d5012  pop rax
000074c3551d5013  add rsp, 0x08
000074c3551d5017  jmp 0x000074C3551D025D
000074c3551d501c  sub rsp, 0x08
000074c3551d5020  push rax
000074c3551d5021  push rcx
000074c3551d5022  push rdx
000074c3551d5023  push rdi
000074c3551d5024  push rsi
000074c3551d5025  push r8
000074c3551d5027  push r9
000074c3551d5029  push r10
000074c3551d502b  push r11
000074c3551d502d  sub rsp, 0xF0
000074c3551d5034  vmovaps [rsp], xmm0
000074c3551d5039  vmovaps [rsp+0x10], xmm1
000074c3551d503f  vmovaps [rsp+0x20], xmm2
000074c3551d5045  vmovaps [rsp+0x30], xmm3
000074c3551d504b  vmovaps [rsp+0x40], xmm4
000074c3551d5051  vmovaps [rsp+0x50], xmm5
000074c3551d5057  vmovaps [rsp+0x60], xmm6
000074c3551d505d  vmovaps [rsp+0x70], xmm7
000074c3551d5063  vmovaps [rsp+0x80], xmm8
000074c3551d506c  vmovaps [rsp+0x90], xmm9
000074c3551d5075  vmovaps [rsp+0xA0], xmm11
000074c3551d507e  vmovaps [rsp+0xB0], xmm12
000074c3551d5087  vmovaps [rsp+0xC0], xmm13
000074c3551d5090  vmovaps [rsp+0xD0], xmm14
000074c3551d5099  vmovaps [rsp+0xE0], xmm15
000074c3551d50a2  sub rsp, 0x30
000074c3551d50a6  movaps [rsp], xmm10
000074c3551d50ab  movaps [rsp+0x10], xmm11
000074c3551d50b1  movaps [rsp+0x20], xmm15
000074c3551d50b7  lea rdi, [rsp]
000074c3551d50bb  mov esi, 0x00
000074c3551d50c0  mov rax, 0x5F9407FA9530
000074c3551d50ca  call rax
000074c3551d50cc  movaps xmm10, [rsp]
000074c3551d50d1  add rsp, 0x30
000074c3551d50d5  vmovaps xmm0, [rsp]
000074c3551d50da  vmovaps xmm1, [rsp+0x10]
000074c3551d50e0  vmovaps xmm2, [rsp+0x20]
000074c3551d50e6  vmovaps xmm3, [rsp+0x30]
000074c3551d50ec  vmovaps xmm4, [rsp+0x40]
000074c3551d50f2  vmovaps xmm5, [rsp+0x50]
000074c3551d50f8  vmovaps xmm6, [rsp+0x60]
000074c3551d50fe  vmovaps xmm7, [rsp+0x70]
000074c3551d5104  vmovaps xmm8, [rsp+0x80]
000074c3551d510d  vmovaps xmm9, [rsp+0x90]
000074c3551d5116  vmovaps xmm11, [rsp+0xA0]
000074c3551d511f  vmovaps xmm12, [rsp+0xB0]
000074c3551d5128  vmovaps xmm13, [rsp+0xC0]
000074c3551d5131  vmovaps xmm14, [rsp+0xD0]
000074c3551d513a  vmovaps xmm15, [rsp+0xE0]
000074c3551d5143  add rsp, 0xF0
000074c3551d514a  pop r11
000074c3551d514c  pop r10
000074c3551d514e  pop r9
000074c3551d5150  pop r8
000074c3551d5152  pop rsi
000074c3551d5153  pop rdi
000074c3551d5154  pop rdx
000074c3551d5155  pop rcx
000074c3551d5156  pop rax
000074c3551d5157  add rsp, 0x08
000074c3551d515b  jmp 0x000074C3551D028B
000074c3551d5160  sub rsp, 0x08
000074c3551d5164  push rax
000074c3551d5165  push rcx
000074c3551d5166  push rdx
000074c3551d5167  push rdi
000074c3551d5168  push rsi
000074c3551d5169  push r8
000074c3551d516b  push r9
000074c3551d516d  push r10
000074c3551d516f  push r11
000074c3551d5171  sub rsp, 0xF0
000074c3551d5178  vmovaps [rsp], xmm0
000074c3551d517d  vmovaps [rsp+0x10], xmm1
000074c3551d5183  vmovaps [rsp+0x20], xmm2
000074c3551d5189  vmovaps [rsp+0x30], xmm3
000074c3551d518f  vmovaps [rsp+0x40], xmm4
000074c3551d5195  vmovaps [rsp+0x50], xmm5
000074c3551d519b  vmovaps [rsp+0x60], xmm6
000074c3551d51a1  vmovaps [rsp+0x70], xmm7
000074c3551d51a7  vmovaps [rsp+0x80], xmm8
000074c3551d51b0  vmovaps [rsp+0x90], xmm9
000074c3551d51b9  vmovaps [rsp+0xA0], xmm10
000074c3551d51c2  vmovaps [rsp+0xB0], xmm12
000074c3551d51cb  vmovaps [rsp+0xC0], xmm13
000074c3551d51d4  vmovaps [rsp+0xD0], xmm14
000074c3551d51dd  vmovaps [rsp+0xE0], xmm15
000074c3551d51e6  sub rsp, 0x30
000074c3551d51ea  movaps [rsp], xmm11
000074c3551d51ef  movaps [rsp+0x10], xmm12
000074c3551d51f5  movaps [rsp+0x20], xmm15
000074c3551d51fb  lea rdi, [rsp]
000074c3551d51ff  mov esi, 0x00
000074c3551d5204  mov rax, 0x5F9407FA9530
000074c3551d520e  call rax
000074c3551d5210  movaps xmm11, [rsp]
000074c3551d5215  add rsp, 0x30
000074c3551d5219  vmovaps xmm0, [rsp]
000074c3551d521e  vmovaps xmm1, [rsp+0x10]
000074c3551d5224  vmovaps xmm2, [rsp+0x20]
000074c3551d522a  vmovaps xmm3, [rsp+0x30]
000074c3551d5230  vmovaps xmm4, [rsp+0x40]
000074c3551d5236  vmovaps xmm5, [rsp+0x50]
000074c3551d523c  vmovaps xmm6, [rsp+0x60]
000074c3551d5242  vmovaps xmm7, [rsp+0x70]
000074c3551d5248  vmovaps xmm8, [rsp+0x80]
000074c3551d5251  vmovaps xmm9, [rsp+0x90]
000074c3551d525a  vmovaps xmm10, [rsp+0xA0]
000074c3551d5263  vmovaps xmm12, [rsp+0xB0]
000074c3551d526c  vmovaps xmm13, [rsp+0xC0]
000074c3551d5275  vmovaps xmm14, [rsp+0xD0]
000074c3551d527e  vmovaps xmm15, [rsp+0xE0]
000074c3551d5287  add rsp, 0xF0
000074c3551d528e  pop r11
000074c3551d5290  pop r10
000074c3551d5292  pop r9
000074c3551d5294  pop r8
000074c3551d5296  pop rsi
000074c3551d5297  pop rdi
000074c3551d5298  pop rdx
000074c3551d5299  pop rcx
000074c3551d529a  pop rax
000074c3551d529b  add rsp, 0x08
000074c3551d529f  jmp 0x000074C3551D02B9
000074c3551d52a4  sub rsp, 0x08
000074c3551d52a8  push rax
000074c3551d52a9  push rcx
000074c3551d52aa  push rdx
000074c3551d52ab  push rdi
000074c3551d52ac  push rsi
000074c3551d52ad  push r8
000074c3551d52af  push r9
000074c3551d52b1  push r10
000074c3551d52b3  push r11
000074c3551d52b5  sub rsp, 0xF0
000074c3551d52bc  vmovaps [rsp], xmm0
000074c3551d52c1  vmovaps [rsp+0x10], xmm1
000074c3551d52c7  vmovaps [rsp+0x20], xmm2
000074c3551d52cd  vmovaps [rsp+0x30], xmm3
000074c3551d52d3  vmovaps [rsp+0x40], xmm4
000074c3551d52d9  vmovaps [rsp+0x50], xmm5
000074c3551d52df  vmovaps [rsp+0x60], xmm6
000074c3551d52e5  vmovaps [rsp+0x70], xmm7
000074c3551d52eb  vmovaps [rsp+0x80], xmm8
000074c3551d52f4  vmovaps [rsp+0x90], xmm9
000074c3551d52fd  vmovaps [rsp+0xA0], xmm10
000074c3551d5306  vmovaps [rsp+0xB0], xmm11
000074c3551d530f  vmovaps [rsp+0xC0], xmm12
000074c3551d5318  vmovaps [rsp+0xD0], xmm13
000074c3551d5321  vmovaps [rsp+0xE0], xmm14
000074c3551d532a  sub rsp, 0x30
000074c3551d532e  movaps [rsp], xmm15
000074c3551d5333  movaps [rsp+0x10], xmm13
000074c3551d5339  movaps [rsp+0x20], xmm9
000074c3551d533f  lea rdi, [rsp]
000074c3551d5343  mov esi, 0x00
000074c3551d5348  mov rax, 0x5F9407FA9530
000074c3551d5352  call rax
000074c3551d5354  movaps xmm15, [rsp]
000074c3551d5359  add rsp, 0x30
000074c3551d535d  vmovaps xmm0, [rsp]
000074c3551d5362  vmovaps xmm1, [rsp+0x10]
000074c3551d5368  vmovaps xmm2, [rsp+0x20]
000074c3551d536e  vmovaps xmm3, [rsp+0x30]
000074c3551d5374  vmovaps xmm4, [rsp+0x40]
000074c3551d537a  vmovaps xmm5, [rsp+0x50]
000074c3551d5380  vmovaps xmm6, [rsp+0x60]
000074c3551d5386  vmovaps xmm7, [rsp+0x70]
000074c3551d538c  vmovaps xmm8, [rsp+0x80]
000074c3551d5395  vmovaps xmm9, [rsp+0x90]
000074c3551d539e  vmovaps xmm10, [rsp+0xA0]
000074c3551d53a7  vmovaps xmm11, [rsp+0xB0]
000074c3551d53b0  vmovaps xmm12, [rsp+0xC0]
000074c3551d53b9  vmovaps xmm13, [rsp+0xD0]
000074c3551d53c2  vmovaps xmm14, [rsp+0xE0]
000074c3551d53cb  add rsp, 0xF0
000074c3551d53d2  pop r11
000074c3551d53d4  pop r10
000074c3551d53d6  pop r9
000074c3551d53d8  pop r8
000074c3551d53da  pop rsi
000074c3551d53db  pop rdi
000074c3551d53dc  pop rdx
000074c3551d53dd  pop rcx
000074c3551d53de  pop rax
000074c3551d53df  add rsp, 0x08
000074c3551d53e3  jmp 0x000074C3551D02D4
000074c3551d53e8  sub rsp, 0x08
000074c3551d53ec  push rax
000074c3551d53ed  push rcx
000074c3551d53ee  push rdx
000074c3551d53ef  push rdi
000074c3551d53f0  push rsi
000074c3551d53f1  push r8
000074c3551d53f3  push r9
000074c3551d53f5  push r10
000074c3551d53f7  push r11
000074c3551d53f9  sub rsp, 0xF0
000074c3551d5400  vmovaps [rsp], xmm0
000074c3551d5405  vmovaps [rsp+0x10], xmm1
000074c3551d540b  vmovaps [rsp+0x20], xmm2
000074c3551d5411  vmovaps [rsp+0x30], xmm3
000074c3551d5417  vmovaps [rsp+0x40], xmm4
000074c3551d541d  vmovaps [rsp+0x50], xmm5
000074c3551d5423  vmovaps [rsp+0x60], xmm6
000074c3551d5429  vmovaps [rsp+0x70], xmm7
000074c3551d542f  vmovaps [rsp+0x80], xmm8
000074c3551d5438  vmovaps [rsp+0x90], xmm9
000074c3551d5441  vmovaps [rsp+0xA0], xmm10
000074c3551d544a  vmovaps [rsp+0xB0], xmm11
000074c3551d5453  vmovaps [rsp+0xC0], xmm12
000074c3551d545c  vmovaps [rsp+0xD0], xmm14
000074c3551d5465  vmovaps [rsp+0xE0], xmm15
000074c3551d546e  sub rsp, 0x30
000074c3551d5472  movaps [rsp], xmm13
000074c3551d5477  movaps [rsp+0x10], xmm8
000074c3551d547d  movaps [rsp+0x20], xmm14
000074c3551d5483  lea rdi, [rsp]
000074c3551d5487  mov esi, 0x00
000074c3551d548c  mov rax, 0x5F9407FA9530
000074c3551d5496  call rax
000074c3551d5498  movaps xmm13, [rsp]
000074c3551d549d  add rsp, 0x30
000074c3551d54a1  vmovaps xmm0, [rsp]
000074c3551d54a6  vmovaps xmm1, [rsp+0x10]
000074c3551d54ac  vmovaps xmm2, [rsp+0x20]
000074c3551d54b2  vmovaps xmm3, [rsp+0x30]
000074c3551d54b8  vmovaps xmm4, [rsp+0x40]
000074c3551d54be  vmovaps xmm5, [rsp+0x50]
000074c3551d54c4  vmovaps xmm6, [rsp+0x60]
000074c3551d54ca  vmovaps xmm7, [rsp+0x70]
000074c3551d54d0  vmovaps xmm8, [rsp+0x80]
000074c3551d54d9  vmovaps xmm9, [rsp+0x90]
000074c3551d54e2  vmovaps xmm10, [rsp+0xA0]
000074c3551d54eb  vmovaps xmm11, [rsp+0xB0]
000074c3551d54f4  vmovaps xmm12, [rsp+0xC0]
000074c3551d54fd  vmovaps xmm14, [rsp+0xD0]
000074c3551d5506  vmovaps xmm15, [rsp+0xE0]
000074c3551d550f  add rsp, 0xF0
000074c3551d5516  pop r11
000074c3551d5518  pop r10
000074c3551d551a  pop r9
000074c3551d551c  pop r8
000074c3551d551e  pop rsi
000074c3551d551f  pop rdi
000074c3551d5520  pop rdx
000074c3551d5521  pop rcx
000074c3551d5522  pop rax
000074c3551d5523  add rsp, 0x08
000074c3551d5527  jmp 0x000074C3551D02F7
000074c3551d552c  sub rsp, 0x08
000074c3551d5530  push rax
000074c3551d5531  push rcx
000074c3551d5532  push rdx
000074c3551d5533  push rdi
000074c3551d5534  push rsi
000074c3551d5535  push r8
000074c3551d5537  push r9
000074c3551d5539  push r10
000074c3551d553b  push r11
000074c3551d553d  sub rsp, 0xF0
000074c3551d5544  vmovaps [rsp], xmm0
000074c3551d5549  vmovaps [rsp+0x10], xmm1
000074c3551d554f  vmovaps [rsp+0x20], xmm2
000074c3551d5555  vmovaps [rsp+0x30], xmm3
000074c3551d555b  vmovaps [rsp+0x40], xmm4
000074c3551d5561  vmovaps [rsp+0x50], xmm5
000074c3551d5567  vmovaps [rsp+0x60], xmm6
000074c3551d556d  vmovaps [rsp+0x70], xmm7
000074c3551d5573  vmovaps [rsp+0x80], xmm8
000074c3551d557c  vmovaps [rsp+0x90], xmm9
000074c3551d5585  vmovaps [rsp+0xA0], xmm10
000074c3551d558e  vmovaps [rsp+0xB0], xmm11
000074c3551d5597  vmovaps [rsp+0xC0], xmm12
000074c3551d55a0  vmovaps [rsp+0xD0], xmm13
000074c3551d55a9  vmovaps [rsp+0xE0], xmm15
000074c3551d55b2  sub rsp, 0x30
000074c3551d55b6  movaps [rsp], xmm14
000074c3551d55bb  movaps [rsp+0x10], xmm1
000074c3551d55c0  movaps [rsp+0x20], xmm10
000074c3551d55c6  lea rdi, [rsp]
000074c3551d55ca  mov esi, 0x00
000074c3551d55cf  mov rax, 0x5F9407FA9530
000074c3551d55d9  call rax
000074c3551d55db  movaps xmm14, [rsp]
000074c3551d55e0  add rsp, 0x30
000074c3551d55e4  vmovaps xmm0, [rsp]
000074c3551d55e9  vmovaps xmm1, [rsp+0x10]
000074c3551d55ef  vmovaps xmm2, [rsp+0x20]
000074c3551d55f5  vmovaps xmm3, [rsp+0x30]
000074c3551d55fb  vmovaps xmm4, [rsp+0x40]
000074c3551d5601  vmovaps xmm5, [rsp+0x50]
000074c3551d5607  vmovaps xmm6, [rsp+0x60]
000074c3551d560d  vmovaps xmm7, [rsp+0x70]
000074c3551d5613  vmovaps xmm8, [rsp+0x80]
000074c3551d561c  vmovaps xmm9, [rsp+0x90]
000074c3551d5625  vmovaps xmm10, [rsp+0xA0]
000074c3551d562e  vmovaps xmm11, [rsp+0xB0]
000074c3551d5637  vmovaps xmm12, [rsp+0xC0]
000074c3551d5640  vmovaps xmm13, [rsp+0xD0]
000074c3551d5649  vmovaps xmm15, [rsp+0xE0]
000074c3551d5652  add rsp, 0xF0
000074c3551d5659  pop r11
000074c3551d565b  pop r10
000074c3551d565d  pop r9
000074c3551d565f  pop r8
000074c3551d5661  pop rsi
000074c3551d5662  pop rdi
000074c3551d5663  pop rdx
000074c3551d5664  pop rcx
000074c3551d5665  pop rax
000074c3551d5666  add rsp, 0x08
000074c3551d566a  jmp 0x000074C3551D031A
000074c3551d566f  sub rsp, 0x08
000074c3551d5673  push rax
000074c3551d5674  push rcx
000074c3551d5675  push rdx
000074c3551d5676  push rdi
000074c3551d5677  push rsi
000074c3551d5678  push r8
000074c3551d567a  push r9
000074c3551d567c  push r10
000074c3551d567e  push r11
000074c3551d5680  sub rsp, 0xF0
000074c3551d5687  vmovaps [rsp], xmm0
000074c3551d568c  vmovaps [rsp+0x10], xmm2
000074c3551d5692  vmovaps [rsp+0x20], xmm3
000074c3551d5698  vmovaps [rsp+0x30], xmm4
000074c3551d569e  vmovaps [rsp+0x40], xmm5
000074c3551d56a4  vmovaps [rsp+0x50], xmm6
000074c3551d56aa  vmovaps [rsp+0x60], xmm7
000074c3551d56b0  vmovaps [rsp+0x70], xmm8
000074c3551d56b6  vmovaps [rsp+0x80], xmm9
000074c3551d56bf  vmovaps [rsp+0x90], xmm10
000074c3551d56c8  vmovaps [rsp+0xA0], xmm11
000074c3551d56d1  vmovaps [rsp+0xB0], xmm12
000074c3551d56da  vmovaps [rsp+0xC0], xmm13
000074c3551d56e3  vmovaps [rsp+0xD0], xmm14
000074c3551d56ec  vmovaps [rsp+0xE0], xmm15
000074c3551d56f5  sub rsp, 0x30
000074c3551d56f9  movaps [rsp], xmm1
000074c3551d56fd  movaps [rsp+0x10], xmm7
000074c3551d5702  movaps [rsp+0x20], xmm11
000074c3551d5708  lea rdi, [rsp]
000074c3551d570c  mov esi, 0x00
000074c3551d5711  mov rax, 0x5F9407FA9530
000074c3551d571b  call rax
000074c3551d571d  movaps xmm1, [rsp]
000074c3551d5721  add rsp, 0x30
000074c3551d5725  vmovaps xmm0, [rsp]
000074c3551d572a  vmovaps xmm2, [rsp+0x10]
000074c3551d5730  vmovaps xmm3, [rsp+0x20]
000074c3551d5736  vmovaps xmm4, [rsp+0x30]
000074c3551d573c  vmovaps xmm5, [rsp+0x40]
000074c3551d5742  vmovaps xmm6, [rsp+0x50]
000074c3551d5748  vmovaps xmm7, [rsp+0x60]
000074c3551d574e  vmovaps xmm8, [rsp+0x70]
000074c3551d5754  vmovaps xmm9, [rsp+0x80]
000074c3551d575d  vmovaps xmm10, [rsp+0x90]
000074c3551d5766  vmovaps xmm11, [rsp+0xA0]
000074c3551d576f  vmovaps xmm12, [rsp+0xB0]
000074c3551d5778  vmovaps xmm13, [rsp+0xC0]
000074c3551d5781  vmovaps xmm14, [rsp+0xD0]
000074c3551d578a  vmovaps xmm15, [rsp+0xE0]
000074c3551d5793  add rsp, 0xF0
000074c3551d579a  pop r11
000074c3551d579c  pop r10
000074c3551d579e  pop r9
000074c3551d57a0  pop r8
000074c3551d57a2  pop rsi
000074c3551d57a3  pop rdi
000074c3551d57a4  pop rdx
000074c3551d57a5  pop rcx
000074c3551d57a6  pop rax
000074c3551d57a7  add rsp, 0x08
000074c3551d57ab  jmp 0x000074C3551D033B
000074c3551d57b0  call 0x000074C35500E880
000074c3551d57b5  jmp 0x000074C3551D034E
000074c3551d57ba  call 0x000074C35500C380
000074c3551d57bf  jmp 0x000074C3551D0359
000074c3551d57c4  call 0x000074C35500D600
000074c3551d57c9  jmp 0x000074C3551D0364
000074c3551d57ce  call 0x000074C354FFF540
000074c3551d57d3  jmp 0x000074C3551D036F
000074c3551d57d8  int3
000074c3551d57d9  nop [rax], eax
000074c3551d57e0  mov rax, [r15+0x40]
000074c3551d57e4  mov r14, [r15+0x58]
000074c3551d57e8  lea r12, [rax+r14*1]
000074c3551d57ec  movaps xmm1, [r15+0x1D0]
000074c3551d57f4  vmovaps [rsp+0x10], xmm1
000074c3551d57fa  vmovaps xmm15, [rsp+0x10]
000074c3551d5800  por xmm1, xmm15
000074c3551d5805  movaps xmm14, [r15+0x1A0]
000074c3551d580d  vmovaps [rsp+0x10], xmm14
000074c3551d5813  vmovaps xmm13, [rsp+0x10]
000074c3551d5819  por xmm14, xmm13
000074c3551d581e  lea rax, [r12+0x30]
000074c3551d5823  mov r11, [r13+rax*1]
000074c3551d5828  lea rax, [r12+0x38]
000074c3551d582d  mov r10, [r13+rax*1]
000074c3551d5832  movq xmm13, r11
000074c3551d5837  movq xmm12, r10
000074c3551d583c  movq xmm13, xmm13
000074c3551d5841  vmovaps [rsp+0x10], xmm13
000074c3551d5847  movq xmm13, xmm13
000074c3551d584c  movaps [r15+0x130], xmm13
000074c3551d5854  movq xmm12, xmm12
000074c3551d5859  vmovaps [rsp+0x20], xmm12
000074c3551d585f  movq xmm12, xmm12
000074c3551d5864  movaps [r15+0x280], xmm12
000074c3551d586c  movaps xmm13, [r15+0x270]
000074c3551d5874  vmovaps [rsp+0x30], xmm13
000074c3551d587a  vmovaps xmm12, [rsp+0x30]
000074c3551d5880  por xmm13, xmm12
000074c3551d5885  lea rax, [r12+0x20]
000074c3551d588a  mov r11, [r13+rax*1]
000074c3551d588f  lea rax, [r12+0x28]
000074c3551d5894  mov r10, [r13+rax*1]
000074c3551d5899  movq xmm12, r11
000074c3551d589e  movq xmm11, r10
000074c3551d58a3  movq xmm12, xmm12
000074c3551d58a8  vmovaps [rsp+0x30], xmm12
000074c3551d58ae  movq xmm12, xmm12
000074c3551d58b3  movaps [r15+0x150], xmm12
000074c3551d58bb  movq xmm11, xmm11
000074c3551d58c0  vmovaps [rsp+0x40], xmm11
000074c3551d58c6  movq xmm11, xmm11
000074c3551d58cb  movaps [r15+0x140], xmm11
000074c3551d58d3  lea rax, [r12+0x10]
000074c3551d58d8  mov r11, [r13+rax*1]
000074c3551d58dd  lea rax, [r12+0x18]
000074c3551d58e2  mov r10, [r13+rax*1]
000074c3551d58e7  movq xmm12, r11
000074c3551d58ec  movq xmm11, r10
000074c3551d58f1  movq xmm12, xmm12
000074c3551d58f6  vmovaps [rsp+0x50], xmm12
000074c3551d58fc  movq xmm12, xmm12
000074c3551d5901  movaps [r15+0x170], xmm12
000074c3551d5909  movq xmm11, xmm11
000074c3551d590e  vmovaps [rsp+0x60], xmm11
000074c3551d5914  movq xmm11, xmm11
000074c3551d5919  movaps [r15+0x160], xmm11
000074c3551d5921  mov rax, [r13+r12*1]
000074c3551d5926  vmovq xmm12, rax
000074c3551d592b  vpbroadcastq xmm12, xmm12
000074c3551d5930  lea rax, [r12+0x08]
000074c3551d5935  mov r12, [r13+rax*1]
000074c3551d593a  movq xmm11, r12
000074c3551d593f  movaps [r15+0x230], xmm11
000074c3551d5947  mov rax, [r15+0xF8]
000074c3551d594e  lea r12, [rax+0x50]
000074c3551d5952  movups xmm11, [r13+r12*1]
000074c3551d5958  lea r12, [rax+0x60]
000074c3551d595c  movups xmm10, [r13+r12*1]
000074c3551d5962  lea r12, [rax+0x30]
000074c3551d5966  movups xmm9, [r13+r12*1]
000074c3551d596c  mov r12, [r15+0x50]
000074c3551d5970  lea r11, [r12+r14*1]
000074c3551d5974  mov [r15+0x60], r11
000074c3551d5978  lea r12, [r14+0x40]
000074c3551d597c  mov [r15+0x58], r12
000074c3551d5980  movaps xmm8, xmm12
000074c3551d5984  mulpd xmm8, xmm15
000074c3551d5989  vcmppd xmm7, xmm8, xmm8, 0x03
000074c3551d598f  ptest xmm7, xmm7
000074c3551d5994  jnz 0x000074C3551D67B7
000074c3551d599a  movq xmm15, qword ptr [r15+0x230]
000074c3551d59a3  vmovaps [rsp+0x70], xmm15
000074c3551d59a9  vpermilpd xmm15, xmm15, 0x00
000074c3551d59af  movaps xmm7, xmm9
000074c3551d59b3  mulpd xmm7, xmm15
000074c3551d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000074c3551d59bd  ptest xmm6, xmm6
000074c3551d59c2  jnz 0x000074C3551D68FB
000074c3551d59c8  vxorps xmm15, xmm15, xmm15
000074c3551d59cd  vpbroadcastq xmm15, xmm15
000074c3551d59d2  movaps xmm9, xmm12
000074c3551d59d6  mulpd xmm9, xmm10
000074c3551d59db  vcmppd xmm6, xmm9, xmm9, 0x03
000074c3551d59e1  ptest xmm6, xmm6
000074c3551d59e6  jnz 0x000074C3551D6A3D
000074c3551d59ec  movaps xmm10, xmm12
000074c3551d59f0  mulpd xmm10, xmm11
000074c3551d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000074c3551d59fb  ptest xmm6, xmm6
000074c3551d5a00  jnz 0x000074C3551D6B81
000074c3551d5a06  movaps xmm11, [r15+0x1F0]
000074c3551d5a0e  movaps xmm6, xmm12
000074c3551d5a12  mulpd xmm6, xmm11
000074c3551d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000074c3551d5a1c  ptest xmm5, xmm5
000074c3551d5a21  jnz 0x000074C3551D6CC5
000074c3551d5a27  movaps xmm12, [r15+0x2A0]
000074c3551d5a2f  vmovaps [rsp+0x80], xmm12
000074c3551d5a38  vmovaps xmm11, [rsp+0x80]
000074c3551d5a41  por xmm12, xmm11
000074c3551d5a46  movaps xmm11, [r15+0x250]
000074c3551d5a4e  vmovaps [rsp+0x80], xmm11
000074c3551d5a57  vmovaps xmm5, [rsp+0x80]
000074c3551d5a60  por xmm11, xmm5
000074c3551d5a65  vmovaps xmm4, [rsp+0x70]
000074c3551d5a6b  vpermilpd xmm4, xmm4, 0x00
000074c3551d5a71  movaps xmm3, xmm5
000074c3551d5a74  mulpd xmm3, xmm4
000074c3551d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000074c3551d5a7d  ptest xmm2, xmm2
000074c3551d5a82  jnz 0x000074C3551D6E07
000074c3551d5a88  mov [rsp+0x80], rax
000074c3551d5a90  xor eax, eax
000074c3551d5a92  mov r14d, 0x200
000074c3551d5a98  cmp r12, r14
000074c3551d5a9b  cmc
000074c3551d5a9c  lahf
000074c3551d5a9d  seto al
000074c3551d5aa0  mov [r15+0x108], eax
000074c3551d5aa7  movaps xmm5, xmm8
000074c3551d5aab  addpd xmm5, xmm15
000074c3551d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000074c3551d5ab5  ptest xmm4, xmm4
000074c3551d5aba  jnz 0x000074C3551D6F47
000074c3551d5ac0  movaps xmm8, [r15+0x1B0]
000074c3551d5ac8  movaps xmm4, xmm9
000074c3551d5acc  addpd xmm4, xmm8
000074c3551d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000074c3551d5ad6  ptest xmm2, xmm2
000074c3551d5adb  jnz 0x000074C3551D7089
000074c3551d5ae1  movaps xmm9, xmm10
000074c3551d5ae5  addpd xmm9, xmm8
000074c3551d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000074c3551d5af0  ptest xmm2, xmm2
000074c3551d5af5  jnz 0x000074C3551D71CB
000074c3551d5afb  movaps xmm10, [r15+0x2F0]
000074c3551d5b03  vmovaps [rsp+0x90], xmm10
000074c3551d5b0c  vmovaps xmm8, [rsp+0x90]
000074c3551d5b15  por xmm10, xmm8
000074c3551d5b1a  movaps xmm8, [r15+0x2E0]
000074c3551d5b22  vmovaps [rsp+0x90], xmm8
000074c3551d5b2b  vmovaps xmm2, [rsp+0x90]
000074c3551d5b34  por xmm8, xmm2
000074c3551d5b39  movaps xmm2, [r15+0x2D0]
000074c3551d5b41  vmovaps [rsp+0x90], xmm2
000074c3551d5b4a  vmovaps [rsp+0xA0], xmm1
000074c3551d5b53  vmovaps xmm1, [rsp+0x90]
000074c3551d5b5c  por xmm2, xmm1
000074c3551d5b60  movaps xmm1, [r15+0x200]
000074c3551d5b68  vmovaps [rsp+0x90], xmm1
000074c3551d5b71  vmovaps [rsp+0xB0], xmm15
000074c3551d5b7a  vmovaps xmm15, [rsp+0x90]
000074c3551d5b83  por xmm1, xmm15
000074c3551d5b88  movaps xmm15, [r15+0x1C0]
000074c3551d5b90  vmovaps [rsp+0x90], xmm15
000074c3551d5b99  vmovaps [rsp+0xC0], xmm1
000074c3551d5ba2  vmovaps xmm1, [rsp+0x90]
000074c3551d5bab  por xmm15, xmm1
000074c3551d5bb0  movaps xmm1, [r15+0x190]
000074c3551d5bb8  vmovaps [rsp+0x90], xmm1
000074c3551d5bc1  vmovaps [rsp+0xD0], xmm15
000074c3551d5bca  vmovaps xmm15, [rsp+0x90]
000074c3551d5bd3  por xmm1, xmm15
000074c3551d5bd8  movaps xmm15, [r15+0x300]
000074c3551d5be0  vmovaps [rsp+0x90], xmm15
000074c3551d5be9  vmovaps [rsp+0xE0], xmm1
000074c3551d5bf2  vmovaps xmm1, [rsp+0x90]
000074c3551d5bfb  por xmm15, xmm1
000074c3551d5c00  mov rax, [rsp+0x80]
000074c3551d5c08  lea r14, [rax+0xA0]
000074c3551d5c0f  movups xmm1, [r13+r14*1]
000074c3551d5c15  lea r14, [rax+0xB0]
000074c3551d5c1c  vmovaps [rsp+0x80], xmm1
000074c3551d5c25  movups xmm1, [r13+r14*1]
000074c3551d5c2b  vmovaps [rsp+0x90], xmm1
000074c3551d5c34  vmovaps [rsp+0xF0], xmm15
000074c3551d5c3d  vmovaps xmm15, [rsp+0xB0]
000074c3551d5c46  vmovaps [rsp+0xB0], xmm14
000074c3551d5c4f  movaps xmm1, xmm6
000074c3551d5c52  addpd xmm1, xmm15
000074c3551d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000074c3551d5c5c  ptest xmm14, xmm14
000074c3551d5c62  jnz 0x000074C3551D7323
000074c3551d5c68  lea r14, [rax+0xF0]
000074c3551d5c6f  movups xmm15, [r13+r14*1]
000074c3551d5c75  movaps xmm14, xmm4
000074c3551d5c79  addpd xmm14, xmm3
000074c3551d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000074c3551d5c84  ptest xmm6, xmm6
000074c3551d5c89  jnz 0x000074C3551D746E
000074c3551d5c8f  movaps xmm6, xmm9
000074c3551d5c93  addpd xmm6, xmm7
000074c3551d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000074c3551d5c9c  ptest xmm4, xmm4
000074c3551d5ca1  jnz 0x000074C3551D75B0
000074c3551d5ca7  vmovaps xmm9, [rsp+0x70]
000074c3551d5cad  vpermilpd xmm9, xmm9, 0x00
000074c3551d5cb3  vmovaps xmm4, [rsp+0x90]
000074c3551d5cbc  movaps xmm7, xmm4
000074c3551d5cbf  mulpd xmm7, xmm9
000074c3551d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000074c3551d5cc9  ptest xmm3, xmm3
000074c3551d5cce  jnz 0x000074C3551D76F1
000074c3551d5cd4  vmovaps xmm9, [rsp+0x50]
000074c3551d5cda  vpermilpd xmm9, xmm9, 0x00
000074c3551d5ce0  movaps xmm4, xmm15
000074c3551d5ce4  mulpd xmm4, xmm9
000074c3551d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000074c3551d5cee  ptest xmm3, xmm3
000074c3551d5cf3  jnz 0x000074C3551D7832
000074c3551d5cf9  lea r14, [rax+0xE0]
000074c3551d5d00  movups xmm15, [r13+r14*1]
000074c3551d5d06  vmovaps xmm9, [rsp+0x70]
000074c3551d5d0c  vpermilpd xmm9, xmm9, 0x00
000074c3551d5d12  vmovaps [rsp+0x70], xmm1
000074c3551d5d18  vmovaps xmm1, [rsp+0x80]
000074c3551d5d21  vmovaps [rsp+0x80], xmm15
000074c3551d5d2a  movaps xmm3, xmm1
000074c3551d5d2d  mulpd xmm3, xmm9
000074c3551d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000074c3551d5d37  ptest xmm15, xmm15
000074c3551d5d3d  jnz 0x000074C3551D797E
000074c3551d5d43  vmovaps xmm1, [rsp+0xF0]
000074c3551d5d4c  vmovaps xmm15, [rsp+0xF0]
000074c3551d5d55  por xmm1, xmm15
000074c3551d5d5a  movaps [r15+0x300], xmm1
000074c3551d5d62  vmovaps xmm15, [rsp+0xE0]
000074c3551d5d6b  vmovaps xmm9, [rsp+0xE0]
000074c3551d5d74  por xmm15, xmm9
000074c3551d5d79  movaps [r15+0x190], xmm15
000074c3551d5d81  vmovaps xmm9, [rsp+0x50]
000074c3551d5d87  vpermilpd xmm9, xmm9, 0x00
000074c3551d5d8d  vmovaps [rsp+0x90], xmm1
000074c3551d5d96  vmovaps [rsp+0xE0], xmm15
000074c3551d5d9f  vmovaps xmm15, [rsp+0x80]
000074c3551d5da8  vmovaps [rsp+0x80], xmm14
000074c3551d5db1  movaps xmm1, xmm15
000074c3551d5db5  mulpd xmm1, xmm9
000074c3551d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000074c3551d5dbf  ptest xmm14, xmm14
000074c3551d5dc5  jnz 0x000074C3551D7ABF
000074c3551d5dcb  lea r14, [rax+0x90]
000074c3551d5dd2  movups xmm15, [r13+r14*1]
000074c3551d5dd8  vmovaps xmm14, [rsp+0xD0]
000074c3551d5de1  vmovaps xmm9, [rsp+0xD0]
000074c3551d5dea  por xmm14, xmm9
000074c3551d5def  movaps [r15+0x1C0], xmm14
000074c3551d5df7  vmovaps xmm9, [rsp+0xC0]
000074c3551d5e00  vmovaps [rsp+0xD0], xmm1
000074c3551d5e09  vmovaps xmm1, [rsp+0xC0]
000074c3551d5e12  por xmm9, xmm1
000074c3551d5e17  movaps [r15+0x200], xmm9
000074c3551d5e1f  vmovaps [rsp+0xC0], xmm2
000074c3551d5e28  vmovaps xmm1, [rsp+0xC0]
000074c3551d5e31  por xmm2, xmm1
000074c3551d5e35  movaps [r15+0x2D0], xmm2
000074c3551d5e3d  vmovaps [rsp+0xC0], xmm8
000074c3551d5e46  vmovaps xmm1, [rsp+0xC0]
000074c3551d5e4f  por xmm8, xmm1
000074c3551d5e54  movaps [r15+0x2E0], xmm8
000074c3551d5e5c  vmovaps [rsp+0xC0], xmm15
000074c3551d5e65  movaps xmm1, xmm5
000074c3551d5e68  addpd xmm1, xmm7
000074c3551d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000074c3551d5e71  ptest xmm15, xmm15
000074c3551d5e77  jnz 0x000074C3551D7C0B
000074c3551d5e7d  vmovaps xmm15, [rsp+0x50]
000074c3551d5e83  vpermilpd xmm15, xmm15, 0x00
000074c3551d5e89  vmovaps xmm5, [rsp+0xC0]
000074c3551d5e92  vmovaps [rsp+0xC0], xmm1
000074c3551d5e9b  movaps xmm7, xmm5
000074c3551d5e9e  mulpd xmm7, xmm15
000074c3551d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000074c3551d5ea8  ptest xmm1, xmm1
000074c3551d5ead  jnz 0x000074C3551D7D4B
000074c3551d5eb3  lea r14, [rax+0x80]
000074c3551d5eba  movups xmm1, [r13+r14*1]
000074c3551d5ec0  vmovaps xmm5, [rsp+0x70]
000074c3551d5ec6  vmovaps [rsp+0x70], xmm1
000074c3551d5ecc  movaps xmm15, xmm5
000074c3551d5ed0  addpd xmm15, xmm3
000074c3551d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000074c3551d5edb  ptest xmm1, xmm1
000074c3551d5ee0  jnz 0x000074C3551D7E96
000074c3551d5ee6  vmovaps xmm5, [rsp+0x80]
000074c3551d5eef  movaps xmm1, xmm5
000074c3551d5ef2  addpd xmm1, xmm4
000074c3551d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000074c3551d5efb  ptest xmm3, xmm3
000074c3551d5f00  jnz 0x000074C3551D7FD8
000074c3551d5f06  vmovaps [rsp+0x80], xmm10
000074c3551d5f0f  vmovaps xmm5, [rsp+0x80]
000074c3551d5f18  por xmm10, xmm5
000074c3551d5f1d  movaps [r15+0x2F0], xmm10
000074c3551d5f25  vmovaps xmm5, [rsp+0x50]
000074c3551d5f2b  vpermilpd xmm5, xmm5, 0x00
000074c3551d5f31  vmovaps xmm3, [rsp+0x70]
000074c3551d5f37  vmovaps [rsp+0x50], xmm1
000074c3551d5f3d  movaps xmm4, xmm3
000074c3551d5f40  mulpd xmm4, xmm5
000074c3551d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000074c3551d5f49  ptest xmm1, xmm1
000074c3551d5f4e  jnz 0x000074C3551D8118
000074c3551d5f54  lea r14, [rax+0xD0]
000074c3551d5f5b  movups xmm1, [r13+r14*1]
000074c3551d5f61  vmovaps xmm3, [rsp+0xD0]
000074c3551d5f6a  vmovaps [rsp+0x70], xmm1
000074c3551d5f70  movaps xmm5, xmm6
000074c3551d5f73  addpd xmm5, xmm3
000074c3551d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000074c3551d5f7c  ptest xmm1, xmm1
000074c3551d5f81  jnz 0x000074C3551D8262
000074c3551d5f87  vmovaps xmm1, [rsp+0x60]
000074c3551d5f8d  vpermilpd xmm1, xmm1, 0x00
000074c3551d5f93  movaps xmm6, xmm9
000074c3551d5f97  mulpd xmm6, xmm1
000074c3551d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000074c3551d5fa0  ptest xmm3, xmm3
000074c3551d5fa5  jnz 0x000074C3551D83A2
000074c3551d5fab  movaps [r15+0x260], xmm6
000074c3551d5fb3  vxorps xmm1, xmm1, xmm1
000074c3551d5fb7  vpbroadcastq xmm1, xmm1
000074c3551d5fbc  movaps [r15+0x1B0], xmm1
000074c3551d5fc4  vmovaps xmm1, [rsp+0x60]
000074c3551d5fca  vpermilpd xmm1, xmm1, 0x00
000074c3551d5fd0  vmovaps xmm3, [rsp+0x70]
000074c3551d5fd6  vmovaps [rsp+0x70], xmm15
000074c3551d5fdc  movaps xmm9, xmm3
000074c3551d5fe0  mulpd xmm9, xmm1
000074c3551d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000074c3551d5feb  ptest xmm15, xmm15
000074c3551d5ff1  jnz 0x000074C3551D84E3
000074c3551d5ff7  lea r14, [rax+0xC0]
000074c3551d5ffe  movups xmm1, [r13+r14*1]
000074c3551d6004  vmovaps xmm3, [rsp+0xC0]
000074c3551d600d  vmovaps [rsp+0x80], xmm1
000074c3551d6016  movaps xmm15, xmm3
000074c3551d601a  addpd xmm15, xmm7
000074c3551d601f  vcmppd xmm1, xmm15, xmm15, 0x03
000074c3551d6025  ptest xmm1, xmm1
000074c3551d602a  jnz 0x000074C3551D862F
000074c3551d6030  vmovaps [rsp+0xC0], xmm13
000074c3551d6039  vmovaps xmm1, [rsp+0xC0]
000074c3551d6042  por xmm13, xmm1
000074c3551d6047  movaps [r15+0x270], xmm13
000074c3551d604f  vmovaps xmm1, [rsp+0xB0]
000074c3551d6058  vmovaps xmm7, [rsp+0xB0]
000074c3551d6061  por xmm1, xmm7
000074c3551d6065  movaps [r15+0x1A0], xmm1
000074c3551d606d  vmovaps xmm1, [rsp+0x60]
000074c3551d6073  vpermilpd xmm1, xmm1, 0x00
000074c3551d6079  vmovaps [rsp+0xB0], xmm1
000074c3551d6082  vmovaps xmm1, [rsp+0x80]
000074c3551d608b  vmovaps [rsp+0x80], xmm15
000074c3551d6094  vmovaps xmm15, [rsp+0xB0]
000074c3551d609d  vmovaps [rsp+0xB0], xmm14
000074c3551d60a6  movaps xmm3, xmm1
000074c3551d60a9  mulpd xmm3, xmm15
000074c3551d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000074c3551d60b3  ptest xmm14, xmm14
000074c3551d60b9  jnz 0x000074C3551D8771
000074c3551d60bf  lea r14, [rax+0x20]
000074c3551d60c3  movups xmm1, [r13+r14*1]
000074c3551d60c9  movaps [r15+0x110], xmm1
000074c3551d60d1  vmovaps xmm14, [rsp+0x70]
000074c3551d60d7  vmovaps [rsp+0x70], xmm1
000074c3551d60dd  movaps xmm15, xmm14
000074c3551d60e1  addpd xmm15, xmm4
000074c3551d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000074c3551d60ec  ptest xmm1, xmm1
000074c3551d60f1  jnz 0x000074C3551D88BC
000074c3551d60f7  vmovaps xmm1, [rsp+0x60]
000074c3551d60fd  vpermilpd xmm1, xmm1, 0x00
000074c3551d6103  movaps xmm14, xmm2
000074c3551d6107  mulpd xmm14, xmm1
000074c3551d610c  vcmppd xmm4, xmm14, xmm14, 0x03
000074c3551d6112  ptest xmm4, xmm4
000074c3551d6117  jnz 0x000074C3551D89FF
000074c3551d611d  vmovaps xmm4, [rsp+0x50]
000074c3551d6123  movaps xmm1, xmm4
000074c3551d6126  addpd xmm1, xmm9
000074c3551d612b  vcmppd xmm2, xmm1, xmm1, 0x03
000074c3551d6130  ptest xmm2, xmm2
000074c3551d6135  jnz 0x000074C3551D8B41
000074c3551d613b  vmovaps xmm9, [rsp+0x30]
000074c3551d6141  vpermilpd xmm9, xmm9, 0x00
000074c3551d6147  vmovaps xmm2, [rsp+0x70]
000074c3551d614d  vmovaps [rsp+0x50], xmm1
000074c3551d6153  movaps xmm4, xmm2
000074c3551d6156  mulpd xmm4, xmm9
000074c3551d615b  vcmppd xmm1, xmm4, xmm4, 0x03
000074c3551d6160  ptest xmm1, xmm1
000074c3551d6165  jnz 0x000074C3551D8C82
000074c3551d616b  vmovaps xmm1, [rsp+0x30]
000074c3551d6171  vpermilpd xmm1, xmm1, 0x00
000074c3551d6177  vmovaps xmm2, [rsp+0x90]
000074c3551d6180  vmovaps [rsp+0x60], xmm15
000074c3551d6186  movaps xmm9, xmm2
000074c3551d618a  mulpd xmm9, xmm1
000074c3551d618f  vcmppd xmm15, xmm9, xmm9, 0x03
000074c3551d6195  ptest xmm15, xmm15
000074c3551d619b  jnz 0x000074C3551D8DC3
000074c3551d61a1  vmovaps xmm15, [rsp+0x80]
000074c3551d61aa  movaps xmm1, xmm15
000074c3551d61ae  addpd xmm1, xmm6
000074c3551d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000074c3551d61b7  ptest xmm2, xmm2
000074c3551d61bc  jnz 0x000074C3551D8F05
000074c3551d61c2  movaps xmm15, xmm5
000074c3551d61c6  addpd xmm15, xmm3
000074c3551d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000074c3551d61d1  ptest xmm6, xmm6
000074c3551d61d6  jnz 0x000074C3551D9046
000074c3551d61dc  vmovaps xmm6, [rsp+0x30]
000074c3551d61e2  vpermilpd xmm6, xmm6, 0x00
000074c3551d61e8  movaps xmm5, xmm8
000074c3551d61ec  mulpd xmm5, xmm6
000074c3551d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000074c3551d61f5  ptest xmm3, xmm3
000074c3551d61fa  jnz 0x000074C3551D9188
000074c3551d6200  vmovaps xmm8, [rsp+0x30]
000074c3551d6206  vpermilpd xmm8, xmm8, 0x00
000074c3551d620c  movaps xmm6, xmm10
000074c3551d6210  mulpd xmm6, xmm8
000074c3551d6215  vcmppd xmm3, xmm6, xmm6, 0x03
000074c3551d621a  ptest xmm3, xmm3
000074c3551d621f  jnz 0x000074C3551D92C9
000074c3551d6225  vmovaps xmm8, [rsp+0x60]
000074c3551d622b  movaps xmm10, xmm8
000074c3551d622f  addpd xmm10, xmm14
000074c3551d6234  vcmppd xmm3, xmm10, xmm10, 0x03
000074c3551d623a  ptest xmm3, xmm3
000074c3551d623f  jnz 0x000074C3551D940B
000074c3551d6245  vmovaps xmm8, [rsp+0x50]
000074c3551d624b  movaps xmm14, xmm8
000074c3551d624f  addpd xmm14, xmm4
000074c3551d6254  vcmppd xmm3, xmm14, xmm14, 0x03
000074c3551d625a  ptest xmm3, xmm3
000074c3551d625f  jnz 0x000074C3551D954F
000074c3551d6265  vmovaps xmm8, [rsp+0x40]
000074c3551d626b  vpermilpd xmm8, xmm8, 0x00
000074c3551d6271  movaps xmm4, xmm13
000074c3551d6275  mulpd xmm4, xmm8
000074c3551d627a  vcmppd xmm3, xmm4, xmm4, 0x03
000074c3551d627f  ptest xmm3, xmm3
000074c3551d6284  jnz 0x000074C3551D9692
000074c3551d628a  movaps xmm13, xmm15
000074c3551d628e  addpd xmm13, xmm9
000074c3551d6293  vcmppd xmm8, xmm13, xmm13, 0x03
000074c3551d6299  ptest xmm8, xmm8
000074c3551d629f  jnz 0x000074C3551D97D4
000074c3551d62a5  movaps xmm15, xmm1
000074c3551d62a9  addpd xmm15, xmm5
000074c3551d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000074c3551d62b4  ptest xmm9, xmm9
000074c3551d62ba  jnz 0x000074C3551D9918
000074c3551d62c0  vmovaps [rsp+0x30], xmm11
000074c3551d62c6  vmovaps xmm1, [rsp+0x30]
000074c3551d62cc  por xmm11, xmm1
000074c3551d62d1  movaps [r15+0x250], xmm11
000074c3551d62d9  vmovaps [rsp+0x30], xmm12
000074c3551d62df  vmovaps xmm1, [rsp+0x30]
000074c3551d62e5  por xmm12, xmm1
000074c3551d62ea  movaps [r15+0x2A0], xmm12
000074c3551d62f2  vmovaps xmm1, [rsp+0xA0]
000074c3551d62fb  vmovaps xmm11, [rsp+0xA0]
000074c3551d6304  por xmm1, xmm11
000074c3551d6309  movaps [r15+0x1D0], xmm1
000074c3551d6311  lea r14, [rax+0x40]
000074c3551d6315  movups xmm1, [r13+r14*1]
000074c3551d631b  movaps [r15+0x2C0], xmm1
000074c3551d6323  vmovaps xmm11, [rsp+0x40]
000074c3551d6329  vpermilpd xmm11, xmm11, 0x00
000074c3551d632f  vmovaps xmm8, [rsp+0xE0]
000074c3551d6338  movaps xmm9, xmm8
000074c3551d633c  mulpd xmm9, xmm11
000074c3551d6341  vcmppd xmm5, xmm9, xmm9, 0x03
000074c3551d6347  ptest xmm5, xmm5
000074c3551d634c  jnz 0x000074C3551D9A64
000074c3551d6352  movaps xmm11, xmm10
000074c3551d6356  addpd xmm11, xmm6
000074c3551d635b  vcmppd xmm8, xmm11, xmm11, 0x03
000074c3551d6361  ptest xmm8, xmm8
000074c3551d6367  jnz 0x000074C3551D9BA8
000074c3551d636d  movaps xmm10, xmm14
000074c3551d6371  addpd xmm10, xmm4
000074c3551d6376  vcmppd xmm8, xmm10, xmm10, 0x03
000074c3551d637c  ptest xmm8, xmm8
000074c3551d6382  jnz 0x000074C3551D9CEB
000074c3551d6388  vmovaps xmm14, [rsp+0x40]
000074c3551d638e  vpermilpd xmm14, xmm14, 0x00
000074c3551d6394  movaps xmm8, xmm1
000074c3551d6398  mulpd xmm8, xmm14
000074c3551d639d  vcmppd xmm6, xmm8, xmm8, 0x03
000074c3551d63a3  ptest xmm6, xmm6
000074c3551d63a8  jnz 0x000074C3551D9E2E
000074c3551d63ae  movaps xmm1, [r15+0x2B0]
000074c3551d63b6  vmovaps xmm14, [rsp+0x40]
000074c3551d63bc  vpermilpd xmm14, xmm14, 0x00
000074c3551d63c2  movaps xmm6, xmm1
000074c3551d63c5  mulpd xmm6, xmm14
000074c3551d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000074c3551d63cf  ptest xmm5, xmm5
000074c3551d63d4  jnz 0x000074C3551D9F71
000074c3551d63da  vmovaps xmm1, [rsp+0x10]
000074c3551d63e0  vpermilpd xmm1, xmm1, 0x00
000074c3551d63e6  movaps xmm14, xmm12
000074c3551d63ea  mulpd xmm14, xmm1
000074c3551d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000074c3551d63f5  ptest xmm5, xmm5
000074c3551d63fa  jnz 0x000074C3551DA0B2
000074c3551d6400  movaps xmm1, xmm13
000074c3551d6404  addpd xmm1, xmm9
000074c3551d6409  vcmppd xmm12, xmm1, xmm1, 0x03
000074c3551d640e  ptest xmm12, xmm12
000074c3551d6414  jnz 0x000074C3551DA1F5
000074c3551d641a  vmovaps xmm13, [rsp+0x10]
000074c3551d6420  vpermilpd xmm13, xmm13, 0x00
000074c3551d6426  movaps xmm12, xmm7
000074c3551d642a  mulpd xmm12, xmm13
000074c3551d642f  vcmppd xmm9, xmm12, xmm12, 0x03
000074c3551d6435  ptest xmm9, xmm9
000074c3551d643b  jnz 0x000074C3551DA337
000074c3551d6441  movaps xmm13, xmm15
000074c3551d6445  addpd xmm13, xmm8
000074c3551d644a  vcmppd xmm9, xmm13, xmm13, 0x03
000074c3551d6450  ptest xmm9, xmm9
000074c3551d6456  jnz 0x000074C3551DA47A
000074c3551d645c  movaps xmm15, [r15+0x290]
000074c3551d6464  vmovaps xmm9, [rsp+0x10]
000074c3551d646a  vpermilpd xmm9, xmm9, 0x00
000074c3551d6470  movaps xmm8, xmm15
000074c3551d6474  mulpd xmm8, xmm9
000074c3551d6479  vcmppd xmm7, xmm8, xmm8, 0x03
000074c3551d647f  ptest xmm7, xmm7
000074c3551d6484  jnz 0x000074C3551DA5BE
000074c3551d648a  movaps xmm15, xmm11
000074c3551d648e  addpd xmm15, xmm6
000074c3551d6493  vcmppd xmm9, xmm15, xmm15, 0x03
000074c3551d6499  ptest xmm9, xmm9
000074c3551d649f  jnz 0x000074C3551DA702
000074c3551d64a5  movaps xmm11, [r15+0x1E0]
000074c3551d64ad  vmovaps xmm9, [rsp+0x10]
000074c3551d64b3  vpermilpd xmm9, xmm9, 0x00
000074c3551d64b9  movaps xmm7, xmm11
000074c3551d64bd  mulpd xmm7, xmm9
000074c3551d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000074c3551d64c7  ptest xmm6, xmm6
000074c3551d64cc  jnz 0x000074C3551DA845
000074c3551d64d2  movaps xmm11, xmm10
000074c3551d64d6  addpd xmm11, xmm14
000074c3551d64db  vcmppd xmm9, xmm11, xmm11, 0x03
000074c3551d64e1  ptest xmm9, xmm9
000074c3551d64e7  jnz 0x000074C3551DA987
000074c3551d64ed  lea r14, [rax+0x70]
000074c3551d64f1  movups xmm14, [r13+r14*1]
000074c3551d64f7  movaps [r15+0x240], xmm14
000074c3551d64ff  movaps xmm10, xmm1
000074c3551d6503  addpd xmm10, xmm12
000074c3551d6508  vcmppd xmm9, xmm10, xmm10, 0x03
000074c3551d650e  ptest xmm9, xmm9
000074c3551d6514  jnz 0x000074C3551DAAD5
000074c3551d651a  movaps [r15+0x170], xmm10
000074c3551d6522  vmovaps xmm1, [rsp+0x20]
000074c3551d6528  vpermilpd xmm1, xmm1, 0x00
000074c3551d652e  movaps xmm12, xmm14
000074c3551d6532  mulpd xmm12, xmm1
000074c3551d6537  vcmppd xmm9, xmm12, xmm12, 0x03
000074c3551d653d  ptest xmm9, xmm9
000074c3551d6543  jnz 0x000074C3551DAC18
000074c3551d6549  vmovaps xmm1, [rsp+0x20]
000074c3551d654f  vpermilpd xmm1, xmm1, 0x00
000074c3551d6555  vmovaps xmm9, [rsp+0xB0]
000074c3551d655e  movaps xmm14, xmm9
000074c3551d6562  mulpd xmm14, xmm1
000074c3551d6567  vcmppd xmm6, xmm14, xmm14, 0x03
000074c3551d656d  ptest xmm6, xmm6
000074c3551d6572  jnz 0x000074C3551DAD5B
000074c3551d6578  movaps [r15+0x180], xmm14
000074c3551d6580  movaps xmm1, xmm13
000074c3551d6584  addpd xmm1, xmm8
000074c3551d6589  vcmppd xmm9, xmm1, xmm1, 0x03
000074c3551d658e  ptest xmm9, xmm9
000074c3551d6594  jnz 0x000074C3551DAE9E
000074c3551d659a  movaps [r15+0x210], xmm1
000074c3551d65a2  movups xmm13, [r13+rax*1]
000074c3551d65a8  lea r14, [rax+0x10]
000074c3551d65ac  movups xmm9, [r13+r14*1]
000074c3551d65b2  movaps [r15+0x230], xmm9
000074c3551d65ba  movaps xmm8, xmm15
000074c3551d65be  addpd xmm8, xmm7
000074c3551d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000074c3551d65c9  ptest xmm6, xmm6
000074c3551d65ce  jnz 0x000074C3551DAFF4
000074c3551d65d4  movaps [r15+0x130], xmm8
000074c3551d65dc  vmovaps xmm15, [rsp+0x20]
000074c3551d65e2  vpermilpd xmm15, xmm15, 0x00
000074c3551d65e8  movaps xmm7, xmm9
000074c3551d65ec  mulpd xmm7, xmm15
000074c3551d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000074c3551d65f6  ptest xmm6, xmm6
000074c3551d65fb  jnz 0x000074C3551DB137
000074c3551d6601  movaps [r15+0x220], xmm7
000074c3551d6609  vmovaps xmm15, [rsp+0x20]
000074c3551d660f  vpermilpd xmm15, xmm15, 0x00
000074c3551d6615  movaps xmm9, xmm13
000074c3551d6619  mulpd xmm9, xmm15
000074c3551d661e  vcmppd xmm6, xmm9, xmm9, 0x03
000074c3551d6624  ptest xmm6, xmm6
000074c3551d6629  jnz 0x000074C3551DB279
000074c3551d662f  movaps xmm15, xmm11
000074c3551d6633  addpd xmm15, xmm12
000074c3551d6638  vcmppd xmm13, xmm15, xmm15, 0x03
000074c3551d663e  ptest xmm13, xmm13
000074c3551d6644  jnz 0x000074C3551DB3BD
000074c3551d664a  movaps [r15+0x140], xmm15
000074c3551d6652  movaps xmm13, xmm10
000074c3551d6656  addpd xmm13, xmm14
000074c3551d665b  vcmppd xmm12, xmm13, xmm13, 0x03
000074c3551d6661  ptest xmm12, xmm12
000074c3551d6667  jnz 0x000074C3551DB501
000074c3551d666d  movaps [r15+0x150], xmm13
000074c3551d6675  movaps xmm14, xmm1
000074c3551d6679  addpd xmm14, xmm7
000074c3551d667e  vcmppd xmm12, xmm14, xmm14, 0x03
000074c3551d6684  ptest xmm12, xmm12
000074c3551d668a  jnz 0x000074C3551DB645
000074c3551d6690  movaps [r15+0x160], xmm14
000074c3551d6698  movaps xmm1, xmm8
000074c3551d669c  addpd xmm1, xmm9
000074c3551d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000074c3551d66a6  ptest xmm12, xmm12
000074c3551d66ac  jnz 0x000074C3551DB787
000074c3551d66b2  movaps [r15+0x120], xmm1
000074c3551d66ba  movups [r13+r11*1], xmm15
000074c3551d66c0  lea rax, [r11+0x10]
000074c3551d66c4  movups [r13+rax*1], xmm13
000074c3551d66ca  lea rax, [r11+0x20]
000074c3551d66ce  movups [r13+rax*1], xmm14
000074c3551d66d4  lea rax, [r11+0x30]
000074c3551d66d8  movups [r13+rax*1], xmm1
000074c3551d66de  mov eax, [r15+0x108]
000074c3551d66e5  sahf
000074c3551d66e6  jnz 0x000074C3551D6718
000074c3551d66e8  cmp dword ptr [r15+0x318], 0x00
000074c3551d66f0  jz 0x000074C3551DB900
000074c3551d66f6  nop [rax+rax*1], ax
000074c3551d66ff  nop [rax+rax*1], eax
000074c3551d6707  mov eax, 0x410444
000074c3551d670c  mov [r15+0x100], rax
000074c3551d6713  jmp 0x000074C354FFE110
000074c3551d6718  cmp dword ptr [r15+0x318], 0x00
000074c3551d6720  jz 0x000074C3551D57E0
000074c3551d6726  nop [rax+rax*1], ax
000074c3551d672f  nop [rax+rax*1], eax
000074c3551d6737  mov eax, 0x410278
000074c3551d673c  mov [r15+0x100], rax
000074c3551d6743  jmp 0x000074C354FFE110
000074c3551d6748  int3
000074c3551d6749  call 0x000074C35500A4B0
000074c3551d674e  jmp 0x000074C3551D5828
000074c3551d6753  call 0x000074C355009240
000074c3551d6758  jmp 0x000074C3551D5832
000074c3551d675d  call 0x000074C35500A4B0
000074c3551d6762  jmp 0x000074C3551D588F
000074c3551d6767  call 0x000074C355009240
000074c3551d676c  jmp 0x000074C3551D5899
000074c3551d6771  call 0x000074C35500A4B0
000074c3551d6776  jmp 0x000074C3551D58DD
000074c3551d677b  call 0x000074C355009240
000074c3551d6780  jmp 0x000074C3551D58E7
000074c3551d6785  call 0x000074C3550B47C0
000074c3551d678a  jmp 0x000074C3551D5926
000074c3551d678f  call 0x000074C35500B720
000074c3551d6794  jmp 0x000074C3551D593A
000074c3551d6799  call 0x000074C3550BFC30
000074c3551d679e  jmp 0x000074C3551D5958
000074c3551d67a3  call 0x000074C3550BE9C0
000074c3551d67a8  jmp 0x000074C3551D5962
000074c3551d67ad  call 0x000074C3550BD750
000074c3551d67b2  jmp 0x000074C3551D596C
000074c3551d67b7  sub rsp, 0x08
000074c3551d67bb  push rax
000074c3551d67bc  push rcx
000074c3551d67bd  push rdx
000074c3551d67be  push rdi
000074c3551d67bf  push rsi
000074c3551d67c0  push r8
000074c3551d67c2  push r9
000074c3551d67c4  push r10
000074c3551d67c6  push r11
000074c3551d67c8  sub rsp, 0xF0
000074c3551d67cf  vmovaps [rsp], xmm0
000074c3551d67d4  vmovaps [rsp+0x10], xmm1
000074c3551d67da  vmovaps [rsp+0x20], xmm2
000074c3551d67e0  vmovaps [rsp+0x30], xmm3
000074c3551d67e6  vmovaps [rsp+0x40], xmm4
000074c3551d67ec  vmovaps [rsp+0x50], xmm5
000074c3551d67f2  vmovaps [rsp+0x60], xmm6
000074c3551d67f8  vmovaps [rsp+0x70], xmm7
000074c3551d67fe  vmovaps [rsp+0x80], xmm9
000074c3551d6807  vmovaps [rsp+0x90], xmm10
000074c3551d6810  vmovaps [rsp+0xA0], xmm11
000074c3551d6819  vmovaps [rsp+0xB0], xmm12
000074c3551d6822  vmovaps [rsp+0xC0], xmm13
000074c3551d682b  vmovaps [rsp+0xD0], xmm14
000074c3551d6834  vmovaps [rsp+0xE0], xmm15
000074c3551d683d  sub rsp, 0x30
000074c3551d6841  movaps [rsp], xmm8
000074c3551d6846  movaps [rsp+0x10], xmm12
000074c3551d684c  movaps [rsp+0x20], xmm15
000074c3551d6852  lea rdi, [rsp]
000074c3551d6856  mov esi, 0x00
000074c3551d685b  mov rax, 0x5F9407FA9530
000074c3551d6865  call rax
000074c3551d6867  movaps xmm8, [rsp]
000074c3551d686c  add rsp, 0x30
000074c3551d6870  vmovaps xmm0, [rsp]
000074c3551d6875  vmovaps xmm1, [rsp+0x10]
000074c3551d687b  vmovaps xmm2, [rsp+0x20]
000074c3551d6881  vmovaps xmm3, [rsp+0x30]
000074c3551d6887  vmovaps xmm4, [rsp+0x40]
000074c3551d688d  vmovaps xmm5, [rsp+0x50]
000074c3551d6893  vmovaps xmm6, [rsp+0x60]
000074c3551d6899  vmovaps xmm7, [rsp+0x70]
000074c3551d689f  vmovaps xmm9, [rsp+0x80]
000074c3551d68a8  vmovaps xmm10, [rsp+0x90]
000074c3551d68b1  vmovaps xmm11, [rsp+0xA0]
000074c3551d68ba  vmovaps xmm12, [rsp+0xB0]
000074c3551d68c3  vmovaps xmm13, [rsp+0xC0]
000074c3551d68cc  vmovaps xmm14, [rsp+0xD0]
000074c3551d68d5  vmovaps xmm15, [rsp+0xE0]
000074c3551d68de  add rsp, 0xF0
000074c3551d68e5  pop r11
000074c3551d68e7  pop r10
000074c3551d68e9  pop r9
000074c3551d68eb  pop r8
000074c3551d68ed  pop rsi
000074c3551d68ee  pop rdi
000074c3551d68ef  pop rdx
000074c3551d68f0  pop rcx
000074c3551d68f1  pop rax
000074c3551d68f2  add rsp, 0x08
000074c3551d68f6  jmp 0x000074C3551D599A
000074c3551d68fb  sub rsp, 0x08
000074c3551d68ff  push rax
000074c3551d6900  push rcx
000074c3551d6901  push rdx
000074c3551d6902  push rdi
000074c3551d6903  push rsi
000074c3551d6904  push r8
000074c3551d6906  push r9
000074c3551d6908  push r10
000074c3551d690a  push r11
000074c3551d690c  sub rsp, 0xF0
000074c3551d6913  vmovaps [rsp], xmm0
000074c3551d6918  vmovaps [rsp+0x10], xmm1
000074c3551d691e  vmovaps [rsp+0x20], xmm2
000074c3551d6924  vmovaps [rsp+0x30], xmm3
000074c3551d692a  vmovaps [rsp+0x40], xmm4
000074c3551d6930  vmovaps [rsp+0x50], xmm5
000074c3551d6936  vmovaps [rsp+0x60], xmm6
000074c3551d693c  vmovaps [rsp+0x70], xmm8
000074c3551d6942  vmovaps [rsp+0x80], xmm9
000074c3551d694b  vmovaps [rsp+0x90], xmm10
000074c3551d6954  vmovaps [rsp+0xA0], xmm11
000074c3551d695d  vmovaps [rsp+0xB0], xmm12
000074c3551d6966  vmovaps [rsp+0xC0], xmm13
000074c3551d696f  vmovaps [rsp+0xD0], xmm14
000074c3551d6978  vmovaps [rsp+0xE0], xmm15
000074c3551d6981  sub rsp, 0x30
000074c3551d6985  movaps [rsp], xmm7
000074c3551d6989  movaps [rsp+0x10], xmm9
000074c3551d698f  movaps [rsp+0x20], xmm15
000074c3551d6995  lea rdi, [rsp]
000074c3551d6999  mov esi, 0x00
000074c3551d699e  mov rax, 0x5F9407FA9530
000074c3551d69a8  call rax
000074c3551d69aa  movaps xmm7, [rsp]
000074c3551d69ae  add rsp, 0x30
000074c3551d69b2  vmovaps xmm0, [rsp]
000074c3551d69b7  vmovaps xmm1, [rsp+0x10]
000074c3551d69bd  vmovaps xmm2, [rsp+0x20]
000074c3551d69c3  vmovaps xmm3, [rsp+0x30]
000074c3551d69c9  vmovaps xmm4, [rsp+0x40]
000074c3551d69cf  vmovaps xmm5, [rsp+0x50]
000074c3551d69d5  vmovaps xmm6, [rsp+0x60]
000074c3551d69db  vmovaps xmm8, [rsp+0x70]
000074c3551d69e1  vmovaps xmm9, [rsp+0x80]
000074c3551d69ea  vmovaps xmm10, [rsp+0x90]
000074c3551d69f3  vmovaps xmm11, [rsp+0xA0]
000074c3551d69fc  vmovaps xmm12, [rsp+0xB0]
000074c3551d6a05  vmovaps xmm13, [rsp+0xC0]
000074c3551d6a0e  vmovaps xmm14, [rsp+0xD0]
000074c3551d6a17  vmovaps xmm15, [rsp+0xE0]
000074c3551d6a20  add rsp, 0xF0
000074c3551d6a27  pop r11
000074c3551d6a29  pop r10
000074c3551d6a2b  pop r9
000074c3551d6a2d  pop r8
000074c3551d6a2f  pop rsi
000074c3551d6a30  pop rdi
000074c3551d6a31  pop rdx
000074c3551d6a32  pop rcx
000074c3551d6a33  pop rax
000074c3551d6a34  add rsp, 0x08
000074c3551d6a38  jmp 0x000074C3551D59C8
000074c3551d6a3d  sub rsp, 0x08
000074c3551d6a41  push rax
000074c3551d6a42  push rcx
000074c3551d6a43  push rdx
000074c3551d6a44  push rdi
000074c3551d6a45  push rsi
000074c3551d6a46  push r8
000074c3551d6a48  push r9
000074c3551d6a4a  push r10
000074c3551d6a4c  push r11
000074c3551d6a4e  sub rsp, 0xF0
000074c3551d6a55  vmovaps [rsp], xmm0
000074c3551d6a5a  vmovaps [rsp+0x10], xmm1
000074c3551d6a60  vmovaps [rsp+0x20], xmm2
000074c3551d6a66  vmovaps [rsp+0x30], xmm3
000074c3551d6a6c  vmovaps [rsp+0x40], xmm4
000074c3551d6a72  vmovaps [rsp+0x50], xmm5
000074c3551d6a78  vmovaps [rsp+0x60], xmm6
000074c3551d6a7e  vmovaps [rsp+0x70], xmm7
000074c3551d6a84  vmovaps [rsp+0x80], xmm8
000074c3551d6a8d  vmovaps [rsp+0x90], xmm10
000074c3551d6a96  vmovaps [rsp+0xA0], xmm11
000074c3551d6a9f  vmovaps [rsp+0xB0], xmm12
000074c3551d6aa8  vmovaps [rsp+0xC0], xmm13
000074c3551d6ab1  vmovaps [rsp+0xD0], xmm14
000074c3551d6aba  vmovaps [rsp+0xE0], xmm15
000074c3551d6ac3  sub rsp, 0x30
000074c3551d6ac7  movaps [rsp], xmm9
000074c3551d6acc  movaps [rsp+0x10], xmm12
000074c3551d6ad2  movaps [rsp+0x20], xmm10
000074c3551d6ad8  lea rdi, [rsp]
000074c3551d6adc  mov esi, 0x00
000074c3551d6ae1  mov rax, 0x5F9407FA9530
000074c3551d6aeb  call rax
000074c3551d6aed  movaps xmm9, [rsp]
000074c3551d6af2  add rsp, 0x30
000074c3551d6af6  vmovaps xmm0, [rsp]
000074c3551d6afb  vmovaps xmm1, [rsp+0x10]
000074c3551d6b01  vmovaps xmm2, [rsp+0x20]
000074c3551d6b07  vmovaps xmm3, [rsp+0x30]
000074c3551d6b0d  vmovaps xmm4, [rsp+0x40]
000074c3551d6b13  vmovaps xmm5, [rsp+0x50]
000074c3551d6b19  vmovaps xmm6, [rsp+0x60]
000074c3551d6b1f  vmovaps xmm7, [rsp+0x70]
000074c3551d6b25  vmovaps xmm8, [rsp+0x80]
000074c3551d6b2e  vmovaps xmm10, [rsp+0x90]
000074c3551d6b37  vmovaps xmm11, [rsp+0xA0]
000074c3551d6b40  vmovaps xmm12, [rsp+0xB0]
000074c3551d6b49  vmovaps xmm13, [rsp+0xC0]
000074c3551d6b52  vmovaps xmm14, [rsp+0xD0]
000074c3551d6b5b  vmovaps xmm15, [rsp+0xE0]
000074c3551d6b64  add rsp, 0xF0
000074c3551d6b6b  pop r11
000074c3551d6b6d  pop r10
000074c3551d6b6f  pop r9
000074c3551d6b71  pop r8
000074c3551d6b73  pop rsi
000074c3551d6b74  pop rdi
000074c3551d6b75  pop rdx
000074c3551d6b76  pop rcx
000074c3551d6b77  pop rax
000074c3551d6b78  add rsp, 0x08
000074c3551d6b7c  jmp 0x000074C3551D59EC
000074c3551d6b81  sub rsp, 0x08
000074c3551d6b85  push rax
000074c3551d6b86  push rcx
000074c3551d6b87  push rdx
000074c3551d6b88  push rdi
000074c3551d6b89  push rsi
000074c3551d6b8a  push r8
000074c3551d6b8c  push r9
000074c3551d6b8e  push r10
000074c3551d6b90  push r11
000074c3551d6b92  sub rsp, 0xF0
000074c3551d6b99  vmovaps [rsp], xmm0
000074c3551d6b9e  vmovaps [rsp+0x10], xmm1
000074c3551d6ba4  vmovaps [rsp+0x20], xmm2
000074c3551d6baa  vmovaps [rsp+0x30], xmm3
000074c3551d6bb0  vmovaps [rsp+0x40], xmm4
000074c3551d6bb6  vmovaps [rsp+0x50], xmm5
000074c3551d6bbc  vmovaps [rsp+0x60], xmm6
000074c3551d6bc2  vmovaps [rsp+0x70], xmm7
000074c3551d6bc8  vmovaps [rsp+0x80], xmm8
000074c3551d6bd1  vmovaps [rsp+0x90], xmm9
000074c3551d6bda  vmovaps [rsp+0xA0], xmm11
000074c3551d6be3  vmovaps [rsp+0xB0], xmm12
000074c3551d6bec  vmovaps [rsp+0xC0], xmm13
000074c3551d6bf5  vmovaps [rsp+0xD0], xmm14
000074c3551d6bfe  vmovaps [rsp+0xE0], xmm15
000074c3551d6c07  sub rsp, 0x30
000074c3551d6c0b  movaps [rsp], xmm10
000074c3551d6c10  movaps [rsp+0x10], xmm12
000074c3551d6c16  movaps [rsp+0x20], xmm11
000074c3551d6c1c  lea rdi, [rsp]
000074c3551d6c20  mov esi, 0x00
000074c3551d6c25  mov rax, 0x5F9407FA9530
000074c3551d6c2f  call rax
000074c3551d6c31  movaps xmm10, [rsp]
000074c3551d6c36  add rsp, 0x30
000074c3551d6c3a  vmovaps xmm0, [rsp]
000074c3551d6c3f  vmovaps xmm1, [rsp+0x10]
000074c3551d6c45  vmovaps xmm2, [rsp+0x20]
000074c3551d6c4b  vmovaps xmm3, [rsp+0x30]
000074c3551d6c51  vmovaps xmm4, [rsp+0x40]
000074c3551d6c57  vmovaps xmm5, [rsp+0x50]
000074c3551d6c5d  vmovaps xmm6, [rsp+0x60]
000074c3551d6c63  vmovaps xmm7, [rsp+0x70]
000074c3551d6c69  vmovaps xmm8, [rsp+0x80]
000074c3551d6c72  vmovaps xmm9, [rsp+0x90]
000074c3551d6c7b  vmovaps xmm11, [rsp+0xA0]
000074c3551d6c84  vmovaps xmm12, [rsp+0xB0]
000074c3551d6c8d  vmovaps xmm13, [rsp+0xC0]
000074c3551d6c96  vmovaps xmm14, [rsp+0xD0]
000074c3551d6c9f  vmovaps xmm15, [rsp+0xE0]
000074c3551d6ca8  add rsp, 0xF0
000074c3551d6caf  pop r11
000074c3551d6cb1  pop r10
000074c3551d6cb3  pop r9
000074c3551d6cb5  pop r8
000074c3551d6cb7  pop rsi
000074c3551d6cb8  pop rdi
000074c3551d6cb9  pop rdx
000074c3551d6cba  pop rcx
000074c3551d6cbb  pop rax
000074c3551d6cbc  add rsp, 0x08
000074c3551d6cc0  jmp 0x000074C3551D5A06
000074c3551d6cc5  sub rsp, 0x08
000074c3551d6cc9  push rax
000074c3551d6cca  push rcx
000074c3551d6ccb  push rdx
000074c3551d6ccc  push rdi
000074c3551d6ccd  push rsi
000074c3551d6cce  push r8
000074c3551d6cd0  push r9
000074c3551d6cd2  push r10
000074c3551d6cd4  push r11
000074c3551d6cd6  sub rsp, 0xF0
000074c3551d6cdd  vmovaps [rsp], xmm0
000074c3551d6ce2  vmovaps [rsp+0x10], xmm1
000074c3551d6ce8  vmovaps [rsp+0x20], xmm2
000074c3551d6cee  vmovaps [rsp+0x30], xmm3
000074c3551d6cf4  vmovaps [rsp+0x40], xmm4
000074c3551d6cfa  vmovaps [rsp+0x50], xmm5
000074c3551d6d00  vmovaps [rsp+0x60], xmm7
000074c3551d6d06  vmovaps [rsp+0x70], xmm8
000074c3551d6d0c  vmovaps [rsp+0x80], xmm9
000074c3551d6d15  vmovaps [rsp+0x90], xmm10
000074c3551d6d1e  vmovaps [rsp+0xA0], xmm11
000074c3551d6d27  vmovaps [rsp+0xB0], xmm12
000074c3551d6d30  vmovaps [rsp+0xC0], xmm13
000074c3551d6d39  vmovaps [rsp+0xD0], xmm14
000074c3551d6d42  vmovaps [rsp+0xE0], xmm15
000074c3551d6d4b  sub rsp, 0x30
000074c3551d6d4f  movaps [rsp], xmm6
000074c3551d6d53  movaps [rsp+0x10], xmm12
000074c3551d6d59  movaps [rsp+0x20], xmm11
000074c3551d6d5f  lea rdi, [rsp]
000074c3551d6d63  mov esi, 0x00
000074c3551d6d68  mov rax, 0x5F9407FA9530
000074c3551d6d72  call rax
000074c3551d6d74  movaps xmm6, [rsp]
000074c3551d6d78  add rsp, 0x30
000074c3551d6d7c  vmovaps xmm0, [rsp]
000074c3551d6d81  vmovaps xmm1, [rsp+0x10]
000074c3551d6d87  vmovaps xmm2, [rsp+0x20]
000074c3551d6d8d  vmovaps xmm3, [rsp+0x30]
000074c3551d6d93  vmovaps xmm4, [rsp+0x40]
000074c3551d6d99  vmovaps xmm5, [rsp+0x50]
000074c3551d6d9f  vmovaps xmm7, [rsp+0x60]
000074c3551d6da5  vmovaps xmm8, [rsp+0x70]
000074c3551d6dab  vmovaps xmm9, [rsp+0x80]
000074c3551d6db4  vmovaps xmm10, [rsp+0x90]
000074c3551d6dbd  vmovaps xmm11, [rsp+0xA0]
000074c3551d6dc6  vmovaps xmm12, [rsp+0xB0]
000074c3551d6dcf  vmovaps xmm13, [rsp+0xC0]
000074c3551d6dd8  vmovaps xmm14, [rsp+0xD0]
000074c3551d6de1  vmovaps xmm15, [rsp+0xE0]
000074c3551d6dea  add rsp, 0xF0
000074c3551d6df1  pop r11
000074c3551d6df3  pop r10
000074c3551d6df5  pop r9
000074c3551d6df7  pop r8
000074c3551d6df9  pop rsi
000074c3551d6dfa  pop rdi
000074c3551d6dfb  pop rdx
000074c3551d6dfc  pop rcx
000074c3551d6dfd  pop rax
000074c3551d6dfe  add rsp, 0x08
000074c3551d6e02  jmp 0x000074C3551D5A27
000074c3551d6e07  sub rsp, 0x08
000074c3551d6e0b  push rax
000074c3551d6e0c  push rcx
000074c3551d6e0d  push rdx
000074c3551d6e0e  push rdi
000074c3551d6e0f  push rsi
000074c3551d6e10  push r8
000074c3551d6e12  push r9
000074c3551d6e14  push r10
000074c3551d6e16  push r11
000074c3551d6e18  sub rsp, 0xF0
000074c3551d6e1f  vmovaps [rsp], xmm0
000074c3551d6e24  vmovaps [rsp+0x10], xmm1
000074c3551d6e2a  vmovaps [rsp+0x20], xmm2
000074c3551d6e30  vmovaps [rsp+0x30], xmm4
000074c3551d6e36  vmovaps [rsp+0x40], xmm5
000074c3551d6e3c  vmovaps [rsp+0x50], xmm6
000074c3551d6e42  vmovaps [rsp+0x60], xmm7
000074c3551d6e48  vmovaps [rsp+0x70], xmm8
000074c3551d6e4e  vmovaps [rsp+0x80], xmm9
000074c3551d6e57  vmovaps [rsp+0x90], xmm10
000074c3551d6e60  vmovaps [rsp+0xA0], xmm11
000074c3551d6e69  vmovaps [rsp+0xB0], xmm12
000074c3551d6e72  vmovaps [rsp+0xC0], xmm13
000074c3551d6e7b  vmovaps [rsp+0xD0], xmm14
000074c3551d6e84  vmovaps [rsp+0xE0], xmm15
000074c3551d6e8d  sub rsp, 0x30
000074c3551d6e91  movaps [rsp], xmm3
000074c3551d6e95  movaps [rsp+0x10], xmm5
000074c3551d6e9a  movaps [rsp+0x20], xmm4
000074c3551d6e9f  lea rdi, [rsp]
000074c3551d6ea3  mov esi, 0x00
000074c3551d6ea8  mov rax, 0x5F9407FA9530
000074c3551d6eb2  call rax
000074c3551d6eb4  movaps xmm3, [rsp]
000074c3551d6eb8  add rsp, 0x30
000074c3551d6ebc  vmovaps xmm0, [rsp]
000074c3551d6ec1  vmovaps xmm1, [rsp+0x10]
000074c3551d6ec7  vmovaps xmm2, [rsp+0x20]
000074c3551d6ecd  vmovaps xmm4, [rsp+0x30]
000074c3551d6ed3  vmovaps xmm5, [rsp+0x40]
000074c3551d6ed9  vmovaps xmm6, [rsp+0x50]
000074c3551d6edf  vmovaps xmm7, [rsp+0x60]
000074c3551d6ee5  vmovaps xmm8, [rsp+0x70]
000074c3551d6eeb  vmovaps xmm9, [rsp+0x80]
000074c3551d6ef4  vmovaps xmm10, [rsp+0x90]
000074c3551d6efd  vmovaps xmm11, [rsp+0xA0]
000074c3551d6f06  vmovaps xmm12, [rsp+0xB0]
000074c3551d6f0f  vmovaps xmm13, [rsp+0xC0]
000074c3551d6f18  vmovaps xmm14, [rsp+0xD0]
000074c3551d6f21  vmovaps xmm15, [rsp+0xE0]
000074c3551d6f2a  add rsp, 0xF0
000074c3551d6f31  pop r11
000074c3551d6f33  pop r10
000074c3551d6f35  pop r9
000074c3551d6f37  pop r8
000074c3551d6f39  pop rsi
000074c3551d6f3a  pop rdi
000074c3551d6f3b  pop rdx
000074c3551d6f3c  pop rcx
000074c3551d6f3d  pop rax
000074c3551d6f3e  add rsp, 0x08
000074c3551d6f42  jmp 0x000074C3551D5A88
000074c3551d6f47  sub rsp, 0x08
000074c3551d6f4b  push rax
000074c3551d6f4c  push rcx
000074c3551d6f4d  push rdx
000074c3551d6f4e  push rdi
000074c3551d6f4f  push rsi
000074c3551d6f50  push r8
000074c3551d6f52  push r9
000074c3551d6f54  push r10
000074c3551d6f56  push r11
000074c3551d6f58  sub rsp, 0xF0
000074c3551d6f5f  vmovaps [rsp], xmm0
000074c3551d6f64  vmovaps [rsp+0x10], xmm1
000074c3551d6f6a  vmovaps [rsp+0x20], xmm2
000074c3551d6f70  vmovaps [rsp+0x30], xmm3
000074c3551d6f76  vmovaps [rsp+0x40], xmm4
000074c3551d6f7c  vmovaps [rsp+0x50], xmm6
000074c3551d6f82  vmovaps [rsp+0x60], xmm7
000074c3551d6f88  vmovaps [rsp+0x70], xmm8
000074c3551d6f8e  vmovaps [rsp+0x80], xmm9
000074c3551d6f97  vmovaps [rsp+0x90], xmm10
000074c3551d6fa0  vmovaps [rsp+0xA0], xmm11
000074c3551d6fa9  vmovaps [rsp+0xB0], xmm12
000074c3551d6fb2  vmovaps [rsp+0xC0], xmm13
000074c3551d6fbb  vmovaps [rsp+0xD0], xmm14
000074c3551d6fc4  vmovaps [rsp+0xE0], xmm15
000074c3551d6fcd  sub rsp, 0x30
000074c3551d6fd1  movaps [rsp], xmm5
000074c3551d6fd5  movaps [rsp+0x10], xmm8
000074c3551d6fdb  movaps [rsp+0x20], xmm15
000074c3551d6fe1  lea rdi, [rsp]
000074c3551d6fe5  mov esi, 0x00
000074c3551d6fea  mov rax, 0x5F9407FA9530
000074c3551d6ff4  call rax
000074c3551d6ff6  movaps xmm5, [rsp]
000074c3551d6ffa  add rsp, 0x30
000074c3551d6ffe  vmovaps xmm0, [rsp]
000074c3551d7003  vmovaps xmm1, [rsp+0x10]
000074c3551d7009  vmovaps xmm2, [rsp+0x20]
000074c3551d700f  vmovaps xmm3, [rsp+0x30]
000074c3551d7015  vmovaps xmm4, [rsp+0x40]
000074c3551d701b  vmovaps xmm6, [rsp+0x50]
000074c3551d7021  vmovaps xmm7, [rsp+0x60]
000074c3551d7027  vmovaps xmm8, [rsp+0x70]
000074c3551d702d  vmovaps xmm9, [rsp+0x80]
000074c3551d7036  vmovaps xmm10, [rsp+0x90]
000074c3551d703f  vmovaps xmm11, [rsp+0xA0]
000074c3551d7048  vmovaps xmm12, [rsp+0xB0]
000074c3551d7051  vmovaps xmm13, [rsp+0xC0]
000074c3551d705a  vmovaps xmm14, [rsp+0xD0]
000074c3551d7063  vmovaps xmm15, [rsp+0xE0]
000074c3551d706c  add rsp, 0xF0
000074c3551d7073  pop r11
000074c3551d7075  pop r10
000074c3551d7077  pop r9
000074c3551d7079  pop r8
000074c3551d707b  pop rsi
000074c3551d707c  pop rdi
000074c3551d707d  pop rdx
000074c3551d707e  pop rcx
000074c3551d707f  pop rax
000074c3551d7080  add rsp, 0x08
000074c3551d7084  jmp 0x000074C3551D5AC0
000074c3551d7089  sub rsp, 0x08
000074c3551d708d  push rax
000074c3551d708e  push rcx
000074c3551d708f  push rdx
000074c3551d7090  push rdi
000074c3551d7091  push rsi
000074c3551d7092  push r8
000074c3551d7094  push r9
000074c3551d7096  push r10
000074c3551d7098  push r11
000074c3551d709a  sub rsp, 0xF0
000074c3551d70a1  vmovaps [rsp], xmm0
000074c3551d70a6  vmovaps [rsp+0x10], xmm1
000074c3551d70ac  vmovaps [rsp+0x20], xmm2
000074c3551d70b2  vmovaps [rsp+0x30], xmm3
000074c3551d70b8  vmovaps [rsp+0x40], xmm5
000074c3551d70be  vmovaps [rsp+0x50], xmm6
000074c3551d70c4  vmovaps [rsp+0x60], xmm7
000074c3551d70ca  vmovaps [rsp+0x70], xmm8
000074c3551d70d0  vmovaps [rsp+0x80], xmm9
000074c3551d70d9  vmovaps [rsp+0x90], xmm10
000074c3551d70e2  vmovaps [rsp+0xA0], xmm11
000074c3551d70eb  vmovaps [rsp+0xB0], xmm12
000074c3551d70f4  vmovaps [rsp+0xC0], xmm13
000074c3551d70fd  vmovaps [rsp+0xD0], xmm14
000074c3551d7106  vmovaps [rsp+0xE0], xmm15
000074c3551d710f  sub rsp, 0x30
000074c3551d7113  movaps [rsp], xmm4
000074c3551d7117  movaps [rsp+0x10], xmm9
000074c3551d711d  movaps [rsp+0x20], xmm8
000074c3551d7123  lea rdi, [rsp]
000074c3551d7127  mov esi, 0x00
000074c3551d712c  mov rax, 0x5F9407FA9530
000074c3551d7136  call rax
000074c3551d7138  movaps xmm4, [rsp]
000074c3551d713c  add rsp, 0x30
000074c3551d7140  vmovaps xmm0, [rsp]
000074c3551d7145  vmovaps xmm1, [rsp+0x10]
000074c3551d714b  vmovaps xmm2, [rsp+0x20]
000074c3551d7151  vmovaps xmm3, [rsp+0x30]
000074c3551d7157  vmovaps xmm5, [rsp+0x40]
000074c3551d715d  vmovaps xmm6, [rsp+0x50]
000074c3551d7163  vmovaps xmm7, [rsp+0x60]
000074c3551d7169  vmovaps xmm8, [rsp+0x70]
000074c3551d716f  vmovaps xmm9, [rsp+0x80]
000074c3551d7178  vmovaps xmm10, [rsp+0x90]
000074c3551d7181  vmovaps xmm11, [rsp+0xA0]
000074c3551d718a  vmovaps xmm12, [rsp+0xB0]
000074c3551d7193  vmovaps xmm13, [rsp+0xC0]
000074c3551d719c  vmovaps xmm14, [rsp+0xD0]
000074c3551d71a5  vmovaps xmm15, [rsp+0xE0]
000074c3551d71ae  add rsp, 0xF0
000074c3551d71b5  pop r11
000074c3551d71b7  pop r10
000074c3551d71b9  pop r9
000074c3551d71bb  pop r8
000074c3551d71bd  pop rsi
000074c3551d71be  pop rdi
000074c3551d71bf  pop rdx
000074c3551d71c0  pop rcx
000074c3551d71c1  pop rax
000074c3551d71c2  add rsp, 0x08
000074c3551d71c6  jmp 0x000074C3551D5AE1
000074c3551d71cb  sub rsp, 0x08
000074c3551d71cf  push rax
000074c3551d71d0  push rcx
000074c3551d71d1  push rdx
000074c3551d71d2  push rdi
000074c3551d71d3  push rsi
000074c3551d71d4  push r8
000074c3551d71d6  push r9
000074c3551d71d8  push r10
000074c3551d71da  push r11
000074c3551d71dc  sub rsp, 0xF0
000074c3551d71e3  vmovaps [rsp], xmm0
000074c3551d71e8  vmovaps [rsp+0x10], xmm1
000074c3551d71ee  vmovaps [rsp+0x20], xmm2
000074c3551d71f4  vmovaps [rsp+0x30], xmm3
000074c3551d71fa  vmovaps [rsp+0x40], xmm4
000074c3551d7200  vmovaps [rsp+0x50], xmm5
000074c3551d7206  vmovaps [rsp+0x60], xmm6
000074c3551d720c  vmovaps [rsp+0x70], xmm7
000074c3551d7212  vmovaps [rsp+0x80], xmm8
000074c3551d721b  vmovaps [rsp+0x90], xmm10
000074c3551d7224  vmovaps [rsp+0xA0], xmm11
000074c3551d722d  vmovaps [rsp+0xB0], xmm12
000074c3551d7236  vmovaps [rsp+0xC0], xmm13
000074c3551d723f  vmovaps [rsp+0xD0], xmm14
000074c3551d7248  vmovaps [rsp+0xE0], xmm15
000074c3551d7251  sub rsp, 0x30
000074c3551d7255  movaps [rsp], xmm9
000074c3551d725a  movaps [rsp+0x10], xmm10
000074c3551d7260  movaps [rsp+0x20], xmm8
000074c3551d7266  lea rdi, [rsp]
000074c3551d726a  mov esi, 0x00
000074c3551d726f  mov rax, 0x5F9407FA9530
000074c3551d7279  call rax
000074c3551d727b  movaps xmm9, [rsp]
000074c3551d7280  add rsp, 0x30
000074c3551d7284  vmovaps xmm0, [rsp]
000074c3551d7289  vmovaps xmm1, [rsp+0x10]
000074c3551d728f  vmovaps xmm2, [rsp+0x20]
000074c3551d7295  vmovaps xmm3, [rsp+0x30]
000074c3551d729b  vmovaps xmm4, [rsp+0x40]
000074c3551d72a1  vmovaps xmm5, [rsp+0x50]
000074c3551d72a7  vmovaps xmm6, [rsp+0x60]
000074c3551d72ad  vmovaps xmm7, [rsp+0x70]
000074c3551d72b3  vmovaps xmm8, [rsp+0x80]
000074c3551d72bc  vmovaps xmm10, [rsp+0x90]
000074c3551d72c5  vmovaps xmm11, [rsp+0xA0]
000074c3551d72ce  vmovaps xmm12, [rsp+0xB0]
000074c3551d72d7  vmovaps xmm13, [rsp+0xC0]
000074c3551d72e0  vmovaps xmm14, [rsp+0xD0]
000074c3551d72e9  vmovaps xmm15, [rsp+0xE0]
000074c3551d72f2  add rsp, 0xF0
000074c3551d72f9  pop r11
000074c3551d72fb  pop r10
000074c3551d72fd  pop r9
000074c3551d72ff  pop r8
000074c3551d7301  pop rsi
000074c3551d7302  pop rdi
000074c3551d7303  pop rdx
000074c3551d7304  pop rcx
000074c3551d7305  pop rax
000074c3551d7306  add rsp, 0x08
000074c3551d730a  jmp 0x000074C3551D5AFB
000074c3551d730f  call 0x000074C3550D64F0
000074c3551d7314  jmp 0x000074C3551D5C15
000074c3551d7319  call 0x000074C3550D64F0
000074c3551d731e  jmp 0x000074C3551D5C2B
000074c3551d7323  sub rsp, 0x08
000074c3551d7327  push rax
000074c3551d7328  push rcx
000074c3551d7329  push rdx
000074c3551d732a  push rdi
000074c3551d732b  push rsi
000074c3551d732c  push r8
000074c3551d732e  push r9
000074c3551d7330  push r10
000074c3551d7332  push r11
000074c3551d7334  sub rsp, 0xF0
000074c3551d733b  vmovaps [rsp], xmm0
000074c3551d7340  vmovaps [rsp+0x10], xmm2
000074c3551d7346  vmovaps [rsp+0x20], xmm3
000074c3551d734c  vmovaps [rsp+0x30], xmm4
000074c3551d7352  vmovaps [rsp+0x40], xmm5
000074c3551d7358  vmovaps [rsp+0x50], xmm6
000074c3551d735e  vmovaps [rsp+0x60], xmm7
000074c3551d7364  vmovaps [rsp+0x70], xmm8
000074c3551d736a  vmovaps [rsp+0x80], xmm9
000074c3551d7373  vmovaps [rsp+0x90], xmm10
000074c3551d737c  vmovaps [rsp+0xA0], xmm11
000074c3551d7385  vmovaps [rsp+0xB0], xmm12
000074c3551d738e  vmovaps [rsp+0xC0], xmm13
000074c3551d7397  vmovaps [rsp+0xD0], xmm14
000074c3551d73a0  vmovaps [rsp+0xE0], xmm15
000074c3551d73a9  sub rsp, 0x30
000074c3551d73ad  movaps [rsp], xmm1
000074c3551d73b1  movaps [rsp+0x10], xmm6
000074c3551d73b6  movaps [rsp+0x20], xmm15
000074c3551d73bc  lea rdi, [rsp]
000074c3551d73c0  mov esi, 0x00
000074c3551d73c5  mov rax, 0x5F9407FA9530
000074c3551d73cf  call rax
000074c3551d73d1  movaps xmm1, [rsp]
000074c3551d73d5  add rsp, 0x30
000074c3551d73d9  vmovaps xmm0, [rsp]
000074c3551d73de  vmovaps xmm2, [rsp+0x10]
000074c3551d73e4  vmovaps xmm3, [rsp+0x20]
000074c3551d73ea  vmovaps xmm4, [rsp+0x30]
000074c3551d73f0  vmovaps xmm5, [rsp+0x40]
000074c3551d73f6  vmovaps xmm6, [rsp+0x50]
000074c3551d73fc  vmovaps xmm7, [rsp+0x60]
000074c3551d7402  vmovaps xmm8, [rsp+0x70]
000074c3551d7408  vmovaps xmm9, [rsp+0x80]
000074c3551d7411  vmovaps xmm10, [rsp+0x90]
000074c3551d741a  vmovaps xmm11, [rsp+0xA0]
000074c3551d7423  vmovaps xmm12, [rsp+0xB0]
000074c3551d742c  vmovaps xmm13, [rsp+0xC0]
000074c3551d7435  vmovaps xmm14, [rsp+0xD0]
000074c3551d743e  vmovaps xmm15, [rsp+0xE0]
000074c3551d7447  add rsp, 0xF0
000074c3551d744e  pop r11
000074c3551d7450  pop r10
000074c3551d7452  pop r9
000074c3551d7454  pop r8
000074c3551d7456  pop rsi
000074c3551d7457  pop rdi
000074c3551d7458  pop rdx
000074c3551d7459  pop rcx
000074c3551d745a  pop rax
000074c3551d745b  add rsp, 0x08
000074c3551d745f  jmp 0x000074C3551D5C68
000074c3551d7464  call 0x000074C3550E5820
000074c3551d7469  jmp 0x000074C3551D5C75
000074c3551d746e  sub rsp, 0x08
000074c3551d7472  push rax
000074c3551d7473  push rcx
000074c3551d7474  push rdx
000074c3551d7475  push rdi
000074c3551d7476  push rsi
000074c3551d7477  push r8
000074c3551d7479  push r9
000074c3551d747b  push r10
000074c3551d747d  push r11
000074c3551d747f  sub rsp, 0xF0
000074c3551d7486  vmovaps [rsp], xmm0
000074c3551d748b  vmovaps [rsp+0x10], xmm1
000074c3551d7491  vmovaps [rsp+0x20], xmm2
000074c3551d7497  vmovaps [rsp+0x30], xmm3
000074c3551d749d  vmovaps [rsp+0x40], xmm4
000074c3551d74a3  vmovaps [rsp+0x50], xmm5
000074c3551d74a9  vmovaps [rsp+0x60], xmm6
000074c3551d74af  vmovaps [rsp+0x70], xmm7
000074c3551d74b5  vmovaps [rsp+0x80], xmm8
000074c3551d74be  vmovaps [rsp+0x90], xmm9
000074c3551d74c7  vmovaps [rsp+0xA0], xmm10
000074c3551d74d0  vmovaps [rsp+0xB0], xmm11
000074c3551d74d9  vmovaps [rsp+0xC0], xmm12
000074c3551d74e2  vmovaps [rsp+0xD0], xmm13
000074c3551d74eb  vmovaps [rsp+0xE0], xmm15
000074c3551d74f4  sub rsp, 0x30
000074c3551d74f8  movaps [rsp], xmm14
000074c3551d74fd  movaps [rsp+0x10], xmm4
000074c3551d7502  movaps [rsp+0x20], xmm3
000074c3551d7507  lea rdi, [rsp]
000074c3551d750b  mov esi, 0x00
000074c3551d7510  mov rax, 0x5F9407FA9530
000074c3551d751a  call rax
000074c3551d751c  movaps xmm14, [rsp]
000074c3551d7521  add rsp, 0x30
000074c3551d7525  vmovaps xmm0, [rsp]
000074c3551d752a  vmovaps xmm1, [rsp+0x10]
000074c3551d7530  vmovaps xmm2, [rsp+0x20]
000074c3551d7536  vmovaps xmm3, [rsp+0x30]
000074c3551d753c  vmovaps xmm4, [rsp+0x40]
000074c3551d7542  vmovaps xmm5, [rsp+0x50]
000074c3551d7548  vmovaps xmm6, [rsp+0x60]
000074c3551d754e  vmovaps xmm7, [rsp+0x70]
000074c3551d7554  vmovaps xmm8, [rsp+0x80]
000074c3551d755d  vmovaps xmm9, [rsp+0x90]
000074c3551d7566  vmovaps xmm10, [rsp+0xA0]
000074c3551d756f  vmovaps xmm11, [rsp+0xB0]
000074c3551d7578  vmovaps xmm12, [rsp+0xC0]
000074c3551d7581  vmovaps xmm13, [rsp+0xD0]
000074c3551d758a  vmovaps xmm15, [rsp+0xE0]
000074c3551d7593  add rsp, 0xF0
000074c3551d759a  pop r11
000074c3551d759c  pop r10
000074c3551d759e  pop r9
000074c3551d75a0  pop r8
000074c3551d75a2  pop rsi
000074c3551d75a3  pop rdi
000074c3551d75a4  pop rdx
000074c3551d75a5  pop rcx
000074c3551d75a6  pop rax
000074c3551d75a7  add rsp, 0x08
000074c3551d75ab  jmp 0x000074C3551D5C8F
000074c3551d75b0  sub rsp, 0x08
000074c3551d75b4  push rax
000074c3551d75b5  push rcx
000074c3551d75b6  push rdx
000074c3551d75b7  push rdi
000074c3551d75b8  push rsi
000074c3551d75b9  push r8
000074c3551d75bb  push r9
000074c3551d75bd  push r10
000074c3551d75bf  push r11
000074c3551d75c1  sub rsp, 0xF0
000074c3551d75c8  vmovaps [rsp], xmm0
000074c3551d75cd  vmovaps [rsp+0x10], xmm1
000074c3551d75d3  vmovaps [rsp+0x20], xmm2
000074c3551d75d9  vmovaps [rsp+0x30], xmm3
000074c3551d75df  vmovaps [rsp+0x40], xmm4
000074c3551d75e5  vmovaps [rsp+0x50], xmm5
000074c3551d75eb  vmovaps [rsp+0x60], xmm7
000074c3551d75f1  vmovaps [rsp+0x70], xmm8
000074c3551d75f7  vmovaps [rsp+0x80], xmm9
000074c3551d7600  vmovaps [rsp+0x90], xmm10
000074c3551d7609  vmovaps [rsp+0xA0], xmm11
000074c3551d7612  vmovaps [rsp+0xB0], xmm12
000074c3551d761b  vmovaps [rsp+0xC0], xmm13
000074c3551d7624  vmovaps [rsp+0xD0], xmm14
000074c3551d762d  vmovaps [rsp+0xE0], xmm15
000074c3551d7636  sub rsp, 0x30
000074c3551d763a  movaps [rsp], xmm6
000074c3551d763e  movaps [rsp+0x10], xmm9
000074c3551d7644  movaps [rsp+0x20], xmm7
000074c3551d7649  lea rdi, [rsp]
000074c3551d764d  mov esi, 0x00
000074c3551d7652  mov rax, 0x5F9407FA9530
000074c3551d765c  call rax
000074c3551d765e  movaps xmm6, [rsp]
000074c3551d7662  add rsp, 0x30
000074c3551d7666  vmovaps xmm0, [rsp]
000074c3551d766b  vmovaps xmm1, [rsp+0x10]
000074c3551d7671  vmovaps xmm2, [rsp+0x20]
000074c3551d7677  vmovaps xmm3, [rsp+0x30]
000074c3551d767d  vmovaps xmm4, [rsp+0x40]
000074c3551d7683  vmovaps xmm5, [rsp+0x50]
000074c3551d7689  vmovaps xmm7, [rsp+0x60]
000074c3551d768f  vmovaps xmm8, [rsp+0x70]
000074c3551d7695  vmovaps xmm9, [rsp+0x80]
000074c3551d769e  vmovaps xmm10, [rsp+0x90]
000074c3551d76a7  vmovaps xmm11, [rsp+0xA0]
000074c3551d76b0  vmovaps xmm12, [rsp+0xB0]
000074c3551d76b9  vmovaps xmm13, [rsp+0xC0]
000074c3551d76c2  vmovaps xmm14, [rsp+0xD0]
000074c3551d76cb  vmovaps xmm15, [rsp+0xE0]
000074c3551d76d4  add rsp, 0xF0
000074c3551d76db  pop r11
000074c3551d76dd  pop r10
000074c3551d76df  pop r9
000074c3551d76e1  pop r8
000074c3551d76e3  pop rsi
000074c3551d76e4  pop rdi
000074c3551d76e5  pop rdx
000074c3551d76e6  pop rcx
000074c3551d76e7  pop rax
000074c3551d76e8  add rsp, 0x08
000074c3551d76ec  jmp 0x000074C3551D5CA7
000074c3551d76f1  sub rsp, 0x08
000074c3551d76f5  push rax
000074c3551d76f6  push rcx
000074c3551d76f7  push rdx
000074c3551d76f8  push rdi
000074c3551d76f9  push rsi
000074c3551d76fa  push r8
000074c3551d76fc  push r9
000074c3551d76fe  push r10
000074c3551d7700  push r11
000074c3551d7702  sub rsp, 0xF0
000074c3551d7709  vmovaps [rsp], xmm0
000074c3551d770e  vmovaps [rsp+0x10], xmm1
000074c3551d7714  vmovaps [rsp+0x20], xmm2
000074c3551d771a  vmovaps [rsp+0x30], xmm3
000074c3551d7720  vmovaps [rsp+0x40], xmm4
000074c3551d7726  vmovaps [rsp+0x50], xmm5
000074c3551d772c  vmovaps [rsp+0x60], xmm6
000074c3551d7732  vmovaps [rsp+0x70], xmm8
000074c3551d7738  vmovaps [rsp+0x80], xmm9
000074c3551d7741  vmovaps [rsp+0x90], xmm10
000074c3551d774a  vmovaps [rsp+0xA0], xmm11
000074c3551d7753  vmovaps [rsp+0xB0], xmm12
000074c3551d775c  vmovaps [rsp+0xC0], xmm13
000074c3551d7765  vmovaps [rsp+0xD0], xmm14
000074c3551d776e  vmovaps [rsp+0xE0], xmm15
000074c3551d7777  sub rsp, 0x30
000074c3551d777b  movaps [rsp], xmm7
000074c3551d777f  movaps [rsp+0x10], xmm4
000074c3551d7784  movaps [rsp+0x20], xmm9
000074c3551d778a  lea rdi, [rsp]
000074c3551d778e  mov esi, 0x00
000074c3551d7793  mov rax, 0x5F9407FA9530
000074c3551d779d  call rax
000074c3551d779f  movaps xmm7, [rsp]
000074c3551d77a3  add rsp, 0x30
000074c3551d77a7  vmovaps xmm0, [rsp]
000074c3551d77ac  vmovaps xmm1, [rsp+0x10]
000074c3551d77b2  vmovaps xmm2, [rsp+0x20]
000074c3551d77b8  vmovaps xmm3, [rsp+0x30]
000074c3551d77be  vmovaps xmm4, [rsp+0x40]
000074c3551d77c4  vmovaps xmm5, [rsp+0x50]
000074c3551d77ca  vmovaps xmm6, [rsp+0x60]
000074c3551d77d0  vmovaps xmm8, [rsp+0x70]
000074c3551d77d6  vmovaps xmm9, [rsp+0x80]
000074c3551d77df  vmovaps xmm10, [rsp+0x90]
000074c3551d77e8  vmovaps xmm11, [rsp+0xA0]
000074c3551d77f1  vmovaps xmm12, [rsp+0xB0]
000074c3551d77fa  vmovaps xmm13, [rsp+0xC0]
000074c3551d7803  vmovaps xmm14, [rsp+0xD0]
000074c3551d780c  vmovaps xmm15, [rsp+0xE0]
000074c3551d7815  add rsp, 0xF0
000074c3551d781c  pop r11
000074c3551d781e  pop r10
000074c3551d7820  pop r9
000074c3551d7822  pop r8
000074c3551d7824  pop rsi
000074c3551d7825  pop rdi
000074c3551d7826  pop rdx
000074c3551d7827  pop rcx
000074c3551d7828  pop rax
000074c3551d7829  add rsp, 0x08
000074c3551d782d  jmp 0x000074C3551D5CD4
000074c3551d7832  sub rsp, 0x08
000074c3551d7836  push rax
000074c3551d7837  push rcx
000074c3551d7838  push rdx
000074c3551d7839  push rdi
000074c3551d783a  push rsi
000074c3551d783b  push r8
000074c3551d783d  push r9
000074c3551d783f  push r10
000074c3551d7841  push r11
000074c3551d7843  sub rsp, 0xF0
000074c3551d784a  vmovaps [rsp], xmm0
000074c3551d784f  vmovaps [rsp+0x10], xmm1
000074c3551d7855  vmovaps [rsp+0x20], xmm2
000074c3551d785b  vmovaps [rsp+0x30], xmm3
000074c3551d7861  vmovaps [rsp+0x40], xmm5
000074c3551d7867  vmovaps [rsp+0x50], xmm6
000074c3551d786d  vmovaps [rsp+0x60], xmm7
000074c3551d7873  vmovaps [rsp+0x70], xmm8
000074c3551d7879  vmovaps [rsp+0x80], xmm9
000074c3551d7882  vmovaps [rsp+0x90], xmm10
000074c3551d788b  vmovaps [rsp+0xA0], xmm11
000074c3551d7894  vmovaps [rsp+0xB0], xmm12
000074c3551d789d  vmovaps [rsp+0xC0], xmm13
000074c3551d78a6  vmovaps [rsp+0xD0], xmm14
000074c3551d78af  vmovaps [rsp+0xE0], xmm15
000074c3551d78b8  sub rsp, 0x30
000074c3551d78bc  movaps [rsp], xmm4
000074c3551d78c0  movaps [rsp+0x10], xmm15
000074c3551d78c6  movaps [rsp+0x20], xmm9
000074c3551d78cc  lea rdi, [rsp]
000074c3551d78d0  mov esi, 0x00
000074c3551d78d5  mov rax, 0x5F9407FA9530
000074c3551d78df  call rax
000074c3551d78e1  movaps xmm4, [rsp]
000074c3551d78e5  add rsp, 0x30
000074c3551d78e9  vmovaps xmm0, [rsp]
000074c3551d78ee  vmovaps xmm1, [rsp+0x10]
000074c3551d78f4  vmovaps xmm2, [rsp+0x20]
000074c3551d78fa  vmovaps xmm3, [rsp+0x30]
000074c3551d7900  vmovaps xmm5, [rsp+0x40]
000074c3551d7906  vmovaps xmm6, [rsp+0x50]
000074c3551d790c  vmovaps xmm7, [rsp+0x60]
000074c3551d7912  vmovaps xmm8, [rsp+0x70]
000074c3551d7918  vmovaps xmm9, [rsp+0x80]
000074c3551d7921  vmovaps xmm10, [rsp+0x90]
000074c3551d792a  vmovaps xmm11, [rsp+0xA0]
000074c3551d7933  vmovaps xmm12, [rsp+0xB0]
000074c3551d793c  vmovaps xmm13, [rsp+0xC0]
000074c3551d7945  vmovaps xmm14, [rsp+0xD0]
000074c3551d794e  vmovaps xmm15, [rsp+0xE0]
000074c3551d7957  add rsp, 0xF0
000074c3551d795e  pop r11
000074c3551d7960  pop r10
000074c3551d7962  pop r9
000074c3551d7964  pop r8
000074c3551d7966  pop rsi
000074c3551d7967  pop rdi
000074c3551d7968  pop rdx
000074c3551d7969  pop rcx
000074c3551d796a  pop rax
000074c3551d796b  add rsp, 0x08
000074c3551d796f  jmp 0x000074C3551D5CF9
000074c3551d7974  call 0x000074C3550E5820
000074c3551d7979  jmp 0x000074C3551D5D06
000074c3551d797e  sub rsp, 0x08
000074c3551d7982  push rax
000074c3551d7983  push rcx
000074c3551d7984  push rdx
000074c3551d7985  push rdi
000074c3551d7986  push rsi
000074c3551d7987  push r8
000074c3551d7989  push r9
000074c3551d798b  push r10
000074c3551d798d  push r11
000074c3551d798f  sub rsp, 0xF0
000074c3551d7996  vmovaps [rsp], xmm0
000074c3551d799b  vmovaps [rsp+0x10], xmm1
000074c3551d79a1  vmovaps [rsp+0x20], xmm2
000074c3551d79a7  vmovaps [rsp+0x30], xmm4
000074c3551d79ad  vmovaps [rsp+0x40], xmm5
000074c3551d79b3  vmovaps [rsp+0x50], xmm6
000074c3551d79b9  vmovaps [rsp+0x60], xmm7
000074c3551d79bf  vmovaps [rsp+0x70], xmm8
000074c3551d79c5  vmovaps [rsp+0x80], xmm9
000074c3551d79ce  vmovaps [rsp+0x90], xmm10
000074c3551d79d7  vmovaps [rsp+0xA0], xmm11
000074c3551d79e0  vmovaps [rsp+0xB0], xmm12
000074c3551d79e9  vmovaps [rsp+0xC0], xmm13
000074c3551d79f2  vmovaps [rsp+0xD0], xmm14
000074c3551d79fb  vmovaps [rsp+0xE0], xmm15
000074c3551d7a04  sub rsp, 0x30
000074c3551d7a08  movaps [rsp], xmm3
000074c3551d7a0c  movaps [rsp+0x10], xmm1
000074c3551d7a11  movaps [rsp+0x20], xmm9
000074c3551d7a17  lea rdi, [rsp]
000074c3551d7a1b  mov esi, 0x00
000074c3551d7a20  mov rax, 0x5F9407FA9530
000074c3551d7a2a  call rax
000074c3551d7a2c  movaps xmm3, [rsp]
000074c3551d7a30  add rsp, 0x30
000074c3551d7a34  vmovaps xmm0, [rsp]
000074c3551d7a39  vmovaps xmm1, [rsp+0x10]
000074c3551d7a3f  vmovaps xmm2, [rsp+0x20]
000074c3551d7a45  vmovaps xmm4, [rsp+0x30]
000074c3551d7a4b  vmovaps xmm5, [rsp+0x40]
000074c3551d7a51  vmovaps xmm6, [rsp+0x50]
000074c3551d7a57  vmovaps xmm7, [rsp+0x60]
000074c3551d7a5d  vmovaps xmm8, [rsp+0x70]
000074c3551d7a63  vmovaps xmm9, [rsp+0x80]
000074c3551d7a6c  vmovaps xmm10, [rsp+0x90]
000074c3551d7a75  vmovaps xmm11, [rsp+0xA0]
000074c3551d7a7e  vmovaps xmm12, [rsp+0xB0]
000074c3551d7a87  vmovaps xmm13, [rsp+0xC0]
000074c3551d7a90  vmovaps xmm14, [rsp+0xD0]
000074c3551d7a99  vmovaps xmm15, [rsp+0xE0]
000074c3551d7aa2  add rsp, 0xF0
000074c3551d7aa9  pop r11
000074c3551d7aab  pop r10
000074c3551d7aad  pop r9
000074c3551d7aaf  pop r8
000074c3551d7ab1  pop rsi
000074c3551d7ab2  pop rdi
000074c3551d7ab3  pop rdx
000074c3551d7ab4  pop rcx
000074c3551d7ab5  pop rax
000074c3551d7ab6  add rsp, 0x08
000074c3551d7aba  jmp 0x000074C3551D5D43
000074c3551d7abf  sub rsp, 0x08
000074c3551d7ac3  push rax
000074c3551d7ac4  push rcx
000074c3551d7ac5  push rdx
000074c3551d7ac6  push rdi
000074c3551d7ac7  push rsi
000074c3551d7ac8  push r8
000074c3551d7aca  push r9
000074c3551d7acc  push r10
000074c3551d7ace  push r11
000074c3551d7ad0  sub rsp, 0xF0
000074c3551d7ad7  vmovaps [rsp], xmm0
000074c3551d7adc  vmovaps [rsp+0x10], xmm2
000074c3551d7ae2  vmovaps [rsp+0x20], xmm3
000074c3551d7ae8  vmovaps [rsp+0x30], xmm4
000074c3551d7aee  vmovaps [rsp+0x40], xmm5
000074c3551d7af4  vmovaps [rsp+0x50], xmm6
000074c3551d7afa  vmovaps [rsp+0x60], xmm7
000074c3551d7b00  vmovaps [rsp+0x70], xmm8
000074c3551d7b06  vmovaps [rsp+0x80], xmm9
000074c3551d7b0f  vmovaps [rsp+0x90], xmm10
000074c3551d7b18  vmovaps [rsp+0xA0], xmm11
000074c3551d7b21  vmovaps [rsp+0xB0], xmm12
000074c3551d7b2a  vmovaps [rsp+0xC0], xmm13
000074c3551d7b33  vmovaps [rsp+0xD0], xmm14
000074c3551d7b3c  vmovaps [rsp+0xE0], xmm15
000074c3551d7b45  sub rsp, 0x30
000074c3551d7b49  movaps [rsp], xmm1
000074c3551d7b4d  movaps [rsp+0x10], xmm15
000074c3551d7b53  movaps [rsp+0x20], xmm9
000074c3551d7b59  lea rdi, [rsp]
000074c3551d7b5d  mov esi, 0x00
000074c3551d7b62  mov rax, 0x5F9407FA9530
000074c3551d7b6c  call rax
000074c3551d7b6e  movaps xmm1, [rsp]
000074c3551d7b72  add rsp, 0x30
000074c3551d7b76  vmovaps xmm0, [rsp]
000074c3551d7b7b  vmovaps xmm2, [rsp+0x10]
000074c3551d7b81  vmovaps xmm3, [rsp+0x20]
000074c3551d7b87  vmovaps xmm4, [rsp+0x30]
000074c3551d7b8d  vmovaps xmm5, [rsp+0x40]
000074c3551d7b93  vmovaps xmm6, [rsp+0x50]
000074c3551d7b99  vmovaps xmm7, [rsp+0x60]
000074c3551d7b9f  vmovaps xmm8, [rsp+0x70]
000074c3551d7ba5  vmovaps xmm9, [rsp+0x80]
000074c3551d7bae  vmovaps xmm10, [rsp+0x90]
000074c3551d7bb7  vmovaps xmm11, [rsp+0xA0]
000074c3551d7bc0  vmovaps xmm12, [rsp+0xB0]
000074c3551d7bc9  vmovaps xmm13, [rsp+0xC0]
000074c3551d7bd2  vmovaps xmm14, [rsp+0xD0]
000074c3551d7bdb  vmovaps xmm15, [rsp+0xE0]
000074c3551d7be4  add rsp, 0xF0
000074c3551d7beb  pop r11
000074c3551d7bed  pop r10
000074c3551d7bef  pop r9
000074c3551d7bf1  pop r8
000074c3551d7bf3  pop rsi
000074c3551d7bf4  pop rdi
000074c3551d7bf5  pop rdx
000074c3551d7bf6  pop rcx
000074c3551d7bf7  pop rax
000074c3551d7bf8  add rsp, 0x08
000074c3551d7bfc  jmp 0x000074C3551D5DCB
000074c3551d7c01  call 0x000074C3550E5820
000074c3551d7c06  jmp 0x000074C3551D5DD8
000074c3551d7c0b  sub rsp, 0x08
000074c3551d7c0f  push rax
000074c3551d7c10  push rcx
000074c3551d7c11  push rdx
000074c3551d7c12  push rdi
000074c3551d7c13  push rsi
000074c3551d7c14  push r8
000074c3551d7c16  push r9
000074c3551d7c18  push r10
000074c3551d7c1a  push r11
000074c3551d7c1c  sub rsp, 0xF0
000074c3551d7c23  vmovaps [rsp], xmm0
000074c3551d7c28  vmovaps [rsp+0x10], xmm2
000074c3551d7c2e  vmovaps [rsp+0x20], xmm3
000074c3551d7c34  vmovaps [rsp+0x30], xmm4
000074c3551d7c3a  vmovaps [rsp+0x40], xmm5
000074c3551d7c40  vmovaps [rsp+0x50], xmm6
000074c3551d7c46  vmovaps [rsp+0x60], xmm7
000074c3551d7c4c  vmovaps [rsp+0x70], xmm8
000074c3551d7c52  vmovaps [rsp+0x80], xmm9
000074c3551d7c5b  vmovaps [rsp+0x90], xmm10
000074c3551d7c64  vmovaps [rsp+0xA0], xmm11
000074c3551d7c6d  vmovaps [rsp+0xB0], xmm12
000074c3551d7c76  vmovaps [rsp+0xC0], xmm13
000074c3551d7c7f  vmovaps [rsp+0xD0], xmm14
000074c3551d7c88  vmovaps [rsp+0xE0], xmm15
000074c3551d7c91  sub rsp, 0x30
000074c3551d7c95  movaps [rsp], xmm1
000074c3551d7c99  movaps [rsp+0x10], xmm5
000074c3551d7c9e  movaps [rsp+0x20], xmm7
000074c3551d7ca3  lea rdi, [rsp]
000074c3551d7ca7  mov esi, 0x00
000074c3551d7cac  mov rax, 0x5F9407FA9530
000074c3551d7cb6  call rax
000074c3551d7cb8  movaps xmm1, [rsp]
000074c3551d7cbc  add rsp, 0x30
000074c3551d7cc0  vmovaps xmm0, [rsp]
000074c3551d7cc5  vmovaps xmm2, [rsp+0x10]
000074c3551d7ccb  vmovaps xmm3, [rsp+0x20]
000074c3551d7cd1  vmovaps xmm4, [rsp+0x30]
000074c3551d7cd7  vmovaps xmm5, [rsp+0x40]
000074c3551d7cdd  vmovaps xmm6, [rsp+0x50]
000074c3551d7ce3  vmovaps xmm7, [rsp+0x60]
000074c3551d7ce9  vmovaps xmm8, [rsp+0x70]
000074c3551d7cef  vmovaps xmm9, [rsp+0x80]
000074c3551d7cf8  vmovaps xmm10, [rsp+0x90]
000074c3551d7d01  vmovaps xmm11, [rsp+0xA0]
000074c3551d7d0a  vmovaps xmm12, [rsp+0xB0]
000074c3551d7d13  vmovaps xmm13, [rsp+0xC0]
000074c3551d7d1c  vmovaps xmm14, [rsp+0xD0]
000074c3551d7d25  vmovaps xmm15, [rsp+0xE0]
000074c3551d7d2e  add rsp, 0xF0
000074c3551d7d35  pop r11
000074c3551d7d37  pop r10
000074c3551d7d39  pop r9
000074c3551d7d3b  pop r8
000074c3551d7d3d  pop rsi
000074c3551d7d3e  pop rdi
000074c3551d7d3f  pop rdx
000074c3551d7d40  pop rcx
000074c3551d7d41  pop rax
000074c3551d7d42  add rsp, 0x08
000074c3551d7d46  jmp 0x000074C3551D5E7D
000074c3551d7d4b  sub rsp, 0x08
000074c3551d7d4f  push rax
000074c3551d7d50  push rcx
000074c3551d7d51  push rdx
000074c3551d7d52  push rdi
000074c3551d7d53  push rsi
000074c3551d7d54  push r8
000074c3551d7d56  push r9
000074c3551d7d58  push r10
000074c3551d7d5a  push r11
000074c3551d7d5c  sub rsp, 0xF0
000074c3551d7d63  vmovaps [rsp], xmm0
000074c3551d7d68  vmovaps [rsp+0x10], xmm1
000074c3551d7d6e  vmovaps [rsp+0x20], xmm2
000074c3551d7d74  vmovaps [rsp+0x30], xmm3
000074c3551d7d7a  vmovaps [rsp+0x40], xmm4
000074c3551d7d80  vmovaps [rsp+0x50], xmm5
000074c3551d7d86  vmovaps [rsp+0x60], xmm6
000074c3551d7d8c  vmovaps [rsp+0x70], xmm8
000074c3551d7d92  vmovaps [rsp+0x80], xmm9
000074c3551d7d9b  vmovaps [rsp+0x90], xmm10
000074c3551d7da4  vmovaps [rsp+0xA0], xmm11
000074c3551d7dad  vmovaps [rsp+0xB0], xmm12
000074c3551d7db6  vmovaps [rsp+0xC0], xmm13
000074c3551d7dbf  vmovaps [rsp+0xD0], xmm14
000074c3551d7dc8  vmovaps [rsp+0xE0], xmm15
000074c3551d7dd1  sub rsp, 0x30
000074c3551d7dd5  movaps [rsp], xmm7
000074c3551d7dd9  movaps [rsp+0x10], xmm5
000074c3551d7dde  movaps [rsp+0x20], xmm15
000074c3551d7de4  lea rdi, [rsp]
000074c3551d7de8  mov esi, 0x00
000074c3551d7ded  mov rax, 0x5F9407FA9530
000074c3551d7df7  call rax
000074c3551d7df9  movaps xmm7, [rsp]
000074c3551d7dfd  add rsp, 0x30
000074c3551d7e01  vmovaps xmm0, [rsp]
000074c3551d7e06  vmovaps xmm1, [rsp+0x10]
000074c3551d7e0c  vmovaps xmm2, [rsp+0x20]
000074c3551d7e12  vmovaps xmm3, [rsp+0x30]
000074c3551d7e18  vmovaps xmm4, [rsp+0x40]
000074c3551d7e1e  vmovaps xmm5, [rsp+0x50]
000074c3551d7e24  vmovaps xmm6, [rsp+0x60]
000074c3551d7e2a  vmovaps xmm8, [rsp+0x70]
000074c3551d7e30  vmovaps xmm9, [rsp+0x80]
000074c3551d7e39  vmovaps xmm10, [rsp+0x90]
000074c3551d7e42  vmovaps xmm11, [rsp+0xA0]
000074c3551d7e4b  vmovaps xmm12, [rsp+0xB0]
000074c3551d7e54  vmovaps xmm13, [rsp+0xC0]
000074c3551d7e5d  vmovaps xmm14, [rsp+0xD0]
000074c3551d7e66  vmovaps xmm15, [rsp+0xE0]
000074c3551d7e6f  add rsp, 0xF0
000074c3551d7e76  pop r11
000074c3551d7e78  pop r10
000074c3551d7e7a  pop r9
000074c3551d7e7c  pop r8
000074c3551d7e7e  pop rsi
000074c3551d7e7f  pop rdi
000074c3551d7e80  pop rdx
000074c3551d7e81  pop rcx
000074c3551d7e82  pop rax
000074c3551d7e83  add rsp, 0x08
000074c3551d7e87  jmp 0x000074C3551D5EB3
000074c3551d7e8c  call 0x000074C3550D64F0
000074c3551d7e91  jmp 0x000074C3551D5EC0
000074c3551d7e96  sub rsp, 0x08
000074c3551d7e9a  push rax
000074c3551d7e9b  push rcx
000074c3551d7e9c  push rdx
000074c3551d7e9d  push rdi
000074c3551d7e9e  push rsi
000074c3551d7e9f  push r8
000074c3551d7ea1  push r9
000074c3551d7ea3  push r10
000074c3551d7ea5  push r11
000074c3551d7ea7  sub rsp, 0xF0
000074c3551d7eae  vmovaps [rsp], xmm0
000074c3551d7eb3  vmovaps [rsp+0x10], xmm1
000074c3551d7eb9  vmovaps [rsp+0x20], xmm2
000074c3551d7ebf  vmovaps [rsp+0x30], xmm3
000074c3551d7ec5  vmovaps [rsp+0x40], xmm4
000074c3551d7ecb  vmovaps [rsp+0x50], xmm5
000074c3551d7ed1  vmovaps [rsp+0x60], xmm6
000074c3551d7ed7  vmovaps [rsp+0x70], xmm7
000074c3551d7edd  vmovaps [rsp+0x80], xmm8
000074c3551d7ee6  vmovaps [rsp+0x90], xmm9
000074c3551d7eef  vmovaps [rsp+0xA0], xmm10
000074c3551d7ef8  vmovaps [rsp+0xB0], xmm11
000074c3551d7f01  vmovaps [rsp+0xC0], xmm12
000074c3551d7f0a  vmovaps [rsp+0xD0], xmm13
000074c3551d7f13  vmovaps [rsp+0xE0], xmm14
000074c3551d7f1c  sub rsp, 0x30
000074c3551d7f20  movaps [rsp], xmm15
000074c3551d7f25  movaps [rsp+0x10], xmm5
000074c3551d7f2a  movaps [rsp+0x20], xmm3
000074c3551d7f2f  lea rdi, [rsp]
000074c3551d7f33  mov esi, 0x00
000074c3551d7f38  mov rax, 0x5F9407FA9530
000074c3551d7f42  call rax
000074c3551d7f44  movaps xmm15, [rsp]
000074c3551d7f49  add rsp, 0x30
000074c3551d7f4d  vmovaps xmm0, [rsp]
000074c3551d7f52  vmovaps xmm1, [rsp+0x10]
000074c3551d7f58  vmovaps xmm2, [rsp+0x20]
000074c3551d7f5e  vmovaps xmm3, [rsp+0x30]
000074c3551d7f64  vmovaps xmm4, [rsp+0x40]
000074c3551d7f6a  vmovaps xmm5, [rsp+0x50]
000074c3551d7f70  vmovaps xmm6, [rsp+0x60]
000074c3551d7f76  vmovaps xmm7, [rsp+0x70]
000074c3551d7f7c  vmovaps xmm8, [rsp+0x80]
000074c3551d7f85  vmovaps xmm9, [rsp+0x90]
000074c3551d7f8e  vmovaps xmm10, [rsp+0xA0]
000074c3551d7f97  vmovaps xmm11, [rsp+0xB0]
000074c3551d7fa0  vmovaps xmm12, [rsp+0xC0]
000074c3551d7fa9  vmovaps xmm13, [rsp+0xD0]
000074c3551d7fb2  vmovaps xmm14, [rsp+0xE0]
000074c3551d7fbb  add rsp, 0xF0
000074c3551d7fc2  pop r11
000074c3551d7fc4  pop r10
000074c3551d7fc6  pop r9
000074c3551d7fc8  pop r8
000074c3551d7fca  pop rsi
000074c3551d7fcb  pop rdi
000074c3551d7fcc  pop rdx
000074c3551d7fcd  pop rcx
000074c3551d7fce  pop rax
000074c3551d7fcf  add rsp, 0x08
000074c3551d7fd3  jmp 0x000074C3551D5EE6
000074c3551d7fd8  sub rsp, 0x08
000074c3551d7fdc  push rax
000074c3551d7fdd  push rcx
000074c3551d7fde  push rdx
000074c3551d7fdf  push rdi
000074c3551d7fe0  push rsi
000074c3551d7fe1  push r8
000074c3551d7fe3  push r9
000074c3551d7fe5  push r10
000074c3551d7fe7  push r11
000074c3551d7fe9  sub rsp, 0xF0
000074c3551d7ff0  vmovaps [rsp], xmm0
000074c3551d7ff5  vmovaps [rsp+0x10], xmm2
000074c3551d7ffb  vmovaps [rsp+0x20], xmm3
000074c3551d8001  vmovaps [rsp+0x30], xmm4
000074c3551d8007  vmovaps [rsp+0x40], xmm5
000074c3551d800d  vmovaps [rsp+0x50], xmm6
000074c3551d8013  vmovaps [rsp+0x60], xmm7
000074c3551d8019  vmovaps [rsp+0x70], xmm8
000074c3551d801f  vmovaps [rsp+0x80], xmm9
000074c3551d8028  vmovaps [rsp+0x90], xmm10
000074c3551d8031  vmovaps [rsp+0xA0], xmm11
000074c3551d803a  vmovaps [rsp+0xB0], xmm12
000074c3551d8043  vmovaps [rsp+0xC0], xmm13
000074c3551d804c  vmovaps [rsp+0xD0], xmm14
000074c3551d8055  vmovaps [rsp+0xE0], xmm15
000074c3551d805e  sub rsp, 0x30
000074c3551d8062  movaps [rsp], xmm1
000074c3551d8066  movaps [rsp+0x10], xmm5
000074c3551d806b  movaps [rsp+0x20], xmm4
000074c3551d8070  lea rdi, [rsp]
000074c3551d8074  mov esi, 0x00
000074c3551d8079  mov rax, 0x5F9407FA9530
000074c3551d8083  call rax
000074c3551d8085  movaps xmm1, [rsp]
000074c3551d8089  add rsp, 0x30
000074c3551d808d  vmovaps xmm0, [rsp]
000074c3551d8092  vmovaps xmm2, [rsp+0x10]
000074c3551d8098  vmovaps xmm3, [rsp+0x20]
000074c3551d809e  vmovaps xmm4, [rsp+0x30]
000074c3551d80a4  vmovaps xmm5, [rsp+0x40]
000074c3551d80aa  vmovaps xmm6, [rsp+0x50]
000074c3551d80b0  vmovaps xmm7, [rsp+0x60]
000074c3551d80b6  vmovaps xmm8, [rsp+0x70]
000074c3551d80bc  vmovaps xmm9, [rsp+0x80]
000074c3551d80c5  vmovaps xmm10, [rsp+0x90]
000074c3551d80ce  vmovaps xmm11, [rsp+0xA0]
000074c3551d80d7  vmovaps xmm12, [rsp+0xB0]
000074c3551d80e0  vmovaps xmm13, [rsp+0xC0]
000074c3551d80e9  vmovaps xmm14, [rsp+0xD0]
000074c3551d80f2  vmovaps xmm15, [rsp+0xE0]
000074c3551d80fb  add rsp, 0xF0
000074c3551d8102  pop r11
000074c3551d8104  pop r10
000074c3551d8106  pop r9
000074c3551d8108  pop r8
000074c3551d810a  pop rsi
000074c3551d810b  pop rdi
000074c3551d810c  pop rdx
000074c3551d810d  pop rcx
000074c3551d810e  pop rax
000074c3551d810f  add rsp, 0x08
000074c3551d8113  jmp 0x000074C3551D5F06
000074c3551d8118  sub rsp, 0x08
000074c3551d811c  push rax
000074c3551d811d  push rcx
000074c3551d811e  push rdx
000074c3551d811f  push rdi
000074c3551d8120  push rsi
000074c3551d8121  push r8
000074c3551d8123  push r9
000074c3551d8125  push r10
000074c3551d8127  push r11
000074c3551d8129  sub rsp, 0xF0
000074c3551d8130  vmovaps [rsp], xmm0
000074c3551d8135  vmovaps [rsp+0x10], xmm1
000074c3551d813b  vmovaps [rsp+0x20], xmm2
000074c3551d8141  vmovaps [rsp+0x30], xmm3
000074c3551d8147  vmovaps [rsp+0x40], xmm5
000074c3551d814d  vmovaps [rsp+0x50], xmm6
000074c3551d8153  vmovaps [rsp+0x60], xmm7
000074c3551d8159  vmovaps [rsp+0x70], xmm8
000074c3551d815f  vmovaps [rsp+0x80], xmm9
000074c3551d8168  vmovaps [rsp+0x90], xmm10
000074c3551d8171  vmovaps [rsp+0xA0], xmm11
000074c3551d817a  vmovaps [rsp+0xB0], xmm12
000074c3551d8183  vmovaps [rsp+0xC0], xmm13
000074c3551d818c  vmovaps [rsp+0xD0], xmm14
000074c3551d8195  vmovaps [rsp+0xE0], xmm15
000074c3551d819e  sub rsp, 0x30
000074c3551d81a2  movaps [rsp], xmm4
000074c3551d81a6  movaps [rsp+0x10], xmm3
000074c3551d81ab  movaps [rsp+0x20], xmm5
000074c3551d81b0  lea rdi, [rsp]
000074c3551d81b4  mov esi, 0x00
000074c3551d81b9  mov rax, 0x5F9407FA9530
000074c3551d81c3  call rax
000074c3551d81c5  movaps xmm4, [rsp]
000074c3551d81c9  add rsp, 0x30
000074c3551d81cd  vmovaps xmm0, [rsp]
000074c3551d81d2  vmovaps xmm1, [rsp+0x10]
000074c3551d81d8  vmovaps xmm2, [rsp+0x20]
000074c3551d81de  vmovaps xmm3, [rsp+0x30]
000074c3551d81e4  vmovaps xmm5, [rsp+0x40]
000074c3551d81ea  vmovaps xmm6, [rsp+0x50]
000074c3551d81f0  vmovaps xmm7, [rsp+0x60]
000074c3551d81f6  vmovaps xmm8, [rsp+0x70]
000074c3551d81fc  vmovaps xmm9, [rsp+0x80]
000074c3551d8205  vmovaps xmm10, [rsp+0x90]
000074c3551d820e  vmovaps xmm11, [rsp+0xA0]
000074c3551d8217  vmovaps xmm12, [rsp+0xB0]
000074c3551d8220  vmovaps xmm13, [rsp+0xC0]
000074c3551d8229  vmovaps xmm14, [rsp+0xD0]
000074c3551d8232  vmovaps xmm15, [rsp+0xE0]
000074c3551d823b  add rsp, 0xF0
000074c3551d8242  pop r11
000074c3551d8244  pop r10
000074c3551d8246  pop r9
000074c3551d8248  pop r8
000074c3551d824a  pop rsi
000074c3551d824b  pop rdi
000074c3551d824c  pop rdx
000074c3551d824d  pop rcx
000074c3551d824e  pop rax
000074c3551d824f  add rsp, 0x08
000074c3551d8253  jmp 0x000074C3551D5F54
000074c3551d8258  call 0x000074C3550D64F0
000074c3551d825d  jmp 0x000074C3551D5F61
000074c3551d8262  sub rsp, 0x08
000074c3551d8266  push rax
000074c3551d8267  push rcx
000074c3551d8268  push rdx
000074c3551d8269  push rdi
000074c3551d826a  push rsi
000074c3551d826b  push r8
000074c3551d826d  push r9
000074c3551d826f  push r10
000074c3551d8271  push r11
000074c3551d8273  sub rsp, 0xF0
000074c3551d827a  vmovaps [rsp], xmm0
000074c3551d827f  vmovaps [rsp+0x10], xmm1
000074c3551d8285  vmovaps [rsp+0x20], xmm2
000074c3551d828b  vmovaps [rsp+0x30], xmm3
000074c3551d8291  vmovaps [rsp+0x40], xmm4
000074c3551d8297  vmovaps [rsp+0x50], xmm6
000074c3551d829d  vmovaps [rsp+0x60], xmm7
000074c3551d82a3  vmovaps [rsp+0x70], xmm8
000074c3551d82a9  vmovaps [rsp+0x80], xmm9
000074c3551d82b2  vmovaps [rsp+0x90], xmm10
000074c3551d82bb  vmovaps [rsp+0xA0], xmm11
000074c3551d82c4  vmovaps [rsp+0xB0], xmm12
000074c3551d82cd  vmovaps [rsp+0xC0], xmm13
000074c3551d82d6  vmovaps [rsp+0xD0], xmm14
000074c3551d82df  vmovaps [rsp+0xE0], xmm15
000074c3551d82e8  sub rsp, 0x30
000074c3551d82ec  movaps [rsp], xmm5
000074c3551d82f0  movaps [rsp+0x10], xmm6
000074c3551d82f5  movaps [rsp+0x20], xmm3
000074c3551d82fa  lea rdi, [rsp]
000074c3551d82fe  mov esi, 0x00
000074c3551d8303  mov rax, 0x5F9407FA9530
000074c3551d830d  call rax
000074c3551d830f  movaps xmm5, [rsp]
000074c3551d8313  add rsp, 0x30
000074c3551d8317  vmovaps xmm0, [rsp]
000074c3551d831c  vmovaps xmm1, [rsp+0x10]
000074c3551d8322  vmovaps xmm2, [rsp+0x20]
000074c3551d8328  vmovaps xmm3, [rsp+0x30]
000074c3551d832e  vmovaps xmm4, [rsp+0x40]
000074c3551d8334  vmovaps xmm6, [rsp+0x50]
000074c3551d833a  vmovaps xmm7, [rsp+0x60]
000074c3551d8340  vmovaps xmm8, [rsp+0x70]
000074c3551d8346  vmovaps xmm9, [rsp+0x80]
000074c3551d834f  vmovaps xmm10, [rsp+0x90]
000074c3551d8358  vmovaps xmm11, [rsp+0xA0]
000074c3551d8361  vmovaps xmm12, [rsp+0xB0]
000074c3551d836a  vmovaps xmm13, [rsp+0xC0]
000074c3551d8373  vmovaps xmm14, [rsp+0xD0]
000074c3551d837c  vmovaps xmm15, [rsp+0xE0]
000074c3551d8385  add rsp, 0xF0
000074c3551d838c  pop r11
000074c3551d838e  pop r10
000074c3551d8390  pop r9
000074c3551d8392  pop r8
000074c3551d8394  pop rsi
000074c3551d8395  pop rdi
000074c3551d8396  pop rdx
000074c3551d8397  pop rcx
000074c3551d8398  pop rax
000074c3551d8399  add rsp, 0x08
000074c3551d839d  jmp 0x000074C3551D5F87
000074c3551d83a2  sub rsp, 0x08
000074c3551d83a6  push rax
000074c3551d83a7  push rcx
000074c3551d83a8  push rdx
000074c3551d83a9  push rdi
000074c3551d83aa  push rsi
000074c3551d83ab  push r8
000074c3551d83ad  push r9
000074c3551d83af  push r10
000074c3551d83b1  push r11
000074c3551d83b3  sub rsp, 0xF0
000074c3551d83ba  vmovaps [rsp], xmm0
000074c3551d83bf  vmovaps [rsp+0x10], xmm1
000074c3551d83c5  vmovaps [rsp+0x20], xmm2
000074c3551d83cb  vmovaps [rsp+0x30], xmm3
000074c3551d83d1  vmovaps [rsp+0x40], xmm4
000074c3551d83d7  vmovaps [rsp+0x50], xmm5
000074c3551d83dd  vmovaps [rsp+0x60], xmm7
000074c3551d83e3  vmovaps [rsp+0x70], xmm8
000074c3551d83e9  vmovaps [rsp+0x80], xmm9
000074c3551d83f2  vmovaps [rsp+0x90], xmm10
000074c3551d83fb  vmovaps [rsp+0xA0], xmm11
000074c3551d8404  vmovaps [rsp+0xB0], xmm12
000074c3551d840d  vmovaps [rsp+0xC0], xmm13
000074c3551d8416  vmovaps [rsp+0xD0], xmm14
000074c3551d841f  vmovaps [rsp+0xE0], xmm15
000074c3551d8428  sub rsp, 0x30
000074c3551d842c  movaps [rsp], xmm6
000074c3551d8430  movaps [rsp+0x10], xmm9
000074c3551d8436  movaps [rsp+0x20], xmm1
000074c3551d843b  lea rdi, [rsp]
000074c3551d843f  mov esi, 0x00
000074c3551d8444  mov rax, 0x5F9407FA9530
000074c3551d844e  call rax
000074c3551d8450  movaps xmm6, [rsp]
000074c3551d8454  add rsp, 0x30
000074c3551d8458  vmovaps xmm0, [rsp]
000074c3551d845d  vmovaps xmm1, [rsp+0x10]
000074c3551d8463  vmovaps xmm2, [rsp+0x20]
000074c3551d8469  vmovaps xmm3, [rsp+0x30]
000074c3551d846f  vmovaps xmm4, [rsp+0x40]
000074c3551d8475  vmovaps xmm5, [rsp+0x50]
000074c3551d847b  vmovaps xmm7, [rsp+0x60]
000074c3551d8481  vmovaps xmm8, [rsp+0x70]
000074c3551d8487  vmovaps xmm9, [rsp+0x80]
000074c3551d8490  vmovaps xmm10, [rsp+0x90]
000074c3551d8499  vmovaps xmm11, [rsp+0xA0]
000074c3551d84a2  vmovaps xmm12, [rsp+0xB0]
000074c3551d84ab  vmovaps xmm13, [rsp+0xC0]
000074c3551d84b4  vmovaps xmm14, [rsp+0xD0]
000074c3551d84bd  vmovaps xmm15, [rsp+0xE0]
000074c3551d84c6  add rsp, 0xF0
000074c3551d84cd  pop r11
000074c3551d84cf  pop r10
000074c3551d84d1  pop r9
000074c3551d84d3  pop r8
000074c3551d84d5  pop rsi
000074c3551d84d6  pop rdi
000074c3551d84d7  pop rdx
000074c3551d84d8  pop rcx
000074c3551d84d9  pop rax
000074c3551d84da  add rsp, 0x08
000074c3551d84de  jmp 0x000074C3551D5FAB
000074c3551d84e3  sub rsp, 0x08
000074c3551d84e7  push rax
000074c3551d84e8  push rcx
000074c3551d84e9  push rdx
000074c3551d84ea  push rdi
000074c3551d84eb  push rsi
000074c3551d84ec  push r8
000074c3551d84ee  push r9
000074c3551d84f0  push r10
000074c3551d84f2  push r11
000074c3551d84f4  sub rsp, 0xF0
000074c3551d84fb  vmovaps [rsp], xmm0
000074c3551d8500  vmovaps [rsp+0x10], xmm1
000074c3551d8506  vmovaps [rsp+0x20], xmm2
000074c3551d850c  vmovaps [rsp+0x30], xmm3
000074c3551d8512  vmovaps [rsp+0x40], xmm4
000074c3551d8518  vmovaps [rsp+0x50], xmm5
000074c3551d851e  vmovaps [rsp+0x60], xmm6
000074c3551d8524  vmovaps [rsp+0x70], xmm7
000074c3551d852a  vmovaps [rsp+0x80], xmm8
000074c3551d8533  vmovaps [rsp+0x90], xmm10
000074c3551d853c  vmovaps [rsp+0xA0], xmm11
000074c3551d8545  vmovaps [rsp+0xB0], xmm12
000074c3551d854e  vmovaps [rsp+0xC0], xmm13
000074c3551d8557  vmovaps [rsp+0xD0], xmm14
000074c3551d8560  vmovaps [rsp+0xE0], xmm15
000074c3551d8569  sub rsp, 0x30
000074c3551d856d  movaps [rsp], xmm9
000074c3551d8572  movaps [rsp+0x10], xmm3
000074c3551d8577  movaps [rsp+0x20], xmm1
000074c3551d857c  lea rdi, [rsp]
000074c3551d8580  mov esi, 0x00
000074c3551d8585  mov rax, 0x5F9407FA9530
000074c3551d858f  call rax
000074c3551d8591  movaps xmm9, [rsp]
000074c3551d8596  add rsp, 0x30
000074c3551d859a  vmovaps xmm0, [rsp]
000074c3551d859f  vmovaps xmm1, [rsp+0x10]
000074c3551d85a5  vmovaps xmm2, [rsp+0x20]
000074c3551d85ab  vmovaps xmm3, [rsp+0x30]
000074c3551d85b1  vmovaps xmm4, [rsp+0x40]
000074c3551d85b7  vmovaps xmm5, [rsp+0x50]
000074c3551d85bd  vmovaps xmm6, [rsp+0x60]
000074c3551d85c3  vmovaps xmm7, [rsp+0x70]
000074c3551d85c9  vmovaps xmm8, [rsp+0x80]
000074c3551d85d2  vmovaps xmm10, [rsp+0x90]
000074c3551d85db  vmovaps xmm11, [rsp+0xA0]
000074c3551d85e4  vmovaps xmm12, [rsp+0xB0]
000074c3551d85ed  vmovaps xmm13, [rsp+0xC0]
000074c3551d85f6  vmovaps xmm14, [rsp+0xD0]
000074c3551d85ff  vmovaps xmm15, [rsp+0xE0]
000074c3551d8608  add rsp, 0xF0
000074c3551d860f  pop r11
000074c3551d8611  pop r10
000074c3551d8613  pop r9
000074c3551d8615  pop r8
000074c3551d8617  pop rsi
000074c3551d8618  pop rdi
000074c3551d8619  pop rdx
000074c3551d861a  pop rcx
000074c3551d861b  pop rax
000074c3551d861c  add rsp, 0x08
000074c3551d8620  jmp 0x000074C3551D5FF7
000074c3551d8625  call 0x000074C3550D64F0
000074c3551d862a  jmp 0x000074C3551D6004
000074c3551d862f  sub rsp, 0x08
000074c3551d8633  push rax
000074c3551d8634  push rcx
000074c3551d8635  push rdx
000074c3551d8636  push rdi
000074c3551d8637  push rsi
000074c3551d8638  push r8
000074c3551d863a  push r9
000074c3551d863c  push r10
000074c3551d863e  push r11
000074c3551d8640  sub rsp, 0xF0
000074c3551d8647  vmovaps [rsp], xmm0
000074c3551d864c  vmovaps [rsp+0x10], xmm1
000074c3551d8652  vmovaps [rsp+0x20], xmm2
000074c3551d8658  vmovaps [rsp+0x30], xmm3
000074c3551d865e  vmovaps [rsp+0x40], xmm4
000074c3551d8664  vmovaps [rsp+0x50], xmm5
000074c3551d866a  vmovaps [rsp+0x60], xmm6
000074c3551d8670  vmovaps [rsp+0x70], xmm7
000074c3551d8676  vmovaps [rsp+0x80], xmm8
000074c3551d867f  vmovaps [rsp+0x90], xmm9
000074c3551d8688  vmovaps [rsp+0xA0], xmm10
000074c3551d8691  vmovaps [rsp+0xB0], xmm11
000074c3551d869a  vmovaps [rsp+0xC0], xmm12
000074c3551d86a3  vmovaps [rsp+0xD0], xmm13
000074c3551d86ac  vmovaps [rsp+0xE0], xmm14
000074c3551d86b5  sub rsp, 0x30
000074c3551d86b9  movaps [rsp], xmm15
000074c3551d86be  movaps [rsp+0x10], xmm3
000074c3551d86c3  movaps [rsp+0x20], xmm7
000074c3551d86c8  lea rdi, [rsp]
000074c3551d86cc  mov esi, 0x00
000074c3551d86d1  mov rax, 0x5F9407FA9530
000074c3551d86db  call rax
000074c3551d86dd  movaps xmm15, [rsp]
000074c3551d86e2  add rsp, 0x30
000074c3551d86e6  vmovaps xmm0, [rsp]
000074c3551d86eb  vmovaps xmm1, [rsp+0x10]
000074c3551d86f1  vmovaps xmm2, [rsp+0x20]
000074c3551d86f7  vmovaps xmm3, [rsp+0x30]
000074c3551d86fd  vmovaps xmm4, [rsp+0x40]
000074c3551d8703  vmovaps xmm5, [rsp+0x50]
000074c3551d8709  vmovaps xmm6, [rsp+0x60]
000074c3551d870f  vmovaps xmm7, [rsp+0x70]
000074c3551d8715  vmovaps xmm8, [rsp+0x80]
000074c3551d871e  vmovaps xmm9, [rsp+0x90]
000074c3551d8727  vmovaps xmm10, [rsp+0xA0]
000074c3551d8730  vmovaps xmm11, [rsp+0xB0]
000074c3551d8739  vmovaps xmm12, [rsp+0xC0]
000074c3551d8742  vmovaps xmm13, [rsp+0xD0]
000074c3551d874b  vmovaps xmm14, [rsp+0xE0]
000074c3551d8754  add rsp, 0xF0
000074c3551d875b  pop r11
000074c3551d875d  pop r10
000074c3551d875f  pop r9
000074c3551d8761  pop r8
000074c3551d8763  pop rsi
000074c3551d8764  pop rdi
000074c3551d8765  pop rdx
000074c3551d8766  pop rcx
000074c3551d8767  pop rax
000074c3551d8768  add rsp, 0x08
000074c3551d876c  jmp 0x000074C3551D6030
000074c3551d8771  sub rsp, 0x08
000074c3551d8775  push rax
000074c3551d8776  push rcx
000074c3551d8777  push rdx
000074c3551d8778  push rdi
000074c3551d8779  push rsi
000074c3551d877a  push r8
000074c3551d877c  push r9
000074c3551d877e  push r10
000074c3551d8780  push r11
000074c3551d8782  sub rsp, 0xF0
000074c3551d8789  vmovaps [rsp], xmm0
000074c3551d878e  vmovaps [rsp+0x10], xmm1
000074c3551d8794  vmovaps [rsp+0x20], xmm2
000074c3551d879a  vmovaps [rsp+0x30], xmm4
000074c3551d87a0  vmovaps [rsp+0x40], xmm5
000074c3551d87a6  vmovaps [rsp+0x50], xmm6
000074c3551d87ac  vmovaps [rsp+0x60], xmm7
000074c3551d87b2  vmovaps [rsp+0x70], xmm8
000074c3551d87b8  vmovaps [rsp+0x80], xmm9
000074c3551d87c1  vmovaps [rsp+0x90], xmm10
000074c3551d87ca  vmovaps [rsp+0xA0], xmm11
000074c3551d87d3  vmovaps [rsp+0xB0], xmm12
000074c3551d87dc  vmovaps [rsp+0xC0], xmm13
000074c3551d87e5  vmovaps [rsp+0xD0], xmm14
000074c3551d87ee  vmovaps [rsp+0xE0], xmm15
000074c3551d87f7  sub rsp, 0x30
000074c3551d87fb  movaps [rsp], xmm3
000074c3551d87ff  movaps [rsp+0x10], xmm1
000074c3551d8804  movaps [rsp+0x20], xmm15
000074c3551d880a  lea rdi, [rsp]
000074c3551d880e  mov esi, 0x00
000074c3551d8813  mov rax, 0x5F9407FA9530
000074c3551d881d  call rax
000074c3551d881f  movaps xmm3, [rsp]
000074c3551d8823  add rsp, 0x30
000074c3551d8827  vmovaps xmm0, [rsp]
000074c3551d882c  vmovaps xmm1, [rsp+0x10]
000074c3551d8832  vmovaps xmm2, [rsp+0x20]
000074c3551d8838  vmovaps xmm4, [rsp+0x30]
000074c3551d883e  vmovaps xmm5, [rsp+0x40]
000074c3551d8844  vmovaps xmm6, [rsp+0x50]
000074c3551d884a  vmovaps xmm7, [rsp+0x60]
000074c3551d8850  vmovaps xmm8, [rsp+0x70]
000074c3551d8856  vmovaps xmm9, [rsp+0x80]
000074c3551d885f  vmovaps xmm10, [rsp+0x90]
000074c3551d8868  vmovaps xmm11, [rsp+0xA0]
000074c3551d8871  vmovaps xmm12, [rsp+0xB0]
000074c3551d887a  vmovaps xmm13, [rsp+0xC0]
000074c3551d8883  vmovaps xmm14, [rsp+0xD0]
000074c3551d888c  vmovaps xmm15, [rsp+0xE0]
000074c3551d8895  add rsp, 0xF0
000074c3551d889c  pop r11
000074c3551d889e  pop r10
000074c3551d88a0  pop r9
000074c3551d88a2  pop r8
000074c3551d88a4  pop rsi
000074c3551d88a5  pop rdi
000074c3551d88a6  pop rdx
000074c3551d88a7  pop rcx
000074c3551d88a8  pop rax
000074c3551d88a9  add rsp, 0x08
000074c3551d88ad  jmp 0x000074C3551D60BF
000074c3551d88b2  call 0x000074C3550D64F0
000074c3551d88b7  jmp 0x000074C3551D60C9
000074c3551d88bc  sub rsp, 0x08
000074c3551d88c0  push rax
000074c3551d88c1  push rcx
000074c3551d88c2  push rdx
000074c3551d88c3  push rdi
000074c3551d88c4  push rsi
000074c3551d88c5  push r8
000074c3551d88c7  push r9
000074c3551d88c9  push r10
000074c3551d88cb  push r11
000074c3551d88cd  sub rsp, 0xF0
000074c3551d88d4  vmovaps [rsp], xmm0
000074c3551d88d9  vmovaps [rsp+0x10], xmm1
000074c3551d88df  vmovaps [rsp+0x20], xmm2
000074c3551d88e5  vmovaps [rsp+0x30], xmm3
000074c3551d88eb  vmovaps [rsp+0x40], xmm4
000074c3551d88f1  vmovaps [rsp+0x50], xmm5
000074c3551d88f7  vmovaps [rsp+0x60], xmm6
000074c3551d88fd  vmovaps [rsp+0x70], xmm7
000074c3551d8903  vmovaps [rsp+0x80], xmm8
000074c3551d890c  vmovaps [rsp+0x90], xmm9
000074c3551d8915  vmovaps [rsp+0xA0], xmm10
000074c3551d891e  vmovaps [rsp+0xB0], xmm11
000074c3551d8927  vmovaps [rsp+0xC0], xmm12
000074c3551d8930  vmovaps [rsp+0xD0], xmm13
000074c3551d8939  vmovaps [rsp+0xE0], xmm14
000074c3551d8942  sub rsp, 0x30
000074c3551d8946  movaps [rsp], xmm15
000074c3551d894b  movaps [rsp+0x10], xmm14
000074c3551d8951  movaps [rsp+0x20], xmm4
000074c3551d8956  lea rdi, [rsp]
000074c3551d895a  mov esi, 0x00
000074c3551d895f  mov rax, 0x5F9407FA9530
000074c3551d8969  call rax
000074c3551d896b  movaps xmm15, [rsp]
000074c3551d8970  add rsp, 0x30
000074c3551d8974  vmovaps xmm0, [rsp]
000074c3551d8979  vmovaps xmm1, [rsp+0x10]
000074c3551d897f  vmovaps xmm2, [rsp+0x20]
000074c3551d8985  vmovaps xmm3, [rsp+0x30]
000074c3551d898b  vmovaps xmm4, [rsp+0x40]
000074c3551d8991  vmovaps xmm5, [rsp+0x50]
000074c3551d8997  vmovaps xmm6, [rsp+0x60]
000074c3551d899d  vmovaps xmm7, [rsp+0x70]
000074c3551d89a3  vmovaps xmm8, [rsp+0x80]
000074c3551d89ac  vmovaps xmm9, [rsp+0x90]
000074c3551d89b5  vmovaps xmm10, [rsp+0xA0]
000074c3551d89be  vmovaps xmm11, [rsp+0xB0]
000074c3551d89c7  vmovaps xmm12, [rsp+0xC0]
000074c3551d89d0  vmovaps xmm13, [rsp+0xD0]
000074c3551d89d9  vmovaps xmm14, [rsp+0xE0]
000074c3551d89e2  add rsp, 0xF0
000074c3551d89e9  pop r11
000074c3551d89eb  pop r10
000074c3551d89ed  pop r9
000074c3551d89ef  pop r8
000074c3551d89f1  pop rsi
000074c3551d89f2  pop rdi
000074c3551d89f3  pop rdx
000074c3551d89f4  pop rcx
000074c3551d89f5  pop rax
000074c3551d89f6  add rsp, 0x08
000074c3551d89fa  jmp 0x000074C3551D60F7
000074c3551d89ff  sub rsp, 0x08
000074c3551d8a03  push rax
000074c3551d8a04  push rcx
000074c3551d8a05  push rdx
000074c3551d8a06  push rdi
000074c3551d8a07  push rsi
000074c3551d8a08  push r8
000074c3551d8a0a  push r9
000074c3551d8a0c  push r10
000074c3551d8a0e  push r11
000074c3551d8a10  sub rsp, 0xF0
000074c3551d8a17  vmovaps [rsp], xmm0
000074c3551d8a1c  vmovaps [rsp+0x10], xmm1
000074c3551d8a22  vmovaps [rsp+0x20], xmm2
000074c3551d8a28  vmovaps [rsp+0x30], xmm3
000074c3551d8a2e  vmovaps [rsp+0x40], xmm4
000074c3551d8a34  vmovaps [rsp+0x50], xmm5
000074c3551d8a3a  vmovaps [rsp+0x60], xmm6
000074c3551d8a40  vmovaps [rsp+0x70], xmm7
000074c3551d8a46  vmovaps [rsp+0x80], xmm8
000074c3551d8a4f  vmovaps [rsp+0x90], xmm9
000074c3551d8a58  vmovaps [rsp+0xA0], xmm10
000074c3551d8a61  vmovaps [rsp+0xB0], xmm11
000074c3551d8a6a  vmovaps [rsp+0xC0], xmm12
000074c3551d8a73  vmovaps [rsp+0xD0], xmm13
000074c3551d8a7c  vmovaps [rsp+0xE0], xmm15
000074c3551d8a85  sub rsp, 0x30
000074c3551d8a89  movaps [rsp], xmm14
000074c3551d8a8e  movaps [rsp+0x10], xmm2
000074c3551d8a93  movaps [rsp+0x20], xmm1
000074c3551d8a98  lea rdi, [rsp]
000074c3551d8a9c  mov esi, 0x00
000074c3551d8aa1  mov rax, 0x5F9407FA9530
000074c3551d8aab  call rax
000074c3551d8aad  movaps xmm14, [rsp]
000074c3551d8ab2  add rsp, 0x30
000074c3551d8ab6  vmovaps xmm0, [rsp]
000074c3551d8abb  vmovaps xmm1, [rsp+0x10]
000074c3551d8ac1  vmovaps xmm2, [rsp+0x20]
000074c3551d8ac7  vmovaps xmm3, [rsp+0x30]
000074c3551d8acd  vmovaps xmm4, [rsp+0x40]
000074c3551d8ad3  vmovaps xmm5, [rsp+0x50]
000074c3551d8ad9  vmovaps xmm6, [rsp+0x60]
000074c3551d8adf  vmovaps xmm7, [rsp+0x70]
000074c3551d8ae5  vmovaps xmm8, [rsp+0x80]
000074c3551d8aee  vmovaps xmm9, [rsp+0x90]
000074c3551d8af7  vmovaps xmm10, [rsp+0xA0]
000074c3551d8b00  vmovaps xmm11, [rsp+0xB0]
000074c3551d8b09  vmovaps xmm12, [rsp+0xC0]
000074c3551d8b12  vmovaps xmm13, [rsp+0xD0]
000074c3551d8b1b  vmovaps xmm15, [rsp+0xE0]
000074c3551d8b24  add rsp, 0xF0
000074c3551d8b2b  pop r11
000074c3551d8b2d  pop r10
000074c3551d8b2f  pop r9
000074c3551d8b31  pop r8
000074c3551d8b33  pop rsi
000074c3551d8b34  pop rdi
000074c3551d8b35  pop rdx
000074c3551d8b36  pop rcx
000074c3551d8b37  pop rax
000074c3551d8b38  add rsp, 0x08
000074c3551d8b3c  jmp 0x000074C3551D611D
000074c3551d8b41  sub rsp, 0x08
000074c3551d8b45  push rax
000074c3551d8b46  push rcx
000074c3551d8b47  push rdx
000074c3551d8b48  push rdi
000074c3551d8b49  push rsi
000074c3551d8b4a  push r8
000074c3551d8b4c  push r9
000074c3551d8b4e  push r10
000074c3551d8b50  push r11
000074c3551d8b52  sub rsp, 0xF0
000074c3551d8b59  vmovaps [rsp], xmm0
000074c3551d8b5e  vmovaps [rsp+0x10], xmm2
000074c3551d8b64  vmovaps [rsp+0x20], xmm3
000074c3551d8b6a  vmovaps [rsp+0x30], xmm4
000074c3551d8b70  vmovaps [rsp+0x40], xmm5
000074c3551d8b76  vmovaps [rsp+0x50], xmm6
000074c3551d8b7c  vmovaps [rsp+0x60], xmm7
000074c3551d8b82  vmovaps [rsp+0x70], xmm8
000074c3551d8b88  vmovaps [rsp+0x80], xmm9
000074c3551d8b91  vmovaps [rsp+0x90], xmm10
000074c3551d8b9a  vmovaps [rsp+0xA0], xmm11
000074c3551d8ba3  vmovaps [rsp+0xB0], xmm12
000074c3551d8bac  vmovaps [rsp+0xC0], xmm13
000074c3551d8bb5  vmovaps [rsp+0xD0], xmm14
000074c3551d8bbe  vmovaps [rsp+0xE0], xmm15
000074c3551d8bc7  sub rsp, 0x30
000074c3551d8bcb  movaps [rsp], xmm1
000074c3551d8bcf  movaps [rsp+0x10], xmm4
000074c3551d8bd4  movaps [rsp+0x20], xmm9
000074c3551d8bda  lea rdi, [rsp]
000074c3551d8bde  mov esi, 0x00
000074c3551d8be3  mov rax, 0x5F9407FA9530
000074c3551d8bed  call rax
000074c3551d8bef  movaps xmm1, [rsp]
000074c3551d8bf3  add rsp, 0x30
000074c3551d8bf7  vmovaps xmm0, [rsp]
000074c3551d8bfc  vmovaps xmm2, [rsp+0x10]
000074c3551d8c02  vmovaps xmm3, [rsp+0x20]
000074c3551d8c08  vmovaps xmm4, [rsp+0x30]
000074c3551d8c0e  vmovaps xmm5, [rsp+0x40]
000074c3551d8c14  vmovaps xmm6, [rsp+0x50]
000074c3551d8c1a  vmovaps xmm7, [rsp+0x60]
000074c3551d8c20  vmovaps xmm8, [rsp+0x70]
000074c3551d8c26  vmovaps xmm9, [rsp+0x80]
000074c3551d8c2f  vmovaps xmm10, [rsp+0x90]
000074c3551d8c38  vmovaps xmm11, [rsp+0xA0]
000074c3551d8c41  vmovaps xmm12, [rsp+0xB0]
000074c3551d8c4a  vmovaps xmm13, [rsp+0xC0]
000074c3551d8c53  vmovaps xmm14, [rsp+0xD0]
000074c3551d8c5c  vmovaps xmm15, [rsp+0xE0]
000074c3551d8c65  add rsp, 0xF0
000074c3551d8c6c  pop r11
000074c3551d8c6e  pop r10
000074c3551d8c70  pop r9
000074c3551d8c72  pop r8
000074c3551d8c74  pop rsi
000074c3551d8c75  pop rdi
000074c3551d8c76  pop rdx
000074c3551d8c77  pop rcx
000074c3551d8c78  pop rax
000074c3551d8c79  add rsp, 0x08
000074c3551d8c7d  jmp 0x000074C3551D613B
000074c3551d8c82  sub rsp, 0x08
000074c3551d8c86  push rax
000074c3551d8c87  push rcx
000074c3551d8c88  push rdx
000074c3551d8c89  push rdi
000074c3551d8c8a  push rsi
000074c3551d8c8b  push r8
000074c3551d8c8d  push r9
000074c3551d8c8f  push r10
000074c3551d8c91  push r11
000074c3551d8c93  sub rsp, 0xF0
000074c3551d8c9a  vmovaps [rsp], xmm0
000074c3551d8c9f  vmovaps [rsp+0x10], xmm1
000074c3551d8ca5  vmovaps [rsp+0x20], xmm2
000074c3551d8cab  vmovaps [rsp+0x30], xmm3
000074c3551d8cb1  vmovaps [rsp+0x40], xmm5
000074c3551d8cb7  vmovaps [rsp+0x50], xmm6
000074c3551d8cbd  vmovaps [rsp+0x60], xmm7
000074c3551d8cc3  vmovaps [rsp+0x70], xmm8
000074c3551d8cc9  vmovaps [rsp+0x80], xmm9
000074c3551d8cd2  vmovaps [rsp+0x90], xmm10
000074c3551d8cdb  vmovaps [rsp+0xA0], xmm11
000074c3551d8ce4  vmovaps [rsp+0xB0], xmm12
000074c3551d8ced  vmovaps [rsp+0xC0], xmm13
000074c3551d8cf6  vmovaps [rsp+0xD0], xmm14
000074c3551d8cff  vmovaps [rsp+0xE0], xmm15
000074c3551d8d08  sub rsp, 0x30
000074c3551d8d0c  movaps [rsp], xmm4
000074c3551d8d10  movaps [rsp+0x10], xmm2
000074c3551d8d15  movaps [rsp+0x20], xmm9
000074c3551d8d1b  lea rdi, [rsp]
000074c3551d8d1f  mov esi, 0x00
000074c3551d8d24  mov rax, 0x5F9407FA9530
000074c3551d8d2e  call rax
000074c3551d8d30  movaps xmm4, [rsp]
000074c3551d8d34  add rsp, 0x30
000074c3551d8d38  vmovaps xmm0, [rsp]
000074c3551d8d3d  vmovaps xmm1, [rsp+0x10]
000074c3551d8d43  vmovaps xmm2, [rsp+0x20]
000074c3551d8d49  vmovaps xmm3, [rsp+0x30]
000074c3551d8d4f  vmovaps xmm5, [rsp+0x40]
000074c3551d8d55  vmovaps xmm6, [rsp+0x50]
000074c3551d8d5b  vmovaps xmm7, [rsp+0x60]
000074c3551d8d61  vmovaps xmm8, [rsp+0x70]
000074c3551d8d67  vmovaps xmm9, [rsp+0x80]
000074c3551d8d70  vmovaps xmm10, [rsp+0x90]
000074c3551d8d79  vmovaps xmm11, [rsp+0xA0]
000074c3551d8d82  vmovaps xmm12, [rsp+0xB0]
000074c3551d8d8b  vmovaps xmm13, [rsp+0xC0]
000074c3551d8d94  vmovaps xmm14, [rsp+0xD0]
000074c3551d8d9d  vmovaps xmm15, [rsp+0xE0]
000074c3551d8da6  add rsp, 0xF0
000074c3551d8dad  pop r11
000074c3551d8daf  pop r10
000074c3551d8db1  pop r9
000074c3551d8db3  pop r8
000074c3551d8db5  pop rsi
000074c3551d8db6  pop rdi
000074c3551d8db7  pop rdx
000074c3551d8db8  pop rcx
000074c3551d8db9  pop rax
000074c3551d8dba  add rsp, 0x08
000074c3551d8dbe  jmp 0x000074C3551D616B
000074c3551d8dc3  sub rsp, 0x08
000074c3551d8dc7  push rax
000074c3551d8dc8  push rcx
000074c3551d8dc9  push rdx
000074c3551d8dca  push rdi
000074c3551d8dcb  push rsi
000074c3551d8dcc  push r8
000074c3551d8dce  push r9
000074c3551d8dd0  push r10
000074c3551d8dd2  push r11
000074c3551d8dd4  sub rsp, 0xF0
000074c3551d8ddb  vmovaps [rsp], xmm0
000074c3551d8de0  vmovaps [rsp+0x10], xmm1
000074c3551d8de6  vmovaps [rsp+0x20], xmm2
000074c3551d8dec  vmovaps [rsp+0x30], xmm3
000074c3551d8df2  vmovaps [rsp+0x40], xmm4
000074c3551d8df8  vmovaps [rsp+0x50], xmm5
000074c3551d8dfe  vmovaps [rsp+0x60], xmm6
000074c3551d8e04  vmovaps [rsp+0x70], xmm7
000074c3551d8e0a  vmovaps [rsp+0x80], xmm8
000074c3551d8e13  vmovaps [rsp+0x90], xmm10
000074c3551d8e1c  vmovaps [rsp+0xA0], xmm11
000074c3551d8e25  vmovaps [rsp+0xB0], xmm12
000074c3551d8e2e  vmovaps [rsp+0xC0], xmm13
000074c3551d8e37  vmovaps [rsp+0xD0], xmm14
000074c3551d8e40  vmovaps [rsp+0xE0], xmm15
000074c3551d8e49  sub rsp, 0x30
000074c3551d8e4d  movaps [rsp], xmm9
000074c3551d8e52  movaps [rsp+0x10], xmm2
000074c3551d8e57  movaps [rsp+0x20], xmm1
000074c3551d8e5c  lea rdi, [rsp]
000074c3551d8e60  mov esi, 0x00
000074c3551d8e65  mov rax, 0x5F9407FA9530
000074c3551d8e6f  call rax
000074c3551d8e71  movaps xmm9, [rsp]
000074c3551d8e76  add rsp, 0x30
000074c3551d8e7a  vmovaps xmm0, [rsp]
000074c3551d8e7f  vmovaps xmm1, [rsp+0x10]
000074c3551d8e85  vmovaps xmm2, [rsp+0x20]
000074c3551d8e8b  vmovaps xmm3, [rsp+0x30]
000074c3551d8e91  vmovaps xmm4, [rsp+0x40]
000074c3551d8e97  vmovaps xmm5, [rsp+0x50]
000074c3551d8e9d  vmovaps xmm6, [rsp+0x60]
000074c3551d8ea3  vmovaps xmm7, [rsp+0x70]
000074c3551d8ea9  vmovaps xmm8, [rsp+0x80]
000074c3551d8eb2  vmovaps xmm10, [rsp+0x90]
000074c3551d8ebb  vmovaps xmm11, [rsp+0xA0]
000074c3551d8ec4  vmovaps xmm12, [rsp+0xB0]
000074c3551d8ecd  vmovaps xmm13, [rsp+0xC0]
000074c3551d8ed6  vmovaps xmm14, [rsp+0xD0]
000074c3551d8edf  vmovaps xmm15, [rsp+0xE0]
000074c3551d8ee8  add rsp, 0xF0
000074c3551d8eef  pop r11
000074c3551d8ef1  pop r10
000074c3551d8ef3  pop r9
000074c3551d8ef5  pop r8
000074c3551d8ef7  pop rsi
000074c3551d8ef8  pop rdi
000074c3551d8ef9  pop rdx
000074c3551d8efa  pop rcx
000074c3551d8efb  pop rax
000074c3551d8efc  add rsp, 0x08
000074c3551d8f00  jmp 0x000074C3551D61A1
000074c3551d8f05  sub rsp, 0x08
000074c3551d8f09  push rax
000074c3551d8f0a  push rcx
000074c3551d8f0b  push rdx
000074c3551d8f0c  push rdi
000074c3551d8f0d  push rsi
000074c3551d8f0e  push r8
000074c3551d8f10  push r9
000074c3551d8f12  push r10
000074c3551d8f14  push r11
000074c3551d8f16  sub rsp, 0xF0
000074c3551d8f1d  vmovaps [rsp], xmm0
000074c3551d8f22  vmovaps [rsp+0x10], xmm2
000074c3551d8f28  vmovaps [rsp+0x20], xmm3
000074c3551d8f2e  vmovaps [rsp+0x30], xmm4
000074c3551d8f34  vmovaps [rsp+0x40], xmm5
000074c3551d8f3a  vmovaps [rsp+0x50], xmm6
000074c3551d8f40  vmovaps [rsp+0x60], xmm7
000074c3551d8f46  vmovaps [rsp+0x70], xmm8
000074c3551d8f4c  vmovaps [rsp+0x80], xmm9
000074c3551d8f55  vmovaps [rsp+0x90], xmm10
000074c3551d8f5e  vmovaps [rsp+0xA0], xmm11
000074c3551d8f67  vmovaps [rsp+0xB0], xmm12
000074c3551d8f70  vmovaps [rsp+0xC0], xmm13
000074c3551d8f79  vmovaps [rsp+0xD0], xmm14
000074c3551d8f82  vmovaps [rsp+0xE0], xmm15
000074c3551d8f8b  sub rsp, 0x30
000074c3551d8f8f  movaps [rsp], xmm1
000074c3551d8f93  movaps [rsp+0x10], xmm15
000074c3551d8f99  movaps [rsp+0x20], xmm6
000074c3551d8f9e  lea rdi, [rsp]
000074c3551d8fa2  mov esi, 0x00
000074c3551d8fa7  mov rax, 0x5F9407FA9530
000074c3551d8fb1  call rax
000074c3551d8fb3  movaps xmm1, [rsp]
000074c3551d8fb7  add rsp, 0x30
000074c3551d8fbb  vmovaps xmm0, [rsp]
000074c3551d8fc0  vmovaps xmm2, [rsp+0x10]
000074c3551d8fc6  vmovaps xmm3, [rsp+0x20]
000074c3551d8fcc  vmovaps xmm4, [rsp+0x30]
000074c3551d8fd2  vmovaps xmm5, [rsp+0x40]
000074c3551d8fd8  vmovaps xmm6, [rsp+0x50]
000074c3551d8fde  vmovaps xmm7, [rsp+0x60]
000074c3551d8fe4  vmovaps xmm8, [rsp+0x70]
000074c3551d8fea  vmovaps xmm9, [rsp+0x80]
000074c3551d8ff3  vmovaps xmm10, [rsp+0x90]
000074c3551d8ffc  vmovaps xmm11, [rsp+0xA0]
000074c3551d9005  vmovaps xmm12, [rsp+0xB0]
000074c3551d900e  vmovaps xmm13, [rsp+0xC0]
000074c3551d9017  vmovaps xmm14, [rsp+0xD0]
000074c3551d9020  vmovaps xmm15, [rsp+0xE0]
000074c3551d9029  add rsp, 0xF0
000074c3551d9030  pop r11
000074c3551d9032  pop r10
000074c3551d9034  pop r9
000074c3551d9036  pop r8
000074c3551d9038  pop rsi
000074c3551d9039  pop rdi
000074c3551d903a  pop rdx
000074c3551d903b  pop rcx
000074c3551d903c  pop rax
000074c3551d903d  add rsp, 0x08
000074c3551d9041  jmp 0x000074C3551D61C2
000074c3551d9046  sub rsp, 0x08
000074c3551d904a  push rax
000074c3551d904b  push rcx
000074c3551d904c  push rdx
000074c3551d904d  push rdi
000074c3551d904e  push rsi
000074c3551d904f  push r8
000074c3551d9051  push r9
000074c3551d9053  push r10
000074c3551d9055  push r11
000074c3551d9057  sub rsp, 0xF0
000074c3551d905e  vmovaps [rsp], xmm0
000074c3551d9063  vmovaps [rsp+0x10], xmm1
000074c3551d9069  vmovaps [rsp+0x20], xmm2
000074c3551d906f  vmovaps [rsp+0x30], xmm3
000074c3551d9075  vmovaps [rsp+0x40], xmm4
000074c3551d907b  vmovaps [rsp+0x50], xmm5
000074c3551d9081  vmovaps [rsp+0x60], xmm6
000074c3551d9087  vmovaps [rsp+0x70], xmm7
000074c3551d908d  vmovaps [rsp+0x80], xmm8
000074c3551d9096  vmovaps [rsp+0x90], xmm9
000074c3551d909f  vmovaps [rsp+0xA0], xmm10
000074c3551d90a8  vmovaps [rsp+0xB0], xmm11
000074c3551d90b1  vmovaps [rsp+0xC0], xmm12
000074c3551d90ba  vmovaps [rsp+0xD0], xmm13
000074c3551d90c3  vmovaps [rsp+0xE0], xmm14
000074c3551d90cc  sub rsp, 0x30
000074c3551d90d0  movaps [rsp], xmm15
000074c3551d90d5  movaps [rsp+0x10], xmm5
000074c3551d90da  movaps [rsp+0x20], xmm3
000074c3551d90df  lea rdi, [rsp]
000074c3551d90e3  mov esi, 0x00
000074c3551d90e8  mov rax, 0x5F9407FA9530
000074c3551d90f2  call rax
000074c3551d90f4  movaps xmm15, [rsp]
000074c3551d90f9  add rsp, 0x30
000074c3551d90fd  vmovaps xmm0, [rsp]
000074c3551d9102  vmovaps xmm1, [rsp+0x10]
000074c3551d9108  vmovaps xmm2, [rsp+0x20]
000074c3551d910e  vmovaps xmm3, [rsp+0x30]
000074c3551d9114  vmovaps xmm4, [rsp+0x40]
000074c3551d911a  vmovaps xmm5, [rsp+0x50]
000074c3551d9120  vmovaps xmm6, [rsp+0x60]
000074c3551d9126  vmovaps xmm7, [rsp+0x70]
000074c3551d912c  vmovaps xmm8, [rsp+0x80]
000074c3551d9135  vmovaps xmm9, [rsp+0x90]
000074c3551d913e  vmovaps xmm10, [rsp+0xA0]
000074c3551d9147  vmovaps xmm11, [rsp+0xB0]
000074c3551d9150  vmovaps xmm12, [rsp+0xC0]
000074c3551d9159  vmovaps xmm13, [rsp+0xD0]
000074c3551d9162  vmovaps xmm14, [rsp+0xE0]
000074c3551d916b  add rsp, 0xF0
000074c3551d9172  pop r11
000074c3551d9174  pop r10
000074c3551d9176  pop r9
000074c3551d9178  pop r8
000074c3551d917a  pop rsi
000074c3551d917b  pop rdi
000074c3551d917c  pop rdx
000074c3551d917d  pop rcx
000074c3551d917e  pop rax
000074c3551d917f  add rsp, 0x08
000074c3551d9183  jmp 0x000074C3551D61DC
000074c3551d9188  sub rsp, 0x08
000074c3551d918c  push rax
000074c3551d918d  push rcx
000074c3551d918e  push rdx
000074c3551d918f  push rdi
000074c3551d9190  push rsi
000074c3551d9191  push r8
000074c3551d9193  push r9
000074c3551d9195  push r10
000074c3551d9197  push r11
000074c3551d9199  sub rsp, 0xF0
000074c3551d91a0  vmovaps [rsp], xmm0
000074c3551d91a5  vmovaps [rsp+0x10], xmm1
000074c3551d91ab  vmovaps [rsp+0x20], xmm2
000074c3551d91b1  vmovaps [rsp+0x30], xmm3
000074c3551d91b7  vmovaps [rsp+0x40], xmm4
000074c3551d91bd  vmovaps [rsp+0x50], xmm6
000074c3551d91c3  vmovaps [rsp+0x60], xmm7
000074c3551d91c9  vmovaps [rsp+0x70], xmm8
000074c3551d91cf  vmovaps [rsp+0x80], xmm9
000074c3551d91d8  vmovaps [rsp+0x90], xmm10
000074c3551d91e1  vmovaps [rsp+0xA0], xmm11
000074c3551d91ea  vmovaps [rsp+0xB0], xmm12
000074c3551d91f3  vmovaps [rsp+0xC0], xmm13
000074c3551d91fc  vmovaps [rsp+0xD0], xmm14
000074c3551d9205  vmovaps [rsp+0xE0], xmm15
000074c3551d920e  sub rsp, 0x30
000074c3551d9212  movaps [rsp], xmm5
000074c3551d9216  movaps [rsp+0x10], xmm8
000074c3551d921c  movaps [rsp+0x20], xmm6
000074c3551d9221  lea rdi, [rsp]
000074c3551d9225  mov esi, 0x00
000074c3551d922a  mov rax, 0x5F9407FA9530
000074c3551d9234  call rax
000074c3551d9236  movaps xmm5, [rsp]
000074c3551d923a  add rsp, 0x30
000074c3551d923e  vmovaps xmm0, [rsp]
000074c3551d9243  vmovaps xmm1, [rsp+0x10]
000074c3551d9249  vmovaps xmm2, [rsp+0x20]
000074c3551d924f  vmovaps xmm3, [rsp+0x30]
000074c3551d9255  vmovaps xmm4, [rsp+0x40]
000074c3551d925b  vmovaps xmm6, [rsp+0x50]
000074c3551d9261  vmovaps xmm7, [rsp+0x60]
000074c3551d9267  vmovaps xmm8, [rsp+0x70]
000074c3551d926d  vmovaps xmm9, [rsp+0x80]
000074c3551d9276  vmovaps xmm10, [rsp+0x90]
000074c3551d927f  vmovaps xmm11, [rsp+0xA0]
000074c3551d9288  vmovaps xmm12, [rsp+0xB0]
000074c3551d9291  vmovaps xmm13, [rsp+0xC0]
000074c3551d929a  vmovaps xmm14, [rsp+0xD0]
000074c3551d92a3  vmovaps xmm15, [rsp+0xE0]
000074c3551d92ac  add rsp, 0xF0
000074c3551d92b3  pop r11
000074c3551d92b5  pop r10
000074c3551d92b7  pop r9
000074c3551d92b9  pop r8
000074c3551d92bb  pop rsi
000074c3551d92bc  pop rdi
000074c3551d92bd  pop rdx
000074c3551d92be  pop rcx
000074c3551d92bf  pop rax
000074c3551d92c0  add rsp, 0x08
000074c3551d92c4  jmp 0x000074C3551D6200
000074c3551d92c9  sub rsp, 0x08
000074c3551d92cd  push rax
000074c3551d92ce  push rcx
000074c3551d92cf  push rdx
000074c3551d92d0  push rdi
000074c3551d92d1  push rsi
000074c3551d92d2  push r8
000074c3551d92d4  push r9
000074c3551d92d6  push r10
000074c3551d92d8  push r11
000074c3551d92da  sub rsp, 0xF0
000074c3551d92e1  vmovaps [rsp], xmm0
000074c3551d92e6  vmovaps [rsp+0x10], xmm1
000074c3551d92ec  vmovaps [rsp+0x20], xmm2
000074c3551d92f2  vmovaps [rsp+0x30], xmm3
000074c3551d92f8  vmovaps [rsp+0x40], xmm4
000074c3551d92fe  vmovaps [rsp+0x50], xmm5
000074c3551d9304  vmovaps [rsp+0x60], xmm7
000074c3551d930a  vmovaps [rsp+0x70], xmm8
000074c3551d9310  vmovaps [rsp+0x80], xmm9
000074c3551d9319  vmovaps [rsp+0x90], xmm10
000074c3551d9322  vmovaps [rsp+0xA0], xmm11
000074c3551d932b  vmovaps [rsp+0xB0], xmm12
000074c3551d9334  vmovaps [rsp+0xC0], xmm13
000074c3551d933d  vmovaps [rsp+0xD0], xmm14
000074c3551d9346  vmovaps [rsp+0xE0], xmm15
000074c3551d934f  sub rsp, 0x30
000074c3551d9353  movaps [rsp], xmm6
000074c3551d9357  movaps [rsp+0x10], xmm10
000074c3551d935d  movaps [rsp+0x20], xmm8
000074c3551d9363  lea rdi, [rsp]
000074c3551d9367  mov esi, 0x00
000074c3551d936c  mov rax, 0x5F9407FA9530
000074c3551d9376  call rax
000074c3551d9378  movaps xmm6, [rsp]
000074c3551d937c  add rsp, 0x30
000074c3551d9380  vmovaps xmm0, [rsp]
000074c3551d9385  vmovaps xmm1, [rsp+0x10]
000074c3551d938b  vmovaps xmm2, [rsp+0x20]
000074c3551d9391  vmovaps xmm3, [rsp+0x30]
000074c3551d9397  vmovaps xmm4, [rsp+0x40]
000074c3551d939d  vmovaps xmm5, [rsp+0x50]
000074c3551d93a3  vmovaps xmm7, [rsp+0x60]
000074c3551d93a9  vmovaps xmm8, [rsp+0x70]
000074c3551d93af  vmovaps xmm9, [rsp+0x80]
000074c3551d93b8  vmovaps xmm10, [rsp+0x90]
000074c3551d93c1  vmovaps xmm11, [rsp+0xA0]
000074c3551d93ca  vmovaps xmm12, [rsp+0xB0]
000074c3551d93d3  vmovaps xmm13, [rsp+0xC0]
000074c3551d93dc  vmovaps xmm14, [rsp+0xD0]
000074c3551d93e5  vmovaps xmm15, [rsp+0xE0]
000074c3551d93ee  add rsp, 0xF0
000074c3551d93f5  pop r11
000074c3551d93f7  pop r10
000074c3551d93f9  pop r9
000074c3551d93fb  pop r8
000074c3551d93fd  pop rsi
000074c3551d93fe  pop rdi
000074c3551d93ff  pop rdx
000074c3551d9400  pop rcx
000074c3551d9401  pop rax
000074c3551d9402  add rsp, 0x08
000074c3551d9406  jmp 0x000074C3551D6225
000074c3551d940b  sub rsp, 0x08
000074c3551d940f  push rax
000074c3551d9410  push rcx
000074c3551d9411  push rdx
000074c3551d9412  push rdi
000074c3551d9413  push rsi
000074c3551d9414  push r8
000074c3551d9416  push r9
000074c3551d9418  push r10
000074c3551d941a  push r11
000074c3551d941c  sub rsp, 0xF0
000074c3551d9423  vmovaps [rsp], xmm0
000074c3551d9428  vmovaps [rsp+0x10], xmm1
000074c3551d942e  vmovaps [rsp+0x20], xmm2
000074c3551d9434  vmovaps [rsp+0x30], xmm3
000074c3551d943a  vmovaps [rsp+0x40], xmm4
000074c3551d9440  vmovaps [rsp+0x50], xmm5
000074c3551d9446  vmovaps [rsp+0x60], xmm6
000074c3551d944c  vmovaps [rsp+0x70], xmm7
000074c3551d9452  vmovaps [rsp+0x80], xmm8
000074c3551d945b  vmovaps [rsp+0x90], xmm9
000074c3551d9464  vmovaps [rsp+0xA0], xmm11
000074c3551d946d  vmovaps [rsp+0xB0], xmm12
000074c3551d9476  vmovaps [rsp+0xC0], xmm13
000074c3551d947f  vmovaps [rsp+0xD0], xmm14
000074c3551d9488  vmovaps [rsp+0xE0], xmm15
000074c3551d9491  sub rsp, 0x30
000074c3551d9495  movaps [rsp], xmm10
000074c3551d949a  movaps [rsp+0x10], xmm8
000074c3551d94a0  movaps [rsp+0x20], xmm14
000074c3551d94a6  lea rdi, [rsp]
000074c3551d94aa  mov esi, 0x00
000074c3551d94af  mov rax, 0x5F9407FA9530
000074c3551d94b9  call rax
000074c3551d94bb  movaps xmm10, [rsp]
000074c3551d94c0  add rsp, 0x30
000074c3551d94c4  vmovaps xmm0, [rsp]
000074c3551d94c9  vmovaps xmm1, [rsp+0x10]
000074c3551d94cf  vmovaps xmm2, [rsp+0x20]
000074c3551d94d5  vmovaps xmm3, [rsp+0x30]
000074c3551d94db  vmovaps xmm4, [rsp+0x40]
000074c3551d94e1  vmovaps xmm5, [rsp+0x50]
000074c3551d94e7  vmovaps xmm6, [rsp+0x60]
000074c3551d94ed  vmovaps xmm7, [rsp+0x70]
000074c3551d94f3  vmovaps xmm8, [rsp+0x80]
000074c3551d94fc  vmovaps xmm9, [rsp+0x90]
000074c3551d9505  vmovaps xmm11, [rsp+0xA0]
000074c3551d950e  vmovaps xmm12, [rsp+0xB0]
000074c3551d9517  vmovaps xmm13, [rsp+0xC0]
000074c3551d9520  vmovaps xmm14, [rsp+0xD0]
000074c3551d9529  vmovaps xmm15, [rsp+0xE0]
000074c3551d9532  add rsp, 0xF0
000074c3551d9539  pop r11
000074c3551d953b  pop r10
000074c3551d953d  pop r9
000074c3551d953f  pop r8
000074c3551d9541  pop rsi
000074c3551d9542  pop rdi
000074c3551d9543  pop rdx
000074c3551d9544  pop rcx
000074c3551d9545  pop rax
000074c3551d9546  add rsp, 0x08
000074c3551d954a  jmp 0x000074C3551D6245
000074c3551d954f  sub rsp, 0x08
000074c3551d9553  push rax
000074c3551d9554  push rcx
000074c3551d9555  push rdx
000074c3551d9556  push rdi
000074c3551d9557  push rsi
000074c3551d9558  push r8
000074c3551d955a  push r9
000074c3551d955c  push r10
000074c3551d955e  push r11
000074c3551d9560  sub rsp, 0xF0
000074c3551d9567  vmovaps [rsp], xmm0
000074c3551d956c  vmovaps [rsp+0x10], xmm1
000074c3551d9572  vmovaps [rsp+0x20], xmm2
000074c3551d9578  vmovaps [rsp+0x30], xmm3
000074c3551d957e  vmovaps [rsp+0x40], xmm4
000074c3551d9584  vmovaps [rsp+0x50], xmm5
000074c3551d958a  vmovaps [rsp+0x60], xmm6
000074c3551d9590  vmovaps [rsp+0x70], xmm7
000074c3551d9596  vmovaps [rsp+0x80], xmm8
000074c3551d959f  vmovaps [rsp+0x90], xmm9
000074c3551d95a8  vmovaps [rsp+0xA0], xmm10
000074c3551d95b1  vmovaps [rsp+0xB0], xmm11
000074c3551d95ba  vmovaps [rsp+0xC0], xmm12
000074c3551d95c3  vmovaps [rsp+0xD0], xmm13
000074c3551d95cc  vmovaps [rsp+0xE0], xmm15
000074c3551d95d5  sub rsp, 0x30
000074c3551d95d9  movaps [rsp], xmm14
000074c3551d95de  movaps [rsp+0x10], xmm8
000074c3551d95e4  movaps [rsp+0x20], xmm4
000074c3551d95e9  lea rdi, [rsp]
000074c3551d95ed  mov esi, 0x00
000074c3551d95f2  mov rax, 0x5F9407FA9530
000074c3551d95fc  call rax
000074c3551d95fe  movaps xmm14, [rsp]
000074c3551d9603  add rsp, 0x30
000074c3551d9607  vmovaps xmm0, [rsp]
000074c3551d960c  vmovaps xmm1, [rsp+0x10]
000074c3551d9612  vmovaps xmm2, [rsp+0x20]
000074c3551d9618  vmovaps xmm3, [rsp+0x30]
000074c3551d961e  vmovaps xmm4, [rsp+0x40]
000074c3551d9624  vmovaps xmm5, [rsp+0x50]
000074c3551d962a  vmovaps xmm6, [rsp+0x60]
000074c3551d9630  vmovaps xmm7, [rsp+0x70]
000074c3551d9636  vmovaps xmm8, [rsp+0x80]
000074c3551d963f  vmovaps xmm9, [rsp+0x90]
000074c3551d9648  vmovaps xmm10, [rsp+0xA0]
000074c3551d9651  vmovaps xmm11, [rsp+0xB0]
000074c3551d965a  vmovaps xmm12, [rsp+0xC0]
000074c3551d9663  vmovaps xmm13, [rsp+0xD0]
000074c3551d966c  vmovaps xmm15, [rsp+0xE0]
000074c3551d9675  add rsp, 0xF0
000074c3551d967c  pop r11
000074c3551d967e  pop r10
000074c3551d9680  pop r9
000074c3551d9682  pop r8
000074c3551d9684  pop rsi
000074c3551d9685  pop rdi
000074c3551d9686  pop rdx
000074c3551d9687  pop rcx
000074c3551d9688  pop rax
000074c3551d9689  add rsp, 0x08
000074c3551d968d  jmp 0x000074C3551D6265
000074c3551d9692  sub rsp, 0x08
000074c3551d9696  push rax
000074c3551d9697  push rcx
000074c3551d9698  push rdx
000074c3551d9699  push rdi
000074c3551d969a  push rsi
000074c3551d969b  push r8
000074c3551d969d  push r9
000074c3551d969f  push r10
000074c3551d96a1  push r11
000074c3551d96a3  sub rsp, 0xF0
000074c3551d96aa  vmovaps [rsp], xmm0
000074c3551d96af  vmovaps [rsp+0x10], xmm1
000074c3551d96b5  vmovaps [rsp+0x20], xmm2
000074c3551d96bb  vmovaps [rsp+0x30], xmm3
000074c3551d96c1  vmovaps [rsp+0x40], xmm5
000074c3551d96c7  vmovaps [rsp+0x50], xmm6
000074c3551d96cd  vmovaps [rsp+0x60], xmm7
000074c3551d96d3  vmovaps [rsp+0x70], xmm8
000074c3551d96d9  vmovaps [rsp+0x80], xmm9
000074c3551d96e2  vmovaps [rsp+0x90], xmm10
000074c3551d96eb  vmovaps [rsp+0xA0], xmm11
000074c3551d96f4  vmovaps [rsp+0xB0], xmm12
000074c3551d96fd  vmovaps [rsp+0xC0], xmm13
000074c3551d9706  vmovaps [rsp+0xD0], xmm14
000074c3551d970f  vmovaps [rsp+0xE0], xmm15
000074c3551d9718  sub rsp, 0x30
000074c3551d971c  movaps [rsp], xmm4
000074c3551d9720  movaps [rsp+0x10], xmm13
000074c3551d9726  movaps [rsp+0x20], xmm8
000074c3551d972c  lea rdi, [rsp]
000074c3551d9730  mov esi, 0x00
000074c3551d9735  mov rax, 0x5F9407FA9530
000074c3551d973f  call rax
000074c3551d9741  movaps xmm4, [rsp]
000074c3551d9745  add rsp, 0x30
000074c3551d9749  vmovaps xmm0, [rsp]
000074c3551d974e  vmovaps xmm1, [rsp+0x10]
000074c3551d9754  vmovaps xmm2, [rsp+0x20]
000074c3551d975a  vmovaps xmm3, [rsp+0x30]
000074c3551d9760  vmovaps xmm5, [rsp+0x40]
000074c3551d9766  vmovaps xmm6, [rsp+0x50]
000074c3551d976c  vmovaps xmm7, [rsp+0x60]
000074c3551d9772  vmovaps xmm8, [rsp+0x70]
000074c3551d9778  vmovaps xmm9, [rsp+0x80]
000074c3551d9781  vmovaps xmm10, [rsp+0x90]
000074c3551d978a  vmovaps xmm11, [rsp+0xA0]
000074c3551d9793  vmovaps xmm12, [rsp+0xB0]
000074c3551d979c  vmovaps xmm13, [rsp+0xC0]
000074c3551d97a5  vmovaps xmm14, [rsp+0xD0]
000074c3551d97ae  vmovaps xmm15, [rsp+0xE0]
000074c3551d97b7  add rsp, 0xF0
000074c3551d97be  pop r11
000074c3551d97c0  pop r10
000074c3551d97c2  pop r9
000074c3551d97c4  pop r8
000074c3551d97c6  pop rsi
000074c3551d97c7  pop rdi
000074c3551d97c8  pop rdx
000074c3551d97c9  pop rcx
000074c3551d97ca  pop rax
000074c3551d97cb  add rsp, 0x08
000074c3551d97cf  jmp 0x000074C3551D628A
000074c3551d97d4  sub rsp, 0x08
000074c3551d97d8  push rax
000074c3551d97d9  push rcx
000074c3551d97da  push rdx
000074c3551d97db  push rdi
000074c3551d97dc  push rsi
000074c3551d97dd  push r8
000074c3551d97df  push r9
000074c3551d97e1  push r10
000074c3551d97e3  push r11
000074c3551d97e5  sub rsp, 0xF0
000074c3551d97ec  vmovaps [rsp], xmm0
000074c3551d97f1  vmovaps [rsp+0x10], xmm1
000074c3551d97f7  vmovaps [rsp+0x20], xmm2
000074c3551d97fd  vmovaps [rsp+0x30], xmm3
000074c3551d9803  vmovaps [rsp+0x40], xmm4
000074c3551d9809  vmovaps [rsp+0x50], xmm5
000074c3551d980f  vmovaps [rsp+0x60], xmm6
000074c3551d9815  vmovaps [rsp+0x70], xmm7
000074c3551d981b  vmovaps [rsp+0x80], xmm8
000074c3551d9824  vmovaps [rsp+0x90], xmm9
000074c3551d982d  vmovaps [rsp+0xA0], xmm10
000074c3551d9836  vmovaps [rsp+0xB0], xmm11
000074c3551d983f  vmovaps [rsp+0xC0], xmm12
000074c3551d9848  vmovaps [rsp+0xD0], xmm14
000074c3551d9851  vmovaps [rsp+0xE0], xmm15
000074c3551d985a  sub rsp, 0x30
000074c3551d985e  movaps [rsp], xmm13
000074c3551d9863  movaps [rsp+0x10], xmm15
000074c3551d9869  movaps [rsp+0x20], xmm9
000074c3551d986f  lea rdi, [rsp]
000074c3551d9873  mov esi, 0x00
000074c3551d9878  mov rax, 0x5F9407FA9530
000074c3551d9882  call rax
000074c3551d9884  movaps xmm13, [rsp]
000074c3551d9889  add rsp, 0x30
000074c3551d988d  vmovaps xmm0, [rsp]
000074c3551d9892  vmovaps xmm1, [rsp+0x10]
000074c3551d9898  vmovaps xmm2, [rsp+0x20]
000074c3551d989e  vmovaps xmm3, [rsp+0x30]
000074c3551d98a4  vmovaps xmm4, [rsp+0x40]
000074c3551d98aa  vmovaps xmm5, [rsp+0x50]
000074c3551d98b0  vmovaps xmm6, [rsp+0x60]
000074c3551d98b6  vmovaps xmm7, [rsp+0x70]
000074c3551d98bc  vmovaps xmm8, [rsp+0x80]
000074c3551d98c5  vmovaps xmm9, [rsp+0x90]
000074c3551d98ce  vmovaps xmm10, [rsp+0xA0]
000074c3551d98d7  vmovaps xmm11, [rsp+0xB0]
000074c3551d98e0  vmovaps xmm12, [rsp+0xC0]
000074c3551d98e9  vmovaps xmm14, [rsp+0xD0]
000074c3551d98f2  vmovaps xmm15, [rsp+0xE0]
000074c3551d98fb  add rsp, 0xF0
000074c3551d9902  pop r11
000074c3551d9904  pop r10
000074c3551d9906  pop r9
000074c3551d9908  pop r8
000074c3551d990a  pop rsi
000074c3551d990b  pop rdi
000074c3551d990c  pop rdx
000074c3551d990d  pop rcx
000074c3551d990e  pop rax
000074c3551d990f  add rsp, 0x08
000074c3551d9913  jmp 0x000074C3551D62A5
000074c3551d9918  sub rsp, 0x08
000074c3551d991c  push rax
000074c3551d991d  push rcx
000074c3551d991e  push rdx
000074c3551d991f  push rdi
000074c3551d9920  push rsi
000074c3551d9921  push r8
000074c3551d9923  push r9
000074c3551d9925  push r10
000074c3551d9927  push r11
000074c3551d9929  sub rsp, 0xF0
000074c3551d9930  vmovaps [rsp], xmm0
000074c3551d9935  vmovaps [rsp+0x10], xmm1
000074c3551d993b  vmovaps [rsp+0x20], xmm2
000074c3551d9941  vmovaps [rsp+0x30], xmm3
000074c3551d9947  vmovaps [rsp+0x40], xmm4
000074c3551d994d  vmovaps [rsp+0x50], xmm5
000074c3551d9953  vmovaps [rsp+0x60], xmm6
000074c3551d9959  vmovaps [rsp+0x70], xmm7
000074c3551d995f  vmovaps [rsp+0x80], xmm8
000074c3551d9968  vmovaps [rsp+0x90], xmm9
000074c3551d9971  vmovaps [rsp+0xA0], xmm10
000074c3551d997a  vmovaps [rsp+0xB0], xmm11
000074c3551d9983  vmovaps [rsp+0xC0], xmm12
000074c3551d998c  vmovaps [rsp+0xD0], xmm13
000074c3551d9995  vmovaps [rsp+0xE0], xmm14
000074c3551d999e  sub rsp, 0x30
000074c3551d99a2  movaps [rsp], xmm15
000074c3551d99a7  movaps [rsp+0x10], xmm1
000074c3551d99ac  movaps [rsp+0x20], xmm5
000074c3551d99b1  lea rdi, [rsp]
000074c3551d99b5  mov esi, 0x00
000074c3551d99ba  mov rax, 0x5F9407FA9530
000074c3551d99c4  call rax
000074c3551d99c6  movaps xmm15, [rsp]
000074c3551d99cb  add rsp, 0x30
000074c3551d99cf  vmovaps xmm0, [rsp]
000074c3551d99d4  vmovaps xmm1, [rsp+0x10]
000074c3551d99da  vmovaps xmm2, [rsp+0x20]
000074c3551d99e0  vmovaps xmm3, [rsp+0x30]
000074c3551d99e6  vmovaps xmm4, [rsp+0x40]
000074c3551d99ec  vmovaps xmm5, [rsp+0x50]
000074c3551d99f2  vmovaps xmm6, [rsp+0x60]
000074c3551d99f8  vmovaps xmm7, [rsp+0x70]
000074c3551d99fe  vmovaps xmm8, [rsp+0x80]
000074c3551d9a07  vmovaps xmm9, [rsp+0x90]
000074c3551d9a10  vmovaps xmm10, [rsp+0xA0]
000074c3551d9a19  vmovaps xmm11, [rsp+0xB0]
000074c3551d9a22  vmovaps xmm12, [rsp+0xC0]
000074c3551d9a2b  vmovaps xmm13, [rsp+0xD0]
000074c3551d9a34  vmovaps xmm14, [rsp+0xE0]
000074c3551d9a3d  add rsp, 0xF0
000074c3551d9a44  pop r11
000074c3551d9a46  pop r10
000074c3551d9a48  pop r9
000074c3551d9a4a  pop r8
000074c3551d9a4c  pop rsi
000074c3551d9a4d  pop rdi
000074c3551d9a4e  pop rdx
000074c3551d9a4f  pop rcx
000074c3551d9a50  pop rax
000074c3551d9a51  add rsp, 0x08
000074c3551d9a55  jmp 0x000074C3551D62C0
000074c3551d9a5a  call 0x000074C3550D64F0
000074c3551d9a5f  jmp 0x000074C3551D631B
000074c3551d9a64  sub rsp, 0x08
000074c3551d9a68  push rax
000074c3551d9a69  push rcx
000074c3551d9a6a  push rdx
000074c3551d9a6b  push rdi
000074c3551d9a6c  push rsi
000074c3551d9a6d  push r8
000074c3551d9a6f  push r9
000074c3551d9a71  push r10
000074c3551d9a73  push r11
000074c3551d9a75  sub rsp, 0xF0
000074c3551d9a7c  vmovaps [rsp], xmm0
000074c3551d9a81  vmovaps [rsp+0x10], xmm1
000074c3551d9a87  vmovaps [rsp+0x20], xmm2
000074c3551d9a8d  vmovaps [rsp+0x30], xmm3
000074c3551d9a93  vmovaps [rsp+0x40], xmm4
000074c3551d9a99  vmovaps [rsp+0x50], xmm5
000074c3551d9a9f  vmovaps [rsp+0x60], xmm6
000074c3551d9aa5  vmovaps [rsp+0x70], xmm7
000074c3551d9aab  vmovaps [rsp+0x80], xmm8
000074c3551d9ab4  vmovaps [rsp+0x90], xmm10
000074c3551d9abd  vmovaps [rsp+0xA0], xmm11
000074c3551d9ac6  vmovaps [rsp+0xB0], xmm12
000074c3551d9acf  vmovaps [rsp+0xC0], xmm13
000074c3551d9ad8  vmovaps [rsp+0xD0], xmm14
000074c3551d9ae1  vmovaps [rsp+0xE0], xmm15
000074c3551d9aea  sub rsp, 0x30
000074c3551d9aee  movaps [rsp], xmm9
000074c3551d9af3  movaps [rsp+0x10], xmm8
000074c3551d9af9  movaps [rsp+0x20], xmm11
000074c3551d9aff  lea rdi, [rsp]
000074c3551d9b03  mov esi, 0x00
000074c3551d9b08  mov rax, 0x5F9407FA9530
000074c3551d9b12  call rax
000074c3551d9b14  movaps xmm9, [rsp]
000074c3551d9b19  add rsp, 0x30
000074c3551d9b1d  vmovaps xmm0, [rsp]
000074c3551d9b22  vmovaps xmm1, [rsp+0x10]
000074c3551d9b28  vmovaps xmm2, [rsp+0x20]
000074c3551d9b2e  vmovaps xmm3, [rsp+0x30]
000074c3551d9b34  vmovaps xmm4, [rsp+0x40]
000074c3551d9b3a  vmovaps xmm5, [rsp+0x50]
000074c3551d9b40  vmovaps xmm6, [rsp+0x60]
000074c3551d9b46  vmovaps xmm7, [rsp+0x70]
000074c3551d9b4c  vmovaps xmm8, [rsp+0x80]
000074c3551d9b55  vmovaps xmm10, [rsp+0x90]
000074c3551d9b5e  vmovaps xmm11, [rsp+0xA0]
000074c3551d9b67  vmovaps xmm12, [rsp+0xB0]
000074c3551d9b70  vmovaps xmm13, [rsp+0xC0]
000074c3551d9b79  vmovaps xmm14, [rsp+0xD0]
000074c3551d9b82  vmovaps xmm15, [rsp+0xE0]
000074c3551d9b8b  add rsp, 0xF0
000074c3551d9b92  pop r11
000074c3551d9b94  pop r10
000074c3551d9b96  pop r9
000074c3551d9b98  pop r8
000074c3551d9b9a  pop rsi
000074c3551d9b9b  pop rdi
000074c3551d9b9c  pop rdx
000074c3551d9b9d  pop rcx
000074c3551d9b9e  pop rax
000074c3551d9b9f  add rsp, 0x08
000074c3551d9ba3  jmp 0x000074C3551D6352
000074c3551d9ba8  sub rsp, 0x08
000074c3551d9bac  push rax
000074c3551d9bad  push rcx
000074c3551d9bae  push rdx
000074c3551d9baf  push rdi
000074c3551d9bb0  push rsi
000074c3551d9bb1  push r8
000074c3551d9bb3  push r9
000074c3551d9bb5  push r10
000074c3551d9bb7  push r11
000074c3551d9bb9  sub rsp, 0xF0
000074c3551d9bc0  vmovaps [rsp], xmm0
000074c3551d9bc5  vmovaps [rsp+0x10], xmm1
000074c3551d9bcb  vmovaps [rsp+0x20], xmm2
000074c3551d9bd1  vmovaps [rsp+0x30], xmm3
000074c3551d9bd7  vmovaps [rsp+0x40], xmm4
000074c3551d9bdd  vmovaps [rsp+0x50], xmm5
000074c3551d9be3  vmovaps [rsp+0x60], xmm6
000074c3551d9be9  vmovaps [rsp+0x70], xmm7
000074c3551d9bef  vmovaps [rsp+0x80], xmm8
000074c3551d9bf8  vmovaps [rsp+0x90], xmm9
000074c3551d9c01  vmovaps [rsp+0xA0], xmm10
000074c3551d9c0a  vmovaps [rsp+0xB0], xmm12
000074c3551d9c13  vmovaps [rsp+0xC0], xmm13
000074c3551d9c1c  vmovaps [rsp+0xD0], xmm14
000074c3551d9c25  vmovaps [rsp+0xE0], xmm15
000074c3551d9c2e  sub rsp, 0x30
000074c3551d9c32  movaps [rsp], xmm11
000074c3551d9c37  movaps [rsp+0x10], xmm10
000074c3551d9c3d  movaps [rsp+0x20], xmm6
000074c3551d9c42  lea rdi, [rsp]
000074c3551d9c46  mov esi, 0x00
000074c3551d9c4b  mov rax, 0x5F9407FA9530
000074c3551d9c55  call rax
000074c3551d9c57  movaps xmm11, [rsp]
000074c3551d9c5c  add rsp, 0x30
000074c3551d9c60  vmovaps xmm0, [rsp]
000074c3551d9c65  vmovaps xmm1, [rsp+0x10]
000074c3551d9c6b  vmovaps xmm2, [rsp+0x20]
000074c3551d9c71  vmovaps xmm3, [rsp+0x30]
000074c3551d9c77  vmovaps xmm4, [rsp+0x40]
000074c3551d9c7d  vmovaps xmm5, [rsp+0x50]
000074c3551d9c83  vmovaps xmm6, [rsp+0x60]
000074c3551d9c89  vmovaps xmm7, [rsp+0x70]
000074c3551d9c8f  vmovaps xmm8, [rsp+0x80]
000074c3551d9c98  vmovaps xmm9, [rsp+0x90]
000074c3551d9ca1  vmovaps xmm10, [rsp+0xA0]
000074c3551d9caa  vmovaps xmm12, [rsp+0xB0]
000074c3551d9cb3  vmovaps xmm13, [rsp+0xC0]
000074c3551d9cbc  vmovaps xmm14, [rsp+0xD0]
000074c3551d9cc5  vmovaps xmm15, [rsp+0xE0]
000074c3551d9cce  add rsp, 0xF0
000074c3551d9cd5  pop r11
000074c3551d9cd7  pop r10
000074c3551d9cd9  pop r9
000074c3551d9cdb  pop r8
000074c3551d9cdd  pop rsi
000074c3551d9cde  pop rdi
000074c3551d9cdf  pop rdx
000074c3551d9ce0  pop rcx
000074c3551d9ce1  pop rax
000074c3551d9ce2  add rsp, 0x08
000074c3551d9ce6  jmp 0x000074C3551D636D
000074c3551d9ceb  sub rsp, 0x08
000074c3551d9cef  push rax
000074c3551d9cf0  push rcx
000074c3551d9cf1  push rdx
000074c3551d9cf2  push rdi
000074c3551d9cf3  push rsi
000074c3551d9cf4  push r8
000074c3551d9cf6  push r9
000074c3551d9cf8  push r10
000074c3551d9cfa  push r11
000074c3551d9cfc  sub rsp, 0xF0
000074c3551d9d03  vmovaps [rsp], xmm0
000074c3551d9d08  vmovaps [rsp+0x10], xmm1
000074c3551d9d0e  vmovaps [rsp+0x20], xmm2
000074c3551d9d14  vmovaps [rsp+0x30], xmm3
000074c3551d9d1a  vmovaps [rsp+0x40], xmm4
000074c3551d9d20  vmovaps [rsp+0x50], xmm5
000074c3551d9d26  vmovaps [rsp+0x60], xmm6
000074c3551d9d2c  vmovaps [rsp+0x70], xmm7
000074c3551d9d32  vmovaps [rsp+0x80], xmm8
000074c3551d9d3b  vmovaps [rsp+0x90], xmm9
000074c3551d9d44  vmovaps [rsp+0xA0], xmm11
000074c3551d9d4d  vmovaps [rsp+0xB0], xmm12
000074c3551d9d56  vmovaps [rsp+0xC0], xmm13
000074c3551d9d5f  vmovaps [rsp+0xD0], xmm14
000074c3551d9d68  vmovaps [rsp+0xE0], xmm15
000074c3551d9d71  sub rsp, 0x30
000074c3551d9d75  movaps [rsp], xmm10
000074c3551d9d7a  movaps [rsp+0x10], xmm14
000074c3551d9d80  movaps [rsp+0x20], xmm4
000074c3551d9d85  lea rdi, [rsp]
000074c3551d9d89  mov esi, 0x00
000074c3551d9d8e  mov rax, 0x5F9407FA9530
000074c3551d9d98  call rax
000074c3551d9d9a  movaps xmm10, [rsp]
000074c3551d9d9f  add rsp, 0x30
000074c3551d9da3  vmovaps xmm0, [rsp]
000074c3551d9da8  vmovaps xmm1, [rsp+0x10]
000074c3551d9dae  vmovaps xmm2, [rsp+0x20]
000074c3551d9db4  vmovaps xmm3, [rsp+0x30]
000074c3551d9dba  vmovaps xmm4, [rsp+0x40]
000074c3551d9dc0  vmovaps xmm5, [rsp+0x50]
000074c3551d9dc6  vmovaps xmm6, [rsp+0x60]
000074c3551d9dcc  vmovaps xmm7, [rsp+0x70]
000074c3551d9dd2  vmovaps xmm8, [rsp+0x80]
000074c3551d9ddb  vmovaps xmm9, [rsp+0x90]
000074c3551d9de4  vmovaps xmm11, [rsp+0xA0]
000074c3551d9ded  vmovaps xmm12, [rsp+0xB0]
000074c3551d9df6  vmovaps xmm13, [rsp+0xC0]
000074c3551d9dff  vmovaps xmm14, [rsp+0xD0]
000074c3551d9e08  vmovaps xmm15, [rsp+0xE0]
000074c3551d9e11  add rsp, 0xF0
000074c3551d9e18  pop r11
000074c3551d9e1a  pop r10
000074c3551d9e1c  pop r9
000074c3551d9e1e  pop r8
000074c3551d9e20  pop rsi
000074c3551d9e21  pop rdi
000074c3551d9e22  pop rdx
000074c3551d9e23  pop rcx
000074c3551d9e24  pop rax
000074c3551d9e25  add rsp, 0x08
000074c3551d9e29  jmp 0x000074C3551D6388
000074c3551d9e2e  sub rsp, 0x08
000074c3551d9e32  push rax
000074c3551d9e33  push rcx
000074c3551d9e34  push rdx
000074c3551d9e35  push rdi
000074c3551d9e36  push rsi
000074c3551d9e37  push r8
000074c3551d9e39  push r9
000074c3551d9e3b  push r10
000074c3551d9e3d  push r11
000074c3551d9e3f  sub rsp, 0xF0
000074c3551d9e46  vmovaps [rsp], xmm0
000074c3551d9e4b  vmovaps [rsp+0x10], xmm1
000074c3551d9e51  vmovaps [rsp+0x20], xmm2
000074c3551d9e57  vmovaps [rsp+0x30], xmm3
000074c3551d9e5d  vmovaps [rsp+0x40], xmm4
000074c3551d9e63  vmovaps [rsp+0x50], xmm5
000074c3551d9e69  vmovaps [rsp+0x60], xmm6
000074c3551d9e6f  vmovaps [rsp+0x70], xmm7
000074c3551d9e75  vmovaps [rsp+0x80], xmm9
000074c3551d9e7e  vmovaps [rsp+0x90], xmm10
000074c3551d9e87  vmovaps [rsp+0xA0], xmm11
000074c3551d9e90  vmovaps [rsp+0xB0], xmm12
000074c3551d9e99  vmovaps [rsp+0xC0], xmm13
000074c3551d9ea2  vmovaps [rsp+0xD0], xmm14
000074c3551d9eab  vmovaps [rsp+0xE0], xmm15
000074c3551d9eb4  sub rsp, 0x30
000074c3551d9eb8  movaps [rsp], xmm8
000074c3551d9ebd  movaps [rsp+0x10], xmm1
000074c3551d9ec2  movaps [rsp+0x20], xmm14
000074c3551d9ec8  lea rdi, [rsp]
000074c3551d9ecc  mov esi, 0x00
000074c3551d9ed1  mov rax, 0x5F9407FA9530
000074c3551d9edb  call rax
000074c3551d9edd  movaps xmm8, [rsp]
000074c3551d9ee2  add rsp, 0x30
000074c3551d9ee6  vmovaps xmm0, [rsp]
000074c3551d9eeb  vmovaps xmm1, [rsp+0x10]
000074c3551d9ef1  vmovaps xmm2, [rsp+0x20]
000074c3551d9ef7  vmovaps xmm3, [rsp+0x30]
000074c3551d9efd  vmovaps xmm4, [rsp+0x40]
000074c3551d9f03  vmovaps xmm5, [rsp+0x50]
000074c3551d9f09  vmovaps xmm6, [rsp+0x60]
000074c3551d9f0f  vmovaps xmm7, [rsp+0x70]
000074c3551d9f15  vmovaps xmm9, [rsp+0x80]
000074c3551d9f1e  vmovaps xmm10, [rsp+0x90]
000074c3551d9f27  vmovaps xmm11, [rsp+0xA0]
000074c3551d9f30  vmovaps xmm12, [rsp+0xB0]
000074c3551d9f39  vmovaps xmm13, [rsp+0xC0]
000074c3551d9f42  vmovaps xmm14, [rsp+0xD0]
000074c3551d9f4b  vmovaps xmm15, [rsp+0xE0]
000074c3551d9f54  add rsp, 0xF0
000074c3551d9f5b  pop r11
000074c3551d9f5d  pop r10
000074c3551d9f5f  pop r9
000074c3551d9f61  pop r8
000074c3551d9f63  pop rsi
000074c3551d9f64  pop rdi
000074c3551d9f65  pop rdx
000074c3551d9f66  pop rcx
000074c3551d9f67  pop rax
000074c3551d9f68  add rsp, 0x08
000074c3551d9f6c  jmp 0x000074C3551D63AE
000074c3551d9f71  sub rsp, 0x08
000074c3551d9f75  push rax
000074c3551d9f76  push rcx
000074c3551d9f77  push rdx
000074c3551d9f78  push rdi
000074c3551d9f79  push rsi
000074c3551d9f7a  push r8
000074c3551d9f7c  push r9
000074c3551d9f7e  push r10
000074c3551d9f80  push r11
000074c3551d9f82  sub rsp, 0xF0
000074c3551d9f89  vmovaps [rsp], xmm0
000074c3551d9f8e  vmovaps [rsp+0x10], xmm1
000074c3551d9f94  vmovaps [rsp+0x20], xmm2
000074c3551d9f9a  vmovaps [rsp+0x30], xmm3
000074c3551d9fa0  vmovaps [rsp+0x40], xmm4
000074c3551d9fa6  vmovaps [rsp+0x50], xmm5
000074c3551d9fac  vmovaps [rsp+0x60], xmm7
000074c3551d9fb2  vmovaps [rsp+0x70], xmm8
000074c3551d9fb8  vmovaps [rsp+0x80], xmm9
000074c3551d9fc1  vmovaps [rsp+0x90], xmm10
000074c3551d9fca  vmovaps [rsp+0xA0], xmm11
000074c3551d9fd3  vmovaps [rsp+0xB0], xmm12
000074c3551d9fdc  vmovaps [rsp+0xC0], xmm13
000074c3551d9fe5  vmovaps [rsp+0xD0], xmm14
000074c3551d9fee  vmovaps [rsp+0xE0], xmm15
000074c3551d9ff7  sub rsp, 0x30
000074c3551d9ffb  movaps [rsp], xmm6
000074c3551d9fff  movaps [rsp+0x10], xmm1
000074c3551da004  movaps [rsp+0x20], xmm14
000074c3551da00a  lea rdi, [rsp]
000074c3551da00e  mov esi, 0x00
000074c3551da013  mov rax, 0x5F9407FA9530
000074c3551da01d  call rax
000074c3551da01f  movaps xmm6, [rsp]
000074c3551da023  add rsp, 0x30
000074c3551da027  vmovaps xmm0, [rsp]
000074c3551da02c  vmovaps xmm1, [rsp+0x10]
000074c3551da032  vmovaps xmm2, [rsp+0x20]
000074c3551da038  vmovaps xmm3, [rsp+0x30]
000074c3551da03e  vmovaps xmm4, [rsp+0x40]
000074c3551da044  vmovaps xmm5, [rsp+0x50]
000074c3551da04a  vmovaps xmm7, [rsp+0x60]
000074c3551da050  vmovaps xmm8, [rsp+0x70]
000074c3551da056  vmovaps xmm9, [rsp+0x80]
000074c3551da05f  vmovaps xmm10, [rsp+0x90]
000074c3551da068  vmovaps xmm11, [rsp+0xA0]
000074c3551da071  vmovaps xmm12, [rsp+0xB0]
000074c3551da07a  vmovaps xmm13, [rsp+0xC0]
000074c3551da083  vmovaps xmm14, [rsp+0xD0]
000074c3551da08c  vmovaps xmm15, [rsp+0xE0]
000074c3551da095  add rsp, 0xF0
000074c3551da09c  pop r11
000074c3551da09e  pop r10
000074c3551da0a0  pop r9
000074c3551da0a2  pop r8
000074c3551da0a4  pop rsi
000074c3551da0a5  pop rdi
000074c3551da0a6  pop rdx
000074c3551da0a7  pop rcx
000074c3551da0a8  pop rax
000074c3551da0a9  add rsp, 0x08
000074c3551da0ad  jmp 0x000074C3551D63DA
000074c3551da0b2  sub rsp, 0x08
000074c3551da0b6  push rax
000074c3551da0b7  push rcx
000074c3551da0b8  push rdx
000074c3551da0b9  push rdi
000074c3551da0ba  push rsi
000074c3551da0bb  push r8
000074c3551da0bd  push r9
000074c3551da0bf  push r10
000074c3551da0c1  push r11
000074c3551da0c3  sub rsp, 0xF0
000074c3551da0ca  vmovaps [rsp], xmm0
000074c3551da0cf  vmovaps [rsp+0x10], xmm1
000074c3551da0d5  vmovaps [rsp+0x20], xmm2
000074c3551da0db  vmovaps [rsp+0x30], xmm3
000074c3551da0e1  vmovaps [rsp+0x40], xmm4
000074c3551da0e7  vmovaps [rsp+0x50], xmm5
000074c3551da0ed  vmovaps [rsp+0x60], xmm6
000074c3551da0f3  vmovaps [rsp+0x70], xmm7
000074c3551da0f9  vmovaps [rsp+0x80], xmm8
000074c3551da102  vmovaps [rsp+0x90], xmm9
000074c3551da10b  vmovaps [rsp+0xA0], xmm10
000074c3551da114  vmovaps [rsp+0xB0], xmm11
000074c3551da11d  vmovaps [rsp+0xC0], xmm12
000074c3551da126  vmovaps [rsp+0xD0], xmm13
000074c3551da12f  vmovaps [rsp+0xE0], xmm15
000074c3551da138  sub rsp, 0x30
000074c3551da13c  movaps [rsp], xmm14
000074c3551da141  movaps [rsp+0x10], xmm12
000074c3551da147  movaps [rsp+0x20], xmm1
000074c3551da14c  lea rdi, [rsp]
000074c3551da150  mov esi, 0x00
000074c3551da155  mov rax, 0x5F9407FA9530
000074c3551da15f  call rax
000074c3551da161  movaps xmm14, [rsp]
000074c3551da166  add rsp, 0x30
000074c3551da16a  vmovaps xmm0, [rsp]
000074c3551da16f  vmovaps xmm1, [rsp+0x10]
000074c3551da175  vmovaps xmm2, [rsp+0x20]
000074c3551da17b  vmovaps xmm3, [rsp+0x30]
000074c3551da181  vmovaps xmm4, [rsp+0x40]
000074c3551da187  vmovaps xmm5, [rsp+0x50]
000074c3551da18d  vmovaps xmm6, [rsp+0x60]
000074c3551da193  vmovaps xmm7, [rsp+0x70]
000074c3551da199  vmovaps xmm8, [rsp+0x80]
000074c3551da1a2  vmovaps xmm9, [rsp+0x90]
000074c3551da1ab  vmovaps xmm10, [rsp+0xA0]
000074c3551da1b4  vmovaps xmm11, [rsp+0xB0]
000074c3551da1bd  vmovaps xmm12, [rsp+0xC0]
000074c3551da1c6  vmovaps xmm13, [rsp+0xD0]
000074c3551da1cf  vmovaps xmm15, [rsp+0xE0]
000074c3551da1d8  add rsp, 0xF0
000074c3551da1df  pop r11
000074c3551da1e1  pop r10
000074c3551da1e3  pop r9
000074c3551da1e5  pop r8
000074c3551da1e7  pop rsi
000074c3551da1e8  pop rdi
000074c3551da1e9  pop rdx
000074c3551da1ea  pop rcx
000074c3551da1eb  pop rax
000074c3551da1ec  add rsp, 0x08
000074c3551da1f0  jmp 0x000074C3551D6400
000074c3551da1f5  sub rsp, 0x08
000074c3551da1f9  push rax
000074c3551da1fa  push rcx
000074c3551da1fb  push rdx
000074c3551da1fc  push rdi
000074c3551da1fd  push rsi
000074c3551da1fe  push r8
000074c3551da200  push r9
000074c3551da202  push r10
000074c3551da204  push r11
000074c3551da206  sub rsp, 0xF0
000074c3551da20d  vmovaps [rsp], xmm0
000074c3551da212  vmovaps [rsp+0x10], xmm2
000074c3551da218  vmovaps [rsp+0x20], xmm3
000074c3551da21e  vmovaps [rsp+0x30], xmm4
000074c3551da224  vmovaps [rsp+0x40], xmm5
000074c3551da22a  vmovaps [rsp+0x50], xmm6
000074c3551da230  vmovaps [rsp+0x60], xmm7
000074c3551da236  vmovaps [rsp+0x70], xmm8
000074c3551da23c  vmovaps [rsp+0x80], xmm9
000074c3551da245  vmovaps [rsp+0x90], xmm10
000074c3551da24e  vmovaps [rsp+0xA0], xmm11
000074c3551da257  vmovaps [rsp+0xB0], xmm12
000074c3551da260  vmovaps [rsp+0xC0], xmm13
000074c3551da269  vmovaps [rsp+0xD0], xmm14
000074c3551da272  vmovaps [rsp+0xE0], xmm15
000074c3551da27b  sub rsp, 0x30
000074c3551da27f  movaps [rsp], xmm1
000074c3551da283  movaps [rsp+0x10], xmm13
000074c3551da289  movaps [rsp+0x20], xmm9
000074c3551da28f  lea rdi, [rsp]
000074c3551da293  mov esi, 0x00
000074c3551da298  mov rax, 0x5F9407FA9530
000074c3551da2a2  call rax
000074c3551da2a4  movaps xmm1, [rsp]
000074c3551da2a8  add rsp, 0x30
000074c3551da2ac  vmovaps xmm0, [rsp]
000074c3551da2b1  vmovaps xmm2, [rsp+0x10]
000074c3551da2b7  vmovaps xmm3, [rsp+0x20]
000074c3551da2bd  vmovaps xmm4, [rsp+0x30]
000074c3551da2c3  vmovaps xmm5, [rsp+0x40]
000074c3551da2c9  vmovaps xmm6, [rsp+0x50]
000074c3551da2cf  vmovaps xmm7, [rsp+0x60]
000074c3551da2d5  vmovaps xmm8, [rsp+0x70]
000074c3551da2db  vmovaps xmm9, [rsp+0x80]
000074c3551da2e4  vmovaps xmm10, [rsp+0x90]
000074c3551da2ed  vmovaps xmm11, [rsp+0xA0]
000074c3551da2f6  vmovaps xmm12, [rsp+0xB0]
000074c3551da2ff  vmovaps xmm13, [rsp+0xC0]
000074c3551da308  vmovaps xmm14, [rsp+0xD0]
000074c3551da311  vmovaps xmm15, [rsp+0xE0]
000074c3551da31a  add rsp, 0xF0
000074c3551da321  pop r11
000074c3551da323  pop r10
000074c3551da325  pop r9
000074c3551da327  pop r8
000074c3551da329  pop rsi
000074c3551da32a  pop rdi
000074c3551da32b  pop rdx
000074c3551da32c  pop rcx
000074c3551da32d  pop rax
000074c3551da32e  add rsp, 0x08
000074c3551da332  jmp 0x000074C3551D641A
000074c3551da337  sub rsp, 0x08
000074c3551da33b  push rax
000074c3551da33c  push rcx
000074c3551da33d  push rdx
000074c3551da33e  push rdi
000074c3551da33f  push rsi
000074c3551da340  push r8
000074c3551da342  push r9
000074c3551da344  push r10
000074c3551da346  push r11
000074c3551da348  sub rsp, 0xF0
000074c3551da34f  vmovaps [rsp], xmm0
000074c3551da354  vmovaps [rsp+0x10], xmm1
000074c3551da35a  vmovaps [rsp+0x20], xmm2
000074c3551da360  vmovaps [rsp+0x30], xmm3
000074c3551da366  vmovaps [rsp+0x40], xmm4
000074c3551da36c  vmovaps [rsp+0x50], xmm5
000074c3551da372  vmovaps [rsp+0x60], xmm6
000074c3551da378  vmovaps [rsp+0x70], xmm7
000074c3551da37e  vmovaps [rsp+0x80], xmm8
000074c3551da387  vmovaps [rsp+0x90], xmm9
000074c3551da390  vmovaps [rsp+0xA0], xmm10
000074c3551da399  vmovaps [rsp+0xB0], xmm11
000074c3551da3a2  vmovaps [rsp+0xC0], xmm13
000074c3551da3ab  vmovaps [rsp+0xD0], xmm14
000074c3551da3b4  vmovaps [rsp+0xE0], xmm15
000074c3551da3bd  sub rsp, 0x30
000074c3551da3c1  movaps [rsp], xmm12
000074c3551da3c6  movaps [rsp+0x10], xmm7
000074c3551da3cb  movaps [rsp+0x20], xmm13
000074c3551da3d1  lea rdi, [rsp]
000074c3551da3d5  mov esi, 0x00
000074c3551da3da  mov rax, 0x5F9407FA9530
000074c3551da3e4  call rax
000074c3551da3e6  movaps xmm12, [rsp]
000074c3551da3eb  add rsp, 0x30
000074c3551da3ef  vmovaps xmm0, [rsp]
000074c3551da3f4  vmovaps xmm1, [rsp+0x10]
000074c3551da3fa  vmovaps xmm2, [rsp+0x20]
000074c3551da400  vmovaps xmm3, [rsp+0x30]
000074c3551da406  vmovaps xmm4, [rsp+0x40]
000074c3551da40c  vmovaps xmm5, [rsp+0x50]
000074c3551da412  vmovaps xmm6, [rsp+0x60]
000074c3551da418  vmovaps xmm7, [rsp+0x70]
000074c3551da41e  vmovaps xmm8, [rsp+0x80]
000074c3551da427  vmovaps xmm9, [rsp+0x90]
000074c3551da430  vmovaps xmm10, [rsp+0xA0]
000074c3551da439  vmovaps xmm11, [rsp+0xB0]
000074c3551da442  vmovaps xmm13, [rsp+0xC0]
000074c3551da44b  vmovaps xmm14, [rsp+0xD0]
000074c3551da454  vmovaps xmm15, [rsp+0xE0]
000074c3551da45d  add rsp, 0xF0
000074c3551da464  pop r11
000074c3551da466  pop r10
000074c3551da468  pop r9
000074c3551da46a  pop r8
000074c3551da46c  pop rsi
000074c3551da46d  pop rdi
000074c3551da46e  pop rdx
000074c3551da46f  pop rcx
000074c3551da470  pop rax
000074c3551da471  add rsp, 0x08
000074c3551da475  jmp 0x000074C3551D6441
000074c3551da47a  sub rsp, 0x08
000074c3551da47e  push rax
000074c3551da47f  push rcx
000074c3551da480  push rdx
000074c3551da481  push rdi
000074c3551da482  push rsi
000074c3551da483  push r8
000074c3551da485  push r9
000074c3551da487  push r10
000074c3551da489  push r11
000074c3551da48b  sub rsp, 0xF0
000074c3551da492  vmovaps [rsp], xmm0
000074c3551da497  vmovaps [rsp+0x10], xmm1
000074c3551da49d  vmovaps [rsp+0x20], xmm2
000074c3551da4a3  vmovaps [rsp+0x30], xmm3
000074c3551da4a9  vmovaps [rsp+0x40], xmm4
000074c3551da4af  vmovaps [rsp+0x50], xmm5
000074c3551da4b5  vmovaps [rsp+0x60], xmm6
000074c3551da4bb  vmovaps [rsp+0x70], xmm7
000074c3551da4c1  vmovaps [rsp+0x80], xmm8
000074c3551da4ca  vmovaps [rsp+0x90], xmm9
000074c3551da4d3  vmovaps [rsp+0xA0], xmm10
000074c3551da4dc  vmovaps [rsp+0xB0], xmm11
000074c3551da4e5  vmovaps [rsp+0xC0], xmm12
000074c3551da4ee  vmovaps [rsp+0xD0], xmm14
000074c3551da4f7  vmovaps [rsp+0xE0], xmm15
000074c3551da500  sub rsp, 0x30
000074c3551da504  movaps [rsp], xmm13
000074c3551da509  movaps [rsp+0x10], xmm15
000074c3551da50f  movaps [rsp+0x20], xmm8
000074c3551da515  lea rdi, [rsp]
000074c3551da519  mov esi, 0x00
000074c3551da51e  mov rax, 0x5F9407FA9530
000074c3551da528  call rax
000074c3551da52a  movaps xmm13, [rsp]
000074c3551da52f  add rsp, 0x30
000074c3551da533  vmovaps xmm0, [rsp]
000074c3551da538  vmovaps xmm1, [rsp+0x10]
000074c3551da53e  vmovaps xmm2, [rsp+0x20]
000074c3551da544  vmovaps xmm3, [rsp+0x30]
000074c3551da54a  vmovaps xmm4, [rsp+0x40]
000074c3551da550  vmovaps xmm5, [rsp+0x50]
000074c3551da556  vmovaps xmm6, [rsp+0x60]
000074c3551da55c  vmovaps xmm7, [rsp+0x70]
000074c3551da562  vmovaps xmm8, [rsp+0x80]
000074c3551da56b  vmovaps xmm9, [rsp+0x90]
000074c3551da574  vmovaps xmm10, [rsp+0xA0]
000074c3551da57d  vmovaps xmm11, [rsp+0xB0]
000074c3551da586  vmovaps xmm12, [rsp+0xC0]
000074c3551da58f  vmovaps xmm14, [rsp+0xD0]
000074c3551da598  vmovaps xmm15, [rsp+0xE0]
000074c3551da5a1  add rsp, 0xF0
000074c3551da5a8  pop r11
000074c3551da5aa  pop r10
000074c3551da5ac  pop r9
000074c3551da5ae  pop r8
000074c3551da5b0  pop rsi
000074c3551da5b1  pop rdi
000074c3551da5b2  pop rdx
000074c3551da5b3  pop rcx
000074c3551da5b4  pop rax
000074c3551da5b5  add rsp, 0x08
000074c3551da5b9  jmp 0x000074C3551D645C
000074c3551da5be  sub rsp, 0x08
000074c3551da5c2  push rax
000074c3551da5c3  push rcx
000074c3551da5c4  push rdx
000074c3551da5c5  push rdi
000074c3551da5c6  push rsi
000074c3551da5c7  push r8
000074c3551da5c9  push r9
000074c3551da5cb  push r10
000074c3551da5cd  push r11
000074c3551da5cf  sub rsp, 0xF0
000074c3551da5d6  vmovaps [rsp], xmm0
000074c3551da5db  vmovaps [rsp+0x10], xmm1
000074c3551da5e1  vmovaps [rsp+0x20], xmm2
000074c3551da5e7  vmovaps [rsp+0x30], xmm3
000074c3551da5ed  vmovaps [rsp+0x40], xmm4
000074c3551da5f3  vmovaps [rsp+0x50], xmm5
000074c3551da5f9  vmovaps [rsp+0x60], xmm6
000074c3551da5ff  vmovaps [rsp+0x70], xmm7
000074c3551da605  vmovaps [rsp+0x80], xmm9
000074c3551da60e  vmovaps [rsp+0x90], xmm10
000074c3551da617  vmovaps [rsp+0xA0], xmm11
000074c3551da620  vmovaps [rsp+0xB0], xmm12
000074c3551da629  vmovaps [rsp+0xC0], xmm13
000074c3551da632  vmovaps [rsp+0xD0], xmm14
000074c3551da63b  vmovaps [rsp+0xE0], xmm15
000074c3551da644  sub rsp, 0x30
000074c3551da648  movaps [rsp], xmm8
000074c3551da64d  movaps [rsp+0x10], xmm15
000074c3551da653  movaps [rsp+0x20], xmm9
000074c3551da659  lea rdi, [rsp]
000074c3551da65d  mov esi, 0x00
000074c3551da662  mov rax, 0x5F9407FA9530
000074c3551da66c  call rax
000074c3551da66e  movaps xmm8, [rsp]
000074c3551da673  add rsp, 0x30
000074c3551da677  vmovaps xmm0, [rsp]
000074c3551da67c  vmovaps xmm1, [rsp+0x10]
000074c3551da682  vmovaps xmm2, [rsp+0x20]
000074c3551da688  vmovaps xmm3, [rsp+0x30]
000074c3551da68e  vmovaps xmm4, [rsp+0x40]
000074c3551da694  vmovaps xmm5, [rsp+0x50]
000074c3551da69a  vmovaps xmm6, [rsp+0x60]
000074c3551da6a0  vmovaps xmm7, [rsp+0x70]
000074c3551da6a6  vmovaps xmm9, [rsp+0x80]
000074c3551da6af  vmovaps xmm10, [rsp+0x90]
000074c3551da6b8  vmovaps xmm11, [rsp+0xA0]
000074c3551da6c1  vmovaps xmm12, [rsp+0xB0]
000074c3551da6ca  vmovaps xmm13, [rsp+0xC0]
000074c3551da6d3  vmovaps xmm14, [rsp+0xD0]
000074c3551da6dc  vmovaps xmm15, [rsp+0xE0]
000074c3551da6e5  add rsp, 0xF0
000074c3551da6ec  pop r11
000074c3551da6ee  pop r10
000074c3551da6f0  pop r9
000074c3551da6f2  pop r8
000074c3551da6f4  pop rsi
000074c3551da6f5  pop rdi
000074c3551da6f6  pop rdx
000074c3551da6f7  pop rcx
000074c3551da6f8  pop rax
000074c3551da6f9  add rsp, 0x08
000074c3551da6fd  jmp 0x000074C3551D648A
000074c3551da702  sub rsp, 0x08
000074c3551da706  push rax
000074c3551da707  push rcx
000074c3551da708  push rdx
000074c3551da709  push rdi
000074c3551da70a  push rsi
000074c3551da70b  push r8
000074c3551da70d  push r9
000074c3551da70f  push r10
000074c3551da711  push r11
000074c3551da713  sub rsp, 0xF0
000074c3551da71a  vmovaps [rsp], xmm0
000074c3551da71f  vmovaps [rsp+0x10], xmm1
000074c3551da725  vmovaps [rsp+0x20], xmm2
000074c3551da72b  vmovaps [rsp+0x30], xmm3
000074c3551da731  vmovaps [rsp+0x40], xmm4
000074c3551da737  vmovaps [rsp+0x50], xmm5
000074c3551da73d  vmovaps [rsp+0x60], xmm6
000074c3551da743  vmovaps [rsp+0x70], xmm7
000074c3551da749  vmovaps [rsp+0x80], xmm8
000074c3551da752  vmovaps [rsp+0x90], xmm9
000074c3551da75b  vmovaps [rsp+0xA0], xmm10
000074c3551da764  vmovaps [rsp+0xB0], xmm11
000074c3551da76d  vmovaps [rsp+0xC0], xmm12
000074c3551da776  vmovaps [rsp+0xD0], xmm13
000074c3551da77f  vmovaps [rsp+0xE0], xmm14
000074c3551da788  sub rsp, 0x30
000074c3551da78c  movaps [rsp], xmm15
000074c3551da791  movaps [rsp+0x10], xmm11
000074c3551da797  movaps [rsp+0x20], xmm6
000074c3551da79c  lea rdi, [rsp]
000074c3551da7a0  mov esi, 0x00
000074c3551da7a5  mov rax, 0x5F9407FA9530
000074c3551da7af  call rax
000074c3551da7b1  movaps xmm15, [rsp]
000074c3551da7b6  add rsp, 0x30
000074c3551da7ba  vmovaps xmm0, [rsp]
000074c3551da7bf  vmovaps xmm1, [rsp+0x10]
000074c3551da7c5  vmovaps xmm2, [rsp+0x20]
000074c3551da7cb  vmovaps xmm3, [rsp+0x30]
000074c3551da7d1  vmovaps xmm4, [rsp+0x40]
000074c3551da7d7  vmovaps xmm5, [rsp+0x50]
000074c3551da7dd  vmovaps xmm6, [rsp+0x60]
000074c3551da7e3  vmovaps xmm7, [rsp+0x70]
000074c3551da7e9  vmovaps xmm8, [rsp+0x80]
000074c3551da7f2  vmovaps xmm9, [rsp+0x90]
000074c3551da7fb  vmovaps xmm10, [rsp+0xA0]
000074c3551da804  vmovaps xmm11, [rsp+0xB0]
000074c3551da80d  vmovaps xmm12, [rsp+0xC0]
000074c3551da816  vmovaps xmm13, [rsp+0xD0]
000074c3551da81f  vmovaps xmm14, [rsp+0xE0]
000074c3551da828  add rsp, 0xF0
000074c3551da82f  pop r11
000074c3551da831  pop r10
000074c3551da833  pop r9
000074c3551da835  pop r8
000074c3551da837  pop rsi
000074c3551da838  pop rdi
000074c3551da839  pop rdx
000074c3551da83a  pop rcx
000074c3551da83b  pop rax
000074c3551da83c  add rsp, 0x08
000074c3551da840  jmp 0x000074C3551D64A5
000074c3551da845  sub rsp, 0x08
000074c3551da849  push rax
000074c3551da84a  push rcx
000074c3551da84b  push rdx
000074c3551da84c  push rdi
000074c3551da84d  push rsi
000074c3551da84e  push r8
000074c3551da850  push r9
000074c3551da852  push r10
000074c3551da854  push r11
000074c3551da856  sub rsp, 0xF0
000074c3551da85d  vmovaps [rsp], xmm0
000074c3551da862  vmovaps [rsp+0x10], xmm1
000074c3551da868  vmovaps [rsp+0x20], xmm2
000074c3551da86e  vmovaps [rsp+0x30], xmm3
000074c3551da874  vmovaps [rsp+0x40], xmm4
000074c3551da87a  vmovaps [rsp+0x50], xmm5
000074c3551da880  vmovaps [rsp+0x60], xmm6
000074c3551da886  vmovaps [rsp+0x70], xmm8
000074c3551da88c  vmovaps [rsp+0x80], xmm9
000074c3551da895  vmovaps [rsp+0x90], xmm10
000074c3551da89e  vmovaps [rsp+0xA0], xmm11
000074c3551da8a7  vmovaps [rsp+0xB0], xmm12
000074c3551da8b0  vmovaps [rsp+0xC0], xmm13
000074c3551da8b9  vmovaps [rsp+0xD0], xmm14
000074c3551da8c2  vmovaps [rsp+0xE0], xmm15
000074c3551da8cb  sub rsp, 0x30
000074c3551da8cf  movaps [rsp], xmm7
000074c3551da8d3  movaps [rsp+0x10], xmm11
000074c3551da8d9  movaps [rsp+0x20], xmm9
000074c3551da8df  lea rdi, [rsp]
000074c3551da8e3  mov esi, 0x00
000074c3551da8e8  mov rax, 0x5F9407FA9530
000074c3551da8f2  call rax
000074c3551da8f4  movaps xmm7, [rsp]
000074c3551da8f8  add rsp, 0x30
000074c3551da8fc  vmovaps xmm0, [rsp]
000074c3551da901  vmovaps xmm1, [rsp+0x10]
000074c3551da907  vmovaps xmm2, [rsp+0x20]
000074c3551da90d  vmovaps xmm3, [rsp+0x30]
000074c3551da913  vmovaps xmm4, [rsp+0x40]
000074c3551da919  vmovaps xmm5, [rsp+0x50]
000074c3551da91f  vmovaps xmm6, [rsp+0x60]
000074c3551da925  vmovaps xmm8, [rsp+0x70]
000074c3551da92b  vmovaps xmm9, [rsp+0x80]
000074c3551da934  vmovaps xmm10, [rsp+0x90]
000074c3551da93d  vmovaps xmm11, [rsp+0xA0]
000074c3551da946  vmovaps xmm12, [rsp+0xB0]
000074c3551da94f  vmovaps xmm13, [rsp+0xC0]
000074c3551da958  vmovaps xmm14, [rsp+0xD0]
000074c3551da961  vmovaps xmm15, [rsp+0xE0]
000074c3551da96a  add rsp, 0xF0
000074c3551da971  pop r11
000074c3551da973  pop r10
000074c3551da975  pop r9
000074c3551da977  pop r8
000074c3551da979  pop rsi
000074c3551da97a  pop rdi
000074c3551da97b  pop rdx
000074c3551da97c  pop rcx
000074c3551da97d  pop rax
000074c3551da97e  add rsp, 0x08
000074c3551da982  jmp 0x000074C3551D64D2
000074c3551da987  sub rsp, 0x08
000074c3551da98b  push rax
000074c3551da98c  push rcx
000074c3551da98d  push rdx
000074c3551da98e  push rdi
000074c3551da98f  push rsi
000074c3551da990  push r8
000074c3551da992  push r9
000074c3551da994  push r10
000074c3551da996  push r11
000074c3551da998  sub rsp, 0xF0
000074c3551da99f  vmovaps [rsp], xmm0
000074c3551da9a4  vmovaps [rsp+0x10], xmm1
000074c3551da9aa  vmovaps [rsp+0x20], xmm2
000074c3551da9b0  vmovaps [rsp+0x30], xmm3
000074c3551da9b6  vmovaps [rsp+0x40], xmm4
000074c3551da9bc  vmovaps [rsp+0x50], xmm5
000074c3551da9c2  vmovaps [rsp+0x60], xmm6
000074c3551da9c8  vmovaps [rsp+0x70], xmm7
000074c3551da9ce  vmovaps [rsp+0x80], xmm8
000074c3551da9d7  vmovaps [rsp+0x90], xmm9
000074c3551da9e0  vmovaps [rsp+0xA0], xmm10
000074c3551da9e9  vmovaps [rsp+0xB0], xmm12
000074c3551da9f2  vmovaps [rsp+0xC0], xmm13
000074c3551da9fb  vmovaps [rsp+0xD0], xmm14
000074c3551daa04  vmovaps [rsp+0xE0], xmm15
000074c3551daa0d  sub rsp, 0x30
000074c3551daa11  movaps [rsp], xmm11
000074c3551daa16  movaps [rsp+0x10], xmm10
000074c3551daa1c  movaps [rsp+0x20], xmm14
000074c3551daa22  lea rdi, [rsp]
000074c3551daa26  mov esi, 0x00
000074c3551daa2b  mov rax, 0x5F9407FA9530
000074c3551daa35  call rax
000074c3551daa37  movaps xmm11, [rsp]
000074c3551daa3c  add rsp, 0x30
000074c3551daa40  vmovaps xmm0, [rsp]
000074c3551daa45  vmovaps xmm1, [rsp+0x10]
000074c3551daa4b  vmovaps xmm2, [rsp+0x20]
000074c3551daa51  vmovaps xmm3, [rsp+0x30]
000074c3551daa57  vmovaps xmm4, [rsp+0x40]
000074c3551daa5d  vmovaps xmm5, [rsp+0x50]
000074c3551daa63  vmovaps xmm6, [rsp+0x60]
000074c3551daa69  vmovaps xmm7, [rsp+0x70]
000074c3551daa6f  vmovaps xmm8, [rsp+0x80]
000074c3551daa78  vmovaps xmm9, [rsp+0x90]
000074c3551daa81  vmovaps xmm10, [rsp+0xA0]
000074c3551daa8a  vmovaps xmm12, [rsp+0xB0]
000074c3551daa93  vmovaps xmm13, [rsp+0xC0]
000074c3551daa9c  vmovaps xmm14, [rsp+0xD0]
000074c3551daaa5  vmovaps xmm15, [rsp+0xE0]
000074c3551daaae  add rsp, 0xF0
000074c3551daab5  pop r11
000074c3551daab7  pop r10
000074c3551daab9  pop r9
000074c3551daabb  pop r8
000074c3551daabd  pop rsi
000074c3551daabe  pop rdi
000074c3551daabf  pop rdx
000074c3551daac0  pop rcx
000074c3551daac1  pop rax
000074c3551daac2  add rsp, 0x08
000074c3551daac6  jmp 0x000074C3551D64ED
000074c3551daacb  call 0x000074C3550E45A0
000074c3551daad0  jmp 0x000074C3551D64F7
000074c3551daad5  sub rsp, 0x08
000074c3551daad9  push rax
000074c3551daada  push rcx
000074c3551daadb  push rdx
000074c3551daadc  push rdi
000074c3551daadd  push rsi
000074c3551daade  push r8
000074c3551daae0  push r9
000074c3551daae2  push r10
000074c3551daae4  push r11
000074c3551daae6  sub rsp, 0xF0
000074c3551daaed  vmovaps [rsp], xmm0
000074c3551daaf2  vmovaps [rsp+0x10], xmm1
000074c3551daaf8  vmovaps [rsp+0x20], xmm2
000074c3551daafe  vmovaps [rsp+0x30], xmm3
000074c3551dab04  vmovaps [rsp+0x40], xmm4
000074c3551dab0a  vmovaps [rsp+0x50], xmm5
000074c3551dab10  vmovaps [rsp+0x60], xmm6
000074c3551dab16  vmovaps [rsp+0x70], xmm7
000074c3551dab1c  vmovaps [rsp+0x80], xmm8
000074c3551dab25  vmovaps [rsp+0x90], xmm9
000074c3551dab2e  vmovaps [rsp+0xA0], xmm11
000074c3551dab37  vmovaps [rsp+0xB0], xmm12
000074c3551dab40  vmovaps [rsp+0xC0], xmm13
000074c3551dab49  vmovaps [rsp+0xD0], xmm14
000074c3551dab52  vmovaps [rsp+0xE0], xmm15
000074c3551dab5b  sub rsp, 0x30
000074c3551dab5f  movaps [rsp], xmm10
000074c3551dab64  movaps [rsp+0x10], xmm1
000074c3551dab69  movaps [rsp+0x20], xmm12
000074c3551dab6f  lea rdi, [rsp]
000074c3551dab73  mov esi, 0x00
000074c3551dab78  mov rax, 0x5F9407FA9530
000074c3551dab82  call rax
000074c3551dab84  movaps xmm10, [rsp]
000074c3551dab89  add rsp, 0x30
000074c3551dab8d  vmovaps xmm0, [rsp]
000074c3551dab92  vmovaps xmm1, [rsp+0x10]
000074c3551dab98  vmovaps xmm2, [rsp+0x20]
000074c3551dab9e  vmovaps xmm3, [rsp+0x30]
000074c3551daba4  vmovaps xmm4, [rsp+0x40]
000074c3551dabaa  vmovaps xmm5, [rsp+0x50]
000074c3551dabb0  vmovaps xmm6, [rsp+0x60]
000074c3551dabb6  vmovaps xmm7, [rsp+0x70]
000074c3551dabbc  vmovaps xmm8, [rsp+0x80]
000074c3551dabc5  vmovaps xmm9, [rsp+0x90]
000074c3551dabce  vmovaps xmm11, [rsp+0xA0]
000074c3551dabd7  vmovaps xmm12, [rsp+0xB0]
000074c3551dabe0  vmovaps xmm13, [rsp+0xC0]
000074c3551dabe9  vmovaps xmm14, [rsp+0xD0]
000074c3551dabf2  vmovaps xmm15, [rsp+0xE0]
000074c3551dabfb  add rsp, 0xF0
000074c3551dac02  pop r11
000074c3551dac04  pop r10
000074c3551dac06  pop r9
000074c3551dac08  pop r8
000074c3551dac0a  pop rsi
000074c3551dac0b  pop rdi
000074c3551dac0c  pop rdx
000074c3551dac0d  pop rcx
000074c3551dac0e  pop rax
000074c3551dac0f  add rsp, 0x08
000074c3551dac13  jmp 0x000074C3551D651A
000074c3551dac18  sub rsp, 0x08
000074c3551dac1c  push rax
000074c3551dac1d  push rcx
000074c3551dac1e  push rdx
000074c3551dac1f  push rdi
000074c3551dac20  push rsi
000074c3551dac21  push r8
000074c3551dac23  push r9
000074c3551dac25  push r10
000074c3551dac27  push r11
000074c3551dac29  sub rsp, 0xF0
000074c3551dac30  vmovaps [rsp], xmm0
000074c3551dac35  vmovaps [rsp+0x10], xmm1
000074c3551dac3b  vmovaps [rsp+0x20], xmm2
000074c3551dac41  vmovaps [rsp+0x30], xmm3
000074c3551dac47  vmovaps [rsp+0x40], xmm4
000074c3551dac4d  vmovaps [rsp+0x50], xmm5
000074c3551dac53  vmovaps [rsp+0x60], xmm6
000074c3551dac59  vmovaps [rsp+0x70], xmm7
000074c3551dac5f  vmovaps [rsp+0x80], xmm8
000074c3551dac68  vmovaps [rsp+0x90], xmm9
000074c3551dac71  vmovaps [rsp+0xA0], xmm10
000074c3551dac7a  vmovaps [rsp+0xB0], xmm11
000074c3551dac83  vmovaps [rsp+0xC0], xmm13
000074c3551dac8c  vmovaps [rsp+0xD0], xmm14
000074c3551dac95  vmovaps [rsp+0xE0], xmm15
000074c3551dac9e  sub rsp, 0x30
000074c3551daca2  movaps [rsp], xmm12
000074c3551daca7  movaps [rsp+0x10], xmm14
000074c3551dacad  movaps [rsp+0x20], xmm1
000074c3551dacb2  lea rdi, [rsp]
000074c3551dacb6  mov esi, 0x00
000074c3551dacbb  mov rax, 0x5F9407FA9530
000074c3551dacc5  call rax
000074c3551dacc7  movaps xmm12, [rsp]
000074c3551daccc  add rsp, 0x30
000074c3551dacd0  vmovaps xmm0, [rsp]
000074c3551dacd5  vmovaps xmm1, [rsp+0x10]
000074c3551dacdb  vmovaps xmm2, [rsp+0x20]
000074c3551dace1  vmovaps xmm3, [rsp+0x30]
000074c3551dace7  vmovaps xmm4, [rsp+0x40]
000074c3551daced  vmovaps xmm5, [rsp+0x50]
000074c3551dacf3  vmovaps xmm6, [rsp+0x60]
000074c3551dacf9  vmovaps xmm7, [rsp+0x70]
000074c3551dacff  vmovaps xmm8, [rsp+0x80]
000074c3551dad08  vmovaps xmm9, [rsp+0x90]
000074c3551dad11  vmovaps xmm10, [rsp+0xA0]
000074c3551dad1a  vmovaps xmm11, [rsp+0xB0]
000074c3551dad23  vmovaps xmm13, [rsp+0xC0]
000074c3551dad2c  vmovaps xmm14, [rsp+0xD0]
000074c3551dad35  vmovaps xmm15, [rsp+0xE0]
000074c3551dad3e  add rsp, 0xF0
000074c3551dad45  pop r11
000074c3551dad47  pop r10
000074c3551dad49  pop r9
000074c3551dad4b  pop r8
000074c3551dad4d  pop rsi
000074c3551dad4e  pop rdi
000074c3551dad4f  pop rdx
000074c3551dad50  pop rcx
000074c3551dad51  pop rax
000074c3551dad52  add rsp, 0x08
000074c3551dad56  jmp 0x000074C3551D6549
000074c3551dad5b  sub rsp, 0x08
000074c3551dad5f  push rax
000074c3551dad60  push rcx
000074c3551dad61  push rdx
000074c3551dad62  push rdi
000074c3551dad63  push rsi
000074c3551dad64  push r8
000074c3551dad66  push r9
000074c3551dad68  push r10
000074c3551dad6a  push r11
000074c3551dad6c  sub rsp, 0xF0
000074c3551dad73  vmovaps [rsp], xmm0
000074c3551dad78  vmovaps [rsp+0x10], xmm1
000074c3551dad7e  vmovaps [rsp+0x20], xmm2
000074c3551dad84  vmovaps [rsp+0x30], xmm3
000074c3551dad8a  vmovaps [rsp+0x40], xmm4
000074c3551dad90  vmovaps [rsp+0x50], xmm5
000074c3551dad96  vmovaps [rsp+0x60], xmm6
000074c3551dad9c  vmovaps [rsp+0x70], xmm7
000074c3551dada2  vmovaps [rsp+0x80], xmm8
000074c3551dadab  vmovaps [rsp+0x90], xmm9
000074c3551dadb4  vmovaps [rsp+0xA0], xmm10
000074c3551dadbd  vmovaps [rsp+0xB0], xmm11
000074c3551dadc6  vmovaps [rsp+0xC0], xmm12
000074c3551dadcf  vmovaps [rsp+0xD0], xmm13
000074c3551dadd8  vmovaps [rsp+0xE0], xmm15
000074c3551dade1  sub rsp, 0x30
000074c3551dade5  movaps [rsp], xmm14
000074c3551dadea  movaps [rsp+0x10], xmm9
000074c3551dadf0  movaps [rsp+0x20], xmm1
000074c3551dadf5  lea rdi, [rsp]
000074c3551dadf9  mov esi, 0x00
000074c3551dadfe  mov rax, 0x5F9407FA9530
000074c3551dae08  call rax
000074c3551dae0a  movaps xmm14, [rsp]
000074c3551dae0f  add rsp, 0x30
000074c3551dae13  vmovaps xmm0, [rsp]
000074c3551dae18  vmovaps xmm1, [rsp+0x10]
000074c3551dae1e  vmovaps xmm2, [rsp+0x20]
000074c3551dae24  vmovaps xmm3, [rsp+0x30]
000074c3551dae2a  vmovaps xmm4, [rsp+0x40]
000074c3551dae30  vmovaps xmm5, [rsp+0x50]
000074c3551dae36  vmovaps xmm6, [rsp+0x60]
000074c3551dae3c  vmovaps xmm7, [rsp+0x70]
000074c3551dae42  vmovaps xmm8, [rsp+0x80]
000074c3551dae4b  vmovaps xmm9, [rsp+0x90]
000074c3551dae54  vmovaps xmm10, [rsp+0xA0]
000074c3551dae5d  vmovaps xmm11, [rsp+0xB0]
000074c3551dae66  vmovaps xmm12, [rsp+0xC0]
000074c3551dae6f  vmovaps xmm13, [rsp+0xD0]
000074c3551dae78  vmovaps xmm15, [rsp+0xE0]
000074c3551dae81  add rsp, 0xF0
000074c3551dae88  pop r11
000074c3551dae8a  pop r10
000074c3551dae8c  pop r9
000074c3551dae8e  pop r8
000074c3551dae90  pop rsi
000074c3551dae91  pop rdi
000074c3551dae92  pop rdx
000074c3551dae93  pop rcx
000074c3551dae94  pop rax
000074c3551dae95  add rsp, 0x08
000074c3551dae99  jmp 0x000074C3551D6578
000074c3551dae9e  sub rsp, 0x08
000074c3551daea2  push rax
000074c3551daea3  push rcx
000074c3551daea4  push rdx
000074c3551daea5  push rdi
000074c3551daea6  push rsi
000074c3551daea7  push r8
000074c3551daea9  push r9
000074c3551daeab  push r10
000074c3551daead  push r11
000074c3551daeaf  sub rsp, 0xF0
000074c3551daeb6  vmovaps [rsp], xmm0
000074c3551daebb  vmovaps [rsp+0x10], xmm2
000074c3551daec1  vmovaps [rsp+0x20], xmm3
000074c3551daec7  vmovaps [rsp+0x30], xmm4
000074c3551daecd  vmovaps [rsp+0x40], xmm5
000074c3551daed3  vmovaps [rsp+0x50], xmm6
000074c3551daed9  vmovaps [rsp+0x60], xmm7
000074c3551daedf  vmovaps [rsp+0x70], xmm8
000074c3551daee5  vmovaps [rsp+0x80], xmm9
000074c3551daeee  vmovaps [rsp+0x90], xmm10
000074c3551daef7  vmovaps [rsp+0xA0], xmm11
000074c3551daf00  vmovaps [rsp+0xB0], xmm12
000074c3551daf09  vmovaps [rsp+0xC0], xmm13
000074c3551daf12  vmovaps [rsp+0xD0], xmm14
000074c3551daf1b  vmovaps [rsp+0xE0], xmm15
000074c3551daf24  sub rsp, 0x30
000074c3551daf28  movaps [rsp], xmm1
000074c3551daf2c  movaps [rsp+0x10], xmm13
000074c3551daf32  movaps [rsp+0x20], xmm8
000074c3551daf38  lea rdi, [rsp]
000074c3551daf3c  mov esi, 0x00
000074c3551daf41  mov rax, 0x5F9407FA9530
000074c3551daf4b  call rax
000074c3551daf4d  movaps xmm1, [rsp]
000074c3551daf51  add rsp, 0x30
000074c3551daf55  vmovaps xmm0, [rsp]
000074c3551daf5a  vmovaps xmm2, [rsp+0x10]
000074c3551daf60  vmovaps xmm3, [rsp+0x20]
000074c3551daf66  vmovaps xmm4, [rsp+0x30]
000074c3551daf6c  vmovaps xmm5, [rsp+0x40]
000074c3551daf72  vmovaps xmm6, [rsp+0x50]
000074c3551daf78  vmovaps xmm7, [rsp+0x60]
000074c3551daf7e  vmovaps xmm8, [rsp+0x70]
000074c3551daf84  vmovaps xmm9, [rsp+0x80]
000074c3551daf8d  vmovaps xmm10, [rsp+0x90]
000074c3551daf96  vmovaps xmm11, [rsp+0xA0]
000074c3551daf9f  vmovaps xmm12, [rsp+0xB0]
000074c3551dafa8  vmovaps xmm13, [rsp+0xC0]
000074c3551dafb1  vmovaps xmm14, [rsp+0xD0]
000074c3551dafba  vmovaps xmm15, [rsp+0xE0]
000074c3551dafc3  add rsp, 0xF0
000074c3551dafca  pop r11
000074c3551dafcc  pop r10
000074c3551dafce  pop r9
000074c3551dafd0  pop r8
000074c3551dafd2  pop rsi
000074c3551dafd3  pop rdi
000074c3551dafd4  pop rdx
000074c3551dafd5  pop rcx
000074c3551dafd6  pop rax
000074c3551dafd7  add rsp, 0x08
000074c3551dafdb  jmp 0x000074C3551D659A
000074c3551dafe0  call 0x000074C35500C260
000074c3551dafe5  jmp 0x000074C3551D65A8
000074c3551dafea  call 0x000074C3550DE950
000074c3551dafef  jmp 0x000074C3551D65B2
000074c3551daff4  sub rsp, 0x08
000074c3551daff8  push rax
000074c3551daff9  push rcx
000074c3551daffa  push rdx
000074c3551daffb  push rdi
000074c3551daffc  push rsi
000074c3551daffd  push r8
000074c3551dafff  push r9
000074c3551db001  push r10
000074c3551db003  push r11
000074c3551db005  sub rsp, 0xF0
000074c3551db00c  vmovaps [rsp], xmm0
000074c3551db011  vmovaps [rsp+0x10], xmm1
000074c3551db017  vmovaps [rsp+0x20], xmm2
000074c3551db01d  vmovaps [rsp+0x30], xmm3
000074c3551db023  vmovaps [rsp+0x40], xmm4
000074c3551db029  vmovaps [rsp+0x50], xmm5
000074c3551db02f  vmovaps [rsp+0x60], xmm6
000074c3551db035  vmovaps [rsp+0x70], xmm7
000074c3551db03b  vmovaps [rsp+0x80], xmm9
000074c3551db044  vmovaps [rsp+0x90], xmm10
000074c3551db04d  vmovaps [rsp+0xA0], xmm11
000074c3551db056  vmovaps [rsp+0xB0], xmm12
000074c3551db05f  vmovaps [rsp+0xC0], xmm13
000074c3551db068  vmovaps [rsp+0xD0], xmm14
000074c3551db071  vmovaps [rsp+0xE0], xmm15
000074c3551db07a  sub rsp, 0x30
000074c3551db07e  movaps [rsp], xmm8
000074c3551db083  movaps [rsp+0x10], xmm15
000074c3551db089  movaps [rsp+0x20], xmm7
000074c3551db08e  lea rdi, [rsp]
000074c3551db092  mov esi, 0x00
000074c3551db097  mov rax, 0x5F9407FA9530
000074c3551db0a1  call rax
000074c3551db0a3  movaps xmm8, [rsp]
000074c3551db0a8  add rsp, 0x30
000074c3551db0ac  vmovaps xmm0, [rsp]
000074c3551db0b1  vmovaps xmm1, [rsp+0x10]
000074c3551db0b7  vmovaps xmm2, [rsp+0x20]
000074c3551db0bd  vmovaps xmm3, [rsp+0x30]
000074c3551db0c3  vmovaps xmm4, [rsp+0x40]
000074c3551db0c9  vmovaps xmm5, [rsp+0x50]
000074c3551db0cf  vmovaps xmm6, [rsp+0x60]
000074c3551db0d5  vmovaps xmm7, [rsp+0x70]
000074c3551db0db  vmovaps xmm9, [rsp+0x80]
000074c3551db0e4  vmovaps xmm10, [rsp+0x90]
000074c3551db0ed  vmovaps xmm11, [rsp+0xA0]
000074c3551db0f6  vmovaps xmm12, [rsp+0xB0]
000074c3551db0ff  vmovaps xmm13, [rsp+0xC0]
000074c3551db108  vmovaps xmm14, [rsp+0xD0]
000074c3551db111  vmovaps xmm15, [rsp+0xE0]
000074c3551db11a  add rsp, 0xF0
000074c3551db121  pop r11
000074c3551db123  pop r10
000074c3551db125  pop r9
000074c3551db127  pop r8
000074c3551db129  pop rsi
000074c3551db12a  pop rdi
000074c3551db12b  pop rdx
000074c3551db12c  pop rcx
000074c3551db12d  pop rax
000074c3551db12e  add rsp, 0x08
000074c3551db132  jmp 0x000074C3551D65D4
000074c3551db137  sub rsp, 0x08
000074c3551db13b  push rax
000074c3551db13c  push rcx
000074c3551db13d  push rdx
000074c3551db13e  push rdi
000074c3551db13f  push rsi
000074c3551db140  push r8
000074c3551db142  push r9
000074c3551db144  push r10
000074c3551db146  push r11
000074c3551db148  sub rsp, 0xF0
000074c3551db14f  vmovaps [rsp], xmm0
000074c3551db154  vmovaps [rsp+0x10], xmm1
000074c3551db15a  vmovaps [rsp+0x20], xmm2
000074c3551db160  vmovaps [rsp+0x30], xmm3
000074c3551db166  vmovaps [rsp+0x40], xmm4
000074c3551db16c  vmovaps [rsp+0x50], xmm5
000074c3551db172  vmovaps [rsp+0x60], xmm6
000074c3551db178  vmovaps [rsp+0x70], xmm8
000074c3551db17e  vmovaps [rsp+0x80], xmm9
000074c3551db187  vmovaps [rsp+0x90], xmm10
000074c3551db190  vmovaps [rsp+0xA0], xmm11
000074c3551db199  vmovaps [rsp+0xB0], xmm12
000074c3551db1a2  vmovaps [rsp+0xC0], xmm13
000074c3551db1ab  vmovaps [rsp+0xD0], xmm14
000074c3551db1b4  vmovaps [rsp+0xE0], xmm15
000074c3551db1bd  sub rsp, 0x30
000074c3551db1c1  movaps [rsp], xmm7
000074c3551db1c5  movaps [rsp+0x10], xmm9
000074c3551db1cb  movaps [rsp+0x20], xmm15
000074c3551db1d1  lea rdi, [rsp]
000074c3551db1d5  mov esi, 0x00
000074c3551db1da  mov rax, 0x5F9407FA9530
000074c3551db1e4  call rax
000074c3551db1e6  movaps xmm7, [rsp]
000074c3551db1ea  add rsp, 0x30
000074c3551db1ee  vmovaps xmm0, [rsp]
000074c3551db1f3  vmovaps xmm1, [rsp+0x10]
000074c3551db1f9  vmovaps xmm2, [rsp+0x20]
000074c3551db1ff  vmovaps xmm3, [rsp+0x30]
000074c3551db205  vmovaps xmm4, [rsp+0x40]
000074c3551db20b  vmovaps xmm5, [rsp+0x50]
000074c3551db211  vmovaps xmm6, [rsp+0x60]
000074c3551db217  vmovaps xmm8, [rsp+0x70]
000074c3551db21d  vmovaps xmm9, [rsp+0x80]
000074c3551db226  vmovaps xmm10, [rsp+0x90]
000074c3551db22f  vmovaps xmm11, [rsp+0xA0]
000074c3551db238  vmovaps xmm12, [rsp+0xB0]
000074c3551db241  vmovaps xmm13, [rsp+0xC0]
000074c3551db24a  vmovaps xmm14, [rsp+0xD0]
000074c3551db253  vmovaps xmm15, [rsp+0xE0]
000074c3551db25c  add rsp, 0xF0
000074c3551db263  pop r11
000074c3551db265  pop r10
000074c3551db267  pop r9
000074c3551db269  pop r8
000074c3551db26b  pop rsi
000074c3551db26c  pop rdi
000074c3551db26d  pop rdx
000074c3551db26e  pop rcx
000074c3551db26f  pop rax
000074c3551db270  add rsp, 0x08
000074c3551db274  jmp 0x000074C3551D6601
000074c3551db279  sub rsp, 0x08
000074c3551db27d  push rax
000074c3551db27e  push rcx
000074c3551db27f  push rdx
000074c3551db280  push rdi
000074c3551db281  push rsi
000074c3551db282  push r8
000074c3551db284  push r9
000074c3551db286  push r10
000074c3551db288  push r11
000074c3551db28a  sub rsp, 0xF0
000074c3551db291  vmovaps [rsp], xmm0
000074c3551db296  vmovaps [rsp+0x10], xmm1
000074c3551db29c  vmovaps [rsp+0x20], xmm2
000074c3551db2a2  vmovaps [rsp+0x30], xmm3
000074c3551db2a8  vmovaps [rsp+0x40], xmm4
000074c3551db2ae  vmovaps [rsp+0x50], xmm5
000074c3551db2b4  vmovaps [rsp+0x60], xmm6
000074c3551db2ba  vmovaps [rsp+0x70], xmm7
000074c3551db2c0  vmovaps [rsp+0x80], xmm8
000074c3551db2c9  vmovaps [rsp+0x90], xmm10
000074c3551db2d2  vmovaps [rsp+0xA0], xmm11
000074c3551db2db  vmovaps [rsp+0xB0], xmm12
000074c3551db2e4  vmovaps [rsp+0xC0], xmm13
000074c3551db2ed  vmovaps [rsp+0xD0], xmm14
000074c3551db2f6  vmovaps [rsp+0xE0], xmm15
000074c3551db2ff  sub rsp, 0x30
000074c3551db303  movaps [rsp], xmm9
000074c3551db308  movaps [rsp+0x10], xmm13
000074c3551db30e  movaps [rsp+0x20], xmm15
000074c3551db314  lea rdi, [rsp]
000074c3551db318  mov esi, 0x00
000074c3551db31d  mov rax, 0x5F9407FA9530
000074c3551db327  call rax
000074c3551db329  movaps xmm9, [rsp]
000074c3551db32e  add rsp, 0x30
000074c3551db332  vmovaps xmm0, [rsp]
000074c3551db337  vmovaps xmm1, [rsp+0x10]
000074c3551db33d  vmovaps xmm2, [rsp+0x20]
000074c3551db343  vmovaps xmm3, [rsp+0x30]
000074c3551db349  vmovaps xmm4, [rsp+0x40]
000074c3551db34f  vmovaps xmm5, [rsp+0x50]
000074c3551db355  vmovaps xmm6, [rsp+0x60]
000074c3551db35b  vmovaps xmm7, [rsp+0x70]
000074c3551db361  vmovaps xmm8, [rsp+0x80]
000074c3551db36a  vmovaps xmm10, [rsp+0x90]
000074c3551db373  vmovaps xmm11, [rsp+0xA0]
000074c3551db37c  vmovaps xmm12, [rsp+0xB0]
000074c3551db385  vmovaps xmm13, [rsp+0xC0]
000074c3551db38e  vmovaps xmm14, [rsp+0xD0]
000074c3551db397  vmovaps xmm15, [rsp+0xE0]
000074c3551db3a0  add rsp, 0xF0
000074c3551db3a7  pop r11
000074c3551db3a9  pop r10
000074c3551db3ab  pop r9
000074c3551db3ad  pop r8
000074c3551db3af  pop rsi
000074c3551db3b0  pop rdi
000074c3551db3b1  pop rdx
000074c3551db3b2  pop rcx
000074c3551db3b3  pop rax
000074c3551db3b4  add rsp, 0x08
000074c3551db3b8  jmp 0x000074C3551D662F
000074c3551db3bd  sub rsp, 0x08
000074c3551db3c1  push rax
000074c3551db3c2  push rcx
000074c3551db3c3  push rdx
000074c3551db3c4  push rdi
000074c3551db3c5  push rsi
000074c3551db3c6  push r8
000074c3551db3c8  push r9
000074c3551db3ca  push r10
000074c3551db3cc  push r11
000074c3551db3ce  sub rsp, 0xF0
000074c3551db3d5  vmovaps [rsp], xmm0
000074c3551db3da  vmovaps [rsp+0x10], xmm1
000074c3551db3e0  vmovaps [rsp+0x20], xmm2
000074c3551db3e6  vmovaps [rsp+0x30], xmm3
000074c3551db3ec  vmovaps [rsp+0x40], xmm4
000074c3551db3f2  vmovaps [rsp+0x50], xmm5
000074c3551db3f8  vmovaps [rsp+0x60], xmm6
000074c3551db3fe  vmovaps [rsp+0x70], xmm7
000074c3551db404  vmovaps [rsp+0x80], xmm8
000074c3551db40d  vmovaps [rsp+0x90], xmm9
000074c3551db416  vmovaps [rsp+0xA0], xmm10
000074c3551db41f  vmovaps [rsp+0xB0], xmm11
000074c3551db428  vmovaps [rsp+0xC0], xmm12
000074c3551db431  vmovaps [rsp+0xD0], xmm13
000074c3551db43a  vmovaps [rsp+0xE0], xmm14
000074c3551db443  sub rsp, 0x30
000074c3551db447  movaps [rsp], xmm15
000074c3551db44c  movaps [rsp+0x10], xmm11
000074c3551db452  movaps [rsp+0x20], xmm12
000074c3551db458  lea rdi, [rsp]
000074c3551db45c  mov esi, 0x00
000074c3551db461  mov rax, 0x5F9407FA9530
000074c3551db46b  call rax
000074c3551db46d  movaps xmm15, [rsp]
000074c3551db472  add rsp, 0x30
000074c3551db476  vmovaps xmm0, [rsp]
000074c3551db47b  vmovaps xmm1, [rsp+0x10]
000074c3551db481  vmovaps xmm2, [rsp+0x20]
000074c3551db487  vmovaps xmm3, [rsp+0x30]
000074c3551db48d  vmovaps xmm4, [rsp+0x40]
000074c3551db493  vmovaps xmm5, [rsp+0x50]
000074c3551db499  vmovaps xmm6, [rsp+0x60]
000074c3551db49f  vmovaps xmm7, [rsp+0x70]
000074c3551db4a5  vmovaps xmm8, [rsp+0x80]
000074c3551db4ae  vmovaps xmm9, [rsp+0x90]
000074c3551db4b7  vmovaps xmm10, [rsp+0xA0]
000074c3551db4c0  vmovaps xmm11, [rsp+0xB0]
000074c3551db4c9  vmovaps xmm12, [rsp+0xC0]
000074c3551db4d2  vmovaps xmm13, [rsp+0xD0]
000074c3551db4db  vmovaps xmm14, [rsp+0xE0]
000074c3551db4e4  add rsp, 0xF0
000074c3551db4eb  pop r11
000074c3551db4ed  pop r10
000074c3551db4ef  pop r9
000074c3551db4f1  pop r8
000074c3551db4f3  pop rsi
000074c3551db4f4  pop rdi
000074c3551db4f5  pop rdx
000074c3551db4f6  pop rcx
000074c3551db4f7  pop rax
000074c3551db4f8  add rsp, 0x08
000074c3551db4fc  jmp 0x000074C3551D664A
000074c3551db501  sub rsp, 0x08
000074c3551db505  push rax
000074c3551db506  push rcx
000074c3551db507  push rdx
000074c3551db508  push rdi
000074c3551db509  push rsi
000074c3551db50a  push r8
000074c3551db50c  push r9
000074c3551db50e  push r10
000074c3551db510  push r11
000074c3551db512  sub rsp, 0xF0
000074c3551db519  vmovaps [rsp], xmm0
000074c3551db51e  vmovaps [rsp+0x10], xmm1
000074c3551db524  vmovaps [rsp+0x20], xmm2
000074c3551db52a  vmovaps [rsp+0x30], xmm3
000074c3551db530  vmovaps [rsp+0x40], xmm4
000074c3551db536  vmovaps [rsp+0x50], xmm5
000074c3551db53c  vmovaps [rsp+0x60], xmm6
000074c3551db542  vmovaps [rsp+0x70], xmm7
000074c3551db548  vmovaps [rsp+0x80], xmm8
000074c3551db551  vmovaps [rsp+0x90], xmm9
000074c3551db55a  vmovaps [rsp+0xA0], xmm10
000074c3551db563  vmovaps [rsp+0xB0], xmm11
000074c3551db56c  vmovaps [rsp+0xC0], xmm12
000074c3551db575  vmovaps [rsp+0xD0], xmm14
000074c3551db57e  vmovaps [rsp+0xE0], xmm15
000074c3551db587  sub rsp, 0x30
000074c3551db58b  movaps [rsp], xmm13
000074c3551db590  movaps [rsp+0x10], xmm10
000074c3551db596  movaps [rsp+0x20], xmm14
000074c3551db59c  lea rdi, [rsp]
000074c3551db5a0  mov esi, 0x00
000074c3551db5a5  mov rax, 0x5F9407FA9530
000074c3551db5af  call rax
000074c3551db5b1  movaps xmm13, [rsp]
000074c3551db5b6  add rsp, 0x30
000074c3551db5ba  vmovaps xmm0, [rsp]
000074c3551db5bf  vmovaps xmm1, [rsp+0x10]
000074c3551db5c5  vmovaps xmm2, [rsp+0x20]
000074c3551db5cb  vmovaps xmm3, [rsp+0x30]
000074c3551db5d1  vmovaps xmm4, [rsp+0x40]
000074c3551db5d7  vmovaps xmm5, [rsp+0x50]
000074c3551db5dd  vmovaps xmm6, [rsp+0x60]
000074c3551db5e3  vmovaps xmm7, [rsp+0x70]
000074c3551db5e9  vmovaps xmm8, [rsp+0x80]
000074c3551db5f2  vmovaps xmm9, [rsp+0x90]
000074c3551db5fb  vmovaps xmm10, [rsp+0xA0]
000074c3551db604  vmovaps xmm11, [rsp+0xB0]
000074c3551db60d  vmovaps xmm12, [rsp+0xC0]
000074c3551db616  vmovaps xmm14, [rsp+0xD0]
000074c3551db61f  vmovaps xmm15, [rsp+0xE0]
000074c3551db628  add rsp, 0xF0
000074c3551db62f  pop r11
000074c3551db631  pop r10
000074c3551db633  pop r9
000074c3551db635  pop r8
000074c3551db637  pop rsi
000074c3551db638  pop rdi
000074c3551db639  pop rdx
000074c3551db63a  pop rcx
000074c3551db63b  pop rax
000074c3551db63c  add rsp, 0x08
000074c3551db640  jmp 0x000074C3551D666D
000074c3551db645  sub rsp, 0x08
000074c3551db649  push rax
000074c3551db64a  push rcx
000074c3551db64b  push rdx
000074c3551db64c  push rdi
000074c3551db64d  push rsi
000074c3551db64e  push r8
000074c3551db650  push r9
000074c3551db652  push r10
000074c3551db654  push r11
000074c3551db656  sub rsp, 0xF0
000074c3551db65d  vmovaps [rsp], xmm0
000074c3551db662  vmovaps [rsp+0x10], xmm1
000074c3551db668  vmovaps [rsp+0x20], xmm2
000074c3551db66e  vmovaps [rsp+0x30], xmm3
000074c3551db674  vmovaps [rsp+0x40], xmm4
000074c3551db67a  vmovaps [rsp+0x50], xmm5
000074c3551db680  vmovaps [rsp+0x60], xmm6
000074c3551db686  vmovaps [rsp+0x70], xmm7
000074c3551db68c  vmovaps [rsp+0x80], xmm8
000074c3551db695  vmovaps [rsp+0x90], xmm9
000074c3551db69e  vmovaps [rsp+0xA0], xmm10
000074c3551db6a7  vmovaps [rsp+0xB0], xmm11
000074c3551db6b0  vmovaps [rsp+0xC0], xmm12
000074c3551db6b9  vmovaps [rsp+0xD0], xmm13
000074c3551db6c2  vmovaps [rsp+0xE0], xmm15
000074c3551db6cb  sub rsp, 0x30
000074c3551db6cf  movaps [rsp], xmm14
000074c3551db6d4  movaps [rsp+0x10], xmm1
000074c3551db6d9  movaps [rsp+0x20], xmm7
000074c3551db6de  lea rdi, [rsp]
000074c3551db6e2  mov esi, 0x00
000074c3551db6e7  mov rax, 0x5F9407FA9530
000074c3551db6f1  call rax
000074c3551db6f3  movaps xmm14, [rsp]
000074c3551db6f8  add rsp, 0x30
000074c3551db6fc  vmovaps xmm0, [rsp]
000074c3551db701  vmovaps xmm1, [rsp+0x10]
000074c3551db707  vmovaps xmm2, [rsp+0x20]
000074c3551db70d  vmovaps xmm3, [rsp+0x30]
000074c3551db713  vmovaps xmm4, [rsp+0x40]
000074c3551db719  vmovaps xmm5, [rsp+0x50]
000074c3551db71f  vmovaps xmm6, [rsp+0x60]
000074c3551db725  vmovaps xmm7, [rsp+0x70]
000074c3551db72b  vmovaps xmm8, [rsp+0x80]
000074c3551db734  vmovaps xmm9, [rsp+0x90]
000074c3551db73d  vmovaps xmm10, [rsp+0xA0]
000074c3551db746  vmovaps xmm11, [rsp+0xB0]
000074c3551db74f  vmovaps xmm12, [rsp+0xC0]
000074c3551db758  vmovaps xmm13, [rsp+0xD0]
000074c3551db761  vmovaps xmm15, [rsp+0xE0]
000074c3551db76a  add rsp, 0xF0
000074c3551db771  pop r11
000074c3551db773  pop r10
000074c3551db775  pop r9
000074c3551db777  pop r8
000074c3551db779  pop rsi
000074c3551db77a  pop rdi
000074c3551db77b  pop rdx
000074c3551db77c  pop rcx
000074c3551db77d  pop rax
000074c3551db77e  add rsp, 0x08
000074c3551db782  jmp 0x000074C3551D6690
000074c3551db787  sub rsp, 0x08
000074c3551db78b  push rax
000074c3551db78c  push rcx
000074c3551db78d  push rdx
000074c3551db78e  push rdi
000074c3551db78f  push rsi
000074c3551db790  push r8
000074c3551db792  push r9
000074c3551db794  push r10
000074c3551db796  push r11
000074c3551db798  sub rsp, 0xF0
000074c3551db79f  vmovaps [rsp], xmm0
000074c3551db7a4  vmovaps [rsp+0x10], xmm2
000074c3551db7aa  vmovaps [rsp+0x20], xmm3
000074c3551db7b0  vmovaps [rsp+0x30], xmm4
000074c3551db7b6  vmovaps [rsp+0x40], xmm5
000074c3551db7bc  vmovaps [rsp+0x50], xmm6
000074c3551db7c2  vmovaps [rsp+0x60], xmm7
000074c3551db7c8  vmovaps [rsp+0x70], xmm8
000074c3551db7ce  vmovaps [rsp+0x80], xmm9
000074c3551db7d7  vmovaps [rsp+0x90], xmm10
000074c3551db7e0  vmovaps [rsp+0xA0], xmm11
000074c3551db7e9  vmovaps [rsp+0xB0], xmm12
000074c3551db7f2  vmovaps [rsp+0xC0], xmm13
000074c3551db7fb  vmovaps [rsp+0xD0], xmm14
000074c3551db804  vmovaps [rsp+0xE0], xmm15
000074c3551db80d  sub rsp, 0x30
000074c3551db811  movaps [rsp], xmm1
000074c3551db815  movaps [rsp+0x10], xmm8
000074c3551db81b  movaps [rsp+0x20], xmm9
000074c3551db821  lea rdi, [rsp]
000074c3551db825  mov esi, 0x00
000074c3551db82a  mov rax, 0x5F9407FA9530
000074c3551db834  call rax
000074c3551db836  movaps xmm1, [rsp]
000074c3551db83a  add rsp, 0x30
000074c3551db83e  vmovaps xmm0, [rsp]
000074c3551db843  vmovaps xmm2, [rsp+0x10]
000074c3551db849  vmovaps xmm3, [rsp+0x20]
000074c3551db84f  vmovaps xmm4, [rsp+0x30]
000074c3551db855  vmovaps xmm5, [rsp+0x40]
000074c3551db85b  vmovaps xmm6, [rsp+0x50]
000074c3551db861  vmovaps xmm7, [rsp+0x60]
000074c3551db867  vmovaps xmm8, [rsp+0x70]
000074c3551db86d  vmovaps xmm9, [rsp+0x80]
000074c3551db876  vmovaps xmm10, [rsp+0x90]
000074c3551db87f  vmovaps xmm11, [rsp+0xA0]
000074c3551db888  vmovaps xmm12, [rsp+0xB0]
000074c3551db891  vmovaps xmm13, [rsp+0xC0]
000074c3551db89a  vmovaps xmm14, [rsp+0xD0]
000074c3551db8a3  vmovaps xmm15, [rsp+0xE0]
000074c3551db8ac  add rsp, 0xF0
000074c3551db8b3  pop r11
000074c3551db8b5  pop r10
000074c3551db8b7  pop r9
000074c3551db8b9  pop r8
000074c3551db8bb  pop rsi
000074c3551db8bc  pop rdi
000074c3551db8bd  pop rdx
000074c3551db8be  pop rcx
000074c3551db8bf  pop rax
000074c3551db8c0  add rsp, 0x08
000074c3551db8c4  jmp 0x000074C3551D66B2
000074c3551db8c9  call 0x000074C3550B3E40
000074c3551db8ce  jmp 0x000074C3551D66C0
000074c3551db8d3  call 0x000074C35500C380
000074c3551db8d8  jmp 0x000074C3551D66CA
000074c3551db8dd  call 0x000074C35500D600
000074c3551db8e2  jmp 0x000074C3551D66D4
000074c3551db8e7  call 0x000074C354FFF540
000074c3551db8ec  jmp 0x000074C3551D66DE
000074c3551db8f1  int3
000074c3551db8f2  nop [rax+rax*1], ax
000074c3551db8fb  nop [rax+rax*1], eax
000074c3551db900  mov eax, [r15+0x48]
000074c3551db904  lea r14d, [eax+0x01]
000074c3551db909  mov [rsp+0x10], r14d
000074c3551db90e  mov r14d, r14d
000074c3551db911  mov [r15+0x48], r14
000074c3551db915  xor eax, eax
000074c3551db917  mov r14d, [rsp+0x10]
000074c3551db91c  cmp r14d, 0x1F4
000074c3551db923  cmc
000074c3551db924  lahf
000074c3551db925  seto al
000074c3551db928  mov [r15+0x108], eax
000074c3551db92f  mov eax, [r15+0x108]
000074c3551db936  sahf
000074c3551db937  jnz 0x000074C3551DB969
000074c3551db939  cmp dword ptr [r15+0x318], 0x00
000074c3551db941  jz 0x000074C3551E1AB0
000074c3551db947  nop [rax+rax*1], ax
000074c3551db950  nop [rax+rax*1], eax
000074c3551db958  mov eax, 0x410450
000074c3551db95d  mov [r15+0x100], rax
000074c3551db964  jmp 0x000074C354FFE110
000074c3551db969  cmp dword ptr [r15+0x318], 0x00
000074c3551db971  jz 0x000074C3551DB9A0
000074c3551db977  nop [rax+rax*1], ax
000074c3551db980  nop [rax+rax*1], eax
000074c3551db988  mov eax, 0x410274
000074c3551db98d  mov [r15+0x100], rax
000074c3551db994  jmp 0x000074C354FFE110
000074c3551db999  int3
000074c3551db99a  int3
000074c3551db99b  nop [rax+rax*1], eax
000074c3551db9a0  mov rax, [r15+0x40]
000074c3551db9a4  movaps xmm1, [r15+0x1D0]
000074c3551db9ac  vmovaps [rsp+0x10], xmm1
000074c3551db9b2  vmovaps xmm15, [rsp+0x10]
000074c3551db9b8  por xmm1, xmm15
000074c3551db9bd  movaps xmm14, [r15+0x1A0]
000074c3551db9c5  vmovaps [rsp+0x10], xmm14
000074c3551db9cb  vmovaps xmm13, [rsp+0x10]
000074c3551db9d1  por xmm14, xmm13
000074c3551db9d6  lea r14, [rax+0x30]
000074c3551db9da  mov r12, [r13+r14*1]
000074c3551db9df  lea r14, [rax+0x38]
000074c3551db9e3  mov r11, [r13+r14*1]
000074c3551db9e8  movq xmm13, r12
000074c3551db9ed  movq xmm12, r11
000074c3551db9f2  movq xmm13, xmm13
000074c3551db9f7  vmovaps [rsp+0x10], xmm13
000074c3551db9fd  movq xmm13, xmm13
000074c3551dba02  movaps [r15+0x130], xmm13
000074c3551dba0a  movq xmm12, xmm12
000074c3551dba0f  vmovaps [rsp+0x20], xmm12
000074c3551dba15  movq xmm12, xmm12
000074c3551dba1a  movaps [r15+0x280], xmm12
000074c3551dba22  movaps xmm13, [r15+0x270]
000074c3551dba2a  vmovaps [rsp+0x30], xmm13
000074c3551dba30  vmovaps xmm12, [rsp+0x30]
000074c3551dba36  por xmm13, xmm12
000074c3551dba3b  lea r14, [rax+0x20]
000074c3551dba3f  mov r12, [r13+r14*1]
000074c3551dba44  lea r14, [rax+0x28]
000074c3551dba48  mov r11, [r13+r14*1]
000074c3551dba4d  movq xmm12, r12
000074c3551dba52  movq xmm11, r11
000074c3551dba57  movq xmm12, xmm12
000074c3551dba5c  vmovaps [rsp+0x30], xmm12
000074c3551dba62  movq xmm12, xmm12
000074c3551dba67  movaps [r15+0x150], xmm12
000074c3551dba6f  movq xmm11, xmm11
000074c3551dba74  vmovaps [rsp+0x40], xmm11
000074c3551dba7a  movq xmm11, xmm11
000074c3551dba7f  movaps [r15+0x140], xmm11
000074c3551dba87  lea r14, [rax+0x10]
000074c3551dba8b  mov r12, [r13+r14*1]
000074c3551dba90  lea r14, [rax+0x18]
000074c3551dba94  mov r11, [r13+r14*1]
000074c3551dba99  movq xmm12, r12
000074c3551dba9e  movq xmm11, r11
000074c3551dbaa3  movq xmm12, xmm12
000074c3551dbaa8  vmovaps [rsp+0x50], xmm12
000074c3551dbaae  movq xmm12, xmm12
000074c3551dbab3  movaps [r15+0x170], xmm12
000074c3551dbabb  movq xmm11, xmm11
000074c3551dbac0  vmovaps [rsp+0x60], xmm11
000074c3551dbac6  movq xmm11, xmm11
000074c3551dbacb  movaps [r15+0x160], xmm11
000074c3551dbad3  mov r14, [r13+rax*1]
000074c3551dbad8  vmovq xmm12, r14
000074c3551dbadd  vpbroadcastq xmm12, xmm12
000074c3551dbae2  lea r14, [rax+0x08]
000074c3551dbae6  mov rax, [r13+r14*1]
000074c3551dbaeb  movq xmm11, rax
000074c3551dbaf0  movaps [r15+0x230], xmm11
000074c3551dbaf8  mov rax, [r15+0xF8]
000074c3551dbaff  lea r14, [rax+0x50]
000074c3551dbb03  movups xmm11, [r13+r14*1]
000074c3551dbb09  lea r14, [rax+0x60]
000074c3551dbb0d  movups xmm10, [r13+r14*1]
000074c3551dbb13  lea r14, [rax+0x30]
000074c3551dbb17  movups xmm9, [r13+r14*1]
000074c3551dbb1d  mov r14, [r15+0x50]
000074c3551dbb21  mov [r15+0x60], r14
000074c3551dbb25  mov qword ptr [r15+0x58], 0x40
000074c3551dbb2d  movaps xmm8, xmm12
000074c3551dbb31  mulpd xmm8, xmm15
000074c3551dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000074c3551dbb3c  ptest xmm7, xmm7
000074c3551dbb41  jnz 0x000074C3551DC96A
000074c3551dbb47  movq xmm15, qword ptr [r15+0x230]
000074c3551dbb50  vmovaps [rsp+0x70], xmm15
000074c3551dbb56  vpermilpd xmm15, xmm15, 0x00
000074c3551dbb5c  movaps xmm7, xmm9
000074c3551dbb60  mulpd xmm7, xmm15
000074c3551dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000074c3551dbb6a  ptest xmm6, xmm6
000074c3551dbb6f  jnz 0x000074C3551DCAAE
000074c3551dbb75  vxorps xmm15, xmm15, xmm15
000074c3551dbb7a  vpbroadcastq xmm15, xmm15
000074c3551dbb7f  movaps xmm9, xmm12
000074c3551dbb83  mulpd xmm9, xmm10
000074c3551dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000074c3551dbb8e  ptest xmm6, xmm6
000074c3551dbb93  jnz 0x000074C3551DCBF0
000074c3551dbb99  movaps xmm10, xmm12
000074c3551dbb9d  mulpd xmm10, xmm11
000074c3551dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000074c3551dbba8  ptest xmm6, xmm6
000074c3551dbbad  jnz 0x000074C3551DCD34
000074c3551dbbb3  movaps xmm11, [r15+0x1F0]
000074c3551dbbbb  movaps xmm6, xmm12
000074c3551dbbbf  mulpd xmm6, xmm11
000074c3551dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000074c3551dbbc9  ptest xmm5, xmm5
000074c3551dbbce  jnz 0x000074C3551DCE78
000074c3551dbbd4  movaps xmm12, [r15+0x2A0]
000074c3551dbbdc  vmovaps [rsp+0x80], xmm12
000074c3551dbbe5  vmovaps xmm11, [rsp+0x80]
000074c3551dbbee  por xmm12, xmm11
000074c3551dbbf3  movaps xmm11, [r15+0x250]
000074c3551dbbfb  vmovaps [rsp+0x80], xmm11
000074c3551dbc04  vmovaps xmm5, [rsp+0x80]
000074c3551dbc0d  por xmm11, xmm5
000074c3551dbc12  vmovaps xmm4, [rsp+0x70]
000074c3551dbc18  vpermilpd xmm4, xmm4, 0x00
000074c3551dbc1e  movaps xmm3, xmm5
000074c3551dbc21  mulpd xmm3, xmm4
000074c3551dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000074c3551dbc2a  ptest xmm2, xmm2
000074c3551dbc2f  jnz 0x000074C3551DCFBA
000074c3551dbc35  mov [rsp+0x80], rax
000074c3551dbc3d  xor eax, eax
000074c3551dbc3f  mov r12d, 0x40
000074c3551dbc45  mov r11d, 0x200
000074c3551dbc4b  cmp r12, r11
000074c3551dbc4e  cmc
000074c3551dbc4f  lahf
000074c3551dbc50  seto al
000074c3551dbc53  mov [r15+0x108], eax
000074c3551dbc5a  movaps xmm5, xmm8
000074c3551dbc5e  addpd xmm5, xmm15
000074c3551dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000074c3551dbc68  ptest xmm4, xmm4
000074c3551dbc6d  jnz 0x000074C3551DD0FA
000074c3551dbc73  movaps xmm8, [r15+0x1B0]
000074c3551dbc7b  movaps xmm4, xmm9
000074c3551dbc7f  addpd xmm4, xmm8
000074c3551dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000074c3551dbc89  ptest xmm2, xmm2
000074c3551dbc8e  jnz 0x000074C3551DD23C
000074c3551dbc94  movaps xmm9, xmm10
000074c3551dbc98  addpd xmm9, xmm8
000074c3551dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000074c3551dbca3  ptest xmm2, xmm2
000074c3551dbca8  jnz 0x000074C3551DD37E
000074c3551dbcae  movaps xmm10, [r15+0x2F0]
000074c3551dbcb6  vmovaps [rsp+0x90], xmm10
000074c3551dbcbf  vmovaps xmm8, [rsp+0x90]
000074c3551dbcc8  por xmm10, xmm8
000074c3551dbccd  movaps xmm8, [r15+0x2E0]
000074c3551dbcd5  vmovaps [rsp+0x90], xmm8
000074c3551dbcde  vmovaps xmm2, [rsp+0x90]
000074c3551dbce7  por xmm8, xmm2
000074c3551dbcec  movaps xmm2, [r15+0x2D0]
000074c3551dbcf4  vmovaps [rsp+0x90], xmm2
000074c3551dbcfd  vmovaps [rsp+0xA0], xmm1
000074c3551dbd06  vmovaps xmm1, [rsp+0x90]
000074c3551dbd0f  por xmm2, xmm1
000074c3551dbd13  movaps xmm1, [r15+0x200]
000074c3551dbd1b  vmovaps [rsp+0x90], xmm1
000074c3551dbd24  vmovaps [rsp+0xB0], xmm15
000074c3551dbd2d  vmovaps xmm15, [rsp+0x90]
000074c3551dbd36  por xmm1, xmm15
000074c3551dbd3b  movaps xmm15, [r15+0x1C0]
000074c3551dbd43  vmovaps [rsp+0x90], xmm15
000074c3551dbd4c  vmovaps [rsp+0xC0], xmm1
000074c3551dbd55  vmovaps xmm1, [rsp+0x90]
000074c3551dbd5e  por xmm15, xmm1
000074c3551dbd63  movaps xmm1, [r15+0x190]
000074c3551dbd6b  vmovaps [rsp+0x90], xmm1
000074c3551dbd74  vmovaps [rsp+0xD0], xmm15
000074c3551dbd7d  vmovaps xmm15, [rsp+0x90]
000074c3551dbd86  por xmm1, xmm15
000074c3551dbd8b  movaps xmm15, [r15+0x300]
000074c3551dbd93  vmovaps [rsp+0x90], xmm15
000074c3551dbd9c  vmovaps [rsp+0xE0], xmm1
000074c3551dbda5  vmovaps xmm1, [rsp+0x90]
000074c3551dbdae  por xmm15, xmm1
000074c3551dbdb3  mov rax, [rsp+0x80]
000074c3551dbdbb  lea r12, [rax+0xA0]
000074c3551dbdc2  movups xmm1, [r13+r12*1]
000074c3551dbdc8  lea r12, [rax+0xB0]
000074c3551dbdcf  vmovaps [rsp+0x80], xmm1
000074c3551dbdd8  movups xmm1, [r13+r12*1]
000074c3551dbdde  vmovaps [rsp+0x90], xmm1
000074c3551dbde7  vmovaps [rsp+0xF0], xmm15
000074c3551dbdf0  vmovaps xmm15, [rsp+0xB0]
000074c3551dbdf9  vmovaps [rsp+0xB0], xmm14
000074c3551dbe02  movaps xmm1, xmm6
000074c3551dbe05  addpd xmm1, xmm15
000074c3551dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000074c3551dbe0f  ptest xmm14, xmm14
000074c3551dbe15  jnz 0x000074C3551DD4D6
000074c3551dbe1b  lea r12, [rax+0xF0]
000074c3551dbe22  movups xmm15, [r13+r12*1]
000074c3551dbe28  movaps xmm14, xmm4
000074c3551dbe2c  addpd xmm14, xmm3
000074c3551dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000074c3551dbe37  ptest xmm6, xmm6
000074c3551dbe3c  jnz 0x000074C3551DD621
000074c3551dbe42  movaps xmm6, xmm9
000074c3551dbe46  addpd xmm6, xmm7
000074c3551dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000074c3551dbe4f  ptest xmm4, xmm4
000074c3551dbe54  jnz 0x000074C3551DD763
000074c3551dbe5a  vmovaps xmm9, [rsp+0x70]
000074c3551dbe60  vpermilpd xmm9, xmm9, 0x00
000074c3551dbe66  vmovaps xmm4, [rsp+0x90]
000074c3551dbe6f  movaps xmm7, xmm4
000074c3551dbe72  mulpd xmm7, xmm9
000074c3551dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000074c3551dbe7c  ptest xmm3, xmm3
000074c3551dbe81  jnz 0x000074C3551DD8A4
000074c3551dbe87  vmovaps xmm9, [rsp+0x50]
000074c3551dbe8d  vpermilpd xmm9, xmm9, 0x00
000074c3551dbe93  movaps xmm4, xmm15
000074c3551dbe97  mulpd xmm4, xmm9
000074c3551dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000074c3551dbea1  ptest xmm3, xmm3
000074c3551dbea6  jnz 0x000074C3551DD9E5
000074c3551dbeac  lea r12, [rax+0xE0]
000074c3551dbeb3  movups xmm15, [r13+r12*1]
000074c3551dbeb9  vmovaps xmm9, [rsp+0x70]
000074c3551dbebf  vpermilpd xmm9, xmm9, 0x00
000074c3551dbec5  vmovaps [rsp+0x70], xmm1
000074c3551dbecb  vmovaps xmm1, [rsp+0x80]
000074c3551dbed4  vmovaps [rsp+0x80], xmm15
000074c3551dbedd  movaps xmm3, xmm1
000074c3551dbee0  mulpd xmm3, xmm9
000074c3551dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000074c3551dbeea  ptest xmm15, xmm15
000074c3551dbef0  jnz 0x000074C3551DDB31
000074c3551dbef6  vmovaps xmm1, [rsp+0xF0]
000074c3551dbeff  vmovaps xmm15, [rsp+0xF0]
000074c3551dbf08  por xmm1, xmm15
000074c3551dbf0d  movaps [r15+0x300], xmm1
000074c3551dbf15  vmovaps xmm15, [rsp+0xE0]
000074c3551dbf1e  vmovaps xmm9, [rsp+0xE0]
000074c3551dbf27  por xmm15, xmm9
000074c3551dbf2c  movaps [r15+0x190], xmm15
000074c3551dbf34  vmovaps xmm9, [rsp+0x50]
000074c3551dbf3a  vpermilpd xmm9, xmm9, 0x00
000074c3551dbf40  vmovaps [rsp+0x90], xmm1
000074c3551dbf49  vmovaps [rsp+0xE0], xmm15
000074c3551dbf52  vmovaps xmm15, [rsp+0x80]
000074c3551dbf5b  vmovaps [rsp+0x80], xmm14
000074c3551dbf64  movaps xmm1, xmm15
000074c3551dbf68  mulpd xmm1, xmm9
000074c3551dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000074c3551dbf72  ptest xmm14, xmm14
000074c3551dbf78  jnz 0x000074C3551DDC72
000074c3551dbf7e  lea r12, [rax+0x90]
000074c3551dbf85  movups xmm15, [r13+r12*1]
000074c3551dbf8b  vmovaps xmm14, [rsp+0xD0]
000074c3551dbf94  vmovaps xmm9, [rsp+0xD0]
000074c3551dbf9d  por xmm14, xmm9
000074c3551dbfa2  movaps [r15+0x1C0], xmm14
000074c3551dbfaa  vmovaps xmm9, [rsp+0xC0]
000074c3551dbfb3  vmovaps [rsp+0xD0], xmm1
000074c3551dbfbc  vmovaps xmm1, [rsp+0xC0]
000074c3551dbfc5  por xmm9, xmm1
000074c3551dbfca  movaps [r15+0x200], xmm9
000074c3551dbfd2  vmovaps [rsp+0xC0], xmm2
000074c3551dbfdb  vmovaps xmm1, [rsp+0xC0]
000074c3551dbfe4  por xmm2, xmm1
000074c3551dbfe8  movaps [r15+0x2D0], xmm2
000074c3551dbff0  vmovaps [rsp+0xC0], xmm8
000074c3551dbff9  vmovaps xmm1, [rsp+0xC0]
000074c3551dc002  por xmm8, xmm1
000074c3551dc007  movaps [r15+0x2E0], xmm8
000074c3551dc00f  vmovaps [rsp+0xC0], xmm15
000074c3551dc018  movaps xmm1, xmm5
000074c3551dc01b  addpd xmm1, xmm7
000074c3551dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000074c3551dc024  ptest xmm15, xmm15
000074c3551dc02a  jnz 0x000074C3551DDDBE
000074c3551dc030  vmovaps xmm15, [rsp+0x50]
000074c3551dc036  vpermilpd xmm15, xmm15, 0x00
000074c3551dc03c  vmovaps xmm5, [rsp+0xC0]
000074c3551dc045  vmovaps [rsp+0xC0], xmm1
000074c3551dc04e  movaps xmm7, xmm5
000074c3551dc051  mulpd xmm7, xmm15
000074c3551dc056  vcmppd xmm1, xmm7, xmm7, 0x03
000074c3551dc05b  ptest xmm1, xmm1
000074c3551dc060  jnz 0x000074C3551DDEFE
000074c3551dc066  lea r12, [rax+0x80]
000074c3551dc06d  movups xmm1, [r13+r12*1]
000074c3551dc073  vmovaps xmm5, [rsp+0x70]
000074c3551dc079  vmovaps [rsp+0x70], xmm1
000074c3551dc07f  movaps xmm15, xmm5
000074c3551dc083  addpd xmm15, xmm3
000074c3551dc088  vcmppd xmm1, xmm15, xmm15, 0x03
000074c3551dc08e  ptest xmm1, xmm1
000074c3551dc093  jnz 0x000074C3551DE049
000074c3551dc099  vmovaps xmm5, [rsp+0x80]
000074c3551dc0a2  movaps xmm1, xmm5
000074c3551dc0a5  addpd xmm1, xmm4
000074c3551dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000074c3551dc0ae  ptest xmm3, xmm3
000074c3551dc0b3  jnz 0x000074C3551DE18B
000074c3551dc0b9  vmovaps [rsp+0x80], xmm10
000074c3551dc0c2  vmovaps xmm5, [rsp+0x80]
000074c3551dc0cb  por xmm10, xmm5
000074c3551dc0d0  movaps [r15+0x2F0], xmm10
000074c3551dc0d8  vmovaps xmm5, [rsp+0x50]
000074c3551dc0de  vpermilpd xmm5, xmm5, 0x00
000074c3551dc0e4  vmovaps xmm3, [rsp+0x70]
000074c3551dc0ea  vmovaps [rsp+0x50], xmm1
000074c3551dc0f0  movaps xmm4, xmm3
000074c3551dc0f3  mulpd xmm4, xmm5
000074c3551dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000074c3551dc0fc  ptest xmm1, xmm1
000074c3551dc101  jnz 0x000074C3551DE2CB
000074c3551dc107  lea r12, [rax+0xD0]
000074c3551dc10e  movups xmm1, [r13+r12*1]
000074c3551dc114  vmovaps xmm3, [rsp+0xD0]
000074c3551dc11d  vmovaps [rsp+0x70], xmm1
000074c3551dc123  movaps xmm5, xmm6
000074c3551dc126  addpd xmm5, xmm3
000074c3551dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000074c3551dc12f  ptest xmm1, xmm1
000074c3551dc134  jnz 0x000074C3551DE415
000074c3551dc13a  vmovaps xmm1, [rsp+0x60]
000074c3551dc140  vpermilpd xmm1, xmm1, 0x00
000074c3551dc146  movaps xmm6, xmm9
000074c3551dc14a  mulpd xmm6, xmm1
000074c3551dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000074c3551dc153  ptest xmm3, xmm3
000074c3551dc158  jnz 0x000074C3551DE555
000074c3551dc15e  movaps [r15+0x260], xmm6
000074c3551dc166  vxorps xmm1, xmm1, xmm1
000074c3551dc16a  vpbroadcastq xmm1, xmm1
000074c3551dc16f  movaps [r15+0x1B0], xmm1
000074c3551dc177  vmovaps xmm1, [rsp+0x60]
000074c3551dc17d  vpermilpd xmm1, xmm1, 0x00
000074c3551dc183  vmovaps xmm3, [rsp+0x70]
000074c3551dc189  vmovaps [rsp+0x70], xmm15
000074c3551dc18f  movaps xmm9, xmm3
000074c3551dc193  mulpd xmm9, xmm1
000074c3551dc198  vcmppd xmm15, xmm9, xmm9, 0x03
000074c3551dc19e  ptest xmm15, xmm15
000074c3551dc1a4  jnz 0x000074C3551DE696
000074c3551dc1aa  lea r12, [rax+0xC0]
000074c3551dc1b1  movups xmm1, [r13+r12*1]
000074c3551dc1b7  vmovaps xmm3, [rsp+0xC0]
000074c3551dc1c0  vmovaps [rsp+0x80], xmm1
000074c3551dc1c9  movaps xmm15, xmm3
000074c3551dc1cd  addpd xmm15, xmm7
000074c3551dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000074c3551dc1d8  ptest xmm1, xmm1
000074c3551dc1dd  jnz 0x000074C3551DE7E2
000074c3551dc1e3  vmovaps [rsp+0xC0], xmm13
000074c3551dc1ec  vmovaps xmm1, [rsp+0xC0]
000074c3551dc1f5  por xmm13, xmm1
000074c3551dc1fa  movaps [r15+0x270], xmm13
000074c3551dc202  vmovaps xmm1, [rsp+0xB0]
000074c3551dc20b  vmovaps xmm7, [rsp+0xB0]
000074c3551dc214  por xmm1, xmm7
000074c3551dc218  movaps [r15+0x1A0], xmm1
000074c3551dc220  vmovaps xmm1, [rsp+0x60]
000074c3551dc226  vpermilpd xmm1, xmm1, 0x00
000074c3551dc22c  vmovaps [rsp+0xB0], xmm1
000074c3551dc235  vmovaps xmm1, [rsp+0x80]
000074c3551dc23e  vmovaps [rsp+0x80], xmm15
000074c3551dc247  vmovaps xmm15, [rsp+0xB0]
000074c3551dc250  vmovaps [rsp+0xB0], xmm14
000074c3551dc259  movaps xmm3, xmm1
000074c3551dc25c  mulpd xmm3, xmm15
000074c3551dc261  vcmppd xmm14, xmm3, xmm3, 0x03
000074c3551dc266  ptest xmm14, xmm14
000074c3551dc26c  jnz 0x000074C3551DE924
000074c3551dc272  lea r12, [rax+0x20]
000074c3551dc276  movups xmm1, [r13+r12*1]
000074c3551dc27c  movaps [r15+0x110], xmm1
000074c3551dc284  vmovaps xmm14, [rsp+0x70]
000074c3551dc28a  vmovaps [rsp+0x70], xmm1
000074c3551dc290  movaps xmm15, xmm14
000074c3551dc294  addpd xmm15, xmm4
000074c3551dc299  vcmppd xmm1, xmm15, xmm15, 0x03
000074c3551dc29f  ptest xmm1, xmm1
000074c3551dc2a4  jnz 0x000074C3551DEA6F
000074c3551dc2aa  vmovaps xmm1, [rsp+0x60]
000074c3551dc2b0  vpermilpd xmm1, xmm1, 0x00
000074c3551dc2b6  movaps xmm14, xmm2
000074c3551dc2ba  mulpd xmm14, xmm1
000074c3551dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000074c3551dc2c5  ptest xmm4, xmm4
000074c3551dc2ca  jnz 0x000074C3551DEBB2
000074c3551dc2d0  vmovaps xmm4, [rsp+0x50]
000074c3551dc2d6  movaps xmm1, xmm4
000074c3551dc2d9  addpd xmm1, xmm9
000074c3551dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000074c3551dc2e3  ptest xmm2, xmm2
000074c3551dc2e8  jnz 0x000074C3551DECF4
000074c3551dc2ee  vmovaps xmm9, [rsp+0x30]
000074c3551dc2f4  vpermilpd xmm9, xmm9, 0x00
000074c3551dc2fa  vmovaps xmm2, [rsp+0x70]
000074c3551dc300  vmovaps [rsp+0x50], xmm1
000074c3551dc306  movaps xmm4, xmm2
000074c3551dc309  mulpd xmm4, xmm9
000074c3551dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000074c3551dc313  ptest xmm1, xmm1
000074c3551dc318  jnz 0x000074C3551DEE35
000074c3551dc31e  vmovaps xmm1, [rsp+0x30]
000074c3551dc324  vpermilpd xmm1, xmm1, 0x00
000074c3551dc32a  vmovaps xmm2, [rsp+0x90]
000074c3551dc333  vmovaps [rsp+0x60], xmm15
000074c3551dc339  movaps xmm9, xmm2
000074c3551dc33d  mulpd xmm9, xmm1
000074c3551dc342  vcmppd xmm15, xmm9, xmm9, 0x03
000074c3551dc348  ptest xmm15, xmm15
000074c3551dc34e  jnz 0x000074C3551DEF76
000074c3551dc354  vmovaps xmm15, [rsp+0x80]
000074c3551dc35d  movaps xmm1, xmm15
000074c3551dc361  addpd xmm1, xmm6
000074c3551dc365  vcmppd xmm2, xmm1, xmm1, 0x03
000074c3551dc36a  ptest xmm2, xmm2
000074c3551dc36f  jnz 0x000074C3551DF0B8
000074c3551dc375  movaps xmm15, xmm5
000074c3551dc379  addpd xmm15, xmm3
000074c3551dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000074c3551dc384  ptest xmm6, xmm6
000074c3551dc389  jnz 0x000074C3551DF1F9
000074c3551dc38f  vmovaps xmm6, [rsp+0x30]
000074c3551dc395  vpermilpd xmm6, xmm6, 0x00
000074c3551dc39b  movaps xmm5, xmm8
000074c3551dc39f  mulpd xmm5, xmm6
000074c3551dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000074c3551dc3a8  ptest xmm3, xmm3
000074c3551dc3ad  jnz 0x000074C3551DF33B
000074c3551dc3b3  vmovaps xmm8, [rsp+0x30]
000074c3551dc3b9  vpermilpd xmm8, xmm8, 0x00
000074c3551dc3bf  movaps xmm6, xmm10
000074c3551dc3c3  mulpd xmm6, xmm8
000074c3551dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000074c3551dc3cd  ptest xmm3, xmm3
000074c3551dc3d2  jnz 0x000074C3551DF47C
000074c3551dc3d8  vmovaps xmm8, [rsp+0x60]
000074c3551dc3de  movaps xmm10, xmm8
000074c3551dc3e2  addpd xmm10, xmm14
000074c3551dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000074c3551dc3ed  ptest xmm3, xmm3
000074c3551dc3f2  jnz 0x000074C3551DF5BE
000074c3551dc3f8  vmovaps xmm8, [rsp+0x50]
000074c3551dc3fe  movaps xmm14, xmm8
000074c3551dc402  addpd xmm14, xmm4
000074c3551dc407  vcmppd xmm3, xmm14, xmm14, 0x03
000074c3551dc40d  ptest xmm3, xmm3
000074c3551dc412  jnz 0x000074C3551DF702
000074c3551dc418  vmovaps xmm8, [rsp+0x40]
000074c3551dc41e  vpermilpd xmm8, xmm8, 0x00
000074c3551dc424  movaps xmm4, xmm13
000074c3551dc428  mulpd xmm4, xmm8
000074c3551dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000074c3551dc432  ptest xmm3, xmm3
000074c3551dc437  jnz 0x000074C3551DF845
000074c3551dc43d  movaps xmm13, xmm15
000074c3551dc441  addpd xmm13, xmm9
000074c3551dc446  vcmppd xmm8, xmm13, xmm13, 0x03
000074c3551dc44c  ptest xmm8, xmm8
000074c3551dc452  jnz 0x000074C3551DF987
000074c3551dc458  movaps xmm15, xmm1
000074c3551dc45c  addpd xmm15, xmm5
000074c3551dc461  vcmppd xmm9, xmm15, xmm15, 0x03
000074c3551dc467  ptest xmm9, xmm9
000074c3551dc46d  jnz 0x000074C3551DFACB
000074c3551dc473  vmovaps [rsp+0x30], xmm11
000074c3551dc479  vmovaps xmm1, [rsp+0x30]
000074c3551dc47f  por xmm11, xmm1
000074c3551dc484  movaps [r15+0x250], xmm11
000074c3551dc48c  vmovaps [rsp+0x30], xmm12
000074c3551dc492  vmovaps xmm1, [rsp+0x30]
000074c3551dc498  por xmm12, xmm1
000074c3551dc49d  movaps [r15+0x2A0], xmm12
000074c3551dc4a5  vmovaps xmm1, [rsp+0xA0]
000074c3551dc4ae  vmovaps xmm11, [rsp+0xA0]
000074c3551dc4b7  por xmm1, xmm11
000074c3551dc4bc  movaps [r15+0x1D0], xmm1
000074c3551dc4c4  lea r12, [rax+0x40]
000074c3551dc4c8  movups xmm1, [r13+r12*1]
000074c3551dc4ce  movaps [r15+0x2C0], xmm1
000074c3551dc4d6  vmovaps xmm11, [rsp+0x40]
000074c3551dc4dc  vpermilpd xmm11, xmm11, 0x00
000074c3551dc4e2  vmovaps xmm8, [rsp+0xE0]
000074c3551dc4eb  movaps xmm9, xmm8
000074c3551dc4ef  mulpd xmm9, xmm11
000074c3551dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000074c3551dc4fa  ptest xmm5, xmm5
000074c3551dc4ff  jnz 0x000074C3551DFC17
000074c3551dc505  movaps xmm11, xmm10
000074c3551dc509  addpd xmm11, xmm6
000074c3551dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000074c3551dc514  ptest xmm8, xmm8
000074c3551dc51a  jnz 0x000074C3551DFD5B
000074c3551dc520  movaps xmm10, xmm14
000074c3551dc524  addpd xmm10, xmm4
000074c3551dc529  vcmppd xmm8, xmm10, xmm10, 0x03
000074c3551dc52f  ptest xmm8, xmm8
000074c3551dc535  jnz 0x000074C3551DFE9E
000074c3551dc53b  vmovaps xmm14, [rsp+0x40]
000074c3551dc541  vpermilpd xmm14, xmm14, 0x00
000074c3551dc547  movaps xmm8, xmm1
000074c3551dc54b  mulpd xmm8, xmm14
000074c3551dc550  vcmppd xmm6, xmm8, xmm8, 0x03
000074c3551dc556  ptest xmm6, xmm6
000074c3551dc55b  jnz 0x000074C3551DFFE1
000074c3551dc561  movaps xmm1, [r15+0x2B0]
000074c3551dc569  vmovaps xmm14, [rsp+0x40]
000074c3551dc56f  vpermilpd xmm14, xmm14, 0x00
000074c3551dc575  movaps xmm6, xmm1
000074c3551dc578  mulpd xmm6, xmm14
000074c3551dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000074c3551dc582  ptest xmm5, xmm5
000074c3551dc587  jnz 0x000074C3551E0124
000074c3551dc58d  vmovaps xmm1, [rsp+0x10]
000074c3551dc593  vpermilpd xmm1, xmm1, 0x00
000074c3551dc599  movaps xmm14, xmm12
000074c3551dc59d  mulpd xmm14, xmm1
000074c3551dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000074c3551dc5a8  ptest xmm5, xmm5
000074c3551dc5ad  jnz 0x000074C3551E0265
000074c3551dc5b3  movaps xmm1, xmm13
000074c3551dc5b7  addpd xmm1, xmm9
000074c3551dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000074c3551dc5c1  ptest xmm12, xmm12
000074c3551dc5c7  jnz 0x000074C3551E03A8
000074c3551dc5cd  vmovaps xmm13, [rsp+0x10]
000074c3551dc5d3  vpermilpd xmm13, xmm13, 0x00
000074c3551dc5d9  movaps xmm12, xmm7
000074c3551dc5dd  mulpd xmm12, xmm13
000074c3551dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000074c3551dc5e8  ptest xmm9, xmm9
000074c3551dc5ee  jnz 0x000074C3551E04EA
000074c3551dc5f4  movaps xmm13, xmm15
000074c3551dc5f8  addpd xmm13, xmm8
000074c3551dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000074c3551dc603  ptest xmm9, xmm9
000074c3551dc609  jnz 0x000074C3551E062D
000074c3551dc60f  movaps xmm15, [r15+0x290]
000074c3551dc617  vmovaps xmm9, [rsp+0x10]
000074c3551dc61d  vpermilpd xmm9, xmm9, 0x00
000074c3551dc623  movaps xmm8, xmm15
000074c3551dc627  mulpd xmm8, xmm9
000074c3551dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000074c3551dc632  ptest xmm7, xmm7
000074c3551dc637  jnz 0x000074C3551E0771
000074c3551dc63d  movaps xmm15, xmm11
000074c3551dc641  addpd xmm15, xmm6
000074c3551dc646  vcmppd xmm9, xmm15, xmm15, 0x03
000074c3551dc64c  ptest xmm9, xmm9
000074c3551dc652  jnz 0x000074C3551E08B5
000074c3551dc658  movaps xmm11, [r15+0x1E0]
000074c3551dc660  vmovaps xmm9, [rsp+0x10]
000074c3551dc666  vpermilpd xmm9, xmm9, 0x00
000074c3551dc66c  movaps xmm7, xmm11
000074c3551dc670  mulpd xmm7, xmm9
000074c3551dc675  vcmppd xmm6, xmm7, xmm7, 0x03
000074c3551dc67a  ptest xmm6, xmm6
000074c3551dc67f  jnz 0x000074C3551E09F8
000074c3551dc685  movaps xmm11, xmm10
000074c3551dc689  addpd xmm11, xmm14
000074c3551dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000074c3551dc694  ptest xmm9, xmm9
000074c3551dc69a  jnz 0x000074C3551E0B3A
000074c3551dc6a0  lea r12, [rax+0x70]
000074c3551dc6a4  movups xmm14, [r13+r12*1]
000074c3551dc6aa  movaps [r15+0x240], xmm14
000074c3551dc6b2  movaps xmm10, xmm1
000074c3551dc6b6  addpd xmm10, xmm12
000074c3551dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000074c3551dc6c1  ptest xmm9, xmm9
000074c3551dc6c7  jnz 0x000074C3551E0C88
000074c3551dc6cd  movaps [r15+0x170], xmm10
000074c3551dc6d5  vmovaps xmm1, [rsp+0x20]
000074c3551dc6db  vpermilpd xmm1, xmm1, 0x00
000074c3551dc6e1  movaps xmm12, xmm14
000074c3551dc6e5  mulpd xmm12, xmm1
000074c3551dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000074c3551dc6f0  ptest xmm9, xmm9
000074c3551dc6f6  jnz 0x000074C3551E0DCB
000074c3551dc6fc  vmovaps xmm1, [rsp+0x20]
000074c3551dc702  vpermilpd xmm1, xmm1, 0x00
000074c3551dc708  vmovaps xmm9, [rsp+0xB0]
000074c3551dc711  movaps xmm14, xmm9
000074c3551dc715  mulpd xmm14, xmm1
000074c3551dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000074c3551dc720  ptest xmm6, xmm6
000074c3551dc725  jnz 0x000074C3551E0F0E
000074c3551dc72b  movaps [r15+0x180], xmm14
000074c3551dc733  movaps xmm1, xmm13
000074c3551dc737  addpd xmm1, xmm8
000074c3551dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000074c3551dc741  ptest xmm9, xmm9
000074c3551dc747  jnz 0x000074C3551E1051
000074c3551dc74d  movaps [r15+0x210], xmm1
000074c3551dc755  movups xmm13, [r13+rax*1]
000074c3551dc75b  lea r12, [rax+0x10]
000074c3551dc75f  movups xmm9, [r13+r12*1]
000074c3551dc765  movaps [r15+0x230], xmm9
000074c3551dc76d  movaps xmm8, xmm15
000074c3551dc771  addpd xmm8, xmm7
000074c3551dc776  vcmppd xmm6, xmm8, xmm8, 0x03
000074c3551dc77c  ptest xmm6, xmm6
000074c3551dc781  jnz 0x000074C3551E11A7
000074c3551dc787  movaps [r15+0x130], xmm8
000074c3551dc78f  vmovaps xmm15, [rsp+0x20]
000074c3551dc795  vpermilpd xmm15, xmm15, 0x00
000074c3551dc79b  movaps xmm7, xmm9
000074c3551dc79f  mulpd xmm7, xmm15
000074c3551dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000074c3551dc7a9  ptest xmm6, xmm6
000074c3551dc7ae  jnz 0x000074C3551E12EA
000074c3551dc7b4  movaps [r15+0x220], xmm7
000074c3551dc7bc  vmovaps xmm15, [rsp+0x20]
000074c3551dc7c2  vpermilpd xmm15, xmm15, 0x00
000074c3551dc7c8  movaps xmm9, xmm13
000074c3551dc7cc  mulpd xmm9, xmm15
000074c3551dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000074c3551dc7d7  ptest xmm6, xmm6
000074c3551dc7dc  jnz 0x000074C3551E142C
000074c3551dc7e2  movaps xmm15, xmm11
000074c3551dc7e6  addpd xmm15, xmm12
000074c3551dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000074c3551dc7f1  ptest xmm13, xmm13
000074c3551dc7f7  jnz 0x000074C3551E1570
000074c3551dc7fd  movaps [r15+0x140], xmm15
000074c3551dc805  movaps xmm13, xmm10
000074c3551dc809  addpd xmm13, xmm14
000074c3551dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000074c3551dc814  ptest xmm12, xmm12
000074c3551dc81a  jnz 0x000074C3551E16B4
000074c3551dc820  movaps [r15+0x150], xmm13
000074c3551dc828  movaps xmm14, xmm1
000074c3551dc82c  addpd xmm14, xmm7
000074c3551dc831  vcmppd xmm12, xmm14, xmm14, 0x03
000074c3551dc837  ptest xmm12, xmm12
000074c3551dc83d  jnz 0x000074C3551E17F8
000074c3551dc843  movaps [r15+0x160], xmm14
000074c3551dc84b  movaps xmm1, xmm8
000074c3551dc84f  addpd xmm1, xmm9
000074c3551dc854  vcmppd xmm12, xmm1, xmm1, 0x03
000074c3551dc859  ptest xmm12, xmm12
000074c3551dc85f  jnz 0x000074C3551E193A
000074c3551dc865  movaps [r15+0x120], xmm1
000074c3551dc86d  movups [r13+r14*1], xmm15
000074c3551dc873  lea rax, [r14+0x10]
000074c3551dc877  movups [r13+rax*1], xmm13
000074c3551dc87d  lea rax, [r14+0x20]
000074c3551dc881  movups [r13+rax*1], xmm14
000074c3551dc887  lea rax, [r14+0x30]
000074c3551dc88b  movups [r13+rax*1], xmm1
000074c3551dc891  mov eax, [r15+0x108]
000074c3551dc898  sahf
000074c3551dc899  jnz 0x000074C3551DC8CB
000074c3551dc89b  cmp dword ptr [r15+0x318], 0x00
000074c3551dc8a3  jz 0x000074C3551DB900
000074c3551dc8a9  nop [rax+rax*1], ax
000074c3551dc8b2  nop [rax+rax*1], eax
000074c3551dc8ba  mov eax, 0x410444
000074c3551dc8bf  mov [r15+0x100], rax
000074c3551dc8c6  jmp 0x000074C354FFE110
000074c3551dc8cb  cmp dword ptr [r15+0x318], 0x00
000074c3551dc8d3  jz 0x000074C3551D57E0
000074c3551dc8d9  nop [rax+rax*1], ax
000074c3551dc8e2  nop [rax+rax*1], eax
000074c3551dc8ea  mov eax, 0x410278
000074c3551dc8ef  mov [r15+0x100], rax
000074c3551dc8f6  jmp 0x000074C354FFE110
000074c3551dc8fb  int3
000074c3551dc8fc  call 0x000074C3550E27E0
000074c3551dc901  jmp 0x000074C3551DB9DF
000074c3551dc906  call 0x000074C3550E1570
000074c3551dc90b  jmp 0x000074C3551DB9E8
000074c3551dc910  call 0x000074C3550E27E0
000074c3551dc915  jmp 0x000074C3551DBA44
000074c3551dc91a  call 0x000074C3550E1570
000074c3551dc91f  jmp 0x000074C3551DBA4D
000074c3551dc924  call 0x000074C3550E27E0
000074c3551dc929  jmp 0x000074C3551DBA90
000074c3551dc92e  call 0x000074C3550E1570
000074c3551dc933  jmp 0x000074C3551DBA99
000074c3551dc938  call 0x000074C35500DC20
000074c3551dc93d  jmp 0x000074C3551DBAD8
000074c3551dc942  call 0x000074C3550D59C0
000074c3551dc947  jmp 0x000074C3551DBAEB
000074c3551dc94c  call 0x000074C3550E0E30
000074c3551dc951  jmp 0x000074C3551DBB09
000074c3551dc956  call 0x000074C3550DFBC0
000074c3551dc95b  jmp 0x000074C3551DBB13
000074c3551dc960  call 0x000074C3550DE950
000074c3551dc965  jmp 0x000074C3551DBB1D
000074c3551dc96a  sub rsp, 0x08
000074c3551dc96e  push rax
000074c3551dc96f  push rcx
000074c3551dc970  push rdx
000074c3551dc971  push rdi
000074c3551dc972  push rsi
000074c3551dc973  push r8
000074c3551dc975  push r9
000074c3551dc977  push r10
000074c3551dc979  push r11
000074c3551dc97b  sub rsp, 0xF0
000074c3551dc982  vmovaps [rsp], xmm0
000074c3551dc987  vmovaps [rsp+0x10], xmm1
000074c3551dc98d  vmovaps [rsp+0x20], xmm2
000074c3551dc993  vmovaps [rsp+0x30], xmm3
000074c3551dc999  vmovaps [rsp+0x40], xmm4
000074c3551dc99f  vmovaps [rsp+0x50], xmm5
000074c3551dc9a5  vmovaps [rsp+0x60], xmm6
000074c3551dc9ab  vmovaps [rsp+0x70], xmm7
000074c3551dc9b1  vmovaps [rsp+0x80], xmm9
000074c3551dc9ba  vmovaps [rsp+0x90], xmm10
000074c3551dc9c3  vmovaps [rsp+0xA0], xmm11
000074c3551dc9cc  vmovaps [rsp+0xB0], xmm12
000074c3551dc9d5  vmovaps [rsp+0xC0], xmm13
000074c3551dc9de  vmovaps [rsp+0xD0], xmm14
000074c3551dc9e7  vmovaps [rsp+0xE0], xmm15
000074c3551dc9f0  sub rsp, 0x30
000074c3551dc9f4  movaps [rsp], xmm8
000074c3551dc9f9  movaps [rsp+0x10], xmm12
000074c3551dc9ff  movaps [rsp+0x20], xmm15
000074c3551dca05  lea rdi, [rsp]
000074c3551dca09  mov esi, 0x00
000074c3551dca0e  mov rax, 0x5F9407FA9530
000074c3551dca18  call rax
000074c3551dca1a  movaps xmm8, [rsp]
000074c3551dca1f  add rsp, 0x30
000074c3551dca23  vmovaps xmm0, [rsp]
000074c3551dca28  vmovaps xmm1, [rsp+0x10]
000074c3551dca2e  vmovaps xmm2, [rsp+0x20]
000074c3551dca34  vmovaps xmm3, [rsp+0x30]
000074c3551dca3a  vmovaps xmm4, [rsp+0x40]
000074c3551dca40  vmovaps xmm5, [rsp+0x50]
000074c3551dca46  vmovaps xmm6, [rsp+0x60]
000074c3551dca4c  vmovaps xmm7, [rsp+0x70]
000074c3551dca52  vmovaps xmm9, [rsp+0x80]
000074c3551dca5b  vmovaps xmm10, [rsp+0x90]
000074c3551dca64  vmovaps xmm11, [rsp+0xA0]
000074c3551dca6d  vmovaps xmm12, [rsp+0xB0]
000074c3551dca76  vmovaps xmm13, [rsp+0xC0]
000074c3551dca7f  vmovaps xmm14, [rsp+0xD0]
000074c3551dca88  vmovaps xmm15, [rsp+0xE0]
000074c3551dca91  add rsp, 0xF0
000074c3551dca98  pop r11
000074c3551dca9a  pop r10
000074c3551dca9c  pop r9
000074c3551dca9e  pop r8
000074c3551dcaa0  pop rsi
000074c3551dcaa1  pop rdi
000074c3551dcaa2  pop rdx
000074c3551dcaa3  pop rcx
000074c3551dcaa4  pop rax
000074c3551dcaa5  add rsp, 0x08
000074c3551dcaa9  jmp 0x000074C3551DBB47
000074c3551dcaae  sub rsp, 0x08
000074c3551dcab2  push rax
000074c3551dcab3  push rcx
000074c3551dcab4  push rdx
000074c3551dcab5  push rdi
000074c3551dcab6  push rsi
000074c3551dcab7  push r8
000074c3551dcab9  push r9
000074c3551dcabb  push r10
000074c3551dcabd  push r11
000074c3551dcabf  sub rsp, 0xF0
000074c3551dcac6  vmovaps [rsp], xmm0
000074c3551dcacb  vmovaps [rsp+0x10], xmm1
000074c3551dcad1  vmovaps [rsp+0x20], xmm2
000074c3551dcad7  vmovaps [rsp+0x30], xmm3
000074c3551dcadd  vmovaps [rsp+0x40], xmm4
000074c3551dcae3  vmovaps [rsp+0x50], xmm5
000074c3551dcae9  vmovaps [rsp+0x60], xmm6
000074c3551dcaef  vmovaps [rsp+0x70], xmm8
000074c3551dcaf5  vmovaps [rsp+0x80], xmm9
000074c3551dcafe  vmovaps [rsp+0x90], xmm10
000074c3551dcb07  vmovaps [rsp+0xA0], xmm11
000074c3551dcb10  vmovaps [rsp+0xB0], xmm12
000074c3551dcb19  vmovaps [rsp+0xC0], xmm13
000074c3551dcb22  vmovaps [rsp+0xD0], xmm14
000074c3551dcb2b  vmovaps [rsp+0xE0], xmm15
000074c3551dcb34  sub rsp, 0x30
000074c3551dcb38  movaps [rsp], xmm7
000074c3551dcb3c  movaps [rsp+0x10], xmm9
000074c3551dcb42  movaps [rsp+0x20], xmm15
000074c3551dcb48  lea rdi, [rsp]
000074c3551dcb4c  mov esi, 0x00
000074c3551dcb51  mov rax, 0x5F9407FA9530
000074c3551dcb5b  call rax
000074c3551dcb5d  movaps xmm7, [rsp]
000074c3551dcb61  add rsp, 0x30
000074c3551dcb65  vmovaps xmm0, [rsp]
000074c3551dcb6a  vmovaps xmm1, [rsp+0x10]
000074c3551dcb70  vmovaps xmm2, [rsp+0x20]
000074c3551dcb76  vmovaps xmm3, [rsp+0x30]
000074c3551dcb7c  vmovaps xmm4, [rsp+0x40]
000074c3551dcb82  vmovaps xmm5, [rsp+0x50]
000074c3551dcb88  vmovaps xmm6, [rsp+0x60]
000074c3551dcb8e  vmovaps xmm8, [rsp+0x70]
000074c3551dcb94  vmovaps xmm9, [rsp+0x80]
000074c3551dcb9d  vmovaps xmm10, [rsp+0x90]
000074c3551dcba6  vmovaps xmm11, [rsp+0xA0]
000074c3551dcbaf  vmovaps xmm12, [rsp+0xB0]
000074c3551dcbb8  vmovaps xmm13, [rsp+0xC0]
000074c3551dcbc1  vmovaps xmm14, [rsp+0xD0]
000074c3551dcbca  vmovaps xmm15, [rsp+0xE0]
000074c3551dcbd3  add rsp, 0xF0
000074c3551dcbda  pop r11
000074c3551dcbdc  pop r10
000074c3551dcbde  pop r9
000074c3551dcbe0  pop r8
000074c3551dcbe2  pop rsi
000074c3551dcbe3  pop rdi
000074c3551dcbe4  pop rdx
000074c3551dcbe5  pop rcx
000074c3551dcbe6  pop rax
000074c3551dcbe7  add rsp, 0x08
000074c3551dcbeb  jmp 0x000074C3551DBB75
000074c3551dcbf0  sub rsp, 0x08
000074c3551dcbf4  push rax
000074c3551dcbf5  push rcx
000074c3551dcbf6  push rdx
000074c3551dcbf7  push rdi
000074c3551dcbf8  push rsi
000074c3551dcbf9  push r8
000074c3551dcbfb  push r9
000074c3551dcbfd  push r10
000074c3551dcbff  push r11
000074c3551dcc01  sub rsp, 0xF0
000074c3551dcc08  vmovaps [rsp], xmm0
000074c3551dcc0d  vmovaps [rsp+0x10], xmm1
000074c3551dcc13  vmovaps [rsp+0x20], xmm2
000074c3551dcc19  vmovaps [rsp+0x30], xmm3
000074c3551dcc1f  vmovaps [rsp+0x40], xmm4
000074c3551dcc25  vmovaps [rsp+0x50], xmm5
000074c3551dcc2b  vmovaps [rsp+0x60], xmm6
000074c3551dcc31  vmovaps [rsp+0x70], xmm7
000074c3551dcc37  vmovaps [rsp+0x80], xmm8
000074c3551dcc40  vmovaps [rsp+0x90], xmm10
000074c3551dcc49  vmovaps [rsp+0xA0], xmm11
000074c3551dcc52  vmovaps [rsp+0xB0], xmm12
000074c3551dcc5b  vmovaps [rsp+0xC0], xmm13
000074c3551dcc64  vmovaps [rsp+0xD0], xmm14
000074c3551dcc6d  vmovaps [rsp+0xE0], xmm15
000074c3551dcc76  sub rsp, 0x30
000074c3551dcc7a  movaps [rsp], xmm9
000074c3551dcc7f  movaps [rsp+0x10], xmm12
000074c3551dcc85  movaps [rsp+0x20], xmm10
000074c3551dcc8b  lea rdi, [rsp]
000074c3551dcc8f  mov esi, 0x00
000074c3551dcc94  mov rax, 0x5F9407FA9530
000074c3551dcc9e  call rax
000074c3551dcca0  movaps xmm9, [rsp]
000074c3551dcca5  add rsp, 0x30
000074c3551dcca9  vmovaps xmm0, [rsp]
000074c3551dccae  vmovaps xmm1, [rsp+0x10]
000074c3551dccb4  vmovaps xmm2, [rsp+0x20]
000074c3551dccba  vmovaps xmm3, [rsp+0x30]
000074c3551dccc0  vmovaps xmm4, [rsp+0x40]
000074c3551dccc6  vmovaps xmm5, [rsp+0x50]
000074c3551dcccc  vmovaps xmm6, [rsp+0x60]
000074c3551dccd2  vmovaps xmm7, [rsp+0x70]
000074c3551dccd8  vmovaps xmm8, [rsp+0x80]
000074c3551dcce1  vmovaps xmm10, [rsp+0x90]
000074c3551dccea  vmovaps xmm11, [rsp+0xA0]
000074c3551dccf3  vmovaps xmm12, [rsp+0xB0]
000074c3551dccfc  vmovaps xmm13, [rsp+0xC0]
000074c3551dcd05  vmovaps xmm14, [rsp+0xD0]
000074c3551dcd0e  vmovaps xmm15, [rsp+0xE0]
000074c3551dcd17  add rsp, 0xF0
000074c3551dcd1e  pop r11
000074c3551dcd20  pop r10
000074c3551dcd22  pop r9
000074c3551dcd24  pop r8
000074c3551dcd26  pop rsi
000074c3551dcd27  pop rdi
000074c3551dcd28  pop rdx
000074c3551dcd29  pop rcx
000074c3551dcd2a  pop rax
000074c3551dcd2b  add rsp, 0x08
000074c3551dcd2f  jmp 0x000074C3551DBB99
000074c3551dcd34  sub rsp, 0x08
000074c3551dcd38  push rax
000074c3551dcd39  push rcx
000074c3551dcd3a  push rdx
000074c3551dcd3b  push rdi
000074c3551dcd3c  push rsi
000074c3551dcd3d  push r8
000074c3551dcd3f  push r9
000074c3551dcd41  push r10
000074c3551dcd43  push r11
000074c3551dcd45  sub rsp, 0xF0
000074c3551dcd4c  vmovaps [rsp], xmm0
000074c3551dcd51  vmovaps [rsp+0x10], xmm1
000074c3551dcd57  vmovaps [rsp+0x20], xmm2
000074c3551dcd5d  vmovaps [rsp+0x30], xmm3
000074c3551dcd63  vmovaps [rsp+0x40], xmm4
000074c3551dcd69  vmovaps [rsp+0x50], xmm5
000074c3551dcd6f  vmovaps [rsp+0x60], xmm6
000074c3551dcd75  vmovaps [rsp+0x70], xmm7
000074c3551dcd7b  vmovaps [rsp+0x80], xmm8
000074c3551dcd84  vmovaps [rsp+0x90], xmm9
000074c3551dcd8d  vmovaps [rsp+0xA0], xmm11
000074c3551dcd96  vmovaps [rsp+0xB0], xmm12
000074c3551dcd9f  vmovaps [rsp+0xC0], xmm13
000074c3551dcda8  vmovaps [rsp+0xD0], xmm14
000074c3551dcdb1  vmovaps [rsp+0xE0], xmm15
000074c3551dcdba  sub rsp, 0x30
000074c3551dcdbe  movaps [rsp], xmm10
000074c3551dcdc3  movaps [rsp+0x10], xmm12
000074c3551dcdc9  movaps [rsp+0x20], xmm11
000074c3551dcdcf  lea rdi, [rsp]
000074c3551dcdd3  mov esi, 0x00
000074c3551dcdd8  mov rax, 0x5F9407FA9530
000074c3551dcde2  call rax
000074c3551dcde4  movaps xmm10, [rsp]
000074c3551dcde9  add rsp, 0x30
000074c3551dcded  vmovaps xmm0, [rsp]
000074c3551dcdf2  vmovaps xmm1, [rsp+0x10]
000074c3551dcdf8  vmovaps xmm2, [rsp+0x20]
000074c3551dcdfe  vmovaps xmm3, [rsp+0x30]
000074c3551dce04  vmovaps xmm4, [rsp+0x40]
000074c3551dce0a  vmovaps xmm5, [rsp+0x50]
000074c3551dce10  vmovaps xmm6, [rsp+0x60]
000074c3551dce16  vmovaps xmm7, [rsp+0x70]
000074c3551dce1c  vmovaps xmm8, [rsp+0x80]
000074c3551dce25  vmovaps xmm9, [rsp+0x90]
000074c3551dce2e  vmovaps xmm11, [rsp+0xA0]
000074c3551dce37  vmovaps xmm12, [rsp+0xB0]
000074c3551dce40  vmovaps xmm13, [rsp+0xC0]
000074c3551dce49  vmovaps xmm14, [rsp+0xD0]
000074c3551dce52  vmovaps xmm15, [rsp+0xE0]
000074c3551dce5b  add rsp, 0xF0
000074c3551dce62  pop r11
000074c3551dce64  pop r10
000074c3551dce66  pop r9
000074c3551dce68  pop r8
000074c3551dce6a  pop rsi
000074c3551dce6b  pop rdi
000074c3551dce6c  pop rdx
000074c3551dce6d  pop rcx
000074c3551dce6e  pop rax
000074c3551dce6f  add rsp, 0x08
000074c3551dce73  jmp 0x000074C3551DBBB3
000074c3551dce78  sub rsp, 0x08
000074c3551dce7c  push rax
000074c3551dce7d  push rcx
000074c3551dce7e  push rdx
000074c3551dce7f  push rdi
000074c3551dce80  push rsi
000074c3551dce81  push r8
000074c3551dce83  push r9
000074c3551dce85  push r10
000074c3551dce87  push r11
000074c3551dce89  sub rsp, 0xF0
000074c3551dce90  vmovaps [rsp], xmm0
000074c3551dce95  vmovaps [rsp+0x10], xmm1
000074c3551dce9b  vmovaps [rsp+0x20], xmm2
000074c3551dcea1  vmovaps [rsp+0x30], xmm3
000074c3551dcea7  vmovaps [rsp+0x40], xmm4
000074c3551dcead  vmovaps [rsp+0x50], xmm5
000074c3551dceb3  vmovaps [rsp+0x60], xmm7
000074c3551dceb9  vmovaps [rsp+0x70], xmm8
000074c3551dcebf  vmovaps [rsp+0x80], xmm9
000074c3551dcec8  vmovaps [rsp+0x90], xmm10
000074c3551dced1  vmovaps [rsp+0xA0], xmm11
000074c3551dceda  vmovaps [rsp+0xB0], xmm12
000074c3551dcee3  vmovaps [rsp+0xC0], xmm13
000074c3551dceec  vmovaps [rsp+0xD0], xmm14
000074c3551dcef5  vmovaps [rsp+0xE0], xmm15
000074c3551dcefe  sub rsp, 0x30
000074c3551dcf02  movaps [rsp], xmm6
000074c3551dcf06  movaps [rsp+0x10], xmm12
000074c3551dcf0c  movaps [rsp+0x20], xmm11
000074c3551dcf12  lea rdi, [rsp]
000074c3551dcf16  mov esi, 0x00
000074c3551dcf1b  mov rax, 0x5F9407FA9530
000074c3551dcf25  call rax
000074c3551dcf27  movaps xmm6, [rsp]
000074c3551dcf2b  add rsp, 0x30
000074c3551dcf2f  vmovaps xmm0, [rsp]
000074c3551dcf34  vmovaps xmm1, [rsp+0x10]
000074c3551dcf3a  vmovaps xmm2, [rsp+0x20]
000074c3551dcf40  vmovaps xmm3, [rsp+0x30]
000074c3551dcf46  vmovaps xmm4, [rsp+0x40]
000074c3551dcf4c  vmovaps xmm5, [rsp+0x50]
000074c3551dcf52  vmovaps xmm7, [rsp+0x60]
000074c3551dcf58  vmovaps xmm8, [rsp+0x70]
000074c3551dcf5e  vmovaps xmm9, [rsp+0x80]
000074c3551dcf67  vmovaps xmm10, [rsp+0x90]
000074c3551dcf70  vmovaps xmm11, [rsp+0xA0]
000074c3551dcf79  vmovaps xmm12, [rsp+0xB0]
000074c3551dcf82  vmovaps xmm13, [rsp+0xC0]
000074c3551dcf8b  vmovaps xmm14, [rsp+0xD0]
000074c3551dcf94  vmovaps xmm15, [rsp+0xE0]
000074c3551dcf9d  add rsp, 0xF0
000074c3551dcfa4  pop r11
000074c3551dcfa6  pop r10
000074c3551dcfa8  pop r9
000074c3551dcfaa  pop r8
000074c3551dcfac  pop rsi
000074c3551dcfad  pop rdi
000074c3551dcfae  pop rdx
000074c3551dcfaf  pop rcx
000074c3551dcfb0  pop rax
000074c3551dcfb1  add rsp, 0x08
000074c3551dcfb5  jmp 0x000074C3551DBBD4
000074c3551dcfba  sub rsp, 0x08
000074c3551dcfbe  push rax
000074c3551dcfbf  push rcx
000074c3551dcfc0  push rdx
000074c3551dcfc1  push rdi
000074c3551dcfc2  push rsi
000074c3551dcfc3  push r8
000074c3551dcfc5  push r9
000074c3551dcfc7  push r10
000074c3551dcfc9  push r11
000074c3551dcfcb  sub rsp, 0xF0
000074c3551dcfd2  vmovaps [rsp], xmm0
000074c3551dcfd7  vmovaps [rsp+0x10], xmm1
000074c3551dcfdd  vmovaps [rsp+0x20], xmm2
000074c3551dcfe3  vmovaps [rsp+0x30], xmm4
000074c3551dcfe9  vmovaps [rsp+0x40], xmm5
000074c3551dcfef  vmovaps [rsp+0x50], xmm6
000074c3551dcff5  vmovaps [rsp+0x60], xmm7
000074c3551dcffb  vmovaps [rsp+0x70], xmm8
000074c3551dd001  vmovaps [rsp+0x80], xmm9
000074c3551dd00a  vmovaps [rsp+0x90], xmm10
000074c3551dd013  vmovaps [rsp+0xA0], xmm11
000074c3551dd01c  vmovaps [rsp+0xB0], xmm12
000074c3551dd025  vmovaps [rsp+0xC0], xmm13
000074c3551dd02e  vmovaps [rsp+0xD0], xmm14
000074c3551dd037  vmovaps [rsp+0xE0], xmm15
000074c3551dd040  sub rsp, 0x30
000074c3551dd044  movaps [rsp], xmm3
000074c3551dd048  movaps [rsp+0x10], xmm5
000074c3551dd04d  movaps [rsp+0x20], xmm4
000074c3551dd052  lea rdi, [rsp]
000074c3551dd056  mov esi, 0x00
000074c3551dd05b  mov rax, 0x5F9407FA9530
000074c3551dd065  call rax
000074c3551dd067  movaps xmm3, [rsp]
000074c3551dd06b  add rsp, 0x30
000074c3551dd06f  vmovaps xmm0, [rsp]
000074c3551dd074  vmovaps xmm1, [rsp+0x10]
000074c3551dd07a  vmovaps xmm2, [rsp+0x20]
000074c3551dd080  vmovaps xmm4, [rsp+0x30]
000074c3551dd086  vmovaps xmm5, [rsp+0x40]
000074c3551dd08c  vmovaps xmm6, [rsp+0x50]
000074c3551dd092  vmovaps xmm7, [rsp+0x60]
000074c3551dd098  vmovaps xmm8, [rsp+0x70]
000074c3551dd09e  vmovaps xmm9, [rsp+0x80]
000074c3551dd0a7  vmovaps xmm10, [rsp+0x90]
000074c3551dd0b0  vmovaps xmm11, [rsp+0xA0]
000074c3551dd0b9  vmovaps xmm12, [rsp+0xB0]
000074c3551dd0c2  vmovaps xmm13, [rsp+0xC0]
000074c3551dd0cb  vmovaps xmm14, [rsp+0xD0]
000074c3551dd0d4  vmovaps xmm15, [rsp+0xE0]
000074c3551dd0dd  add rsp, 0xF0
000074c3551dd0e4  pop r11
000074c3551dd0e6  pop r10
000074c3551dd0e8  pop r9
000074c3551dd0ea  pop r8
000074c3551dd0ec  pop rsi
000074c3551dd0ed  pop rdi
000074c3551dd0ee  pop rdx
000074c3551dd0ef  pop rcx
000074c3551dd0f0  pop rax
000074c3551dd0f1  add rsp, 0x08
000074c3551dd0f5  jmp 0x000074C3551DBC35
000074c3551dd0fa  sub rsp, 0x08
000074c3551dd0fe  push rax
000074c3551dd0ff  push rcx
000074c3551dd100  push rdx
000074c3551dd101  push rdi
000074c3551dd102  push rsi
000074c3551dd103  push r8
000074c3551dd105  push r9
000074c3551dd107  push r10
000074c3551dd109  push r11
000074c3551dd10b  sub rsp, 0xF0
000074c3551dd112  vmovaps [rsp], xmm0
000074c3551dd117  vmovaps [rsp+0x10], xmm1
000074c3551dd11d  vmovaps [rsp+0x20], xmm2
000074c3551dd123  vmovaps [rsp+0x30], xmm3
000074c3551dd129  vmovaps [rsp+0x40], xmm4
000074c3551dd12f  vmovaps [rsp+0x50], xmm6
000074c3551dd135  vmovaps [rsp+0x60], xmm7
000074c3551dd13b  vmovaps [rsp+0x70], xmm8
000074c3551dd141  vmovaps [rsp+0x80], xmm9
000074c3551dd14a  vmovaps [rsp+0x90], xmm10
000074c3551dd153  vmovaps [rsp+0xA0], xmm11
000074c3551dd15c  vmovaps [rsp+0xB0], xmm12
000074c3551dd165  vmovaps [rsp+0xC0], xmm13
000074c3551dd16e  vmovaps [rsp+0xD0], xmm14
000074c3551dd177  vmovaps [rsp+0xE0], xmm15
000074c3551dd180  sub rsp, 0x30
000074c3551dd184  movaps [rsp], xmm5
000074c3551dd188  movaps [rsp+0x10], xmm8
000074c3551dd18e  movaps [rsp+0x20], xmm15
000074c3551dd194  lea rdi, [rsp]
000074c3551dd198  mov esi, 0x00
000074c3551dd19d  mov rax, 0x5F9407FA9530
000074c3551dd1a7  call rax
000074c3551dd1a9  movaps xmm5, [rsp]
000074c3551dd1ad  add rsp, 0x30
000074c3551dd1b1  vmovaps xmm0, [rsp]
000074c3551dd1b6  vmovaps xmm1, [rsp+0x10]
000074c3551dd1bc  vmovaps xmm2, [rsp+0x20]
000074c3551dd1c2  vmovaps xmm3, [rsp+0x30]
000074c3551dd1c8  vmovaps xmm4, [rsp+0x40]
000074c3551dd1ce  vmovaps xmm6, [rsp+0x50]
000074c3551dd1d4  vmovaps xmm7, [rsp+0x60]
000074c3551dd1da  vmovaps xmm8, [rsp+0x70]
000074c3551dd1e0  vmovaps xmm9, [rsp+0x80]
000074c3551dd1e9  vmovaps xmm10, [rsp+0x90]
000074c3551dd1f2  vmovaps xmm11, [rsp+0xA0]
000074c3551dd1fb  vmovaps xmm12, [rsp+0xB0]
000074c3551dd204  vmovaps xmm13, [rsp+0xC0]
000074c3551dd20d  vmovaps xmm14, [rsp+0xD0]
000074c3551dd216  vmovaps xmm15, [rsp+0xE0]
000074c3551dd21f  add rsp, 0xF0
000074c3551dd226  pop r11
000074c3551dd228  pop r10
000074c3551dd22a  pop r9
000074c3551dd22c  pop r8
000074c3551dd22e  pop rsi
000074c3551dd22f  pop rdi
000074c3551dd230  pop rdx
000074c3551dd231  pop rcx
000074c3551dd232  pop rax
000074c3551dd233  add rsp, 0x08
000074c3551dd237  jmp 0x000074C3551DBC73
000074c3551dd23c  sub rsp, 0x08
000074c3551dd240  push rax
000074c3551dd241  push rcx
000074c3551dd242  push rdx
000074c3551dd243  push rdi
000074c3551dd244  push rsi
000074c3551dd245  push r8
000074c3551dd247  push r9
000074c3551dd249  push r10
000074c3551dd24b  push r11
000074c3551dd24d  sub rsp, 0xF0
000074c3551dd254  vmovaps [rsp], xmm0
000074c3551dd259  vmovaps [rsp+0x10], xmm1
000074c3551dd25f  vmovaps [rsp+0x20], xmm2
000074c3551dd265  vmovaps [rsp+0x30], xmm3
000074c3551dd26b  vmovaps [rsp+0x40], xmm5
000074c3551dd271  vmovaps [rsp+0x50], xmm6
000074c3551dd277  vmovaps [rsp+0x60], xmm7
000074c3551dd27d  vmovaps [rsp+0x70], xmm8
000074c3551dd283  vmovaps [rsp+0x80], xmm9
000074c3551dd28c  vmovaps [rsp+0x90], xmm10
000074c3551dd295  vmovaps [rsp+0xA0], xmm11
000074c3551dd29e  vmovaps [rsp+0xB0], xmm12
000074c3551dd2a7  vmovaps [rsp+0xC0], xmm13
000074c3551dd2b0  vmovaps [rsp+0xD0], xmm14
000074c3551dd2b9  vmovaps [rsp+0xE0], xmm15
000074c3551dd2c2  sub rsp, 0x30
000074c3551dd2c6  movaps [rsp], xmm4
000074c3551dd2ca  movaps [rsp+0x10], xmm9
000074c3551dd2d0  movaps [rsp+0x20], xmm8
000074c3551dd2d6  lea rdi, [rsp]
000074c3551dd2da  mov esi, 0x00
000074c3551dd2df  mov rax, 0x5F9407FA9530
000074c3551dd2e9  call rax
000074c3551dd2eb  movaps xmm4, [rsp]
000074c3551dd2ef  add rsp, 0x30
000074c3551dd2f3  vmovaps xmm0, [rsp]
000074c3551dd2f8  vmovaps xmm1, [rsp+0x10]
000074c3551dd2fe  vmovaps xmm2, [rsp+0x20]
000074c3551dd304  vmovaps xmm3, [rsp+0x30]
000074c3551dd30a  vmovaps xmm5, [rsp+0x40]
000074c3551dd310  vmovaps xmm6, [rsp+0x50]
000074c3551dd316  vmovaps xmm7, [rsp+0x60]
000074c3551dd31c  vmovaps xmm8, [rsp+0x70]
000074c3551dd322  vmovaps xmm9, [rsp+0x80]
000074c3551dd32b  vmovaps xmm10, [rsp+0x90]
000074c3551dd334  vmovaps xmm11, [rsp+0xA0]
000074c3551dd33d  vmovaps xmm12, [rsp+0xB0]
000074c3551dd346  vmovaps xmm13, [rsp+0xC0]
000074c3551dd34f  vmovaps xmm14, [rsp+0xD0]
000074c3551dd358  vmovaps xmm15, [rsp+0xE0]
000074c3551dd361  add rsp, 0xF0
000074c3551dd368  pop r11
000074c3551dd36a  pop r10
000074c3551dd36c  pop r9
000074c3551dd36e  pop r8
000074c3551dd370  pop rsi
000074c3551dd371  pop rdi
000074c3551dd372  pop rdx
000074c3551dd373  pop rcx
000074c3551dd374  pop rax
000074c3551dd375  add rsp, 0x08
000074c3551dd379  jmp 0x000074C3551DBC94
000074c3551dd37e  sub rsp, 0x08
000074c3551dd382  push rax
000074c3551dd383  push rcx
000074c3551dd384  push rdx
000074c3551dd385  push rdi
000074c3551dd386  push rsi
000074c3551dd387  push r8
000074c3551dd389  push r9
000074c3551dd38b  push r10
000074c3551dd38d  push r11
000074c3551dd38f  sub rsp, 0xF0
000074c3551dd396  vmovaps [rsp], xmm0
000074c3551dd39b  vmovaps [rsp+0x10], xmm1
000074c3551dd3a1  vmovaps [rsp+0x20], xmm2
000074c3551dd3a7  vmovaps [rsp+0x30], xmm3
000074c3551dd3ad  vmovaps [rsp+0x40], xmm4
000074c3551dd3b3  vmovaps [rsp+0x50], xmm5
000074c3551dd3b9  vmovaps [rsp+0x60], xmm6
000074c3551dd3bf  vmovaps [rsp+0x70], xmm7
000074c3551dd3c5  vmovaps [rsp+0x80], xmm8
000074c3551dd3ce  vmovaps [rsp+0x90], xmm10
000074c3551dd3d7  vmovaps [rsp+0xA0], xmm11
000074c3551dd3e0  vmovaps [rsp+0xB0], xmm12
000074c3551dd3e9  vmovaps [rsp+0xC0], xmm13
000074c3551dd3f2  vmovaps [rsp+0xD0], xmm14
000074c3551dd3fb  vmovaps [rsp+0xE0], xmm15
000074c3551dd404  sub rsp, 0x30
000074c3551dd408  movaps [rsp], xmm9
000074c3551dd40d  movaps [rsp+0x10], xmm10
000074c3551dd413  movaps [rsp+0x20], xmm8
000074c3551dd419  lea rdi, [rsp]
000074c3551dd41d  mov esi, 0x00
000074c3551dd422  mov rax, 0x5F9407FA9530
000074c3551dd42c  call rax
000074c3551dd42e  movaps xmm9, [rsp]
000074c3551dd433  add rsp, 0x30
000074c3551dd437  vmovaps xmm0, [rsp]
000074c3551dd43c  vmovaps xmm1, [rsp+0x10]
000074c3551dd442  vmovaps xmm2, [rsp+0x20]
000074c3551dd448  vmovaps xmm3, [rsp+0x30]
000074c3551dd44e  vmovaps xmm4, [rsp+0x40]
000074c3551dd454  vmovaps xmm5, [rsp+0x50]
000074c3551dd45a  vmovaps xmm6, [rsp+0x60]
000074c3551dd460  vmovaps xmm7, [rsp+0x70]
000074c3551dd466  vmovaps xmm8, [rsp+0x80]
000074c3551dd46f  vmovaps xmm10, [rsp+0x90]
000074c3551dd478  vmovaps xmm11, [rsp+0xA0]
000074c3551dd481  vmovaps xmm12, [rsp+0xB0]
000074c3551dd48a  vmovaps xmm13, [rsp+0xC0]
000074c3551dd493  vmovaps xmm14, [rsp+0xD0]
000074c3551dd49c  vmovaps xmm15, [rsp+0xE0]
000074c3551dd4a5  add rsp, 0xF0
000074c3551dd4ac  pop r11
000074c3551dd4ae  pop r10
000074c3551dd4b0  pop r9
000074c3551dd4b2  pop r8
000074c3551dd4b4  pop rsi
000074c3551dd4b5  pop rdi
000074c3551dd4b6  pop rdx
000074c3551dd4b7  pop rcx
000074c3551dd4b8  pop rax
000074c3551dd4b9  add rsp, 0x08
000074c3551dd4bd  jmp 0x000074C3551DBCAE
000074c3551dd4c2  call 0x000074C3550B52F0
000074c3551dd4c7  jmp 0x000074C3551DBDC8
000074c3551dd4cc  call 0x000074C3550B52F0
000074c3551dd4d1  jmp 0x000074C3551DBDDE
000074c3551dd4d6  sub rsp, 0x08
000074c3551dd4da  push rax
000074c3551dd4db  push rcx
000074c3551dd4dc  push rdx
000074c3551dd4dd  push rdi
000074c3551dd4de  push rsi
000074c3551dd4df  push r8
000074c3551dd4e1  push r9
000074c3551dd4e3  push r10
000074c3551dd4e5  push r11
000074c3551dd4e7  sub rsp, 0xF0
000074c3551dd4ee  vmovaps [rsp], xmm0
000074c3551dd4f3  vmovaps [rsp+0x10], xmm2
000074c3551dd4f9  vmovaps [rsp+0x20], xmm3
000074c3551dd4ff  vmovaps [rsp+0x30], xmm4
000074c3551dd505  vmovaps [rsp+0x40], xmm5
000074c3551dd50b  vmovaps [rsp+0x50], xmm6
000074c3551dd511  vmovaps [rsp+0x60], xmm7
000074c3551dd517  vmovaps [rsp+0x70], xmm8
000074c3551dd51d  vmovaps [rsp+0x80], xmm9
000074c3551dd526  vmovaps [rsp+0x90], xmm10
000074c3551dd52f  vmovaps [rsp+0xA0], xmm11
000074c3551dd538  vmovaps [rsp+0xB0], xmm12
000074c3551dd541  vmovaps [rsp+0xC0], xmm13
000074c3551dd54a  vmovaps [rsp+0xD0], xmm14
000074c3551dd553  vmovaps [rsp+0xE0], xmm15
000074c3551dd55c  sub rsp, 0x30
000074c3551dd560  movaps [rsp], xmm1
000074c3551dd564  movaps [rsp+0x10], xmm6
000074c3551dd569  movaps [rsp+0x20], xmm15
000074c3551dd56f  lea rdi, [rsp]
000074c3551dd573  mov esi, 0x00
000074c3551dd578  mov rax, 0x5F9407FA9530
000074c3551dd582  call rax
000074c3551dd584  movaps xmm1, [rsp]
000074c3551dd588  add rsp, 0x30
000074c3551dd58c  vmovaps xmm0, [rsp]
000074c3551dd591  vmovaps xmm2, [rsp+0x10]
000074c3551dd597  vmovaps xmm3, [rsp+0x20]
000074c3551dd59d  vmovaps xmm4, [rsp+0x30]
000074c3551dd5a3  vmovaps xmm5, [rsp+0x40]
000074c3551dd5a9  vmovaps xmm6, [rsp+0x50]
000074c3551dd5af  vmovaps xmm7, [rsp+0x60]
000074c3551dd5b5  vmovaps xmm8, [rsp+0x70]
000074c3551dd5bb  vmovaps xmm9, [rsp+0x80]
000074c3551dd5c4  vmovaps xmm10, [rsp+0x90]
000074c3551dd5cd  vmovaps xmm11, [rsp+0xA0]
000074c3551dd5d6  vmovaps xmm12, [rsp+0xB0]
000074c3551dd5df  vmovaps xmm13, [rsp+0xC0]
000074c3551dd5e8  vmovaps xmm14, [rsp+0xD0]
000074c3551dd5f1  vmovaps xmm15, [rsp+0xE0]
000074c3551dd5fa  add rsp, 0xF0
000074c3551dd601  pop r11
000074c3551dd603  pop r10
000074c3551dd605  pop r9
000074c3551dd607  pop r8
000074c3551dd609  pop rsi
000074c3551dd60a  pop rdi
000074c3551dd60b  pop rdx
000074c3551dd60c  pop rcx
000074c3551dd60d  pop rax
000074c3551dd60e  add rsp, 0x08
000074c3551dd612  jmp 0x000074C3551DBE1B
000074c3551dd617  call 0x000074C3550C4620
000074c3551dd61c  jmp 0x000074C3551DBE28
000074c3551dd621  sub rsp, 0x08
000074c3551dd625  push rax
000074c3551dd626  push rcx
000074c3551dd627  push rdx
000074c3551dd628  push rdi
000074c3551dd629  push rsi
000074c3551dd62a  push r8
000074c3551dd62c  push r9
000074c3551dd62e  push r10
000074c3551dd630  push r11
000074c3551dd632  sub rsp, 0xF0
000074c3551dd639  vmovaps [rsp], xmm0
000074c3551dd63e  vmovaps [rsp+0x10], xmm1
000074c3551dd644  vmovaps [rsp+0x20], xmm2
000074c3551dd64a  vmovaps [rsp+0x30], xmm3
000074c3551dd650  vmovaps [rsp+0x40], xmm4
000074c3551dd656  vmovaps [rsp+0x50], xmm5
000074c3551dd65c  vmovaps [rsp+0x60], xmm6
000074c3551dd662  vmovaps [rsp+0x70], xmm7
000074c3551dd668  vmovaps [rsp+0x80], xmm8
000074c3551dd671  vmovaps [rsp+0x90], xmm9
000074c3551dd67a  vmovaps [rsp+0xA0], xmm10
000074c3551dd683  vmovaps [rsp+0xB0], xmm11
000074c3551dd68c  vmovaps [rsp+0xC0], xmm12
000074c3551dd695  vmovaps [rsp+0xD0], xmm13
000074c3551dd69e  vmovaps [rsp+0xE0], xmm15
000074c3551dd6a7  sub rsp, 0x30
000074c3551dd6ab  movaps [rsp], xmm14
000074c3551dd6b0  movaps [rsp+0x10], xmm4
000074c3551dd6b5  movaps [rsp+0x20], xmm3
000074c3551dd6ba  lea rdi, [rsp]
000074c3551dd6be  mov esi, 0x00
000074c3551dd6c3  mov rax, 0x5F9407FA9530
000074c3551dd6cd  call rax
000074c3551dd6cf  movaps xmm14, [rsp]
000074c3551dd6d4  add rsp, 0x30
000074c3551dd6d8  vmovaps xmm0, [rsp]
000074c3551dd6dd  vmovaps xmm1, [rsp+0x10]
000074c3551dd6e3  vmovaps xmm2, [rsp+0x20]
000074c3551dd6e9  vmovaps xmm3, [rsp+0x30]
000074c3551dd6ef  vmovaps xmm4, [rsp+0x40]
000074c3551dd6f5  vmovaps xmm5, [rsp+0x50]
000074c3551dd6fb  vmovaps xmm6, [rsp+0x60]
000074c3551dd701  vmovaps xmm7, [rsp+0x70]
000074c3551dd707  vmovaps xmm8, [rsp+0x80]
000074c3551dd710  vmovaps xmm9, [rsp+0x90]
000074c3551dd719  vmovaps xmm10, [rsp+0xA0]
000074c3551dd722  vmovaps xmm11, [rsp+0xB0]
000074c3551dd72b  vmovaps xmm12, [rsp+0xC0]
000074c3551dd734  vmovaps xmm13, [rsp+0xD0]
000074c3551dd73d  vmovaps xmm15, [rsp+0xE0]
000074c3551dd746  add rsp, 0xF0
000074c3551dd74d  pop r11
000074c3551dd74f  pop r10
000074c3551dd751  pop r9
000074c3551dd753  pop r8
000074c3551dd755  pop rsi
000074c3551dd756  pop rdi
000074c3551dd757  pop rdx
000074c3551dd758  pop rcx
000074c3551dd759  pop rax
000074c3551dd75a  add rsp, 0x08
000074c3551dd75e  jmp 0x000074C3551DBE42
000074c3551dd763  sub rsp, 0x08
000074c3551dd767  push rax
000074c3551dd768  push rcx
000074c3551dd769  push rdx
000074c3551dd76a  push rdi
000074c3551dd76b  push rsi
000074c3551dd76c  push r8
000074c3551dd76e  push r9
000074c3551dd770  push r10
000074c3551dd772  push r11
000074c3551dd774  sub rsp, 0xF0
000074c3551dd77b  vmovaps [rsp], xmm0
000074c3551dd780  vmovaps [rsp+0x10], xmm1
000074c3551dd786  vmovaps [rsp+0x20], xmm2
000074c3551dd78c  vmovaps [rsp+0x30], xmm3
000074c3551dd792  vmovaps [rsp+0x40], xmm4
000074c3551dd798  vmovaps [rsp+0x50], xmm5
000074c3551dd79e  vmovaps [rsp+0x60], xmm7
000074c3551dd7a4  vmovaps [rsp+0x70], xmm8
000074c3551dd7aa  vmovaps [rsp+0x80], xmm9
000074c3551dd7b3  vmovaps [rsp+0x90], xmm10
000074c3551dd7bc  vmovaps [rsp+0xA0], xmm11
000074c3551dd7c5  vmovaps [rsp+0xB0], xmm12
000074c3551dd7ce  vmovaps [rsp+0xC0], xmm13
000074c3551dd7d7  vmovaps [rsp+0xD0], xmm14
000074c3551dd7e0  vmovaps [rsp+0xE0], xmm15
000074c3551dd7e9  sub rsp, 0x30
000074c3551dd7ed  movaps [rsp], xmm6
000074c3551dd7f1  movaps [rsp+0x10], xmm9
000074c3551dd7f7  movaps [rsp+0x20], xmm7
000074c3551dd7fc  lea rdi, [rsp]
000074c3551dd800  mov esi, 0x00
000074c3551dd805  mov rax, 0x5F9407FA9530
000074c3551dd80f  call rax
000074c3551dd811  movaps xmm6, [rsp]
000074c3551dd815  add rsp, 0x30
000074c3551dd819  vmovaps xmm0, [rsp]
000074c3551dd81e  vmovaps xmm1, [rsp+0x10]
000074c3551dd824  vmovaps xmm2, [rsp+0x20]
000074c3551dd82a  vmovaps xmm3, [rsp+0x30]
000074c3551dd830  vmovaps xmm4, [rsp+0x40]
000074c3551dd836  vmovaps xmm5, [rsp+0x50]
000074c3551dd83c  vmovaps xmm7, [rsp+0x60]
000074c3551dd842  vmovaps xmm8, [rsp+0x70]
000074c3551dd848  vmovaps xmm9, [rsp+0x80]
000074c3551dd851  vmovaps xmm10, [rsp+0x90]
000074c3551dd85a  vmovaps xmm11, [rsp+0xA0]
000074c3551dd863  vmovaps xmm12, [rsp+0xB0]
000074c3551dd86c  vmovaps xmm13, [rsp+0xC0]
000074c3551dd875  vmovaps xmm14, [rsp+0xD0]
000074c3551dd87e  vmovaps xmm15, [rsp+0xE0]
000074c3551dd887  add rsp, 0xF0
000074c3551dd88e  pop r11
000074c3551dd890  pop r10
000074c3551dd892  pop r9
000074c3551dd894  pop r8
000074c3551dd896  pop rsi
000074c3551dd897  pop rdi
000074c3551dd898  pop rdx
000074c3551dd899  pop rcx
000074c3551dd89a  pop rax
000074c3551dd89b  add rsp, 0x08
000074c3551dd89f  jmp 0x000074C3551DBE5A
000074c3551dd8a4  sub rsp, 0x08
000074c3551dd8a8  push rax
000074c3551dd8a9  push rcx
000074c3551dd8aa  push rdx
000074c3551dd8ab  push rdi
000074c3551dd8ac  push rsi
000074c3551dd8ad  push r8
000074c3551dd8af  push r9
000074c3551dd8b1  push r10
000074c3551dd8b3  push r11
000074c3551dd8b5  sub rsp, 0xF0
000074c3551dd8bc  vmovaps [rsp], xmm0
000074c3551dd8c1  vmovaps [rsp+0x10], xmm1
000074c3551dd8c7  vmovaps [rsp+0x20], xmm2
000074c3551dd8cd  vmovaps [rsp+0x30], xmm3
000074c3551dd8d3  vmovaps [rsp+0x40], xmm4
000074c3551dd8d9  vmovaps [rsp+0x50], xmm5
000074c3551dd8df  vmovaps [rsp+0x60], xmm6
000074c3551dd8e5  vmovaps [rsp+0x70], xmm8
000074c3551dd8eb  vmovaps [rsp+0x80], xmm9
000074c3551dd8f4  vmovaps [rsp+0x90], xmm10
000074c3551dd8fd  vmovaps [rsp+0xA0], xmm11
000074c3551dd906  vmovaps [rsp+0xB0], xmm12
000074c3551dd90f  vmovaps [rsp+0xC0], xmm13
000074c3551dd918  vmovaps [rsp+0xD0], xmm14
000074c3551dd921  vmovaps [rsp+0xE0], xmm15
000074c3551dd92a  sub rsp, 0x30
000074c3551dd92e  movaps [rsp], xmm7
000074c3551dd932  movaps [rsp+0x10], xmm4
000074c3551dd937  movaps [rsp+0x20], xmm9
000074c3551dd93d  lea rdi, [rsp]
000074c3551dd941  mov esi, 0x00
000074c3551dd946  mov rax, 0x5F9407FA9530
000074c3551dd950  call rax
000074c3551dd952  movaps xmm7, [rsp]
000074c3551dd956  add rsp, 0x30
000074c3551dd95a  vmovaps xmm0, [rsp]
000074c3551dd95f  vmovaps xmm1, [rsp+0x10]
000074c3551dd965  vmovaps xmm2, [rsp+0x20]
000074c3551dd96b  vmovaps xmm3, [rsp+0x30]
000074c3551dd971  vmovaps xmm4, [rsp+0x40]
000074c3551dd977  vmovaps xmm5, [rsp+0x50]
000074c3551dd97d  vmovaps xmm6, [rsp+0x60]
000074c3551dd983  vmovaps xmm8, [rsp+0x70]
000074c3551dd989  vmovaps xmm9, [rsp+0x80]
000074c3551dd992  vmovaps xmm10, [rsp+0x90]
000074c3551dd99b  vmovaps xmm11, [rsp+0xA0]
000074c3551dd9a4  vmovaps xmm12, [rsp+0xB0]
000074c3551dd9ad  vmovaps xmm13, [rsp+0xC0]
000074c3551dd9b6  vmovaps xmm14, [rsp+0xD0]
000074c3551dd9bf  vmovaps xmm15, [rsp+0xE0]
000074c3551dd9c8  add rsp, 0xF0
000074c3551dd9cf  pop r11
000074c3551dd9d1  pop r10
000074c3551dd9d3  pop r9
000074c3551dd9d5  pop r8
000074c3551dd9d7  pop rsi
000074c3551dd9d8  pop rdi
000074c3551dd9d9  pop rdx
000074c3551dd9da  pop rcx
000074c3551dd9db  pop rax
000074c3551dd9dc  add rsp, 0x08
000074c3551dd9e0  jmp 0x000074C3551DBE87
000074c3551dd9e5  sub rsp, 0x08
000074c3551dd9e9  push rax
000074c3551dd9ea  push rcx
000074c3551dd9eb  push rdx
000074c3551dd9ec  push rdi
000074c3551dd9ed  push rsi
000074c3551dd9ee  push r8
000074c3551dd9f0  push r9
000074c3551dd9f2  push r10
000074c3551dd9f4  push r11
000074c3551dd9f6  sub rsp, 0xF0
000074c3551dd9fd  vmovaps [rsp], xmm0
000074c3551dda02  vmovaps [rsp+0x10], xmm1
000074c3551dda08  vmovaps [rsp+0x20], xmm2
000074c3551dda0e  vmovaps [rsp+0x30], xmm3
000074c3551dda14  vmovaps [rsp+0x40], xmm5
000074c3551dda1a  vmovaps [rsp+0x50], xmm6
000074c3551dda20  vmovaps [rsp+0x60], xmm7
000074c3551dda26  vmovaps [rsp+0x70], xmm8
000074c3551dda2c  vmovaps [rsp+0x80], xmm9
000074c3551dda35  vmovaps [rsp+0x90], xmm10
000074c3551dda3e  vmovaps [rsp+0xA0], xmm11
000074c3551dda47  vmovaps [rsp+0xB0], xmm12
000074c3551dda50  vmovaps [rsp+0xC0], xmm13
000074c3551dda59  vmovaps [rsp+0xD0], xmm14
000074c3551dda62  vmovaps [rsp+0xE0], xmm15
000074c3551dda6b  sub rsp, 0x30
000074c3551dda6f  movaps [rsp], xmm4
000074c3551dda73  movaps [rsp+0x10], xmm15
000074c3551dda79  movaps [rsp+0x20], xmm9
000074c3551dda7f  lea rdi, [rsp]
000074c3551dda83  mov esi, 0x00
000074c3551dda88  mov rax, 0x5F9407FA9530
000074c3551dda92  call rax
000074c3551dda94  movaps xmm4, [rsp]
000074c3551dda98  add rsp, 0x30
000074c3551dda9c  vmovaps xmm0, [rsp]
000074c3551ddaa1  vmovaps xmm1, [rsp+0x10]
000074c3551ddaa7  vmovaps xmm2, [rsp+0x20]
000074c3551ddaad  vmovaps xmm3, [rsp+0x30]
000074c3551ddab3  vmovaps xmm5, [rsp+0x40]
000074c3551ddab9  vmovaps xmm6, [rsp+0x50]
000074c3551ddabf  vmovaps xmm7, [rsp+0x60]
000074c3551ddac5  vmovaps xmm8, [rsp+0x70]
000074c3551ddacb  vmovaps xmm9, [rsp+0x80]
000074c3551ddad4  vmovaps xmm10, [rsp+0x90]
000074c3551ddadd  vmovaps xmm11, [rsp+0xA0]
000074c3551ddae6  vmovaps xmm12, [rsp+0xB0]
000074c3551ddaef  vmovaps xmm13, [rsp+0xC0]
000074c3551ddaf8  vmovaps xmm14, [rsp+0xD0]
000074c3551ddb01  vmovaps xmm15, [rsp+0xE0]
000074c3551ddb0a  add rsp, 0xF0
000074c3551ddb11  pop r11
000074c3551ddb13  pop r10
000074c3551ddb15  pop r9
000074c3551ddb17  pop r8
000074c3551ddb19  pop rsi
000074c3551ddb1a  pop rdi
000074c3551ddb1b  pop rdx
000074c3551ddb1c  pop rcx
000074c3551ddb1d  pop rax
000074c3551ddb1e  add rsp, 0x08
000074c3551ddb22  jmp 0x000074C3551DBEAC
000074c3551ddb27  call 0x000074C3550C4620
000074c3551ddb2c  jmp 0x000074C3551DBEB9
000074c3551ddb31  sub rsp, 0x08
000074c3551ddb35  push rax
000074c3551ddb36  push rcx
000074c3551ddb37  push rdx
000074c3551ddb38  push rdi
000074c3551ddb39  push rsi
000074c3551ddb3a  push r8
000074c3551ddb3c  push r9
000074c3551ddb3e  push r10
000074c3551ddb40  push r11
000074c3551ddb42  sub rsp, 0xF0
000074c3551ddb49  vmovaps [rsp], xmm0
000074c3551ddb4e  vmovaps [rsp+0x10], xmm1
000074c3551ddb54  vmovaps [rsp+0x20], xmm2
000074c3551ddb5a  vmovaps [rsp+0x30], xmm4
000074c3551ddb60  vmovaps [rsp+0x40], xmm5
000074c3551ddb66  vmovaps [rsp+0x50], xmm6
000074c3551ddb6c  vmovaps [rsp+0x60], xmm7
000074c3551ddb72  vmovaps [rsp+0x70], xmm8
000074c3551ddb78  vmovaps [rsp+0x80], xmm9
000074c3551ddb81  vmovaps [rsp+0x90], xmm10
000074c3551ddb8a  vmovaps [rsp+0xA0], xmm11
000074c3551ddb93  vmovaps [rsp+0xB0], xmm12
000074c3551ddb9c  vmovaps [rsp+0xC0], xmm13
000074c3551ddba5  vmovaps [rsp+0xD0], xmm14
000074c3551ddbae  vmovaps [rsp+0xE0], xmm15
000074c3551ddbb7  sub rsp, 0x30
000074c3551ddbbb  movaps [rsp], xmm3
000074c3551ddbbf  movaps [rsp+0x10], xmm1
000074c3551ddbc4  movaps [rsp+0x20], xmm9
000074c3551ddbca  lea rdi, [rsp]
000074c3551ddbce  mov esi, 0x00
000074c3551ddbd3  mov rax, 0x5F9407FA9530
000074c3551ddbdd  call rax
000074c3551ddbdf  movaps xmm3, [rsp]
000074c3551ddbe3  add rsp, 0x30
000074c3551ddbe7  vmovaps xmm0, [rsp]
000074c3551ddbec  vmovaps xmm1, [rsp+0x10]
000074c3551ddbf2  vmovaps xmm2, [rsp+0x20]
000074c3551ddbf8  vmovaps xmm4, [rsp+0x30]
000074c3551ddbfe  vmovaps xmm5, [rsp+0x40]
000074c3551ddc04  vmovaps xmm6, [rsp+0x50]
000074c3551ddc0a  vmovaps xmm7, [rsp+0x60]
000074c3551ddc10  vmovaps xmm8, [rsp+0x70]
000074c3551ddc16  vmovaps xmm9, [rsp+0x80]
000074c3551ddc1f  vmovaps xmm10, [rsp+0x90]
000074c3551ddc28  vmovaps xmm11, [rsp+0xA0]
000074c3551ddc31  vmovaps xmm12, [rsp+0xB0]
000074c3551ddc3a  vmovaps xmm13, [rsp+0xC0]
000074c3551ddc43  vmovaps xmm14, [rsp+0xD0]
000074c3551ddc4c  vmovaps xmm15, [rsp+0xE0]
000074c3551ddc55  add rsp, 0xF0
000074c3551ddc5c  pop r11
000074c3551ddc5e  pop r10
000074c3551ddc60  pop r9
000074c3551ddc62  pop r8
000074c3551ddc64  pop rsi
000074c3551ddc65  pop rdi
000074c3551ddc66  pop rdx
000074c3551ddc67  pop rcx
000074c3551ddc68  pop rax
000074c3551ddc69  add rsp, 0x08
000074c3551ddc6d  jmp 0x000074C3551DBEF6
000074c3551ddc72  sub rsp, 0x08
000074c3551ddc76  push rax
000074c3551ddc77  push rcx
000074c3551ddc78  push rdx
000074c3551ddc79  push rdi
000074c3551ddc7a  push rsi
000074c3551ddc7b  push r8
000074c3551ddc7d  push r9
000074c3551ddc7f  push r10
000074c3551ddc81  push r11
000074c3551ddc83  sub rsp, 0xF0
000074c3551ddc8a  vmovaps [rsp], xmm0
000074c3551ddc8f  vmovaps [rsp+0x10], xmm2
000074c3551ddc95  vmovaps [rsp+0x20], xmm3
000074c3551ddc9b  vmovaps [rsp+0x30], xmm4
000074c3551ddca1  vmovaps [rsp+0x40], xmm5
000074c3551ddca7  vmovaps [rsp+0x50], xmm6
000074c3551ddcad  vmovaps [rsp+0x60], xmm7
000074c3551ddcb3  vmovaps [rsp+0x70], xmm8
000074c3551ddcb9  vmovaps [rsp+0x80], xmm9
000074c3551ddcc2  vmovaps [rsp+0x90], xmm10
000074c3551ddccb  vmovaps [rsp+0xA0], xmm11
000074c3551ddcd4  vmovaps [rsp+0xB0], xmm12
000074c3551ddcdd  vmovaps [rsp+0xC0], xmm13
000074c3551ddce6  vmovaps [rsp+0xD0], xmm14
000074c3551ddcef  vmovaps [rsp+0xE0], xmm15
000074c3551ddcf8  sub rsp, 0x30
000074c3551ddcfc  movaps [rsp], xmm1
000074c3551ddd00  movaps [rsp+0x10], xmm15
000074c3551ddd06  movaps [rsp+0x20], xmm9
000074c3551ddd0c  lea rdi, [rsp]
000074c3551ddd10  mov esi, 0x00
000074c3551ddd15  mov rax, 0x5F9407FA9530
000074c3551ddd1f  call rax
000074c3551ddd21  movaps xmm1, [rsp]
000074c3551ddd25  add rsp, 0x30
000074c3551ddd29  vmovaps xmm0, [rsp]
000074c3551ddd2e  vmovaps xmm2, [rsp+0x10]
000074c3551ddd34  vmovaps xmm3, [rsp+0x20]
000074c3551ddd3a  vmovaps xmm4, [rsp+0x30]
000074c3551ddd40  vmovaps xmm5, [rsp+0x40]
000074c3551ddd46  vmovaps xmm6, [rsp+0x50]
000074c3551ddd4c  vmovaps xmm7, [rsp+0x60]
000074c3551ddd52  vmovaps xmm8, [rsp+0x70]
000074c3551ddd58  vmovaps xmm9, [rsp+0x80]
000074c3551ddd61  vmovaps xmm10, [rsp+0x90]
000074c3551ddd6a  vmovaps xmm11, [rsp+0xA0]
000074c3551ddd73  vmovaps xmm12, [rsp+0xB0]
000074c3551ddd7c  vmovaps xmm13, [rsp+0xC0]
000074c3551ddd85  vmovaps xmm14, [rsp+0xD0]
000074c3551ddd8e  vmovaps xmm15, [rsp+0xE0]
000074c3551ddd97  add rsp, 0xF0
000074c3551ddd9e  pop r11
000074c3551ddda0  pop r10
000074c3551ddda2  pop r9
000074c3551ddda4  pop r8
000074c3551ddda6  pop rsi
000074c3551ddda7  pop rdi
000074c3551ddda8  pop rdx
000074c3551ddda9  pop rcx
000074c3551dddaa  pop rax
000074c3551dddab  add rsp, 0x08
000074c3551dddaf  jmp 0x000074C3551DBF7E
000074c3551dddb4  call 0x000074C3550C4620
000074c3551dddb9  jmp 0x000074C3551DBF8B
000074c3551dddbe  sub rsp, 0x08
000074c3551dddc2  push rax
000074c3551dddc3  push rcx
000074c3551dddc4  push rdx
000074c3551dddc5  push rdi
000074c3551dddc6  push rsi
000074c3551dddc7  push r8
000074c3551dddc9  push r9
000074c3551dddcb  push r10
000074c3551dddcd  push r11
000074c3551dddcf  sub rsp, 0xF0
000074c3551dddd6  vmovaps [rsp], xmm0
000074c3551ddddb  vmovaps [rsp+0x10], xmm2
000074c3551ddde1  vmovaps [rsp+0x20], xmm3
000074c3551ddde7  vmovaps [rsp+0x30], xmm4
000074c3551ddded  vmovaps [rsp+0x40], xmm5
000074c3551dddf3  vmovaps [rsp+0x50], xmm6
000074c3551dddf9  vmovaps [rsp+0x60], xmm7
000074c3551dddff  vmovaps [rsp+0x70], xmm8
000074c3551dde05  vmovaps [rsp+0x80], xmm9
000074c3551dde0e  vmovaps [rsp+0x90], xmm10
000074c3551dde17  vmovaps [rsp+0xA0], xmm11
000074c3551dde20  vmovaps [rsp+0xB0], xmm12
000074c3551dde29  vmovaps [rsp+0xC0], xmm13
000074c3551dde32  vmovaps [rsp+0xD0], xmm14
000074c3551dde3b  vmovaps [rsp+0xE0], xmm15
000074c3551dde44  sub rsp, 0x30
000074c3551dde48  movaps [rsp], xmm1
000074c3551dde4c  movaps [rsp+0x10], xmm5
000074c3551dde51  movaps [rsp+0x20], xmm7
000074c3551dde56  lea rdi, [rsp]
000074c3551dde5a  mov esi, 0x00
000074c3551dde5f  mov rax, 0x5F9407FA9530
000074c3551dde69  call rax
000074c3551dde6b  movaps xmm1, [rsp]
000074c3551dde6f  add rsp, 0x30
000074c3551dde73  vmovaps xmm0, [rsp]
000074c3551dde78  vmovaps xmm2, [rsp+0x10]
000074c3551dde7e  vmovaps xmm3, [rsp+0x20]
000074c3551dde84  vmovaps xmm4, [rsp+0x30]
000074c3551dde8a  vmovaps xmm5, [rsp+0x40]
000074c3551dde90  vmovaps xmm6, [rsp+0x50]
000074c3551dde96  vmovaps xmm7, [rsp+0x60]
000074c3551dde9c  vmovaps xmm8, [rsp+0x70]
000074c3551ddea2  vmovaps xmm9, [rsp+0x80]
000074c3551ddeab  vmovaps xmm10, [rsp+0x90]
000074c3551ddeb4  vmovaps xmm11, [rsp+0xA0]
000074c3551ddebd  vmovaps xmm12, [rsp+0xB0]
000074c3551ddec6  vmovaps xmm13, [rsp+0xC0]
000074c3551ddecf  vmovaps xmm14, [rsp+0xD0]
000074c3551dded8  vmovaps xmm15, [rsp+0xE0]
000074c3551ddee1  add rsp, 0xF0
000074c3551ddee8  pop r11
000074c3551ddeea  pop r10
000074c3551ddeec  pop r9
000074c3551ddeee  pop r8
000074c3551ddef0  pop rsi
000074c3551ddef1  pop rdi
000074c3551ddef2  pop rdx
000074c3551ddef3  pop rcx
000074c3551ddef4  pop rax
000074c3551ddef5  add rsp, 0x08
000074c3551ddef9  jmp 0x000074C3551DC030
000074c3551ddefe  sub rsp, 0x08
000074c3551ddf02  push rax
000074c3551ddf03  push rcx
000074c3551ddf04  push rdx
000074c3551ddf05  push rdi
000074c3551ddf06  push rsi
000074c3551ddf07  push r8
000074c3551ddf09  push r9
000074c3551ddf0b  push r10
000074c3551ddf0d  push r11
000074c3551ddf0f  sub rsp, 0xF0
000074c3551ddf16  vmovaps [rsp], xmm0
000074c3551ddf1b  vmovaps [rsp+0x10], xmm1
000074c3551ddf21  vmovaps [rsp+0x20], xmm2
000074c3551ddf27  vmovaps [rsp+0x30], xmm3
000074c3551ddf2d  vmovaps [rsp+0x40], xmm4
000074c3551ddf33  vmovaps [rsp+0x50], xmm5
000074c3551ddf39  vmovaps [rsp+0x60], xmm6
000074c3551ddf3f  vmovaps [rsp+0x70], xmm8
000074c3551ddf45  vmovaps [rsp+0x80], xmm9
000074c3551ddf4e  vmovaps [rsp+0x90], xmm10
000074c3551ddf57  vmovaps [rsp+0xA0], xmm11
000074c3551ddf60  vmovaps [rsp+0xB0], xmm12
000074c3551ddf69  vmovaps [rsp+0xC0], xmm13
000074c3551ddf72  vmovaps [rsp+0xD0], xmm14
000074c3551ddf7b  vmovaps [rsp+0xE0], xmm15
000074c3551ddf84  sub rsp, 0x30
000074c3551ddf88  movaps [rsp], xmm7
000074c3551ddf8c  movaps [rsp+0x10], xmm5
000074c3551ddf91  movaps [rsp+0x20], xmm15
000074c3551ddf97  lea rdi, [rsp]
000074c3551ddf9b  mov esi, 0x00
000074c3551ddfa0  mov rax, 0x5F9407FA9530
000074c3551ddfaa  call rax
000074c3551ddfac  movaps xmm7, [rsp]
000074c3551ddfb0  add rsp, 0x30
000074c3551ddfb4  vmovaps xmm0, [rsp]
000074c3551ddfb9  vmovaps xmm1, [rsp+0x10]
000074c3551ddfbf  vmovaps xmm2, [rsp+0x20]
000074c3551ddfc5  vmovaps xmm3, [rsp+0x30]
000074c3551ddfcb  vmovaps xmm4, [rsp+0x40]
000074c3551ddfd1  vmovaps xmm5, [rsp+0x50]
000074c3551ddfd7  vmovaps xmm6, [rsp+0x60]
000074c3551ddfdd  vmovaps xmm8, [rsp+0x70]
000074c3551ddfe3  vmovaps xmm9, [rsp+0x80]
000074c3551ddfec  vmovaps xmm10, [rsp+0x90]
000074c3551ddff5  vmovaps xmm11, [rsp+0xA0]
000074c3551ddffe  vmovaps xmm12, [rsp+0xB0]
000074c3551de007  vmovaps xmm13, [rsp+0xC0]
000074c3551de010  vmovaps xmm14, [rsp+0xD0]
000074c3551de019  vmovaps xmm15, [rsp+0xE0]
000074c3551de022  add rsp, 0xF0
000074c3551de029  pop r11
000074c3551de02b  pop r10
000074c3551de02d  pop r9
000074c3551de02f  pop r8
000074c3551de031  pop rsi
000074c3551de032  pop rdi
000074c3551de033  pop rdx
000074c3551de034  pop rcx
000074c3551de035  pop rax
000074c3551de036  add rsp, 0x08
000074c3551de03a  jmp 0x000074C3551DC066
000074c3551de03f  call 0x000074C3550B52F0
000074c3551de044  jmp 0x000074C3551DC073
000074c3551de049  sub rsp, 0x08
000074c3551de04d  push rax
000074c3551de04e  push rcx
000074c3551de04f  push rdx
000074c3551de050  push rdi
000074c3551de051  push rsi
000074c3551de052  push r8
000074c3551de054  push r9
000074c3551de056  push r10
000074c3551de058  push r11
000074c3551de05a  sub rsp, 0xF0
000074c3551de061  vmovaps [rsp], xmm0
000074c3551de066  vmovaps [rsp+0x10], xmm1
000074c3551de06c  vmovaps [rsp+0x20], xmm2
000074c3551de072  vmovaps [rsp+0x30], xmm3
000074c3551de078  vmovaps [rsp+0x40], xmm4
000074c3551de07e  vmovaps [rsp+0x50], xmm5
000074c3551de084  vmovaps [rsp+0x60], xmm6
000074c3551de08a  vmovaps [rsp+0x70], xmm7
000074c3551de090  vmovaps [rsp+0x80], xmm8
000074c3551de099  vmovaps [rsp+0x90], xmm9
000074c3551de0a2  vmovaps [rsp+0xA0], xmm10
000074c3551de0ab  vmovaps [rsp+0xB0], xmm11
000074c3551de0b4  vmovaps [rsp+0xC0], xmm12
000074c3551de0bd  vmovaps [rsp+0xD0], xmm13
000074c3551de0c6  vmovaps [rsp+0xE0], xmm14
000074c3551de0cf  sub rsp, 0x30
000074c3551de0d3  movaps [rsp], xmm15
000074c3551de0d8  movaps [rsp+0x10], xmm5
000074c3551de0dd  movaps [rsp+0x20], xmm3
000074c3551de0e2  lea rdi, [rsp]
000074c3551de0e6  mov esi, 0x00
000074c3551de0eb  mov rax, 0x5F9407FA9530
000074c3551de0f5  call rax
000074c3551de0f7  movaps xmm15, [rsp]
000074c3551de0fc  add rsp, 0x30
000074c3551de100  vmovaps xmm0, [rsp]
000074c3551de105  vmovaps xmm1, [rsp+0x10]
000074c3551de10b  vmovaps xmm2, [rsp+0x20]
000074c3551de111  vmovaps xmm3, [rsp+0x30]
000074c3551de117  vmovaps xmm4, [rsp+0x40]
000074c3551de11d  vmovaps xmm5, [rsp+0x50]
000074c3551de123  vmovaps xmm6, [rsp+0x60]
000074c3551de129  vmovaps xmm7, [rsp+0x70]
000074c3551de12f  vmovaps xmm8, [rsp+0x80]
000074c3551de138  vmovaps xmm9, [rsp+0x90]
000074c3551de141  vmovaps xmm10, [rsp+0xA0]
000074c3551de14a  vmovaps xmm11, [rsp+0xB0]
000074c3551de153  vmovaps xmm12, [rsp+0xC0]
000074c3551de15c  vmovaps xmm13, [rsp+0xD0]
000074c3551de165  vmovaps xmm14, [rsp+0xE0]
000074c3551de16e  add rsp, 0xF0
000074c3551de175  pop r11
000074c3551de177  pop r10
000074c3551de179  pop r9
000074c3551de17b  pop r8
000074c3551de17d  pop rsi
000074c3551de17e  pop rdi
000074c3551de17f  pop rdx
000074c3551de180  pop rcx
000074c3551de181  pop rax
000074c3551de182  add rsp, 0x08
000074c3551de186  jmp 0x000074C3551DC099
000074c3551de18b  sub rsp, 0x08
000074c3551de18f  push rax
000074c3551de190  push rcx
000074c3551de191  push rdx
000074c3551de192  push rdi
000074c3551de193  push rsi
000074c3551de194  push r8
000074c3551de196  push r9
000074c3551de198  push r10
000074c3551de19a  push r11
000074c3551de19c  sub rsp, 0xF0
000074c3551de1a3  vmovaps [rsp], xmm0
000074c3551de1a8  vmovaps [rsp+0x10], xmm2
000074c3551de1ae  vmovaps [rsp+0x20], xmm3
000074c3551de1b4  vmovaps [rsp+0x30], xmm4
000074c3551de1ba  vmovaps [rsp+0x40], xmm5
000074c3551de1c0  vmovaps [rsp+0x50], xmm6
000074c3551de1c6  vmovaps [rsp+0x60], xmm7
000074c3551de1cc  vmovaps [rsp+0x70], xmm8
000074c3551de1d2  vmovaps [rsp+0x80], xmm9
000074c3551de1db  vmovaps [rsp+0x90], xmm10
000074c3551de1e4  vmovaps [rsp+0xA0], xmm11
000074c3551de1ed  vmovaps [rsp+0xB0], xmm12
000074c3551de1f6  vmovaps [rsp+0xC0], xmm13
000074c3551de1ff  vmovaps [rsp+0xD0], xmm14
000074c3551de208  vmovaps [rsp+0xE0], xmm15
000074c3551de211  sub rsp, 0x30
000074c3551de215  movaps [rsp], xmm1
000074c3551de219  movaps [rsp+0x10], xmm5
000074c3551de21e  movaps [rsp+0x20], xmm4
000074c3551de223  lea rdi, [rsp]
000074c3551de227  mov esi, 0x00
000074c3551de22c  mov rax, 0x5F9407FA9530
000074c3551de236  call rax
000074c3551de238  movaps xmm1, [rsp]
000074c3551de23c  add rsp, 0x30
000074c3551de240  vmovaps xmm0, [rsp]
000074c3551de245  vmovaps xmm2, [rsp+0x10]
000074c3551de24b  vmovaps xmm3, [rsp+0x20]
000074c3551de251  vmovaps xmm4, [rsp+0x30]
000074c3551de257  vmovaps xmm5, [rsp+0x40]
000074c3551de25d  vmovaps xmm6, [rsp+0x50]
000074c3551de263  vmovaps xmm7, [rsp+0x60]
000074c3551de269  vmovaps xmm8, [rsp+0x70]
000074c3551de26f  vmovaps xmm9, [rsp+0x80]
000074c3551de278  vmovaps xmm10, [rsp+0x90]
000074c3551de281  vmovaps xmm11, [rsp+0xA0]
000074c3551de28a  vmovaps xmm12, [rsp+0xB0]
000074c3551de293  vmovaps xmm13, [rsp+0xC0]
000074c3551de29c  vmovaps xmm14, [rsp+0xD0]
000074c3551de2a5  vmovaps xmm15, [rsp+0xE0]
000074c3551de2ae  add rsp, 0xF0
000074c3551de2b5  pop r11
000074c3551de2b7  pop r10
000074c3551de2b9  pop r9
000074c3551de2bb  pop r8
000074c3551de2bd  pop rsi
000074c3551de2be  pop rdi
000074c3551de2bf  pop rdx
000074c3551de2c0  pop rcx
000074c3551de2c1  pop rax
000074c3551de2c2  add rsp, 0x08
000074c3551de2c6  jmp 0x000074C3551DC0B9
000074c3551de2cb  sub rsp, 0x08
000074c3551de2cf  push rax
000074c3551de2d0  push rcx
000074c3551de2d1  push rdx
000074c3551de2d2  push rdi
000074c3551de2d3  push rsi
000074c3551de2d4  push r8
000074c3551de2d6  push r9
000074c3551de2d8  push r10
000074c3551de2da  push r11
000074c3551de2dc  sub rsp, 0xF0
000074c3551de2e3  vmovaps [rsp], xmm0
000074c3551de2e8  vmovaps [rsp+0x10], xmm1
000074c3551de2ee  vmovaps [rsp+0x20], xmm2
000074c3551de2f4  vmovaps [rsp+0x30], xmm3
000074c3551de2fa  vmovaps [rsp+0x40], xmm5
000074c3551de300  vmovaps [rsp+0x50], xmm6
000074c3551de306  vmovaps [rsp+0x60], xmm7
000074c3551de30c  vmovaps [rsp+0x70], xmm8
000074c3551de312  vmovaps [rsp+0x80], xmm9
000074c3551de31b  vmovaps [rsp+0x90], xmm10
000074c3551de324  vmovaps [rsp+0xA0], xmm11
000074c3551de32d  vmovaps [rsp+0xB0], xmm12
000074c3551de336  vmovaps [rsp+0xC0], xmm13
000074c3551de33f  vmovaps [rsp+0xD0], xmm14
000074c3551de348  vmovaps [rsp+0xE0], xmm15
000074c3551de351  sub rsp, 0x30
000074c3551de355  movaps [rsp], xmm4
000074c3551de359  movaps [rsp+0x10], xmm3
000074c3551de35e  movaps [rsp+0x20], xmm5
000074c3551de363  lea rdi, [rsp]
000074c3551de367  mov esi, 0x00
000074c3551de36c  mov rax, 0x5F9407FA9530
000074c3551de376  call rax
000074c3551de378  movaps xmm4, [rsp]
000074c3551de37c  add rsp, 0x30
000074c3551de380  vmovaps xmm0, [rsp]
000074c3551de385  vmovaps xmm1, [rsp+0x10]
000074c3551de38b  vmovaps xmm2, [rsp+0x20]
000074c3551de391  vmovaps xmm3, [rsp+0x30]
000074c3551de397  vmovaps xmm5, [rsp+0x40]
000074c3551de39d  vmovaps xmm6, [rsp+0x50]
000074c3551de3a3  vmovaps xmm7, [rsp+0x60]
000074c3551de3a9  vmovaps xmm8, [rsp+0x70]
000074c3551de3af  vmovaps xmm9, [rsp+0x80]
000074c3551de3b8  vmovaps xmm10, [rsp+0x90]
000074c3551de3c1  vmovaps xmm11, [rsp+0xA0]
000074c3551de3ca  vmovaps xmm12, [rsp+0xB0]
000074c3551de3d3  vmovaps xmm13, [rsp+0xC0]
000074c3551de3dc  vmovaps xmm14, [rsp+0xD0]
000074c3551de3e5  vmovaps xmm15, [rsp+0xE0]
000074c3551de3ee  add rsp, 0xF0
000074c3551de3f5  pop r11
000074c3551de3f7  pop r10
000074c3551de3f9  pop r9
000074c3551de3fb  pop r8
000074c3551de3fd  pop rsi
000074c3551de3fe  pop rdi
000074c3551de3ff  pop rdx
000074c3551de400  pop rcx
000074c3551de401  pop rax
000074c3551de402  add rsp, 0x08
000074c3551de406  jmp 0x000074C3551DC107
000074c3551de40b  call 0x000074C3550B52F0
000074c3551de410  jmp 0x000074C3551DC114
000074c3551de415  sub rsp, 0x08
000074c3551de419  push rax
000074c3551de41a  push rcx
000074c3551de41b  push rdx
000074c3551de41c  push rdi
000074c3551de41d  push rsi
000074c3551de41e  push r8
000074c3551de420  push r9
000074c3551de422  push r10
000074c3551de424  push r11
000074c3551de426  sub rsp, 0xF0
000074c3551de42d  vmovaps [rsp], xmm0
000074c3551de432  vmovaps [rsp+0x10], xmm1
000074c3551de438  vmovaps [rsp+0x20], xmm2
000074c3551de43e  vmovaps [rsp+0x30], xmm3
000074c3551de444  vmovaps [rsp+0x40], xmm4
000074c3551de44a  vmovaps [rsp+0x50], xmm6
000074c3551de450  vmovaps [rsp+0x60], xmm7
000074c3551de456  vmovaps [rsp+0x70], xmm8
000074c3551de45c  vmovaps [rsp+0x80], xmm9
000074c3551de465  vmovaps [rsp+0x90], xmm10
000074c3551de46e  vmovaps [rsp+0xA0], xmm11
000074c3551de477  vmovaps [rsp+0xB0], xmm12
000074c3551de480  vmovaps [rsp+0xC0], xmm13
000074c3551de489  vmovaps [rsp+0xD0], xmm14
000074c3551de492  vmovaps [rsp+0xE0], xmm15
000074c3551de49b  sub rsp, 0x30
000074c3551de49f  movaps [rsp], xmm5
000074c3551de4a3  movaps [rsp+0x10], xmm6
000074c3551de4a8  movaps [rsp+0x20], xmm3
000074c3551de4ad  lea rdi, [rsp]
000074c3551de4b1  mov esi, 0x00
000074c3551de4b6  mov rax, 0x5F9407FA9530
000074c3551de4c0  call rax
000074c3551de4c2  movaps xmm5, [rsp]
000074c3551de4c6  add rsp, 0x30
000074c3551de4ca  vmovaps xmm0, [rsp]
000074c3551de4cf  vmovaps xmm1, [rsp+0x10]
000074c3551de4d5  vmovaps xmm2, [rsp+0x20]
000074c3551de4db  vmovaps xmm3, [rsp+0x30]
000074c3551de4e1  vmovaps xmm4, [rsp+0x40]
000074c3551de4e7  vmovaps xmm6, [rsp+0x50]
000074c3551de4ed  vmovaps xmm7, [rsp+0x60]
000074c3551de4f3  vmovaps xmm8, [rsp+0x70]
000074c3551de4f9  vmovaps xmm9, [rsp+0x80]
000074c3551de502  vmovaps xmm10, [rsp+0x90]
000074c3551de50b  vmovaps xmm11, [rsp+0xA0]
000074c3551de514  vmovaps xmm12, [rsp+0xB0]
000074c3551de51d  vmovaps xmm13, [rsp+0xC0]
000074c3551de526  vmovaps xmm14, [rsp+0xD0]
000074c3551de52f  vmovaps xmm15, [rsp+0xE0]
000074c3551de538  add rsp, 0xF0
000074c3551de53f  pop r11
000074c3551de541  pop r10
000074c3551de543  pop r9
000074c3551de545  pop r8
000074c3551de547  pop rsi
000074c3551de548  pop rdi
000074c3551de549  pop rdx
000074c3551de54a  pop rcx
000074c3551de54b  pop rax
000074c3551de54c  add rsp, 0x08
000074c3551de550  jmp 0x000074C3551DC13A
000074c3551de555  sub rsp, 0x08
000074c3551de559  push rax
000074c3551de55a  push rcx
000074c3551de55b  push rdx
000074c3551de55c  push rdi
000074c3551de55d  push rsi
000074c3551de55e  push r8
000074c3551de560  push r9
000074c3551de562  push r10
000074c3551de564  push r11
000074c3551de566  sub rsp, 0xF0
000074c3551de56d  vmovaps [rsp], xmm0
000074c3551de572  vmovaps [rsp+0x10], xmm1
000074c3551de578  vmovaps [rsp+0x20], xmm2
000074c3551de57e  vmovaps [rsp+0x30], xmm3
000074c3551de584  vmovaps [rsp+0x40], xmm4
000074c3551de58a  vmovaps [rsp+0x50], xmm5
000074c3551de590  vmovaps [rsp+0x60], xmm7
000074c3551de596  vmovaps [rsp+0x70], xmm8
000074c3551de59c  vmovaps [rsp+0x80], xmm9
000074c3551de5a5  vmovaps [rsp+0x90], xmm10
000074c3551de5ae  vmovaps [rsp+0xA0], xmm11
000074c3551de5b7  vmovaps [rsp+0xB0], xmm12
000074c3551de5c0  vmovaps [rsp+0xC0], xmm13
000074c3551de5c9  vmovaps [rsp+0xD0], xmm14
000074c3551de5d2  vmovaps [rsp+0xE0], xmm15
000074c3551de5db  sub rsp, 0x30
000074c3551de5df  movaps [rsp], xmm6
000074c3551de5e3  movaps [rsp+0x10], xmm9
000074c3551de5e9  movaps [rsp+0x20], xmm1
000074c3551de5ee  lea rdi, [rsp]
000074c3551de5f2  mov esi, 0x00
000074c3551de5f7  mov rax, 0x5F9407FA9530
000074c3551de601  call rax
000074c3551de603  movaps xmm6, [rsp]
000074c3551de607  add rsp, 0x30
000074c3551de60b  vmovaps xmm0, [rsp]
000074c3551de610  vmovaps xmm1, [rsp+0x10]
000074c3551de616  vmovaps xmm2, [rsp+0x20]
000074c3551de61c  vmovaps xmm3, [rsp+0x30]
000074c3551de622  vmovaps xmm4, [rsp+0x40]
000074c3551de628  vmovaps xmm5, [rsp+0x50]
000074c3551de62e  vmovaps xmm7, [rsp+0x60]
000074c3551de634  vmovaps xmm8, [rsp+0x70]
000074c3551de63a  vmovaps xmm9, [rsp+0x80]
000074c3551de643  vmovaps xmm10, [rsp+0x90]
000074c3551de64c  vmovaps xmm11, [rsp+0xA0]
000074c3551de655  vmovaps xmm12, [rsp+0xB0]
000074c3551de65e  vmovaps xmm13, [rsp+0xC0]
000074c3551de667  vmovaps xmm14, [rsp+0xD0]
000074c3551de670  vmovaps xmm15, [rsp+0xE0]
000074c3551de679  add rsp, 0xF0
000074c3551de680  pop r11
000074c3551de682  pop r10
000074c3551de684  pop r9
000074c3551de686  pop r8
000074c3551de688  pop rsi
000074c3551de689  pop rdi
000074c3551de68a  pop rdx
000074c3551de68b  pop rcx
000074c3551de68c  pop rax
000074c3551de68d  add rsp, 0x08
000074c3551de691  jmp 0x000074C3551DC15E
000074c3551de696  sub rsp, 0x08
000074c3551de69a  push rax
000074c3551de69b  push rcx
000074c3551de69c  push rdx
000074c3551de69d  push rdi
000074c3551de69e  push rsi
000074c3551de69f  push r8
000074c3551de6a1  push r9
000074c3551de6a3  push r10
000074c3551de6a5  push r11
000074c3551de6a7  sub rsp, 0xF0
000074c3551de6ae  vmovaps [rsp], xmm0
000074c3551de6b3  vmovaps [rsp+0x10], xmm1
000074c3551de6b9  vmovaps [rsp+0x20], xmm2
000074c3551de6bf  vmovaps [rsp+0x30], xmm3
000074c3551de6c5  vmovaps [rsp+0x40], xmm4
000074c3551de6cb  vmovaps [rsp+0x50], xmm5
000074c3551de6d1  vmovaps [rsp+0x60], xmm6
000074c3551de6d7  vmovaps [rsp+0x70], xmm7
000074c3551de6dd  vmovaps [rsp+0x80], xmm8
000074c3551de6e6  vmovaps [rsp+0x90], xmm10
000074c3551de6ef  vmovaps [rsp+0xA0], xmm11
000074c3551de6f8  vmovaps [rsp+0xB0], xmm12
000074c3551de701  vmovaps [rsp+0xC0], xmm13
000074c3551de70a  vmovaps [rsp+0xD0], xmm14
000074c3551de713  vmovaps [rsp+0xE0], xmm15
000074c3551de71c  sub rsp, 0x30
000074c3551de720  movaps [rsp], xmm9
000074c3551de725  movaps [rsp+0x10], xmm3
000074c3551de72a  movaps [rsp+0x20], xmm1
000074c3551de72f  lea rdi, [rsp]
000074c3551de733  mov esi, 0x00
000074c3551de738  mov rax, 0x5F9407FA9530
000074c3551de742  call rax
000074c3551de744  movaps xmm9, [rsp]
000074c3551de749  add rsp, 0x30
000074c3551de74d  vmovaps xmm0, [rsp]
000074c3551de752  vmovaps xmm1, [rsp+0x10]
000074c3551de758  vmovaps xmm2, [rsp+0x20]
000074c3551de75e  vmovaps xmm3, [rsp+0x30]
000074c3551de764  vmovaps xmm4, [rsp+0x40]
000074c3551de76a  vmovaps xmm5, [rsp+0x50]
000074c3551de770  vmovaps xmm6, [rsp+0x60]
000074c3551de776  vmovaps xmm7, [rsp+0x70]
000074c3551de77c  vmovaps xmm8, [rsp+0x80]
000074c3551de785  vmovaps xmm10, [rsp+0x90]
000074c3551de78e  vmovaps xmm11, [rsp+0xA0]
000074c3551de797  vmovaps xmm12, [rsp+0xB0]
000074c3551de7a0  vmovaps xmm13, [rsp+0xC0]
000074c3551de7a9  vmovaps xmm14, [rsp+0xD0]
000074c3551de7b2  vmovaps xmm15, [rsp+0xE0]
000074c3551de7bb  add rsp, 0xF0
000074c3551de7c2  pop r11
000074c3551de7c4  pop r10
000074c3551de7c6  pop r9
000074c3551de7c8  pop r8
000074c3551de7ca  pop rsi
000074c3551de7cb  pop rdi
000074c3551de7cc  pop rdx
000074c3551de7cd  pop rcx
000074c3551de7ce  pop rax
000074c3551de7cf  add rsp, 0x08
000074c3551de7d3  jmp 0x000074C3551DC1AA
000074c3551de7d8  call 0x000074C3550B52F0
000074c3551de7dd  jmp 0x000074C3551DC1B7
000074c3551de7e2  sub rsp, 0x08
000074c3551de7e6  push rax
000074c3551de7e7  push rcx
000074c3551de7e8  push rdx
000074c3551de7e9  push rdi
000074c3551de7ea  push rsi
000074c3551de7eb  push r8
000074c3551de7ed  push r9
000074c3551de7ef  push r10
000074c3551de7f1  push r11
000074c3551de7f3  sub rsp, 0xF0
000074c3551de7fa  vmovaps [rsp], xmm0
000074c3551de7ff  vmovaps [rsp+0x10], xmm1
000074c3551de805  vmovaps [rsp+0x20], xmm2
000074c3551de80b  vmovaps [rsp+0x30], xmm3
000074c3551de811  vmovaps [rsp+0x40], xmm4
000074c3551de817  vmovaps [rsp+0x50], xmm5
000074c3551de81d  vmovaps [rsp+0x60], xmm6
000074c3551de823  vmovaps [rsp+0x70], xmm7
000074c3551de829  vmovaps [rsp+0x80], xmm8
000074c3551de832  vmovaps [rsp+0x90], xmm9
000074c3551de83b  vmovaps [rsp+0xA0], xmm10
000074c3551de844  vmovaps [rsp+0xB0], xmm11
000074c3551de84d  vmovaps [rsp+0xC0], xmm12
000074c3551de856  vmovaps [rsp+0xD0], xmm13
000074c3551de85f  vmovaps [rsp+0xE0], xmm14
000074c3551de868  sub rsp, 0x30
000074c3551de86c  movaps [rsp], xmm15
000074c3551de871  movaps [rsp+0x10], xmm3
000074c3551de876  movaps [rsp+0x20], xmm7
000074c3551de87b  lea rdi, [rsp]
000074c3551de87f  mov esi, 0x00
000074c3551de884  mov rax, 0x5F9407FA9530
000074c3551de88e  call rax
000074c3551de890  movaps xmm15, [rsp]
000074c3551de895  add rsp, 0x30
000074c3551de899  vmovaps xmm0, [rsp]
000074c3551de89e  vmovaps xmm1, [rsp+0x10]
000074c3551de8a4  vmovaps xmm2, [rsp+0x20]
000074c3551de8aa  vmovaps xmm3, [rsp+0x30]
000074c3551de8b0  vmovaps xmm4, [rsp+0x40]
000074c3551de8b6  vmovaps xmm5, [rsp+0x50]
000074c3551de8bc  vmovaps xmm6, [rsp+0x60]
000074c3551de8c2  vmovaps xmm7, [rsp+0x70]
000074c3551de8c8  vmovaps xmm8, [rsp+0x80]
000074c3551de8d1  vmovaps xmm9, [rsp+0x90]
000074c3551de8da  vmovaps xmm10, [rsp+0xA0]
000074c3551de8e3  vmovaps xmm11, [rsp+0xB0]
000074c3551de8ec  vmovaps xmm12, [rsp+0xC0]
000074c3551de8f5  vmovaps xmm13, [rsp+0xD0]
000074c3551de8fe  vmovaps xmm14, [rsp+0xE0]
000074c3551de907  add rsp, 0xF0
000074c3551de90e  pop r11
000074c3551de910  pop r10
000074c3551de912  pop r9
000074c3551de914  pop r8
000074c3551de916  pop rsi
000074c3551de917  pop rdi
000074c3551de918  pop rdx
000074c3551de919  pop rcx
000074c3551de91a  pop rax
000074c3551de91b  add rsp, 0x08
000074c3551de91f  jmp 0x000074C3551DC1E3
000074c3551de924  sub rsp, 0x08
000074c3551de928  push rax
000074c3551de929  push rcx
000074c3551de92a  push rdx
000074c3551de92b  push rdi
000074c3551de92c  push rsi
000074c3551de92d  push r8
000074c3551de92f  push r9
000074c3551de931  push r10
000074c3551de933  push r11
000074c3551de935  sub rsp, 0xF0
000074c3551de93c  vmovaps [rsp], xmm0
000074c3551de941  vmovaps [rsp+0x10], xmm1
000074c3551de947  vmovaps [rsp+0x20], xmm2
000074c3551de94d  vmovaps [rsp+0x30], xmm4
000074c3551de953  vmovaps [rsp+0x40], xmm5
000074c3551de959  vmovaps [rsp+0x50], xmm6
000074c3551de95f  vmovaps [rsp+0x60], xmm7
000074c3551de965  vmovaps [rsp+0x70], xmm8
000074c3551de96b  vmovaps [rsp+0x80], xmm9
000074c3551de974  vmovaps [rsp+0x90], xmm10
000074c3551de97d  vmovaps [rsp+0xA0], xmm11
000074c3551de986  vmovaps [rsp+0xB0], xmm12
000074c3551de98f  vmovaps [rsp+0xC0], xmm13
000074c3551de998  vmovaps [rsp+0xD0], xmm14
000074c3551de9a1  vmovaps [rsp+0xE0], xmm15
000074c3551de9aa  sub rsp, 0x30
000074c3551de9ae  movaps [rsp], xmm3
000074c3551de9b2  movaps [rsp+0x10], xmm1
000074c3551de9b7  movaps [rsp+0x20], xmm15
000074c3551de9bd  lea rdi, [rsp]
000074c3551de9c1  mov esi, 0x00
000074c3551de9c6  mov rax, 0x5F9407FA9530
000074c3551de9d0  call rax
000074c3551de9d2  movaps xmm3, [rsp]
000074c3551de9d6  add rsp, 0x30
000074c3551de9da  vmovaps xmm0, [rsp]
000074c3551de9df  vmovaps xmm1, [rsp+0x10]
000074c3551de9e5  vmovaps xmm2, [rsp+0x20]
000074c3551de9eb  vmovaps xmm4, [rsp+0x30]
000074c3551de9f1  vmovaps xmm5, [rsp+0x40]
000074c3551de9f7  vmovaps xmm6, [rsp+0x50]
000074c3551de9fd  vmovaps xmm7, [rsp+0x60]
000074c3551dea03  vmovaps xmm8, [rsp+0x70]
000074c3551dea09  vmovaps xmm9, [rsp+0x80]
000074c3551dea12  vmovaps xmm10, [rsp+0x90]
000074c3551dea1b  vmovaps xmm11, [rsp+0xA0]
000074c3551dea24  vmovaps xmm12, [rsp+0xB0]
000074c3551dea2d  vmovaps xmm13, [rsp+0xC0]
000074c3551dea36  vmovaps xmm14, [rsp+0xD0]
000074c3551dea3f  vmovaps xmm15, [rsp+0xE0]
000074c3551dea48  add rsp, 0xF0
000074c3551dea4f  pop r11
000074c3551dea51  pop r10
000074c3551dea53  pop r9
000074c3551dea55  pop r8
000074c3551dea57  pop rsi
000074c3551dea58  pop rdi
000074c3551dea59  pop rdx
000074c3551dea5a  pop rcx
000074c3551dea5b  pop rax
000074c3551dea5c  add rsp, 0x08
000074c3551dea60  jmp 0x000074C3551DC272
000074c3551dea65  call 0x000074C3550B52F0
000074c3551dea6a  jmp 0x000074C3551DC27C
000074c3551dea6f  sub rsp, 0x08
000074c3551dea73  push rax
000074c3551dea74  push rcx
000074c3551dea75  push rdx
000074c3551dea76  push rdi
000074c3551dea77  push rsi
000074c3551dea78  push r8
000074c3551dea7a  push r9
000074c3551dea7c  push r10
000074c3551dea7e  push r11
000074c3551dea80  sub rsp, 0xF0
000074c3551dea87  vmovaps [rsp], xmm0
000074c3551dea8c  vmovaps [rsp+0x10], xmm1
000074c3551dea92  vmovaps [rsp+0x20], xmm2
000074c3551dea98  vmovaps [rsp+0x30], xmm3
000074c3551dea9e  vmovaps [rsp+0x40], xmm4
000074c3551deaa4  vmovaps [rsp+0x50], xmm5
000074c3551deaaa  vmovaps [rsp+0x60], xmm6
000074c3551deab0  vmovaps [rsp+0x70], xmm7
000074c3551deab6  vmovaps [rsp+0x80], xmm8
000074c3551deabf  vmovaps [rsp+0x90], xmm9
000074c3551deac8  vmovaps [rsp+0xA0], xmm10
000074c3551dead1  vmovaps [rsp+0xB0], xmm11
000074c3551deada  vmovaps [rsp+0xC0], xmm12
000074c3551deae3  vmovaps [rsp+0xD0], xmm13
000074c3551deaec  vmovaps [rsp+0xE0], xmm14
000074c3551deaf5  sub rsp, 0x30
000074c3551deaf9  movaps [rsp], xmm15
000074c3551deafe  movaps [rsp+0x10], xmm14
000074c3551deb04  movaps [rsp+0x20], xmm4
000074c3551deb09  lea rdi, [rsp]
000074c3551deb0d  mov esi, 0x00
000074c3551deb12  mov rax, 0x5F9407FA9530
000074c3551deb1c  call rax
000074c3551deb1e  movaps xmm15, [rsp]
000074c3551deb23  add rsp, 0x30
000074c3551deb27  vmovaps xmm0, [rsp]
000074c3551deb2c  vmovaps xmm1, [rsp+0x10]
000074c3551deb32  vmovaps xmm2, [rsp+0x20]
000074c3551deb38  vmovaps xmm3, [rsp+0x30]
000074c3551deb3e  vmovaps xmm4, [rsp+0x40]
000074c3551deb44  vmovaps xmm5, [rsp+0x50]
000074c3551deb4a  vmovaps xmm6, [rsp+0x60]
000074c3551deb50  vmovaps xmm7, [rsp+0x70]
000074c3551deb56  vmovaps xmm8, [rsp+0x80]
000074c3551deb5f  vmovaps xmm9, [rsp+0x90]
000074c3551deb68  vmovaps xmm10, [rsp+0xA0]
000074c3551deb71  vmovaps xmm11, [rsp+0xB0]
000074c3551deb7a  vmovaps xmm12, [rsp+0xC0]
000074c3551deb83  vmovaps xmm13, [rsp+0xD0]
000074c3551deb8c  vmovaps xmm14, [rsp+0xE0]
000074c3551deb95  add rsp, 0xF0
000074c3551deb9c  pop r11
000074c3551deb9e  pop r10
000074c3551deba0  pop r9
000074c3551deba2  pop r8
000074c3551deba4  pop rsi
000074c3551deba5  pop rdi
000074c3551deba6  pop rdx
000074c3551deba7  pop rcx
000074c3551deba8  pop rax
000074c3551deba9  add rsp, 0x08
000074c3551debad  jmp 0x000074C3551DC2AA
000074c3551debb2  sub rsp, 0x08
000074c3551debb6  push rax
000074c3551debb7  push rcx
000074c3551debb8  push rdx
000074c3551debb9  push rdi
000074c3551debba  push rsi
000074c3551debbb  push r8
000074c3551debbd  push r9
000074c3551debbf  push r10
000074c3551debc1  push r11
000074c3551debc3  sub rsp, 0xF0
000074c3551debca  vmovaps [rsp], xmm0
000074c3551debcf  vmovaps [rsp+0x10], xmm1
000074c3551debd5  vmovaps [rsp+0x20], xmm2
000074c3551debdb  vmovaps [rsp+0x30], xmm3
000074c3551debe1  vmovaps [rsp+0x40], xmm4
000074c3551debe7  vmovaps [rsp+0x50], xmm5
000074c3551debed  vmovaps [rsp+0x60], xmm6
000074c3551debf3  vmovaps [rsp+0x70], xmm7
000074c3551debf9  vmovaps [rsp+0x80], xmm8
000074c3551dec02  vmovaps [rsp+0x90], xmm9
000074c3551dec0b  vmovaps [rsp+0xA0], xmm10
000074c3551dec14  vmovaps [rsp+0xB0], xmm11
000074c3551dec1d  vmovaps [rsp+0xC0], xmm12
000074c3551dec26  vmovaps [rsp+0xD0], xmm13
000074c3551dec2f  vmovaps [rsp+0xE0], xmm15
000074c3551dec38  sub rsp, 0x30
000074c3551dec3c  movaps [rsp], xmm14
000074c3551dec41  movaps [rsp+0x10], xmm2
000074c3551dec46  movaps [rsp+0x20], xmm1
000074c3551dec4b  lea rdi, [rsp]
000074c3551dec4f  mov esi, 0x00
000074c3551dec54  mov rax, 0x5F9407FA9530
000074c3551dec5e  call rax
000074c3551dec60  movaps xmm14, [rsp]
000074c3551dec65  add rsp, 0x30
000074c3551dec69  vmovaps xmm0, [rsp]
000074c3551dec6e  vmovaps xmm1, [rsp+0x10]
000074c3551dec74  vmovaps xmm2, [rsp+0x20]
000074c3551dec7a  vmovaps xmm3, [rsp+0x30]
000074c3551dec80  vmovaps xmm4, [rsp+0x40]
000074c3551dec86  vmovaps xmm5, [rsp+0x50]
000074c3551dec8c  vmovaps xmm6, [rsp+0x60]
000074c3551dec92  vmovaps xmm7, [rsp+0x70]
000074c3551dec98  vmovaps xmm8, [rsp+0x80]
000074c3551deca1  vmovaps xmm9, [rsp+0x90]
000074c3551decaa  vmovaps xmm10, [rsp+0xA0]
000074c3551decb3  vmovaps xmm11, [rsp+0xB0]
000074c3551decbc  vmovaps xmm12, [rsp+0xC0]
000074c3551decc5  vmovaps xmm13, [rsp+0xD0]
000074c3551decce  vmovaps xmm15, [rsp+0xE0]
000074c3551decd7  add rsp, 0xF0
000074c3551decde  pop r11
000074c3551dece0  pop r10
000074c3551dece2  pop r9
000074c3551dece4  pop r8
000074c3551dece6  pop rsi
000074c3551dece7  pop rdi
000074c3551dece8  pop rdx
000074c3551dece9  pop rcx
000074c3551decea  pop rax
000074c3551deceb  add rsp, 0x08
000074c3551decef  jmp 0x000074C3551DC2D0
000074c3551decf4  sub rsp, 0x08
000074c3551decf8  push rax
000074c3551decf9  push rcx
000074c3551decfa  push rdx
000074c3551decfb  push rdi
000074c3551decfc  push rsi
000074c3551decfd  push r8
000074c3551decff  push r9
000074c3551ded01  push r10
000074c3551ded03  push r11
000074c3551ded05  sub rsp, 0xF0
000074c3551ded0c  vmovaps [rsp], xmm0
000074c3551ded11  vmovaps [rsp+0x10], xmm2
000074c3551ded17  vmovaps [rsp+0x20], xmm3
000074c3551ded1d  vmovaps [rsp+0x30], xmm4
000074c3551ded23  vmovaps [rsp+0x40], xmm5
000074c3551ded29  vmovaps [rsp+0x50], xmm6
000074c3551ded2f  vmovaps [rsp+0x60], xmm7
000074c3551ded35  vmovaps [rsp+0x70], xmm8
000074c3551ded3b  vmovaps [rsp+0x80], xmm9
000074c3551ded44  vmovaps [rsp+0x90], xmm10
000074c3551ded4d  vmovaps [rsp+0xA0], xmm11
000074c3551ded56  vmovaps [rsp+0xB0], xmm12
000074c3551ded5f  vmovaps [rsp+0xC0], xmm13
000074c3551ded68  vmovaps [rsp+0xD0], xmm14
000074c3551ded71  vmovaps [rsp+0xE0], xmm15
000074c3551ded7a  sub rsp, 0x30
000074c3551ded7e  movaps [rsp], xmm1
000074c3551ded82  movaps [rsp+0x10], xmm4
000074c3551ded87  movaps [rsp+0x20], xmm9
000074c3551ded8d  lea rdi, [rsp]
000074c3551ded91  mov esi, 0x00
000074c3551ded96  mov rax, 0x5F9407FA9530
000074c3551deda0  call rax
000074c3551deda2  movaps xmm1, [rsp]
000074c3551deda6  add rsp, 0x30
000074c3551dedaa  vmovaps xmm0, [rsp]
000074c3551dedaf  vmovaps xmm2, [rsp+0x10]
000074c3551dedb5  vmovaps xmm3, [rsp+0x20]
000074c3551dedbb  vmovaps xmm4, [rsp+0x30]
000074c3551dedc1  vmovaps xmm5, [rsp+0x40]
000074c3551dedc7  vmovaps xmm6, [rsp+0x50]
000074c3551dedcd  vmovaps xmm7, [rsp+0x60]
000074c3551dedd3  vmovaps xmm8, [rsp+0x70]
000074c3551dedd9  vmovaps xmm9, [rsp+0x80]
000074c3551dede2  vmovaps xmm10, [rsp+0x90]
000074c3551dedeb  vmovaps xmm11, [rsp+0xA0]
000074c3551dedf4  vmovaps xmm12, [rsp+0xB0]
000074c3551dedfd  vmovaps xmm13, [rsp+0xC0]
000074c3551dee06  vmovaps xmm14, [rsp+0xD0]
000074c3551dee0f  vmovaps xmm15, [rsp+0xE0]
000074c3551dee18  add rsp, 0xF0
000074c3551dee1f  pop r11
000074c3551dee21  pop r10
000074c3551dee23  pop r9
000074c3551dee25  pop r8
000074c3551dee27  pop rsi
000074c3551dee28  pop rdi
000074c3551dee29  pop rdx
000074c3551dee2a  pop rcx
000074c3551dee2b  pop rax
000074c3551dee2c  add rsp, 0x08
000074c3551dee30  jmp 0x000074C3551DC2EE
000074c3551dee35  sub rsp, 0x08
000074c3551dee39  push rax
000074c3551dee3a  push rcx
000074c3551dee3b  push rdx
000074c3551dee3c  push rdi
000074c3551dee3d  push rsi
000074c3551dee3e  push r8
000074c3551dee40  push r9
000074c3551dee42  push r10
000074c3551dee44  push r11
000074c3551dee46  sub rsp, 0xF0
000074c3551dee4d  vmovaps [rsp], xmm0
000074c3551dee52  vmovaps [rsp+0x10], xmm1
000074c3551dee58  vmovaps [rsp+0x20], xmm2
000074c3551dee5e  vmovaps [rsp+0x30], xmm3
000074c3551dee64  vmovaps [rsp+0x40], xmm5
000074c3551dee6a  vmovaps [rsp+0x50], xmm6
000074c3551dee70  vmovaps [rsp+0x60], xmm7
000074c3551dee76  vmovaps [rsp+0x70], xmm8
000074c3551dee7c  vmovaps [rsp+0x80], xmm9
000074c3551dee85  vmovaps [rsp+0x90], xmm10
000074c3551dee8e  vmovaps [rsp+0xA0], xmm11
000074c3551dee97  vmovaps [rsp+0xB0], xmm12
000074c3551deea0  vmovaps [rsp+0xC0], xmm13
000074c3551deea9  vmovaps [rsp+0xD0], xmm14
000074c3551deeb2  vmovaps [rsp+0xE0], xmm15
000074c3551deebb  sub rsp, 0x30
000074c3551deebf  movaps [rsp], xmm4
000074c3551deec3  movaps [rsp+0x10], xmm2
000074c3551deec8  movaps [rsp+0x20], xmm9
000074c3551deece  lea rdi, [rsp]
000074c3551deed2  mov esi, 0x00
000074c3551deed7  mov rax, 0x5F9407FA9530
000074c3551deee1  call rax
000074c3551deee3  movaps xmm4, [rsp]
000074c3551deee7  add rsp, 0x30
000074c3551deeeb  vmovaps xmm0, [rsp]
000074c3551deef0  vmovaps xmm1, [rsp+0x10]
000074c3551deef6  vmovaps xmm2, [rsp+0x20]
000074c3551deefc  vmovaps xmm3, [rsp+0x30]
000074c3551def02  vmovaps xmm5, [rsp+0x40]
000074c3551def08  vmovaps xmm6, [rsp+0x50]
000074c3551def0e  vmovaps xmm7, [rsp+0x60]
000074c3551def14  vmovaps xmm8, [rsp+0x70]
000074c3551def1a  vmovaps xmm9, [rsp+0x80]
000074c3551def23  vmovaps xmm10, [rsp+0x90]
000074c3551def2c  vmovaps xmm11, [rsp+0xA0]
000074c3551def35  vmovaps xmm12, [rsp+0xB0]
000074c3551def3e  vmovaps xmm13, [rsp+0xC0]
000074c3551def47  vmovaps xmm14, [rsp+0xD0]
000074c3551def50  vmovaps xmm15, [rsp+0xE0]
000074c3551def59  add rsp, 0xF0
000074c3551def60  pop r11
000074c3551def62  pop r10
000074c3551def64  pop r9
000074c3551def66  pop r8
000074c3551def68  pop rsi
000074c3551def69  pop rdi
000074c3551def6a  pop rdx
000074c3551def6b  pop rcx
000074c3551def6c  pop rax
000074c3551def6d  add rsp, 0x08
000074c3551def71  jmp 0x000074C3551DC31E
000074c3551def76  sub rsp, 0x08
000074c3551def7a  push rax
000074c3551def7b  push rcx
000074c3551def7c  push rdx
000074c3551def7d  push rdi
000074c3551def7e  push rsi
000074c3551def7f  push r8
000074c3551def81  push r9
000074c3551def83  push r10
000074c3551def85  push r11
000074c3551def87  sub rsp, 0xF0
000074c3551def8e  vmovaps [rsp], xmm0
000074c3551def93  vmovaps [rsp+0x10], xmm1
000074c3551def99  vmovaps [rsp+0x20], xmm2
000074c3551def9f  vmovaps [rsp+0x30], xmm3
000074c3551defa5  vmovaps [rsp+0x40], xmm4
000074c3551defab  vmovaps [rsp+0x50], xmm5
000074c3551defb1  vmovaps [rsp+0x60], xmm6
000074c3551defb7  vmovaps [rsp+0x70], xmm7
000074c3551defbd  vmovaps [rsp+0x80], xmm8
000074c3551defc6  vmovaps [rsp+0x90], xmm10
000074c3551defcf  vmovaps [rsp+0xA0], xmm11
000074c3551defd8  vmovaps [rsp+0xB0], xmm12
000074c3551defe1  vmovaps [rsp+0xC0], xmm13
000074c3551defea  vmovaps [rsp+0xD0], xmm14
000074c3551deff3  vmovaps [rsp+0xE0], xmm15
000074c3551deffc  sub rsp, 0x30
000074c3551df000  movaps [rsp], xmm9
000074c3551df005  movaps [rsp+0x10], xmm2
000074c3551df00a  movaps [rsp+0x20], xmm1
000074c3551df00f  lea rdi, [rsp]
000074c3551df013  mov esi, 0x00
000074c3551df018  mov rax, 0x5F9407FA9530
000074c3551df022  call rax
000074c3551df024  movaps xmm9, [rsp]
000074c3551df029  add rsp, 0x30
000074c3551df02d  vmovaps xmm0, [rsp]
000074c3551df032  vmovaps xmm1, [rsp+0x10]
000074c3551df038  vmovaps xmm2, [rsp+0x20]
000074c3551df03e  vmovaps xmm3, [rsp+0x30]
000074c3551df044  vmovaps xmm4, [rsp+0x40]
000074c3551df04a  vmovaps xmm5, [rsp+0x50]
000074c3551df050  vmovaps xmm6, [rsp+0x60]
000074c3551df056  vmovaps xmm7, [rsp+0x70]
000074c3551df05c  vmovaps xmm8, [rsp+0x80]
000074c3551df065  vmovaps xmm10, [rsp+0x90]
000074c3551df06e  vmovaps xmm11, [rsp+0xA0]
000074c3551df077  vmovaps xmm12, [rsp+0xB0]
000074c3551df080  vmovaps xmm13, [rsp+0xC0]
000074c3551df089  vmovaps xmm14, [rsp+0xD0]
000074c3551df092  vmovaps xmm15, [rsp+0xE0]
000074c3551df09b  add rsp, 0xF0
000074c3551df0a2  pop r11
000074c3551df0a4  pop r10
000074c3551df0a6  pop r9
000074c3551df0a8  pop r8
000074c3551df0aa  pop rsi
000074c3551df0ab  pop rdi
000074c3551df0ac  pop rdx
000074c3551df0ad  pop rcx
000074c3551df0ae  pop rax
000074c3551df0af  add rsp, 0x08
000074c3551df0b3  jmp 0x000074C3551DC354
000074c3551df0b8  sub rsp, 0x08
000074c3551df0bc  push rax
000074c3551df0bd  push rcx
000074c3551df0be  push rdx
000074c3551df0bf  push rdi
000074c3551df0c0  push rsi
000074c3551df0c1  push r8
000074c3551df0c3  push r9
000074c3551df0c5  push r10
000074c3551df0c7  push r11
000074c3551df0c9  sub rsp, 0xF0
000074c3551df0d0  vmovaps [rsp], xmm0
000074c3551df0d5  vmovaps [rsp+0x10], xmm2
000074c3551df0db  vmovaps [rsp+0x20], xmm3
000074c3551df0e1  vmovaps [rsp+0x30], xmm4
000074c3551df0e7  vmovaps [rsp+0x40], xmm5
000074c3551df0ed  vmovaps [rsp+0x50], xmm6
000074c3551df0f3  vmovaps [rsp+0x60], xmm7
000074c3551df0f9  vmovaps [rsp+0x70], xmm8
000074c3551df0ff  vmovaps [rsp+0x80], xmm9
000074c3551df108  vmovaps [rsp+0x90], xmm10
000074c3551df111  vmovaps [rsp+0xA0], xmm11
000074c3551df11a  vmovaps [rsp+0xB0], xmm12
000074c3551df123  vmovaps [rsp+0xC0], xmm13
000074c3551df12c  vmovaps [rsp+0xD0], xmm14
000074c3551df135  vmovaps [rsp+0xE0], xmm15
000074c3551df13e  sub rsp, 0x30
000074c3551df142  movaps [rsp], xmm1
000074c3551df146  movaps [rsp+0x10], xmm15
000074c3551df14c  movaps [rsp+0x20], xmm6
000074c3551df151  lea rdi, [rsp]
000074c3551df155  mov esi, 0x00
000074c3551df15a  mov rax, 0x5F9407FA9530
000074c3551df164  call rax
000074c3551df166  movaps xmm1, [rsp]
000074c3551df16a  add rsp, 0x30
000074c3551df16e  vmovaps xmm0, [rsp]
000074c3551df173  vmovaps xmm2, [rsp+0x10]
000074c3551df179  vmovaps xmm3, [rsp+0x20]
000074c3551df17f  vmovaps xmm4, [rsp+0x30]
000074c3551df185  vmovaps xmm5, [rsp+0x40]
000074c3551df18b  vmovaps xmm6, [rsp+0x50]
000074c3551df191  vmovaps xmm7, [rsp+0x60]
000074c3551df197  vmovaps xmm8, [rsp+0x70]
000074c3551df19d  vmovaps xmm9, [rsp+0x80]
000074c3551df1a6  vmovaps xmm10, [rsp+0x90]
000074c3551df1af  vmovaps xmm11, [rsp+0xA0]
000074c3551df1b8  vmovaps xmm12, [rsp+0xB0]
000074c3551df1c1  vmovaps xmm13, [rsp+0xC0]
000074c3551df1ca  vmovaps xmm14, [rsp+0xD0]
000074c3551df1d3  vmovaps xmm15, [rsp+0xE0]
000074c3551df1dc  add rsp, 0xF0
000074c3551df1e3  pop r11
000074c3551df1e5  pop r10
000074c3551df1e7  pop r9
000074c3551df1e9  pop r8
000074c3551df1eb  pop rsi
000074c3551df1ec  pop rdi
000074c3551df1ed  pop rdx
000074c3551df1ee  pop rcx
000074c3551df1ef  pop rax
000074c3551df1f0  add rsp, 0x08
000074c3551df1f4  jmp 0x000074C3551DC375
000074c3551df1f9  sub rsp, 0x08
000074c3551df1fd  push rax
000074c3551df1fe  push rcx
000074c3551df1ff  push rdx
000074c3551df200  push rdi
000074c3551df201  push rsi
000074c3551df202  push r8
000074c3551df204  push r9
000074c3551df206  push r10
000074c3551df208  push r11
000074c3551df20a  sub rsp, 0xF0
000074c3551df211  vmovaps [rsp], xmm0
000074c3551df216  vmovaps [rsp+0x10], xmm1
000074c3551df21c  vmovaps [rsp+0x20], xmm2
000074c3551df222  vmovaps [rsp+0x30], xmm3
000074c3551df228  vmovaps [rsp+0x40], xmm4
000074c3551df22e  vmovaps [rsp+0x50], xmm5
000074c3551df234  vmovaps [rsp+0x60], xmm6
000074c3551df23a  vmovaps [rsp+0x70], xmm7
000074c3551df240  vmovaps [rsp+0x80], xmm8
000074c3551df249  vmovaps [rsp+0x90], xmm9
000074c3551df252  vmovaps [rsp+0xA0], xmm10
000074c3551df25b  vmovaps [rsp+0xB0], xmm11
000074c3551df264  vmovaps [rsp+0xC0], xmm12
000074c3551df26d  vmovaps [rsp+0xD0], xmm13
000074c3551df276  vmovaps [rsp+0xE0], xmm14
000074c3551df27f  sub rsp, 0x30
000074c3551df283  movaps [rsp], xmm15
000074c3551df288  movaps [rsp+0x10], xmm5
000074c3551df28d  movaps [rsp+0x20], xmm3
000074c3551df292  lea rdi, [rsp]
000074c3551df296  mov esi, 0x00
000074c3551df29b  mov rax, 0x5F9407FA9530
000074c3551df2a5  call rax
000074c3551df2a7  movaps xmm15, [rsp]
000074c3551df2ac  add rsp, 0x30
000074c3551df2b0  vmovaps xmm0, [rsp]
000074c3551df2b5  vmovaps xmm1, [rsp+0x10]
000074c3551df2bb  vmovaps xmm2, [rsp+0x20]
000074c3551df2c1  vmovaps xmm3, [rsp+0x30]
000074c3551df2c7  vmovaps xmm4, [rsp+0x40]
000074c3551df2cd  vmovaps xmm5, [rsp+0x50]
000074c3551df2d3  vmovaps xmm6, [rsp+0x60]
000074c3551df2d9  vmovaps xmm7, [rsp+0x70]
000074c3551df2df  vmovaps xmm8, [rsp+0x80]
000074c3551df2e8  vmovaps xmm9, [rsp+0x90]
000074c3551df2f1  vmovaps xmm10, [rsp+0xA0]
000074c3551df2fa  vmovaps xmm11, [rsp+0xB0]
000074c3551df303  vmovaps xmm12, [rsp+0xC0]
000074c3551df30c  vmovaps xmm13, [rsp+0xD0]
000074c3551df315  vmovaps xmm14, [rsp+0xE0]
000074c3551df31e  add rsp, 0xF0
000074c3551df325  pop r11
000074c3551df327  pop r10
000074c3551df329  pop r9
000074c3551df32b  pop r8
000074c3551df32d  pop rsi
000074c3551df32e  pop rdi
000074c3551df32f  pop rdx
000074c3551df330  pop rcx
000074c3551df331  pop rax
000074c3551df332  add rsp, 0x08
000074c3551df336  jmp 0x000074C3551DC38F
000074c3551df33b  sub rsp, 0x08
000074c3551df33f  push rax
000074c3551df340  push rcx
000074c3551df341  push rdx
000074c3551df342  push rdi
000074c3551df343  push rsi
000074c3551df344  push r8
000074c3551df346  push r9
000074c3551df348  push r10
000074c3551df34a  push r11
000074c3551df34c  sub rsp, 0xF0
000074c3551df353  vmovaps [rsp], xmm0
000074c3551df358  vmovaps [rsp+0x10], xmm1
000074c3551df35e  vmovaps [rsp+0x20], xmm2
000074c3551df364  vmovaps [rsp+0x30], xmm3
000074c3551df36a  vmovaps [rsp+0x40], xmm4
000074c3551df370  vmovaps [rsp+0x50], xmm6
000074c3551df376  vmovaps [rsp+0x60], xmm7
000074c3551df37c  vmovaps [rsp+0x70], xmm8
000074c3551df382  vmovaps [rsp+0x80], xmm9
000074c3551df38b  vmovaps [rsp+0x90], xmm10
000074c3551df394  vmovaps [rsp+0xA0], xmm11
000074c3551df39d  vmovaps [rsp+0xB0], xmm12
000074c3551df3a6  vmovaps [rsp+0xC0], xmm13
000074c3551df3af  vmovaps [rsp+0xD0], xmm14
000074c3551df3b8  vmovaps [rsp+0xE0], xmm15
000074c3551df3c1  sub rsp, 0x30
000074c3551df3c5  movaps [rsp], xmm5
000074c3551df3c9  movaps [rsp+0x10], xmm8
000074c3551df3cf  movaps [rsp+0x20], xmm6
000074c3551df3d4  lea rdi, [rsp]
000074c3551df3d8  mov esi, 0x00
000074c3551df3dd  mov rax, 0x5F9407FA9530
000074c3551df3e7  call rax
000074c3551df3e9  movaps xmm5, [rsp]
000074c3551df3ed  add rsp, 0x30
000074c3551df3f1  vmovaps xmm0, [rsp]
000074c3551df3f6  vmovaps xmm1, [rsp+0x10]
000074c3551df3fc  vmovaps xmm2, [rsp+0x20]
000074c3551df402  vmovaps xmm3, [rsp+0x30]
000074c3551df408  vmovaps xmm4, [rsp+0x40]
000074c3551df40e  vmovaps xmm6, [rsp+0x50]
000074c3551df414  vmovaps xmm7, [rsp+0x60]
000074c3551df41a  vmovaps xmm8, [rsp+0x70]
000074c3551df420  vmovaps xmm9, [rsp+0x80]
000074c3551df429  vmovaps xmm10, [rsp+0x90]
000074c3551df432  vmovaps xmm11, [rsp+0xA0]
000074c3551df43b  vmovaps xmm12, [rsp+0xB0]
000074c3551df444  vmovaps xmm13, [rsp+0xC0]
000074c3551df44d  vmovaps xmm14, [rsp+0xD0]
000074c3551df456  vmovaps xmm15, [rsp+0xE0]
000074c3551df45f  add rsp, 0xF0
000074c3551df466  pop r11
000074c3551df468  pop r10
000074c3551df46a  pop r9
000074c3551df46c  pop r8
000074c3551df46e  pop rsi
000074c3551df46f  pop rdi
000074c3551df470  pop rdx
000074c3551df471  pop rcx
000074c3551df472  pop rax
000074c3551df473  add rsp, 0x08
000074c3551df477  jmp 0x000074C3551DC3B3
000074c3551df47c  sub rsp, 0x08
000074c3551df480  push rax
000074c3551df481  push rcx
000074c3551df482  push rdx
000074c3551df483  push rdi
000074c3551df484  push rsi
000074c3551df485  push r8
000074c3551df487  push r9
000074c3551df489  push r10
000074c3551df48b  push r11
000074c3551df48d  sub rsp, 0xF0
000074c3551df494  vmovaps [rsp], xmm0
000074c3551df499  vmovaps [rsp+0x10], xmm1
000074c3551df49f  vmovaps [rsp+0x20], xmm2
000074c3551df4a5  vmovaps [rsp+0x30], xmm3
000074c3551df4ab  vmovaps [rsp+0x40], xmm4
000074c3551df4b1  vmovaps [rsp+0x50], xmm5
000074c3551df4b7  vmovaps [rsp+0x60], xmm7
000074c3551df4bd  vmovaps [rsp+0x70], xmm8
000074c3551df4c3  vmovaps [rsp+0x80], xmm9
000074c3551df4cc  vmovaps [rsp+0x90], xmm10
000074c3551df4d5  vmovaps [rsp+0xA0], xmm11
000074c3551df4de  vmovaps [rsp+0xB0], xmm12
000074c3551df4e7  vmovaps [rsp+0xC0], xmm13
000074c3551df4f0  vmovaps [rsp+0xD0], xmm14
000074c3551df4f9  vmovaps [rsp+0xE0], xmm15
000074c3551df502  sub rsp, 0x30
000074c3551df506  movaps [rsp], xmm6
000074c3551df50a  movaps [rsp+0x10], xmm10
000074c3551df510  movaps [rsp+0x20], xmm8
000074c3551df516  lea rdi, [rsp]
000074c3551df51a  mov esi, 0x00
000074c3551df51f  mov rax, 0x5F9407FA9530
000074c3551df529  call rax
000074c3551df52b  movaps xmm6, [rsp]
000074c3551df52f  add rsp, 0x30
000074c3551df533  vmovaps xmm0, [rsp]
000074c3551df538  vmovaps xmm1, [rsp+0x10]
000074c3551df53e  vmovaps xmm2, [rsp+0x20]
000074c3551df544  vmovaps xmm3, [rsp+0x30]
000074c3551df54a  vmovaps xmm4, [rsp+0x40]
000074c3551df550  vmovaps xmm5, [rsp+0x50]
000074c3551df556  vmovaps xmm7, [rsp+0x60]
000074c3551df55c  vmovaps xmm8, [rsp+0x70]
000074c3551df562  vmovaps xmm9, [rsp+0x80]
000074c3551df56b  vmovaps xmm10, [rsp+0x90]
000074c3551df574  vmovaps xmm11, [rsp+0xA0]
000074c3551df57d  vmovaps xmm12, [rsp+0xB0]
000074c3551df586  vmovaps xmm13, [rsp+0xC0]
000074c3551df58f  vmovaps xmm14, [rsp+0xD0]
000074c3551df598  vmovaps xmm15, [rsp+0xE0]
000074c3551df5a1  add rsp, 0xF0
000074c3551df5a8  pop r11
000074c3551df5aa  pop r10
000074c3551df5ac  pop r9
000074c3551df5ae  pop r8
000074c3551df5b0  pop rsi
000074c3551df5b1  pop rdi
000074c3551df5b2  pop rdx
000074c3551df5b3  pop rcx
000074c3551df5b4  pop rax
000074c3551df5b5  add rsp, 0x08
000074c3551df5b9  jmp 0x000074C3551DC3D8
000074c3551df5be  sub rsp, 0x08
000074c3551df5c2  push rax
000074c3551df5c3  push rcx
000074c3551df5c4  push rdx
000074c3551df5c5  push rdi
000074c3551df5c6  push rsi
000074c3551df5c7  push r8
000074c3551df5c9  push r9
000074c3551df5cb  push r10
000074c3551df5cd  push r11
000074c3551df5cf  sub rsp, 0xF0
000074c3551df5d6  vmovaps [rsp], xmm0
000074c3551df5db  vmovaps [rsp+0x10], xmm1
000074c3551df5e1  vmovaps [rsp+0x20], xmm2
000074c3551df5e7  vmovaps [rsp+0x30], xmm3
000074c3551df5ed  vmovaps [rsp+0x40], xmm4
000074c3551df5f3  vmovaps [rsp+0x50], xmm5
000074c3551df5f9  vmovaps [rsp+0x60], xmm6
000074c3551df5ff  vmovaps [rsp+0x70], xmm7
000074c3551df605  vmovaps [rsp+0x80], xmm8
000074c3551df60e  vmovaps [rsp+0x90], xmm9
000074c3551df617  vmovaps [rsp+0xA0], xmm11
000074c3551df620  vmovaps [rsp+0xB0], xmm12
000074c3551df629  vmovaps [rsp+0xC0], xmm13
000074c3551df632  vmovaps [rsp+0xD0], xmm14
000074c3551df63b  vmovaps [rsp+0xE0], xmm15
000074c3551df644  sub rsp, 0x30
000074c3551df648  movaps [rsp], xmm10
000074c3551df64d  movaps [rsp+0x10], xmm8
000074c3551df653  movaps [rsp+0x20], xmm14
000074c3551df659  lea rdi, [rsp]
000074c3551df65d  mov esi, 0x00
000074c3551df662  mov rax, 0x5F9407FA9530
000074c3551df66c  call rax
000074c3551df66e  movaps xmm10, [rsp]
000074c3551df673  add rsp, 0x30
000074c3551df677  vmovaps xmm0, [rsp]
000074c3551df67c  vmovaps xmm1, [rsp+0x10]
000074c3551df682  vmovaps xmm2, [rsp+0x20]
000074c3551df688  vmovaps xmm3, [rsp+0x30]
000074c3551df68e  vmovaps xmm4, [rsp+0x40]
000074c3551df694  vmovaps xmm5, [rsp+0x50]
000074c3551df69a  vmovaps xmm6, [rsp+0x60]
000074c3551df6a0  vmovaps xmm7, [rsp+0x70]
000074c3551df6a6  vmovaps xmm8, [rsp+0x80]
000074c3551df6af  vmovaps xmm9, [rsp+0x90]
000074c3551df6b8  vmovaps xmm11, [rsp+0xA0]
000074c3551df6c1  vmovaps xmm12, [rsp+0xB0]
000074c3551df6ca  vmovaps xmm13, [rsp+0xC0]
000074c3551df6d3  vmovaps xmm14, [rsp+0xD0]
000074c3551df6dc  vmovaps xmm15, [rsp+0xE0]
000074c3551df6e5  add rsp, 0xF0
000074c3551df6ec  pop r11
000074c3551df6ee  pop r10
000074c3551df6f0  pop r9
000074c3551df6f2  pop r8
000074c3551df6f4  pop rsi
000074c3551df6f5  pop rdi
000074c3551df6f6  pop rdx
000074c3551df6f7  pop rcx
000074c3551df6f8  pop rax
000074c3551df6f9  add rsp, 0x08
000074c3551df6fd  jmp 0x000074C3551DC3F8
000074c3551df702  sub rsp, 0x08
000074c3551df706  push rax
000074c3551df707  push rcx
000074c3551df708  push rdx
000074c3551df709  push rdi
000074c3551df70a  push rsi
000074c3551df70b  push r8
000074c3551df70d  push r9
000074c3551df70f  push r10
000074c3551df711  push r11
000074c3551df713  sub rsp, 0xF0
000074c3551df71a  vmovaps [rsp], xmm0
000074c3551df71f  vmovaps [rsp+0x10], xmm1
000074c3551df725  vmovaps [rsp+0x20], xmm2
000074c3551df72b  vmovaps [rsp+0x30], xmm3
000074c3551df731  vmovaps [rsp+0x40], xmm4
000074c3551df737  vmovaps [rsp+0x50], xmm5
000074c3551df73d  vmovaps [rsp+0x60], xmm6
000074c3551df743  vmovaps [rsp+0x70], xmm7
000074c3551df749  vmovaps [rsp+0x80], xmm8
000074c3551df752  vmovaps [rsp+0x90], xmm9
000074c3551df75b  vmovaps [rsp+0xA0], xmm10
000074c3551df764  vmovaps [rsp+0xB0], xmm11
000074c3551df76d  vmovaps [rsp+0xC0], xmm12
000074c3551df776  vmovaps [rsp+0xD0], xmm13
000074c3551df77f  vmovaps [rsp+0xE0], xmm15
000074c3551df788  sub rsp, 0x30
000074c3551df78c  movaps [rsp], xmm14
000074c3551df791  movaps [rsp+0x10], xmm8
000074c3551df797  movaps [rsp+0x20], xmm4
000074c3551df79c  lea rdi, [rsp]
000074c3551df7a0  mov esi, 0x00
000074c3551df7a5  mov rax, 0x5F9407FA9530
000074c3551df7af  call rax
000074c3551df7b1  movaps xmm14, [rsp]
000074c3551df7b6  add rsp, 0x30
000074c3551df7ba  vmovaps xmm0, [rsp]
000074c3551df7bf  vmovaps xmm1, [rsp+0x10]
000074c3551df7c5  vmovaps xmm2, [rsp+0x20]
000074c3551df7cb  vmovaps xmm3, [rsp+0x30]
000074c3551df7d1  vmovaps xmm4, [rsp+0x40]
000074c3551df7d7  vmovaps xmm5, [rsp+0x50]
000074c3551df7dd  vmovaps xmm6, [rsp+0x60]
000074c3551df7e3  vmovaps xmm7, [rsp+0x70]
000074c3551df7e9  vmovaps xmm8, [rsp+0x80]
000074c3551df7f2  vmovaps xmm9, [rsp+0x90]
000074c3551df7fb  vmovaps xmm10, [rsp+0xA0]
000074c3551df804  vmovaps xmm11, [rsp+0xB0]
000074c3551df80d  vmovaps xmm12, [rsp+0xC0]
000074c3551df816  vmovaps xmm13, [rsp+0xD0]
000074c3551df81f  vmovaps xmm15, [rsp+0xE0]
000074c3551df828  add rsp, 0xF0
000074c3551df82f  pop r11
000074c3551df831  pop r10
000074c3551df833  pop r9
000074c3551df835  pop r8
000074c3551df837  pop rsi
000074c3551df838  pop rdi
000074c3551df839  pop rdx
000074c3551df83a  pop rcx
000074c3551df83b  pop rax
000074c3551df83c  add rsp, 0x08
000074c3551df840  jmp 0x000074C3551DC418
000074c3551df845  sub rsp, 0x08
000074c3551df849  push rax
000074c3551df84a  push rcx
000074c3551df84b  push rdx
000074c3551df84c  push rdi
000074c3551df84d  push rsi
000074c3551df84e  push r8
000074c3551df850  push r9
000074c3551df852  push r10
000074c3551df854  push r11
000074c3551df856  sub rsp, 0xF0
000074c3551df85d  vmovaps [rsp], xmm0
000074c3551df862  vmovaps [rsp+0x10], xmm1
000074c3551df868  vmovaps [rsp+0x20], xmm2
000074c3551df86e  vmovaps [rsp+0x30], xmm3
000074c3551df874  vmovaps [rsp+0x40], xmm5
000074c3551df87a  vmovaps [rsp+0x50], xmm6
000074c3551df880  vmovaps [rsp+0x60], xmm7
000074c3551df886  vmovaps [rsp+0x70], xmm8
000074c3551df88c  vmovaps [rsp+0x80], xmm9
000074c3551df895  vmovaps [rsp+0x90], xmm10
000074c3551df89e  vmovaps [rsp+0xA0], xmm11
000074c3551df8a7  vmovaps [rsp+0xB0], xmm12
000074c3551df8b0  vmovaps [rsp+0xC0], xmm13
000074c3551df8b9  vmovaps [rsp+0xD0], xmm14
000074c3551df8c2  vmovaps [rsp+0xE0], xmm15
000074c3551df8cb  sub rsp, 0x30
000074c3551df8cf  movaps [rsp], xmm4
000074c3551df8d3  movaps [rsp+0x10], xmm13
000074c3551df8d9  movaps [rsp+0x20], xmm8
000074c3551df8df  lea rdi, [rsp]
000074c3551df8e3  mov esi, 0x00
000074c3551df8e8  mov rax, 0x5F9407FA9530
000074c3551df8f2  call rax
000074c3551df8f4  movaps xmm4, [rsp]
000074c3551df8f8  add rsp, 0x30
000074c3551df8fc  vmovaps xmm0, [rsp]
000074c3551df901  vmovaps xmm1, [rsp+0x10]
000074c3551df907  vmovaps xmm2, [rsp+0x20]
000074c3551df90d  vmovaps xmm3, [rsp+0x30]
000074c3551df913  vmovaps xmm5, [rsp+0x40]
000074c3551df919  vmovaps xmm6, [rsp+0x50]
000074c3551df91f  vmovaps xmm7, [rsp+0x60]
000074c3551df925  vmovaps xmm8, [rsp+0x70]
000074c3551df92b  vmovaps xmm9, [rsp+0x80]
000074c3551df934  vmovaps xmm10, [rsp+0x90]
000074c3551df93d  vmovaps xmm11, [rsp+0xA0]
000074c3551df946  vmovaps xmm12, [rsp+0xB0]
000074c3551df94f  vmovaps xmm13, [rsp+0xC0]
000074c3551df958  vmovaps xmm14, [rsp+0xD0]
000074c3551df961  vmovaps xmm15, [rsp+0xE0]
000074c3551df96a  add rsp, 0xF0
000074c3551df971  pop r11
000074c3551df973  pop r10
000074c3551df975  pop r9
000074c3551df977  pop r8
000074c3551df979  pop rsi
000074c3551df97a  pop rdi
000074c3551df97b  pop rdx
000074c3551df97c  pop rcx
000074c3551df97d  pop rax
000074c3551df97e  add rsp, 0x08
000074c3551df982  jmp 0x000074C3551DC43D
000074c3551df987  sub rsp, 0x08
000074c3551df98b  push rax
000074c3551df98c  push rcx
000074c3551df98d  push rdx
000074c3551df98e  push rdi
000074c3551df98f  push rsi
000074c3551df990  push r8
000074c3551df992  push r9
000074c3551df994  push r10
000074c3551df996  push r11
000074c3551df998  sub rsp, 0xF0
000074c3551df99f  vmovaps [rsp], xmm0
000074c3551df9a4  vmovaps [rsp+0x10], xmm1
000074c3551df9aa  vmovaps [rsp+0x20], xmm2
000074c3551df9b0  vmovaps [rsp+0x30], xmm3
000074c3551df9b6  vmovaps [rsp+0x40], xmm4
000074c3551df9bc  vmovaps [rsp+0x50], xmm5
000074c3551df9c2  vmovaps [rsp+0x60], xmm6
000074c3551df9c8  vmovaps [rsp+0x70], xmm7
000074c3551df9ce  vmovaps [rsp+0x80], xmm8
000074c3551df9d7  vmovaps [rsp+0x90], xmm9
000074c3551df9e0  vmovaps [rsp+0xA0], xmm10
000074c3551df9e9  vmovaps [rsp+0xB0], xmm11
000074c3551df9f2  vmovaps [rsp+0xC0], xmm12
000074c3551df9fb  vmovaps [rsp+0xD0], xmm14
000074c3551dfa04  vmovaps [rsp+0xE0], xmm15
000074c3551dfa0d  sub rsp, 0x30
000074c3551dfa11  movaps [rsp], xmm13
000074c3551dfa16  movaps [rsp+0x10], xmm15
000074c3551dfa1c  movaps [rsp+0x20], xmm9
000074c3551dfa22  lea rdi, [rsp]
000074c3551dfa26  mov esi, 0x00
000074c3551dfa2b  mov rax, 0x5F9407FA9530
000074c3551dfa35  call rax
000074c3551dfa37  movaps xmm13, [rsp]
000074c3551dfa3c  add rsp, 0x30
000074c3551dfa40  vmovaps xmm0, [rsp]
000074c3551dfa45  vmovaps xmm1, [rsp+0x10]
000074c3551dfa4b  vmovaps xmm2, [rsp+0x20]
000074c3551dfa51  vmovaps xmm3, [rsp+0x30]
000074c3551dfa57  vmovaps xmm4, [rsp+0x40]
000074c3551dfa5d  vmovaps xmm5, [rsp+0x50]
000074c3551dfa63  vmovaps xmm6, [rsp+0x60]
000074c3551dfa69  vmovaps xmm7, [rsp+0x70]
000074c3551dfa6f  vmovaps xmm8, [rsp+0x80]
000074c3551dfa78  vmovaps xmm9, [rsp+0x90]
000074c3551dfa81  vmovaps xmm10, [rsp+0xA0]
000074c3551dfa8a  vmovaps xmm11, [rsp+0xB0]
000074c3551dfa93  vmovaps xmm12, [rsp+0xC0]
000074c3551dfa9c  vmovaps xmm14, [rsp+0xD0]
000074c3551dfaa5  vmovaps xmm15, [rsp+0xE0]
000074c3551dfaae  add rsp, 0xF0
000074c3551dfab5  pop r11
000074c3551dfab7  pop r10
000074c3551dfab9  pop r9
000074c3551dfabb  pop r8
000074c3551dfabd  pop rsi
000074c3551dfabe  pop rdi
000074c3551dfabf  pop rdx
000074c3551dfac0  pop rcx
000074c3551dfac1  pop rax
000074c3551dfac2  add rsp, 0x08
000074c3551dfac6  jmp 0x000074C3551DC458
000074c3551dfacb  sub rsp, 0x08
000074c3551dfacf  push rax
000074c3551dfad0  push rcx
000074c3551dfad1  push rdx
000074c3551dfad2  push rdi
000074c3551dfad3  push rsi
000074c3551dfad4  push r8
000074c3551dfad6  push r9
000074c3551dfad8  push r10
000074c3551dfada  push r11
000074c3551dfadc  sub rsp, 0xF0
000074c3551dfae3  vmovaps [rsp], xmm0
000074c3551dfae8  vmovaps [rsp+0x10], xmm1
000074c3551dfaee  vmovaps [rsp+0x20], xmm2
000074c3551dfaf4  vmovaps [rsp+0x30], xmm3
000074c3551dfafa  vmovaps [rsp+0x40], xmm4
000074c3551dfb00  vmovaps [rsp+0x50], xmm5
000074c3551dfb06  vmovaps [rsp+0x60], xmm6
000074c3551dfb0c  vmovaps [rsp+0x70], xmm7
000074c3551dfb12  vmovaps [rsp+0x80], xmm8
000074c3551dfb1b  vmovaps [rsp+0x90], xmm9
000074c3551dfb24  vmovaps [rsp+0xA0], xmm10
000074c3551dfb2d  vmovaps [rsp+0xB0], xmm11
000074c3551dfb36  vmovaps [rsp+0xC0], xmm12
000074c3551dfb3f  vmovaps [rsp+0xD0], xmm13
000074c3551dfb48  vmovaps [rsp+0xE0], xmm14
000074c3551dfb51  sub rsp, 0x30
000074c3551dfb55  movaps [rsp], xmm15
000074c3551dfb5a  movaps [rsp+0x10], xmm1
000074c3551dfb5f  movaps [rsp+0x20], xmm5
000074c3551dfb64  lea rdi, [rsp]
000074c3551dfb68  mov esi, 0x00
000074c3551dfb6d  mov rax, 0x5F9407FA9530
000074c3551dfb77  call rax
000074c3551dfb79  movaps xmm15, [rsp]
000074c3551dfb7e  add rsp, 0x30
000074c3551dfb82  vmovaps xmm0, [rsp]
000074c3551dfb87  vmovaps xmm1, [rsp+0x10]
000074c3551dfb8d  vmovaps xmm2, [rsp+0x20]
000074c3551dfb93  vmovaps xmm3, [rsp+0x30]
000074c3551dfb99  vmovaps xmm4, [rsp+0x40]
000074c3551dfb9f  vmovaps xmm5, [rsp+0x50]
000074c3551dfba5  vmovaps xmm6, [rsp+0x60]
000074c3551dfbab  vmovaps xmm7, [rsp+0x70]
000074c3551dfbb1  vmovaps xmm8, [rsp+0x80]
000074c3551dfbba  vmovaps xmm9, [rsp+0x90]
000074c3551dfbc3  vmovaps xmm10, [rsp+0xA0]
000074c3551dfbcc  vmovaps xmm11, [rsp+0xB0]
000074c3551dfbd5  vmovaps xmm12, [rsp+0xC0]
000074c3551dfbde  vmovaps xmm13, [rsp+0xD0]
000074c3551dfbe7  vmovaps xmm14, [rsp+0xE0]
000074c3551dfbf0  add rsp, 0xF0
000074c3551dfbf7  pop r11
000074c3551dfbf9  pop r10
000074c3551dfbfb  pop r9
000074c3551dfbfd  pop r8
000074c3551dfbff  pop rsi
000074c3551dfc00  pop rdi
000074c3551dfc01  pop rdx
000074c3551dfc02  pop rcx
000074c3551dfc03  pop rax
000074c3551dfc04  add rsp, 0x08
000074c3551dfc08  jmp 0x000074C3551DC473
000074c3551dfc0d  call 0x000074C3550B52F0
000074c3551dfc12  jmp 0x000074C3551DC4CE
000074c3551dfc17  sub rsp, 0x08
000074c3551dfc1b  push rax
000074c3551dfc1c  push rcx
000074c3551dfc1d  push rdx
000074c3551dfc1e  push rdi
000074c3551dfc1f  push rsi
000074c3551dfc20  push r8
000074c3551dfc22  push r9
000074c3551dfc24  push r10
000074c3551dfc26  push r11
000074c3551dfc28  sub rsp, 0xF0
000074c3551dfc2f  vmovaps [rsp], xmm0
000074c3551dfc34  vmovaps [rsp+0x10], xmm1
000074c3551dfc3a  vmovaps [rsp+0x20], xmm2
000074c3551dfc40  vmovaps [rsp+0x30], xmm3
000074c3551dfc46  vmovaps [rsp+0x40], xmm4
000074c3551dfc4c  vmovaps [rsp+0x50], xmm5
000074c3551dfc52  vmovaps [rsp+0x60], xmm6
000074c3551dfc58  vmovaps [rsp+0x70], xmm7
000074c3551dfc5e  vmovaps [rsp+0x80], xmm8
000074c3551dfc67  vmovaps [rsp+0x90], xmm10
000074c3551dfc70  vmovaps [rsp+0xA0], xmm11
000074c3551dfc79  vmovaps [rsp+0xB0], xmm12
000074c3551dfc82  vmovaps [rsp+0xC0], xmm13
000074c3551dfc8b  vmovaps [rsp+0xD0], xmm14
000074c3551dfc94  vmovaps [rsp+0xE0], xmm15
000074c3551dfc9d  sub rsp, 0x30
000074c3551dfca1  movaps [rsp], xmm9
000074c3551dfca6  movaps [rsp+0x10], xmm8
000074c3551dfcac  movaps [rsp+0x20], xmm11
000074c3551dfcb2  lea rdi, [rsp]
000074c3551dfcb6  mov esi, 0x00
000074c3551dfcbb  mov rax, 0x5F9407FA9530
000074c3551dfcc5  call rax
000074c3551dfcc7  movaps xmm9, [rsp]
000074c3551dfccc  add rsp, 0x30
000074c3551dfcd0  vmovaps xmm0, [rsp]
000074c3551dfcd5  vmovaps xmm1, [rsp+0x10]
000074c3551dfcdb  vmovaps xmm2, [rsp+0x20]
000074c3551dfce1  vmovaps xmm3, [rsp+0x30]
000074c3551dfce7  vmovaps xmm4, [rsp+0x40]
000074c3551dfced  vmovaps xmm5, [rsp+0x50]
000074c3551dfcf3  vmovaps xmm6, [rsp+0x60]
000074c3551dfcf9  vmovaps xmm7, [rsp+0x70]
000074c3551dfcff  vmovaps xmm8, [rsp+0x80]
000074c3551dfd08  vmovaps xmm10, [rsp+0x90]
000074c3551dfd11  vmovaps xmm11, [rsp+0xA0]
000074c3551dfd1a  vmovaps xmm12, [rsp+0xB0]
000074c3551dfd23  vmovaps xmm13, [rsp+0xC0]
000074c3551dfd2c  vmovaps xmm14, [rsp+0xD0]
000074c3551dfd35  vmovaps xmm15, [rsp+0xE0]
000074c3551dfd3e  add rsp, 0xF0
000074c3551dfd45  pop r11
000074c3551dfd47  pop r10
000074c3551dfd49  pop r9
000074c3551dfd4b  pop r8
000074c3551dfd4d  pop rsi
000074c3551dfd4e  pop rdi
000074c3551dfd4f  pop rdx
000074c3551dfd50  pop rcx
000074c3551dfd51  pop rax
000074c3551dfd52  add rsp, 0x08
000074c3551dfd56  jmp 0x000074C3551DC505
000074c3551dfd5b  sub rsp, 0x08
000074c3551dfd5f  push rax
000074c3551dfd60  push rcx
000074c3551dfd61  push rdx
000074c3551dfd62  push rdi
000074c3551dfd63  push rsi
000074c3551dfd64  push r8
000074c3551dfd66  push r9
000074c3551dfd68  push r10
000074c3551dfd6a  push r11
000074c3551dfd6c  sub rsp, 0xF0
000074c3551dfd73  vmovaps [rsp], xmm0
000074c3551dfd78  vmovaps [rsp+0x10], xmm1
000074c3551dfd7e  vmovaps [rsp+0x20], xmm2
000074c3551dfd84  vmovaps [rsp+0x30], xmm3
000074c3551dfd8a  vmovaps [rsp+0x40], xmm4
000074c3551dfd90  vmovaps [rsp+0x50], xmm5
000074c3551dfd96  vmovaps [rsp+0x60], xmm6
000074c3551dfd9c  vmovaps [rsp+0x70], xmm7
000074c3551dfda2  vmovaps [rsp+0x80], xmm8
000074c3551dfdab  vmovaps [rsp+0x90], xmm9
000074c3551dfdb4  vmovaps [rsp+0xA0], xmm10
000074c3551dfdbd  vmovaps [rsp+0xB0], xmm12
000074c3551dfdc6  vmovaps [rsp+0xC0], xmm13
000074c3551dfdcf  vmovaps [rsp+0xD0], xmm14
000074c3551dfdd8  vmovaps [rsp+0xE0], xmm15
000074c3551dfde1  sub rsp, 0x30
000074c3551dfde5  movaps [rsp], xmm11
000074c3551dfdea  movaps [rsp+0x10], xmm10
000074c3551dfdf0  movaps [rsp+0x20], xmm6
000074c3551dfdf5  lea rdi, [rsp]
000074c3551dfdf9  mov esi, 0x00
000074c3551dfdfe  mov rax, 0x5F9407FA9530
000074c3551dfe08  call rax
000074c3551dfe0a  movaps xmm11, [rsp]
000074c3551dfe0f  add rsp, 0x30
000074c3551dfe13  vmovaps xmm0, [rsp]
000074c3551dfe18  vmovaps xmm1, [rsp+0x10]
000074c3551dfe1e  vmovaps xmm2, [rsp+0x20]
000074c3551dfe24  vmovaps xmm3, [rsp+0x30]
000074c3551dfe2a  vmovaps xmm4, [rsp+0x40]
000074c3551dfe30  vmovaps xmm5, [rsp+0x50]
000074c3551dfe36  vmovaps xmm6, [rsp+0x60]
000074c3551dfe3c  vmovaps xmm7, [rsp+0x70]
000074c3551dfe42  vmovaps xmm8, [rsp+0x80]
000074c3551dfe4b  vmovaps xmm9, [rsp+0x90]
000074c3551dfe54  vmovaps xmm10, [rsp+0xA0]
000074c3551dfe5d  vmovaps xmm12, [rsp+0xB0]
000074c3551dfe66  vmovaps xmm13, [rsp+0xC0]
000074c3551dfe6f  vmovaps xmm14, [rsp+0xD0]
000074c3551dfe78  vmovaps xmm15, [rsp+0xE0]
000074c3551dfe81  add rsp, 0xF0
000074c3551dfe88  pop r11
000074c3551dfe8a  pop r10
000074c3551dfe8c  pop r9
000074c3551dfe8e  pop r8
000074c3551dfe90  pop rsi
000074c3551dfe91  pop rdi
000074c3551dfe92  pop rdx
000074c3551dfe93  pop rcx
000074c3551dfe94  pop rax
000074c3551dfe95  add rsp, 0x08
000074c3551dfe99  jmp 0x000074C3551DC520
000074c3551dfe9e  sub rsp, 0x08
000074c3551dfea2  push rax
000074c3551dfea3  push rcx
000074c3551dfea4  push rdx
000074c3551dfea5  push rdi
000074c3551dfea6  push rsi
000074c3551dfea7  push r8
000074c3551dfea9  push r9
000074c3551dfeab  push r10
000074c3551dfead  push r11
000074c3551dfeaf  sub rsp, 0xF0
000074c3551dfeb6  vmovaps [rsp], xmm0
000074c3551dfebb  vmovaps [rsp+0x10], xmm1
000074c3551dfec1  vmovaps [rsp+0x20], xmm2
000074c3551dfec7  vmovaps [rsp+0x30], xmm3
000074c3551dfecd  vmovaps [rsp+0x40], xmm4
000074c3551dfed3  vmovaps [rsp+0x50], xmm5
000074c3551dfed9  vmovaps [rsp+0x60], xmm6
000074c3551dfedf  vmovaps [rsp+0x70], xmm7
000074c3551dfee5  vmovaps [rsp+0x80], xmm8
000074c3551dfeee  vmovaps [rsp+0x90], xmm9
000074c3551dfef7  vmovaps [rsp+0xA0], xmm11
000074c3551dff00  vmovaps [rsp+0xB0], xmm12
000074c3551dff09  vmovaps [rsp+0xC0], xmm13
000074c3551dff12  vmovaps [rsp+0xD0], xmm14
000074c3551dff1b  vmovaps [rsp+0xE0], xmm15
000074c3551dff24  sub rsp, 0x30
000074c3551dff28  movaps [rsp], xmm10
000074c3551dff2d  movaps [rsp+0x10], xmm14
000074c3551dff33  movaps [rsp+0x20], xmm4
000074c3551dff38  lea rdi, [rsp]
000074c3551dff3c  mov esi, 0x00
000074c3551dff41  mov rax, 0x5F9407FA9530
000074c3551dff4b  call rax
000074c3551dff4d  movaps xmm10, [rsp]
000074c3551dff52  add rsp, 0x30
000074c3551dff56  vmovaps xmm0, [rsp]
000074c3551dff5b  vmovaps xmm1, [rsp+0x10]
000074c3551dff61  vmovaps xmm2, [rsp+0x20]
000074c3551dff67  vmovaps xmm3, [rsp+0x30]
000074c3551dff6d  vmovaps xmm4, [rsp+0x40]
000074c3551dff73  vmovaps xmm5, [rsp+0x50]
000074c3551dff79  vmovaps xmm6, [rsp+0x60]
000074c3551dff7f  vmovaps xmm7, [rsp+0x70]
000074c3551dff85  vmovaps xmm8, [rsp+0x80]
000074c3551dff8e  vmovaps xmm9, [rsp+0x90]
000074c3551dff97  vmovaps xmm11, [rsp+0xA0]
000074c3551dffa0  vmovaps xmm12, [rsp+0xB0]
000074c3551dffa9  vmovaps xmm13, [rsp+0xC0]
000074c3551dffb2  vmovaps xmm14, [rsp+0xD0]
000074c3551dffbb  vmovaps xmm15, [rsp+0xE0]
000074c3551dffc4  add rsp, 0xF0
000074c3551dffcb  pop r11
000074c3551dffcd  pop r10
000074c3551dffcf  pop r9
000074c3551dffd1  pop r8
000074c3551dffd3  pop rsi
000074c3551dffd4  pop rdi
000074c3551dffd5  pop rdx
000074c3551dffd6  pop rcx
000074c3551dffd7  pop rax
000074c3551dffd8  add rsp, 0x08
000074c3551dffdc  jmp 0x000074C3551DC53B
000074c3551dffe1  sub rsp, 0x08
000074c3551dffe5  push rax
000074c3551dffe6  push rcx
000074c3551dffe7  push rdx
000074c3551dffe8  push rdi
000074c3551dffe9  push rsi
000074c3551dffea  push r8
000074c3551dffec  push r9
000074c3551dffee  push r10
000074c3551dfff0  push r11
000074c3551dfff2  sub rsp, 0xF0
000074c3551dfff9  vmovaps [rsp], xmm0
000074c3551dfffe  vmovaps [rsp+0x10], xmm1
000074c3551e0004  vmovaps [rsp+0x20], xmm2
000074c3551e000a  vmovaps [rsp+0x30], xmm3
000074c3551e0010  vmovaps [rsp+0x40], xmm4
000074c3551e0016  vmovaps [rsp+0x50], xmm5
000074c3551e001c  vmovaps [rsp+0x60], xmm6
000074c3551e0022  vmovaps [rsp+0x70], xmm7
000074c3551e0028  vmovaps [rsp+0x80], xmm9
000074c3551e0031  vmovaps [rsp+0x90], xmm10
000074c3551e003a  vmovaps [rsp+0xA0], xmm11
000074c3551e0043  vmovaps [rsp+0xB0], xmm12
000074c3551e004c  vmovaps [rsp+0xC0], xmm13
000074c3551e0055  vmovaps [rsp+0xD0], xmm14
000074c3551e005e  vmovaps [rsp+0xE0], xmm15
000074c3551e0067  sub rsp, 0x30
000074c3551e006b  movaps [rsp], xmm8
000074c3551e0070  movaps [rsp+0x10], xmm1
000074c3551e0075  movaps [rsp+0x20], xmm14
000074c3551e007b  lea rdi, [rsp]
000074c3551e007f  mov esi, 0x00
000074c3551e0084  mov rax, 0x5F9407FA9530
000074c3551e008e  call rax
000074c3551e0090  movaps xmm8, [rsp]
000074c3551e0095  add rsp, 0x30
000074c3551e0099  vmovaps xmm0, [rsp]
000074c3551e009e  vmovaps xmm1, [rsp+0x10]
000074c3551e00a4  vmovaps xmm2, [rsp+0x20]
000074c3551e00aa  vmovaps xmm3, [rsp+0x30]
000074c3551e00b0  vmovaps xmm4, [rsp+0x40]
000074c3551e00b6  vmovaps xmm5, [rsp+0x50]
000074c3551e00bc  vmovaps xmm6, [rsp+0x60]
000074c3551e00c2  vmovaps xmm7, [rsp+0x70]
000074c3551e00c8  vmovaps xmm9, [rsp+0x80]
000074c3551e00d1  vmovaps xmm10, [rsp+0x90]
000074c3551e00da  vmovaps xmm11, [rsp+0xA0]
000074c3551e00e3  vmovaps xmm12, [rsp+0xB0]
000074c3551e00ec  vmovaps xmm13, [rsp+0xC0]
000074c3551e00f5  vmovaps xmm14, [rsp+0xD0]
000074c3551e00fe  vmovaps xmm15, [rsp+0xE0]
000074c3551e0107  add rsp, 0xF0
000074c3551e010e  pop r11
000074c3551e0110  pop r10
000074c3551e0112  pop r9
000074c3551e0114  pop r8
000074c3551e0116  pop rsi
000074c3551e0117  pop rdi
000074c3551e0118  pop rdx
000074c3551e0119  pop rcx
000074c3551e011a  pop rax
000074c3551e011b  add rsp, 0x08
000074c3551e011f  jmp 0x000074C3551DC561
000074c3551e0124  sub rsp, 0x08
000074c3551e0128  push rax
000074c3551e0129  push rcx
000074c3551e012a  push rdx
000074c3551e012b  push rdi
000074c3551e012c  push rsi
000074c3551e012d  push r8
000074c3551e012f  push r9
000074c3551e0131  push r10
000074c3551e0133  push r11
000074c3551e0135  sub rsp, 0xF0
000074c3551e013c  vmovaps [rsp], xmm0
000074c3551e0141  vmovaps [rsp+0x10], xmm1
000074c3551e0147  vmovaps [rsp+0x20], xmm2
000074c3551e014d  vmovaps [rsp+0x30], xmm3
000074c3551e0153  vmovaps [rsp+0x40], xmm4
000074c3551e0159  vmovaps [rsp+0x50], xmm5
000074c3551e015f  vmovaps [rsp+0x60], xmm7
000074c3551e0165  vmovaps [rsp+0x70], xmm8
000074c3551e016b  vmovaps [rsp+0x80], xmm9
000074c3551e0174  vmovaps [rsp+0x90], xmm10
000074c3551e017d  vmovaps [rsp+0xA0], xmm11
000074c3551e0186  vmovaps [rsp+0xB0], xmm12
000074c3551e018f  vmovaps [rsp+0xC0], xmm13
000074c3551e0198  vmovaps [rsp+0xD0], xmm14
000074c3551e01a1  vmovaps [rsp+0xE0], xmm15
000074c3551e01aa  sub rsp, 0x30
000074c3551e01ae  movaps [rsp], xmm6
000074c3551e01b2  movaps [rsp+0x10], xmm1
000074c3551e01b7  movaps [rsp+0x20], xmm14
000074c3551e01bd  lea rdi, [rsp]
000074c3551e01c1  mov esi, 0x00
000074c3551e01c6  mov rax, 0x5F9407FA9530
000074c3551e01d0  call rax
000074c3551e01d2  movaps xmm6, [rsp]
000074c3551e01d6  add rsp, 0x30
000074c3551e01da  vmovaps xmm0, [rsp]
000074c3551e01df  vmovaps xmm1, [rsp+0x10]
000074c3551e01e5  vmovaps xmm2, [rsp+0x20]
000074c3551e01eb  vmovaps xmm3, [rsp+0x30]
000074c3551e01f1  vmovaps xmm4, [rsp+0x40]
000074c3551e01f7  vmovaps xmm5, [rsp+0x50]
000074c3551e01fd  vmovaps xmm7, [rsp+0x60]
000074c3551e0203  vmovaps xmm8, [rsp+0x70]
000074c3551e0209  vmovaps xmm9, [rsp+0x80]
000074c3551e0212  vmovaps xmm10, [rsp+0x90]
000074c3551e021b  vmovaps xmm11, [rsp+0xA0]
000074c3551e0224  vmovaps xmm12, [rsp+0xB0]
000074c3551e022d  vmovaps xmm13, [rsp+0xC0]
000074c3551e0236  vmovaps xmm14, [rsp+0xD0]
000074c3551e023f  vmovaps xmm15, [rsp+0xE0]
000074c3551e0248  add rsp, 0xF0
000074c3551e024f  pop r11
000074c3551e0251  pop r10
000074c3551e0253  pop r9
000074c3551e0255  pop r8
000074c3551e0257  pop rsi
000074c3551e0258  pop rdi
000074c3551e0259  pop rdx
000074c3551e025a  pop rcx
000074c3551e025b  pop rax
000074c3551e025c  add rsp, 0x08
000074c3551e0260  jmp 0x000074C3551DC58D
000074c3551e0265  sub rsp, 0x08
000074c3551e0269  push rax
000074c3551e026a  push rcx
000074c3551e026b  push rdx
000074c3551e026c  push rdi
000074c3551e026d  push rsi
000074c3551e026e  push r8
000074c3551e0270  push r9
000074c3551e0272  push r10
000074c3551e0274  push r11
000074c3551e0276  sub rsp, 0xF0
000074c3551e027d  vmovaps [rsp], xmm0
000074c3551e0282  vmovaps [rsp+0x10], xmm1
000074c3551e0288  vmovaps [rsp+0x20], xmm2
000074c3551e028e  vmovaps [rsp+0x30], xmm3
000074c3551e0294  vmovaps [rsp+0x40], xmm4
000074c3551e029a  vmovaps [rsp+0x50], xmm5
000074c3551e02a0  vmovaps [rsp+0x60], xmm6
000074c3551e02a6  vmovaps [rsp+0x70], xmm7
000074c3551e02ac  vmovaps [rsp+0x80], xmm8
000074c3551e02b5  vmovaps [rsp+0x90], xmm9
000074c3551e02be  vmovaps [rsp+0xA0], xmm10
000074c3551e02c7  vmovaps [rsp+0xB0], xmm11
000074c3551e02d0  vmovaps [rsp+0xC0], xmm12
000074c3551e02d9  vmovaps [rsp+0xD0], xmm13
000074c3551e02e2  vmovaps [rsp+0xE0], xmm15
000074c3551e02eb  sub rsp, 0x30
000074c3551e02ef  movaps [rsp], xmm14
000074c3551e02f4  movaps [rsp+0x10], xmm12
000074c3551e02fa  movaps [rsp+0x20], xmm1
000074c3551e02ff  lea rdi, [rsp]
000074c3551e0303  mov esi, 0x00
000074c3551e0308  mov rax, 0x5F9407FA9530
000074c3551e0312  call rax
000074c3551e0314  movaps xmm14, [rsp]
000074c3551e0319  add rsp, 0x30
000074c3551e031d  vmovaps xmm0, [rsp]
000074c3551e0322  vmovaps xmm1, [rsp+0x10]
000074c3551e0328  vmovaps xmm2, [rsp+0x20]
000074c3551e032e  vmovaps xmm3, [rsp+0x30]
000074c3551e0334  vmovaps xmm4, [rsp+0x40]
000074c3551e033a  vmovaps xmm5, [rsp+0x50]
000074c3551e0340  vmovaps xmm6, [rsp+0x60]
000074c3551e0346  vmovaps xmm7, [rsp+0x70]
000074c3551e034c  vmovaps xmm8, [rsp+0x80]
000074c3551e0355  vmovaps xmm9, [rsp+0x90]
000074c3551e035e  vmovaps xmm10, [rsp+0xA0]
000074c3551e0367  vmovaps xmm11, [rsp+0xB0]
000074c3551e0370  vmovaps xmm12, [rsp+0xC0]
000074c3551e0379  vmovaps xmm13, [rsp+0xD0]
000074c3551e0382  vmovaps xmm15, [rsp+0xE0]
000074c3551e038b  add rsp, 0xF0
000074c3551e0392  pop r11
000074c3551e0394  pop r10
000074c3551e0396  pop r9
000074c3551e0398  pop r8
000074c3551e039a  pop rsi
000074c3551e039b  pop rdi
000074c3551e039c  pop rdx
000074c3551e039d  pop rcx
000074c3551e039e  pop rax
000074c3551e039f  add rsp, 0x08
000074c3551e03a3  jmp 0x000074C3551DC5B3
000074c3551e03a8  sub rsp, 0x08
000074c3551e03ac  push rax
000074c3551e03ad  push rcx
000074c3551e03ae  push rdx
000074c3551e03af  push rdi
000074c3551e03b0  push rsi
000074c3551e03b1  push r8
000074c3551e03b3  push r9
000074c3551e03b5  push r10
000074c3551e03b7  push r11
000074c3551e03b9  sub rsp, 0xF0
000074c3551e03c0  vmovaps [rsp], xmm0
000074c3551e03c5  vmovaps [rsp+0x10], xmm2
000074c3551e03cb  vmovaps [rsp+0x20], xmm3
000074c3551e03d1  vmovaps [rsp+0x30], xmm4
000074c3551e03d7  vmovaps [rsp+0x40], xmm5
000074c3551e03dd  vmovaps [rsp+0x50], xmm6
000074c3551e03e3  vmovaps [rsp+0x60], xmm7
000074c3551e03e9  vmovaps [rsp+0x70], xmm8
000074c3551e03ef  vmovaps [rsp+0x80], xmm9
000074c3551e03f8  vmovaps [rsp+0x90], xmm10
000074c3551e0401  vmovaps [rsp+0xA0], xmm11
000074c3551e040a  vmovaps [rsp+0xB0], xmm12
000074c3551e0413  vmovaps [rsp+0xC0], xmm13
000074c3551e041c  vmovaps [rsp+0xD0], xmm14
000074c3551e0425  vmovaps [rsp+0xE0], xmm15
000074c3551e042e  sub rsp, 0x30
000074c3551e0432  movaps [rsp], xmm1
000074c3551e0436  movaps [rsp+0x10], xmm13
000074c3551e043c  movaps [rsp+0x20], xmm9
000074c3551e0442  lea rdi, [rsp]
000074c3551e0446  mov esi, 0x00
000074c3551e044b  mov rax, 0x5F9407FA9530
000074c3551e0455  call rax
000074c3551e0457  movaps xmm1, [rsp]
000074c3551e045b  add rsp, 0x30
000074c3551e045f  vmovaps xmm0, [rsp]
000074c3551e0464  vmovaps xmm2, [rsp+0x10]
000074c3551e046a  vmovaps xmm3, [rsp+0x20]
000074c3551e0470  vmovaps xmm4, [rsp+0x30]
000074c3551e0476  vmovaps xmm5, [rsp+0x40]
000074c3551e047c  vmovaps xmm6, [rsp+0x50]
000074c3551e0482  vmovaps xmm7, [rsp+0x60]
000074c3551e0488  vmovaps xmm8, [rsp+0x70]
000074c3551e048e  vmovaps xmm9, [rsp+0x80]
000074c3551e0497  vmovaps xmm10, [rsp+0x90]
000074c3551e04a0  vmovaps xmm11, [rsp+0xA0]
000074c3551e04a9  vmovaps xmm12, [rsp+0xB0]
000074c3551e04b2  vmovaps xmm13, [rsp+0xC0]
000074c3551e04bb  vmovaps xmm14, [rsp+0xD0]
000074c3551e04c4  vmovaps xmm15, [rsp+0xE0]
000074c3551e04cd  add rsp, 0xF0
000074c3551e04d4  pop r11
000074c3551e04d6  pop r10
000074c3551e04d8  pop r9
000074c3551e04da  pop r8
000074c3551e04dc  pop rsi
000074c3551e04dd  pop rdi
000074c3551e04de  pop rdx
000074c3551e04df  pop rcx
000074c3551e04e0  pop rax
000074c3551e04e1  add rsp, 0x08
000074c3551e04e5  jmp 0x000074C3551DC5CD
000074c3551e04ea  sub rsp, 0x08
000074c3551e04ee  push rax
000074c3551e04ef  push rcx
000074c3551e04f0  push rdx
000074c3551e04f1  push rdi
000074c3551e04f2  push rsi
000074c3551e04f3  push r8
000074c3551e04f5  push r9
000074c3551e04f7  push r10
000074c3551e04f9  push r11
000074c3551e04fb  sub rsp, 0xF0
000074c3551e0502  vmovaps [rsp], xmm0
000074c3551e0507  vmovaps [rsp+0x10], xmm1
000074c3551e050d  vmovaps [rsp+0x20], xmm2
000074c3551e0513  vmovaps [rsp+0x30], xmm3
000074c3551e0519  vmovaps [rsp+0x40], xmm4
000074c3551e051f  vmovaps [rsp+0x50], xmm5
000074c3551e0525  vmovaps [rsp+0x60], xmm6
000074c3551e052b  vmovaps [rsp+0x70], xmm7
000074c3551e0531  vmovaps [rsp+0x80], xmm8
000074c3551e053a  vmovaps [rsp+0x90], xmm9
000074c3551e0543  vmovaps [rsp+0xA0], xmm10
000074c3551e054c  vmovaps [rsp+0xB0], xmm11
000074c3551e0555  vmovaps [rsp+0xC0], xmm13
000074c3551e055e  vmovaps [rsp+0xD0], xmm14
000074c3551e0567  vmovaps [rsp+0xE0], xmm15
000074c3551e0570  sub rsp, 0x30
000074c3551e0574  movaps [rsp], xmm12
000074c3551e0579  movaps [rsp+0x10], xmm7
000074c3551e057e  movaps [rsp+0x20], xmm13
000074c3551e0584  lea rdi, [rsp]
000074c3551e0588  mov esi, 0x00
000074c3551e058d  mov rax, 0x5F9407FA9530
000074c3551e0597  call rax
000074c3551e0599  movaps xmm12, [rsp]
000074c3551e059e  add rsp, 0x30
000074c3551e05a2  vmovaps xmm0, [rsp]
000074c3551e05a7  vmovaps xmm1, [rsp+0x10]
000074c3551e05ad  vmovaps xmm2, [rsp+0x20]
000074c3551e05b3  vmovaps xmm3, [rsp+0x30]
000074c3551e05b9  vmovaps xmm4, [rsp+0x40]
000074c3551e05bf  vmovaps xmm5, [rsp+0x50]
000074c3551e05c5  vmovaps xmm6, [rsp+0x60]
000074c3551e05cb  vmovaps xmm7, [rsp+0x70]
000074c3551e05d1  vmovaps xmm8, [rsp+0x80]
000074c3551e05da  vmovaps xmm9, [rsp+0x90]
000074c3551e05e3  vmovaps xmm10, [rsp+0xA0]
000074c3551e05ec  vmovaps xmm11, [rsp+0xB0]
000074c3551e05f5  vmovaps xmm13, [rsp+0xC0]
000074c3551e05fe  vmovaps xmm14, [rsp+0xD0]
000074c3551e0607  vmovaps xmm15, [rsp+0xE0]
000074c3551e0610  add rsp, 0xF0
000074c3551e0617  pop r11
000074c3551e0619  pop r10
000074c3551e061b  pop r9
000074c3551e061d  pop r8
000074c3551e061f  pop rsi
000074c3551e0620  pop rdi
000074c3551e0621  pop rdx
000074c3551e0622  pop rcx
000074c3551e0623  pop rax
000074c3551e0624  add rsp, 0x08
000074c3551e0628  jmp 0x000074C3551DC5F4
000074c3551e062d  sub rsp, 0x08
000074c3551e0631  push rax
000074c3551e0632  push rcx
000074c3551e0633  push rdx
000074c3551e0634  push rdi
000074c3551e0635  push rsi
000074c3551e0636  push r8
000074c3551e0638  push r9
000074c3551e063a  push r10
000074c3551e063c  push r11
000074c3551e063e  sub rsp, 0xF0
000074c3551e0645  vmovaps [rsp], xmm0
000074c3551e064a  vmovaps [rsp+0x10], xmm1
000074c3551e0650  vmovaps [rsp+0x20], xmm2
000074c3551e0656  vmovaps [rsp+0x30], xmm3
000074c3551e065c  vmovaps [rsp+0x40], xmm4
000074c3551e0662  vmovaps [rsp+0x50], xmm5
000074c3551e0668  vmovaps [rsp+0x60], xmm6
000074c3551e066e  vmovaps [rsp+0x70], xmm7
000074c3551e0674  vmovaps [rsp+0x80], xmm8
000074c3551e067d  vmovaps [rsp+0x90], xmm9
000074c3551e0686  vmovaps [rsp+0xA0], xmm10
000074c3551e068f  vmovaps [rsp+0xB0], xmm11
000074c3551e0698  vmovaps [rsp+0xC0], xmm12
000074c3551e06a1  vmovaps [rsp+0xD0], xmm14
000074c3551e06aa  vmovaps [rsp+0xE0], xmm15
000074c3551e06b3  sub rsp, 0x30
000074c3551e06b7  movaps [rsp], xmm13
000074c3551e06bc  movaps [rsp+0x10], xmm15
000074c3551e06c2  movaps [rsp+0x20], xmm8
000074c3551e06c8  lea rdi, [rsp]
000074c3551e06cc  mov esi, 0x00
000074c3551e06d1  mov rax, 0x5F9407FA9530
000074c3551e06db  call rax
000074c3551e06dd  movaps xmm13, [rsp]
000074c3551e06e2  add rsp, 0x30
000074c3551e06e6  vmovaps xmm0, [rsp]
000074c3551e06eb  vmovaps xmm1, [rsp+0x10]
000074c3551e06f1  vmovaps xmm2, [rsp+0x20]
000074c3551e06f7  vmovaps xmm3, [rsp+0x30]
000074c3551e06fd  vmovaps xmm4, [rsp+0x40]
000074c3551e0703  vmovaps xmm5, [rsp+0x50]
000074c3551e0709  vmovaps xmm6, [rsp+0x60]
000074c3551e070f  vmovaps xmm7, [rsp+0x70]
000074c3551e0715  vmovaps xmm8, [rsp+0x80]
000074c3551e071e  vmovaps xmm9, [rsp+0x90]
000074c3551e0727  vmovaps xmm10, [rsp+0xA0]
000074c3551e0730  vmovaps xmm11, [rsp+0xB0]
000074c3551e0739  vmovaps xmm12, [rsp+0xC0]
000074c3551e0742  vmovaps xmm14, [rsp+0xD0]
000074c3551e074b  vmovaps xmm15, [rsp+0xE0]
000074c3551e0754  add rsp, 0xF0
000074c3551e075b  pop r11
000074c3551e075d  pop r10
000074c3551e075f  pop r9
000074c3551e0761  pop r8
000074c3551e0763  pop rsi
000074c3551e0764  pop rdi
000074c3551e0765  pop rdx
000074c3551e0766  pop rcx
000074c3551e0767  pop rax
000074c3551e0768  add rsp, 0x08
000074c3551e076c  jmp 0x000074C3551DC60F
000074c3551e0771  sub rsp, 0x08
000074c3551e0775  push rax
000074c3551e0776  push rcx
000074c3551e0777  push rdx
000074c3551e0778  push rdi
000074c3551e0779  push rsi
000074c3551e077a  push r8
000074c3551e077c  push r9
000074c3551e077e  push r10
000074c3551e0780  push r11
000074c3551e0782  sub rsp, 0xF0
000074c3551e0789  vmovaps [rsp], xmm0
000074c3551e078e  vmovaps [rsp+0x10], xmm1
000074c3551e0794  vmovaps [rsp+0x20], xmm2
000074c3551e079a  vmovaps [rsp+0x30], xmm3
000074c3551e07a0  vmovaps [rsp+0x40], xmm4
000074c3551e07a6  vmovaps [rsp+0x50], xmm5
000074c3551e07ac  vmovaps [rsp+0x60], xmm6
000074c3551e07b2  vmovaps [rsp+0x70], xmm7
000074c3551e07b8  vmovaps [rsp+0x80], xmm9
000074c3551e07c1  vmovaps [rsp+0x90], xmm10
000074c3551e07ca  vmovaps [rsp+0xA0], xmm11
000074c3551e07d3  vmovaps [rsp+0xB0], xmm12
000074c3551e07dc  vmovaps [rsp+0xC0], xmm13
000074c3551e07e5  vmovaps [rsp+0xD0], xmm14
000074c3551e07ee  vmovaps [rsp+0xE0], xmm15
000074c3551e07f7  sub rsp, 0x30
000074c3551e07fb  movaps [rsp], xmm8
000074c3551e0800  movaps [rsp+0x10], xmm15
000074c3551e0806  movaps [rsp+0x20], xmm9
000074c3551e080c  lea rdi, [rsp]
000074c3551e0810  mov esi, 0x00
000074c3551e0815  mov rax, 0x5F9407FA9530
000074c3551e081f  call rax
000074c3551e0821  movaps xmm8, [rsp]
000074c3551e0826  add rsp, 0x30
000074c3551e082a  vmovaps xmm0, [rsp]
000074c3551e082f  vmovaps xmm1, [rsp+0x10]
000074c3551e0835  vmovaps xmm2, [rsp+0x20]
000074c3551e083b  vmovaps xmm3, [rsp+0x30]
000074c3551e0841  vmovaps xmm4, [rsp+0x40]
000074c3551e0847  vmovaps xmm5, [rsp+0x50]
000074c3551e084d  vmovaps xmm6, [rsp+0x60]
000074c3551e0853  vmovaps xmm7, [rsp+0x70]
000074c3551e0859  vmovaps xmm9, [rsp+0x80]
000074c3551e0862  vmovaps xmm10, [rsp+0x90]
000074c3551e086b  vmovaps xmm11, [rsp+0xA0]
000074c3551e0874  vmovaps xmm12, [rsp+0xB0]
000074c3551e087d  vmovaps xmm13, [rsp+0xC0]
000074c3551e0886  vmovaps xmm14, [rsp+0xD0]
000074c3551e088f  vmovaps xmm15, [rsp+0xE0]
000074c3551e0898  add rsp, 0xF0
000074c3551e089f  pop r11
000074c3551e08a1  pop r10
000074c3551e08a3  pop r9
000074c3551e08a5  pop r8
000074c3551e08a7  pop rsi
000074c3551e08a8  pop rdi
000074c3551e08a9  pop rdx
000074c3551e08aa  pop rcx
000074c3551e08ab  pop rax
000074c3551e08ac  add rsp, 0x08
000074c3551e08b0  jmp 0x000074C3551DC63D
000074c3551e08b5  sub rsp, 0x08
000074c3551e08b9  push rax
000074c3551e08ba  push rcx
000074c3551e08bb  push rdx
000074c3551e08bc  push rdi
000074c3551e08bd  push rsi
000074c3551e08be  push r8
000074c3551e08c0  push r9
000074c3551e08c2  push r10
000074c3551e08c4  push r11
000074c3551e08c6  sub rsp, 0xF0
000074c3551e08cd  vmovaps [rsp], xmm0
000074c3551e08d2  vmovaps [rsp+0x10], xmm1
000074c3551e08d8  vmovaps [rsp+0x20], xmm2
000074c3551e08de  vmovaps [rsp+0x30], xmm3
000074c3551e08e4  vmovaps [rsp+0x40], xmm4
000074c3551e08ea  vmovaps [rsp+0x50], xmm5
000074c3551e08f0  vmovaps [rsp+0x60], xmm6
000074c3551e08f6  vmovaps [rsp+0x70], xmm7
000074c3551e08fc  vmovaps [rsp+0x80], xmm8
000074c3551e0905  vmovaps [rsp+0x90], xmm9
000074c3551e090e  vmovaps [rsp+0xA0], xmm10
000074c3551e0917  vmovaps [rsp+0xB0], xmm11
000074c3551e0920  vmovaps [rsp+0xC0], xmm12
000074c3551e0929  vmovaps [rsp+0xD0], xmm13
000074c3551e0932  vmovaps [rsp+0xE0], xmm14
000074c3551e093b  sub rsp, 0x30
000074c3551e093f  movaps [rsp], xmm15
000074c3551e0944  movaps [rsp+0x10], xmm11
000074c3551e094a  movaps [rsp+0x20], xmm6
000074c3551e094f  lea rdi, [rsp]
000074c3551e0953  mov esi, 0x00
000074c3551e0958  mov rax, 0x5F9407FA9530
000074c3551e0962  call rax
000074c3551e0964  movaps xmm15, [rsp]
000074c3551e0969  add rsp, 0x30
000074c3551e096d  vmovaps xmm0, [rsp]
000074c3551e0972  vmovaps xmm1, [rsp+0x10]
000074c3551e0978  vmovaps xmm2, [rsp+0x20]
000074c3551e097e  vmovaps xmm3, [rsp+0x30]
000074c3551e0984  vmovaps xmm4, [rsp+0x40]
000074c3551e098a  vmovaps xmm5, [rsp+0x50]
000074c3551e0990  vmovaps xmm6, [rsp+0x60]
000074c3551e0996  vmovaps xmm7, [rsp+0x70]
000074c3551e099c  vmovaps xmm8, [rsp+0x80]
000074c3551e09a5  vmovaps xmm9, [rsp+0x90]
000074c3551e09ae  vmovaps xmm10, [rsp+0xA0]
000074c3551e09b7  vmovaps xmm11, [rsp+0xB0]
000074c3551e09c0  vmovaps xmm12, [rsp+0xC0]
000074c3551e09c9  vmovaps xmm13, [rsp+0xD0]
000074c3551e09d2  vmovaps xmm14, [rsp+0xE0]
000074c3551e09db  add rsp, 0xF0
000074c3551e09e2  pop r11
000074c3551e09e4  pop r10
000074c3551e09e6  pop r9
000074c3551e09e8  pop r8
000074c3551e09ea  pop rsi
000074c3551e09eb  pop rdi
000074c3551e09ec  pop rdx
000074c3551e09ed  pop rcx
000074c3551e09ee  pop rax
000074c3551e09ef  add rsp, 0x08
000074c3551e09f3  jmp 0x000074C3551DC658
000074c3551e09f8  sub rsp, 0x08
000074c3551e09fc  push rax
000074c3551e09fd  push rcx
000074c3551e09fe  push rdx
000074c3551e09ff  push rdi
000074c3551e0a00  push rsi
000074c3551e0a01  push r8
000074c3551e0a03  push r9
000074c3551e0a05  push r10
000074c3551e0a07  push r11
000074c3551e0a09  sub rsp, 0xF0
000074c3551e0a10  vmovaps [rsp], xmm0
000074c3551e0a15  vmovaps [rsp+0x10], xmm1
000074c3551e0a1b  vmovaps [rsp+0x20], xmm2
000074c3551e0a21  vmovaps [rsp+0x30], xmm3
000074c3551e0a27  vmovaps [rsp+0x40], xmm4
000074c3551e0a2d  vmovaps [rsp+0x50], xmm5
000074c3551e0a33  vmovaps [rsp+0x60], xmm6
000074c3551e0a39  vmovaps [rsp+0x70], xmm8
000074c3551e0a3f  vmovaps [rsp+0x80], xmm9
000074c3551e0a48  vmovaps [rsp+0x90], xmm10
000074c3551e0a51  vmovaps [rsp+0xA0], xmm11
000074c3551e0a5a  vmovaps [rsp+0xB0], xmm12
000074c3551e0a63  vmovaps [rsp+0xC0], xmm13
000074c3551e0a6c  vmovaps [rsp+0xD0], xmm14
000074c3551e0a75  vmovaps [rsp+0xE0], xmm15
000074c3551e0a7e  sub rsp, 0x30
000074c3551e0a82  movaps [rsp], xmm7
000074c3551e0a86  movaps [rsp+0x10], xmm11
000074c3551e0a8c  movaps [rsp+0x20], xmm9
000074c3551e0a92  lea rdi, [rsp]
000074c3551e0a96  mov esi, 0x00
000074c3551e0a9b  mov rax, 0x5F9407FA9530
000074c3551e0aa5  call rax
000074c3551e0aa7  movaps xmm7, [rsp]
000074c3551e0aab  add rsp, 0x30
000074c3551e0aaf  vmovaps xmm0, [rsp]
000074c3551e0ab4  vmovaps xmm1, [rsp+0x10]
000074c3551e0aba  vmovaps xmm2, [rsp+0x20]
000074c3551e0ac0  vmovaps xmm3, [rsp+0x30]
000074c3551e0ac6  vmovaps xmm4, [rsp+0x40]
000074c3551e0acc  vmovaps xmm5, [rsp+0x50]
000074c3551e0ad2  vmovaps xmm6, [rsp+0x60]
000074c3551e0ad8  vmovaps xmm8, [rsp+0x70]
000074c3551e0ade  vmovaps xmm9, [rsp+0x80]
000074c3551e0ae7  vmovaps xmm10, [rsp+0x90]
000074c3551e0af0  vmovaps xmm11, [rsp+0xA0]
000074c3551e0af9  vmovaps xmm12, [rsp+0xB0]
000074c3551e0b02  vmovaps xmm13, [rsp+0xC0]
000074c3551e0b0b  vmovaps xmm14, [rsp+0xD0]
000074c3551e0b14  vmovaps xmm15, [rsp+0xE0]
000074c3551e0b1d  add rsp, 0xF0
000074c3551e0b24  pop r11
000074c3551e0b26  pop r10
000074c3551e0b28  pop r9
000074c3551e0b2a  pop r8
000074c3551e0b2c  pop rsi
000074c3551e0b2d  pop rdi
000074c3551e0b2e  pop rdx
000074c3551e0b2f  pop rcx
000074c3551e0b30  pop rax
000074c3551e0b31  add rsp, 0x08
000074c3551e0b35  jmp 0x000074C3551DC685
000074c3551e0b3a  sub rsp, 0x08
000074c3551e0b3e  push rax
000074c3551e0b3f  push rcx
000074c3551e0b40  push rdx
000074c3551e0b41  push rdi
000074c3551e0b42  push rsi
000074c3551e0b43  push r8
000074c3551e0b45  push r9
000074c3551e0b47  push r10
000074c3551e0b49  push r11
000074c3551e0b4b  sub rsp, 0xF0
000074c3551e0b52  vmovaps [rsp], xmm0
000074c3551e0b57  vmovaps [rsp+0x10], xmm1
000074c3551e0b5d  vmovaps [rsp+0x20], xmm2
000074c3551e0b63  vmovaps [rsp+0x30], xmm3
000074c3551e0b69  vmovaps [rsp+0x40], xmm4
000074c3551e0b6f  vmovaps [rsp+0x50], xmm5
000074c3551e0b75  vmovaps [rsp+0x60], xmm6
000074c3551e0b7b  vmovaps [rsp+0x70], xmm7
000074c3551e0b81  vmovaps [rsp+0x80], xmm8
000074c3551e0b8a  vmovaps [rsp+0x90], xmm9
000074c3551e0b93  vmovaps [rsp+0xA0], xmm10
000074c3551e0b9c  vmovaps [rsp+0xB0], xmm12
000074c3551e0ba5  vmovaps [rsp+0xC0], xmm13
000074c3551e0bae  vmovaps [rsp+0xD0], xmm14
000074c3551e0bb7  vmovaps [rsp+0xE0], xmm15
000074c3551e0bc0  sub rsp, 0x30
000074c3551e0bc4  movaps [rsp], xmm11
000074c3551e0bc9  movaps [rsp+0x10], xmm10
000074c3551e0bcf  movaps [rsp+0x20], xmm14
000074c3551e0bd5  lea rdi, [rsp]
000074c3551e0bd9  mov esi, 0x00
000074c3551e0bde  mov rax, 0x5F9407FA9530
000074c3551e0be8  call rax
000074c3551e0bea  movaps xmm11, [rsp]
000074c3551e0bef  add rsp, 0x30
000074c3551e0bf3  vmovaps xmm0, [rsp]
000074c3551e0bf8  vmovaps xmm1, [rsp+0x10]
000074c3551e0bfe  vmovaps xmm2, [rsp+0x20]
000074c3551e0c04  vmovaps xmm3, [rsp+0x30]
000074c3551e0c0a  vmovaps xmm4, [rsp+0x40]
000074c3551e0c10  vmovaps xmm5, [rsp+0x50]
000074c3551e0c16  vmovaps xmm6, [rsp+0x60]
000074c3551e0c1c  vmovaps xmm7, [rsp+0x70]
000074c3551e0c22  vmovaps xmm8, [rsp+0x80]
000074c3551e0c2b  vmovaps xmm9, [rsp+0x90]
000074c3551e0c34  vmovaps xmm10, [rsp+0xA0]
000074c3551e0c3d  vmovaps xmm12, [rsp+0xB0]
000074c3551e0c46  vmovaps xmm13, [rsp+0xC0]
000074c3551e0c4f  vmovaps xmm14, [rsp+0xD0]
000074c3551e0c58  vmovaps xmm15, [rsp+0xE0]
000074c3551e0c61  add rsp, 0xF0
000074c3551e0c68  pop r11
000074c3551e0c6a  pop r10
000074c3551e0c6c  pop r9
000074c3551e0c6e  pop r8
000074c3551e0c70  pop rsi
000074c3551e0c71  pop rdi
000074c3551e0c72  pop rdx
000074c3551e0c73  pop rcx
000074c3551e0c74  pop rax
000074c3551e0c75  add rsp, 0x08
000074c3551e0c79  jmp 0x000074C3551DC6A0
000074c3551e0c7e  call 0x000074C3550C33A0
000074c3551e0c83  jmp 0x000074C3551DC6AA
000074c3551e0c88  sub rsp, 0x08
000074c3551e0c8c  push rax
000074c3551e0c8d  push rcx
000074c3551e0c8e  push rdx
000074c3551e0c8f  push rdi
000074c3551e0c90  push rsi
000074c3551e0c91  push r8
000074c3551e0c93  push r9
000074c3551e0c95  push r10
000074c3551e0c97  push r11
000074c3551e0c99  sub rsp, 0xF0
000074c3551e0ca0  vmovaps [rsp], xmm0
000074c3551e0ca5  vmovaps [rsp+0x10], xmm1
000074c3551e0cab  vmovaps [rsp+0x20], xmm2
000074c3551e0cb1  vmovaps [rsp+0x30], xmm3
000074c3551e0cb7  vmovaps [rsp+0x40], xmm4
000074c3551e0cbd  vmovaps [rsp+0x50], xmm5
000074c3551e0cc3  vmovaps [rsp+0x60], xmm6
000074c3551e0cc9  vmovaps [rsp+0x70], xmm7
000074c3551e0ccf  vmovaps [rsp+0x80], xmm8
000074c3551e0cd8  vmovaps [rsp+0x90], xmm9
000074c3551e0ce1  vmovaps [rsp+0xA0], xmm11
000074c3551e0cea  vmovaps [rsp+0xB0], xmm12
000074c3551e0cf3  vmovaps [rsp+0xC0], xmm13
000074c3551e0cfc  vmovaps [rsp+0xD0], xmm14
000074c3551e0d05  vmovaps [rsp+0xE0], xmm15
000074c3551e0d0e  sub rsp, 0x30
000074c3551e0d12  movaps [rsp], xmm10
000074c3551e0d17  movaps [rsp+0x10], xmm1
000074c3551e0d1c  movaps [rsp+0x20], xmm12
000074c3551e0d22  lea rdi, [rsp]
000074c3551e0d26  mov esi, 0x00
000074c3551e0d2b  mov rax, 0x5F9407FA9530
000074c3551e0d35  call rax
000074c3551e0d37  movaps xmm10, [rsp]
000074c3551e0d3c  add rsp, 0x30
000074c3551e0d40  vmovaps xmm0, [rsp]
000074c3551e0d45  vmovaps xmm1, [rsp+0x10]
000074c3551e0d4b  vmovaps xmm2, [rsp+0x20]
000074c3551e0d51  vmovaps xmm3, [rsp+0x30]
000074c3551e0d57  vmovaps xmm4, [rsp+0x40]
000074c3551e0d5d  vmovaps xmm5, [rsp+0x50]
000074c3551e0d63  vmovaps xmm6, [rsp+0x60]
000074c3551e0d69  vmovaps xmm7, [rsp+0x70]
000074c3551e0d6f  vmovaps xmm8, [rsp+0x80]
000074c3551e0d78  vmovaps xmm9, [rsp+0x90]
000074c3551e0d81  vmovaps xmm11, [rsp+0xA0]
000074c3551e0d8a  vmovaps xmm12, [rsp+0xB0]
000074c3551e0d93  vmovaps xmm13, [rsp+0xC0]
000074c3551e0d9c  vmovaps xmm14, [rsp+0xD0]
000074c3551e0da5  vmovaps xmm15, [rsp+0xE0]
000074c3551e0dae  add rsp, 0xF0
000074c3551e0db5  pop r11
000074c3551e0db7  pop r10
000074c3551e0db9  pop r9
000074c3551e0dbb  pop r8
000074c3551e0dbd  pop rsi
000074c3551e0dbe  pop rdi
000074c3551e0dbf  pop rdx
000074c3551e0dc0  pop rcx
000074c3551e0dc1  pop rax
000074c3551e0dc2  add rsp, 0x08
000074c3551e0dc6  jmp 0x000074C3551DC6CD
000074c3551e0dcb  sub rsp, 0x08
000074c3551e0dcf  push rax
000074c3551e0dd0  push rcx
000074c3551e0dd1  push rdx
000074c3551e0dd2  push rdi
000074c3551e0dd3  push rsi
000074c3551e0dd4  push r8
000074c3551e0dd6  push r9
000074c3551e0dd8  push r10
000074c3551e0dda  push r11
000074c3551e0ddc  sub rsp, 0xF0
000074c3551e0de3  vmovaps [rsp], xmm0
000074c3551e0de8  vmovaps [rsp+0x10], xmm1
000074c3551e0dee  vmovaps [rsp+0x20], xmm2
000074c3551e0df4  vmovaps [rsp+0x30], xmm3
000074c3551e0dfa  vmovaps [rsp+0x40], xmm4
000074c3551e0e00  vmovaps [rsp+0x50], xmm5
000074c3551e0e06  vmovaps [rsp+0x60], xmm6
000074c3551e0e0c  vmovaps [rsp+0x70], xmm7
000074c3551e0e12  vmovaps [rsp+0x80], xmm8
000074c3551e0e1b  vmovaps [rsp+0x90], xmm9
000074c3551e0e24  vmovaps [rsp+0xA0], xmm10
000074c3551e0e2d  vmovaps [rsp+0xB0], xmm11
000074c3551e0e36  vmovaps [rsp+0xC0], xmm13
000074c3551e0e3f  vmovaps [rsp+0xD0], xmm14
000074c3551e0e48  vmovaps [rsp+0xE0], xmm15
000074c3551e0e51  sub rsp, 0x30
000074c3551e0e55  movaps [rsp], xmm12
000074c3551e0e5a  movaps [rsp+0x10], xmm14
000074c3551e0e60  movaps [rsp+0x20], xmm1
000074c3551e0e65  lea rdi, [rsp]
000074c3551e0e69  mov esi, 0x00
000074c3551e0e6e  mov rax, 0x5F9407FA9530
000074c3551e0e78  call rax
000074c3551e0e7a  movaps xmm12, [rsp]
000074c3551e0e7f  add rsp, 0x30
000074c3551e0e83  vmovaps xmm0, [rsp]
000074c3551e0e88  vmovaps xmm1, [rsp+0x10]
000074c3551e0e8e  vmovaps xmm2, [rsp+0x20]
000074c3551e0e94  vmovaps xmm3, [rsp+0x30]
000074c3551e0e9a  vmovaps xmm4, [rsp+0x40]
000074c3551e0ea0  vmovaps xmm5, [rsp+0x50]
000074c3551e0ea6  vmovaps xmm6, [rsp+0x60]
000074c3551e0eac  vmovaps xmm7, [rsp+0x70]
000074c3551e0eb2  vmovaps xmm8, [rsp+0x80]
000074c3551e0ebb  vmovaps xmm9, [rsp+0x90]
000074c3551e0ec4  vmovaps xmm10, [rsp+0xA0]
000074c3551e0ecd  vmovaps xmm11, [rsp+0xB0]
000074c3551e0ed6  vmovaps xmm13, [rsp+0xC0]
000074c3551e0edf  vmovaps xmm14, [rsp+0xD0]
000074c3551e0ee8  vmovaps xmm15, [rsp+0xE0]
000074c3551e0ef1  add rsp, 0xF0
000074c3551e0ef8  pop r11
000074c3551e0efa  pop r10
000074c3551e0efc  pop r9
000074c3551e0efe  pop r8
000074c3551e0f00  pop rsi
000074c3551e0f01  pop rdi
000074c3551e0f02  pop rdx
000074c3551e0f03  pop rcx
000074c3551e0f04  pop rax
000074c3551e0f05  add rsp, 0x08
000074c3551e0f09  jmp 0x000074C3551DC6FC
000074c3551e0f0e  sub rsp, 0x08
000074c3551e0f12  push rax
000074c3551e0f13  push rcx
000074c3551e0f14  push rdx
000074c3551e0f15  push rdi
000074c3551e0f16  push rsi
000074c3551e0f17  push r8
000074c3551e0f19  push r9
000074c3551e0f1b  push r10
000074c3551e0f1d  push r11
000074c3551e0f1f  sub rsp, 0xF0
000074c3551e0f26  vmovaps [rsp], xmm0
000074c3551e0f2b  vmovaps [rsp+0x10], xmm1
000074c3551e0f31  vmovaps [rsp+0x20], xmm2
000074c3551e0f37  vmovaps [rsp+0x30], xmm3
000074c3551e0f3d  vmovaps [rsp+0x40], xmm4
000074c3551e0f43  vmovaps [rsp+0x50], xmm5
000074c3551e0f49  vmovaps [rsp+0x60], xmm6
000074c3551e0f4f  vmovaps [rsp+0x70], xmm7
000074c3551e0f55  vmovaps [rsp+0x80], xmm8
000074c3551e0f5e  vmovaps [rsp+0x90], xmm9
000074c3551e0f67  vmovaps [rsp+0xA0], xmm10
000074c3551e0f70  vmovaps [rsp+0xB0], xmm11
000074c3551e0f79  vmovaps [rsp+0xC0], xmm12
000074c3551e0f82  vmovaps [rsp+0xD0], xmm13
000074c3551e0f8b  vmovaps [rsp+0xE0], xmm15
000074c3551e0f94  sub rsp, 0x30
000074c3551e0f98  movaps [rsp], xmm14
000074c3551e0f9d  movaps [rsp+0x10], xmm9
000074c3551e0fa3  movaps [rsp+0x20], xmm1
000074c3551e0fa8  lea rdi, [rsp]
000074c3551e0fac  mov esi, 0x00
000074c3551e0fb1  mov rax, 0x5F9407FA9530
000074c3551e0fbb  call rax
000074c3551e0fbd  movaps xmm14, [rsp]
000074c3551e0fc2  add rsp, 0x30
000074c3551e0fc6  vmovaps xmm0, [rsp]
000074c3551e0fcb  vmovaps xmm1, [rsp+0x10]
000074c3551e0fd1  vmovaps xmm2, [rsp+0x20]
000074c3551e0fd7  vmovaps xmm3, [rsp+0x30]
000074c3551e0fdd  vmovaps xmm4, [rsp+0x40]
000074c3551e0fe3  vmovaps xmm5, [rsp+0x50]
000074c3551e0fe9  vmovaps xmm6, [rsp+0x60]
000074c3551e0fef  vmovaps xmm7, [rsp+0x70]
000074c3551e0ff5  vmovaps xmm8, [rsp+0x80]
000074c3551e0ffe  vmovaps xmm9, [rsp+0x90]
000074c3551e1007  vmovaps xmm10, [rsp+0xA0]
000074c3551e1010  vmovaps xmm11, [rsp+0xB0]
000074c3551e1019  vmovaps xmm12, [rsp+0xC0]
000074c3551e1022  vmovaps xmm13, [rsp+0xD0]
000074c3551e102b  vmovaps xmm15, [rsp+0xE0]
000074c3551e1034  add rsp, 0xF0
000074c3551e103b  pop r11
000074c3551e103d  pop r10
000074c3551e103f  pop r9
000074c3551e1041  pop r8
000074c3551e1043  pop rsi
000074c3551e1044  pop rdi
000074c3551e1045  pop rdx
000074c3551e1046  pop rcx
000074c3551e1047  pop rax
000074c3551e1048  add rsp, 0x08
000074c3551e104c  jmp 0x000074C3551DC72B
000074c3551e1051  sub rsp, 0x08
000074c3551e1055  push rax
000074c3551e1056  push rcx
000074c3551e1057  push rdx
000074c3551e1058  push rdi
000074c3551e1059  push rsi
000074c3551e105a  push r8
000074c3551e105c  push r9
000074c3551e105e  push r10
000074c3551e1060  push r11
000074c3551e1062  sub rsp, 0xF0
000074c3551e1069  vmovaps [rsp], xmm0
000074c3551e106e  vmovaps [rsp+0x10], xmm2
000074c3551e1074  vmovaps [rsp+0x20], xmm3
000074c3551e107a  vmovaps [rsp+0x30], xmm4
000074c3551e1080  vmovaps [rsp+0x40], xmm5
000074c3551e1086  vmovaps [rsp+0x50], xmm6
000074c3551e108c  vmovaps [rsp+0x60], xmm7
000074c3551e1092  vmovaps [rsp+0x70], xmm8
000074c3551e1098  vmovaps [rsp+0x80], xmm9
000074c3551e10a1  vmovaps [rsp+0x90], xmm10
000074c3551e10aa  vmovaps [rsp+0xA0], xmm11
000074c3551e10b3  vmovaps [rsp+0xB0], xmm12
000074c3551e10bc  vmovaps [rsp+0xC0], xmm13
000074c3551e10c5  vmovaps [rsp+0xD0], xmm14
000074c3551e10ce  vmovaps [rsp+0xE0], xmm15
000074c3551e10d7  sub rsp, 0x30
000074c3551e10db  movaps [rsp], xmm1
000074c3551e10df  movaps [rsp+0x10], xmm13
000074c3551e10e5  movaps [rsp+0x20], xmm8
000074c3551e10eb  lea rdi, [rsp]
000074c3551e10ef  mov esi, 0x00
000074c3551e10f4  mov rax, 0x5F9407FA9530
000074c3551e10fe  call rax
000074c3551e1100  movaps xmm1, [rsp]
000074c3551e1104  add rsp, 0x30
000074c3551e1108  vmovaps xmm0, [rsp]
000074c3551e110d  vmovaps xmm2, [rsp+0x10]
000074c3551e1113  vmovaps xmm3, [rsp+0x20]
000074c3551e1119  vmovaps xmm4, [rsp+0x30]
000074c3551e111f  vmovaps xmm5, [rsp+0x40]
000074c3551e1125  vmovaps xmm6, [rsp+0x50]
000074c3551e112b  vmovaps xmm7, [rsp+0x60]
000074c3551e1131  vmovaps xmm8, [rsp+0x70]
000074c3551e1137  vmovaps xmm9, [rsp+0x80]
000074c3551e1140  vmovaps xmm10, [rsp+0x90]
000074c3551e1149  vmovaps xmm11, [rsp+0xA0]
000074c3551e1152  vmovaps xmm12, [rsp+0xB0]
000074c3551e115b  vmovaps xmm13, [rsp+0xC0]
000074c3551e1164  vmovaps xmm14, [rsp+0xD0]
000074c3551e116d  vmovaps xmm15, [rsp+0xE0]
000074c3551e1176  add rsp, 0xF0
000074c3551e117d  pop r11
000074c3551e117f  pop r10
000074c3551e1181  pop r9
000074c3551e1183  pop r8
000074c3551e1185  pop rsi
000074c3551e1186  pop rdi
000074c3551e1187  pop rdx
000074c3551e1188  pop rcx
000074c3551e1189  pop rax
000074c3551e118a  add rsp, 0x08
000074c3551e118e  jmp 0x000074C3551DC74D
000074c3551e1193  call 0x000074C35500C260
000074c3551e1198  jmp 0x000074C3551DC75B
000074c3551e119d  call 0x000074C3550BD750
000074c3551e11a2  jmp 0x000074C3551DC765
000074c3551e11a7  sub rsp, 0x08
000074c3551e11ab  push rax
000074c3551e11ac  push rcx
000074c3551e11ad  push rdx
000074c3551e11ae  push rdi
000074c3551e11af  push rsi
000074c3551e11b0  push r8
000074c3551e11b2  push r9
000074c3551e11b4  push r10
000074c3551e11b6  push r11
000074c3551e11b8  sub rsp, 0xF0
000074c3551e11bf  vmovaps [rsp], xmm0
000074c3551e11c4  vmovaps [rsp+0x10], xmm1
000074c3551e11ca  vmovaps [rsp+0x20], xmm2
000074c3551e11d0  vmovaps [rsp+0x30], xmm3
000074c3551e11d6  vmovaps [rsp+0x40], xmm4
000074c3551e11dc  vmovaps [rsp+0x50], xmm5
000074c3551e11e2  vmovaps [rsp+0x60], xmm6
000074c3551e11e8  vmovaps [rsp+0x70], xmm7
000074c3551e11ee  vmovaps [rsp+0x80], xmm9
000074c3551e11f7  vmovaps [rsp+0x90], xmm10
000074c3551e1200  vmovaps [rsp+0xA0], xmm11
000074c3551e1209  vmovaps [rsp+0xB0], xmm12
000074c3551e1212  vmovaps [rsp+0xC0], xmm13
000074c3551e121b  vmovaps [rsp+0xD0], xmm14
000074c3551e1224  vmovaps [rsp+0xE0], xmm15
000074c3551e122d  sub rsp, 0x30
000074c3551e1231  movaps [rsp], xmm8
000074c3551e1236  movaps [rsp+0x10], xmm15
000074c3551e123c  movaps [rsp+0x20], xmm7
000074c3551e1241  lea rdi, [rsp]
000074c3551e1245  mov esi, 0x00
000074c3551e124a  mov rax, 0x5F9407FA9530
000074c3551e1254  call rax
000074c3551e1256  movaps xmm8, [rsp]
000074c3551e125b  add rsp, 0x30
000074c3551e125f  vmovaps xmm0, [rsp]
000074c3551e1264  vmovaps xmm1, [rsp+0x10]
000074c3551e126a  vmovaps xmm2, [rsp+0x20]
000074c3551e1270  vmovaps xmm3, [rsp+0x30]
000074c3551e1276  vmovaps xmm4, [rsp+0x40]
000074c3551e127c  vmovaps xmm5, [rsp+0x50]
000074c3551e1282  vmovaps xmm6, [rsp+0x60]
000074c3551e1288  vmovaps xmm7, [rsp+0x70]
000074c3551e128e  vmovaps xmm9, [rsp+0x80]
000074c3551e1297  vmovaps xmm10, [rsp+0x90]
000074c3551e12a0  vmovaps xmm11, [rsp+0xA0]
000074c3551e12a9  vmovaps xmm12, [rsp+0xB0]
000074c3551e12b2  vmovaps xmm13, [rsp+0xC0]
000074c3551e12bb  vmovaps xmm14, [rsp+0xD0]
000074c3551e12c4  vmovaps xmm15, [rsp+0xE0]
000074c3551e12cd  add rsp, 0xF0
000074c3551e12d4  pop r11
000074c3551e12d6  pop r10
000074c3551e12d8  pop r9
000074c3551e12da  pop r8
000074c3551e12dc  pop rsi
000074c3551e12dd  pop rdi
000074c3551e12de  pop rdx
000074c3551e12df  pop rcx
000074c3551e12e0  pop rax
000074c3551e12e1  add rsp, 0x08
000074c3551e12e5  jmp 0x000074C3551DC787
000074c3551e12ea  sub rsp, 0x08
000074c3551e12ee  push rax
000074c3551e12ef  push rcx
000074c3551e12f0  push rdx
000074c3551e12f1  push rdi
000074c3551e12f2  push rsi
000074c3551e12f3  push r8
000074c3551e12f5  push r9
000074c3551e12f7  push r10
000074c3551e12f9  push r11
000074c3551e12fb  sub rsp, 0xF0
000074c3551e1302  vmovaps [rsp], xmm0
000074c3551e1307  vmovaps [rsp+0x10], xmm1
000074c3551e130d  vmovaps [rsp+0x20], xmm2
000074c3551e1313  vmovaps [rsp+0x30], xmm3
000074c3551e1319  vmovaps [rsp+0x40], xmm4
000074c3551e131f  vmovaps [rsp+0x50], xmm5
000074c3551e1325  vmovaps [rsp+0x60], xmm6
000074c3551e132b  vmovaps [rsp+0x70], xmm8
000074c3551e1331  vmovaps [rsp+0x80], xmm9
000074c3551e133a  vmovaps [rsp+0x90], xmm10
000074c3551e1343  vmovaps [rsp+0xA0], xmm11
000074c3551e134c  vmovaps [rsp+0xB0], xmm12
000074c3551e1355  vmovaps [rsp+0xC0], xmm13
000074c3551e135e  vmovaps [rsp+0xD0], xmm14
000074c3551e1367  vmovaps [rsp+0xE0], xmm15
000074c3551e1370  sub rsp, 0x30
000074c3551e1374  movaps [rsp], xmm7
000074c3551e1378  movaps [rsp+0x10], xmm9
000074c3551e137e  movaps [rsp+0x20], xmm15
000074c3551e1384  lea rdi, [rsp]
000074c3551e1388  mov esi, 0x00
000074c3551e138d  mov rax, 0x5F9407FA9530
000074c3551e1397  call rax
000074c3551e1399  movaps xmm7, [rsp]
000074c3551e139d  add rsp, 0x30
000074c3551e13a1  vmovaps xmm0, [rsp]
000074c3551e13a6  vmovaps xmm1, [rsp+0x10]
000074c3551e13ac  vmovaps xmm2, [rsp+0x20]
000074c3551e13b2  vmovaps xmm3, [rsp+0x30]
000074c3551e13b8  vmovaps xmm4, [rsp+0x40]
000074c3551e13be  vmovaps xmm5, [rsp+0x50]
000074c3551e13c4  vmovaps xmm6, [rsp+0x60]
000074c3551e13ca  vmovaps xmm8, [rsp+0x70]
000074c3551e13d0  vmovaps xmm9, [rsp+0x80]
000074c3551e13d9  vmovaps xmm10, [rsp+0x90]
000074c3551e13e2  vmovaps xmm11, [rsp+0xA0]
000074c3551e13eb  vmovaps xmm12, [rsp+0xB0]
000074c3551e13f4  vmovaps xmm13, [rsp+0xC0]
000074c3551e13fd  vmovaps xmm14, [rsp+0xD0]
000074c3551e1406  vmovaps xmm15, [rsp+0xE0]
000074c3551e140f  add rsp, 0xF0
000074c3551e1416  pop r11
000074c3551e1418  pop r10
000074c3551e141a  pop r9
000074c3551e141c  pop r8
000074c3551e141e  pop rsi
000074c3551e141f  pop rdi
000074c3551e1420  pop rdx
000074c3551e1421  pop rcx
000074c3551e1422  pop rax
000074c3551e1423  add rsp, 0x08
000074c3551e1427  jmp 0x000074C3551DC7B4
000074c3551e142c  sub rsp, 0x08
000074c3551e1430  push rax
000074c3551e1431  push rcx
000074c3551e1432  push rdx
000074c3551e1433  push rdi
000074c3551e1434  push rsi
000074c3551e1435  push r8
000074c3551e1437  push r9
000074c3551e1439  push r10
000074c3551e143b  push r11
000074c3551e143d  sub rsp, 0xF0
000074c3551e1444  vmovaps [rsp], xmm0
000074c3551e1449  vmovaps [rsp+0x10], xmm1
000074c3551e144f  vmovaps [rsp+0x20], xmm2
000074c3551e1455  vmovaps [rsp+0x30], xmm3
000074c3551e145b  vmovaps [rsp+0x40], xmm4
000074c3551e1461  vmovaps [rsp+0x50], xmm5
000074c3551e1467  vmovaps [rsp+0x60], xmm6
000074c3551e146d  vmovaps [rsp+0x70], xmm7
000074c3551e1473  vmovaps [rsp+0x80], xmm8
000074c3551e147c  vmovaps [rsp+0x90], xmm10
000074c3551e1485  vmovaps [rsp+0xA0], xmm11
000074c3551e148e  vmovaps [rsp+0xB0], xmm12
000074c3551e1497  vmovaps [rsp+0xC0], xmm13
000074c3551e14a0  vmovaps [rsp+0xD0], xmm14
000074c3551e14a9  vmovaps [rsp+0xE0], xmm15
000074c3551e14b2  sub rsp, 0x30
000074c3551e14b6  movaps [rsp], xmm9
000074c3551e14bb  movaps [rsp+0x10], xmm13
000074c3551e14c1  movaps [rsp+0x20], xmm15
000074c3551e14c7  lea rdi, [rsp]
000074c3551e14cb  mov esi, 0x00
000074c3551e14d0  mov rax, 0x5F9407FA9530
000074c3551e14da  call rax
000074c3551e14dc  movaps xmm9, [rsp]
000074c3551e14e1  add rsp, 0x30
000074c3551e14e5  vmovaps xmm0, [rsp]
000074c3551e14ea  vmovaps xmm1, [rsp+0x10]
000074c3551e14f0  vmovaps xmm2, [rsp+0x20]
000074c3551e14f6  vmovaps xmm3, [rsp+0x30]
000074c3551e14fc  vmovaps xmm4, [rsp+0x40]
000074c3551e1502  vmovaps xmm5, [rsp+0x50]
000074c3551e1508  vmovaps xmm6, [rsp+0x60]
000074c3551e150e  vmovaps xmm7, [rsp+0x70]
000074c3551e1514  vmovaps xmm8, [rsp+0x80]
000074c3551e151d  vmovaps xmm10, [rsp+0x90]
000074c3551e1526  vmovaps xmm11, [rsp+0xA0]
000074c3551e152f  vmovaps xmm12, [rsp+0xB0]
000074c3551e1538  vmovaps xmm13, [rsp+0xC0]
000074c3551e1541  vmovaps xmm14, [rsp+0xD0]
000074c3551e154a  vmovaps xmm15, [rsp+0xE0]
000074c3551e1553  add rsp, 0xF0
000074c3551e155a  pop r11
000074c3551e155c  pop r10
000074c3551e155e  pop r9
000074c3551e1560  pop r8
000074c3551e1562  pop rsi
000074c3551e1563  pop rdi
000074c3551e1564  pop rdx
000074c3551e1565  pop rcx
000074c3551e1566  pop rax
000074c3551e1567  add rsp, 0x08
000074c3551e156b  jmp 0x000074C3551DC7E2
000074c3551e1570  sub rsp, 0x08
000074c3551e1574  push rax
000074c3551e1575  push rcx
000074c3551e1576  push rdx
000074c3551e1577  push rdi
000074c3551e1578  push rsi
000074c3551e1579  push r8
000074c3551e157b  push r9
000074c3551e157d  push r10
000074c3551e157f  push r11
000074c3551e1581  sub rsp, 0xF0
000074c3551e1588  vmovaps [rsp], xmm0
000074c3551e158d  vmovaps [rsp+0x10], xmm1
000074c3551e1593  vmovaps [rsp+0x20], xmm2
000074c3551e1599  vmovaps [rsp+0x30], xmm3
000074c3551e159f  vmovaps [rsp+0x40], xmm4
000074c3551e15a5  vmovaps [rsp+0x50], xmm5
000074c3551e15ab  vmovaps [rsp+0x60], xmm6
000074c3551e15b1  vmovaps [rsp+0x70], xmm7
000074c3551e15b7  vmovaps [rsp+0x80], xmm8
000074c3551e15c0  vmovaps [rsp+0x90], xmm9
000074c3551e15c9  vmovaps [rsp+0xA0], xmm10
000074c3551e15d2  vmovaps [rsp+0xB0], xmm11
000074c3551e15db  vmovaps [rsp+0xC0], xmm12
000074c3551e15e4  vmovaps [rsp+0xD0], xmm13
000074c3551e15ed  vmovaps [rsp+0xE0], xmm14
000074c3551e15f6  sub rsp, 0x30
000074c3551e15fa  movaps [rsp], xmm15
000074c3551e15ff  movaps [rsp+0x10], xmm11
000074c3551e1605  movaps [rsp+0x20], xmm12
000074c3551e160b  lea rdi, [rsp]
000074c3551e160f  mov esi, 0x00
000074c3551e1614  mov rax, 0x5F9407FA9530
000074c3551e161e  call rax
000074c3551e1620  movaps xmm15, [rsp]
000074c3551e1625  add rsp, 0x30
000074c3551e1629  vmovaps xmm0, [rsp]
000074c3551e162e  vmovaps xmm1, [rsp+0x10]
000074c3551e1634  vmovaps xmm2, [rsp+0x20]
000074c3551e163a  vmovaps xmm3, [rsp+0x30]
000074c3551e1640  vmovaps xmm4, [rsp+0x40]
000074c3551e1646  vmovaps xmm5, [rsp+0x50]
000074c3551e164c  vmovaps xmm6, [rsp+0x60]
000074c3551e1652  vmovaps xmm7, [rsp+0x70]
000074c3551e1658  vmovaps xmm8, [rsp+0x80]
000074c3551e1661  vmovaps xmm9, [rsp+0x90]
000074c3551e166a  vmovaps xmm10, [rsp+0xA0]
000074c3551e1673  vmovaps xmm11, [rsp+0xB0]
000074c3551e167c  vmovaps xmm12, [rsp+0xC0]
000074c3551e1685  vmovaps xmm13, [rsp+0xD0]
000074c3551e168e  vmovaps xmm14, [rsp+0xE0]
000074c3551e1697  add rsp, 0xF0
000074c3551e169e  pop r11
000074c3551e16a0  pop r10
000074c3551e16a2  pop r9
000074c3551e16a4  pop r8
000074c3551e16a6  pop rsi
000074c3551e16a7  pop rdi
000074c3551e16a8  pop rdx
000074c3551e16a9  pop rcx
000074c3551e16aa  pop rax
000074c3551e16ab  add rsp, 0x08
000074c3551e16af  jmp 0x000074C3551DC7FD
000074c3551e16b4  sub rsp, 0x08
000074c3551e16b8  push rax
000074c3551e16b9  push rcx
000074c3551e16ba  push rdx
000074c3551e16bb  push rdi
000074c3551e16bc  push rsi
000074c3551e16bd  push r8
000074c3551e16bf  push r9
000074c3551e16c1  push r10
000074c3551e16c3  push r11
000074c3551e16c5  sub rsp, 0xF0
000074c3551e16cc  vmovaps [rsp], xmm0
000074c3551e16d1  vmovaps [rsp+0x10], xmm1
000074c3551e16d7  vmovaps [rsp+0x20], xmm2
000074c3551e16dd  vmovaps [rsp+0x30], xmm3
000074c3551e16e3  vmovaps [rsp+0x40], xmm4
000074c3551e16e9  vmovaps [rsp+0x50], xmm5
000074c3551e16ef  vmovaps [rsp+0x60], xmm6
000074c3551e16f5  vmovaps [rsp+0x70], xmm7
000074c3551e16fb  vmovaps [rsp+0x80], xmm8
000074c3551e1704  vmovaps [rsp+0x90], xmm9
000074c3551e170d  vmovaps [rsp+0xA0], xmm10
000074c3551e1716  vmovaps [rsp+0xB0], xmm11
000074c3551e171f  vmovaps [rsp+0xC0], xmm12
000074c3551e1728  vmovaps [rsp+0xD0], xmm14
000074c3551e1731  vmovaps [rsp+0xE0], xmm15
000074c3551e173a  sub rsp, 0x30
000074c3551e173e  movaps [rsp], xmm13
000074c3551e1743  movaps [rsp+0x10], xmm10
000074c3551e1749  movaps [rsp+0x20], xmm14
000074c3551e174f  lea rdi, [rsp]
000074c3551e1753  mov esi, 0x00
000074c3551e1758  mov rax, 0x5F9407FA9530
000074c3551e1762  call rax
000074c3551e1764  movaps xmm13, [rsp]
000074c3551e1769  add rsp, 0x30
000074c3551e176d  vmovaps xmm0, [rsp]
000074c3551e1772  vmovaps xmm1, [rsp+0x10]
000074c3551e1778  vmovaps xmm2, [rsp+0x20]
000074c3551e177e  vmovaps xmm3, [rsp+0x30]
000074c3551e1784  vmovaps xmm4, [rsp+0x40]
000074c3551e178a  vmovaps xmm5, [rsp+0x50]
000074c3551e1790  vmovaps xmm6, [rsp+0x60]
000074c3551e1796  vmovaps xmm7, [rsp+0x70]
000074c3551e179c  vmovaps xmm8, [rsp+0x80]
000074c3551e17a5  vmovaps xmm9, [rsp+0x90]
000074c3551e17ae  vmovaps xmm10, [rsp+0xA0]
000074c3551e17b7  vmovaps xmm11, [rsp+0xB0]
000074c3551e17c0  vmovaps xmm12, [rsp+0xC0]
000074c3551e17c9  vmovaps xmm14, [rsp+0xD0]
000074c3551e17d2  vmovaps xmm15, [rsp+0xE0]
000074c3551e17db  add rsp, 0xF0
000074c3551e17e2  pop r11
000074c3551e17e4  pop r10
000074c3551e17e6  pop r9
000074c3551e17e8  pop r8
000074c3551e17ea  pop rsi
000074c3551e17eb  pop rdi
000074c3551e17ec  pop rdx
000074c3551e17ed  pop rcx
000074c3551e17ee  pop rax
000074c3551e17ef  add rsp, 0x08
000074c3551e17f3  jmp 0x000074C3551DC820
000074c3551e17f8  sub rsp, 0x08
000074c3551e17fc  push rax
000074c3551e17fd  push rcx
000074c3551e17fe  push rdx
000074c3551e17ff  push rdi
000074c3551e1800  push rsi
000074c3551e1801  push r8
000074c3551e1803  push r9
000074c3551e1805  push r10
000074c3551e1807  push r11
000074c3551e1809  sub rsp, 0xF0
000074c3551e1810  vmovaps [rsp], xmm0
000074c3551e1815  vmovaps [rsp+0x10], xmm1
000074c3551e181b  vmovaps [rsp+0x20], xmm2
000074c3551e1821  vmovaps [rsp+0x30], xmm3
000074c3551e1827  vmovaps [rsp+0x40], xmm4
000074c3551e182d  vmovaps [rsp+0x50], xmm5
000074c3551e1833  vmovaps [rsp+0x60], xmm6
000074c3551e1839  vmovaps [rsp+0x70], xmm7
000074c3551e183f  vmovaps [rsp+0x80], xmm8
000074c3551e1848  vmovaps [rsp+0x90], xmm9
000074c3551e1851  vmovaps [rsp+0xA0], xmm10
000074c3551e185a  vmovaps [rsp+0xB0], xmm11
000074c3551e1863  vmovaps [rsp+0xC0], xmm12
000074c3551e186c  vmovaps [rsp+0xD0], xmm13
000074c3551e1875  vmovaps [rsp+0xE0], xmm15
000074c3551e187e  sub rsp, 0x30
000074c3551e1882  movaps [rsp], xmm14
000074c3551e1887  movaps [rsp+0x10], xmm1
000074c3551e188c  movaps [rsp+0x20], xmm7
000074c3551e1891  lea rdi, [rsp]
000074c3551e1895  mov esi, 0x00
000074c3551e189a  mov rax, 0x5F9407FA9530
000074c3551e18a4  call rax
000074c3551e18a6  movaps xmm14, [rsp]
000074c3551e18ab  add rsp, 0x30
000074c3551e18af  vmovaps xmm0, [rsp]
000074c3551e18b4  vmovaps xmm1, [rsp+0x10]
000074c3551e18ba  vmovaps xmm2, [rsp+0x20]
000074c3551e18c0  vmovaps xmm3, [rsp+0x30]
000074c3551e18c6  vmovaps xmm4, [rsp+0x40]
000074c3551e18cc  vmovaps xmm5, [rsp+0x50]
000074c3551e18d2  vmovaps xmm6, [rsp+0x60]
000074c3551e18d8  vmovaps xmm7, [rsp+0x70]
000074c3551e18de  vmovaps xmm8, [rsp+0x80]
000074c3551e18e7  vmovaps xmm9, [rsp+0x90]
000074c3551e18f0  vmovaps xmm10, [rsp+0xA0]
000074c3551e18f9  vmovaps xmm11, [rsp+0xB0]
000074c3551e1902  vmovaps xmm12, [rsp+0xC0]
000074c3551e190b  vmovaps xmm13, [rsp+0xD0]
000074c3551e1914  vmovaps xmm15, [rsp+0xE0]
000074c3551e191d  add rsp, 0xF0
000074c3551e1924  pop r11
000074c3551e1926  pop r10
000074c3551e1928  pop r9
000074c3551e192a  pop r8
000074c3551e192c  pop rsi
000074c3551e192d  pop rdi
000074c3551e192e  pop rdx
000074c3551e192f  pop rcx
000074c3551e1930  pop rax
000074c3551e1931  add rsp, 0x08
000074c3551e1935  jmp 0x000074C3551DC843
000074c3551e193a  sub rsp, 0x08
000074c3551e193e  push rax
000074c3551e193f  push rcx
000074c3551e1940  push rdx
000074c3551e1941  push rdi
000074c3551e1942  push rsi
000074c3551e1943  push r8
000074c3551e1945  push r9
000074c3551e1947  push r10
000074c3551e1949  push r11
000074c3551e194b  sub rsp, 0xF0
000074c3551e1952  vmovaps [rsp], xmm0
000074c3551e1957  vmovaps [rsp+0x10], xmm2
000074c3551e195d  vmovaps [rsp+0x20], xmm3
000074c3551e1963  vmovaps [rsp+0x30], xmm4
000074c3551e1969  vmovaps [rsp+0x40], xmm5
000074c3551e196f  vmovaps [rsp+0x50], xmm6
000074c3551e1975  vmovaps [rsp+0x60], xmm7
000074c3551e197b  vmovaps [rsp+0x70], xmm8
000074c3551e1981  vmovaps [rsp+0x80], xmm9
000074c3551e198a  vmovaps [rsp+0x90], xmm10
000074c3551e1993  vmovaps [rsp+0xA0], xmm11
000074c3551e199c  vmovaps [rsp+0xB0], xmm12
000074c3551e19a5  vmovaps [rsp+0xC0], xmm13
000074c3551e19ae  vmovaps [rsp+0xD0], xmm14
000074c3551e19b7  vmovaps [rsp+0xE0], xmm15
000074c3551e19c0  sub rsp, 0x30
000074c3551e19c4  movaps [rsp], xmm1
000074c3551e19c8  movaps [rsp+0x10], xmm8
000074c3551e19ce  movaps [rsp+0x20], xmm9
000074c3551e19d4  lea rdi, [rsp]
000074c3551e19d8  mov esi, 0x00
000074c3551e19dd  mov rax, 0x5F9407FA9530
000074c3551e19e7  call rax
000074c3551e19e9  movaps xmm1, [rsp]
000074c3551e19ed  add rsp, 0x30
000074c3551e19f1  vmovaps xmm0, [rsp]
000074c3551e19f6  vmovaps xmm2, [rsp+0x10]
000074c3551e19fc  vmovaps xmm3, [rsp+0x20]
000074c3551e1a02  vmovaps xmm4, [rsp+0x30]
000074c3551e1a08  vmovaps xmm5, [rsp+0x40]
000074c3551e1a0e  vmovaps xmm6, [rsp+0x50]
000074c3551e1a14  vmovaps xmm7, [rsp+0x60]
000074c3551e1a1a  vmovaps xmm8, [rsp+0x70]
000074c3551e1a20  vmovaps xmm9, [rsp+0x80]
000074c3551e1a29  vmovaps xmm10, [rsp+0x90]
000074c3551e1a32  vmovaps xmm11, [rsp+0xA0]
000074c3551e1a3b  vmovaps xmm12, [rsp+0xB0]
000074c3551e1a44  vmovaps xmm13, [rsp+0xC0]
000074c3551e1a4d  vmovaps xmm14, [rsp+0xD0]
000074c3551e1a56  vmovaps xmm15, [rsp+0xE0]
000074c3551e1a5f  add rsp, 0xF0
000074c3551e1a66  pop r11
000074c3551e1a68  pop r10
000074c3551e1a6a  pop r9
000074c3551e1a6c  pop r8
000074c3551e1a6e  pop rsi
000074c3551e1a6f  pop rdi
000074c3551e1a70  pop rdx
000074c3551e1a71  pop rcx
000074c3551e1a72  pop rax
000074c3551e1a73  add rsp, 0x08
000074c3551e1a77  jmp 0x000074C3551DC865
000074c3551e1a7c  call 0x000074C3550E5940
000074c3551e1a81  jmp 0x000074C3551DC873
000074c3551e1a86  call 0x000074C35500C380
000074c3551e1a8b  jmp 0x000074C3551DC87D
000074c3551e1a90  call 0x000074C35500D600
000074c3551e1a95  jmp 0x000074C3551DC887
000074c3551e1a9a  call 0x000074C354FFF540
000074c3551e1a9f  jmp 0x000074C3551DC891
000074c3551e1aa4  int3
000074c3551e1aa5  nop [rax+rax*1], ax
000074c3551e1aae  nop
000074c3551e1ab0  mov rax, [r15+0xF8]
000074c3551e1ab7  lea r14, [rax+0x140]
000074c3551e1abe  mov r12, [r13+r14*1]
000074c3551e1ac3  mov [r15+0xE8], r12
000074c3551e1aca  lea r14, [rax+0x130]
000074c3551e1ad1  mov r12, [r13+r14*1]
000074c3551e1ad6  lea r14, [rax+0x138]
000074c3551e1add  mov r11, [r13+r14*1]
000074c3551e1ae2  movq xmm1, r12
000074c3551e1ae7  movq xmm15, r11
000074c3551e1aec  movq xmm1, xmm1
000074c3551e1af0  movq xmm1, xmm1
000074c3551e1af4  movaps [r15+0x1A0], xmm1
000074c3551e1afc  movq xmm15, xmm15
000074c3551e1b01  movq xmm15, xmm15
000074c3551e1b06  movaps [r15+0x190], xmm15
000074c3551e1b0e  lea r14, [rax+0x120]
000074c3551e1b15  mov r12, [r13+r14*1]
000074c3551e1b1a  lea r14, [rax+0x128]
000074c3551e1b21  mov r11, [r13+r14*1]
000074c3551e1b26  movq xmm1, r12
000074c3551e1b2b  movq xmm15, r11
000074c3551e1b30  movq xmm1, xmm1
000074c3551e1b34  movq xmm1, xmm1
000074c3551e1b38  movaps [r15+0x1C0], xmm1
000074c3551e1b40  movq xmm15, xmm15
000074c3551e1b45  movq xmm15, xmm15
000074c3551e1b4a  movaps [r15+0x1B0], xmm15
000074c3551e1b52  lea r14, [rax+0x110]
000074c3551e1b59  mov r12, [r13+r14*1]
000074c3551e1b5e  lea r14, [rax+0x118]
000074c3551e1b65  mov r11, [r13+r14*1]
000074c3551e1b6a  movq xmm1, r12
000074c3551e1b6f  movq xmm15, r11
000074c3551e1b74  movq xmm1, xmm1
000074c3551e1b78  movq xmm1, xmm1
000074c3551e1b7c  movaps [r15+0x1E0], xmm1
000074c3551e1b84  movq xmm15, xmm15
000074c3551e1b89  movq xmm15, xmm15
000074c3551e1b8e  movaps [r15+0x1D0], xmm15
000074c3551e1b96  lea r14, [rax+0x100]
000074c3551e1b9d  mov r12, [r13+r14*1]
000074c3551e1ba2  lea r14, [rax+0x108]
000074c3551e1ba9  mov r11, [r13+r14*1]
000074c3551e1bae  movq xmm1, r12
000074c3551e1bb3  movq xmm15, r11
000074c3551e1bb8  movq xmm1, xmm1
000074c3551e1bbc  movq xmm1, xmm1
000074c3551e1bc0  movaps [r15+0x200], xmm1
000074c3551e1bc8  movq xmm15, xmm15
000074c3551e1bcd  movq xmm15, xmm15
000074c3551e1bd2  movaps [r15+0x1F0], xmm15
000074c3551e1bda  mov qword ptr [r15+0x40], 0x430000
000074c3551e1be2  mov r14d, 0x430510
000074c3551e1be8  mov r12, [r13+r14*1]
000074c3551e1bed  movq xmm1, r12
000074c3551e1bf2  lea r14, [rax+0x150]
000074c3551e1bf9  mov [r15+0xF8], r14
000074c3551e1c00  mov rax, [r15+0x50]
000074c3551e1c04  movups xmm15, [r13+rax*1]
000074c3551e1c0a  movaps [r15+0x120], xmm15
000074c3551e1c12  mov qword ptr [r15+0x48], 0x10
000074c3551e1c1a  xor eax, eax
000074c3551e1c1c  mov r14d, 0x10
000074c3551e1c22  mov r12d, 0x200
000074c3551e1c28  cmp r14, r12
000074c3551e1c2b  cmc
000074c3551e1c2c  lahf
000074c3551e1c2d  seto al
000074c3551e1c30  mov [r15+0x108], eax
000074c3551e1c37  pextrq rax, xmm15, 0x01
000074c3551e1c3e  movq xmm14, rax
000074c3551e1c43  movaps [r15+0x130], xmm14
000074c3551e1c4b  movq rax, xmm1
000074c3551e1c50  movq r14, xmm15
000074c3551e1c55  vmovq xmm1, rax
000074c3551e1c5a  vmovq xmm15, r14
000074c3551e1c5f  movaps xmm13, xmm1
000074c3551e1c63  addsd xmm13, xmm15
000074c3551e1c68  ucomisd xmm13, xmm13
000074c3551e1c6d  jp 0x000074C3551E1D86
000074c3551e1c73  movq xmm13, xmm13
000074c3551e1c78  movq rax, xmm13
000074c3551e1c7d  movq r14, xmm14
000074c3551e1c82  vmovq xmm1, rax
000074c3551e1c87  vmovq xmm15, r14
000074c3551e1c8c  movaps xmm14, xmm1
000074c3551e1c90  addsd xmm14, xmm15
000074c3551e1c95  ucomisd xmm14, xmm14
000074c3551e1c9a  jp 0x000074C3551E1DCE
000074c3551e1ca0  movq xmm14, xmm14
000074c3551e1ca5  movaps [r15+0x110], xmm14
000074c3551e1cad  mov eax, [r15+0x108]
000074c3551e1cb4  sahf
000074c3551e1cb5  jnz 0x000074C3551E1CE7
000074c3551e1cb7  cmp dword ptr [r15+0x318], 0x00
000074c3551e1cbf  jz 0x000074C3551E1FE0
000074c3551e1cc5  nop [rax+rax*1], ax
000074c3551e1cce  nop [rax+rax*1], eax
000074c3551e1cd6  mov eax, 0x410490
000074c3551e1cdb  mov [r15+0x100], rax
000074c3551e1ce2  jmp 0x000074C354FFE110
000074c3551e1ce7  cmp dword ptr [r15+0x318], 0x00
000074c3551e1cef  jz 0x000074C3551E1E20
000074c3551e1cf5  nop [rax+rax*1], ax
000074c3551e1cfe  nop [rax+rax*1], eax
000074c3551e1d06  mov eax, 0x410474
000074c3551e1d0b  mov [r15+0x100], rax
000074c3551e1d12  jmp 0x000074C354FFE110
000074c3551e1d17  int3
000074c3551e1d18  call 0x000074C3550E27E0
000074c3551e1d1d  jmp 0x000074C3551E1AC3
000074c3551e1d22  call 0x000074C3550E27E0
000074c3551e1d27  jmp 0x000074C3551E1AD6
000074c3551e1d2c  call 0x000074C3550E1570
000074c3551e1d31  jmp 0x000074C3551E1AE2
000074c3551e1d36  call 0x000074C3550E27E0
000074c3551e1d3b  jmp 0x000074C3551E1B1A
000074c3551e1d40  call 0x000074C3550E1570
000074c3551e1d45  jmp 0x000074C3551E1B26
000074c3551e1d4a  call 0x000074C3550E27E0
000074c3551e1d4f  jmp 0x000074C3551E1B5E
000074c3551e1d54  call 0x000074C3550E1570
000074c3551e1d59  jmp 0x000074C3551E1B6A
000074c3551e1d5e  call 0x000074C3550E27E0
000074c3551e1d63  jmp 0x000074C3551E1BA2
000074c3551e1d68  call 0x000074C3550E1570
000074c3551e1d6d  jmp 0x000074C3551E1BAE
000074c3551e1d72  call 0x000074C3550E27E0
000074c3551e1d77  jmp 0x000074C3551E1BED
000074c3551e1d7c  call 0x000074C35500E760
000074c3551e1d81  jmp 0x000074C3551E1C0A
000074c3551e1d86  ucomisd xmm1, xmm15
000074c3551e1d8b  jp 0x000074C3551E1D9A
000074c3551e1d8d  movaps xmm13, [0x000074C354DFE060]
000074c3551e1d95  jmp 0x000074C3551E1C73
000074c3551e1d9a  vxorps xmm0, xmm1, xmm15
000074c3551e1d9f  pextrw eax, xmm0, 0x03
000074c3551e1da4  and eax, 0x7FF8
000074c3551e1da9  cmp eax, 0x08
000074c3551e1dac  jnz 0x000074C3551E1C73
000074c3551e1db2  movq rax, xmm15
000074c3551e1db7  shl rax, 0x0D
000074c3551e1dbb  jbe 0x000074C3551E1C73
000074c3551e1dc1  vorps xmm13, xmm15, [0x000074C354DFE070]
000074c3551e1dc9  jmp 0x000074C3551E1C73
000074c3551e1dce  ucomisd xmm1, xmm15
000074c3551e1dd3  jp 0x000074C3551E1DE2
000074c3551e1dd5  movaps xmm14, [0x000074C354DFE060]
000074c3551e1ddd  jmp 0x000074C3551E1CA0
000074c3551e1de2  vxorps xmm0, xmm1, xmm15
000074c3551e1de7  pextrw eax, xmm0, 0x03
000074c3551e1dec  and eax, 0x7FF8
000074c3551e1df1  cmp eax, 0x08
000074c3551e1df4  jnz 0x000074C3551E1CA0
000074c3551e1dfa  movq rax, xmm15
000074c3551e1dff  shl rax, 0x0D
000074c3551e1e03  jbe 0x000074C3551E1CA0
000074c3551e1e09  vorps xmm14, xmm15, [0x000074C354DFE070]
000074c3551e1e11  jmp 0x000074C3551E1CA0
000074c3551e1e16  int3
000074c3551e1e17  nop [rax+rax*1], ax
000074c3551e1e20  mov rax, [r15+0x48]
000074c3551e1e24  mov r14, [r15+0x50]
000074c3551e1e28  lea r12, [r14+rax*1]
000074c3551e1e2c  movups xmm1, [r13+r12*1]
000074c3551e1e32  movaps [r15+0x120], xmm1
000074c3551e1e3a  lea r14, [rax+0x10]
000074c3551e1e3e  mov [r15+0x48], r14
000074c3551e1e42  xor eax, eax
000074c3551e1e44  mov r12d, 0x200
000074c3551e1e4a  cmp r14, r12
000074c3551e1e4d  cmc
000074c3551e1e4e  lahf
000074c3551e1e4f  seto al
000074c3551e1e52  mov [r15+0x108], eax
000074c3551e1e59  pextrq rax, xmm1, 0x01
000074c3551e1e60  movq xmm15, rax
000074c3551e1e65  movaps [r15+0x130], xmm15
000074c3551e1e6d  movaps xmm14, [r15+0x110]
000074c3551e1e75  movq rax, xmm14
000074c3551e1e7a  movq r14, xmm1
000074c3551e1e7f  vmovq xmm1, rax
000074c3551e1e84  vmovq xmm14, r14
000074c3551e1e89  movaps xmm13, xmm1
000074c3551e1e8d  addsd xmm13, xmm14
000074c3551e1e92  ucomisd xmm13, xmm13
000074c3551e1e97  jp 0x000074C3551E1F4C
000074c3551e1e9d  movq xmm13, xmm13
000074c3551e1ea2  movq rax, xmm13
000074c3551e1ea7  movq r14, xmm15
000074c3551e1eac  vmovq xmm1, rax
000074c3551e1eb1  vmovq xmm15, r14
000074c3551e1eb6  movaps xmm14, xmm1
000074c3551e1eba  addsd xmm14, xmm15
000074c3551e1ebf  ucomisd xmm14, xmm14
000074c3551e1ec4  jp 0x000074C3551E1F94
000074c3551e1eca  movq xmm14, xmm14
000074c3551e1ecf  movaps [r15+0x110], xmm14
000074c3551e1ed7  mov eax, [r15+0x108]
000074c3551e1ede  sahf
000074c3551e1edf  jnz 0x000074C3551E1F11
000074c3551e1ee1  cmp dword ptr [r15+0x318], 0x00
000074c3551e1ee9  jz 0x000074C3551E1FE0
000074c3551e1eef  nop [rax+rax*1], ax
000074c3551e1ef8  nop [rax+rax*1], eax
000074c3551e1f00  mov eax, 0x410490
000074c3551e1f05  mov [r15+0x100], rax
000074c3551e1f0c  jmp 0x000074C354FFE110
000074c3551e1f11  cmp dword ptr [r15+0x318], 0x00
000074c3551e1f19  jz 0x000074C3551E1E20
000074c3551e1f1f  nop [rax+rax*1], ax
000074c3551e1f28  nop [rax+rax*1], eax
000074c3551e1f30  mov eax, 0x410474
000074c3551e1f35  mov [r15+0x100], rax
000074c3551e1f3c  jmp 0x000074C354FFE110
000074c3551e1f41  int3
000074c3551e1f42  call 0x000074C3550B52F0
000074c3551e1f47  jmp 0x000074C3551E1E32
000074c3551e1f4c  ucomisd xmm1, xmm14
000074c3551e1f51  jp 0x000074C3551E1F60
000074c3551e1f53  movaps xmm13, [0x000074C354DFE060]
000074c3551e1f5b  jmp 0x000074C3551E1E9D
000074c3551e1f60  vxorps xmm0, xmm1, xmm14
000074c3551e1f65  pextrw eax, xmm0, 0x03
000074c3551e1f6a  and eax, 0x7FF8
000074c3551e1f6f  cmp eax, 0x08
000074c3551e1f72  jnz 0x000074C3551E1E9D
000074c3551e1f78  movq rax, xmm14
000074c3551e1f7d  shl rax, 0x0D
000074c3551e1f81  jbe 0x000074C3551E1E9D
000074c3551e1f87  vorps xmm13, xmm14, [0x000074C354DFE070]
000074c3551e1f8f  jmp 0x000074C3551E1E9D
000074c3551e1f94  ucomisd xmm1, xmm15
000074c3551e1f99  jp 0x000074C3551E1FA8
000074c3551e1f9b  movaps xmm14, [0x000074C354DFE060]
000074c3551e1fa3  jmp 0x000074C3551E1ECA
000074c3551e1fa8  vxorps xmm0, xmm1, xmm15
000074c3551e1fad  pextrw eax, xmm0, 0x03
000074c3551e1fb2  and eax, 0x7FF8
000074c3551e1fb7  cmp eax, 0x08
000074c3551e1fba  jnz 0x000074C3551E1ECA
000074c3551e1fc0  movq rax, xmm15
000074c3551e1fc5  shl rax, 0x0D
000074c3551e1fc9  jbe 0x000074C3551E1ECA
000074c3551e1fcf  vorps xmm14, xmm15, [0x000074C354DFE070]
000074c3551e1fd7  jmp 0x000074C3551E1ECA
000074c3551e1fdc  int3
000074c3551e1fdd  nop [rax], eax
000074c3551e1fe0  mov rax, [r15+0x40]
000074c3551e1fe4  lea r14, [rax+0x510]
000074c3551e1feb  movaps xmm1, [r15+0x110]
000074c3551e1ff3  movq rax, xmm1
000074c3551e1ff8  mov [r13+r14*1], rax
000074c3551e1ffd  mov rax, [r15+0xF0]
000074c3551e2004  mov [r15+0x100], rax
000074c3551e200b  jmp 0x000074C3551CE5C0
000074c3551e2010  int3
000074c3551e2011  call 0x000074C3550D5EB0
000074c3551e2016  jmp 0x000074C3551E1FFD
000074c3551e201b  int3
000074c3551e201c  nop [rax], eax
000074c3551e2020  mov qword ptr [r15+0x100], 0x04
000074c3551e202b  mov esi, 0x00
000074c3551e2030  mov edx, 0x09
000074c3551e2035  mov rdi, 0x7FFCE55C1C50
000074c3551e203f  mov rax, 0x5F9407E3C970
000074c3551e2049  call rax
000074c3551e204b  cmp dword ptr [r15+0x318], 0x00
000074c3551e2053  jnz 0x000074C354FFE110
000074c3551e2059  jmp 0x000074C354FFE0A0
000074c3551e205e  int3
000074c3551e205f  int3
