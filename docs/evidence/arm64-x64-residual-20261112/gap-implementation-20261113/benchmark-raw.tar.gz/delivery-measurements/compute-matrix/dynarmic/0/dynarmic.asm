00007b629adce69b  nop [rax+rax*1], eax
00007b629adce6a0  vmovaps xmm1, [0x00007B629A9FE010]
00007b629adce6a8  movq xmm1, xmm1
00007b629adce6ac  movaps [r15+0x110], xmm1
00007b629adce6b4  vmovaps xmm1, [0x00007B629A9FE020]
00007b629adce6bc  movq xmm1, xmm1
00007b629adce6c0  movaps [r15+0x120], xmm1
00007b629adce6c8  mov eax, 0x4204C0
00007b629adce6cd  mov r14, [r13+rax*1]
00007b629adce6d2  movq xmm1, r14
00007b629adce6d7  movaps [r15+0x130], xmm1
00007b629adce6df  vmovaps xmm1, [0x00007B629A9FE030]
00007b629adce6e7  vpbroadcastq xmm1, xmm1
00007b629adce6ec  movaps [r15+0x140], xmm1
00007b629adce6f4  mov qword ptr [r15+0x40], 0x02
00007b629adce6fc  vmovaps xmm15, [0x00007B629A9FE040]
00007b629adce704  movq xmm15, xmm15
00007b629adce709  movaps [r15+0x150], xmm15
00007b629adce711  mov qword ptr [r15+0x58], 0x420000
00007b629adce719  vmovaps xmm15, [0x00007B629A9FE050]
00007b629adce721  vpbroadcastq xmm15, xmm15
00007b629adce726  movaps [r15+0x160], xmm15
00007b629adce72e  mov rax, [r15+0x40]
00007b629adce732  vmovq xmm14, rax
00007b629adce737  vpbroadcastq xmm14, xmm14
00007b629adce73c  movaps [r15+0x170], xmm14
00007b629adce744  mov eax, 0x4204D0
00007b629adce749  movups xmm13, [r13+rax*1]
00007b629adce74f  mov qword ptr [r15+0x40], 0x430518
00007b629adce757  mov qword ptr [r15+0x50], 0x430720
00007b629adce75f  vpmovqd xmm12, xmm13
00007b629adce765  pxor xmm11, xmm11
00007b629adce76a  punpcklqdq xmm12, xmm11
00007b629adce76f  movaps [r15+0x210], xmm12
00007b629adce777  movq xmm12, qword ptr [r15+0x120]
00007b629adce780  movq xmm11, qword ptr [r15+0x130]
00007b629adce789  psubd xmm12, xmm11
00007b629adce78e  movq xmm12, xmm12
00007b629adce793  paddq xmm13, xmm14
00007b629adce798  movaps [r15+0x180], xmm13
00007b629adce7a0  movq xmm14, qword ptr [r15+0x150]
00007b629adce7a9  paddd xmm11, xmm14
00007b629adce7ae  movq xmm11, xmm11
00007b629adce7b3  movq xmm11, xmm11
00007b629adce7b8  movaps [r15+0x130], xmm11
00007b629adce7c0  pmovzxdq xmm12, xmm12
00007b629adce7c6  psllq xmm12, 0x00
00007b629adce7cc  movq xmm14, qword ptr [r15+0x210]
00007b629adce7d5  movq xmm13, qword ptr [r15+0x110]
00007b629adce7de  paddd xmm14, xmm13
00007b629adce7e3  movq xmm14, xmm14
00007b629adce7e8  vcvtuqq2pd xmm12, xmm12
00007b629adce7ee  pmovzxdq xmm14, xmm14
00007b629adce7f4  psllq xmm14, 0x00
00007b629adce7fa  vcvtuqq2pd xmm14, xmm14
00007b629adce800  movaps xmm13, xmm12
00007b629adce804  mulpd xmm13, xmm1
00007b629adce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007b629adce80f  ptest xmm11, xmm11
00007b629adce815  jnz 0x00007B629ADCE8FF
00007b629adce81b  movaps [r15+0x220], xmm13
00007b629adce823  mov eax, 0x430720
00007b629adce828  movups [r13+rax*1], xmm13
00007b629adce82e  movaps xmm1, xmm14
00007b629adce832  mulpd xmm1, xmm15
00007b629adce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007b629adce83c  ptest xmm13, xmm13
00007b629adce842  jnz 0x00007B629ADCEA4C
00007b629adce848  movaps [r15+0x210], xmm1
00007b629adce850  mov eax, 0x430518
00007b629adce855  movups [r13+rax*1], xmm1
00007b629adce85b  mov qword ptr [r15+0x48], 0x10
00007b629adce863  xor eax, eax
00007b629adce865  mov r14d, 0x10
00007b629adce86b  mov r12d, 0x200
00007b629adce871  cmp r14, r12
00007b629adce874  cmc
00007b629adce875  lahf
00007b629adce876  seto al
00007b629adce879  mov [r15+0x108], eax
00007b629adce880  mov eax, [r15+0x108]
00007b629adce887  sahf
00007b629adce888  jnz 0x00007B629ADCE8BA
00007b629adce88a  cmp dword ptr [r15+0x318], 0x00
00007b629adce892  jz 0x00007B629ADCEFF0
00007b629adce898  nop [rax+rax*1], ax
00007b629adce8a1  nop [rax+rax*1], eax
00007b629adce8a9  mov eax, 0x4101EC
00007b629adce8ae  mov [r15+0x100], rax
00007b629adce8b5  jmp 0x00007B629ABFE110
00007b629adce8ba  cmp dword ptr [r15+0x318], 0x00
00007b629adce8c2  jz 0x00007B629ADCEBA0
00007b629adce8c8  nop [rax+rax*1], ax
00007b629adce8d1  nop [rax+rax*1], eax
00007b629adce8d9  mov eax, 0x4101AC
00007b629adce8de  mov [r15+0x100], rax
00007b629adce8e5  jmp 0x00007B629ABFE110
00007b629adce8ea  int3
00007b629adce8eb  call 0x00007B629AC0DC20
00007b629adce8f0  jmp 0x00007B629ADCE6D2
00007b629adce8f5  call 0x00007B629AC0C260
00007b629adce8fa  jmp 0x00007B629ADCE74F
00007b629adce8ff  sub rsp, 0x08
00007b629adce903  push rax
00007b629adce904  push rcx
00007b629adce905  push rdx
00007b629adce906  push rdi
00007b629adce907  push rsi
00007b629adce908  push r8
00007b629adce90a  push r9
00007b629adce90c  push r10
00007b629adce90e  push r11
00007b629adce910  sub rsp, 0xF0
00007b629adce917  vmovaps [rsp], xmm0
00007b629adce91c  vmovaps [rsp+0x10], xmm1
00007b629adce922  vmovaps [rsp+0x20], xmm2
00007b629adce928  vmovaps [rsp+0x30], xmm3
00007b629adce92e  vmovaps [rsp+0x40], xmm4
00007b629adce934  vmovaps [rsp+0x50], xmm5
00007b629adce93a  vmovaps [rsp+0x60], xmm6
00007b629adce940  vmovaps [rsp+0x70], xmm7
00007b629adce946  vmovaps [rsp+0x80], xmm8
00007b629adce94f  vmovaps [rsp+0x90], xmm9
00007b629adce958  vmovaps [rsp+0xA0], xmm10
00007b629adce961  vmovaps [rsp+0xB0], xmm11
00007b629adce96a  vmovaps [rsp+0xC0], xmm12
00007b629adce973  vmovaps [rsp+0xD0], xmm14
00007b629adce97c  vmovaps [rsp+0xE0], xmm15
00007b629adce985  sub rsp, 0x30
00007b629adce989  movaps [rsp], xmm13
00007b629adce98e  movaps [rsp+0x10], xmm12
00007b629adce994  movaps [rsp+0x20], xmm1
00007b629adce999  lea rdi, [rsp]
00007b629adce99d  mov esi, 0x00
00007b629adce9a2  mov rax, 0x583FED93F530
00007b629adce9ac  call rax
00007b629adce9ae  movaps xmm13, [rsp]
00007b629adce9b3  add rsp, 0x30
00007b629adce9b7  vmovaps xmm0, [rsp]
00007b629adce9bc  vmovaps xmm1, [rsp+0x10]
00007b629adce9c2  vmovaps xmm2, [rsp+0x20]
00007b629adce9c8  vmovaps xmm3, [rsp+0x30]
00007b629adce9ce  vmovaps xmm4, [rsp+0x40]
00007b629adce9d4  vmovaps xmm5, [rsp+0x50]
00007b629adce9da  vmovaps xmm6, [rsp+0x60]
00007b629adce9e0  vmovaps xmm7, [rsp+0x70]
00007b629adce9e6  vmovaps xmm8, [rsp+0x80]
00007b629adce9ef  vmovaps xmm9, [rsp+0x90]
00007b629adce9f8  vmovaps xmm10, [rsp+0xA0]
00007b629adcea01  vmovaps xmm11, [rsp+0xB0]
00007b629adcea0a  vmovaps xmm12, [rsp+0xC0]
00007b629adcea13  vmovaps xmm14, [rsp+0xD0]
00007b629adcea1c  vmovaps xmm15, [rsp+0xE0]
00007b629adcea25  add rsp, 0xF0
00007b629adcea2c  pop r11
00007b629adcea2e  pop r10
00007b629adcea30  pop r9
00007b629adcea32  pop r8
00007b629adcea34  pop rsi
00007b629adcea35  pop rdi
00007b629adcea36  pop rdx
00007b629adcea37  pop rcx
00007b629adcea38  pop rax
00007b629adcea39  add rsp, 0x08
00007b629adcea3d  jmp 0x00007B629ADCE81B
00007b629adcea42  call 0x00007B629AC0C380
00007b629adcea47  jmp 0x00007B629ADCE82E
00007b629adcea4c  sub rsp, 0x08
00007b629adcea50  push rax
00007b629adcea51  push rcx
00007b629adcea52  push rdx
00007b629adcea53  push rdi
00007b629adcea54  push rsi
00007b629adcea55  push r8
00007b629adcea57  push r9
00007b629adcea59  push r10
00007b629adcea5b  push r11
00007b629adcea5d  sub rsp, 0xF0
00007b629adcea64  vmovaps [rsp], xmm0
00007b629adcea69  vmovaps [rsp+0x10], xmm2
00007b629adcea6f  vmovaps [rsp+0x20], xmm3
00007b629adcea75  vmovaps [rsp+0x30], xmm4
00007b629adcea7b  vmovaps [rsp+0x40], xmm5
00007b629adcea81  vmovaps [rsp+0x50], xmm6
00007b629adcea87  vmovaps [rsp+0x60], xmm7
00007b629adcea8d  vmovaps [rsp+0x70], xmm8
00007b629adcea93  vmovaps [rsp+0x80], xmm9
00007b629adcea9c  vmovaps [rsp+0x90], xmm10
00007b629adceaa5  vmovaps [rsp+0xA0], xmm11
00007b629adceaae  vmovaps [rsp+0xB0], xmm12
00007b629adceab7  vmovaps [rsp+0xC0], xmm13
00007b629adceac0  vmovaps [rsp+0xD0], xmm14
00007b629adceac9  vmovaps [rsp+0xE0], xmm15
00007b629adcead2  sub rsp, 0x30
00007b629adcead6  movaps [rsp], xmm1
00007b629adceada  movaps [rsp+0x10], xmm14
00007b629adceae0  movaps [rsp+0x20], xmm15
00007b629adceae6  lea rdi, [rsp]
00007b629adceaea  mov esi, 0x00
00007b629adceaef  mov rax, 0x583FED93F530
00007b629adceaf9  call rax
00007b629adceafb  movaps xmm1, [rsp]
00007b629adceaff  add rsp, 0x30
00007b629adceb03  vmovaps xmm0, [rsp]
00007b629adceb08  vmovaps xmm2, [rsp+0x10]
00007b629adceb0e  vmovaps xmm3, [rsp+0x20]
00007b629adceb14  vmovaps xmm4, [rsp+0x30]
00007b629adceb1a  vmovaps xmm5, [rsp+0x40]
00007b629adceb20  vmovaps xmm6, [rsp+0x50]
00007b629adceb26  vmovaps xmm7, [rsp+0x60]
00007b629adceb2c  vmovaps xmm8, [rsp+0x70]
00007b629adceb32  vmovaps xmm9, [rsp+0x80]
00007b629adceb3b  vmovaps xmm10, [rsp+0x90]
00007b629adceb44  vmovaps xmm11, [rsp+0xA0]
00007b629adceb4d  vmovaps xmm12, [rsp+0xB0]
00007b629adceb56  vmovaps xmm13, [rsp+0xC0]
00007b629adceb5f  vmovaps xmm14, [rsp+0xD0]
00007b629adceb68  vmovaps xmm15, [rsp+0xE0]
00007b629adceb71  add rsp, 0xF0
00007b629adceb78  pop r11
00007b629adceb7a  pop r10
00007b629adceb7c  pop r9
00007b629adceb7e  pop r8
00007b629adceb80  pop rsi
00007b629adceb81  pop rdi
00007b629adceb82  pop rdx
00007b629adceb83  pop rcx
00007b629adceb84  pop rax
00007b629adceb85  add rsp, 0x08
00007b629adceb89  jmp 0x00007B629ADCE848
00007b629adceb8e  call 0x00007B629ABFF540
00007b629adceb93  jmp 0x00007B629ADCE85B
00007b629adceb98  int3
00007b629adceb99  nop [rax], eax
00007b629adceba0  movaps xmm1, [r15+0x180]
00007b629adceba8  vpmovqd xmm15, xmm1
00007b629adcebae  pxor xmm14, xmm14
00007b629adcebb3  punpcklqdq xmm15, xmm14
00007b629adcebb8  movaps [r15+0x210], xmm15
00007b629adcebc0  movq xmm15, qword ptr [r15+0x120]
00007b629adcebc9  movq xmm14, qword ptr [r15+0x130]
00007b629adcebd2  psubd xmm15, xmm14
00007b629adcebd7  movq xmm15, xmm15
00007b629adcebdc  movaps xmm13, [r15+0x170]
00007b629adcebe4  paddq xmm1, xmm13
00007b629adcebe9  movaps [r15+0x180], xmm1
00007b629adcebf1  movq xmm1, qword ptr [r15+0x150]
00007b629adcebfa  paddd xmm14, xmm1
00007b629adcebff  movq xmm14, xmm14
00007b629adcec04  movq xmm14, xmm14
00007b629adcec09  movaps [r15+0x130], xmm14
00007b629adcec11  pmovzxdq xmm15, xmm15
00007b629adcec17  psllq xmm15, 0x00
00007b629adcec1d  movq xmm1, qword ptr [r15+0x210]
00007b629adcec26  movq xmm14, qword ptr [r15+0x110]
00007b629adcec2f  paddd xmm1, xmm14
00007b629adcec34  movq xmm1, xmm1
00007b629adcec38  vcvtuqq2pd xmm15, xmm15
00007b629adcec3e  pmovzxdq xmm1, xmm1
00007b629adcec43  psllq xmm1, 0x00
00007b629adcec48  vcvtuqq2pd xmm1, xmm1
00007b629adcec4e  movaps xmm14, [r15+0x140]
00007b629adcec56  movaps xmm13, xmm15
00007b629adcec5a  mulpd xmm13, xmm14
00007b629adcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007b629adcec65  ptest xmm12, xmm12
00007b629adcec6b  jnz 0x00007B629ADCED4E
00007b629adcec71  movaps [r15+0x220], xmm13
00007b629adcec79  mov rax, [r15+0x48]
00007b629adcec7d  mov r14, [r15+0x50]
00007b629adcec81  lea r12, [r14+rax*1]
00007b629adcec85  movups [r13+r12*1], xmm13
00007b629adcec8b  movaps xmm15, [r15+0x160]
00007b629adcec93  movaps xmm14, xmm1
00007b629adcec97  mulpd xmm14, xmm15
00007b629adcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007b629adceca2  ptest xmm13, xmm13
00007b629adceca8  jnz 0x00007B629ADCEE9C
00007b629adcecae  movaps [r15+0x210], xmm14
00007b629adcecb6  mov r14, [r15+0x40]
00007b629adcecba  lea r12, [r14+rax*1]
00007b629adcecbe  movups [r13+r12*1], xmm14
00007b629adcecc4  lea r14, [rax+0x10]
00007b629adcecc8  mov [r15+0x48], r14
00007b629adceccc  xor eax, eax
00007b629adcecce  mov r12d, 0x200
00007b629adcecd4  cmp r14, r12
00007b629adcecd7  cmc
00007b629adcecd8  lahf
00007b629adcecd9  seto al
00007b629adcecdc  mov [r15+0x108], eax
00007b629adcece3  mov eax, [r15+0x108]
00007b629adcecea  sahf
00007b629adceceb  jnz 0x00007B629ADCED1D
00007b629adceced  cmp dword ptr [r15+0x318], 0x00
00007b629adcecf5  jz 0x00007B629ADCEFF0
00007b629adcecfb  nop [rax+rax*1], ax
00007b629adced04  nop [rax+rax*1], eax
00007b629adced0c  mov eax, 0x4101EC
00007b629adced11  mov [r15+0x100], rax
00007b629adced18  jmp 0x00007B629ABFE110
00007b629adced1d  cmp dword ptr [r15+0x318], 0x00
00007b629adced25  jz 0x00007B629ADCEBA0
00007b629adced2b  nop [rax+rax*1], ax
00007b629adced34  nop [rax+rax*1], eax
00007b629adced3c  mov eax, 0x4101AC
00007b629adced41  mov [r15+0x100], rax
00007b629adced48  jmp 0x00007B629ABFE110
00007b629adced4d  int3
00007b629adced4e  sub rsp, 0x08
00007b629adced52  push rax
00007b629adced53  push rcx
00007b629adced54  push rdx
00007b629adced55  push rdi
00007b629adced56  push rsi
00007b629adced57  push r8
00007b629adced59  push r9
00007b629adced5b  push r10
00007b629adced5d  push r11
00007b629adced5f  sub rsp, 0xF0
00007b629adced66  vmovaps [rsp], xmm0
00007b629adced6b  vmovaps [rsp+0x10], xmm1
00007b629adced71  vmovaps [rsp+0x20], xmm2
00007b629adced77  vmovaps [rsp+0x30], xmm3
00007b629adced7d  vmovaps [rsp+0x40], xmm4
00007b629adced83  vmovaps [rsp+0x50], xmm5
00007b629adced89  vmovaps [rsp+0x60], xmm6
00007b629adced8f  vmovaps [rsp+0x70], xmm7
00007b629adced95  vmovaps [rsp+0x80], xmm8
00007b629adced9e  vmovaps [rsp+0x90], xmm9
00007b629adceda7  vmovaps [rsp+0xA0], xmm10
00007b629adcedb0  vmovaps [rsp+0xB0], xmm11
00007b629adcedb9  vmovaps [rsp+0xC0], xmm12
00007b629adcedc2  vmovaps [rsp+0xD0], xmm14
00007b629adcedcb  vmovaps [rsp+0xE0], xmm15
00007b629adcedd4  sub rsp, 0x30
00007b629adcedd8  movaps [rsp], xmm13
00007b629adceddd  movaps [rsp+0x10], xmm15
00007b629adcede3  movaps [rsp+0x20], xmm14
00007b629adcede9  lea rdi, [rsp]
00007b629adceded  mov esi, 0x00
00007b629adcedf2  mov rax, 0x583FED93F530
00007b629adcedfc  call rax
00007b629adcedfe  movaps xmm13, [rsp]
00007b629adcee03  add rsp, 0x30
00007b629adcee07  vmovaps xmm0, [rsp]
00007b629adcee0c  vmovaps xmm1, [rsp+0x10]
00007b629adcee12  vmovaps xmm2, [rsp+0x20]
00007b629adcee18  vmovaps xmm3, [rsp+0x30]
00007b629adcee1e  vmovaps xmm4, [rsp+0x40]
00007b629adcee24  vmovaps xmm5, [rsp+0x50]
00007b629adcee2a  vmovaps xmm6, [rsp+0x60]
00007b629adcee30  vmovaps xmm7, [rsp+0x70]
00007b629adcee36  vmovaps xmm8, [rsp+0x80]
00007b629adcee3f  vmovaps xmm9, [rsp+0x90]
00007b629adcee48  vmovaps xmm10, [rsp+0xA0]
00007b629adcee51  vmovaps xmm11, [rsp+0xB0]
00007b629adcee5a  vmovaps xmm12, [rsp+0xC0]
00007b629adcee63  vmovaps xmm14, [rsp+0xD0]
00007b629adcee6c  vmovaps xmm15, [rsp+0xE0]
00007b629adcee75  add rsp, 0xF0
00007b629adcee7c  pop r11
00007b629adcee7e  pop r10
00007b629adcee80  pop r9
00007b629adcee82  pop r8
00007b629adcee84  pop rsi
00007b629adcee85  pop rdi
00007b629adcee86  pop rdx
00007b629adcee87  pop rcx
00007b629adcee88  pop rax
00007b629adcee89  add rsp, 0x08
00007b629adcee8d  jmp 0x00007B629ADCEC71
00007b629adcee92  call 0x00007B629ACC2240
00007b629adcee97  jmp 0x00007B629ADCEC8B
00007b629adcee9c  sub rsp, 0x08
00007b629adceea0  push rax
00007b629adceea1  push rcx
00007b629adceea2  push rdx
00007b629adceea3  push rdi
00007b629adceea4  push rsi
00007b629adceea5  push r8
00007b629adceea7  push r9
00007b629adceea9  push r10
00007b629adceeab  push r11
00007b629adceead  sub rsp, 0xF0
00007b629adceeb4  vmovaps [rsp], xmm0
00007b629adceeb9  vmovaps [rsp+0x10], xmm1
00007b629adceebf  vmovaps [rsp+0x20], xmm2
00007b629adceec5  vmovaps [rsp+0x30], xmm3
00007b629adceecb  vmovaps [rsp+0x40], xmm4
00007b629adceed1  vmovaps [rsp+0x50], xmm5
00007b629adceed7  vmovaps [rsp+0x60], xmm6
00007b629adceedd  vmovaps [rsp+0x70], xmm7
00007b629adceee3  vmovaps [rsp+0x80], xmm8
00007b629adceeec  vmovaps [rsp+0x90], xmm9
00007b629adceef5  vmovaps [rsp+0xA0], xmm10
00007b629adceefe  vmovaps [rsp+0xB0], xmm11
00007b629adcef07  vmovaps [rsp+0xC0], xmm12
00007b629adcef10  vmovaps [rsp+0xD0], xmm13
00007b629adcef19  vmovaps [rsp+0xE0], xmm15
00007b629adcef22  sub rsp, 0x30
00007b629adcef26  movaps [rsp], xmm14
00007b629adcef2b  movaps [rsp+0x10], xmm1
00007b629adcef30  movaps [rsp+0x20], xmm15
00007b629adcef36  lea rdi, [rsp]
00007b629adcef3a  mov esi, 0x00
00007b629adcef3f  mov rax, 0x583FED93F530
00007b629adcef49  call rax
00007b629adcef4b  movaps xmm14, [rsp]
00007b629adcef50  add rsp, 0x30
00007b629adcef54  vmovaps xmm0, [rsp]
00007b629adcef59  vmovaps xmm1, [rsp+0x10]
00007b629adcef5f  vmovaps xmm2, [rsp+0x20]
00007b629adcef65  vmovaps xmm3, [rsp+0x30]
00007b629adcef6b  vmovaps xmm4, [rsp+0x40]
00007b629adcef71  vmovaps xmm5, [rsp+0x50]
00007b629adcef77  vmovaps xmm6, [rsp+0x60]
00007b629adcef7d  vmovaps xmm7, [rsp+0x70]
00007b629adcef83  vmovaps xmm8, [rsp+0x80]
00007b629adcef8c  vmovaps xmm9, [rsp+0x90]
00007b629adcef95  vmovaps xmm10, [rsp+0xA0]
00007b629adcef9e  vmovaps xmm11, [rsp+0xB0]
00007b629adcefa7  vmovaps xmm12, [rsp+0xC0]
00007b629adcefb0  vmovaps xmm13, [rsp+0xD0]
00007b629adcefb9  vmovaps xmm15, [rsp+0xE0]
00007b629adcefc2  add rsp, 0xF0
00007b629adcefc9  pop r11
00007b629adcefcb  pop r10
00007b629adcefcd  pop r9
00007b629adcefcf  pop r8
00007b629adcefd1  pop rsi
00007b629adcefd2  pop rdi
00007b629adcefd3  pop rdx
00007b629adcefd4  pop rcx
00007b629adcefd5  pop rax
00007b629adcefd6  add rsp, 0x08
00007b629adcefda  jmp 0x00007B629ADCECAE
00007b629adcefdf  call 0x00007B629ACC34C0
00007b629adcefe4  jmp 0x00007B629ADCECC4
00007b629adcefe9  int3
00007b629adcefea  nop [rax+rax*1], ax
00007b629adceff0  mov rax, [r15+0xF8]
00007b629adceff7  lea r14, [rax-0x150]
00007b629adceffe  mov [r15+0xF8], r14
00007b629adcf005  mov rax, [r15+0x50]
00007b629adcf009  lea r12, [rax+0x80]
00007b629adcf010  movups xmm1, [r13+r12*1]
00007b629adcf016  lea r12, [rax+0x90]
00007b629adcf01d  movups xmm15, [r13+r12*1]
00007b629adcf023  mov qword ptr [r15+0x48], 0x00
00007b629adcf02b  lea r12, [rax+0x40]
00007b629adcf02f  movups xmm14, [r13+r12*1]
00007b629adcf035  lea r12, [rax+0x50]
00007b629adcf039  movups xmm13, [r13+r12*1]
00007b629adcf03f  lea r12, [r14+0x120]
00007b629adcf046  movq xmm12, qword ptr [r15+0x1C0]
00007b629adcf04f  movq xmm11, qword ptr [r15+0x1B0]
00007b629adcf058  movq r11, xmm12
00007b629adcf05d  movq r10, xmm11
00007b629adcf062  mov [r13+r12*1], r11
00007b629adcf067  lea r12, [r14+0x128]
00007b629adcf06e  mov [r13+r12*1], r10
00007b629adcf073  vxorps xmm12, xmm12, xmm12
00007b629adcf078  vpbroadcastq xmm12, xmm12
00007b629adcf07d  lea r12, [r14+0x100]
00007b629adcf084  movq xmm11, qword ptr [r15+0x200]
00007b629adcf08d  movq xmm10, qword ptr [r15+0x1F0]
00007b629adcf096  movq r11, xmm11
00007b629adcf09b  movq r10, xmm10
00007b629adcf0a0  mov [r13+r12*1], r11
00007b629adcf0a5  lea r12, [r14+0x108]
00007b629adcf0ac  mov [r13+r12*1], r10
00007b629adcf0b1  lea r12, [r14+0xE0]
00007b629adcf0b8  movups [r13+r12*1], xmm15
00007b629adcf0be  lea r12, [r14+0xF0]
00007b629adcf0c5  movups [r13+r12*1], xmm1
00007b629adcf0cb  lea r12, [rax+0xC0]
00007b629adcf0d2  movups xmm1, [r13+r12*1]
00007b629adcf0d8  lea r12, [rax+0xD0]
00007b629adcf0df  movups xmm15, [r13+r12*1]
00007b629adcf0e5  lea r12, [r14+0x110]
00007b629adcf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007b629adcf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007b629adcf0fe  movq r11, xmm11
00007b629adcf103  movq r10, xmm10
00007b629adcf108  mov [r13+r12*1], r11
00007b629adcf10d  lea r12, [r14+0x118]
00007b629adcf114  mov [r13+r12*1], r10
00007b629adcf119  movups xmm11, [r13+rax*1]
00007b629adcf11f  lea r12, [rax+0x10]
00007b629adcf123  movups xmm10, [r13+r12*1]
00007b629adcf129  lea r12, [r14+0x130]
00007b629adcf130  movq xmm9, qword ptr [r15+0x1A0]
00007b629adcf139  movq xmm8, qword ptr [r15+0x190]
00007b629adcf142  movq r11, xmm9
00007b629adcf147  movq r10, xmm8
00007b629adcf14c  mov [r13+r12*1], r11
00007b629adcf151  lea r12, [r14+0x138]
00007b629adcf158  mov [r13+r12*1], r10
00007b629adcf15d  lea r12, [rax+0x140]
00007b629adcf164  movups xmm9, [r13+r12*1]
00007b629adcf16a  lea r12, [rax+0x150]
00007b629adcf171  movups xmm8, [r13+r12*1]
00007b629adcf177  lea r12, [r14+0xC0]
00007b629adcf17e  movups [r13+r12*1], xmm15
00007b629adcf184  lea r12, [r14+0xD0]
00007b629adcf18b  movups [r13+r12*1], xmm1
00007b629adcf191  lea r12, [rax+0x100]
00007b629adcf198  movups xmm1, [r13+r12*1]
00007b629adcf19e  lea r12, [rax+0x110]
00007b629adcf1a5  movups xmm15, [r13+r12*1]
00007b629adcf1ab  lea r12, [r14+0x140]
00007b629adcf1b2  mov r11, [r15+0xE8]
00007b629adcf1b9  mov [r13+r12*1], r11
00007b629adcf1be  lea r12, [rax+0x180]
00007b629adcf1c5  movups xmm7, [r13+r12*1]
00007b629adcf1cb  lea r12, [rax+0x190]
00007b629adcf1d2  movups xmm6, [r13+r12*1]
00007b629adcf1d8  lea r12, [rax+0x1C0]
00007b629adcf1df  movups xmm5, [r13+r12*1]
00007b629adcf1e5  lea r12, [rax+0x1D0]
00007b629adcf1ec  movups xmm4, [r13+r12*1]
00007b629adcf1f2  lea r12, [r14+0x20]
00007b629adcf1f6  movups [r13+r12*1], xmm1
00007b629adcf1fc  lea r12, [r14+0x30]
00007b629adcf200  movups [r13+r12*1], xmm13
00007b629adcf206  lea r12, [rax+0x60]
00007b629adcf20a  movups xmm1, [r13+r12*1]
00007b629adcf210  lea r12, [rax+0x70]
00007b629adcf214  movups xmm13, [r13+r12*1]
00007b629adcf21a  lea r12, [rax+0x20]
00007b629adcf21e  movups xmm3, [r13+r12*1]
00007b629adcf224  lea r12, [rax+0x30]
00007b629adcf228  movups xmm2, [r13+r12*1]
00007b629adcf22e  movaps [r15+0x1F0], xmm2
00007b629adcf236  lea r12, [r14+0x60]
00007b629adcf23a  movups [r13+r12*1], xmm11
00007b629adcf240  lea r12, [r14+0x70]
00007b629adcf244  movups [r13+r12*1], xmm5
00007b629adcf24a  lea r12, [rax+0xE0]
00007b629adcf251  movups xmm11, [r13+r12*1]
00007b629adcf257  lea r12, [rax+0xF0]
00007b629adcf25e  movups xmm5, [r13+r12*1]
00007b629adcf264  lea r12, [r14+0xA0]
00007b629adcf26b  movups [r13+r12*1], xmm13
00007b629adcf271  lea r12, [r14+0xB0]
00007b629adcf278  movups [r13+r12*1], xmm1
00007b629adcf27e  lea r12, [rax+0xA0]
00007b629adcf285  movups xmm1, [r13+r12*1]
00007b629adcf28b  lea r12, [rax+0xB0]
00007b629adcf292  movups xmm13, [r13+r12*1]
00007b629adcf298  lea r12, [rax+0x120]
00007b629adcf29f  vmovaps [rsp+0x10], xmm1
00007b629adcf2a5  movups xmm1, [r13+r12*1]
00007b629adcf2ab  lea r12, [rax+0x130]
00007b629adcf2b2  vmovaps [rsp+0x20], xmm1
00007b629adcf2b8  movups xmm1, [r13+r12*1]
00007b629adcf2be  lea r12, [rax+0x160]
00007b629adcf2c5  vmovaps [rsp+0x30], xmm1
00007b629adcf2cb  movups xmm1, [r13+r12*1]
00007b629adcf2d1  lea r12, [rax+0x170]
00007b629adcf2d8  vmovaps [rsp+0x40], xmm1
00007b629adcf2de  movups xmm1, [r13+r12*1]
00007b629adcf2e4  movaps [r15+0x2B0], xmm1
00007b629adcf2ec  lea r12, [r14+0x80]
00007b629adcf2f3  movups [r13+r12*1], xmm13
00007b629adcf2f9  lea r12, [r14+0x90]
00007b629adcf300  vmovaps xmm13, [rsp+0x10]
00007b629adcf306  movups [r13+r12*1], xmm13
00007b629adcf30c  lea r12, [rax+0x1A0]
00007b629adcf313  movups xmm13, [r13+r12*1]
00007b629adcf319  lea r12, [rax+0x1B0]
00007b629adcf320  vmovaps [rsp+0x10], xmm1
00007b629adcf326  movups xmm1, [r13+r12*1]
00007b629adcf32c  movaps [r15+0x290], xmm13
00007b629adcf334  movaps [r15+0x1E0], xmm1
00007b629adcf33c  lea r12, [rax+0x1E0]
00007b629adcf343  vmovaps [rsp+0x50], xmm1
00007b629adcf349  movups xmm1, [r13+r12*1]
00007b629adcf34f  lea r12, [rax+0x1F0]
00007b629adcf356  vmovaps [rsp+0x60], xmm1
00007b629adcf35c  movups xmm1, [r13+r12*1]
00007b629adcf362  mov qword ptr [r15+0x50], 0x430920
00007b629adcf36a  lea rax, [r14+0x40]
00007b629adcf36e  vmovaps [rsp+0x70], xmm1
00007b629adcf374  vmovaps xmm1, [rsp+0x40]
00007b629adcf37a  movups [r13+rax*1], xmm1
00007b629adcf380  lea rax, [r14+0x50]
00007b629adcf384  movups [r13+rax*1], xmm10
00007b629adcf38a  vmovaps xmm1, [rsp+0x70]
00007b629adcf390  movups [r13+r14*1], xmm1
00007b629adcf396  lea rax, [r14+0x10]
00007b629adcf39a  vmovaps xmm1, [rsp+0x60]
00007b629adcf3a0  movups [r13+rax*1], xmm1
00007b629adcf3a6  mov rax, [r15+0x40]
00007b629adcf3aa  vmovaps [rsp+0x40], xmm3
00007b629adcf3b0  vmovaps xmm1, [rsp+0x40]
00007b629adcf3b6  por xmm3, xmm1
00007b629adcf3ba  vmovaps [rsp+0x40], xmm6
00007b629adcf3c0  vmovaps xmm10, [rsp+0x40]
00007b629adcf3c6  por xmm6, xmm10
00007b629adcf3cb  lea r12, [rax+0x30]
00007b629adcf3cf  mov r11, [r13+r12*1]
00007b629adcf3d4  lea r12, [rax+0x38]
00007b629adcf3d8  mov r10, [r13+r12*1]
00007b629adcf3dd  movq xmm10, r11
00007b629adcf3e2  vmovaps [rsp+0x40], xmm1
00007b629adcf3e8  movq xmm1, r10
00007b629adcf3ed  movq xmm10, xmm10
00007b629adcf3f2  vmovaps [rsp+0x60], xmm10
00007b629adcf3f8  movq xmm10, xmm10
00007b629adcf3fd  movaps [r15+0x130], xmm10
00007b629adcf405  movq xmm1, xmm1
00007b629adcf409  vmovaps [rsp+0x70], xmm1
00007b629adcf40f  movq xmm1, xmm1
00007b629adcf413  movaps [r15+0x280], xmm1
00007b629adcf41b  vmovaps [rsp+0x80], xmm9
00007b629adcf424  vmovaps xmm1, [rsp+0x80]
00007b629adcf42d  por xmm9, xmm1
00007b629adcf432  lea r12, [rax+0x20]
00007b629adcf436  mov r11, [r13+r12*1]
00007b629adcf43b  lea r12, [rax+0x28]
00007b629adcf43f  mov r10, [r13+r12*1]
00007b629adcf444  movq xmm1, r11
00007b629adcf449  movq xmm10, r10
00007b629adcf44e  movq xmm1, xmm1
00007b629adcf452  vmovaps [rsp+0x80], xmm1
00007b629adcf45b  movq xmm1, xmm1
00007b629adcf45f  movaps [r15+0x150], xmm1
00007b629adcf467  movq xmm10, xmm10
00007b629adcf46c  vmovaps [rsp+0x90], xmm10
00007b629adcf475  movq xmm10, xmm10
00007b629adcf47a  movaps [r15+0x140], xmm10
00007b629adcf482  lea r12, [rax+0x10]
00007b629adcf486  mov r11, [r13+r12*1]
00007b629adcf48b  lea r12, [rax+0x18]
00007b629adcf48f  mov r10, [r13+r12*1]
00007b629adcf494  movq xmm1, r11
00007b629adcf499  movq xmm10, r10
00007b629adcf49e  movq xmm1, xmm1
00007b629adcf4a2  vmovaps [rsp+0xA0], xmm1
00007b629adcf4ab  movq xmm1, xmm1
00007b629adcf4af  movaps [r15+0x170], xmm1
00007b629adcf4b7  movq xmm10, xmm10
00007b629adcf4bc  vmovaps [rsp+0xB0], xmm10
00007b629adcf4c5  movq xmm10, xmm10
00007b629adcf4ca  movaps [r15+0x160], xmm10
00007b629adcf4d2  mov r12, [r13+rax*1]
00007b629adcf4d7  vmovq xmm1, r12
00007b629adcf4dc  vpbroadcastq xmm1, xmm1
00007b629adcf4e1  lea r12, [rax+0x08]
00007b629adcf4e5  mov rax, [r13+r12*1]
00007b629adcf4ea  movq xmm10, rax
00007b629adcf4ef  movaps [r15+0x230], xmm10
00007b629adcf4f7  lea rax, [r14+0x50]
00007b629adcf4fb  movups xmm10, [r13+rax*1]
00007b629adcf501  lea rax, [r14+0x60]
00007b629adcf505  vmovaps [rsp+0xC0], xmm1
00007b629adcf50e  movups xmm1, [r13+rax*1]
00007b629adcf514  lea rax, [r14+0x30]
00007b629adcf518  vmovaps [rsp+0xD0], xmm1
00007b629adcf521  movups xmm1, [r13+rax*1]
00007b629adcf527  mov qword ptr [r15+0x60], 0x430920
00007b629adcf52f  mov qword ptr [r15+0x58], 0x40
00007b629adcf537  vmovaps [rsp+0xE0], xmm1
00007b629adcf540  vmovaps [rsp+0xF0], xmm15
00007b629adcf549  vmovaps xmm15, [rsp+0xC0]
00007b629adcf552  vmovaps [rsp+0xC0], xmm14
00007b629adcf55b  vmovaps xmm14, [rsp+0x40]
00007b629adcf561  vmovaps [rsp+0x40], xmm13
00007b629adcf567  movaps xmm1, xmm15
00007b629adcf56b  mulpd xmm1, xmm14
00007b629adcf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007b629adcf575  ptest xmm13, xmm13
00007b629adcf57b  jnz 0x00007B629ADD0682
00007b629adcf581  movq xmm14, qword ptr [r15+0x230]
00007b629adcf58a  vmovaps [rsp+0x100], xmm14
00007b629adcf593  vpermilpd xmm14, xmm14, 0x00
00007b629adcf599  vmovaps [rsp+0x110], xmm1
00007b629adcf5a2  vmovaps xmm1, [rsp+0xE0]
00007b629adcf5ab  vmovaps [rsp+0xE0], xmm15
00007b629adcf5b4  movaps xmm13, xmm1
00007b629adcf5b8  mulpd xmm13, xmm14
00007b629adcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007b629adcf5c3  ptest xmm15, xmm15
00007b629adcf5c9  jnz 0x00007B629ADD07C4
00007b629adcf5cf  vxorps xmm1, xmm1, xmm1
00007b629adcf5d3  vpbroadcastq xmm1, xmm1
00007b629adcf5d8  vmovaps xmm14, [rsp+0xE0]
00007b629adcf5e1  vmovaps [rsp+0xE0], xmm1
00007b629adcf5ea  vmovaps xmm1, [rsp+0xD0]
00007b629adcf5f3  vmovaps [rsp+0xD0], xmm13
00007b629adcf5fc  movaps xmm15, xmm14
00007b629adcf600  mulpd xmm15, xmm1
00007b629adcf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007b629adcf60b  ptest xmm13, xmm13
00007b629adcf611  jnz 0x00007B629ADD0907
00007b629adcf617  movaps xmm1, xmm14
00007b629adcf61b  mulpd xmm1, xmm10
00007b629adcf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007b629adcf625  ptest xmm13, xmm13
00007b629adcf62b  jnz 0x00007B629ADD0A4A
00007b629adcf631  movaps xmm13, xmm14
00007b629adcf635  mulpd xmm13, xmm2
00007b629adcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007b629adcf640  ptest xmm10, xmm10
00007b629adcf646  jnz 0x00007B629ADD0B8C
00007b629adcf64c  vmovaps [rsp+0x120], xmm7
00007b629adcf655  vmovaps xmm14, [rsp+0x120]
00007b629adcf65e  por xmm7, xmm14
00007b629adcf663  vmovaps xmm14, [rsp+0xC0]
00007b629adcf66c  vmovaps xmm10, [rsp+0xC0]
00007b629adcf675  por xmm14, xmm10
00007b629adcf67a  vmovaps xmm2, [rsp+0x100]
00007b629adcf683  vpermilpd xmm2, xmm2, 0x00
00007b629adcf689  vmovaps [rsp+0xC0], xmm1
00007b629adcf692  vmovaps [rsp+0x120], xmm15
00007b629adcf69b  movaps xmm1, xmm10
00007b629adcf69f  mulpd xmm1, xmm2
00007b629adcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007b629adcf6a8  ptest xmm15, xmm15
00007b629adcf6ae  jnz 0x00007B629ADD0CCF
00007b629adcf6b4  xor eax, eax
00007b629adcf6b6  mov r12d, 0x40
00007b629adcf6bc  mov r11d, 0x200
00007b629adcf6c2  cmp r12, r11
00007b629adcf6c5  cmc
00007b629adcf6c6  lahf
00007b629adcf6c7  seto al
00007b629adcf6ca  mov [r15+0x108], eax
00007b629adcf6d1  vmovaps xmm10, [rsp+0x110]
00007b629adcf6da  vmovaps xmm2, [rsp+0xE0]
00007b629adcf6e3  vmovaps [rsp+0xE0], xmm1
00007b629adcf6ec  movaps xmm15, xmm10
00007b629adcf6f0  addpd xmm15, xmm2
00007b629adcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007b629adcf6fb  ptest xmm1, xmm1
00007b629adcf700  jnz 0x00007B629ADD0E10
00007b629adcf706  vmovaps xmm10, [rsp+0x120]
00007b629adcf70f  vmovaps [rsp+0x110], xmm15
00007b629adcf718  movaps xmm1, xmm10
00007b629adcf71c  addpd xmm1, xmm12
00007b629adcf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007b629adcf726  ptest xmm15, xmm15
00007b629adcf72c  jnz 0x00007B629ADD0F53
00007b629adcf732  vmovaps xmm10, [rsp+0xC0]
00007b629adcf73b  vmovaps [rsp+0xC0], xmm1
00007b629adcf744  movaps xmm15, xmm10
00007b629adcf748  addpd xmm15, xmm12
00007b629adcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007b629adcf753  ptest xmm1, xmm1
00007b629adcf758  jnz 0x00007B629ADD1095
00007b629adcf75e  vmovaps xmm1, [rsp+0x30]
00007b629adcf764  vmovaps xmm12, [rsp+0x30]
00007b629adcf76a  por xmm1, xmm12
00007b629adcf76f  vmovaps xmm12, [rsp+0x20]
00007b629adcf775  vmovaps xmm10, [rsp+0x20]
00007b629adcf77b  por xmm12, xmm10
00007b629adcf780  vmovaps [rsp+0x20], xmm5
00007b629adcf786  vmovaps xmm10, [rsp+0x20]
00007b629adcf78c  por xmm5, xmm10
00007b629adcf791  vmovaps [rsp+0x20], xmm11
00007b629adcf797  vmovaps xmm10, [rsp+0x20]
00007b629adcf79d  por xmm11, xmm10
00007b629adcf7a2  vmovaps [rsp+0x20], xmm4
00007b629adcf7a8  vmovaps xmm10, [rsp+0x20]
00007b629adcf7ae  por xmm4, xmm10
00007b629adcf7b3  vmovaps [rsp+0x20], xmm8
00007b629adcf7b9  vmovaps xmm10, [rsp+0x20]
00007b629adcf7bf  por xmm8, xmm10
00007b629adcf7c4  vmovaps xmm10, [rsp+0xF0]
00007b629adcf7cd  vmovaps [rsp+0x20], xmm1
00007b629adcf7d3  vmovaps xmm1, [rsp+0xF0]
00007b629adcf7dc  por xmm10, xmm1
00007b629adcf7e1  lea rax, [r14+0xA0]
00007b629adcf7e8  movups xmm1, [r13+rax*1]
00007b629adcf7ee  lea rax, [r14+0xB0]
00007b629adcf7f5  vmovaps [rsp+0x30], xmm1
00007b629adcf7fb  movups xmm1, [r13+rax*1]
00007b629adcf801  vmovaps [rsp+0xF0], xmm1
00007b629adcf80a  vmovaps [rsp+0x120], xmm15
00007b629adcf813  movaps xmm1, xmm13
00007b629adcf817  addpd xmm1, xmm2
00007b629adcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007b629adcf820  ptest xmm15, xmm15
00007b629adcf826  jnz 0x00007B629ADD11ED
00007b629adcf82c  lea rax, [r14+0xF0]
00007b629adcf833  movups xmm15, [r13+rax*1]
00007b629adcf839  vmovaps xmm2, [rsp+0xC0]
00007b629adcf842  vmovaps [rsp+0xC0], xmm1
00007b629adcf84b  vmovaps xmm1, [rsp+0xE0]
00007b629adcf854  vmovaps [rsp+0xE0], xmm15
00007b629adcf85d  movaps xmm13, xmm2
00007b629adcf861  addpd xmm13, xmm1
00007b629adcf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007b629adcf86c  ptest xmm15, xmm15
00007b629adcf872  jnz 0x00007B629ADD1338
00007b629adcf878  vmovaps xmm15, [rsp+0x120]
00007b629adcf881  vmovaps xmm2, [rsp+0xD0]
00007b629adcf88a  vmovaps [rsp+0xD0], xmm14
00007b629adcf893  movaps xmm1, xmm15
00007b629adcf897  addpd xmm1, xmm2
00007b629adcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007b629adcf8a0  ptest xmm14, xmm14
00007b629adcf8a6  jnz 0x00007B629ADD147A
00007b629adcf8ac  vmovaps xmm15, [rsp+0x100]
00007b629adcf8b5  vpermilpd xmm15, xmm15, 0x00
00007b629adcf8bb  vmovaps xmm2, [rsp+0xF0]
00007b629adcf8c4  vmovaps [rsp+0xF0], xmm1
00007b629adcf8cd  movaps xmm14, xmm2
00007b629adcf8d1  mulpd xmm14, xmm15
00007b629adcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007b629adcf8dc  ptest xmm1, xmm1
00007b629adcf8e1  jnz 0x00007B629ADD15BB
00007b629adcf8e7  vmovaps xmm1, [rsp+0xA0]
00007b629adcf8f0  vpermilpd xmm1, xmm1, 0x00
00007b629adcf8f6  vmovaps xmm2, [rsp+0xE0]
00007b629adcf8ff  vmovaps [rsp+0xE0], xmm14
00007b629adcf908  movaps xmm15, xmm2
00007b629adcf90c  mulpd xmm15, xmm1
00007b629adcf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007b629adcf917  ptest xmm14, xmm14
00007b629adcf91d  jnz 0x00007B629ADD16FE
00007b629adcf923  lea rax, [r14+0xE0]
00007b629adcf92a  movups xmm1, [r13+rax*1]
00007b629adcf930  vmovaps xmm14, [rsp+0x100]
00007b629adcf939  vpermilpd xmm14, xmm14, 0x00
00007b629adcf93f  vmovaps [rsp+0x100], xmm1
00007b629adcf948  vmovaps xmm1, [rsp+0x30]
00007b629adcf94e  vmovaps [rsp+0x30], xmm15
00007b629adcf954  movaps xmm2, xmm1
00007b629adcf957  mulpd xmm2, xmm14
00007b629adcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007b629adcf961  ptest xmm15, xmm15
00007b629adcf967  jnz 0x00007B629ADD184A
00007b629adcf96d  vmovaps [rsp+0x120], xmm10
00007b629adcf976  vmovaps xmm1, [rsp+0x120]
00007b629adcf97f  por xmm10, xmm1
00007b629adcf984  movaps [r15+0x300], xmm10
00007b629adcf98c  vmovaps [rsp+0x120], xmm8
00007b629adcf995  vmovaps xmm1, [rsp+0x120]
00007b629adcf99e  por xmm8, xmm1
00007b629adcf9a3  movaps [r15+0x190], xmm8
00007b629adcf9ab  vmovaps xmm1, [rsp+0xA0]
00007b629adcf9b4  vpermilpd xmm1, xmm1, 0x00
00007b629adcf9ba  vmovaps xmm14, [rsp+0x100]
00007b629adcf9c3  vmovaps [rsp+0x100], xmm13
00007b629adcf9cc  movaps xmm15, xmm14
00007b629adcf9d0  mulpd xmm15, xmm1
00007b629adcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007b629adcf9db  ptest xmm13, xmm13
00007b629adcf9e1  jnz 0x00007B629ADD198B
00007b629adcf9e7  lea rax, [r14+0x90]
00007b629adcf9ee  movups xmm1, [r13+rax*1]
00007b629adcf9f4  vmovaps [rsp+0x120], xmm4
00007b629adcf9fd  vmovaps xmm14, [rsp+0x120]
00007b629adcfa06  por xmm4, xmm14
00007b629adcfa0b  movaps [r15+0x1C0], xmm4
00007b629adcfa13  vmovaps [rsp+0x120], xmm11
00007b629adcfa1c  vmovaps xmm14, [rsp+0x120]
00007b629adcfa25  por xmm11, xmm14
00007b629adcfa2a  movaps [r15+0x200], xmm11
00007b629adcfa32  vmovaps [rsp+0x120], xmm5
00007b629adcfa3b  vmovaps xmm14, [rsp+0x120]
00007b629adcfa44  por xmm5, xmm14
00007b629adcfa49  movaps [r15+0x2D0], xmm5
00007b629adcfa51  vmovaps [rsp+0x120], xmm12
00007b629adcfa5a  vmovaps xmm14, [rsp+0x120]
00007b629adcfa63  por xmm12, xmm14
00007b629adcfa68  movaps [r15+0x2E0], xmm12
00007b629adcfa70  vmovaps xmm13, [rsp+0x110]
00007b629adcfa79  vmovaps [rsp+0x110], xmm1
00007b629adcfa82  vmovaps xmm1, [rsp+0xE0]
00007b629adcfa8b  vmovaps [rsp+0xE0], xmm15
00007b629adcfa94  movaps xmm14, xmm13
00007b629adcfa98  addpd xmm14, xmm1
00007b629adcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007b629adcfaa3  ptest xmm15, xmm15
00007b629adcfaa9  jnz 0x00007B629ADD1AD8
00007b629adcfaaf  vmovaps xmm1, [rsp+0xA0]
00007b629adcfab8  vpermilpd xmm1, xmm1, 0x00
00007b629adcfabe  vmovaps xmm13, [rsp+0x110]
00007b629adcfac7  vmovaps [rsp+0x110], xmm14
00007b629adcfad0  movaps xmm15, xmm13
00007b629adcfad4  mulpd xmm15, xmm1
00007b629adcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007b629adcfadf  ptest xmm14, xmm14
00007b629adcfae5  jnz 0x00007B629ADD1C1B
00007b629adcfaeb  lea rax, [r14+0x80]
00007b629adcfaf2  movups xmm1, [r13+rax*1]
00007b629adcfaf8  vmovaps xmm13, [rsp+0xC0]
00007b629adcfb01  vmovaps [rsp+0xC0], xmm1
00007b629adcfb0a  movaps xmm14, xmm13
00007b629adcfb0e  addpd xmm14, xmm2
00007b629adcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007b629adcfb19  ptest xmm1, xmm1
00007b629adcfb1e  jnz 0x00007B629ADD1D68
00007b629adcfb24  vmovaps xmm13, [rsp+0x100]
00007b629adcfb2d  vmovaps xmm2, [rsp+0x30]
00007b629adcfb33  vmovaps [rsp+0x30], xmm15
00007b629adcfb39  movaps xmm1, xmm13
00007b629adcfb3d  addpd xmm1, xmm2
00007b629adcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007b629adcfb46  ptest xmm15, xmm15
00007b629adcfb4c  jnz 0x00007B629ADD1EAB
00007b629adcfb52  vmovaps xmm15, [rsp+0x20]
00007b629adcfb58  vmovaps xmm13, [rsp+0x20]
00007b629adcfb5e  por xmm15, xmm13
00007b629adcfb63  movaps [r15+0x2F0], xmm15
00007b629adcfb6b  vmovaps xmm13, [rsp+0xA0]
00007b629adcfb74  vpermilpd xmm13, xmm13, 0x00
00007b629adcfb7a  vmovaps [rsp+0x20], xmm1
00007b629adcfb80  vmovaps xmm1, [rsp+0xC0]
00007b629adcfb89  vmovaps [rsp+0xA0], xmm15
00007b629adcfb92  movaps xmm2, xmm1
00007b629adcfb95  mulpd xmm2, xmm13
00007b629adcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007b629adcfb9f  ptest xmm15, xmm15
00007b629adcfba5  jnz 0x00007B629ADD1FEC
00007b629adcfbab  lea rax, [r14+0xD0]
00007b629adcfbb2  movups xmm1, [r13+rax*1]
00007b629adcfbb8  vmovaps xmm13, [rsp+0xF0]
00007b629adcfbc1  vmovaps [rsp+0xC0], xmm1
00007b629adcfbca  vmovaps xmm1, [rsp+0xE0]
00007b629adcfbd3  vmovaps [rsp+0xE0], xmm14
00007b629adcfbdc  movaps xmm15, xmm13
00007b629adcfbe0  addpd xmm15, xmm1
00007b629adcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007b629adcfbeb  ptest xmm14, xmm14
00007b629adcfbf1  jnz 0x00007B629ADD2137
00007b629adcfbf7  vmovaps xmm1, [rsp+0xB0]
00007b629adcfc00  vpermilpd xmm1, xmm1, 0x00
00007b629adcfc06  movaps xmm14, xmm11
00007b629adcfc0a  mulpd xmm14, xmm1
00007b629adcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007b629adcfc15  ptest xmm13, xmm13
00007b629adcfc1b  jnz 0x00007B629ADD227A
00007b629adcfc21  movaps [r15+0x260], xmm14
00007b629adcfc29  vxorps xmm1, xmm1, xmm1
00007b629adcfc2d  vpbroadcastq xmm1, xmm1
00007b629adcfc32  movaps [r15+0x1B0], xmm1
00007b629adcfc3a  vmovaps xmm1, [rsp+0xB0]
00007b629adcfc43  vpermilpd xmm1, xmm1, 0x00
00007b629adcfc49  vmovaps xmm11, [rsp+0xC0]
00007b629adcfc52  vmovaps [rsp+0xC0], xmm15
00007b629adcfc5b  movaps xmm13, xmm11
00007b629adcfc5f  mulpd xmm13, xmm1
00007b629adcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007b629adcfc6a  ptest xmm15, xmm15
00007b629adcfc70  jnz 0x00007B629ADD23BD
00007b629adcfc76  lea rax, [r14+0xC0]
00007b629adcfc7d  movups xmm1, [r13+rax*1]
00007b629adcfc83  vmovaps xmm11, [rsp+0x110]
00007b629adcfc8c  vmovaps [rsp+0xF0], xmm1
00007b629adcfc95  vmovaps xmm1, [rsp+0x30]
00007b629adcfc9b  vmovaps [rsp+0x30], xmm14
00007b629adcfca1  movaps xmm15, xmm11
00007b629adcfca5  addpd xmm15, xmm1
00007b629adcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007b629adcfcb0  ptest xmm14, xmm14
00007b629adcfcb6  jnz 0x00007B629ADD250A
00007b629adcfcbc  vmovaps [rsp+0x100], xmm9
00007b629adcfcc5  vmovaps xmm1, [rsp+0x100]
00007b629adcfcce  por xmm9, xmm1
00007b629adcfcd3  movaps [r15+0x270], xmm9
00007b629adcfcdb  vmovaps [rsp+0x100], xmm6
00007b629adcfce4  vmovaps xmm1, [rsp+0x100]
00007b629adcfced  por xmm6, xmm1
00007b629adcfcf1  movaps [r15+0x1A0], xmm6
00007b629adcfcf9  vmovaps xmm14, [rsp+0xB0]
00007b629adcfd02  vpermilpd xmm14, xmm14, 0x00
00007b629adcfd08  vmovaps xmm6, [rsp+0xF0]
00007b629adcfd11  vmovaps [rsp+0xF0], xmm1
00007b629adcfd1a  movaps xmm11, xmm6
00007b629adcfd1e  mulpd xmm11, xmm14
00007b629adcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007b629adcfd29  ptest xmm1, xmm1
00007b629adcfd2e  jnz 0x00007B629ADD264D
00007b629adcfd34  lea rax, [r14+0x20]
00007b629adcfd38  movups xmm1, [r13+rax*1]
00007b629adcfd3e  movaps [r15+0x110], xmm1
00007b629adcfd46  vmovaps xmm6, [rsp+0xE0]
00007b629adcfd4f  vmovaps [rsp+0xE0], xmm1
00007b629adcfd58  movaps xmm14, xmm6
00007b629adcfd5c  addpd xmm14, xmm2
00007b629adcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007b629adcfd67  ptest xmm1, xmm1
00007b629adcfd6c  jnz 0x00007B629ADD279A
00007b629adcfd72  vmovaps xmm1, [rsp+0xB0]
00007b629adcfd7b  vpermilpd xmm1, xmm1, 0x00
00007b629adcfd81  movaps xmm6, xmm5
00007b629adcfd84  mulpd xmm6, xmm1
00007b629adcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007b629adcfd8d  ptest xmm2, xmm2
00007b629adcfd92  jnz 0x00007B629ADD28DC
00007b629adcfd98  vmovaps xmm5, [rsp+0x20]
00007b629adcfd9e  movaps xmm1, xmm5
00007b629adcfda1  addpd xmm1, xmm13
00007b629adcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007b629adcfdab  ptest xmm2, xmm2
00007b629adcfdb0  jnz 0x00007B629ADD2A1C
00007b629adcfdb6  vmovaps xmm13, [rsp+0x80]
00007b629adcfdbf  vpermilpd xmm13, xmm13, 0x00
00007b629adcfdc5  vmovaps xmm2, [rsp+0xE0]
00007b629adcfdce  vmovaps [rsp+0x20], xmm1
00007b629adcfdd4  movaps xmm5, xmm2
00007b629adcfdd7  mulpd xmm5, xmm13
00007b629adcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007b629adcfde1  ptest xmm1, xmm1
00007b629adcfde6  jnz 0x00007B629ADD2B5D
00007b629adcfdec  vmovaps xmm1, [rsp+0x80]
00007b629adcfdf5  vpermilpd xmm1, xmm1, 0x00
00007b629adcfdfb  movaps xmm13, xmm10
00007b629adcfdff  mulpd xmm13, xmm1
00007b629adcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007b629adcfe0a  ptest xmm2, xmm2
00007b629adcfe0f  jnz 0x00007B629ADD2C9E
00007b629adcfe15  vmovaps xmm10, [rsp+0x30]
00007b629adcfe1b  movaps xmm1, xmm15
00007b629adcfe1f  addpd xmm1, xmm10
00007b629adcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007b629adcfe29  ptest xmm2, xmm2
00007b629adcfe2e  jnz 0x00007B629ADD2DE1
00007b629adcfe34  vmovaps xmm10, [rsp+0xC0]
00007b629adcfe3d  movaps xmm15, xmm10
00007b629adcfe41  addpd xmm15, xmm11
00007b629adcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007b629adcfe4c  ptest xmm2, xmm2
00007b629adcfe51  jnz 0x00007B629ADD2F23
00007b629adcfe57  vmovaps xmm11, [rsp+0x80]
00007b629adcfe60  vpermilpd xmm11, xmm11, 0x00
00007b629adcfe66  movaps xmm10, xmm12
00007b629adcfe6a  mulpd xmm10, xmm11
00007b629adcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007b629adcfe75  ptest xmm2, xmm2
00007b629adcfe7a  jnz 0x00007B629ADD3067
00007b629adcfe80  vmovaps xmm12, [rsp+0x80]
00007b629adcfe89  vpermilpd xmm12, xmm12, 0x00
00007b629adcfe8f  vmovaps xmm2, [rsp+0xA0]
00007b629adcfe98  vmovaps [rsp+0x30], xmm1
00007b629adcfe9e  movaps xmm11, xmm2
00007b629adcfea2  mulpd xmm11, xmm12
00007b629adcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007b629adcfead  ptest xmm1, xmm1
00007b629adcfeb2  jnz 0x00007B629ADD31AB
00007b629adcfeb8  movaps xmm1, xmm14
00007b629adcfebc  addpd xmm1, xmm6
00007b629adcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007b629adcfec5  ptest xmm12, xmm12
00007b629adcfecb  jnz 0x00007B629ADD32EE
00007b629adcfed1  vmovaps xmm12, [rsp+0x20]
00007b629adcfed7  movaps xmm14, xmm12
00007b629adcfedb  addpd xmm14, xmm5
00007b629adcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007b629adcfee6  ptest xmm6, xmm6
00007b629adcfeeb  jnz 0x00007B629ADD342F
00007b629adcfef1  vmovaps xmm12, [rsp+0x90]
00007b629adcfefa  vpermilpd xmm12, xmm12, 0x00
00007b629adcff00  movaps xmm6, xmm9
00007b629adcff04  mulpd xmm6, xmm12
00007b629adcff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007b629adcff0e  ptest xmm5, xmm5
00007b629adcff13  jnz 0x00007B629ADD3572
00007b629adcff19  movaps xmm12, xmm15
00007b629adcff1d  addpd xmm12, xmm13
00007b629adcff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007b629adcff28  ptest xmm9, xmm9
00007b629adcff2e  jnz 0x00007B629ADD36B4
00007b629adcff34  vmovaps xmm13, [rsp+0x30]
00007b629adcff3a  movaps xmm15, xmm13
00007b629adcff3e  addpd xmm15, xmm10
00007b629adcff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007b629adcff49  ptest xmm9, xmm9
00007b629adcff4f  jnz 0x00007B629ADD37F8
00007b629adcff55  vmovaps xmm13, [rsp+0xD0]
00007b629adcff5e  vmovaps xmm10, [rsp+0xD0]
00007b629adcff67  por xmm13, xmm10
00007b629adcff6c  movaps [r15+0x250], xmm13
00007b629adcff74  vmovaps [rsp+0x20], xmm7
00007b629adcff7a  vmovaps xmm13, [rsp+0x20]
00007b629adcff80  por xmm7, xmm13
00007b629adcff85  movaps [r15+0x2A0], xmm7
00007b629adcff8d  vmovaps [rsp+0x20], xmm3
00007b629adcff93  vmovaps xmm13, [rsp+0x20]
00007b629adcff99  por xmm3, xmm13
00007b629adcff9e  movaps [r15+0x1D0], xmm3
00007b629adcffa6  lea rax, [r14+0x40]
00007b629adcffaa  movups xmm13, [r13+rax*1]
00007b629adcffb0  movaps [r15+0x2C0], xmm13
00007b629adcffb8  vmovaps xmm10, [rsp+0x90]
00007b629adcffc1  vpermilpd xmm10, xmm10, 0x00
00007b629adcffc7  movaps xmm9, xmm8
00007b629adcffcb  mulpd xmm9, xmm10
00007b629adcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007b629adcffd6  ptest xmm5, xmm5
00007b629adcffdb  jnz 0x00007B629ADD3946
00007b629adcffe1  movaps xmm10, xmm1
00007b629adcffe5  addpd xmm10, xmm11
00007b629adcffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007b629adcfff0  ptest xmm8, xmm8
00007b629adcfff6  jnz 0x00007B629ADD3A8A
00007b629adcfffc  movaps xmm1, xmm14
00007b629add0000  addpd xmm1, xmm6
00007b629add0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007b629add0009  ptest xmm11, xmm11
00007b629add000f  jnz 0x00007B629ADD3BCD
00007b629add0015  vmovaps xmm14, [rsp+0x90]
00007b629add001e  vpermilpd xmm14, xmm14, 0x00
00007b629add0024  movaps xmm11, xmm13
00007b629add0028  mulpd xmm11, xmm14
00007b629add002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007b629add0033  ptest xmm8, xmm8
00007b629add0039  jnz 0x00007B629ADD3D0E
00007b629add003f  vmovaps xmm14, [rsp+0x90]
00007b629add0048  vpermilpd xmm14, xmm14, 0x00
00007b629add004e  vmovaps xmm8, [rsp+0x10]
00007b629add0054  movaps xmm13, xmm8
00007b629add0058  mulpd xmm13, xmm14
00007b629add005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007b629add0063  ptest xmm6, xmm6
00007b629add0068  jnz 0x00007B629ADD3E52
00007b629add006e  vmovaps xmm14, [rsp+0x60]
00007b629add0074  vpermilpd xmm14, xmm14, 0x00
00007b629add007a  movaps xmm8, xmm7
00007b629add007e  mulpd xmm8, xmm14
00007b629add0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007b629add0089  ptest xmm6, xmm6
00007b629add008e  jnz 0x00007B629ADD3F96
00007b629add0094  movaps xmm14, xmm12
00007b629add0098  addpd xmm14, xmm9
00007b629add009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007b629add00a3  ptest xmm7, xmm7
00007b629add00a8  jnz 0x00007B629ADD40D9
00007b629add00ae  vmovaps xmm12, [rsp+0x60]
00007b629add00b4  vpermilpd xmm12, xmm12, 0x00
00007b629add00ba  vmovaps xmm7, [rsp+0xF0]
00007b629add00c3  movaps xmm9, xmm7
00007b629add00c7  mulpd xmm9, xmm12
00007b629add00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007b629add00d2  ptest xmm6, xmm6
00007b629add00d7  jnz 0x00007B629ADD421D
00007b629add00dd  movaps xmm12, xmm15
00007b629add00e1  addpd xmm12, xmm11
00007b629add00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007b629add00ec  ptest xmm7, xmm7
00007b629add00f1  jnz 0x00007B629ADD4360
00007b629add00f7  vmovaps xmm15, [rsp+0x60]
00007b629add00fd  vpermilpd xmm15, xmm15, 0x00
00007b629add0103  vmovaps xmm7, [rsp+0x40]
00007b629add0109  movaps xmm11, xmm7
00007b629add010d  mulpd xmm11, xmm15
00007b629add0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007b629add0118  ptest xmm6, xmm6
00007b629add011d  jnz 0x00007B629ADD44A4
00007b629add0123  movaps xmm15, xmm10
00007b629add0127  addpd xmm15, xmm13
00007b629add012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007b629add0132  ptest xmm7, xmm7
00007b629add0137  jnz 0x00007B629ADD45E7
00007b629add013d  vmovaps xmm13, [rsp+0x60]
00007b629add0143  vpermilpd xmm13, xmm13, 0x00
00007b629add0149  vmovaps xmm7, [rsp+0x50]
00007b629add014f  movaps xmm10, xmm7
00007b629add0153  mulpd xmm10, xmm13
00007b629add0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007b629add015e  ptest xmm6, xmm6
00007b629add0163  jnz 0x00007B629ADD472B
00007b629add0169  movaps xmm13, xmm1
00007b629add016d  addpd xmm13, xmm8
00007b629add0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007b629add0178  ptest xmm7, xmm7
00007b629add017d  jnz 0x00007B629ADD486E
00007b629add0183  lea rax, [r14+0x70]
00007b629add0187  movups xmm1, [r13+rax*1]
00007b629add018d  movaps [r15+0x240], xmm1
00007b629add0195  movaps xmm8, xmm14
00007b629add0199  addpd xmm8, xmm9
00007b629add019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007b629add01a4  ptest xmm7, xmm7
00007b629add01a9  jnz 0x00007B629ADD49BB
00007b629add01af  movaps [r15+0x170], xmm8
00007b629add01b7  vmovaps xmm14, [rsp+0x70]
00007b629add01bd  vpermilpd xmm14, xmm14, 0x00
00007b629add01c3  movaps xmm9, xmm1
00007b629add01c7  mulpd xmm9, xmm14
00007b629add01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007b629add01d2  ptest xmm7, xmm7
00007b629add01d7  jnz 0x00007B629ADD4AFF
00007b629add01dd  vmovaps xmm1, [rsp+0x70]
00007b629add01e3  vpermilpd xmm1, xmm1, 0x00
00007b629add01e9  movaps xmm14, xmm4
00007b629add01ed  mulpd xmm14, xmm1
00007b629add01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007b629add01f8  ptest xmm7, xmm7
00007b629add01fd  jnz 0x00007B629ADD4C42
00007b629add0203  movaps [r15+0x180], xmm14
00007b629add020b  movaps xmm1, xmm12
00007b629add020f  addpd xmm1, xmm11
00007b629add0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007b629add0219  ptest xmm7, xmm7
00007b629add021e  jnz 0x00007B629ADD4D84
00007b629add0224  movaps [r15+0x210], xmm1
00007b629add022c  movups xmm12, [r13+r14*1]
00007b629add0232  lea rax, [r14+0x10]
00007b629add0236  movups xmm11, [r13+rax*1]
00007b629add023c  movaps [r15+0x230], xmm11
00007b629add0244  movaps xmm7, xmm15
00007b629add0248  addpd xmm7, xmm10
00007b629add024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007b629add0252  ptest xmm6, xmm6
00007b629add0257  jnz 0x00007B629ADD4EDA
00007b629add025d  movaps [r15+0x130], xmm7
00007b629add0265  vmovaps xmm15, [rsp+0x70]
00007b629add026b  vpermilpd xmm15, xmm15, 0x00
00007b629add0271  movaps xmm10, xmm11
00007b629add0275  mulpd xmm10, xmm15
00007b629add027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007b629add0280  ptest xmm6, xmm6
00007b629add0285  jnz 0x00007B629ADD501C
00007b629add028b  movaps [r15+0x220], xmm10
00007b629add0293  vmovaps xmm15, [rsp+0x70]
00007b629add0299  vpermilpd xmm15, xmm15, 0x00
00007b629add029f  movaps xmm11, xmm12
00007b629add02a3  mulpd xmm11, xmm15
00007b629add02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007b629add02ae  ptest xmm6, xmm6
00007b629add02b3  jnz 0x00007B629ADD5160
00007b629add02b9  movaps xmm15, xmm13
00007b629add02bd  addpd xmm15, xmm9
00007b629add02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007b629add02c8  ptest xmm12, xmm12
00007b629add02ce  jnz 0x00007B629ADD52A4
00007b629add02d4  movaps [r15+0x140], xmm15
00007b629add02dc  movaps xmm13, xmm8
00007b629add02e0  addpd xmm13, xmm14
00007b629add02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007b629add02eb  ptest xmm12, xmm12
00007b629add02f1  jnz 0x00007B629ADD53E8
00007b629add02f7  movaps [r15+0x150], xmm13
00007b629add02ff  movaps xmm14, xmm1
00007b629add0303  addpd xmm14, xmm10
00007b629add0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007b629add030e  ptest xmm12, xmm12
00007b629add0314  jnz 0x00007B629ADD552C
00007b629add031a  movaps [r15+0x160], xmm14
00007b629add0322  movaps xmm1, xmm7
00007b629add0325  addpd xmm1, xmm11
00007b629add032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007b629add032f  ptest xmm12, xmm12
00007b629add0335  jnz 0x00007B629ADD566F
00007b629add033b  movaps [r15+0x120], xmm1
00007b629add0343  mov eax, 0x430920
00007b629add0348  movups [r13+rax*1], xmm15
00007b629add034e  mov eax, 0x430930
00007b629add0353  movups [r13+rax*1], xmm13
00007b629add0359  mov eax, 0x430940
00007b629add035e  movups [r13+rax*1], xmm14
00007b629add0364  mov eax, 0x430950
00007b629add0369  movups [r13+rax*1], xmm1
00007b629add036f  mov eax, [r15+0x108]
00007b629add0376  sahf
00007b629add0377  jnz 0x00007B629ADD03A9
00007b629add0379  cmp dword ptr [r15+0x318], 0x00
00007b629add0381  jz 0x00007B629ADDB900
00007b629add0387  nop [rax+rax*1], ax
00007b629add0390  nop [rax+rax*1], eax
00007b629add0398  mov eax, 0x410444
00007b629add039d  mov [r15+0x100], rax
00007b629add03a4  jmp 0x00007B629ABFE110
00007b629add03a9  cmp dword ptr [r15+0x318], 0x00
00007b629add03b1  jz 0x00007B629ADD57E0
00007b629add03b7  nop [rax+rax*1], ax
00007b629add03c0  nop [rax+rax*1], eax
00007b629add03c8  mov eax, 0x410278
00007b629add03cd  mov [r15+0x100], rax
00007b629add03d4  jmp 0x00007B629ABFE110
00007b629add03d9  int3
00007b629add03da  call 0x00007B629ACB52F0
00007b629add03df  jmp 0x00007B629ADCF016
00007b629add03e4  call 0x00007B629ACC4620
00007b629add03e9  jmp 0x00007B629ADCF023
00007b629add03ee  call 0x00007B629ACC33A0
00007b629add03f3  jmp 0x00007B629ADCF035
00007b629add03f8  call 0x00007B629ACC2120
00007b629add03fd  jmp 0x00007B629ADCF03F
00007b629add0402  call 0x00007B629ACC0860
00007b629add0407  jmp 0x00007B629ADCF067
00007b629add040c  call 0x00007B629ACBF5F0
00007b629add0411  jmp 0x00007B629ADCF073
00007b629add0416  call 0x00007B629ACC0860
00007b629add041b  jmp 0x00007B629ADCF0A5
00007b629add0420  call 0x00007B629ACBF5F0
00007b629add0425  jmp 0x00007B629ADCF0B1
00007b629add042a  call 0x00007B629ACC4740
00007b629add042f  jmp 0x00007B629ADCF0BE
00007b629add0434  call 0x00007B629ACB5400
00007b629add0439  jmp 0x00007B629ADCF0CB
00007b629add043e  call 0x00007B629ACB52F0
00007b629add0443  jmp 0x00007B629ADCF0D8
00007b629add0448  call 0x00007B629ACC4620
00007b629add044d  jmp 0x00007B629ADCF0E5
00007b629add0452  call 0x00007B629ACC0860
00007b629add0457  jmp 0x00007B629ADCF10D
00007b629add045c  call 0x00007B629ACBF5F0
00007b629add0461  jmp 0x00007B629ADCF119
00007b629add0466  call 0x00007B629AC09D70
00007b629add046b  jmp 0x00007B629ADCF11F
00007b629add0470  call 0x00007B629ACBE9C0
00007b629add0475  jmp 0x00007B629ADCF129
00007b629add047a  call 0x00007B629ACC0860
00007b629add047f  jmp 0x00007B629ADCF151
00007b629add0484  call 0x00007B629ACBF5F0
00007b629add0489  jmp 0x00007B629ADCF15D
00007b629add048e  call 0x00007B629ACBD750
00007b629add0493  jmp 0x00007B629ADCF16A
00007b629add0498  call 0x00007B629ACBC4E0
00007b629add049d  jmp 0x00007B629ADCF177
00007b629add04a2  call 0x00007B629ACC4740
00007b629add04a7  jmp 0x00007B629ADCF184
00007b629add04ac  call 0x00007B629ACB5400
00007b629add04b1  jmp 0x00007B629ADCF191
00007b629add04b6  call 0x00007B629ACB52F0
00007b629add04bb  jmp 0x00007B629ADCF19E
00007b629add04c0  call 0x00007B629ACC4620
00007b629add04c5  jmp 0x00007B629ADCF1AB
00007b629add04ca  call 0x00007B629ACC0860
00007b629add04cf  jmp 0x00007B629ADCF1BE
00007b629add04d4  call 0x00007B629ACBB270
00007b629add04d9  jmp 0x00007B629ADCF1CB
00007b629add04de  call 0x00007B629ACBA000
00007b629add04e3  jmp 0x00007B629ADCF1D8
00007b629add04e8  call 0x00007B629ACB8D90
00007b629add04ed  jmp 0x00007B629ADCF1E5
00007b629add04f2  call 0x00007B629ACB8A20
00007b629add04f7  jmp 0x00007B629ADCF1F2
00007b629add04fc  call 0x00007B629ACB5400
00007b629add0501  jmp 0x00007B629ADCF1FC
00007b629add0506  call 0x00007B629ACC2240
00007b629add050b  jmp 0x00007B629ADCF206
00007b629add0510  call 0x00007B629ACB52F0
00007b629add0515  jmp 0x00007B629ADCF210
00007b629add051a  call 0x00007B629ACC2120
00007b629add051f  jmp 0x00007B629ADCF21A
00007b629add0524  call 0x00007B629ACB77B0
00007b629add0529  jmp 0x00007B629ADCF224
00007b629add052e  call 0x00007B629ACB6550
00007b629add0533  jmp 0x00007B629ADCF22E
00007b629add0538  call 0x00007B629ACBFD50
00007b629add053d  jmp 0x00007B629ADCF240
00007b629add0542  call 0x00007B629ACB8EA0
00007b629add0547  jmp 0x00007B629ADCF24A
00007b629add054c  call 0x00007B629ACBFC30
00007b629add0551  jmp 0x00007B629ADCF257
00007b629add0556  call 0x00007B629ACB8D90
00007b629add055b  jmp 0x00007B629ADCF264
00007b629add0560  call 0x00007B629ACC2240
00007b629add0565  jmp 0x00007B629ADCF271
00007b629add056a  call 0x00007B629ACB5400
00007b629add056f  jmp 0x00007B629ADCF27E
00007b629add0574  call 0x00007B629ACB52F0
00007b629add0579  jmp 0x00007B629ADCF28B
00007b629add057e  call 0x00007B629ACC2120
00007b629add0583  jmp 0x00007B629ADCF298
00007b629add0588  call 0x00007B629ACB52F0
00007b629add058d  jmp 0x00007B629ADCF2AB
00007b629add0592  call 0x00007B629ACB52F0
00007b629add0597  jmp 0x00007B629ADCF2BE
00007b629add059c  call 0x00007B629ACB52F0
00007b629add05a1  jmp 0x00007B629ADCF2D1
00007b629add05a6  call 0x00007B629ACB52F0
00007b629add05ab  jmp 0x00007B629ADCF2E4
00007b629add05b0  call 0x00007B629ACC2240
00007b629add05b5  jmp 0x00007B629ADCF2F9
00007b629add05ba  call 0x00007B629ACC2240
00007b629add05bf  jmp 0x00007B629ADCF30C
00007b629add05c4  call 0x00007B629ACC2120
00007b629add05c9  jmp 0x00007B629ADCF319
00007b629add05ce  call 0x00007B629ACB52F0
00007b629add05d3  jmp 0x00007B629ADCF32C
00007b629add05d8  call 0x00007B629ACB52F0
00007b629add05dd  jmp 0x00007B629ADCF34F
00007b629add05e2  call 0x00007B629ACB52F0
00007b629add05e7  jmp 0x00007B629ADCF362
00007b629add05ec  call 0x00007B629ABFF540
00007b629add05f1  jmp 0x00007B629ADCF380
00007b629add05f6  call 0x00007B629AC08C20
00007b629add05fb  jmp 0x00007B629ADCF38A
00007b629add0600  call 0x00007B629ACD6600
00007b629add0605  jmp 0x00007B629ADCF396
00007b629add060a  call 0x00007B629ABFF540
00007b629add060f  jmp 0x00007B629ADCF3A6
00007b629add0614  call 0x00007B629ACC0370
00007b629add0619  jmp 0x00007B629ADCF3D4
00007b629add061e  call 0x00007B629ACBF100
00007b629add0623  jmp 0x00007B629ADCF3DD
00007b629add0628  call 0x00007B629ACC0370
00007b629add062d  jmp 0x00007B629ADCF43B
00007b629add0632  call 0x00007B629ACBF100
00007b629add0637  jmp 0x00007B629ADCF444
00007b629add063c  call 0x00007B629ACC0370
00007b629add0641  jmp 0x00007B629ADCF48B
00007b629add0646  call 0x00007B629ACBF100
00007b629add064b  jmp 0x00007B629ADCF494
00007b629add0650  call 0x00007B629AC0B720
00007b629add0655  jmp 0x00007B629ADCF4D7
00007b629add065a  call 0x00007B629ACB47C0
00007b629add065f  jmp 0x00007B629ADCF4EA
00007b629add0664  call 0x00007B629AC08B00
00007b629add0669  jmp 0x00007B629ADCF501
00007b629add066e  call 0x00007B629ABFF430
00007b629add0673  jmp 0x00007B629ADCF514
00007b629add0678  call 0x00007B629ABFF430
00007b629add067d  jmp 0x00007B629ADCF527
00007b629add0682  sub rsp, 0x08
00007b629add0686  push rax
00007b629add0687  push rcx
00007b629add0688  push rdx
00007b629add0689  push rdi
00007b629add068a  push rsi
00007b629add068b  push r8
00007b629add068d  push r9
00007b629add068f  push r10
00007b629add0691  push r11
00007b629add0693  sub rsp, 0xF0
00007b629add069a  vmovaps [rsp], xmm0
00007b629add069f  vmovaps [rsp+0x10], xmm2
00007b629add06a5  vmovaps [rsp+0x20], xmm3
00007b629add06ab  vmovaps [rsp+0x30], xmm4
00007b629add06b1  vmovaps [rsp+0x40], xmm5
00007b629add06b7  vmovaps [rsp+0x50], xmm6
00007b629add06bd  vmovaps [rsp+0x60], xmm7
00007b629add06c3  vmovaps [rsp+0x70], xmm8
00007b629add06c9  vmovaps [rsp+0x80], xmm9
00007b629add06d2  vmovaps [rsp+0x90], xmm10
00007b629add06db  vmovaps [rsp+0xA0], xmm11
00007b629add06e4  vmovaps [rsp+0xB0], xmm12
00007b629add06ed  vmovaps [rsp+0xC0], xmm13
00007b629add06f6  vmovaps [rsp+0xD0], xmm14
00007b629add06ff  vmovaps [rsp+0xE0], xmm15
00007b629add0708  sub rsp, 0x30
00007b629add070c  movaps [rsp], xmm1
00007b629add0710  movaps [rsp+0x10], xmm15
00007b629add0716  movaps [rsp+0x20], xmm14
00007b629add071c  lea rdi, [rsp]
00007b629add0720  mov esi, 0x00
00007b629add0725  mov rax, 0x583FED93F530
00007b629add072f  call rax
00007b629add0731  movaps xmm1, [rsp]
00007b629add0735  add rsp, 0x30
00007b629add0739  vmovaps xmm0, [rsp]
00007b629add073e  vmovaps xmm2, [rsp+0x10]
00007b629add0744  vmovaps xmm3, [rsp+0x20]
00007b629add074a  vmovaps xmm4, [rsp+0x30]
00007b629add0750  vmovaps xmm5, [rsp+0x40]
00007b629add0756  vmovaps xmm6, [rsp+0x50]
00007b629add075c  vmovaps xmm7, [rsp+0x60]
00007b629add0762  vmovaps xmm8, [rsp+0x70]
00007b629add0768  vmovaps xmm9, [rsp+0x80]
00007b629add0771  vmovaps xmm10, [rsp+0x90]
00007b629add077a  vmovaps xmm11, [rsp+0xA0]
00007b629add0783  vmovaps xmm12, [rsp+0xB0]
00007b629add078c  vmovaps xmm13, [rsp+0xC0]
00007b629add0795  vmovaps xmm14, [rsp+0xD0]
00007b629add079e  vmovaps xmm15, [rsp+0xE0]
00007b629add07a7  add rsp, 0xF0
00007b629add07ae  pop r11
00007b629add07b0  pop r10
00007b629add07b2  pop r9
00007b629add07b4  pop r8
00007b629add07b6  pop rsi
00007b629add07b7  pop rdi
00007b629add07b8  pop rdx
00007b629add07b9  pop rcx
00007b629add07ba  pop rax
00007b629add07bb  add rsp, 0x08
00007b629add07bf  jmp 0x00007B629ADCF581
00007b629add07c4  sub rsp, 0x08
00007b629add07c8  push rax
00007b629add07c9  push rcx
00007b629add07ca  push rdx
00007b629add07cb  push rdi
00007b629add07cc  push rsi
00007b629add07cd  push r8
00007b629add07cf  push r9
00007b629add07d1  push r10
00007b629add07d3  push r11
00007b629add07d5  sub rsp, 0xF0
00007b629add07dc  vmovaps [rsp], xmm0
00007b629add07e1  vmovaps [rsp+0x10], xmm1
00007b629add07e7  vmovaps [rsp+0x20], xmm2
00007b629add07ed  vmovaps [rsp+0x30], xmm3
00007b629add07f3  vmovaps [rsp+0x40], xmm4
00007b629add07f9  vmovaps [rsp+0x50], xmm5
00007b629add07ff  vmovaps [rsp+0x60], xmm6
00007b629add0805  vmovaps [rsp+0x70], xmm7
00007b629add080b  vmovaps [rsp+0x80], xmm8
00007b629add0814  vmovaps [rsp+0x90], xmm9
00007b629add081d  vmovaps [rsp+0xA0], xmm10
00007b629add0826  vmovaps [rsp+0xB0], xmm11
00007b629add082f  vmovaps [rsp+0xC0], xmm12
00007b629add0838  vmovaps [rsp+0xD0], xmm14
00007b629add0841  vmovaps [rsp+0xE0], xmm15
00007b629add084a  sub rsp, 0x30
00007b629add084e  movaps [rsp], xmm13
00007b629add0853  movaps [rsp+0x10], xmm1
00007b629add0858  movaps [rsp+0x20], xmm14
00007b629add085e  lea rdi, [rsp]
00007b629add0862  mov esi, 0x00
00007b629add0867  mov rax, 0x583FED93F530
00007b629add0871  call rax
00007b629add0873  movaps xmm13, [rsp]
00007b629add0878  add rsp, 0x30
00007b629add087c  vmovaps xmm0, [rsp]
00007b629add0881  vmovaps xmm1, [rsp+0x10]
00007b629add0887  vmovaps xmm2, [rsp+0x20]
00007b629add088d  vmovaps xmm3, [rsp+0x30]
00007b629add0893  vmovaps xmm4, [rsp+0x40]
00007b629add0899  vmovaps xmm5, [rsp+0x50]
00007b629add089f  vmovaps xmm6, [rsp+0x60]
00007b629add08a5  vmovaps xmm7, [rsp+0x70]
00007b629add08ab  vmovaps xmm8, [rsp+0x80]
00007b629add08b4  vmovaps xmm9, [rsp+0x90]
00007b629add08bd  vmovaps xmm10, [rsp+0xA0]
00007b629add08c6  vmovaps xmm11, [rsp+0xB0]
00007b629add08cf  vmovaps xmm12, [rsp+0xC0]
00007b629add08d8  vmovaps xmm14, [rsp+0xD0]
00007b629add08e1  vmovaps xmm15, [rsp+0xE0]
00007b629add08ea  add rsp, 0xF0
00007b629add08f1  pop r11
00007b629add08f3  pop r10
00007b629add08f5  pop r9
00007b629add08f7  pop r8
00007b629add08f9  pop rsi
00007b629add08fa  pop rdi
00007b629add08fb  pop rdx
00007b629add08fc  pop rcx
00007b629add08fd  pop rax
00007b629add08fe  add rsp, 0x08
00007b629add0902  jmp 0x00007B629ADCF5CF
00007b629add0907  sub rsp, 0x08
00007b629add090b  push rax
00007b629add090c  push rcx
00007b629add090d  push rdx
00007b629add090e  push rdi
00007b629add090f  push rsi
00007b629add0910  push r8
00007b629add0912  push r9
00007b629add0914  push r10
00007b629add0916  push r11
00007b629add0918  sub rsp, 0xF0
00007b629add091f  vmovaps [rsp], xmm0
00007b629add0924  vmovaps [rsp+0x10], xmm1
00007b629add092a  vmovaps [rsp+0x20], xmm2
00007b629add0930  vmovaps [rsp+0x30], xmm3
00007b629add0936  vmovaps [rsp+0x40], xmm4
00007b629add093c  vmovaps [rsp+0x50], xmm5
00007b629add0942  vmovaps [rsp+0x60], xmm6
00007b629add0948  vmovaps [rsp+0x70], xmm7
00007b629add094e  vmovaps [rsp+0x80], xmm8
00007b629add0957  vmovaps [rsp+0x90], xmm9
00007b629add0960  vmovaps [rsp+0xA0], xmm10
00007b629add0969  vmovaps [rsp+0xB0], xmm11
00007b629add0972  vmovaps [rsp+0xC0], xmm12
00007b629add097b  vmovaps [rsp+0xD0], xmm13
00007b629add0984  vmovaps [rsp+0xE0], xmm14
00007b629add098d  sub rsp, 0x30
00007b629add0991  movaps [rsp], xmm15
00007b629add0996  movaps [rsp+0x10], xmm14
00007b629add099c  movaps [rsp+0x20], xmm1
00007b629add09a1  lea rdi, [rsp]
00007b629add09a5  mov esi, 0x00
00007b629add09aa  mov rax, 0x583FED93F530
00007b629add09b4  call rax
00007b629add09b6  movaps xmm15, [rsp]
00007b629add09bb  add rsp, 0x30
00007b629add09bf  vmovaps xmm0, [rsp]
00007b629add09c4  vmovaps xmm1, [rsp+0x10]
00007b629add09ca  vmovaps xmm2, [rsp+0x20]
00007b629add09d0  vmovaps xmm3, [rsp+0x30]
00007b629add09d6  vmovaps xmm4, [rsp+0x40]
00007b629add09dc  vmovaps xmm5, [rsp+0x50]
00007b629add09e2  vmovaps xmm6, [rsp+0x60]
00007b629add09e8  vmovaps xmm7, [rsp+0x70]
00007b629add09ee  vmovaps xmm8, [rsp+0x80]
00007b629add09f7  vmovaps xmm9, [rsp+0x90]
00007b629add0a00  vmovaps xmm10, [rsp+0xA0]
00007b629add0a09  vmovaps xmm11, [rsp+0xB0]
00007b629add0a12  vmovaps xmm12, [rsp+0xC0]
00007b629add0a1b  vmovaps xmm13, [rsp+0xD0]
00007b629add0a24  vmovaps xmm14, [rsp+0xE0]
00007b629add0a2d  add rsp, 0xF0
00007b629add0a34  pop r11
00007b629add0a36  pop r10
00007b629add0a38  pop r9
00007b629add0a3a  pop r8
00007b629add0a3c  pop rsi
00007b629add0a3d  pop rdi
00007b629add0a3e  pop rdx
00007b629add0a3f  pop rcx
00007b629add0a40  pop rax
00007b629add0a41  add rsp, 0x08
00007b629add0a45  jmp 0x00007B629ADCF617
00007b629add0a4a  sub rsp, 0x08
00007b629add0a4e  push rax
00007b629add0a4f  push rcx
00007b629add0a50  push rdx
00007b629add0a51  push rdi
00007b629add0a52  push rsi
00007b629add0a53  push r8
00007b629add0a55  push r9
00007b629add0a57  push r10
00007b629add0a59  push r11
00007b629add0a5b  sub rsp, 0xF0
00007b629add0a62  vmovaps [rsp], xmm0
00007b629add0a67  vmovaps [rsp+0x10], xmm2
00007b629add0a6d  vmovaps [rsp+0x20], xmm3
00007b629add0a73  vmovaps [rsp+0x30], xmm4
00007b629add0a79  vmovaps [rsp+0x40], xmm5
00007b629add0a7f  vmovaps [rsp+0x50], xmm6
00007b629add0a85  vmovaps [rsp+0x60], xmm7
00007b629add0a8b  vmovaps [rsp+0x70], xmm8
00007b629add0a91  vmovaps [rsp+0x80], xmm9
00007b629add0a9a  vmovaps [rsp+0x90], xmm10
00007b629add0aa3  vmovaps [rsp+0xA0], xmm11
00007b629add0aac  vmovaps [rsp+0xB0], xmm12
00007b629add0ab5  vmovaps [rsp+0xC0], xmm13
00007b629add0abe  vmovaps [rsp+0xD0], xmm14
00007b629add0ac7  vmovaps [rsp+0xE0], xmm15
00007b629add0ad0  sub rsp, 0x30
00007b629add0ad4  movaps [rsp], xmm1
00007b629add0ad8  movaps [rsp+0x10], xmm14
00007b629add0ade  movaps [rsp+0x20], xmm10
00007b629add0ae4  lea rdi, [rsp]
00007b629add0ae8  mov esi, 0x00
00007b629add0aed  mov rax, 0x583FED93F530
00007b629add0af7  call rax
00007b629add0af9  movaps xmm1, [rsp]
00007b629add0afd  add rsp, 0x30
00007b629add0b01  vmovaps xmm0, [rsp]
00007b629add0b06  vmovaps xmm2, [rsp+0x10]
00007b629add0b0c  vmovaps xmm3, [rsp+0x20]
00007b629add0b12  vmovaps xmm4, [rsp+0x30]
00007b629add0b18  vmovaps xmm5, [rsp+0x40]
00007b629add0b1e  vmovaps xmm6, [rsp+0x50]
00007b629add0b24  vmovaps xmm7, [rsp+0x60]
00007b629add0b2a  vmovaps xmm8, [rsp+0x70]
00007b629add0b30  vmovaps xmm9, [rsp+0x80]
00007b629add0b39  vmovaps xmm10, [rsp+0x90]
00007b629add0b42  vmovaps xmm11, [rsp+0xA0]
00007b629add0b4b  vmovaps xmm12, [rsp+0xB0]
00007b629add0b54  vmovaps xmm13, [rsp+0xC0]
00007b629add0b5d  vmovaps xmm14, [rsp+0xD0]
00007b629add0b66  vmovaps xmm15, [rsp+0xE0]
00007b629add0b6f  add rsp, 0xF0
00007b629add0b76  pop r11
00007b629add0b78  pop r10
00007b629add0b7a  pop r9
00007b629add0b7c  pop r8
00007b629add0b7e  pop rsi
00007b629add0b7f  pop rdi
00007b629add0b80  pop rdx
00007b629add0b81  pop rcx
00007b629add0b82  pop rax
00007b629add0b83  add rsp, 0x08
00007b629add0b87  jmp 0x00007B629ADCF631
00007b629add0b8c  sub rsp, 0x08
00007b629add0b90  push rax
00007b629add0b91  push rcx
00007b629add0b92  push rdx
00007b629add0b93  push rdi
00007b629add0b94  push rsi
00007b629add0b95  push r8
00007b629add0b97  push r9
00007b629add0b99  push r10
00007b629add0b9b  push r11
00007b629add0b9d  sub rsp, 0xF0
00007b629add0ba4  vmovaps [rsp], xmm0
00007b629add0ba9  vmovaps [rsp+0x10], xmm1
00007b629add0baf  vmovaps [rsp+0x20], xmm2
00007b629add0bb5  vmovaps [rsp+0x30], xmm3
00007b629add0bbb  vmovaps [rsp+0x40], xmm4
00007b629add0bc1  vmovaps [rsp+0x50], xmm5
00007b629add0bc7  vmovaps [rsp+0x60], xmm6
00007b629add0bcd  vmovaps [rsp+0x70], xmm7
00007b629add0bd3  vmovaps [rsp+0x80], xmm8
00007b629add0bdc  vmovaps [rsp+0x90], xmm9
00007b629add0be5  vmovaps [rsp+0xA0], xmm10
00007b629add0bee  vmovaps [rsp+0xB0], xmm11
00007b629add0bf7  vmovaps [rsp+0xC0], xmm12
00007b629add0c00  vmovaps [rsp+0xD0], xmm14
00007b629add0c09  vmovaps [rsp+0xE0], xmm15
00007b629add0c12  sub rsp, 0x30
00007b629add0c16  movaps [rsp], xmm13
00007b629add0c1b  movaps [rsp+0x10], xmm14
00007b629add0c21  movaps [rsp+0x20], xmm2
00007b629add0c26  lea rdi, [rsp]
00007b629add0c2a  mov esi, 0x00
00007b629add0c2f  mov rax, 0x583FED93F530
00007b629add0c39  call rax
00007b629add0c3b  movaps xmm13, [rsp]
00007b629add0c40  add rsp, 0x30
00007b629add0c44  vmovaps xmm0, [rsp]
00007b629add0c49  vmovaps xmm1, [rsp+0x10]
00007b629add0c4f  vmovaps xmm2, [rsp+0x20]
00007b629add0c55  vmovaps xmm3, [rsp+0x30]
00007b629add0c5b  vmovaps xmm4, [rsp+0x40]
00007b629add0c61  vmovaps xmm5, [rsp+0x50]
00007b629add0c67  vmovaps xmm6, [rsp+0x60]
00007b629add0c6d  vmovaps xmm7, [rsp+0x70]
00007b629add0c73  vmovaps xmm8, [rsp+0x80]
00007b629add0c7c  vmovaps xmm9, [rsp+0x90]
00007b629add0c85  vmovaps xmm10, [rsp+0xA0]
00007b629add0c8e  vmovaps xmm11, [rsp+0xB0]
00007b629add0c97  vmovaps xmm12, [rsp+0xC0]
00007b629add0ca0  vmovaps xmm14, [rsp+0xD0]
00007b629add0ca9  vmovaps xmm15, [rsp+0xE0]
00007b629add0cb2  add rsp, 0xF0
00007b629add0cb9  pop r11
00007b629add0cbb  pop r10
00007b629add0cbd  pop r9
00007b629add0cbf  pop r8
00007b629add0cc1  pop rsi
00007b629add0cc2  pop rdi
00007b629add0cc3  pop rdx
00007b629add0cc4  pop rcx
00007b629add0cc5  pop rax
00007b629add0cc6  add rsp, 0x08
00007b629add0cca  jmp 0x00007B629ADCF64C
00007b629add0ccf  sub rsp, 0x08
00007b629add0cd3  push rax
00007b629add0cd4  push rcx
00007b629add0cd5  push rdx
00007b629add0cd6  push rdi
00007b629add0cd7  push rsi
00007b629add0cd8  push r8
00007b629add0cda  push r9
00007b629add0cdc  push r10
00007b629add0cde  push r11
00007b629add0ce0  sub rsp, 0xF0
00007b629add0ce7  vmovaps [rsp], xmm0
00007b629add0cec  vmovaps [rsp+0x10], xmm2
00007b629add0cf2  vmovaps [rsp+0x20], xmm3
00007b629add0cf8  vmovaps [rsp+0x30], xmm4
00007b629add0cfe  vmovaps [rsp+0x40], xmm5
00007b629add0d04  vmovaps [rsp+0x50], xmm6
00007b629add0d0a  vmovaps [rsp+0x60], xmm7
00007b629add0d10  vmovaps [rsp+0x70], xmm8
00007b629add0d16  vmovaps [rsp+0x80], xmm9
00007b629add0d1f  vmovaps [rsp+0x90], xmm10
00007b629add0d28  vmovaps [rsp+0xA0], xmm11
00007b629add0d31  vmovaps [rsp+0xB0], xmm12
00007b629add0d3a  vmovaps [rsp+0xC0], xmm13
00007b629add0d43  vmovaps [rsp+0xD0], xmm14
00007b629add0d4c  vmovaps [rsp+0xE0], xmm15
00007b629add0d55  sub rsp, 0x30
00007b629add0d59  movaps [rsp], xmm1
00007b629add0d5d  movaps [rsp+0x10], xmm10
00007b629add0d63  movaps [rsp+0x20], xmm2
00007b629add0d68  lea rdi, [rsp]
00007b629add0d6c  mov esi, 0x00
00007b629add0d71  mov rax, 0x583FED93F530
00007b629add0d7b  call rax
00007b629add0d7d  movaps xmm1, [rsp]
00007b629add0d81  add rsp, 0x30
00007b629add0d85  vmovaps xmm0, [rsp]
00007b629add0d8a  vmovaps xmm2, [rsp+0x10]
00007b629add0d90  vmovaps xmm3, [rsp+0x20]
00007b629add0d96  vmovaps xmm4, [rsp+0x30]
00007b629add0d9c  vmovaps xmm5, [rsp+0x40]
00007b629add0da2  vmovaps xmm6, [rsp+0x50]
00007b629add0da8  vmovaps xmm7, [rsp+0x60]
00007b629add0dae  vmovaps xmm8, [rsp+0x70]
00007b629add0db4  vmovaps xmm9, [rsp+0x80]
00007b629add0dbd  vmovaps xmm10, [rsp+0x90]
00007b629add0dc6  vmovaps xmm11, [rsp+0xA0]
00007b629add0dcf  vmovaps xmm12, [rsp+0xB0]
00007b629add0dd8  vmovaps xmm13, [rsp+0xC0]
00007b629add0de1  vmovaps xmm14, [rsp+0xD0]
00007b629add0dea  vmovaps xmm15, [rsp+0xE0]
00007b629add0df3  add rsp, 0xF0
00007b629add0dfa  pop r11
00007b629add0dfc  pop r10
00007b629add0dfe  pop r9
00007b629add0e00  pop r8
00007b629add0e02  pop rsi
00007b629add0e03  pop rdi
00007b629add0e04  pop rdx
00007b629add0e05  pop rcx
00007b629add0e06  pop rax
00007b629add0e07  add rsp, 0x08
00007b629add0e0b  jmp 0x00007B629ADCF6B4
00007b629add0e10  sub rsp, 0x08
00007b629add0e14  push rax
00007b629add0e15  push rcx
00007b629add0e16  push rdx
00007b629add0e17  push rdi
00007b629add0e18  push rsi
00007b629add0e19  push r8
00007b629add0e1b  push r9
00007b629add0e1d  push r10
00007b629add0e1f  push r11
00007b629add0e21  sub rsp, 0xF0
00007b629add0e28  vmovaps [rsp], xmm0
00007b629add0e2d  vmovaps [rsp+0x10], xmm1
00007b629add0e33  vmovaps [rsp+0x20], xmm2
00007b629add0e39  vmovaps [rsp+0x30], xmm3
00007b629add0e3f  vmovaps [rsp+0x40], xmm4
00007b629add0e45  vmovaps [rsp+0x50], xmm5
00007b629add0e4b  vmovaps [rsp+0x60], xmm6
00007b629add0e51  vmovaps [rsp+0x70], xmm7
00007b629add0e57  vmovaps [rsp+0x80], xmm8
00007b629add0e60  vmovaps [rsp+0x90], xmm9
00007b629add0e69  vmovaps [rsp+0xA0], xmm10
00007b629add0e72  vmovaps [rsp+0xB0], xmm11
00007b629add0e7b  vmovaps [rsp+0xC0], xmm12
00007b629add0e84  vmovaps [rsp+0xD0], xmm13
00007b629add0e8d  vmovaps [rsp+0xE0], xmm14
00007b629add0e96  sub rsp, 0x30
00007b629add0e9a  movaps [rsp], xmm15
00007b629add0e9f  movaps [rsp+0x10], xmm10
00007b629add0ea5  movaps [rsp+0x20], xmm2
00007b629add0eaa  lea rdi, [rsp]
00007b629add0eae  mov esi, 0x00
00007b629add0eb3  mov rax, 0x583FED93F530
00007b629add0ebd  call rax
00007b629add0ebf  movaps xmm15, [rsp]
00007b629add0ec4  add rsp, 0x30
00007b629add0ec8  vmovaps xmm0, [rsp]
00007b629add0ecd  vmovaps xmm1, [rsp+0x10]
00007b629add0ed3  vmovaps xmm2, [rsp+0x20]
00007b629add0ed9  vmovaps xmm3, [rsp+0x30]
00007b629add0edf  vmovaps xmm4, [rsp+0x40]
00007b629add0ee5  vmovaps xmm5, [rsp+0x50]
00007b629add0eeb  vmovaps xmm6, [rsp+0x60]
00007b629add0ef1  vmovaps xmm7, [rsp+0x70]
00007b629add0ef7  vmovaps xmm8, [rsp+0x80]
00007b629add0f00  vmovaps xmm9, [rsp+0x90]
00007b629add0f09  vmovaps xmm10, [rsp+0xA0]
00007b629add0f12  vmovaps xmm11, [rsp+0xB0]
00007b629add0f1b  vmovaps xmm12, [rsp+0xC0]
00007b629add0f24  vmovaps xmm13, [rsp+0xD0]
00007b629add0f2d  vmovaps xmm14, [rsp+0xE0]
00007b629add0f36  add rsp, 0xF0
00007b629add0f3d  pop r11
00007b629add0f3f  pop r10
00007b629add0f41  pop r9
00007b629add0f43  pop r8
00007b629add0f45  pop rsi
00007b629add0f46  pop rdi
00007b629add0f47  pop rdx
00007b629add0f48  pop rcx
00007b629add0f49  pop rax
00007b629add0f4a  add rsp, 0x08
00007b629add0f4e  jmp 0x00007B629ADCF706
00007b629add0f53  sub rsp, 0x08
00007b629add0f57  push rax
00007b629add0f58  push rcx
00007b629add0f59  push rdx
00007b629add0f5a  push rdi
00007b629add0f5b  push rsi
00007b629add0f5c  push r8
00007b629add0f5e  push r9
00007b629add0f60  push r10
00007b629add0f62  push r11
00007b629add0f64  sub rsp, 0xF0
00007b629add0f6b  vmovaps [rsp], xmm0
00007b629add0f70  vmovaps [rsp+0x10], xmm2
00007b629add0f76  vmovaps [rsp+0x20], xmm3
00007b629add0f7c  vmovaps [rsp+0x30], xmm4
00007b629add0f82  vmovaps [rsp+0x40], xmm5
00007b629add0f88  vmovaps [rsp+0x50], xmm6
00007b629add0f8e  vmovaps [rsp+0x60], xmm7
00007b629add0f94  vmovaps [rsp+0x70], xmm8
00007b629add0f9a  vmovaps [rsp+0x80], xmm9
00007b629add0fa3  vmovaps [rsp+0x90], xmm10
00007b629add0fac  vmovaps [rsp+0xA0], xmm11
00007b629add0fb5  vmovaps [rsp+0xB0], xmm12
00007b629add0fbe  vmovaps [rsp+0xC0], xmm13
00007b629add0fc7  vmovaps [rsp+0xD0], xmm14
00007b629add0fd0  vmovaps [rsp+0xE0], xmm15
00007b629add0fd9  sub rsp, 0x30
00007b629add0fdd  movaps [rsp], xmm1
00007b629add0fe1  movaps [rsp+0x10], xmm10
00007b629add0fe7  movaps [rsp+0x20], xmm12
00007b629add0fed  lea rdi, [rsp]
00007b629add0ff1  mov esi, 0x00
00007b629add0ff6  mov rax, 0x583FED93F530
00007b629add1000  call rax
00007b629add1002  movaps xmm1, [rsp]
00007b629add1006  add rsp, 0x30
00007b629add100a  vmovaps xmm0, [rsp]
00007b629add100f  vmovaps xmm2, [rsp+0x10]
00007b629add1015  vmovaps xmm3, [rsp+0x20]
00007b629add101b  vmovaps xmm4, [rsp+0x30]
00007b629add1021  vmovaps xmm5, [rsp+0x40]
00007b629add1027  vmovaps xmm6, [rsp+0x50]
00007b629add102d  vmovaps xmm7, [rsp+0x60]
00007b629add1033  vmovaps xmm8, [rsp+0x70]
00007b629add1039  vmovaps xmm9, [rsp+0x80]
00007b629add1042  vmovaps xmm10, [rsp+0x90]
00007b629add104b  vmovaps xmm11, [rsp+0xA0]
00007b629add1054  vmovaps xmm12, [rsp+0xB0]
00007b629add105d  vmovaps xmm13, [rsp+0xC0]
00007b629add1066  vmovaps xmm14, [rsp+0xD0]
00007b629add106f  vmovaps xmm15, [rsp+0xE0]
00007b629add1078  add rsp, 0xF0
00007b629add107f  pop r11
00007b629add1081  pop r10
00007b629add1083  pop r9
00007b629add1085  pop r8
00007b629add1087  pop rsi
00007b629add1088  pop rdi
00007b629add1089  pop rdx
00007b629add108a  pop rcx
00007b629add108b  pop rax
00007b629add108c  add rsp, 0x08
00007b629add1090  jmp 0x00007B629ADCF732
00007b629add1095  sub rsp, 0x08
00007b629add1099  push rax
00007b629add109a  push rcx
00007b629add109b  push rdx
00007b629add109c  push rdi
00007b629add109d  push rsi
00007b629add109e  push r8
00007b629add10a0  push r9
00007b629add10a2  push r10
00007b629add10a4  push r11
00007b629add10a6  sub rsp, 0xF0
00007b629add10ad  vmovaps [rsp], xmm0
00007b629add10b2  vmovaps [rsp+0x10], xmm1
00007b629add10b8  vmovaps [rsp+0x20], xmm2
00007b629add10be  vmovaps [rsp+0x30], xmm3
00007b629add10c4  vmovaps [rsp+0x40], xmm4
00007b629add10ca  vmovaps [rsp+0x50], xmm5
00007b629add10d0  vmovaps [rsp+0x60], xmm6
00007b629add10d6  vmovaps [rsp+0x70], xmm7
00007b629add10dc  vmovaps [rsp+0x80], xmm8
00007b629add10e5  vmovaps [rsp+0x90], xmm9
00007b629add10ee  vmovaps [rsp+0xA0], xmm10
00007b629add10f7  vmovaps [rsp+0xB0], xmm11
00007b629add1100  vmovaps [rsp+0xC0], xmm12
00007b629add1109  vmovaps [rsp+0xD0], xmm13
00007b629add1112  vmovaps [rsp+0xE0], xmm14
00007b629add111b  sub rsp, 0x30
00007b629add111f  movaps [rsp], xmm15
00007b629add1124  movaps [rsp+0x10], xmm10
00007b629add112a  movaps [rsp+0x20], xmm12
00007b629add1130  lea rdi, [rsp]
00007b629add1134  mov esi, 0x00
00007b629add1139  mov rax, 0x583FED93F530
00007b629add1143  call rax
00007b629add1145  movaps xmm15, [rsp]
00007b629add114a  add rsp, 0x30
00007b629add114e  vmovaps xmm0, [rsp]
00007b629add1153  vmovaps xmm1, [rsp+0x10]
00007b629add1159  vmovaps xmm2, [rsp+0x20]
00007b629add115f  vmovaps xmm3, [rsp+0x30]
00007b629add1165  vmovaps xmm4, [rsp+0x40]
00007b629add116b  vmovaps xmm5, [rsp+0x50]
00007b629add1171  vmovaps xmm6, [rsp+0x60]
00007b629add1177  vmovaps xmm7, [rsp+0x70]
00007b629add117d  vmovaps xmm8, [rsp+0x80]
00007b629add1186  vmovaps xmm9, [rsp+0x90]
00007b629add118f  vmovaps xmm10, [rsp+0xA0]
00007b629add1198  vmovaps xmm11, [rsp+0xB0]
00007b629add11a1  vmovaps xmm12, [rsp+0xC0]
00007b629add11aa  vmovaps xmm13, [rsp+0xD0]
00007b629add11b3  vmovaps xmm14, [rsp+0xE0]
00007b629add11bc  add rsp, 0xF0
00007b629add11c3  pop r11
00007b629add11c5  pop r10
00007b629add11c7  pop r9
00007b629add11c9  pop r8
00007b629add11cb  pop rsi
00007b629add11cc  pop rdi
00007b629add11cd  pop rdx
00007b629add11ce  pop rcx
00007b629add11cf  pop rax
00007b629add11d0  add rsp, 0x08
00007b629add11d4  jmp 0x00007B629ADCF75E
00007b629add11d9  call 0x00007B629ABFF430
00007b629add11de  jmp 0x00007B629ADCF7EE
00007b629add11e3  call 0x00007B629ABFF430
00007b629add11e8  jmp 0x00007B629ADCF801
00007b629add11ed  sub rsp, 0x08
00007b629add11f1  push rax
00007b629add11f2  push rcx
00007b629add11f3  push rdx
00007b629add11f4  push rdi
00007b629add11f5  push rsi
00007b629add11f6  push r8
00007b629add11f8  push r9
00007b629add11fa  push r10
00007b629add11fc  push r11
00007b629add11fe  sub rsp, 0xF0
00007b629add1205  vmovaps [rsp], xmm0
00007b629add120a  vmovaps [rsp+0x10], xmm2
00007b629add1210  vmovaps [rsp+0x20], xmm3
00007b629add1216  vmovaps [rsp+0x30], xmm4
00007b629add121c  vmovaps [rsp+0x40], xmm5
00007b629add1222  vmovaps [rsp+0x50], xmm6
00007b629add1228  vmovaps [rsp+0x60], xmm7
00007b629add122e  vmovaps [rsp+0x70], xmm8
00007b629add1234  vmovaps [rsp+0x80], xmm9
00007b629add123d  vmovaps [rsp+0x90], xmm10
00007b629add1246  vmovaps [rsp+0xA0], xmm11
00007b629add124f  vmovaps [rsp+0xB0], xmm12
00007b629add1258  vmovaps [rsp+0xC0], xmm13
00007b629add1261  vmovaps [rsp+0xD0], xmm14
00007b629add126a  vmovaps [rsp+0xE0], xmm15
00007b629add1273  sub rsp, 0x30
00007b629add1277  movaps [rsp], xmm1
00007b629add127b  movaps [rsp+0x10], xmm13
00007b629add1281  movaps [rsp+0x20], xmm2
00007b629add1286  lea rdi, [rsp]
00007b629add128a  mov esi, 0x00
00007b629add128f  mov rax, 0x583FED93F530
00007b629add1299  call rax
00007b629add129b  movaps xmm1, [rsp]
00007b629add129f  add rsp, 0x30
00007b629add12a3  vmovaps xmm0, [rsp]
00007b629add12a8  vmovaps xmm2, [rsp+0x10]
00007b629add12ae  vmovaps xmm3, [rsp+0x20]
00007b629add12b4  vmovaps xmm4, [rsp+0x30]
00007b629add12ba  vmovaps xmm5, [rsp+0x40]
00007b629add12c0  vmovaps xmm6, [rsp+0x50]
00007b629add12c6  vmovaps xmm7, [rsp+0x60]
00007b629add12cc  vmovaps xmm8, [rsp+0x70]
00007b629add12d2  vmovaps xmm9, [rsp+0x80]
00007b629add12db  vmovaps xmm10, [rsp+0x90]
00007b629add12e4  vmovaps xmm11, [rsp+0xA0]
00007b629add12ed  vmovaps xmm12, [rsp+0xB0]
00007b629add12f6  vmovaps xmm13, [rsp+0xC0]
00007b629add12ff  vmovaps xmm14, [rsp+0xD0]
00007b629add1308  vmovaps xmm15, [rsp+0xE0]
00007b629add1311  add rsp, 0xF0
00007b629add1318  pop r11
00007b629add131a  pop r10
00007b629add131c  pop r9
00007b629add131e  pop r8
00007b629add1320  pop rsi
00007b629add1321  pop rdi
00007b629add1322  pop rdx
00007b629add1323  pop rcx
00007b629add1324  pop rax
00007b629add1325  add rsp, 0x08
00007b629add1329  jmp 0x00007B629ADCF82C
00007b629add132e  call 0x00007B629AC0E760
00007b629add1333  jmp 0x00007B629ADCF839
00007b629add1338  sub rsp, 0x08
00007b629add133c  push rax
00007b629add133d  push rcx
00007b629add133e  push rdx
00007b629add133f  push rdi
00007b629add1340  push rsi
00007b629add1341  push r8
00007b629add1343  push r9
00007b629add1345  push r10
00007b629add1347  push r11
00007b629add1349  sub rsp, 0xF0
00007b629add1350  vmovaps [rsp], xmm0
00007b629add1355  vmovaps [rsp+0x10], xmm1
00007b629add135b  vmovaps [rsp+0x20], xmm2
00007b629add1361  vmovaps [rsp+0x30], xmm3
00007b629add1367  vmovaps [rsp+0x40], xmm4
00007b629add136d  vmovaps [rsp+0x50], xmm5
00007b629add1373  vmovaps [rsp+0x60], xmm6
00007b629add1379  vmovaps [rsp+0x70], xmm7
00007b629add137f  vmovaps [rsp+0x80], xmm8
00007b629add1388  vmovaps [rsp+0x90], xmm9
00007b629add1391  vmovaps [rsp+0xA0], xmm10
00007b629add139a  vmovaps [rsp+0xB0], xmm11
00007b629add13a3  vmovaps [rsp+0xC0], xmm12
00007b629add13ac  vmovaps [rsp+0xD0], xmm14
00007b629add13b5  vmovaps [rsp+0xE0], xmm15
00007b629add13be  sub rsp, 0x30
00007b629add13c2  movaps [rsp], xmm13
00007b629add13c7  movaps [rsp+0x10], xmm2
00007b629add13cc  movaps [rsp+0x20], xmm1
00007b629add13d1  lea rdi, [rsp]
00007b629add13d5  mov esi, 0x00
00007b629add13da  mov rax, 0x583FED93F530
00007b629add13e4  call rax
00007b629add13e6  movaps xmm13, [rsp]
00007b629add13eb  add rsp, 0x30
00007b629add13ef  vmovaps xmm0, [rsp]
00007b629add13f4  vmovaps xmm1, [rsp+0x10]
00007b629add13fa  vmovaps xmm2, [rsp+0x20]
00007b629add1400  vmovaps xmm3, [rsp+0x30]
00007b629add1406  vmovaps xmm4, [rsp+0x40]
00007b629add140c  vmovaps xmm5, [rsp+0x50]
00007b629add1412  vmovaps xmm6, [rsp+0x60]
00007b629add1418  vmovaps xmm7, [rsp+0x70]
00007b629add141e  vmovaps xmm8, [rsp+0x80]
00007b629add1427  vmovaps xmm9, [rsp+0x90]
00007b629add1430  vmovaps xmm10, [rsp+0xA0]
00007b629add1439  vmovaps xmm11, [rsp+0xB0]
00007b629add1442  vmovaps xmm12, [rsp+0xC0]
00007b629add144b  vmovaps xmm14, [rsp+0xD0]
00007b629add1454  vmovaps xmm15, [rsp+0xE0]
00007b629add145d  add rsp, 0xF0
00007b629add1464  pop r11
00007b629add1466  pop r10
00007b629add1468  pop r9
00007b629add146a  pop r8
00007b629add146c  pop rsi
00007b629add146d  pop rdi
00007b629add146e  pop rdx
00007b629add146f  pop rcx
00007b629add1470  pop rax
00007b629add1471  add rsp, 0x08
00007b629add1475  jmp 0x00007B629ADCF878
00007b629add147a  sub rsp, 0x08
00007b629add147e  push rax
00007b629add147f  push rcx
00007b629add1480  push rdx
00007b629add1481  push rdi
00007b629add1482  push rsi
00007b629add1483  push r8
00007b629add1485  push r9
00007b629add1487  push r10
00007b629add1489  push r11
00007b629add148b  sub rsp, 0xF0
00007b629add1492  vmovaps [rsp], xmm0
00007b629add1497  vmovaps [rsp+0x10], xmm2
00007b629add149d  vmovaps [rsp+0x20], xmm3
00007b629add14a3  vmovaps [rsp+0x30], xmm4
00007b629add14a9  vmovaps [rsp+0x40], xmm5
00007b629add14af  vmovaps [rsp+0x50], xmm6
00007b629add14b5  vmovaps [rsp+0x60], xmm7
00007b629add14bb  vmovaps [rsp+0x70], xmm8
00007b629add14c1  vmovaps [rsp+0x80], xmm9
00007b629add14ca  vmovaps [rsp+0x90], xmm10
00007b629add14d3  vmovaps [rsp+0xA0], xmm11
00007b629add14dc  vmovaps [rsp+0xB0], xmm12
00007b629add14e5  vmovaps [rsp+0xC0], xmm13
00007b629add14ee  vmovaps [rsp+0xD0], xmm14
00007b629add14f7  vmovaps [rsp+0xE0], xmm15
00007b629add1500  sub rsp, 0x30
00007b629add1504  movaps [rsp], xmm1
00007b629add1508  movaps [rsp+0x10], xmm15
00007b629add150e  movaps [rsp+0x20], xmm2
00007b629add1513  lea rdi, [rsp]
00007b629add1517  mov esi, 0x00
00007b629add151c  mov rax, 0x583FED93F530
00007b629add1526  call rax
00007b629add1528  movaps xmm1, [rsp]
00007b629add152c  add rsp, 0x30
00007b629add1530  vmovaps xmm0, [rsp]
00007b629add1535  vmovaps xmm2, [rsp+0x10]
00007b629add153b  vmovaps xmm3, [rsp+0x20]
00007b629add1541  vmovaps xmm4, [rsp+0x30]
00007b629add1547  vmovaps xmm5, [rsp+0x40]
00007b629add154d  vmovaps xmm6, [rsp+0x50]
00007b629add1553  vmovaps xmm7, [rsp+0x60]
00007b629add1559  vmovaps xmm8, [rsp+0x70]
00007b629add155f  vmovaps xmm9, [rsp+0x80]
00007b629add1568  vmovaps xmm10, [rsp+0x90]
00007b629add1571  vmovaps xmm11, [rsp+0xA0]
00007b629add157a  vmovaps xmm12, [rsp+0xB0]
00007b629add1583  vmovaps xmm13, [rsp+0xC0]
00007b629add158c  vmovaps xmm14, [rsp+0xD0]
00007b629add1595  vmovaps xmm15, [rsp+0xE0]
00007b629add159e  add rsp, 0xF0
00007b629add15a5  pop r11
00007b629add15a7  pop r10
00007b629add15a9  pop r9
00007b629add15ab  pop r8
00007b629add15ad  pop rsi
00007b629add15ae  pop rdi
00007b629add15af  pop rdx
00007b629add15b0  pop rcx
00007b629add15b1  pop rax
00007b629add15b2  add rsp, 0x08
00007b629add15b6  jmp 0x00007B629ADCF8AC
00007b629add15bb  sub rsp, 0x08
00007b629add15bf  push rax
00007b629add15c0  push rcx
00007b629add15c1  push rdx
00007b629add15c2  push rdi
00007b629add15c3  push rsi
00007b629add15c4  push r8
00007b629add15c6  push r9
00007b629add15c8  push r10
00007b629add15ca  push r11
00007b629add15cc  sub rsp, 0xF0
00007b629add15d3  vmovaps [rsp], xmm0
00007b629add15d8  vmovaps [rsp+0x10], xmm1
00007b629add15de  vmovaps [rsp+0x20], xmm2
00007b629add15e4  vmovaps [rsp+0x30], xmm3
00007b629add15ea  vmovaps [rsp+0x40], xmm4
00007b629add15f0  vmovaps [rsp+0x50], xmm5
00007b629add15f6  vmovaps [rsp+0x60], xmm6
00007b629add15fc  vmovaps [rsp+0x70], xmm7
00007b629add1602  vmovaps [rsp+0x80], xmm8
00007b629add160b  vmovaps [rsp+0x90], xmm9
00007b629add1614  vmovaps [rsp+0xA0], xmm10
00007b629add161d  vmovaps [rsp+0xB0], xmm11
00007b629add1626  vmovaps [rsp+0xC0], xmm12
00007b629add162f  vmovaps [rsp+0xD0], xmm13
00007b629add1638  vmovaps [rsp+0xE0], xmm15
00007b629add1641  sub rsp, 0x30
00007b629add1645  movaps [rsp], xmm14
00007b629add164a  movaps [rsp+0x10], xmm2
00007b629add164f  movaps [rsp+0x20], xmm15
00007b629add1655  lea rdi, [rsp]
00007b629add1659  mov esi, 0x00
00007b629add165e  mov rax, 0x583FED93F530
00007b629add1668  call rax
00007b629add166a  movaps xmm14, [rsp]
00007b629add166f  add rsp, 0x30
00007b629add1673  vmovaps xmm0, [rsp]
00007b629add1678  vmovaps xmm1, [rsp+0x10]
00007b629add167e  vmovaps xmm2, [rsp+0x20]
00007b629add1684  vmovaps xmm3, [rsp+0x30]
00007b629add168a  vmovaps xmm4, [rsp+0x40]
00007b629add1690  vmovaps xmm5, [rsp+0x50]
00007b629add1696  vmovaps xmm6, [rsp+0x60]
00007b629add169c  vmovaps xmm7, [rsp+0x70]
00007b629add16a2  vmovaps xmm8, [rsp+0x80]
00007b629add16ab  vmovaps xmm9, [rsp+0x90]
00007b629add16b4  vmovaps xmm10, [rsp+0xA0]
00007b629add16bd  vmovaps xmm11, [rsp+0xB0]
00007b629add16c6  vmovaps xmm12, [rsp+0xC0]
00007b629add16cf  vmovaps xmm13, [rsp+0xD0]
00007b629add16d8  vmovaps xmm15, [rsp+0xE0]
00007b629add16e1  add rsp, 0xF0
00007b629add16e8  pop r11
00007b629add16ea  pop r10
00007b629add16ec  pop r9
00007b629add16ee  pop r8
00007b629add16f0  pop rsi
00007b629add16f1  pop rdi
00007b629add16f2  pop rdx
00007b629add16f3  pop rcx
00007b629add16f4  pop rax
00007b629add16f5  add rsp, 0x08
00007b629add16f9  jmp 0x00007B629ADCF8E7
00007b629add16fe  sub rsp, 0x08
00007b629add1702  push rax
00007b629add1703  push rcx
00007b629add1704  push rdx
00007b629add1705  push rdi
00007b629add1706  push rsi
00007b629add1707  push r8
00007b629add1709  push r9
00007b629add170b  push r10
00007b629add170d  push r11
00007b629add170f  sub rsp, 0xF0
00007b629add1716  vmovaps [rsp], xmm0
00007b629add171b  vmovaps [rsp+0x10], xmm1
00007b629add1721  vmovaps [rsp+0x20], xmm2
00007b629add1727  vmovaps [rsp+0x30], xmm3
00007b629add172d  vmovaps [rsp+0x40], xmm4
00007b629add1733  vmovaps [rsp+0x50], xmm5
00007b629add1739  vmovaps [rsp+0x60], xmm6
00007b629add173f  vmovaps [rsp+0x70], xmm7
00007b629add1745  vmovaps [rsp+0x80], xmm8
00007b629add174e  vmovaps [rsp+0x90], xmm9
00007b629add1757  vmovaps [rsp+0xA0], xmm10
00007b629add1760  vmovaps [rsp+0xB0], xmm11
00007b629add1769  vmovaps [rsp+0xC0], xmm12
00007b629add1772  vmovaps [rsp+0xD0], xmm13
00007b629add177b  vmovaps [rsp+0xE0], xmm14
00007b629add1784  sub rsp, 0x30
00007b629add1788  movaps [rsp], xmm15
00007b629add178d  movaps [rsp+0x10], xmm2
00007b629add1792  movaps [rsp+0x20], xmm1
00007b629add1797  lea rdi, [rsp]
00007b629add179b  mov esi, 0x00
00007b629add17a0  mov rax, 0x583FED93F530
00007b629add17aa  call rax
00007b629add17ac  movaps xmm15, [rsp]
00007b629add17b1  add rsp, 0x30
00007b629add17b5  vmovaps xmm0, [rsp]
00007b629add17ba  vmovaps xmm1, [rsp+0x10]
00007b629add17c0  vmovaps xmm2, [rsp+0x20]
00007b629add17c6  vmovaps xmm3, [rsp+0x30]
00007b629add17cc  vmovaps xmm4, [rsp+0x40]
00007b629add17d2  vmovaps xmm5, [rsp+0x50]
00007b629add17d8  vmovaps xmm6, [rsp+0x60]
00007b629add17de  vmovaps xmm7, [rsp+0x70]
00007b629add17e4  vmovaps xmm8, [rsp+0x80]
00007b629add17ed  vmovaps xmm9, [rsp+0x90]
00007b629add17f6  vmovaps xmm10, [rsp+0xA0]
00007b629add17ff  vmovaps xmm11, [rsp+0xB0]
00007b629add1808  vmovaps xmm12, [rsp+0xC0]
00007b629add1811  vmovaps xmm13, [rsp+0xD0]
00007b629add181a  vmovaps xmm14, [rsp+0xE0]
00007b629add1823  add rsp, 0xF0
00007b629add182a  pop r11
00007b629add182c  pop r10
00007b629add182e  pop r9
00007b629add1830  pop r8
00007b629add1832  pop rsi
00007b629add1833  pop rdi
00007b629add1834  pop rdx
00007b629add1835  pop rcx
00007b629add1836  pop rax
00007b629add1837  add rsp, 0x08
00007b629add183b  jmp 0x00007B629ADCF923
00007b629add1840  call 0x00007B629ABFF430
00007b629add1845  jmp 0x00007B629ADCF930
00007b629add184a  sub rsp, 0x08
00007b629add184e  push rax
00007b629add184f  push rcx
00007b629add1850  push rdx
00007b629add1851  push rdi
00007b629add1852  push rsi
00007b629add1853  push r8
00007b629add1855  push r9
00007b629add1857  push r10
00007b629add1859  push r11
00007b629add185b  sub rsp, 0xF0
00007b629add1862  vmovaps [rsp], xmm0
00007b629add1867  vmovaps [rsp+0x10], xmm1
00007b629add186d  vmovaps [rsp+0x20], xmm3
00007b629add1873  vmovaps [rsp+0x30], xmm4
00007b629add1879  vmovaps [rsp+0x40], xmm5
00007b629add187f  vmovaps [rsp+0x50], xmm6
00007b629add1885  vmovaps [rsp+0x60], xmm7
00007b629add188b  vmovaps [rsp+0x70], xmm8
00007b629add1891  vmovaps [rsp+0x80], xmm9
00007b629add189a  vmovaps [rsp+0x90], xmm10
00007b629add18a3  vmovaps [rsp+0xA0], xmm11
00007b629add18ac  vmovaps [rsp+0xB0], xmm12
00007b629add18b5  vmovaps [rsp+0xC0], xmm13
00007b629add18be  vmovaps [rsp+0xD0], xmm14
00007b629add18c7  vmovaps [rsp+0xE0], xmm15
00007b629add18d0  sub rsp, 0x30
00007b629add18d4  movaps [rsp], xmm2
00007b629add18d8  movaps [rsp+0x10], xmm1
00007b629add18dd  movaps [rsp+0x20], xmm14
00007b629add18e3  lea rdi, [rsp]
00007b629add18e7  mov esi, 0x00
00007b629add18ec  mov rax, 0x583FED93F530
00007b629add18f6  call rax
00007b629add18f8  movaps xmm2, [rsp]
00007b629add18fc  add rsp, 0x30
00007b629add1900  vmovaps xmm0, [rsp]
00007b629add1905  vmovaps xmm1, [rsp+0x10]
00007b629add190b  vmovaps xmm3, [rsp+0x20]
00007b629add1911  vmovaps xmm4, [rsp+0x30]
00007b629add1917  vmovaps xmm5, [rsp+0x40]
00007b629add191d  vmovaps xmm6, [rsp+0x50]
00007b629add1923  vmovaps xmm7, [rsp+0x60]
00007b629add1929  vmovaps xmm8, [rsp+0x70]
00007b629add192f  vmovaps xmm9, [rsp+0x80]
00007b629add1938  vmovaps xmm10, [rsp+0x90]
00007b629add1941  vmovaps xmm11, [rsp+0xA0]
00007b629add194a  vmovaps xmm12, [rsp+0xB0]
00007b629add1953  vmovaps xmm13, [rsp+0xC0]
00007b629add195c  vmovaps xmm14, [rsp+0xD0]
00007b629add1965  vmovaps xmm15, [rsp+0xE0]
00007b629add196e  add rsp, 0xF0
00007b629add1975  pop r11
00007b629add1977  pop r10
00007b629add1979  pop r9
00007b629add197b  pop r8
00007b629add197d  pop rsi
00007b629add197e  pop rdi
00007b629add197f  pop rdx
00007b629add1980  pop rcx
00007b629add1981  pop rax
00007b629add1982  add rsp, 0x08
00007b629add1986  jmp 0x00007B629ADCF96D
00007b629add198b  sub rsp, 0x08
00007b629add198f  push rax
00007b629add1990  push rcx
00007b629add1991  push rdx
00007b629add1992  push rdi
00007b629add1993  push rsi
00007b629add1994  push r8
00007b629add1996  push r9
00007b629add1998  push r10
00007b629add199a  push r11
00007b629add199c  sub rsp, 0xF0
00007b629add19a3  vmovaps [rsp], xmm0
00007b629add19a8  vmovaps [rsp+0x10], xmm1
00007b629add19ae  vmovaps [rsp+0x20], xmm2
00007b629add19b4  vmovaps [rsp+0x30], xmm3
00007b629add19ba  vmovaps [rsp+0x40], xmm4
00007b629add19c0  vmovaps [rsp+0x50], xmm5
00007b629add19c6  vmovaps [rsp+0x60], xmm6
00007b629add19cc  vmovaps [rsp+0x70], xmm7
00007b629add19d2  vmovaps [rsp+0x80], xmm8
00007b629add19db  vmovaps [rsp+0x90], xmm9
00007b629add19e4  vmovaps [rsp+0xA0], xmm10
00007b629add19ed  vmovaps [rsp+0xB0], xmm11
00007b629add19f6  vmovaps [rsp+0xC0], xmm12
00007b629add19ff  vmovaps [rsp+0xD0], xmm13
00007b629add1a08  vmovaps [rsp+0xE0], xmm14
00007b629add1a11  sub rsp, 0x30
00007b629add1a15  movaps [rsp], xmm15
00007b629add1a1a  movaps [rsp+0x10], xmm14
00007b629add1a20  movaps [rsp+0x20], xmm1
00007b629add1a25  lea rdi, [rsp]
00007b629add1a29  mov esi, 0x00
00007b629add1a2e  mov rax, 0x583FED93F530
00007b629add1a38  call rax
00007b629add1a3a  movaps xmm15, [rsp]
00007b629add1a3f  add rsp, 0x30
00007b629add1a43  vmovaps xmm0, [rsp]
00007b629add1a48  vmovaps xmm1, [rsp+0x10]
00007b629add1a4e  vmovaps xmm2, [rsp+0x20]
00007b629add1a54  vmovaps xmm3, [rsp+0x30]
00007b629add1a5a  vmovaps xmm4, [rsp+0x40]
00007b629add1a60  vmovaps xmm5, [rsp+0x50]
00007b629add1a66  vmovaps xmm6, [rsp+0x60]
00007b629add1a6c  vmovaps xmm7, [rsp+0x70]
00007b629add1a72  vmovaps xmm8, [rsp+0x80]
00007b629add1a7b  vmovaps xmm9, [rsp+0x90]
00007b629add1a84  vmovaps xmm10, [rsp+0xA0]
00007b629add1a8d  vmovaps xmm11, [rsp+0xB0]
00007b629add1a96  vmovaps xmm12, [rsp+0xC0]
00007b629add1a9f  vmovaps xmm13, [rsp+0xD0]
00007b629add1aa8  vmovaps xmm14, [rsp+0xE0]
00007b629add1ab1  add rsp, 0xF0
00007b629add1ab8  pop r11
00007b629add1aba  pop r10
00007b629add1abc  pop r9
00007b629add1abe  pop r8
00007b629add1ac0  pop rsi
00007b629add1ac1  pop rdi
00007b629add1ac2  pop rdx
00007b629add1ac3  pop rcx
00007b629add1ac4  pop rax
00007b629add1ac5  add rsp, 0x08
00007b629add1ac9  jmp 0x00007B629ADCF9E7
00007b629add1ace  call 0x00007B629ABFF430
00007b629add1ad3  jmp 0x00007B629ADCF9F4
00007b629add1ad8  sub rsp, 0x08
00007b629add1adc  push rax
00007b629add1add  push rcx
00007b629add1ade  push rdx
00007b629add1adf  push rdi
00007b629add1ae0  push rsi
00007b629add1ae1  push r8
00007b629add1ae3  push r9
00007b629add1ae5  push r10
00007b629add1ae7  push r11
00007b629add1ae9  sub rsp, 0xF0
00007b629add1af0  vmovaps [rsp], xmm0
00007b629add1af5  vmovaps [rsp+0x10], xmm1
00007b629add1afb  vmovaps [rsp+0x20], xmm2
00007b629add1b01  vmovaps [rsp+0x30], xmm3
00007b629add1b07  vmovaps [rsp+0x40], xmm4
00007b629add1b0d  vmovaps [rsp+0x50], xmm5
00007b629add1b13  vmovaps [rsp+0x60], xmm6
00007b629add1b19  vmovaps [rsp+0x70], xmm7
00007b629add1b1f  vmovaps [rsp+0x80], xmm8
00007b629add1b28  vmovaps [rsp+0x90], xmm9
00007b629add1b31  vmovaps [rsp+0xA0], xmm10
00007b629add1b3a  vmovaps [rsp+0xB0], xmm11
00007b629add1b43  vmovaps [rsp+0xC0], xmm12
00007b629add1b4c  vmovaps [rsp+0xD0], xmm13
00007b629add1b55  vmovaps [rsp+0xE0], xmm15
00007b629add1b5e  sub rsp, 0x30
00007b629add1b62  movaps [rsp], xmm14
00007b629add1b67  movaps [rsp+0x10], xmm13
00007b629add1b6d  movaps [rsp+0x20], xmm1
00007b629add1b72  lea rdi, [rsp]
00007b629add1b76  mov esi, 0x00
00007b629add1b7b  mov rax, 0x583FED93F530
00007b629add1b85  call rax
00007b629add1b87  movaps xmm14, [rsp]
00007b629add1b8c  add rsp, 0x30
00007b629add1b90  vmovaps xmm0, [rsp]
00007b629add1b95  vmovaps xmm1, [rsp+0x10]
00007b629add1b9b  vmovaps xmm2, [rsp+0x20]
00007b629add1ba1  vmovaps xmm3, [rsp+0x30]
00007b629add1ba7  vmovaps xmm4, [rsp+0x40]
00007b629add1bad  vmovaps xmm5, [rsp+0x50]
00007b629add1bb3  vmovaps xmm6, [rsp+0x60]
00007b629add1bb9  vmovaps xmm7, [rsp+0x70]
00007b629add1bbf  vmovaps xmm8, [rsp+0x80]
00007b629add1bc8  vmovaps xmm9, [rsp+0x90]
00007b629add1bd1  vmovaps xmm10, [rsp+0xA0]
00007b629add1bda  vmovaps xmm11, [rsp+0xB0]
00007b629add1be3  vmovaps xmm12, [rsp+0xC0]
00007b629add1bec  vmovaps xmm13, [rsp+0xD0]
00007b629add1bf5  vmovaps xmm15, [rsp+0xE0]
00007b629add1bfe  add rsp, 0xF0
00007b629add1c05  pop r11
00007b629add1c07  pop r10
00007b629add1c09  pop r9
00007b629add1c0b  pop r8
00007b629add1c0d  pop rsi
00007b629add1c0e  pop rdi
00007b629add1c0f  pop rdx
00007b629add1c10  pop rcx
00007b629add1c11  pop rax
00007b629add1c12  add rsp, 0x08
00007b629add1c16  jmp 0x00007B629ADCFAAF
00007b629add1c1b  sub rsp, 0x08
00007b629add1c1f  push rax
00007b629add1c20  push rcx
00007b629add1c21  push rdx
00007b629add1c22  push rdi
00007b629add1c23  push rsi
00007b629add1c24  push r8
00007b629add1c26  push r9
00007b629add1c28  push r10
00007b629add1c2a  push r11
00007b629add1c2c  sub rsp, 0xF0
00007b629add1c33  vmovaps [rsp], xmm0
00007b629add1c38  vmovaps [rsp+0x10], xmm1
00007b629add1c3e  vmovaps [rsp+0x20], xmm2
00007b629add1c44  vmovaps [rsp+0x30], xmm3
00007b629add1c4a  vmovaps [rsp+0x40], xmm4
00007b629add1c50  vmovaps [rsp+0x50], xmm5
00007b629add1c56  vmovaps [rsp+0x60], xmm6
00007b629add1c5c  vmovaps [rsp+0x70], xmm7
00007b629add1c62  vmovaps [rsp+0x80], xmm8
00007b629add1c6b  vmovaps [rsp+0x90], xmm9
00007b629add1c74  vmovaps [rsp+0xA0], xmm10
00007b629add1c7d  vmovaps [rsp+0xB0], xmm11
00007b629add1c86  vmovaps [rsp+0xC0], xmm12
00007b629add1c8f  vmovaps [rsp+0xD0], xmm13
00007b629add1c98  vmovaps [rsp+0xE0], xmm14
00007b629add1ca1  sub rsp, 0x30
00007b629add1ca5  movaps [rsp], xmm15
00007b629add1caa  movaps [rsp+0x10], xmm13
00007b629add1cb0  movaps [rsp+0x20], xmm1
00007b629add1cb5  lea rdi, [rsp]
00007b629add1cb9  mov esi, 0x00
00007b629add1cbe  mov rax, 0x583FED93F530
00007b629add1cc8  call rax
00007b629add1cca  movaps xmm15, [rsp]
00007b629add1ccf  add rsp, 0x30
00007b629add1cd3  vmovaps xmm0, [rsp]
00007b629add1cd8  vmovaps xmm1, [rsp+0x10]
00007b629add1cde  vmovaps xmm2, [rsp+0x20]
00007b629add1ce4  vmovaps xmm3, [rsp+0x30]
00007b629add1cea  vmovaps xmm4, [rsp+0x40]
00007b629add1cf0  vmovaps xmm5, [rsp+0x50]
00007b629add1cf6  vmovaps xmm6, [rsp+0x60]
00007b629add1cfc  vmovaps xmm7, [rsp+0x70]
00007b629add1d02  vmovaps xmm8, [rsp+0x80]
00007b629add1d0b  vmovaps xmm9, [rsp+0x90]
00007b629add1d14  vmovaps xmm10, [rsp+0xA0]
00007b629add1d1d  vmovaps xmm11, [rsp+0xB0]
00007b629add1d26  vmovaps xmm12, [rsp+0xC0]
00007b629add1d2f  vmovaps xmm13, [rsp+0xD0]
00007b629add1d38  vmovaps xmm14, [rsp+0xE0]
00007b629add1d41  add rsp, 0xF0
00007b629add1d48  pop r11
00007b629add1d4a  pop r10
00007b629add1d4c  pop r9
00007b629add1d4e  pop r8
00007b629add1d50  pop rsi
00007b629add1d51  pop rdi
00007b629add1d52  pop rdx
00007b629add1d53  pop rcx
00007b629add1d54  pop rax
00007b629add1d55  add rsp, 0x08
00007b629add1d59  jmp 0x00007B629ADCFAEB
00007b629add1d5e  call 0x00007B629ABFF430
00007b629add1d63  jmp 0x00007B629ADCFAF8
00007b629add1d68  sub rsp, 0x08
00007b629add1d6c  push rax
00007b629add1d6d  push rcx
00007b629add1d6e  push rdx
00007b629add1d6f  push rdi
00007b629add1d70  push rsi
00007b629add1d71  push r8
00007b629add1d73  push r9
00007b629add1d75  push r10
00007b629add1d77  push r11
00007b629add1d79  sub rsp, 0xF0
00007b629add1d80  vmovaps [rsp], xmm0
00007b629add1d85  vmovaps [rsp+0x10], xmm1
00007b629add1d8b  vmovaps [rsp+0x20], xmm2
00007b629add1d91  vmovaps [rsp+0x30], xmm3
00007b629add1d97  vmovaps [rsp+0x40], xmm4
00007b629add1d9d  vmovaps [rsp+0x50], xmm5
00007b629add1da3  vmovaps [rsp+0x60], xmm6
00007b629add1da9  vmovaps [rsp+0x70], xmm7
00007b629add1daf  vmovaps [rsp+0x80], xmm8
00007b629add1db8  vmovaps [rsp+0x90], xmm9
00007b629add1dc1  vmovaps [rsp+0xA0], xmm10
00007b629add1dca  vmovaps [rsp+0xB0], xmm11
00007b629add1dd3  vmovaps [rsp+0xC0], xmm12
00007b629add1ddc  vmovaps [rsp+0xD0], xmm13
00007b629add1de5  vmovaps [rsp+0xE0], xmm15
00007b629add1dee  sub rsp, 0x30
00007b629add1df2  movaps [rsp], xmm14
00007b629add1df7  movaps [rsp+0x10], xmm13
00007b629add1dfd  movaps [rsp+0x20], xmm2
00007b629add1e02  lea rdi, [rsp]
00007b629add1e06  mov esi, 0x00
00007b629add1e0b  mov rax, 0x583FED93F530
00007b629add1e15  call rax
00007b629add1e17  movaps xmm14, [rsp]
00007b629add1e1c  add rsp, 0x30
00007b629add1e20  vmovaps xmm0, [rsp]
00007b629add1e25  vmovaps xmm1, [rsp+0x10]
00007b629add1e2b  vmovaps xmm2, [rsp+0x20]
00007b629add1e31  vmovaps xmm3, [rsp+0x30]
00007b629add1e37  vmovaps xmm4, [rsp+0x40]
00007b629add1e3d  vmovaps xmm5, [rsp+0x50]
00007b629add1e43  vmovaps xmm6, [rsp+0x60]
00007b629add1e49  vmovaps xmm7, [rsp+0x70]
00007b629add1e4f  vmovaps xmm8, [rsp+0x80]
00007b629add1e58  vmovaps xmm9, [rsp+0x90]
00007b629add1e61  vmovaps xmm10, [rsp+0xA0]
00007b629add1e6a  vmovaps xmm11, [rsp+0xB0]
00007b629add1e73  vmovaps xmm12, [rsp+0xC0]
00007b629add1e7c  vmovaps xmm13, [rsp+0xD0]
00007b629add1e85  vmovaps xmm15, [rsp+0xE0]
00007b629add1e8e  add rsp, 0xF0
00007b629add1e95  pop r11
00007b629add1e97  pop r10
00007b629add1e99  pop r9
00007b629add1e9b  pop r8
00007b629add1e9d  pop rsi
00007b629add1e9e  pop rdi
00007b629add1e9f  pop rdx
00007b629add1ea0  pop rcx
00007b629add1ea1  pop rax
00007b629add1ea2  add rsp, 0x08
00007b629add1ea6  jmp 0x00007B629ADCFB24
00007b629add1eab  sub rsp, 0x08
00007b629add1eaf  push rax
00007b629add1eb0  push rcx
00007b629add1eb1  push rdx
00007b629add1eb2  push rdi
00007b629add1eb3  push rsi
00007b629add1eb4  push r8
00007b629add1eb6  push r9
00007b629add1eb8  push r10
00007b629add1eba  push r11
00007b629add1ebc  sub rsp, 0xF0
00007b629add1ec3  vmovaps [rsp], xmm0
00007b629add1ec8  vmovaps [rsp+0x10], xmm2
00007b629add1ece  vmovaps [rsp+0x20], xmm3
00007b629add1ed4  vmovaps [rsp+0x30], xmm4
00007b629add1eda  vmovaps [rsp+0x40], xmm5
00007b629add1ee0  vmovaps [rsp+0x50], xmm6
00007b629add1ee6  vmovaps [rsp+0x60], xmm7
00007b629add1eec  vmovaps [rsp+0x70], xmm8
00007b629add1ef2  vmovaps [rsp+0x80], xmm9
00007b629add1efb  vmovaps [rsp+0x90], xmm10
00007b629add1f04  vmovaps [rsp+0xA0], xmm11
00007b629add1f0d  vmovaps [rsp+0xB0], xmm12
00007b629add1f16  vmovaps [rsp+0xC0], xmm13
00007b629add1f1f  vmovaps [rsp+0xD0], xmm14
00007b629add1f28  vmovaps [rsp+0xE0], xmm15
00007b629add1f31  sub rsp, 0x30
00007b629add1f35  movaps [rsp], xmm1
00007b629add1f39  movaps [rsp+0x10], xmm13
00007b629add1f3f  movaps [rsp+0x20], xmm2
00007b629add1f44  lea rdi, [rsp]
00007b629add1f48  mov esi, 0x00
00007b629add1f4d  mov rax, 0x583FED93F530
00007b629add1f57  call rax
00007b629add1f59  movaps xmm1, [rsp]
00007b629add1f5d  add rsp, 0x30
00007b629add1f61  vmovaps xmm0, [rsp]
00007b629add1f66  vmovaps xmm2, [rsp+0x10]
00007b629add1f6c  vmovaps xmm3, [rsp+0x20]
00007b629add1f72  vmovaps xmm4, [rsp+0x30]
00007b629add1f78  vmovaps xmm5, [rsp+0x40]
00007b629add1f7e  vmovaps xmm6, [rsp+0x50]
00007b629add1f84  vmovaps xmm7, [rsp+0x60]
00007b629add1f8a  vmovaps xmm8, [rsp+0x70]
00007b629add1f90  vmovaps xmm9, [rsp+0x80]
00007b629add1f99  vmovaps xmm10, [rsp+0x90]
00007b629add1fa2  vmovaps xmm11, [rsp+0xA0]
00007b629add1fab  vmovaps xmm12, [rsp+0xB0]
00007b629add1fb4  vmovaps xmm13, [rsp+0xC0]
00007b629add1fbd  vmovaps xmm14, [rsp+0xD0]
00007b629add1fc6  vmovaps xmm15, [rsp+0xE0]
00007b629add1fcf  add rsp, 0xF0
00007b629add1fd6  pop r11
00007b629add1fd8  pop r10
00007b629add1fda  pop r9
00007b629add1fdc  pop r8
00007b629add1fde  pop rsi
00007b629add1fdf  pop rdi
00007b629add1fe0  pop rdx
00007b629add1fe1  pop rcx
00007b629add1fe2  pop rax
00007b629add1fe3  add rsp, 0x08
00007b629add1fe7  jmp 0x00007B629ADCFB52
00007b629add1fec  sub rsp, 0x08
00007b629add1ff0  push rax
00007b629add1ff1  push rcx
00007b629add1ff2  push rdx
00007b629add1ff3  push rdi
00007b629add1ff4  push rsi
00007b629add1ff5  push r8
00007b629add1ff7  push r9
00007b629add1ff9  push r10
00007b629add1ffb  push r11
00007b629add1ffd  sub rsp, 0xF0
00007b629add2004  vmovaps [rsp], xmm0
00007b629add2009  vmovaps [rsp+0x10], xmm1
00007b629add200f  vmovaps [rsp+0x20], xmm3
00007b629add2015  vmovaps [rsp+0x30], xmm4
00007b629add201b  vmovaps [rsp+0x40], xmm5
00007b629add2021  vmovaps [rsp+0x50], xmm6
00007b629add2027  vmovaps [rsp+0x60], xmm7
00007b629add202d  vmovaps [rsp+0x70], xmm8
00007b629add2033  vmovaps [rsp+0x80], xmm9
00007b629add203c  vmovaps [rsp+0x90], xmm10
00007b629add2045  vmovaps [rsp+0xA0], xmm11
00007b629add204e  vmovaps [rsp+0xB0], xmm12
00007b629add2057  vmovaps [rsp+0xC0], xmm13
00007b629add2060  vmovaps [rsp+0xD0], xmm14
00007b629add2069  vmovaps [rsp+0xE0], xmm15
00007b629add2072  sub rsp, 0x30
00007b629add2076  movaps [rsp], xmm2
00007b629add207a  movaps [rsp+0x10], xmm1
00007b629add207f  movaps [rsp+0x20], xmm13
00007b629add2085  lea rdi, [rsp]
00007b629add2089  mov esi, 0x00
00007b629add208e  mov rax, 0x583FED93F530
00007b629add2098  call rax
00007b629add209a  movaps xmm2, [rsp]
00007b629add209e  add rsp, 0x30
00007b629add20a2  vmovaps xmm0, [rsp]
00007b629add20a7  vmovaps xmm1, [rsp+0x10]
00007b629add20ad  vmovaps xmm3, [rsp+0x20]
00007b629add20b3  vmovaps xmm4, [rsp+0x30]
00007b629add20b9  vmovaps xmm5, [rsp+0x40]
00007b629add20bf  vmovaps xmm6, [rsp+0x50]
00007b629add20c5  vmovaps xmm7, [rsp+0x60]
00007b629add20cb  vmovaps xmm8, [rsp+0x70]
00007b629add20d1  vmovaps xmm9, [rsp+0x80]
00007b629add20da  vmovaps xmm10, [rsp+0x90]
00007b629add20e3  vmovaps xmm11, [rsp+0xA0]
00007b629add20ec  vmovaps xmm12, [rsp+0xB0]
00007b629add20f5  vmovaps xmm13, [rsp+0xC0]
00007b629add20fe  vmovaps xmm14, [rsp+0xD0]
00007b629add2107  vmovaps xmm15, [rsp+0xE0]
00007b629add2110  add rsp, 0xF0
00007b629add2117  pop r11
00007b629add2119  pop r10
00007b629add211b  pop r9
00007b629add211d  pop r8
00007b629add211f  pop rsi
00007b629add2120  pop rdi
00007b629add2121  pop rdx
00007b629add2122  pop rcx
00007b629add2123  pop rax
00007b629add2124  add rsp, 0x08
00007b629add2128  jmp 0x00007B629ADCFBAB
00007b629add212d  call 0x00007B629ABFF430
00007b629add2132  jmp 0x00007B629ADCFBB8
00007b629add2137  sub rsp, 0x08
00007b629add213b  push rax
00007b629add213c  push rcx
00007b629add213d  push rdx
00007b629add213e  push rdi
00007b629add213f  push rsi
00007b629add2140  push r8
00007b629add2142  push r9
00007b629add2144  push r10
00007b629add2146  push r11
00007b629add2148  sub rsp, 0xF0
00007b629add214f  vmovaps [rsp], xmm0
00007b629add2154  vmovaps [rsp+0x10], xmm1
00007b629add215a  vmovaps [rsp+0x20], xmm2
00007b629add2160  vmovaps [rsp+0x30], xmm3
00007b629add2166  vmovaps [rsp+0x40], xmm4
00007b629add216c  vmovaps [rsp+0x50], xmm5
00007b629add2172  vmovaps [rsp+0x60], xmm6
00007b629add2178  vmovaps [rsp+0x70], xmm7
00007b629add217e  vmovaps [rsp+0x80], xmm8
00007b629add2187  vmovaps [rsp+0x90], xmm9
00007b629add2190  vmovaps [rsp+0xA0], xmm10
00007b629add2199  vmovaps [rsp+0xB0], xmm11
00007b629add21a2  vmovaps [rsp+0xC0], xmm12
00007b629add21ab  vmovaps [rsp+0xD0], xmm13
00007b629add21b4  vmovaps [rsp+0xE0], xmm14
00007b629add21bd  sub rsp, 0x30
00007b629add21c1  movaps [rsp], xmm15
00007b629add21c6  movaps [rsp+0x10], xmm13
00007b629add21cc  movaps [rsp+0x20], xmm1
00007b629add21d1  lea rdi, [rsp]
00007b629add21d5  mov esi, 0x00
00007b629add21da  mov rax, 0x583FED93F530
00007b629add21e4  call rax
00007b629add21e6  movaps xmm15, [rsp]
00007b629add21eb  add rsp, 0x30
00007b629add21ef  vmovaps xmm0, [rsp]
00007b629add21f4  vmovaps xmm1, [rsp+0x10]
00007b629add21fa  vmovaps xmm2, [rsp+0x20]
00007b629add2200  vmovaps xmm3, [rsp+0x30]
00007b629add2206  vmovaps xmm4, [rsp+0x40]
00007b629add220c  vmovaps xmm5, [rsp+0x50]
00007b629add2212  vmovaps xmm6, [rsp+0x60]
00007b629add2218  vmovaps xmm7, [rsp+0x70]
00007b629add221e  vmovaps xmm8, [rsp+0x80]
00007b629add2227  vmovaps xmm9, [rsp+0x90]
00007b629add2230  vmovaps xmm10, [rsp+0xA0]
00007b629add2239  vmovaps xmm11, [rsp+0xB0]
00007b629add2242  vmovaps xmm12, [rsp+0xC0]
00007b629add224b  vmovaps xmm13, [rsp+0xD0]
00007b629add2254  vmovaps xmm14, [rsp+0xE0]
00007b629add225d  add rsp, 0xF0
00007b629add2264  pop r11
00007b629add2266  pop r10
00007b629add2268  pop r9
00007b629add226a  pop r8
00007b629add226c  pop rsi
00007b629add226d  pop rdi
00007b629add226e  pop rdx
00007b629add226f  pop rcx
00007b629add2270  pop rax
00007b629add2271  add rsp, 0x08
00007b629add2275  jmp 0x00007B629ADCFBF7
00007b629add227a  sub rsp, 0x08
00007b629add227e  push rax
00007b629add227f  push rcx
00007b629add2280  push rdx
00007b629add2281  push rdi
00007b629add2282  push rsi
00007b629add2283  push r8
00007b629add2285  push r9
00007b629add2287  push r10
00007b629add2289  push r11
00007b629add228b  sub rsp, 0xF0
00007b629add2292  vmovaps [rsp], xmm0
00007b629add2297  vmovaps [rsp+0x10], xmm1
00007b629add229d  vmovaps [rsp+0x20], xmm2
00007b629add22a3  vmovaps [rsp+0x30], xmm3
00007b629add22a9  vmovaps [rsp+0x40], xmm4
00007b629add22af  vmovaps [rsp+0x50], xmm5
00007b629add22b5  vmovaps [rsp+0x60], xmm6
00007b629add22bb  vmovaps [rsp+0x70], xmm7
00007b629add22c1  vmovaps [rsp+0x80], xmm8
00007b629add22ca  vmovaps [rsp+0x90], xmm9
00007b629add22d3  vmovaps [rsp+0xA0], xmm10
00007b629add22dc  vmovaps [rsp+0xB0], xmm11
00007b629add22e5  vmovaps [rsp+0xC0], xmm12
00007b629add22ee  vmovaps [rsp+0xD0], xmm13
00007b629add22f7  vmovaps [rsp+0xE0], xmm15
00007b629add2300  sub rsp, 0x30
00007b629add2304  movaps [rsp], xmm14
00007b629add2309  movaps [rsp+0x10], xmm11
00007b629add230f  movaps [rsp+0x20], xmm1
00007b629add2314  lea rdi, [rsp]
00007b629add2318  mov esi, 0x00
00007b629add231d  mov rax, 0x583FED93F530
00007b629add2327  call rax
00007b629add2329  movaps xmm14, [rsp]
00007b629add232e  add rsp, 0x30
00007b629add2332  vmovaps xmm0, [rsp]
00007b629add2337  vmovaps xmm1, [rsp+0x10]
00007b629add233d  vmovaps xmm2, [rsp+0x20]
00007b629add2343  vmovaps xmm3, [rsp+0x30]
00007b629add2349  vmovaps xmm4, [rsp+0x40]
00007b629add234f  vmovaps xmm5, [rsp+0x50]
00007b629add2355  vmovaps xmm6, [rsp+0x60]
00007b629add235b  vmovaps xmm7, [rsp+0x70]
00007b629add2361  vmovaps xmm8, [rsp+0x80]
00007b629add236a  vmovaps xmm9, [rsp+0x90]
00007b629add2373  vmovaps xmm10, [rsp+0xA0]
00007b629add237c  vmovaps xmm11, [rsp+0xB0]
00007b629add2385  vmovaps xmm12, [rsp+0xC0]
00007b629add238e  vmovaps xmm13, [rsp+0xD0]
00007b629add2397  vmovaps xmm15, [rsp+0xE0]
00007b629add23a0  add rsp, 0xF0
00007b629add23a7  pop r11
00007b629add23a9  pop r10
00007b629add23ab  pop r9
00007b629add23ad  pop r8
00007b629add23af  pop rsi
00007b629add23b0  pop rdi
00007b629add23b1  pop rdx
00007b629add23b2  pop rcx
00007b629add23b3  pop rax
00007b629add23b4  add rsp, 0x08
00007b629add23b8  jmp 0x00007B629ADCFC21
00007b629add23bd  sub rsp, 0x08
00007b629add23c1  push rax
00007b629add23c2  push rcx
00007b629add23c3  push rdx
00007b629add23c4  push rdi
00007b629add23c5  push rsi
00007b629add23c6  push r8
00007b629add23c8  push r9
00007b629add23ca  push r10
00007b629add23cc  push r11
00007b629add23ce  sub rsp, 0xF0
00007b629add23d5  vmovaps [rsp], xmm0
00007b629add23da  vmovaps [rsp+0x10], xmm1
00007b629add23e0  vmovaps [rsp+0x20], xmm2
00007b629add23e6  vmovaps [rsp+0x30], xmm3
00007b629add23ec  vmovaps [rsp+0x40], xmm4
00007b629add23f2  vmovaps [rsp+0x50], xmm5
00007b629add23f8  vmovaps [rsp+0x60], xmm6
00007b629add23fe  vmovaps [rsp+0x70], xmm7
00007b629add2404  vmovaps [rsp+0x80], xmm8
00007b629add240d  vmovaps [rsp+0x90], xmm9
00007b629add2416  vmovaps [rsp+0xA0], xmm10
00007b629add241f  vmovaps [rsp+0xB0], xmm11
00007b629add2428  vmovaps [rsp+0xC0], xmm12
00007b629add2431  vmovaps [rsp+0xD0], xmm14
00007b629add243a  vmovaps [rsp+0xE0], xmm15
00007b629add2443  sub rsp, 0x30
00007b629add2447  movaps [rsp], xmm13
00007b629add244c  movaps [rsp+0x10], xmm11
00007b629add2452  movaps [rsp+0x20], xmm1
00007b629add2457  lea rdi, [rsp]
00007b629add245b  mov esi, 0x00
00007b629add2460  mov rax, 0x583FED93F530
00007b629add246a  call rax
00007b629add246c  movaps xmm13, [rsp]
00007b629add2471  add rsp, 0x30
00007b629add2475  vmovaps xmm0, [rsp]
00007b629add247a  vmovaps xmm1, [rsp+0x10]
00007b629add2480  vmovaps xmm2, [rsp+0x20]
00007b629add2486  vmovaps xmm3, [rsp+0x30]
00007b629add248c  vmovaps xmm4, [rsp+0x40]
00007b629add2492  vmovaps xmm5, [rsp+0x50]
00007b629add2498  vmovaps xmm6, [rsp+0x60]
00007b629add249e  vmovaps xmm7, [rsp+0x70]
00007b629add24a4  vmovaps xmm8, [rsp+0x80]
00007b629add24ad  vmovaps xmm9, [rsp+0x90]
00007b629add24b6  vmovaps xmm10, [rsp+0xA0]
00007b629add24bf  vmovaps xmm11, [rsp+0xB0]
00007b629add24c8  vmovaps xmm12, [rsp+0xC0]
00007b629add24d1  vmovaps xmm14, [rsp+0xD0]
00007b629add24da  vmovaps xmm15, [rsp+0xE0]
00007b629add24e3  add rsp, 0xF0
00007b629add24ea  pop r11
00007b629add24ec  pop r10
00007b629add24ee  pop r9
00007b629add24f0  pop r8
00007b629add24f2  pop rsi
00007b629add24f3  pop rdi
00007b629add24f4  pop rdx
00007b629add24f5  pop rcx
00007b629add24f6  pop rax
00007b629add24f7  add rsp, 0x08
00007b629add24fb  jmp 0x00007B629ADCFC76
00007b629add2500  call 0x00007B629ABFF430
00007b629add2505  jmp 0x00007B629ADCFC83
00007b629add250a  sub rsp, 0x08
00007b629add250e  push rax
00007b629add250f  push rcx
00007b629add2510  push rdx
00007b629add2511  push rdi
00007b629add2512  push rsi
00007b629add2513  push r8
00007b629add2515  push r9
00007b629add2517  push r10
00007b629add2519  push r11
00007b629add251b  sub rsp, 0xF0
00007b629add2522  vmovaps [rsp], xmm0
00007b629add2527  vmovaps [rsp+0x10], xmm1
00007b629add252d  vmovaps [rsp+0x20], xmm2
00007b629add2533  vmovaps [rsp+0x30], xmm3
00007b629add2539  vmovaps [rsp+0x40], xmm4
00007b629add253f  vmovaps [rsp+0x50], xmm5
00007b629add2545  vmovaps [rsp+0x60], xmm6
00007b629add254b  vmovaps [rsp+0x70], xmm7
00007b629add2551  vmovaps [rsp+0x80], xmm8
00007b629add255a  vmovaps [rsp+0x90], xmm9
00007b629add2563  vmovaps [rsp+0xA0], xmm10
00007b629add256c  vmovaps [rsp+0xB0], xmm11
00007b629add2575  vmovaps [rsp+0xC0], xmm12
00007b629add257e  vmovaps [rsp+0xD0], xmm13
00007b629add2587  vmovaps [rsp+0xE0], xmm14
00007b629add2590  sub rsp, 0x30
00007b629add2594  movaps [rsp], xmm15
00007b629add2599  movaps [rsp+0x10], xmm11
00007b629add259f  movaps [rsp+0x20], xmm1
00007b629add25a4  lea rdi, [rsp]
00007b629add25a8  mov esi, 0x00
00007b629add25ad  mov rax, 0x583FED93F530
00007b629add25b7  call rax
00007b629add25b9  movaps xmm15, [rsp]
00007b629add25be  add rsp, 0x30
00007b629add25c2  vmovaps xmm0, [rsp]
00007b629add25c7  vmovaps xmm1, [rsp+0x10]
00007b629add25cd  vmovaps xmm2, [rsp+0x20]
00007b629add25d3  vmovaps xmm3, [rsp+0x30]
00007b629add25d9  vmovaps xmm4, [rsp+0x40]
00007b629add25df  vmovaps xmm5, [rsp+0x50]
00007b629add25e5  vmovaps xmm6, [rsp+0x60]
00007b629add25eb  vmovaps xmm7, [rsp+0x70]
00007b629add25f1  vmovaps xmm8, [rsp+0x80]
00007b629add25fa  vmovaps xmm9, [rsp+0x90]
00007b629add2603  vmovaps xmm10, [rsp+0xA0]
00007b629add260c  vmovaps xmm11, [rsp+0xB0]
00007b629add2615  vmovaps xmm12, [rsp+0xC0]
00007b629add261e  vmovaps xmm13, [rsp+0xD0]
00007b629add2627  vmovaps xmm14, [rsp+0xE0]
00007b629add2630  add rsp, 0xF0
00007b629add2637  pop r11
00007b629add2639  pop r10
00007b629add263b  pop r9
00007b629add263d  pop r8
00007b629add263f  pop rsi
00007b629add2640  pop rdi
00007b629add2641  pop rdx
00007b629add2642  pop rcx
00007b629add2643  pop rax
00007b629add2644  add rsp, 0x08
00007b629add2648  jmp 0x00007B629ADCFCBC
00007b629add264d  sub rsp, 0x08
00007b629add2651  push rax
00007b629add2652  push rcx
00007b629add2653  push rdx
00007b629add2654  push rdi
00007b629add2655  push rsi
00007b629add2656  push r8
00007b629add2658  push r9
00007b629add265a  push r10
00007b629add265c  push r11
00007b629add265e  sub rsp, 0xF0
00007b629add2665  vmovaps [rsp], xmm0
00007b629add266a  vmovaps [rsp+0x10], xmm1
00007b629add2670  vmovaps [rsp+0x20], xmm2
00007b629add2676  vmovaps [rsp+0x30], xmm3
00007b629add267c  vmovaps [rsp+0x40], xmm4
00007b629add2682  vmovaps [rsp+0x50], xmm5
00007b629add2688  vmovaps [rsp+0x60], xmm6
00007b629add268e  vmovaps [rsp+0x70], xmm7
00007b629add2694  vmovaps [rsp+0x80], xmm8
00007b629add269d  vmovaps [rsp+0x90], xmm9
00007b629add26a6  vmovaps [rsp+0xA0], xmm10
00007b629add26af  vmovaps [rsp+0xB0], xmm12
00007b629add26b8  vmovaps [rsp+0xC0], xmm13
00007b629add26c1  vmovaps [rsp+0xD0], xmm14
00007b629add26ca  vmovaps [rsp+0xE0], xmm15
00007b629add26d3  sub rsp, 0x30
00007b629add26d7  movaps [rsp], xmm11
00007b629add26dc  movaps [rsp+0x10], xmm6
00007b629add26e1  movaps [rsp+0x20], xmm14
00007b629add26e7  lea rdi, [rsp]
00007b629add26eb  mov esi, 0x00
00007b629add26f0  mov rax, 0x583FED93F530
00007b629add26fa  call rax
00007b629add26fc  movaps xmm11, [rsp]
00007b629add2701  add rsp, 0x30
00007b629add2705  vmovaps xmm0, [rsp]
00007b629add270a  vmovaps xmm1, [rsp+0x10]
00007b629add2710  vmovaps xmm2, [rsp+0x20]
00007b629add2716  vmovaps xmm3, [rsp+0x30]
00007b629add271c  vmovaps xmm4, [rsp+0x40]
00007b629add2722  vmovaps xmm5, [rsp+0x50]
00007b629add2728  vmovaps xmm6, [rsp+0x60]
00007b629add272e  vmovaps xmm7, [rsp+0x70]
00007b629add2734  vmovaps xmm8, [rsp+0x80]
00007b629add273d  vmovaps xmm9, [rsp+0x90]
00007b629add2746  vmovaps xmm10, [rsp+0xA0]
00007b629add274f  vmovaps xmm12, [rsp+0xB0]
00007b629add2758  vmovaps xmm13, [rsp+0xC0]
00007b629add2761  vmovaps xmm14, [rsp+0xD0]
00007b629add276a  vmovaps xmm15, [rsp+0xE0]
00007b629add2773  add rsp, 0xF0
00007b629add277a  pop r11
00007b629add277c  pop r10
00007b629add277e  pop r9
00007b629add2780  pop r8
00007b629add2782  pop rsi
00007b629add2783  pop rdi
00007b629add2784  pop rdx
00007b629add2785  pop rcx
00007b629add2786  pop rax
00007b629add2787  add rsp, 0x08
00007b629add278b  jmp 0x00007B629ADCFD34
00007b629add2790  call 0x00007B629ABFF430
00007b629add2795  jmp 0x00007B629ADCFD3E
00007b629add279a  sub rsp, 0x08
00007b629add279e  push rax
00007b629add279f  push rcx
00007b629add27a0  push rdx
00007b629add27a1  push rdi
00007b629add27a2  push rsi
00007b629add27a3  push r8
00007b629add27a5  push r9
00007b629add27a7  push r10
00007b629add27a9  push r11
00007b629add27ab  sub rsp, 0xF0
00007b629add27b2  vmovaps [rsp], xmm0
00007b629add27b7  vmovaps [rsp+0x10], xmm1
00007b629add27bd  vmovaps [rsp+0x20], xmm2
00007b629add27c3  vmovaps [rsp+0x30], xmm3
00007b629add27c9  vmovaps [rsp+0x40], xmm4
00007b629add27cf  vmovaps [rsp+0x50], xmm5
00007b629add27d5  vmovaps [rsp+0x60], xmm6
00007b629add27db  vmovaps [rsp+0x70], xmm7
00007b629add27e1  vmovaps [rsp+0x80], xmm8
00007b629add27ea  vmovaps [rsp+0x90], xmm9
00007b629add27f3  vmovaps [rsp+0xA0], xmm10
00007b629add27fc  vmovaps [rsp+0xB0], xmm11
00007b629add2805  vmovaps [rsp+0xC0], xmm12
00007b629add280e  vmovaps [rsp+0xD0], xmm13
00007b629add2817  vmovaps [rsp+0xE0], xmm15
00007b629add2820  sub rsp, 0x30
00007b629add2824  movaps [rsp], xmm14
00007b629add2829  movaps [rsp+0x10], xmm6
00007b629add282e  movaps [rsp+0x20], xmm2
00007b629add2833  lea rdi, [rsp]
00007b629add2837  mov esi, 0x00
00007b629add283c  mov rax, 0x583FED93F530
00007b629add2846  call rax
00007b629add2848  movaps xmm14, [rsp]
00007b629add284d  add rsp, 0x30
00007b629add2851  vmovaps xmm0, [rsp]
00007b629add2856  vmovaps xmm1, [rsp+0x10]
00007b629add285c  vmovaps xmm2, [rsp+0x20]
00007b629add2862  vmovaps xmm3, [rsp+0x30]
00007b629add2868  vmovaps xmm4, [rsp+0x40]
00007b629add286e  vmovaps xmm5, [rsp+0x50]
00007b629add2874  vmovaps xmm6, [rsp+0x60]
00007b629add287a  vmovaps xmm7, [rsp+0x70]
00007b629add2880  vmovaps xmm8, [rsp+0x80]
00007b629add2889  vmovaps xmm9, [rsp+0x90]
00007b629add2892  vmovaps xmm10, [rsp+0xA0]
00007b629add289b  vmovaps xmm11, [rsp+0xB0]
00007b629add28a4  vmovaps xmm12, [rsp+0xC0]
00007b629add28ad  vmovaps xmm13, [rsp+0xD0]
00007b629add28b6  vmovaps xmm15, [rsp+0xE0]
00007b629add28bf  add rsp, 0xF0
00007b629add28c6  pop r11
00007b629add28c8  pop r10
00007b629add28ca  pop r9
00007b629add28cc  pop r8
00007b629add28ce  pop rsi
00007b629add28cf  pop rdi
00007b629add28d0  pop rdx
00007b629add28d1  pop rcx
00007b629add28d2  pop rax
00007b629add28d3  add rsp, 0x08
00007b629add28d7  jmp 0x00007B629ADCFD72
00007b629add28dc  sub rsp, 0x08
00007b629add28e0  push rax
00007b629add28e1  push rcx
00007b629add28e2  push rdx
00007b629add28e3  push rdi
00007b629add28e4  push rsi
00007b629add28e5  push r8
00007b629add28e7  push r9
00007b629add28e9  push r10
00007b629add28eb  push r11
00007b629add28ed  sub rsp, 0xF0
00007b629add28f4  vmovaps [rsp], xmm0
00007b629add28f9  vmovaps [rsp+0x10], xmm1
00007b629add28ff  vmovaps [rsp+0x20], xmm2
00007b629add2905  vmovaps [rsp+0x30], xmm3
00007b629add290b  vmovaps [rsp+0x40], xmm4
00007b629add2911  vmovaps [rsp+0x50], xmm5
00007b629add2917  vmovaps [rsp+0x60], xmm7
00007b629add291d  vmovaps [rsp+0x70], xmm8
00007b629add2923  vmovaps [rsp+0x80], xmm9
00007b629add292c  vmovaps [rsp+0x90], xmm10
00007b629add2935  vmovaps [rsp+0xA0], xmm11
00007b629add293e  vmovaps [rsp+0xB0], xmm12
00007b629add2947  vmovaps [rsp+0xC0], xmm13
00007b629add2950  vmovaps [rsp+0xD0], xmm14
00007b629add2959  vmovaps [rsp+0xE0], xmm15
00007b629add2962  sub rsp, 0x30
00007b629add2966  movaps [rsp], xmm6
00007b629add296a  movaps [rsp+0x10], xmm5
00007b629add296f  movaps [rsp+0x20], xmm1
00007b629add2974  lea rdi, [rsp]
00007b629add2978  mov esi, 0x00
00007b629add297d  mov rax, 0x583FED93F530
00007b629add2987  call rax
00007b629add2989  movaps xmm6, [rsp]
00007b629add298d  add rsp, 0x30
00007b629add2991  vmovaps xmm0, [rsp]
00007b629add2996  vmovaps xmm1, [rsp+0x10]
00007b629add299c  vmovaps xmm2, [rsp+0x20]
00007b629add29a2  vmovaps xmm3, [rsp+0x30]
00007b629add29a8  vmovaps xmm4, [rsp+0x40]
00007b629add29ae  vmovaps xmm5, [rsp+0x50]
00007b629add29b4  vmovaps xmm7, [rsp+0x60]
00007b629add29ba  vmovaps xmm8, [rsp+0x70]
00007b629add29c0  vmovaps xmm9, [rsp+0x80]
00007b629add29c9  vmovaps xmm10, [rsp+0x90]
00007b629add29d2  vmovaps xmm11, [rsp+0xA0]
00007b629add29db  vmovaps xmm12, [rsp+0xB0]
00007b629add29e4  vmovaps xmm13, [rsp+0xC0]
00007b629add29ed  vmovaps xmm14, [rsp+0xD0]
00007b629add29f6  vmovaps xmm15, [rsp+0xE0]
00007b629add29ff  add rsp, 0xF0
00007b629add2a06  pop r11
00007b629add2a08  pop r10
00007b629add2a0a  pop r9
00007b629add2a0c  pop r8
00007b629add2a0e  pop rsi
00007b629add2a0f  pop rdi
00007b629add2a10  pop rdx
00007b629add2a11  pop rcx
00007b629add2a12  pop rax
00007b629add2a13  add rsp, 0x08
00007b629add2a17  jmp 0x00007B629ADCFD98
00007b629add2a1c  sub rsp, 0x08
00007b629add2a20  push rax
00007b629add2a21  push rcx
00007b629add2a22  push rdx
00007b629add2a23  push rdi
00007b629add2a24  push rsi
00007b629add2a25  push r8
00007b629add2a27  push r9
00007b629add2a29  push r10
00007b629add2a2b  push r11
00007b629add2a2d  sub rsp, 0xF0
00007b629add2a34  vmovaps [rsp], xmm0
00007b629add2a39  vmovaps [rsp+0x10], xmm2
00007b629add2a3f  vmovaps [rsp+0x20], xmm3
00007b629add2a45  vmovaps [rsp+0x30], xmm4
00007b629add2a4b  vmovaps [rsp+0x40], xmm5
00007b629add2a51  vmovaps [rsp+0x50], xmm6
00007b629add2a57  vmovaps [rsp+0x60], xmm7
00007b629add2a5d  vmovaps [rsp+0x70], xmm8
00007b629add2a63  vmovaps [rsp+0x80], xmm9
00007b629add2a6c  vmovaps [rsp+0x90], xmm10
00007b629add2a75  vmovaps [rsp+0xA0], xmm11
00007b629add2a7e  vmovaps [rsp+0xB0], xmm12
00007b629add2a87  vmovaps [rsp+0xC0], xmm13
00007b629add2a90  vmovaps [rsp+0xD0], xmm14
00007b629add2a99  vmovaps [rsp+0xE0], xmm15
00007b629add2aa2  sub rsp, 0x30
00007b629add2aa6  movaps [rsp], xmm1
00007b629add2aaa  movaps [rsp+0x10], xmm5
00007b629add2aaf  movaps [rsp+0x20], xmm13
00007b629add2ab5  lea rdi, [rsp]
00007b629add2ab9  mov esi, 0x00
00007b629add2abe  mov rax, 0x583FED93F530
00007b629add2ac8  call rax
00007b629add2aca  movaps xmm1, [rsp]
00007b629add2ace  add rsp, 0x30
00007b629add2ad2  vmovaps xmm0, [rsp]
00007b629add2ad7  vmovaps xmm2, [rsp+0x10]
00007b629add2add  vmovaps xmm3, [rsp+0x20]
00007b629add2ae3  vmovaps xmm4, [rsp+0x30]
00007b629add2ae9  vmovaps xmm5, [rsp+0x40]
00007b629add2aef  vmovaps xmm6, [rsp+0x50]
00007b629add2af5  vmovaps xmm7, [rsp+0x60]
00007b629add2afb  vmovaps xmm8, [rsp+0x70]
00007b629add2b01  vmovaps xmm9, [rsp+0x80]
00007b629add2b0a  vmovaps xmm10, [rsp+0x90]
00007b629add2b13  vmovaps xmm11, [rsp+0xA0]
00007b629add2b1c  vmovaps xmm12, [rsp+0xB0]
00007b629add2b25  vmovaps xmm13, [rsp+0xC0]
00007b629add2b2e  vmovaps xmm14, [rsp+0xD0]
00007b629add2b37  vmovaps xmm15, [rsp+0xE0]
00007b629add2b40  add rsp, 0xF0
00007b629add2b47  pop r11
00007b629add2b49  pop r10
00007b629add2b4b  pop r9
00007b629add2b4d  pop r8
00007b629add2b4f  pop rsi
00007b629add2b50  pop rdi
00007b629add2b51  pop rdx
00007b629add2b52  pop rcx
00007b629add2b53  pop rax
00007b629add2b54  add rsp, 0x08
00007b629add2b58  jmp 0x00007B629ADCFDB6
00007b629add2b5d  sub rsp, 0x08
00007b629add2b61  push rax
00007b629add2b62  push rcx
00007b629add2b63  push rdx
00007b629add2b64  push rdi
00007b629add2b65  push rsi
00007b629add2b66  push r8
00007b629add2b68  push r9
00007b629add2b6a  push r10
00007b629add2b6c  push r11
00007b629add2b6e  sub rsp, 0xF0
00007b629add2b75  vmovaps [rsp], xmm0
00007b629add2b7a  vmovaps [rsp+0x10], xmm1
00007b629add2b80  vmovaps [rsp+0x20], xmm2
00007b629add2b86  vmovaps [rsp+0x30], xmm3
00007b629add2b8c  vmovaps [rsp+0x40], xmm4
00007b629add2b92  vmovaps [rsp+0x50], xmm6
00007b629add2b98  vmovaps [rsp+0x60], xmm7
00007b629add2b9e  vmovaps [rsp+0x70], xmm8
00007b629add2ba4  vmovaps [rsp+0x80], xmm9
00007b629add2bad  vmovaps [rsp+0x90], xmm10
00007b629add2bb6  vmovaps [rsp+0xA0], xmm11
00007b629add2bbf  vmovaps [rsp+0xB0], xmm12
00007b629add2bc8  vmovaps [rsp+0xC0], xmm13
00007b629add2bd1  vmovaps [rsp+0xD0], xmm14
00007b629add2bda  vmovaps [rsp+0xE0], xmm15
00007b629add2be3  sub rsp, 0x30
00007b629add2be7  movaps [rsp], xmm5
00007b629add2beb  movaps [rsp+0x10], xmm2
00007b629add2bf0  movaps [rsp+0x20], xmm13
00007b629add2bf6  lea rdi, [rsp]
00007b629add2bfa  mov esi, 0x00
00007b629add2bff  mov rax, 0x583FED93F530
00007b629add2c09  call rax
00007b629add2c0b  movaps xmm5, [rsp]
00007b629add2c0f  add rsp, 0x30
00007b629add2c13  vmovaps xmm0, [rsp]
00007b629add2c18  vmovaps xmm1, [rsp+0x10]
00007b629add2c1e  vmovaps xmm2, [rsp+0x20]
00007b629add2c24  vmovaps xmm3, [rsp+0x30]
00007b629add2c2a  vmovaps xmm4, [rsp+0x40]
00007b629add2c30  vmovaps xmm6, [rsp+0x50]
00007b629add2c36  vmovaps xmm7, [rsp+0x60]
00007b629add2c3c  vmovaps xmm8, [rsp+0x70]
00007b629add2c42  vmovaps xmm9, [rsp+0x80]
00007b629add2c4b  vmovaps xmm10, [rsp+0x90]
00007b629add2c54  vmovaps xmm11, [rsp+0xA0]
00007b629add2c5d  vmovaps xmm12, [rsp+0xB0]
00007b629add2c66  vmovaps xmm13, [rsp+0xC0]
00007b629add2c6f  vmovaps xmm14, [rsp+0xD0]
00007b629add2c78  vmovaps xmm15, [rsp+0xE0]
00007b629add2c81  add rsp, 0xF0
00007b629add2c88  pop r11
00007b629add2c8a  pop r10
00007b629add2c8c  pop r9
00007b629add2c8e  pop r8
00007b629add2c90  pop rsi
00007b629add2c91  pop rdi
00007b629add2c92  pop rdx
00007b629add2c93  pop rcx
00007b629add2c94  pop rax
00007b629add2c95  add rsp, 0x08
00007b629add2c99  jmp 0x00007B629ADCFDEC
00007b629add2c9e  sub rsp, 0x08
00007b629add2ca2  push rax
00007b629add2ca3  push rcx
00007b629add2ca4  push rdx
00007b629add2ca5  push rdi
00007b629add2ca6  push rsi
00007b629add2ca7  push r8
00007b629add2ca9  push r9
00007b629add2cab  push r10
00007b629add2cad  push r11
00007b629add2caf  sub rsp, 0xF0
00007b629add2cb6  vmovaps [rsp], xmm0
00007b629add2cbb  vmovaps [rsp+0x10], xmm1
00007b629add2cc1  vmovaps [rsp+0x20], xmm2
00007b629add2cc7  vmovaps [rsp+0x30], xmm3
00007b629add2ccd  vmovaps [rsp+0x40], xmm4
00007b629add2cd3  vmovaps [rsp+0x50], xmm5
00007b629add2cd9  vmovaps [rsp+0x60], xmm6
00007b629add2cdf  vmovaps [rsp+0x70], xmm7
00007b629add2ce5  vmovaps [rsp+0x80], xmm8
00007b629add2cee  vmovaps [rsp+0x90], xmm9
00007b629add2cf7  vmovaps [rsp+0xA0], xmm10
00007b629add2d00  vmovaps [rsp+0xB0], xmm11
00007b629add2d09  vmovaps [rsp+0xC0], xmm12
00007b629add2d12  vmovaps [rsp+0xD0], xmm14
00007b629add2d1b  vmovaps [rsp+0xE0], xmm15
00007b629add2d24  sub rsp, 0x30
00007b629add2d28  movaps [rsp], xmm13
00007b629add2d2d  movaps [rsp+0x10], xmm10
00007b629add2d33  movaps [rsp+0x20], xmm1
00007b629add2d38  lea rdi, [rsp]
00007b629add2d3c  mov esi, 0x00
00007b629add2d41  mov rax, 0x583FED93F530
00007b629add2d4b  call rax
00007b629add2d4d  movaps xmm13, [rsp]
00007b629add2d52  add rsp, 0x30
00007b629add2d56  vmovaps xmm0, [rsp]
00007b629add2d5b  vmovaps xmm1, [rsp+0x10]
00007b629add2d61  vmovaps xmm2, [rsp+0x20]
00007b629add2d67  vmovaps xmm3, [rsp+0x30]
00007b629add2d6d  vmovaps xmm4, [rsp+0x40]
00007b629add2d73  vmovaps xmm5, [rsp+0x50]
00007b629add2d79  vmovaps xmm6, [rsp+0x60]
00007b629add2d7f  vmovaps xmm7, [rsp+0x70]
00007b629add2d85  vmovaps xmm8, [rsp+0x80]
00007b629add2d8e  vmovaps xmm9, [rsp+0x90]
00007b629add2d97  vmovaps xmm10, [rsp+0xA0]
00007b629add2da0  vmovaps xmm11, [rsp+0xB0]
00007b629add2da9  vmovaps xmm12, [rsp+0xC0]
00007b629add2db2  vmovaps xmm14, [rsp+0xD0]
00007b629add2dbb  vmovaps xmm15, [rsp+0xE0]
00007b629add2dc4  add rsp, 0xF0
00007b629add2dcb  pop r11
00007b629add2dcd  pop r10
00007b629add2dcf  pop r9
00007b629add2dd1  pop r8
00007b629add2dd3  pop rsi
00007b629add2dd4  pop rdi
00007b629add2dd5  pop rdx
00007b629add2dd6  pop rcx
00007b629add2dd7  pop rax
00007b629add2dd8  add rsp, 0x08
00007b629add2ddc  jmp 0x00007B629ADCFE15
00007b629add2de1  sub rsp, 0x08
00007b629add2de5  push rax
00007b629add2de6  push rcx
00007b629add2de7  push rdx
00007b629add2de8  push rdi
00007b629add2de9  push rsi
00007b629add2dea  push r8
00007b629add2dec  push r9
00007b629add2dee  push r10
00007b629add2df0  push r11
00007b629add2df2  sub rsp, 0xF0
00007b629add2df9  vmovaps [rsp], xmm0
00007b629add2dfe  vmovaps [rsp+0x10], xmm2
00007b629add2e04  vmovaps [rsp+0x20], xmm3
00007b629add2e0a  vmovaps [rsp+0x30], xmm4
00007b629add2e10  vmovaps [rsp+0x40], xmm5
00007b629add2e16  vmovaps [rsp+0x50], xmm6
00007b629add2e1c  vmovaps [rsp+0x60], xmm7
00007b629add2e22  vmovaps [rsp+0x70], xmm8
00007b629add2e28  vmovaps [rsp+0x80], xmm9
00007b629add2e31  vmovaps [rsp+0x90], xmm10
00007b629add2e3a  vmovaps [rsp+0xA0], xmm11
00007b629add2e43  vmovaps [rsp+0xB0], xmm12
00007b629add2e4c  vmovaps [rsp+0xC0], xmm13
00007b629add2e55  vmovaps [rsp+0xD0], xmm14
00007b629add2e5e  vmovaps [rsp+0xE0], xmm15
00007b629add2e67  sub rsp, 0x30
00007b629add2e6b  movaps [rsp], xmm1
00007b629add2e6f  movaps [rsp+0x10], xmm15
00007b629add2e75  movaps [rsp+0x20], xmm10
00007b629add2e7b  lea rdi, [rsp]
00007b629add2e7f  mov esi, 0x00
00007b629add2e84  mov rax, 0x583FED93F530
00007b629add2e8e  call rax
00007b629add2e90  movaps xmm1, [rsp]
00007b629add2e94  add rsp, 0x30
00007b629add2e98  vmovaps xmm0, [rsp]
00007b629add2e9d  vmovaps xmm2, [rsp+0x10]
00007b629add2ea3  vmovaps xmm3, [rsp+0x20]
00007b629add2ea9  vmovaps xmm4, [rsp+0x30]
00007b629add2eaf  vmovaps xmm5, [rsp+0x40]
00007b629add2eb5  vmovaps xmm6, [rsp+0x50]
00007b629add2ebb  vmovaps xmm7, [rsp+0x60]
00007b629add2ec1  vmovaps xmm8, [rsp+0x70]
00007b629add2ec7  vmovaps xmm9, [rsp+0x80]
00007b629add2ed0  vmovaps xmm10, [rsp+0x90]
00007b629add2ed9  vmovaps xmm11, [rsp+0xA0]
00007b629add2ee2  vmovaps xmm12, [rsp+0xB0]
00007b629add2eeb  vmovaps xmm13, [rsp+0xC0]
00007b629add2ef4  vmovaps xmm14, [rsp+0xD0]
00007b629add2efd  vmovaps xmm15, [rsp+0xE0]
00007b629add2f06  add rsp, 0xF0
00007b629add2f0d  pop r11
00007b629add2f0f  pop r10
00007b629add2f11  pop r9
00007b629add2f13  pop r8
00007b629add2f15  pop rsi
00007b629add2f16  pop rdi
00007b629add2f17  pop rdx
00007b629add2f18  pop rcx
00007b629add2f19  pop rax
00007b629add2f1a  add rsp, 0x08
00007b629add2f1e  jmp 0x00007B629ADCFE34
00007b629add2f23  sub rsp, 0x08
00007b629add2f27  push rax
00007b629add2f28  push rcx
00007b629add2f29  push rdx
00007b629add2f2a  push rdi
00007b629add2f2b  push rsi
00007b629add2f2c  push r8
00007b629add2f2e  push r9
00007b629add2f30  push r10
00007b629add2f32  push r11
00007b629add2f34  sub rsp, 0xF0
00007b629add2f3b  vmovaps [rsp], xmm0
00007b629add2f40  vmovaps [rsp+0x10], xmm1
00007b629add2f46  vmovaps [rsp+0x20], xmm2
00007b629add2f4c  vmovaps [rsp+0x30], xmm3
00007b629add2f52  vmovaps [rsp+0x40], xmm4
00007b629add2f58  vmovaps [rsp+0x50], xmm5
00007b629add2f5e  vmovaps [rsp+0x60], xmm6
00007b629add2f64  vmovaps [rsp+0x70], xmm7
00007b629add2f6a  vmovaps [rsp+0x80], xmm8
00007b629add2f73  vmovaps [rsp+0x90], xmm9
00007b629add2f7c  vmovaps [rsp+0xA0], xmm10
00007b629add2f85  vmovaps [rsp+0xB0], xmm11
00007b629add2f8e  vmovaps [rsp+0xC0], xmm12
00007b629add2f97  vmovaps [rsp+0xD0], xmm13
00007b629add2fa0  vmovaps [rsp+0xE0], xmm14
00007b629add2fa9  sub rsp, 0x30
00007b629add2fad  movaps [rsp], xmm15
00007b629add2fb2  movaps [rsp+0x10], xmm10
00007b629add2fb8  movaps [rsp+0x20], xmm11
00007b629add2fbe  lea rdi, [rsp]
00007b629add2fc2  mov esi, 0x00
00007b629add2fc7  mov rax, 0x583FED93F530
00007b629add2fd1  call rax
00007b629add2fd3  movaps xmm15, [rsp]
00007b629add2fd8  add rsp, 0x30
00007b629add2fdc  vmovaps xmm0, [rsp]
00007b629add2fe1  vmovaps xmm1, [rsp+0x10]
00007b629add2fe7  vmovaps xmm2, [rsp+0x20]
00007b629add2fed  vmovaps xmm3, [rsp+0x30]
00007b629add2ff3  vmovaps xmm4, [rsp+0x40]
00007b629add2ff9  vmovaps xmm5, [rsp+0x50]
00007b629add2fff  vmovaps xmm6, [rsp+0x60]
00007b629add3005  vmovaps xmm7, [rsp+0x70]
00007b629add300b  vmovaps xmm8, [rsp+0x80]
00007b629add3014  vmovaps xmm9, [rsp+0x90]
00007b629add301d  vmovaps xmm10, [rsp+0xA0]
00007b629add3026  vmovaps xmm11, [rsp+0xB0]
00007b629add302f  vmovaps xmm12, [rsp+0xC0]
00007b629add3038  vmovaps xmm13, [rsp+0xD0]
00007b629add3041  vmovaps xmm14, [rsp+0xE0]
00007b629add304a  add rsp, 0xF0
00007b629add3051  pop r11
00007b629add3053  pop r10
00007b629add3055  pop r9
00007b629add3057  pop r8
00007b629add3059  pop rsi
00007b629add305a  pop rdi
00007b629add305b  pop rdx
00007b629add305c  pop rcx
00007b629add305d  pop rax
00007b629add305e  add rsp, 0x08
00007b629add3062  jmp 0x00007B629ADCFE57
00007b629add3067  sub rsp, 0x08
00007b629add306b  push rax
00007b629add306c  push rcx
00007b629add306d  push rdx
00007b629add306e  push rdi
00007b629add306f  push rsi
00007b629add3070  push r8
00007b629add3072  push r9
00007b629add3074  push r10
00007b629add3076  push r11
00007b629add3078  sub rsp, 0xF0
00007b629add307f  vmovaps [rsp], xmm0
00007b629add3084  vmovaps [rsp+0x10], xmm1
00007b629add308a  vmovaps [rsp+0x20], xmm2
00007b629add3090  vmovaps [rsp+0x30], xmm3
00007b629add3096  vmovaps [rsp+0x40], xmm4
00007b629add309c  vmovaps [rsp+0x50], xmm5
00007b629add30a2  vmovaps [rsp+0x60], xmm6
00007b629add30a8  vmovaps [rsp+0x70], xmm7
00007b629add30ae  vmovaps [rsp+0x80], xmm8
00007b629add30b7  vmovaps [rsp+0x90], xmm9
00007b629add30c0  vmovaps [rsp+0xA0], xmm11
00007b629add30c9  vmovaps [rsp+0xB0], xmm12
00007b629add30d2  vmovaps [rsp+0xC0], xmm13
00007b629add30db  vmovaps [rsp+0xD0], xmm14
00007b629add30e4  vmovaps [rsp+0xE0], xmm15
00007b629add30ed  sub rsp, 0x30
00007b629add30f1  movaps [rsp], xmm10
00007b629add30f6  movaps [rsp+0x10], xmm12
00007b629add30fc  movaps [rsp+0x20], xmm11
00007b629add3102  lea rdi, [rsp]
00007b629add3106  mov esi, 0x00
00007b629add310b  mov rax, 0x583FED93F530
00007b629add3115  call rax
00007b629add3117  movaps xmm10, [rsp]
00007b629add311c  add rsp, 0x30
00007b629add3120  vmovaps xmm0, [rsp]
00007b629add3125  vmovaps xmm1, [rsp+0x10]
00007b629add312b  vmovaps xmm2, [rsp+0x20]
00007b629add3131  vmovaps xmm3, [rsp+0x30]
00007b629add3137  vmovaps xmm4, [rsp+0x40]
00007b629add313d  vmovaps xmm5, [rsp+0x50]
00007b629add3143  vmovaps xmm6, [rsp+0x60]
00007b629add3149  vmovaps xmm7, [rsp+0x70]
00007b629add314f  vmovaps xmm8, [rsp+0x80]
00007b629add3158  vmovaps xmm9, [rsp+0x90]
00007b629add3161  vmovaps xmm11, [rsp+0xA0]
00007b629add316a  vmovaps xmm12, [rsp+0xB0]
00007b629add3173  vmovaps xmm13, [rsp+0xC0]
00007b629add317c  vmovaps xmm14, [rsp+0xD0]
00007b629add3185  vmovaps xmm15, [rsp+0xE0]
00007b629add318e  add rsp, 0xF0
00007b629add3195  pop r11
00007b629add3197  pop r10
00007b629add3199  pop r9
00007b629add319b  pop r8
00007b629add319d  pop rsi
00007b629add319e  pop rdi
00007b629add319f  pop rdx
00007b629add31a0  pop rcx
00007b629add31a1  pop rax
00007b629add31a2  add rsp, 0x08
00007b629add31a6  jmp 0x00007B629ADCFE80
00007b629add31ab  sub rsp, 0x08
00007b629add31af  push rax
00007b629add31b0  push rcx
00007b629add31b1  push rdx
00007b629add31b2  push rdi
00007b629add31b3  push rsi
00007b629add31b4  push r8
00007b629add31b6  push r9
00007b629add31b8  push r10
00007b629add31ba  push r11
00007b629add31bc  sub rsp, 0xF0
00007b629add31c3  vmovaps [rsp], xmm0
00007b629add31c8  vmovaps [rsp+0x10], xmm1
00007b629add31ce  vmovaps [rsp+0x20], xmm2
00007b629add31d4  vmovaps [rsp+0x30], xmm3
00007b629add31da  vmovaps [rsp+0x40], xmm4
00007b629add31e0  vmovaps [rsp+0x50], xmm5
00007b629add31e6  vmovaps [rsp+0x60], xmm6
00007b629add31ec  vmovaps [rsp+0x70], xmm7
00007b629add31f2  vmovaps [rsp+0x80], xmm8
00007b629add31fb  vmovaps [rsp+0x90], xmm9
00007b629add3204  vmovaps [rsp+0xA0], xmm10
00007b629add320d  vmovaps [rsp+0xB0], xmm12
00007b629add3216  vmovaps [rsp+0xC0], xmm13
00007b629add321f  vmovaps [rsp+0xD0], xmm14
00007b629add3228  vmovaps [rsp+0xE0], xmm15
00007b629add3231  sub rsp, 0x30
00007b629add3235  movaps [rsp], xmm11
00007b629add323a  movaps [rsp+0x10], xmm2
00007b629add323f  movaps [rsp+0x20], xmm12
00007b629add3245  lea rdi, [rsp]
00007b629add3249  mov esi, 0x00
00007b629add324e  mov rax, 0x583FED93F530
00007b629add3258  call rax
00007b629add325a  movaps xmm11, [rsp]
00007b629add325f  add rsp, 0x30
00007b629add3263  vmovaps xmm0, [rsp]
00007b629add3268  vmovaps xmm1, [rsp+0x10]
00007b629add326e  vmovaps xmm2, [rsp+0x20]
00007b629add3274  vmovaps xmm3, [rsp+0x30]
00007b629add327a  vmovaps xmm4, [rsp+0x40]
00007b629add3280  vmovaps xmm5, [rsp+0x50]
00007b629add3286  vmovaps xmm6, [rsp+0x60]
00007b629add328c  vmovaps xmm7, [rsp+0x70]
00007b629add3292  vmovaps xmm8, [rsp+0x80]
00007b629add329b  vmovaps xmm9, [rsp+0x90]
00007b629add32a4  vmovaps xmm10, [rsp+0xA0]
00007b629add32ad  vmovaps xmm12, [rsp+0xB0]
00007b629add32b6  vmovaps xmm13, [rsp+0xC0]
00007b629add32bf  vmovaps xmm14, [rsp+0xD0]
00007b629add32c8  vmovaps xmm15, [rsp+0xE0]
00007b629add32d1  add rsp, 0xF0
00007b629add32d8  pop r11
00007b629add32da  pop r10
00007b629add32dc  pop r9
00007b629add32de  pop r8
00007b629add32e0  pop rsi
00007b629add32e1  pop rdi
00007b629add32e2  pop rdx
00007b629add32e3  pop rcx
00007b629add32e4  pop rax
00007b629add32e5  add rsp, 0x08
00007b629add32e9  jmp 0x00007B629ADCFEB8
00007b629add32ee  sub rsp, 0x08
00007b629add32f2  push rax
00007b629add32f3  push rcx
00007b629add32f4  push rdx
00007b629add32f5  push rdi
00007b629add32f6  push rsi
00007b629add32f7  push r8
00007b629add32f9  push r9
00007b629add32fb  push r10
00007b629add32fd  push r11
00007b629add32ff  sub rsp, 0xF0
00007b629add3306  vmovaps [rsp], xmm0
00007b629add330b  vmovaps [rsp+0x10], xmm2
00007b629add3311  vmovaps [rsp+0x20], xmm3
00007b629add3317  vmovaps [rsp+0x30], xmm4
00007b629add331d  vmovaps [rsp+0x40], xmm5
00007b629add3323  vmovaps [rsp+0x50], xmm6
00007b629add3329  vmovaps [rsp+0x60], xmm7
00007b629add332f  vmovaps [rsp+0x70], xmm8
00007b629add3335  vmovaps [rsp+0x80], xmm9
00007b629add333e  vmovaps [rsp+0x90], xmm10
00007b629add3347  vmovaps [rsp+0xA0], xmm11
00007b629add3350  vmovaps [rsp+0xB0], xmm12
00007b629add3359  vmovaps [rsp+0xC0], xmm13
00007b629add3362  vmovaps [rsp+0xD0], xmm14
00007b629add336b  vmovaps [rsp+0xE0], xmm15
00007b629add3374  sub rsp, 0x30
00007b629add3378  movaps [rsp], xmm1
00007b629add337c  movaps [rsp+0x10], xmm14
00007b629add3382  movaps [rsp+0x20], xmm6
00007b629add3387  lea rdi, [rsp]
00007b629add338b  mov esi, 0x00
00007b629add3390  mov rax, 0x583FED93F530
00007b629add339a  call rax
00007b629add339c  movaps xmm1, [rsp]
00007b629add33a0  add rsp, 0x30
00007b629add33a4  vmovaps xmm0, [rsp]
00007b629add33a9  vmovaps xmm2, [rsp+0x10]
00007b629add33af  vmovaps xmm3, [rsp+0x20]
00007b629add33b5  vmovaps xmm4, [rsp+0x30]
00007b629add33bb  vmovaps xmm5, [rsp+0x40]
00007b629add33c1  vmovaps xmm6, [rsp+0x50]
00007b629add33c7  vmovaps xmm7, [rsp+0x60]
00007b629add33cd  vmovaps xmm8, [rsp+0x70]
00007b629add33d3  vmovaps xmm9, [rsp+0x80]
00007b629add33dc  vmovaps xmm10, [rsp+0x90]
00007b629add33e5  vmovaps xmm11, [rsp+0xA0]
00007b629add33ee  vmovaps xmm12, [rsp+0xB0]
00007b629add33f7  vmovaps xmm13, [rsp+0xC0]
00007b629add3400  vmovaps xmm14, [rsp+0xD0]
00007b629add3409  vmovaps xmm15, [rsp+0xE0]
00007b629add3412  add rsp, 0xF0
00007b629add3419  pop r11
00007b629add341b  pop r10
00007b629add341d  pop r9
00007b629add341f  pop r8
00007b629add3421  pop rsi
00007b629add3422  pop rdi
00007b629add3423  pop rdx
00007b629add3424  pop rcx
00007b629add3425  pop rax
00007b629add3426  add rsp, 0x08
00007b629add342a  jmp 0x00007B629ADCFED1
00007b629add342f  sub rsp, 0x08
00007b629add3433  push rax
00007b629add3434  push rcx
00007b629add3435  push rdx
00007b629add3436  push rdi
00007b629add3437  push rsi
00007b629add3438  push r8
00007b629add343a  push r9
00007b629add343c  push r10
00007b629add343e  push r11
00007b629add3440  sub rsp, 0xF0
00007b629add3447  vmovaps [rsp], xmm0
00007b629add344c  vmovaps [rsp+0x10], xmm1
00007b629add3452  vmovaps [rsp+0x20], xmm2
00007b629add3458  vmovaps [rsp+0x30], xmm3
00007b629add345e  vmovaps [rsp+0x40], xmm4
00007b629add3464  vmovaps [rsp+0x50], xmm5
00007b629add346a  vmovaps [rsp+0x60], xmm6
00007b629add3470  vmovaps [rsp+0x70], xmm7
00007b629add3476  vmovaps [rsp+0x80], xmm8
00007b629add347f  vmovaps [rsp+0x90], xmm9
00007b629add3488  vmovaps [rsp+0xA0], xmm10
00007b629add3491  vmovaps [rsp+0xB0], xmm11
00007b629add349a  vmovaps [rsp+0xC0], xmm12
00007b629add34a3  vmovaps [rsp+0xD0], xmm13
00007b629add34ac  vmovaps [rsp+0xE0], xmm15
00007b629add34b5  sub rsp, 0x30
00007b629add34b9  movaps [rsp], xmm14
00007b629add34be  movaps [rsp+0x10], xmm12
00007b629add34c4  movaps [rsp+0x20], xmm5
00007b629add34c9  lea rdi, [rsp]
00007b629add34cd  mov esi, 0x00
00007b629add34d2  mov rax, 0x583FED93F530
00007b629add34dc  call rax
00007b629add34de  movaps xmm14, [rsp]
00007b629add34e3  add rsp, 0x30
00007b629add34e7  vmovaps xmm0, [rsp]
00007b629add34ec  vmovaps xmm1, [rsp+0x10]
00007b629add34f2  vmovaps xmm2, [rsp+0x20]
00007b629add34f8  vmovaps xmm3, [rsp+0x30]
00007b629add34fe  vmovaps xmm4, [rsp+0x40]
00007b629add3504  vmovaps xmm5, [rsp+0x50]
00007b629add350a  vmovaps xmm6, [rsp+0x60]
00007b629add3510  vmovaps xmm7, [rsp+0x70]
00007b629add3516  vmovaps xmm8, [rsp+0x80]
00007b629add351f  vmovaps xmm9, [rsp+0x90]
00007b629add3528  vmovaps xmm10, [rsp+0xA0]
00007b629add3531  vmovaps xmm11, [rsp+0xB0]
00007b629add353a  vmovaps xmm12, [rsp+0xC0]
00007b629add3543  vmovaps xmm13, [rsp+0xD0]
00007b629add354c  vmovaps xmm15, [rsp+0xE0]
00007b629add3555  add rsp, 0xF0
00007b629add355c  pop r11
00007b629add355e  pop r10
00007b629add3560  pop r9
00007b629add3562  pop r8
00007b629add3564  pop rsi
00007b629add3565  pop rdi
00007b629add3566  pop rdx
00007b629add3567  pop rcx
00007b629add3568  pop rax
00007b629add3569  add rsp, 0x08
00007b629add356d  jmp 0x00007B629ADCFEF1
00007b629add3572  sub rsp, 0x08
00007b629add3576  push rax
00007b629add3577  push rcx
00007b629add3578  push rdx
00007b629add3579  push rdi
00007b629add357a  push rsi
00007b629add357b  push r8
00007b629add357d  push r9
00007b629add357f  push r10
00007b629add3581  push r11
00007b629add3583  sub rsp, 0xF0
00007b629add358a  vmovaps [rsp], xmm0
00007b629add358f  vmovaps [rsp+0x10], xmm1
00007b629add3595  vmovaps [rsp+0x20], xmm2
00007b629add359b  vmovaps [rsp+0x30], xmm3
00007b629add35a1  vmovaps [rsp+0x40], xmm4
00007b629add35a7  vmovaps [rsp+0x50], xmm5
00007b629add35ad  vmovaps [rsp+0x60], xmm7
00007b629add35b3  vmovaps [rsp+0x70], xmm8
00007b629add35b9  vmovaps [rsp+0x80], xmm9
00007b629add35c2  vmovaps [rsp+0x90], xmm10
00007b629add35cb  vmovaps [rsp+0xA0], xmm11
00007b629add35d4  vmovaps [rsp+0xB0], xmm12
00007b629add35dd  vmovaps [rsp+0xC0], xmm13
00007b629add35e6  vmovaps [rsp+0xD0], xmm14
00007b629add35ef  vmovaps [rsp+0xE0], xmm15
00007b629add35f8  sub rsp, 0x30
00007b629add35fc  movaps [rsp], xmm6
00007b629add3600  movaps [rsp+0x10], xmm9
00007b629add3606  movaps [rsp+0x20], xmm12
00007b629add360c  lea rdi, [rsp]
00007b629add3610  mov esi, 0x00
00007b629add3615  mov rax, 0x583FED93F530
00007b629add361f  call rax
00007b629add3621  movaps xmm6, [rsp]
00007b629add3625  add rsp, 0x30
00007b629add3629  vmovaps xmm0, [rsp]
00007b629add362e  vmovaps xmm1, [rsp+0x10]
00007b629add3634  vmovaps xmm2, [rsp+0x20]
00007b629add363a  vmovaps xmm3, [rsp+0x30]
00007b629add3640  vmovaps xmm4, [rsp+0x40]
00007b629add3646  vmovaps xmm5, [rsp+0x50]
00007b629add364c  vmovaps xmm7, [rsp+0x60]
00007b629add3652  vmovaps xmm8, [rsp+0x70]
00007b629add3658  vmovaps xmm9, [rsp+0x80]
00007b629add3661  vmovaps xmm10, [rsp+0x90]
00007b629add366a  vmovaps xmm11, [rsp+0xA0]
00007b629add3673  vmovaps xmm12, [rsp+0xB0]
00007b629add367c  vmovaps xmm13, [rsp+0xC0]
00007b629add3685  vmovaps xmm14, [rsp+0xD0]
00007b629add368e  vmovaps xmm15, [rsp+0xE0]
00007b629add3697  add rsp, 0xF0
00007b629add369e  pop r11
00007b629add36a0  pop r10
00007b629add36a2  pop r9
00007b629add36a4  pop r8
00007b629add36a6  pop rsi
00007b629add36a7  pop rdi
00007b629add36a8  pop rdx
00007b629add36a9  pop rcx
00007b629add36aa  pop rax
00007b629add36ab  add rsp, 0x08
00007b629add36af  jmp 0x00007B629ADCFF19
00007b629add36b4  sub rsp, 0x08
00007b629add36b8  push rax
00007b629add36b9  push rcx
00007b629add36ba  push rdx
00007b629add36bb  push rdi
00007b629add36bc  push rsi
00007b629add36bd  push r8
00007b629add36bf  push r9
00007b629add36c1  push r10
00007b629add36c3  push r11
00007b629add36c5  sub rsp, 0xF0
00007b629add36cc  vmovaps [rsp], xmm0
00007b629add36d1  vmovaps [rsp+0x10], xmm1
00007b629add36d7  vmovaps [rsp+0x20], xmm2
00007b629add36dd  vmovaps [rsp+0x30], xmm3
00007b629add36e3  vmovaps [rsp+0x40], xmm4
00007b629add36e9  vmovaps [rsp+0x50], xmm5
00007b629add36ef  vmovaps [rsp+0x60], xmm6
00007b629add36f5  vmovaps [rsp+0x70], xmm7
00007b629add36fb  vmovaps [rsp+0x80], xmm8
00007b629add3704  vmovaps [rsp+0x90], xmm9
00007b629add370d  vmovaps [rsp+0xA0], xmm10
00007b629add3716  vmovaps [rsp+0xB0], xmm11
00007b629add371f  vmovaps [rsp+0xC0], xmm13
00007b629add3728  vmovaps [rsp+0xD0], xmm14
00007b629add3731  vmovaps [rsp+0xE0], xmm15
00007b629add373a  sub rsp, 0x30
00007b629add373e  movaps [rsp], xmm12
00007b629add3743  movaps [rsp+0x10], xmm15
00007b629add3749  movaps [rsp+0x20], xmm13
00007b629add374f  lea rdi, [rsp]
00007b629add3753  mov esi, 0x00
00007b629add3758  mov rax, 0x583FED93F530
00007b629add3762  call rax
00007b629add3764  movaps xmm12, [rsp]
00007b629add3769  add rsp, 0x30
00007b629add376d  vmovaps xmm0, [rsp]
00007b629add3772  vmovaps xmm1, [rsp+0x10]
00007b629add3778  vmovaps xmm2, [rsp+0x20]
00007b629add377e  vmovaps xmm3, [rsp+0x30]
00007b629add3784  vmovaps xmm4, [rsp+0x40]
00007b629add378a  vmovaps xmm5, [rsp+0x50]
00007b629add3790  vmovaps xmm6, [rsp+0x60]
00007b629add3796  vmovaps xmm7, [rsp+0x70]
00007b629add379c  vmovaps xmm8, [rsp+0x80]
00007b629add37a5  vmovaps xmm9, [rsp+0x90]
00007b629add37ae  vmovaps xmm10, [rsp+0xA0]
00007b629add37b7  vmovaps xmm11, [rsp+0xB0]
00007b629add37c0  vmovaps xmm13, [rsp+0xC0]
00007b629add37c9  vmovaps xmm14, [rsp+0xD0]
00007b629add37d2  vmovaps xmm15, [rsp+0xE0]
00007b629add37db  add rsp, 0xF0
00007b629add37e2  pop r11
00007b629add37e4  pop r10
00007b629add37e6  pop r9
00007b629add37e8  pop r8
00007b629add37ea  pop rsi
00007b629add37eb  pop rdi
00007b629add37ec  pop rdx
00007b629add37ed  pop rcx
00007b629add37ee  pop rax
00007b629add37ef  add rsp, 0x08
00007b629add37f3  jmp 0x00007B629ADCFF34
00007b629add37f8  sub rsp, 0x08
00007b629add37fc  push rax
00007b629add37fd  push rcx
00007b629add37fe  push rdx
00007b629add37ff  push rdi
00007b629add3800  push rsi
00007b629add3801  push r8
00007b629add3803  push r9
00007b629add3805  push r10
00007b629add3807  push r11
00007b629add3809  sub rsp, 0xF0
00007b629add3810  vmovaps [rsp], xmm0
00007b629add3815  vmovaps [rsp+0x10], xmm1
00007b629add381b  vmovaps [rsp+0x20], xmm2
00007b629add3821  vmovaps [rsp+0x30], xmm3
00007b629add3827  vmovaps [rsp+0x40], xmm4
00007b629add382d  vmovaps [rsp+0x50], xmm5
00007b629add3833  vmovaps [rsp+0x60], xmm6
00007b629add3839  vmovaps [rsp+0x70], xmm7
00007b629add383f  vmovaps [rsp+0x80], xmm8
00007b629add3848  vmovaps [rsp+0x90], xmm9
00007b629add3851  vmovaps [rsp+0xA0], xmm10
00007b629add385a  vmovaps [rsp+0xB0], xmm11
00007b629add3863  vmovaps [rsp+0xC0], xmm12
00007b629add386c  vmovaps [rsp+0xD0], xmm13
00007b629add3875  vmovaps [rsp+0xE0], xmm14
00007b629add387e  sub rsp, 0x30
00007b629add3882  movaps [rsp], xmm15
00007b629add3887  movaps [rsp+0x10], xmm13
00007b629add388d  movaps [rsp+0x20], xmm10
00007b629add3893  lea rdi, [rsp]
00007b629add3897  mov esi, 0x00
00007b629add389c  mov rax, 0x583FED93F530
00007b629add38a6  call rax
00007b629add38a8  movaps xmm15, [rsp]
00007b629add38ad  add rsp, 0x30
00007b629add38b1  vmovaps xmm0, [rsp]
00007b629add38b6  vmovaps xmm1, [rsp+0x10]
00007b629add38bc  vmovaps xmm2, [rsp+0x20]
00007b629add38c2  vmovaps xmm3, [rsp+0x30]
00007b629add38c8  vmovaps xmm4, [rsp+0x40]
00007b629add38ce  vmovaps xmm5, [rsp+0x50]
00007b629add38d4  vmovaps xmm6, [rsp+0x60]
00007b629add38da  vmovaps xmm7, [rsp+0x70]
00007b629add38e0  vmovaps xmm8, [rsp+0x80]
00007b629add38e9  vmovaps xmm9, [rsp+0x90]
00007b629add38f2  vmovaps xmm10, [rsp+0xA0]
00007b629add38fb  vmovaps xmm11, [rsp+0xB0]
00007b629add3904  vmovaps xmm12, [rsp+0xC0]
00007b629add390d  vmovaps xmm13, [rsp+0xD0]
00007b629add3916  vmovaps xmm14, [rsp+0xE0]
00007b629add391f  add rsp, 0xF0
00007b629add3926  pop r11
00007b629add3928  pop r10
00007b629add392a  pop r9
00007b629add392c  pop r8
00007b629add392e  pop rsi
00007b629add392f  pop rdi
00007b629add3930  pop rdx
00007b629add3931  pop rcx
00007b629add3932  pop rax
00007b629add3933  add rsp, 0x08
00007b629add3937  jmp 0x00007B629ADCFF55
00007b629add393c  call 0x00007B629AC0C260
00007b629add3941  jmp 0x00007B629ADCFFB0
00007b629add3946  sub rsp, 0x08
00007b629add394a  push rax
00007b629add394b  push rcx
00007b629add394c  push rdx
00007b629add394d  push rdi
00007b629add394e  push rsi
00007b629add394f  push r8
00007b629add3951  push r9
00007b629add3953  push r10
00007b629add3955  push r11
00007b629add3957  sub rsp, 0xF0
00007b629add395e  vmovaps [rsp], xmm0
00007b629add3963  vmovaps [rsp+0x10], xmm1
00007b629add3969  vmovaps [rsp+0x20], xmm2
00007b629add396f  vmovaps [rsp+0x30], xmm3
00007b629add3975  vmovaps [rsp+0x40], xmm4
00007b629add397b  vmovaps [rsp+0x50], xmm5
00007b629add3981  vmovaps [rsp+0x60], xmm6
00007b629add3987  vmovaps [rsp+0x70], xmm7
00007b629add398d  vmovaps [rsp+0x80], xmm8
00007b629add3996  vmovaps [rsp+0x90], xmm10
00007b629add399f  vmovaps [rsp+0xA0], xmm11
00007b629add39a8  vmovaps [rsp+0xB0], xmm12
00007b629add39b1  vmovaps [rsp+0xC0], xmm13
00007b629add39ba  vmovaps [rsp+0xD0], xmm14
00007b629add39c3  vmovaps [rsp+0xE0], xmm15
00007b629add39cc  sub rsp, 0x30
00007b629add39d0  movaps [rsp], xmm9
00007b629add39d5  movaps [rsp+0x10], xmm8
00007b629add39db  movaps [rsp+0x20], xmm10
00007b629add39e1  lea rdi, [rsp]
00007b629add39e5  mov esi, 0x00
00007b629add39ea  mov rax, 0x583FED93F530
00007b629add39f4  call rax
00007b629add39f6  movaps xmm9, [rsp]
00007b629add39fb  add rsp, 0x30
00007b629add39ff  vmovaps xmm0, [rsp]
00007b629add3a04  vmovaps xmm1, [rsp+0x10]
00007b629add3a0a  vmovaps xmm2, [rsp+0x20]
00007b629add3a10  vmovaps xmm3, [rsp+0x30]
00007b629add3a16  vmovaps xmm4, [rsp+0x40]
00007b629add3a1c  vmovaps xmm5, [rsp+0x50]
00007b629add3a22  vmovaps xmm6, [rsp+0x60]
00007b629add3a28  vmovaps xmm7, [rsp+0x70]
00007b629add3a2e  vmovaps xmm8, [rsp+0x80]
00007b629add3a37  vmovaps xmm10, [rsp+0x90]
00007b629add3a40  vmovaps xmm11, [rsp+0xA0]
00007b629add3a49  vmovaps xmm12, [rsp+0xB0]
00007b629add3a52  vmovaps xmm13, [rsp+0xC0]
00007b629add3a5b  vmovaps xmm14, [rsp+0xD0]
00007b629add3a64  vmovaps xmm15, [rsp+0xE0]
00007b629add3a6d  add rsp, 0xF0
00007b629add3a74  pop r11
00007b629add3a76  pop r10
00007b629add3a78  pop r9
00007b629add3a7a  pop r8
00007b629add3a7c  pop rsi
00007b629add3a7d  pop rdi
00007b629add3a7e  pop rdx
00007b629add3a7f  pop rcx
00007b629add3a80  pop rax
00007b629add3a81  add rsp, 0x08
00007b629add3a85  jmp 0x00007B629ADCFFE1
00007b629add3a8a  sub rsp, 0x08
00007b629add3a8e  push rax
00007b629add3a8f  push rcx
00007b629add3a90  push rdx
00007b629add3a91  push rdi
00007b629add3a92  push rsi
00007b629add3a93  push r8
00007b629add3a95  push r9
00007b629add3a97  push r10
00007b629add3a99  push r11
00007b629add3a9b  sub rsp, 0xF0
00007b629add3aa2  vmovaps [rsp], xmm0
00007b629add3aa7  vmovaps [rsp+0x10], xmm1
00007b629add3aad  vmovaps [rsp+0x20], xmm2
00007b629add3ab3  vmovaps [rsp+0x30], xmm3
00007b629add3ab9  vmovaps [rsp+0x40], xmm4
00007b629add3abf  vmovaps [rsp+0x50], xmm5
00007b629add3ac5  vmovaps [rsp+0x60], xmm6
00007b629add3acb  vmovaps [rsp+0x70], xmm7
00007b629add3ad1  vmovaps [rsp+0x80], xmm8
00007b629add3ada  vmovaps [rsp+0x90], xmm9
00007b629add3ae3  vmovaps [rsp+0xA0], xmm11
00007b629add3aec  vmovaps [rsp+0xB0], xmm12
00007b629add3af5  vmovaps [rsp+0xC0], xmm13
00007b629add3afe  vmovaps [rsp+0xD0], xmm14
00007b629add3b07  vmovaps [rsp+0xE0], xmm15
00007b629add3b10  sub rsp, 0x30
00007b629add3b14  movaps [rsp], xmm10
00007b629add3b19  movaps [rsp+0x10], xmm1
00007b629add3b1e  movaps [rsp+0x20], xmm11
00007b629add3b24  lea rdi, [rsp]
00007b629add3b28  mov esi, 0x00
00007b629add3b2d  mov rax, 0x583FED93F530
00007b629add3b37  call rax
00007b629add3b39  movaps xmm10, [rsp]
00007b629add3b3e  add rsp, 0x30
00007b629add3b42  vmovaps xmm0, [rsp]
00007b629add3b47  vmovaps xmm1, [rsp+0x10]
00007b629add3b4d  vmovaps xmm2, [rsp+0x20]
00007b629add3b53  vmovaps xmm3, [rsp+0x30]
00007b629add3b59  vmovaps xmm4, [rsp+0x40]
00007b629add3b5f  vmovaps xmm5, [rsp+0x50]
00007b629add3b65  vmovaps xmm6, [rsp+0x60]
00007b629add3b6b  vmovaps xmm7, [rsp+0x70]
00007b629add3b71  vmovaps xmm8, [rsp+0x80]
00007b629add3b7a  vmovaps xmm9, [rsp+0x90]
00007b629add3b83  vmovaps xmm11, [rsp+0xA0]
00007b629add3b8c  vmovaps xmm12, [rsp+0xB0]
00007b629add3b95  vmovaps xmm13, [rsp+0xC0]
00007b629add3b9e  vmovaps xmm14, [rsp+0xD0]
00007b629add3ba7  vmovaps xmm15, [rsp+0xE0]
00007b629add3bb0  add rsp, 0xF0
00007b629add3bb7  pop r11
00007b629add3bb9  pop r10
00007b629add3bbb  pop r9
00007b629add3bbd  pop r8
00007b629add3bbf  pop rsi
00007b629add3bc0  pop rdi
00007b629add3bc1  pop rdx
00007b629add3bc2  pop rcx
00007b629add3bc3  pop rax
00007b629add3bc4  add rsp, 0x08
00007b629add3bc8  jmp 0x00007B629ADCFFFC
00007b629add3bcd  sub rsp, 0x08
00007b629add3bd1  push rax
00007b629add3bd2  push rcx
00007b629add3bd3  push rdx
00007b629add3bd4  push rdi
00007b629add3bd5  push rsi
00007b629add3bd6  push r8
00007b629add3bd8  push r9
00007b629add3bda  push r10
00007b629add3bdc  push r11
00007b629add3bde  sub rsp, 0xF0
00007b629add3be5  vmovaps [rsp], xmm0
00007b629add3bea  vmovaps [rsp+0x10], xmm2
00007b629add3bf0  vmovaps [rsp+0x20], xmm3
00007b629add3bf6  vmovaps [rsp+0x30], xmm4
00007b629add3bfc  vmovaps [rsp+0x40], xmm5
00007b629add3c02  vmovaps [rsp+0x50], xmm6
00007b629add3c08  vmovaps [rsp+0x60], xmm7
00007b629add3c0e  vmovaps [rsp+0x70], xmm8
00007b629add3c14  vmovaps [rsp+0x80], xmm9
00007b629add3c1d  vmovaps [rsp+0x90], xmm10
00007b629add3c26  vmovaps [rsp+0xA0], xmm11
00007b629add3c2f  vmovaps [rsp+0xB0], xmm12
00007b629add3c38  vmovaps [rsp+0xC0], xmm13
00007b629add3c41  vmovaps [rsp+0xD0], xmm14
00007b629add3c4a  vmovaps [rsp+0xE0], xmm15
00007b629add3c53  sub rsp, 0x30
00007b629add3c57  movaps [rsp], xmm1
00007b629add3c5b  movaps [rsp+0x10], xmm14
00007b629add3c61  movaps [rsp+0x20], xmm6
00007b629add3c66  lea rdi, [rsp]
00007b629add3c6a  mov esi, 0x00
00007b629add3c6f  mov rax, 0x583FED93F530
00007b629add3c79  call rax
00007b629add3c7b  movaps xmm1, [rsp]
00007b629add3c7f  add rsp, 0x30
00007b629add3c83  vmovaps xmm0, [rsp]
00007b629add3c88  vmovaps xmm2, [rsp+0x10]
00007b629add3c8e  vmovaps xmm3, [rsp+0x20]
00007b629add3c94  vmovaps xmm4, [rsp+0x30]
00007b629add3c9a  vmovaps xmm5, [rsp+0x40]
00007b629add3ca0  vmovaps xmm6, [rsp+0x50]
00007b629add3ca6  vmovaps xmm7, [rsp+0x60]
00007b629add3cac  vmovaps xmm8, [rsp+0x70]
00007b629add3cb2  vmovaps xmm9, [rsp+0x80]
00007b629add3cbb  vmovaps xmm10, [rsp+0x90]
00007b629add3cc4  vmovaps xmm11, [rsp+0xA0]
00007b629add3ccd  vmovaps xmm12, [rsp+0xB0]
00007b629add3cd6  vmovaps xmm13, [rsp+0xC0]
00007b629add3cdf  vmovaps xmm14, [rsp+0xD0]
00007b629add3ce8  vmovaps xmm15, [rsp+0xE0]
00007b629add3cf1  add rsp, 0xF0
00007b629add3cf8  pop r11
00007b629add3cfa  pop r10
00007b629add3cfc  pop r9
00007b629add3cfe  pop r8
00007b629add3d00  pop rsi
00007b629add3d01  pop rdi
00007b629add3d02  pop rdx
00007b629add3d03  pop rcx
00007b629add3d04  pop rax
00007b629add3d05  add rsp, 0x08
00007b629add3d09  jmp 0x00007B629ADD0015
00007b629add3d0e  sub rsp, 0x08
00007b629add3d12  push rax
00007b629add3d13  push rcx
00007b629add3d14  push rdx
00007b629add3d15  push rdi
00007b629add3d16  push rsi
00007b629add3d17  push r8
00007b629add3d19  push r9
00007b629add3d1b  push r10
00007b629add3d1d  push r11
00007b629add3d1f  sub rsp, 0xF0
00007b629add3d26  vmovaps [rsp], xmm0
00007b629add3d2b  vmovaps [rsp+0x10], xmm1
00007b629add3d31  vmovaps [rsp+0x20], xmm2
00007b629add3d37  vmovaps [rsp+0x30], xmm3
00007b629add3d3d  vmovaps [rsp+0x40], xmm4
00007b629add3d43  vmovaps [rsp+0x50], xmm5
00007b629add3d49  vmovaps [rsp+0x60], xmm6
00007b629add3d4f  vmovaps [rsp+0x70], xmm7
00007b629add3d55  vmovaps [rsp+0x80], xmm8
00007b629add3d5e  vmovaps [rsp+0x90], xmm9
00007b629add3d67  vmovaps [rsp+0xA0], xmm10
00007b629add3d70  vmovaps [rsp+0xB0], xmm12
00007b629add3d79  vmovaps [rsp+0xC0], xmm13
00007b629add3d82  vmovaps [rsp+0xD0], xmm14
00007b629add3d8b  vmovaps [rsp+0xE0], xmm15
00007b629add3d94  sub rsp, 0x30
00007b629add3d98  movaps [rsp], xmm11
00007b629add3d9d  movaps [rsp+0x10], xmm13
00007b629add3da3  movaps [rsp+0x20], xmm14
00007b629add3da9  lea rdi, [rsp]
00007b629add3dad  mov esi, 0x00
00007b629add3db2  mov rax, 0x583FED93F530
00007b629add3dbc  call rax
00007b629add3dbe  movaps xmm11, [rsp]
00007b629add3dc3  add rsp, 0x30
00007b629add3dc7  vmovaps xmm0, [rsp]
00007b629add3dcc  vmovaps xmm1, [rsp+0x10]
00007b629add3dd2  vmovaps xmm2, [rsp+0x20]
00007b629add3dd8  vmovaps xmm3, [rsp+0x30]
00007b629add3dde  vmovaps xmm4, [rsp+0x40]
00007b629add3de4  vmovaps xmm5, [rsp+0x50]
00007b629add3dea  vmovaps xmm6, [rsp+0x60]
00007b629add3df0  vmovaps xmm7, [rsp+0x70]
00007b629add3df6  vmovaps xmm8, [rsp+0x80]
00007b629add3dff  vmovaps xmm9, [rsp+0x90]
00007b629add3e08  vmovaps xmm10, [rsp+0xA0]
00007b629add3e11  vmovaps xmm12, [rsp+0xB0]
00007b629add3e1a  vmovaps xmm13, [rsp+0xC0]
00007b629add3e23  vmovaps xmm14, [rsp+0xD0]
00007b629add3e2c  vmovaps xmm15, [rsp+0xE0]
00007b629add3e35  add rsp, 0xF0
00007b629add3e3c  pop r11
00007b629add3e3e  pop r10
00007b629add3e40  pop r9
00007b629add3e42  pop r8
00007b629add3e44  pop rsi
00007b629add3e45  pop rdi
00007b629add3e46  pop rdx
00007b629add3e47  pop rcx
00007b629add3e48  pop rax
00007b629add3e49  add rsp, 0x08
00007b629add3e4d  jmp 0x00007B629ADD003F
00007b629add3e52  sub rsp, 0x08
00007b629add3e56  push rax
00007b629add3e57  push rcx
00007b629add3e58  push rdx
00007b629add3e59  push rdi
00007b629add3e5a  push rsi
00007b629add3e5b  push r8
00007b629add3e5d  push r9
00007b629add3e5f  push r10
00007b629add3e61  push r11
00007b629add3e63  sub rsp, 0xF0
00007b629add3e6a  vmovaps [rsp], xmm0
00007b629add3e6f  vmovaps [rsp+0x10], xmm1
00007b629add3e75  vmovaps [rsp+0x20], xmm2
00007b629add3e7b  vmovaps [rsp+0x30], xmm3
00007b629add3e81  vmovaps [rsp+0x40], xmm4
00007b629add3e87  vmovaps [rsp+0x50], xmm5
00007b629add3e8d  vmovaps [rsp+0x60], xmm6
00007b629add3e93  vmovaps [rsp+0x70], xmm7
00007b629add3e99  vmovaps [rsp+0x80], xmm8
00007b629add3ea2  vmovaps [rsp+0x90], xmm9
00007b629add3eab  vmovaps [rsp+0xA0], xmm10
00007b629add3eb4  vmovaps [rsp+0xB0], xmm11
00007b629add3ebd  vmovaps [rsp+0xC0], xmm12
00007b629add3ec6  vmovaps [rsp+0xD0], xmm14
00007b629add3ecf  vmovaps [rsp+0xE0], xmm15
00007b629add3ed8  sub rsp, 0x30
00007b629add3edc  movaps [rsp], xmm13
00007b629add3ee1  movaps [rsp+0x10], xmm8
00007b629add3ee7  movaps [rsp+0x20], xmm14
00007b629add3eed  lea rdi, [rsp]
00007b629add3ef1  mov esi, 0x00
00007b629add3ef6  mov rax, 0x583FED93F530
00007b629add3f00  call rax
00007b629add3f02  movaps xmm13, [rsp]
00007b629add3f07  add rsp, 0x30
00007b629add3f0b  vmovaps xmm0, [rsp]
00007b629add3f10  vmovaps xmm1, [rsp+0x10]
00007b629add3f16  vmovaps xmm2, [rsp+0x20]
00007b629add3f1c  vmovaps xmm3, [rsp+0x30]
00007b629add3f22  vmovaps xmm4, [rsp+0x40]
00007b629add3f28  vmovaps xmm5, [rsp+0x50]
00007b629add3f2e  vmovaps xmm6, [rsp+0x60]
00007b629add3f34  vmovaps xmm7, [rsp+0x70]
00007b629add3f3a  vmovaps xmm8, [rsp+0x80]
00007b629add3f43  vmovaps xmm9, [rsp+0x90]
00007b629add3f4c  vmovaps xmm10, [rsp+0xA0]
00007b629add3f55  vmovaps xmm11, [rsp+0xB0]
00007b629add3f5e  vmovaps xmm12, [rsp+0xC0]
00007b629add3f67  vmovaps xmm14, [rsp+0xD0]
00007b629add3f70  vmovaps xmm15, [rsp+0xE0]
00007b629add3f79  add rsp, 0xF0
00007b629add3f80  pop r11
00007b629add3f82  pop r10
00007b629add3f84  pop r9
00007b629add3f86  pop r8
00007b629add3f88  pop rsi
00007b629add3f89  pop rdi
00007b629add3f8a  pop rdx
00007b629add3f8b  pop rcx
00007b629add3f8c  pop rax
00007b629add3f8d  add rsp, 0x08
00007b629add3f91  jmp 0x00007B629ADD006E
00007b629add3f96  sub rsp, 0x08
00007b629add3f9a  push rax
00007b629add3f9b  push rcx
00007b629add3f9c  push rdx
00007b629add3f9d  push rdi
00007b629add3f9e  push rsi
00007b629add3f9f  push r8
00007b629add3fa1  push r9
00007b629add3fa3  push r10
00007b629add3fa5  push r11
00007b629add3fa7  sub rsp, 0xF0
00007b629add3fae  vmovaps [rsp], xmm0
00007b629add3fb3  vmovaps [rsp+0x10], xmm1
00007b629add3fb9  vmovaps [rsp+0x20], xmm2
00007b629add3fbf  vmovaps [rsp+0x30], xmm3
00007b629add3fc5  vmovaps [rsp+0x40], xmm4
00007b629add3fcb  vmovaps [rsp+0x50], xmm5
00007b629add3fd1  vmovaps [rsp+0x60], xmm6
00007b629add3fd7  vmovaps [rsp+0x70], xmm7
00007b629add3fdd  vmovaps [rsp+0x80], xmm9
00007b629add3fe6  vmovaps [rsp+0x90], xmm10
00007b629add3fef  vmovaps [rsp+0xA0], xmm11
00007b629add3ff8  vmovaps [rsp+0xB0], xmm12
00007b629add4001  vmovaps [rsp+0xC0], xmm13
00007b629add400a  vmovaps [rsp+0xD0], xmm14
00007b629add4013  vmovaps [rsp+0xE0], xmm15
00007b629add401c  sub rsp, 0x30
00007b629add4020  movaps [rsp], xmm8
00007b629add4025  movaps [rsp+0x10], xmm7
00007b629add402a  movaps [rsp+0x20], xmm14
00007b629add4030  lea rdi, [rsp]
00007b629add4034  mov esi, 0x00
00007b629add4039  mov rax, 0x583FED93F530
00007b629add4043  call rax
00007b629add4045  movaps xmm8, [rsp]
00007b629add404a  add rsp, 0x30
00007b629add404e  vmovaps xmm0, [rsp]
00007b629add4053  vmovaps xmm1, [rsp+0x10]
00007b629add4059  vmovaps xmm2, [rsp+0x20]
00007b629add405f  vmovaps xmm3, [rsp+0x30]
00007b629add4065  vmovaps xmm4, [rsp+0x40]
00007b629add406b  vmovaps xmm5, [rsp+0x50]
00007b629add4071  vmovaps xmm6, [rsp+0x60]
00007b629add4077  vmovaps xmm7, [rsp+0x70]
00007b629add407d  vmovaps xmm9, [rsp+0x80]
00007b629add4086  vmovaps xmm10, [rsp+0x90]
00007b629add408f  vmovaps xmm11, [rsp+0xA0]
00007b629add4098  vmovaps xmm12, [rsp+0xB0]
00007b629add40a1  vmovaps xmm13, [rsp+0xC0]
00007b629add40aa  vmovaps xmm14, [rsp+0xD0]
00007b629add40b3  vmovaps xmm15, [rsp+0xE0]
00007b629add40bc  add rsp, 0xF0
00007b629add40c3  pop r11
00007b629add40c5  pop r10
00007b629add40c7  pop r9
00007b629add40c9  pop r8
00007b629add40cb  pop rsi
00007b629add40cc  pop rdi
00007b629add40cd  pop rdx
00007b629add40ce  pop rcx
00007b629add40cf  pop rax
00007b629add40d0  add rsp, 0x08
00007b629add40d4  jmp 0x00007B629ADD0094
00007b629add40d9  sub rsp, 0x08
00007b629add40dd  push rax
00007b629add40de  push rcx
00007b629add40df  push rdx
00007b629add40e0  push rdi
00007b629add40e1  push rsi
00007b629add40e2  push r8
00007b629add40e4  push r9
00007b629add40e6  push r10
00007b629add40e8  push r11
00007b629add40ea  sub rsp, 0xF0
00007b629add40f1  vmovaps [rsp], xmm0
00007b629add40f6  vmovaps [rsp+0x10], xmm1
00007b629add40fc  vmovaps [rsp+0x20], xmm2
00007b629add4102  vmovaps [rsp+0x30], xmm3
00007b629add4108  vmovaps [rsp+0x40], xmm4
00007b629add410e  vmovaps [rsp+0x50], xmm5
00007b629add4114  vmovaps [rsp+0x60], xmm6
00007b629add411a  vmovaps [rsp+0x70], xmm7
00007b629add4120  vmovaps [rsp+0x80], xmm8
00007b629add4129  vmovaps [rsp+0x90], xmm9
00007b629add4132  vmovaps [rsp+0xA0], xmm10
00007b629add413b  vmovaps [rsp+0xB0], xmm11
00007b629add4144  vmovaps [rsp+0xC0], xmm12
00007b629add414d  vmovaps [rsp+0xD0], xmm13
00007b629add4156  vmovaps [rsp+0xE0], xmm15
00007b629add415f  sub rsp, 0x30
00007b629add4163  movaps [rsp], xmm14
00007b629add4168  movaps [rsp+0x10], xmm12
00007b629add416e  movaps [rsp+0x20], xmm9
00007b629add4174  lea rdi, [rsp]
00007b629add4178  mov esi, 0x00
00007b629add417d  mov rax, 0x583FED93F530
00007b629add4187  call rax
00007b629add4189  movaps xmm14, [rsp]
00007b629add418e  add rsp, 0x30
00007b629add4192  vmovaps xmm0, [rsp]
00007b629add4197  vmovaps xmm1, [rsp+0x10]
00007b629add419d  vmovaps xmm2, [rsp+0x20]
00007b629add41a3  vmovaps xmm3, [rsp+0x30]
00007b629add41a9  vmovaps xmm4, [rsp+0x40]
00007b629add41af  vmovaps xmm5, [rsp+0x50]
00007b629add41b5  vmovaps xmm6, [rsp+0x60]
00007b629add41bb  vmovaps xmm7, [rsp+0x70]
00007b629add41c1  vmovaps xmm8, [rsp+0x80]
00007b629add41ca  vmovaps xmm9, [rsp+0x90]
00007b629add41d3  vmovaps xmm10, [rsp+0xA0]
00007b629add41dc  vmovaps xmm11, [rsp+0xB0]
00007b629add41e5  vmovaps xmm12, [rsp+0xC0]
00007b629add41ee  vmovaps xmm13, [rsp+0xD0]
00007b629add41f7  vmovaps xmm15, [rsp+0xE0]
00007b629add4200  add rsp, 0xF0
00007b629add4207  pop r11
00007b629add4209  pop r10
00007b629add420b  pop r9
00007b629add420d  pop r8
00007b629add420f  pop rsi
00007b629add4210  pop rdi
00007b629add4211  pop rdx
00007b629add4212  pop rcx
00007b629add4213  pop rax
00007b629add4214  add rsp, 0x08
00007b629add4218  jmp 0x00007B629ADD00AE
00007b629add421d  sub rsp, 0x08
00007b629add4221  push rax
00007b629add4222  push rcx
00007b629add4223  push rdx
00007b629add4224  push rdi
00007b629add4225  push rsi
00007b629add4226  push r8
00007b629add4228  push r9
00007b629add422a  push r10
00007b629add422c  push r11
00007b629add422e  sub rsp, 0xF0
00007b629add4235  vmovaps [rsp], xmm0
00007b629add423a  vmovaps [rsp+0x10], xmm1
00007b629add4240  vmovaps [rsp+0x20], xmm2
00007b629add4246  vmovaps [rsp+0x30], xmm3
00007b629add424c  vmovaps [rsp+0x40], xmm4
00007b629add4252  vmovaps [rsp+0x50], xmm5
00007b629add4258  vmovaps [rsp+0x60], xmm6
00007b629add425e  vmovaps [rsp+0x70], xmm7
00007b629add4264  vmovaps [rsp+0x80], xmm8
00007b629add426d  vmovaps [rsp+0x90], xmm10
00007b629add4276  vmovaps [rsp+0xA0], xmm11
00007b629add427f  vmovaps [rsp+0xB0], xmm12
00007b629add4288  vmovaps [rsp+0xC0], xmm13
00007b629add4291  vmovaps [rsp+0xD0], xmm14
00007b629add429a  vmovaps [rsp+0xE0], xmm15
00007b629add42a3  sub rsp, 0x30
00007b629add42a7  movaps [rsp], xmm9
00007b629add42ac  movaps [rsp+0x10], xmm7
00007b629add42b1  movaps [rsp+0x20], xmm12
00007b629add42b7  lea rdi, [rsp]
00007b629add42bb  mov esi, 0x00
00007b629add42c0  mov rax, 0x583FED93F530
00007b629add42ca  call rax
00007b629add42cc  movaps xmm9, [rsp]
00007b629add42d1  add rsp, 0x30
00007b629add42d5  vmovaps xmm0, [rsp]
00007b629add42da  vmovaps xmm1, [rsp+0x10]
00007b629add42e0  vmovaps xmm2, [rsp+0x20]
00007b629add42e6  vmovaps xmm3, [rsp+0x30]
00007b629add42ec  vmovaps xmm4, [rsp+0x40]
00007b629add42f2  vmovaps xmm5, [rsp+0x50]
00007b629add42f8  vmovaps xmm6, [rsp+0x60]
00007b629add42fe  vmovaps xmm7, [rsp+0x70]
00007b629add4304  vmovaps xmm8, [rsp+0x80]
00007b629add430d  vmovaps xmm10, [rsp+0x90]
00007b629add4316  vmovaps xmm11, [rsp+0xA0]
00007b629add431f  vmovaps xmm12, [rsp+0xB0]
00007b629add4328  vmovaps xmm13, [rsp+0xC0]
00007b629add4331  vmovaps xmm14, [rsp+0xD0]
00007b629add433a  vmovaps xmm15, [rsp+0xE0]
00007b629add4343  add rsp, 0xF0
00007b629add434a  pop r11
00007b629add434c  pop r10
00007b629add434e  pop r9
00007b629add4350  pop r8
00007b629add4352  pop rsi
00007b629add4353  pop rdi
00007b629add4354  pop rdx
00007b629add4355  pop rcx
00007b629add4356  pop rax
00007b629add4357  add rsp, 0x08
00007b629add435b  jmp 0x00007B629ADD00DD
00007b629add4360  sub rsp, 0x08
00007b629add4364  push rax
00007b629add4365  push rcx
00007b629add4366  push rdx
00007b629add4367  push rdi
00007b629add4368  push rsi
00007b629add4369  push r8
00007b629add436b  push r9
00007b629add436d  push r10
00007b629add436f  push r11
00007b629add4371  sub rsp, 0xF0
00007b629add4378  vmovaps [rsp], xmm0
00007b629add437d  vmovaps [rsp+0x10], xmm1
00007b629add4383  vmovaps [rsp+0x20], xmm2
00007b629add4389  vmovaps [rsp+0x30], xmm3
00007b629add438f  vmovaps [rsp+0x40], xmm4
00007b629add4395  vmovaps [rsp+0x50], xmm5
00007b629add439b  vmovaps [rsp+0x60], xmm6
00007b629add43a1  vmovaps [rsp+0x70], xmm7
00007b629add43a7  vmovaps [rsp+0x80], xmm8
00007b629add43b0  vmovaps [rsp+0x90], xmm9
00007b629add43b9  vmovaps [rsp+0xA0], xmm10
00007b629add43c2  vmovaps [rsp+0xB0], xmm11
00007b629add43cb  vmovaps [rsp+0xC0], xmm13
00007b629add43d4  vmovaps [rsp+0xD0], xmm14
00007b629add43dd  vmovaps [rsp+0xE0], xmm15
00007b629add43e6  sub rsp, 0x30
00007b629add43ea  movaps [rsp], xmm12
00007b629add43ef  movaps [rsp+0x10], xmm15
00007b629add43f5  movaps [rsp+0x20], xmm11
00007b629add43fb  lea rdi, [rsp]
00007b629add43ff  mov esi, 0x00
00007b629add4404  mov rax, 0x583FED93F530
00007b629add440e  call rax
00007b629add4410  movaps xmm12, [rsp]
00007b629add4415  add rsp, 0x30
00007b629add4419  vmovaps xmm0, [rsp]
00007b629add441e  vmovaps xmm1, [rsp+0x10]
00007b629add4424  vmovaps xmm2, [rsp+0x20]
00007b629add442a  vmovaps xmm3, [rsp+0x30]
00007b629add4430  vmovaps xmm4, [rsp+0x40]
00007b629add4436  vmovaps xmm5, [rsp+0x50]
00007b629add443c  vmovaps xmm6, [rsp+0x60]
00007b629add4442  vmovaps xmm7, [rsp+0x70]
00007b629add4448  vmovaps xmm8, [rsp+0x80]
00007b629add4451  vmovaps xmm9, [rsp+0x90]
00007b629add445a  vmovaps xmm10, [rsp+0xA0]
00007b629add4463  vmovaps xmm11, [rsp+0xB0]
00007b629add446c  vmovaps xmm13, [rsp+0xC0]
00007b629add4475  vmovaps xmm14, [rsp+0xD0]
00007b629add447e  vmovaps xmm15, [rsp+0xE0]
00007b629add4487  add rsp, 0xF0
00007b629add448e  pop r11
00007b629add4490  pop r10
00007b629add4492  pop r9
00007b629add4494  pop r8
00007b629add4496  pop rsi
00007b629add4497  pop rdi
00007b629add4498  pop rdx
00007b629add4499  pop rcx
00007b629add449a  pop rax
00007b629add449b  add rsp, 0x08
00007b629add449f  jmp 0x00007B629ADD00F7
00007b629add44a4  sub rsp, 0x08
00007b629add44a8  push rax
00007b629add44a9  push rcx
00007b629add44aa  push rdx
00007b629add44ab  push rdi
00007b629add44ac  push rsi
00007b629add44ad  push r8
00007b629add44af  push r9
00007b629add44b1  push r10
00007b629add44b3  push r11
00007b629add44b5  sub rsp, 0xF0
00007b629add44bc  vmovaps [rsp], xmm0
00007b629add44c1  vmovaps [rsp+0x10], xmm1
00007b629add44c7  vmovaps [rsp+0x20], xmm2
00007b629add44cd  vmovaps [rsp+0x30], xmm3
00007b629add44d3  vmovaps [rsp+0x40], xmm4
00007b629add44d9  vmovaps [rsp+0x50], xmm5
00007b629add44df  vmovaps [rsp+0x60], xmm6
00007b629add44e5  vmovaps [rsp+0x70], xmm7
00007b629add44eb  vmovaps [rsp+0x80], xmm8
00007b629add44f4  vmovaps [rsp+0x90], xmm9
00007b629add44fd  vmovaps [rsp+0xA0], xmm10
00007b629add4506  vmovaps [rsp+0xB0], xmm12
00007b629add450f  vmovaps [rsp+0xC0], xmm13
00007b629add4518  vmovaps [rsp+0xD0], xmm14
00007b629add4521  vmovaps [rsp+0xE0], xmm15
00007b629add452a  sub rsp, 0x30
00007b629add452e  movaps [rsp], xmm11
00007b629add4533  movaps [rsp+0x10], xmm7
00007b629add4538  movaps [rsp+0x20], xmm15
00007b629add453e  lea rdi, [rsp]
00007b629add4542  mov esi, 0x00
00007b629add4547  mov rax, 0x583FED93F530
00007b629add4551  call rax
00007b629add4553  movaps xmm11, [rsp]
00007b629add4558  add rsp, 0x30
00007b629add455c  vmovaps xmm0, [rsp]
00007b629add4561  vmovaps xmm1, [rsp+0x10]
00007b629add4567  vmovaps xmm2, [rsp+0x20]
00007b629add456d  vmovaps xmm3, [rsp+0x30]
00007b629add4573  vmovaps xmm4, [rsp+0x40]
00007b629add4579  vmovaps xmm5, [rsp+0x50]
00007b629add457f  vmovaps xmm6, [rsp+0x60]
00007b629add4585  vmovaps xmm7, [rsp+0x70]
00007b629add458b  vmovaps xmm8, [rsp+0x80]
00007b629add4594  vmovaps xmm9, [rsp+0x90]
00007b629add459d  vmovaps xmm10, [rsp+0xA0]
00007b629add45a6  vmovaps xmm12, [rsp+0xB0]
00007b629add45af  vmovaps xmm13, [rsp+0xC0]
00007b629add45b8  vmovaps xmm14, [rsp+0xD0]
00007b629add45c1  vmovaps xmm15, [rsp+0xE0]
00007b629add45ca  add rsp, 0xF0
00007b629add45d1  pop r11
00007b629add45d3  pop r10
00007b629add45d5  pop r9
00007b629add45d7  pop r8
00007b629add45d9  pop rsi
00007b629add45da  pop rdi
00007b629add45db  pop rdx
00007b629add45dc  pop rcx
00007b629add45dd  pop rax
00007b629add45de  add rsp, 0x08
00007b629add45e2  jmp 0x00007B629ADD0123
00007b629add45e7  sub rsp, 0x08
00007b629add45eb  push rax
00007b629add45ec  push rcx
00007b629add45ed  push rdx
00007b629add45ee  push rdi
00007b629add45ef  push rsi
00007b629add45f0  push r8
00007b629add45f2  push r9
00007b629add45f4  push r10
00007b629add45f6  push r11
00007b629add45f8  sub rsp, 0xF0
00007b629add45ff  vmovaps [rsp], xmm0
00007b629add4604  vmovaps [rsp+0x10], xmm1
00007b629add460a  vmovaps [rsp+0x20], xmm2
00007b629add4610  vmovaps [rsp+0x30], xmm3
00007b629add4616  vmovaps [rsp+0x40], xmm4
00007b629add461c  vmovaps [rsp+0x50], xmm5
00007b629add4622  vmovaps [rsp+0x60], xmm6
00007b629add4628  vmovaps [rsp+0x70], xmm7
00007b629add462e  vmovaps [rsp+0x80], xmm8
00007b629add4637  vmovaps [rsp+0x90], xmm9
00007b629add4640  vmovaps [rsp+0xA0], xmm10
00007b629add4649  vmovaps [rsp+0xB0], xmm11
00007b629add4652  vmovaps [rsp+0xC0], xmm12
00007b629add465b  vmovaps [rsp+0xD0], xmm13
00007b629add4664  vmovaps [rsp+0xE0], xmm14
00007b629add466d  sub rsp, 0x30
00007b629add4671  movaps [rsp], xmm15
00007b629add4676  movaps [rsp+0x10], xmm10
00007b629add467c  movaps [rsp+0x20], xmm13
00007b629add4682  lea rdi, [rsp]
00007b629add4686  mov esi, 0x00
00007b629add468b  mov rax, 0x583FED93F530
00007b629add4695  call rax
00007b629add4697  movaps xmm15, [rsp]
00007b629add469c  add rsp, 0x30
00007b629add46a0  vmovaps xmm0, [rsp]
00007b629add46a5  vmovaps xmm1, [rsp+0x10]
00007b629add46ab  vmovaps xmm2, [rsp+0x20]
00007b629add46b1  vmovaps xmm3, [rsp+0x30]
00007b629add46b7  vmovaps xmm4, [rsp+0x40]
00007b629add46bd  vmovaps xmm5, [rsp+0x50]
00007b629add46c3  vmovaps xmm6, [rsp+0x60]
00007b629add46c9  vmovaps xmm7, [rsp+0x70]
00007b629add46cf  vmovaps xmm8, [rsp+0x80]
00007b629add46d8  vmovaps xmm9, [rsp+0x90]
00007b629add46e1  vmovaps xmm10, [rsp+0xA0]
00007b629add46ea  vmovaps xmm11, [rsp+0xB0]
00007b629add46f3  vmovaps xmm12, [rsp+0xC0]
00007b629add46fc  vmovaps xmm13, [rsp+0xD0]
00007b629add4705  vmovaps xmm14, [rsp+0xE0]
00007b629add470e  add rsp, 0xF0
00007b629add4715  pop r11
00007b629add4717  pop r10
00007b629add4719  pop r9
00007b629add471b  pop r8
00007b629add471d  pop rsi
00007b629add471e  pop rdi
00007b629add471f  pop rdx
00007b629add4720  pop rcx
00007b629add4721  pop rax
00007b629add4722  add rsp, 0x08
00007b629add4726  jmp 0x00007B629ADD013D
00007b629add472b  sub rsp, 0x08
00007b629add472f  push rax
00007b629add4730  push rcx
00007b629add4731  push rdx
00007b629add4732  push rdi
00007b629add4733  push rsi
00007b629add4734  push r8
00007b629add4736  push r9
00007b629add4738  push r10
00007b629add473a  push r11
00007b629add473c  sub rsp, 0xF0
00007b629add4743  vmovaps [rsp], xmm0
00007b629add4748  vmovaps [rsp+0x10], xmm1
00007b629add474e  vmovaps [rsp+0x20], xmm2
00007b629add4754  vmovaps [rsp+0x30], xmm3
00007b629add475a  vmovaps [rsp+0x40], xmm4
00007b629add4760  vmovaps [rsp+0x50], xmm5
00007b629add4766  vmovaps [rsp+0x60], xmm6
00007b629add476c  vmovaps [rsp+0x70], xmm7
00007b629add4772  vmovaps [rsp+0x80], xmm8
00007b629add477b  vmovaps [rsp+0x90], xmm9
00007b629add4784  vmovaps [rsp+0xA0], xmm11
00007b629add478d  vmovaps [rsp+0xB0], xmm12
00007b629add4796  vmovaps [rsp+0xC0], xmm13
00007b629add479f  vmovaps [rsp+0xD0], xmm14
00007b629add47a8  vmovaps [rsp+0xE0], xmm15
00007b629add47b1  sub rsp, 0x30
00007b629add47b5  movaps [rsp], xmm10
00007b629add47ba  movaps [rsp+0x10], xmm7
00007b629add47bf  movaps [rsp+0x20], xmm13
00007b629add47c5  lea rdi, [rsp]
00007b629add47c9  mov esi, 0x00
00007b629add47ce  mov rax, 0x583FED93F530
00007b629add47d8  call rax
00007b629add47da  movaps xmm10, [rsp]
00007b629add47df  add rsp, 0x30
00007b629add47e3  vmovaps xmm0, [rsp]
00007b629add47e8  vmovaps xmm1, [rsp+0x10]
00007b629add47ee  vmovaps xmm2, [rsp+0x20]
00007b629add47f4  vmovaps xmm3, [rsp+0x30]
00007b629add47fa  vmovaps xmm4, [rsp+0x40]
00007b629add4800  vmovaps xmm5, [rsp+0x50]
00007b629add4806  vmovaps xmm6, [rsp+0x60]
00007b629add480c  vmovaps xmm7, [rsp+0x70]
00007b629add4812  vmovaps xmm8, [rsp+0x80]
00007b629add481b  vmovaps xmm9, [rsp+0x90]
00007b629add4824  vmovaps xmm11, [rsp+0xA0]
00007b629add482d  vmovaps xmm12, [rsp+0xB0]
00007b629add4836  vmovaps xmm13, [rsp+0xC0]
00007b629add483f  vmovaps xmm14, [rsp+0xD0]
00007b629add4848  vmovaps xmm15, [rsp+0xE0]
00007b629add4851  add rsp, 0xF0
00007b629add4858  pop r11
00007b629add485a  pop r10
00007b629add485c  pop r9
00007b629add485e  pop r8
00007b629add4860  pop rsi
00007b629add4861  pop rdi
00007b629add4862  pop rdx
00007b629add4863  pop rcx
00007b629add4864  pop rax
00007b629add4865  add rsp, 0x08
00007b629add4869  jmp 0x00007B629ADD0169
00007b629add486e  sub rsp, 0x08
00007b629add4872  push rax
00007b629add4873  push rcx
00007b629add4874  push rdx
00007b629add4875  push rdi
00007b629add4876  push rsi
00007b629add4877  push r8
00007b629add4879  push r9
00007b629add487b  push r10
00007b629add487d  push r11
00007b629add487f  sub rsp, 0xF0
00007b629add4886  vmovaps [rsp], xmm0
00007b629add488b  vmovaps [rsp+0x10], xmm1
00007b629add4891  vmovaps [rsp+0x20], xmm2
00007b629add4897  vmovaps [rsp+0x30], xmm3
00007b629add489d  vmovaps [rsp+0x40], xmm4
00007b629add48a3  vmovaps [rsp+0x50], xmm5
00007b629add48a9  vmovaps [rsp+0x60], xmm6
00007b629add48af  vmovaps [rsp+0x70], xmm7
00007b629add48b5  vmovaps [rsp+0x80], xmm8
00007b629add48be  vmovaps [rsp+0x90], xmm9
00007b629add48c7  vmovaps [rsp+0xA0], xmm10
00007b629add48d0  vmovaps [rsp+0xB0], xmm11
00007b629add48d9  vmovaps [rsp+0xC0], xmm12
00007b629add48e2  vmovaps [rsp+0xD0], xmm14
00007b629add48eb  vmovaps [rsp+0xE0], xmm15
00007b629add48f4  sub rsp, 0x30
00007b629add48f8  movaps [rsp], xmm13
00007b629add48fd  movaps [rsp+0x10], xmm1
00007b629add4902  movaps [rsp+0x20], xmm8
00007b629add4908  lea rdi, [rsp]
00007b629add490c  mov esi, 0x00
00007b629add4911  mov rax, 0x583FED93F530
00007b629add491b  call rax
00007b629add491d  movaps xmm13, [rsp]
00007b629add4922  add rsp, 0x30
00007b629add4926  vmovaps xmm0, [rsp]
00007b629add492b  vmovaps xmm1, [rsp+0x10]
00007b629add4931  vmovaps xmm2, [rsp+0x20]
00007b629add4937  vmovaps xmm3, [rsp+0x30]
00007b629add493d  vmovaps xmm4, [rsp+0x40]
00007b629add4943  vmovaps xmm5, [rsp+0x50]
00007b629add4949  vmovaps xmm6, [rsp+0x60]
00007b629add494f  vmovaps xmm7, [rsp+0x70]
00007b629add4955  vmovaps xmm8, [rsp+0x80]
00007b629add495e  vmovaps xmm9, [rsp+0x90]
00007b629add4967  vmovaps xmm10, [rsp+0xA0]
00007b629add4970  vmovaps xmm11, [rsp+0xB0]
00007b629add4979  vmovaps xmm12, [rsp+0xC0]
00007b629add4982  vmovaps xmm14, [rsp+0xD0]
00007b629add498b  vmovaps xmm15, [rsp+0xE0]
00007b629add4994  add rsp, 0xF0
00007b629add499b  pop r11
00007b629add499d  pop r10
00007b629add499f  pop r9
00007b629add49a1  pop r8
00007b629add49a3  pop rsi
00007b629add49a4  pop rdi
00007b629add49a5  pop rdx
00007b629add49a6  pop rcx
00007b629add49a7  pop rax
00007b629add49a8  add rsp, 0x08
00007b629add49ac  jmp 0x00007B629ADD0183
00007b629add49b1  call 0x00007B629ABFF430
00007b629add49b6  jmp 0x00007B629ADD018D
00007b629add49bb  sub rsp, 0x08
00007b629add49bf  push rax
00007b629add49c0  push rcx
00007b629add49c1  push rdx
00007b629add49c2  push rdi
00007b629add49c3  push rsi
00007b629add49c4  push r8
00007b629add49c6  push r9
00007b629add49c8  push r10
00007b629add49ca  push r11
00007b629add49cc  sub rsp, 0xF0
00007b629add49d3  vmovaps [rsp], xmm0
00007b629add49d8  vmovaps [rsp+0x10], xmm1
00007b629add49de  vmovaps [rsp+0x20], xmm2
00007b629add49e4  vmovaps [rsp+0x30], xmm3
00007b629add49ea  vmovaps [rsp+0x40], xmm4
00007b629add49f0  vmovaps [rsp+0x50], xmm5
00007b629add49f6  vmovaps [rsp+0x60], xmm6
00007b629add49fc  vmovaps [rsp+0x70], xmm7
00007b629add4a02  vmovaps [rsp+0x80], xmm9
00007b629add4a0b  vmovaps [rsp+0x90], xmm10
00007b629add4a14  vmovaps [rsp+0xA0], xmm11
00007b629add4a1d  vmovaps [rsp+0xB0], xmm12
00007b629add4a26  vmovaps [rsp+0xC0], xmm13
00007b629add4a2f  vmovaps [rsp+0xD0], xmm14
00007b629add4a38  vmovaps [rsp+0xE0], xmm15
00007b629add4a41  sub rsp, 0x30
00007b629add4a45  movaps [rsp], xmm8
00007b629add4a4a  movaps [rsp+0x10], xmm14
00007b629add4a50  movaps [rsp+0x20], xmm9
00007b629add4a56  lea rdi, [rsp]
00007b629add4a5a  mov esi, 0x00
00007b629add4a5f  mov rax, 0x583FED93F530
00007b629add4a69  call rax
00007b629add4a6b  movaps xmm8, [rsp]
00007b629add4a70  add rsp, 0x30
00007b629add4a74  vmovaps xmm0, [rsp]
00007b629add4a79  vmovaps xmm1, [rsp+0x10]
00007b629add4a7f  vmovaps xmm2, [rsp+0x20]
00007b629add4a85  vmovaps xmm3, [rsp+0x30]
00007b629add4a8b  vmovaps xmm4, [rsp+0x40]
00007b629add4a91  vmovaps xmm5, [rsp+0x50]
00007b629add4a97  vmovaps xmm6, [rsp+0x60]
00007b629add4a9d  vmovaps xmm7, [rsp+0x70]
00007b629add4aa3  vmovaps xmm9, [rsp+0x80]
00007b629add4aac  vmovaps xmm10, [rsp+0x90]
00007b629add4ab5  vmovaps xmm11, [rsp+0xA0]
00007b629add4abe  vmovaps xmm12, [rsp+0xB0]
00007b629add4ac7  vmovaps xmm13, [rsp+0xC0]
00007b629add4ad0  vmovaps xmm14, [rsp+0xD0]
00007b629add4ad9  vmovaps xmm15, [rsp+0xE0]
00007b629add4ae2  add rsp, 0xF0
00007b629add4ae9  pop r11
00007b629add4aeb  pop r10
00007b629add4aed  pop r9
00007b629add4aef  pop r8
00007b629add4af1  pop rsi
00007b629add4af2  pop rdi
00007b629add4af3  pop rdx
00007b629add4af4  pop rcx
00007b629add4af5  pop rax
00007b629add4af6  add rsp, 0x08
00007b629add4afa  jmp 0x00007B629ADD01AF
00007b629add4aff  sub rsp, 0x08
00007b629add4b03  push rax
00007b629add4b04  push rcx
00007b629add4b05  push rdx
00007b629add4b06  push rdi
00007b629add4b07  push rsi
00007b629add4b08  push r8
00007b629add4b0a  push r9
00007b629add4b0c  push r10
00007b629add4b0e  push r11
00007b629add4b10  sub rsp, 0xF0
00007b629add4b17  vmovaps [rsp], xmm0
00007b629add4b1c  vmovaps [rsp+0x10], xmm1
00007b629add4b22  vmovaps [rsp+0x20], xmm2
00007b629add4b28  vmovaps [rsp+0x30], xmm3
00007b629add4b2e  vmovaps [rsp+0x40], xmm4
00007b629add4b34  vmovaps [rsp+0x50], xmm5
00007b629add4b3a  vmovaps [rsp+0x60], xmm6
00007b629add4b40  vmovaps [rsp+0x70], xmm7
00007b629add4b46  vmovaps [rsp+0x80], xmm8
00007b629add4b4f  vmovaps [rsp+0x90], xmm10
00007b629add4b58  vmovaps [rsp+0xA0], xmm11
00007b629add4b61  vmovaps [rsp+0xB0], xmm12
00007b629add4b6a  vmovaps [rsp+0xC0], xmm13
00007b629add4b73  vmovaps [rsp+0xD0], xmm14
00007b629add4b7c  vmovaps [rsp+0xE0], xmm15
00007b629add4b85  sub rsp, 0x30
00007b629add4b89  movaps [rsp], xmm9
00007b629add4b8e  movaps [rsp+0x10], xmm1
00007b629add4b93  movaps [rsp+0x20], xmm14
00007b629add4b99  lea rdi, [rsp]
00007b629add4b9d  mov esi, 0x00
00007b629add4ba2  mov rax, 0x583FED93F530
00007b629add4bac  call rax
00007b629add4bae  movaps xmm9, [rsp]
00007b629add4bb3  add rsp, 0x30
00007b629add4bb7  vmovaps xmm0, [rsp]
00007b629add4bbc  vmovaps xmm1, [rsp+0x10]
00007b629add4bc2  vmovaps xmm2, [rsp+0x20]
00007b629add4bc8  vmovaps xmm3, [rsp+0x30]
00007b629add4bce  vmovaps xmm4, [rsp+0x40]
00007b629add4bd4  vmovaps xmm5, [rsp+0x50]
00007b629add4bda  vmovaps xmm6, [rsp+0x60]
00007b629add4be0  vmovaps xmm7, [rsp+0x70]
00007b629add4be6  vmovaps xmm8, [rsp+0x80]
00007b629add4bef  vmovaps xmm10, [rsp+0x90]
00007b629add4bf8  vmovaps xmm11, [rsp+0xA0]
00007b629add4c01  vmovaps xmm12, [rsp+0xB0]
00007b629add4c0a  vmovaps xmm13, [rsp+0xC0]
00007b629add4c13  vmovaps xmm14, [rsp+0xD0]
00007b629add4c1c  vmovaps xmm15, [rsp+0xE0]
00007b629add4c25  add rsp, 0xF0
00007b629add4c2c  pop r11
00007b629add4c2e  pop r10
00007b629add4c30  pop r9
00007b629add4c32  pop r8
00007b629add4c34  pop rsi
00007b629add4c35  pop rdi
00007b629add4c36  pop rdx
00007b629add4c37  pop rcx
00007b629add4c38  pop rax
00007b629add4c39  add rsp, 0x08
00007b629add4c3d  jmp 0x00007B629ADD01DD
00007b629add4c42  sub rsp, 0x08
00007b629add4c46  push rax
00007b629add4c47  push rcx
00007b629add4c48  push rdx
00007b629add4c49  push rdi
00007b629add4c4a  push rsi
00007b629add4c4b  push r8
00007b629add4c4d  push r9
00007b629add4c4f  push r10
00007b629add4c51  push r11
00007b629add4c53  sub rsp, 0xF0
00007b629add4c5a  vmovaps [rsp], xmm0
00007b629add4c5f  vmovaps [rsp+0x10], xmm1
00007b629add4c65  vmovaps [rsp+0x20], xmm2
00007b629add4c6b  vmovaps [rsp+0x30], xmm3
00007b629add4c71  vmovaps [rsp+0x40], xmm4
00007b629add4c77  vmovaps [rsp+0x50], xmm5
00007b629add4c7d  vmovaps [rsp+0x60], xmm6
00007b629add4c83  vmovaps [rsp+0x70], xmm7
00007b629add4c89  vmovaps [rsp+0x80], xmm8
00007b629add4c92  vmovaps [rsp+0x90], xmm9
00007b629add4c9b  vmovaps [rsp+0xA0], xmm10
00007b629add4ca4  vmovaps [rsp+0xB0], xmm11
00007b629add4cad  vmovaps [rsp+0xC0], xmm12
00007b629add4cb6  vmovaps [rsp+0xD0], xmm13
00007b629add4cbf  vmovaps [rsp+0xE0], xmm15
00007b629add4cc8  sub rsp, 0x30
00007b629add4ccc  movaps [rsp], xmm14
00007b629add4cd1  movaps [rsp+0x10], xmm4
00007b629add4cd6  movaps [rsp+0x20], xmm1
00007b629add4cdb  lea rdi, [rsp]
00007b629add4cdf  mov esi, 0x00
00007b629add4ce4  mov rax, 0x583FED93F530
00007b629add4cee  call rax
00007b629add4cf0  movaps xmm14, [rsp]
00007b629add4cf5  add rsp, 0x30
00007b629add4cf9  vmovaps xmm0, [rsp]
00007b629add4cfe  vmovaps xmm1, [rsp+0x10]
00007b629add4d04  vmovaps xmm2, [rsp+0x20]
00007b629add4d0a  vmovaps xmm3, [rsp+0x30]
00007b629add4d10  vmovaps xmm4, [rsp+0x40]
00007b629add4d16  vmovaps xmm5, [rsp+0x50]
00007b629add4d1c  vmovaps xmm6, [rsp+0x60]
00007b629add4d22  vmovaps xmm7, [rsp+0x70]
00007b629add4d28  vmovaps xmm8, [rsp+0x80]
00007b629add4d31  vmovaps xmm9, [rsp+0x90]
00007b629add4d3a  vmovaps xmm10, [rsp+0xA0]
00007b629add4d43  vmovaps xmm11, [rsp+0xB0]
00007b629add4d4c  vmovaps xmm12, [rsp+0xC0]
00007b629add4d55  vmovaps xmm13, [rsp+0xD0]
00007b629add4d5e  vmovaps xmm15, [rsp+0xE0]
00007b629add4d67  add rsp, 0xF0
00007b629add4d6e  pop r11
00007b629add4d70  pop r10
00007b629add4d72  pop r9
00007b629add4d74  pop r8
00007b629add4d76  pop rsi
00007b629add4d77  pop rdi
00007b629add4d78  pop rdx
00007b629add4d79  pop rcx
00007b629add4d7a  pop rax
00007b629add4d7b  add rsp, 0x08
00007b629add4d7f  jmp 0x00007B629ADD0203
00007b629add4d84  sub rsp, 0x08
00007b629add4d88  push rax
00007b629add4d89  push rcx
00007b629add4d8a  push rdx
00007b629add4d8b  push rdi
00007b629add4d8c  push rsi
00007b629add4d8d  push r8
00007b629add4d8f  push r9
00007b629add4d91  push r10
00007b629add4d93  push r11
00007b629add4d95  sub rsp, 0xF0
00007b629add4d9c  vmovaps [rsp], xmm0
00007b629add4da1  vmovaps [rsp+0x10], xmm2
00007b629add4da7  vmovaps [rsp+0x20], xmm3
00007b629add4dad  vmovaps [rsp+0x30], xmm4
00007b629add4db3  vmovaps [rsp+0x40], xmm5
00007b629add4db9  vmovaps [rsp+0x50], xmm6
00007b629add4dbf  vmovaps [rsp+0x60], xmm7
00007b629add4dc5  vmovaps [rsp+0x70], xmm8
00007b629add4dcb  vmovaps [rsp+0x80], xmm9
00007b629add4dd4  vmovaps [rsp+0x90], xmm10
00007b629add4ddd  vmovaps [rsp+0xA0], xmm11
00007b629add4de6  vmovaps [rsp+0xB0], xmm12
00007b629add4def  vmovaps [rsp+0xC0], xmm13
00007b629add4df8  vmovaps [rsp+0xD0], xmm14
00007b629add4e01  vmovaps [rsp+0xE0], xmm15
00007b629add4e0a  sub rsp, 0x30
00007b629add4e0e  movaps [rsp], xmm1
00007b629add4e12  movaps [rsp+0x10], xmm12
00007b629add4e18  movaps [rsp+0x20], xmm11
00007b629add4e1e  lea rdi, [rsp]
00007b629add4e22  mov esi, 0x00
00007b629add4e27  mov rax, 0x583FED93F530
00007b629add4e31  call rax
00007b629add4e33  movaps xmm1, [rsp]
00007b629add4e37  add rsp, 0x30
00007b629add4e3b  vmovaps xmm0, [rsp]
00007b629add4e40  vmovaps xmm2, [rsp+0x10]
00007b629add4e46  vmovaps xmm3, [rsp+0x20]
00007b629add4e4c  vmovaps xmm4, [rsp+0x30]
00007b629add4e52  vmovaps xmm5, [rsp+0x40]
00007b629add4e58  vmovaps xmm6, [rsp+0x50]
00007b629add4e5e  vmovaps xmm7, [rsp+0x60]
00007b629add4e64  vmovaps xmm8, [rsp+0x70]
00007b629add4e6a  vmovaps xmm9, [rsp+0x80]
00007b629add4e73  vmovaps xmm10, [rsp+0x90]
00007b629add4e7c  vmovaps xmm11, [rsp+0xA0]
00007b629add4e85  vmovaps xmm12, [rsp+0xB0]
00007b629add4e8e  vmovaps xmm13, [rsp+0xC0]
00007b629add4e97  vmovaps xmm14, [rsp+0xD0]
00007b629add4ea0  vmovaps xmm15, [rsp+0xE0]
00007b629add4ea9  add rsp, 0xF0
00007b629add4eb0  pop r11
00007b629add4eb2  pop r10
00007b629add4eb4  pop r9
00007b629add4eb6  pop r8
00007b629add4eb8  pop rsi
00007b629add4eb9  pop rdi
00007b629add4eba  pop rdx
00007b629add4ebb  pop rcx
00007b629add4ebc  pop rax
00007b629add4ebd  add rsp, 0x08
00007b629add4ec1  jmp 0x00007B629ADD0224
00007b629add4ec6  call 0x00007B629ACE20A0
00007b629add4ecb  jmp 0x00007B629ADD0232
00007b629add4ed0  call 0x00007B629AC09D70
00007b629add4ed5  jmp 0x00007B629ADD023C
00007b629add4eda  sub rsp, 0x08
00007b629add4ede  push rax
00007b629add4edf  push rcx
00007b629add4ee0  push rdx
00007b629add4ee1  push rdi
00007b629add4ee2  push rsi
00007b629add4ee3  push r8
00007b629add4ee5  push r9
00007b629add4ee7  push r10
00007b629add4ee9  push r11
00007b629add4eeb  sub rsp, 0xF0
00007b629add4ef2  vmovaps [rsp], xmm0
00007b629add4ef7  vmovaps [rsp+0x10], xmm1
00007b629add4efd  vmovaps [rsp+0x20], xmm2
00007b629add4f03  vmovaps [rsp+0x30], xmm3
00007b629add4f09  vmovaps [rsp+0x40], xmm4
00007b629add4f0f  vmovaps [rsp+0x50], xmm5
00007b629add4f15  vmovaps [rsp+0x60], xmm6
00007b629add4f1b  vmovaps [rsp+0x70], xmm8
00007b629add4f21  vmovaps [rsp+0x80], xmm9
00007b629add4f2a  vmovaps [rsp+0x90], xmm10
00007b629add4f33  vmovaps [rsp+0xA0], xmm11
00007b629add4f3c  vmovaps [rsp+0xB0], xmm12
00007b629add4f45  vmovaps [rsp+0xC0], xmm13
00007b629add4f4e  vmovaps [rsp+0xD0], xmm14
00007b629add4f57  vmovaps [rsp+0xE0], xmm15
00007b629add4f60  sub rsp, 0x30
00007b629add4f64  movaps [rsp], xmm7
00007b629add4f68  movaps [rsp+0x10], xmm15
00007b629add4f6e  movaps [rsp+0x20], xmm10
00007b629add4f74  lea rdi, [rsp]
00007b629add4f78  mov esi, 0x00
00007b629add4f7d  mov rax, 0x583FED93F530
00007b629add4f87  call rax
00007b629add4f89  movaps xmm7, [rsp]
00007b629add4f8d  add rsp, 0x30
00007b629add4f91  vmovaps xmm0, [rsp]
00007b629add4f96  vmovaps xmm1, [rsp+0x10]
00007b629add4f9c  vmovaps xmm2, [rsp+0x20]
00007b629add4fa2  vmovaps xmm3, [rsp+0x30]
00007b629add4fa8  vmovaps xmm4, [rsp+0x40]
00007b629add4fae  vmovaps xmm5, [rsp+0x50]
00007b629add4fb4  vmovaps xmm6, [rsp+0x60]
00007b629add4fba  vmovaps xmm8, [rsp+0x70]
00007b629add4fc0  vmovaps xmm9, [rsp+0x80]
00007b629add4fc9  vmovaps xmm10, [rsp+0x90]
00007b629add4fd2  vmovaps xmm11, [rsp+0xA0]
00007b629add4fdb  vmovaps xmm12, [rsp+0xB0]
00007b629add4fe4  vmovaps xmm13, [rsp+0xC0]
00007b629add4fed  vmovaps xmm14, [rsp+0xD0]
00007b629add4ff6  vmovaps xmm15, [rsp+0xE0]
00007b629add4fff  add rsp, 0xF0
00007b629add5006  pop r11
00007b629add5008  pop r10
00007b629add500a  pop r9
00007b629add500c  pop r8
00007b629add500e  pop rsi
00007b629add500f  pop rdi
00007b629add5010  pop rdx
00007b629add5011  pop rcx
00007b629add5012  pop rax
00007b629add5013  add rsp, 0x08
00007b629add5017  jmp 0x00007B629ADD025D
00007b629add501c  sub rsp, 0x08
00007b629add5020  push rax
00007b629add5021  push rcx
00007b629add5022  push rdx
00007b629add5023  push rdi
00007b629add5024  push rsi
00007b629add5025  push r8
00007b629add5027  push r9
00007b629add5029  push r10
00007b629add502b  push r11
00007b629add502d  sub rsp, 0xF0
00007b629add5034  vmovaps [rsp], xmm0
00007b629add5039  vmovaps [rsp+0x10], xmm1
00007b629add503f  vmovaps [rsp+0x20], xmm2
00007b629add5045  vmovaps [rsp+0x30], xmm3
00007b629add504b  vmovaps [rsp+0x40], xmm4
00007b629add5051  vmovaps [rsp+0x50], xmm5
00007b629add5057  vmovaps [rsp+0x60], xmm6
00007b629add505d  vmovaps [rsp+0x70], xmm7
00007b629add5063  vmovaps [rsp+0x80], xmm8
00007b629add506c  vmovaps [rsp+0x90], xmm9
00007b629add5075  vmovaps [rsp+0xA0], xmm11
00007b629add507e  vmovaps [rsp+0xB0], xmm12
00007b629add5087  vmovaps [rsp+0xC0], xmm13
00007b629add5090  vmovaps [rsp+0xD0], xmm14
00007b629add5099  vmovaps [rsp+0xE0], xmm15
00007b629add50a2  sub rsp, 0x30
00007b629add50a6  movaps [rsp], xmm10
00007b629add50ab  movaps [rsp+0x10], xmm11
00007b629add50b1  movaps [rsp+0x20], xmm15
00007b629add50b7  lea rdi, [rsp]
00007b629add50bb  mov esi, 0x00
00007b629add50c0  mov rax, 0x583FED93F530
00007b629add50ca  call rax
00007b629add50cc  movaps xmm10, [rsp]
00007b629add50d1  add rsp, 0x30
00007b629add50d5  vmovaps xmm0, [rsp]
00007b629add50da  vmovaps xmm1, [rsp+0x10]
00007b629add50e0  vmovaps xmm2, [rsp+0x20]
00007b629add50e6  vmovaps xmm3, [rsp+0x30]
00007b629add50ec  vmovaps xmm4, [rsp+0x40]
00007b629add50f2  vmovaps xmm5, [rsp+0x50]
00007b629add50f8  vmovaps xmm6, [rsp+0x60]
00007b629add50fe  vmovaps xmm7, [rsp+0x70]
00007b629add5104  vmovaps xmm8, [rsp+0x80]
00007b629add510d  vmovaps xmm9, [rsp+0x90]
00007b629add5116  vmovaps xmm11, [rsp+0xA0]
00007b629add511f  vmovaps xmm12, [rsp+0xB0]
00007b629add5128  vmovaps xmm13, [rsp+0xC0]
00007b629add5131  vmovaps xmm14, [rsp+0xD0]
00007b629add513a  vmovaps xmm15, [rsp+0xE0]
00007b629add5143  add rsp, 0xF0
00007b629add514a  pop r11
00007b629add514c  pop r10
00007b629add514e  pop r9
00007b629add5150  pop r8
00007b629add5152  pop rsi
00007b629add5153  pop rdi
00007b629add5154  pop rdx
00007b629add5155  pop rcx
00007b629add5156  pop rax
00007b629add5157  add rsp, 0x08
00007b629add515b  jmp 0x00007B629ADD028B
00007b629add5160  sub rsp, 0x08
00007b629add5164  push rax
00007b629add5165  push rcx
00007b629add5166  push rdx
00007b629add5167  push rdi
00007b629add5168  push rsi
00007b629add5169  push r8
00007b629add516b  push r9
00007b629add516d  push r10
00007b629add516f  push r11
00007b629add5171  sub rsp, 0xF0
00007b629add5178  vmovaps [rsp], xmm0
00007b629add517d  vmovaps [rsp+0x10], xmm1
00007b629add5183  vmovaps [rsp+0x20], xmm2
00007b629add5189  vmovaps [rsp+0x30], xmm3
00007b629add518f  vmovaps [rsp+0x40], xmm4
00007b629add5195  vmovaps [rsp+0x50], xmm5
00007b629add519b  vmovaps [rsp+0x60], xmm6
00007b629add51a1  vmovaps [rsp+0x70], xmm7
00007b629add51a7  vmovaps [rsp+0x80], xmm8
00007b629add51b0  vmovaps [rsp+0x90], xmm9
00007b629add51b9  vmovaps [rsp+0xA0], xmm10
00007b629add51c2  vmovaps [rsp+0xB0], xmm12
00007b629add51cb  vmovaps [rsp+0xC0], xmm13
00007b629add51d4  vmovaps [rsp+0xD0], xmm14
00007b629add51dd  vmovaps [rsp+0xE0], xmm15
00007b629add51e6  sub rsp, 0x30
00007b629add51ea  movaps [rsp], xmm11
00007b629add51ef  movaps [rsp+0x10], xmm12
00007b629add51f5  movaps [rsp+0x20], xmm15
00007b629add51fb  lea rdi, [rsp]
00007b629add51ff  mov esi, 0x00
00007b629add5204  mov rax, 0x583FED93F530
00007b629add520e  call rax
00007b629add5210  movaps xmm11, [rsp]
00007b629add5215  add rsp, 0x30
00007b629add5219  vmovaps xmm0, [rsp]
00007b629add521e  vmovaps xmm1, [rsp+0x10]
00007b629add5224  vmovaps xmm2, [rsp+0x20]
00007b629add522a  vmovaps xmm3, [rsp+0x30]
00007b629add5230  vmovaps xmm4, [rsp+0x40]
00007b629add5236  vmovaps xmm5, [rsp+0x50]
00007b629add523c  vmovaps xmm6, [rsp+0x60]
00007b629add5242  vmovaps xmm7, [rsp+0x70]
00007b629add5248  vmovaps xmm8, [rsp+0x80]
00007b629add5251  vmovaps xmm9, [rsp+0x90]
00007b629add525a  vmovaps xmm10, [rsp+0xA0]
00007b629add5263  vmovaps xmm12, [rsp+0xB0]
00007b629add526c  vmovaps xmm13, [rsp+0xC0]
00007b629add5275  vmovaps xmm14, [rsp+0xD0]
00007b629add527e  vmovaps xmm15, [rsp+0xE0]
00007b629add5287  add rsp, 0xF0
00007b629add528e  pop r11
00007b629add5290  pop r10
00007b629add5292  pop r9
00007b629add5294  pop r8
00007b629add5296  pop rsi
00007b629add5297  pop rdi
00007b629add5298  pop rdx
00007b629add5299  pop rcx
00007b629add529a  pop rax
00007b629add529b  add rsp, 0x08
00007b629add529f  jmp 0x00007B629ADD02B9
00007b629add52a4  sub rsp, 0x08
00007b629add52a8  push rax
00007b629add52a9  push rcx
00007b629add52aa  push rdx
00007b629add52ab  push rdi
00007b629add52ac  push rsi
00007b629add52ad  push r8
00007b629add52af  push r9
00007b629add52b1  push r10
00007b629add52b3  push r11
00007b629add52b5  sub rsp, 0xF0
00007b629add52bc  vmovaps [rsp], xmm0
00007b629add52c1  vmovaps [rsp+0x10], xmm1
00007b629add52c7  vmovaps [rsp+0x20], xmm2
00007b629add52cd  vmovaps [rsp+0x30], xmm3
00007b629add52d3  vmovaps [rsp+0x40], xmm4
00007b629add52d9  vmovaps [rsp+0x50], xmm5
00007b629add52df  vmovaps [rsp+0x60], xmm6
00007b629add52e5  vmovaps [rsp+0x70], xmm7
00007b629add52eb  vmovaps [rsp+0x80], xmm8
00007b629add52f4  vmovaps [rsp+0x90], xmm9
00007b629add52fd  vmovaps [rsp+0xA0], xmm10
00007b629add5306  vmovaps [rsp+0xB0], xmm11
00007b629add530f  vmovaps [rsp+0xC0], xmm12
00007b629add5318  vmovaps [rsp+0xD0], xmm13
00007b629add5321  vmovaps [rsp+0xE0], xmm14
00007b629add532a  sub rsp, 0x30
00007b629add532e  movaps [rsp], xmm15
00007b629add5333  movaps [rsp+0x10], xmm13
00007b629add5339  movaps [rsp+0x20], xmm9
00007b629add533f  lea rdi, [rsp]
00007b629add5343  mov esi, 0x00
00007b629add5348  mov rax, 0x583FED93F530
00007b629add5352  call rax
00007b629add5354  movaps xmm15, [rsp]
00007b629add5359  add rsp, 0x30
00007b629add535d  vmovaps xmm0, [rsp]
00007b629add5362  vmovaps xmm1, [rsp+0x10]
00007b629add5368  vmovaps xmm2, [rsp+0x20]
00007b629add536e  vmovaps xmm3, [rsp+0x30]
00007b629add5374  vmovaps xmm4, [rsp+0x40]
00007b629add537a  vmovaps xmm5, [rsp+0x50]
00007b629add5380  vmovaps xmm6, [rsp+0x60]
00007b629add5386  vmovaps xmm7, [rsp+0x70]
00007b629add538c  vmovaps xmm8, [rsp+0x80]
00007b629add5395  vmovaps xmm9, [rsp+0x90]
00007b629add539e  vmovaps xmm10, [rsp+0xA0]
00007b629add53a7  vmovaps xmm11, [rsp+0xB0]
00007b629add53b0  vmovaps xmm12, [rsp+0xC0]
00007b629add53b9  vmovaps xmm13, [rsp+0xD0]
00007b629add53c2  vmovaps xmm14, [rsp+0xE0]
00007b629add53cb  add rsp, 0xF0
00007b629add53d2  pop r11
00007b629add53d4  pop r10
00007b629add53d6  pop r9
00007b629add53d8  pop r8
00007b629add53da  pop rsi
00007b629add53db  pop rdi
00007b629add53dc  pop rdx
00007b629add53dd  pop rcx
00007b629add53de  pop rax
00007b629add53df  add rsp, 0x08
00007b629add53e3  jmp 0x00007B629ADD02D4
00007b629add53e8  sub rsp, 0x08
00007b629add53ec  push rax
00007b629add53ed  push rcx
00007b629add53ee  push rdx
00007b629add53ef  push rdi
00007b629add53f0  push rsi
00007b629add53f1  push r8
00007b629add53f3  push r9
00007b629add53f5  push r10
00007b629add53f7  push r11
00007b629add53f9  sub rsp, 0xF0
00007b629add5400  vmovaps [rsp], xmm0
00007b629add5405  vmovaps [rsp+0x10], xmm1
00007b629add540b  vmovaps [rsp+0x20], xmm2
00007b629add5411  vmovaps [rsp+0x30], xmm3
00007b629add5417  vmovaps [rsp+0x40], xmm4
00007b629add541d  vmovaps [rsp+0x50], xmm5
00007b629add5423  vmovaps [rsp+0x60], xmm6
00007b629add5429  vmovaps [rsp+0x70], xmm7
00007b629add542f  vmovaps [rsp+0x80], xmm8
00007b629add5438  vmovaps [rsp+0x90], xmm9
00007b629add5441  vmovaps [rsp+0xA0], xmm10
00007b629add544a  vmovaps [rsp+0xB0], xmm11
00007b629add5453  vmovaps [rsp+0xC0], xmm12
00007b629add545c  vmovaps [rsp+0xD0], xmm14
00007b629add5465  vmovaps [rsp+0xE0], xmm15
00007b629add546e  sub rsp, 0x30
00007b629add5472  movaps [rsp], xmm13
00007b629add5477  movaps [rsp+0x10], xmm8
00007b629add547d  movaps [rsp+0x20], xmm14
00007b629add5483  lea rdi, [rsp]
00007b629add5487  mov esi, 0x00
00007b629add548c  mov rax, 0x583FED93F530
00007b629add5496  call rax
00007b629add5498  movaps xmm13, [rsp]
00007b629add549d  add rsp, 0x30
00007b629add54a1  vmovaps xmm0, [rsp]
00007b629add54a6  vmovaps xmm1, [rsp+0x10]
00007b629add54ac  vmovaps xmm2, [rsp+0x20]
00007b629add54b2  vmovaps xmm3, [rsp+0x30]
00007b629add54b8  vmovaps xmm4, [rsp+0x40]
00007b629add54be  vmovaps xmm5, [rsp+0x50]
00007b629add54c4  vmovaps xmm6, [rsp+0x60]
00007b629add54ca  vmovaps xmm7, [rsp+0x70]
00007b629add54d0  vmovaps xmm8, [rsp+0x80]
00007b629add54d9  vmovaps xmm9, [rsp+0x90]
00007b629add54e2  vmovaps xmm10, [rsp+0xA0]
00007b629add54eb  vmovaps xmm11, [rsp+0xB0]
00007b629add54f4  vmovaps xmm12, [rsp+0xC0]
00007b629add54fd  vmovaps xmm14, [rsp+0xD0]
00007b629add5506  vmovaps xmm15, [rsp+0xE0]
00007b629add550f  add rsp, 0xF0
00007b629add5516  pop r11
00007b629add5518  pop r10
00007b629add551a  pop r9
00007b629add551c  pop r8
00007b629add551e  pop rsi
00007b629add551f  pop rdi
00007b629add5520  pop rdx
00007b629add5521  pop rcx
00007b629add5522  pop rax
00007b629add5523  add rsp, 0x08
00007b629add5527  jmp 0x00007B629ADD02F7
00007b629add552c  sub rsp, 0x08
00007b629add5530  push rax
00007b629add5531  push rcx
00007b629add5532  push rdx
00007b629add5533  push rdi
00007b629add5534  push rsi
00007b629add5535  push r8
00007b629add5537  push r9
00007b629add5539  push r10
00007b629add553b  push r11
00007b629add553d  sub rsp, 0xF0
00007b629add5544  vmovaps [rsp], xmm0
00007b629add5549  vmovaps [rsp+0x10], xmm1
00007b629add554f  vmovaps [rsp+0x20], xmm2
00007b629add5555  vmovaps [rsp+0x30], xmm3
00007b629add555b  vmovaps [rsp+0x40], xmm4
00007b629add5561  vmovaps [rsp+0x50], xmm5
00007b629add5567  vmovaps [rsp+0x60], xmm6
00007b629add556d  vmovaps [rsp+0x70], xmm7
00007b629add5573  vmovaps [rsp+0x80], xmm8
00007b629add557c  vmovaps [rsp+0x90], xmm9
00007b629add5585  vmovaps [rsp+0xA0], xmm10
00007b629add558e  vmovaps [rsp+0xB0], xmm11
00007b629add5597  vmovaps [rsp+0xC0], xmm12
00007b629add55a0  vmovaps [rsp+0xD0], xmm13
00007b629add55a9  vmovaps [rsp+0xE0], xmm15
00007b629add55b2  sub rsp, 0x30
00007b629add55b6  movaps [rsp], xmm14
00007b629add55bb  movaps [rsp+0x10], xmm1
00007b629add55c0  movaps [rsp+0x20], xmm10
00007b629add55c6  lea rdi, [rsp]
00007b629add55ca  mov esi, 0x00
00007b629add55cf  mov rax, 0x583FED93F530
00007b629add55d9  call rax
00007b629add55db  movaps xmm14, [rsp]
00007b629add55e0  add rsp, 0x30
00007b629add55e4  vmovaps xmm0, [rsp]
00007b629add55e9  vmovaps xmm1, [rsp+0x10]
00007b629add55ef  vmovaps xmm2, [rsp+0x20]
00007b629add55f5  vmovaps xmm3, [rsp+0x30]
00007b629add55fb  vmovaps xmm4, [rsp+0x40]
00007b629add5601  vmovaps xmm5, [rsp+0x50]
00007b629add5607  vmovaps xmm6, [rsp+0x60]
00007b629add560d  vmovaps xmm7, [rsp+0x70]
00007b629add5613  vmovaps xmm8, [rsp+0x80]
00007b629add561c  vmovaps xmm9, [rsp+0x90]
00007b629add5625  vmovaps xmm10, [rsp+0xA0]
00007b629add562e  vmovaps xmm11, [rsp+0xB0]
00007b629add5637  vmovaps xmm12, [rsp+0xC0]
00007b629add5640  vmovaps xmm13, [rsp+0xD0]
00007b629add5649  vmovaps xmm15, [rsp+0xE0]
00007b629add5652  add rsp, 0xF0
00007b629add5659  pop r11
00007b629add565b  pop r10
00007b629add565d  pop r9
00007b629add565f  pop r8
00007b629add5661  pop rsi
00007b629add5662  pop rdi
00007b629add5663  pop rdx
00007b629add5664  pop rcx
00007b629add5665  pop rax
00007b629add5666  add rsp, 0x08
00007b629add566a  jmp 0x00007B629ADD031A
00007b629add566f  sub rsp, 0x08
00007b629add5673  push rax
00007b629add5674  push rcx
00007b629add5675  push rdx
00007b629add5676  push rdi
00007b629add5677  push rsi
00007b629add5678  push r8
00007b629add567a  push r9
00007b629add567c  push r10
00007b629add567e  push r11
00007b629add5680  sub rsp, 0xF0
00007b629add5687  vmovaps [rsp], xmm0
00007b629add568c  vmovaps [rsp+0x10], xmm2
00007b629add5692  vmovaps [rsp+0x20], xmm3
00007b629add5698  vmovaps [rsp+0x30], xmm4
00007b629add569e  vmovaps [rsp+0x40], xmm5
00007b629add56a4  vmovaps [rsp+0x50], xmm6
00007b629add56aa  vmovaps [rsp+0x60], xmm7
00007b629add56b0  vmovaps [rsp+0x70], xmm8
00007b629add56b6  vmovaps [rsp+0x80], xmm9
00007b629add56bf  vmovaps [rsp+0x90], xmm10
00007b629add56c8  vmovaps [rsp+0xA0], xmm11
00007b629add56d1  vmovaps [rsp+0xB0], xmm12
00007b629add56da  vmovaps [rsp+0xC0], xmm13
00007b629add56e3  vmovaps [rsp+0xD0], xmm14
00007b629add56ec  vmovaps [rsp+0xE0], xmm15
00007b629add56f5  sub rsp, 0x30
00007b629add56f9  movaps [rsp], xmm1
00007b629add56fd  movaps [rsp+0x10], xmm7
00007b629add5702  movaps [rsp+0x20], xmm11
00007b629add5708  lea rdi, [rsp]
00007b629add570c  mov esi, 0x00
00007b629add5711  mov rax, 0x583FED93F530
00007b629add571b  call rax
00007b629add571d  movaps xmm1, [rsp]
00007b629add5721  add rsp, 0x30
00007b629add5725  vmovaps xmm0, [rsp]
00007b629add572a  vmovaps xmm2, [rsp+0x10]
00007b629add5730  vmovaps xmm3, [rsp+0x20]
00007b629add5736  vmovaps xmm4, [rsp+0x30]
00007b629add573c  vmovaps xmm5, [rsp+0x40]
00007b629add5742  vmovaps xmm6, [rsp+0x50]
00007b629add5748  vmovaps xmm7, [rsp+0x60]
00007b629add574e  vmovaps xmm8, [rsp+0x70]
00007b629add5754  vmovaps xmm9, [rsp+0x80]
00007b629add575d  vmovaps xmm10, [rsp+0x90]
00007b629add5766  vmovaps xmm11, [rsp+0xA0]
00007b629add576f  vmovaps xmm12, [rsp+0xB0]
00007b629add5778  vmovaps xmm13, [rsp+0xC0]
00007b629add5781  vmovaps xmm14, [rsp+0xD0]
00007b629add578a  vmovaps xmm15, [rsp+0xE0]
00007b629add5793  add rsp, 0xF0
00007b629add579a  pop r11
00007b629add579c  pop r10
00007b629add579e  pop r9
00007b629add57a0  pop r8
00007b629add57a2  pop rsi
00007b629add57a3  pop rdi
00007b629add57a4  pop rdx
00007b629add57a5  pop rcx
00007b629add57a6  pop rax
00007b629add57a7  add rsp, 0x08
00007b629add57ab  jmp 0x00007B629ADD033B
00007b629add57b0  call 0x00007B629AC0E880
00007b629add57b5  jmp 0x00007B629ADD034E
00007b629add57ba  call 0x00007B629AC0C380
00007b629add57bf  jmp 0x00007B629ADD0359
00007b629add57c4  call 0x00007B629AC0D600
00007b629add57c9  jmp 0x00007B629ADD0364
00007b629add57ce  call 0x00007B629ABFF540
00007b629add57d3  jmp 0x00007B629ADD036F
00007b629add57d8  int3
00007b629add57d9  nop [rax], eax
00007b629add57e0  mov rax, [r15+0x40]
00007b629add57e4  mov r14, [r15+0x58]
00007b629add57e8  lea r12, [rax+r14*1]
00007b629add57ec  movaps xmm1, [r15+0x1D0]
00007b629add57f4  vmovaps [rsp+0x10], xmm1
00007b629add57fa  vmovaps xmm15, [rsp+0x10]
00007b629add5800  por xmm1, xmm15
00007b629add5805  movaps xmm14, [r15+0x1A0]
00007b629add580d  vmovaps [rsp+0x10], xmm14
00007b629add5813  vmovaps xmm13, [rsp+0x10]
00007b629add5819  por xmm14, xmm13
00007b629add581e  lea rax, [r12+0x30]
00007b629add5823  mov r11, [r13+rax*1]
00007b629add5828  lea rax, [r12+0x38]
00007b629add582d  mov r10, [r13+rax*1]
00007b629add5832  movq xmm13, r11
00007b629add5837  movq xmm12, r10
00007b629add583c  movq xmm13, xmm13
00007b629add5841  vmovaps [rsp+0x10], xmm13
00007b629add5847  movq xmm13, xmm13
00007b629add584c  movaps [r15+0x130], xmm13
00007b629add5854  movq xmm12, xmm12
00007b629add5859  vmovaps [rsp+0x20], xmm12
00007b629add585f  movq xmm12, xmm12
00007b629add5864  movaps [r15+0x280], xmm12
00007b629add586c  movaps xmm13, [r15+0x270]
00007b629add5874  vmovaps [rsp+0x30], xmm13
00007b629add587a  vmovaps xmm12, [rsp+0x30]
00007b629add5880  por xmm13, xmm12
00007b629add5885  lea rax, [r12+0x20]
00007b629add588a  mov r11, [r13+rax*1]
00007b629add588f  lea rax, [r12+0x28]
00007b629add5894  mov r10, [r13+rax*1]
00007b629add5899  movq xmm12, r11
00007b629add589e  movq xmm11, r10
00007b629add58a3  movq xmm12, xmm12
00007b629add58a8  vmovaps [rsp+0x30], xmm12
00007b629add58ae  movq xmm12, xmm12
00007b629add58b3  movaps [r15+0x150], xmm12
00007b629add58bb  movq xmm11, xmm11
00007b629add58c0  vmovaps [rsp+0x40], xmm11
00007b629add58c6  movq xmm11, xmm11
00007b629add58cb  movaps [r15+0x140], xmm11
00007b629add58d3  lea rax, [r12+0x10]
00007b629add58d8  mov r11, [r13+rax*1]
00007b629add58dd  lea rax, [r12+0x18]
00007b629add58e2  mov r10, [r13+rax*1]
00007b629add58e7  movq xmm12, r11
00007b629add58ec  movq xmm11, r10
00007b629add58f1  movq xmm12, xmm12
00007b629add58f6  vmovaps [rsp+0x50], xmm12
00007b629add58fc  movq xmm12, xmm12
00007b629add5901  movaps [r15+0x170], xmm12
00007b629add5909  movq xmm11, xmm11
00007b629add590e  vmovaps [rsp+0x60], xmm11
00007b629add5914  movq xmm11, xmm11
00007b629add5919  movaps [r15+0x160], xmm11
00007b629add5921  mov rax, [r13+r12*1]
00007b629add5926  vmovq xmm12, rax
00007b629add592b  vpbroadcastq xmm12, xmm12
00007b629add5930  lea rax, [r12+0x08]
00007b629add5935  mov r12, [r13+rax*1]
00007b629add593a  movq xmm11, r12
00007b629add593f  movaps [r15+0x230], xmm11
00007b629add5947  mov rax, [r15+0xF8]
00007b629add594e  lea r12, [rax+0x50]
00007b629add5952  movups xmm11, [r13+r12*1]
00007b629add5958  lea r12, [rax+0x60]
00007b629add595c  movups xmm10, [r13+r12*1]
00007b629add5962  lea r12, [rax+0x30]
00007b629add5966  movups xmm9, [r13+r12*1]
00007b629add596c  mov r12, [r15+0x50]
00007b629add5970  lea r11, [r12+r14*1]
00007b629add5974  mov [r15+0x60], r11
00007b629add5978  lea r12, [r14+0x40]
00007b629add597c  mov [r15+0x58], r12
00007b629add5980  movaps xmm8, xmm12
00007b629add5984  mulpd xmm8, xmm15
00007b629add5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007b629add598f  ptest xmm7, xmm7
00007b629add5994  jnz 0x00007B629ADD67B7
00007b629add599a  movq xmm15, qword ptr [r15+0x230]
00007b629add59a3  vmovaps [rsp+0x70], xmm15
00007b629add59a9  vpermilpd xmm15, xmm15, 0x00
00007b629add59af  movaps xmm7, xmm9
00007b629add59b3  mulpd xmm7, xmm15
00007b629add59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007b629add59bd  ptest xmm6, xmm6
00007b629add59c2  jnz 0x00007B629ADD68FB
00007b629add59c8  vxorps xmm15, xmm15, xmm15
00007b629add59cd  vpbroadcastq xmm15, xmm15
00007b629add59d2  movaps xmm9, xmm12
00007b629add59d6  mulpd xmm9, xmm10
00007b629add59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007b629add59e1  ptest xmm6, xmm6
00007b629add59e6  jnz 0x00007B629ADD6A3D
00007b629add59ec  movaps xmm10, xmm12
00007b629add59f0  mulpd xmm10, xmm11
00007b629add59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007b629add59fb  ptest xmm6, xmm6
00007b629add5a00  jnz 0x00007B629ADD6B81
00007b629add5a06  movaps xmm11, [r15+0x1F0]
00007b629add5a0e  movaps xmm6, xmm12
00007b629add5a12  mulpd xmm6, xmm11
00007b629add5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007b629add5a1c  ptest xmm5, xmm5
00007b629add5a21  jnz 0x00007B629ADD6CC5
00007b629add5a27  movaps xmm12, [r15+0x2A0]
00007b629add5a2f  vmovaps [rsp+0x80], xmm12
00007b629add5a38  vmovaps xmm11, [rsp+0x80]
00007b629add5a41  por xmm12, xmm11
00007b629add5a46  movaps xmm11, [r15+0x250]
00007b629add5a4e  vmovaps [rsp+0x80], xmm11
00007b629add5a57  vmovaps xmm5, [rsp+0x80]
00007b629add5a60  por xmm11, xmm5
00007b629add5a65  vmovaps xmm4, [rsp+0x70]
00007b629add5a6b  vpermilpd xmm4, xmm4, 0x00
00007b629add5a71  movaps xmm3, xmm5
00007b629add5a74  mulpd xmm3, xmm4
00007b629add5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007b629add5a7d  ptest xmm2, xmm2
00007b629add5a82  jnz 0x00007B629ADD6E07
00007b629add5a88  mov [rsp+0x80], rax
00007b629add5a90  xor eax, eax
00007b629add5a92  mov r14d, 0x200
00007b629add5a98  cmp r12, r14
00007b629add5a9b  cmc
00007b629add5a9c  lahf
00007b629add5a9d  seto al
00007b629add5aa0  mov [r15+0x108], eax
00007b629add5aa7  movaps xmm5, xmm8
00007b629add5aab  addpd xmm5, xmm15
00007b629add5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007b629add5ab5  ptest xmm4, xmm4
00007b629add5aba  jnz 0x00007B629ADD6F47
00007b629add5ac0  movaps xmm8, [r15+0x1B0]
00007b629add5ac8  movaps xmm4, xmm9
00007b629add5acc  addpd xmm4, xmm8
00007b629add5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007b629add5ad6  ptest xmm2, xmm2
00007b629add5adb  jnz 0x00007B629ADD7089
00007b629add5ae1  movaps xmm9, xmm10
00007b629add5ae5  addpd xmm9, xmm8
00007b629add5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007b629add5af0  ptest xmm2, xmm2
00007b629add5af5  jnz 0x00007B629ADD71CB
00007b629add5afb  movaps xmm10, [r15+0x2F0]
00007b629add5b03  vmovaps [rsp+0x90], xmm10
00007b629add5b0c  vmovaps xmm8, [rsp+0x90]
00007b629add5b15  por xmm10, xmm8
00007b629add5b1a  movaps xmm8, [r15+0x2E0]
00007b629add5b22  vmovaps [rsp+0x90], xmm8
00007b629add5b2b  vmovaps xmm2, [rsp+0x90]
00007b629add5b34  por xmm8, xmm2
00007b629add5b39  movaps xmm2, [r15+0x2D0]
00007b629add5b41  vmovaps [rsp+0x90], xmm2
00007b629add5b4a  vmovaps [rsp+0xA0], xmm1
00007b629add5b53  vmovaps xmm1, [rsp+0x90]
00007b629add5b5c  por xmm2, xmm1
00007b629add5b60  movaps xmm1, [r15+0x200]
00007b629add5b68  vmovaps [rsp+0x90], xmm1
00007b629add5b71  vmovaps [rsp+0xB0], xmm15
00007b629add5b7a  vmovaps xmm15, [rsp+0x90]
00007b629add5b83  por xmm1, xmm15
00007b629add5b88  movaps xmm15, [r15+0x1C0]
00007b629add5b90  vmovaps [rsp+0x90], xmm15
00007b629add5b99  vmovaps [rsp+0xC0], xmm1
00007b629add5ba2  vmovaps xmm1, [rsp+0x90]
00007b629add5bab  por xmm15, xmm1
00007b629add5bb0  movaps xmm1, [r15+0x190]
00007b629add5bb8  vmovaps [rsp+0x90], xmm1
00007b629add5bc1  vmovaps [rsp+0xD0], xmm15
00007b629add5bca  vmovaps xmm15, [rsp+0x90]
00007b629add5bd3  por xmm1, xmm15
00007b629add5bd8  movaps xmm15, [r15+0x300]
00007b629add5be0  vmovaps [rsp+0x90], xmm15
00007b629add5be9  vmovaps [rsp+0xE0], xmm1
00007b629add5bf2  vmovaps xmm1, [rsp+0x90]
00007b629add5bfb  por xmm15, xmm1
00007b629add5c00  mov rax, [rsp+0x80]
00007b629add5c08  lea r14, [rax+0xA0]
00007b629add5c0f  movups xmm1, [r13+r14*1]
00007b629add5c15  lea r14, [rax+0xB0]
00007b629add5c1c  vmovaps [rsp+0x80], xmm1
00007b629add5c25  movups xmm1, [r13+r14*1]
00007b629add5c2b  vmovaps [rsp+0x90], xmm1
00007b629add5c34  vmovaps [rsp+0xF0], xmm15
00007b629add5c3d  vmovaps xmm15, [rsp+0xB0]
00007b629add5c46  vmovaps [rsp+0xB0], xmm14
00007b629add5c4f  movaps xmm1, xmm6
00007b629add5c52  addpd xmm1, xmm15
00007b629add5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007b629add5c5c  ptest xmm14, xmm14
00007b629add5c62  jnz 0x00007B629ADD7323
00007b629add5c68  lea r14, [rax+0xF0]
00007b629add5c6f  movups xmm15, [r13+r14*1]
00007b629add5c75  movaps xmm14, xmm4
00007b629add5c79  addpd xmm14, xmm3
00007b629add5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007b629add5c84  ptest xmm6, xmm6
00007b629add5c89  jnz 0x00007B629ADD746E
00007b629add5c8f  movaps xmm6, xmm9
00007b629add5c93  addpd xmm6, xmm7
00007b629add5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007b629add5c9c  ptest xmm4, xmm4
00007b629add5ca1  jnz 0x00007B629ADD75B0
00007b629add5ca7  vmovaps xmm9, [rsp+0x70]
00007b629add5cad  vpermilpd xmm9, xmm9, 0x00
00007b629add5cb3  vmovaps xmm4, [rsp+0x90]
00007b629add5cbc  movaps xmm7, xmm4
00007b629add5cbf  mulpd xmm7, xmm9
00007b629add5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007b629add5cc9  ptest xmm3, xmm3
00007b629add5cce  jnz 0x00007B629ADD76F1
00007b629add5cd4  vmovaps xmm9, [rsp+0x50]
00007b629add5cda  vpermilpd xmm9, xmm9, 0x00
00007b629add5ce0  movaps xmm4, xmm15
00007b629add5ce4  mulpd xmm4, xmm9
00007b629add5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007b629add5cee  ptest xmm3, xmm3
00007b629add5cf3  jnz 0x00007B629ADD7832
00007b629add5cf9  lea r14, [rax+0xE0]
00007b629add5d00  movups xmm15, [r13+r14*1]
00007b629add5d06  vmovaps xmm9, [rsp+0x70]
00007b629add5d0c  vpermilpd xmm9, xmm9, 0x00
00007b629add5d12  vmovaps [rsp+0x70], xmm1
00007b629add5d18  vmovaps xmm1, [rsp+0x80]
00007b629add5d21  vmovaps [rsp+0x80], xmm15
00007b629add5d2a  movaps xmm3, xmm1
00007b629add5d2d  mulpd xmm3, xmm9
00007b629add5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007b629add5d37  ptest xmm15, xmm15
00007b629add5d3d  jnz 0x00007B629ADD797E
00007b629add5d43  vmovaps xmm1, [rsp+0xF0]
00007b629add5d4c  vmovaps xmm15, [rsp+0xF0]
00007b629add5d55  por xmm1, xmm15
00007b629add5d5a  movaps [r15+0x300], xmm1
00007b629add5d62  vmovaps xmm15, [rsp+0xE0]
00007b629add5d6b  vmovaps xmm9, [rsp+0xE0]
00007b629add5d74  por xmm15, xmm9
00007b629add5d79  movaps [r15+0x190], xmm15
00007b629add5d81  vmovaps xmm9, [rsp+0x50]
00007b629add5d87  vpermilpd xmm9, xmm9, 0x00
00007b629add5d8d  vmovaps [rsp+0x90], xmm1
00007b629add5d96  vmovaps [rsp+0xE0], xmm15
00007b629add5d9f  vmovaps xmm15, [rsp+0x80]
00007b629add5da8  vmovaps [rsp+0x80], xmm14
00007b629add5db1  movaps xmm1, xmm15
00007b629add5db5  mulpd xmm1, xmm9
00007b629add5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007b629add5dbf  ptest xmm14, xmm14
00007b629add5dc5  jnz 0x00007B629ADD7ABF
00007b629add5dcb  lea r14, [rax+0x90]
00007b629add5dd2  movups xmm15, [r13+r14*1]
00007b629add5dd8  vmovaps xmm14, [rsp+0xD0]
00007b629add5de1  vmovaps xmm9, [rsp+0xD0]
00007b629add5dea  por xmm14, xmm9
00007b629add5def  movaps [r15+0x1C0], xmm14
00007b629add5df7  vmovaps xmm9, [rsp+0xC0]
00007b629add5e00  vmovaps [rsp+0xD0], xmm1
00007b629add5e09  vmovaps xmm1, [rsp+0xC0]
00007b629add5e12  por xmm9, xmm1
00007b629add5e17  movaps [r15+0x200], xmm9
00007b629add5e1f  vmovaps [rsp+0xC0], xmm2
00007b629add5e28  vmovaps xmm1, [rsp+0xC0]
00007b629add5e31  por xmm2, xmm1
00007b629add5e35  movaps [r15+0x2D0], xmm2
00007b629add5e3d  vmovaps [rsp+0xC0], xmm8
00007b629add5e46  vmovaps xmm1, [rsp+0xC0]
00007b629add5e4f  por xmm8, xmm1
00007b629add5e54  movaps [r15+0x2E0], xmm8
00007b629add5e5c  vmovaps [rsp+0xC0], xmm15
00007b629add5e65  movaps xmm1, xmm5
00007b629add5e68  addpd xmm1, xmm7
00007b629add5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007b629add5e71  ptest xmm15, xmm15
00007b629add5e77  jnz 0x00007B629ADD7C0B
00007b629add5e7d  vmovaps xmm15, [rsp+0x50]
00007b629add5e83  vpermilpd xmm15, xmm15, 0x00
00007b629add5e89  vmovaps xmm5, [rsp+0xC0]
00007b629add5e92  vmovaps [rsp+0xC0], xmm1
00007b629add5e9b  movaps xmm7, xmm5
00007b629add5e9e  mulpd xmm7, xmm15
00007b629add5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007b629add5ea8  ptest xmm1, xmm1
00007b629add5ead  jnz 0x00007B629ADD7D4B
00007b629add5eb3  lea r14, [rax+0x80]
00007b629add5eba  movups xmm1, [r13+r14*1]
00007b629add5ec0  vmovaps xmm5, [rsp+0x70]
00007b629add5ec6  vmovaps [rsp+0x70], xmm1
00007b629add5ecc  movaps xmm15, xmm5
00007b629add5ed0  addpd xmm15, xmm3
00007b629add5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007b629add5edb  ptest xmm1, xmm1
00007b629add5ee0  jnz 0x00007B629ADD7E96
00007b629add5ee6  vmovaps xmm5, [rsp+0x80]
00007b629add5eef  movaps xmm1, xmm5
00007b629add5ef2  addpd xmm1, xmm4
00007b629add5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007b629add5efb  ptest xmm3, xmm3
00007b629add5f00  jnz 0x00007B629ADD7FD8
00007b629add5f06  vmovaps [rsp+0x80], xmm10
00007b629add5f0f  vmovaps xmm5, [rsp+0x80]
00007b629add5f18  por xmm10, xmm5
00007b629add5f1d  movaps [r15+0x2F0], xmm10
00007b629add5f25  vmovaps xmm5, [rsp+0x50]
00007b629add5f2b  vpermilpd xmm5, xmm5, 0x00
00007b629add5f31  vmovaps xmm3, [rsp+0x70]
00007b629add5f37  vmovaps [rsp+0x50], xmm1
00007b629add5f3d  movaps xmm4, xmm3
00007b629add5f40  mulpd xmm4, xmm5
00007b629add5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007b629add5f49  ptest xmm1, xmm1
00007b629add5f4e  jnz 0x00007B629ADD8118
00007b629add5f54  lea r14, [rax+0xD0]
00007b629add5f5b  movups xmm1, [r13+r14*1]
00007b629add5f61  vmovaps xmm3, [rsp+0xD0]
00007b629add5f6a  vmovaps [rsp+0x70], xmm1
00007b629add5f70  movaps xmm5, xmm6
00007b629add5f73  addpd xmm5, xmm3
00007b629add5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007b629add5f7c  ptest xmm1, xmm1
00007b629add5f81  jnz 0x00007B629ADD8262
00007b629add5f87  vmovaps xmm1, [rsp+0x60]
00007b629add5f8d  vpermilpd xmm1, xmm1, 0x00
00007b629add5f93  movaps xmm6, xmm9
00007b629add5f97  mulpd xmm6, xmm1
00007b629add5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007b629add5fa0  ptest xmm3, xmm3
00007b629add5fa5  jnz 0x00007B629ADD83A2
00007b629add5fab  movaps [r15+0x260], xmm6
00007b629add5fb3  vxorps xmm1, xmm1, xmm1
00007b629add5fb7  vpbroadcastq xmm1, xmm1
00007b629add5fbc  movaps [r15+0x1B0], xmm1
00007b629add5fc4  vmovaps xmm1, [rsp+0x60]
00007b629add5fca  vpermilpd xmm1, xmm1, 0x00
00007b629add5fd0  vmovaps xmm3, [rsp+0x70]
00007b629add5fd6  vmovaps [rsp+0x70], xmm15
00007b629add5fdc  movaps xmm9, xmm3
00007b629add5fe0  mulpd xmm9, xmm1
00007b629add5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007b629add5feb  ptest xmm15, xmm15
00007b629add5ff1  jnz 0x00007B629ADD84E3
00007b629add5ff7  lea r14, [rax+0xC0]
00007b629add5ffe  movups xmm1, [r13+r14*1]
00007b629add6004  vmovaps xmm3, [rsp+0xC0]
00007b629add600d  vmovaps [rsp+0x80], xmm1
00007b629add6016  movaps xmm15, xmm3
00007b629add601a  addpd xmm15, xmm7
00007b629add601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007b629add6025  ptest xmm1, xmm1
00007b629add602a  jnz 0x00007B629ADD862F
00007b629add6030  vmovaps [rsp+0xC0], xmm13
00007b629add6039  vmovaps xmm1, [rsp+0xC0]
00007b629add6042  por xmm13, xmm1
00007b629add6047  movaps [r15+0x270], xmm13
00007b629add604f  vmovaps xmm1, [rsp+0xB0]
00007b629add6058  vmovaps xmm7, [rsp+0xB0]
00007b629add6061  por xmm1, xmm7
00007b629add6065  movaps [r15+0x1A0], xmm1
00007b629add606d  vmovaps xmm1, [rsp+0x60]
00007b629add6073  vpermilpd xmm1, xmm1, 0x00
00007b629add6079  vmovaps [rsp+0xB0], xmm1
00007b629add6082  vmovaps xmm1, [rsp+0x80]
00007b629add608b  vmovaps [rsp+0x80], xmm15
00007b629add6094  vmovaps xmm15, [rsp+0xB0]
00007b629add609d  vmovaps [rsp+0xB0], xmm14
00007b629add60a6  movaps xmm3, xmm1
00007b629add60a9  mulpd xmm3, xmm15
00007b629add60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007b629add60b3  ptest xmm14, xmm14
00007b629add60b9  jnz 0x00007B629ADD8771
00007b629add60bf  lea r14, [rax+0x20]
00007b629add60c3  movups xmm1, [r13+r14*1]
00007b629add60c9  movaps [r15+0x110], xmm1
00007b629add60d1  vmovaps xmm14, [rsp+0x70]
00007b629add60d7  vmovaps [rsp+0x70], xmm1
00007b629add60dd  movaps xmm15, xmm14
00007b629add60e1  addpd xmm15, xmm4
00007b629add60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007b629add60ec  ptest xmm1, xmm1
00007b629add60f1  jnz 0x00007B629ADD88BC
00007b629add60f7  vmovaps xmm1, [rsp+0x60]
00007b629add60fd  vpermilpd xmm1, xmm1, 0x00
00007b629add6103  movaps xmm14, xmm2
00007b629add6107  mulpd xmm14, xmm1
00007b629add610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007b629add6112  ptest xmm4, xmm4
00007b629add6117  jnz 0x00007B629ADD89FF
00007b629add611d  vmovaps xmm4, [rsp+0x50]
00007b629add6123  movaps xmm1, xmm4
00007b629add6126  addpd xmm1, xmm9
00007b629add612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007b629add6130  ptest xmm2, xmm2
00007b629add6135  jnz 0x00007B629ADD8B41
00007b629add613b  vmovaps xmm9, [rsp+0x30]
00007b629add6141  vpermilpd xmm9, xmm9, 0x00
00007b629add6147  vmovaps xmm2, [rsp+0x70]
00007b629add614d  vmovaps [rsp+0x50], xmm1
00007b629add6153  movaps xmm4, xmm2
00007b629add6156  mulpd xmm4, xmm9
00007b629add615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007b629add6160  ptest xmm1, xmm1
00007b629add6165  jnz 0x00007B629ADD8C82
00007b629add616b  vmovaps xmm1, [rsp+0x30]
00007b629add6171  vpermilpd xmm1, xmm1, 0x00
00007b629add6177  vmovaps xmm2, [rsp+0x90]
00007b629add6180  vmovaps [rsp+0x60], xmm15
00007b629add6186  movaps xmm9, xmm2
00007b629add618a  mulpd xmm9, xmm1
00007b629add618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007b629add6195  ptest xmm15, xmm15
00007b629add619b  jnz 0x00007B629ADD8DC3
00007b629add61a1  vmovaps xmm15, [rsp+0x80]
00007b629add61aa  movaps xmm1, xmm15
00007b629add61ae  addpd xmm1, xmm6
00007b629add61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007b629add61b7  ptest xmm2, xmm2
00007b629add61bc  jnz 0x00007B629ADD8F05
00007b629add61c2  movaps xmm15, xmm5
00007b629add61c6  addpd xmm15, xmm3
00007b629add61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007b629add61d1  ptest xmm6, xmm6
00007b629add61d6  jnz 0x00007B629ADD9046
00007b629add61dc  vmovaps xmm6, [rsp+0x30]
00007b629add61e2  vpermilpd xmm6, xmm6, 0x00
00007b629add61e8  movaps xmm5, xmm8
00007b629add61ec  mulpd xmm5, xmm6
00007b629add61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007b629add61f5  ptest xmm3, xmm3
00007b629add61fa  jnz 0x00007B629ADD9188
00007b629add6200  vmovaps xmm8, [rsp+0x30]
00007b629add6206  vpermilpd xmm8, xmm8, 0x00
00007b629add620c  movaps xmm6, xmm10
00007b629add6210  mulpd xmm6, xmm8
00007b629add6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007b629add621a  ptest xmm3, xmm3
00007b629add621f  jnz 0x00007B629ADD92C9
00007b629add6225  vmovaps xmm8, [rsp+0x60]
00007b629add622b  movaps xmm10, xmm8
00007b629add622f  addpd xmm10, xmm14
00007b629add6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007b629add623a  ptest xmm3, xmm3
00007b629add623f  jnz 0x00007B629ADD940B
00007b629add6245  vmovaps xmm8, [rsp+0x50]
00007b629add624b  movaps xmm14, xmm8
00007b629add624f  addpd xmm14, xmm4
00007b629add6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007b629add625a  ptest xmm3, xmm3
00007b629add625f  jnz 0x00007B629ADD954F
00007b629add6265  vmovaps xmm8, [rsp+0x40]
00007b629add626b  vpermilpd xmm8, xmm8, 0x00
00007b629add6271  movaps xmm4, xmm13
00007b629add6275  mulpd xmm4, xmm8
00007b629add627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007b629add627f  ptest xmm3, xmm3
00007b629add6284  jnz 0x00007B629ADD9692
00007b629add628a  movaps xmm13, xmm15
00007b629add628e  addpd xmm13, xmm9
00007b629add6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007b629add6299  ptest xmm8, xmm8
00007b629add629f  jnz 0x00007B629ADD97D4
00007b629add62a5  movaps xmm15, xmm1
00007b629add62a9  addpd xmm15, xmm5
00007b629add62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007b629add62b4  ptest xmm9, xmm9
00007b629add62ba  jnz 0x00007B629ADD9918
00007b629add62c0  vmovaps [rsp+0x30], xmm11
00007b629add62c6  vmovaps xmm1, [rsp+0x30]
00007b629add62cc  por xmm11, xmm1
00007b629add62d1  movaps [r15+0x250], xmm11
00007b629add62d9  vmovaps [rsp+0x30], xmm12
00007b629add62df  vmovaps xmm1, [rsp+0x30]
00007b629add62e5  por xmm12, xmm1
00007b629add62ea  movaps [r15+0x2A0], xmm12
00007b629add62f2  vmovaps xmm1, [rsp+0xA0]
00007b629add62fb  vmovaps xmm11, [rsp+0xA0]
00007b629add6304  por xmm1, xmm11
00007b629add6309  movaps [r15+0x1D0], xmm1
00007b629add6311  lea r14, [rax+0x40]
00007b629add6315  movups xmm1, [r13+r14*1]
00007b629add631b  movaps [r15+0x2C0], xmm1
00007b629add6323  vmovaps xmm11, [rsp+0x40]
00007b629add6329  vpermilpd xmm11, xmm11, 0x00
00007b629add632f  vmovaps xmm8, [rsp+0xE0]
00007b629add6338  movaps xmm9, xmm8
00007b629add633c  mulpd xmm9, xmm11
00007b629add6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007b629add6347  ptest xmm5, xmm5
00007b629add634c  jnz 0x00007B629ADD9A64
00007b629add6352  movaps xmm11, xmm10
00007b629add6356  addpd xmm11, xmm6
00007b629add635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007b629add6361  ptest xmm8, xmm8
00007b629add6367  jnz 0x00007B629ADD9BA8
00007b629add636d  movaps xmm10, xmm14
00007b629add6371  addpd xmm10, xmm4
00007b629add6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007b629add637c  ptest xmm8, xmm8
00007b629add6382  jnz 0x00007B629ADD9CEB
00007b629add6388  vmovaps xmm14, [rsp+0x40]
00007b629add638e  vpermilpd xmm14, xmm14, 0x00
00007b629add6394  movaps xmm8, xmm1
00007b629add6398  mulpd xmm8, xmm14
00007b629add639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007b629add63a3  ptest xmm6, xmm6
00007b629add63a8  jnz 0x00007B629ADD9E2E
00007b629add63ae  movaps xmm1, [r15+0x2B0]
00007b629add63b6  vmovaps xmm14, [rsp+0x40]
00007b629add63bc  vpermilpd xmm14, xmm14, 0x00
00007b629add63c2  movaps xmm6, xmm1
00007b629add63c5  mulpd xmm6, xmm14
00007b629add63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007b629add63cf  ptest xmm5, xmm5
00007b629add63d4  jnz 0x00007B629ADD9F71
00007b629add63da  vmovaps xmm1, [rsp+0x10]
00007b629add63e0  vpermilpd xmm1, xmm1, 0x00
00007b629add63e6  movaps xmm14, xmm12
00007b629add63ea  mulpd xmm14, xmm1
00007b629add63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007b629add63f5  ptest xmm5, xmm5
00007b629add63fa  jnz 0x00007B629ADDA0B2
00007b629add6400  movaps xmm1, xmm13
00007b629add6404  addpd xmm1, xmm9
00007b629add6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007b629add640e  ptest xmm12, xmm12
00007b629add6414  jnz 0x00007B629ADDA1F5
00007b629add641a  vmovaps xmm13, [rsp+0x10]
00007b629add6420  vpermilpd xmm13, xmm13, 0x00
00007b629add6426  movaps xmm12, xmm7
00007b629add642a  mulpd xmm12, xmm13
00007b629add642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007b629add6435  ptest xmm9, xmm9
00007b629add643b  jnz 0x00007B629ADDA337
00007b629add6441  movaps xmm13, xmm15
00007b629add6445  addpd xmm13, xmm8
00007b629add644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007b629add6450  ptest xmm9, xmm9
00007b629add6456  jnz 0x00007B629ADDA47A
00007b629add645c  movaps xmm15, [r15+0x290]
00007b629add6464  vmovaps xmm9, [rsp+0x10]
00007b629add646a  vpermilpd xmm9, xmm9, 0x00
00007b629add6470  movaps xmm8, xmm15
00007b629add6474  mulpd xmm8, xmm9
00007b629add6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007b629add647f  ptest xmm7, xmm7
00007b629add6484  jnz 0x00007B629ADDA5BE
00007b629add648a  movaps xmm15, xmm11
00007b629add648e  addpd xmm15, xmm6
00007b629add6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007b629add6499  ptest xmm9, xmm9
00007b629add649f  jnz 0x00007B629ADDA702
00007b629add64a5  movaps xmm11, [r15+0x1E0]
00007b629add64ad  vmovaps xmm9, [rsp+0x10]
00007b629add64b3  vpermilpd xmm9, xmm9, 0x00
00007b629add64b9  movaps xmm7, xmm11
00007b629add64bd  mulpd xmm7, xmm9
00007b629add64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007b629add64c7  ptest xmm6, xmm6
00007b629add64cc  jnz 0x00007B629ADDA845
00007b629add64d2  movaps xmm11, xmm10
00007b629add64d6  addpd xmm11, xmm14
00007b629add64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007b629add64e1  ptest xmm9, xmm9
00007b629add64e7  jnz 0x00007B629ADDA987
00007b629add64ed  lea r14, [rax+0x70]
00007b629add64f1  movups xmm14, [r13+r14*1]
00007b629add64f7  movaps [r15+0x240], xmm14
00007b629add64ff  movaps xmm10, xmm1
00007b629add6503  addpd xmm10, xmm12
00007b629add6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007b629add650e  ptest xmm9, xmm9
00007b629add6514  jnz 0x00007B629ADDAAD5
00007b629add651a  movaps [r15+0x170], xmm10
00007b629add6522  vmovaps xmm1, [rsp+0x20]
00007b629add6528  vpermilpd xmm1, xmm1, 0x00
00007b629add652e  movaps xmm12, xmm14
00007b629add6532  mulpd xmm12, xmm1
00007b629add6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007b629add653d  ptest xmm9, xmm9
00007b629add6543  jnz 0x00007B629ADDAC18
00007b629add6549  vmovaps xmm1, [rsp+0x20]
00007b629add654f  vpermilpd xmm1, xmm1, 0x00
00007b629add6555  vmovaps xmm9, [rsp+0xB0]
00007b629add655e  movaps xmm14, xmm9
00007b629add6562  mulpd xmm14, xmm1
00007b629add6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007b629add656d  ptest xmm6, xmm6
00007b629add6572  jnz 0x00007B629ADDAD5B
00007b629add6578  movaps [r15+0x180], xmm14
00007b629add6580  movaps xmm1, xmm13
00007b629add6584  addpd xmm1, xmm8
00007b629add6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007b629add658e  ptest xmm9, xmm9
00007b629add6594  jnz 0x00007B629ADDAE9E
00007b629add659a  movaps [r15+0x210], xmm1
00007b629add65a2  movups xmm13, [r13+rax*1]
00007b629add65a8  lea r14, [rax+0x10]
00007b629add65ac  movups xmm9, [r13+r14*1]
00007b629add65b2  movaps [r15+0x230], xmm9
00007b629add65ba  movaps xmm8, xmm15
00007b629add65be  addpd xmm8, xmm7
00007b629add65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007b629add65c9  ptest xmm6, xmm6
00007b629add65ce  jnz 0x00007B629ADDAFF4
00007b629add65d4  movaps [r15+0x130], xmm8
00007b629add65dc  vmovaps xmm15, [rsp+0x20]
00007b629add65e2  vpermilpd xmm15, xmm15, 0x00
00007b629add65e8  movaps xmm7, xmm9
00007b629add65ec  mulpd xmm7, xmm15
00007b629add65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007b629add65f6  ptest xmm6, xmm6
00007b629add65fb  jnz 0x00007B629ADDB137
00007b629add6601  movaps [r15+0x220], xmm7
00007b629add6609  vmovaps xmm15, [rsp+0x20]
00007b629add660f  vpermilpd xmm15, xmm15, 0x00
00007b629add6615  movaps xmm9, xmm13
00007b629add6619  mulpd xmm9, xmm15
00007b629add661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007b629add6624  ptest xmm6, xmm6
00007b629add6629  jnz 0x00007B629ADDB279
00007b629add662f  movaps xmm15, xmm11
00007b629add6633  addpd xmm15, xmm12
00007b629add6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007b629add663e  ptest xmm13, xmm13
00007b629add6644  jnz 0x00007B629ADDB3BD
00007b629add664a  movaps [r15+0x140], xmm15
00007b629add6652  movaps xmm13, xmm10
00007b629add6656  addpd xmm13, xmm14
00007b629add665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007b629add6661  ptest xmm12, xmm12
00007b629add6667  jnz 0x00007B629ADDB501
00007b629add666d  movaps [r15+0x150], xmm13
00007b629add6675  movaps xmm14, xmm1
00007b629add6679  addpd xmm14, xmm7
00007b629add667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007b629add6684  ptest xmm12, xmm12
00007b629add668a  jnz 0x00007B629ADDB645
00007b629add6690  movaps [r15+0x160], xmm14
00007b629add6698  movaps xmm1, xmm8
00007b629add669c  addpd xmm1, xmm9
00007b629add66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007b629add66a6  ptest xmm12, xmm12
00007b629add66ac  jnz 0x00007B629ADDB787
00007b629add66b2  movaps [r15+0x120], xmm1
00007b629add66ba  movups [r13+r11*1], xmm15
00007b629add66c0  lea rax, [r11+0x10]
00007b629add66c4  movups [r13+rax*1], xmm13
00007b629add66ca  lea rax, [r11+0x20]
00007b629add66ce  movups [r13+rax*1], xmm14
00007b629add66d4  lea rax, [r11+0x30]
00007b629add66d8  movups [r13+rax*1], xmm1
00007b629add66de  mov eax, [r15+0x108]
00007b629add66e5  sahf
00007b629add66e6  jnz 0x00007B629ADD6718
00007b629add66e8  cmp dword ptr [r15+0x318], 0x00
00007b629add66f0  jz 0x00007B629ADDB900
00007b629add66f6  nop [rax+rax*1], ax
00007b629add66ff  nop [rax+rax*1], eax
00007b629add6707  mov eax, 0x410444
00007b629add670c  mov [r15+0x100], rax
00007b629add6713  jmp 0x00007B629ABFE110
00007b629add6718  cmp dword ptr [r15+0x318], 0x00
00007b629add6720  jz 0x00007B629ADD57E0
00007b629add6726  nop [rax+rax*1], ax
00007b629add672f  nop [rax+rax*1], eax
00007b629add6737  mov eax, 0x410278
00007b629add673c  mov [r15+0x100], rax
00007b629add6743  jmp 0x00007B629ABFE110
00007b629add6748  int3
00007b629add6749  call 0x00007B629AC0A4B0
00007b629add674e  jmp 0x00007B629ADD5828
00007b629add6753  call 0x00007B629AC09240
00007b629add6758  jmp 0x00007B629ADD5832
00007b629add675d  call 0x00007B629AC0A4B0
00007b629add6762  jmp 0x00007B629ADD588F
00007b629add6767  call 0x00007B629AC09240
00007b629add676c  jmp 0x00007B629ADD5899
00007b629add6771  call 0x00007B629AC0A4B0
00007b629add6776  jmp 0x00007B629ADD58DD
00007b629add677b  call 0x00007B629AC09240
00007b629add6780  jmp 0x00007B629ADD58E7
00007b629add6785  call 0x00007B629ACB47C0
00007b629add678a  jmp 0x00007B629ADD5926
00007b629add678f  call 0x00007B629AC0B720
00007b629add6794  jmp 0x00007B629ADD593A
00007b629add6799  call 0x00007B629ACBFC30
00007b629add679e  jmp 0x00007B629ADD5958
00007b629add67a3  call 0x00007B629ACBE9C0
00007b629add67a8  jmp 0x00007B629ADD5962
00007b629add67ad  call 0x00007B629ACBD750
00007b629add67b2  jmp 0x00007B629ADD596C
00007b629add67b7  sub rsp, 0x08
00007b629add67bb  push rax
00007b629add67bc  push rcx
00007b629add67bd  push rdx
00007b629add67be  push rdi
00007b629add67bf  push rsi
00007b629add67c0  push r8
00007b629add67c2  push r9
00007b629add67c4  push r10
00007b629add67c6  push r11
00007b629add67c8  sub rsp, 0xF0
00007b629add67cf  vmovaps [rsp], xmm0
00007b629add67d4  vmovaps [rsp+0x10], xmm1
00007b629add67da  vmovaps [rsp+0x20], xmm2
00007b629add67e0  vmovaps [rsp+0x30], xmm3
00007b629add67e6  vmovaps [rsp+0x40], xmm4
00007b629add67ec  vmovaps [rsp+0x50], xmm5
00007b629add67f2  vmovaps [rsp+0x60], xmm6
00007b629add67f8  vmovaps [rsp+0x70], xmm7
00007b629add67fe  vmovaps [rsp+0x80], xmm9
00007b629add6807  vmovaps [rsp+0x90], xmm10
00007b629add6810  vmovaps [rsp+0xA0], xmm11
00007b629add6819  vmovaps [rsp+0xB0], xmm12
00007b629add6822  vmovaps [rsp+0xC0], xmm13
00007b629add682b  vmovaps [rsp+0xD0], xmm14
00007b629add6834  vmovaps [rsp+0xE0], xmm15
00007b629add683d  sub rsp, 0x30
00007b629add6841  movaps [rsp], xmm8
00007b629add6846  movaps [rsp+0x10], xmm12
00007b629add684c  movaps [rsp+0x20], xmm15
00007b629add6852  lea rdi, [rsp]
00007b629add6856  mov esi, 0x00
00007b629add685b  mov rax, 0x583FED93F530
00007b629add6865  call rax
00007b629add6867  movaps xmm8, [rsp]
00007b629add686c  add rsp, 0x30
00007b629add6870  vmovaps xmm0, [rsp]
00007b629add6875  vmovaps xmm1, [rsp+0x10]
00007b629add687b  vmovaps xmm2, [rsp+0x20]
00007b629add6881  vmovaps xmm3, [rsp+0x30]
00007b629add6887  vmovaps xmm4, [rsp+0x40]
00007b629add688d  vmovaps xmm5, [rsp+0x50]
00007b629add6893  vmovaps xmm6, [rsp+0x60]
00007b629add6899  vmovaps xmm7, [rsp+0x70]
00007b629add689f  vmovaps xmm9, [rsp+0x80]
00007b629add68a8  vmovaps xmm10, [rsp+0x90]
00007b629add68b1  vmovaps xmm11, [rsp+0xA0]
00007b629add68ba  vmovaps xmm12, [rsp+0xB0]
00007b629add68c3  vmovaps xmm13, [rsp+0xC0]
00007b629add68cc  vmovaps xmm14, [rsp+0xD0]
00007b629add68d5  vmovaps xmm15, [rsp+0xE0]
00007b629add68de  add rsp, 0xF0
00007b629add68e5  pop r11
00007b629add68e7  pop r10
00007b629add68e9  pop r9
00007b629add68eb  pop r8
00007b629add68ed  pop rsi
00007b629add68ee  pop rdi
00007b629add68ef  pop rdx
00007b629add68f0  pop rcx
00007b629add68f1  pop rax
00007b629add68f2  add rsp, 0x08
00007b629add68f6  jmp 0x00007B629ADD599A
00007b629add68fb  sub rsp, 0x08
00007b629add68ff  push rax
00007b629add6900  push rcx
00007b629add6901  push rdx
00007b629add6902  push rdi
00007b629add6903  push rsi
00007b629add6904  push r8
00007b629add6906  push r9
00007b629add6908  push r10
00007b629add690a  push r11
00007b629add690c  sub rsp, 0xF0
00007b629add6913  vmovaps [rsp], xmm0
00007b629add6918  vmovaps [rsp+0x10], xmm1
00007b629add691e  vmovaps [rsp+0x20], xmm2
00007b629add6924  vmovaps [rsp+0x30], xmm3
00007b629add692a  vmovaps [rsp+0x40], xmm4
00007b629add6930  vmovaps [rsp+0x50], xmm5
00007b629add6936  vmovaps [rsp+0x60], xmm6
00007b629add693c  vmovaps [rsp+0x70], xmm8
00007b629add6942  vmovaps [rsp+0x80], xmm9
00007b629add694b  vmovaps [rsp+0x90], xmm10
00007b629add6954  vmovaps [rsp+0xA0], xmm11
00007b629add695d  vmovaps [rsp+0xB0], xmm12
00007b629add6966  vmovaps [rsp+0xC0], xmm13
00007b629add696f  vmovaps [rsp+0xD0], xmm14
00007b629add6978  vmovaps [rsp+0xE0], xmm15
00007b629add6981  sub rsp, 0x30
00007b629add6985  movaps [rsp], xmm7
00007b629add6989  movaps [rsp+0x10], xmm9
00007b629add698f  movaps [rsp+0x20], xmm15
00007b629add6995  lea rdi, [rsp]
00007b629add6999  mov esi, 0x00
00007b629add699e  mov rax, 0x583FED93F530
00007b629add69a8  call rax
00007b629add69aa  movaps xmm7, [rsp]
00007b629add69ae  add rsp, 0x30
00007b629add69b2  vmovaps xmm0, [rsp]
00007b629add69b7  vmovaps xmm1, [rsp+0x10]
00007b629add69bd  vmovaps xmm2, [rsp+0x20]
00007b629add69c3  vmovaps xmm3, [rsp+0x30]
00007b629add69c9  vmovaps xmm4, [rsp+0x40]
00007b629add69cf  vmovaps xmm5, [rsp+0x50]
00007b629add69d5  vmovaps xmm6, [rsp+0x60]
00007b629add69db  vmovaps xmm8, [rsp+0x70]
00007b629add69e1  vmovaps xmm9, [rsp+0x80]
00007b629add69ea  vmovaps xmm10, [rsp+0x90]
00007b629add69f3  vmovaps xmm11, [rsp+0xA0]
00007b629add69fc  vmovaps xmm12, [rsp+0xB0]
00007b629add6a05  vmovaps xmm13, [rsp+0xC0]
00007b629add6a0e  vmovaps xmm14, [rsp+0xD0]
00007b629add6a17  vmovaps xmm15, [rsp+0xE0]
00007b629add6a20  add rsp, 0xF0
00007b629add6a27  pop r11
00007b629add6a29  pop r10
00007b629add6a2b  pop r9
00007b629add6a2d  pop r8
00007b629add6a2f  pop rsi
00007b629add6a30  pop rdi
00007b629add6a31  pop rdx
00007b629add6a32  pop rcx
00007b629add6a33  pop rax
00007b629add6a34  add rsp, 0x08
00007b629add6a38  jmp 0x00007B629ADD59C8
00007b629add6a3d  sub rsp, 0x08
00007b629add6a41  push rax
00007b629add6a42  push rcx
00007b629add6a43  push rdx
00007b629add6a44  push rdi
00007b629add6a45  push rsi
00007b629add6a46  push r8
00007b629add6a48  push r9
00007b629add6a4a  push r10
00007b629add6a4c  push r11
00007b629add6a4e  sub rsp, 0xF0
00007b629add6a55  vmovaps [rsp], xmm0
00007b629add6a5a  vmovaps [rsp+0x10], xmm1
00007b629add6a60  vmovaps [rsp+0x20], xmm2
00007b629add6a66  vmovaps [rsp+0x30], xmm3
00007b629add6a6c  vmovaps [rsp+0x40], xmm4
00007b629add6a72  vmovaps [rsp+0x50], xmm5
00007b629add6a78  vmovaps [rsp+0x60], xmm6
00007b629add6a7e  vmovaps [rsp+0x70], xmm7
00007b629add6a84  vmovaps [rsp+0x80], xmm8
00007b629add6a8d  vmovaps [rsp+0x90], xmm10
00007b629add6a96  vmovaps [rsp+0xA0], xmm11
00007b629add6a9f  vmovaps [rsp+0xB0], xmm12
00007b629add6aa8  vmovaps [rsp+0xC0], xmm13
00007b629add6ab1  vmovaps [rsp+0xD0], xmm14
00007b629add6aba  vmovaps [rsp+0xE0], xmm15
00007b629add6ac3  sub rsp, 0x30
00007b629add6ac7  movaps [rsp], xmm9
00007b629add6acc  movaps [rsp+0x10], xmm12
00007b629add6ad2  movaps [rsp+0x20], xmm10
00007b629add6ad8  lea rdi, [rsp]
00007b629add6adc  mov esi, 0x00
00007b629add6ae1  mov rax, 0x583FED93F530
00007b629add6aeb  call rax
00007b629add6aed  movaps xmm9, [rsp]
00007b629add6af2  add rsp, 0x30
00007b629add6af6  vmovaps xmm0, [rsp]
00007b629add6afb  vmovaps xmm1, [rsp+0x10]
00007b629add6b01  vmovaps xmm2, [rsp+0x20]
00007b629add6b07  vmovaps xmm3, [rsp+0x30]
00007b629add6b0d  vmovaps xmm4, [rsp+0x40]
00007b629add6b13  vmovaps xmm5, [rsp+0x50]
00007b629add6b19  vmovaps xmm6, [rsp+0x60]
00007b629add6b1f  vmovaps xmm7, [rsp+0x70]
00007b629add6b25  vmovaps xmm8, [rsp+0x80]
00007b629add6b2e  vmovaps xmm10, [rsp+0x90]
00007b629add6b37  vmovaps xmm11, [rsp+0xA0]
00007b629add6b40  vmovaps xmm12, [rsp+0xB0]
00007b629add6b49  vmovaps xmm13, [rsp+0xC0]
00007b629add6b52  vmovaps xmm14, [rsp+0xD0]
00007b629add6b5b  vmovaps xmm15, [rsp+0xE0]
00007b629add6b64  add rsp, 0xF0
00007b629add6b6b  pop r11
00007b629add6b6d  pop r10
00007b629add6b6f  pop r9
00007b629add6b71  pop r8
00007b629add6b73  pop rsi
00007b629add6b74  pop rdi
00007b629add6b75  pop rdx
00007b629add6b76  pop rcx
00007b629add6b77  pop rax
00007b629add6b78  add rsp, 0x08
00007b629add6b7c  jmp 0x00007B629ADD59EC
00007b629add6b81  sub rsp, 0x08
00007b629add6b85  push rax
00007b629add6b86  push rcx
00007b629add6b87  push rdx
00007b629add6b88  push rdi
00007b629add6b89  push rsi
00007b629add6b8a  push r8
00007b629add6b8c  push r9
00007b629add6b8e  push r10
00007b629add6b90  push r11
00007b629add6b92  sub rsp, 0xF0
00007b629add6b99  vmovaps [rsp], xmm0
00007b629add6b9e  vmovaps [rsp+0x10], xmm1
00007b629add6ba4  vmovaps [rsp+0x20], xmm2
00007b629add6baa  vmovaps [rsp+0x30], xmm3
00007b629add6bb0  vmovaps [rsp+0x40], xmm4
00007b629add6bb6  vmovaps [rsp+0x50], xmm5
00007b629add6bbc  vmovaps [rsp+0x60], xmm6
00007b629add6bc2  vmovaps [rsp+0x70], xmm7
00007b629add6bc8  vmovaps [rsp+0x80], xmm8
00007b629add6bd1  vmovaps [rsp+0x90], xmm9
00007b629add6bda  vmovaps [rsp+0xA0], xmm11
00007b629add6be3  vmovaps [rsp+0xB0], xmm12
00007b629add6bec  vmovaps [rsp+0xC0], xmm13
00007b629add6bf5  vmovaps [rsp+0xD0], xmm14
00007b629add6bfe  vmovaps [rsp+0xE0], xmm15
00007b629add6c07  sub rsp, 0x30
00007b629add6c0b  movaps [rsp], xmm10
00007b629add6c10  movaps [rsp+0x10], xmm12
00007b629add6c16  movaps [rsp+0x20], xmm11
00007b629add6c1c  lea rdi, [rsp]
00007b629add6c20  mov esi, 0x00
00007b629add6c25  mov rax, 0x583FED93F530
00007b629add6c2f  call rax
00007b629add6c31  movaps xmm10, [rsp]
00007b629add6c36  add rsp, 0x30
00007b629add6c3a  vmovaps xmm0, [rsp]
00007b629add6c3f  vmovaps xmm1, [rsp+0x10]
00007b629add6c45  vmovaps xmm2, [rsp+0x20]
00007b629add6c4b  vmovaps xmm3, [rsp+0x30]
00007b629add6c51  vmovaps xmm4, [rsp+0x40]
00007b629add6c57  vmovaps xmm5, [rsp+0x50]
00007b629add6c5d  vmovaps xmm6, [rsp+0x60]
00007b629add6c63  vmovaps xmm7, [rsp+0x70]
00007b629add6c69  vmovaps xmm8, [rsp+0x80]
00007b629add6c72  vmovaps xmm9, [rsp+0x90]
00007b629add6c7b  vmovaps xmm11, [rsp+0xA0]
00007b629add6c84  vmovaps xmm12, [rsp+0xB0]
00007b629add6c8d  vmovaps xmm13, [rsp+0xC0]
00007b629add6c96  vmovaps xmm14, [rsp+0xD0]
00007b629add6c9f  vmovaps xmm15, [rsp+0xE0]
00007b629add6ca8  add rsp, 0xF0
00007b629add6caf  pop r11
00007b629add6cb1  pop r10
00007b629add6cb3  pop r9
00007b629add6cb5  pop r8
00007b629add6cb7  pop rsi
00007b629add6cb8  pop rdi
00007b629add6cb9  pop rdx
00007b629add6cba  pop rcx
00007b629add6cbb  pop rax
00007b629add6cbc  add rsp, 0x08
00007b629add6cc0  jmp 0x00007B629ADD5A06
00007b629add6cc5  sub rsp, 0x08
00007b629add6cc9  push rax
00007b629add6cca  push rcx
00007b629add6ccb  push rdx
00007b629add6ccc  push rdi
00007b629add6ccd  push rsi
00007b629add6cce  push r8
00007b629add6cd0  push r9
00007b629add6cd2  push r10
00007b629add6cd4  push r11
00007b629add6cd6  sub rsp, 0xF0
00007b629add6cdd  vmovaps [rsp], xmm0
00007b629add6ce2  vmovaps [rsp+0x10], xmm1
00007b629add6ce8  vmovaps [rsp+0x20], xmm2
00007b629add6cee  vmovaps [rsp+0x30], xmm3
00007b629add6cf4  vmovaps [rsp+0x40], xmm4
00007b629add6cfa  vmovaps [rsp+0x50], xmm5
00007b629add6d00  vmovaps [rsp+0x60], xmm7
00007b629add6d06  vmovaps [rsp+0x70], xmm8
00007b629add6d0c  vmovaps [rsp+0x80], xmm9
00007b629add6d15  vmovaps [rsp+0x90], xmm10
00007b629add6d1e  vmovaps [rsp+0xA0], xmm11
00007b629add6d27  vmovaps [rsp+0xB0], xmm12
00007b629add6d30  vmovaps [rsp+0xC0], xmm13
00007b629add6d39  vmovaps [rsp+0xD0], xmm14
00007b629add6d42  vmovaps [rsp+0xE0], xmm15
00007b629add6d4b  sub rsp, 0x30
00007b629add6d4f  movaps [rsp], xmm6
00007b629add6d53  movaps [rsp+0x10], xmm12
00007b629add6d59  movaps [rsp+0x20], xmm11
00007b629add6d5f  lea rdi, [rsp]
00007b629add6d63  mov esi, 0x00
00007b629add6d68  mov rax, 0x583FED93F530
00007b629add6d72  call rax
00007b629add6d74  movaps xmm6, [rsp]
00007b629add6d78  add rsp, 0x30
00007b629add6d7c  vmovaps xmm0, [rsp]
00007b629add6d81  vmovaps xmm1, [rsp+0x10]
00007b629add6d87  vmovaps xmm2, [rsp+0x20]
00007b629add6d8d  vmovaps xmm3, [rsp+0x30]
00007b629add6d93  vmovaps xmm4, [rsp+0x40]
00007b629add6d99  vmovaps xmm5, [rsp+0x50]
00007b629add6d9f  vmovaps xmm7, [rsp+0x60]
00007b629add6da5  vmovaps xmm8, [rsp+0x70]
00007b629add6dab  vmovaps xmm9, [rsp+0x80]
00007b629add6db4  vmovaps xmm10, [rsp+0x90]
00007b629add6dbd  vmovaps xmm11, [rsp+0xA0]
00007b629add6dc6  vmovaps xmm12, [rsp+0xB0]
00007b629add6dcf  vmovaps xmm13, [rsp+0xC0]
00007b629add6dd8  vmovaps xmm14, [rsp+0xD0]
00007b629add6de1  vmovaps xmm15, [rsp+0xE0]
00007b629add6dea  add rsp, 0xF0
00007b629add6df1  pop r11
00007b629add6df3  pop r10
00007b629add6df5  pop r9
00007b629add6df7  pop r8
00007b629add6df9  pop rsi
00007b629add6dfa  pop rdi
00007b629add6dfb  pop rdx
00007b629add6dfc  pop rcx
00007b629add6dfd  pop rax
00007b629add6dfe  add rsp, 0x08
00007b629add6e02  jmp 0x00007B629ADD5A27
00007b629add6e07  sub rsp, 0x08
00007b629add6e0b  push rax
00007b629add6e0c  push rcx
00007b629add6e0d  push rdx
00007b629add6e0e  push rdi
00007b629add6e0f  push rsi
00007b629add6e10  push r8
00007b629add6e12  push r9
00007b629add6e14  push r10
00007b629add6e16  push r11
00007b629add6e18  sub rsp, 0xF0
00007b629add6e1f  vmovaps [rsp], xmm0
00007b629add6e24  vmovaps [rsp+0x10], xmm1
00007b629add6e2a  vmovaps [rsp+0x20], xmm2
00007b629add6e30  vmovaps [rsp+0x30], xmm4
00007b629add6e36  vmovaps [rsp+0x40], xmm5
00007b629add6e3c  vmovaps [rsp+0x50], xmm6
00007b629add6e42  vmovaps [rsp+0x60], xmm7
00007b629add6e48  vmovaps [rsp+0x70], xmm8
00007b629add6e4e  vmovaps [rsp+0x80], xmm9
00007b629add6e57  vmovaps [rsp+0x90], xmm10
00007b629add6e60  vmovaps [rsp+0xA0], xmm11
00007b629add6e69  vmovaps [rsp+0xB0], xmm12
00007b629add6e72  vmovaps [rsp+0xC0], xmm13
00007b629add6e7b  vmovaps [rsp+0xD0], xmm14
00007b629add6e84  vmovaps [rsp+0xE0], xmm15
00007b629add6e8d  sub rsp, 0x30
00007b629add6e91  movaps [rsp], xmm3
00007b629add6e95  movaps [rsp+0x10], xmm5
00007b629add6e9a  movaps [rsp+0x20], xmm4
00007b629add6e9f  lea rdi, [rsp]
00007b629add6ea3  mov esi, 0x00
00007b629add6ea8  mov rax, 0x583FED93F530
00007b629add6eb2  call rax
00007b629add6eb4  movaps xmm3, [rsp]
00007b629add6eb8  add rsp, 0x30
00007b629add6ebc  vmovaps xmm0, [rsp]
00007b629add6ec1  vmovaps xmm1, [rsp+0x10]
00007b629add6ec7  vmovaps xmm2, [rsp+0x20]
00007b629add6ecd  vmovaps xmm4, [rsp+0x30]
00007b629add6ed3  vmovaps xmm5, [rsp+0x40]
00007b629add6ed9  vmovaps xmm6, [rsp+0x50]
00007b629add6edf  vmovaps xmm7, [rsp+0x60]
00007b629add6ee5  vmovaps xmm8, [rsp+0x70]
00007b629add6eeb  vmovaps xmm9, [rsp+0x80]
00007b629add6ef4  vmovaps xmm10, [rsp+0x90]
00007b629add6efd  vmovaps xmm11, [rsp+0xA0]
00007b629add6f06  vmovaps xmm12, [rsp+0xB0]
00007b629add6f0f  vmovaps xmm13, [rsp+0xC0]
00007b629add6f18  vmovaps xmm14, [rsp+0xD0]
00007b629add6f21  vmovaps xmm15, [rsp+0xE0]
00007b629add6f2a  add rsp, 0xF0
00007b629add6f31  pop r11
00007b629add6f33  pop r10
00007b629add6f35  pop r9
00007b629add6f37  pop r8
00007b629add6f39  pop rsi
00007b629add6f3a  pop rdi
00007b629add6f3b  pop rdx
00007b629add6f3c  pop rcx
00007b629add6f3d  pop rax
00007b629add6f3e  add rsp, 0x08
00007b629add6f42  jmp 0x00007B629ADD5A88
00007b629add6f47  sub rsp, 0x08
00007b629add6f4b  push rax
00007b629add6f4c  push rcx
00007b629add6f4d  push rdx
00007b629add6f4e  push rdi
00007b629add6f4f  push rsi
00007b629add6f50  push r8
00007b629add6f52  push r9
00007b629add6f54  push r10
00007b629add6f56  push r11
00007b629add6f58  sub rsp, 0xF0
00007b629add6f5f  vmovaps [rsp], xmm0
00007b629add6f64  vmovaps [rsp+0x10], xmm1
00007b629add6f6a  vmovaps [rsp+0x20], xmm2
00007b629add6f70  vmovaps [rsp+0x30], xmm3
00007b629add6f76  vmovaps [rsp+0x40], xmm4
00007b629add6f7c  vmovaps [rsp+0x50], xmm6
00007b629add6f82  vmovaps [rsp+0x60], xmm7
00007b629add6f88  vmovaps [rsp+0x70], xmm8
00007b629add6f8e  vmovaps [rsp+0x80], xmm9
00007b629add6f97  vmovaps [rsp+0x90], xmm10
00007b629add6fa0  vmovaps [rsp+0xA0], xmm11
00007b629add6fa9  vmovaps [rsp+0xB0], xmm12
00007b629add6fb2  vmovaps [rsp+0xC0], xmm13
00007b629add6fbb  vmovaps [rsp+0xD0], xmm14
00007b629add6fc4  vmovaps [rsp+0xE0], xmm15
00007b629add6fcd  sub rsp, 0x30
00007b629add6fd1  movaps [rsp], xmm5
00007b629add6fd5  movaps [rsp+0x10], xmm8
00007b629add6fdb  movaps [rsp+0x20], xmm15
00007b629add6fe1  lea rdi, [rsp]
00007b629add6fe5  mov esi, 0x00
00007b629add6fea  mov rax, 0x583FED93F530
00007b629add6ff4  call rax
00007b629add6ff6  movaps xmm5, [rsp]
00007b629add6ffa  add rsp, 0x30
00007b629add6ffe  vmovaps xmm0, [rsp]
00007b629add7003  vmovaps xmm1, [rsp+0x10]
00007b629add7009  vmovaps xmm2, [rsp+0x20]
00007b629add700f  vmovaps xmm3, [rsp+0x30]
00007b629add7015  vmovaps xmm4, [rsp+0x40]
00007b629add701b  vmovaps xmm6, [rsp+0x50]
00007b629add7021  vmovaps xmm7, [rsp+0x60]
00007b629add7027  vmovaps xmm8, [rsp+0x70]
00007b629add702d  vmovaps xmm9, [rsp+0x80]
00007b629add7036  vmovaps xmm10, [rsp+0x90]
00007b629add703f  vmovaps xmm11, [rsp+0xA0]
00007b629add7048  vmovaps xmm12, [rsp+0xB0]
00007b629add7051  vmovaps xmm13, [rsp+0xC0]
00007b629add705a  vmovaps xmm14, [rsp+0xD0]
00007b629add7063  vmovaps xmm15, [rsp+0xE0]
00007b629add706c  add rsp, 0xF0
00007b629add7073  pop r11
00007b629add7075  pop r10
00007b629add7077  pop r9
00007b629add7079  pop r8
00007b629add707b  pop rsi
00007b629add707c  pop rdi
00007b629add707d  pop rdx
00007b629add707e  pop rcx
00007b629add707f  pop rax
00007b629add7080  add rsp, 0x08
00007b629add7084  jmp 0x00007B629ADD5AC0
00007b629add7089  sub rsp, 0x08
00007b629add708d  push rax
00007b629add708e  push rcx
00007b629add708f  push rdx
00007b629add7090  push rdi
00007b629add7091  push rsi
00007b629add7092  push r8
00007b629add7094  push r9
00007b629add7096  push r10
00007b629add7098  push r11
00007b629add709a  sub rsp, 0xF0
00007b629add70a1  vmovaps [rsp], xmm0
00007b629add70a6  vmovaps [rsp+0x10], xmm1
00007b629add70ac  vmovaps [rsp+0x20], xmm2
00007b629add70b2  vmovaps [rsp+0x30], xmm3
00007b629add70b8  vmovaps [rsp+0x40], xmm5
00007b629add70be  vmovaps [rsp+0x50], xmm6
00007b629add70c4  vmovaps [rsp+0x60], xmm7
00007b629add70ca  vmovaps [rsp+0x70], xmm8
00007b629add70d0  vmovaps [rsp+0x80], xmm9
00007b629add70d9  vmovaps [rsp+0x90], xmm10
00007b629add70e2  vmovaps [rsp+0xA0], xmm11
00007b629add70eb  vmovaps [rsp+0xB0], xmm12
00007b629add70f4  vmovaps [rsp+0xC0], xmm13
00007b629add70fd  vmovaps [rsp+0xD0], xmm14
00007b629add7106  vmovaps [rsp+0xE0], xmm15
00007b629add710f  sub rsp, 0x30
00007b629add7113  movaps [rsp], xmm4
00007b629add7117  movaps [rsp+0x10], xmm9
00007b629add711d  movaps [rsp+0x20], xmm8
00007b629add7123  lea rdi, [rsp]
00007b629add7127  mov esi, 0x00
00007b629add712c  mov rax, 0x583FED93F530
00007b629add7136  call rax
00007b629add7138  movaps xmm4, [rsp]
00007b629add713c  add rsp, 0x30
00007b629add7140  vmovaps xmm0, [rsp]
00007b629add7145  vmovaps xmm1, [rsp+0x10]
00007b629add714b  vmovaps xmm2, [rsp+0x20]
00007b629add7151  vmovaps xmm3, [rsp+0x30]
00007b629add7157  vmovaps xmm5, [rsp+0x40]
00007b629add715d  vmovaps xmm6, [rsp+0x50]
00007b629add7163  vmovaps xmm7, [rsp+0x60]
00007b629add7169  vmovaps xmm8, [rsp+0x70]
00007b629add716f  vmovaps xmm9, [rsp+0x80]
00007b629add7178  vmovaps xmm10, [rsp+0x90]
00007b629add7181  vmovaps xmm11, [rsp+0xA0]
00007b629add718a  vmovaps xmm12, [rsp+0xB0]
00007b629add7193  vmovaps xmm13, [rsp+0xC0]
00007b629add719c  vmovaps xmm14, [rsp+0xD0]
00007b629add71a5  vmovaps xmm15, [rsp+0xE0]
00007b629add71ae  add rsp, 0xF0
00007b629add71b5  pop r11
00007b629add71b7  pop r10
00007b629add71b9  pop r9
00007b629add71bb  pop r8
00007b629add71bd  pop rsi
00007b629add71be  pop rdi
00007b629add71bf  pop rdx
00007b629add71c0  pop rcx
00007b629add71c1  pop rax
00007b629add71c2  add rsp, 0x08
00007b629add71c6  jmp 0x00007B629ADD5AE1
00007b629add71cb  sub rsp, 0x08
00007b629add71cf  push rax
00007b629add71d0  push rcx
00007b629add71d1  push rdx
00007b629add71d2  push rdi
00007b629add71d3  push rsi
00007b629add71d4  push r8
00007b629add71d6  push r9
00007b629add71d8  push r10
00007b629add71da  push r11
00007b629add71dc  sub rsp, 0xF0
00007b629add71e3  vmovaps [rsp], xmm0
00007b629add71e8  vmovaps [rsp+0x10], xmm1
00007b629add71ee  vmovaps [rsp+0x20], xmm2
00007b629add71f4  vmovaps [rsp+0x30], xmm3
00007b629add71fa  vmovaps [rsp+0x40], xmm4
00007b629add7200  vmovaps [rsp+0x50], xmm5
00007b629add7206  vmovaps [rsp+0x60], xmm6
00007b629add720c  vmovaps [rsp+0x70], xmm7
00007b629add7212  vmovaps [rsp+0x80], xmm8
00007b629add721b  vmovaps [rsp+0x90], xmm10
00007b629add7224  vmovaps [rsp+0xA0], xmm11
00007b629add722d  vmovaps [rsp+0xB0], xmm12
00007b629add7236  vmovaps [rsp+0xC0], xmm13
00007b629add723f  vmovaps [rsp+0xD0], xmm14
00007b629add7248  vmovaps [rsp+0xE0], xmm15
00007b629add7251  sub rsp, 0x30
00007b629add7255  movaps [rsp], xmm9
00007b629add725a  movaps [rsp+0x10], xmm10
00007b629add7260  movaps [rsp+0x20], xmm8
00007b629add7266  lea rdi, [rsp]
00007b629add726a  mov esi, 0x00
00007b629add726f  mov rax, 0x583FED93F530
00007b629add7279  call rax
00007b629add727b  movaps xmm9, [rsp]
00007b629add7280  add rsp, 0x30
00007b629add7284  vmovaps xmm0, [rsp]
00007b629add7289  vmovaps xmm1, [rsp+0x10]
00007b629add728f  vmovaps xmm2, [rsp+0x20]
00007b629add7295  vmovaps xmm3, [rsp+0x30]
00007b629add729b  vmovaps xmm4, [rsp+0x40]
00007b629add72a1  vmovaps xmm5, [rsp+0x50]
00007b629add72a7  vmovaps xmm6, [rsp+0x60]
00007b629add72ad  vmovaps xmm7, [rsp+0x70]
00007b629add72b3  vmovaps xmm8, [rsp+0x80]
00007b629add72bc  vmovaps xmm10, [rsp+0x90]
00007b629add72c5  vmovaps xmm11, [rsp+0xA0]
00007b629add72ce  vmovaps xmm12, [rsp+0xB0]
00007b629add72d7  vmovaps xmm13, [rsp+0xC0]
00007b629add72e0  vmovaps xmm14, [rsp+0xD0]
00007b629add72e9  vmovaps xmm15, [rsp+0xE0]
00007b629add72f2  add rsp, 0xF0
00007b629add72f9  pop r11
00007b629add72fb  pop r10
00007b629add72fd  pop r9
00007b629add72ff  pop r8
00007b629add7301  pop rsi
00007b629add7302  pop rdi
00007b629add7303  pop rdx
00007b629add7304  pop rcx
00007b629add7305  pop rax
00007b629add7306  add rsp, 0x08
00007b629add730a  jmp 0x00007B629ADD5AFB
00007b629add730f  call 0x00007B629ACD64F0
00007b629add7314  jmp 0x00007B629ADD5C15
00007b629add7319  call 0x00007B629ACD64F0
00007b629add731e  jmp 0x00007B629ADD5C2B
00007b629add7323  sub rsp, 0x08
00007b629add7327  push rax
00007b629add7328  push rcx
00007b629add7329  push rdx
00007b629add732a  push rdi
00007b629add732b  push rsi
00007b629add732c  push r8
00007b629add732e  push r9
00007b629add7330  push r10
00007b629add7332  push r11
00007b629add7334  sub rsp, 0xF0
00007b629add733b  vmovaps [rsp], xmm0
00007b629add7340  vmovaps [rsp+0x10], xmm2
00007b629add7346  vmovaps [rsp+0x20], xmm3
00007b629add734c  vmovaps [rsp+0x30], xmm4
00007b629add7352  vmovaps [rsp+0x40], xmm5
00007b629add7358  vmovaps [rsp+0x50], xmm6
00007b629add735e  vmovaps [rsp+0x60], xmm7
00007b629add7364  vmovaps [rsp+0x70], xmm8
00007b629add736a  vmovaps [rsp+0x80], xmm9
00007b629add7373  vmovaps [rsp+0x90], xmm10
00007b629add737c  vmovaps [rsp+0xA0], xmm11
00007b629add7385  vmovaps [rsp+0xB0], xmm12
00007b629add738e  vmovaps [rsp+0xC0], xmm13
00007b629add7397  vmovaps [rsp+0xD0], xmm14
00007b629add73a0  vmovaps [rsp+0xE0], xmm15
00007b629add73a9  sub rsp, 0x30
00007b629add73ad  movaps [rsp], xmm1
00007b629add73b1  movaps [rsp+0x10], xmm6
00007b629add73b6  movaps [rsp+0x20], xmm15
00007b629add73bc  lea rdi, [rsp]
00007b629add73c0  mov esi, 0x00
00007b629add73c5  mov rax, 0x583FED93F530
00007b629add73cf  call rax
00007b629add73d1  movaps xmm1, [rsp]
00007b629add73d5  add rsp, 0x30
00007b629add73d9  vmovaps xmm0, [rsp]
00007b629add73de  vmovaps xmm2, [rsp+0x10]
00007b629add73e4  vmovaps xmm3, [rsp+0x20]
00007b629add73ea  vmovaps xmm4, [rsp+0x30]
00007b629add73f0  vmovaps xmm5, [rsp+0x40]
00007b629add73f6  vmovaps xmm6, [rsp+0x50]
00007b629add73fc  vmovaps xmm7, [rsp+0x60]
00007b629add7402  vmovaps xmm8, [rsp+0x70]
00007b629add7408  vmovaps xmm9, [rsp+0x80]
00007b629add7411  vmovaps xmm10, [rsp+0x90]
00007b629add741a  vmovaps xmm11, [rsp+0xA0]
00007b629add7423  vmovaps xmm12, [rsp+0xB0]
00007b629add742c  vmovaps xmm13, [rsp+0xC0]
00007b629add7435  vmovaps xmm14, [rsp+0xD0]
00007b629add743e  vmovaps xmm15, [rsp+0xE0]
00007b629add7447  add rsp, 0xF0
00007b629add744e  pop r11
00007b629add7450  pop r10
00007b629add7452  pop r9
00007b629add7454  pop r8
00007b629add7456  pop rsi
00007b629add7457  pop rdi
00007b629add7458  pop rdx
00007b629add7459  pop rcx
00007b629add745a  pop rax
00007b629add745b  add rsp, 0x08
00007b629add745f  jmp 0x00007B629ADD5C68
00007b629add7464  call 0x00007B629ACE5820
00007b629add7469  jmp 0x00007B629ADD5C75
00007b629add746e  sub rsp, 0x08
00007b629add7472  push rax
00007b629add7473  push rcx
00007b629add7474  push rdx
00007b629add7475  push rdi
00007b629add7476  push rsi
00007b629add7477  push r8
00007b629add7479  push r9
00007b629add747b  push r10
00007b629add747d  push r11
00007b629add747f  sub rsp, 0xF0
00007b629add7486  vmovaps [rsp], xmm0
00007b629add748b  vmovaps [rsp+0x10], xmm1
00007b629add7491  vmovaps [rsp+0x20], xmm2
00007b629add7497  vmovaps [rsp+0x30], xmm3
00007b629add749d  vmovaps [rsp+0x40], xmm4
00007b629add74a3  vmovaps [rsp+0x50], xmm5
00007b629add74a9  vmovaps [rsp+0x60], xmm6
00007b629add74af  vmovaps [rsp+0x70], xmm7
00007b629add74b5  vmovaps [rsp+0x80], xmm8
00007b629add74be  vmovaps [rsp+0x90], xmm9
00007b629add74c7  vmovaps [rsp+0xA0], xmm10
00007b629add74d0  vmovaps [rsp+0xB0], xmm11
00007b629add74d9  vmovaps [rsp+0xC0], xmm12
00007b629add74e2  vmovaps [rsp+0xD0], xmm13
00007b629add74eb  vmovaps [rsp+0xE0], xmm15
00007b629add74f4  sub rsp, 0x30
00007b629add74f8  movaps [rsp], xmm14
00007b629add74fd  movaps [rsp+0x10], xmm4
00007b629add7502  movaps [rsp+0x20], xmm3
00007b629add7507  lea rdi, [rsp]
00007b629add750b  mov esi, 0x00
00007b629add7510  mov rax, 0x583FED93F530
00007b629add751a  call rax
00007b629add751c  movaps xmm14, [rsp]
00007b629add7521  add rsp, 0x30
00007b629add7525  vmovaps xmm0, [rsp]
00007b629add752a  vmovaps xmm1, [rsp+0x10]
00007b629add7530  vmovaps xmm2, [rsp+0x20]
00007b629add7536  vmovaps xmm3, [rsp+0x30]
00007b629add753c  vmovaps xmm4, [rsp+0x40]
00007b629add7542  vmovaps xmm5, [rsp+0x50]
00007b629add7548  vmovaps xmm6, [rsp+0x60]
00007b629add754e  vmovaps xmm7, [rsp+0x70]
00007b629add7554  vmovaps xmm8, [rsp+0x80]
00007b629add755d  vmovaps xmm9, [rsp+0x90]
00007b629add7566  vmovaps xmm10, [rsp+0xA0]
00007b629add756f  vmovaps xmm11, [rsp+0xB0]
00007b629add7578  vmovaps xmm12, [rsp+0xC0]
00007b629add7581  vmovaps xmm13, [rsp+0xD0]
00007b629add758a  vmovaps xmm15, [rsp+0xE0]
00007b629add7593  add rsp, 0xF0
00007b629add759a  pop r11
00007b629add759c  pop r10
00007b629add759e  pop r9
00007b629add75a0  pop r8
00007b629add75a2  pop rsi
00007b629add75a3  pop rdi
00007b629add75a4  pop rdx
00007b629add75a5  pop rcx
00007b629add75a6  pop rax
00007b629add75a7  add rsp, 0x08
00007b629add75ab  jmp 0x00007B629ADD5C8F
00007b629add75b0  sub rsp, 0x08
00007b629add75b4  push rax
00007b629add75b5  push rcx
00007b629add75b6  push rdx
00007b629add75b7  push rdi
00007b629add75b8  push rsi
00007b629add75b9  push r8
00007b629add75bb  push r9
00007b629add75bd  push r10
00007b629add75bf  push r11
00007b629add75c1  sub rsp, 0xF0
00007b629add75c8  vmovaps [rsp], xmm0
00007b629add75cd  vmovaps [rsp+0x10], xmm1
00007b629add75d3  vmovaps [rsp+0x20], xmm2
00007b629add75d9  vmovaps [rsp+0x30], xmm3
00007b629add75df  vmovaps [rsp+0x40], xmm4
00007b629add75e5  vmovaps [rsp+0x50], xmm5
00007b629add75eb  vmovaps [rsp+0x60], xmm7
00007b629add75f1  vmovaps [rsp+0x70], xmm8
00007b629add75f7  vmovaps [rsp+0x80], xmm9
00007b629add7600  vmovaps [rsp+0x90], xmm10
00007b629add7609  vmovaps [rsp+0xA0], xmm11
00007b629add7612  vmovaps [rsp+0xB0], xmm12
00007b629add761b  vmovaps [rsp+0xC0], xmm13
00007b629add7624  vmovaps [rsp+0xD0], xmm14
00007b629add762d  vmovaps [rsp+0xE0], xmm15
00007b629add7636  sub rsp, 0x30
00007b629add763a  movaps [rsp], xmm6
00007b629add763e  movaps [rsp+0x10], xmm9
00007b629add7644  movaps [rsp+0x20], xmm7
00007b629add7649  lea rdi, [rsp]
00007b629add764d  mov esi, 0x00
00007b629add7652  mov rax, 0x583FED93F530
00007b629add765c  call rax
00007b629add765e  movaps xmm6, [rsp]
00007b629add7662  add rsp, 0x30
00007b629add7666  vmovaps xmm0, [rsp]
00007b629add766b  vmovaps xmm1, [rsp+0x10]
00007b629add7671  vmovaps xmm2, [rsp+0x20]
00007b629add7677  vmovaps xmm3, [rsp+0x30]
00007b629add767d  vmovaps xmm4, [rsp+0x40]
00007b629add7683  vmovaps xmm5, [rsp+0x50]
00007b629add7689  vmovaps xmm7, [rsp+0x60]
00007b629add768f  vmovaps xmm8, [rsp+0x70]
00007b629add7695  vmovaps xmm9, [rsp+0x80]
00007b629add769e  vmovaps xmm10, [rsp+0x90]
00007b629add76a7  vmovaps xmm11, [rsp+0xA0]
00007b629add76b0  vmovaps xmm12, [rsp+0xB0]
00007b629add76b9  vmovaps xmm13, [rsp+0xC0]
00007b629add76c2  vmovaps xmm14, [rsp+0xD0]
00007b629add76cb  vmovaps xmm15, [rsp+0xE0]
00007b629add76d4  add rsp, 0xF0
00007b629add76db  pop r11
00007b629add76dd  pop r10
00007b629add76df  pop r9
00007b629add76e1  pop r8
00007b629add76e3  pop rsi
00007b629add76e4  pop rdi
00007b629add76e5  pop rdx
00007b629add76e6  pop rcx
00007b629add76e7  pop rax
00007b629add76e8  add rsp, 0x08
00007b629add76ec  jmp 0x00007B629ADD5CA7
00007b629add76f1  sub rsp, 0x08
00007b629add76f5  push rax
00007b629add76f6  push rcx
00007b629add76f7  push rdx
00007b629add76f8  push rdi
00007b629add76f9  push rsi
00007b629add76fa  push r8
00007b629add76fc  push r9
00007b629add76fe  push r10
00007b629add7700  push r11
00007b629add7702  sub rsp, 0xF0
00007b629add7709  vmovaps [rsp], xmm0
00007b629add770e  vmovaps [rsp+0x10], xmm1
00007b629add7714  vmovaps [rsp+0x20], xmm2
00007b629add771a  vmovaps [rsp+0x30], xmm3
00007b629add7720  vmovaps [rsp+0x40], xmm4
00007b629add7726  vmovaps [rsp+0x50], xmm5
00007b629add772c  vmovaps [rsp+0x60], xmm6
00007b629add7732  vmovaps [rsp+0x70], xmm8
00007b629add7738  vmovaps [rsp+0x80], xmm9
00007b629add7741  vmovaps [rsp+0x90], xmm10
00007b629add774a  vmovaps [rsp+0xA0], xmm11
00007b629add7753  vmovaps [rsp+0xB0], xmm12
00007b629add775c  vmovaps [rsp+0xC0], xmm13
00007b629add7765  vmovaps [rsp+0xD0], xmm14
00007b629add776e  vmovaps [rsp+0xE0], xmm15
00007b629add7777  sub rsp, 0x30
00007b629add777b  movaps [rsp], xmm7
00007b629add777f  movaps [rsp+0x10], xmm4
00007b629add7784  movaps [rsp+0x20], xmm9
00007b629add778a  lea rdi, [rsp]
00007b629add778e  mov esi, 0x00
00007b629add7793  mov rax, 0x583FED93F530
00007b629add779d  call rax
00007b629add779f  movaps xmm7, [rsp]
00007b629add77a3  add rsp, 0x30
00007b629add77a7  vmovaps xmm0, [rsp]
00007b629add77ac  vmovaps xmm1, [rsp+0x10]
00007b629add77b2  vmovaps xmm2, [rsp+0x20]
00007b629add77b8  vmovaps xmm3, [rsp+0x30]
00007b629add77be  vmovaps xmm4, [rsp+0x40]
00007b629add77c4  vmovaps xmm5, [rsp+0x50]
00007b629add77ca  vmovaps xmm6, [rsp+0x60]
00007b629add77d0  vmovaps xmm8, [rsp+0x70]
00007b629add77d6  vmovaps xmm9, [rsp+0x80]
00007b629add77df  vmovaps xmm10, [rsp+0x90]
00007b629add77e8  vmovaps xmm11, [rsp+0xA0]
00007b629add77f1  vmovaps xmm12, [rsp+0xB0]
00007b629add77fa  vmovaps xmm13, [rsp+0xC0]
00007b629add7803  vmovaps xmm14, [rsp+0xD0]
00007b629add780c  vmovaps xmm15, [rsp+0xE0]
00007b629add7815  add rsp, 0xF0
00007b629add781c  pop r11
00007b629add781e  pop r10
00007b629add7820  pop r9
00007b629add7822  pop r8
00007b629add7824  pop rsi
00007b629add7825  pop rdi
00007b629add7826  pop rdx
00007b629add7827  pop rcx
00007b629add7828  pop rax
00007b629add7829  add rsp, 0x08
00007b629add782d  jmp 0x00007B629ADD5CD4
00007b629add7832  sub rsp, 0x08
00007b629add7836  push rax
00007b629add7837  push rcx
00007b629add7838  push rdx
00007b629add7839  push rdi
00007b629add783a  push rsi
00007b629add783b  push r8
00007b629add783d  push r9
00007b629add783f  push r10
00007b629add7841  push r11
00007b629add7843  sub rsp, 0xF0
00007b629add784a  vmovaps [rsp], xmm0
00007b629add784f  vmovaps [rsp+0x10], xmm1
00007b629add7855  vmovaps [rsp+0x20], xmm2
00007b629add785b  vmovaps [rsp+0x30], xmm3
00007b629add7861  vmovaps [rsp+0x40], xmm5
00007b629add7867  vmovaps [rsp+0x50], xmm6
00007b629add786d  vmovaps [rsp+0x60], xmm7
00007b629add7873  vmovaps [rsp+0x70], xmm8
00007b629add7879  vmovaps [rsp+0x80], xmm9
00007b629add7882  vmovaps [rsp+0x90], xmm10
00007b629add788b  vmovaps [rsp+0xA0], xmm11
00007b629add7894  vmovaps [rsp+0xB0], xmm12
00007b629add789d  vmovaps [rsp+0xC0], xmm13
00007b629add78a6  vmovaps [rsp+0xD0], xmm14
00007b629add78af  vmovaps [rsp+0xE0], xmm15
00007b629add78b8  sub rsp, 0x30
00007b629add78bc  movaps [rsp], xmm4
00007b629add78c0  movaps [rsp+0x10], xmm15
00007b629add78c6  movaps [rsp+0x20], xmm9
00007b629add78cc  lea rdi, [rsp]
00007b629add78d0  mov esi, 0x00
00007b629add78d5  mov rax, 0x583FED93F530
00007b629add78df  call rax
00007b629add78e1  movaps xmm4, [rsp]
00007b629add78e5  add rsp, 0x30
00007b629add78e9  vmovaps xmm0, [rsp]
00007b629add78ee  vmovaps xmm1, [rsp+0x10]
00007b629add78f4  vmovaps xmm2, [rsp+0x20]
00007b629add78fa  vmovaps xmm3, [rsp+0x30]
00007b629add7900  vmovaps xmm5, [rsp+0x40]
00007b629add7906  vmovaps xmm6, [rsp+0x50]
00007b629add790c  vmovaps xmm7, [rsp+0x60]
00007b629add7912  vmovaps xmm8, [rsp+0x70]
00007b629add7918  vmovaps xmm9, [rsp+0x80]
00007b629add7921  vmovaps xmm10, [rsp+0x90]
00007b629add792a  vmovaps xmm11, [rsp+0xA0]
00007b629add7933  vmovaps xmm12, [rsp+0xB0]
00007b629add793c  vmovaps xmm13, [rsp+0xC0]
00007b629add7945  vmovaps xmm14, [rsp+0xD0]
00007b629add794e  vmovaps xmm15, [rsp+0xE0]
00007b629add7957  add rsp, 0xF0
00007b629add795e  pop r11
00007b629add7960  pop r10
00007b629add7962  pop r9
00007b629add7964  pop r8
00007b629add7966  pop rsi
00007b629add7967  pop rdi
00007b629add7968  pop rdx
00007b629add7969  pop rcx
00007b629add796a  pop rax
00007b629add796b  add rsp, 0x08
00007b629add796f  jmp 0x00007B629ADD5CF9
00007b629add7974  call 0x00007B629ACE5820
00007b629add7979  jmp 0x00007B629ADD5D06
00007b629add797e  sub rsp, 0x08
00007b629add7982  push rax
00007b629add7983  push rcx
00007b629add7984  push rdx
00007b629add7985  push rdi
00007b629add7986  push rsi
00007b629add7987  push r8
00007b629add7989  push r9
00007b629add798b  push r10
00007b629add798d  push r11
00007b629add798f  sub rsp, 0xF0
00007b629add7996  vmovaps [rsp], xmm0
00007b629add799b  vmovaps [rsp+0x10], xmm1
00007b629add79a1  vmovaps [rsp+0x20], xmm2
00007b629add79a7  vmovaps [rsp+0x30], xmm4
00007b629add79ad  vmovaps [rsp+0x40], xmm5
00007b629add79b3  vmovaps [rsp+0x50], xmm6
00007b629add79b9  vmovaps [rsp+0x60], xmm7
00007b629add79bf  vmovaps [rsp+0x70], xmm8
00007b629add79c5  vmovaps [rsp+0x80], xmm9
00007b629add79ce  vmovaps [rsp+0x90], xmm10
00007b629add79d7  vmovaps [rsp+0xA0], xmm11
00007b629add79e0  vmovaps [rsp+0xB0], xmm12
00007b629add79e9  vmovaps [rsp+0xC0], xmm13
00007b629add79f2  vmovaps [rsp+0xD0], xmm14
00007b629add79fb  vmovaps [rsp+0xE0], xmm15
00007b629add7a04  sub rsp, 0x30
00007b629add7a08  movaps [rsp], xmm3
00007b629add7a0c  movaps [rsp+0x10], xmm1
00007b629add7a11  movaps [rsp+0x20], xmm9
00007b629add7a17  lea rdi, [rsp]
00007b629add7a1b  mov esi, 0x00
00007b629add7a20  mov rax, 0x583FED93F530
00007b629add7a2a  call rax
00007b629add7a2c  movaps xmm3, [rsp]
00007b629add7a30  add rsp, 0x30
00007b629add7a34  vmovaps xmm0, [rsp]
00007b629add7a39  vmovaps xmm1, [rsp+0x10]
00007b629add7a3f  vmovaps xmm2, [rsp+0x20]
00007b629add7a45  vmovaps xmm4, [rsp+0x30]
00007b629add7a4b  vmovaps xmm5, [rsp+0x40]
00007b629add7a51  vmovaps xmm6, [rsp+0x50]
00007b629add7a57  vmovaps xmm7, [rsp+0x60]
00007b629add7a5d  vmovaps xmm8, [rsp+0x70]
00007b629add7a63  vmovaps xmm9, [rsp+0x80]
00007b629add7a6c  vmovaps xmm10, [rsp+0x90]
00007b629add7a75  vmovaps xmm11, [rsp+0xA0]
00007b629add7a7e  vmovaps xmm12, [rsp+0xB0]
00007b629add7a87  vmovaps xmm13, [rsp+0xC0]
00007b629add7a90  vmovaps xmm14, [rsp+0xD0]
00007b629add7a99  vmovaps xmm15, [rsp+0xE0]
00007b629add7aa2  add rsp, 0xF0
00007b629add7aa9  pop r11
00007b629add7aab  pop r10
00007b629add7aad  pop r9
00007b629add7aaf  pop r8
00007b629add7ab1  pop rsi
00007b629add7ab2  pop rdi
00007b629add7ab3  pop rdx
00007b629add7ab4  pop rcx
00007b629add7ab5  pop rax
00007b629add7ab6  add rsp, 0x08
00007b629add7aba  jmp 0x00007B629ADD5D43
00007b629add7abf  sub rsp, 0x08
00007b629add7ac3  push rax
00007b629add7ac4  push rcx
00007b629add7ac5  push rdx
00007b629add7ac6  push rdi
00007b629add7ac7  push rsi
00007b629add7ac8  push r8
00007b629add7aca  push r9
00007b629add7acc  push r10
00007b629add7ace  push r11
00007b629add7ad0  sub rsp, 0xF0
00007b629add7ad7  vmovaps [rsp], xmm0
00007b629add7adc  vmovaps [rsp+0x10], xmm2
00007b629add7ae2  vmovaps [rsp+0x20], xmm3
00007b629add7ae8  vmovaps [rsp+0x30], xmm4
00007b629add7aee  vmovaps [rsp+0x40], xmm5
00007b629add7af4  vmovaps [rsp+0x50], xmm6
00007b629add7afa  vmovaps [rsp+0x60], xmm7
00007b629add7b00  vmovaps [rsp+0x70], xmm8
00007b629add7b06  vmovaps [rsp+0x80], xmm9
00007b629add7b0f  vmovaps [rsp+0x90], xmm10
00007b629add7b18  vmovaps [rsp+0xA0], xmm11
00007b629add7b21  vmovaps [rsp+0xB0], xmm12
00007b629add7b2a  vmovaps [rsp+0xC0], xmm13
00007b629add7b33  vmovaps [rsp+0xD0], xmm14
00007b629add7b3c  vmovaps [rsp+0xE0], xmm15
00007b629add7b45  sub rsp, 0x30
00007b629add7b49  movaps [rsp], xmm1
00007b629add7b4d  movaps [rsp+0x10], xmm15
00007b629add7b53  movaps [rsp+0x20], xmm9
00007b629add7b59  lea rdi, [rsp]
00007b629add7b5d  mov esi, 0x00
00007b629add7b62  mov rax, 0x583FED93F530
00007b629add7b6c  call rax
00007b629add7b6e  movaps xmm1, [rsp]
00007b629add7b72  add rsp, 0x30
00007b629add7b76  vmovaps xmm0, [rsp]
00007b629add7b7b  vmovaps xmm2, [rsp+0x10]
00007b629add7b81  vmovaps xmm3, [rsp+0x20]
00007b629add7b87  vmovaps xmm4, [rsp+0x30]
00007b629add7b8d  vmovaps xmm5, [rsp+0x40]
00007b629add7b93  vmovaps xmm6, [rsp+0x50]
00007b629add7b99  vmovaps xmm7, [rsp+0x60]
00007b629add7b9f  vmovaps xmm8, [rsp+0x70]
00007b629add7ba5  vmovaps xmm9, [rsp+0x80]
00007b629add7bae  vmovaps xmm10, [rsp+0x90]
00007b629add7bb7  vmovaps xmm11, [rsp+0xA0]
00007b629add7bc0  vmovaps xmm12, [rsp+0xB0]
00007b629add7bc9  vmovaps xmm13, [rsp+0xC0]
00007b629add7bd2  vmovaps xmm14, [rsp+0xD0]
00007b629add7bdb  vmovaps xmm15, [rsp+0xE0]
00007b629add7be4  add rsp, 0xF0
00007b629add7beb  pop r11
00007b629add7bed  pop r10
00007b629add7bef  pop r9
00007b629add7bf1  pop r8
00007b629add7bf3  pop rsi
00007b629add7bf4  pop rdi
00007b629add7bf5  pop rdx
00007b629add7bf6  pop rcx
00007b629add7bf7  pop rax
00007b629add7bf8  add rsp, 0x08
00007b629add7bfc  jmp 0x00007B629ADD5DCB
00007b629add7c01  call 0x00007B629ACE5820
00007b629add7c06  jmp 0x00007B629ADD5DD8
00007b629add7c0b  sub rsp, 0x08
00007b629add7c0f  push rax
00007b629add7c10  push rcx
00007b629add7c11  push rdx
00007b629add7c12  push rdi
00007b629add7c13  push rsi
00007b629add7c14  push r8
00007b629add7c16  push r9
00007b629add7c18  push r10
00007b629add7c1a  push r11
00007b629add7c1c  sub rsp, 0xF0
00007b629add7c23  vmovaps [rsp], xmm0
00007b629add7c28  vmovaps [rsp+0x10], xmm2
00007b629add7c2e  vmovaps [rsp+0x20], xmm3
00007b629add7c34  vmovaps [rsp+0x30], xmm4
00007b629add7c3a  vmovaps [rsp+0x40], xmm5
00007b629add7c40  vmovaps [rsp+0x50], xmm6
00007b629add7c46  vmovaps [rsp+0x60], xmm7
00007b629add7c4c  vmovaps [rsp+0x70], xmm8
00007b629add7c52  vmovaps [rsp+0x80], xmm9
00007b629add7c5b  vmovaps [rsp+0x90], xmm10
00007b629add7c64  vmovaps [rsp+0xA0], xmm11
00007b629add7c6d  vmovaps [rsp+0xB0], xmm12
00007b629add7c76  vmovaps [rsp+0xC0], xmm13
00007b629add7c7f  vmovaps [rsp+0xD0], xmm14
00007b629add7c88  vmovaps [rsp+0xE0], xmm15
00007b629add7c91  sub rsp, 0x30
00007b629add7c95  movaps [rsp], xmm1
00007b629add7c99  movaps [rsp+0x10], xmm5
00007b629add7c9e  movaps [rsp+0x20], xmm7
00007b629add7ca3  lea rdi, [rsp]
00007b629add7ca7  mov esi, 0x00
00007b629add7cac  mov rax, 0x583FED93F530
00007b629add7cb6  call rax
00007b629add7cb8  movaps xmm1, [rsp]
00007b629add7cbc  add rsp, 0x30
00007b629add7cc0  vmovaps xmm0, [rsp]
00007b629add7cc5  vmovaps xmm2, [rsp+0x10]
00007b629add7ccb  vmovaps xmm3, [rsp+0x20]
00007b629add7cd1  vmovaps xmm4, [rsp+0x30]
00007b629add7cd7  vmovaps xmm5, [rsp+0x40]
00007b629add7cdd  vmovaps xmm6, [rsp+0x50]
00007b629add7ce3  vmovaps xmm7, [rsp+0x60]
00007b629add7ce9  vmovaps xmm8, [rsp+0x70]
00007b629add7cef  vmovaps xmm9, [rsp+0x80]
00007b629add7cf8  vmovaps xmm10, [rsp+0x90]
00007b629add7d01  vmovaps xmm11, [rsp+0xA0]
00007b629add7d0a  vmovaps xmm12, [rsp+0xB0]
00007b629add7d13  vmovaps xmm13, [rsp+0xC0]
00007b629add7d1c  vmovaps xmm14, [rsp+0xD0]
00007b629add7d25  vmovaps xmm15, [rsp+0xE0]
00007b629add7d2e  add rsp, 0xF0
00007b629add7d35  pop r11
00007b629add7d37  pop r10
00007b629add7d39  pop r9
00007b629add7d3b  pop r8
00007b629add7d3d  pop rsi
00007b629add7d3e  pop rdi
00007b629add7d3f  pop rdx
00007b629add7d40  pop rcx
00007b629add7d41  pop rax
00007b629add7d42  add rsp, 0x08
00007b629add7d46  jmp 0x00007B629ADD5E7D
00007b629add7d4b  sub rsp, 0x08
00007b629add7d4f  push rax
00007b629add7d50  push rcx
00007b629add7d51  push rdx
00007b629add7d52  push rdi
00007b629add7d53  push rsi
00007b629add7d54  push r8
00007b629add7d56  push r9
00007b629add7d58  push r10
00007b629add7d5a  push r11
00007b629add7d5c  sub rsp, 0xF0
00007b629add7d63  vmovaps [rsp], xmm0
00007b629add7d68  vmovaps [rsp+0x10], xmm1
00007b629add7d6e  vmovaps [rsp+0x20], xmm2
00007b629add7d74  vmovaps [rsp+0x30], xmm3
00007b629add7d7a  vmovaps [rsp+0x40], xmm4
00007b629add7d80  vmovaps [rsp+0x50], xmm5
00007b629add7d86  vmovaps [rsp+0x60], xmm6
00007b629add7d8c  vmovaps [rsp+0x70], xmm8
00007b629add7d92  vmovaps [rsp+0x80], xmm9
00007b629add7d9b  vmovaps [rsp+0x90], xmm10
00007b629add7da4  vmovaps [rsp+0xA0], xmm11
00007b629add7dad  vmovaps [rsp+0xB0], xmm12
00007b629add7db6  vmovaps [rsp+0xC0], xmm13
00007b629add7dbf  vmovaps [rsp+0xD0], xmm14
00007b629add7dc8  vmovaps [rsp+0xE0], xmm15
00007b629add7dd1  sub rsp, 0x30
00007b629add7dd5  movaps [rsp], xmm7
00007b629add7dd9  movaps [rsp+0x10], xmm5
00007b629add7dde  movaps [rsp+0x20], xmm15
00007b629add7de4  lea rdi, [rsp]
00007b629add7de8  mov esi, 0x00
00007b629add7ded  mov rax, 0x583FED93F530
00007b629add7df7  call rax
00007b629add7df9  movaps xmm7, [rsp]
00007b629add7dfd  add rsp, 0x30
00007b629add7e01  vmovaps xmm0, [rsp]
00007b629add7e06  vmovaps xmm1, [rsp+0x10]
00007b629add7e0c  vmovaps xmm2, [rsp+0x20]
00007b629add7e12  vmovaps xmm3, [rsp+0x30]
00007b629add7e18  vmovaps xmm4, [rsp+0x40]
00007b629add7e1e  vmovaps xmm5, [rsp+0x50]
00007b629add7e24  vmovaps xmm6, [rsp+0x60]
00007b629add7e2a  vmovaps xmm8, [rsp+0x70]
00007b629add7e30  vmovaps xmm9, [rsp+0x80]
00007b629add7e39  vmovaps xmm10, [rsp+0x90]
00007b629add7e42  vmovaps xmm11, [rsp+0xA0]
00007b629add7e4b  vmovaps xmm12, [rsp+0xB0]
00007b629add7e54  vmovaps xmm13, [rsp+0xC0]
00007b629add7e5d  vmovaps xmm14, [rsp+0xD0]
00007b629add7e66  vmovaps xmm15, [rsp+0xE0]
00007b629add7e6f  add rsp, 0xF0
00007b629add7e76  pop r11
00007b629add7e78  pop r10
00007b629add7e7a  pop r9
00007b629add7e7c  pop r8
00007b629add7e7e  pop rsi
00007b629add7e7f  pop rdi
00007b629add7e80  pop rdx
00007b629add7e81  pop rcx
00007b629add7e82  pop rax
00007b629add7e83  add rsp, 0x08
00007b629add7e87  jmp 0x00007B629ADD5EB3
00007b629add7e8c  call 0x00007B629ACD64F0
00007b629add7e91  jmp 0x00007B629ADD5EC0
00007b629add7e96  sub rsp, 0x08
00007b629add7e9a  push rax
00007b629add7e9b  push rcx
00007b629add7e9c  push rdx
00007b629add7e9d  push rdi
00007b629add7e9e  push rsi
00007b629add7e9f  push r8
00007b629add7ea1  push r9
00007b629add7ea3  push r10
00007b629add7ea5  push r11
00007b629add7ea7  sub rsp, 0xF0
00007b629add7eae  vmovaps [rsp], xmm0
00007b629add7eb3  vmovaps [rsp+0x10], xmm1
00007b629add7eb9  vmovaps [rsp+0x20], xmm2
00007b629add7ebf  vmovaps [rsp+0x30], xmm3
00007b629add7ec5  vmovaps [rsp+0x40], xmm4
00007b629add7ecb  vmovaps [rsp+0x50], xmm5
00007b629add7ed1  vmovaps [rsp+0x60], xmm6
00007b629add7ed7  vmovaps [rsp+0x70], xmm7
00007b629add7edd  vmovaps [rsp+0x80], xmm8
00007b629add7ee6  vmovaps [rsp+0x90], xmm9
00007b629add7eef  vmovaps [rsp+0xA0], xmm10
00007b629add7ef8  vmovaps [rsp+0xB0], xmm11
00007b629add7f01  vmovaps [rsp+0xC0], xmm12
00007b629add7f0a  vmovaps [rsp+0xD0], xmm13
00007b629add7f13  vmovaps [rsp+0xE0], xmm14
00007b629add7f1c  sub rsp, 0x30
00007b629add7f20  movaps [rsp], xmm15
00007b629add7f25  movaps [rsp+0x10], xmm5
00007b629add7f2a  movaps [rsp+0x20], xmm3
00007b629add7f2f  lea rdi, [rsp]
00007b629add7f33  mov esi, 0x00
00007b629add7f38  mov rax, 0x583FED93F530
00007b629add7f42  call rax
00007b629add7f44  movaps xmm15, [rsp]
00007b629add7f49  add rsp, 0x30
00007b629add7f4d  vmovaps xmm0, [rsp]
00007b629add7f52  vmovaps xmm1, [rsp+0x10]
00007b629add7f58  vmovaps xmm2, [rsp+0x20]
00007b629add7f5e  vmovaps xmm3, [rsp+0x30]
00007b629add7f64  vmovaps xmm4, [rsp+0x40]
00007b629add7f6a  vmovaps xmm5, [rsp+0x50]
00007b629add7f70  vmovaps xmm6, [rsp+0x60]
00007b629add7f76  vmovaps xmm7, [rsp+0x70]
00007b629add7f7c  vmovaps xmm8, [rsp+0x80]
00007b629add7f85  vmovaps xmm9, [rsp+0x90]
00007b629add7f8e  vmovaps xmm10, [rsp+0xA0]
00007b629add7f97  vmovaps xmm11, [rsp+0xB0]
00007b629add7fa0  vmovaps xmm12, [rsp+0xC0]
00007b629add7fa9  vmovaps xmm13, [rsp+0xD0]
00007b629add7fb2  vmovaps xmm14, [rsp+0xE0]
00007b629add7fbb  add rsp, 0xF0
00007b629add7fc2  pop r11
00007b629add7fc4  pop r10
00007b629add7fc6  pop r9
00007b629add7fc8  pop r8
00007b629add7fca  pop rsi
00007b629add7fcb  pop rdi
00007b629add7fcc  pop rdx
00007b629add7fcd  pop rcx
00007b629add7fce  pop rax
00007b629add7fcf  add rsp, 0x08
00007b629add7fd3  jmp 0x00007B629ADD5EE6
00007b629add7fd8  sub rsp, 0x08
00007b629add7fdc  push rax
00007b629add7fdd  push rcx
00007b629add7fde  push rdx
00007b629add7fdf  push rdi
00007b629add7fe0  push rsi
00007b629add7fe1  push r8
00007b629add7fe3  push r9
00007b629add7fe5  push r10
00007b629add7fe7  push r11
00007b629add7fe9  sub rsp, 0xF0
00007b629add7ff0  vmovaps [rsp], xmm0
00007b629add7ff5  vmovaps [rsp+0x10], xmm2
00007b629add7ffb  vmovaps [rsp+0x20], xmm3
00007b629add8001  vmovaps [rsp+0x30], xmm4
00007b629add8007  vmovaps [rsp+0x40], xmm5
00007b629add800d  vmovaps [rsp+0x50], xmm6
00007b629add8013  vmovaps [rsp+0x60], xmm7
00007b629add8019  vmovaps [rsp+0x70], xmm8
00007b629add801f  vmovaps [rsp+0x80], xmm9
00007b629add8028  vmovaps [rsp+0x90], xmm10
00007b629add8031  vmovaps [rsp+0xA0], xmm11
00007b629add803a  vmovaps [rsp+0xB0], xmm12
00007b629add8043  vmovaps [rsp+0xC0], xmm13
00007b629add804c  vmovaps [rsp+0xD0], xmm14
00007b629add8055  vmovaps [rsp+0xE0], xmm15
00007b629add805e  sub rsp, 0x30
00007b629add8062  movaps [rsp], xmm1
00007b629add8066  movaps [rsp+0x10], xmm5
00007b629add806b  movaps [rsp+0x20], xmm4
00007b629add8070  lea rdi, [rsp]
00007b629add8074  mov esi, 0x00
00007b629add8079  mov rax, 0x583FED93F530
00007b629add8083  call rax
00007b629add8085  movaps xmm1, [rsp]
00007b629add8089  add rsp, 0x30
00007b629add808d  vmovaps xmm0, [rsp]
00007b629add8092  vmovaps xmm2, [rsp+0x10]
00007b629add8098  vmovaps xmm3, [rsp+0x20]
00007b629add809e  vmovaps xmm4, [rsp+0x30]
00007b629add80a4  vmovaps xmm5, [rsp+0x40]
00007b629add80aa  vmovaps xmm6, [rsp+0x50]
00007b629add80b0  vmovaps xmm7, [rsp+0x60]
00007b629add80b6  vmovaps xmm8, [rsp+0x70]
00007b629add80bc  vmovaps xmm9, [rsp+0x80]
00007b629add80c5  vmovaps xmm10, [rsp+0x90]
00007b629add80ce  vmovaps xmm11, [rsp+0xA0]
00007b629add80d7  vmovaps xmm12, [rsp+0xB0]
00007b629add80e0  vmovaps xmm13, [rsp+0xC0]
00007b629add80e9  vmovaps xmm14, [rsp+0xD0]
00007b629add80f2  vmovaps xmm15, [rsp+0xE0]
00007b629add80fb  add rsp, 0xF0
00007b629add8102  pop r11
00007b629add8104  pop r10
00007b629add8106  pop r9
00007b629add8108  pop r8
00007b629add810a  pop rsi
00007b629add810b  pop rdi
00007b629add810c  pop rdx
00007b629add810d  pop rcx
00007b629add810e  pop rax
00007b629add810f  add rsp, 0x08
00007b629add8113  jmp 0x00007B629ADD5F06
00007b629add8118  sub rsp, 0x08
00007b629add811c  push rax
00007b629add811d  push rcx
00007b629add811e  push rdx
00007b629add811f  push rdi
00007b629add8120  push rsi
00007b629add8121  push r8
00007b629add8123  push r9
00007b629add8125  push r10
00007b629add8127  push r11
00007b629add8129  sub rsp, 0xF0
00007b629add8130  vmovaps [rsp], xmm0
00007b629add8135  vmovaps [rsp+0x10], xmm1
00007b629add813b  vmovaps [rsp+0x20], xmm2
00007b629add8141  vmovaps [rsp+0x30], xmm3
00007b629add8147  vmovaps [rsp+0x40], xmm5
00007b629add814d  vmovaps [rsp+0x50], xmm6
00007b629add8153  vmovaps [rsp+0x60], xmm7
00007b629add8159  vmovaps [rsp+0x70], xmm8
00007b629add815f  vmovaps [rsp+0x80], xmm9
00007b629add8168  vmovaps [rsp+0x90], xmm10
00007b629add8171  vmovaps [rsp+0xA0], xmm11
00007b629add817a  vmovaps [rsp+0xB0], xmm12
00007b629add8183  vmovaps [rsp+0xC0], xmm13
00007b629add818c  vmovaps [rsp+0xD0], xmm14
00007b629add8195  vmovaps [rsp+0xE0], xmm15
00007b629add819e  sub rsp, 0x30
00007b629add81a2  movaps [rsp], xmm4
00007b629add81a6  movaps [rsp+0x10], xmm3
00007b629add81ab  movaps [rsp+0x20], xmm5
00007b629add81b0  lea rdi, [rsp]
00007b629add81b4  mov esi, 0x00
00007b629add81b9  mov rax, 0x583FED93F530
00007b629add81c3  call rax
00007b629add81c5  movaps xmm4, [rsp]
00007b629add81c9  add rsp, 0x30
00007b629add81cd  vmovaps xmm0, [rsp]
00007b629add81d2  vmovaps xmm1, [rsp+0x10]
00007b629add81d8  vmovaps xmm2, [rsp+0x20]
00007b629add81de  vmovaps xmm3, [rsp+0x30]
00007b629add81e4  vmovaps xmm5, [rsp+0x40]
00007b629add81ea  vmovaps xmm6, [rsp+0x50]
00007b629add81f0  vmovaps xmm7, [rsp+0x60]
00007b629add81f6  vmovaps xmm8, [rsp+0x70]
00007b629add81fc  vmovaps xmm9, [rsp+0x80]
00007b629add8205  vmovaps xmm10, [rsp+0x90]
00007b629add820e  vmovaps xmm11, [rsp+0xA0]
00007b629add8217  vmovaps xmm12, [rsp+0xB0]
00007b629add8220  vmovaps xmm13, [rsp+0xC0]
00007b629add8229  vmovaps xmm14, [rsp+0xD0]
00007b629add8232  vmovaps xmm15, [rsp+0xE0]
00007b629add823b  add rsp, 0xF0
00007b629add8242  pop r11
00007b629add8244  pop r10
00007b629add8246  pop r9
00007b629add8248  pop r8
00007b629add824a  pop rsi
00007b629add824b  pop rdi
00007b629add824c  pop rdx
00007b629add824d  pop rcx
00007b629add824e  pop rax
00007b629add824f  add rsp, 0x08
00007b629add8253  jmp 0x00007B629ADD5F54
00007b629add8258  call 0x00007B629ACD64F0
00007b629add825d  jmp 0x00007B629ADD5F61
00007b629add8262  sub rsp, 0x08
00007b629add8266  push rax
00007b629add8267  push rcx
00007b629add8268  push rdx
00007b629add8269  push rdi
00007b629add826a  push rsi
00007b629add826b  push r8
00007b629add826d  push r9
00007b629add826f  push r10
00007b629add8271  push r11
00007b629add8273  sub rsp, 0xF0
00007b629add827a  vmovaps [rsp], xmm0
00007b629add827f  vmovaps [rsp+0x10], xmm1
00007b629add8285  vmovaps [rsp+0x20], xmm2
00007b629add828b  vmovaps [rsp+0x30], xmm3
00007b629add8291  vmovaps [rsp+0x40], xmm4
00007b629add8297  vmovaps [rsp+0x50], xmm6
00007b629add829d  vmovaps [rsp+0x60], xmm7
00007b629add82a3  vmovaps [rsp+0x70], xmm8
00007b629add82a9  vmovaps [rsp+0x80], xmm9
00007b629add82b2  vmovaps [rsp+0x90], xmm10
00007b629add82bb  vmovaps [rsp+0xA0], xmm11
00007b629add82c4  vmovaps [rsp+0xB0], xmm12
00007b629add82cd  vmovaps [rsp+0xC0], xmm13
00007b629add82d6  vmovaps [rsp+0xD0], xmm14
00007b629add82df  vmovaps [rsp+0xE0], xmm15
00007b629add82e8  sub rsp, 0x30
00007b629add82ec  movaps [rsp], xmm5
00007b629add82f0  movaps [rsp+0x10], xmm6
00007b629add82f5  movaps [rsp+0x20], xmm3
00007b629add82fa  lea rdi, [rsp]
00007b629add82fe  mov esi, 0x00
00007b629add8303  mov rax, 0x583FED93F530
00007b629add830d  call rax
00007b629add830f  movaps xmm5, [rsp]
00007b629add8313  add rsp, 0x30
00007b629add8317  vmovaps xmm0, [rsp]
00007b629add831c  vmovaps xmm1, [rsp+0x10]
00007b629add8322  vmovaps xmm2, [rsp+0x20]
00007b629add8328  vmovaps xmm3, [rsp+0x30]
00007b629add832e  vmovaps xmm4, [rsp+0x40]
00007b629add8334  vmovaps xmm6, [rsp+0x50]
00007b629add833a  vmovaps xmm7, [rsp+0x60]
00007b629add8340  vmovaps xmm8, [rsp+0x70]
00007b629add8346  vmovaps xmm9, [rsp+0x80]
00007b629add834f  vmovaps xmm10, [rsp+0x90]
00007b629add8358  vmovaps xmm11, [rsp+0xA0]
00007b629add8361  vmovaps xmm12, [rsp+0xB0]
00007b629add836a  vmovaps xmm13, [rsp+0xC0]
00007b629add8373  vmovaps xmm14, [rsp+0xD0]
00007b629add837c  vmovaps xmm15, [rsp+0xE0]
00007b629add8385  add rsp, 0xF0
00007b629add838c  pop r11
00007b629add838e  pop r10
00007b629add8390  pop r9
00007b629add8392  pop r8
00007b629add8394  pop rsi
00007b629add8395  pop rdi
00007b629add8396  pop rdx
00007b629add8397  pop rcx
00007b629add8398  pop rax
00007b629add8399  add rsp, 0x08
00007b629add839d  jmp 0x00007B629ADD5F87
00007b629add83a2  sub rsp, 0x08
00007b629add83a6  push rax
00007b629add83a7  push rcx
00007b629add83a8  push rdx
00007b629add83a9  push rdi
00007b629add83aa  push rsi
00007b629add83ab  push r8
00007b629add83ad  push r9
00007b629add83af  push r10
00007b629add83b1  push r11
00007b629add83b3  sub rsp, 0xF0
00007b629add83ba  vmovaps [rsp], xmm0
00007b629add83bf  vmovaps [rsp+0x10], xmm1
00007b629add83c5  vmovaps [rsp+0x20], xmm2
00007b629add83cb  vmovaps [rsp+0x30], xmm3
00007b629add83d1  vmovaps [rsp+0x40], xmm4
00007b629add83d7  vmovaps [rsp+0x50], xmm5
00007b629add83dd  vmovaps [rsp+0x60], xmm7
00007b629add83e3  vmovaps [rsp+0x70], xmm8
00007b629add83e9  vmovaps [rsp+0x80], xmm9
00007b629add83f2  vmovaps [rsp+0x90], xmm10
00007b629add83fb  vmovaps [rsp+0xA0], xmm11
00007b629add8404  vmovaps [rsp+0xB0], xmm12
00007b629add840d  vmovaps [rsp+0xC0], xmm13
00007b629add8416  vmovaps [rsp+0xD0], xmm14
00007b629add841f  vmovaps [rsp+0xE0], xmm15
00007b629add8428  sub rsp, 0x30
00007b629add842c  movaps [rsp], xmm6
00007b629add8430  movaps [rsp+0x10], xmm9
00007b629add8436  movaps [rsp+0x20], xmm1
00007b629add843b  lea rdi, [rsp]
00007b629add843f  mov esi, 0x00
00007b629add8444  mov rax, 0x583FED93F530
00007b629add844e  call rax
00007b629add8450  movaps xmm6, [rsp]
00007b629add8454  add rsp, 0x30
00007b629add8458  vmovaps xmm0, [rsp]
00007b629add845d  vmovaps xmm1, [rsp+0x10]
00007b629add8463  vmovaps xmm2, [rsp+0x20]
00007b629add8469  vmovaps xmm3, [rsp+0x30]
00007b629add846f  vmovaps xmm4, [rsp+0x40]
00007b629add8475  vmovaps xmm5, [rsp+0x50]
00007b629add847b  vmovaps xmm7, [rsp+0x60]
00007b629add8481  vmovaps xmm8, [rsp+0x70]
00007b629add8487  vmovaps xmm9, [rsp+0x80]
00007b629add8490  vmovaps xmm10, [rsp+0x90]
00007b629add8499  vmovaps xmm11, [rsp+0xA0]
00007b629add84a2  vmovaps xmm12, [rsp+0xB0]
00007b629add84ab  vmovaps xmm13, [rsp+0xC0]
00007b629add84b4  vmovaps xmm14, [rsp+0xD0]
00007b629add84bd  vmovaps xmm15, [rsp+0xE0]
00007b629add84c6  add rsp, 0xF0
00007b629add84cd  pop r11
00007b629add84cf  pop r10
00007b629add84d1  pop r9
00007b629add84d3  pop r8
00007b629add84d5  pop rsi
00007b629add84d6  pop rdi
00007b629add84d7  pop rdx
00007b629add84d8  pop rcx
00007b629add84d9  pop rax
00007b629add84da  add rsp, 0x08
00007b629add84de  jmp 0x00007B629ADD5FAB
00007b629add84e3  sub rsp, 0x08
00007b629add84e7  push rax
00007b629add84e8  push rcx
00007b629add84e9  push rdx
00007b629add84ea  push rdi
00007b629add84eb  push rsi
00007b629add84ec  push r8
00007b629add84ee  push r9
00007b629add84f0  push r10
00007b629add84f2  push r11
00007b629add84f4  sub rsp, 0xF0
00007b629add84fb  vmovaps [rsp], xmm0
00007b629add8500  vmovaps [rsp+0x10], xmm1
00007b629add8506  vmovaps [rsp+0x20], xmm2
00007b629add850c  vmovaps [rsp+0x30], xmm3
00007b629add8512  vmovaps [rsp+0x40], xmm4
00007b629add8518  vmovaps [rsp+0x50], xmm5
00007b629add851e  vmovaps [rsp+0x60], xmm6
00007b629add8524  vmovaps [rsp+0x70], xmm7
00007b629add852a  vmovaps [rsp+0x80], xmm8
00007b629add8533  vmovaps [rsp+0x90], xmm10
00007b629add853c  vmovaps [rsp+0xA0], xmm11
00007b629add8545  vmovaps [rsp+0xB0], xmm12
00007b629add854e  vmovaps [rsp+0xC0], xmm13
00007b629add8557  vmovaps [rsp+0xD0], xmm14
00007b629add8560  vmovaps [rsp+0xE0], xmm15
00007b629add8569  sub rsp, 0x30
00007b629add856d  movaps [rsp], xmm9
00007b629add8572  movaps [rsp+0x10], xmm3
00007b629add8577  movaps [rsp+0x20], xmm1
00007b629add857c  lea rdi, [rsp]
00007b629add8580  mov esi, 0x00
00007b629add8585  mov rax, 0x583FED93F530
00007b629add858f  call rax
00007b629add8591  movaps xmm9, [rsp]
00007b629add8596  add rsp, 0x30
00007b629add859a  vmovaps xmm0, [rsp]
00007b629add859f  vmovaps xmm1, [rsp+0x10]
00007b629add85a5  vmovaps xmm2, [rsp+0x20]
00007b629add85ab  vmovaps xmm3, [rsp+0x30]
00007b629add85b1  vmovaps xmm4, [rsp+0x40]
00007b629add85b7  vmovaps xmm5, [rsp+0x50]
00007b629add85bd  vmovaps xmm6, [rsp+0x60]
00007b629add85c3  vmovaps xmm7, [rsp+0x70]
00007b629add85c9  vmovaps xmm8, [rsp+0x80]
00007b629add85d2  vmovaps xmm10, [rsp+0x90]
00007b629add85db  vmovaps xmm11, [rsp+0xA0]
00007b629add85e4  vmovaps xmm12, [rsp+0xB0]
00007b629add85ed  vmovaps xmm13, [rsp+0xC0]
00007b629add85f6  vmovaps xmm14, [rsp+0xD0]
00007b629add85ff  vmovaps xmm15, [rsp+0xE0]
00007b629add8608  add rsp, 0xF0
00007b629add860f  pop r11
00007b629add8611  pop r10
00007b629add8613  pop r9
00007b629add8615  pop r8
00007b629add8617  pop rsi
00007b629add8618  pop rdi
00007b629add8619  pop rdx
00007b629add861a  pop rcx
00007b629add861b  pop rax
00007b629add861c  add rsp, 0x08
00007b629add8620  jmp 0x00007B629ADD5FF7
00007b629add8625  call 0x00007B629ACD64F0
00007b629add862a  jmp 0x00007B629ADD6004
00007b629add862f  sub rsp, 0x08
00007b629add8633  push rax
00007b629add8634  push rcx
00007b629add8635  push rdx
00007b629add8636  push rdi
00007b629add8637  push rsi
00007b629add8638  push r8
00007b629add863a  push r9
00007b629add863c  push r10
00007b629add863e  push r11
00007b629add8640  sub rsp, 0xF0
00007b629add8647  vmovaps [rsp], xmm0
00007b629add864c  vmovaps [rsp+0x10], xmm1
00007b629add8652  vmovaps [rsp+0x20], xmm2
00007b629add8658  vmovaps [rsp+0x30], xmm3
00007b629add865e  vmovaps [rsp+0x40], xmm4
00007b629add8664  vmovaps [rsp+0x50], xmm5
00007b629add866a  vmovaps [rsp+0x60], xmm6
00007b629add8670  vmovaps [rsp+0x70], xmm7
00007b629add8676  vmovaps [rsp+0x80], xmm8
00007b629add867f  vmovaps [rsp+0x90], xmm9
00007b629add8688  vmovaps [rsp+0xA0], xmm10
00007b629add8691  vmovaps [rsp+0xB0], xmm11
00007b629add869a  vmovaps [rsp+0xC0], xmm12
00007b629add86a3  vmovaps [rsp+0xD0], xmm13
00007b629add86ac  vmovaps [rsp+0xE0], xmm14
00007b629add86b5  sub rsp, 0x30
00007b629add86b9  movaps [rsp], xmm15
00007b629add86be  movaps [rsp+0x10], xmm3
00007b629add86c3  movaps [rsp+0x20], xmm7
00007b629add86c8  lea rdi, [rsp]
00007b629add86cc  mov esi, 0x00
00007b629add86d1  mov rax, 0x583FED93F530
00007b629add86db  call rax
00007b629add86dd  movaps xmm15, [rsp]
00007b629add86e2  add rsp, 0x30
00007b629add86e6  vmovaps xmm0, [rsp]
00007b629add86eb  vmovaps xmm1, [rsp+0x10]
00007b629add86f1  vmovaps xmm2, [rsp+0x20]
00007b629add86f7  vmovaps xmm3, [rsp+0x30]
00007b629add86fd  vmovaps xmm4, [rsp+0x40]
00007b629add8703  vmovaps xmm5, [rsp+0x50]
00007b629add8709  vmovaps xmm6, [rsp+0x60]
00007b629add870f  vmovaps xmm7, [rsp+0x70]
00007b629add8715  vmovaps xmm8, [rsp+0x80]
00007b629add871e  vmovaps xmm9, [rsp+0x90]
00007b629add8727  vmovaps xmm10, [rsp+0xA0]
00007b629add8730  vmovaps xmm11, [rsp+0xB0]
00007b629add8739  vmovaps xmm12, [rsp+0xC0]
00007b629add8742  vmovaps xmm13, [rsp+0xD0]
00007b629add874b  vmovaps xmm14, [rsp+0xE0]
00007b629add8754  add rsp, 0xF0
00007b629add875b  pop r11
00007b629add875d  pop r10
00007b629add875f  pop r9
00007b629add8761  pop r8
00007b629add8763  pop rsi
00007b629add8764  pop rdi
00007b629add8765  pop rdx
00007b629add8766  pop rcx
00007b629add8767  pop rax
00007b629add8768  add rsp, 0x08
00007b629add876c  jmp 0x00007B629ADD6030
00007b629add8771  sub rsp, 0x08
00007b629add8775  push rax
00007b629add8776  push rcx
00007b629add8777  push rdx
00007b629add8778  push rdi
00007b629add8779  push rsi
00007b629add877a  push r8
00007b629add877c  push r9
00007b629add877e  push r10
00007b629add8780  push r11
00007b629add8782  sub rsp, 0xF0
00007b629add8789  vmovaps [rsp], xmm0
00007b629add878e  vmovaps [rsp+0x10], xmm1
00007b629add8794  vmovaps [rsp+0x20], xmm2
00007b629add879a  vmovaps [rsp+0x30], xmm4
00007b629add87a0  vmovaps [rsp+0x40], xmm5
00007b629add87a6  vmovaps [rsp+0x50], xmm6
00007b629add87ac  vmovaps [rsp+0x60], xmm7
00007b629add87b2  vmovaps [rsp+0x70], xmm8
00007b629add87b8  vmovaps [rsp+0x80], xmm9
00007b629add87c1  vmovaps [rsp+0x90], xmm10
00007b629add87ca  vmovaps [rsp+0xA0], xmm11
00007b629add87d3  vmovaps [rsp+0xB0], xmm12
00007b629add87dc  vmovaps [rsp+0xC0], xmm13
00007b629add87e5  vmovaps [rsp+0xD0], xmm14
00007b629add87ee  vmovaps [rsp+0xE0], xmm15
00007b629add87f7  sub rsp, 0x30
00007b629add87fb  movaps [rsp], xmm3
00007b629add87ff  movaps [rsp+0x10], xmm1
00007b629add8804  movaps [rsp+0x20], xmm15
00007b629add880a  lea rdi, [rsp]
00007b629add880e  mov esi, 0x00
00007b629add8813  mov rax, 0x583FED93F530
00007b629add881d  call rax
00007b629add881f  movaps xmm3, [rsp]
00007b629add8823  add rsp, 0x30
00007b629add8827  vmovaps xmm0, [rsp]
00007b629add882c  vmovaps xmm1, [rsp+0x10]
00007b629add8832  vmovaps xmm2, [rsp+0x20]
00007b629add8838  vmovaps xmm4, [rsp+0x30]
00007b629add883e  vmovaps xmm5, [rsp+0x40]
00007b629add8844  vmovaps xmm6, [rsp+0x50]
00007b629add884a  vmovaps xmm7, [rsp+0x60]
00007b629add8850  vmovaps xmm8, [rsp+0x70]
00007b629add8856  vmovaps xmm9, [rsp+0x80]
00007b629add885f  vmovaps xmm10, [rsp+0x90]
00007b629add8868  vmovaps xmm11, [rsp+0xA0]
00007b629add8871  vmovaps xmm12, [rsp+0xB0]
00007b629add887a  vmovaps xmm13, [rsp+0xC0]
00007b629add8883  vmovaps xmm14, [rsp+0xD0]
00007b629add888c  vmovaps xmm15, [rsp+0xE0]
00007b629add8895  add rsp, 0xF0
00007b629add889c  pop r11
00007b629add889e  pop r10
00007b629add88a0  pop r9
00007b629add88a2  pop r8
00007b629add88a4  pop rsi
00007b629add88a5  pop rdi
00007b629add88a6  pop rdx
00007b629add88a7  pop rcx
00007b629add88a8  pop rax
00007b629add88a9  add rsp, 0x08
00007b629add88ad  jmp 0x00007B629ADD60BF
00007b629add88b2  call 0x00007B629ACD64F0
00007b629add88b7  jmp 0x00007B629ADD60C9
00007b629add88bc  sub rsp, 0x08
00007b629add88c0  push rax
00007b629add88c1  push rcx
00007b629add88c2  push rdx
00007b629add88c3  push rdi
00007b629add88c4  push rsi
00007b629add88c5  push r8
00007b629add88c7  push r9
00007b629add88c9  push r10
00007b629add88cb  push r11
00007b629add88cd  sub rsp, 0xF0
00007b629add88d4  vmovaps [rsp], xmm0
00007b629add88d9  vmovaps [rsp+0x10], xmm1
00007b629add88df  vmovaps [rsp+0x20], xmm2
00007b629add88e5  vmovaps [rsp+0x30], xmm3
00007b629add88eb  vmovaps [rsp+0x40], xmm4
00007b629add88f1  vmovaps [rsp+0x50], xmm5
00007b629add88f7  vmovaps [rsp+0x60], xmm6
00007b629add88fd  vmovaps [rsp+0x70], xmm7
00007b629add8903  vmovaps [rsp+0x80], xmm8
00007b629add890c  vmovaps [rsp+0x90], xmm9
00007b629add8915  vmovaps [rsp+0xA0], xmm10
00007b629add891e  vmovaps [rsp+0xB0], xmm11
00007b629add8927  vmovaps [rsp+0xC0], xmm12
00007b629add8930  vmovaps [rsp+0xD0], xmm13
00007b629add8939  vmovaps [rsp+0xE0], xmm14
00007b629add8942  sub rsp, 0x30
00007b629add8946  movaps [rsp], xmm15
00007b629add894b  movaps [rsp+0x10], xmm14
00007b629add8951  movaps [rsp+0x20], xmm4
00007b629add8956  lea rdi, [rsp]
00007b629add895a  mov esi, 0x00
00007b629add895f  mov rax, 0x583FED93F530
00007b629add8969  call rax
00007b629add896b  movaps xmm15, [rsp]
00007b629add8970  add rsp, 0x30
00007b629add8974  vmovaps xmm0, [rsp]
00007b629add8979  vmovaps xmm1, [rsp+0x10]
00007b629add897f  vmovaps xmm2, [rsp+0x20]
00007b629add8985  vmovaps xmm3, [rsp+0x30]
00007b629add898b  vmovaps xmm4, [rsp+0x40]
00007b629add8991  vmovaps xmm5, [rsp+0x50]
00007b629add8997  vmovaps xmm6, [rsp+0x60]
00007b629add899d  vmovaps xmm7, [rsp+0x70]
00007b629add89a3  vmovaps xmm8, [rsp+0x80]
00007b629add89ac  vmovaps xmm9, [rsp+0x90]
00007b629add89b5  vmovaps xmm10, [rsp+0xA0]
00007b629add89be  vmovaps xmm11, [rsp+0xB0]
00007b629add89c7  vmovaps xmm12, [rsp+0xC0]
00007b629add89d0  vmovaps xmm13, [rsp+0xD0]
00007b629add89d9  vmovaps xmm14, [rsp+0xE0]
00007b629add89e2  add rsp, 0xF0
00007b629add89e9  pop r11
00007b629add89eb  pop r10
00007b629add89ed  pop r9
00007b629add89ef  pop r8
00007b629add89f1  pop rsi
00007b629add89f2  pop rdi
00007b629add89f3  pop rdx
00007b629add89f4  pop rcx
00007b629add89f5  pop rax
00007b629add89f6  add rsp, 0x08
00007b629add89fa  jmp 0x00007B629ADD60F7
00007b629add89ff  sub rsp, 0x08
00007b629add8a03  push rax
00007b629add8a04  push rcx
00007b629add8a05  push rdx
00007b629add8a06  push rdi
00007b629add8a07  push rsi
00007b629add8a08  push r8
00007b629add8a0a  push r9
00007b629add8a0c  push r10
00007b629add8a0e  push r11
00007b629add8a10  sub rsp, 0xF0
00007b629add8a17  vmovaps [rsp], xmm0
00007b629add8a1c  vmovaps [rsp+0x10], xmm1
00007b629add8a22  vmovaps [rsp+0x20], xmm2
00007b629add8a28  vmovaps [rsp+0x30], xmm3
00007b629add8a2e  vmovaps [rsp+0x40], xmm4
00007b629add8a34  vmovaps [rsp+0x50], xmm5
00007b629add8a3a  vmovaps [rsp+0x60], xmm6
00007b629add8a40  vmovaps [rsp+0x70], xmm7
00007b629add8a46  vmovaps [rsp+0x80], xmm8
00007b629add8a4f  vmovaps [rsp+0x90], xmm9
00007b629add8a58  vmovaps [rsp+0xA0], xmm10
00007b629add8a61  vmovaps [rsp+0xB0], xmm11
00007b629add8a6a  vmovaps [rsp+0xC0], xmm12
00007b629add8a73  vmovaps [rsp+0xD0], xmm13
00007b629add8a7c  vmovaps [rsp+0xE0], xmm15
00007b629add8a85  sub rsp, 0x30
00007b629add8a89  movaps [rsp], xmm14
00007b629add8a8e  movaps [rsp+0x10], xmm2
00007b629add8a93  movaps [rsp+0x20], xmm1
00007b629add8a98  lea rdi, [rsp]
00007b629add8a9c  mov esi, 0x00
00007b629add8aa1  mov rax, 0x583FED93F530
00007b629add8aab  call rax
00007b629add8aad  movaps xmm14, [rsp]
00007b629add8ab2  add rsp, 0x30
00007b629add8ab6  vmovaps xmm0, [rsp]
00007b629add8abb  vmovaps xmm1, [rsp+0x10]
00007b629add8ac1  vmovaps xmm2, [rsp+0x20]
00007b629add8ac7  vmovaps xmm3, [rsp+0x30]
00007b629add8acd  vmovaps xmm4, [rsp+0x40]
00007b629add8ad3  vmovaps xmm5, [rsp+0x50]
00007b629add8ad9  vmovaps xmm6, [rsp+0x60]
00007b629add8adf  vmovaps xmm7, [rsp+0x70]
00007b629add8ae5  vmovaps xmm8, [rsp+0x80]
00007b629add8aee  vmovaps xmm9, [rsp+0x90]
00007b629add8af7  vmovaps xmm10, [rsp+0xA0]
00007b629add8b00  vmovaps xmm11, [rsp+0xB0]
00007b629add8b09  vmovaps xmm12, [rsp+0xC0]
00007b629add8b12  vmovaps xmm13, [rsp+0xD0]
00007b629add8b1b  vmovaps xmm15, [rsp+0xE0]
00007b629add8b24  add rsp, 0xF0
00007b629add8b2b  pop r11
00007b629add8b2d  pop r10
00007b629add8b2f  pop r9
00007b629add8b31  pop r8
00007b629add8b33  pop rsi
00007b629add8b34  pop rdi
00007b629add8b35  pop rdx
00007b629add8b36  pop rcx
00007b629add8b37  pop rax
00007b629add8b38  add rsp, 0x08
00007b629add8b3c  jmp 0x00007B629ADD611D
00007b629add8b41  sub rsp, 0x08
00007b629add8b45  push rax
00007b629add8b46  push rcx
00007b629add8b47  push rdx
00007b629add8b48  push rdi
00007b629add8b49  push rsi
00007b629add8b4a  push r8
00007b629add8b4c  push r9
00007b629add8b4e  push r10
00007b629add8b50  push r11
00007b629add8b52  sub rsp, 0xF0
00007b629add8b59  vmovaps [rsp], xmm0
00007b629add8b5e  vmovaps [rsp+0x10], xmm2
00007b629add8b64  vmovaps [rsp+0x20], xmm3
00007b629add8b6a  vmovaps [rsp+0x30], xmm4
00007b629add8b70  vmovaps [rsp+0x40], xmm5
00007b629add8b76  vmovaps [rsp+0x50], xmm6
00007b629add8b7c  vmovaps [rsp+0x60], xmm7
00007b629add8b82  vmovaps [rsp+0x70], xmm8
00007b629add8b88  vmovaps [rsp+0x80], xmm9
00007b629add8b91  vmovaps [rsp+0x90], xmm10
00007b629add8b9a  vmovaps [rsp+0xA0], xmm11
00007b629add8ba3  vmovaps [rsp+0xB0], xmm12
00007b629add8bac  vmovaps [rsp+0xC0], xmm13
00007b629add8bb5  vmovaps [rsp+0xD0], xmm14
00007b629add8bbe  vmovaps [rsp+0xE0], xmm15
00007b629add8bc7  sub rsp, 0x30
00007b629add8bcb  movaps [rsp], xmm1
00007b629add8bcf  movaps [rsp+0x10], xmm4
00007b629add8bd4  movaps [rsp+0x20], xmm9
00007b629add8bda  lea rdi, [rsp]
00007b629add8bde  mov esi, 0x00
00007b629add8be3  mov rax, 0x583FED93F530
00007b629add8bed  call rax
00007b629add8bef  movaps xmm1, [rsp]
00007b629add8bf3  add rsp, 0x30
00007b629add8bf7  vmovaps xmm0, [rsp]
00007b629add8bfc  vmovaps xmm2, [rsp+0x10]
00007b629add8c02  vmovaps xmm3, [rsp+0x20]
00007b629add8c08  vmovaps xmm4, [rsp+0x30]
00007b629add8c0e  vmovaps xmm5, [rsp+0x40]
00007b629add8c14  vmovaps xmm6, [rsp+0x50]
00007b629add8c1a  vmovaps xmm7, [rsp+0x60]
00007b629add8c20  vmovaps xmm8, [rsp+0x70]
00007b629add8c26  vmovaps xmm9, [rsp+0x80]
00007b629add8c2f  vmovaps xmm10, [rsp+0x90]
00007b629add8c38  vmovaps xmm11, [rsp+0xA0]
00007b629add8c41  vmovaps xmm12, [rsp+0xB0]
00007b629add8c4a  vmovaps xmm13, [rsp+0xC0]
00007b629add8c53  vmovaps xmm14, [rsp+0xD0]
00007b629add8c5c  vmovaps xmm15, [rsp+0xE0]
00007b629add8c65  add rsp, 0xF0
00007b629add8c6c  pop r11
00007b629add8c6e  pop r10
00007b629add8c70  pop r9
00007b629add8c72  pop r8
00007b629add8c74  pop rsi
00007b629add8c75  pop rdi
00007b629add8c76  pop rdx
00007b629add8c77  pop rcx
00007b629add8c78  pop rax
00007b629add8c79  add rsp, 0x08
00007b629add8c7d  jmp 0x00007B629ADD613B
00007b629add8c82  sub rsp, 0x08
00007b629add8c86  push rax
00007b629add8c87  push rcx
00007b629add8c88  push rdx
00007b629add8c89  push rdi
00007b629add8c8a  push rsi
00007b629add8c8b  push r8
00007b629add8c8d  push r9
00007b629add8c8f  push r10
00007b629add8c91  push r11
00007b629add8c93  sub rsp, 0xF0
00007b629add8c9a  vmovaps [rsp], xmm0
00007b629add8c9f  vmovaps [rsp+0x10], xmm1
00007b629add8ca5  vmovaps [rsp+0x20], xmm2
00007b629add8cab  vmovaps [rsp+0x30], xmm3
00007b629add8cb1  vmovaps [rsp+0x40], xmm5
00007b629add8cb7  vmovaps [rsp+0x50], xmm6
00007b629add8cbd  vmovaps [rsp+0x60], xmm7
00007b629add8cc3  vmovaps [rsp+0x70], xmm8
00007b629add8cc9  vmovaps [rsp+0x80], xmm9
00007b629add8cd2  vmovaps [rsp+0x90], xmm10
00007b629add8cdb  vmovaps [rsp+0xA0], xmm11
00007b629add8ce4  vmovaps [rsp+0xB0], xmm12
00007b629add8ced  vmovaps [rsp+0xC0], xmm13
00007b629add8cf6  vmovaps [rsp+0xD0], xmm14
00007b629add8cff  vmovaps [rsp+0xE0], xmm15
00007b629add8d08  sub rsp, 0x30
00007b629add8d0c  movaps [rsp], xmm4
00007b629add8d10  movaps [rsp+0x10], xmm2
00007b629add8d15  movaps [rsp+0x20], xmm9
00007b629add8d1b  lea rdi, [rsp]
00007b629add8d1f  mov esi, 0x00
00007b629add8d24  mov rax, 0x583FED93F530
00007b629add8d2e  call rax
00007b629add8d30  movaps xmm4, [rsp]
00007b629add8d34  add rsp, 0x30
00007b629add8d38  vmovaps xmm0, [rsp]
00007b629add8d3d  vmovaps xmm1, [rsp+0x10]
00007b629add8d43  vmovaps xmm2, [rsp+0x20]
00007b629add8d49  vmovaps xmm3, [rsp+0x30]
00007b629add8d4f  vmovaps xmm5, [rsp+0x40]
00007b629add8d55  vmovaps xmm6, [rsp+0x50]
00007b629add8d5b  vmovaps xmm7, [rsp+0x60]
00007b629add8d61  vmovaps xmm8, [rsp+0x70]
00007b629add8d67  vmovaps xmm9, [rsp+0x80]
00007b629add8d70  vmovaps xmm10, [rsp+0x90]
00007b629add8d79  vmovaps xmm11, [rsp+0xA0]
00007b629add8d82  vmovaps xmm12, [rsp+0xB0]
00007b629add8d8b  vmovaps xmm13, [rsp+0xC0]
00007b629add8d94  vmovaps xmm14, [rsp+0xD0]
00007b629add8d9d  vmovaps xmm15, [rsp+0xE0]
00007b629add8da6  add rsp, 0xF0
00007b629add8dad  pop r11
00007b629add8daf  pop r10
00007b629add8db1  pop r9
00007b629add8db3  pop r8
00007b629add8db5  pop rsi
00007b629add8db6  pop rdi
00007b629add8db7  pop rdx
00007b629add8db8  pop rcx
00007b629add8db9  pop rax
00007b629add8dba  add rsp, 0x08
00007b629add8dbe  jmp 0x00007B629ADD616B
00007b629add8dc3  sub rsp, 0x08
00007b629add8dc7  push rax
00007b629add8dc8  push rcx
00007b629add8dc9  push rdx
00007b629add8dca  push rdi
00007b629add8dcb  push rsi
00007b629add8dcc  push r8
00007b629add8dce  push r9
00007b629add8dd0  push r10
00007b629add8dd2  push r11
00007b629add8dd4  sub rsp, 0xF0
00007b629add8ddb  vmovaps [rsp], xmm0
00007b629add8de0  vmovaps [rsp+0x10], xmm1
00007b629add8de6  vmovaps [rsp+0x20], xmm2
00007b629add8dec  vmovaps [rsp+0x30], xmm3
00007b629add8df2  vmovaps [rsp+0x40], xmm4
00007b629add8df8  vmovaps [rsp+0x50], xmm5
00007b629add8dfe  vmovaps [rsp+0x60], xmm6
00007b629add8e04  vmovaps [rsp+0x70], xmm7
00007b629add8e0a  vmovaps [rsp+0x80], xmm8
00007b629add8e13  vmovaps [rsp+0x90], xmm10
00007b629add8e1c  vmovaps [rsp+0xA0], xmm11
00007b629add8e25  vmovaps [rsp+0xB0], xmm12
00007b629add8e2e  vmovaps [rsp+0xC0], xmm13
00007b629add8e37  vmovaps [rsp+0xD0], xmm14
00007b629add8e40  vmovaps [rsp+0xE0], xmm15
00007b629add8e49  sub rsp, 0x30
00007b629add8e4d  movaps [rsp], xmm9
00007b629add8e52  movaps [rsp+0x10], xmm2
00007b629add8e57  movaps [rsp+0x20], xmm1
00007b629add8e5c  lea rdi, [rsp]
00007b629add8e60  mov esi, 0x00
00007b629add8e65  mov rax, 0x583FED93F530
00007b629add8e6f  call rax
00007b629add8e71  movaps xmm9, [rsp]
00007b629add8e76  add rsp, 0x30
00007b629add8e7a  vmovaps xmm0, [rsp]
00007b629add8e7f  vmovaps xmm1, [rsp+0x10]
00007b629add8e85  vmovaps xmm2, [rsp+0x20]
00007b629add8e8b  vmovaps xmm3, [rsp+0x30]
00007b629add8e91  vmovaps xmm4, [rsp+0x40]
00007b629add8e97  vmovaps xmm5, [rsp+0x50]
00007b629add8e9d  vmovaps xmm6, [rsp+0x60]
00007b629add8ea3  vmovaps xmm7, [rsp+0x70]
00007b629add8ea9  vmovaps xmm8, [rsp+0x80]
00007b629add8eb2  vmovaps xmm10, [rsp+0x90]
00007b629add8ebb  vmovaps xmm11, [rsp+0xA0]
00007b629add8ec4  vmovaps xmm12, [rsp+0xB0]
00007b629add8ecd  vmovaps xmm13, [rsp+0xC0]
00007b629add8ed6  vmovaps xmm14, [rsp+0xD0]
00007b629add8edf  vmovaps xmm15, [rsp+0xE0]
00007b629add8ee8  add rsp, 0xF0
00007b629add8eef  pop r11
00007b629add8ef1  pop r10
00007b629add8ef3  pop r9
00007b629add8ef5  pop r8
00007b629add8ef7  pop rsi
00007b629add8ef8  pop rdi
00007b629add8ef9  pop rdx
00007b629add8efa  pop rcx
00007b629add8efb  pop rax
00007b629add8efc  add rsp, 0x08
00007b629add8f00  jmp 0x00007B629ADD61A1
00007b629add8f05  sub rsp, 0x08
00007b629add8f09  push rax
00007b629add8f0a  push rcx
00007b629add8f0b  push rdx
00007b629add8f0c  push rdi
00007b629add8f0d  push rsi
00007b629add8f0e  push r8
00007b629add8f10  push r9
00007b629add8f12  push r10
00007b629add8f14  push r11
00007b629add8f16  sub rsp, 0xF0
00007b629add8f1d  vmovaps [rsp], xmm0
00007b629add8f22  vmovaps [rsp+0x10], xmm2
00007b629add8f28  vmovaps [rsp+0x20], xmm3
00007b629add8f2e  vmovaps [rsp+0x30], xmm4
00007b629add8f34  vmovaps [rsp+0x40], xmm5
00007b629add8f3a  vmovaps [rsp+0x50], xmm6
00007b629add8f40  vmovaps [rsp+0x60], xmm7
00007b629add8f46  vmovaps [rsp+0x70], xmm8
00007b629add8f4c  vmovaps [rsp+0x80], xmm9
00007b629add8f55  vmovaps [rsp+0x90], xmm10
00007b629add8f5e  vmovaps [rsp+0xA0], xmm11
00007b629add8f67  vmovaps [rsp+0xB0], xmm12
00007b629add8f70  vmovaps [rsp+0xC0], xmm13
00007b629add8f79  vmovaps [rsp+0xD0], xmm14
00007b629add8f82  vmovaps [rsp+0xE0], xmm15
00007b629add8f8b  sub rsp, 0x30
00007b629add8f8f  movaps [rsp], xmm1
00007b629add8f93  movaps [rsp+0x10], xmm15
00007b629add8f99  movaps [rsp+0x20], xmm6
00007b629add8f9e  lea rdi, [rsp]
00007b629add8fa2  mov esi, 0x00
00007b629add8fa7  mov rax, 0x583FED93F530
00007b629add8fb1  call rax
00007b629add8fb3  movaps xmm1, [rsp]
00007b629add8fb7  add rsp, 0x30
00007b629add8fbb  vmovaps xmm0, [rsp]
00007b629add8fc0  vmovaps xmm2, [rsp+0x10]
00007b629add8fc6  vmovaps xmm3, [rsp+0x20]
00007b629add8fcc  vmovaps xmm4, [rsp+0x30]
00007b629add8fd2  vmovaps xmm5, [rsp+0x40]
00007b629add8fd8  vmovaps xmm6, [rsp+0x50]
00007b629add8fde  vmovaps xmm7, [rsp+0x60]
00007b629add8fe4  vmovaps xmm8, [rsp+0x70]
00007b629add8fea  vmovaps xmm9, [rsp+0x80]
00007b629add8ff3  vmovaps xmm10, [rsp+0x90]
00007b629add8ffc  vmovaps xmm11, [rsp+0xA0]
00007b629add9005  vmovaps xmm12, [rsp+0xB0]
00007b629add900e  vmovaps xmm13, [rsp+0xC0]
00007b629add9017  vmovaps xmm14, [rsp+0xD0]
00007b629add9020  vmovaps xmm15, [rsp+0xE0]
00007b629add9029  add rsp, 0xF0
00007b629add9030  pop r11
00007b629add9032  pop r10
00007b629add9034  pop r9
00007b629add9036  pop r8
00007b629add9038  pop rsi
00007b629add9039  pop rdi
00007b629add903a  pop rdx
00007b629add903b  pop rcx
00007b629add903c  pop rax
00007b629add903d  add rsp, 0x08
00007b629add9041  jmp 0x00007B629ADD61C2
00007b629add9046  sub rsp, 0x08
00007b629add904a  push rax
00007b629add904b  push rcx
00007b629add904c  push rdx
00007b629add904d  push rdi
00007b629add904e  push rsi
00007b629add904f  push r8
00007b629add9051  push r9
00007b629add9053  push r10
00007b629add9055  push r11
00007b629add9057  sub rsp, 0xF0
00007b629add905e  vmovaps [rsp], xmm0
00007b629add9063  vmovaps [rsp+0x10], xmm1
00007b629add9069  vmovaps [rsp+0x20], xmm2
00007b629add906f  vmovaps [rsp+0x30], xmm3
00007b629add9075  vmovaps [rsp+0x40], xmm4
00007b629add907b  vmovaps [rsp+0x50], xmm5
00007b629add9081  vmovaps [rsp+0x60], xmm6
00007b629add9087  vmovaps [rsp+0x70], xmm7
00007b629add908d  vmovaps [rsp+0x80], xmm8
00007b629add9096  vmovaps [rsp+0x90], xmm9
00007b629add909f  vmovaps [rsp+0xA0], xmm10
00007b629add90a8  vmovaps [rsp+0xB0], xmm11
00007b629add90b1  vmovaps [rsp+0xC0], xmm12
00007b629add90ba  vmovaps [rsp+0xD0], xmm13
00007b629add90c3  vmovaps [rsp+0xE0], xmm14
00007b629add90cc  sub rsp, 0x30
00007b629add90d0  movaps [rsp], xmm15
00007b629add90d5  movaps [rsp+0x10], xmm5
00007b629add90da  movaps [rsp+0x20], xmm3
00007b629add90df  lea rdi, [rsp]
00007b629add90e3  mov esi, 0x00
00007b629add90e8  mov rax, 0x583FED93F530
00007b629add90f2  call rax
00007b629add90f4  movaps xmm15, [rsp]
00007b629add90f9  add rsp, 0x30
00007b629add90fd  vmovaps xmm0, [rsp]
00007b629add9102  vmovaps xmm1, [rsp+0x10]
00007b629add9108  vmovaps xmm2, [rsp+0x20]
00007b629add910e  vmovaps xmm3, [rsp+0x30]
00007b629add9114  vmovaps xmm4, [rsp+0x40]
00007b629add911a  vmovaps xmm5, [rsp+0x50]
00007b629add9120  vmovaps xmm6, [rsp+0x60]
00007b629add9126  vmovaps xmm7, [rsp+0x70]
00007b629add912c  vmovaps xmm8, [rsp+0x80]
00007b629add9135  vmovaps xmm9, [rsp+0x90]
00007b629add913e  vmovaps xmm10, [rsp+0xA0]
00007b629add9147  vmovaps xmm11, [rsp+0xB0]
00007b629add9150  vmovaps xmm12, [rsp+0xC0]
00007b629add9159  vmovaps xmm13, [rsp+0xD0]
00007b629add9162  vmovaps xmm14, [rsp+0xE0]
00007b629add916b  add rsp, 0xF0
00007b629add9172  pop r11
00007b629add9174  pop r10
00007b629add9176  pop r9
00007b629add9178  pop r8
00007b629add917a  pop rsi
00007b629add917b  pop rdi
00007b629add917c  pop rdx
00007b629add917d  pop rcx
00007b629add917e  pop rax
00007b629add917f  add rsp, 0x08
00007b629add9183  jmp 0x00007B629ADD61DC
00007b629add9188  sub rsp, 0x08
00007b629add918c  push rax
00007b629add918d  push rcx
00007b629add918e  push rdx
00007b629add918f  push rdi
00007b629add9190  push rsi
00007b629add9191  push r8
00007b629add9193  push r9
00007b629add9195  push r10
00007b629add9197  push r11
00007b629add9199  sub rsp, 0xF0
00007b629add91a0  vmovaps [rsp], xmm0
00007b629add91a5  vmovaps [rsp+0x10], xmm1
00007b629add91ab  vmovaps [rsp+0x20], xmm2
00007b629add91b1  vmovaps [rsp+0x30], xmm3
00007b629add91b7  vmovaps [rsp+0x40], xmm4
00007b629add91bd  vmovaps [rsp+0x50], xmm6
00007b629add91c3  vmovaps [rsp+0x60], xmm7
00007b629add91c9  vmovaps [rsp+0x70], xmm8
00007b629add91cf  vmovaps [rsp+0x80], xmm9
00007b629add91d8  vmovaps [rsp+0x90], xmm10
00007b629add91e1  vmovaps [rsp+0xA0], xmm11
00007b629add91ea  vmovaps [rsp+0xB0], xmm12
00007b629add91f3  vmovaps [rsp+0xC0], xmm13
00007b629add91fc  vmovaps [rsp+0xD0], xmm14
00007b629add9205  vmovaps [rsp+0xE0], xmm15
00007b629add920e  sub rsp, 0x30
00007b629add9212  movaps [rsp], xmm5
00007b629add9216  movaps [rsp+0x10], xmm8
00007b629add921c  movaps [rsp+0x20], xmm6
00007b629add9221  lea rdi, [rsp]
00007b629add9225  mov esi, 0x00
00007b629add922a  mov rax, 0x583FED93F530
00007b629add9234  call rax
00007b629add9236  movaps xmm5, [rsp]
00007b629add923a  add rsp, 0x30
00007b629add923e  vmovaps xmm0, [rsp]
00007b629add9243  vmovaps xmm1, [rsp+0x10]
00007b629add9249  vmovaps xmm2, [rsp+0x20]
00007b629add924f  vmovaps xmm3, [rsp+0x30]
00007b629add9255  vmovaps xmm4, [rsp+0x40]
00007b629add925b  vmovaps xmm6, [rsp+0x50]
00007b629add9261  vmovaps xmm7, [rsp+0x60]
00007b629add9267  vmovaps xmm8, [rsp+0x70]
00007b629add926d  vmovaps xmm9, [rsp+0x80]
00007b629add9276  vmovaps xmm10, [rsp+0x90]
00007b629add927f  vmovaps xmm11, [rsp+0xA0]
00007b629add9288  vmovaps xmm12, [rsp+0xB0]
00007b629add9291  vmovaps xmm13, [rsp+0xC0]
00007b629add929a  vmovaps xmm14, [rsp+0xD0]
00007b629add92a3  vmovaps xmm15, [rsp+0xE0]
00007b629add92ac  add rsp, 0xF0
00007b629add92b3  pop r11
00007b629add92b5  pop r10
00007b629add92b7  pop r9
00007b629add92b9  pop r8
00007b629add92bb  pop rsi
00007b629add92bc  pop rdi
00007b629add92bd  pop rdx
00007b629add92be  pop rcx
00007b629add92bf  pop rax
00007b629add92c0  add rsp, 0x08
00007b629add92c4  jmp 0x00007B629ADD6200
00007b629add92c9  sub rsp, 0x08
00007b629add92cd  push rax
00007b629add92ce  push rcx
00007b629add92cf  push rdx
00007b629add92d0  push rdi
00007b629add92d1  push rsi
00007b629add92d2  push r8
00007b629add92d4  push r9
00007b629add92d6  push r10
00007b629add92d8  push r11
00007b629add92da  sub rsp, 0xF0
00007b629add92e1  vmovaps [rsp], xmm0
00007b629add92e6  vmovaps [rsp+0x10], xmm1
00007b629add92ec  vmovaps [rsp+0x20], xmm2
00007b629add92f2  vmovaps [rsp+0x30], xmm3
00007b629add92f8  vmovaps [rsp+0x40], xmm4
00007b629add92fe  vmovaps [rsp+0x50], xmm5
00007b629add9304  vmovaps [rsp+0x60], xmm7
00007b629add930a  vmovaps [rsp+0x70], xmm8
00007b629add9310  vmovaps [rsp+0x80], xmm9
00007b629add9319  vmovaps [rsp+0x90], xmm10
00007b629add9322  vmovaps [rsp+0xA0], xmm11
00007b629add932b  vmovaps [rsp+0xB0], xmm12
00007b629add9334  vmovaps [rsp+0xC0], xmm13
00007b629add933d  vmovaps [rsp+0xD0], xmm14
00007b629add9346  vmovaps [rsp+0xE0], xmm15
00007b629add934f  sub rsp, 0x30
00007b629add9353  movaps [rsp], xmm6
00007b629add9357  movaps [rsp+0x10], xmm10
00007b629add935d  movaps [rsp+0x20], xmm8
00007b629add9363  lea rdi, [rsp]
00007b629add9367  mov esi, 0x00
00007b629add936c  mov rax, 0x583FED93F530
00007b629add9376  call rax
00007b629add9378  movaps xmm6, [rsp]
00007b629add937c  add rsp, 0x30
00007b629add9380  vmovaps xmm0, [rsp]
00007b629add9385  vmovaps xmm1, [rsp+0x10]
00007b629add938b  vmovaps xmm2, [rsp+0x20]
00007b629add9391  vmovaps xmm3, [rsp+0x30]
00007b629add9397  vmovaps xmm4, [rsp+0x40]
00007b629add939d  vmovaps xmm5, [rsp+0x50]
00007b629add93a3  vmovaps xmm7, [rsp+0x60]
00007b629add93a9  vmovaps xmm8, [rsp+0x70]
00007b629add93af  vmovaps xmm9, [rsp+0x80]
00007b629add93b8  vmovaps xmm10, [rsp+0x90]
00007b629add93c1  vmovaps xmm11, [rsp+0xA0]
00007b629add93ca  vmovaps xmm12, [rsp+0xB0]
00007b629add93d3  vmovaps xmm13, [rsp+0xC0]
00007b629add93dc  vmovaps xmm14, [rsp+0xD0]
00007b629add93e5  vmovaps xmm15, [rsp+0xE0]
00007b629add93ee  add rsp, 0xF0
00007b629add93f5  pop r11
00007b629add93f7  pop r10
00007b629add93f9  pop r9
00007b629add93fb  pop r8
00007b629add93fd  pop rsi
00007b629add93fe  pop rdi
00007b629add93ff  pop rdx
00007b629add9400  pop rcx
00007b629add9401  pop rax
00007b629add9402  add rsp, 0x08
00007b629add9406  jmp 0x00007B629ADD6225
00007b629add940b  sub rsp, 0x08
00007b629add940f  push rax
00007b629add9410  push rcx
00007b629add9411  push rdx
00007b629add9412  push rdi
00007b629add9413  push rsi
00007b629add9414  push r8
00007b629add9416  push r9
00007b629add9418  push r10
00007b629add941a  push r11
00007b629add941c  sub rsp, 0xF0
00007b629add9423  vmovaps [rsp], xmm0
00007b629add9428  vmovaps [rsp+0x10], xmm1
00007b629add942e  vmovaps [rsp+0x20], xmm2
00007b629add9434  vmovaps [rsp+0x30], xmm3
00007b629add943a  vmovaps [rsp+0x40], xmm4
00007b629add9440  vmovaps [rsp+0x50], xmm5
00007b629add9446  vmovaps [rsp+0x60], xmm6
00007b629add944c  vmovaps [rsp+0x70], xmm7
00007b629add9452  vmovaps [rsp+0x80], xmm8
00007b629add945b  vmovaps [rsp+0x90], xmm9
00007b629add9464  vmovaps [rsp+0xA0], xmm11
00007b629add946d  vmovaps [rsp+0xB0], xmm12
00007b629add9476  vmovaps [rsp+0xC0], xmm13
00007b629add947f  vmovaps [rsp+0xD0], xmm14
00007b629add9488  vmovaps [rsp+0xE0], xmm15
00007b629add9491  sub rsp, 0x30
00007b629add9495  movaps [rsp], xmm10
00007b629add949a  movaps [rsp+0x10], xmm8
00007b629add94a0  movaps [rsp+0x20], xmm14
00007b629add94a6  lea rdi, [rsp]
00007b629add94aa  mov esi, 0x00
00007b629add94af  mov rax, 0x583FED93F530
00007b629add94b9  call rax
00007b629add94bb  movaps xmm10, [rsp]
00007b629add94c0  add rsp, 0x30
00007b629add94c4  vmovaps xmm0, [rsp]
00007b629add94c9  vmovaps xmm1, [rsp+0x10]
00007b629add94cf  vmovaps xmm2, [rsp+0x20]
00007b629add94d5  vmovaps xmm3, [rsp+0x30]
00007b629add94db  vmovaps xmm4, [rsp+0x40]
00007b629add94e1  vmovaps xmm5, [rsp+0x50]
00007b629add94e7  vmovaps xmm6, [rsp+0x60]
00007b629add94ed  vmovaps xmm7, [rsp+0x70]
00007b629add94f3  vmovaps xmm8, [rsp+0x80]
00007b629add94fc  vmovaps xmm9, [rsp+0x90]
00007b629add9505  vmovaps xmm11, [rsp+0xA0]
00007b629add950e  vmovaps xmm12, [rsp+0xB0]
00007b629add9517  vmovaps xmm13, [rsp+0xC0]
00007b629add9520  vmovaps xmm14, [rsp+0xD0]
00007b629add9529  vmovaps xmm15, [rsp+0xE0]
00007b629add9532  add rsp, 0xF0
00007b629add9539  pop r11
00007b629add953b  pop r10
00007b629add953d  pop r9
00007b629add953f  pop r8
00007b629add9541  pop rsi
00007b629add9542  pop rdi
00007b629add9543  pop rdx
00007b629add9544  pop rcx
00007b629add9545  pop rax
00007b629add9546  add rsp, 0x08
00007b629add954a  jmp 0x00007B629ADD6245
00007b629add954f  sub rsp, 0x08
00007b629add9553  push rax
00007b629add9554  push rcx
00007b629add9555  push rdx
00007b629add9556  push rdi
00007b629add9557  push rsi
00007b629add9558  push r8
00007b629add955a  push r9
00007b629add955c  push r10
00007b629add955e  push r11
00007b629add9560  sub rsp, 0xF0
00007b629add9567  vmovaps [rsp], xmm0
00007b629add956c  vmovaps [rsp+0x10], xmm1
00007b629add9572  vmovaps [rsp+0x20], xmm2
00007b629add9578  vmovaps [rsp+0x30], xmm3
00007b629add957e  vmovaps [rsp+0x40], xmm4
00007b629add9584  vmovaps [rsp+0x50], xmm5
00007b629add958a  vmovaps [rsp+0x60], xmm6
00007b629add9590  vmovaps [rsp+0x70], xmm7
00007b629add9596  vmovaps [rsp+0x80], xmm8
00007b629add959f  vmovaps [rsp+0x90], xmm9
00007b629add95a8  vmovaps [rsp+0xA0], xmm10
00007b629add95b1  vmovaps [rsp+0xB0], xmm11
00007b629add95ba  vmovaps [rsp+0xC0], xmm12
00007b629add95c3  vmovaps [rsp+0xD0], xmm13
00007b629add95cc  vmovaps [rsp+0xE0], xmm15
00007b629add95d5  sub rsp, 0x30
00007b629add95d9  movaps [rsp], xmm14
00007b629add95de  movaps [rsp+0x10], xmm8
00007b629add95e4  movaps [rsp+0x20], xmm4
00007b629add95e9  lea rdi, [rsp]
00007b629add95ed  mov esi, 0x00
00007b629add95f2  mov rax, 0x583FED93F530
00007b629add95fc  call rax
00007b629add95fe  movaps xmm14, [rsp]
00007b629add9603  add rsp, 0x30
00007b629add9607  vmovaps xmm0, [rsp]
00007b629add960c  vmovaps xmm1, [rsp+0x10]
00007b629add9612  vmovaps xmm2, [rsp+0x20]
00007b629add9618  vmovaps xmm3, [rsp+0x30]
00007b629add961e  vmovaps xmm4, [rsp+0x40]
00007b629add9624  vmovaps xmm5, [rsp+0x50]
00007b629add962a  vmovaps xmm6, [rsp+0x60]
00007b629add9630  vmovaps xmm7, [rsp+0x70]
00007b629add9636  vmovaps xmm8, [rsp+0x80]
00007b629add963f  vmovaps xmm9, [rsp+0x90]
00007b629add9648  vmovaps xmm10, [rsp+0xA0]
00007b629add9651  vmovaps xmm11, [rsp+0xB0]
00007b629add965a  vmovaps xmm12, [rsp+0xC0]
00007b629add9663  vmovaps xmm13, [rsp+0xD0]
00007b629add966c  vmovaps xmm15, [rsp+0xE0]
00007b629add9675  add rsp, 0xF0
00007b629add967c  pop r11
00007b629add967e  pop r10
00007b629add9680  pop r9
00007b629add9682  pop r8
00007b629add9684  pop rsi
00007b629add9685  pop rdi
00007b629add9686  pop rdx
00007b629add9687  pop rcx
00007b629add9688  pop rax
00007b629add9689  add rsp, 0x08
00007b629add968d  jmp 0x00007B629ADD6265
00007b629add9692  sub rsp, 0x08
00007b629add9696  push rax
00007b629add9697  push rcx
00007b629add9698  push rdx
00007b629add9699  push rdi
00007b629add969a  push rsi
00007b629add969b  push r8
00007b629add969d  push r9
00007b629add969f  push r10
00007b629add96a1  push r11
00007b629add96a3  sub rsp, 0xF0
00007b629add96aa  vmovaps [rsp], xmm0
00007b629add96af  vmovaps [rsp+0x10], xmm1
00007b629add96b5  vmovaps [rsp+0x20], xmm2
00007b629add96bb  vmovaps [rsp+0x30], xmm3
00007b629add96c1  vmovaps [rsp+0x40], xmm5
00007b629add96c7  vmovaps [rsp+0x50], xmm6
00007b629add96cd  vmovaps [rsp+0x60], xmm7
00007b629add96d3  vmovaps [rsp+0x70], xmm8
00007b629add96d9  vmovaps [rsp+0x80], xmm9
00007b629add96e2  vmovaps [rsp+0x90], xmm10
00007b629add96eb  vmovaps [rsp+0xA0], xmm11
00007b629add96f4  vmovaps [rsp+0xB0], xmm12
00007b629add96fd  vmovaps [rsp+0xC0], xmm13
00007b629add9706  vmovaps [rsp+0xD0], xmm14
00007b629add970f  vmovaps [rsp+0xE0], xmm15
00007b629add9718  sub rsp, 0x30
00007b629add971c  movaps [rsp], xmm4
00007b629add9720  movaps [rsp+0x10], xmm13
00007b629add9726  movaps [rsp+0x20], xmm8
00007b629add972c  lea rdi, [rsp]
00007b629add9730  mov esi, 0x00
00007b629add9735  mov rax, 0x583FED93F530
00007b629add973f  call rax
00007b629add9741  movaps xmm4, [rsp]
00007b629add9745  add rsp, 0x30
00007b629add9749  vmovaps xmm0, [rsp]
00007b629add974e  vmovaps xmm1, [rsp+0x10]
00007b629add9754  vmovaps xmm2, [rsp+0x20]
00007b629add975a  vmovaps xmm3, [rsp+0x30]
00007b629add9760  vmovaps xmm5, [rsp+0x40]
00007b629add9766  vmovaps xmm6, [rsp+0x50]
00007b629add976c  vmovaps xmm7, [rsp+0x60]
00007b629add9772  vmovaps xmm8, [rsp+0x70]
00007b629add9778  vmovaps xmm9, [rsp+0x80]
00007b629add9781  vmovaps xmm10, [rsp+0x90]
00007b629add978a  vmovaps xmm11, [rsp+0xA0]
00007b629add9793  vmovaps xmm12, [rsp+0xB0]
00007b629add979c  vmovaps xmm13, [rsp+0xC0]
00007b629add97a5  vmovaps xmm14, [rsp+0xD0]
00007b629add97ae  vmovaps xmm15, [rsp+0xE0]
00007b629add97b7  add rsp, 0xF0
00007b629add97be  pop r11
00007b629add97c0  pop r10
00007b629add97c2  pop r9
00007b629add97c4  pop r8
00007b629add97c6  pop rsi
00007b629add97c7  pop rdi
00007b629add97c8  pop rdx
00007b629add97c9  pop rcx
00007b629add97ca  pop rax
00007b629add97cb  add rsp, 0x08
00007b629add97cf  jmp 0x00007B629ADD628A
00007b629add97d4  sub rsp, 0x08
00007b629add97d8  push rax
00007b629add97d9  push rcx
00007b629add97da  push rdx
00007b629add97db  push rdi
00007b629add97dc  push rsi
00007b629add97dd  push r8
00007b629add97df  push r9
00007b629add97e1  push r10
00007b629add97e3  push r11
00007b629add97e5  sub rsp, 0xF0
00007b629add97ec  vmovaps [rsp], xmm0
00007b629add97f1  vmovaps [rsp+0x10], xmm1
00007b629add97f7  vmovaps [rsp+0x20], xmm2
00007b629add97fd  vmovaps [rsp+0x30], xmm3
00007b629add9803  vmovaps [rsp+0x40], xmm4
00007b629add9809  vmovaps [rsp+0x50], xmm5
00007b629add980f  vmovaps [rsp+0x60], xmm6
00007b629add9815  vmovaps [rsp+0x70], xmm7
00007b629add981b  vmovaps [rsp+0x80], xmm8
00007b629add9824  vmovaps [rsp+0x90], xmm9
00007b629add982d  vmovaps [rsp+0xA0], xmm10
00007b629add9836  vmovaps [rsp+0xB0], xmm11
00007b629add983f  vmovaps [rsp+0xC0], xmm12
00007b629add9848  vmovaps [rsp+0xD0], xmm14
00007b629add9851  vmovaps [rsp+0xE0], xmm15
00007b629add985a  sub rsp, 0x30
00007b629add985e  movaps [rsp], xmm13
00007b629add9863  movaps [rsp+0x10], xmm15
00007b629add9869  movaps [rsp+0x20], xmm9
00007b629add986f  lea rdi, [rsp]
00007b629add9873  mov esi, 0x00
00007b629add9878  mov rax, 0x583FED93F530
00007b629add9882  call rax
00007b629add9884  movaps xmm13, [rsp]
00007b629add9889  add rsp, 0x30
00007b629add988d  vmovaps xmm0, [rsp]
00007b629add9892  vmovaps xmm1, [rsp+0x10]
00007b629add9898  vmovaps xmm2, [rsp+0x20]
00007b629add989e  vmovaps xmm3, [rsp+0x30]
00007b629add98a4  vmovaps xmm4, [rsp+0x40]
00007b629add98aa  vmovaps xmm5, [rsp+0x50]
00007b629add98b0  vmovaps xmm6, [rsp+0x60]
00007b629add98b6  vmovaps xmm7, [rsp+0x70]
00007b629add98bc  vmovaps xmm8, [rsp+0x80]
00007b629add98c5  vmovaps xmm9, [rsp+0x90]
00007b629add98ce  vmovaps xmm10, [rsp+0xA0]
00007b629add98d7  vmovaps xmm11, [rsp+0xB0]
00007b629add98e0  vmovaps xmm12, [rsp+0xC0]
00007b629add98e9  vmovaps xmm14, [rsp+0xD0]
00007b629add98f2  vmovaps xmm15, [rsp+0xE0]
00007b629add98fb  add rsp, 0xF0
00007b629add9902  pop r11
00007b629add9904  pop r10
00007b629add9906  pop r9
00007b629add9908  pop r8
00007b629add990a  pop rsi
00007b629add990b  pop rdi
00007b629add990c  pop rdx
00007b629add990d  pop rcx
00007b629add990e  pop rax
00007b629add990f  add rsp, 0x08
00007b629add9913  jmp 0x00007B629ADD62A5
00007b629add9918  sub rsp, 0x08
00007b629add991c  push rax
00007b629add991d  push rcx
00007b629add991e  push rdx
00007b629add991f  push rdi
00007b629add9920  push rsi
00007b629add9921  push r8
00007b629add9923  push r9
00007b629add9925  push r10
00007b629add9927  push r11
00007b629add9929  sub rsp, 0xF0
00007b629add9930  vmovaps [rsp], xmm0
00007b629add9935  vmovaps [rsp+0x10], xmm1
00007b629add993b  vmovaps [rsp+0x20], xmm2
00007b629add9941  vmovaps [rsp+0x30], xmm3
00007b629add9947  vmovaps [rsp+0x40], xmm4
00007b629add994d  vmovaps [rsp+0x50], xmm5
00007b629add9953  vmovaps [rsp+0x60], xmm6
00007b629add9959  vmovaps [rsp+0x70], xmm7
00007b629add995f  vmovaps [rsp+0x80], xmm8
00007b629add9968  vmovaps [rsp+0x90], xmm9
00007b629add9971  vmovaps [rsp+0xA0], xmm10
00007b629add997a  vmovaps [rsp+0xB0], xmm11
00007b629add9983  vmovaps [rsp+0xC0], xmm12
00007b629add998c  vmovaps [rsp+0xD0], xmm13
00007b629add9995  vmovaps [rsp+0xE0], xmm14
00007b629add999e  sub rsp, 0x30
00007b629add99a2  movaps [rsp], xmm15
00007b629add99a7  movaps [rsp+0x10], xmm1
00007b629add99ac  movaps [rsp+0x20], xmm5
00007b629add99b1  lea rdi, [rsp]
00007b629add99b5  mov esi, 0x00
00007b629add99ba  mov rax, 0x583FED93F530
00007b629add99c4  call rax
00007b629add99c6  movaps xmm15, [rsp]
00007b629add99cb  add rsp, 0x30
00007b629add99cf  vmovaps xmm0, [rsp]
00007b629add99d4  vmovaps xmm1, [rsp+0x10]
00007b629add99da  vmovaps xmm2, [rsp+0x20]
00007b629add99e0  vmovaps xmm3, [rsp+0x30]
00007b629add99e6  vmovaps xmm4, [rsp+0x40]
00007b629add99ec  vmovaps xmm5, [rsp+0x50]
00007b629add99f2  vmovaps xmm6, [rsp+0x60]
00007b629add99f8  vmovaps xmm7, [rsp+0x70]
00007b629add99fe  vmovaps xmm8, [rsp+0x80]
00007b629add9a07  vmovaps xmm9, [rsp+0x90]
00007b629add9a10  vmovaps xmm10, [rsp+0xA0]
00007b629add9a19  vmovaps xmm11, [rsp+0xB0]
00007b629add9a22  vmovaps xmm12, [rsp+0xC0]
00007b629add9a2b  vmovaps xmm13, [rsp+0xD0]
00007b629add9a34  vmovaps xmm14, [rsp+0xE0]
00007b629add9a3d  add rsp, 0xF0
00007b629add9a44  pop r11
00007b629add9a46  pop r10
00007b629add9a48  pop r9
00007b629add9a4a  pop r8
00007b629add9a4c  pop rsi
00007b629add9a4d  pop rdi
00007b629add9a4e  pop rdx
00007b629add9a4f  pop rcx
00007b629add9a50  pop rax
00007b629add9a51  add rsp, 0x08
00007b629add9a55  jmp 0x00007B629ADD62C0
00007b629add9a5a  call 0x00007B629ACD64F0
00007b629add9a5f  jmp 0x00007B629ADD631B
00007b629add9a64  sub rsp, 0x08
00007b629add9a68  push rax
00007b629add9a69  push rcx
00007b629add9a6a  push rdx
00007b629add9a6b  push rdi
00007b629add9a6c  push rsi
00007b629add9a6d  push r8
00007b629add9a6f  push r9
00007b629add9a71  push r10
00007b629add9a73  push r11
00007b629add9a75  sub rsp, 0xF0
00007b629add9a7c  vmovaps [rsp], xmm0
00007b629add9a81  vmovaps [rsp+0x10], xmm1
00007b629add9a87  vmovaps [rsp+0x20], xmm2
00007b629add9a8d  vmovaps [rsp+0x30], xmm3
00007b629add9a93  vmovaps [rsp+0x40], xmm4
00007b629add9a99  vmovaps [rsp+0x50], xmm5
00007b629add9a9f  vmovaps [rsp+0x60], xmm6
00007b629add9aa5  vmovaps [rsp+0x70], xmm7
00007b629add9aab  vmovaps [rsp+0x80], xmm8
00007b629add9ab4  vmovaps [rsp+0x90], xmm10
00007b629add9abd  vmovaps [rsp+0xA0], xmm11
00007b629add9ac6  vmovaps [rsp+0xB0], xmm12
00007b629add9acf  vmovaps [rsp+0xC0], xmm13
00007b629add9ad8  vmovaps [rsp+0xD0], xmm14
00007b629add9ae1  vmovaps [rsp+0xE0], xmm15
00007b629add9aea  sub rsp, 0x30
00007b629add9aee  movaps [rsp], xmm9
00007b629add9af3  movaps [rsp+0x10], xmm8
00007b629add9af9  movaps [rsp+0x20], xmm11
00007b629add9aff  lea rdi, [rsp]
00007b629add9b03  mov esi, 0x00
00007b629add9b08  mov rax, 0x583FED93F530
00007b629add9b12  call rax
00007b629add9b14  movaps xmm9, [rsp]
00007b629add9b19  add rsp, 0x30
00007b629add9b1d  vmovaps xmm0, [rsp]
00007b629add9b22  vmovaps xmm1, [rsp+0x10]
00007b629add9b28  vmovaps xmm2, [rsp+0x20]
00007b629add9b2e  vmovaps xmm3, [rsp+0x30]
00007b629add9b34  vmovaps xmm4, [rsp+0x40]
00007b629add9b3a  vmovaps xmm5, [rsp+0x50]
00007b629add9b40  vmovaps xmm6, [rsp+0x60]
00007b629add9b46  vmovaps xmm7, [rsp+0x70]
00007b629add9b4c  vmovaps xmm8, [rsp+0x80]
00007b629add9b55  vmovaps xmm10, [rsp+0x90]
00007b629add9b5e  vmovaps xmm11, [rsp+0xA0]
00007b629add9b67  vmovaps xmm12, [rsp+0xB0]
00007b629add9b70  vmovaps xmm13, [rsp+0xC0]
00007b629add9b79  vmovaps xmm14, [rsp+0xD0]
00007b629add9b82  vmovaps xmm15, [rsp+0xE0]
00007b629add9b8b  add rsp, 0xF0
00007b629add9b92  pop r11
00007b629add9b94  pop r10
00007b629add9b96  pop r9
00007b629add9b98  pop r8
00007b629add9b9a  pop rsi
00007b629add9b9b  pop rdi
00007b629add9b9c  pop rdx
00007b629add9b9d  pop rcx
00007b629add9b9e  pop rax
00007b629add9b9f  add rsp, 0x08
00007b629add9ba3  jmp 0x00007B629ADD6352
00007b629add9ba8  sub rsp, 0x08
00007b629add9bac  push rax
00007b629add9bad  push rcx
00007b629add9bae  push rdx
00007b629add9baf  push rdi
00007b629add9bb0  push rsi
00007b629add9bb1  push r8
00007b629add9bb3  push r9
00007b629add9bb5  push r10
00007b629add9bb7  push r11
00007b629add9bb9  sub rsp, 0xF0
00007b629add9bc0  vmovaps [rsp], xmm0
00007b629add9bc5  vmovaps [rsp+0x10], xmm1
00007b629add9bcb  vmovaps [rsp+0x20], xmm2
00007b629add9bd1  vmovaps [rsp+0x30], xmm3
00007b629add9bd7  vmovaps [rsp+0x40], xmm4
00007b629add9bdd  vmovaps [rsp+0x50], xmm5
00007b629add9be3  vmovaps [rsp+0x60], xmm6
00007b629add9be9  vmovaps [rsp+0x70], xmm7
00007b629add9bef  vmovaps [rsp+0x80], xmm8
00007b629add9bf8  vmovaps [rsp+0x90], xmm9
00007b629add9c01  vmovaps [rsp+0xA0], xmm10
00007b629add9c0a  vmovaps [rsp+0xB0], xmm12
00007b629add9c13  vmovaps [rsp+0xC0], xmm13
00007b629add9c1c  vmovaps [rsp+0xD0], xmm14
00007b629add9c25  vmovaps [rsp+0xE0], xmm15
00007b629add9c2e  sub rsp, 0x30
00007b629add9c32  movaps [rsp], xmm11
00007b629add9c37  movaps [rsp+0x10], xmm10
00007b629add9c3d  movaps [rsp+0x20], xmm6
00007b629add9c42  lea rdi, [rsp]
00007b629add9c46  mov esi, 0x00
00007b629add9c4b  mov rax, 0x583FED93F530
00007b629add9c55  call rax
00007b629add9c57  movaps xmm11, [rsp]
00007b629add9c5c  add rsp, 0x30
00007b629add9c60  vmovaps xmm0, [rsp]
00007b629add9c65  vmovaps xmm1, [rsp+0x10]
00007b629add9c6b  vmovaps xmm2, [rsp+0x20]
00007b629add9c71  vmovaps xmm3, [rsp+0x30]
00007b629add9c77  vmovaps xmm4, [rsp+0x40]
00007b629add9c7d  vmovaps xmm5, [rsp+0x50]
00007b629add9c83  vmovaps xmm6, [rsp+0x60]
00007b629add9c89  vmovaps xmm7, [rsp+0x70]
00007b629add9c8f  vmovaps xmm8, [rsp+0x80]
00007b629add9c98  vmovaps xmm9, [rsp+0x90]
00007b629add9ca1  vmovaps xmm10, [rsp+0xA0]
00007b629add9caa  vmovaps xmm12, [rsp+0xB0]
00007b629add9cb3  vmovaps xmm13, [rsp+0xC0]
00007b629add9cbc  vmovaps xmm14, [rsp+0xD0]
00007b629add9cc5  vmovaps xmm15, [rsp+0xE0]
00007b629add9cce  add rsp, 0xF0
00007b629add9cd5  pop r11
00007b629add9cd7  pop r10
00007b629add9cd9  pop r9
00007b629add9cdb  pop r8
00007b629add9cdd  pop rsi
00007b629add9cde  pop rdi
00007b629add9cdf  pop rdx
00007b629add9ce0  pop rcx
00007b629add9ce1  pop rax
00007b629add9ce2  add rsp, 0x08
00007b629add9ce6  jmp 0x00007B629ADD636D
00007b629add9ceb  sub rsp, 0x08
00007b629add9cef  push rax
00007b629add9cf0  push rcx
00007b629add9cf1  push rdx
00007b629add9cf2  push rdi
00007b629add9cf3  push rsi
00007b629add9cf4  push r8
00007b629add9cf6  push r9
00007b629add9cf8  push r10
00007b629add9cfa  push r11
00007b629add9cfc  sub rsp, 0xF0
00007b629add9d03  vmovaps [rsp], xmm0
00007b629add9d08  vmovaps [rsp+0x10], xmm1
00007b629add9d0e  vmovaps [rsp+0x20], xmm2
00007b629add9d14  vmovaps [rsp+0x30], xmm3
00007b629add9d1a  vmovaps [rsp+0x40], xmm4
00007b629add9d20  vmovaps [rsp+0x50], xmm5
00007b629add9d26  vmovaps [rsp+0x60], xmm6
00007b629add9d2c  vmovaps [rsp+0x70], xmm7
00007b629add9d32  vmovaps [rsp+0x80], xmm8
00007b629add9d3b  vmovaps [rsp+0x90], xmm9
00007b629add9d44  vmovaps [rsp+0xA0], xmm11
00007b629add9d4d  vmovaps [rsp+0xB0], xmm12
00007b629add9d56  vmovaps [rsp+0xC0], xmm13
00007b629add9d5f  vmovaps [rsp+0xD0], xmm14
00007b629add9d68  vmovaps [rsp+0xE0], xmm15
00007b629add9d71  sub rsp, 0x30
00007b629add9d75  movaps [rsp], xmm10
00007b629add9d7a  movaps [rsp+0x10], xmm14
00007b629add9d80  movaps [rsp+0x20], xmm4
00007b629add9d85  lea rdi, [rsp]
00007b629add9d89  mov esi, 0x00
00007b629add9d8e  mov rax, 0x583FED93F530
00007b629add9d98  call rax
00007b629add9d9a  movaps xmm10, [rsp]
00007b629add9d9f  add rsp, 0x30
00007b629add9da3  vmovaps xmm0, [rsp]
00007b629add9da8  vmovaps xmm1, [rsp+0x10]
00007b629add9dae  vmovaps xmm2, [rsp+0x20]
00007b629add9db4  vmovaps xmm3, [rsp+0x30]
00007b629add9dba  vmovaps xmm4, [rsp+0x40]
00007b629add9dc0  vmovaps xmm5, [rsp+0x50]
00007b629add9dc6  vmovaps xmm6, [rsp+0x60]
00007b629add9dcc  vmovaps xmm7, [rsp+0x70]
00007b629add9dd2  vmovaps xmm8, [rsp+0x80]
00007b629add9ddb  vmovaps xmm9, [rsp+0x90]
00007b629add9de4  vmovaps xmm11, [rsp+0xA0]
00007b629add9ded  vmovaps xmm12, [rsp+0xB0]
00007b629add9df6  vmovaps xmm13, [rsp+0xC0]
00007b629add9dff  vmovaps xmm14, [rsp+0xD0]
00007b629add9e08  vmovaps xmm15, [rsp+0xE0]
00007b629add9e11  add rsp, 0xF0
00007b629add9e18  pop r11
00007b629add9e1a  pop r10
00007b629add9e1c  pop r9
00007b629add9e1e  pop r8
00007b629add9e20  pop rsi
00007b629add9e21  pop rdi
00007b629add9e22  pop rdx
00007b629add9e23  pop rcx
00007b629add9e24  pop rax
00007b629add9e25  add rsp, 0x08
00007b629add9e29  jmp 0x00007B629ADD6388
00007b629add9e2e  sub rsp, 0x08
00007b629add9e32  push rax
00007b629add9e33  push rcx
00007b629add9e34  push rdx
00007b629add9e35  push rdi
00007b629add9e36  push rsi
00007b629add9e37  push r8
00007b629add9e39  push r9
00007b629add9e3b  push r10
00007b629add9e3d  push r11
00007b629add9e3f  sub rsp, 0xF0
00007b629add9e46  vmovaps [rsp], xmm0
00007b629add9e4b  vmovaps [rsp+0x10], xmm1
00007b629add9e51  vmovaps [rsp+0x20], xmm2
00007b629add9e57  vmovaps [rsp+0x30], xmm3
00007b629add9e5d  vmovaps [rsp+0x40], xmm4
00007b629add9e63  vmovaps [rsp+0x50], xmm5
00007b629add9e69  vmovaps [rsp+0x60], xmm6
00007b629add9e6f  vmovaps [rsp+0x70], xmm7
00007b629add9e75  vmovaps [rsp+0x80], xmm9
00007b629add9e7e  vmovaps [rsp+0x90], xmm10
00007b629add9e87  vmovaps [rsp+0xA0], xmm11
00007b629add9e90  vmovaps [rsp+0xB0], xmm12
00007b629add9e99  vmovaps [rsp+0xC0], xmm13
00007b629add9ea2  vmovaps [rsp+0xD0], xmm14
00007b629add9eab  vmovaps [rsp+0xE0], xmm15
00007b629add9eb4  sub rsp, 0x30
00007b629add9eb8  movaps [rsp], xmm8
00007b629add9ebd  movaps [rsp+0x10], xmm1
00007b629add9ec2  movaps [rsp+0x20], xmm14
00007b629add9ec8  lea rdi, [rsp]
00007b629add9ecc  mov esi, 0x00
00007b629add9ed1  mov rax, 0x583FED93F530
00007b629add9edb  call rax
00007b629add9edd  movaps xmm8, [rsp]
00007b629add9ee2  add rsp, 0x30
00007b629add9ee6  vmovaps xmm0, [rsp]
00007b629add9eeb  vmovaps xmm1, [rsp+0x10]
00007b629add9ef1  vmovaps xmm2, [rsp+0x20]
00007b629add9ef7  vmovaps xmm3, [rsp+0x30]
00007b629add9efd  vmovaps xmm4, [rsp+0x40]
00007b629add9f03  vmovaps xmm5, [rsp+0x50]
00007b629add9f09  vmovaps xmm6, [rsp+0x60]
00007b629add9f0f  vmovaps xmm7, [rsp+0x70]
00007b629add9f15  vmovaps xmm9, [rsp+0x80]
00007b629add9f1e  vmovaps xmm10, [rsp+0x90]
00007b629add9f27  vmovaps xmm11, [rsp+0xA0]
00007b629add9f30  vmovaps xmm12, [rsp+0xB0]
00007b629add9f39  vmovaps xmm13, [rsp+0xC0]
00007b629add9f42  vmovaps xmm14, [rsp+0xD0]
00007b629add9f4b  vmovaps xmm15, [rsp+0xE0]
00007b629add9f54  add rsp, 0xF0
00007b629add9f5b  pop r11
00007b629add9f5d  pop r10
00007b629add9f5f  pop r9
00007b629add9f61  pop r8
00007b629add9f63  pop rsi
00007b629add9f64  pop rdi
00007b629add9f65  pop rdx
00007b629add9f66  pop rcx
00007b629add9f67  pop rax
00007b629add9f68  add rsp, 0x08
00007b629add9f6c  jmp 0x00007B629ADD63AE
00007b629add9f71  sub rsp, 0x08
00007b629add9f75  push rax
00007b629add9f76  push rcx
00007b629add9f77  push rdx
00007b629add9f78  push rdi
00007b629add9f79  push rsi
00007b629add9f7a  push r8
00007b629add9f7c  push r9
00007b629add9f7e  push r10
00007b629add9f80  push r11
00007b629add9f82  sub rsp, 0xF0
00007b629add9f89  vmovaps [rsp], xmm0
00007b629add9f8e  vmovaps [rsp+0x10], xmm1
00007b629add9f94  vmovaps [rsp+0x20], xmm2
00007b629add9f9a  vmovaps [rsp+0x30], xmm3
00007b629add9fa0  vmovaps [rsp+0x40], xmm4
00007b629add9fa6  vmovaps [rsp+0x50], xmm5
00007b629add9fac  vmovaps [rsp+0x60], xmm7
00007b629add9fb2  vmovaps [rsp+0x70], xmm8
00007b629add9fb8  vmovaps [rsp+0x80], xmm9
00007b629add9fc1  vmovaps [rsp+0x90], xmm10
00007b629add9fca  vmovaps [rsp+0xA0], xmm11
00007b629add9fd3  vmovaps [rsp+0xB0], xmm12
00007b629add9fdc  vmovaps [rsp+0xC0], xmm13
00007b629add9fe5  vmovaps [rsp+0xD0], xmm14
00007b629add9fee  vmovaps [rsp+0xE0], xmm15
00007b629add9ff7  sub rsp, 0x30
00007b629add9ffb  movaps [rsp], xmm6
00007b629add9fff  movaps [rsp+0x10], xmm1
00007b629adda004  movaps [rsp+0x20], xmm14
00007b629adda00a  lea rdi, [rsp]
00007b629adda00e  mov esi, 0x00
00007b629adda013  mov rax, 0x583FED93F530
00007b629adda01d  call rax
00007b629adda01f  movaps xmm6, [rsp]
00007b629adda023  add rsp, 0x30
00007b629adda027  vmovaps xmm0, [rsp]
00007b629adda02c  vmovaps xmm1, [rsp+0x10]
00007b629adda032  vmovaps xmm2, [rsp+0x20]
00007b629adda038  vmovaps xmm3, [rsp+0x30]
00007b629adda03e  vmovaps xmm4, [rsp+0x40]
00007b629adda044  vmovaps xmm5, [rsp+0x50]
00007b629adda04a  vmovaps xmm7, [rsp+0x60]
00007b629adda050  vmovaps xmm8, [rsp+0x70]
00007b629adda056  vmovaps xmm9, [rsp+0x80]
00007b629adda05f  vmovaps xmm10, [rsp+0x90]
00007b629adda068  vmovaps xmm11, [rsp+0xA0]
00007b629adda071  vmovaps xmm12, [rsp+0xB0]
00007b629adda07a  vmovaps xmm13, [rsp+0xC0]
00007b629adda083  vmovaps xmm14, [rsp+0xD0]
00007b629adda08c  vmovaps xmm15, [rsp+0xE0]
00007b629adda095  add rsp, 0xF0
00007b629adda09c  pop r11
00007b629adda09e  pop r10
00007b629adda0a0  pop r9
00007b629adda0a2  pop r8
00007b629adda0a4  pop rsi
00007b629adda0a5  pop rdi
00007b629adda0a6  pop rdx
00007b629adda0a7  pop rcx
00007b629adda0a8  pop rax
00007b629adda0a9  add rsp, 0x08
00007b629adda0ad  jmp 0x00007B629ADD63DA
00007b629adda0b2  sub rsp, 0x08
00007b629adda0b6  push rax
00007b629adda0b7  push rcx
00007b629adda0b8  push rdx
00007b629adda0b9  push rdi
00007b629adda0ba  push rsi
00007b629adda0bb  push r8
00007b629adda0bd  push r9
00007b629adda0bf  push r10
00007b629adda0c1  push r11
00007b629adda0c3  sub rsp, 0xF0
00007b629adda0ca  vmovaps [rsp], xmm0
00007b629adda0cf  vmovaps [rsp+0x10], xmm1
00007b629adda0d5  vmovaps [rsp+0x20], xmm2
00007b629adda0db  vmovaps [rsp+0x30], xmm3
00007b629adda0e1  vmovaps [rsp+0x40], xmm4
00007b629adda0e7  vmovaps [rsp+0x50], xmm5
00007b629adda0ed  vmovaps [rsp+0x60], xmm6
00007b629adda0f3  vmovaps [rsp+0x70], xmm7
00007b629adda0f9  vmovaps [rsp+0x80], xmm8
00007b629adda102  vmovaps [rsp+0x90], xmm9
00007b629adda10b  vmovaps [rsp+0xA0], xmm10
00007b629adda114  vmovaps [rsp+0xB0], xmm11
00007b629adda11d  vmovaps [rsp+0xC0], xmm12
00007b629adda126  vmovaps [rsp+0xD0], xmm13
00007b629adda12f  vmovaps [rsp+0xE0], xmm15
00007b629adda138  sub rsp, 0x30
00007b629adda13c  movaps [rsp], xmm14
00007b629adda141  movaps [rsp+0x10], xmm12
00007b629adda147  movaps [rsp+0x20], xmm1
00007b629adda14c  lea rdi, [rsp]
00007b629adda150  mov esi, 0x00
00007b629adda155  mov rax, 0x583FED93F530
00007b629adda15f  call rax
00007b629adda161  movaps xmm14, [rsp]
00007b629adda166  add rsp, 0x30
00007b629adda16a  vmovaps xmm0, [rsp]
00007b629adda16f  vmovaps xmm1, [rsp+0x10]
00007b629adda175  vmovaps xmm2, [rsp+0x20]
00007b629adda17b  vmovaps xmm3, [rsp+0x30]
00007b629adda181  vmovaps xmm4, [rsp+0x40]
00007b629adda187  vmovaps xmm5, [rsp+0x50]
00007b629adda18d  vmovaps xmm6, [rsp+0x60]
00007b629adda193  vmovaps xmm7, [rsp+0x70]
00007b629adda199  vmovaps xmm8, [rsp+0x80]
00007b629adda1a2  vmovaps xmm9, [rsp+0x90]
00007b629adda1ab  vmovaps xmm10, [rsp+0xA0]
00007b629adda1b4  vmovaps xmm11, [rsp+0xB0]
00007b629adda1bd  vmovaps xmm12, [rsp+0xC0]
00007b629adda1c6  vmovaps xmm13, [rsp+0xD0]
00007b629adda1cf  vmovaps xmm15, [rsp+0xE0]
00007b629adda1d8  add rsp, 0xF0
00007b629adda1df  pop r11
00007b629adda1e1  pop r10
00007b629adda1e3  pop r9
00007b629adda1e5  pop r8
00007b629adda1e7  pop rsi
00007b629adda1e8  pop rdi
00007b629adda1e9  pop rdx
00007b629adda1ea  pop rcx
00007b629adda1eb  pop rax
00007b629adda1ec  add rsp, 0x08
00007b629adda1f0  jmp 0x00007B629ADD6400
00007b629adda1f5  sub rsp, 0x08
00007b629adda1f9  push rax
00007b629adda1fa  push rcx
00007b629adda1fb  push rdx
00007b629adda1fc  push rdi
00007b629adda1fd  push rsi
00007b629adda1fe  push r8
00007b629adda200  push r9
00007b629adda202  push r10
00007b629adda204  push r11
00007b629adda206  sub rsp, 0xF0
00007b629adda20d  vmovaps [rsp], xmm0
00007b629adda212  vmovaps [rsp+0x10], xmm2
00007b629adda218  vmovaps [rsp+0x20], xmm3
00007b629adda21e  vmovaps [rsp+0x30], xmm4
00007b629adda224  vmovaps [rsp+0x40], xmm5
00007b629adda22a  vmovaps [rsp+0x50], xmm6
00007b629adda230  vmovaps [rsp+0x60], xmm7
00007b629adda236  vmovaps [rsp+0x70], xmm8
00007b629adda23c  vmovaps [rsp+0x80], xmm9
00007b629adda245  vmovaps [rsp+0x90], xmm10
00007b629adda24e  vmovaps [rsp+0xA0], xmm11
00007b629adda257  vmovaps [rsp+0xB0], xmm12
00007b629adda260  vmovaps [rsp+0xC0], xmm13
00007b629adda269  vmovaps [rsp+0xD0], xmm14
00007b629adda272  vmovaps [rsp+0xE0], xmm15
00007b629adda27b  sub rsp, 0x30
00007b629adda27f  movaps [rsp], xmm1
00007b629adda283  movaps [rsp+0x10], xmm13
00007b629adda289  movaps [rsp+0x20], xmm9
00007b629adda28f  lea rdi, [rsp]
00007b629adda293  mov esi, 0x00
00007b629adda298  mov rax, 0x583FED93F530
00007b629adda2a2  call rax
00007b629adda2a4  movaps xmm1, [rsp]
00007b629adda2a8  add rsp, 0x30
00007b629adda2ac  vmovaps xmm0, [rsp]
00007b629adda2b1  vmovaps xmm2, [rsp+0x10]
00007b629adda2b7  vmovaps xmm3, [rsp+0x20]
00007b629adda2bd  vmovaps xmm4, [rsp+0x30]
00007b629adda2c3  vmovaps xmm5, [rsp+0x40]
00007b629adda2c9  vmovaps xmm6, [rsp+0x50]
00007b629adda2cf  vmovaps xmm7, [rsp+0x60]
00007b629adda2d5  vmovaps xmm8, [rsp+0x70]
00007b629adda2db  vmovaps xmm9, [rsp+0x80]
00007b629adda2e4  vmovaps xmm10, [rsp+0x90]
00007b629adda2ed  vmovaps xmm11, [rsp+0xA0]
00007b629adda2f6  vmovaps xmm12, [rsp+0xB0]
00007b629adda2ff  vmovaps xmm13, [rsp+0xC0]
00007b629adda308  vmovaps xmm14, [rsp+0xD0]
00007b629adda311  vmovaps xmm15, [rsp+0xE0]
00007b629adda31a  add rsp, 0xF0
00007b629adda321  pop r11
00007b629adda323  pop r10
00007b629adda325  pop r9
00007b629adda327  pop r8
00007b629adda329  pop rsi
00007b629adda32a  pop rdi
00007b629adda32b  pop rdx
00007b629adda32c  pop rcx
00007b629adda32d  pop rax
00007b629adda32e  add rsp, 0x08
00007b629adda332  jmp 0x00007B629ADD641A
00007b629adda337  sub rsp, 0x08
00007b629adda33b  push rax
00007b629adda33c  push rcx
00007b629adda33d  push rdx
00007b629adda33e  push rdi
00007b629adda33f  push rsi
00007b629adda340  push r8
00007b629adda342  push r9
00007b629adda344  push r10
00007b629adda346  push r11
00007b629adda348  sub rsp, 0xF0
00007b629adda34f  vmovaps [rsp], xmm0
00007b629adda354  vmovaps [rsp+0x10], xmm1
00007b629adda35a  vmovaps [rsp+0x20], xmm2
00007b629adda360  vmovaps [rsp+0x30], xmm3
00007b629adda366  vmovaps [rsp+0x40], xmm4
00007b629adda36c  vmovaps [rsp+0x50], xmm5
00007b629adda372  vmovaps [rsp+0x60], xmm6
00007b629adda378  vmovaps [rsp+0x70], xmm7
00007b629adda37e  vmovaps [rsp+0x80], xmm8
00007b629adda387  vmovaps [rsp+0x90], xmm9
00007b629adda390  vmovaps [rsp+0xA0], xmm10
00007b629adda399  vmovaps [rsp+0xB0], xmm11
00007b629adda3a2  vmovaps [rsp+0xC0], xmm13
00007b629adda3ab  vmovaps [rsp+0xD0], xmm14
00007b629adda3b4  vmovaps [rsp+0xE0], xmm15
00007b629adda3bd  sub rsp, 0x30
00007b629adda3c1  movaps [rsp], xmm12
00007b629adda3c6  movaps [rsp+0x10], xmm7
00007b629adda3cb  movaps [rsp+0x20], xmm13
00007b629adda3d1  lea rdi, [rsp]
00007b629adda3d5  mov esi, 0x00
00007b629adda3da  mov rax, 0x583FED93F530
00007b629adda3e4  call rax
00007b629adda3e6  movaps xmm12, [rsp]
00007b629adda3eb  add rsp, 0x30
00007b629adda3ef  vmovaps xmm0, [rsp]
00007b629adda3f4  vmovaps xmm1, [rsp+0x10]
00007b629adda3fa  vmovaps xmm2, [rsp+0x20]
00007b629adda400  vmovaps xmm3, [rsp+0x30]
00007b629adda406  vmovaps xmm4, [rsp+0x40]
00007b629adda40c  vmovaps xmm5, [rsp+0x50]
00007b629adda412  vmovaps xmm6, [rsp+0x60]
00007b629adda418  vmovaps xmm7, [rsp+0x70]
00007b629adda41e  vmovaps xmm8, [rsp+0x80]
00007b629adda427  vmovaps xmm9, [rsp+0x90]
00007b629adda430  vmovaps xmm10, [rsp+0xA0]
00007b629adda439  vmovaps xmm11, [rsp+0xB0]
00007b629adda442  vmovaps xmm13, [rsp+0xC0]
00007b629adda44b  vmovaps xmm14, [rsp+0xD0]
00007b629adda454  vmovaps xmm15, [rsp+0xE0]
00007b629adda45d  add rsp, 0xF0
00007b629adda464  pop r11
00007b629adda466  pop r10
00007b629adda468  pop r9
00007b629adda46a  pop r8
00007b629adda46c  pop rsi
00007b629adda46d  pop rdi
00007b629adda46e  pop rdx
00007b629adda46f  pop rcx
00007b629adda470  pop rax
00007b629adda471  add rsp, 0x08
00007b629adda475  jmp 0x00007B629ADD6441
00007b629adda47a  sub rsp, 0x08
00007b629adda47e  push rax
00007b629adda47f  push rcx
00007b629adda480  push rdx
00007b629adda481  push rdi
00007b629adda482  push rsi
00007b629adda483  push r8
00007b629adda485  push r9
00007b629adda487  push r10
00007b629adda489  push r11
00007b629adda48b  sub rsp, 0xF0
00007b629adda492  vmovaps [rsp], xmm0
00007b629adda497  vmovaps [rsp+0x10], xmm1
00007b629adda49d  vmovaps [rsp+0x20], xmm2
00007b629adda4a3  vmovaps [rsp+0x30], xmm3
00007b629adda4a9  vmovaps [rsp+0x40], xmm4
00007b629adda4af  vmovaps [rsp+0x50], xmm5
00007b629adda4b5  vmovaps [rsp+0x60], xmm6
00007b629adda4bb  vmovaps [rsp+0x70], xmm7
00007b629adda4c1  vmovaps [rsp+0x80], xmm8
00007b629adda4ca  vmovaps [rsp+0x90], xmm9
00007b629adda4d3  vmovaps [rsp+0xA0], xmm10
00007b629adda4dc  vmovaps [rsp+0xB0], xmm11
00007b629adda4e5  vmovaps [rsp+0xC0], xmm12
00007b629adda4ee  vmovaps [rsp+0xD0], xmm14
00007b629adda4f7  vmovaps [rsp+0xE0], xmm15
00007b629adda500  sub rsp, 0x30
00007b629adda504  movaps [rsp], xmm13
00007b629adda509  movaps [rsp+0x10], xmm15
00007b629adda50f  movaps [rsp+0x20], xmm8
00007b629adda515  lea rdi, [rsp]
00007b629adda519  mov esi, 0x00
00007b629adda51e  mov rax, 0x583FED93F530
00007b629adda528  call rax
00007b629adda52a  movaps xmm13, [rsp]
00007b629adda52f  add rsp, 0x30
00007b629adda533  vmovaps xmm0, [rsp]
00007b629adda538  vmovaps xmm1, [rsp+0x10]
00007b629adda53e  vmovaps xmm2, [rsp+0x20]
00007b629adda544  vmovaps xmm3, [rsp+0x30]
00007b629adda54a  vmovaps xmm4, [rsp+0x40]
00007b629adda550  vmovaps xmm5, [rsp+0x50]
00007b629adda556  vmovaps xmm6, [rsp+0x60]
00007b629adda55c  vmovaps xmm7, [rsp+0x70]
00007b629adda562  vmovaps xmm8, [rsp+0x80]
00007b629adda56b  vmovaps xmm9, [rsp+0x90]
00007b629adda574  vmovaps xmm10, [rsp+0xA0]
00007b629adda57d  vmovaps xmm11, [rsp+0xB0]
00007b629adda586  vmovaps xmm12, [rsp+0xC0]
00007b629adda58f  vmovaps xmm14, [rsp+0xD0]
00007b629adda598  vmovaps xmm15, [rsp+0xE0]
00007b629adda5a1  add rsp, 0xF0
00007b629adda5a8  pop r11
00007b629adda5aa  pop r10
00007b629adda5ac  pop r9
00007b629adda5ae  pop r8
00007b629adda5b0  pop rsi
00007b629adda5b1  pop rdi
00007b629adda5b2  pop rdx
00007b629adda5b3  pop rcx
00007b629adda5b4  pop rax
00007b629adda5b5  add rsp, 0x08
00007b629adda5b9  jmp 0x00007B629ADD645C
00007b629adda5be  sub rsp, 0x08
00007b629adda5c2  push rax
00007b629adda5c3  push rcx
00007b629adda5c4  push rdx
00007b629adda5c5  push rdi
00007b629adda5c6  push rsi
00007b629adda5c7  push r8
00007b629adda5c9  push r9
00007b629adda5cb  push r10
00007b629adda5cd  push r11
00007b629adda5cf  sub rsp, 0xF0
00007b629adda5d6  vmovaps [rsp], xmm0
00007b629adda5db  vmovaps [rsp+0x10], xmm1
00007b629adda5e1  vmovaps [rsp+0x20], xmm2
00007b629adda5e7  vmovaps [rsp+0x30], xmm3
00007b629adda5ed  vmovaps [rsp+0x40], xmm4
00007b629adda5f3  vmovaps [rsp+0x50], xmm5
00007b629adda5f9  vmovaps [rsp+0x60], xmm6
00007b629adda5ff  vmovaps [rsp+0x70], xmm7
00007b629adda605  vmovaps [rsp+0x80], xmm9
00007b629adda60e  vmovaps [rsp+0x90], xmm10
00007b629adda617  vmovaps [rsp+0xA0], xmm11
00007b629adda620  vmovaps [rsp+0xB0], xmm12
00007b629adda629  vmovaps [rsp+0xC0], xmm13
00007b629adda632  vmovaps [rsp+0xD0], xmm14
00007b629adda63b  vmovaps [rsp+0xE0], xmm15
00007b629adda644  sub rsp, 0x30
00007b629adda648  movaps [rsp], xmm8
00007b629adda64d  movaps [rsp+0x10], xmm15
00007b629adda653  movaps [rsp+0x20], xmm9
00007b629adda659  lea rdi, [rsp]
00007b629adda65d  mov esi, 0x00
00007b629adda662  mov rax, 0x583FED93F530
00007b629adda66c  call rax
00007b629adda66e  movaps xmm8, [rsp]
00007b629adda673  add rsp, 0x30
00007b629adda677  vmovaps xmm0, [rsp]
00007b629adda67c  vmovaps xmm1, [rsp+0x10]
00007b629adda682  vmovaps xmm2, [rsp+0x20]
00007b629adda688  vmovaps xmm3, [rsp+0x30]
00007b629adda68e  vmovaps xmm4, [rsp+0x40]
00007b629adda694  vmovaps xmm5, [rsp+0x50]
00007b629adda69a  vmovaps xmm6, [rsp+0x60]
00007b629adda6a0  vmovaps xmm7, [rsp+0x70]
00007b629adda6a6  vmovaps xmm9, [rsp+0x80]
00007b629adda6af  vmovaps xmm10, [rsp+0x90]
00007b629adda6b8  vmovaps xmm11, [rsp+0xA0]
00007b629adda6c1  vmovaps xmm12, [rsp+0xB0]
00007b629adda6ca  vmovaps xmm13, [rsp+0xC0]
00007b629adda6d3  vmovaps xmm14, [rsp+0xD0]
00007b629adda6dc  vmovaps xmm15, [rsp+0xE0]
00007b629adda6e5  add rsp, 0xF0
00007b629adda6ec  pop r11
00007b629adda6ee  pop r10
00007b629adda6f0  pop r9
00007b629adda6f2  pop r8
00007b629adda6f4  pop rsi
00007b629adda6f5  pop rdi
00007b629adda6f6  pop rdx
00007b629adda6f7  pop rcx
00007b629adda6f8  pop rax
00007b629adda6f9  add rsp, 0x08
00007b629adda6fd  jmp 0x00007B629ADD648A
00007b629adda702  sub rsp, 0x08
00007b629adda706  push rax
00007b629adda707  push rcx
00007b629adda708  push rdx
00007b629adda709  push rdi
00007b629adda70a  push rsi
00007b629adda70b  push r8
00007b629adda70d  push r9
00007b629adda70f  push r10
00007b629adda711  push r11
00007b629adda713  sub rsp, 0xF0
00007b629adda71a  vmovaps [rsp], xmm0
00007b629adda71f  vmovaps [rsp+0x10], xmm1
00007b629adda725  vmovaps [rsp+0x20], xmm2
00007b629adda72b  vmovaps [rsp+0x30], xmm3
00007b629adda731  vmovaps [rsp+0x40], xmm4
00007b629adda737  vmovaps [rsp+0x50], xmm5
00007b629adda73d  vmovaps [rsp+0x60], xmm6
00007b629adda743  vmovaps [rsp+0x70], xmm7
00007b629adda749  vmovaps [rsp+0x80], xmm8
00007b629adda752  vmovaps [rsp+0x90], xmm9
00007b629adda75b  vmovaps [rsp+0xA0], xmm10
00007b629adda764  vmovaps [rsp+0xB0], xmm11
00007b629adda76d  vmovaps [rsp+0xC0], xmm12
00007b629adda776  vmovaps [rsp+0xD0], xmm13
00007b629adda77f  vmovaps [rsp+0xE0], xmm14
00007b629adda788  sub rsp, 0x30
00007b629adda78c  movaps [rsp], xmm15
00007b629adda791  movaps [rsp+0x10], xmm11
00007b629adda797  movaps [rsp+0x20], xmm6
00007b629adda79c  lea rdi, [rsp]
00007b629adda7a0  mov esi, 0x00
00007b629adda7a5  mov rax, 0x583FED93F530
00007b629adda7af  call rax
00007b629adda7b1  movaps xmm15, [rsp]
00007b629adda7b6  add rsp, 0x30
00007b629adda7ba  vmovaps xmm0, [rsp]
00007b629adda7bf  vmovaps xmm1, [rsp+0x10]
00007b629adda7c5  vmovaps xmm2, [rsp+0x20]
00007b629adda7cb  vmovaps xmm3, [rsp+0x30]
00007b629adda7d1  vmovaps xmm4, [rsp+0x40]
00007b629adda7d7  vmovaps xmm5, [rsp+0x50]
00007b629adda7dd  vmovaps xmm6, [rsp+0x60]
00007b629adda7e3  vmovaps xmm7, [rsp+0x70]
00007b629adda7e9  vmovaps xmm8, [rsp+0x80]
00007b629adda7f2  vmovaps xmm9, [rsp+0x90]
00007b629adda7fb  vmovaps xmm10, [rsp+0xA0]
00007b629adda804  vmovaps xmm11, [rsp+0xB0]
00007b629adda80d  vmovaps xmm12, [rsp+0xC0]
00007b629adda816  vmovaps xmm13, [rsp+0xD0]
00007b629adda81f  vmovaps xmm14, [rsp+0xE0]
00007b629adda828  add rsp, 0xF0
00007b629adda82f  pop r11
00007b629adda831  pop r10
00007b629adda833  pop r9
00007b629adda835  pop r8
00007b629adda837  pop rsi
00007b629adda838  pop rdi
00007b629adda839  pop rdx
00007b629adda83a  pop rcx
00007b629adda83b  pop rax
00007b629adda83c  add rsp, 0x08
00007b629adda840  jmp 0x00007B629ADD64A5
00007b629adda845  sub rsp, 0x08
00007b629adda849  push rax
00007b629adda84a  push rcx
00007b629adda84b  push rdx
00007b629adda84c  push rdi
00007b629adda84d  push rsi
00007b629adda84e  push r8
00007b629adda850  push r9
00007b629adda852  push r10
00007b629adda854  push r11
00007b629adda856  sub rsp, 0xF0
00007b629adda85d  vmovaps [rsp], xmm0
00007b629adda862  vmovaps [rsp+0x10], xmm1
00007b629adda868  vmovaps [rsp+0x20], xmm2
00007b629adda86e  vmovaps [rsp+0x30], xmm3
00007b629adda874  vmovaps [rsp+0x40], xmm4
00007b629adda87a  vmovaps [rsp+0x50], xmm5
00007b629adda880  vmovaps [rsp+0x60], xmm6
00007b629adda886  vmovaps [rsp+0x70], xmm8
00007b629adda88c  vmovaps [rsp+0x80], xmm9
00007b629adda895  vmovaps [rsp+0x90], xmm10
00007b629adda89e  vmovaps [rsp+0xA0], xmm11
00007b629adda8a7  vmovaps [rsp+0xB0], xmm12
00007b629adda8b0  vmovaps [rsp+0xC0], xmm13
00007b629adda8b9  vmovaps [rsp+0xD0], xmm14
00007b629adda8c2  vmovaps [rsp+0xE0], xmm15
00007b629adda8cb  sub rsp, 0x30
00007b629adda8cf  movaps [rsp], xmm7
00007b629adda8d3  movaps [rsp+0x10], xmm11
00007b629adda8d9  movaps [rsp+0x20], xmm9
00007b629adda8df  lea rdi, [rsp]
00007b629adda8e3  mov esi, 0x00
00007b629adda8e8  mov rax, 0x583FED93F530
00007b629adda8f2  call rax
00007b629adda8f4  movaps xmm7, [rsp]
00007b629adda8f8  add rsp, 0x30
00007b629adda8fc  vmovaps xmm0, [rsp]
00007b629adda901  vmovaps xmm1, [rsp+0x10]
00007b629adda907  vmovaps xmm2, [rsp+0x20]
00007b629adda90d  vmovaps xmm3, [rsp+0x30]
00007b629adda913  vmovaps xmm4, [rsp+0x40]
00007b629adda919  vmovaps xmm5, [rsp+0x50]
00007b629adda91f  vmovaps xmm6, [rsp+0x60]
00007b629adda925  vmovaps xmm8, [rsp+0x70]
00007b629adda92b  vmovaps xmm9, [rsp+0x80]
00007b629adda934  vmovaps xmm10, [rsp+0x90]
00007b629adda93d  vmovaps xmm11, [rsp+0xA0]
00007b629adda946  vmovaps xmm12, [rsp+0xB0]
00007b629adda94f  vmovaps xmm13, [rsp+0xC0]
00007b629adda958  vmovaps xmm14, [rsp+0xD0]
00007b629adda961  vmovaps xmm15, [rsp+0xE0]
00007b629adda96a  add rsp, 0xF0
00007b629adda971  pop r11
00007b629adda973  pop r10
00007b629adda975  pop r9
00007b629adda977  pop r8
00007b629adda979  pop rsi
00007b629adda97a  pop rdi
00007b629adda97b  pop rdx
00007b629adda97c  pop rcx
00007b629adda97d  pop rax
00007b629adda97e  add rsp, 0x08
00007b629adda982  jmp 0x00007B629ADD64D2
00007b629adda987  sub rsp, 0x08
00007b629adda98b  push rax
00007b629adda98c  push rcx
00007b629adda98d  push rdx
00007b629adda98e  push rdi
00007b629adda98f  push rsi
00007b629adda990  push r8
00007b629adda992  push r9
00007b629adda994  push r10
00007b629adda996  push r11
00007b629adda998  sub rsp, 0xF0
00007b629adda99f  vmovaps [rsp], xmm0
00007b629adda9a4  vmovaps [rsp+0x10], xmm1
00007b629adda9aa  vmovaps [rsp+0x20], xmm2
00007b629adda9b0  vmovaps [rsp+0x30], xmm3
00007b629adda9b6  vmovaps [rsp+0x40], xmm4
00007b629adda9bc  vmovaps [rsp+0x50], xmm5
00007b629adda9c2  vmovaps [rsp+0x60], xmm6
00007b629adda9c8  vmovaps [rsp+0x70], xmm7
00007b629adda9ce  vmovaps [rsp+0x80], xmm8
00007b629adda9d7  vmovaps [rsp+0x90], xmm9
00007b629adda9e0  vmovaps [rsp+0xA0], xmm10
00007b629adda9e9  vmovaps [rsp+0xB0], xmm12
00007b629adda9f2  vmovaps [rsp+0xC0], xmm13
00007b629adda9fb  vmovaps [rsp+0xD0], xmm14
00007b629addaa04  vmovaps [rsp+0xE0], xmm15
00007b629addaa0d  sub rsp, 0x30
00007b629addaa11  movaps [rsp], xmm11
00007b629addaa16  movaps [rsp+0x10], xmm10
00007b629addaa1c  movaps [rsp+0x20], xmm14
00007b629addaa22  lea rdi, [rsp]
00007b629addaa26  mov esi, 0x00
00007b629addaa2b  mov rax, 0x583FED93F530
00007b629addaa35  call rax
00007b629addaa37  movaps xmm11, [rsp]
00007b629addaa3c  add rsp, 0x30
00007b629addaa40  vmovaps xmm0, [rsp]
00007b629addaa45  vmovaps xmm1, [rsp+0x10]
00007b629addaa4b  vmovaps xmm2, [rsp+0x20]
00007b629addaa51  vmovaps xmm3, [rsp+0x30]
00007b629addaa57  vmovaps xmm4, [rsp+0x40]
00007b629addaa5d  vmovaps xmm5, [rsp+0x50]
00007b629addaa63  vmovaps xmm6, [rsp+0x60]
00007b629addaa69  vmovaps xmm7, [rsp+0x70]
00007b629addaa6f  vmovaps xmm8, [rsp+0x80]
00007b629addaa78  vmovaps xmm9, [rsp+0x90]
00007b629addaa81  vmovaps xmm10, [rsp+0xA0]
00007b629addaa8a  vmovaps xmm12, [rsp+0xB0]
00007b629addaa93  vmovaps xmm13, [rsp+0xC0]
00007b629addaa9c  vmovaps xmm14, [rsp+0xD0]
00007b629addaaa5  vmovaps xmm15, [rsp+0xE0]
00007b629addaaae  add rsp, 0xF0
00007b629addaab5  pop r11
00007b629addaab7  pop r10
00007b629addaab9  pop r9
00007b629addaabb  pop r8
00007b629addaabd  pop rsi
00007b629addaabe  pop rdi
00007b629addaabf  pop rdx
00007b629addaac0  pop rcx
00007b629addaac1  pop rax
00007b629addaac2  add rsp, 0x08
00007b629addaac6  jmp 0x00007B629ADD64ED
00007b629addaacb  call 0x00007B629ACE45A0
00007b629addaad0  jmp 0x00007B629ADD64F7
00007b629addaad5  sub rsp, 0x08
00007b629addaad9  push rax
00007b629addaada  push rcx
00007b629addaadb  push rdx
00007b629addaadc  push rdi
00007b629addaadd  push rsi
00007b629addaade  push r8
00007b629addaae0  push r9
00007b629addaae2  push r10
00007b629addaae4  push r11
00007b629addaae6  sub rsp, 0xF0
00007b629addaaed  vmovaps [rsp], xmm0
00007b629addaaf2  vmovaps [rsp+0x10], xmm1
00007b629addaaf8  vmovaps [rsp+0x20], xmm2
00007b629addaafe  vmovaps [rsp+0x30], xmm3
00007b629addab04  vmovaps [rsp+0x40], xmm4
00007b629addab0a  vmovaps [rsp+0x50], xmm5
00007b629addab10  vmovaps [rsp+0x60], xmm6
00007b629addab16  vmovaps [rsp+0x70], xmm7
00007b629addab1c  vmovaps [rsp+0x80], xmm8
00007b629addab25  vmovaps [rsp+0x90], xmm9
00007b629addab2e  vmovaps [rsp+0xA0], xmm11
00007b629addab37  vmovaps [rsp+0xB0], xmm12
00007b629addab40  vmovaps [rsp+0xC0], xmm13
00007b629addab49  vmovaps [rsp+0xD0], xmm14
00007b629addab52  vmovaps [rsp+0xE0], xmm15
00007b629addab5b  sub rsp, 0x30
00007b629addab5f  movaps [rsp], xmm10
00007b629addab64  movaps [rsp+0x10], xmm1
00007b629addab69  movaps [rsp+0x20], xmm12
00007b629addab6f  lea rdi, [rsp]
00007b629addab73  mov esi, 0x00
00007b629addab78  mov rax, 0x583FED93F530
00007b629addab82  call rax
00007b629addab84  movaps xmm10, [rsp]
00007b629addab89  add rsp, 0x30
00007b629addab8d  vmovaps xmm0, [rsp]
00007b629addab92  vmovaps xmm1, [rsp+0x10]
00007b629addab98  vmovaps xmm2, [rsp+0x20]
00007b629addab9e  vmovaps xmm3, [rsp+0x30]
00007b629addaba4  vmovaps xmm4, [rsp+0x40]
00007b629addabaa  vmovaps xmm5, [rsp+0x50]
00007b629addabb0  vmovaps xmm6, [rsp+0x60]
00007b629addabb6  vmovaps xmm7, [rsp+0x70]
00007b629addabbc  vmovaps xmm8, [rsp+0x80]
00007b629addabc5  vmovaps xmm9, [rsp+0x90]
00007b629addabce  vmovaps xmm11, [rsp+0xA0]
00007b629addabd7  vmovaps xmm12, [rsp+0xB0]
00007b629addabe0  vmovaps xmm13, [rsp+0xC0]
00007b629addabe9  vmovaps xmm14, [rsp+0xD0]
00007b629addabf2  vmovaps xmm15, [rsp+0xE0]
00007b629addabfb  add rsp, 0xF0
00007b629addac02  pop r11
00007b629addac04  pop r10
00007b629addac06  pop r9
00007b629addac08  pop r8
00007b629addac0a  pop rsi
00007b629addac0b  pop rdi
00007b629addac0c  pop rdx
00007b629addac0d  pop rcx
00007b629addac0e  pop rax
00007b629addac0f  add rsp, 0x08
00007b629addac13  jmp 0x00007B629ADD651A
00007b629addac18  sub rsp, 0x08
00007b629addac1c  push rax
00007b629addac1d  push rcx
00007b629addac1e  push rdx
00007b629addac1f  push rdi
00007b629addac20  push rsi
00007b629addac21  push r8
00007b629addac23  push r9
00007b629addac25  push r10
00007b629addac27  push r11
00007b629addac29  sub rsp, 0xF0
00007b629addac30  vmovaps [rsp], xmm0
00007b629addac35  vmovaps [rsp+0x10], xmm1
00007b629addac3b  vmovaps [rsp+0x20], xmm2
00007b629addac41  vmovaps [rsp+0x30], xmm3
00007b629addac47  vmovaps [rsp+0x40], xmm4
00007b629addac4d  vmovaps [rsp+0x50], xmm5
00007b629addac53  vmovaps [rsp+0x60], xmm6
00007b629addac59  vmovaps [rsp+0x70], xmm7
00007b629addac5f  vmovaps [rsp+0x80], xmm8
00007b629addac68  vmovaps [rsp+0x90], xmm9
00007b629addac71  vmovaps [rsp+0xA0], xmm10
00007b629addac7a  vmovaps [rsp+0xB0], xmm11
00007b629addac83  vmovaps [rsp+0xC0], xmm13
00007b629addac8c  vmovaps [rsp+0xD0], xmm14
00007b629addac95  vmovaps [rsp+0xE0], xmm15
00007b629addac9e  sub rsp, 0x30
00007b629addaca2  movaps [rsp], xmm12
00007b629addaca7  movaps [rsp+0x10], xmm14
00007b629addacad  movaps [rsp+0x20], xmm1
00007b629addacb2  lea rdi, [rsp]
00007b629addacb6  mov esi, 0x00
00007b629addacbb  mov rax, 0x583FED93F530
00007b629addacc5  call rax
00007b629addacc7  movaps xmm12, [rsp]
00007b629addaccc  add rsp, 0x30
00007b629addacd0  vmovaps xmm0, [rsp]
00007b629addacd5  vmovaps xmm1, [rsp+0x10]
00007b629addacdb  vmovaps xmm2, [rsp+0x20]
00007b629addace1  vmovaps xmm3, [rsp+0x30]
00007b629addace7  vmovaps xmm4, [rsp+0x40]
00007b629addaced  vmovaps xmm5, [rsp+0x50]
00007b629addacf3  vmovaps xmm6, [rsp+0x60]
00007b629addacf9  vmovaps xmm7, [rsp+0x70]
00007b629addacff  vmovaps xmm8, [rsp+0x80]
00007b629addad08  vmovaps xmm9, [rsp+0x90]
00007b629addad11  vmovaps xmm10, [rsp+0xA0]
00007b629addad1a  vmovaps xmm11, [rsp+0xB0]
00007b629addad23  vmovaps xmm13, [rsp+0xC0]
00007b629addad2c  vmovaps xmm14, [rsp+0xD0]
00007b629addad35  vmovaps xmm15, [rsp+0xE0]
00007b629addad3e  add rsp, 0xF0
00007b629addad45  pop r11
00007b629addad47  pop r10
00007b629addad49  pop r9
00007b629addad4b  pop r8
00007b629addad4d  pop rsi
00007b629addad4e  pop rdi
00007b629addad4f  pop rdx
00007b629addad50  pop rcx
00007b629addad51  pop rax
00007b629addad52  add rsp, 0x08
00007b629addad56  jmp 0x00007B629ADD6549
00007b629addad5b  sub rsp, 0x08
00007b629addad5f  push rax
00007b629addad60  push rcx
00007b629addad61  push rdx
00007b629addad62  push rdi
00007b629addad63  push rsi
00007b629addad64  push r8
00007b629addad66  push r9
00007b629addad68  push r10
00007b629addad6a  push r11
00007b629addad6c  sub rsp, 0xF0
00007b629addad73  vmovaps [rsp], xmm0
00007b629addad78  vmovaps [rsp+0x10], xmm1
00007b629addad7e  vmovaps [rsp+0x20], xmm2
00007b629addad84  vmovaps [rsp+0x30], xmm3
00007b629addad8a  vmovaps [rsp+0x40], xmm4
00007b629addad90  vmovaps [rsp+0x50], xmm5
00007b629addad96  vmovaps [rsp+0x60], xmm6
00007b629addad9c  vmovaps [rsp+0x70], xmm7
00007b629addada2  vmovaps [rsp+0x80], xmm8
00007b629addadab  vmovaps [rsp+0x90], xmm9
00007b629addadb4  vmovaps [rsp+0xA0], xmm10
00007b629addadbd  vmovaps [rsp+0xB0], xmm11
00007b629addadc6  vmovaps [rsp+0xC0], xmm12
00007b629addadcf  vmovaps [rsp+0xD0], xmm13
00007b629addadd8  vmovaps [rsp+0xE0], xmm15
00007b629addade1  sub rsp, 0x30
00007b629addade5  movaps [rsp], xmm14
00007b629addadea  movaps [rsp+0x10], xmm9
00007b629addadf0  movaps [rsp+0x20], xmm1
00007b629addadf5  lea rdi, [rsp]
00007b629addadf9  mov esi, 0x00
00007b629addadfe  mov rax, 0x583FED93F530
00007b629addae08  call rax
00007b629addae0a  movaps xmm14, [rsp]
00007b629addae0f  add rsp, 0x30
00007b629addae13  vmovaps xmm0, [rsp]
00007b629addae18  vmovaps xmm1, [rsp+0x10]
00007b629addae1e  vmovaps xmm2, [rsp+0x20]
00007b629addae24  vmovaps xmm3, [rsp+0x30]
00007b629addae2a  vmovaps xmm4, [rsp+0x40]
00007b629addae30  vmovaps xmm5, [rsp+0x50]
00007b629addae36  vmovaps xmm6, [rsp+0x60]
00007b629addae3c  vmovaps xmm7, [rsp+0x70]
00007b629addae42  vmovaps xmm8, [rsp+0x80]
00007b629addae4b  vmovaps xmm9, [rsp+0x90]
00007b629addae54  vmovaps xmm10, [rsp+0xA0]
00007b629addae5d  vmovaps xmm11, [rsp+0xB0]
00007b629addae66  vmovaps xmm12, [rsp+0xC0]
00007b629addae6f  vmovaps xmm13, [rsp+0xD0]
00007b629addae78  vmovaps xmm15, [rsp+0xE0]
00007b629addae81  add rsp, 0xF0
00007b629addae88  pop r11
00007b629addae8a  pop r10
00007b629addae8c  pop r9
00007b629addae8e  pop r8
00007b629addae90  pop rsi
00007b629addae91  pop rdi
00007b629addae92  pop rdx
00007b629addae93  pop rcx
00007b629addae94  pop rax
00007b629addae95  add rsp, 0x08
00007b629addae99  jmp 0x00007B629ADD6578
00007b629addae9e  sub rsp, 0x08
00007b629addaea2  push rax
00007b629addaea3  push rcx
00007b629addaea4  push rdx
00007b629addaea5  push rdi
00007b629addaea6  push rsi
00007b629addaea7  push r8
00007b629addaea9  push r9
00007b629addaeab  push r10
00007b629addaead  push r11
00007b629addaeaf  sub rsp, 0xF0
00007b629addaeb6  vmovaps [rsp], xmm0
00007b629addaebb  vmovaps [rsp+0x10], xmm2
00007b629addaec1  vmovaps [rsp+0x20], xmm3
00007b629addaec7  vmovaps [rsp+0x30], xmm4
00007b629addaecd  vmovaps [rsp+0x40], xmm5
00007b629addaed3  vmovaps [rsp+0x50], xmm6
00007b629addaed9  vmovaps [rsp+0x60], xmm7
00007b629addaedf  vmovaps [rsp+0x70], xmm8
00007b629addaee5  vmovaps [rsp+0x80], xmm9
00007b629addaeee  vmovaps [rsp+0x90], xmm10
00007b629addaef7  vmovaps [rsp+0xA0], xmm11
00007b629addaf00  vmovaps [rsp+0xB0], xmm12
00007b629addaf09  vmovaps [rsp+0xC0], xmm13
00007b629addaf12  vmovaps [rsp+0xD0], xmm14
00007b629addaf1b  vmovaps [rsp+0xE0], xmm15
00007b629addaf24  sub rsp, 0x30
00007b629addaf28  movaps [rsp], xmm1
00007b629addaf2c  movaps [rsp+0x10], xmm13
00007b629addaf32  movaps [rsp+0x20], xmm8
00007b629addaf38  lea rdi, [rsp]
00007b629addaf3c  mov esi, 0x00
00007b629addaf41  mov rax, 0x583FED93F530
00007b629addaf4b  call rax
00007b629addaf4d  movaps xmm1, [rsp]
00007b629addaf51  add rsp, 0x30
00007b629addaf55  vmovaps xmm0, [rsp]
00007b629addaf5a  vmovaps xmm2, [rsp+0x10]
00007b629addaf60  vmovaps xmm3, [rsp+0x20]
00007b629addaf66  vmovaps xmm4, [rsp+0x30]
00007b629addaf6c  vmovaps xmm5, [rsp+0x40]
00007b629addaf72  vmovaps xmm6, [rsp+0x50]
00007b629addaf78  vmovaps xmm7, [rsp+0x60]
00007b629addaf7e  vmovaps xmm8, [rsp+0x70]
00007b629addaf84  vmovaps xmm9, [rsp+0x80]
00007b629addaf8d  vmovaps xmm10, [rsp+0x90]
00007b629addaf96  vmovaps xmm11, [rsp+0xA0]
00007b629addaf9f  vmovaps xmm12, [rsp+0xB0]
00007b629addafa8  vmovaps xmm13, [rsp+0xC0]
00007b629addafb1  vmovaps xmm14, [rsp+0xD0]
00007b629addafba  vmovaps xmm15, [rsp+0xE0]
00007b629addafc3  add rsp, 0xF0
00007b629addafca  pop r11
00007b629addafcc  pop r10
00007b629addafce  pop r9
00007b629addafd0  pop r8
00007b629addafd2  pop rsi
00007b629addafd3  pop rdi
00007b629addafd4  pop rdx
00007b629addafd5  pop rcx
00007b629addafd6  pop rax
00007b629addafd7  add rsp, 0x08
00007b629addafdb  jmp 0x00007B629ADD659A
00007b629addafe0  call 0x00007B629AC0C260
00007b629addafe5  jmp 0x00007B629ADD65A8
00007b629addafea  call 0x00007B629ACDE950
00007b629addafef  jmp 0x00007B629ADD65B2
00007b629addaff4  sub rsp, 0x08
00007b629addaff8  push rax
00007b629addaff9  push rcx
00007b629addaffa  push rdx
00007b629addaffb  push rdi
00007b629addaffc  push rsi
00007b629addaffd  push r8
00007b629addafff  push r9
00007b629addb001  push r10
00007b629addb003  push r11
00007b629addb005  sub rsp, 0xF0
00007b629addb00c  vmovaps [rsp], xmm0
00007b629addb011  vmovaps [rsp+0x10], xmm1
00007b629addb017  vmovaps [rsp+0x20], xmm2
00007b629addb01d  vmovaps [rsp+0x30], xmm3
00007b629addb023  vmovaps [rsp+0x40], xmm4
00007b629addb029  vmovaps [rsp+0x50], xmm5
00007b629addb02f  vmovaps [rsp+0x60], xmm6
00007b629addb035  vmovaps [rsp+0x70], xmm7
00007b629addb03b  vmovaps [rsp+0x80], xmm9
00007b629addb044  vmovaps [rsp+0x90], xmm10
00007b629addb04d  vmovaps [rsp+0xA0], xmm11
00007b629addb056  vmovaps [rsp+0xB0], xmm12
00007b629addb05f  vmovaps [rsp+0xC0], xmm13
00007b629addb068  vmovaps [rsp+0xD0], xmm14
00007b629addb071  vmovaps [rsp+0xE0], xmm15
00007b629addb07a  sub rsp, 0x30
00007b629addb07e  movaps [rsp], xmm8
00007b629addb083  movaps [rsp+0x10], xmm15
00007b629addb089  movaps [rsp+0x20], xmm7
00007b629addb08e  lea rdi, [rsp]
00007b629addb092  mov esi, 0x00
00007b629addb097  mov rax, 0x583FED93F530
00007b629addb0a1  call rax
00007b629addb0a3  movaps xmm8, [rsp]
00007b629addb0a8  add rsp, 0x30
00007b629addb0ac  vmovaps xmm0, [rsp]
00007b629addb0b1  vmovaps xmm1, [rsp+0x10]
00007b629addb0b7  vmovaps xmm2, [rsp+0x20]
00007b629addb0bd  vmovaps xmm3, [rsp+0x30]
00007b629addb0c3  vmovaps xmm4, [rsp+0x40]
00007b629addb0c9  vmovaps xmm5, [rsp+0x50]
00007b629addb0cf  vmovaps xmm6, [rsp+0x60]
00007b629addb0d5  vmovaps xmm7, [rsp+0x70]
00007b629addb0db  vmovaps xmm9, [rsp+0x80]
00007b629addb0e4  vmovaps xmm10, [rsp+0x90]
00007b629addb0ed  vmovaps xmm11, [rsp+0xA0]
00007b629addb0f6  vmovaps xmm12, [rsp+0xB0]
00007b629addb0ff  vmovaps xmm13, [rsp+0xC0]
00007b629addb108  vmovaps xmm14, [rsp+0xD0]
00007b629addb111  vmovaps xmm15, [rsp+0xE0]
00007b629addb11a  add rsp, 0xF0
00007b629addb121  pop r11
00007b629addb123  pop r10
00007b629addb125  pop r9
00007b629addb127  pop r8
00007b629addb129  pop rsi
00007b629addb12a  pop rdi
00007b629addb12b  pop rdx
00007b629addb12c  pop rcx
00007b629addb12d  pop rax
00007b629addb12e  add rsp, 0x08
00007b629addb132  jmp 0x00007B629ADD65D4
00007b629addb137  sub rsp, 0x08
00007b629addb13b  push rax
00007b629addb13c  push rcx
00007b629addb13d  push rdx
00007b629addb13e  push rdi
00007b629addb13f  push rsi
00007b629addb140  push r8
00007b629addb142  push r9
00007b629addb144  push r10
00007b629addb146  push r11
00007b629addb148  sub rsp, 0xF0
00007b629addb14f  vmovaps [rsp], xmm0
00007b629addb154  vmovaps [rsp+0x10], xmm1
00007b629addb15a  vmovaps [rsp+0x20], xmm2
00007b629addb160  vmovaps [rsp+0x30], xmm3
00007b629addb166  vmovaps [rsp+0x40], xmm4
00007b629addb16c  vmovaps [rsp+0x50], xmm5
00007b629addb172  vmovaps [rsp+0x60], xmm6
00007b629addb178  vmovaps [rsp+0x70], xmm8
00007b629addb17e  vmovaps [rsp+0x80], xmm9
00007b629addb187  vmovaps [rsp+0x90], xmm10
00007b629addb190  vmovaps [rsp+0xA0], xmm11
00007b629addb199  vmovaps [rsp+0xB0], xmm12
00007b629addb1a2  vmovaps [rsp+0xC0], xmm13
00007b629addb1ab  vmovaps [rsp+0xD0], xmm14
00007b629addb1b4  vmovaps [rsp+0xE0], xmm15
00007b629addb1bd  sub rsp, 0x30
00007b629addb1c1  movaps [rsp], xmm7
00007b629addb1c5  movaps [rsp+0x10], xmm9
00007b629addb1cb  movaps [rsp+0x20], xmm15
00007b629addb1d1  lea rdi, [rsp]
00007b629addb1d5  mov esi, 0x00
00007b629addb1da  mov rax, 0x583FED93F530
00007b629addb1e4  call rax
00007b629addb1e6  movaps xmm7, [rsp]
00007b629addb1ea  add rsp, 0x30
00007b629addb1ee  vmovaps xmm0, [rsp]
00007b629addb1f3  vmovaps xmm1, [rsp+0x10]
00007b629addb1f9  vmovaps xmm2, [rsp+0x20]
00007b629addb1ff  vmovaps xmm3, [rsp+0x30]
00007b629addb205  vmovaps xmm4, [rsp+0x40]
00007b629addb20b  vmovaps xmm5, [rsp+0x50]
00007b629addb211  vmovaps xmm6, [rsp+0x60]
00007b629addb217  vmovaps xmm8, [rsp+0x70]
00007b629addb21d  vmovaps xmm9, [rsp+0x80]
00007b629addb226  vmovaps xmm10, [rsp+0x90]
00007b629addb22f  vmovaps xmm11, [rsp+0xA0]
00007b629addb238  vmovaps xmm12, [rsp+0xB0]
00007b629addb241  vmovaps xmm13, [rsp+0xC0]
00007b629addb24a  vmovaps xmm14, [rsp+0xD0]
00007b629addb253  vmovaps xmm15, [rsp+0xE0]
00007b629addb25c  add rsp, 0xF0
00007b629addb263  pop r11
00007b629addb265  pop r10
00007b629addb267  pop r9
00007b629addb269  pop r8
00007b629addb26b  pop rsi
00007b629addb26c  pop rdi
00007b629addb26d  pop rdx
00007b629addb26e  pop rcx
00007b629addb26f  pop rax
00007b629addb270  add rsp, 0x08
00007b629addb274  jmp 0x00007B629ADD6601
00007b629addb279  sub rsp, 0x08
00007b629addb27d  push rax
00007b629addb27e  push rcx
00007b629addb27f  push rdx
00007b629addb280  push rdi
00007b629addb281  push rsi
00007b629addb282  push r8
00007b629addb284  push r9
00007b629addb286  push r10
00007b629addb288  push r11
00007b629addb28a  sub rsp, 0xF0
00007b629addb291  vmovaps [rsp], xmm0
00007b629addb296  vmovaps [rsp+0x10], xmm1
00007b629addb29c  vmovaps [rsp+0x20], xmm2
00007b629addb2a2  vmovaps [rsp+0x30], xmm3
00007b629addb2a8  vmovaps [rsp+0x40], xmm4
00007b629addb2ae  vmovaps [rsp+0x50], xmm5
00007b629addb2b4  vmovaps [rsp+0x60], xmm6
00007b629addb2ba  vmovaps [rsp+0x70], xmm7
00007b629addb2c0  vmovaps [rsp+0x80], xmm8
00007b629addb2c9  vmovaps [rsp+0x90], xmm10
00007b629addb2d2  vmovaps [rsp+0xA0], xmm11
00007b629addb2db  vmovaps [rsp+0xB0], xmm12
00007b629addb2e4  vmovaps [rsp+0xC0], xmm13
00007b629addb2ed  vmovaps [rsp+0xD0], xmm14
00007b629addb2f6  vmovaps [rsp+0xE0], xmm15
00007b629addb2ff  sub rsp, 0x30
00007b629addb303  movaps [rsp], xmm9
00007b629addb308  movaps [rsp+0x10], xmm13
00007b629addb30e  movaps [rsp+0x20], xmm15
00007b629addb314  lea rdi, [rsp]
00007b629addb318  mov esi, 0x00
00007b629addb31d  mov rax, 0x583FED93F530
00007b629addb327  call rax
00007b629addb329  movaps xmm9, [rsp]
00007b629addb32e  add rsp, 0x30
00007b629addb332  vmovaps xmm0, [rsp]
00007b629addb337  vmovaps xmm1, [rsp+0x10]
00007b629addb33d  vmovaps xmm2, [rsp+0x20]
00007b629addb343  vmovaps xmm3, [rsp+0x30]
00007b629addb349  vmovaps xmm4, [rsp+0x40]
00007b629addb34f  vmovaps xmm5, [rsp+0x50]
00007b629addb355  vmovaps xmm6, [rsp+0x60]
00007b629addb35b  vmovaps xmm7, [rsp+0x70]
00007b629addb361  vmovaps xmm8, [rsp+0x80]
00007b629addb36a  vmovaps xmm10, [rsp+0x90]
00007b629addb373  vmovaps xmm11, [rsp+0xA0]
00007b629addb37c  vmovaps xmm12, [rsp+0xB0]
00007b629addb385  vmovaps xmm13, [rsp+0xC0]
00007b629addb38e  vmovaps xmm14, [rsp+0xD0]
00007b629addb397  vmovaps xmm15, [rsp+0xE0]
00007b629addb3a0  add rsp, 0xF0
00007b629addb3a7  pop r11
00007b629addb3a9  pop r10
00007b629addb3ab  pop r9
00007b629addb3ad  pop r8
00007b629addb3af  pop rsi
00007b629addb3b0  pop rdi
00007b629addb3b1  pop rdx
00007b629addb3b2  pop rcx
00007b629addb3b3  pop rax
00007b629addb3b4  add rsp, 0x08
00007b629addb3b8  jmp 0x00007B629ADD662F
00007b629addb3bd  sub rsp, 0x08
00007b629addb3c1  push rax
00007b629addb3c2  push rcx
00007b629addb3c3  push rdx
00007b629addb3c4  push rdi
00007b629addb3c5  push rsi
00007b629addb3c6  push r8
00007b629addb3c8  push r9
00007b629addb3ca  push r10
00007b629addb3cc  push r11
00007b629addb3ce  sub rsp, 0xF0
00007b629addb3d5  vmovaps [rsp], xmm0
00007b629addb3da  vmovaps [rsp+0x10], xmm1
00007b629addb3e0  vmovaps [rsp+0x20], xmm2
00007b629addb3e6  vmovaps [rsp+0x30], xmm3
00007b629addb3ec  vmovaps [rsp+0x40], xmm4
00007b629addb3f2  vmovaps [rsp+0x50], xmm5
00007b629addb3f8  vmovaps [rsp+0x60], xmm6
00007b629addb3fe  vmovaps [rsp+0x70], xmm7
00007b629addb404  vmovaps [rsp+0x80], xmm8
00007b629addb40d  vmovaps [rsp+0x90], xmm9
00007b629addb416  vmovaps [rsp+0xA0], xmm10
00007b629addb41f  vmovaps [rsp+0xB0], xmm11
00007b629addb428  vmovaps [rsp+0xC0], xmm12
00007b629addb431  vmovaps [rsp+0xD0], xmm13
00007b629addb43a  vmovaps [rsp+0xE0], xmm14
00007b629addb443  sub rsp, 0x30
00007b629addb447  movaps [rsp], xmm15
00007b629addb44c  movaps [rsp+0x10], xmm11
00007b629addb452  movaps [rsp+0x20], xmm12
00007b629addb458  lea rdi, [rsp]
00007b629addb45c  mov esi, 0x00
00007b629addb461  mov rax, 0x583FED93F530
00007b629addb46b  call rax
00007b629addb46d  movaps xmm15, [rsp]
00007b629addb472  add rsp, 0x30
00007b629addb476  vmovaps xmm0, [rsp]
00007b629addb47b  vmovaps xmm1, [rsp+0x10]
00007b629addb481  vmovaps xmm2, [rsp+0x20]
00007b629addb487  vmovaps xmm3, [rsp+0x30]
00007b629addb48d  vmovaps xmm4, [rsp+0x40]
00007b629addb493  vmovaps xmm5, [rsp+0x50]
00007b629addb499  vmovaps xmm6, [rsp+0x60]
00007b629addb49f  vmovaps xmm7, [rsp+0x70]
00007b629addb4a5  vmovaps xmm8, [rsp+0x80]
00007b629addb4ae  vmovaps xmm9, [rsp+0x90]
00007b629addb4b7  vmovaps xmm10, [rsp+0xA0]
00007b629addb4c0  vmovaps xmm11, [rsp+0xB0]
00007b629addb4c9  vmovaps xmm12, [rsp+0xC0]
00007b629addb4d2  vmovaps xmm13, [rsp+0xD0]
00007b629addb4db  vmovaps xmm14, [rsp+0xE0]
00007b629addb4e4  add rsp, 0xF0
00007b629addb4eb  pop r11
00007b629addb4ed  pop r10
00007b629addb4ef  pop r9
00007b629addb4f1  pop r8
00007b629addb4f3  pop rsi
00007b629addb4f4  pop rdi
00007b629addb4f5  pop rdx
00007b629addb4f6  pop rcx
00007b629addb4f7  pop rax
00007b629addb4f8  add rsp, 0x08
00007b629addb4fc  jmp 0x00007B629ADD664A
00007b629addb501  sub rsp, 0x08
00007b629addb505  push rax
00007b629addb506  push rcx
00007b629addb507  push rdx
00007b629addb508  push rdi
00007b629addb509  push rsi
00007b629addb50a  push r8
00007b629addb50c  push r9
00007b629addb50e  push r10
00007b629addb510  push r11
00007b629addb512  sub rsp, 0xF0
00007b629addb519  vmovaps [rsp], xmm0
00007b629addb51e  vmovaps [rsp+0x10], xmm1
00007b629addb524  vmovaps [rsp+0x20], xmm2
00007b629addb52a  vmovaps [rsp+0x30], xmm3
00007b629addb530  vmovaps [rsp+0x40], xmm4
00007b629addb536  vmovaps [rsp+0x50], xmm5
00007b629addb53c  vmovaps [rsp+0x60], xmm6
00007b629addb542  vmovaps [rsp+0x70], xmm7
00007b629addb548  vmovaps [rsp+0x80], xmm8
00007b629addb551  vmovaps [rsp+0x90], xmm9
00007b629addb55a  vmovaps [rsp+0xA0], xmm10
00007b629addb563  vmovaps [rsp+0xB0], xmm11
00007b629addb56c  vmovaps [rsp+0xC0], xmm12
00007b629addb575  vmovaps [rsp+0xD0], xmm14
00007b629addb57e  vmovaps [rsp+0xE0], xmm15
00007b629addb587  sub rsp, 0x30
00007b629addb58b  movaps [rsp], xmm13
00007b629addb590  movaps [rsp+0x10], xmm10
00007b629addb596  movaps [rsp+0x20], xmm14
00007b629addb59c  lea rdi, [rsp]
00007b629addb5a0  mov esi, 0x00
00007b629addb5a5  mov rax, 0x583FED93F530
00007b629addb5af  call rax
00007b629addb5b1  movaps xmm13, [rsp]
00007b629addb5b6  add rsp, 0x30
00007b629addb5ba  vmovaps xmm0, [rsp]
00007b629addb5bf  vmovaps xmm1, [rsp+0x10]
00007b629addb5c5  vmovaps xmm2, [rsp+0x20]
00007b629addb5cb  vmovaps xmm3, [rsp+0x30]
00007b629addb5d1  vmovaps xmm4, [rsp+0x40]
00007b629addb5d7  vmovaps xmm5, [rsp+0x50]
00007b629addb5dd  vmovaps xmm6, [rsp+0x60]
00007b629addb5e3  vmovaps xmm7, [rsp+0x70]
00007b629addb5e9  vmovaps xmm8, [rsp+0x80]
00007b629addb5f2  vmovaps xmm9, [rsp+0x90]
00007b629addb5fb  vmovaps xmm10, [rsp+0xA0]
00007b629addb604  vmovaps xmm11, [rsp+0xB0]
00007b629addb60d  vmovaps xmm12, [rsp+0xC0]
00007b629addb616  vmovaps xmm14, [rsp+0xD0]
00007b629addb61f  vmovaps xmm15, [rsp+0xE0]
00007b629addb628  add rsp, 0xF0
00007b629addb62f  pop r11
00007b629addb631  pop r10
00007b629addb633  pop r9
00007b629addb635  pop r8
00007b629addb637  pop rsi
00007b629addb638  pop rdi
00007b629addb639  pop rdx
00007b629addb63a  pop rcx
00007b629addb63b  pop rax
00007b629addb63c  add rsp, 0x08
00007b629addb640  jmp 0x00007B629ADD666D
00007b629addb645  sub rsp, 0x08
00007b629addb649  push rax
00007b629addb64a  push rcx
00007b629addb64b  push rdx
00007b629addb64c  push rdi
00007b629addb64d  push rsi
00007b629addb64e  push r8
00007b629addb650  push r9
00007b629addb652  push r10
00007b629addb654  push r11
00007b629addb656  sub rsp, 0xF0
00007b629addb65d  vmovaps [rsp], xmm0
00007b629addb662  vmovaps [rsp+0x10], xmm1
00007b629addb668  vmovaps [rsp+0x20], xmm2
00007b629addb66e  vmovaps [rsp+0x30], xmm3
00007b629addb674  vmovaps [rsp+0x40], xmm4
00007b629addb67a  vmovaps [rsp+0x50], xmm5
00007b629addb680  vmovaps [rsp+0x60], xmm6
00007b629addb686  vmovaps [rsp+0x70], xmm7
00007b629addb68c  vmovaps [rsp+0x80], xmm8
00007b629addb695  vmovaps [rsp+0x90], xmm9
00007b629addb69e  vmovaps [rsp+0xA0], xmm10
00007b629addb6a7  vmovaps [rsp+0xB0], xmm11
00007b629addb6b0  vmovaps [rsp+0xC0], xmm12
00007b629addb6b9  vmovaps [rsp+0xD0], xmm13
00007b629addb6c2  vmovaps [rsp+0xE0], xmm15
00007b629addb6cb  sub rsp, 0x30
00007b629addb6cf  movaps [rsp], xmm14
00007b629addb6d4  movaps [rsp+0x10], xmm1
00007b629addb6d9  movaps [rsp+0x20], xmm7
00007b629addb6de  lea rdi, [rsp]
00007b629addb6e2  mov esi, 0x00
00007b629addb6e7  mov rax, 0x583FED93F530
00007b629addb6f1  call rax
00007b629addb6f3  movaps xmm14, [rsp]
00007b629addb6f8  add rsp, 0x30
00007b629addb6fc  vmovaps xmm0, [rsp]
00007b629addb701  vmovaps xmm1, [rsp+0x10]
00007b629addb707  vmovaps xmm2, [rsp+0x20]
00007b629addb70d  vmovaps xmm3, [rsp+0x30]
00007b629addb713  vmovaps xmm4, [rsp+0x40]
00007b629addb719  vmovaps xmm5, [rsp+0x50]
00007b629addb71f  vmovaps xmm6, [rsp+0x60]
00007b629addb725  vmovaps xmm7, [rsp+0x70]
00007b629addb72b  vmovaps xmm8, [rsp+0x80]
00007b629addb734  vmovaps xmm9, [rsp+0x90]
00007b629addb73d  vmovaps xmm10, [rsp+0xA0]
00007b629addb746  vmovaps xmm11, [rsp+0xB0]
00007b629addb74f  vmovaps xmm12, [rsp+0xC0]
00007b629addb758  vmovaps xmm13, [rsp+0xD0]
00007b629addb761  vmovaps xmm15, [rsp+0xE0]
00007b629addb76a  add rsp, 0xF0
00007b629addb771  pop r11
00007b629addb773  pop r10
00007b629addb775  pop r9
00007b629addb777  pop r8
00007b629addb779  pop rsi
00007b629addb77a  pop rdi
00007b629addb77b  pop rdx
00007b629addb77c  pop rcx
00007b629addb77d  pop rax
00007b629addb77e  add rsp, 0x08
00007b629addb782  jmp 0x00007B629ADD6690
00007b629addb787  sub rsp, 0x08
00007b629addb78b  push rax
00007b629addb78c  push rcx
00007b629addb78d  push rdx
00007b629addb78e  push rdi
00007b629addb78f  push rsi
00007b629addb790  push r8
00007b629addb792  push r9
00007b629addb794  push r10
00007b629addb796  push r11
00007b629addb798  sub rsp, 0xF0
00007b629addb79f  vmovaps [rsp], xmm0
00007b629addb7a4  vmovaps [rsp+0x10], xmm2
00007b629addb7aa  vmovaps [rsp+0x20], xmm3
00007b629addb7b0  vmovaps [rsp+0x30], xmm4
00007b629addb7b6  vmovaps [rsp+0x40], xmm5
00007b629addb7bc  vmovaps [rsp+0x50], xmm6
00007b629addb7c2  vmovaps [rsp+0x60], xmm7
00007b629addb7c8  vmovaps [rsp+0x70], xmm8
00007b629addb7ce  vmovaps [rsp+0x80], xmm9
00007b629addb7d7  vmovaps [rsp+0x90], xmm10
00007b629addb7e0  vmovaps [rsp+0xA0], xmm11
00007b629addb7e9  vmovaps [rsp+0xB0], xmm12
00007b629addb7f2  vmovaps [rsp+0xC0], xmm13
00007b629addb7fb  vmovaps [rsp+0xD0], xmm14
00007b629addb804  vmovaps [rsp+0xE0], xmm15
00007b629addb80d  sub rsp, 0x30
00007b629addb811  movaps [rsp], xmm1
00007b629addb815  movaps [rsp+0x10], xmm8
00007b629addb81b  movaps [rsp+0x20], xmm9
00007b629addb821  lea rdi, [rsp]
00007b629addb825  mov esi, 0x00
00007b629addb82a  mov rax, 0x583FED93F530
00007b629addb834  call rax
00007b629addb836  movaps xmm1, [rsp]
00007b629addb83a  add rsp, 0x30
00007b629addb83e  vmovaps xmm0, [rsp]
00007b629addb843  vmovaps xmm2, [rsp+0x10]
00007b629addb849  vmovaps xmm3, [rsp+0x20]
00007b629addb84f  vmovaps xmm4, [rsp+0x30]
00007b629addb855  vmovaps xmm5, [rsp+0x40]
00007b629addb85b  vmovaps xmm6, [rsp+0x50]
00007b629addb861  vmovaps xmm7, [rsp+0x60]
00007b629addb867  vmovaps xmm8, [rsp+0x70]
00007b629addb86d  vmovaps xmm9, [rsp+0x80]
00007b629addb876  vmovaps xmm10, [rsp+0x90]
00007b629addb87f  vmovaps xmm11, [rsp+0xA0]
00007b629addb888  vmovaps xmm12, [rsp+0xB0]
00007b629addb891  vmovaps xmm13, [rsp+0xC0]
00007b629addb89a  vmovaps xmm14, [rsp+0xD0]
00007b629addb8a3  vmovaps xmm15, [rsp+0xE0]
00007b629addb8ac  add rsp, 0xF0
00007b629addb8b3  pop r11
00007b629addb8b5  pop r10
00007b629addb8b7  pop r9
00007b629addb8b9  pop r8
00007b629addb8bb  pop rsi
00007b629addb8bc  pop rdi
00007b629addb8bd  pop rdx
00007b629addb8be  pop rcx
00007b629addb8bf  pop rax
00007b629addb8c0  add rsp, 0x08
00007b629addb8c4  jmp 0x00007B629ADD66B2
00007b629addb8c9  call 0x00007B629ACB3E40
00007b629addb8ce  jmp 0x00007B629ADD66C0
00007b629addb8d3  call 0x00007B629AC0C380
00007b629addb8d8  jmp 0x00007B629ADD66CA
00007b629addb8dd  call 0x00007B629AC0D600
00007b629addb8e2  jmp 0x00007B629ADD66D4
00007b629addb8e7  call 0x00007B629ABFF540
00007b629addb8ec  jmp 0x00007B629ADD66DE
00007b629addb8f1  int3
00007b629addb8f2  nop [rax+rax*1], ax
00007b629addb8fb  nop [rax+rax*1], eax
00007b629addb900  mov eax, [r15+0x48]
00007b629addb904  lea r14d, [eax+0x01]
00007b629addb909  mov [rsp+0x10], r14d
00007b629addb90e  mov r14d, r14d
00007b629addb911  mov [r15+0x48], r14
00007b629addb915  xor eax, eax
00007b629addb917  mov r14d, [rsp+0x10]
00007b629addb91c  cmp r14d, 0x1F4
00007b629addb923  cmc
00007b629addb924  lahf
00007b629addb925  seto al
00007b629addb928  mov [r15+0x108], eax
00007b629addb92f  mov eax, [r15+0x108]
00007b629addb936  sahf
00007b629addb937  jnz 0x00007B629ADDB969
00007b629addb939  cmp dword ptr [r15+0x318], 0x00
00007b629addb941  jz 0x00007B629ADE1AB0
00007b629addb947  nop [rax+rax*1], ax
00007b629addb950  nop [rax+rax*1], eax
00007b629addb958  mov eax, 0x410450
00007b629addb95d  mov [r15+0x100], rax
00007b629addb964  jmp 0x00007B629ABFE110
00007b629addb969  cmp dword ptr [r15+0x318], 0x00
00007b629addb971  jz 0x00007B629ADDB9A0
00007b629addb977  nop [rax+rax*1], ax
00007b629addb980  nop [rax+rax*1], eax
00007b629addb988  mov eax, 0x410274
00007b629addb98d  mov [r15+0x100], rax
00007b629addb994  jmp 0x00007B629ABFE110
00007b629addb999  int3
00007b629addb99a  int3
00007b629addb99b  nop [rax+rax*1], eax
00007b629addb9a0  mov rax, [r15+0x40]
00007b629addb9a4  movaps xmm1, [r15+0x1D0]
00007b629addb9ac  vmovaps [rsp+0x10], xmm1
00007b629addb9b2  vmovaps xmm15, [rsp+0x10]
00007b629addb9b8  por xmm1, xmm15
00007b629addb9bd  movaps xmm14, [r15+0x1A0]
00007b629addb9c5  vmovaps [rsp+0x10], xmm14
00007b629addb9cb  vmovaps xmm13, [rsp+0x10]
00007b629addb9d1  por xmm14, xmm13
00007b629addb9d6  lea r14, [rax+0x30]
00007b629addb9da  mov r12, [r13+r14*1]
00007b629addb9df  lea r14, [rax+0x38]
00007b629addb9e3  mov r11, [r13+r14*1]
00007b629addb9e8  movq xmm13, r12
00007b629addb9ed  movq xmm12, r11
00007b629addb9f2  movq xmm13, xmm13
00007b629addb9f7  vmovaps [rsp+0x10], xmm13
00007b629addb9fd  movq xmm13, xmm13
00007b629addba02  movaps [r15+0x130], xmm13
00007b629addba0a  movq xmm12, xmm12
00007b629addba0f  vmovaps [rsp+0x20], xmm12
00007b629addba15  movq xmm12, xmm12
00007b629addba1a  movaps [r15+0x280], xmm12
00007b629addba22  movaps xmm13, [r15+0x270]
00007b629addba2a  vmovaps [rsp+0x30], xmm13
00007b629addba30  vmovaps xmm12, [rsp+0x30]
00007b629addba36  por xmm13, xmm12
00007b629addba3b  lea r14, [rax+0x20]
00007b629addba3f  mov r12, [r13+r14*1]
00007b629addba44  lea r14, [rax+0x28]
00007b629addba48  mov r11, [r13+r14*1]
00007b629addba4d  movq xmm12, r12
00007b629addba52  movq xmm11, r11
00007b629addba57  movq xmm12, xmm12
00007b629addba5c  vmovaps [rsp+0x30], xmm12
00007b629addba62  movq xmm12, xmm12
00007b629addba67  movaps [r15+0x150], xmm12
00007b629addba6f  movq xmm11, xmm11
00007b629addba74  vmovaps [rsp+0x40], xmm11
00007b629addba7a  movq xmm11, xmm11
00007b629addba7f  movaps [r15+0x140], xmm11
00007b629addba87  lea r14, [rax+0x10]
00007b629addba8b  mov r12, [r13+r14*1]
00007b629addba90  lea r14, [rax+0x18]
00007b629addba94  mov r11, [r13+r14*1]
00007b629addba99  movq xmm12, r12
00007b629addba9e  movq xmm11, r11
00007b629addbaa3  movq xmm12, xmm12
00007b629addbaa8  vmovaps [rsp+0x50], xmm12
00007b629addbaae  movq xmm12, xmm12
00007b629addbab3  movaps [r15+0x170], xmm12
00007b629addbabb  movq xmm11, xmm11
00007b629addbac0  vmovaps [rsp+0x60], xmm11
00007b629addbac6  movq xmm11, xmm11
00007b629addbacb  movaps [r15+0x160], xmm11
00007b629addbad3  mov r14, [r13+rax*1]
00007b629addbad8  vmovq xmm12, r14
00007b629addbadd  vpbroadcastq xmm12, xmm12
00007b629addbae2  lea r14, [rax+0x08]
00007b629addbae6  mov rax, [r13+r14*1]
00007b629addbaeb  movq xmm11, rax
00007b629addbaf0  movaps [r15+0x230], xmm11
00007b629addbaf8  mov rax, [r15+0xF8]
00007b629addbaff  lea r14, [rax+0x50]
00007b629addbb03  movups xmm11, [r13+r14*1]
00007b629addbb09  lea r14, [rax+0x60]
00007b629addbb0d  movups xmm10, [r13+r14*1]
00007b629addbb13  lea r14, [rax+0x30]
00007b629addbb17  movups xmm9, [r13+r14*1]
00007b629addbb1d  mov r14, [r15+0x50]
00007b629addbb21  mov [r15+0x60], r14
00007b629addbb25  mov qword ptr [r15+0x58], 0x40
00007b629addbb2d  movaps xmm8, xmm12
00007b629addbb31  mulpd xmm8, xmm15
00007b629addbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007b629addbb3c  ptest xmm7, xmm7
00007b629addbb41  jnz 0x00007B629ADDC96A
00007b629addbb47  movq xmm15, qword ptr [r15+0x230]
00007b629addbb50  vmovaps [rsp+0x70], xmm15
00007b629addbb56  vpermilpd xmm15, xmm15, 0x00
00007b629addbb5c  movaps xmm7, xmm9
00007b629addbb60  mulpd xmm7, xmm15
00007b629addbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007b629addbb6a  ptest xmm6, xmm6
00007b629addbb6f  jnz 0x00007B629ADDCAAE
00007b629addbb75  vxorps xmm15, xmm15, xmm15
00007b629addbb7a  vpbroadcastq xmm15, xmm15
00007b629addbb7f  movaps xmm9, xmm12
00007b629addbb83  mulpd xmm9, xmm10
00007b629addbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007b629addbb8e  ptest xmm6, xmm6
00007b629addbb93  jnz 0x00007B629ADDCBF0
00007b629addbb99  movaps xmm10, xmm12
00007b629addbb9d  mulpd xmm10, xmm11
00007b629addbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007b629addbba8  ptest xmm6, xmm6
00007b629addbbad  jnz 0x00007B629ADDCD34
00007b629addbbb3  movaps xmm11, [r15+0x1F0]
00007b629addbbbb  movaps xmm6, xmm12
00007b629addbbbf  mulpd xmm6, xmm11
00007b629addbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007b629addbbc9  ptest xmm5, xmm5
00007b629addbbce  jnz 0x00007B629ADDCE78
00007b629addbbd4  movaps xmm12, [r15+0x2A0]
00007b629addbbdc  vmovaps [rsp+0x80], xmm12
00007b629addbbe5  vmovaps xmm11, [rsp+0x80]
00007b629addbbee  por xmm12, xmm11
00007b629addbbf3  movaps xmm11, [r15+0x250]
00007b629addbbfb  vmovaps [rsp+0x80], xmm11
00007b629addbc04  vmovaps xmm5, [rsp+0x80]
00007b629addbc0d  por xmm11, xmm5
00007b629addbc12  vmovaps xmm4, [rsp+0x70]
00007b629addbc18  vpermilpd xmm4, xmm4, 0x00
00007b629addbc1e  movaps xmm3, xmm5
00007b629addbc21  mulpd xmm3, xmm4
00007b629addbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007b629addbc2a  ptest xmm2, xmm2
00007b629addbc2f  jnz 0x00007B629ADDCFBA
00007b629addbc35  mov [rsp+0x80], rax
00007b629addbc3d  xor eax, eax
00007b629addbc3f  mov r12d, 0x40
00007b629addbc45  mov r11d, 0x200
00007b629addbc4b  cmp r12, r11
00007b629addbc4e  cmc
00007b629addbc4f  lahf
00007b629addbc50  seto al
00007b629addbc53  mov [r15+0x108], eax
00007b629addbc5a  movaps xmm5, xmm8
00007b629addbc5e  addpd xmm5, xmm15
00007b629addbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007b629addbc68  ptest xmm4, xmm4
00007b629addbc6d  jnz 0x00007B629ADDD0FA
00007b629addbc73  movaps xmm8, [r15+0x1B0]
00007b629addbc7b  movaps xmm4, xmm9
00007b629addbc7f  addpd xmm4, xmm8
00007b629addbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007b629addbc89  ptest xmm2, xmm2
00007b629addbc8e  jnz 0x00007B629ADDD23C
00007b629addbc94  movaps xmm9, xmm10
00007b629addbc98  addpd xmm9, xmm8
00007b629addbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007b629addbca3  ptest xmm2, xmm2
00007b629addbca8  jnz 0x00007B629ADDD37E
00007b629addbcae  movaps xmm10, [r15+0x2F0]
00007b629addbcb6  vmovaps [rsp+0x90], xmm10
00007b629addbcbf  vmovaps xmm8, [rsp+0x90]
00007b629addbcc8  por xmm10, xmm8
00007b629addbccd  movaps xmm8, [r15+0x2E0]
00007b629addbcd5  vmovaps [rsp+0x90], xmm8
00007b629addbcde  vmovaps xmm2, [rsp+0x90]
00007b629addbce7  por xmm8, xmm2
00007b629addbcec  movaps xmm2, [r15+0x2D0]
00007b629addbcf4  vmovaps [rsp+0x90], xmm2
00007b629addbcfd  vmovaps [rsp+0xA0], xmm1
00007b629addbd06  vmovaps xmm1, [rsp+0x90]
00007b629addbd0f  por xmm2, xmm1
00007b629addbd13  movaps xmm1, [r15+0x200]
00007b629addbd1b  vmovaps [rsp+0x90], xmm1
00007b629addbd24  vmovaps [rsp+0xB0], xmm15
00007b629addbd2d  vmovaps xmm15, [rsp+0x90]
00007b629addbd36  por xmm1, xmm15
00007b629addbd3b  movaps xmm15, [r15+0x1C0]
00007b629addbd43  vmovaps [rsp+0x90], xmm15
00007b629addbd4c  vmovaps [rsp+0xC0], xmm1
00007b629addbd55  vmovaps xmm1, [rsp+0x90]
00007b629addbd5e  por xmm15, xmm1
00007b629addbd63  movaps xmm1, [r15+0x190]
00007b629addbd6b  vmovaps [rsp+0x90], xmm1
00007b629addbd74  vmovaps [rsp+0xD0], xmm15
00007b629addbd7d  vmovaps xmm15, [rsp+0x90]
00007b629addbd86  por xmm1, xmm15
00007b629addbd8b  movaps xmm15, [r15+0x300]
00007b629addbd93  vmovaps [rsp+0x90], xmm15
00007b629addbd9c  vmovaps [rsp+0xE0], xmm1
00007b629addbda5  vmovaps xmm1, [rsp+0x90]
00007b629addbdae  por xmm15, xmm1
00007b629addbdb3  mov rax, [rsp+0x80]
00007b629addbdbb  lea r12, [rax+0xA0]
00007b629addbdc2  movups xmm1, [r13+r12*1]
00007b629addbdc8  lea r12, [rax+0xB0]
00007b629addbdcf  vmovaps [rsp+0x80], xmm1
00007b629addbdd8  movups xmm1, [r13+r12*1]
00007b629addbdde  vmovaps [rsp+0x90], xmm1
00007b629addbde7  vmovaps [rsp+0xF0], xmm15
00007b629addbdf0  vmovaps xmm15, [rsp+0xB0]
00007b629addbdf9  vmovaps [rsp+0xB0], xmm14
00007b629addbe02  movaps xmm1, xmm6
00007b629addbe05  addpd xmm1, xmm15
00007b629addbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007b629addbe0f  ptest xmm14, xmm14
00007b629addbe15  jnz 0x00007B629ADDD4D6
00007b629addbe1b  lea r12, [rax+0xF0]
00007b629addbe22  movups xmm15, [r13+r12*1]
00007b629addbe28  movaps xmm14, xmm4
00007b629addbe2c  addpd xmm14, xmm3
00007b629addbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007b629addbe37  ptest xmm6, xmm6
00007b629addbe3c  jnz 0x00007B629ADDD621
00007b629addbe42  movaps xmm6, xmm9
00007b629addbe46  addpd xmm6, xmm7
00007b629addbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007b629addbe4f  ptest xmm4, xmm4
00007b629addbe54  jnz 0x00007B629ADDD763
00007b629addbe5a  vmovaps xmm9, [rsp+0x70]
00007b629addbe60  vpermilpd xmm9, xmm9, 0x00
00007b629addbe66  vmovaps xmm4, [rsp+0x90]
00007b629addbe6f  movaps xmm7, xmm4
00007b629addbe72  mulpd xmm7, xmm9
00007b629addbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007b629addbe7c  ptest xmm3, xmm3
00007b629addbe81  jnz 0x00007B629ADDD8A4
00007b629addbe87  vmovaps xmm9, [rsp+0x50]
00007b629addbe8d  vpermilpd xmm9, xmm9, 0x00
00007b629addbe93  movaps xmm4, xmm15
00007b629addbe97  mulpd xmm4, xmm9
00007b629addbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007b629addbea1  ptest xmm3, xmm3
00007b629addbea6  jnz 0x00007B629ADDD9E5
00007b629addbeac  lea r12, [rax+0xE0]
00007b629addbeb3  movups xmm15, [r13+r12*1]
00007b629addbeb9  vmovaps xmm9, [rsp+0x70]
00007b629addbebf  vpermilpd xmm9, xmm9, 0x00
00007b629addbec5  vmovaps [rsp+0x70], xmm1
00007b629addbecb  vmovaps xmm1, [rsp+0x80]
00007b629addbed4  vmovaps [rsp+0x80], xmm15
00007b629addbedd  movaps xmm3, xmm1
00007b629addbee0  mulpd xmm3, xmm9
00007b629addbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007b629addbeea  ptest xmm15, xmm15
00007b629addbef0  jnz 0x00007B629ADDDB31
00007b629addbef6  vmovaps xmm1, [rsp+0xF0]
00007b629addbeff  vmovaps xmm15, [rsp+0xF0]
00007b629addbf08  por xmm1, xmm15
00007b629addbf0d  movaps [r15+0x300], xmm1
00007b629addbf15  vmovaps xmm15, [rsp+0xE0]
00007b629addbf1e  vmovaps xmm9, [rsp+0xE0]
00007b629addbf27  por xmm15, xmm9
00007b629addbf2c  movaps [r15+0x190], xmm15
00007b629addbf34  vmovaps xmm9, [rsp+0x50]
00007b629addbf3a  vpermilpd xmm9, xmm9, 0x00
00007b629addbf40  vmovaps [rsp+0x90], xmm1
00007b629addbf49  vmovaps [rsp+0xE0], xmm15
00007b629addbf52  vmovaps xmm15, [rsp+0x80]
00007b629addbf5b  vmovaps [rsp+0x80], xmm14
00007b629addbf64  movaps xmm1, xmm15
00007b629addbf68  mulpd xmm1, xmm9
00007b629addbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007b629addbf72  ptest xmm14, xmm14
00007b629addbf78  jnz 0x00007B629ADDDC72
00007b629addbf7e  lea r12, [rax+0x90]
00007b629addbf85  movups xmm15, [r13+r12*1]
00007b629addbf8b  vmovaps xmm14, [rsp+0xD0]
00007b629addbf94  vmovaps xmm9, [rsp+0xD0]
00007b629addbf9d  por xmm14, xmm9
00007b629addbfa2  movaps [r15+0x1C0], xmm14
00007b629addbfaa  vmovaps xmm9, [rsp+0xC0]
00007b629addbfb3  vmovaps [rsp+0xD0], xmm1
00007b629addbfbc  vmovaps xmm1, [rsp+0xC0]
00007b629addbfc5  por xmm9, xmm1
00007b629addbfca  movaps [r15+0x200], xmm9
00007b629addbfd2  vmovaps [rsp+0xC0], xmm2
00007b629addbfdb  vmovaps xmm1, [rsp+0xC0]
00007b629addbfe4  por xmm2, xmm1
00007b629addbfe8  movaps [r15+0x2D0], xmm2
00007b629addbff0  vmovaps [rsp+0xC0], xmm8
00007b629addbff9  vmovaps xmm1, [rsp+0xC0]
00007b629addc002  por xmm8, xmm1
00007b629addc007  movaps [r15+0x2E0], xmm8
00007b629addc00f  vmovaps [rsp+0xC0], xmm15
00007b629addc018  movaps xmm1, xmm5
00007b629addc01b  addpd xmm1, xmm7
00007b629addc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007b629addc024  ptest xmm15, xmm15
00007b629addc02a  jnz 0x00007B629ADDDDBE
00007b629addc030  vmovaps xmm15, [rsp+0x50]
00007b629addc036  vpermilpd xmm15, xmm15, 0x00
00007b629addc03c  vmovaps xmm5, [rsp+0xC0]
00007b629addc045  vmovaps [rsp+0xC0], xmm1
00007b629addc04e  movaps xmm7, xmm5
00007b629addc051  mulpd xmm7, xmm15
00007b629addc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007b629addc05b  ptest xmm1, xmm1
00007b629addc060  jnz 0x00007B629ADDDEFE
00007b629addc066  lea r12, [rax+0x80]
00007b629addc06d  movups xmm1, [r13+r12*1]
00007b629addc073  vmovaps xmm5, [rsp+0x70]
00007b629addc079  vmovaps [rsp+0x70], xmm1
00007b629addc07f  movaps xmm15, xmm5
00007b629addc083  addpd xmm15, xmm3
00007b629addc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007b629addc08e  ptest xmm1, xmm1
00007b629addc093  jnz 0x00007B629ADDE049
00007b629addc099  vmovaps xmm5, [rsp+0x80]
00007b629addc0a2  movaps xmm1, xmm5
00007b629addc0a5  addpd xmm1, xmm4
00007b629addc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007b629addc0ae  ptest xmm3, xmm3
00007b629addc0b3  jnz 0x00007B629ADDE18B
00007b629addc0b9  vmovaps [rsp+0x80], xmm10
00007b629addc0c2  vmovaps xmm5, [rsp+0x80]
00007b629addc0cb  por xmm10, xmm5
00007b629addc0d0  movaps [r15+0x2F0], xmm10
00007b629addc0d8  vmovaps xmm5, [rsp+0x50]
00007b629addc0de  vpermilpd xmm5, xmm5, 0x00
00007b629addc0e4  vmovaps xmm3, [rsp+0x70]
00007b629addc0ea  vmovaps [rsp+0x50], xmm1
00007b629addc0f0  movaps xmm4, xmm3
00007b629addc0f3  mulpd xmm4, xmm5
00007b629addc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007b629addc0fc  ptest xmm1, xmm1
00007b629addc101  jnz 0x00007B629ADDE2CB
00007b629addc107  lea r12, [rax+0xD0]
00007b629addc10e  movups xmm1, [r13+r12*1]
00007b629addc114  vmovaps xmm3, [rsp+0xD0]
00007b629addc11d  vmovaps [rsp+0x70], xmm1
00007b629addc123  movaps xmm5, xmm6
00007b629addc126  addpd xmm5, xmm3
00007b629addc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007b629addc12f  ptest xmm1, xmm1
00007b629addc134  jnz 0x00007B629ADDE415
00007b629addc13a  vmovaps xmm1, [rsp+0x60]
00007b629addc140  vpermilpd xmm1, xmm1, 0x00
00007b629addc146  movaps xmm6, xmm9
00007b629addc14a  mulpd xmm6, xmm1
00007b629addc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007b629addc153  ptest xmm3, xmm3
00007b629addc158  jnz 0x00007B629ADDE555
00007b629addc15e  movaps [r15+0x260], xmm6
00007b629addc166  vxorps xmm1, xmm1, xmm1
00007b629addc16a  vpbroadcastq xmm1, xmm1
00007b629addc16f  movaps [r15+0x1B0], xmm1
00007b629addc177  vmovaps xmm1, [rsp+0x60]
00007b629addc17d  vpermilpd xmm1, xmm1, 0x00
00007b629addc183  vmovaps xmm3, [rsp+0x70]
00007b629addc189  vmovaps [rsp+0x70], xmm15
00007b629addc18f  movaps xmm9, xmm3
00007b629addc193  mulpd xmm9, xmm1
00007b629addc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007b629addc19e  ptest xmm15, xmm15
00007b629addc1a4  jnz 0x00007B629ADDE696
00007b629addc1aa  lea r12, [rax+0xC0]
00007b629addc1b1  movups xmm1, [r13+r12*1]
00007b629addc1b7  vmovaps xmm3, [rsp+0xC0]
00007b629addc1c0  vmovaps [rsp+0x80], xmm1
00007b629addc1c9  movaps xmm15, xmm3
00007b629addc1cd  addpd xmm15, xmm7
00007b629addc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007b629addc1d8  ptest xmm1, xmm1
00007b629addc1dd  jnz 0x00007B629ADDE7E2
00007b629addc1e3  vmovaps [rsp+0xC0], xmm13
00007b629addc1ec  vmovaps xmm1, [rsp+0xC0]
00007b629addc1f5  por xmm13, xmm1
00007b629addc1fa  movaps [r15+0x270], xmm13
00007b629addc202  vmovaps xmm1, [rsp+0xB0]
00007b629addc20b  vmovaps xmm7, [rsp+0xB0]
00007b629addc214  por xmm1, xmm7
00007b629addc218  movaps [r15+0x1A0], xmm1
00007b629addc220  vmovaps xmm1, [rsp+0x60]
00007b629addc226  vpermilpd xmm1, xmm1, 0x00
00007b629addc22c  vmovaps [rsp+0xB0], xmm1
00007b629addc235  vmovaps xmm1, [rsp+0x80]
00007b629addc23e  vmovaps [rsp+0x80], xmm15
00007b629addc247  vmovaps xmm15, [rsp+0xB0]
00007b629addc250  vmovaps [rsp+0xB0], xmm14
00007b629addc259  movaps xmm3, xmm1
00007b629addc25c  mulpd xmm3, xmm15
00007b629addc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007b629addc266  ptest xmm14, xmm14
00007b629addc26c  jnz 0x00007B629ADDE924
00007b629addc272  lea r12, [rax+0x20]
00007b629addc276  movups xmm1, [r13+r12*1]
00007b629addc27c  movaps [r15+0x110], xmm1
00007b629addc284  vmovaps xmm14, [rsp+0x70]
00007b629addc28a  vmovaps [rsp+0x70], xmm1
00007b629addc290  movaps xmm15, xmm14
00007b629addc294  addpd xmm15, xmm4
00007b629addc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007b629addc29f  ptest xmm1, xmm1
00007b629addc2a4  jnz 0x00007B629ADDEA6F
00007b629addc2aa  vmovaps xmm1, [rsp+0x60]
00007b629addc2b0  vpermilpd xmm1, xmm1, 0x00
00007b629addc2b6  movaps xmm14, xmm2
00007b629addc2ba  mulpd xmm14, xmm1
00007b629addc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007b629addc2c5  ptest xmm4, xmm4
00007b629addc2ca  jnz 0x00007B629ADDEBB2
00007b629addc2d0  vmovaps xmm4, [rsp+0x50]
00007b629addc2d6  movaps xmm1, xmm4
00007b629addc2d9  addpd xmm1, xmm9
00007b629addc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007b629addc2e3  ptest xmm2, xmm2
00007b629addc2e8  jnz 0x00007B629ADDECF4
00007b629addc2ee  vmovaps xmm9, [rsp+0x30]
00007b629addc2f4  vpermilpd xmm9, xmm9, 0x00
00007b629addc2fa  vmovaps xmm2, [rsp+0x70]
00007b629addc300  vmovaps [rsp+0x50], xmm1
00007b629addc306  movaps xmm4, xmm2
00007b629addc309  mulpd xmm4, xmm9
00007b629addc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007b629addc313  ptest xmm1, xmm1
00007b629addc318  jnz 0x00007B629ADDEE35
00007b629addc31e  vmovaps xmm1, [rsp+0x30]
00007b629addc324  vpermilpd xmm1, xmm1, 0x00
00007b629addc32a  vmovaps xmm2, [rsp+0x90]
00007b629addc333  vmovaps [rsp+0x60], xmm15
00007b629addc339  movaps xmm9, xmm2
00007b629addc33d  mulpd xmm9, xmm1
00007b629addc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007b629addc348  ptest xmm15, xmm15
00007b629addc34e  jnz 0x00007B629ADDEF76
00007b629addc354  vmovaps xmm15, [rsp+0x80]
00007b629addc35d  movaps xmm1, xmm15
00007b629addc361  addpd xmm1, xmm6
00007b629addc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007b629addc36a  ptest xmm2, xmm2
00007b629addc36f  jnz 0x00007B629ADDF0B8
00007b629addc375  movaps xmm15, xmm5
00007b629addc379  addpd xmm15, xmm3
00007b629addc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007b629addc384  ptest xmm6, xmm6
00007b629addc389  jnz 0x00007B629ADDF1F9
00007b629addc38f  vmovaps xmm6, [rsp+0x30]
00007b629addc395  vpermilpd xmm6, xmm6, 0x00
00007b629addc39b  movaps xmm5, xmm8
00007b629addc39f  mulpd xmm5, xmm6
00007b629addc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007b629addc3a8  ptest xmm3, xmm3
00007b629addc3ad  jnz 0x00007B629ADDF33B
00007b629addc3b3  vmovaps xmm8, [rsp+0x30]
00007b629addc3b9  vpermilpd xmm8, xmm8, 0x00
00007b629addc3bf  movaps xmm6, xmm10
00007b629addc3c3  mulpd xmm6, xmm8
00007b629addc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007b629addc3cd  ptest xmm3, xmm3
00007b629addc3d2  jnz 0x00007B629ADDF47C
00007b629addc3d8  vmovaps xmm8, [rsp+0x60]
00007b629addc3de  movaps xmm10, xmm8
00007b629addc3e2  addpd xmm10, xmm14
00007b629addc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007b629addc3ed  ptest xmm3, xmm3
00007b629addc3f2  jnz 0x00007B629ADDF5BE
00007b629addc3f8  vmovaps xmm8, [rsp+0x50]
00007b629addc3fe  movaps xmm14, xmm8
00007b629addc402  addpd xmm14, xmm4
00007b629addc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007b629addc40d  ptest xmm3, xmm3
00007b629addc412  jnz 0x00007B629ADDF702
00007b629addc418  vmovaps xmm8, [rsp+0x40]
00007b629addc41e  vpermilpd xmm8, xmm8, 0x00
00007b629addc424  movaps xmm4, xmm13
00007b629addc428  mulpd xmm4, xmm8
00007b629addc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007b629addc432  ptest xmm3, xmm3
00007b629addc437  jnz 0x00007B629ADDF845
00007b629addc43d  movaps xmm13, xmm15
00007b629addc441  addpd xmm13, xmm9
00007b629addc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007b629addc44c  ptest xmm8, xmm8
00007b629addc452  jnz 0x00007B629ADDF987
00007b629addc458  movaps xmm15, xmm1
00007b629addc45c  addpd xmm15, xmm5
00007b629addc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007b629addc467  ptest xmm9, xmm9
00007b629addc46d  jnz 0x00007B629ADDFACB
00007b629addc473  vmovaps [rsp+0x30], xmm11
00007b629addc479  vmovaps xmm1, [rsp+0x30]
00007b629addc47f  por xmm11, xmm1
00007b629addc484  movaps [r15+0x250], xmm11
00007b629addc48c  vmovaps [rsp+0x30], xmm12
00007b629addc492  vmovaps xmm1, [rsp+0x30]
00007b629addc498  por xmm12, xmm1
00007b629addc49d  movaps [r15+0x2A0], xmm12
00007b629addc4a5  vmovaps xmm1, [rsp+0xA0]
00007b629addc4ae  vmovaps xmm11, [rsp+0xA0]
00007b629addc4b7  por xmm1, xmm11
00007b629addc4bc  movaps [r15+0x1D0], xmm1
00007b629addc4c4  lea r12, [rax+0x40]
00007b629addc4c8  movups xmm1, [r13+r12*1]
00007b629addc4ce  movaps [r15+0x2C0], xmm1
00007b629addc4d6  vmovaps xmm11, [rsp+0x40]
00007b629addc4dc  vpermilpd xmm11, xmm11, 0x00
00007b629addc4e2  vmovaps xmm8, [rsp+0xE0]
00007b629addc4eb  movaps xmm9, xmm8
00007b629addc4ef  mulpd xmm9, xmm11
00007b629addc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007b629addc4fa  ptest xmm5, xmm5
00007b629addc4ff  jnz 0x00007B629ADDFC17
00007b629addc505  movaps xmm11, xmm10
00007b629addc509  addpd xmm11, xmm6
00007b629addc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007b629addc514  ptest xmm8, xmm8
00007b629addc51a  jnz 0x00007B629ADDFD5B
00007b629addc520  movaps xmm10, xmm14
00007b629addc524  addpd xmm10, xmm4
00007b629addc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007b629addc52f  ptest xmm8, xmm8
00007b629addc535  jnz 0x00007B629ADDFE9E
00007b629addc53b  vmovaps xmm14, [rsp+0x40]
00007b629addc541  vpermilpd xmm14, xmm14, 0x00
00007b629addc547  movaps xmm8, xmm1
00007b629addc54b  mulpd xmm8, xmm14
00007b629addc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007b629addc556  ptest xmm6, xmm6
00007b629addc55b  jnz 0x00007B629ADDFFE1
00007b629addc561  movaps xmm1, [r15+0x2B0]
00007b629addc569  vmovaps xmm14, [rsp+0x40]
00007b629addc56f  vpermilpd xmm14, xmm14, 0x00
00007b629addc575  movaps xmm6, xmm1
00007b629addc578  mulpd xmm6, xmm14
00007b629addc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007b629addc582  ptest xmm5, xmm5
00007b629addc587  jnz 0x00007B629ADE0124
00007b629addc58d  vmovaps xmm1, [rsp+0x10]
00007b629addc593  vpermilpd xmm1, xmm1, 0x00
00007b629addc599  movaps xmm14, xmm12
00007b629addc59d  mulpd xmm14, xmm1
00007b629addc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007b629addc5a8  ptest xmm5, xmm5
00007b629addc5ad  jnz 0x00007B629ADE0265
00007b629addc5b3  movaps xmm1, xmm13
00007b629addc5b7  addpd xmm1, xmm9
00007b629addc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007b629addc5c1  ptest xmm12, xmm12
00007b629addc5c7  jnz 0x00007B629ADE03A8
00007b629addc5cd  vmovaps xmm13, [rsp+0x10]
00007b629addc5d3  vpermilpd xmm13, xmm13, 0x00
00007b629addc5d9  movaps xmm12, xmm7
00007b629addc5dd  mulpd xmm12, xmm13
00007b629addc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007b629addc5e8  ptest xmm9, xmm9
00007b629addc5ee  jnz 0x00007B629ADE04EA
00007b629addc5f4  movaps xmm13, xmm15
00007b629addc5f8  addpd xmm13, xmm8
00007b629addc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007b629addc603  ptest xmm9, xmm9
00007b629addc609  jnz 0x00007B629ADE062D
00007b629addc60f  movaps xmm15, [r15+0x290]
00007b629addc617  vmovaps xmm9, [rsp+0x10]
00007b629addc61d  vpermilpd xmm9, xmm9, 0x00
00007b629addc623  movaps xmm8, xmm15
00007b629addc627  mulpd xmm8, xmm9
00007b629addc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007b629addc632  ptest xmm7, xmm7
00007b629addc637  jnz 0x00007B629ADE0771
00007b629addc63d  movaps xmm15, xmm11
00007b629addc641  addpd xmm15, xmm6
00007b629addc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007b629addc64c  ptest xmm9, xmm9
00007b629addc652  jnz 0x00007B629ADE08B5
00007b629addc658  movaps xmm11, [r15+0x1E0]
00007b629addc660  vmovaps xmm9, [rsp+0x10]
00007b629addc666  vpermilpd xmm9, xmm9, 0x00
00007b629addc66c  movaps xmm7, xmm11
00007b629addc670  mulpd xmm7, xmm9
00007b629addc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007b629addc67a  ptest xmm6, xmm6
00007b629addc67f  jnz 0x00007B629ADE09F8
00007b629addc685  movaps xmm11, xmm10
00007b629addc689  addpd xmm11, xmm14
00007b629addc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007b629addc694  ptest xmm9, xmm9
00007b629addc69a  jnz 0x00007B629ADE0B3A
00007b629addc6a0  lea r12, [rax+0x70]
00007b629addc6a4  movups xmm14, [r13+r12*1]
00007b629addc6aa  movaps [r15+0x240], xmm14
00007b629addc6b2  movaps xmm10, xmm1
00007b629addc6b6  addpd xmm10, xmm12
00007b629addc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007b629addc6c1  ptest xmm9, xmm9
00007b629addc6c7  jnz 0x00007B629ADE0C88
00007b629addc6cd  movaps [r15+0x170], xmm10
00007b629addc6d5  vmovaps xmm1, [rsp+0x20]
00007b629addc6db  vpermilpd xmm1, xmm1, 0x00
00007b629addc6e1  movaps xmm12, xmm14
00007b629addc6e5  mulpd xmm12, xmm1
00007b629addc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007b629addc6f0  ptest xmm9, xmm9
00007b629addc6f6  jnz 0x00007B629ADE0DCB
00007b629addc6fc  vmovaps xmm1, [rsp+0x20]
00007b629addc702  vpermilpd xmm1, xmm1, 0x00
00007b629addc708  vmovaps xmm9, [rsp+0xB0]
00007b629addc711  movaps xmm14, xmm9
00007b629addc715  mulpd xmm14, xmm1
00007b629addc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007b629addc720  ptest xmm6, xmm6
00007b629addc725  jnz 0x00007B629ADE0F0E
00007b629addc72b  movaps [r15+0x180], xmm14
00007b629addc733  movaps xmm1, xmm13
00007b629addc737  addpd xmm1, xmm8
00007b629addc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007b629addc741  ptest xmm9, xmm9
00007b629addc747  jnz 0x00007B629ADE1051
00007b629addc74d  movaps [r15+0x210], xmm1
00007b629addc755  movups xmm13, [r13+rax*1]
00007b629addc75b  lea r12, [rax+0x10]
00007b629addc75f  movups xmm9, [r13+r12*1]
00007b629addc765  movaps [r15+0x230], xmm9
00007b629addc76d  movaps xmm8, xmm15
00007b629addc771  addpd xmm8, xmm7
00007b629addc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007b629addc77c  ptest xmm6, xmm6
00007b629addc781  jnz 0x00007B629ADE11A7
00007b629addc787  movaps [r15+0x130], xmm8
00007b629addc78f  vmovaps xmm15, [rsp+0x20]
00007b629addc795  vpermilpd xmm15, xmm15, 0x00
00007b629addc79b  movaps xmm7, xmm9
00007b629addc79f  mulpd xmm7, xmm15
00007b629addc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007b629addc7a9  ptest xmm6, xmm6
00007b629addc7ae  jnz 0x00007B629ADE12EA
00007b629addc7b4  movaps [r15+0x220], xmm7
00007b629addc7bc  vmovaps xmm15, [rsp+0x20]
00007b629addc7c2  vpermilpd xmm15, xmm15, 0x00
00007b629addc7c8  movaps xmm9, xmm13
00007b629addc7cc  mulpd xmm9, xmm15
00007b629addc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007b629addc7d7  ptest xmm6, xmm6
00007b629addc7dc  jnz 0x00007B629ADE142C
00007b629addc7e2  movaps xmm15, xmm11
00007b629addc7e6  addpd xmm15, xmm12
00007b629addc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007b629addc7f1  ptest xmm13, xmm13
00007b629addc7f7  jnz 0x00007B629ADE1570
00007b629addc7fd  movaps [r15+0x140], xmm15
00007b629addc805  movaps xmm13, xmm10
00007b629addc809  addpd xmm13, xmm14
00007b629addc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007b629addc814  ptest xmm12, xmm12
00007b629addc81a  jnz 0x00007B629ADE16B4
00007b629addc820  movaps [r15+0x150], xmm13
00007b629addc828  movaps xmm14, xmm1
00007b629addc82c  addpd xmm14, xmm7
00007b629addc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007b629addc837  ptest xmm12, xmm12
00007b629addc83d  jnz 0x00007B629ADE17F8
00007b629addc843  movaps [r15+0x160], xmm14
00007b629addc84b  movaps xmm1, xmm8
00007b629addc84f  addpd xmm1, xmm9
00007b629addc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007b629addc859  ptest xmm12, xmm12
00007b629addc85f  jnz 0x00007B629ADE193A
00007b629addc865  movaps [r15+0x120], xmm1
00007b629addc86d  movups [r13+r14*1], xmm15
00007b629addc873  lea rax, [r14+0x10]
00007b629addc877  movups [r13+rax*1], xmm13
00007b629addc87d  lea rax, [r14+0x20]
00007b629addc881  movups [r13+rax*1], xmm14
00007b629addc887  lea rax, [r14+0x30]
00007b629addc88b  movups [r13+rax*1], xmm1
00007b629addc891  mov eax, [r15+0x108]
00007b629addc898  sahf
00007b629addc899  jnz 0x00007B629ADDC8CB
00007b629addc89b  cmp dword ptr [r15+0x318], 0x00
00007b629addc8a3  jz 0x00007B629ADDB900
00007b629addc8a9  nop [rax+rax*1], ax
00007b629addc8b2  nop [rax+rax*1], eax
00007b629addc8ba  mov eax, 0x410444
00007b629addc8bf  mov [r15+0x100], rax
00007b629addc8c6  jmp 0x00007B629ABFE110
00007b629addc8cb  cmp dword ptr [r15+0x318], 0x00
00007b629addc8d3  jz 0x00007B629ADD57E0
00007b629addc8d9  nop [rax+rax*1], ax
00007b629addc8e2  nop [rax+rax*1], eax
00007b629addc8ea  mov eax, 0x410278
00007b629addc8ef  mov [r15+0x100], rax
00007b629addc8f6  jmp 0x00007B629ABFE110
00007b629addc8fb  int3
00007b629addc8fc  call 0x00007B629ACE27E0
00007b629addc901  jmp 0x00007B629ADDB9DF
00007b629addc906  call 0x00007B629ACE1570
00007b629addc90b  jmp 0x00007B629ADDB9E8
00007b629addc910  call 0x00007B629ACE27E0
00007b629addc915  jmp 0x00007B629ADDBA44
00007b629addc91a  call 0x00007B629ACE1570
00007b629addc91f  jmp 0x00007B629ADDBA4D
00007b629addc924  call 0x00007B629ACE27E0
00007b629addc929  jmp 0x00007B629ADDBA90
00007b629addc92e  call 0x00007B629ACE1570
00007b629addc933  jmp 0x00007B629ADDBA99
00007b629addc938  call 0x00007B629AC0DC20
00007b629addc93d  jmp 0x00007B629ADDBAD8
00007b629addc942  call 0x00007B629ACD59C0
00007b629addc947  jmp 0x00007B629ADDBAEB
00007b629addc94c  call 0x00007B629ACE0E30
00007b629addc951  jmp 0x00007B629ADDBB09
00007b629addc956  call 0x00007B629ACDFBC0
00007b629addc95b  jmp 0x00007B629ADDBB13
00007b629addc960  call 0x00007B629ACDE950
00007b629addc965  jmp 0x00007B629ADDBB1D
00007b629addc96a  sub rsp, 0x08
00007b629addc96e  push rax
00007b629addc96f  push rcx
00007b629addc970  push rdx
00007b629addc971  push rdi
00007b629addc972  push rsi
00007b629addc973  push r8
00007b629addc975  push r9
00007b629addc977  push r10
00007b629addc979  push r11
00007b629addc97b  sub rsp, 0xF0
00007b629addc982  vmovaps [rsp], xmm0
00007b629addc987  vmovaps [rsp+0x10], xmm1
00007b629addc98d  vmovaps [rsp+0x20], xmm2
00007b629addc993  vmovaps [rsp+0x30], xmm3
00007b629addc999  vmovaps [rsp+0x40], xmm4
00007b629addc99f  vmovaps [rsp+0x50], xmm5
00007b629addc9a5  vmovaps [rsp+0x60], xmm6
00007b629addc9ab  vmovaps [rsp+0x70], xmm7
00007b629addc9b1  vmovaps [rsp+0x80], xmm9
00007b629addc9ba  vmovaps [rsp+0x90], xmm10
00007b629addc9c3  vmovaps [rsp+0xA0], xmm11
00007b629addc9cc  vmovaps [rsp+0xB0], xmm12
00007b629addc9d5  vmovaps [rsp+0xC0], xmm13
00007b629addc9de  vmovaps [rsp+0xD0], xmm14
00007b629addc9e7  vmovaps [rsp+0xE0], xmm15
00007b629addc9f0  sub rsp, 0x30
00007b629addc9f4  movaps [rsp], xmm8
00007b629addc9f9  movaps [rsp+0x10], xmm12
00007b629addc9ff  movaps [rsp+0x20], xmm15
00007b629addca05  lea rdi, [rsp]
00007b629addca09  mov esi, 0x00
00007b629addca0e  mov rax, 0x583FED93F530
00007b629addca18  call rax
00007b629addca1a  movaps xmm8, [rsp]
00007b629addca1f  add rsp, 0x30
00007b629addca23  vmovaps xmm0, [rsp]
00007b629addca28  vmovaps xmm1, [rsp+0x10]
00007b629addca2e  vmovaps xmm2, [rsp+0x20]
00007b629addca34  vmovaps xmm3, [rsp+0x30]
00007b629addca3a  vmovaps xmm4, [rsp+0x40]
00007b629addca40  vmovaps xmm5, [rsp+0x50]
00007b629addca46  vmovaps xmm6, [rsp+0x60]
00007b629addca4c  vmovaps xmm7, [rsp+0x70]
00007b629addca52  vmovaps xmm9, [rsp+0x80]
00007b629addca5b  vmovaps xmm10, [rsp+0x90]
00007b629addca64  vmovaps xmm11, [rsp+0xA0]
00007b629addca6d  vmovaps xmm12, [rsp+0xB0]
00007b629addca76  vmovaps xmm13, [rsp+0xC0]
00007b629addca7f  vmovaps xmm14, [rsp+0xD0]
00007b629addca88  vmovaps xmm15, [rsp+0xE0]
00007b629addca91  add rsp, 0xF0
00007b629addca98  pop r11
00007b629addca9a  pop r10
00007b629addca9c  pop r9
00007b629addca9e  pop r8
00007b629addcaa0  pop rsi
00007b629addcaa1  pop rdi
00007b629addcaa2  pop rdx
00007b629addcaa3  pop rcx
00007b629addcaa4  pop rax
00007b629addcaa5  add rsp, 0x08
00007b629addcaa9  jmp 0x00007B629ADDBB47
00007b629addcaae  sub rsp, 0x08
00007b629addcab2  push rax
00007b629addcab3  push rcx
00007b629addcab4  push rdx
00007b629addcab5  push rdi
00007b629addcab6  push rsi
00007b629addcab7  push r8
00007b629addcab9  push r9
00007b629addcabb  push r10
00007b629addcabd  push r11
00007b629addcabf  sub rsp, 0xF0
00007b629addcac6  vmovaps [rsp], xmm0
00007b629addcacb  vmovaps [rsp+0x10], xmm1
00007b629addcad1  vmovaps [rsp+0x20], xmm2
00007b629addcad7  vmovaps [rsp+0x30], xmm3
00007b629addcadd  vmovaps [rsp+0x40], xmm4
00007b629addcae3  vmovaps [rsp+0x50], xmm5
00007b629addcae9  vmovaps [rsp+0x60], xmm6
00007b629addcaef  vmovaps [rsp+0x70], xmm8
00007b629addcaf5  vmovaps [rsp+0x80], xmm9
00007b629addcafe  vmovaps [rsp+0x90], xmm10
00007b629addcb07  vmovaps [rsp+0xA0], xmm11
00007b629addcb10  vmovaps [rsp+0xB0], xmm12
00007b629addcb19  vmovaps [rsp+0xC0], xmm13
00007b629addcb22  vmovaps [rsp+0xD0], xmm14
00007b629addcb2b  vmovaps [rsp+0xE0], xmm15
00007b629addcb34  sub rsp, 0x30
00007b629addcb38  movaps [rsp], xmm7
00007b629addcb3c  movaps [rsp+0x10], xmm9
00007b629addcb42  movaps [rsp+0x20], xmm15
00007b629addcb48  lea rdi, [rsp]
00007b629addcb4c  mov esi, 0x00
00007b629addcb51  mov rax, 0x583FED93F530
00007b629addcb5b  call rax
00007b629addcb5d  movaps xmm7, [rsp]
00007b629addcb61  add rsp, 0x30
00007b629addcb65  vmovaps xmm0, [rsp]
00007b629addcb6a  vmovaps xmm1, [rsp+0x10]
00007b629addcb70  vmovaps xmm2, [rsp+0x20]
00007b629addcb76  vmovaps xmm3, [rsp+0x30]
00007b629addcb7c  vmovaps xmm4, [rsp+0x40]
00007b629addcb82  vmovaps xmm5, [rsp+0x50]
00007b629addcb88  vmovaps xmm6, [rsp+0x60]
00007b629addcb8e  vmovaps xmm8, [rsp+0x70]
00007b629addcb94  vmovaps xmm9, [rsp+0x80]
00007b629addcb9d  vmovaps xmm10, [rsp+0x90]
00007b629addcba6  vmovaps xmm11, [rsp+0xA0]
00007b629addcbaf  vmovaps xmm12, [rsp+0xB0]
00007b629addcbb8  vmovaps xmm13, [rsp+0xC0]
00007b629addcbc1  vmovaps xmm14, [rsp+0xD0]
00007b629addcbca  vmovaps xmm15, [rsp+0xE0]
00007b629addcbd3  add rsp, 0xF0
00007b629addcbda  pop r11
00007b629addcbdc  pop r10
00007b629addcbde  pop r9
00007b629addcbe0  pop r8
00007b629addcbe2  pop rsi
00007b629addcbe3  pop rdi
00007b629addcbe4  pop rdx
00007b629addcbe5  pop rcx
00007b629addcbe6  pop rax
00007b629addcbe7  add rsp, 0x08
00007b629addcbeb  jmp 0x00007B629ADDBB75
00007b629addcbf0  sub rsp, 0x08
00007b629addcbf4  push rax
00007b629addcbf5  push rcx
00007b629addcbf6  push rdx
00007b629addcbf7  push rdi
00007b629addcbf8  push rsi
00007b629addcbf9  push r8
00007b629addcbfb  push r9
00007b629addcbfd  push r10
00007b629addcbff  push r11
00007b629addcc01  sub rsp, 0xF0
00007b629addcc08  vmovaps [rsp], xmm0
00007b629addcc0d  vmovaps [rsp+0x10], xmm1
00007b629addcc13  vmovaps [rsp+0x20], xmm2
00007b629addcc19  vmovaps [rsp+0x30], xmm3
00007b629addcc1f  vmovaps [rsp+0x40], xmm4
00007b629addcc25  vmovaps [rsp+0x50], xmm5
00007b629addcc2b  vmovaps [rsp+0x60], xmm6
00007b629addcc31  vmovaps [rsp+0x70], xmm7
00007b629addcc37  vmovaps [rsp+0x80], xmm8
00007b629addcc40  vmovaps [rsp+0x90], xmm10
00007b629addcc49  vmovaps [rsp+0xA0], xmm11
00007b629addcc52  vmovaps [rsp+0xB0], xmm12
00007b629addcc5b  vmovaps [rsp+0xC0], xmm13
00007b629addcc64  vmovaps [rsp+0xD0], xmm14
00007b629addcc6d  vmovaps [rsp+0xE0], xmm15
00007b629addcc76  sub rsp, 0x30
00007b629addcc7a  movaps [rsp], xmm9
00007b629addcc7f  movaps [rsp+0x10], xmm12
00007b629addcc85  movaps [rsp+0x20], xmm10
00007b629addcc8b  lea rdi, [rsp]
00007b629addcc8f  mov esi, 0x00
00007b629addcc94  mov rax, 0x583FED93F530
00007b629addcc9e  call rax
00007b629addcca0  movaps xmm9, [rsp]
00007b629addcca5  add rsp, 0x30
00007b629addcca9  vmovaps xmm0, [rsp]
00007b629addccae  vmovaps xmm1, [rsp+0x10]
00007b629addccb4  vmovaps xmm2, [rsp+0x20]
00007b629addccba  vmovaps xmm3, [rsp+0x30]
00007b629addccc0  vmovaps xmm4, [rsp+0x40]
00007b629addccc6  vmovaps xmm5, [rsp+0x50]
00007b629addcccc  vmovaps xmm6, [rsp+0x60]
00007b629addccd2  vmovaps xmm7, [rsp+0x70]
00007b629addccd8  vmovaps xmm8, [rsp+0x80]
00007b629addcce1  vmovaps xmm10, [rsp+0x90]
00007b629addccea  vmovaps xmm11, [rsp+0xA0]
00007b629addccf3  vmovaps xmm12, [rsp+0xB0]
00007b629addccfc  vmovaps xmm13, [rsp+0xC0]
00007b629addcd05  vmovaps xmm14, [rsp+0xD0]
00007b629addcd0e  vmovaps xmm15, [rsp+0xE0]
00007b629addcd17  add rsp, 0xF0
00007b629addcd1e  pop r11
00007b629addcd20  pop r10
00007b629addcd22  pop r9
00007b629addcd24  pop r8
00007b629addcd26  pop rsi
00007b629addcd27  pop rdi
00007b629addcd28  pop rdx
00007b629addcd29  pop rcx
00007b629addcd2a  pop rax
00007b629addcd2b  add rsp, 0x08
00007b629addcd2f  jmp 0x00007B629ADDBB99
00007b629addcd34  sub rsp, 0x08
00007b629addcd38  push rax
00007b629addcd39  push rcx
00007b629addcd3a  push rdx
00007b629addcd3b  push rdi
00007b629addcd3c  push rsi
00007b629addcd3d  push r8
00007b629addcd3f  push r9
00007b629addcd41  push r10
00007b629addcd43  push r11
00007b629addcd45  sub rsp, 0xF0
00007b629addcd4c  vmovaps [rsp], xmm0
00007b629addcd51  vmovaps [rsp+0x10], xmm1
00007b629addcd57  vmovaps [rsp+0x20], xmm2
00007b629addcd5d  vmovaps [rsp+0x30], xmm3
00007b629addcd63  vmovaps [rsp+0x40], xmm4
00007b629addcd69  vmovaps [rsp+0x50], xmm5
00007b629addcd6f  vmovaps [rsp+0x60], xmm6
00007b629addcd75  vmovaps [rsp+0x70], xmm7
00007b629addcd7b  vmovaps [rsp+0x80], xmm8
00007b629addcd84  vmovaps [rsp+0x90], xmm9
00007b629addcd8d  vmovaps [rsp+0xA0], xmm11
00007b629addcd96  vmovaps [rsp+0xB0], xmm12
00007b629addcd9f  vmovaps [rsp+0xC0], xmm13
00007b629addcda8  vmovaps [rsp+0xD0], xmm14
00007b629addcdb1  vmovaps [rsp+0xE0], xmm15
00007b629addcdba  sub rsp, 0x30
00007b629addcdbe  movaps [rsp], xmm10
00007b629addcdc3  movaps [rsp+0x10], xmm12
00007b629addcdc9  movaps [rsp+0x20], xmm11
00007b629addcdcf  lea rdi, [rsp]
00007b629addcdd3  mov esi, 0x00
00007b629addcdd8  mov rax, 0x583FED93F530
00007b629addcde2  call rax
00007b629addcde4  movaps xmm10, [rsp]
00007b629addcde9  add rsp, 0x30
00007b629addcded  vmovaps xmm0, [rsp]
00007b629addcdf2  vmovaps xmm1, [rsp+0x10]
00007b629addcdf8  vmovaps xmm2, [rsp+0x20]
00007b629addcdfe  vmovaps xmm3, [rsp+0x30]
00007b629addce04  vmovaps xmm4, [rsp+0x40]
00007b629addce0a  vmovaps xmm5, [rsp+0x50]
00007b629addce10  vmovaps xmm6, [rsp+0x60]
00007b629addce16  vmovaps xmm7, [rsp+0x70]
00007b629addce1c  vmovaps xmm8, [rsp+0x80]
00007b629addce25  vmovaps xmm9, [rsp+0x90]
00007b629addce2e  vmovaps xmm11, [rsp+0xA0]
00007b629addce37  vmovaps xmm12, [rsp+0xB0]
00007b629addce40  vmovaps xmm13, [rsp+0xC0]
00007b629addce49  vmovaps xmm14, [rsp+0xD0]
00007b629addce52  vmovaps xmm15, [rsp+0xE0]
00007b629addce5b  add rsp, 0xF0
00007b629addce62  pop r11
00007b629addce64  pop r10
00007b629addce66  pop r9
00007b629addce68  pop r8
00007b629addce6a  pop rsi
00007b629addce6b  pop rdi
00007b629addce6c  pop rdx
00007b629addce6d  pop rcx
00007b629addce6e  pop rax
00007b629addce6f  add rsp, 0x08
00007b629addce73  jmp 0x00007B629ADDBBB3
00007b629addce78  sub rsp, 0x08
00007b629addce7c  push rax
00007b629addce7d  push rcx
00007b629addce7e  push rdx
00007b629addce7f  push rdi
00007b629addce80  push rsi
00007b629addce81  push r8
00007b629addce83  push r9
00007b629addce85  push r10
00007b629addce87  push r11
00007b629addce89  sub rsp, 0xF0
00007b629addce90  vmovaps [rsp], xmm0
00007b629addce95  vmovaps [rsp+0x10], xmm1
00007b629addce9b  vmovaps [rsp+0x20], xmm2
00007b629addcea1  vmovaps [rsp+0x30], xmm3
00007b629addcea7  vmovaps [rsp+0x40], xmm4
00007b629addcead  vmovaps [rsp+0x50], xmm5
00007b629addceb3  vmovaps [rsp+0x60], xmm7
00007b629addceb9  vmovaps [rsp+0x70], xmm8
00007b629addcebf  vmovaps [rsp+0x80], xmm9
00007b629addcec8  vmovaps [rsp+0x90], xmm10
00007b629addced1  vmovaps [rsp+0xA0], xmm11
00007b629addceda  vmovaps [rsp+0xB0], xmm12
00007b629addcee3  vmovaps [rsp+0xC0], xmm13
00007b629addceec  vmovaps [rsp+0xD0], xmm14
00007b629addcef5  vmovaps [rsp+0xE0], xmm15
00007b629addcefe  sub rsp, 0x30
00007b629addcf02  movaps [rsp], xmm6
00007b629addcf06  movaps [rsp+0x10], xmm12
00007b629addcf0c  movaps [rsp+0x20], xmm11
00007b629addcf12  lea rdi, [rsp]
00007b629addcf16  mov esi, 0x00
00007b629addcf1b  mov rax, 0x583FED93F530
00007b629addcf25  call rax
00007b629addcf27  movaps xmm6, [rsp]
00007b629addcf2b  add rsp, 0x30
00007b629addcf2f  vmovaps xmm0, [rsp]
00007b629addcf34  vmovaps xmm1, [rsp+0x10]
00007b629addcf3a  vmovaps xmm2, [rsp+0x20]
00007b629addcf40  vmovaps xmm3, [rsp+0x30]
00007b629addcf46  vmovaps xmm4, [rsp+0x40]
00007b629addcf4c  vmovaps xmm5, [rsp+0x50]
00007b629addcf52  vmovaps xmm7, [rsp+0x60]
00007b629addcf58  vmovaps xmm8, [rsp+0x70]
00007b629addcf5e  vmovaps xmm9, [rsp+0x80]
00007b629addcf67  vmovaps xmm10, [rsp+0x90]
00007b629addcf70  vmovaps xmm11, [rsp+0xA0]
00007b629addcf79  vmovaps xmm12, [rsp+0xB0]
00007b629addcf82  vmovaps xmm13, [rsp+0xC0]
00007b629addcf8b  vmovaps xmm14, [rsp+0xD0]
00007b629addcf94  vmovaps xmm15, [rsp+0xE0]
00007b629addcf9d  add rsp, 0xF0
00007b629addcfa4  pop r11
00007b629addcfa6  pop r10
00007b629addcfa8  pop r9
00007b629addcfaa  pop r8
00007b629addcfac  pop rsi
00007b629addcfad  pop rdi
00007b629addcfae  pop rdx
00007b629addcfaf  pop rcx
00007b629addcfb0  pop rax
00007b629addcfb1  add rsp, 0x08
00007b629addcfb5  jmp 0x00007B629ADDBBD4
00007b629addcfba  sub rsp, 0x08
00007b629addcfbe  push rax
00007b629addcfbf  push rcx
00007b629addcfc0  push rdx
00007b629addcfc1  push rdi
00007b629addcfc2  push rsi
00007b629addcfc3  push r8
00007b629addcfc5  push r9
00007b629addcfc7  push r10
00007b629addcfc9  push r11
00007b629addcfcb  sub rsp, 0xF0
00007b629addcfd2  vmovaps [rsp], xmm0
00007b629addcfd7  vmovaps [rsp+0x10], xmm1
00007b629addcfdd  vmovaps [rsp+0x20], xmm2
00007b629addcfe3  vmovaps [rsp+0x30], xmm4
00007b629addcfe9  vmovaps [rsp+0x40], xmm5
00007b629addcfef  vmovaps [rsp+0x50], xmm6
00007b629addcff5  vmovaps [rsp+0x60], xmm7
00007b629addcffb  vmovaps [rsp+0x70], xmm8
00007b629addd001  vmovaps [rsp+0x80], xmm9
00007b629addd00a  vmovaps [rsp+0x90], xmm10
00007b629addd013  vmovaps [rsp+0xA0], xmm11
00007b629addd01c  vmovaps [rsp+0xB0], xmm12
00007b629addd025  vmovaps [rsp+0xC0], xmm13
00007b629addd02e  vmovaps [rsp+0xD0], xmm14
00007b629addd037  vmovaps [rsp+0xE0], xmm15
00007b629addd040  sub rsp, 0x30
00007b629addd044  movaps [rsp], xmm3
00007b629addd048  movaps [rsp+0x10], xmm5
00007b629addd04d  movaps [rsp+0x20], xmm4
00007b629addd052  lea rdi, [rsp]
00007b629addd056  mov esi, 0x00
00007b629addd05b  mov rax, 0x583FED93F530
00007b629addd065  call rax
00007b629addd067  movaps xmm3, [rsp]
00007b629addd06b  add rsp, 0x30
00007b629addd06f  vmovaps xmm0, [rsp]
00007b629addd074  vmovaps xmm1, [rsp+0x10]
00007b629addd07a  vmovaps xmm2, [rsp+0x20]
00007b629addd080  vmovaps xmm4, [rsp+0x30]
00007b629addd086  vmovaps xmm5, [rsp+0x40]
00007b629addd08c  vmovaps xmm6, [rsp+0x50]
00007b629addd092  vmovaps xmm7, [rsp+0x60]
00007b629addd098  vmovaps xmm8, [rsp+0x70]
00007b629addd09e  vmovaps xmm9, [rsp+0x80]
00007b629addd0a7  vmovaps xmm10, [rsp+0x90]
00007b629addd0b0  vmovaps xmm11, [rsp+0xA0]
00007b629addd0b9  vmovaps xmm12, [rsp+0xB0]
00007b629addd0c2  vmovaps xmm13, [rsp+0xC0]
00007b629addd0cb  vmovaps xmm14, [rsp+0xD0]
00007b629addd0d4  vmovaps xmm15, [rsp+0xE0]
00007b629addd0dd  add rsp, 0xF0
00007b629addd0e4  pop r11
00007b629addd0e6  pop r10
00007b629addd0e8  pop r9
00007b629addd0ea  pop r8
00007b629addd0ec  pop rsi
00007b629addd0ed  pop rdi
00007b629addd0ee  pop rdx
00007b629addd0ef  pop rcx
00007b629addd0f0  pop rax
00007b629addd0f1  add rsp, 0x08
00007b629addd0f5  jmp 0x00007B629ADDBC35
00007b629addd0fa  sub rsp, 0x08
00007b629addd0fe  push rax
00007b629addd0ff  push rcx
00007b629addd100  push rdx
00007b629addd101  push rdi
00007b629addd102  push rsi
00007b629addd103  push r8
00007b629addd105  push r9
00007b629addd107  push r10
00007b629addd109  push r11
00007b629addd10b  sub rsp, 0xF0
00007b629addd112  vmovaps [rsp], xmm0
00007b629addd117  vmovaps [rsp+0x10], xmm1
00007b629addd11d  vmovaps [rsp+0x20], xmm2
00007b629addd123  vmovaps [rsp+0x30], xmm3
00007b629addd129  vmovaps [rsp+0x40], xmm4
00007b629addd12f  vmovaps [rsp+0x50], xmm6
00007b629addd135  vmovaps [rsp+0x60], xmm7
00007b629addd13b  vmovaps [rsp+0x70], xmm8
00007b629addd141  vmovaps [rsp+0x80], xmm9
00007b629addd14a  vmovaps [rsp+0x90], xmm10
00007b629addd153  vmovaps [rsp+0xA0], xmm11
00007b629addd15c  vmovaps [rsp+0xB0], xmm12
00007b629addd165  vmovaps [rsp+0xC0], xmm13
00007b629addd16e  vmovaps [rsp+0xD0], xmm14
00007b629addd177  vmovaps [rsp+0xE0], xmm15
00007b629addd180  sub rsp, 0x30
00007b629addd184  movaps [rsp], xmm5
00007b629addd188  movaps [rsp+0x10], xmm8
00007b629addd18e  movaps [rsp+0x20], xmm15
00007b629addd194  lea rdi, [rsp]
00007b629addd198  mov esi, 0x00
00007b629addd19d  mov rax, 0x583FED93F530
00007b629addd1a7  call rax
00007b629addd1a9  movaps xmm5, [rsp]
00007b629addd1ad  add rsp, 0x30
00007b629addd1b1  vmovaps xmm0, [rsp]
00007b629addd1b6  vmovaps xmm1, [rsp+0x10]
00007b629addd1bc  vmovaps xmm2, [rsp+0x20]
00007b629addd1c2  vmovaps xmm3, [rsp+0x30]
00007b629addd1c8  vmovaps xmm4, [rsp+0x40]
00007b629addd1ce  vmovaps xmm6, [rsp+0x50]
00007b629addd1d4  vmovaps xmm7, [rsp+0x60]
00007b629addd1da  vmovaps xmm8, [rsp+0x70]
00007b629addd1e0  vmovaps xmm9, [rsp+0x80]
00007b629addd1e9  vmovaps xmm10, [rsp+0x90]
00007b629addd1f2  vmovaps xmm11, [rsp+0xA0]
00007b629addd1fb  vmovaps xmm12, [rsp+0xB0]
00007b629addd204  vmovaps xmm13, [rsp+0xC0]
00007b629addd20d  vmovaps xmm14, [rsp+0xD0]
00007b629addd216  vmovaps xmm15, [rsp+0xE0]
00007b629addd21f  add rsp, 0xF0
00007b629addd226  pop r11
00007b629addd228  pop r10
00007b629addd22a  pop r9
00007b629addd22c  pop r8
00007b629addd22e  pop rsi
00007b629addd22f  pop rdi
00007b629addd230  pop rdx
00007b629addd231  pop rcx
00007b629addd232  pop rax
00007b629addd233  add rsp, 0x08
00007b629addd237  jmp 0x00007B629ADDBC73
00007b629addd23c  sub rsp, 0x08
00007b629addd240  push rax
00007b629addd241  push rcx
00007b629addd242  push rdx
00007b629addd243  push rdi
00007b629addd244  push rsi
00007b629addd245  push r8
00007b629addd247  push r9
00007b629addd249  push r10
00007b629addd24b  push r11
00007b629addd24d  sub rsp, 0xF0
00007b629addd254  vmovaps [rsp], xmm0
00007b629addd259  vmovaps [rsp+0x10], xmm1
00007b629addd25f  vmovaps [rsp+0x20], xmm2
00007b629addd265  vmovaps [rsp+0x30], xmm3
00007b629addd26b  vmovaps [rsp+0x40], xmm5
00007b629addd271  vmovaps [rsp+0x50], xmm6
00007b629addd277  vmovaps [rsp+0x60], xmm7
00007b629addd27d  vmovaps [rsp+0x70], xmm8
00007b629addd283  vmovaps [rsp+0x80], xmm9
00007b629addd28c  vmovaps [rsp+0x90], xmm10
00007b629addd295  vmovaps [rsp+0xA0], xmm11
00007b629addd29e  vmovaps [rsp+0xB0], xmm12
00007b629addd2a7  vmovaps [rsp+0xC0], xmm13
00007b629addd2b0  vmovaps [rsp+0xD0], xmm14
00007b629addd2b9  vmovaps [rsp+0xE0], xmm15
00007b629addd2c2  sub rsp, 0x30
00007b629addd2c6  movaps [rsp], xmm4
00007b629addd2ca  movaps [rsp+0x10], xmm9
00007b629addd2d0  movaps [rsp+0x20], xmm8
00007b629addd2d6  lea rdi, [rsp]
00007b629addd2da  mov esi, 0x00
00007b629addd2df  mov rax, 0x583FED93F530
00007b629addd2e9  call rax
00007b629addd2eb  movaps xmm4, [rsp]
00007b629addd2ef  add rsp, 0x30
00007b629addd2f3  vmovaps xmm0, [rsp]
00007b629addd2f8  vmovaps xmm1, [rsp+0x10]
00007b629addd2fe  vmovaps xmm2, [rsp+0x20]
00007b629addd304  vmovaps xmm3, [rsp+0x30]
00007b629addd30a  vmovaps xmm5, [rsp+0x40]
00007b629addd310  vmovaps xmm6, [rsp+0x50]
00007b629addd316  vmovaps xmm7, [rsp+0x60]
00007b629addd31c  vmovaps xmm8, [rsp+0x70]
00007b629addd322  vmovaps xmm9, [rsp+0x80]
00007b629addd32b  vmovaps xmm10, [rsp+0x90]
00007b629addd334  vmovaps xmm11, [rsp+0xA0]
00007b629addd33d  vmovaps xmm12, [rsp+0xB0]
00007b629addd346  vmovaps xmm13, [rsp+0xC0]
00007b629addd34f  vmovaps xmm14, [rsp+0xD0]
00007b629addd358  vmovaps xmm15, [rsp+0xE0]
00007b629addd361  add rsp, 0xF0
00007b629addd368  pop r11
00007b629addd36a  pop r10
00007b629addd36c  pop r9
00007b629addd36e  pop r8
00007b629addd370  pop rsi
00007b629addd371  pop rdi
00007b629addd372  pop rdx
00007b629addd373  pop rcx
00007b629addd374  pop rax
00007b629addd375  add rsp, 0x08
00007b629addd379  jmp 0x00007B629ADDBC94
00007b629addd37e  sub rsp, 0x08
00007b629addd382  push rax
00007b629addd383  push rcx
00007b629addd384  push rdx
00007b629addd385  push rdi
00007b629addd386  push rsi
00007b629addd387  push r8
00007b629addd389  push r9
00007b629addd38b  push r10
00007b629addd38d  push r11
00007b629addd38f  sub rsp, 0xF0
00007b629addd396  vmovaps [rsp], xmm0
00007b629addd39b  vmovaps [rsp+0x10], xmm1
00007b629addd3a1  vmovaps [rsp+0x20], xmm2
00007b629addd3a7  vmovaps [rsp+0x30], xmm3
00007b629addd3ad  vmovaps [rsp+0x40], xmm4
00007b629addd3b3  vmovaps [rsp+0x50], xmm5
00007b629addd3b9  vmovaps [rsp+0x60], xmm6
00007b629addd3bf  vmovaps [rsp+0x70], xmm7
00007b629addd3c5  vmovaps [rsp+0x80], xmm8
00007b629addd3ce  vmovaps [rsp+0x90], xmm10
00007b629addd3d7  vmovaps [rsp+0xA0], xmm11
00007b629addd3e0  vmovaps [rsp+0xB0], xmm12
00007b629addd3e9  vmovaps [rsp+0xC0], xmm13
00007b629addd3f2  vmovaps [rsp+0xD0], xmm14
00007b629addd3fb  vmovaps [rsp+0xE0], xmm15
00007b629addd404  sub rsp, 0x30
00007b629addd408  movaps [rsp], xmm9
00007b629addd40d  movaps [rsp+0x10], xmm10
00007b629addd413  movaps [rsp+0x20], xmm8
00007b629addd419  lea rdi, [rsp]
00007b629addd41d  mov esi, 0x00
00007b629addd422  mov rax, 0x583FED93F530
00007b629addd42c  call rax
00007b629addd42e  movaps xmm9, [rsp]
00007b629addd433  add rsp, 0x30
00007b629addd437  vmovaps xmm0, [rsp]
00007b629addd43c  vmovaps xmm1, [rsp+0x10]
00007b629addd442  vmovaps xmm2, [rsp+0x20]
00007b629addd448  vmovaps xmm3, [rsp+0x30]
00007b629addd44e  vmovaps xmm4, [rsp+0x40]
00007b629addd454  vmovaps xmm5, [rsp+0x50]
00007b629addd45a  vmovaps xmm6, [rsp+0x60]
00007b629addd460  vmovaps xmm7, [rsp+0x70]
00007b629addd466  vmovaps xmm8, [rsp+0x80]
00007b629addd46f  vmovaps xmm10, [rsp+0x90]
00007b629addd478  vmovaps xmm11, [rsp+0xA0]
00007b629addd481  vmovaps xmm12, [rsp+0xB0]
00007b629addd48a  vmovaps xmm13, [rsp+0xC0]
00007b629addd493  vmovaps xmm14, [rsp+0xD0]
00007b629addd49c  vmovaps xmm15, [rsp+0xE0]
00007b629addd4a5  add rsp, 0xF0
00007b629addd4ac  pop r11
00007b629addd4ae  pop r10
00007b629addd4b0  pop r9
00007b629addd4b2  pop r8
00007b629addd4b4  pop rsi
00007b629addd4b5  pop rdi
00007b629addd4b6  pop rdx
00007b629addd4b7  pop rcx
00007b629addd4b8  pop rax
00007b629addd4b9  add rsp, 0x08
00007b629addd4bd  jmp 0x00007B629ADDBCAE
00007b629addd4c2  call 0x00007B629ACB52F0
00007b629addd4c7  jmp 0x00007B629ADDBDC8
00007b629addd4cc  call 0x00007B629ACB52F0
00007b629addd4d1  jmp 0x00007B629ADDBDDE
00007b629addd4d6  sub rsp, 0x08
00007b629addd4da  push rax
00007b629addd4db  push rcx
00007b629addd4dc  push rdx
00007b629addd4dd  push rdi
00007b629addd4de  push rsi
00007b629addd4df  push r8
00007b629addd4e1  push r9
00007b629addd4e3  push r10
00007b629addd4e5  push r11
00007b629addd4e7  sub rsp, 0xF0
00007b629addd4ee  vmovaps [rsp], xmm0
00007b629addd4f3  vmovaps [rsp+0x10], xmm2
00007b629addd4f9  vmovaps [rsp+0x20], xmm3
00007b629addd4ff  vmovaps [rsp+0x30], xmm4
00007b629addd505  vmovaps [rsp+0x40], xmm5
00007b629addd50b  vmovaps [rsp+0x50], xmm6
00007b629addd511  vmovaps [rsp+0x60], xmm7
00007b629addd517  vmovaps [rsp+0x70], xmm8
00007b629addd51d  vmovaps [rsp+0x80], xmm9
00007b629addd526  vmovaps [rsp+0x90], xmm10
00007b629addd52f  vmovaps [rsp+0xA0], xmm11
00007b629addd538  vmovaps [rsp+0xB0], xmm12
00007b629addd541  vmovaps [rsp+0xC0], xmm13
00007b629addd54a  vmovaps [rsp+0xD0], xmm14
00007b629addd553  vmovaps [rsp+0xE0], xmm15
00007b629addd55c  sub rsp, 0x30
00007b629addd560  movaps [rsp], xmm1
00007b629addd564  movaps [rsp+0x10], xmm6
00007b629addd569  movaps [rsp+0x20], xmm15
00007b629addd56f  lea rdi, [rsp]
00007b629addd573  mov esi, 0x00
00007b629addd578  mov rax, 0x583FED93F530
00007b629addd582  call rax
00007b629addd584  movaps xmm1, [rsp]
00007b629addd588  add rsp, 0x30
00007b629addd58c  vmovaps xmm0, [rsp]
00007b629addd591  vmovaps xmm2, [rsp+0x10]
00007b629addd597  vmovaps xmm3, [rsp+0x20]
00007b629addd59d  vmovaps xmm4, [rsp+0x30]
00007b629addd5a3  vmovaps xmm5, [rsp+0x40]
00007b629addd5a9  vmovaps xmm6, [rsp+0x50]
00007b629addd5af  vmovaps xmm7, [rsp+0x60]
00007b629addd5b5  vmovaps xmm8, [rsp+0x70]
00007b629addd5bb  vmovaps xmm9, [rsp+0x80]
00007b629addd5c4  vmovaps xmm10, [rsp+0x90]
00007b629addd5cd  vmovaps xmm11, [rsp+0xA0]
00007b629addd5d6  vmovaps xmm12, [rsp+0xB0]
00007b629addd5df  vmovaps xmm13, [rsp+0xC0]
00007b629addd5e8  vmovaps xmm14, [rsp+0xD0]
00007b629addd5f1  vmovaps xmm15, [rsp+0xE0]
00007b629addd5fa  add rsp, 0xF0
00007b629addd601  pop r11
00007b629addd603  pop r10
00007b629addd605  pop r9
00007b629addd607  pop r8
00007b629addd609  pop rsi
00007b629addd60a  pop rdi
00007b629addd60b  pop rdx
00007b629addd60c  pop rcx
00007b629addd60d  pop rax
00007b629addd60e  add rsp, 0x08
00007b629addd612  jmp 0x00007B629ADDBE1B
00007b629addd617  call 0x00007B629ACC4620
00007b629addd61c  jmp 0x00007B629ADDBE28
00007b629addd621  sub rsp, 0x08
00007b629addd625  push rax
00007b629addd626  push rcx
00007b629addd627  push rdx
00007b629addd628  push rdi
00007b629addd629  push rsi
00007b629addd62a  push r8
00007b629addd62c  push r9
00007b629addd62e  push r10
00007b629addd630  push r11
00007b629addd632  sub rsp, 0xF0
00007b629addd639  vmovaps [rsp], xmm0
00007b629addd63e  vmovaps [rsp+0x10], xmm1
00007b629addd644  vmovaps [rsp+0x20], xmm2
00007b629addd64a  vmovaps [rsp+0x30], xmm3
00007b629addd650  vmovaps [rsp+0x40], xmm4
00007b629addd656  vmovaps [rsp+0x50], xmm5
00007b629addd65c  vmovaps [rsp+0x60], xmm6
00007b629addd662  vmovaps [rsp+0x70], xmm7
00007b629addd668  vmovaps [rsp+0x80], xmm8
00007b629addd671  vmovaps [rsp+0x90], xmm9
00007b629addd67a  vmovaps [rsp+0xA0], xmm10
00007b629addd683  vmovaps [rsp+0xB0], xmm11
00007b629addd68c  vmovaps [rsp+0xC0], xmm12
00007b629addd695  vmovaps [rsp+0xD0], xmm13
00007b629addd69e  vmovaps [rsp+0xE0], xmm15
00007b629addd6a7  sub rsp, 0x30
00007b629addd6ab  movaps [rsp], xmm14
00007b629addd6b0  movaps [rsp+0x10], xmm4
00007b629addd6b5  movaps [rsp+0x20], xmm3
00007b629addd6ba  lea rdi, [rsp]
00007b629addd6be  mov esi, 0x00
00007b629addd6c3  mov rax, 0x583FED93F530
00007b629addd6cd  call rax
00007b629addd6cf  movaps xmm14, [rsp]
00007b629addd6d4  add rsp, 0x30
00007b629addd6d8  vmovaps xmm0, [rsp]
00007b629addd6dd  vmovaps xmm1, [rsp+0x10]
00007b629addd6e3  vmovaps xmm2, [rsp+0x20]
00007b629addd6e9  vmovaps xmm3, [rsp+0x30]
00007b629addd6ef  vmovaps xmm4, [rsp+0x40]
00007b629addd6f5  vmovaps xmm5, [rsp+0x50]
00007b629addd6fb  vmovaps xmm6, [rsp+0x60]
00007b629addd701  vmovaps xmm7, [rsp+0x70]
00007b629addd707  vmovaps xmm8, [rsp+0x80]
00007b629addd710  vmovaps xmm9, [rsp+0x90]
00007b629addd719  vmovaps xmm10, [rsp+0xA0]
00007b629addd722  vmovaps xmm11, [rsp+0xB0]
00007b629addd72b  vmovaps xmm12, [rsp+0xC0]
00007b629addd734  vmovaps xmm13, [rsp+0xD0]
00007b629addd73d  vmovaps xmm15, [rsp+0xE0]
00007b629addd746  add rsp, 0xF0
00007b629addd74d  pop r11
00007b629addd74f  pop r10
00007b629addd751  pop r9
00007b629addd753  pop r8
00007b629addd755  pop rsi
00007b629addd756  pop rdi
00007b629addd757  pop rdx
00007b629addd758  pop rcx
00007b629addd759  pop rax
00007b629addd75a  add rsp, 0x08
00007b629addd75e  jmp 0x00007B629ADDBE42
00007b629addd763  sub rsp, 0x08
00007b629addd767  push rax
00007b629addd768  push rcx
00007b629addd769  push rdx
00007b629addd76a  push rdi
00007b629addd76b  push rsi
00007b629addd76c  push r8
00007b629addd76e  push r9
00007b629addd770  push r10
00007b629addd772  push r11
00007b629addd774  sub rsp, 0xF0
00007b629addd77b  vmovaps [rsp], xmm0
00007b629addd780  vmovaps [rsp+0x10], xmm1
00007b629addd786  vmovaps [rsp+0x20], xmm2
00007b629addd78c  vmovaps [rsp+0x30], xmm3
00007b629addd792  vmovaps [rsp+0x40], xmm4
00007b629addd798  vmovaps [rsp+0x50], xmm5
00007b629addd79e  vmovaps [rsp+0x60], xmm7
00007b629addd7a4  vmovaps [rsp+0x70], xmm8
00007b629addd7aa  vmovaps [rsp+0x80], xmm9
00007b629addd7b3  vmovaps [rsp+0x90], xmm10
00007b629addd7bc  vmovaps [rsp+0xA0], xmm11
00007b629addd7c5  vmovaps [rsp+0xB0], xmm12
00007b629addd7ce  vmovaps [rsp+0xC0], xmm13
00007b629addd7d7  vmovaps [rsp+0xD0], xmm14
00007b629addd7e0  vmovaps [rsp+0xE0], xmm15
00007b629addd7e9  sub rsp, 0x30
00007b629addd7ed  movaps [rsp], xmm6
00007b629addd7f1  movaps [rsp+0x10], xmm9
00007b629addd7f7  movaps [rsp+0x20], xmm7
00007b629addd7fc  lea rdi, [rsp]
00007b629addd800  mov esi, 0x00
00007b629addd805  mov rax, 0x583FED93F530
00007b629addd80f  call rax
00007b629addd811  movaps xmm6, [rsp]
00007b629addd815  add rsp, 0x30
00007b629addd819  vmovaps xmm0, [rsp]
00007b629addd81e  vmovaps xmm1, [rsp+0x10]
00007b629addd824  vmovaps xmm2, [rsp+0x20]
00007b629addd82a  vmovaps xmm3, [rsp+0x30]
00007b629addd830  vmovaps xmm4, [rsp+0x40]
00007b629addd836  vmovaps xmm5, [rsp+0x50]
00007b629addd83c  vmovaps xmm7, [rsp+0x60]
00007b629addd842  vmovaps xmm8, [rsp+0x70]
00007b629addd848  vmovaps xmm9, [rsp+0x80]
00007b629addd851  vmovaps xmm10, [rsp+0x90]
00007b629addd85a  vmovaps xmm11, [rsp+0xA0]
00007b629addd863  vmovaps xmm12, [rsp+0xB0]
00007b629addd86c  vmovaps xmm13, [rsp+0xC0]
00007b629addd875  vmovaps xmm14, [rsp+0xD0]
00007b629addd87e  vmovaps xmm15, [rsp+0xE0]
00007b629addd887  add rsp, 0xF0
00007b629addd88e  pop r11
00007b629addd890  pop r10
00007b629addd892  pop r9
00007b629addd894  pop r8
00007b629addd896  pop rsi
00007b629addd897  pop rdi
00007b629addd898  pop rdx
00007b629addd899  pop rcx
00007b629addd89a  pop rax
00007b629addd89b  add rsp, 0x08
00007b629addd89f  jmp 0x00007B629ADDBE5A
00007b629addd8a4  sub rsp, 0x08
00007b629addd8a8  push rax
00007b629addd8a9  push rcx
00007b629addd8aa  push rdx
00007b629addd8ab  push rdi
00007b629addd8ac  push rsi
00007b629addd8ad  push r8
00007b629addd8af  push r9
00007b629addd8b1  push r10
00007b629addd8b3  push r11
00007b629addd8b5  sub rsp, 0xF0
00007b629addd8bc  vmovaps [rsp], xmm0
00007b629addd8c1  vmovaps [rsp+0x10], xmm1
00007b629addd8c7  vmovaps [rsp+0x20], xmm2
00007b629addd8cd  vmovaps [rsp+0x30], xmm3
00007b629addd8d3  vmovaps [rsp+0x40], xmm4
00007b629addd8d9  vmovaps [rsp+0x50], xmm5
00007b629addd8df  vmovaps [rsp+0x60], xmm6
00007b629addd8e5  vmovaps [rsp+0x70], xmm8
00007b629addd8eb  vmovaps [rsp+0x80], xmm9
00007b629addd8f4  vmovaps [rsp+0x90], xmm10
00007b629addd8fd  vmovaps [rsp+0xA0], xmm11
00007b629addd906  vmovaps [rsp+0xB0], xmm12
00007b629addd90f  vmovaps [rsp+0xC0], xmm13
00007b629addd918  vmovaps [rsp+0xD0], xmm14
00007b629addd921  vmovaps [rsp+0xE0], xmm15
00007b629addd92a  sub rsp, 0x30
00007b629addd92e  movaps [rsp], xmm7
00007b629addd932  movaps [rsp+0x10], xmm4
00007b629addd937  movaps [rsp+0x20], xmm9
00007b629addd93d  lea rdi, [rsp]
00007b629addd941  mov esi, 0x00
00007b629addd946  mov rax, 0x583FED93F530
00007b629addd950  call rax
00007b629addd952  movaps xmm7, [rsp]
00007b629addd956  add rsp, 0x30
00007b629addd95a  vmovaps xmm0, [rsp]
00007b629addd95f  vmovaps xmm1, [rsp+0x10]
00007b629addd965  vmovaps xmm2, [rsp+0x20]
00007b629addd96b  vmovaps xmm3, [rsp+0x30]
00007b629addd971  vmovaps xmm4, [rsp+0x40]
00007b629addd977  vmovaps xmm5, [rsp+0x50]
00007b629addd97d  vmovaps xmm6, [rsp+0x60]
00007b629addd983  vmovaps xmm8, [rsp+0x70]
00007b629addd989  vmovaps xmm9, [rsp+0x80]
00007b629addd992  vmovaps xmm10, [rsp+0x90]
00007b629addd99b  vmovaps xmm11, [rsp+0xA0]
00007b629addd9a4  vmovaps xmm12, [rsp+0xB0]
00007b629addd9ad  vmovaps xmm13, [rsp+0xC0]
00007b629addd9b6  vmovaps xmm14, [rsp+0xD0]
00007b629addd9bf  vmovaps xmm15, [rsp+0xE0]
00007b629addd9c8  add rsp, 0xF0
00007b629addd9cf  pop r11
00007b629addd9d1  pop r10
00007b629addd9d3  pop r9
00007b629addd9d5  pop r8
00007b629addd9d7  pop rsi
00007b629addd9d8  pop rdi
00007b629addd9d9  pop rdx
00007b629addd9da  pop rcx
00007b629addd9db  pop rax
00007b629addd9dc  add rsp, 0x08
00007b629addd9e0  jmp 0x00007B629ADDBE87
00007b629addd9e5  sub rsp, 0x08
00007b629addd9e9  push rax
00007b629addd9ea  push rcx
00007b629addd9eb  push rdx
00007b629addd9ec  push rdi
00007b629addd9ed  push rsi
00007b629addd9ee  push r8
00007b629addd9f0  push r9
00007b629addd9f2  push r10
00007b629addd9f4  push r11
00007b629addd9f6  sub rsp, 0xF0
00007b629addd9fd  vmovaps [rsp], xmm0
00007b629addda02  vmovaps [rsp+0x10], xmm1
00007b629addda08  vmovaps [rsp+0x20], xmm2
00007b629addda0e  vmovaps [rsp+0x30], xmm3
00007b629addda14  vmovaps [rsp+0x40], xmm5
00007b629addda1a  vmovaps [rsp+0x50], xmm6
00007b629addda20  vmovaps [rsp+0x60], xmm7
00007b629addda26  vmovaps [rsp+0x70], xmm8
00007b629addda2c  vmovaps [rsp+0x80], xmm9
00007b629addda35  vmovaps [rsp+0x90], xmm10
00007b629addda3e  vmovaps [rsp+0xA0], xmm11
00007b629addda47  vmovaps [rsp+0xB0], xmm12
00007b629addda50  vmovaps [rsp+0xC0], xmm13
00007b629addda59  vmovaps [rsp+0xD0], xmm14
00007b629addda62  vmovaps [rsp+0xE0], xmm15
00007b629addda6b  sub rsp, 0x30
00007b629addda6f  movaps [rsp], xmm4
00007b629addda73  movaps [rsp+0x10], xmm15
00007b629addda79  movaps [rsp+0x20], xmm9
00007b629addda7f  lea rdi, [rsp]
00007b629addda83  mov esi, 0x00
00007b629addda88  mov rax, 0x583FED93F530
00007b629addda92  call rax
00007b629addda94  movaps xmm4, [rsp]
00007b629addda98  add rsp, 0x30
00007b629addda9c  vmovaps xmm0, [rsp]
00007b629adddaa1  vmovaps xmm1, [rsp+0x10]
00007b629adddaa7  vmovaps xmm2, [rsp+0x20]
00007b629adddaad  vmovaps xmm3, [rsp+0x30]
00007b629adddab3  vmovaps xmm5, [rsp+0x40]
00007b629adddab9  vmovaps xmm6, [rsp+0x50]
00007b629adddabf  vmovaps xmm7, [rsp+0x60]
00007b629adddac5  vmovaps xmm8, [rsp+0x70]
00007b629adddacb  vmovaps xmm9, [rsp+0x80]
00007b629adddad4  vmovaps xmm10, [rsp+0x90]
00007b629adddadd  vmovaps xmm11, [rsp+0xA0]
00007b629adddae6  vmovaps xmm12, [rsp+0xB0]
00007b629adddaef  vmovaps xmm13, [rsp+0xC0]
00007b629adddaf8  vmovaps xmm14, [rsp+0xD0]
00007b629adddb01  vmovaps xmm15, [rsp+0xE0]
00007b629adddb0a  add rsp, 0xF0
00007b629adddb11  pop r11
00007b629adddb13  pop r10
00007b629adddb15  pop r9
00007b629adddb17  pop r8
00007b629adddb19  pop rsi
00007b629adddb1a  pop rdi
00007b629adddb1b  pop rdx
00007b629adddb1c  pop rcx
00007b629adddb1d  pop rax
00007b629adddb1e  add rsp, 0x08
00007b629adddb22  jmp 0x00007B629ADDBEAC
00007b629adddb27  call 0x00007B629ACC4620
00007b629adddb2c  jmp 0x00007B629ADDBEB9
00007b629adddb31  sub rsp, 0x08
00007b629adddb35  push rax
00007b629adddb36  push rcx
00007b629adddb37  push rdx
00007b629adddb38  push rdi
00007b629adddb39  push rsi
00007b629adddb3a  push r8
00007b629adddb3c  push r9
00007b629adddb3e  push r10
00007b629adddb40  push r11
00007b629adddb42  sub rsp, 0xF0
00007b629adddb49  vmovaps [rsp], xmm0
00007b629adddb4e  vmovaps [rsp+0x10], xmm1
00007b629adddb54  vmovaps [rsp+0x20], xmm2
00007b629adddb5a  vmovaps [rsp+0x30], xmm4
00007b629adddb60  vmovaps [rsp+0x40], xmm5
00007b629adddb66  vmovaps [rsp+0x50], xmm6
00007b629adddb6c  vmovaps [rsp+0x60], xmm7
00007b629adddb72  vmovaps [rsp+0x70], xmm8
00007b629adddb78  vmovaps [rsp+0x80], xmm9
00007b629adddb81  vmovaps [rsp+0x90], xmm10
00007b629adddb8a  vmovaps [rsp+0xA0], xmm11
00007b629adddb93  vmovaps [rsp+0xB0], xmm12
00007b629adddb9c  vmovaps [rsp+0xC0], xmm13
00007b629adddba5  vmovaps [rsp+0xD0], xmm14
00007b629adddbae  vmovaps [rsp+0xE0], xmm15
00007b629adddbb7  sub rsp, 0x30
00007b629adddbbb  movaps [rsp], xmm3
00007b629adddbbf  movaps [rsp+0x10], xmm1
00007b629adddbc4  movaps [rsp+0x20], xmm9
00007b629adddbca  lea rdi, [rsp]
00007b629adddbce  mov esi, 0x00
00007b629adddbd3  mov rax, 0x583FED93F530
00007b629adddbdd  call rax
00007b629adddbdf  movaps xmm3, [rsp]
00007b629adddbe3  add rsp, 0x30
00007b629adddbe7  vmovaps xmm0, [rsp]
00007b629adddbec  vmovaps xmm1, [rsp+0x10]
00007b629adddbf2  vmovaps xmm2, [rsp+0x20]
00007b629adddbf8  vmovaps xmm4, [rsp+0x30]
00007b629adddbfe  vmovaps xmm5, [rsp+0x40]
00007b629adddc04  vmovaps xmm6, [rsp+0x50]
00007b629adddc0a  vmovaps xmm7, [rsp+0x60]
00007b629adddc10  vmovaps xmm8, [rsp+0x70]
00007b629adddc16  vmovaps xmm9, [rsp+0x80]
00007b629adddc1f  vmovaps xmm10, [rsp+0x90]
00007b629adddc28  vmovaps xmm11, [rsp+0xA0]
00007b629adddc31  vmovaps xmm12, [rsp+0xB0]
00007b629adddc3a  vmovaps xmm13, [rsp+0xC0]
00007b629adddc43  vmovaps xmm14, [rsp+0xD0]
00007b629adddc4c  vmovaps xmm15, [rsp+0xE0]
00007b629adddc55  add rsp, 0xF0
00007b629adddc5c  pop r11
00007b629adddc5e  pop r10
00007b629adddc60  pop r9
00007b629adddc62  pop r8
00007b629adddc64  pop rsi
00007b629adddc65  pop rdi
00007b629adddc66  pop rdx
00007b629adddc67  pop rcx
00007b629adddc68  pop rax
00007b629adddc69  add rsp, 0x08
00007b629adddc6d  jmp 0x00007B629ADDBEF6
00007b629adddc72  sub rsp, 0x08
00007b629adddc76  push rax
00007b629adddc77  push rcx
00007b629adddc78  push rdx
00007b629adddc79  push rdi
00007b629adddc7a  push rsi
00007b629adddc7b  push r8
00007b629adddc7d  push r9
00007b629adddc7f  push r10
00007b629adddc81  push r11
00007b629adddc83  sub rsp, 0xF0
00007b629adddc8a  vmovaps [rsp], xmm0
00007b629adddc8f  vmovaps [rsp+0x10], xmm2
00007b629adddc95  vmovaps [rsp+0x20], xmm3
00007b629adddc9b  vmovaps [rsp+0x30], xmm4
00007b629adddca1  vmovaps [rsp+0x40], xmm5
00007b629adddca7  vmovaps [rsp+0x50], xmm6
00007b629adddcad  vmovaps [rsp+0x60], xmm7
00007b629adddcb3  vmovaps [rsp+0x70], xmm8
00007b629adddcb9  vmovaps [rsp+0x80], xmm9
00007b629adddcc2  vmovaps [rsp+0x90], xmm10
00007b629adddccb  vmovaps [rsp+0xA0], xmm11
00007b629adddcd4  vmovaps [rsp+0xB0], xmm12
00007b629adddcdd  vmovaps [rsp+0xC0], xmm13
00007b629adddce6  vmovaps [rsp+0xD0], xmm14
00007b629adddcef  vmovaps [rsp+0xE0], xmm15
00007b629adddcf8  sub rsp, 0x30
00007b629adddcfc  movaps [rsp], xmm1
00007b629adddd00  movaps [rsp+0x10], xmm15
00007b629adddd06  movaps [rsp+0x20], xmm9
00007b629adddd0c  lea rdi, [rsp]
00007b629adddd10  mov esi, 0x00
00007b629adddd15  mov rax, 0x583FED93F530
00007b629adddd1f  call rax
00007b629adddd21  movaps xmm1, [rsp]
00007b629adddd25  add rsp, 0x30
00007b629adddd29  vmovaps xmm0, [rsp]
00007b629adddd2e  vmovaps xmm2, [rsp+0x10]
00007b629adddd34  vmovaps xmm3, [rsp+0x20]
00007b629adddd3a  vmovaps xmm4, [rsp+0x30]
00007b629adddd40  vmovaps xmm5, [rsp+0x40]
00007b629adddd46  vmovaps xmm6, [rsp+0x50]
00007b629adddd4c  vmovaps xmm7, [rsp+0x60]
00007b629adddd52  vmovaps xmm8, [rsp+0x70]
00007b629adddd58  vmovaps xmm9, [rsp+0x80]
00007b629adddd61  vmovaps xmm10, [rsp+0x90]
00007b629adddd6a  vmovaps xmm11, [rsp+0xA0]
00007b629adddd73  vmovaps xmm12, [rsp+0xB0]
00007b629adddd7c  vmovaps xmm13, [rsp+0xC0]
00007b629adddd85  vmovaps xmm14, [rsp+0xD0]
00007b629adddd8e  vmovaps xmm15, [rsp+0xE0]
00007b629adddd97  add rsp, 0xF0
00007b629adddd9e  pop r11
00007b629adddda0  pop r10
00007b629adddda2  pop r9
00007b629adddda4  pop r8
00007b629adddda6  pop rsi
00007b629adddda7  pop rdi
00007b629adddda8  pop rdx
00007b629adddda9  pop rcx
00007b629addddaa  pop rax
00007b629addddab  add rsp, 0x08
00007b629addddaf  jmp 0x00007B629ADDBF7E
00007b629addddb4  call 0x00007B629ACC4620
00007b629addddb9  jmp 0x00007B629ADDBF8B
00007b629addddbe  sub rsp, 0x08
00007b629addddc2  push rax
00007b629addddc3  push rcx
00007b629addddc4  push rdx
00007b629addddc5  push rdi
00007b629addddc6  push rsi
00007b629addddc7  push r8
00007b629addddc9  push r9
00007b629addddcb  push r10
00007b629addddcd  push r11
00007b629addddcf  sub rsp, 0xF0
00007b629addddd6  vmovaps [rsp], xmm0
00007b629adddddb  vmovaps [rsp+0x10], xmm2
00007b629adddde1  vmovaps [rsp+0x20], xmm3
00007b629adddde7  vmovaps [rsp+0x30], xmm4
00007b629adddded  vmovaps [rsp+0x40], xmm5
00007b629addddf3  vmovaps [rsp+0x50], xmm6
00007b629addddf9  vmovaps [rsp+0x60], xmm7
00007b629addddff  vmovaps [rsp+0x70], xmm8
00007b629addde05  vmovaps [rsp+0x80], xmm9
00007b629addde0e  vmovaps [rsp+0x90], xmm10
00007b629addde17  vmovaps [rsp+0xA0], xmm11
00007b629addde20  vmovaps [rsp+0xB0], xmm12
00007b629addde29  vmovaps [rsp+0xC0], xmm13
00007b629addde32  vmovaps [rsp+0xD0], xmm14
00007b629addde3b  vmovaps [rsp+0xE0], xmm15
00007b629addde44  sub rsp, 0x30
00007b629addde48  movaps [rsp], xmm1
00007b629addde4c  movaps [rsp+0x10], xmm5
00007b629addde51  movaps [rsp+0x20], xmm7
00007b629addde56  lea rdi, [rsp]
00007b629addde5a  mov esi, 0x00
00007b629addde5f  mov rax, 0x583FED93F530
00007b629addde69  call rax
00007b629addde6b  movaps xmm1, [rsp]
00007b629addde6f  add rsp, 0x30
00007b629addde73  vmovaps xmm0, [rsp]
00007b629addde78  vmovaps xmm2, [rsp+0x10]
00007b629addde7e  vmovaps xmm3, [rsp+0x20]
00007b629addde84  vmovaps xmm4, [rsp+0x30]
00007b629addde8a  vmovaps xmm5, [rsp+0x40]
00007b629addde90  vmovaps xmm6, [rsp+0x50]
00007b629addde96  vmovaps xmm7, [rsp+0x60]
00007b629addde9c  vmovaps xmm8, [rsp+0x70]
00007b629adddea2  vmovaps xmm9, [rsp+0x80]
00007b629adddeab  vmovaps xmm10, [rsp+0x90]
00007b629adddeb4  vmovaps xmm11, [rsp+0xA0]
00007b629adddebd  vmovaps xmm12, [rsp+0xB0]
00007b629adddec6  vmovaps xmm13, [rsp+0xC0]
00007b629adddecf  vmovaps xmm14, [rsp+0xD0]
00007b629addded8  vmovaps xmm15, [rsp+0xE0]
00007b629adddee1  add rsp, 0xF0
00007b629adddee8  pop r11
00007b629adddeea  pop r10
00007b629adddeec  pop r9
00007b629adddeee  pop r8
00007b629adddef0  pop rsi
00007b629adddef1  pop rdi
00007b629adddef2  pop rdx
00007b629adddef3  pop rcx
00007b629adddef4  pop rax
00007b629adddef5  add rsp, 0x08
00007b629adddef9  jmp 0x00007B629ADDC030
00007b629adddefe  sub rsp, 0x08
00007b629adddf02  push rax
00007b629adddf03  push rcx
00007b629adddf04  push rdx
00007b629adddf05  push rdi
00007b629adddf06  push rsi
00007b629adddf07  push r8
00007b629adddf09  push r9
00007b629adddf0b  push r10
00007b629adddf0d  push r11
00007b629adddf0f  sub rsp, 0xF0
00007b629adddf16  vmovaps [rsp], xmm0
00007b629adddf1b  vmovaps [rsp+0x10], xmm1
00007b629adddf21  vmovaps [rsp+0x20], xmm2
00007b629adddf27  vmovaps [rsp+0x30], xmm3
00007b629adddf2d  vmovaps [rsp+0x40], xmm4
00007b629adddf33  vmovaps [rsp+0x50], xmm5
00007b629adddf39  vmovaps [rsp+0x60], xmm6
00007b629adddf3f  vmovaps [rsp+0x70], xmm8
00007b629adddf45  vmovaps [rsp+0x80], xmm9
00007b629adddf4e  vmovaps [rsp+0x90], xmm10
00007b629adddf57  vmovaps [rsp+0xA0], xmm11
00007b629adddf60  vmovaps [rsp+0xB0], xmm12
00007b629adddf69  vmovaps [rsp+0xC0], xmm13
00007b629adddf72  vmovaps [rsp+0xD0], xmm14
00007b629adddf7b  vmovaps [rsp+0xE0], xmm15
00007b629adddf84  sub rsp, 0x30
00007b629adddf88  movaps [rsp], xmm7
00007b629adddf8c  movaps [rsp+0x10], xmm5
00007b629adddf91  movaps [rsp+0x20], xmm15
00007b629adddf97  lea rdi, [rsp]
00007b629adddf9b  mov esi, 0x00
00007b629adddfa0  mov rax, 0x583FED93F530
00007b629adddfaa  call rax
00007b629adddfac  movaps xmm7, [rsp]
00007b629adddfb0  add rsp, 0x30
00007b629adddfb4  vmovaps xmm0, [rsp]
00007b629adddfb9  vmovaps xmm1, [rsp+0x10]
00007b629adddfbf  vmovaps xmm2, [rsp+0x20]
00007b629adddfc5  vmovaps xmm3, [rsp+0x30]
00007b629adddfcb  vmovaps xmm4, [rsp+0x40]
00007b629adddfd1  vmovaps xmm5, [rsp+0x50]
00007b629adddfd7  vmovaps xmm6, [rsp+0x60]
00007b629adddfdd  vmovaps xmm8, [rsp+0x70]
00007b629adddfe3  vmovaps xmm9, [rsp+0x80]
00007b629adddfec  vmovaps xmm10, [rsp+0x90]
00007b629adddff5  vmovaps xmm11, [rsp+0xA0]
00007b629adddffe  vmovaps xmm12, [rsp+0xB0]
00007b629adde007  vmovaps xmm13, [rsp+0xC0]
00007b629adde010  vmovaps xmm14, [rsp+0xD0]
00007b629adde019  vmovaps xmm15, [rsp+0xE0]
00007b629adde022  add rsp, 0xF0
00007b629adde029  pop r11
00007b629adde02b  pop r10
00007b629adde02d  pop r9
00007b629adde02f  pop r8
00007b629adde031  pop rsi
00007b629adde032  pop rdi
00007b629adde033  pop rdx
00007b629adde034  pop rcx
00007b629adde035  pop rax
00007b629adde036  add rsp, 0x08
00007b629adde03a  jmp 0x00007B629ADDC066
00007b629adde03f  call 0x00007B629ACB52F0
00007b629adde044  jmp 0x00007B629ADDC073
00007b629adde049  sub rsp, 0x08
00007b629adde04d  push rax
00007b629adde04e  push rcx
00007b629adde04f  push rdx
00007b629adde050  push rdi
00007b629adde051  push rsi
00007b629adde052  push r8
00007b629adde054  push r9
00007b629adde056  push r10
00007b629adde058  push r11
00007b629adde05a  sub rsp, 0xF0
00007b629adde061  vmovaps [rsp], xmm0
00007b629adde066  vmovaps [rsp+0x10], xmm1
00007b629adde06c  vmovaps [rsp+0x20], xmm2
00007b629adde072  vmovaps [rsp+0x30], xmm3
00007b629adde078  vmovaps [rsp+0x40], xmm4
00007b629adde07e  vmovaps [rsp+0x50], xmm5
00007b629adde084  vmovaps [rsp+0x60], xmm6
00007b629adde08a  vmovaps [rsp+0x70], xmm7
00007b629adde090  vmovaps [rsp+0x80], xmm8
00007b629adde099  vmovaps [rsp+0x90], xmm9
00007b629adde0a2  vmovaps [rsp+0xA0], xmm10
00007b629adde0ab  vmovaps [rsp+0xB0], xmm11
00007b629adde0b4  vmovaps [rsp+0xC0], xmm12
00007b629adde0bd  vmovaps [rsp+0xD0], xmm13
00007b629adde0c6  vmovaps [rsp+0xE0], xmm14
00007b629adde0cf  sub rsp, 0x30
00007b629adde0d3  movaps [rsp], xmm15
00007b629adde0d8  movaps [rsp+0x10], xmm5
00007b629adde0dd  movaps [rsp+0x20], xmm3
00007b629adde0e2  lea rdi, [rsp]
00007b629adde0e6  mov esi, 0x00
00007b629adde0eb  mov rax, 0x583FED93F530
00007b629adde0f5  call rax
00007b629adde0f7  movaps xmm15, [rsp]
00007b629adde0fc  add rsp, 0x30
00007b629adde100  vmovaps xmm0, [rsp]
00007b629adde105  vmovaps xmm1, [rsp+0x10]
00007b629adde10b  vmovaps xmm2, [rsp+0x20]
00007b629adde111  vmovaps xmm3, [rsp+0x30]
00007b629adde117  vmovaps xmm4, [rsp+0x40]
00007b629adde11d  vmovaps xmm5, [rsp+0x50]
00007b629adde123  vmovaps xmm6, [rsp+0x60]
00007b629adde129  vmovaps xmm7, [rsp+0x70]
00007b629adde12f  vmovaps xmm8, [rsp+0x80]
00007b629adde138  vmovaps xmm9, [rsp+0x90]
00007b629adde141  vmovaps xmm10, [rsp+0xA0]
00007b629adde14a  vmovaps xmm11, [rsp+0xB0]
00007b629adde153  vmovaps xmm12, [rsp+0xC0]
00007b629adde15c  vmovaps xmm13, [rsp+0xD0]
00007b629adde165  vmovaps xmm14, [rsp+0xE0]
00007b629adde16e  add rsp, 0xF0
00007b629adde175  pop r11
00007b629adde177  pop r10
00007b629adde179  pop r9
00007b629adde17b  pop r8
00007b629adde17d  pop rsi
00007b629adde17e  pop rdi
00007b629adde17f  pop rdx
00007b629adde180  pop rcx
00007b629adde181  pop rax
00007b629adde182  add rsp, 0x08
00007b629adde186  jmp 0x00007B629ADDC099
00007b629adde18b  sub rsp, 0x08
00007b629adde18f  push rax
00007b629adde190  push rcx
00007b629adde191  push rdx
00007b629adde192  push rdi
00007b629adde193  push rsi
00007b629adde194  push r8
00007b629adde196  push r9
00007b629adde198  push r10
00007b629adde19a  push r11
00007b629adde19c  sub rsp, 0xF0
00007b629adde1a3  vmovaps [rsp], xmm0
00007b629adde1a8  vmovaps [rsp+0x10], xmm2
00007b629adde1ae  vmovaps [rsp+0x20], xmm3
00007b629adde1b4  vmovaps [rsp+0x30], xmm4
00007b629adde1ba  vmovaps [rsp+0x40], xmm5
00007b629adde1c0  vmovaps [rsp+0x50], xmm6
00007b629adde1c6  vmovaps [rsp+0x60], xmm7
00007b629adde1cc  vmovaps [rsp+0x70], xmm8
00007b629adde1d2  vmovaps [rsp+0x80], xmm9
00007b629adde1db  vmovaps [rsp+0x90], xmm10
00007b629adde1e4  vmovaps [rsp+0xA0], xmm11
00007b629adde1ed  vmovaps [rsp+0xB0], xmm12
00007b629adde1f6  vmovaps [rsp+0xC0], xmm13
00007b629adde1ff  vmovaps [rsp+0xD0], xmm14
00007b629adde208  vmovaps [rsp+0xE0], xmm15
00007b629adde211  sub rsp, 0x30
00007b629adde215  movaps [rsp], xmm1
00007b629adde219  movaps [rsp+0x10], xmm5
00007b629adde21e  movaps [rsp+0x20], xmm4
00007b629adde223  lea rdi, [rsp]
00007b629adde227  mov esi, 0x00
00007b629adde22c  mov rax, 0x583FED93F530
00007b629adde236  call rax
00007b629adde238  movaps xmm1, [rsp]
00007b629adde23c  add rsp, 0x30
00007b629adde240  vmovaps xmm0, [rsp]
00007b629adde245  vmovaps xmm2, [rsp+0x10]
00007b629adde24b  vmovaps xmm3, [rsp+0x20]
00007b629adde251  vmovaps xmm4, [rsp+0x30]
00007b629adde257  vmovaps xmm5, [rsp+0x40]
00007b629adde25d  vmovaps xmm6, [rsp+0x50]
00007b629adde263  vmovaps xmm7, [rsp+0x60]
00007b629adde269  vmovaps xmm8, [rsp+0x70]
00007b629adde26f  vmovaps xmm9, [rsp+0x80]
00007b629adde278  vmovaps xmm10, [rsp+0x90]
00007b629adde281  vmovaps xmm11, [rsp+0xA0]
00007b629adde28a  vmovaps xmm12, [rsp+0xB0]
00007b629adde293  vmovaps xmm13, [rsp+0xC0]
00007b629adde29c  vmovaps xmm14, [rsp+0xD0]
00007b629adde2a5  vmovaps xmm15, [rsp+0xE0]
00007b629adde2ae  add rsp, 0xF0
00007b629adde2b5  pop r11
00007b629adde2b7  pop r10
00007b629adde2b9  pop r9
00007b629adde2bb  pop r8
00007b629adde2bd  pop rsi
00007b629adde2be  pop rdi
00007b629adde2bf  pop rdx
00007b629adde2c0  pop rcx
00007b629adde2c1  pop rax
00007b629adde2c2  add rsp, 0x08
00007b629adde2c6  jmp 0x00007B629ADDC0B9
00007b629adde2cb  sub rsp, 0x08
00007b629adde2cf  push rax
00007b629adde2d0  push rcx
00007b629adde2d1  push rdx
00007b629adde2d2  push rdi
00007b629adde2d3  push rsi
00007b629adde2d4  push r8
00007b629adde2d6  push r9
00007b629adde2d8  push r10
00007b629adde2da  push r11
00007b629adde2dc  sub rsp, 0xF0
00007b629adde2e3  vmovaps [rsp], xmm0
00007b629adde2e8  vmovaps [rsp+0x10], xmm1
00007b629adde2ee  vmovaps [rsp+0x20], xmm2
00007b629adde2f4  vmovaps [rsp+0x30], xmm3
00007b629adde2fa  vmovaps [rsp+0x40], xmm5
00007b629adde300  vmovaps [rsp+0x50], xmm6
00007b629adde306  vmovaps [rsp+0x60], xmm7
00007b629adde30c  vmovaps [rsp+0x70], xmm8
00007b629adde312  vmovaps [rsp+0x80], xmm9
00007b629adde31b  vmovaps [rsp+0x90], xmm10
00007b629adde324  vmovaps [rsp+0xA0], xmm11
00007b629adde32d  vmovaps [rsp+0xB0], xmm12
00007b629adde336  vmovaps [rsp+0xC0], xmm13
00007b629adde33f  vmovaps [rsp+0xD0], xmm14
00007b629adde348  vmovaps [rsp+0xE0], xmm15
00007b629adde351  sub rsp, 0x30
00007b629adde355  movaps [rsp], xmm4
00007b629adde359  movaps [rsp+0x10], xmm3
00007b629adde35e  movaps [rsp+0x20], xmm5
00007b629adde363  lea rdi, [rsp]
00007b629adde367  mov esi, 0x00
00007b629adde36c  mov rax, 0x583FED93F530
00007b629adde376  call rax
00007b629adde378  movaps xmm4, [rsp]
00007b629adde37c  add rsp, 0x30
00007b629adde380  vmovaps xmm0, [rsp]
00007b629adde385  vmovaps xmm1, [rsp+0x10]
00007b629adde38b  vmovaps xmm2, [rsp+0x20]
00007b629adde391  vmovaps xmm3, [rsp+0x30]
00007b629adde397  vmovaps xmm5, [rsp+0x40]
00007b629adde39d  vmovaps xmm6, [rsp+0x50]
00007b629adde3a3  vmovaps xmm7, [rsp+0x60]
00007b629adde3a9  vmovaps xmm8, [rsp+0x70]
00007b629adde3af  vmovaps xmm9, [rsp+0x80]
00007b629adde3b8  vmovaps xmm10, [rsp+0x90]
00007b629adde3c1  vmovaps xmm11, [rsp+0xA0]
00007b629adde3ca  vmovaps xmm12, [rsp+0xB0]
00007b629adde3d3  vmovaps xmm13, [rsp+0xC0]
00007b629adde3dc  vmovaps xmm14, [rsp+0xD0]
00007b629adde3e5  vmovaps xmm15, [rsp+0xE0]
00007b629adde3ee  add rsp, 0xF0
00007b629adde3f5  pop r11
00007b629adde3f7  pop r10
00007b629adde3f9  pop r9
00007b629adde3fb  pop r8
00007b629adde3fd  pop rsi
00007b629adde3fe  pop rdi
00007b629adde3ff  pop rdx
00007b629adde400  pop rcx
00007b629adde401  pop rax
00007b629adde402  add rsp, 0x08
00007b629adde406  jmp 0x00007B629ADDC107
00007b629adde40b  call 0x00007B629ACB52F0
00007b629adde410  jmp 0x00007B629ADDC114
00007b629adde415  sub rsp, 0x08
00007b629adde419  push rax
00007b629adde41a  push rcx
00007b629adde41b  push rdx
00007b629adde41c  push rdi
00007b629adde41d  push rsi
00007b629adde41e  push r8
00007b629adde420  push r9
00007b629adde422  push r10
00007b629adde424  push r11
00007b629adde426  sub rsp, 0xF0
00007b629adde42d  vmovaps [rsp], xmm0
00007b629adde432  vmovaps [rsp+0x10], xmm1
00007b629adde438  vmovaps [rsp+0x20], xmm2
00007b629adde43e  vmovaps [rsp+0x30], xmm3
00007b629adde444  vmovaps [rsp+0x40], xmm4
00007b629adde44a  vmovaps [rsp+0x50], xmm6
00007b629adde450  vmovaps [rsp+0x60], xmm7
00007b629adde456  vmovaps [rsp+0x70], xmm8
00007b629adde45c  vmovaps [rsp+0x80], xmm9
00007b629adde465  vmovaps [rsp+0x90], xmm10
00007b629adde46e  vmovaps [rsp+0xA0], xmm11
00007b629adde477  vmovaps [rsp+0xB0], xmm12
00007b629adde480  vmovaps [rsp+0xC0], xmm13
00007b629adde489  vmovaps [rsp+0xD0], xmm14
00007b629adde492  vmovaps [rsp+0xE0], xmm15
00007b629adde49b  sub rsp, 0x30
00007b629adde49f  movaps [rsp], xmm5
00007b629adde4a3  movaps [rsp+0x10], xmm6
00007b629adde4a8  movaps [rsp+0x20], xmm3
00007b629adde4ad  lea rdi, [rsp]
00007b629adde4b1  mov esi, 0x00
00007b629adde4b6  mov rax, 0x583FED93F530
00007b629adde4c0  call rax
00007b629adde4c2  movaps xmm5, [rsp]
00007b629adde4c6  add rsp, 0x30
00007b629adde4ca  vmovaps xmm0, [rsp]
00007b629adde4cf  vmovaps xmm1, [rsp+0x10]
00007b629adde4d5  vmovaps xmm2, [rsp+0x20]
00007b629adde4db  vmovaps xmm3, [rsp+0x30]
00007b629adde4e1  vmovaps xmm4, [rsp+0x40]
00007b629adde4e7  vmovaps xmm6, [rsp+0x50]
00007b629adde4ed  vmovaps xmm7, [rsp+0x60]
00007b629adde4f3  vmovaps xmm8, [rsp+0x70]
00007b629adde4f9  vmovaps xmm9, [rsp+0x80]
00007b629adde502  vmovaps xmm10, [rsp+0x90]
00007b629adde50b  vmovaps xmm11, [rsp+0xA0]
00007b629adde514  vmovaps xmm12, [rsp+0xB0]
00007b629adde51d  vmovaps xmm13, [rsp+0xC0]
00007b629adde526  vmovaps xmm14, [rsp+0xD0]
00007b629adde52f  vmovaps xmm15, [rsp+0xE0]
00007b629adde538  add rsp, 0xF0
00007b629adde53f  pop r11
00007b629adde541  pop r10
00007b629adde543  pop r9
00007b629adde545  pop r8
00007b629adde547  pop rsi
00007b629adde548  pop rdi
00007b629adde549  pop rdx
00007b629adde54a  pop rcx
00007b629adde54b  pop rax
00007b629adde54c  add rsp, 0x08
00007b629adde550  jmp 0x00007B629ADDC13A
00007b629adde555  sub rsp, 0x08
00007b629adde559  push rax
00007b629adde55a  push rcx
00007b629adde55b  push rdx
00007b629adde55c  push rdi
00007b629adde55d  push rsi
00007b629adde55e  push r8
00007b629adde560  push r9
00007b629adde562  push r10
00007b629adde564  push r11
00007b629adde566  sub rsp, 0xF0
00007b629adde56d  vmovaps [rsp], xmm0
00007b629adde572  vmovaps [rsp+0x10], xmm1
00007b629adde578  vmovaps [rsp+0x20], xmm2
00007b629adde57e  vmovaps [rsp+0x30], xmm3
00007b629adde584  vmovaps [rsp+0x40], xmm4
00007b629adde58a  vmovaps [rsp+0x50], xmm5
00007b629adde590  vmovaps [rsp+0x60], xmm7
00007b629adde596  vmovaps [rsp+0x70], xmm8
00007b629adde59c  vmovaps [rsp+0x80], xmm9
00007b629adde5a5  vmovaps [rsp+0x90], xmm10
00007b629adde5ae  vmovaps [rsp+0xA0], xmm11
00007b629adde5b7  vmovaps [rsp+0xB0], xmm12
00007b629adde5c0  vmovaps [rsp+0xC0], xmm13
00007b629adde5c9  vmovaps [rsp+0xD0], xmm14
00007b629adde5d2  vmovaps [rsp+0xE0], xmm15
00007b629adde5db  sub rsp, 0x30
00007b629adde5df  movaps [rsp], xmm6
00007b629adde5e3  movaps [rsp+0x10], xmm9
00007b629adde5e9  movaps [rsp+0x20], xmm1
00007b629adde5ee  lea rdi, [rsp]
00007b629adde5f2  mov esi, 0x00
00007b629adde5f7  mov rax, 0x583FED93F530
00007b629adde601  call rax
00007b629adde603  movaps xmm6, [rsp]
00007b629adde607  add rsp, 0x30
00007b629adde60b  vmovaps xmm0, [rsp]
00007b629adde610  vmovaps xmm1, [rsp+0x10]
00007b629adde616  vmovaps xmm2, [rsp+0x20]
00007b629adde61c  vmovaps xmm3, [rsp+0x30]
00007b629adde622  vmovaps xmm4, [rsp+0x40]
00007b629adde628  vmovaps xmm5, [rsp+0x50]
00007b629adde62e  vmovaps xmm7, [rsp+0x60]
00007b629adde634  vmovaps xmm8, [rsp+0x70]
00007b629adde63a  vmovaps xmm9, [rsp+0x80]
00007b629adde643  vmovaps xmm10, [rsp+0x90]
00007b629adde64c  vmovaps xmm11, [rsp+0xA0]
00007b629adde655  vmovaps xmm12, [rsp+0xB0]
00007b629adde65e  vmovaps xmm13, [rsp+0xC0]
00007b629adde667  vmovaps xmm14, [rsp+0xD0]
00007b629adde670  vmovaps xmm15, [rsp+0xE0]
00007b629adde679  add rsp, 0xF0
00007b629adde680  pop r11
00007b629adde682  pop r10
00007b629adde684  pop r9
00007b629adde686  pop r8
00007b629adde688  pop rsi
00007b629adde689  pop rdi
00007b629adde68a  pop rdx
00007b629adde68b  pop rcx
00007b629adde68c  pop rax
00007b629adde68d  add rsp, 0x08
00007b629adde691  jmp 0x00007B629ADDC15E
00007b629adde696  sub rsp, 0x08
00007b629adde69a  push rax
00007b629adde69b  push rcx
00007b629adde69c  push rdx
00007b629adde69d  push rdi
00007b629adde69e  push rsi
00007b629adde69f  push r8
00007b629adde6a1  push r9
00007b629adde6a3  push r10
00007b629adde6a5  push r11
00007b629adde6a7  sub rsp, 0xF0
00007b629adde6ae  vmovaps [rsp], xmm0
00007b629adde6b3  vmovaps [rsp+0x10], xmm1
00007b629adde6b9  vmovaps [rsp+0x20], xmm2
00007b629adde6bf  vmovaps [rsp+0x30], xmm3
00007b629adde6c5  vmovaps [rsp+0x40], xmm4
00007b629adde6cb  vmovaps [rsp+0x50], xmm5
00007b629adde6d1  vmovaps [rsp+0x60], xmm6
00007b629adde6d7  vmovaps [rsp+0x70], xmm7
00007b629adde6dd  vmovaps [rsp+0x80], xmm8
00007b629adde6e6  vmovaps [rsp+0x90], xmm10
00007b629adde6ef  vmovaps [rsp+0xA0], xmm11
00007b629adde6f8  vmovaps [rsp+0xB0], xmm12
00007b629adde701  vmovaps [rsp+0xC0], xmm13
00007b629adde70a  vmovaps [rsp+0xD0], xmm14
00007b629adde713  vmovaps [rsp+0xE0], xmm15
00007b629adde71c  sub rsp, 0x30
00007b629adde720  movaps [rsp], xmm9
00007b629adde725  movaps [rsp+0x10], xmm3
00007b629adde72a  movaps [rsp+0x20], xmm1
00007b629adde72f  lea rdi, [rsp]
00007b629adde733  mov esi, 0x00
00007b629adde738  mov rax, 0x583FED93F530
00007b629adde742  call rax
00007b629adde744  movaps xmm9, [rsp]
00007b629adde749  add rsp, 0x30
00007b629adde74d  vmovaps xmm0, [rsp]
00007b629adde752  vmovaps xmm1, [rsp+0x10]
00007b629adde758  vmovaps xmm2, [rsp+0x20]
00007b629adde75e  vmovaps xmm3, [rsp+0x30]
00007b629adde764  vmovaps xmm4, [rsp+0x40]
00007b629adde76a  vmovaps xmm5, [rsp+0x50]
00007b629adde770  vmovaps xmm6, [rsp+0x60]
00007b629adde776  vmovaps xmm7, [rsp+0x70]
00007b629adde77c  vmovaps xmm8, [rsp+0x80]
00007b629adde785  vmovaps xmm10, [rsp+0x90]
00007b629adde78e  vmovaps xmm11, [rsp+0xA0]
00007b629adde797  vmovaps xmm12, [rsp+0xB0]
00007b629adde7a0  vmovaps xmm13, [rsp+0xC0]
00007b629adde7a9  vmovaps xmm14, [rsp+0xD0]
00007b629adde7b2  vmovaps xmm15, [rsp+0xE0]
00007b629adde7bb  add rsp, 0xF0
00007b629adde7c2  pop r11
00007b629adde7c4  pop r10
00007b629adde7c6  pop r9
00007b629adde7c8  pop r8
00007b629adde7ca  pop rsi
00007b629adde7cb  pop rdi
00007b629adde7cc  pop rdx
00007b629adde7cd  pop rcx
00007b629adde7ce  pop rax
00007b629adde7cf  add rsp, 0x08
00007b629adde7d3  jmp 0x00007B629ADDC1AA
00007b629adde7d8  call 0x00007B629ACB52F0
00007b629adde7dd  jmp 0x00007B629ADDC1B7
00007b629adde7e2  sub rsp, 0x08
00007b629adde7e6  push rax
00007b629adde7e7  push rcx
00007b629adde7e8  push rdx
00007b629adde7e9  push rdi
00007b629adde7ea  push rsi
00007b629adde7eb  push r8
00007b629adde7ed  push r9
00007b629adde7ef  push r10
00007b629adde7f1  push r11
00007b629adde7f3  sub rsp, 0xF0
00007b629adde7fa  vmovaps [rsp], xmm0
00007b629adde7ff  vmovaps [rsp+0x10], xmm1
00007b629adde805  vmovaps [rsp+0x20], xmm2
00007b629adde80b  vmovaps [rsp+0x30], xmm3
00007b629adde811  vmovaps [rsp+0x40], xmm4
00007b629adde817  vmovaps [rsp+0x50], xmm5
00007b629adde81d  vmovaps [rsp+0x60], xmm6
00007b629adde823  vmovaps [rsp+0x70], xmm7
00007b629adde829  vmovaps [rsp+0x80], xmm8
00007b629adde832  vmovaps [rsp+0x90], xmm9
00007b629adde83b  vmovaps [rsp+0xA0], xmm10
00007b629adde844  vmovaps [rsp+0xB0], xmm11
00007b629adde84d  vmovaps [rsp+0xC0], xmm12
00007b629adde856  vmovaps [rsp+0xD0], xmm13
00007b629adde85f  vmovaps [rsp+0xE0], xmm14
00007b629adde868  sub rsp, 0x30
00007b629adde86c  movaps [rsp], xmm15
00007b629adde871  movaps [rsp+0x10], xmm3
00007b629adde876  movaps [rsp+0x20], xmm7
00007b629adde87b  lea rdi, [rsp]
00007b629adde87f  mov esi, 0x00
00007b629adde884  mov rax, 0x583FED93F530
00007b629adde88e  call rax
00007b629adde890  movaps xmm15, [rsp]
00007b629adde895  add rsp, 0x30
00007b629adde899  vmovaps xmm0, [rsp]
00007b629adde89e  vmovaps xmm1, [rsp+0x10]
00007b629adde8a4  vmovaps xmm2, [rsp+0x20]
00007b629adde8aa  vmovaps xmm3, [rsp+0x30]
00007b629adde8b0  vmovaps xmm4, [rsp+0x40]
00007b629adde8b6  vmovaps xmm5, [rsp+0x50]
00007b629adde8bc  vmovaps xmm6, [rsp+0x60]
00007b629adde8c2  vmovaps xmm7, [rsp+0x70]
00007b629adde8c8  vmovaps xmm8, [rsp+0x80]
00007b629adde8d1  vmovaps xmm9, [rsp+0x90]
00007b629adde8da  vmovaps xmm10, [rsp+0xA0]
00007b629adde8e3  vmovaps xmm11, [rsp+0xB0]
00007b629adde8ec  vmovaps xmm12, [rsp+0xC0]
00007b629adde8f5  vmovaps xmm13, [rsp+0xD0]
00007b629adde8fe  vmovaps xmm14, [rsp+0xE0]
00007b629adde907  add rsp, 0xF0
00007b629adde90e  pop r11
00007b629adde910  pop r10
00007b629adde912  pop r9
00007b629adde914  pop r8
00007b629adde916  pop rsi
00007b629adde917  pop rdi
00007b629adde918  pop rdx
00007b629adde919  pop rcx
00007b629adde91a  pop rax
00007b629adde91b  add rsp, 0x08
00007b629adde91f  jmp 0x00007B629ADDC1E3
00007b629adde924  sub rsp, 0x08
00007b629adde928  push rax
00007b629adde929  push rcx
00007b629adde92a  push rdx
00007b629adde92b  push rdi
00007b629adde92c  push rsi
00007b629adde92d  push r8
00007b629adde92f  push r9
00007b629adde931  push r10
00007b629adde933  push r11
00007b629adde935  sub rsp, 0xF0
00007b629adde93c  vmovaps [rsp], xmm0
00007b629adde941  vmovaps [rsp+0x10], xmm1
00007b629adde947  vmovaps [rsp+0x20], xmm2
00007b629adde94d  vmovaps [rsp+0x30], xmm4
00007b629adde953  vmovaps [rsp+0x40], xmm5
00007b629adde959  vmovaps [rsp+0x50], xmm6
00007b629adde95f  vmovaps [rsp+0x60], xmm7
00007b629adde965  vmovaps [rsp+0x70], xmm8
00007b629adde96b  vmovaps [rsp+0x80], xmm9
00007b629adde974  vmovaps [rsp+0x90], xmm10
00007b629adde97d  vmovaps [rsp+0xA0], xmm11
00007b629adde986  vmovaps [rsp+0xB0], xmm12
00007b629adde98f  vmovaps [rsp+0xC0], xmm13
00007b629adde998  vmovaps [rsp+0xD0], xmm14
00007b629adde9a1  vmovaps [rsp+0xE0], xmm15
00007b629adde9aa  sub rsp, 0x30
00007b629adde9ae  movaps [rsp], xmm3
00007b629adde9b2  movaps [rsp+0x10], xmm1
00007b629adde9b7  movaps [rsp+0x20], xmm15
00007b629adde9bd  lea rdi, [rsp]
00007b629adde9c1  mov esi, 0x00
00007b629adde9c6  mov rax, 0x583FED93F530
00007b629adde9d0  call rax
00007b629adde9d2  movaps xmm3, [rsp]
00007b629adde9d6  add rsp, 0x30
00007b629adde9da  vmovaps xmm0, [rsp]
00007b629adde9df  vmovaps xmm1, [rsp+0x10]
00007b629adde9e5  vmovaps xmm2, [rsp+0x20]
00007b629adde9eb  vmovaps xmm4, [rsp+0x30]
00007b629adde9f1  vmovaps xmm5, [rsp+0x40]
00007b629adde9f7  vmovaps xmm6, [rsp+0x50]
00007b629adde9fd  vmovaps xmm7, [rsp+0x60]
00007b629addea03  vmovaps xmm8, [rsp+0x70]
00007b629addea09  vmovaps xmm9, [rsp+0x80]
00007b629addea12  vmovaps xmm10, [rsp+0x90]
00007b629addea1b  vmovaps xmm11, [rsp+0xA0]
00007b629addea24  vmovaps xmm12, [rsp+0xB0]
00007b629addea2d  vmovaps xmm13, [rsp+0xC0]
00007b629addea36  vmovaps xmm14, [rsp+0xD0]
00007b629addea3f  vmovaps xmm15, [rsp+0xE0]
00007b629addea48  add rsp, 0xF0
00007b629addea4f  pop r11
00007b629addea51  pop r10
00007b629addea53  pop r9
00007b629addea55  pop r8
00007b629addea57  pop rsi
00007b629addea58  pop rdi
00007b629addea59  pop rdx
00007b629addea5a  pop rcx
00007b629addea5b  pop rax
00007b629addea5c  add rsp, 0x08
00007b629addea60  jmp 0x00007B629ADDC272
00007b629addea65  call 0x00007B629ACB52F0
00007b629addea6a  jmp 0x00007B629ADDC27C
00007b629addea6f  sub rsp, 0x08
00007b629addea73  push rax
00007b629addea74  push rcx
00007b629addea75  push rdx
00007b629addea76  push rdi
00007b629addea77  push rsi
00007b629addea78  push r8
00007b629addea7a  push r9
00007b629addea7c  push r10
00007b629addea7e  push r11
00007b629addea80  sub rsp, 0xF0
00007b629addea87  vmovaps [rsp], xmm0
00007b629addea8c  vmovaps [rsp+0x10], xmm1
00007b629addea92  vmovaps [rsp+0x20], xmm2
00007b629addea98  vmovaps [rsp+0x30], xmm3
00007b629addea9e  vmovaps [rsp+0x40], xmm4
00007b629addeaa4  vmovaps [rsp+0x50], xmm5
00007b629addeaaa  vmovaps [rsp+0x60], xmm6
00007b629addeab0  vmovaps [rsp+0x70], xmm7
00007b629addeab6  vmovaps [rsp+0x80], xmm8
00007b629addeabf  vmovaps [rsp+0x90], xmm9
00007b629addeac8  vmovaps [rsp+0xA0], xmm10
00007b629addead1  vmovaps [rsp+0xB0], xmm11
00007b629addeada  vmovaps [rsp+0xC0], xmm12
00007b629addeae3  vmovaps [rsp+0xD0], xmm13
00007b629addeaec  vmovaps [rsp+0xE0], xmm14
00007b629addeaf5  sub rsp, 0x30
00007b629addeaf9  movaps [rsp], xmm15
00007b629addeafe  movaps [rsp+0x10], xmm14
00007b629addeb04  movaps [rsp+0x20], xmm4
00007b629addeb09  lea rdi, [rsp]
00007b629addeb0d  mov esi, 0x00
00007b629addeb12  mov rax, 0x583FED93F530
00007b629addeb1c  call rax
00007b629addeb1e  movaps xmm15, [rsp]
00007b629addeb23  add rsp, 0x30
00007b629addeb27  vmovaps xmm0, [rsp]
00007b629addeb2c  vmovaps xmm1, [rsp+0x10]
00007b629addeb32  vmovaps xmm2, [rsp+0x20]
00007b629addeb38  vmovaps xmm3, [rsp+0x30]
00007b629addeb3e  vmovaps xmm4, [rsp+0x40]
00007b629addeb44  vmovaps xmm5, [rsp+0x50]
00007b629addeb4a  vmovaps xmm6, [rsp+0x60]
00007b629addeb50  vmovaps xmm7, [rsp+0x70]
00007b629addeb56  vmovaps xmm8, [rsp+0x80]
00007b629addeb5f  vmovaps xmm9, [rsp+0x90]
00007b629addeb68  vmovaps xmm10, [rsp+0xA0]
00007b629addeb71  vmovaps xmm11, [rsp+0xB0]
00007b629addeb7a  vmovaps xmm12, [rsp+0xC0]
00007b629addeb83  vmovaps xmm13, [rsp+0xD0]
00007b629addeb8c  vmovaps xmm14, [rsp+0xE0]
00007b629addeb95  add rsp, 0xF0
00007b629addeb9c  pop r11
00007b629addeb9e  pop r10
00007b629addeba0  pop r9
00007b629addeba2  pop r8
00007b629addeba4  pop rsi
00007b629addeba5  pop rdi
00007b629addeba6  pop rdx
00007b629addeba7  pop rcx
00007b629addeba8  pop rax
00007b629addeba9  add rsp, 0x08
00007b629addebad  jmp 0x00007B629ADDC2AA
00007b629addebb2  sub rsp, 0x08
00007b629addebb6  push rax
00007b629addebb7  push rcx
00007b629addebb8  push rdx
00007b629addebb9  push rdi
00007b629addebba  push rsi
00007b629addebbb  push r8
00007b629addebbd  push r9
00007b629addebbf  push r10
00007b629addebc1  push r11
00007b629addebc3  sub rsp, 0xF0
00007b629addebca  vmovaps [rsp], xmm0
00007b629addebcf  vmovaps [rsp+0x10], xmm1
00007b629addebd5  vmovaps [rsp+0x20], xmm2
00007b629addebdb  vmovaps [rsp+0x30], xmm3
00007b629addebe1  vmovaps [rsp+0x40], xmm4
00007b629addebe7  vmovaps [rsp+0x50], xmm5
00007b629addebed  vmovaps [rsp+0x60], xmm6
00007b629addebf3  vmovaps [rsp+0x70], xmm7
00007b629addebf9  vmovaps [rsp+0x80], xmm8
00007b629addec02  vmovaps [rsp+0x90], xmm9
00007b629addec0b  vmovaps [rsp+0xA0], xmm10
00007b629addec14  vmovaps [rsp+0xB0], xmm11
00007b629addec1d  vmovaps [rsp+0xC0], xmm12
00007b629addec26  vmovaps [rsp+0xD0], xmm13
00007b629addec2f  vmovaps [rsp+0xE0], xmm15
00007b629addec38  sub rsp, 0x30
00007b629addec3c  movaps [rsp], xmm14
00007b629addec41  movaps [rsp+0x10], xmm2
00007b629addec46  movaps [rsp+0x20], xmm1
00007b629addec4b  lea rdi, [rsp]
00007b629addec4f  mov esi, 0x00
00007b629addec54  mov rax, 0x583FED93F530
00007b629addec5e  call rax
00007b629addec60  movaps xmm14, [rsp]
00007b629addec65  add rsp, 0x30
00007b629addec69  vmovaps xmm0, [rsp]
00007b629addec6e  vmovaps xmm1, [rsp+0x10]
00007b629addec74  vmovaps xmm2, [rsp+0x20]
00007b629addec7a  vmovaps xmm3, [rsp+0x30]
00007b629addec80  vmovaps xmm4, [rsp+0x40]
00007b629addec86  vmovaps xmm5, [rsp+0x50]
00007b629addec8c  vmovaps xmm6, [rsp+0x60]
00007b629addec92  vmovaps xmm7, [rsp+0x70]
00007b629addec98  vmovaps xmm8, [rsp+0x80]
00007b629addeca1  vmovaps xmm9, [rsp+0x90]
00007b629addecaa  vmovaps xmm10, [rsp+0xA0]
00007b629addecb3  vmovaps xmm11, [rsp+0xB0]
00007b629addecbc  vmovaps xmm12, [rsp+0xC0]
00007b629addecc5  vmovaps xmm13, [rsp+0xD0]
00007b629addecce  vmovaps xmm15, [rsp+0xE0]
00007b629addecd7  add rsp, 0xF0
00007b629addecde  pop r11
00007b629addece0  pop r10
00007b629addece2  pop r9
00007b629addece4  pop r8
00007b629addece6  pop rsi
00007b629addece7  pop rdi
00007b629addece8  pop rdx
00007b629addece9  pop rcx
00007b629addecea  pop rax
00007b629addeceb  add rsp, 0x08
00007b629addecef  jmp 0x00007B629ADDC2D0
00007b629addecf4  sub rsp, 0x08
00007b629addecf8  push rax
00007b629addecf9  push rcx
00007b629addecfa  push rdx
00007b629addecfb  push rdi
00007b629addecfc  push rsi
00007b629addecfd  push r8
00007b629addecff  push r9
00007b629added01  push r10
00007b629added03  push r11
00007b629added05  sub rsp, 0xF0
00007b629added0c  vmovaps [rsp], xmm0
00007b629added11  vmovaps [rsp+0x10], xmm2
00007b629added17  vmovaps [rsp+0x20], xmm3
00007b629added1d  vmovaps [rsp+0x30], xmm4
00007b629added23  vmovaps [rsp+0x40], xmm5
00007b629added29  vmovaps [rsp+0x50], xmm6
00007b629added2f  vmovaps [rsp+0x60], xmm7
00007b629added35  vmovaps [rsp+0x70], xmm8
00007b629added3b  vmovaps [rsp+0x80], xmm9
00007b629added44  vmovaps [rsp+0x90], xmm10
00007b629added4d  vmovaps [rsp+0xA0], xmm11
00007b629added56  vmovaps [rsp+0xB0], xmm12
00007b629added5f  vmovaps [rsp+0xC0], xmm13
00007b629added68  vmovaps [rsp+0xD0], xmm14
00007b629added71  vmovaps [rsp+0xE0], xmm15
00007b629added7a  sub rsp, 0x30
00007b629added7e  movaps [rsp], xmm1
00007b629added82  movaps [rsp+0x10], xmm4
00007b629added87  movaps [rsp+0x20], xmm9
00007b629added8d  lea rdi, [rsp]
00007b629added91  mov esi, 0x00
00007b629added96  mov rax, 0x583FED93F530
00007b629addeda0  call rax
00007b629addeda2  movaps xmm1, [rsp]
00007b629addeda6  add rsp, 0x30
00007b629addedaa  vmovaps xmm0, [rsp]
00007b629addedaf  vmovaps xmm2, [rsp+0x10]
00007b629addedb5  vmovaps xmm3, [rsp+0x20]
00007b629addedbb  vmovaps xmm4, [rsp+0x30]
00007b629addedc1  vmovaps xmm5, [rsp+0x40]
00007b629addedc7  vmovaps xmm6, [rsp+0x50]
00007b629addedcd  vmovaps xmm7, [rsp+0x60]
00007b629addedd3  vmovaps xmm8, [rsp+0x70]
00007b629addedd9  vmovaps xmm9, [rsp+0x80]
00007b629addede2  vmovaps xmm10, [rsp+0x90]
00007b629addedeb  vmovaps xmm11, [rsp+0xA0]
00007b629addedf4  vmovaps xmm12, [rsp+0xB0]
00007b629addedfd  vmovaps xmm13, [rsp+0xC0]
00007b629addee06  vmovaps xmm14, [rsp+0xD0]
00007b629addee0f  vmovaps xmm15, [rsp+0xE0]
00007b629addee18  add rsp, 0xF0
00007b629addee1f  pop r11
00007b629addee21  pop r10
00007b629addee23  pop r9
00007b629addee25  pop r8
00007b629addee27  pop rsi
00007b629addee28  pop rdi
00007b629addee29  pop rdx
00007b629addee2a  pop rcx
00007b629addee2b  pop rax
00007b629addee2c  add rsp, 0x08
00007b629addee30  jmp 0x00007B629ADDC2EE
00007b629addee35  sub rsp, 0x08
00007b629addee39  push rax
00007b629addee3a  push rcx
00007b629addee3b  push rdx
00007b629addee3c  push rdi
00007b629addee3d  push rsi
00007b629addee3e  push r8
00007b629addee40  push r9
00007b629addee42  push r10
00007b629addee44  push r11
00007b629addee46  sub rsp, 0xF0
00007b629addee4d  vmovaps [rsp], xmm0
00007b629addee52  vmovaps [rsp+0x10], xmm1
00007b629addee58  vmovaps [rsp+0x20], xmm2
00007b629addee5e  vmovaps [rsp+0x30], xmm3
00007b629addee64  vmovaps [rsp+0x40], xmm5
00007b629addee6a  vmovaps [rsp+0x50], xmm6
00007b629addee70  vmovaps [rsp+0x60], xmm7
00007b629addee76  vmovaps [rsp+0x70], xmm8
00007b629addee7c  vmovaps [rsp+0x80], xmm9
00007b629addee85  vmovaps [rsp+0x90], xmm10
00007b629addee8e  vmovaps [rsp+0xA0], xmm11
00007b629addee97  vmovaps [rsp+0xB0], xmm12
00007b629addeea0  vmovaps [rsp+0xC0], xmm13
00007b629addeea9  vmovaps [rsp+0xD0], xmm14
00007b629addeeb2  vmovaps [rsp+0xE0], xmm15
00007b629addeebb  sub rsp, 0x30
00007b629addeebf  movaps [rsp], xmm4
00007b629addeec3  movaps [rsp+0x10], xmm2
00007b629addeec8  movaps [rsp+0x20], xmm9
00007b629addeece  lea rdi, [rsp]
00007b629addeed2  mov esi, 0x00
00007b629addeed7  mov rax, 0x583FED93F530
00007b629addeee1  call rax
00007b629addeee3  movaps xmm4, [rsp]
00007b629addeee7  add rsp, 0x30
00007b629addeeeb  vmovaps xmm0, [rsp]
00007b629addeef0  vmovaps xmm1, [rsp+0x10]
00007b629addeef6  vmovaps xmm2, [rsp+0x20]
00007b629addeefc  vmovaps xmm3, [rsp+0x30]
00007b629addef02  vmovaps xmm5, [rsp+0x40]
00007b629addef08  vmovaps xmm6, [rsp+0x50]
00007b629addef0e  vmovaps xmm7, [rsp+0x60]
00007b629addef14  vmovaps xmm8, [rsp+0x70]
00007b629addef1a  vmovaps xmm9, [rsp+0x80]
00007b629addef23  vmovaps xmm10, [rsp+0x90]
00007b629addef2c  vmovaps xmm11, [rsp+0xA0]
00007b629addef35  vmovaps xmm12, [rsp+0xB0]
00007b629addef3e  vmovaps xmm13, [rsp+0xC0]
00007b629addef47  vmovaps xmm14, [rsp+0xD0]
00007b629addef50  vmovaps xmm15, [rsp+0xE0]
00007b629addef59  add rsp, 0xF0
00007b629addef60  pop r11
00007b629addef62  pop r10
00007b629addef64  pop r9
00007b629addef66  pop r8
00007b629addef68  pop rsi
00007b629addef69  pop rdi
00007b629addef6a  pop rdx
00007b629addef6b  pop rcx
00007b629addef6c  pop rax
00007b629addef6d  add rsp, 0x08
00007b629addef71  jmp 0x00007B629ADDC31E
00007b629addef76  sub rsp, 0x08
00007b629addef7a  push rax
00007b629addef7b  push rcx
00007b629addef7c  push rdx
00007b629addef7d  push rdi
00007b629addef7e  push rsi
00007b629addef7f  push r8
00007b629addef81  push r9
00007b629addef83  push r10
00007b629addef85  push r11
00007b629addef87  sub rsp, 0xF0
00007b629addef8e  vmovaps [rsp], xmm0
00007b629addef93  vmovaps [rsp+0x10], xmm1
00007b629addef99  vmovaps [rsp+0x20], xmm2
00007b629addef9f  vmovaps [rsp+0x30], xmm3
00007b629addefa5  vmovaps [rsp+0x40], xmm4
00007b629addefab  vmovaps [rsp+0x50], xmm5
00007b629addefb1  vmovaps [rsp+0x60], xmm6
00007b629addefb7  vmovaps [rsp+0x70], xmm7
00007b629addefbd  vmovaps [rsp+0x80], xmm8
00007b629addefc6  vmovaps [rsp+0x90], xmm10
00007b629addefcf  vmovaps [rsp+0xA0], xmm11
00007b629addefd8  vmovaps [rsp+0xB0], xmm12
00007b629addefe1  vmovaps [rsp+0xC0], xmm13
00007b629addefea  vmovaps [rsp+0xD0], xmm14
00007b629addeff3  vmovaps [rsp+0xE0], xmm15
00007b629addeffc  sub rsp, 0x30
00007b629addf000  movaps [rsp], xmm9
00007b629addf005  movaps [rsp+0x10], xmm2
00007b629addf00a  movaps [rsp+0x20], xmm1
00007b629addf00f  lea rdi, [rsp]
00007b629addf013  mov esi, 0x00
00007b629addf018  mov rax, 0x583FED93F530
00007b629addf022  call rax
00007b629addf024  movaps xmm9, [rsp]
00007b629addf029  add rsp, 0x30
00007b629addf02d  vmovaps xmm0, [rsp]
00007b629addf032  vmovaps xmm1, [rsp+0x10]
00007b629addf038  vmovaps xmm2, [rsp+0x20]
00007b629addf03e  vmovaps xmm3, [rsp+0x30]
00007b629addf044  vmovaps xmm4, [rsp+0x40]
00007b629addf04a  vmovaps xmm5, [rsp+0x50]
00007b629addf050  vmovaps xmm6, [rsp+0x60]
00007b629addf056  vmovaps xmm7, [rsp+0x70]
00007b629addf05c  vmovaps xmm8, [rsp+0x80]
00007b629addf065  vmovaps xmm10, [rsp+0x90]
00007b629addf06e  vmovaps xmm11, [rsp+0xA0]
00007b629addf077  vmovaps xmm12, [rsp+0xB0]
00007b629addf080  vmovaps xmm13, [rsp+0xC0]
00007b629addf089  vmovaps xmm14, [rsp+0xD0]
00007b629addf092  vmovaps xmm15, [rsp+0xE0]
00007b629addf09b  add rsp, 0xF0
00007b629addf0a2  pop r11
00007b629addf0a4  pop r10
00007b629addf0a6  pop r9
00007b629addf0a8  pop r8
00007b629addf0aa  pop rsi
00007b629addf0ab  pop rdi
00007b629addf0ac  pop rdx
00007b629addf0ad  pop rcx
00007b629addf0ae  pop rax
00007b629addf0af  add rsp, 0x08
00007b629addf0b3  jmp 0x00007B629ADDC354
00007b629addf0b8  sub rsp, 0x08
00007b629addf0bc  push rax
00007b629addf0bd  push rcx
00007b629addf0be  push rdx
00007b629addf0bf  push rdi
00007b629addf0c0  push rsi
00007b629addf0c1  push r8
00007b629addf0c3  push r9
00007b629addf0c5  push r10
00007b629addf0c7  push r11
00007b629addf0c9  sub rsp, 0xF0
00007b629addf0d0  vmovaps [rsp], xmm0
00007b629addf0d5  vmovaps [rsp+0x10], xmm2
00007b629addf0db  vmovaps [rsp+0x20], xmm3
00007b629addf0e1  vmovaps [rsp+0x30], xmm4
00007b629addf0e7  vmovaps [rsp+0x40], xmm5
00007b629addf0ed  vmovaps [rsp+0x50], xmm6
00007b629addf0f3  vmovaps [rsp+0x60], xmm7
00007b629addf0f9  vmovaps [rsp+0x70], xmm8
00007b629addf0ff  vmovaps [rsp+0x80], xmm9
00007b629addf108  vmovaps [rsp+0x90], xmm10
00007b629addf111  vmovaps [rsp+0xA0], xmm11
00007b629addf11a  vmovaps [rsp+0xB0], xmm12
00007b629addf123  vmovaps [rsp+0xC0], xmm13
00007b629addf12c  vmovaps [rsp+0xD0], xmm14
00007b629addf135  vmovaps [rsp+0xE0], xmm15
00007b629addf13e  sub rsp, 0x30
00007b629addf142  movaps [rsp], xmm1
00007b629addf146  movaps [rsp+0x10], xmm15
00007b629addf14c  movaps [rsp+0x20], xmm6
00007b629addf151  lea rdi, [rsp]
00007b629addf155  mov esi, 0x00
00007b629addf15a  mov rax, 0x583FED93F530
00007b629addf164  call rax
00007b629addf166  movaps xmm1, [rsp]
00007b629addf16a  add rsp, 0x30
00007b629addf16e  vmovaps xmm0, [rsp]
00007b629addf173  vmovaps xmm2, [rsp+0x10]
00007b629addf179  vmovaps xmm3, [rsp+0x20]
00007b629addf17f  vmovaps xmm4, [rsp+0x30]
00007b629addf185  vmovaps xmm5, [rsp+0x40]
00007b629addf18b  vmovaps xmm6, [rsp+0x50]
00007b629addf191  vmovaps xmm7, [rsp+0x60]
00007b629addf197  vmovaps xmm8, [rsp+0x70]
00007b629addf19d  vmovaps xmm9, [rsp+0x80]
00007b629addf1a6  vmovaps xmm10, [rsp+0x90]
00007b629addf1af  vmovaps xmm11, [rsp+0xA0]
00007b629addf1b8  vmovaps xmm12, [rsp+0xB0]
00007b629addf1c1  vmovaps xmm13, [rsp+0xC0]
00007b629addf1ca  vmovaps xmm14, [rsp+0xD0]
00007b629addf1d3  vmovaps xmm15, [rsp+0xE0]
00007b629addf1dc  add rsp, 0xF0
00007b629addf1e3  pop r11
00007b629addf1e5  pop r10
00007b629addf1e7  pop r9
00007b629addf1e9  pop r8
00007b629addf1eb  pop rsi
00007b629addf1ec  pop rdi
00007b629addf1ed  pop rdx
00007b629addf1ee  pop rcx
00007b629addf1ef  pop rax
00007b629addf1f0  add rsp, 0x08
00007b629addf1f4  jmp 0x00007B629ADDC375
00007b629addf1f9  sub rsp, 0x08
00007b629addf1fd  push rax
00007b629addf1fe  push rcx
00007b629addf1ff  push rdx
00007b629addf200  push rdi
00007b629addf201  push rsi
00007b629addf202  push r8
00007b629addf204  push r9
00007b629addf206  push r10
00007b629addf208  push r11
00007b629addf20a  sub rsp, 0xF0
00007b629addf211  vmovaps [rsp], xmm0
00007b629addf216  vmovaps [rsp+0x10], xmm1
00007b629addf21c  vmovaps [rsp+0x20], xmm2
00007b629addf222  vmovaps [rsp+0x30], xmm3
00007b629addf228  vmovaps [rsp+0x40], xmm4
00007b629addf22e  vmovaps [rsp+0x50], xmm5
00007b629addf234  vmovaps [rsp+0x60], xmm6
00007b629addf23a  vmovaps [rsp+0x70], xmm7
00007b629addf240  vmovaps [rsp+0x80], xmm8
00007b629addf249  vmovaps [rsp+0x90], xmm9
00007b629addf252  vmovaps [rsp+0xA0], xmm10
00007b629addf25b  vmovaps [rsp+0xB0], xmm11
00007b629addf264  vmovaps [rsp+0xC0], xmm12
00007b629addf26d  vmovaps [rsp+0xD0], xmm13
00007b629addf276  vmovaps [rsp+0xE0], xmm14
00007b629addf27f  sub rsp, 0x30
00007b629addf283  movaps [rsp], xmm15
00007b629addf288  movaps [rsp+0x10], xmm5
00007b629addf28d  movaps [rsp+0x20], xmm3
00007b629addf292  lea rdi, [rsp]
00007b629addf296  mov esi, 0x00
00007b629addf29b  mov rax, 0x583FED93F530
00007b629addf2a5  call rax
00007b629addf2a7  movaps xmm15, [rsp]
00007b629addf2ac  add rsp, 0x30
00007b629addf2b0  vmovaps xmm0, [rsp]
00007b629addf2b5  vmovaps xmm1, [rsp+0x10]
00007b629addf2bb  vmovaps xmm2, [rsp+0x20]
00007b629addf2c1  vmovaps xmm3, [rsp+0x30]
00007b629addf2c7  vmovaps xmm4, [rsp+0x40]
00007b629addf2cd  vmovaps xmm5, [rsp+0x50]
00007b629addf2d3  vmovaps xmm6, [rsp+0x60]
00007b629addf2d9  vmovaps xmm7, [rsp+0x70]
00007b629addf2df  vmovaps xmm8, [rsp+0x80]
00007b629addf2e8  vmovaps xmm9, [rsp+0x90]
00007b629addf2f1  vmovaps xmm10, [rsp+0xA0]
00007b629addf2fa  vmovaps xmm11, [rsp+0xB0]
00007b629addf303  vmovaps xmm12, [rsp+0xC0]
00007b629addf30c  vmovaps xmm13, [rsp+0xD0]
00007b629addf315  vmovaps xmm14, [rsp+0xE0]
00007b629addf31e  add rsp, 0xF0
00007b629addf325  pop r11
00007b629addf327  pop r10
00007b629addf329  pop r9
00007b629addf32b  pop r8
00007b629addf32d  pop rsi
00007b629addf32e  pop rdi
00007b629addf32f  pop rdx
00007b629addf330  pop rcx
00007b629addf331  pop rax
00007b629addf332  add rsp, 0x08
00007b629addf336  jmp 0x00007B629ADDC38F
00007b629addf33b  sub rsp, 0x08
00007b629addf33f  push rax
00007b629addf340  push rcx
00007b629addf341  push rdx
00007b629addf342  push rdi
00007b629addf343  push rsi
00007b629addf344  push r8
00007b629addf346  push r9
00007b629addf348  push r10
00007b629addf34a  push r11
00007b629addf34c  sub rsp, 0xF0
00007b629addf353  vmovaps [rsp], xmm0
00007b629addf358  vmovaps [rsp+0x10], xmm1
00007b629addf35e  vmovaps [rsp+0x20], xmm2
00007b629addf364  vmovaps [rsp+0x30], xmm3
00007b629addf36a  vmovaps [rsp+0x40], xmm4
00007b629addf370  vmovaps [rsp+0x50], xmm6
00007b629addf376  vmovaps [rsp+0x60], xmm7
00007b629addf37c  vmovaps [rsp+0x70], xmm8
00007b629addf382  vmovaps [rsp+0x80], xmm9
00007b629addf38b  vmovaps [rsp+0x90], xmm10
00007b629addf394  vmovaps [rsp+0xA0], xmm11
00007b629addf39d  vmovaps [rsp+0xB0], xmm12
00007b629addf3a6  vmovaps [rsp+0xC0], xmm13
00007b629addf3af  vmovaps [rsp+0xD0], xmm14
00007b629addf3b8  vmovaps [rsp+0xE0], xmm15
00007b629addf3c1  sub rsp, 0x30
00007b629addf3c5  movaps [rsp], xmm5
00007b629addf3c9  movaps [rsp+0x10], xmm8
00007b629addf3cf  movaps [rsp+0x20], xmm6
00007b629addf3d4  lea rdi, [rsp]
00007b629addf3d8  mov esi, 0x00
00007b629addf3dd  mov rax, 0x583FED93F530
00007b629addf3e7  call rax
00007b629addf3e9  movaps xmm5, [rsp]
00007b629addf3ed  add rsp, 0x30
00007b629addf3f1  vmovaps xmm0, [rsp]
00007b629addf3f6  vmovaps xmm1, [rsp+0x10]
00007b629addf3fc  vmovaps xmm2, [rsp+0x20]
00007b629addf402  vmovaps xmm3, [rsp+0x30]
00007b629addf408  vmovaps xmm4, [rsp+0x40]
00007b629addf40e  vmovaps xmm6, [rsp+0x50]
00007b629addf414  vmovaps xmm7, [rsp+0x60]
00007b629addf41a  vmovaps xmm8, [rsp+0x70]
00007b629addf420  vmovaps xmm9, [rsp+0x80]
00007b629addf429  vmovaps xmm10, [rsp+0x90]
00007b629addf432  vmovaps xmm11, [rsp+0xA0]
00007b629addf43b  vmovaps xmm12, [rsp+0xB0]
00007b629addf444  vmovaps xmm13, [rsp+0xC0]
00007b629addf44d  vmovaps xmm14, [rsp+0xD0]
00007b629addf456  vmovaps xmm15, [rsp+0xE0]
00007b629addf45f  add rsp, 0xF0
00007b629addf466  pop r11
00007b629addf468  pop r10
00007b629addf46a  pop r9
00007b629addf46c  pop r8
00007b629addf46e  pop rsi
00007b629addf46f  pop rdi
00007b629addf470  pop rdx
00007b629addf471  pop rcx
00007b629addf472  pop rax
00007b629addf473  add rsp, 0x08
00007b629addf477  jmp 0x00007B629ADDC3B3
00007b629addf47c  sub rsp, 0x08
00007b629addf480  push rax
00007b629addf481  push rcx
00007b629addf482  push rdx
00007b629addf483  push rdi
00007b629addf484  push rsi
00007b629addf485  push r8
00007b629addf487  push r9
00007b629addf489  push r10
00007b629addf48b  push r11
00007b629addf48d  sub rsp, 0xF0
00007b629addf494  vmovaps [rsp], xmm0
00007b629addf499  vmovaps [rsp+0x10], xmm1
00007b629addf49f  vmovaps [rsp+0x20], xmm2
00007b629addf4a5  vmovaps [rsp+0x30], xmm3
00007b629addf4ab  vmovaps [rsp+0x40], xmm4
00007b629addf4b1  vmovaps [rsp+0x50], xmm5
00007b629addf4b7  vmovaps [rsp+0x60], xmm7
00007b629addf4bd  vmovaps [rsp+0x70], xmm8
00007b629addf4c3  vmovaps [rsp+0x80], xmm9
00007b629addf4cc  vmovaps [rsp+0x90], xmm10
00007b629addf4d5  vmovaps [rsp+0xA0], xmm11
00007b629addf4de  vmovaps [rsp+0xB0], xmm12
00007b629addf4e7  vmovaps [rsp+0xC0], xmm13
00007b629addf4f0  vmovaps [rsp+0xD0], xmm14
00007b629addf4f9  vmovaps [rsp+0xE0], xmm15
00007b629addf502  sub rsp, 0x30
00007b629addf506  movaps [rsp], xmm6
00007b629addf50a  movaps [rsp+0x10], xmm10
00007b629addf510  movaps [rsp+0x20], xmm8
00007b629addf516  lea rdi, [rsp]
00007b629addf51a  mov esi, 0x00
00007b629addf51f  mov rax, 0x583FED93F530
00007b629addf529  call rax
00007b629addf52b  movaps xmm6, [rsp]
00007b629addf52f  add rsp, 0x30
00007b629addf533  vmovaps xmm0, [rsp]
00007b629addf538  vmovaps xmm1, [rsp+0x10]
00007b629addf53e  vmovaps xmm2, [rsp+0x20]
00007b629addf544  vmovaps xmm3, [rsp+0x30]
00007b629addf54a  vmovaps xmm4, [rsp+0x40]
00007b629addf550  vmovaps xmm5, [rsp+0x50]
00007b629addf556  vmovaps xmm7, [rsp+0x60]
00007b629addf55c  vmovaps xmm8, [rsp+0x70]
00007b629addf562  vmovaps xmm9, [rsp+0x80]
00007b629addf56b  vmovaps xmm10, [rsp+0x90]
00007b629addf574  vmovaps xmm11, [rsp+0xA0]
00007b629addf57d  vmovaps xmm12, [rsp+0xB0]
00007b629addf586  vmovaps xmm13, [rsp+0xC0]
00007b629addf58f  vmovaps xmm14, [rsp+0xD0]
00007b629addf598  vmovaps xmm15, [rsp+0xE0]
00007b629addf5a1  add rsp, 0xF0
00007b629addf5a8  pop r11
00007b629addf5aa  pop r10
00007b629addf5ac  pop r9
00007b629addf5ae  pop r8
00007b629addf5b0  pop rsi
00007b629addf5b1  pop rdi
00007b629addf5b2  pop rdx
00007b629addf5b3  pop rcx
00007b629addf5b4  pop rax
00007b629addf5b5  add rsp, 0x08
00007b629addf5b9  jmp 0x00007B629ADDC3D8
00007b629addf5be  sub rsp, 0x08
00007b629addf5c2  push rax
00007b629addf5c3  push rcx
00007b629addf5c4  push rdx
00007b629addf5c5  push rdi
00007b629addf5c6  push rsi
00007b629addf5c7  push r8
00007b629addf5c9  push r9
00007b629addf5cb  push r10
00007b629addf5cd  push r11
00007b629addf5cf  sub rsp, 0xF0
00007b629addf5d6  vmovaps [rsp], xmm0
00007b629addf5db  vmovaps [rsp+0x10], xmm1
00007b629addf5e1  vmovaps [rsp+0x20], xmm2
00007b629addf5e7  vmovaps [rsp+0x30], xmm3
00007b629addf5ed  vmovaps [rsp+0x40], xmm4
00007b629addf5f3  vmovaps [rsp+0x50], xmm5
00007b629addf5f9  vmovaps [rsp+0x60], xmm6
00007b629addf5ff  vmovaps [rsp+0x70], xmm7
00007b629addf605  vmovaps [rsp+0x80], xmm8
00007b629addf60e  vmovaps [rsp+0x90], xmm9
00007b629addf617  vmovaps [rsp+0xA0], xmm11
00007b629addf620  vmovaps [rsp+0xB0], xmm12
00007b629addf629  vmovaps [rsp+0xC0], xmm13
00007b629addf632  vmovaps [rsp+0xD0], xmm14
00007b629addf63b  vmovaps [rsp+0xE0], xmm15
00007b629addf644  sub rsp, 0x30
00007b629addf648  movaps [rsp], xmm10
00007b629addf64d  movaps [rsp+0x10], xmm8
00007b629addf653  movaps [rsp+0x20], xmm14
00007b629addf659  lea rdi, [rsp]
00007b629addf65d  mov esi, 0x00
00007b629addf662  mov rax, 0x583FED93F530
00007b629addf66c  call rax
00007b629addf66e  movaps xmm10, [rsp]
00007b629addf673  add rsp, 0x30
00007b629addf677  vmovaps xmm0, [rsp]
00007b629addf67c  vmovaps xmm1, [rsp+0x10]
00007b629addf682  vmovaps xmm2, [rsp+0x20]
00007b629addf688  vmovaps xmm3, [rsp+0x30]
00007b629addf68e  vmovaps xmm4, [rsp+0x40]
00007b629addf694  vmovaps xmm5, [rsp+0x50]
00007b629addf69a  vmovaps xmm6, [rsp+0x60]
00007b629addf6a0  vmovaps xmm7, [rsp+0x70]
00007b629addf6a6  vmovaps xmm8, [rsp+0x80]
00007b629addf6af  vmovaps xmm9, [rsp+0x90]
00007b629addf6b8  vmovaps xmm11, [rsp+0xA0]
00007b629addf6c1  vmovaps xmm12, [rsp+0xB0]
00007b629addf6ca  vmovaps xmm13, [rsp+0xC0]
00007b629addf6d3  vmovaps xmm14, [rsp+0xD0]
00007b629addf6dc  vmovaps xmm15, [rsp+0xE0]
00007b629addf6e5  add rsp, 0xF0
00007b629addf6ec  pop r11
00007b629addf6ee  pop r10
00007b629addf6f0  pop r9
00007b629addf6f2  pop r8
00007b629addf6f4  pop rsi
00007b629addf6f5  pop rdi
00007b629addf6f6  pop rdx
00007b629addf6f7  pop rcx
00007b629addf6f8  pop rax
00007b629addf6f9  add rsp, 0x08
00007b629addf6fd  jmp 0x00007B629ADDC3F8
00007b629addf702  sub rsp, 0x08
00007b629addf706  push rax
00007b629addf707  push rcx
00007b629addf708  push rdx
00007b629addf709  push rdi
00007b629addf70a  push rsi
00007b629addf70b  push r8
00007b629addf70d  push r9
00007b629addf70f  push r10
00007b629addf711  push r11
00007b629addf713  sub rsp, 0xF0
00007b629addf71a  vmovaps [rsp], xmm0
00007b629addf71f  vmovaps [rsp+0x10], xmm1
00007b629addf725  vmovaps [rsp+0x20], xmm2
00007b629addf72b  vmovaps [rsp+0x30], xmm3
00007b629addf731  vmovaps [rsp+0x40], xmm4
00007b629addf737  vmovaps [rsp+0x50], xmm5
00007b629addf73d  vmovaps [rsp+0x60], xmm6
00007b629addf743  vmovaps [rsp+0x70], xmm7
00007b629addf749  vmovaps [rsp+0x80], xmm8
00007b629addf752  vmovaps [rsp+0x90], xmm9
00007b629addf75b  vmovaps [rsp+0xA0], xmm10
00007b629addf764  vmovaps [rsp+0xB0], xmm11
00007b629addf76d  vmovaps [rsp+0xC0], xmm12
00007b629addf776  vmovaps [rsp+0xD0], xmm13
00007b629addf77f  vmovaps [rsp+0xE0], xmm15
00007b629addf788  sub rsp, 0x30
00007b629addf78c  movaps [rsp], xmm14
00007b629addf791  movaps [rsp+0x10], xmm8
00007b629addf797  movaps [rsp+0x20], xmm4
00007b629addf79c  lea rdi, [rsp]
00007b629addf7a0  mov esi, 0x00
00007b629addf7a5  mov rax, 0x583FED93F530
00007b629addf7af  call rax
00007b629addf7b1  movaps xmm14, [rsp]
00007b629addf7b6  add rsp, 0x30
00007b629addf7ba  vmovaps xmm0, [rsp]
00007b629addf7bf  vmovaps xmm1, [rsp+0x10]
00007b629addf7c5  vmovaps xmm2, [rsp+0x20]
00007b629addf7cb  vmovaps xmm3, [rsp+0x30]
00007b629addf7d1  vmovaps xmm4, [rsp+0x40]
00007b629addf7d7  vmovaps xmm5, [rsp+0x50]
00007b629addf7dd  vmovaps xmm6, [rsp+0x60]
00007b629addf7e3  vmovaps xmm7, [rsp+0x70]
00007b629addf7e9  vmovaps xmm8, [rsp+0x80]
00007b629addf7f2  vmovaps xmm9, [rsp+0x90]
00007b629addf7fb  vmovaps xmm10, [rsp+0xA0]
00007b629addf804  vmovaps xmm11, [rsp+0xB0]
00007b629addf80d  vmovaps xmm12, [rsp+0xC0]
00007b629addf816  vmovaps xmm13, [rsp+0xD0]
00007b629addf81f  vmovaps xmm15, [rsp+0xE0]
00007b629addf828  add rsp, 0xF0
00007b629addf82f  pop r11
00007b629addf831  pop r10
00007b629addf833  pop r9
00007b629addf835  pop r8
00007b629addf837  pop rsi
00007b629addf838  pop rdi
00007b629addf839  pop rdx
00007b629addf83a  pop rcx
00007b629addf83b  pop rax
00007b629addf83c  add rsp, 0x08
00007b629addf840  jmp 0x00007B629ADDC418
00007b629addf845  sub rsp, 0x08
00007b629addf849  push rax
00007b629addf84a  push rcx
00007b629addf84b  push rdx
00007b629addf84c  push rdi
00007b629addf84d  push rsi
00007b629addf84e  push r8
00007b629addf850  push r9
00007b629addf852  push r10
00007b629addf854  push r11
00007b629addf856  sub rsp, 0xF0
00007b629addf85d  vmovaps [rsp], xmm0
00007b629addf862  vmovaps [rsp+0x10], xmm1
00007b629addf868  vmovaps [rsp+0x20], xmm2
00007b629addf86e  vmovaps [rsp+0x30], xmm3
00007b629addf874  vmovaps [rsp+0x40], xmm5
00007b629addf87a  vmovaps [rsp+0x50], xmm6
00007b629addf880  vmovaps [rsp+0x60], xmm7
00007b629addf886  vmovaps [rsp+0x70], xmm8
00007b629addf88c  vmovaps [rsp+0x80], xmm9
00007b629addf895  vmovaps [rsp+0x90], xmm10
00007b629addf89e  vmovaps [rsp+0xA0], xmm11
00007b629addf8a7  vmovaps [rsp+0xB0], xmm12
00007b629addf8b0  vmovaps [rsp+0xC0], xmm13
00007b629addf8b9  vmovaps [rsp+0xD0], xmm14
00007b629addf8c2  vmovaps [rsp+0xE0], xmm15
00007b629addf8cb  sub rsp, 0x30
00007b629addf8cf  movaps [rsp], xmm4
00007b629addf8d3  movaps [rsp+0x10], xmm13
00007b629addf8d9  movaps [rsp+0x20], xmm8
00007b629addf8df  lea rdi, [rsp]
00007b629addf8e3  mov esi, 0x00
00007b629addf8e8  mov rax, 0x583FED93F530
00007b629addf8f2  call rax
00007b629addf8f4  movaps xmm4, [rsp]
00007b629addf8f8  add rsp, 0x30
00007b629addf8fc  vmovaps xmm0, [rsp]
00007b629addf901  vmovaps xmm1, [rsp+0x10]
00007b629addf907  vmovaps xmm2, [rsp+0x20]
00007b629addf90d  vmovaps xmm3, [rsp+0x30]
00007b629addf913  vmovaps xmm5, [rsp+0x40]
00007b629addf919  vmovaps xmm6, [rsp+0x50]
00007b629addf91f  vmovaps xmm7, [rsp+0x60]
00007b629addf925  vmovaps xmm8, [rsp+0x70]
00007b629addf92b  vmovaps xmm9, [rsp+0x80]
00007b629addf934  vmovaps xmm10, [rsp+0x90]
00007b629addf93d  vmovaps xmm11, [rsp+0xA0]
00007b629addf946  vmovaps xmm12, [rsp+0xB0]
00007b629addf94f  vmovaps xmm13, [rsp+0xC0]
00007b629addf958  vmovaps xmm14, [rsp+0xD0]
00007b629addf961  vmovaps xmm15, [rsp+0xE0]
00007b629addf96a  add rsp, 0xF0
00007b629addf971  pop r11
00007b629addf973  pop r10
00007b629addf975  pop r9
00007b629addf977  pop r8
00007b629addf979  pop rsi
00007b629addf97a  pop rdi
00007b629addf97b  pop rdx
00007b629addf97c  pop rcx
00007b629addf97d  pop rax
00007b629addf97e  add rsp, 0x08
00007b629addf982  jmp 0x00007B629ADDC43D
00007b629addf987  sub rsp, 0x08
00007b629addf98b  push rax
00007b629addf98c  push rcx
00007b629addf98d  push rdx
00007b629addf98e  push rdi
00007b629addf98f  push rsi
00007b629addf990  push r8
00007b629addf992  push r9
00007b629addf994  push r10
00007b629addf996  push r11
00007b629addf998  sub rsp, 0xF0
00007b629addf99f  vmovaps [rsp], xmm0
00007b629addf9a4  vmovaps [rsp+0x10], xmm1
00007b629addf9aa  vmovaps [rsp+0x20], xmm2
00007b629addf9b0  vmovaps [rsp+0x30], xmm3
00007b629addf9b6  vmovaps [rsp+0x40], xmm4
00007b629addf9bc  vmovaps [rsp+0x50], xmm5
00007b629addf9c2  vmovaps [rsp+0x60], xmm6
00007b629addf9c8  vmovaps [rsp+0x70], xmm7
00007b629addf9ce  vmovaps [rsp+0x80], xmm8
00007b629addf9d7  vmovaps [rsp+0x90], xmm9
00007b629addf9e0  vmovaps [rsp+0xA0], xmm10
00007b629addf9e9  vmovaps [rsp+0xB0], xmm11
00007b629addf9f2  vmovaps [rsp+0xC0], xmm12
00007b629addf9fb  vmovaps [rsp+0xD0], xmm14
00007b629addfa04  vmovaps [rsp+0xE0], xmm15
00007b629addfa0d  sub rsp, 0x30
00007b629addfa11  movaps [rsp], xmm13
00007b629addfa16  movaps [rsp+0x10], xmm15
00007b629addfa1c  movaps [rsp+0x20], xmm9
00007b629addfa22  lea rdi, [rsp]
00007b629addfa26  mov esi, 0x00
00007b629addfa2b  mov rax, 0x583FED93F530
00007b629addfa35  call rax
00007b629addfa37  movaps xmm13, [rsp]
00007b629addfa3c  add rsp, 0x30
00007b629addfa40  vmovaps xmm0, [rsp]
00007b629addfa45  vmovaps xmm1, [rsp+0x10]
00007b629addfa4b  vmovaps xmm2, [rsp+0x20]
00007b629addfa51  vmovaps xmm3, [rsp+0x30]
00007b629addfa57  vmovaps xmm4, [rsp+0x40]
00007b629addfa5d  vmovaps xmm5, [rsp+0x50]
00007b629addfa63  vmovaps xmm6, [rsp+0x60]
00007b629addfa69  vmovaps xmm7, [rsp+0x70]
00007b629addfa6f  vmovaps xmm8, [rsp+0x80]
00007b629addfa78  vmovaps xmm9, [rsp+0x90]
00007b629addfa81  vmovaps xmm10, [rsp+0xA0]
00007b629addfa8a  vmovaps xmm11, [rsp+0xB0]
00007b629addfa93  vmovaps xmm12, [rsp+0xC0]
00007b629addfa9c  vmovaps xmm14, [rsp+0xD0]
00007b629addfaa5  vmovaps xmm15, [rsp+0xE0]
00007b629addfaae  add rsp, 0xF0
00007b629addfab5  pop r11
00007b629addfab7  pop r10
00007b629addfab9  pop r9
00007b629addfabb  pop r8
00007b629addfabd  pop rsi
00007b629addfabe  pop rdi
00007b629addfabf  pop rdx
00007b629addfac0  pop rcx
00007b629addfac1  pop rax
00007b629addfac2  add rsp, 0x08
00007b629addfac6  jmp 0x00007B629ADDC458
00007b629addfacb  sub rsp, 0x08
00007b629addfacf  push rax
00007b629addfad0  push rcx
00007b629addfad1  push rdx
00007b629addfad2  push rdi
00007b629addfad3  push rsi
00007b629addfad4  push r8
00007b629addfad6  push r9
00007b629addfad8  push r10
00007b629addfada  push r11
00007b629addfadc  sub rsp, 0xF0
00007b629addfae3  vmovaps [rsp], xmm0
00007b629addfae8  vmovaps [rsp+0x10], xmm1
00007b629addfaee  vmovaps [rsp+0x20], xmm2
00007b629addfaf4  vmovaps [rsp+0x30], xmm3
00007b629addfafa  vmovaps [rsp+0x40], xmm4
00007b629addfb00  vmovaps [rsp+0x50], xmm5
00007b629addfb06  vmovaps [rsp+0x60], xmm6
00007b629addfb0c  vmovaps [rsp+0x70], xmm7
00007b629addfb12  vmovaps [rsp+0x80], xmm8
00007b629addfb1b  vmovaps [rsp+0x90], xmm9
00007b629addfb24  vmovaps [rsp+0xA0], xmm10
00007b629addfb2d  vmovaps [rsp+0xB0], xmm11
00007b629addfb36  vmovaps [rsp+0xC0], xmm12
00007b629addfb3f  vmovaps [rsp+0xD0], xmm13
00007b629addfb48  vmovaps [rsp+0xE0], xmm14
00007b629addfb51  sub rsp, 0x30
00007b629addfb55  movaps [rsp], xmm15
00007b629addfb5a  movaps [rsp+0x10], xmm1
00007b629addfb5f  movaps [rsp+0x20], xmm5
00007b629addfb64  lea rdi, [rsp]
00007b629addfb68  mov esi, 0x00
00007b629addfb6d  mov rax, 0x583FED93F530
00007b629addfb77  call rax
00007b629addfb79  movaps xmm15, [rsp]
00007b629addfb7e  add rsp, 0x30
00007b629addfb82  vmovaps xmm0, [rsp]
00007b629addfb87  vmovaps xmm1, [rsp+0x10]
00007b629addfb8d  vmovaps xmm2, [rsp+0x20]
00007b629addfb93  vmovaps xmm3, [rsp+0x30]
00007b629addfb99  vmovaps xmm4, [rsp+0x40]
00007b629addfb9f  vmovaps xmm5, [rsp+0x50]
00007b629addfba5  vmovaps xmm6, [rsp+0x60]
00007b629addfbab  vmovaps xmm7, [rsp+0x70]
00007b629addfbb1  vmovaps xmm8, [rsp+0x80]
00007b629addfbba  vmovaps xmm9, [rsp+0x90]
00007b629addfbc3  vmovaps xmm10, [rsp+0xA0]
00007b629addfbcc  vmovaps xmm11, [rsp+0xB0]
00007b629addfbd5  vmovaps xmm12, [rsp+0xC0]
00007b629addfbde  vmovaps xmm13, [rsp+0xD0]
00007b629addfbe7  vmovaps xmm14, [rsp+0xE0]
00007b629addfbf0  add rsp, 0xF0
00007b629addfbf7  pop r11
00007b629addfbf9  pop r10
00007b629addfbfb  pop r9
00007b629addfbfd  pop r8
00007b629addfbff  pop rsi
00007b629addfc00  pop rdi
00007b629addfc01  pop rdx
00007b629addfc02  pop rcx
00007b629addfc03  pop rax
00007b629addfc04  add rsp, 0x08
00007b629addfc08  jmp 0x00007B629ADDC473
00007b629addfc0d  call 0x00007B629ACB52F0
00007b629addfc12  jmp 0x00007B629ADDC4CE
00007b629addfc17  sub rsp, 0x08
00007b629addfc1b  push rax
00007b629addfc1c  push rcx
00007b629addfc1d  push rdx
00007b629addfc1e  push rdi
00007b629addfc1f  push rsi
00007b629addfc20  push r8
00007b629addfc22  push r9
00007b629addfc24  push r10
00007b629addfc26  push r11
00007b629addfc28  sub rsp, 0xF0
00007b629addfc2f  vmovaps [rsp], xmm0
00007b629addfc34  vmovaps [rsp+0x10], xmm1
00007b629addfc3a  vmovaps [rsp+0x20], xmm2
00007b629addfc40  vmovaps [rsp+0x30], xmm3
00007b629addfc46  vmovaps [rsp+0x40], xmm4
00007b629addfc4c  vmovaps [rsp+0x50], xmm5
00007b629addfc52  vmovaps [rsp+0x60], xmm6
00007b629addfc58  vmovaps [rsp+0x70], xmm7
00007b629addfc5e  vmovaps [rsp+0x80], xmm8
00007b629addfc67  vmovaps [rsp+0x90], xmm10
00007b629addfc70  vmovaps [rsp+0xA0], xmm11
00007b629addfc79  vmovaps [rsp+0xB0], xmm12
00007b629addfc82  vmovaps [rsp+0xC0], xmm13
00007b629addfc8b  vmovaps [rsp+0xD0], xmm14
00007b629addfc94  vmovaps [rsp+0xE0], xmm15
00007b629addfc9d  sub rsp, 0x30
00007b629addfca1  movaps [rsp], xmm9
00007b629addfca6  movaps [rsp+0x10], xmm8
00007b629addfcac  movaps [rsp+0x20], xmm11
00007b629addfcb2  lea rdi, [rsp]
00007b629addfcb6  mov esi, 0x00
00007b629addfcbb  mov rax, 0x583FED93F530
00007b629addfcc5  call rax
00007b629addfcc7  movaps xmm9, [rsp]
00007b629addfccc  add rsp, 0x30
00007b629addfcd0  vmovaps xmm0, [rsp]
00007b629addfcd5  vmovaps xmm1, [rsp+0x10]
00007b629addfcdb  vmovaps xmm2, [rsp+0x20]
00007b629addfce1  vmovaps xmm3, [rsp+0x30]
00007b629addfce7  vmovaps xmm4, [rsp+0x40]
00007b629addfced  vmovaps xmm5, [rsp+0x50]
00007b629addfcf3  vmovaps xmm6, [rsp+0x60]
00007b629addfcf9  vmovaps xmm7, [rsp+0x70]
00007b629addfcff  vmovaps xmm8, [rsp+0x80]
00007b629addfd08  vmovaps xmm10, [rsp+0x90]
00007b629addfd11  vmovaps xmm11, [rsp+0xA0]
00007b629addfd1a  vmovaps xmm12, [rsp+0xB0]
00007b629addfd23  vmovaps xmm13, [rsp+0xC0]
00007b629addfd2c  vmovaps xmm14, [rsp+0xD0]
00007b629addfd35  vmovaps xmm15, [rsp+0xE0]
00007b629addfd3e  add rsp, 0xF0
00007b629addfd45  pop r11
00007b629addfd47  pop r10
00007b629addfd49  pop r9
00007b629addfd4b  pop r8
00007b629addfd4d  pop rsi
00007b629addfd4e  pop rdi
00007b629addfd4f  pop rdx
00007b629addfd50  pop rcx
00007b629addfd51  pop rax
00007b629addfd52  add rsp, 0x08
00007b629addfd56  jmp 0x00007B629ADDC505
00007b629addfd5b  sub rsp, 0x08
00007b629addfd5f  push rax
00007b629addfd60  push rcx
00007b629addfd61  push rdx
00007b629addfd62  push rdi
00007b629addfd63  push rsi
00007b629addfd64  push r8
00007b629addfd66  push r9
00007b629addfd68  push r10
00007b629addfd6a  push r11
00007b629addfd6c  sub rsp, 0xF0
00007b629addfd73  vmovaps [rsp], xmm0
00007b629addfd78  vmovaps [rsp+0x10], xmm1
00007b629addfd7e  vmovaps [rsp+0x20], xmm2
00007b629addfd84  vmovaps [rsp+0x30], xmm3
00007b629addfd8a  vmovaps [rsp+0x40], xmm4
00007b629addfd90  vmovaps [rsp+0x50], xmm5
00007b629addfd96  vmovaps [rsp+0x60], xmm6
00007b629addfd9c  vmovaps [rsp+0x70], xmm7
00007b629addfda2  vmovaps [rsp+0x80], xmm8
00007b629addfdab  vmovaps [rsp+0x90], xmm9
00007b629addfdb4  vmovaps [rsp+0xA0], xmm10
00007b629addfdbd  vmovaps [rsp+0xB0], xmm12
00007b629addfdc6  vmovaps [rsp+0xC0], xmm13
00007b629addfdcf  vmovaps [rsp+0xD0], xmm14
00007b629addfdd8  vmovaps [rsp+0xE0], xmm15
00007b629addfde1  sub rsp, 0x30
00007b629addfde5  movaps [rsp], xmm11
00007b629addfdea  movaps [rsp+0x10], xmm10
00007b629addfdf0  movaps [rsp+0x20], xmm6
00007b629addfdf5  lea rdi, [rsp]
00007b629addfdf9  mov esi, 0x00
00007b629addfdfe  mov rax, 0x583FED93F530
00007b629addfe08  call rax
00007b629addfe0a  movaps xmm11, [rsp]
00007b629addfe0f  add rsp, 0x30
00007b629addfe13  vmovaps xmm0, [rsp]
00007b629addfe18  vmovaps xmm1, [rsp+0x10]
00007b629addfe1e  vmovaps xmm2, [rsp+0x20]
00007b629addfe24  vmovaps xmm3, [rsp+0x30]
00007b629addfe2a  vmovaps xmm4, [rsp+0x40]
00007b629addfe30  vmovaps xmm5, [rsp+0x50]
00007b629addfe36  vmovaps xmm6, [rsp+0x60]
00007b629addfe3c  vmovaps xmm7, [rsp+0x70]
00007b629addfe42  vmovaps xmm8, [rsp+0x80]
00007b629addfe4b  vmovaps xmm9, [rsp+0x90]
00007b629addfe54  vmovaps xmm10, [rsp+0xA0]
00007b629addfe5d  vmovaps xmm12, [rsp+0xB0]
00007b629addfe66  vmovaps xmm13, [rsp+0xC0]
00007b629addfe6f  vmovaps xmm14, [rsp+0xD0]
00007b629addfe78  vmovaps xmm15, [rsp+0xE0]
00007b629addfe81  add rsp, 0xF0
00007b629addfe88  pop r11
00007b629addfe8a  pop r10
00007b629addfe8c  pop r9
00007b629addfe8e  pop r8
00007b629addfe90  pop rsi
00007b629addfe91  pop rdi
00007b629addfe92  pop rdx
00007b629addfe93  pop rcx
00007b629addfe94  pop rax
00007b629addfe95  add rsp, 0x08
00007b629addfe99  jmp 0x00007B629ADDC520
00007b629addfe9e  sub rsp, 0x08
00007b629addfea2  push rax
00007b629addfea3  push rcx
00007b629addfea4  push rdx
00007b629addfea5  push rdi
00007b629addfea6  push rsi
00007b629addfea7  push r8
00007b629addfea9  push r9
00007b629addfeab  push r10
00007b629addfead  push r11
00007b629addfeaf  sub rsp, 0xF0
00007b629addfeb6  vmovaps [rsp], xmm0
00007b629addfebb  vmovaps [rsp+0x10], xmm1
00007b629addfec1  vmovaps [rsp+0x20], xmm2
00007b629addfec7  vmovaps [rsp+0x30], xmm3
00007b629addfecd  vmovaps [rsp+0x40], xmm4
00007b629addfed3  vmovaps [rsp+0x50], xmm5
00007b629addfed9  vmovaps [rsp+0x60], xmm6
00007b629addfedf  vmovaps [rsp+0x70], xmm7
00007b629addfee5  vmovaps [rsp+0x80], xmm8
00007b629addfeee  vmovaps [rsp+0x90], xmm9
00007b629addfef7  vmovaps [rsp+0xA0], xmm11
00007b629addff00  vmovaps [rsp+0xB0], xmm12
00007b629addff09  vmovaps [rsp+0xC0], xmm13
00007b629addff12  vmovaps [rsp+0xD0], xmm14
00007b629addff1b  vmovaps [rsp+0xE0], xmm15
00007b629addff24  sub rsp, 0x30
00007b629addff28  movaps [rsp], xmm10
00007b629addff2d  movaps [rsp+0x10], xmm14
00007b629addff33  movaps [rsp+0x20], xmm4
00007b629addff38  lea rdi, [rsp]
00007b629addff3c  mov esi, 0x00
00007b629addff41  mov rax, 0x583FED93F530
00007b629addff4b  call rax
00007b629addff4d  movaps xmm10, [rsp]
00007b629addff52  add rsp, 0x30
00007b629addff56  vmovaps xmm0, [rsp]
00007b629addff5b  vmovaps xmm1, [rsp+0x10]
00007b629addff61  vmovaps xmm2, [rsp+0x20]
00007b629addff67  vmovaps xmm3, [rsp+0x30]
00007b629addff6d  vmovaps xmm4, [rsp+0x40]
00007b629addff73  vmovaps xmm5, [rsp+0x50]
00007b629addff79  vmovaps xmm6, [rsp+0x60]
00007b629addff7f  vmovaps xmm7, [rsp+0x70]
00007b629addff85  vmovaps xmm8, [rsp+0x80]
00007b629addff8e  vmovaps xmm9, [rsp+0x90]
00007b629addff97  vmovaps xmm11, [rsp+0xA0]
00007b629addffa0  vmovaps xmm12, [rsp+0xB0]
00007b629addffa9  vmovaps xmm13, [rsp+0xC0]
00007b629addffb2  vmovaps xmm14, [rsp+0xD0]
00007b629addffbb  vmovaps xmm15, [rsp+0xE0]
00007b629addffc4  add rsp, 0xF0
00007b629addffcb  pop r11
00007b629addffcd  pop r10
00007b629addffcf  pop r9
00007b629addffd1  pop r8
00007b629addffd3  pop rsi
00007b629addffd4  pop rdi
00007b629addffd5  pop rdx
00007b629addffd6  pop rcx
00007b629addffd7  pop rax
00007b629addffd8  add rsp, 0x08
00007b629addffdc  jmp 0x00007B629ADDC53B
00007b629addffe1  sub rsp, 0x08
00007b629addffe5  push rax
00007b629addffe6  push rcx
00007b629addffe7  push rdx
00007b629addffe8  push rdi
00007b629addffe9  push rsi
00007b629addffea  push r8
00007b629addffec  push r9
00007b629addffee  push r10
00007b629addfff0  push r11
00007b629addfff2  sub rsp, 0xF0
00007b629addfff9  vmovaps [rsp], xmm0
00007b629addfffe  vmovaps [rsp+0x10], xmm1
00007b629ade0004  vmovaps [rsp+0x20], xmm2
00007b629ade000a  vmovaps [rsp+0x30], xmm3
00007b629ade0010  vmovaps [rsp+0x40], xmm4
00007b629ade0016  vmovaps [rsp+0x50], xmm5
00007b629ade001c  vmovaps [rsp+0x60], xmm6
00007b629ade0022  vmovaps [rsp+0x70], xmm7
00007b629ade0028  vmovaps [rsp+0x80], xmm9
00007b629ade0031  vmovaps [rsp+0x90], xmm10
00007b629ade003a  vmovaps [rsp+0xA0], xmm11
00007b629ade0043  vmovaps [rsp+0xB0], xmm12
00007b629ade004c  vmovaps [rsp+0xC0], xmm13
00007b629ade0055  vmovaps [rsp+0xD0], xmm14
00007b629ade005e  vmovaps [rsp+0xE0], xmm15
00007b629ade0067  sub rsp, 0x30
00007b629ade006b  movaps [rsp], xmm8
00007b629ade0070  movaps [rsp+0x10], xmm1
00007b629ade0075  movaps [rsp+0x20], xmm14
00007b629ade007b  lea rdi, [rsp]
00007b629ade007f  mov esi, 0x00
00007b629ade0084  mov rax, 0x583FED93F530
00007b629ade008e  call rax
00007b629ade0090  movaps xmm8, [rsp]
00007b629ade0095  add rsp, 0x30
00007b629ade0099  vmovaps xmm0, [rsp]
00007b629ade009e  vmovaps xmm1, [rsp+0x10]
00007b629ade00a4  vmovaps xmm2, [rsp+0x20]
00007b629ade00aa  vmovaps xmm3, [rsp+0x30]
00007b629ade00b0  vmovaps xmm4, [rsp+0x40]
00007b629ade00b6  vmovaps xmm5, [rsp+0x50]
00007b629ade00bc  vmovaps xmm6, [rsp+0x60]
00007b629ade00c2  vmovaps xmm7, [rsp+0x70]
00007b629ade00c8  vmovaps xmm9, [rsp+0x80]
00007b629ade00d1  vmovaps xmm10, [rsp+0x90]
00007b629ade00da  vmovaps xmm11, [rsp+0xA0]
00007b629ade00e3  vmovaps xmm12, [rsp+0xB0]
00007b629ade00ec  vmovaps xmm13, [rsp+0xC0]
00007b629ade00f5  vmovaps xmm14, [rsp+0xD0]
00007b629ade00fe  vmovaps xmm15, [rsp+0xE0]
00007b629ade0107  add rsp, 0xF0
00007b629ade010e  pop r11
00007b629ade0110  pop r10
00007b629ade0112  pop r9
00007b629ade0114  pop r8
00007b629ade0116  pop rsi
00007b629ade0117  pop rdi
00007b629ade0118  pop rdx
00007b629ade0119  pop rcx
00007b629ade011a  pop rax
00007b629ade011b  add rsp, 0x08
00007b629ade011f  jmp 0x00007B629ADDC561
00007b629ade0124  sub rsp, 0x08
00007b629ade0128  push rax
00007b629ade0129  push rcx
00007b629ade012a  push rdx
00007b629ade012b  push rdi
00007b629ade012c  push rsi
00007b629ade012d  push r8
00007b629ade012f  push r9
00007b629ade0131  push r10
00007b629ade0133  push r11
00007b629ade0135  sub rsp, 0xF0
00007b629ade013c  vmovaps [rsp], xmm0
00007b629ade0141  vmovaps [rsp+0x10], xmm1
00007b629ade0147  vmovaps [rsp+0x20], xmm2
00007b629ade014d  vmovaps [rsp+0x30], xmm3
00007b629ade0153  vmovaps [rsp+0x40], xmm4
00007b629ade0159  vmovaps [rsp+0x50], xmm5
00007b629ade015f  vmovaps [rsp+0x60], xmm7
00007b629ade0165  vmovaps [rsp+0x70], xmm8
00007b629ade016b  vmovaps [rsp+0x80], xmm9
00007b629ade0174  vmovaps [rsp+0x90], xmm10
00007b629ade017d  vmovaps [rsp+0xA0], xmm11
00007b629ade0186  vmovaps [rsp+0xB0], xmm12
00007b629ade018f  vmovaps [rsp+0xC0], xmm13
00007b629ade0198  vmovaps [rsp+0xD0], xmm14
00007b629ade01a1  vmovaps [rsp+0xE0], xmm15
00007b629ade01aa  sub rsp, 0x30
00007b629ade01ae  movaps [rsp], xmm6
00007b629ade01b2  movaps [rsp+0x10], xmm1
00007b629ade01b7  movaps [rsp+0x20], xmm14
00007b629ade01bd  lea rdi, [rsp]
00007b629ade01c1  mov esi, 0x00
00007b629ade01c6  mov rax, 0x583FED93F530
00007b629ade01d0  call rax
00007b629ade01d2  movaps xmm6, [rsp]
00007b629ade01d6  add rsp, 0x30
00007b629ade01da  vmovaps xmm0, [rsp]
00007b629ade01df  vmovaps xmm1, [rsp+0x10]
00007b629ade01e5  vmovaps xmm2, [rsp+0x20]
00007b629ade01eb  vmovaps xmm3, [rsp+0x30]
00007b629ade01f1  vmovaps xmm4, [rsp+0x40]
00007b629ade01f7  vmovaps xmm5, [rsp+0x50]
00007b629ade01fd  vmovaps xmm7, [rsp+0x60]
00007b629ade0203  vmovaps xmm8, [rsp+0x70]
00007b629ade0209  vmovaps xmm9, [rsp+0x80]
00007b629ade0212  vmovaps xmm10, [rsp+0x90]
00007b629ade021b  vmovaps xmm11, [rsp+0xA0]
00007b629ade0224  vmovaps xmm12, [rsp+0xB0]
00007b629ade022d  vmovaps xmm13, [rsp+0xC0]
00007b629ade0236  vmovaps xmm14, [rsp+0xD0]
00007b629ade023f  vmovaps xmm15, [rsp+0xE0]
00007b629ade0248  add rsp, 0xF0
00007b629ade024f  pop r11
00007b629ade0251  pop r10
00007b629ade0253  pop r9
00007b629ade0255  pop r8
00007b629ade0257  pop rsi
00007b629ade0258  pop rdi
00007b629ade0259  pop rdx
00007b629ade025a  pop rcx
00007b629ade025b  pop rax
00007b629ade025c  add rsp, 0x08
00007b629ade0260  jmp 0x00007B629ADDC58D
00007b629ade0265  sub rsp, 0x08
00007b629ade0269  push rax
00007b629ade026a  push rcx
00007b629ade026b  push rdx
00007b629ade026c  push rdi
00007b629ade026d  push rsi
00007b629ade026e  push r8
00007b629ade0270  push r9
00007b629ade0272  push r10
00007b629ade0274  push r11
00007b629ade0276  sub rsp, 0xF0
00007b629ade027d  vmovaps [rsp], xmm0
00007b629ade0282  vmovaps [rsp+0x10], xmm1
00007b629ade0288  vmovaps [rsp+0x20], xmm2
00007b629ade028e  vmovaps [rsp+0x30], xmm3
00007b629ade0294  vmovaps [rsp+0x40], xmm4
00007b629ade029a  vmovaps [rsp+0x50], xmm5
00007b629ade02a0  vmovaps [rsp+0x60], xmm6
00007b629ade02a6  vmovaps [rsp+0x70], xmm7
00007b629ade02ac  vmovaps [rsp+0x80], xmm8
00007b629ade02b5  vmovaps [rsp+0x90], xmm9
00007b629ade02be  vmovaps [rsp+0xA0], xmm10
00007b629ade02c7  vmovaps [rsp+0xB0], xmm11
00007b629ade02d0  vmovaps [rsp+0xC0], xmm12
00007b629ade02d9  vmovaps [rsp+0xD0], xmm13
00007b629ade02e2  vmovaps [rsp+0xE0], xmm15
00007b629ade02eb  sub rsp, 0x30
00007b629ade02ef  movaps [rsp], xmm14
00007b629ade02f4  movaps [rsp+0x10], xmm12
00007b629ade02fa  movaps [rsp+0x20], xmm1
00007b629ade02ff  lea rdi, [rsp]
00007b629ade0303  mov esi, 0x00
00007b629ade0308  mov rax, 0x583FED93F530
00007b629ade0312  call rax
00007b629ade0314  movaps xmm14, [rsp]
00007b629ade0319  add rsp, 0x30
00007b629ade031d  vmovaps xmm0, [rsp]
00007b629ade0322  vmovaps xmm1, [rsp+0x10]
00007b629ade0328  vmovaps xmm2, [rsp+0x20]
00007b629ade032e  vmovaps xmm3, [rsp+0x30]
00007b629ade0334  vmovaps xmm4, [rsp+0x40]
00007b629ade033a  vmovaps xmm5, [rsp+0x50]
00007b629ade0340  vmovaps xmm6, [rsp+0x60]
00007b629ade0346  vmovaps xmm7, [rsp+0x70]
00007b629ade034c  vmovaps xmm8, [rsp+0x80]
00007b629ade0355  vmovaps xmm9, [rsp+0x90]
00007b629ade035e  vmovaps xmm10, [rsp+0xA0]
00007b629ade0367  vmovaps xmm11, [rsp+0xB0]
00007b629ade0370  vmovaps xmm12, [rsp+0xC0]
00007b629ade0379  vmovaps xmm13, [rsp+0xD0]
00007b629ade0382  vmovaps xmm15, [rsp+0xE0]
00007b629ade038b  add rsp, 0xF0
00007b629ade0392  pop r11
00007b629ade0394  pop r10
00007b629ade0396  pop r9
00007b629ade0398  pop r8
00007b629ade039a  pop rsi
00007b629ade039b  pop rdi
00007b629ade039c  pop rdx
00007b629ade039d  pop rcx
00007b629ade039e  pop rax
00007b629ade039f  add rsp, 0x08
00007b629ade03a3  jmp 0x00007B629ADDC5B3
00007b629ade03a8  sub rsp, 0x08
00007b629ade03ac  push rax
00007b629ade03ad  push rcx
00007b629ade03ae  push rdx
00007b629ade03af  push rdi
00007b629ade03b0  push rsi
00007b629ade03b1  push r8
00007b629ade03b3  push r9
00007b629ade03b5  push r10
00007b629ade03b7  push r11
00007b629ade03b9  sub rsp, 0xF0
00007b629ade03c0  vmovaps [rsp], xmm0
00007b629ade03c5  vmovaps [rsp+0x10], xmm2
00007b629ade03cb  vmovaps [rsp+0x20], xmm3
00007b629ade03d1  vmovaps [rsp+0x30], xmm4
00007b629ade03d7  vmovaps [rsp+0x40], xmm5
00007b629ade03dd  vmovaps [rsp+0x50], xmm6
00007b629ade03e3  vmovaps [rsp+0x60], xmm7
00007b629ade03e9  vmovaps [rsp+0x70], xmm8
00007b629ade03ef  vmovaps [rsp+0x80], xmm9
00007b629ade03f8  vmovaps [rsp+0x90], xmm10
00007b629ade0401  vmovaps [rsp+0xA0], xmm11
00007b629ade040a  vmovaps [rsp+0xB0], xmm12
00007b629ade0413  vmovaps [rsp+0xC0], xmm13
00007b629ade041c  vmovaps [rsp+0xD0], xmm14
00007b629ade0425  vmovaps [rsp+0xE0], xmm15
00007b629ade042e  sub rsp, 0x30
00007b629ade0432  movaps [rsp], xmm1
00007b629ade0436  movaps [rsp+0x10], xmm13
00007b629ade043c  movaps [rsp+0x20], xmm9
00007b629ade0442  lea rdi, [rsp]
00007b629ade0446  mov esi, 0x00
00007b629ade044b  mov rax, 0x583FED93F530
00007b629ade0455  call rax
00007b629ade0457  movaps xmm1, [rsp]
00007b629ade045b  add rsp, 0x30
00007b629ade045f  vmovaps xmm0, [rsp]
00007b629ade0464  vmovaps xmm2, [rsp+0x10]
00007b629ade046a  vmovaps xmm3, [rsp+0x20]
00007b629ade0470  vmovaps xmm4, [rsp+0x30]
00007b629ade0476  vmovaps xmm5, [rsp+0x40]
00007b629ade047c  vmovaps xmm6, [rsp+0x50]
00007b629ade0482  vmovaps xmm7, [rsp+0x60]
00007b629ade0488  vmovaps xmm8, [rsp+0x70]
00007b629ade048e  vmovaps xmm9, [rsp+0x80]
00007b629ade0497  vmovaps xmm10, [rsp+0x90]
00007b629ade04a0  vmovaps xmm11, [rsp+0xA0]
00007b629ade04a9  vmovaps xmm12, [rsp+0xB0]
00007b629ade04b2  vmovaps xmm13, [rsp+0xC0]
00007b629ade04bb  vmovaps xmm14, [rsp+0xD0]
00007b629ade04c4  vmovaps xmm15, [rsp+0xE0]
00007b629ade04cd  add rsp, 0xF0
00007b629ade04d4  pop r11
00007b629ade04d6  pop r10
00007b629ade04d8  pop r9
00007b629ade04da  pop r8
00007b629ade04dc  pop rsi
00007b629ade04dd  pop rdi
00007b629ade04de  pop rdx
00007b629ade04df  pop rcx
00007b629ade04e0  pop rax
00007b629ade04e1  add rsp, 0x08
00007b629ade04e5  jmp 0x00007B629ADDC5CD
00007b629ade04ea  sub rsp, 0x08
00007b629ade04ee  push rax
00007b629ade04ef  push rcx
00007b629ade04f0  push rdx
00007b629ade04f1  push rdi
00007b629ade04f2  push rsi
00007b629ade04f3  push r8
00007b629ade04f5  push r9
00007b629ade04f7  push r10
00007b629ade04f9  push r11
00007b629ade04fb  sub rsp, 0xF0
00007b629ade0502  vmovaps [rsp], xmm0
00007b629ade0507  vmovaps [rsp+0x10], xmm1
00007b629ade050d  vmovaps [rsp+0x20], xmm2
00007b629ade0513  vmovaps [rsp+0x30], xmm3
00007b629ade0519  vmovaps [rsp+0x40], xmm4
00007b629ade051f  vmovaps [rsp+0x50], xmm5
00007b629ade0525  vmovaps [rsp+0x60], xmm6
00007b629ade052b  vmovaps [rsp+0x70], xmm7
00007b629ade0531  vmovaps [rsp+0x80], xmm8
00007b629ade053a  vmovaps [rsp+0x90], xmm9
00007b629ade0543  vmovaps [rsp+0xA0], xmm10
00007b629ade054c  vmovaps [rsp+0xB0], xmm11
00007b629ade0555  vmovaps [rsp+0xC0], xmm13
00007b629ade055e  vmovaps [rsp+0xD0], xmm14
00007b629ade0567  vmovaps [rsp+0xE0], xmm15
00007b629ade0570  sub rsp, 0x30
00007b629ade0574  movaps [rsp], xmm12
00007b629ade0579  movaps [rsp+0x10], xmm7
00007b629ade057e  movaps [rsp+0x20], xmm13
00007b629ade0584  lea rdi, [rsp]
00007b629ade0588  mov esi, 0x00
00007b629ade058d  mov rax, 0x583FED93F530
00007b629ade0597  call rax
00007b629ade0599  movaps xmm12, [rsp]
00007b629ade059e  add rsp, 0x30
00007b629ade05a2  vmovaps xmm0, [rsp]
00007b629ade05a7  vmovaps xmm1, [rsp+0x10]
00007b629ade05ad  vmovaps xmm2, [rsp+0x20]
00007b629ade05b3  vmovaps xmm3, [rsp+0x30]
00007b629ade05b9  vmovaps xmm4, [rsp+0x40]
00007b629ade05bf  vmovaps xmm5, [rsp+0x50]
00007b629ade05c5  vmovaps xmm6, [rsp+0x60]
00007b629ade05cb  vmovaps xmm7, [rsp+0x70]
00007b629ade05d1  vmovaps xmm8, [rsp+0x80]
00007b629ade05da  vmovaps xmm9, [rsp+0x90]
00007b629ade05e3  vmovaps xmm10, [rsp+0xA0]
00007b629ade05ec  vmovaps xmm11, [rsp+0xB0]
00007b629ade05f5  vmovaps xmm13, [rsp+0xC0]
00007b629ade05fe  vmovaps xmm14, [rsp+0xD0]
00007b629ade0607  vmovaps xmm15, [rsp+0xE0]
00007b629ade0610  add rsp, 0xF0
00007b629ade0617  pop r11
00007b629ade0619  pop r10
00007b629ade061b  pop r9
00007b629ade061d  pop r8
00007b629ade061f  pop rsi
00007b629ade0620  pop rdi
00007b629ade0621  pop rdx
00007b629ade0622  pop rcx
00007b629ade0623  pop rax
00007b629ade0624  add rsp, 0x08
00007b629ade0628  jmp 0x00007B629ADDC5F4
00007b629ade062d  sub rsp, 0x08
00007b629ade0631  push rax
00007b629ade0632  push rcx
00007b629ade0633  push rdx
00007b629ade0634  push rdi
00007b629ade0635  push rsi
00007b629ade0636  push r8
00007b629ade0638  push r9
00007b629ade063a  push r10
00007b629ade063c  push r11
00007b629ade063e  sub rsp, 0xF0
00007b629ade0645  vmovaps [rsp], xmm0
00007b629ade064a  vmovaps [rsp+0x10], xmm1
00007b629ade0650  vmovaps [rsp+0x20], xmm2
00007b629ade0656  vmovaps [rsp+0x30], xmm3
00007b629ade065c  vmovaps [rsp+0x40], xmm4
00007b629ade0662  vmovaps [rsp+0x50], xmm5
00007b629ade0668  vmovaps [rsp+0x60], xmm6
00007b629ade066e  vmovaps [rsp+0x70], xmm7
00007b629ade0674  vmovaps [rsp+0x80], xmm8
00007b629ade067d  vmovaps [rsp+0x90], xmm9
00007b629ade0686  vmovaps [rsp+0xA0], xmm10
00007b629ade068f  vmovaps [rsp+0xB0], xmm11
00007b629ade0698  vmovaps [rsp+0xC0], xmm12
00007b629ade06a1  vmovaps [rsp+0xD0], xmm14
00007b629ade06aa  vmovaps [rsp+0xE0], xmm15
00007b629ade06b3  sub rsp, 0x30
00007b629ade06b7  movaps [rsp], xmm13
00007b629ade06bc  movaps [rsp+0x10], xmm15
00007b629ade06c2  movaps [rsp+0x20], xmm8
00007b629ade06c8  lea rdi, [rsp]
00007b629ade06cc  mov esi, 0x00
00007b629ade06d1  mov rax, 0x583FED93F530
00007b629ade06db  call rax
00007b629ade06dd  movaps xmm13, [rsp]
00007b629ade06e2  add rsp, 0x30
00007b629ade06e6  vmovaps xmm0, [rsp]
00007b629ade06eb  vmovaps xmm1, [rsp+0x10]
00007b629ade06f1  vmovaps xmm2, [rsp+0x20]
00007b629ade06f7  vmovaps xmm3, [rsp+0x30]
00007b629ade06fd  vmovaps xmm4, [rsp+0x40]
00007b629ade0703  vmovaps xmm5, [rsp+0x50]
00007b629ade0709  vmovaps xmm6, [rsp+0x60]
00007b629ade070f  vmovaps xmm7, [rsp+0x70]
00007b629ade0715  vmovaps xmm8, [rsp+0x80]
00007b629ade071e  vmovaps xmm9, [rsp+0x90]
00007b629ade0727  vmovaps xmm10, [rsp+0xA0]
00007b629ade0730  vmovaps xmm11, [rsp+0xB0]
00007b629ade0739  vmovaps xmm12, [rsp+0xC0]
00007b629ade0742  vmovaps xmm14, [rsp+0xD0]
00007b629ade074b  vmovaps xmm15, [rsp+0xE0]
00007b629ade0754  add rsp, 0xF0
00007b629ade075b  pop r11
00007b629ade075d  pop r10
00007b629ade075f  pop r9
00007b629ade0761  pop r8
00007b629ade0763  pop rsi
00007b629ade0764  pop rdi
00007b629ade0765  pop rdx
00007b629ade0766  pop rcx
00007b629ade0767  pop rax
00007b629ade0768  add rsp, 0x08
00007b629ade076c  jmp 0x00007B629ADDC60F
00007b629ade0771  sub rsp, 0x08
00007b629ade0775  push rax
00007b629ade0776  push rcx
00007b629ade0777  push rdx
00007b629ade0778  push rdi
00007b629ade0779  push rsi
00007b629ade077a  push r8
00007b629ade077c  push r9
00007b629ade077e  push r10
00007b629ade0780  push r11
00007b629ade0782  sub rsp, 0xF0
00007b629ade0789  vmovaps [rsp], xmm0
00007b629ade078e  vmovaps [rsp+0x10], xmm1
00007b629ade0794  vmovaps [rsp+0x20], xmm2
00007b629ade079a  vmovaps [rsp+0x30], xmm3
00007b629ade07a0  vmovaps [rsp+0x40], xmm4
00007b629ade07a6  vmovaps [rsp+0x50], xmm5
00007b629ade07ac  vmovaps [rsp+0x60], xmm6
00007b629ade07b2  vmovaps [rsp+0x70], xmm7
00007b629ade07b8  vmovaps [rsp+0x80], xmm9
00007b629ade07c1  vmovaps [rsp+0x90], xmm10
00007b629ade07ca  vmovaps [rsp+0xA0], xmm11
00007b629ade07d3  vmovaps [rsp+0xB0], xmm12
00007b629ade07dc  vmovaps [rsp+0xC0], xmm13
00007b629ade07e5  vmovaps [rsp+0xD0], xmm14
00007b629ade07ee  vmovaps [rsp+0xE0], xmm15
00007b629ade07f7  sub rsp, 0x30
00007b629ade07fb  movaps [rsp], xmm8
00007b629ade0800  movaps [rsp+0x10], xmm15
00007b629ade0806  movaps [rsp+0x20], xmm9
00007b629ade080c  lea rdi, [rsp]
00007b629ade0810  mov esi, 0x00
00007b629ade0815  mov rax, 0x583FED93F530
00007b629ade081f  call rax
00007b629ade0821  movaps xmm8, [rsp]
00007b629ade0826  add rsp, 0x30
00007b629ade082a  vmovaps xmm0, [rsp]
00007b629ade082f  vmovaps xmm1, [rsp+0x10]
00007b629ade0835  vmovaps xmm2, [rsp+0x20]
00007b629ade083b  vmovaps xmm3, [rsp+0x30]
00007b629ade0841  vmovaps xmm4, [rsp+0x40]
00007b629ade0847  vmovaps xmm5, [rsp+0x50]
00007b629ade084d  vmovaps xmm6, [rsp+0x60]
00007b629ade0853  vmovaps xmm7, [rsp+0x70]
00007b629ade0859  vmovaps xmm9, [rsp+0x80]
00007b629ade0862  vmovaps xmm10, [rsp+0x90]
00007b629ade086b  vmovaps xmm11, [rsp+0xA0]
00007b629ade0874  vmovaps xmm12, [rsp+0xB0]
00007b629ade087d  vmovaps xmm13, [rsp+0xC0]
00007b629ade0886  vmovaps xmm14, [rsp+0xD0]
00007b629ade088f  vmovaps xmm15, [rsp+0xE0]
00007b629ade0898  add rsp, 0xF0
00007b629ade089f  pop r11
00007b629ade08a1  pop r10
00007b629ade08a3  pop r9
00007b629ade08a5  pop r8
00007b629ade08a7  pop rsi
00007b629ade08a8  pop rdi
00007b629ade08a9  pop rdx
00007b629ade08aa  pop rcx
00007b629ade08ab  pop rax
00007b629ade08ac  add rsp, 0x08
00007b629ade08b0  jmp 0x00007B629ADDC63D
00007b629ade08b5  sub rsp, 0x08
00007b629ade08b9  push rax
00007b629ade08ba  push rcx
00007b629ade08bb  push rdx
00007b629ade08bc  push rdi
00007b629ade08bd  push rsi
00007b629ade08be  push r8
00007b629ade08c0  push r9
00007b629ade08c2  push r10
00007b629ade08c4  push r11
00007b629ade08c6  sub rsp, 0xF0
00007b629ade08cd  vmovaps [rsp], xmm0
00007b629ade08d2  vmovaps [rsp+0x10], xmm1
00007b629ade08d8  vmovaps [rsp+0x20], xmm2
00007b629ade08de  vmovaps [rsp+0x30], xmm3
00007b629ade08e4  vmovaps [rsp+0x40], xmm4
00007b629ade08ea  vmovaps [rsp+0x50], xmm5
00007b629ade08f0  vmovaps [rsp+0x60], xmm6
00007b629ade08f6  vmovaps [rsp+0x70], xmm7
00007b629ade08fc  vmovaps [rsp+0x80], xmm8
00007b629ade0905  vmovaps [rsp+0x90], xmm9
00007b629ade090e  vmovaps [rsp+0xA0], xmm10
00007b629ade0917  vmovaps [rsp+0xB0], xmm11
00007b629ade0920  vmovaps [rsp+0xC0], xmm12
00007b629ade0929  vmovaps [rsp+0xD0], xmm13
00007b629ade0932  vmovaps [rsp+0xE0], xmm14
00007b629ade093b  sub rsp, 0x30
00007b629ade093f  movaps [rsp], xmm15
00007b629ade0944  movaps [rsp+0x10], xmm11
00007b629ade094a  movaps [rsp+0x20], xmm6
00007b629ade094f  lea rdi, [rsp]
00007b629ade0953  mov esi, 0x00
00007b629ade0958  mov rax, 0x583FED93F530
00007b629ade0962  call rax
00007b629ade0964  movaps xmm15, [rsp]
00007b629ade0969  add rsp, 0x30
00007b629ade096d  vmovaps xmm0, [rsp]
00007b629ade0972  vmovaps xmm1, [rsp+0x10]
00007b629ade0978  vmovaps xmm2, [rsp+0x20]
00007b629ade097e  vmovaps xmm3, [rsp+0x30]
00007b629ade0984  vmovaps xmm4, [rsp+0x40]
00007b629ade098a  vmovaps xmm5, [rsp+0x50]
00007b629ade0990  vmovaps xmm6, [rsp+0x60]
00007b629ade0996  vmovaps xmm7, [rsp+0x70]
00007b629ade099c  vmovaps xmm8, [rsp+0x80]
00007b629ade09a5  vmovaps xmm9, [rsp+0x90]
00007b629ade09ae  vmovaps xmm10, [rsp+0xA0]
00007b629ade09b7  vmovaps xmm11, [rsp+0xB0]
00007b629ade09c0  vmovaps xmm12, [rsp+0xC0]
00007b629ade09c9  vmovaps xmm13, [rsp+0xD0]
00007b629ade09d2  vmovaps xmm14, [rsp+0xE0]
00007b629ade09db  add rsp, 0xF0
00007b629ade09e2  pop r11
00007b629ade09e4  pop r10
00007b629ade09e6  pop r9
00007b629ade09e8  pop r8
00007b629ade09ea  pop rsi
00007b629ade09eb  pop rdi
00007b629ade09ec  pop rdx
00007b629ade09ed  pop rcx
00007b629ade09ee  pop rax
00007b629ade09ef  add rsp, 0x08
00007b629ade09f3  jmp 0x00007B629ADDC658
00007b629ade09f8  sub rsp, 0x08
00007b629ade09fc  push rax
00007b629ade09fd  push rcx
00007b629ade09fe  push rdx
00007b629ade09ff  push rdi
00007b629ade0a00  push rsi
00007b629ade0a01  push r8
00007b629ade0a03  push r9
00007b629ade0a05  push r10
00007b629ade0a07  push r11
00007b629ade0a09  sub rsp, 0xF0
00007b629ade0a10  vmovaps [rsp], xmm0
00007b629ade0a15  vmovaps [rsp+0x10], xmm1
00007b629ade0a1b  vmovaps [rsp+0x20], xmm2
00007b629ade0a21  vmovaps [rsp+0x30], xmm3
00007b629ade0a27  vmovaps [rsp+0x40], xmm4
00007b629ade0a2d  vmovaps [rsp+0x50], xmm5
00007b629ade0a33  vmovaps [rsp+0x60], xmm6
00007b629ade0a39  vmovaps [rsp+0x70], xmm8
00007b629ade0a3f  vmovaps [rsp+0x80], xmm9
00007b629ade0a48  vmovaps [rsp+0x90], xmm10
00007b629ade0a51  vmovaps [rsp+0xA0], xmm11
00007b629ade0a5a  vmovaps [rsp+0xB0], xmm12
00007b629ade0a63  vmovaps [rsp+0xC0], xmm13
00007b629ade0a6c  vmovaps [rsp+0xD0], xmm14
00007b629ade0a75  vmovaps [rsp+0xE0], xmm15
00007b629ade0a7e  sub rsp, 0x30
00007b629ade0a82  movaps [rsp], xmm7
00007b629ade0a86  movaps [rsp+0x10], xmm11
00007b629ade0a8c  movaps [rsp+0x20], xmm9
00007b629ade0a92  lea rdi, [rsp]
00007b629ade0a96  mov esi, 0x00
00007b629ade0a9b  mov rax, 0x583FED93F530
00007b629ade0aa5  call rax
00007b629ade0aa7  movaps xmm7, [rsp]
00007b629ade0aab  add rsp, 0x30
00007b629ade0aaf  vmovaps xmm0, [rsp]
00007b629ade0ab4  vmovaps xmm1, [rsp+0x10]
00007b629ade0aba  vmovaps xmm2, [rsp+0x20]
00007b629ade0ac0  vmovaps xmm3, [rsp+0x30]
00007b629ade0ac6  vmovaps xmm4, [rsp+0x40]
00007b629ade0acc  vmovaps xmm5, [rsp+0x50]
00007b629ade0ad2  vmovaps xmm6, [rsp+0x60]
00007b629ade0ad8  vmovaps xmm8, [rsp+0x70]
00007b629ade0ade  vmovaps xmm9, [rsp+0x80]
00007b629ade0ae7  vmovaps xmm10, [rsp+0x90]
00007b629ade0af0  vmovaps xmm11, [rsp+0xA0]
00007b629ade0af9  vmovaps xmm12, [rsp+0xB0]
00007b629ade0b02  vmovaps xmm13, [rsp+0xC0]
00007b629ade0b0b  vmovaps xmm14, [rsp+0xD0]
00007b629ade0b14  vmovaps xmm15, [rsp+0xE0]
00007b629ade0b1d  add rsp, 0xF0
00007b629ade0b24  pop r11
00007b629ade0b26  pop r10
00007b629ade0b28  pop r9
00007b629ade0b2a  pop r8
00007b629ade0b2c  pop rsi
00007b629ade0b2d  pop rdi
00007b629ade0b2e  pop rdx
00007b629ade0b2f  pop rcx
00007b629ade0b30  pop rax
00007b629ade0b31  add rsp, 0x08
00007b629ade0b35  jmp 0x00007B629ADDC685
00007b629ade0b3a  sub rsp, 0x08
00007b629ade0b3e  push rax
00007b629ade0b3f  push rcx
00007b629ade0b40  push rdx
00007b629ade0b41  push rdi
00007b629ade0b42  push rsi
00007b629ade0b43  push r8
00007b629ade0b45  push r9
00007b629ade0b47  push r10
00007b629ade0b49  push r11
00007b629ade0b4b  sub rsp, 0xF0
00007b629ade0b52  vmovaps [rsp], xmm0
00007b629ade0b57  vmovaps [rsp+0x10], xmm1
00007b629ade0b5d  vmovaps [rsp+0x20], xmm2
00007b629ade0b63  vmovaps [rsp+0x30], xmm3
00007b629ade0b69  vmovaps [rsp+0x40], xmm4
00007b629ade0b6f  vmovaps [rsp+0x50], xmm5
00007b629ade0b75  vmovaps [rsp+0x60], xmm6
00007b629ade0b7b  vmovaps [rsp+0x70], xmm7
00007b629ade0b81  vmovaps [rsp+0x80], xmm8
00007b629ade0b8a  vmovaps [rsp+0x90], xmm9
00007b629ade0b93  vmovaps [rsp+0xA0], xmm10
00007b629ade0b9c  vmovaps [rsp+0xB0], xmm12
00007b629ade0ba5  vmovaps [rsp+0xC0], xmm13
00007b629ade0bae  vmovaps [rsp+0xD0], xmm14
00007b629ade0bb7  vmovaps [rsp+0xE0], xmm15
00007b629ade0bc0  sub rsp, 0x30
00007b629ade0bc4  movaps [rsp], xmm11
00007b629ade0bc9  movaps [rsp+0x10], xmm10
00007b629ade0bcf  movaps [rsp+0x20], xmm14
00007b629ade0bd5  lea rdi, [rsp]
00007b629ade0bd9  mov esi, 0x00
00007b629ade0bde  mov rax, 0x583FED93F530
00007b629ade0be8  call rax
00007b629ade0bea  movaps xmm11, [rsp]
00007b629ade0bef  add rsp, 0x30
00007b629ade0bf3  vmovaps xmm0, [rsp]
00007b629ade0bf8  vmovaps xmm1, [rsp+0x10]
00007b629ade0bfe  vmovaps xmm2, [rsp+0x20]
00007b629ade0c04  vmovaps xmm3, [rsp+0x30]
00007b629ade0c0a  vmovaps xmm4, [rsp+0x40]
00007b629ade0c10  vmovaps xmm5, [rsp+0x50]
00007b629ade0c16  vmovaps xmm6, [rsp+0x60]
00007b629ade0c1c  vmovaps xmm7, [rsp+0x70]
00007b629ade0c22  vmovaps xmm8, [rsp+0x80]
00007b629ade0c2b  vmovaps xmm9, [rsp+0x90]
00007b629ade0c34  vmovaps xmm10, [rsp+0xA0]
00007b629ade0c3d  vmovaps xmm12, [rsp+0xB0]
00007b629ade0c46  vmovaps xmm13, [rsp+0xC0]
00007b629ade0c4f  vmovaps xmm14, [rsp+0xD0]
00007b629ade0c58  vmovaps xmm15, [rsp+0xE0]
00007b629ade0c61  add rsp, 0xF0
00007b629ade0c68  pop r11
00007b629ade0c6a  pop r10
00007b629ade0c6c  pop r9
00007b629ade0c6e  pop r8
00007b629ade0c70  pop rsi
00007b629ade0c71  pop rdi
00007b629ade0c72  pop rdx
00007b629ade0c73  pop rcx
00007b629ade0c74  pop rax
00007b629ade0c75  add rsp, 0x08
00007b629ade0c79  jmp 0x00007B629ADDC6A0
00007b629ade0c7e  call 0x00007B629ACC33A0
00007b629ade0c83  jmp 0x00007B629ADDC6AA
00007b629ade0c88  sub rsp, 0x08
00007b629ade0c8c  push rax
00007b629ade0c8d  push rcx
00007b629ade0c8e  push rdx
00007b629ade0c8f  push rdi
00007b629ade0c90  push rsi
00007b629ade0c91  push r8
00007b629ade0c93  push r9
00007b629ade0c95  push r10
00007b629ade0c97  push r11
00007b629ade0c99  sub rsp, 0xF0
00007b629ade0ca0  vmovaps [rsp], xmm0
00007b629ade0ca5  vmovaps [rsp+0x10], xmm1
00007b629ade0cab  vmovaps [rsp+0x20], xmm2
00007b629ade0cb1  vmovaps [rsp+0x30], xmm3
00007b629ade0cb7  vmovaps [rsp+0x40], xmm4
00007b629ade0cbd  vmovaps [rsp+0x50], xmm5
00007b629ade0cc3  vmovaps [rsp+0x60], xmm6
00007b629ade0cc9  vmovaps [rsp+0x70], xmm7
00007b629ade0ccf  vmovaps [rsp+0x80], xmm8
00007b629ade0cd8  vmovaps [rsp+0x90], xmm9
00007b629ade0ce1  vmovaps [rsp+0xA0], xmm11
00007b629ade0cea  vmovaps [rsp+0xB0], xmm12
00007b629ade0cf3  vmovaps [rsp+0xC0], xmm13
00007b629ade0cfc  vmovaps [rsp+0xD0], xmm14
00007b629ade0d05  vmovaps [rsp+0xE0], xmm15
00007b629ade0d0e  sub rsp, 0x30
00007b629ade0d12  movaps [rsp], xmm10
00007b629ade0d17  movaps [rsp+0x10], xmm1
00007b629ade0d1c  movaps [rsp+0x20], xmm12
00007b629ade0d22  lea rdi, [rsp]
00007b629ade0d26  mov esi, 0x00
00007b629ade0d2b  mov rax, 0x583FED93F530
00007b629ade0d35  call rax
00007b629ade0d37  movaps xmm10, [rsp]
00007b629ade0d3c  add rsp, 0x30
00007b629ade0d40  vmovaps xmm0, [rsp]
00007b629ade0d45  vmovaps xmm1, [rsp+0x10]
00007b629ade0d4b  vmovaps xmm2, [rsp+0x20]
00007b629ade0d51  vmovaps xmm3, [rsp+0x30]
00007b629ade0d57  vmovaps xmm4, [rsp+0x40]
00007b629ade0d5d  vmovaps xmm5, [rsp+0x50]
00007b629ade0d63  vmovaps xmm6, [rsp+0x60]
00007b629ade0d69  vmovaps xmm7, [rsp+0x70]
00007b629ade0d6f  vmovaps xmm8, [rsp+0x80]
00007b629ade0d78  vmovaps xmm9, [rsp+0x90]
00007b629ade0d81  vmovaps xmm11, [rsp+0xA0]
00007b629ade0d8a  vmovaps xmm12, [rsp+0xB0]
00007b629ade0d93  vmovaps xmm13, [rsp+0xC0]
00007b629ade0d9c  vmovaps xmm14, [rsp+0xD0]
00007b629ade0da5  vmovaps xmm15, [rsp+0xE0]
00007b629ade0dae  add rsp, 0xF0
00007b629ade0db5  pop r11
00007b629ade0db7  pop r10
00007b629ade0db9  pop r9
00007b629ade0dbb  pop r8
00007b629ade0dbd  pop rsi
00007b629ade0dbe  pop rdi
00007b629ade0dbf  pop rdx
00007b629ade0dc0  pop rcx
00007b629ade0dc1  pop rax
00007b629ade0dc2  add rsp, 0x08
00007b629ade0dc6  jmp 0x00007B629ADDC6CD
00007b629ade0dcb  sub rsp, 0x08
00007b629ade0dcf  push rax
00007b629ade0dd0  push rcx
00007b629ade0dd1  push rdx
00007b629ade0dd2  push rdi
00007b629ade0dd3  push rsi
00007b629ade0dd4  push r8
00007b629ade0dd6  push r9
00007b629ade0dd8  push r10
00007b629ade0dda  push r11
00007b629ade0ddc  sub rsp, 0xF0
00007b629ade0de3  vmovaps [rsp], xmm0
00007b629ade0de8  vmovaps [rsp+0x10], xmm1
00007b629ade0dee  vmovaps [rsp+0x20], xmm2
00007b629ade0df4  vmovaps [rsp+0x30], xmm3
00007b629ade0dfa  vmovaps [rsp+0x40], xmm4
00007b629ade0e00  vmovaps [rsp+0x50], xmm5
00007b629ade0e06  vmovaps [rsp+0x60], xmm6
00007b629ade0e0c  vmovaps [rsp+0x70], xmm7
00007b629ade0e12  vmovaps [rsp+0x80], xmm8
00007b629ade0e1b  vmovaps [rsp+0x90], xmm9
00007b629ade0e24  vmovaps [rsp+0xA0], xmm10
00007b629ade0e2d  vmovaps [rsp+0xB0], xmm11
00007b629ade0e36  vmovaps [rsp+0xC0], xmm13
00007b629ade0e3f  vmovaps [rsp+0xD0], xmm14
00007b629ade0e48  vmovaps [rsp+0xE0], xmm15
00007b629ade0e51  sub rsp, 0x30
00007b629ade0e55  movaps [rsp], xmm12
00007b629ade0e5a  movaps [rsp+0x10], xmm14
00007b629ade0e60  movaps [rsp+0x20], xmm1
00007b629ade0e65  lea rdi, [rsp]
00007b629ade0e69  mov esi, 0x00
00007b629ade0e6e  mov rax, 0x583FED93F530
00007b629ade0e78  call rax
00007b629ade0e7a  movaps xmm12, [rsp]
00007b629ade0e7f  add rsp, 0x30
00007b629ade0e83  vmovaps xmm0, [rsp]
00007b629ade0e88  vmovaps xmm1, [rsp+0x10]
00007b629ade0e8e  vmovaps xmm2, [rsp+0x20]
00007b629ade0e94  vmovaps xmm3, [rsp+0x30]
00007b629ade0e9a  vmovaps xmm4, [rsp+0x40]
00007b629ade0ea0  vmovaps xmm5, [rsp+0x50]
00007b629ade0ea6  vmovaps xmm6, [rsp+0x60]
00007b629ade0eac  vmovaps xmm7, [rsp+0x70]
00007b629ade0eb2  vmovaps xmm8, [rsp+0x80]
00007b629ade0ebb  vmovaps xmm9, [rsp+0x90]
00007b629ade0ec4  vmovaps xmm10, [rsp+0xA0]
00007b629ade0ecd  vmovaps xmm11, [rsp+0xB0]
00007b629ade0ed6  vmovaps xmm13, [rsp+0xC0]
00007b629ade0edf  vmovaps xmm14, [rsp+0xD0]
00007b629ade0ee8  vmovaps xmm15, [rsp+0xE0]
00007b629ade0ef1  add rsp, 0xF0
00007b629ade0ef8  pop r11
00007b629ade0efa  pop r10
00007b629ade0efc  pop r9
00007b629ade0efe  pop r8
00007b629ade0f00  pop rsi
00007b629ade0f01  pop rdi
00007b629ade0f02  pop rdx
00007b629ade0f03  pop rcx
00007b629ade0f04  pop rax
00007b629ade0f05  add rsp, 0x08
00007b629ade0f09  jmp 0x00007B629ADDC6FC
00007b629ade0f0e  sub rsp, 0x08
00007b629ade0f12  push rax
00007b629ade0f13  push rcx
00007b629ade0f14  push rdx
00007b629ade0f15  push rdi
00007b629ade0f16  push rsi
00007b629ade0f17  push r8
00007b629ade0f19  push r9
00007b629ade0f1b  push r10
00007b629ade0f1d  push r11
00007b629ade0f1f  sub rsp, 0xF0
00007b629ade0f26  vmovaps [rsp], xmm0
00007b629ade0f2b  vmovaps [rsp+0x10], xmm1
00007b629ade0f31  vmovaps [rsp+0x20], xmm2
00007b629ade0f37  vmovaps [rsp+0x30], xmm3
00007b629ade0f3d  vmovaps [rsp+0x40], xmm4
00007b629ade0f43  vmovaps [rsp+0x50], xmm5
00007b629ade0f49  vmovaps [rsp+0x60], xmm6
00007b629ade0f4f  vmovaps [rsp+0x70], xmm7
00007b629ade0f55  vmovaps [rsp+0x80], xmm8
00007b629ade0f5e  vmovaps [rsp+0x90], xmm9
00007b629ade0f67  vmovaps [rsp+0xA0], xmm10
00007b629ade0f70  vmovaps [rsp+0xB0], xmm11
00007b629ade0f79  vmovaps [rsp+0xC0], xmm12
00007b629ade0f82  vmovaps [rsp+0xD0], xmm13
00007b629ade0f8b  vmovaps [rsp+0xE0], xmm15
00007b629ade0f94  sub rsp, 0x30
00007b629ade0f98  movaps [rsp], xmm14
00007b629ade0f9d  movaps [rsp+0x10], xmm9
00007b629ade0fa3  movaps [rsp+0x20], xmm1
00007b629ade0fa8  lea rdi, [rsp]
00007b629ade0fac  mov esi, 0x00
00007b629ade0fb1  mov rax, 0x583FED93F530
00007b629ade0fbb  call rax
00007b629ade0fbd  movaps xmm14, [rsp]
00007b629ade0fc2  add rsp, 0x30
00007b629ade0fc6  vmovaps xmm0, [rsp]
00007b629ade0fcb  vmovaps xmm1, [rsp+0x10]
00007b629ade0fd1  vmovaps xmm2, [rsp+0x20]
00007b629ade0fd7  vmovaps xmm3, [rsp+0x30]
00007b629ade0fdd  vmovaps xmm4, [rsp+0x40]
00007b629ade0fe3  vmovaps xmm5, [rsp+0x50]
00007b629ade0fe9  vmovaps xmm6, [rsp+0x60]
00007b629ade0fef  vmovaps xmm7, [rsp+0x70]
00007b629ade0ff5  vmovaps xmm8, [rsp+0x80]
00007b629ade0ffe  vmovaps xmm9, [rsp+0x90]
00007b629ade1007  vmovaps xmm10, [rsp+0xA0]
00007b629ade1010  vmovaps xmm11, [rsp+0xB0]
00007b629ade1019  vmovaps xmm12, [rsp+0xC0]
00007b629ade1022  vmovaps xmm13, [rsp+0xD0]
00007b629ade102b  vmovaps xmm15, [rsp+0xE0]
00007b629ade1034  add rsp, 0xF0
00007b629ade103b  pop r11
00007b629ade103d  pop r10
00007b629ade103f  pop r9
00007b629ade1041  pop r8
00007b629ade1043  pop rsi
00007b629ade1044  pop rdi
00007b629ade1045  pop rdx
00007b629ade1046  pop rcx
00007b629ade1047  pop rax
00007b629ade1048  add rsp, 0x08
00007b629ade104c  jmp 0x00007B629ADDC72B
00007b629ade1051  sub rsp, 0x08
00007b629ade1055  push rax
00007b629ade1056  push rcx
00007b629ade1057  push rdx
00007b629ade1058  push rdi
00007b629ade1059  push rsi
00007b629ade105a  push r8
00007b629ade105c  push r9
00007b629ade105e  push r10
00007b629ade1060  push r11
00007b629ade1062  sub rsp, 0xF0
00007b629ade1069  vmovaps [rsp], xmm0
00007b629ade106e  vmovaps [rsp+0x10], xmm2
00007b629ade1074  vmovaps [rsp+0x20], xmm3
00007b629ade107a  vmovaps [rsp+0x30], xmm4
00007b629ade1080  vmovaps [rsp+0x40], xmm5
00007b629ade1086  vmovaps [rsp+0x50], xmm6
00007b629ade108c  vmovaps [rsp+0x60], xmm7
00007b629ade1092  vmovaps [rsp+0x70], xmm8
00007b629ade1098  vmovaps [rsp+0x80], xmm9
00007b629ade10a1  vmovaps [rsp+0x90], xmm10
00007b629ade10aa  vmovaps [rsp+0xA0], xmm11
00007b629ade10b3  vmovaps [rsp+0xB0], xmm12
00007b629ade10bc  vmovaps [rsp+0xC0], xmm13
00007b629ade10c5  vmovaps [rsp+0xD0], xmm14
00007b629ade10ce  vmovaps [rsp+0xE0], xmm15
00007b629ade10d7  sub rsp, 0x30
00007b629ade10db  movaps [rsp], xmm1
00007b629ade10df  movaps [rsp+0x10], xmm13
00007b629ade10e5  movaps [rsp+0x20], xmm8
00007b629ade10eb  lea rdi, [rsp]
00007b629ade10ef  mov esi, 0x00
00007b629ade10f4  mov rax, 0x583FED93F530
00007b629ade10fe  call rax
00007b629ade1100  movaps xmm1, [rsp]
00007b629ade1104  add rsp, 0x30
00007b629ade1108  vmovaps xmm0, [rsp]
00007b629ade110d  vmovaps xmm2, [rsp+0x10]
00007b629ade1113  vmovaps xmm3, [rsp+0x20]
00007b629ade1119  vmovaps xmm4, [rsp+0x30]
00007b629ade111f  vmovaps xmm5, [rsp+0x40]
00007b629ade1125  vmovaps xmm6, [rsp+0x50]
00007b629ade112b  vmovaps xmm7, [rsp+0x60]
00007b629ade1131  vmovaps xmm8, [rsp+0x70]
00007b629ade1137  vmovaps xmm9, [rsp+0x80]
00007b629ade1140  vmovaps xmm10, [rsp+0x90]
00007b629ade1149  vmovaps xmm11, [rsp+0xA0]
00007b629ade1152  vmovaps xmm12, [rsp+0xB0]
00007b629ade115b  vmovaps xmm13, [rsp+0xC0]
00007b629ade1164  vmovaps xmm14, [rsp+0xD0]
00007b629ade116d  vmovaps xmm15, [rsp+0xE0]
00007b629ade1176  add rsp, 0xF0
00007b629ade117d  pop r11
00007b629ade117f  pop r10
00007b629ade1181  pop r9
00007b629ade1183  pop r8
00007b629ade1185  pop rsi
00007b629ade1186  pop rdi
00007b629ade1187  pop rdx
00007b629ade1188  pop rcx
00007b629ade1189  pop rax
00007b629ade118a  add rsp, 0x08
00007b629ade118e  jmp 0x00007B629ADDC74D
00007b629ade1193  call 0x00007B629AC0C260
00007b629ade1198  jmp 0x00007B629ADDC75B
00007b629ade119d  call 0x00007B629ACBD750
00007b629ade11a2  jmp 0x00007B629ADDC765
00007b629ade11a7  sub rsp, 0x08
00007b629ade11ab  push rax
00007b629ade11ac  push rcx
00007b629ade11ad  push rdx
00007b629ade11ae  push rdi
00007b629ade11af  push rsi
00007b629ade11b0  push r8
00007b629ade11b2  push r9
00007b629ade11b4  push r10
00007b629ade11b6  push r11
00007b629ade11b8  sub rsp, 0xF0
00007b629ade11bf  vmovaps [rsp], xmm0
00007b629ade11c4  vmovaps [rsp+0x10], xmm1
00007b629ade11ca  vmovaps [rsp+0x20], xmm2
00007b629ade11d0  vmovaps [rsp+0x30], xmm3
00007b629ade11d6  vmovaps [rsp+0x40], xmm4
00007b629ade11dc  vmovaps [rsp+0x50], xmm5
00007b629ade11e2  vmovaps [rsp+0x60], xmm6
00007b629ade11e8  vmovaps [rsp+0x70], xmm7
00007b629ade11ee  vmovaps [rsp+0x80], xmm9
00007b629ade11f7  vmovaps [rsp+0x90], xmm10
00007b629ade1200  vmovaps [rsp+0xA0], xmm11
00007b629ade1209  vmovaps [rsp+0xB0], xmm12
00007b629ade1212  vmovaps [rsp+0xC0], xmm13
00007b629ade121b  vmovaps [rsp+0xD0], xmm14
00007b629ade1224  vmovaps [rsp+0xE0], xmm15
00007b629ade122d  sub rsp, 0x30
00007b629ade1231  movaps [rsp], xmm8
00007b629ade1236  movaps [rsp+0x10], xmm15
00007b629ade123c  movaps [rsp+0x20], xmm7
00007b629ade1241  lea rdi, [rsp]
00007b629ade1245  mov esi, 0x00
00007b629ade124a  mov rax, 0x583FED93F530
00007b629ade1254  call rax
00007b629ade1256  movaps xmm8, [rsp]
00007b629ade125b  add rsp, 0x30
00007b629ade125f  vmovaps xmm0, [rsp]
00007b629ade1264  vmovaps xmm1, [rsp+0x10]
00007b629ade126a  vmovaps xmm2, [rsp+0x20]
00007b629ade1270  vmovaps xmm3, [rsp+0x30]
00007b629ade1276  vmovaps xmm4, [rsp+0x40]
00007b629ade127c  vmovaps xmm5, [rsp+0x50]
00007b629ade1282  vmovaps xmm6, [rsp+0x60]
00007b629ade1288  vmovaps xmm7, [rsp+0x70]
00007b629ade128e  vmovaps xmm9, [rsp+0x80]
00007b629ade1297  vmovaps xmm10, [rsp+0x90]
00007b629ade12a0  vmovaps xmm11, [rsp+0xA0]
00007b629ade12a9  vmovaps xmm12, [rsp+0xB0]
00007b629ade12b2  vmovaps xmm13, [rsp+0xC0]
00007b629ade12bb  vmovaps xmm14, [rsp+0xD0]
00007b629ade12c4  vmovaps xmm15, [rsp+0xE0]
00007b629ade12cd  add rsp, 0xF0
00007b629ade12d4  pop r11
00007b629ade12d6  pop r10
00007b629ade12d8  pop r9
00007b629ade12da  pop r8
00007b629ade12dc  pop rsi
00007b629ade12dd  pop rdi
00007b629ade12de  pop rdx
00007b629ade12df  pop rcx
00007b629ade12e0  pop rax
00007b629ade12e1  add rsp, 0x08
00007b629ade12e5  jmp 0x00007B629ADDC787
00007b629ade12ea  sub rsp, 0x08
00007b629ade12ee  push rax
00007b629ade12ef  push rcx
00007b629ade12f0  push rdx
00007b629ade12f1  push rdi
00007b629ade12f2  push rsi
00007b629ade12f3  push r8
00007b629ade12f5  push r9
00007b629ade12f7  push r10
00007b629ade12f9  push r11
00007b629ade12fb  sub rsp, 0xF0
00007b629ade1302  vmovaps [rsp], xmm0
00007b629ade1307  vmovaps [rsp+0x10], xmm1
00007b629ade130d  vmovaps [rsp+0x20], xmm2
00007b629ade1313  vmovaps [rsp+0x30], xmm3
00007b629ade1319  vmovaps [rsp+0x40], xmm4
00007b629ade131f  vmovaps [rsp+0x50], xmm5
00007b629ade1325  vmovaps [rsp+0x60], xmm6
00007b629ade132b  vmovaps [rsp+0x70], xmm8
00007b629ade1331  vmovaps [rsp+0x80], xmm9
00007b629ade133a  vmovaps [rsp+0x90], xmm10
00007b629ade1343  vmovaps [rsp+0xA0], xmm11
00007b629ade134c  vmovaps [rsp+0xB0], xmm12
00007b629ade1355  vmovaps [rsp+0xC0], xmm13
00007b629ade135e  vmovaps [rsp+0xD0], xmm14
00007b629ade1367  vmovaps [rsp+0xE0], xmm15
00007b629ade1370  sub rsp, 0x30
00007b629ade1374  movaps [rsp], xmm7
00007b629ade1378  movaps [rsp+0x10], xmm9
00007b629ade137e  movaps [rsp+0x20], xmm15
00007b629ade1384  lea rdi, [rsp]
00007b629ade1388  mov esi, 0x00
00007b629ade138d  mov rax, 0x583FED93F530
00007b629ade1397  call rax
00007b629ade1399  movaps xmm7, [rsp]
00007b629ade139d  add rsp, 0x30
00007b629ade13a1  vmovaps xmm0, [rsp]
00007b629ade13a6  vmovaps xmm1, [rsp+0x10]
00007b629ade13ac  vmovaps xmm2, [rsp+0x20]
00007b629ade13b2  vmovaps xmm3, [rsp+0x30]
00007b629ade13b8  vmovaps xmm4, [rsp+0x40]
00007b629ade13be  vmovaps xmm5, [rsp+0x50]
00007b629ade13c4  vmovaps xmm6, [rsp+0x60]
00007b629ade13ca  vmovaps xmm8, [rsp+0x70]
00007b629ade13d0  vmovaps xmm9, [rsp+0x80]
00007b629ade13d9  vmovaps xmm10, [rsp+0x90]
00007b629ade13e2  vmovaps xmm11, [rsp+0xA0]
00007b629ade13eb  vmovaps xmm12, [rsp+0xB0]
00007b629ade13f4  vmovaps xmm13, [rsp+0xC0]
00007b629ade13fd  vmovaps xmm14, [rsp+0xD0]
00007b629ade1406  vmovaps xmm15, [rsp+0xE0]
00007b629ade140f  add rsp, 0xF0
00007b629ade1416  pop r11
00007b629ade1418  pop r10
00007b629ade141a  pop r9
00007b629ade141c  pop r8
00007b629ade141e  pop rsi
00007b629ade141f  pop rdi
00007b629ade1420  pop rdx
00007b629ade1421  pop rcx
00007b629ade1422  pop rax
00007b629ade1423  add rsp, 0x08
00007b629ade1427  jmp 0x00007B629ADDC7B4
00007b629ade142c  sub rsp, 0x08
00007b629ade1430  push rax
00007b629ade1431  push rcx
00007b629ade1432  push rdx
00007b629ade1433  push rdi
00007b629ade1434  push rsi
00007b629ade1435  push r8
00007b629ade1437  push r9
00007b629ade1439  push r10
00007b629ade143b  push r11
00007b629ade143d  sub rsp, 0xF0
00007b629ade1444  vmovaps [rsp], xmm0
00007b629ade1449  vmovaps [rsp+0x10], xmm1
00007b629ade144f  vmovaps [rsp+0x20], xmm2
00007b629ade1455  vmovaps [rsp+0x30], xmm3
00007b629ade145b  vmovaps [rsp+0x40], xmm4
00007b629ade1461  vmovaps [rsp+0x50], xmm5
00007b629ade1467  vmovaps [rsp+0x60], xmm6
00007b629ade146d  vmovaps [rsp+0x70], xmm7
00007b629ade1473  vmovaps [rsp+0x80], xmm8
00007b629ade147c  vmovaps [rsp+0x90], xmm10
00007b629ade1485  vmovaps [rsp+0xA0], xmm11
00007b629ade148e  vmovaps [rsp+0xB0], xmm12
00007b629ade1497  vmovaps [rsp+0xC0], xmm13
00007b629ade14a0  vmovaps [rsp+0xD0], xmm14
00007b629ade14a9  vmovaps [rsp+0xE0], xmm15
00007b629ade14b2  sub rsp, 0x30
00007b629ade14b6  movaps [rsp], xmm9
00007b629ade14bb  movaps [rsp+0x10], xmm13
00007b629ade14c1  movaps [rsp+0x20], xmm15
00007b629ade14c7  lea rdi, [rsp]
00007b629ade14cb  mov esi, 0x00
00007b629ade14d0  mov rax, 0x583FED93F530
00007b629ade14da  call rax
00007b629ade14dc  movaps xmm9, [rsp]
00007b629ade14e1  add rsp, 0x30
00007b629ade14e5  vmovaps xmm0, [rsp]
00007b629ade14ea  vmovaps xmm1, [rsp+0x10]
00007b629ade14f0  vmovaps xmm2, [rsp+0x20]
00007b629ade14f6  vmovaps xmm3, [rsp+0x30]
00007b629ade14fc  vmovaps xmm4, [rsp+0x40]
00007b629ade1502  vmovaps xmm5, [rsp+0x50]
00007b629ade1508  vmovaps xmm6, [rsp+0x60]
00007b629ade150e  vmovaps xmm7, [rsp+0x70]
00007b629ade1514  vmovaps xmm8, [rsp+0x80]
00007b629ade151d  vmovaps xmm10, [rsp+0x90]
00007b629ade1526  vmovaps xmm11, [rsp+0xA0]
00007b629ade152f  vmovaps xmm12, [rsp+0xB0]
00007b629ade1538  vmovaps xmm13, [rsp+0xC0]
00007b629ade1541  vmovaps xmm14, [rsp+0xD0]
00007b629ade154a  vmovaps xmm15, [rsp+0xE0]
00007b629ade1553  add rsp, 0xF0
00007b629ade155a  pop r11
00007b629ade155c  pop r10
00007b629ade155e  pop r9
00007b629ade1560  pop r8
00007b629ade1562  pop rsi
00007b629ade1563  pop rdi
00007b629ade1564  pop rdx
00007b629ade1565  pop rcx
00007b629ade1566  pop rax
00007b629ade1567  add rsp, 0x08
00007b629ade156b  jmp 0x00007B629ADDC7E2
00007b629ade1570  sub rsp, 0x08
00007b629ade1574  push rax
00007b629ade1575  push rcx
00007b629ade1576  push rdx
00007b629ade1577  push rdi
00007b629ade1578  push rsi
00007b629ade1579  push r8
00007b629ade157b  push r9
00007b629ade157d  push r10
00007b629ade157f  push r11
00007b629ade1581  sub rsp, 0xF0
00007b629ade1588  vmovaps [rsp], xmm0
00007b629ade158d  vmovaps [rsp+0x10], xmm1
00007b629ade1593  vmovaps [rsp+0x20], xmm2
00007b629ade1599  vmovaps [rsp+0x30], xmm3
00007b629ade159f  vmovaps [rsp+0x40], xmm4
00007b629ade15a5  vmovaps [rsp+0x50], xmm5
00007b629ade15ab  vmovaps [rsp+0x60], xmm6
00007b629ade15b1  vmovaps [rsp+0x70], xmm7
00007b629ade15b7  vmovaps [rsp+0x80], xmm8
00007b629ade15c0  vmovaps [rsp+0x90], xmm9
00007b629ade15c9  vmovaps [rsp+0xA0], xmm10
00007b629ade15d2  vmovaps [rsp+0xB0], xmm11
00007b629ade15db  vmovaps [rsp+0xC0], xmm12
00007b629ade15e4  vmovaps [rsp+0xD0], xmm13
00007b629ade15ed  vmovaps [rsp+0xE0], xmm14
00007b629ade15f6  sub rsp, 0x30
00007b629ade15fa  movaps [rsp], xmm15
00007b629ade15ff  movaps [rsp+0x10], xmm11
00007b629ade1605  movaps [rsp+0x20], xmm12
00007b629ade160b  lea rdi, [rsp]
00007b629ade160f  mov esi, 0x00
00007b629ade1614  mov rax, 0x583FED93F530
00007b629ade161e  call rax
00007b629ade1620  movaps xmm15, [rsp]
00007b629ade1625  add rsp, 0x30
00007b629ade1629  vmovaps xmm0, [rsp]
00007b629ade162e  vmovaps xmm1, [rsp+0x10]
00007b629ade1634  vmovaps xmm2, [rsp+0x20]
00007b629ade163a  vmovaps xmm3, [rsp+0x30]
00007b629ade1640  vmovaps xmm4, [rsp+0x40]
00007b629ade1646  vmovaps xmm5, [rsp+0x50]
00007b629ade164c  vmovaps xmm6, [rsp+0x60]
00007b629ade1652  vmovaps xmm7, [rsp+0x70]
00007b629ade1658  vmovaps xmm8, [rsp+0x80]
00007b629ade1661  vmovaps xmm9, [rsp+0x90]
00007b629ade166a  vmovaps xmm10, [rsp+0xA0]
00007b629ade1673  vmovaps xmm11, [rsp+0xB0]
00007b629ade167c  vmovaps xmm12, [rsp+0xC0]
00007b629ade1685  vmovaps xmm13, [rsp+0xD0]
00007b629ade168e  vmovaps xmm14, [rsp+0xE0]
00007b629ade1697  add rsp, 0xF0
00007b629ade169e  pop r11
00007b629ade16a0  pop r10
00007b629ade16a2  pop r9
00007b629ade16a4  pop r8
00007b629ade16a6  pop rsi
00007b629ade16a7  pop rdi
00007b629ade16a8  pop rdx
00007b629ade16a9  pop rcx
00007b629ade16aa  pop rax
00007b629ade16ab  add rsp, 0x08
00007b629ade16af  jmp 0x00007B629ADDC7FD
00007b629ade16b4  sub rsp, 0x08
00007b629ade16b8  push rax
00007b629ade16b9  push rcx
00007b629ade16ba  push rdx
00007b629ade16bb  push rdi
00007b629ade16bc  push rsi
00007b629ade16bd  push r8
00007b629ade16bf  push r9
00007b629ade16c1  push r10
00007b629ade16c3  push r11
00007b629ade16c5  sub rsp, 0xF0
00007b629ade16cc  vmovaps [rsp], xmm0
00007b629ade16d1  vmovaps [rsp+0x10], xmm1
00007b629ade16d7  vmovaps [rsp+0x20], xmm2
00007b629ade16dd  vmovaps [rsp+0x30], xmm3
00007b629ade16e3  vmovaps [rsp+0x40], xmm4
00007b629ade16e9  vmovaps [rsp+0x50], xmm5
00007b629ade16ef  vmovaps [rsp+0x60], xmm6
00007b629ade16f5  vmovaps [rsp+0x70], xmm7
00007b629ade16fb  vmovaps [rsp+0x80], xmm8
00007b629ade1704  vmovaps [rsp+0x90], xmm9
00007b629ade170d  vmovaps [rsp+0xA0], xmm10
00007b629ade1716  vmovaps [rsp+0xB0], xmm11
00007b629ade171f  vmovaps [rsp+0xC0], xmm12
00007b629ade1728  vmovaps [rsp+0xD0], xmm14
00007b629ade1731  vmovaps [rsp+0xE0], xmm15
00007b629ade173a  sub rsp, 0x30
00007b629ade173e  movaps [rsp], xmm13
00007b629ade1743  movaps [rsp+0x10], xmm10
00007b629ade1749  movaps [rsp+0x20], xmm14
00007b629ade174f  lea rdi, [rsp]
00007b629ade1753  mov esi, 0x00
00007b629ade1758  mov rax, 0x583FED93F530
00007b629ade1762  call rax
00007b629ade1764  movaps xmm13, [rsp]
00007b629ade1769  add rsp, 0x30
00007b629ade176d  vmovaps xmm0, [rsp]
00007b629ade1772  vmovaps xmm1, [rsp+0x10]
00007b629ade1778  vmovaps xmm2, [rsp+0x20]
00007b629ade177e  vmovaps xmm3, [rsp+0x30]
00007b629ade1784  vmovaps xmm4, [rsp+0x40]
00007b629ade178a  vmovaps xmm5, [rsp+0x50]
00007b629ade1790  vmovaps xmm6, [rsp+0x60]
00007b629ade1796  vmovaps xmm7, [rsp+0x70]
00007b629ade179c  vmovaps xmm8, [rsp+0x80]
00007b629ade17a5  vmovaps xmm9, [rsp+0x90]
00007b629ade17ae  vmovaps xmm10, [rsp+0xA0]
00007b629ade17b7  vmovaps xmm11, [rsp+0xB0]
00007b629ade17c0  vmovaps xmm12, [rsp+0xC0]
00007b629ade17c9  vmovaps xmm14, [rsp+0xD0]
00007b629ade17d2  vmovaps xmm15, [rsp+0xE0]
00007b629ade17db  add rsp, 0xF0
00007b629ade17e2  pop r11
00007b629ade17e4  pop r10
00007b629ade17e6  pop r9
00007b629ade17e8  pop r8
00007b629ade17ea  pop rsi
00007b629ade17eb  pop rdi
00007b629ade17ec  pop rdx
00007b629ade17ed  pop rcx
00007b629ade17ee  pop rax
00007b629ade17ef  add rsp, 0x08
00007b629ade17f3  jmp 0x00007B629ADDC820
00007b629ade17f8  sub rsp, 0x08
00007b629ade17fc  push rax
00007b629ade17fd  push rcx
00007b629ade17fe  push rdx
00007b629ade17ff  push rdi
00007b629ade1800  push rsi
00007b629ade1801  push r8
00007b629ade1803  push r9
00007b629ade1805  push r10
00007b629ade1807  push r11
00007b629ade1809  sub rsp, 0xF0
00007b629ade1810  vmovaps [rsp], xmm0
00007b629ade1815  vmovaps [rsp+0x10], xmm1
00007b629ade181b  vmovaps [rsp+0x20], xmm2
00007b629ade1821  vmovaps [rsp+0x30], xmm3
00007b629ade1827  vmovaps [rsp+0x40], xmm4
00007b629ade182d  vmovaps [rsp+0x50], xmm5
00007b629ade1833  vmovaps [rsp+0x60], xmm6
00007b629ade1839  vmovaps [rsp+0x70], xmm7
00007b629ade183f  vmovaps [rsp+0x80], xmm8
00007b629ade1848  vmovaps [rsp+0x90], xmm9
00007b629ade1851  vmovaps [rsp+0xA0], xmm10
00007b629ade185a  vmovaps [rsp+0xB0], xmm11
00007b629ade1863  vmovaps [rsp+0xC0], xmm12
00007b629ade186c  vmovaps [rsp+0xD0], xmm13
00007b629ade1875  vmovaps [rsp+0xE0], xmm15
00007b629ade187e  sub rsp, 0x30
00007b629ade1882  movaps [rsp], xmm14
00007b629ade1887  movaps [rsp+0x10], xmm1
00007b629ade188c  movaps [rsp+0x20], xmm7
00007b629ade1891  lea rdi, [rsp]
00007b629ade1895  mov esi, 0x00
00007b629ade189a  mov rax, 0x583FED93F530
00007b629ade18a4  call rax
00007b629ade18a6  movaps xmm14, [rsp]
00007b629ade18ab  add rsp, 0x30
00007b629ade18af  vmovaps xmm0, [rsp]
00007b629ade18b4  vmovaps xmm1, [rsp+0x10]
00007b629ade18ba  vmovaps xmm2, [rsp+0x20]
00007b629ade18c0  vmovaps xmm3, [rsp+0x30]
00007b629ade18c6  vmovaps xmm4, [rsp+0x40]
00007b629ade18cc  vmovaps xmm5, [rsp+0x50]
00007b629ade18d2  vmovaps xmm6, [rsp+0x60]
00007b629ade18d8  vmovaps xmm7, [rsp+0x70]
00007b629ade18de  vmovaps xmm8, [rsp+0x80]
00007b629ade18e7  vmovaps xmm9, [rsp+0x90]
00007b629ade18f0  vmovaps xmm10, [rsp+0xA0]
00007b629ade18f9  vmovaps xmm11, [rsp+0xB0]
00007b629ade1902  vmovaps xmm12, [rsp+0xC0]
00007b629ade190b  vmovaps xmm13, [rsp+0xD0]
00007b629ade1914  vmovaps xmm15, [rsp+0xE0]
00007b629ade191d  add rsp, 0xF0
00007b629ade1924  pop r11
00007b629ade1926  pop r10
00007b629ade1928  pop r9
00007b629ade192a  pop r8
00007b629ade192c  pop rsi
00007b629ade192d  pop rdi
00007b629ade192e  pop rdx
00007b629ade192f  pop rcx
00007b629ade1930  pop rax
00007b629ade1931  add rsp, 0x08
00007b629ade1935  jmp 0x00007B629ADDC843
00007b629ade193a  sub rsp, 0x08
00007b629ade193e  push rax
00007b629ade193f  push rcx
00007b629ade1940  push rdx
00007b629ade1941  push rdi
00007b629ade1942  push rsi
00007b629ade1943  push r8
00007b629ade1945  push r9
00007b629ade1947  push r10
00007b629ade1949  push r11
00007b629ade194b  sub rsp, 0xF0
00007b629ade1952  vmovaps [rsp], xmm0
00007b629ade1957  vmovaps [rsp+0x10], xmm2
00007b629ade195d  vmovaps [rsp+0x20], xmm3
00007b629ade1963  vmovaps [rsp+0x30], xmm4
00007b629ade1969  vmovaps [rsp+0x40], xmm5
00007b629ade196f  vmovaps [rsp+0x50], xmm6
00007b629ade1975  vmovaps [rsp+0x60], xmm7
00007b629ade197b  vmovaps [rsp+0x70], xmm8
00007b629ade1981  vmovaps [rsp+0x80], xmm9
00007b629ade198a  vmovaps [rsp+0x90], xmm10
00007b629ade1993  vmovaps [rsp+0xA0], xmm11
00007b629ade199c  vmovaps [rsp+0xB0], xmm12
00007b629ade19a5  vmovaps [rsp+0xC0], xmm13
00007b629ade19ae  vmovaps [rsp+0xD0], xmm14
00007b629ade19b7  vmovaps [rsp+0xE0], xmm15
00007b629ade19c0  sub rsp, 0x30
00007b629ade19c4  movaps [rsp], xmm1
00007b629ade19c8  movaps [rsp+0x10], xmm8
00007b629ade19ce  movaps [rsp+0x20], xmm9
00007b629ade19d4  lea rdi, [rsp]
00007b629ade19d8  mov esi, 0x00
00007b629ade19dd  mov rax, 0x583FED93F530
00007b629ade19e7  call rax
00007b629ade19e9  movaps xmm1, [rsp]
00007b629ade19ed  add rsp, 0x30
00007b629ade19f1  vmovaps xmm0, [rsp]
00007b629ade19f6  vmovaps xmm2, [rsp+0x10]
00007b629ade19fc  vmovaps xmm3, [rsp+0x20]
00007b629ade1a02  vmovaps xmm4, [rsp+0x30]
00007b629ade1a08  vmovaps xmm5, [rsp+0x40]
00007b629ade1a0e  vmovaps xmm6, [rsp+0x50]
00007b629ade1a14  vmovaps xmm7, [rsp+0x60]
00007b629ade1a1a  vmovaps xmm8, [rsp+0x70]
00007b629ade1a20  vmovaps xmm9, [rsp+0x80]
00007b629ade1a29  vmovaps xmm10, [rsp+0x90]
00007b629ade1a32  vmovaps xmm11, [rsp+0xA0]
00007b629ade1a3b  vmovaps xmm12, [rsp+0xB0]
00007b629ade1a44  vmovaps xmm13, [rsp+0xC0]
00007b629ade1a4d  vmovaps xmm14, [rsp+0xD0]
00007b629ade1a56  vmovaps xmm15, [rsp+0xE0]
00007b629ade1a5f  add rsp, 0xF0
00007b629ade1a66  pop r11
00007b629ade1a68  pop r10
00007b629ade1a6a  pop r9
00007b629ade1a6c  pop r8
00007b629ade1a6e  pop rsi
00007b629ade1a6f  pop rdi
00007b629ade1a70  pop rdx
00007b629ade1a71  pop rcx
00007b629ade1a72  pop rax
00007b629ade1a73  add rsp, 0x08
00007b629ade1a77  jmp 0x00007B629ADDC865
00007b629ade1a7c  call 0x00007B629ACE5940
00007b629ade1a81  jmp 0x00007B629ADDC873
00007b629ade1a86  call 0x00007B629AC0C380
00007b629ade1a8b  jmp 0x00007B629ADDC87D
00007b629ade1a90  call 0x00007B629AC0D600
00007b629ade1a95  jmp 0x00007B629ADDC887
00007b629ade1a9a  call 0x00007B629ABFF540
00007b629ade1a9f  jmp 0x00007B629ADDC891
00007b629ade1aa4  int3
00007b629ade1aa5  nop [rax+rax*1], ax
00007b629ade1aae  nop
00007b629ade1ab0  mov rax, [r15+0xF8]
00007b629ade1ab7  lea r14, [rax+0x140]
00007b629ade1abe  mov r12, [r13+r14*1]
00007b629ade1ac3  mov [r15+0xE8], r12
00007b629ade1aca  lea r14, [rax+0x130]
00007b629ade1ad1  mov r12, [r13+r14*1]
00007b629ade1ad6  lea r14, [rax+0x138]
00007b629ade1add  mov r11, [r13+r14*1]
00007b629ade1ae2  movq xmm1, r12
00007b629ade1ae7  movq xmm15, r11
00007b629ade1aec  movq xmm1, xmm1
00007b629ade1af0  movq xmm1, xmm1
00007b629ade1af4  movaps [r15+0x1A0], xmm1
00007b629ade1afc  movq xmm15, xmm15
00007b629ade1b01  movq xmm15, xmm15
00007b629ade1b06  movaps [r15+0x190], xmm15
00007b629ade1b0e  lea r14, [rax+0x120]
00007b629ade1b15  mov r12, [r13+r14*1]
00007b629ade1b1a  lea r14, [rax+0x128]
00007b629ade1b21  mov r11, [r13+r14*1]
00007b629ade1b26  movq xmm1, r12
00007b629ade1b2b  movq xmm15, r11
00007b629ade1b30  movq xmm1, xmm1
00007b629ade1b34  movq xmm1, xmm1
00007b629ade1b38  movaps [r15+0x1C0], xmm1
00007b629ade1b40  movq xmm15, xmm15
00007b629ade1b45  movq xmm15, xmm15
00007b629ade1b4a  movaps [r15+0x1B0], xmm15
00007b629ade1b52  lea r14, [rax+0x110]
00007b629ade1b59  mov r12, [r13+r14*1]
00007b629ade1b5e  lea r14, [rax+0x118]
00007b629ade1b65  mov r11, [r13+r14*1]
00007b629ade1b6a  movq xmm1, r12
00007b629ade1b6f  movq xmm15, r11
00007b629ade1b74  movq xmm1, xmm1
00007b629ade1b78  movq xmm1, xmm1
00007b629ade1b7c  movaps [r15+0x1E0], xmm1
00007b629ade1b84  movq xmm15, xmm15
00007b629ade1b89  movq xmm15, xmm15
00007b629ade1b8e  movaps [r15+0x1D0], xmm15
00007b629ade1b96  lea r14, [rax+0x100]
00007b629ade1b9d  mov r12, [r13+r14*1]
00007b629ade1ba2  lea r14, [rax+0x108]
00007b629ade1ba9  mov r11, [r13+r14*1]
00007b629ade1bae  movq xmm1, r12
00007b629ade1bb3  movq xmm15, r11
00007b629ade1bb8  movq xmm1, xmm1
00007b629ade1bbc  movq xmm1, xmm1
00007b629ade1bc0  movaps [r15+0x200], xmm1
00007b629ade1bc8  movq xmm15, xmm15
00007b629ade1bcd  movq xmm15, xmm15
00007b629ade1bd2  movaps [r15+0x1F0], xmm15
00007b629ade1bda  mov qword ptr [r15+0x40], 0x430000
00007b629ade1be2  mov r14d, 0x430510
00007b629ade1be8  mov r12, [r13+r14*1]
00007b629ade1bed  movq xmm1, r12
00007b629ade1bf2  lea r14, [rax+0x150]
00007b629ade1bf9  mov [r15+0xF8], r14
00007b629ade1c00  mov rax, [r15+0x50]
00007b629ade1c04  movups xmm15, [r13+rax*1]
00007b629ade1c0a  movaps [r15+0x120], xmm15
00007b629ade1c12  mov qword ptr [r15+0x48], 0x10
00007b629ade1c1a  xor eax, eax
00007b629ade1c1c  mov r14d, 0x10
00007b629ade1c22  mov r12d, 0x200
00007b629ade1c28  cmp r14, r12
00007b629ade1c2b  cmc
00007b629ade1c2c  lahf
00007b629ade1c2d  seto al
00007b629ade1c30  mov [r15+0x108], eax
00007b629ade1c37  pextrq rax, xmm15, 0x01
00007b629ade1c3e  movq xmm14, rax
00007b629ade1c43  movaps [r15+0x130], xmm14
00007b629ade1c4b  movq rax, xmm1
00007b629ade1c50  movq r14, xmm15
00007b629ade1c55  vmovq xmm1, rax
00007b629ade1c5a  vmovq xmm15, r14
00007b629ade1c5f  movaps xmm13, xmm1
00007b629ade1c63  addsd xmm13, xmm15
00007b629ade1c68  ucomisd xmm13, xmm13
00007b629ade1c6d  jp 0x00007B629ADE1D86
00007b629ade1c73  movq xmm13, xmm13
00007b629ade1c78  movq rax, xmm13
00007b629ade1c7d  movq r14, xmm14
00007b629ade1c82  vmovq xmm1, rax
00007b629ade1c87  vmovq xmm15, r14
00007b629ade1c8c  movaps xmm14, xmm1
00007b629ade1c90  addsd xmm14, xmm15
00007b629ade1c95  ucomisd xmm14, xmm14
00007b629ade1c9a  jp 0x00007B629ADE1DCE
00007b629ade1ca0  movq xmm14, xmm14
00007b629ade1ca5  movaps [r15+0x110], xmm14
00007b629ade1cad  mov eax, [r15+0x108]
00007b629ade1cb4  sahf
00007b629ade1cb5  jnz 0x00007B629ADE1CE7
00007b629ade1cb7  cmp dword ptr [r15+0x318], 0x00
00007b629ade1cbf  jz 0x00007B629ADE1FE0
00007b629ade1cc5  nop [rax+rax*1], ax
00007b629ade1cce  nop [rax+rax*1], eax
00007b629ade1cd6  mov eax, 0x410490
00007b629ade1cdb  mov [r15+0x100], rax
00007b629ade1ce2  jmp 0x00007B629ABFE110
00007b629ade1ce7  cmp dword ptr [r15+0x318], 0x00
00007b629ade1cef  jz 0x00007B629ADE1E20
00007b629ade1cf5  nop [rax+rax*1], ax
00007b629ade1cfe  nop [rax+rax*1], eax
00007b629ade1d06  mov eax, 0x410474
00007b629ade1d0b  mov [r15+0x100], rax
00007b629ade1d12  jmp 0x00007B629ABFE110
00007b629ade1d17  int3
00007b629ade1d18  call 0x00007B629ACE27E0
00007b629ade1d1d  jmp 0x00007B629ADE1AC3
00007b629ade1d22  call 0x00007B629ACE27E0
00007b629ade1d27  jmp 0x00007B629ADE1AD6
00007b629ade1d2c  call 0x00007B629ACE1570
00007b629ade1d31  jmp 0x00007B629ADE1AE2
00007b629ade1d36  call 0x00007B629ACE27E0
00007b629ade1d3b  jmp 0x00007B629ADE1B1A
00007b629ade1d40  call 0x00007B629ACE1570
00007b629ade1d45  jmp 0x00007B629ADE1B26
00007b629ade1d4a  call 0x00007B629ACE27E0
00007b629ade1d4f  jmp 0x00007B629ADE1B5E
00007b629ade1d54  call 0x00007B629ACE1570
00007b629ade1d59  jmp 0x00007B629ADE1B6A
00007b629ade1d5e  call 0x00007B629ACE27E0
00007b629ade1d63  jmp 0x00007B629ADE1BA2
00007b629ade1d68  call 0x00007B629ACE1570
00007b629ade1d6d  jmp 0x00007B629ADE1BAE
00007b629ade1d72  call 0x00007B629ACE27E0
00007b629ade1d77  jmp 0x00007B629ADE1BED
00007b629ade1d7c  call 0x00007B629AC0E760
00007b629ade1d81  jmp 0x00007B629ADE1C0A
00007b629ade1d86  ucomisd xmm1, xmm15
00007b629ade1d8b  jp 0x00007B629ADE1D9A
00007b629ade1d8d  movaps xmm13, [0x00007B629A9FE060]
00007b629ade1d95  jmp 0x00007B629ADE1C73
00007b629ade1d9a  vxorps xmm0, xmm1, xmm15
00007b629ade1d9f  pextrw eax, xmm0, 0x03
00007b629ade1da4  and eax, 0x7FF8
00007b629ade1da9  cmp eax, 0x08
00007b629ade1dac  jnz 0x00007B629ADE1C73
00007b629ade1db2  movq rax, xmm15
00007b629ade1db7  shl rax, 0x0D
00007b629ade1dbb  jbe 0x00007B629ADE1C73
00007b629ade1dc1  vorps xmm13, xmm15, [0x00007B629A9FE070]
00007b629ade1dc9  jmp 0x00007B629ADE1C73
00007b629ade1dce  ucomisd xmm1, xmm15
00007b629ade1dd3  jp 0x00007B629ADE1DE2
00007b629ade1dd5  movaps xmm14, [0x00007B629A9FE060]
00007b629ade1ddd  jmp 0x00007B629ADE1CA0
00007b629ade1de2  vxorps xmm0, xmm1, xmm15
00007b629ade1de7  pextrw eax, xmm0, 0x03
00007b629ade1dec  and eax, 0x7FF8
00007b629ade1df1  cmp eax, 0x08
00007b629ade1df4  jnz 0x00007B629ADE1CA0
00007b629ade1dfa  movq rax, xmm15
00007b629ade1dff  shl rax, 0x0D
00007b629ade1e03  jbe 0x00007B629ADE1CA0
00007b629ade1e09  vorps xmm14, xmm15, [0x00007B629A9FE070]
00007b629ade1e11  jmp 0x00007B629ADE1CA0
00007b629ade1e16  int3
00007b629ade1e17  nop [rax+rax*1], ax
00007b629ade1e20  mov rax, [r15+0x48]
00007b629ade1e24  mov r14, [r15+0x50]
00007b629ade1e28  lea r12, [r14+rax*1]
00007b629ade1e2c  movups xmm1, [r13+r12*1]
00007b629ade1e32  movaps [r15+0x120], xmm1
00007b629ade1e3a  lea r14, [rax+0x10]
00007b629ade1e3e  mov [r15+0x48], r14
00007b629ade1e42  xor eax, eax
00007b629ade1e44  mov r12d, 0x200
00007b629ade1e4a  cmp r14, r12
00007b629ade1e4d  cmc
00007b629ade1e4e  lahf
00007b629ade1e4f  seto al
00007b629ade1e52  mov [r15+0x108], eax
00007b629ade1e59  pextrq rax, xmm1, 0x01
00007b629ade1e60  movq xmm15, rax
00007b629ade1e65  movaps [r15+0x130], xmm15
00007b629ade1e6d  movaps xmm14, [r15+0x110]
00007b629ade1e75  movq rax, xmm14
00007b629ade1e7a  movq r14, xmm1
00007b629ade1e7f  vmovq xmm1, rax
00007b629ade1e84  vmovq xmm14, r14
00007b629ade1e89  movaps xmm13, xmm1
00007b629ade1e8d  addsd xmm13, xmm14
00007b629ade1e92  ucomisd xmm13, xmm13
00007b629ade1e97  jp 0x00007B629ADE1F4C
00007b629ade1e9d  movq xmm13, xmm13
00007b629ade1ea2  movq rax, xmm13
00007b629ade1ea7  movq r14, xmm15
00007b629ade1eac  vmovq xmm1, rax
00007b629ade1eb1  vmovq xmm15, r14
00007b629ade1eb6  movaps xmm14, xmm1
00007b629ade1eba  addsd xmm14, xmm15
00007b629ade1ebf  ucomisd xmm14, xmm14
00007b629ade1ec4  jp 0x00007B629ADE1F94
00007b629ade1eca  movq xmm14, xmm14
00007b629ade1ecf  movaps [r15+0x110], xmm14
00007b629ade1ed7  mov eax, [r15+0x108]
00007b629ade1ede  sahf
00007b629ade1edf  jnz 0x00007B629ADE1F11
00007b629ade1ee1  cmp dword ptr [r15+0x318], 0x00
00007b629ade1ee9  jz 0x00007B629ADE1FE0
00007b629ade1eef  nop [rax+rax*1], ax
00007b629ade1ef8  nop [rax+rax*1], eax
00007b629ade1f00  mov eax, 0x410490
00007b629ade1f05  mov [r15+0x100], rax
00007b629ade1f0c  jmp 0x00007B629ABFE110
00007b629ade1f11  cmp dword ptr [r15+0x318], 0x00
00007b629ade1f19  jz 0x00007B629ADE1E20
00007b629ade1f1f  nop [rax+rax*1], ax
00007b629ade1f28  nop [rax+rax*1], eax
00007b629ade1f30  mov eax, 0x410474
00007b629ade1f35  mov [r15+0x100], rax
00007b629ade1f3c  jmp 0x00007B629ABFE110
00007b629ade1f41  int3
00007b629ade1f42  call 0x00007B629ACB52F0
00007b629ade1f47  jmp 0x00007B629ADE1E32
00007b629ade1f4c  ucomisd xmm1, xmm14
00007b629ade1f51  jp 0x00007B629ADE1F60
00007b629ade1f53  movaps xmm13, [0x00007B629A9FE060]
00007b629ade1f5b  jmp 0x00007B629ADE1E9D
00007b629ade1f60  vxorps xmm0, xmm1, xmm14
00007b629ade1f65  pextrw eax, xmm0, 0x03
00007b629ade1f6a  and eax, 0x7FF8
00007b629ade1f6f  cmp eax, 0x08
00007b629ade1f72  jnz 0x00007B629ADE1E9D
00007b629ade1f78  movq rax, xmm14
00007b629ade1f7d  shl rax, 0x0D
00007b629ade1f81  jbe 0x00007B629ADE1E9D
00007b629ade1f87  vorps xmm13, xmm14, [0x00007B629A9FE070]
00007b629ade1f8f  jmp 0x00007B629ADE1E9D
00007b629ade1f94  ucomisd xmm1, xmm15
00007b629ade1f99  jp 0x00007B629ADE1FA8
00007b629ade1f9b  movaps xmm14, [0x00007B629A9FE060]
00007b629ade1fa3  jmp 0x00007B629ADE1ECA
00007b629ade1fa8  vxorps xmm0, xmm1, xmm15
00007b629ade1fad  pextrw eax, xmm0, 0x03
00007b629ade1fb2  and eax, 0x7FF8
00007b629ade1fb7  cmp eax, 0x08
00007b629ade1fba  jnz 0x00007B629ADE1ECA
00007b629ade1fc0  movq rax, xmm15
00007b629ade1fc5  shl rax, 0x0D
00007b629ade1fc9  jbe 0x00007B629ADE1ECA
00007b629ade1fcf  vorps xmm14, xmm15, [0x00007B629A9FE070]
00007b629ade1fd7  jmp 0x00007B629ADE1ECA
00007b629ade1fdc  int3
00007b629ade1fdd  nop [rax], eax
00007b629ade1fe0  mov rax, [r15+0x40]
00007b629ade1fe4  lea r14, [rax+0x510]
00007b629ade1feb  movaps xmm1, [r15+0x110]
00007b629ade1ff3  movq rax, xmm1
00007b629ade1ff8  mov [r13+r14*1], rax
00007b629ade1ffd  mov rax, [r15+0xF0]
00007b629ade2004  mov [r15+0x100], rax
00007b629ade200b  jmp 0x00007B629ADCE5C0
00007b629ade2010  int3
00007b629ade2011  call 0x00007B629ACD5EB0
00007b629ade2016  jmp 0x00007B629ADE1FFD
00007b629ade201b  int3
00007b629ade201c  nop [rax], eax
00007b629ade2020  mov qword ptr [r15+0x100], 0x04
00007b629ade202b  mov esi, 0x00
00007b629ade2030  mov edx, 0x09
00007b629ade2035  mov rdi, 0x7FFF3E353770
00007b629ade203f  mov rax, 0x583FED7D2970
00007b629ade2049  call rax
00007b629ade204b  cmp dword ptr [r15+0x318], 0x00
00007b629ade2053  jnz 0x00007B629ABFE110
00007b629ade2059  jmp 0x00007B629ABFE0A0
00007b629ade205e  int3
00007b629ade205f  int3
