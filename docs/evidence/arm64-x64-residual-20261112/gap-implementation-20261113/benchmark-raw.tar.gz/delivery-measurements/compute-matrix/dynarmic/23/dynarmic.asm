000072bd77dce69b  nop [rax+rax*1], eax
000072bd77dce6a0  vmovaps xmm1, [0x000072BD779FE010]
000072bd77dce6a8  movq xmm1, xmm1
000072bd77dce6ac  movaps [r15+0x110], xmm1
000072bd77dce6b4  vmovaps xmm1, [0x000072BD779FE020]
000072bd77dce6bc  movq xmm1, xmm1
000072bd77dce6c0  movaps [r15+0x120], xmm1
000072bd77dce6c8  mov eax, 0x4204C0
000072bd77dce6cd  mov r14, [r13+rax*1]
000072bd77dce6d2  movq xmm1, r14
000072bd77dce6d7  movaps [r15+0x130], xmm1
000072bd77dce6df  vmovaps xmm1, [0x000072BD779FE030]
000072bd77dce6e7  vpbroadcastq xmm1, xmm1
000072bd77dce6ec  movaps [r15+0x140], xmm1
000072bd77dce6f4  mov qword ptr [r15+0x40], 0x02
000072bd77dce6fc  vmovaps xmm15, [0x000072BD779FE040]
000072bd77dce704  movq xmm15, xmm15
000072bd77dce709  movaps [r15+0x150], xmm15
000072bd77dce711  mov qword ptr [r15+0x58], 0x420000
000072bd77dce719  vmovaps xmm15, [0x000072BD779FE050]
000072bd77dce721  vpbroadcastq xmm15, xmm15
000072bd77dce726  movaps [r15+0x160], xmm15
000072bd77dce72e  mov rax, [r15+0x40]
000072bd77dce732  vmovq xmm14, rax
000072bd77dce737  vpbroadcastq xmm14, xmm14
000072bd77dce73c  movaps [r15+0x170], xmm14
000072bd77dce744  mov eax, 0x4204D0
000072bd77dce749  movups xmm13, [r13+rax*1]
000072bd77dce74f  mov qword ptr [r15+0x40], 0x430518
000072bd77dce757  mov qword ptr [r15+0x50], 0x430720
000072bd77dce75f  vpmovqd xmm12, xmm13
000072bd77dce765  pxor xmm11, xmm11
000072bd77dce76a  punpcklqdq xmm12, xmm11
000072bd77dce76f  movaps [r15+0x210], xmm12
000072bd77dce777  movq xmm12, qword ptr [r15+0x120]
000072bd77dce780  movq xmm11, qword ptr [r15+0x130]
000072bd77dce789  psubd xmm12, xmm11
000072bd77dce78e  movq xmm12, xmm12
000072bd77dce793  paddq xmm13, xmm14
000072bd77dce798  movaps [r15+0x180], xmm13
000072bd77dce7a0  movq xmm14, qword ptr [r15+0x150]
000072bd77dce7a9  paddd xmm11, xmm14
000072bd77dce7ae  movq xmm11, xmm11
000072bd77dce7b3  movq xmm11, xmm11
000072bd77dce7b8  movaps [r15+0x130], xmm11
000072bd77dce7c0  pmovzxdq xmm12, xmm12
000072bd77dce7c6  psllq xmm12, 0x00
000072bd77dce7cc  movq xmm14, qword ptr [r15+0x210]
000072bd77dce7d5  movq xmm13, qword ptr [r15+0x110]
000072bd77dce7de  paddd xmm14, xmm13
000072bd77dce7e3  movq xmm14, xmm14
000072bd77dce7e8  vcvtuqq2pd xmm12, xmm12
000072bd77dce7ee  pmovzxdq xmm14, xmm14
000072bd77dce7f4  psllq xmm14, 0x00
000072bd77dce7fa  vcvtuqq2pd xmm14, xmm14
000072bd77dce800  movaps xmm13, xmm12
000072bd77dce804  mulpd xmm13, xmm1
000072bd77dce809  vcmppd xmm11, xmm13, xmm13, 0x03
000072bd77dce80f  ptest xmm11, xmm11
000072bd77dce815  jnz 0x000072BD77DCE8FF
000072bd77dce81b  movaps [r15+0x220], xmm13
000072bd77dce823  mov eax, 0x430720
000072bd77dce828  movups [r13+rax*1], xmm13
000072bd77dce82e  movaps xmm1, xmm14
000072bd77dce832  mulpd xmm1, xmm15
000072bd77dce837  vcmppd xmm13, xmm1, xmm1, 0x03
000072bd77dce83c  ptest xmm13, xmm13
000072bd77dce842  jnz 0x000072BD77DCEA4C
000072bd77dce848  movaps [r15+0x210], xmm1
000072bd77dce850  mov eax, 0x430518
000072bd77dce855  movups [r13+rax*1], xmm1
000072bd77dce85b  mov qword ptr [r15+0x48], 0x10
000072bd77dce863  xor eax, eax
000072bd77dce865  mov r14d, 0x10
000072bd77dce86b  mov r12d, 0x200
000072bd77dce871  cmp r14, r12
000072bd77dce874  cmc
000072bd77dce875  lahf
000072bd77dce876  seto al
000072bd77dce879  mov [r15+0x108], eax
000072bd77dce880  mov eax, [r15+0x108]
000072bd77dce887  sahf
000072bd77dce888  jnz 0x000072BD77DCE8BA
000072bd77dce88a  cmp dword ptr [r15+0x318], 0x00
000072bd77dce892  jz 0x000072BD77DCEFF0
000072bd77dce898  nop [rax+rax*1], ax
000072bd77dce8a1  nop [rax+rax*1], eax
000072bd77dce8a9  mov eax, 0x4101EC
000072bd77dce8ae  mov [r15+0x100], rax
000072bd77dce8b5  jmp 0x000072BD77BFE110
000072bd77dce8ba  cmp dword ptr [r15+0x318], 0x00
000072bd77dce8c2  jz 0x000072BD77DCEBA0
000072bd77dce8c8  nop [rax+rax*1], ax
000072bd77dce8d1  nop [rax+rax*1], eax
000072bd77dce8d9  mov eax, 0x4101AC
000072bd77dce8de  mov [r15+0x100], rax
000072bd77dce8e5  jmp 0x000072BD77BFE110
000072bd77dce8ea  int3
000072bd77dce8eb  call 0x000072BD77C0DC20
000072bd77dce8f0  jmp 0x000072BD77DCE6D2
000072bd77dce8f5  call 0x000072BD77C0C260
000072bd77dce8fa  jmp 0x000072BD77DCE74F
000072bd77dce8ff  sub rsp, 0x08
000072bd77dce903  push rax
000072bd77dce904  push rcx
000072bd77dce905  push rdx
000072bd77dce906  push rdi
000072bd77dce907  push rsi
000072bd77dce908  push r8
000072bd77dce90a  push r9
000072bd77dce90c  push r10
000072bd77dce90e  push r11
000072bd77dce910  sub rsp, 0xF0
000072bd77dce917  vmovaps [rsp], xmm0
000072bd77dce91c  vmovaps [rsp+0x10], xmm1
000072bd77dce922  vmovaps [rsp+0x20], xmm2
000072bd77dce928  vmovaps [rsp+0x30], xmm3
000072bd77dce92e  vmovaps [rsp+0x40], xmm4
000072bd77dce934  vmovaps [rsp+0x50], xmm5
000072bd77dce93a  vmovaps [rsp+0x60], xmm6
000072bd77dce940  vmovaps [rsp+0x70], xmm7
000072bd77dce946  vmovaps [rsp+0x80], xmm8
000072bd77dce94f  vmovaps [rsp+0x90], xmm9
000072bd77dce958  vmovaps [rsp+0xA0], xmm10
000072bd77dce961  vmovaps [rsp+0xB0], xmm11
000072bd77dce96a  vmovaps [rsp+0xC0], xmm12
000072bd77dce973  vmovaps [rsp+0xD0], xmm14
000072bd77dce97c  vmovaps [rsp+0xE0], xmm15
000072bd77dce985  sub rsp, 0x30
000072bd77dce989  movaps [rsp], xmm13
000072bd77dce98e  movaps [rsp+0x10], xmm12
000072bd77dce994  movaps [rsp+0x20], xmm1
000072bd77dce999  lea rdi, [rsp]
000072bd77dce99d  mov esi, 0x00
000072bd77dce9a2  mov rax, 0x643206AC3530
000072bd77dce9ac  call rax
000072bd77dce9ae  movaps xmm13, [rsp]
000072bd77dce9b3  add rsp, 0x30
000072bd77dce9b7  vmovaps xmm0, [rsp]
000072bd77dce9bc  vmovaps xmm1, [rsp+0x10]
000072bd77dce9c2  vmovaps xmm2, [rsp+0x20]
000072bd77dce9c8  vmovaps xmm3, [rsp+0x30]
000072bd77dce9ce  vmovaps xmm4, [rsp+0x40]
000072bd77dce9d4  vmovaps xmm5, [rsp+0x50]
000072bd77dce9da  vmovaps xmm6, [rsp+0x60]
000072bd77dce9e0  vmovaps xmm7, [rsp+0x70]
000072bd77dce9e6  vmovaps xmm8, [rsp+0x80]
000072bd77dce9ef  vmovaps xmm9, [rsp+0x90]
000072bd77dce9f8  vmovaps xmm10, [rsp+0xA0]
000072bd77dcea01  vmovaps xmm11, [rsp+0xB0]
000072bd77dcea0a  vmovaps xmm12, [rsp+0xC0]
000072bd77dcea13  vmovaps xmm14, [rsp+0xD0]
000072bd77dcea1c  vmovaps xmm15, [rsp+0xE0]
000072bd77dcea25  add rsp, 0xF0
000072bd77dcea2c  pop r11
000072bd77dcea2e  pop r10
000072bd77dcea30  pop r9
000072bd77dcea32  pop r8
000072bd77dcea34  pop rsi
000072bd77dcea35  pop rdi
000072bd77dcea36  pop rdx
000072bd77dcea37  pop rcx
000072bd77dcea38  pop rax
000072bd77dcea39  add rsp, 0x08
000072bd77dcea3d  jmp 0x000072BD77DCE81B
000072bd77dcea42  call 0x000072BD77C0C380
000072bd77dcea47  jmp 0x000072BD77DCE82E
000072bd77dcea4c  sub rsp, 0x08
000072bd77dcea50  push rax
000072bd77dcea51  push rcx
000072bd77dcea52  push rdx
000072bd77dcea53  push rdi
000072bd77dcea54  push rsi
000072bd77dcea55  push r8
000072bd77dcea57  push r9
000072bd77dcea59  push r10
000072bd77dcea5b  push r11
000072bd77dcea5d  sub rsp, 0xF0
000072bd77dcea64  vmovaps [rsp], xmm0
000072bd77dcea69  vmovaps [rsp+0x10], xmm2
000072bd77dcea6f  vmovaps [rsp+0x20], xmm3
000072bd77dcea75  vmovaps [rsp+0x30], xmm4
000072bd77dcea7b  vmovaps [rsp+0x40], xmm5
000072bd77dcea81  vmovaps [rsp+0x50], xmm6
000072bd77dcea87  vmovaps [rsp+0x60], xmm7
000072bd77dcea8d  vmovaps [rsp+0x70], xmm8
000072bd77dcea93  vmovaps [rsp+0x80], xmm9
000072bd77dcea9c  vmovaps [rsp+0x90], xmm10
000072bd77dceaa5  vmovaps [rsp+0xA0], xmm11
000072bd77dceaae  vmovaps [rsp+0xB0], xmm12
000072bd77dceab7  vmovaps [rsp+0xC0], xmm13
000072bd77dceac0  vmovaps [rsp+0xD0], xmm14
000072bd77dceac9  vmovaps [rsp+0xE0], xmm15
000072bd77dcead2  sub rsp, 0x30
000072bd77dcead6  movaps [rsp], xmm1
000072bd77dceada  movaps [rsp+0x10], xmm14
000072bd77dceae0  movaps [rsp+0x20], xmm15
000072bd77dceae6  lea rdi, [rsp]
000072bd77dceaea  mov esi, 0x00
000072bd77dceaef  mov rax, 0x643206AC3530
000072bd77dceaf9  call rax
000072bd77dceafb  movaps xmm1, [rsp]
000072bd77dceaff  add rsp, 0x30
000072bd77dceb03  vmovaps xmm0, [rsp]
000072bd77dceb08  vmovaps xmm2, [rsp+0x10]
000072bd77dceb0e  vmovaps xmm3, [rsp+0x20]
000072bd77dceb14  vmovaps xmm4, [rsp+0x30]
000072bd77dceb1a  vmovaps xmm5, [rsp+0x40]
000072bd77dceb20  vmovaps xmm6, [rsp+0x50]
000072bd77dceb26  vmovaps xmm7, [rsp+0x60]
000072bd77dceb2c  vmovaps xmm8, [rsp+0x70]
000072bd77dceb32  vmovaps xmm9, [rsp+0x80]
000072bd77dceb3b  vmovaps xmm10, [rsp+0x90]
000072bd77dceb44  vmovaps xmm11, [rsp+0xA0]
000072bd77dceb4d  vmovaps xmm12, [rsp+0xB0]
000072bd77dceb56  vmovaps xmm13, [rsp+0xC0]
000072bd77dceb5f  vmovaps xmm14, [rsp+0xD0]
000072bd77dceb68  vmovaps xmm15, [rsp+0xE0]
000072bd77dceb71  add rsp, 0xF0
000072bd77dceb78  pop r11
000072bd77dceb7a  pop r10
000072bd77dceb7c  pop r9
000072bd77dceb7e  pop r8
000072bd77dceb80  pop rsi
000072bd77dceb81  pop rdi
000072bd77dceb82  pop rdx
000072bd77dceb83  pop rcx
000072bd77dceb84  pop rax
000072bd77dceb85  add rsp, 0x08
000072bd77dceb89  jmp 0x000072BD77DCE848
000072bd77dceb8e  call 0x000072BD77BFF540
000072bd77dceb93  jmp 0x000072BD77DCE85B
000072bd77dceb98  int3
000072bd77dceb99  nop [rax], eax
000072bd77dceba0  movaps xmm1, [r15+0x180]
000072bd77dceba8  vpmovqd xmm15, xmm1
000072bd77dcebae  pxor xmm14, xmm14
000072bd77dcebb3  punpcklqdq xmm15, xmm14
000072bd77dcebb8  movaps [r15+0x210], xmm15
000072bd77dcebc0  movq xmm15, qword ptr [r15+0x120]
000072bd77dcebc9  movq xmm14, qword ptr [r15+0x130]
000072bd77dcebd2  psubd xmm15, xmm14
000072bd77dcebd7  movq xmm15, xmm15
000072bd77dcebdc  movaps xmm13, [r15+0x170]
000072bd77dcebe4  paddq xmm1, xmm13
000072bd77dcebe9  movaps [r15+0x180], xmm1
000072bd77dcebf1  movq xmm1, qword ptr [r15+0x150]
000072bd77dcebfa  paddd xmm14, xmm1
000072bd77dcebff  movq xmm14, xmm14
000072bd77dcec04  movq xmm14, xmm14
000072bd77dcec09  movaps [r15+0x130], xmm14
000072bd77dcec11  pmovzxdq xmm15, xmm15
000072bd77dcec17  psllq xmm15, 0x00
000072bd77dcec1d  movq xmm1, qword ptr [r15+0x210]
000072bd77dcec26  movq xmm14, qword ptr [r15+0x110]
000072bd77dcec2f  paddd xmm1, xmm14
000072bd77dcec34  movq xmm1, xmm1
000072bd77dcec38  vcvtuqq2pd xmm15, xmm15
000072bd77dcec3e  pmovzxdq xmm1, xmm1
000072bd77dcec43  psllq xmm1, 0x00
000072bd77dcec48  vcvtuqq2pd xmm1, xmm1
000072bd77dcec4e  movaps xmm14, [r15+0x140]
000072bd77dcec56  movaps xmm13, xmm15
000072bd77dcec5a  mulpd xmm13, xmm14
000072bd77dcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000072bd77dcec65  ptest xmm12, xmm12
000072bd77dcec6b  jnz 0x000072BD77DCED4E
000072bd77dcec71  movaps [r15+0x220], xmm13
000072bd77dcec79  mov rax, [r15+0x48]
000072bd77dcec7d  mov r14, [r15+0x50]
000072bd77dcec81  lea r12, [r14+rax*1]
000072bd77dcec85  movups [r13+r12*1], xmm13
000072bd77dcec8b  movaps xmm15, [r15+0x160]
000072bd77dcec93  movaps xmm14, xmm1
000072bd77dcec97  mulpd xmm14, xmm15
000072bd77dcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000072bd77dceca2  ptest xmm13, xmm13
000072bd77dceca8  jnz 0x000072BD77DCEE9C
000072bd77dcecae  movaps [r15+0x210], xmm14
000072bd77dcecb6  mov r14, [r15+0x40]
000072bd77dcecba  lea r12, [r14+rax*1]
000072bd77dcecbe  movups [r13+r12*1], xmm14
000072bd77dcecc4  lea r14, [rax+0x10]
000072bd77dcecc8  mov [r15+0x48], r14
000072bd77dceccc  xor eax, eax
000072bd77dcecce  mov r12d, 0x200
000072bd77dcecd4  cmp r14, r12
000072bd77dcecd7  cmc
000072bd77dcecd8  lahf
000072bd77dcecd9  seto al
000072bd77dcecdc  mov [r15+0x108], eax
000072bd77dcece3  mov eax, [r15+0x108]
000072bd77dcecea  sahf
000072bd77dceceb  jnz 0x000072BD77DCED1D
000072bd77dceced  cmp dword ptr [r15+0x318], 0x00
000072bd77dcecf5  jz 0x000072BD77DCEFF0
000072bd77dcecfb  nop [rax+rax*1], ax
000072bd77dced04  nop [rax+rax*1], eax
000072bd77dced0c  mov eax, 0x4101EC
000072bd77dced11  mov [r15+0x100], rax
000072bd77dced18  jmp 0x000072BD77BFE110
000072bd77dced1d  cmp dword ptr [r15+0x318], 0x00
000072bd77dced25  jz 0x000072BD77DCEBA0
000072bd77dced2b  nop [rax+rax*1], ax
000072bd77dced34  nop [rax+rax*1], eax
000072bd77dced3c  mov eax, 0x4101AC
000072bd77dced41  mov [r15+0x100], rax
000072bd77dced48  jmp 0x000072BD77BFE110
000072bd77dced4d  int3
000072bd77dced4e  sub rsp, 0x08
000072bd77dced52  push rax
000072bd77dced53  push rcx
000072bd77dced54  push rdx
000072bd77dced55  push rdi
000072bd77dced56  push rsi
000072bd77dced57  push r8
000072bd77dced59  push r9
000072bd77dced5b  push r10
000072bd77dced5d  push r11
000072bd77dced5f  sub rsp, 0xF0
000072bd77dced66  vmovaps [rsp], xmm0
000072bd77dced6b  vmovaps [rsp+0x10], xmm1
000072bd77dced71  vmovaps [rsp+0x20], xmm2
000072bd77dced77  vmovaps [rsp+0x30], xmm3
000072bd77dced7d  vmovaps [rsp+0x40], xmm4
000072bd77dced83  vmovaps [rsp+0x50], xmm5
000072bd77dced89  vmovaps [rsp+0x60], xmm6
000072bd77dced8f  vmovaps [rsp+0x70], xmm7
000072bd77dced95  vmovaps [rsp+0x80], xmm8
000072bd77dced9e  vmovaps [rsp+0x90], xmm9
000072bd77dceda7  vmovaps [rsp+0xA0], xmm10
000072bd77dcedb0  vmovaps [rsp+0xB0], xmm11
000072bd77dcedb9  vmovaps [rsp+0xC0], xmm12
000072bd77dcedc2  vmovaps [rsp+0xD0], xmm14
000072bd77dcedcb  vmovaps [rsp+0xE0], xmm15
000072bd77dcedd4  sub rsp, 0x30
000072bd77dcedd8  movaps [rsp], xmm13
000072bd77dceddd  movaps [rsp+0x10], xmm15
000072bd77dcede3  movaps [rsp+0x20], xmm14
000072bd77dcede9  lea rdi, [rsp]
000072bd77dceded  mov esi, 0x00
000072bd77dcedf2  mov rax, 0x643206AC3530
000072bd77dcedfc  call rax
000072bd77dcedfe  movaps xmm13, [rsp]
000072bd77dcee03  add rsp, 0x30
000072bd77dcee07  vmovaps xmm0, [rsp]
000072bd77dcee0c  vmovaps xmm1, [rsp+0x10]
000072bd77dcee12  vmovaps xmm2, [rsp+0x20]
000072bd77dcee18  vmovaps xmm3, [rsp+0x30]
000072bd77dcee1e  vmovaps xmm4, [rsp+0x40]
000072bd77dcee24  vmovaps xmm5, [rsp+0x50]
000072bd77dcee2a  vmovaps xmm6, [rsp+0x60]
000072bd77dcee30  vmovaps xmm7, [rsp+0x70]
000072bd77dcee36  vmovaps xmm8, [rsp+0x80]
000072bd77dcee3f  vmovaps xmm9, [rsp+0x90]
000072bd77dcee48  vmovaps xmm10, [rsp+0xA0]
000072bd77dcee51  vmovaps xmm11, [rsp+0xB0]
000072bd77dcee5a  vmovaps xmm12, [rsp+0xC0]
000072bd77dcee63  vmovaps xmm14, [rsp+0xD0]
000072bd77dcee6c  vmovaps xmm15, [rsp+0xE0]
000072bd77dcee75  add rsp, 0xF0
000072bd77dcee7c  pop r11
000072bd77dcee7e  pop r10
000072bd77dcee80  pop r9
000072bd77dcee82  pop r8
000072bd77dcee84  pop rsi
000072bd77dcee85  pop rdi
000072bd77dcee86  pop rdx
000072bd77dcee87  pop rcx
000072bd77dcee88  pop rax
000072bd77dcee89  add rsp, 0x08
000072bd77dcee8d  jmp 0x000072BD77DCEC71
000072bd77dcee92  call 0x000072BD77CC2240
000072bd77dcee97  jmp 0x000072BD77DCEC8B
000072bd77dcee9c  sub rsp, 0x08
000072bd77dceea0  push rax
000072bd77dceea1  push rcx
000072bd77dceea2  push rdx
000072bd77dceea3  push rdi
000072bd77dceea4  push rsi
000072bd77dceea5  push r8
000072bd77dceea7  push r9
000072bd77dceea9  push r10
000072bd77dceeab  push r11
000072bd77dceead  sub rsp, 0xF0
000072bd77dceeb4  vmovaps [rsp], xmm0
000072bd77dceeb9  vmovaps [rsp+0x10], xmm1
000072bd77dceebf  vmovaps [rsp+0x20], xmm2
000072bd77dceec5  vmovaps [rsp+0x30], xmm3
000072bd77dceecb  vmovaps [rsp+0x40], xmm4
000072bd77dceed1  vmovaps [rsp+0x50], xmm5
000072bd77dceed7  vmovaps [rsp+0x60], xmm6
000072bd77dceedd  vmovaps [rsp+0x70], xmm7
000072bd77dceee3  vmovaps [rsp+0x80], xmm8
000072bd77dceeec  vmovaps [rsp+0x90], xmm9
000072bd77dceef5  vmovaps [rsp+0xA0], xmm10
000072bd77dceefe  vmovaps [rsp+0xB0], xmm11
000072bd77dcef07  vmovaps [rsp+0xC0], xmm12
000072bd77dcef10  vmovaps [rsp+0xD0], xmm13
000072bd77dcef19  vmovaps [rsp+0xE0], xmm15
000072bd77dcef22  sub rsp, 0x30
000072bd77dcef26  movaps [rsp], xmm14
000072bd77dcef2b  movaps [rsp+0x10], xmm1
000072bd77dcef30  movaps [rsp+0x20], xmm15
000072bd77dcef36  lea rdi, [rsp]
000072bd77dcef3a  mov esi, 0x00
000072bd77dcef3f  mov rax, 0x643206AC3530
000072bd77dcef49  call rax
000072bd77dcef4b  movaps xmm14, [rsp]
000072bd77dcef50  add rsp, 0x30
000072bd77dcef54  vmovaps xmm0, [rsp]
000072bd77dcef59  vmovaps xmm1, [rsp+0x10]
000072bd77dcef5f  vmovaps xmm2, [rsp+0x20]
000072bd77dcef65  vmovaps xmm3, [rsp+0x30]
000072bd77dcef6b  vmovaps xmm4, [rsp+0x40]
000072bd77dcef71  vmovaps xmm5, [rsp+0x50]
000072bd77dcef77  vmovaps xmm6, [rsp+0x60]
000072bd77dcef7d  vmovaps xmm7, [rsp+0x70]
000072bd77dcef83  vmovaps xmm8, [rsp+0x80]
000072bd77dcef8c  vmovaps xmm9, [rsp+0x90]
000072bd77dcef95  vmovaps xmm10, [rsp+0xA0]
000072bd77dcef9e  vmovaps xmm11, [rsp+0xB0]
000072bd77dcefa7  vmovaps xmm12, [rsp+0xC0]
000072bd77dcefb0  vmovaps xmm13, [rsp+0xD0]
000072bd77dcefb9  vmovaps xmm15, [rsp+0xE0]
000072bd77dcefc2  add rsp, 0xF0
000072bd77dcefc9  pop r11
000072bd77dcefcb  pop r10
000072bd77dcefcd  pop r9
000072bd77dcefcf  pop r8
000072bd77dcefd1  pop rsi
000072bd77dcefd2  pop rdi
000072bd77dcefd3  pop rdx
000072bd77dcefd4  pop rcx
000072bd77dcefd5  pop rax
000072bd77dcefd6  add rsp, 0x08
000072bd77dcefda  jmp 0x000072BD77DCECAE
000072bd77dcefdf  call 0x000072BD77CC34C0
000072bd77dcefe4  jmp 0x000072BD77DCECC4
000072bd77dcefe9  int3
000072bd77dcefea  nop [rax+rax*1], ax
000072bd77dceff0  mov rax, [r15+0xF8]
000072bd77dceff7  lea r14, [rax-0x150]
000072bd77dceffe  mov [r15+0xF8], r14
000072bd77dcf005  mov rax, [r15+0x50]
000072bd77dcf009  lea r12, [rax+0x80]
000072bd77dcf010  movups xmm1, [r13+r12*1]
000072bd77dcf016  lea r12, [rax+0x90]
000072bd77dcf01d  movups xmm15, [r13+r12*1]
000072bd77dcf023  mov qword ptr [r15+0x48], 0x00
000072bd77dcf02b  lea r12, [rax+0x40]
000072bd77dcf02f  movups xmm14, [r13+r12*1]
000072bd77dcf035  lea r12, [rax+0x50]
000072bd77dcf039  movups xmm13, [r13+r12*1]
000072bd77dcf03f  lea r12, [r14+0x120]
000072bd77dcf046  movq xmm12, qword ptr [r15+0x1C0]
000072bd77dcf04f  movq xmm11, qword ptr [r15+0x1B0]
000072bd77dcf058  movq r11, xmm12
000072bd77dcf05d  movq r10, xmm11
000072bd77dcf062  mov [r13+r12*1], r11
000072bd77dcf067  lea r12, [r14+0x128]
000072bd77dcf06e  mov [r13+r12*1], r10
000072bd77dcf073  vxorps xmm12, xmm12, xmm12
000072bd77dcf078  vpbroadcastq xmm12, xmm12
000072bd77dcf07d  lea r12, [r14+0x100]
000072bd77dcf084  movq xmm11, qword ptr [r15+0x200]
000072bd77dcf08d  movq xmm10, qword ptr [r15+0x1F0]
000072bd77dcf096  movq r11, xmm11
000072bd77dcf09b  movq r10, xmm10
000072bd77dcf0a0  mov [r13+r12*1], r11
000072bd77dcf0a5  lea r12, [r14+0x108]
000072bd77dcf0ac  mov [r13+r12*1], r10
000072bd77dcf0b1  lea r12, [r14+0xE0]
000072bd77dcf0b8  movups [r13+r12*1], xmm15
000072bd77dcf0be  lea r12, [r14+0xF0]
000072bd77dcf0c5  movups [r13+r12*1], xmm1
000072bd77dcf0cb  lea r12, [rax+0xC0]
000072bd77dcf0d2  movups xmm1, [r13+r12*1]
000072bd77dcf0d8  lea r12, [rax+0xD0]
000072bd77dcf0df  movups xmm15, [r13+r12*1]
000072bd77dcf0e5  lea r12, [r14+0x110]
000072bd77dcf0ec  movq xmm11, qword ptr [r15+0x1E0]
000072bd77dcf0f5  movq xmm10, qword ptr [r15+0x1D0]
000072bd77dcf0fe  movq r11, xmm11
000072bd77dcf103  movq r10, xmm10
000072bd77dcf108  mov [r13+r12*1], r11
000072bd77dcf10d  lea r12, [r14+0x118]
000072bd77dcf114  mov [r13+r12*1], r10
000072bd77dcf119  movups xmm11, [r13+rax*1]
000072bd77dcf11f  lea r12, [rax+0x10]
000072bd77dcf123  movups xmm10, [r13+r12*1]
000072bd77dcf129  lea r12, [r14+0x130]
000072bd77dcf130  movq xmm9, qword ptr [r15+0x1A0]
000072bd77dcf139  movq xmm8, qword ptr [r15+0x190]
000072bd77dcf142  movq r11, xmm9
000072bd77dcf147  movq r10, xmm8
000072bd77dcf14c  mov [r13+r12*1], r11
000072bd77dcf151  lea r12, [r14+0x138]
000072bd77dcf158  mov [r13+r12*1], r10
000072bd77dcf15d  lea r12, [rax+0x140]
000072bd77dcf164  movups xmm9, [r13+r12*1]
000072bd77dcf16a  lea r12, [rax+0x150]
000072bd77dcf171  movups xmm8, [r13+r12*1]
000072bd77dcf177  lea r12, [r14+0xC0]
000072bd77dcf17e  movups [r13+r12*1], xmm15
000072bd77dcf184  lea r12, [r14+0xD0]
000072bd77dcf18b  movups [r13+r12*1], xmm1
000072bd77dcf191  lea r12, [rax+0x100]
000072bd77dcf198  movups xmm1, [r13+r12*1]
000072bd77dcf19e  lea r12, [rax+0x110]
000072bd77dcf1a5  movups xmm15, [r13+r12*1]
000072bd77dcf1ab  lea r12, [r14+0x140]
000072bd77dcf1b2  mov r11, [r15+0xE8]
000072bd77dcf1b9  mov [r13+r12*1], r11
000072bd77dcf1be  lea r12, [rax+0x180]
000072bd77dcf1c5  movups xmm7, [r13+r12*1]
000072bd77dcf1cb  lea r12, [rax+0x190]
000072bd77dcf1d2  movups xmm6, [r13+r12*1]
000072bd77dcf1d8  lea r12, [rax+0x1C0]
000072bd77dcf1df  movups xmm5, [r13+r12*1]
000072bd77dcf1e5  lea r12, [rax+0x1D0]
000072bd77dcf1ec  movups xmm4, [r13+r12*1]
000072bd77dcf1f2  lea r12, [r14+0x20]
000072bd77dcf1f6  movups [r13+r12*1], xmm1
000072bd77dcf1fc  lea r12, [r14+0x30]
000072bd77dcf200  movups [r13+r12*1], xmm13
000072bd77dcf206  lea r12, [rax+0x60]
000072bd77dcf20a  movups xmm1, [r13+r12*1]
000072bd77dcf210  lea r12, [rax+0x70]
000072bd77dcf214  movups xmm13, [r13+r12*1]
000072bd77dcf21a  lea r12, [rax+0x20]
000072bd77dcf21e  movups xmm3, [r13+r12*1]
000072bd77dcf224  lea r12, [rax+0x30]
000072bd77dcf228  movups xmm2, [r13+r12*1]
000072bd77dcf22e  movaps [r15+0x1F0], xmm2
000072bd77dcf236  lea r12, [r14+0x60]
000072bd77dcf23a  movups [r13+r12*1], xmm11
000072bd77dcf240  lea r12, [r14+0x70]
000072bd77dcf244  movups [r13+r12*1], xmm5
000072bd77dcf24a  lea r12, [rax+0xE0]
000072bd77dcf251  movups xmm11, [r13+r12*1]
000072bd77dcf257  lea r12, [rax+0xF0]
000072bd77dcf25e  movups xmm5, [r13+r12*1]
000072bd77dcf264  lea r12, [r14+0xA0]
000072bd77dcf26b  movups [r13+r12*1], xmm13
000072bd77dcf271  lea r12, [r14+0xB0]
000072bd77dcf278  movups [r13+r12*1], xmm1
000072bd77dcf27e  lea r12, [rax+0xA0]
000072bd77dcf285  movups xmm1, [r13+r12*1]
000072bd77dcf28b  lea r12, [rax+0xB0]
000072bd77dcf292  movups xmm13, [r13+r12*1]
000072bd77dcf298  lea r12, [rax+0x120]
000072bd77dcf29f  vmovaps [rsp+0x10], xmm1
000072bd77dcf2a5  movups xmm1, [r13+r12*1]
000072bd77dcf2ab  lea r12, [rax+0x130]
000072bd77dcf2b2  vmovaps [rsp+0x20], xmm1
000072bd77dcf2b8  movups xmm1, [r13+r12*1]
000072bd77dcf2be  lea r12, [rax+0x160]
000072bd77dcf2c5  vmovaps [rsp+0x30], xmm1
000072bd77dcf2cb  movups xmm1, [r13+r12*1]
000072bd77dcf2d1  lea r12, [rax+0x170]
000072bd77dcf2d8  vmovaps [rsp+0x40], xmm1
000072bd77dcf2de  movups xmm1, [r13+r12*1]
000072bd77dcf2e4  movaps [r15+0x2B0], xmm1
000072bd77dcf2ec  lea r12, [r14+0x80]
000072bd77dcf2f3  movups [r13+r12*1], xmm13
000072bd77dcf2f9  lea r12, [r14+0x90]
000072bd77dcf300  vmovaps xmm13, [rsp+0x10]
000072bd77dcf306  movups [r13+r12*1], xmm13
000072bd77dcf30c  lea r12, [rax+0x1A0]
000072bd77dcf313  movups xmm13, [r13+r12*1]
000072bd77dcf319  lea r12, [rax+0x1B0]
000072bd77dcf320  vmovaps [rsp+0x10], xmm1
000072bd77dcf326  movups xmm1, [r13+r12*1]
000072bd77dcf32c  movaps [r15+0x290], xmm13
000072bd77dcf334  movaps [r15+0x1E0], xmm1
000072bd77dcf33c  lea r12, [rax+0x1E0]
000072bd77dcf343  vmovaps [rsp+0x50], xmm1
000072bd77dcf349  movups xmm1, [r13+r12*1]
000072bd77dcf34f  lea r12, [rax+0x1F0]
000072bd77dcf356  vmovaps [rsp+0x60], xmm1
000072bd77dcf35c  movups xmm1, [r13+r12*1]
000072bd77dcf362  mov qword ptr [r15+0x50], 0x430920
000072bd77dcf36a  lea rax, [r14+0x40]
000072bd77dcf36e  vmovaps [rsp+0x70], xmm1
000072bd77dcf374  vmovaps xmm1, [rsp+0x40]
000072bd77dcf37a  movups [r13+rax*1], xmm1
000072bd77dcf380  lea rax, [r14+0x50]
000072bd77dcf384  movups [r13+rax*1], xmm10
000072bd77dcf38a  vmovaps xmm1, [rsp+0x70]
000072bd77dcf390  movups [r13+r14*1], xmm1
000072bd77dcf396  lea rax, [r14+0x10]
000072bd77dcf39a  vmovaps xmm1, [rsp+0x60]
000072bd77dcf3a0  movups [r13+rax*1], xmm1
000072bd77dcf3a6  mov rax, [r15+0x40]
000072bd77dcf3aa  vmovaps [rsp+0x40], xmm3
000072bd77dcf3b0  vmovaps xmm1, [rsp+0x40]
000072bd77dcf3b6  por xmm3, xmm1
000072bd77dcf3ba  vmovaps [rsp+0x40], xmm6
000072bd77dcf3c0  vmovaps xmm10, [rsp+0x40]
000072bd77dcf3c6  por xmm6, xmm10
000072bd77dcf3cb  lea r12, [rax+0x30]
000072bd77dcf3cf  mov r11, [r13+r12*1]
000072bd77dcf3d4  lea r12, [rax+0x38]
000072bd77dcf3d8  mov r10, [r13+r12*1]
000072bd77dcf3dd  movq xmm10, r11
000072bd77dcf3e2  vmovaps [rsp+0x40], xmm1
000072bd77dcf3e8  movq xmm1, r10
000072bd77dcf3ed  movq xmm10, xmm10
000072bd77dcf3f2  vmovaps [rsp+0x60], xmm10
000072bd77dcf3f8  movq xmm10, xmm10
000072bd77dcf3fd  movaps [r15+0x130], xmm10
000072bd77dcf405  movq xmm1, xmm1
000072bd77dcf409  vmovaps [rsp+0x70], xmm1
000072bd77dcf40f  movq xmm1, xmm1
000072bd77dcf413  movaps [r15+0x280], xmm1
000072bd77dcf41b  vmovaps [rsp+0x80], xmm9
000072bd77dcf424  vmovaps xmm1, [rsp+0x80]
000072bd77dcf42d  por xmm9, xmm1
000072bd77dcf432  lea r12, [rax+0x20]
000072bd77dcf436  mov r11, [r13+r12*1]
000072bd77dcf43b  lea r12, [rax+0x28]
000072bd77dcf43f  mov r10, [r13+r12*1]
000072bd77dcf444  movq xmm1, r11
000072bd77dcf449  movq xmm10, r10
000072bd77dcf44e  movq xmm1, xmm1
000072bd77dcf452  vmovaps [rsp+0x80], xmm1
000072bd77dcf45b  movq xmm1, xmm1
000072bd77dcf45f  movaps [r15+0x150], xmm1
000072bd77dcf467  movq xmm10, xmm10
000072bd77dcf46c  vmovaps [rsp+0x90], xmm10
000072bd77dcf475  movq xmm10, xmm10
000072bd77dcf47a  movaps [r15+0x140], xmm10
000072bd77dcf482  lea r12, [rax+0x10]
000072bd77dcf486  mov r11, [r13+r12*1]
000072bd77dcf48b  lea r12, [rax+0x18]
000072bd77dcf48f  mov r10, [r13+r12*1]
000072bd77dcf494  movq xmm1, r11
000072bd77dcf499  movq xmm10, r10
000072bd77dcf49e  movq xmm1, xmm1
000072bd77dcf4a2  vmovaps [rsp+0xA0], xmm1
000072bd77dcf4ab  movq xmm1, xmm1
000072bd77dcf4af  movaps [r15+0x170], xmm1
000072bd77dcf4b7  movq xmm10, xmm10
000072bd77dcf4bc  vmovaps [rsp+0xB0], xmm10
000072bd77dcf4c5  movq xmm10, xmm10
000072bd77dcf4ca  movaps [r15+0x160], xmm10
000072bd77dcf4d2  mov r12, [r13+rax*1]
000072bd77dcf4d7  vmovq xmm1, r12
000072bd77dcf4dc  vpbroadcastq xmm1, xmm1
000072bd77dcf4e1  lea r12, [rax+0x08]
000072bd77dcf4e5  mov rax, [r13+r12*1]
000072bd77dcf4ea  movq xmm10, rax
000072bd77dcf4ef  movaps [r15+0x230], xmm10
000072bd77dcf4f7  lea rax, [r14+0x50]
000072bd77dcf4fb  movups xmm10, [r13+rax*1]
000072bd77dcf501  lea rax, [r14+0x60]
000072bd77dcf505  vmovaps [rsp+0xC0], xmm1
000072bd77dcf50e  movups xmm1, [r13+rax*1]
000072bd77dcf514  lea rax, [r14+0x30]
000072bd77dcf518  vmovaps [rsp+0xD0], xmm1
000072bd77dcf521  movups xmm1, [r13+rax*1]
000072bd77dcf527  mov qword ptr [r15+0x60], 0x430920
000072bd77dcf52f  mov qword ptr [r15+0x58], 0x40
000072bd77dcf537  vmovaps [rsp+0xE0], xmm1
000072bd77dcf540  vmovaps [rsp+0xF0], xmm15
000072bd77dcf549  vmovaps xmm15, [rsp+0xC0]
000072bd77dcf552  vmovaps [rsp+0xC0], xmm14
000072bd77dcf55b  vmovaps xmm14, [rsp+0x40]
000072bd77dcf561  vmovaps [rsp+0x40], xmm13
000072bd77dcf567  movaps xmm1, xmm15
000072bd77dcf56b  mulpd xmm1, xmm14
000072bd77dcf570  vcmppd xmm13, xmm1, xmm1, 0x03
000072bd77dcf575  ptest xmm13, xmm13
000072bd77dcf57b  jnz 0x000072BD77DD0682
000072bd77dcf581  movq xmm14, qword ptr [r15+0x230]
000072bd77dcf58a  vmovaps [rsp+0x100], xmm14
000072bd77dcf593  vpermilpd xmm14, xmm14, 0x00
000072bd77dcf599  vmovaps [rsp+0x110], xmm1
000072bd77dcf5a2  vmovaps xmm1, [rsp+0xE0]
000072bd77dcf5ab  vmovaps [rsp+0xE0], xmm15
000072bd77dcf5b4  movaps xmm13, xmm1
000072bd77dcf5b8  mulpd xmm13, xmm14
000072bd77dcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000072bd77dcf5c3  ptest xmm15, xmm15
000072bd77dcf5c9  jnz 0x000072BD77DD07C4
000072bd77dcf5cf  vxorps xmm1, xmm1, xmm1
000072bd77dcf5d3  vpbroadcastq xmm1, xmm1
000072bd77dcf5d8  vmovaps xmm14, [rsp+0xE0]
000072bd77dcf5e1  vmovaps [rsp+0xE0], xmm1
000072bd77dcf5ea  vmovaps xmm1, [rsp+0xD0]
000072bd77dcf5f3  vmovaps [rsp+0xD0], xmm13
000072bd77dcf5fc  movaps xmm15, xmm14
000072bd77dcf600  mulpd xmm15, xmm1
000072bd77dcf605  vcmppd xmm13, xmm15, xmm15, 0x03
000072bd77dcf60b  ptest xmm13, xmm13
000072bd77dcf611  jnz 0x000072BD77DD0907
000072bd77dcf617  movaps xmm1, xmm14
000072bd77dcf61b  mulpd xmm1, xmm10
000072bd77dcf620  vcmppd xmm13, xmm1, xmm1, 0x03
000072bd77dcf625  ptest xmm13, xmm13
000072bd77dcf62b  jnz 0x000072BD77DD0A4A
000072bd77dcf631  movaps xmm13, xmm14
000072bd77dcf635  mulpd xmm13, xmm2
000072bd77dcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000072bd77dcf640  ptest xmm10, xmm10
000072bd77dcf646  jnz 0x000072BD77DD0B8C
000072bd77dcf64c  vmovaps [rsp+0x120], xmm7
000072bd77dcf655  vmovaps xmm14, [rsp+0x120]
000072bd77dcf65e  por xmm7, xmm14
000072bd77dcf663  vmovaps xmm14, [rsp+0xC0]
000072bd77dcf66c  vmovaps xmm10, [rsp+0xC0]
000072bd77dcf675  por xmm14, xmm10
000072bd77dcf67a  vmovaps xmm2, [rsp+0x100]
000072bd77dcf683  vpermilpd xmm2, xmm2, 0x00
000072bd77dcf689  vmovaps [rsp+0xC0], xmm1
000072bd77dcf692  vmovaps [rsp+0x120], xmm15
000072bd77dcf69b  movaps xmm1, xmm10
000072bd77dcf69f  mulpd xmm1, xmm2
000072bd77dcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000072bd77dcf6a8  ptest xmm15, xmm15
000072bd77dcf6ae  jnz 0x000072BD77DD0CCF
000072bd77dcf6b4  xor eax, eax
000072bd77dcf6b6  mov r12d, 0x40
000072bd77dcf6bc  mov r11d, 0x200
000072bd77dcf6c2  cmp r12, r11
000072bd77dcf6c5  cmc
000072bd77dcf6c6  lahf
000072bd77dcf6c7  seto al
000072bd77dcf6ca  mov [r15+0x108], eax
000072bd77dcf6d1  vmovaps xmm10, [rsp+0x110]
000072bd77dcf6da  vmovaps xmm2, [rsp+0xE0]
000072bd77dcf6e3  vmovaps [rsp+0xE0], xmm1
000072bd77dcf6ec  movaps xmm15, xmm10
000072bd77dcf6f0  addpd xmm15, xmm2
000072bd77dcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000072bd77dcf6fb  ptest xmm1, xmm1
000072bd77dcf700  jnz 0x000072BD77DD0E10
000072bd77dcf706  vmovaps xmm10, [rsp+0x120]
000072bd77dcf70f  vmovaps [rsp+0x110], xmm15
000072bd77dcf718  movaps xmm1, xmm10
000072bd77dcf71c  addpd xmm1, xmm12
000072bd77dcf721  vcmppd xmm15, xmm1, xmm1, 0x03
000072bd77dcf726  ptest xmm15, xmm15
000072bd77dcf72c  jnz 0x000072BD77DD0F53
000072bd77dcf732  vmovaps xmm10, [rsp+0xC0]
000072bd77dcf73b  vmovaps [rsp+0xC0], xmm1
000072bd77dcf744  movaps xmm15, xmm10
000072bd77dcf748  addpd xmm15, xmm12
000072bd77dcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000072bd77dcf753  ptest xmm1, xmm1
000072bd77dcf758  jnz 0x000072BD77DD1095
000072bd77dcf75e  vmovaps xmm1, [rsp+0x30]
000072bd77dcf764  vmovaps xmm12, [rsp+0x30]
000072bd77dcf76a  por xmm1, xmm12
000072bd77dcf76f  vmovaps xmm12, [rsp+0x20]
000072bd77dcf775  vmovaps xmm10, [rsp+0x20]
000072bd77dcf77b  por xmm12, xmm10
000072bd77dcf780  vmovaps [rsp+0x20], xmm5
000072bd77dcf786  vmovaps xmm10, [rsp+0x20]
000072bd77dcf78c  por xmm5, xmm10
000072bd77dcf791  vmovaps [rsp+0x20], xmm11
000072bd77dcf797  vmovaps xmm10, [rsp+0x20]
000072bd77dcf79d  por xmm11, xmm10
000072bd77dcf7a2  vmovaps [rsp+0x20], xmm4
000072bd77dcf7a8  vmovaps xmm10, [rsp+0x20]
000072bd77dcf7ae  por xmm4, xmm10
000072bd77dcf7b3  vmovaps [rsp+0x20], xmm8
000072bd77dcf7b9  vmovaps xmm10, [rsp+0x20]
000072bd77dcf7bf  por xmm8, xmm10
000072bd77dcf7c4  vmovaps xmm10, [rsp+0xF0]
000072bd77dcf7cd  vmovaps [rsp+0x20], xmm1
000072bd77dcf7d3  vmovaps xmm1, [rsp+0xF0]
000072bd77dcf7dc  por xmm10, xmm1
000072bd77dcf7e1  lea rax, [r14+0xA0]
000072bd77dcf7e8  movups xmm1, [r13+rax*1]
000072bd77dcf7ee  lea rax, [r14+0xB0]
000072bd77dcf7f5  vmovaps [rsp+0x30], xmm1
000072bd77dcf7fb  movups xmm1, [r13+rax*1]
000072bd77dcf801  vmovaps [rsp+0xF0], xmm1
000072bd77dcf80a  vmovaps [rsp+0x120], xmm15
000072bd77dcf813  movaps xmm1, xmm13
000072bd77dcf817  addpd xmm1, xmm2
000072bd77dcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000072bd77dcf820  ptest xmm15, xmm15
000072bd77dcf826  jnz 0x000072BD77DD11ED
000072bd77dcf82c  lea rax, [r14+0xF0]
000072bd77dcf833  movups xmm15, [r13+rax*1]
000072bd77dcf839  vmovaps xmm2, [rsp+0xC0]
000072bd77dcf842  vmovaps [rsp+0xC0], xmm1
000072bd77dcf84b  vmovaps xmm1, [rsp+0xE0]
000072bd77dcf854  vmovaps [rsp+0xE0], xmm15
000072bd77dcf85d  movaps xmm13, xmm2
000072bd77dcf861  addpd xmm13, xmm1
000072bd77dcf866  vcmppd xmm15, xmm13, xmm13, 0x03
000072bd77dcf86c  ptest xmm15, xmm15
000072bd77dcf872  jnz 0x000072BD77DD1338
000072bd77dcf878  vmovaps xmm15, [rsp+0x120]
000072bd77dcf881  vmovaps xmm2, [rsp+0xD0]
000072bd77dcf88a  vmovaps [rsp+0xD0], xmm14
000072bd77dcf893  movaps xmm1, xmm15
000072bd77dcf897  addpd xmm1, xmm2
000072bd77dcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000072bd77dcf8a0  ptest xmm14, xmm14
000072bd77dcf8a6  jnz 0x000072BD77DD147A
000072bd77dcf8ac  vmovaps xmm15, [rsp+0x100]
000072bd77dcf8b5  vpermilpd xmm15, xmm15, 0x00
000072bd77dcf8bb  vmovaps xmm2, [rsp+0xF0]
000072bd77dcf8c4  vmovaps [rsp+0xF0], xmm1
000072bd77dcf8cd  movaps xmm14, xmm2
000072bd77dcf8d1  mulpd xmm14, xmm15
000072bd77dcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000072bd77dcf8dc  ptest xmm1, xmm1
000072bd77dcf8e1  jnz 0x000072BD77DD15BB
000072bd77dcf8e7  vmovaps xmm1, [rsp+0xA0]
000072bd77dcf8f0  vpermilpd xmm1, xmm1, 0x00
000072bd77dcf8f6  vmovaps xmm2, [rsp+0xE0]
000072bd77dcf8ff  vmovaps [rsp+0xE0], xmm14
000072bd77dcf908  movaps xmm15, xmm2
000072bd77dcf90c  mulpd xmm15, xmm1
000072bd77dcf911  vcmppd xmm14, xmm15, xmm15, 0x03
000072bd77dcf917  ptest xmm14, xmm14
000072bd77dcf91d  jnz 0x000072BD77DD16FE
000072bd77dcf923  lea rax, [r14+0xE0]
000072bd77dcf92a  movups xmm1, [r13+rax*1]
000072bd77dcf930  vmovaps xmm14, [rsp+0x100]
000072bd77dcf939  vpermilpd xmm14, xmm14, 0x00
000072bd77dcf93f  vmovaps [rsp+0x100], xmm1
000072bd77dcf948  vmovaps xmm1, [rsp+0x30]
000072bd77dcf94e  vmovaps [rsp+0x30], xmm15
000072bd77dcf954  movaps xmm2, xmm1
000072bd77dcf957  mulpd xmm2, xmm14
000072bd77dcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000072bd77dcf961  ptest xmm15, xmm15
000072bd77dcf967  jnz 0x000072BD77DD184A
000072bd77dcf96d  vmovaps [rsp+0x120], xmm10
000072bd77dcf976  vmovaps xmm1, [rsp+0x120]
000072bd77dcf97f  por xmm10, xmm1
000072bd77dcf984  movaps [r15+0x300], xmm10
000072bd77dcf98c  vmovaps [rsp+0x120], xmm8
000072bd77dcf995  vmovaps xmm1, [rsp+0x120]
000072bd77dcf99e  por xmm8, xmm1
000072bd77dcf9a3  movaps [r15+0x190], xmm8
000072bd77dcf9ab  vmovaps xmm1, [rsp+0xA0]
000072bd77dcf9b4  vpermilpd xmm1, xmm1, 0x00
000072bd77dcf9ba  vmovaps xmm14, [rsp+0x100]
000072bd77dcf9c3  vmovaps [rsp+0x100], xmm13
000072bd77dcf9cc  movaps xmm15, xmm14
000072bd77dcf9d0  mulpd xmm15, xmm1
000072bd77dcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000072bd77dcf9db  ptest xmm13, xmm13
000072bd77dcf9e1  jnz 0x000072BD77DD198B
000072bd77dcf9e7  lea rax, [r14+0x90]
000072bd77dcf9ee  movups xmm1, [r13+rax*1]
000072bd77dcf9f4  vmovaps [rsp+0x120], xmm4
000072bd77dcf9fd  vmovaps xmm14, [rsp+0x120]
000072bd77dcfa06  por xmm4, xmm14
000072bd77dcfa0b  movaps [r15+0x1C0], xmm4
000072bd77dcfa13  vmovaps [rsp+0x120], xmm11
000072bd77dcfa1c  vmovaps xmm14, [rsp+0x120]
000072bd77dcfa25  por xmm11, xmm14
000072bd77dcfa2a  movaps [r15+0x200], xmm11
000072bd77dcfa32  vmovaps [rsp+0x120], xmm5
000072bd77dcfa3b  vmovaps xmm14, [rsp+0x120]
000072bd77dcfa44  por xmm5, xmm14
000072bd77dcfa49  movaps [r15+0x2D0], xmm5
000072bd77dcfa51  vmovaps [rsp+0x120], xmm12
000072bd77dcfa5a  vmovaps xmm14, [rsp+0x120]
000072bd77dcfa63  por xmm12, xmm14
000072bd77dcfa68  movaps [r15+0x2E0], xmm12
000072bd77dcfa70  vmovaps xmm13, [rsp+0x110]
000072bd77dcfa79  vmovaps [rsp+0x110], xmm1
000072bd77dcfa82  vmovaps xmm1, [rsp+0xE0]
000072bd77dcfa8b  vmovaps [rsp+0xE0], xmm15
000072bd77dcfa94  movaps xmm14, xmm13
000072bd77dcfa98  addpd xmm14, xmm1
000072bd77dcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000072bd77dcfaa3  ptest xmm15, xmm15
000072bd77dcfaa9  jnz 0x000072BD77DD1AD8
000072bd77dcfaaf  vmovaps xmm1, [rsp+0xA0]
000072bd77dcfab8  vpermilpd xmm1, xmm1, 0x00
000072bd77dcfabe  vmovaps xmm13, [rsp+0x110]
000072bd77dcfac7  vmovaps [rsp+0x110], xmm14
000072bd77dcfad0  movaps xmm15, xmm13
000072bd77dcfad4  mulpd xmm15, xmm1
000072bd77dcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000072bd77dcfadf  ptest xmm14, xmm14
000072bd77dcfae5  jnz 0x000072BD77DD1C1B
000072bd77dcfaeb  lea rax, [r14+0x80]
000072bd77dcfaf2  movups xmm1, [r13+rax*1]
000072bd77dcfaf8  vmovaps xmm13, [rsp+0xC0]
000072bd77dcfb01  vmovaps [rsp+0xC0], xmm1
000072bd77dcfb0a  movaps xmm14, xmm13
000072bd77dcfb0e  addpd xmm14, xmm2
000072bd77dcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000072bd77dcfb19  ptest xmm1, xmm1
000072bd77dcfb1e  jnz 0x000072BD77DD1D68
000072bd77dcfb24  vmovaps xmm13, [rsp+0x100]
000072bd77dcfb2d  vmovaps xmm2, [rsp+0x30]
000072bd77dcfb33  vmovaps [rsp+0x30], xmm15
000072bd77dcfb39  movaps xmm1, xmm13
000072bd77dcfb3d  addpd xmm1, xmm2
000072bd77dcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000072bd77dcfb46  ptest xmm15, xmm15
000072bd77dcfb4c  jnz 0x000072BD77DD1EAB
000072bd77dcfb52  vmovaps xmm15, [rsp+0x20]
000072bd77dcfb58  vmovaps xmm13, [rsp+0x20]
000072bd77dcfb5e  por xmm15, xmm13
000072bd77dcfb63  movaps [r15+0x2F0], xmm15
000072bd77dcfb6b  vmovaps xmm13, [rsp+0xA0]
000072bd77dcfb74  vpermilpd xmm13, xmm13, 0x00
000072bd77dcfb7a  vmovaps [rsp+0x20], xmm1
000072bd77dcfb80  vmovaps xmm1, [rsp+0xC0]
000072bd77dcfb89  vmovaps [rsp+0xA0], xmm15
000072bd77dcfb92  movaps xmm2, xmm1
000072bd77dcfb95  mulpd xmm2, xmm13
000072bd77dcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000072bd77dcfb9f  ptest xmm15, xmm15
000072bd77dcfba5  jnz 0x000072BD77DD1FEC
000072bd77dcfbab  lea rax, [r14+0xD0]
000072bd77dcfbb2  movups xmm1, [r13+rax*1]
000072bd77dcfbb8  vmovaps xmm13, [rsp+0xF0]
000072bd77dcfbc1  vmovaps [rsp+0xC0], xmm1
000072bd77dcfbca  vmovaps xmm1, [rsp+0xE0]
000072bd77dcfbd3  vmovaps [rsp+0xE0], xmm14
000072bd77dcfbdc  movaps xmm15, xmm13
000072bd77dcfbe0  addpd xmm15, xmm1
000072bd77dcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000072bd77dcfbeb  ptest xmm14, xmm14
000072bd77dcfbf1  jnz 0x000072BD77DD2137
000072bd77dcfbf7  vmovaps xmm1, [rsp+0xB0]
000072bd77dcfc00  vpermilpd xmm1, xmm1, 0x00
000072bd77dcfc06  movaps xmm14, xmm11
000072bd77dcfc0a  mulpd xmm14, xmm1
000072bd77dcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000072bd77dcfc15  ptest xmm13, xmm13
000072bd77dcfc1b  jnz 0x000072BD77DD227A
000072bd77dcfc21  movaps [r15+0x260], xmm14
000072bd77dcfc29  vxorps xmm1, xmm1, xmm1
000072bd77dcfc2d  vpbroadcastq xmm1, xmm1
000072bd77dcfc32  movaps [r15+0x1B0], xmm1
000072bd77dcfc3a  vmovaps xmm1, [rsp+0xB0]
000072bd77dcfc43  vpermilpd xmm1, xmm1, 0x00
000072bd77dcfc49  vmovaps xmm11, [rsp+0xC0]
000072bd77dcfc52  vmovaps [rsp+0xC0], xmm15
000072bd77dcfc5b  movaps xmm13, xmm11
000072bd77dcfc5f  mulpd xmm13, xmm1
000072bd77dcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000072bd77dcfc6a  ptest xmm15, xmm15
000072bd77dcfc70  jnz 0x000072BD77DD23BD
000072bd77dcfc76  lea rax, [r14+0xC0]
000072bd77dcfc7d  movups xmm1, [r13+rax*1]
000072bd77dcfc83  vmovaps xmm11, [rsp+0x110]
000072bd77dcfc8c  vmovaps [rsp+0xF0], xmm1
000072bd77dcfc95  vmovaps xmm1, [rsp+0x30]
000072bd77dcfc9b  vmovaps [rsp+0x30], xmm14
000072bd77dcfca1  movaps xmm15, xmm11
000072bd77dcfca5  addpd xmm15, xmm1
000072bd77dcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000072bd77dcfcb0  ptest xmm14, xmm14
000072bd77dcfcb6  jnz 0x000072BD77DD250A
000072bd77dcfcbc  vmovaps [rsp+0x100], xmm9
000072bd77dcfcc5  vmovaps xmm1, [rsp+0x100]
000072bd77dcfcce  por xmm9, xmm1
000072bd77dcfcd3  movaps [r15+0x270], xmm9
000072bd77dcfcdb  vmovaps [rsp+0x100], xmm6
000072bd77dcfce4  vmovaps xmm1, [rsp+0x100]
000072bd77dcfced  por xmm6, xmm1
000072bd77dcfcf1  movaps [r15+0x1A0], xmm6
000072bd77dcfcf9  vmovaps xmm14, [rsp+0xB0]
000072bd77dcfd02  vpermilpd xmm14, xmm14, 0x00
000072bd77dcfd08  vmovaps xmm6, [rsp+0xF0]
000072bd77dcfd11  vmovaps [rsp+0xF0], xmm1
000072bd77dcfd1a  movaps xmm11, xmm6
000072bd77dcfd1e  mulpd xmm11, xmm14
000072bd77dcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000072bd77dcfd29  ptest xmm1, xmm1
000072bd77dcfd2e  jnz 0x000072BD77DD264D
000072bd77dcfd34  lea rax, [r14+0x20]
000072bd77dcfd38  movups xmm1, [r13+rax*1]
000072bd77dcfd3e  movaps [r15+0x110], xmm1
000072bd77dcfd46  vmovaps xmm6, [rsp+0xE0]
000072bd77dcfd4f  vmovaps [rsp+0xE0], xmm1
000072bd77dcfd58  movaps xmm14, xmm6
000072bd77dcfd5c  addpd xmm14, xmm2
000072bd77dcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000072bd77dcfd67  ptest xmm1, xmm1
000072bd77dcfd6c  jnz 0x000072BD77DD279A
000072bd77dcfd72  vmovaps xmm1, [rsp+0xB0]
000072bd77dcfd7b  vpermilpd xmm1, xmm1, 0x00
000072bd77dcfd81  movaps xmm6, xmm5
000072bd77dcfd84  mulpd xmm6, xmm1
000072bd77dcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000072bd77dcfd8d  ptest xmm2, xmm2
000072bd77dcfd92  jnz 0x000072BD77DD28DC
000072bd77dcfd98  vmovaps xmm5, [rsp+0x20]
000072bd77dcfd9e  movaps xmm1, xmm5
000072bd77dcfda1  addpd xmm1, xmm13
000072bd77dcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000072bd77dcfdab  ptest xmm2, xmm2
000072bd77dcfdb0  jnz 0x000072BD77DD2A1C
000072bd77dcfdb6  vmovaps xmm13, [rsp+0x80]
000072bd77dcfdbf  vpermilpd xmm13, xmm13, 0x00
000072bd77dcfdc5  vmovaps xmm2, [rsp+0xE0]
000072bd77dcfdce  vmovaps [rsp+0x20], xmm1
000072bd77dcfdd4  movaps xmm5, xmm2
000072bd77dcfdd7  mulpd xmm5, xmm13
000072bd77dcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000072bd77dcfde1  ptest xmm1, xmm1
000072bd77dcfde6  jnz 0x000072BD77DD2B5D
000072bd77dcfdec  vmovaps xmm1, [rsp+0x80]
000072bd77dcfdf5  vpermilpd xmm1, xmm1, 0x00
000072bd77dcfdfb  movaps xmm13, xmm10
000072bd77dcfdff  mulpd xmm13, xmm1
000072bd77dcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000072bd77dcfe0a  ptest xmm2, xmm2
000072bd77dcfe0f  jnz 0x000072BD77DD2C9E
000072bd77dcfe15  vmovaps xmm10, [rsp+0x30]
000072bd77dcfe1b  movaps xmm1, xmm15
000072bd77dcfe1f  addpd xmm1, xmm10
000072bd77dcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000072bd77dcfe29  ptest xmm2, xmm2
000072bd77dcfe2e  jnz 0x000072BD77DD2DE1
000072bd77dcfe34  vmovaps xmm10, [rsp+0xC0]
000072bd77dcfe3d  movaps xmm15, xmm10
000072bd77dcfe41  addpd xmm15, xmm11
000072bd77dcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000072bd77dcfe4c  ptest xmm2, xmm2
000072bd77dcfe51  jnz 0x000072BD77DD2F23
000072bd77dcfe57  vmovaps xmm11, [rsp+0x80]
000072bd77dcfe60  vpermilpd xmm11, xmm11, 0x00
000072bd77dcfe66  movaps xmm10, xmm12
000072bd77dcfe6a  mulpd xmm10, xmm11
000072bd77dcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000072bd77dcfe75  ptest xmm2, xmm2
000072bd77dcfe7a  jnz 0x000072BD77DD3067
000072bd77dcfe80  vmovaps xmm12, [rsp+0x80]
000072bd77dcfe89  vpermilpd xmm12, xmm12, 0x00
000072bd77dcfe8f  vmovaps xmm2, [rsp+0xA0]
000072bd77dcfe98  vmovaps [rsp+0x30], xmm1
000072bd77dcfe9e  movaps xmm11, xmm2
000072bd77dcfea2  mulpd xmm11, xmm12
000072bd77dcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000072bd77dcfead  ptest xmm1, xmm1
000072bd77dcfeb2  jnz 0x000072BD77DD31AB
000072bd77dcfeb8  movaps xmm1, xmm14
000072bd77dcfebc  addpd xmm1, xmm6
000072bd77dcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000072bd77dcfec5  ptest xmm12, xmm12
000072bd77dcfecb  jnz 0x000072BD77DD32EE
000072bd77dcfed1  vmovaps xmm12, [rsp+0x20]
000072bd77dcfed7  movaps xmm14, xmm12
000072bd77dcfedb  addpd xmm14, xmm5
000072bd77dcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000072bd77dcfee6  ptest xmm6, xmm6
000072bd77dcfeeb  jnz 0x000072BD77DD342F
000072bd77dcfef1  vmovaps xmm12, [rsp+0x90]
000072bd77dcfefa  vpermilpd xmm12, xmm12, 0x00
000072bd77dcff00  movaps xmm6, xmm9
000072bd77dcff04  mulpd xmm6, xmm12
000072bd77dcff09  vcmppd xmm5, xmm6, xmm6, 0x03
000072bd77dcff0e  ptest xmm5, xmm5
000072bd77dcff13  jnz 0x000072BD77DD3572
000072bd77dcff19  movaps xmm12, xmm15
000072bd77dcff1d  addpd xmm12, xmm13
000072bd77dcff22  vcmppd xmm9, xmm12, xmm12, 0x03
000072bd77dcff28  ptest xmm9, xmm9
000072bd77dcff2e  jnz 0x000072BD77DD36B4
000072bd77dcff34  vmovaps xmm13, [rsp+0x30]
000072bd77dcff3a  movaps xmm15, xmm13
000072bd77dcff3e  addpd xmm15, xmm10
000072bd77dcff43  vcmppd xmm9, xmm15, xmm15, 0x03
000072bd77dcff49  ptest xmm9, xmm9
000072bd77dcff4f  jnz 0x000072BD77DD37F8
000072bd77dcff55  vmovaps xmm13, [rsp+0xD0]
000072bd77dcff5e  vmovaps xmm10, [rsp+0xD0]
000072bd77dcff67  por xmm13, xmm10
000072bd77dcff6c  movaps [r15+0x250], xmm13
000072bd77dcff74  vmovaps [rsp+0x20], xmm7
000072bd77dcff7a  vmovaps xmm13, [rsp+0x20]
000072bd77dcff80  por xmm7, xmm13
000072bd77dcff85  movaps [r15+0x2A0], xmm7
000072bd77dcff8d  vmovaps [rsp+0x20], xmm3
000072bd77dcff93  vmovaps xmm13, [rsp+0x20]
000072bd77dcff99  por xmm3, xmm13
000072bd77dcff9e  movaps [r15+0x1D0], xmm3
000072bd77dcffa6  lea rax, [r14+0x40]
000072bd77dcffaa  movups xmm13, [r13+rax*1]
000072bd77dcffb0  movaps [r15+0x2C0], xmm13
000072bd77dcffb8  vmovaps xmm10, [rsp+0x90]
000072bd77dcffc1  vpermilpd xmm10, xmm10, 0x00
000072bd77dcffc7  movaps xmm9, xmm8
000072bd77dcffcb  mulpd xmm9, xmm10
000072bd77dcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000072bd77dcffd6  ptest xmm5, xmm5
000072bd77dcffdb  jnz 0x000072BD77DD3946
000072bd77dcffe1  movaps xmm10, xmm1
000072bd77dcffe5  addpd xmm10, xmm11
000072bd77dcffea  vcmppd xmm8, xmm10, xmm10, 0x03
000072bd77dcfff0  ptest xmm8, xmm8
000072bd77dcfff6  jnz 0x000072BD77DD3A8A
000072bd77dcfffc  movaps xmm1, xmm14
000072bd77dd0000  addpd xmm1, xmm6
000072bd77dd0004  vcmppd xmm11, xmm1, xmm1, 0x03
000072bd77dd0009  ptest xmm11, xmm11
000072bd77dd000f  jnz 0x000072BD77DD3BCD
000072bd77dd0015  vmovaps xmm14, [rsp+0x90]
000072bd77dd001e  vpermilpd xmm14, xmm14, 0x00
000072bd77dd0024  movaps xmm11, xmm13
000072bd77dd0028  mulpd xmm11, xmm14
000072bd77dd002d  vcmppd xmm8, xmm11, xmm11, 0x03
000072bd77dd0033  ptest xmm8, xmm8
000072bd77dd0039  jnz 0x000072BD77DD3D0E
000072bd77dd003f  vmovaps xmm14, [rsp+0x90]
000072bd77dd0048  vpermilpd xmm14, xmm14, 0x00
000072bd77dd004e  vmovaps xmm8, [rsp+0x10]
000072bd77dd0054  movaps xmm13, xmm8
000072bd77dd0058  mulpd xmm13, xmm14
000072bd77dd005d  vcmppd xmm6, xmm13, xmm13, 0x03
000072bd77dd0063  ptest xmm6, xmm6
000072bd77dd0068  jnz 0x000072BD77DD3E52
000072bd77dd006e  vmovaps xmm14, [rsp+0x60]
000072bd77dd0074  vpermilpd xmm14, xmm14, 0x00
000072bd77dd007a  movaps xmm8, xmm7
000072bd77dd007e  mulpd xmm8, xmm14
000072bd77dd0083  vcmppd xmm6, xmm8, xmm8, 0x03
000072bd77dd0089  ptest xmm6, xmm6
000072bd77dd008e  jnz 0x000072BD77DD3F96
000072bd77dd0094  movaps xmm14, xmm12
000072bd77dd0098  addpd xmm14, xmm9
000072bd77dd009d  vcmppd xmm7, xmm14, xmm14, 0x03
000072bd77dd00a3  ptest xmm7, xmm7
000072bd77dd00a8  jnz 0x000072BD77DD40D9
000072bd77dd00ae  vmovaps xmm12, [rsp+0x60]
000072bd77dd00b4  vpermilpd xmm12, xmm12, 0x00
000072bd77dd00ba  vmovaps xmm7, [rsp+0xF0]
000072bd77dd00c3  movaps xmm9, xmm7
000072bd77dd00c7  mulpd xmm9, xmm12
000072bd77dd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000072bd77dd00d2  ptest xmm6, xmm6
000072bd77dd00d7  jnz 0x000072BD77DD421D
000072bd77dd00dd  movaps xmm12, xmm15
000072bd77dd00e1  addpd xmm12, xmm11
000072bd77dd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000072bd77dd00ec  ptest xmm7, xmm7
000072bd77dd00f1  jnz 0x000072BD77DD4360
000072bd77dd00f7  vmovaps xmm15, [rsp+0x60]
000072bd77dd00fd  vpermilpd xmm15, xmm15, 0x00
000072bd77dd0103  vmovaps xmm7, [rsp+0x40]
000072bd77dd0109  movaps xmm11, xmm7
000072bd77dd010d  mulpd xmm11, xmm15
000072bd77dd0112  vcmppd xmm6, xmm11, xmm11, 0x03
000072bd77dd0118  ptest xmm6, xmm6
000072bd77dd011d  jnz 0x000072BD77DD44A4
000072bd77dd0123  movaps xmm15, xmm10
000072bd77dd0127  addpd xmm15, xmm13
000072bd77dd012c  vcmppd xmm7, xmm15, xmm15, 0x03
000072bd77dd0132  ptest xmm7, xmm7
000072bd77dd0137  jnz 0x000072BD77DD45E7
000072bd77dd013d  vmovaps xmm13, [rsp+0x60]
000072bd77dd0143  vpermilpd xmm13, xmm13, 0x00
000072bd77dd0149  vmovaps xmm7, [rsp+0x50]
000072bd77dd014f  movaps xmm10, xmm7
000072bd77dd0153  mulpd xmm10, xmm13
000072bd77dd0158  vcmppd xmm6, xmm10, xmm10, 0x03
000072bd77dd015e  ptest xmm6, xmm6
000072bd77dd0163  jnz 0x000072BD77DD472B
000072bd77dd0169  movaps xmm13, xmm1
000072bd77dd016d  addpd xmm13, xmm8
000072bd77dd0172  vcmppd xmm7, xmm13, xmm13, 0x03
000072bd77dd0178  ptest xmm7, xmm7
000072bd77dd017d  jnz 0x000072BD77DD486E
000072bd77dd0183  lea rax, [r14+0x70]
000072bd77dd0187  movups xmm1, [r13+rax*1]
000072bd77dd018d  movaps [r15+0x240], xmm1
000072bd77dd0195  movaps xmm8, xmm14
000072bd77dd0199  addpd xmm8, xmm9
000072bd77dd019e  vcmppd xmm7, xmm8, xmm8, 0x03
000072bd77dd01a4  ptest xmm7, xmm7
000072bd77dd01a9  jnz 0x000072BD77DD49BB
000072bd77dd01af  movaps [r15+0x170], xmm8
000072bd77dd01b7  vmovaps xmm14, [rsp+0x70]
000072bd77dd01bd  vpermilpd xmm14, xmm14, 0x00
000072bd77dd01c3  movaps xmm9, xmm1
000072bd77dd01c7  mulpd xmm9, xmm14
000072bd77dd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000072bd77dd01d2  ptest xmm7, xmm7
000072bd77dd01d7  jnz 0x000072BD77DD4AFF
000072bd77dd01dd  vmovaps xmm1, [rsp+0x70]
000072bd77dd01e3  vpermilpd xmm1, xmm1, 0x00
000072bd77dd01e9  movaps xmm14, xmm4
000072bd77dd01ed  mulpd xmm14, xmm1
000072bd77dd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000072bd77dd01f8  ptest xmm7, xmm7
000072bd77dd01fd  jnz 0x000072BD77DD4C42
000072bd77dd0203  movaps [r15+0x180], xmm14
000072bd77dd020b  movaps xmm1, xmm12
000072bd77dd020f  addpd xmm1, xmm11
000072bd77dd0214  vcmppd xmm7, xmm1, xmm1, 0x03
000072bd77dd0219  ptest xmm7, xmm7
000072bd77dd021e  jnz 0x000072BD77DD4D84
000072bd77dd0224  movaps [r15+0x210], xmm1
000072bd77dd022c  movups xmm12, [r13+r14*1]
000072bd77dd0232  lea rax, [r14+0x10]
000072bd77dd0236  movups xmm11, [r13+rax*1]
000072bd77dd023c  movaps [r15+0x230], xmm11
000072bd77dd0244  movaps xmm7, xmm15
000072bd77dd0248  addpd xmm7, xmm10
000072bd77dd024d  vcmppd xmm6, xmm7, xmm7, 0x03
000072bd77dd0252  ptest xmm6, xmm6
000072bd77dd0257  jnz 0x000072BD77DD4EDA
000072bd77dd025d  movaps [r15+0x130], xmm7
000072bd77dd0265  vmovaps xmm15, [rsp+0x70]
000072bd77dd026b  vpermilpd xmm15, xmm15, 0x00
000072bd77dd0271  movaps xmm10, xmm11
000072bd77dd0275  mulpd xmm10, xmm15
000072bd77dd027a  vcmppd xmm6, xmm10, xmm10, 0x03
000072bd77dd0280  ptest xmm6, xmm6
000072bd77dd0285  jnz 0x000072BD77DD501C
000072bd77dd028b  movaps [r15+0x220], xmm10
000072bd77dd0293  vmovaps xmm15, [rsp+0x70]
000072bd77dd0299  vpermilpd xmm15, xmm15, 0x00
000072bd77dd029f  movaps xmm11, xmm12
000072bd77dd02a3  mulpd xmm11, xmm15
000072bd77dd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000072bd77dd02ae  ptest xmm6, xmm6
000072bd77dd02b3  jnz 0x000072BD77DD5160
000072bd77dd02b9  movaps xmm15, xmm13
000072bd77dd02bd  addpd xmm15, xmm9
000072bd77dd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000072bd77dd02c8  ptest xmm12, xmm12
000072bd77dd02ce  jnz 0x000072BD77DD52A4
000072bd77dd02d4  movaps [r15+0x140], xmm15
000072bd77dd02dc  movaps xmm13, xmm8
000072bd77dd02e0  addpd xmm13, xmm14
000072bd77dd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000072bd77dd02eb  ptest xmm12, xmm12
000072bd77dd02f1  jnz 0x000072BD77DD53E8
000072bd77dd02f7  movaps [r15+0x150], xmm13
000072bd77dd02ff  movaps xmm14, xmm1
000072bd77dd0303  addpd xmm14, xmm10
000072bd77dd0308  vcmppd xmm12, xmm14, xmm14, 0x03
000072bd77dd030e  ptest xmm12, xmm12
000072bd77dd0314  jnz 0x000072BD77DD552C
000072bd77dd031a  movaps [r15+0x160], xmm14
000072bd77dd0322  movaps xmm1, xmm7
000072bd77dd0325  addpd xmm1, xmm11
000072bd77dd032a  vcmppd xmm12, xmm1, xmm1, 0x03
000072bd77dd032f  ptest xmm12, xmm12
000072bd77dd0335  jnz 0x000072BD77DD566F
000072bd77dd033b  movaps [r15+0x120], xmm1
000072bd77dd0343  mov eax, 0x430920
000072bd77dd0348  movups [r13+rax*1], xmm15
000072bd77dd034e  mov eax, 0x430930
000072bd77dd0353  movups [r13+rax*1], xmm13
000072bd77dd0359  mov eax, 0x430940
000072bd77dd035e  movups [r13+rax*1], xmm14
000072bd77dd0364  mov eax, 0x430950
000072bd77dd0369  movups [r13+rax*1], xmm1
000072bd77dd036f  mov eax, [r15+0x108]
000072bd77dd0376  sahf
000072bd77dd0377  jnz 0x000072BD77DD03A9
000072bd77dd0379  cmp dword ptr [r15+0x318], 0x00
000072bd77dd0381  jz 0x000072BD77DDB900
000072bd77dd0387  nop [rax+rax*1], ax
000072bd77dd0390  nop [rax+rax*1], eax
000072bd77dd0398  mov eax, 0x410444
000072bd77dd039d  mov [r15+0x100], rax
000072bd77dd03a4  jmp 0x000072BD77BFE110
000072bd77dd03a9  cmp dword ptr [r15+0x318], 0x00
000072bd77dd03b1  jz 0x000072BD77DD57E0
000072bd77dd03b7  nop [rax+rax*1], ax
000072bd77dd03c0  nop [rax+rax*1], eax
000072bd77dd03c8  mov eax, 0x410278
000072bd77dd03cd  mov [r15+0x100], rax
000072bd77dd03d4  jmp 0x000072BD77BFE110
000072bd77dd03d9  int3
000072bd77dd03da  call 0x000072BD77CB52F0
000072bd77dd03df  jmp 0x000072BD77DCF016
000072bd77dd03e4  call 0x000072BD77CC4620
000072bd77dd03e9  jmp 0x000072BD77DCF023
000072bd77dd03ee  call 0x000072BD77CC33A0
000072bd77dd03f3  jmp 0x000072BD77DCF035
000072bd77dd03f8  call 0x000072BD77CC2120
000072bd77dd03fd  jmp 0x000072BD77DCF03F
000072bd77dd0402  call 0x000072BD77CC0860
000072bd77dd0407  jmp 0x000072BD77DCF067
000072bd77dd040c  call 0x000072BD77CBF5F0
000072bd77dd0411  jmp 0x000072BD77DCF073
000072bd77dd0416  call 0x000072BD77CC0860
000072bd77dd041b  jmp 0x000072BD77DCF0A5
000072bd77dd0420  call 0x000072BD77CBF5F0
000072bd77dd0425  jmp 0x000072BD77DCF0B1
000072bd77dd042a  call 0x000072BD77CC4740
000072bd77dd042f  jmp 0x000072BD77DCF0BE
000072bd77dd0434  call 0x000072BD77CB5400
000072bd77dd0439  jmp 0x000072BD77DCF0CB
000072bd77dd043e  call 0x000072BD77CB52F0
000072bd77dd0443  jmp 0x000072BD77DCF0D8
000072bd77dd0448  call 0x000072BD77CC4620
000072bd77dd044d  jmp 0x000072BD77DCF0E5
000072bd77dd0452  call 0x000072BD77CC0860
000072bd77dd0457  jmp 0x000072BD77DCF10D
000072bd77dd045c  call 0x000072BD77CBF5F0
000072bd77dd0461  jmp 0x000072BD77DCF119
000072bd77dd0466  call 0x000072BD77C09D70
000072bd77dd046b  jmp 0x000072BD77DCF11F
000072bd77dd0470  call 0x000072BD77CBE9C0
000072bd77dd0475  jmp 0x000072BD77DCF129
000072bd77dd047a  call 0x000072BD77CC0860
000072bd77dd047f  jmp 0x000072BD77DCF151
000072bd77dd0484  call 0x000072BD77CBF5F0
000072bd77dd0489  jmp 0x000072BD77DCF15D
000072bd77dd048e  call 0x000072BD77CBD750
000072bd77dd0493  jmp 0x000072BD77DCF16A
000072bd77dd0498  call 0x000072BD77CBC4E0
000072bd77dd049d  jmp 0x000072BD77DCF177
000072bd77dd04a2  call 0x000072BD77CC4740
000072bd77dd04a7  jmp 0x000072BD77DCF184
000072bd77dd04ac  call 0x000072BD77CB5400
000072bd77dd04b1  jmp 0x000072BD77DCF191
000072bd77dd04b6  call 0x000072BD77CB52F0
000072bd77dd04bb  jmp 0x000072BD77DCF19E
000072bd77dd04c0  call 0x000072BD77CC4620
000072bd77dd04c5  jmp 0x000072BD77DCF1AB
000072bd77dd04ca  call 0x000072BD77CC0860
000072bd77dd04cf  jmp 0x000072BD77DCF1BE
000072bd77dd04d4  call 0x000072BD77CBB270
000072bd77dd04d9  jmp 0x000072BD77DCF1CB
000072bd77dd04de  call 0x000072BD77CBA000
000072bd77dd04e3  jmp 0x000072BD77DCF1D8
000072bd77dd04e8  call 0x000072BD77CB8D90
000072bd77dd04ed  jmp 0x000072BD77DCF1E5
000072bd77dd04f2  call 0x000072BD77CB8A20
000072bd77dd04f7  jmp 0x000072BD77DCF1F2
000072bd77dd04fc  call 0x000072BD77CB5400
000072bd77dd0501  jmp 0x000072BD77DCF1FC
000072bd77dd0506  call 0x000072BD77CC2240
000072bd77dd050b  jmp 0x000072BD77DCF206
000072bd77dd0510  call 0x000072BD77CB52F0
000072bd77dd0515  jmp 0x000072BD77DCF210
000072bd77dd051a  call 0x000072BD77CC2120
000072bd77dd051f  jmp 0x000072BD77DCF21A
000072bd77dd0524  call 0x000072BD77CB77B0
000072bd77dd0529  jmp 0x000072BD77DCF224
000072bd77dd052e  call 0x000072BD77CB6550
000072bd77dd0533  jmp 0x000072BD77DCF22E
000072bd77dd0538  call 0x000072BD77CBFD50
000072bd77dd053d  jmp 0x000072BD77DCF240
000072bd77dd0542  call 0x000072BD77CB8EA0
000072bd77dd0547  jmp 0x000072BD77DCF24A
000072bd77dd054c  call 0x000072BD77CBFC30
000072bd77dd0551  jmp 0x000072BD77DCF257
000072bd77dd0556  call 0x000072BD77CB8D90
000072bd77dd055b  jmp 0x000072BD77DCF264
000072bd77dd0560  call 0x000072BD77CC2240
000072bd77dd0565  jmp 0x000072BD77DCF271
000072bd77dd056a  call 0x000072BD77CB5400
000072bd77dd056f  jmp 0x000072BD77DCF27E
000072bd77dd0574  call 0x000072BD77CB52F0
000072bd77dd0579  jmp 0x000072BD77DCF28B
000072bd77dd057e  call 0x000072BD77CC2120
000072bd77dd0583  jmp 0x000072BD77DCF298
000072bd77dd0588  call 0x000072BD77CB52F0
000072bd77dd058d  jmp 0x000072BD77DCF2AB
000072bd77dd0592  call 0x000072BD77CB52F0
000072bd77dd0597  jmp 0x000072BD77DCF2BE
000072bd77dd059c  call 0x000072BD77CB52F0
000072bd77dd05a1  jmp 0x000072BD77DCF2D1
000072bd77dd05a6  call 0x000072BD77CB52F0
000072bd77dd05ab  jmp 0x000072BD77DCF2E4
000072bd77dd05b0  call 0x000072BD77CC2240
000072bd77dd05b5  jmp 0x000072BD77DCF2F9
000072bd77dd05ba  call 0x000072BD77CC2240
000072bd77dd05bf  jmp 0x000072BD77DCF30C
000072bd77dd05c4  call 0x000072BD77CC2120
000072bd77dd05c9  jmp 0x000072BD77DCF319
000072bd77dd05ce  call 0x000072BD77CB52F0
000072bd77dd05d3  jmp 0x000072BD77DCF32C
000072bd77dd05d8  call 0x000072BD77CB52F0
000072bd77dd05dd  jmp 0x000072BD77DCF34F
000072bd77dd05e2  call 0x000072BD77CB52F0
000072bd77dd05e7  jmp 0x000072BD77DCF362
000072bd77dd05ec  call 0x000072BD77BFF540
000072bd77dd05f1  jmp 0x000072BD77DCF380
000072bd77dd05f6  call 0x000072BD77C08C20
000072bd77dd05fb  jmp 0x000072BD77DCF38A
000072bd77dd0600  call 0x000072BD77CD6600
000072bd77dd0605  jmp 0x000072BD77DCF396
000072bd77dd060a  call 0x000072BD77BFF540
000072bd77dd060f  jmp 0x000072BD77DCF3A6
000072bd77dd0614  call 0x000072BD77CC0370
000072bd77dd0619  jmp 0x000072BD77DCF3D4
000072bd77dd061e  call 0x000072BD77CBF100
000072bd77dd0623  jmp 0x000072BD77DCF3DD
000072bd77dd0628  call 0x000072BD77CC0370
000072bd77dd062d  jmp 0x000072BD77DCF43B
000072bd77dd0632  call 0x000072BD77CBF100
000072bd77dd0637  jmp 0x000072BD77DCF444
000072bd77dd063c  call 0x000072BD77CC0370
000072bd77dd0641  jmp 0x000072BD77DCF48B
000072bd77dd0646  call 0x000072BD77CBF100
000072bd77dd064b  jmp 0x000072BD77DCF494
000072bd77dd0650  call 0x000072BD77C0B720
000072bd77dd0655  jmp 0x000072BD77DCF4D7
000072bd77dd065a  call 0x000072BD77CB47C0
000072bd77dd065f  jmp 0x000072BD77DCF4EA
000072bd77dd0664  call 0x000072BD77C08B00
000072bd77dd0669  jmp 0x000072BD77DCF501
000072bd77dd066e  call 0x000072BD77BFF430
000072bd77dd0673  jmp 0x000072BD77DCF514
000072bd77dd0678  call 0x000072BD77BFF430
000072bd77dd067d  jmp 0x000072BD77DCF527
000072bd77dd0682  sub rsp, 0x08
000072bd77dd0686  push rax
000072bd77dd0687  push rcx
000072bd77dd0688  push rdx
000072bd77dd0689  push rdi
000072bd77dd068a  push rsi
000072bd77dd068b  push r8
000072bd77dd068d  push r9
000072bd77dd068f  push r10
000072bd77dd0691  push r11
000072bd77dd0693  sub rsp, 0xF0
000072bd77dd069a  vmovaps [rsp], xmm0
000072bd77dd069f  vmovaps [rsp+0x10], xmm2
000072bd77dd06a5  vmovaps [rsp+0x20], xmm3
000072bd77dd06ab  vmovaps [rsp+0x30], xmm4
000072bd77dd06b1  vmovaps [rsp+0x40], xmm5
000072bd77dd06b7  vmovaps [rsp+0x50], xmm6
000072bd77dd06bd  vmovaps [rsp+0x60], xmm7
000072bd77dd06c3  vmovaps [rsp+0x70], xmm8
000072bd77dd06c9  vmovaps [rsp+0x80], xmm9
000072bd77dd06d2  vmovaps [rsp+0x90], xmm10
000072bd77dd06db  vmovaps [rsp+0xA0], xmm11
000072bd77dd06e4  vmovaps [rsp+0xB0], xmm12
000072bd77dd06ed  vmovaps [rsp+0xC0], xmm13
000072bd77dd06f6  vmovaps [rsp+0xD0], xmm14
000072bd77dd06ff  vmovaps [rsp+0xE0], xmm15
000072bd77dd0708  sub rsp, 0x30
000072bd77dd070c  movaps [rsp], xmm1
000072bd77dd0710  movaps [rsp+0x10], xmm15
000072bd77dd0716  movaps [rsp+0x20], xmm14
000072bd77dd071c  lea rdi, [rsp]
000072bd77dd0720  mov esi, 0x00
000072bd77dd0725  mov rax, 0x643206AC3530
000072bd77dd072f  call rax
000072bd77dd0731  movaps xmm1, [rsp]
000072bd77dd0735  add rsp, 0x30
000072bd77dd0739  vmovaps xmm0, [rsp]
000072bd77dd073e  vmovaps xmm2, [rsp+0x10]
000072bd77dd0744  vmovaps xmm3, [rsp+0x20]
000072bd77dd074a  vmovaps xmm4, [rsp+0x30]
000072bd77dd0750  vmovaps xmm5, [rsp+0x40]
000072bd77dd0756  vmovaps xmm6, [rsp+0x50]
000072bd77dd075c  vmovaps xmm7, [rsp+0x60]
000072bd77dd0762  vmovaps xmm8, [rsp+0x70]
000072bd77dd0768  vmovaps xmm9, [rsp+0x80]
000072bd77dd0771  vmovaps xmm10, [rsp+0x90]
000072bd77dd077a  vmovaps xmm11, [rsp+0xA0]
000072bd77dd0783  vmovaps xmm12, [rsp+0xB0]
000072bd77dd078c  vmovaps xmm13, [rsp+0xC0]
000072bd77dd0795  vmovaps xmm14, [rsp+0xD0]
000072bd77dd079e  vmovaps xmm15, [rsp+0xE0]
000072bd77dd07a7  add rsp, 0xF0
000072bd77dd07ae  pop r11
000072bd77dd07b0  pop r10
000072bd77dd07b2  pop r9
000072bd77dd07b4  pop r8
000072bd77dd07b6  pop rsi
000072bd77dd07b7  pop rdi
000072bd77dd07b8  pop rdx
000072bd77dd07b9  pop rcx
000072bd77dd07ba  pop rax
000072bd77dd07bb  add rsp, 0x08
000072bd77dd07bf  jmp 0x000072BD77DCF581
000072bd77dd07c4  sub rsp, 0x08
000072bd77dd07c8  push rax
000072bd77dd07c9  push rcx
000072bd77dd07ca  push rdx
000072bd77dd07cb  push rdi
000072bd77dd07cc  push rsi
000072bd77dd07cd  push r8
000072bd77dd07cf  push r9
000072bd77dd07d1  push r10
000072bd77dd07d3  push r11
000072bd77dd07d5  sub rsp, 0xF0
000072bd77dd07dc  vmovaps [rsp], xmm0
000072bd77dd07e1  vmovaps [rsp+0x10], xmm1
000072bd77dd07e7  vmovaps [rsp+0x20], xmm2
000072bd77dd07ed  vmovaps [rsp+0x30], xmm3
000072bd77dd07f3  vmovaps [rsp+0x40], xmm4
000072bd77dd07f9  vmovaps [rsp+0x50], xmm5
000072bd77dd07ff  vmovaps [rsp+0x60], xmm6
000072bd77dd0805  vmovaps [rsp+0x70], xmm7
000072bd77dd080b  vmovaps [rsp+0x80], xmm8
000072bd77dd0814  vmovaps [rsp+0x90], xmm9
000072bd77dd081d  vmovaps [rsp+0xA0], xmm10
000072bd77dd0826  vmovaps [rsp+0xB0], xmm11
000072bd77dd082f  vmovaps [rsp+0xC0], xmm12
000072bd77dd0838  vmovaps [rsp+0xD0], xmm14
000072bd77dd0841  vmovaps [rsp+0xE0], xmm15
000072bd77dd084a  sub rsp, 0x30
000072bd77dd084e  movaps [rsp], xmm13
000072bd77dd0853  movaps [rsp+0x10], xmm1
000072bd77dd0858  movaps [rsp+0x20], xmm14
000072bd77dd085e  lea rdi, [rsp]
000072bd77dd0862  mov esi, 0x00
000072bd77dd0867  mov rax, 0x643206AC3530
000072bd77dd0871  call rax
000072bd77dd0873  movaps xmm13, [rsp]
000072bd77dd0878  add rsp, 0x30
000072bd77dd087c  vmovaps xmm0, [rsp]
000072bd77dd0881  vmovaps xmm1, [rsp+0x10]
000072bd77dd0887  vmovaps xmm2, [rsp+0x20]
000072bd77dd088d  vmovaps xmm3, [rsp+0x30]
000072bd77dd0893  vmovaps xmm4, [rsp+0x40]
000072bd77dd0899  vmovaps xmm5, [rsp+0x50]
000072bd77dd089f  vmovaps xmm6, [rsp+0x60]
000072bd77dd08a5  vmovaps xmm7, [rsp+0x70]
000072bd77dd08ab  vmovaps xmm8, [rsp+0x80]
000072bd77dd08b4  vmovaps xmm9, [rsp+0x90]
000072bd77dd08bd  vmovaps xmm10, [rsp+0xA0]
000072bd77dd08c6  vmovaps xmm11, [rsp+0xB0]
000072bd77dd08cf  vmovaps xmm12, [rsp+0xC0]
000072bd77dd08d8  vmovaps xmm14, [rsp+0xD0]
000072bd77dd08e1  vmovaps xmm15, [rsp+0xE0]
000072bd77dd08ea  add rsp, 0xF0
000072bd77dd08f1  pop r11
000072bd77dd08f3  pop r10
000072bd77dd08f5  pop r9
000072bd77dd08f7  pop r8
000072bd77dd08f9  pop rsi
000072bd77dd08fa  pop rdi
000072bd77dd08fb  pop rdx
000072bd77dd08fc  pop rcx
000072bd77dd08fd  pop rax
000072bd77dd08fe  add rsp, 0x08
000072bd77dd0902  jmp 0x000072BD77DCF5CF
000072bd77dd0907  sub rsp, 0x08
000072bd77dd090b  push rax
000072bd77dd090c  push rcx
000072bd77dd090d  push rdx
000072bd77dd090e  push rdi
000072bd77dd090f  push rsi
000072bd77dd0910  push r8
000072bd77dd0912  push r9
000072bd77dd0914  push r10
000072bd77dd0916  push r11
000072bd77dd0918  sub rsp, 0xF0
000072bd77dd091f  vmovaps [rsp], xmm0
000072bd77dd0924  vmovaps [rsp+0x10], xmm1
000072bd77dd092a  vmovaps [rsp+0x20], xmm2
000072bd77dd0930  vmovaps [rsp+0x30], xmm3
000072bd77dd0936  vmovaps [rsp+0x40], xmm4
000072bd77dd093c  vmovaps [rsp+0x50], xmm5
000072bd77dd0942  vmovaps [rsp+0x60], xmm6
000072bd77dd0948  vmovaps [rsp+0x70], xmm7
000072bd77dd094e  vmovaps [rsp+0x80], xmm8
000072bd77dd0957  vmovaps [rsp+0x90], xmm9
000072bd77dd0960  vmovaps [rsp+0xA0], xmm10
000072bd77dd0969  vmovaps [rsp+0xB0], xmm11
000072bd77dd0972  vmovaps [rsp+0xC0], xmm12
000072bd77dd097b  vmovaps [rsp+0xD0], xmm13
000072bd77dd0984  vmovaps [rsp+0xE0], xmm14
000072bd77dd098d  sub rsp, 0x30
000072bd77dd0991  movaps [rsp], xmm15
000072bd77dd0996  movaps [rsp+0x10], xmm14
000072bd77dd099c  movaps [rsp+0x20], xmm1
000072bd77dd09a1  lea rdi, [rsp]
000072bd77dd09a5  mov esi, 0x00
000072bd77dd09aa  mov rax, 0x643206AC3530
000072bd77dd09b4  call rax
000072bd77dd09b6  movaps xmm15, [rsp]
000072bd77dd09bb  add rsp, 0x30
000072bd77dd09bf  vmovaps xmm0, [rsp]
000072bd77dd09c4  vmovaps xmm1, [rsp+0x10]
000072bd77dd09ca  vmovaps xmm2, [rsp+0x20]
000072bd77dd09d0  vmovaps xmm3, [rsp+0x30]
000072bd77dd09d6  vmovaps xmm4, [rsp+0x40]
000072bd77dd09dc  vmovaps xmm5, [rsp+0x50]
000072bd77dd09e2  vmovaps xmm6, [rsp+0x60]
000072bd77dd09e8  vmovaps xmm7, [rsp+0x70]
000072bd77dd09ee  vmovaps xmm8, [rsp+0x80]
000072bd77dd09f7  vmovaps xmm9, [rsp+0x90]
000072bd77dd0a00  vmovaps xmm10, [rsp+0xA0]
000072bd77dd0a09  vmovaps xmm11, [rsp+0xB0]
000072bd77dd0a12  vmovaps xmm12, [rsp+0xC0]
000072bd77dd0a1b  vmovaps xmm13, [rsp+0xD0]
000072bd77dd0a24  vmovaps xmm14, [rsp+0xE0]
000072bd77dd0a2d  add rsp, 0xF0
000072bd77dd0a34  pop r11
000072bd77dd0a36  pop r10
000072bd77dd0a38  pop r9
000072bd77dd0a3a  pop r8
000072bd77dd0a3c  pop rsi
000072bd77dd0a3d  pop rdi
000072bd77dd0a3e  pop rdx
000072bd77dd0a3f  pop rcx
000072bd77dd0a40  pop rax
000072bd77dd0a41  add rsp, 0x08
000072bd77dd0a45  jmp 0x000072BD77DCF617
000072bd77dd0a4a  sub rsp, 0x08
000072bd77dd0a4e  push rax
000072bd77dd0a4f  push rcx
000072bd77dd0a50  push rdx
000072bd77dd0a51  push rdi
000072bd77dd0a52  push rsi
000072bd77dd0a53  push r8
000072bd77dd0a55  push r9
000072bd77dd0a57  push r10
000072bd77dd0a59  push r11
000072bd77dd0a5b  sub rsp, 0xF0
000072bd77dd0a62  vmovaps [rsp], xmm0
000072bd77dd0a67  vmovaps [rsp+0x10], xmm2
000072bd77dd0a6d  vmovaps [rsp+0x20], xmm3
000072bd77dd0a73  vmovaps [rsp+0x30], xmm4
000072bd77dd0a79  vmovaps [rsp+0x40], xmm5
000072bd77dd0a7f  vmovaps [rsp+0x50], xmm6
000072bd77dd0a85  vmovaps [rsp+0x60], xmm7
000072bd77dd0a8b  vmovaps [rsp+0x70], xmm8
000072bd77dd0a91  vmovaps [rsp+0x80], xmm9
000072bd77dd0a9a  vmovaps [rsp+0x90], xmm10
000072bd77dd0aa3  vmovaps [rsp+0xA0], xmm11
000072bd77dd0aac  vmovaps [rsp+0xB0], xmm12
000072bd77dd0ab5  vmovaps [rsp+0xC0], xmm13
000072bd77dd0abe  vmovaps [rsp+0xD0], xmm14
000072bd77dd0ac7  vmovaps [rsp+0xE0], xmm15
000072bd77dd0ad0  sub rsp, 0x30
000072bd77dd0ad4  movaps [rsp], xmm1
000072bd77dd0ad8  movaps [rsp+0x10], xmm14
000072bd77dd0ade  movaps [rsp+0x20], xmm10
000072bd77dd0ae4  lea rdi, [rsp]
000072bd77dd0ae8  mov esi, 0x00
000072bd77dd0aed  mov rax, 0x643206AC3530
000072bd77dd0af7  call rax
000072bd77dd0af9  movaps xmm1, [rsp]
000072bd77dd0afd  add rsp, 0x30
000072bd77dd0b01  vmovaps xmm0, [rsp]
000072bd77dd0b06  vmovaps xmm2, [rsp+0x10]
000072bd77dd0b0c  vmovaps xmm3, [rsp+0x20]
000072bd77dd0b12  vmovaps xmm4, [rsp+0x30]
000072bd77dd0b18  vmovaps xmm5, [rsp+0x40]
000072bd77dd0b1e  vmovaps xmm6, [rsp+0x50]
000072bd77dd0b24  vmovaps xmm7, [rsp+0x60]
000072bd77dd0b2a  vmovaps xmm8, [rsp+0x70]
000072bd77dd0b30  vmovaps xmm9, [rsp+0x80]
000072bd77dd0b39  vmovaps xmm10, [rsp+0x90]
000072bd77dd0b42  vmovaps xmm11, [rsp+0xA0]
000072bd77dd0b4b  vmovaps xmm12, [rsp+0xB0]
000072bd77dd0b54  vmovaps xmm13, [rsp+0xC0]
000072bd77dd0b5d  vmovaps xmm14, [rsp+0xD0]
000072bd77dd0b66  vmovaps xmm15, [rsp+0xE0]
000072bd77dd0b6f  add rsp, 0xF0
000072bd77dd0b76  pop r11
000072bd77dd0b78  pop r10
000072bd77dd0b7a  pop r9
000072bd77dd0b7c  pop r8
000072bd77dd0b7e  pop rsi
000072bd77dd0b7f  pop rdi
000072bd77dd0b80  pop rdx
000072bd77dd0b81  pop rcx
000072bd77dd0b82  pop rax
000072bd77dd0b83  add rsp, 0x08
000072bd77dd0b87  jmp 0x000072BD77DCF631
000072bd77dd0b8c  sub rsp, 0x08
000072bd77dd0b90  push rax
000072bd77dd0b91  push rcx
000072bd77dd0b92  push rdx
000072bd77dd0b93  push rdi
000072bd77dd0b94  push rsi
000072bd77dd0b95  push r8
000072bd77dd0b97  push r9
000072bd77dd0b99  push r10
000072bd77dd0b9b  push r11
000072bd77dd0b9d  sub rsp, 0xF0
000072bd77dd0ba4  vmovaps [rsp], xmm0
000072bd77dd0ba9  vmovaps [rsp+0x10], xmm1
000072bd77dd0baf  vmovaps [rsp+0x20], xmm2
000072bd77dd0bb5  vmovaps [rsp+0x30], xmm3
000072bd77dd0bbb  vmovaps [rsp+0x40], xmm4
000072bd77dd0bc1  vmovaps [rsp+0x50], xmm5
000072bd77dd0bc7  vmovaps [rsp+0x60], xmm6
000072bd77dd0bcd  vmovaps [rsp+0x70], xmm7
000072bd77dd0bd3  vmovaps [rsp+0x80], xmm8
000072bd77dd0bdc  vmovaps [rsp+0x90], xmm9
000072bd77dd0be5  vmovaps [rsp+0xA0], xmm10
000072bd77dd0bee  vmovaps [rsp+0xB0], xmm11
000072bd77dd0bf7  vmovaps [rsp+0xC0], xmm12
000072bd77dd0c00  vmovaps [rsp+0xD0], xmm14
000072bd77dd0c09  vmovaps [rsp+0xE0], xmm15
000072bd77dd0c12  sub rsp, 0x30
000072bd77dd0c16  movaps [rsp], xmm13
000072bd77dd0c1b  movaps [rsp+0x10], xmm14
000072bd77dd0c21  movaps [rsp+0x20], xmm2
000072bd77dd0c26  lea rdi, [rsp]
000072bd77dd0c2a  mov esi, 0x00
000072bd77dd0c2f  mov rax, 0x643206AC3530
000072bd77dd0c39  call rax
000072bd77dd0c3b  movaps xmm13, [rsp]
000072bd77dd0c40  add rsp, 0x30
000072bd77dd0c44  vmovaps xmm0, [rsp]
000072bd77dd0c49  vmovaps xmm1, [rsp+0x10]
000072bd77dd0c4f  vmovaps xmm2, [rsp+0x20]
000072bd77dd0c55  vmovaps xmm3, [rsp+0x30]
000072bd77dd0c5b  vmovaps xmm4, [rsp+0x40]
000072bd77dd0c61  vmovaps xmm5, [rsp+0x50]
000072bd77dd0c67  vmovaps xmm6, [rsp+0x60]
000072bd77dd0c6d  vmovaps xmm7, [rsp+0x70]
000072bd77dd0c73  vmovaps xmm8, [rsp+0x80]
000072bd77dd0c7c  vmovaps xmm9, [rsp+0x90]
000072bd77dd0c85  vmovaps xmm10, [rsp+0xA0]
000072bd77dd0c8e  vmovaps xmm11, [rsp+0xB0]
000072bd77dd0c97  vmovaps xmm12, [rsp+0xC0]
000072bd77dd0ca0  vmovaps xmm14, [rsp+0xD0]
000072bd77dd0ca9  vmovaps xmm15, [rsp+0xE0]
000072bd77dd0cb2  add rsp, 0xF0
000072bd77dd0cb9  pop r11
000072bd77dd0cbb  pop r10
000072bd77dd0cbd  pop r9
000072bd77dd0cbf  pop r8
000072bd77dd0cc1  pop rsi
000072bd77dd0cc2  pop rdi
000072bd77dd0cc3  pop rdx
000072bd77dd0cc4  pop rcx
000072bd77dd0cc5  pop rax
000072bd77dd0cc6  add rsp, 0x08
000072bd77dd0cca  jmp 0x000072BD77DCF64C
000072bd77dd0ccf  sub rsp, 0x08
000072bd77dd0cd3  push rax
000072bd77dd0cd4  push rcx
000072bd77dd0cd5  push rdx
000072bd77dd0cd6  push rdi
000072bd77dd0cd7  push rsi
000072bd77dd0cd8  push r8
000072bd77dd0cda  push r9
000072bd77dd0cdc  push r10
000072bd77dd0cde  push r11
000072bd77dd0ce0  sub rsp, 0xF0
000072bd77dd0ce7  vmovaps [rsp], xmm0
000072bd77dd0cec  vmovaps [rsp+0x10], xmm2
000072bd77dd0cf2  vmovaps [rsp+0x20], xmm3
000072bd77dd0cf8  vmovaps [rsp+0x30], xmm4
000072bd77dd0cfe  vmovaps [rsp+0x40], xmm5
000072bd77dd0d04  vmovaps [rsp+0x50], xmm6
000072bd77dd0d0a  vmovaps [rsp+0x60], xmm7
000072bd77dd0d10  vmovaps [rsp+0x70], xmm8
000072bd77dd0d16  vmovaps [rsp+0x80], xmm9
000072bd77dd0d1f  vmovaps [rsp+0x90], xmm10
000072bd77dd0d28  vmovaps [rsp+0xA0], xmm11
000072bd77dd0d31  vmovaps [rsp+0xB0], xmm12
000072bd77dd0d3a  vmovaps [rsp+0xC0], xmm13
000072bd77dd0d43  vmovaps [rsp+0xD0], xmm14
000072bd77dd0d4c  vmovaps [rsp+0xE0], xmm15
000072bd77dd0d55  sub rsp, 0x30
000072bd77dd0d59  movaps [rsp], xmm1
000072bd77dd0d5d  movaps [rsp+0x10], xmm10
000072bd77dd0d63  movaps [rsp+0x20], xmm2
000072bd77dd0d68  lea rdi, [rsp]
000072bd77dd0d6c  mov esi, 0x00
000072bd77dd0d71  mov rax, 0x643206AC3530
000072bd77dd0d7b  call rax
000072bd77dd0d7d  movaps xmm1, [rsp]
000072bd77dd0d81  add rsp, 0x30
000072bd77dd0d85  vmovaps xmm0, [rsp]
000072bd77dd0d8a  vmovaps xmm2, [rsp+0x10]
000072bd77dd0d90  vmovaps xmm3, [rsp+0x20]
000072bd77dd0d96  vmovaps xmm4, [rsp+0x30]
000072bd77dd0d9c  vmovaps xmm5, [rsp+0x40]
000072bd77dd0da2  vmovaps xmm6, [rsp+0x50]
000072bd77dd0da8  vmovaps xmm7, [rsp+0x60]
000072bd77dd0dae  vmovaps xmm8, [rsp+0x70]
000072bd77dd0db4  vmovaps xmm9, [rsp+0x80]
000072bd77dd0dbd  vmovaps xmm10, [rsp+0x90]
000072bd77dd0dc6  vmovaps xmm11, [rsp+0xA0]
000072bd77dd0dcf  vmovaps xmm12, [rsp+0xB0]
000072bd77dd0dd8  vmovaps xmm13, [rsp+0xC0]
000072bd77dd0de1  vmovaps xmm14, [rsp+0xD0]
000072bd77dd0dea  vmovaps xmm15, [rsp+0xE0]
000072bd77dd0df3  add rsp, 0xF0
000072bd77dd0dfa  pop r11
000072bd77dd0dfc  pop r10
000072bd77dd0dfe  pop r9
000072bd77dd0e00  pop r8
000072bd77dd0e02  pop rsi
000072bd77dd0e03  pop rdi
000072bd77dd0e04  pop rdx
000072bd77dd0e05  pop rcx
000072bd77dd0e06  pop rax
000072bd77dd0e07  add rsp, 0x08
000072bd77dd0e0b  jmp 0x000072BD77DCF6B4
000072bd77dd0e10  sub rsp, 0x08
000072bd77dd0e14  push rax
000072bd77dd0e15  push rcx
000072bd77dd0e16  push rdx
000072bd77dd0e17  push rdi
000072bd77dd0e18  push rsi
000072bd77dd0e19  push r8
000072bd77dd0e1b  push r9
000072bd77dd0e1d  push r10
000072bd77dd0e1f  push r11
000072bd77dd0e21  sub rsp, 0xF0
000072bd77dd0e28  vmovaps [rsp], xmm0
000072bd77dd0e2d  vmovaps [rsp+0x10], xmm1
000072bd77dd0e33  vmovaps [rsp+0x20], xmm2
000072bd77dd0e39  vmovaps [rsp+0x30], xmm3
000072bd77dd0e3f  vmovaps [rsp+0x40], xmm4
000072bd77dd0e45  vmovaps [rsp+0x50], xmm5
000072bd77dd0e4b  vmovaps [rsp+0x60], xmm6
000072bd77dd0e51  vmovaps [rsp+0x70], xmm7
000072bd77dd0e57  vmovaps [rsp+0x80], xmm8
000072bd77dd0e60  vmovaps [rsp+0x90], xmm9
000072bd77dd0e69  vmovaps [rsp+0xA0], xmm10
000072bd77dd0e72  vmovaps [rsp+0xB0], xmm11
000072bd77dd0e7b  vmovaps [rsp+0xC0], xmm12
000072bd77dd0e84  vmovaps [rsp+0xD0], xmm13
000072bd77dd0e8d  vmovaps [rsp+0xE0], xmm14
000072bd77dd0e96  sub rsp, 0x30
000072bd77dd0e9a  movaps [rsp], xmm15
000072bd77dd0e9f  movaps [rsp+0x10], xmm10
000072bd77dd0ea5  movaps [rsp+0x20], xmm2
000072bd77dd0eaa  lea rdi, [rsp]
000072bd77dd0eae  mov esi, 0x00
000072bd77dd0eb3  mov rax, 0x643206AC3530
000072bd77dd0ebd  call rax
000072bd77dd0ebf  movaps xmm15, [rsp]
000072bd77dd0ec4  add rsp, 0x30
000072bd77dd0ec8  vmovaps xmm0, [rsp]
000072bd77dd0ecd  vmovaps xmm1, [rsp+0x10]
000072bd77dd0ed3  vmovaps xmm2, [rsp+0x20]
000072bd77dd0ed9  vmovaps xmm3, [rsp+0x30]
000072bd77dd0edf  vmovaps xmm4, [rsp+0x40]
000072bd77dd0ee5  vmovaps xmm5, [rsp+0x50]
000072bd77dd0eeb  vmovaps xmm6, [rsp+0x60]
000072bd77dd0ef1  vmovaps xmm7, [rsp+0x70]
000072bd77dd0ef7  vmovaps xmm8, [rsp+0x80]
000072bd77dd0f00  vmovaps xmm9, [rsp+0x90]
000072bd77dd0f09  vmovaps xmm10, [rsp+0xA0]
000072bd77dd0f12  vmovaps xmm11, [rsp+0xB0]
000072bd77dd0f1b  vmovaps xmm12, [rsp+0xC0]
000072bd77dd0f24  vmovaps xmm13, [rsp+0xD0]
000072bd77dd0f2d  vmovaps xmm14, [rsp+0xE0]
000072bd77dd0f36  add rsp, 0xF0
000072bd77dd0f3d  pop r11
000072bd77dd0f3f  pop r10
000072bd77dd0f41  pop r9
000072bd77dd0f43  pop r8
000072bd77dd0f45  pop rsi
000072bd77dd0f46  pop rdi
000072bd77dd0f47  pop rdx
000072bd77dd0f48  pop rcx
000072bd77dd0f49  pop rax
000072bd77dd0f4a  add rsp, 0x08
000072bd77dd0f4e  jmp 0x000072BD77DCF706
000072bd77dd0f53  sub rsp, 0x08
000072bd77dd0f57  push rax
000072bd77dd0f58  push rcx
000072bd77dd0f59  push rdx
000072bd77dd0f5a  push rdi
000072bd77dd0f5b  push rsi
000072bd77dd0f5c  push r8
000072bd77dd0f5e  push r9
000072bd77dd0f60  push r10
000072bd77dd0f62  push r11
000072bd77dd0f64  sub rsp, 0xF0
000072bd77dd0f6b  vmovaps [rsp], xmm0
000072bd77dd0f70  vmovaps [rsp+0x10], xmm2
000072bd77dd0f76  vmovaps [rsp+0x20], xmm3
000072bd77dd0f7c  vmovaps [rsp+0x30], xmm4
000072bd77dd0f82  vmovaps [rsp+0x40], xmm5
000072bd77dd0f88  vmovaps [rsp+0x50], xmm6
000072bd77dd0f8e  vmovaps [rsp+0x60], xmm7
000072bd77dd0f94  vmovaps [rsp+0x70], xmm8
000072bd77dd0f9a  vmovaps [rsp+0x80], xmm9
000072bd77dd0fa3  vmovaps [rsp+0x90], xmm10
000072bd77dd0fac  vmovaps [rsp+0xA0], xmm11
000072bd77dd0fb5  vmovaps [rsp+0xB0], xmm12
000072bd77dd0fbe  vmovaps [rsp+0xC0], xmm13
000072bd77dd0fc7  vmovaps [rsp+0xD0], xmm14
000072bd77dd0fd0  vmovaps [rsp+0xE0], xmm15
000072bd77dd0fd9  sub rsp, 0x30
000072bd77dd0fdd  movaps [rsp], xmm1
000072bd77dd0fe1  movaps [rsp+0x10], xmm10
000072bd77dd0fe7  movaps [rsp+0x20], xmm12
000072bd77dd0fed  lea rdi, [rsp]
000072bd77dd0ff1  mov esi, 0x00
000072bd77dd0ff6  mov rax, 0x643206AC3530
000072bd77dd1000  call rax
000072bd77dd1002  movaps xmm1, [rsp]
000072bd77dd1006  add rsp, 0x30
000072bd77dd100a  vmovaps xmm0, [rsp]
000072bd77dd100f  vmovaps xmm2, [rsp+0x10]
000072bd77dd1015  vmovaps xmm3, [rsp+0x20]
000072bd77dd101b  vmovaps xmm4, [rsp+0x30]
000072bd77dd1021  vmovaps xmm5, [rsp+0x40]
000072bd77dd1027  vmovaps xmm6, [rsp+0x50]
000072bd77dd102d  vmovaps xmm7, [rsp+0x60]
000072bd77dd1033  vmovaps xmm8, [rsp+0x70]
000072bd77dd1039  vmovaps xmm9, [rsp+0x80]
000072bd77dd1042  vmovaps xmm10, [rsp+0x90]
000072bd77dd104b  vmovaps xmm11, [rsp+0xA0]
000072bd77dd1054  vmovaps xmm12, [rsp+0xB0]
000072bd77dd105d  vmovaps xmm13, [rsp+0xC0]
000072bd77dd1066  vmovaps xmm14, [rsp+0xD0]
000072bd77dd106f  vmovaps xmm15, [rsp+0xE0]
000072bd77dd1078  add rsp, 0xF0
000072bd77dd107f  pop r11
000072bd77dd1081  pop r10
000072bd77dd1083  pop r9
000072bd77dd1085  pop r8
000072bd77dd1087  pop rsi
000072bd77dd1088  pop rdi
000072bd77dd1089  pop rdx
000072bd77dd108a  pop rcx
000072bd77dd108b  pop rax
000072bd77dd108c  add rsp, 0x08
000072bd77dd1090  jmp 0x000072BD77DCF732
000072bd77dd1095  sub rsp, 0x08
000072bd77dd1099  push rax
000072bd77dd109a  push rcx
000072bd77dd109b  push rdx
000072bd77dd109c  push rdi
000072bd77dd109d  push rsi
000072bd77dd109e  push r8
000072bd77dd10a0  push r9
000072bd77dd10a2  push r10
000072bd77dd10a4  push r11
000072bd77dd10a6  sub rsp, 0xF0
000072bd77dd10ad  vmovaps [rsp], xmm0
000072bd77dd10b2  vmovaps [rsp+0x10], xmm1
000072bd77dd10b8  vmovaps [rsp+0x20], xmm2
000072bd77dd10be  vmovaps [rsp+0x30], xmm3
000072bd77dd10c4  vmovaps [rsp+0x40], xmm4
000072bd77dd10ca  vmovaps [rsp+0x50], xmm5
000072bd77dd10d0  vmovaps [rsp+0x60], xmm6
000072bd77dd10d6  vmovaps [rsp+0x70], xmm7
000072bd77dd10dc  vmovaps [rsp+0x80], xmm8
000072bd77dd10e5  vmovaps [rsp+0x90], xmm9
000072bd77dd10ee  vmovaps [rsp+0xA0], xmm10
000072bd77dd10f7  vmovaps [rsp+0xB0], xmm11
000072bd77dd1100  vmovaps [rsp+0xC0], xmm12
000072bd77dd1109  vmovaps [rsp+0xD0], xmm13
000072bd77dd1112  vmovaps [rsp+0xE0], xmm14
000072bd77dd111b  sub rsp, 0x30
000072bd77dd111f  movaps [rsp], xmm15
000072bd77dd1124  movaps [rsp+0x10], xmm10
000072bd77dd112a  movaps [rsp+0x20], xmm12
000072bd77dd1130  lea rdi, [rsp]
000072bd77dd1134  mov esi, 0x00
000072bd77dd1139  mov rax, 0x643206AC3530
000072bd77dd1143  call rax
000072bd77dd1145  movaps xmm15, [rsp]
000072bd77dd114a  add rsp, 0x30
000072bd77dd114e  vmovaps xmm0, [rsp]
000072bd77dd1153  vmovaps xmm1, [rsp+0x10]
000072bd77dd1159  vmovaps xmm2, [rsp+0x20]
000072bd77dd115f  vmovaps xmm3, [rsp+0x30]
000072bd77dd1165  vmovaps xmm4, [rsp+0x40]
000072bd77dd116b  vmovaps xmm5, [rsp+0x50]
000072bd77dd1171  vmovaps xmm6, [rsp+0x60]
000072bd77dd1177  vmovaps xmm7, [rsp+0x70]
000072bd77dd117d  vmovaps xmm8, [rsp+0x80]
000072bd77dd1186  vmovaps xmm9, [rsp+0x90]
000072bd77dd118f  vmovaps xmm10, [rsp+0xA0]
000072bd77dd1198  vmovaps xmm11, [rsp+0xB0]
000072bd77dd11a1  vmovaps xmm12, [rsp+0xC0]
000072bd77dd11aa  vmovaps xmm13, [rsp+0xD0]
000072bd77dd11b3  vmovaps xmm14, [rsp+0xE0]
000072bd77dd11bc  add rsp, 0xF0
000072bd77dd11c3  pop r11
000072bd77dd11c5  pop r10
000072bd77dd11c7  pop r9
000072bd77dd11c9  pop r8
000072bd77dd11cb  pop rsi
000072bd77dd11cc  pop rdi
000072bd77dd11cd  pop rdx
000072bd77dd11ce  pop rcx
000072bd77dd11cf  pop rax
000072bd77dd11d0  add rsp, 0x08
000072bd77dd11d4  jmp 0x000072BD77DCF75E
000072bd77dd11d9  call 0x000072BD77BFF430
000072bd77dd11de  jmp 0x000072BD77DCF7EE
000072bd77dd11e3  call 0x000072BD77BFF430
000072bd77dd11e8  jmp 0x000072BD77DCF801
000072bd77dd11ed  sub rsp, 0x08
000072bd77dd11f1  push rax
000072bd77dd11f2  push rcx
000072bd77dd11f3  push rdx
000072bd77dd11f4  push rdi
000072bd77dd11f5  push rsi
000072bd77dd11f6  push r8
000072bd77dd11f8  push r9
000072bd77dd11fa  push r10
000072bd77dd11fc  push r11
000072bd77dd11fe  sub rsp, 0xF0
000072bd77dd1205  vmovaps [rsp], xmm0
000072bd77dd120a  vmovaps [rsp+0x10], xmm2
000072bd77dd1210  vmovaps [rsp+0x20], xmm3
000072bd77dd1216  vmovaps [rsp+0x30], xmm4
000072bd77dd121c  vmovaps [rsp+0x40], xmm5
000072bd77dd1222  vmovaps [rsp+0x50], xmm6
000072bd77dd1228  vmovaps [rsp+0x60], xmm7
000072bd77dd122e  vmovaps [rsp+0x70], xmm8
000072bd77dd1234  vmovaps [rsp+0x80], xmm9
000072bd77dd123d  vmovaps [rsp+0x90], xmm10
000072bd77dd1246  vmovaps [rsp+0xA0], xmm11
000072bd77dd124f  vmovaps [rsp+0xB0], xmm12
000072bd77dd1258  vmovaps [rsp+0xC0], xmm13
000072bd77dd1261  vmovaps [rsp+0xD0], xmm14
000072bd77dd126a  vmovaps [rsp+0xE0], xmm15
000072bd77dd1273  sub rsp, 0x30
000072bd77dd1277  movaps [rsp], xmm1
000072bd77dd127b  movaps [rsp+0x10], xmm13
000072bd77dd1281  movaps [rsp+0x20], xmm2
000072bd77dd1286  lea rdi, [rsp]
000072bd77dd128a  mov esi, 0x00
000072bd77dd128f  mov rax, 0x643206AC3530
000072bd77dd1299  call rax
000072bd77dd129b  movaps xmm1, [rsp]
000072bd77dd129f  add rsp, 0x30
000072bd77dd12a3  vmovaps xmm0, [rsp]
000072bd77dd12a8  vmovaps xmm2, [rsp+0x10]
000072bd77dd12ae  vmovaps xmm3, [rsp+0x20]
000072bd77dd12b4  vmovaps xmm4, [rsp+0x30]
000072bd77dd12ba  vmovaps xmm5, [rsp+0x40]
000072bd77dd12c0  vmovaps xmm6, [rsp+0x50]
000072bd77dd12c6  vmovaps xmm7, [rsp+0x60]
000072bd77dd12cc  vmovaps xmm8, [rsp+0x70]
000072bd77dd12d2  vmovaps xmm9, [rsp+0x80]
000072bd77dd12db  vmovaps xmm10, [rsp+0x90]
000072bd77dd12e4  vmovaps xmm11, [rsp+0xA0]
000072bd77dd12ed  vmovaps xmm12, [rsp+0xB0]
000072bd77dd12f6  vmovaps xmm13, [rsp+0xC0]
000072bd77dd12ff  vmovaps xmm14, [rsp+0xD0]
000072bd77dd1308  vmovaps xmm15, [rsp+0xE0]
000072bd77dd1311  add rsp, 0xF0
000072bd77dd1318  pop r11
000072bd77dd131a  pop r10
000072bd77dd131c  pop r9
000072bd77dd131e  pop r8
000072bd77dd1320  pop rsi
000072bd77dd1321  pop rdi
000072bd77dd1322  pop rdx
000072bd77dd1323  pop rcx
000072bd77dd1324  pop rax
000072bd77dd1325  add rsp, 0x08
000072bd77dd1329  jmp 0x000072BD77DCF82C
000072bd77dd132e  call 0x000072BD77C0E760
000072bd77dd1333  jmp 0x000072BD77DCF839
000072bd77dd1338  sub rsp, 0x08
000072bd77dd133c  push rax
000072bd77dd133d  push rcx
000072bd77dd133e  push rdx
000072bd77dd133f  push rdi
000072bd77dd1340  push rsi
000072bd77dd1341  push r8
000072bd77dd1343  push r9
000072bd77dd1345  push r10
000072bd77dd1347  push r11
000072bd77dd1349  sub rsp, 0xF0
000072bd77dd1350  vmovaps [rsp], xmm0
000072bd77dd1355  vmovaps [rsp+0x10], xmm1
000072bd77dd135b  vmovaps [rsp+0x20], xmm2
000072bd77dd1361  vmovaps [rsp+0x30], xmm3
000072bd77dd1367  vmovaps [rsp+0x40], xmm4
000072bd77dd136d  vmovaps [rsp+0x50], xmm5
000072bd77dd1373  vmovaps [rsp+0x60], xmm6
000072bd77dd1379  vmovaps [rsp+0x70], xmm7
000072bd77dd137f  vmovaps [rsp+0x80], xmm8
000072bd77dd1388  vmovaps [rsp+0x90], xmm9
000072bd77dd1391  vmovaps [rsp+0xA0], xmm10
000072bd77dd139a  vmovaps [rsp+0xB0], xmm11
000072bd77dd13a3  vmovaps [rsp+0xC0], xmm12
000072bd77dd13ac  vmovaps [rsp+0xD0], xmm14
000072bd77dd13b5  vmovaps [rsp+0xE0], xmm15
000072bd77dd13be  sub rsp, 0x30
000072bd77dd13c2  movaps [rsp], xmm13
000072bd77dd13c7  movaps [rsp+0x10], xmm2
000072bd77dd13cc  movaps [rsp+0x20], xmm1
000072bd77dd13d1  lea rdi, [rsp]
000072bd77dd13d5  mov esi, 0x00
000072bd77dd13da  mov rax, 0x643206AC3530
000072bd77dd13e4  call rax
000072bd77dd13e6  movaps xmm13, [rsp]
000072bd77dd13eb  add rsp, 0x30
000072bd77dd13ef  vmovaps xmm0, [rsp]
000072bd77dd13f4  vmovaps xmm1, [rsp+0x10]
000072bd77dd13fa  vmovaps xmm2, [rsp+0x20]
000072bd77dd1400  vmovaps xmm3, [rsp+0x30]
000072bd77dd1406  vmovaps xmm4, [rsp+0x40]
000072bd77dd140c  vmovaps xmm5, [rsp+0x50]
000072bd77dd1412  vmovaps xmm6, [rsp+0x60]
000072bd77dd1418  vmovaps xmm7, [rsp+0x70]
000072bd77dd141e  vmovaps xmm8, [rsp+0x80]
000072bd77dd1427  vmovaps xmm9, [rsp+0x90]
000072bd77dd1430  vmovaps xmm10, [rsp+0xA0]
000072bd77dd1439  vmovaps xmm11, [rsp+0xB0]
000072bd77dd1442  vmovaps xmm12, [rsp+0xC0]
000072bd77dd144b  vmovaps xmm14, [rsp+0xD0]
000072bd77dd1454  vmovaps xmm15, [rsp+0xE0]
000072bd77dd145d  add rsp, 0xF0
000072bd77dd1464  pop r11
000072bd77dd1466  pop r10
000072bd77dd1468  pop r9
000072bd77dd146a  pop r8
000072bd77dd146c  pop rsi
000072bd77dd146d  pop rdi
000072bd77dd146e  pop rdx
000072bd77dd146f  pop rcx
000072bd77dd1470  pop rax
000072bd77dd1471  add rsp, 0x08
000072bd77dd1475  jmp 0x000072BD77DCF878
000072bd77dd147a  sub rsp, 0x08
000072bd77dd147e  push rax
000072bd77dd147f  push rcx
000072bd77dd1480  push rdx
000072bd77dd1481  push rdi
000072bd77dd1482  push rsi
000072bd77dd1483  push r8
000072bd77dd1485  push r9
000072bd77dd1487  push r10
000072bd77dd1489  push r11
000072bd77dd148b  sub rsp, 0xF0
000072bd77dd1492  vmovaps [rsp], xmm0
000072bd77dd1497  vmovaps [rsp+0x10], xmm2
000072bd77dd149d  vmovaps [rsp+0x20], xmm3
000072bd77dd14a3  vmovaps [rsp+0x30], xmm4
000072bd77dd14a9  vmovaps [rsp+0x40], xmm5
000072bd77dd14af  vmovaps [rsp+0x50], xmm6
000072bd77dd14b5  vmovaps [rsp+0x60], xmm7
000072bd77dd14bb  vmovaps [rsp+0x70], xmm8
000072bd77dd14c1  vmovaps [rsp+0x80], xmm9
000072bd77dd14ca  vmovaps [rsp+0x90], xmm10
000072bd77dd14d3  vmovaps [rsp+0xA0], xmm11
000072bd77dd14dc  vmovaps [rsp+0xB0], xmm12
000072bd77dd14e5  vmovaps [rsp+0xC0], xmm13
000072bd77dd14ee  vmovaps [rsp+0xD0], xmm14
000072bd77dd14f7  vmovaps [rsp+0xE0], xmm15
000072bd77dd1500  sub rsp, 0x30
000072bd77dd1504  movaps [rsp], xmm1
000072bd77dd1508  movaps [rsp+0x10], xmm15
000072bd77dd150e  movaps [rsp+0x20], xmm2
000072bd77dd1513  lea rdi, [rsp]
000072bd77dd1517  mov esi, 0x00
000072bd77dd151c  mov rax, 0x643206AC3530
000072bd77dd1526  call rax
000072bd77dd1528  movaps xmm1, [rsp]
000072bd77dd152c  add rsp, 0x30
000072bd77dd1530  vmovaps xmm0, [rsp]
000072bd77dd1535  vmovaps xmm2, [rsp+0x10]
000072bd77dd153b  vmovaps xmm3, [rsp+0x20]
000072bd77dd1541  vmovaps xmm4, [rsp+0x30]
000072bd77dd1547  vmovaps xmm5, [rsp+0x40]
000072bd77dd154d  vmovaps xmm6, [rsp+0x50]
000072bd77dd1553  vmovaps xmm7, [rsp+0x60]
000072bd77dd1559  vmovaps xmm8, [rsp+0x70]
000072bd77dd155f  vmovaps xmm9, [rsp+0x80]
000072bd77dd1568  vmovaps xmm10, [rsp+0x90]
000072bd77dd1571  vmovaps xmm11, [rsp+0xA0]
000072bd77dd157a  vmovaps xmm12, [rsp+0xB0]
000072bd77dd1583  vmovaps xmm13, [rsp+0xC0]
000072bd77dd158c  vmovaps xmm14, [rsp+0xD0]
000072bd77dd1595  vmovaps xmm15, [rsp+0xE0]
000072bd77dd159e  add rsp, 0xF0
000072bd77dd15a5  pop r11
000072bd77dd15a7  pop r10
000072bd77dd15a9  pop r9
000072bd77dd15ab  pop r8
000072bd77dd15ad  pop rsi
000072bd77dd15ae  pop rdi
000072bd77dd15af  pop rdx
000072bd77dd15b0  pop rcx
000072bd77dd15b1  pop rax
000072bd77dd15b2  add rsp, 0x08
000072bd77dd15b6  jmp 0x000072BD77DCF8AC
000072bd77dd15bb  sub rsp, 0x08
000072bd77dd15bf  push rax
000072bd77dd15c0  push rcx
000072bd77dd15c1  push rdx
000072bd77dd15c2  push rdi
000072bd77dd15c3  push rsi
000072bd77dd15c4  push r8
000072bd77dd15c6  push r9
000072bd77dd15c8  push r10
000072bd77dd15ca  push r11
000072bd77dd15cc  sub rsp, 0xF0
000072bd77dd15d3  vmovaps [rsp], xmm0
000072bd77dd15d8  vmovaps [rsp+0x10], xmm1
000072bd77dd15de  vmovaps [rsp+0x20], xmm2
000072bd77dd15e4  vmovaps [rsp+0x30], xmm3
000072bd77dd15ea  vmovaps [rsp+0x40], xmm4
000072bd77dd15f0  vmovaps [rsp+0x50], xmm5
000072bd77dd15f6  vmovaps [rsp+0x60], xmm6
000072bd77dd15fc  vmovaps [rsp+0x70], xmm7
000072bd77dd1602  vmovaps [rsp+0x80], xmm8
000072bd77dd160b  vmovaps [rsp+0x90], xmm9
000072bd77dd1614  vmovaps [rsp+0xA0], xmm10
000072bd77dd161d  vmovaps [rsp+0xB0], xmm11
000072bd77dd1626  vmovaps [rsp+0xC0], xmm12
000072bd77dd162f  vmovaps [rsp+0xD0], xmm13
000072bd77dd1638  vmovaps [rsp+0xE0], xmm15
000072bd77dd1641  sub rsp, 0x30
000072bd77dd1645  movaps [rsp], xmm14
000072bd77dd164a  movaps [rsp+0x10], xmm2
000072bd77dd164f  movaps [rsp+0x20], xmm15
000072bd77dd1655  lea rdi, [rsp]
000072bd77dd1659  mov esi, 0x00
000072bd77dd165e  mov rax, 0x643206AC3530
000072bd77dd1668  call rax
000072bd77dd166a  movaps xmm14, [rsp]
000072bd77dd166f  add rsp, 0x30
000072bd77dd1673  vmovaps xmm0, [rsp]
000072bd77dd1678  vmovaps xmm1, [rsp+0x10]
000072bd77dd167e  vmovaps xmm2, [rsp+0x20]
000072bd77dd1684  vmovaps xmm3, [rsp+0x30]
000072bd77dd168a  vmovaps xmm4, [rsp+0x40]
000072bd77dd1690  vmovaps xmm5, [rsp+0x50]
000072bd77dd1696  vmovaps xmm6, [rsp+0x60]
000072bd77dd169c  vmovaps xmm7, [rsp+0x70]
000072bd77dd16a2  vmovaps xmm8, [rsp+0x80]
000072bd77dd16ab  vmovaps xmm9, [rsp+0x90]
000072bd77dd16b4  vmovaps xmm10, [rsp+0xA0]
000072bd77dd16bd  vmovaps xmm11, [rsp+0xB0]
000072bd77dd16c6  vmovaps xmm12, [rsp+0xC0]
000072bd77dd16cf  vmovaps xmm13, [rsp+0xD0]
000072bd77dd16d8  vmovaps xmm15, [rsp+0xE0]
000072bd77dd16e1  add rsp, 0xF0
000072bd77dd16e8  pop r11
000072bd77dd16ea  pop r10
000072bd77dd16ec  pop r9
000072bd77dd16ee  pop r8
000072bd77dd16f0  pop rsi
000072bd77dd16f1  pop rdi
000072bd77dd16f2  pop rdx
000072bd77dd16f3  pop rcx
000072bd77dd16f4  pop rax
000072bd77dd16f5  add rsp, 0x08
000072bd77dd16f9  jmp 0x000072BD77DCF8E7
000072bd77dd16fe  sub rsp, 0x08
000072bd77dd1702  push rax
000072bd77dd1703  push rcx
000072bd77dd1704  push rdx
000072bd77dd1705  push rdi
000072bd77dd1706  push rsi
000072bd77dd1707  push r8
000072bd77dd1709  push r9
000072bd77dd170b  push r10
000072bd77dd170d  push r11
000072bd77dd170f  sub rsp, 0xF0
000072bd77dd1716  vmovaps [rsp], xmm0
000072bd77dd171b  vmovaps [rsp+0x10], xmm1
000072bd77dd1721  vmovaps [rsp+0x20], xmm2
000072bd77dd1727  vmovaps [rsp+0x30], xmm3
000072bd77dd172d  vmovaps [rsp+0x40], xmm4
000072bd77dd1733  vmovaps [rsp+0x50], xmm5
000072bd77dd1739  vmovaps [rsp+0x60], xmm6
000072bd77dd173f  vmovaps [rsp+0x70], xmm7
000072bd77dd1745  vmovaps [rsp+0x80], xmm8
000072bd77dd174e  vmovaps [rsp+0x90], xmm9
000072bd77dd1757  vmovaps [rsp+0xA0], xmm10
000072bd77dd1760  vmovaps [rsp+0xB0], xmm11
000072bd77dd1769  vmovaps [rsp+0xC0], xmm12
000072bd77dd1772  vmovaps [rsp+0xD0], xmm13
000072bd77dd177b  vmovaps [rsp+0xE0], xmm14
000072bd77dd1784  sub rsp, 0x30
000072bd77dd1788  movaps [rsp], xmm15
000072bd77dd178d  movaps [rsp+0x10], xmm2
000072bd77dd1792  movaps [rsp+0x20], xmm1
000072bd77dd1797  lea rdi, [rsp]
000072bd77dd179b  mov esi, 0x00
000072bd77dd17a0  mov rax, 0x643206AC3530
000072bd77dd17aa  call rax
000072bd77dd17ac  movaps xmm15, [rsp]
000072bd77dd17b1  add rsp, 0x30
000072bd77dd17b5  vmovaps xmm0, [rsp]
000072bd77dd17ba  vmovaps xmm1, [rsp+0x10]
000072bd77dd17c0  vmovaps xmm2, [rsp+0x20]
000072bd77dd17c6  vmovaps xmm3, [rsp+0x30]
000072bd77dd17cc  vmovaps xmm4, [rsp+0x40]
000072bd77dd17d2  vmovaps xmm5, [rsp+0x50]
000072bd77dd17d8  vmovaps xmm6, [rsp+0x60]
000072bd77dd17de  vmovaps xmm7, [rsp+0x70]
000072bd77dd17e4  vmovaps xmm8, [rsp+0x80]
000072bd77dd17ed  vmovaps xmm9, [rsp+0x90]
000072bd77dd17f6  vmovaps xmm10, [rsp+0xA0]
000072bd77dd17ff  vmovaps xmm11, [rsp+0xB0]
000072bd77dd1808  vmovaps xmm12, [rsp+0xC0]
000072bd77dd1811  vmovaps xmm13, [rsp+0xD0]
000072bd77dd181a  vmovaps xmm14, [rsp+0xE0]
000072bd77dd1823  add rsp, 0xF0
000072bd77dd182a  pop r11
000072bd77dd182c  pop r10
000072bd77dd182e  pop r9
000072bd77dd1830  pop r8
000072bd77dd1832  pop rsi
000072bd77dd1833  pop rdi
000072bd77dd1834  pop rdx
000072bd77dd1835  pop rcx
000072bd77dd1836  pop rax
000072bd77dd1837  add rsp, 0x08
000072bd77dd183b  jmp 0x000072BD77DCF923
000072bd77dd1840  call 0x000072BD77BFF430
000072bd77dd1845  jmp 0x000072BD77DCF930
000072bd77dd184a  sub rsp, 0x08
000072bd77dd184e  push rax
000072bd77dd184f  push rcx
000072bd77dd1850  push rdx
000072bd77dd1851  push rdi
000072bd77dd1852  push rsi
000072bd77dd1853  push r8
000072bd77dd1855  push r9
000072bd77dd1857  push r10
000072bd77dd1859  push r11
000072bd77dd185b  sub rsp, 0xF0
000072bd77dd1862  vmovaps [rsp], xmm0
000072bd77dd1867  vmovaps [rsp+0x10], xmm1
000072bd77dd186d  vmovaps [rsp+0x20], xmm3
000072bd77dd1873  vmovaps [rsp+0x30], xmm4
000072bd77dd1879  vmovaps [rsp+0x40], xmm5
000072bd77dd187f  vmovaps [rsp+0x50], xmm6
000072bd77dd1885  vmovaps [rsp+0x60], xmm7
000072bd77dd188b  vmovaps [rsp+0x70], xmm8
000072bd77dd1891  vmovaps [rsp+0x80], xmm9
000072bd77dd189a  vmovaps [rsp+0x90], xmm10
000072bd77dd18a3  vmovaps [rsp+0xA0], xmm11
000072bd77dd18ac  vmovaps [rsp+0xB0], xmm12
000072bd77dd18b5  vmovaps [rsp+0xC0], xmm13
000072bd77dd18be  vmovaps [rsp+0xD0], xmm14
000072bd77dd18c7  vmovaps [rsp+0xE0], xmm15
000072bd77dd18d0  sub rsp, 0x30
000072bd77dd18d4  movaps [rsp], xmm2
000072bd77dd18d8  movaps [rsp+0x10], xmm1
000072bd77dd18dd  movaps [rsp+0x20], xmm14
000072bd77dd18e3  lea rdi, [rsp]
000072bd77dd18e7  mov esi, 0x00
000072bd77dd18ec  mov rax, 0x643206AC3530
000072bd77dd18f6  call rax
000072bd77dd18f8  movaps xmm2, [rsp]
000072bd77dd18fc  add rsp, 0x30
000072bd77dd1900  vmovaps xmm0, [rsp]
000072bd77dd1905  vmovaps xmm1, [rsp+0x10]
000072bd77dd190b  vmovaps xmm3, [rsp+0x20]
000072bd77dd1911  vmovaps xmm4, [rsp+0x30]
000072bd77dd1917  vmovaps xmm5, [rsp+0x40]
000072bd77dd191d  vmovaps xmm6, [rsp+0x50]
000072bd77dd1923  vmovaps xmm7, [rsp+0x60]
000072bd77dd1929  vmovaps xmm8, [rsp+0x70]
000072bd77dd192f  vmovaps xmm9, [rsp+0x80]
000072bd77dd1938  vmovaps xmm10, [rsp+0x90]
000072bd77dd1941  vmovaps xmm11, [rsp+0xA0]
000072bd77dd194a  vmovaps xmm12, [rsp+0xB0]
000072bd77dd1953  vmovaps xmm13, [rsp+0xC0]
000072bd77dd195c  vmovaps xmm14, [rsp+0xD0]
000072bd77dd1965  vmovaps xmm15, [rsp+0xE0]
000072bd77dd196e  add rsp, 0xF0
000072bd77dd1975  pop r11
000072bd77dd1977  pop r10
000072bd77dd1979  pop r9
000072bd77dd197b  pop r8
000072bd77dd197d  pop rsi
000072bd77dd197e  pop rdi
000072bd77dd197f  pop rdx
000072bd77dd1980  pop rcx
000072bd77dd1981  pop rax
000072bd77dd1982  add rsp, 0x08
000072bd77dd1986  jmp 0x000072BD77DCF96D
000072bd77dd198b  sub rsp, 0x08
000072bd77dd198f  push rax
000072bd77dd1990  push rcx
000072bd77dd1991  push rdx
000072bd77dd1992  push rdi
000072bd77dd1993  push rsi
000072bd77dd1994  push r8
000072bd77dd1996  push r9
000072bd77dd1998  push r10
000072bd77dd199a  push r11
000072bd77dd199c  sub rsp, 0xF0
000072bd77dd19a3  vmovaps [rsp], xmm0
000072bd77dd19a8  vmovaps [rsp+0x10], xmm1
000072bd77dd19ae  vmovaps [rsp+0x20], xmm2
000072bd77dd19b4  vmovaps [rsp+0x30], xmm3
000072bd77dd19ba  vmovaps [rsp+0x40], xmm4
000072bd77dd19c0  vmovaps [rsp+0x50], xmm5
000072bd77dd19c6  vmovaps [rsp+0x60], xmm6
000072bd77dd19cc  vmovaps [rsp+0x70], xmm7
000072bd77dd19d2  vmovaps [rsp+0x80], xmm8
000072bd77dd19db  vmovaps [rsp+0x90], xmm9
000072bd77dd19e4  vmovaps [rsp+0xA0], xmm10
000072bd77dd19ed  vmovaps [rsp+0xB0], xmm11
000072bd77dd19f6  vmovaps [rsp+0xC0], xmm12
000072bd77dd19ff  vmovaps [rsp+0xD0], xmm13
000072bd77dd1a08  vmovaps [rsp+0xE0], xmm14
000072bd77dd1a11  sub rsp, 0x30
000072bd77dd1a15  movaps [rsp], xmm15
000072bd77dd1a1a  movaps [rsp+0x10], xmm14
000072bd77dd1a20  movaps [rsp+0x20], xmm1
000072bd77dd1a25  lea rdi, [rsp]
000072bd77dd1a29  mov esi, 0x00
000072bd77dd1a2e  mov rax, 0x643206AC3530
000072bd77dd1a38  call rax
000072bd77dd1a3a  movaps xmm15, [rsp]
000072bd77dd1a3f  add rsp, 0x30
000072bd77dd1a43  vmovaps xmm0, [rsp]
000072bd77dd1a48  vmovaps xmm1, [rsp+0x10]
000072bd77dd1a4e  vmovaps xmm2, [rsp+0x20]
000072bd77dd1a54  vmovaps xmm3, [rsp+0x30]
000072bd77dd1a5a  vmovaps xmm4, [rsp+0x40]
000072bd77dd1a60  vmovaps xmm5, [rsp+0x50]
000072bd77dd1a66  vmovaps xmm6, [rsp+0x60]
000072bd77dd1a6c  vmovaps xmm7, [rsp+0x70]
000072bd77dd1a72  vmovaps xmm8, [rsp+0x80]
000072bd77dd1a7b  vmovaps xmm9, [rsp+0x90]
000072bd77dd1a84  vmovaps xmm10, [rsp+0xA0]
000072bd77dd1a8d  vmovaps xmm11, [rsp+0xB0]
000072bd77dd1a96  vmovaps xmm12, [rsp+0xC0]
000072bd77dd1a9f  vmovaps xmm13, [rsp+0xD0]
000072bd77dd1aa8  vmovaps xmm14, [rsp+0xE0]
000072bd77dd1ab1  add rsp, 0xF0
000072bd77dd1ab8  pop r11
000072bd77dd1aba  pop r10
000072bd77dd1abc  pop r9
000072bd77dd1abe  pop r8
000072bd77dd1ac0  pop rsi
000072bd77dd1ac1  pop rdi
000072bd77dd1ac2  pop rdx
000072bd77dd1ac3  pop rcx
000072bd77dd1ac4  pop rax
000072bd77dd1ac5  add rsp, 0x08
000072bd77dd1ac9  jmp 0x000072BD77DCF9E7
000072bd77dd1ace  call 0x000072BD77BFF430
000072bd77dd1ad3  jmp 0x000072BD77DCF9F4
000072bd77dd1ad8  sub rsp, 0x08
000072bd77dd1adc  push rax
000072bd77dd1add  push rcx
000072bd77dd1ade  push rdx
000072bd77dd1adf  push rdi
000072bd77dd1ae0  push rsi
000072bd77dd1ae1  push r8
000072bd77dd1ae3  push r9
000072bd77dd1ae5  push r10
000072bd77dd1ae7  push r11
000072bd77dd1ae9  sub rsp, 0xF0
000072bd77dd1af0  vmovaps [rsp], xmm0
000072bd77dd1af5  vmovaps [rsp+0x10], xmm1
000072bd77dd1afb  vmovaps [rsp+0x20], xmm2
000072bd77dd1b01  vmovaps [rsp+0x30], xmm3
000072bd77dd1b07  vmovaps [rsp+0x40], xmm4
000072bd77dd1b0d  vmovaps [rsp+0x50], xmm5
000072bd77dd1b13  vmovaps [rsp+0x60], xmm6
000072bd77dd1b19  vmovaps [rsp+0x70], xmm7
000072bd77dd1b1f  vmovaps [rsp+0x80], xmm8
000072bd77dd1b28  vmovaps [rsp+0x90], xmm9
000072bd77dd1b31  vmovaps [rsp+0xA0], xmm10
000072bd77dd1b3a  vmovaps [rsp+0xB0], xmm11
000072bd77dd1b43  vmovaps [rsp+0xC0], xmm12
000072bd77dd1b4c  vmovaps [rsp+0xD0], xmm13
000072bd77dd1b55  vmovaps [rsp+0xE0], xmm15
000072bd77dd1b5e  sub rsp, 0x30
000072bd77dd1b62  movaps [rsp], xmm14
000072bd77dd1b67  movaps [rsp+0x10], xmm13
000072bd77dd1b6d  movaps [rsp+0x20], xmm1
000072bd77dd1b72  lea rdi, [rsp]
000072bd77dd1b76  mov esi, 0x00
000072bd77dd1b7b  mov rax, 0x643206AC3530
000072bd77dd1b85  call rax
000072bd77dd1b87  movaps xmm14, [rsp]
000072bd77dd1b8c  add rsp, 0x30
000072bd77dd1b90  vmovaps xmm0, [rsp]
000072bd77dd1b95  vmovaps xmm1, [rsp+0x10]
000072bd77dd1b9b  vmovaps xmm2, [rsp+0x20]
000072bd77dd1ba1  vmovaps xmm3, [rsp+0x30]
000072bd77dd1ba7  vmovaps xmm4, [rsp+0x40]
000072bd77dd1bad  vmovaps xmm5, [rsp+0x50]
000072bd77dd1bb3  vmovaps xmm6, [rsp+0x60]
000072bd77dd1bb9  vmovaps xmm7, [rsp+0x70]
000072bd77dd1bbf  vmovaps xmm8, [rsp+0x80]
000072bd77dd1bc8  vmovaps xmm9, [rsp+0x90]
000072bd77dd1bd1  vmovaps xmm10, [rsp+0xA0]
000072bd77dd1bda  vmovaps xmm11, [rsp+0xB0]
000072bd77dd1be3  vmovaps xmm12, [rsp+0xC0]
000072bd77dd1bec  vmovaps xmm13, [rsp+0xD0]
000072bd77dd1bf5  vmovaps xmm15, [rsp+0xE0]
000072bd77dd1bfe  add rsp, 0xF0
000072bd77dd1c05  pop r11
000072bd77dd1c07  pop r10
000072bd77dd1c09  pop r9
000072bd77dd1c0b  pop r8
000072bd77dd1c0d  pop rsi
000072bd77dd1c0e  pop rdi
000072bd77dd1c0f  pop rdx
000072bd77dd1c10  pop rcx
000072bd77dd1c11  pop rax
000072bd77dd1c12  add rsp, 0x08
000072bd77dd1c16  jmp 0x000072BD77DCFAAF
000072bd77dd1c1b  sub rsp, 0x08
000072bd77dd1c1f  push rax
000072bd77dd1c20  push rcx
000072bd77dd1c21  push rdx
000072bd77dd1c22  push rdi
000072bd77dd1c23  push rsi
000072bd77dd1c24  push r8
000072bd77dd1c26  push r9
000072bd77dd1c28  push r10
000072bd77dd1c2a  push r11
000072bd77dd1c2c  sub rsp, 0xF0
000072bd77dd1c33  vmovaps [rsp], xmm0
000072bd77dd1c38  vmovaps [rsp+0x10], xmm1
000072bd77dd1c3e  vmovaps [rsp+0x20], xmm2
000072bd77dd1c44  vmovaps [rsp+0x30], xmm3
000072bd77dd1c4a  vmovaps [rsp+0x40], xmm4
000072bd77dd1c50  vmovaps [rsp+0x50], xmm5
000072bd77dd1c56  vmovaps [rsp+0x60], xmm6
000072bd77dd1c5c  vmovaps [rsp+0x70], xmm7
000072bd77dd1c62  vmovaps [rsp+0x80], xmm8
000072bd77dd1c6b  vmovaps [rsp+0x90], xmm9
000072bd77dd1c74  vmovaps [rsp+0xA0], xmm10
000072bd77dd1c7d  vmovaps [rsp+0xB0], xmm11
000072bd77dd1c86  vmovaps [rsp+0xC0], xmm12
000072bd77dd1c8f  vmovaps [rsp+0xD0], xmm13
000072bd77dd1c98  vmovaps [rsp+0xE0], xmm14
000072bd77dd1ca1  sub rsp, 0x30
000072bd77dd1ca5  movaps [rsp], xmm15
000072bd77dd1caa  movaps [rsp+0x10], xmm13
000072bd77dd1cb0  movaps [rsp+0x20], xmm1
000072bd77dd1cb5  lea rdi, [rsp]
000072bd77dd1cb9  mov esi, 0x00
000072bd77dd1cbe  mov rax, 0x643206AC3530
000072bd77dd1cc8  call rax
000072bd77dd1cca  movaps xmm15, [rsp]
000072bd77dd1ccf  add rsp, 0x30
000072bd77dd1cd3  vmovaps xmm0, [rsp]
000072bd77dd1cd8  vmovaps xmm1, [rsp+0x10]
000072bd77dd1cde  vmovaps xmm2, [rsp+0x20]
000072bd77dd1ce4  vmovaps xmm3, [rsp+0x30]
000072bd77dd1cea  vmovaps xmm4, [rsp+0x40]
000072bd77dd1cf0  vmovaps xmm5, [rsp+0x50]
000072bd77dd1cf6  vmovaps xmm6, [rsp+0x60]
000072bd77dd1cfc  vmovaps xmm7, [rsp+0x70]
000072bd77dd1d02  vmovaps xmm8, [rsp+0x80]
000072bd77dd1d0b  vmovaps xmm9, [rsp+0x90]
000072bd77dd1d14  vmovaps xmm10, [rsp+0xA0]
000072bd77dd1d1d  vmovaps xmm11, [rsp+0xB0]
000072bd77dd1d26  vmovaps xmm12, [rsp+0xC0]
000072bd77dd1d2f  vmovaps xmm13, [rsp+0xD0]
000072bd77dd1d38  vmovaps xmm14, [rsp+0xE0]
000072bd77dd1d41  add rsp, 0xF0
000072bd77dd1d48  pop r11
000072bd77dd1d4a  pop r10
000072bd77dd1d4c  pop r9
000072bd77dd1d4e  pop r8
000072bd77dd1d50  pop rsi
000072bd77dd1d51  pop rdi
000072bd77dd1d52  pop rdx
000072bd77dd1d53  pop rcx
000072bd77dd1d54  pop rax
000072bd77dd1d55  add rsp, 0x08
000072bd77dd1d59  jmp 0x000072BD77DCFAEB
000072bd77dd1d5e  call 0x000072BD77BFF430
000072bd77dd1d63  jmp 0x000072BD77DCFAF8
000072bd77dd1d68  sub rsp, 0x08
000072bd77dd1d6c  push rax
000072bd77dd1d6d  push rcx
000072bd77dd1d6e  push rdx
000072bd77dd1d6f  push rdi
000072bd77dd1d70  push rsi
000072bd77dd1d71  push r8
000072bd77dd1d73  push r9
000072bd77dd1d75  push r10
000072bd77dd1d77  push r11
000072bd77dd1d79  sub rsp, 0xF0
000072bd77dd1d80  vmovaps [rsp], xmm0
000072bd77dd1d85  vmovaps [rsp+0x10], xmm1
000072bd77dd1d8b  vmovaps [rsp+0x20], xmm2
000072bd77dd1d91  vmovaps [rsp+0x30], xmm3
000072bd77dd1d97  vmovaps [rsp+0x40], xmm4
000072bd77dd1d9d  vmovaps [rsp+0x50], xmm5
000072bd77dd1da3  vmovaps [rsp+0x60], xmm6
000072bd77dd1da9  vmovaps [rsp+0x70], xmm7
000072bd77dd1daf  vmovaps [rsp+0x80], xmm8
000072bd77dd1db8  vmovaps [rsp+0x90], xmm9
000072bd77dd1dc1  vmovaps [rsp+0xA0], xmm10
000072bd77dd1dca  vmovaps [rsp+0xB0], xmm11
000072bd77dd1dd3  vmovaps [rsp+0xC0], xmm12
000072bd77dd1ddc  vmovaps [rsp+0xD0], xmm13
000072bd77dd1de5  vmovaps [rsp+0xE0], xmm15
000072bd77dd1dee  sub rsp, 0x30
000072bd77dd1df2  movaps [rsp], xmm14
000072bd77dd1df7  movaps [rsp+0x10], xmm13
000072bd77dd1dfd  movaps [rsp+0x20], xmm2
000072bd77dd1e02  lea rdi, [rsp]
000072bd77dd1e06  mov esi, 0x00
000072bd77dd1e0b  mov rax, 0x643206AC3530
000072bd77dd1e15  call rax
000072bd77dd1e17  movaps xmm14, [rsp]
000072bd77dd1e1c  add rsp, 0x30
000072bd77dd1e20  vmovaps xmm0, [rsp]
000072bd77dd1e25  vmovaps xmm1, [rsp+0x10]
000072bd77dd1e2b  vmovaps xmm2, [rsp+0x20]
000072bd77dd1e31  vmovaps xmm3, [rsp+0x30]
000072bd77dd1e37  vmovaps xmm4, [rsp+0x40]
000072bd77dd1e3d  vmovaps xmm5, [rsp+0x50]
000072bd77dd1e43  vmovaps xmm6, [rsp+0x60]
000072bd77dd1e49  vmovaps xmm7, [rsp+0x70]
000072bd77dd1e4f  vmovaps xmm8, [rsp+0x80]
000072bd77dd1e58  vmovaps xmm9, [rsp+0x90]
000072bd77dd1e61  vmovaps xmm10, [rsp+0xA0]
000072bd77dd1e6a  vmovaps xmm11, [rsp+0xB0]
000072bd77dd1e73  vmovaps xmm12, [rsp+0xC0]
000072bd77dd1e7c  vmovaps xmm13, [rsp+0xD0]
000072bd77dd1e85  vmovaps xmm15, [rsp+0xE0]
000072bd77dd1e8e  add rsp, 0xF0
000072bd77dd1e95  pop r11
000072bd77dd1e97  pop r10
000072bd77dd1e99  pop r9
000072bd77dd1e9b  pop r8
000072bd77dd1e9d  pop rsi
000072bd77dd1e9e  pop rdi
000072bd77dd1e9f  pop rdx
000072bd77dd1ea0  pop rcx
000072bd77dd1ea1  pop rax
000072bd77dd1ea2  add rsp, 0x08
000072bd77dd1ea6  jmp 0x000072BD77DCFB24
000072bd77dd1eab  sub rsp, 0x08
000072bd77dd1eaf  push rax
000072bd77dd1eb0  push rcx
000072bd77dd1eb1  push rdx
000072bd77dd1eb2  push rdi
000072bd77dd1eb3  push rsi
000072bd77dd1eb4  push r8
000072bd77dd1eb6  push r9
000072bd77dd1eb8  push r10
000072bd77dd1eba  push r11
000072bd77dd1ebc  sub rsp, 0xF0
000072bd77dd1ec3  vmovaps [rsp], xmm0
000072bd77dd1ec8  vmovaps [rsp+0x10], xmm2
000072bd77dd1ece  vmovaps [rsp+0x20], xmm3
000072bd77dd1ed4  vmovaps [rsp+0x30], xmm4
000072bd77dd1eda  vmovaps [rsp+0x40], xmm5
000072bd77dd1ee0  vmovaps [rsp+0x50], xmm6
000072bd77dd1ee6  vmovaps [rsp+0x60], xmm7
000072bd77dd1eec  vmovaps [rsp+0x70], xmm8
000072bd77dd1ef2  vmovaps [rsp+0x80], xmm9
000072bd77dd1efb  vmovaps [rsp+0x90], xmm10
000072bd77dd1f04  vmovaps [rsp+0xA0], xmm11
000072bd77dd1f0d  vmovaps [rsp+0xB0], xmm12
000072bd77dd1f16  vmovaps [rsp+0xC0], xmm13
000072bd77dd1f1f  vmovaps [rsp+0xD0], xmm14
000072bd77dd1f28  vmovaps [rsp+0xE0], xmm15
000072bd77dd1f31  sub rsp, 0x30
000072bd77dd1f35  movaps [rsp], xmm1
000072bd77dd1f39  movaps [rsp+0x10], xmm13
000072bd77dd1f3f  movaps [rsp+0x20], xmm2
000072bd77dd1f44  lea rdi, [rsp]
000072bd77dd1f48  mov esi, 0x00
000072bd77dd1f4d  mov rax, 0x643206AC3530
000072bd77dd1f57  call rax
000072bd77dd1f59  movaps xmm1, [rsp]
000072bd77dd1f5d  add rsp, 0x30
000072bd77dd1f61  vmovaps xmm0, [rsp]
000072bd77dd1f66  vmovaps xmm2, [rsp+0x10]
000072bd77dd1f6c  vmovaps xmm3, [rsp+0x20]
000072bd77dd1f72  vmovaps xmm4, [rsp+0x30]
000072bd77dd1f78  vmovaps xmm5, [rsp+0x40]
000072bd77dd1f7e  vmovaps xmm6, [rsp+0x50]
000072bd77dd1f84  vmovaps xmm7, [rsp+0x60]
000072bd77dd1f8a  vmovaps xmm8, [rsp+0x70]
000072bd77dd1f90  vmovaps xmm9, [rsp+0x80]
000072bd77dd1f99  vmovaps xmm10, [rsp+0x90]
000072bd77dd1fa2  vmovaps xmm11, [rsp+0xA0]
000072bd77dd1fab  vmovaps xmm12, [rsp+0xB0]
000072bd77dd1fb4  vmovaps xmm13, [rsp+0xC0]
000072bd77dd1fbd  vmovaps xmm14, [rsp+0xD0]
000072bd77dd1fc6  vmovaps xmm15, [rsp+0xE0]
000072bd77dd1fcf  add rsp, 0xF0
000072bd77dd1fd6  pop r11
000072bd77dd1fd8  pop r10
000072bd77dd1fda  pop r9
000072bd77dd1fdc  pop r8
000072bd77dd1fde  pop rsi
000072bd77dd1fdf  pop rdi
000072bd77dd1fe0  pop rdx
000072bd77dd1fe1  pop rcx
000072bd77dd1fe2  pop rax
000072bd77dd1fe3  add rsp, 0x08
000072bd77dd1fe7  jmp 0x000072BD77DCFB52
000072bd77dd1fec  sub rsp, 0x08
000072bd77dd1ff0  push rax
000072bd77dd1ff1  push rcx
000072bd77dd1ff2  push rdx
000072bd77dd1ff3  push rdi
000072bd77dd1ff4  push rsi
000072bd77dd1ff5  push r8
000072bd77dd1ff7  push r9
000072bd77dd1ff9  push r10
000072bd77dd1ffb  push r11
000072bd77dd1ffd  sub rsp, 0xF0
000072bd77dd2004  vmovaps [rsp], xmm0
000072bd77dd2009  vmovaps [rsp+0x10], xmm1
000072bd77dd200f  vmovaps [rsp+0x20], xmm3
000072bd77dd2015  vmovaps [rsp+0x30], xmm4
000072bd77dd201b  vmovaps [rsp+0x40], xmm5
000072bd77dd2021  vmovaps [rsp+0x50], xmm6
000072bd77dd2027  vmovaps [rsp+0x60], xmm7
000072bd77dd202d  vmovaps [rsp+0x70], xmm8
000072bd77dd2033  vmovaps [rsp+0x80], xmm9
000072bd77dd203c  vmovaps [rsp+0x90], xmm10
000072bd77dd2045  vmovaps [rsp+0xA0], xmm11
000072bd77dd204e  vmovaps [rsp+0xB0], xmm12
000072bd77dd2057  vmovaps [rsp+0xC0], xmm13
000072bd77dd2060  vmovaps [rsp+0xD0], xmm14
000072bd77dd2069  vmovaps [rsp+0xE0], xmm15
000072bd77dd2072  sub rsp, 0x30
000072bd77dd2076  movaps [rsp], xmm2
000072bd77dd207a  movaps [rsp+0x10], xmm1
000072bd77dd207f  movaps [rsp+0x20], xmm13
000072bd77dd2085  lea rdi, [rsp]
000072bd77dd2089  mov esi, 0x00
000072bd77dd208e  mov rax, 0x643206AC3530
000072bd77dd2098  call rax
000072bd77dd209a  movaps xmm2, [rsp]
000072bd77dd209e  add rsp, 0x30
000072bd77dd20a2  vmovaps xmm0, [rsp]
000072bd77dd20a7  vmovaps xmm1, [rsp+0x10]
000072bd77dd20ad  vmovaps xmm3, [rsp+0x20]
000072bd77dd20b3  vmovaps xmm4, [rsp+0x30]
000072bd77dd20b9  vmovaps xmm5, [rsp+0x40]
000072bd77dd20bf  vmovaps xmm6, [rsp+0x50]
000072bd77dd20c5  vmovaps xmm7, [rsp+0x60]
000072bd77dd20cb  vmovaps xmm8, [rsp+0x70]
000072bd77dd20d1  vmovaps xmm9, [rsp+0x80]
000072bd77dd20da  vmovaps xmm10, [rsp+0x90]
000072bd77dd20e3  vmovaps xmm11, [rsp+0xA0]
000072bd77dd20ec  vmovaps xmm12, [rsp+0xB0]
000072bd77dd20f5  vmovaps xmm13, [rsp+0xC0]
000072bd77dd20fe  vmovaps xmm14, [rsp+0xD0]
000072bd77dd2107  vmovaps xmm15, [rsp+0xE0]
000072bd77dd2110  add rsp, 0xF0
000072bd77dd2117  pop r11
000072bd77dd2119  pop r10
000072bd77dd211b  pop r9
000072bd77dd211d  pop r8
000072bd77dd211f  pop rsi
000072bd77dd2120  pop rdi
000072bd77dd2121  pop rdx
000072bd77dd2122  pop rcx
000072bd77dd2123  pop rax
000072bd77dd2124  add rsp, 0x08
000072bd77dd2128  jmp 0x000072BD77DCFBAB
000072bd77dd212d  call 0x000072BD77BFF430
000072bd77dd2132  jmp 0x000072BD77DCFBB8
000072bd77dd2137  sub rsp, 0x08
000072bd77dd213b  push rax
000072bd77dd213c  push rcx
000072bd77dd213d  push rdx
000072bd77dd213e  push rdi
000072bd77dd213f  push rsi
000072bd77dd2140  push r8
000072bd77dd2142  push r9
000072bd77dd2144  push r10
000072bd77dd2146  push r11
000072bd77dd2148  sub rsp, 0xF0
000072bd77dd214f  vmovaps [rsp], xmm0
000072bd77dd2154  vmovaps [rsp+0x10], xmm1
000072bd77dd215a  vmovaps [rsp+0x20], xmm2
000072bd77dd2160  vmovaps [rsp+0x30], xmm3
000072bd77dd2166  vmovaps [rsp+0x40], xmm4
000072bd77dd216c  vmovaps [rsp+0x50], xmm5
000072bd77dd2172  vmovaps [rsp+0x60], xmm6
000072bd77dd2178  vmovaps [rsp+0x70], xmm7
000072bd77dd217e  vmovaps [rsp+0x80], xmm8
000072bd77dd2187  vmovaps [rsp+0x90], xmm9
000072bd77dd2190  vmovaps [rsp+0xA0], xmm10
000072bd77dd2199  vmovaps [rsp+0xB0], xmm11
000072bd77dd21a2  vmovaps [rsp+0xC0], xmm12
000072bd77dd21ab  vmovaps [rsp+0xD0], xmm13
000072bd77dd21b4  vmovaps [rsp+0xE0], xmm14
000072bd77dd21bd  sub rsp, 0x30
000072bd77dd21c1  movaps [rsp], xmm15
000072bd77dd21c6  movaps [rsp+0x10], xmm13
000072bd77dd21cc  movaps [rsp+0x20], xmm1
000072bd77dd21d1  lea rdi, [rsp]
000072bd77dd21d5  mov esi, 0x00
000072bd77dd21da  mov rax, 0x643206AC3530
000072bd77dd21e4  call rax
000072bd77dd21e6  movaps xmm15, [rsp]
000072bd77dd21eb  add rsp, 0x30
000072bd77dd21ef  vmovaps xmm0, [rsp]
000072bd77dd21f4  vmovaps xmm1, [rsp+0x10]
000072bd77dd21fa  vmovaps xmm2, [rsp+0x20]
000072bd77dd2200  vmovaps xmm3, [rsp+0x30]
000072bd77dd2206  vmovaps xmm4, [rsp+0x40]
000072bd77dd220c  vmovaps xmm5, [rsp+0x50]
000072bd77dd2212  vmovaps xmm6, [rsp+0x60]
000072bd77dd2218  vmovaps xmm7, [rsp+0x70]
000072bd77dd221e  vmovaps xmm8, [rsp+0x80]
000072bd77dd2227  vmovaps xmm9, [rsp+0x90]
000072bd77dd2230  vmovaps xmm10, [rsp+0xA0]
000072bd77dd2239  vmovaps xmm11, [rsp+0xB0]
000072bd77dd2242  vmovaps xmm12, [rsp+0xC0]
000072bd77dd224b  vmovaps xmm13, [rsp+0xD0]
000072bd77dd2254  vmovaps xmm14, [rsp+0xE0]
000072bd77dd225d  add rsp, 0xF0
000072bd77dd2264  pop r11
000072bd77dd2266  pop r10
000072bd77dd2268  pop r9
000072bd77dd226a  pop r8
000072bd77dd226c  pop rsi
000072bd77dd226d  pop rdi
000072bd77dd226e  pop rdx
000072bd77dd226f  pop rcx
000072bd77dd2270  pop rax
000072bd77dd2271  add rsp, 0x08
000072bd77dd2275  jmp 0x000072BD77DCFBF7
000072bd77dd227a  sub rsp, 0x08
000072bd77dd227e  push rax
000072bd77dd227f  push rcx
000072bd77dd2280  push rdx
000072bd77dd2281  push rdi
000072bd77dd2282  push rsi
000072bd77dd2283  push r8
000072bd77dd2285  push r9
000072bd77dd2287  push r10
000072bd77dd2289  push r11
000072bd77dd228b  sub rsp, 0xF0
000072bd77dd2292  vmovaps [rsp], xmm0
000072bd77dd2297  vmovaps [rsp+0x10], xmm1
000072bd77dd229d  vmovaps [rsp+0x20], xmm2
000072bd77dd22a3  vmovaps [rsp+0x30], xmm3
000072bd77dd22a9  vmovaps [rsp+0x40], xmm4
000072bd77dd22af  vmovaps [rsp+0x50], xmm5
000072bd77dd22b5  vmovaps [rsp+0x60], xmm6
000072bd77dd22bb  vmovaps [rsp+0x70], xmm7
000072bd77dd22c1  vmovaps [rsp+0x80], xmm8
000072bd77dd22ca  vmovaps [rsp+0x90], xmm9
000072bd77dd22d3  vmovaps [rsp+0xA0], xmm10
000072bd77dd22dc  vmovaps [rsp+0xB0], xmm11
000072bd77dd22e5  vmovaps [rsp+0xC0], xmm12
000072bd77dd22ee  vmovaps [rsp+0xD0], xmm13
000072bd77dd22f7  vmovaps [rsp+0xE0], xmm15
000072bd77dd2300  sub rsp, 0x30
000072bd77dd2304  movaps [rsp], xmm14
000072bd77dd2309  movaps [rsp+0x10], xmm11
000072bd77dd230f  movaps [rsp+0x20], xmm1
000072bd77dd2314  lea rdi, [rsp]
000072bd77dd2318  mov esi, 0x00
000072bd77dd231d  mov rax, 0x643206AC3530
000072bd77dd2327  call rax
000072bd77dd2329  movaps xmm14, [rsp]
000072bd77dd232e  add rsp, 0x30
000072bd77dd2332  vmovaps xmm0, [rsp]
000072bd77dd2337  vmovaps xmm1, [rsp+0x10]
000072bd77dd233d  vmovaps xmm2, [rsp+0x20]
000072bd77dd2343  vmovaps xmm3, [rsp+0x30]
000072bd77dd2349  vmovaps xmm4, [rsp+0x40]
000072bd77dd234f  vmovaps xmm5, [rsp+0x50]
000072bd77dd2355  vmovaps xmm6, [rsp+0x60]
000072bd77dd235b  vmovaps xmm7, [rsp+0x70]
000072bd77dd2361  vmovaps xmm8, [rsp+0x80]
000072bd77dd236a  vmovaps xmm9, [rsp+0x90]
000072bd77dd2373  vmovaps xmm10, [rsp+0xA0]
000072bd77dd237c  vmovaps xmm11, [rsp+0xB0]
000072bd77dd2385  vmovaps xmm12, [rsp+0xC0]
000072bd77dd238e  vmovaps xmm13, [rsp+0xD0]
000072bd77dd2397  vmovaps xmm15, [rsp+0xE0]
000072bd77dd23a0  add rsp, 0xF0
000072bd77dd23a7  pop r11
000072bd77dd23a9  pop r10
000072bd77dd23ab  pop r9
000072bd77dd23ad  pop r8
000072bd77dd23af  pop rsi
000072bd77dd23b0  pop rdi
000072bd77dd23b1  pop rdx
000072bd77dd23b2  pop rcx
000072bd77dd23b3  pop rax
000072bd77dd23b4  add rsp, 0x08
000072bd77dd23b8  jmp 0x000072BD77DCFC21
000072bd77dd23bd  sub rsp, 0x08
000072bd77dd23c1  push rax
000072bd77dd23c2  push rcx
000072bd77dd23c3  push rdx
000072bd77dd23c4  push rdi
000072bd77dd23c5  push rsi
000072bd77dd23c6  push r8
000072bd77dd23c8  push r9
000072bd77dd23ca  push r10
000072bd77dd23cc  push r11
000072bd77dd23ce  sub rsp, 0xF0
000072bd77dd23d5  vmovaps [rsp], xmm0
000072bd77dd23da  vmovaps [rsp+0x10], xmm1
000072bd77dd23e0  vmovaps [rsp+0x20], xmm2
000072bd77dd23e6  vmovaps [rsp+0x30], xmm3
000072bd77dd23ec  vmovaps [rsp+0x40], xmm4
000072bd77dd23f2  vmovaps [rsp+0x50], xmm5
000072bd77dd23f8  vmovaps [rsp+0x60], xmm6
000072bd77dd23fe  vmovaps [rsp+0x70], xmm7
000072bd77dd2404  vmovaps [rsp+0x80], xmm8
000072bd77dd240d  vmovaps [rsp+0x90], xmm9
000072bd77dd2416  vmovaps [rsp+0xA0], xmm10
000072bd77dd241f  vmovaps [rsp+0xB0], xmm11
000072bd77dd2428  vmovaps [rsp+0xC0], xmm12
000072bd77dd2431  vmovaps [rsp+0xD0], xmm14
000072bd77dd243a  vmovaps [rsp+0xE0], xmm15
000072bd77dd2443  sub rsp, 0x30
000072bd77dd2447  movaps [rsp], xmm13
000072bd77dd244c  movaps [rsp+0x10], xmm11
000072bd77dd2452  movaps [rsp+0x20], xmm1
000072bd77dd2457  lea rdi, [rsp]
000072bd77dd245b  mov esi, 0x00
000072bd77dd2460  mov rax, 0x643206AC3530
000072bd77dd246a  call rax
000072bd77dd246c  movaps xmm13, [rsp]
000072bd77dd2471  add rsp, 0x30
000072bd77dd2475  vmovaps xmm0, [rsp]
000072bd77dd247a  vmovaps xmm1, [rsp+0x10]
000072bd77dd2480  vmovaps xmm2, [rsp+0x20]
000072bd77dd2486  vmovaps xmm3, [rsp+0x30]
000072bd77dd248c  vmovaps xmm4, [rsp+0x40]
000072bd77dd2492  vmovaps xmm5, [rsp+0x50]
000072bd77dd2498  vmovaps xmm6, [rsp+0x60]
000072bd77dd249e  vmovaps xmm7, [rsp+0x70]
000072bd77dd24a4  vmovaps xmm8, [rsp+0x80]
000072bd77dd24ad  vmovaps xmm9, [rsp+0x90]
000072bd77dd24b6  vmovaps xmm10, [rsp+0xA0]
000072bd77dd24bf  vmovaps xmm11, [rsp+0xB0]
000072bd77dd24c8  vmovaps xmm12, [rsp+0xC0]
000072bd77dd24d1  vmovaps xmm14, [rsp+0xD0]
000072bd77dd24da  vmovaps xmm15, [rsp+0xE0]
000072bd77dd24e3  add rsp, 0xF0
000072bd77dd24ea  pop r11
000072bd77dd24ec  pop r10
000072bd77dd24ee  pop r9
000072bd77dd24f0  pop r8
000072bd77dd24f2  pop rsi
000072bd77dd24f3  pop rdi
000072bd77dd24f4  pop rdx
000072bd77dd24f5  pop rcx
000072bd77dd24f6  pop rax
000072bd77dd24f7  add rsp, 0x08
000072bd77dd24fb  jmp 0x000072BD77DCFC76
000072bd77dd2500  call 0x000072BD77BFF430
000072bd77dd2505  jmp 0x000072BD77DCFC83
000072bd77dd250a  sub rsp, 0x08
000072bd77dd250e  push rax
000072bd77dd250f  push rcx
000072bd77dd2510  push rdx
000072bd77dd2511  push rdi
000072bd77dd2512  push rsi
000072bd77dd2513  push r8
000072bd77dd2515  push r9
000072bd77dd2517  push r10
000072bd77dd2519  push r11
000072bd77dd251b  sub rsp, 0xF0
000072bd77dd2522  vmovaps [rsp], xmm0
000072bd77dd2527  vmovaps [rsp+0x10], xmm1
000072bd77dd252d  vmovaps [rsp+0x20], xmm2
000072bd77dd2533  vmovaps [rsp+0x30], xmm3
000072bd77dd2539  vmovaps [rsp+0x40], xmm4
000072bd77dd253f  vmovaps [rsp+0x50], xmm5
000072bd77dd2545  vmovaps [rsp+0x60], xmm6
000072bd77dd254b  vmovaps [rsp+0x70], xmm7
000072bd77dd2551  vmovaps [rsp+0x80], xmm8
000072bd77dd255a  vmovaps [rsp+0x90], xmm9
000072bd77dd2563  vmovaps [rsp+0xA0], xmm10
000072bd77dd256c  vmovaps [rsp+0xB0], xmm11
000072bd77dd2575  vmovaps [rsp+0xC0], xmm12
000072bd77dd257e  vmovaps [rsp+0xD0], xmm13
000072bd77dd2587  vmovaps [rsp+0xE0], xmm14
000072bd77dd2590  sub rsp, 0x30
000072bd77dd2594  movaps [rsp], xmm15
000072bd77dd2599  movaps [rsp+0x10], xmm11
000072bd77dd259f  movaps [rsp+0x20], xmm1
000072bd77dd25a4  lea rdi, [rsp]
000072bd77dd25a8  mov esi, 0x00
000072bd77dd25ad  mov rax, 0x643206AC3530
000072bd77dd25b7  call rax
000072bd77dd25b9  movaps xmm15, [rsp]
000072bd77dd25be  add rsp, 0x30
000072bd77dd25c2  vmovaps xmm0, [rsp]
000072bd77dd25c7  vmovaps xmm1, [rsp+0x10]
000072bd77dd25cd  vmovaps xmm2, [rsp+0x20]
000072bd77dd25d3  vmovaps xmm3, [rsp+0x30]
000072bd77dd25d9  vmovaps xmm4, [rsp+0x40]
000072bd77dd25df  vmovaps xmm5, [rsp+0x50]
000072bd77dd25e5  vmovaps xmm6, [rsp+0x60]
000072bd77dd25eb  vmovaps xmm7, [rsp+0x70]
000072bd77dd25f1  vmovaps xmm8, [rsp+0x80]
000072bd77dd25fa  vmovaps xmm9, [rsp+0x90]
000072bd77dd2603  vmovaps xmm10, [rsp+0xA0]
000072bd77dd260c  vmovaps xmm11, [rsp+0xB0]
000072bd77dd2615  vmovaps xmm12, [rsp+0xC0]
000072bd77dd261e  vmovaps xmm13, [rsp+0xD0]
000072bd77dd2627  vmovaps xmm14, [rsp+0xE0]
000072bd77dd2630  add rsp, 0xF0
000072bd77dd2637  pop r11
000072bd77dd2639  pop r10
000072bd77dd263b  pop r9
000072bd77dd263d  pop r8
000072bd77dd263f  pop rsi
000072bd77dd2640  pop rdi
000072bd77dd2641  pop rdx
000072bd77dd2642  pop rcx
000072bd77dd2643  pop rax
000072bd77dd2644  add rsp, 0x08
000072bd77dd2648  jmp 0x000072BD77DCFCBC
000072bd77dd264d  sub rsp, 0x08
000072bd77dd2651  push rax
000072bd77dd2652  push rcx
000072bd77dd2653  push rdx
000072bd77dd2654  push rdi
000072bd77dd2655  push rsi
000072bd77dd2656  push r8
000072bd77dd2658  push r9
000072bd77dd265a  push r10
000072bd77dd265c  push r11
000072bd77dd265e  sub rsp, 0xF0
000072bd77dd2665  vmovaps [rsp], xmm0
000072bd77dd266a  vmovaps [rsp+0x10], xmm1
000072bd77dd2670  vmovaps [rsp+0x20], xmm2
000072bd77dd2676  vmovaps [rsp+0x30], xmm3
000072bd77dd267c  vmovaps [rsp+0x40], xmm4
000072bd77dd2682  vmovaps [rsp+0x50], xmm5
000072bd77dd2688  vmovaps [rsp+0x60], xmm6
000072bd77dd268e  vmovaps [rsp+0x70], xmm7
000072bd77dd2694  vmovaps [rsp+0x80], xmm8
000072bd77dd269d  vmovaps [rsp+0x90], xmm9
000072bd77dd26a6  vmovaps [rsp+0xA0], xmm10
000072bd77dd26af  vmovaps [rsp+0xB0], xmm12
000072bd77dd26b8  vmovaps [rsp+0xC0], xmm13
000072bd77dd26c1  vmovaps [rsp+0xD0], xmm14
000072bd77dd26ca  vmovaps [rsp+0xE0], xmm15
000072bd77dd26d3  sub rsp, 0x30
000072bd77dd26d7  movaps [rsp], xmm11
000072bd77dd26dc  movaps [rsp+0x10], xmm6
000072bd77dd26e1  movaps [rsp+0x20], xmm14
000072bd77dd26e7  lea rdi, [rsp]
000072bd77dd26eb  mov esi, 0x00
000072bd77dd26f0  mov rax, 0x643206AC3530
000072bd77dd26fa  call rax
000072bd77dd26fc  movaps xmm11, [rsp]
000072bd77dd2701  add rsp, 0x30
000072bd77dd2705  vmovaps xmm0, [rsp]
000072bd77dd270a  vmovaps xmm1, [rsp+0x10]
000072bd77dd2710  vmovaps xmm2, [rsp+0x20]
000072bd77dd2716  vmovaps xmm3, [rsp+0x30]
000072bd77dd271c  vmovaps xmm4, [rsp+0x40]
000072bd77dd2722  vmovaps xmm5, [rsp+0x50]
000072bd77dd2728  vmovaps xmm6, [rsp+0x60]
000072bd77dd272e  vmovaps xmm7, [rsp+0x70]
000072bd77dd2734  vmovaps xmm8, [rsp+0x80]
000072bd77dd273d  vmovaps xmm9, [rsp+0x90]
000072bd77dd2746  vmovaps xmm10, [rsp+0xA0]
000072bd77dd274f  vmovaps xmm12, [rsp+0xB0]
000072bd77dd2758  vmovaps xmm13, [rsp+0xC0]
000072bd77dd2761  vmovaps xmm14, [rsp+0xD0]
000072bd77dd276a  vmovaps xmm15, [rsp+0xE0]
000072bd77dd2773  add rsp, 0xF0
000072bd77dd277a  pop r11
000072bd77dd277c  pop r10
000072bd77dd277e  pop r9
000072bd77dd2780  pop r8
000072bd77dd2782  pop rsi
000072bd77dd2783  pop rdi
000072bd77dd2784  pop rdx
000072bd77dd2785  pop rcx
000072bd77dd2786  pop rax
000072bd77dd2787  add rsp, 0x08
000072bd77dd278b  jmp 0x000072BD77DCFD34
000072bd77dd2790  call 0x000072BD77BFF430
000072bd77dd2795  jmp 0x000072BD77DCFD3E
000072bd77dd279a  sub rsp, 0x08
000072bd77dd279e  push rax
000072bd77dd279f  push rcx
000072bd77dd27a0  push rdx
000072bd77dd27a1  push rdi
000072bd77dd27a2  push rsi
000072bd77dd27a3  push r8
000072bd77dd27a5  push r9
000072bd77dd27a7  push r10
000072bd77dd27a9  push r11
000072bd77dd27ab  sub rsp, 0xF0
000072bd77dd27b2  vmovaps [rsp], xmm0
000072bd77dd27b7  vmovaps [rsp+0x10], xmm1
000072bd77dd27bd  vmovaps [rsp+0x20], xmm2
000072bd77dd27c3  vmovaps [rsp+0x30], xmm3
000072bd77dd27c9  vmovaps [rsp+0x40], xmm4
000072bd77dd27cf  vmovaps [rsp+0x50], xmm5
000072bd77dd27d5  vmovaps [rsp+0x60], xmm6
000072bd77dd27db  vmovaps [rsp+0x70], xmm7
000072bd77dd27e1  vmovaps [rsp+0x80], xmm8
000072bd77dd27ea  vmovaps [rsp+0x90], xmm9
000072bd77dd27f3  vmovaps [rsp+0xA0], xmm10
000072bd77dd27fc  vmovaps [rsp+0xB0], xmm11
000072bd77dd2805  vmovaps [rsp+0xC0], xmm12
000072bd77dd280e  vmovaps [rsp+0xD0], xmm13
000072bd77dd2817  vmovaps [rsp+0xE0], xmm15
000072bd77dd2820  sub rsp, 0x30
000072bd77dd2824  movaps [rsp], xmm14
000072bd77dd2829  movaps [rsp+0x10], xmm6
000072bd77dd282e  movaps [rsp+0x20], xmm2
000072bd77dd2833  lea rdi, [rsp]
000072bd77dd2837  mov esi, 0x00
000072bd77dd283c  mov rax, 0x643206AC3530
000072bd77dd2846  call rax
000072bd77dd2848  movaps xmm14, [rsp]
000072bd77dd284d  add rsp, 0x30
000072bd77dd2851  vmovaps xmm0, [rsp]
000072bd77dd2856  vmovaps xmm1, [rsp+0x10]
000072bd77dd285c  vmovaps xmm2, [rsp+0x20]
000072bd77dd2862  vmovaps xmm3, [rsp+0x30]
000072bd77dd2868  vmovaps xmm4, [rsp+0x40]
000072bd77dd286e  vmovaps xmm5, [rsp+0x50]
000072bd77dd2874  vmovaps xmm6, [rsp+0x60]
000072bd77dd287a  vmovaps xmm7, [rsp+0x70]
000072bd77dd2880  vmovaps xmm8, [rsp+0x80]
000072bd77dd2889  vmovaps xmm9, [rsp+0x90]
000072bd77dd2892  vmovaps xmm10, [rsp+0xA0]
000072bd77dd289b  vmovaps xmm11, [rsp+0xB0]
000072bd77dd28a4  vmovaps xmm12, [rsp+0xC0]
000072bd77dd28ad  vmovaps xmm13, [rsp+0xD0]
000072bd77dd28b6  vmovaps xmm15, [rsp+0xE0]
000072bd77dd28bf  add rsp, 0xF0
000072bd77dd28c6  pop r11
000072bd77dd28c8  pop r10
000072bd77dd28ca  pop r9
000072bd77dd28cc  pop r8
000072bd77dd28ce  pop rsi
000072bd77dd28cf  pop rdi
000072bd77dd28d0  pop rdx
000072bd77dd28d1  pop rcx
000072bd77dd28d2  pop rax
000072bd77dd28d3  add rsp, 0x08
000072bd77dd28d7  jmp 0x000072BD77DCFD72
000072bd77dd28dc  sub rsp, 0x08
000072bd77dd28e0  push rax
000072bd77dd28e1  push rcx
000072bd77dd28e2  push rdx
000072bd77dd28e3  push rdi
000072bd77dd28e4  push rsi
000072bd77dd28e5  push r8
000072bd77dd28e7  push r9
000072bd77dd28e9  push r10
000072bd77dd28eb  push r11
000072bd77dd28ed  sub rsp, 0xF0
000072bd77dd28f4  vmovaps [rsp], xmm0
000072bd77dd28f9  vmovaps [rsp+0x10], xmm1
000072bd77dd28ff  vmovaps [rsp+0x20], xmm2
000072bd77dd2905  vmovaps [rsp+0x30], xmm3
000072bd77dd290b  vmovaps [rsp+0x40], xmm4
000072bd77dd2911  vmovaps [rsp+0x50], xmm5
000072bd77dd2917  vmovaps [rsp+0x60], xmm7
000072bd77dd291d  vmovaps [rsp+0x70], xmm8
000072bd77dd2923  vmovaps [rsp+0x80], xmm9
000072bd77dd292c  vmovaps [rsp+0x90], xmm10
000072bd77dd2935  vmovaps [rsp+0xA0], xmm11
000072bd77dd293e  vmovaps [rsp+0xB0], xmm12
000072bd77dd2947  vmovaps [rsp+0xC0], xmm13
000072bd77dd2950  vmovaps [rsp+0xD0], xmm14
000072bd77dd2959  vmovaps [rsp+0xE0], xmm15
000072bd77dd2962  sub rsp, 0x30
000072bd77dd2966  movaps [rsp], xmm6
000072bd77dd296a  movaps [rsp+0x10], xmm5
000072bd77dd296f  movaps [rsp+0x20], xmm1
000072bd77dd2974  lea rdi, [rsp]
000072bd77dd2978  mov esi, 0x00
000072bd77dd297d  mov rax, 0x643206AC3530
000072bd77dd2987  call rax
000072bd77dd2989  movaps xmm6, [rsp]
000072bd77dd298d  add rsp, 0x30
000072bd77dd2991  vmovaps xmm0, [rsp]
000072bd77dd2996  vmovaps xmm1, [rsp+0x10]
000072bd77dd299c  vmovaps xmm2, [rsp+0x20]
000072bd77dd29a2  vmovaps xmm3, [rsp+0x30]
000072bd77dd29a8  vmovaps xmm4, [rsp+0x40]
000072bd77dd29ae  vmovaps xmm5, [rsp+0x50]
000072bd77dd29b4  vmovaps xmm7, [rsp+0x60]
000072bd77dd29ba  vmovaps xmm8, [rsp+0x70]
000072bd77dd29c0  vmovaps xmm9, [rsp+0x80]
000072bd77dd29c9  vmovaps xmm10, [rsp+0x90]
000072bd77dd29d2  vmovaps xmm11, [rsp+0xA0]
000072bd77dd29db  vmovaps xmm12, [rsp+0xB0]
000072bd77dd29e4  vmovaps xmm13, [rsp+0xC0]
000072bd77dd29ed  vmovaps xmm14, [rsp+0xD0]
000072bd77dd29f6  vmovaps xmm15, [rsp+0xE0]
000072bd77dd29ff  add rsp, 0xF0
000072bd77dd2a06  pop r11
000072bd77dd2a08  pop r10
000072bd77dd2a0a  pop r9
000072bd77dd2a0c  pop r8
000072bd77dd2a0e  pop rsi
000072bd77dd2a0f  pop rdi
000072bd77dd2a10  pop rdx
000072bd77dd2a11  pop rcx
000072bd77dd2a12  pop rax
000072bd77dd2a13  add rsp, 0x08
000072bd77dd2a17  jmp 0x000072BD77DCFD98
000072bd77dd2a1c  sub rsp, 0x08
000072bd77dd2a20  push rax
000072bd77dd2a21  push rcx
000072bd77dd2a22  push rdx
000072bd77dd2a23  push rdi
000072bd77dd2a24  push rsi
000072bd77dd2a25  push r8
000072bd77dd2a27  push r9
000072bd77dd2a29  push r10
000072bd77dd2a2b  push r11
000072bd77dd2a2d  sub rsp, 0xF0
000072bd77dd2a34  vmovaps [rsp], xmm0
000072bd77dd2a39  vmovaps [rsp+0x10], xmm2
000072bd77dd2a3f  vmovaps [rsp+0x20], xmm3
000072bd77dd2a45  vmovaps [rsp+0x30], xmm4
000072bd77dd2a4b  vmovaps [rsp+0x40], xmm5
000072bd77dd2a51  vmovaps [rsp+0x50], xmm6
000072bd77dd2a57  vmovaps [rsp+0x60], xmm7
000072bd77dd2a5d  vmovaps [rsp+0x70], xmm8
000072bd77dd2a63  vmovaps [rsp+0x80], xmm9
000072bd77dd2a6c  vmovaps [rsp+0x90], xmm10
000072bd77dd2a75  vmovaps [rsp+0xA0], xmm11
000072bd77dd2a7e  vmovaps [rsp+0xB0], xmm12
000072bd77dd2a87  vmovaps [rsp+0xC0], xmm13
000072bd77dd2a90  vmovaps [rsp+0xD0], xmm14
000072bd77dd2a99  vmovaps [rsp+0xE0], xmm15
000072bd77dd2aa2  sub rsp, 0x30
000072bd77dd2aa6  movaps [rsp], xmm1
000072bd77dd2aaa  movaps [rsp+0x10], xmm5
000072bd77dd2aaf  movaps [rsp+0x20], xmm13
000072bd77dd2ab5  lea rdi, [rsp]
000072bd77dd2ab9  mov esi, 0x00
000072bd77dd2abe  mov rax, 0x643206AC3530
000072bd77dd2ac8  call rax
000072bd77dd2aca  movaps xmm1, [rsp]
000072bd77dd2ace  add rsp, 0x30
000072bd77dd2ad2  vmovaps xmm0, [rsp]
000072bd77dd2ad7  vmovaps xmm2, [rsp+0x10]
000072bd77dd2add  vmovaps xmm3, [rsp+0x20]
000072bd77dd2ae3  vmovaps xmm4, [rsp+0x30]
000072bd77dd2ae9  vmovaps xmm5, [rsp+0x40]
000072bd77dd2aef  vmovaps xmm6, [rsp+0x50]
000072bd77dd2af5  vmovaps xmm7, [rsp+0x60]
000072bd77dd2afb  vmovaps xmm8, [rsp+0x70]
000072bd77dd2b01  vmovaps xmm9, [rsp+0x80]
000072bd77dd2b0a  vmovaps xmm10, [rsp+0x90]
000072bd77dd2b13  vmovaps xmm11, [rsp+0xA0]
000072bd77dd2b1c  vmovaps xmm12, [rsp+0xB0]
000072bd77dd2b25  vmovaps xmm13, [rsp+0xC0]
000072bd77dd2b2e  vmovaps xmm14, [rsp+0xD0]
000072bd77dd2b37  vmovaps xmm15, [rsp+0xE0]
000072bd77dd2b40  add rsp, 0xF0
000072bd77dd2b47  pop r11
000072bd77dd2b49  pop r10
000072bd77dd2b4b  pop r9
000072bd77dd2b4d  pop r8
000072bd77dd2b4f  pop rsi
000072bd77dd2b50  pop rdi
000072bd77dd2b51  pop rdx
000072bd77dd2b52  pop rcx
000072bd77dd2b53  pop rax
000072bd77dd2b54  add rsp, 0x08
000072bd77dd2b58  jmp 0x000072BD77DCFDB6
000072bd77dd2b5d  sub rsp, 0x08
000072bd77dd2b61  push rax
000072bd77dd2b62  push rcx
000072bd77dd2b63  push rdx
000072bd77dd2b64  push rdi
000072bd77dd2b65  push rsi
000072bd77dd2b66  push r8
000072bd77dd2b68  push r9
000072bd77dd2b6a  push r10
000072bd77dd2b6c  push r11
000072bd77dd2b6e  sub rsp, 0xF0
000072bd77dd2b75  vmovaps [rsp], xmm0
000072bd77dd2b7a  vmovaps [rsp+0x10], xmm1
000072bd77dd2b80  vmovaps [rsp+0x20], xmm2
000072bd77dd2b86  vmovaps [rsp+0x30], xmm3
000072bd77dd2b8c  vmovaps [rsp+0x40], xmm4
000072bd77dd2b92  vmovaps [rsp+0x50], xmm6
000072bd77dd2b98  vmovaps [rsp+0x60], xmm7
000072bd77dd2b9e  vmovaps [rsp+0x70], xmm8
000072bd77dd2ba4  vmovaps [rsp+0x80], xmm9
000072bd77dd2bad  vmovaps [rsp+0x90], xmm10
000072bd77dd2bb6  vmovaps [rsp+0xA0], xmm11
000072bd77dd2bbf  vmovaps [rsp+0xB0], xmm12
000072bd77dd2bc8  vmovaps [rsp+0xC0], xmm13
000072bd77dd2bd1  vmovaps [rsp+0xD0], xmm14
000072bd77dd2bda  vmovaps [rsp+0xE0], xmm15
000072bd77dd2be3  sub rsp, 0x30
000072bd77dd2be7  movaps [rsp], xmm5
000072bd77dd2beb  movaps [rsp+0x10], xmm2
000072bd77dd2bf0  movaps [rsp+0x20], xmm13
000072bd77dd2bf6  lea rdi, [rsp]
000072bd77dd2bfa  mov esi, 0x00
000072bd77dd2bff  mov rax, 0x643206AC3530
000072bd77dd2c09  call rax
000072bd77dd2c0b  movaps xmm5, [rsp]
000072bd77dd2c0f  add rsp, 0x30
000072bd77dd2c13  vmovaps xmm0, [rsp]
000072bd77dd2c18  vmovaps xmm1, [rsp+0x10]
000072bd77dd2c1e  vmovaps xmm2, [rsp+0x20]
000072bd77dd2c24  vmovaps xmm3, [rsp+0x30]
000072bd77dd2c2a  vmovaps xmm4, [rsp+0x40]
000072bd77dd2c30  vmovaps xmm6, [rsp+0x50]
000072bd77dd2c36  vmovaps xmm7, [rsp+0x60]
000072bd77dd2c3c  vmovaps xmm8, [rsp+0x70]
000072bd77dd2c42  vmovaps xmm9, [rsp+0x80]
000072bd77dd2c4b  vmovaps xmm10, [rsp+0x90]
000072bd77dd2c54  vmovaps xmm11, [rsp+0xA0]
000072bd77dd2c5d  vmovaps xmm12, [rsp+0xB0]
000072bd77dd2c66  vmovaps xmm13, [rsp+0xC0]
000072bd77dd2c6f  vmovaps xmm14, [rsp+0xD0]
000072bd77dd2c78  vmovaps xmm15, [rsp+0xE0]
000072bd77dd2c81  add rsp, 0xF0
000072bd77dd2c88  pop r11
000072bd77dd2c8a  pop r10
000072bd77dd2c8c  pop r9
000072bd77dd2c8e  pop r8
000072bd77dd2c90  pop rsi
000072bd77dd2c91  pop rdi
000072bd77dd2c92  pop rdx
000072bd77dd2c93  pop rcx
000072bd77dd2c94  pop rax
000072bd77dd2c95  add rsp, 0x08
000072bd77dd2c99  jmp 0x000072BD77DCFDEC
000072bd77dd2c9e  sub rsp, 0x08
000072bd77dd2ca2  push rax
000072bd77dd2ca3  push rcx
000072bd77dd2ca4  push rdx
000072bd77dd2ca5  push rdi
000072bd77dd2ca6  push rsi
000072bd77dd2ca7  push r8
000072bd77dd2ca9  push r9
000072bd77dd2cab  push r10
000072bd77dd2cad  push r11
000072bd77dd2caf  sub rsp, 0xF0
000072bd77dd2cb6  vmovaps [rsp], xmm0
000072bd77dd2cbb  vmovaps [rsp+0x10], xmm1
000072bd77dd2cc1  vmovaps [rsp+0x20], xmm2
000072bd77dd2cc7  vmovaps [rsp+0x30], xmm3
000072bd77dd2ccd  vmovaps [rsp+0x40], xmm4
000072bd77dd2cd3  vmovaps [rsp+0x50], xmm5
000072bd77dd2cd9  vmovaps [rsp+0x60], xmm6
000072bd77dd2cdf  vmovaps [rsp+0x70], xmm7
000072bd77dd2ce5  vmovaps [rsp+0x80], xmm8
000072bd77dd2cee  vmovaps [rsp+0x90], xmm9
000072bd77dd2cf7  vmovaps [rsp+0xA0], xmm10
000072bd77dd2d00  vmovaps [rsp+0xB0], xmm11
000072bd77dd2d09  vmovaps [rsp+0xC0], xmm12
000072bd77dd2d12  vmovaps [rsp+0xD0], xmm14
000072bd77dd2d1b  vmovaps [rsp+0xE0], xmm15
000072bd77dd2d24  sub rsp, 0x30
000072bd77dd2d28  movaps [rsp], xmm13
000072bd77dd2d2d  movaps [rsp+0x10], xmm10
000072bd77dd2d33  movaps [rsp+0x20], xmm1
000072bd77dd2d38  lea rdi, [rsp]
000072bd77dd2d3c  mov esi, 0x00
000072bd77dd2d41  mov rax, 0x643206AC3530
000072bd77dd2d4b  call rax
000072bd77dd2d4d  movaps xmm13, [rsp]
000072bd77dd2d52  add rsp, 0x30
000072bd77dd2d56  vmovaps xmm0, [rsp]
000072bd77dd2d5b  vmovaps xmm1, [rsp+0x10]
000072bd77dd2d61  vmovaps xmm2, [rsp+0x20]
000072bd77dd2d67  vmovaps xmm3, [rsp+0x30]
000072bd77dd2d6d  vmovaps xmm4, [rsp+0x40]
000072bd77dd2d73  vmovaps xmm5, [rsp+0x50]
000072bd77dd2d79  vmovaps xmm6, [rsp+0x60]
000072bd77dd2d7f  vmovaps xmm7, [rsp+0x70]
000072bd77dd2d85  vmovaps xmm8, [rsp+0x80]
000072bd77dd2d8e  vmovaps xmm9, [rsp+0x90]
000072bd77dd2d97  vmovaps xmm10, [rsp+0xA0]
000072bd77dd2da0  vmovaps xmm11, [rsp+0xB0]
000072bd77dd2da9  vmovaps xmm12, [rsp+0xC0]
000072bd77dd2db2  vmovaps xmm14, [rsp+0xD0]
000072bd77dd2dbb  vmovaps xmm15, [rsp+0xE0]
000072bd77dd2dc4  add rsp, 0xF0
000072bd77dd2dcb  pop r11
000072bd77dd2dcd  pop r10
000072bd77dd2dcf  pop r9
000072bd77dd2dd1  pop r8
000072bd77dd2dd3  pop rsi
000072bd77dd2dd4  pop rdi
000072bd77dd2dd5  pop rdx
000072bd77dd2dd6  pop rcx
000072bd77dd2dd7  pop rax
000072bd77dd2dd8  add rsp, 0x08
000072bd77dd2ddc  jmp 0x000072BD77DCFE15
000072bd77dd2de1  sub rsp, 0x08
000072bd77dd2de5  push rax
000072bd77dd2de6  push rcx
000072bd77dd2de7  push rdx
000072bd77dd2de8  push rdi
000072bd77dd2de9  push rsi
000072bd77dd2dea  push r8
000072bd77dd2dec  push r9
000072bd77dd2dee  push r10
000072bd77dd2df0  push r11
000072bd77dd2df2  sub rsp, 0xF0
000072bd77dd2df9  vmovaps [rsp], xmm0
000072bd77dd2dfe  vmovaps [rsp+0x10], xmm2
000072bd77dd2e04  vmovaps [rsp+0x20], xmm3
000072bd77dd2e0a  vmovaps [rsp+0x30], xmm4
000072bd77dd2e10  vmovaps [rsp+0x40], xmm5
000072bd77dd2e16  vmovaps [rsp+0x50], xmm6
000072bd77dd2e1c  vmovaps [rsp+0x60], xmm7
000072bd77dd2e22  vmovaps [rsp+0x70], xmm8
000072bd77dd2e28  vmovaps [rsp+0x80], xmm9
000072bd77dd2e31  vmovaps [rsp+0x90], xmm10
000072bd77dd2e3a  vmovaps [rsp+0xA0], xmm11
000072bd77dd2e43  vmovaps [rsp+0xB0], xmm12
000072bd77dd2e4c  vmovaps [rsp+0xC0], xmm13
000072bd77dd2e55  vmovaps [rsp+0xD0], xmm14
000072bd77dd2e5e  vmovaps [rsp+0xE0], xmm15
000072bd77dd2e67  sub rsp, 0x30
000072bd77dd2e6b  movaps [rsp], xmm1
000072bd77dd2e6f  movaps [rsp+0x10], xmm15
000072bd77dd2e75  movaps [rsp+0x20], xmm10
000072bd77dd2e7b  lea rdi, [rsp]
000072bd77dd2e7f  mov esi, 0x00
000072bd77dd2e84  mov rax, 0x643206AC3530
000072bd77dd2e8e  call rax
000072bd77dd2e90  movaps xmm1, [rsp]
000072bd77dd2e94  add rsp, 0x30
000072bd77dd2e98  vmovaps xmm0, [rsp]
000072bd77dd2e9d  vmovaps xmm2, [rsp+0x10]
000072bd77dd2ea3  vmovaps xmm3, [rsp+0x20]
000072bd77dd2ea9  vmovaps xmm4, [rsp+0x30]
000072bd77dd2eaf  vmovaps xmm5, [rsp+0x40]
000072bd77dd2eb5  vmovaps xmm6, [rsp+0x50]
000072bd77dd2ebb  vmovaps xmm7, [rsp+0x60]
000072bd77dd2ec1  vmovaps xmm8, [rsp+0x70]
000072bd77dd2ec7  vmovaps xmm9, [rsp+0x80]
000072bd77dd2ed0  vmovaps xmm10, [rsp+0x90]
000072bd77dd2ed9  vmovaps xmm11, [rsp+0xA0]
000072bd77dd2ee2  vmovaps xmm12, [rsp+0xB0]
000072bd77dd2eeb  vmovaps xmm13, [rsp+0xC0]
000072bd77dd2ef4  vmovaps xmm14, [rsp+0xD0]
000072bd77dd2efd  vmovaps xmm15, [rsp+0xE0]
000072bd77dd2f06  add rsp, 0xF0
000072bd77dd2f0d  pop r11
000072bd77dd2f0f  pop r10
000072bd77dd2f11  pop r9
000072bd77dd2f13  pop r8
000072bd77dd2f15  pop rsi
000072bd77dd2f16  pop rdi
000072bd77dd2f17  pop rdx
000072bd77dd2f18  pop rcx
000072bd77dd2f19  pop rax
000072bd77dd2f1a  add rsp, 0x08
000072bd77dd2f1e  jmp 0x000072BD77DCFE34
000072bd77dd2f23  sub rsp, 0x08
000072bd77dd2f27  push rax
000072bd77dd2f28  push rcx
000072bd77dd2f29  push rdx
000072bd77dd2f2a  push rdi
000072bd77dd2f2b  push rsi
000072bd77dd2f2c  push r8
000072bd77dd2f2e  push r9
000072bd77dd2f30  push r10
000072bd77dd2f32  push r11
000072bd77dd2f34  sub rsp, 0xF0
000072bd77dd2f3b  vmovaps [rsp], xmm0
000072bd77dd2f40  vmovaps [rsp+0x10], xmm1
000072bd77dd2f46  vmovaps [rsp+0x20], xmm2
000072bd77dd2f4c  vmovaps [rsp+0x30], xmm3
000072bd77dd2f52  vmovaps [rsp+0x40], xmm4
000072bd77dd2f58  vmovaps [rsp+0x50], xmm5
000072bd77dd2f5e  vmovaps [rsp+0x60], xmm6
000072bd77dd2f64  vmovaps [rsp+0x70], xmm7
000072bd77dd2f6a  vmovaps [rsp+0x80], xmm8
000072bd77dd2f73  vmovaps [rsp+0x90], xmm9
000072bd77dd2f7c  vmovaps [rsp+0xA0], xmm10
000072bd77dd2f85  vmovaps [rsp+0xB0], xmm11
000072bd77dd2f8e  vmovaps [rsp+0xC0], xmm12
000072bd77dd2f97  vmovaps [rsp+0xD0], xmm13
000072bd77dd2fa0  vmovaps [rsp+0xE0], xmm14
000072bd77dd2fa9  sub rsp, 0x30
000072bd77dd2fad  movaps [rsp], xmm15
000072bd77dd2fb2  movaps [rsp+0x10], xmm10
000072bd77dd2fb8  movaps [rsp+0x20], xmm11
000072bd77dd2fbe  lea rdi, [rsp]
000072bd77dd2fc2  mov esi, 0x00
000072bd77dd2fc7  mov rax, 0x643206AC3530
000072bd77dd2fd1  call rax
000072bd77dd2fd3  movaps xmm15, [rsp]
000072bd77dd2fd8  add rsp, 0x30
000072bd77dd2fdc  vmovaps xmm0, [rsp]
000072bd77dd2fe1  vmovaps xmm1, [rsp+0x10]
000072bd77dd2fe7  vmovaps xmm2, [rsp+0x20]
000072bd77dd2fed  vmovaps xmm3, [rsp+0x30]
000072bd77dd2ff3  vmovaps xmm4, [rsp+0x40]
000072bd77dd2ff9  vmovaps xmm5, [rsp+0x50]
000072bd77dd2fff  vmovaps xmm6, [rsp+0x60]
000072bd77dd3005  vmovaps xmm7, [rsp+0x70]
000072bd77dd300b  vmovaps xmm8, [rsp+0x80]
000072bd77dd3014  vmovaps xmm9, [rsp+0x90]
000072bd77dd301d  vmovaps xmm10, [rsp+0xA0]
000072bd77dd3026  vmovaps xmm11, [rsp+0xB0]
000072bd77dd302f  vmovaps xmm12, [rsp+0xC0]
000072bd77dd3038  vmovaps xmm13, [rsp+0xD0]
000072bd77dd3041  vmovaps xmm14, [rsp+0xE0]
000072bd77dd304a  add rsp, 0xF0
000072bd77dd3051  pop r11
000072bd77dd3053  pop r10
000072bd77dd3055  pop r9
000072bd77dd3057  pop r8
000072bd77dd3059  pop rsi
000072bd77dd305a  pop rdi
000072bd77dd305b  pop rdx
000072bd77dd305c  pop rcx
000072bd77dd305d  pop rax
000072bd77dd305e  add rsp, 0x08
000072bd77dd3062  jmp 0x000072BD77DCFE57
000072bd77dd3067  sub rsp, 0x08
000072bd77dd306b  push rax
000072bd77dd306c  push rcx
000072bd77dd306d  push rdx
000072bd77dd306e  push rdi
000072bd77dd306f  push rsi
000072bd77dd3070  push r8
000072bd77dd3072  push r9
000072bd77dd3074  push r10
000072bd77dd3076  push r11
000072bd77dd3078  sub rsp, 0xF0
000072bd77dd307f  vmovaps [rsp], xmm0
000072bd77dd3084  vmovaps [rsp+0x10], xmm1
000072bd77dd308a  vmovaps [rsp+0x20], xmm2
000072bd77dd3090  vmovaps [rsp+0x30], xmm3
000072bd77dd3096  vmovaps [rsp+0x40], xmm4
000072bd77dd309c  vmovaps [rsp+0x50], xmm5
000072bd77dd30a2  vmovaps [rsp+0x60], xmm6
000072bd77dd30a8  vmovaps [rsp+0x70], xmm7
000072bd77dd30ae  vmovaps [rsp+0x80], xmm8
000072bd77dd30b7  vmovaps [rsp+0x90], xmm9
000072bd77dd30c0  vmovaps [rsp+0xA0], xmm11
000072bd77dd30c9  vmovaps [rsp+0xB0], xmm12
000072bd77dd30d2  vmovaps [rsp+0xC0], xmm13
000072bd77dd30db  vmovaps [rsp+0xD0], xmm14
000072bd77dd30e4  vmovaps [rsp+0xE0], xmm15
000072bd77dd30ed  sub rsp, 0x30
000072bd77dd30f1  movaps [rsp], xmm10
000072bd77dd30f6  movaps [rsp+0x10], xmm12
000072bd77dd30fc  movaps [rsp+0x20], xmm11
000072bd77dd3102  lea rdi, [rsp]
000072bd77dd3106  mov esi, 0x00
000072bd77dd310b  mov rax, 0x643206AC3530
000072bd77dd3115  call rax
000072bd77dd3117  movaps xmm10, [rsp]
000072bd77dd311c  add rsp, 0x30
000072bd77dd3120  vmovaps xmm0, [rsp]
000072bd77dd3125  vmovaps xmm1, [rsp+0x10]
000072bd77dd312b  vmovaps xmm2, [rsp+0x20]
000072bd77dd3131  vmovaps xmm3, [rsp+0x30]
000072bd77dd3137  vmovaps xmm4, [rsp+0x40]
000072bd77dd313d  vmovaps xmm5, [rsp+0x50]
000072bd77dd3143  vmovaps xmm6, [rsp+0x60]
000072bd77dd3149  vmovaps xmm7, [rsp+0x70]
000072bd77dd314f  vmovaps xmm8, [rsp+0x80]
000072bd77dd3158  vmovaps xmm9, [rsp+0x90]
000072bd77dd3161  vmovaps xmm11, [rsp+0xA0]
000072bd77dd316a  vmovaps xmm12, [rsp+0xB0]
000072bd77dd3173  vmovaps xmm13, [rsp+0xC0]
000072bd77dd317c  vmovaps xmm14, [rsp+0xD0]
000072bd77dd3185  vmovaps xmm15, [rsp+0xE0]
000072bd77dd318e  add rsp, 0xF0
000072bd77dd3195  pop r11
000072bd77dd3197  pop r10
000072bd77dd3199  pop r9
000072bd77dd319b  pop r8
000072bd77dd319d  pop rsi
000072bd77dd319e  pop rdi
000072bd77dd319f  pop rdx
000072bd77dd31a0  pop rcx
000072bd77dd31a1  pop rax
000072bd77dd31a2  add rsp, 0x08
000072bd77dd31a6  jmp 0x000072BD77DCFE80
000072bd77dd31ab  sub rsp, 0x08
000072bd77dd31af  push rax
000072bd77dd31b0  push rcx
000072bd77dd31b1  push rdx
000072bd77dd31b2  push rdi
000072bd77dd31b3  push rsi
000072bd77dd31b4  push r8
000072bd77dd31b6  push r9
000072bd77dd31b8  push r10
000072bd77dd31ba  push r11
000072bd77dd31bc  sub rsp, 0xF0
000072bd77dd31c3  vmovaps [rsp], xmm0
000072bd77dd31c8  vmovaps [rsp+0x10], xmm1
000072bd77dd31ce  vmovaps [rsp+0x20], xmm2
000072bd77dd31d4  vmovaps [rsp+0x30], xmm3
000072bd77dd31da  vmovaps [rsp+0x40], xmm4
000072bd77dd31e0  vmovaps [rsp+0x50], xmm5
000072bd77dd31e6  vmovaps [rsp+0x60], xmm6
000072bd77dd31ec  vmovaps [rsp+0x70], xmm7
000072bd77dd31f2  vmovaps [rsp+0x80], xmm8
000072bd77dd31fb  vmovaps [rsp+0x90], xmm9
000072bd77dd3204  vmovaps [rsp+0xA0], xmm10
000072bd77dd320d  vmovaps [rsp+0xB0], xmm12
000072bd77dd3216  vmovaps [rsp+0xC0], xmm13
000072bd77dd321f  vmovaps [rsp+0xD0], xmm14
000072bd77dd3228  vmovaps [rsp+0xE0], xmm15
000072bd77dd3231  sub rsp, 0x30
000072bd77dd3235  movaps [rsp], xmm11
000072bd77dd323a  movaps [rsp+0x10], xmm2
000072bd77dd323f  movaps [rsp+0x20], xmm12
000072bd77dd3245  lea rdi, [rsp]
000072bd77dd3249  mov esi, 0x00
000072bd77dd324e  mov rax, 0x643206AC3530
000072bd77dd3258  call rax
000072bd77dd325a  movaps xmm11, [rsp]
000072bd77dd325f  add rsp, 0x30
000072bd77dd3263  vmovaps xmm0, [rsp]
000072bd77dd3268  vmovaps xmm1, [rsp+0x10]
000072bd77dd326e  vmovaps xmm2, [rsp+0x20]
000072bd77dd3274  vmovaps xmm3, [rsp+0x30]
000072bd77dd327a  vmovaps xmm4, [rsp+0x40]
000072bd77dd3280  vmovaps xmm5, [rsp+0x50]
000072bd77dd3286  vmovaps xmm6, [rsp+0x60]
000072bd77dd328c  vmovaps xmm7, [rsp+0x70]
000072bd77dd3292  vmovaps xmm8, [rsp+0x80]
000072bd77dd329b  vmovaps xmm9, [rsp+0x90]
000072bd77dd32a4  vmovaps xmm10, [rsp+0xA0]
000072bd77dd32ad  vmovaps xmm12, [rsp+0xB0]
000072bd77dd32b6  vmovaps xmm13, [rsp+0xC0]
000072bd77dd32bf  vmovaps xmm14, [rsp+0xD0]
000072bd77dd32c8  vmovaps xmm15, [rsp+0xE0]
000072bd77dd32d1  add rsp, 0xF0
000072bd77dd32d8  pop r11
000072bd77dd32da  pop r10
000072bd77dd32dc  pop r9
000072bd77dd32de  pop r8
000072bd77dd32e0  pop rsi
000072bd77dd32e1  pop rdi
000072bd77dd32e2  pop rdx
000072bd77dd32e3  pop rcx
000072bd77dd32e4  pop rax
000072bd77dd32e5  add rsp, 0x08
000072bd77dd32e9  jmp 0x000072BD77DCFEB8
000072bd77dd32ee  sub rsp, 0x08
000072bd77dd32f2  push rax
000072bd77dd32f3  push rcx
000072bd77dd32f4  push rdx
000072bd77dd32f5  push rdi
000072bd77dd32f6  push rsi
000072bd77dd32f7  push r8
000072bd77dd32f9  push r9
000072bd77dd32fb  push r10
000072bd77dd32fd  push r11
000072bd77dd32ff  sub rsp, 0xF0
000072bd77dd3306  vmovaps [rsp], xmm0
000072bd77dd330b  vmovaps [rsp+0x10], xmm2
000072bd77dd3311  vmovaps [rsp+0x20], xmm3
000072bd77dd3317  vmovaps [rsp+0x30], xmm4
000072bd77dd331d  vmovaps [rsp+0x40], xmm5
000072bd77dd3323  vmovaps [rsp+0x50], xmm6
000072bd77dd3329  vmovaps [rsp+0x60], xmm7
000072bd77dd332f  vmovaps [rsp+0x70], xmm8
000072bd77dd3335  vmovaps [rsp+0x80], xmm9
000072bd77dd333e  vmovaps [rsp+0x90], xmm10
000072bd77dd3347  vmovaps [rsp+0xA0], xmm11
000072bd77dd3350  vmovaps [rsp+0xB0], xmm12
000072bd77dd3359  vmovaps [rsp+0xC0], xmm13
000072bd77dd3362  vmovaps [rsp+0xD0], xmm14
000072bd77dd336b  vmovaps [rsp+0xE0], xmm15
000072bd77dd3374  sub rsp, 0x30
000072bd77dd3378  movaps [rsp], xmm1
000072bd77dd337c  movaps [rsp+0x10], xmm14
000072bd77dd3382  movaps [rsp+0x20], xmm6
000072bd77dd3387  lea rdi, [rsp]
000072bd77dd338b  mov esi, 0x00
000072bd77dd3390  mov rax, 0x643206AC3530
000072bd77dd339a  call rax
000072bd77dd339c  movaps xmm1, [rsp]
000072bd77dd33a0  add rsp, 0x30
000072bd77dd33a4  vmovaps xmm0, [rsp]
000072bd77dd33a9  vmovaps xmm2, [rsp+0x10]
000072bd77dd33af  vmovaps xmm3, [rsp+0x20]
000072bd77dd33b5  vmovaps xmm4, [rsp+0x30]
000072bd77dd33bb  vmovaps xmm5, [rsp+0x40]
000072bd77dd33c1  vmovaps xmm6, [rsp+0x50]
000072bd77dd33c7  vmovaps xmm7, [rsp+0x60]
000072bd77dd33cd  vmovaps xmm8, [rsp+0x70]
000072bd77dd33d3  vmovaps xmm9, [rsp+0x80]
000072bd77dd33dc  vmovaps xmm10, [rsp+0x90]
000072bd77dd33e5  vmovaps xmm11, [rsp+0xA0]
000072bd77dd33ee  vmovaps xmm12, [rsp+0xB0]
000072bd77dd33f7  vmovaps xmm13, [rsp+0xC0]
000072bd77dd3400  vmovaps xmm14, [rsp+0xD0]
000072bd77dd3409  vmovaps xmm15, [rsp+0xE0]
000072bd77dd3412  add rsp, 0xF0
000072bd77dd3419  pop r11
000072bd77dd341b  pop r10
000072bd77dd341d  pop r9
000072bd77dd341f  pop r8
000072bd77dd3421  pop rsi
000072bd77dd3422  pop rdi
000072bd77dd3423  pop rdx
000072bd77dd3424  pop rcx
000072bd77dd3425  pop rax
000072bd77dd3426  add rsp, 0x08
000072bd77dd342a  jmp 0x000072BD77DCFED1
000072bd77dd342f  sub rsp, 0x08
000072bd77dd3433  push rax
000072bd77dd3434  push rcx
000072bd77dd3435  push rdx
000072bd77dd3436  push rdi
000072bd77dd3437  push rsi
000072bd77dd3438  push r8
000072bd77dd343a  push r9
000072bd77dd343c  push r10
000072bd77dd343e  push r11
000072bd77dd3440  sub rsp, 0xF0
000072bd77dd3447  vmovaps [rsp], xmm0
000072bd77dd344c  vmovaps [rsp+0x10], xmm1
000072bd77dd3452  vmovaps [rsp+0x20], xmm2
000072bd77dd3458  vmovaps [rsp+0x30], xmm3
000072bd77dd345e  vmovaps [rsp+0x40], xmm4
000072bd77dd3464  vmovaps [rsp+0x50], xmm5
000072bd77dd346a  vmovaps [rsp+0x60], xmm6
000072bd77dd3470  vmovaps [rsp+0x70], xmm7
000072bd77dd3476  vmovaps [rsp+0x80], xmm8
000072bd77dd347f  vmovaps [rsp+0x90], xmm9
000072bd77dd3488  vmovaps [rsp+0xA0], xmm10
000072bd77dd3491  vmovaps [rsp+0xB0], xmm11
000072bd77dd349a  vmovaps [rsp+0xC0], xmm12
000072bd77dd34a3  vmovaps [rsp+0xD0], xmm13
000072bd77dd34ac  vmovaps [rsp+0xE0], xmm15
000072bd77dd34b5  sub rsp, 0x30
000072bd77dd34b9  movaps [rsp], xmm14
000072bd77dd34be  movaps [rsp+0x10], xmm12
000072bd77dd34c4  movaps [rsp+0x20], xmm5
000072bd77dd34c9  lea rdi, [rsp]
000072bd77dd34cd  mov esi, 0x00
000072bd77dd34d2  mov rax, 0x643206AC3530
000072bd77dd34dc  call rax
000072bd77dd34de  movaps xmm14, [rsp]
000072bd77dd34e3  add rsp, 0x30
000072bd77dd34e7  vmovaps xmm0, [rsp]
000072bd77dd34ec  vmovaps xmm1, [rsp+0x10]
000072bd77dd34f2  vmovaps xmm2, [rsp+0x20]
000072bd77dd34f8  vmovaps xmm3, [rsp+0x30]
000072bd77dd34fe  vmovaps xmm4, [rsp+0x40]
000072bd77dd3504  vmovaps xmm5, [rsp+0x50]
000072bd77dd350a  vmovaps xmm6, [rsp+0x60]
000072bd77dd3510  vmovaps xmm7, [rsp+0x70]
000072bd77dd3516  vmovaps xmm8, [rsp+0x80]
000072bd77dd351f  vmovaps xmm9, [rsp+0x90]
000072bd77dd3528  vmovaps xmm10, [rsp+0xA0]
000072bd77dd3531  vmovaps xmm11, [rsp+0xB0]
000072bd77dd353a  vmovaps xmm12, [rsp+0xC0]
000072bd77dd3543  vmovaps xmm13, [rsp+0xD0]
000072bd77dd354c  vmovaps xmm15, [rsp+0xE0]
000072bd77dd3555  add rsp, 0xF0
000072bd77dd355c  pop r11
000072bd77dd355e  pop r10
000072bd77dd3560  pop r9
000072bd77dd3562  pop r8
000072bd77dd3564  pop rsi
000072bd77dd3565  pop rdi
000072bd77dd3566  pop rdx
000072bd77dd3567  pop rcx
000072bd77dd3568  pop rax
000072bd77dd3569  add rsp, 0x08
000072bd77dd356d  jmp 0x000072BD77DCFEF1
000072bd77dd3572  sub rsp, 0x08
000072bd77dd3576  push rax
000072bd77dd3577  push rcx
000072bd77dd3578  push rdx
000072bd77dd3579  push rdi
000072bd77dd357a  push rsi
000072bd77dd357b  push r8
000072bd77dd357d  push r9
000072bd77dd357f  push r10
000072bd77dd3581  push r11
000072bd77dd3583  sub rsp, 0xF0
000072bd77dd358a  vmovaps [rsp], xmm0
000072bd77dd358f  vmovaps [rsp+0x10], xmm1
000072bd77dd3595  vmovaps [rsp+0x20], xmm2
000072bd77dd359b  vmovaps [rsp+0x30], xmm3
000072bd77dd35a1  vmovaps [rsp+0x40], xmm4
000072bd77dd35a7  vmovaps [rsp+0x50], xmm5
000072bd77dd35ad  vmovaps [rsp+0x60], xmm7
000072bd77dd35b3  vmovaps [rsp+0x70], xmm8
000072bd77dd35b9  vmovaps [rsp+0x80], xmm9
000072bd77dd35c2  vmovaps [rsp+0x90], xmm10
000072bd77dd35cb  vmovaps [rsp+0xA0], xmm11
000072bd77dd35d4  vmovaps [rsp+0xB0], xmm12
000072bd77dd35dd  vmovaps [rsp+0xC0], xmm13
000072bd77dd35e6  vmovaps [rsp+0xD0], xmm14
000072bd77dd35ef  vmovaps [rsp+0xE0], xmm15
000072bd77dd35f8  sub rsp, 0x30
000072bd77dd35fc  movaps [rsp], xmm6
000072bd77dd3600  movaps [rsp+0x10], xmm9
000072bd77dd3606  movaps [rsp+0x20], xmm12
000072bd77dd360c  lea rdi, [rsp]
000072bd77dd3610  mov esi, 0x00
000072bd77dd3615  mov rax, 0x643206AC3530
000072bd77dd361f  call rax
000072bd77dd3621  movaps xmm6, [rsp]
000072bd77dd3625  add rsp, 0x30
000072bd77dd3629  vmovaps xmm0, [rsp]
000072bd77dd362e  vmovaps xmm1, [rsp+0x10]
000072bd77dd3634  vmovaps xmm2, [rsp+0x20]
000072bd77dd363a  vmovaps xmm3, [rsp+0x30]
000072bd77dd3640  vmovaps xmm4, [rsp+0x40]
000072bd77dd3646  vmovaps xmm5, [rsp+0x50]
000072bd77dd364c  vmovaps xmm7, [rsp+0x60]
000072bd77dd3652  vmovaps xmm8, [rsp+0x70]
000072bd77dd3658  vmovaps xmm9, [rsp+0x80]
000072bd77dd3661  vmovaps xmm10, [rsp+0x90]
000072bd77dd366a  vmovaps xmm11, [rsp+0xA0]
000072bd77dd3673  vmovaps xmm12, [rsp+0xB0]
000072bd77dd367c  vmovaps xmm13, [rsp+0xC0]
000072bd77dd3685  vmovaps xmm14, [rsp+0xD0]
000072bd77dd368e  vmovaps xmm15, [rsp+0xE0]
000072bd77dd3697  add rsp, 0xF0
000072bd77dd369e  pop r11
000072bd77dd36a0  pop r10
000072bd77dd36a2  pop r9
000072bd77dd36a4  pop r8
000072bd77dd36a6  pop rsi
000072bd77dd36a7  pop rdi
000072bd77dd36a8  pop rdx
000072bd77dd36a9  pop rcx
000072bd77dd36aa  pop rax
000072bd77dd36ab  add rsp, 0x08
000072bd77dd36af  jmp 0x000072BD77DCFF19
000072bd77dd36b4  sub rsp, 0x08
000072bd77dd36b8  push rax
000072bd77dd36b9  push rcx
000072bd77dd36ba  push rdx
000072bd77dd36bb  push rdi
000072bd77dd36bc  push rsi
000072bd77dd36bd  push r8
000072bd77dd36bf  push r9
000072bd77dd36c1  push r10
000072bd77dd36c3  push r11
000072bd77dd36c5  sub rsp, 0xF0
000072bd77dd36cc  vmovaps [rsp], xmm0
000072bd77dd36d1  vmovaps [rsp+0x10], xmm1
000072bd77dd36d7  vmovaps [rsp+0x20], xmm2
000072bd77dd36dd  vmovaps [rsp+0x30], xmm3
000072bd77dd36e3  vmovaps [rsp+0x40], xmm4
000072bd77dd36e9  vmovaps [rsp+0x50], xmm5
000072bd77dd36ef  vmovaps [rsp+0x60], xmm6
000072bd77dd36f5  vmovaps [rsp+0x70], xmm7
000072bd77dd36fb  vmovaps [rsp+0x80], xmm8
000072bd77dd3704  vmovaps [rsp+0x90], xmm9
000072bd77dd370d  vmovaps [rsp+0xA0], xmm10
000072bd77dd3716  vmovaps [rsp+0xB0], xmm11
000072bd77dd371f  vmovaps [rsp+0xC0], xmm13
000072bd77dd3728  vmovaps [rsp+0xD0], xmm14
000072bd77dd3731  vmovaps [rsp+0xE0], xmm15
000072bd77dd373a  sub rsp, 0x30
000072bd77dd373e  movaps [rsp], xmm12
000072bd77dd3743  movaps [rsp+0x10], xmm15
000072bd77dd3749  movaps [rsp+0x20], xmm13
000072bd77dd374f  lea rdi, [rsp]
000072bd77dd3753  mov esi, 0x00
000072bd77dd3758  mov rax, 0x643206AC3530
000072bd77dd3762  call rax
000072bd77dd3764  movaps xmm12, [rsp]
000072bd77dd3769  add rsp, 0x30
000072bd77dd376d  vmovaps xmm0, [rsp]
000072bd77dd3772  vmovaps xmm1, [rsp+0x10]
000072bd77dd3778  vmovaps xmm2, [rsp+0x20]
000072bd77dd377e  vmovaps xmm3, [rsp+0x30]
000072bd77dd3784  vmovaps xmm4, [rsp+0x40]
000072bd77dd378a  vmovaps xmm5, [rsp+0x50]
000072bd77dd3790  vmovaps xmm6, [rsp+0x60]
000072bd77dd3796  vmovaps xmm7, [rsp+0x70]
000072bd77dd379c  vmovaps xmm8, [rsp+0x80]
000072bd77dd37a5  vmovaps xmm9, [rsp+0x90]
000072bd77dd37ae  vmovaps xmm10, [rsp+0xA0]
000072bd77dd37b7  vmovaps xmm11, [rsp+0xB0]
000072bd77dd37c0  vmovaps xmm13, [rsp+0xC0]
000072bd77dd37c9  vmovaps xmm14, [rsp+0xD0]
000072bd77dd37d2  vmovaps xmm15, [rsp+0xE0]
000072bd77dd37db  add rsp, 0xF0
000072bd77dd37e2  pop r11
000072bd77dd37e4  pop r10
000072bd77dd37e6  pop r9
000072bd77dd37e8  pop r8
000072bd77dd37ea  pop rsi
000072bd77dd37eb  pop rdi
000072bd77dd37ec  pop rdx
000072bd77dd37ed  pop rcx
000072bd77dd37ee  pop rax
000072bd77dd37ef  add rsp, 0x08
000072bd77dd37f3  jmp 0x000072BD77DCFF34
000072bd77dd37f8  sub rsp, 0x08
000072bd77dd37fc  push rax
000072bd77dd37fd  push rcx
000072bd77dd37fe  push rdx
000072bd77dd37ff  push rdi
000072bd77dd3800  push rsi
000072bd77dd3801  push r8
000072bd77dd3803  push r9
000072bd77dd3805  push r10
000072bd77dd3807  push r11
000072bd77dd3809  sub rsp, 0xF0
000072bd77dd3810  vmovaps [rsp], xmm0
000072bd77dd3815  vmovaps [rsp+0x10], xmm1
000072bd77dd381b  vmovaps [rsp+0x20], xmm2
000072bd77dd3821  vmovaps [rsp+0x30], xmm3
000072bd77dd3827  vmovaps [rsp+0x40], xmm4
000072bd77dd382d  vmovaps [rsp+0x50], xmm5
000072bd77dd3833  vmovaps [rsp+0x60], xmm6
000072bd77dd3839  vmovaps [rsp+0x70], xmm7
000072bd77dd383f  vmovaps [rsp+0x80], xmm8
000072bd77dd3848  vmovaps [rsp+0x90], xmm9
000072bd77dd3851  vmovaps [rsp+0xA0], xmm10
000072bd77dd385a  vmovaps [rsp+0xB0], xmm11
000072bd77dd3863  vmovaps [rsp+0xC0], xmm12
000072bd77dd386c  vmovaps [rsp+0xD0], xmm13
000072bd77dd3875  vmovaps [rsp+0xE0], xmm14
000072bd77dd387e  sub rsp, 0x30
000072bd77dd3882  movaps [rsp], xmm15
000072bd77dd3887  movaps [rsp+0x10], xmm13
000072bd77dd388d  movaps [rsp+0x20], xmm10
000072bd77dd3893  lea rdi, [rsp]
000072bd77dd3897  mov esi, 0x00
000072bd77dd389c  mov rax, 0x643206AC3530
000072bd77dd38a6  call rax
000072bd77dd38a8  movaps xmm15, [rsp]
000072bd77dd38ad  add rsp, 0x30
000072bd77dd38b1  vmovaps xmm0, [rsp]
000072bd77dd38b6  vmovaps xmm1, [rsp+0x10]
000072bd77dd38bc  vmovaps xmm2, [rsp+0x20]
000072bd77dd38c2  vmovaps xmm3, [rsp+0x30]
000072bd77dd38c8  vmovaps xmm4, [rsp+0x40]
000072bd77dd38ce  vmovaps xmm5, [rsp+0x50]
000072bd77dd38d4  vmovaps xmm6, [rsp+0x60]
000072bd77dd38da  vmovaps xmm7, [rsp+0x70]
000072bd77dd38e0  vmovaps xmm8, [rsp+0x80]
000072bd77dd38e9  vmovaps xmm9, [rsp+0x90]
000072bd77dd38f2  vmovaps xmm10, [rsp+0xA0]
000072bd77dd38fb  vmovaps xmm11, [rsp+0xB0]
000072bd77dd3904  vmovaps xmm12, [rsp+0xC0]
000072bd77dd390d  vmovaps xmm13, [rsp+0xD0]
000072bd77dd3916  vmovaps xmm14, [rsp+0xE0]
000072bd77dd391f  add rsp, 0xF0
000072bd77dd3926  pop r11
000072bd77dd3928  pop r10
000072bd77dd392a  pop r9
000072bd77dd392c  pop r8
000072bd77dd392e  pop rsi
000072bd77dd392f  pop rdi
000072bd77dd3930  pop rdx
000072bd77dd3931  pop rcx
000072bd77dd3932  pop rax
000072bd77dd3933  add rsp, 0x08
000072bd77dd3937  jmp 0x000072BD77DCFF55
000072bd77dd393c  call 0x000072BD77C0C260
000072bd77dd3941  jmp 0x000072BD77DCFFB0
000072bd77dd3946  sub rsp, 0x08
000072bd77dd394a  push rax
000072bd77dd394b  push rcx
000072bd77dd394c  push rdx
000072bd77dd394d  push rdi
000072bd77dd394e  push rsi
000072bd77dd394f  push r8
000072bd77dd3951  push r9
000072bd77dd3953  push r10
000072bd77dd3955  push r11
000072bd77dd3957  sub rsp, 0xF0
000072bd77dd395e  vmovaps [rsp], xmm0
000072bd77dd3963  vmovaps [rsp+0x10], xmm1
000072bd77dd3969  vmovaps [rsp+0x20], xmm2
000072bd77dd396f  vmovaps [rsp+0x30], xmm3
000072bd77dd3975  vmovaps [rsp+0x40], xmm4
000072bd77dd397b  vmovaps [rsp+0x50], xmm5
000072bd77dd3981  vmovaps [rsp+0x60], xmm6
000072bd77dd3987  vmovaps [rsp+0x70], xmm7
000072bd77dd398d  vmovaps [rsp+0x80], xmm8
000072bd77dd3996  vmovaps [rsp+0x90], xmm10
000072bd77dd399f  vmovaps [rsp+0xA0], xmm11
000072bd77dd39a8  vmovaps [rsp+0xB0], xmm12
000072bd77dd39b1  vmovaps [rsp+0xC0], xmm13
000072bd77dd39ba  vmovaps [rsp+0xD0], xmm14
000072bd77dd39c3  vmovaps [rsp+0xE0], xmm15
000072bd77dd39cc  sub rsp, 0x30
000072bd77dd39d0  movaps [rsp], xmm9
000072bd77dd39d5  movaps [rsp+0x10], xmm8
000072bd77dd39db  movaps [rsp+0x20], xmm10
000072bd77dd39e1  lea rdi, [rsp]
000072bd77dd39e5  mov esi, 0x00
000072bd77dd39ea  mov rax, 0x643206AC3530
000072bd77dd39f4  call rax
000072bd77dd39f6  movaps xmm9, [rsp]
000072bd77dd39fb  add rsp, 0x30
000072bd77dd39ff  vmovaps xmm0, [rsp]
000072bd77dd3a04  vmovaps xmm1, [rsp+0x10]
000072bd77dd3a0a  vmovaps xmm2, [rsp+0x20]
000072bd77dd3a10  vmovaps xmm3, [rsp+0x30]
000072bd77dd3a16  vmovaps xmm4, [rsp+0x40]
000072bd77dd3a1c  vmovaps xmm5, [rsp+0x50]
000072bd77dd3a22  vmovaps xmm6, [rsp+0x60]
000072bd77dd3a28  vmovaps xmm7, [rsp+0x70]
000072bd77dd3a2e  vmovaps xmm8, [rsp+0x80]
000072bd77dd3a37  vmovaps xmm10, [rsp+0x90]
000072bd77dd3a40  vmovaps xmm11, [rsp+0xA0]
000072bd77dd3a49  vmovaps xmm12, [rsp+0xB0]
000072bd77dd3a52  vmovaps xmm13, [rsp+0xC0]
000072bd77dd3a5b  vmovaps xmm14, [rsp+0xD0]
000072bd77dd3a64  vmovaps xmm15, [rsp+0xE0]
000072bd77dd3a6d  add rsp, 0xF0
000072bd77dd3a74  pop r11
000072bd77dd3a76  pop r10
000072bd77dd3a78  pop r9
000072bd77dd3a7a  pop r8
000072bd77dd3a7c  pop rsi
000072bd77dd3a7d  pop rdi
000072bd77dd3a7e  pop rdx
000072bd77dd3a7f  pop rcx
000072bd77dd3a80  pop rax
000072bd77dd3a81  add rsp, 0x08
000072bd77dd3a85  jmp 0x000072BD77DCFFE1
000072bd77dd3a8a  sub rsp, 0x08
000072bd77dd3a8e  push rax
000072bd77dd3a8f  push rcx
000072bd77dd3a90  push rdx
000072bd77dd3a91  push rdi
000072bd77dd3a92  push rsi
000072bd77dd3a93  push r8
000072bd77dd3a95  push r9
000072bd77dd3a97  push r10
000072bd77dd3a99  push r11
000072bd77dd3a9b  sub rsp, 0xF0
000072bd77dd3aa2  vmovaps [rsp], xmm0
000072bd77dd3aa7  vmovaps [rsp+0x10], xmm1
000072bd77dd3aad  vmovaps [rsp+0x20], xmm2
000072bd77dd3ab3  vmovaps [rsp+0x30], xmm3
000072bd77dd3ab9  vmovaps [rsp+0x40], xmm4
000072bd77dd3abf  vmovaps [rsp+0x50], xmm5
000072bd77dd3ac5  vmovaps [rsp+0x60], xmm6
000072bd77dd3acb  vmovaps [rsp+0x70], xmm7
000072bd77dd3ad1  vmovaps [rsp+0x80], xmm8
000072bd77dd3ada  vmovaps [rsp+0x90], xmm9
000072bd77dd3ae3  vmovaps [rsp+0xA0], xmm11
000072bd77dd3aec  vmovaps [rsp+0xB0], xmm12
000072bd77dd3af5  vmovaps [rsp+0xC0], xmm13
000072bd77dd3afe  vmovaps [rsp+0xD0], xmm14
000072bd77dd3b07  vmovaps [rsp+0xE0], xmm15
000072bd77dd3b10  sub rsp, 0x30
000072bd77dd3b14  movaps [rsp], xmm10
000072bd77dd3b19  movaps [rsp+0x10], xmm1
000072bd77dd3b1e  movaps [rsp+0x20], xmm11
000072bd77dd3b24  lea rdi, [rsp]
000072bd77dd3b28  mov esi, 0x00
000072bd77dd3b2d  mov rax, 0x643206AC3530
000072bd77dd3b37  call rax
000072bd77dd3b39  movaps xmm10, [rsp]
000072bd77dd3b3e  add rsp, 0x30
000072bd77dd3b42  vmovaps xmm0, [rsp]
000072bd77dd3b47  vmovaps xmm1, [rsp+0x10]
000072bd77dd3b4d  vmovaps xmm2, [rsp+0x20]
000072bd77dd3b53  vmovaps xmm3, [rsp+0x30]
000072bd77dd3b59  vmovaps xmm4, [rsp+0x40]
000072bd77dd3b5f  vmovaps xmm5, [rsp+0x50]
000072bd77dd3b65  vmovaps xmm6, [rsp+0x60]
000072bd77dd3b6b  vmovaps xmm7, [rsp+0x70]
000072bd77dd3b71  vmovaps xmm8, [rsp+0x80]
000072bd77dd3b7a  vmovaps xmm9, [rsp+0x90]
000072bd77dd3b83  vmovaps xmm11, [rsp+0xA0]
000072bd77dd3b8c  vmovaps xmm12, [rsp+0xB0]
000072bd77dd3b95  vmovaps xmm13, [rsp+0xC0]
000072bd77dd3b9e  vmovaps xmm14, [rsp+0xD0]
000072bd77dd3ba7  vmovaps xmm15, [rsp+0xE0]
000072bd77dd3bb0  add rsp, 0xF0
000072bd77dd3bb7  pop r11
000072bd77dd3bb9  pop r10
000072bd77dd3bbb  pop r9
000072bd77dd3bbd  pop r8
000072bd77dd3bbf  pop rsi
000072bd77dd3bc0  pop rdi
000072bd77dd3bc1  pop rdx
000072bd77dd3bc2  pop rcx
000072bd77dd3bc3  pop rax
000072bd77dd3bc4  add rsp, 0x08
000072bd77dd3bc8  jmp 0x000072BD77DCFFFC
000072bd77dd3bcd  sub rsp, 0x08
000072bd77dd3bd1  push rax
000072bd77dd3bd2  push rcx
000072bd77dd3bd3  push rdx
000072bd77dd3bd4  push rdi
000072bd77dd3bd5  push rsi
000072bd77dd3bd6  push r8
000072bd77dd3bd8  push r9
000072bd77dd3bda  push r10
000072bd77dd3bdc  push r11
000072bd77dd3bde  sub rsp, 0xF0
000072bd77dd3be5  vmovaps [rsp], xmm0
000072bd77dd3bea  vmovaps [rsp+0x10], xmm2
000072bd77dd3bf0  vmovaps [rsp+0x20], xmm3
000072bd77dd3bf6  vmovaps [rsp+0x30], xmm4
000072bd77dd3bfc  vmovaps [rsp+0x40], xmm5
000072bd77dd3c02  vmovaps [rsp+0x50], xmm6
000072bd77dd3c08  vmovaps [rsp+0x60], xmm7
000072bd77dd3c0e  vmovaps [rsp+0x70], xmm8
000072bd77dd3c14  vmovaps [rsp+0x80], xmm9
000072bd77dd3c1d  vmovaps [rsp+0x90], xmm10
000072bd77dd3c26  vmovaps [rsp+0xA0], xmm11
000072bd77dd3c2f  vmovaps [rsp+0xB0], xmm12
000072bd77dd3c38  vmovaps [rsp+0xC0], xmm13
000072bd77dd3c41  vmovaps [rsp+0xD0], xmm14
000072bd77dd3c4a  vmovaps [rsp+0xE0], xmm15
000072bd77dd3c53  sub rsp, 0x30
000072bd77dd3c57  movaps [rsp], xmm1
000072bd77dd3c5b  movaps [rsp+0x10], xmm14
000072bd77dd3c61  movaps [rsp+0x20], xmm6
000072bd77dd3c66  lea rdi, [rsp]
000072bd77dd3c6a  mov esi, 0x00
000072bd77dd3c6f  mov rax, 0x643206AC3530
000072bd77dd3c79  call rax
000072bd77dd3c7b  movaps xmm1, [rsp]
000072bd77dd3c7f  add rsp, 0x30
000072bd77dd3c83  vmovaps xmm0, [rsp]
000072bd77dd3c88  vmovaps xmm2, [rsp+0x10]
000072bd77dd3c8e  vmovaps xmm3, [rsp+0x20]
000072bd77dd3c94  vmovaps xmm4, [rsp+0x30]
000072bd77dd3c9a  vmovaps xmm5, [rsp+0x40]
000072bd77dd3ca0  vmovaps xmm6, [rsp+0x50]
000072bd77dd3ca6  vmovaps xmm7, [rsp+0x60]
000072bd77dd3cac  vmovaps xmm8, [rsp+0x70]
000072bd77dd3cb2  vmovaps xmm9, [rsp+0x80]
000072bd77dd3cbb  vmovaps xmm10, [rsp+0x90]
000072bd77dd3cc4  vmovaps xmm11, [rsp+0xA0]
000072bd77dd3ccd  vmovaps xmm12, [rsp+0xB0]
000072bd77dd3cd6  vmovaps xmm13, [rsp+0xC0]
000072bd77dd3cdf  vmovaps xmm14, [rsp+0xD0]
000072bd77dd3ce8  vmovaps xmm15, [rsp+0xE0]
000072bd77dd3cf1  add rsp, 0xF0
000072bd77dd3cf8  pop r11
000072bd77dd3cfa  pop r10
000072bd77dd3cfc  pop r9
000072bd77dd3cfe  pop r8
000072bd77dd3d00  pop rsi
000072bd77dd3d01  pop rdi
000072bd77dd3d02  pop rdx
000072bd77dd3d03  pop rcx
000072bd77dd3d04  pop rax
000072bd77dd3d05  add rsp, 0x08
000072bd77dd3d09  jmp 0x000072BD77DD0015
000072bd77dd3d0e  sub rsp, 0x08
000072bd77dd3d12  push rax
000072bd77dd3d13  push rcx
000072bd77dd3d14  push rdx
000072bd77dd3d15  push rdi
000072bd77dd3d16  push rsi
000072bd77dd3d17  push r8
000072bd77dd3d19  push r9
000072bd77dd3d1b  push r10
000072bd77dd3d1d  push r11
000072bd77dd3d1f  sub rsp, 0xF0
000072bd77dd3d26  vmovaps [rsp], xmm0
000072bd77dd3d2b  vmovaps [rsp+0x10], xmm1
000072bd77dd3d31  vmovaps [rsp+0x20], xmm2
000072bd77dd3d37  vmovaps [rsp+0x30], xmm3
000072bd77dd3d3d  vmovaps [rsp+0x40], xmm4
000072bd77dd3d43  vmovaps [rsp+0x50], xmm5
000072bd77dd3d49  vmovaps [rsp+0x60], xmm6
000072bd77dd3d4f  vmovaps [rsp+0x70], xmm7
000072bd77dd3d55  vmovaps [rsp+0x80], xmm8
000072bd77dd3d5e  vmovaps [rsp+0x90], xmm9
000072bd77dd3d67  vmovaps [rsp+0xA0], xmm10
000072bd77dd3d70  vmovaps [rsp+0xB0], xmm12
000072bd77dd3d79  vmovaps [rsp+0xC0], xmm13
000072bd77dd3d82  vmovaps [rsp+0xD0], xmm14
000072bd77dd3d8b  vmovaps [rsp+0xE0], xmm15
000072bd77dd3d94  sub rsp, 0x30
000072bd77dd3d98  movaps [rsp], xmm11
000072bd77dd3d9d  movaps [rsp+0x10], xmm13
000072bd77dd3da3  movaps [rsp+0x20], xmm14
000072bd77dd3da9  lea rdi, [rsp]
000072bd77dd3dad  mov esi, 0x00
000072bd77dd3db2  mov rax, 0x643206AC3530
000072bd77dd3dbc  call rax
000072bd77dd3dbe  movaps xmm11, [rsp]
000072bd77dd3dc3  add rsp, 0x30
000072bd77dd3dc7  vmovaps xmm0, [rsp]
000072bd77dd3dcc  vmovaps xmm1, [rsp+0x10]
000072bd77dd3dd2  vmovaps xmm2, [rsp+0x20]
000072bd77dd3dd8  vmovaps xmm3, [rsp+0x30]
000072bd77dd3dde  vmovaps xmm4, [rsp+0x40]
000072bd77dd3de4  vmovaps xmm5, [rsp+0x50]
000072bd77dd3dea  vmovaps xmm6, [rsp+0x60]
000072bd77dd3df0  vmovaps xmm7, [rsp+0x70]
000072bd77dd3df6  vmovaps xmm8, [rsp+0x80]
000072bd77dd3dff  vmovaps xmm9, [rsp+0x90]
000072bd77dd3e08  vmovaps xmm10, [rsp+0xA0]
000072bd77dd3e11  vmovaps xmm12, [rsp+0xB0]
000072bd77dd3e1a  vmovaps xmm13, [rsp+0xC0]
000072bd77dd3e23  vmovaps xmm14, [rsp+0xD0]
000072bd77dd3e2c  vmovaps xmm15, [rsp+0xE0]
000072bd77dd3e35  add rsp, 0xF0
000072bd77dd3e3c  pop r11
000072bd77dd3e3e  pop r10
000072bd77dd3e40  pop r9
000072bd77dd3e42  pop r8
000072bd77dd3e44  pop rsi
000072bd77dd3e45  pop rdi
000072bd77dd3e46  pop rdx
000072bd77dd3e47  pop rcx
000072bd77dd3e48  pop rax
000072bd77dd3e49  add rsp, 0x08
000072bd77dd3e4d  jmp 0x000072BD77DD003F
000072bd77dd3e52  sub rsp, 0x08
000072bd77dd3e56  push rax
000072bd77dd3e57  push rcx
000072bd77dd3e58  push rdx
000072bd77dd3e59  push rdi
000072bd77dd3e5a  push rsi
000072bd77dd3e5b  push r8
000072bd77dd3e5d  push r9
000072bd77dd3e5f  push r10
000072bd77dd3e61  push r11
000072bd77dd3e63  sub rsp, 0xF0
000072bd77dd3e6a  vmovaps [rsp], xmm0
000072bd77dd3e6f  vmovaps [rsp+0x10], xmm1
000072bd77dd3e75  vmovaps [rsp+0x20], xmm2
000072bd77dd3e7b  vmovaps [rsp+0x30], xmm3
000072bd77dd3e81  vmovaps [rsp+0x40], xmm4
000072bd77dd3e87  vmovaps [rsp+0x50], xmm5
000072bd77dd3e8d  vmovaps [rsp+0x60], xmm6
000072bd77dd3e93  vmovaps [rsp+0x70], xmm7
000072bd77dd3e99  vmovaps [rsp+0x80], xmm8
000072bd77dd3ea2  vmovaps [rsp+0x90], xmm9
000072bd77dd3eab  vmovaps [rsp+0xA0], xmm10
000072bd77dd3eb4  vmovaps [rsp+0xB0], xmm11
000072bd77dd3ebd  vmovaps [rsp+0xC0], xmm12
000072bd77dd3ec6  vmovaps [rsp+0xD0], xmm14
000072bd77dd3ecf  vmovaps [rsp+0xE0], xmm15
000072bd77dd3ed8  sub rsp, 0x30
000072bd77dd3edc  movaps [rsp], xmm13
000072bd77dd3ee1  movaps [rsp+0x10], xmm8
000072bd77dd3ee7  movaps [rsp+0x20], xmm14
000072bd77dd3eed  lea rdi, [rsp]
000072bd77dd3ef1  mov esi, 0x00
000072bd77dd3ef6  mov rax, 0x643206AC3530
000072bd77dd3f00  call rax
000072bd77dd3f02  movaps xmm13, [rsp]
000072bd77dd3f07  add rsp, 0x30
000072bd77dd3f0b  vmovaps xmm0, [rsp]
000072bd77dd3f10  vmovaps xmm1, [rsp+0x10]
000072bd77dd3f16  vmovaps xmm2, [rsp+0x20]
000072bd77dd3f1c  vmovaps xmm3, [rsp+0x30]
000072bd77dd3f22  vmovaps xmm4, [rsp+0x40]
000072bd77dd3f28  vmovaps xmm5, [rsp+0x50]
000072bd77dd3f2e  vmovaps xmm6, [rsp+0x60]
000072bd77dd3f34  vmovaps xmm7, [rsp+0x70]
000072bd77dd3f3a  vmovaps xmm8, [rsp+0x80]
000072bd77dd3f43  vmovaps xmm9, [rsp+0x90]
000072bd77dd3f4c  vmovaps xmm10, [rsp+0xA0]
000072bd77dd3f55  vmovaps xmm11, [rsp+0xB0]
000072bd77dd3f5e  vmovaps xmm12, [rsp+0xC0]
000072bd77dd3f67  vmovaps xmm14, [rsp+0xD0]
000072bd77dd3f70  vmovaps xmm15, [rsp+0xE0]
000072bd77dd3f79  add rsp, 0xF0
000072bd77dd3f80  pop r11
000072bd77dd3f82  pop r10
000072bd77dd3f84  pop r9
000072bd77dd3f86  pop r8
000072bd77dd3f88  pop rsi
000072bd77dd3f89  pop rdi
000072bd77dd3f8a  pop rdx
000072bd77dd3f8b  pop rcx
000072bd77dd3f8c  pop rax
000072bd77dd3f8d  add rsp, 0x08
000072bd77dd3f91  jmp 0x000072BD77DD006E
000072bd77dd3f96  sub rsp, 0x08
000072bd77dd3f9a  push rax
000072bd77dd3f9b  push rcx
000072bd77dd3f9c  push rdx
000072bd77dd3f9d  push rdi
000072bd77dd3f9e  push rsi
000072bd77dd3f9f  push r8
000072bd77dd3fa1  push r9
000072bd77dd3fa3  push r10
000072bd77dd3fa5  push r11
000072bd77dd3fa7  sub rsp, 0xF0
000072bd77dd3fae  vmovaps [rsp], xmm0
000072bd77dd3fb3  vmovaps [rsp+0x10], xmm1
000072bd77dd3fb9  vmovaps [rsp+0x20], xmm2
000072bd77dd3fbf  vmovaps [rsp+0x30], xmm3
000072bd77dd3fc5  vmovaps [rsp+0x40], xmm4
000072bd77dd3fcb  vmovaps [rsp+0x50], xmm5
000072bd77dd3fd1  vmovaps [rsp+0x60], xmm6
000072bd77dd3fd7  vmovaps [rsp+0x70], xmm7
000072bd77dd3fdd  vmovaps [rsp+0x80], xmm9
000072bd77dd3fe6  vmovaps [rsp+0x90], xmm10
000072bd77dd3fef  vmovaps [rsp+0xA0], xmm11
000072bd77dd3ff8  vmovaps [rsp+0xB0], xmm12
000072bd77dd4001  vmovaps [rsp+0xC0], xmm13
000072bd77dd400a  vmovaps [rsp+0xD0], xmm14
000072bd77dd4013  vmovaps [rsp+0xE0], xmm15
000072bd77dd401c  sub rsp, 0x30
000072bd77dd4020  movaps [rsp], xmm8
000072bd77dd4025  movaps [rsp+0x10], xmm7
000072bd77dd402a  movaps [rsp+0x20], xmm14
000072bd77dd4030  lea rdi, [rsp]
000072bd77dd4034  mov esi, 0x00
000072bd77dd4039  mov rax, 0x643206AC3530
000072bd77dd4043  call rax
000072bd77dd4045  movaps xmm8, [rsp]
000072bd77dd404a  add rsp, 0x30
000072bd77dd404e  vmovaps xmm0, [rsp]
000072bd77dd4053  vmovaps xmm1, [rsp+0x10]
000072bd77dd4059  vmovaps xmm2, [rsp+0x20]
000072bd77dd405f  vmovaps xmm3, [rsp+0x30]
000072bd77dd4065  vmovaps xmm4, [rsp+0x40]
000072bd77dd406b  vmovaps xmm5, [rsp+0x50]
000072bd77dd4071  vmovaps xmm6, [rsp+0x60]
000072bd77dd4077  vmovaps xmm7, [rsp+0x70]
000072bd77dd407d  vmovaps xmm9, [rsp+0x80]
000072bd77dd4086  vmovaps xmm10, [rsp+0x90]
000072bd77dd408f  vmovaps xmm11, [rsp+0xA0]
000072bd77dd4098  vmovaps xmm12, [rsp+0xB0]
000072bd77dd40a1  vmovaps xmm13, [rsp+0xC0]
000072bd77dd40aa  vmovaps xmm14, [rsp+0xD0]
000072bd77dd40b3  vmovaps xmm15, [rsp+0xE0]
000072bd77dd40bc  add rsp, 0xF0
000072bd77dd40c3  pop r11
000072bd77dd40c5  pop r10
000072bd77dd40c7  pop r9
000072bd77dd40c9  pop r8
000072bd77dd40cb  pop rsi
000072bd77dd40cc  pop rdi
000072bd77dd40cd  pop rdx
000072bd77dd40ce  pop rcx
000072bd77dd40cf  pop rax
000072bd77dd40d0  add rsp, 0x08
000072bd77dd40d4  jmp 0x000072BD77DD0094
000072bd77dd40d9  sub rsp, 0x08
000072bd77dd40dd  push rax
000072bd77dd40de  push rcx
000072bd77dd40df  push rdx
000072bd77dd40e0  push rdi
000072bd77dd40e1  push rsi
000072bd77dd40e2  push r8
000072bd77dd40e4  push r9
000072bd77dd40e6  push r10
000072bd77dd40e8  push r11
000072bd77dd40ea  sub rsp, 0xF0
000072bd77dd40f1  vmovaps [rsp], xmm0
000072bd77dd40f6  vmovaps [rsp+0x10], xmm1
000072bd77dd40fc  vmovaps [rsp+0x20], xmm2
000072bd77dd4102  vmovaps [rsp+0x30], xmm3
000072bd77dd4108  vmovaps [rsp+0x40], xmm4
000072bd77dd410e  vmovaps [rsp+0x50], xmm5
000072bd77dd4114  vmovaps [rsp+0x60], xmm6
000072bd77dd411a  vmovaps [rsp+0x70], xmm7
000072bd77dd4120  vmovaps [rsp+0x80], xmm8
000072bd77dd4129  vmovaps [rsp+0x90], xmm9
000072bd77dd4132  vmovaps [rsp+0xA0], xmm10
000072bd77dd413b  vmovaps [rsp+0xB0], xmm11
000072bd77dd4144  vmovaps [rsp+0xC0], xmm12
000072bd77dd414d  vmovaps [rsp+0xD0], xmm13
000072bd77dd4156  vmovaps [rsp+0xE0], xmm15
000072bd77dd415f  sub rsp, 0x30
000072bd77dd4163  movaps [rsp], xmm14
000072bd77dd4168  movaps [rsp+0x10], xmm12
000072bd77dd416e  movaps [rsp+0x20], xmm9
000072bd77dd4174  lea rdi, [rsp]
000072bd77dd4178  mov esi, 0x00
000072bd77dd417d  mov rax, 0x643206AC3530
000072bd77dd4187  call rax
000072bd77dd4189  movaps xmm14, [rsp]
000072bd77dd418e  add rsp, 0x30
000072bd77dd4192  vmovaps xmm0, [rsp]
000072bd77dd4197  vmovaps xmm1, [rsp+0x10]
000072bd77dd419d  vmovaps xmm2, [rsp+0x20]
000072bd77dd41a3  vmovaps xmm3, [rsp+0x30]
000072bd77dd41a9  vmovaps xmm4, [rsp+0x40]
000072bd77dd41af  vmovaps xmm5, [rsp+0x50]
000072bd77dd41b5  vmovaps xmm6, [rsp+0x60]
000072bd77dd41bb  vmovaps xmm7, [rsp+0x70]
000072bd77dd41c1  vmovaps xmm8, [rsp+0x80]
000072bd77dd41ca  vmovaps xmm9, [rsp+0x90]
000072bd77dd41d3  vmovaps xmm10, [rsp+0xA0]
000072bd77dd41dc  vmovaps xmm11, [rsp+0xB0]
000072bd77dd41e5  vmovaps xmm12, [rsp+0xC0]
000072bd77dd41ee  vmovaps xmm13, [rsp+0xD0]
000072bd77dd41f7  vmovaps xmm15, [rsp+0xE0]
000072bd77dd4200  add rsp, 0xF0
000072bd77dd4207  pop r11
000072bd77dd4209  pop r10
000072bd77dd420b  pop r9
000072bd77dd420d  pop r8
000072bd77dd420f  pop rsi
000072bd77dd4210  pop rdi
000072bd77dd4211  pop rdx
000072bd77dd4212  pop rcx
000072bd77dd4213  pop rax
000072bd77dd4214  add rsp, 0x08
000072bd77dd4218  jmp 0x000072BD77DD00AE
000072bd77dd421d  sub rsp, 0x08
000072bd77dd4221  push rax
000072bd77dd4222  push rcx
000072bd77dd4223  push rdx
000072bd77dd4224  push rdi
000072bd77dd4225  push rsi
000072bd77dd4226  push r8
000072bd77dd4228  push r9
000072bd77dd422a  push r10
000072bd77dd422c  push r11
000072bd77dd422e  sub rsp, 0xF0
000072bd77dd4235  vmovaps [rsp], xmm0
000072bd77dd423a  vmovaps [rsp+0x10], xmm1
000072bd77dd4240  vmovaps [rsp+0x20], xmm2
000072bd77dd4246  vmovaps [rsp+0x30], xmm3
000072bd77dd424c  vmovaps [rsp+0x40], xmm4
000072bd77dd4252  vmovaps [rsp+0x50], xmm5
000072bd77dd4258  vmovaps [rsp+0x60], xmm6
000072bd77dd425e  vmovaps [rsp+0x70], xmm7
000072bd77dd4264  vmovaps [rsp+0x80], xmm8
000072bd77dd426d  vmovaps [rsp+0x90], xmm10
000072bd77dd4276  vmovaps [rsp+0xA0], xmm11
000072bd77dd427f  vmovaps [rsp+0xB0], xmm12
000072bd77dd4288  vmovaps [rsp+0xC0], xmm13
000072bd77dd4291  vmovaps [rsp+0xD0], xmm14
000072bd77dd429a  vmovaps [rsp+0xE0], xmm15
000072bd77dd42a3  sub rsp, 0x30
000072bd77dd42a7  movaps [rsp], xmm9
000072bd77dd42ac  movaps [rsp+0x10], xmm7
000072bd77dd42b1  movaps [rsp+0x20], xmm12
000072bd77dd42b7  lea rdi, [rsp]
000072bd77dd42bb  mov esi, 0x00
000072bd77dd42c0  mov rax, 0x643206AC3530
000072bd77dd42ca  call rax
000072bd77dd42cc  movaps xmm9, [rsp]
000072bd77dd42d1  add rsp, 0x30
000072bd77dd42d5  vmovaps xmm0, [rsp]
000072bd77dd42da  vmovaps xmm1, [rsp+0x10]
000072bd77dd42e0  vmovaps xmm2, [rsp+0x20]
000072bd77dd42e6  vmovaps xmm3, [rsp+0x30]
000072bd77dd42ec  vmovaps xmm4, [rsp+0x40]
000072bd77dd42f2  vmovaps xmm5, [rsp+0x50]
000072bd77dd42f8  vmovaps xmm6, [rsp+0x60]
000072bd77dd42fe  vmovaps xmm7, [rsp+0x70]
000072bd77dd4304  vmovaps xmm8, [rsp+0x80]
000072bd77dd430d  vmovaps xmm10, [rsp+0x90]
000072bd77dd4316  vmovaps xmm11, [rsp+0xA0]
000072bd77dd431f  vmovaps xmm12, [rsp+0xB0]
000072bd77dd4328  vmovaps xmm13, [rsp+0xC0]
000072bd77dd4331  vmovaps xmm14, [rsp+0xD0]
000072bd77dd433a  vmovaps xmm15, [rsp+0xE0]
000072bd77dd4343  add rsp, 0xF0
000072bd77dd434a  pop r11
000072bd77dd434c  pop r10
000072bd77dd434e  pop r9
000072bd77dd4350  pop r8
000072bd77dd4352  pop rsi
000072bd77dd4353  pop rdi
000072bd77dd4354  pop rdx
000072bd77dd4355  pop rcx
000072bd77dd4356  pop rax
000072bd77dd4357  add rsp, 0x08
000072bd77dd435b  jmp 0x000072BD77DD00DD
000072bd77dd4360  sub rsp, 0x08
000072bd77dd4364  push rax
000072bd77dd4365  push rcx
000072bd77dd4366  push rdx
000072bd77dd4367  push rdi
000072bd77dd4368  push rsi
000072bd77dd4369  push r8
000072bd77dd436b  push r9
000072bd77dd436d  push r10
000072bd77dd436f  push r11
000072bd77dd4371  sub rsp, 0xF0
000072bd77dd4378  vmovaps [rsp], xmm0
000072bd77dd437d  vmovaps [rsp+0x10], xmm1
000072bd77dd4383  vmovaps [rsp+0x20], xmm2
000072bd77dd4389  vmovaps [rsp+0x30], xmm3
000072bd77dd438f  vmovaps [rsp+0x40], xmm4
000072bd77dd4395  vmovaps [rsp+0x50], xmm5
000072bd77dd439b  vmovaps [rsp+0x60], xmm6
000072bd77dd43a1  vmovaps [rsp+0x70], xmm7
000072bd77dd43a7  vmovaps [rsp+0x80], xmm8
000072bd77dd43b0  vmovaps [rsp+0x90], xmm9
000072bd77dd43b9  vmovaps [rsp+0xA0], xmm10
000072bd77dd43c2  vmovaps [rsp+0xB0], xmm11
000072bd77dd43cb  vmovaps [rsp+0xC0], xmm13
000072bd77dd43d4  vmovaps [rsp+0xD0], xmm14
000072bd77dd43dd  vmovaps [rsp+0xE0], xmm15
000072bd77dd43e6  sub rsp, 0x30
000072bd77dd43ea  movaps [rsp], xmm12
000072bd77dd43ef  movaps [rsp+0x10], xmm15
000072bd77dd43f5  movaps [rsp+0x20], xmm11
000072bd77dd43fb  lea rdi, [rsp]
000072bd77dd43ff  mov esi, 0x00
000072bd77dd4404  mov rax, 0x643206AC3530
000072bd77dd440e  call rax
000072bd77dd4410  movaps xmm12, [rsp]
000072bd77dd4415  add rsp, 0x30
000072bd77dd4419  vmovaps xmm0, [rsp]
000072bd77dd441e  vmovaps xmm1, [rsp+0x10]
000072bd77dd4424  vmovaps xmm2, [rsp+0x20]
000072bd77dd442a  vmovaps xmm3, [rsp+0x30]
000072bd77dd4430  vmovaps xmm4, [rsp+0x40]
000072bd77dd4436  vmovaps xmm5, [rsp+0x50]
000072bd77dd443c  vmovaps xmm6, [rsp+0x60]
000072bd77dd4442  vmovaps xmm7, [rsp+0x70]
000072bd77dd4448  vmovaps xmm8, [rsp+0x80]
000072bd77dd4451  vmovaps xmm9, [rsp+0x90]
000072bd77dd445a  vmovaps xmm10, [rsp+0xA0]
000072bd77dd4463  vmovaps xmm11, [rsp+0xB0]
000072bd77dd446c  vmovaps xmm13, [rsp+0xC0]
000072bd77dd4475  vmovaps xmm14, [rsp+0xD0]
000072bd77dd447e  vmovaps xmm15, [rsp+0xE0]
000072bd77dd4487  add rsp, 0xF0
000072bd77dd448e  pop r11
000072bd77dd4490  pop r10
000072bd77dd4492  pop r9
000072bd77dd4494  pop r8
000072bd77dd4496  pop rsi
000072bd77dd4497  pop rdi
000072bd77dd4498  pop rdx
000072bd77dd4499  pop rcx
000072bd77dd449a  pop rax
000072bd77dd449b  add rsp, 0x08
000072bd77dd449f  jmp 0x000072BD77DD00F7
000072bd77dd44a4  sub rsp, 0x08
000072bd77dd44a8  push rax
000072bd77dd44a9  push rcx
000072bd77dd44aa  push rdx
000072bd77dd44ab  push rdi
000072bd77dd44ac  push rsi
000072bd77dd44ad  push r8
000072bd77dd44af  push r9
000072bd77dd44b1  push r10
000072bd77dd44b3  push r11
000072bd77dd44b5  sub rsp, 0xF0
000072bd77dd44bc  vmovaps [rsp], xmm0
000072bd77dd44c1  vmovaps [rsp+0x10], xmm1
000072bd77dd44c7  vmovaps [rsp+0x20], xmm2
000072bd77dd44cd  vmovaps [rsp+0x30], xmm3
000072bd77dd44d3  vmovaps [rsp+0x40], xmm4
000072bd77dd44d9  vmovaps [rsp+0x50], xmm5
000072bd77dd44df  vmovaps [rsp+0x60], xmm6
000072bd77dd44e5  vmovaps [rsp+0x70], xmm7
000072bd77dd44eb  vmovaps [rsp+0x80], xmm8
000072bd77dd44f4  vmovaps [rsp+0x90], xmm9
000072bd77dd44fd  vmovaps [rsp+0xA0], xmm10
000072bd77dd4506  vmovaps [rsp+0xB0], xmm12
000072bd77dd450f  vmovaps [rsp+0xC0], xmm13
000072bd77dd4518  vmovaps [rsp+0xD0], xmm14
000072bd77dd4521  vmovaps [rsp+0xE0], xmm15
000072bd77dd452a  sub rsp, 0x30
000072bd77dd452e  movaps [rsp], xmm11
000072bd77dd4533  movaps [rsp+0x10], xmm7
000072bd77dd4538  movaps [rsp+0x20], xmm15
000072bd77dd453e  lea rdi, [rsp]
000072bd77dd4542  mov esi, 0x00
000072bd77dd4547  mov rax, 0x643206AC3530
000072bd77dd4551  call rax
000072bd77dd4553  movaps xmm11, [rsp]
000072bd77dd4558  add rsp, 0x30
000072bd77dd455c  vmovaps xmm0, [rsp]
000072bd77dd4561  vmovaps xmm1, [rsp+0x10]
000072bd77dd4567  vmovaps xmm2, [rsp+0x20]
000072bd77dd456d  vmovaps xmm3, [rsp+0x30]
000072bd77dd4573  vmovaps xmm4, [rsp+0x40]
000072bd77dd4579  vmovaps xmm5, [rsp+0x50]
000072bd77dd457f  vmovaps xmm6, [rsp+0x60]
000072bd77dd4585  vmovaps xmm7, [rsp+0x70]
000072bd77dd458b  vmovaps xmm8, [rsp+0x80]
000072bd77dd4594  vmovaps xmm9, [rsp+0x90]
000072bd77dd459d  vmovaps xmm10, [rsp+0xA0]
000072bd77dd45a6  vmovaps xmm12, [rsp+0xB0]
000072bd77dd45af  vmovaps xmm13, [rsp+0xC0]
000072bd77dd45b8  vmovaps xmm14, [rsp+0xD0]
000072bd77dd45c1  vmovaps xmm15, [rsp+0xE0]
000072bd77dd45ca  add rsp, 0xF0
000072bd77dd45d1  pop r11
000072bd77dd45d3  pop r10
000072bd77dd45d5  pop r9
000072bd77dd45d7  pop r8
000072bd77dd45d9  pop rsi
000072bd77dd45da  pop rdi
000072bd77dd45db  pop rdx
000072bd77dd45dc  pop rcx
000072bd77dd45dd  pop rax
000072bd77dd45de  add rsp, 0x08
000072bd77dd45e2  jmp 0x000072BD77DD0123
000072bd77dd45e7  sub rsp, 0x08
000072bd77dd45eb  push rax
000072bd77dd45ec  push rcx
000072bd77dd45ed  push rdx
000072bd77dd45ee  push rdi
000072bd77dd45ef  push rsi
000072bd77dd45f0  push r8
000072bd77dd45f2  push r9
000072bd77dd45f4  push r10
000072bd77dd45f6  push r11
000072bd77dd45f8  sub rsp, 0xF0
000072bd77dd45ff  vmovaps [rsp], xmm0
000072bd77dd4604  vmovaps [rsp+0x10], xmm1
000072bd77dd460a  vmovaps [rsp+0x20], xmm2
000072bd77dd4610  vmovaps [rsp+0x30], xmm3
000072bd77dd4616  vmovaps [rsp+0x40], xmm4
000072bd77dd461c  vmovaps [rsp+0x50], xmm5
000072bd77dd4622  vmovaps [rsp+0x60], xmm6
000072bd77dd4628  vmovaps [rsp+0x70], xmm7
000072bd77dd462e  vmovaps [rsp+0x80], xmm8
000072bd77dd4637  vmovaps [rsp+0x90], xmm9
000072bd77dd4640  vmovaps [rsp+0xA0], xmm10
000072bd77dd4649  vmovaps [rsp+0xB0], xmm11
000072bd77dd4652  vmovaps [rsp+0xC0], xmm12
000072bd77dd465b  vmovaps [rsp+0xD0], xmm13
000072bd77dd4664  vmovaps [rsp+0xE0], xmm14
000072bd77dd466d  sub rsp, 0x30
000072bd77dd4671  movaps [rsp], xmm15
000072bd77dd4676  movaps [rsp+0x10], xmm10
000072bd77dd467c  movaps [rsp+0x20], xmm13
000072bd77dd4682  lea rdi, [rsp]
000072bd77dd4686  mov esi, 0x00
000072bd77dd468b  mov rax, 0x643206AC3530
000072bd77dd4695  call rax
000072bd77dd4697  movaps xmm15, [rsp]
000072bd77dd469c  add rsp, 0x30
000072bd77dd46a0  vmovaps xmm0, [rsp]
000072bd77dd46a5  vmovaps xmm1, [rsp+0x10]
000072bd77dd46ab  vmovaps xmm2, [rsp+0x20]
000072bd77dd46b1  vmovaps xmm3, [rsp+0x30]
000072bd77dd46b7  vmovaps xmm4, [rsp+0x40]
000072bd77dd46bd  vmovaps xmm5, [rsp+0x50]
000072bd77dd46c3  vmovaps xmm6, [rsp+0x60]
000072bd77dd46c9  vmovaps xmm7, [rsp+0x70]
000072bd77dd46cf  vmovaps xmm8, [rsp+0x80]
000072bd77dd46d8  vmovaps xmm9, [rsp+0x90]
000072bd77dd46e1  vmovaps xmm10, [rsp+0xA0]
000072bd77dd46ea  vmovaps xmm11, [rsp+0xB0]
000072bd77dd46f3  vmovaps xmm12, [rsp+0xC0]
000072bd77dd46fc  vmovaps xmm13, [rsp+0xD0]
000072bd77dd4705  vmovaps xmm14, [rsp+0xE0]
000072bd77dd470e  add rsp, 0xF0
000072bd77dd4715  pop r11
000072bd77dd4717  pop r10
000072bd77dd4719  pop r9
000072bd77dd471b  pop r8
000072bd77dd471d  pop rsi
000072bd77dd471e  pop rdi
000072bd77dd471f  pop rdx
000072bd77dd4720  pop rcx
000072bd77dd4721  pop rax
000072bd77dd4722  add rsp, 0x08
000072bd77dd4726  jmp 0x000072BD77DD013D
000072bd77dd472b  sub rsp, 0x08
000072bd77dd472f  push rax
000072bd77dd4730  push rcx
000072bd77dd4731  push rdx
000072bd77dd4732  push rdi
000072bd77dd4733  push rsi
000072bd77dd4734  push r8
000072bd77dd4736  push r9
000072bd77dd4738  push r10
000072bd77dd473a  push r11
000072bd77dd473c  sub rsp, 0xF0
000072bd77dd4743  vmovaps [rsp], xmm0
000072bd77dd4748  vmovaps [rsp+0x10], xmm1
000072bd77dd474e  vmovaps [rsp+0x20], xmm2
000072bd77dd4754  vmovaps [rsp+0x30], xmm3
000072bd77dd475a  vmovaps [rsp+0x40], xmm4
000072bd77dd4760  vmovaps [rsp+0x50], xmm5
000072bd77dd4766  vmovaps [rsp+0x60], xmm6
000072bd77dd476c  vmovaps [rsp+0x70], xmm7
000072bd77dd4772  vmovaps [rsp+0x80], xmm8
000072bd77dd477b  vmovaps [rsp+0x90], xmm9
000072bd77dd4784  vmovaps [rsp+0xA0], xmm11
000072bd77dd478d  vmovaps [rsp+0xB0], xmm12
000072bd77dd4796  vmovaps [rsp+0xC0], xmm13
000072bd77dd479f  vmovaps [rsp+0xD0], xmm14
000072bd77dd47a8  vmovaps [rsp+0xE0], xmm15
000072bd77dd47b1  sub rsp, 0x30
000072bd77dd47b5  movaps [rsp], xmm10
000072bd77dd47ba  movaps [rsp+0x10], xmm7
000072bd77dd47bf  movaps [rsp+0x20], xmm13
000072bd77dd47c5  lea rdi, [rsp]
000072bd77dd47c9  mov esi, 0x00
000072bd77dd47ce  mov rax, 0x643206AC3530
000072bd77dd47d8  call rax
000072bd77dd47da  movaps xmm10, [rsp]
000072bd77dd47df  add rsp, 0x30
000072bd77dd47e3  vmovaps xmm0, [rsp]
000072bd77dd47e8  vmovaps xmm1, [rsp+0x10]
000072bd77dd47ee  vmovaps xmm2, [rsp+0x20]
000072bd77dd47f4  vmovaps xmm3, [rsp+0x30]
000072bd77dd47fa  vmovaps xmm4, [rsp+0x40]
000072bd77dd4800  vmovaps xmm5, [rsp+0x50]
000072bd77dd4806  vmovaps xmm6, [rsp+0x60]
000072bd77dd480c  vmovaps xmm7, [rsp+0x70]
000072bd77dd4812  vmovaps xmm8, [rsp+0x80]
000072bd77dd481b  vmovaps xmm9, [rsp+0x90]
000072bd77dd4824  vmovaps xmm11, [rsp+0xA0]
000072bd77dd482d  vmovaps xmm12, [rsp+0xB0]
000072bd77dd4836  vmovaps xmm13, [rsp+0xC0]
000072bd77dd483f  vmovaps xmm14, [rsp+0xD0]
000072bd77dd4848  vmovaps xmm15, [rsp+0xE0]
000072bd77dd4851  add rsp, 0xF0
000072bd77dd4858  pop r11
000072bd77dd485a  pop r10
000072bd77dd485c  pop r9
000072bd77dd485e  pop r8
000072bd77dd4860  pop rsi
000072bd77dd4861  pop rdi
000072bd77dd4862  pop rdx
000072bd77dd4863  pop rcx
000072bd77dd4864  pop rax
000072bd77dd4865  add rsp, 0x08
000072bd77dd4869  jmp 0x000072BD77DD0169
000072bd77dd486e  sub rsp, 0x08
000072bd77dd4872  push rax
000072bd77dd4873  push rcx
000072bd77dd4874  push rdx
000072bd77dd4875  push rdi
000072bd77dd4876  push rsi
000072bd77dd4877  push r8
000072bd77dd4879  push r9
000072bd77dd487b  push r10
000072bd77dd487d  push r11
000072bd77dd487f  sub rsp, 0xF0
000072bd77dd4886  vmovaps [rsp], xmm0
000072bd77dd488b  vmovaps [rsp+0x10], xmm1
000072bd77dd4891  vmovaps [rsp+0x20], xmm2
000072bd77dd4897  vmovaps [rsp+0x30], xmm3
000072bd77dd489d  vmovaps [rsp+0x40], xmm4
000072bd77dd48a3  vmovaps [rsp+0x50], xmm5
000072bd77dd48a9  vmovaps [rsp+0x60], xmm6
000072bd77dd48af  vmovaps [rsp+0x70], xmm7
000072bd77dd48b5  vmovaps [rsp+0x80], xmm8
000072bd77dd48be  vmovaps [rsp+0x90], xmm9
000072bd77dd48c7  vmovaps [rsp+0xA0], xmm10
000072bd77dd48d0  vmovaps [rsp+0xB0], xmm11
000072bd77dd48d9  vmovaps [rsp+0xC0], xmm12
000072bd77dd48e2  vmovaps [rsp+0xD0], xmm14
000072bd77dd48eb  vmovaps [rsp+0xE0], xmm15
000072bd77dd48f4  sub rsp, 0x30
000072bd77dd48f8  movaps [rsp], xmm13
000072bd77dd48fd  movaps [rsp+0x10], xmm1
000072bd77dd4902  movaps [rsp+0x20], xmm8
000072bd77dd4908  lea rdi, [rsp]
000072bd77dd490c  mov esi, 0x00
000072bd77dd4911  mov rax, 0x643206AC3530
000072bd77dd491b  call rax
000072bd77dd491d  movaps xmm13, [rsp]
000072bd77dd4922  add rsp, 0x30
000072bd77dd4926  vmovaps xmm0, [rsp]
000072bd77dd492b  vmovaps xmm1, [rsp+0x10]
000072bd77dd4931  vmovaps xmm2, [rsp+0x20]
000072bd77dd4937  vmovaps xmm3, [rsp+0x30]
000072bd77dd493d  vmovaps xmm4, [rsp+0x40]
000072bd77dd4943  vmovaps xmm5, [rsp+0x50]
000072bd77dd4949  vmovaps xmm6, [rsp+0x60]
000072bd77dd494f  vmovaps xmm7, [rsp+0x70]
000072bd77dd4955  vmovaps xmm8, [rsp+0x80]
000072bd77dd495e  vmovaps xmm9, [rsp+0x90]
000072bd77dd4967  vmovaps xmm10, [rsp+0xA0]
000072bd77dd4970  vmovaps xmm11, [rsp+0xB0]
000072bd77dd4979  vmovaps xmm12, [rsp+0xC0]
000072bd77dd4982  vmovaps xmm14, [rsp+0xD0]
000072bd77dd498b  vmovaps xmm15, [rsp+0xE0]
000072bd77dd4994  add rsp, 0xF0
000072bd77dd499b  pop r11
000072bd77dd499d  pop r10
000072bd77dd499f  pop r9
000072bd77dd49a1  pop r8
000072bd77dd49a3  pop rsi
000072bd77dd49a4  pop rdi
000072bd77dd49a5  pop rdx
000072bd77dd49a6  pop rcx
000072bd77dd49a7  pop rax
000072bd77dd49a8  add rsp, 0x08
000072bd77dd49ac  jmp 0x000072BD77DD0183
000072bd77dd49b1  call 0x000072BD77BFF430
000072bd77dd49b6  jmp 0x000072BD77DD018D
000072bd77dd49bb  sub rsp, 0x08
000072bd77dd49bf  push rax
000072bd77dd49c0  push rcx
000072bd77dd49c1  push rdx
000072bd77dd49c2  push rdi
000072bd77dd49c3  push rsi
000072bd77dd49c4  push r8
000072bd77dd49c6  push r9
000072bd77dd49c8  push r10
000072bd77dd49ca  push r11
000072bd77dd49cc  sub rsp, 0xF0
000072bd77dd49d3  vmovaps [rsp], xmm0
000072bd77dd49d8  vmovaps [rsp+0x10], xmm1
000072bd77dd49de  vmovaps [rsp+0x20], xmm2
000072bd77dd49e4  vmovaps [rsp+0x30], xmm3
000072bd77dd49ea  vmovaps [rsp+0x40], xmm4
000072bd77dd49f0  vmovaps [rsp+0x50], xmm5
000072bd77dd49f6  vmovaps [rsp+0x60], xmm6
000072bd77dd49fc  vmovaps [rsp+0x70], xmm7
000072bd77dd4a02  vmovaps [rsp+0x80], xmm9
000072bd77dd4a0b  vmovaps [rsp+0x90], xmm10
000072bd77dd4a14  vmovaps [rsp+0xA0], xmm11
000072bd77dd4a1d  vmovaps [rsp+0xB0], xmm12
000072bd77dd4a26  vmovaps [rsp+0xC0], xmm13
000072bd77dd4a2f  vmovaps [rsp+0xD0], xmm14
000072bd77dd4a38  vmovaps [rsp+0xE0], xmm15
000072bd77dd4a41  sub rsp, 0x30
000072bd77dd4a45  movaps [rsp], xmm8
000072bd77dd4a4a  movaps [rsp+0x10], xmm14
000072bd77dd4a50  movaps [rsp+0x20], xmm9
000072bd77dd4a56  lea rdi, [rsp]
000072bd77dd4a5a  mov esi, 0x00
000072bd77dd4a5f  mov rax, 0x643206AC3530
000072bd77dd4a69  call rax
000072bd77dd4a6b  movaps xmm8, [rsp]
000072bd77dd4a70  add rsp, 0x30
000072bd77dd4a74  vmovaps xmm0, [rsp]
000072bd77dd4a79  vmovaps xmm1, [rsp+0x10]
000072bd77dd4a7f  vmovaps xmm2, [rsp+0x20]
000072bd77dd4a85  vmovaps xmm3, [rsp+0x30]
000072bd77dd4a8b  vmovaps xmm4, [rsp+0x40]
000072bd77dd4a91  vmovaps xmm5, [rsp+0x50]
000072bd77dd4a97  vmovaps xmm6, [rsp+0x60]
000072bd77dd4a9d  vmovaps xmm7, [rsp+0x70]
000072bd77dd4aa3  vmovaps xmm9, [rsp+0x80]
000072bd77dd4aac  vmovaps xmm10, [rsp+0x90]
000072bd77dd4ab5  vmovaps xmm11, [rsp+0xA0]
000072bd77dd4abe  vmovaps xmm12, [rsp+0xB0]
000072bd77dd4ac7  vmovaps xmm13, [rsp+0xC0]
000072bd77dd4ad0  vmovaps xmm14, [rsp+0xD0]
000072bd77dd4ad9  vmovaps xmm15, [rsp+0xE0]
000072bd77dd4ae2  add rsp, 0xF0
000072bd77dd4ae9  pop r11
000072bd77dd4aeb  pop r10
000072bd77dd4aed  pop r9
000072bd77dd4aef  pop r8
000072bd77dd4af1  pop rsi
000072bd77dd4af2  pop rdi
000072bd77dd4af3  pop rdx
000072bd77dd4af4  pop rcx
000072bd77dd4af5  pop rax
000072bd77dd4af6  add rsp, 0x08
000072bd77dd4afa  jmp 0x000072BD77DD01AF
000072bd77dd4aff  sub rsp, 0x08
000072bd77dd4b03  push rax
000072bd77dd4b04  push rcx
000072bd77dd4b05  push rdx
000072bd77dd4b06  push rdi
000072bd77dd4b07  push rsi
000072bd77dd4b08  push r8
000072bd77dd4b0a  push r9
000072bd77dd4b0c  push r10
000072bd77dd4b0e  push r11
000072bd77dd4b10  sub rsp, 0xF0
000072bd77dd4b17  vmovaps [rsp], xmm0
000072bd77dd4b1c  vmovaps [rsp+0x10], xmm1
000072bd77dd4b22  vmovaps [rsp+0x20], xmm2
000072bd77dd4b28  vmovaps [rsp+0x30], xmm3
000072bd77dd4b2e  vmovaps [rsp+0x40], xmm4
000072bd77dd4b34  vmovaps [rsp+0x50], xmm5
000072bd77dd4b3a  vmovaps [rsp+0x60], xmm6
000072bd77dd4b40  vmovaps [rsp+0x70], xmm7
000072bd77dd4b46  vmovaps [rsp+0x80], xmm8
000072bd77dd4b4f  vmovaps [rsp+0x90], xmm10
000072bd77dd4b58  vmovaps [rsp+0xA0], xmm11
000072bd77dd4b61  vmovaps [rsp+0xB0], xmm12
000072bd77dd4b6a  vmovaps [rsp+0xC0], xmm13
000072bd77dd4b73  vmovaps [rsp+0xD0], xmm14
000072bd77dd4b7c  vmovaps [rsp+0xE0], xmm15
000072bd77dd4b85  sub rsp, 0x30
000072bd77dd4b89  movaps [rsp], xmm9
000072bd77dd4b8e  movaps [rsp+0x10], xmm1
000072bd77dd4b93  movaps [rsp+0x20], xmm14
000072bd77dd4b99  lea rdi, [rsp]
000072bd77dd4b9d  mov esi, 0x00
000072bd77dd4ba2  mov rax, 0x643206AC3530
000072bd77dd4bac  call rax
000072bd77dd4bae  movaps xmm9, [rsp]
000072bd77dd4bb3  add rsp, 0x30
000072bd77dd4bb7  vmovaps xmm0, [rsp]
000072bd77dd4bbc  vmovaps xmm1, [rsp+0x10]
000072bd77dd4bc2  vmovaps xmm2, [rsp+0x20]
000072bd77dd4bc8  vmovaps xmm3, [rsp+0x30]
000072bd77dd4bce  vmovaps xmm4, [rsp+0x40]
000072bd77dd4bd4  vmovaps xmm5, [rsp+0x50]
000072bd77dd4bda  vmovaps xmm6, [rsp+0x60]
000072bd77dd4be0  vmovaps xmm7, [rsp+0x70]
000072bd77dd4be6  vmovaps xmm8, [rsp+0x80]
000072bd77dd4bef  vmovaps xmm10, [rsp+0x90]
000072bd77dd4bf8  vmovaps xmm11, [rsp+0xA0]
000072bd77dd4c01  vmovaps xmm12, [rsp+0xB0]
000072bd77dd4c0a  vmovaps xmm13, [rsp+0xC0]
000072bd77dd4c13  vmovaps xmm14, [rsp+0xD0]
000072bd77dd4c1c  vmovaps xmm15, [rsp+0xE0]
000072bd77dd4c25  add rsp, 0xF0
000072bd77dd4c2c  pop r11
000072bd77dd4c2e  pop r10
000072bd77dd4c30  pop r9
000072bd77dd4c32  pop r8
000072bd77dd4c34  pop rsi
000072bd77dd4c35  pop rdi
000072bd77dd4c36  pop rdx
000072bd77dd4c37  pop rcx
000072bd77dd4c38  pop rax
000072bd77dd4c39  add rsp, 0x08
000072bd77dd4c3d  jmp 0x000072BD77DD01DD
000072bd77dd4c42  sub rsp, 0x08
000072bd77dd4c46  push rax
000072bd77dd4c47  push rcx
000072bd77dd4c48  push rdx
000072bd77dd4c49  push rdi
000072bd77dd4c4a  push rsi
000072bd77dd4c4b  push r8
000072bd77dd4c4d  push r9
000072bd77dd4c4f  push r10
000072bd77dd4c51  push r11
000072bd77dd4c53  sub rsp, 0xF0
000072bd77dd4c5a  vmovaps [rsp], xmm0
000072bd77dd4c5f  vmovaps [rsp+0x10], xmm1
000072bd77dd4c65  vmovaps [rsp+0x20], xmm2
000072bd77dd4c6b  vmovaps [rsp+0x30], xmm3
000072bd77dd4c71  vmovaps [rsp+0x40], xmm4
000072bd77dd4c77  vmovaps [rsp+0x50], xmm5
000072bd77dd4c7d  vmovaps [rsp+0x60], xmm6
000072bd77dd4c83  vmovaps [rsp+0x70], xmm7
000072bd77dd4c89  vmovaps [rsp+0x80], xmm8
000072bd77dd4c92  vmovaps [rsp+0x90], xmm9
000072bd77dd4c9b  vmovaps [rsp+0xA0], xmm10
000072bd77dd4ca4  vmovaps [rsp+0xB0], xmm11
000072bd77dd4cad  vmovaps [rsp+0xC0], xmm12
000072bd77dd4cb6  vmovaps [rsp+0xD0], xmm13
000072bd77dd4cbf  vmovaps [rsp+0xE0], xmm15
000072bd77dd4cc8  sub rsp, 0x30
000072bd77dd4ccc  movaps [rsp], xmm14
000072bd77dd4cd1  movaps [rsp+0x10], xmm4
000072bd77dd4cd6  movaps [rsp+0x20], xmm1
000072bd77dd4cdb  lea rdi, [rsp]
000072bd77dd4cdf  mov esi, 0x00
000072bd77dd4ce4  mov rax, 0x643206AC3530
000072bd77dd4cee  call rax
000072bd77dd4cf0  movaps xmm14, [rsp]
000072bd77dd4cf5  add rsp, 0x30
000072bd77dd4cf9  vmovaps xmm0, [rsp]
000072bd77dd4cfe  vmovaps xmm1, [rsp+0x10]
000072bd77dd4d04  vmovaps xmm2, [rsp+0x20]
000072bd77dd4d0a  vmovaps xmm3, [rsp+0x30]
000072bd77dd4d10  vmovaps xmm4, [rsp+0x40]
000072bd77dd4d16  vmovaps xmm5, [rsp+0x50]
000072bd77dd4d1c  vmovaps xmm6, [rsp+0x60]
000072bd77dd4d22  vmovaps xmm7, [rsp+0x70]
000072bd77dd4d28  vmovaps xmm8, [rsp+0x80]
000072bd77dd4d31  vmovaps xmm9, [rsp+0x90]
000072bd77dd4d3a  vmovaps xmm10, [rsp+0xA0]
000072bd77dd4d43  vmovaps xmm11, [rsp+0xB0]
000072bd77dd4d4c  vmovaps xmm12, [rsp+0xC0]
000072bd77dd4d55  vmovaps xmm13, [rsp+0xD0]
000072bd77dd4d5e  vmovaps xmm15, [rsp+0xE0]
000072bd77dd4d67  add rsp, 0xF0
000072bd77dd4d6e  pop r11
000072bd77dd4d70  pop r10
000072bd77dd4d72  pop r9
000072bd77dd4d74  pop r8
000072bd77dd4d76  pop rsi
000072bd77dd4d77  pop rdi
000072bd77dd4d78  pop rdx
000072bd77dd4d79  pop rcx
000072bd77dd4d7a  pop rax
000072bd77dd4d7b  add rsp, 0x08
000072bd77dd4d7f  jmp 0x000072BD77DD0203
000072bd77dd4d84  sub rsp, 0x08
000072bd77dd4d88  push rax
000072bd77dd4d89  push rcx
000072bd77dd4d8a  push rdx
000072bd77dd4d8b  push rdi
000072bd77dd4d8c  push rsi
000072bd77dd4d8d  push r8
000072bd77dd4d8f  push r9
000072bd77dd4d91  push r10
000072bd77dd4d93  push r11
000072bd77dd4d95  sub rsp, 0xF0
000072bd77dd4d9c  vmovaps [rsp], xmm0
000072bd77dd4da1  vmovaps [rsp+0x10], xmm2
000072bd77dd4da7  vmovaps [rsp+0x20], xmm3
000072bd77dd4dad  vmovaps [rsp+0x30], xmm4
000072bd77dd4db3  vmovaps [rsp+0x40], xmm5
000072bd77dd4db9  vmovaps [rsp+0x50], xmm6
000072bd77dd4dbf  vmovaps [rsp+0x60], xmm7
000072bd77dd4dc5  vmovaps [rsp+0x70], xmm8
000072bd77dd4dcb  vmovaps [rsp+0x80], xmm9
000072bd77dd4dd4  vmovaps [rsp+0x90], xmm10
000072bd77dd4ddd  vmovaps [rsp+0xA0], xmm11
000072bd77dd4de6  vmovaps [rsp+0xB0], xmm12
000072bd77dd4def  vmovaps [rsp+0xC0], xmm13
000072bd77dd4df8  vmovaps [rsp+0xD0], xmm14
000072bd77dd4e01  vmovaps [rsp+0xE0], xmm15
000072bd77dd4e0a  sub rsp, 0x30
000072bd77dd4e0e  movaps [rsp], xmm1
000072bd77dd4e12  movaps [rsp+0x10], xmm12
000072bd77dd4e18  movaps [rsp+0x20], xmm11
000072bd77dd4e1e  lea rdi, [rsp]
000072bd77dd4e22  mov esi, 0x00
000072bd77dd4e27  mov rax, 0x643206AC3530
000072bd77dd4e31  call rax
000072bd77dd4e33  movaps xmm1, [rsp]
000072bd77dd4e37  add rsp, 0x30
000072bd77dd4e3b  vmovaps xmm0, [rsp]
000072bd77dd4e40  vmovaps xmm2, [rsp+0x10]
000072bd77dd4e46  vmovaps xmm3, [rsp+0x20]
000072bd77dd4e4c  vmovaps xmm4, [rsp+0x30]
000072bd77dd4e52  vmovaps xmm5, [rsp+0x40]
000072bd77dd4e58  vmovaps xmm6, [rsp+0x50]
000072bd77dd4e5e  vmovaps xmm7, [rsp+0x60]
000072bd77dd4e64  vmovaps xmm8, [rsp+0x70]
000072bd77dd4e6a  vmovaps xmm9, [rsp+0x80]
000072bd77dd4e73  vmovaps xmm10, [rsp+0x90]
000072bd77dd4e7c  vmovaps xmm11, [rsp+0xA0]
000072bd77dd4e85  vmovaps xmm12, [rsp+0xB0]
000072bd77dd4e8e  vmovaps xmm13, [rsp+0xC0]
000072bd77dd4e97  vmovaps xmm14, [rsp+0xD0]
000072bd77dd4ea0  vmovaps xmm15, [rsp+0xE0]
000072bd77dd4ea9  add rsp, 0xF0
000072bd77dd4eb0  pop r11
000072bd77dd4eb2  pop r10
000072bd77dd4eb4  pop r9
000072bd77dd4eb6  pop r8
000072bd77dd4eb8  pop rsi
000072bd77dd4eb9  pop rdi
000072bd77dd4eba  pop rdx
000072bd77dd4ebb  pop rcx
000072bd77dd4ebc  pop rax
000072bd77dd4ebd  add rsp, 0x08
000072bd77dd4ec1  jmp 0x000072BD77DD0224
000072bd77dd4ec6  call 0x000072BD77CE20A0
000072bd77dd4ecb  jmp 0x000072BD77DD0232
000072bd77dd4ed0  call 0x000072BD77C09D70
000072bd77dd4ed5  jmp 0x000072BD77DD023C
000072bd77dd4eda  sub rsp, 0x08
000072bd77dd4ede  push rax
000072bd77dd4edf  push rcx
000072bd77dd4ee0  push rdx
000072bd77dd4ee1  push rdi
000072bd77dd4ee2  push rsi
000072bd77dd4ee3  push r8
000072bd77dd4ee5  push r9
000072bd77dd4ee7  push r10
000072bd77dd4ee9  push r11
000072bd77dd4eeb  sub rsp, 0xF0
000072bd77dd4ef2  vmovaps [rsp], xmm0
000072bd77dd4ef7  vmovaps [rsp+0x10], xmm1
000072bd77dd4efd  vmovaps [rsp+0x20], xmm2
000072bd77dd4f03  vmovaps [rsp+0x30], xmm3
000072bd77dd4f09  vmovaps [rsp+0x40], xmm4
000072bd77dd4f0f  vmovaps [rsp+0x50], xmm5
000072bd77dd4f15  vmovaps [rsp+0x60], xmm6
000072bd77dd4f1b  vmovaps [rsp+0x70], xmm8
000072bd77dd4f21  vmovaps [rsp+0x80], xmm9
000072bd77dd4f2a  vmovaps [rsp+0x90], xmm10
000072bd77dd4f33  vmovaps [rsp+0xA0], xmm11
000072bd77dd4f3c  vmovaps [rsp+0xB0], xmm12
000072bd77dd4f45  vmovaps [rsp+0xC0], xmm13
000072bd77dd4f4e  vmovaps [rsp+0xD0], xmm14
000072bd77dd4f57  vmovaps [rsp+0xE0], xmm15
000072bd77dd4f60  sub rsp, 0x30
000072bd77dd4f64  movaps [rsp], xmm7
000072bd77dd4f68  movaps [rsp+0x10], xmm15
000072bd77dd4f6e  movaps [rsp+0x20], xmm10
000072bd77dd4f74  lea rdi, [rsp]
000072bd77dd4f78  mov esi, 0x00
000072bd77dd4f7d  mov rax, 0x643206AC3530
000072bd77dd4f87  call rax
000072bd77dd4f89  movaps xmm7, [rsp]
000072bd77dd4f8d  add rsp, 0x30
000072bd77dd4f91  vmovaps xmm0, [rsp]
000072bd77dd4f96  vmovaps xmm1, [rsp+0x10]
000072bd77dd4f9c  vmovaps xmm2, [rsp+0x20]
000072bd77dd4fa2  vmovaps xmm3, [rsp+0x30]
000072bd77dd4fa8  vmovaps xmm4, [rsp+0x40]
000072bd77dd4fae  vmovaps xmm5, [rsp+0x50]
000072bd77dd4fb4  vmovaps xmm6, [rsp+0x60]
000072bd77dd4fba  vmovaps xmm8, [rsp+0x70]
000072bd77dd4fc0  vmovaps xmm9, [rsp+0x80]
000072bd77dd4fc9  vmovaps xmm10, [rsp+0x90]
000072bd77dd4fd2  vmovaps xmm11, [rsp+0xA0]
000072bd77dd4fdb  vmovaps xmm12, [rsp+0xB0]
000072bd77dd4fe4  vmovaps xmm13, [rsp+0xC0]
000072bd77dd4fed  vmovaps xmm14, [rsp+0xD0]
000072bd77dd4ff6  vmovaps xmm15, [rsp+0xE0]
000072bd77dd4fff  add rsp, 0xF0
000072bd77dd5006  pop r11
000072bd77dd5008  pop r10
000072bd77dd500a  pop r9
000072bd77dd500c  pop r8
000072bd77dd500e  pop rsi
000072bd77dd500f  pop rdi
000072bd77dd5010  pop rdx
000072bd77dd5011  pop rcx
000072bd77dd5012  pop rax
000072bd77dd5013  add rsp, 0x08
000072bd77dd5017  jmp 0x000072BD77DD025D
000072bd77dd501c  sub rsp, 0x08
000072bd77dd5020  push rax
000072bd77dd5021  push rcx
000072bd77dd5022  push rdx
000072bd77dd5023  push rdi
000072bd77dd5024  push rsi
000072bd77dd5025  push r8
000072bd77dd5027  push r9
000072bd77dd5029  push r10
000072bd77dd502b  push r11
000072bd77dd502d  sub rsp, 0xF0
000072bd77dd5034  vmovaps [rsp], xmm0
000072bd77dd5039  vmovaps [rsp+0x10], xmm1
000072bd77dd503f  vmovaps [rsp+0x20], xmm2
000072bd77dd5045  vmovaps [rsp+0x30], xmm3
000072bd77dd504b  vmovaps [rsp+0x40], xmm4
000072bd77dd5051  vmovaps [rsp+0x50], xmm5
000072bd77dd5057  vmovaps [rsp+0x60], xmm6
000072bd77dd505d  vmovaps [rsp+0x70], xmm7
000072bd77dd5063  vmovaps [rsp+0x80], xmm8
000072bd77dd506c  vmovaps [rsp+0x90], xmm9
000072bd77dd5075  vmovaps [rsp+0xA0], xmm11
000072bd77dd507e  vmovaps [rsp+0xB0], xmm12
000072bd77dd5087  vmovaps [rsp+0xC0], xmm13
000072bd77dd5090  vmovaps [rsp+0xD0], xmm14
000072bd77dd5099  vmovaps [rsp+0xE0], xmm15
000072bd77dd50a2  sub rsp, 0x30
000072bd77dd50a6  movaps [rsp], xmm10
000072bd77dd50ab  movaps [rsp+0x10], xmm11
000072bd77dd50b1  movaps [rsp+0x20], xmm15
000072bd77dd50b7  lea rdi, [rsp]
000072bd77dd50bb  mov esi, 0x00
000072bd77dd50c0  mov rax, 0x643206AC3530
000072bd77dd50ca  call rax
000072bd77dd50cc  movaps xmm10, [rsp]
000072bd77dd50d1  add rsp, 0x30
000072bd77dd50d5  vmovaps xmm0, [rsp]
000072bd77dd50da  vmovaps xmm1, [rsp+0x10]
000072bd77dd50e0  vmovaps xmm2, [rsp+0x20]
000072bd77dd50e6  vmovaps xmm3, [rsp+0x30]
000072bd77dd50ec  vmovaps xmm4, [rsp+0x40]
000072bd77dd50f2  vmovaps xmm5, [rsp+0x50]
000072bd77dd50f8  vmovaps xmm6, [rsp+0x60]
000072bd77dd50fe  vmovaps xmm7, [rsp+0x70]
000072bd77dd5104  vmovaps xmm8, [rsp+0x80]
000072bd77dd510d  vmovaps xmm9, [rsp+0x90]
000072bd77dd5116  vmovaps xmm11, [rsp+0xA0]
000072bd77dd511f  vmovaps xmm12, [rsp+0xB0]
000072bd77dd5128  vmovaps xmm13, [rsp+0xC0]
000072bd77dd5131  vmovaps xmm14, [rsp+0xD0]
000072bd77dd513a  vmovaps xmm15, [rsp+0xE0]
000072bd77dd5143  add rsp, 0xF0
000072bd77dd514a  pop r11
000072bd77dd514c  pop r10
000072bd77dd514e  pop r9
000072bd77dd5150  pop r8
000072bd77dd5152  pop rsi
000072bd77dd5153  pop rdi
000072bd77dd5154  pop rdx
000072bd77dd5155  pop rcx
000072bd77dd5156  pop rax
000072bd77dd5157  add rsp, 0x08
000072bd77dd515b  jmp 0x000072BD77DD028B
000072bd77dd5160  sub rsp, 0x08
000072bd77dd5164  push rax
000072bd77dd5165  push rcx
000072bd77dd5166  push rdx
000072bd77dd5167  push rdi
000072bd77dd5168  push rsi
000072bd77dd5169  push r8
000072bd77dd516b  push r9
000072bd77dd516d  push r10
000072bd77dd516f  push r11
000072bd77dd5171  sub rsp, 0xF0
000072bd77dd5178  vmovaps [rsp], xmm0
000072bd77dd517d  vmovaps [rsp+0x10], xmm1
000072bd77dd5183  vmovaps [rsp+0x20], xmm2
000072bd77dd5189  vmovaps [rsp+0x30], xmm3
000072bd77dd518f  vmovaps [rsp+0x40], xmm4
000072bd77dd5195  vmovaps [rsp+0x50], xmm5
000072bd77dd519b  vmovaps [rsp+0x60], xmm6
000072bd77dd51a1  vmovaps [rsp+0x70], xmm7
000072bd77dd51a7  vmovaps [rsp+0x80], xmm8
000072bd77dd51b0  vmovaps [rsp+0x90], xmm9
000072bd77dd51b9  vmovaps [rsp+0xA0], xmm10
000072bd77dd51c2  vmovaps [rsp+0xB0], xmm12
000072bd77dd51cb  vmovaps [rsp+0xC0], xmm13
000072bd77dd51d4  vmovaps [rsp+0xD0], xmm14
000072bd77dd51dd  vmovaps [rsp+0xE0], xmm15
000072bd77dd51e6  sub rsp, 0x30
000072bd77dd51ea  movaps [rsp], xmm11
000072bd77dd51ef  movaps [rsp+0x10], xmm12
000072bd77dd51f5  movaps [rsp+0x20], xmm15
000072bd77dd51fb  lea rdi, [rsp]
000072bd77dd51ff  mov esi, 0x00
000072bd77dd5204  mov rax, 0x643206AC3530
000072bd77dd520e  call rax
000072bd77dd5210  movaps xmm11, [rsp]
000072bd77dd5215  add rsp, 0x30
000072bd77dd5219  vmovaps xmm0, [rsp]
000072bd77dd521e  vmovaps xmm1, [rsp+0x10]
000072bd77dd5224  vmovaps xmm2, [rsp+0x20]
000072bd77dd522a  vmovaps xmm3, [rsp+0x30]
000072bd77dd5230  vmovaps xmm4, [rsp+0x40]
000072bd77dd5236  vmovaps xmm5, [rsp+0x50]
000072bd77dd523c  vmovaps xmm6, [rsp+0x60]
000072bd77dd5242  vmovaps xmm7, [rsp+0x70]
000072bd77dd5248  vmovaps xmm8, [rsp+0x80]
000072bd77dd5251  vmovaps xmm9, [rsp+0x90]
000072bd77dd525a  vmovaps xmm10, [rsp+0xA0]
000072bd77dd5263  vmovaps xmm12, [rsp+0xB0]
000072bd77dd526c  vmovaps xmm13, [rsp+0xC0]
000072bd77dd5275  vmovaps xmm14, [rsp+0xD0]
000072bd77dd527e  vmovaps xmm15, [rsp+0xE0]
000072bd77dd5287  add rsp, 0xF0
000072bd77dd528e  pop r11
000072bd77dd5290  pop r10
000072bd77dd5292  pop r9
000072bd77dd5294  pop r8
000072bd77dd5296  pop rsi
000072bd77dd5297  pop rdi
000072bd77dd5298  pop rdx
000072bd77dd5299  pop rcx
000072bd77dd529a  pop rax
000072bd77dd529b  add rsp, 0x08
000072bd77dd529f  jmp 0x000072BD77DD02B9
000072bd77dd52a4  sub rsp, 0x08
000072bd77dd52a8  push rax
000072bd77dd52a9  push rcx
000072bd77dd52aa  push rdx
000072bd77dd52ab  push rdi
000072bd77dd52ac  push rsi
000072bd77dd52ad  push r8
000072bd77dd52af  push r9
000072bd77dd52b1  push r10
000072bd77dd52b3  push r11
000072bd77dd52b5  sub rsp, 0xF0
000072bd77dd52bc  vmovaps [rsp], xmm0
000072bd77dd52c1  vmovaps [rsp+0x10], xmm1
000072bd77dd52c7  vmovaps [rsp+0x20], xmm2
000072bd77dd52cd  vmovaps [rsp+0x30], xmm3
000072bd77dd52d3  vmovaps [rsp+0x40], xmm4
000072bd77dd52d9  vmovaps [rsp+0x50], xmm5
000072bd77dd52df  vmovaps [rsp+0x60], xmm6
000072bd77dd52e5  vmovaps [rsp+0x70], xmm7
000072bd77dd52eb  vmovaps [rsp+0x80], xmm8
000072bd77dd52f4  vmovaps [rsp+0x90], xmm9
000072bd77dd52fd  vmovaps [rsp+0xA0], xmm10
000072bd77dd5306  vmovaps [rsp+0xB0], xmm11
000072bd77dd530f  vmovaps [rsp+0xC0], xmm12
000072bd77dd5318  vmovaps [rsp+0xD0], xmm13
000072bd77dd5321  vmovaps [rsp+0xE0], xmm14
000072bd77dd532a  sub rsp, 0x30
000072bd77dd532e  movaps [rsp], xmm15
000072bd77dd5333  movaps [rsp+0x10], xmm13
000072bd77dd5339  movaps [rsp+0x20], xmm9
000072bd77dd533f  lea rdi, [rsp]
000072bd77dd5343  mov esi, 0x00
000072bd77dd5348  mov rax, 0x643206AC3530
000072bd77dd5352  call rax
000072bd77dd5354  movaps xmm15, [rsp]
000072bd77dd5359  add rsp, 0x30
000072bd77dd535d  vmovaps xmm0, [rsp]
000072bd77dd5362  vmovaps xmm1, [rsp+0x10]
000072bd77dd5368  vmovaps xmm2, [rsp+0x20]
000072bd77dd536e  vmovaps xmm3, [rsp+0x30]
000072bd77dd5374  vmovaps xmm4, [rsp+0x40]
000072bd77dd537a  vmovaps xmm5, [rsp+0x50]
000072bd77dd5380  vmovaps xmm6, [rsp+0x60]
000072bd77dd5386  vmovaps xmm7, [rsp+0x70]
000072bd77dd538c  vmovaps xmm8, [rsp+0x80]
000072bd77dd5395  vmovaps xmm9, [rsp+0x90]
000072bd77dd539e  vmovaps xmm10, [rsp+0xA0]
000072bd77dd53a7  vmovaps xmm11, [rsp+0xB0]
000072bd77dd53b0  vmovaps xmm12, [rsp+0xC0]
000072bd77dd53b9  vmovaps xmm13, [rsp+0xD0]
000072bd77dd53c2  vmovaps xmm14, [rsp+0xE0]
000072bd77dd53cb  add rsp, 0xF0
000072bd77dd53d2  pop r11
000072bd77dd53d4  pop r10
000072bd77dd53d6  pop r9
000072bd77dd53d8  pop r8
000072bd77dd53da  pop rsi
000072bd77dd53db  pop rdi
000072bd77dd53dc  pop rdx
000072bd77dd53dd  pop rcx
000072bd77dd53de  pop rax
000072bd77dd53df  add rsp, 0x08
000072bd77dd53e3  jmp 0x000072BD77DD02D4
000072bd77dd53e8  sub rsp, 0x08
000072bd77dd53ec  push rax
000072bd77dd53ed  push rcx
000072bd77dd53ee  push rdx
000072bd77dd53ef  push rdi
000072bd77dd53f0  push rsi
000072bd77dd53f1  push r8
000072bd77dd53f3  push r9
000072bd77dd53f5  push r10
000072bd77dd53f7  push r11
000072bd77dd53f9  sub rsp, 0xF0
000072bd77dd5400  vmovaps [rsp], xmm0
000072bd77dd5405  vmovaps [rsp+0x10], xmm1
000072bd77dd540b  vmovaps [rsp+0x20], xmm2
000072bd77dd5411  vmovaps [rsp+0x30], xmm3
000072bd77dd5417  vmovaps [rsp+0x40], xmm4
000072bd77dd541d  vmovaps [rsp+0x50], xmm5
000072bd77dd5423  vmovaps [rsp+0x60], xmm6
000072bd77dd5429  vmovaps [rsp+0x70], xmm7
000072bd77dd542f  vmovaps [rsp+0x80], xmm8
000072bd77dd5438  vmovaps [rsp+0x90], xmm9
000072bd77dd5441  vmovaps [rsp+0xA0], xmm10
000072bd77dd544a  vmovaps [rsp+0xB0], xmm11
000072bd77dd5453  vmovaps [rsp+0xC0], xmm12
000072bd77dd545c  vmovaps [rsp+0xD0], xmm14
000072bd77dd5465  vmovaps [rsp+0xE0], xmm15
000072bd77dd546e  sub rsp, 0x30
000072bd77dd5472  movaps [rsp], xmm13
000072bd77dd5477  movaps [rsp+0x10], xmm8
000072bd77dd547d  movaps [rsp+0x20], xmm14
000072bd77dd5483  lea rdi, [rsp]
000072bd77dd5487  mov esi, 0x00
000072bd77dd548c  mov rax, 0x643206AC3530
000072bd77dd5496  call rax
000072bd77dd5498  movaps xmm13, [rsp]
000072bd77dd549d  add rsp, 0x30
000072bd77dd54a1  vmovaps xmm0, [rsp]
000072bd77dd54a6  vmovaps xmm1, [rsp+0x10]
000072bd77dd54ac  vmovaps xmm2, [rsp+0x20]
000072bd77dd54b2  vmovaps xmm3, [rsp+0x30]
000072bd77dd54b8  vmovaps xmm4, [rsp+0x40]
000072bd77dd54be  vmovaps xmm5, [rsp+0x50]
000072bd77dd54c4  vmovaps xmm6, [rsp+0x60]
000072bd77dd54ca  vmovaps xmm7, [rsp+0x70]
000072bd77dd54d0  vmovaps xmm8, [rsp+0x80]
000072bd77dd54d9  vmovaps xmm9, [rsp+0x90]
000072bd77dd54e2  vmovaps xmm10, [rsp+0xA0]
000072bd77dd54eb  vmovaps xmm11, [rsp+0xB0]
000072bd77dd54f4  vmovaps xmm12, [rsp+0xC0]
000072bd77dd54fd  vmovaps xmm14, [rsp+0xD0]
000072bd77dd5506  vmovaps xmm15, [rsp+0xE0]
000072bd77dd550f  add rsp, 0xF0
000072bd77dd5516  pop r11
000072bd77dd5518  pop r10
000072bd77dd551a  pop r9
000072bd77dd551c  pop r8
000072bd77dd551e  pop rsi
000072bd77dd551f  pop rdi
000072bd77dd5520  pop rdx
000072bd77dd5521  pop rcx
000072bd77dd5522  pop rax
000072bd77dd5523  add rsp, 0x08
000072bd77dd5527  jmp 0x000072BD77DD02F7
000072bd77dd552c  sub rsp, 0x08
000072bd77dd5530  push rax
000072bd77dd5531  push rcx
000072bd77dd5532  push rdx
000072bd77dd5533  push rdi
000072bd77dd5534  push rsi
000072bd77dd5535  push r8
000072bd77dd5537  push r9
000072bd77dd5539  push r10
000072bd77dd553b  push r11
000072bd77dd553d  sub rsp, 0xF0
000072bd77dd5544  vmovaps [rsp], xmm0
000072bd77dd5549  vmovaps [rsp+0x10], xmm1
000072bd77dd554f  vmovaps [rsp+0x20], xmm2
000072bd77dd5555  vmovaps [rsp+0x30], xmm3
000072bd77dd555b  vmovaps [rsp+0x40], xmm4
000072bd77dd5561  vmovaps [rsp+0x50], xmm5
000072bd77dd5567  vmovaps [rsp+0x60], xmm6
000072bd77dd556d  vmovaps [rsp+0x70], xmm7
000072bd77dd5573  vmovaps [rsp+0x80], xmm8
000072bd77dd557c  vmovaps [rsp+0x90], xmm9
000072bd77dd5585  vmovaps [rsp+0xA0], xmm10
000072bd77dd558e  vmovaps [rsp+0xB0], xmm11
000072bd77dd5597  vmovaps [rsp+0xC0], xmm12
000072bd77dd55a0  vmovaps [rsp+0xD0], xmm13
000072bd77dd55a9  vmovaps [rsp+0xE0], xmm15
000072bd77dd55b2  sub rsp, 0x30
000072bd77dd55b6  movaps [rsp], xmm14
000072bd77dd55bb  movaps [rsp+0x10], xmm1
000072bd77dd55c0  movaps [rsp+0x20], xmm10
000072bd77dd55c6  lea rdi, [rsp]
000072bd77dd55ca  mov esi, 0x00
000072bd77dd55cf  mov rax, 0x643206AC3530
000072bd77dd55d9  call rax
000072bd77dd55db  movaps xmm14, [rsp]
000072bd77dd55e0  add rsp, 0x30
000072bd77dd55e4  vmovaps xmm0, [rsp]
000072bd77dd55e9  vmovaps xmm1, [rsp+0x10]
000072bd77dd55ef  vmovaps xmm2, [rsp+0x20]
000072bd77dd55f5  vmovaps xmm3, [rsp+0x30]
000072bd77dd55fb  vmovaps xmm4, [rsp+0x40]
000072bd77dd5601  vmovaps xmm5, [rsp+0x50]
000072bd77dd5607  vmovaps xmm6, [rsp+0x60]
000072bd77dd560d  vmovaps xmm7, [rsp+0x70]
000072bd77dd5613  vmovaps xmm8, [rsp+0x80]
000072bd77dd561c  vmovaps xmm9, [rsp+0x90]
000072bd77dd5625  vmovaps xmm10, [rsp+0xA0]
000072bd77dd562e  vmovaps xmm11, [rsp+0xB0]
000072bd77dd5637  vmovaps xmm12, [rsp+0xC0]
000072bd77dd5640  vmovaps xmm13, [rsp+0xD0]
000072bd77dd5649  vmovaps xmm15, [rsp+0xE0]
000072bd77dd5652  add rsp, 0xF0
000072bd77dd5659  pop r11
000072bd77dd565b  pop r10
000072bd77dd565d  pop r9
000072bd77dd565f  pop r8
000072bd77dd5661  pop rsi
000072bd77dd5662  pop rdi
000072bd77dd5663  pop rdx
000072bd77dd5664  pop rcx
000072bd77dd5665  pop rax
000072bd77dd5666  add rsp, 0x08
000072bd77dd566a  jmp 0x000072BD77DD031A
000072bd77dd566f  sub rsp, 0x08
000072bd77dd5673  push rax
000072bd77dd5674  push rcx
000072bd77dd5675  push rdx
000072bd77dd5676  push rdi
000072bd77dd5677  push rsi
000072bd77dd5678  push r8
000072bd77dd567a  push r9
000072bd77dd567c  push r10
000072bd77dd567e  push r11
000072bd77dd5680  sub rsp, 0xF0
000072bd77dd5687  vmovaps [rsp], xmm0
000072bd77dd568c  vmovaps [rsp+0x10], xmm2
000072bd77dd5692  vmovaps [rsp+0x20], xmm3
000072bd77dd5698  vmovaps [rsp+0x30], xmm4
000072bd77dd569e  vmovaps [rsp+0x40], xmm5
000072bd77dd56a4  vmovaps [rsp+0x50], xmm6
000072bd77dd56aa  vmovaps [rsp+0x60], xmm7
000072bd77dd56b0  vmovaps [rsp+0x70], xmm8
000072bd77dd56b6  vmovaps [rsp+0x80], xmm9
000072bd77dd56bf  vmovaps [rsp+0x90], xmm10
000072bd77dd56c8  vmovaps [rsp+0xA0], xmm11
000072bd77dd56d1  vmovaps [rsp+0xB0], xmm12
000072bd77dd56da  vmovaps [rsp+0xC0], xmm13
000072bd77dd56e3  vmovaps [rsp+0xD0], xmm14
000072bd77dd56ec  vmovaps [rsp+0xE0], xmm15
000072bd77dd56f5  sub rsp, 0x30
000072bd77dd56f9  movaps [rsp], xmm1
000072bd77dd56fd  movaps [rsp+0x10], xmm7
000072bd77dd5702  movaps [rsp+0x20], xmm11
000072bd77dd5708  lea rdi, [rsp]
000072bd77dd570c  mov esi, 0x00
000072bd77dd5711  mov rax, 0x643206AC3530
000072bd77dd571b  call rax
000072bd77dd571d  movaps xmm1, [rsp]
000072bd77dd5721  add rsp, 0x30
000072bd77dd5725  vmovaps xmm0, [rsp]
000072bd77dd572a  vmovaps xmm2, [rsp+0x10]
000072bd77dd5730  vmovaps xmm3, [rsp+0x20]
000072bd77dd5736  vmovaps xmm4, [rsp+0x30]
000072bd77dd573c  vmovaps xmm5, [rsp+0x40]
000072bd77dd5742  vmovaps xmm6, [rsp+0x50]
000072bd77dd5748  vmovaps xmm7, [rsp+0x60]
000072bd77dd574e  vmovaps xmm8, [rsp+0x70]
000072bd77dd5754  vmovaps xmm9, [rsp+0x80]
000072bd77dd575d  vmovaps xmm10, [rsp+0x90]
000072bd77dd5766  vmovaps xmm11, [rsp+0xA0]
000072bd77dd576f  vmovaps xmm12, [rsp+0xB0]
000072bd77dd5778  vmovaps xmm13, [rsp+0xC0]
000072bd77dd5781  vmovaps xmm14, [rsp+0xD0]
000072bd77dd578a  vmovaps xmm15, [rsp+0xE0]
000072bd77dd5793  add rsp, 0xF0
000072bd77dd579a  pop r11
000072bd77dd579c  pop r10
000072bd77dd579e  pop r9
000072bd77dd57a0  pop r8
000072bd77dd57a2  pop rsi
000072bd77dd57a3  pop rdi
000072bd77dd57a4  pop rdx
000072bd77dd57a5  pop rcx
000072bd77dd57a6  pop rax
000072bd77dd57a7  add rsp, 0x08
000072bd77dd57ab  jmp 0x000072BD77DD033B
000072bd77dd57b0  call 0x000072BD77C0E880
000072bd77dd57b5  jmp 0x000072BD77DD034E
000072bd77dd57ba  call 0x000072BD77C0C380
000072bd77dd57bf  jmp 0x000072BD77DD0359
000072bd77dd57c4  call 0x000072BD77C0D600
000072bd77dd57c9  jmp 0x000072BD77DD0364
000072bd77dd57ce  call 0x000072BD77BFF540
000072bd77dd57d3  jmp 0x000072BD77DD036F
000072bd77dd57d8  int3
000072bd77dd57d9  nop [rax], eax
000072bd77dd57e0  mov rax, [r15+0x40]
000072bd77dd57e4  mov r14, [r15+0x58]
000072bd77dd57e8  lea r12, [rax+r14*1]
000072bd77dd57ec  movaps xmm1, [r15+0x1D0]
000072bd77dd57f4  vmovaps [rsp+0x10], xmm1
000072bd77dd57fa  vmovaps xmm15, [rsp+0x10]
000072bd77dd5800  por xmm1, xmm15
000072bd77dd5805  movaps xmm14, [r15+0x1A0]
000072bd77dd580d  vmovaps [rsp+0x10], xmm14
000072bd77dd5813  vmovaps xmm13, [rsp+0x10]
000072bd77dd5819  por xmm14, xmm13
000072bd77dd581e  lea rax, [r12+0x30]
000072bd77dd5823  mov r11, [r13+rax*1]
000072bd77dd5828  lea rax, [r12+0x38]
000072bd77dd582d  mov r10, [r13+rax*1]
000072bd77dd5832  movq xmm13, r11
000072bd77dd5837  movq xmm12, r10
000072bd77dd583c  movq xmm13, xmm13
000072bd77dd5841  vmovaps [rsp+0x10], xmm13
000072bd77dd5847  movq xmm13, xmm13
000072bd77dd584c  movaps [r15+0x130], xmm13
000072bd77dd5854  movq xmm12, xmm12
000072bd77dd5859  vmovaps [rsp+0x20], xmm12
000072bd77dd585f  movq xmm12, xmm12
000072bd77dd5864  movaps [r15+0x280], xmm12
000072bd77dd586c  movaps xmm13, [r15+0x270]
000072bd77dd5874  vmovaps [rsp+0x30], xmm13
000072bd77dd587a  vmovaps xmm12, [rsp+0x30]
000072bd77dd5880  por xmm13, xmm12
000072bd77dd5885  lea rax, [r12+0x20]
000072bd77dd588a  mov r11, [r13+rax*1]
000072bd77dd588f  lea rax, [r12+0x28]
000072bd77dd5894  mov r10, [r13+rax*1]
000072bd77dd5899  movq xmm12, r11
000072bd77dd589e  movq xmm11, r10
000072bd77dd58a3  movq xmm12, xmm12
000072bd77dd58a8  vmovaps [rsp+0x30], xmm12
000072bd77dd58ae  movq xmm12, xmm12
000072bd77dd58b3  movaps [r15+0x150], xmm12
000072bd77dd58bb  movq xmm11, xmm11
000072bd77dd58c0  vmovaps [rsp+0x40], xmm11
000072bd77dd58c6  movq xmm11, xmm11
000072bd77dd58cb  movaps [r15+0x140], xmm11
000072bd77dd58d3  lea rax, [r12+0x10]
000072bd77dd58d8  mov r11, [r13+rax*1]
000072bd77dd58dd  lea rax, [r12+0x18]
000072bd77dd58e2  mov r10, [r13+rax*1]
000072bd77dd58e7  movq xmm12, r11
000072bd77dd58ec  movq xmm11, r10
000072bd77dd58f1  movq xmm12, xmm12
000072bd77dd58f6  vmovaps [rsp+0x50], xmm12
000072bd77dd58fc  movq xmm12, xmm12
000072bd77dd5901  movaps [r15+0x170], xmm12
000072bd77dd5909  movq xmm11, xmm11
000072bd77dd590e  vmovaps [rsp+0x60], xmm11
000072bd77dd5914  movq xmm11, xmm11
000072bd77dd5919  movaps [r15+0x160], xmm11
000072bd77dd5921  mov rax, [r13+r12*1]
000072bd77dd5926  vmovq xmm12, rax
000072bd77dd592b  vpbroadcastq xmm12, xmm12
000072bd77dd5930  lea rax, [r12+0x08]
000072bd77dd5935  mov r12, [r13+rax*1]
000072bd77dd593a  movq xmm11, r12
000072bd77dd593f  movaps [r15+0x230], xmm11
000072bd77dd5947  mov rax, [r15+0xF8]
000072bd77dd594e  lea r12, [rax+0x50]
000072bd77dd5952  movups xmm11, [r13+r12*1]
000072bd77dd5958  lea r12, [rax+0x60]
000072bd77dd595c  movups xmm10, [r13+r12*1]
000072bd77dd5962  lea r12, [rax+0x30]
000072bd77dd5966  movups xmm9, [r13+r12*1]
000072bd77dd596c  mov r12, [r15+0x50]
000072bd77dd5970  lea r11, [r12+r14*1]
000072bd77dd5974  mov [r15+0x60], r11
000072bd77dd5978  lea r12, [r14+0x40]
000072bd77dd597c  mov [r15+0x58], r12
000072bd77dd5980  movaps xmm8, xmm12
000072bd77dd5984  mulpd xmm8, xmm15
000072bd77dd5989  vcmppd xmm7, xmm8, xmm8, 0x03
000072bd77dd598f  ptest xmm7, xmm7
000072bd77dd5994  jnz 0x000072BD77DD67B7
000072bd77dd599a  movq xmm15, qword ptr [r15+0x230]
000072bd77dd59a3  vmovaps [rsp+0x70], xmm15
000072bd77dd59a9  vpermilpd xmm15, xmm15, 0x00
000072bd77dd59af  movaps xmm7, xmm9
000072bd77dd59b3  mulpd xmm7, xmm15
000072bd77dd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000072bd77dd59bd  ptest xmm6, xmm6
000072bd77dd59c2  jnz 0x000072BD77DD68FB
000072bd77dd59c8  vxorps xmm15, xmm15, xmm15
000072bd77dd59cd  vpbroadcastq xmm15, xmm15
000072bd77dd59d2  movaps xmm9, xmm12
000072bd77dd59d6  mulpd xmm9, xmm10
000072bd77dd59db  vcmppd xmm6, xmm9, xmm9, 0x03
000072bd77dd59e1  ptest xmm6, xmm6
000072bd77dd59e6  jnz 0x000072BD77DD6A3D
000072bd77dd59ec  movaps xmm10, xmm12
000072bd77dd59f0  mulpd xmm10, xmm11
000072bd77dd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000072bd77dd59fb  ptest xmm6, xmm6
000072bd77dd5a00  jnz 0x000072BD77DD6B81
000072bd77dd5a06  movaps xmm11, [r15+0x1F0]
000072bd77dd5a0e  movaps xmm6, xmm12
000072bd77dd5a12  mulpd xmm6, xmm11
000072bd77dd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000072bd77dd5a1c  ptest xmm5, xmm5
000072bd77dd5a21  jnz 0x000072BD77DD6CC5
000072bd77dd5a27  movaps xmm12, [r15+0x2A0]
000072bd77dd5a2f  vmovaps [rsp+0x80], xmm12
000072bd77dd5a38  vmovaps xmm11, [rsp+0x80]
000072bd77dd5a41  por xmm12, xmm11
000072bd77dd5a46  movaps xmm11, [r15+0x250]
000072bd77dd5a4e  vmovaps [rsp+0x80], xmm11
000072bd77dd5a57  vmovaps xmm5, [rsp+0x80]
000072bd77dd5a60  por xmm11, xmm5
000072bd77dd5a65  vmovaps xmm4, [rsp+0x70]
000072bd77dd5a6b  vpermilpd xmm4, xmm4, 0x00
000072bd77dd5a71  movaps xmm3, xmm5
000072bd77dd5a74  mulpd xmm3, xmm4
000072bd77dd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000072bd77dd5a7d  ptest xmm2, xmm2
000072bd77dd5a82  jnz 0x000072BD77DD6E07
000072bd77dd5a88  mov [rsp+0x80], rax
000072bd77dd5a90  xor eax, eax
000072bd77dd5a92  mov r14d, 0x200
000072bd77dd5a98  cmp r12, r14
000072bd77dd5a9b  cmc
000072bd77dd5a9c  lahf
000072bd77dd5a9d  seto al
000072bd77dd5aa0  mov [r15+0x108], eax
000072bd77dd5aa7  movaps xmm5, xmm8
000072bd77dd5aab  addpd xmm5, xmm15
000072bd77dd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000072bd77dd5ab5  ptest xmm4, xmm4
000072bd77dd5aba  jnz 0x000072BD77DD6F47
000072bd77dd5ac0  movaps xmm8, [r15+0x1B0]
000072bd77dd5ac8  movaps xmm4, xmm9
000072bd77dd5acc  addpd xmm4, xmm8
000072bd77dd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000072bd77dd5ad6  ptest xmm2, xmm2
000072bd77dd5adb  jnz 0x000072BD77DD7089
000072bd77dd5ae1  movaps xmm9, xmm10
000072bd77dd5ae5  addpd xmm9, xmm8
000072bd77dd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000072bd77dd5af0  ptest xmm2, xmm2
000072bd77dd5af5  jnz 0x000072BD77DD71CB
000072bd77dd5afb  movaps xmm10, [r15+0x2F0]
000072bd77dd5b03  vmovaps [rsp+0x90], xmm10
000072bd77dd5b0c  vmovaps xmm8, [rsp+0x90]
000072bd77dd5b15  por xmm10, xmm8
000072bd77dd5b1a  movaps xmm8, [r15+0x2E0]
000072bd77dd5b22  vmovaps [rsp+0x90], xmm8
000072bd77dd5b2b  vmovaps xmm2, [rsp+0x90]
000072bd77dd5b34  por xmm8, xmm2
000072bd77dd5b39  movaps xmm2, [r15+0x2D0]
000072bd77dd5b41  vmovaps [rsp+0x90], xmm2
000072bd77dd5b4a  vmovaps [rsp+0xA0], xmm1
000072bd77dd5b53  vmovaps xmm1, [rsp+0x90]
000072bd77dd5b5c  por xmm2, xmm1
000072bd77dd5b60  movaps xmm1, [r15+0x200]
000072bd77dd5b68  vmovaps [rsp+0x90], xmm1
000072bd77dd5b71  vmovaps [rsp+0xB0], xmm15
000072bd77dd5b7a  vmovaps xmm15, [rsp+0x90]
000072bd77dd5b83  por xmm1, xmm15
000072bd77dd5b88  movaps xmm15, [r15+0x1C0]
000072bd77dd5b90  vmovaps [rsp+0x90], xmm15
000072bd77dd5b99  vmovaps [rsp+0xC0], xmm1
000072bd77dd5ba2  vmovaps xmm1, [rsp+0x90]
000072bd77dd5bab  por xmm15, xmm1
000072bd77dd5bb0  movaps xmm1, [r15+0x190]
000072bd77dd5bb8  vmovaps [rsp+0x90], xmm1
000072bd77dd5bc1  vmovaps [rsp+0xD0], xmm15
000072bd77dd5bca  vmovaps xmm15, [rsp+0x90]
000072bd77dd5bd3  por xmm1, xmm15
000072bd77dd5bd8  movaps xmm15, [r15+0x300]
000072bd77dd5be0  vmovaps [rsp+0x90], xmm15
000072bd77dd5be9  vmovaps [rsp+0xE0], xmm1
000072bd77dd5bf2  vmovaps xmm1, [rsp+0x90]
000072bd77dd5bfb  por xmm15, xmm1
000072bd77dd5c00  mov rax, [rsp+0x80]
000072bd77dd5c08  lea r14, [rax+0xA0]
000072bd77dd5c0f  movups xmm1, [r13+r14*1]
000072bd77dd5c15  lea r14, [rax+0xB0]
000072bd77dd5c1c  vmovaps [rsp+0x80], xmm1
000072bd77dd5c25  movups xmm1, [r13+r14*1]
000072bd77dd5c2b  vmovaps [rsp+0x90], xmm1
000072bd77dd5c34  vmovaps [rsp+0xF0], xmm15
000072bd77dd5c3d  vmovaps xmm15, [rsp+0xB0]
000072bd77dd5c46  vmovaps [rsp+0xB0], xmm14
000072bd77dd5c4f  movaps xmm1, xmm6
000072bd77dd5c52  addpd xmm1, xmm15
000072bd77dd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000072bd77dd5c5c  ptest xmm14, xmm14
000072bd77dd5c62  jnz 0x000072BD77DD7323
000072bd77dd5c68  lea r14, [rax+0xF0]
000072bd77dd5c6f  movups xmm15, [r13+r14*1]
000072bd77dd5c75  movaps xmm14, xmm4
000072bd77dd5c79  addpd xmm14, xmm3
000072bd77dd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000072bd77dd5c84  ptest xmm6, xmm6
000072bd77dd5c89  jnz 0x000072BD77DD746E
000072bd77dd5c8f  movaps xmm6, xmm9
000072bd77dd5c93  addpd xmm6, xmm7
000072bd77dd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000072bd77dd5c9c  ptest xmm4, xmm4
000072bd77dd5ca1  jnz 0x000072BD77DD75B0
000072bd77dd5ca7  vmovaps xmm9, [rsp+0x70]
000072bd77dd5cad  vpermilpd xmm9, xmm9, 0x00
000072bd77dd5cb3  vmovaps xmm4, [rsp+0x90]
000072bd77dd5cbc  movaps xmm7, xmm4
000072bd77dd5cbf  mulpd xmm7, xmm9
000072bd77dd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000072bd77dd5cc9  ptest xmm3, xmm3
000072bd77dd5cce  jnz 0x000072BD77DD76F1
000072bd77dd5cd4  vmovaps xmm9, [rsp+0x50]
000072bd77dd5cda  vpermilpd xmm9, xmm9, 0x00
000072bd77dd5ce0  movaps xmm4, xmm15
000072bd77dd5ce4  mulpd xmm4, xmm9
000072bd77dd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000072bd77dd5cee  ptest xmm3, xmm3
000072bd77dd5cf3  jnz 0x000072BD77DD7832
000072bd77dd5cf9  lea r14, [rax+0xE0]
000072bd77dd5d00  movups xmm15, [r13+r14*1]
000072bd77dd5d06  vmovaps xmm9, [rsp+0x70]
000072bd77dd5d0c  vpermilpd xmm9, xmm9, 0x00
000072bd77dd5d12  vmovaps [rsp+0x70], xmm1
000072bd77dd5d18  vmovaps xmm1, [rsp+0x80]
000072bd77dd5d21  vmovaps [rsp+0x80], xmm15
000072bd77dd5d2a  movaps xmm3, xmm1
000072bd77dd5d2d  mulpd xmm3, xmm9
000072bd77dd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000072bd77dd5d37  ptest xmm15, xmm15
000072bd77dd5d3d  jnz 0x000072BD77DD797E
000072bd77dd5d43  vmovaps xmm1, [rsp+0xF0]
000072bd77dd5d4c  vmovaps xmm15, [rsp+0xF0]
000072bd77dd5d55  por xmm1, xmm15
000072bd77dd5d5a  movaps [r15+0x300], xmm1
000072bd77dd5d62  vmovaps xmm15, [rsp+0xE0]
000072bd77dd5d6b  vmovaps xmm9, [rsp+0xE0]
000072bd77dd5d74  por xmm15, xmm9
000072bd77dd5d79  movaps [r15+0x190], xmm15
000072bd77dd5d81  vmovaps xmm9, [rsp+0x50]
000072bd77dd5d87  vpermilpd xmm9, xmm9, 0x00
000072bd77dd5d8d  vmovaps [rsp+0x90], xmm1
000072bd77dd5d96  vmovaps [rsp+0xE0], xmm15
000072bd77dd5d9f  vmovaps xmm15, [rsp+0x80]
000072bd77dd5da8  vmovaps [rsp+0x80], xmm14
000072bd77dd5db1  movaps xmm1, xmm15
000072bd77dd5db5  mulpd xmm1, xmm9
000072bd77dd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000072bd77dd5dbf  ptest xmm14, xmm14
000072bd77dd5dc5  jnz 0x000072BD77DD7ABF
000072bd77dd5dcb  lea r14, [rax+0x90]
000072bd77dd5dd2  movups xmm15, [r13+r14*1]
000072bd77dd5dd8  vmovaps xmm14, [rsp+0xD0]
000072bd77dd5de1  vmovaps xmm9, [rsp+0xD0]
000072bd77dd5dea  por xmm14, xmm9
000072bd77dd5def  movaps [r15+0x1C0], xmm14
000072bd77dd5df7  vmovaps xmm9, [rsp+0xC0]
000072bd77dd5e00  vmovaps [rsp+0xD0], xmm1
000072bd77dd5e09  vmovaps xmm1, [rsp+0xC0]
000072bd77dd5e12  por xmm9, xmm1
000072bd77dd5e17  movaps [r15+0x200], xmm9
000072bd77dd5e1f  vmovaps [rsp+0xC0], xmm2
000072bd77dd5e28  vmovaps xmm1, [rsp+0xC0]
000072bd77dd5e31  por xmm2, xmm1
000072bd77dd5e35  movaps [r15+0x2D0], xmm2
000072bd77dd5e3d  vmovaps [rsp+0xC0], xmm8
000072bd77dd5e46  vmovaps xmm1, [rsp+0xC0]
000072bd77dd5e4f  por xmm8, xmm1
000072bd77dd5e54  movaps [r15+0x2E0], xmm8
000072bd77dd5e5c  vmovaps [rsp+0xC0], xmm15
000072bd77dd5e65  movaps xmm1, xmm5
000072bd77dd5e68  addpd xmm1, xmm7
000072bd77dd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000072bd77dd5e71  ptest xmm15, xmm15
000072bd77dd5e77  jnz 0x000072BD77DD7C0B
000072bd77dd5e7d  vmovaps xmm15, [rsp+0x50]
000072bd77dd5e83  vpermilpd xmm15, xmm15, 0x00
000072bd77dd5e89  vmovaps xmm5, [rsp+0xC0]
000072bd77dd5e92  vmovaps [rsp+0xC0], xmm1
000072bd77dd5e9b  movaps xmm7, xmm5
000072bd77dd5e9e  mulpd xmm7, xmm15
000072bd77dd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000072bd77dd5ea8  ptest xmm1, xmm1
000072bd77dd5ead  jnz 0x000072BD77DD7D4B
000072bd77dd5eb3  lea r14, [rax+0x80]
000072bd77dd5eba  movups xmm1, [r13+r14*1]
000072bd77dd5ec0  vmovaps xmm5, [rsp+0x70]
000072bd77dd5ec6  vmovaps [rsp+0x70], xmm1
000072bd77dd5ecc  movaps xmm15, xmm5
000072bd77dd5ed0  addpd xmm15, xmm3
000072bd77dd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000072bd77dd5edb  ptest xmm1, xmm1
000072bd77dd5ee0  jnz 0x000072BD77DD7E96
000072bd77dd5ee6  vmovaps xmm5, [rsp+0x80]
000072bd77dd5eef  movaps xmm1, xmm5
000072bd77dd5ef2  addpd xmm1, xmm4
000072bd77dd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000072bd77dd5efb  ptest xmm3, xmm3
000072bd77dd5f00  jnz 0x000072BD77DD7FD8
000072bd77dd5f06  vmovaps [rsp+0x80], xmm10
000072bd77dd5f0f  vmovaps xmm5, [rsp+0x80]
000072bd77dd5f18  por xmm10, xmm5
000072bd77dd5f1d  movaps [r15+0x2F0], xmm10
000072bd77dd5f25  vmovaps xmm5, [rsp+0x50]
000072bd77dd5f2b  vpermilpd xmm5, xmm5, 0x00
000072bd77dd5f31  vmovaps xmm3, [rsp+0x70]
000072bd77dd5f37  vmovaps [rsp+0x50], xmm1
000072bd77dd5f3d  movaps xmm4, xmm3
000072bd77dd5f40  mulpd xmm4, xmm5
000072bd77dd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000072bd77dd5f49  ptest xmm1, xmm1
000072bd77dd5f4e  jnz 0x000072BD77DD8118
000072bd77dd5f54  lea r14, [rax+0xD0]
000072bd77dd5f5b  movups xmm1, [r13+r14*1]
000072bd77dd5f61  vmovaps xmm3, [rsp+0xD0]
000072bd77dd5f6a  vmovaps [rsp+0x70], xmm1
000072bd77dd5f70  movaps xmm5, xmm6
000072bd77dd5f73  addpd xmm5, xmm3
000072bd77dd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000072bd77dd5f7c  ptest xmm1, xmm1
000072bd77dd5f81  jnz 0x000072BD77DD8262
000072bd77dd5f87  vmovaps xmm1, [rsp+0x60]
000072bd77dd5f8d  vpermilpd xmm1, xmm1, 0x00
000072bd77dd5f93  movaps xmm6, xmm9
000072bd77dd5f97  mulpd xmm6, xmm1
000072bd77dd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000072bd77dd5fa0  ptest xmm3, xmm3
000072bd77dd5fa5  jnz 0x000072BD77DD83A2
000072bd77dd5fab  movaps [r15+0x260], xmm6
000072bd77dd5fb3  vxorps xmm1, xmm1, xmm1
000072bd77dd5fb7  vpbroadcastq xmm1, xmm1
000072bd77dd5fbc  movaps [r15+0x1B0], xmm1
000072bd77dd5fc4  vmovaps xmm1, [rsp+0x60]
000072bd77dd5fca  vpermilpd xmm1, xmm1, 0x00
000072bd77dd5fd0  vmovaps xmm3, [rsp+0x70]
000072bd77dd5fd6  vmovaps [rsp+0x70], xmm15
000072bd77dd5fdc  movaps xmm9, xmm3
000072bd77dd5fe0  mulpd xmm9, xmm1
000072bd77dd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000072bd77dd5feb  ptest xmm15, xmm15
000072bd77dd5ff1  jnz 0x000072BD77DD84E3
000072bd77dd5ff7  lea r14, [rax+0xC0]
000072bd77dd5ffe  movups xmm1, [r13+r14*1]
000072bd77dd6004  vmovaps xmm3, [rsp+0xC0]
000072bd77dd600d  vmovaps [rsp+0x80], xmm1
000072bd77dd6016  movaps xmm15, xmm3
000072bd77dd601a  addpd xmm15, xmm7
000072bd77dd601f  vcmppd xmm1, xmm15, xmm15, 0x03
000072bd77dd6025  ptest xmm1, xmm1
000072bd77dd602a  jnz 0x000072BD77DD862F
000072bd77dd6030  vmovaps [rsp+0xC0], xmm13
000072bd77dd6039  vmovaps xmm1, [rsp+0xC0]
000072bd77dd6042  por xmm13, xmm1
000072bd77dd6047  movaps [r15+0x270], xmm13
000072bd77dd604f  vmovaps xmm1, [rsp+0xB0]
000072bd77dd6058  vmovaps xmm7, [rsp+0xB0]
000072bd77dd6061  por xmm1, xmm7
000072bd77dd6065  movaps [r15+0x1A0], xmm1
000072bd77dd606d  vmovaps xmm1, [rsp+0x60]
000072bd77dd6073  vpermilpd xmm1, xmm1, 0x00
000072bd77dd6079  vmovaps [rsp+0xB0], xmm1
000072bd77dd6082  vmovaps xmm1, [rsp+0x80]
000072bd77dd608b  vmovaps [rsp+0x80], xmm15
000072bd77dd6094  vmovaps xmm15, [rsp+0xB0]
000072bd77dd609d  vmovaps [rsp+0xB0], xmm14
000072bd77dd60a6  movaps xmm3, xmm1
000072bd77dd60a9  mulpd xmm3, xmm15
000072bd77dd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000072bd77dd60b3  ptest xmm14, xmm14
000072bd77dd60b9  jnz 0x000072BD77DD8771
000072bd77dd60bf  lea r14, [rax+0x20]
000072bd77dd60c3  movups xmm1, [r13+r14*1]
000072bd77dd60c9  movaps [r15+0x110], xmm1
000072bd77dd60d1  vmovaps xmm14, [rsp+0x70]
000072bd77dd60d7  vmovaps [rsp+0x70], xmm1
000072bd77dd60dd  movaps xmm15, xmm14
000072bd77dd60e1  addpd xmm15, xmm4
000072bd77dd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000072bd77dd60ec  ptest xmm1, xmm1
000072bd77dd60f1  jnz 0x000072BD77DD88BC
000072bd77dd60f7  vmovaps xmm1, [rsp+0x60]
000072bd77dd60fd  vpermilpd xmm1, xmm1, 0x00
000072bd77dd6103  movaps xmm14, xmm2
000072bd77dd6107  mulpd xmm14, xmm1
000072bd77dd610c  vcmppd xmm4, xmm14, xmm14, 0x03
000072bd77dd6112  ptest xmm4, xmm4
000072bd77dd6117  jnz 0x000072BD77DD89FF
000072bd77dd611d  vmovaps xmm4, [rsp+0x50]
000072bd77dd6123  movaps xmm1, xmm4
000072bd77dd6126  addpd xmm1, xmm9
000072bd77dd612b  vcmppd xmm2, xmm1, xmm1, 0x03
000072bd77dd6130  ptest xmm2, xmm2
000072bd77dd6135  jnz 0x000072BD77DD8B41
000072bd77dd613b  vmovaps xmm9, [rsp+0x30]
000072bd77dd6141  vpermilpd xmm9, xmm9, 0x00
000072bd77dd6147  vmovaps xmm2, [rsp+0x70]
000072bd77dd614d  vmovaps [rsp+0x50], xmm1
000072bd77dd6153  movaps xmm4, xmm2
000072bd77dd6156  mulpd xmm4, xmm9
000072bd77dd615b  vcmppd xmm1, xmm4, xmm4, 0x03
000072bd77dd6160  ptest xmm1, xmm1
000072bd77dd6165  jnz 0x000072BD77DD8C82
000072bd77dd616b  vmovaps xmm1, [rsp+0x30]
000072bd77dd6171  vpermilpd xmm1, xmm1, 0x00
000072bd77dd6177  vmovaps xmm2, [rsp+0x90]
000072bd77dd6180  vmovaps [rsp+0x60], xmm15
000072bd77dd6186  movaps xmm9, xmm2
000072bd77dd618a  mulpd xmm9, xmm1
000072bd77dd618f  vcmppd xmm15, xmm9, xmm9, 0x03
000072bd77dd6195  ptest xmm15, xmm15
000072bd77dd619b  jnz 0x000072BD77DD8DC3
000072bd77dd61a1  vmovaps xmm15, [rsp+0x80]
000072bd77dd61aa  movaps xmm1, xmm15
000072bd77dd61ae  addpd xmm1, xmm6
000072bd77dd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000072bd77dd61b7  ptest xmm2, xmm2
000072bd77dd61bc  jnz 0x000072BD77DD8F05
000072bd77dd61c2  movaps xmm15, xmm5
000072bd77dd61c6  addpd xmm15, xmm3
000072bd77dd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000072bd77dd61d1  ptest xmm6, xmm6
000072bd77dd61d6  jnz 0x000072BD77DD9046
000072bd77dd61dc  vmovaps xmm6, [rsp+0x30]
000072bd77dd61e2  vpermilpd xmm6, xmm6, 0x00
000072bd77dd61e8  movaps xmm5, xmm8
000072bd77dd61ec  mulpd xmm5, xmm6
000072bd77dd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000072bd77dd61f5  ptest xmm3, xmm3
000072bd77dd61fa  jnz 0x000072BD77DD9188
000072bd77dd6200  vmovaps xmm8, [rsp+0x30]
000072bd77dd6206  vpermilpd xmm8, xmm8, 0x00
000072bd77dd620c  movaps xmm6, xmm10
000072bd77dd6210  mulpd xmm6, xmm8
000072bd77dd6215  vcmppd xmm3, xmm6, xmm6, 0x03
000072bd77dd621a  ptest xmm3, xmm3
000072bd77dd621f  jnz 0x000072BD77DD92C9
000072bd77dd6225  vmovaps xmm8, [rsp+0x60]
000072bd77dd622b  movaps xmm10, xmm8
000072bd77dd622f  addpd xmm10, xmm14
000072bd77dd6234  vcmppd xmm3, xmm10, xmm10, 0x03
000072bd77dd623a  ptest xmm3, xmm3
000072bd77dd623f  jnz 0x000072BD77DD940B
000072bd77dd6245  vmovaps xmm8, [rsp+0x50]
000072bd77dd624b  movaps xmm14, xmm8
000072bd77dd624f  addpd xmm14, xmm4
000072bd77dd6254  vcmppd xmm3, xmm14, xmm14, 0x03
000072bd77dd625a  ptest xmm3, xmm3
000072bd77dd625f  jnz 0x000072BD77DD954F
000072bd77dd6265  vmovaps xmm8, [rsp+0x40]
000072bd77dd626b  vpermilpd xmm8, xmm8, 0x00
000072bd77dd6271  movaps xmm4, xmm13
000072bd77dd6275  mulpd xmm4, xmm8
000072bd77dd627a  vcmppd xmm3, xmm4, xmm4, 0x03
000072bd77dd627f  ptest xmm3, xmm3
000072bd77dd6284  jnz 0x000072BD77DD9692
000072bd77dd628a  movaps xmm13, xmm15
000072bd77dd628e  addpd xmm13, xmm9
000072bd77dd6293  vcmppd xmm8, xmm13, xmm13, 0x03
000072bd77dd6299  ptest xmm8, xmm8
000072bd77dd629f  jnz 0x000072BD77DD97D4
000072bd77dd62a5  movaps xmm15, xmm1
000072bd77dd62a9  addpd xmm15, xmm5
000072bd77dd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000072bd77dd62b4  ptest xmm9, xmm9
000072bd77dd62ba  jnz 0x000072BD77DD9918
000072bd77dd62c0  vmovaps [rsp+0x30], xmm11
000072bd77dd62c6  vmovaps xmm1, [rsp+0x30]
000072bd77dd62cc  por xmm11, xmm1
000072bd77dd62d1  movaps [r15+0x250], xmm11
000072bd77dd62d9  vmovaps [rsp+0x30], xmm12
000072bd77dd62df  vmovaps xmm1, [rsp+0x30]
000072bd77dd62e5  por xmm12, xmm1
000072bd77dd62ea  movaps [r15+0x2A0], xmm12
000072bd77dd62f2  vmovaps xmm1, [rsp+0xA0]
000072bd77dd62fb  vmovaps xmm11, [rsp+0xA0]
000072bd77dd6304  por xmm1, xmm11
000072bd77dd6309  movaps [r15+0x1D0], xmm1
000072bd77dd6311  lea r14, [rax+0x40]
000072bd77dd6315  movups xmm1, [r13+r14*1]
000072bd77dd631b  movaps [r15+0x2C0], xmm1
000072bd77dd6323  vmovaps xmm11, [rsp+0x40]
000072bd77dd6329  vpermilpd xmm11, xmm11, 0x00
000072bd77dd632f  vmovaps xmm8, [rsp+0xE0]
000072bd77dd6338  movaps xmm9, xmm8
000072bd77dd633c  mulpd xmm9, xmm11
000072bd77dd6341  vcmppd xmm5, xmm9, xmm9, 0x03
000072bd77dd6347  ptest xmm5, xmm5
000072bd77dd634c  jnz 0x000072BD77DD9A64
000072bd77dd6352  movaps xmm11, xmm10
000072bd77dd6356  addpd xmm11, xmm6
000072bd77dd635b  vcmppd xmm8, xmm11, xmm11, 0x03
000072bd77dd6361  ptest xmm8, xmm8
000072bd77dd6367  jnz 0x000072BD77DD9BA8
000072bd77dd636d  movaps xmm10, xmm14
000072bd77dd6371  addpd xmm10, xmm4
000072bd77dd6376  vcmppd xmm8, xmm10, xmm10, 0x03
000072bd77dd637c  ptest xmm8, xmm8
000072bd77dd6382  jnz 0x000072BD77DD9CEB
000072bd77dd6388  vmovaps xmm14, [rsp+0x40]
000072bd77dd638e  vpermilpd xmm14, xmm14, 0x00
000072bd77dd6394  movaps xmm8, xmm1
000072bd77dd6398  mulpd xmm8, xmm14
000072bd77dd639d  vcmppd xmm6, xmm8, xmm8, 0x03
000072bd77dd63a3  ptest xmm6, xmm6
000072bd77dd63a8  jnz 0x000072BD77DD9E2E
000072bd77dd63ae  movaps xmm1, [r15+0x2B0]
000072bd77dd63b6  vmovaps xmm14, [rsp+0x40]
000072bd77dd63bc  vpermilpd xmm14, xmm14, 0x00
000072bd77dd63c2  movaps xmm6, xmm1
000072bd77dd63c5  mulpd xmm6, xmm14
000072bd77dd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000072bd77dd63cf  ptest xmm5, xmm5
000072bd77dd63d4  jnz 0x000072BD77DD9F71
000072bd77dd63da  vmovaps xmm1, [rsp+0x10]
000072bd77dd63e0  vpermilpd xmm1, xmm1, 0x00
000072bd77dd63e6  movaps xmm14, xmm12
000072bd77dd63ea  mulpd xmm14, xmm1
000072bd77dd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000072bd77dd63f5  ptest xmm5, xmm5
000072bd77dd63fa  jnz 0x000072BD77DDA0B2
000072bd77dd6400  movaps xmm1, xmm13
000072bd77dd6404  addpd xmm1, xmm9
000072bd77dd6409  vcmppd xmm12, xmm1, xmm1, 0x03
000072bd77dd640e  ptest xmm12, xmm12
000072bd77dd6414  jnz 0x000072BD77DDA1F5
000072bd77dd641a  vmovaps xmm13, [rsp+0x10]
000072bd77dd6420  vpermilpd xmm13, xmm13, 0x00
000072bd77dd6426  movaps xmm12, xmm7
000072bd77dd642a  mulpd xmm12, xmm13
000072bd77dd642f  vcmppd xmm9, xmm12, xmm12, 0x03
000072bd77dd6435  ptest xmm9, xmm9
000072bd77dd643b  jnz 0x000072BD77DDA337
000072bd77dd6441  movaps xmm13, xmm15
000072bd77dd6445  addpd xmm13, xmm8
000072bd77dd644a  vcmppd xmm9, xmm13, xmm13, 0x03
000072bd77dd6450  ptest xmm9, xmm9
000072bd77dd6456  jnz 0x000072BD77DDA47A
000072bd77dd645c  movaps xmm15, [r15+0x290]
000072bd77dd6464  vmovaps xmm9, [rsp+0x10]
000072bd77dd646a  vpermilpd xmm9, xmm9, 0x00
000072bd77dd6470  movaps xmm8, xmm15
000072bd77dd6474  mulpd xmm8, xmm9
000072bd77dd6479  vcmppd xmm7, xmm8, xmm8, 0x03
000072bd77dd647f  ptest xmm7, xmm7
000072bd77dd6484  jnz 0x000072BD77DDA5BE
000072bd77dd648a  movaps xmm15, xmm11
000072bd77dd648e  addpd xmm15, xmm6
000072bd77dd6493  vcmppd xmm9, xmm15, xmm15, 0x03
000072bd77dd6499  ptest xmm9, xmm9
000072bd77dd649f  jnz 0x000072BD77DDA702
000072bd77dd64a5  movaps xmm11, [r15+0x1E0]
000072bd77dd64ad  vmovaps xmm9, [rsp+0x10]
000072bd77dd64b3  vpermilpd xmm9, xmm9, 0x00
000072bd77dd64b9  movaps xmm7, xmm11
000072bd77dd64bd  mulpd xmm7, xmm9
000072bd77dd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000072bd77dd64c7  ptest xmm6, xmm6
000072bd77dd64cc  jnz 0x000072BD77DDA845
000072bd77dd64d2  movaps xmm11, xmm10
000072bd77dd64d6  addpd xmm11, xmm14
000072bd77dd64db  vcmppd xmm9, xmm11, xmm11, 0x03
000072bd77dd64e1  ptest xmm9, xmm9
000072bd77dd64e7  jnz 0x000072BD77DDA987
000072bd77dd64ed  lea r14, [rax+0x70]
000072bd77dd64f1  movups xmm14, [r13+r14*1]
000072bd77dd64f7  movaps [r15+0x240], xmm14
000072bd77dd64ff  movaps xmm10, xmm1
000072bd77dd6503  addpd xmm10, xmm12
000072bd77dd6508  vcmppd xmm9, xmm10, xmm10, 0x03
000072bd77dd650e  ptest xmm9, xmm9
000072bd77dd6514  jnz 0x000072BD77DDAAD5
000072bd77dd651a  movaps [r15+0x170], xmm10
000072bd77dd6522  vmovaps xmm1, [rsp+0x20]
000072bd77dd6528  vpermilpd xmm1, xmm1, 0x00
000072bd77dd652e  movaps xmm12, xmm14
000072bd77dd6532  mulpd xmm12, xmm1
000072bd77dd6537  vcmppd xmm9, xmm12, xmm12, 0x03
000072bd77dd653d  ptest xmm9, xmm9
000072bd77dd6543  jnz 0x000072BD77DDAC18
000072bd77dd6549  vmovaps xmm1, [rsp+0x20]
000072bd77dd654f  vpermilpd xmm1, xmm1, 0x00
000072bd77dd6555  vmovaps xmm9, [rsp+0xB0]
000072bd77dd655e  movaps xmm14, xmm9
000072bd77dd6562  mulpd xmm14, xmm1
000072bd77dd6567  vcmppd xmm6, xmm14, xmm14, 0x03
000072bd77dd656d  ptest xmm6, xmm6
000072bd77dd6572  jnz 0x000072BD77DDAD5B
000072bd77dd6578  movaps [r15+0x180], xmm14
000072bd77dd6580  movaps xmm1, xmm13
000072bd77dd6584  addpd xmm1, xmm8
000072bd77dd6589  vcmppd xmm9, xmm1, xmm1, 0x03
000072bd77dd658e  ptest xmm9, xmm9
000072bd77dd6594  jnz 0x000072BD77DDAE9E
000072bd77dd659a  movaps [r15+0x210], xmm1
000072bd77dd65a2  movups xmm13, [r13+rax*1]
000072bd77dd65a8  lea r14, [rax+0x10]
000072bd77dd65ac  movups xmm9, [r13+r14*1]
000072bd77dd65b2  movaps [r15+0x230], xmm9
000072bd77dd65ba  movaps xmm8, xmm15
000072bd77dd65be  addpd xmm8, xmm7
000072bd77dd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000072bd77dd65c9  ptest xmm6, xmm6
000072bd77dd65ce  jnz 0x000072BD77DDAFF4
000072bd77dd65d4  movaps [r15+0x130], xmm8
000072bd77dd65dc  vmovaps xmm15, [rsp+0x20]
000072bd77dd65e2  vpermilpd xmm15, xmm15, 0x00
000072bd77dd65e8  movaps xmm7, xmm9
000072bd77dd65ec  mulpd xmm7, xmm15
000072bd77dd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000072bd77dd65f6  ptest xmm6, xmm6
000072bd77dd65fb  jnz 0x000072BD77DDB137
000072bd77dd6601  movaps [r15+0x220], xmm7
000072bd77dd6609  vmovaps xmm15, [rsp+0x20]
000072bd77dd660f  vpermilpd xmm15, xmm15, 0x00
000072bd77dd6615  movaps xmm9, xmm13
000072bd77dd6619  mulpd xmm9, xmm15
000072bd77dd661e  vcmppd xmm6, xmm9, xmm9, 0x03
000072bd77dd6624  ptest xmm6, xmm6
000072bd77dd6629  jnz 0x000072BD77DDB279
000072bd77dd662f  movaps xmm15, xmm11
000072bd77dd6633  addpd xmm15, xmm12
000072bd77dd6638  vcmppd xmm13, xmm15, xmm15, 0x03
000072bd77dd663e  ptest xmm13, xmm13
000072bd77dd6644  jnz 0x000072BD77DDB3BD
000072bd77dd664a  movaps [r15+0x140], xmm15
000072bd77dd6652  movaps xmm13, xmm10
000072bd77dd6656  addpd xmm13, xmm14
000072bd77dd665b  vcmppd xmm12, xmm13, xmm13, 0x03
000072bd77dd6661  ptest xmm12, xmm12
000072bd77dd6667  jnz 0x000072BD77DDB501
000072bd77dd666d  movaps [r15+0x150], xmm13
000072bd77dd6675  movaps xmm14, xmm1
000072bd77dd6679  addpd xmm14, xmm7
000072bd77dd667e  vcmppd xmm12, xmm14, xmm14, 0x03
000072bd77dd6684  ptest xmm12, xmm12
000072bd77dd668a  jnz 0x000072BD77DDB645
000072bd77dd6690  movaps [r15+0x160], xmm14
000072bd77dd6698  movaps xmm1, xmm8
000072bd77dd669c  addpd xmm1, xmm9
000072bd77dd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000072bd77dd66a6  ptest xmm12, xmm12
000072bd77dd66ac  jnz 0x000072BD77DDB787
000072bd77dd66b2  movaps [r15+0x120], xmm1
000072bd77dd66ba  movups [r13+r11*1], xmm15
000072bd77dd66c0  lea rax, [r11+0x10]
000072bd77dd66c4  movups [r13+rax*1], xmm13
000072bd77dd66ca  lea rax, [r11+0x20]
000072bd77dd66ce  movups [r13+rax*1], xmm14
000072bd77dd66d4  lea rax, [r11+0x30]
000072bd77dd66d8  movups [r13+rax*1], xmm1
000072bd77dd66de  mov eax, [r15+0x108]
000072bd77dd66e5  sahf
000072bd77dd66e6  jnz 0x000072BD77DD6718
000072bd77dd66e8  cmp dword ptr [r15+0x318], 0x00
000072bd77dd66f0  jz 0x000072BD77DDB900
000072bd77dd66f6  nop [rax+rax*1], ax
000072bd77dd66ff  nop [rax+rax*1], eax
000072bd77dd6707  mov eax, 0x410444
000072bd77dd670c  mov [r15+0x100], rax
000072bd77dd6713  jmp 0x000072BD77BFE110
000072bd77dd6718  cmp dword ptr [r15+0x318], 0x00
000072bd77dd6720  jz 0x000072BD77DD57E0
000072bd77dd6726  nop [rax+rax*1], ax
000072bd77dd672f  nop [rax+rax*1], eax
000072bd77dd6737  mov eax, 0x410278
000072bd77dd673c  mov [r15+0x100], rax
000072bd77dd6743  jmp 0x000072BD77BFE110
000072bd77dd6748  int3
000072bd77dd6749  call 0x000072BD77C0A4B0
000072bd77dd674e  jmp 0x000072BD77DD5828
000072bd77dd6753  call 0x000072BD77C09240
000072bd77dd6758  jmp 0x000072BD77DD5832
000072bd77dd675d  call 0x000072BD77C0A4B0
000072bd77dd6762  jmp 0x000072BD77DD588F
000072bd77dd6767  call 0x000072BD77C09240
000072bd77dd676c  jmp 0x000072BD77DD5899
000072bd77dd6771  call 0x000072BD77C0A4B0
000072bd77dd6776  jmp 0x000072BD77DD58DD
000072bd77dd677b  call 0x000072BD77C09240
000072bd77dd6780  jmp 0x000072BD77DD58E7
000072bd77dd6785  call 0x000072BD77CB47C0
000072bd77dd678a  jmp 0x000072BD77DD5926
000072bd77dd678f  call 0x000072BD77C0B720
000072bd77dd6794  jmp 0x000072BD77DD593A
000072bd77dd6799  call 0x000072BD77CBFC30
000072bd77dd679e  jmp 0x000072BD77DD5958
000072bd77dd67a3  call 0x000072BD77CBE9C0
000072bd77dd67a8  jmp 0x000072BD77DD5962
000072bd77dd67ad  call 0x000072BD77CBD750
000072bd77dd67b2  jmp 0x000072BD77DD596C
000072bd77dd67b7  sub rsp, 0x08
000072bd77dd67bb  push rax
000072bd77dd67bc  push rcx
000072bd77dd67bd  push rdx
000072bd77dd67be  push rdi
000072bd77dd67bf  push rsi
000072bd77dd67c0  push r8
000072bd77dd67c2  push r9
000072bd77dd67c4  push r10
000072bd77dd67c6  push r11
000072bd77dd67c8  sub rsp, 0xF0
000072bd77dd67cf  vmovaps [rsp], xmm0
000072bd77dd67d4  vmovaps [rsp+0x10], xmm1
000072bd77dd67da  vmovaps [rsp+0x20], xmm2
000072bd77dd67e0  vmovaps [rsp+0x30], xmm3
000072bd77dd67e6  vmovaps [rsp+0x40], xmm4
000072bd77dd67ec  vmovaps [rsp+0x50], xmm5
000072bd77dd67f2  vmovaps [rsp+0x60], xmm6
000072bd77dd67f8  vmovaps [rsp+0x70], xmm7
000072bd77dd67fe  vmovaps [rsp+0x80], xmm9
000072bd77dd6807  vmovaps [rsp+0x90], xmm10
000072bd77dd6810  vmovaps [rsp+0xA0], xmm11
000072bd77dd6819  vmovaps [rsp+0xB0], xmm12
000072bd77dd6822  vmovaps [rsp+0xC0], xmm13
000072bd77dd682b  vmovaps [rsp+0xD0], xmm14
000072bd77dd6834  vmovaps [rsp+0xE0], xmm15
000072bd77dd683d  sub rsp, 0x30
000072bd77dd6841  movaps [rsp], xmm8
000072bd77dd6846  movaps [rsp+0x10], xmm12
000072bd77dd684c  movaps [rsp+0x20], xmm15
000072bd77dd6852  lea rdi, [rsp]
000072bd77dd6856  mov esi, 0x00
000072bd77dd685b  mov rax, 0x643206AC3530
000072bd77dd6865  call rax
000072bd77dd6867  movaps xmm8, [rsp]
000072bd77dd686c  add rsp, 0x30
000072bd77dd6870  vmovaps xmm0, [rsp]
000072bd77dd6875  vmovaps xmm1, [rsp+0x10]
000072bd77dd687b  vmovaps xmm2, [rsp+0x20]
000072bd77dd6881  vmovaps xmm3, [rsp+0x30]
000072bd77dd6887  vmovaps xmm4, [rsp+0x40]
000072bd77dd688d  vmovaps xmm5, [rsp+0x50]
000072bd77dd6893  vmovaps xmm6, [rsp+0x60]
000072bd77dd6899  vmovaps xmm7, [rsp+0x70]
000072bd77dd689f  vmovaps xmm9, [rsp+0x80]
000072bd77dd68a8  vmovaps xmm10, [rsp+0x90]
000072bd77dd68b1  vmovaps xmm11, [rsp+0xA0]
000072bd77dd68ba  vmovaps xmm12, [rsp+0xB0]
000072bd77dd68c3  vmovaps xmm13, [rsp+0xC0]
000072bd77dd68cc  vmovaps xmm14, [rsp+0xD0]
000072bd77dd68d5  vmovaps xmm15, [rsp+0xE0]
000072bd77dd68de  add rsp, 0xF0
000072bd77dd68e5  pop r11
000072bd77dd68e7  pop r10
000072bd77dd68e9  pop r9
000072bd77dd68eb  pop r8
000072bd77dd68ed  pop rsi
000072bd77dd68ee  pop rdi
000072bd77dd68ef  pop rdx
000072bd77dd68f0  pop rcx
000072bd77dd68f1  pop rax
000072bd77dd68f2  add rsp, 0x08
000072bd77dd68f6  jmp 0x000072BD77DD599A
000072bd77dd68fb  sub rsp, 0x08
000072bd77dd68ff  push rax
000072bd77dd6900  push rcx
000072bd77dd6901  push rdx
000072bd77dd6902  push rdi
000072bd77dd6903  push rsi
000072bd77dd6904  push r8
000072bd77dd6906  push r9
000072bd77dd6908  push r10
000072bd77dd690a  push r11
000072bd77dd690c  sub rsp, 0xF0
000072bd77dd6913  vmovaps [rsp], xmm0
000072bd77dd6918  vmovaps [rsp+0x10], xmm1
000072bd77dd691e  vmovaps [rsp+0x20], xmm2
000072bd77dd6924  vmovaps [rsp+0x30], xmm3
000072bd77dd692a  vmovaps [rsp+0x40], xmm4
000072bd77dd6930  vmovaps [rsp+0x50], xmm5
000072bd77dd6936  vmovaps [rsp+0x60], xmm6
000072bd77dd693c  vmovaps [rsp+0x70], xmm8
000072bd77dd6942  vmovaps [rsp+0x80], xmm9
000072bd77dd694b  vmovaps [rsp+0x90], xmm10
000072bd77dd6954  vmovaps [rsp+0xA0], xmm11
000072bd77dd695d  vmovaps [rsp+0xB0], xmm12
000072bd77dd6966  vmovaps [rsp+0xC0], xmm13
000072bd77dd696f  vmovaps [rsp+0xD0], xmm14
000072bd77dd6978  vmovaps [rsp+0xE0], xmm15
000072bd77dd6981  sub rsp, 0x30
000072bd77dd6985  movaps [rsp], xmm7
000072bd77dd6989  movaps [rsp+0x10], xmm9
000072bd77dd698f  movaps [rsp+0x20], xmm15
000072bd77dd6995  lea rdi, [rsp]
000072bd77dd6999  mov esi, 0x00
000072bd77dd699e  mov rax, 0x643206AC3530
000072bd77dd69a8  call rax
000072bd77dd69aa  movaps xmm7, [rsp]
000072bd77dd69ae  add rsp, 0x30
000072bd77dd69b2  vmovaps xmm0, [rsp]
000072bd77dd69b7  vmovaps xmm1, [rsp+0x10]
000072bd77dd69bd  vmovaps xmm2, [rsp+0x20]
000072bd77dd69c3  vmovaps xmm3, [rsp+0x30]
000072bd77dd69c9  vmovaps xmm4, [rsp+0x40]
000072bd77dd69cf  vmovaps xmm5, [rsp+0x50]
000072bd77dd69d5  vmovaps xmm6, [rsp+0x60]
000072bd77dd69db  vmovaps xmm8, [rsp+0x70]
000072bd77dd69e1  vmovaps xmm9, [rsp+0x80]
000072bd77dd69ea  vmovaps xmm10, [rsp+0x90]
000072bd77dd69f3  vmovaps xmm11, [rsp+0xA0]
000072bd77dd69fc  vmovaps xmm12, [rsp+0xB0]
000072bd77dd6a05  vmovaps xmm13, [rsp+0xC0]
000072bd77dd6a0e  vmovaps xmm14, [rsp+0xD0]
000072bd77dd6a17  vmovaps xmm15, [rsp+0xE0]
000072bd77dd6a20  add rsp, 0xF0
000072bd77dd6a27  pop r11
000072bd77dd6a29  pop r10
000072bd77dd6a2b  pop r9
000072bd77dd6a2d  pop r8
000072bd77dd6a2f  pop rsi
000072bd77dd6a30  pop rdi
000072bd77dd6a31  pop rdx
000072bd77dd6a32  pop rcx
000072bd77dd6a33  pop rax
000072bd77dd6a34  add rsp, 0x08
000072bd77dd6a38  jmp 0x000072BD77DD59C8
000072bd77dd6a3d  sub rsp, 0x08
000072bd77dd6a41  push rax
000072bd77dd6a42  push rcx
000072bd77dd6a43  push rdx
000072bd77dd6a44  push rdi
000072bd77dd6a45  push rsi
000072bd77dd6a46  push r8
000072bd77dd6a48  push r9
000072bd77dd6a4a  push r10
000072bd77dd6a4c  push r11
000072bd77dd6a4e  sub rsp, 0xF0
000072bd77dd6a55  vmovaps [rsp], xmm0
000072bd77dd6a5a  vmovaps [rsp+0x10], xmm1
000072bd77dd6a60  vmovaps [rsp+0x20], xmm2
000072bd77dd6a66  vmovaps [rsp+0x30], xmm3
000072bd77dd6a6c  vmovaps [rsp+0x40], xmm4
000072bd77dd6a72  vmovaps [rsp+0x50], xmm5
000072bd77dd6a78  vmovaps [rsp+0x60], xmm6
000072bd77dd6a7e  vmovaps [rsp+0x70], xmm7
000072bd77dd6a84  vmovaps [rsp+0x80], xmm8
000072bd77dd6a8d  vmovaps [rsp+0x90], xmm10
000072bd77dd6a96  vmovaps [rsp+0xA0], xmm11
000072bd77dd6a9f  vmovaps [rsp+0xB0], xmm12
000072bd77dd6aa8  vmovaps [rsp+0xC0], xmm13
000072bd77dd6ab1  vmovaps [rsp+0xD0], xmm14
000072bd77dd6aba  vmovaps [rsp+0xE0], xmm15
000072bd77dd6ac3  sub rsp, 0x30
000072bd77dd6ac7  movaps [rsp], xmm9
000072bd77dd6acc  movaps [rsp+0x10], xmm12
000072bd77dd6ad2  movaps [rsp+0x20], xmm10
000072bd77dd6ad8  lea rdi, [rsp]
000072bd77dd6adc  mov esi, 0x00
000072bd77dd6ae1  mov rax, 0x643206AC3530
000072bd77dd6aeb  call rax
000072bd77dd6aed  movaps xmm9, [rsp]
000072bd77dd6af2  add rsp, 0x30
000072bd77dd6af6  vmovaps xmm0, [rsp]
000072bd77dd6afb  vmovaps xmm1, [rsp+0x10]
000072bd77dd6b01  vmovaps xmm2, [rsp+0x20]
000072bd77dd6b07  vmovaps xmm3, [rsp+0x30]
000072bd77dd6b0d  vmovaps xmm4, [rsp+0x40]
000072bd77dd6b13  vmovaps xmm5, [rsp+0x50]
000072bd77dd6b19  vmovaps xmm6, [rsp+0x60]
000072bd77dd6b1f  vmovaps xmm7, [rsp+0x70]
000072bd77dd6b25  vmovaps xmm8, [rsp+0x80]
000072bd77dd6b2e  vmovaps xmm10, [rsp+0x90]
000072bd77dd6b37  vmovaps xmm11, [rsp+0xA0]
000072bd77dd6b40  vmovaps xmm12, [rsp+0xB0]
000072bd77dd6b49  vmovaps xmm13, [rsp+0xC0]
000072bd77dd6b52  vmovaps xmm14, [rsp+0xD0]
000072bd77dd6b5b  vmovaps xmm15, [rsp+0xE0]
000072bd77dd6b64  add rsp, 0xF0
000072bd77dd6b6b  pop r11
000072bd77dd6b6d  pop r10
000072bd77dd6b6f  pop r9
000072bd77dd6b71  pop r8
000072bd77dd6b73  pop rsi
000072bd77dd6b74  pop rdi
000072bd77dd6b75  pop rdx
000072bd77dd6b76  pop rcx
000072bd77dd6b77  pop rax
000072bd77dd6b78  add rsp, 0x08
000072bd77dd6b7c  jmp 0x000072BD77DD59EC
000072bd77dd6b81  sub rsp, 0x08
000072bd77dd6b85  push rax
000072bd77dd6b86  push rcx
000072bd77dd6b87  push rdx
000072bd77dd6b88  push rdi
000072bd77dd6b89  push rsi
000072bd77dd6b8a  push r8
000072bd77dd6b8c  push r9
000072bd77dd6b8e  push r10
000072bd77dd6b90  push r11
000072bd77dd6b92  sub rsp, 0xF0
000072bd77dd6b99  vmovaps [rsp], xmm0
000072bd77dd6b9e  vmovaps [rsp+0x10], xmm1
000072bd77dd6ba4  vmovaps [rsp+0x20], xmm2
000072bd77dd6baa  vmovaps [rsp+0x30], xmm3
000072bd77dd6bb0  vmovaps [rsp+0x40], xmm4
000072bd77dd6bb6  vmovaps [rsp+0x50], xmm5
000072bd77dd6bbc  vmovaps [rsp+0x60], xmm6
000072bd77dd6bc2  vmovaps [rsp+0x70], xmm7
000072bd77dd6bc8  vmovaps [rsp+0x80], xmm8
000072bd77dd6bd1  vmovaps [rsp+0x90], xmm9
000072bd77dd6bda  vmovaps [rsp+0xA0], xmm11
000072bd77dd6be3  vmovaps [rsp+0xB0], xmm12
000072bd77dd6bec  vmovaps [rsp+0xC0], xmm13
000072bd77dd6bf5  vmovaps [rsp+0xD0], xmm14
000072bd77dd6bfe  vmovaps [rsp+0xE0], xmm15
000072bd77dd6c07  sub rsp, 0x30
000072bd77dd6c0b  movaps [rsp], xmm10
000072bd77dd6c10  movaps [rsp+0x10], xmm12
000072bd77dd6c16  movaps [rsp+0x20], xmm11
000072bd77dd6c1c  lea rdi, [rsp]
000072bd77dd6c20  mov esi, 0x00
000072bd77dd6c25  mov rax, 0x643206AC3530
000072bd77dd6c2f  call rax
000072bd77dd6c31  movaps xmm10, [rsp]
000072bd77dd6c36  add rsp, 0x30
000072bd77dd6c3a  vmovaps xmm0, [rsp]
000072bd77dd6c3f  vmovaps xmm1, [rsp+0x10]
000072bd77dd6c45  vmovaps xmm2, [rsp+0x20]
000072bd77dd6c4b  vmovaps xmm3, [rsp+0x30]
000072bd77dd6c51  vmovaps xmm4, [rsp+0x40]
000072bd77dd6c57  vmovaps xmm5, [rsp+0x50]
000072bd77dd6c5d  vmovaps xmm6, [rsp+0x60]
000072bd77dd6c63  vmovaps xmm7, [rsp+0x70]
000072bd77dd6c69  vmovaps xmm8, [rsp+0x80]
000072bd77dd6c72  vmovaps xmm9, [rsp+0x90]
000072bd77dd6c7b  vmovaps xmm11, [rsp+0xA0]
000072bd77dd6c84  vmovaps xmm12, [rsp+0xB0]
000072bd77dd6c8d  vmovaps xmm13, [rsp+0xC0]
000072bd77dd6c96  vmovaps xmm14, [rsp+0xD0]
000072bd77dd6c9f  vmovaps xmm15, [rsp+0xE0]
000072bd77dd6ca8  add rsp, 0xF0
000072bd77dd6caf  pop r11
000072bd77dd6cb1  pop r10
000072bd77dd6cb3  pop r9
000072bd77dd6cb5  pop r8
000072bd77dd6cb7  pop rsi
000072bd77dd6cb8  pop rdi
000072bd77dd6cb9  pop rdx
000072bd77dd6cba  pop rcx
000072bd77dd6cbb  pop rax
000072bd77dd6cbc  add rsp, 0x08
000072bd77dd6cc0  jmp 0x000072BD77DD5A06
000072bd77dd6cc5  sub rsp, 0x08
000072bd77dd6cc9  push rax
000072bd77dd6cca  push rcx
000072bd77dd6ccb  push rdx
000072bd77dd6ccc  push rdi
000072bd77dd6ccd  push rsi
000072bd77dd6cce  push r8
000072bd77dd6cd0  push r9
000072bd77dd6cd2  push r10
000072bd77dd6cd4  push r11
000072bd77dd6cd6  sub rsp, 0xF0
000072bd77dd6cdd  vmovaps [rsp], xmm0
000072bd77dd6ce2  vmovaps [rsp+0x10], xmm1
000072bd77dd6ce8  vmovaps [rsp+0x20], xmm2
000072bd77dd6cee  vmovaps [rsp+0x30], xmm3
000072bd77dd6cf4  vmovaps [rsp+0x40], xmm4
000072bd77dd6cfa  vmovaps [rsp+0x50], xmm5
000072bd77dd6d00  vmovaps [rsp+0x60], xmm7
000072bd77dd6d06  vmovaps [rsp+0x70], xmm8
000072bd77dd6d0c  vmovaps [rsp+0x80], xmm9
000072bd77dd6d15  vmovaps [rsp+0x90], xmm10
000072bd77dd6d1e  vmovaps [rsp+0xA0], xmm11
000072bd77dd6d27  vmovaps [rsp+0xB0], xmm12
000072bd77dd6d30  vmovaps [rsp+0xC0], xmm13
000072bd77dd6d39  vmovaps [rsp+0xD0], xmm14
000072bd77dd6d42  vmovaps [rsp+0xE0], xmm15
000072bd77dd6d4b  sub rsp, 0x30
000072bd77dd6d4f  movaps [rsp], xmm6
000072bd77dd6d53  movaps [rsp+0x10], xmm12
000072bd77dd6d59  movaps [rsp+0x20], xmm11
000072bd77dd6d5f  lea rdi, [rsp]
000072bd77dd6d63  mov esi, 0x00
000072bd77dd6d68  mov rax, 0x643206AC3530
000072bd77dd6d72  call rax
000072bd77dd6d74  movaps xmm6, [rsp]
000072bd77dd6d78  add rsp, 0x30
000072bd77dd6d7c  vmovaps xmm0, [rsp]
000072bd77dd6d81  vmovaps xmm1, [rsp+0x10]
000072bd77dd6d87  vmovaps xmm2, [rsp+0x20]
000072bd77dd6d8d  vmovaps xmm3, [rsp+0x30]
000072bd77dd6d93  vmovaps xmm4, [rsp+0x40]
000072bd77dd6d99  vmovaps xmm5, [rsp+0x50]
000072bd77dd6d9f  vmovaps xmm7, [rsp+0x60]
000072bd77dd6da5  vmovaps xmm8, [rsp+0x70]
000072bd77dd6dab  vmovaps xmm9, [rsp+0x80]
000072bd77dd6db4  vmovaps xmm10, [rsp+0x90]
000072bd77dd6dbd  vmovaps xmm11, [rsp+0xA0]
000072bd77dd6dc6  vmovaps xmm12, [rsp+0xB0]
000072bd77dd6dcf  vmovaps xmm13, [rsp+0xC0]
000072bd77dd6dd8  vmovaps xmm14, [rsp+0xD0]
000072bd77dd6de1  vmovaps xmm15, [rsp+0xE0]
000072bd77dd6dea  add rsp, 0xF0
000072bd77dd6df1  pop r11
000072bd77dd6df3  pop r10
000072bd77dd6df5  pop r9
000072bd77dd6df7  pop r8
000072bd77dd6df9  pop rsi
000072bd77dd6dfa  pop rdi
000072bd77dd6dfb  pop rdx
000072bd77dd6dfc  pop rcx
000072bd77dd6dfd  pop rax
000072bd77dd6dfe  add rsp, 0x08
000072bd77dd6e02  jmp 0x000072BD77DD5A27
000072bd77dd6e07  sub rsp, 0x08
000072bd77dd6e0b  push rax
000072bd77dd6e0c  push rcx
000072bd77dd6e0d  push rdx
000072bd77dd6e0e  push rdi
000072bd77dd6e0f  push rsi
000072bd77dd6e10  push r8
000072bd77dd6e12  push r9
000072bd77dd6e14  push r10
000072bd77dd6e16  push r11
000072bd77dd6e18  sub rsp, 0xF0
000072bd77dd6e1f  vmovaps [rsp], xmm0
000072bd77dd6e24  vmovaps [rsp+0x10], xmm1
000072bd77dd6e2a  vmovaps [rsp+0x20], xmm2
000072bd77dd6e30  vmovaps [rsp+0x30], xmm4
000072bd77dd6e36  vmovaps [rsp+0x40], xmm5
000072bd77dd6e3c  vmovaps [rsp+0x50], xmm6
000072bd77dd6e42  vmovaps [rsp+0x60], xmm7
000072bd77dd6e48  vmovaps [rsp+0x70], xmm8
000072bd77dd6e4e  vmovaps [rsp+0x80], xmm9
000072bd77dd6e57  vmovaps [rsp+0x90], xmm10
000072bd77dd6e60  vmovaps [rsp+0xA0], xmm11
000072bd77dd6e69  vmovaps [rsp+0xB0], xmm12
000072bd77dd6e72  vmovaps [rsp+0xC0], xmm13
000072bd77dd6e7b  vmovaps [rsp+0xD0], xmm14
000072bd77dd6e84  vmovaps [rsp+0xE0], xmm15
000072bd77dd6e8d  sub rsp, 0x30
000072bd77dd6e91  movaps [rsp], xmm3
000072bd77dd6e95  movaps [rsp+0x10], xmm5
000072bd77dd6e9a  movaps [rsp+0x20], xmm4
000072bd77dd6e9f  lea rdi, [rsp]
000072bd77dd6ea3  mov esi, 0x00
000072bd77dd6ea8  mov rax, 0x643206AC3530
000072bd77dd6eb2  call rax
000072bd77dd6eb4  movaps xmm3, [rsp]
000072bd77dd6eb8  add rsp, 0x30
000072bd77dd6ebc  vmovaps xmm0, [rsp]
000072bd77dd6ec1  vmovaps xmm1, [rsp+0x10]
000072bd77dd6ec7  vmovaps xmm2, [rsp+0x20]
000072bd77dd6ecd  vmovaps xmm4, [rsp+0x30]
000072bd77dd6ed3  vmovaps xmm5, [rsp+0x40]
000072bd77dd6ed9  vmovaps xmm6, [rsp+0x50]
000072bd77dd6edf  vmovaps xmm7, [rsp+0x60]
000072bd77dd6ee5  vmovaps xmm8, [rsp+0x70]
000072bd77dd6eeb  vmovaps xmm9, [rsp+0x80]
000072bd77dd6ef4  vmovaps xmm10, [rsp+0x90]
000072bd77dd6efd  vmovaps xmm11, [rsp+0xA0]
000072bd77dd6f06  vmovaps xmm12, [rsp+0xB0]
000072bd77dd6f0f  vmovaps xmm13, [rsp+0xC0]
000072bd77dd6f18  vmovaps xmm14, [rsp+0xD0]
000072bd77dd6f21  vmovaps xmm15, [rsp+0xE0]
000072bd77dd6f2a  add rsp, 0xF0
000072bd77dd6f31  pop r11
000072bd77dd6f33  pop r10
000072bd77dd6f35  pop r9
000072bd77dd6f37  pop r8
000072bd77dd6f39  pop rsi
000072bd77dd6f3a  pop rdi
000072bd77dd6f3b  pop rdx
000072bd77dd6f3c  pop rcx
000072bd77dd6f3d  pop rax
000072bd77dd6f3e  add rsp, 0x08
000072bd77dd6f42  jmp 0x000072BD77DD5A88
000072bd77dd6f47  sub rsp, 0x08
000072bd77dd6f4b  push rax
000072bd77dd6f4c  push rcx
000072bd77dd6f4d  push rdx
000072bd77dd6f4e  push rdi
000072bd77dd6f4f  push rsi
000072bd77dd6f50  push r8
000072bd77dd6f52  push r9
000072bd77dd6f54  push r10
000072bd77dd6f56  push r11
000072bd77dd6f58  sub rsp, 0xF0
000072bd77dd6f5f  vmovaps [rsp], xmm0
000072bd77dd6f64  vmovaps [rsp+0x10], xmm1
000072bd77dd6f6a  vmovaps [rsp+0x20], xmm2
000072bd77dd6f70  vmovaps [rsp+0x30], xmm3
000072bd77dd6f76  vmovaps [rsp+0x40], xmm4
000072bd77dd6f7c  vmovaps [rsp+0x50], xmm6
000072bd77dd6f82  vmovaps [rsp+0x60], xmm7
000072bd77dd6f88  vmovaps [rsp+0x70], xmm8
000072bd77dd6f8e  vmovaps [rsp+0x80], xmm9
000072bd77dd6f97  vmovaps [rsp+0x90], xmm10
000072bd77dd6fa0  vmovaps [rsp+0xA0], xmm11
000072bd77dd6fa9  vmovaps [rsp+0xB0], xmm12
000072bd77dd6fb2  vmovaps [rsp+0xC0], xmm13
000072bd77dd6fbb  vmovaps [rsp+0xD0], xmm14
000072bd77dd6fc4  vmovaps [rsp+0xE0], xmm15
000072bd77dd6fcd  sub rsp, 0x30
000072bd77dd6fd1  movaps [rsp], xmm5
000072bd77dd6fd5  movaps [rsp+0x10], xmm8
000072bd77dd6fdb  movaps [rsp+0x20], xmm15
000072bd77dd6fe1  lea rdi, [rsp]
000072bd77dd6fe5  mov esi, 0x00
000072bd77dd6fea  mov rax, 0x643206AC3530
000072bd77dd6ff4  call rax
000072bd77dd6ff6  movaps xmm5, [rsp]
000072bd77dd6ffa  add rsp, 0x30
000072bd77dd6ffe  vmovaps xmm0, [rsp]
000072bd77dd7003  vmovaps xmm1, [rsp+0x10]
000072bd77dd7009  vmovaps xmm2, [rsp+0x20]
000072bd77dd700f  vmovaps xmm3, [rsp+0x30]
000072bd77dd7015  vmovaps xmm4, [rsp+0x40]
000072bd77dd701b  vmovaps xmm6, [rsp+0x50]
000072bd77dd7021  vmovaps xmm7, [rsp+0x60]
000072bd77dd7027  vmovaps xmm8, [rsp+0x70]
000072bd77dd702d  vmovaps xmm9, [rsp+0x80]
000072bd77dd7036  vmovaps xmm10, [rsp+0x90]
000072bd77dd703f  vmovaps xmm11, [rsp+0xA0]
000072bd77dd7048  vmovaps xmm12, [rsp+0xB0]
000072bd77dd7051  vmovaps xmm13, [rsp+0xC0]
000072bd77dd705a  vmovaps xmm14, [rsp+0xD0]
000072bd77dd7063  vmovaps xmm15, [rsp+0xE0]
000072bd77dd706c  add rsp, 0xF0
000072bd77dd7073  pop r11
000072bd77dd7075  pop r10
000072bd77dd7077  pop r9
000072bd77dd7079  pop r8
000072bd77dd707b  pop rsi
000072bd77dd707c  pop rdi
000072bd77dd707d  pop rdx
000072bd77dd707e  pop rcx
000072bd77dd707f  pop rax
000072bd77dd7080  add rsp, 0x08
000072bd77dd7084  jmp 0x000072BD77DD5AC0
000072bd77dd7089  sub rsp, 0x08
000072bd77dd708d  push rax
000072bd77dd708e  push rcx
000072bd77dd708f  push rdx
000072bd77dd7090  push rdi
000072bd77dd7091  push rsi
000072bd77dd7092  push r8
000072bd77dd7094  push r9
000072bd77dd7096  push r10
000072bd77dd7098  push r11
000072bd77dd709a  sub rsp, 0xF0
000072bd77dd70a1  vmovaps [rsp], xmm0
000072bd77dd70a6  vmovaps [rsp+0x10], xmm1
000072bd77dd70ac  vmovaps [rsp+0x20], xmm2
000072bd77dd70b2  vmovaps [rsp+0x30], xmm3
000072bd77dd70b8  vmovaps [rsp+0x40], xmm5
000072bd77dd70be  vmovaps [rsp+0x50], xmm6
000072bd77dd70c4  vmovaps [rsp+0x60], xmm7
000072bd77dd70ca  vmovaps [rsp+0x70], xmm8
000072bd77dd70d0  vmovaps [rsp+0x80], xmm9
000072bd77dd70d9  vmovaps [rsp+0x90], xmm10
000072bd77dd70e2  vmovaps [rsp+0xA0], xmm11
000072bd77dd70eb  vmovaps [rsp+0xB0], xmm12
000072bd77dd70f4  vmovaps [rsp+0xC0], xmm13
000072bd77dd70fd  vmovaps [rsp+0xD0], xmm14
000072bd77dd7106  vmovaps [rsp+0xE0], xmm15
000072bd77dd710f  sub rsp, 0x30
000072bd77dd7113  movaps [rsp], xmm4
000072bd77dd7117  movaps [rsp+0x10], xmm9
000072bd77dd711d  movaps [rsp+0x20], xmm8
000072bd77dd7123  lea rdi, [rsp]
000072bd77dd7127  mov esi, 0x00
000072bd77dd712c  mov rax, 0x643206AC3530
000072bd77dd7136  call rax
000072bd77dd7138  movaps xmm4, [rsp]
000072bd77dd713c  add rsp, 0x30
000072bd77dd7140  vmovaps xmm0, [rsp]
000072bd77dd7145  vmovaps xmm1, [rsp+0x10]
000072bd77dd714b  vmovaps xmm2, [rsp+0x20]
000072bd77dd7151  vmovaps xmm3, [rsp+0x30]
000072bd77dd7157  vmovaps xmm5, [rsp+0x40]
000072bd77dd715d  vmovaps xmm6, [rsp+0x50]
000072bd77dd7163  vmovaps xmm7, [rsp+0x60]
000072bd77dd7169  vmovaps xmm8, [rsp+0x70]
000072bd77dd716f  vmovaps xmm9, [rsp+0x80]
000072bd77dd7178  vmovaps xmm10, [rsp+0x90]
000072bd77dd7181  vmovaps xmm11, [rsp+0xA0]
000072bd77dd718a  vmovaps xmm12, [rsp+0xB0]
000072bd77dd7193  vmovaps xmm13, [rsp+0xC0]
000072bd77dd719c  vmovaps xmm14, [rsp+0xD0]
000072bd77dd71a5  vmovaps xmm15, [rsp+0xE0]
000072bd77dd71ae  add rsp, 0xF0
000072bd77dd71b5  pop r11
000072bd77dd71b7  pop r10
000072bd77dd71b9  pop r9
000072bd77dd71bb  pop r8
000072bd77dd71bd  pop rsi
000072bd77dd71be  pop rdi
000072bd77dd71bf  pop rdx
000072bd77dd71c0  pop rcx
000072bd77dd71c1  pop rax
000072bd77dd71c2  add rsp, 0x08
000072bd77dd71c6  jmp 0x000072BD77DD5AE1
000072bd77dd71cb  sub rsp, 0x08
000072bd77dd71cf  push rax
000072bd77dd71d0  push rcx
000072bd77dd71d1  push rdx
000072bd77dd71d2  push rdi
000072bd77dd71d3  push rsi
000072bd77dd71d4  push r8
000072bd77dd71d6  push r9
000072bd77dd71d8  push r10
000072bd77dd71da  push r11
000072bd77dd71dc  sub rsp, 0xF0
000072bd77dd71e3  vmovaps [rsp], xmm0
000072bd77dd71e8  vmovaps [rsp+0x10], xmm1
000072bd77dd71ee  vmovaps [rsp+0x20], xmm2
000072bd77dd71f4  vmovaps [rsp+0x30], xmm3
000072bd77dd71fa  vmovaps [rsp+0x40], xmm4
000072bd77dd7200  vmovaps [rsp+0x50], xmm5
000072bd77dd7206  vmovaps [rsp+0x60], xmm6
000072bd77dd720c  vmovaps [rsp+0x70], xmm7
000072bd77dd7212  vmovaps [rsp+0x80], xmm8
000072bd77dd721b  vmovaps [rsp+0x90], xmm10
000072bd77dd7224  vmovaps [rsp+0xA0], xmm11
000072bd77dd722d  vmovaps [rsp+0xB0], xmm12
000072bd77dd7236  vmovaps [rsp+0xC0], xmm13
000072bd77dd723f  vmovaps [rsp+0xD0], xmm14
000072bd77dd7248  vmovaps [rsp+0xE0], xmm15
000072bd77dd7251  sub rsp, 0x30
000072bd77dd7255  movaps [rsp], xmm9
000072bd77dd725a  movaps [rsp+0x10], xmm10
000072bd77dd7260  movaps [rsp+0x20], xmm8
000072bd77dd7266  lea rdi, [rsp]
000072bd77dd726a  mov esi, 0x00
000072bd77dd726f  mov rax, 0x643206AC3530
000072bd77dd7279  call rax
000072bd77dd727b  movaps xmm9, [rsp]
000072bd77dd7280  add rsp, 0x30
000072bd77dd7284  vmovaps xmm0, [rsp]
000072bd77dd7289  vmovaps xmm1, [rsp+0x10]
000072bd77dd728f  vmovaps xmm2, [rsp+0x20]
000072bd77dd7295  vmovaps xmm3, [rsp+0x30]
000072bd77dd729b  vmovaps xmm4, [rsp+0x40]
000072bd77dd72a1  vmovaps xmm5, [rsp+0x50]
000072bd77dd72a7  vmovaps xmm6, [rsp+0x60]
000072bd77dd72ad  vmovaps xmm7, [rsp+0x70]
000072bd77dd72b3  vmovaps xmm8, [rsp+0x80]
000072bd77dd72bc  vmovaps xmm10, [rsp+0x90]
000072bd77dd72c5  vmovaps xmm11, [rsp+0xA0]
000072bd77dd72ce  vmovaps xmm12, [rsp+0xB0]
000072bd77dd72d7  vmovaps xmm13, [rsp+0xC0]
000072bd77dd72e0  vmovaps xmm14, [rsp+0xD0]
000072bd77dd72e9  vmovaps xmm15, [rsp+0xE0]
000072bd77dd72f2  add rsp, 0xF0
000072bd77dd72f9  pop r11
000072bd77dd72fb  pop r10
000072bd77dd72fd  pop r9
000072bd77dd72ff  pop r8
000072bd77dd7301  pop rsi
000072bd77dd7302  pop rdi
000072bd77dd7303  pop rdx
000072bd77dd7304  pop rcx
000072bd77dd7305  pop rax
000072bd77dd7306  add rsp, 0x08
000072bd77dd730a  jmp 0x000072BD77DD5AFB
000072bd77dd730f  call 0x000072BD77CD64F0
000072bd77dd7314  jmp 0x000072BD77DD5C15
000072bd77dd7319  call 0x000072BD77CD64F0
000072bd77dd731e  jmp 0x000072BD77DD5C2B
000072bd77dd7323  sub rsp, 0x08
000072bd77dd7327  push rax
000072bd77dd7328  push rcx
000072bd77dd7329  push rdx
000072bd77dd732a  push rdi
000072bd77dd732b  push rsi
000072bd77dd732c  push r8
000072bd77dd732e  push r9
000072bd77dd7330  push r10
000072bd77dd7332  push r11
000072bd77dd7334  sub rsp, 0xF0
000072bd77dd733b  vmovaps [rsp], xmm0
000072bd77dd7340  vmovaps [rsp+0x10], xmm2
000072bd77dd7346  vmovaps [rsp+0x20], xmm3
000072bd77dd734c  vmovaps [rsp+0x30], xmm4
000072bd77dd7352  vmovaps [rsp+0x40], xmm5
000072bd77dd7358  vmovaps [rsp+0x50], xmm6
000072bd77dd735e  vmovaps [rsp+0x60], xmm7
000072bd77dd7364  vmovaps [rsp+0x70], xmm8
000072bd77dd736a  vmovaps [rsp+0x80], xmm9
000072bd77dd7373  vmovaps [rsp+0x90], xmm10
000072bd77dd737c  vmovaps [rsp+0xA0], xmm11
000072bd77dd7385  vmovaps [rsp+0xB0], xmm12
000072bd77dd738e  vmovaps [rsp+0xC0], xmm13
000072bd77dd7397  vmovaps [rsp+0xD0], xmm14
000072bd77dd73a0  vmovaps [rsp+0xE0], xmm15
000072bd77dd73a9  sub rsp, 0x30
000072bd77dd73ad  movaps [rsp], xmm1
000072bd77dd73b1  movaps [rsp+0x10], xmm6
000072bd77dd73b6  movaps [rsp+0x20], xmm15
000072bd77dd73bc  lea rdi, [rsp]
000072bd77dd73c0  mov esi, 0x00
000072bd77dd73c5  mov rax, 0x643206AC3530
000072bd77dd73cf  call rax
000072bd77dd73d1  movaps xmm1, [rsp]
000072bd77dd73d5  add rsp, 0x30
000072bd77dd73d9  vmovaps xmm0, [rsp]
000072bd77dd73de  vmovaps xmm2, [rsp+0x10]
000072bd77dd73e4  vmovaps xmm3, [rsp+0x20]
000072bd77dd73ea  vmovaps xmm4, [rsp+0x30]
000072bd77dd73f0  vmovaps xmm5, [rsp+0x40]
000072bd77dd73f6  vmovaps xmm6, [rsp+0x50]
000072bd77dd73fc  vmovaps xmm7, [rsp+0x60]
000072bd77dd7402  vmovaps xmm8, [rsp+0x70]
000072bd77dd7408  vmovaps xmm9, [rsp+0x80]
000072bd77dd7411  vmovaps xmm10, [rsp+0x90]
000072bd77dd741a  vmovaps xmm11, [rsp+0xA0]
000072bd77dd7423  vmovaps xmm12, [rsp+0xB0]
000072bd77dd742c  vmovaps xmm13, [rsp+0xC0]
000072bd77dd7435  vmovaps xmm14, [rsp+0xD0]
000072bd77dd743e  vmovaps xmm15, [rsp+0xE0]
000072bd77dd7447  add rsp, 0xF0
000072bd77dd744e  pop r11
000072bd77dd7450  pop r10
000072bd77dd7452  pop r9
000072bd77dd7454  pop r8
000072bd77dd7456  pop rsi
000072bd77dd7457  pop rdi
000072bd77dd7458  pop rdx
000072bd77dd7459  pop rcx
000072bd77dd745a  pop rax
000072bd77dd745b  add rsp, 0x08
000072bd77dd745f  jmp 0x000072BD77DD5C68
000072bd77dd7464  call 0x000072BD77CE5820
000072bd77dd7469  jmp 0x000072BD77DD5C75
000072bd77dd746e  sub rsp, 0x08
000072bd77dd7472  push rax
000072bd77dd7473  push rcx
000072bd77dd7474  push rdx
000072bd77dd7475  push rdi
000072bd77dd7476  push rsi
000072bd77dd7477  push r8
000072bd77dd7479  push r9
000072bd77dd747b  push r10
000072bd77dd747d  push r11
000072bd77dd747f  sub rsp, 0xF0
000072bd77dd7486  vmovaps [rsp], xmm0
000072bd77dd748b  vmovaps [rsp+0x10], xmm1
000072bd77dd7491  vmovaps [rsp+0x20], xmm2
000072bd77dd7497  vmovaps [rsp+0x30], xmm3
000072bd77dd749d  vmovaps [rsp+0x40], xmm4
000072bd77dd74a3  vmovaps [rsp+0x50], xmm5
000072bd77dd74a9  vmovaps [rsp+0x60], xmm6
000072bd77dd74af  vmovaps [rsp+0x70], xmm7
000072bd77dd74b5  vmovaps [rsp+0x80], xmm8
000072bd77dd74be  vmovaps [rsp+0x90], xmm9
000072bd77dd74c7  vmovaps [rsp+0xA0], xmm10
000072bd77dd74d0  vmovaps [rsp+0xB0], xmm11
000072bd77dd74d9  vmovaps [rsp+0xC0], xmm12
000072bd77dd74e2  vmovaps [rsp+0xD0], xmm13
000072bd77dd74eb  vmovaps [rsp+0xE0], xmm15
000072bd77dd74f4  sub rsp, 0x30
000072bd77dd74f8  movaps [rsp], xmm14
000072bd77dd74fd  movaps [rsp+0x10], xmm4
000072bd77dd7502  movaps [rsp+0x20], xmm3
000072bd77dd7507  lea rdi, [rsp]
000072bd77dd750b  mov esi, 0x00
000072bd77dd7510  mov rax, 0x643206AC3530
000072bd77dd751a  call rax
000072bd77dd751c  movaps xmm14, [rsp]
000072bd77dd7521  add rsp, 0x30
000072bd77dd7525  vmovaps xmm0, [rsp]
000072bd77dd752a  vmovaps xmm1, [rsp+0x10]
000072bd77dd7530  vmovaps xmm2, [rsp+0x20]
000072bd77dd7536  vmovaps xmm3, [rsp+0x30]
000072bd77dd753c  vmovaps xmm4, [rsp+0x40]
000072bd77dd7542  vmovaps xmm5, [rsp+0x50]
000072bd77dd7548  vmovaps xmm6, [rsp+0x60]
000072bd77dd754e  vmovaps xmm7, [rsp+0x70]
000072bd77dd7554  vmovaps xmm8, [rsp+0x80]
000072bd77dd755d  vmovaps xmm9, [rsp+0x90]
000072bd77dd7566  vmovaps xmm10, [rsp+0xA0]
000072bd77dd756f  vmovaps xmm11, [rsp+0xB0]
000072bd77dd7578  vmovaps xmm12, [rsp+0xC0]
000072bd77dd7581  vmovaps xmm13, [rsp+0xD0]
000072bd77dd758a  vmovaps xmm15, [rsp+0xE0]
000072bd77dd7593  add rsp, 0xF0
000072bd77dd759a  pop r11
000072bd77dd759c  pop r10
000072bd77dd759e  pop r9
000072bd77dd75a0  pop r8
000072bd77dd75a2  pop rsi
000072bd77dd75a3  pop rdi
000072bd77dd75a4  pop rdx
000072bd77dd75a5  pop rcx
000072bd77dd75a6  pop rax
000072bd77dd75a7  add rsp, 0x08
000072bd77dd75ab  jmp 0x000072BD77DD5C8F
000072bd77dd75b0  sub rsp, 0x08
000072bd77dd75b4  push rax
000072bd77dd75b5  push rcx
000072bd77dd75b6  push rdx
000072bd77dd75b7  push rdi
000072bd77dd75b8  push rsi
000072bd77dd75b9  push r8
000072bd77dd75bb  push r9
000072bd77dd75bd  push r10
000072bd77dd75bf  push r11
000072bd77dd75c1  sub rsp, 0xF0
000072bd77dd75c8  vmovaps [rsp], xmm0
000072bd77dd75cd  vmovaps [rsp+0x10], xmm1
000072bd77dd75d3  vmovaps [rsp+0x20], xmm2
000072bd77dd75d9  vmovaps [rsp+0x30], xmm3
000072bd77dd75df  vmovaps [rsp+0x40], xmm4
000072bd77dd75e5  vmovaps [rsp+0x50], xmm5
000072bd77dd75eb  vmovaps [rsp+0x60], xmm7
000072bd77dd75f1  vmovaps [rsp+0x70], xmm8
000072bd77dd75f7  vmovaps [rsp+0x80], xmm9
000072bd77dd7600  vmovaps [rsp+0x90], xmm10
000072bd77dd7609  vmovaps [rsp+0xA0], xmm11
000072bd77dd7612  vmovaps [rsp+0xB0], xmm12
000072bd77dd761b  vmovaps [rsp+0xC0], xmm13
000072bd77dd7624  vmovaps [rsp+0xD0], xmm14
000072bd77dd762d  vmovaps [rsp+0xE0], xmm15
000072bd77dd7636  sub rsp, 0x30
000072bd77dd763a  movaps [rsp], xmm6
000072bd77dd763e  movaps [rsp+0x10], xmm9
000072bd77dd7644  movaps [rsp+0x20], xmm7
000072bd77dd7649  lea rdi, [rsp]
000072bd77dd764d  mov esi, 0x00
000072bd77dd7652  mov rax, 0x643206AC3530
000072bd77dd765c  call rax
000072bd77dd765e  movaps xmm6, [rsp]
000072bd77dd7662  add rsp, 0x30
000072bd77dd7666  vmovaps xmm0, [rsp]
000072bd77dd766b  vmovaps xmm1, [rsp+0x10]
000072bd77dd7671  vmovaps xmm2, [rsp+0x20]
000072bd77dd7677  vmovaps xmm3, [rsp+0x30]
000072bd77dd767d  vmovaps xmm4, [rsp+0x40]
000072bd77dd7683  vmovaps xmm5, [rsp+0x50]
000072bd77dd7689  vmovaps xmm7, [rsp+0x60]
000072bd77dd768f  vmovaps xmm8, [rsp+0x70]
000072bd77dd7695  vmovaps xmm9, [rsp+0x80]
000072bd77dd769e  vmovaps xmm10, [rsp+0x90]
000072bd77dd76a7  vmovaps xmm11, [rsp+0xA0]
000072bd77dd76b0  vmovaps xmm12, [rsp+0xB0]
000072bd77dd76b9  vmovaps xmm13, [rsp+0xC0]
000072bd77dd76c2  vmovaps xmm14, [rsp+0xD0]
000072bd77dd76cb  vmovaps xmm15, [rsp+0xE0]
000072bd77dd76d4  add rsp, 0xF0
000072bd77dd76db  pop r11
000072bd77dd76dd  pop r10
000072bd77dd76df  pop r9
000072bd77dd76e1  pop r8
000072bd77dd76e3  pop rsi
000072bd77dd76e4  pop rdi
000072bd77dd76e5  pop rdx
000072bd77dd76e6  pop rcx
000072bd77dd76e7  pop rax
000072bd77dd76e8  add rsp, 0x08
000072bd77dd76ec  jmp 0x000072BD77DD5CA7
000072bd77dd76f1  sub rsp, 0x08
000072bd77dd76f5  push rax
000072bd77dd76f6  push rcx
000072bd77dd76f7  push rdx
000072bd77dd76f8  push rdi
000072bd77dd76f9  push rsi
000072bd77dd76fa  push r8
000072bd77dd76fc  push r9
000072bd77dd76fe  push r10
000072bd77dd7700  push r11
000072bd77dd7702  sub rsp, 0xF0
000072bd77dd7709  vmovaps [rsp], xmm0
000072bd77dd770e  vmovaps [rsp+0x10], xmm1
000072bd77dd7714  vmovaps [rsp+0x20], xmm2
000072bd77dd771a  vmovaps [rsp+0x30], xmm3
000072bd77dd7720  vmovaps [rsp+0x40], xmm4
000072bd77dd7726  vmovaps [rsp+0x50], xmm5
000072bd77dd772c  vmovaps [rsp+0x60], xmm6
000072bd77dd7732  vmovaps [rsp+0x70], xmm8
000072bd77dd7738  vmovaps [rsp+0x80], xmm9
000072bd77dd7741  vmovaps [rsp+0x90], xmm10
000072bd77dd774a  vmovaps [rsp+0xA0], xmm11
000072bd77dd7753  vmovaps [rsp+0xB0], xmm12
000072bd77dd775c  vmovaps [rsp+0xC0], xmm13
000072bd77dd7765  vmovaps [rsp+0xD0], xmm14
000072bd77dd776e  vmovaps [rsp+0xE0], xmm15
000072bd77dd7777  sub rsp, 0x30
000072bd77dd777b  movaps [rsp], xmm7
000072bd77dd777f  movaps [rsp+0x10], xmm4
000072bd77dd7784  movaps [rsp+0x20], xmm9
000072bd77dd778a  lea rdi, [rsp]
000072bd77dd778e  mov esi, 0x00
000072bd77dd7793  mov rax, 0x643206AC3530
000072bd77dd779d  call rax
000072bd77dd779f  movaps xmm7, [rsp]
000072bd77dd77a3  add rsp, 0x30
000072bd77dd77a7  vmovaps xmm0, [rsp]
000072bd77dd77ac  vmovaps xmm1, [rsp+0x10]
000072bd77dd77b2  vmovaps xmm2, [rsp+0x20]
000072bd77dd77b8  vmovaps xmm3, [rsp+0x30]
000072bd77dd77be  vmovaps xmm4, [rsp+0x40]
000072bd77dd77c4  vmovaps xmm5, [rsp+0x50]
000072bd77dd77ca  vmovaps xmm6, [rsp+0x60]
000072bd77dd77d0  vmovaps xmm8, [rsp+0x70]
000072bd77dd77d6  vmovaps xmm9, [rsp+0x80]
000072bd77dd77df  vmovaps xmm10, [rsp+0x90]
000072bd77dd77e8  vmovaps xmm11, [rsp+0xA0]
000072bd77dd77f1  vmovaps xmm12, [rsp+0xB0]
000072bd77dd77fa  vmovaps xmm13, [rsp+0xC0]
000072bd77dd7803  vmovaps xmm14, [rsp+0xD0]
000072bd77dd780c  vmovaps xmm15, [rsp+0xE0]
000072bd77dd7815  add rsp, 0xF0
000072bd77dd781c  pop r11
000072bd77dd781e  pop r10
000072bd77dd7820  pop r9
000072bd77dd7822  pop r8
000072bd77dd7824  pop rsi
000072bd77dd7825  pop rdi
000072bd77dd7826  pop rdx
000072bd77dd7827  pop rcx
000072bd77dd7828  pop rax
000072bd77dd7829  add rsp, 0x08
000072bd77dd782d  jmp 0x000072BD77DD5CD4
000072bd77dd7832  sub rsp, 0x08
000072bd77dd7836  push rax
000072bd77dd7837  push rcx
000072bd77dd7838  push rdx
000072bd77dd7839  push rdi
000072bd77dd783a  push rsi
000072bd77dd783b  push r8
000072bd77dd783d  push r9
000072bd77dd783f  push r10
000072bd77dd7841  push r11
000072bd77dd7843  sub rsp, 0xF0
000072bd77dd784a  vmovaps [rsp], xmm0
000072bd77dd784f  vmovaps [rsp+0x10], xmm1
000072bd77dd7855  vmovaps [rsp+0x20], xmm2
000072bd77dd785b  vmovaps [rsp+0x30], xmm3
000072bd77dd7861  vmovaps [rsp+0x40], xmm5
000072bd77dd7867  vmovaps [rsp+0x50], xmm6
000072bd77dd786d  vmovaps [rsp+0x60], xmm7
000072bd77dd7873  vmovaps [rsp+0x70], xmm8
000072bd77dd7879  vmovaps [rsp+0x80], xmm9
000072bd77dd7882  vmovaps [rsp+0x90], xmm10
000072bd77dd788b  vmovaps [rsp+0xA0], xmm11
000072bd77dd7894  vmovaps [rsp+0xB0], xmm12
000072bd77dd789d  vmovaps [rsp+0xC0], xmm13
000072bd77dd78a6  vmovaps [rsp+0xD0], xmm14
000072bd77dd78af  vmovaps [rsp+0xE0], xmm15
000072bd77dd78b8  sub rsp, 0x30
000072bd77dd78bc  movaps [rsp], xmm4
000072bd77dd78c0  movaps [rsp+0x10], xmm15
000072bd77dd78c6  movaps [rsp+0x20], xmm9
000072bd77dd78cc  lea rdi, [rsp]
000072bd77dd78d0  mov esi, 0x00
000072bd77dd78d5  mov rax, 0x643206AC3530
000072bd77dd78df  call rax
000072bd77dd78e1  movaps xmm4, [rsp]
000072bd77dd78e5  add rsp, 0x30
000072bd77dd78e9  vmovaps xmm0, [rsp]
000072bd77dd78ee  vmovaps xmm1, [rsp+0x10]
000072bd77dd78f4  vmovaps xmm2, [rsp+0x20]
000072bd77dd78fa  vmovaps xmm3, [rsp+0x30]
000072bd77dd7900  vmovaps xmm5, [rsp+0x40]
000072bd77dd7906  vmovaps xmm6, [rsp+0x50]
000072bd77dd790c  vmovaps xmm7, [rsp+0x60]
000072bd77dd7912  vmovaps xmm8, [rsp+0x70]
000072bd77dd7918  vmovaps xmm9, [rsp+0x80]
000072bd77dd7921  vmovaps xmm10, [rsp+0x90]
000072bd77dd792a  vmovaps xmm11, [rsp+0xA0]
000072bd77dd7933  vmovaps xmm12, [rsp+0xB0]
000072bd77dd793c  vmovaps xmm13, [rsp+0xC0]
000072bd77dd7945  vmovaps xmm14, [rsp+0xD0]
000072bd77dd794e  vmovaps xmm15, [rsp+0xE0]
000072bd77dd7957  add rsp, 0xF0
000072bd77dd795e  pop r11
000072bd77dd7960  pop r10
000072bd77dd7962  pop r9
000072bd77dd7964  pop r8
000072bd77dd7966  pop rsi
000072bd77dd7967  pop rdi
000072bd77dd7968  pop rdx
000072bd77dd7969  pop rcx
000072bd77dd796a  pop rax
000072bd77dd796b  add rsp, 0x08
000072bd77dd796f  jmp 0x000072BD77DD5CF9
000072bd77dd7974  call 0x000072BD77CE5820
000072bd77dd7979  jmp 0x000072BD77DD5D06
000072bd77dd797e  sub rsp, 0x08
000072bd77dd7982  push rax
000072bd77dd7983  push rcx
000072bd77dd7984  push rdx
000072bd77dd7985  push rdi
000072bd77dd7986  push rsi
000072bd77dd7987  push r8
000072bd77dd7989  push r9
000072bd77dd798b  push r10
000072bd77dd798d  push r11
000072bd77dd798f  sub rsp, 0xF0
000072bd77dd7996  vmovaps [rsp], xmm0
000072bd77dd799b  vmovaps [rsp+0x10], xmm1
000072bd77dd79a1  vmovaps [rsp+0x20], xmm2
000072bd77dd79a7  vmovaps [rsp+0x30], xmm4
000072bd77dd79ad  vmovaps [rsp+0x40], xmm5
000072bd77dd79b3  vmovaps [rsp+0x50], xmm6
000072bd77dd79b9  vmovaps [rsp+0x60], xmm7
000072bd77dd79bf  vmovaps [rsp+0x70], xmm8
000072bd77dd79c5  vmovaps [rsp+0x80], xmm9
000072bd77dd79ce  vmovaps [rsp+0x90], xmm10
000072bd77dd79d7  vmovaps [rsp+0xA0], xmm11
000072bd77dd79e0  vmovaps [rsp+0xB0], xmm12
000072bd77dd79e9  vmovaps [rsp+0xC0], xmm13
000072bd77dd79f2  vmovaps [rsp+0xD0], xmm14
000072bd77dd79fb  vmovaps [rsp+0xE0], xmm15
000072bd77dd7a04  sub rsp, 0x30
000072bd77dd7a08  movaps [rsp], xmm3
000072bd77dd7a0c  movaps [rsp+0x10], xmm1
000072bd77dd7a11  movaps [rsp+0x20], xmm9
000072bd77dd7a17  lea rdi, [rsp]
000072bd77dd7a1b  mov esi, 0x00
000072bd77dd7a20  mov rax, 0x643206AC3530
000072bd77dd7a2a  call rax
000072bd77dd7a2c  movaps xmm3, [rsp]
000072bd77dd7a30  add rsp, 0x30
000072bd77dd7a34  vmovaps xmm0, [rsp]
000072bd77dd7a39  vmovaps xmm1, [rsp+0x10]
000072bd77dd7a3f  vmovaps xmm2, [rsp+0x20]
000072bd77dd7a45  vmovaps xmm4, [rsp+0x30]
000072bd77dd7a4b  vmovaps xmm5, [rsp+0x40]
000072bd77dd7a51  vmovaps xmm6, [rsp+0x50]
000072bd77dd7a57  vmovaps xmm7, [rsp+0x60]
000072bd77dd7a5d  vmovaps xmm8, [rsp+0x70]
000072bd77dd7a63  vmovaps xmm9, [rsp+0x80]
000072bd77dd7a6c  vmovaps xmm10, [rsp+0x90]
000072bd77dd7a75  vmovaps xmm11, [rsp+0xA0]
000072bd77dd7a7e  vmovaps xmm12, [rsp+0xB0]
000072bd77dd7a87  vmovaps xmm13, [rsp+0xC0]
000072bd77dd7a90  vmovaps xmm14, [rsp+0xD0]
000072bd77dd7a99  vmovaps xmm15, [rsp+0xE0]
000072bd77dd7aa2  add rsp, 0xF0
000072bd77dd7aa9  pop r11
000072bd77dd7aab  pop r10
000072bd77dd7aad  pop r9
000072bd77dd7aaf  pop r8
000072bd77dd7ab1  pop rsi
000072bd77dd7ab2  pop rdi
000072bd77dd7ab3  pop rdx
000072bd77dd7ab4  pop rcx
000072bd77dd7ab5  pop rax
000072bd77dd7ab6  add rsp, 0x08
000072bd77dd7aba  jmp 0x000072BD77DD5D43
000072bd77dd7abf  sub rsp, 0x08
000072bd77dd7ac3  push rax
000072bd77dd7ac4  push rcx
000072bd77dd7ac5  push rdx
000072bd77dd7ac6  push rdi
000072bd77dd7ac7  push rsi
000072bd77dd7ac8  push r8
000072bd77dd7aca  push r9
000072bd77dd7acc  push r10
000072bd77dd7ace  push r11
000072bd77dd7ad0  sub rsp, 0xF0
000072bd77dd7ad7  vmovaps [rsp], xmm0
000072bd77dd7adc  vmovaps [rsp+0x10], xmm2
000072bd77dd7ae2  vmovaps [rsp+0x20], xmm3
000072bd77dd7ae8  vmovaps [rsp+0x30], xmm4
000072bd77dd7aee  vmovaps [rsp+0x40], xmm5
000072bd77dd7af4  vmovaps [rsp+0x50], xmm6
000072bd77dd7afa  vmovaps [rsp+0x60], xmm7
000072bd77dd7b00  vmovaps [rsp+0x70], xmm8
000072bd77dd7b06  vmovaps [rsp+0x80], xmm9
000072bd77dd7b0f  vmovaps [rsp+0x90], xmm10
000072bd77dd7b18  vmovaps [rsp+0xA0], xmm11
000072bd77dd7b21  vmovaps [rsp+0xB0], xmm12
000072bd77dd7b2a  vmovaps [rsp+0xC0], xmm13
000072bd77dd7b33  vmovaps [rsp+0xD0], xmm14
000072bd77dd7b3c  vmovaps [rsp+0xE0], xmm15
000072bd77dd7b45  sub rsp, 0x30
000072bd77dd7b49  movaps [rsp], xmm1
000072bd77dd7b4d  movaps [rsp+0x10], xmm15
000072bd77dd7b53  movaps [rsp+0x20], xmm9
000072bd77dd7b59  lea rdi, [rsp]
000072bd77dd7b5d  mov esi, 0x00
000072bd77dd7b62  mov rax, 0x643206AC3530
000072bd77dd7b6c  call rax
000072bd77dd7b6e  movaps xmm1, [rsp]
000072bd77dd7b72  add rsp, 0x30
000072bd77dd7b76  vmovaps xmm0, [rsp]
000072bd77dd7b7b  vmovaps xmm2, [rsp+0x10]
000072bd77dd7b81  vmovaps xmm3, [rsp+0x20]
000072bd77dd7b87  vmovaps xmm4, [rsp+0x30]
000072bd77dd7b8d  vmovaps xmm5, [rsp+0x40]
000072bd77dd7b93  vmovaps xmm6, [rsp+0x50]
000072bd77dd7b99  vmovaps xmm7, [rsp+0x60]
000072bd77dd7b9f  vmovaps xmm8, [rsp+0x70]
000072bd77dd7ba5  vmovaps xmm9, [rsp+0x80]
000072bd77dd7bae  vmovaps xmm10, [rsp+0x90]
000072bd77dd7bb7  vmovaps xmm11, [rsp+0xA0]
000072bd77dd7bc0  vmovaps xmm12, [rsp+0xB0]
000072bd77dd7bc9  vmovaps xmm13, [rsp+0xC0]
000072bd77dd7bd2  vmovaps xmm14, [rsp+0xD0]
000072bd77dd7bdb  vmovaps xmm15, [rsp+0xE0]
000072bd77dd7be4  add rsp, 0xF0
000072bd77dd7beb  pop r11
000072bd77dd7bed  pop r10
000072bd77dd7bef  pop r9
000072bd77dd7bf1  pop r8
000072bd77dd7bf3  pop rsi
000072bd77dd7bf4  pop rdi
000072bd77dd7bf5  pop rdx
000072bd77dd7bf6  pop rcx
000072bd77dd7bf7  pop rax
000072bd77dd7bf8  add rsp, 0x08
000072bd77dd7bfc  jmp 0x000072BD77DD5DCB
000072bd77dd7c01  call 0x000072BD77CE5820
000072bd77dd7c06  jmp 0x000072BD77DD5DD8
000072bd77dd7c0b  sub rsp, 0x08
000072bd77dd7c0f  push rax
000072bd77dd7c10  push rcx
000072bd77dd7c11  push rdx
000072bd77dd7c12  push rdi
000072bd77dd7c13  push rsi
000072bd77dd7c14  push r8
000072bd77dd7c16  push r9
000072bd77dd7c18  push r10
000072bd77dd7c1a  push r11
000072bd77dd7c1c  sub rsp, 0xF0
000072bd77dd7c23  vmovaps [rsp], xmm0
000072bd77dd7c28  vmovaps [rsp+0x10], xmm2
000072bd77dd7c2e  vmovaps [rsp+0x20], xmm3
000072bd77dd7c34  vmovaps [rsp+0x30], xmm4
000072bd77dd7c3a  vmovaps [rsp+0x40], xmm5
000072bd77dd7c40  vmovaps [rsp+0x50], xmm6
000072bd77dd7c46  vmovaps [rsp+0x60], xmm7
000072bd77dd7c4c  vmovaps [rsp+0x70], xmm8
000072bd77dd7c52  vmovaps [rsp+0x80], xmm9
000072bd77dd7c5b  vmovaps [rsp+0x90], xmm10
000072bd77dd7c64  vmovaps [rsp+0xA0], xmm11
000072bd77dd7c6d  vmovaps [rsp+0xB0], xmm12
000072bd77dd7c76  vmovaps [rsp+0xC0], xmm13
000072bd77dd7c7f  vmovaps [rsp+0xD0], xmm14
000072bd77dd7c88  vmovaps [rsp+0xE0], xmm15
000072bd77dd7c91  sub rsp, 0x30
000072bd77dd7c95  movaps [rsp], xmm1
000072bd77dd7c99  movaps [rsp+0x10], xmm5
000072bd77dd7c9e  movaps [rsp+0x20], xmm7
000072bd77dd7ca3  lea rdi, [rsp]
000072bd77dd7ca7  mov esi, 0x00
000072bd77dd7cac  mov rax, 0x643206AC3530
000072bd77dd7cb6  call rax
000072bd77dd7cb8  movaps xmm1, [rsp]
000072bd77dd7cbc  add rsp, 0x30
000072bd77dd7cc0  vmovaps xmm0, [rsp]
000072bd77dd7cc5  vmovaps xmm2, [rsp+0x10]
000072bd77dd7ccb  vmovaps xmm3, [rsp+0x20]
000072bd77dd7cd1  vmovaps xmm4, [rsp+0x30]
000072bd77dd7cd7  vmovaps xmm5, [rsp+0x40]
000072bd77dd7cdd  vmovaps xmm6, [rsp+0x50]
000072bd77dd7ce3  vmovaps xmm7, [rsp+0x60]
000072bd77dd7ce9  vmovaps xmm8, [rsp+0x70]
000072bd77dd7cef  vmovaps xmm9, [rsp+0x80]
000072bd77dd7cf8  vmovaps xmm10, [rsp+0x90]
000072bd77dd7d01  vmovaps xmm11, [rsp+0xA0]
000072bd77dd7d0a  vmovaps xmm12, [rsp+0xB0]
000072bd77dd7d13  vmovaps xmm13, [rsp+0xC0]
000072bd77dd7d1c  vmovaps xmm14, [rsp+0xD0]
000072bd77dd7d25  vmovaps xmm15, [rsp+0xE0]
000072bd77dd7d2e  add rsp, 0xF0
000072bd77dd7d35  pop r11
000072bd77dd7d37  pop r10
000072bd77dd7d39  pop r9
000072bd77dd7d3b  pop r8
000072bd77dd7d3d  pop rsi
000072bd77dd7d3e  pop rdi
000072bd77dd7d3f  pop rdx
000072bd77dd7d40  pop rcx
000072bd77dd7d41  pop rax
000072bd77dd7d42  add rsp, 0x08
000072bd77dd7d46  jmp 0x000072BD77DD5E7D
000072bd77dd7d4b  sub rsp, 0x08
000072bd77dd7d4f  push rax
000072bd77dd7d50  push rcx
000072bd77dd7d51  push rdx
000072bd77dd7d52  push rdi
000072bd77dd7d53  push rsi
000072bd77dd7d54  push r8
000072bd77dd7d56  push r9
000072bd77dd7d58  push r10
000072bd77dd7d5a  push r11
000072bd77dd7d5c  sub rsp, 0xF0
000072bd77dd7d63  vmovaps [rsp], xmm0
000072bd77dd7d68  vmovaps [rsp+0x10], xmm1
000072bd77dd7d6e  vmovaps [rsp+0x20], xmm2
000072bd77dd7d74  vmovaps [rsp+0x30], xmm3
000072bd77dd7d7a  vmovaps [rsp+0x40], xmm4
000072bd77dd7d80  vmovaps [rsp+0x50], xmm5
000072bd77dd7d86  vmovaps [rsp+0x60], xmm6
000072bd77dd7d8c  vmovaps [rsp+0x70], xmm8
000072bd77dd7d92  vmovaps [rsp+0x80], xmm9
000072bd77dd7d9b  vmovaps [rsp+0x90], xmm10
000072bd77dd7da4  vmovaps [rsp+0xA0], xmm11
000072bd77dd7dad  vmovaps [rsp+0xB0], xmm12
000072bd77dd7db6  vmovaps [rsp+0xC0], xmm13
000072bd77dd7dbf  vmovaps [rsp+0xD0], xmm14
000072bd77dd7dc8  vmovaps [rsp+0xE0], xmm15
000072bd77dd7dd1  sub rsp, 0x30
000072bd77dd7dd5  movaps [rsp], xmm7
000072bd77dd7dd9  movaps [rsp+0x10], xmm5
000072bd77dd7dde  movaps [rsp+0x20], xmm15
000072bd77dd7de4  lea rdi, [rsp]
000072bd77dd7de8  mov esi, 0x00
000072bd77dd7ded  mov rax, 0x643206AC3530
000072bd77dd7df7  call rax
000072bd77dd7df9  movaps xmm7, [rsp]
000072bd77dd7dfd  add rsp, 0x30
000072bd77dd7e01  vmovaps xmm0, [rsp]
000072bd77dd7e06  vmovaps xmm1, [rsp+0x10]
000072bd77dd7e0c  vmovaps xmm2, [rsp+0x20]
000072bd77dd7e12  vmovaps xmm3, [rsp+0x30]
000072bd77dd7e18  vmovaps xmm4, [rsp+0x40]
000072bd77dd7e1e  vmovaps xmm5, [rsp+0x50]
000072bd77dd7e24  vmovaps xmm6, [rsp+0x60]
000072bd77dd7e2a  vmovaps xmm8, [rsp+0x70]
000072bd77dd7e30  vmovaps xmm9, [rsp+0x80]
000072bd77dd7e39  vmovaps xmm10, [rsp+0x90]
000072bd77dd7e42  vmovaps xmm11, [rsp+0xA0]
000072bd77dd7e4b  vmovaps xmm12, [rsp+0xB0]
000072bd77dd7e54  vmovaps xmm13, [rsp+0xC0]
000072bd77dd7e5d  vmovaps xmm14, [rsp+0xD0]
000072bd77dd7e66  vmovaps xmm15, [rsp+0xE0]
000072bd77dd7e6f  add rsp, 0xF0
000072bd77dd7e76  pop r11
000072bd77dd7e78  pop r10
000072bd77dd7e7a  pop r9
000072bd77dd7e7c  pop r8
000072bd77dd7e7e  pop rsi
000072bd77dd7e7f  pop rdi
000072bd77dd7e80  pop rdx
000072bd77dd7e81  pop rcx
000072bd77dd7e82  pop rax
000072bd77dd7e83  add rsp, 0x08
000072bd77dd7e87  jmp 0x000072BD77DD5EB3
000072bd77dd7e8c  call 0x000072BD77CD64F0
000072bd77dd7e91  jmp 0x000072BD77DD5EC0
000072bd77dd7e96  sub rsp, 0x08
000072bd77dd7e9a  push rax
000072bd77dd7e9b  push rcx
000072bd77dd7e9c  push rdx
000072bd77dd7e9d  push rdi
000072bd77dd7e9e  push rsi
000072bd77dd7e9f  push r8
000072bd77dd7ea1  push r9
000072bd77dd7ea3  push r10
000072bd77dd7ea5  push r11
000072bd77dd7ea7  sub rsp, 0xF0
000072bd77dd7eae  vmovaps [rsp], xmm0
000072bd77dd7eb3  vmovaps [rsp+0x10], xmm1
000072bd77dd7eb9  vmovaps [rsp+0x20], xmm2
000072bd77dd7ebf  vmovaps [rsp+0x30], xmm3
000072bd77dd7ec5  vmovaps [rsp+0x40], xmm4
000072bd77dd7ecb  vmovaps [rsp+0x50], xmm5
000072bd77dd7ed1  vmovaps [rsp+0x60], xmm6
000072bd77dd7ed7  vmovaps [rsp+0x70], xmm7
000072bd77dd7edd  vmovaps [rsp+0x80], xmm8
000072bd77dd7ee6  vmovaps [rsp+0x90], xmm9
000072bd77dd7eef  vmovaps [rsp+0xA0], xmm10
000072bd77dd7ef8  vmovaps [rsp+0xB0], xmm11
000072bd77dd7f01  vmovaps [rsp+0xC0], xmm12
000072bd77dd7f0a  vmovaps [rsp+0xD0], xmm13
000072bd77dd7f13  vmovaps [rsp+0xE0], xmm14
000072bd77dd7f1c  sub rsp, 0x30
000072bd77dd7f20  movaps [rsp], xmm15
000072bd77dd7f25  movaps [rsp+0x10], xmm5
000072bd77dd7f2a  movaps [rsp+0x20], xmm3
000072bd77dd7f2f  lea rdi, [rsp]
000072bd77dd7f33  mov esi, 0x00
000072bd77dd7f38  mov rax, 0x643206AC3530
000072bd77dd7f42  call rax
000072bd77dd7f44  movaps xmm15, [rsp]
000072bd77dd7f49  add rsp, 0x30
000072bd77dd7f4d  vmovaps xmm0, [rsp]
000072bd77dd7f52  vmovaps xmm1, [rsp+0x10]
000072bd77dd7f58  vmovaps xmm2, [rsp+0x20]
000072bd77dd7f5e  vmovaps xmm3, [rsp+0x30]
000072bd77dd7f64  vmovaps xmm4, [rsp+0x40]
000072bd77dd7f6a  vmovaps xmm5, [rsp+0x50]
000072bd77dd7f70  vmovaps xmm6, [rsp+0x60]
000072bd77dd7f76  vmovaps xmm7, [rsp+0x70]
000072bd77dd7f7c  vmovaps xmm8, [rsp+0x80]
000072bd77dd7f85  vmovaps xmm9, [rsp+0x90]
000072bd77dd7f8e  vmovaps xmm10, [rsp+0xA0]
000072bd77dd7f97  vmovaps xmm11, [rsp+0xB0]
000072bd77dd7fa0  vmovaps xmm12, [rsp+0xC0]
000072bd77dd7fa9  vmovaps xmm13, [rsp+0xD0]
000072bd77dd7fb2  vmovaps xmm14, [rsp+0xE0]
000072bd77dd7fbb  add rsp, 0xF0
000072bd77dd7fc2  pop r11
000072bd77dd7fc4  pop r10
000072bd77dd7fc6  pop r9
000072bd77dd7fc8  pop r8
000072bd77dd7fca  pop rsi
000072bd77dd7fcb  pop rdi
000072bd77dd7fcc  pop rdx
000072bd77dd7fcd  pop rcx
000072bd77dd7fce  pop rax
000072bd77dd7fcf  add rsp, 0x08
000072bd77dd7fd3  jmp 0x000072BD77DD5EE6
000072bd77dd7fd8  sub rsp, 0x08
000072bd77dd7fdc  push rax
000072bd77dd7fdd  push rcx
000072bd77dd7fde  push rdx
000072bd77dd7fdf  push rdi
000072bd77dd7fe0  push rsi
000072bd77dd7fe1  push r8
000072bd77dd7fe3  push r9
000072bd77dd7fe5  push r10
000072bd77dd7fe7  push r11
000072bd77dd7fe9  sub rsp, 0xF0
000072bd77dd7ff0  vmovaps [rsp], xmm0
000072bd77dd7ff5  vmovaps [rsp+0x10], xmm2
000072bd77dd7ffb  vmovaps [rsp+0x20], xmm3
000072bd77dd8001  vmovaps [rsp+0x30], xmm4
000072bd77dd8007  vmovaps [rsp+0x40], xmm5
000072bd77dd800d  vmovaps [rsp+0x50], xmm6
000072bd77dd8013  vmovaps [rsp+0x60], xmm7
000072bd77dd8019  vmovaps [rsp+0x70], xmm8
000072bd77dd801f  vmovaps [rsp+0x80], xmm9
000072bd77dd8028  vmovaps [rsp+0x90], xmm10
000072bd77dd8031  vmovaps [rsp+0xA0], xmm11
000072bd77dd803a  vmovaps [rsp+0xB0], xmm12
000072bd77dd8043  vmovaps [rsp+0xC0], xmm13
000072bd77dd804c  vmovaps [rsp+0xD0], xmm14
000072bd77dd8055  vmovaps [rsp+0xE0], xmm15
000072bd77dd805e  sub rsp, 0x30
000072bd77dd8062  movaps [rsp], xmm1
000072bd77dd8066  movaps [rsp+0x10], xmm5
000072bd77dd806b  movaps [rsp+0x20], xmm4
000072bd77dd8070  lea rdi, [rsp]
000072bd77dd8074  mov esi, 0x00
000072bd77dd8079  mov rax, 0x643206AC3530
000072bd77dd8083  call rax
000072bd77dd8085  movaps xmm1, [rsp]
000072bd77dd8089  add rsp, 0x30
000072bd77dd808d  vmovaps xmm0, [rsp]
000072bd77dd8092  vmovaps xmm2, [rsp+0x10]
000072bd77dd8098  vmovaps xmm3, [rsp+0x20]
000072bd77dd809e  vmovaps xmm4, [rsp+0x30]
000072bd77dd80a4  vmovaps xmm5, [rsp+0x40]
000072bd77dd80aa  vmovaps xmm6, [rsp+0x50]
000072bd77dd80b0  vmovaps xmm7, [rsp+0x60]
000072bd77dd80b6  vmovaps xmm8, [rsp+0x70]
000072bd77dd80bc  vmovaps xmm9, [rsp+0x80]
000072bd77dd80c5  vmovaps xmm10, [rsp+0x90]
000072bd77dd80ce  vmovaps xmm11, [rsp+0xA0]
000072bd77dd80d7  vmovaps xmm12, [rsp+0xB0]
000072bd77dd80e0  vmovaps xmm13, [rsp+0xC0]
000072bd77dd80e9  vmovaps xmm14, [rsp+0xD0]
000072bd77dd80f2  vmovaps xmm15, [rsp+0xE0]
000072bd77dd80fb  add rsp, 0xF0
000072bd77dd8102  pop r11
000072bd77dd8104  pop r10
000072bd77dd8106  pop r9
000072bd77dd8108  pop r8
000072bd77dd810a  pop rsi
000072bd77dd810b  pop rdi
000072bd77dd810c  pop rdx
000072bd77dd810d  pop rcx
000072bd77dd810e  pop rax
000072bd77dd810f  add rsp, 0x08
000072bd77dd8113  jmp 0x000072BD77DD5F06
000072bd77dd8118  sub rsp, 0x08
000072bd77dd811c  push rax
000072bd77dd811d  push rcx
000072bd77dd811e  push rdx
000072bd77dd811f  push rdi
000072bd77dd8120  push rsi
000072bd77dd8121  push r8
000072bd77dd8123  push r9
000072bd77dd8125  push r10
000072bd77dd8127  push r11
000072bd77dd8129  sub rsp, 0xF0
000072bd77dd8130  vmovaps [rsp], xmm0
000072bd77dd8135  vmovaps [rsp+0x10], xmm1
000072bd77dd813b  vmovaps [rsp+0x20], xmm2
000072bd77dd8141  vmovaps [rsp+0x30], xmm3
000072bd77dd8147  vmovaps [rsp+0x40], xmm5
000072bd77dd814d  vmovaps [rsp+0x50], xmm6
000072bd77dd8153  vmovaps [rsp+0x60], xmm7
000072bd77dd8159  vmovaps [rsp+0x70], xmm8
000072bd77dd815f  vmovaps [rsp+0x80], xmm9
000072bd77dd8168  vmovaps [rsp+0x90], xmm10
000072bd77dd8171  vmovaps [rsp+0xA0], xmm11
000072bd77dd817a  vmovaps [rsp+0xB0], xmm12
000072bd77dd8183  vmovaps [rsp+0xC0], xmm13
000072bd77dd818c  vmovaps [rsp+0xD0], xmm14
000072bd77dd8195  vmovaps [rsp+0xE0], xmm15
000072bd77dd819e  sub rsp, 0x30
000072bd77dd81a2  movaps [rsp], xmm4
000072bd77dd81a6  movaps [rsp+0x10], xmm3
000072bd77dd81ab  movaps [rsp+0x20], xmm5
000072bd77dd81b0  lea rdi, [rsp]
000072bd77dd81b4  mov esi, 0x00
000072bd77dd81b9  mov rax, 0x643206AC3530
000072bd77dd81c3  call rax
000072bd77dd81c5  movaps xmm4, [rsp]
000072bd77dd81c9  add rsp, 0x30
000072bd77dd81cd  vmovaps xmm0, [rsp]
000072bd77dd81d2  vmovaps xmm1, [rsp+0x10]
000072bd77dd81d8  vmovaps xmm2, [rsp+0x20]
000072bd77dd81de  vmovaps xmm3, [rsp+0x30]
000072bd77dd81e4  vmovaps xmm5, [rsp+0x40]
000072bd77dd81ea  vmovaps xmm6, [rsp+0x50]
000072bd77dd81f0  vmovaps xmm7, [rsp+0x60]
000072bd77dd81f6  vmovaps xmm8, [rsp+0x70]
000072bd77dd81fc  vmovaps xmm9, [rsp+0x80]
000072bd77dd8205  vmovaps xmm10, [rsp+0x90]
000072bd77dd820e  vmovaps xmm11, [rsp+0xA0]
000072bd77dd8217  vmovaps xmm12, [rsp+0xB0]
000072bd77dd8220  vmovaps xmm13, [rsp+0xC0]
000072bd77dd8229  vmovaps xmm14, [rsp+0xD0]
000072bd77dd8232  vmovaps xmm15, [rsp+0xE0]
000072bd77dd823b  add rsp, 0xF0
000072bd77dd8242  pop r11
000072bd77dd8244  pop r10
000072bd77dd8246  pop r9
000072bd77dd8248  pop r8
000072bd77dd824a  pop rsi
000072bd77dd824b  pop rdi
000072bd77dd824c  pop rdx
000072bd77dd824d  pop rcx
000072bd77dd824e  pop rax
000072bd77dd824f  add rsp, 0x08
000072bd77dd8253  jmp 0x000072BD77DD5F54
000072bd77dd8258  call 0x000072BD77CD64F0
000072bd77dd825d  jmp 0x000072BD77DD5F61
000072bd77dd8262  sub rsp, 0x08
000072bd77dd8266  push rax
000072bd77dd8267  push rcx
000072bd77dd8268  push rdx
000072bd77dd8269  push rdi
000072bd77dd826a  push rsi
000072bd77dd826b  push r8
000072bd77dd826d  push r9
000072bd77dd826f  push r10
000072bd77dd8271  push r11
000072bd77dd8273  sub rsp, 0xF0
000072bd77dd827a  vmovaps [rsp], xmm0
000072bd77dd827f  vmovaps [rsp+0x10], xmm1
000072bd77dd8285  vmovaps [rsp+0x20], xmm2
000072bd77dd828b  vmovaps [rsp+0x30], xmm3
000072bd77dd8291  vmovaps [rsp+0x40], xmm4
000072bd77dd8297  vmovaps [rsp+0x50], xmm6
000072bd77dd829d  vmovaps [rsp+0x60], xmm7
000072bd77dd82a3  vmovaps [rsp+0x70], xmm8
000072bd77dd82a9  vmovaps [rsp+0x80], xmm9
000072bd77dd82b2  vmovaps [rsp+0x90], xmm10
000072bd77dd82bb  vmovaps [rsp+0xA0], xmm11
000072bd77dd82c4  vmovaps [rsp+0xB0], xmm12
000072bd77dd82cd  vmovaps [rsp+0xC0], xmm13
000072bd77dd82d6  vmovaps [rsp+0xD0], xmm14
000072bd77dd82df  vmovaps [rsp+0xE0], xmm15
000072bd77dd82e8  sub rsp, 0x30
000072bd77dd82ec  movaps [rsp], xmm5
000072bd77dd82f0  movaps [rsp+0x10], xmm6
000072bd77dd82f5  movaps [rsp+0x20], xmm3
000072bd77dd82fa  lea rdi, [rsp]
000072bd77dd82fe  mov esi, 0x00
000072bd77dd8303  mov rax, 0x643206AC3530
000072bd77dd830d  call rax
000072bd77dd830f  movaps xmm5, [rsp]
000072bd77dd8313  add rsp, 0x30
000072bd77dd8317  vmovaps xmm0, [rsp]
000072bd77dd831c  vmovaps xmm1, [rsp+0x10]
000072bd77dd8322  vmovaps xmm2, [rsp+0x20]
000072bd77dd8328  vmovaps xmm3, [rsp+0x30]
000072bd77dd832e  vmovaps xmm4, [rsp+0x40]
000072bd77dd8334  vmovaps xmm6, [rsp+0x50]
000072bd77dd833a  vmovaps xmm7, [rsp+0x60]
000072bd77dd8340  vmovaps xmm8, [rsp+0x70]
000072bd77dd8346  vmovaps xmm9, [rsp+0x80]
000072bd77dd834f  vmovaps xmm10, [rsp+0x90]
000072bd77dd8358  vmovaps xmm11, [rsp+0xA0]
000072bd77dd8361  vmovaps xmm12, [rsp+0xB0]
000072bd77dd836a  vmovaps xmm13, [rsp+0xC0]
000072bd77dd8373  vmovaps xmm14, [rsp+0xD0]
000072bd77dd837c  vmovaps xmm15, [rsp+0xE0]
000072bd77dd8385  add rsp, 0xF0
000072bd77dd838c  pop r11
000072bd77dd838e  pop r10
000072bd77dd8390  pop r9
000072bd77dd8392  pop r8
000072bd77dd8394  pop rsi
000072bd77dd8395  pop rdi
000072bd77dd8396  pop rdx
000072bd77dd8397  pop rcx
000072bd77dd8398  pop rax
000072bd77dd8399  add rsp, 0x08
000072bd77dd839d  jmp 0x000072BD77DD5F87
000072bd77dd83a2  sub rsp, 0x08
000072bd77dd83a6  push rax
000072bd77dd83a7  push rcx
000072bd77dd83a8  push rdx
000072bd77dd83a9  push rdi
000072bd77dd83aa  push rsi
000072bd77dd83ab  push r8
000072bd77dd83ad  push r9
000072bd77dd83af  push r10
000072bd77dd83b1  push r11
000072bd77dd83b3  sub rsp, 0xF0
000072bd77dd83ba  vmovaps [rsp], xmm0
000072bd77dd83bf  vmovaps [rsp+0x10], xmm1
000072bd77dd83c5  vmovaps [rsp+0x20], xmm2
000072bd77dd83cb  vmovaps [rsp+0x30], xmm3
000072bd77dd83d1  vmovaps [rsp+0x40], xmm4
000072bd77dd83d7  vmovaps [rsp+0x50], xmm5
000072bd77dd83dd  vmovaps [rsp+0x60], xmm7
000072bd77dd83e3  vmovaps [rsp+0x70], xmm8
000072bd77dd83e9  vmovaps [rsp+0x80], xmm9
000072bd77dd83f2  vmovaps [rsp+0x90], xmm10
000072bd77dd83fb  vmovaps [rsp+0xA0], xmm11
000072bd77dd8404  vmovaps [rsp+0xB0], xmm12
000072bd77dd840d  vmovaps [rsp+0xC0], xmm13
000072bd77dd8416  vmovaps [rsp+0xD0], xmm14
000072bd77dd841f  vmovaps [rsp+0xE0], xmm15
000072bd77dd8428  sub rsp, 0x30
000072bd77dd842c  movaps [rsp], xmm6
000072bd77dd8430  movaps [rsp+0x10], xmm9
000072bd77dd8436  movaps [rsp+0x20], xmm1
000072bd77dd843b  lea rdi, [rsp]
000072bd77dd843f  mov esi, 0x00
000072bd77dd8444  mov rax, 0x643206AC3530
000072bd77dd844e  call rax
000072bd77dd8450  movaps xmm6, [rsp]
000072bd77dd8454  add rsp, 0x30
000072bd77dd8458  vmovaps xmm0, [rsp]
000072bd77dd845d  vmovaps xmm1, [rsp+0x10]
000072bd77dd8463  vmovaps xmm2, [rsp+0x20]
000072bd77dd8469  vmovaps xmm3, [rsp+0x30]
000072bd77dd846f  vmovaps xmm4, [rsp+0x40]
000072bd77dd8475  vmovaps xmm5, [rsp+0x50]
000072bd77dd847b  vmovaps xmm7, [rsp+0x60]
000072bd77dd8481  vmovaps xmm8, [rsp+0x70]
000072bd77dd8487  vmovaps xmm9, [rsp+0x80]
000072bd77dd8490  vmovaps xmm10, [rsp+0x90]
000072bd77dd8499  vmovaps xmm11, [rsp+0xA0]
000072bd77dd84a2  vmovaps xmm12, [rsp+0xB0]
000072bd77dd84ab  vmovaps xmm13, [rsp+0xC0]
000072bd77dd84b4  vmovaps xmm14, [rsp+0xD0]
000072bd77dd84bd  vmovaps xmm15, [rsp+0xE0]
000072bd77dd84c6  add rsp, 0xF0
000072bd77dd84cd  pop r11
000072bd77dd84cf  pop r10
000072bd77dd84d1  pop r9
000072bd77dd84d3  pop r8
000072bd77dd84d5  pop rsi
000072bd77dd84d6  pop rdi
000072bd77dd84d7  pop rdx
000072bd77dd84d8  pop rcx
000072bd77dd84d9  pop rax
000072bd77dd84da  add rsp, 0x08
000072bd77dd84de  jmp 0x000072BD77DD5FAB
000072bd77dd84e3  sub rsp, 0x08
000072bd77dd84e7  push rax
000072bd77dd84e8  push rcx
000072bd77dd84e9  push rdx
000072bd77dd84ea  push rdi
000072bd77dd84eb  push rsi
000072bd77dd84ec  push r8
000072bd77dd84ee  push r9
000072bd77dd84f0  push r10
000072bd77dd84f2  push r11
000072bd77dd84f4  sub rsp, 0xF0
000072bd77dd84fb  vmovaps [rsp], xmm0
000072bd77dd8500  vmovaps [rsp+0x10], xmm1
000072bd77dd8506  vmovaps [rsp+0x20], xmm2
000072bd77dd850c  vmovaps [rsp+0x30], xmm3
000072bd77dd8512  vmovaps [rsp+0x40], xmm4
000072bd77dd8518  vmovaps [rsp+0x50], xmm5
000072bd77dd851e  vmovaps [rsp+0x60], xmm6
000072bd77dd8524  vmovaps [rsp+0x70], xmm7
000072bd77dd852a  vmovaps [rsp+0x80], xmm8
000072bd77dd8533  vmovaps [rsp+0x90], xmm10
000072bd77dd853c  vmovaps [rsp+0xA0], xmm11
000072bd77dd8545  vmovaps [rsp+0xB0], xmm12
000072bd77dd854e  vmovaps [rsp+0xC0], xmm13
000072bd77dd8557  vmovaps [rsp+0xD0], xmm14
000072bd77dd8560  vmovaps [rsp+0xE0], xmm15
000072bd77dd8569  sub rsp, 0x30
000072bd77dd856d  movaps [rsp], xmm9
000072bd77dd8572  movaps [rsp+0x10], xmm3
000072bd77dd8577  movaps [rsp+0x20], xmm1
000072bd77dd857c  lea rdi, [rsp]
000072bd77dd8580  mov esi, 0x00
000072bd77dd8585  mov rax, 0x643206AC3530
000072bd77dd858f  call rax
000072bd77dd8591  movaps xmm9, [rsp]
000072bd77dd8596  add rsp, 0x30
000072bd77dd859a  vmovaps xmm0, [rsp]
000072bd77dd859f  vmovaps xmm1, [rsp+0x10]
000072bd77dd85a5  vmovaps xmm2, [rsp+0x20]
000072bd77dd85ab  vmovaps xmm3, [rsp+0x30]
000072bd77dd85b1  vmovaps xmm4, [rsp+0x40]
000072bd77dd85b7  vmovaps xmm5, [rsp+0x50]
000072bd77dd85bd  vmovaps xmm6, [rsp+0x60]
000072bd77dd85c3  vmovaps xmm7, [rsp+0x70]
000072bd77dd85c9  vmovaps xmm8, [rsp+0x80]
000072bd77dd85d2  vmovaps xmm10, [rsp+0x90]
000072bd77dd85db  vmovaps xmm11, [rsp+0xA0]
000072bd77dd85e4  vmovaps xmm12, [rsp+0xB0]
000072bd77dd85ed  vmovaps xmm13, [rsp+0xC0]
000072bd77dd85f6  vmovaps xmm14, [rsp+0xD0]
000072bd77dd85ff  vmovaps xmm15, [rsp+0xE0]
000072bd77dd8608  add rsp, 0xF0
000072bd77dd860f  pop r11
000072bd77dd8611  pop r10
000072bd77dd8613  pop r9
000072bd77dd8615  pop r8
000072bd77dd8617  pop rsi
000072bd77dd8618  pop rdi
000072bd77dd8619  pop rdx
000072bd77dd861a  pop rcx
000072bd77dd861b  pop rax
000072bd77dd861c  add rsp, 0x08
000072bd77dd8620  jmp 0x000072BD77DD5FF7
000072bd77dd8625  call 0x000072BD77CD64F0
000072bd77dd862a  jmp 0x000072BD77DD6004
000072bd77dd862f  sub rsp, 0x08
000072bd77dd8633  push rax
000072bd77dd8634  push rcx
000072bd77dd8635  push rdx
000072bd77dd8636  push rdi
000072bd77dd8637  push rsi
000072bd77dd8638  push r8
000072bd77dd863a  push r9
000072bd77dd863c  push r10
000072bd77dd863e  push r11
000072bd77dd8640  sub rsp, 0xF0
000072bd77dd8647  vmovaps [rsp], xmm0
000072bd77dd864c  vmovaps [rsp+0x10], xmm1
000072bd77dd8652  vmovaps [rsp+0x20], xmm2
000072bd77dd8658  vmovaps [rsp+0x30], xmm3
000072bd77dd865e  vmovaps [rsp+0x40], xmm4
000072bd77dd8664  vmovaps [rsp+0x50], xmm5
000072bd77dd866a  vmovaps [rsp+0x60], xmm6
000072bd77dd8670  vmovaps [rsp+0x70], xmm7
000072bd77dd8676  vmovaps [rsp+0x80], xmm8
000072bd77dd867f  vmovaps [rsp+0x90], xmm9
000072bd77dd8688  vmovaps [rsp+0xA0], xmm10
000072bd77dd8691  vmovaps [rsp+0xB0], xmm11
000072bd77dd869a  vmovaps [rsp+0xC0], xmm12
000072bd77dd86a3  vmovaps [rsp+0xD0], xmm13
000072bd77dd86ac  vmovaps [rsp+0xE0], xmm14
000072bd77dd86b5  sub rsp, 0x30
000072bd77dd86b9  movaps [rsp], xmm15
000072bd77dd86be  movaps [rsp+0x10], xmm3
000072bd77dd86c3  movaps [rsp+0x20], xmm7
000072bd77dd86c8  lea rdi, [rsp]
000072bd77dd86cc  mov esi, 0x00
000072bd77dd86d1  mov rax, 0x643206AC3530
000072bd77dd86db  call rax
000072bd77dd86dd  movaps xmm15, [rsp]
000072bd77dd86e2  add rsp, 0x30
000072bd77dd86e6  vmovaps xmm0, [rsp]
000072bd77dd86eb  vmovaps xmm1, [rsp+0x10]
000072bd77dd86f1  vmovaps xmm2, [rsp+0x20]
000072bd77dd86f7  vmovaps xmm3, [rsp+0x30]
000072bd77dd86fd  vmovaps xmm4, [rsp+0x40]
000072bd77dd8703  vmovaps xmm5, [rsp+0x50]
000072bd77dd8709  vmovaps xmm6, [rsp+0x60]
000072bd77dd870f  vmovaps xmm7, [rsp+0x70]
000072bd77dd8715  vmovaps xmm8, [rsp+0x80]
000072bd77dd871e  vmovaps xmm9, [rsp+0x90]
000072bd77dd8727  vmovaps xmm10, [rsp+0xA0]
000072bd77dd8730  vmovaps xmm11, [rsp+0xB0]
000072bd77dd8739  vmovaps xmm12, [rsp+0xC0]
000072bd77dd8742  vmovaps xmm13, [rsp+0xD0]
000072bd77dd874b  vmovaps xmm14, [rsp+0xE0]
000072bd77dd8754  add rsp, 0xF0
000072bd77dd875b  pop r11
000072bd77dd875d  pop r10
000072bd77dd875f  pop r9
000072bd77dd8761  pop r8
000072bd77dd8763  pop rsi
000072bd77dd8764  pop rdi
000072bd77dd8765  pop rdx
000072bd77dd8766  pop rcx
000072bd77dd8767  pop rax
000072bd77dd8768  add rsp, 0x08
000072bd77dd876c  jmp 0x000072BD77DD6030
000072bd77dd8771  sub rsp, 0x08
000072bd77dd8775  push rax
000072bd77dd8776  push rcx
000072bd77dd8777  push rdx
000072bd77dd8778  push rdi
000072bd77dd8779  push rsi
000072bd77dd877a  push r8
000072bd77dd877c  push r9
000072bd77dd877e  push r10
000072bd77dd8780  push r11
000072bd77dd8782  sub rsp, 0xF0
000072bd77dd8789  vmovaps [rsp], xmm0
000072bd77dd878e  vmovaps [rsp+0x10], xmm1
000072bd77dd8794  vmovaps [rsp+0x20], xmm2
000072bd77dd879a  vmovaps [rsp+0x30], xmm4
000072bd77dd87a0  vmovaps [rsp+0x40], xmm5
000072bd77dd87a6  vmovaps [rsp+0x50], xmm6
000072bd77dd87ac  vmovaps [rsp+0x60], xmm7
000072bd77dd87b2  vmovaps [rsp+0x70], xmm8
000072bd77dd87b8  vmovaps [rsp+0x80], xmm9
000072bd77dd87c1  vmovaps [rsp+0x90], xmm10
000072bd77dd87ca  vmovaps [rsp+0xA0], xmm11
000072bd77dd87d3  vmovaps [rsp+0xB0], xmm12
000072bd77dd87dc  vmovaps [rsp+0xC0], xmm13
000072bd77dd87e5  vmovaps [rsp+0xD0], xmm14
000072bd77dd87ee  vmovaps [rsp+0xE0], xmm15
000072bd77dd87f7  sub rsp, 0x30
000072bd77dd87fb  movaps [rsp], xmm3
000072bd77dd87ff  movaps [rsp+0x10], xmm1
000072bd77dd8804  movaps [rsp+0x20], xmm15
000072bd77dd880a  lea rdi, [rsp]
000072bd77dd880e  mov esi, 0x00
000072bd77dd8813  mov rax, 0x643206AC3530
000072bd77dd881d  call rax
000072bd77dd881f  movaps xmm3, [rsp]
000072bd77dd8823  add rsp, 0x30
000072bd77dd8827  vmovaps xmm0, [rsp]
000072bd77dd882c  vmovaps xmm1, [rsp+0x10]
000072bd77dd8832  vmovaps xmm2, [rsp+0x20]
000072bd77dd8838  vmovaps xmm4, [rsp+0x30]
000072bd77dd883e  vmovaps xmm5, [rsp+0x40]
000072bd77dd8844  vmovaps xmm6, [rsp+0x50]
000072bd77dd884a  vmovaps xmm7, [rsp+0x60]
000072bd77dd8850  vmovaps xmm8, [rsp+0x70]
000072bd77dd8856  vmovaps xmm9, [rsp+0x80]
000072bd77dd885f  vmovaps xmm10, [rsp+0x90]
000072bd77dd8868  vmovaps xmm11, [rsp+0xA0]
000072bd77dd8871  vmovaps xmm12, [rsp+0xB0]
000072bd77dd887a  vmovaps xmm13, [rsp+0xC0]
000072bd77dd8883  vmovaps xmm14, [rsp+0xD0]
000072bd77dd888c  vmovaps xmm15, [rsp+0xE0]
000072bd77dd8895  add rsp, 0xF0
000072bd77dd889c  pop r11
000072bd77dd889e  pop r10
000072bd77dd88a0  pop r9
000072bd77dd88a2  pop r8
000072bd77dd88a4  pop rsi
000072bd77dd88a5  pop rdi
000072bd77dd88a6  pop rdx
000072bd77dd88a7  pop rcx
000072bd77dd88a8  pop rax
000072bd77dd88a9  add rsp, 0x08
000072bd77dd88ad  jmp 0x000072BD77DD60BF
000072bd77dd88b2  call 0x000072BD77CD64F0
000072bd77dd88b7  jmp 0x000072BD77DD60C9
000072bd77dd88bc  sub rsp, 0x08
000072bd77dd88c0  push rax
000072bd77dd88c1  push rcx
000072bd77dd88c2  push rdx
000072bd77dd88c3  push rdi
000072bd77dd88c4  push rsi
000072bd77dd88c5  push r8
000072bd77dd88c7  push r9
000072bd77dd88c9  push r10
000072bd77dd88cb  push r11
000072bd77dd88cd  sub rsp, 0xF0
000072bd77dd88d4  vmovaps [rsp], xmm0
000072bd77dd88d9  vmovaps [rsp+0x10], xmm1
000072bd77dd88df  vmovaps [rsp+0x20], xmm2
000072bd77dd88e5  vmovaps [rsp+0x30], xmm3
000072bd77dd88eb  vmovaps [rsp+0x40], xmm4
000072bd77dd88f1  vmovaps [rsp+0x50], xmm5
000072bd77dd88f7  vmovaps [rsp+0x60], xmm6
000072bd77dd88fd  vmovaps [rsp+0x70], xmm7
000072bd77dd8903  vmovaps [rsp+0x80], xmm8
000072bd77dd890c  vmovaps [rsp+0x90], xmm9
000072bd77dd8915  vmovaps [rsp+0xA0], xmm10
000072bd77dd891e  vmovaps [rsp+0xB0], xmm11
000072bd77dd8927  vmovaps [rsp+0xC0], xmm12
000072bd77dd8930  vmovaps [rsp+0xD0], xmm13
000072bd77dd8939  vmovaps [rsp+0xE0], xmm14
000072bd77dd8942  sub rsp, 0x30
000072bd77dd8946  movaps [rsp], xmm15
000072bd77dd894b  movaps [rsp+0x10], xmm14
000072bd77dd8951  movaps [rsp+0x20], xmm4
000072bd77dd8956  lea rdi, [rsp]
000072bd77dd895a  mov esi, 0x00
000072bd77dd895f  mov rax, 0x643206AC3530
000072bd77dd8969  call rax
000072bd77dd896b  movaps xmm15, [rsp]
000072bd77dd8970  add rsp, 0x30
000072bd77dd8974  vmovaps xmm0, [rsp]
000072bd77dd8979  vmovaps xmm1, [rsp+0x10]
000072bd77dd897f  vmovaps xmm2, [rsp+0x20]
000072bd77dd8985  vmovaps xmm3, [rsp+0x30]
000072bd77dd898b  vmovaps xmm4, [rsp+0x40]
000072bd77dd8991  vmovaps xmm5, [rsp+0x50]
000072bd77dd8997  vmovaps xmm6, [rsp+0x60]
000072bd77dd899d  vmovaps xmm7, [rsp+0x70]
000072bd77dd89a3  vmovaps xmm8, [rsp+0x80]
000072bd77dd89ac  vmovaps xmm9, [rsp+0x90]
000072bd77dd89b5  vmovaps xmm10, [rsp+0xA0]
000072bd77dd89be  vmovaps xmm11, [rsp+0xB0]
000072bd77dd89c7  vmovaps xmm12, [rsp+0xC0]
000072bd77dd89d0  vmovaps xmm13, [rsp+0xD0]
000072bd77dd89d9  vmovaps xmm14, [rsp+0xE0]
000072bd77dd89e2  add rsp, 0xF0
000072bd77dd89e9  pop r11
000072bd77dd89eb  pop r10
000072bd77dd89ed  pop r9
000072bd77dd89ef  pop r8
000072bd77dd89f1  pop rsi
000072bd77dd89f2  pop rdi
000072bd77dd89f3  pop rdx
000072bd77dd89f4  pop rcx
000072bd77dd89f5  pop rax
000072bd77dd89f6  add rsp, 0x08
000072bd77dd89fa  jmp 0x000072BD77DD60F7
000072bd77dd89ff  sub rsp, 0x08
000072bd77dd8a03  push rax
000072bd77dd8a04  push rcx
000072bd77dd8a05  push rdx
000072bd77dd8a06  push rdi
000072bd77dd8a07  push rsi
000072bd77dd8a08  push r8
000072bd77dd8a0a  push r9
000072bd77dd8a0c  push r10
000072bd77dd8a0e  push r11
000072bd77dd8a10  sub rsp, 0xF0
000072bd77dd8a17  vmovaps [rsp], xmm0
000072bd77dd8a1c  vmovaps [rsp+0x10], xmm1
000072bd77dd8a22  vmovaps [rsp+0x20], xmm2
000072bd77dd8a28  vmovaps [rsp+0x30], xmm3
000072bd77dd8a2e  vmovaps [rsp+0x40], xmm4
000072bd77dd8a34  vmovaps [rsp+0x50], xmm5
000072bd77dd8a3a  vmovaps [rsp+0x60], xmm6
000072bd77dd8a40  vmovaps [rsp+0x70], xmm7
000072bd77dd8a46  vmovaps [rsp+0x80], xmm8
000072bd77dd8a4f  vmovaps [rsp+0x90], xmm9
000072bd77dd8a58  vmovaps [rsp+0xA0], xmm10
000072bd77dd8a61  vmovaps [rsp+0xB0], xmm11
000072bd77dd8a6a  vmovaps [rsp+0xC0], xmm12
000072bd77dd8a73  vmovaps [rsp+0xD0], xmm13
000072bd77dd8a7c  vmovaps [rsp+0xE0], xmm15
000072bd77dd8a85  sub rsp, 0x30
000072bd77dd8a89  movaps [rsp], xmm14
000072bd77dd8a8e  movaps [rsp+0x10], xmm2
000072bd77dd8a93  movaps [rsp+0x20], xmm1
000072bd77dd8a98  lea rdi, [rsp]
000072bd77dd8a9c  mov esi, 0x00
000072bd77dd8aa1  mov rax, 0x643206AC3530
000072bd77dd8aab  call rax
000072bd77dd8aad  movaps xmm14, [rsp]
000072bd77dd8ab2  add rsp, 0x30
000072bd77dd8ab6  vmovaps xmm0, [rsp]
000072bd77dd8abb  vmovaps xmm1, [rsp+0x10]
000072bd77dd8ac1  vmovaps xmm2, [rsp+0x20]
000072bd77dd8ac7  vmovaps xmm3, [rsp+0x30]
000072bd77dd8acd  vmovaps xmm4, [rsp+0x40]
000072bd77dd8ad3  vmovaps xmm5, [rsp+0x50]
000072bd77dd8ad9  vmovaps xmm6, [rsp+0x60]
000072bd77dd8adf  vmovaps xmm7, [rsp+0x70]
000072bd77dd8ae5  vmovaps xmm8, [rsp+0x80]
000072bd77dd8aee  vmovaps xmm9, [rsp+0x90]
000072bd77dd8af7  vmovaps xmm10, [rsp+0xA0]
000072bd77dd8b00  vmovaps xmm11, [rsp+0xB0]
000072bd77dd8b09  vmovaps xmm12, [rsp+0xC0]
000072bd77dd8b12  vmovaps xmm13, [rsp+0xD0]
000072bd77dd8b1b  vmovaps xmm15, [rsp+0xE0]
000072bd77dd8b24  add rsp, 0xF0
000072bd77dd8b2b  pop r11
000072bd77dd8b2d  pop r10
000072bd77dd8b2f  pop r9
000072bd77dd8b31  pop r8
000072bd77dd8b33  pop rsi
000072bd77dd8b34  pop rdi
000072bd77dd8b35  pop rdx
000072bd77dd8b36  pop rcx
000072bd77dd8b37  pop rax
000072bd77dd8b38  add rsp, 0x08
000072bd77dd8b3c  jmp 0x000072BD77DD611D
000072bd77dd8b41  sub rsp, 0x08
000072bd77dd8b45  push rax
000072bd77dd8b46  push rcx
000072bd77dd8b47  push rdx
000072bd77dd8b48  push rdi
000072bd77dd8b49  push rsi
000072bd77dd8b4a  push r8
000072bd77dd8b4c  push r9
000072bd77dd8b4e  push r10
000072bd77dd8b50  push r11
000072bd77dd8b52  sub rsp, 0xF0
000072bd77dd8b59  vmovaps [rsp], xmm0
000072bd77dd8b5e  vmovaps [rsp+0x10], xmm2
000072bd77dd8b64  vmovaps [rsp+0x20], xmm3
000072bd77dd8b6a  vmovaps [rsp+0x30], xmm4
000072bd77dd8b70  vmovaps [rsp+0x40], xmm5
000072bd77dd8b76  vmovaps [rsp+0x50], xmm6
000072bd77dd8b7c  vmovaps [rsp+0x60], xmm7
000072bd77dd8b82  vmovaps [rsp+0x70], xmm8
000072bd77dd8b88  vmovaps [rsp+0x80], xmm9
000072bd77dd8b91  vmovaps [rsp+0x90], xmm10
000072bd77dd8b9a  vmovaps [rsp+0xA0], xmm11
000072bd77dd8ba3  vmovaps [rsp+0xB0], xmm12
000072bd77dd8bac  vmovaps [rsp+0xC0], xmm13
000072bd77dd8bb5  vmovaps [rsp+0xD0], xmm14
000072bd77dd8bbe  vmovaps [rsp+0xE0], xmm15
000072bd77dd8bc7  sub rsp, 0x30
000072bd77dd8bcb  movaps [rsp], xmm1
000072bd77dd8bcf  movaps [rsp+0x10], xmm4
000072bd77dd8bd4  movaps [rsp+0x20], xmm9
000072bd77dd8bda  lea rdi, [rsp]
000072bd77dd8bde  mov esi, 0x00
000072bd77dd8be3  mov rax, 0x643206AC3530
000072bd77dd8bed  call rax
000072bd77dd8bef  movaps xmm1, [rsp]
000072bd77dd8bf3  add rsp, 0x30
000072bd77dd8bf7  vmovaps xmm0, [rsp]
000072bd77dd8bfc  vmovaps xmm2, [rsp+0x10]
000072bd77dd8c02  vmovaps xmm3, [rsp+0x20]
000072bd77dd8c08  vmovaps xmm4, [rsp+0x30]
000072bd77dd8c0e  vmovaps xmm5, [rsp+0x40]
000072bd77dd8c14  vmovaps xmm6, [rsp+0x50]
000072bd77dd8c1a  vmovaps xmm7, [rsp+0x60]
000072bd77dd8c20  vmovaps xmm8, [rsp+0x70]
000072bd77dd8c26  vmovaps xmm9, [rsp+0x80]
000072bd77dd8c2f  vmovaps xmm10, [rsp+0x90]
000072bd77dd8c38  vmovaps xmm11, [rsp+0xA0]
000072bd77dd8c41  vmovaps xmm12, [rsp+0xB0]
000072bd77dd8c4a  vmovaps xmm13, [rsp+0xC0]
000072bd77dd8c53  vmovaps xmm14, [rsp+0xD0]
000072bd77dd8c5c  vmovaps xmm15, [rsp+0xE0]
000072bd77dd8c65  add rsp, 0xF0
000072bd77dd8c6c  pop r11
000072bd77dd8c6e  pop r10
000072bd77dd8c70  pop r9
000072bd77dd8c72  pop r8
000072bd77dd8c74  pop rsi
000072bd77dd8c75  pop rdi
000072bd77dd8c76  pop rdx
000072bd77dd8c77  pop rcx
000072bd77dd8c78  pop rax
000072bd77dd8c79  add rsp, 0x08
000072bd77dd8c7d  jmp 0x000072BD77DD613B
000072bd77dd8c82  sub rsp, 0x08
000072bd77dd8c86  push rax
000072bd77dd8c87  push rcx
000072bd77dd8c88  push rdx
000072bd77dd8c89  push rdi
000072bd77dd8c8a  push rsi
000072bd77dd8c8b  push r8
000072bd77dd8c8d  push r9
000072bd77dd8c8f  push r10
000072bd77dd8c91  push r11
000072bd77dd8c93  sub rsp, 0xF0
000072bd77dd8c9a  vmovaps [rsp], xmm0
000072bd77dd8c9f  vmovaps [rsp+0x10], xmm1
000072bd77dd8ca5  vmovaps [rsp+0x20], xmm2
000072bd77dd8cab  vmovaps [rsp+0x30], xmm3
000072bd77dd8cb1  vmovaps [rsp+0x40], xmm5
000072bd77dd8cb7  vmovaps [rsp+0x50], xmm6
000072bd77dd8cbd  vmovaps [rsp+0x60], xmm7
000072bd77dd8cc3  vmovaps [rsp+0x70], xmm8
000072bd77dd8cc9  vmovaps [rsp+0x80], xmm9
000072bd77dd8cd2  vmovaps [rsp+0x90], xmm10
000072bd77dd8cdb  vmovaps [rsp+0xA0], xmm11
000072bd77dd8ce4  vmovaps [rsp+0xB0], xmm12
000072bd77dd8ced  vmovaps [rsp+0xC0], xmm13
000072bd77dd8cf6  vmovaps [rsp+0xD0], xmm14
000072bd77dd8cff  vmovaps [rsp+0xE0], xmm15
000072bd77dd8d08  sub rsp, 0x30
000072bd77dd8d0c  movaps [rsp], xmm4
000072bd77dd8d10  movaps [rsp+0x10], xmm2
000072bd77dd8d15  movaps [rsp+0x20], xmm9
000072bd77dd8d1b  lea rdi, [rsp]
000072bd77dd8d1f  mov esi, 0x00
000072bd77dd8d24  mov rax, 0x643206AC3530
000072bd77dd8d2e  call rax
000072bd77dd8d30  movaps xmm4, [rsp]
000072bd77dd8d34  add rsp, 0x30
000072bd77dd8d38  vmovaps xmm0, [rsp]
000072bd77dd8d3d  vmovaps xmm1, [rsp+0x10]
000072bd77dd8d43  vmovaps xmm2, [rsp+0x20]
000072bd77dd8d49  vmovaps xmm3, [rsp+0x30]
000072bd77dd8d4f  vmovaps xmm5, [rsp+0x40]
000072bd77dd8d55  vmovaps xmm6, [rsp+0x50]
000072bd77dd8d5b  vmovaps xmm7, [rsp+0x60]
000072bd77dd8d61  vmovaps xmm8, [rsp+0x70]
000072bd77dd8d67  vmovaps xmm9, [rsp+0x80]
000072bd77dd8d70  vmovaps xmm10, [rsp+0x90]
000072bd77dd8d79  vmovaps xmm11, [rsp+0xA0]
000072bd77dd8d82  vmovaps xmm12, [rsp+0xB0]
000072bd77dd8d8b  vmovaps xmm13, [rsp+0xC0]
000072bd77dd8d94  vmovaps xmm14, [rsp+0xD0]
000072bd77dd8d9d  vmovaps xmm15, [rsp+0xE0]
000072bd77dd8da6  add rsp, 0xF0
000072bd77dd8dad  pop r11
000072bd77dd8daf  pop r10
000072bd77dd8db1  pop r9
000072bd77dd8db3  pop r8
000072bd77dd8db5  pop rsi
000072bd77dd8db6  pop rdi
000072bd77dd8db7  pop rdx
000072bd77dd8db8  pop rcx
000072bd77dd8db9  pop rax
000072bd77dd8dba  add rsp, 0x08
000072bd77dd8dbe  jmp 0x000072BD77DD616B
000072bd77dd8dc3  sub rsp, 0x08
000072bd77dd8dc7  push rax
000072bd77dd8dc8  push rcx
000072bd77dd8dc9  push rdx
000072bd77dd8dca  push rdi
000072bd77dd8dcb  push rsi
000072bd77dd8dcc  push r8
000072bd77dd8dce  push r9
000072bd77dd8dd0  push r10
000072bd77dd8dd2  push r11
000072bd77dd8dd4  sub rsp, 0xF0
000072bd77dd8ddb  vmovaps [rsp], xmm0
000072bd77dd8de0  vmovaps [rsp+0x10], xmm1
000072bd77dd8de6  vmovaps [rsp+0x20], xmm2
000072bd77dd8dec  vmovaps [rsp+0x30], xmm3
000072bd77dd8df2  vmovaps [rsp+0x40], xmm4
000072bd77dd8df8  vmovaps [rsp+0x50], xmm5
000072bd77dd8dfe  vmovaps [rsp+0x60], xmm6
000072bd77dd8e04  vmovaps [rsp+0x70], xmm7
000072bd77dd8e0a  vmovaps [rsp+0x80], xmm8
000072bd77dd8e13  vmovaps [rsp+0x90], xmm10
000072bd77dd8e1c  vmovaps [rsp+0xA0], xmm11
000072bd77dd8e25  vmovaps [rsp+0xB0], xmm12
000072bd77dd8e2e  vmovaps [rsp+0xC0], xmm13
000072bd77dd8e37  vmovaps [rsp+0xD0], xmm14
000072bd77dd8e40  vmovaps [rsp+0xE0], xmm15
000072bd77dd8e49  sub rsp, 0x30
000072bd77dd8e4d  movaps [rsp], xmm9
000072bd77dd8e52  movaps [rsp+0x10], xmm2
000072bd77dd8e57  movaps [rsp+0x20], xmm1
000072bd77dd8e5c  lea rdi, [rsp]
000072bd77dd8e60  mov esi, 0x00
000072bd77dd8e65  mov rax, 0x643206AC3530
000072bd77dd8e6f  call rax
000072bd77dd8e71  movaps xmm9, [rsp]
000072bd77dd8e76  add rsp, 0x30
000072bd77dd8e7a  vmovaps xmm0, [rsp]
000072bd77dd8e7f  vmovaps xmm1, [rsp+0x10]
000072bd77dd8e85  vmovaps xmm2, [rsp+0x20]
000072bd77dd8e8b  vmovaps xmm3, [rsp+0x30]
000072bd77dd8e91  vmovaps xmm4, [rsp+0x40]
000072bd77dd8e97  vmovaps xmm5, [rsp+0x50]
000072bd77dd8e9d  vmovaps xmm6, [rsp+0x60]
000072bd77dd8ea3  vmovaps xmm7, [rsp+0x70]
000072bd77dd8ea9  vmovaps xmm8, [rsp+0x80]
000072bd77dd8eb2  vmovaps xmm10, [rsp+0x90]
000072bd77dd8ebb  vmovaps xmm11, [rsp+0xA0]
000072bd77dd8ec4  vmovaps xmm12, [rsp+0xB0]
000072bd77dd8ecd  vmovaps xmm13, [rsp+0xC0]
000072bd77dd8ed6  vmovaps xmm14, [rsp+0xD0]
000072bd77dd8edf  vmovaps xmm15, [rsp+0xE0]
000072bd77dd8ee8  add rsp, 0xF0
000072bd77dd8eef  pop r11
000072bd77dd8ef1  pop r10
000072bd77dd8ef3  pop r9
000072bd77dd8ef5  pop r8
000072bd77dd8ef7  pop rsi
000072bd77dd8ef8  pop rdi
000072bd77dd8ef9  pop rdx
000072bd77dd8efa  pop rcx
000072bd77dd8efb  pop rax
000072bd77dd8efc  add rsp, 0x08
000072bd77dd8f00  jmp 0x000072BD77DD61A1
000072bd77dd8f05  sub rsp, 0x08
000072bd77dd8f09  push rax
000072bd77dd8f0a  push rcx
000072bd77dd8f0b  push rdx
000072bd77dd8f0c  push rdi
000072bd77dd8f0d  push rsi
000072bd77dd8f0e  push r8
000072bd77dd8f10  push r9
000072bd77dd8f12  push r10
000072bd77dd8f14  push r11
000072bd77dd8f16  sub rsp, 0xF0
000072bd77dd8f1d  vmovaps [rsp], xmm0
000072bd77dd8f22  vmovaps [rsp+0x10], xmm2
000072bd77dd8f28  vmovaps [rsp+0x20], xmm3
000072bd77dd8f2e  vmovaps [rsp+0x30], xmm4
000072bd77dd8f34  vmovaps [rsp+0x40], xmm5
000072bd77dd8f3a  vmovaps [rsp+0x50], xmm6
000072bd77dd8f40  vmovaps [rsp+0x60], xmm7
000072bd77dd8f46  vmovaps [rsp+0x70], xmm8
000072bd77dd8f4c  vmovaps [rsp+0x80], xmm9
000072bd77dd8f55  vmovaps [rsp+0x90], xmm10
000072bd77dd8f5e  vmovaps [rsp+0xA0], xmm11
000072bd77dd8f67  vmovaps [rsp+0xB0], xmm12
000072bd77dd8f70  vmovaps [rsp+0xC0], xmm13
000072bd77dd8f79  vmovaps [rsp+0xD0], xmm14
000072bd77dd8f82  vmovaps [rsp+0xE0], xmm15
000072bd77dd8f8b  sub rsp, 0x30
000072bd77dd8f8f  movaps [rsp], xmm1
000072bd77dd8f93  movaps [rsp+0x10], xmm15
000072bd77dd8f99  movaps [rsp+0x20], xmm6
000072bd77dd8f9e  lea rdi, [rsp]
000072bd77dd8fa2  mov esi, 0x00
000072bd77dd8fa7  mov rax, 0x643206AC3530
000072bd77dd8fb1  call rax
000072bd77dd8fb3  movaps xmm1, [rsp]
000072bd77dd8fb7  add rsp, 0x30
000072bd77dd8fbb  vmovaps xmm0, [rsp]
000072bd77dd8fc0  vmovaps xmm2, [rsp+0x10]
000072bd77dd8fc6  vmovaps xmm3, [rsp+0x20]
000072bd77dd8fcc  vmovaps xmm4, [rsp+0x30]
000072bd77dd8fd2  vmovaps xmm5, [rsp+0x40]
000072bd77dd8fd8  vmovaps xmm6, [rsp+0x50]
000072bd77dd8fde  vmovaps xmm7, [rsp+0x60]
000072bd77dd8fe4  vmovaps xmm8, [rsp+0x70]
000072bd77dd8fea  vmovaps xmm9, [rsp+0x80]
000072bd77dd8ff3  vmovaps xmm10, [rsp+0x90]
000072bd77dd8ffc  vmovaps xmm11, [rsp+0xA0]
000072bd77dd9005  vmovaps xmm12, [rsp+0xB0]
000072bd77dd900e  vmovaps xmm13, [rsp+0xC0]
000072bd77dd9017  vmovaps xmm14, [rsp+0xD0]
000072bd77dd9020  vmovaps xmm15, [rsp+0xE0]
000072bd77dd9029  add rsp, 0xF0
000072bd77dd9030  pop r11
000072bd77dd9032  pop r10
000072bd77dd9034  pop r9
000072bd77dd9036  pop r8
000072bd77dd9038  pop rsi
000072bd77dd9039  pop rdi
000072bd77dd903a  pop rdx
000072bd77dd903b  pop rcx
000072bd77dd903c  pop rax
000072bd77dd903d  add rsp, 0x08
000072bd77dd9041  jmp 0x000072BD77DD61C2
000072bd77dd9046  sub rsp, 0x08
000072bd77dd904a  push rax
000072bd77dd904b  push rcx
000072bd77dd904c  push rdx
000072bd77dd904d  push rdi
000072bd77dd904e  push rsi
000072bd77dd904f  push r8
000072bd77dd9051  push r9
000072bd77dd9053  push r10
000072bd77dd9055  push r11
000072bd77dd9057  sub rsp, 0xF0
000072bd77dd905e  vmovaps [rsp], xmm0
000072bd77dd9063  vmovaps [rsp+0x10], xmm1
000072bd77dd9069  vmovaps [rsp+0x20], xmm2
000072bd77dd906f  vmovaps [rsp+0x30], xmm3
000072bd77dd9075  vmovaps [rsp+0x40], xmm4
000072bd77dd907b  vmovaps [rsp+0x50], xmm5
000072bd77dd9081  vmovaps [rsp+0x60], xmm6
000072bd77dd9087  vmovaps [rsp+0x70], xmm7
000072bd77dd908d  vmovaps [rsp+0x80], xmm8
000072bd77dd9096  vmovaps [rsp+0x90], xmm9
000072bd77dd909f  vmovaps [rsp+0xA0], xmm10
000072bd77dd90a8  vmovaps [rsp+0xB0], xmm11
000072bd77dd90b1  vmovaps [rsp+0xC0], xmm12
000072bd77dd90ba  vmovaps [rsp+0xD0], xmm13
000072bd77dd90c3  vmovaps [rsp+0xE0], xmm14
000072bd77dd90cc  sub rsp, 0x30
000072bd77dd90d0  movaps [rsp], xmm15
000072bd77dd90d5  movaps [rsp+0x10], xmm5
000072bd77dd90da  movaps [rsp+0x20], xmm3
000072bd77dd90df  lea rdi, [rsp]
000072bd77dd90e3  mov esi, 0x00
000072bd77dd90e8  mov rax, 0x643206AC3530
000072bd77dd90f2  call rax
000072bd77dd90f4  movaps xmm15, [rsp]
000072bd77dd90f9  add rsp, 0x30
000072bd77dd90fd  vmovaps xmm0, [rsp]
000072bd77dd9102  vmovaps xmm1, [rsp+0x10]
000072bd77dd9108  vmovaps xmm2, [rsp+0x20]
000072bd77dd910e  vmovaps xmm3, [rsp+0x30]
000072bd77dd9114  vmovaps xmm4, [rsp+0x40]
000072bd77dd911a  vmovaps xmm5, [rsp+0x50]
000072bd77dd9120  vmovaps xmm6, [rsp+0x60]
000072bd77dd9126  vmovaps xmm7, [rsp+0x70]
000072bd77dd912c  vmovaps xmm8, [rsp+0x80]
000072bd77dd9135  vmovaps xmm9, [rsp+0x90]
000072bd77dd913e  vmovaps xmm10, [rsp+0xA0]
000072bd77dd9147  vmovaps xmm11, [rsp+0xB0]
000072bd77dd9150  vmovaps xmm12, [rsp+0xC0]
000072bd77dd9159  vmovaps xmm13, [rsp+0xD0]
000072bd77dd9162  vmovaps xmm14, [rsp+0xE0]
000072bd77dd916b  add rsp, 0xF0
000072bd77dd9172  pop r11
000072bd77dd9174  pop r10
000072bd77dd9176  pop r9
000072bd77dd9178  pop r8
000072bd77dd917a  pop rsi
000072bd77dd917b  pop rdi
000072bd77dd917c  pop rdx
000072bd77dd917d  pop rcx
000072bd77dd917e  pop rax
000072bd77dd917f  add rsp, 0x08
000072bd77dd9183  jmp 0x000072BD77DD61DC
000072bd77dd9188  sub rsp, 0x08
000072bd77dd918c  push rax
000072bd77dd918d  push rcx
000072bd77dd918e  push rdx
000072bd77dd918f  push rdi
000072bd77dd9190  push rsi
000072bd77dd9191  push r8
000072bd77dd9193  push r9
000072bd77dd9195  push r10
000072bd77dd9197  push r11
000072bd77dd9199  sub rsp, 0xF0
000072bd77dd91a0  vmovaps [rsp], xmm0
000072bd77dd91a5  vmovaps [rsp+0x10], xmm1
000072bd77dd91ab  vmovaps [rsp+0x20], xmm2
000072bd77dd91b1  vmovaps [rsp+0x30], xmm3
000072bd77dd91b7  vmovaps [rsp+0x40], xmm4
000072bd77dd91bd  vmovaps [rsp+0x50], xmm6
000072bd77dd91c3  vmovaps [rsp+0x60], xmm7
000072bd77dd91c9  vmovaps [rsp+0x70], xmm8
000072bd77dd91cf  vmovaps [rsp+0x80], xmm9
000072bd77dd91d8  vmovaps [rsp+0x90], xmm10
000072bd77dd91e1  vmovaps [rsp+0xA0], xmm11
000072bd77dd91ea  vmovaps [rsp+0xB0], xmm12
000072bd77dd91f3  vmovaps [rsp+0xC0], xmm13
000072bd77dd91fc  vmovaps [rsp+0xD0], xmm14
000072bd77dd9205  vmovaps [rsp+0xE0], xmm15
000072bd77dd920e  sub rsp, 0x30
000072bd77dd9212  movaps [rsp], xmm5
000072bd77dd9216  movaps [rsp+0x10], xmm8
000072bd77dd921c  movaps [rsp+0x20], xmm6
000072bd77dd9221  lea rdi, [rsp]
000072bd77dd9225  mov esi, 0x00
000072bd77dd922a  mov rax, 0x643206AC3530
000072bd77dd9234  call rax
000072bd77dd9236  movaps xmm5, [rsp]
000072bd77dd923a  add rsp, 0x30
000072bd77dd923e  vmovaps xmm0, [rsp]
000072bd77dd9243  vmovaps xmm1, [rsp+0x10]
000072bd77dd9249  vmovaps xmm2, [rsp+0x20]
000072bd77dd924f  vmovaps xmm3, [rsp+0x30]
000072bd77dd9255  vmovaps xmm4, [rsp+0x40]
000072bd77dd925b  vmovaps xmm6, [rsp+0x50]
000072bd77dd9261  vmovaps xmm7, [rsp+0x60]
000072bd77dd9267  vmovaps xmm8, [rsp+0x70]
000072bd77dd926d  vmovaps xmm9, [rsp+0x80]
000072bd77dd9276  vmovaps xmm10, [rsp+0x90]
000072bd77dd927f  vmovaps xmm11, [rsp+0xA0]
000072bd77dd9288  vmovaps xmm12, [rsp+0xB0]
000072bd77dd9291  vmovaps xmm13, [rsp+0xC0]
000072bd77dd929a  vmovaps xmm14, [rsp+0xD0]
000072bd77dd92a3  vmovaps xmm15, [rsp+0xE0]
000072bd77dd92ac  add rsp, 0xF0
000072bd77dd92b3  pop r11
000072bd77dd92b5  pop r10
000072bd77dd92b7  pop r9
000072bd77dd92b9  pop r8
000072bd77dd92bb  pop rsi
000072bd77dd92bc  pop rdi
000072bd77dd92bd  pop rdx
000072bd77dd92be  pop rcx
000072bd77dd92bf  pop rax
000072bd77dd92c0  add rsp, 0x08
000072bd77dd92c4  jmp 0x000072BD77DD6200
000072bd77dd92c9  sub rsp, 0x08
000072bd77dd92cd  push rax
000072bd77dd92ce  push rcx
000072bd77dd92cf  push rdx
000072bd77dd92d0  push rdi
000072bd77dd92d1  push rsi
000072bd77dd92d2  push r8
000072bd77dd92d4  push r9
000072bd77dd92d6  push r10
000072bd77dd92d8  push r11
000072bd77dd92da  sub rsp, 0xF0
000072bd77dd92e1  vmovaps [rsp], xmm0
000072bd77dd92e6  vmovaps [rsp+0x10], xmm1
000072bd77dd92ec  vmovaps [rsp+0x20], xmm2
000072bd77dd92f2  vmovaps [rsp+0x30], xmm3
000072bd77dd92f8  vmovaps [rsp+0x40], xmm4
000072bd77dd92fe  vmovaps [rsp+0x50], xmm5
000072bd77dd9304  vmovaps [rsp+0x60], xmm7
000072bd77dd930a  vmovaps [rsp+0x70], xmm8
000072bd77dd9310  vmovaps [rsp+0x80], xmm9
000072bd77dd9319  vmovaps [rsp+0x90], xmm10
000072bd77dd9322  vmovaps [rsp+0xA0], xmm11
000072bd77dd932b  vmovaps [rsp+0xB0], xmm12
000072bd77dd9334  vmovaps [rsp+0xC0], xmm13
000072bd77dd933d  vmovaps [rsp+0xD0], xmm14
000072bd77dd9346  vmovaps [rsp+0xE0], xmm15
000072bd77dd934f  sub rsp, 0x30
000072bd77dd9353  movaps [rsp], xmm6
000072bd77dd9357  movaps [rsp+0x10], xmm10
000072bd77dd935d  movaps [rsp+0x20], xmm8
000072bd77dd9363  lea rdi, [rsp]
000072bd77dd9367  mov esi, 0x00
000072bd77dd936c  mov rax, 0x643206AC3530
000072bd77dd9376  call rax
000072bd77dd9378  movaps xmm6, [rsp]
000072bd77dd937c  add rsp, 0x30
000072bd77dd9380  vmovaps xmm0, [rsp]
000072bd77dd9385  vmovaps xmm1, [rsp+0x10]
000072bd77dd938b  vmovaps xmm2, [rsp+0x20]
000072bd77dd9391  vmovaps xmm3, [rsp+0x30]
000072bd77dd9397  vmovaps xmm4, [rsp+0x40]
000072bd77dd939d  vmovaps xmm5, [rsp+0x50]
000072bd77dd93a3  vmovaps xmm7, [rsp+0x60]
000072bd77dd93a9  vmovaps xmm8, [rsp+0x70]
000072bd77dd93af  vmovaps xmm9, [rsp+0x80]
000072bd77dd93b8  vmovaps xmm10, [rsp+0x90]
000072bd77dd93c1  vmovaps xmm11, [rsp+0xA0]
000072bd77dd93ca  vmovaps xmm12, [rsp+0xB0]
000072bd77dd93d3  vmovaps xmm13, [rsp+0xC0]
000072bd77dd93dc  vmovaps xmm14, [rsp+0xD0]
000072bd77dd93e5  vmovaps xmm15, [rsp+0xE0]
000072bd77dd93ee  add rsp, 0xF0
000072bd77dd93f5  pop r11
000072bd77dd93f7  pop r10
000072bd77dd93f9  pop r9
000072bd77dd93fb  pop r8
000072bd77dd93fd  pop rsi
000072bd77dd93fe  pop rdi
000072bd77dd93ff  pop rdx
000072bd77dd9400  pop rcx
000072bd77dd9401  pop rax
000072bd77dd9402  add rsp, 0x08
000072bd77dd9406  jmp 0x000072BD77DD6225
000072bd77dd940b  sub rsp, 0x08
000072bd77dd940f  push rax
000072bd77dd9410  push rcx
000072bd77dd9411  push rdx
000072bd77dd9412  push rdi
000072bd77dd9413  push rsi
000072bd77dd9414  push r8
000072bd77dd9416  push r9
000072bd77dd9418  push r10
000072bd77dd941a  push r11
000072bd77dd941c  sub rsp, 0xF0
000072bd77dd9423  vmovaps [rsp], xmm0
000072bd77dd9428  vmovaps [rsp+0x10], xmm1
000072bd77dd942e  vmovaps [rsp+0x20], xmm2
000072bd77dd9434  vmovaps [rsp+0x30], xmm3
000072bd77dd943a  vmovaps [rsp+0x40], xmm4
000072bd77dd9440  vmovaps [rsp+0x50], xmm5
000072bd77dd9446  vmovaps [rsp+0x60], xmm6
000072bd77dd944c  vmovaps [rsp+0x70], xmm7
000072bd77dd9452  vmovaps [rsp+0x80], xmm8
000072bd77dd945b  vmovaps [rsp+0x90], xmm9
000072bd77dd9464  vmovaps [rsp+0xA0], xmm11
000072bd77dd946d  vmovaps [rsp+0xB0], xmm12
000072bd77dd9476  vmovaps [rsp+0xC0], xmm13
000072bd77dd947f  vmovaps [rsp+0xD0], xmm14
000072bd77dd9488  vmovaps [rsp+0xE0], xmm15
000072bd77dd9491  sub rsp, 0x30
000072bd77dd9495  movaps [rsp], xmm10
000072bd77dd949a  movaps [rsp+0x10], xmm8
000072bd77dd94a0  movaps [rsp+0x20], xmm14
000072bd77dd94a6  lea rdi, [rsp]
000072bd77dd94aa  mov esi, 0x00
000072bd77dd94af  mov rax, 0x643206AC3530
000072bd77dd94b9  call rax
000072bd77dd94bb  movaps xmm10, [rsp]
000072bd77dd94c0  add rsp, 0x30
000072bd77dd94c4  vmovaps xmm0, [rsp]
000072bd77dd94c9  vmovaps xmm1, [rsp+0x10]
000072bd77dd94cf  vmovaps xmm2, [rsp+0x20]
000072bd77dd94d5  vmovaps xmm3, [rsp+0x30]
000072bd77dd94db  vmovaps xmm4, [rsp+0x40]
000072bd77dd94e1  vmovaps xmm5, [rsp+0x50]
000072bd77dd94e7  vmovaps xmm6, [rsp+0x60]
000072bd77dd94ed  vmovaps xmm7, [rsp+0x70]
000072bd77dd94f3  vmovaps xmm8, [rsp+0x80]
000072bd77dd94fc  vmovaps xmm9, [rsp+0x90]
000072bd77dd9505  vmovaps xmm11, [rsp+0xA0]
000072bd77dd950e  vmovaps xmm12, [rsp+0xB0]
000072bd77dd9517  vmovaps xmm13, [rsp+0xC0]
000072bd77dd9520  vmovaps xmm14, [rsp+0xD0]
000072bd77dd9529  vmovaps xmm15, [rsp+0xE0]
000072bd77dd9532  add rsp, 0xF0
000072bd77dd9539  pop r11
000072bd77dd953b  pop r10
000072bd77dd953d  pop r9
000072bd77dd953f  pop r8
000072bd77dd9541  pop rsi
000072bd77dd9542  pop rdi
000072bd77dd9543  pop rdx
000072bd77dd9544  pop rcx
000072bd77dd9545  pop rax
000072bd77dd9546  add rsp, 0x08
000072bd77dd954a  jmp 0x000072BD77DD6245
000072bd77dd954f  sub rsp, 0x08
000072bd77dd9553  push rax
000072bd77dd9554  push rcx
000072bd77dd9555  push rdx
000072bd77dd9556  push rdi
000072bd77dd9557  push rsi
000072bd77dd9558  push r8
000072bd77dd955a  push r9
000072bd77dd955c  push r10
000072bd77dd955e  push r11
000072bd77dd9560  sub rsp, 0xF0
000072bd77dd9567  vmovaps [rsp], xmm0
000072bd77dd956c  vmovaps [rsp+0x10], xmm1
000072bd77dd9572  vmovaps [rsp+0x20], xmm2
000072bd77dd9578  vmovaps [rsp+0x30], xmm3
000072bd77dd957e  vmovaps [rsp+0x40], xmm4
000072bd77dd9584  vmovaps [rsp+0x50], xmm5
000072bd77dd958a  vmovaps [rsp+0x60], xmm6
000072bd77dd9590  vmovaps [rsp+0x70], xmm7
000072bd77dd9596  vmovaps [rsp+0x80], xmm8
000072bd77dd959f  vmovaps [rsp+0x90], xmm9
000072bd77dd95a8  vmovaps [rsp+0xA0], xmm10
000072bd77dd95b1  vmovaps [rsp+0xB0], xmm11
000072bd77dd95ba  vmovaps [rsp+0xC0], xmm12
000072bd77dd95c3  vmovaps [rsp+0xD0], xmm13
000072bd77dd95cc  vmovaps [rsp+0xE0], xmm15
000072bd77dd95d5  sub rsp, 0x30
000072bd77dd95d9  movaps [rsp], xmm14
000072bd77dd95de  movaps [rsp+0x10], xmm8
000072bd77dd95e4  movaps [rsp+0x20], xmm4
000072bd77dd95e9  lea rdi, [rsp]
000072bd77dd95ed  mov esi, 0x00
000072bd77dd95f2  mov rax, 0x643206AC3530
000072bd77dd95fc  call rax
000072bd77dd95fe  movaps xmm14, [rsp]
000072bd77dd9603  add rsp, 0x30
000072bd77dd9607  vmovaps xmm0, [rsp]
000072bd77dd960c  vmovaps xmm1, [rsp+0x10]
000072bd77dd9612  vmovaps xmm2, [rsp+0x20]
000072bd77dd9618  vmovaps xmm3, [rsp+0x30]
000072bd77dd961e  vmovaps xmm4, [rsp+0x40]
000072bd77dd9624  vmovaps xmm5, [rsp+0x50]
000072bd77dd962a  vmovaps xmm6, [rsp+0x60]
000072bd77dd9630  vmovaps xmm7, [rsp+0x70]
000072bd77dd9636  vmovaps xmm8, [rsp+0x80]
000072bd77dd963f  vmovaps xmm9, [rsp+0x90]
000072bd77dd9648  vmovaps xmm10, [rsp+0xA0]
000072bd77dd9651  vmovaps xmm11, [rsp+0xB0]
000072bd77dd965a  vmovaps xmm12, [rsp+0xC0]
000072bd77dd9663  vmovaps xmm13, [rsp+0xD0]
000072bd77dd966c  vmovaps xmm15, [rsp+0xE0]
000072bd77dd9675  add rsp, 0xF0
000072bd77dd967c  pop r11
000072bd77dd967e  pop r10
000072bd77dd9680  pop r9
000072bd77dd9682  pop r8
000072bd77dd9684  pop rsi
000072bd77dd9685  pop rdi
000072bd77dd9686  pop rdx
000072bd77dd9687  pop rcx
000072bd77dd9688  pop rax
000072bd77dd9689  add rsp, 0x08
000072bd77dd968d  jmp 0x000072BD77DD6265
000072bd77dd9692  sub rsp, 0x08
000072bd77dd9696  push rax
000072bd77dd9697  push rcx
000072bd77dd9698  push rdx
000072bd77dd9699  push rdi
000072bd77dd969a  push rsi
000072bd77dd969b  push r8
000072bd77dd969d  push r9
000072bd77dd969f  push r10
000072bd77dd96a1  push r11
000072bd77dd96a3  sub rsp, 0xF0
000072bd77dd96aa  vmovaps [rsp], xmm0
000072bd77dd96af  vmovaps [rsp+0x10], xmm1
000072bd77dd96b5  vmovaps [rsp+0x20], xmm2
000072bd77dd96bb  vmovaps [rsp+0x30], xmm3
000072bd77dd96c1  vmovaps [rsp+0x40], xmm5
000072bd77dd96c7  vmovaps [rsp+0x50], xmm6
000072bd77dd96cd  vmovaps [rsp+0x60], xmm7
000072bd77dd96d3  vmovaps [rsp+0x70], xmm8
000072bd77dd96d9  vmovaps [rsp+0x80], xmm9
000072bd77dd96e2  vmovaps [rsp+0x90], xmm10
000072bd77dd96eb  vmovaps [rsp+0xA0], xmm11
000072bd77dd96f4  vmovaps [rsp+0xB0], xmm12
000072bd77dd96fd  vmovaps [rsp+0xC0], xmm13
000072bd77dd9706  vmovaps [rsp+0xD0], xmm14
000072bd77dd970f  vmovaps [rsp+0xE0], xmm15
000072bd77dd9718  sub rsp, 0x30
000072bd77dd971c  movaps [rsp], xmm4
000072bd77dd9720  movaps [rsp+0x10], xmm13
000072bd77dd9726  movaps [rsp+0x20], xmm8
000072bd77dd972c  lea rdi, [rsp]
000072bd77dd9730  mov esi, 0x00
000072bd77dd9735  mov rax, 0x643206AC3530
000072bd77dd973f  call rax
000072bd77dd9741  movaps xmm4, [rsp]
000072bd77dd9745  add rsp, 0x30
000072bd77dd9749  vmovaps xmm0, [rsp]
000072bd77dd974e  vmovaps xmm1, [rsp+0x10]
000072bd77dd9754  vmovaps xmm2, [rsp+0x20]
000072bd77dd975a  vmovaps xmm3, [rsp+0x30]
000072bd77dd9760  vmovaps xmm5, [rsp+0x40]
000072bd77dd9766  vmovaps xmm6, [rsp+0x50]
000072bd77dd976c  vmovaps xmm7, [rsp+0x60]
000072bd77dd9772  vmovaps xmm8, [rsp+0x70]
000072bd77dd9778  vmovaps xmm9, [rsp+0x80]
000072bd77dd9781  vmovaps xmm10, [rsp+0x90]
000072bd77dd978a  vmovaps xmm11, [rsp+0xA0]
000072bd77dd9793  vmovaps xmm12, [rsp+0xB0]
000072bd77dd979c  vmovaps xmm13, [rsp+0xC0]
000072bd77dd97a5  vmovaps xmm14, [rsp+0xD0]
000072bd77dd97ae  vmovaps xmm15, [rsp+0xE0]
000072bd77dd97b7  add rsp, 0xF0
000072bd77dd97be  pop r11
000072bd77dd97c0  pop r10
000072bd77dd97c2  pop r9
000072bd77dd97c4  pop r8
000072bd77dd97c6  pop rsi
000072bd77dd97c7  pop rdi
000072bd77dd97c8  pop rdx
000072bd77dd97c9  pop rcx
000072bd77dd97ca  pop rax
000072bd77dd97cb  add rsp, 0x08
000072bd77dd97cf  jmp 0x000072BD77DD628A
000072bd77dd97d4  sub rsp, 0x08
000072bd77dd97d8  push rax
000072bd77dd97d9  push rcx
000072bd77dd97da  push rdx
000072bd77dd97db  push rdi
000072bd77dd97dc  push rsi
000072bd77dd97dd  push r8
000072bd77dd97df  push r9
000072bd77dd97e1  push r10
000072bd77dd97e3  push r11
000072bd77dd97e5  sub rsp, 0xF0
000072bd77dd97ec  vmovaps [rsp], xmm0
000072bd77dd97f1  vmovaps [rsp+0x10], xmm1
000072bd77dd97f7  vmovaps [rsp+0x20], xmm2
000072bd77dd97fd  vmovaps [rsp+0x30], xmm3
000072bd77dd9803  vmovaps [rsp+0x40], xmm4
000072bd77dd9809  vmovaps [rsp+0x50], xmm5
000072bd77dd980f  vmovaps [rsp+0x60], xmm6
000072bd77dd9815  vmovaps [rsp+0x70], xmm7
000072bd77dd981b  vmovaps [rsp+0x80], xmm8
000072bd77dd9824  vmovaps [rsp+0x90], xmm9
000072bd77dd982d  vmovaps [rsp+0xA0], xmm10
000072bd77dd9836  vmovaps [rsp+0xB0], xmm11
000072bd77dd983f  vmovaps [rsp+0xC0], xmm12
000072bd77dd9848  vmovaps [rsp+0xD0], xmm14
000072bd77dd9851  vmovaps [rsp+0xE0], xmm15
000072bd77dd985a  sub rsp, 0x30
000072bd77dd985e  movaps [rsp], xmm13
000072bd77dd9863  movaps [rsp+0x10], xmm15
000072bd77dd9869  movaps [rsp+0x20], xmm9
000072bd77dd986f  lea rdi, [rsp]
000072bd77dd9873  mov esi, 0x00
000072bd77dd9878  mov rax, 0x643206AC3530
000072bd77dd9882  call rax
000072bd77dd9884  movaps xmm13, [rsp]
000072bd77dd9889  add rsp, 0x30
000072bd77dd988d  vmovaps xmm0, [rsp]
000072bd77dd9892  vmovaps xmm1, [rsp+0x10]
000072bd77dd9898  vmovaps xmm2, [rsp+0x20]
000072bd77dd989e  vmovaps xmm3, [rsp+0x30]
000072bd77dd98a4  vmovaps xmm4, [rsp+0x40]
000072bd77dd98aa  vmovaps xmm5, [rsp+0x50]
000072bd77dd98b0  vmovaps xmm6, [rsp+0x60]
000072bd77dd98b6  vmovaps xmm7, [rsp+0x70]
000072bd77dd98bc  vmovaps xmm8, [rsp+0x80]
000072bd77dd98c5  vmovaps xmm9, [rsp+0x90]
000072bd77dd98ce  vmovaps xmm10, [rsp+0xA0]
000072bd77dd98d7  vmovaps xmm11, [rsp+0xB0]
000072bd77dd98e0  vmovaps xmm12, [rsp+0xC0]
000072bd77dd98e9  vmovaps xmm14, [rsp+0xD0]
000072bd77dd98f2  vmovaps xmm15, [rsp+0xE0]
000072bd77dd98fb  add rsp, 0xF0
000072bd77dd9902  pop r11
000072bd77dd9904  pop r10
000072bd77dd9906  pop r9
000072bd77dd9908  pop r8
000072bd77dd990a  pop rsi
000072bd77dd990b  pop rdi
000072bd77dd990c  pop rdx
000072bd77dd990d  pop rcx
000072bd77dd990e  pop rax
000072bd77dd990f  add rsp, 0x08
000072bd77dd9913  jmp 0x000072BD77DD62A5
000072bd77dd9918  sub rsp, 0x08
000072bd77dd991c  push rax
000072bd77dd991d  push rcx
000072bd77dd991e  push rdx
000072bd77dd991f  push rdi
000072bd77dd9920  push rsi
000072bd77dd9921  push r8
000072bd77dd9923  push r9
000072bd77dd9925  push r10
000072bd77dd9927  push r11
000072bd77dd9929  sub rsp, 0xF0
000072bd77dd9930  vmovaps [rsp], xmm0
000072bd77dd9935  vmovaps [rsp+0x10], xmm1
000072bd77dd993b  vmovaps [rsp+0x20], xmm2
000072bd77dd9941  vmovaps [rsp+0x30], xmm3
000072bd77dd9947  vmovaps [rsp+0x40], xmm4
000072bd77dd994d  vmovaps [rsp+0x50], xmm5
000072bd77dd9953  vmovaps [rsp+0x60], xmm6
000072bd77dd9959  vmovaps [rsp+0x70], xmm7
000072bd77dd995f  vmovaps [rsp+0x80], xmm8
000072bd77dd9968  vmovaps [rsp+0x90], xmm9
000072bd77dd9971  vmovaps [rsp+0xA0], xmm10
000072bd77dd997a  vmovaps [rsp+0xB0], xmm11
000072bd77dd9983  vmovaps [rsp+0xC0], xmm12
000072bd77dd998c  vmovaps [rsp+0xD0], xmm13
000072bd77dd9995  vmovaps [rsp+0xE0], xmm14
000072bd77dd999e  sub rsp, 0x30
000072bd77dd99a2  movaps [rsp], xmm15
000072bd77dd99a7  movaps [rsp+0x10], xmm1
000072bd77dd99ac  movaps [rsp+0x20], xmm5
000072bd77dd99b1  lea rdi, [rsp]
000072bd77dd99b5  mov esi, 0x00
000072bd77dd99ba  mov rax, 0x643206AC3530
000072bd77dd99c4  call rax
000072bd77dd99c6  movaps xmm15, [rsp]
000072bd77dd99cb  add rsp, 0x30
000072bd77dd99cf  vmovaps xmm0, [rsp]
000072bd77dd99d4  vmovaps xmm1, [rsp+0x10]
000072bd77dd99da  vmovaps xmm2, [rsp+0x20]
000072bd77dd99e0  vmovaps xmm3, [rsp+0x30]
000072bd77dd99e6  vmovaps xmm4, [rsp+0x40]
000072bd77dd99ec  vmovaps xmm5, [rsp+0x50]
000072bd77dd99f2  vmovaps xmm6, [rsp+0x60]
000072bd77dd99f8  vmovaps xmm7, [rsp+0x70]
000072bd77dd99fe  vmovaps xmm8, [rsp+0x80]
000072bd77dd9a07  vmovaps xmm9, [rsp+0x90]
000072bd77dd9a10  vmovaps xmm10, [rsp+0xA0]
000072bd77dd9a19  vmovaps xmm11, [rsp+0xB0]
000072bd77dd9a22  vmovaps xmm12, [rsp+0xC0]
000072bd77dd9a2b  vmovaps xmm13, [rsp+0xD0]
000072bd77dd9a34  vmovaps xmm14, [rsp+0xE0]
000072bd77dd9a3d  add rsp, 0xF0
000072bd77dd9a44  pop r11
000072bd77dd9a46  pop r10
000072bd77dd9a48  pop r9
000072bd77dd9a4a  pop r8
000072bd77dd9a4c  pop rsi
000072bd77dd9a4d  pop rdi
000072bd77dd9a4e  pop rdx
000072bd77dd9a4f  pop rcx
000072bd77dd9a50  pop rax
000072bd77dd9a51  add rsp, 0x08
000072bd77dd9a55  jmp 0x000072BD77DD62C0
000072bd77dd9a5a  call 0x000072BD77CD64F0
000072bd77dd9a5f  jmp 0x000072BD77DD631B
000072bd77dd9a64  sub rsp, 0x08
000072bd77dd9a68  push rax
000072bd77dd9a69  push rcx
000072bd77dd9a6a  push rdx
000072bd77dd9a6b  push rdi
000072bd77dd9a6c  push rsi
000072bd77dd9a6d  push r8
000072bd77dd9a6f  push r9
000072bd77dd9a71  push r10
000072bd77dd9a73  push r11
000072bd77dd9a75  sub rsp, 0xF0
000072bd77dd9a7c  vmovaps [rsp], xmm0
000072bd77dd9a81  vmovaps [rsp+0x10], xmm1
000072bd77dd9a87  vmovaps [rsp+0x20], xmm2
000072bd77dd9a8d  vmovaps [rsp+0x30], xmm3
000072bd77dd9a93  vmovaps [rsp+0x40], xmm4
000072bd77dd9a99  vmovaps [rsp+0x50], xmm5
000072bd77dd9a9f  vmovaps [rsp+0x60], xmm6
000072bd77dd9aa5  vmovaps [rsp+0x70], xmm7
000072bd77dd9aab  vmovaps [rsp+0x80], xmm8
000072bd77dd9ab4  vmovaps [rsp+0x90], xmm10
000072bd77dd9abd  vmovaps [rsp+0xA0], xmm11
000072bd77dd9ac6  vmovaps [rsp+0xB0], xmm12
000072bd77dd9acf  vmovaps [rsp+0xC0], xmm13
000072bd77dd9ad8  vmovaps [rsp+0xD0], xmm14
000072bd77dd9ae1  vmovaps [rsp+0xE0], xmm15
000072bd77dd9aea  sub rsp, 0x30
000072bd77dd9aee  movaps [rsp], xmm9
000072bd77dd9af3  movaps [rsp+0x10], xmm8
000072bd77dd9af9  movaps [rsp+0x20], xmm11
000072bd77dd9aff  lea rdi, [rsp]
000072bd77dd9b03  mov esi, 0x00
000072bd77dd9b08  mov rax, 0x643206AC3530
000072bd77dd9b12  call rax
000072bd77dd9b14  movaps xmm9, [rsp]
000072bd77dd9b19  add rsp, 0x30
000072bd77dd9b1d  vmovaps xmm0, [rsp]
000072bd77dd9b22  vmovaps xmm1, [rsp+0x10]
000072bd77dd9b28  vmovaps xmm2, [rsp+0x20]
000072bd77dd9b2e  vmovaps xmm3, [rsp+0x30]
000072bd77dd9b34  vmovaps xmm4, [rsp+0x40]
000072bd77dd9b3a  vmovaps xmm5, [rsp+0x50]
000072bd77dd9b40  vmovaps xmm6, [rsp+0x60]
000072bd77dd9b46  vmovaps xmm7, [rsp+0x70]
000072bd77dd9b4c  vmovaps xmm8, [rsp+0x80]
000072bd77dd9b55  vmovaps xmm10, [rsp+0x90]
000072bd77dd9b5e  vmovaps xmm11, [rsp+0xA0]
000072bd77dd9b67  vmovaps xmm12, [rsp+0xB0]
000072bd77dd9b70  vmovaps xmm13, [rsp+0xC0]
000072bd77dd9b79  vmovaps xmm14, [rsp+0xD0]
000072bd77dd9b82  vmovaps xmm15, [rsp+0xE0]
000072bd77dd9b8b  add rsp, 0xF0
000072bd77dd9b92  pop r11
000072bd77dd9b94  pop r10
000072bd77dd9b96  pop r9
000072bd77dd9b98  pop r8
000072bd77dd9b9a  pop rsi
000072bd77dd9b9b  pop rdi
000072bd77dd9b9c  pop rdx
000072bd77dd9b9d  pop rcx
000072bd77dd9b9e  pop rax
000072bd77dd9b9f  add rsp, 0x08
000072bd77dd9ba3  jmp 0x000072BD77DD6352
000072bd77dd9ba8  sub rsp, 0x08
000072bd77dd9bac  push rax
000072bd77dd9bad  push rcx
000072bd77dd9bae  push rdx
000072bd77dd9baf  push rdi
000072bd77dd9bb0  push rsi
000072bd77dd9bb1  push r8
000072bd77dd9bb3  push r9
000072bd77dd9bb5  push r10
000072bd77dd9bb7  push r11
000072bd77dd9bb9  sub rsp, 0xF0
000072bd77dd9bc0  vmovaps [rsp], xmm0
000072bd77dd9bc5  vmovaps [rsp+0x10], xmm1
000072bd77dd9bcb  vmovaps [rsp+0x20], xmm2
000072bd77dd9bd1  vmovaps [rsp+0x30], xmm3
000072bd77dd9bd7  vmovaps [rsp+0x40], xmm4
000072bd77dd9bdd  vmovaps [rsp+0x50], xmm5
000072bd77dd9be3  vmovaps [rsp+0x60], xmm6
000072bd77dd9be9  vmovaps [rsp+0x70], xmm7
000072bd77dd9bef  vmovaps [rsp+0x80], xmm8
000072bd77dd9bf8  vmovaps [rsp+0x90], xmm9
000072bd77dd9c01  vmovaps [rsp+0xA0], xmm10
000072bd77dd9c0a  vmovaps [rsp+0xB0], xmm12
000072bd77dd9c13  vmovaps [rsp+0xC0], xmm13
000072bd77dd9c1c  vmovaps [rsp+0xD0], xmm14
000072bd77dd9c25  vmovaps [rsp+0xE0], xmm15
000072bd77dd9c2e  sub rsp, 0x30
000072bd77dd9c32  movaps [rsp], xmm11
000072bd77dd9c37  movaps [rsp+0x10], xmm10
000072bd77dd9c3d  movaps [rsp+0x20], xmm6
000072bd77dd9c42  lea rdi, [rsp]
000072bd77dd9c46  mov esi, 0x00
000072bd77dd9c4b  mov rax, 0x643206AC3530
000072bd77dd9c55  call rax
000072bd77dd9c57  movaps xmm11, [rsp]
000072bd77dd9c5c  add rsp, 0x30
000072bd77dd9c60  vmovaps xmm0, [rsp]
000072bd77dd9c65  vmovaps xmm1, [rsp+0x10]
000072bd77dd9c6b  vmovaps xmm2, [rsp+0x20]
000072bd77dd9c71  vmovaps xmm3, [rsp+0x30]
000072bd77dd9c77  vmovaps xmm4, [rsp+0x40]
000072bd77dd9c7d  vmovaps xmm5, [rsp+0x50]
000072bd77dd9c83  vmovaps xmm6, [rsp+0x60]
000072bd77dd9c89  vmovaps xmm7, [rsp+0x70]
000072bd77dd9c8f  vmovaps xmm8, [rsp+0x80]
000072bd77dd9c98  vmovaps xmm9, [rsp+0x90]
000072bd77dd9ca1  vmovaps xmm10, [rsp+0xA0]
000072bd77dd9caa  vmovaps xmm12, [rsp+0xB0]
000072bd77dd9cb3  vmovaps xmm13, [rsp+0xC0]
000072bd77dd9cbc  vmovaps xmm14, [rsp+0xD0]
000072bd77dd9cc5  vmovaps xmm15, [rsp+0xE0]
000072bd77dd9cce  add rsp, 0xF0
000072bd77dd9cd5  pop r11
000072bd77dd9cd7  pop r10
000072bd77dd9cd9  pop r9
000072bd77dd9cdb  pop r8
000072bd77dd9cdd  pop rsi
000072bd77dd9cde  pop rdi
000072bd77dd9cdf  pop rdx
000072bd77dd9ce0  pop rcx
000072bd77dd9ce1  pop rax
000072bd77dd9ce2  add rsp, 0x08
000072bd77dd9ce6  jmp 0x000072BD77DD636D
000072bd77dd9ceb  sub rsp, 0x08
000072bd77dd9cef  push rax
000072bd77dd9cf0  push rcx
000072bd77dd9cf1  push rdx
000072bd77dd9cf2  push rdi
000072bd77dd9cf3  push rsi
000072bd77dd9cf4  push r8
000072bd77dd9cf6  push r9
000072bd77dd9cf8  push r10
000072bd77dd9cfa  push r11
000072bd77dd9cfc  sub rsp, 0xF0
000072bd77dd9d03  vmovaps [rsp], xmm0
000072bd77dd9d08  vmovaps [rsp+0x10], xmm1
000072bd77dd9d0e  vmovaps [rsp+0x20], xmm2
000072bd77dd9d14  vmovaps [rsp+0x30], xmm3
000072bd77dd9d1a  vmovaps [rsp+0x40], xmm4
000072bd77dd9d20  vmovaps [rsp+0x50], xmm5
000072bd77dd9d26  vmovaps [rsp+0x60], xmm6
000072bd77dd9d2c  vmovaps [rsp+0x70], xmm7
000072bd77dd9d32  vmovaps [rsp+0x80], xmm8
000072bd77dd9d3b  vmovaps [rsp+0x90], xmm9
000072bd77dd9d44  vmovaps [rsp+0xA0], xmm11
000072bd77dd9d4d  vmovaps [rsp+0xB0], xmm12
000072bd77dd9d56  vmovaps [rsp+0xC0], xmm13
000072bd77dd9d5f  vmovaps [rsp+0xD0], xmm14
000072bd77dd9d68  vmovaps [rsp+0xE0], xmm15
000072bd77dd9d71  sub rsp, 0x30
000072bd77dd9d75  movaps [rsp], xmm10
000072bd77dd9d7a  movaps [rsp+0x10], xmm14
000072bd77dd9d80  movaps [rsp+0x20], xmm4
000072bd77dd9d85  lea rdi, [rsp]
000072bd77dd9d89  mov esi, 0x00
000072bd77dd9d8e  mov rax, 0x643206AC3530
000072bd77dd9d98  call rax
000072bd77dd9d9a  movaps xmm10, [rsp]
000072bd77dd9d9f  add rsp, 0x30
000072bd77dd9da3  vmovaps xmm0, [rsp]
000072bd77dd9da8  vmovaps xmm1, [rsp+0x10]
000072bd77dd9dae  vmovaps xmm2, [rsp+0x20]
000072bd77dd9db4  vmovaps xmm3, [rsp+0x30]
000072bd77dd9dba  vmovaps xmm4, [rsp+0x40]
000072bd77dd9dc0  vmovaps xmm5, [rsp+0x50]
000072bd77dd9dc6  vmovaps xmm6, [rsp+0x60]
000072bd77dd9dcc  vmovaps xmm7, [rsp+0x70]
000072bd77dd9dd2  vmovaps xmm8, [rsp+0x80]
000072bd77dd9ddb  vmovaps xmm9, [rsp+0x90]
000072bd77dd9de4  vmovaps xmm11, [rsp+0xA0]
000072bd77dd9ded  vmovaps xmm12, [rsp+0xB0]
000072bd77dd9df6  vmovaps xmm13, [rsp+0xC0]
000072bd77dd9dff  vmovaps xmm14, [rsp+0xD0]
000072bd77dd9e08  vmovaps xmm15, [rsp+0xE0]
000072bd77dd9e11  add rsp, 0xF0
000072bd77dd9e18  pop r11
000072bd77dd9e1a  pop r10
000072bd77dd9e1c  pop r9
000072bd77dd9e1e  pop r8
000072bd77dd9e20  pop rsi
000072bd77dd9e21  pop rdi
000072bd77dd9e22  pop rdx
000072bd77dd9e23  pop rcx
000072bd77dd9e24  pop rax
000072bd77dd9e25  add rsp, 0x08
000072bd77dd9e29  jmp 0x000072BD77DD6388
000072bd77dd9e2e  sub rsp, 0x08
000072bd77dd9e32  push rax
000072bd77dd9e33  push rcx
000072bd77dd9e34  push rdx
000072bd77dd9e35  push rdi
000072bd77dd9e36  push rsi
000072bd77dd9e37  push r8
000072bd77dd9e39  push r9
000072bd77dd9e3b  push r10
000072bd77dd9e3d  push r11
000072bd77dd9e3f  sub rsp, 0xF0
000072bd77dd9e46  vmovaps [rsp], xmm0
000072bd77dd9e4b  vmovaps [rsp+0x10], xmm1
000072bd77dd9e51  vmovaps [rsp+0x20], xmm2
000072bd77dd9e57  vmovaps [rsp+0x30], xmm3
000072bd77dd9e5d  vmovaps [rsp+0x40], xmm4
000072bd77dd9e63  vmovaps [rsp+0x50], xmm5
000072bd77dd9e69  vmovaps [rsp+0x60], xmm6
000072bd77dd9e6f  vmovaps [rsp+0x70], xmm7
000072bd77dd9e75  vmovaps [rsp+0x80], xmm9
000072bd77dd9e7e  vmovaps [rsp+0x90], xmm10
000072bd77dd9e87  vmovaps [rsp+0xA0], xmm11
000072bd77dd9e90  vmovaps [rsp+0xB0], xmm12
000072bd77dd9e99  vmovaps [rsp+0xC0], xmm13
000072bd77dd9ea2  vmovaps [rsp+0xD0], xmm14
000072bd77dd9eab  vmovaps [rsp+0xE0], xmm15
000072bd77dd9eb4  sub rsp, 0x30
000072bd77dd9eb8  movaps [rsp], xmm8
000072bd77dd9ebd  movaps [rsp+0x10], xmm1
000072bd77dd9ec2  movaps [rsp+0x20], xmm14
000072bd77dd9ec8  lea rdi, [rsp]
000072bd77dd9ecc  mov esi, 0x00
000072bd77dd9ed1  mov rax, 0x643206AC3530
000072bd77dd9edb  call rax
000072bd77dd9edd  movaps xmm8, [rsp]
000072bd77dd9ee2  add rsp, 0x30
000072bd77dd9ee6  vmovaps xmm0, [rsp]
000072bd77dd9eeb  vmovaps xmm1, [rsp+0x10]
000072bd77dd9ef1  vmovaps xmm2, [rsp+0x20]
000072bd77dd9ef7  vmovaps xmm3, [rsp+0x30]
000072bd77dd9efd  vmovaps xmm4, [rsp+0x40]
000072bd77dd9f03  vmovaps xmm5, [rsp+0x50]
000072bd77dd9f09  vmovaps xmm6, [rsp+0x60]
000072bd77dd9f0f  vmovaps xmm7, [rsp+0x70]
000072bd77dd9f15  vmovaps xmm9, [rsp+0x80]
000072bd77dd9f1e  vmovaps xmm10, [rsp+0x90]
000072bd77dd9f27  vmovaps xmm11, [rsp+0xA0]
000072bd77dd9f30  vmovaps xmm12, [rsp+0xB0]
000072bd77dd9f39  vmovaps xmm13, [rsp+0xC0]
000072bd77dd9f42  vmovaps xmm14, [rsp+0xD0]
000072bd77dd9f4b  vmovaps xmm15, [rsp+0xE0]
000072bd77dd9f54  add rsp, 0xF0
000072bd77dd9f5b  pop r11
000072bd77dd9f5d  pop r10
000072bd77dd9f5f  pop r9
000072bd77dd9f61  pop r8
000072bd77dd9f63  pop rsi
000072bd77dd9f64  pop rdi
000072bd77dd9f65  pop rdx
000072bd77dd9f66  pop rcx
000072bd77dd9f67  pop rax
000072bd77dd9f68  add rsp, 0x08
000072bd77dd9f6c  jmp 0x000072BD77DD63AE
000072bd77dd9f71  sub rsp, 0x08
000072bd77dd9f75  push rax
000072bd77dd9f76  push rcx
000072bd77dd9f77  push rdx
000072bd77dd9f78  push rdi
000072bd77dd9f79  push rsi
000072bd77dd9f7a  push r8
000072bd77dd9f7c  push r9
000072bd77dd9f7e  push r10
000072bd77dd9f80  push r11
000072bd77dd9f82  sub rsp, 0xF0
000072bd77dd9f89  vmovaps [rsp], xmm0
000072bd77dd9f8e  vmovaps [rsp+0x10], xmm1
000072bd77dd9f94  vmovaps [rsp+0x20], xmm2
000072bd77dd9f9a  vmovaps [rsp+0x30], xmm3
000072bd77dd9fa0  vmovaps [rsp+0x40], xmm4
000072bd77dd9fa6  vmovaps [rsp+0x50], xmm5
000072bd77dd9fac  vmovaps [rsp+0x60], xmm7
000072bd77dd9fb2  vmovaps [rsp+0x70], xmm8
000072bd77dd9fb8  vmovaps [rsp+0x80], xmm9
000072bd77dd9fc1  vmovaps [rsp+0x90], xmm10
000072bd77dd9fca  vmovaps [rsp+0xA0], xmm11
000072bd77dd9fd3  vmovaps [rsp+0xB0], xmm12
000072bd77dd9fdc  vmovaps [rsp+0xC0], xmm13
000072bd77dd9fe5  vmovaps [rsp+0xD0], xmm14
000072bd77dd9fee  vmovaps [rsp+0xE0], xmm15
000072bd77dd9ff7  sub rsp, 0x30
000072bd77dd9ffb  movaps [rsp], xmm6
000072bd77dd9fff  movaps [rsp+0x10], xmm1
000072bd77dda004  movaps [rsp+0x20], xmm14
000072bd77dda00a  lea rdi, [rsp]
000072bd77dda00e  mov esi, 0x00
000072bd77dda013  mov rax, 0x643206AC3530
000072bd77dda01d  call rax
000072bd77dda01f  movaps xmm6, [rsp]
000072bd77dda023  add rsp, 0x30
000072bd77dda027  vmovaps xmm0, [rsp]
000072bd77dda02c  vmovaps xmm1, [rsp+0x10]
000072bd77dda032  vmovaps xmm2, [rsp+0x20]
000072bd77dda038  vmovaps xmm3, [rsp+0x30]
000072bd77dda03e  vmovaps xmm4, [rsp+0x40]
000072bd77dda044  vmovaps xmm5, [rsp+0x50]
000072bd77dda04a  vmovaps xmm7, [rsp+0x60]
000072bd77dda050  vmovaps xmm8, [rsp+0x70]
000072bd77dda056  vmovaps xmm9, [rsp+0x80]
000072bd77dda05f  vmovaps xmm10, [rsp+0x90]
000072bd77dda068  vmovaps xmm11, [rsp+0xA0]
000072bd77dda071  vmovaps xmm12, [rsp+0xB0]
000072bd77dda07a  vmovaps xmm13, [rsp+0xC0]
000072bd77dda083  vmovaps xmm14, [rsp+0xD0]
000072bd77dda08c  vmovaps xmm15, [rsp+0xE0]
000072bd77dda095  add rsp, 0xF0
000072bd77dda09c  pop r11
000072bd77dda09e  pop r10
000072bd77dda0a0  pop r9
000072bd77dda0a2  pop r8
000072bd77dda0a4  pop rsi
000072bd77dda0a5  pop rdi
000072bd77dda0a6  pop rdx
000072bd77dda0a7  pop rcx
000072bd77dda0a8  pop rax
000072bd77dda0a9  add rsp, 0x08
000072bd77dda0ad  jmp 0x000072BD77DD63DA
000072bd77dda0b2  sub rsp, 0x08
000072bd77dda0b6  push rax
000072bd77dda0b7  push rcx
000072bd77dda0b8  push rdx
000072bd77dda0b9  push rdi
000072bd77dda0ba  push rsi
000072bd77dda0bb  push r8
000072bd77dda0bd  push r9
000072bd77dda0bf  push r10
000072bd77dda0c1  push r11
000072bd77dda0c3  sub rsp, 0xF0
000072bd77dda0ca  vmovaps [rsp], xmm0
000072bd77dda0cf  vmovaps [rsp+0x10], xmm1
000072bd77dda0d5  vmovaps [rsp+0x20], xmm2
000072bd77dda0db  vmovaps [rsp+0x30], xmm3
000072bd77dda0e1  vmovaps [rsp+0x40], xmm4
000072bd77dda0e7  vmovaps [rsp+0x50], xmm5
000072bd77dda0ed  vmovaps [rsp+0x60], xmm6
000072bd77dda0f3  vmovaps [rsp+0x70], xmm7
000072bd77dda0f9  vmovaps [rsp+0x80], xmm8
000072bd77dda102  vmovaps [rsp+0x90], xmm9
000072bd77dda10b  vmovaps [rsp+0xA0], xmm10
000072bd77dda114  vmovaps [rsp+0xB0], xmm11
000072bd77dda11d  vmovaps [rsp+0xC0], xmm12
000072bd77dda126  vmovaps [rsp+0xD0], xmm13
000072bd77dda12f  vmovaps [rsp+0xE0], xmm15
000072bd77dda138  sub rsp, 0x30
000072bd77dda13c  movaps [rsp], xmm14
000072bd77dda141  movaps [rsp+0x10], xmm12
000072bd77dda147  movaps [rsp+0x20], xmm1
000072bd77dda14c  lea rdi, [rsp]
000072bd77dda150  mov esi, 0x00
000072bd77dda155  mov rax, 0x643206AC3530
000072bd77dda15f  call rax
000072bd77dda161  movaps xmm14, [rsp]
000072bd77dda166  add rsp, 0x30
000072bd77dda16a  vmovaps xmm0, [rsp]
000072bd77dda16f  vmovaps xmm1, [rsp+0x10]
000072bd77dda175  vmovaps xmm2, [rsp+0x20]
000072bd77dda17b  vmovaps xmm3, [rsp+0x30]
000072bd77dda181  vmovaps xmm4, [rsp+0x40]
000072bd77dda187  vmovaps xmm5, [rsp+0x50]
000072bd77dda18d  vmovaps xmm6, [rsp+0x60]
000072bd77dda193  vmovaps xmm7, [rsp+0x70]
000072bd77dda199  vmovaps xmm8, [rsp+0x80]
000072bd77dda1a2  vmovaps xmm9, [rsp+0x90]
000072bd77dda1ab  vmovaps xmm10, [rsp+0xA0]
000072bd77dda1b4  vmovaps xmm11, [rsp+0xB0]
000072bd77dda1bd  vmovaps xmm12, [rsp+0xC0]
000072bd77dda1c6  vmovaps xmm13, [rsp+0xD0]
000072bd77dda1cf  vmovaps xmm15, [rsp+0xE0]
000072bd77dda1d8  add rsp, 0xF0
000072bd77dda1df  pop r11
000072bd77dda1e1  pop r10
000072bd77dda1e3  pop r9
000072bd77dda1e5  pop r8
000072bd77dda1e7  pop rsi
000072bd77dda1e8  pop rdi
000072bd77dda1e9  pop rdx
000072bd77dda1ea  pop rcx
000072bd77dda1eb  pop rax
000072bd77dda1ec  add rsp, 0x08
000072bd77dda1f0  jmp 0x000072BD77DD6400
000072bd77dda1f5  sub rsp, 0x08
000072bd77dda1f9  push rax
000072bd77dda1fa  push rcx
000072bd77dda1fb  push rdx
000072bd77dda1fc  push rdi
000072bd77dda1fd  push rsi
000072bd77dda1fe  push r8
000072bd77dda200  push r9
000072bd77dda202  push r10
000072bd77dda204  push r11
000072bd77dda206  sub rsp, 0xF0
000072bd77dda20d  vmovaps [rsp], xmm0
000072bd77dda212  vmovaps [rsp+0x10], xmm2
000072bd77dda218  vmovaps [rsp+0x20], xmm3
000072bd77dda21e  vmovaps [rsp+0x30], xmm4
000072bd77dda224  vmovaps [rsp+0x40], xmm5
000072bd77dda22a  vmovaps [rsp+0x50], xmm6
000072bd77dda230  vmovaps [rsp+0x60], xmm7
000072bd77dda236  vmovaps [rsp+0x70], xmm8
000072bd77dda23c  vmovaps [rsp+0x80], xmm9
000072bd77dda245  vmovaps [rsp+0x90], xmm10
000072bd77dda24e  vmovaps [rsp+0xA0], xmm11
000072bd77dda257  vmovaps [rsp+0xB0], xmm12
000072bd77dda260  vmovaps [rsp+0xC0], xmm13
000072bd77dda269  vmovaps [rsp+0xD0], xmm14
000072bd77dda272  vmovaps [rsp+0xE0], xmm15
000072bd77dda27b  sub rsp, 0x30
000072bd77dda27f  movaps [rsp], xmm1
000072bd77dda283  movaps [rsp+0x10], xmm13
000072bd77dda289  movaps [rsp+0x20], xmm9
000072bd77dda28f  lea rdi, [rsp]
000072bd77dda293  mov esi, 0x00
000072bd77dda298  mov rax, 0x643206AC3530
000072bd77dda2a2  call rax
000072bd77dda2a4  movaps xmm1, [rsp]
000072bd77dda2a8  add rsp, 0x30
000072bd77dda2ac  vmovaps xmm0, [rsp]
000072bd77dda2b1  vmovaps xmm2, [rsp+0x10]
000072bd77dda2b7  vmovaps xmm3, [rsp+0x20]
000072bd77dda2bd  vmovaps xmm4, [rsp+0x30]
000072bd77dda2c3  vmovaps xmm5, [rsp+0x40]
000072bd77dda2c9  vmovaps xmm6, [rsp+0x50]
000072bd77dda2cf  vmovaps xmm7, [rsp+0x60]
000072bd77dda2d5  vmovaps xmm8, [rsp+0x70]
000072bd77dda2db  vmovaps xmm9, [rsp+0x80]
000072bd77dda2e4  vmovaps xmm10, [rsp+0x90]
000072bd77dda2ed  vmovaps xmm11, [rsp+0xA0]
000072bd77dda2f6  vmovaps xmm12, [rsp+0xB0]
000072bd77dda2ff  vmovaps xmm13, [rsp+0xC0]
000072bd77dda308  vmovaps xmm14, [rsp+0xD0]
000072bd77dda311  vmovaps xmm15, [rsp+0xE0]
000072bd77dda31a  add rsp, 0xF0
000072bd77dda321  pop r11
000072bd77dda323  pop r10
000072bd77dda325  pop r9
000072bd77dda327  pop r8
000072bd77dda329  pop rsi
000072bd77dda32a  pop rdi
000072bd77dda32b  pop rdx
000072bd77dda32c  pop rcx
000072bd77dda32d  pop rax
000072bd77dda32e  add rsp, 0x08
000072bd77dda332  jmp 0x000072BD77DD641A
000072bd77dda337  sub rsp, 0x08
000072bd77dda33b  push rax
000072bd77dda33c  push rcx
000072bd77dda33d  push rdx
000072bd77dda33e  push rdi
000072bd77dda33f  push rsi
000072bd77dda340  push r8
000072bd77dda342  push r9
000072bd77dda344  push r10
000072bd77dda346  push r11
000072bd77dda348  sub rsp, 0xF0
000072bd77dda34f  vmovaps [rsp], xmm0
000072bd77dda354  vmovaps [rsp+0x10], xmm1
000072bd77dda35a  vmovaps [rsp+0x20], xmm2
000072bd77dda360  vmovaps [rsp+0x30], xmm3
000072bd77dda366  vmovaps [rsp+0x40], xmm4
000072bd77dda36c  vmovaps [rsp+0x50], xmm5
000072bd77dda372  vmovaps [rsp+0x60], xmm6
000072bd77dda378  vmovaps [rsp+0x70], xmm7
000072bd77dda37e  vmovaps [rsp+0x80], xmm8
000072bd77dda387  vmovaps [rsp+0x90], xmm9
000072bd77dda390  vmovaps [rsp+0xA0], xmm10
000072bd77dda399  vmovaps [rsp+0xB0], xmm11
000072bd77dda3a2  vmovaps [rsp+0xC0], xmm13
000072bd77dda3ab  vmovaps [rsp+0xD0], xmm14
000072bd77dda3b4  vmovaps [rsp+0xE0], xmm15
000072bd77dda3bd  sub rsp, 0x30
000072bd77dda3c1  movaps [rsp], xmm12
000072bd77dda3c6  movaps [rsp+0x10], xmm7
000072bd77dda3cb  movaps [rsp+0x20], xmm13
000072bd77dda3d1  lea rdi, [rsp]
000072bd77dda3d5  mov esi, 0x00
000072bd77dda3da  mov rax, 0x643206AC3530
000072bd77dda3e4  call rax
000072bd77dda3e6  movaps xmm12, [rsp]
000072bd77dda3eb  add rsp, 0x30
000072bd77dda3ef  vmovaps xmm0, [rsp]
000072bd77dda3f4  vmovaps xmm1, [rsp+0x10]
000072bd77dda3fa  vmovaps xmm2, [rsp+0x20]
000072bd77dda400  vmovaps xmm3, [rsp+0x30]
000072bd77dda406  vmovaps xmm4, [rsp+0x40]
000072bd77dda40c  vmovaps xmm5, [rsp+0x50]
000072bd77dda412  vmovaps xmm6, [rsp+0x60]
000072bd77dda418  vmovaps xmm7, [rsp+0x70]
000072bd77dda41e  vmovaps xmm8, [rsp+0x80]
000072bd77dda427  vmovaps xmm9, [rsp+0x90]
000072bd77dda430  vmovaps xmm10, [rsp+0xA0]
000072bd77dda439  vmovaps xmm11, [rsp+0xB0]
000072bd77dda442  vmovaps xmm13, [rsp+0xC0]
000072bd77dda44b  vmovaps xmm14, [rsp+0xD0]
000072bd77dda454  vmovaps xmm15, [rsp+0xE0]
000072bd77dda45d  add rsp, 0xF0
000072bd77dda464  pop r11
000072bd77dda466  pop r10
000072bd77dda468  pop r9
000072bd77dda46a  pop r8
000072bd77dda46c  pop rsi
000072bd77dda46d  pop rdi
000072bd77dda46e  pop rdx
000072bd77dda46f  pop rcx
000072bd77dda470  pop rax
000072bd77dda471  add rsp, 0x08
000072bd77dda475  jmp 0x000072BD77DD6441
000072bd77dda47a  sub rsp, 0x08
000072bd77dda47e  push rax
000072bd77dda47f  push rcx
000072bd77dda480  push rdx
000072bd77dda481  push rdi
000072bd77dda482  push rsi
000072bd77dda483  push r8
000072bd77dda485  push r9
000072bd77dda487  push r10
000072bd77dda489  push r11
000072bd77dda48b  sub rsp, 0xF0
000072bd77dda492  vmovaps [rsp], xmm0
000072bd77dda497  vmovaps [rsp+0x10], xmm1
000072bd77dda49d  vmovaps [rsp+0x20], xmm2
000072bd77dda4a3  vmovaps [rsp+0x30], xmm3
000072bd77dda4a9  vmovaps [rsp+0x40], xmm4
000072bd77dda4af  vmovaps [rsp+0x50], xmm5
000072bd77dda4b5  vmovaps [rsp+0x60], xmm6
000072bd77dda4bb  vmovaps [rsp+0x70], xmm7
000072bd77dda4c1  vmovaps [rsp+0x80], xmm8
000072bd77dda4ca  vmovaps [rsp+0x90], xmm9
000072bd77dda4d3  vmovaps [rsp+0xA0], xmm10
000072bd77dda4dc  vmovaps [rsp+0xB0], xmm11
000072bd77dda4e5  vmovaps [rsp+0xC0], xmm12
000072bd77dda4ee  vmovaps [rsp+0xD0], xmm14
000072bd77dda4f7  vmovaps [rsp+0xE0], xmm15
000072bd77dda500  sub rsp, 0x30
000072bd77dda504  movaps [rsp], xmm13
000072bd77dda509  movaps [rsp+0x10], xmm15
000072bd77dda50f  movaps [rsp+0x20], xmm8
000072bd77dda515  lea rdi, [rsp]
000072bd77dda519  mov esi, 0x00
000072bd77dda51e  mov rax, 0x643206AC3530
000072bd77dda528  call rax
000072bd77dda52a  movaps xmm13, [rsp]
000072bd77dda52f  add rsp, 0x30
000072bd77dda533  vmovaps xmm0, [rsp]
000072bd77dda538  vmovaps xmm1, [rsp+0x10]
000072bd77dda53e  vmovaps xmm2, [rsp+0x20]
000072bd77dda544  vmovaps xmm3, [rsp+0x30]
000072bd77dda54a  vmovaps xmm4, [rsp+0x40]
000072bd77dda550  vmovaps xmm5, [rsp+0x50]
000072bd77dda556  vmovaps xmm6, [rsp+0x60]
000072bd77dda55c  vmovaps xmm7, [rsp+0x70]
000072bd77dda562  vmovaps xmm8, [rsp+0x80]
000072bd77dda56b  vmovaps xmm9, [rsp+0x90]
000072bd77dda574  vmovaps xmm10, [rsp+0xA0]
000072bd77dda57d  vmovaps xmm11, [rsp+0xB0]
000072bd77dda586  vmovaps xmm12, [rsp+0xC0]
000072bd77dda58f  vmovaps xmm14, [rsp+0xD0]
000072bd77dda598  vmovaps xmm15, [rsp+0xE0]
000072bd77dda5a1  add rsp, 0xF0
000072bd77dda5a8  pop r11
000072bd77dda5aa  pop r10
000072bd77dda5ac  pop r9
000072bd77dda5ae  pop r8
000072bd77dda5b0  pop rsi
000072bd77dda5b1  pop rdi
000072bd77dda5b2  pop rdx
000072bd77dda5b3  pop rcx
000072bd77dda5b4  pop rax
000072bd77dda5b5  add rsp, 0x08
000072bd77dda5b9  jmp 0x000072BD77DD645C
000072bd77dda5be  sub rsp, 0x08
000072bd77dda5c2  push rax
000072bd77dda5c3  push rcx
000072bd77dda5c4  push rdx
000072bd77dda5c5  push rdi
000072bd77dda5c6  push rsi
000072bd77dda5c7  push r8
000072bd77dda5c9  push r9
000072bd77dda5cb  push r10
000072bd77dda5cd  push r11
000072bd77dda5cf  sub rsp, 0xF0
000072bd77dda5d6  vmovaps [rsp], xmm0
000072bd77dda5db  vmovaps [rsp+0x10], xmm1
000072bd77dda5e1  vmovaps [rsp+0x20], xmm2
000072bd77dda5e7  vmovaps [rsp+0x30], xmm3
000072bd77dda5ed  vmovaps [rsp+0x40], xmm4
000072bd77dda5f3  vmovaps [rsp+0x50], xmm5
000072bd77dda5f9  vmovaps [rsp+0x60], xmm6
000072bd77dda5ff  vmovaps [rsp+0x70], xmm7
000072bd77dda605  vmovaps [rsp+0x80], xmm9
000072bd77dda60e  vmovaps [rsp+0x90], xmm10
000072bd77dda617  vmovaps [rsp+0xA0], xmm11
000072bd77dda620  vmovaps [rsp+0xB0], xmm12
000072bd77dda629  vmovaps [rsp+0xC0], xmm13
000072bd77dda632  vmovaps [rsp+0xD0], xmm14
000072bd77dda63b  vmovaps [rsp+0xE0], xmm15
000072bd77dda644  sub rsp, 0x30
000072bd77dda648  movaps [rsp], xmm8
000072bd77dda64d  movaps [rsp+0x10], xmm15
000072bd77dda653  movaps [rsp+0x20], xmm9
000072bd77dda659  lea rdi, [rsp]
000072bd77dda65d  mov esi, 0x00
000072bd77dda662  mov rax, 0x643206AC3530
000072bd77dda66c  call rax
000072bd77dda66e  movaps xmm8, [rsp]
000072bd77dda673  add rsp, 0x30
000072bd77dda677  vmovaps xmm0, [rsp]
000072bd77dda67c  vmovaps xmm1, [rsp+0x10]
000072bd77dda682  vmovaps xmm2, [rsp+0x20]
000072bd77dda688  vmovaps xmm3, [rsp+0x30]
000072bd77dda68e  vmovaps xmm4, [rsp+0x40]
000072bd77dda694  vmovaps xmm5, [rsp+0x50]
000072bd77dda69a  vmovaps xmm6, [rsp+0x60]
000072bd77dda6a0  vmovaps xmm7, [rsp+0x70]
000072bd77dda6a6  vmovaps xmm9, [rsp+0x80]
000072bd77dda6af  vmovaps xmm10, [rsp+0x90]
000072bd77dda6b8  vmovaps xmm11, [rsp+0xA0]
000072bd77dda6c1  vmovaps xmm12, [rsp+0xB0]
000072bd77dda6ca  vmovaps xmm13, [rsp+0xC0]
000072bd77dda6d3  vmovaps xmm14, [rsp+0xD0]
000072bd77dda6dc  vmovaps xmm15, [rsp+0xE0]
000072bd77dda6e5  add rsp, 0xF0
000072bd77dda6ec  pop r11
000072bd77dda6ee  pop r10
000072bd77dda6f0  pop r9
000072bd77dda6f2  pop r8
000072bd77dda6f4  pop rsi
000072bd77dda6f5  pop rdi
000072bd77dda6f6  pop rdx
000072bd77dda6f7  pop rcx
000072bd77dda6f8  pop rax
000072bd77dda6f9  add rsp, 0x08
000072bd77dda6fd  jmp 0x000072BD77DD648A
000072bd77dda702  sub rsp, 0x08
000072bd77dda706  push rax
000072bd77dda707  push rcx
000072bd77dda708  push rdx
000072bd77dda709  push rdi
000072bd77dda70a  push rsi
000072bd77dda70b  push r8
000072bd77dda70d  push r9
000072bd77dda70f  push r10
000072bd77dda711  push r11
000072bd77dda713  sub rsp, 0xF0
000072bd77dda71a  vmovaps [rsp], xmm0
000072bd77dda71f  vmovaps [rsp+0x10], xmm1
000072bd77dda725  vmovaps [rsp+0x20], xmm2
000072bd77dda72b  vmovaps [rsp+0x30], xmm3
000072bd77dda731  vmovaps [rsp+0x40], xmm4
000072bd77dda737  vmovaps [rsp+0x50], xmm5
000072bd77dda73d  vmovaps [rsp+0x60], xmm6
000072bd77dda743  vmovaps [rsp+0x70], xmm7
000072bd77dda749  vmovaps [rsp+0x80], xmm8
000072bd77dda752  vmovaps [rsp+0x90], xmm9
000072bd77dda75b  vmovaps [rsp+0xA0], xmm10
000072bd77dda764  vmovaps [rsp+0xB0], xmm11
000072bd77dda76d  vmovaps [rsp+0xC0], xmm12
000072bd77dda776  vmovaps [rsp+0xD0], xmm13
000072bd77dda77f  vmovaps [rsp+0xE0], xmm14
000072bd77dda788  sub rsp, 0x30
000072bd77dda78c  movaps [rsp], xmm15
000072bd77dda791  movaps [rsp+0x10], xmm11
000072bd77dda797  movaps [rsp+0x20], xmm6
000072bd77dda79c  lea rdi, [rsp]
000072bd77dda7a0  mov esi, 0x00
000072bd77dda7a5  mov rax, 0x643206AC3530
000072bd77dda7af  call rax
000072bd77dda7b1  movaps xmm15, [rsp]
000072bd77dda7b6  add rsp, 0x30
000072bd77dda7ba  vmovaps xmm0, [rsp]
000072bd77dda7bf  vmovaps xmm1, [rsp+0x10]
000072bd77dda7c5  vmovaps xmm2, [rsp+0x20]
000072bd77dda7cb  vmovaps xmm3, [rsp+0x30]
000072bd77dda7d1  vmovaps xmm4, [rsp+0x40]
000072bd77dda7d7  vmovaps xmm5, [rsp+0x50]
000072bd77dda7dd  vmovaps xmm6, [rsp+0x60]
000072bd77dda7e3  vmovaps xmm7, [rsp+0x70]
000072bd77dda7e9  vmovaps xmm8, [rsp+0x80]
000072bd77dda7f2  vmovaps xmm9, [rsp+0x90]
000072bd77dda7fb  vmovaps xmm10, [rsp+0xA0]
000072bd77dda804  vmovaps xmm11, [rsp+0xB0]
000072bd77dda80d  vmovaps xmm12, [rsp+0xC0]
000072bd77dda816  vmovaps xmm13, [rsp+0xD0]
000072bd77dda81f  vmovaps xmm14, [rsp+0xE0]
000072bd77dda828  add rsp, 0xF0
000072bd77dda82f  pop r11
000072bd77dda831  pop r10
000072bd77dda833  pop r9
000072bd77dda835  pop r8
000072bd77dda837  pop rsi
000072bd77dda838  pop rdi
000072bd77dda839  pop rdx
000072bd77dda83a  pop rcx
000072bd77dda83b  pop rax
000072bd77dda83c  add rsp, 0x08
000072bd77dda840  jmp 0x000072BD77DD64A5
000072bd77dda845  sub rsp, 0x08
000072bd77dda849  push rax
000072bd77dda84a  push rcx
000072bd77dda84b  push rdx
000072bd77dda84c  push rdi
000072bd77dda84d  push rsi
000072bd77dda84e  push r8
000072bd77dda850  push r9
000072bd77dda852  push r10
000072bd77dda854  push r11
000072bd77dda856  sub rsp, 0xF0
000072bd77dda85d  vmovaps [rsp], xmm0
000072bd77dda862  vmovaps [rsp+0x10], xmm1
000072bd77dda868  vmovaps [rsp+0x20], xmm2
000072bd77dda86e  vmovaps [rsp+0x30], xmm3
000072bd77dda874  vmovaps [rsp+0x40], xmm4
000072bd77dda87a  vmovaps [rsp+0x50], xmm5
000072bd77dda880  vmovaps [rsp+0x60], xmm6
000072bd77dda886  vmovaps [rsp+0x70], xmm8
000072bd77dda88c  vmovaps [rsp+0x80], xmm9
000072bd77dda895  vmovaps [rsp+0x90], xmm10
000072bd77dda89e  vmovaps [rsp+0xA0], xmm11
000072bd77dda8a7  vmovaps [rsp+0xB0], xmm12
000072bd77dda8b0  vmovaps [rsp+0xC0], xmm13
000072bd77dda8b9  vmovaps [rsp+0xD0], xmm14
000072bd77dda8c2  vmovaps [rsp+0xE0], xmm15
000072bd77dda8cb  sub rsp, 0x30
000072bd77dda8cf  movaps [rsp], xmm7
000072bd77dda8d3  movaps [rsp+0x10], xmm11
000072bd77dda8d9  movaps [rsp+0x20], xmm9
000072bd77dda8df  lea rdi, [rsp]
000072bd77dda8e3  mov esi, 0x00
000072bd77dda8e8  mov rax, 0x643206AC3530
000072bd77dda8f2  call rax
000072bd77dda8f4  movaps xmm7, [rsp]
000072bd77dda8f8  add rsp, 0x30
000072bd77dda8fc  vmovaps xmm0, [rsp]
000072bd77dda901  vmovaps xmm1, [rsp+0x10]
000072bd77dda907  vmovaps xmm2, [rsp+0x20]
000072bd77dda90d  vmovaps xmm3, [rsp+0x30]
000072bd77dda913  vmovaps xmm4, [rsp+0x40]
000072bd77dda919  vmovaps xmm5, [rsp+0x50]
000072bd77dda91f  vmovaps xmm6, [rsp+0x60]
000072bd77dda925  vmovaps xmm8, [rsp+0x70]
000072bd77dda92b  vmovaps xmm9, [rsp+0x80]
000072bd77dda934  vmovaps xmm10, [rsp+0x90]
000072bd77dda93d  vmovaps xmm11, [rsp+0xA0]
000072bd77dda946  vmovaps xmm12, [rsp+0xB0]
000072bd77dda94f  vmovaps xmm13, [rsp+0xC0]
000072bd77dda958  vmovaps xmm14, [rsp+0xD0]
000072bd77dda961  vmovaps xmm15, [rsp+0xE0]
000072bd77dda96a  add rsp, 0xF0
000072bd77dda971  pop r11
000072bd77dda973  pop r10
000072bd77dda975  pop r9
000072bd77dda977  pop r8
000072bd77dda979  pop rsi
000072bd77dda97a  pop rdi
000072bd77dda97b  pop rdx
000072bd77dda97c  pop rcx
000072bd77dda97d  pop rax
000072bd77dda97e  add rsp, 0x08
000072bd77dda982  jmp 0x000072BD77DD64D2
000072bd77dda987  sub rsp, 0x08
000072bd77dda98b  push rax
000072bd77dda98c  push rcx
000072bd77dda98d  push rdx
000072bd77dda98e  push rdi
000072bd77dda98f  push rsi
000072bd77dda990  push r8
000072bd77dda992  push r9
000072bd77dda994  push r10
000072bd77dda996  push r11
000072bd77dda998  sub rsp, 0xF0
000072bd77dda99f  vmovaps [rsp], xmm0
000072bd77dda9a4  vmovaps [rsp+0x10], xmm1
000072bd77dda9aa  vmovaps [rsp+0x20], xmm2
000072bd77dda9b0  vmovaps [rsp+0x30], xmm3
000072bd77dda9b6  vmovaps [rsp+0x40], xmm4
000072bd77dda9bc  vmovaps [rsp+0x50], xmm5
000072bd77dda9c2  vmovaps [rsp+0x60], xmm6
000072bd77dda9c8  vmovaps [rsp+0x70], xmm7
000072bd77dda9ce  vmovaps [rsp+0x80], xmm8
000072bd77dda9d7  vmovaps [rsp+0x90], xmm9
000072bd77dda9e0  vmovaps [rsp+0xA0], xmm10
000072bd77dda9e9  vmovaps [rsp+0xB0], xmm12
000072bd77dda9f2  vmovaps [rsp+0xC0], xmm13
000072bd77dda9fb  vmovaps [rsp+0xD0], xmm14
000072bd77ddaa04  vmovaps [rsp+0xE0], xmm15
000072bd77ddaa0d  sub rsp, 0x30
000072bd77ddaa11  movaps [rsp], xmm11
000072bd77ddaa16  movaps [rsp+0x10], xmm10
000072bd77ddaa1c  movaps [rsp+0x20], xmm14
000072bd77ddaa22  lea rdi, [rsp]
000072bd77ddaa26  mov esi, 0x00
000072bd77ddaa2b  mov rax, 0x643206AC3530
000072bd77ddaa35  call rax
000072bd77ddaa37  movaps xmm11, [rsp]
000072bd77ddaa3c  add rsp, 0x30
000072bd77ddaa40  vmovaps xmm0, [rsp]
000072bd77ddaa45  vmovaps xmm1, [rsp+0x10]
000072bd77ddaa4b  vmovaps xmm2, [rsp+0x20]
000072bd77ddaa51  vmovaps xmm3, [rsp+0x30]
000072bd77ddaa57  vmovaps xmm4, [rsp+0x40]
000072bd77ddaa5d  vmovaps xmm5, [rsp+0x50]
000072bd77ddaa63  vmovaps xmm6, [rsp+0x60]
000072bd77ddaa69  vmovaps xmm7, [rsp+0x70]
000072bd77ddaa6f  vmovaps xmm8, [rsp+0x80]
000072bd77ddaa78  vmovaps xmm9, [rsp+0x90]
000072bd77ddaa81  vmovaps xmm10, [rsp+0xA0]
000072bd77ddaa8a  vmovaps xmm12, [rsp+0xB0]
000072bd77ddaa93  vmovaps xmm13, [rsp+0xC0]
000072bd77ddaa9c  vmovaps xmm14, [rsp+0xD0]
000072bd77ddaaa5  vmovaps xmm15, [rsp+0xE0]
000072bd77ddaaae  add rsp, 0xF0
000072bd77ddaab5  pop r11
000072bd77ddaab7  pop r10
000072bd77ddaab9  pop r9
000072bd77ddaabb  pop r8
000072bd77ddaabd  pop rsi
000072bd77ddaabe  pop rdi
000072bd77ddaabf  pop rdx
000072bd77ddaac0  pop rcx
000072bd77ddaac1  pop rax
000072bd77ddaac2  add rsp, 0x08
000072bd77ddaac6  jmp 0x000072BD77DD64ED
000072bd77ddaacb  call 0x000072BD77CE45A0
000072bd77ddaad0  jmp 0x000072BD77DD64F7
000072bd77ddaad5  sub rsp, 0x08
000072bd77ddaad9  push rax
000072bd77ddaada  push rcx
000072bd77ddaadb  push rdx
000072bd77ddaadc  push rdi
000072bd77ddaadd  push rsi
000072bd77ddaade  push r8
000072bd77ddaae0  push r9
000072bd77ddaae2  push r10
000072bd77ddaae4  push r11
000072bd77ddaae6  sub rsp, 0xF0
000072bd77ddaaed  vmovaps [rsp], xmm0
000072bd77ddaaf2  vmovaps [rsp+0x10], xmm1
000072bd77ddaaf8  vmovaps [rsp+0x20], xmm2
000072bd77ddaafe  vmovaps [rsp+0x30], xmm3
000072bd77ddab04  vmovaps [rsp+0x40], xmm4
000072bd77ddab0a  vmovaps [rsp+0x50], xmm5
000072bd77ddab10  vmovaps [rsp+0x60], xmm6
000072bd77ddab16  vmovaps [rsp+0x70], xmm7
000072bd77ddab1c  vmovaps [rsp+0x80], xmm8
000072bd77ddab25  vmovaps [rsp+0x90], xmm9
000072bd77ddab2e  vmovaps [rsp+0xA0], xmm11
000072bd77ddab37  vmovaps [rsp+0xB0], xmm12
000072bd77ddab40  vmovaps [rsp+0xC0], xmm13
000072bd77ddab49  vmovaps [rsp+0xD0], xmm14
000072bd77ddab52  vmovaps [rsp+0xE0], xmm15
000072bd77ddab5b  sub rsp, 0x30
000072bd77ddab5f  movaps [rsp], xmm10
000072bd77ddab64  movaps [rsp+0x10], xmm1
000072bd77ddab69  movaps [rsp+0x20], xmm12
000072bd77ddab6f  lea rdi, [rsp]
000072bd77ddab73  mov esi, 0x00
000072bd77ddab78  mov rax, 0x643206AC3530
000072bd77ddab82  call rax
000072bd77ddab84  movaps xmm10, [rsp]
000072bd77ddab89  add rsp, 0x30
000072bd77ddab8d  vmovaps xmm0, [rsp]
000072bd77ddab92  vmovaps xmm1, [rsp+0x10]
000072bd77ddab98  vmovaps xmm2, [rsp+0x20]
000072bd77ddab9e  vmovaps xmm3, [rsp+0x30]
000072bd77ddaba4  vmovaps xmm4, [rsp+0x40]
000072bd77ddabaa  vmovaps xmm5, [rsp+0x50]
000072bd77ddabb0  vmovaps xmm6, [rsp+0x60]
000072bd77ddabb6  vmovaps xmm7, [rsp+0x70]
000072bd77ddabbc  vmovaps xmm8, [rsp+0x80]
000072bd77ddabc5  vmovaps xmm9, [rsp+0x90]
000072bd77ddabce  vmovaps xmm11, [rsp+0xA0]
000072bd77ddabd7  vmovaps xmm12, [rsp+0xB0]
000072bd77ddabe0  vmovaps xmm13, [rsp+0xC0]
000072bd77ddabe9  vmovaps xmm14, [rsp+0xD0]
000072bd77ddabf2  vmovaps xmm15, [rsp+0xE0]
000072bd77ddabfb  add rsp, 0xF0
000072bd77ddac02  pop r11
000072bd77ddac04  pop r10
000072bd77ddac06  pop r9
000072bd77ddac08  pop r8
000072bd77ddac0a  pop rsi
000072bd77ddac0b  pop rdi
000072bd77ddac0c  pop rdx
000072bd77ddac0d  pop rcx
000072bd77ddac0e  pop rax
000072bd77ddac0f  add rsp, 0x08
000072bd77ddac13  jmp 0x000072BD77DD651A
000072bd77ddac18  sub rsp, 0x08
000072bd77ddac1c  push rax
000072bd77ddac1d  push rcx
000072bd77ddac1e  push rdx
000072bd77ddac1f  push rdi
000072bd77ddac20  push rsi
000072bd77ddac21  push r8
000072bd77ddac23  push r9
000072bd77ddac25  push r10
000072bd77ddac27  push r11
000072bd77ddac29  sub rsp, 0xF0
000072bd77ddac30  vmovaps [rsp], xmm0
000072bd77ddac35  vmovaps [rsp+0x10], xmm1
000072bd77ddac3b  vmovaps [rsp+0x20], xmm2
000072bd77ddac41  vmovaps [rsp+0x30], xmm3
000072bd77ddac47  vmovaps [rsp+0x40], xmm4
000072bd77ddac4d  vmovaps [rsp+0x50], xmm5
000072bd77ddac53  vmovaps [rsp+0x60], xmm6
000072bd77ddac59  vmovaps [rsp+0x70], xmm7
000072bd77ddac5f  vmovaps [rsp+0x80], xmm8
000072bd77ddac68  vmovaps [rsp+0x90], xmm9
000072bd77ddac71  vmovaps [rsp+0xA0], xmm10
000072bd77ddac7a  vmovaps [rsp+0xB0], xmm11
000072bd77ddac83  vmovaps [rsp+0xC0], xmm13
000072bd77ddac8c  vmovaps [rsp+0xD0], xmm14
000072bd77ddac95  vmovaps [rsp+0xE0], xmm15
000072bd77ddac9e  sub rsp, 0x30
000072bd77ddaca2  movaps [rsp], xmm12
000072bd77ddaca7  movaps [rsp+0x10], xmm14
000072bd77ddacad  movaps [rsp+0x20], xmm1
000072bd77ddacb2  lea rdi, [rsp]
000072bd77ddacb6  mov esi, 0x00
000072bd77ddacbb  mov rax, 0x643206AC3530
000072bd77ddacc5  call rax
000072bd77ddacc7  movaps xmm12, [rsp]
000072bd77ddaccc  add rsp, 0x30
000072bd77ddacd0  vmovaps xmm0, [rsp]
000072bd77ddacd5  vmovaps xmm1, [rsp+0x10]
000072bd77ddacdb  vmovaps xmm2, [rsp+0x20]
000072bd77ddace1  vmovaps xmm3, [rsp+0x30]
000072bd77ddace7  vmovaps xmm4, [rsp+0x40]
000072bd77ddaced  vmovaps xmm5, [rsp+0x50]
000072bd77ddacf3  vmovaps xmm6, [rsp+0x60]
000072bd77ddacf9  vmovaps xmm7, [rsp+0x70]
000072bd77ddacff  vmovaps xmm8, [rsp+0x80]
000072bd77ddad08  vmovaps xmm9, [rsp+0x90]
000072bd77ddad11  vmovaps xmm10, [rsp+0xA0]
000072bd77ddad1a  vmovaps xmm11, [rsp+0xB0]
000072bd77ddad23  vmovaps xmm13, [rsp+0xC0]
000072bd77ddad2c  vmovaps xmm14, [rsp+0xD0]
000072bd77ddad35  vmovaps xmm15, [rsp+0xE0]
000072bd77ddad3e  add rsp, 0xF0
000072bd77ddad45  pop r11
000072bd77ddad47  pop r10
000072bd77ddad49  pop r9
000072bd77ddad4b  pop r8
000072bd77ddad4d  pop rsi
000072bd77ddad4e  pop rdi
000072bd77ddad4f  pop rdx
000072bd77ddad50  pop rcx
000072bd77ddad51  pop rax
000072bd77ddad52  add rsp, 0x08
000072bd77ddad56  jmp 0x000072BD77DD6549
000072bd77ddad5b  sub rsp, 0x08
000072bd77ddad5f  push rax
000072bd77ddad60  push rcx
000072bd77ddad61  push rdx
000072bd77ddad62  push rdi
000072bd77ddad63  push rsi
000072bd77ddad64  push r8
000072bd77ddad66  push r9
000072bd77ddad68  push r10
000072bd77ddad6a  push r11
000072bd77ddad6c  sub rsp, 0xF0
000072bd77ddad73  vmovaps [rsp], xmm0
000072bd77ddad78  vmovaps [rsp+0x10], xmm1
000072bd77ddad7e  vmovaps [rsp+0x20], xmm2
000072bd77ddad84  vmovaps [rsp+0x30], xmm3
000072bd77ddad8a  vmovaps [rsp+0x40], xmm4
000072bd77ddad90  vmovaps [rsp+0x50], xmm5
000072bd77ddad96  vmovaps [rsp+0x60], xmm6
000072bd77ddad9c  vmovaps [rsp+0x70], xmm7
000072bd77ddada2  vmovaps [rsp+0x80], xmm8
000072bd77ddadab  vmovaps [rsp+0x90], xmm9
000072bd77ddadb4  vmovaps [rsp+0xA0], xmm10
000072bd77ddadbd  vmovaps [rsp+0xB0], xmm11
000072bd77ddadc6  vmovaps [rsp+0xC0], xmm12
000072bd77ddadcf  vmovaps [rsp+0xD0], xmm13
000072bd77ddadd8  vmovaps [rsp+0xE0], xmm15
000072bd77ddade1  sub rsp, 0x30
000072bd77ddade5  movaps [rsp], xmm14
000072bd77ddadea  movaps [rsp+0x10], xmm9
000072bd77ddadf0  movaps [rsp+0x20], xmm1
000072bd77ddadf5  lea rdi, [rsp]
000072bd77ddadf9  mov esi, 0x00
000072bd77ddadfe  mov rax, 0x643206AC3530
000072bd77ddae08  call rax
000072bd77ddae0a  movaps xmm14, [rsp]
000072bd77ddae0f  add rsp, 0x30
000072bd77ddae13  vmovaps xmm0, [rsp]
000072bd77ddae18  vmovaps xmm1, [rsp+0x10]
000072bd77ddae1e  vmovaps xmm2, [rsp+0x20]
000072bd77ddae24  vmovaps xmm3, [rsp+0x30]
000072bd77ddae2a  vmovaps xmm4, [rsp+0x40]
000072bd77ddae30  vmovaps xmm5, [rsp+0x50]
000072bd77ddae36  vmovaps xmm6, [rsp+0x60]
000072bd77ddae3c  vmovaps xmm7, [rsp+0x70]
000072bd77ddae42  vmovaps xmm8, [rsp+0x80]
000072bd77ddae4b  vmovaps xmm9, [rsp+0x90]
000072bd77ddae54  vmovaps xmm10, [rsp+0xA0]
000072bd77ddae5d  vmovaps xmm11, [rsp+0xB0]
000072bd77ddae66  vmovaps xmm12, [rsp+0xC0]
000072bd77ddae6f  vmovaps xmm13, [rsp+0xD0]
000072bd77ddae78  vmovaps xmm15, [rsp+0xE0]
000072bd77ddae81  add rsp, 0xF0
000072bd77ddae88  pop r11
000072bd77ddae8a  pop r10
000072bd77ddae8c  pop r9
000072bd77ddae8e  pop r8
000072bd77ddae90  pop rsi
000072bd77ddae91  pop rdi
000072bd77ddae92  pop rdx
000072bd77ddae93  pop rcx
000072bd77ddae94  pop rax
000072bd77ddae95  add rsp, 0x08
000072bd77ddae99  jmp 0x000072BD77DD6578
000072bd77ddae9e  sub rsp, 0x08
000072bd77ddaea2  push rax
000072bd77ddaea3  push rcx
000072bd77ddaea4  push rdx
000072bd77ddaea5  push rdi
000072bd77ddaea6  push rsi
000072bd77ddaea7  push r8
000072bd77ddaea9  push r9
000072bd77ddaeab  push r10
000072bd77ddaead  push r11
000072bd77ddaeaf  sub rsp, 0xF0
000072bd77ddaeb6  vmovaps [rsp], xmm0
000072bd77ddaebb  vmovaps [rsp+0x10], xmm2
000072bd77ddaec1  vmovaps [rsp+0x20], xmm3
000072bd77ddaec7  vmovaps [rsp+0x30], xmm4
000072bd77ddaecd  vmovaps [rsp+0x40], xmm5
000072bd77ddaed3  vmovaps [rsp+0x50], xmm6
000072bd77ddaed9  vmovaps [rsp+0x60], xmm7
000072bd77ddaedf  vmovaps [rsp+0x70], xmm8
000072bd77ddaee5  vmovaps [rsp+0x80], xmm9
000072bd77ddaeee  vmovaps [rsp+0x90], xmm10
000072bd77ddaef7  vmovaps [rsp+0xA0], xmm11
000072bd77ddaf00  vmovaps [rsp+0xB0], xmm12
000072bd77ddaf09  vmovaps [rsp+0xC0], xmm13
000072bd77ddaf12  vmovaps [rsp+0xD0], xmm14
000072bd77ddaf1b  vmovaps [rsp+0xE0], xmm15
000072bd77ddaf24  sub rsp, 0x30
000072bd77ddaf28  movaps [rsp], xmm1
000072bd77ddaf2c  movaps [rsp+0x10], xmm13
000072bd77ddaf32  movaps [rsp+0x20], xmm8
000072bd77ddaf38  lea rdi, [rsp]
000072bd77ddaf3c  mov esi, 0x00
000072bd77ddaf41  mov rax, 0x643206AC3530
000072bd77ddaf4b  call rax
000072bd77ddaf4d  movaps xmm1, [rsp]
000072bd77ddaf51  add rsp, 0x30
000072bd77ddaf55  vmovaps xmm0, [rsp]
000072bd77ddaf5a  vmovaps xmm2, [rsp+0x10]
000072bd77ddaf60  vmovaps xmm3, [rsp+0x20]
000072bd77ddaf66  vmovaps xmm4, [rsp+0x30]
000072bd77ddaf6c  vmovaps xmm5, [rsp+0x40]
000072bd77ddaf72  vmovaps xmm6, [rsp+0x50]
000072bd77ddaf78  vmovaps xmm7, [rsp+0x60]
000072bd77ddaf7e  vmovaps xmm8, [rsp+0x70]
000072bd77ddaf84  vmovaps xmm9, [rsp+0x80]
000072bd77ddaf8d  vmovaps xmm10, [rsp+0x90]
000072bd77ddaf96  vmovaps xmm11, [rsp+0xA0]
000072bd77ddaf9f  vmovaps xmm12, [rsp+0xB0]
000072bd77ddafa8  vmovaps xmm13, [rsp+0xC0]
000072bd77ddafb1  vmovaps xmm14, [rsp+0xD0]
000072bd77ddafba  vmovaps xmm15, [rsp+0xE0]
000072bd77ddafc3  add rsp, 0xF0
000072bd77ddafca  pop r11
000072bd77ddafcc  pop r10
000072bd77ddafce  pop r9
000072bd77ddafd0  pop r8
000072bd77ddafd2  pop rsi
000072bd77ddafd3  pop rdi
000072bd77ddafd4  pop rdx
000072bd77ddafd5  pop rcx
000072bd77ddafd6  pop rax
000072bd77ddafd7  add rsp, 0x08
000072bd77ddafdb  jmp 0x000072BD77DD659A
000072bd77ddafe0  call 0x000072BD77C0C260
000072bd77ddafe5  jmp 0x000072BD77DD65A8
000072bd77ddafea  call 0x000072BD77CDE950
000072bd77ddafef  jmp 0x000072BD77DD65B2
000072bd77ddaff4  sub rsp, 0x08
000072bd77ddaff8  push rax
000072bd77ddaff9  push rcx
000072bd77ddaffa  push rdx
000072bd77ddaffb  push rdi
000072bd77ddaffc  push rsi
000072bd77ddaffd  push r8
000072bd77ddafff  push r9
000072bd77ddb001  push r10
000072bd77ddb003  push r11
000072bd77ddb005  sub rsp, 0xF0
000072bd77ddb00c  vmovaps [rsp], xmm0
000072bd77ddb011  vmovaps [rsp+0x10], xmm1
000072bd77ddb017  vmovaps [rsp+0x20], xmm2
000072bd77ddb01d  vmovaps [rsp+0x30], xmm3
000072bd77ddb023  vmovaps [rsp+0x40], xmm4
000072bd77ddb029  vmovaps [rsp+0x50], xmm5
000072bd77ddb02f  vmovaps [rsp+0x60], xmm6
000072bd77ddb035  vmovaps [rsp+0x70], xmm7
000072bd77ddb03b  vmovaps [rsp+0x80], xmm9
000072bd77ddb044  vmovaps [rsp+0x90], xmm10
000072bd77ddb04d  vmovaps [rsp+0xA0], xmm11
000072bd77ddb056  vmovaps [rsp+0xB0], xmm12
000072bd77ddb05f  vmovaps [rsp+0xC0], xmm13
000072bd77ddb068  vmovaps [rsp+0xD0], xmm14
000072bd77ddb071  vmovaps [rsp+0xE0], xmm15
000072bd77ddb07a  sub rsp, 0x30
000072bd77ddb07e  movaps [rsp], xmm8
000072bd77ddb083  movaps [rsp+0x10], xmm15
000072bd77ddb089  movaps [rsp+0x20], xmm7
000072bd77ddb08e  lea rdi, [rsp]
000072bd77ddb092  mov esi, 0x00
000072bd77ddb097  mov rax, 0x643206AC3530
000072bd77ddb0a1  call rax
000072bd77ddb0a3  movaps xmm8, [rsp]
000072bd77ddb0a8  add rsp, 0x30
000072bd77ddb0ac  vmovaps xmm0, [rsp]
000072bd77ddb0b1  vmovaps xmm1, [rsp+0x10]
000072bd77ddb0b7  vmovaps xmm2, [rsp+0x20]
000072bd77ddb0bd  vmovaps xmm3, [rsp+0x30]
000072bd77ddb0c3  vmovaps xmm4, [rsp+0x40]
000072bd77ddb0c9  vmovaps xmm5, [rsp+0x50]
000072bd77ddb0cf  vmovaps xmm6, [rsp+0x60]
000072bd77ddb0d5  vmovaps xmm7, [rsp+0x70]
000072bd77ddb0db  vmovaps xmm9, [rsp+0x80]
000072bd77ddb0e4  vmovaps xmm10, [rsp+0x90]
000072bd77ddb0ed  vmovaps xmm11, [rsp+0xA0]
000072bd77ddb0f6  vmovaps xmm12, [rsp+0xB0]
000072bd77ddb0ff  vmovaps xmm13, [rsp+0xC0]
000072bd77ddb108  vmovaps xmm14, [rsp+0xD0]
000072bd77ddb111  vmovaps xmm15, [rsp+0xE0]
000072bd77ddb11a  add rsp, 0xF0
000072bd77ddb121  pop r11
000072bd77ddb123  pop r10
000072bd77ddb125  pop r9
000072bd77ddb127  pop r8
000072bd77ddb129  pop rsi
000072bd77ddb12a  pop rdi
000072bd77ddb12b  pop rdx
000072bd77ddb12c  pop rcx
000072bd77ddb12d  pop rax
000072bd77ddb12e  add rsp, 0x08
000072bd77ddb132  jmp 0x000072BD77DD65D4
000072bd77ddb137  sub rsp, 0x08
000072bd77ddb13b  push rax
000072bd77ddb13c  push rcx
000072bd77ddb13d  push rdx
000072bd77ddb13e  push rdi
000072bd77ddb13f  push rsi
000072bd77ddb140  push r8
000072bd77ddb142  push r9
000072bd77ddb144  push r10
000072bd77ddb146  push r11
000072bd77ddb148  sub rsp, 0xF0
000072bd77ddb14f  vmovaps [rsp], xmm0
000072bd77ddb154  vmovaps [rsp+0x10], xmm1
000072bd77ddb15a  vmovaps [rsp+0x20], xmm2
000072bd77ddb160  vmovaps [rsp+0x30], xmm3
000072bd77ddb166  vmovaps [rsp+0x40], xmm4
000072bd77ddb16c  vmovaps [rsp+0x50], xmm5
000072bd77ddb172  vmovaps [rsp+0x60], xmm6
000072bd77ddb178  vmovaps [rsp+0x70], xmm8
000072bd77ddb17e  vmovaps [rsp+0x80], xmm9
000072bd77ddb187  vmovaps [rsp+0x90], xmm10
000072bd77ddb190  vmovaps [rsp+0xA0], xmm11
000072bd77ddb199  vmovaps [rsp+0xB0], xmm12
000072bd77ddb1a2  vmovaps [rsp+0xC0], xmm13
000072bd77ddb1ab  vmovaps [rsp+0xD0], xmm14
000072bd77ddb1b4  vmovaps [rsp+0xE0], xmm15
000072bd77ddb1bd  sub rsp, 0x30
000072bd77ddb1c1  movaps [rsp], xmm7
000072bd77ddb1c5  movaps [rsp+0x10], xmm9
000072bd77ddb1cb  movaps [rsp+0x20], xmm15
000072bd77ddb1d1  lea rdi, [rsp]
000072bd77ddb1d5  mov esi, 0x00
000072bd77ddb1da  mov rax, 0x643206AC3530
000072bd77ddb1e4  call rax
000072bd77ddb1e6  movaps xmm7, [rsp]
000072bd77ddb1ea  add rsp, 0x30
000072bd77ddb1ee  vmovaps xmm0, [rsp]
000072bd77ddb1f3  vmovaps xmm1, [rsp+0x10]
000072bd77ddb1f9  vmovaps xmm2, [rsp+0x20]
000072bd77ddb1ff  vmovaps xmm3, [rsp+0x30]
000072bd77ddb205  vmovaps xmm4, [rsp+0x40]
000072bd77ddb20b  vmovaps xmm5, [rsp+0x50]
000072bd77ddb211  vmovaps xmm6, [rsp+0x60]
000072bd77ddb217  vmovaps xmm8, [rsp+0x70]
000072bd77ddb21d  vmovaps xmm9, [rsp+0x80]
000072bd77ddb226  vmovaps xmm10, [rsp+0x90]
000072bd77ddb22f  vmovaps xmm11, [rsp+0xA0]
000072bd77ddb238  vmovaps xmm12, [rsp+0xB0]
000072bd77ddb241  vmovaps xmm13, [rsp+0xC0]
000072bd77ddb24a  vmovaps xmm14, [rsp+0xD0]
000072bd77ddb253  vmovaps xmm15, [rsp+0xE0]
000072bd77ddb25c  add rsp, 0xF0
000072bd77ddb263  pop r11
000072bd77ddb265  pop r10
000072bd77ddb267  pop r9
000072bd77ddb269  pop r8
000072bd77ddb26b  pop rsi
000072bd77ddb26c  pop rdi
000072bd77ddb26d  pop rdx
000072bd77ddb26e  pop rcx
000072bd77ddb26f  pop rax
000072bd77ddb270  add rsp, 0x08
000072bd77ddb274  jmp 0x000072BD77DD6601
000072bd77ddb279  sub rsp, 0x08
000072bd77ddb27d  push rax
000072bd77ddb27e  push rcx
000072bd77ddb27f  push rdx
000072bd77ddb280  push rdi
000072bd77ddb281  push rsi
000072bd77ddb282  push r8
000072bd77ddb284  push r9
000072bd77ddb286  push r10
000072bd77ddb288  push r11
000072bd77ddb28a  sub rsp, 0xF0
000072bd77ddb291  vmovaps [rsp], xmm0
000072bd77ddb296  vmovaps [rsp+0x10], xmm1
000072bd77ddb29c  vmovaps [rsp+0x20], xmm2
000072bd77ddb2a2  vmovaps [rsp+0x30], xmm3
000072bd77ddb2a8  vmovaps [rsp+0x40], xmm4
000072bd77ddb2ae  vmovaps [rsp+0x50], xmm5
000072bd77ddb2b4  vmovaps [rsp+0x60], xmm6
000072bd77ddb2ba  vmovaps [rsp+0x70], xmm7
000072bd77ddb2c0  vmovaps [rsp+0x80], xmm8
000072bd77ddb2c9  vmovaps [rsp+0x90], xmm10
000072bd77ddb2d2  vmovaps [rsp+0xA0], xmm11
000072bd77ddb2db  vmovaps [rsp+0xB0], xmm12
000072bd77ddb2e4  vmovaps [rsp+0xC0], xmm13
000072bd77ddb2ed  vmovaps [rsp+0xD0], xmm14
000072bd77ddb2f6  vmovaps [rsp+0xE0], xmm15
000072bd77ddb2ff  sub rsp, 0x30
000072bd77ddb303  movaps [rsp], xmm9
000072bd77ddb308  movaps [rsp+0x10], xmm13
000072bd77ddb30e  movaps [rsp+0x20], xmm15
000072bd77ddb314  lea rdi, [rsp]
000072bd77ddb318  mov esi, 0x00
000072bd77ddb31d  mov rax, 0x643206AC3530
000072bd77ddb327  call rax
000072bd77ddb329  movaps xmm9, [rsp]
000072bd77ddb32e  add rsp, 0x30
000072bd77ddb332  vmovaps xmm0, [rsp]
000072bd77ddb337  vmovaps xmm1, [rsp+0x10]
000072bd77ddb33d  vmovaps xmm2, [rsp+0x20]
000072bd77ddb343  vmovaps xmm3, [rsp+0x30]
000072bd77ddb349  vmovaps xmm4, [rsp+0x40]
000072bd77ddb34f  vmovaps xmm5, [rsp+0x50]
000072bd77ddb355  vmovaps xmm6, [rsp+0x60]
000072bd77ddb35b  vmovaps xmm7, [rsp+0x70]
000072bd77ddb361  vmovaps xmm8, [rsp+0x80]
000072bd77ddb36a  vmovaps xmm10, [rsp+0x90]
000072bd77ddb373  vmovaps xmm11, [rsp+0xA0]
000072bd77ddb37c  vmovaps xmm12, [rsp+0xB0]
000072bd77ddb385  vmovaps xmm13, [rsp+0xC0]
000072bd77ddb38e  vmovaps xmm14, [rsp+0xD0]
000072bd77ddb397  vmovaps xmm15, [rsp+0xE0]
000072bd77ddb3a0  add rsp, 0xF0
000072bd77ddb3a7  pop r11
000072bd77ddb3a9  pop r10
000072bd77ddb3ab  pop r9
000072bd77ddb3ad  pop r8
000072bd77ddb3af  pop rsi
000072bd77ddb3b0  pop rdi
000072bd77ddb3b1  pop rdx
000072bd77ddb3b2  pop rcx
000072bd77ddb3b3  pop rax
000072bd77ddb3b4  add rsp, 0x08
000072bd77ddb3b8  jmp 0x000072BD77DD662F
000072bd77ddb3bd  sub rsp, 0x08
000072bd77ddb3c1  push rax
000072bd77ddb3c2  push rcx
000072bd77ddb3c3  push rdx
000072bd77ddb3c4  push rdi
000072bd77ddb3c5  push rsi
000072bd77ddb3c6  push r8
000072bd77ddb3c8  push r9
000072bd77ddb3ca  push r10
000072bd77ddb3cc  push r11
000072bd77ddb3ce  sub rsp, 0xF0
000072bd77ddb3d5  vmovaps [rsp], xmm0
000072bd77ddb3da  vmovaps [rsp+0x10], xmm1
000072bd77ddb3e0  vmovaps [rsp+0x20], xmm2
000072bd77ddb3e6  vmovaps [rsp+0x30], xmm3
000072bd77ddb3ec  vmovaps [rsp+0x40], xmm4
000072bd77ddb3f2  vmovaps [rsp+0x50], xmm5
000072bd77ddb3f8  vmovaps [rsp+0x60], xmm6
000072bd77ddb3fe  vmovaps [rsp+0x70], xmm7
000072bd77ddb404  vmovaps [rsp+0x80], xmm8
000072bd77ddb40d  vmovaps [rsp+0x90], xmm9
000072bd77ddb416  vmovaps [rsp+0xA0], xmm10
000072bd77ddb41f  vmovaps [rsp+0xB0], xmm11
000072bd77ddb428  vmovaps [rsp+0xC0], xmm12
000072bd77ddb431  vmovaps [rsp+0xD0], xmm13
000072bd77ddb43a  vmovaps [rsp+0xE0], xmm14
000072bd77ddb443  sub rsp, 0x30
000072bd77ddb447  movaps [rsp], xmm15
000072bd77ddb44c  movaps [rsp+0x10], xmm11
000072bd77ddb452  movaps [rsp+0x20], xmm12
000072bd77ddb458  lea rdi, [rsp]
000072bd77ddb45c  mov esi, 0x00
000072bd77ddb461  mov rax, 0x643206AC3530
000072bd77ddb46b  call rax
000072bd77ddb46d  movaps xmm15, [rsp]
000072bd77ddb472  add rsp, 0x30
000072bd77ddb476  vmovaps xmm0, [rsp]
000072bd77ddb47b  vmovaps xmm1, [rsp+0x10]
000072bd77ddb481  vmovaps xmm2, [rsp+0x20]
000072bd77ddb487  vmovaps xmm3, [rsp+0x30]
000072bd77ddb48d  vmovaps xmm4, [rsp+0x40]
000072bd77ddb493  vmovaps xmm5, [rsp+0x50]
000072bd77ddb499  vmovaps xmm6, [rsp+0x60]
000072bd77ddb49f  vmovaps xmm7, [rsp+0x70]
000072bd77ddb4a5  vmovaps xmm8, [rsp+0x80]
000072bd77ddb4ae  vmovaps xmm9, [rsp+0x90]
000072bd77ddb4b7  vmovaps xmm10, [rsp+0xA0]
000072bd77ddb4c0  vmovaps xmm11, [rsp+0xB0]
000072bd77ddb4c9  vmovaps xmm12, [rsp+0xC0]
000072bd77ddb4d2  vmovaps xmm13, [rsp+0xD0]
000072bd77ddb4db  vmovaps xmm14, [rsp+0xE0]
000072bd77ddb4e4  add rsp, 0xF0
000072bd77ddb4eb  pop r11
000072bd77ddb4ed  pop r10
000072bd77ddb4ef  pop r9
000072bd77ddb4f1  pop r8
000072bd77ddb4f3  pop rsi
000072bd77ddb4f4  pop rdi
000072bd77ddb4f5  pop rdx
000072bd77ddb4f6  pop rcx
000072bd77ddb4f7  pop rax
000072bd77ddb4f8  add rsp, 0x08
000072bd77ddb4fc  jmp 0x000072BD77DD664A
000072bd77ddb501  sub rsp, 0x08
000072bd77ddb505  push rax
000072bd77ddb506  push rcx
000072bd77ddb507  push rdx
000072bd77ddb508  push rdi
000072bd77ddb509  push rsi
000072bd77ddb50a  push r8
000072bd77ddb50c  push r9
000072bd77ddb50e  push r10
000072bd77ddb510  push r11
000072bd77ddb512  sub rsp, 0xF0
000072bd77ddb519  vmovaps [rsp], xmm0
000072bd77ddb51e  vmovaps [rsp+0x10], xmm1
000072bd77ddb524  vmovaps [rsp+0x20], xmm2
000072bd77ddb52a  vmovaps [rsp+0x30], xmm3
000072bd77ddb530  vmovaps [rsp+0x40], xmm4
000072bd77ddb536  vmovaps [rsp+0x50], xmm5
000072bd77ddb53c  vmovaps [rsp+0x60], xmm6
000072bd77ddb542  vmovaps [rsp+0x70], xmm7
000072bd77ddb548  vmovaps [rsp+0x80], xmm8
000072bd77ddb551  vmovaps [rsp+0x90], xmm9
000072bd77ddb55a  vmovaps [rsp+0xA0], xmm10
000072bd77ddb563  vmovaps [rsp+0xB0], xmm11
000072bd77ddb56c  vmovaps [rsp+0xC0], xmm12
000072bd77ddb575  vmovaps [rsp+0xD0], xmm14
000072bd77ddb57e  vmovaps [rsp+0xE0], xmm15
000072bd77ddb587  sub rsp, 0x30
000072bd77ddb58b  movaps [rsp], xmm13
000072bd77ddb590  movaps [rsp+0x10], xmm10
000072bd77ddb596  movaps [rsp+0x20], xmm14
000072bd77ddb59c  lea rdi, [rsp]
000072bd77ddb5a0  mov esi, 0x00
000072bd77ddb5a5  mov rax, 0x643206AC3530
000072bd77ddb5af  call rax
000072bd77ddb5b1  movaps xmm13, [rsp]
000072bd77ddb5b6  add rsp, 0x30
000072bd77ddb5ba  vmovaps xmm0, [rsp]
000072bd77ddb5bf  vmovaps xmm1, [rsp+0x10]
000072bd77ddb5c5  vmovaps xmm2, [rsp+0x20]
000072bd77ddb5cb  vmovaps xmm3, [rsp+0x30]
000072bd77ddb5d1  vmovaps xmm4, [rsp+0x40]
000072bd77ddb5d7  vmovaps xmm5, [rsp+0x50]
000072bd77ddb5dd  vmovaps xmm6, [rsp+0x60]
000072bd77ddb5e3  vmovaps xmm7, [rsp+0x70]
000072bd77ddb5e9  vmovaps xmm8, [rsp+0x80]
000072bd77ddb5f2  vmovaps xmm9, [rsp+0x90]
000072bd77ddb5fb  vmovaps xmm10, [rsp+0xA0]
000072bd77ddb604  vmovaps xmm11, [rsp+0xB0]
000072bd77ddb60d  vmovaps xmm12, [rsp+0xC0]
000072bd77ddb616  vmovaps xmm14, [rsp+0xD0]
000072bd77ddb61f  vmovaps xmm15, [rsp+0xE0]
000072bd77ddb628  add rsp, 0xF0
000072bd77ddb62f  pop r11
000072bd77ddb631  pop r10
000072bd77ddb633  pop r9
000072bd77ddb635  pop r8
000072bd77ddb637  pop rsi
000072bd77ddb638  pop rdi
000072bd77ddb639  pop rdx
000072bd77ddb63a  pop rcx
000072bd77ddb63b  pop rax
000072bd77ddb63c  add rsp, 0x08
000072bd77ddb640  jmp 0x000072BD77DD666D
000072bd77ddb645  sub rsp, 0x08
000072bd77ddb649  push rax
000072bd77ddb64a  push rcx
000072bd77ddb64b  push rdx
000072bd77ddb64c  push rdi
000072bd77ddb64d  push rsi
000072bd77ddb64e  push r8
000072bd77ddb650  push r9
000072bd77ddb652  push r10
000072bd77ddb654  push r11
000072bd77ddb656  sub rsp, 0xF0
000072bd77ddb65d  vmovaps [rsp], xmm0
000072bd77ddb662  vmovaps [rsp+0x10], xmm1
000072bd77ddb668  vmovaps [rsp+0x20], xmm2
000072bd77ddb66e  vmovaps [rsp+0x30], xmm3
000072bd77ddb674  vmovaps [rsp+0x40], xmm4
000072bd77ddb67a  vmovaps [rsp+0x50], xmm5
000072bd77ddb680  vmovaps [rsp+0x60], xmm6
000072bd77ddb686  vmovaps [rsp+0x70], xmm7
000072bd77ddb68c  vmovaps [rsp+0x80], xmm8
000072bd77ddb695  vmovaps [rsp+0x90], xmm9
000072bd77ddb69e  vmovaps [rsp+0xA0], xmm10
000072bd77ddb6a7  vmovaps [rsp+0xB0], xmm11
000072bd77ddb6b0  vmovaps [rsp+0xC0], xmm12
000072bd77ddb6b9  vmovaps [rsp+0xD0], xmm13
000072bd77ddb6c2  vmovaps [rsp+0xE0], xmm15
000072bd77ddb6cb  sub rsp, 0x30
000072bd77ddb6cf  movaps [rsp], xmm14
000072bd77ddb6d4  movaps [rsp+0x10], xmm1
000072bd77ddb6d9  movaps [rsp+0x20], xmm7
000072bd77ddb6de  lea rdi, [rsp]
000072bd77ddb6e2  mov esi, 0x00
000072bd77ddb6e7  mov rax, 0x643206AC3530
000072bd77ddb6f1  call rax
000072bd77ddb6f3  movaps xmm14, [rsp]
000072bd77ddb6f8  add rsp, 0x30
000072bd77ddb6fc  vmovaps xmm0, [rsp]
000072bd77ddb701  vmovaps xmm1, [rsp+0x10]
000072bd77ddb707  vmovaps xmm2, [rsp+0x20]
000072bd77ddb70d  vmovaps xmm3, [rsp+0x30]
000072bd77ddb713  vmovaps xmm4, [rsp+0x40]
000072bd77ddb719  vmovaps xmm5, [rsp+0x50]
000072bd77ddb71f  vmovaps xmm6, [rsp+0x60]
000072bd77ddb725  vmovaps xmm7, [rsp+0x70]
000072bd77ddb72b  vmovaps xmm8, [rsp+0x80]
000072bd77ddb734  vmovaps xmm9, [rsp+0x90]
000072bd77ddb73d  vmovaps xmm10, [rsp+0xA0]
000072bd77ddb746  vmovaps xmm11, [rsp+0xB0]
000072bd77ddb74f  vmovaps xmm12, [rsp+0xC0]
000072bd77ddb758  vmovaps xmm13, [rsp+0xD0]
000072bd77ddb761  vmovaps xmm15, [rsp+0xE0]
000072bd77ddb76a  add rsp, 0xF0
000072bd77ddb771  pop r11
000072bd77ddb773  pop r10
000072bd77ddb775  pop r9
000072bd77ddb777  pop r8
000072bd77ddb779  pop rsi
000072bd77ddb77a  pop rdi
000072bd77ddb77b  pop rdx
000072bd77ddb77c  pop rcx
000072bd77ddb77d  pop rax
000072bd77ddb77e  add rsp, 0x08
000072bd77ddb782  jmp 0x000072BD77DD6690
000072bd77ddb787  sub rsp, 0x08
000072bd77ddb78b  push rax
000072bd77ddb78c  push rcx
000072bd77ddb78d  push rdx
000072bd77ddb78e  push rdi
000072bd77ddb78f  push rsi
000072bd77ddb790  push r8
000072bd77ddb792  push r9
000072bd77ddb794  push r10
000072bd77ddb796  push r11
000072bd77ddb798  sub rsp, 0xF0
000072bd77ddb79f  vmovaps [rsp], xmm0
000072bd77ddb7a4  vmovaps [rsp+0x10], xmm2
000072bd77ddb7aa  vmovaps [rsp+0x20], xmm3
000072bd77ddb7b0  vmovaps [rsp+0x30], xmm4
000072bd77ddb7b6  vmovaps [rsp+0x40], xmm5
000072bd77ddb7bc  vmovaps [rsp+0x50], xmm6
000072bd77ddb7c2  vmovaps [rsp+0x60], xmm7
000072bd77ddb7c8  vmovaps [rsp+0x70], xmm8
000072bd77ddb7ce  vmovaps [rsp+0x80], xmm9
000072bd77ddb7d7  vmovaps [rsp+0x90], xmm10
000072bd77ddb7e0  vmovaps [rsp+0xA0], xmm11
000072bd77ddb7e9  vmovaps [rsp+0xB0], xmm12
000072bd77ddb7f2  vmovaps [rsp+0xC0], xmm13
000072bd77ddb7fb  vmovaps [rsp+0xD0], xmm14
000072bd77ddb804  vmovaps [rsp+0xE0], xmm15
000072bd77ddb80d  sub rsp, 0x30
000072bd77ddb811  movaps [rsp], xmm1
000072bd77ddb815  movaps [rsp+0x10], xmm8
000072bd77ddb81b  movaps [rsp+0x20], xmm9
000072bd77ddb821  lea rdi, [rsp]
000072bd77ddb825  mov esi, 0x00
000072bd77ddb82a  mov rax, 0x643206AC3530
000072bd77ddb834  call rax
000072bd77ddb836  movaps xmm1, [rsp]
000072bd77ddb83a  add rsp, 0x30
000072bd77ddb83e  vmovaps xmm0, [rsp]
000072bd77ddb843  vmovaps xmm2, [rsp+0x10]
000072bd77ddb849  vmovaps xmm3, [rsp+0x20]
000072bd77ddb84f  vmovaps xmm4, [rsp+0x30]
000072bd77ddb855  vmovaps xmm5, [rsp+0x40]
000072bd77ddb85b  vmovaps xmm6, [rsp+0x50]
000072bd77ddb861  vmovaps xmm7, [rsp+0x60]
000072bd77ddb867  vmovaps xmm8, [rsp+0x70]
000072bd77ddb86d  vmovaps xmm9, [rsp+0x80]
000072bd77ddb876  vmovaps xmm10, [rsp+0x90]
000072bd77ddb87f  vmovaps xmm11, [rsp+0xA0]
000072bd77ddb888  vmovaps xmm12, [rsp+0xB0]
000072bd77ddb891  vmovaps xmm13, [rsp+0xC0]
000072bd77ddb89a  vmovaps xmm14, [rsp+0xD0]
000072bd77ddb8a3  vmovaps xmm15, [rsp+0xE0]
000072bd77ddb8ac  add rsp, 0xF0
000072bd77ddb8b3  pop r11
000072bd77ddb8b5  pop r10
000072bd77ddb8b7  pop r9
000072bd77ddb8b9  pop r8
000072bd77ddb8bb  pop rsi
000072bd77ddb8bc  pop rdi
000072bd77ddb8bd  pop rdx
000072bd77ddb8be  pop rcx
000072bd77ddb8bf  pop rax
000072bd77ddb8c0  add rsp, 0x08
000072bd77ddb8c4  jmp 0x000072BD77DD66B2
000072bd77ddb8c9  call 0x000072BD77CB3E40
000072bd77ddb8ce  jmp 0x000072BD77DD66C0
000072bd77ddb8d3  call 0x000072BD77C0C380
000072bd77ddb8d8  jmp 0x000072BD77DD66CA
000072bd77ddb8dd  call 0x000072BD77C0D600
000072bd77ddb8e2  jmp 0x000072BD77DD66D4
000072bd77ddb8e7  call 0x000072BD77BFF540
000072bd77ddb8ec  jmp 0x000072BD77DD66DE
000072bd77ddb8f1  int3
000072bd77ddb8f2  nop [rax+rax*1], ax
000072bd77ddb8fb  nop [rax+rax*1], eax
000072bd77ddb900  mov eax, [r15+0x48]
000072bd77ddb904  lea r14d, [eax+0x01]
000072bd77ddb909  mov [rsp+0x10], r14d
000072bd77ddb90e  mov r14d, r14d
000072bd77ddb911  mov [r15+0x48], r14
000072bd77ddb915  xor eax, eax
000072bd77ddb917  mov r14d, [rsp+0x10]
000072bd77ddb91c  cmp r14d, 0x1F4
000072bd77ddb923  cmc
000072bd77ddb924  lahf
000072bd77ddb925  seto al
000072bd77ddb928  mov [r15+0x108], eax
000072bd77ddb92f  mov eax, [r15+0x108]
000072bd77ddb936  sahf
000072bd77ddb937  jnz 0x000072BD77DDB969
000072bd77ddb939  cmp dword ptr [r15+0x318], 0x00
000072bd77ddb941  jz 0x000072BD77DE1AB0
000072bd77ddb947  nop [rax+rax*1], ax
000072bd77ddb950  nop [rax+rax*1], eax
000072bd77ddb958  mov eax, 0x410450
000072bd77ddb95d  mov [r15+0x100], rax
000072bd77ddb964  jmp 0x000072BD77BFE110
000072bd77ddb969  cmp dword ptr [r15+0x318], 0x00
000072bd77ddb971  jz 0x000072BD77DDB9A0
000072bd77ddb977  nop [rax+rax*1], ax
000072bd77ddb980  nop [rax+rax*1], eax
000072bd77ddb988  mov eax, 0x410274
000072bd77ddb98d  mov [r15+0x100], rax
000072bd77ddb994  jmp 0x000072BD77BFE110
000072bd77ddb999  int3
000072bd77ddb99a  int3
000072bd77ddb99b  nop [rax+rax*1], eax
000072bd77ddb9a0  mov rax, [r15+0x40]
000072bd77ddb9a4  movaps xmm1, [r15+0x1D0]
000072bd77ddb9ac  vmovaps [rsp+0x10], xmm1
000072bd77ddb9b2  vmovaps xmm15, [rsp+0x10]
000072bd77ddb9b8  por xmm1, xmm15
000072bd77ddb9bd  movaps xmm14, [r15+0x1A0]
000072bd77ddb9c5  vmovaps [rsp+0x10], xmm14
000072bd77ddb9cb  vmovaps xmm13, [rsp+0x10]
000072bd77ddb9d1  por xmm14, xmm13
000072bd77ddb9d6  lea r14, [rax+0x30]
000072bd77ddb9da  mov r12, [r13+r14*1]
000072bd77ddb9df  lea r14, [rax+0x38]
000072bd77ddb9e3  mov r11, [r13+r14*1]
000072bd77ddb9e8  movq xmm13, r12
000072bd77ddb9ed  movq xmm12, r11
000072bd77ddb9f2  movq xmm13, xmm13
000072bd77ddb9f7  vmovaps [rsp+0x10], xmm13
000072bd77ddb9fd  movq xmm13, xmm13
000072bd77ddba02  movaps [r15+0x130], xmm13
000072bd77ddba0a  movq xmm12, xmm12
000072bd77ddba0f  vmovaps [rsp+0x20], xmm12
000072bd77ddba15  movq xmm12, xmm12
000072bd77ddba1a  movaps [r15+0x280], xmm12
000072bd77ddba22  movaps xmm13, [r15+0x270]
000072bd77ddba2a  vmovaps [rsp+0x30], xmm13
000072bd77ddba30  vmovaps xmm12, [rsp+0x30]
000072bd77ddba36  por xmm13, xmm12
000072bd77ddba3b  lea r14, [rax+0x20]
000072bd77ddba3f  mov r12, [r13+r14*1]
000072bd77ddba44  lea r14, [rax+0x28]
000072bd77ddba48  mov r11, [r13+r14*1]
000072bd77ddba4d  movq xmm12, r12
000072bd77ddba52  movq xmm11, r11
000072bd77ddba57  movq xmm12, xmm12
000072bd77ddba5c  vmovaps [rsp+0x30], xmm12
000072bd77ddba62  movq xmm12, xmm12
000072bd77ddba67  movaps [r15+0x150], xmm12
000072bd77ddba6f  movq xmm11, xmm11
000072bd77ddba74  vmovaps [rsp+0x40], xmm11
000072bd77ddba7a  movq xmm11, xmm11
000072bd77ddba7f  movaps [r15+0x140], xmm11
000072bd77ddba87  lea r14, [rax+0x10]
000072bd77ddba8b  mov r12, [r13+r14*1]
000072bd77ddba90  lea r14, [rax+0x18]
000072bd77ddba94  mov r11, [r13+r14*1]
000072bd77ddba99  movq xmm12, r12
000072bd77ddba9e  movq xmm11, r11
000072bd77ddbaa3  movq xmm12, xmm12
000072bd77ddbaa8  vmovaps [rsp+0x50], xmm12
000072bd77ddbaae  movq xmm12, xmm12
000072bd77ddbab3  movaps [r15+0x170], xmm12
000072bd77ddbabb  movq xmm11, xmm11
000072bd77ddbac0  vmovaps [rsp+0x60], xmm11
000072bd77ddbac6  movq xmm11, xmm11
000072bd77ddbacb  movaps [r15+0x160], xmm11
000072bd77ddbad3  mov r14, [r13+rax*1]
000072bd77ddbad8  vmovq xmm12, r14
000072bd77ddbadd  vpbroadcastq xmm12, xmm12
000072bd77ddbae2  lea r14, [rax+0x08]
000072bd77ddbae6  mov rax, [r13+r14*1]
000072bd77ddbaeb  movq xmm11, rax
000072bd77ddbaf0  movaps [r15+0x230], xmm11
000072bd77ddbaf8  mov rax, [r15+0xF8]
000072bd77ddbaff  lea r14, [rax+0x50]
000072bd77ddbb03  movups xmm11, [r13+r14*1]
000072bd77ddbb09  lea r14, [rax+0x60]
000072bd77ddbb0d  movups xmm10, [r13+r14*1]
000072bd77ddbb13  lea r14, [rax+0x30]
000072bd77ddbb17  movups xmm9, [r13+r14*1]
000072bd77ddbb1d  mov r14, [r15+0x50]
000072bd77ddbb21  mov [r15+0x60], r14
000072bd77ddbb25  mov qword ptr [r15+0x58], 0x40
000072bd77ddbb2d  movaps xmm8, xmm12
000072bd77ddbb31  mulpd xmm8, xmm15
000072bd77ddbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000072bd77ddbb3c  ptest xmm7, xmm7
000072bd77ddbb41  jnz 0x000072BD77DDC96A
000072bd77ddbb47  movq xmm15, qword ptr [r15+0x230]
000072bd77ddbb50  vmovaps [rsp+0x70], xmm15
000072bd77ddbb56  vpermilpd xmm15, xmm15, 0x00
000072bd77ddbb5c  movaps xmm7, xmm9
000072bd77ddbb60  mulpd xmm7, xmm15
000072bd77ddbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000072bd77ddbb6a  ptest xmm6, xmm6
000072bd77ddbb6f  jnz 0x000072BD77DDCAAE
000072bd77ddbb75  vxorps xmm15, xmm15, xmm15
000072bd77ddbb7a  vpbroadcastq xmm15, xmm15
000072bd77ddbb7f  movaps xmm9, xmm12
000072bd77ddbb83  mulpd xmm9, xmm10
000072bd77ddbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000072bd77ddbb8e  ptest xmm6, xmm6
000072bd77ddbb93  jnz 0x000072BD77DDCBF0
000072bd77ddbb99  movaps xmm10, xmm12
000072bd77ddbb9d  mulpd xmm10, xmm11
000072bd77ddbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000072bd77ddbba8  ptest xmm6, xmm6
000072bd77ddbbad  jnz 0x000072BD77DDCD34
000072bd77ddbbb3  movaps xmm11, [r15+0x1F0]
000072bd77ddbbbb  movaps xmm6, xmm12
000072bd77ddbbbf  mulpd xmm6, xmm11
000072bd77ddbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000072bd77ddbbc9  ptest xmm5, xmm5
000072bd77ddbbce  jnz 0x000072BD77DDCE78
000072bd77ddbbd4  movaps xmm12, [r15+0x2A0]
000072bd77ddbbdc  vmovaps [rsp+0x80], xmm12
000072bd77ddbbe5  vmovaps xmm11, [rsp+0x80]
000072bd77ddbbee  por xmm12, xmm11
000072bd77ddbbf3  movaps xmm11, [r15+0x250]
000072bd77ddbbfb  vmovaps [rsp+0x80], xmm11
000072bd77ddbc04  vmovaps xmm5, [rsp+0x80]
000072bd77ddbc0d  por xmm11, xmm5
000072bd77ddbc12  vmovaps xmm4, [rsp+0x70]
000072bd77ddbc18  vpermilpd xmm4, xmm4, 0x00
000072bd77ddbc1e  movaps xmm3, xmm5
000072bd77ddbc21  mulpd xmm3, xmm4
000072bd77ddbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000072bd77ddbc2a  ptest xmm2, xmm2
000072bd77ddbc2f  jnz 0x000072BD77DDCFBA
000072bd77ddbc35  mov [rsp+0x80], rax
000072bd77ddbc3d  xor eax, eax
000072bd77ddbc3f  mov r12d, 0x40
000072bd77ddbc45  mov r11d, 0x200
000072bd77ddbc4b  cmp r12, r11
000072bd77ddbc4e  cmc
000072bd77ddbc4f  lahf
000072bd77ddbc50  seto al
000072bd77ddbc53  mov [r15+0x108], eax
000072bd77ddbc5a  movaps xmm5, xmm8
000072bd77ddbc5e  addpd xmm5, xmm15
000072bd77ddbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000072bd77ddbc68  ptest xmm4, xmm4
000072bd77ddbc6d  jnz 0x000072BD77DDD0FA
000072bd77ddbc73  movaps xmm8, [r15+0x1B0]
000072bd77ddbc7b  movaps xmm4, xmm9
000072bd77ddbc7f  addpd xmm4, xmm8
000072bd77ddbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000072bd77ddbc89  ptest xmm2, xmm2
000072bd77ddbc8e  jnz 0x000072BD77DDD23C
000072bd77ddbc94  movaps xmm9, xmm10
000072bd77ddbc98  addpd xmm9, xmm8
000072bd77ddbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000072bd77ddbca3  ptest xmm2, xmm2
000072bd77ddbca8  jnz 0x000072BD77DDD37E
000072bd77ddbcae  movaps xmm10, [r15+0x2F0]
000072bd77ddbcb6  vmovaps [rsp+0x90], xmm10
000072bd77ddbcbf  vmovaps xmm8, [rsp+0x90]
000072bd77ddbcc8  por xmm10, xmm8
000072bd77ddbccd  movaps xmm8, [r15+0x2E0]
000072bd77ddbcd5  vmovaps [rsp+0x90], xmm8
000072bd77ddbcde  vmovaps xmm2, [rsp+0x90]
000072bd77ddbce7  por xmm8, xmm2
000072bd77ddbcec  movaps xmm2, [r15+0x2D0]
000072bd77ddbcf4  vmovaps [rsp+0x90], xmm2
000072bd77ddbcfd  vmovaps [rsp+0xA0], xmm1
000072bd77ddbd06  vmovaps xmm1, [rsp+0x90]
000072bd77ddbd0f  por xmm2, xmm1
000072bd77ddbd13  movaps xmm1, [r15+0x200]
000072bd77ddbd1b  vmovaps [rsp+0x90], xmm1
000072bd77ddbd24  vmovaps [rsp+0xB0], xmm15
000072bd77ddbd2d  vmovaps xmm15, [rsp+0x90]
000072bd77ddbd36  por xmm1, xmm15
000072bd77ddbd3b  movaps xmm15, [r15+0x1C0]
000072bd77ddbd43  vmovaps [rsp+0x90], xmm15
000072bd77ddbd4c  vmovaps [rsp+0xC0], xmm1
000072bd77ddbd55  vmovaps xmm1, [rsp+0x90]
000072bd77ddbd5e  por xmm15, xmm1
000072bd77ddbd63  movaps xmm1, [r15+0x190]
000072bd77ddbd6b  vmovaps [rsp+0x90], xmm1
000072bd77ddbd74  vmovaps [rsp+0xD0], xmm15
000072bd77ddbd7d  vmovaps xmm15, [rsp+0x90]
000072bd77ddbd86  por xmm1, xmm15
000072bd77ddbd8b  movaps xmm15, [r15+0x300]
000072bd77ddbd93  vmovaps [rsp+0x90], xmm15
000072bd77ddbd9c  vmovaps [rsp+0xE0], xmm1
000072bd77ddbda5  vmovaps xmm1, [rsp+0x90]
000072bd77ddbdae  por xmm15, xmm1
000072bd77ddbdb3  mov rax, [rsp+0x80]
000072bd77ddbdbb  lea r12, [rax+0xA0]
000072bd77ddbdc2  movups xmm1, [r13+r12*1]
000072bd77ddbdc8  lea r12, [rax+0xB0]
000072bd77ddbdcf  vmovaps [rsp+0x80], xmm1
000072bd77ddbdd8  movups xmm1, [r13+r12*1]
000072bd77ddbdde  vmovaps [rsp+0x90], xmm1
000072bd77ddbde7  vmovaps [rsp+0xF0], xmm15
000072bd77ddbdf0  vmovaps xmm15, [rsp+0xB0]
000072bd77ddbdf9  vmovaps [rsp+0xB0], xmm14
000072bd77ddbe02  movaps xmm1, xmm6
000072bd77ddbe05  addpd xmm1, xmm15
000072bd77ddbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000072bd77ddbe0f  ptest xmm14, xmm14
000072bd77ddbe15  jnz 0x000072BD77DDD4D6
000072bd77ddbe1b  lea r12, [rax+0xF0]
000072bd77ddbe22  movups xmm15, [r13+r12*1]
000072bd77ddbe28  movaps xmm14, xmm4
000072bd77ddbe2c  addpd xmm14, xmm3
000072bd77ddbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000072bd77ddbe37  ptest xmm6, xmm6
000072bd77ddbe3c  jnz 0x000072BD77DDD621
000072bd77ddbe42  movaps xmm6, xmm9
000072bd77ddbe46  addpd xmm6, xmm7
000072bd77ddbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000072bd77ddbe4f  ptest xmm4, xmm4
000072bd77ddbe54  jnz 0x000072BD77DDD763
000072bd77ddbe5a  vmovaps xmm9, [rsp+0x70]
000072bd77ddbe60  vpermilpd xmm9, xmm9, 0x00
000072bd77ddbe66  vmovaps xmm4, [rsp+0x90]
000072bd77ddbe6f  movaps xmm7, xmm4
000072bd77ddbe72  mulpd xmm7, xmm9
000072bd77ddbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000072bd77ddbe7c  ptest xmm3, xmm3
000072bd77ddbe81  jnz 0x000072BD77DDD8A4
000072bd77ddbe87  vmovaps xmm9, [rsp+0x50]
000072bd77ddbe8d  vpermilpd xmm9, xmm9, 0x00
000072bd77ddbe93  movaps xmm4, xmm15
000072bd77ddbe97  mulpd xmm4, xmm9
000072bd77ddbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000072bd77ddbea1  ptest xmm3, xmm3
000072bd77ddbea6  jnz 0x000072BD77DDD9E5
000072bd77ddbeac  lea r12, [rax+0xE0]
000072bd77ddbeb3  movups xmm15, [r13+r12*1]
000072bd77ddbeb9  vmovaps xmm9, [rsp+0x70]
000072bd77ddbebf  vpermilpd xmm9, xmm9, 0x00
000072bd77ddbec5  vmovaps [rsp+0x70], xmm1
000072bd77ddbecb  vmovaps xmm1, [rsp+0x80]
000072bd77ddbed4  vmovaps [rsp+0x80], xmm15
000072bd77ddbedd  movaps xmm3, xmm1
000072bd77ddbee0  mulpd xmm3, xmm9
000072bd77ddbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000072bd77ddbeea  ptest xmm15, xmm15
000072bd77ddbef0  jnz 0x000072BD77DDDB31
000072bd77ddbef6  vmovaps xmm1, [rsp+0xF0]
000072bd77ddbeff  vmovaps xmm15, [rsp+0xF0]
000072bd77ddbf08  por xmm1, xmm15
000072bd77ddbf0d  movaps [r15+0x300], xmm1
000072bd77ddbf15  vmovaps xmm15, [rsp+0xE0]
000072bd77ddbf1e  vmovaps xmm9, [rsp+0xE0]
000072bd77ddbf27  por xmm15, xmm9
000072bd77ddbf2c  movaps [r15+0x190], xmm15
000072bd77ddbf34  vmovaps xmm9, [rsp+0x50]
000072bd77ddbf3a  vpermilpd xmm9, xmm9, 0x00
000072bd77ddbf40  vmovaps [rsp+0x90], xmm1
000072bd77ddbf49  vmovaps [rsp+0xE0], xmm15
000072bd77ddbf52  vmovaps xmm15, [rsp+0x80]
000072bd77ddbf5b  vmovaps [rsp+0x80], xmm14
000072bd77ddbf64  movaps xmm1, xmm15
000072bd77ddbf68  mulpd xmm1, xmm9
000072bd77ddbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000072bd77ddbf72  ptest xmm14, xmm14
000072bd77ddbf78  jnz 0x000072BD77DDDC72
000072bd77ddbf7e  lea r12, [rax+0x90]
000072bd77ddbf85  movups xmm15, [r13+r12*1]
000072bd77ddbf8b  vmovaps xmm14, [rsp+0xD0]
000072bd77ddbf94  vmovaps xmm9, [rsp+0xD0]
000072bd77ddbf9d  por xmm14, xmm9
000072bd77ddbfa2  movaps [r15+0x1C0], xmm14
000072bd77ddbfaa  vmovaps xmm9, [rsp+0xC0]
000072bd77ddbfb3  vmovaps [rsp+0xD0], xmm1
000072bd77ddbfbc  vmovaps xmm1, [rsp+0xC0]
000072bd77ddbfc5  por xmm9, xmm1
000072bd77ddbfca  movaps [r15+0x200], xmm9
000072bd77ddbfd2  vmovaps [rsp+0xC0], xmm2
000072bd77ddbfdb  vmovaps xmm1, [rsp+0xC0]
000072bd77ddbfe4  por xmm2, xmm1
000072bd77ddbfe8  movaps [r15+0x2D0], xmm2
000072bd77ddbff0  vmovaps [rsp+0xC0], xmm8
000072bd77ddbff9  vmovaps xmm1, [rsp+0xC0]
000072bd77ddc002  por xmm8, xmm1
000072bd77ddc007  movaps [r15+0x2E0], xmm8
000072bd77ddc00f  vmovaps [rsp+0xC0], xmm15
000072bd77ddc018  movaps xmm1, xmm5
000072bd77ddc01b  addpd xmm1, xmm7
000072bd77ddc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000072bd77ddc024  ptest xmm15, xmm15
000072bd77ddc02a  jnz 0x000072BD77DDDDBE
000072bd77ddc030  vmovaps xmm15, [rsp+0x50]
000072bd77ddc036  vpermilpd xmm15, xmm15, 0x00
000072bd77ddc03c  vmovaps xmm5, [rsp+0xC0]
000072bd77ddc045  vmovaps [rsp+0xC0], xmm1
000072bd77ddc04e  movaps xmm7, xmm5
000072bd77ddc051  mulpd xmm7, xmm15
000072bd77ddc056  vcmppd xmm1, xmm7, xmm7, 0x03
000072bd77ddc05b  ptest xmm1, xmm1
000072bd77ddc060  jnz 0x000072BD77DDDEFE
000072bd77ddc066  lea r12, [rax+0x80]
000072bd77ddc06d  movups xmm1, [r13+r12*1]
000072bd77ddc073  vmovaps xmm5, [rsp+0x70]
000072bd77ddc079  vmovaps [rsp+0x70], xmm1
000072bd77ddc07f  movaps xmm15, xmm5
000072bd77ddc083  addpd xmm15, xmm3
000072bd77ddc088  vcmppd xmm1, xmm15, xmm15, 0x03
000072bd77ddc08e  ptest xmm1, xmm1
000072bd77ddc093  jnz 0x000072BD77DDE049
000072bd77ddc099  vmovaps xmm5, [rsp+0x80]
000072bd77ddc0a2  movaps xmm1, xmm5
000072bd77ddc0a5  addpd xmm1, xmm4
000072bd77ddc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000072bd77ddc0ae  ptest xmm3, xmm3
000072bd77ddc0b3  jnz 0x000072BD77DDE18B
000072bd77ddc0b9  vmovaps [rsp+0x80], xmm10
000072bd77ddc0c2  vmovaps xmm5, [rsp+0x80]
000072bd77ddc0cb  por xmm10, xmm5
000072bd77ddc0d0  movaps [r15+0x2F0], xmm10
000072bd77ddc0d8  vmovaps xmm5, [rsp+0x50]
000072bd77ddc0de  vpermilpd xmm5, xmm5, 0x00
000072bd77ddc0e4  vmovaps xmm3, [rsp+0x70]
000072bd77ddc0ea  vmovaps [rsp+0x50], xmm1
000072bd77ddc0f0  movaps xmm4, xmm3
000072bd77ddc0f3  mulpd xmm4, xmm5
000072bd77ddc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000072bd77ddc0fc  ptest xmm1, xmm1
000072bd77ddc101  jnz 0x000072BD77DDE2CB
000072bd77ddc107  lea r12, [rax+0xD0]
000072bd77ddc10e  movups xmm1, [r13+r12*1]
000072bd77ddc114  vmovaps xmm3, [rsp+0xD0]
000072bd77ddc11d  vmovaps [rsp+0x70], xmm1
000072bd77ddc123  movaps xmm5, xmm6
000072bd77ddc126  addpd xmm5, xmm3
000072bd77ddc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000072bd77ddc12f  ptest xmm1, xmm1
000072bd77ddc134  jnz 0x000072BD77DDE415
000072bd77ddc13a  vmovaps xmm1, [rsp+0x60]
000072bd77ddc140  vpermilpd xmm1, xmm1, 0x00
000072bd77ddc146  movaps xmm6, xmm9
000072bd77ddc14a  mulpd xmm6, xmm1
000072bd77ddc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000072bd77ddc153  ptest xmm3, xmm3
000072bd77ddc158  jnz 0x000072BD77DDE555
000072bd77ddc15e  movaps [r15+0x260], xmm6
000072bd77ddc166  vxorps xmm1, xmm1, xmm1
000072bd77ddc16a  vpbroadcastq xmm1, xmm1
000072bd77ddc16f  movaps [r15+0x1B0], xmm1
000072bd77ddc177  vmovaps xmm1, [rsp+0x60]
000072bd77ddc17d  vpermilpd xmm1, xmm1, 0x00
000072bd77ddc183  vmovaps xmm3, [rsp+0x70]
000072bd77ddc189  vmovaps [rsp+0x70], xmm15
000072bd77ddc18f  movaps xmm9, xmm3
000072bd77ddc193  mulpd xmm9, xmm1
000072bd77ddc198  vcmppd xmm15, xmm9, xmm9, 0x03
000072bd77ddc19e  ptest xmm15, xmm15
000072bd77ddc1a4  jnz 0x000072BD77DDE696
000072bd77ddc1aa  lea r12, [rax+0xC0]
000072bd77ddc1b1  movups xmm1, [r13+r12*1]
000072bd77ddc1b7  vmovaps xmm3, [rsp+0xC0]
000072bd77ddc1c0  vmovaps [rsp+0x80], xmm1
000072bd77ddc1c9  movaps xmm15, xmm3
000072bd77ddc1cd  addpd xmm15, xmm7
000072bd77ddc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000072bd77ddc1d8  ptest xmm1, xmm1
000072bd77ddc1dd  jnz 0x000072BD77DDE7E2
000072bd77ddc1e3  vmovaps [rsp+0xC0], xmm13
000072bd77ddc1ec  vmovaps xmm1, [rsp+0xC0]
000072bd77ddc1f5  por xmm13, xmm1
000072bd77ddc1fa  movaps [r15+0x270], xmm13
000072bd77ddc202  vmovaps xmm1, [rsp+0xB0]
000072bd77ddc20b  vmovaps xmm7, [rsp+0xB0]
000072bd77ddc214  por xmm1, xmm7
000072bd77ddc218  movaps [r15+0x1A0], xmm1
000072bd77ddc220  vmovaps xmm1, [rsp+0x60]
000072bd77ddc226  vpermilpd xmm1, xmm1, 0x00
000072bd77ddc22c  vmovaps [rsp+0xB0], xmm1
000072bd77ddc235  vmovaps xmm1, [rsp+0x80]
000072bd77ddc23e  vmovaps [rsp+0x80], xmm15
000072bd77ddc247  vmovaps xmm15, [rsp+0xB0]
000072bd77ddc250  vmovaps [rsp+0xB0], xmm14
000072bd77ddc259  movaps xmm3, xmm1
000072bd77ddc25c  mulpd xmm3, xmm15
000072bd77ddc261  vcmppd xmm14, xmm3, xmm3, 0x03
000072bd77ddc266  ptest xmm14, xmm14
000072bd77ddc26c  jnz 0x000072BD77DDE924
000072bd77ddc272  lea r12, [rax+0x20]
000072bd77ddc276  movups xmm1, [r13+r12*1]
000072bd77ddc27c  movaps [r15+0x110], xmm1
000072bd77ddc284  vmovaps xmm14, [rsp+0x70]
000072bd77ddc28a  vmovaps [rsp+0x70], xmm1
000072bd77ddc290  movaps xmm15, xmm14
000072bd77ddc294  addpd xmm15, xmm4
000072bd77ddc299  vcmppd xmm1, xmm15, xmm15, 0x03
000072bd77ddc29f  ptest xmm1, xmm1
000072bd77ddc2a4  jnz 0x000072BD77DDEA6F
000072bd77ddc2aa  vmovaps xmm1, [rsp+0x60]
000072bd77ddc2b0  vpermilpd xmm1, xmm1, 0x00
000072bd77ddc2b6  movaps xmm14, xmm2
000072bd77ddc2ba  mulpd xmm14, xmm1
000072bd77ddc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000072bd77ddc2c5  ptest xmm4, xmm4
000072bd77ddc2ca  jnz 0x000072BD77DDEBB2
000072bd77ddc2d0  vmovaps xmm4, [rsp+0x50]
000072bd77ddc2d6  movaps xmm1, xmm4
000072bd77ddc2d9  addpd xmm1, xmm9
000072bd77ddc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000072bd77ddc2e3  ptest xmm2, xmm2
000072bd77ddc2e8  jnz 0x000072BD77DDECF4
000072bd77ddc2ee  vmovaps xmm9, [rsp+0x30]
000072bd77ddc2f4  vpermilpd xmm9, xmm9, 0x00
000072bd77ddc2fa  vmovaps xmm2, [rsp+0x70]
000072bd77ddc300  vmovaps [rsp+0x50], xmm1
000072bd77ddc306  movaps xmm4, xmm2
000072bd77ddc309  mulpd xmm4, xmm9
000072bd77ddc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000072bd77ddc313  ptest xmm1, xmm1
000072bd77ddc318  jnz 0x000072BD77DDEE35
000072bd77ddc31e  vmovaps xmm1, [rsp+0x30]
000072bd77ddc324  vpermilpd xmm1, xmm1, 0x00
000072bd77ddc32a  vmovaps xmm2, [rsp+0x90]
000072bd77ddc333  vmovaps [rsp+0x60], xmm15
000072bd77ddc339  movaps xmm9, xmm2
000072bd77ddc33d  mulpd xmm9, xmm1
000072bd77ddc342  vcmppd xmm15, xmm9, xmm9, 0x03
000072bd77ddc348  ptest xmm15, xmm15
000072bd77ddc34e  jnz 0x000072BD77DDEF76
000072bd77ddc354  vmovaps xmm15, [rsp+0x80]
000072bd77ddc35d  movaps xmm1, xmm15
000072bd77ddc361  addpd xmm1, xmm6
000072bd77ddc365  vcmppd xmm2, xmm1, xmm1, 0x03
000072bd77ddc36a  ptest xmm2, xmm2
000072bd77ddc36f  jnz 0x000072BD77DDF0B8
000072bd77ddc375  movaps xmm15, xmm5
000072bd77ddc379  addpd xmm15, xmm3
000072bd77ddc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000072bd77ddc384  ptest xmm6, xmm6
000072bd77ddc389  jnz 0x000072BD77DDF1F9
000072bd77ddc38f  vmovaps xmm6, [rsp+0x30]
000072bd77ddc395  vpermilpd xmm6, xmm6, 0x00
000072bd77ddc39b  movaps xmm5, xmm8
000072bd77ddc39f  mulpd xmm5, xmm6
000072bd77ddc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000072bd77ddc3a8  ptest xmm3, xmm3
000072bd77ddc3ad  jnz 0x000072BD77DDF33B
000072bd77ddc3b3  vmovaps xmm8, [rsp+0x30]
000072bd77ddc3b9  vpermilpd xmm8, xmm8, 0x00
000072bd77ddc3bf  movaps xmm6, xmm10
000072bd77ddc3c3  mulpd xmm6, xmm8
000072bd77ddc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000072bd77ddc3cd  ptest xmm3, xmm3
000072bd77ddc3d2  jnz 0x000072BD77DDF47C
000072bd77ddc3d8  vmovaps xmm8, [rsp+0x60]
000072bd77ddc3de  movaps xmm10, xmm8
000072bd77ddc3e2  addpd xmm10, xmm14
000072bd77ddc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000072bd77ddc3ed  ptest xmm3, xmm3
000072bd77ddc3f2  jnz 0x000072BD77DDF5BE
000072bd77ddc3f8  vmovaps xmm8, [rsp+0x50]
000072bd77ddc3fe  movaps xmm14, xmm8
000072bd77ddc402  addpd xmm14, xmm4
000072bd77ddc407  vcmppd xmm3, xmm14, xmm14, 0x03
000072bd77ddc40d  ptest xmm3, xmm3
000072bd77ddc412  jnz 0x000072BD77DDF702
000072bd77ddc418  vmovaps xmm8, [rsp+0x40]
000072bd77ddc41e  vpermilpd xmm8, xmm8, 0x00
000072bd77ddc424  movaps xmm4, xmm13
000072bd77ddc428  mulpd xmm4, xmm8
000072bd77ddc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000072bd77ddc432  ptest xmm3, xmm3
000072bd77ddc437  jnz 0x000072BD77DDF845
000072bd77ddc43d  movaps xmm13, xmm15
000072bd77ddc441  addpd xmm13, xmm9
000072bd77ddc446  vcmppd xmm8, xmm13, xmm13, 0x03
000072bd77ddc44c  ptest xmm8, xmm8
000072bd77ddc452  jnz 0x000072BD77DDF987
000072bd77ddc458  movaps xmm15, xmm1
000072bd77ddc45c  addpd xmm15, xmm5
000072bd77ddc461  vcmppd xmm9, xmm15, xmm15, 0x03
000072bd77ddc467  ptest xmm9, xmm9
000072bd77ddc46d  jnz 0x000072BD77DDFACB
000072bd77ddc473  vmovaps [rsp+0x30], xmm11
000072bd77ddc479  vmovaps xmm1, [rsp+0x30]
000072bd77ddc47f  por xmm11, xmm1
000072bd77ddc484  movaps [r15+0x250], xmm11
000072bd77ddc48c  vmovaps [rsp+0x30], xmm12
000072bd77ddc492  vmovaps xmm1, [rsp+0x30]
000072bd77ddc498  por xmm12, xmm1
000072bd77ddc49d  movaps [r15+0x2A0], xmm12
000072bd77ddc4a5  vmovaps xmm1, [rsp+0xA0]
000072bd77ddc4ae  vmovaps xmm11, [rsp+0xA0]
000072bd77ddc4b7  por xmm1, xmm11
000072bd77ddc4bc  movaps [r15+0x1D0], xmm1
000072bd77ddc4c4  lea r12, [rax+0x40]
000072bd77ddc4c8  movups xmm1, [r13+r12*1]
000072bd77ddc4ce  movaps [r15+0x2C0], xmm1
000072bd77ddc4d6  vmovaps xmm11, [rsp+0x40]
000072bd77ddc4dc  vpermilpd xmm11, xmm11, 0x00
000072bd77ddc4e2  vmovaps xmm8, [rsp+0xE0]
000072bd77ddc4eb  movaps xmm9, xmm8
000072bd77ddc4ef  mulpd xmm9, xmm11
000072bd77ddc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000072bd77ddc4fa  ptest xmm5, xmm5
000072bd77ddc4ff  jnz 0x000072BD77DDFC17
000072bd77ddc505  movaps xmm11, xmm10
000072bd77ddc509  addpd xmm11, xmm6
000072bd77ddc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000072bd77ddc514  ptest xmm8, xmm8
000072bd77ddc51a  jnz 0x000072BD77DDFD5B
000072bd77ddc520  movaps xmm10, xmm14
000072bd77ddc524  addpd xmm10, xmm4
000072bd77ddc529  vcmppd xmm8, xmm10, xmm10, 0x03
000072bd77ddc52f  ptest xmm8, xmm8
000072bd77ddc535  jnz 0x000072BD77DDFE9E
000072bd77ddc53b  vmovaps xmm14, [rsp+0x40]
000072bd77ddc541  vpermilpd xmm14, xmm14, 0x00
000072bd77ddc547  movaps xmm8, xmm1
000072bd77ddc54b  mulpd xmm8, xmm14
000072bd77ddc550  vcmppd xmm6, xmm8, xmm8, 0x03
000072bd77ddc556  ptest xmm6, xmm6
000072bd77ddc55b  jnz 0x000072BD77DDFFE1
000072bd77ddc561  movaps xmm1, [r15+0x2B0]
000072bd77ddc569  vmovaps xmm14, [rsp+0x40]
000072bd77ddc56f  vpermilpd xmm14, xmm14, 0x00
000072bd77ddc575  movaps xmm6, xmm1
000072bd77ddc578  mulpd xmm6, xmm14
000072bd77ddc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000072bd77ddc582  ptest xmm5, xmm5
000072bd77ddc587  jnz 0x000072BD77DE0124
000072bd77ddc58d  vmovaps xmm1, [rsp+0x10]
000072bd77ddc593  vpermilpd xmm1, xmm1, 0x00
000072bd77ddc599  movaps xmm14, xmm12
000072bd77ddc59d  mulpd xmm14, xmm1
000072bd77ddc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000072bd77ddc5a8  ptest xmm5, xmm5
000072bd77ddc5ad  jnz 0x000072BD77DE0265
000072bd77ddc5b3  movaps xmm1, xmm13
000072bd77ddc5b7  addpd xmm1, xmm9
000072bd77ddc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000072bd77ddc5c1  ptest xmm12, xmm12
000072bd77ddc5c7  jnz 0x000072BD77DE03A8
000072bd77ddc5cd  vmovaps xmm13, [rsp+0x10]
000072bd77ddc5d3  vpermilpd xmm13, xmm13, 0x00
000072bd77ddc5d9  movaps xmm12, xmm7
000072bd77ddc5dd  mulpd xmm12, xmm13
000072bd77ddc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000072bd77ddc5e8  ptest xmm9, xmm9
000072bd77ddc5ee  jnz 0x000072BD77DE04EA
000072bd77ddc5f4  movaps xmm13, xmm15
000072bd77ddc5f8  addpd xmm13, xmm8
000072bd77ddc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000072bd77ddc603  ptest xmm9, xmm9
000072bd77ddc609  jnz 0x000072BD77DE062D
000072bd77ddc60f  movaps xmm15, [r15+0x290]
000072bd77ddc617  vmovaps xmm9, [rsp+0x10]
000072bd77ddc61d  vpermilpd xmm9, xmm9, 0x00
000072bd77ddc623  movaps xmm8, xmm15
000072bd77ddc627  mulpd xmm8, xmm9
000072bd77ddc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000072bd77ddc632  ptest xmm7, xmm7
000072bd77ddc637  jnz 0x000072BD77DE0771
000072bd77ddc63d  movaps xmm15, xmm11
000072bd77ddc641  addpd xmm15, xmm6
000072bd77ddc646  vcmppd xmm9, xmm15, xmm15, 0x03
000072bd77ddc64c  ptest xmm9, xmm9
000072bd77ddc652  jnz 0x000072BD77DE08B5
000072bd77ddc658  movaps xmm11, [r15+0x1E0]
000072bd77ddc660  vmovaps xmm9, [rsp+0x10]
000072bd77ddc666  vpermilpd xmm9, xmm9, 0x00
000072bd77ddc66c  movaps xmm7, xmm11
000072bd77ddc670  mulpd xmm7, xmm9
000072bd77ddc675  vcmppd xmm6, xmm7, xmm7, 0x03
000072bd77ddc67a  ptest xmm6, xmm6
000072bd77ddc67f  jnz 0x000072BD77DE09F8
000072bd77ddc685  movaps xmm11, xmm10
000072bd77ddc689  addpd xmm11, xmm14
000072bd77ddc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000072bd77ddc694  ptest xmm9, xmm9
000072bd77ddc69a  jnz 0x000072BD77DE0B3A
000072bd77ddc6a0  lea r12, [rax+0x70]
000072bd77ddc6a4  movups xmm14, [r13+r12*1]
000072bd77ddc6aa  movaps [r15+0x240], xmm14
000072bd77ddc6b2  movaps xmm10, xmm1
000072bd77ddc6b6  addpd xmm10, xmm12
000072bd77ddc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000072bd77ddc6c1  ptest xmm9, xmm9
000072bd77ddc6c7  jnz 0x000072BD77DE0C88
000072bd77ddc6cd  movaps [r15+0x170], xmm10
000072bd77ddc6d5  vmovaps xmm1, [rsp+0x20]
000072bd77ddc6db  vpermilpd xmm1, xmm1, 0x00
000072bd77ddc6e1  movaps xmm12, xmm14
000072bd77ddc6e5  mulpd xmm12, xmm1
000072bd77ddc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000072bd77ddc6f0  ptest xmm9, xmm9
000072bd77ddc6f6  jnz 0x000072BD77DE0DCB
000072bd77ddc6fc  vmovaps xmm1, [rsp+0x20]
000072bd77ddc702  vpermilpd xmm1, xmm1, 0x00
000072bd77ddc708  vmovaps xmm9, [rsp+0xB0]
000072bd77ddc711  movaps xmm14, xmm9
000072bd77ddc715  mulpd xmm14, xmm1
000072bd77ddc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000072bd77ddc720  ptest xmm6, xmm6
000072bd77ddc725  jnz 0x000072BD77DE0F0E
000072bd77ddc72b  movaps [r15+0x180], xmm14
000072bd77ddc733  movaps xmm1, xmm13
000072bd77ddc737  addpd xmm1, xmm8
000072bd77ddc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000072bd77ddc741  ptest xmm9, xmm9
000072bd77ddc747  jnz 0x000072BD77DE1051
000072bd77ddc74d  movaps [r15+0x210], xmm1
000072bd77ddc755  movups xmm13, [r13+rax*1]
000072bd77ddc75b  lea r12, [rax+0x10]
000072bd77ddc75f  movups xmm9, [r13+r12*1]
000072bd77ddc765  movaps [r15+0x230], xmm9
000072bd77ddc76d  movaps xmm8, xmm15
000072bd77ddc771  addpd xmm8, xmm7
000072bd77ddc776  vcmppd xmm6, xmm8, xmm8, 0x03
000072bd77ddc77c  ptest xmm6, xmm6
000072bd77ddc781  jnz 0x000072BD77DE11A7
000072bd77ddc787  movaps [r15+0x130], xmm8
000072bd77ddc78f  vmovaps xmm15, [rsp+0x20]
000072bd77ddc795  vpermilpd xmm15, xmm15, 0x00
000072bd77ddc79b  movaps xmm7, xmm9
000072bd77ddc79f  mulpd xmm7, xmm15
000072bd77ddc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000072bd77ddc7a9  ptest xmm6, xmm6
000072bd77ddc7ae  jnz 0x000072BD77DE12EA
000072bd77ddc7b4  movaps [r15+0x220], xmm7
000072bd77ddc7bc  vmovaps xmm15, [rsp+0x20]
000072bd77ddc7c2  vpermilpd xmm15, xmm15, 0x00
000072bd77ddc7c8  movaps xmm9, xmm13
000072bd77ddc7cc  mulpd xmm9, xmm15
000072bd77ddc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000072bd77ddc7d7  ptest xmm6, xmm6
000072bd77ddc7dc  jnz 0x000072BD77DE142C
000072bd77ddc7e2  movaps xmm15, xmm11
000072bd77ddc7e6  addpd xmm15, xmm12
000072bd77ddc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000072bd77ddc7f1  ptest xmm13, xmm13
000072bd77ddc7f7  jnz 0x000072BD77DE1570
000072bd77ddc7fd  movaps [r15+0x140], xmm15
000072bd77ddc805  movaps xmm13, xmm10
000072bd77ddc809  addpd xmm13, xmm14
000072bd77ddc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000072bd77ddc814  ptest xmm12, xmm12
000072bd77ddc81a  jnz 0x000072BD77DE16B4
000072bd77ddc820  movaps [r15+0x150], xmm13
000072bd77ddc828  movaps xmm14, xmm1
000072bd77ddc82c  addpd xmm14, xmm7
000072bd77ddc831  vcmppd xmm12, xmm14, xmm14, 0x03
000072bd77ddc837  ptest xmm12, xmm12
000072bd77ddc83d  jnz 0x000072BD77DE17F8
000072bd77ddc843  movaps [r15+0x160], xmm14
000072bd77ddc84b  movaps xmm1, xmm8
000072bd77ddc84f  addpd xmm1, xmm9
000072bd77ddc854  vcmppd xmm12, xmm1, xmm1, 0x03
000072bd77ddc859  ptest xmm12, xmm12
000072bd77ddc85f  jnz 0x000072BD77DE193A
000072bd77ddc865  movaps [r15+0x120], xmm1
000072bd77ddc86d  movups [r13+r14*1], xmm15
000072bd77ddc873  lea rax, [r14+0x10]
000072bd77ddc877  movups [r13+rax*1], xmm13
000072bd77ddc87d  lea rax, [r14+0x20]
000072bd77ddc881  movups [r13+rax*1], xmm14
000072bd77ddc887  lea rax, [r14+0x30]
000072bd77ddc88b  movups [r13+rax*1], xmm1
000072bd77ddc891  mov eax, [r15+0x108]
000072bd77ddc898  sahf
000072bd77ddc899  jnz 0x000072BD77DDC8CB
000072bd77ddc89b  cmp dword ptr [r15+0x318], 0x00
000072bd77ddc8a3  jz 0x000072BD77DDB900
000072bd77ddc8a9  nop [rax+rax*1], ax
000072bd77ddc8b2  nop [rax+rax*1], eax
000072bd77ddc8ba  mov eax, 0x410444
000072bd77ddc8bf  mov [r15+0x100], rax
000072bd77ddc8c6  jmp 0x000072BD77BFE110
000072bd77ddc8cb  cmp dword ptr [r15+0x318], 0x00
000072bd77ddc8d3  jz 0x000072BD77DD57E0
000072bd77ddc8d9  nop [rax+rax*1], ax
000072bd77ddc8e2  nop [rax+rax*1], eax
000072bd77ddc8ea  mov eax, 0x410278
000072bd77ddc8ef  mov [r15+0x100], rax
000072bd77ddc8f6  jmp 0x000072BD77BFE110
000072bd77ddc8fb  int3
000072bd77ddc8fc  call 0x000072BD77CE27E0
000072bd77ddc901  jmp 0x000072BD77DDB9DF
000072bd77ddc906  call 0x000072BD77CE1570
000072bd77ddc90b  jmp 0x000072BD77DDB9E8
000072bd77ddc910  call 0x000072BD77CE27E0
000072bd77ddc915  jmp 0x000072BD77DDBA44
000072bd77ddc91a  call 0x000072BD77CE1570
000072bd77ddc91f  jmp 0x000072BD77DDBA4D
000072bd77ddc924  call 0x000072BD77CE27E0
000072bd77ddc929  jmp 0x000072BD77DDBA90
000072bd77ddc92e  call 0x000072BD77CE1570
000072bd77ddc933  jmp 0x000072BD77DDBA99
000072bd77ddc938  call 0x000072BD77C0DC20
000072bd77ddc93d  jmp 0x000072BD77DDBAD8
000072bd77ddc942  call 0x000072BD77CD59C0
000072bd77ddc947  jmp 0x000072BD77DDBAEB
000072bd77ddc94c  call 0x000072BD77CE0E30
000072bd77ddc951  jmp 0x000072BD77DDBB09
000072bd77ddc956  call 0x000072BD77CDFBC0
000072bd77ddc95b  jmp 0x000072BD77DDBB13
000072bd77ddc960  call 0x000072BD77CDE950
000072bd77ddc965  jmp 0x000072BD77DDBB1D
000072bd77ddc96a  sub rsp, 0x08
000072bd77ddc96e  push rax
000072bd77ddc96f  push rcx
000072bd77ddc970  push rdx
000072bd77ddc971  push rdi
000072bd77ddc972  push rsi
000072bd77ddc973  push r8
000072bd77ddc975  push r9
000072bd77ddc977  push r10
000072bd77ddc979  push r11
000072bd77ddc97b  sub rsp, 0xF0
000072bd77ddc982  vmovaps [rsp], xmm0
000072bd77ddc987  vmovaps [rsp+0x10], xmm1
000072bd77ddc98d  vmovaps [rsp+0x20], xmm2
000072bd77ddc993  vmovaps [rsp+0x30], xmm3
000072bd77ddc999  vmovaps [rsp+0x40], xmm4
000072bd77ddc99f  vmovaps [rsp+0x50], xmm5
000072bd77ddc9a5  vmovaps [rsp+0x60], xmm6
000072bd77ddc9ab  vmovaps [rsp+0x70], xmm7
000072bd77ddc9b1  vmovaps [rsp+0x80], xmm9
000072bd77ddc9ba  vmovaps [rsp+0x90], xmm10
000072bd77ddc9c3  vmovaps [rsp+0xA0], xmm11
000072bd77ddc9cc  vmovaps [rsp+0xB0], xmm12
000072bd77ddc9d5  vmovaps [rsp+0xC0], xmm13
000072bd77ddc9de  vmovaps [rsp+0xD0], xmm14
000072bd77ddc9e7  vmovaps [rsp+0xE0], xmm15
000072bd77ddc9f0  sub rsp, 0x30
000072bd77ddc9f4  movaps [rsp], xmm8
000072bd77ddc9f9  movaps [rsp+0x10], xmm12
000072bd77ddc9ff  movaps [rsp+0x20], xmm15
000072bd77ddca05  lea rdi, [rsp]
000072bd77ddca09  mov esi, 0x00
000072bd77ddca0e  mov rax, 0x643206AC3530
000072bd77ddca18  call rax
000072bd77ddca1a  movaps xmm8, [rsp]
000072bd77ddca1f  add rsp, 0x30
000072bd77ddca23  vmovaps xmm0, [rsp]
000072bd77ddca28  vmovaps xmm1, [rsp+0x10]
000072bd77ddca2e  vmovaps xmm2, [rsp+0x20]
000072bd77ddca34  vmovaps xmm3, [rsp+0x30]
000072bd77ddca3a  vmovaps xmm4, [rsp+0x40]
000072bd77ddca40  vmovaps xmm5, [rsp+0x50]
000072bd77ddca46  vmovaps xmm6, [rsp+0x60]
000072bd77ddca4c  vmovaps xmm7, [rsp+0x70]
000072bd77ddca52  vmovaps xmm9, [rsp+0x80]
000072bd77ddca5b  vmovaps xmm10, [rsp+0x90]
000072bd77ddca64  vmovaps xmm11, [rsp+0xA0]
000072bd77ddca6d  vmovaps xmm12, [rsp+0xB0]
000072bd77ddca76  vmovaps xmm13, [rsp+0xC0]
000072bd77ddca7f  vmovaps xmm14, [rsp+0xD0]
000072bd77ddca88  vmovaps xmm15, [rsp+0xE0]
000072bd77ddca91  add rsp, 0xF0
000072bd77ddca98  pop r11
000072bd77ddca9a  pop r10
000072bd77ddca9c  pop r9
000072bd77ddca9e  pop r8
000072bd77ddcaa0  pop rsi
000072bd77ddcaa1  pop rdi
000072bd77ddcaa2  pop rdx
000072bd77ddcaa3  pop rcx
000072bd77ddcaa4  pop rax
000072bd77ddcaa5  add rsp, 0x08
000072bd77ddcaa9  jmp 0x000072BD77DDBB47
000072bd77ddcaae  sub rsp, 0x08
000072bd77ddcab2  push rax
000072bd77ddcab3  push rcx
000072bd77ddcab4  push rdx
000072bd77ddcab5  push rdi
000072bd77ddcab6  push rsi
000072bd77ddcab7  push r8
000072bd77ddcab9  push r9
000072bd77ddcabb  push r10
000072bd77ddcabd  push r11
000072bd77ddcabf  sub rsp, 0xF0
000072bd77ddcac6  vmovaps [rsp], xmm0
000072bd77ddcacb  vmovaps [rsp+0x10], xmm1
000072bd77ddcad1  vmovaps [rsp+0x20], xmm2
000072bd77ddcad7  vmovaps [rsp+0x30], xmm3
000072bd77ddcadd  vmovaps [rsp+0x40], xmm4
000072bd77ddcae3  vmovaps [rsp+0x50], xmm5
000072bd77ddcae9  vmovaps [rsp+0x60], xmm6
000072bd77ddcaef  vmovaps [rsp+0x70], xmm8
000072bd77ddcaf5  vmovaps [rsp+0x80], xmm9
000072bd77ddcafe  vmovaps [rsp+0x90], xmm10
000072bd77ddcb07  vmovaps [rsp+0xA0], xmm11
000072bd77ddcb10  vmovaps [rsp+0xB0], xmm12
000072bd77ddcb19  vmovaps [rsp+0xC0], xmm13
000072bd77ddcb22  vmovaps [rsp+0xD0], xmm14
000072bd77ddcb2b  vmovaps [rsp+0xE0], xmm15
000072bd77ddcb34  sub rsp, 0x30
000072bd77ddcb38  movaps [rsp], xmm7
000072bd77ddcb3c  movaps [rsp+0x10], xmm9
000072bd77ddcb42  movaps [rsp+0x20], xmm15
000072bd77ddcb48  lea rdi, [rsp]
000072bd77ddcb4c  mov esi, 0x00
000072bd77ddcb51  mov rax, 0x643206AC3530
000072bd77ddcb5b  call rax
000072bd77ddcb5d  movaps xmm7, [rsp]
000072bd77ddcb61  add rsp, 0x30
000072bd77ddcb65  vmovaps xmm0, [rsp]
000072bd77ddcb6a  vmovaps xmm1, [rsp+0x10]
000072bd77ddcb70  vmovaps xmm2, [rsp+0x20]
000072bd77ddcb76  vmovaps xmm3, [rsp+0x30]
000072bd77ddcb7c  vmovaps xmm4, [rsp+0x40]
000072bd77ddcb82  vmovaps xmm5, [rsp+0x50]
000072bd77ddcb88  vmovaps xmm6, [rsp+0x60]
000072bd77ddcb8e  vmovaps xmm8, [rsp+0x70]
000072bd77ddcb94  vmovaps xmm9, [rsp+0x80]
000072bd77ddcb9d  vmovaps xmm10, [rsp+0x90]
000072bd77ddcba6  vmovaps xmm11, [rsp+0xA0]
000072bd77ddcbaf  vmovaps xmm12, [rsp+0xB0]
000072bd77ddcbb8  vmovaps xmm13, [rsp+0xC0]
000072bd77ddcbc1  vmovaps xmm14, [rsp+0xD0]
000072bd77ddcbca  vmovaps xmm15, [rsp+0xE0]
000072bd77ddcbd3  add rsp, 0xF0
000072bd77ddcbda  pop r11
000072bd77ddcbdc  pop r10
000072bd77ddcbde  pop r9
000072bd77ddcbe0  pop r8
000072bd77ddcbe2  pop rsi
000072bd77ddcbe3  pop rdi
000072bd77ddcbe4  pop rdx
000072bd77ddcbe5  pop rcx
000072bd77ddcbe6  pop rax
000072bd77ddcbe7  add rsp, 0x08
000072bd77ddcbeb  jmp 0x000072BD77DDBB75
000072bd77ddcbf0  sub rsp, 0x08
000072bd77ddcbf4  push rax
000072bd77ddcbf5  push rcx
000072bd77ddcbf6  push rdx
000072bd77ddcbf7  push rdi
000072bd77ddcbf8  push rsi
000072bd77ddcbf9  push r8
000072bd77ddcbfb  push r9
000072bd77ddcbfd  push r10
000072bd77ddcbff  push r11
000072bd77ddcc01  sub rsp, 0xF0
000072bd77ddcc08  vmovaps [rsp], xmm0
000072bd77ddcc0d  vmovaps [rsp+0x10], xmm1
000072bd77ddcc13  vmovaps [rsp+0x20], xmm2
000072bd77ddcc19  vmovaps [rsp+0x30], xmm3
000072bd77ddcc1f  vmovaps [rsp+0x40], xmm4
000072bd77ddcc25  vmovaps [rsp+0x50], xmm5
000072bd77ddcc2b  vmovaps [rsp+0x60], xmm6
000072bd77ddcc31  vmovaps [rsp+0x70], xmm7
000072bd77ddcc37  vmovaps [rsp+0x80], xmm8
000072bd77ddcc40  vmovaps [rsp+0x90], xmm10
000072bd77ddcc49  vmovaps [rsp+0xA0], xmm11
000072bd77ddcc52  vmovaps [rsp+0xB0], xmm12
000072bd77ddcc5b  vmovaps [rsp+0xC0], xmm13
000072bd77ddcc64  vmovaps [rsp+0xD0], xmm14
000072bd77ddcc6d  vmovaps [rsp+0xE0], xmm15
000072bd77ddcc76  sub rsp, 0x30
000072bd77ddcc7a  movaps [rsp], xmm9
000072bd77ddcc7f  movaps [rsp+0x10], xmm12
000072bd77ddcc85  movaps [rsp+0x20], xmm10
000072bd77ddcc8b  lea rdi, [rsp]
000072bd77ddcc8f  mov esi, 0x00
000072bd77ddcc94  mov rax, 0x643206AC3530
000072bd77ddcc9e  call rax
000072bd77ddcca0  movaps xmm9, [rsp]
000072bd77ddcca5  add rsp, 0x30
000072bd77ddcca9  vmovaps xmm0, [rsp]
000072bd77ddccae  vmovaps xmm1, [rsp+0x10]
000072bd77ddccb4  vmovaps xmm2, [rsp+0x20]
000072bd77ddccba  vmovaps xmm3, [rsp+0x30]
000072bd77ddccc0  vmovaps xmm4, [rsp+0x40]
000072bd77ddccc6  vmovaps xmm5, [rsp+0x50]
000072bd77ddcccc  vmovaps xmm6, [rsp+0x60]
000072bd77ddccd2  vmovaps xmm7, [rsp+0x70]
000072bd77ddccd8  vmovaps xmm8, [rsp+0x80]
000072bd77ddcce1  vmovaps xmm10, [rsp+0x90]
000072bd77ddccea  vmovaps xmm11, [rsp+0xA0]
000072bd77ddccf3  vmovaps xmm12, [rsp+0xB0]
000072bd77ddccfc  vmovaps xmm13, [rsp+0xC0]
000072bd77ddcd05  vmovaps xmm14, [rsp+0xD0]
000072bd77ddcd0e  vmovaps xmm15, [rsp+0xE0]
000072bd77ddcd17  add rsp, 0xF0
000072bd77ddcd1e  pop r11
000072bd77ddcd20  pop r10
000072bd77ddcd22  pop r9
000072bd77ddcd24  pop r8
000072bd77ddcd26  pop rsi
000072bd77ddcd27  pop rdi
000072bd77ddcd28  pop rdx
000072bd77ddcd29  pop rcx
000072bd77ddcd2a  pop rax
000072bd77ddcd2b  add rsp, 0x08
000072bd77ddcd2f  jmp 0x000072BD77DDBB99
000072bd77ddcd34  sub rsp, 0x08
000072bd77ddcd38  push rax
000072bd77ddcd39  push rcx
000072bd77ddcd3a  push rdx
000072bd77ddcd3b  push rdi
000072bd77ddcd3c  push rsi
000072bd77ddcd3d  push r8
000072bd77ddcd3f  push r9
000072bd77ddcd41  push r10
000072bd77ddcd43  push r11
000072bd77ddcd45  sub rsp, 0xF0
000072bd77ddcd4c  vmovaps [rsp], xmm0
000072bd77ddcd51  vmovaps [rsp+0x10], xmm1
000072bd77ddcd57  vmovaps [rsp+0x20], xmm2
000072bd77ddcd5d  vmovaps [rsp+0x30], xmm3
000072bd77ddcd63  vmovaps [rsp+0x40], xmm4
000072bd77ddcd69  vmovaps [rsp+0x50], xmm5
000072bd77ddcd6f  vmovaps [rsp+0x60], xmm6
000072bd77ddcd75  vmovaps [rsp+0x70], xmm7
000072bd77ddcd7b  vmovaps [rsp+0x80], xmm8
000072bd77ddcd84  vmovaps [rsp+0x90], xmm9
000072bd77ddcd8d  vmovaps [rsp+0xA0], xmm11
000072bd77ddcd96  vmovaps [rsp+0xB0], xmm12
000072bd77ddcd9f  vmovaps [rsp+0xC0], xmm13
000072bd77ddcda8  vmovaps [rsp+0xD0], xmm14
000072bd77ddcdb1  vmovaps [rsp+0xE0], xmm15
000072bd77ddcdba  sub rsp, 0x30
000072bd77ddcdbe  movaps [rsp], xmm10
000072bd77ddcdc3  movaps [rsp+0x10], xmm12
000072bd77ddcdc9  movaps [rsp+0x20], xmm11
000072bd77ddcdcf  lea rdi, [rsp]
000072bd77ddcdd3  mov esi, 0x00
000072bd77ddcdd8  mov rax, 0x643206AC3530
000072bd77ddcde2  call rax
000072bd77ddcde4  movaps xmm10, [rsp]
000072bd77ddcde9  add rsp, 0x30
000072bd77ddcded  vmovaps xmm0, [rsp]
000072bd77ddcdf2  vmovaps xmm1, [rsp+0x10]
000072bd77ddcdf8  vmovaps xmm2, [rsp+0x20]
000072bd77ddcdfe  vmovaps xmm3, [rsp+0x30]
000072bd77ddce04  vmovaps xmm4, [rsp+0x40]
000072bd77ddce0a  vmovaps xmm5, [rsp+0x50]
000072bd77ddce10  vmovaps xmm6, [rsp+0x60]
000072bd77ddce16  vmovaps xmm7, [rsp+0x70]
000072bd77ddce1c  vmovaps xmm8, [rsp+0x80]
000072bd77ddce25  vmovaps xmm9, [rsp+0x90]
000072bd77ddce2e  vmovaps xmm11, [rsp+0xA0]
000072bd77ddce37  vmovaps xmm12, [rsp+0xB0]
000072bd77ddce40  vmovaps xmm13, [rsp+0xC0]
000072bd77ddce49  vmovaps xmm14, [rsp+0xD0]
000072bd77ddce52  vmovaps xmm15, [rsp+0xE0]
000072bd77ddce5b  add rsp, 0xF0
000072bd77ddce62  pop r11
000072bd77ddce64  pop r10
000072bd77ddce66  pop r9
000072bd77ddce68  pop r8
000072bd77ddce6a  pop rsi
000072bd77ddce6b  pop rdi
000072bd77ddce6c  pop rdx
000072bd77ddce6d  pop rcx
000072bd77ddce6e  pop rax
000072bd77ddce6f  add rsp, 0x08
000072bd77ddce73  jmp 0x000072BD77DDBBB3
000072bd77ddce78  sub rsp, 0x08
000072bd77ddce7c  push rax
000072bd77ddce7d  push rcx
000072bd77ddce7e  push rdx
000072bd77ddce7f  push rdi
000072bd77ddce80  push rsi
000072bd77ddce81  push r8
000072bd77ddce83  push r9
000072bd77ddce85  push r10
000072bd77ddce87  push r11
000072bd77ddce89  sub rsp, 0xF0
000072bd77ddce90  vmovaps [rsp], xmm0
000072bd77ddce95  vmovaps [rsp+0x10], xmm1
000072bd77ddce9b  vmovaps [rsp+0x20], xmm2
000072bd77ddcea1  vmovaps [rsp+0x30], xmm3
000072bd77ddcea7  vmovaps [rsp+0x40], xmm4
000072bd77ddcead  vmovaps [rsp+0x50], xmm5
000072bd77ddceb3  vmovaps [rsp+0x60], xmm7
000072bd77ddceb9  vmovaps [rsp+0x70], xmm8
000072bd77ddcebf  vmovaps [rsp+0x80], xmm9
000072bd77ddcec8  vmovaps [rsp+0x90], xmm10
000072bd77ddced1  vmovaps [rsp+0xA0], xmm11
000072bd77ddceda  vmovaps [rsp+0xB0], xmm12
000072bd77ddcee3  vmovaps [rsp+0xC0], xmm13
000072bd77ddceec  vmovaps [rsp+0xD0], xmm14
000072bd77ddcef5  vmovaps [rsp+0xE0], xmm15
000072bd77ddcefe  sub rsp, 0x30
000072bd77ddcf02  movaps [rsp], xmm6
000072bd77ddcf06  movaps [rsp+0x10], xmm12
000072bd77ddcf0c  movaps [rsp+0x20], xmm11
000072bd77ddcf12  lea rdi, [rsp]
000072bd77ddcf16  mov esi, 0x00
000072bd77ddcf1b  mov rax, 0x643206AC3530
000072bd77ddcf25  call rax
000072bd77ddcf27  movaps xmm6, [rsp]
000072bd77ddcf2b  add rsp, 0x30
000072bd77ddcf2f  vmovaps xmm0, [rsp]
000072bd77ddcf34  vmovaps xmm1, [rsp+0x10]
000072bd77ddcf3a  vmovaps xmm2, [rsp+0x20]
000072bd77ddcf40  vmovaps xmm3, [rsp+0x30]
000072bd77ddcf46  vmovaps xmm4, [rsp+0x40]
000072bd77ddcf4c  vmovaps xmm5, [rsp+0x50]
000072bd77ddcf52  vmovaps xmm7, [rsp+0x60]
000072bd77ddcf58  vmovaps xmm8, [rsp+0x70]
000072bd77ddcf5e  vmovaps xmm9, [rsp+0x80]
000072bd77ddcf67  vmovaps xmm10, [rsp+0x90]
000072bd77ddcf70  vmovaps xmm11, [rsp+0xA0]
000072bd77ddcf79  vmovaps xmm12, [rsp+0xB0]
000072bd77ddcf82  vmovaps xmm13, [rsp+0xC0]
000072bd77ddcf8b  vmovaps xmm14, [rsp+0xD0]
000072bd77ddcf94  vmovaps xmm15, [rsp+0xE0]
000072bd77ddcf9d  add rsp, 0xF0
000072bd77ddcfa4  pop r11
000072bd77ddcfa6  pop r10
000072bd77ddcfa8  pop r9
000072bd77ddcfaa  pop r8
000072bd77ddcfac  pop rsi
000072bd77ddcfad  pop rdi
000072bd77ddcfae  pop rdx
000072bd77ddcfaf  pop rcx
000072bd77ddcfb0  pop rax
000072bd77ddcfb1  add rsp, 0x08
000072bd77ddcfb5  jmp 0x000072BD77DDBBD4
000072bd77ddcfba  sub rsp, 0x08
000072bd77ddcfbe  push rax
000072bd77ddcfbf  push rcx
000072bd77ddcfc0  push rdx
000072bd77ddcfc1  push rdi
000072bd77ddcfc2  push rsi
000072bd77ddcfc3  push r8
000072bd77ddcfc5  push r9
000072bd77ddcfc7  push r10
000072bd77ddcfc9  push r11
000072bd77ddcfcb  sub rsp, 0xF0
000072bd77ddcfd2  vmovaps [rsp], xmm0
000072bd77ddcfd7  vmovaps [rsp+0x10], xmm1
000072bd77ddcfdd  vmovaps [rsp+0x20], xmm2
000072bd77ddcfe3  vmovaps [rsp+0x30], xmm4
000072bd77ddcfe9  vmovaps [rsp+0x40], xmm5
000072bd77ddcfef  vmovaps [rsp+0x50], xmm6
000072bd77ddcff5  vmovaps [rsp+0x60], xmm7
000072bd77ddcffb  vmovaps [rsp+0x70], xmm8
000072bd77ddd001  vmovaps [rsp+0x80], xmm9
000072bd77ddd00a  vmovaps [rsp+0x90], xmm10
000072bd77ddd013  vmovaps [rsp+0xA0], xmm11
000072bd77ddd01c  vmovaps [rsp+0xB0], xmm12
000072bd77ddd025  vmovaps [rsp+0xC0], xmm13
000072bd77ddd02e  vmovaps [rsp+0xD0], xmm14
000072bd77ddd037  vmovaps [rsp+0xE0], xmm15
000072bd77ddd040  sub rsp, 0x30
000072bd77ddd044  movaps [rsp], xmm3
000072bd77ddd048  movaps [rsp+0x10], xmm5
000072bd77ddd04d  movaps [rsp+0x20], xmm4
000072bd77ddd052  lea rdi, [rsp]
000072bd77ddd056  mov esi, 0x00
000072bd77ddd05b  mov rax, 0x643206AC3530
000072bd77ddd065  call rax
000072bd77ddd067  movaps xmm3, [rsp]
000072bd77ddd06b  add rsp, 0x30
000072bd77ddd06f  vmovaps xmm0, [rsp]
000072bd77ddd074  vmovaps xmm1, [rsp+0x10]
000072bd77ddd07a  vmovaps xmm2, [rsp+0x20]
000072bd77ddd080  vmovaps xmm4, [rsp+0x30]
000072bd77ddd086  vmovaps xmm5, [rsp+0x40]
000072bd77ddd08c  vmovaps xmm6, [rsp+0x50]
000072bd77ddd092  vmovaps xmm7, [rsp+0x60]
000072bd77ddd098  vmovaps xmm8, [rsp+0x70]
000072bd77ddd09e  vmovaps xmm9, [rsp+0x80]
000072bd77ddd0a7  vmovaps xmm10, [rsp+0x90]
000072bd77ddd0b0  vmovaps xmm11, [rsp+0xA0]
000072bd77ddd0b9  vmovaps xmm12, [rsp+0xB0]
000072bd77ddd0c2  vmovaps xmm13, [rsp+0xC0]
000072bd77ddd0cb  vmovaps xmm14, [rsp+0xD0]
000072bd77ddd0d4  vmovaps xmm15, [rsp+0xE0]
000072bd77ddd0dd  add rsp, 0xF0
000072bd77ddd0e4  pop r11
000072bd77ddd0e6  pop r10
000072bd77ddd0e8  pop r9
000072bd77ddd0ea  pop r8
000072bd77ddd0ec  pop rsi
000072bd77ddd0ed  pop rdi
000072bd77ddd0ee  pop rdx
000072bd77ddd0ef  pop rcx
000072bd77ddd0f0  pop rax
000072bd77ddd0f1  add rsp, 0x08
000072bd77ddd0f5  jmp 0x000072BD77DDBC35
000072bd77ddd0fa  sub rsp, 0x08
000072bd77ddd0fe  push rax
000072bd77ddd0ff  push rcx
000072bd77ddd100  push rdx
000072bd77ddd101  push rdi
000072bd77ddd102  push rsi
000072bd77ddd103  push r8
000072bd77ddd105  push r9
000072bd77ddd107  push r10
000072bd77ddd109  push r11
000072bd77ddd10b  sub rsp, 0xF0
000072bd77ddd112  vmovaps [rsp], xmm0
000072bd77ddd117  vmovaps [rsp+0x10], xmm1
000072bd77ddd11d  vmovaps [rsp+0x20], xmm2
000072bd77ddd123  vmovaps [rsp+0x30], xmm3
000072bd77ddd129  vmovaps [rsp+0x40], xmm4
000072bd77ddd12f  vmovaps [rsp+0x50], xmm6
000072bd77ddd135  vmovaps [rsp+0x60], xmm7
000072bd77ddd13b  vmovaps [rsp+0x70], xmm8
000072bd77ddd141  vmovaps [rsp+0x80], xmm9
000072bd77ddd14a  vmovaps [rsp+0x90], xmm10
000072bd77ddd153  vmovaps [rsp+0xA0], xmm11
000072bd77ddd15c  vmovaps [rsp+0xB0], xmm12
000072bd77ddd165  vmovaps [rsp+0xC0], xmm13
000072bd77ddd16e  vmovaps [rsp+0xD0], xmm14
000072bd77ddd177  vmovaps [rsp+0xE0], xmm15
000072bd77ddd180  sub rsp, 0x30
000072bd77ddd184  movaps [rsp], xmm5
000072bd77ddd188  movaps [rsp+0x10], xmm8
000072bd77ddd18e  movaps [rsp+0x20], xmm15
000072bd77ddd194  lea rdi, [rsp]
000072bd77ddd198  mov esi, 0x00
000072bd77ddd19d  mov rax, 0x643206AC3530
000072bd77ddd1a7  call rax
000072bd77ddd1a9  movaps xmm5, [rsp]
000072bd77ddd1ad  add rsp, 0x30
000072bd77ddd1b1  vmovaps xmm0, [rsp]
000072bd77ddd1b6  vmovaps xmm1, [rsp+0x10]
000072bd77ddd1bc  vmovaps xmm2, [rsp+0x20]
000072bd77ddd1c2  vmovaps xmm3, [rsp+0x30]
000072bd77ddd1c8  vmovaps xmm4, [rsp+0x40]
000072bd77ddd1ce  vmovaps xmm6, [rsp+0x50]
000072bd77ddd1d4  vmovaps xmm7, [rsp+0x60]
000072bd77ddd1da  vmovaps xmm8, [rsp+0x70]
000072bd77ddd1e0  vmovaps xmm9, [rsp+0x80]
000072bd77ddd1e9  vmovaps xmm10, [rsp+0x90]
000072bd77ddd1f2  vmovaps xmm11, [rsp+0xA0]
000072bd77ddd1fb  vmovaps xmm12, [rsp+0xB0]
000072bd77ddd204  vmovaps xmm13, [rsp+0xC0]
000072bd77ddd20d  vmovaps xmm14, [rsp+0xD0]
000072bd77ddd216  vmovaps xmm15, [rsp+0xE0]
000072bd77ddd21f  add rsp, 0xF0
000072bd77ddd226  pop r11
000072bd77ddd228  pop r10
000072bd77ddd22a  pop r9
000072bd77ddd22c  pop r8
000072bd77ddd22e  pop rsi
000072bd77ddd22f  pop rdi
000072bd77ddd230  pop rdx
000072bd77ddd231  pop rcx
000072bd77ddd232  pop rax
000072bd77ddd233  add rsp, 0x08
000072bd77ddd237  jmp 0x000072BD77DDBC73
000072bd77ddd23c  sub rsp, 0x08
000072bd77ddd240  push rax
000072bd77ddd241  push rcx
000072bd77ddd242  push rdx
000072bd77ddd243  push rdi
000072bd77ddd244  push rsi
000072bd77ddd245  push r8
000072bd77ddd247  push r9
000072bd77ddd249  push r10
000072bd77ddd24b  push r11
000072bd77ddd24d  sub rsp, 0xF0
000072bd77ddd254  vmovaps [rsp], xmm0
000072bd77ddd259  vmovaps [rsp+0x10], xmm1
000072bd77ddd25f  vmovaps [rsp+0x20], xmm2
000072bd77ddd265  vmovaps [rsp+0x30], xmm3
000072bd77ddd26b  vmovaps [rsp+0x40], xmm5
000072bd77ddd271  vmovaps [rsp+0x50], xmm6
000072bd77ddd277  vmovaps [rsp+0x60], xmm7
000072bd77ddd27d  vmovaps [rsp+0x70], xmm8
000072bd77ddd283  vmovaps [rsp+0x80], xmm9
000072bd77ddd28c  vmovaps [rsp+0x90], xmm10
000072bd77ddd295  vmovaps [rsp+0xA0], xmm11
000072bd77ddd29e  vmovaps [rsp+0xB0], xmm12
000072bd77ddd2a7  vmovaps [rsp+0xC0], xmm13
000072bd77ddd2b0  vmovaps [rsp+0xD0], xmm14
000072bd77ddd2b9  vmovaps [rsp+0xE0], xmm15
000072bd77ddd2c2  sub rsp, 0x30
000072bd77ddd2c6  movaps [rsp], xmm4
000072bd77ddd2ca  movaps [rsp+0x10], xmm9
000072bd77ddd2d0  movaps [rsp+0x20], xmm8
000072bd77ddd2d6  lea rdi, [rsp]
000072bd77ddd2da  mov esi, 0x00
000072bd77ddd2df  mov rax, 0x643206AC3530
000072bd77ddd2e9  call rax
000072bd77ddd2eb  movaps xmm4, [rsp]
000072bd77ddd2ef  add rsp, 0x30
000072bd77ddd2f3  vmovaps xmm0, [rsp]
000072bd77ddd2f8  vmovaps xmm1, [rsp+0x10]
000072bd77ddd2fe  vmovaps xmm2, [rsp+0x20]
000072bd77ddd304  vmovaps xmm3, [rsp+0x30]
000072bd77ddd30a  vmovaps xmm5, [rsp+0x40]
000072bd77ddd310  vmovaps xmm6, [rsp+0x50]
000072bd77ddd316  vmovaps xmm7, [rsp+0x60]
000072bd77ddd31c  vmovaps xmm8, [rsp+0x70]
000072bd77ddd322  vmovaps xmm9, [rsp+0x80]
000072bd77ddd32b  vmovaps xmm10, [rsp+0x90]
000072bd77ddd334  vmovaps xmm11, [rsp+0xA0]
000072bd77ddd33d  vmovaps xmm12, [rsp+0xB0]
000072bd77ddd346  vmovaps xmm13, [rsp+0xC0]
000072bd77ddd34f  vmovaps xmm14, [rsp+0xD0]
000072bd77ddd358  vmovaps xmm15, [rsp+0xE0]
000072bd77ddd361  add rsp, 0xF0
000072bd77ddd368  pop r11
000072bd77ddd36a  pop r10
000072bd77ddd36c  pop r9
000072bd77ddd36e  pop r8
000072bd77ddd370  pop rsi
000072bd77ddd371  pop rdi
000072bd77ddd372  pop rdx
000072bd77ddd373  pop rcx
000072bd77ddd374  pop rax
000072bd77ddd375  add rsp, 0x08
000072bd77ddd379  jmp 0x000072BD77DDBC94
000072bd77ddd37e  sub rsp, 0x08
000072bd77ddd382  push rax
000072bd77ddd383  push rcx
000072bd77ddd384  push rdx
000072bd77ddd385  push rdi
000072bd77ddd386  push rsi
000072bd77ddd387  push r8
000072bd77ddd389  push r9
000072bd77ddd38b  push r10
000072bd77ddd38d  push r11
000072bd77ddd38f  sub rsp, 0xF0
000072bd77ddd396  vmovaps [rsp], xmm0
000072bd77ddd39b  vmovaps [rsp+0x10], xmm1
000072bd77ddd3a1  vmovaps [rsp+0x20], xmm2
000072bd77ddd3a7  vmovaps [rsp+0x30], xmm3
000072bd77ddd3ad  vmovaps [rsp+0x40], xmm4
000072bd77ddd3b3  vmovaps [rsp+0x50], xmm5
000072bd77ddd3b9  vmovaps [rsp+0x60], xmm6
000072bd77ddd3bf  vmovaps [rsp+0x70], xmm7
000072bd77ddd3c5  vmovaps [rsp+0x80], xmm8
000072bd77ddd3ce  vmovaps [rsp+0x90], xmm10
000072bd77ddd3d7  vmovaps [rsp+0xA0], xmm11
000072bd77ddd3e0  vmovaps [rsp+0xB0], xmm12
000072bd77ddd3e9  vmovaps [rsp+0xC0], xmm13
000072bd77ddd3f2  vmovaps [rsp+0xD0], xmm14
000072bd77ddd3fb  vmovaps [rsp+0xE0], xmm15
000072bd77ddd404  sub rsp, 0x30
000072bd77ddd408  movaps [rsp], xmm9
000072bd77ddd40d  movaps [rsp+0x10], xmm10
000072bd77ddd413  movaps [rsp+0x20], xmm8
000072bd77ddd419  lea rdi, [rsp]
000072bd77ddd41d  mov esi, 0x00
000072bd77ddd422  mov rax, 0x643206AC3530
000072bd77ddd42c  call rax
000072bd77ddd42e  movaps xmm9, [rsp]
000072bd77ddd433  add rsp, 0x30
000072bd77ddd437  vmovaps xmm0, [rsp]
000072bd77ddd43c  vmovaps xmm1, [rsp+0x10]
000072bd77ddd442  vmovaps xmm2, [rsp+0x20]
000072bd77ddd448  vmovaps xmm3, [rsp+0x30]
000072bd77ddd44e  vmovaps xmm4, [rsp+0x40]
000072bd77ddd454  vmovaps xmm5, [rsp+0x50]
000072bd77ddd45a  vmovaps xmm6, [rsp+0x60]
000072bd77ddd460  vmovaps xmm7, [rsp+0x70]
000072bd77ddd466  vmovaps xmm8, [rsp+0x80]
000072bd77ddd46f  vmovaps xmm10, [rsp+0x90]
000072bd77ddd478  vmovaps xmm11, [rsp+0xA0]
000072bd77ddd481  vmovaps xmm12, [rsp+0xB0]
000072bd77ddd48a  vmovaps xmm13, [rsp+0xC0]
000072bd77ddd493  vmovaps xmm14, [rsp+0xD0]
000072bd77ddd49c  vmovaps xmm15, [rsp+0xE0]
000072bd77ddd4a5  add rsp, 0xF0
000072bd77ddd4ac  pop r11
000072bd77ddd4ae  pop r10
000072bd77ddd4b0  pop r9
000072bd77ddd4b2  pop r8
000072bd77ddd4b4  pop rsi
000072bd77ddd4b5  pop rdi
000072bd77ddd4b6  pop rdx
000072bd77ddd4b7  pop rcx
000072bd77ddd4b8  pop rax
000072bd77ddd4b9  add rsp, 0x08
000072bd77ddd4bd  jmp 0x000072BD77DDBCAE
000072bd77ddd4c2  call 0x000072BD77CB52F0
000072bd77ddd4c7  jmp 0x000072BD77DDBDC8
000072bd77ddd4cc  call 0x000072BD77CB52F0
000072bd77ddd4d1  jmp 0x000072BD77DDBDDE
000072bd77ddd4d6  sub rsp, 0x08
000072bd77ddd4da  push rax
000072bd77ddd4db  push rcx
000072bd77ddd4dc  push rdx
000072bd77ddd4dd  push rdi
000072bd77ddd4de  push rsi
000072bd77ddd4df  push r8
000072bd77ddd4e1  push r9
000072bd77ddd4e3  push r10
000072bd77ddd4e5  push r11
000072bd77ddd4e7  sub rsp, 0xF0
000072bd77ddd4ee  vmovaps [rsp], xmm0
000072bd77ddd4f3  vmovaps [rsp+0x10], xmm2
000072bd77ddd4f9  vmovaps [rsp+0x20], xmm3
000072bd77ddd4ff  vmovaps [rsp+0x30], xmm4
000072bd77ddd505  vmovaps [rsp+0x40], xmm5
000072bd77ddd50b  vmovaps [rsp+0x50], xmm6
000072bd77ddd511  vmovaps [rsp+0x60], xmm7
000072bd77ddd517  vmovaps [rsp+0x70], xmm8
000072bd77ddd51d  vmovaps [rsp+0x80], xmm9
000072bd77ddd526  vmovaps [rsp+0x90], xmm10
000072bd77ddd52f  vmovaps [rsp+0xA0], xmm11
000072bd77ddd538  vmovaps [rsp+0xB0], xmm12
000072bd77ddd541  vmovaps [rsp+0xC0], xmm13
000072bd77ddd54a  vmovaps [rsp+0xD0], xmm14
000072bd77ddd553  vmovaps [rsp+0xE0], xmm15
000072bd77ddd55c  sub rsp, 0x30
000072bd77ddd560  movaps [rsp], xmm1
000072bd77ddd564  movaps [rsp+0x10], xmm6
000072bd77ddd569  movaps [rsp+0x20], xmm15
000072bd77ddd56f  lea rdi, [rsp]
000072bd77ddd573  mov esi, 0x00
000072bd77ddd578  mov rax, 0x643206AC3530
000072bd77ddd582  call rax
000072bd77ddd584  movaps xmm1, [rsp]
000072bd77ddd588  add rsp, 0x30
000072bd77ddd58c  vmovaps xmm0, [rsp]
000072bd77ddd591  vmovaps xmm2, [rsp+0x10]
000072bd77ddd597  vmovaps xmm3, [rsp+0x20]
000072bd77ddd59d  vmovaps xmm4, [rsp+0x30]
000072bd77ddd5a3  vmovaps xmm5, [rsp+0x40]
000072bd77ddd5a9  vmovaps xmm6, [rsp+0x50]
000072bd77ddd5af  vmovaps xmm7, [rsp+0x60]
000072bd77ddd5b5  vmovaps xmm8, [rsp+0x70]
000072bd77ddd5bb  vmovaps xmm9, [rsp+0x80]
000072bd77ddd5c4  vmovaps xmm10, [rsp+0x90]
000072bd77ddd5cd  vmovaps xmm11, [rsp+0xA0]
000072bd77ddd5d6  vmovaps xmm12, [rsp+0xB0]
000072bd77ddd5df  vmovaps xmm13, [rsp+0xC0]
000072bd77ddd5e8  vmovaps xmm14, [rsp+0xD0]
000072bd77ddd5f1  vmovaps xmm15, [rsp+0xE0]
000072bd77ddd5fa  add rsp, 0xF0
000072bd77ddd601  pop r11
000072bd77ddd603  pop r10
000072bd77ddd605  pop r9
000072bd77ddd607  pop r8
000072bd77ddd609  pop rsi
000072bd77ddd60a  pop rdi
000072bd77ddd60b  pop rdx
000072bd77ddd60c  pop rcx
000072bd77ddd60d  pop rax
000072bd77ddd60e  add rsp, 0x08
000072bd77ddd612  jmp 0x000072BD77DDBE1B
000072bd77ddd617  call 0x000072BD77CC4620
000072bd77ddd61c  jmp 0x000072BD77DDBE28
000072bd77ddd621  sub rsp, 0x08
000072bd77ddd625  push rax
000072bd77ddd626  push rcx
000072bd77ddd627  push rdx
000072bd77ddd628  push rdi
000072bd77ddd629  push rsi
000072bd77ddd62a  push r8
000072bd77ddd62c  push r9
000072bd77ddd62e  push r10
000072bd77ddd630  push r11
000072bd77ddd632  sub rsp, 0xF0
000072bd77ddd639  vmovaps [rsp], xmm0
000072bd77ddd63e  vmovaps [rsp+0x10], xmm1
000072bd77ddd644  vmovaps [rsp+0x20], xmm2
000072bd77ddd64a  vmovaps [rsp+0x30], xmm3
000072bd77ddd650  vmovaps [rsp+0x40], xmm4
000072bd77ddd656  vmovaps [rsp+0x50], xmm5
000072bd77ddd65c  vmovaps [rsp+0x60], xmm6
000072bd77ddd662  vmovaps [rsp+0x70], xmm7
000072bd77ddd668  vmovaps [rsp+0x80], xmm8
000072bd77ddd671  vmovaps [rsp+0x90], xmm9
000072bd77ddd67a  vmovaps [rsp+0xA0], xmm10
000072bd77ddd683  vmovaps [rsp+0xB0], xmm11
000072bd77ddd68c  vmovaps [rsp+0xC0], xmm12
000072bd77ddd695  vmovaps [rsp+0xD0], xmm13
000072bd77ddd69e  vmovaps [rsp+0xE0], xmm15
000072bd77ddd6a7  sub rsp, 0x30
000072bd77ddd6ab  movaps [rsp], xmm14
000072bd77ddd6b0  movaps [rsp+0x10], xmm4
000072bd77ddd6b5  movaps [rsp+0x20], xmm3
000072bd77ddd6ba  lea rdi, [rsp]
000072bd77ddd6be  mov esi, 0x00
000072bd77ddd6c3  mov rax, 0x643206AC3530
000072bd77ddd6cd  call rax
000072bd77ddd6cf  movaps xmm14, [rsp]
000072bd77ddd6d4  add rsp, 0x30
000072bd77ddd6d8  vmovaps xmm0, [rsp]
000072bd77ddd6dd  vmovaps xmm1, [rsp+0x10]
000072bd77ddd6e3  vmovaps xmm2, [rsp+0x20]
000072bd77ddd6e9  vmovaps xmm3, [rsp+0x30]
000072bd77ddd6ef  vmovaps xmm4, [rsp+0x40]
000072bd77ddd6f5  vmovaps xmm5, [rsp+0x50]
000072bd77ddd6fb  vmovaps xmm6, [rsp+0x60]
000072bd77ddd701  vmovaps xmm7, [rsp+0x70]
000072bd77ddd707  vmovaps xmm8, [rsp+0x80]
000072bd77ddd710  vmovaps xmm9, [rsp+0x90]
000072bd77ddd719  vmovaps xmm10, [rsp+0xA0]
000072bd77ddd722  vmovaps xmm11, [rsp+0xB0]
000072bd77ddd72b  vmovaps xmm12, [rsp+0xC0]
000072bd77ddd734  vmovaps xmm13, [rsp+0xD0]
000072bd77ddd73d  vmovaps xmm15, [rsp+0xE0]
000072bd77ddd746  add rsp, 0xF0
000072bd77ddd74d  pop r11
000072bd77ddd74f  pop r10
000072bd77ddd751  pop r9
000072bd77ddd753  pop r8
000072bd77ddd755  pop rsi
000072bd77ddd756  pop rdi
000072bd77ddd757  pop rdx
000072bd77ddd758  pop rcx
000072bd77ddd759  pop rax
000072bd77ddd75a  add rsp, 0x08
000072bd77ddd75e  jmp 0x000072BD77DDBE42
000072bd77ddd763  sub rsp, 0x08
000072bd77ddd767  push rax
000072bd77ddd768  push rcx
000072bd77ddd769  push rdx
000072bd77ddd76a  push rdi
000072bd77ddd76b  push rsi
000072bd77ddd76c  push r8
000072bd77ddd76e  push r9
000072bd77ddd770  push r10
000072bd77ddd772  push r11
000072bd77ddd774  sub rsp, 0xF0
000072bd77ddd77b  vmovaps [rsp], xmm0
000072bd77ddd780  vmovaps [rsp+0x10], xmm1
000072bd77ddd786  vmovaps [rsp+0x20], xmm2
000072bd77ddd78c  vmovaps [rsp+0x30], xmm3
000072bd77ddd792  vmovaps [rsp+0x40], xmm4
000072bd77ddd798  vmovaps [rsp+0x50], xmm5
000072bd77ddd79e  vmovaps [rsp+0x60], xmm7
000072bd77ddd7a4  vmovaps [rsp+0x70], xmm8
000072bd77ddd7aa  vmovaps [rsp+0x80], xmm9
000072bd77ddd7b3  vmovaps [rsp+0x90], xmm10
000072bd77ddd7bc  vmovaps [rsp+0xA0], xmm11
000072bd77ddd7c5  vmovaps [rsp+0xB0], xmm12
000072bd77ddd7ce  vmovaps [rsp+0xC0], xmm13
000072bd77ddd7d7  vmovaps [rsp+0xD0], xmm14
000072bd77ddd7e0  vmovaps [rsp+0xE0], xmm15
000072bd77ddd7e9  sub rsp, 0x30
000072bd77ddd7ed  movaps [rsp], xmm6
000072bd77ddd7f1  movaps [rsp+0x10], xmm9
000072bd77ddd7f7  movaps [rsp+0x20], xmm7
000072bd77ddd7fc  lea rdi, [rsp]
000072bd77ddd800  mov esi, 0x00
000072bd77ddd805  mov rax, 0x643206AC3530
000072bd77ddd80f  call rax
000072bd77ddd811  movaps xmm6, [rsp]
000072bd77ddd815  add rsp, 0x30
000072bd77ddd819  vmovaps xmm0, [rsp]
000072bd77ddd81e  vmovaps xmm1, [rsp+0x10]
000072bd77ddd824  vmovaps xmm2, [rsp+0x20]
000072bd77ddd82a  vmovaps xmm3, [rsp+0x30]
000072bd77ddd830  vmovaps xmm4, [rsp+0x40]
000072bd77ddd836  vmovaps xmm5, [rsp+0x50]
000072bd77ddd83c  vmovaps xmm7, [rsp+0x60]
000072bd77ddd842  vmovaps xmm8, [rsp+0x70]
000072bd77ddd848  vmovaps xmm9, [rsp+0x80]
000072bd77ddd851  vmovaps xmm10, [rsp+0x90]
000072bd77ddd85a  vmovaps xmm11, [rsp+0xA0]
000072bd77ddd863  vmovaps xmm12, [rsp+0xB0]
000072bd77ddd86c  vmovaps xmm13, [rsp+0xC0]
000072bd77ddd875  vmovaps xmm14, [rsp+0xD0]
000072bd77ddd87e  vmovaps xmm15, [rsp+0xE0]
000072bd77ddd887  add rsp, 0xF0
000072bd77ddd88e  pop r11
000072bd77ddd890  pop r10
000072bd77ddd892  pop r9
000072bd77ddd894  pop r8
000072bd77ddd896  pop rsi
000072bd77ddd897  pop rdi
000072bd77ddd898  pop rdx
000072bd77ddd899  pop rcx
000072bd77ddd89a  pop rax
000072bd77ddd89b  add rsp, 0x08
000072bd77ddd89f  jmp 0x000072BD77DDBE5A
000072bd77ddd8a4  sub rsp, 0x08
000072bd77ddd8a8  push rax
000072bd77ddd8a9  push rcx
000072bd77ddd8aa  push rdx
000072bd77ddd8ab  push rdi
000072bd77ddd8ac  push rsi
000072bd77ddd8ad  push r8
000072bd77ddd8af  push r9
000072bd77ddd8b1  push r10
000072bd77ddd8b3  push r11
000072bd77ddd8b5  sub rsp, 0xF0
000072bd77ddd8bc  vmovaps [rsp], xmm0
000072bd77ddd8c1  vmovaps [rsp+0x10], xmm1
000072bd77ddd8c7  vmovaps [rsp+0x20], xmm2
000072bd77ddd8cd  vmovaps [rsp+0x30], xmm3
000072bd77ddd8d3  vmovaps [rsp+0x40], xmm4
000072bd77ddd8d9  vmovaps [rsp+0x50], xmm5
000072bd77ddd8df  vmovaps [rsp+0x60], xmm6
000072bd77ddd8e5  vmovaps [rsp+0x70], xmm8
000072bd77ddd8eb  vmovaps [rsp+0x80], xmm9
000072bd77ddd8f4  vmovaps [rsp+0x90], xmm10
000072bd77ddd8fd  vmovaps [rsp+0xA0], xmm11
000072bd77ddd906  vmovaps [rsp+0xB0], xmm12
000072bd77ddd90f  vmovaps [rsp+0xC0], xmm13
000072bd77ddd918  vmovaps [rsp+0xD0], xmm14
000072bd77ddd921  vmovaps [rsp+0xE0], xmm15
000072bd77ddd92a  sub rsp, 0x30
000072bd77ddd92e  movaps [rsp], xmm7
000072bd77ddd932  movaps [rsp+0x10], xmm4
000072bd77ddd937  movaps [rsp+0x20], xmm9
000072bd77ddd93d  lea rdi, [rsp]
000072bd77ddd941  mov esi, 0x00
000072bd77ddd946  mov rax, 0x643206AC3530
000072bd77ddd950  call rax
000072bd77ddd952  movaps xmm7, [rsp]
000072bd77ddd956  add rsp, 0x30
000072bd77ddd95a  vmovaps xmm0, [rsp]
000072bd77ddd95f  vmovaps xmm1, [rsp+0x10]
000072bd77ddd965  vmovaps xmm2, [rsp+0x20]
000072bd77ddd96b  vmovaps xmm3, [rsp+0x30]
000072bd77ddd971  vmovaps xmm4, [rsp+0x40]
000072bd77ddd977  vmovaps xmm5, [rsp+0x50]
000072bd77ddd97d  vmovaps xmm6, [rsp+0x60]
000072bd77ddd983  vmovaps xmm8, [rsp+0x70]
000072bd77ddd989  vmovaps xmm9, [rsp+0x80]
000072bd77ddd992  vmovaps xmm10, [rsp+0x90]
000072bd77ddd99b  vmovaps xmm11, [rsp+0xA0]
000072bd77ddd9a4  vmovaps xmm12, [rsp+0xB0]
000072bd77ddd9ad  vmovaps xmm13, [rsp+0xC0]
000072bd77ddd9b6  vmovaps xmm14, [rsp+0xD0]
000072bd77ddd9bf  vmovaps xmm15, [rsp+0xE0]
000072bd77ddd9c8  add rsp, 0xF0
000072bd77ddd9cf  pop r11
000072bd77ddd9d1  pop r10
000072bd77ddd9d3  pop r9
000072bd77ddd9d5  pop r8
000072bd77ddd9d7  pop rsi
000072bd77ddd9d8  pop rdi
000072bd77ddd9d9  pop rdx
000072bd77ddd9da  pop rcx
000072bd77ddd9db  pop rax
000072bd77ddd9dc  add rsp, 0x08
000072bd77ddd9e0  jmp 0x000072BD77DDBE87
000072bd77ddd9e5  sub rsp, 0x08
000072bd77ddd9e9  push rax
000072bd77ddd9ea  push rcx
000072bd77ddd9eb  push rdx
000072bd77ddd9ec  push rdi
000072bd77ddd9ed  push rsi
000072bd77ddd9ee  push r8
000072bd77ddd9f0  push r9
000072bd77ddd9f2  push r10
000072bd77ddd9f4  push r11
000072bd77ddd9f6  sub rsp, 0xF0
000072bd77ddd9fd  vmovaps [rsp], xmm0
000072bd77ddda02  vmovaps [rsp+0x10], xmm1
000072bd77ddda08  vmovaps [rsp+0x20], xmm2
000072bd77ddda0e  vmovaps [rsp+0x30], xmm3
000072bd77ddda14  vmovaps [rsp+0x40], xmm5
000072bd77ddda1a  vmovaps [rsp+0x50], xmm6
000072bd77ddda20  vmovaps [rsp+0x60], xmm7
000072bd77ddda26  vmovaps [rsp+0x70], xmm8
000072bd77ddda2c  vmovaps [rsp+0x80], xmm9
000072bd77ddda35  vmovaps [rsp+0x90], xmm10
000072bd77ddda3e  vmovaps [rsp+0xA0], xmm11
000072bd77ddda47  vmovaps [rsp+0xB0], xmm12
000072bd77ddda50  vmovaps [rsp+0xC0], xmm13
000072bd77ddda59  vmovaps [rsp+0xD0], xmm14
000072bd77ddda62  vmovaps [rsp+0xE0], xmm15
000072bd77ddda6b  sub rsp, 0x30
000072bd77ddda6f  movaps [rsp], xmm4
000072bd77ddda73  movaps [rsp+0x10], xmm15
000072bd77ddda79  movaps [rsp+0x20], xmm9
000072bd77ddda7f  lea rdi, [rsp]
000072bd77ddda83  mov esi, 0x00
000072bd77ddda88  mov rax, 0x643206AC3530
000072bd77ddda92  call rax
000072bd77ddda94  movaps xmm4, [rsp]
000072bd77ddda98  add rsp, 0x30
000072bd77ddda9c  vmovaps xmm0, [rsp]
000072bd77dddaa1  vmovaps xmm1, [rsp+0x10]
000072bd77dddaa7  vmovaps xmm2, [rsp+0x20]
000072bd77dddaad  vmovaps xmm3, [rsp+0x30]
000072bd77dddab3  vmovaps xmm5, [rsp+0x40]
000072bd77dddab9  vmovaps xmm6, [rsp+0x50]
000072bd77dddabf  vmovaps xmm7, [rsp+0x60]
000072bd77dddac5  vmovaps xmm8, [rsp+0x70]
000072bd77dddacb  vmovaps xmm9, [rsp+0x80]
000072bd77dddad4  vmovaps xmm10, [rsp+0x90]
000072bd77dddadd  vmovaps xmm11, [rsp+0xA0]
000072bd77dddae6  vmovaps xmm12, [rsp+0xB0]
000072bd77dddaef  vmovaps xmm13, [rsp+0xC0]
000072bd77dddaf8  vmovaps xmm14, [rsp+0xD0]
000072bd77dddb01  vmovaps xmm15, [rsp+0xE0]
000072bd77dddb0a  add rsp, 0xF0
000072bd77dddb11  pop r11
000072bd77dddb13  pop r10
000072bd77dddb15  pop r9
000072bd77dddb17  pop r8
000072bd77dddb19  pop rsi
000072bd77dddb1a  pop rdi
000072bd77dddb1b  pop rdx
000072bd77dddb1c  pop rcx
000072bd77dddb1d  pop rax
000072bd77dddb1e  add rsp, 0x08
000072bd77dddb22  jmp 0x000072BD77DDBEAC
000072bd77dddb27  call 0x000072BD77CC4620
000072bd77dddb2c  jmp 0x000072BD77DDBEB9
000072bd77dddb31  sub rsp, 0x08
000072bd77dddb35  push rax
000072bd77dddb36  push rcx
000072bd77dddb37  push rdx
000072bd77dddb38  push rdi
000072bd77dddb39  push rsi
000072bd77dddb3a  push r8
000072bd77dddb3c  push r9
000072bd77dddb3e  push r10
000072bd77dddb40  push r11
000072bd77dddb42  sub rsp, 0xF0
000072bd77dddb49  vmovaps [rsp], xmm0
000072bd77dddb4e  vmovaps [rsp+0x10], xmm1
000072bd77dddb54  vmovaps [rsp+0x20], xmm2
000072bd77dddb5a  vmovaps [rsp+0x30], xmm4
000072bd77dddb60  vmovaps [rsp+0x40], xmm5
000072bd77dddb66  vmovaps [rsp+0x50], xmm6
000072bd77dddb6c  vmovaps [rsp+0x60], xmm7
000072bd77dddb72  vmovaps [rsp+0x70], xmm8
000072bd77dddb78  vmovaps [rsp+0x80], xmm9
000072bd77dddb81  vmovaps [rsp+0x90], xmm10
000072bd77dddb8a  vmovaps [rsp+0xA0], xmm11
000072bd77dddb93  vmovaps [rsp+0xB0], xmm12
000072bd77dddb9c  vmovaps [rsp+0xC0], xmm13
000072bd77dddba5  vmovaps [rsp+0xD0], xmm14
000072bd77dddbae  vmovaps [rsp+0xE0], xmm15
000072bd77dddbb7  sub rsp, 0x30
000072bd77dddbbb  movaps [rsp], xmm3
000072bd77dddbbf  movaps [rsp+0x10], xmm1
000072bd77dddbc4  movaps [rsp+0x20], xmm9
000072bd77dddbca  lea rdi, [rsp]
000072bd77dddbce  mov esi, 0x00
000072bd77dddbd3  mov rax, 0x643206AC3530
000072bd77dddbdd  call rax
000072bd77dddbdf  movaps xmm3, [rsp]
000072bd77dddbe3  add rsp, 0x30
000072bd77dddbe7  vmovaps xmm0, [rsp]
000072bd77dddbec  vmovaps xmm1, [rsp+0x10]
000072bd77dddbf2  vmovaps xmm2, [rsp+0x20]
000072bd77dddbf8  vmovaps xmm4, [rsp+0x30]
000072bd77dddbfe  vmovaps xmm5, [rsp+0x40]
000072bd77dddc04  vmovaps xmm6, [rsp+0x50]
000072bd77dddc0a  vmovaps xmm7, [rsp+0x60]
000072bd77dddc10  vmovaps xmm8, [rsp+0x70]
000072bd77dddc16  vmovaps xmm9, [rsp+0x80]
000072bd77dddc1f  vmovaps xmm10, [rsp+0x90]
000072bd77dddc28  vmovaps xmm11, [rsp+0xA0]
000072bd77dddc31  vmovaps xmm12, [rsp+0xB0]
000072bd77dddc3a  vmovaps xmm13, [rsp+0xC0]
000072bd77dddc43  vmovaps xmm14, [rsp+0xD0]
000072bd77dddc4c  vmovaps xmm15, [rsp+0xE0]
000072bd77dddc55  add rsp, 0xF0
000072bd77dddc5c  pop r11
000072bd77dddc5e  pop r10
000072bd77dddc60  pop r9
000072bd77dddc62  pop r8
000072bd77dddc64  pop rsi
000072bd77dddc65  pop rdi
000072bd77dddc66  pop rdx
000072bd77dddc67  pop rcx
000072bd77dddc68  pop rax
000072bd77dddc69  add rsp, 0x08
000072bd77dddc6d  jmp 0x000072BD77DDBEF6
000072bd77dddc72  sub rsp, 0x08
000072bd77dddc76  push rax
000072bd77dddc77  push rcx
000072bd77dddc78  push rdx
000072bd77dddc79  push rdi
000072bd77dddc7a  push rsi
000072bd77dddc7b  push r8
000072bd77dddc7d  push r9
000072bd77dddc7f  push r10
000072bd77dddc81  push r11
000072bd77dddc83  sub rsp, 0xF0
000072bd77dddc8a  vmovaps [rsp], xmm0
000072bd77dddc8f  vmovaps [rsp+0x10], xmm2
000072bd77dddc95  vmovaps [rsp+0x20], xmm3
000072bd77dddc9b  vmovaps [rsp+0x30], xmm4
000072bd77dddca1  vmovaps [rsp+0x40], xmm5
000072bd77dddca7  vmovaps [rsp+0x50], xmm6
000072bd77dddcad  vmovaps [rsp+0x60], xmm7
000072bd77dddcb3  vmovaps [rsp+0x70], xmm8
000072bd77dddcb9  vmovaps [rsp+0x80], xmm9
000072bd77dddcc2  vmovaps [rsp+0x90], xmm10
000072bd77dddccb  vmovaps [rsp+0xA0], xmm11
000072bd77dddcd4  vmovaps [rsp+0xB0], xmm12
000072bd77dddcdd  vmovaps [rsp+0xC0], xmm13
000072bd77dddce6  vmovaps [rsp+0xD0], xmm14
000072bd77dddcef  vmovaps [rsp+0xE0], xmm15
000072bd77dddcf8  sub rsp, 0x30
000072bd77dddcfc  movaps [rsp], xmm1
000072bd77dddd00  movaps [rsp+0x10], xmm15
000072bd77dddd06  movaps [rsp+0x20], xmm9
000072bd77dddd0c  lea rdi, [rsp]
000072bd77dddd10  mov esi, 0x00
000072bd77dddd15  mov rax, 0x643206AC3530
000072bd77dddd1f  call rax
000072bd77dddd21  movaps xmm1, [rsp]
000072bd77dddd25  add rsp, 0x30
000072bd77dddd29  vmovaps xmm0, [rsp]
000072bd77dddd2e  vmovaps xmm2, [rsp+0x10]
000072bd77dddd34  vmovaps xmm3, [rsp+0x20]
000072bd77dddd3a  vmovaps xmm4, [rsp+0x30]
000072bd77dddd40  vmovaps xmm5, [rsp+0x40]
000072bd77dddd46  vmovaps xmm6, [rsp+0x50]
000072bd77dddd4c  vmovaps xmm7, [rsp+0x60]
000072bd77dddd52  vmovaps xmm8, [rsp+0x70]
000072bd77dddd58  vmovaps xmm9, [rsp+0x80]
000072bd77dddd61  vmovaps xmm10, [rsp+0x90]
000072bd77dddd6a  vmovaps xmm11, [rsp+0xA0]
000072bd77dddd73  vmovaps xmm12, [rsp+0xB0]
000072bd77dddd7c  vmovaps xmm13, [rsp+0xC0]
000072bd77dddd85  vmovaps xmm14, [rsp+0xD0]
000072bd77dddd8e  vmovaps xmm15, [rsp+0xE0]
000072bd77dddd97  add rsp, 0xF0
000072bd77dddd9e  pop r11
000072bd77dddda0  pop r10
000072bd77dddda2  pop r9
000072bd77dddda4  pop r8
000072bd77dddda6  pop rsi
000072bd77dddda7  pop rdi
000072bd77dddda8  pop rdx
000072bd77dddda9  pop rcx
000072bd77ddddaa  pop rax
000072bd77ddddab  add rsp, 0x08
000072bd77ddddaf  jmp 0x000072BD77DDBF7E
000072bd77ddddb4  call 0x000072BD77CC4620
000072bd77ddddb9  jmp 0x000072BD77DDBF8B
000072bd77ddddbe  sub rsp, 0x08
000072bd77ddddc2  push rax
000072bd77ddddc3  push rcx
000072bd77ddddc4  push rdx
000072bd77ddddc5  push rdi
000072bd77ddddc6  push rsi
000072bd77ddddc7  push r8
000072bd77ddddc9  push r9
000072bd77ddddcb  push r10
000072bd77ddddcd  push r11
000072bd77ddddcf  sub rsp, 0xF0
000072bd77ddddd6  vmovaps [rsp], xmm0
000072bd77dddddb  vmovaps [rsp+0x10], xmm2
000072bd77dddde1  vmovaps [rsp+0x20], xmm3
000072bd77dddde7  vmovaps [rsp+0x30], xmm4
000072bd77dddded  vmovaps [rsp+0x40], xmm5
000072bd77ddddf3  vmovaps [rsp+0x50], xmm6
000072bd77ddddf9  vmovaps [rsp+0x60], xmm7
000072bd77ddddff  vmovaps [rsp+0x70], xmm8
000072bd77ddde05  vmovaps [rsp+0x80], xmm9
000072bd77ddde0e  vmovaps [rsp+0x90], xmm10
000072bd77ddde17  vmovaps [rsp+0xA0], xmm11
000072bd77ddde20  vmovaps [rsp+0xB0], xmm12
000072bd77ddde29  vmovaps [rsp+0xC0], xmm13
000072bd77ddde32  vmovaps [rsp+0xD0], xmm14
000072bd77ddde3b  vmovaps [rsp+0xE0], xmm15
000072bd77ddde44  sub rsp, 0x30
000072bd77ddde48  movaps [rsp], xmm1
000072bd77ddde4c  movaps [rsp+0x10], xmm5
000072bd77ddde51  movaps [rsp+0x20], xmm7
000072bd77ddde56  lea rdi, [rsp]
000072bd77ddde5a  mov esi, 0x00
000072bd77ddde5f  mov rax, 0x643206AC3530
000072bd77ddde69  call rax
000072bd77ddde6b  movaps xmm1, [rsp]
000072bd77ddde6f  add rsp, 0x30
000072bd77ddde73  vmovaps xmm0, [rsp]
000072bd77ddde78  vmovaps xmm2, [rsp+0x10]
000072bd77ddde7e  vmovaps xmm3, [rsp+0x20]
000072bd77ddde84  vmovaps xmm4, [rsp+0x30]
000072bd77ddde8a  vmovaps xmm5, [rsp+0x40]
000072bd77ddde90  vmovaps xmm6, [rsp+0x50]
000072bd77ddde96  vmovaps xmm7, [rsp+0x60]
000072bd77ddde9c  vmovaps xmm8, [rsp+0x70]
000072bd77dddea2  vmovaps xmm9, [rsp+0x80]
000072bd77dddeab  vmovaps xmm10, [rsp+0x90]
000072bd77dddeb4  vmovaps xmm11, [rsp+0xA0]
000072bd77dddebd  vmovaps xmm12, [rsp+0xB0]
000072bd77dddec6  vmovaps xmm13, [rsp+0xC0]
000072bd77dddecf  vmovaps xmm14, [rsp+0xD0]
000072bd77ddded8  vmovaps xmm15, [rsp+0xE0]
000072bd77dddee1  add rsp, 0xF0
000072bd77dddee8  pop r11
000072bd77dddeea  pop r10
000072bd77dddeec  pop r9
000072bd77dddeee  pop r8
000072bd77dddef0  pop rsi
000072bd77dddef1  pop rdi
000072bd77dddef2  pop rdx
000072bd77dddef3  pop rcx
000072bd77dddef4  pop rax
000072bd77dddef5  add rsp, 0x08
000072bd77dddef9  jmp 0x000072BD77DDC030
000072bd77dddefe  sub rsp, 0x08
000072bd77dddf02  push rax
000072bd77dddf03  push rcx
000072bd77dddf04  push rdx
000072bd77dddf05  push rdi
000072bd77dddf06  push rsi
000072bd77dddf07  push r8
000072bd77dddf09  push r9
000072bd77dddf0b  push r10
000072bd77dddf0d  push r11
000072bd77dddf0f  sub rsp, 0xF0
000072bd77dddf16  vmovaps [rsp], xmm0
000072bd77dddf1b  vmovaps [rsp+0x10], xmm1
000072bd77dddf21  vmovaps [rsp+0x20], xmm2
000072bd77dddf27  vmovaps [rsp+0x30], xmm3
000072bd77dddf2d  vmovaps [rsp+0x40], xmm4
000072bd77dddf33  vmovaps [rsp+0x50], xmm5
000072bd77dddf39  vmovaps [rsp+0x60], xmm6
000072bd77dddf3f  vmovaps [rsp+0x70], xmm8
000072bd77dddf45  vmovaps [rsp+0x80], xmm9
000072bd77dddf4e  vmovaps [rsp+0x90], xmm10
000072bd77dddf57  vmovaps [rsp+0xA0], xmm11
000072bd77dddf60  vmovaps [rsp+0xB0], xmm12
000072bd77dddf69  vmovaps [rsp+0xC0], xmm13
000072bd77dddf72  vmovaps [rsp+0xD0], xmm14
000072bd77dddf7b  vmovaps [rsp+0xE0], xmm15
000072bd77dddf84  sub rsp, 0x30
000072bd77dddf88  movaps [rsp], xmm7
000072bd77dddf8c  movaps [rsp+0x10], xmm5
000072bd77dddf91  movaps [rsp+0x20], xmm15
000072bd77dddf97  lea rdi, [rsp]
000072bd77dddf9b  mov esi, 0x00
000072bd77dddfa0  mov rax, 0x643206AC3530
000072bd77dddfaa  call rax
000072bd77dddfac  movaps xmm7, [rsp]
000072bd77dddfb0  add rsp, 0x30
000072bd77dddfb4  vmovaps xmm0, [rsp]
000072bd77dddfb9  vmovaps xmm1, [rsp+0x10]
000072bd77dddfbf  vmovaps xmm2, [rsp+0x20]
000072bd77dddfc5  vmovaps xmm3, [rsp+0x30]
000072bd77dddfcb  vmovaps xmm4, [rsp+0x40]
000072bd77dddfd1  vmovaps xmm5, [rsp+0x50]
000072bd77dddfd7  vmovaps xmm6, [rsp+0x60]
000072bd77dddfdd  vmovaps xmm8, [rsp+0x70]
000072bd77dddfe3  vmovaps xmm9, [rsp+0x80]
000072bd77dddfec  vmovaps xmm10, [rsp+0x90]
000072bd77dddff5  vmovaps xmm11, [rsp+0xA0]
000072bd77dddffe  vmovaps xmm12, [rsp+0xB0]
000072bd77dde007  vmovaps xmm13, [rsp+0xC0]
000072bd77dde010  vmovaps xmm14, [rsp+0xD0]
000072bd77dde019  vmovaps xmm15, [rsp+0xE0]
000072bd77dde022  add rsp, 0xF0
000072bd77dde029  pop r11
000072bd77dde02b  pop r10
000072bd77dde02d  pop r9
000072bd77dde02f  pop r8
000072bd77dde031  pop rsi
000072bd77dde032  pop rdi
000072bd77dde033  pop rdx
000072bd77dde034  pop rcx
000072bd77dde035  pop rax
000072bd77dde036  add rsp, 0x08
000072bd77dde03a  jmp 0x000072BD77DDC066
000072bd77dde03f  call 0x000072BD77CB52F0
000072bd77dde044  jmp 0x000072BD77DDC073
000072bd77dde049  sub rsp, 0x08
000072bd77dde04d  push rax
000072bd77dde04e  push rcx
000072bd77dde04f  push rdx
000072bd77dde050  push rdi
000072bd77dde051  push rsi
000072bd77dde052  push r8
000072bd77dde054  push r9
000072bd77dde056  push r10
000072bd77dde058  push r11
000072bd77dde05a  sub rsp, 0xF0
000072bd77dde061  vmovaps [rsp], xmm0
000072bd77dde066  vmovaps [rsp+0x10], xmm1
000072bd77dde06c  vmovaps [rsp+0x20], xmm2
000072bd77dde072  vmovaps [rsp+0x30], xmm3
000072bd77dde078  vmovaps [rsp+0x40], xmm4
000072bd77dde07e  vmovaps [rsp+0x50], xmm5
000072bd77dde084  vmovaps [rsp+0x60], xmm6
000072bd77dde08a  vmovaps [rsp+0x70], xmm7
000072bd77dde090  vmovaps [rsp+0x80], xmm8
000072bd77dde099  vmovaps [rsp+0x90], xmm9
000072bd77dde0a2  vmovaps [rsp+0xA0], xmm10
000072bd77dde0ab  vmovaps [rsp+0xB0], xmm11
000072bd77dde0b4  vmovaps [rsp+0xC0], xmm12
000072bd77dde0bd  vmovaps [rsp+0xD0], xmm13
000072bd77dde0c6  vmovaps [rsp+0xE0], xmm14
000072bd77dde0cf  sub rsp, 0x30
000072bd77dde0d3  movaps [rsp], xmm15
000072bd77dde0d8  movaps [rsp+0x10], xmm5
000072bd77dde0dd  movaps [rsp+0x20], xmm3
000072bd77dde0e2  lea rdi, [rsp]
000072bd77dde0e6  mov esi, 0x00
000072bd77dde0eb  mov rax, 0x643206AC3530
000072bd77dde0f5  call rax
000072bd77dde0f7  movaps xmm15, [rsp]
000072bd77dde0fc  add rsp, 0x30
000072bd77dde100  vmovaps xmm0, [rsp]
000072bd77dde105  vmovaps xmm1, [rsp+0x10]
000072bd77dde10b  vmovaps xmm2, [rsp+0x20]
000072bd77dde111  vmovaps xmm3, [rsp+0x30]
000072bd77dde117  vmovaps xmm4, [rsp+0x40]
000072bd77dde11d  vmovaps xmm5, [rsp+0x50]
000072bd77dde123  vmovaps xmm6, [rsp+0x60]
000072bd77dde129  vmovaps xmm7, [rsp+0x70]
000072bd77dde12f  vmovaps xmm8, [rsp+0x80]
000072bd77dde138  vmovaps xmm9, [rsp+0x90]
000072bd77dde141  vmovaps xmm10, [rsp+0xA0]
000072bd77dde14a  vmovaps xmm11, [rsp+0xB0]
000072bd77dde153  vmovaps xmm12, [rsp+0xC0]
000072bd77dde15c  vmovaps xmm13, [rsp+0xD0]
000072bd77dde165  vmovaps xmm14, [rsp+0xE0]
000072bd77dde16e  add rsp, 0xF0
000072bd77dde175  pop r11
000072bd77dde177  pop r10
000072bd77dde179  pop r9
000072bd77dde17b  pop r8
000072bd77dde17d  pop rsi
000072bd77dde17e  pop rdi
000072bd77dde17f  pop rdx
000072bd77dde180  pop rcx
000072bd77dde181  pop rax
000072bd77dde182  add rsp, 0x08
000072bd77dde186  jmp 0x000072BD77DDC099
000072bd77dde18b  sub rsp, 0x08
000072bd77dde18f  push rax
000072bd77dde190  push rcx
000072bd77dde191  push rdx
000072bd77dde192  push rdi
000072bd77dde193  push rsi
000072bd77dde194  push r8
000072bd77dde196  push r9
000072bd77dde198  push r10
000072bd77dde19a  push r11
000072bd77dde19c  sub rsp, 0xF0
000072bd77dde1a3  vmovaps [rsp], xmm0
000072bd77dde1a8  vmovaps [rsp+0x10], xmm2
000072bd77dde1ae  vmovaps [rsp+0x20], xmm3
000072bd77dde1b4  vmovaps [rsp+0x30], xmm4
000072bd77dde1ba  vmovaps [rsp+0x40], xmm5
000072bd77dde1c0  vmovaps [rsp+0x50], xmm6
000072bd77dde1c6  vmovaps [rsp+0x60], xmm7
000072bd77dde1cc  vmovaps [rsp+0x70], xmm8
000072bd77dde1d2  vmovaps [rsp+0x80], xmm9
000072bd77dde1db  vmovaps [rsp+0x90], xmm10
000072bd77dde1e4  vmovaps [rsp+0xA0], xmm11
000072bd77dde1ed  vmovaps [rsp+0xB0], xmm12
000072bd77dde1f6  vmovaps [rsp+0xC0], xmm13
000072bd77dde1ff  vmovaps [rsp+0xD0], xmm14
000072bd77dde208  vmovaps [rsp+0xE0], xmm15
000072bd77dde211  sub rsp, 0x30
000072bd77dde215  movaps [rsp], xmm1
000072bd77dde219  movaps [rsp+0x10], xmm5
000072bd77dde21e  movaps [rsp+0x20], xmm4
000072bd77dde223  lea rdi, [rsp]
000072bd77dde227  mov esi, 0x00
000072bd77dde22c  mov rax, 0x643206AC3530
000072bd77dde236  call rax
000072bd77dde238  movaps xmm1, [rsp]
000072bd77dde23c  add rsp, 0x30
000072bd77dde240  vmovaps xmm0, [rsp]
000072bd77dde245  vmovaps xmm2, [rsp+0x10]
000072bd77dde24b  vmovaps xmm3, [rsp+0x20]
000072bd77dde251  vmovaps xmm4, [rsp+0x30]
000072bd77dde257  vmovaps xmm5, [rsp+0x40]
000072bd77dde25d  vmovaps xmm6, [rsp+0x50]
000072bd77dde263  vmovaps xmm7, [rsp+0x60]
000072bd77dde269  vmovaps xmm8, [rsp+0x70]
000072bd77dde26f  vmovaps xmm9, [rsp+0x80]
000072bd77dde278  vmovaps xmm10, [rsp+0x90]
000072bd77dde281  vmovaps xmm11, [rsp+0xA0]
000072bd77dde28a  vmovaps xmm12, [rsp+0xB0]
000072bd77dde293  vmovaps xmm13, [rsp+0xC0]
000072bd77dde29c  vmovaps xmm14, [rsp+0xD0]
000072bd77dde2a5  vmovaps xmm15, [rsp+0xE0]
000072bd77dde2ae  add rsp, 0xF0
000072bd77dde2b5  pop r11
000072bd77dde2b7  pop r10
000072bd77dde2b9  pop r9
000072bd77dde2bb  pop r8
000072bd77dde2bd  pop rsi
000072bd77dde2be  pop rdi
000072bd77dde2bf  pop rdx
000072bd77dde2c0  pop rcx
000072bd77dde2c1  pop rax
000072bd77dde2c2  add rsp, 0x08
000072bd77dde2c6  jmp 0x000072BD77DDC0B9
000072bd77dde2cb  sub rsp, 0x08
000072bd77dde2cf  push rax
000072bd77dde2d0  push rcx
000072bd77dde2d1  push rdx
000072bd77dde2d2  push rdi
000072bd77dde2d3  push rsi
000072bd77dde2d4  push r8
000072bd77dde2d6  push r9
000072bd77dde2d8  push r10
000072bd77dde2da  push r11
000072bd77dde2dc  sub rsp, 0xF0
000072bd77dde2e3  vmovaps [rsp], xmm0
000072bd77dde2e8  vmovaps [rsp+0x10], xmm1
000072bd77dde2ee  vmovaps [rsp+0x20], xmm2
000072bd77dde2f4  vmovaps [rsp+0x30], xmm3
000072bd77dde2fa  vmovaps [rsp+0x40], xmm5
000072bd77dde300  vmovaps [rsp+0x50], xmm6
000072bd77dde306  vmovaps [rsp+0x60], xmm7
000072bd77dde30c  vmovaps [rsp+0x70], xmm8
000072bd77dde312  vmovaps [rsp+0x80], xmm9
000072bd77dde31b  vmovaps [rsp+0x90], xmm10
000072bd77dde324  vmovaps [rsp+0xA0], xmm11
000072bd77dde32d  vmovaps [rsp+0xB0], xmm12
000072bd77dde336  vmovaps [rsp+0xC0], xmm13
000072bd77dde33f  vmovaps [rsp+0xD0], xmm14
000072bd77dde348  vmovaps [rsp+0xE0], xmm15
000072bd77dde351  sub rsp, 0x30
000072bd77dde355  movaps [rsp], xmm4
000072bd77dde359  movaps [rsp+0x10], xmm3
000072bd77dde35e  movaps [rsp+0x20], xmm5
000072bd77dde363  lea rdi, [rsp]
000072bd77dde367  mov esi, 0x00
000072bd77dde36c  mov rax, 0x643206AC3530
000072bd77dde376  call rax
000072bd77dde378  movaps xmm4, [rsp]
000072bd77dde37c  add rsp, 0x30
000072bd77dde380  vmovaps xmm0, [rsp]
000072bd77dde385  vmovaps xmm1, [rsp+0x10]
000072bd77dde38b  vmovaps xmm2, [rsp+0x20]
000072bd77dde391  vmovaps xmm3, [rsp+0x30]
000072bd77dde397  vmovaps xmm5, [rsp+0x40]
000072bd77dde39d  vmovaps xmm6, [rsp+0x50]
000072bd77dde3a3  vmovaps xmm7, [rsp+0x60]
000072bd77dde3a9  vmovaps xmm8, [rsp+0x70]
000072bd77dde3af  vmovaps xmm9, [rsp+0x80]
000072bd77dde3b8  vmovaps xmm10, [rsp+0x90]
000072bd77dde3c1  vmovaps xmm11, [rsp+0xA0]
000072bd77dde3ca  vmovaps xmm12, [rsp+0xB0]
000072bd77dde3d3  vmovaps xmm13, [rsp+0xC0]
000072bd77dde3dc  vmovaps xmm14, [rsp+0xD0]
000072bd77dde3e5  vmovaps xmm15, [rsp+0xE0]
000072bd77dde3ee  add rsp, 0xF0
000072bd77dde3f5  pop r11
000072bd77dde3f7  pop r10
000072bd77dde3f9  pop r9
000072bd77dde3fb  pop r8
000072bd77dde3fd  pop rsi
000072bd77dde3fe  pop rdi
000072bd77dde3ff  pop rdx
000072bd77dde400  pop rcx
000072bd77dde401  pop rax
000072bd77dde402  add rsp, 0x08
000072bd77dde406  jmp 0x000072BD77DDC107
000072bd77dde40b  call 0x000072BD77CB52F0
000072bd77dde410  jmp 0x000072BD77DDC114
000072bd77dde415  sub rsp, 0x08
000072bd77dde419  push rax
000072bd77dde41a  push rcx
000072bd77dde41b  push rdx
000072bd77dde41c  push rdi
000072bd77dde41d  push rsi
000072bd77dde41e  push r8
000072bd77dde420  push r9
000072bd77dde422  push r10
000072bd77dde424  push r11
000072bd77dde426  sub rsp, 0xF0
000072bd77dde42d  vmovaps [rsp], xmm0
000072bd77dde432  vmovaps [rsp+0x10], xmm1
000072bd77dde438  vmovaps [rsp+0x20], xmm2
000072bd77dde43e  vmovaps [rsp+0x30], xmm3
000072bd77dde444  vmovaps [rsp+0x40], xmm4
000072bd77dde44a  vmovaps [rsp+0x50], xmm6
000072bd77dde450  vmovaps [rsp+0x60], xmm7
000072bd77dde456  vmovaps [rsp+0x70], xmm8
000072bd77dde45c  vmovaps [rsp+0x80], xmm9
000072bd77dde465  vmovaps [rsp+0x90], xmm10
000072bd77dde46e  vmovaps [rsp+0xA0], xmm11
000072bd77dde477  vmovaps [rsp+0xB0], xmm12
000072bd77dde480  vmovaps [rsp+0xC0], xmm13
000072bd77dde489  vmovaps [rsp+0xD0], xmm14
000072bd77dde492  vmovaps [rsp+0xE0], xmm15
000072bd77dde49b  sub rsp, 0x30
000072bd77dde49f  movaps [rsp], xmm5
000072bd77dde4a3  movaps [rsp+0x10], xmm6
000072bd77dde4a8  movaps [rsp+0x20], xmm3
000072bd77dde4ad  lea rdi, [rsp]
000072bd77dde4b1  mov esi, 0x00
000072bd77dde4b6  mov rax, 0x643206AC3530
000072bd77dde4c0  call rax
000072bd77dde4c2  movaps xmm5, [rsp]
000072bd77dde4c6  add rsp, 0x30
000072bd77dde4ca  vmovaps xmm0, [rsp]
000072bd77dde4cf  vmovaps xmm1, [rsp+0x10]
000072bd77dde4d5  vmovaps xmm2, [rsp+0x20]
000072bd77dde4db  vmovaps xmm3, [rsp+0x30]
000072bd77dde4e1  vmovaps xmm4, [rsp+0x40]
000072bd77dde4e7  vmovaps xmm6, [rsp+0x50]
000072bd77dde4ed  vmovaps xmm7, [rsp+0x60]
000072bd77dde4f3  vmovaps xmm8, [rsp+0x70]
000072bd77dde4f9  vmovaps xmm9, [rsp+0x80]
000072bd77dde502  vmovaps xmm10, [rsp+0x90]
000072bd77dde50b  vmovaps xmm11, [rsp+0xA0]
000072bd77dde514  vmovaps xmm12, [rsp+0xB0]
000072bd77dde51d  vmovaps xmm13, [rsp+0xC0]
000072bd77dde526  vmovaps xmm14, [rsp+0xD0]
000072bd77dde52f  vmovaps xmm15, [rsp+0xE0]
000072bd77dde538  add rsp, 0xF0
000072bd77dde53f  pop r11
000072bd77dde541  pop r10
000072bd77dde543  pop r9
000072bd77dde545  pop r8
000072bd77dde547  pop rsi
000072bd77dde548  pop rdi
000072bd77dde549  pop rdx
000072bd77dde54a  pop rcx
000072bd77dde54b  pop rax
000072bd77dde54c  add rsp, 0x08
000072bd77dde550  jmp 0x000072BD77DDC13A
000072bd77dde555  sub rsp, 0x08
000072bd77dde559  push rax
000072bd77dde55a  push rcx
000072bd77dde55b  push rdx
000072bd77dde55c  push rdi
000072bd77dde55d  push rsi
000072bd77dde55e  push r8
000072bd77dde560  push r9
000072bd77dde562  push r10
000072bd77dde564  push r11
000072bd77dde566  sub rsp, 0xF0
000072bd77dde56d  vmovaps [rsp], xmm0
000072bd77dde572  vmovaps [rsp+0x10], xmm1
000072bd77dde578  vmovaps [rsp+0x20], xmm2
000072bd77dde57e  vmovaps [rsp+0x30], xmm3
000072bd77dde584  vmovaps [rsp+0x40], xmm4
000072bd77dde58a  vmovaps [rsp+0x50], xmm5
000072bd77dde590  vmovaps [rsp+0x60], xmm7
000072bd77dde596  vmovaps [rsp+0x70], xmm8
000072bd77dde59c  vmovaps [rsp+0x80], xmm9
000072bd77dde5a5  vmovaps [rsp+0x90], xmm10
000072bd77dde5ae  vmovaps [rsp+0xA0], xmm11
000072bd77dde5b7  vmovaps [rsp+0xB0], xmm12
000072bd77dde5c0  vmovaps [rsp+0xC0], xmm13
000072bd77dde5c9  vmovaps [rsp+0xD0], xmm14
000072bd77dde5d2  vmovaps [rsp+0xE0], xmm15
000072bd77dde5db  sub rsp, 0x30
000072bd77dde5df  movaps [rsp], xmm6
000072bd77dde5e3  movaps [rsp+0x10], xmm9
000072bd77dde5e9  movaps [rsp+0x20], xmm1
000072bd77dde5ee  lea rdi, [rsp]
000072bd77dde5f2  mov esi, 0x00
000072bd77dde5f7  mov rax, 0x643206AC3530
000072bd77dde601  call rax
000072bd77dde603  movaps xmm6, [rsp]
000072bd77dde607  add rsp, 0x30
000072bd77dde60b  vmovaps xmm0, [rsp]
000072bd77dde610  vmovaps xmm1, [rsp+0x10]
000072bd77dde616  vmovaps xmm2, [rsp+0x20]
000072bd77dde61c  vmovaps xmm3, [rsp+0x30]
000072bd77dde622  vmovaps xmm4, [rsp+0x40]
000072bd77dde628  vmovaps xmm5, [rsp+0x50]
000072bd77dde62e  vmovaps xmm7, [rsp+0x60]
000072bd77dde634  vmovaps xmm8, [rsp+0x70]
000072bd77dde63a  vmovaps xmm9, [rsp+0x80]
000072bd77dde643  vmovaps xmm10, [rsp+0x90]
000072bd77dde64c  vmovaps xmm11, [rsp+0xA0]
000072bd77dde655  vmovaps xmm12, [rsp+0xB0]
000072bd77dde65e  vmovaps xmm13, [rsp+0xC0]
000072bd77dde667  vmovaps xmm14, [rsp+0xD0]
000072bd77dde670  vmovaps xmm15, [rsp+0xE0]
000072bd77dde679  add rsp, 0xF0
000072bd77dde680  pop r11
000072bd77dde682  pop r10
000072bd77dde684  pop r9
000072bd77dde686  pop r8
000072bd77dde688  pop rsi
000072bd77dde689  pop rdi
000072bd77dde68a  pop rdx
000072bd77dde68b  pop rcx
000072bd77dde68c  pop rax
000072bd77dde68d  add rsp, 0x08
000072bd77dde691  jmp 0x000072BD77DDC15E
000072bd77dde696  sub rsp, 0x08
000072bd77dde69a  push rax
000072bd77dde69b  push rcx
000072bd77dde69c  push rdx
000072bd77dde69d  push rdi
000072bd77dde69e  push rsi
000072bd77dde69f  push r8
000072bd77dde6a1  push r9
000072bd77dde6a3  push r10
000072bd77dde6a5  push r11
000072bd77dde6a7  sub rsp, 0xF0
000072bd77dde6ae  vmovaps [rsp], xmm0
000072bd77dde6b3  vmovaps [rsp+0x10], xmm1
000072bd77dde6b9  vmovaps [rsp+0x20], xmm2
000072bd77dde6bf  vmovaps [rsp+0x30], xmm3
000072bd77dde6c5  vmovaps [rsp+0x40], xmm4
000072bd77dde6cb  vmovaps [rsp+0x50], xmm5
000072bd77dde6d1  vmovaps [rsp+0x60], xmm6
000072bd77dde6d7  vmovaps [rsp+0x70], xmm7
000072bd77dde6dd  vmovaps [rsp+0x80], xmm8
000072bd77dde6e6  vmovaps [rsp+0x90], xmm10
000072bd77dde6ef  vmovaps [rsp+0xA0], xmm11
000072bd77dde6f8  vmovaps [rsp+0xB0], xmm12
000072bd77dde701  vmovaps [rsp+0xC0], xmm13
000072bd77dde70a  vmovaps [rsp+0xD0], xmm14
000072bd77dde713  vmovaps [rsp+0xE0], xmm15
000072bd77dde71c  sub rsp, 0x30
000072bd77dde720  movaps [rsp], xmm9
000072bd77dde725  movaps [rsp+0x10], xmm3
000072bd77dde72a  movaps [rsp+0x20], xmm1
000072bd77dde72f  lea rdi, [rsp]
000072bd77dde733  mov esi, 0x00
000072bd77dde738  mov rax, 0x643206AC3530
000072bd77dde742  call rax
000072bd77dde744  movaps xmm9, [rsp]
000072bd77dde749  add rsp, 0x30
000072bd77dde74d  vmovaps xmm0, [rsp]
000072bd77dde752  vmovaps xmm1, [rsp+0x10]
000072bd77dde758  vmovaps xmm2, [rsp+0x20]
000072bd77dde75e  vmovaps xmm3, [rsp+0x30]
000072bd77dde764  vmovaps xmm4, [rsp+0x40]
000072bd77dde76a  vmovaps xmm5, [rsp+0x50]
000072bd77dde770  vmovaps xmm6, [rsp+0x60]
000072bd77dde776  vmovaps xmm7, [rsp+0x70]
000072bd77dde77c  vmovaps xmm8, [rsp+0x80]
000072bd77dde785  vmovaps xmm10, [rsp+0x90]
000072bd77dde78e  vmovaps xmm11, [rsp+0xA0]
000072bd77dde797  vmovaps xmm12, [rsp+0xB0]
000072bd77dde7a0  vmovaps xmm13, [rsp+0xC0]
000072bd77dde7a9  vmovaps xmm14, [rsp+0xD0]
000072bd77dde7b2  vmovaps xmm15, [rsp+0xE0]
000072bd77dde7bb  add rsp, 0xF0
000072bd77dde7c2  pop r11
000072bd77dde7c4  pop r10
000072bd77dde7c6  pop r9
000072bd77dde7c8  pop r8
000072bd77dde7ca  pop rsi
000072bd77dde7cb  pop rdi
000072bd77dde7cc  pop rdx
000072bd77dde7cd  pop rcx
000072bd77dde7ce  pop rax
000072bd77dde7cf  add rsp, 0x08
000072bd77dde7d3  jmp 0x000072BD77DDC1AA
000072bd77dde7d8  call 0x000072BD77CB52F0
000072bd77dde7dd  jmp 0x000072BD77DDC1B7
000072bd77dde7e2  sub rsp, 0x08
000072bd77dde7e6  push rax
000072bd77dde7e7  push rcx
000072bd77dde7e8  push rdx
000072bd77dde7e9  push rdi
000072bd77dde7ea  push rsi
000072bd77dde7eb  push r8
000072bd77dde7ed  push r9
000072bd77dde7ef  push r10
000072bd77dde7f1  push r11
000072bd77dde7f3  sub rsp, 0xF0
000072bd77dde7fa  vmovaps [rsp], xmm0
000072bd77dde7ff  vmovaps [rsp+0x10], xmm1
000072bd77dde805  vmovaps [rsp+0x20], xmm2
000072bd77dde80b  vmovaps [rsp+0x30], xmm3
000072bd77dde811  vmovaps [rsp+0x40], xmm4
000072bd77dde817  vmovaps [rsp+0x50], xmm5
000072bd77dde81d  vmovaps [rsp+0x60], xmm6
000072bd77dde823  vmovaps [rsp+0x70], xmm7
000072bd77dde829  vmovaps [rsp+0x80], xmm8
000072bd77dde832  vmovaps [rsp+0x90], xmm9
000072bd77dde83b  vmovaps [rsp+0xA0], xmm10
000072bd77dde844  vmovaps [rsp+0xB0], xmm11
000072bd77dde84d  vmovaps [rsp+0xC0], xmm12
000072bd77dde856  vmovaps [rsp+0xD0], xmm13
000072bd77dde85f  vmovaps [rsp+0xE0], xmm14
000072bd77dde868  sub rsp, 0x30
000072bd77dde86c  movaps [rsp], xmm15
000072bd77dde871  movaps [rsp+0x10], xmm3
000072bd77dde876  movaps [rsp+0x20], xmm7
000072bd77dde87b  lea rdi, [rsp]
000072bd77dde87f  mov esi, 0x00
000072bd77dde884  mov rax, 0x643206AC3530
000072bd77dde88e  call rax
000072bd77dde890  movaps xmm15, [rsp]
000072bd77dde895  add rsp, 0x30
000072bd77dde899  vmovaps xmm0, [rsp]
000072bd77dde89e  vmovaps xmm1, [rsp+0x10]
000072bd77dde8a4  vmovaps xmm2, [rsp+0x20]
000072bd77dde8aa  vmovaps xmm3, [rsp+0x30]
000072bd77dde8b0  vmovaps xmm4, [rsp+0x40]
000072bd77dde8b6  vmovaps xmm5, [rsp+0x50]
000072bd77dde8bc  vmovaps xmm6, [rsp+0x60]
000072bd77dde8c2  vmovaps xmm7, [rsp+0x70]
000072bd77dde8c8  vmovaps xmm8, [rsp+0x80]
000072bd77dde8d1  vmovaps xmm9, [rsp+0x90]
000072bd77dde8da  vmovaps xmm10, [rsp+0xA0]
000072bd77dde8e3  vmovaps xmm11, [rsp+0xB0]
000072bd77dde8ec  vmovaps xmm12, [rsp+0xC0]
000072bd77dde8f5  vmovaps xmm13, [rsp+0xD0]
000072bd77dde8fe  vmovaps xmm14, [rsp+0xE0]
000072bd77dde907  add rsp, 0xF0
000072bd77dde90e  pop r11
000072bd77dde910  pop r10
000072bd77dde912  pop r9
000072bd77dde914  pop r8
000072bd77dde916  pop rsi
000072bd77dde917  pop rdi
000072bd77dde918  pop rdx
000072bd77dde919  pop rcx
000072bd77dde91a  pop rax
000072bd77dde91b  add rsp, 0x08
000072bd77dde91f  jmp 0x000072BD77DDC1E3
000072bd77dde924  sub rsp, 0x08
000072bd77dde928  push rax
000072bd77dde929  push rcx
000072bd77dde92a  push rdx
000072bd77dde92b  push rdi
000072bd77dde92c  push rsi
000072bd77dde92d  push r8
000072bd77dde92f  push r9
000072bd77dde931  push r10
000072bd77dde933  push r11
000072bd77dde935  sub rsp, 0xF0
000072bd77dde93c  vmovaps [rsp], xmm0
000072bd77dde941  vmovaps [rsp+0x10], xmm1
000072bd77dde947  vmovaps [rsp+0x20], xmm2
000072bd77dde94d  vmovaps [rsp+0x30], xmm4
000072bd77dde953  vmovaps [rsp+0x40], xmm5
000072bd77dde959  vmovaps [rsp+0x50], xmm6
000072bd77dde95f  vmovaps [rsp+0x60], xmm7
000072bd77dde965  vmovaps [rsp+0x70], xmm8
000072bd77dde96b  vmovaps [rsp+0x80], xmm9
000072bd77dde974  vmovaps [rsp+0x90], xmm10
000072bd77dde97d  vmovaps [rsp+0xA0], xmm11
000072bd77dde986  vmovaps [rsp+0xB0], xmm12
000072bd77dde98f  vmovaps [rsp+0xC0], xmm13
000072bd77dde998  vmovaps [rsp+0xD0], xmm14
000072bd77dde9a1  vmovaps [rsp+0xE0], xmm15
000072bd77dde9aa  sub rsp, 0x30
000072bd77dde9ae  movaps [rsp], xmm3
000072bd77dde9b2  movaps [rsp+0x10], xmm1
000072bd77dde9b7  movaps [rsp+0x20], xmm15
000072bd77dde9bd  lea rdi, [rsp]
000072bd77dde9c1  mov esi, 0x00
000072bd77dde9c6  mov rax, 0x643206AC3530
000072bd77dde9d0  call rax
000072bd77dde9d2  movaps xmm3, [rsp]
000072bd77dde9d6  add rsp, 0x30
000072bd77dde9da  vmovaps xmm0, [rsp]
000072bd77dde9df  vmovaps xmm1, [rsp+0x10]
000072bd77dde9e5  vmovaps xmm2, [rsp+0x20]
000072bd77dde9eb  vmovaps xmm4, [rsp+0x30]
000072bd77dde9f1  vmovaps xmm5, [rsp+0x40]
000072bd77dde9f7  vmovaps xmm6, [rsp+0x50]
000072bd77dde9fd  vmovaps xmm7, [rsp+0x60]
000072bd77ddea03  vmovaps xmm8, [rsp+0x70]
000072bd77ddea09  vmovaps xmm9, [rsp+0x80]
000072bd77ddea12  vmovaps xmm10, [rsp+0x90]
000072bd77ddea1b  vmovaps xmm11, [rsp+0xA0]
000072bd77ddea24  vmovaps xmm12, [rsp+0xB0]
000072bd77ddea2d  vmovaps xmm13, [rsp+0xC0]
000072bd77ddea36  vmovaps xmm14, [rsp+0xD0]
000072bd77ddea3f  vmovaps xmm15, [rsp+0xE0]
000072bd77ddea48  add rsp, 0xF0
000072bd77ddea4f  pop r11
000072bd77ddea51  pop r10
000072bd77ddea53  pop r9
000072bd77ddea55  pop r8
000072bd77ddea57  pop rsi
000072bd77ddea58  pop rdi
000072bd77ddea59  pop rdx
000072bd77ddea5a  pop rcx
000072bd77ddea5b  pop rax
000072bd77ddea5c  add rsp, 0x08
000072bd77ddea60  jmp 0x000072BD77DDC272
000072bd77ddea65  call 0x000072BD77CB52F0
000072bd77ddea6a  jmp 0x000072BD77DDC27C
000072bd77ddea6f  sub rsp, 0x08
000072bd77ddea73  push rax
000072bd77ddea74  push rcx
000072bd77ddea75  push rdx
000072bd77ddea76  push rdi
000072bd77ddea77  push rsi
000072bd77ddea78  push r8
000072bd77ddea7a  push r9
000072bd77ddea7c  push r10
000072bd77ddea7e  push r11
000072bd77ddea80  sub rsp, 0xF0
000072bd77ddea87  vmovaps [rsp], xmm0
000072bd77ddea8c  vmovaps [rsp+0x10], xmm1
000072bd77ddea92  vmovaps [rsp+0x20], xmm2
000072bd77ddea98  vmovaps [rsp+0x30], xmm3
000072bd77ddea9e  vmovaps [rsp+0x40], xmm4
000072bd77ddeaa4  vmovaps [rsp+0x50], xmm5
000072bd77ddeaaa  vmovaps [rsp+0x60], xmm6
000072bd77ddeab0  vmovaps [rsp+0x70], xmm7
000072bd77ddeab6  vmovaps [rsp+0x80], xmm8
000072bd77ddeabf  vmovaps [rsp+0x90], xmm9
000072bd77ddeac8  vmovaps [rsp+0xA0], xmm10
000072bd77ddead1  vmovaps [rsp+0xB0], xmm11
000072bd77ddeada  vmovaps [rsp+0xC0], xmm12
000072bd77ddeae3  vmovaps [rsp+0xD0], xmm13
000072bd77ddeaec  vmovaps [rsp+0xE0], xmm14
000072bd77ddeaf5  sub rsp, 0x30
000072bd77ddeaf9  movaps [rsp], xmm15
000072bd77ddeafe  movaps [rsp+0x10], xmm14
000072bd77ddeb04  movaps [rsp+0x20], xmm4
000072bd77ddeb09  lea rdi, [rsp]
000072bd77ddeb0d  mov esi, 0x00
000072bd77ddeb12  mov rax, 0x643206AC3530
000072bd77ddeb1c  call rax
000072bd77ddeb1e  movaps xmm15, [rsp]
000072bd77ddeb23  add rsp, 0x30
000072bd77ddeb27  vmovaps xmm0, [rsp]
000072bd77ddeb2c  vmovaps xmm1, [rsp+0x10]
000072bd77ddeb32  vmovaps xmm2, [rsp+0x20]
000072bd77ddeb38  vmovaps xmm3, [rsp+0x30]
000072bd77ddeb3e  vmovaps xmm4, [rsp+0x40]
000072bd77ddeb44  vmovaps xmm5, [rsp+0x50]
000072bd77ddeb4a  vmovaps xmm6, [rsp+0x60]
000072bd77ddeb50  vmovaps xmm7, [rsp+0x70]
000072bd77ddeb56  vmovaps xmm8, [rsp+0x80]
000072bd77ddeb5f  vmovaps xmm9, [rsp+0x90]
000072bd77ddeb68  vmovaps xmm10, [rsp+0xA0]
000072bd77ddeb71  vmovaps xmm11, [rsp+0xB0]
000072bd77ddeb7a  vmovaps xmm12, [rsp+0xC0]
000072bd77ddeb83  vmovaps xmm13, [rsp+0xD0]
000072bd77ddeb8c  vmovaps xmm14, [rsp+0xE0]
000072bd77ddeb95  add rsp, 0xF0
000072bd77ddeb9c  pop r11
000072bd77ddeb9e  pop r10
000072bd77ddeba0  pop r9
000072bd77ddeba2  pop r8
000072bd77ddeba4  pop rsi
000072bd77ddeba5  pop rdi
000072bd77ddeba6  pop rdx
000072bd77ddeba7  pop rcx
000072bd77ddeba8  pop rax
000072bd77ddeba9  add rsp, 0x08
000072bd77ddebad  jmp 0x000072BD77DDC2AA
000072bd77ddebb2  sub rsp, 0x08
000072bd77ddebb6  push rax
000072bd77ddebb7  push rcx
000072bd77ddebb8  push rdx
000072bd77ddebb9  push rdi
000072bd77ddebba  push rsi
000072bd77ddebbb  push r8
000072bd77ddebbd  push r9
000072bd77ddebbf  push r10
000072bd77ddebc1  push r11
000072bd77ddebc3  sub rsp, 0xF0
000072bd77ddebca  vmovaps [rsp], xmm0
000072bd77ddebcf  vmovaps [rsp+0x10], xmm1
000072bd77ddebd5  vmovaps [rsp+0x20], xmm2
000072bd77ddebdb  vmovaps [rsp+0x30], xmm3
000072bd77ddebe1  vmovaps [rsp+0x40], xmm4
000072bd77ddebe7  vmovaps [rsp+0x50], xmm5
000072bd77ddebed  vmovaps [rsp+0x60], xmm6
000072bd77ddebf3  vmovaps [rsp+0x70], xmm7
000072bd77ddebf9  vmovaps [rsp+0x80], xmm8
000072bd77ddec02  vmovaps [rsp+0x90], xmm9
000072bd77ddec0b  vmovaps [rsp+0xA0], xmm10
000072bd77ddec14  vmovaps [rsp+0xB0], xmm11
000072bd77ddec1d  vmovaps [rsp+0xC0], xmm12
000072bd77ddec26  vmovaps [rsp+0xD0], xmm13
000072bd77ddec2f  vmovaps [rsp+0xE0], xmm15
000072bd77ddec38  sub rsp, 0x30
000072bd77ddec3c  movaps [rsp], xmm14
000072bd77ddec41  movaps [rsp+0x10], xmm2
000072bd77ddec46  movaps [rsp+0x20], xmm1
000072bd77ddec4b  lea rdi, [rsp]
000072bd77ddec4f  mov esi, 0x00
000072bd77ddec54  mov rax, 0x643206AC3530
000072bd77ddec5e  call rax
000072bd77ddec60  movaps xmm14, [rsp]
000072bd77ddec65  add rsp, 0x30
000072bd77ddec69  vmovaps xmm0, [rsp]
000072bd77ddec6e  vmovaps xmm1, [rsp+0x10]
000072bd77ddec74  vmovaps xmm2, [rsp+0x20]
000072bd77ddec7a  vmovaps xmm3, [rsp+0x30]
000072bd77ddec80  vmovaps xmm4, [rsp+0x40]
000072bd77ddec86  vmovaps xmm5, [rsp+0x50]
000072bd77ddec8c  vmovaps xmm6, [rsp+0x60]
000072bd77ddec92  vmovaps xmm7, [rsp+0x70]
000072bd77ddec98  vmovaps xmm8, [rsp+0x80]
000072bd77ddeca1  vmovaps xmm9, [rsp+0x90]
000072bd77ddecaa  vmovaps xmm10, [rsp+0xA0]
000072bd77ddecb3  vmovaps xmm11, [rsp+0xB0]
000072bd77ddecbc  vmovaps xmm12, [rsp+0xC0]
000072bd77ddecc5  vmovaps xmm13, [rsp+0xD0]
000072bd77ddecce  vmovaps xmm15, [rsp+0xE0]
000072bd77ddecd7  add rsp, 0xF0
000072bd77ddecde  pop r11
000072bd77ddece0  pop r10
000072bd77ddece2  pop r9
000072bd77ddece4  pop r8
000072bd77ddece6  pop rsi
000072bd77ddece7  pop rdi
000072bd77ddece8  pop rdx
000072bd77ddece9  pop rcx
000072bd77ddecea  pop rax
000072bd77ddeceb  add rsp, 0x08
000072bd77ddecef  jmp 0x000072BD77DDC2D0
000072bd77ddecf4  sub rsp, 0x08
000072bd77ddecf8  push rax
000072bd77ddecf9  push rcx
000072bd77ddecfa  push rdx
000072bd77ddecfb  push rdi
000072bd77ddecfc  push rsi
000072bd77ddecfd  push r8
000072bd77ddecff  push r9
000072bd77dded01  push r10
000072bd77dded03  push r11
000072bd77dded05  sub rsp, 0xF0
000072bd77dded0c  vmovaps [rsp], xmm0
000072bd77dded11  vmovaps [rsp+0x10], xmm2
000072bd77dded17  vmovaps [rsp+0x20], xmm3
000072bd77dded1d  vmovaps [rsp+0x30], xmm4
000072bd77dded23  vmovaps [rsp+0x40], xmm5
000072bd77dded29  vmovaps [rsp+0x50], xmm6
000072bd77dded2f  vmovaps [rsp+0x60], xmm7
000072bd77dded35  vmovaps [rsp+0x70], xmm8
000072bd77dded3b  vmovaps [rsp+0x80], xmm9
000072bd77dded44  vmovaps [rsp+0x90], xmm10
000072bd77dded4d  vmovaps [rsp+0xA0], xmm11
000072bd77dded56  vmovaps [rsp+0xB0], xmm12
000072bd77dded5f  vmovaps [rsp+0xC0], xmm13
000072bd77dded68  vmovaps [rsp+0xD0], xmm14
000072bd77dded71  vmovaps [rsp+0xE0], xmm15
000072bd77dded7a  sub rsp, 0x30
000072bd77dded7e  movaps [rsp], xmm1
000072bd77dded82  movaps [rsp+0x10], xmm4
000072bd77dded87  movaps [rsp+0x20], xmm9
000072bd77dded8d  lea rdi, [rsp]
000072bd77dded91  mov esi, 0x00
000072bd77dded96  mov rax, 0x643206AC3530
000072bd77ddeda0  call rax
000072bd77ddeda2  movaps xmm1, [rsp]
000072bd77ddeda6  add rsp, 0x30
000072bd77ddedaa  vmovaps xmm0, [rsp]
000072bd77ddedaf  vmovaps xmm2, [rsp+0x10]
000072bd77ddedb5  vmovaps xmm3, [rsp+0x20]
000072bd77ddedbb  vmovaps xmm4, [rsp+0x30]
000072bd77ddedc1  vmovaps xmm5, [rsp+0x40]
000072bd77ddedc7  vmovaps xmm6, [rsp+0x50]
000072bd77ddedcd  vmovaps xmm7, [rsp+0x60]
000072bd77ddedd3  vmovaps xmm8, [rsp+0x70]
000072bd77ddedd9  vmovaps xmm9, [rsp+0x80]
000072bd77ddede2  vmovaps xmm10, [rsp+0x90]
000072bd77ddedeb  vmovaps xmm11, [rsp+0xA0]
000072bd77ddedf4  vmovaps xmm12, [rsp+0xB0]
000072bd77ddedfd  vmovaps xmm13, [rsp+0xC0]
000072bd77ddee06  vmovaps xmm14, [rsp+0xD0]
000072bd77ddee0f  vmovaps xmm15, [rsp+0xE0]
000072bd77ddee18  add rsp, 0xF0
000072bd77ddee1f  pop r11
000072bd77ddee21  pop r10
000072bd77ddee23  pop r9
000072bd77ddee25  pop r8
000072bd77ddee27  pop rsi
000072bd77ddee28  pop rdi
000072bd77ddee29  pop rdx
000072bd77ddee2a  pop rcx
000072bd77ddee2b  pop rax
000072bd77ddee2c  add rsp, 0x08
000072bd77ddee30  jmp 0x000072BD77DDC2EE
000072bd77ddee35  sub rsp, 0x08
000072bd77ddee39  push rax
000072bd77ddee3a  push rcx
000072bd77ddee3b  push rdx
000072bd77ddee3c  push rdi
000072bd77ddee3d  push rsi
000072bd77ddee3e  push r8
000072bd77ddee40  push r9
000072bd77ddee42  push r10
000072bd77ddee44  push r11
000072bd77ddee46  sub rsp, 0xF0
000072bd77ddee4d  vmovaps [rsp], xmm0
000072bd77ddee52  vmovaps [rsp+0x10], xmm1
000072bd77ddee58  vmovaps [rsp+0x20], xmm2
000072bd77ddee5e  vmovaps [rsp+0x30], xmm3
000072bd77ddee64  vmovaps [rsp+0x40], xmm5
000072bd77ddee6a  vmovaps [rsp+0x50], xmm6
000072bd77ddee70  vmovaps [rsp+0x60], xmm7
000072bd77ddee76  vmovaps [rsp+0x70], xmm8
000072bd77ddee7c  vmovaps [rsp+0x80], xmm9
000072bd77ddee85  vmovaps [rsp+0x90], xmm10
000072bd77ddee8e  vmovaps [rsp+0xA0], xmm11
000072bd77ddee97  vmovaps [rsp+0xB0], xmm12
000072bd77ddeea0  vmovaps [rsp+0xC0], xmm13
000072bd77ddeea9  vmovaps [rsp+0xD0], xmm14
000072bd77ddeeb2  vmovaps [rsp+0xE0], xmm15
000072bd77ddeebb  sub rsp, 0x30
000072bd77ddeebf  movaps [rsp], xmm4
000072bd77ddeec3  movaps [rsp+0x10], xmm2
000072bd77ddeec8  movaps [rsp+0x20], xmm9
000072bd77ddeece  lea rdi, [rsp]
000072bd77ddeed2  mov esi, 0x00
000072bd77ddeed7  mov rax, 0x643206AC3530
000072bd77ddeee1  call rax
000072bd77ddeee3  movaps xmm4, [rsp]
000072bd77ddeee7  add rsp, 0x30
000072bd77ddeeeb  vmovaps xmm0, [rsp]
000072bd77ddeef0  vmovaps xmm1, [rsp+0x10]
000072bd77ddeef6  vmovaps xmm2, [rsp+0x20]
000072bd77ddeefc  vmovaps xmm3, [rsp+0x30]
000072bd77ddef02  vmovaps xmm5, [rsp+0x40]
000072bd77ddef08  vmovaps xmm6, [rsp+0x50]
000072bd77ddef0e  vmovaps xmm7, [rsp+0x60]
000072bd77ddef14  vmovaps xmm8, [rsp+0x70]
000072bd77ddef1a  vmovaps xmm9, [rsp+0x80]
000072bd77ddef23  vmovaps xmm10, [rsp+0x90]
000072bd77ddef2c  vmovaps xmm11, [rsp+0xA0]
000072bd77ddef35  vmovaps xmm12, [rsp+0xB0]
000072bd77ddef3e  vmovaps xmm13, [rsp+0xC0]
000072bd77ddef47  vmovaps xmm14, [rsp+0xD0]
000072bd77ddef50  vmovaps xmm15, [rsp+0xE0]
000072bd77ddef59  add rsp, 0xF0
000072bd77ddef60  pop r11
000072bd77ddef62  pop r10
000072bd77ddef64  pop r9
000072bd77ddef66  pop r8
000072bd77ddef68  pop rsi
000072bd77ddef69  pop rdi
000072bd77ddef6a  pop rdx
000072bd77ddef6b  pop rcx
000072bd77ddef6c  pop rax
000072bd77ddef6d  add rsp, 0x08
000072bd77ddef71  jmp 0x000072BD77DDC31E
000072bd77ddef76  sub rsp, 0x08
000072bd77ddef7a  push rax
000072bd77ddef7b  push rcx
000072bd77ddef7c  push rdx
000072bd77ddef7d  push rdi
000072bd77ddef7e  push rsi
000072bd77ddef7f  push r8
000072bd77ddef81  push r9
000072bd77ddef83  push r10
000072bd77ddef85  push r11
000072bd77ddef87  sub rsp, 0xF0
000072bd77ddef8e  vmovaps [rsp], xmm0
000072bd77ddef93  vmovaps [rsp+0x10], xmm1
000072bd77ddef99  vmovaps [rsp+0x20], xmm2
000072bd77ddef9f  vmovaps [rsp+0x30], xmm3
000072bd77ddefa5  vmovaps [rsp+0x40], xmm4
000072bd77ddefab  vmovaps [rsp+0x50], xmm5
000072bd77ddefb1  vmovaps [rsp+0x60], xmm6
000072bd77ddefb7  vmovaps [rsp+0x70], xmm7
000072bd77ddefbd  vmovaps [rsp+0x80], xmm8
000072bd77ddefc6  vmovaps [rsp+0x90], xmm10
000072bd77ddefcf  vmovaps [rsp+0xA0], xmm11
000072bd77ddefd8  vmovaps [rsp+0xB0], xmm12
000072bd77ddefe1  vmovaps [rsp+0xC0], xmm13
000072bd77ddefea  vmovaps [rsp+0xD0], xmm14
000072bd77ddeff3  vmovaps [rsp+0xE0], xmm15
000072bd77ddeffc  sub rsp, 0x30
000072bd77ddf000  movaps [rsp], xmm9
000072bd77ddf005  movaps [rsp+0x10], xmm2
000072bd77ddf00a  movaps [rsp+0x20], xmm1
000072bd77ddf00f  lea rdi, [rsp]
000072bd77ddf013  mov esi, 0x00
000072bd77ddf018  mov rax, 0x643206AC3530
000072bd77ddf022  call rax
000072bd77ddf024  movaps xmm9, [rsp]
000072bd77ddf029  add rsp, 0x30
000072bd77ddf02d  vmovaps xmm0, [rsp]
000072bd77ddf032  vmovaps xmm1, [rsp+0x10]
000072bd77ddf038  vmovaps xmm2, [rsp+0x20]
000072bd77ddf03e  vmovaps xmm3, [rsp+0x30]
000072bd77ddf044  vmovaps xmm4, [rsp+0x40]
000072bd77ddf04a  vmovaps xmm5, [rsp+0x50]
000072bd77ddf050  vmovaps xmm6, [rsp+0x60]
000072bd77ddf056  vmovaps xmm7, [rsp+0x70]
000072bd77ddf05c  vmovaps xmm8, [rsp+0x80]
000072bd77ddf065  vmovaps xmm10, [rsp+0x90]
000072bd77ddf06e  vmovaps xmm11, [rsp+0xA0]
000072bd77ddf077  vmovaps xmm12, [rsp+0xB0]
000072bd77ddf080  vmovaps xmm13, [rsp+0xC0]
000072bd77ddf089  vmovaps xmm14, [rsp+0xD0]
000072bd77ddf092  vmovaps xmm15, [rsp+0xE0]
000072bd77ddf09b  add rsp, 0xF0
000072bd77ddf0a2  pop r11
000072bd77ddf0a4  pop r10
000072bd77ddf0a6  pop r9
000072bd77ddf0a8  pop r8
000072bd77ddf0aa  pop rsi
000072bd77ddf0ab  pop rdi
000072bd77ddf0ac  pop rdx
000072bd77ddf0ad  pop rcx
000072bd77ddf0ae  pop rax
000072bd77ddf0af  add rsp, 0x08
000072bd77ddf0b3  jmp 0x000072BD77DDC354
000072bd77ddf0b8  sub rsp, 0x08
000072bd77ddf0bc  push rax
000072bd77ddf0bd  push rcx
000072bd77ddf0be  push rdx
000072bd77ddf0bf  push rdi
000072bd77ddf0c0  push rsi
000072bd77ddf0c1  push r8
000072bd77ddf0c3  push r9
000072bd77ddf0c5  push r10
000072bd77ddf0c7  push r11
000072bd77ddf0c9  sub rsp, 0xF0
000072bd77ddf0d0  vmovaps [rsp], xmm0
000072bd77ddf0d5  vmovaps [rsp+0x10], xmm2
000072bd77ddf0db  vmovaps [rsp+0x20], xmm3
000072bd77ddf0e1  vmovaps [rsp+0x30], xmm4
000072bd77ddf0e7  vmovaps [rsp+0x40], xmm5
000072bd77ddf0ed  vmovaps [rsp+0x50], xmm6
000072bd77ddf0f3  vmovaps [rsp+0x60], xmm7
000072bd77ddf0f9  vmovaps [rsp+0x70], xmm8
000072bd77ddf0ff  vmovaps [rsp+0x80], xmm9
000072bd77ddf108  vmovaps [rsp+0x90], xmm10
000072bd77ddf111  vmovaps [rsp+0xA0], xmm11
000072bd77ddf11a  vmovaps [rsp+0xB0], xmm12
000072bd77ddf123  vmovaps [rsp+0xC0], xmm13
000072bd77ddf12c  vmovaps [rsp+0xD0], xmm14
000072bd77ddf135  vmovaps [rsp+0xE0], xmm15
000072bd77ddf13e  sub rsp, 0x30
000072bd77ddf142  movaps [rsp], xmm1
000072bd77ddf146  movaps [rsp+0x10], xmm15
000072bd77ddf14c  movaps [rsp+0x20], xmm6
000072bd77ddf151  lea rdi, [rsp]
000072bd77ddf155  mov esi, 0x00
000072bd77ddf15a  mov rax, 0x643206AC3530
000072bd77ddf164  call rax
000072bd77ddf166  movaps xmm1, [rsp]
000072bd77ddf16a  add rsp, 0x30
000072bd77ddf16e  vmovaps xmm0, [rsp]
000072bd77ddf173  vmovaps xmm2, [rsp+0x10]
000072bd77ddf179  vmovaps xmm3, [rsp+0x20]
000072bd77ddf17f  vmovaps xmm4, [rsp+0x30]
000072bd77ddf185  vmovaps xmm5, [rsp+0x40]
000072bd77ddf18b  vmovaps xmm6, [rsp+0x50]
000072bd77ddf191  vmovaps xmm7, [rsp+0x60]
000072bd77ddf197  vmovaps xmm8, [rsp+0x70]
000072bd77ddf19d  vmovaps xmm9, [rsp+0x80]
000072bd77ddf1a6  vmovaps xmm10, [rsp+0x90]
000072bd77ddf1af  vmovaps xmm11, [rsp+0xA0]
000072bd77ddf1b8  vmovaps xmm12, [rsp+0xB0]
000072bd77ddf1c1  vmovaps xmm13, [rsp+0xC0]
000072bd77ddf1ca  vmovaps xmm14, [rsp+0xD0]
000072bd77ddf1d3  vmovaps xmm15, [rsp+0xE0]
000072bd77ddf1dc  add rsp, 0xF0
000072bd77ddf1e3  pop r11
000072bd77ddf1e5  pop r10
000072bd77ddf1e7  pop r9
000072bd77ddf1e9  pop r8
000072bd77ddf1eb  pop rsi
000072bd77ddf1ec  pop rdi
000072bd77ddf1ed  pop rdx
000072bd77ddf1ee  pop rcx
000072bd77ddf1ef  pop rax
000072bd77ddf1f0  add rsp, 0x08
000072bd77ddf1f4  jmp 0x000072BD77DDC375
000072bd77ddf1f9  sub rsp, 0x08
000072bd77ddf1fd  push rax
000072bd77ddf1fe  push rcx
000072bd77ddf1ff  push rdx
000072bd77ddf200  push rdi
000072bd77ddf201  push rsi
000072bd77ddf202  push r8
000072bd77ddf204  push r9
000072bd77ddf206  push r10
000072bd77ddf208  push r11
000072bd77ddf20a  sub rsp, 0xF0
000072bd77ddf211  vmovaps [rsp], xmm0
000072bd77ddf216  vmovaps [rsp+0x10], xmm1
000072bd77ddf21c  vmovaps [rsp+0x20], xmm2
000072bd77ddf222  vmovaps [rsp+0x30], xmm3
000072bd77ddf228  vmovaps [rsp+0x40], xmm4
000072bd77ddf22e  vmovaps [rsp+0x50], xmm5
000072bd77ddf234  vmovaps [rsp+0x60], xmm6
000072bd77ddf23a  vmovaps [rsp+0x70], xmm7
000072bd77ddf240  vmovaps [rsp+0x80], xmm8
000072bd77ddf249  vmovaps [rsp+0x90], xmm9
000072bd77ddf252  vmovaps [rsp+0xA0], xmm10
000072bd77ddf25b  vmovaps [rsp+0xB0], xmm11
000072bd77ddf264  vmovaps [rsp+0xC0], xmm12
000072bd77ddf26d  vmovaps [rsp+0xD0], xmm13
000072bd77ddf276  vmovaps [rsp+0xE0], xmm14
000072bd77ddf27f  sub rsp, 0x30
000072bd77ddf283  movaps [rsp], xmm15
000072bd77ddf288  movaps [rsp+0x10], xmm5
000072bd77ddf28d  movaps [rsp+0x20], xmm3
000072bd77ddf292  lea rdi, [rsp]
000072bd77ddf296  mov esi, 0x00
000072bd77ddf29b  mov rax, 0x643206AC3530
000072bd77ddf2a5  call rax
000072bd77ddf2a7  movaps xmm15, [rsp]
000072bd77ddf2ac  add rsp, 0x30
000072bd77ddf2b0  vmovaps xmm0, [rsp]
000072bd77ddf2b5  vmovaps xmm1, [rsp+0x10]
000072bd77ddf2bb  vmovaps xmm2, [rsp+0x20]
000072bd77ddf2c1  vmovaps xmm3, [rsp+0x30]
000072bd77ddf2c7  vmovaps xmm4, [rsp+0x40]
000072bd77ddf2cd  vmovaps xmm5, [rsp+0x50]
000072bd77ddf2d3  vmovaps xmm6, [rsp+0x60]
000072bd77ddf2d9  vmovaps xmm7, [rsp+0x70]
000072bd77ddf2df  vmovaps xmm8, [rsp+0x80]
000072bd77ddf2e8  vmovaps xmm9, [rsp+0x90]
000072bd77ddf2f1  vmovaps xmm10, [rsp+0xA0]
000072bd77ddf2fa  vmovaps xmm11, [rsp+0xB0]
000072bd77ddf303  vmovaps xmm12, [rsp+0xC0]
000072bd77ddf30c  vmovaps xmm13, [rsp+0xD0]
000072bd77ddf315  vmovaps xmm14, [rsp+0xE0]
000072bd77ddf31e  add rsp, 0xF0
000072bd77ddf325  pop r11
000072bd77ddf327  pop r10
000072bd77ddf329  pop r9
000072bd77ddf32b  pop r8
000072bd77ddf32d  pop rsi
000072bd77ddf32e  pop rdi
000072bd77ddf32f  pop rdx
000072bd77ddf330  pop rcx
000072bd77ddf331  pop rax
000072bd77ddf332  add rsp, 0x08
000072bd77ddf336  jmp 0x000072BD77DDC38F
000072bd77ddf33b  sub rsp, 0x08
000072bd77ddf33f  push rax
000072bd77ddf340  push rcx
000072bd77ddf341  push rdx
000072bd77ddf342  push rdi
000072bd77ddf343  push rsi
000072bd77ddf344  push r8
000072bd77ddf346  push r9
000072bd77ddf348  push r10
000072bd77ddf34a  push r11
000072bd77ddf34c  sub rsp, 0xF0
000072bd77ddf353  vmovaps [rsp], xmm0
000072bd77ddf358  vmovaps [rsp+0x10], xmm1
000072bd77ddf35e  vmovaps [rsp+0x20], xmm2
000072bd77ddf364  vmovaps [rsp+0x30], xmm3
000072bd77ddf36a  vmovaps [rsp+0x40], xmm4
000072bd77ddf370  vmovaps [rsp+0x50], xmm6
000072bd77ddf376  vmovaps [rsp+0x60], xmm7
000072bd77ddf37c  vmovaps [rsp+0x70], xmm8
000072bd77ddf382  vmovaps [rsp+0x80], xmm9
000072bd77ddf38b  vmovaps [rsp+0x90], xmm10
000072bd77ddf394  vmovaps [rsp+0xA0], xmm11
000072bd77ddf39d  vmovaps [rsp+0xB0], xmm12
000072bd77ddf3a6  vmovaps [rsp+0xC0], xmm13
000072bd77ddf3af  vmovaps [rsp+0xD0], xmm14
000072bd77ddf3b8  vmovaps [rsp+0xE0], xmm15
000072bd77ddf3c1  sub rsp, 0x30
000072bd77ddf3c5  movaps [rsp], xmm5
000072bd77ddf3c9  movaps [rsp+0x10], xmm8
000072bd77ddf3cf  movaps [rsp+0x20], xmm6
000072bd77ddf3d4  lea rdi, [rsp]
000072bd77ddf3d8  mov esi, 0x00
000072bd77ddf3dd  mov rax, 0x643206AC3530
000072bd77ddf3e7  call rax
000072bd77ddf3e9  movaps xmm5, [rsp]
000072bd77ddf3ed  add rsp, 0x30
000072bd77ddf3f1  vmovaps xmm0, [rsp]
000072bd77ddf3f6  vmovaps xmm1, [rsp+0x10]
000072bd77ddf3fc  vmovaps xmm2, [rsp+0x20]
000072bd77ddf402  vmovaps xmm3, [rsp+0x30]
000072bd77ddf408  vmovaps xmm4, [rsp+0x40]
000072bd77ddf40e  vmovaps xmm6, [rsp+0x50]
000072bd77ddf414  vmovaps xmm7, [rsp+0x60]
000072bd77ddf41a  vmovaps xmm8, [rsp+0x70]
000072bd77ddf420  vmovaps xmm9, [rsp+0x80]
000072bd77ddf429  vmovaps xmm10, [rsp+0x90]
000072bd77ddf432  vmovaps xmm11, [rsp+0xA0]
000072bd77ddf43b  vmovaps xmm12, [rsp+0xB0]
000072bd77ddf444  vmovaps xmm13, [rsp+0xC0]
000072bd77ddf44d  vmovaps xmm14, [rsp+0xD0]
000072bd77ddf456  vmovaps xmm15, [rsp+0xE0]
000072bd77ddf45f  add rsp, 0xF0
000072bd77ddf466  pop r11
000072bd77ddf468  pop r10
000072bd77ddf46a  pop r9
000072bd77ddf46c  pop r8
000072bd77ddf46e  pop rsi
000072bd77ddf46f  pop rdi
000072bd77ddf470  pop rdx
000072bd77ddf471  pop rcx
000072bd77ddf472  pop rax
000072bd77ddf473  add rsp, 0x08
000072bd77ddf477  jmp 0x000072BD77DDC3B3
000072bd77ddf47c  sub rsp, 0x08
000072bd77ddf480  push rax
000072bd77ddf481  push rcx
000072bd77ddf482  push rdx
000072bd77ddf483  push rdi
000072bd77ddf484  push rsi
000072bd77ddf485  push r8
000072bd77ddf487  push r9
000072bd77ddf489  push r10
000072bd77ddf48b  push r11
000072bd77ddf48d  sub rsp, 0xF0
000072bd77ddf494  vmovaps [rsp], xmm0
000072bd77ddf499  vmovaps [rsp+0x10], xmm1
000072bd77ddf49f  vmovaps [rsp+0x20], xmm2
000072bd77ddf4a5  vmovaps [rsp+0x30], xmm3
000072bd77ddf4ab  vmovaps [rsp+0x40], xmm4
000072bd77ddf4b1  vmovaps [rsp+0x50], xmm5
000072bd77ddf4b7  vmovaps [rsp+0x60], xmm7
000072bd77ddf4bd  vmovaps [rsp+0x70], xmm8
000072bd77ddf4c3  vmovaps [rsp+0x80], xmm9
000072bd77ddf4cc  vmovaps [rsp+0x90], xmm10
000072bd77ddf4d5  vmovaps [rsp+0xA0], xmm11
000072bd77ddf4de  vmovaps [rsp+0xB0], xmm12
000072bd77ddf4e7  vmovaps [rsp+0xC0], xmm13
000072bd77ddf4f0  vmovaps [rsp+0xD0], xmm14
000072bd77ddf4f9  vmovaps [rsp+0xE0], xmm15
000072bd77ddf502  sub rsp, 0x30
000072bd77ddf506  movaps [rsp], xmm6
000072bd77ddf50a  movaps [rsp+0x10], xmm10
000072bd77ddf510  movaps [rsp+0x20], xmm8
000072bd77ddf516  lea rdi, [rsp]
000072bd77ddf51a  mov esi, 0x00
000072bd77ddf51f  mov rax, 0x643206AC3530
000072bd77ddf529  call rax
000072bd77ddf52b  movaps xmm6, [rsp]
000072bd77ddf52f  add rsp, 0x30
000072bd77ddf533  vmovaps xmm0, [rsp]
000072bd77ddf538  vmovaps xmm1, [rsp+0x10]
000072bd77ddf53e  vmovaps xmm2, [rsp+0x20]
000072bd77ddf544  vmovaps xmm3, [rsp+0x30]
000072bd77ddf54a  vmovaps xmm4, [rsp+0x40]
000072bd77ddf550  vmovaps xmm5, [rsp+0x50]
000072bd77ddf556  vmovaps xmm7, [rsp+0x60]
000072bd77ddf55c  vmovaps xmm8, [rsp+0x70]
000072bd77ddf562  vmovaps xmm9, [rsp+0x80]
000072bd77ddf56b  vmovaps xmm10, [rsp+0x90]
000072bd77ddf574  vmovaps xmm11, [rsp+0xA0]
000072bd77ddf57d  vmovaps xmm12, [rsp+0xB0]
000072bd77ddf586  vmovaps xmm13, [rsp+0xC0]
000072bd77ddf58f  vmovaps xmm14, [rsp+0xD0]
000072bd77ddf598  vmovaps xmm15, [rsp+0xE0]
000072bd77ddf5a1  add rsp, 0xF0
000072bd77ddf5a8  pop r11
000072bd77ddf5aa  pop r10
000072bd77ddf5ac  pop r9
000072bd77ddf5ae  pop r8
000072bd77ddf5b0  pop rsi
000072bd77ddf5b1  pop rdi
000072bd77ddf5b2  pop rdx
000072bd77ddf5b3  pop rcx
000072bd77ddf5b4  pop rax
000072bd77ddf5b5  add rsp, 0x08
000072bd77ddf5b9  jmp 0x000072BD77DDC3D8
000072bd77ddf5be  sub rsp, 0x08
000072bd77ddf5c2  push rax
000072bd77ddf5c3  push rcx
000072bd77ddf5c4  push rdx
000072bd77ddf5c5  push rdi
000072bd77ddf5c6  push rsi
000072bd77ddf5c7  push r8
000072bd77ddf5c9  push r9
000072bd77ddf5cb  push r10
000072bd77ddf5cd  push r11
000072bd77ddf5cf  sub rsp, 0xF0
000072bd77ddf5d6  vmovaps [rsp], xmm0
000072bd77ddf5db  vmovaps [rsp+0x10], xmm1
000072bd77ddf5e1  vmovaps [rsp+0x20], xmm2
000072bd77ddf5e7  vmovaps [rsp+0x30], xmm3
000072bd77ddf5ed  vmovaps [rsp+0x40], xmm4
000072bd77ddf5f3  vmovaps [rsp+0x50], xmm5
000072bd77ddf5f9  vmovaps [rsp+0x60], xmm6
000072bd77ddf5ff  vmovaps [rsp+0x70], xmm7
000072bd77ddf605  vmovaps [rsp+0x80], xmm8
000072bd77ddf60e  vmovaps [rsp+0x90], xmm9
000072bd77ddf617  vmovaps [rsp+0xA0], xmm11
000072bd77ddf620  vmovaps [rsp+0xB0], xmm12
000072bd77ddf629  vmovaps [rsp+0xC0], xmm13
000072bd77ddf632  vmovaps [rsp+0xD0], xmm14
000072bd77ddf63b  vmovaps [rsp+0xE0], xmm15
000072bd77ddf644  sub rsp, 0x30
000072bd77ddf648  movaps [rsp], xmm10
000072bd77ddf64d  movaps [rsp+0x10], xmm8
000072bd77ddf653  movaps [rsp+0x20], xmm14
000072bd77ddf659  lea rdi, [rsp]
000072bd77ddf65d  mov esi, 0x00
000072bd77ddf662  mov rax, 0x643206AC3530
000072bd77ddf66c  call rax
000072bd77ddf66e  movaps xmm10, [rsp]
000072bd77ddf673  add rsp, 0x30
000072bd77ddf677  vmovaps xmm0, [rsp]
000072bd77ddf67c  vmovaps xmm1, [rsp+0x10]
000072bd77ddf682  vmovaps xmm2, [rsp+0x20]
000072bd77ddf688  vmovaps xmm3, [rsp+0x30]
000072bd77ddf68e  vmovaps xmm4, [rsp+0x40]
000072bd77ddf694  vmovaps xmm5, [rsp+0x50]
000072bd77ddf69a  vmovaps xmm6, [rsp+0x60]
000072bd77ddf6a0  vmovaps xmm7, [rsp+0x70]
000072bd77ddf6a6  vmovaps xmm8, [rsp+0x80]
000072bd77ddf6af  vmovaps xmm9, [rsp+0x90]
000072bd77ddf6b8  vmovaps xmm11, [rsp+0xA0]
000072bd77ddf6c1  vmovaps xmm12, [rsp+0xB0]
000072bd77ddf6ca  vmovaps xmm13, [rsp+0xC0]
000072bd77ddf6d3  vmovaps xmm14, [rsp+0xD0]
000072bd77ddf6dc  vmovaps xmm15, [rsp+0xE0]
000072bd77ddf6e5  add rsp, 0xF0
000072bd77ddf6ec  pop r11
000072bd77ddf6ee  pop r10
000072bd77ddf6f0  pop r9
000072bd77ddf6f2  pop r8
000072bd77ddf6f4  pop rsi
000072bd77ddf6f5  pop rdi
000072bd77ddf6f6  pop rdx
000072bd77ddf6f7  pop rcx
000072bd77ddf6f8  pop rax
000072bd77ddf6f9  add rsp, 0x08
000072bd77ddf6fd  jmp 0x000072BD77DDC3F8
000072bd77ddf702  sub rsp, 0x08
000072bd77ddf706  push rax
000072bd77ddf707  push rcx
000072bd77ddf708  push rdx
000072bd77ddf709  push rdi
000072bd77ddf70a  push rsi
000072bd77ddf70b  push r8
000072bd77ddf70d  push r9
000072bd77ddf70f  push r10
000072bd77ddf711  push r11
000072bd77ddf713  sub rsp, 0xF0
000072bd77ddf71a  vmovaps [rsp], xmm0
000072bd77ddf71f  vmovaps [rsp+0x10], xmm1
000072bd77ddf725  vmovaps [rsp+0x20], xmm2
000072bd77ddf72b  vmovaps [rsp+0x30], xmm3
000072bd77ddf731  vmovaps [rsp+0x40], xmm4
000072bd77ddf737  vmovaps [rsp+0x50], xmm5
000072bd77ddf73d  vmovaps [rsp+0x60], xmm6
000072bd77ddf743  vmovaps [rsp+0x70], xmm7
000072bd77ddf749  vmovaps [rsp+0x80], xmm8
000072bd77ddf752  vmovaps [rsp+0x90], xmm9
000072bd77ddf75b  vmovaps [rsp+0xA0], xmm10
000072bd77ddf764  vmovaps [rsp+0xB0], xmm11
000072bd77ddf76d  vmovaps [rsp+0xC0], xmm12
000072bd77ddf776  vmovaps [rsp+0xD0], xmm13
000072bd77ddf77f  vmovaps [rsp+0xE0], xmm15
000072bd77ddf788  sub rsp, 0x30
000072bd77ddf78c  movaps [rsp], xmm14
000072bd77ddf791  movaps [rsp+0x10], xmm8
000072bd77ddf797  movaps [rsp+0x20], xmm4
000072bd77ddf79c  lea rdi, [rsp]
000072bd77ddf7a0  mov esi, 0x00
000072bd77ddf7a5  mov rax, 0x643206AC3530
000072bd77ddf7af  call rax
000072bd77ddf7b1  movaps xmm14, [rsp]
000072bd77ddf7b6  add rsp, 0x30
000072bd77ddf7ba  vmovaps xmm0, [rsp]
000072bd77ddf7bf  vmovaps xmm1, [rsp+0x10]
000072bd77ddf7c5  vmovaps xmm2, [rsp+0x20]
000072bd77ddf7cb  vmovaps xmm3, [rsp+0x30]
000072bd77ddf7d1  vmovaps xmm4, [rsp+0x40]
000072bd77ddf7d7  vmovaps xmm5, [rsp+0x50]
000072bd77ddf7dd  vmovaps xmm6, [rsp+0x60]
000072bd77ddf7e3  vmovaps xmm7, [rsp+0x70]
000072bd77ddf7e9  vmovaps xmm8, [rsp+0x80]
000072bd77ddf7f2  vmovaps xmm9, [rsp+0x90]
000072bd77ddf7fb  vmovaps xmm10, [rsp+0xA0]
000072bd77ddf804  vmovaps xmm11, [rsp+0xB0]
000072bd77ddf80d  vmovaps xmm12, [rsp+0xC0]
000072bd77ddf816  vmovaps xmm13, [rsp+0xD0]
000072bd77ddf81f  vmovaps xmm15, [rsp+0xE0]
000072bd77ddf828  add rsp, 0xF0
000072bd77ddf82f  pop r11
000072bd77ddf831  pop r10
000072bd77ddf833  pop r9
000072bd77ddf835  pop r8
000072bd77ddf837  pop rsi
000072bd77ddf838  pop rdi
000072bd77ddf839  pop rdx
000072bd77ddf83a  pop rcx
000072bd77ddf83b  pop rax
000072bd77ddf83c  add rsp, 0x08
000072bd77ddf840  jmp 0x000072BD77DDC418
000072bd77ddf845  sub rsp, 0x08
000072bd77ddf849  push rax
000072bd77ddf84a  push rcx
000072bd77ddf84b  push rdx
000072bd77ddf84c  push rdi
000072bd77ddf84d  push rsi
000072bd77ddf84e  push r8
000072bd77ddf850  push r9
000072bd77ddf852  push r10
000072bd77ddf854  push r11
000072bd77ddf856  sub rsp, 0xF0
000072bd77ddf85d  vmovaps [rsp], xmm0
000072bd77ddf862  vmovaps [rsp+0x10], xmm1
000072bd77ddf868  vmovaps [rsp+0x20], xmm2
000072bd77ddf86e  vmovaps [rsp+0x30], xmm3
000072bd77ddf874  vmovaps [rsp+0x40], xmm5
000072bd77ddf87a  vmovaps [rsp+0x50], xmm6
000072bd77ddf880  vmovaps [rsp+0x60], xmm7
000072bd77ddf886  vmovaps [rsp+0x70], xmm8
000072bd77ddf88c  vmovaps [rsp+0x80], xmm9
000072bd77ddf895  vmovaps [rsp+0x90], xmm10
000072bd77ddf89e  vmovaps [rsp+0xA0], xmm11
000072bd77ddf8a7  vmovaps [rsp+0xB0], xmm12
000072bd77ddf8b0  vmovaps [rsp+0xC0], xmm13
000072bd77ddf8b9  vmovaps [rsp+0xD0], xmm14
000072bd77ddf8c2  vmovaps [rsp+0xE0], xmm15
000072bd77ddf8cb  sub rsp, 0x30
000072bd77ddf8cf  movaps [rsp], xmm4
000072bd77ddf8d3  movaps [rsp+0x10], xmm13
000072bd77ddf8d9  movaps [rsp+0x20], xmm8
000072bd77ddf8df  lea rdi, [rsp]
000072bd77ddf8e3  mov esi, 0x00
000072bd77ddf8e8  mov rax, 0x643206AC3530
000072bd77ddf8f2  call rax
000072bd77ddf8f4  movaps xmm4, [rsp]
000072bd77ddf8f8  add rsp, 0x30
000072bd77ddf8fc  vmovaps xmm0, [rsp]
000072bd77ddf901  vmovaps xmm1, [rsp+0x10]
000072bd77ddf907  vmovaps xmm2, [rsp+0x20]
000072bd77ddf90d  vmovaps xmm3, [rsp+0x30]
000072bd77ddf913  vmovaps xmm5, [rsp+0x40]
000072bd77ddf919  vmovaps xmm6, [rsp+0x50]
000072bd77ddf91f  vmovaps xmm7, [rsp+0x60]
000072bd77ddf925  vmovaps xmm8, [rsp+0x70]
000072bd77ddf92b  vmovaps xmm9, [rsp+0x80]
000072bd77ddf934  vmovaps xmm10, [rsp+0x90]
000072bd77ddf93d  vmovaps xmm11, [rsp+0xA0]
000072bd77ddf946  vmovaps xmm12, [rsp+0xB0]
000072bd77ddf94f  vmovaps xmm13, [rsp+0xC0]
000072bd77ddf958  vmovaps xmm14, [rsp+0xD0]
000072bd77ddf961  vmovaps xmm15, [rsp+0xE0]
000072bd77ddf96a  add rsp, 0xF0
000072bd77ddf971  pop r11
000072bd77ddf973  pop r10
000072bd77ddf975  pop r9
000072bd77ddf977  pop r8
000072bd77ddf979  pop rsi
000072bd77ddf97a  pop rdi
000072bd77ddf97b  pop rdx
000072bd77ddf97c  pop rcx
000072bd77ddf97d  pop rax
000072bd77ddf97e  add rsp, 0x08
000072bd77ddf982  jmp 0x000072BD77DDC43D
000072bd77ddf987  sub rsp, 0x08
000072bd77ddf98b  push rax
000072bd77ddf98c  push rcx
000072bd77ddf98d  push rdx
000072bd77ddf98e  push rdi
000072bd77ddf98f  push rsi
000072bd77ddf990  push r8
000072bd77ddf992  push r9
000072bd77ddf994  push r10
000072bd77ddf996  push r11
000072bd77ddf998  sub rsp, 0xF0
000072bd77ddf99f  vmovaps [rsp], xmm0
000072bd77ddf9a4  vmovaps [rsp+0x10], xmm1
000072bd77ddf9aa  vmovaps [rsp+0x20], xmm2
000072bd77ddf9b0  vmovaps [rsp+0x30], xmm3
000072bd77ddf9b6  vmovaps [rsp+0x40], xmm4
000072bd77ddf9bc  vmovaps [rsp+0x50], xmm5
000072bd77ddf9c2  vmovaps [rsp+0x60], xmm6
000072bd77ddf9c8  vmovaps [rsp+0x70], xmm7
000072bd77ddf9ce  vmovaps [rsp+0x80], xmm8
000072bd77ddf9d7  vmovaps [rsp+0x90], xmm9
000072bd77ddf9e0  vmovaps [rsp+0xA0], xmm10
000072bd77ddf9e9  vmovaps [rsp+0xB0], xmm11
000072bd77ddf9f2  vmovaps [rsp+0xC0], xmm12
000072bd77ddf9fb  vmovaps [rsp+0xD0], xmm14
000072bd77ddfa04  vmovaps [rsp+0xE0], xmm15
000072bd77ddfa0d  sub rsp, 0x30
000072bd77ddfa11  movaps [rsp], xmm13
000072bd77ddfa16  movaps [rsp+0x10], xmm15
000072bd77ddfa1c  movaps [rsp+0x20], xmm9
000072bd77ddfa22  lea rdi, [rsp]
000072bd77ddfa26  mov esi, 0x00
000072bd77ddfa2b  mov rax, 0x643206AC3530
000072bd77ddfa35  call rax
000072bd77ddfa37  movaps xmm13, [rsp]
000072bd77ddfa3c  add rsp, 0x30
000072bd77ddfa40  vmovaps xmm0, [rsp]
000072bd77ddfa45  vmovaps xmm1, [rsp+0x10]
000072bd77ddfa4b  vmovaps xmm2, [rsp+0x20]
000072bd77ddfa51  vmovaps xmm3, [rsp+0x30]
000072bd77ddfa57  vmovaps xmm4, [rsp+0x40]
000072bd77ddfa5d  vmovaps xmm5, [rsp+0x50]
000072bd77ddfa63  vmovaps xmm6, [rsp+0x60]
000072bd77ddfa69  vmovaps xmm7, [rsp+0x70]
000072bd77ddfa6f  vmovaps xmm8, [rsp+0x80]
000072bd77ddfa78  vmovaps xmm9, [rsp+0x90]
000072bd77ddfa81  vmovaps xmm10, [rsp+0xA0]
000072bd77ddfa8a  vmovaps xmm11, [rsp+0xB0]
000072bd77ddfa93  vmovaps xmm12, [rsp+0xC0]
000072bd77ddfa9c  vmovaps xmm14, [rsp+0xD0]
000072bd77ddfaa5  vmovaps xmm15, [rsp+0xE0]
000072bd77ddfaae  add rsp, 0xF0
000072bd77ddfab5  pop r11
000072bd77ddfab7  pop r10
000072bd77ddfab9  pop r9
000072bd77ddfabb  pop r8
000072bd77ddfabd  pop rsi
000072bd77ddfabe  pop rdi
000072bd77ddfabf  pop rdx
000072bd77ddfac0  pop rcx
000072bd77ddfac1  pop rax
000072bd77ddfac2  add rsp, 0x08
000072bd77ddfac6  jmp 0x000072BD77DDC458
000072bd77ddfacb  sub rsp, 0x08
000072bd77ddfacf  push rax
000072bd77ddfad0  push rcx
000072bd77ddfad1  push rdx
000072bd77ddfad2  push rdi
000072bd77ddfad3  push rsi
000072bd77ddfad4  push r8
000072bd77ddfad6  push r9
000072bd77ddfad8  push r10
000072bd77ddfada  push r11
000072bd77ddfadc  sub rsp, 0xF0
000072bd77ddfae3  vmovaps [rsp], xmm0
000072bd77ddfae8  vmovaps [rsp+0x10], xmm1
000072bd77ddfaee  vmovaps [rsp+0x20], xmm2
000072bd77ddfaf4  vmovaps [rsp+0x30], xmm3
000072bd77ddfafa  vmovaps [rsp+0x40], xmm4
000072bd77ddfb00  vmovaps [rsp+0x50], xmm5
000072bd77ddfb06  vmovaps [rsp+0x60], xmm6
000072bd77ddfb0c  vmovaps [rsp+0x70], xmm7
000072bd77ddfb12  vmovaps [rsp+0x80], xmm8
000072bd77ddfb1b  vmovaps [rsp+0x90], xmm9
000072bd77ddfb24  vmovaps [rsp+0xA0], xmm10
000072bd77ddfb2d  vmovaps [rsp+0xB0], xmm11
000072bd77ddfb36  vmovaps [rsp+0xC0], xmm12
000072bd77ddfb3f  vmovaps [rsp+0xD0], xmm13
000072bd77ddfb48  vmovaps [rsp+0xE0], xmm14
000072bd77ddfb51  sub rsp, 0x30
000072bd77ddfb55  movaps [rsp], xmm15
000072bd77ddfb5a  movaps [rsp+0x10], xmm1
000072bd77ddfb5f  movaps [rsp+0x20], xmm5
000072bd77ddfb64  lea rdi, [rsp]
000072bd77ddfb68  mov esi, 0x00
000072bd77ddfb6d  mov rax, 0x643206AC3530
000072bd77ddfb77  call rax
000072bd77ddfb79  movaps xmm15, [rsp]
000072bd77ddfb7e  add rsp, 0x30
000072bd77ddfb82  vmovaps xmm0, [rsp]
000072bd77ddfb87  vmovaps xmm1, [rsp+0x10]
000072bd77ddfb8d  vmovaps xmm2, [rsp+0x20]
000072bd77ddfb93  vmovaps xmm3, [rsp+0x30]
000072bd77ddfb99  vmovaps xmm4, [rsp+0x40]
000072bd77ddfb9f  vmovaps xmm5, [rsp+0x50]
000072bd77ddfba5  vmovaps xmm6, [rsp+0x60]
000072bd77ddfbab  vmovaps xmm7, [rsp+0x70]
000072bd77ddfbb1  vmovaps xmm8, [rsp+0x80]
000072bd77ddfbba  vmovaps xmm9, [rsp+0x90]
000072bd77ddfbc3  vmovaps xmm10, [rsp+0xA0]
000072bd77ddfbcc  vmovaps xmm11, [rsp+0xB0]
000072bd77ddfbd5  vmovaps xmm12, [rsp+0xC0]
000072bd77ddfbde  vmovaps xmm13, [rsp+0xD0]
000072bd77ddfbe7  vmovaps xmm14, [rsp+0xE0]
000072bd77ddfbf0  add rsp, 0xF0
000072bd77ddfbf7  pop r11
000072bd77ddfbf9  pop r10
000072bd77ddfbfb  pop r9
000072bd77ddfbfd  pop r8
000072bd77ddfbff  pop rsi
000072bd77ddfc00  pop rdi
000072bd77ddfc01  pop rdx
000072bd77ddfc02  pop rcx
000072bd77ddfc03  pop rax
000072bd77ddfc04  add rsp, 0x08
000072bd77ddfc08  jmp 0x000072BD77DDC473
000072bd77ddfc0d  call 0x000072BD77CB52F0
000072bd77ddfc12  jmp 0x000072BD77DDC4CE
000072bd77ddfc17  sub rsp, 0x08
000072bd77ddfc1b  push rax
000072bd77ddfc1c  push rcx
000072bd77ddfc1d  push rdx
000072bd77ddfc1e  push rdi
000072bd77ddfc1f  push rsi
000072bd77ddfc20  push r8
000072bd77ddfc22  push r9
000072bd77ddfc24  push r10
000072bd77ddfc26  push r11
000072bd77ddfc28  sub rsp, 0xF0
000072bd77ddfc2f  vmovaps [rsp], xmm0
000072bd77ddfc34  vmovaps [rsp+0x10], xmm1
000072bd77ddfc3a  vmovaps [rsp+0x20], xmm2
000072bd77ddfc40  vmovaps [rsp+0x30], xmm3
000072bd77ddfc46  vmovaps [rsp+0x40], xmm4
000072bd77ddfc4c  vmovaps [rsp+0x50], xmm5
000072bd77ddfc52  vmovaps [rsp+0x60], xmm6
000072bd77ddfc58  vmovaps [rsp+0x70], xmm7
000072bd77ddfc5e  vmovaps [rsp+0x80], xmm8
000072bd77ddfc67  vmovaps [rsp+0x90], xmm10
000072bd77ddfc70  vmovaps [rsp+0xA0], xmm11
000072bd77ddfc79  vmovaps [rsp+0xB0], xmm12
000072bd77ddfc82  vmovaps [rsp+0xC0], xmm13
000072bd77ddfc8b  vmovaps [rsp+0xD0], xmm14
000072bd77ddfc94  vmovaps [rsp+0xE0], xmm15
000072bd77ddfc9d  sub rsp, 0x30
000072bd77ddfca1  movaps [rsp], xmm9
000072bd77ddfca6  movaps [rsp+0x10], xmm8
000072bd77ddfcac  movaps [rsp+0x20], xmm11
000072bd77ddfcb2  lea rdi, [rsp]
000072bd77ddfcb6  mov esi, 0x00
000072bd77ddfcbb  mov rax, 0x643206AC3530
000072bd77ddfcc5  call rax
000072bd77ddfcc7  movaps xmm9, [rsp]
000072bd77ddfccc  add rsp, 0x30
000072bd77ddfcd0  vmovaps xmm0, [rsp]
000072bd77ddfcd5  vmovaps xmm1, [rsp+0x10]
000072bd77ddfcdb  vmovaps xmm2, [rsp+0x20]
000072bd77ddfce1  vmovaps xmm3, [rsp+0x30]
000072bd77ddfce7  vmovaps xmm4, [rsp+0x40]
000072bd77ddfced  vmovaps xmm5, [rsp+0x50]
000072bd77ddfcf3  vmovaps xmm6, [rsp+0x60]
000072bd77ddfcf9  vmovaps xmm7, [rsp+0x70]
000072bd77ddfcff  vmovaps xmm8, [rsp+0x80]
000072bd77ddfd08  vmovaps xmm10, [rsp+0x90]
000072bd77ddfd11  vmovaps xmm11, [rsp+0xA0]
000072bd77ddfd1a  vmovaps xmm12, [rsp+0xB0]
000072bd77ddfd23  vmovaps xmm13, [rsp+0xC0]
000072bd77ddfd2c  vmovaps xmm14, [rsp+0xD0]
000072bd77ddfd35  vmovaps xmm15, [rsp+0xE0]
000072bd77ddfd3e  add rsp, 0xF0
000072bd77ddfd45  pop r11
000072bd77ddfd47  pop r10
000072bd77ddfd49  pop r9
000072bd77ddfd4b  pop r8
000072bd77ddfd4d  pop rsi
000072bd77ddfd4e  pop rdi
000072bd77ddfd4f  pop rdx
000072bd77ddfd50  pop rcx
000072bd77ddfd51  pop rax
000072bd77ddfd52  add rsp, 0x08
000072bd77ddfd56  jmp 0x000072BD77DDC505
000072bd77ddfd5b  sub rsp, 0x08
000072bd77ddfd5f  push rax
000072bd77ddfd60  push rcx
000072bd77ddfd61  push rdx
000072bd77ddfd62  push rdi
000072bd77ddfd63  push rsi
000072bd77ddfd64  push r8
000072bd77ddfd66  push r9
000072bd77ddfd68  push r10
000072bd77ddfd6a  push r11
000072bd77ddfd6c  sub rsp, 0xF0
000072bd77ddfd73  vmovaps [rsp], xmm0
000072bd77ddfd78  vmovaps [rsp+0x10], xmm1
000072bd77ddfd7e  vmovaps [rsp+0x20], xmm2
000072bd77ddfd84  vmovaps [rsp+0x30], xmm3
000072bd77ddfd8a  vmovaps [rsp+0x40], xmm4
000072bd77ddfd90  vmovaps [rsp+0x50], xmm5
000072bd77ddfd96  vmovaps [rsp+0x60], xmm6
000072bd77ddfd9c  vmovaps [rsp+0x70], xmm7
000072bd77ddfda2  vmovaps [rsp+0x80], xmm8
000072bd77ddfdab  vmovaps [rsp+0x90], xmm9
000072bd77ddfdb4  vmovaps [rsp+0xA0], xmm10
000072bd77ddfdbd  vmovaps [rsp+0xB0], xmm12
000072bd77ddfdc6  vmovaps [rsp+0xC0], xmm13
000072bd77ddfdcf  vmovaps [rsp+0xD0], xmm14
000072bd77ddfdd8  vmovaps [rsp+0xE0], xmm15
000072bd77ddfde1  sub rsp, 0x30
000072bd77ddfde5  movaps [rsp], xmm11
000072bd77ddfdea  movaps [rsp+0x10], xmm10
000072bd77ddfdf0  movaps [rsp+0x20], xmm6
000072bd77ddfdf5  lea rdi, [rsp]
000072bd77ddfdf9  mov esi, 0x00
000072bd77ddfdfe  mov rax, 0x643206AC3530
000072bd77ddfe08  call rax
000072bd77ddfe0a  movaps xmm11, [rsp]
000072bd77ddfe0f  add rsp, 0x30
000072bd77ddfe13  vmovaps xmm0, [rsp]
000072bd77ddfe18  vmovaps xmm1, [rsp+0x10]
000072bd77ddfe1e  vmovaps xmm2, [rsp+0x20]
000072bd77ddfe24  vmovaps xmm3, [rsp+0x30]
000072bd77ddfe2a  vmovaps xmm4, [rsp+0x40]
000072bd77ddfe30  vmovaps xmm5, [rsp+0x50]
000072bd77ddfe36  vmovaps xmm6, [rsp+0x60]
000072bd77ddfe3c  vmovaps xmm7, [rsp+0x70]
000072bd77ddfe42  vmovaps xmm8, [rsp+0x80]
000072bd77ddfe4b  vmovaps xmm9, [rsp+0x90]
000072bd77ddfe54  vmovaps xmm10, [rsp+0xA0]
000072bd77ddfe5d  vmovaps xmm12, [rsp+0xB0]
000072bd77ddfe66  vmovaps xmm13, [rsp+0xC0]
000072bd77ddfe6f  vmovaps xmm14, [rsp+0xD0]
000072bd77ddfe78  vmovaps xmm15, [rsp+0xE0]
000072bd77ddfe81  add rsp, 0xF0
000072bd77ddfe88  pop r11
000072bd77ddfe8a  pop r10
000072bd77ddfe8c  pop r9
000072bd77ddfe8e  pop r8
000072bd77ddfe90  pop rsi
000072bd77ddfe91  pop rdi
000072bd77ddfe92  pop rdx
000072bd77ddfe93  pop rcx
000072bd77ddfe94  pop rax
000072bd77ddfe95  add rsp, 0x08
000072bd77ddfe99  jmp 0x000072BD77DDC520
000072bd77ddfe9e  sub rsp, 0x08
000072bd77ddfea2  push rax
000072bd77ddfea3  push rcx
000072bd77ddfea4  push rdx
000072bd77ddfea5  push rdi
000072bd77ddfea6  push rsi
000072bd77ddfea7  push r8
000072bd77ddfea9  push r9
000072bd77ddfeab  push r10
000072bd77ddfead  push r11
000072bd77ddfeaf  sub rsp, 0xF0
000072bd77ddfeb6  vmovaps [rsp], xmm0
000072bd77ddfebb  vmovaps [rsp+0x10], xmm1
000072bd77ddfec1  vmovaps [rsp+0x20], xmm2
000072bd77ddfec7  vmovaps [rsp+0x30], xmm3
000072bd77ddfecd  vmovaps [rsp+0x40], xmm4
000072bd77ddfed3  vmovaps [rsp+0x50], xmm5
000072bd77ddfed9  vmovaps [rsp+0x60], xmm6
000072bd77ddfedf  vmovaps [rsp+0x70], xmm7
000072bd77ddfee5  vmovaps [rsp+0x80], xmm8
000072bd77ddfeee  vmovaps [rsp+0x90], xmm9
000072bd77ddfef7  vmovaps [rsp+0xA0], xmm11
000072bd77ddff00  vmovaps [rsp+0xB0], xmm12
000072bd77ddff09  vmovaps [rsp+0xC0], xmm13
000072bd77ddff12  vmovaps [rsp+0xD0], xmm14
000072bd77ddff1b  vmovaps [rsp+0xE0], xmm15
000072bd77ddff24  sub rsp, 0x30
000072bd77ddff28  movaps [rsp], xmm10
000072bd77ddff2d  movaps [rsp+0x10], xmm14
000072bd77ddff33  movaps [rsp+0x20], xmm4
000072bd77ddff38  lea rdi, [rsp]
000072bd77ddff3c  mov esi, 0x00
000072bd77ddff41  mov rax, 0x643206AC3530
000072bd77ddff4b  call rax
000072bd77ddff4d  movaps xmm10, [rsp]
000072bd77ddff52  add rsp, 0x30
000072bd77ddff56  vmovaps xmm0, [rsp]
000072bd77ddff5b  vmovaps xmm1, [rsp+0x10]
000072bd77ddff61  vmovaps xmm2, [rsp+0x20]
000072bd77ddff67  vmovaps xmm3, [rsp+0x30]
000072bd77ddff6d  vmovaps xmm4, [rsp+0x40]
000072bd77ddff73  vmovaps xmm5, [rsp+0x50]
000072bd77ddff79  vmovaps xmm6, [rsp+0x60]
000072bd77ddff7f  vmovaps xmm7, [rsp+0x70]
000072bd77ddff85  vmovaps xmm8, [rsp+0x80]
000072bd77ddff8e  vmovaps xmm9, [rsp+0x90]
000072bd77ddff97  vmovaps xmm11, [rsp+0xA0]
000072bd77ddffa0  vmovaps xmm12, [rsp+0xB0]
000072bd77ddffa9  vmovaps xmm13, [rsp+0xC0]
000072bd77ddffb2  vmovaps xmm14, [rsp+0xD0]
000072bd77ddffbb  vmovaps xmm15, [rsp+0xE0]
000072bd77ddffc4  add rsp, 0xF0
000072bd77ddffcb  pop r11
000072bd77ddffcd  pop r10
000072bd77ddffcf  pop r9
000072bd77ddffd1  pop r8
000072bd77ddffd3  pop rsi
000072bd77ddffd4  pop rdi
000072bd77ddffd5  pop rdx
000072bd77ddffd6  pop rcx
000072bd77ddffd7  pop rax
000072bd77ddffd8  add rsp, 0x08
000072bd77ddffdc  jmp 0x000072BD77DDC53B
000072bd77ddffe1  sub rsp, 0x08
000072bd77ddffe5  push rax
000072bd77ddffe6  push rcx
000072bd77ddffe7  push rdx
000072bd77ddffe8  push rdi
000072bd77ddffe9  push rsi
000072bd77ddffea  push r8
000072bd77ddffec  push r9
000072bd77ddffee  push r10
000072bd77ddfff0  push r11
000072bd77ddfff2  sub rsp, 0xF0
000072bd77ddfff9  vmovaps [rsp], xmm0
000072bd77ddfffe  vmovaps [rsp+0x10], xmm1
000072bd77de0004  vmovaps [rsp+0x20], xmm2
000072bd77de000a  vmovaps [rsp+0x30], xmm3
000072bd77de0010  vmovaps [rsp+0x40], xmm4
000072bd77de0016  vmovaps [rsp+0x50], xmm5
000072bd77de001c  vmovaps [rsp+0x60], xmm6
000072bd77de0022  vmovaps [rsp+0x70], xmm7
000072bd77de0028  vmovaps [rsp+0x80], xmm9
000072bd77de0031  vmovaps [rsp+0x90], xmm10
000072bd77de003a  vmovaps [rsp+0xA0], xmm11
000072bd77de0043  vmovaps [rsp+0xB0], xmm12
000072bd77de004c  vmovaps [rsp+0xC0], xmm13
000072bd77de0055  vmovaps [rsp+0xD0], xmm14
000072bd77de005e  vmovaps [rsp+0xE0], xmm15
000072bd77de0067  sub rsp, 0x30
000072bd77de006b  movaps [rsp], xmm8
000072bd77de0070  movaps [rsp+0x10], xmm1
000072bd77de0075  movaps [rsp+0x20], xmm14
000072bd77de007b  lea rdi, [rsp]
000072bd77de007f  mov esi, 0x00
000072bd77de0084  mov rax, 0x643206AC3530
000072bd77de008e  call rax
000072bd77de0090  movaps xmm8, [rsp]
000072bd77de0095  add rsp, 0x30
000072bd77de0099  vmovaps xmm0, [rsp]
000072bd77de009e  vmovaps xmm1, [rsp+0x10]
000072bd77de00a4  vmovaps xmm2, [rsp+0x20]
000072bd77de00aa  vmovaps xmm3, [rsp+0x30]
000072bd77de00b0  vmovaps xmm4, [rsp+0x40]
000072bd77de00b6  vmovaps xmm5, [rsp+0x50]
000072bd77de00bc  vmovaps xmm6, [rsp+0x60]
000072bd77de00c2  vmovaps xmm7, [rsp+0x70]
000072bd77de00c8  vmovaps xmm9, [rsp+0x80]
000072bd77de00d1  vmovaps xmm10, [rsp+0x90]
000072bd77de00da  vmovaps xmm11, [rsp+0xA0]
000072bd77de00e3  vmovaps xmm12, [rsp+0xB0]
000072bd77de00ec  vmovaps xmm13, [rsp+0xC0]
000072bd77de00f5  vmovaps xmm14, [rsp+0xD0]
000072bd77de00fe  vmovaps xmm15, [rsp+0xE0]
000072bd77de0107  add rsp, 0xF0
000072bd77de010e  pop r11
000072bd77de0110  pop r10
000072bd77de0112  pop r9
000072bd77de0114  pop r8
000072bd77de0116  pop rsi
000072bd77de0117  pop rdi
000072bd77de0118  pop rdx
000072bd77de0119  pop rcx
000072bd77de011a  pop rax
000072bd77de011b  add rsp, 0x08
000072bd77de011f  jmp 0x000072BD77DDC561
000072bd77de0124  sub rsp, 0x08
000072bd77de0128  push rax
000072bd77de0129  push rcx
000072bd77de012a  push rdx
000072bd77de012b  push rdi
000072bd77de012c  push rsi
000072bd77de012d  push r8
000072bd77de012f  push r9
000072bd77de0131  push r10
000072bd77de0133  push r11
000072bd77de0135  sub rsp, 0xF0
000072bd77de013c  vmovaps [rsp], xmm0
000072bd77de0141  vmovaps [rsp+0x10], xmm1
000072bd77de0147  vmovaps [rsp+0x20], xmm2
000072bd77de014d  vmovaps [rsp+0x30], xmm3
000072bd77de0153  vmovaps [rsp+0x40], xmm4
000072bd77de0159  vmovaps [rsp+0x50], xmm5
000072bd77de015f  vmovaps [rsp+0x60], xmm7
000072bd77de0165  vmovaps [rsp+0x70], xmm8
000072bd77de016b  vmovaps [rsp+0x80], xmm9
000072bd77de0174  vmovaps [rsp+0x90], xmm10
000072bd77de017d  vmovaps [rsp+0xA0], xmm11
000072bd77de0186  vmovaps [rsp+0xB0], xmm12
000072bd77de018f  vmovaps [rsp+0xC0], xmm13
000072bd77de0198  vmovaps [rsp+0xD0], xmm14
000072bd77de01a1  vmovaps [rsp+0xE0], xmm15
000072bd77de01aa  sub rsp, 0x30
000072bd77de01ae  movaps [rsp], xmm6
000072bd77de01b2  movaps [rsp+0x10], xmm1
000072bd77de01b7  movaps [rsp+0x20], xmm14
000072bd77de01bd  lea rdi, [rsp]
000072bd77de01c1  mov esi, 0x00
000072bd77de01c6  mov rax, 0x643206AC3530
000072bd77de01d0  call rax
000072bd77de01d2  movaps xmm6, [rsp]
000072bd77de01d6  add rsp, 0x30
000072bd77de01da  vmovaps xmm0, [rsp]
000072bd77de01df  vmovaps xmm1, [rsp+0x10]
000072bd77de01e5  vmovaps xmm2, [rsp+0x20]
000072bd77de01eb  vmovaps xmm3, [rsp+0x30]
000072bd77de01f1  vmovaps xmm4, [rsp+0x40]
000072bd77de01f7  vmovaps xmm5, [rsp+0x50]
000072bd77de01fd  vmovaps xmm7, [rsp+0x60]
000072bd77de0203  vmovaps xmm8, [rsp+0x70]
000072bd77de0209  vmovaps xmm9, [rsp+0x80]
000072bd77de0212  vmovaps xmm10, [rsp+0x90]
000072bd77de021b  vmovaps xmm11, [rsp+0xA0]
000072bd77de0224  vmovaps xmm12, [rsp+0xB0]
000072bd77de022d  vmovaps xmm13, [rsp+0xC0]
000072bd77de0236  vmovaps xmm14, [rsp+0xD0]
000072bd77de023f  vmovaps xmm15, [rsp+0xE0]
000072bd77de0248  add rsp, 0xF0
000072bd77de024f  pop r11
000072bd77de0251  pop r10
000072bd77de0253  pop r9
000072bd77de0255  pop r8
000072bd77de0257  pop rsi
000072bd77de0258  pop rdi
000072bd77de0259  pop rdx
000072bd77de025a  pop rcx
000072bd77de025b  pop rax
000072bd77de025c  add rsp, 0x08
000072bd77de0260  jmp 0x000072BD77DDC58D
000072bd77de0265  sub rsp, 0x08
000072bd77de0269  push rax
000072bd77de026a  push rcx
000072bd77de026b  push rdx
000072bd77de026c  push rdi
000072bd77de026d  push rsi
000072bd77de026e  push r8
000072bd77de0270  push r9
000072bd77de0272  push r10
000072bd77de0274  push r11
000072bd77de0276  sub rsp, 0xF0
000072bd77de027d  vmovaps [rsp], xmm0
000072bd77de0282  vmovaps [rsp+0x10], xmm1
000072bd77de0288  vmovaps [rsp+0x20], xmm2
000072bd77de028e  vmovaps [rsp+0x30], xmm3
000072bd77de0294  vmovaps [rsp+0x40], xmm4
000072bd77de029a  vmovaps [rsp+0x50], xmm5
000072bd77de02a0  vmovaps [rsp+0x60], xmm6
000072bd77de02a6  vmovaps [rsp+0x70], xmm7
000072bd77de02ac  vmovaps [rsp+0x80], xmm8
000072bd77de02b5  vmovaps [rsp+0x90], xmm9
000072bd77de02be  vmovaps [rsp+0xA0], xmm10
000072bd77de02c7  vmovaps [rsp+0xB0], xmm11
000072bd77de02d0  vmovaps [rsp+0xC0], xmm12
000072bd77de02d9  vmovaps [rsp+0xD0], xmm13
000072bd77de02e2  vmovaps [rsp+0xE0], xmm15
000072bd77de02eb  sub rsp, 0x30
000072bd77de02ef  movaps [rsp], xmm14
000072bd77de02f4  movaps [rsp+0x10], xmm12
000072bd77de02fa  movaps [rsp+0x20], xmm1
000072bd77de02ff  lea rdi, [rsp]
000072bd77de0303  mov esi, 0x00
000072bd77de0308  mov rax, 0x643206AC3530
000072bd77de0312  call rax
000072bd77de0314  movaps xmm14, [rsp]
000072bd77de0319  add rsp, 0x30
000072bd77de031d  vmovaps xmm0, [rsp]
000072bd77de0322  vmovaps xmm1, [rsp+0x10]
000072bd77de0328  vmovaps xmm2, [rsp+0x20]
000072bd77de032e  vmovaps xmm3, [rsp+0x30]
000072bd77de0334  vmovaps xmm4, [rsp+0x40]
000072bd77de033a  vmovaps xmm5, [rsp+0x50]
000072bd77de0340  vmovaps xmm6, [rsp+0x60]
000072bd77de0346  vmovaps xmm7, [rsp+0x70]
000072bd77de034c  vmovaps xmm8, [rsp+0x80]
000072bd77de0355  vmovaps xmm9, [rsp+0x90]
000072bd77de035e  vmovaps xmm10, [rsp+0xA0]
000072bd77de0367  vmovaps xmm11, [rsp+0xB0]
000072bd77de0370  vmovaps xmm12, [rsp+0xC0]
000072bd77de0379  vmovaps xmm13, [rsp+0xD0]
000072bd77de0382  vmovaps xmm15, [rsp+0xE0]
000072bd77de038b  add rsp, 0xF0
000072bd77de0392  pop r11
000072bd77de0394  pop r10
000072bd77de0396  pop r9
000072bd77de0398  pop r8
000072bd77de039a  pop rsi
000072bd77de039b  pop rdi
000072bd77de039c  pop rdx
000072bd77de039d  pop rcx
000072bd77de039e  pop rax
000072bd77de039f  add rsp, 0x08
000072bd77de03a3  jmp 0x000072BD77DDC5B3
000072bd77de03a8  sub rsp, 0x08
000072bd77de03ac  push rax
000072bd77de03ad  push rcx
000072bd77de03ae  push rdx
000072bd77de03af  push rdi
000072bd77de03b0  push rsi
000072bd77de03b1  push r8
000072bd77de03b3  push r9
000072bd77de03b5  push r10
000072bd77de03b7  push r11
000072bd77de03b9  sub rsp, 0xF0
000072bd77de03c0  vmovaps [rsp], xmm0
000072bd77de03c5  vmovaps [rsp+0x10], xmm2
000072bd77de03cb  vmovaps [rsp+0x20], xmm3
000072bd77de03d1  vmovaps [rsp+0x30], xmm4
000072bd77de03d7  vmovaps [rsp+0x40], xmm5
000072bd77de03dd  vmovaps [rsp+0x50], xmm6
000072bd77de03e3  vmovaps [rsp+0x60], xmm7
000072bd77de03e9  vmovaps [rsp+0x70], xmm8
000072bd77de03ef  vmovaps [rsp+0x80], xmm9
000072bd77de03f8  vmovaps [rsp+0x90], xmm10
000072bd77de0401  vmovaps [rsp+0xA0], xmm11
000072bd77de040a  vmovaps [rsp+0xB0], xmm12
000072bd77de0413  vmovaps [rsp+0xC0], xmm13
000072bd77de041c  vmovaps [rsp+0xD0], xmm14
000072bd77de0425  vmovaps [rsp+0xE0], xmm15
000072bd77de042e  sub rsp, 0x30
000072bd77de0432  movaps [rsp], xmm1
000072bd77de0436  movaps [rsp+0x10], xmm13
000072bd77de043c  movaps [rsp+0x20], xmm9
000072bd77de0442  lea rdi, [rsp]
000072bd77de0446  mov esi, 0x00
000072bd77de044b  mov rax, 0x643206AC3530
000072bd77de0455  call rax
000072bd77de0457  movaps xmm1, [rsp]
000072bd77de045b  add rsp, 0x30
000072bd77de045f  vmovaps xmm0, [rsp]
000072bd77de0464  vmovaps xmm2, [rsp+0x10]
000072bd77de046a  vmovaps xmm3, [rsp+0x20]
000072bd77de0470  vmovaps xmm4, [rsp+0x30]
000072bd77de0476  vmovaps xmm5, [rsp+0x40]
000072bd77de047c  vmovaps xmm6, [rsp+0x50]
000072bd77de0482  vmovaps xmm7, [rsp+0x60]
000072bd77de0488  vmovaps xmm8, [rsp+0x70]
000072bd77de048e  vmovaps xmm9, [rsp+0x80]
000072bd77de0497  vmovaps xmm10, [rsp+0x90]
000072bd77de04a0  vmovaps xmm11, [rsp+0xA0]
000072bd77de04a9  vmovaps xmm12, [rsp+0xB0]
000072bd77de04b2  vmovaps xmm13, [rsp+0xC0]
000072bd77de04bb  vmovaps xmm14, [rsp+0xD0]
000072bd77de04c4  vmovaps xmm15, [rsp+0xE0]
000072bd77de04cd  add rsp, 0xF0
000072bd77de04d4  pop r11
000072bd77de04d6  pop r10
000072bd77de04d8  pop r9
000072bd77de04da  pop r8
000072bd77de04dc  pop rsi
000072bd77de04dd  pop rdi
000072bd77de04de  pop rdx
000072bd77de04df  pop rcx
000072bd77de04e0  pop rax
000072bd77de04e1  add rsp, 0x08
000072bd77de04e5  jmp 0x000072BD77DDC5CD
000072bd77de04ea  sub rsp, 0x08
000072bd77de04ee  push rax
000072bd77de04ef  push rcx
000072bd77de04f0  push rdx
000072bd77de04f1  push rdi
000072bd77de04f2  push rsi
000072bd77de04f3  push r8
000072bd77de04f5  push r9
000072bd77de04f7  push r10
000072bd77de04f9  push r11
000072bd77de04fb  sub rsp, 0xF0
000072bd77de0502  vmovaps [rsp], xmm0
000072bd77de0507  vmovaps [rsp+0x10], xmm1
000072bd77de050d  vmovaps [rsp+0x20], xmm2
000072bd77de0513  vmovaps [rsp+0x30], xmm3
000072bd77de0519  vmovaps [rsp+0x40], xmm4
000072bd77de051f  vmovaps [rsp+0x50], xmm5
000072bd77de0525  vmovaps [rsp+0x60], xmm6
000072bd77de052b  vmovaps [rsp+0x70], xmm7
000072bd77de0531  vmovaps [rsp+0x80], xmm8
000072bd77de053a  vmovaps [rsp+0x90], xmm9
000072bd77de0543  vmovaps [rsp+0xA0], xmm10
000072bd77de054c  vmovaps [rsp+0xB0], xmm11
000072bd77de0555  vmovaps [rsp+0xC0], xmm13
000072bd77de055e  vmovaps [rsp+0xD0], xmm14
000072bd77de0567  vmovaps [rsp+0xE0], xmm15
000072bd77de0570  sub rsp, 0x30
000072bd77de0574  movaps [rsp], xmm12
000072bd77de0579  movaps [rsp+0x10], xmm7
000072bd77de057e  movaps [rsp+0x20], xmm13
000072bd77de0584  lea rdi, [rsp]
000072bd77de0588  mov esi, 0x00
000072bd77de058d  mov rax, 0x643206AC3530
000072bd77de0597  call rax
000072bd77de0599  movaps xmm12, [rsp]
000072bd77de059e  add rsp, 0x30
000072bd77de05a2  vmovaps xmm0, [rsp]
000072bd77de05a7  vmovaps xmm1, [rsp+0x10]
000072bd77de05ad  vmovaps xmm2, [rsp+0x20]
000072bd77de05b3  vmovaps xmm3, [rsp+0x30]
000072bd77de05b9  vmovaps xmm4, [rsp+0x40]
000072bd77de05bf  vmovaps xmm5, [rsp+0x50]
000072bd77de05c5  vmovaps xmm6, [rsp+0x60]
000072bd77de05cb  vmovaps xmm7, [rsp+0x70]
000072bd77de05d1  vmovaps xmm8, [rsp+0x80]
000072bd77de05da  vmovaps xmm9, [rsp+0x90]
000072bd77de05e3  vmovaps xmm10, [rsp+0xA0]
000072bd77de05ec  vmovaps xmm11, [rsp+0xB0]
000072bd77de05f5  vmovaps xmm13, [rsp+0xC0]
000072bd77de05fe  vmovaps xmm14, [rsp+0xD0]
000072bd77de0607  vmovaps xmm15, [rsp+0xE0]
000072bd77de0610  add rsp, 0xF0
000072bd77de0617  pop r11
000072bd77de0619  pop r10
000072bd77de061b  pop r9
000072bd77de061d  pop r8
000072bd77de061f  pop rsi
000072bd77de0620  pop rdi
000072bd77de0621  pop rdx
000072bd77de0622  pop rcx
000072bd77de0623  pop rax
000072bd77de0624  add rsp, 0x08
000072bd77de0628  jmp 0x000072BD77DDC5F4
000072bd77de062d  sub rsp, 0x08
000072bd77de0631  push rax
000072bd77de0632  push rcx
000072bd77de0633  push rdx
000072bd77de0634  push rdi
000072bd77de0635  push rsi
000072bd77de0636  push r8
000072bd77de0638  push r9
000072bd77de063a  push r10
000072bd77de063c  push r11
000072bd77de063e  sub rsp, 0xF0
000072bd77de0645  vmovaps [rsp], xmm0
000072bd77de064a  vmovaps [rsp+0x10], xmm1
000072bd77de0650  vmovaps [rsp+0x20], xmm2
000072bd77de0656  vmovaps [rsp+0x30], xmm3
000072bd77de065c  vmovaps [rsp+0x40], xmm4
000072bd77de0662  vmovaps [rsp+0x50], xmm5
000072bd77de0668  vmovaps [rsp+0x60], xmm6
000072bd77de066e  vmovaps [rsp+0x70], xmm7
000072bd77de0674  vmovaps [rsp+0x80], xmm8
000072bd77de067d  vmovaps [rsp+0x90], xmm9
000072bd77de0686  vmovaps [rsp+0xA0], xmm10
000072bd77de068f  vmovaps [rsp+0xB0], xmm11
000072bd77de0698  vmovaps [rsp+0xC0], xmm12
000072bd77de06a1  vmovaps [rsp+0xD0], xmm14
000072bd77de06aa  vmovaps [rsp+0xE0], xmm15
000072bd77de06b3  sub rsp, 0x30
000072bd77de06b7  movaps [rsp], xmm13
000072bd77de06bc  movaps [rsp+0x10], xmm15
000072bd77de06c2  movaps [rsp+0x20], xmm8
000072bd77de06c8  lea rdi, [rsp]
000072bd77de06cc  mov esi, 0x00
000072bd77de06d1  mov rax, 0x643206AC3530
000072bd77de06db  call rax
000072bd77de06dd  movaps xmm13, [rsp]
000072bd77de06e2  add rsp, 0x30
000072bd77de06e6  vmovaps xmm0, [rsp]
000072bd77de06eb  vmovaps xmm1, [rsp+0x10]
000072bd77de06f1  vmovaps xmm2, [rsp+0x20]
000072bd77de06f7  vmovaps xmm3, [rsp+0x30]
000072bd77de06fd  vmovaps xmm4, [rsp+0x40]
000072bd77de0703  vmovaps xmm5, [rsp+0x50]
000072bd77de0709  vmovaps xmm6, [rsp+0x60]
000072bd77de070f  vmovaps xmm7, [rsp+0x70]
000072bd77de0715  vmovaps xmm8, [rsp+0x80]
000072bd77de071e  vmovaps xmm9, [rsp+0x90]
000072bd77de0727  vmovaps xmm10, [rsp+0xA0]
000072bd77de0730  vmovaps xmm11, [rsp+0xB0]
000072bd77de0739  vmovaps xmm12, [rsp+0xC0]
000072bd77de0742  vmovaps xmm14, [rsp+0xD0]
000072bd77de074b  vmovaps xmm15, [rsp+0xE0]
000072bd77de0754  add rsp, 0xF0
000072bd77de075b  pop r11
000072bd77de075d  pop r10
000072bd77de075f  pop r9
000072bd77de0761  pop r8
000072bd77de0763  pop rsi
000072bd77de0764  pop rdi
000072bd77de0765  pop rdx
000072bd77de0766  pop rcx
000072bd77de0767  pop rax
000072bd77de0768  add rsp, 0x08
000072bd77de076c  jmp 0x000072BD77DDC60F
000072bd77de0771  sub rsp, 0x08
000072bd77de0775  push rax
000072bd77de0776  push rcx
000072bd77de0777  push rdx
000072bd77de0778  push rdi
000072bd77de0779  push rsi
000072bd77de077a  push r8
000072bd77de077c  push r9
000072bd77de077e  push r10
000072bd77de0780  push r11
000072bd77de0782  sub rsp, 0xF0
000072bd77de0789  vmovaps [rsp], xmm0
000072bd77de078e  vmovaps [rsp+0x10], xmm1
000072bd77de0794  vmovaps [rsp+0x20], xmm2
000072bd77de079a  vmovaps [rsp+0x30], xmm3
000072bd77de07a0  vmovaps [rsp+0x40], xmm4
000072bd77de07a6  vmovaps [rsp+0x50], xmm5
000072bd77de07ac  vmovaps [rsp+0x60], xmm6
000072bd77de07b2  vmovaps [rsp+0x70], xmm7
000072bd77de07b8  vmovaps [rsp+0x80], xmm9
000072bd77de07c1  vmovaps [rsp+0x90], xmm10
000072bd77de07ca  vmovaps [rsp+0xA0], xmm11
000072bd77de07d3  vmovaps [rsp+0xB0], xmm12
000072bd77de07dc  vmovaps [rsp+0xC0], xmm13
000072bd77de07e5  vmovaps [rsp+0xD0], xmm14
000072bd77de07ee  vmovaps [rsp+0xE0], xmm15
000072bd77de07f7  sub rsp, 0x30
000072bd77de07fb  movaps [rsp], xmm8
000072bd77de0800  movaps [rsp+0x10], xmm15
000072bd77de0806  movaps [rsp+0x20], xmm9
000072bd77de080c  lea rdi, [rsp]
000072bd77de0810  mov esi, 0x00
000072bd77de0815  mov rax, 0x643206AC3530
000072bd77de081f  call rax
000072bd77de0821  movaps xmm8, [rsp]
000072bd77de0826  add rsp, 0x30
000072bd77de082a  vmovaps xmm0, [rsp]
000072bd77de082f  vmovaps xmm1, [rsp+0x10]
000072bd77de0835  vmovaps xmm2, [rsp+0x20]
000072bd77de083b  vmovaps xmm3, [rsp+0x30]
000072bd77de0841  vmovaps xmm4, [rsp+0x40]
000072bd77de0847  vmovaps xmm5, [rsp+0x50]
000072bd77de084d  vmovaps xmm6, [rsp+0x60]
000072bd77de0853  vmovaps xmm7, [rsp+0x70]
000072bd77de0859  vmovaps xmm9, [rsp+0x80]
000072bd77de0862  vmovaps xmm10, [rsp+0x90]
000072bd77de086b  vmovaps xmm11, [rsp+0xA0]
000072bd77de0874  vmovaps xmm12, [rsp+0xB0]
000072bd77de087d  vmovaps xmm13, [rsp+0xC0]
000072bd77de0886  vmovaps xmm14, [rsp+0xD0]
000072bd77de088f  vmovaps xmm15, [rsp+0xE0]
000072bd77de0898  add rsp, 0xF0
000072bd77de089f  pop r11
000072bd77de08a1  pop r10
000072bd77de08a3  pop r9
000072bd77de08a5  pop r8
000072bd77de08a7  pop rsi
000072bd77de08a8  pop rdi
000072bd77de08a9  pop rdx
000072bd77de08aa  pop rcx
000072bd77de08ab  pop rax
000072bd77de08ac  add rsp, 0x08
000072bd77de08b0  jmp 0x000072BD77DDC63D
000072bd77de08b5  sub rsp, 0x08
000072bd77de08b9  push rax
000072bd77de08ba  push rcx
000072bd77de08bb  push rdx
000072bd77de08bc  push rdi
000072bd77de08bd  push rsi
000072bd77de08be  push r8
000072bd77de08c0  push r9
000072bd77de08c2  push r10
000072bd77de08c4  push r11
000072bd77de08c6  sub rsp, 0xF0
000072bd77de08cd  vmovaps [rsp], xmm0
000072bd77de08d2  vmovaps [rsp+0x10], xmm1
000072bd77de08d8  vmovaps [rsp+0x20], xmm2
000072bd77de08de  vmovaps [rsp+0x30], xmm3
000072bd77de08e4  vmovaps [rsp+0x40], xmm4
000072bd77de08ea  vmovaps [rsp+0x50], xmm5
000072bd77de08f0  vmovaps [rsp+0x60], xmm6
000072bd77de08f6  vmovaps [rsp+0x70], xmm7
000072bd77de08fc  vmovaps [rsp+0x80], xmm8
000072bd77de0905  vmovaps [rsp+0x90], xmm9
000072bd77de090e  vmovaps [rsp+0xA0], xmm10
000072bd77de0917  vmovaps [rsp+0xB0], xmm11
000072bd77de0920  vmovaps [rsp+0xC0], xmm12
000072bd77de0929  vmovaps [rsp+0xD0], xmm13
000072bd77de0932  vmovaps [rsp+0xE0], xmm14
000072bd77de093b  sub rsp, 0x30
000072bd77de093f  movaps [rsp], xmm15
000072bd77de0944  movaps [rsp+0x10], xmm11
000072bd77de094a  movaps [rsp+0x20], xmm6
000072bd77de094f  lea rdi, [rsp]
000072bd77de0953  mov esi, 0x00
000072bd77de0958  mov rax, 0x643206AC3530
000072bd77de0962  call rax
000072bd77de0964  movaps xmm15, [rsp]
000072bd77de0969  add rsp, 0x30
000072bd77de096d  vmovaps xmm0, [rsp]
000072bd77de0972  vmovaps xmm1, [rsp+0x10]
000072bd77de0978  vmovaps xmm2, [rsp+0x20]
000072bd77de097e  vmovaps xmm3, [rsp+0x30]
000072bd77de0984  vmovaps xmm4, [rsp+0x40]
000072bd77de098a  vmovaps xmm5, [rsp+0x50]
000072bd77de0990  vmovaps xmm6, [rsp+0x60]
000072bd77de0996  vmovaps xmm7, [rsp+0x70]
000072bd77de099c  vmovaps xmm8, [rsp+0x80]
000072bd77de09a5  vmovaps xmm9, [rsp+0x90]
000072bd77de09ae  vmovaps xmm10, [rsp+0xA0]
000072bd77de09b7  vmovaps xmm11, [rsp+0xB0]
000072bd77de09c0  vmovaps xmm12, [rsp+0xC0]
000072bd77de09c9  vmovaps xmm13, [rsp+0xD0]
000072bd77de09d2  vmovaps xmm14, [rsp+0xE0]
000072bd77de09db  add rsp, 0xF0
000072bd77de09e2  pop r11
000072bd77de09e4  pop r10
000072bd77de09e6  pop r9
000072bd77de09e8  pop r8
000072bd77de09ea  pop rsi
000072bd77de09eb  pop rdi
000072bd77de09ec  pop rdx
000072bd77de09ed  pop rcx
000072bd77de09ee  pop rax
000072bd77de09ef  add rsp, 0x08
000072bd77de09f3  jmp 0x000072BD77DDC658
000072bd77de09f8  sub rsp, 0x08
000072bd77de09fc  push rax
000072bd77de09fd  push rcx
000072bd77de09fe  push rdx
000072bd77de09ff  push rdi
000072bd77de0a00  push rsi
000072bd77de0a01  push r8
000072bd77de0a03  push r9
000072bd77de0a05  push r10
000072bd77de0a07  push r11
000072bd77de0a09  sub rsp, 0xF0
000072bd77de0a10  vmovaps [rsp], xmm0
000072bd77de0a15  vmovaps [rsp+0x10], xmm1
000072bd77de0a1b  vmovaps [rsp+0x20], xmm2
000072bd77de0a21  vmovaps [rsp+0x30], xmm3
000072bd77de0a27  vmovaps [rsp+0x40], xmm4
000072bd77de0a2d  vmovaps [rsp+0x50], xmm5
000072bd77de0a33  vmovaps [rsp+0x60], xmm6
000072bd77de0a39  vmovaps [rsp+0x70], xmm8
000072bd77de0a3f  vmovaps [rsp+0x80], xmm9
000072bd77de0a48  vmovaps [rsp+0x90], xmm10
000072bd77de0a51  vmovaps [rsp+0xA0], xmm11
000072bd77de0a5a  vmovaps [rsp+0xB0], xmm12
000072bd77de0a63  vmovaps [rsp+0xC0], xmm13
000072bd77de0a6c  vmovaps [rsp+0xD0], xmm14
000072bd77de0a75  vmovaps [rsp+0xE0], xmm15
000072bd77de0a7e  sub rsp, 0x30
000072bd77de0a82  movaps [rsp], xmm7
000072bd77de0a86  movaps [rsp+0x10], xmm11
000072bd77de0a8c  movaps [rsp+0x20], xmm9
000072bd77de0a92  lea rdi, [rsp]
000072bd77de0a96  mov esi, 0x00
000072bd77de0a9b  mov rax, 0x643206AC3530
000072bd77de0aa5  call rax
000072bd77de0aa7  movaps xmm7, [rsp]
000072bd77de0aab  add rsp, 0x30
000072bd77de0aaf  vmovaps xmm0, [rsp]
000072bd77de0ab4  vmovaps xmm1, [rsp+0x10]
000072bd77de0aba  vmovaps xmm2, [rsp+0x20]
000072bd77de0ac0  vmovaps xmm3, [rsp+0x30]
000072bd77de0ac6  vmovaps xmm4, [rsp+0x40]
000072bd77de0acc  vmovaps xmm5, [rsp+0x50]
000072bd77de0ad2  vmovaps xmm6, [rsp+0x60]
000072bd77de0ad8  vmovaps xmm8, [rsp+0x70]
000072bd77de0ade  vmovaps xmm9, [rsp+0x80]
000072bd77de0ae7  vmovaps xmm10, [rsp+0x90]
000072bd77de0af0  vmovaps xmm11, [rsp+0xA0]
000072bd77de0af9  vmovaps xmm12, [rsp+0xB0]
000072bd77de0b02  vmovaps xmm13, [rsp+0xC0]
000072bd77de0b0b  vmovaps xmm14, [rsp+0xD0]
000072bd77de0b14  vmovaps xmm15, [rsp+0xE0]
000072bd77de0b1d  add rsp, 0xF0
000072bd77de0b24  pop r11
000072bd77de0b26  pop r10
000072bd77de0b28  pop r9
000072bd77de0b2a  pop r8
000072bd77de0b2c  pop rsi
000072bd77de0b2d  pop rdi
000072bd77de0b2e  pop rdx
000072bd77de0b2f  pop rcx
000072bd77de0b30  pop rax
000072bd77de0b31  add rsp, 0x08
000072bd77de0b35  jmp 0x000072BD77DDC685
000072bd77de0b3a  sub rsp, 0x08
000072bd77de0b3e  push rax
000072bd77de0b3f  push rcx
000072bd77de0b40  push rdx
000072bd77de0b41  push rdi
000072bd77de0b42  push rsi
000072bd77de0b43  push r8
000072bd77de0b45  push r9
000072bd77de0b47  push r10
000072bd77de0b49  push r11
000072bd77de0b4b  sub rsp, 0xF0
000072bd77de0b52  vmovaps [rsp], xmm0
000072bd77de0b57  vmovaps [rsp+0x10], xmm1
000072bd77de0b5d  vmovaps [rsp+0x20], xmm2
000072bd77de0b63  vmovaps [rsp+0x30], xmm3
000072bd77de0b69  vmovaps [rsp+0x40], xmm4
000072bd77de0b6f  vmovaps [rsp+0x50], xmm5
000072bd77de0b75  vmovaps [rsp+0x60], xmm6
000072bd77de0b7b  vmovaps [rsp+0x70], xmm7
000072bd77de0b81  vmovaps [rsp+0x80], xmm8
000072bd77de0b8a  vmovaps [rsp+0x90], xmm9
000072bd77de0b93  vmovaps [rsp+0xA0], xmm10
000072bd77de0b9c  vmovaps [rsp+0xB0], xmm12
000072bd77de0ba5  vmovaps [rsp+0xC0], xmm13
000072bd77de0bae  vmovaps [rsp+0xD0], xmm14
000072bd77de0bb7  vmovaps [rsp+0xE0], xmm15
000072bd77de0bc0  sub rsp, 0x30
000072bd77de0bc4  movaps [rsp], xmm11
000072bd77de0bc9  movaps [rsp+0x10], xmm10
000072bd77de0bcf  movaps [rsp+0x20], xmm14
000072bd77de0bd5  lea rdi, [rsp]
000072bd77de0bd9  mov esi, 0x00
000072bd77de0bde  mov rax, 0x643206AC3530
000072bd77de0be8  call rax
000072bd77de0bea  movaps xmm11, [rsp]
000072bd77de0bef  add rsp, 0x30
000072bd77de0bf3  vmovaps xmm0, [rsp]
000072bd77de0bf8  vmovaps xmm1, [rsp+0x10]
000072bd77de0bfe  vmovaps xmm2, [rsp+0x20]
000072bd77de0c04  vmovaps xmm3, [rsp+0x30]
000072bd77de0c0a  vmovaps xmm4, [rsp+0x40]
000072bd77de0c10  vmovaps xmm5, [rsp+0x50]
000072bd77de0c16  vmovaps xmm6, [rsp+0x60]
000072bd77de0c1c  vmovaps xmm7, [rsp+0x70]
000072bd77de0c22  vmovaps xmm8, [rsp+0x80]
000072bd77de0c2b  vmovaps xmm9, [rsp+0x90]
000072bd77de0c34  vmovaps xmm10, [rsp+0xA0]
000072bd77de0c3d  vmovaps xmm12, [rsp+0xB0]
000072bd77de0c46  vmovaps xmm13, [rsp+0xC0]
000072bd77de0c4f  vmovaps xmm14, [rsp+0xD0]
000072bd77de0c58  vmovaps xmm15, [rsp+0xE0]
000072bd77de0c61  add rsp, 0xF0
000072bd77de0c68  pop r11
000072bd77de0c6a  pop r10
000072bd77de0c6c  pop r9
000072bd77de0c6e  pop r8
000072bd77de0c70  pop rsi
000072bd77de0c71  pop rdi
000072bd77de0c72  pop rdx
000072bd77de0c73  pop rcx
000072bd77de0c74  pop rax
000072bd77de0c75  add rsp, 0x08
000072bd77de0c79  jmp 0x000072BD77DDC6A0
000072bd77de0c7e  call 0x000072BD77CC33A0
000072bd77de0c83  jmp 0x000072BD77DDC6AA
000072bd77de0c88  sub rsp, 0x08
000072bd77de0c8c  push rax
000072bd77de0c8d  push rcx
000072bd77de0c8e  push rdx
000072bd77de0c8f  push rdi
000072bd77de0c90  push rsi
000072bd77de0c91  push r8
000072bd77de0c93  push r9
000072bd77de0c95  push r10
000072bd77de0c97  push r11
000072bd77de0c99  sub rsp, 0xF0
000072bd77de0ca0  vmovaps [rsp], xmm0
000072bd77de0ca5  vmovaps [rsp+0x10], xmm1
000072bd77de0cab  vmovaps [rsp+0x20], xmm2
000072bd77de0cb1  vmovaps [rsp+0x30], xmm3
000072bd77de0cb7  vmovaps [rsp+0x40], xmm4
000072bd77de0cbd  vmovaps [rsp+0x50], xmm5
000072bd77de0cc3  vmovaps [rsp+0x60], xmm6
000072bd77de0cc9  vmovaps [rsp+0x70], xmm7
000072bd77de0ccf  vmovaps [rsp+0x80], xmm8
000072bd77de0cd8  vmovaps [rsp+0x90], xmm9
000072bd77de0ce1  vmovaps [rsp+0xA0], xmm11
000072bd77de0cea  vmovaps [rsp+0xB0], xmm12
000072bd77de0cf3  vmovaps [rsp+0xC0], xmm13
000072bd77de0cfc  vmovaps [rsp+0xD0], xmm14
000072bd77de0d05  vmovaps [rsp+0xE0], xmm15
000072bd77de0d0e  sub rsp, 0x30
000072bd77de0d12  movaps [rsp], xmm10
000072bd77de0d17  movaps [rsp+0x10], xmm1
000072bd77de0d1c  movaps [rsp+0x20], xmm12
000072bd77de0d22  lea rdi, [rsp]
000072bd77de0d26  mov esi, 0x00
000072bd77de0d2b  mov rax, 0x643206AC3530
000072bd77de0d35  call rax
000072bd77de0d37  movaps xmm10, [rsp]
000072bd77de0d3c  add rsp, 0x30
000072bd77de0d40  vmovaps xmm0, [rsp]
000072bd77de0d45  vmovaps xmm1, [rsp+0x10]
000072bd77de0d4b  vmovaps xmm2, [rsp+0x20]
000072bd77de0d51  vmovaps xmm3, [rsp+0x30]
000072bd77de0d57  vmovaps xmm4, [rsp+0x40]
000072bd77de0d5d  vmovaps xmm5, [rsp+0x50]
000072bd77de0d63  vmovaps xmm6, [rsp+0x60]
000072bd77de0d69  vmovaps xmm7, [rsp+0x70]
000072bd77de0d6f  vmovaps xmm8, [rsp+0x80]
000072bd77de0d78  vmovaps xmm9, [rsp+0x90]
000072bd77de0d81  vmovaps xmm11, [rsp+0xA0]
000072bd77de0d8a  vmovaps xmm12, [rsp+0xB0]
000072bd77de0d93  vmovaps xmm13, [rsp+0xC0]
000072bd77de0d9c  vmovaps xmm14, [rsp+0xD0]
000072bd77de0da5  vmovaps xmm15, [rsp+0xE0]
000072bd77de0dae  add rsp, 0xF0
000072bd77de0db5  pop r11
000072bd77de0db7  pop r10
000072bd77de0db9  pop r9
000072bd77de0dbb  pop r8
000072bd77de0dbd  pop rsi
000072bd77de0dbe  pop rdi
000072bd77de0dbf  pop rdx
000072bd77de0dc0  pop rcx
000072bd77de0dc1  pop rax
000072bd77de0dc2  add rsp, 0x08
000072bd77de0dc6  jmp 0x000072BD77DDC6CD
000072bd77de0dcb  sub rsp, 0x08
000072bd77de0dcf  push rax
000072bd77de0dd0  push rcx
000072bd77de0dd1  push rdx
000072bd77de0dd2  push rdi
000072bd77de0dd3  push rsi
000072bd77de0dd4  push r8
000072bd77de0dd6  push r9
000072bd77de0dd8  push r10
000072bd77de0dda  push r11
000072bd77de0ddc  sub rsp, 0xF0
000072bd77de0de3  vmovaps [rsp], xmm0
000072bd77de0de8  vmovaps [rsp+0x10], xmm1
000072bd77de0dee  vmovaps [rsp+0x20], xmm2
000072bd77de0df4  vmovaps [rsp+0x30], xmm3
000072bd77de0dfa  vmovaps [rsp+0x40], xmm4
000072bd77de0e00  vmovaps [rsp+0x50], xmm5
000072bd77de0e06  vmovaps [rsp+0x60], xmm6
000072bd77de0e0c  vmovaps [rsp+0x70], xmm7
000072bd77de0e12  vmovaps [rsp+0x80], xmm8
000072bd77de0e1b  vmovaps [rsp+0x90], xmm9
000072bd77de0e24  vmovaps [rsp+0xA0], xmm10
000072bd77de0e2d  vmovaps [rsp+0xB0], xmm11
000072bd77de0e36  vmovaps [rsp+0xC0], xmm13
000072bd77de0e3f  vmovaps [rsp+0xD0], xmm14
000072bd77de0e48  vmovaps [rsp+0xE0], xmm15
000072bd77de0e51  sub rsp, 0x30
000072bd77de0e55  movaps [rsp], xmm12
000072bd77de0e5a  movaps [rsp+0x10], xmm14
000072bd77de0e60  movaps [rsp+0x20], xmm1
000072bd77de0e65  lea rdi, [rsp]
000072bd77de0e69  mov esi, 0x00
000072bd77de0e6e  mov rax, 0x643206AC3530
000072bd77de0e78  call rax
000072bd77de0e7a  movaps xmm12, [rsp]
000072bd77de0e7f  add rsp, 0x30
000072bd77de0e83  vmovaps xmm0, [rsp]
000072bd77de0e88  vmovaps xmm1, [rsp+0x10]
000072bd77de0e8e  vmovaps xmm2, [rsp+0x20]
000072bd77de0e94  vmovaps xmm3, [rsp+0x30]
000072bd77de0e9a  vmovaps xmm4, [rsp+0x40]
000072bd77de0ea0  vmovaps xmm5, [rsp+0x50]
000072bd77de0ea6  vmovaps xmm6, [rsp+0x60]
000072bd77de0eac  vmovaps xmm7, [rsp+0x70]
000072bd77de0eb2  vmovaps xmm8, [rsp+0x80]
000072bd77de0ebb  vmovaps xmm9, [rsp+0x90]
000072bd77de0ec4  vmovaps xmm10, [rsp+0xA0]
000072bd77de0ecd  vmovaps xmm11, [rsp+0xB0]
000072bd77de0ed6  vmovaps xmm13, [rsp+0xC0]
000072bd77de0edf  vmovaps xmm14, [rsp+0xD0]
000072bd77de0ee8  vmovaps xmm15, [rsp+0xE0]
000072bd77de0ef1  add rsp, 0xF0
000072bd77de0ef8  pop r11
000072bd77de0efa  pop r10
000072bd77de0efc  pop r9
000072bd77de0efe  pop r8
000072bd77de0f00  pop rsi
000072bd77de0f01  pop rdi
000072bd77de0f02  pop rdx
000072bd77de0f03  pop rcx
000072bd77de0f04  pop rax
000072bd77de0f05  add rsp, 0x08
000072bd77de0f09  jmp 0x000072BD77DDC6FC
000072bd77de0f0e  sub rsp, 0x08
000072bd77de0f12  push rax
000072bd77de0f13  push rcx
000072bd77de0f14  push rdx
000072bd77de0f15  push rdi
000072bd77de0f16  push rsi
000072bd77de0f17  push r8
000072bd77de0f19  push r9
000072bd77de0f1b  push r10
000072bd77de0f1d  push r11
000072bd77de0f1f  sub rsp, 0xF0
000072bd77de0f26  vmovaps [rsp], xmm0
000072bd77de0f2b  vmovaps [rsp+0x10], xmm1
000072bd77de0f31  vmovaps [rsp+0x20], xmm2
000072bd77de0f37  vmovaps [rsp+0x30], xmm3
000072bd77de0f3d  vmovaps [rsp+0x40], xmm4
000072bd77de0f43  vmovaps [rsp+0x50], xmm5
000072bd77de0f49  vmovaps [rsp+0x60], xmm6
000072bd77de0f4f  vmovaps [rsp+0x70], xmm7
000072bd77de0f55  vmovaps [rsp+0x80], xmm8
000072bd77de0f5e  vmovaps [rsp+0x90], xmm9
000072bd77de0f67  vmovaps [rsp+0xA0], xmm10
000072bd77de0f70  vmovaps [rsp+0xB0], xmm11
000072bd77de0f79  vmovaps [rsp+0xC0], xmm12
000072bd77de0f82  vmovaps [rsp+0xD0], xmm13
000072bd77de0f8b  vmovaps [rsp+0xE0], xmm15
000072bd77de0f94  sub rsp, 0x30
000072bd77de0f98  movaps [rsp], xmm14
000072bd77de0f9d  movaps [rsp+0x10], xmm9
000072bd77de0fa3  movaps [rsp+0x20], xmm1
000072bd77de0fa8  lea rdi, [rsp]
000072bd77de0fac  mov esi, 0x00
000072bd77de0fb1  mov rax, 0x643206AC3530
000072bd77de0fbb  call rax
000072bd77de0fbd  movaps xmm14, [rsp]
000072bd77de0fc2  add rsp, 0x30
000072bd77de0fc6  vmovaps xmm0, [rsp]
000072bd77de0fcb  vmovaps xmm1, [rsp+0x10]
000072bd77de0fd1  vmovaps xmm2, [rsp+0x20]
000072bd77de0fd7  vmovaps xmm3, [rsp+0x30]
000072bd77de0fdd  vmovaps xmm4, [rsp+0x40]
000072bd77de0fe3  vmovaps xmm5, [rsp+0x50]
000072bd77de0fe9  vmovaps xmm6, [rsp+0x60]
000072bd77de0fef  vmovaps xmm7, [rsp+0x70]
000072bd77de0ff5  vmovaps xmm8, [rsp+0x80]
000072bd77de0ffe  vmovaps xmm9, [rsp+0x90]
000072bd77de1007  vmovaps xmm10, [rsp+0xA0]
000072bd77de1010  vmovaps xmm11, [rsp+0xB0]
000072bd77de1019  vmovaps xmm12, [rsp+0xC0]
000072bd77de1022  vmovaps xmm13, [rsp+0xD0]
000072bd77de102b  vmovaps xmm15, [rsp+0xE0]
000072bd77de1034  add rsp, 0xF0
000072bd77de103b  pop r11
000072bd77de103d  pop r10
000072bd77de103f  pop r9
000072bd77de1041  pop r8
000072bd77de1043  pop rsi
000072bd77de1044  pop rdi
000072bd77de1045  pop rdx
000072bd77de1046  pop rcx
000072bd77de1047  pop rax
000072bd77de1048  add rsp, 0x08
000072bd77de104c  jmp 0x000072BD77DDC72B
000072bd77de1051  sub rsp, 0x08
000072bd77de1055  push rax
000072bd77de1056  push rcx
000072bd77de1057  push rdx
000072bd77de1058  push rdi
000072bd77de1059  push rsi
000072bd77de105a  push r8
000072bd77de105c  push r9
000072bd77de105e  push r10
000072bd77de1060  push r11
000072bd77de1062  sub rsp, 0xF0
000072bd77de1069  vmovaps [rsp], xmm0
000072bd77de106e  vmovaps [rsp+0x10], xmm2
000072bd77de1074  vmovaps [rsp+0x20], xmm3
000072bd77de107a  vmovaps [rsp+0x30], xmm4
000072bd77de1080  vmovaps [rsp+0x40], xmm5
000072bd77de1086  vmovaps [rsp+0x50], xmm6
000072bd77de108c  vmovaps [rsp+0x60], xmm7
000072bd77de1092  vmovaps [rsp+0x70], xmm8
000072bd77de1098  vmovaps [rsp+0x80], xmm9
000072bd77de10a1  vmovaps [rsp+0x90], xmm10
000072bd77de10aa  vmovaps [rsp+0xA0], xmm11
000072bd77de10b3  vmovaps [rsp+0xB0], xmm12
000072bd77de10bc  vmovaps [rsp+0xC0], xmm13
000072bd77de10c5  vmovaps [rsp+0xD0], xmm14
000072bd77de10ce  vmovaps [rsp+0xE0], xmm15
000072bd77de10d7  sub rsp, 0x30
000072bd77de10db  movaps [rsp], xmm1
000072bd77de10df  movaps [rsp+0x10], xmm13
000072bd77de10e5  movaps [rsp+0x20], xmm8
000072bd77de10eb  lea rdi, [rsp]
000072bd77de10ef  mov esi, 0x00
000072bd77de10f4  mov rax, 0x643206AC3530
000072bd77de10fe  call rax
000072bd77de1100  movaps xmm1, [rsp]
000072bd77de1104  add rsp, 0x30
000072bd77de1108  vmovaps xmm0, [rsp]
000072bd77de110d  vmovaps xmm2, [rsp+0x10]
000072bd77de1113  vmovaps xmm3, [rsp+0x20]
000072bd77de1119  vmovaps xmm4, [rsp+0x30]
000072bd77de111f  vmovaps xmm5, [rsp+0x40]
000072bd77de1125  vmovaps xmm6, [rsp+0x50]
000072bd77de112b  vmovaps xmm7, [rsp+0x60]
000072bd77de1131  vmovaps xmm8, [rsp+0x70]
000072bd77de1137  vmovaps xmm9, [rsp+0x80]
000072bd77de1140  vmovaps xmm10, [rsp+0x90]
000072bd77de1149  vmovaps xmm11, [rsp+0xA0]
000072bd77de1152  vmovaps xmm12, [rsp+0xB0]
000072bd77de115b  vmovaps xmm13, [rsp+0xC0]
000072bd77de1164  vmovaps xmm14, [rsp+0xD0]
000072bd77de116d  vmovaps xmm15, [rsp+0xE0]
000072bd77de1176  add rsp, 0xF0
000072bd77de117d  pop r11
000072bd77de117f  pop r10
000072bd77de1181  pop r9
000072bd77de1183  pop r8
000072bd77de1185  pop rsi
000072bd77de1186  pop rdi
000072bd77de1187  pop rdx
000072bd77de1188  pop rcx
000072bd77de1189  pop rax
000072bd77de118a  add rsp, 0x08
000072bd77de118e  jmp 0x000072BD77DDC74D
000072bd77de1193  call 0x000072BD77C0C260
000072bd77de1198  jmp 0x000072BD77DDC75B
000072bd77de119d  call 0x000072BD77CBD750
000072bd77de11a2  jmp 0x000072BD77DDC765
000072bd77de11a7  sub rsp, 0x08
000072bd77de11ab  push rax
000072bd77de11ac  push rcx
000072bd77de11ad  push rdx
000072bd77de11ae  push rdi
000072bd77de11af  push rsi
000072bd77de11b0  push r8
000072bd77de11b2  push r9
000072bd77de11b4  push r10
000072bd77de11b6  push r11
000072bd77de11b8  sub rsp, 0xF0
000072bd77de11bf  vmovaps [rsp], xmm0
000072bd77de11c4  vmovaps [rsp+0x10], xmm1
000072bd77de11ca  vmovaps [rsp+0x20], xmm2
000072bd77de11d0  vmovaps [rsp+0x30], xmm3
000072bd77de11d6  vmovaps [rsp+0x40], xmm4
000072bd77de11dc  vmovaps [rsp+0x50], xmm5
000072bd77de11e2  vmovaps [rsp+0x60], xmm6
000072bd77de11e8  vmovaps [rsp+0x70], xmm7
000072bd77de11ee  vmovaps [rsp+0x80], xmm9
000072bd77de11f7  vmovaps [rsp+0x90], xmm10
000072bd77de1200  vmovaps [rsp+0xA0], xmm11
000072bd77de1209  vmovaps [rsp+0xB0], xmm12
000072bd77de1212  vmovaps [rsp+0xC0], xmm13
000072bd77de121b  vmovaps [rsp+0xD0], xmm14
000072bd77de1224  vmovaps [rsp+0xE0], xmm15
000072bd77de122d  sub rsp, 0x30
000072bd77de1231  movaps [rsp], xmm8
000072bd77de1236  movaps [rsp+0x10], xmm15
000072bd77de123c  movaps [rsp+0x20], xmm7
000072bd77de1241  lea rdi, [rsp]
000072bd77de1245  mov esi, 0x00
000072bd77de124a  mov rax, 0x643206AC3530
000072bd77de1254  call rax
000072bd77de1256  movaps xmm8, [rsp]
000072bd77de125b  add rsp, 0x30
000072bd77de125f  vmovaps xmm0, [rsp]
000072bd77de1264  vmovaps xmm1, [rsp+0x10]
000072bd77de126a  vmovaps xmm2, [rsp+0x20]
000072bd77de1270  vmovaps xmm3, [rsp+0x30]
000072bd77de1276  vmovaps xmm4, [rsp+0x40]
000072bd77de127c  vmovaps xmm5, [rsp+0x50]
000072bd77de1282  vmovaps xmm6, [rsp+0x60]
000072bd77de1288  vmovaps xmm7, [rsp+0x70]
000072bd77de128e  vmovaps xmm9, [rsp+0x80]
000072bd77de1297  vmovaps xmm10, [rsp+0x90]
000072bd77de12a0  vmovaps xmm11, [rsp+0xA0]
000072bd77de12a9  vmovaps xmm12, [rsp+0xB0]
000072bd77de12b2  vmovaps xmm13, [rsp+0xC0]
000072bd77de12bb  vmovaps xmm14, [rsp+0xD0]
000072bd77de12c4  vmovaps xmm15, [rsp+0xE0]
000072bd77de12cd  add rsp, 0xF0
000072bd77de12d4  pop r11
000072bd77de12d6  pop r10
000072bd77de12d8  pop r9
000072bd77de12da  pop r8
000072bd77de12dc  pop rsi
000072bd77de12dd  pop rdi
000072bd77de12de  pop rdx
000072bd77de12df  pop rcx
000072bd77de12e0  pop rax
000072bd77de12e1  add rsp, 0x08
000072bd77de12e5  jmp 0x000072BD77DDC787
000072bd77de12ea  sub rsp, 0x08
000072bd77de12ee  push rax
000072bd77de12ef  push rcx
000072bd77de12f0  push rdx
000072bd77de12f1  push rdi
000072bd77de12f2  push rsi
000072bd77de12f3  push r8
000072bd77de12f5  push r9
000072bd77de12f7  push r10
000072bd77de12f9  push r11
000072bd77de12fb  sub rsp, 0xF0
000072bd77de1302  vmovaps [rsp], xmm0
000072bd77de1307  vmovaps [rsp+0x10], xmm1
000072bd77de130d  vmovaps [rsp+0x20], xmm2
000072bd77de1313  vmovaps [rsp+0x30], xmm3
000072bd77de1319  vmovaps [rsp+0x40], xmm4
000072bd77de131f  vmovaps [rsp+0x50], xmm5
000072bd77de1325  vmovaps [rsp+0x60], xmm6
000072bd77de132b  vmovaps [rsp+0x70], xmm8
000072bd77de1331  vmovaps [rsp+0x80], xmm9
000072bd77de133a  vmovaps [rsp+0x90], xmm10
000072bd77de1343  vmovaps [rsp+0xA0], xmm11
000072bd77de134c  vmovaps [rsp+0xB0], xmm12
000072bd77de1355  vmovaps [rsp+0xC0], xmm13
000072bd77de135e  vmovaps [rsp+0xD0], xmm14
000072bd77de1367  vmovaps [rsp+0xE0], xmm15
000072bd77de1370  sub rsp, 0x30
000072bd77de1374  movaps [rsp], xmm7
000072bd77de1378  movaps [rsp+0x10], xmm9
000072bd77de137e  movaps [rsp+0x20], xmm15
000072bd77de1384  lea rdi, [rsp]
000072bd77de1388  mov esi, 0x00
000072bd77de138d  mov rax, 0x643206AC3530
000072bd77de1397  call rax
000072bd77de1399  movaps xmm7, [rsp]
000072bd77de139d  add rsp, 0x30
000072bd77de13a1  vmovaps xmm0, [rsp]
000072bd77de13a6  vmovaps xmm1, [rsp+0x10]
000072bd77de13ac  vmovaps xmm2, [rsp+0x20]
000072bd77de13b2  vmovaps xmm3, [rsp+0x30]
000072bd77de13b8  vmovaps xmm4, [rsp+0x40]
000072bd77de13be  vmovaps xmm5, [rsp+0x50]
000072bd77de13c4  vmovaps xmm6, [rsp+0x60]
000072bd77de13ca  vmovaps xmm8, [rsp+0x70]
000072bd77de13d0  vmovaps xmm9, [rsp+0x80]
000072bd77de13d9  vmovaps xmm10, [rsp+0x90]
000072bd77de13e2  vmovaps xmm11, [rsp+0xA0]
000072bd77de13eb  vmovaps xmm12, [rsp+0xB0]
000072bd77de13f4  vmovaps xmm13, [rsp+0xC0]
000072bd77de13fd  vmovaps xmm14, [rsp+0xD0]
000072bd77de1406  vmovaps xmm15, [rsp+0xE0]
000072bd77de140f  add rsp, 0xF0
000072bd77de1416  pop r11
000072bd77de1418  pop r10
000072bd77de141a  pop r9
000072bd77de141c  pop r8
000072bd77de141e  pop rsi
000072bd77de141f  pop rdi
000072bd77de1420  pop rdx
000072bd77de1421  pop rcx
000072bd77de1422  pop rax
000072bd77de1423  add rsp, 0x08
000072bd77de1427  jmp 0x000072BD77DDC7B4
000072bd77de142c  sub rsp, 0x08
000072bd77de1430  push rax
000072bd77de1431  push rcx
000072bd77de1432  push rdx
000072bd77de1433  push rdi
000072bd77de1434  push rsi
000072bd77de1435  push r8
000072bd77de1437  push r9
000072bd77de1439  push r10
000072bd77de143b  push r11
000072bd77de143d  sub rsp, 0xF0
000072bd77de1444  vmovaps [rsp], xmm0
000072bd77de1449  vmovaps [rsp+0x10], xmm1
000072bd77de144f  vmovaps [rsp+0x20], xmm2
000072bd77de1455  vmovaps [rsp+0x30], xmm3
000072bd77de145b  vmovaps [rsp+0x40], xmm4
000072bd77de1461  vmovaps [rsp+0x50], xmm5
000072bd77de1467  vmovaps [rsp+0x60], xmm6
000072bd77de146d  vmovaps [rsp+0x70], xmm7
000072bd77de1473  vmovaps [rsp+0x80], xmm8
000072bd77de147c  vmovaps [rsp+0x90], xmm10
000072bd77de1485  vmovaps [rsp+0xA0], xmm11
000072bd77de148e  vmovaps [rsp+0xB0], xmm12
000072bd77de1497  vmovaps [rsp+0xC0], xmm13
000072bd77de14a0  vmovaps [rsp+0xD0], xmm14
000072bd77de14a9  vmovaps [rsp+0xE0], xmm15
000072bd77de14b2  sub rsp, 0x30
000072bd77de14b6  movaps [rsp], xmm9
000072bd77de14bb  movaps [rsp+0x10], xmm13
000072bd77de14c1  movaps [rsp+0x20], xmm15
000072bd77de14c7  lea rdi, [rsp]
000072bd77de14cb  mov esi, 0x00
000072bd77de14d0  mov rax, 0x643206AC3530
000072bd77de14da  call rax
000072bd77de14dc  movaps xmm9, [rsp]
000072bd77de14e1  add rsp, 0x30
000072bd77de14e5  vmovaps xmm0, [rsp]
000072bd77de14ea  vmovaps xmm1, [rsp+0x10]
000072bd77de14f0  vmovaps xmm2, [rsp+0x20]
000072bd77de14f6  vmovaps xmm3, [rsp+0x30]
000072bd77de14fc  vmovaps xmm4, [rsp+0x40]
000072bd77de1502  vmovaps xmm5, [rsp+0x50]
000072bd77de1508  vmovaps xmm6, [rsp+0x60]
000072bd77de150e  vmovaps xmm7, [rsp+0x70]
000072bd77de1514  vmovaps xmm8, [rsp+0x80]
000072bd77de151d  vmovaps xmm10, [rsp+0x90]
000072bd77de1526  vmovaps xmm11, [rsp+0xA0]
000072bd77de152f  vmovaps xmm12, [rsp+0xB0]
000072bd77de1538  vmovaps xmm13, [rsp+0xC0]
000072bd77de1541  vmovaps xmm14, [rsp+0xD0]
000072bd77de154a  vmovaps xmm15, [rsp+0xE0]
000072bd77de1553  add rsp, 0xF0
000072bd77de155a  pop r11
000072bd77de155c  pop r10
000072bd77de155e  pop r9
000072bd77de1560  pop r8
000072bd77de1562  pop rsi
000072bd77de1563  pop rdi
000072bd77de1564  pop rdx
000072bd77de1565  pop rcx
000072bd77de1566  pop rax
000072bd77de1567  add rsp, 0x08
000072bd77de156b  jmp 0x000072BD77DDC7E2
000072bd77de1570  sub rsp, 0x08
000072bd77de1574  push rax
000072bd77de1575  push rcx
000072bd77de1576  push rdx
000072bd77de1577  push rdi
000072bd77de1578  push rsi
000072bd77de1579  push r8
000072bd77de157b  push r9
000072bd77de157d  push r10
000072bd77de157f  push r11
000072bd77de1581  sub rsp, 0xF0
000072bd77de1588  vmovaps [rsp], xmm0
000072bd77de158d  vmovaps [rsp+0x10], xmm1
000072bd77de1593  vmovaps [rsp+0x20], xmm2
000072bd77de1599  vmovaps [rsp+0x30], xmm3
000072bd77de159f  vmovaps [rsp+0x40], xmm4
000072bd77de15a5  vmovaps [rsp+0x50], xmm5
000072bd77de15ab  vmovaps [rsp+0x60], xmm6
000072bd77de15b1  vmovaps [rsp+0x70], xmm7
000072bd77de15b7  vmovaps [rsp+0x80], xmm8
000072bd77de15c0  vmovaps [rsp+0x90], xmm9
000072bd77de15c9  vmovaps [rsp+0xA0], xmm10
000072bd77de15d2  vmovaps [rsp+0xB0], xmm11
000072bd77de15db  vmovaps [rsp+0xC0], xmm12
000072bd77de15e4  vmovaps [rsp+0xD0], xmm13
000072bd77de15ed  vmovaps [rsp+0xE0], xmm14
000072bd77de15f6  sub rsp, 0x30
000072bd77de15fa  movaps [rsp], xmm15
000072bd77de15ff  movaps [rsp+0x10], xmm11
000072bd77de1605  movaps [rsp+0x20], xmm12
000072bd77de160b  lea rdi, [rsp]
000072bd77de160f  mov esi, 0x00
000072bd77de1614  mov rax, 0x643206AC3530
000072bd77de161e  call rax
000072bd77de1620  movaps xmm15, [rsp]
000072bd77de1625  add rsp, 0x30
000072bd77de1629  vmovaps xmm0, [rsp]
000072bd77de162e  vmovaps xmm1, [rsp+0x10]
000072bd77de1634  vmovaps xmm2, [rsp+0x20]
000072bd77de163a  vmovaps xmm3, [rsp+0x30]
000072bd77de1640  vmovaps xmm4, [rsp+0x40]
000072bd77de1646  vmovaps xmm5, [rsp+0x50]
000072bd77de164c  vmovaps xmm6, [rsp+0x60]
000072bd77de1652  vmovaps xmm7, [rsp+0x70]
000072bd77de1658  vmovaps xmm8, [rsp+0x80]
000072bd77de1661  vmovaps xmm9, [rsp+0x90]
000072bd77de166a  vmovaps xmm10, [rsp+0xA0]
000072bd77de1673  vmovaps xmm11, [rsp+0xB0]
000072bd77de167c  vmovaps xmm12, [rsp+0xC0]
000072bd77de1685  vmovaps xmm13, [rsp+0xD0]
000072bd77de168e  vmovaps xmm14, [rsp+0xE0]
000072bd77de1697  add rsp, 0xF0
000072bd77de169e  pop r11
000072bd77de16a0  pop r10
000072bd77de16a2  pop r9
000072bd77de16a4  pop r8
000072bd77de16a6  pop rsi
000072bd77de16a7  pop rdi
000072bd77de16a8  pop rdx
000072bd77de16a9  pop rcx
000072bd77de16aa  pop rax
000072bd77de16ab  add rsp, 0x08
000072bd77de16af  jmp 0x000072BD77DDC7FD
000072bd77de16b4  sub rsp, 0x08
000072bd77de16b8  push rax
000072bd77de16b9  push rcx
000072bd77de16ba  push rdx
000072bd77de16bb  push rdi
000072bd77de16bc  push rsi
000072bd77de16bd  push r8
000072bd77de16bf  push r9
000072bd77de16c1  push r10
000072bd77de16c3  push r11
000072bd77de16c5  sub rsp, 0xF0
000072bd77de16cc  vmovaps [rsp], xmm0
000072bd77de16d1  vmovaps [rsp+0x10], xmm1
000072bd77de16d7  vmovaps [rsp+0x20], xmm2
000072bd77de16dd  vmovaps [rsp+0x30], xmm3
000072bd77de16e3  vmovaps [rsp+0x40], xmm4
000072bd77de16e9  vmovaps [rsp+0x50], xmm5
000072bd77de16ef  vmovaps [rsp+0x60], xmm6
000072bd77de16f5  vmovaps [rsp+0x70], xmm7
000072bd77de16fb  vmovaps [rsp+0x80], xmm8
000072bd77de1704  vmovaps [rsp+0x90], xmm9
000072bd77de170d  vmovaps [rsp+0xA0], xmm10
000072bd77de1716  vmovaps [rsp+0xB0], xmm11
000072bd77de171f  vmovaps [rsp+0xC0], xmm12
000072bd77de1728  vmovaps [rsp+0xD0], xmm14
000072bd77de1731  vmovaps [rsp+0xE0], xmm15
000072bd77de173a  sub rsp, 0x30
000072bd77de173e  movaps [rsp], xmm13
000072bd77de1743  movaps [rsp+0x10], xmm10
000072bd77de1749  movaps [rsp+0x20], xmm14
000072bd77de174f  lea rdi, [rsp]
000072bd77de1753  mov esi, 0x00
000072bd77de1758  mov rax, 0x643206AC3530
000072bd77de1762  call rax
000072bd77de1764  movaps xmm13, [rsp]
000072bd77de1769  add rsp, 0x30
000072bd77de176d  vmovaps xmm0, [rsp]
000072bd77de1772  vmovaps xmm1, [rsp+0x10]
000072bd77de1778  vmovaps xmm2, [rsp+0x20]
000072bd77de177e  vmovaps xmm3, [rsp+0x30]
000072bd77de1784  vmovaps xmm4, [rsp+0x40]
000072bd77de178a  vmovaps xmm5, [rsp+0x50]
000072bd77de1790  vmovaps xmm6, [rsp+0x60]
000072bd77de1796  vmovaps xmm7, [rsp+0x70]
000072bd77de179c  vmovaps xmm8, [rsp+0x80]
000072bd77de17a5  vmovaps xmm9, [rsp+0x90]
000072bd77de17ae  vmovaps xmm10, [rsp+0xA0]
000072bd77de17b7  vmovaps xmm11, [rsp+0xB0]
000072bd77de17c0  vmovaps xmm12, [rsp+0xC0]
000072bd77de17c9  vmovaps xmm14, [rsp+0xD0]
000072bd77de17d2  vmovaps xmm15, [rsp+0xE0]
000072bd77de17db  add rsp, 0xF0
000072bd77de17e2  pop r11
000072bd77de17e4  pop r10
000072bd77de17e6  pop r9
000072bd77de17e8  pop r8
000072bd77de17ea  pop rsi
000072bd77de17eb  pop rdi
000072bd77de17ec  pop rdx
000072bd77de17ed  pop rcx
000072bd77de17ee  pop rax
000072bd77de17ef  add rsp, 0x08
000072bd77de17f3  jmp 0x000072BD77DDC820
000072bd77de17f8  sub rsp, 0x08
000072bd77de17fc  push rax
000072bd77de17fd  push rcx
000072bd77de17fe  push rdx
000072bd77de17ff  push rdi
000072bd77de1800  push rsi
000072bd77de1801  push r8
000072bd77de1803  push r9
000072bd77de1805  push r10
000072bd77de1807  push r11
000072bd77de1809  sub rsp, 0xF0
000072bd77de1810  vmovaps [rsp], xmm0
000072bd77de1815  vmovaps [rsp+0x10], xmm1
000072bd77de181b  vmovaps [rsp+0x20], xmm2
000072bd77de1821  vmovaps [rsp+0x30], xmm3
000072bd77de1827  vmovaps [rsp+0x40], xmm4
000072bd77de182d  vmovaps [rsp+0x50], xmm5
000072bd77de1833  vmovaps [rsp+0x60], xmm6
000072bd77de1839  vmovaps [rsp+0x70], xmm7
000072bd77de183f  vmovaps [rsp+0x80], xmm8
000072bd77de1848  vmovaps [rsp+0x90], xmm9
000072bd77de1851  vmovaps [rsp+0xA0], xmm10
000072bd77de185a  vmovaps [rsp+0xB0], xmm11
000072bd77de1863  vmovaps [rsp+0xC0], xmm12
000072bd77de186c  vmovaps [rsp+0xD0], xmm13
000072bd77de1875  vmovaps [rsp+0xE0], xmm15
000072bd77de187e  sub rsp, 0x30
000072bd77de1882  movaps [rsp], xmm14
000072bd77de1887  movaps [rsp+0x10], xmm1
000072bd77de188c  movaps [rsp+0x20], xmm7
000072bd77de1891  lea rdi, [rsp]
000072bd77de1895  mov esi, 0x00
000072bd77de189a  mov rax, 0x643206AC3530
000072bd77de18a4  call rax
000072bd77de18a6  movaps xmm14, [rsp]
000072bd77de18ab  add rsp, 0x30
000072bd77de18af  vmovaps xmm0, [rsp]
000072bd77de18b4  vmovaps xmm1, [rsp+0x10]
000072bd77de18ba  vmovaps xmm2, [rsp+0x20]
000072bd77de18c0  vmovaps xmm3, [rsp+0x30]
000072bd77de18c6  vmovaps xmm4, [rsp+0x40]
000072bd77de18cc  vmovaps xmm5, [rsp+0x50]
000072bd77de18d2  vmovaps xmm6, [rsp+0x60]
000072bd77de18d8  vmovaps xmm7, [rsp+0x70]
000072bd77de18de  vmovaps xmm8, [rsp+0x80]
000072bd77de18e7  vmovaps xmm9, [rsp+0x90]
000072bd77de18f0  vmovaps xmm10, [rsp+0xA0]
000072bd77de18f9  vmovaps xmm11, [rsp+0xB0]
000072bd77de1902  vmovaps xmm12, [rsp+0xC0]
000072bd77de190b  vmovaps xmm13, [rsp+0xD0]
000072bd77de1914  vmovaps xmm15, [rsp+0xE0]
000072bd77de191d  add rsp, 0xF0
000072bd77de1924  pop r11
000072bd77de1926  pop r10
000072bd77de1928  pop r9
000072bd77de192a  pop r8
000072bd77de192c  pop rsi
000072bd77de192d  pop rdi
000072bd77de192e  pop rdx
000072bd77de192f  pop rcx
000072bd77de1930  pop rax
000072bd77de1931  add rsp, 0x08
000072bd77de1935  jmp 0x000072BD77DDC843
000072bd77de193a  sub rsp, 0x08
000072bd77de193e  push rax
000072bd77de193f  push rcx
000072bd77de1940  push rdx
000072bd77de1941  push rdi
000072bd77de1942  push rsi
000072bd77de1943  push r8
000072bd77de1945  push r9
000072bd77de1947  push r10
000072bd77de1949  push r11
000072bd77de194b  sub rsp, 0xF0
000072bd77de1952  vmovaps [rsp], xmm0
000072bd77de1957  vmovaps [rsp+0x10], xmm2
000072bd77de195d  vmovaps [rsp+0x20], xmm3
000072bd77de1963  vmovaps [rsp+0x30], xmm4
000072bd77de1969  vmovaps [rsp+0x40], xmm5
000072bd77de196f  vmovaps [rsp+0x50], xmm6
000072bd77de1975  vmovaps [rsp+0x60], xmm7
000072bd77de197b  vmovaps [rsp+0x70], xmm8
000072bd77de1981  vmovaps [rsp+0x80], xmm9
000072bd77de198a  vmovaps [rsp+0x90], xmm10
000072bd77de1993  vmovaps [rsp+0xA0], xmm11
000072bd77de199c  vmovaps [rsp+0xB0], xmm12
000072bd77de19a5  vmovaps [rsp+0xC0], xmm13
000072bd77de19ae  vmovaps [rsp+0xD0], xmm14
000072bd77de19b7  vmovaps [rsp+0xE0], xmm15
000072bd77de19c0  sub rsp, 0x30
000072bd77de19c4  movaps [rsp], xmm1
000072bd77de19c8  movaps [rsp+0x10], xmm8
000072bd77de19ce  movaps [rsp+0x20], xmm9
000072bd77de19d4  lea rdi, [rsp]
000072bd77de19d8  mov esi, 0x00
000072bd77de19dd  mov rax, 0x643206AC3530
000072bd77de19e7  call rax
000072bd77de19e9  movaps xmm1, [rsp]
000072bd77de19ed  add rsp, 0x30
000072bd77de19f1  vmovaps xmm0, [rsp]
000072bd77de19f6  vmovaps xmm2, [rsp+0x10]
000072bd77de19fc  vmovaps xmm3, [rsp+0x20]
000072bd77de1a02  vmovaps xmm4, [rsp+0x30]
000072bd77de1a08  vmovaps xmm5, [rsp+0x40]
000072bd77de1a0e  vmovaps xmm6, [rsp+0x50]
000072bd77de1a14  vmovaps xmm7, [rsp+0x60]
000072bd77de1a1a  vmovaps xmm8, [rsp+0x70]
000072bd77de1a20  vmovaps xmm9, [rsp+0x80]
000072bd77de1a29  vmovaps xmm10, [rsp+0x90]
000072bd77de1a32  vmovaps xmm11, [rsp+0xA0]
000072bd77de1a3b  vmovaps xmm12, [rsp+0xB0]
000072bd77de1a44  vmovaps xmm13, [rsp+0xC0]
000072bd77de1a4d  vmovaps xmm14, [rsp+0xD0]
000072bd77de1a56  vmovaps xmm15, [rsp+0xE0]
000072bd77de1a5f  add rsp, 0xF0
000072bd77de1a66  pop r11
000072bd77de1a68  pop r10
000072bd77de1a6a  pop r9
000072bd77de1a6c  pop r8
000072bd77de1a6e  pop rsi
000072bd77de1a6f  pop rdi
000072bd77de1a70  pop rdx
000072bd77de1a71  pop rcx
000072bd77de1a72  pop rax
000072bd77de1a73  add rsp, 0x08
000072bd77de1a77  jmp 0x000072BD77DDC865
000072bd77de1a7c  call 0x000072BD77CE5940
000072bd77de1a81  jmp 0x000072BD77DDC873
000072bd77de1a86  call 0x000072BD77C0C380
000072bd77de1a8b  jmp 0x000072BD77DDC87D
000072bd77de1a90  call 0x000072BD77C0D600
000072bd77de1a95  jmp 0x000072BD77DDC887
000072bd77de1a9a  call 0x000072BD77BFF540
000072bd77de1a9f  jmp 0x000072BD77DDC891
000072bd77de1aa4  int3
000072bd77de1aa5  nop [rax+rax*1], ax
000072bd77de1aae  nop
000072bd77de1ab0  mov rax, [r15+0xF8]
000072bd77de1ab7  lea r14, [rax+0x140]
000072bd77de1abe  mov r12, [r13+r14*1]
000072bd77de1ac3  mov [r15+0xE8], r12
000072bd77de1aca  lea r14, [rax+0x130]
000072bd77de1ad1  mov r12, [r13+r14*1]
000072bd77de1ad6  lea r14, [rax+0x138]
000072bd77de1add  mov r11, [r13+r14*1]
000072bd77de1ae2  movq xmm1, r12
000072bd77de1ae7  movq xmm15, r11
000072bd77de1aec  movq xmm1, xmm1
000072bd77de1af0  movq xmm1, xmm1
000072bd77de1af4  movaps [r15+0x1A0], xmm1
000072bd77de1afc  movq xmm15, xmm15
000072bd77de1b01  movq xmm15, xmm15
000072bd77de1b06  movaps [r15+0x190], xmm15
000072bd77de1b0e  lea r14, [rax+0x120]
000072bd77de1b15  mov r12, [r13+r14*1]
000072bd77de1b1a  lea r14, [rax+0x128]
000072bd77de1b21  mov r11, [r13+r14*1]
000072bd77de1b26  movq xmm1, r12
000072bd77de1b2b  movq xmm15, r11
000072bd77de1b30  movq xmm1, xmm1
000072bd77de1b34  movq xmm1, xmm1
000072bd77de1b38  movaps [r15+0x1C0], xmm1
000072bd77de1b40  movq xmm15, xmm15
000072bd77de1b45  movq xmm15, xmm15
000072bd77de1b4a  movaps [r15+0x1B0], xmm15
000072bd77de1b52  lea r14, [rax+0x110]
000072bd77de1b59  mov r12, [r13+r14*1]
000072bd77de1b5e  lea r14, [rax+0x118]
000072bd77de1b65  mov r11, [r13+r14*1]
000072bd77de1b6a  movq xmm1, r12
000072bd77de1b6f  movq xmm15, r11
000072bd77de1b74  movq xmm1, xmm1
000072bd77de1b78  movq xmm1, xmm1
000072bd77de1b7c  movaps [r15+0x1E0], xmm1
000072bd77de1b84  movq xmm15, xmm15
000072bd77de1b89  movq xmm15, xmm15
000072bd77de1b8e  movaps [r15+0x1D0], xmm15
000072bd77de1b96  lea r14, [rax+0x100]
000072bd77de1b9d  mov r12, [r13+r14*1]
000072bd77de1ba2  lea r14, [rax+0x108]
000072bd77de1ba9  mov r11, [r13+r14*1]
000072bd77de1bae  movq xmm1, r12
000072bd77de1bb3  movq xmm15, r11
000072bd77de1bb8  movq xmm1, xmm1
000072bd77de1bbc  movq xmm1, xmm1
000072bd77de1bc0  movaps [r15+0x200], xmm1
000072bd77de1bc8  movq xmm15, xmm15
000072bd77de1bcd  movq xmm15, xmm15
000072bd77de1bd2  movaps [r15+0x1F0], xmm15
000072bd77de1bda  mov qword ptr [r15+0x40], 0x430000
000072bd77de1be2  mov r14d, 0x430510
000072bd77de1be8  mov r12, [r13+r14*1]
000072bd77de1bed  movq xmm1, r12
000072bd77de1bf2  lea r14, [rax+0x150]
000072bd77de1bf9  mov [r15+0xF8], r14
000072bd77de1c00  mov rax, [r15+0x50]
000072bd77de1c04  movups xmm15, [r13+rax*1]
000072bd77de1c0a  movaps [r15+0x120], xmm15
000072bd77de1c12  mov qword ptr [r15+0x48], 0x10
000072bd77de1c1a  xor eax, eax
000072bd77de1c1c  mov r14d, 0x10
000072bd77de1c22  mov r12d, 0x200
000072bd77de1c28  cmp r14, r12
000072bd77de1c2b  cmc
000072bd77de1c2c  lahf
000072bd77de1c2d  seto al
000072bd77de1c30  mov [r15+0x108], eax
000072bd77de1c37  pextrq rax, xmm15, 0x01
000072bd77de1c3e  movq xmm14, rax
000072bd77de1c43  movaps [r15+0x130], xmm14
000072bd77de1c4b  movq rax, xmm1
000072bd77de1c50  movq r14, xmm15
000072bd77de1c55  vmovq xmm1, rax
000072bd77de1c5a  vmovq xmm15, r14
000072bd77de1c5f  movaps xmm13, xmm1
000072bd77de1c63  addsd xmm13, xmm15
000072bd77de1c68  ucomisd xmm13, xmm13
000072bd77de1c6d  jp 0x000072BD77DE1D86
000072bd77de1c73  movq xmm13, xmm13
000072bd77de1c78  movq rax, xmm13
000072bd77de1c7d  movq r14, xmm14
000072bd77de1c82  vmovq xmm1, rax
000072bd77de1c87  vmovq xmm15, r14
000072bd77de1c8c  movaps xmm14, xmm1
000072bd77de1c90  addsd xmm14, xmm15
000072bd77de1c95  ucomisd xmm14, xmm14
000072bd77de1c9a  jp 0x000072BD77DE1DCE
000072bd77de1ca0  movq xmm14, xmm14
000072bd77de1ca5  movaps [r15+0x110], xmm14
000072bd77de1cad  mov eax, [r15+0x108]
000072bd77de1cb4  sahf
000072bd77de1cb5  jnz 0x000072BD77DE1CE7
000072bd77de1cb7  cmp dword ptr [r15+0x318], 0x00
000072bd77de1cbf  jz 0x000072BD77DE1FE0
000072bd77de1cc5  nop [rax+rax*1], ax
000072bd77de1cce  nop [rax+rax*1], eax
000072bd77de1cd6  mov eax, 0x410490
000072bd77de1cdb  mov [r15+0x100], rax
000072bd77de1ce2  jmp 0x000072BD77BFE110
000072bd77de1ce7  cmp dword ptr [r15+0x318], 0x00
000072bd77de1cef  jz 0x000072BD77DE1E20
000072bd77de1cf5  nop [rax+rax*1], ax
000072bd77de1cfe  nop [rax+rax*1], eax
000072bd77de1d06  mov eax, 0x410474
000072bd77de1d0b  mov [r15+0x100], rax
000072bd77de1d12  jmp 0x000072BD77BFE110
000072bd77de1d17  int3
000072bd77de1d18  call 0x000072BD77CE27E0
000072bd77de1d1d  jmp 0x000072BD77DE1AC3
000072bd77de1d22  call 0x000072BD77CE27E0
000072bd77de1d27  jmp 0x000072BD77DE1AD6
000072bd77de1d2c  call 0x000072BD77CE1570
000072bd77de1d31  jmp 0x000072BD77DE1AE2
000072bd77de1d36  call 0x000072BD77CE27E0
000072bd77de1d3b  jmp 0x000072BD77DE1B1A
000072bd77de1d40  call 0x000072BD77CE1570
000072bd77de1d45  jmp 0x000072BD77DE1B26
000072bd77de1d4a  call 0x000072BD77CE27E0
000072bd77de1d4f  jmp 0x000072BD77DE1B5E
000072bd77de1d54  call 0x000072BD77CE1570
000072bd77de1d59  jmp 0x000072BD77DE1B6A
000072bd77de1d5e  call 0x000072BD77CE27E0
000072bd77de1d63  jmp 0x000072BD77DE1BA2
000072bd77de1d68  call 0x000072BD77CE1570
000072bd77de1d6d  jmp 0x000072BD77DE1BAE
000072bd77de1d72  call 0x000072BD77CE27E0
000072bd77de1d77  jmp 0x000072BD77DE1BED
000072bd77de1d7c  call 0x000072BD77C0E760
000072bd77de1d81  jmp 0x000072BD77DE1C0A
000072bd77de1d86  ucomisd xmm1, xmm15
000072bd77de1d8b  jp 0x000072BD77DE1D9A
000072bd77de1d8d  movaps xmm13, [0x000072BD779FE060]
000072bd77de1d95  jmp 0x000072BD77DE1C73
000072bd77de1d9a  vxorps xmm0, xmm1, xmm15
000072bd77de1d9f  pextrw eax, xmm0, 0x03
000072bd77de1da4  and eax, 0x7FF8
000072bd77de1da9  cmp eax, 0x08
000072bd77de1dac  jnz 0x000072BD77DE1C73
000072bd77de1db2  movq rax, xmm15
000072bd77de1db7  shl rax, 0x0D
000072bd77de1dbb  jbe 0x000072BD77DE1C73
000072bd77de1dc1  vorps xmm13, xmm15, [0x000072BD779FE070]
000072bd77de1dc9  jmp 0x000072BD77DE1C73
000072bd77de1dce  ucomisd xmm1, xmm15
000072bd77de1dd3  jp 0x000072BD77DE1DE2
000072bd77de1dd5  movaps xmm14, [0x000072BD779FE060]
000072bd77de1ddd  jmp 0x000072BD77DE1CA0
000072bd77de1de2  vxorps xmm0, xmm1, xmm15
000072bd77de1de7  pextrw eax, xmm0, 0x03
000072bd77de1dec  and eax, 0x7FF8
000072bd77de1df1  cmp eax, 0x08
000072bd77de1df4  jnz 0x000072BD77DE1CA0
000072bd77de1dfa  movq rax, xmm15
000072bd77de1dff  shl rax, 0x0D
000072bd77de1e03  jbe 0x000072BD77DE1CA0
000072bd77de1e09  vorps xmm14, xmm15, [0x000072BD779FE070]
000072bd77de1e11  jmp 0x000072BD77DE1CA0
000072bd77de1e16  int3
000072bd77de1e17  nop [rax+rax*1], ax
000072bd77de1e20  mov rax, [r15+0x48]
000072bd77de1e24  mov r14, [r15+0x50]
000072bd77de1e28  lea r12, [r14+rax*1]
000072bd77de1e2c  movups xmm1, [r13+r12*1]
000072bd77de1e32  movaps [r15+0x120], xmm1
000072bd77de1e3a  lea r14, [rax+0x10]
000072bd77de1e3e  mov [r15+0x48], r14
000072bd77de1e42  xor eax, eax
000072bd77de1e44  mov r12d, 0x200
000072bd77de1e4a  cmp r14, r12
000072bd77de1e4d  cmc
000072bd77de1e4e  lahf
000072bd77de1e4f  seto al
000072bd77de1e52  mov [r15+0x108], eax
000072bd77de1e59  pextrq rax, xmm1, 0x01
000072bd77de1e60  movq xmm15, rax
000072bd77de1e65  movaps [r15+0x130], xmm15
000072bd77de1e6d  movaps xmm14, [r15+0x110]
000072bd77de1e75  movq rax, xmm14
000072bd77de1e7a  movq r14, xmm1
000072bd77de1e7f  vmovq xmm1, rax
000072bd77de1e84  vmovq xmm14, r14
000072bd77de1e89  movaps xmm13, xmm1
000072bd77de1e8d  addsd xmm13, xmm14
000072bd77de1e92  ucomisd xmm13, xmm13
000072bd77de1e97  jp 0x000072BD77DE1F4C
000072bd77de1e9d  movq xmm13, xmm13
000072bd77de1ea2  movq rax, xmm13
000072bd77de1ea7  movq r14, xmm15
000072bd77de1eac  vmovq xmm1, rax
000072bd77de1eb1  vmovq xmm15, r14
000072bd77de1eb6  movaps xmm14, xmm1
000072bd77de1eba  addsd xmm14, xmm15
000072bd77de1ebf  ucomisd xmm14, xmm14
000072bd77de1ec4  jp 0x000072BD77DE1F94
000072bd77de1eca  movq xmm14, xmm14
000072bd77de1ecf  movaps [r15+0x110], xmm14
000072bd77de1ed7  mov eax, [r15+0x108]
000072bd77de1ede  sahf
000072bd77de1edf  jnz 0x000072BD77DE1F11
000072bd77de1ee1  cmp dword ptr [r15+0x318], 0x00
000072bd77de1ee9  jz 0x000072BD77DE1FE0
000072bd77de1eef  nop [rax+rax*1], ax
000072bd77de1ef8  nop [rax+rax*1], eax
000072bd77de1f00  mov eax, 0x410490
000072bd77de1f05  mov [r15+0x100], rax
000072bd77de1f0c  jmp 0x000072BD77BFE110
000072bd77de1f11  cmp dword ptr [r15+0x318], 0x00
000072bd77de1f19  jz 0x000072BD77DE1E20
000072bd77de1f1f  nop [rax+rax*1], ax
000072bd77de1f28  nop [rax+rax*1], eax
000072bd77de1f30  mov eax, 0x410474
000072bd77de1f35  mov [r15+0x100], rax
000072bd77de1f3c  jmp 0x000072BD77BFE110
000072bd77de1f41  int3
000072bd77de1f42  call 0x000072BD77CB52F0
000072bd77de1f47  jmp 0x000072BD77DE1E32
000072bd77de1f4c  ucomisd xmm1, xmm14
000072bd77de1f51  jp 0x000072BD77DE1F60
000072bd77de1f53  movaps xmm13, [0x000072BD779FE060]
000072bd77de1f5b  jmp 0x000072BD77DE1E9D
000072bd77de1f60  vxorps xmm0, xmm1, xmm14
000072bd77de1f65  pextrw eax, xmm0, 0x03
000072bd77de1f6a  and eax, 0x7FF8
000072bd77de1f6f  cmp eax, 0x08
000072bd77de1f72  jnz 0x000072BD77DE1E9D
000072bd77de1f78  movq rax, xmm14
000072bd77de1f7d  shl rax, 0x0D
000072bd77de1f81  jbe 0x000072BD77DE1E9D
000072bd77de1f87  vorps xmm13, xmm14, [0x000072BD779FE070]
000072bd77de1f8f  jmp 0x000072BD77DE1E9D
000072bd77de1f94  ucomisd xmm1, xmm15
000072bd77de1f99  jp 0x000072BD77DE1FA8
000072bd77de1f9b  movaps xmm14, [0x000072BD779FE060]
000072bd77de1fa3  jmp 0x000072BD77DE1ECA
000072bd77de1fa8  vxorps xmm0, xmm1, xmm15
000072bd77de1fad  pextrw eax, xmm0, 0x03
000072bd77de1fb2  and eax, 0x7FF8
000072bd77de1fb7  cmp eax, 0x08
000072bd77de1fba  jnz 0x000072BD77DE1ECA
000072bd77de1fc0  movq rax, xmm15
000072bd77de1fc5  shl rax, 0x0D
000072bd77de1fc9  jbe 0x000072BD77DE1ECA
000072bd77de1fcf  vorps xmm14, xmm15, [0x000072BD779FE070]
000072bd77de1fd7  jmp 0x000072BD77DE1ECA
000072bd77de1fdc  int3
000072bd77de1fdd  nop [rax], eax
000072bd77de1fe0  mov rax, [r15+0x40]
000072bd77de1fe4  lea r14, [rax+0x510]
000072bd77de1feb  movaps xmm1, [r15+0x110]
000072bd77de1ff3  movq rax, xmm1
000072bd77de1ff8  mov [r13+r14*1], rax
000072bd77de1ffd  mov rax, [r15+0xF0]
000072bd77de2004  mov [r15+0x100], rax
000072bd77de200b  jmp 0x000072BD77DCE5C0
000072bd77de2010  int3
000072bd77de2011  call 0x000072BD77CD5EB0
000072bd77de2016  jmp 0x000072BD77DE1FFD
000072bd77de201b  int3
000072bd77de201c  nop [rax], eax
000072bd77de2020  mov qword ptr [r15+0x100], 0x04
000072bd77de202b  mov esi, 0x00
000072bd77de2030  mov edx, 0x09
000072bd77de2035  mov rdi, 0x7FFFF13EF1C0
000072bd77de203f  mov rax, 0x643206956970
000072bd77de2049  call rax
000072bd77de204b  cmp dword ptr [r15+0x318], 0x00
000072bd77de2053  jnz 0x000072BD77BFE110
000072bd77de2059  jmp 0x000072BD77BFE0A0
000072bd77de205e  int3
000072bd77de205f  int3
