000074fc119ce69b  nop [rax+rax*1], eax
000074fc119ce6a0  vmovaps xmm1, [0x000074FC115FE010]
000074fc119ce6a8  movq xmm1, xmm1
000074fc119ce6ac  movaps [r15+0x110], xmm1
000074fc119ce6b4  vmovaps xmm1, [0x000074FC115FE020]
000074fc119ce6bc  movq xmm1, xmm1
000074fc119ce6c0  movaps [r15+0x120], xmm1
000074fc119ce6c8  mov eax, 0x4204C0
000074fc119ce6cd  mov r14, [r13+rax*1]
000074fc119ce6d2  movq xmm1, r14
000074fc119ce6d7  movaps [r15+0x130], xmm1
000074fc119ce6df  vmovaps xmm1, [0x000074FC115FE030]
000074fc119ce6e7  vpbroadcastq xmm1, xmm1
000074fc119ce6ec  movaps [r15+0x140], xmm1
000074fc119ce6f4  mov qword ptr [r15+0x40], 0x02
000074fc119ce6fc  vmovaps xmm15, [0x000074FC115FE040]
000074fc119ce704  movq xmm15, xmm15
000074fc119ce709  movaps [r15+0x150], xmm15
000074fc119ce711  mov qword ptr [r15+0x58], 0x420000
000074fc119ce719  vmovaps xmm15, [0x000074FC115FE050]
000074fc119ce721  vpbroadcastq xmm15, xmm15
000074fc119ce726  movaps [r15+0x160], xmm15
000074fc119ce72e  mov rax, [r15+0x40]
000074fc119ce732  vmovq xmm14, rax
000074fc119ce737  vpbroadcastq xmm14, xmm14
000074fc119ce73c  movaps [r15+0x170], xmm14
000074fc119ce744  mov eax, 0x4204D0
000074fc119ce749  movups xmm13, [r13+rax*1]
000074fc119ce74f  mov qword ptr [r15+0x40], 0x430518
000074fc119ce757  mov qword ptr [r15+0x50], 0x430720
000074fc119ce75f  vpmovqd xmm12, xmm13
000074fc119ce765  pxor xmm11, xmm11
000074fc119ce76a  punpcklqdq xmm12, xmm11
000074fc119ce76f  movaps [r15+0x210], xmm12
000074fc119ce777  movq xmm12, qword ptr [r15+0x120]
000074fc119ce780  movq xmm11, qword ptr [r15+0x130]
000074fc119ce789  psubd xmm12, xmm11
000074fc119ce78e  movq xmm12, xmm12
000074fc119ce793  paddq xmm13, xmm14
000074fc119ce798  movaps [r15+0x180], xmm13
000074fc119ce7a0  movq xmm14, qword ptr [r15+0x150]
000074fc119ce7a9  paddd xmm11, xmm14
000074fc119ce7ae  movq xmm11, xmm11
000074fc119ce7b3  movq xmm11, xmm11
000074fc119ce7b8  movaps [r15+0x130], xmm11
000074fc119ce7c0  pmovzxdq xmm12, xmm12
000074fc119ce7c6  psllq xmm12, 0x00
000074fc119ce7cc  movq xmm14, qword ptr [r15+0x210]
000074fc119ce7d5  movq xmm13, qword ptr [r15+0x110]
000074fc119ce7de  paddd xmm14, xmm13
000074fc119ce7e3  movq xmm14, xmm14
000074fc119ce7e8  vcvtuqq2pd xmm12, xmm12
000074fc119ce7ee  pmovzxdq xmm14, xmm14
000074fc119ce7f4  psllq xmm14, 0x00
000074fc119ce7fa  vcvtuqq2pd xmm14, xmm14
000074fc119ce800  movaps xmm13, xmm12
000074fc119ce804  mulpd xmm13, xmm1
000074fc119ce809  vcmppd xmm11, xmm13, xmm13, 0x03
000074fc119ce80f  ptest xmm11, xmm11
000074fc119ce815  jnz 0x000074FC119CE8FF
000074fc119ce81b  movaps [r15+0x220], xmm13
000074fc119ce823  mov eax, 0x430720
000074fc119ce828  movups [r13+rax*1], xmm13
000074fc119ce82e  movaps xmm1, xmm14
000074fc119ce832  mulpd xmm1, xmm15
000074fc119ce837  vcmppd xmm13, xmm1, xmm1, 0x03
000074fc119ce83c  ptest xmm13, xmm13
000074fc119ce842  jnz 0x000074FC119CEA4C
000074fc119ce848  movaps [r15+0x210], xmm1
000074fc119ce850  mov eax, 0x430518
000074fc119ce855  movups [r13+rax*1], xmm1
000074fc119ce85b  mov qword ptr [r15+0x48], 0x10
000074fc119ce863  xor eax, eax
000074fc119ce865  mov r14d, 0x10
000074fc119ce86b  mov r12d, 0x200
000074fc119ce871  cmp r14, r12
000074fc119ce874  cmc
000074fc119ce875  lahf
000074fc119ce876  seto al
000074fc119ce879  mov [r15+0x108], eax
000074fc119ce880  mov eax, [r15+0x108]
000074fc119ce887  sahf
000074fc119ce888  jnz 0x000074FC119CE8BA
000074fc119ce88a  cmp dword ptr [r15+0x318], 0x00
000074fc119ce892  jz 0x000074FC119CEFF0
000074fc119ce898  nop [rax+rax*1], ax
000074fc119ce8a1  nop [rax+rax*1], eax
000074fc119ce8a9  mov eax, 0x4101EC
000074fc119ce8ae  mov [r15+0x100], rax
000074fc119ce8b5  jmp 0x000074FC117FE110
000074fc119ce8ba  cmp dword ptr [r15+0x318], 0x00
000074fc119ce8c2  jz 0x000074FC119CEBA0
000074fc119ce8c8  nop [rax+rax*1], ax
000074fc119ce8d1  nop [rax+rax*1], eax
000074fc119ce8d9  mov eax, 0x4101AC
000074fc119ce8de  mov [r15+0x100], rax
000074fc119ce8e5  jmp 0x000074FC117FE110
000074fc119ce8ea  int3
000074fc119ce8eb  call 0x000074FC1180DC20
000074fc119ce8f0  jmp 0x000074FC119CE6D2
000074fc119ce8f5  call 0x000074FC1180C260
000074fc119ce8fa  jmp 0x000074FC119CE74F
000074fc119ce8ff  sub rsp, 0x08
000074fc119ce903  push rax
000074fc119ce904  push rcx
000074fc119ce905  push rdx
000074fc119ce906  push rdi
000074fc119ce907  push rsi
000074fc119ce908  push r8
000074fc119ce90a  push r9
000074fc119ce90c  push r10
000074fc119ce90e  push r11
000074fc119ce910  sub rsp, 0xF0
000074fc119ce917  vmovaps [rsp], xmm0
000074fc119ce91c  vmovaps [rsp+0x10], xmm1
000074fc119ce922  vmovaps [rsp+0x20], xmm2
000074fc119ce928  vmovaps [rsp+0x30], xmm3
000074fc119ce92e  vmovaps [rsp+0x40], xmm4
000074fc119ce934  vmovaps [rsp+0x50], xmm5
000074fc119ce93a  vmovaps [rsp+0x60], xmm6
000074fc119ce940  vmovaps [rsp+0x70], xmm7
000074fc119ce946  vmovaps [rsp+0x80], xmm8
000074fc119ce94f  vmovaps [rsp+0x90], xmm9
000074fc119ce958  vmovaps [rsp+0xA0], xmm10
000074fc119ce961  vmovaps [rsp+0xB0], xmm11
000074fc119ce96a  vmovaps [rsp+0xC0], xmm12
000074fc119ce973  vmovaps [rsp+0xD0], xmm14
000074fc119ce97c  vmovaps [rsp+0xE0], xmm15
000074fc119ce985  sub rsp, 0x30
000074fc119ce989  movaps [rsp], xmm13
000074fc119ce98e  movaps [rsp+0x10], xmm12
000074fc119ce994  movaps [rsp+0x20], xmm1
000074fc119ce999  lea rdi, [rsp]
000074fc119ce99d  mov esi, 0x00
000074fc119ce9a2  mov rax, 0x58C4C8091530
000074fc119ce9ac  call rax
000074fc119ce9ae  movaps xmm13, [rsp]
000074fc119ce9b3  add rsp, 0x30
000074fc119ce9b7  vmovaps xmm0, [rsp]
000074fc119ce9bc  vmovaps xmm1, [rsp+0x10]
000074fc119ce9c2  vmovaps xmm2, [rsp+0x20]
000074fc119ce9c8  vmovaps xmm3, [rsp+0x30]
000074fc119ce9ce  vmovaps xmm4, [rsp+0x40]
000074fc119ce9d4  vmovaps xmm5, [rsp+0x50]
000074fc119ce9da  vmovaps xmm6, [rsp+0x60]
000074fc119ce9e0  vmovaps xmm7, [rsp+0x70]
000074fc119ce9e6  vmovaps xmm8, [rsp+0x80]
000074fc119ce9ef  vmovaps xmm9, [rsp+0x90]
000074fc119ce9f8  vmovaps xmm10, [rsp+0xA0]
000074fc119cea01  vmovaps xmm11, [rsp+0xB0]
000074fc119cea0a  vmovaps xmm12, [rsp+0xC0]
000074fc119cea13  vmovaps xmm14, [rsp+0xD0]
000074fc119cea1c  vmovaps xmm15, [rsp+0xE0]
000074fc119cea25  add rsp, 0xF0
000074fc119cea2c  pop r11
000074fc119cea2e  pop r10
000074fc119cea30  pop r9
000074fc119cea32  pop r8
000074fc119cea34  pop rsi
000074fc119cea35  pop rdi
000074fc119cea36  pop rdx
000074fc119cea37  pop rcx
000074fc119cea38  pop rax
000074fc119cea39  add rsp, 0x08
000074fc119cea3d  jmp 0x000074FC119CE81B
000074fc119cea42  call 0x000074FC1180C380
000074fc119cea47  jmp 0x000074FC119CE82E
000074fc119cea4c  sub rsp, 0x08
000074fc119cea50  push rax
000074fc119cea51  push rcx
000074fc119cea52  push rdx
000074fc119cea53  push rdi
000074fc119cea54  push rsi
000074fc119cea55  push r8
000074fc119cea57  push r9
000074fc119cea59  push r10
000074fc119cea5b  push r11
000074fc119cea5d  sub rsp, 0xF0
000074fc119cea64  vmovaps [rsp], xmm0
000074fc119cea69  vmovaps [rsp+0x10], xmm2
000074fc119cea6f  vmovaps [rsp+0x20], xmm3
000074fc119cea75  vmovaps [rsp+0x30], xmm4
000074fc119cea7b  vmovaps [rsp+0x40], xmm5
000074fc119cea81  vmovaps [rsp+0x50], xmm6
000074fc119cea87  vmovaps [rsp+0x60], xmm7
000074fc119cea8d  vmovaps [rsp+0x70], xmm8
000074fc119cea93  vmovaps [rsp+0x80], xmm9
000074fc119cea9c  vmovaps [rsp+0x90], xmm10
000074fc119ceaa5  vmovaps [rsp+0xA0], xmm11
000074fc119ceaae  vmovaps [rsp+0xB0], xmm12
000074fc119ceab7  vmovaps [rsp+0xC0], xmm13
000074fc119ceac0  vmovaps [rsp+0xD0], xmm14
000074fc119ceac9  vmovaps [rsp+0xE0], xmm15
000074fc119cead2  sub rsp, 0x30
000074fc119cead6  movaps [rsp], xmm1
000074fc119ceada  movaps [rsp+0x10], xmm14
000074fc119ceae0  movaps [rsp+0x20], xmm15
000074fc119ceae6  lea rdi, [rsp]
000074fc119ceaea  mov esi, 0x00
000074fc119ceaef  mov rax, 0x58C4C8091530
000074fc119ceaf9  call rax
000074fc119ceafb  movaps xmm1, [rsp]
000074fc119ceaff  add rsp, 0x30
000074fc119ceb03  vmovaps xmm0, [rsp]
000074fc119ceb08  vmovaps xmm2, [rsp+0x10]
000074fc119ceb0e  vmovaps xmm3, [rsp+0x20]
000074fc119ceb14  vmovaps xmm4, [rsp+0x30]
000074fc119ceb1a  vmovaps xmm5, [rsp+0x40]
000074fc119ceb20  vmovaps xmm6, [rsp+0x50]
000074fc119ceb26  vmovaps xmm7, [rsp+0x60]
000074fc119ceb2c  vmovaps xmm8, [rsp+0x70]
000074fc119ceb32  vmovaps xmm9, [rsp+0x80]
000074fc119ceb3b  vmovaps xmm10, [rsp+0x90]
000074fc119ceb44  vmovaps xmm11, [rsp+0xA0]
000074fc119ceb4d  vmovaps xmm12, [rsp+0xB0]
000074fc119ceb56  vmovaps xmm13, [rsp+0xC0]
000074fc119ceb5f  vmovaps xmm14, [rsp+0xD0]
000074fc119ceb68  vmovaps xmm15, [rsp+0xE0]
000074fc119ceb71  add rsp, 0xF0
000074fc119ceb78  pop r11
000074fc119ceb7a  pop r10
000074fc119ceb7c  pop r9
000074fc119ceb7e  pop r8
000074fc119ceb80  pop rsi
000074fc119ceb81  pop rdi
000074fc119ceb82  pop rdx
000074fc119ceb83  pop rcx
000074fc119ceb84  pop rax
000074fc119ceb85  add rsp, 0x08
000074fc119ceb89  jmp 0x000074FC119CE848
000074fc119ceb8e  call 0x000074FC117FF540
000074fc119ceb93  jmp 0x000074FC119CE85B
000074fc119ceb98  int3
000074fc119ceb99  nop [rax], eax
000074fc119ceba0  movaps xmm1, [r15+0x180]
000074fc119ceba8  vpmovqd xmm15, xmm1
000074fc119cebae  pxor xmm14, xmm14
000074fc119cebb3  punpcklqdq xmm15, xmm14
000074fc119cebb8  movaps [r15+0x210], xmm15
000074fc119cebc0  movq xmm15, qword ptr [r15+0x120]
000074fc119cebc9  movq xmm14, qword ptr [r15+0x130]
000074fc119cebd2  psubd xmm15, xmm14
000074fc119cebd7  movq xmm15, xmm15
000074fc119cebdc  movaps xmm13, [r15+0x170]
000074fc119cebe4  paddq xmm1, xmm13
000074fc119cebe9  movaps [r15+0x180], xmm1
000074fc119cebf1  movq xmm1, qword ptr [r15+0x150]
000074fc119cebfa  paddd xmm14, xmm1
000074fc119cebff  movq xmm14, xmm14
000074fc119cec04  movq xmm14, xmm14
000074fc119cec09  movaps [r15+0x130], xmm14
000074fc119cec11  pmovzxdq xmm15, xmm15
000074fc119cec17  psllq xmm15, 0x00
000074fc119cec1d  movq xmm1, qword ptr [r15+0x210]
000074fc119cec26  movq xmm14, qword ptr [r15+0x110]
000074fc119cec2f  paddd xmm1, xmm14
000074fc119cec34  movq xmm1, xmm1
000074fc119cec38  vcvtuqq2pd xmm15, xmm15
000074fc119cec3e  pmovzxdq xmm1, xmm1
000074fc119cec43  psllq xmm1, 0x00
000074fc119cec48  vcvtuqq2pd xmm1, xmm1
000074fc119cec4e  movaps xmm14, [r15+0x140]
000074fc119cec56  movaps xmm13, xmm15
000074fc119cec5a  mulpd xmm13, xmm14
000074fc119cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000074fc119cec65  ptest xmm12, xmm12
000074fc119cec6b  jnz 0x000074FC119CED4E
000074fc119cec71  movaps [r15+0x220], xmm13
000074fc119cec79  mov rax, [r15+0x48]
000074fc119cec7d  mov r14, [r15+0x50]
000074fc119cec81  lea r12, [r14+rax*1]
000074fc119cec85  movups [r13+r12*1], xmm13
000074fc119cec8b  movaps xmm15, [r15+0x160]
000074fc119cec93  movaps xmm14, xmm1
000074fc119cec97  mulpd xmm14, xmm15
000074fc119cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000074fc119ceca2  ptest xmm13, xmm13
000074fc119ceca8  jnz 0x000074FC119CEE9C
000074fc119cecae  movaps [r15+0x210], xmm14
000074fc119cecb6  mov r14, [r15+0x40]
000074fc119cecba  lea r12, [r14+rax*1]
000074fc119cecbe  movups [r13+r12*1], xmm14
000074fc119cecc4  lea r14, [rax+0x10]
000074fc119cecc8  mov [r15+0x48], r14
000074fc119ceccc  xor eax, eax
000074fc119cecce  mov r12d, 0x200
000074fc119cecd4  cmp r14, r12
000074fc119cecd7  cmc
000074fc119cecd8  lahf
000074fc119cecd9  seto al
000074fc119cecdc  mov [r15+0x108], eax
000074fc119cece3  mov eax, [r15+0x108]
000074fc119cecea  sahf
000074fc119ceceb  jnz 0x000074FC119CED1D
000074fc119ceced  cmp dword ptr [r15+0x318], 0x00
000074fc119cecf5  jz 0x000074FC119CEFF0
000074fc119cecfb  nop [rax+rax*1], ax
000074fc119ced04  nop [rax+rax*1], eax
000074fc119ced0c  mov eax, 0x4101EC
000074fc119ced11  mov [r15+0x100], rax
000074fc119ced18  jmp 0x000074FC117FE110
000074fc119ced1d  cmp dword ptr [r15+0x318], 0x00
000074fc119ced25  jz 0x000074FC119CEBA0
000074fc119ced2b  nop [rax+rax*1], ax
000074fc119ced34  nop [rax+rax*1], eax
000074fc119ced3c  mov eax, 0x4101AC
000074fc119ced41  mov [r15+0x100], rax
000074fc119ced48  jmp 0x000074FC117FE110
000074fc119ced4d  int3
000074fc119ced4e  sub rsp, 0x08
000074fc119ced52  push rax
000074fc119ced53  push rcx
000074fc119ced54  push rdx
000074fc119ced55  push rdi
000074fc119ced56  push rsi
000074fc119ced57  push r8
000074fc119ced59  push r9
000074fc119ced5b  push r10
000074fc119ced5d  push r11
000074fc119ced5f  sub rsp, 0xF0
000074fc119ced66  vmovaps [rsp], xmm0
000074fc119ced6b  vmovaps [rsp+0x10], xmm1
000074fc119ced71  vmovaps [rsp+0x20], xmm2
000074fc119ced77  vmovaps [rsp+0x30], xmm3
000074fc119ced7d  vmovaps [rsp+0x40], xmm4
000074fc119ced83  vmovaps [rsp+0x50], xmm5
000074fc119ced89  vmovaps [rsp+0x60], xmm6
000074fc119ced8f  vmovaps [rsp+0x70], xmm7
000074fc119ced95  vmovaps [rsp+0x80], xmm8
000074fc119ced9e  vmovaps [rsp+0x90], xmm9
000074fc119ceda7  vmovaps [rsp+0xA0], xmm10
000074fc119cedb0  vmovaps [rsp+0xB0], xmm11
000074fc119cedb9  vmovaps [rsp+0xC0], xmm12
000074fc119cedc2  vmovaps [rsp+0xD0], xmm14
000074fc119cedcb  vmovaps [rsp+0xE0], xmm15
000074fc119cedd4  sub rsp, 0x30
000074fc119cedd8  movaps [rsp], xmm13
000074fc119ceddd  movaps [rsp+0x10], xmm15
000074fc119cede3  movaps [rsp+0x20], xmm14
000074fc119cede9  lea rdi, [rsp]
000074fc119ceded  mov esi, 0x00
000074fc119cedf2  mov rax, 0x58C4C8091530
000074fc119cedfc  call rax
000074fc119cedfe  movaps xmm13, [rsp]
000074fc119cee03  add rsp, 0x30
000074fc119cee07  vmovaps xmm0, [rsp]
000074fc119cee0c  vmovaps xmm1, [rsp+0x10]
000074fc119cee12  vmovaps xmm2, [rsp+0x20]
000074fc119cee18  vmovaps xmm3, [rsp+0x30]
000074fc119cee1e  vmovaps xmm4, [rsp+0x40]
000074fc119cee24  vmovaps xmm5, [rsp+0x50]
000074fc119cee2a  vmovaps xmm6, [rsp+0x60]
000074fc119cee30  vmovaps xmm7, [rsp+0x70]
000074fc119cee36  vmovaps xmm8, [rsp+0x80]
000074fc119cee3f  vmovaps xmm9, [rsp+0x90]
000074fc119cee48  vmovaps xmm10, [rsp+0xA0]
000074fc119cee51  vmovaps xmm11, [rsp+0xB0]
000074fc119cee5a  vmovaps xmm12, [rsp+0xC0]
000074fc119cee63  vmovaps xmm14, [rsp+0xD0]
000074fc119cee6c  vmovaps xmm15, [rsp+0xE0]
000074fc119cee75  add rsp, 0xF0
000074fc119cee7c  pop r11
000074fc119cee7e  pop r10
000074fc119cee80  pop r9
000074fc119cee82  pop r8
000074fc119cee84  pop rsi
000074fc119cee85  pop rdi
000074fc119cee86  pop rdx
000074fc119cee87  pop rcx
000074fc119cee88  pop rax
000074fc119cee89  add rsp, 0x08
000074fc119cee8d  jmp 0x000074FC119CEC71
000074fc119cee92  call 0x000074FC118C2240
000074fc119cee97  jmp 0x000074FC119CEC8B
000074fc119cee9c  sub rsp, 0x08
000074fc119ceea0  push rax
000074fc119ceea1  push rcx
000074fc119ceea2  push rdx
000074fc119ceea3  push rdi
000074fc119ceea4  push rsi
000074fc119ceea5  push r8
000074fc119ceea7  push r9
000074fc119ceea9  push r10
000074fc119ceeab  push r11
000074fc119ceead  sub rsp, 0xF0
000074fc119ceeb4  vmovaps [rsp], xmm0
000074fc119ceeb9  vmovaps [rsp+0x10], xmm1
000074fc119ceebf  vmovaps [rsp+0x20], xmm2
000074fc119ceec5  vmovaps [rsp+0x30], xmm3
000074fc119ceecb  vmovaps [rsp+0x40], xmm4
000074fc119ceed1  vmovaps [rsp+0x50], xmm5
000074fc119ceed7  vmovaps [rsp+0x60], xmm6
000074fc119ceedd  vmovaps [rsp+0x70], xmm7
000074fc119ceee3  vmovaps [rsp+0x80], xmm8
000074fc119ceeec  vmovaps [rsp+0x90], xmm9
000074fc119ceef5  vmovaps [rsp+0xA0], xmm10
000074fc119ceefe  vmovaps [rsp+0xB0], xmm11
000074fc119cef07  vmovaps [rsp+0xC0], xmm12
000074fc119cef10  vmovaps [rsp+0xD0], xmm13
000074fc119cef19  vmovaps [rsp+0xE0], xmm15
000074fc119cef22  sub rsp, 0x30
000074fc119cef26  movaps [rsp], xmm14
000074fc119cef2b  movaps [rsp+0x10], xmm1
000074fc119cef30  movaps [rsp+0x20], xmm15
000074fc119cef36  lea rdi, [rsp]
000074fc119cef3a  mov esi, 0x00
000074fc119cef3f  mov rax, 0x58C4C8091530
000074fc119cef49  call rax
000074fc119cef4b  movaps xmm14, [rsp]
000074fc119cef50  add rsp, 0x30
000074fc119cef54  vmovaps xmm0, [rsp]
000074fc119cef59  vmovaps xmm1, [rsp+0x10]
000074fc119cef5f  vmovaps xmm2, [rsp+0x20]
000074fc119cef65  vmovaps xmm3, [rsp+0x30]
000074fc119cef6b  vmovaps xmm4, [rsp+0x40]
000074fc119cef71  vmovaps xmm5, [rsp+0x50]
000074fc119cef77  vmovaps xmm6, [rsp+0x60]
000074fc119cef7d  vmovaps xmm7, [rsp+0x70]
000074fc119cef83  vmovaps xmm8, [rsp+0x80]
000074fc119cef8c  vmovaps xmm9, [rsp+0x90]
000074fc119cef95  vmovaps xmm10, [rsp+0xA0]
000074fc119cef9e  vmovaps xmm11, [rsp+0xB0]
000074fc119cefa7  vmovaps xmm12, [rsp+0xC0]
000074fc119cefb0  vmovaps xmm13, [rsp+0xD0]
000074fc119cefb9  vmovaps xmm15, [rsp+0xE0]
000074fc119cefc2  add rsp, 0xF0
000074fc119cefc9  pop r11
000074fc119cefcb  pop r10
000074fc119cefcd  pop r9
000074fc119cefcf  pop r8
000074fc119cefd1  pop rsi
000074fc119cefd2  pop rdi
000074fc119cefd3  pop rdx
000074fc119cefd4  pop rcx
000074fc119cefd5  pop rax
000074fc119cefd6  add rsp, 0x08
000074fc119cefda  jmp 0x000074FC119CECAE
000074fc119cefdf  call 0x000074FC118C34C0
000074fc119cefe4  jmp 0x000074FC119CECC4
000074fc119cefe9  int3
000074fc119cefea  nop [rax+rax*1], ax
000074fc119ceff0  mov rax, [r15+0xF8]
000074fc119ceff7  lea r14, [rax-0x150]
000074fc119ceffe  mov [r15+0xF8], r14
000074fc119cf005  mov rax, [r15+0x50]
000074fc119cf009  lea r12, [rax+0x80]
000074fc119cf010  movups xmm1, [r13+r12*1]
000074fc119cf016  lea r12, [rax+0x90]
000074fc119cf01d  movups xmm15, [r13+r12*1]
000074fc119cf023  mov qword ptr [r15+0x48], 0x00
000074fc119cf02b  lea r12, [rax+0x40]
000074fc119cf02f  movups xmm14, [r13+r12*1]
000074fc119cf035  lea r12, [rax+0x50]
000074fc119cf039  movups xmm13, [r13+r12*1]
000074fc119cf03f  lea r12, [r14+0x120]
000074fc119cf046  movq xmm12, qword ptr [r15+0x1C0]
000074fc119cf04f  movq xmm11, qword ptr [r15+0x1B0]
000074fc119cf058  movq r11, xmm12
000074fc119cf05d  movq r10, xmm11
000074fc119cf062  mov [r13+r12*1], r11
000074fc119cf067  lea r12, [r14+0x128]
000074fc119cf06e  mov [r13+r12*1], r10
000074fc119cf073  vxorps xmm12, xmm12, xmm12
000074fc119cf078  vpbroadcastq xmm12, xmm12
000074fc119cf07d  lea r12, [r14+0x100]
000074fc119cf084  movq xmm11, qword ptr [r15+0x200]
000074fc119cf08d  movq xmm10, qword ptr [r15+0x1F0]
000074fc119cf096  movq r11, xmm11
000074fc119cf09b  movq r10, xmm10
000074fc119cf0a0  mov [r13+r12*1], r11
000074fc119cf0a5  lea r12, [r14+0x108]
000074fc119cf0ac  mov [r13+r12*1], r10
000074fc119cf0b1  lea r12, [r14+0xE0]
000074fc119cf0b8  movups [r13+r12*1], xmm15
000074fc119cf0be  lea r12, [r14+0xF0]
000074fc119cf0c5  movups [r13+r12*1], xmm1
000074fc119cf0cb  lea r12, [rax+0xC0]
000074fc119cf0d2  movups xmm1, [r13+r12*1]
000074fc119cf0d8  lea r12, [rax+0xD0]
000074fc119cf0df  movups xmm15, [r13+r12*1]
000074fc119cf0e5  lea r12, [r14+0x110]
000074fc119cf0ec  movq xmm11, qword ptr [r15+0x1E0]
000074fc119cf0f5  movq xmm10, qword ptr [r15+0x1D0]
000074fc119cf0fe  movq r11, xmm11
000074fc119cf103  movq r10, xmm10
000074fc119cf108  mov [r13+r12*1], r11
000074fc119cf10d  lea r12, [r14+0x118]
000074fc119cf114  mov [r13+r12*1], r10
000074fc119cf119  movups xmm11, [r13+rax*1]
000074fc119cf11f  lea r12, [rax+0x10]
000074fc119cf123  movups xmm10, [r13+r12*1]
000074fc119cf129  lea r12, [r14+0x130]
000074fc119cf130  movq xmm9, qword ptr [r15+0x1A0]
000074fc119cf139  movq xmm8, qword ptr [r15+0x190]
000074fc119cf142  movq r11, xmm9
000074fc119cf147  movq r10, xmm8
000074fc119cf14c  mov [r13+r12*1], r11
000074fc119cf151  lea r12, [r14+0x138]
000074fc119cf158  mov [r13+r12*1], r10
000074fc119cf15d  lea r12, [rax+0x140]
000074fc119cf164  movups xmm9, [r13+r12*1]
000074fc119cf16a  lea r12, [rax+0x150]
000074fc119cf171  movups xmm8, [r13+r12*1]
000074fc119cf177  lea r12, [r14+0xC0]
000074fc119cf17e  movups [r13+r12*1], xmm15
000074fc119cf184  lea r12, [r14+0xD0]
000074fc119cf18b  movups [r13+r12*1], xmm1
000074fc119cf191  lea r12, [rax+0x100]
000074fc119cf198  movups xmm1, [r13+r12*1]
000074fc119cf19e  lea r12, [rax+0x110]
000074fc119cf1a5  movups xmm15, [r13+r12*1]
000074fc119cf1ab  lea r12, [r14+0x140]
000074fc119cf1b2  mov r11, [r15+0xE8]
000074fc119cf1b9  mov [r13+r12*1], r11
000074fc119cf1be  lea r12, [rax+0x180]
000074fc119cf1c5  movups xmm7, [r13+r12*1]
000074fc119cf1cb  lea r12, [rax+0x190]
000074fc119cf1d2  movups xmm6, [r13+r12*1]
000074fc119cf1d8  lea r12, [rax+0x1C0]
000074fc119cf1df  movups xmm5, [r13+r12*1]
000074fc119cf1e5  lea r12, [rax+0x1D0]
000074fc119cf1ec  movups xmm4, [r13+r12*1]
000074fc119cf1f2  lea r12, [r14+0x20]
000074fc119cf1f6  movups [r13+r12*1], xmm1
000074fc119cf1fc  lea r12, [r14+0x30]
000074fc119cf200  movups [r13+r12*1], xmm13
000074fc119cf206  lea r12, [rax+0x60]
000074fc119cf20a  movups xmm1, [r13+r12*1]
000074fc119cf210  lea r12, [rax+0x70]
000074fc119cf214  movups xmm13, [r13+r12*1]
000074fc119cf21a  lea r12, [rax+0x20]
000074fc119cf21e  movups xmm3, [r13+r12*1]
000074fc119cf224  lea r12, [rax+0x30]
000074fc119cf228  movups xmm2, [r13+r12*1]
000074fc119cf22e  movaps [r15+0x1F0], xmm2
000074fc119cf236  lea r12, [r14+0x60]
000074fc119cf23a  movups [r13+r12*1], xmm11
000074fc119cf240  lea r12, [r14+0x70]
000074fc119cf244  movups [r13+r12*1], xmm5
000074fc119cf24a  lea r12, [rax+0xE0]
000074fc119cf251  movups xmm11, [r13+r12*1]
000074fc119cf257  lea r12, [rax+0xF0]
000074fc119cf25e  movups xmm5, [r13+r12*1]
000074fc119cf264  lea r12, [r14+0xA0]
000074fc119cf26b  movups [r13+r12*1], xmm13
000074fc119cf271  lea r12, [r14+0xB0]
000074fc119cf278  movups [r13+r12*1], xmm1
000074fc119cf27e  lea r12, [rax+0xA0]
000074fc119cf285  movups xmm1, [r13+r12*1]
000074fc119cf28b  lea r12, [rax+0xB0]
000074fc119cf292  movups xmm13, [r13+r12*1]
000074fc119cf298  lea r12, [rax+0x120]
000074fc119cf29f  vmovaps [rsp+0x10], xmm1
000074fc119cf2a5  movups xmm1, [r13+r12*1]
000074fc119cf2ab  lea r12, [rax+0x130]
000074fc119cf2b2  vmovaps [rsp+0x20], xmm1
000074fc119cf2b8  movups xmm1, [r13+r12*1]
000074fc119cf2be  lea r12, [rax+0x160]
000074fc119cf2c5  vmovaps [rsp+0x30], xmm1
000074fc119cf2cb  movups xmm1, [r13+r12*1]
000074fc119cf2d1  lea r12, [rax+0x170]
000074fc119cf2d8  vmovaps [rsp+0x40], xmm1
000074fc119cf2de  movups xmm1, [r13+r12*1]
000074fc119cf2e4  movaps [r15+0x2B0], xmm1
000074fc119cf2ec  lea r12, [r14+0x80]
000074fc119cf2f3  movups [r13+r12*1], xmm13
000074fc119cf2f9  lea r12, [r14+0x90]
000074fc119cf300  vmovaps xmm13, [rsp+0x10]
000074fc119cf306  movups [r13+r12*1], xmm13
000074fc119cf30c  lea r12, [rax+0x1A0]
000074fc119cf313  movups xmm13, [r13+r12*1]
000074fc119cf319  lea r12, [rax+0x1B0]
000074fc119cf320  vmovaps [rsp+0x10], xmm1
000074fc119cf326  movups xmm1, [r13+r12*1]
000074fc119cf32c  movaps [r15+0x290], xmm13
000074fc119cf334  movaps [r15+0x1E0], xmm1
000074fc119cf33c  lea r12, [rax+0x1E0]
000074fc119cf343  vmovaps [rsp+0x50], xmm1
000074fc119cf349  movups xmm1, [r13+r12*1]
000074fc119cf34f  lea r12, [rax+0x1F0]
000074fc119cf356  vmovaps [rsp+0x60], xmm1
000074fc119cf35c  movups xmm1, [r13+r12*1]
000074fc119cf362  mov qword ptr [r15+0x50], 0x430920
000074fc119cf36a  lea rax, [r14+0x40]
000074fc119cf36e  vmovaps [rsp+0x70], xmm1
000074fc119cf374  vmovaps xmm1, [rsp+0x40]
000074fc119cf37a  movups [r13+rax*1], xmm1
000074fc119cf380  lea rax, [r14+0x50]
000074fc119cf384  movups [r13+rax*1], xmm10
000074fc119cf38a  vmovaps xmm1, [rsp+0x70]
000074fc119cf390  movups [r13+r14*1], xmm1
000074fc119cf396  lea rax, [r14+0x10]
000074fc119cf39a  vmovaps xmm1, [rsp+0x60]
000074fc119cf3a0  movups [r13+rax*1], xmm1
000074fc119cf3a6  mov rax, [r15+0x40]
000074fc119cf3aa  vmovaps [rsp+0x40], xmm3
000074fc119cf3b0  vmovaps xmm1, [rsp+0x40]
000074fc119cf3b6  por xmm3, xmm1
000074fc119cf3ba  vmovaps [rsp+0x40], xmm6
000074fc119cf3c0  vmovaps xmm10, [rsp+0x40]
000074fc119cf3c6  por xmm6, xmm10
000074fc119cf3cb  lea r12, [rax+0x30]
000074fc119cf3cf  mov r11, [r13+r12*1]
000074fc119cf3d4  lea r12, [rax+0x38]
000074fc119cf3d8  mov r10, [r13+r12*1]
000074fc119cf3dd  movq xmm10, r11
000074fc119cf3e2  vmovaps [rsp+0x40], xmm1
000074fc119cf3e8  movq xmm1, r10
000074fc119cf3ed  movq xmm10, xmm10
000074fc119cf3f2  vmovaps [rsp+0x60], xmm10
000074fc119cf3f8  movq xmm10, xmm10
000074fc119cf3fd  movaps [r15+0x130], xmm10
000074fc119cf405  movq xmm1, xmm1
000074fc119cf409  vmovaps [rsp+0x70], xmm1
000074fc119cf40f  movq xmm1, xmm1
000074fc119cf413  movaps [r15+0x280], xmm1
000074fc119cf41b  vmovaps [rsp+0x80], xmm9
000074fc119cf424  vmovaps xmm1, [rsp+0x80]
000074fc119cf42d  por xmm9, xmm1
000074fc119cf432  lea r12, [rax+0x20]
000074fc119cf436  mov r11, [r13+r12*1]
000074fc119cf43b  lea r12, [rax+0x28]
000074fc119cf43f  mov r10, [r13+r12*1]
000074fc119cf444  movq xmm1, r11
000074fc119cf449  movq xmm10, r10
000074fc119cf44e  movq xmm1, xmm1
000074fc119cf452  vmovaps [rsp+0x80], xmm1
000074fc119cf45b  movq xmm1, xmm1
000074fc119cf45f  movaps [r15+0x150], xmm1
000074fc119cf467  movq xmm10, xmm10
000074fc119cf46c  vmovaps [rsp+0x90], xmm10
000074fc119cf475  movq xmm10, xmm10
000074fc119cf47a  movaps [r15+0x140], xmm10
000074fc119cf482  lea r12, [rax+0x10]
000074fc119cf486  mov r11, [r13+r12*1]
000074fc119cf48b  lea r12, [rax+0x18]
000074fc119cf48f  mov r10, [r13+r12*1]
000074fc119cf494  movq xmm1, r11
000074fc119cf499  movq xmm10, r10
000074fc119cf49e  movq xmm1, xmm1
000074fc119cf4a2  vmovaps [rsp+0xA0], xmm1
000074fc119cf4ab  movq xmm1, xmm1
000074fc119cf4af  movaps [r15+0x170], xmm1
000074fc119cf4b7  movq xmm10, xmm10
000074fc119cf4bc  vmovaps [rsp+0xB0], xmm10
000074fc119cf4c5  movq xmm10, xmm10
000074fc119cf4ca  movaps [r15+0x160], xmm10
000074fc119cf4d2  mov r12, [r13+rax*1]
000074fc119cf4d7  vmovq xmm1, r12
000074fc119cf4dc  vpbroadcastq xmm1, xmm1
000074fc119cf4e1  lea r12, [rax+0x08]
000074fc119cf4e5  mov rax, [r13+r12*1]
000074fc119cf4ea  movq xmm10, rax
000074fc119cf4ef  movaps [r15+0x230], xmm10
000074fc119cf4f7  lea rax, [r14+0x50]
000074fc119cf4fb  movups xmm10, [r13+rax*1]
000074fc119cf501  lea rax, [r14+0x60]
000074fc119cf505  vmovaps [rsp+0xC0], xmm1
000074fc119cf50e  movups xmm1, [r13+rax*1]
000074fc119cf514  lea rax, [r14+0x30]
000074fc119cf518  vmovaps [rsp+0xD0], xmm1
000074fc119cf521  movups xmm1, [r13+rax*1]
000074fc119cf527  mov qword ptr [r15+0x60], 0x430920
000074fc119cf52f  mov qword ptr [r15+0x58], 0x40
000074fc119cf537  vmovaps [rsp+0xE0], xmm1
000074fc119cf540  vmovaps [rsp+0xF0], xmm15
000074fc119cf549  vmovaps xmm15, [rsp+0xC0]
000074fc119cf552  vmovaps [rsp+0xC0], xmm14
000074fc119cf55b  vmovaps xmm14, [rsp+0x40]
000074fc119cf561  vmovaps [rsp+0x40], xmm13
000074fc119cf567  movaps xmm1, xmm15
000074fc119cf56b  mulpd xmm1, xmm14
000074fc119cf570  vcmppd xmm13, xmm1, xmm1, 0x03
000074fc119cf575  ptest xmm13, xmm13
000074fc119cf57b  jnz 0x000074FC119D0682
000074fc119cf581  movq xmm14, qword ptr [r15+0x230]
000074fc119cf58a  vmovaps [rsp+0x100], xmm14
000074fc119cf593  vpermilpd xmm14, xmm14, 0x00
000074fc119cf599  vmovaps [rsp+0x110], xmm1
000074fc119cf5a2  vmovaps xmm1, [rsp+0xE0]
000074fc119cf5ab  vmovaps [rsp+0xE0], xmm15
000074fc119cf5b4  movaps xmm13, xmm1
000074fc119cf5b8  mulpd xmm13, xmm14
000074fc119cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000074fc119cf5c3  ptest xmm15, xmm15
000074fc119cf5c9  jnz 0x000074FC119D07C4
000074fc119cf5cf  vxorps xmm1, xmm1, xmm1
000074fc119cf5d3  vpbroadcastq xmm1, xmm1
000074fc119cf5d8  vmovaps xmm14, [rsp+0xE0]
000074fc119cf5e1  vmovaps [rsp+0xE0], xmm1
000074fc119cf5ea  vmovaps xmm1, [rsp+0xD0]
000074fc119cf5f3  vmovaps [rsp+0xD0], xmm13
000074fc119cf5fc  movaps xmm15, xmm14
000074fc119cf600  mulpd xmm15, xmm1
000074fc119cf605  vcmppd xmm13, xmm15, xmm15, 0x03
000074fc119cf60b  ptest xmm13, xmm13
000074fc119cf611  jnz 0x000074FC119D0907
000074fc119cf617  movaps xmm1, xmm14
000074fc119cf61b  mulpd xmm1, xmm10
000074fc119cf620  vcmppd xmm13, xmm1, xmm1, 0x03
000074fc119cf625  ptest xmm13, xmm13
000074fc119cf62b  jnz 0x000074FC119D0A4A
000074fc119cf631  movaps xmm13, xmm14
000074fc119cf635  mulpd xmm13, xmm2
000074fc119cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000074fc119cf640  ptest xmm10, xmm10
000074fc119cf646  jnz 0x000074FC119D0B8C
000074fc119cf64c  vmovaps [rsp+0x120], xmm7
000074fc119cf655  vmovaps xmm14, [rsp+0x120]
000074fc119cf65e  por xmm7, xmm14
000074fc119cf663  vmovaps xmm14, [rsp+0xC0]
000074fc119cf66c  vmovaps xmm10, [rsp+0xC0]
000074fc119cf675  por xmm14, xmm10
000074fc119cf67a  vmovaps xmm2, [rsp+0x100]
000074fc119cf683  vpermilpd xmm2, xmm2, 0x00
000074fc119cf689  vmovaps [rsp+0xC0], xmm1
000074fc119cf692  vmovaps [rsp+0x120], xmm15
000074fc119cf69b  movaps xmm1, xmm10
000074fc119cf69f  mulpd xmm1, xmm2
000074fc119cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000074fc119cf6a8  ptest xmm15, xmm15
000074fc119cf6ae  jnz 0x000074FC119D0CCF
000074fc119cf6b4  xor eax, eax
000074fc119cf6b6  mov r12d, 0x40
000074fc119cf6bc  mov r11d, 0x200
000074fc119cf6c2  cmp r12, r11
000074fc119cf6c5  cmc
000074fc119cf6c6  lahf
000074fc119cf6c7  seto al
000074fc119cf6ca  mov [r15+0x108], eax
000074fc119cf6d1  vmovaps xmm10, [rsp+0x110]
000074fc119cf6da  vmovaps xmm2, [rsp+0xE0]
000074fc119cf6e3  vmovaps [rsp+0xE0], xmm1
000074fc119cf6ec  movaps xmm15, xmm10
000074fc119cf6f0  addpd xmm15, xmm2
000074fc119cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000074fc119cf6fb  ptest xmm1, xmm1
000074fc119cf700  jnz 0x000074FC119D0E10
000074fc119cf706  vmovaps xmm10, [rsp+0x120]
000074fc119cf70f  vmovaps [rsp+0x110], xmm15
000074fc119cf718  movaps xmm1, xmm10
000074fc119cf71c  addpd xmm1, xmm12
000074fc119cf721  vcmppd xmm15, xmm1, xmm1, 0x03
000074fc119cf726  ptest xmm15, xmm15
000074fc119cf72c  jnz 0x000074FC119D0F53
000074fc119cf732  vmovaps xmm10, [rsp+0xC0]
000074fc119cf73b  vmovaps [rsp+0xC0], xmm1
000074fc119cf744  movaps xmm15, xmm10
000074fc119cf748  addpd xmm15, xmm12
000074fc119cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000074fc119cf753  ptest xmm1, xmm1
000074fc119cf758  jnz 0x000074FC119D1095
000074fc119cf75e  vmovaps xmm1, [rsp+0x30]
000074fc119cf764  vmovaps xmm12, [rsp+0x30]
000074fc119cf76a  por xmm1, xmm12
000074fc119cf76f  vmovaps xmm12, [rsp+0x20]
000074fc119cf775  vmovaps xmm10, [rsp+0x20]
000074fc119cf77b  por xmm12, xmm10
000074fc119cf780  vmovaps [rsp+0x20], xmm5
000074fc119cf786  vmovaps xmm10, [rsp+0x20]
000074fc119cf78c  por xmm5, xmm10
000074fc119cf791  vmovaps [rsp+0x20], xmm11
000074fc119cf797  vmovaps xmm10, [rsp+0x20]
000074fc119cf79d  por xmm11, xmm10
000074fc119cf7a2  vmovaps [rsp+0x20], xmm4
000074fc119cf7a8  vmovaps xmm10, [rsp+0x20]
000074fc119cf7ae  por xmm4, xmm10
000074fc119cf7b3  vmovaps [rsp+0x20], xmm8
000074fc119cf7b9  vmovaps xmm10, [rsp+0x20]
000074fc119cf7bf  por xmm8, xmm10
000074fc119cf7c4  vmovaps xmm10, [rsp+0xF0]
000074fc119cf7cd  vmovaps [rsp+0x20], xmm1
000074fc119cf7d3  vmovaps xmm1, [rsp+0xF0]
000074fc119cf7dc  por xmm10, xmm1
000074fc119cf7e1  lea rax, [r14+0xA0]
000074fc119cf7e8  movups xmm1, [r13+rax*1]
000074fc119cf7ee  lea rax, [r14+0xB0]
000074fc119cf7f5  vmovaps [rsp+0x30], xmm1
000074fc119cf7fb  movups xmm1, [r13+rax*1]
000074fc119cf801  vmovaps [rsp+0xF0], xmm1
000074fc119cf80a  vmovaps [rsp+0x120], xmm15
000074fc119cf813  movaps xmm1, xmm13
000074fc119cf817  addpd xmm1, xmm2
000074fc119cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000074fc119cf820  ptest xmm15, xmm15
000074fc119cf826  jnz 0x000074FC119D11ED
000074fc119cf82c  lea rax, [r14+0xF0]
000074fc119cf833  movups xmm15, [r13+rax*1]
000074fc119cf839  vmovaps xmm2, [rsp+0xC0]
000074fc119cf842  vmovaps [rsp+0xC0], xmm1
000074fc119cf84b  vmovaps xmm1, [rsp+0xE0]
000074fc119cf854  vmovaps [rsp+0xE0], xmm15
000074fc119cf85d  movaps xmm13, xmm2
000074fc119cf861  addpd xmm13, xmm1
000074fc119cf866  vcmppd xmm15, xmm13, xmm13, 0x03
000074fc119cf86c  ptest xmm15, xmm15
000074fc119cf872  jnz 0x000074FC119D1338
000074fc119cf878  vmovaps xmm15, [rsp+0x120]
000074fc119cf881  vmovaps xmm2, [rsp+0xD0]
000074fc119cf88a  vmovaps [rsp+0xD0], xmm14
000074fc119cf893  movaps xmm1, xmm15
000074fc119cf897  addpd xmm1, xmm2
000074fc119cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000074fc119cf8a0  ptest xmm14, xmm14
000074fc119cf8a6  jnz 0x000074FC119D147A
000074fc119cf8ac  vmovaps xmm15, [rsp+0x100]
000074fc119cf8b5  vpermilpd xmm15, xmm15, 0x00
000074fc119cf8bb  vmovaps xmm2, [rsp+0xF0]
000074fc119cf8c4  vmovaps [rsp+0xF0], xmm1
000074fc119cf8cd  movaps xmm14, xmm2
000074fc119cf8d1  mulpd xmm14, xmm15
000074fc119cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000074fc119cf8dc  ptest xmm1, xmm1
000074fc119cf8e1  jnz 0x000074FC119D15BB
000074fc119cf8e7  vmovaps xmm1, [rsp+0xA0]
000074fc119cf8f0  vpermilpd xmm1, xmm1, 0x00
000074fc119cf8f6  vmovaps xmm2, [rsp+0xE0]
000074fc119cf8ff  vmovaps [rsp+0xE0], xmm14
000074fc119cf908  movaps xmm15, xmm2
000074fc119cf90c  mulpd xmm15, xmm1
000074fc119cf911  vcmppd xmm14, xmm15, xmm15, 0x03
000074fc119cf917  ptest xmm14, xmm14
000074fc119cf91d  jnz 0x000074FC119D16FE
000074fc119cf923  lea rax, [r14+0xE0]
000074fc119cf92a  movups xmm1, [r13+rax*1]
000074fc119cf930  vmovaps xmm14, [rsp+0x100]
000074fc119cf939  vpermilpd xmm14, xmm14, 0x00
000074fc119cf93f  vmovaps [rsp+0x100], xmm1
000074fc119cf948  vmovaps xmm1, [rsp+0x30]
000074fc119cf94e  vmovaps [rsp+0x30], xmm15
000074fc119cf954  movaps xmm2, xmm1
000074fc119cf957  mulpd xmm2, xmm14
000074fc119cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000074fc119cf961  ptest xmm15, xmm15
000074fc119cf967  jnz 0x000074FC119D184A
000074fc119cf96d  vmovaps [rsp+0x120], xmm10
000074fc119cf976  vmovaps xmm1, [rsp+0x120]
000074fc119cf97f  por xmm10, xmm1
000074fc119cf984  movaps [r15+0x300], xmm10
000074fc119cf98c  vmovaps [rsp+0x120], xmm8
000074fc119cf995  vmovaps xmm1, [rsp+0x120]
000074fc119cf99e  por xmm8, xmm1
000074fc119cf9a3  movaps [r15+0x190], xmm8
000074fc119cf9ab  vmovaps xmm1, [rsp+0xA0]
000074fc119cf9b4  vpermilpd xmm1, xmm1, 0x00
000074fc119cf9ba  vmovaps xmm14, [rsp+0x100]
000074fc119cf9c3  vmovaps [rsp+0x100], xmm13
000074fc119cf9cc  movaps xmm15, xmm14
000074fc119cf9d0  mulpd xmm15, xmm1
000074fc119cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000074fc119cf9db  ptest xmm13, xmm13
000074fc119cf9e1  jnz 0x000074FC119D198B
000074fc119cf9e7  lea rax, [r14+0x90]
000074fc119cf9ee  movups xmm1, [r13+rax*1]
000074fc119cf9f4  vmovaps [rsp+0x120], xmm4
000074fc119cf9fd  vmovaps xmm14, [rsp+0x120]
000074fc119cfa06  por xmm4, xmm14
000074fc119cfa0b  movaps [r15+0x1C0], xmm4
000074fc119cfa13  vmovaps [rsp+0x120], xmm11
000074fc119cfa1c  vmovaps xmm14, [rsp+0x120]
000074fc119cfa25  por xmm11, xmm14
000074fc119cfa2a  movaps [r15+0x200], xmm11
000074fc119cfa32  vmovaps [rsp+0x120], xmm5
000074fc119cfa3b  vmovaps xmm14, [rsp+0x120]
000074fc119cfa44  por xmm5, xmm14
000074fc119cfa49  movaps [r15+0x2D0], xmm5
000074fc119cfa51  vmovaps [rsp+0x120], xmm12
000074fc119cfa5a  vmovaps xmm14, [rsp+0x120]
000074fc119cfa63  por xmm12, xmm14
000074fc119cfa68  movaps [r15+0x2E0], xmm12
000074fc119cfa70  vmovaps xmm13, [rsp+0x110]
000074fc119cfa79  vmovaps [rsp+0x110], xmm1
000074fc119cfa82  vmovaps xmm1, [rsp+0xE0]
000074fc119cfa8b  vmovaps [rsp+0xE0], xmm15
000074fc119cfa94  movaps xmm14, xmm13
000074fc119cfa98  addpd xmm14, xmm1
000074fc119cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000074fc119cfaa3  ptest xmm15, xmm15
000074fc119cfaa9  jnz 0x000074FC119D1AD8
000074fc119cfaaf  vmovaps xmm1, [rsp+0xA0]
000074fc119cfab8  vpermilpd xmm1, xmm1, 0x00
000074fc119cfabe  vmovaps xmm13, [rsp+0x110]
000074fc119cfac7  vmovaps [rsp+0x110], xmm14
000074fc119cfad0  movaps xmm15, xmm13
000074fc119cfad4  mulpd xmm15, xmm1
000074fc119cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000074fc119cfadf  ptest xmm14, xmm14
000074fc119cfae5  jnz 0x000074FC119D1C1B
000074fc119cfaeb  lea rax, [r14+0x80]
000074fc119cfaf2  movups xmm1, [r13+rax*1]
000074fc119cfaf8  vmovaps xmm13, [rsp+0xC0]
000074fc119cfb01  vmovaps [rsp+0xC0], xmm1
000074fc119cfb0a  movaps xmm14, xmm13
000074fc119cfb0e  addpd xmm14, xmm2
000074fc119cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000074fc119cfb19  ptest xmm1, xmm1
000074fc119cfb1e  jnz 0x000074FC119D1D68
000074fc119cfb24  vmovaps xmm13, [rsp+0x100]
000074fc119cfb2d  vmovaps xmm2, [rsp+0x30]
000074fc119cfb33  vmovaps [rsp+0x30], xmm15
000074fc119cfb39  movaps xmm1, xmm13
000074fc119cfb3d  addpd xmm1, xmm2
000074fc119cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000074fc119cfb46  ptest xmm15, xmm15
000074fc119cfb4c  jnz 0x000074FC119D1EAB
000074fc119cfb52  vmovaps xmm15, [rsp+0x20]
000074fc119cfb58  vmovaps xmm13, [rsp+0x20]
000074fc119cfb5e  por xmm15, xmm13
000074fc119cfb63  movaps [r15+0x2F0], xmm15
000074fc119cfb6b  vmovaps xmm13, [rsp+0xA0]
000074fc119cfb74  vpermilpd xmm13, xmm13, 0x00
000074fc119cfb7a  vmovaps [rsp+0x20], xmm1
000074fc119cfb80  vmovaps xmm1, [rsp+0xC0]
000074fc119cfb89  vmovaps [rsp+0xA0], xmm15
000074fc119cfb92  movaps xmm2, xmm1
000074fc119cfb95  mulpd xmm2, xmm13
000074fc119cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000074fc119cfb9f  ptest xmm15, xmm15
000074fc119cfba5  jnz 0x000074FC119D1FEC
000074fc119cfbab  lea rax, [r14+0xD0]
000074fc119cfbb2  movups xmm1, [r13+rax*1]
000074fc119cfbb8  vmovaps xmm13, [rsp+0xF0]
000074fc119cfbc1  vmovaps [rsp+0xC0], xmm1
000074fc119cfbca  vmovaps xmm1, [rsp+0xE0]
000074fc119cfbd3  vmovaps [rsp+0xE0], xmm14
000074fc119cfbdc  movaps xmm15, xmm13
000074fc119cfbe0  addpd xmm15, xmm1
000074fc119cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000074fc119cfbeb  ptest xmm14, xmm14
000074fc119cfbf1  jnz 0x000074FC119D2137
000074fc119cfbf7  vmovaps xmm1, [rsp+0xB0]
000074fc119cfc00  vpermilpd xmm1, xmm1, 0x00
000074fc119cfc06  movaps xmm14, xmm11
000074fc119cfc0a  mulpd xmm14, xmm1
000074fc119cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000074fc119cfc15  ptest xmm13, xmm13
000074fc119cfc1b  jnz 0x000074FC119D227A
000074fc119cfc21  movaps [r15+0x260], xmm14
000074fc119cfc29  vxorps xmm1, xmm1, xmm1
000074fc119cfc2d  vpbroadcastq xmm1, xmm1
000074fc119cfc32  movaps [r15+0x1B0], xmm1
000074fc119cfc3a  vmovaps xmm1, [rsp+0xB0]
000074fc119cfc43  vpermilpd xmm1, xmm1, 0x00
000074fc119cfc49  vmovaps xmm11, [rsp+0xC0]
000074fc119cfc52  vmovaps [rsp+0xC0], xmm15
000074fc119cfc5b  movaps xmm13, xmm11
000074fc119cfc5f  mulpd xmm13, xmm1
000074fc119cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000074fc119cfc6a  ptest xmm15, xmm15
000074fc119cfc70  jnz 0x000074FC119D23BD
000074fc119cfc76  lea rax, [r14+0xC0]
000074fc119cfc7d  movups xmm1, [r13+rax*1]
000074fc119cfc83  vmovaps xmm11, [rsp+0x110]
000074fc119cfc8c  vmovaps [rsp+0xF0], xmm1
000074fc119cfc95  vmovaps xmm1, [rsp+0x30]
000074fc119cfc9b  vmovaps [rsp+0x30], xmm14
000074fc119cfca1  movaps xmm15, xmm11
000074fc119cfca5  addpd xmm15, xmm1
000074fc119cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000074fc119cfcb0  ptest xmm14, xmm14
000074fc119cfcb6  jnz 0x000074FC119D250A
000074fc119cfcbc  vmovaps [rsp+0x100], xmm9
000074fc119cfcc5  vmovaps xmm1, [rsp+0x100]
000074fc119cfcce  por xmm9, xmm1
000074fc119cfcd3  movaps [r15+0x270], xmm9
000074fc119cfcdb  vmovaps [rsp+0x100], xmm6
000074fc119cfce4  vmovaps xmm1, [rsp+0x100]
000074fc119cfced  por xmm6, xmm1
000074fc119cfcf1  movaps [r15+0x1A0], xmm6
000074fc119cfcf9  vmovaps xmm14, [rsp+0xB0]
000074fc119cfd02  vpermilpd xmm14, xmm14, 0x00
000074fc119cfd08  vmovaps xmm6, [rsp+0xF0]
000074fc119cfd11  vmovaps [rsp+0xF0], xmm1
000074fc119cfd1a  movaps xmm11, xmm6
000074fc119cfd1e  mulpd xmm11, xmm14
000074fc119cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000074fc119cfd29  ptest xmm1, xmm1
000074fc119cfd2e  jnz 0x000074FC119D264D
000074fc119cfd34  lea rax, [r14+0x20]
000074fc119cfd38  movups xmm1, [r13+rax*1]
000074fc119cfd3e  movaps [r15+0x110], xmm1
000074fc119cfd46  vmovaps xmm6, [rsp+0xE0]
000074fc119cfd4f  vmovaps [rsp+0xE0], xmm1
000074fc119cfd58  movaps xmm14, xmm6
000074fc119cfd5c  addpd xmm14, xmm2
000074fc119cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000074fc119cfd67  ptest xmm1, xmm1
000074fc119cfd6c  jnz 0x000074FC119D279A
000074fc119cfd72  vmovaps xmm1, [rsp+0xB0]
000074fc119cfd7b  vpermilpd xmm1, xmm1, 0x00
000074fc119cfd81  movaps xmm6, xmm5
000074fc119cfd84  mulpd xmm6, xmm1
000074fc119cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000074fc119cfd8d  ptest xmm2, xmm2
000074fc119cfd92  jnz 0x000074FC119D28DC
000074fc119cfd98  vmovaps xmm5, [rsp+0x20]
000074fc119cfd9e  movaps xmm1, xmm5
000074fc119cfda1  addpd xmm1, xmm13
000074fc119cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000074fc119cfdab  ptest xmm2, xmm2
000074fc119cfdb0  jnz 0x000074FC119D2A1C
000074fc119cfdb6  vmovaps xmm13, [rsp+0x80]
000074fc119cfdbf  vpermilpd xmm13, xmm13, 0x00
000074fc119cfdc5  vmovaps xmm2, [rsp+0xE0]
000074fc119cfdce  vmovaps [rsp+0x20], xmm1
000074fc119cfdd4  movaps xmm5, xmm2
000074fc119cfdd7  mulpd xmm5, xmm13
000074fc119cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000074fc119cfde1  ptest xmm1, xmm1
000074fc119cfde6  jnz 0x000074FC119D2B5D
000074fc119cfdec  vmovaps xmm1, [rsp+0x80]
000074fc119cfdf5  vpermilpd xmm1, xmm1, 0x00
000074fc119cfdfb  movaps xmm13, xmm10
000074fc119cfdff  mulpd xmm13, xmm1
000074fc119cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000074fc119cfe0a  ptest xmm2, xmm2
000074fc119cfe0f  jnz 0x000074FC119D2C9E
000074fc119cfe15  vmovaps xmm10, [rsp+0x30]
000074fc119cfe1b  movaps xmm1, xmm15
000074fc119cfe1f  addpd xmm1, xmm10
000074fc119cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000074fc119cfe29  ptest xmm2, xmm2
000074fc119cfe2e  jnz 0x000074FC119D2DE1
000074fc119cfe34  vmovaps xmm10, [rsp+0xC0]
000074fc119cfe3d  movaps xmm15, xmm10
000074fc119cfe41  addpd xmm15, xmm11
000074fc119cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000074fc119cfe4c  ptest xmm2, xmm2
000074fc119cfe51  jnz 0x000074FC119D2F23
000074fc119cfe57  vmovaps xmm11, [rsp+0x80]
000074fc119cfe60  vpermilpd xmm11, xmm11, 0x00
000074fc119cfe66  movaps xmm10, xmm12
000074fc119cfe6a  mulpd xmm10, xmm11
000074fc119cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000074fc119cfe75  ptest xmm2, xmm2
000074fc119cfe7a  jnz 0x000074FC119D3067
000074fc119cfe80  vmovaps xmm12, [rsp+0x80]
000074fc119cfe89  vpermilpd xmm12, xmm12, 0x00
000074fc119cfe8f  vmovaps xmm2, [rsp+0xA0]
000074fc119cfe98  vmovaps [rsp+0x30], xmm1
000074fc119cfe9e  movaps xmm11, xmm2
000074fc119cfea2  mulpd xmm11, xmm12
000074fc119cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000074fc119cfead  ptest xmm1, xmm1
000074fc119cfeb2  jnz 0x000074FC119D31AB
000074fc119cfeb8  movaps xmm1, xmm14
000074fc119cfebc  addpd xmm1, xmm6
000074fc119cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000074fc119cfec5  ptest xmm12, xmm12
000074fc119cfecb  jnz 0x000074FC119D32EE
000074fc119cfed1  vmovaps xmm12, [rsp+0x20]
000074fc119cfed7  movaps xmm14, xmm12
000074fc119cfedb  addpd xmm14, xmm5
000074fc119cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000074fc119cfee6  ptest xmm6, xmm6
000074fc119cfeeb  jnz 0x000074FC119D342F
000074fc119cfef1  vmovaps xmm12, [rsp+0x90]
000074fc119cfefa  vpermilpd xmm12, xmm12, 0x00
000074fc119cff00  movaps xmm6, xmm9
000074fc119cff04  mulpd xmm6, xmm12
000074fc119cff09  vcmppd xmm5, xmm6, xmm6, 0x03
000074fc119cff0e  ptest xmm5, xmm5
000074fc119cff13  jnz 0x000074FC119D3572
000074fc119cff19  movaps xmm12, xmm15
000074fc119cff1d  addpd xmm12, xmm13
000074fc119cff22  vcmppd xmm9, xmm12, xmm12, 0x03
000074fc119cff28  ptest xmm9, xmm9
000074fc119cff2e  jnz 0x000074FC119D36B4
000074fc119cff34  vmovaps xmm13, [rsp+0x30]
000074fc119cff3a  movaps xmm15, xmm13
000074fc119cff3e  addpd xmm15, xmm10
000074fc119cff43  vcmppd xmm9, xmm15, xmm15, 0x03
000074fc119cff49  ptest xmm9, xmm9
000074fc119cff4f  jnz 0x000074FC119D37F8
000074fc119cff55  vmovaps xmm13, [rsp+0xD0]
000074fc119cff5e  vmovaps xmm10, [rsp+0xD0]
000074fc119cff67  por xmm13, xmm10
000074fc119cff6c  movaps [r15+0x250], xmm13
000074fc119cff74  vmovaps [rsp+0x20], xmm7
000074fc119cff7a  vmovaps xmm13, [rsp+0x20]
000074fc119cff80  por xmm7, xmm13
000074fc119cff85  movaps [r15+0x2A0], xmm7
000074fc119cff8d  vmovaps [rsp+0x20], xmm3
000074fc119cff93  vmovaps xmm13, [rsp+0x20]
000074fc119cff99  por xmm3, xmm13
000074fc119cff9e  movaps [r15+0x1D0], xmm3
000074fc119cffa6  lea rax, [r14+0x40]
000074fc119cffaa  movups xmm13, [r13+rax*1]
000074fc119cffb0  movaps [r15+0x2C0], xmm13
000074fc119cffb8  vmovaps xmm10, [rsp+0x90]
000074fc119cffc1  vpermilpd xmm10, xmm10, 0x00
000074fc119cffc7  movaps xmm9, xmm8
000074fc119cffcb  mulpd xmm9, xmm10
000074fc119cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000074fc119cffd6  ptest xmm5, xmm5
000074fc119cffdb  jnz 0x000074FC119D3946
000074fc119cffe1  movaps xmm10, xmm1
000074fc119cffe5  addpd xmm10, xmm11
000074fc119cffea  vcmppd xmm8, xmm10, xmm10, 0x03
000074fc119cfff0  ptest xmm8, xmm8
000074fc119cfff6  jnz 0x000074FC119D3A8A
000074fc119cfffc  movaps xmm1, xmm14
000074fc119d0000  addpd xmm1, xmm6
000074fc119d0004  vcmppd xmm11, xmm1, xmm1, 0x03
000074fc119d0009  ptest xmm11, xmm11
000074fc119d000f  jnz 0x000074FC119D3BCD
000074fc119d0015  vmovaps xmm14, [rsp+0x90]
000074fc119d001e  vpermilpd xmm14, xmm14, 0x00
000074fc119d0024  movaps xmm11, xmm13
000074fc119d0028  mulpd xmm11, xmm14
000074fc119d002d  vcmppd xmm8, xmm11, xmm11, 0x03
000074fc119d0033  ptest xmm8, xmm8
000074fc119d0039  jnz 0x000074FC119D3D0E
000074fc119d003f  vmovaps xmm14, [rsp+0x90]
000074fc119d0048  vpermilpd xmm14, xmm14, 0x00
000074fc119d004e  vmovaps xmm8, [rsp+0x10]
000074fc119d0054  movaps xmm13, xmm8
000074fc119d0058  mulpd xmm13, xmm14
000074fc119d005d  vcmppd xmm6, xmm13, xmm13, 0x03
000074fc119d0063  ptest xmm6, xmm6
000074fc119d0068  jnz 0x000074FC119D3E52
000074fc119d006e  vmovaps xmm14, [rsp+0x60]
000074fc119d0074  vpermilpd xmm14, xmm14, 0x00
000074fc119d007a  movaps xmm8, xmm7
000074fc119d007e  mulpd xmm8, xmm14
000074fc119d0083  vcmppd xmm6, xmm8, xmm8, 0x03
000074fc119d0089  ptest xmm6, xmm6
000074fc119d008e  jnz 0x000074FC119D3F96
000074fc119d0094  movaps xmm14, xmm12
000074fc119d0098  addpd xmm14, xmm9
000074fc119d009d  vcmppd xmm7, xmm14, xmm14, 0x03
000074fc119d00a3  ptest xmm7, xmm7
000074fc119d00a8  jnz 0x000074FC119D40D9
000074fc119d00ae  vmovaps xmm12, [rsp+0x60]
000074fc119d00b4  vpermilpd xmm12, xmm12, 0x00
000074fc119d00ba  vmovaps xmm7, [rsp+0xF0]
000074fc119d00c3  movaps xmm9, xmm7
000074fc119d00c7  mulpd xmm9, xmm12
000074fc119d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000074fc119d00d2  ptest xmm6, xmm6
000074fc119d00d7  jnz 0x000074FC119D421D
000074fc119d00dd  movaps xmm12, xmm15
000074fc119d00e1  addpd xmm12, xmm11
000074fc119d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000074fc119d00ec  ptest xmm7, xmm7
000074fc119d00f1  jnz 0x000074FC119D4360
000074fc119d00f7  vmovaps xmm15, [rsp+0x60]
000074fc119d00fd  vpermilpd xmm15, xmm15, 0x00
000074fc119d0103  vmovaps xmm7, [rsp+0x40]
000074fc119d0109  movaps xmm11, xmm7
000074fc119d010d  mulpd xmm11, xmm15
000074fc119d0112  vcmppd xmm6, xmm11, xmm11, 0x03
000074fc119d0118  ptest xmm6, xmm6
000074fc119d011d  jnz 0x000074FC119D44A4
000074fc119d0123  movaps xmm15, xmm10
000074fc119d0127  addpd xmm15, xmm13
000074fc119d012c  vcmppd xmm7, xmm15, xmm15, 0x03
000074fc119d0132  ptest xmm7, xmm7
000074fc119d0137  jnz 0x000074FC119D45E7
000074fc119d013d  vmovaps xmm13, [rsp+0x60]
000074fc119d0143  vpermilpd xmm13, xmm13, 0x00
000074fc119d0149  vmovaps xmm7, [rsp+0x50]
000074fc119d014f  movaps xmm10, xmm7
000074fc119d0153  mulpd xmm10, xmm13
000074fc119d0158  vcmppd xmm6, xmm10, xmm10, 0x03
000074fc119d015e  ptest xmm6, xmm6
000074fc119d0163  jnz 0x000074FC119D472B
000074fc119d0169  movaps xmm13, xmm1
000074fc119d016d  addpd xmm13, xmm8
000074fc119d0172  vcmppd xmm7, xmm13, xmm13, 0x03
000074fc119d0178  ptest xmm7, xmm7
000074fc119d017d  jnz 0x000074FC119D486E
000074fc119d0183  lea rax, [r14+0x70]
000074fc119d0187  movups xmm1, [r13+rax*1]
000074fc119d018d  movaps [r15+0x240], xmm1
000074fc119d0195  movaps xmm8, xmm14
000074fc119d0199  addpd xmm8, xmm9
000074fc119d019e  vcmppd xmm7, xmm8, xmm8, 0x03
000074fc119d01a4  ptest xmm7, xmm7
000074fc119d01a9  jnz 0x000074FC119D49BB
000074fc119d01af  movaps [r15+0x170], xmm8
000074fc119d01b7  vmovaps xmm14, [rsp+0x70]
000074fc119d01bd  vpermilpd xmm14, xmm14, 0x00
000074fc119d01c3  movaps xmm9, xmm1
000074fc119d01c7  mulpd xmm9, xmm14
000074fc119d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000074fc119d01d2  ptest xmm7, xmm7
000074fc119d01d7  jnz 0x000074FC119D4AFF
000074fc119d01dd  vmovaps xmm1, [rsp+0x70]
000074fc119d01e3  vpermilpd xmm1, xmm1, 0x00
000074fc119d01e9  movaps xmm14, xmm4
000074fc119d01ed  mulpd xmm14, xmm1
000074fc119d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000074fc119d01f8  ptest xmm7, xmm7
000074fc119d01fd  jnz 0x000074FC119D4C42
000074fc119d0203  movaps [r15+0x180], xmm14
000074fc119d020b  movaps xmm1, xmm12
000074fc119d020f  addpd xmm1, xmm11
000074fc119d0214  vcmppd xmm7, xmm1, xmm1, 0x03
000074fc119d0219  ptest xmm7, xmm7
000074fc119d021e  jnz 0x000074FC119D4D84
000074fc119d0224  movaps [r15+0x210], xmm1
000074fc119d022c  movups xmm12, [r13+r14*1]
000074fc119d0232  lea rax, [r14+0x10]
000074fc119d0236  movups xmm11, [r13+rax*1]
000074fc119d023c  movaps [r15+0x230], xmm11
000074fc119d0244  movaps xmm7, xmm15
000074fc119d0248  addpd xmm7, xmm10
000074fc119d024d  vcmppd xmm6, xmm7, xmm7, 0x03
000074fc119d0252  ptest xmm6, xmm6
000074fc119d0257  jnz 0x000074FC119D4EDA
000074fc119d025d  movaps [r15+0x130], xmm7
000074fc119d0265  vmovaps xmm15, [rsp+0x70]
000074fc119d026b  vpermilpd xmm15, xmm15, 0x00
000074fc119d0271  movaps xmm10, xmm11
000074fc119d0275  mulpd xmm10, xmm15
000074fc119d027a  vcmppd xmm6, xmm10, xmm10, 0x03
000074fc119d0280  ptest xmm6, xmm6
000074fc119d0285  jnz 0x000074FC119D501C
000074fc119d028b  movaps [r15+0x220], xmm10
000074fc119d0293  vmovaps xmm15, [rsp+0x70]
000074fc119d0299  vpermilpd xmm15, xmm15, 0x00
000074fc119d029f  movaps xmm11, xmm12
000074fc119d02a3  mulpd xmm11, xmm15
000074fc119d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000074fc119d02ae  ptest xmm6, xmm6
000074fc119d02b3  jnz 0x000074FC119D5160
000074fc119d02b9  movaps xmm15, xmm13
000074fc119d02bd  addpd xmm15, xmm9
000074fc119d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000074fc119d02c8  ptest xmm12, xmm12
000074fc119d02ce  jnz 0x000074FC119D52A4
000074fc119d02d4  movaps [r15+0x140], xmm15
000074fc119d02dc  movaps xmm13, xmm8
000074fc119d02e0  addpd xmm13, xmm14
000074fc119d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000074fc119d02eb  ptest xmm12, xmm12
000074fc119d02f1  jnz 0x000074FC119D53E8
000074fc119d02f7  movaps [r15+0x150], xmm13
000074fc119d02ff  movaps xmm14, xmm1
000074fc119d0303  addpd xmm14, xmm10
000074fc119d0308  vcmppd xmm12, xmm14, xmm14, 0x03
000074fc119d030e  ptest xmm12, xmm12
000074fc119d0314  jnz 0x000074FC119D552C
000074fc119d031a  movaps [r15+0x160], xmm14
000074fc119d0322  movaps xmm1, xmm7
000074fc119d0325  addpd xmm1, xmm11
000074fc119d032a  vcmppd xmm12, xmm1, xmm1, 0x03
000074fc119d032f  ptest xmm12, xmm12
000074fc119d0335  jnz 0x000074FC119D566F
000074fc119d033b  movaps [r15+0x120], xmm1
000074fc119d0343  mov eax, 0x430920
000074fc119d0348  movups [r13+rax*1], xmm15
000074fc119d034e  mov eax, 0x430930
000074fc119d0353  movups [r13+rax*1], xmm13
000074fc119d0359  mov eax, 0x430940
000074fc119d035e  movups [r13+rax*1], xmm14
000074fc119d0364  mov eax, 0x430950
000074fc119d0369  movups [r13+rax*1], xmm1
000074fc119d036f  mov eax, [r15+0x108]
000074fc119d0376  sahf
000074fc119d0377  jnz 0x000074FC119D03A9
000074fc119d0379  cmp dword ptr [r15+0x318], 0x00
000074fc119d0381  jz 0x000074FC119DB900
000074fc119d0387  nop [rax+rax*1], ax
000074fc119d0390  nop [rax+rax*1], eax
000074fc119d0398  mov eax, 0x410444
000074fc119d039d  mov [r15+0x100], rax
000074fc119d03a4  jmp 0x000074FC117FE110
000074fc119d03a9  cmp dword ptr [r15+0x318], 0x00
000074fc119d03b1  jz 0x000074FC119D57E0
000074fc119d03b7  nop [rax+rax*1], ax
000074fc119d03c0  nop [rax+rax*1], eax
000074fc119d03c8  mov eax, 0x410278
000074fc119d03cd  mov [r15+0x100], rax
000074fc119d03d4  jmp 0x000074FC117FE110
000074fc119d03d9  int3
000074fc119d03da  call 0x000074FC118B52F0
000074fc119d03df  jmp 0x000074FC119CF016
000074fc119d03e4  call 0x000074FC118C4620
000074fc119d03e9  jmp 0x000074FC119CF023
000074fc119d03ee  call 0x000074FC118C33A0
000074fc119d03f3  jmp 0x000074FC119CF035
000074fc119d03f8  call 0x000074FC118C2120
000074fc119d03fd  jmp 0x000074FC119CF03F
000074fc119d0402  call 0x000074FC118C0860
000074fc119d0407  jmp 0x000074FC119CF067
000074fc119d040c  call 0x000074FC118BF5F0
000074fc119d0411  jmp 0x000074FC119CF073
000074fc119d0416  call 0x000074FC118C0860
000074fc119d041b  jmp 0x000074FC119CF0A5
000074fc119d0420  call 0x000074FC118BF5F0
000074fc119d0425  jmp 0x000074FC119CF0B1
000074fc119d042a  call 0x000074FC118C4740
000074fc119d042f  jmp 0x000074FC119CF0BE
000074fc119d0434  call 0x000074FC118B5400
000074fc119d0439  jmp 0x000074FC119CF0CB
000074fc119d043e  call 0x000074FC118B52F0
000074fc119d0443  jmp 0x000074FC119CF0D8
000074fc119d0448  call 0x000074FC118C4620
000074fc119d044d  jmp 0x000074FC119CF0E5
000074fc119d0452  call 0x000074FC118C0860
000074fc119d0457  jmp 0x000074FC119CF10D
000074fc119d045c  call 0x000074FC118BF5F0
000074fc119d0461  jmp 0x000074FC119CF119
000074fc119d0466  call 0x000074FC11809D70
000074fc119d046b  jmp 0x000074FC119CF11F
000074fc119d0470  call 0x000074FC118BE9C0
000074fc119d0475  jmp 0x000074FC119CF129
000074fc119d047a  call 0x000074FC118C0860
000074fc119d047f  jmp 0x000074FC119CF151
000074fc119d0484  call 0x000074FC118BF5F0
000074fc119d0489  jmp 0x000074FC119CF15D
000074fc119d048e  call 0x000074FC118BD750
000074fc119d0493  jmp 0x000074FC119CF16A
000074fc119d0498  call 0x000074FC118BC4E0
000074fc119d049d  jmp 0x000074FC119CF177
000074fc119d04a2  call 0x000074FC118C4740
000074fc119d04a7  jmp 0x000074FC119CF184
000074fc119d04ac  call 0x000074FC118B5400
000074fc119d04b1  jmp 0x000074FC119CF191
000074fc119d04b6  call 0x000074FC118B52F0
000074fc119d04bb  jmp 0x000074FC119CF19E
000074fc119d04c0  call 0x000074FC118C4620
000074fc119d04c5  jmp 0x000074FC119CF1AB
000074fc119d04ca  call 0x000074FC118C0860
000074fc119d04cf  jmp 0x000074FC119CF1BE
000074fc119d04d4  call 0x000074FC118BB270
000074fc119d04d9  jmp 0x000074FC119CF1CB
000074fc119d04de  call 0x000074FC118BA000
000074fc119d04e3  jmp 0x000074FC119CF1D8
000074fc119d04e8  call 0x000074FC118B8D90
000074fc119d04ed  jmp 0x000074FC119CF1E5
000074fc119d04f2  call 0x000074FC118B8A20
000074fc119d04f7  jmp 0x000074FC119CF1F2
000074fc119d04fc  call 0x000074FC118B5400
000074fc119d0501  jmp 0x000074FC119CF1FC
000074fc119d0506  call 0x000074FC118C2240
000074fc119d050b  jmp 0x000074FC119CF206
000074fc119d0510  call 0x000074FC118B52F0
000074fc119d0515  jmp 0x000074FC119CF210
000074fc119d051a  call 0x000074FC118C2120
000074fc119d051f  jmp 0x000074FC119CF21A
000074fc119d0524  call 0x000074FC118B77B0
000074fc119d0529  jmp 0x000074FC119CF224
000074fc119d052e  call 0x000074FC118B6550
000074fc119d0533  jmp 0x000074FC119CF22E
000074fc119d0538  call 0x000074FC118BFD50
000074fc119d053d  jmp 0x000074FC119CF240
000074fc119d0542  call 0x000074FC118B8EA0
000074fc119d0547  jmp 0x000074FC119CF24A
000074fc119d054c  call 0x000074FC118BFC30
000074fc119d0551  jmp 0x000074FC119CF257
000074fc119d0556  call 0x000074FC118B8D90
000074fc119d055b  jmp 0x000074FC119CF264
000074fc119d0560  call 0x000074FC118C2240
000074fc119d0565  jmp 0x000074FC119CF271
000074fc119d056a  call 0x000074FC118B5400
000074fc119d056f  jmp 0x000074FC119CF27E
000074fc119d0574  call 0x000074FC118B52F0
000074fc119d0579  jmp 0x000074FC119CF28B
000074fc119d057e  call 0x000074FC118C2120
000074fc119d0583  jmp 0x000074FC119CF298
000074fc119d0588  call 0x000074FC118B52F0
000074fc119d058d  jmp 0x000074FC119CF2AB
000074fc119d0592  call 0x000074FC118B52F0
000074fc119d0597  jmp 0x000074FC119CF2BE
000074fc119d059c  call 0x000074FC118B52F0
000074fc119d05a1  jmp 0x000074FC119CF2D1
000074fc119d05a6  call 0x000074FC118B52F0
000074fc119d05ab  jmp 0x000074FC119CF2E4
000074fc119d05b0  call 0x000074FC118C2240
000074fc119d05b5  jmp 0x000074FC119CF2F9
000074fc119d05ba  call 0x000074FC118C2240
000074fc119d05bf  jmp 0x000074FC119CF30C
000074fc119d05c4  call 0x000074FC118C2120
000074fc119d05c9  jmp 0x000074FC119CF319
000074fc119d05ce  call 0x000074FC118B52F0
000074fc119d05d3  jmp 0x000074FC119CF32C
000074fc119d05d8  call 0x000074FC118B52F0
000074fc119d05dd  jmp 0x000074FC119CF34F
000074fc119d05e2  call 0x000074FC118B52F0
000074fc119d05e7  jmp 0x000074FC119CF362
000074fc119d05ec  call 0x000074FC117FF540
000074fc119d05f1  jmp 0x000074FC119CF380
000074fc119d05f6  call 0x000074FC11808C20
000074fc119d05fb  jmp 0x000074FC119CF38A
000074fc119d0600  call 0x000074FC118D6600
000074fc119d0605  jmp 0x000074FC119CF396
000074fc119d060a  call 0x000074FC117FF540
000074fc119d060f  jmp 0x000074FC119CF3A6
000074fc119d0614  call 0x000074FC118C0370
000074fc119d0619  jmp 0x000074FC119CF3D4
000074fc119d061e  call 0x000074FC118BF100
000074fc119d0623  jmp 0x000074FC119CF3DD
000074fc119d0628  call 0x000074FC118C0370
000074fc119d062d  jmp 0x000074FC119CF43B
000074fc119d0632  call 0x000074FC118BF100
000074fc119d0637  jmp 0x000074FC119CF444
000074fc119d063c  call 0x000074FC118C0370
000074fc119d0641  jmp 0x000074FC119CF48B
000074fc119d0646  call 0x000074FC118BF100
000074fc119d064b  jmp 0x000074FC119CF494
000074fc119d0650  call 0x000074FC1180B720
000074fc119d0655  jmp 0x000074FC119CF4D7
000074fc119d065a  call 0x000074FC118B47C0
000074fc119d065f  jmp 0x000074FC119CF4EA
000074fc119d0664  call 0x000074FC11808B00
000074fc119d0669  jmp 0x000074FC119CF501
000074fc119d066e  call 0x000074FC117FF430
000074fc119d0673  jmp 0x000074FC119CF514
000074fc119d0678  call 0x000074FC117FF430
000074fc119d067d  jmp 0x000074FC119CF527
000074fc119d0682  sub rsp, 0x08
000074fc119d0686  push rax
000074fc119d0687  push rcx
000074fc119d0688  push rdx
000074fc119d0689  push rdi
000074fc119d068a  push rsi
000074fc119d068b  push r8
000074fc119d068d  push r9
000074fc119d068f  push r10
000074fc119d0691  push r11
000074fc119d0693  sub rsp, 0xF0
000074fc119d069a  vmovaps [rsp], xmm0
000074fc119d069f  vmovaps [rsp+0x10], xmm2
000074fc119d06a5  vmovaps [rsp+0x20], xmm3
000074fc119d06ab  vmovaps [rsp+0x30], xmm4
000074fc119d06b1  vmovaps [rsp+0x40], xmm5
000074fc119d06b7  vmovaps [rsp+0x50], xmm6
000074fc119d06bd  vmovaps [rsp+0x60], xmm7
000074fc119d06c3  vmovaps [rsp+0x70], xmm8
000074fc119d06c9  vmovaps [rsp+0x80], xmm9
000074fc119d06d2  vmovaps [rsp+0x90], xmm10
000074fc119d06db  vmovaps [rsp+0xA0], xmm11
000074fc119d06e4  vmovaps [rsp+0xB0], xmm12
000074fc119d06ed  vmovaps [rsp+0xC0], xmm13
000074fc119d06f6  vmovaps [rsp+0xD0], xmm14
000074fc119d06ff  vmovaps [rsp+0xE0], xmm15
000074fc119d0708  sub rsp, 0x30
000074fc119d070c  movaps [rsp], xmm1
000074fc119d0710  movaps [rsp+0x10], xmm15
000074fc119d0716  movaps [rsp+0x20], xmm14
000074fc119d071c  lea rdi, [rsp]
000074fc119d0720  mov esi, 0x00
000074fc119d0725  mov rax, 0x58C4C8091530
000074fc119d072f  call rax
000074fc119d0731  movaps xmm1, [rsp]
000074fc119d0735  add rsp, 0x30
000074fc119d0739  vmovaps xmm0, [rsp]
000074fc119d073e  vmovaps xmm2, [rsp+0x10]
000074fc119d0744  vmovaps xmm3, [rsp+0x20]
000074fc119d074a  vmovaps xmm4, [rsp+0x30]
000074fc119d0750  vmovaps xmm5, [rsp+0x40]
000074fc119d0756  vmovaps xmm6, [rsp+0x50]
000074fc119d075c  vmovaps xmm7, [rsp+0x60]
000074fc119d0762  vmovaps xmm8, [rsp+0x70]
000074fc119d0768  vmovaps xmm9, [rsp+0x80]
000074fc119d0771  vmovaps xmm10, [rsp+0x90]
000074fc119d077a  vmovaps xmm11, [rsp+0xA0]
000074fc119d0783  vmovaps xmm12, [rsp+0xB0]
000074fc119d078c  vmovaps xmm13, [rsp+0xC0]
000074fc119d0795  vmovaps xmm14, [rsp+0xD0]
000074fc119d079e  vmovaps xmm15, [rsp+0xE0]
000074fc119d07a7  add rsp, 0xF0
000074fc119d07ae  pop r11
000074fc119d07b0  pop r10
000074fc119d07b2  pop r9
000074fc119d07b4  pop r8
000074fc119d07b6  pop rsi
000074fc119d07b7  pop rdi
000074fc119d07b8  pop rdx
000074fc119d07b9  pop rcx
000074fc119d07ba  pop rax
000074fc119d07bb  add rsp, 0x08
000074fc119d07bf  jmp 0x000074FC119CF581
000074fc119d07c4  sub rsp, 0x08
000074fc119d07c8  push rax
000074fc119d07c9  push rcx
000074fc119d07ca  push rdx
000074fc119d07cb  push rdi
000074fc119d07cc  push rsi
000074fc119d07cd  push r8
000074fc119d07cf  push r9
000074fc119d07d1  push r10
000074fc119d07d3  push r11
000074fc119d07d5  sub rsp, 0xF0
000074fc119d07dc  vmovaps [rsp], xmm0
000074fc119d07e1  vmovaps [rsp+0x10], xmm1
000074fc119d07e7  vmovaps [rsp+0x20], xmm2
000074fc119d07ed  vmovaps [rsp+0x30], xmm3
000074fc119d07f3  vmovaps [rsp+0x40], xmm4
000074fc119d07f9  vmovaps [rsp+0x50], xmm5
000074fc119d07ff  vmovaps [rsp+0x60], xmm6
000074fc119d0805  vmovaps [rsp+0x70], xmm7
000074fc119d080b  vmovaps [rsp+0x80], xmm8
000074fc119d0814  vmovaps [rsp+0x90], xmm9
000074fc119d081d  vmovaps [rsp+0xA0], xmm10
000074fc119d0826  vmovaps [rsp+0xB0], xmm11
000074fc119d082f  vmovaps [rsp+0xC0], xmm12
000074fc119d0838  vmovaps [rsp+0xD0], xmm14
000074fc119d0841  vmovaps [rsp+0xE0], xmm15
000074fc119d084a  sub rsp, 0x30
000074fc119d084e  movaps [rsp], xmm13
000074fc119d0853  movaps [rsp+0x10], xmm1
000074fc119d0858  movaps [rsp+0x20], xmm14
000074fc119d085e  lea rdi, [rsp]
000074fc119d0862  mov esi, 0x00
000074fc119d0867  mov rax, 0x58C4C8091530
000074fc119d0871  call rax
000074fc119d0873  movaps xmm13, [rsp]
000074fc119d0878  add rsp, 0x30
000074fc119d087c  vmovaps xmm0, [rsp]
000074fc119d0881  vmovaps xmm1, [rsp+0x10]
000074fc119d0887  vmovaps xmm2, [rsp+0x20]
000074fc119d088d  vmovaps xmm3, [rsp+0x30]
000074fc119d0893  vmovaps xmm4, [rsp+0x40]
000074fc119d0899  vmovaps xmm5, [rsp+0x50]
000074fc119d089f  vmovaps xmm6, [rsp+0x60]
000074fc119d08a5  vmovaps xmm7, [rsp+0x70]
000074fc119d08ab  vmovaps xmm8, [rsp+0x80]
000074fc119d08b4  vmovaps xmm9, [rsp+0x90]
000074fc119d08bd  vmovaps xmm10, [rsp+0xA0]
000074fc119d08c6  vmovaps xmm11, [rsp+0xB0]
000074fc119d08cf  vmovaps xmm12, [rsp+0xC0]
000074fc119d08d8  vmovaps xmm14, [rsp+0xD0]
000074fc119d08e1  vmovaps xmm15, [rsp+0xE0]
000074fc119d08ea  add rsp, 0xF0
000074fc119d08f1  pop r11
000074fc119d08f3  pop r10
000074fc119d08f5  pop r9
000074fc119d08f7  pop r8
000074fc119d08f9  pop rsi
000074fc119d08fa  pop rdi
000074fc119d08fb  pop rdx
000074fc119d08fc  pop rcx
000074fc119d08fd  pop rax
000074fc119d08fe  add rsp, 0x08
000074fc119d0902  jmp 0x000074FC119CF5CF
000074fc119d0907  sub rsp, 0x08
000074fc119d090b  push rax
000074fc119d090c  push rcx
000074fc119d090d  push rdx
000074fc119d090e  push rdi
000074fc119d090f  push rsi
000074fc119d0910  push r8
000074fc119d0912  push r9
000074fc119d0914  push r10
000074fc119d0916  push r11
000074fc119d0918  sub rsp, 0xF0
000074fc119d091f  vmovaps [rsp], xmm0
000074fc119d0924  vmovaps [rsp+0x10], xmm1
000074fc119d092a  vmovaps [rsp+0x20], xmm2
000074fc119d0930  vmovaps [rsp+0x30], xmm3
000074fc119d0936  vmovaps [rsp+0x40], xmm4
000074fc119d093c  vmovaps [rsp+0x50], xmm5
000074fc119d0942  vmovaps [rsp+0x60], xmm6
000074fc119d0948  vmovaps [rsp+0x70], xmm7
000074fc119d094e  vmovaps [rsp+0x80], xmm8
000074fc119d0957  vmovaps [rsp+0x90], xmm9
000074fc119d0960  vmovaps [rsp+0xA0], xmm10
000074fc119d0969  vmovaps [rsp+0xB0], xmm11
000074fc119d0972  vmovaps [rsp+0xC0], xmm12
000074fc119d097b  vmovaps [rsp+0xD0], xmm13
000074fc119d0984  vmovaps [rsp+0xE0], xmm14
000074fc119d098d  sub rsp, 0x30
000074fc119d0991  movaps [rsp], xmm15
000074fc119d0996  movaps [rsp+0x10], xmm14
000074fc119d099c  movaps [rsp+0x20], xmm1
000074fc119d09a1  lea rdi, [rsp]
000074fc119d09a5  mov esi, 0x00
000074fc119d09aa  mov rax, 0x58C4C8091530
000074fc119d09b4  call rax
000074fc119d09b6  movaps xmm15, [rsp]
000074fc119d09bb  add rsp, 0x30
000074fc119d09bf  vmovaps xmm0, [rsp]
000074fc119d09c4  vmovaps xmm1, [rsp+0x10]
000074fc119d09ca  vmovaps xmm2, [rsp+0x20]
000074fc119d09d0  vmovaps xmm3, [rsp+0x30]
000074fc119d09d6  vmovaps xmm4, [rsp+0x40]
000074fc119d09dc  vmovaps xmm5, [rsp+0x50]
000074fc119d09e2  vmovaps xmm6, [rsp+0x60]
000074fc119d09e8  vmovaps xmm7, [rsp+0x70]
000074fc119d09ee  vmovaps xmm8, [rsp+0x80]
000074fc119d09f7  vmovaps xmm9, [rsp+0x90]
000074fc119d0a00  vmovaps xmm10, [rsp+0xA0]
000074fc119d0a09  vmovaps xmm11, [rsp+0xB0]
000074fc119d0a12  vmovaps xmm12, [rsp+0xC0]
000074fc119d0a1b  vmovaps xmm13, [rsp+0xD0]
000074fc119d0a24  vmovaps xmm14, [rsp+0xE0]
000074fc119d0a2d  add rsp, 0xF0
000074fc119d0a34  pop r11
000074fc119d0a36  pop r10
000074fc119d0a38  pop r9
000074fc119d0a3a  pop r8
000074fc119d0a3c  pop rsi
000074fc119d0a3d  pop rdi
000074fc119d0a3e  pop rdx
000074fc119d0a3f  pop rcx
000074fc119d0a40  pop rax
000074fc119d0a41  add rsp, 0x08
000074fc119d0a45  jmp 0x000074FC119CF617
000074fc119d0a4a  sub rsp, 0x08
000074fc119d0a4e  push rax
000074fc119d0a4f  push rcx
000074fc119d0a50  push rdx
000074fc119d0a51  push rdi
000074fc119d0a52  push rsi
000074fc119d0a53  push r8
000074fc119d0a55  push r9
000074fc119d0a57  push r10
000074fc119d0a59  push r11
000074fc119d0a5b  sub rsp, 0xF0
000074fc119d0a62  vmovaps [rsp], xmm0
000074fc119d0a67  vmovaps [rsp+0x10], xmm2
000074fc119d0a6d  vmovaps [rsp+0x20], xmm3
000074fc119d0a73  vmovaps [rsp+0x30], xmm4
000074fc119d0a79  vmovaps [rsp+0x40], xmm5
000074fc119d0a7f  vmovaps [rsp+0x50], xmm6
000074fc119d0a85  vmovaps [rsp+0x60], xmm7
000074fc119d0a8b  vmovaps [rsp+0x70], xmm8
000074fc119d0a91  vmovaps [rsp+0x80], xmm9
000074fc119d0a9a  vmovaps [rsp+0x90], xmm10
000074fc119d0aa3  vmovaps [rsp+0xA0], xmm11
000074fc119d0aac  vmovaps [rsp+0xB0], xmm12
000074fc119d0ab5  vmovaps [rsp+0xC0], xmm13
000074fc119d0abe  vmovaps [rsp+0xD0], xmm14
000074fc119d0ac7  vmovaps [rsp+0xE0], xmm15
000074fc119d0ad0  sub rsp, 0x30
000074fc119d0ad4  movaps [rsp], xmm1
000074fc119d0ad8  movaps [rsp+0x10], xmm14
000074fc119d0ade  movaps [rsp+0x20], xmm10
000074fc119d0ae4  lea rdi, [rsp]
000074fc119d0ae8  mov esi, 0x00
000074fc119d0aed  mov rax, 0x58C4C8091530
000074fc119d0af7  call rax
000074fc119d0af9  movaps xmm1, [rsp]
000074fc119d0afd  add rsp, 0x30
000074fc119d0b01  vmovaps xmm0, [rsp]
000074fc119d0b06  vmovaps xmm2, [rsp+0x10]
000074fc119d0b0c  vmovaps xmm3, [rsp+0x20]
000074fc119d0b12  vmovaps xmm4, [rsp+0x30]
000074fc119d0b18  vmovaps xmm5, [rsp+0x40]
000074fc119d0b1e  vmovaps xmm6, [rsp+0x50]
000074fc119d0b24  vmovaps xmm7, [rsp+0x60]
000074fc119d0b2a  vmovaps xmm8, [rsp+0x70]
000074fc119d0b30  vmovaps xmm9, [rsp+0x80]
000074fc119d0b39  vmovaps xmm10, [rsp+0x90]
000074fc119d0b42  vmovaps xmm11, [rsp+0xA0]
000074fc119d0b4b  vmovaps xmm12, [rsp+0xB0]
000074fc119d0b54  vmovaps xmm13, [rsp+0xC0]
000074fc119d0b5d  vmovaps xmm14, [rsp+0xD0]
000074fc119d0b66  vmovaps xmm15, [rsp+0xE0]
000074fc119d0b6f  add rsp, 0xF0
000074fc119d0b76  pop r11
000074fc119d0b78  pop r10
000074fc119d0b7a  pop r9
000074fc119d0b7c  pop r8
000074fc119d0b7e  pop rsi
000074fc119d0b7f  pop rdi
000074fc119d0b80  pop rdx
000074fc119d0b81  pop rcx
000074fc119d0b82  pop rax
000074fc119d0b83  add rsp, 0x08
000074fc119d0b87  jmp 0x000074FC119CF631
000074fc119d0b8c  sub rsp, 0x08
000074fc119d0b90  push rax
000074fc119d0b91  push rcx
000074fc119d0b92  push rdx
000074fc119d0b93  push rdi
000074fc119d0b94  push rsi
000074fc119d0b95  push r8
000074fc119d0b97  push r9
000074fc119d0b99  push r10
000074fc119d0b9b  push r11
000074fc119d0b9d  sub rsp, 0xF0
000074fc119d0ba4  vmovaps [rsp], xmm0
000074fc119d0ba9  vmovaps [rsp+0x10], xmm1
000074fc119d0baf  vmovaps [rsp+0x20], xmm2
000074fc119d0bb5  vmovaps [rsp+0x30], xmm3
000074fc119d0bbb  vmovaps [rsp+0x40], xmm4
000074fc119d0bc1  vmovaps [rsp+0x50], xmm5
000074fc119d0bc7  vmovaps [rsp+0x60], xmm6
000074fc119d0bcd  vmovaps [rsp+0x70], xmm7
000074fc119d0bd3  vmovaps [rsp+0x80], xmm8
000074fc119d0bdc  vmovaps [rsp+0x90], xmm9
000074fc119d0be5  vmovaps [rsp+0xA0], xmm10
000074fc119d0bee  vmovaps [rsp+0xB0], xmm11
000074fc119d0bf7  vmovaps [rsp+0xC0], xmm12
000074fc119d0c00  vmovaps [rsp+0xD0], xmm14
000074fc119d0c09  vmovaps [rsp+0xE0], xmm15
000074fc119d0c12  sub rsp, 0x30
000074fc119d0c16  movaps [rsp], xmm13
000074fc119d0c1b  movaps [rsp+0x10], xmm14
000074fc119d0c21  movaps [rsp+0x20], xmm2
000074fc119d0c26  lea rdi, [rsp]
000074fc119d0c2a  mov esi, 0x00
000074fc119d0c2f  mov rax, 0x58C4C8091530
000074fc119d0c39  call rax
000074fc119d0c3b  movaps xmm13, [rsp]
000074fc119d0c40  add rsp, 0x30
000074fc119d0c44  vmovaps xmm0, [rsp]
000074fc119d0c49  vmovaps xmm1, [rsp+0x10]
000074fc119d0c4f  vmovaps xmm2, [rsp+0x20]
000074fc119d0c55  vmovaps xmm3, [rsp+0x30]
000074fc119d0c5b  vmovaps xmm4, [rsp+0x40]
000074fc119d0c61  vmovaps xmm5, [rsp+0x50]
000074fc119d0c67  vmovaps xmm6, [rsp+0x60]
000074fc119d0c6d  vmovaps xmm7, [rsp+0x70]
000074fc119d0c73  vmovaps xmm8, [rsp+0x80]
000074fc119d0c7c  vmovaps xmm9, [rsp+0x90]
000074fc119d0c85  vmovaps xmm10, [rsp+0xA0]
000074fc119d0c8e  vmovaps xmm11, [rsp+0xB0]
000074fc119d0c97  vmovaps xmm12, [rsp+0xC0]
000074fc119d0ca0  vmovaps xmm14, [rsp+0xD0]
000074fc119d0ca9  vmovaps xmm15, [rsp+0xE0]
000074fc119d0cb2  add rsp, 0xF0
000074fc119d0cb9  pop r11
000074fc119d0cbb  pop r10
000074fc119d0cbd  pop r9
000074fc119d0cbf  pop r8
000074fc119d0cc1  pop rsi
000074fc119d0cc2  pop rdi
000074fc119d0cc3  pop rdx
000074fc119d0cc4  pop rcx
000074fc119d0cc5  pop rax
000074fc119d0cc6  add rsp, 0x08
000074fc119d0cca  jmp 0x000074FC119CF64C
000074fc119d0ccf  sub rsp, 0x08
000074fc119d0cd3  push rax
000074fc119d0cd4  push rcx
000074fc119d0cd5  push rdx
000074fc119d0cd6  push rdi
000074fc119d0cd7  push rsi
000074fc119d0cd8  push r8
000074fc119d0cda  push r9
000074fc119d0cdc  push r10
000074fc119d0cde  push r11
000074fc119d0ce0  sub rsp, 0xF0
000074fc119d0ce7  vmovaps [rsp], xmm0
000074fc119d0cec  vmovaps [rsp+0x10], xmm2
000074fc119d0cf2  vmovaps [rsp+0x20], xmm3
000074fc119d0cf8  vmovaps [rsp+0x30], xmm4
000074fc119d0cfe  vmovaps [rsp+0x40], xmm5
000074fc119d0d04  vmovaps [rsp+0x50], xmm6
000074fc119d0d0a  vmovaps [rsp+0x60], xmm7
000074fc119d0d10  vmovaps [rsp+0x70], xmm8
000074fc119d0d16  vmovaps [rsp+0x80], xmm9
000074fc119d0d1f  vmovaps [rsp+0x90], xmm10
000074fc119d0d28  vmovaps [rsp+0xA0], xmm11
000074fc119d0d31  vmovaps [rsp+0xB0], xmm12
000074fc119d0d3a  vmovaps [rsp+0xC0], xmm13
000074fc119d0d43  vmovaps [rsp+0xD0], xmm14
000074fc119d0d4c  vmovaps [rsp+0xE0], xmm15
000074fc119d0d55  sub rsp, 0x30
000074fc119d0d59  movaps [rsp], xmm1
000074fc119d0d5d  movaps [rsp+0x10], xmm10
000074fc119d0d63  movaps [rsp+0x20], xmm2
000074fc119d0d68  lea rdi, [rsp]
000074fc119d0d6c  mov esi, 0x00
000074fc119d0d71  mov rax, 0x58C4C8091530
000074fc119d0d7b  call rax
000074fc119d0d7d  movaps xmm1, [rsp]
000074fc119d0d81  add rsp, 0x30
000074fc119d0d85  vmovaps xmm0, [rsp]
000074fc119d0d8a  vmovaps xmm2, [rsp+0x10]
000074fc119d0d90  vmovaps xmm3, [rsp+0x20]
000074fc119d0d96  vmovaps xmm4, [rsp+0x30]
000074fc119d0d9c  vmovaps xmm5, [rsp+0x40]
000074fc119d0da2  vmovaps xmm6, [rsp+0x50]
000074fc119d0da8  vmovaps xmm7, [rsp+0x60]
000074fc119d0dae  vmovaps xmm8, [rsp+0x70]
000074fc119d0db4  vmovaps xmm9, [rsp+0x80]
000074fc119d0dbd  vmovaps xmm10, [rsp+0x90]
000074fc119d0dc6  vmovaps xmm11, [rsp+0xA0]
000074fc119d0dcf  vmovaps xmm12, [rsp+0xB0]
000074fc119d0dd8  vmovaps xmm13, [rsp+0xC0]
000074fc119d0de1  vmovaps xmm14, [rsp+0xD0]
000074fc119d0dea  vmovaps xmm15, [rsp+0xE0]
000074fc119d0df3  add rsp, 0xF0
000074fc119d0dfa  pop r11
000074fc119d0dfc  pop r10
000074fc119d0dfe  pop r9
000074fc119d0e00  pop r8
000074fc119d0e02  pop rsi
000074fc119d0e03  pop rdi
000074fc119d0e04  pop rdx
000074fc119d0e05  pop rcx
000074fc119d0e06  pop rax
000074fc119d0e07  add rsp, 0x08
000074fc119d0e0b  jmp 0x000074FC119CF6B4
000074fc119d0e10  sub rsp, 0x08
000074fc119d0e14  push rax
000074fc119d0e15  push rcx
000074fc119d0e16  push rdx
000074fc119d0e17  push rdi
000074fc119d0e18  push rsi
000074fc119d0e19  push r8
000074fc119d0e1b  push r9
000074fc119d0e1d  push r10
000074fc119d0e1f  push r11
000074fc119d0e21  sub rsp, 0xF0
000074fc119d0e28  vmovaps [rsp], xmm0
000074fc119d0e2d  vmovaps [rsp+0x10], xmm1
000074fc119d0e33  vmovaps [rsp+0x20], xmm2
000074fc119d0e39  vmovaps [rsp+0x30], xmm3
000074fc119d0e3f  vmovaps [rsp+0x40], xmm4
000074fc119d0e45  vmovaps [rsp+0x50], xmm5
000074fc119d0e4b  vmovaps [rsp+0x60], xmm6
000074fc119d0e51  vmovaps [rsp+0x70], xmm7
000074fc119d0e57  vmovaps [rsp+0x80], xmm8
000074fc119d0e60  vmovaps [rsp+0x90], xmm9
000074fc119d0e69  vmovaps [rsp+0xA0], xmm10
000074fc119d0e72  vmovaps [rsp+0xB0], xmm11
000074fc119d0e7b  vmovaps [rsp+0xC0], xmm12
000074fc119d0e84  vmovaps [rsp+0xD0], xmm13
000074fc119d0e8d  vmovaps [rsp+0xE0], xmm14
000074fc119d0e96  sub rsp, 0x30
000074fc119d0e9a  movaps [rsp], xmm15
000074fc119d0e9f  movaps [rsp+0x10], xmm10
000074fc119d0ea5  movaps [rsp+0x20], xmm2
000074fc119d0eaa  lea rdi, [rsp]
000074fc119d0eae  mov esi, 0x00
000074fc119d0eb3  mov rax, 0x58C4C8091530
000074fc119d0ebd  call rax
000074fc119d0ebf  movaps xmm15, [rsp]
000074fc119d0ec4  add rsp, 0x30
000074fc119d0ec8  vmovaps xmm0, [rsp]
000074fc119d0ecd  vmovaps xmm1, [rsp+0x10]
000074fc119d0ed3  vmovaps xmm2, [rsp+0x20]
000074fc119d0ed9  vmovaps xmm3, [rsp+0x30]
000074fc119d0edf  vmovaps xmm4, [rsp+0x40]
000074fc119d0ee5  vmovaps xmm5, [rsp+0x50]
000074fc119d0eeb  vmovaps xmm6, [rsp+0x60]
000074fc119d0ef1  vmovaps xmm7, [rsp+0x70]
000074fc119d0ef7  vmovaps xmm8, [rsp+0x80]
000074fc119d0f00  vmovaps xmm9, [rsp+0x90]
000074fc119d0f09  vmovaps xmm10, [rsp+0xA0]
000074fc119d0f12  vmovaps xmm11, [rsp+0xB0]
000074fc119d0f1b  vmovaps xmm12, [rsp+0xC0]
000074fc119d0f24  vmovaps xmm13, [rsp+0xD0]
000074fc119d0f2d  vmovaps xmm14, [rsp+0xE0]
000074fc119d0f36  add rsp, 0xF0
000074fc119d0f3d  pop r11
000074fc119d0f3f  pop r10
000074fc119d0f41  pop r9
000074fc119d0f43  pop r8
000074fc119d0f45  pop rsi
000074fc119d0f46  pop rdi
000074fc119d0f47  pop rdx
000074fc119d0f48  pop rcx
000074fc119d0f49  pop rax
000074fc119d0f4a  add rsp, 0x08
000074fc119d0f4e  jmp 0x000074FC119CF706
000074fc119d0f53  sub rsp, 0x08
000074fc119d0f57  push rax
000074fc119d0f58  push rcx
000074fc119d0f59  push rdx
000074fc119d0f5a  push rdi
000074fc119d0f5b  push rsi
000074fc119d0f5c  push r8
000074fc119d0f5e  push r9
000074fc119d0f60  push r10
000074fc119d0f62  push r11
000074fc119d0f64  sub rsp, 0xF0
000074fc119d0f6b  vmovaps [rsp], xmm0
000074fc119d0f70  vmovaps [rsp+0x10], xmm2
000074fc119d0f76  vmovaps [rsp+0x20], xmm3
000074fc119d0f7c  vmovaps [rsp+0x30], xmm4
000074fc119d0f82  vmovaps [rsp+0x40], xmm5
000074fc119d0f88  vmovaps [rsp+0x50], xmm6
000074fc119d0f8e  vmovaps [rsp+0x60], xmm7
000074fc119d0f94  vmovaps [rsp+0x70], xmm8
000074fc119d0f9a  vmovaps [rsp+0x80], xmm9
000074fc119d0fa3  vmovaps [rsp+0x90], xmm10
000074fc119d0fac  vmovaps [rsp+0xA0], xmm11
000074fc119d0fb5  vmovaps [rsp+0xB0], xmm12
000074fc119d0fbe  vmovaps [rsp+0xC0], xmm13
000074fc119d0fc7  vmovaps [rsp+0xD0], xmm14
000074fc119d0fd0  vmovaps [rsp+0xE0], xmm15
000074fc119d0fd9  sub rsp, 0x30
000074fc119d0fdd  movaps [rsp], xmm1
000074fc119d0fe1  movaps [rsp+0x10], xmm10
000074fc119d0fe7  movaps [rsp+0x20], xmm12
000074fc119d0fed  lea rdi, [rsp]
000074fc119d0ff1  mov esi, 0x00
000074fc119d0ff6  mov rax, 0x58C4C8091530
000074fc119d1000  call rax
000074fc119d1002  movaps xmm1, [rsp]
000074fc119d1006  add rsp, 0x30
000074fc119d100a  vmovaps xmm0, [rsp]
000074fc119d100f  vmovaps xmm2, [rsp+0x10]
000074fc119d1015  vmovaps xmm3, [rsp+0x20]
000074fc119d101b  vmovaps xmm4, [rsp+0x30]
000074fc119d1021  vmovaps xmm5, [rsp+0x40]
000074fc119d1027  vmovaps xmm6, [rsp+0x50]
000074fc119d102d  vmovaps xmm7, [rsp+0x60]
000074fc119d1033  vmovaps xmm8, [rsp+0x70]
000074fc119d1039  vmovaps xmm9, [rsp+0x80]
000074fc119d1042  vmovaps xmm10, [rsp+0x90]
000074fc119d104b  vmovaps xmm11, [rsp+0xA0]
000074fc119d1054  vmovaps xmm12, [rsp+0xB0]
000074fc119d105d  vmovaps xmm13, [rsp+0xC0]
000074fc119d1066  vmovaps xmm14, [rsp+0xD0]
000074fc119d106f  vmovaps xmm15, [rsp+0xE0]
000074fc119d1078  add rsp, 0xF0
000074fc119d107f  pop r11
000074fc119d1081  pop r10
000074fc119d1083  pop r9
000074fc119d1085  pop r8
000074fc119d1087  pop rsi
000074fc119d1088  pop rdi
000074fc119d1089  pop rdx
000074fc119d108a  pop rcx
000074fc119d108b  pop rax
000074fc119d108c  add rsp, 0x08
000074fc119d1090  jmp 0x000074FC119CF732
000074fc119d1095  sub rsp, 0x08
000074fc119d1099  push rax
000074fc119d109a  push rcx
000074fc119d109b  push rdx
000074fc119d109c  push rdi
000074fc119d109d  push rsi
000074fc119d109e  push r8
000074fc119d10a0  push r9
000074fc119d10a2  push r10
000074fc119d10a4  push r11
000074fc119d10a6  sub rsp, 0xF0
000074fc119d10ad  vmovaps [rsp], xmm0
000074fc119d10b2  vmovaps [rsp+0x10], xmm1
000074fc119d10b8  vmovaps [rsp+0x20], xmm2
000074fc119d10be  vmovaps [rsp+0x30], xmm3
000074fc119d10c4  vmovaps [rsp+0x40], xmm4
000074fc119d10ca  vmovaps [rsp+0x50], xmm5
000074fc119d10d0  vmovaps [rsp+0x60], xmm6
000074fc119d10d6  vmovaps [rsp+0x70], xmm7
000074fc119d10dc  vmovaps [rsp+0x80], xmm8
000074fc119d10e5  vmovaps [rsp+0x90], xmm9
000074fc119d10ee  vmovaps [rsp+0xA0], xmm10
000074fc119d10f7  vmovaps [rsp+0xB0], xmm11
000074fc119d1100  vmovaps [rsp+0xC0], xmm12
000074fc119d1109  vmovaps [rsp+0xD0], xmm13
000074fc119d1112  vmovaps [rsp+0xE0], xmm14
000074fc119d111b  sub rsp, 0x30
000074fc119d111f  movaps [rsp], xmm15
000074fc119d1124  movaps [rsp+0x10], xmm10
000074fc119d112a  movaps [rsp+0x20], xmm12
000074fc119d1130  lea rdi, [rsp]
000074fc119d1134  mov esi, 0x00
000074fc119d1139  mov rax, 0x58C4C8091530
000074fc119d1143  call rax
000074fc119d1145  movaps xmm15, [rsp]
000074fc119d114a  add rsp, 0x30
000074fc119d114e  vmovaps xmm0, [rsp]
000074fc119d1153  vmovaps xmm1, [rsp+0x10]
000074fc119d1159  vmovaps xmm2, [rsp+0x20]
000074fc119d115f  vmovaps xmm3, [rsp+0x30]
000074fc119d1165  vmovaps xmm4, [rsp+0x40]
000074fc119d116b  vmovaps xmm5, [rsp+0x50]
000074fc119d1171  vmovaps xmm6, [rsp+0x60]
000074fc119d1177  vmovaps xmm7, [rsp+0x70]
000074fc119d117d  vmovaps xmm8, [rsp+0x80]
000074fc119d1186  vmovaps xmm9, [rsp+0x90]
000074fc119d118f  vmovaps xmm10, [rsp+0xA0]
000074fc119d1198  vmovaps xmm11, [rsp+0xB0]
000074fc119d11a1  vmovaps xmm12, [rsp+0xC0]
000074fc119d11aa  vmovaps xmm13, [rsp+0xD0]
000074fc119d11b3  vmovaps xmm14, [rsp+0xE0]
000074fc119d11bc  add rsp, 0xF0
000074fc119d11c3  pop r11
000074fc119d11c5  pop r10
000074fc119d11c7  pop r9
000074fc119d11c9  pop r8
000074fc119d11cb  pop rsi
000074fc119d11cc  pop rdi
000074fc119d11cd  pop rdx
000074fc119d11ce  pop rcx
000074fc119d11cf  pop rax
000074fc119d11d0  add rsp, 0x08
000074fc119d11d4  jmp 0x000074FC119CF75E
000074fc119d11d9  call 0x000074FC117FF430
000074fc119d11de  jmp 0x000074FC119CF7EE
000074fc119d11e3  call 0x000074FC117FF430
000074fc119d11e8  jmp 0x000074FC119CF801
000074fc119d11ed  sub rsp, 0x08
000074fc119d11f1  push rax
000074fc119d11f2  push rcx
000074fc119d11f3  push rdx
000074fc119d11f4  push rdi
000074fc119d11f5  push rsi
000074fc119d11f6  push r8
000074fc119d11f8  push r9
000074fc119d11fa  push r10
000074fc119d11fc  push r11
000074fc119d11fe  sub rsp, 0xF0
000074fc119d1205  vmovaps [rsp], xmm0
000074fc119d120a  vmovaps [rsp+0x10], xmm2
000074fc119d1210  vmovaps [rsp+0x20], xmm3
000074fc119d1216  vmovaps [rsp+0x30], xmm4
000074fc119d121c  vmovaps [rsp+0x40], xmm5
000074fc119d1222  vmovaps [rsp+0x50], xmm6
000074fc119d1228  vmovaps [rsp+0x60], xmm7
000074fc119d122e  vmovaps [rsp+0x70], xmm8
000074fc119d1234  vmovaps [rsp+0x80], xmm9
000074fc119d123d  vmovaps [rsp+0x90], xmm10
000074fc119d1246  vmovaps [rsp+0xA0], xmm11
000074fc119d124f  vmovaps [rsp+0xB0], xmm12
000074fc119d1258  vmovaps [rsp+0xC0], xmm13
000074fc119d1261  vmovaps [rsp+0xD0], xmm14
000074fc119d126a  vmovaps [rsp+0xE0], xmm15
000074fc119d1273  sub rsp, 0x30
000074fc119d1277  movaps [rsp], xmm1
000074fc119d127b  movaps [rsp+0x10], xmm13
000074fc119d1281  movaps [rsp+0x20], xmm2
000074fc119d1286  lea rdi, [rsp]
000074fc119d128a  mov esi, 0x00
000074fc119d128f  mov rax, 0x58C4C8091530
000074fc119d1299  call rax
000074fc119d129b  movaps xmm1, [rsp]
000074fc119d129f  add rsp, 0x30
000074fc119d12a3  vmovaps xmm0, [rsp]
000074fc119d12a8  vmovaps xmm2, [rsp+0x10]
000074fc119d12ae  vmovaps xmm3, [rsp+0x20]
000074fc119d12b4  vmovaps xmm4, [rsp+0x30]
000074fc119d12ba  vmovaps xmm5, [rsp+0x40]
000074fc119d12c0  vmovaps xmm6, [rsp+0x50]
000074fc119d12c6  vmovaps xmm7, [rsp+0x60]
000074fc119d12cc  vmovaps xmm8, [rsp+0x70]
000074fc119d12d2  vmovaps xmm9, [rsp+0x80]
000074fc119d12db  vmovaps xmm10, [rsp+0x90]
000074fc119d12e4  vmovaps xmm11, [rsp+0xA0]
000074fc119d12ed  vmovaps xmm12, [rsp+0xB0]
000074fc119d12f6  vmovaps xmm13, [rsp+0xC0]
000074fc119d12ff  vmovaps xmm14, [rsp+0xD0]
000074fc119d1308  vmovaps xmm15, [rsp+0xE0]
000074fc119d1311  add rsp, 0xF0
000074fc119d1318  pop r11
000074fc119d131a  pop r10
000074fc119d131c  pop r9
000074fc119d131e  pop r8
000074fc119d1320  pop rsi
000074fc119d1321  pop rdi
000074fc119d1322  pop rdx
000074fc119d1323  pop rcx
000074fc119d1324  pop rax
000074fc119d1325  add rsp, 0x08
000074fc119d1329  jmp 0x000074FC119CF82C
000074fc119d132e  call 0x000074FC1180E760
000074fc119d1333  jmp 0x000074FC119CF839
000074fc119d1338  sub rsp, 0x08
000074fc119d133c  push rax
000074fc119d133d  push rcx
000074fc119d133e  push rdx
000074fc119d133f  push rdi
000074fc119d1340  push rsi
000074fc119d1341  push r8
000074fc119d1343  push r9
000074fc119d1345  push r10
000074fc119d1347  push r11
000074fc119d1349  sub rsp, 0xF0
000074fc119d1350  vmovaps [rsp], xmm0
000074fc119d1355  vmovaps [rsp+0x10], xmm1
000074fc119d135b  vmovaps [rsp+0x20], xmm2
000074fc119d1361  vmovaps [rsp+0x30], xmm3
000074fc119d1367  vmovaps [rsp+0x40], xmm4
000074fc119d136d  vmovaps [rsp+0x50], xmm5
000074fc119d1373  vmovaps [rsp+0x60], xmm6
000074fc119d1379  vmovaps [rsp+0x70], xmm7
000074fc119d137f  vmovaps [rsp+0x80], xmm8
000074fc119d1388  vmovaps [rsp+0x90], xmm9
000074fc119d1391  vmovaps [rsp+0xA0], xmm10
000074fc119d139a  vmovaps [rsp+0xB0], xmm11
000074fc119d13a3  vmovaps [rsp+0xC0], xmm12
000074fc119d13ac  vmovaps [rsp+0xD0], xmm14
000074fc119d13b5  vmovaps [rsp+0xE0], xmm15
000074fc119d13be  sub rsp, 0x30
000074fc119d13c2  movaps [rsp], xmm13
000074fc119d13c7  movaps [rsp+0x10], xmm2
000074fc119d13cc  movaps [rsp+0x20], xmm1
000074fc119d13d1  lea rdi, [rsp]
000074fc119d13d5  mov esi, 0x00
000074fc119d13da  mov rax, 0x58C4C8091530
000074fc119d13e4  call rax
000074fc119d13e6  movaps xmm13, [rsp]
000074fc119d13eb  add rsp, 0x30
000074fc119d13ef  vmovaps xmm0, [rsp]
000074fc119d13f4  vmovaps xmm1, [rsp+0x10]
000074fc119d13fa  vmovaps xmm2, [rsp+0x20]
000074fc119d1400  vmovaps xmm3, [rsp+0x30]
000074fc119d1406  vmovaps xmm4, [rsp+0x40]
000074fc119d140c  vmovaps xmm5, [rsp+0x50]
000074fc119d1412  vmovaps xmm6, [rsp+0x60]
000074fc119d1418  vmovaps xmm7, [rsp+0x70]
000074fc119d141e  vmovaps xmm8, [rsp+0x80]
000074fc119d1427  vmovaps xmm9, [rsp+0x90]
000074fc119d1430  vmovaps xmm10, [rsp+0xA0]
000074fc119d1439  vmovaps xmm11, [rsp+0xB0]
000074fc119d1442  vmovaps xmm12, [rsp+0xC0]
000074fc119d144b  vmovaps xmm14, [rsp+0xD0]
000074fc119d1454  vmovaps xmm15, [rsp+0xE0]
000074fc119d145d  add rsp, 0xF0
000074fc119d1464  pop r11
000074fc119d1466  pop r10
000074fc119d1468  pop r9
000074fc119d146a  pop r8
000074fc119d146c  pop rsi
000074fc119d146d  pop rdi
000074fc119d146e  pop rdx
000074fc119d146f  pop rcx
000074fc119d1470  pop rax
000074fc119d1471  add rsp, 0x08
000074fc119d1475  jmp 0x000074FC119CF878
000074fc119d147a  sub rsp, 0x08
000074fc119d147e  push rax
000074fc119d147f  push rcx
000074fc119d1480  push rdx
000074fc119d1481  push rdi
000074fc119d1482  push rsi
000074fc119d1483  push r8
000074fc119d1485  push r9
000074fc119d1487  push r10
000074fc119d1489  push r11
000074fc119d148b  sub rsp, 0xF0
000074fc119d1492  vmovaps [rsp], xmm0
000074fc119d1497  vmovaps [rsp+0x10], xmm2
000074fc119d149d  vmovaps [rsp+0x20], xmm3
000074fc119d14a3  vmovaps [rsp+0x30], xmm4
000074fc119d14a9  vmovaps [rsp+0x40], xmm5
000074fc119d14af  vmovaps [rsp+0x50], xmm6
000074fc119d14b5  vmovaps [rsp+0x60], xmm7
000074fc119d14bb  vmovaps [rsp+0x70], xmm8
000074fc119d14c1  vmovaps [rsp+0x80], xmm9
000074fc119d14ca  vmovaps [rsp+0x90], xmm10
000074fc119d14d3  vmovaps [rsp+0xA0], xmm11
000074fc119d14dc  vmovaps [rsp+0xB0], xmm12
000074fc119d14e5  vmovaps [rsp+0xC0], xmm13
000074fc119d14ee  vmovaps [rsp+0xD0], xmm14
000074fc119d14f7  vmovaps [rsp+0xE0], xmm15
000074fc119d1500  sub rsp, 0x30
000074fc119d1504  movaps [rsp], xmm1
000074fc119d1508  movaps [rsp+0x10], xmm15
000074fc119d150e  movaps [rsp+0x20], xmm2
000074fc119d1513  lea rdi, [rsp]
000074fc119d1517  mov esi, 0x00
000074fc119d151c  mov rax, 0x58C4C8091530
000074fc119d1526  call rax
000074fc119d1528  movaps xmm1, [rsp]
000074fc119d152c  add rsp, 0x30
000074fc119d1530  vmovaps xmm0, [rsp]
000074fc119d1535  vmovaps xmm2, [rsp+0x10]
000074fc119d153b  vmovaps xmm3, [rsp+0x20]
000074fc119d1541  vmovaps xmm4, [rsp+0x30]
000074fc119d1547  vmovaps xmm5, [rsp+0x40]
000074fc119d154d  vmovaps xmm6, [rsp+0x50]
000074fc119d1553  vmovaps xmm7, [rsp+0x60]
000074fc119d1559  vmovaps xmm8, [rsp+0x70]
000074fc119d155f  vmovaps xmm9, [rsp+0x80]
000074fc119d1568  vmovaps xmm10, [rsp+0x90]
000074fc119d1571  vmovaps xmm11, [rsp+0xA0]
000074fc119d157a  vmovaps xmm12, [rsp+0xB0]
000074fc119d1583  vmovaps xmm13, [rsp+0xC0]
000074fc119d158c  vmovaps xmm14, [rsp+0xD0]
000074fc119d1595  vmovaps xmm15, [rsp+0xE0]
000074fc119d159e  add rsp, 0xF0
000074fc119d15a5  pop r11
000074fc119d15a7  pop r10
000074fc119d15a9  pop r9
000074fc119d15ab  pop r8
000074fc119d15ad  pop rsi
000074fc119d15ae  pop rdi
000074fc119d15af  pop rdx
000074fc119d15b0  pop rcx
000074fc119d15b1  pop rax
000074fc119d15b2  add rsp, 0x08
000074fc119d15b6  jmp 0x000074FC119CF8AC
000074fc119d15bb  sub rsp, 0x08
000074fc119d15bf  push rax
000074fc119d15c0  push rcx
000074fc119d15c1  push rdx
000074fc119d15c2  push rdi
000074fc119d15c3  push rsi
000074fc119d15c4  push r8
000074fc119d15c6  push r9
000074fc119d15c8  push r10
000074fc119d15ca  push r11
000074fc119d15cc  sub rsp, 0xF0
000074fc119d15d3  vmovaps [rsp], xmm0
000074fc119d15d8  vmovaps [rsp+0x10], xmm1
000074fc119d15de  vmovaps [rsp+0x20], xmm2
000074fc119d15e4  vmovaps [rsp+0x30], xmm3
000074fc119d15ea  vmovaps [rsp+0x40], xmm4
000074fc119d15f0  vmovaps [rsp+0x50], xmm5
000074fc119d15f6  vmovaps [rsp+0x60], xmm6
000074fc119d15fc  vmovaps [rsp+0x70], xmm7
000074fc119d1602  vmovaps [rsp+0x80], xmm8
000074fc119d160b  vmovaps [rsp+0x90], xmm9
000074fc119d1614  vmovaps [rsp+0xA0], xmm10
000074fc119d161d  vmovaps [rsp+0xB0], xmm11
000074fc119d1626  vmovaps [rsp+0xC0], xmm12
000074fc119d162f  vmovaps [rsp+0xD0], xmm13
000074fc119d1638  vmovaps [rsp+0xE0], xmm15
000074fc119d1641  sub rsp, 0x30
000074fc119d1645  movaps [rsp], xmm14
000074fc119d164a  movaps [rsp+0x10], xmm2
000074fc119d164f  movaps [rsp+0x20], xmm15
000074fc119d1655  lea rdi, [rsp]
000074fc119d1659  mov esi, 0x00
000074fc119d165e  mov rax, 0x58C4C8091530
000074fc119d1668  call rax
000074fc119d166a  movaps xmm14, [rsp]
000074fc119d166f  add rsp, 0x30
000074fc119d1673  vmovaps xmm0, [rsp]
000074fc119d1678  vmovaps xmm1, [rsp+0x10]
000074fc119d167e  vmovaps xmm2, [rsp+0x20]
000074fc119d1684  vmovaps xmm3, [rsp+0x30]
000074fc119d168a  vmovaps xmm4, [rsp+0x40]
000074fc119d1690  vmovaps xmm5, [rsp+0x50]
000074fc119d1696  vmovaps xmm6, [rsp+0x60]
000074fc119d169c  vmovaps xmm7, [rsp+0x70]
000074fc119d16a2  vmovaps xmm8, [rsp+0x80]
000074fc119d16ab  vmovaps xmm9, [rsp+0x90]
000074fc119d16b4  vmovaps xmm10, [rsp+0xA0]
000074fc119d16bd  vmovaps xmm11, [rsp+0xB0]
000074fc119d16c6  vmovaps xmm12, [rsp+0xC0]
000074fc119d16cf  vmovaps xmm13, [rsp+0xD0]
000074fc119d16d8  vmovaps xmm15, [rsp+0xE0]
000074fc119d16e1  add rsp, 0xF0
000074fc119d16e8  pop r11
000074fc119d16ea  pop r10
000074fc119d16ec  pop r9
000074fc119d16ee  pop r8
000074fc119d16f0  pop rsi
000074fc119d16f1  pop rdi
000074fc119d16f2  pop rdx
000074fc119d16f3  pop rcx
000074fc119d16f4  pop rax
000074fc119d16f5  add rsp, 0x08
000074fc119d16f9  jmp 0x000074FC119CF8E7
000074fc119d16fe  sub rsp, 0x08
000074fc119d1702  push rax
000074fc119d1703  push rcx
000074fc119d1704  push rdx
000074fc119d1705  push rdi
000074fc119d1706  push rsi
000074fc119d1707  push r8
000074fc119d1709  push r9
000074fc119d170b  push r10
000074fc119d170d  push r11
000074fc119d170f  sub rsp, 0xF0
000074fc119d1716  vmovaps [rsp], xmm0
000074fc119d171b  vmovaps [rsp+0x10], xmm1
000074fc119d1721  vmovaps [rsp+0x20], xmm2
000074fc119d1727  vmovaps [rsp+0x30], xmm3
000074fc119d172d  vmovaps [rsp+0x40], xmm4
000074fc119d1733  vmovaps [rsp+0x50], xmm5
000074fc119d1739  vmovaps [rsp+0x60], xmm6
000074fc119d173f  vmovaps [rsp+0x70], xmm7
000074fc119d1745  vmovaps [rsp+0x80], xmm8
000074fc119d174e  vmovaps [rsp+0x90], xmm9
000074fc119d1757  vmovaps [rsp+0xA0], xmm10
000074fc119d1760  vmovaps [rsp+0xB0], xmm11
000074fc119d1769  vmovaps [rsp+0xC0], xmm12
000074fc119d1772  vmovaps [rsp+0xD0], xmm13
000074fc119d177b  vmovaps [rsp+0xE0], xmm14
000074fc119d1784  sub rsp, 0x30
000074fc119d1788  movaps [rsp], xmm15
000074fc119d178d  movaps [rsp+0x10], xmm2
000074fc119d1792  movaps [rsp+0x20], xmm1
000074fc119d1797  lea rdi, [rsp]
000074fc119d179b  mov esi, 0x00
000074fc119d17a0  mov rax, 0x58C4C8091530
000074fc119d17aa  call rax
000074fc119d17ac  movaps xmm15, [rsp]
000074fc119d17b1  add rsp, 0x30
000074fc119d17b5  vmovaps xmm0, [rsp]
000074fc119d17ba  vmovaps xmm1, [rsp+0x10]
000074fc119d17c0  vmovaps xmm2, [rsp+0x20]
000074fc119d17c6  vmovaps xmm3, [rsp+0x30]
000074fc119d17cc  vmovaps xmm4, [rsp+0x40]
000074fc119d17d2  vmovaps xmm5, [rsp+0x50]
000074fc119d17d8  vmovaps xmm6, [rsp+0x60]
000074fc119d17de  vmovaps xmm7, [rsp+0x70]
000074fc119d17e4  vmovaps xmm8, [rsp+0x80]
000074fc119d17ed  vmovaps xmm9, [rsp+0x90]
000074fc119d17f6  vmovaps xmm10, [rsp+0xA0]
000074fc119d17ff  vmovaps xmm11, [rsp+0xB0]
000074fc119d1808  vmovaps xmm12, [rsp+0xC0]
000074fc119d1811  vmovaps xmm13, [rsp+0xD0]
000074fc119d181a  vmovaps xmm14, [rsp+0xE0]
000074fc119d1823  add rsp, 0xF0
000074fc119d182a  pop r11
000074fc119d182c  pop r10
000074fc119d182e  pop r9
000074fc119d1830  pop r8
000074fc119d1832  pop rsi
000074fc119d1833  pop rdi
000074fc119d1834  pop rdx
000074fc119d1835  pop rcx
000074fc119d1836  pop rax
000074fc119d1837  add rsp, 0x08
000074fc119d183b  jmp 0x000074FC119CF923
000074fc119d1840  call 0x000074FC117FF430
000074fc119d1845  jmp 0x000074FC119CF930
000074fc119d184a  sub rsp, 0x08
000074fc119d184e  push rax
000074fc119d184f  push rcx
000074fc119d1850  push rdx
000074fc119d1851  push rdi
000074fc119d1852  push rsi
000074fc119d1853  push r8
000074fc119d1855  push r9
000074fc119d1857  push r10
000074fc119d1859  push r11
000074fc119d185b  sub rsp, 0xF0
000074fc119d1862  vmovaps [rsp], xmm0
000074fc119d1867  vmovaps [rsp+0x10], xmm1
000074fc119d186d  vmovaps [rsp+0x20], xmm3
000074fc119d1873  vmovaps [rsp+0x30], xmm4
000074fc119d1879  vmovaps [rsp+0x40], xmm5
000074fc119d187f  vmovaps [rsp+0x50], xmm6
000074fc119d1885  vmovaps [rsp+0x60], xmm7
000074fc119d188b  vmovaps [rsp+0x70], xmm8
000074fc119d1891  vmovaps [rsp+0x80], xmm9
000074fc119d189a  vmovaps [rsp+0x90], xmm10
000074fc119d18a3  vmovaps [rsp+0xA0], xmm11
000074fc119d18ac  vmovaps [rsp+0xB0], xmm12
000074fc119d18b5  vmovaps [rsp+0xC0], xmm13
000074fc119d18be  vmovaps [rsp+0xD0], xmm14
000074fc119d18c7  vmovaps [rsp+0xE0], xmm15
000074fc119d18d0  sub rsp, 0x30
000074fc119d18d4  movaps [rsp], xmm2
000074fc119d18d8  movaps [rsp+0x10], xmm1
000074fc119d18dd  movaps [rsp+0x20], xmm14
000074fc119d18e3  lea rdi, [rsp]
000074fc119d18e7  mov esi, 0x00
000074fc119d18ec  mov rax, 0x58C4C8091530
000074fc119d18f6  call rax
000074fc119d18f8  movaps xmm2, [rsp]
000074fc119d18fc  add rsp, 0x30
000074fc119d1900  vmovaps xmm0, [rsp]
000074fc119d1905  vmovaps xmm1, [rsp+0x10]
000074fc119d190b  vmovaps xmm3, [rsp+0x20]
000074fc119d1911  vmovaps xmm4, [rsp+0x30]
000074fc119d1917  vmovaps xmm5, [rsp+0x40]
000074fc119d191d  vmovaps xmm6, [rsp+0x50]
000074fc119d1923  vmovaps xmm7, [rsp+0x60]
000074fc119d1929  vmovaps xmm8, [rsp+0x70]
000074fc119d192f  vmovaps xmm9, [rsp+0x80]
000074fc119d1938  vmovaps xmm10, [rsp+0x90]
000074fc119d1941  vmovaps xmm11, [rsp+0xA0]
000074fc119d194a  vmovaps xmm12, [rsp+0xB0]
000074fc119d1953  vmovaps xmm13, [rsp+0xC0]
000074fc119d195c  vmovaps xmm14, [rsp+0xD0]
000074fc119d1965  vmovaps xmm15, [rsp+0xE0]
000074fc119d196e  add rsp, 0xF0
000074fc119d1975  pop r11
000074fc119d1977  pop r10
000074fc119d1979  pop r9
000074fc119d197b  pop r8
000074fc119d197d  pop rsi
000074fc119d197e  pop rdi
000074fc119d197f  pop rdx
000074fc119d1980  pop rcx
000074fc119d1981  pop rax
000074fc119d1982  add rsp, 0x08
000074fc119d1986  jmp 0x000074FC119CF96D
000074fc119d198b  sub rsp, 0x08
000074fc119d198f  push rax
000074fc119d1990  push rcx
000074fc119d1991  push rdx
000074fc119d1992  push rdi
000074fc119d1993  push rsi
000074fc119d1994  push r8
000074fc119d1996  push r9
000074fc119d1998  push r10
000074fc119d199a  push r11
000074fc119d199c  sub rsp, 0xF0
000074fc119d19a3  vmovaps [rsp], xmm0
000074fc119d19a8  vmovaps [rsp+0x10], xmm1
000074fc119d19ae  vmovaps [rsp+0x20], xmm2
000074fc119d19b4  vmovaps [rsp+0x30], xmm3
000074fc119d19ba  vmovaps [rsp+0x40], xmm4
000074fc119d19c0  vmovaps [rsp+0x50], xmm5
000074fc119d19c6  vmovaps [rsp+0x60], xmm6
000074fc119d19cc  vmovaps [rsp+0x70], xmm7
000074fc119d19d2  vmovaps [rsp+0x80], xmm8
000074fc119d19db  vmovaps [rsp+0x90], xmm9
000074fc119d19e4  vmovaps [rsp+0xA0], xmm10
000074fc119d19ed  vmovaps [rsp+0xB0], xmm11
000074fc119d19f6  vmovaps [rsp+0xC0], xmm12
000074fc119d19ff  vmovaps [rsp+0xD0], xmm13
000074fc119d1a08  vmovaps [rsp+0xE0], xmm14
000074fc119d1a11  sub rsp, 0x30
000074fc119d1a15  movaps [rsp], xmm15
000074fc119d1a1a  movaps [rsp+0x10], xmm14
000074fc119d1a20  movaps [rsp+0x20], xmm1
000074fc119d1a25  lea rdi, [rsp]
000074fc119d1a29  mov esi, 0x00
000074fc119d1a2e  mov rax, 0x58C4C8091530
000074fc119d1a38  call rax
000074fc119d1a3a  movaps xmm15, [rsp]
000074fc119d1a3f  add rsp, 0x30
000074fc119d1a43  vmovaps xmm0, [rsp]
000074fc119d1a48  vmovaps xmm1, [rsp+0x10]
000074fc119d1a4e  vmovaps xmm2, [rsp+0x20]
000074fc119d1a54  vmovaps xmm3, [rsp+0x30]
000074fc119d1a5a  vmovaps xmm4, [rsp+0x40]
000074fc119d1a60  vmovaps xmm5, [rsp+0x50]
000074fc119d1a66  vmovaps xmm6, [rsp+0x60]
000074fc119d1a6c  vmovaps xmm7, [rsp+0x70]
000074fc119d1a72  vmovaps xmm8, [rsp+0x80]
000074fc119d1a7b  vmovaps xmm9, [rsp+0x90]
000074fc119d1a84  vmovaps xmm10, [rsp+0xA0]
000074fc119d1a8d  vmovaps xmm11, [rsp+0xB0]
000074fc119d1a96  vmovaps xmm12, [rsp+0xC0]
000074fc119d1a9f  vmovaps xmm13, [rsp+0xD0]
000074fc119d1aa8  vmovaps xmm14, [rsp+0xE0]
000074fc119d1ab1  add rsp, 0xF0
000074fc119d1ab8  pop r11
000074fc119d1aba  pop r10
000074fc119d1abc  pop r9
000074fc119d1abe  pop r8
000074fc119d1ac0  pop rsi
000074fc119d1ac1  pop rdi
000074fc119d1ac2  pop rdx
000074fc119d1ac3  pop rcx
000074fc119d1ac4  pop rax
000074fc119d1ac5  add rsp, 0x08
000074fc119d1ac9  jmp 0x000074FC119CF9E7
000074fc119d1ace  call 0x000074FC117FF430
000074fc119d1ad3  jmp 0x000074FC119CF9F4
000074fc119d1ad8  sub rsp, 0x08
000074fc119d1adc  push rax
000074fc119d1add  push rcx
000074fc119d1ade  push rdx
000074fc119d1adf  push rdi
000074fc119d1ae0  push rsi
000074fc119d1ae1  push r8
000074fc119d1ae3  push r9
000074fc119d1ae5  push r10
000074fc119d1ae7  push r11
000074fc119d1ae9  sub rsp, 0xF0
000074fc119d1af0  vmovaps [rsp], xmm0
000074fc119d1af5  vmovaps [rsp+0x10], xmm1
000074fc119d1afb  vmovaps [rsp+0x20], xmm2
000074fc119d1b01  vmovaps [rsp+0x30], xmm3
000074fc119d1b07  vmovaps [rsp+0x40], xmm4
000074fc119d1b0d  vmovaps [rsp+0x50], xmm5
000074fc119d1b13  vmovaps [rsp+0x60], xmm6
000074fc119d1b19  vmovaps [rsp+0x70], xmm7
000074fc119d1b1f  vmovaps [rsp+0x80], xmm8
000074fc119d1b28  vmovaps [rsp+0x90], xmm9
000074fc119d1b31  vmovaps [rsp+0xA0], xmm10
000074fc119d1b3a  vmovaps [rsp+0xB0], xmm11
000074fc119d1b43  vmovaps [rsp+0xC0], xmm12
000074fc119d1b4c  vmovaps [rsp+0xD0], xmm13
000074fc119d1b55  vmovaps [rsp+0xE0], xmm15
000074fc119d1b5e  sub rsp, 0x30
000074fc119d1b62  movaps [rsp], xmm14
000074fc119d1b67  movaps [rsp+0x10], xmm13
000074fc119d1b6d  movaps [rsp+0x20], xmm1
000074fc119d1b72  lea rdi, [rsp]
000074fc119d1b76  mov esi, 0x00
000074fc119d1b7b  mov rax, 0x58C4C8091530
000074fc119d1b85  call rax
000074fc119d1b87  movaps xmm14, [rsp]
000074fc119d1b8c  add rsp, 0x30
000074fc119d1b90  vmovaps xmm0, [rsp]
000074fc119d1b95  vmovaps xmm1, [rsp+0x10]
000074fc119d1b9b  vmovaps xmm2, [rsp+0x20]
000074fc119d1ba1  vmovaps xmm3, [rsp+0x30]
000074fc119d1ba7  vmovaps xmm4, [rsp+0x40]
000074fc119d1bad  vmovaps xmm5, [rsp+0x50]
000074fc119d1bb3  vmovaps xmm6, [rsp+0x60]
000074fc119d1bb9  vmovaps xmm7, [rsp+0x70]
000074fc119d1bbf  vmovaps xmm8, [rsp+0x80]
000074fc119d1bc8  vmovaps xmm9, [rsp+0x90]
000074fc119d1bd1  vmovaps xmm10, [rsp+0xA0]
000074fc119d1bda  vmovaps xmm11, [rsp+0xB0]
000074fc119d1be3  vmovaps xmm12, [rsp+0xC0]
000074fc119d1bec  vmovaps xmm13, [rsp+0xD0]
000074fc119d1bf5  vmovaps xmm15, [rsp+0xE0]
000074fc119d1bfe  add rsp, 0xF0
000074fc119d1c05  pop r11
000074fc119d1c07  pop r10
000074fc119d1c09  pop r9
000074fc119d1c0b  pop r8
000074fc119d1c0d  pop rsi
000074fc119d1c0e  pop rdi
000074fc119d1c0f  pop rdx
000074fc119d1c10  pop rcx
000074fc119d1c11  pop rax
000074fc119d1c12  add rsp, 0x08
000074fc119d1c16  jmp 0x000074FC119CFAAF
000074fc119d1c1b  sub rsp, 0x08
000074fc119d1c1f  push rax
000074fc119d1c20  push rcx
000074fc119d1c21  push rdx
000074fc119d1c22  push rdi
000074fc119d1c23  push rsi
000074fc119d1c24  push r8
000074fc119d1c26  push r9
000074fc119d1c28  push r10
000074fc119d1c2a  push r11
000074fc119d1c2c  sub rsp, 0xF0
000074fc119d1c33  vmovaps [rsp], xmm0
000074fc119d1c38  vmovaps [rsp+0x10], xmm1
000074fc119d1c3e  vmovaps [rsp+0x20], xmm2
000074fc119d1c44  vmovaps [rsp+0x30], xmm3
000074fc119d1c4a  vmovaps [rsp+0x40], xmm4
000074fc119d1c50  vmovaps [rsp+0x50], xmm5
000074fc119d1c56  vmovaps [rsp+0x60], xmm6
000074fc119d1c5c  vmovaps [rsp+0x70], xmm7
000074fc119d1c62  vmovaps [rsp+0x80], xmm8
000074fc119d1c6b  vmovaps [rsp+0x90], xmm9
000074fc119d1c74  vmovaps [rsp+0xA0], xmm10
000074fc119d1c7d  vmovaps [rsp+0xB0], xmm11
000074fc119d1c86  vmovaps [rsp+0xC0], xmm12
000074fc119d1c8f  vmovaps [rsp+0xD0], xmm13
000074fc119d1c98  vmovaps [rsp+0xE0], xmm14
000074fc119d1ca1  sub rsp, 0x30
000074fc119d1ca5  movaps [rsp], xmm15
000074fc119d1caa  movaps [rsp+0x10], xmm13
000074fc119d1cb0  movaps [rsp+0x20], xmm1
000074fc119d1cb5  lea rdi, [rsp]
000074fc119d1cb9  mov esi, 0x00
000074fc119d1cbe  mov rax, 0x58C4C8091530
000074fc119d1cc8  call rax
000074fc119d1cca  movaps xmm15, [rsp]
000074fc119d1ccf  add rsp, 0x30
000074fc119d1cd3  vmovaps xmm0, [rsp]
000074fc119d1cd8  vmovaps xmm1, [rsp+0x10]
000074fc119d1cde  vmovaps xmm2, [rsp+0x20]
000074fc119d1ce4  vmovaps xmm3, [rsp+0x30]
000074fc119d1cea  vmovaps xmm4, [rsp+0x40]
000074fc119d1cf0  vmovaps xmm5, [rsp+0x50]
000074fc119d1cf6  vmovaps xmm6, [rsp+0x60]
000074fc119d1cfc  vmovaps xmm7, [rsp+0x70]
000074fc119d1d02  vmovaps xmm8, [rsp+0x80]
000074fc119d1d0b  vmovaps xmm9, [rsp+0x90]
000074fc119d1d14  vmovaps xmm10, [rsp+0xA0]
000074fc119d1d1d  vmovaps xmm11, [rsp+0xB0]
000074fc119d1d26  vmovaps xmm12, [rsp+0xC0]
000074fc119d1d2f  vmovaps xmm13, [rsp+0xD0]
000074fc119d1d38  vmovaps xmm14, [rsp+0xE0]
000074fc119d1d41  add rsp, 0xF0
000074fc119d1d48  pop r11
000074fc119d1d4a  pop r10
000074fc119d1d4c  pop r9
000074fc119d1d4e  pop r8
000074fc119d1d50  pop rsi
000074fc119d1d51  pop rdi
000074fc119d1d52  pop rdx
000074fc119d1d53  pop rcx
000074fc119d1d54  pop rax
000074fc119d1d55  add rsp, 0x08
000074fc119d1d59  jmp 0x000074FC119CFAEB
000074fc119d1d5e  call 0x000074FC117FF430
000074fc119d1d63  jmp 0x000074FC119CFAF8
000074fc119d1d68  sub rsp, 0x08
000074fc119d1d6c  push rax
000074fc119d1d6d  push rcx
000074fc119d1d6e  push rdx
000074fc119d1d6f  push rdi
000074fc119d1d70  push rsi
000074fc119d1d71  push r8
000074fc119d1d73  push r9
000074fc119d1d75  push r10
000074fc119d1d77  push r11
000074fc119d1d79  sub rsp, 0xF0
000074fc119d1d80  vmovaps [rsp], xmm0
000074fc119d1d85  vmovaps [rsp+0x10], xmm1
000074fc119d1d8b  vmovaps [rsp+0x20], xmm2
000074fc119d1d91  vmovaps [rsp+0x30], xmm3
000074fc119d1d97  vmovaps [rsp+0x40], xmm4
000074fc119d1d9d  vmovaps [rsp+0x50], xmm5
000074fc119d1da3  vmovaps [rsp+0x60], xmm6
000074fc119d1da9  vmovaps [rsp+0x70], xmm7
000074fc119d1daf  vmovaps [rsp+0x80], xmm8
000074fc119d1db8  vmovaps [rsp+0x90], xmm9
000074fc119d1dc1  vmovaps [rsp+0xA0], xmm10
000074fc119d1dca  vmovaps [rsp+0xB0], xmm11
000074fc119d1dd3  vmovaps [rsp+0xC0], xmm12
000074fc119d1ddc  vmovaps [rsp+0xD0], xmm13
000074fc119d1de5  vmovaps [rsp+0xE0], xmm15
000074fc119d1dee  sub rsp, 0x30
000074fc119d1df2  movaps [rsp], xmm14
000074fc119d1df7  movaps [rsp+0x10], xmm13
000074fc119d1dfd  movaps [rsp+0x20], xmm2
000074fc119d1e02  lea rdi, [rsp]
000074fc119d1e06  mov esi, 0x00
000074fc119d1e0b  mov rax, 0x58C4C8091530
000074fc119d1e15  call rax
000074fc119d1e17  movaps xmm14, [rsp]
000074fc119d1e1c  add rsp, 0x30
000074fc119d1e20  vmovaps xmm0, [rsp]
000074fc119d1e25  vmovaps xmm1, [rsp+0x10]
000074fc119d1e2b  vmovaps xmm2, [rsp+0x20]
000074fc119d1e31  vmovaps xmm3, [rsp+0x30]
000074fc119d1e37  vmovaps xmm4, [rsp+0x40]
000074fc119d1e3d  vmovaps xmm5, [rsp+0x50]
000074fc119d1e43  vmovaps xmm6, [rsp+0x60]
000074fc119d1e49  vmovaps xmm7, [rsp+0x70]
000074fc119d1e4f  vmovaps xmm8, [rsp+0x80]
000074fc119d1e58  vmovaps xmm9, [rsp+0x90]
000074fc119d1e61  vmovaps xmm10, [rsp+0xA0]
000074fc119d1e6a  vmovaps xmm11, [rsp+0xB0]
000074fc119d1e73  vmovaps xmm12, [rsp+0xC0]
000074fc119d1e7c  vmovaps xmm13, [rsp+0xD0]
000074fc119d1e85  vmovaps xmm15, [rsp+0xE0]
000074fc119d1e8e  add rsp, 0xF0
000074fc119d1e95  pop r11
000074fc119d1e97  pop r10
000074fc119d1e99  pop r9
000074fc119d1e9b  pop r8
000074fc119d1e9d  pop rsi
000074fc119d1e9e  pop rdi
000074fc119d1e9f  pop rdx
000074fc119d1ea0  pop rcx
000074fc119d1ea1  pop rax
000074fc119d1ea2  add rsp, 0x08
000074fc119d1ea6  jmp 0x000074FC119CFB24
000074fc119d1eab  sub rsp, 0x08
000074fc119d1eaf  push rax
000074fc119d1eb0  push rcx
000074fc119d1eb1  push rdx
000074fc119d1eb2  push rdi
000074fc119d1eb3  push rsi
000074fc119d1eb4  push r8
000074fc119d1eb6  push r9
000074fc119d1eb8  push r10
000074fc119d1eba  push r11
000074fc119d1ebc  sub rsp, 0xF0
000074fc119d1ec3  vmovaps [rsp], xmm0
000074fc119d1ec8  vmovaps [rsp+0x10], xmm2
000074fc119d1ece  vmovaps [rsp+0x20], xmm3
000074fc119d1ed4  vmovaps [rsp+0x30], xmm4
000074fc119d1eda  vmovaps [rsp+0x40], xmm5
000074fc119d1ee0  vmovaps [rsp+0x50], xmm6
000074fc119d1ee6  vmovaps [rsp+0x60], xmm7
000074fc119d1eec  vmovaps [rsp+0x70], xmm8
000074fc119d1ef2  vmovaps [rsp+0x80], xmm9
000074fc119d1efb  vmovaps [rsp+0x90], xmm10
000074fc119d1f04  vmovaps [rsp+0xA0], xmm11
000074fc119d1f0d  vmovaps [rsp+0xB0], xmm12
000074fc119d1f16  vmovaps [rsp+0xC0], xmm13
000074fc119d1f1f  vmovaps [rsp+0xD0], xmm14
000074fc119d1f28  vmovaps [rsp+0xE0], xmm15
000074fc119d1f31  sub rsp, 0x30
000074fc119d1f35  movaps [rsp], xmm1
000074fc119d1f39  movaps [rsp+0x10], xmm13
000074fc119d1f3f  movaps [rsp+0x20], xmm2
000074fc119d1f44  lea rdi, [rsp]
000074fc119d1f48  mov esi, 0x00
000074fc119d1f4d  mov rax, 0x58C4C8091530
000074fc119d1f57  call rax
000074fc119d1f59  movaps xmm1, [rsp]
000074fc119d1f5d  add rsp, 0x30
000074fc119d1f61  vmovaps xmm0, [rsp]
000074fc119d1f66  vmovaps xmm2, [rsp+0x10]
000074fc119d1f6c  vmovaps xmm3, [rsp+0x20]
000074fc119d1f72  vmovaps xmm4, [rsp+0x30]
000074fc119d1f78  vmovaps xmm5, [rsp+0x40]
000074fc119d1f7e  vmovaps xmm6, [rsp+0x50]
000074fc119d1f84  vmovaps xmm7, [rsp+0x60]
000074fc119d1f8a  vmovaps xmm8, [rsp+0x70]
000074fc119d1f90  vmovaps xmm9, [rsp+0x80]
000074fc119d1f99  vmovaps xmm10, [rsp+0x90]
000074fc119d1fa2  vmovaps xmm11, [rsp+0xA0]
000074fc119d1fab  vmovaps xmm12, [rsp+0xB0]
000074fc119d1fb4  vmovaps xmm13, [rsp+0xC0]
000074fc119d1fbd  vmovaps xmm14, [rsp+0xD0]
000074fc119d1fc6  vmovaps xmm15, [rsp+0xE0]
000074fc119d1fcf  add rsp, 0xF0
000074fc119d1fd6  pop r11
000074fc119d1fd8  pop r10
000074fc119d1fda  pop r9
000074fc119d1fdc  pop r8
000074fc119d1fde  pop rsi
000074fc119d1fdf  pop rdi
000074fc119d1fe0  pop rdx
000074fc119d1fe1  pop rcx
000074fc119d1fe2  pop rax
000074fc119d1fe3  add rsp, 0x08
000074fc119d1fe7  jmp 0x000074FC119CFB52
000074fc119d1fec  sub rsp, 0x08
000074fc119d1ff0  push rax
000074fc119d1ff1  push rcx
000074fc119d1ff2  push rdx
000074fc119d1ff3  push rdi
000074fc119d1ff4  push rsi
000074fc119d1ff5  push r8
000074fc119d1ff7  push r9
000074fc119d1ff9  push r10
000074fc119d1ffb  push r11
000074fc119d1ffd  sub rsp, 0xF0
000074fc119d2004  vmovaps [rsp], xmm0
000074fc119d2009  vmovaps [rsp+0x10], xmm1
000074fc119d200f  vmovaps [rsp+0x20], xmm3
000074fc119d2015  vmovaps [rsp+0x30], xmm4
000074fc119d201b  vmovaps [rsp+0x40], xmm5
000074fc119d2021  vmovaps [rsp+0x50], xmm6
000074fc119d2027  vmovaps [rsp+0x60], xmm7
000074fc119d202d  vmovaps [rsp+0x70], xmm8
000074fc119d2033  vmovaps [rsp+0x80], xmm9
000074fc119d203c  vmovaps [rsp+0x90], xmm10
000074fc119d2045  vmovaps [rsp+0xA0], xmm11
000074fc119d204e  vmovaps [rsp+0xB0], xmm12
000074fc119d2057  vmovaps [rsp+0xC0], xmm13
000074fc119d2060  vmovaps [rsp+0xD0], xmm14
000074fc119d2069  vmovaps [rsp+0xE0], xmm15
000074fc119d2072  sub rsp, 0x30
000074fc119d2076  movaps [rsp], xmm2
000074fc119d207a  movaps [rsp+0x10], xmm1
000074fc119d207f  movaps [rsp+0x20], xmm13
000074fc119d2085  lea rdi, [rsp]
000074fc119d2089  mov esi, 0x00
000074fc119d208e  mov rax, 0x58C4C8091530
000074fc119d2098  call rax
000074fc119d209a  movaps xmm2, [rsp]
000074fc119d209e  add rsp, 0x30
000074fc119d20a2  vmovaps xmm0, [rsp]
000074fc119d20a7  vmovaps xmm1, [rsp+0x10]
000074fc119d20ad  vmovaps xmm3, [rsp+0x20]
000074fc119d20b3  vmovaps xmm4, [rsp+0x30]
000074fc119d20b9  vmovaps xmm5, [rsp+0x40]
000074fc119d20bf  vmovaps xmm6, [rsp+0x50]
000074fc119d20c5  vmovaps xmm7, [rsp+0x60]
000074fc119d20cb  vmovaps xmm8, [rsp+0x70]
000074fc119d20d1  vmovaps xmm9, [rsp+0x80]
000074fc119d20da  vmovaps xmm10, [rsp+0x90]
000074fc119d20e3  vmovaps xmm11, [rsp+0xA0]
000074fc119d20ec  vmovaps xmm12, [rsp+0xB0]
000074fc119d20f5  vmovaps xmm13, [rsp+0xC0]
000074fc119d20fe  vmovaps xmm14, [rsp+0xD0]
000074fc119d2107  vmovaps xmm15, [rsp+0xE0]
000074fc119d2110  add rsp, 0xF0
000074fc119d2117  pop r11
000074fc119d2119  pop r10
000074fc119d211b  pop r9
000074fc119d211d  pop r8
000074fc119d211f  pop rsi
000074fc119d2120  pop rdi
000074fc119d2121  pop rdx
000074fc119d2122  pop rcx
000074fc119d2123  pop rax
000074fc119d2124  add rsp, 0x08
000074fc119d2128  jmp 0x000074FC119CFBAB
000074fc119d212d  call 0x000074FC117FF430
000074fc119d2132  jmp 0x000074FC119CFBB8
000074fc119d2137  sub rsp, 0x08
000074fc119d213b  push rax
000074fc119d213c  push rcx
000074fc119d213d  push rdx
000074fc119d213e  push rdi
000074fc119d213f  push rsi
000074fc119d2140  push r8
000074fc119d2142  push r9
000074fc119d2144  push r10
000074fc119d2146  push r11
000074fc119d2148  sub rsp, 0xF0
000074fc119d214f  vmovaps [rsp], xmm0
000074fc119d2154  vmovaps [rsp+0x10], xmm1
000074fc119d215a  vmovaps [rsp+0x20], xmm2
000074fc119d2160  vmovaps [rsp+0x30], xmm3
000074fc119d2166  vmovaps [rsp+0x40], xmm4
000074fc119d216c  vmovaps [rsp+0x50], xmm5
000074fc119d2172  vmovaps [rsp+0x60], xmm6
000074fc119d2178  vmovaps [rsp+0x70], xmm7
000074fc119d217e  vmovaps [rsp+0x80], xmm8
000074fc119d2187  vmovaps [rsp+0x90], xmm9
000074fc119d2190  vmovaps [rsp+0xA0], xmm10
000074fc119d2199  vmovaps [rsp+0xB0], xmm11
000074fc119d21a2  vmovaps [rsp+0xC0], xmm12
000074fc119d21ab  vmovaps [rsp+0xD0], xmm13
000074fc119d21b4  vmovaps [rsp+0xE0], xmm14
000074fc119d21bd  sub rsp, 0x30
000074fc119d21c1  movaps [rsp], xmm15
000074fc119d21c6  movaps [rsp+0x10], xmm13
000074fc119d21cc  movaps [rsp+0x20], xmm1
000074fc119d21d1  lea rdi, [rsp]
000074fc119d21d5  mov esi, 0x00
000074fc119d21da  mov rax, 0x58C4C8091530
000074fc119d21e4  call rax
000074fc119d21e6  movaps xmm15, [rsp]
000074fc119d21eb  add rsp, 0x30
000074fc119d21ef  vmovaps xmm0, [rsp]
000074fc119d21f4  vmovaps xmm1, [rsp+0x10]
000074fc119d21fa  vmovaps xmm2, [rsp+0x20]
000074fc119d2200  vmovaps xmm3, [rsp+0x30]
000074fc119d2206  vmovaps xmm4, [rsp+0x40]
000074fc119d220c  vmovaps xmm5, [rsp+0x50]
000074fc119d2212  vmovaps xmm6, [rsp+0x60]
000074fc119d2218  vmovaps xmm7, [rsp+0x70]
000074fc119d221e  vmovaps xmm8, [rsp+0x80]
000074fc119d2227  vmovaps xmm9, [rsp+0x90]
000074fc119d2230  vmovaps xmm10, [rsp+0xA0]
000074fc119d2239  vmovaps xmm11, [rsp+0xB0]
000074fc119d2242  vmovaps xmm12, [rsp+0xC0]
000074fc119d224b  vmovaps xmm13, [rsp+0xD0]
000074fc119d2254  vmovaps xmm14, [rsp+0xE0]
000074fc119d225d  add rsp, 0xF0
000074fc119d2264  pop r11
000074fc119d2266  pop r10
000074fc119d2268  pop r9
000074fc119d226a  pop r8
000074fc119d226c  pop rsi
000074fc119d226d  pop rdi
000074fc119d226e  pop rdx
000074fc119d226f  pop rcx
000074fc119d2270  pop rax
000074fc119d2271  add rsp, 0x08
000074fc119d2275  jmp 0x000074FC119CFBF7
000074fc119d227a  sub rsp, 0x08
000074fc119d227e  push rax
000074fc119d227f  push rcx
000074fc119d2280  push rdx
000074fc119d2281  push rdi
000074fc119d2282  push rsi
000074fc119d2283  push r8
000074fc119d2285  push r9
000074fc119d2287  push r10
000074fc119d2289  push r11
000074fc119d228b  sub rsp, 0xF0
000074fc119d2292  vmovaps [rsp], xmm0
000074fc119d2297  vmovaps [rsp+0x10], xmm1
000074fc119d229d  vmovaps [rsp+0x20], xmm2
000074fc119d22a3  vmovaps [rsp+0x30], xmm3
000074fc119d22a9  vmovaps [rsp+0x40], xmm4
000074fc119d22af  vmovaps [rsp+0x50], xmm5
000074fc119d22b5  vmovaps [rsp+0x60], xmm6
000074fc119d22bb  vmovaps [rsp+0x70], xmm7
000074fc119d22c1  vmovaps [rsp+0x80], xmm8
000074fc119d22ca  vmovaps [rsp+0x90], xmm9
000074fc119d22d3  vmovaps [rsp+0xA0], xmm10
000074fc119d22dc  vmovaps [rsp+0xB0], xmm11
000074fc119d22e5  vmovaps [rsp+0xC0], xmm12
000074fc119d22ee  vmovaps [rsp+0xD0], xmm13
000074fc119d22f7  vmovaps [rsp+0xE0], xmm15
000074fc119d2300  sub rsp, 0x30
000074fc119d2304  movaps [rsp], xmm14
000074fc119d2309  movaps [rsp+0x10], xmm11
000074fc119d230f  movaps [rsp+0x20], xmm1
000074fc119d2314  lea rdi, [rsp]
000074fc119d2318  mov esi, 0x00
000074fc119d231d  mov rax, 0x58C4C8091530
000074fc119d2327  call rax
000074fc119d2329  movaps xmm14, [rsp]
000074fc119d232e  add rsp, 0x30
000074fc119d2332  vmovaps xmm0, [rsp]
000074fc119d2337  vmovaps xmm1, [rsp+0x10]
000074fc119d233d  vmovaps xmm2, [rsp+0x20]
000074fc119d2343  vmovaps xmm3, [rsp+0x30]
000074fc119d2349  vmovaps xmm4, [rsp+0x40]
000074fc119d234f  vmovaps xmm5, [rsp+0x50]
000074fc119d2355  vmovaps xmm6, [rsp+0x60]
000074fc119d235b  vmovaps xmm7, [rsp+0x70]
000074fc119d2361  vmovaps xmm8, [rsp+0x80]
000074fc119d236a  vmovaps xmm9, [rsp+0x90]
000074fc119d2373  vmovaps xmm10, [rsp+0xA0]
000074fc119d237c  vmovaps xmm11, [rsp+0xB0]
000074fc119d2385  vmovaps xmm12, [rsp+0xC0]
000074fc119d238e  vmovaps xmm13, [rsp+0xD0]
000074fc119d2397  vmovaps xmm15, [rsp+0xE0]
000074fc119d23a0  add rsp, 0xF0
000074fc119d23a7  pop r11
000074fc119d23a9  pop r10
000074fc119d23ab  pop r9
000074fc119d23ad  pop r8
000074fc119d23af  pop rsi
000074fc119d23b0  pop rdi
000074fc119d23b1  pop rdx
000074fc119d23b2  pop rcx
000074fc119d23b3  pop rax
000074fc119d23b4  add rsp, 0x08
000074fc119d23b8  jmp 0x000074FC119CFC21
000074fc119d23bd  sub rsp, 0x08
000074fc119d23c1  push rax
000074fc119d23c2  push rcx
000074fc119d23c3  push rdx
000074fc119d23c4  push rdi
000074fc119d23c5  push rsi
000074fc119d23c6  push r8
000074fc119d23c8  push r9
000074fc119d23ca  push r10
000074fc119d23cc  push r11
000074fc119d23ce  sub rsp, 0xF0
000074fc119d23d5  vmovaps [rsp], xmm0
000074fc119d23da  vmovaps [rsp+0x10], xmm1
000074fc119d23e0  vmovaps [rsp+0x20], xmm2
000074fc119d23e6  vmovaps [rsp+0x30], xmm3
000074fc119d23ec  vmovaps [rsp+0x40], xmm4
000074fc119d23f2  vmovaps [rsp+0x50], xmm5
000074fc119d23f8  vmovaps [rsp+0x60], xmm6
000074fc119d23fe  vmovaps [rsp+0x70], xmm7
000074fc119d2404  vmovaps [rsp+0x80], xmm8
000074fc119d240d  vmovaps [rsp+0x90], xmm9
000074fc119d2416  vmovaps [rsp+0xA0], xmm10
000074fc119d241f  vmovaps [rsp+0xB0], xmm11
000074fc119d2428  vmovaps [rsp+0xC0], xmm12
000074fc119d2431  vmovaps [rsp+0xD0], xmm14
000074fc119d243a  vmovaps [rsp+0xE0], xmm15
000074fc119d2443  sub rsp, 0x30
000074fc119d2447  movaps [rsp], xmm13
000074fc119d244c  movaps [rsp+0x10], xmm11
000074fc119d2452  movaps [rsp+0x20], xmm1
000074fc119d2457  lea rdi, [rsp]
000074fc119d245b  mov esi, 0x00
000074fc119d2460  mov rax, 0x58C4C8091530
000074fc119d246a  call rax
000074fc119d246c  movaps xmm13, [rsp]
000074fc119d2471  add rsp, 0x30
000074fc119d2475  vmovaps xmm0, [rsp]
000074fc119d247a  vmovaps xmm1, [rsp+0x10]
000074fc119d2480  vmovaps xmm2, [rsp+0x20]
000074fc119d2486  vmovaps xmm3, [rsp+0x30]
000074fc119d248c  vmovaps xmm4, [rsp+0x40]
000074fc119d2492  vmovaps xmm5, [rsp+0x50]
000074fc119d2498  vmovaps xmm6, [rsp+0x60]
000074fc119d249e  vmovaps xmm7, [rsp+0x70]
000074fc119d24a4  vmovaps xmm8, [rsp+0x80]
000074fc119d24ad  vmovaps xmm9, [rsp+0x90]
000074fc119d24b6  vmovaps xmm10, [rsp+0xA0]
000074fc119d24bf  vmovaps xmm11, [rsp+0xB0]
000074fc119d24c8  vmovaps xmm12, [rsp+0xC0]
000074fc119d24d1  vmovaps xmm14, [rsp+0xD0]
000074fc119d24da  vmovaps xmm15, [rsp+0xE0]
000074fc119d24e3  add rsp, 0xF0
000074fc119d24ea  pop r11
000074fc119d24ec  pop r10
000074fc119d24ee  pop r9
000074fc119d24f0  pop r8
000074fc119d24f2  pop rsi
000074fc119d24f3  pop rdi
000074fc119d24f4  pop rdx
000074fc119d24f5  pop rcx
000074fc119d24f6  pop rax
000074fc119d24f7  add rsp, 0x08
000074fc119d24fb  jmp 0x000074FC119CFC76
000074fc119d2500  call 0x000074FC117FF430
000074fc119d2505  jmp 0x000074FC119CFC83
000074fc119d250a  sub rsp, 0x08
000074fc119d250e  push rax
000074fc119d250f  push rcx
000074fc119d2510  push rdx
000074fc119d2511  push rdi
000074fc119d2512  push rsi
000074fc119d2513  push r8
000074fc119d2515  push r9
000074fc119d2517  push r10
000074fc119d2519  push r11
000074fc119d251b  sub rsp, 0xF0
000074fc119d2522  vmovaps [rsp], xmm0
000074fc119d2527  vmovaps [rsp+0x10], xmm1
000074fc119d252d  vmovaps [rsp+0x20], xmm2
000074fc119d2533  vmovaps [rsp+0x30], xmm3
000074fc119d2539  vmovaps [rsp+0x40], xmm4
000074fc119d253f  vmovaps [rsp+0x50], xmm5
000074fc119d2545  vmovaps [rsp+0x60], xmm6
000074fc119d254b  vmovaps [rsp+0x70], xmm7
000074fc119d2551  vmovaps [rsp+0x80], xmm8
000074fc119d255a  vmovaps [rsp+0x90], xmm9
000074fc119d2563  vmovaps [rsp+0xA0], xmm10
000074fc119d256c  vmovaps [rsp+0xB0], xmm11
000074fc119d2575  vmovaps [rsp+0xC0], xmm12
000074fc119d257e  vmovaps [rsp+0xD0], xmm13
000074fc119d2587  vmovaps [rsp+0xE0], xmm14
000074fc119d2590  sub rsp, 0x30
000074fc119d2594  movaps [rsp], xmm15
000074fc119d2599  movaps [rsp+0x10], xmm11
000074fc119d259f  movaps [rsp+0x20], xmm1
000074fc119d25a4  lea rdi, [rsp]
000074fc119d25a8  mov esi, 0x00
000074fc119d25ad  mov rax, 0x58C4C8091530
000074fc119d25b7  call rax
000074fc119d25b9  movaps xmm15, [rsp]
000074fc119d25be  add rsp, 0x30
000074fc119d25c2  vmovaps xmm0, [rsp]
000074fc119d25c7  vmovaps xmm1, [rsp+0x10]
000074fc119d25cd  vmovaps xmm2, [rsp+0x20]
000074fc119d25d3  vmovaps xmm3, [rsp+0x30]
000074fc119d25d9  vmovaps xmm4, [rsp+0x40]
000074fc119d25df  vmovaps xmm5, [rsp+0x50]
000074fc119d25e5  vmovaps xmm6, [rsp+0x60]
000074fc119d25eb  vmovaps xmm7, [rsp+0x70]
000074fc119d25f1  vmovaps xmm8, [rsp+0x80]
000074fc119d25fa  vmovaps xmm9, [rsp+0x90]
000074fc119d2603  vmovaps xmm10, [rsp+0xA0]
000074fc119d260c  vmovaps xmm11, [rsp+0xB0]
000074fc119d2615  vmovaps xmm12, [rsp+0xC0]
000074fc119d261e  vmovaps xmm13, [rsp+0xD0]
000074fc119d2627  vmovaps xmm14, [rsp+0xE0]
000074fc119d2630  add rsp, 0xF0
000074fc119d2637  pop r11
000074fc119d2639  pop r10
000074fc119d263b  pop r9
000074fc119d263d  pop r8
000074fc119d263f  pop rsi
000074fc119d2640  pop rdi
000074fc119d2641  pop rdx
000074fc119d2642  pop rcx
000074fc119d2643  pop rax
000074fc119d2644  add rsp, 0x08
000074fc119d2648  jmp 0x000074FC119CFCBC
000074fc119d264d  sub rsp, 0x08
000074fc119d2651  push rax
000074fc119d2652  push rcx
000074fc119d2653  push rdx
000074fc119d2654  push rdi
000074fc119d2655  push rsi
000074fc119d2656  push r8
000074fc119d2658  push r9
000074fc119d265a  push r10
000074fc119d265c  push r11
000074fc119d265e  sub rsp, 0xF0
000074fc119d2665  vmovaps [rsp], xmm0
000074fc119d266a  vmovaps [rsp+0x10], xmm1
000074fc119d2670  vmovaps [rsp+0x20], xmm2
000074fc119d2676  vmovaps [rsp+0x30], xmm3
000074fc119d267c  vmovaps [rsp+0x40], xmm4
000074fc119d2682  vmovaps [rsp+0x50], xmm5
000074fc119d2688  vmovaps [rsp+0x60], xmm6
000074fc119d268e  vmovaps [rsp+0x70], xmm7
000074fc119d2694  vmovaps [rsp+0x80], xmm8
000074fc119d269d  vmovaps [rsp+0x90], xmm9
000074fc119d26a6  vmovaps [rsp+0xA0], xmm10
000074fc119d26af  vmovaps [rsp+0xB0], xmm12
000074fc119d26b8  vmovaps [rsp+0xC0], xmm13
000074fc119d26c1  vmovaps [rsp+0xD0], xmm14
000074fc119d26ca  vmovaps [rsp+0xE0], xmm15
000074fc119d26d3  sub rsp, 0x30
000074fc119d26d7  movaps [rsp], xmm11
000074fc119d26dc  movaps [rsp+0x10], xmm6
000074fc119d26e1  movaps [rsp+0x20], xmm14
000074fc119d26e7  lea rdi, [rsp]
000074fc119d26eb  mov esi, 0x00
000074fc119d26f0  mov rax, 0x58C4C8091530
000074fc119d26fa  call rax
000074fc119d26fc  movaps xmm11, [rsp]
000074fc119d2701  add rsp, 0x30
000074fc119d2705  vmovaps xmm0, [rsp]
000074fc119d270a  vmovaps xmm1, [rsp+0x10]
000074fc119d2710  vmovaps xmm2, [rsp+0x20]
000074fc119d2716  vmovaps xmm3, [rsp+0x30]
000074fc119d271c  vmovaps xmm4, [rsp+0x40]
000074fc119d2722  vmovaps xmm5, [rsp+0x50]
000074fc119d2728  vmovaps xmm6, [rsp+0x60]
000074fc119d272e  vmovaps xmm7, [rsp+0x70]
000074fc119d2734  vmovaps xmm8, [rsp+0x80]
000074fc119d273d  vmovaps xmm9, [rsp+0x90]
000074fc119d2746  vmovaps xmm10, [rsp+0xA0]
000074fc119d274f  vmovaps xmm12, [rsp+0xB0]
000074fc119d2758  vmovaps xmm13, [rsp+0xC0]
000074fc119d2761  vmovaps xmm14, [rsp+0xD0]
000074fc119d276a  vmovaps xmm15, [rsp+0xE0]
000074fc119d2773  add rsp, 0xF0
000074fc119d277a  pop r11
000074fc119d277c  pop r10
000074fc119d277e  pop r9
000074fc119d2780  pop r8
000074fc119d2782  pop rsi
000074fc119d2783  pop rdi
000074fc119d2784  pop rdx
000074fc119d2785  pop rcx
000074fc119d2786  pop rax
000074fc119d2787  add rsp, 0x08
000074fc119d278b  jmp 0x000074FC119CFD34
000074fc119d2790  call 0x000074FC117FF430
000074fc119d2795  jmp 0x000074FC119CFD3E
000074fc119d279a  sub rsp, 0x08
000074fc119d279e  push rax
000074fc119d279f  push rcx
000074fc119d27a0  push rdx
000074fc119d27a1  push rdi
000074fc119d27a2  push rsi
000074fc119d27a3  push r8
000074fc119d27a5  push r9
000074fc119d27a7  push r10
000074fc119d27a9  push r11
000074fc119d27ab  sub rsp, 0xF0
000074fc119d27b2  vmovaps [rsp], xmm0
000074fc119d27b7  vmovaps [rsp+0x10], xmm1
000074fc119d27bd  vmovaps [rsp+0x20], xmm2
000074fc119d27c3  vmovaps [rsp+0x30], xmm3
000074fc119d27c9  vmovaps [rsp+0x40], xmm4
000074fc119d27cf  vmovaps [rsp+0x50], xmm5
000074fc119d27d5  vmovaps [rsp+0x60], xmm6
000074fc119d27db  vmovaps [rsp+0x70], xmm7
000074fc119d27e1  vmovaps [rsp+0x80], xmm8
000074fc119d27ea  vmovaps [rsp+0x90], xmm9
000074fc119d27f3  vmovaps [rsp+0xA0], xmm10
000074fc119d27fc  vmovaps [rsp+0xB0], xmm11
000074fc119d2805  vmovaps [rsp+0xC0], xmm12
000074fc119d280e  vmovaps [rsp+0xD0], xmm13
000074fc119d2817  vmovaps [rsp+0xE0], xmm15
000074fc119d2820  sub rsp, 0x30
000074fc119d2824  movaps [rsp], xmm14
000074fc119d2829  movaps [rsp+0x10], xmm6
000074fc119d282e  movaps [rsp+0x20], xmm2
000074fc119d2833  lea rdi, [rsp]
000074fc119d2837  mov esi, 0x00
000074fc119d283c  mov rax, 0x58C4C8091530
000074fc119d2846  call rax
000074fc119d2848  movaps xmm14, [rsp]
000074fc119d284d  add rsp, 0x30
000074fc119d2851  vmovaps xmm0, [rsp]
000074fc119d2856  vmovaps xmm1, [rsp+0x10]
000074fc119d285c  vmovaps xmm2, [rsp+0x20]
000074fc119d2862  vmovaps xmm3, [rsp+0x30]
000074fc119d2868  vmovaps xmm4, [rsp+0x40]
000074fc119d286e  vmovaps xmm5, [rsp+0x50]
000074fc119d2874  vmovaps xmm6, [rsp+0x60]
000074fc119d287a  vmovaps xmm7, [rsp+0x70]
000074fc119d2880  vmovaps xmm8, [rsp+0x80]
000074fc119d2889  vmovaps xmm9, [rsp+0x90]
000074fc119d2892  vmovaps xmm10, [rsp+0xA0]
000074fc119d289b  vmovaps xmm11, [rsp+0xB0]
000074fc119d28a4  vmovaps xmm12, [rsp+0xC0]
000074fc119d28ad  vmovaps xmm13, [rsp+0xD0]
000074fc119d28b6  vmovaps xmm15, [rsp+0xE0]
000074fc119d28bf  add rsp, 0xF0
000074fc119d28c6  pop r11
000074fc119d28c8  pop r10
000074fc119d28ca  pop r9
000074fc119d28cc  pop r8
000074fc119d28ce  pop rsi
000074fc119d28cf  pop rdi
000074fc119d28d0  pop rdx
000074fc119d28d1  pop rcx
000074fc119d28d2  pop rax
000074fc119d28d3  add rsp, 0x08
000074fc119d28d7  jmp 0x000074FC119CFD72
000074fc119d28dc  sub rsp, 0x08
000074fc119d28e0  push rax
000074fc119d28e1  push rcx
000074fc119d28e2  push rdx
000074fc119d28e3  push rdi
000074fc119d28e4  push rsi
000074fc119d28e5  push r8
000074fc119d28e7  push r9
000074fc119d28e9  push r10
000074fc119d28eb  push r11
000074fc119d28ed  sub rsp, 0xF0
000074fc119d28f4  vmovaps [rsp], xmm0
000074fc119d28f9  vmovaps [rsp+0x10], xmm1
000074fc119d28ff  vmovaps [rsp+0x20], xmm2
000074fc119d2905  vmovaps [rsp+0x30], xmm3
000074fc119d290b  vmovaps [rsp+0x40], xmm4
000074fc119d2911  vmovaps [rsp+0x50], xmm5
000074fc119d2917  vmovaps [rsp+0x60], xmm7
000074fc119d291d  vmovaps [rsp+0x70], xmm8
000074fc119d2923  vmovaps [rsp+0x80], xmm9
000074fc119d292c  vmovaps [rsp+0x90], xmm10
000074fc119d2935  vmovaps [rsp+0xA0], xmm11
000074fc119d293e  vmovaps [rsp+0xB0], xmm12
000074fc119d2947  vmovaps [rsp+0xC0], xmm13
000074fc119d2950  vmovaps [rsp+0xD0], xmm14
000074fc119d2959  vmovaps [rsp+0xE0], xmm15
000074fc119d2962  sub rsp, 0x30
000074fc119d2966  movaps [rsp], xmm6
000074fc119d296a  movaps [rsp+0x10], xmm5
000074fc119d296f  movaps [rsp+0x20], xmm1
000074fc119d2974  lea rdi, [rsp]
000074fc119d2978  mov esi, 0x00
000074fc119d297d  mov rax, 0x58C4C8091530
000074fc119d2987  call rax
000074fc119d2989  movaps xmm6, [rsp]
000074fc119d298d  add rsp, 0x30
000074fc119d2991  vmovaps xmm0, [rsp]
000074fc119d2996  vmovaps xmm1, [rsp+0x10]
000074fc119d299c  vmovaps xmm2, [rsp+0x20]
000074fc119d29a2  vmovaps xmm3, [rsp+0x30]
000074fc119d29a8  vmovaps xmm4, [rsp+0x40]
000074fc119d29ae  vmovaps xmm5, [rsp+0x50]
000074fc119d29b4  vmovaps xmm7, [rsp+0x60]
000074fc119d29ba  vmovaps xmm8, [rsp+0x70]
000074fc119d29c0  vmovaps xmm9, [rsp+0x80]
000074fc119d29c9  vmovaps xmm10, [rsp+0x90]
000074fc119d29d2  vmovaps xmm11, [rsp+0xA0]
000074fc119d29db  vmovaps xmm12, [rsp+0xB0]
000074fc119d29e4  vmovaps xmm13, [rsp+0xC0]
000074fc119d29ed  vmovaps xmm14, [rsp+0xD0]
000074fc119d29f6  vmovaps xmm15, [rsp+0xE0]
000074fc119d29ff  add rsp, 0xF0
000074fc119d2a06  pop r11
000074fc119d2a08  pop r10
000074fc119d2a0a  pop r9
000074fc119d2a0c  pop r8
000074fc119d2a0e  pop rsi
000074fc119d2a0f  pop rdi
000074fc119d2a10  pop rdx
000074fc119d2a11  pop rcx
000074fc119d2a12  pop rax
000074fc119d2a13  add rsp, 0x08
000074fc119d2a17  jmp 0x000074FC119CFD98
000074fc119d2a1c  sub rsp, 0x08
000074fc119d2a20  push rax
000074fc119d2a21  push rcx
000074fc119d2a22  push rdx
000074fc119d2a23  push rdi
000074fc119d2a24  push rsi
000074fc119d2a25  push r8
000074fc119d2a27  push r9
000074fc119d2a29  push r10
000074fc119d2a2b  push r11
000074fc119d2a2d  sub rsp, 0xF0
000074fc119d2a34  vmovaps [rsp], xmm0
000074fc119d2a39  vmovaps [rsp+0x10], xmm2
000074fc119d2a3f  vmovaps [rsp+0x20], xmm3
000074fc119d2a45  vmovaps [rsp+0x30], xmm4
000074fc119d2a4b  vmovaps [rsp+0x40], xmm5
000074fc119d2a51  vmovaps [rsp+0x50], xmm6
000074fc119d2a57  vmovaps [rsp+0x60], xmm7
000074fc119d2a5d  vmovaps [rsp+0x70], xmm8
000074fc119d2a63  vmovaps [rsp+0x80], xmm9
000074fc119d2a6c  vmovaps [rsp+0x90], xmm10
000074fc119d2a75  vmovaps [rsp+0xA0], xmm11
000074fc119d2a7e  vmovaps [rsp+0xB0], xmm12
000074fc119d2a87  vmovaps [rsp+0xC0], xmm13
000074fc119d2a90  vmovaps [rsp+0xD0], xmm14
000074fc119d2a99  vmovaps [rsp+0xE0], xmm15
000074fc119d2aa2  sub rsp, 0x30
000074fc119d2aa6  movaps [rsp], xmm1
000074fc119d2aaa  movaps [rsp+0x10], xmm5
000074fc119d2aaf  movaps [rsp+0x20], xmm13
000074fc119d2ab5  lea rdi, [rsp]
000074fc119d2ab9  mov esi, 0x00
000074fc119d2abe  mov rax, 0x58C4C8091530
000074fc119d2ac8  call rax
000074fc119d2aca  movaps xmm1, [rsp]
000074fc119d2ace  add rsp, 0x30
000074fc119d2ad2  vmovaps xmm0, [rsp]
000074fc119d2ad7  vmovaps xmm2, [rsp+0x10]
000074fc119d2add  vmovaps xmm3, [rsp+0x20]
000074fc119d2ae3  vmovaps xmm4, [rsp+0x30]
000074fc119d2ae9  vmovaps xmm5, [rsp+0x40]
000074fc119d2aef  vmovaps xmm6, [rsp+0x50]
000074fc119d2af5  vmovaps xmm7, [rsp+0x60]
000074fc119d2afb  vmovaps xmm8, [rsp+0x70]
000074fc119d2b01  vmovaps xmm9, [rsp+0x80]
000074fc119d2b0a  vmovaps xmm10, [rsp+0x90]
000074fc119d2b13  vmovaps xmm11, [rsp+0xA0]
000074fc119d2b1c  vmovaps xmm12, [rsp+0xB0]
000074fc119d2b25  vmovaps xmm13, [rsp+0xC0]
000074fc119d2b2e  vmovaps xmm14, [rsp+0xD0]
000074fc119d2b37  vmovaps xmm15, [rsp+0xE0]
000074fc119d2b40  add rsp, 0xF0
000074fc119d2b47  pop r11
000074fc119d2b49  pop r10
000074fc119d2b4b  pop r9
000074fc119d2b4d  pop r8
000074fc119d2b4f  pop rsi
000074fc119d2b50  pop rdi
000074fc119d2b51  pop rdx
000074fc119d2b52  pop rcx
000074fc119d2b53  pop rax
000074fc119d2b54  add rsp, 0x08
000074fc119d2b58  jmp 0x000074FC119CFDB6
000074fc119d2b5d  sub rsp, 0x08
000074fc119d2b61  push rax
000074fc119d2b62  push rcx
000074fc119d2b63  push rdx
000074fc119d2b64  push rdi
000074fc119d2b65  push rsi
000074fc119d2b66  push r8
000074fc119d2b68  push r9
000074fc119d2b6a  push r10
000074fc119d2b6c  push r11
000074fc119d2b6e  sub rsp, 0xF0
000074fc119d2b75  vmovaps [rsp], xmm0
000074fc119d2b7a  vmovaps [rsp+0x10], xmm1
000074fc119d2b80  vmovaps [rsp+0x20], xmm2
000074fc119d2b86  vmovaps [rsp+0x30], xmm3
000074fc119d2b8c  vmovaps [rsp+0x40], xmm4
000074fc119d2b92  vmovaps [rsp+0x50], xmm6
000074fc119d2b98  vmovaps [rsp+0x60], xmm7
000074fc119d2b9e  vmovaps [rsp+0x70], xmm8
000074fc119d2ba4  vmovaps [rsp+0x80], xmm9
000074fc119d2bad  vmovaps [rsp+0x90], xmm10
000074fc119d2bb6  vmovaps [rsp+0xA0], xmm11
000074fc119d2bbf  vmovaps [rsp+0xB0], xmm12
000074fc119d2bc8  vmovaps [rsp+0xC0], xmm13
000074fc119d2bd1  vmovaps [rsp+0xD0], xmm14
000074fc119d2bda  vmovaps [rsp+0xE0], xmm15
000074fc119d2be3  sub rsp, 0x30
000074fc119d2be7  movaps [rsp], xmm5
000074fc119d2beb  movaps [rsp+0x10], xmm2
000074fc119d2bf0  movaps [rsp+0x20], xmm13
000074fc119d2bf6  lea rdi, [rsp]
000074fc119d2bfa  mov esi, 0x00
000074fc119d2bff  mov rax, 0x58C4C8091530
000074fc119d2c09  call rax
000074fc119d2c0b  movaps xmm5, [rsp]
000074fc119d2c0f  add rsp, 0x30
000074fc119d2c13  vmovaps xmm0, [rsp]
000074fc119d2c18  vmovaps xmm1, [rsp+0x10]
000074fc119d2c1e  vmovaps xmm2, [rsp+0x20]
000074fc119d2c24  vmovaps xmm3, [rsp+0x30]
000074fc119d2c2a  vmovaps xmm4, [rsp+0x40]
000074fc119d2c30  vmovaps xmm6, [rsp+0x50]
000074fc119d2c36  vmovaps xmm7, [rsp+0x60]
000074fc119d2c3c  vmovaps xmm8, [rsp+0x70]
000074fc119d2c42  vmovaps xmm9, [rsp+0x80]
000074fc119d2c4b  vmovaps xmm10, [rsp+0x90]
000074fc119d2c54  vmovaps xmm11, [rsp+0xA0]
000074fc119d2c5d  vmovaps xmm12, [rsp+0xB0]
000074fc119d2c66  vmovaps xmm13, [rsp+0xC0]
000074fc119d2c6f  vmovaps xmm14, [rsp+0xD0]
000074fc119d2c78  vmovaps xmm15, [rsp+0xE0]
000074fc119d2c81  add rsp, 0xF0
000074fc119d2c88  pop r11
000074fc119d2c8a  pop r10
000074fc119d2c8c  pop r9
000074fc119d2c8e  pop r8
000074fc119d2c90  pop rsi
000074fc119d2c91  pop rdi
000074fc119d2c92  pop rdx
000074fc119d2c93  pop rcx
000074fc119d2c94  pop rax
000074fc119d2c95  add rsp, 0x08
000074fc119d2c99  jmp 0x000074FC119CFDEC
000074fc119d2c9e  sub rsp, 0x08
000074fc119d2ca2  push rax
000074fc119d2ca3  push rcx
000074fc119d2ca4  push rdx
000074fc119d2ca5  push rdi
000074fc119d2ca6  push rsi
000074fc119d2ca7  push r8
000074fc119d2ca9  push r9
000074fc119d2cab  push r10
000074fc119d2cad  push r11
000074fc119d2caf  sub rsp, 0xF0
000074fc119d2cb6  vmovaps [rsp], xmm0
000074fc119d2cbb  vmovaps [rsp+0x10], xmm1
000074fc119d2cc1  vmovaps [rsp+0x20], xmm2
000074fc119d2cc7  vmovaps [rsp+0x30], xmm3
000074fc119d2ccd  vmovaps [rsp+0x40], xmm4
000074fc119d2cd3  vmovaps [rsp+0x50], xmm5
000074fc119d2cd9  vmovaps [rsp+0x60], xmm6
000074fc119d2cdf  vmovaps [rsp+0x70], xmm7
000074fc119d2ce5  vmovaps [rsp+0x80], xmm8
000074fc119d2cee  vmovaps [rsp+0x90], xmm9
000074fc119d2cf7  vmovaps [rsp+0xA0], xmm10
000074fc119d2d00  vmovaps [rsp+0xB0], xmm11
000074fc119d2d09  vmovaps [rsp+0xC0], xmm12
000074fc119d2d12  vmovaps [rsp+0xD0], xmm14
000074fc119d2d1b  vmovaps [rsp+0xE0], xmm15
000074fc119d2d24  sub rsp, 0x30
000074fc119d2d28  movaps [rsp], xmm13
000074fc119d2d2d  movaps [rsp+0x10], xmm10
000074fc119d2d33  movaps [rsp+0x20], xmm1
000074fc119d2d38  lea rdi, [rsp]
000074fc119d2d3c  mov esi, 0x00
000074fc119d2d41  mov rax, 0x58C4C8091530
000074fc119d2d4b  call rax
000074fc119d2d4d  movaps xmm13, [rsp]
000074fc119d2d52  add rsp, 0x30
000074fc119d2d56  vmovaps xmm0, [rsp]
000074fc119d2d5b  vmovaps xmm1, [rsp+0x10]
000074fc119d2d61  vmovaps xmm2, [rsp+0x20]
000074fc119d2d67  vmovaps xmm3, [rsp+0x30]
000074fc119d2d6d  vmovaps xmm4, [rsp+0x40]
000074fc119d2d73  vmovaps xmm5, [rsp+0x50]
000074fc119d2d79  vmovaps xmm6, [rsp+0x60]
000074fc119d2d7f  vmovaps xmm7, [rsp+0x70]
000074fc119d2d85  vmovaps xmm8, [rsp+0x80]
000074fc119d2d8e  vmovaps xmm9, [rsp+0x90]
000074fc119d2d97  vmovaps xmm10, [rsp+0xA0]
000074fc119d2da0  vmovaps xmm11, [rsp+0xB0]
000074fc119d2da9  vmovaps xmm12, [rsp+0xC0]
000074fc119d2db2  vmovaps xmm14, [rsp+0xD0]
000074fc119d2dbb  vmovaps xmm15, [rsp+0xE0]
000074fc119d2dc4  add rsp, 0xF0
000074fc119d2dcb  pop r11
000074fc119d2dcd  pop r10
000074fc119d2dcf  pop r9
000074fc119d2dd1  pop r8
000074fc119d2dd3  pop rsi
000074fc119d2dd4  pop rdi
000074fc119d2dd5  pop rdx
000074fc119d2dd6  pop rcx
000074fc119d2dd7  pop rax
000074fc119d2dd8  add rsp, 0x08
000074fc119d2ddc  jmp 0x000074FC119CFE15
000074fc119d2de1  sub rsp, 0x08
000074fc119d2de5  push rax
000074fc119d2de6  push rcx
000074fc119d2de7  push rdx
000074fc119d2de8  push rdi
000074fc119d2de9  push rsi
000074fc119d2dea  push r8
000074fc119d2dec  push r9
000074fc119d2dee  push r10
000074fc119d2df0  push r11
000074fc119d2df2  sub rsp, 0xF0
000074fc119d2df9  vmovaps [rsp], xmm0
000074fc119d2dfe  vmovaps [rsp+0x10], xmm2
000074fc119d2e04  vmovaps [rsp+0x20], xmm3
000074fc119d2e0a  vmovaps [rsp+0x30], xmm4
000074fc119d2e10  vmovaps [rsp+0x40], xmm5
000074fc119d2e16  vmovaps [rsp+0x50], xmm6
000074fc119d2e1c  vmovaps [rsp+0x60], xmm7
000074fc119d2e22  vmovaps [rsp+0x70], xmm8
000074fc119d2e28  vmovaps [rsp+0x80], xmm9
000074fc119d2e31  vmovaps [rsp+0x90], xmm10
000074fc119d2e3a  vmovaps [rsp+0xA0], xmm11
000074fc119d2e43  vmovaps [rsp+0xB0], xmm12
000074fc119d2e4c  vmovaps [rsp+0xC0], xmm13
000074fc119d2e55  vmovaps [rsp+0xD0], xmm14
000074fc119d2e5e  vmovaps [rsp+0xE0], xmm15
000074fc119d2e67  sub rsp, 0x30
000074fc119d2e6b  movaps [rsp], xmm1
000074fc119d2e6f  movaps [rsp+0x10], xmm15
000074fc119d2e75  movaps [rsp+0x20], xmm10
000074fc119d2e7b  lea rdi, [rsp]
000074fc119d2e7f  mov esi, 0x00
000074fc119d2e84  mov rax, 0x58C4C8091530
000074fc119d2e8e  call rax
000074fc119d2e90  movaps xmm1, [rsp]
000074fc119d2e94  add rsp, 0x30
000074fc119d2e98  vmovaps xmm0, [rsp]
000074fc119d2e9d  vmovaps xmm2, [rsp+0x10]
000074fc119d2ea3  vmovaps xmm3, [rsp+0x20]
000074fc119d2ea9  vmovaps xmm4, [rsp+0x30]
000074fc119d2eaf  vmovaps xmm5, [rsp+0x40]
000074fc119d2eb5  vmovaps xmm6, [rsp+0x50]
000074fc119d2ebb  vmovaps xmm7, [rsp+0x60]
000074fc119d2ec1  vmovaps xmm8, [rsp+0x70]
000074fc119d2ec7  vmovaps xmm9, [rsp+0x80]
000074fc119d2ed0  vmovaps xmm10, [rsp+0x90]
000074fc119d2ed9  vmovaps xmm11, [rsp+0xA0]
000074fc119d2ee2  vmovaps xmm12, [rsp+0xB0]
000074fc119d2eeb  vmovaps xmm13, [rsp+0xC0]
000074fc119d2ef4  vmovaps xmm14, [rsp+0xD0]
000074fc119d2efd  vmovaps xmm15, [rsp+0xE0]
000074fc119d2f06  add rsp, 0xF0
000074fc119d2f0d  pop r11
000074fc119d2f0f  pop r10
000074fc119d2f11  pop r9
000074fc119d2f13  pop r8
000074fc119d2f15  pop rsi
000074fc119d2f16  pop rdi
000074fc119d2f17  pop rdx
000074fc119d2f18  pop rcx
000074fc119d2f19  pop rax
000074fc119d2f1a  add rsp, 0x08
000074fc119d2f1e  jmp 0x000074FC119CFE34
000074fc119d2f23  sub rsp, 0x08
000074fc119d2f27  push rax
000074fc119d2f28  push rcx
000074fc119d2f29  push rdx
000074fc119d2f2a  push rdi
000074fc119d2f2b  push rsi
000074fc119d2f2c  push r8
000074fc119d2f2e  push r9
000074fc119d2f30  push r10
000074fc119d2f32  push r11
000074fc119d2f34  sub rsp, 0xF0
000074fc119d2f3b  vmovaps [rsp], xmm0
000074fc119d2f40  vmovaps [rsp+0x10], xmm1
000074fc119d2f46  vmovaps [rsp+0x20], xmm2
000074fc119d2f4c  vmovaps [rsp+0x30], xmm3
000074fc119d2f52  vmovaps [rsp+0x40], xmm4
000074fc119d2f58  vmovaps [rsp+0x50], xmm5
000074fc119d2f5e  vmovaps [rsp+0x60], xmm6
000074fc119d2f64  vmovaps [rsp+0x70], xmm7
000074fc119d2f6a  vmovaps [rsp+0x80], xmm8
000074fc119d2f73  vmovaps [rsp+0x90], xmm9
000074fc119d2f7c  vmovaps [rsp+0xA0], xmm10
000074fc119d2f85  vmovaps [rsp+0xB0], xmm11
000074fc119d2f8e  vmovaps [rsp+0xC0], xmm12
000074fc119d2f97  vmovaps [rsp+0xD0], xmm13
000074fc119d2fa0  vmovaps [rsp+0xE0], xmm14
000074fc119d2fa9  sub rsp, 0x30
000074fc119d2fad  movaps [rsp], xmm15
000074fc119d2fb2  movaps [rsp+0x10], xmm10
000074fc119d2fb8  movaps [rsp+0x20], xmm11
000074fc119d2fbe  lea rdi, [rsp]
000074fc119d2fc2  mov esi, 0x00
000074fc119d2fc7  mov rax, 0x58C4C8091530
000074fc119d2fd1  call rax
000074fc119d2fd3  movaps xmm15, [rsp]
000074fc119d2fd8  add rsp, 0x30
000074fc119d2fdc  vmovaps xmm0, [rsp]
000074fc119d2fe1  vmovaps xmm1, [rsp+0x10]
000074fc119d2fe7  vmovaps xmm2, [rsp+0x20]
000074fc119d2fed  vmovaps xmm3, [rsp+0x30]
000074fc119d2ff3  vmovaps xmm4, [rsp+0x40]
000074fc119d2ff9  vmovaps xmm5, [rsp+0x50]
000074fc119d2fff  vmovaps xmm6, [rsp+0x60]
000074fc119d3005  vmovaps xmm7, [rsp+0x70]
000074fc119d300b  vmovaps xmm8, [rsp+0x80]
000074fc119d3014  vmovaps xmm9, [rsp+0x90]
000074fc119d301d  vmovaps xmm10, [rsp+0xA0]
000074fc119d3026  vmovaps xmm11, [rsp+0xB0]
000074fc119d302f  vmovaps xmm12, [rsp+0xC0]
000074fc119d3038  vmovaps xmm13, [rsp+0xD0]
000074fc119d3041  vmovaps xmm14, [rsp+0xE0]
000074fc119d304a  add rsp, 0xF0
000074fc119d3051  pop r11
000074fc119d3053  pop r10
000074fc119d3055  pop r9
000074fc119d3057  pop r8
000074fc119d3059  pop rsi
000074fc119d305a  pop rdi
000074fc119d305b  pop rdx
000074fc119d305c  pop rcx
000074fc119d305d  pop rax
000074fc119d305e  add rsp, 0x08
000074fc119d3062  jmp 0x000074FC119CFE57
000074fc119d3067  sub rsp, 0x08
000074fc119d306b  push rax
000074fc119d306c  push rcx
000074fc119d306d  push rdx
000074fc119d306e  push rdi
000074fc119d306f  push rsi
000074fc119d3070  push r8
000074fc119d3072  push r9
000074fc119d3074  push r10
000074fc119d3076  push r11
000074fc119d3078  sub rsp, 0xF0
000074fc119d307f  vmovaps [rsp], xmm0
000074fc119d3084  vmovaps [rsp+0x10], xmm1
000074fc119d308a  vmovaps [rsp+0x20], xmm2
000074fc119d3090  vmovaps [rsp+0x30], xmm3
000074fc119d3096  vmovaps [rsp+0x40], xmm4
000074fc119d309c  vmovaps [rsp+0x50], xmm5
000074fc119d30a2  vmovaps [rsp+0x60], xmm6
000074fc119d30a8  vmovaps [rsp+0x70], xmm7
000074fc119d30ae  vmovaps [rsp+0x80], xmm8
000074fc119d30b7  vmovaps [rsp+0x90], xmm9
000074fc119d30c0  vmovaps [rsp+0xA0], xmm11
000074fc119d30c9  vmovaps [rsp+0xB0], xmm12
000074fc119d30d2  vmovaps [rsp+0xC0], xmm13
000074fc119d30db  vmovaps [rsp+0xD0], xmm14
000074fc119d30e4  vmovaps [rsp+0xE0], xmm15
000074fc119d30ed  sub rsp, 0x30
000074fc119d30f1  movaps [rsp], xmm10
000074fc119d30f6  movaps [rsp+0x10], xmm12
000074fc119d30fc  movaps [rsp+0x20], xmm11
000074fc119d3102  lea rdi, [rsp]
000074fc119d3106  mov esi, 0x00
000074fc119d310b  mov rax, 0x58C4C8091530
000074fc119d3115  call rax
000074fc119d3117  movaps xmm10, [rsp]
000074fc119d311c  add rsp, 0x30
000074fc119d3120  vmovaps xmm0, [rsp]
000074fc119d3125  vmovaps xmm1, [rsp+0x10]
000074fc119d312b  vmovaps xmm2, [rsp+0x20]
000074fc119d3131  vmovaps xmm3, [rsp+0x30]
000074fc119d3137  vmovaps xmm4, [rsp+0x40]
000074fc119d313d  vmovaps xmm5, [rsp+0x50]
000074fc119d3143  vmovaps xmm6, [rsp+0x60]
000074fc119d3149  vmovaps xmm7, [rsp+0x70]
000074fc119d314f  vmovaps xmm8, [rsp+0x80]
000074fc119d3158  vmovaps xmm9, [rsp+0x90]
000074fc119d3161  vmovaps xmm11, [rsp+0xA0]
000074fc119d316a  vmovaps xmm12, [rsp+0xB0]
000074fc119d3173  vmovaps xmm13, [rsp+0xC0]
000074fc119d317c  vmovaps xmm14, [rsp+0xD0]
000074fc119d3185  vmovaps xmm15, [rsp+0xE0]
000074fc119d318e  add rsp, 0xF0
000074fc119d3195  pop r11
000074fc119d3197  pop r10
000074fc119d3199  pop r9
000074fc119d319b  pop r8
000074fc119d319d  pop rsi
000074fc119d319e  pop rdi
000074fc119d319f  pop rdx
000074fc119d31a0  pop rcx
000074fc119d31a1  pop rax
000074fc119d31a2  add rsp, 0x08
000074fc119d31a6  jmp 0x000074FC119CFE80
000074fc119d31ab  sub rsp, 0x08
000074fc119d31af  push rax
000074fc119d31b0  push rcx
000074fc119d31b1  push rdx
000074fc119d31b2  push rdi
000074fc119d31b3  push rsi
000074fc119d31b4  push r8
000074fc119d31b6  push r9
000074fc119d31b8  push r10
000074fc119d31ba  push r11
000074fc119d31bc  sub rsp, 0xF0
000074fc119d31c3  vmovaps [rsp], xmm0
000074fc119d31c8  vmovaps [rsp+0x10], xmm1
000074fc119d31ce  vmovaps [rsp+0x20], xmm2
000074fc119d31d4  vmovaps [rsp+0x30], xmm3
000074fc119d31da  vmovaps [rsp+0x40], xmm4
000074fc119d31e0  vmovaps [rsp+0x50], xmm5
000074fc119d31e6  vmovaps [rsp+0x60], xmm6
000074fc119d31ec  vmovaps [rsp+0x70], xmm7
000074fc119d31f2  vmovaps [rsp+0x80], xmm8
000074fc119d31fb  vmovaps [rsp+0x90], xmm9
000074fc119d3204  vmovaps [rsp+0xA0], xmm10
000074fc119d320d  vmovaps [rsp+0xB0], xmm12
000074fc119d3216  vmovaps [rsp+0xC0], xmm13
000074fc119d321f  vmovaps [rsp+0xD0], xmm14
000074fc119d3228  vmovaps [rsp+0xE0], xmm15
000074fc119d3231  sub rsp, 0x30
000074fc119d3235  movaps [rsp], xmm11
000074fc119d323a  movaps [rsp+0x10], xmm2
000074fc119d323f  movaps [rsp+0x20], xmm12
000074fc119d3245  lea rdi, [rsp]
000074fc119d3249  mov esi, 0x00
000074fc119d324e  mov rax, 0x58C4C8091530
000074fc119d3258  call rax
000074fc119d325a  movaps xmm11, [rsp]
000074fc119d325f  add rsp, 0x30
000074fc119d3263  vmovaps xmm0, [rsp]
000074fc119d3268  vmovaps xmm1, [rsp+0x10]
000074fc119d326e  vmovaps xmm2, [rsp+0x20]
000074fc119d3274  vmovaps xmm3, [rsp+0x30]
000074fc119d327a  vmovaps xmm4, [rsp+0x40]
000074fc119d3280  vmovaps xmm5, [rsp+0x50]
000074fc119d3286  vmovaps xmm6, [rsp+0x60]
000074fc119d328c  vmovaps xmm7, [rsp+0x70]
000074fc119d3292  vmovaps xmm8, [rsp+0x80]
000074fc119d329b  vmovaps xmm9, [rsp+0x90]
000074fc119d32a4  vmovaps xmm10, [rsp+0xA0]
000074fc119d32ad  vmovaps xmm12, [rsp+0xB0]
000074fc119d32b6  vmovaps xmm13, [rsp+0xC0]
000074fc119d32bf  vmovaps xmm14, [rsp+0xD0]
000074fc119d32c8  vmovaps xmm15, [rsp+0xE0]
000074fc119d32d1  add rsp, 0xF0
000074fc119d32d8  pop r11
000074fc119d32da  pop r10
000074fc119d32dc  pop r9
000074fc119d32de  pop r8
000074fc119d32e0  pop rsi
000074fc119d32e1  pop rdi
000074fc119d32e2  pop rdx
000074fc119d32e3  pop rcx
000074fc119d32e4  pop rax
000074fc119d32e5  add rsp, 0x08
000074fc119d32e9  jmp 0x000074FC119CFEB8
000074fc119d32ee  sub rsp, 0x08
000074fc119d32f2  push rax
000074fc119d32f3  push rcx
000074fc119d32f4  push rdx
000074fc119d32f5  push rdi
000074fc119d32f6  push rsi
000074fc119d32f7  push r8
000074fc119d32f9  push r9
000074fc119d32fb  push r10
000074fc119d32fd  push r11
000074fc119d32ff  sub rsp, 0xF0
000074fc119d3306  vmovaps [rsp], xmm0
000074fc119d330b  vmovaps [rsp+0x10], xmm2
000074fc119d3311  vmovaps [rsp+0x20], xmm3
000074fc119d3317  vmovaps [rsp+0x30], xmm4
000074fc119d331d  vmovaps [rsp+0x40], xmm5
000074fc119d3323  vmovaps [rsp+0x50], xmm6
000074fc119d3329  vmovaps [rsp+0x60], xmm7
000074fc119d332f  vmovaps [rsp+0x70], xmm8
000074fc119d3335  vmovaps [rsp+0x80], xmm9
000074fc119d333e  vmovaps [rsp+0x90], xmm10
000074fc119d3347  vmovaps [rsp+0xA0], xmm11
000074fc119d3350  vmovaps [rsp+0xB0], xmm12
000074fc119d3359  vmovaps [rsp+0xC0], xmm13
000074fc119d3362  vmovaps [rsp+0xD0], xmm14
000074fc119d336b  vmovaps [rsp+0xE0], xmm15
000074fc119d3374  sub rsp, 0x30
000074fc119d3378  movaps [rsp], xmm1
000074fc119d337c  movaps [rsp+0x10], xmm14
000074fc119d3382  movaps [rsp+0x20], xmm6
000074fc119d3387  lea rdi, [rsp]
000074fc119d338b  mov esi, 0x00
000074fc119d3390  mov rax, 0x58C4C8091530
000074fc119d339a  call rax
000074fc119d339c  movaps xmm1, [rsp]
000074fc119d33a0  add rsp, 0x30
000074fc119d33a4  vmovaps xmm0, [rsp]
000074fc119d33a9  vmovaps xmm2, [rsp+0x10]
000074fc119d33af  vmovaps xmm3, [rsp+0x20]
000074fc119d33b5  vmovaps xmm4, [rsp+0x30]
000074fc119d33bb  vmovaps xmm5, [rsp+0x40]
000074fc119d33c1  vmovaps xmm6, [rsp+0x50]
000074fc119d33c7  vmovaps xmm7, [rsp+0x60]
000074fc119d33cd  vmovaps xmm8, [rsp+0x70]
000074fc119d33d3  vmovaps xmm9, [rsp+0x80]
000074fc119d33dc  vmovaps xmm10, [rsp+0x90]
000074fc119d33e5  vmovaps xmm11, [rsp+0xA0]
000074fc119d33ee  vmovaps xmm12, [rsp+0xB0]
000074fc119d33f7  vmovaps xmm13, [rsp+0xC0]
000074fc119d3400  vmovaps xmm14, [rsp+0xD0]
000074fc119d3409  vmovaps xmm15, [rsp+0xE0]
000074fc119d3412  add rsp, 0xF0
000074fc119d3419  pop r11
000074fc119d341b  pop r10
000074fc119d341d  pop r9
000074fc119d341f  pop r8
000074fc119d3421  pop rsi
000074fc119d3422  pop rdi
000074fc119d3423  pop rdx
000074fc119d3424  pop rcx
000074fc119d3425  pop rax
000074fc119d3426  add rsp, 0x08
000074fc119d342a  jmp 0x000074FC119CFED1
000074fc119d342f  sub rsp, 0x08
000074fc119d3433  push rax
000074fc119d3434  push rcx
000074fc119d3435  push rdx
000074fc119d3436  push rdi
000074fc119d3437  push rsi
000074fc119d3438  push r8
000074fc119d343a  push r9
000074fc119d343c  push r10
000074fc119d343e  push r11
000074fc119d3440  sub rsp, 0xF0
000074fc119d3447  vmovaps [rsp], xmm0
000074fc119d344c  vmovaps [rsp+0x10], xmm1
000074fc119d3452  vmovaps [rsp+0x20], xmm2
000074fc119d3458  vmovaps [rsp+0x30], xmm3
000074fc119d345e  vmovaps [rsp+0x40], xmm4
000074fc119d3464  vmovaps [rsp+0x50], xmm5
000074fc119d346a  vmovaps [rsp+0x60], xmm6
000074fc119d3470  vmovaps [rsp+0x70], xmm7
000074fc119d3476  vmovaps [rsp+0x80], xmm8
000074fc119d347f  vmovaps [rsp+0x90], xmm9
000074fc119d3488  vmovaps [rsp+0xA0], xmm10
000074fc119d3491  vmovaps [rsp+0xB0], xmm11
000074fc119d349a  vmovaps [rsp+0xC0], xmm12
000074fc119d34a3  vmovaps [rsp+0xD0], xmm13
000074fc119d34ac  vmovaps [rsp+0xE0], xmm15
000074fc119d34b5  sub rsp, 0x30
000074fc119d34b9  movaps [rsp], xmm14
000074fc119d34be  movaps [rsp+0x10], xmm12
000074fc119d34c4  movaps [rsp+0x20], xmm5
000074fc119d34c9  lea rdi, [rsp]
000074fc119d34cd  mov esi, 0x00
000074fc119d34d2  mov rax, 0x58C4C8091530
000074fc119d34dc  call rax
000074fc119d34de  movaps xmm14, [rsp]
000074fc119d34e3  add rsp, 0x30
000074fc119d34e7  vmovaps xmm0, [rsp]
000074fc119d34ec  vmovaps xmm1, [rsp+0x10]
000074fc119d34f2  vmovaps xmm2, [rsp+0x20]
000074fc119d34f8  vmovaps xmm3, [rsp+0x30]
000074fc119d34fe  vmovaps xmm4, [rsp+0x40]
000074fc119d3504  vmovaps xmm5, [rsp+0x50]
000074fc119d350a  vmovaps xmm6, [rsp+0x60]
000074fc119d3510  vmovaps xmm7, [rsp+0x70]
000074fc119d3516  vmovaps xmm8, [rsp+0x80]
000074fc119d351f  vmovaps xmm9, [rsp+0x90]
000074fc119d3528  vmovaps xmm10, [rsp+0xA0]
000074fc119d3531  vmovaps xmm11, [rsp+0xB0]
000074fc119d353a  vmovaps xmm12, [rsp+0xC0]
000074fc119d3543  vmovaps xmm13, [rsp+0xD0]
000074fc119d354c  vmovaps xmm15, [rsp+0xE0]
000074fc119d3555  add rsp, 0xF0
000074fc119d355c  pop r11
000074fc119d355e  pop r10
000074fc119d3560  pop r9
000074fc119d3562  pop r8
000074fc119d3564  pop rsi
000074fc119d3565  pop rdi
000074fc119d3566  pop rdx
000074fc119d3567  pop rcx
000074fc119d3568  pop rax
000074fc119d3569  add rsp, 0x08
000074fc119d356d  jmp 0x000074FC119CFEF1
000074fc119d3572  sub rsp, 0x08
000074fc119d3576  push rax
000074fc119d3577  push rcx
000074fc119d3578  push rdx
000074fc119d3579  push rdi
000074fc119d357a  push rsi
000074fc119d357b  push r8
000074fc119d357d  push r9
000074fc119d357f  push r10
000074fc119d3581  push r11
000074fc119d3583  sub rsp, 0xF0
000074fc119d358a  vmovaps [rsp], xmm0
000074fc119d358f  vmovaps [rsp+0x10], xmm1
000074fc119d3595  vmovaps [rsp+0x20], xmm2
000074fc119d359b  vmovaps [rsp+0x30], xmm3
000074fc119d35a1  vmovaps [rsp+0x40], xmm4
000074fc119d35a7  vmovaps [rsp+0x50], xmm5
000074fc119d35ad  vmovaps [rsp+0x60], xmm7
000074fc119d35b3  vmovaps [rsp+0x70], xmm8
000074fc119d35b9  vmovaps [rsp+0x80], xmm9
000074fc119d35c2  vmovaps [rsp+0x90], xmm10
000074fc119d35cb  vmovaps [rsp+0xA0], xmm11
000074fc119d35d4  vmovaps [rsp+0xB0], xmm12
000074fc119d35dd  vmovaps [rsp+0xC0], xmm13
000074fc119d35e6  vmovaps [rsp+0xD0], xmm14
000074fc119d35ef  vmovaps [rsp+0xE0], xmm15
000074fc119d35f8  sub rsp, 0x30
000074fc119d35fc  movaps [rsp], xmm6
000074fc119d3600  movaps [rsp+0x10], xmm9
000074fc119d3606  movaps [rsp+0x20], xmm12
000074fc119d360c  lea rdi, [rsp]
000074fc119d3610  mov esi, 0x00
000074fc119d3615  mov rax, 0x58C4C8091530
000074fc119d361f  call rax
000074fc119d3621  movaps xmm6, [rsp]
000074fc119d3625  add rsp, 0x30
000074fc119d3629  vmovaps xmm0, [rsp]
000074fc119d362e  vmovaps xmm1, [rsp+0x10]
000074fc119d3634  vmovaps xmm2, [rsp+0x20]
000074fc119d363a  vmovaps xmm3, [rsp+0x30]
000074fc119d3640  vmovaps xmm4, [rsp+0x40]
000074fc119d3646  vmovaps xmm5, [rsp+0x50]
000074fc119d364c  vmovaps xmm7, [rsp+0x60]
000074fc119d3652  vmovaps xmm8, [rsp+0x70]
000074fc119d3658  vmovaps xmm9, [rsp+0x80]
000074fc119d3661  vmovaps xmm10, [rsp+0x90]
000074fc119d366a  vmovaps xmm11, [rsp+0xA0]
000074fc119d3673  vmovaps xmm12, [rsp+0xB0]
000074fc119d367c  vmovaps xmm13, [rsp+0xC0]
000074fc119d3685  vmovaps xmm14, [rsp+0xD0]
000074fc119d368e  vmovaps xmm15, [rsp+0xE0]
000074fc119d3697  add rsp, 0xF0
000074fc119d369e  pop r11
000074fc119d36a0  pop r10
000074fc119d36a2  pop r9
000074fc119d36a4  pop r8
000074fc119d36a6  pop rsi
000074fc119d36a7  pop rdi
000074fc119d36a8  pop rdx
000074fc119d36a9  pop rcx
000074fc119d36aa  pop rax
000074fc119d36ab  add rsp, 0x08
000074fc119d36af  jmp 0x000074FC119CFF19
000074fc119d36b4  sub rsp, 0x08
000074fc119d36b8  push rax
000074fc119d36b9  push rcx
000074fc119d36ba  push rdx
000074fc119d36bb  push rdi
000074fc119d36bc  push rsi
000074fc119d36bd  push r8
000074fc119d36bf  push r9
000074fc119d36c1  push r10
000074fc119d36c3  push r11
000074fc119d36c5  sub rsp, 0xF0
000074fc119d36cc  vmovaps [rsp], xmm0
000074fc119d36d1  vmovaps [rsp+0x10], xmm1
000074fc119d36d7  vmovaps [rsp+0x20], xmm2
000074fc119d36dd  vmovaps [rsp+0x30], xmm3
000074fc119d36e3  vmovaps [rsp+0x40], xmm4
000074fc119d36e9  vmovaps [rsp+0x50], xmm5
000074fc119d36ef  vmovaps [rsp+0x60], xmm6
000074fc119d36f5  vmovaps [rsp+0x70], xmm7
000074fc119d36fb  vmovaps [rsp+0x80], xmm8
000074fc119d3704  vmovaps [rsp+0x90], xmm9
000074fc119d370d  vmovaps [rsp+0xA0], xmm10
000074fc119d3716  vmovaps [rsp+0xB0], xmm11
000074fc119d371f  vmovaps [rsp+0xC0], xmm13
000074fc119d3728  vmovaps [rsp+0xD0], xmm14
000074fc119d3731  vmovaps [rsp+0xE0], xmm15
000074fc119d373a  sub rsp, 0x30
000074fc119d373e  movaps [rsp], xmm12
000074fc119d3743  movaps [rsp+0x10], xmm15
000074fc119d3749  movaps [rsp+0x20], xmm13
000074fc119d374f  lea rdi, [rsp]
000074fc119d3753  mov esi, 0x00
000074fc119d3758  mov rax, 0x58C4C8091530
000074fc119d3762  call rax
000074fc119d3764  movaps xmm12, [rsp]
000074fc119d3769  add rsp, 0x30
000074fc119d376d  vmovaps xmm0, [rsp]
000074fc119d3772  vmovaps xmm1, [rsp+0x10]
000074fc119d3778  vmovaps xmm2, [rsp+0x20]
000074fc119d377e  vmovaps xmm3, [rsp+0x30]
000074fc119d3784  vmovaps xmm4, [rsp+0x40]
000074fc119d378a  vmovaps xmm5, [rsp+0x50]
000074fc119d3790  vmovaps xmm6, [rsp+0x60]
000074fc119d3796  vmovaps xmm7, [rsp+0x70]
000074fc119d379c  vmovaps xmm8, [rsp+0x80]
000074fc119d37a5  vmovaps xmm9, [rsp+0x90]
000074fc119d37ae  vmovaps xmm10, [rsp+0xA0]
000074fc119d37b7  vmovaps xmm11, [rsp+0xB0]
000074fc119d37c0  vmovaps xmm13, [rsp+0xC0]
000074fc119d37c9  vmovaps xmm14, [rsp+0xD0]
000074fc119d37d2  vmovaps xmm15, [rsp+0xE0]
000074fc119d37db  add rsp, 0xF0
000074fc119d37e2  pop r11
000074fc119d37e4  pop r10
000074fc119d37e6  pop r9
000074fc119d37e8  pop r8
000074fc119d37ea  pop rsi
000074fc119d37eb  pop rdi
000074fc119d37ec  pop rdx
000074fc119d37ed  pop rcx
000074fc119d37ee  pop rax
000074fc119d37ef  add rsp, 0x08
000074fc119d37f3  jmp 0x000074FC119CFF34
000074fc119d37f8  sub rsp, 0x08
000074fc119d37fc  push rax
000074fc119d37fd  push rcx
000074fc119d37fe  push rdx
000074fc119d37ff  push rdi
000074fc119d3800  push rsi
000074fc119d3801  push r8
000074fc119d3803  push r9
000074fc119d3805  push r10
000074fc119d3807  push r11
000074fc119d3809  sub rsp, 0xF0
000074fc119d3810  vmovaps [rsp], xmm0
000074fc119d3815  vmovaps [rsp+0x10], xmm1
000074fc119d381b  vmovaps [rsp+0x20], xmm2
000074fc119d3821  vmovaps [rsp+0x30], xmm3
000074fc119d3827  vmovaps [rsp+0x40], xmm4
000074fc119d382d  vmovaps [rsp+0x50], xmm5
000074fc119d3833  vmovaps [rsp+0x60], xmm6
000074fc119d3839  vmovaps [rsp+0x70], xmm7
000074fc119d383f  vmovaps [rsp+0x80], xmm8
000074fc119d3848  vmovaps [rsp+0x90], xmm9
000074fc119d3851  vmovaps [rsp+0xA0], xmm10
000074fc119d385a  vmovaps [rsp+0xB0], xmm11
000074fc119d3863  vmovaps [rsp+0xC0], xmm12
000074fc119d386c  vmovaps [rsp+0xD0], xmm13
000074fc119d3875  vmovaps [rsp+0xE0], xmm14
000074fc119d387e  sub rsp, 0x30
000074fc119d3882  movaps [rsp], xmm15
000074fc119d3887  movaps [rsp+0x10], xmm13
000074fc119d388d  movaps [rsp+0x20], xmm10
000074fc119d3893  lea rdi, [rsp]
000074fc119d3897  mov esi, 0x00
000074fc119d389c  mov rax, 0x58C4C8091530
000074fc119d38a6  call rax
000074fc119d38a8  movaps xmm15, [rsp]
000074fc119d38ad  add rsp, 0x30
000074fc119d38b1  vmovaps xmm0, [rsp]
000074fc119d38b6  vmovaps xmm1, [rsp+0x10]
000074fc119d38bc  vmovaps xmm2, [rsp+0x20]
000074fc119d38c2  vmovaps xmm3, [rsp+0x30]
000074fc119d38c8  vmovaps xmm4, [rsp+0x40]
000074fc119d38ce  vmovaps xmm5, [rsp+0x50]
000074fc119d38d4  vmovaps xmm6, [rsp+0x60]
000074fc119d38da  vmovaps xmm7, [rsp+0x70]
000074fc119d38e0  vmovaps xmm8, [rsp+0x80]
000074fc119d38e9  vmovaps xmm9, [rsp+0x90]
000074fc119d38f2  vmovaps xmm10, [rsp+0xA0]
000074fc119d38fb  vmovaps xmm11, [rsp+0xB0]
000074fc119d3904  vmovaps xmm12, [rsp+0xC0]
000074fc119d390d  vmovaps xmm13, [rsp+0xD0]
000074fc119d3916  vmovaps xmm14, [rsp+0xE0]
000074fc119d391f  add rsp, 0xF0
000074fc119d3926  pop r11
000074fc119d3928  pop r10
000074fc119d392a  pop r9
000074fc119d392c  pop r8
000074fc119d392e  pop rsi
000074fc119d392f  pop rdi
000074fc119d3930  pop rdx
000074fc119d3931  pop rcx
000074fc119d3932  pop rax
000074fc119d3933  add rsp, 0x08
000074fc119d3937  jmp 0x000074FC119CFF55
000074fc119d393c  call 0x000074FC1180C260
000074fc119d3941  jmp 0x000074FC119CFFB0
000074fc119d3946  sub rsp, 0x08
000074fc119d394a  push rax
000074fc119d394b  push rcx
000074fc119d394c  push rdx
000074fc119d394d  push rdi
000074fc119d394e  push rsi
000074fc119d394f  push r8
000074fc119d3951  push r9
000074fc119d3953  push r10
000074fc119d3955  push r11
000074fc119d3957  sub rsp, 0xF0
000074fc119d395e  vmovaps [rsp], xmm0
000074fc119d3963  vmovaps [rsp+0x10], xmm1
000074fc119d3969  vmovaps [rsp+0x20], xmm2
000074fc119d396f  vmovaps [rsp+0x30], xmm3
000074fc119d3975  vmovaps [rsp+0x40], xmm4
000074fc119d397b  vmovaps [rsp+0x50], xmm5
000074fc119d3981  vmovaps [rsp+0x60], xmm6
000074fc119d3987  vmovaps [rsp+0x70], xmm7
000074fc119d398d  vmovaps [rsp+0x80], xmm8
000074fc119d3996  vmovaps [rsp+0x90], xmm10
000074fc119d399f  vmovaps [rsp+0xA0], xmm11
000074fc119d39a8  vmovaps [rsp+0xB0], xmm12
000074fc119d39b1  vmovaps [rsp+0xC0], xmm13
000074fc119d39ba  vmovaps [rsp+0xD0], xmm14
000074fc119d39c3  vmovaps [rsp+0xE0], xmm15
000074fc119d39cc  sub rsp, 0x30
000074fc119d39d0  movaps [rsp], xmm9
000074fc119d39d5  movaps [rsp+0x10], xmm8
000074fc119d39db  movaps [rsp+0x20], xmm10
000074fc119d39e1  lea rdi, [rsp]
000074fc119d39e5  mov esi, 0x00
000074fc119d39ea  mov rax, 0x58C4C8091530
000074fc119d39f4  call rax
000074fc119d39f6  movaps xmm9, [rsp]
000074fc119d39fb  add rsp, 0x30
000074fc119d39ff  vmovaps xmm0, [rsp]
000074fc119d3a04  vmovaps xmm1, [rsp+0x10]
000074fc119d3a0a  vmovaps xmm2, [rsp+0x20]
000074fc119d3a10  vmovaps xmm3, [rsp+0x30]
000074fc119d3a16  vmovaps xmm4, [rsp+0x40]
000074fc119d3a1c  vmovaps xmm5, [rsp+0x50]
000074fc119d3a22  vmovaps xmm6, [rsp+0x60]
000074fc119d3a28  vmovaps xmm7, [rsp+0x70]
000074fc119d3a2e  vmovaps xmm8, [rsp+0x80]
000074fc119d3a37  vmovaps xmm10, [rsp+0x90]
000074fc119d3a40  vmovaps xmm11, [rsp+0xA0]
000074fc119d3a49  vmovaps xmm12, [rsp+0xB0]
000074fc119d3a52  vmovaps xmm13, [rsp+0xC0]
000074fc119d3a5b  vmovaps xmm14, [rsp+0xD0]
000074fc119d3a64  vmovaps xmm15, [rsp+0xE0]
000074fc119d3a6d  add rsp, 0xF0
000074fc119d3a74  pop r11
000074fc119d3a76  pop r10
000074fc119d3a78  pop r9
000074fc119d3a7a  pop r8
000074fc119d3a7c  pop rsi
000074fc119d3a7d  pop rdi
000074fc119d3a7e  pop rdx
000074fc119d3a7f  pop rcx
000074fc119d3a80  pop rax
000074fc119d3a81  add rsp, 0x08
000074fc119d3a85  jmp 0x000074FC119CFFE1
000074fc119d3a8a  sub rsp, 0x08
000074fc119d3a8e  push rax
000074fc119d3a8f  push rcx
000074fc119d3a90  push rdx
000074fc119d3a91  push rdi
000074fc119d3a92  push rsi
000074fc119d3a93  push r8
000074fc119d3a95  push r9
000074fc119d3a97  push r10
000074fc119d3a99  push r11
000074fc119d3a9b  sub rsp, 0xF0
000074fc119d3aa2  vmovaps [rsp], xmm0
000074fc119d3aa7  vmovaps [rsp+0x10], xmm1
000074fc119d3aad  vmovaps [rsp+0x20], xmm2
000074fc119d3ab3  vmovaps [rsp+0x30], xmm3
000074fc119d3ab9  vmovaps [rsp+0x40], xmm4
000074fc119d3abf  vmovaps [rsp+0x50], xmm5
000074fc119d3ac5  vmovaps [rsp+0x60], xmm6
000074fc119d3acb  vmovaps [rsp+0x70], xmm7
000074fc119d3ad1  vmovaps [rsp+0x80], xmm8
000074fc119d3ada  vmovaps [rsp+0x90], xmm9
000074fc119d3ae3  vmovaps [rsp+0xA0], xmm11
000074fc119d3aec  vmovaps [rsp+0xB0], xmm12
000074fc119d3af5  vmovaps [rsp+0xC0], xmm13
000074fc119d3afe  vmovaps [rsp+0xD0], xmm14
000074fc119d3b07  vmovaps [rsp+0xE0], xmm15
000074fc119d3b10  sub rsp, 0x30
000074fc119d3b14  movaps [rsp], xmm10
000074fc119d3b19  movaps [rsp+0x10], xmm1
000074fc119d3b1e  movaps [rsp+0x20], xmm11
000074fc119d3b24  lea rdi, [rsp]
000074fc119d3b28  mov esi, 0x00
000074fc119d3b2d  mov rax, 0x58C4C8091530
000074fc119d3b37  call rax
000074fc119d3b39  movaps xmm10, [rsp]
000074fc119d3b3e  add rsp, 0x30
000074fc119d3b42  vmovaps xmm0, [rsp]
000074fc119d3b47  vmovaps xmm1, [rsp+0x10]
000074fc119d3b4d  vmovaps xmm2, [rsp+0x20]
000074fc119d3b53  vmovaps xmm3, [rsp+0x30]
000074fc119d3b59  vmovaps xmm4, [rsp+0x40]
000074fc119d3b5f  vmovaps xmm5, [rsp+0x50]
000074fc119d3b65  vmovaps xmm6, [rsp+0x60]
000074fc119d3b6b  vmovaps xmm7, [rsp+0x70]
000074fc119d3b71  vmovaps xmm8, [rsp+0x80]
000074fc119d3b7a  vmovaps xmm9, [rsp+0x90]
000074fc119d3b83  vmovaps xmm11, [rsp+0xA0]
000074fc119d3b8c  vmovaps xmm12, [rsp+0xB0]
000074fc119d3b95  vmovaps xmm13, [rsp+0xC0]
000074fc119d3b9e  vmovaps xmm14, [rsp+0xD0]
000074fc119d3ba7  vmovaps xmm15, [rsp+0xE0]
000074fc119d3bb0  add rsp, 0xF0
000074fc119d3bb7  pop r11
000074fc119d3bb9  pop r10
000074fc119d3bbb  pop r9
000074fc119d3bbd  pop r8
000074fc119d3bbf  pop rsi
000074fc119d3bc0  pop rdi
000074fc119d3bc1  pop rdx
000074fc119d3bc2  pop rcx
000074fc119d3bc3  pop rax
000074fc119d3bc4  add rsp, 0x08
000074fc119d3bc8  jmp 0x000074FC119CFFFC
000074fc119d3bcd  sub rsp, 0x08
000074fc119d3bd1  push rax
000074fc119d3bd2  push rcx
000074fc119d3bd3  push rdx
000074fc119d3bd4  push rdi
000074fc119d3bd5  push rsi
000074fc119d3bd6  push r8
000074fc119d3bd8  push r9
000074fc119d3bda  push r10
000074fc119d3bdc  push r11
000074fc119d3bde  sub rsp, 0xF0
000074fc119d3be5  vmovaps [rsp], xmm0
000074fc119d3bea  vmovaps [rsp+0x10], xmm2
000074fc119d3bf0  vmovaps [rsp+0x20], xmm3
000074fc119d3bf6  vmovaps [rsp+0x30], xmm4
000074fc119d3bfc  vmovaps [rsp+0x40], xmm5
000074fc119d3c02  vmovaps [rsp+0x50], xmm6
000074fc119d3c08  vmovaps [rsp+0x60], xmm7
000074fc119d3c0e  vmovaps [rsp+0x70], xmm8
000074fc119d3c14  vmovaps [rsp+0x80], xmm9
000074fc119d3c1d  vmovaps [rsp+0x90], xmm10
000074fc119d3c26  vmovaps [rsp+0xA0], xmm11
000074fc119d3c2f  vmovaps [rsp+0xB0], xmm12
000074fc119d3c38  vmovaps [rsp+0xC0], xmm13
000074fc119d3c41  vmovaps [rsp+0xD0], xmm14
000074fc119d3c4a  vmovaps [rsp+0xE0], xmm15
000074fc119d3c53  sub rsp, 0x30
000074fc119d3c57  movaps [rsp], xmm1
000074fc119d3c5b  movaps [rsp+0x10], xmm14
000074fc119d3c61  movaps [rsp+0x20], xmm6
000074fc119d3c66  lea rdi, [rsp]
000074fc119d3c6a  mov esi, 0x00
000074fc119d3c6f  mov rax, 0x58C4C8091530
000074fc119d3c79  call rax
000074fc119d3c7b  movaps xmm1, [rsp]
000074fc119d3c7f  add rsp, 0x30
000074fc119d3c83  vmovaps xmm0, [rsp]
000074fc119d3c88  vmovaps xmm2, [rsp+0x10]
000074fc119d3c8e  vmovaps xmm3, [rsp+0x20]
000074fc119d3c94  vmovaps xmm4, [rsp+0x30]
000074fc119d3c9a  vmovaps xmm5, [rsp+0x40]
000074fc119d3ca0  vmovaps xmm6, [rsp+0x50]
000074fc119d3ca6  vmovaps xmm7, [rsp+0x60]
000074fc119d3cac  vmovaps xmm8, [rsp+0x70]
000074fc119d3cb2  vmovaps xmm9, [rsp+0x80]
000074fc119d3cbb  vmovaps xmm10, [rsp+0x90]
000074fc119d3cc4  vmovaps xmm11, [rsp+0xA0]
000074fc119d3ccd  vmovaps xmm12, [rsp+0xB0]
000074fc119d3cd6  vmovaps xmm13, [rsp+0xC0]
000074fc119d3cdf  vmovaps xmm14, [rsp+0xD0]
000074fc119d3ce8  vmovaps xmm15, [rsp+0xE0]
000074fc119d3cf1  add rsp, 0xF0
000074fc119d3cf8  pop r11
000074fc119d3cfa  pop r10
000074fc119d3cfc  pop r9
000074fc119d3cfe  pop r8
000074fc119d3d00  pop rsi
000074fc119d3d01  pop rdi
000074fc119d3d02  pop rdx
000074fc119d3d03  pop rcx
000074fc119d3d04  pop rax
000074fc119d3d05  add rsp, 0x08
000074fc119d3d09  jmp 0x000074FC119D0015
000074fc119d3d0e  sub rsp, 0x08
000074fc119d3d12  push rax
000074fc119d3d13  push rcx
000074fc119d3d14  push rdx
000074fc119d3d15  push rdi
000074fc119d3d16  push rsi
000074fc119d3d17  push r8
000074fc119d3d19  push r9
000074fc119d3d1b  push r10
000074fc119d3d1d  push r11
000074fc119d3d1f  sub rsp, 0xF0
000074fc119d3d26  vmovaps [rsp], xmm0
000074fc119d3d2b  vmovaps [rsp+0x10], xmm1
000074fc119d3d31  vmovaps [rsp+0x20], xmm2
000074fc119d3d37  vmovaps [rsp+0x30], xmm3
000074fc119d3d3d  vmovaps [rsp+0x40], xmm4
000074fc119d3d43  vmovaps [rsp+0x50], xmm5
000074fc119d3d49  vmovaps [rsp+0x60], xmm6
000074fc119d3d4f  vmovaps [rsp+0x70], xmm7
000074fc119d3d55  vmovaps [rsp+0x80], xmm8
000074fc119d3d5e  vmovaps [rsp+0x90], xmm9
000074fc119d3d67  vmovaps [rsp+0xA0], xmm10
000074fc119d3d70  vmovaps [rsp+0xB0], xmm12
000074fc119d3d79  vmovaps [rsp+0xC0], xmm13
000074fc119d3d82  vmovaps [rsp+0xD0], xmm14
000074fc119d3d8b  vmovaps [rsp+0xE0], xmm15
000074fc119d3d94  sub rsp, 0x30
000074fc119d3d98  movaps [rsp], xmm11
000074fc119d3d9d  movaps [rsp+0x10], xmm13
000074fc119d3da3  movaps [rsp+0x20], xmm14
000074fc119d3da9  lea rdi, [rsp]
000074fc119d3dad  mov esi, 0x00
000074fc119d3db2  mov rax, 0x58C4C8091530
000074fc119d3dbc  call rax
000074fc119d3dbe  movaps xmm11, [rsp]
000074fc119d3dc3  add rsp, 0x30
000074fc119d3dc7  vmovaps xmm0, [rsp]
000074fc119d3dcc  vmovaps xmm1, [rsp+0x10]
000074fc119d3dd2  vmovaps xmm2, [rsp+0x20]
000074fc119d3dd8  vmovaps xmm3, [rsp+0x30]
000074fc119d3dde  vmovaps xmm4, [rsp+0x40]
000074fc119d3de4  vmovaps xmm5, [rsp+0x50]
000074fc119d3dea  vmovaps xmm6, [rsp+0x60]
000074fc119d3df0  vmovaps xmm7, [rsp+0x70]
000074fc119d3df6  vmovaps xmm8, [rsp+0x80]
000074fc119d3dff  vmovaps xmm9, [rsp+0x90]
000074fc119d3e08  vmovaps xmm10, [rsp+0xA0]
000074fc119d3e11  vmovaps xmm12, [rsp+0xB0]
000074fc119d3e1a  vmovaps xmm13, [rsp+0xC0]
000074fc119d3e23  vmovaps xmm14, [rsp+0xD0]
000074fc119d3e2c  vmovaps xmm15, [rsp+0xE0]
000074fc119d3e35  add rsp, 0xF0
000074fc119d3e3c  pop r11
000074fc119d3e3e  pop r10
000074fc119d3e40  pop r9
000074fc119d3e42  pop r8
000074fc119d3e44  pop rsi
000074fc119d3e45  pop rdi
000074fc119d3e46  pop rdx
000074fc119d3e47  pop rcx
000074fc119d3e48  pop rax
000074fc119d3e49  add rsp, 0x08
000074fc119d3e4d  jmp 0x000074FC119D003F
000074fc119d3e52  sub rsp, 0x08
000074fc119d3e56  push rax
000074fc119d3e57  push rcx
000074fc119d3e58  push rdx
000074fc119d3e59  push rdi
000074fc119d3e5a  push rsi
000074fc119d3e5b  push r8
000074fc119d3e5d  push r9
000074fc119d3e5f  push r10
000074fc119d3e61  push r11
000074fc119d3e63  sub rsp, 0xF0
000074fc119d3e6a  vmovaps [rsp], xmm0
000074fc119d3e6f  vmovaps [rsp+0x10], xmm1
000074fc119d3e75  vmovaps [rsp+0x20], xmm2
000074fc119d3e7b  vmovaps [rsp+0x30], xmm3
000074fc119d3e81  vmovaps [rsp+0x40], xmm4
000074fc119d3e87  vmovaps [rsp+0x50], xmm5
000074fc119d3e8d  vmovaps [rsp+0x60], xmm6
000074fc119d3e93  vmovaps [rsp+0x70], xmm7
000074fc119d3e99  vmovaps [rsp+0x80], xmm8
000074fc119d3ea2  vmovaps [rsp+0x90], xmm9
000074fc119d3eab  vmovaps [rsp+0xA0], xmm10
000074fc119d3eb4  vmovaps [rsp+0xB0], xmm11
000074fc119d3ebd  vmovaps [rsp+0xC0], xmm12
000074fc119d3ec6  vmovaps [rsp+0xD0], xmm14
000074fc119d3ecf  vmovaps [rsp+0xE0], xmm15
000074fc119d3ed8  sub rsp, 0x30
000074fc119d3edc  movaps [rsp], xmm13
000074fc119d3ee1  movaps [rsp+0x10], xmm8
000074fc119d3ee7  movaps [rsp+0x20], xmm14
000074fc119d3eed  lea rdi, [rsp]
000074fc119d3ef1  mov esi, 0x00
000074fc119d3ef6  mov rax, 0x58C4C8091530
000074fc119d3f00  call rax
000074fc119d3f02  movaps xmm13, [rsp]
000074fc119d3f07  add rsp, 0x30
000074fc119d3f0b  vmovaps xmm0, [rsp]
000074fc119d3f10  vmovaps xmm1, [rsp+0x10]
000074fc119d3f16  vmovaps xmm2, [rsp+0x20]
000074fc119d3f1c  vmovaps xmm3, [rsp+0x30]
000074fc119d3f22  vmovaps xmm4, [rsp+0x40]
000074fc119d3f28  vmovaps xmm5, [rsp+0x50]
000074fc119d3f2e  vmovaps xmm6, [rsp+0x60]
000074fc119d3f34  vmovaps xmm7, [rsp+0x70]
000074fc119d3f3a  vmovaps xmm8, [rsp+0x80]
000074fc119d3f43  vmovaps xmm9, [rsp+0x90]
000074fc119d3f4c  vmovaps xmm10, [rsp+0xA0]
000074fc119d3f55  vmovaps xmm11, [rsp+0xB0]
000074fc119d3f5e  vmovaps xmm12, [rsp+0xC0]
000074fc119d3f67  vmovaps xmm14, [rsp+0xD0]
000074fc119d3f70  vmovaps xmm15, [rsp+0xE0]
000074fc119d3f79  add rsp, 0xF0
000074fc119d3f80  pop r11
000074fc119d3f82  pop r10
000074fc119d3f84  pop r9
000074fc119d3f86  pop r8
000074fc119d3f88  pop rsi
000074fc119d3f89  pop rdi
000074fc119d3f8a  pop rdx
000074fc119d3f8b  pop rcx
000074fc119d3f8c  pop rax
000074fc119d3f8d  add rsp, 0x08
000074fc119d3f91  jmp 0x000074FC119D006E
000074fc119d3f96  sub rsp, 0x08
000074fc119d3f9a  push rax
000074fc119d3f9b  push rcx
000074fc119d3f9c  push rdx
000074fc119d3f9d  push rdi
000074fc119d3f9e  push rsi
000074fc119d3f9f  push r8
000074fc119d3fa1  push r9
000074fc119d3fa3  push r10
000074fc119d3fa5  push r11
000074fc119d3fa7  sub rsp, 0xF0
000074fc119d3fae  vmovaps [rsp], xmm0
000074fc119d3fb3  vmovaps [rsp+0x10], xmm1
000074fc119d3fb9  vmovaps [rsp+0x20], xmm2
000074fc119d3fbf  vmovaps [rsp+0x30], xmm3
000074fc119d3fc5  vmovaps [rsp+0x40], xmm4
000074fc119d3fcb  vmovaps [rsp+0x50], xmm5
000074fc119d3fd1  vmovaps [rsp+0x60], xmm6
000074fc119d3fd7  vmovaps [rsp+0x70], xmm7
000074fc119d3fdd  vmovaps [rsp+0x80], xmm9
000074fc119d3fe6  vmovaps [rsp+0x90], xmm10
000074fc119d3fef  vmovaps [rsp+0xA0], xmm11
000074fc119d3ff8  vmovaps [rsp+0xB0], xmm12
000074fc119d4001  vmovaps [rsp+0xC0], xmm13
000074fc119d400a  vmovaps [rsp+0xD0], xmm14
000074fc119d4013  vmovaps [rsp+0xE0], xmm15
000074fc119d401c  sub rsp, 0x30
000074fc119d4020  movaps [rsp], xmm8
000074fc119d4025  movaps [rsp+0x10], xmm7
000074fc119d402a  movaps [rsp+0x20], xmm14
000074fc119d4030  lea rdi, [rsp]
000074fc119d4034  mov esi, 0x00
000074fc119d4039  mov rax, 0x58C4C8091530
000074fc119d4043  call rax
000074fc119d4045  movaps xmm8, [rsp]
000074fc119d404a  add rsp, 0x30
000074fc119d404e  vmovaps xmm0, [rsp]
000074fc119d4053  vmovaps xmm1, [rsp+0x10]
000074fc119d4059  vmovaps xmm2, [rsp+0x20]
000074fc119d405f  vmovaps xmm3, [rsp+0x30]
000074fc119d4065  vmovaps xmm4, [rsp+0x40]
000074fc119d406b  vmovaps xmm5, [rsp+0x50]
000074fc119d4071  vmovaps xmm6, [rsp+0x60]
000074fc119d4077  vmovaps xmm7, [rsp+0x70]
000074fc119d407d  vmovaps xmm9, [rsp+0x80]
000074fc119d4086  vmovaps xmm10, [rsp+0x90]
000074fc119d408f  vmovaps xmm11, [rsp+0xA0]
000074fc119d4098  vmovaps xmm12, [rsp+0xB0]
000074fc119d40a1  vmovaps xmm13, [rsp+0xC0]
000074fc119d40aa  vmovaps xmm14, [rsp+0xD0]
000074fc119d40b3  vmovaps xmm15, [rsp+0xE0]
000074fc119d40bc  add rsp, 0xF0
000074fc119d40c3  pop r11
000074fc119d40c5  pop r10
000074fc119d40c7  pop r9
000074fc119d40c9  pop r8
000074fc119d40cb  pop rsi
000074fc119d40cc  pop rdi
000074fc119d40cd  pop rdx
000074fc119d40ce  pop rcx
000074fc119d40cf  pop rax
000074fc119d40d0  add rsp, 0x08
000074fc119d40d4  jmp 0x000074FC119D0094
000074fc119d40d9  sub rsp, 0x08
000074fc119d40dd  push rax
000074fc119d40de  push rcx
000074fc119d40df  push rdx
000074fc119d40e0  push rdi
000074fc119d40e1  push rsi
000074fc119d40e2  push r8
000074fc119d40e4  push r9
000074fc119d40e6  push r10
000074fc119d40e8  push r11
000074fc119d40ea  sub rsp, 0xF0
000074fc119d40f1  vmovaps [rsp], xmm0
000074fc119d40f6  vmovaps [rsp+0x10], xmm1
000074fc119d40fc  vmovaps [rsp+0x20], xmm2
000074fc119d4102  vmovaps [rsp+0x30], xmm3
000074fc119d4108  vmovaps [rsp+0x40], xmm4
000074fc119d410e  vmovaps [rsp+0x50], xmm5
000074fc119d4114  vmovaps [rsp+0x60], xmm6
000074fc119d411a  vmovaps [rsp+0x70], xmm7
000074fc119d4120  vmovaps [rsp+0x80], xmm8
000074fc119d4129  vmovaps [rsp+0x90], xmm9
000074fc119d4132  vmovaps [rsp+0xA0], xmm10
000074fc119d413b  vmovaps [rsp+0xB0], xmm11
000074fc119d4144  vmovaps [rsp+0xC0], xmm12
000074fc119d414d  vmovaps [rsp+0xD0], xmm13
000074fc119d4156  vmovaps [rsp+0xE0], xmm15
000074fc119d415f  sub rsp, 0x30
000074fc119d4163  movaps [rsp], xmm14
000074fc119d4168  movaps [rsp+0x10], xmm12
000074fc119d416e  movaps [rsp+0x20], xmm9
000074fc119d4174  lea rdi, [rsp]
000074fc119d4178  mov esi, 0x00
000074fc119d417d  mov rax, 0x58C4C8091530
000074fc119d4187  call rax
000074fc119d4189  movaps xmm14, [rsp]
000074fc119d418e  add rsp, 0x30
000074fc119d4192  vmovaps xmm0, [rsp]
000074fc119d4197  vmovaps xmm1, [rsp+0x10]
000074fc119d419d  vmovaps xmm2, [rsp+0x20]
000074fc119d41a3  vmovaps xmm3, [rsp+0x30]
000074fc119d41a9  vmovaps xmm4, [rsp+0x40]
000074fc119d41af  vmovaps xmm5, [rsp+0x50]
000074fc119d41b5  vmovaps xmm6, [rsp+0x60]
000074fc119d41bb  vmovaps xmm7, [rsp+0x70]
000074fc119d41c1  vmovaps xmm8, [rsp+0x80]
000074fc119d41ca  vmovaps xmm9, [rsp+0x90]
000074fc119d41d3  vmovaps xmm10, [rsp+0xA0]
000074fc119d41dc  vmovaps xmm11, [rsp+0xB0]
000074fc119d41e5  vmovaps xmm12, [rsp+0xC0]
000074fc119d41ee  vmovaps xmm13, [rsp+0xD0]
000074fc119d41f7  vmovaps xmm15, [rsp+0xE0]
000074fc119d4200  add rsp, 0xF0
000074fc119d4207  pop r11
000074fc119d4209  pop r10
000074fc119d420b  pop r9
000074fc119d420d  pop r8
000074fc119d420f  pop rsi
000074fc119d4210  pop rdi
000074fc119d4211  pop rdx
000074fc119d4212  pop rcx
000074fc119d4213  pop rax
000074fc119d4214  add rsp, 0x08
000074fc119d4218  jmp 0x000074FC119D00AE
000074fc119d421d  sub rsp, 0x08
000074fc119d4221  push rax
000074fc119d4222  push rcx
000074fc119d4223  push rdx
000074fc119d4224  push rdi
000074fc119d4225  push rsi
000074fc119d4226  push r8
000074fc119d4228  push r9
000074fc119d422a  push r10
000074fc119d422c  push r11
000074fc119d422e  sub rsp, 0xF0
000074fc119d4235  vmovaps [rsp], xmm0
000074fc119d423a  vmovaps [rsp+0x10], xmm1
000074fc119d4240  vmovaps [rsp+0x20], xmm2
000074fc119d4246  vmovaps [rsp+0x30], xmm3
000074fc119d424c  vmovaps [rsp+0x40], xmm4
000074fc119d4252  vmovaps [rsp+0x50], xmm5
000074fc119d4258  vmovaps [rsp+0x60], xmm6
000074fc119d425e  vmovaps [rsp+0x70], xmm7
000074fc119d4264  vmovaps [rsp+0x80], xmm8
000074fc119d426d  vmovaps [rsp+0x90], xmm10
000074fc119d4276  vmovaps [rsp+0xA0], xmm11
000074fc119d427f  vmovaps [rsp+0xB0], xmm12
000074fc119d4288  vmovaps [rsp+0xC0], xmm13
000074fc119d4291  vmovaps [rsp+0xD0], xmm14
000074fc119d429a  vmovaps [rsp+0xE0], xmm15
000074fc119d42a3  sub rsp, 0x30
000074fc119d42a7  movaps [rsp], xmm9
000074fc119d42ac  movaps [rsp+0x10], xmm7
000074fc119d42b1  movaps [rsp+0x20], xmm12
000074fc119d42b7  lea rdi, [rsp]
000074fc119d42bb  mov esi, 0x00
000074fc119d42c0  mov rax, 0x58C4C8091530
000074fc119d42ca  call rax
000074fc119d42cc  movaps xmm9, [rsp]
000074fc119d42d1  add rsp, 0x30
000074fc119d42d5  vmovaps xmm0, [rsp]
000074fc119d42da  vmovaps xmm1, [rsp+0x10]
000074fc119d42e0  vmovaps xmm2, [rsp+0x20]
000074fc119d42e6  vmovaps xmm3, [rsp+0x30]
000074fc119d42ec  vmovaps xmm4, [rsp+0x40]
000074fc119d42f2  vmovaps xmm5, [rsp+0x50]
000074fc119d42f8  vmovaps xmm6, [rsp+0x60]
000074fc119d42fe  vmovaps xmm7, [rsp+0x70]
000074fc119d4304  vmovaps xmm8, [rsp+0x80]
000074fc119d430d  vmovaps xmm10, [rsp+0x90]
000074fc119d4316  vmovaps xmm11, [rsp+0xA0]
000074fc119d431f  vmovaps xmm12, [rsp+0xB0]
000074fc119d4328  vmovaps xmm13, [rsp+0xC0]
000074fc119d4331  vmovaps xmm14, [rsp+0xD0]
000074fc119d433a  vmovaps xmm15, [rsp+0xE0]
000074fc119d4343  add rsp, 0xF0
000074fc119d434a  pop r11
000074fc119d434c  pop r10
000074fc119d434e  pop r9
000074fc119d4350  pop r8
000074fc119d4352  pop rsi
000074fc119d4353  pop rdi
000074fc119d4354  pop rdx
000074fc119d4355  pop rcx
000074fc119d4356  pop rax
000074fc119d4357  add rsp, 0x08
000074fc119d435b  jmp 0x000074FC119D00DD
000074fc119d4360  sub rsp, 0x08
000074fc119d4364  push rax
000074fc119d4365  push rcx
000074fc119d4366  push rdx
000074fc119d4367  push rdi
000074fc119d4368  push rsi
000074fc119d4369  push r8
000074fc119d436b  push r9
000074fc119d436d  push r10
000074fc119d436f  push r11
000074fc119d4371  sub rsp, 0xF0
000074fc119d4378  vmovaps [rsp], xmm0
000074fc119d437d  vmovaps [rsp+0x10], xmm1
000074fc119d4383  vmovaps [rsp+0x20], xmm2
000074fc119d4389  vmovaps [rsp+0x30], xmm3
000074fc119d438f  vmovaps [rsp+0x40], xmm4
000074fc119d4395  vmovaps [rsp+0x50], xmm5
000074fc119d439b  vmovaps [rsp+0x60], xmm6
000074fc119d43a1  vmovaps [rsp+0x70], xmm7
000074fc119d43a7  vmovaps [rsp+0x80], xmm8
000074fc119d43b0  vmovaps [rsp+0x90], xmm9
000074fc119d43b9  vmovaps [rsp+0xA0], xmm10
000074fc119d43c2  vmovaps [rsp+0xB0], xmm11
000074fc119d43cb  vmovaps [rsp+0xC0], xmm13
000074fc119d43d4  vmovaps [rsp+0xD0], xmm14
000074fc119d43dd  vmovaps [rsp+0xE0], xmm15
000074fc119d43e6  sub rsp, 0x30
000074fc119d43ea  movaps [rsp], xmm12
000074fc119d43ef  movaps [rsp+0x10], xmm15
000074fc119d43f5  movaps [rsp+0x20], xmm11
000074fc119d43fb  lea rdi, [rsp]
000074fc119d43ff  mov esi, 0x00
000074fc119d4404  mov rax, 0x58C4C8091530
000074fc119d440e  call rax
000074fc119d4410  movaps xmm12, [rsp]
000074fc119d4415  add rsp, 0x30
000074fc119d4419  vmovaps xmm0, [rsp]
000074fc119d441e  vmovaps xmm1, [rsp+0x10]
000074fc119d4424  vmovaps xmm2, [rsp+0x20]
000074fc119d442a  vmovaps xmm3, [rsp+0x30]
000074fc119d4430  vmovaps xmm4, [rsp+0x40]
000074fc119d4436  vmovaps xmm5, [rsp+0x50]
000074fc119d443c  vmovaps xmm6, [rsp+0x60]
000074fc119d4442  vmovaps xmm7, [rsp+0x70]
000074fc119d4448  vmovaps xmm8, [rsp+0x80]
000074fc119d4451  vmovaps xmm9, [rsp+0x90]
000074fc119d445a  vmovaps xmm10, [rsp+0xA0]
000074fc119d4463  vmovaps xmm11, [rsp+0xB0]
000074fc119d446c  vmovaps xmm13, [rsp+0xC0]
000074fc119d4475  vmovaps xmm14, [rsp+0xD0]
000074fc119d447e  vmovaps xmm15, [rsp+0xE0]
000074fc119d4487  add rsp, 0xF0
000074fc119d448e  pop r11
000074fc119d4490  pop r10
000074fc119d4492  pop r9
000074fc119d4494  pop r8
000074fc119d4496  pop rsi
000074fc119d4497  pop rdi
000074fc119d4498  pop rdx
000074fc119d4499  pop rcx
000074fc119d449a  pop rax
000074fc119d449b  add rsp, 0x08
000074fc119d449f  jmp 0x000074FC119D00F7
000074fc119d44a4  sub rsp, 0x08
000074fc119d44a8  push rax
000074fc119d44a9  push rcx
000074fc119d44aa  push rdx
000074fc119d44ab  push rdi
000074fc119d44ac  push rsi
000074fc119d44ad  push r8
000074fc119d44af  push r9
000074fc119d44b1  push r10
000074fc119d44b3  push r11
000074fc119d44b5  sub rsp, 0xF0
000074fc119d44bc  vmovaps [rsp], xmm0
000074fc119d44c1  vmovaps [rsp+0x10], xmm1
000074fc119d44c7  vmovaps [rsp+0x20], xmm2
000074fc119d44cd  vmovaps [rsp+0x30], xmm3
000074fc119d44d3  vmovaps [rsp+0x40], xmm4
000074fc119d44d9  vmovaps [rsp+0x50], xmm5
000074fc119d44df  vmovaps [rsp+0x60], xmm6
000074fc119d44e5  vmovaps [rsp+0x70], xmm7
000074fc119d44eb  vmovaps [rsp+0x80], xmm8
000074fc119d44f4  vmovaps [rsp+0x90], xmm9
000074fc119d44fd  vmovaps [rsp+0xA0], xmm10
000074fc119d4506  vmovaps [rsp+0xB0], xmm12
000074fc119d450f  vmovaps [rsp+0xC0], xmm13
000074fc119d4518  vmovaps [rsp+0xD0], xmm14
000074fc119d4521  vmovaps [rsp+0xE0], xmm15
000074fc119d452a  sub rsp, 0x30
000074fc119d452e  movaps [rsp], xmm11
000074fc119d4533  movaps [rsp+0x10], xmm7
000074fc119d4538  movaps [rsp+0x20], xmm15
000074fc119d453e  lea rdi, [rsp]
000074fc119d4542  mov esi, 0x00
000074fc119d4547  mov rax, 0x58C4C8091530
000074fc119d4551  call rax
000074fc119d4553  movaps xmm11, [rsp]
000074fc119d4558  add rsp, 0x30
000074fc119d455c  vmovaps xmm0, [rsp]
000074fc119d4561  vmovaps xmm1, [rsp+0x10]
000074fc119d4567  vmovaps xmm2, [rsp+0x20]
000074fc119d456d  vmovaps xmm3, [rsp+0x30]
000074fc119d4573  vmovaps xmm4, [rsp+0x40]
000074fc119d4579  vmovaps xmm5, [rsp+0x50]
000074fc119d457f  vmovaps xmm6, [rsp+0x60]
000074fc119d4585  vmovaps xmm7, [rsp+0x70]
000074fc119d458b  vmovaps xmm8, [rsp+0x80]
000074fc119d4594  vmovaps xmm9, [rsp+0x90]
000074fc119d459d  vmovaps xmm10, [rsp+0xA0]
000074fc119d45a6  vmovaps xmm12, [rsp+0xB0]
000074fc119d45af  vmovaps xmm13, [rsp+0xC0]
000074fc119d45b8  vmovaps xmm14, [rsp+0xD0]
000074fc119d45c1  vmovaps xmm15, [rsp+0xE0]
000074fc119d45ca  add rsp, 0xF0
000074fc119d45d1  pop r11
000074fc119d45d3  pop r10
000074fc119d45d5  pop r9
000074fc119d45d7  pop r8
000074fc119d45d9  pop rsi
000074fc119d45da  pop rdi
000074fc119d45db  pop rdx
000074fc119d45dc  pop rcx
000074fc119d45dd  pop rax
000074fc119d45de  add rsp, 0x08
000074fc119d45e2  jmp 0x000074FC119D0123
000074fc119d45e7  sub rsp, 0x08
000074fc119d45eb  push rax
000074fc119d45ec  push rcx
000074fc119d45ed  push rdx
000074fc119d45ee  push rdi
000074fc119d45ef  push rsi
000074fc119d45f0  push r8
000074fc119d45f2  push r9
000074fc119d45f4  push r10
000074fc119d45f6  push r11
000074fc119d45f8  sub rsp, 0xF0
000074fc119d45ff  vmovaps [rsp], xmm0
000074fc119d4604  vmovaps [rsp+0x10], xmm1
000074fc119d460a  vmovaps [rsp+0x20], xmm2
000074fc119d4610  vmovaps [rsp+0x30], xmm3
000074fc119d4616  vmovaps [rsp+0x40], xmm4
000074fc119d461c  vmovaps [rsp+0x50], xmm5
000074fc119d4622  vmovaps [rsp+0x60], xmm6
000074fc119d4628  vmovaps [rsp+0x70], xmm7
000074fc119d462e  vmovaps [rsp+0x80], xmm8
000074fc119d4637  vmovaps [rsp+0x90], xmm9
000074fc119d4640  vmovaps [rsp+0xA0], xmm10
000074fc119d4649  vmovaps [rsp+0xB0], xmm11
000074fc119d4652  vmovaps [rsp+0xC0], xmm12
000074fc119d465b  vmovaps [rsp+0xD0], xmm13
000074fc119d4664  vmovaps [rsp+0xE0], xmm14
000074fc119d466d  sub rsp, 0x30
000074fc119d4671  movaps [rsp], xmm15
000074fc119d4676  movaps [rsp+0x10], xmm10
000074fc119d467c  movaps [rsp+0x20], xmm13
000074fc119d4682  lea rdi, [rsp]
000074fc119d4686  mov esi, 0x00
000074fc119d468b  mov rax, 0x58C4C8091530
000074fc119d4695  call rax
000074fc119d4697  movaps xmm15, [rsp]
000074fc119d469c  add rsp, 0x30
000074fc119d46a0  vmovaps xmm0, [rsp]
000074fc119d46a5  vmovaps xmm1, [rsp+0x10]
000074fc119d46ab  vmovaps xmm2, [rsp+0x20]
000074fc119d46b1  vmovaps xmm3, [rsp+0x30]
000074fc119d46b7  vmovaps xmm4, [rsp+0x40]
000074fc119d46bd  vmovaps xmm5, [rsp+0x50]
000074fc119d46c3  vmovaps xmm6, [rsp+0x60]
000074fc119d46c9  vmovaps xmm7, [rsp+0x70]
000074fc119d46cf  vmovaps xmm8, [rsp+0x80]
000074fc119d46d8  vmovaps xmm9, [rsp+0x90]
000074fc119d46e1  vmovaps xmm10, [rsp+0xA0]
000074fc119d46ea  vmovaps xmm11, [rsp+0xB0]
000074fc119d46f3  vmovaps xmm12, [rsp+0xC0]
000074fc119d46fc  vmovaps xmm13, [rsp+0xD0]
000074fc119d4705  vmovaps xmm14, [rsp+0xE0]
000074fc119d470e  add rsp, 0xF0
000074fc119d4715  pop r11
000074fc119d4717  pop r10
000074fc119d4719  pop r9
000074fc119d471b  pop r8
000074fc119d471d  pop rsi
000074fc119d471e  pop rdi
000074fc119d471f  pop rdx
000074fc119d4720  pop rcx
000074fc119d4721  pop rax
000074fc119d4722  add rsp, 0x08
000074fc119d4726  jmp 0x000074FC119D013D
000074fc119d472b  sub rsp, 0x08
000074fc119d472f  push rax
000074fc119d4730  push rcx
000074fc119d4731  push rdx
000074fc119d4732  push rdi
000074fc119d4733  push rsi
000074fc119d4734  push r8
000074fc119d4736  push r9
000074fc119d4738  push r10
000074fc119d473a  push r11
000074fc119d473c  sub rsp, 0xF0
000074fc119d4743  vmovaps [rsp], xmm0
000074fc119d4748  vmovaps [rsp+0x10], xmm1
000074fc119d474e  vmovaps [rsp+0x20], xmm2
000074fc119d4754  vmovaps [rsp+0x30], xmm3
000074fc119d475a  vmovaps [rsp+0x40], xmm4
000074fc119d4760  vmovaps [rsp+0x50], xmm5
000074fc119d4766  vmovaps [rsp+0x60], xmm6
000074fc119d476c  vmovaps [rsp+0x70], xmm7
000074fc119d4772  vmovaps [rsp+0x80], xmm8
000074fc119d477b  vmovaps [rsp+0x90], xmm9
000074fc119d4784  vmovaps [rsp+0xA0], xmm11
000074fc119d478d  vmovaps [rsp+0xB0], xmm12
000074fc119d4796  vmovaps [rsp+0xC0], xmm13
000074fc119d479f  vmovaps [rsp+0xD0], xmm14
000074fc119d47a8  vmovaps [rsp+0xE0], xmm15
000074fc119d47b1  sub rsp, 0x30
000074fc119d47b5  movaps [rsp], xmm10
000074fc119d47ba  movaps [rsp+0x10], xmm7
000074fc119d47bf  movaps [rsp+0x20], xmm13
000074fc119d47c5  lea rdi, [rsp]
000074fc119d47c9  mov esi, 0x00
000074fc119d47ce  mov rax, 0x58C4C8091530
000074fc119d47d8  call rax
000074fc119d47da  movaps xmm10, [rsp]
000074fc119d47df  add rsp, 0x30
000074fc119d47e3  vmovaps xmm0, [rsp]
000074fc119d47e8  vmovaps xmm1, [rsp+0x10]
000074fc119d47ee  vmovaps xmm2, [rsp+0x20]
000074fc119d47f4  vmovaps xmm3, [rsp+0x30]
000074fc119d47fa  vmovaps xmm4, [rsp+0x40]
000074fc119d4800  vmovaps xmm5, [rsp+0x50]
000074fc119d4806  vmovaps xmm6, [rsp+0x60]
000074fc119d480c  vmovaps xmm7, [rsp+0x70]
000074fc119d4812  vmovaps xmm8, [rsp+0x80]
000074fc119d481b  vmovaps xmm9, [rsp+0x90]
000074fc119d4824  vmovaps xmm11, [rsp+0xA0]
000074fc119d482d  vmovaps xmm12, [rsp+0xB0]
000074fc119d4836  vmovaps xmm13, [rsp+0xC0]
000074fc119d483f  vmovaps xmm14, [rsp+0xD0]
000074fc119d4848  vmovaps xmm15, [rsp+0xE0]
000074fc119d4851  add rsp, 0xF0
000074fc119d4858  pop r11
000074fc119d485a  pop r10
000074fc119d485c  pop r9
000074fc119d485e  pop r8
000074fc119d4860  pop rsi
000074fc119d4861  pop rdi
000074fc119d4862  pop rdx
000074fc119d4863  pop rcx
000074fc119d4864  pop rax
000074fc119d4865  add rsp, 0x08
000074fc119d4869  jmp 0x000074FC119D0169
000074fc119d486e  sub rsp, 0x08
000074fc119d4872  push rax
000074fc119d4873  push rcx
000074fc119d4874  push rdx
000074fc119d4875  push rdi
000074fc119d4876  push rsi
000074fc119d4877  push r8
000074fc119d4879  push r9
000074fc119d487b  push r10
000074fc119d487d  push r11
000074fc119d487f  sub rsp, 0xF0
000074fc119d4886  vmovaps [rsp], xmm0
000074fc119d488b  vmovaps [rsp+0x10], xmm1
000074fc119d4891  vmovaps [rsp+0x20], xmm2
000074fc119d4897  vmovaps [rsp+0x30], xmm3
000074fc119d489d  vmovaps [rsp+0x40], xmm4
000074fc119d48a3  vmovaps [rsp+0x50], xmm5
000074fc119d48a9  vmovaps [rsp+0x60], xmm6
000074fc119d48af  vmovaps [rsp+0x70], xmm7
000074fc119d48b5  vmovaps [rsp+0x80], xmm8
000074fc119d48be  vmovaps [rsp+0x90], xmm9
000074fc119d48c7  vmovaps [rsp+0xA0], xmm10
000074fc119d48d0  vmovaps [rsp+0xB0], xmm11
000074fc119d48d9  vmovaps [rsp+0xC0], xmm12
000074fc119d48e2  vmovaps [rsp+0xD0], xmm14
000074fc119d48eb  vmovaps [rsp+0xE0], xmm15
000074fc119d48f4  sub rsp, 0x30
000074fc119d48f8  movaps [rsp], xmm13
000074fc119d48fd  movaps [rsp+0x10], xmm1
000074fc119d4902  movaps [rsp+0x20], xmm8
000074fc119d4908  lea rdi, [rsp]
000074fc119d490c  mov esi, 0x00
000074fc119d4911  mov rax, 0x58C4C8091530
000074fc119d491b  call rax
000074fc119d491d  movaps xmm13, [rsp]
000074fc119d4922  add rsp, 0x30
000074fc119d4926  vmovaps xmm0, [rsp]
000074fc119d492b  vmovaps xmm1, [rsp+0x10]
000074fc119d4931  vmovaps xmm2, [rsp+0x20]
000074fc119d4937  vmovaps xmm3, [rsp+0x30]
000074fc119d493d  vmovaps xmm4, [rsp+0x40]
000074fc119d4943  vmovaps xmm5, [rsp+0x50]
000074fc119d4949  vmovaps xmm6, [rsp+0x60]
000074fc119d494f  vmovaps xmm7, [rsp+0x70]
000074fc119d4955  vmovaps xmm8, [rsp+0x80]
000074fc119d495e  vmovaps xmm9, [rsp+0x90]
000074fc119d4967  vmovaps xmm10, [rsp+0xA0]
000074fc119d4970  vmovaps xmm11, [rsp+0xB0]
000074fc119d4979  vmovaps xmm12, [rsp+0xC0]
000074fc119d4982  vmovaps xmm14, [rsp+0xD0]
000074fc119d498b  vmovaps xmm15, [rsp+0xE0]
000074fc119d4994  add rsp, 0xF0
000074fc119d499b  pop r11
000074fc119d499d  pop r10
000074fc119d499f  pop r9
000074fc119d49a1  pop r8
000074fc119d49a3  pop rsi
000074fc119d49a4  pop rdi
000074fc119d49a5  pop rdx
000074fc119d49a6  pop rcx
000074fc119d49a7  pop rax
000074fc119d49a8  add rsp, 0x08
000074fc119d49ac  jmp 0x000074FC119D0183
000074fc119d49b1  call 0x000074FC117FF430
000074fc119d49b6  jmp 0x000074FC119D018D
000074fc119d49bb  sub rsp, 0x08
000074fc119d49bf  push rax
000074fc119d49c0  push rcx
000074fc119d49c1  push rdx
000074fc119d49c2  push rdi
000074fc119d49c3  push rsi
000074fc119d49c4  push r8
000074fc119d49c6  push r9
000074fc119d49c8  push r10
000074fc119d49ca  push r11
000074fc119d49cc  sub rsp, 0xF0
000074fc119d49d3  vmovaps [rsp], xmm0
000074fc119d49d8  vmovaps [rsp+0x10], xmm1
000074fc119d49de  vmovaps [rsp+0x20], xmm2
000074fc119d49e4  vmovaps [rsp+0x30], xmm3
000074fc119d49ea  vmovaps [rsp+0x40], xmm4
000074fc119d49f0  vmovaps [rsp+0x50], xmm5
000074fc119d49f6  vmovaps [rsp+0x60], xmm6
000074fc119d49fc  vmovaps [rsp+0x70], xmm7
000074fc119d4a02  vmovaps [rsp+0x80], xmm9
000074fc119d4a0b  vmovaps [rsp+0x90], xmm10
000074fc119d4a14  vmovaps [rsp+0xA0], xmm11
000074fc119d4a1d  vmovaps [rsp+0xB0], xmm12
000074fc119d4a26  vmovaps [rsp+0xC0], xmm13
000074fc119d4a2f  vmovaps [rsp+0xD0], xmm14
000074fc119d4a38  vmovaps [rsp+0xE0], xmm15
000074fc119d4a41  sub rsp, 0x30
000074fc119d4a45  movaps [rsp], xmm8
000074fc119d4a4a  movaps [rsp+0x10], xmm14
000074fc119d4a50  movaps [rsp+0x20], xmm9
000074fc119d4a56  lea rdi, [rsp]
000074fc119d4a5a  mov esi, 0x00
000074fc119d4a5f  mov rax, 0x58C4C8091530
000074fc119d4a69  call rax
000074fc119d4a6b  movaps xmm8, [rsp]
000074fc119d4a70  add rsp, 0x30
000074fc119d4a74  vmovaps xmm0, [rsp]
000074fc119d4a79  vmovaps xmm1, [rsp+0x10]
000074fc119d4a7f  vmovaps xmm2, [rsp+0x20]
000074fc119d4a85  vmovaps xmm3, [rsp+0x30]
000074fc119d4a8b  vmovaps xmm4, [rsp+0x40]
000074fc119d4a91  vmovaps xmm5, [rsp+0x50]
000074fc119d4a97  vmovaps xmm6, [rsp+0x60]
000074fc119d4a9d  vmovaps xmm7, [rsp+0x70]
000074fc119d4aa3  vmovaps xmm9, [rsp+0x80]
000074fc119d4aac  vmovaps xmm10, [rsp+0x90]
000074fc119d4ab5  vmovaps xmm11, [rsp+0xA0]
000074fc119d4abe  vmovaps xmm12, [rsp+0xB0]
000074fc119d4ac7  vmovaps xmm13, [rsp+0xC0]
000074fc119d4ad0  vmovaps xmm14, [rsp+0xD0]
000074fc119d4ad9  vmovaps xmm15, [rsp+0xE0]
000074fc119d4ae2  add rsp, 0xF0
000074fc119d4ae9  pop r11
000074fc119d4aeb  pop r10
000074fc119d4aed  pop r9
000074fc119d4aef  pop r8
000074fc119d4af1  pop rsi
000074fc119d4af2  pop rdi
000074fc119d4af3  pop rdx
000074fc119d4af4  pop rcx
000074fc119d4af5  pop rax
000074fc119d4af6  add rsp, 0x08
000074fc119d4afa  jmp 0x000074FC119D01AF
000074fc119d4aff  sub rsp, 0x08
000074fc119d4b03  push rax
000074fc119d4b04  push rcx
000074fc119d4b05  push rdx
000074fc119d4b06  push rdi
000074fc119d4b07  push rsi
000074fc119d4b08  push r8
000074fc119d4b0a  push r9
000074fc119d4b0c  push r10
000074fc119d4b0e  push r11
000074fc119d4b10  sub rsp, 0xF0
000074fc119d4b17  vmovaps [rsp], xmm0
000074fc119d4b1c  vmovaps [rsp+0x10], xmm1
000074fc119d4b22  vmovaps [rsp+0x20], xmm2
000074fc119d4b28  vmovaps [rsp+0x30], xmm3
000074fc119d4b2e  vmovaps [rsp+0x40], xmm4
000074fc119d4b34  vmovaps [rsp+0x50], xmm5
000074fc119d4b3a  vmovaps [rsp+0x60], xmm6
000074fc119d4b40  vmovaps [rsp+0x70], xmm7
000074fc119d4b46  vmovaps [rsp+0x80], xmm8
000074fc119d4b4f  vmovaps [rsp+0x90], xmm10
000074fc119d4b58  vmovaps [rsp+0xA0], xmm11
000074fc119d4b61  vmovaps [rsp+0xB0], xmm12
000074fc119d4b6a  vmovaps [rsp+0xC0], xmm13
000074fc119d4b73  vmovaps [rsp+0xD0], xmm14
000074fc119d4b7c  vmovaps [rsp+0xE0], xmm15
000074fc119d4b85  sub rsp, 0x30
000074fc119d4b89  movaps [rsp], xmm9
000074fc119d4b8e  movaps [rsp+0x10], xmm1
000074fc119d4b93  movaps [rsp+0x20], xmm14
000074fc119d4b99  lea rdi, [rsp]
000074fc119d4b9d  mov esi, 0x00
000074fc119d4ba2  mov rax, 0x58C4C8091530
000074fc119d4bac  call rax
000074fc119d4bae  movaps xmm9, [rsp]
000074fc119d4bb3  add rsp, 0x30
000074fc119d4bb7  vmovaps xmm0, [rsp]
000074fc119d4bbc  vmovaps xmm1, [rsp+0x10]
000074fc119d4bc2  vmovaps xmm2, [rsp+0x20]
000074fc119d4bc8  vmovaps xmm3, [rsp+0x30]
000074fc119d4bce  vmovaps xmm4, [rsp+0x40]
000074fc119d4bd4  vmovaps xmm5, [rsp+0x50]
000074fc119d4bda  vmovaps xmm6, [rsp+0x60]
000074fc119d4be0  vmovaps xmm7, [rsp+0x70]
000074fc119d4be6  vmovaps xmm8, [rsp+0x80]
000074fc119d4bef  vmovaps xmm10, [rsp+0x90]
000074fc119d4bf8  vmovaps xmm11, [rsp+0xA0]
000074fc119d4c01  vmovaps xmm12, [rsp+0xB0]
000074fc119d4c0a  vmovaps xmm13, [rsp+0xC0]
000074fc119d4c13  vmovaps xmm14, [rsp+0xD0]
000074fc119d4c1c  vmovaps xmm15, [rsp+0xE0]
000074fc119d4c25  add rsp, 0xF0
000074fc119d4c2c  pop r11
000074fc119d4c2e  pop r10
000074fc119d4c30  pop r9
000074fc119d4c32  pop r8
000074fc119d4c34  pop rsi
000074fc119d4c35  pop rdi
000074fc119d4c36  pop rdx
000074fc119d4c37  pop rcx
000074fc119d4c38  pop rax
000074fc119d4c39  add rsp, 0x08
000074fc119d4c3d  jmp 0x000074FC119D01DD
000074fc119d4c42  sub rsp, 0x08
000074fc119d4c46  push rax
000074fc119d4c47  push rcx
000074fc119d4c48  push rdx
000074fc119d4c49  push rdi
000074fc119d4c4a  push rsi
000074fc119d4c4b  push r8
000074fc119d4c4d  push r9
000074fc119d4c4f  push r10
000074fc119d4c51  push r11
000074fc119d4c53  sub rsp, 0xF0
000074fc119d4c5a  vmovaps [rsp], xmm0
000074fc119d4c5f  vmovaps [rsp+0x10], xmm1
000074fc119d4c65  vmovaps [rsp+0x20], xmm2
000074fc119d4c6b  vmovaps [rsp+0x30], xmm3
000074fc119d4c71  vmovaps [rsp+0x40], xmm4
000074fc119d4c77  vmovaps [rsp+0x50], xmm5
000074fc119d4c7d  vmovaps [rsp+0x60], xmm6
000074fc119d4c83  vmovaps [rsp+0x70], xmm7
000074fc119d4c89  vmovaps [rsp+0x80], xmm8
000074fc119d4c92  vmovaps [rsp+0x90], xmm9
000074fc119d4c9b  vmovaps [rsp+0xA0], xmm10
000074fc119d4ca4  vmovaps [rsp+0xB0], xmm11
000074fc119d4cad  vmovaps [rsp+0xC0], xmm12
000074fc119d4cb6  vmovaps [rsp+0xD0], xmm13
000074fc119d4cbf  vmovaps [rsp+0xE0], xmm15
000074fc119d4cc8  sub rsp, 0x30
000074fc119d4ccc  movaps [rsp], xmm14
000074fc119d4cd1  movaps [rsp+0x10], xmm4
000074fc119d4cd6  movaps [rsp+0x20], xmm1
000074fc119d4cdb  lea rdi, [rsp]
000074fc119d4cdf  mov esi, 0x00
000074fc119d4ce4  mov rax, 0x58C4C8091530
000074fc119d4cee  call rax
000074fc119d4cf0  movaps xmm14, [rsp]
000074fc119d4cf5  add rsp, 0x30
000074fc119d4cf9  vmovaps xmm0, [rsp]
000074fc119d4cfe  vmovaps xmm1, [rsp+0x10]
000074fc119d4d04  vmovaps xmm2, [rsp+0x20]
000074fc119d4d0a  vmovaps xmm3, [rsp+0x30]
000074fc119d4d10  vmovaps xmm4, [rsp+0x40]
000074fc119d4d16  vmovaps xmm5, [rsp+0x50]
000074fc119d4d1c  vmovaps xmm6, [rsp+0x60]
000074fc119d4d22  vmovaps xmm7, [rsp+0x70]
000074fc119d4d28  vmovaps xmm8, [rsp+0x80]
000074fc119d4d31  vmovaps xmm9, [rsp+0x90]
000074fc119d4d3a  vmovaps xmm10, [rsp+0xA0]
000074fc119d4d43  vmovaps xmm11, [rsp+0xB0]
000074fc119d4d4c  vmovaps xmm12, [rsp+0xC0]
000074fc119d4d55  vmovaps xmm13, [rsp+0xD0]
000074fc119d4d5e  vmovaps xmm15, [rsp+0xE0]
000074fc119d4d67  add rsp, 0xF0
000074fc119d4d6e  pop r11
000074fc119d4d70  pop r10
000074fc119d4d72  pop r9
000074fc119d4d74  pop r8
000074fc119d4d76  pop rsi
000074fc119d4d77  pop rdi
000074fc119d4d78  pop rdx
000074fc119d4d79  pop rcx
000074fc119d4d7a  pop rax
000074fc119d4d7b  add rsp, 0x08
000074fc119d4d7f  jmp 0x000074FC119D0203
000074fc119d4d84  sub rsp, 0x08
000074fc119d4d88  push rax
000074fc119d4d89  push rcx
000074fc119d4d8a  push rdx
000074fc119d4d8b  push rdi
000074fc119d4d8c  push rsi
000074fc119d4d8d  push r8
000074fc119d4d8f  push r9
000074fc119d4d91  push r10
000074fc119d4d93  push r11
000074fc119d4d95  sub rsp, 0xF0
000074fc119d4d9c  vmovaps [rsp], xmm0
000074fc119d4da1  vmovaps [rsp+0x10], xmm2
000074fc119d4da7  vmovaps [rsp+0x20], xmm3
000074fc119d4dad  vmovaps [rsp+0x30], xmm4
000074fc119d4db3  vmovaps [rsp+0x40], xmm5
000074fc119d4db9  vmovaps [rsp+0x50], xmm6
000074fc119d4dbf  vmovaps [rsp+0x60], xmm7
000074fc119d4dc5  vmovaps [rsp+0x70], xmm8
000074fc119d4dcb  vmovaps [rsp+0x80], xmm9
000074fc119d4dd4  vmovaps [rsp+0x90], xmm10
000074fc119d4ddd  vmovaps [rsp+0xA0], xmm11
000074fc119d4de6  vmovaps [rsp+0xB0], xmm12
000074fc119d4def  vmovaps [rsp+0xC0], xmm13
000074fc119d4df8  vmovaps [rsp+0xD0], xmm14
000074fc119d4e01  vmovaps [rsp+0xE0], xmm15
000074fc119d4e0a  sub rsp, 0x30
000074fc119d4e0e  movaps [rsp], xmm1
000074fc119d4e12  movaps [rsp+0x10], xmm12
000074fc119d4e18  movaps [rsp+0x20], xmm11
000074fc119d4e1e  lea rdi, [rsp]
000074fc119d4e22  mov esi, 0x00
000074fc119d4e27  mov rax, 0x58C4C8091530
000074fc119d4e31  call rax
000074fc119d4e33  movaps xmm1, [rsp]
000074fc119d4e37  add rsp, 0x30
000074fc119d4e3b  vmovaps xmm0, [rsp]
000074fc119d4e40  vmovaps xmm2, [rsp+0x10]
000074fc119d4e46  vmovaps xmm3, [rsp+0x20]
000074fc119d4e4c  vmovaps xmm4, [rsp+0x30]
000074fc119d4e52  vmovaps xmm5, [rsp+0x40]
000074fc119d4e58  vmovaps xmm6, [rsp+0x50]
000074fc119d4e5e  vmovaps xmm7, [rsp+0x60]
000074fc119d4e64  vmovaps xmm8, [rsp+0x70]
000074fc119d4e6a  vmovaps xmm9, [rsp+0x80]
000074fc119d4e73  vmovaps xmm10, [rsp+0x90]
000074fc119d4e7c  vmovaps xmm11, [rsp+0xA0]
000074fc119d4e85  vmovaps xmm12, [rsp+0xB0]
000074fc119d4e8e  vmovaps xmm13, [rsp+0xC0]
000074fc119d4e97  vmovaps xmm14, [rsp+0xD0]
000074fc119d4ea0  vmovaps xmm15, [rsp+0xE0]
000074fc119d4ea9  add rsp, 0xF0
000074fc119d4eb0  pop r11
000074fc119d4eb2  pop r10
000074fc119d4eb4  pop r9
000074fc119d4eb6  pop r8
000074fc119d4eb8  pop rsi
000074fc119d4eb9  pop rdi
000074fc119d4eba  pop rdx
000074fc119d4ebb  pop rcx
000074fc119d4ebc  pop rax
000074fc119d4ebd  add rsp, 0x08
000074fc119d4ec1  jmp 0x000074FC119D0224
000074fc119d4ec6  call 0x000074FC118E20A0
000074fc119d4ecb  jmp 0x000074FC119D0232
000074fc119d4ed0  call 0x000074FC11809D70
000074fc119d4ed5  jmp 0x000074FC119D023C
000074fc119d4eda  sub rsp, 0x08
000074fc119d4ede  push rax
000074fc119d4edf  push rcx
000074fc119d4ee0  push rdx
000074fc119d4ee1  push rdi
000074fc119d4ee2  push rsi
000074fc119d4ee3  push r8
000074fc119d4ee5  push r9
000074fc119d4ee7  push r10
000074fc119d4ee9  push r11
000074fc119d4eeb  sub rsp, 0xF0
000074fc119d4ef2  vmovaps [rsp], xmm0
000074fc119d4ef7  vmovaps [rsp+0x10], xmm1
000074fc119d4efd  vmovaps [rsp+0x20], xmm2
000074fc119d4f03  vmovaps [rsp+0x30], xmm3
000074fc119d4f09  vmovaps [rsp+0x40], xmm4
000074fc119d4f0f  vmovaps [rsp+0x50], xmm5
000074fc119d4f15  vmovaps [rsp+0x60], xmm6
000074fc119d4f1b  vmovaps [rsp+0x70], xmm8
000074fc119d4f21  vmovaps [rsp+0x80], xmm9
000074fc119d4f2a  vmovaps [rsp+0x90], xmm10
000074fc119d4f33  vmovaps [rsp+0xA0], xmm11
000074fc119d4f3c  vmovaps [rsp+0xB0], xmm12
000074fc119d4f45  vmovaps [rsp+0xC0], xmm13
000074fc119d4f4e  vmovaps [rsp+0xD0], xmm14
000074fc119d4f57  vmovaps [rsp+0xE0], xmm15
000074fc119d4f60  sub rsp, 0x30
000074fc119d4f64  movaps [rsp], xmm7
000074fc119d4f68  movaps [rsp+0x10], xmm15
000074fc119d4f6e  movaps [rsp+0x20], xmm10
000074fc119d4f74  lea rdi, [rsp]
000074fc119d4f78  mov esi, 0x00
000074fc119d4f7d  mov rax, 0x58C4C8091530
000074fc119d4f87  call rax
000074fc119d4f89  movaps xmm7, [rsp]
000074fc119d4f8d  add rsp, 0x30
000074fc119d4f91  vmovaps xmm0, [rsp]
000074fc119d4f96  vmovaps xmm1, [rsp+0x10]
000074fc119d4f9c  vmovaps xmm2, [rsp+0x20]
000074fc119d4fa2  vmovaps xmm3, [rsp+0x30]
000074fc119d4fa8  vmovaps xmm4, [rsp+0x40]
000074fc119d4fae  vmovaps xmm5, [rsp+0x50]
000074fc119d4fb4  vmovaps xmm6, [rsp+0x60]
000074fc119d4fba  vmovaps xmm8, [rsp+0x70]
000074fc119d4fc0  vmovaps xmm9, [rsp+0x80]
000074fc119d4fc9  vmovaps xmm10, [rsp+0x90]
000074fc119d4fd2  vmovaps xmm11, [rsp+0xA0]
000074fc119d4fdb  vmovaps xmm12, [rsp+0xB0]
000074fc119d4fe4  vmovaps xmm13, [rsp+0xC0]
000074fc119d4fed  vmovaps xmm14, [rsp+0xD0]
000074fc119d4ff6  vmovaps xmm15, [rsp+0xE0]
000074fc119d4fff  add rsp, 0xF0
000074fc119d5006  pop r11
000074fc119d5008  pop r10
000074fc119d500a  pop r9
000074fc119d500c  pop r8
000074fc119d500e  pop rsi
000074fc119d500f  pop rdi
000074fc119d5010  pop rdx
000074fc119d5011  pop rcx
000074fc119d5012  pop rax
000074fc119d5013  add rsp, 0x08
000074fc119d5017  jmp 0x000074FC119D025D
000074fc119d501c  sub rsp, 0x08
000074fc119d5020  push rax
000074fc119d5021  push rcx
000074fc119d5022  push rdx
000074fc119d5023  push rdi
000074fc119d5024  push rsi
000074fc119d5025  push r8
000074fc119d5027  push r9
000074fc119d5029  push r10
000074fc119d502b  push r11
000074fc119d502d  sub rsp, 0xF0
000074fc119d5034  vmovaps [rsp], xmm0
000074fc119d5039  vmovaps [rsp+0x10], xmm1
000074fc119d503f  vmovaps [rsp+0x20], xmm2
000074fc119d5045  vmovaps [rsp+0x30], xmm3
000074fc119d504b  vmovaps [rsp+0x40], xmm4
000074fc119d5051  vmovaps [rsp+0x50], xmm5
000074fc119d5057  vmovaps [rsp+0x60], xmm6
000074fc119d505d  vmovaps [rsp+0x70], xmm7
000074fc119d5063  vmovaps [rsp+0x80], xmm8
000074fc119d506c  vmovaps [rsp+0x90], xmm9
000074fc119d5075  vmovaps [rsp+0xA0], xmm11
000074fc119d507e  vmovaps [rsp+0xB0], xmm12
000074fc119d5087  vmovaps [rsp+0xC0], xmm13
000074fc119d5090  vmovaps [rsp+0xD0], xmm14
000074fc119d5099  vmovaps [rsp+0xE0], xmm15
000074fc119d50a2  sub rsp, 0x30
000074fc119d50a6  movaps [rsp], xmm10
000074fc119d50ab  movaps [rsp+0x10], xmm11
000074fc119d50b1  movaps [rsp+0x20], xmm15
000074fc119d50b7  lea rdi, [rsp]
000074fc119d50bb  mov esi, 0x00
000074fc119d50c0  mov rax, 0x58C4C8091530
000074fc119d50ca  call rax
000074fc119d50cc  movaps xmm10, [rsp]
000074fc119d50d1  add rsp, 0x30
000074fc119d50d5  vmovaps xmm0, [rsp]
000074fc119d50da  vmovaps xmm1, [rsp+0x10]
000074fc119d50e0  vmovaps xmm2, [rsp+0x20]
000074fc119d50e6  vmovaps xmm3, [rsp+0x30]
000074fc119d50ec  vmovaps xmm4, [rsp+0x40]
000074fc119d50f2  vmovaps xmm5, [rsp+0x50]
000074fc119d50f8  vmovaps xmm6, [rsp+0x60]
000074fc119d50fe  vmovaps xmm7, [rsp+0x70]
000074fc119d5104  vmovaps xmm8, [rsp+0x80]
000074fc119d510d  vmovaps xmm9, [rsp+0x90]
000074fc119d5116  vmovaps xmm11, [rsp+0xA0]
000074fc119d511f  vmovaps xmm12, [rsp+0xB0]
000074fc119d5128  vmovaps xmm13, [rsp+0xC0]
000074fc119d5131  vmovaps xmm14, [rsp+0xD0]
000074fc119d513a  vmovaps xmm15, [rsp+0xE0]
000074fc119d5143  add rsp, 0xF0
000074fc119d514a  pop r11
000074fc119d514c  pop r10
000074fc119d514e  pop r9
000074fc119d5150  pop r8
000074fc119d5152  pop rsi
000074fc119d5153  pop rdi
000074fc119d5154  pop rdx
000074fc119d5155  pop rcx
000074fc119d5156  pop rax
000074fc119d5157  add rsp, 0x08
000074fc119d515b  jmp 0x000074FC119D028B
000074fc119d5160  sub rsp, 0x08
000074fc119d5164  push rax
000074fc119d5165  push rcx
000074fc119d5166  push rdx
000074fc119d5167  push rdi
000074fc119d5168  push rsi
000074fc119d5169  push r8
000074fc119d516b  push r9
000074fc119d516d  push r10
000074fc119d516f  push r11
000074fc119d5171  sub rsp, 0xF0
000074fc119d5178  vmovaps [rsp], xmm0
000074fc119d517d  vmovaps [rsp+0x10], xmm1
000074fc119d5183  vmovaps [rsp+0x20], xmm2
000074fc119d5189  vmovaps [rsp+0x30], xmm3
000074fc119d518f  vmovaps [rsp+0x40], xmm4
000074fc119d5195  vmovaps [rsp+0x50], xmm5
000074fc119d519b  vmovaps [rsp+0x60], xmm6
000074fc119d51a1  vmovaps [rsp+0x70], xmm7
000074fc119d51a7  vmovaps [rsp+0x80], xmm8
000074fc119d51b0  vmovaps [rsp+0x90], xmm9
000074fc119d51b9  vmovaps [rsp+0xA0], xmm10
000074fc119d51c2  vmovaps [rsp+0xB0], xmm12
000074fc119d51cb  vmovaps [rsp+0xC0], xmm13
000074fc119d51d4  vmovaps [rsp+0xD0], xmm14
000074fc119d51dd  vmovaps [rsp+0xE0], xmm15
000074fc119d51e6  sub rsp, 0x30
000074fc119d51ea  movaps [rsp], xmm11
000074fc119d51ef  movaps [rsp+0x10], xmm12
000074fc119d51f5  movaps [rsp+0x20], xmm15
000074fc119d51fb  lea rdi, [rsp]
000074fc119d51ff  mov esi, 0x00
000074fc119d5204  mov rax, 0x58C4C8091530
000074fc119d520e  call rax
000074fc119d5210  movaps xmm11, [rsp]
000074fc119d5215  add rsp, 0x30
000074fc119d5219  vmovaps xmm0, [rsp]
000074fc119d521e  vmovaps xmm1, [rsp+0x10]
000074fc119d5224  vmovaps xmm2, [rsp+0x20]
000074fc119d522a  vmovaps xmm3, [rsp+0x30]
000074fc119d5230  vmovaps xmm4, [rsp+0x40]
000074fc119d5236  vmovaps xmm5, [rsp+0x50]
000074fc119d523c  vmovaps xmm6, [rsp+0x60]
000074fc119d5242  vmovaps xmm7, [rsp+0x70]
000074fc119d5248  vmovaps xmm8, [rsp+0x80]
000074fc119d5251  vmovaps xmm9, [rsp+0x90]
000074fc119d525a  vmovaps xmm10, [rsp+0xA0]
000074fc119d5263  vmovaps xmm12, [rsp+0xB0]
000074fc119d526c  vmovaps xmm13, [rsp+0xC0]
000074fc119d5275  vmovaps xmm14, [rsp+0xD0]
000074fc119d527e  vmovaps xmm15, [rsp+0xE0]
000074fc119d5287  add rsp, 0xF0
000074fc119d528e  pop r11
000074fc119d5290  pop r10
000074fc119d5292  pop r9
000074fc119d5294  pop r8
000074fc119d5296  pop rsi
000074fc119d5297  pop rdi
000074fc119d5298  pop rdx
000074fc119d5299  pop rcx
000074fc119d529a  pop rax
000074fc119d529b  add rsp, 0x08
000074fc119d529f  jmp 0x000074FC119D02B9
000074fc119d52a4  sub rsp, 0x08
000074fc119d52a8  push rax
000074fc119d52a9  push rcx
000074fc119d52aa  push rdx
000074fc119d52ab  push rdi
000074fc119d52ac  push rsi
000074fc119d52ad  push r8
000074fc119d52af  push r9
000074fc119d52b1  push r10
000074fc119d52b3  push r11
000074fc119d52b5  sub rsp, 0xF0
000074fc119d52bc  vmovaps [rsp], xmm0
000074fc119d52c1  vmovaps [rsp+0x10], xmm1
000074fc119d52c7  vmovaps [rsp+0x20], xmm2
000074fc119d52cd  vmovaps [rsp+0x30], xmm3
000074fc119d52d3  vmovaps [rsp+0x40], xmm4
000074fc119d52d9  vmovaps [rsp+0x50], xmm5
000074fc119d52df  vmovaps [rsp+0x60], xmm6
000074fc119d52e5  vmovaps [rsp+0x70], xmm7
000074fc119d52eb  vmovaps [rsp+0x80], xmm8
000074fc119d52f4  vmovaps [rsp+0x90], xmm9
000074fc119d52fd  vmovaps [rsp+0xA0], xmm10
000074fc119d5306  vmovaps [rsp+0xB0], xmm11
000074fc119d530f  vmovaps [rsp+0xC0], xmm12
000074fc119d5318  vmovaps [rsp+0xD0], xmm13
000074fc119d5321  vmovaps [rsp+0xE0], xmm14
000074fc119d532a  sub rsp, 0x30
000074fc119d532e  movaps [rsp], xmm15
000074fc119d5333  movaps [rsp+0x10], xmm13
000074fc119d5339  movaps [rsp+0x20], xmm9
000074fc119d533f  lea rdi, [rsp]
000074fc119d5343  mov esi, 0x00
000074fc119d5348  mov rax, 0x58C4C8091530
000074fc119d5352  call rax
000074fc119d5354  movaps xmm15, [rsp]
000074fc119d5359  add rsp, 0x30
000074fc119d535d  vmovaps xmm0, [rsp]
000074fc119d5362  vmovaps xmm1, [rsp+0x10]
000074fc119d5368  vmovaps xmm2, [rsp+0x20]
000074fc119d536e  vmovaps xmm3, [rsp+0x30]
000074fc119d5374  vmovaps xmm4, [rsp+0x40]
000074fc119d537a  vmovaps xmm5, [rsp+0x50]
000074fc119d5380  vmovaps xmm6, [rsp+0x60]
000074fc119d5386  vmovaps xmm7, [rsp+0x70]
000074fc119d538c  vmovaps xmm8, [rsp+0x80]
000074fc119d5395  vmovaps xmm9, [rsp+0x90]
000074fc119d539e  vmovaps xmm10, [rsp+0xA0]
000074fc119d53a7  vmovaps xmm11, [rsp+0xB0]
000074fc119d53b0  vmovaps xmm12, [rsp+0xC0]
000074fc119d53b9  vmovaps xmm13, [rsp+0xD0]
000074fc119d53c2  vmovaps xmm14, [rsp+0xE0]
000074fc119d53cb  add rsp, 0xF0
000074fc119d53d2  pop r11
000074fc119d53d4  pop r10
000074fc119d53d6  pop r9
000074fc119d53d8  pop r8
000074fc119d53da  pop rsi
000074fc119d53db  pop rdi
000074fc119d53dc  pop rdx
000074fc119d53dd  pop rcx
000074fc119d53de  pop rax
000074fc119d53df  add rsp, 0x08
000074fc119d53e3  jmp 0x000074FC119D02D4
000074fc119d53e8  sub rsp, 0x08
000074fc119d53ec  push rax
000074fc119d53ed  push rcx
000074fc119d53ee  push rdx
000074fc119d53ef  push rdi
000074fc119d53f0  push rsi
000074fc119d53f1  push r8
000074fc119d53f3  push r9
000074fc119d53f5  push r10
000074fc119d53f7  push r11
000074fc119d53f9  sub rsp, 0xF0
000074fc119d5400  vmovaps [rsp], xmm0
000074fc119d5405  vmovaps [rsp+0x10], xmm1
000074fc119d540b  vmovaps [rsp+0x20], xmm2
000074fc119d5411  vmovaps [rsp+0x30], xmm3
000074fc119d5417  vmovaps [rsp+0x40], xmm4
000074fc119d541d  vmovaps [rsp+0x50], xmm5
000074fc119d5423  vmovaps [rsp+0x60], xmm6
000074fc119d5429  vmovaps [rsp+0x70], xmm7
000074fc119d542f  vmovaps [rsp+0x80], xmm8
000074fc119d5438  vmovaps [rsp+0x90], xmm9
000074fc119d5441  vmovaps [rsp+0xA0], xmm10
000074fc119d544a  vmovaps [rsp+0xB0], xmm11
000074fc119d5453  vmovaps [rsp+0xC0], xmm12
000074fc119d545c  vmovaps [rsp+0xD0], xmm14
000074fc119d5465  vmovaps [rsp+0xE0], xmm15
000074fc119d546e  sub rsp, 0x30
000074fc119d5472  movaps [rsp], xmm13
000074fc119d5477  movaps [rsp+0x10], xmm8
000074fc119d547d  movaps [rsp+0x20], xmm14
000074fc119d5483  lea rdi, [rsp]
000074fc119d5487  mov esi, 0x00
000074fc119d548c  mov rax, 0x58C4C8091530
000074fc119d5496  call rax
000074fc119d5498  movaps xmm13, [rsp]
000074fc119d549d  add rsp, 0x30
000074fc119d54a1  vmovaps xmm0, [rsp]
000074fc119d54a6  vmovaps xmm1, [rsp+0x10]
000074fc119d54ac  vmovaps xmm2, [rsp+0x20]
000074fc119d54b2  vmovaps xmm3, [rsp+0x30]
000074fc119d54b8  vmovaps xmm4, [rsp+0x40]
000074fc119d54be  vmovaps xmm5, [rsp+0x50]
000074fc119d54c4  vmovaps xmm6, [rsp+0x60]
000074fc119d54ca  vmovaps xmm7, [rsp+0x70]
000074fc119d54d0  vmovaps xmm8, [rsp+0x80]
000074fc119d54d9  vmovaps xmm9, [rsp+0x90]
000074fc119d54e2  vmovaps xmm10, [rsp+0xA0]
000074fc119d54eb  vmovaps xmm11, [rsp+0xB0]
000074fc119d54f4  vmovaps xmm12, [rsp+0xC0]
000074fc119d54fd  vmovaps xmm14, [rsp+0xD0]
000074fc119d5506  vmovaps xmm15, [rsp+0xE0]
000074fc119d550f  add rsp, 0xF0
000074fc119d5516  pop r11
000074fc119d5518  pop r10
000074fc119d551a  pop r9
000074fc119d551c  pop r8
000074fc119d551e  pop rsi
000074fc119d551f  pop rdi
000074fc119d5520  pop rdx
000074fc119d5521  pop rcx
000074fc119d5522  pop rax
000074fc119d5523  add rsp, 0x08
000074fc119d5527  jmp 0x000074FC119D02F7
000074fc119d552c  sub rsp, 0x08
000074fc119d5530  push rax
000074fc119d5531  push rcx
000074fc119d5532  push rdx
000074fc119d5533  push rdi
000074fc119d5534  push rsi
000074fc119d5535  push r8
000074fc119d5537  push r9
000074fc119d5539  push r10
000074fc119d553b  push r11
000074fc119d553d  sub rsp, 0xF0
000074fc119d5544  vmovaps [rsp], xmm0
000074fc119d5549  vmovaps [rsp+0x10], xmm1
000074fc119d554f  vmovaps [rsp+0x20], xmm2
000074fc119d5555  vmovaps [rsp+0x30], xmm3
000074fc119d555b  vmovaps [rsp+0x40], xmm4
000074fc119d5561  vmovaps [rsp+0x50], xmm5
000074fc119d5567  vmovaps [rsp+0x60], xmm6
000074fc119d556d  vmovaps [rsp+0x70], xmm7
000074fc119d5573  vmovaps [rsp+0x80], xmm8
000074fc119d557c  vmovaps [rsp+0x90], xmm9
000074fc119d5585  vmovaps [rsp+0xA0], xmm10
000074fc119d558e  vmovaps [rsp+0xB0], xmm11
000074fc119d5597  vmovaps [rsp+0xC0], xmm12
000074fc119d55a0  vmovaps [rsp+0xD0], xmm13
000074fc119d55a9  vmovaps [rsp+0xE0], xmm15
000074fc119d55b2  sub rsp, 0x30
000074fc119d55b6  movaps [rsp], xmm14
000074fc119d55bb  movaps [rsp+0x10], xmm1
000074fc119d55c0  movaps [rsp+0x20], xmm10
000074fc119d55c6  lea rdi, [rsp]
000074fc119d55ca  mov esi, 0x00
000074fc119d55cf  mov rax, 0x58C4C8091530
000074fc119d55d9  call rax
000074fc119d55db  movaps xmm14, [rsp]
000074fc119d55e0  add rsp, 0x30
000074fc119d55e4  vmovaps xmm0, [rsp]
000074fc119d55e9  vmovaps xmm1, [rsp+0x10]
000074fc119d55ef  vmovaps xmm2, [rsp+0x20]
000074fc119d55f5  vmovaps xmm3, [rsp+0x30]
000074fc119d55fb  vmovaps xmm4, [rsp+0x40]
000074fc119d5601  vmovaps xmm5, [rsp+0x50]
000074fc119d5607  vmovaps xmm6, [rsp+0x60]
000074fc119d560d  vmovaps xmm7, [rsp+0x70]
000074fc119d5613  vmovaps xmm8, [rsp+0x80]
000074fc119d561c  vmovaps xmm9, [rsp+0x90]
000074fc119d5625  vmovaps xmm10, [rsp+0xA0]
000074fc119d562e  vmovaps xmm11, [rsp+0xB0]
000074fc119d5637  vmovaps xmm12, [rsp+0xC0]
000074fc119d5640  vmovaps xmm13, [rsp+0xD0]
000074fc119d5649  vmovaps xmm15, [rsp+0xE0]
000074fc119d5652  add rsp, 0xF0
000074fc119d5659  pop r11
000074fc119d565b  pop r10
000074fc119d565d  pop r9
000074fc119d565f  pop r8
000074fc119d5661  pop rsi
000074fc119d5662  pop rdi
000074fc119d5663  pop rdx
000074fc119d5664  pop rcx
000074fc119d5665  pop rax
000074fc119d5666  add rsp, 0x08
000074fc119d566a  jmp 0x000074FC119D031A
000074fc119d566f  sub rsp, 0x08
000074fc119d5673  push rax
000074fc119d5674  push rcx
000074fc119d5675  push rdx
000074fc119d5676  push rdi
000074fc119d5677  push rsi
000074fc119d5678  push r8
000074fc119d567a  push r9
000074fc119d567c  push r10
000074fc119d567e  push r11
000074fc119d5680  sub rsp, 0xF0
000074fc119d5687  vmovaps [rsp], xmm0
000074fc119d568c  vmovaps [rsp+0x10], xmm2
000074fc119d5692  vmovaps [rsp+0x20], xmm3
000074fc119d5698  vmovaps [rsp+0x30], xmm4
000074fc119d569e  vmovaps [rsp+0x40], xmm5
000074fc119d56a4  vmovaps [rsp+0x50], xmm6
000074fc119d56aa  vmovaps [rsp+0x60], xmm7
000074fc119d56b0  vmovaps [rsp+0x70], xmm8
000074fc119d56b6  vmovaps [rsp+0x80], xmm9
000074fc119d56bf  vmovaps [rsp+0x90], xmm10
000074fc119d56c8  vmovaps [rsp+0xA0], xmm11
000074fc119d56d1  vmovaps [rsp+0xB0], xmm12
000074fc119d56da  vmovaps [rsp+0xC0], xmm13
000074fc119d56e3  vmovaps [rsp+0xD0], xmm14
000074fc119d56ec  vmovaps [rsp+0xE0], xmm15
000074fc119d56f5  sub rsp, 0x30
000074fc119d56f9  movaps [rsp], xmm1
000074fc119d56fd  movaps [rsp+0x10], xmm7
000074fc119d5702  movaps [rsp+0x20], xmm11
000074fc119d5708  lea rdi, [rsp]
000074fc119d570c  mov esi, 0x00
000074fc119d5711  mov rax, 0x58C4C8091530
000074fc119d571b  call rax
000074fc119d571d  movaps xmm1, [rsp]
000074fc119d5721  add rsp, 0x30
000074fc119d5725  vmovaps xmm0, [rsp]
000074fc119d572a  vmovaps xmm2, [rsp+0x10]
000074fc119d5730  vmovaps xmm3, [rsp+0x20]
000074fc119d5736  vmovaps xmm4, [rsp+0x30]
000074fc119d573c  vmovaps xmm5, [rsp+0x40]
000074fc119d5742  vmovaps xmm6, [rsp+0x50]
000074fc119d5748  vmovaps xmm7, [rsp+0x60]
000074fc119d574e  vmovaps xmm8, [rsp+0x70]
000074fc119d5754  vmovaps xmm9, [rsp+0x80]
000074fc119d575d  vmovaps xmm10, [rsp+0x90]
000074fc119d5766  vmovaps xmm11, [rsp+0xA0]
000074fc119d576f  vmovaps xmm12, [rsp+0xB0]
000074fc119d5778  vmovaps xmm13, [rsp+0xC0]
000074fc119d5781  vmovaps xmm14, [rsp+0xD0]
000074fc119d578a  vmovaps xmm15, [rsp+0xE0]
000074fc119d5793  add rsp, 0xF0
000074fc119d579a  pop r11
000074fc119d579c  pop r10
000074fc119d579e  pop r9
000074fc119d57a0  pop r8
000074fc119d57a2  pop rsi
000074fc119d57a3  pop rdi
000074fc119d57a4  pop rdx
000074fc119d57a5  pop rcx
000074fc119d57a6  pop rax
000074fc119d57a7  add rsp, 0x08
000074fc119d57ab  jmp 0x000074FC119D033B
000074fc119d57b0  call 0x000074FC1180E880
000074fc119d57b5  jmp 0x000074FC119D034E
000074fc119d57ba  call 0x000074FC1180C380
000074fc119d57bf  jmp 0x000074FC119D0359
000074fc119d57c4  call 0x000074FC1180D600
000074fc119d57c9  jmp 0x000074FC119D0364
000074fc119d57ce  call 0x000074FC117FF540
000074fc119d57d3  jmp 0x000074FC119D036F
000074fc119d57d8  int3
000074fc119d57d9  nop [rax], eax
000074fc119d57e0  mov rax, [r15+0x40]
000074fc119d57e4  mov r14, [r15+0x58]
000074fc119d57e8  lea r12, [rax+r14*1]
000074fc119d57ec  movaps xmm1, [r15+0x1D0]
000074fc119d57f4  vmovaps [rsp+0x10], xmm1
000074fc119d57fa  vmovaps xmm15, [rsp+0x10]
000074fc119d5800  por xmm1, xmm15
000074fc119d5805  movaps xmm14, [r15+0x1A0]
000074fc119d580d  vmovaps [rsp+0x10], xmm14
000074fc119d5813  vmovaps xmm13, [rsp+0x10]
000074fc119d5819  por xmm14, xmm13
000074fc119d581e  lea rax, [r12+0x30]
000074fc119d5823  mov r11, [r13+rax*1]
000074fc119d5828  lea rax, [r12+0x38]
000074fc119d582d  mov r10, [r13+rax*1]
000074fc119d5832  movq xmm13, r11
000074fc119d5837  movq xmm12, r10
000074fc119d583c  movq xmm13, xmm13
000074fc119d5841  vmovaps [rsp+0x10], xmm13
000074fc119d5847  movq xmm13, xmm13
000074fc119d584c  movaps [r15+0x130], xmm13
000074fc119d5854  movq xmm12, xmm12
000074fc119d5859  vmovaps [rsp+0x20], xmm12
000074fc119d585f  movq xmm12, xmm12
000074fc119d5864  movaps [r15+0x280], xmm12
000074fc119d586c  movaps xmm13, [r15+0x270]
000074fc119d5874  vmovaps [rsp+0x30], xmm13
000074fc119d587a  vmovaps xmm12, [rsp+0x30]
000074fc119d5880  por xmm13, xmm12
000074fc119d5885  lea rax, [r12+0x20]
000074fc119d588a  mov r11, [r13+rax*1]
000074fc119d588f  lea rax, [r12+0x28]
000074fc119d5894  mov r10, [r13+rax*1]
000074fc119d5899  movq xmm12, r11
000074fc119d589e  movq xmm11, r10
000074fc119d58a3  movq xmm12, xmm12
000074fc119d58a8  vmovaps [rsp+0x30], xmm12
000074fc119d58ae  movq xmm12, xmm12
000074fc119d58b3  movaps [r15+0x150], xmm12
000074fc119d58bb  movq xmm11, xmm11
000074fc119d58c0  vmovaps [rsp+0x40], xmm11
000074fc119d58c6  movq xmm11, xmm11
000074fc119d58cb  movaps [r15+0x140], xmm11
000074fc119d58d3  lea rax, [r12+0x10]
000074fc119d58d8  mov r11, [r13+rax*1]
000074fc119d58dd  lea rax, [r12+0x18]
000074fc119d58e2  mov r10, [r13+rax*1]
000074fc119d58e7  movq xmm12, r11
000074fc119d58ec  movq xmm11, r10
000074fc119d58f1  movq xmm12, xmm12
000074fc119d58f6  vmovaps [rsp+0x50], xmm12
000074fc119d58fc  movq xmm12, xmm12
000074fc119d5901  movaps [r15+0x170], xmm12
000074fc119d5909  movq xmm11, xmm11
000074fc119d590e  vmovaps [rsp+0x60], xmm11
000074fc119d5914  movq xmm11, xmm11
000074fc119d5919  movaps [r15+0x160], xmm11
000074fc119d5921  mov rax, [r13+r12*1]
000074fc119d5926  vmovq xmm12, rax
000074fc119d592b  vpbroadcastq xmm12, xmm12
000074fc119d5930  lea rax, [r12+0x08]
000074fc119d5935  mov r12, [r13+rax*1]
000074fc119d593a  movq xmm11, r12
000074fc119d593f  movaps [r15+0x230], xmm11
000074fc119d5947  mov rax, [r15+0xF8]
000074fc119d594e  lea r12, [rax+0x50]
000074fc119d5952  movups xmm11, [r13+r12*1]
000074fc119d5958  lea r12, [rax+0x60]
000074fc119d595c  movups xmm10, [r13+r12*1]
000074fc119d5962  lea r12, [rax+0x30]
000074fc119d5966  movups xmm9, [r13+r12*1]
000074fc119d596c  mov r12, [r15+0x50]
000074fc119d5970  lea r11, [r12+r14*1]
000074fc119d5974  mov [r15+0x60], r11
000074fc119d5978  lea r12, [r14+0x40]
000074fc119d597c  mov [r15+0x58], r12
000074fc119d5980  movaps xmm8, xmm12
000074fc119d5984  mulpd xmm8, xmm15
000074fc119d5989  vcmppd xmm7, xmm8, xmm8, 0x03
000074fc119d598f  ptest xmm7, xmm7
000074fc119d5994  jnz 0x000074FC119D67B7
000074fc119d599a  movq xmm15, qword ptr [r15+0x230]
000074fc119d59a3  vmovaps [rsp+0x70], xmm15
000074fc119d59a9  vpermilpd xmm15, xmm15, 0x00
000074fc119d59af  movaps xmm7, xmm9
000074fc119d59b3  mulpd xmm7, xmm15
000074fc119d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000074fc119d59bd  ptest xmm6, xmm6
000074fc119d59c2  jnz 0x000074FC119D68FB
000074fc119d59c8  vxorps xmm15, xmm15, xmm15
000074fc119d59cd  vpbroadcastq xmm15, xmm15
000074fc119d59d2  movaps xmm9, xmm12
000074fc119d59d6  mulpd xmm9, xmm10
000074fc119d59db  vcmppd xmm6, xmm9, xmm9, 0x03
000074fc119d59e1  ptest xmm6, xmm6
000074fc119d59e6  jnz 0x000074FC119D6A3D
000074fc119d59ec  movaps xmm10, xmm12
000074fc119d59f0  mulpd xmm10, xmm11
000074fc119d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000074fc119d59fb  ptest xmm6, xmm6
000074fc119d5a00  jnz 0x000074FC119D6B81
000074fc119d5a06  movaps xmm11, [r15+0x1F0]
000074fc119d5a0e  movaps xmm6, xmm12
000074fc119d5a12  mulpd xmm6, xmm11
000074fc119d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000074fc119d5a1c  ptest xmm5, xmm5
000074fc119d5a21  jnz 0x000074FC119D6CC5
000074fc119d5a27  movaps xmm12, [r15+0x2A0]
000074fc119d5a2f  vmovaps [rsp+0x80], xmm12
000074fc119d5a38  vmovaps xmm11, [rsp+0x80]
000074fc119d5a41  por xmm12, xmm11
000074fc119d5a46  movaps xmm11, [r15+0x250]
000074fc119d5a4e  vmovaps [rsp+0x80], xmm11
000074fc119d5a57  vmovaps xmm5, [rsp+0x80]
000074fc119d5a60  por xmm11, xmm5
000074fc119d5a65  vmovaps xmm4, [rsp+0x70]
000074fc119d5a6b  vpermilpd xmm4, xmm4, 0x00
000074fc119d5a71  movaps xmm3, xmm5
000074fc119d5a74  mulpd xmm3, xmm4
000074fc119d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000074fc119d5a7d  ptest xmm2, xmm2
000074fc119d5a82  jnz 0x000074FC119D6E07
000074fc119d5a88  mov [rsp+0x80], rax
000074fc119d5a90  xor eax, eax
000074fc119d5a92  mov r14d, 0x200
000074fc119d5a98  cmp r12, r14
000074fc119d5a9b  cmc
000074fc119d5a9c  lahf
000074fc119d5a9d  seto al
000074fc119d5aa0  mov [r15+0x108], eax
000074fc119d5aa7  movaps xmm5, xmm8
000074fc119d5aab  addpd xmm5, xmm15
000074fc119d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000074fc119d5ab5  ptest xmm4, xmm4
000074fc119d5aba  jnz 0x000074FC119D6F47
000074fc119d5ac0  movaps xmm8, [r15+0x1B0]
000074fc119d5ac8  movaps xmm4, xmm9
000074fc119d5acc  addpd xmm4, xmm8
000074fc119d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000074fc119d5ad6  ptest xmm2, xmm2
000074fc119d5adb  jnz 0x000074FC119D7089
000074fc119d5ae1  movaps xmm9, xmm10
000074fc119d5ae5  addpd xmm9, xmm8
000074fc119d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000074fc119d5af0  ptest xmm2, xmm2
000074fc119d5af5  jnz 0x000074FC119D71CB
000074fc119d5afb  movaps xmm10, [r15+0x2F0]
000074fc119d5b03  vmovaps [rsp+0x90], xmm10
000074fc119d5b0c  vmovaps xmm8, [rsp+0x90]
000074fc119d5b15  por xmm10, xmm8
000074fc119d5b1a  movaps xmm8, [r15+0x2E0]
000074fc119d5b22  vmovaps [rsp+0x90], xmm8
000074fc119d5b2b  vmovaps xmm2, [rsp+0x90]
000074fc119d5b34  por xmm8, xmm2
000074fc119d5b39  movaps xmm2, [r15+0x2D0]
000074fc119d5b41  vmovaps [rsp+0x90], xmm2
000074fc119d5b4a  vmovaps [rsp+0xA0], xmm1
000074fc119d5b53  vmovaps xmm1, [rsp+0x90]
000074fc119d5b5c  por xmm2, xmm1
000074fc119d5b60  movaps xmm1, [r15+0x200]
000074fc119d5b68  vmovaps [rsp+0x90], xmm1
000074fc119d5b71  vmovaps [rsp+0xB0], xmm15
000074fc119d5b7a  vmovaps xmm15, [rsp+0x90]
000074fc119d5b83  por xmm1, xmm15
000074fc119d5b88  movaps xmm15, [r15+0x1C0]
000074fc119d5b90  vmovaps [rsp+0x90], xmm15
000074fc119d5b99  vmovaps [rsp+0xC0], xmm1
000074fc119d5ba2  vmovaps xmm1, [rsp+0x90]
000074fc119d5bab  por xmm15, xmm1
000074fc119d5bb0  movaps xmm1, [r15+0x190]
000074fc119d5bb8  vmovaps [rsp+0x90], xmm1
000074fc119d5bc1  vmovaps [rsp+0xD0], xmm15
000074fc119d5bca  vmovaps xmm15, [rsp+0x90]
000074fc119d5bd3  por xmm1, xmm15
000074fc119d5bd8  movaps xmm15, [r15+0x300]
000074fc119d5be0  vmovaps [rsp+0x90], xmm15
000074fc119d5be9  vmovaps [rsp+0xE0], xmm1
000074fc119d5bf2  vmovaps xmm1, [rsp+0x90]
000074fc119d5bfb  por xmm15, xmm1
000074fc119d5c00  mov rax, [rsp+0x80]
000074fc119d5c08  lea r14, [rax+0xA0]
000074fc119d5c0f  movups xmm1, [r13+r14*1]
000074fc119d5c15  lea r14, [rax+0xB0]
000074fc119d5c1c  vmovaps [rsp+0x80], xmm1
000074fc119d5c25  movups xmm1, [r13+r14*1]
000074fc119d5c2b  vmovaps [rsp+0x90], xmm1
000074fc119d5c34  vmovaps [rsp+0xF0], xmm15
000074fc119d5c3d  vmovaps xmm15, [rsp+0xB0]
000074fc119d5c46  vmovaps [rsp+0xB0], xmm14
000074fc119d5c4f  movaps xmm1, xmm6
000074fc119d5c52  addpd xmm1, xmm15
000074fc119d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000074fc119d5c5c  ptest xmm14, xmm14
000074fc119d5c62  jnz 0x000074FC119D7323
000074fc119d5c68  lea r14, [rax+0xF0]
000074fc119d5c6f  movups xmm15, [r13+r14*1]
000074fc119d5c75  movaps xmm14, xmm4
000074fc119d5c79  addpd xmm14, xmm3
000074fc119d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000074fc119d5c84  ptest xmm6, xmm6
000074fc119d5c89  jnz 0x000074FC119D746E
000074fc119d5c8f  movaps xmm6, xmm9
000074fc119d5c93  addpd xmm6, xmm7
000074fc119d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000074fc119d5c9c  ptest xmm4, xmm4
000074fc119d5ca1  jnz 0x000074FC119D75B0
000074fc119d5ca7  vmovaps xmm9, [rsp+0x70]
000074fc119d5cad  vpermilpd xmm9, xmm9, 0x00
000074fc119d5cb3  vmovaps xmm4, [rsp+0x90]
000074fc119d5cbc  movaps xmm7, xmm4
000074fc119d5cbf  mulpd xmm7, xmm9
000074fc119d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000074fc119d5cc9  ptest xmm3, xmm3
000074fc119d5cce  jnz 0x000074FC119D76F1
000074fc119d5cd4  vmovaps xmm9, [rsp+0x50]
000074fc119d5cda  vpermilpd xmm9, xmm9, 0x00
000074fc119d5ce0  movaps xmm4, xmm15
000074fc119d5ce4  mulpd xmm4, xmm9
000074fc119d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000074fc119d5cee  ptest xmm3, xmm3
000074fc119d5cf3  jnz 0x000074FC119D7832
000074fc119d5cf9  lea r14, [rax+0xE0]
000074fc119d5d00  movups xmm15, [r13+r14*1]
000074fc119d5d06  vmovaps xmm9, [rsp+0x70]
000074fc119d5d0c  vpermilpd xmm9, xmm9, 0x00
000074fc119d5d12  vmovaps [rsp+0x70], xmm1
000074fc119d5d18  vmovaps xmm1, [rsp+0x80]
000074fc119d5d21  vmovaps [rsp+0x80], xmm15
000074fc119d5d2a  movaps xmm3, xmm1
000074fc119d5d2d  mulpd xmm3, xmm9
000074fc119d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000074fc119d5d37  ptest xmm15, xmm15
000074fc119d5d3d  jnz 0x000074FC119D797E
000074fc119d5d43  vmovaps xmm1, [rsp+0xF0]
000074fc119d5d4c  vmovaps xmm15, [rsp+0xF0]
000074fc119d5d55  por xmm1, xmm15
000074fc119d5d5a  movaps [r15+0x300], xmm1
000074fc119d5d62  vmovaps xmm15, [rsp+0xE0]
000074fc119d5d6b  vmovaps xmm9, [rsp+0xE0]
000074fc119d5d74  por xmm15, xmm9
000074fc119d5d79  movaps [r15+0x190], xmm15
000074fc119d5d81  vmovaps xmm9, [rsp+0x50]
000074fc119d5d87  vpermilpd xmm9, xmm9, 0x00
000074fc119d5d8d  vmovaps [rsp+0x90], xmm1
000074fc119d5d96  vmovaps [rsp+0xE0], xmm15
000074fc119d5d9f  vmovaps xmm15, [rsp+0x80]
000074fc119d5da8  vmovaps [rsp+0x80], xmm14
000074fc119d5db1  movaps xmm1, xmm15
000074fc119d5db5  mulpd xmm1, xmm9
000074fc119d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000074fc119d5dbf  ptest xmm14, xmm14
000074fc119d5dc5  jnz 0x000074FC119D7ABF
000074fc119d5dcb  lea r14, [rax+0x90]
000074fc119d5dd2  movups xmm15, [r13+r14*1]
000074fc119d5dd8  vmovaps xmm14, [rsp+0xD0]
000074fc119d5de1  vmovaps xmm9, [rsp+0xD0]
000074fc119d5dea  por xmm14, xmm9
000074fc119d5def  movaps [r15+0x1C0], xmm14
000074fc119d5df7  vmovaps xmm9, [rsp+0xC0]
000074fc119d5e00  vmovaps [rsp+0xD0], xmm1
000074fc119d5e09  vmovaps xmm1, [rsp+0xC0]
000074fc119d5e12  por xmm9, xmm1
000074fc119d5e17  movaps [r15+0x200], xmm9
000074fc119d5e1f  vmovaps [rsp+0xC0], xmm2
000074fc119d5e28  vmovaps xmm1, [rsp+0xC0]
000074fc119d5e31  por xmm2, xmm1
000074fc119d5e35  movaps [r15+0x2D0], xmm2
000074fc119d5e3d  vmovaps [rsp+0xC0], xmm8
000074fc119d5e46  vmovaps xmm1, [rsp+0xC0]
000074fc119d5e4f  por xmm8, xmm1
000074fc119d5e54  movaps [r15+0x2E0], xmm8
000074fc119d5e5c  vmovaps [rsp+0xC0], xmm15
000074fc119d5e65  movaps xmm1, xmm5
000074fc119d5e68  addpd xmm1, xmm7
000074fc119d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000074fc119d5e71  ptest xmm15, xmm15
000074fc119d5e77  jnz 0x000074FC119D7C0B
000074fc119d5e7d  vmovaps xmm15, [rsp+0x50]
000074fc119d5e83  vpermilpd xmm15, xmm15, 0x00
000074fc119d5e89  vmovaps xmm5, [rsp+0xC0]
000074fc119d5e92  vmovaps [rsp+0xC0], xmm1
000074fc119d5e9b  movaps xmm7, xmm5
000074fc119d5e9e  mulpd xmm7, xmm15
000074fc119d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000074fc119d5ea8  ptest xmm1, xmm1
000074fc119d5ead  jnz 0x000074FC119D7D4B
000074fc119d5eb3  lea r14, [rax+0x80]
000074fc119d5eba  movups xmm1, [r13+r14*1]
000074fc119d5ec0  vmovaps xmm5, [rsp+0x70]
000074fc119d5ec6  vmovaps [rsp+0x70], xmm1
000074fc119d5ecc  movaps xmm15, xmm5
000074fc119d5ed0  addpd xmm15, xmm3
000074fc119d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000074fc119d5edb  ptest xmm1, xmm1
000074fc119d5ee0  jnz 0x000074FC119D7E96
000074fc119d5ee6  vmovaps xmm5, [rsp+0x80]
000074fc119d5eef  movaps xmm1, xmm5
000074fc119d5ef2  addpd xmm1, xmm4
000074fc119d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000074fc119d5efb  ptest xmm3, xmm3
000074fc119d5f00  jnz 0x000074FC119D7FD8
000074fc119d5f06  vmovaps [rsp+0x80], xmm10
000074fc119d5f0f  vmovaps xmm5, [rsp+0x80]
000074fc119d5f18  por xmm10, xmm5
000074fc119d5f1d  movaps [r15+0x2F0], xmm10
000074fc119d5f25  vmovaps xmm5, [rsp+0x50]
000074fc119d5f2b  vpermilpd xmm5, xmm5, 0x00
000074fc119d5f31  vmovaps xmm3, [rsp+0x70]
000074fc119d5f37  vmovaps [rsp+0x50], xmm1
000074fc119d5f3d  movaps xmm4, xmm3
000074fc119d5f40  mulpd xmm4, xmm5
000074fc119d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000074fc119d5f49  ptest xmm1, xmm1
000074fc119d5f4e  jnz 0x000074FC119D8118
000074fc119d5f54  lea r14, [rax+0xD0]
000074fc119d5f5b  movups xmm1, [r13+r14*1]
000074fc119d5f61  vmovaps xmm3, [rsp+0xD0]
000074fc119d5f6a  vmovaps [rsp+0x70], xmm1
000074fc119d5f70  movaps xmm5, xmm6
000074fc119d5f73  addpd xmm5, xmm3
000074fc119d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000074fc119d5f7c  ptest xmm1, xmm1
000074fc119d5f81  jnz 0x000074FC119D8262
000074fc119d5f87  vmovaps xmm1, [rsp+0x60]
000074fc119d5f8d  vpermilpd xmm1, xmm1, 0x00
000074fc119d5f93  movaps xmm6, xmm9
000074fc119d5f97  mulpd xmm6, xmm1
000074fc119d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000074fc119d5fa0  ptest xmm3, xmm3
000074fc119d5fa5  jnz 0x000074FC119D83A2
000074fc119d5fab  movaps [r15+0x260], xmm6
000074fc119d5fb3  vxorps xmm1, xmm1, xmm1
000074fc119d5fb7  vpbroadcastq xmm1, xmm1
000074fc119d5fbc  movaps [r15+0x1B0], xmm1
000074fc119d5fc4  vmovaps xmm1, [rsp+0x60]
000074fc119d5fca  vpermilpd xmm1, xmm1, 0x00
000074fc119d5fd0  vmovaps xmm3, [rsp+0x70]
000074fc119d5fd6  vmovaps [rsp+0x70], xmm15
000074fc119d5fdc  movaps xmm9, xmm3
000074fc119d5fe0  mulpd xmm9, xmm1
000074fc119d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000074fc119d5feb  ptest xmm15, xmm15
000074fc119d5ff1  jnz 0x000074FC119D84E3
000074fc119d5ff7  lea r14, [rax+0xC0]
000074fc119d5ffe  movups xmm1, [r13+r14*1]
000074fc119d6004  vmovaps xmm3, [rsp+0xC0]
000074fc119d600d  vmovaps [rsp+0x80], xmm1
000074fc119d6016  movaps xmm15, xmm3
000074fc119d601a  addpd xmm15, xmm7
000074fc119d601f  vcmppd xmm1, xmm15, xmm15, 0x03
000074fc119d6025  ptest xmm1, xmm1
000074fc119d602a  jnz 0x000074FC119D862F
000074fc119d6030  vmovaps [rsp+0xC0], xmm13
000074fc119d6039  vmovaps xmm1, [rsp+0xC0]
000074fc119d6042  por xmm13, xmm1
000074fc119d6047  movaps [r15+0x270], xmm13
000074fc119d604f  vmovaps xmm1, [rsp+0xB0]
000074fc119d6058  vmovaps xmm7, [rsp+0xB0]
000074fc119d6061  por xmm1, xmm7
000074fc119d6065  movaps [r15+0x1A0], xmm1
000074fc119d606d  vmovaps xmm1, [rsp+0x60]
000074fc119d6073  vpermilpd xmm1, xmm1, 0x00
000074fc119d6079  vmovaps [rsp+0xB0], xmm1
000074fc119d6082  vmovaps xmm1, [rsp+0x80]
000074fc119d608b  vmovaps [rsp+0x80], xmm15
000074fc119d6094  vmovaps xmm15, [rsp+0xB0]
000074fc119d609d  vmovaps [rsp+0xB0], xmm14
000074fc119d60a6  movaps xmm3, xmm1
000074fc119d60a9  mulpd xmm3, xmm15
000074fc119d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000074fc119d60b3  ptest xmm14, xmm14
000074fc119d60b9  jnz 0x000074FC119D8771
000074fc119d60bf  lea r14, [rax+0x20]
000074fc119d60c3  movups xmm1, [r13+r14*1]
000074fc119d60c9  movaps [r15+0x110], xmm1
000074fc119d60d1  vmovaps xmm14, [rsp+0x70]
000074fc119d60d7  vmovaps [rsp+0x70], xmm1
000074fc119d60dd  movaps xmm15, xmm14
000074fc119d60e1  addpd xmm15, xmm4
000074fc119d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000074fc119d60ec  ptest xmm1, xmm1
000074fc119d60f1  jnz 0x000074FC119D88BC
000074fc119d60f7  vmovaps xmm1, [rsp+0x60]
000074fc119d60fd  vpermilpd xmm1, xmm1, 0x00
000074fc119d6103  movaps xmm14, xmm2
000074fc119d6107  mulpd xmm14, xmm1
000074fc119d610c  vcmppd xmm4, xmm14, xmm14, 0x03
000074fc119d6112  ptest xmm4, xmm4
000074fc119d6117  jnz 0x000074FC119D89FF
000074fc119d611d  vmovaps xmm4, [rsp+0x50]
000074fc119d6123  movaps xmm1, xmm4
000074fc119d6126  addpd xmm1, xmm9
000074fc119d612b  vcmppd xmm2, xmm1, xmm1, 0x03
000074fc119d6130  ptest xmm2, xmm2
000074fc119d6135  jnz 0x000074FC119D8B41
000074fc119d613b  vmovaps xmm9, [rsp+0x30]
000074fc119d6141  vpermilpd xmm9, xmm9, 0x00
000074fc119d6147  vmovaps xmm2, [rsp+0x70]
000074fc119d614d  vmovaps [rsp+0x50], xmm1
000074fc119d6153  movaps xmm4, xmm2
000074fc119d6156  mulpd xmm4, xmm9
000074fc119d615b  vcmppd xmm1, xmm4, xmm4, 0x03
000074fc119d6160  ptest xmm1, xmm1
000074fc119d6165  jnz 0x000074FC119D8C82
000074fc119d616b  vmovaps xmm1, [rsp+0x30]
000074fc119d6171  vpermilpd xmm1, xmm1, 0x00
000074fc119d6177  vmovaps xmm2, [rsp+0x90]
000074fc119d6180  vmovaps [rsp+0x60], xmm15
000074fc119d6186  movaps xmm9, xmm2
000074fc119d618a  mulpd xmm9, xmm1
000074fc119d618f  vcmppd xmm15, xmm9, xmm9, 0x03
000074fc119d6195  ptest xmm15, xmm15
000074fc119d619b  jnz 0x000074FC119D8DC3
000074fc119d61a1  vmovaps xmm15, [rsp+0x80]
000074fc119d61aa  movaps xmm1, xmm15
000074fc119d61ae  addpd xmm1, xmm6
000074fc119d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000074fc119d61b7  ptest xmm2, xmm2
000074fc119d61bc  jnz 0x000074FC119D8F05
000074fc119d61c2  movaps xmm15, xmm5
000074fc119d61c6  addpd xmm15, xmm3
000074fc119d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000074fc119d61d1  ptest xmm6, xmm6
000074fc119d61d6  jnz 0x000074FC119D9046
000074fc119d61dc  vmovaps xmm6, [rsp+0x30]
000074fc119d61e2  vpermilpd xmm6, xmm6, 0x00
000074fc119d61e8  movaps xmm5, xmm8
000074fc119d61ec  mulpd xmm5, xmm6
000074fc119d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000074fc119d61f5  ptest xmm3, xmm3
000074fc119d61fa  jnz 0x000074FC119D9188
000074fc119d6200  vmovaps xmm8, [rsp+0x30]
000074fc119d6206  vpermilpd xmm8, xmm8, 0x00
000074fc119d620c  movaps xmm6, xmm10
000074fc119d6210  mulpd xmm6, xmm8
000074fc119d6215  vcmppd xmm3, xmm6, xmm6, 0x03
000074fc119d621a  ptest xmm3, xmm3
000074fc119d621f  jnz 0x000074FC119D92C9
000074fc119d6225  vmovaps xmm8, [rsp+0x60]
000074fc119d622b  movaps xmm10, xmm8
000074fc119d622f  addpd xmm10, xmm14
000074fc119d6234  vcmppd xmm3, xmm10, xmm10, 0x03
000074fc119d623a  ptest xmm3, xmm3
000074fc119d623f  jnz 0x000074FC119D940B
000074fc119d6245  vmovaps xmm8, [rsp+0x50]
000074fc119d624b  movaps xmm14, xmm8
000074fc119d624f  addpd xmm14, xmm4
000074fc119d6254  vcmppd xmm3, xmm14, xmm14, 0x03
000074fc119d625a  ptest xmm3, xmm3
000074fc119d625f  jnz 0x000074FC119D954F
000074fc119d6265  vmovaps xmm8, [rsp+0x40]
000074fc119d626b  vpermilpd xmm8, xmm8, 0x00
000074fc119d6271  movaps xmm4, xmm13
000074fc119d6275  mulpd xmm4, xmm8
000074fc119d627a  vcmppd xmm3, xmm4, xmm4, 0x03
000074fc119d627f  ptest xmm3, xmm3
000074fc119d6284  jnz 0x000074FC119D9692
000074fc119d628a  movaps xmm13, xmm15
000074fc119d628e  addpd xmm13, xmm9
000074fc119d6293  vcmppd xmm8, xmm13, xmm13, 0x03
000074fc119d6299  ptest xmm8, xmm8
000074fc119d629f  jnz 0x000074FC119D97D4
000074fc119d62a5  movaps xmm15, xmm1
000074fc119d62a9  addpd xmm15, xmm5
000074fc119d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000074fc119d62b4  ptest xmm9, xmm9
000074fc119d62ba  jnz 0x000074FC119D9918
000074fc119d62c0  vmovaps [rsp+0x30], xmm11
000074fc119d62c6  vmovaps xmm1, [rsp+0x30]
000074fc119d62cc  por xmm11, xmm1
000074fc119d62d1  movaps [r15+0x250], xmm11
000074fc119d62d9  vmovaps [rsp+0x30], xmm12
000074fc119d62df  vmovaps xmm1, [rsp+0x30]
000074fc119d62e5  por xmm12, xmm1
000074fc119d62ea  movaps [r15+0x2A0], xmm12
000074fc119d62f2  vmovaps xmm1, [rsp+0xA0]
000074fc119d62fb  vmovaps xmm11, [rsp+0xA0]
000074fc119d6304  por xmm1, xmm11
000074fc119d6309  movaps [r15+0x1D0], xmm1
000074fc119d6311  lea r14, [rax+0x40]
000074fc119d6315  movups xmm1, [r13+r14*1]
000074fc119d631b  movaps [r15+0x2C0], xmm1
000074fc119d6323  vmovaps xmm11, [rsp+0x40]
000074fc119d6329  vpermilpd xmm11, xmm11, 0x00
000074fc119d632f  vmovaps xmm8, [rsp+0xE0]
000074fc119d6338  movaps xmm9, xmm8
000074fc119d633c  mulpd xmm9, xmm11
000074fc119d6341  vcmppd xmm5, xmm9, xmm9, 0x03
000074fc119d6347  ptest xmm5, xmm5
000074fc119d634c  jnz 0x000074FC119D9A64
000074fc119d6352  movaps xmm11, xmm10
000074fc119d6356  addpd xmm11, xmm6
000074fc119d635b  vcmppd xmm8, xmm11, xmm11, 0x03
000074fc119d6361  ptest xmm8, xmm8
000074fc119d6367  jnz 0x000074FC119D9BA8
000074fc119d636d  movaps xmm10, xmm14
000074fc119d6371  addpd xmm10, xmm4
000074fc119d6376  vcmppd xmm8, xmm10, xmm10, 0x03
000074fc119d637c  ptest xmm8, xmm8
000074fc119d6382  jnz 0x000074FC119D9CEB
000074fc119d6388  vmovaps xmm14, [rsp+0x40]
000074fc119d638e  vpermilpd xmm14, xmm14, 0x00
000074fc119d6394  movaps xmm8, xmm1
000074fc119d6398  mulpd xmm8, xmm14
000074fc119d639d  vcmppd xmm6, xmm8, xmm8, 0x03
000074fc119d63a3  ptest xmm6, xmm6
000074fc119d63a8  jnz 0x000074FC119D9E2E
000074fc119d63ae  movaps xmm1, [r15+0x2B0]
000074fc119d63b6  vmovaps xmm14, [rsp+0x40]
000074fc119d63bc  vpermilpd xmm14, xmm14, 0x00
000074fc119d63c2  movaps xmm6, xmm1
000074fc119d63c5  mulpd xmm6, xmm14
000074fc119d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000074fc119d63cf  ptest xmm5, xmm5
000074fc119d63d4  jnz 0x000074FC119D9F71
000074fc119d63da  vmovaps xmm1, [rsp+0x10]
000074fc119d63e0  vpermilpd xmm1, xmm1, 0x00
000074fc119d63e6  movaps xmm14, xmm12
000074fc119d63ea  mulpd xmm14, xmm1
000074fc119d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000074fc119d63f5  ptest xmm5, xmm5
000074fc119d63fa  jnz 0x000074FC119DA0B2
000074fc119d6400  movaps xmm1, xmm13
000074fc119d6404  addpd xmm1, xmm9
000074fc119d6409  vcmppd xmm12, xmm1, xmm1, 0x03
000074fc119d640e  ptest xmm12, xmm12
000074fc119d6414  jnz 0x000074FC119DA1F5
000074fc119d641a  vmovaps xmm13, [rsp+0x10]
000074fc119d6420  vpermilpd xmm13, xmm13, 0x00
000074fc119d6426  movaps xmm12, xmm7
000074fc119d642a  mulpd xmm12, xmm13
000074fc119d642f  vcmppd xmm9, xmm12, xmm12, 0x03
000074fc119d6435  ptest xmm9, xmm9
000074fc119d643b  jnz 0x000074FC119DA337
000074fc119d6441  movaps xmm13, xmm15
000074fc119d6445  addpd xmm13, xmm8
000074fc119d644a  vcmppd xmm9, xmm13, xmm13, 0x03
000074fc119d6450  ptest xmm9, xmm9
000074fc119d6456  jnz 0x000074FC119DA47A
000074fc119d645c  movaps xmm15, [r15+0x290]
000074fc119d6464  vmovaps xmm9, [rsp+0x10]
000074fc119d646a  vpermilpd xmm9, xmm9, 0x00
000074fc119d6470  movaps xmm8, xmm15
000074fc119d6474  mulpd xmm8, xmm9
000074fc119d6479  vcmppd xmm7, xmm8, xmm8, 0x03
000074fc119d647f  ptest xmm7, xmm7
000074fc119d6484  jnz 0x000074FC119DA5BE
000074fc119d648a  movaps xmm15, xmm11
000074fc119d648e  addpd xmm15, xmm6
000074fc119d6493  vcmppd xmm9, xmm15, xmm15, 0x03
000074fc119d6499  ptest xmm9, xmm9
000074fc119d649f  jnz 0x000074FC119DA702
000074fc119d64a5  movaps xmm11, [r15+0x1E0]
000074fc119d64ad  vmovaps xmm9, [rsp+0x10]
000074fc119d64b3  vpermilpd xmm9, xmm9, 0x00
000074fc119d64b9  movaps xmm7, xmm11
000074fc119d64bd  mulpd xmm7, xmm9
000074fc119d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000074fc119d64c7  ptest xmm6, xmm6
000074fc119d64cc  jnz 0x000074FC119DA845
000074fc119d64d2  movaps xmm11, xmm10
000074fc119d64d6  addpd xmm11, xmm14
000074fc119d64db  vcmppd xmm9, xmm11, xmm11, 0x03
000074fc119d64e1  ptest xmm9, xmm9
000074fc119d64e7  jnz 0x000074FC119DA987
000074fc119d64ed  lea r14, [rax+0x70]
000074fc119d64f1  movups xmm14, [r13+r14*1]
000074fc119d64f7  movaps [r15+0x240], xmm14
000074fc119d64ff  movaps xmm10, xmm1
000074fc119d6503  addpd xmm10, xmm12
000074fc119d6508  vcmppd xmm9, xmm10, xmm10, 0x03
000074fc119d650e  ptest xmm9, xmm9
000074fc119d6514  jnz 0x000074FC119DAAD5
000074fc119d651a  movaps [r15+0x170], xmm10
000074fc119d6522  vmovaps xmm1, [rsp+0x20]
000074fc119d6528  vpermilpd xmm1, xmm1, 0x00
000074fc119d652e  movaps xmm12, xmm14
000074fc119d6532  mulpd xmm12, xmm1
000074fc119d6537  vcmppd xmm9, xmm12, xmm12, 0x03
000074fc119d653d  ptest xmm9, xmm9
000074fc119d6543  jnz 0x000074FC119DAC18
000074fc119d6549  vmovaps xmm1, [rsp+0x20]
000074fc119d654f  vpermilpd xmm1, xmm1, 0x00
000074fc119d6555  vmovaps xmm9, [rsp+0xB0]
000074fc119d655e  movaps xmm14, xmm9
000074fc119d6562  mulpd xmm14, xmm1
000074fc119d6567  vcmppd xmm6, xmm14, xmm14, 0x03
000074fc119d656d  ptest xmm6, xmm6
000074fc119d6572  jnz 0x000074FC119DAD5B
000074fc119d6578  movaps [r15+0x180], xmm14
000074fc119d6580  movaps xmm1, xmm13
000074fc119d6584  addpd xmm1, xmm8
000074fc119d6589  vcmppd xmm9, xmm1, xmm1, 0x03
000074fc119d658e  ptest xmm9, xmm9
000074fc119d6594  jnz 0x000074FC119DAE9E
000074fc119d659a  movaps [r15+0x210], xmm1
000074fc119d65a2  movups xmm13, [r13+rax*1]
000074fc119d65a8  lea r14, [rax+0x10]
000074fc119d65ac  movups xmm9, [r13+r14*1]
000074fc119d65b2  movaps [r15+0x230], xmm9
000074fc119d65ba  movaps xmm8, xmm15
000074fc119d65be  addpd xmm8, xmm7
000074fc119d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000074fc119d65c9  ptest xmm6, xmm6
000074fc119d65ce  jnz 0x000074FC119DAFF4
000074fc119d65d4  movaps [r15+0x130], xmm8
000074fc119d65dc  vmovaps xmm15, [rsp+0x20]
000074fc119d65e2  vpermilpd xmm15, xmm15, 0x00
000074fc119d65e8  movaps xmm7, xmm9
000074fc119d65ec  mulpd xmm7, xmm15
000074fc119d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000074fc119d65f6  ptest xmm6, xmm6
000074fc119d65fb  jnz 0x000074FC119DB137
000074fc119d6601  movaps [r15+0x220], xmm7
000074fc119d6609  vmovaps xmm15, [rsp+0x20]
000074fc119d660f  vpermilpd xmm15, xmm15, 0x00
000074fc119d6615  movaps xmm9, xmm13
000074fc119d6619  mulpd xmm9, xmm15
000074fc119d661e  vcmppd xmm6, xmm9, xmm9, 0x03
000074fc119d6624  ptest xmm6, xmm6
000074fc119d6629  jnz 0x000074FC119DB279
000074fc119d662f  movaps xmm15, xmm11
000074fc119d6633  addpd xmm15, xmm12
000074fc119d6638  vcmppd xmm13, xmm15, xmm15, 0x03
000074fc119d663e  ptest xmm13, xmm13
000074fc119d6644  jnz 0x000074FC119DB3BD
000074fc119d664a  movaps [r15+0x140], xmm15
000074fc119d6652  movaps xmm13, xmm10
000074fc119d6656  addpd xmm13, xmm14
000074fc119d665b  vcmppd xmm12, xmm13, xmm13, 0x03
000074fc119d6661  ptest xmm12, xmm12
000074fc119d6667  jnz 0x000074FC119DB501
000074fc119d666d  movaps [r15+0x150], xmm13
000074fc119d6675  movaps xmm14, xmm1
000074fc119d6679  addpd xmm14, xmm7
000074fc119d667e  vcmppd xmm12, xmm14, xmm14, 0x03
000074fc119d6684  ptest xmm12, xmm12
000074fc119d668a  jnz 0x000074FC119DB645
000074fc119d6690  movaps [r15+0x160], xmm14
000074fc119d6698  movaps xmm1, xmm8
000074fc119d669c  addpd xmm1, xmm9
000074fc119d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000074fc119d66a6  ptest xmm12, xmm12
000074fc119d66ac  jnz 0x000074FC119DB787
000074fc119d66b2  movaps [r15+0x120], xmm1
000074fc119d66ba  movups [r13+r11*1], xmm15
000074fc119d66c0  lea rax, [r11+0x10]
000074fc119d66c4  movups [r13+rax*1], xmm13
000074fc119d66ca  lea rax, [r11+0x20]
000074fc119d66ce  movups [r13+rax*1], xmm14
000074fc119d66d4  lea rax, [r11+0x30]
000074fc119d66d8  movups [r13+rax*1], xmm1
000074fc119d66de  mov eax, [r15+0x108]
000074fc119d66e5  sahf
000074fc119d66e6  jnz 0x000074FC119D6718
000074fc119d66e8  cmp dword ptr [r15+0x318], 0x00
000074fc119d66f0  jz 0x000074FC119DB900
000074fc119d66f6  nop [rax+rax*1], ax
000074fc119d66ff  nop [rax+rax*1], eax
000074fc119d6707  mov eax, 0x410444
000074fc119d670c  mov [r15+0x100], rax
000074fc119d6713  jmp 0x000074FC117FE110
000074fc119d6718  cmp dword ptr [r15+0x318], 0x00
000074fc119d6720  jz 0x000074FC119D57E0
000074fc119d6726  nop [rax+rax*1], ax
000074fc119d672f  nop [rax+rax*1], eax
000074fc119d6737  mov eax, 0x410278
000074fc119d673c  mov [r15+0x100], rax
000074fc119d6743  jmp 0x000074FC117FE110
000074fc119d6748  int3
000074fc119d6749  call 0x000074FC1180A4B0
000074fc119d674e  jmp 0x000074FC119D5828
000074fc119d6753  call 0x000074FC11809240
000074fc119d6758  jmp 0x000074FC119D5832
000074fc119d675d  call 0x000074FC1180A4B0
000074fc119d6762  jmp 0x000074FC119D588F
000074fc119d6767  call 0x000074FC11809240
000074fc119d676c  jmp 0x000074FC119D5899
000074fc119d6771  call 0x000074FC1180A4B0
000074fc119d6776  jmp 0x000074FC119D58DD
000074fc119d677b  call 0x000074FC11809240
000074fc119d6780  jmp 0x000074FC119D58E7
000074fc119d6785  call 0x000074FC118B47C0
000074fc119d678a  jmp 0x000074FC119D5926
000074fc119d678f  call 0x000074FC1180B720
000074fc119d6794  jmp 0x000074FC119D593A
000074fc119d6799  call 0x000074FC118BFC30
000074fc119d679e  jmp 0x000074FC119D5958
000074fc119d67a3  call 0x000074FC118BE9C0
000074fc119d67a8  jmp 0x000074FC119D5962
000074fc119d67ad  call 0x000074FC118BD750
000074fc119d67b2  jmp 0x000074FC119D596C
000074fc119d67b7  sub rsp, 0x08
000074fc119d67bb  push rax
000074fc119d67bc  push rcx
000074fc119d67bd  push rdx
000074fc119d67be  push rdi
000074fc119d67bf  push rsi
000074fc119d67c0  push r8
000074fc119d67c2  push r9
000074fc119d67c4  push r10
000074fc119d67c6  push r11
000074fc119d67c8  sub rsp, 0xF0
000074fc119d67cf  vmovaps [rsp], xmm0
000074fc119d67d4  vmovaps [rsp+0x10], xmm1
000074fc119d67da  vmovaps [rsp+0x20], xmm2
000074fc119d67e0  vmovaps [rsp+0x30], xmm3
000074fc119d67e6  vmovaps [rsp+0x40], xmm4
000074fc119d67ec  vmovaps [rsp+0x50], xmm5
000074fc119d67f2  vmovaps [rsp+0x60], xmm6
000074fc119d67f8  vmovaps [rsp+0x70], xmm7
000074fc119d67fe  vmovaps [rsp+0x80], xmm9
000074fc119d6807  vmovaps [rsp+0x90], xmm10
000074fc119d6810  vmovaps [rsp+0xA0], xmm11
000074fc119d6819  vmovaps [rsp+0xB0], xmm12
000074fc119d6822  vmovaps [rsp+0xC0], xmm13
000074fc119d682b  vmovaps [rsp+0xD0], xmm14
000074fc119d6834  vmovaps [rsp+0xE0], xmm15
000074fc119d683d  sub rsp, 0x30
000074fc119d6841  movaps [rsp], xmm8
000074fc119d6846  movaps [rsp+0x10], xmm12
000074fc119d684c  movaps [rsp+0x20], xmm15
000074fc119d6852  lea rdi, [rsp]
000074fc119d6856  mov esi, 0x00
000074fc119d685b  mov rax, 0x58C4C8091530
000074fc119d6865  call rax
000074fc119d6867  movaps xmm8, [rsp]
000074fc119d686c  add rsp, 0x30
000074fc119d6870  vmovaps xmm0, [rsp]
000074fc119d6875  vmovaps xmm1, [rsp+0x10]
000074fc119d687b  vmovaps xmm2, [rsp+0x20]
000074fc119d6881  vmovaps xmm3, [rsp+0x30]
000074fc119d6887  vmovaps xmm4, [rsp+0x40]
000074fc119d688d  vmovaps xmm5, [rsp+0x50]
000074fc119d6893  vmovaps xmm6, [rsp+0x60]
000074fc119d6899  vmovaps xmm7, [rsp+0x70]
000074fc119d689f  vmovaps xmm9, [rsp+0x80]
000074fc119d68a8  vmovaps xmm10, [rsp+0x90]
000074fc119d68b1  vmovaps xmm11, [rsp+0xA0]
000074fc119d68ba  vmovaps xmm12, [rsp+0xB0]
000074fc119d68c3  vmovaps xmm13, [rsp+0xC0]
000074fc119d68cc  vmovaps xmm14, [rsp+0xD0]
000074fc119d68d5  vmovaps xmm15, [rsp+0xE0]
000074fc119d68de  add rsp, 0xF0
000074fc119d68e5  pop r11
000074fc119d68e7  pop r10
000074fc119d68e9  pop r9
000074fc119d68eb  pop r8
000074fc119d68ed  pop rsi
000074fc119d68ee  pop rdi
000074fc119d68ef  pop rdx
000074fc119d68f0  pop rcx
000074fc119d68f1  pop rax
000074fc119d68f2  add rsp, 0x08
000074fc119d68f6  jmp 0x000074FC119D599A
000074fc119d68fb  sub rsp, 0x08
000074fc119d68ff  push rax
000074fc119d6900  push rcx
000074fc119d6901  push rdx
000074fc119d6902  push rdi
000074fc119d6903  push rsi
000074fc119d6904  push r8
000074fc119d6906  push r9
000074fc119d6908  push r10
000074fc119d690a  push r11
000074fc119d690c  sub rsp, 0xF0
000074fc119d6913  vmovaps [rsp], xmm0
000074fc119d6918  vmovaps [rsp+0x10], xmm1
000074fc119d691e  vmovaps [rsp+0x20], xmm2
000074fc119d6924  vmovaps [rsp+0x30], xmm3
000074fc119d692a  vmovaps [rsp+0x40], xmm4
000074fc119d6930  vmovaps [rsp+0x50], xmm5
000074fc119d6936  vmovaps [rsp+0x60], xmm6
000074fc119d693c  vmovaps [rsp+0x70], xmm8
000074fc119d6942  vmovaps [rsp+0x80], xmm9
000074fc119d694b  vmovaps [rsp+0x90], xmm10
000074fc119d6954  vmovaps [rsp+0xA0], xmm11
000074fc119d695d  vmovaps [rsp+0xB0], xmm12
000074fc119d6966  vmovaps [rsp+0xC0], xmm13
000074fc119d696f  vmovaps [rsp+0xD0], xmm14
000074fc119d6978  vmovaps [rsp+0xE0], xmm15
000074fc119d6981  sub rsp, 0x30
000074fc119d6985  movaps [rsp], xmm7
000074fc119d6989  movaps [rsp+0x10], xmm9
000074fc119d698f  movaps [rsp+0x20], xmm15
000074fc119d6995  lea rdi, [rsp]
000074fc119d6999  mov esi, 0x00
000074fc119d699e  mov rax, 0x58C4C8091530
000074fc119d69a8  call rax
000074fc119d69aa  movaps xmm7, [rsp]
000074fc119d69ae  add rsp, 0x30
000074fc119d69b2  vmovaps xmm0, [rsp]
000074fc119d69b7  vmovaps xmm1, [rsp+0x10]
000074fc119d69bd  vmovaps xmm2, [rsp+0x20]
000074fc119d69c3  vmovaps xmm3, [rsp+0x30]
000074fc119d69c9  vmovaps xmm4, [rsp+0x40]
000074fc119d69cf  vmovaps xmm5, [rsp+0x50]
000074fc119d69d5  vmovaps xmm6, [rsp+0x60]
000074fc119d69db  vmovaps xmm8, [rsp+0x70]
000074fc119d69e1  vmovaps xmm9, [rsp+0x80]
000074fc119d69ea  vmovaps xmm10, [rsp+0x90]
000074fc119d69f3  vmovaps xmm11, [rsp+0xA0]
000074fc119d69fc  vmovaps xmm12, [rsp+0xB0]
000074fc119d6a05  vmovaps xmm13, [rsp+0xC0]
000074fc119d6a0e  vmovaps xmm14, [rsp+0xD0]
000074fc119d6a17  vmovaps xmm15, [rsp+0xE0]
000074fc119d6a20  add rsp, 0xF0
000074fc119d6a27  pop r11
000074fc119d6a29  pop r10
000074fc119d6a2b  pop r9
000074fc119d6a2d  pop r8
000074fc119d6a2f  pop rsi
000074fc119d6a30  pop rdi
000074fc119d6a31  pop rdx
000074fc119d6a32  pop rcx
000074fc119d6a33  pop rax
000074fc119d6a34  add rsp, 0x08
000074fc119d6a38  jmp 0x000074FC119D59C8
000074fc119d6a3d  sub rsp, 0x08
000074fc119d6a41  push rax
000074fc119d6a42  push rcx
000074fc119d6a43  push rdx
000074fc119d6a44  push rdi
000074fc119d6a45  push rsi
000074fc119d6a46  push r8
000074fc119d6a48  push r9
000074fc119d6a4a  push r10
000074fc119d6a4c  push r11
000074fc119d6a4e  sub rsp, 0xF0
000074fc119d6a55  vmovaps [rsp], xmm0
000074fc119d6a5a  vmovaps [rsp+0x10], xmm1
000074fc119d6a60  vmovaps [rsp+0x20], xmm2
000074fc119d6a66  vmovaps [rsp+0x30], xmm3
000074fc119d6a6c  vmovaps [rsp+0x40], xmm4
000074fc119d6a72  vmovaps [rsp+0x50], xmm5
000074fc119d6a78  vmovaps [rsp+0x60], xmm6
000074fc119d6a7e  vmovaps [rsp+0x70], xmm7
000074fc119d6a84  vmovaps [rsp+0x80], xmm8
000074fc119d6a8d  vmovaps [rsp+0x90], xmm10
000074fc119d6a96  vmovaps [rsp+0xA0], xmm11
000074fc119d6a9f  vmovaps [rsp+0xB0], xmm12
000074fc119d6aa8  vmovaps [rsp+0xC0], xmm13
000074fc119d6ab1  vmovaps [rsp+0xD0], xmm14
000074fc119d6aba  vmovaps [rsp+0xE0], xmm15
000074fc119d6ac3  sub rsp, 0x30
000074fc119d6ac7  movaps [rsp], xmm9
000074fc119d6acc  movaps [rsp+0x10], xmm12
000074fc119d6ad2  movaps [rsp+0x20], xmm10
000074fc119d6ad8  lea rdi, [rsp]
000074fc119d6adc  mov esi, 0x00
000074fc119d6ae1  mov rax, 0x58C4C8091530
000074fc119d6aeb  call rax
000074fc119d6aed  movaps xmm9, [rsp]
000074fc119d6af2  add rsp, 0x30
000074fc119d6af6  vmovaps xmm0, [rsp]
000074fc119d6afb  vmovaps xmm1, [rsp+0x10]
000074fc119d6b01  vmovaps xmm2, [rsp+0x20]
000074fc119d6b07  vmovaps xmm3, [rsp+0x30]
000074fc119d6b0d  vmovaps xmm4, [rsp+0x40]
000074fc119d6b13  vmovaps xmm5, [rsp+0x50]
000074fc119d6b19  vmovaps xmm6, [rsp+0x60]
000074fc119d6b1f  vmovaps xmm7, [rsp+0x70]
000074fc119d6b25  vmovaps xmm8, [rsp+0x80]
000074fc119d6b2e  vmovaps xmm10, [rsp+0x90]
000074fc119d6b37  vmovaps xmm11, [rsp+0xA0]
000074fc119d6b40  vmovaps xmm12, [rsp+0xB0]
000074fc119d6b49  vmovaps xmm13, [rsp+0xC0]
000074fc119d6b52  vmovaps xmm14, [rsp+0xD0]
000074fc119d6b5b  vmovaps xmm15, [rsp+0xE0]
000074fc119d6b64  add rsp, 0xF0
000074fc119d6b6b  pop r11
000074fc119d6b6d  pop r10
000074fc119d6b6f  pop r9
000074fc119d6b71  pop r8
000074fc119d6b73  pop rsi
000074fc119d6b74  pop rdi
000074fc119d6b75  pop rdx
000074fc119d6b76  pop rcx
000074fc119d6b77  pop rax
000074fc119d6b78  add rsp, 0x08
000074fc119d6b7c  jmp 0x000074FC119D59EC
000074fc119d6b81  sub rsp, 0x08
000074fc119d6b85  push rax
000074fc119d6b86  push rcx
000074fc119d6b87  push rdx
000074fc119d6b88  push rdi
000074fc119d6b89  push rsi
000074fc119d6b8a  push r8
000074fc119d6b8c  push r9
000074fc119d6b8e  push r10
000074fc119d6b90  push r11
000074fc119d6b92  sub rsp, 0xF0
000074fc119d6b99  vmovaps [rsp], xmm0
000074fc119d6b9e  vmovaps [rsp+0x10], xmm1
000074fc119d6ba4  vmovaps [rsp+0x20], xmm2
000074fc119d6baa  vmovaps [rsp+0x30], xmm3
000074fc119d6bb0  vmovaps [rsp+0x40], xmm4
000074fc119d6bb6  vmovaps [rsp+0x50], xmm5
000074fc119d6bbc  vmovaps [rsp+0x60], xmm6
000074fc119d6bc2  vmovaps [rsp+0x70], xmm7
000074fc119d6bc8  vmovaps [rsp+0x80], xmm8
000074fc119d6bd1  vmovaps [rsp+0x90], xmm9
000074fc119d6bda  vmovaps [rsp+0xA0], xmm11
000074fc119d6be3  vmovaps [rsp+0xB0], xmm12
000074fc119d6bec  vmovaps [rsp+0xC0], xmm13
000074fc119d6bf5  vmovaps [rsp+0xD0], xmm14
000074fc119d6bfe  vmovaps [rsp+0xE0], xmm15
000074fc119d6c07  sub rsp, 0x30
000074fc119d6c0b  movaps [rsp], xmm10
000074fc119d6c10  movaps [rsp+0x10], xmm12
000074fc119d6c16  movaps [rsp+0x20], xmm11
000074fc119d6c1c  lea rdi, [rsp]
000074fc119d6c20  mov esi, 0x00
000074fc119d6c25  mov rax, 0x58C4C8091530
000074fc119d6c2f  call rax
000074fc119d6c31  movaps xmm10, [rsp]
000074fc119d6c36  add rsp, 0x30
000074fc119d6c3a  vmovaps xmm0, [rsp]
000074fc119d6c3f  vmovaps xmm1, [rsp+0x10]
000074fc119d6c45  vmovaps xmm2, [rsp+0x20]
000074fc119d6c4b  vmovaps xmm3, [rsp+0x30]
000074fc119d6c51  vmovaps xmm4, [rsp+0x40]
000074fc119d6c57  vmovaps xmm5, [rsp+0x50]
000074fc119d6c5d  vmovaps xmm6, [rsp+0x60]
000074fc119d6c63  vmovaps xmm7, [rsp+0x70]
000074fc119d6c69  vmovaps xmm8, [rsp+0x80]
000074fc119d6c72  vmovaps xmm9, [rsp+0x90]
000074fc119d6c7b  vmovaps xmm11, [rsp+0xA0]
000074fc119d6c84  vmovaps xmm12, [rsp+0xB0]
000074fc119d6c8d  vmovaps xmm13, [rsp+0xC0]
000074fc119d6c96  vmovaps xmm14, [rsp+0xD0]
000074fc119d6c9f  vmovaps xmm15, [rsp+0xE0]
000074fc119d6ca8  add rsp, 0xF0
000074fc119d6caf  pop r11
000074fc119d6cb1  pop r10
000074fc119d6cb3  pop r9
000074fc119d6cb5  pop r8
000074fc119d6cb7  pop rsi
000074fc119d6cb8  pop rdi
000074fc119d6cb9  pop rdx
000074fc119d6cba  pop rcx
000074fc119d6cbb  pop rax
000074fc119d6cbc  add rsp, 0x08
000074fc119d6cc0  jmp 0x000074FC119D5A06
000074fc119d6cc5  sub rsp, 0x08
000074fc119d6cc9  push rax
000074fc119d6cca  push rcx
000074fc119d6ccb  push rdx
000074fc119d6ccc  push rdi
000074fc119d6ccd  push rsi
000074fc119d6cce  push r8
000074fc119d6cd0  push r9
000074fc119d6cd2  push r10
000074fc119d6cd4  push r11
000074fc119d6cd6  sub rsp, 0xF0
000074fc119d6cdd  vmovaps [rsp], xmm0
000074fc119d6ce2  vmovaps [rsp+0x10], xmm1
000074fc119d6ce8  vmovaps [rsp+0x20], xmm2
000074fc119d6cee  vmovaps [rsp+0x30], xmm3
000074fc119d6cf4  vmovaps [rsp+0x40], xmm4
000074fc119d6cfa  vmovaps [rsp+0x50], xmm5
000074fc119d6d00  vmovaps [rsp+0x60], xmm7
000074fc119d6d06  vmovaps [rsp+0x70], xmm8
000074fc119d6d0c  vmovaps [rsp+0x80], xmm9
000074fc119d6d15  vmovaps [rsp+0x90], xmm10
000074fc119d6d1e  vmovaps [rsp+0xA0], xmm11
000074fc119d6d27  vmovaps [rsp+0xB0], xmm12
000074fc119d6d30  vmovaps [rsp+0xC0], xmm13
000074fc119d6d39  vmovaps [rsp+0xD0], xmm14
000074fc119d6d42  vmovaps [rsp+0xE0], xmm15
000074fc119d6d4b  sub rsp, 0x30
000074fc119d6d4f  movaps [rsp], xmm6
000074fc119d6d53  movaps [rsp+0x10], xmm12
000074fc119d6d59  movaps [rsp+0x20], xmm11
000074fc119d6d5f  lea rdi, [rsp]
000074fc119d6d63  mov esi, 0x00
000074fc119d6d68  mov rax, 0x58C4C8091530
000074fc119d6d72  call rax
000074fc119d6d74  movaps xmm6, [rsp]
000074fc119d6d78  add rsp, 0x30
000074fc119d6d7c  vmovaps xmm0, [rsp]
000074fc119d6d81  vmovaps xmm1, [rsp+0x10]
000074fc119d6d87  vmovaps xmm2, [rsp+0x20]
000074fc119d6d8d  vmovaps xmm3, [rsp+0x30]
000074fc119d6d93  vmovaps xmm4, [rsp+0x40]
000074fc119d6d99  vmovaps xmm5, [rsp+0x50]
000074fc119d6d9f  vmovaps xmm7, [rsp+0x60]
000074fc119d6da5  vmovaps xmm8, [rsp+0x70]
000074fc119d6dab  vmovaps xmm9, [rsp+0x80]
000074fc119d6db4  vmovaps xmm10, [rsp+0x90]
000074fc119d6dbd  vmovaps xmm11, [rsp+0xA0]
000074fc119d6dc6  vmovaps xmm12, [rsp+0xB0]
000074fc119d6dcf  vmovaps xmm13, [rsp+0xC0]
000074fc119d6dd8  vmovaps xmm14, [rsp+0xD0]
000074fc119d6de1  vmovaps xmm15, [rsp+0xE0]
000074fc119d6dea  add rsp, 0xF0
000074fc119d6df1  pop r11
000074fc119d6df3  pop r10
000074fc119d6df5  pop r9
000074fc119d6df7  pop r8
000074fc119d6df9  pop rsi
000074fc119d6dfa  pop rdi
000074fc119d6dfb  pop rdx
000074fc119d6dfc  pop rcx
000074fc119d6dfd  pop rax
000074fc119d6dfe  add rsp, 0x08
000074fc119d6e02  jmp 0x000074FC119D5A27
000074fc119d6e07  sub rsp, 0x08
000074fc119d6e0b  push rax
000074fc119d6e0c  push rcx
000074fc119d6e0d  push rdx
000074fc119d6e0e  push rdi
000074fc119d6e0f  push rsi
000074fc119d6e10  push r8
000074fc119d6e12  push r9
000074fc119d6e14  push r10
000074fc119d6e16  push r11
000074fc119d6e18  sub rsp, 0xF0
000074fc119d6e1f  vmovaps [rsp], xmm0
000074fc119d6e24  vmovaps [rsp+0x10], xmm1
000074fc119d6e2a  vmovaps [rsp+0x20], xmm2
000074fc119d6e30  vmovaps [rsp+0x30], xmm4
000074fc119d6e36  vmovaps [rsp+0x40], xmm5
000074fc119d6e3c  vmovaps [rsp+0x50], xmm6
000074fc119d6e42  vmovaps [rsp+0x60], xmm7
000074fc119d6e48  vmovaps [rsp+0x70], xmm8
000074fc119d6e4e  vmovaps [rsp+0x80], xmm9
000074fc119d6e57  vmovaps [rsp+0x90], xmm10
000074fc119d6e60  vmovaps [rsp+0xA0], xmm11
000074fc119d6e69  vmovaps [rsp+0xB0], xmm12
000074fc119d6e72  vmovaps [rsp+0xC0], xmm13
000074fc119d6e7b  vmovaps [rsp+0xD0], xmm14
000074fc119d6e84  vmovaps [rsp+0xE0], xmm15
000074fc119d6e8d  sub rsp, 0x30
000074fc119d6e91  movaps [rsp], xmm3
000074fc119d6e95  movaps [rsp+0x10], xmm5
000074fc119d6e9a  movaps [rsp+0x20], xmm4
000074fc119d6e9f  lea rdi, [rsp]
000074fc119d6ea3  mov esi, 0x00
000074fc119d6ea8  mov rax, 0x58C4C8091530
000074fc119d6eb2  call rax
000074fc119d6eb4  movaps xmm3, [rsp]
000074fc119d6eb8  add rsp, 0x30
000074fc119d6ebc  vmovaps xmm0, [rsp]
000074fc119d6ec1  vmovaps xmm1, [rsp+0x10]
000074fc119d6ec7  vmovaps xmm2, [rsp+0x20]
000074fc119d6ecd  vmovaps xmm4, [rsp+0x30]
000074fc119d6ed3  vmovaps xmm5, [rsp+0x40]
000074fc119d6ed9  vmovaps xmm6, [rsp+0x50]
000074fc119d6edf  vmovaps xmm7, [rsp+0x60]
000074fc119d6ee5  vmovaps xmm8, [rsp+0x70]
000074fc119d6eeb  vmovaps xmm9, [rsp+0x80]
000074fc119d6ef4  vmovaps xmm10, [rsp+0x90]
000074fc119d6efd  vmovaps xmm11, [rsp+0xA0]
000074fc119d6f06  vmovaps xmm12, [rsp+0xB0]
000074fc119d6f0f  vmovaps xmm13, [rsp+0xC0]
000074fc119d6f18  vmovaps xmm14, [rsp+0xD0]
000074fc119d6f21  vmovaps xmm15, [rsp+0xE0]
000074fc119d6f2a  add rsp, 0xF0
000074fc119d6f31  pop r11
000074fc119d6f33  pop r10
000074fc119d6f35  pop r9
000074fc119d6f37  pop r8
000074fc119d6f39  pop rsi
000074fc119d6f3a  pop rdi
000074fc119d6f3b  pop rdx
000074fc119d6f3c  pop rcx
000074fc119d6f3d  pop rax
000074fc119d6f3e  add rsp, 0x08
000074fc119d6f42  jmp 0x000074FC119D5A88
000074fc119d6f47  sub rsp, 0x08
000074fc119d6f4b  push rax
000074fc119d6f4c  push rcx
000074fc119d6f4d  push rdx
000074fc119d6f4e  push rdi
000074fc119d6f4f  push rsi
000074fc119d6f50  push r8
000074fc119d6f52  push r9
000074fc119d6f54  push r10
000074fc119d6f56  push r11
000074fc119d6f58  sub rsp, 0xF0
000074fc119d6f5f  vmovaps [rsp], xmm0
000074fc119d6f64  vmovaps [rsp+0x10], xmm1
000074fc119d6f6a  vmovaps [rsp+0x20], xmm2
000074fc119d6f70  vmovaps [rsp+0x30], xmm3
000074fc119d6f76  vmovaps [rsp+0x40], xmm4
000074fc119d6f7c  vmovaps [rsp+0x50], xmm6
000074fc119d6f82  vmovaps [rsp+0x60], xmm7
000074fc119d6f88  vmovaps [rsp+0x70], xmm8
000074fc119d6f8e  vmovaps [rsp+0x80], xmm9
000074fc119d6f97  vmovaps [rsp+0x90], xmm10
000074fc119d6fa0  vmovaps [rsp+0xA0], xmm11
000074fc119d6fa9  vmovaps [rsp+0xB0], xmm12
000074fc119d6fb2  vmovaps [rsp+0xC0], xmm13
000074fc119d6fbb  vmovaps [rsp+0xD0], xmm14
000074fc119d6fc4  vmovaps [rsp+0xE0], xmm15
000074fc119d6fcd  sub rsp, 0x30
000074fc119d6fd1  movaps [rsp], xmm5
000074fc119d6fd5  movaps [rsp+0x10], xmm8
000074fc119d6fdb  movaps [rsp+0x20], xmm15
000074fc119d6fe1  lea rdi, [rsp]
000074fc119d6fe5  mov esi, 0x00
000074fc119d6fea  mov rax, 0x58C4C8091530
000074fc119d6ff4  call rax
000074fc119d6ff6  movaps xmm5, [rsp]
000074fc119d6ffa  add rsp, 0x30
000074fc119d6ffe  vmovaps xmm0, [rsp]
000074fc119d7003  vmovaps xmm1, [rsp+0x10]
000074fc119d7009  vmovaps xmm2, [rsp+0x20]
000074fc119d700f  vmovaps xmm3, [rsp+0x30]
000074fc119d7015  vmovaps xmm4, [rsp+0x40]
000074fc119d701b  vmovaps xmm6, [rsp+0x50]
000074fc119d7021  vmovaps xmm7, [rsp+0x60]
000074fc119d7027  vmovaps xmm8, [rsp+0x70]
000074fc119d702d  vmovaps xmm9, [rsp+0x80]
000074fc119d7036  vmovaps xmm10, [rsp+0x90]
000074fc119d703f  vmovaps xmm11, [rsp+0xA0]
000074fc119d7048  vmovaps xmm12, [rsp+0xB0]
000074fc119d7051  vmovaps xmm13, [rsp+0xC0]
000074fc119d705a  vmovaps xmm14, [rsp+0xD0]
000074fc119d7063  vmovaps xmm15, [rsp+0xE0]
000074fc119d706c  add rsp, 0xF0
000074fc119d7073  pop r11
000074fc119d7075  pop r10
000074fc119d7077  pop r9
000074fc119d7079  pop r8
000074fc119d707b  pop rsi
000074fc119d707c  pop rdi
000074fc119d707d  pop rdx
000074fc119d707e  pop rcx
000074fc119d707f  pop rax
000074fc119d7080  add rsp, 0x08
000074fc119d7084  jmp 0x000074FC119D5AC0
000074fc119d7089  sub rsp, 0x08
000074fc119d708d  push rax
000074fc119d708e  push rcx
000074fc119d708f  push rdx
000074fc119d7090  push rdi
000074fc119d7091  push rsi
000074fc119d7092  push r8
000074fc119d7094  push r9
000074fc119d7096  push r10
000074fc119d7098  push r11
000074fc119d709a  sub rsp, 0xF0
000074fc119d70a1  vmovaps [rsp], xmm0
000074fc119d70a6  vmovaps [rsp+0x10], xmm1
000074fc119d70ac  vmovaps [rsp+0x20], xmm2
000074fc119d70b2  vmovaps [rsp+0x30], xmm3
000074fc119d70b8  vmovaps [rsp+0x40], xmm5
000074fc119d70be  vmovaps [rsp+0x50], xmm6
000074fc119d70c4  vmovaps [rsp+0x60], xmm7
000074fc119d70ca  vmovaps [rsp+0x70], xmm8
000074fc119d70d0  vmovaps [rsp+0x80], xmm9
000074fc119d70d9  vmovaps [rsp+0x90], xmm10
000074fc119d70e2  vmovaps [rsp+0xA0], xmm11
000074fc119d70eb  vmovaps [rsp+0xB0], xmm12
000074fc119d70f4  vmovaps [rsp+0xC0], xmm13
000074fc119d70fd  vmovaps [rsp+0xD0], xmm14
000074fc119d7106  vmovaps [rsp+0xE0], xmm15
000074fc119d710f  sub rsp, 0x30
000074fc119d7113  movaps [rsp], xmm4
000074fc119d7117  movaps [rsp+0x10], xmm9
000074fc119d711d  movaps [rsp+0x20], xmm8
000074fc119d7123  lea rdi, [rsp]
000074fc119d7127  mov esi, 0x00
000074fc119d712c  mov rax, 0x58C4C8091530
000074fc119d7136  call rax
000074fc119d7138  movaps xmm4, [rsp]
000074fc119d713c  add rsp, 0x30
000074fc119d7140  vmovaps xmm0, [rsp]
000074fc119d7145  vmovaps xmm1, [rsp+0x10]
000074fc119d714b  vmovaps xmm2, [rsp+0x20]
000074fc119d7151  vmovaps xmm3, [rsp+0x30]
000074fc119d7157  vmovaps xmm5, [rsp+0x40]
000074fc119d715d  vmovaps xmm6, [rsp+0x50]
000074fc119d7163  vmovaps xmm7, [rsp+0x60]
000074fc119d7169  vmovaps xmm8, [rsp+0x70]
000074fc119d716f  vmovaps xmm9, [rsp+0x80]
000074fc119d7178  vmovaps xmm10, [rsp+0x90]
000074fc119d7181  vmovaps xmm11, [rsp+0xA0]
000074fc119d718a  vmovaps xmm12, [rsp+0xB0]
000074fc119d7193  vmovaps xmm13, [rsp+0xC0]
000074fc119d719c  vmovaps xmm14, [rsp+0xD0]
000074fc119d71a5  vmovaps xmm15, [rsp+0xE0]
000074fc119d71ae  add rsp, 0xF0
000074fc119d71b5  pop r11
000074fc119d71b7  pop r10
000074fc119d71b9  pop r9
000074fc119d71bb  pop r8
000074fc119d71bd  pop rsi
000074fc119d71be  pop rdi
000074fc119d71bf  pop rdx
000074fc119d71c0  pop rcx
000074fc119d71c1  pop rax
000074fc119d71c2  add rsp, 0x08
000074fc119d71c6  jmp 0x000074FC119D5AE1
000074fc119d71cb  sub rsp, 0x08
000074fc119d71cf  push rax
000074fc119d71d0  push rcx
000074fc119d71d1  push rdx
000074fc119d71d2  push rdi
000074fc119d71d3  push rsi
000074fc119d71d4  push r8
000074fc119d71d6  push r9
000074fc119d71d8  push r10
000074fc119d71da  push r11
000074fc119d71dc  sub rsp, 0xF0
000074fc119d71e3  vmovaps [rsp], xmm0
000074fc119d71e8  vmovaps [rsp+0x10], xmm1
000074fc119d71ee  vmovaps [rsp+0x20], xmm2
000074fc119d71f4  vmovaps [rsp+0x30], xmm3
000074fc119d71fa  vmovaps [rsp+0x40], xmm4
000074fc119d7200  vmovaps [rsp+0x50], xmm5
000074fc119d7206  vmovaps [rsp+0x60], xmm6
000074fc119d720c  vmovaps [rsp+0x70], xmm7
000074fc119d7212  vmovaps [rsp+0x80], xmm8
000074fc119d721b  vmovaps [rsp+0x90], xmm10
000074fc119d7224  vmovaps [rsp+0xA0], xmm11
000074fc119d722d  vmovaps [rsp+0xB0], xmm12
000074fc119d7236  vmovaps [rsp+0xC0], xmm13
000074fc119d723f  vmovaps [rsp+0xD0], xmm14
000074fc119d7248  vmovaps [rsp+0xE0], xmm15
000074fc119d7251  sub rsp, 0x30
000074fc119d7255  movaps [rsp], xmm9
000074fc119d725a  movaps [rsp+0x10], xmm10
000074fc119d7260  movaps [rsp+0x20], xmm8
000074fc119d7266  lea rdi, [rsp]
000074fc119d726a  mov esi, 0x00
000074fc119d726f  mov rax, 0x58C4C8091530
000074fc119d7279  call rax
000074fc119d727b  movaps xmm9, [rsp]
000074fc119d7280  add rsp, 0x30
000074fc119d7284  vmovaps xmm0, [rsp]
000074fc119d7289  vmovaps xmm1, [rsp+0x10]
000074fc119d728f  vmovaps xmm2, [rsp+0x20]
000074fc119d7295  vmovaps xmm3, [rsp+0x30]
000074fc119d729b  vmovaps xmm4, [rsp+0x40]
000074fc119d72a1  vmovaps xmm5, [rsp+0x50]
000074fc119d72a7  vmovaps xmm6, [rsp+0x60]
000074fc119d72ad  vmovaps xmm7, [rsp+0x70]
000074fc119d72b3  vmovaps xmm8, [rsp+0x80]
000074fc119d72bc  vmovaps xmm10, [rsp+0x90]
000074fc119d72c5  vmovaps xmm11, [rsp+0xA0]
000074fc119d72ce  vmovaps xmm12, [rsp+0xB0]
000074fc119d72d7  vmovaps xmm13, [rsp+0xC0]
000074fc119d72e0  vmovaps xmm14, [rsp+0xD0]
000074fc119d72e9  vmovaps xmm15, [rsp+0xE0]
000074fc119d72f2  add rsp, 0xF0
000074fc119d72f9  pop r11
000074fc119d72fb  pop r10
000074fc119d72fd  pop r9
000074fc119d72ff  pop r8
000074fc119d7301  pop rsi
000074fc119d7302  pop rdi
000074fc119d7303  pop rdx
000074fc119d7304  pop rcx
000074fc119d7305  pop rax
000074fc119d7306  add rsp, 0x08
000074fc119d730a  jmp 0x000074FC119D5AFB
000074fc119d730f  call 0x000074FC118D64F0
000074fc119d7314  jmp 0x000074FC119D5C15
000074fc119d7319  call 0x000074FC118D64F0
000074fc119d731e  jmp 0x000074FC119D5C2B
000074fc119d7323  sub rsp, 0x08
000074fc119d7327  push rax
000074fc119d7328  push rcx
000074fc119d7329  push rdx
000074fc119d732a  push rdi
000074fc119d732b  push rsi
000074fc119d732c  push r8
000074fc119d732e  push r9
000074fc119d7330  push r10
000074fc119d7332  push r11
000074fc119d7334  sub rsp, 0xF0
000074fc119d733b  vmovaps [rsp], xmm0
000074fc119d7340  vmovaps [rsp+0x10], xmm2
000074fc119d7346  vmovaps [rsp+0x20], xmm3
000074fc119d734c  vmovaps [rsp+0x30], xmm4
000074fc119d7352  vmovaps [rsp+0x40], xmm5
000074fc119d7358  vmovaps [rsp+0x50], xmm6
000074fc119d735e  vmovaps [rsp+0x60], xmm7
000074fc119d7364  vmovaps [rsp+0x70], xmm8
000074fc119d736a  vmovaps [rsp+0x80], xmm9
000074fc119d7373  vmovaps [rsp+0x90], xmm10
000074fc119d737c  vmovaps [rsp+0xA0], xmm11
000074fc119d7385  vmovaps [rsp+0xB0], xmm12
000074fc119d738e  vmovaps [rsp+0xC0], xmm13
000074fc119d7397  vmovaps [rsp+0xD0], xmm14
000074fc119d73a0  vmovaps [rsp+0xE0], xmm15
000074fc119d73a9  sub rsp, 0x30
000074fc119d73ad  movaps [rsp], xmm1
000074fc119d73b1  movaps [rsp+0x10], xmm6
000074fc119d73b6  movaps [rsp+0x20], xmm15
000074fc119d73bc  lea rdi, [rsp]
000074fc119d73c0  mov esi, 0x00
000074fc119d73c5  mov rax, 0x58C4C8091530
000074fc119d73cf  call rax
000074fc119d73d1  movaps xmm1, [rsp]
000074fc119d73d5  add rsp, 0x30
000074fc119d73d9  vmovaps xmm0, [rsp]
000074fc119d73de  vmovaps xmm2, [rsp+0x10]
000074fc119d73e4  vmovaps xmm3, [rsp+0x20]
000074fc119d73ea  vmovaps xmm4, [rsp+0x30]
000074fc119d73f0  vmovaps xmm5, [rsp+0x40]
000074fc119d73f6  vmovaps xmm6, [rsp+0x50]
000074fc119d73fc  vmovaps xmm7, [rsp+0x60]
000074fc119d7402  vmovaps xmm8, [rsp+0x70]
000074fc119d7408  vmovaps xmm9, [rsp+0x80]
000074fc119d7411  vmovaps xmm10, [rsp+0x90]
000074fc119d741a  vmovaps xmm11, [rsp+0xA0]
000074fc119d7423  vmovaps xmm12, [rsp+0xB0]
000074fc119d742c  vmovaps xmm13, [rsp+0xC0]
000074fc119d7435  vmovaps xmm14, [rsp+0xD0]
000074fc119d743e  vmovaps xmm15, [rsp+0xE0]
000074fc119d7447  add rsp, 0xF0
000074fc119d744e  pop r11
000074fc119d7450  pop r10
000074fc119d7452  pop r9
000074fc119d7454  pop r8
000074fc119d7456  pop rsi
000074fc119d7457  pop rdi
000074fc119d7458  pop rdx
000074fc119d7459  pop rcx
000074fc119d745a  pop rax
000074fc119d745b  add rsp, 0x08
000074fc119d745f  jmp 0x000074FC119D5C68
000074fc119d7464  call 0x000074FC118E5820
000074fc119d7469  jmp 0x000074FC119D5C75
000074fc119d746e  sub rsp, 0x08
000074fc119d7472  push rax
000074fc119d7473  push rcx
000074fc119d7474  push rdx
000074fc119d7475  push rdi
000074fc119d7476  push rsi
000074fc119d7477  push r8
000074fc119d7479  push r9
000074fc119d747b  push r10
000074fc119d747d  push r11
000074fc119d747f  sub rsp, 0xF0
000074fc119d7486  vmovaps [rsp], xmm0
000074fc119d748b  vmovaps [rsp+0x10], xmm1
000074fc119d7491  vmovaps [rsp+0x20], xmm2
000074fc119d7497  vmovaps [rsp+0x30], xmm3
000074fc119d749d  vmovaps [rsp+0x40], xmm4
000074fc119d74a3  vmovaps [rsp+0x50], xmm5
000074fc119d74a9  vmovaps [rsp+0x60], xmm6
000074fc119d74af  vmovaps [rsp+0x70], xmm7
000074fc119d74b5  vmovaps [rsp+0x80], xmm8
000074fc119d74be  vmovaps [rsp+0x90], xmm9
000074fc119d74c7  vmovaps [rsp+0xA0], xmm10
000074fc119d74d0  vmovaps [rsp+0xB0], xmm11
000074fc119d74d9  vmovaps [rsp+0xC0], xmm12
000074fc119d74e2  vmovaps [rsp+0xD0], xmm13
000074fc119d74eb  vmovaps [rsp+0xE0], xmm15
000074fc119d74f4  sub rsp, 0x30
000074fc119d74f8  movaps [rsp], xmm14
000074fc119d74fd  movaps [rsp+0x10], xmm4
000074fc119d7502  movaps [rsp+0x20], xmm3
000074fc119d7507  lea rdi, [rsp]
000074fc119d750b  mov esi, 0x00
000074fc119d7510  mov rax, 0x58C4C8091530
000074fc119d751a  call rax
000074fc119d751c  movaps xmm14, [rsp]
000074fc119d7521  add rsp, 0x30
000074fc119d7525  vmovaps xmm0, [rsp]
000074fc119d752a  vmovaps xmm1, [rsp+0x10]
000074fc119d7530  vmovaps xmm2, [rsp+0x20]
000074fc119d7536  vmovaps xmm3, [rsp+0x30]
000074fc119d753c  vmovaps xmm4, [rsp+0x40]
000074fc119d7542  vmovaps xmm5, [rsp+0x50]
000074fc119d7548  vmovaps xmm6, [rsp+0x60]
000074fc119d754e  vmovaps xmm7, [rsp+0x70]
000074fc119d7554  vmovaps xmm8, [rsp+0x80]
000074fc119d755d  vmovaps xmm9, [rsp+0x90]
000074fc119d7566  vmovaps xmm10, [rsp+0xA0]
000074fc119d756f  vmovaps xmm11, [rsp+0xB0]
000074fc119d7578  vmovaps xmm12, [rsp+0xC0]
000074fc119d7581  vmovaps xmm13, [rsp+0xD0]
000074fc119d758a  vmovaps xmm15, [rsp+0xE0]
000074fc119d7593  add rsp, 0xF0
000074fc119d759a  pop r11
000074fc119d759c  pop r10
000074fc119d759e  pop r9
000074fc119d75a0  pop r8
000074fc119d75a2  pop rsi
000074fc119d75a3  pop rdi
000074fc119d75a4  pop rdx
000074fc119d75a5  pop rcx
000074fc119d75a6  pop rax
000074fc119d75a7  add rsp, 0x08
000074fc119d75ab  jmp 0x000074FC119D5C8F
000074fc119d75b0  sub rsp, 0x08
000074fc119d75b4  push rax
000074fc119d75b5  push rcx
000074fc119d75b6  push rdx
000074fc119d75b7  push rdi
000074fc119d75b8  push rsi
000074fc119d75b9  push r8
000074fc119d75bb  push r9
000074fc119d75bd  push r10
000074fc119d75bf  push r11
000074fc119d75c1  sub rsp, 0xF0
000074fc119d75c8  vmovaps [rsp], xmm0
000074fc119d75cd  vmovaps [rsp+0x10], xmm1
000074fc119d75d3  vmovaps [rsp+0x20], xmm2
000074fc119d75d9  vmovaps [rsp+0x30], xmm3
000074fc119d75df  vmovaps [rsp+0x40], xmm4
000074fc119d75e5  vmovaps [rsp+0x50], xmm5
000074fc119d75eb  vmovaps [rsp+0x60], xmm7
000074fc119d75f1  vmovaps [rsp+0x70], xmm8
000074fc119d75f7  vmovaps [rsp+0x80], xmm9
000074fc119d7600  vmovaps [rsp+0x90], xmm10
000074fc119d7609  vmovaps [rsp+0xA0], xmm11
000074fc119d7612  vmovaps [rsp+0xB0], xmm12
000074fc119d761b  vmovaps [rsp+0xC0], xmm13
000074fc119d7624  vmovaps [rsp+0xD0], xmm14
000074fc119d762d  vmovaps [rsp+0xE0], xmm15
000074fc119d7636  sub rsp, 0x30
000074fc119d763a  movaps [rsp], xmm6
000074fc119d763e  movaps [rsp+0x10], xmm9
000074fc119d7644  movaps [rsp+0x20], xmm7
000074fc119d7649  lea rdi, [rsp]
000074fc119d764d  mov esi, 0x00
000074fc119d7652  mov rax, 0x58C4C8091530
000074fc119d765c  call rax
000074fc119d765e  movaps xmm6, [rsp]
000074fc119d7662  add rsp, 0x30
000074fc119d7666  vmovaps xmm0, [rsp]
000074fc119d766b  vmovaps xmm1, [rsp+0x10]
000074fc119d7671  vmovaps xmm2, [rsp+0x20]
000074fc119d7677  vmovaps xmm3, [rsp+0x30]
000074fc119d767d  vmovaps xmm4, [rsp+0x40]
000074fc119d7683  vmovaps xmm5, [rsp+0x50]
000074fc119d7689  vmovaps xmm7, [rsp+0x60]
000074fc119d768f  vmovaps xmm8, [rsp+0x70]
000074fc119d7695  vmovaps xmm9, [rsp+0x80]
000074fc119d769e  vmovaps xmm10, [rsp+0x90]
000074fc119d76a7  vmovaps xmm11, [rsp+0xA0]
000074fc119d76b0  vmovaps xmm12, [rsp+0xB0]
000074fc119d76b9  vmovaps xmm13, [rsp+0xC0]
000074fc119d76c2  vmovaps xmm14, [rsp+0xD0]
000074fc119d76cb  vmovaps xmm15, [rsp+0xE0]
000074fc119d76d4  add rsp, 0xF0
000074fc119d76db  pop r11
000074fc119d76dd  pop r10
000074fc119d76df  pop r9
000074fc119d76e1  pop r8
000074fc119d76e3  pop rsi
000074fc119d76e4  pop rdi
000074fc119d76e5  pop rdx
000074fc119d76e6  pop rcx
000074fc119d76e7  pop rax
000074fc119d76e8  add rsp, 0x08
000074fc119d76ec  jmp 0x000074FC119D5CA7
000074fc119d76f1  sub rsp, 0x08
000074fc119d76f5  push rax
000074fc119d76f6  push rcx
000074fc119d76f7  push rdx
000074fc119d76f8  push rdi
000074fc119d76f9  push rsi
000074fc119d76fa  push r8
000074fc119d76fc  push r9
000074fc119d76fe  push r10
000074fc119d7700  push r11
000074fc119d7702  sub rsp, 0xF0
000074fc119d7709  vmovaps [rsp], xmm0
000074fc119d770e  vmovaps [rsp+0x10], xmm1
000074fc119d7714  vmovaps [rsp+0x20], xmm2
000074fc119d771a  vmovaps [rsp+0x30], xmm3
000074fc119d7720  vmovaps [rsp+0x40], xmm4
000074fc119d7726  vmovaps [rsp+0x50], xmm5
000074fc119d772c  vmovaps [rsp+0x60], xmm6
000074fc119d7732  vmovaps [rsp+0x70], xmm8
000074fc119d7738  vmovaps [rsp+0x80], xmm9
000074fc119d7741  vmovaps [rsp+0x90], xmm10
000074fc119d774a  vmovaps [rsp+0xA0], xmm11
000074fc119d7753  vmovaps [rsp+0xB0], xmm12
000074fc119d775c  vmovaps [rsp+0xC0], xmm13
000074fc119d7765  vmovaps [rsp+0xD0], xmm14
000074fc119d776e  vmovaps [rsp+0xE0], xmm15
000074fc119d7777  sub rsp, 0x30
000074fc119d777b  movaps [rsp], xmm7
000074fc119d777f  movaps [rsp+0x10], xmm4
000074fc119d7784  movaps [rsp+0x20], xmm9
000074fc119d778a  lea rdi, [rsp]
000074fc119d778e  mov esi, 0x00
000074fc119d7793  mov rax, 0x58C4C8091530
000074fc119d779d  call rax
000074fc119d779f  movaps xmm7, [rsp]
000074fc119d77a3  add rsp, 0x30
000074fc119d77a7  vmovaps xmm0, [rsp]
000074fc119d77ac  vmovaps xmm1, [rsp+0x10]
000074fc119d77b2  vmovaps xmm2, [rsp+0x20]
000074fc119d77b8  vmovaps xmm3, [rsp+0x30]
000074fc119d77be  vmovaps xmm4, [rsp+0x40]
000074fc119d77c4  vmovaps xmm5, [rsp+0x50]
000074fc119d77ca  vmovaps xmm6, [rsp+0x60]
000074fc119d77d0  vmovaps xmm8, [rsp+0x70]
000074fc119d77d6  vmovaps xmm9, [rsp+0x80]
000074fc119d77df  vmovaps xmm10, [rsp+0x90]
000074fc119d77e8  vmovaps xmm11, [rsp+0xA0]
000074fc119d77f1  vmovaps xmm12, [rsp+0xB0]
000074fc119d77fa  vmovaps xmm13, [rsp+0xC0]
000074fc119d7803  vmovaps xmm14, [rsp+0xD0]
000074fc119d780c  vmovaps xmm15, [rsp+0xE0]
000074fc119d7815  add rsp, 0xF0
000074fc119d781c  pop r11
000074fc119d781e  pop r10
000074fc119d7820  pop r9
000074fc119d7822  pop r8
000074fc119d7824  pop rsi
000074fc119d7825  pop rdi
000074fc119d7826  pop rdx
000074fc119d7827  pop rcx
000074fc119d7828  pop rax
000074fc119d7829  add rsp, 0x08
000074fc119d782d  jmp 0x000074FC119D5CD4
000074fc119d7832  sub rsp, 0x08
000074fc119d7836  push rax
000074fc119d7837  push rcx
000074fc119d7838  push rdx
000074fc119d7839  push rdi
000074fc119d783a  push rsi
000074fc119d783b  push r8
000074fc119d783d  push r9
000074fc119d783f  push r10
000074fc119d7841  push r11
000074fc119d7843  sub rsp, 0xF0
000074fc119d784a  vmovaps [rsp], xmm0
000074fc119d784f  vmovaps [rsp+0x10], xmm1
000074fc119d7855  vmovaps [rsp+0x20], xmm2
000074fc119d785b  vmovaps [rsp+0x30], xmm3
000074fc119d7861  vmovaps [rsp+0x40], xmm5
000074fc119d7867  vmovaps [rsp+0x50], xmm6
000074fc119d786d  vmovaps [rsp+0x60], xmm7
000074fc119d7873  vmovaps [rsp+0x70], xmm8
000074fc119d7879  vmovaps [rsp+0x80], xmm9
000074fc119d7882  vmovaps [rsp+0x90], xmm10
000074fc119d788b  vmovaps [rsp+0xA0], xmm11
000074fc119d7894  vmovaps [rsp+0xB0], xmm12
000074fc119d789d  vmovaps [rsp+0xC0], xmm13
000074fc119d78a6  vmovaps [rsp+0xD0], xmm14
000074fc119d78af  vmovaps [rsp+0xE0], xmm15
000074fc119d78b8  sub rsp, 0x30
000074fc119d78bc  movaps [rsp], xmm4
000074fc119d78c0  movaps [rsp+0x10], xmm15
000074fc119d78c6  movaps [rsp+0x20], xmm9
000074fc119d78cc  lea rdi, [rsp]
000074fc119d78d0  mov esi, 0x00
000074fc119d78d5  mov rax, 0x58C4C8091530
000074fc119d78df  call rax
000074fc119d78e1  movaps xmm4, [rsp]
000074fc119d78e5  add rsp, 0x30
000074fc119d78e9  vmovaps xmm0, [rsp]
000074fc119d78ee  vmovaps xmm1, [rsp+0x10]
000074fc119d78f4  vmovaps xmm2, [rsp+0x20]
000074fc119d78fa  vmovaps xmm3, [rsp+0x30]
000074fc119d7900  vmovaps xmm5, [rsp+0x40]
000074fc119d7906  vmovaps xmm6, [rsp+0x50]
000074fc119d790c  vmovaps xmm7, [rsp+0x60]
000074fc119d7912  vmovaps xmm8, [rsp+0x70]
000074fc119d7918  vmovaps xmm9, [rsp+0x80]
000074fc119d7921  vmovaps xmm10, [rsp+0x90]
000074fc119d792a  vmovaps xmm11, [rsp+0xA0]
000074fc119d7933  vmovaps xmm12, [rsp+0xB0]
000074fc119d793c  vmovaps xmm13, [rsp+0xC0]
000074fc119d7945  vmovaps xmm14, [rsp+0xD0]
000074fc119d794e  vmovaps xmm15, [rsp+0xE0]
000074fc119d7957  add rsp, 0xF0
000074fc119d795e  pop r11
000074fc119d7960  pop r10
000074fc119d7962  pop r9
000074fc119d7964  pop r8
000074fc119d7966  pop rsi
000074fc119d7967  pop rdi
000074fc119d7968  pop rdx
000074fc119d7969  pop rcx
000074fc119d796a  pop rax
000074fc119d796b  add rsp, 0x08
000074fc119d796f  jmp 0x000074FC119D5CF9
000074fc119d7974  call 0x000074FC118E5820
000074fc119d7979  jmp 0x000074FC119D5D06
000074fc119d797e  sub rsp, 0x08
000074fc119d7982  push rax
000074fc119d7983  push rcx
000074fc119d7984  push rdx
000074fc119d7985  push rdi
000074fc119d7986  push rsi
000074fc119d7987  push r8
000074fc119d7989  push r9
000074fc119d798b  push r10
000074fc119d798d  push r11
000074fc119d798f  sub rsp, 0xF0
000074fc119d7996  vmovaps [rsp], xmm0
000074fc119d799b  vmovaps [rsp+0x10], xmm1
000074fc119d79a1  vmovaps [rsp+0x20], xmm2
000074fc119d79a7  vmovaps [rsp+0x30], xmm4
000074fc119d79ad  vmovaps [rsp+0x40], xmm5
000074fc119d79b3  vmovaps [rsp+0x50], xmm6
000074fc119d79b9  vmovaps [rsp+0x60], xmm7
000074fc119d79bf  vmovaps [rsp+0x70], xmm8
000074fc119d79c5  vmovaps [rsp+0x80], xmm9
000074fc119d79ce  vmovaps [rsp+0x90], xmm10
000074fc119d79d7  vmovaps [rsp+0xA0], xmm11
000074fc119d79e0  vmovaps [rsp+0xB0], xmm12
000074fc119d79e9  vmovaps [rsp+0xC0], xmm13
000074fc119d79f2  vmovaps [rsp+0xD0], xmm14
000074fc119d79fb  vmovaps [rsp+0xE0], xmm15
000074fc119d7a04  sub rsp, 0x30
000074fc119d7a08  movaps [rsp], xmm3
000074fc119d7a0c  movaps [rsp+0x10], xmm1
000074fc119d7a11  movaps [rsp+0x20], xmm9
000074fc119d7a17  lea rdi, [rsp]
000074fc119d7a1b  mov esi, 0x00
000074fc119d7a20  mov rax, 0x58C4C8091530
000074fc119d7a2a  call rax
000074fc119d7a2c  movaps xmm3, [rsp]
000074fc119d7a30  add rsp, 0x30
000074fc119d7a34  vmovaps xmm0, [rsp]
000074fc119d7a39  vmovaps xmm1, [rsp+0x10]
000074fc119d7a3f  vmovaps xmm2, [rsp+0x20]
000074fc119d7a45  vmovaps xmm4, [rsp+0x30]
000074fc119d7a4b  vmovaps xmm5, [rsp+0x40]
000074fc119d7a51  vmovaps xmm6, [rsp+0x50]
000074fc119d7a57  vmovaps xmm7, [rsp+0x60]
000074fc119d7a5d  vmovaps xmm8, [rsp+0x70]
000074fc119d7a63  vmovaps xmm9, [rsp+0x80]
000074fc119d7a6c  vmovaps xmm10, [rsp+0x90]
000074fc119d7a75  vmovaps xmm11, [rsp+0xA0]
000074fc119d7a7e  vmovaps xmm12, [rsp+0xB0]
000074fc119d7a87  vmovaps xmm13, [rsp+0xC0]
000074fc119d7a90  vmovaps xmm14, [rsp+0xD0]
000074fc119d7a99  vmovaps xmm15, [rsp+0xE0]
000074fc119d7aa2  add rsp, 0xF0
000074fc119d7aa9  pop r11
000074fc119d7aab  pop r10
000074fc119d7aad  pop r9
000074fc119d7aaf  pop r8
000074fc119d7ab1  pop rsi
000074fc119d7ab2  pop rdi
000074fc119d7ab3  pop rdx
000074fc119d7ab4  pop rcx
000074fc119d7ab5  pop rax
000074fc119d7ab6  add rsp, 0x08
000074fc119d7aba  jmp 0x000074FC119D5D43
000074fc119d7abf  sub rsp, 0x08
000074fc119d7ac3  push rax
000074fc119d7ac4  push rcx
000074fc119d7ac5  push rdx
000074fc119d7ac6  push rdi
000074fc119d7ac7  push rsi
000074fc119d7ac8  push r8
000074fc119d7aca  push r9
000074fc119d7acc  push r10
000074fc119d7ace  push r11
000074fc119d7ad0  sub rsp, 0xF0
000074fc119d7ad7  vmovaps [rsp], xmm0
000074fc119d7adc  vmovaps [rsp+0x10], xmm2
000074fc119d7ae2  vmovaps [rsp+0x20], xmm3
000074fc119d7ae8  vmovaps [rsp+0x30], xmm4
000074fc119d7aee  vmovaps [rsp+0x40], xmm5
000074fc119d7af4  vmovaps [rsp+0x50], xmm6
000074fc119d7afa  vmovaps [rsp+0x60], xmm7
000074fc119d7b00  vmovaps [rsp+0x70], xmm8
000074fc119d7b06  vmovaps [rsp+0x80], xmm9
000074fc119d7b0f  vmovaps [rsp+0x90], xmm10
000074fc119d7b18  vmovaps [rsp+0xA0], xmm11
000074fc119d7b21  vmovaps [rsp+0xB0], xmm12
000074fc119d7b2a  vmovaps [rsp+0xC0], xmm13
000074fc119d7b33  vmovaps [rsp+0xD0], xmm14
000074fc119d7b3c  vmovaps [rsp+0xE0], xmm15
000074fc119d7b45  sub rsp, 0x30
000074fc119d7b49  movaps [rsp], xmm1
000074fc119d7b4d  movaps [rsp+0x10], xmm15
000074fc119d7b53  movaps [rsp+0x20], xmm9
000074fc119d7b59  lea rdi, [rsp]
000074fc119d7b5d  mov esi, 0x00
000074fc119d7b62  mov rax, 0x58C4C8091530
000074fc119d7b6c  call rax
000074fc119d7b6e  movaps xmm1, [rsp]
000074fc119d7b72  add rsp, 0x30
000074fc119d7b76  vmovaps xmm0, [rsp]
000074fc119d7b7b  vmovaps xmm2, [rsp+0x10]
000074fc119d7b81  vmovaps xmm3, [rsp+0x20]
000074fc119d7b87  vmovaps xmm4, [rsp+0x30]
000074fc119d7b8d  vmovaps xmm5, [rsp+0x40]
000074fc119d7b93  vmovaps xmm6, [rsp+0x50]
000074fc119d7b99  vmovaps xmm7, [rsp+0x60]
000074fc119d7b9f  vmovaps xmm8, [rsp+0x70]
000074fc119d7ba5  vmovaps xmm9, [rsp+0x80]
000074fc119d7bae  vmovaps xmm10, [rsp+0x90]
000074fc119d7bb7  vmovaps xmm11, [rsp+0xA0]
000074fc119d7bc0  vmovaps xmm12, [rsp+0xB0]
000074fc119d7bc9  vmovaps xmm13, [rsp+0xC0]
000074fc119d7bd2  vmovaps xmm14, [rsp+0xD0]
000074fc119d7bdb  vmovaps xmm15, [rsp+0xE0]
000074fc119d7be4  add rsp, 0xF0
000074fc119d7beb  pop r11
000074fc119d7bed  pop r10
000074fc119d7bef  pop r9
000074fc119d7bf1  pop r8
000074fc119d7bf3  pop rsi
000074fc119d7bf4  pop rdi
000074fc119d7bf5  pop rdx
000074fc119d7bf6  pop rcx
000074fc119d7bf7  pop rax
000074fc119d7bf8  add rsp, 0x08
000074fc119d7bfc  jmp 0x000074FC119D5DCB
000074fc119d7c01  call 0x000074FC118E5820
000074fc119d7c06  jmp 0x000074FC119D5DD8
000074fc119d7c0b  sub rsp, 0x08
000074fc119d7c0f  push rax
000074fc119d7c10  push rcx
000074fc119d7c11  push rdx
000074fc119d7c12  push rdi
000074fc119d7c13  push rsi
000074fc119d7c14  push r8
000074fc119d7c16  push r9
000074fc119d7c18  push r10
000074fc119d7c1a  push r11
000074fc119d7c1c  sub rsp, 0xF0
000074fc119d7c23  vmovaps [rsp], xmm0
000074fc119d7c28  vmovaps [rsp+0x10], xmm2
000074fc119d7c2e  vmovaps [rsp+0x20], xmm3
000074fc119d7c34  vmovaps [rsp+0x30], xmm4
000074fc119d7c3a  vmovaps [rsp+0x40], xmm5
000074fc119d7c40  vmovaps [rsp+0x50], xmm6
000074fc119d7c46  vmovaps [rsp+0x60], xmm7
000074fc119d7c4c  vmovaps [rsp+0x70], xmm8
000074fc119d7c52  vmovaps [rsp+0x80], xmm9
000074fc119d7c5b  vmovaps [rsp+0x90], xmm10
000074fc119d7c64  vmovaps [rsp+0xA0], xmm11
000074fc119d7c6d  vmovaps [rsp+0xB0], xmm12
000074fc119d7c76  vmovaps [rsp+0xC0], xmm13
000074fc119d7c7f  vmovaps [rsp+0xD0], xmm14
000074fc119d7c88  vmovaps [rsp+0xE0], xmm15
000074fc119d7c91  sub rsp, 0x30
000074fc119d7c95  movaps [rsp], xmm1
000074fc119d7c99  movaps [rsp+0x10], xmm5
000074fc119d7c9e  movaps [rsp+0x20], xmm7
000074fc119d7ca3  lea rdi, [rsp]
000074fc119d7ca7  mov esi, 0x00
000074fc119d7cac  mov rax, 0x58C4C8091530
000074fc119d7cb6  call rax
000074fc119d7cb8  movaps xmm1, [rsp]
000074fc119d7cbc  add rsp, 0x30
000074fc119d7cc0  vmovaps xmm0, [rsp]
000074fc119d7cc5  vmovaps xmm2, [rsp+0x10]
000074fc119d7ccb  vmovaps xmm3, [rsp+0x20]
000074fc119d7cd1  vmovaps xmm4, [rsp+0x30]
000074fc119d7cd7  vmovaps xmm5, [rsp+0x40]
000074fc119d7cdd  vmovaps xmm6, [rsp+0x50]
000074fc119d7ce3  vmovaps xmm7, [rsp+0x60]
000074fc119d7ce9  vmovaps xmm8, [rsp+0x70]
000074fc119d7cef  vmovaps xmm9, [rsp+0x80]
000074fc119d7cf8  vmovaps xmm10, [rsp+0x90]
000074fc119d7d01  vmovaps xmm11, [rsp+0xA0]
000074fc119d7d0a  vmovaps xmm12, [rsp+0xB0]
000074fc119d7d13  vmovaps xmm13, [rsp+0xC0]
000074fc119d7d1c  vmovaps xmm14, [rsp+0xD0]
000074fc119d7d25  vmovaps xmm15, [rsp+0xE0]
000074fc119d7d2e  add rsp, 0xF0
000074fc119d7d35  pop r11
000074fc119d7d37  pop r10
000074fc119d7d39  pop r9
000074fc119d7d3b  pop r8
000074fc119d7d3d  pop rsi
000074fc119d7d3e  pop rdi
000074fc119d7d3f  pop rdx
000074fc119d7d40  pop rcx
000074fc119d7d41  pop rax
000074fc119d7d42  add rsp, 0x08
000074fc119d7d46  jmp 0x000074FC119D5E7D
000074fc119d7d4b  sub rsp, 0x08
000074fc119d7d4f  push rax
000074fc119d7d50  push rcx
000074fc119d7d51  push rdx
000074fc119d7d52  push rdi
000074fc119d7d53  push rsi
000074fc119d7d54  push r8
000074fc119d7d56  push r9
000074fc119d7d58  push r10
000074fc119d7d5a  push r11
000074fc119d7d5c  sub rsp, 0xF0
000074fc119d7d63  vmovaps [rsp], xmm0
000074fc119d7d68  vmovaps [rsp+0x10], xmm1
000074fc119d7d6e  vmovaps [rsp+0x20], xmm2
000074fc119d7d74  vmovaps [rsp+0x30], xmm3
000074fc119d7d7a  vmovaps [rsp+0x40], xmm4
000074fc119d7d80  vmovaps [rsp+0x50], xmm5
000074fc119d7d86  vmovaps [rsp+0x60], xmm6
000074fc119d7d8c  vmovaps [rsp+0x70], xmm8
000074fc119d7d92  vmovaps [rsp+0x80], xmm9
000074fc119d7d9b  vmovaps [rsp+0x90], xmm10
000074fc119d7da4  vmovaps [rsp+0xA0], xmm11
000074fc119d7dad  vmovaps [rsp+0xB0], xmm12
000074fc119d7db6  vmovaps [rsp+0xC0], xmm13
000074fc119d7dbf  vmovaps [rsp+0xD0], xmm14
000074fc119d7dc8  vmovaps [rsp+0xE0], xmm15
000074fc119d7dd1  sub rsp, 0x30
000074fc119d7dd5  movaps [rsp], xmm7
000074fc119d7dd9  movaps [rsp+0x10], xmm5
000074fc119d7dde  movaps [rsp+0x20], xmm15
000074fc119d7de4  lea rdi, [rsp]
000074fc119d7de8  mov esi, 0x00
000074fc119d7ded  mov rax, 0x58C4C8091530
000074fc119d7df7  call rax
000074fc119d7df9  movaps xmm7, [rsp]
000074fc119d7dfd  add rsp, 0x30
000074fc119d7e01  vmovaps xmm0, [rsp]
000074fc119d7e06  vmovaps xmm1, [rsp+0x10]
000074fc119d7e0c  vmovaps xmm2, [rsp+0x20]
000074fc119d7e12  vmovaps xmm3, [rsp+0x30]
000074fc119d7e18  vmovaps xmm4, [rsp+0x40]
000074fc119d7e1e  vmovaps xmm5, [rsp+0x50]
000074fc119d7e24  vmovaps xmm6, [rsp+0x60]
000074fc119d7e2a  vmovaps xmm8, [rsp+0x70]
000074fc119d7e30  vmovaps xmm9, [rsp+0x80]
000074fc119d7e39  vmovaps xmm10, [rsp+0x90]
000074fc119d7e42  vmovaps xmm11, [rsp+0xA0]
000074fc119d7e4b  vmovaps xmm12, [rsp+0xB0]
000074fc119d7e54  vmovaps xmm13, [rsp+0xC0]
000074fc119d7e5d  vmovaps xmm14, [rsp+0xD0]
000074fc119d7e66  vmovaps xmm15, [rsp+0xE0]
000074fc119d7e6f  add rsp, 0xF0
000074fc119d7e76  pop r11
000074fc119d7e78  pop r10
000074fc119d7e7a  pop r9
000074fc119d7e7c  pop r8
000074fc119d7e7e  pop rsi
000074fc119d7e7f  pop rdi
000074fc119d7e80  pop rdx
000074fc119d7e81  pop rcx
000074fc119d7e82  pop rax
000074fc119d7e83  add rsp, 0x08
000074fc119d7e87  jmp 0x000074FC119D5EB3
000074fc119d7e8c  call 0x000074FC118D64F0
000074fc119d7e91  jmp 0x000074FC119D5EC0
000074fc119d7e96  sub rsp, 0x08
000074fc119d7e9a  push rax
000074fc119d7e9b  push rcx
000074fc119d7e9c  push rdx
000074fc119d7e9d  push rdi
000074fc119d7e9e  push rsi
000074fc119d7e9f  push r8
000074fc119d7ea1  push r9
000074fc119d7ea3  push r10
000074fc119d7ea5  push r11
000074fc119d7ea7  sub rsp, 0xF0
000074fc119d7eae  vmovaps [rsp], xmm0
000074fc119d7eb3  vmovaps [rsp+0x10], xmm1
000074fc119d7eb9  vmovaps [rsp+0x20], xmm2
000074fc119d7ebf  vmovaps [rsp+0x30], xmm3
000074fc119d7ec5  vmovaps [rsp+0x40], xmm4
000074fc119d7ecb  vmovaps [rsp+0x50], xmm5
000074fc119d7ed1  vmovaps [rsp+0x60], xmm6
000074fc119d7ed7  vmovaps [rsp+0x70], xmm7
000074fc119d7edd  vmovaps [rsp+0x80], xmm8
000074fc119d7ee6  vmovaps [rsp+0x90], xmm9
000074fc119d7eef  vmovaps [rsp+0xA0], xmm10
000074fc119d7ef8  vmovaps [rsp+0xB0], xmm11
000074fc119d7f01  vmovaps [rsp+0xC0], xmm12
000074fc119d7f0a  vmovaps [rsp+0xD0], xmm13
000074fc119d7f13  vmovaps [rsp+0xE0], xmm14
000074fc119d7f1c  sub rsp, 0x30
000074fc119d7f20  movaps [rsp], xmm15
000074fc119d7f25  movaps [rsp+0x10], xmm5
000074fc119d7f2a  movaps [rsp+0x20], xmm3
000074fc119d7f2f  lea rdi, [rsp]
000074fc119d7f33  mov esi, 0x00
000074fc119d7f38  mov rax, 0x58C4C8091530
000074fc119d7f42  call rax
000074fc119d7f44  movaps xmm15, [rsp]
000074fc119d7f49  add rsp, 0x30
000074fc119d7f4d  vmovaps xmm0, [rsp]
000074fc119d7f52  vmovaps xmm1, [rsp+0x10]
000074fc119d7f58  vmovaps xmm2, [rsp+0x20]
000074fc119d7f5e  vmovaps xmm3, [rsp+0x30]
000074fc119d7f64  vmovaps xmm4, [rsp+0x40]
000074fc119d7f6a  vmovaps xmm5, [rsp+0x50]
000074fc119d7f70  vmovaps xmm6, [rsp+0x60]
000074fc119d7f76  vmovaps xmm7, [rsp+0x70]
000074fc119d7f7c  vmovaps xmm8, [rsp+0x80]
000074fc119d7f85  vmovaps xmm9, [rsp+0x90]
000074fc119d7f8e  vmovaps xmm10, [rsp+0xA0]
000074fc119d7f97  vmovaps xmm11, [rsp+0xB0]
000074fc119d7fa0  vmovaps xmm12, [rsp+0xC0]
000074fc119d7fa9  vmovaps xmm13, [rsp+0xD0]
000074fc119d7fb2  vmovaps xmm14, [rsp+0xE0]
000074fc119d7fbb  add rsp, 0xF0
000074fc119d7fc2  pop r11
000074fc119d7fc4  pop r10
000074fc119d7fc6  pop r9
000074fc119d7fc8  pop r8
000074fc119d7fca  pop rsi
000074fc119d7fcb  pop rdi
000074fc119d7fcc  pop rdx
000074fc119d7fcd  pop rcx
000074fc119d7fce  pop rax
000074fc119d7fcf  add rsp, 0x08
000074fc119d7fd3  jmp 0x000074FC119D5EE6
000074fc119d7fd8  sub rsp, 0x08
000074fc119d7fdc  push rax
000074fc119d7fdd  push rcx
000074fc119d7fde  push rdx
000074fc119d7fdf  push rdi
000074fc119d7fe0  push rsi
000074fc119d7fe1  push r8
000074fc119d7fe3  push r9
000074fc119d7fe5  push r10
000074fc119d7fe7  push r11
000074fc119d7fe9  sub rsp, 0xF0
000074fc119d7ff0  vmovaps [rsp], xmm0
000074fc119d7ff5  vmovaps [rsp+0x10], xmm2
000074fc119d7ffb  vmovaps [rsp+0x20], xmm3
000074fc119d8001  vmovaps [rsp+0x30], xmm4
000074fc119d8007  vmovaps [rsp+0x40], xmm5
000074fc119d800d  vmovaps [rsp+0x50], xmm6
000074fc119d8013  vmovaps [rsp+0x60], xmm7
000074fc119d8019  vmovaps [rsp+0x70], xmm8
000074fc119d801f  vmovaps [rsp+0x80], xmm9
000074fc119d8028  vmovaps [rsp+0x90], xmm10
000074fc119d8031  vmovaps [rsp+0xA0], xmm11
000074fc119d803a  vmovaps [rsp+0xB0], xmm12
000074fc119d8043  vmovaps [rsp+0xC0], xmm13
000074fc119d804c  vmovaps [rsp+0xD0], xmm14
000074fc119d8055  vmovaps [rsp+0xE0], xmm15
000074fc119d805e  sub rsp, 0x30
000074fc119d8062  movaps [rsp], xmm1
000074fc119d8066  movaps [rsp+0x10], xmm5
000074fc119d806b  movaps [rsp+0x20], xmm4
000074fc119d8070  lea rdi, [rsp]
000074fc119d8074  mov esi, 0x00
000074fc119d8079  mov rax, 0x58C4C8091530
000074fc119d8083  call rax
000074fc119d8085  movaps xmm1, [rsp]
000074fc119d8089  add rsp, 0x30
000074fc119d808d  vmovaps xmm0, [rsp]
000074fc119d8092  vmovaps xmm2, [rsp+0x10]
000074fc119d8098  vmovaps xmm3, [rsp+0x20]
000074fc119d809e  vmovaps xmm4, [rsp+0x30]
000074fc119d80a4  vmovaps xmm5, [rsp+0x40]
000074fc119d80aa  vmovaps xmm6, [rsp+0x50]
000074fc119d80b0  vmovaps xmm7, [rsp+0x60]
000074fc119d80b6  vmovaps xmm8, [rsp+0x70]
000074fc119d80bc  vmovaps xmm9, [rsp+0x80]
000074fc119d80c5  vmovaps xmm10, [rsp+0x90]
000074fc119d80ce  vmovaps xmm11, [rsp+0xA0]
000074fc119d80d7  vmovaps xmm12, [rsp+0xB0]
000074fc119d80e0  vmovaps xmm13, [rsp+0xC0]
000074fc119d80e9  vmovaps xmm14, [rsp+0xD0]
000074fc119d80f2  vmovaps xmm15, [rsp+0xE0]
000074fc119d80fb  add rsp, 0xF0
000074fc119d8102  pop r11
000074fc119d8104  pop r10
000074fc119d8106  pop r9
000074fc119d8108  pop r8
000074fc119d810a  pop rsi
000074fc119d810b  pop rdi
000074fc119d810c  pop rdx
000074fc119d810d  pop rcx
000074fc119d810e  pop rax
000074fc119d810f  add rsp, 0x08
000074fc119d8113  jmp 0x000074FC119D5F06
000074fc119d8118  sub rsp, 0x08
000074fc119d811c  push rax
000074fc119d811d  push rcx
000074fc119d811e  push rdx
000074fc119d811f  push rdi
000074fc119d8120  push rsi
000074fc119d8121  push r8
000074fc119d8123  push r9
000074fc119d8125  push r10
000074fc119d8127  push r11
000074fc119d8129  sub rsp, 0xF0
000074fc119d8130  vmovaps [rsp], xmm0
000074fc119d8135  vmovaps [rsp+0x10], xmm1
000074fc119d813b  vmovaps [rsp+0x20], xmm2
000074fc119d8141  vmovaps [rsp+0x30], xmm3
000074fc119d8147  vmovaps [rsp+0x40], xmm5
000074fc119d814d  vmovaps [rsp+0x50], xmm6
000074fc119d8153  vmovaps [rsp+0x60], xmm7
000074fc119d8159  vmovaps [rsp+0x70], xmm8
000074fc119d815f  vmovaps [rsp+0x80], xmm9
000074fc119d8168  vmovaps [rsp+0x90], xmm10
000074fc119d8171  vmovaps [rsp+0xA0], xmm11
000074fc119d817a  vmovaps [rsp+0xB0], xmm12
000074fc119d8183  vmovaps [rsp+0xC0], xmm13
000074fc119d818c  vmovaps [rsp+0xD0], xmm14
000074fc119d8195  vmovaps [rsp+0xE0], xmm15
000074fc119d819e  sub rsp, 0x30
000074fc119d81a2  movaps [rsp], xmm4
000074fc119d81a6  movaps [rsp+0x10], xmm3
000074fc119d81ab  movaps [rsp+0x20], xmm5
000074fc119d81b0  lea rdi, [rsp]
000074fc119d81b4  mov esi, 0x00
000074fc119d81b9  mov rax, 0x58C4C8091530
000074fc119d81c3  call rax
000074fc119d81c5  movaps xmm4, [rsp]
000074fc119d81c9  add rsp, 0x30
000074fc119d81cd  vmovaps xmm0, [rsp]
000074fc119d81d2  vmovaps xmm1, [rsp+0x10]
000074fc119d81d8  vmovaps xmm2, [rsp+0x20]
000074fc119d81de  vmovaps xmm3, [rsp+0x30]
000074fc119d81e4  vmovaps xmm5, [rsp+0x40]
000074fc119d81ea  vmovaps xmm6, [rsp+0x50]
000074fc119d81f0  vmovaps xmm7, [rsp+0x60]
000074fc119d81f6  vmovaps xmm8, [rsp+0x70]
000074fc119d81fc  vmovaps xmm9, [rsp+0x80]
000074fc119d8205  vmovaps xmm10, [rsp+0x90]
000074fc119d820e  vmovaps xmm11, [rsp+0xA0]
000074fc119d8217  vmovaps xmm12, [rsp+0xB0]
000074fc119d8220  vmovaps xmm13, [rsp+0xC0]
000074fc119d8229  vmovaps xmm14, [rsp+0xD0]
000074fc119d8232  vmovaps xmm15, [rsp+0xE0]
000074fc119d823b  add rsp, 0xF0
000074fc119d8242  pop r11
000074fc119d8244  pop r10
000074fc119d8246  pop r9
000074fc119d8248  pop r8
000074fc119d824a  pop rsi
000074fc119d824b  pop rdi
000074fc119d824c  pop rdx
000074fc119d824d  pop rcx
000074fc119d824e  pop rax
000074fc119d824f  add rsp, 0x08
000074fc119d8253  jmp 0x000074FC119D5F54
000074fc119d8258  call 0x000074FC118D64F0
000074fc119d825d  jmp 0x000074FC119D5F61
000074fc119d8262  sub rsp, 0x08
000074fc119d8266  push rax
000074fc119d8267  push rcx
000074fc119d8268  push rdx
000074fc119d8269  push rdi
000074fc119d826a  push rsi
000074fc119d826b  push r8
000074fc119d826d  push r9
000074fc119d826f  push r10
000074fc119d8271  push r11
000074fc119d8273  sub rsp, 0xF0
000074fc119d827a  vmovaps [rsp], xmm0
000074fc119d827f  vmovaps [rsp+0x10], xmm1
000074fc119d8285  vmovaps [rsp+0x20], xmm2
000074fc119d828b  vmovaps [rsp+0x30], xmm3
000074fc119d8291  vmovaps [rsp+0x40], xmm4
000074fc119d8297  vmovaps [rsp+0x50], xmm6
000074fc119d829d  vmovaps [rsp+0x60], xmm7
000074fc119d82a3  vmovaps [rsp+0x70], xmm8
000074fc119d82a9  vmovaps [rsp+0x80], xmm9
000074fc119d82b2  vmovaps [rsp+0x90], xmm10
000074fc119d82bb  vmovaps [rsp+0xA0], xmm11
000074fc119d82c4  vmovaps [rsp+0xB0], xmm12
000074fc119d82cd  vmovaps [rsp+0xC0], xmm13
000074fc119d82d6  vmovaps [rsp+0xD0], xmm14
000074fc119d82df  vmovaps [rsp+0xE0], xmm15
000074fc119d82e8  sub rsp, 0x30
000074fc119d82ec  movaps [rsp], xmm5
000074fc119d82f0  movaps [rsp+0x10], xmm6
000074fc119d82f5  movaps [rsp+0x20], xmm3
000074fc119d82fa  lea rdi, [rsp]
000074fc119d82fe  mov esi, 0x00
000074fc119d8303  mov rax, 0x58C4C8091530
000074fc119d830d  call rax
000074fc119d830f  movaps xmm5, [rsp]
000074fc119d8313  add rsp, 0x30
000074fc119d8317  vmovaps xmm0, [rsp]
000074fc119d831c  vmovaps xmm1, [rsp+0x10]
000074fc119d8322  vmovaps xmm2, [rsp+0x20]
000074fc119d8328  vmovaps xmm3, [rsp+0x30]
000074fc119d832e  vmovaps xmm4, [rsp+0x40]
000074fc119d8334  vmovaps xmm6, [rsp+0x50]
000074fc119d833a  vmovaps xmm7, [rsp+0x60]
000074fc119d8340  vmovaps xmm8, [rsp+0x70]
000074fc119d8346  vmovaps xmm9, [rsp+0x80]
000074fc119d834f  vmovaps xmm10, [rsp+0x90]
000074fc119d8358  vmovaps xmm11, [rsp+0xA0]
000074fc119d8361  vmovaps xmm12, [rsp+0xB0]
000074fc119d836a  vmovaps xmm13, [rsp+0xC0]
000074fc119d8373  vmovaps xmm14, [rsp+0xD0]
000074fc119d837c  vmovaps xmm15, [rsp+0xE0]
000074fc119d8385  add rsp, 0xF0
000074fc119d838c  pop r11
000074fc119d838e  pop r10
000074fc119d8390  pop r9
000074fc119d8392  pop r8
000074fc119d8394  pop rsi
000074fc119d8395  pop rdi
000074fc119d8396  pop rdx
000074fc119d8397  pop rcx
000074fc119d8398  pop rax
000074fc119d8399  add rsp, 0x08
000074fc119d839d  jmp 0x000074FC119D5F87
000074fc119d83a2  sub rsp, 0x08
000074fc119d83a6  push rax
000074fc119d83a7  push rcx
000074fc119d83a8  push rdx
000074fc119d83a9  push rdi
000074fc119d83aa  push rsi
000074fc119d83ab  push r8
000074fc119d83ad  push r9
000074fc119d83af  push r10
000074fc119d83b1  push r11
000074fc119d83b3  sub rsp, 0xF0
000074fc119d83ba  vmovaps [rsp], xmm0
000074fc119d83bf  vmovaps [rsp+0x10], xmm1
000074fc119d83c5  vmovaps [rsp+0x20], xmm2
000074fc119d83cb  vmovaps [rsp+0x30], xmm3
000074fc119d83d1  vmovaps [rsp+0x40], xmm4
000074fc119d83d7  vmovaps [rsp+0x50], xmm5
000074fc119d83dd  vmovaps [rsp+0x60], xmm7
000074fc119d83e3  vmovaps [rsp+0x70], xmm8
000074fc119d83e9  vmovaps [rsp+0x80], xmm9
000074fc119d83f2  vmovaps [rsp+0x90], xmm10
000074fc119d83fb  vmovaps [rsp+0xA0], xmm11
000074fc119d8404  vmovaps [rsp+0xB0], xmm12
000074fc119d840d  vmovaps [rsp+0xC0], xmm13
000074fc119d8416  vmovaps [rsp+0xD0], xmm14
000074fc119d841f  vmovaps [rsp+0xE0], xmm15
000074fc119d8428  sub rsp, 0x30
000074fc119d842c  movaps [rsp], xmm6
000074fc119d8430  movaps [rsp+0x10], xmm9
000074fc119d8436  movaps [rsp+0x20], xmm1
000074fc119d843b  lea rdi, [rsp]
000074fc119d843f  mov esi, 0x00
000074fc119d8444  mov rax, 0x58C4C8091530
000074fc119d844e  call rax
000074fc119d8450  movaps xmm6, [rsp]
000074fc119d8454  add rsp, 0x30
000074fc119d8458  vmovaps xmm0, [rsp]
000074fc119d845d  vmovaps xmm1, [rsp+0x10]
000074fc119d8463  vmovaps xmm2, [rsp+0x20]
000074fc119d8469  vmovaps xmm3, [rsp+0x30]
000074fc119d846f  vmovaps xmm4, [rsp+0x40]
000074fc119d8475  vmovaps xmm5, [rsp+0x50]
000074fc119d847b  vmovaps xmm7, [rsp+0x60]
000074fc119d8481  vmovaps xmm8, [rsp+0x70]
000074fc119d8487  vmovaps xmm9, [rsp+0x80]
000074fc119d8490  vmovaps xmm10, [rsp+0x90]
000074fc119d8499  vmovaps xmm11, [rsp+0xA0]
000074fc119d84a2  vmovaps xmm12, [rsp+0xB0]
000074fc119d84ab  vmovaps xmm13, [rsp+0xC0]
000074fc119d84b4  vmovaps xmm14, [rsp+0xD0]
000074fc119d84bd  vmovaps xmm15, [rsp+0xE0]
000074fc119d84c6  add rsp, 0xF0
000074fc119d84cd  pop r11
000074fc119d84cf  pop r10
000074fc119d84d1  pop r9
000074fc119d84d3  pop r8
000074fc119d84d5  pop rsi
000074fc119d84d6  pop rdi
000074fc119d84d7  pop rdx
000074fc119d84d8  pop rcx
000074fc119d84d9  pop rax
000074fc119d84da  add rsp, 0x08
000074fc119d84de  jmp 0x000074FC119D5FAB
000074fc119d84e3  sub rsp, 0x08
000074fc119d84e7  push rax
000074fc119d84e8  push rcx
000074fc119d84e9  push rdx
000074fc119d84ea  push rdi
000074fc119d84eb  push rsi
000074fc119d84ec  push r8
000074fc119d84ee  push r9
000074fc119d84f0  push r10
000074fc119d84f2  push r11
000074fc119d84f4  sub rsp, 0xF0
000074fc119d84fb  vmovaps [rsp], xmm0
000074fc119d8500  vmovaps [rsp+0x10], xmm1
000074fc119d8506  vmovaps [rsp+0x20], xmm2
000074fc119d850c  vmovaps [rsp+0x30], xmm3
000074fc119d8512  vmovaps [rsp+0x40], xmm4
000074fc119d8518  vmovaps [rsp+0x50], xmm5
000074fc119d851e  vmovaps [rsp+0x60], xmm6
000074fc119d8524  vmovaps [rsp+0x70], xmm7
000074fc119d852a  vmovaps [rsp+0x80], xmm8
000074fc119d8533  vmovaps [rsp+0x90], xmm10
000074fc119d853c  vmovaps [rsp+0xA0], xmm11
000074fc119d8545  vmovaps [rsp+0xB0], xmm12
000074fc119d854e  vmovaps [rsp+0xC0], xmm13
000074fc119d8557  vmovaps [rsp+0xD0], xmm14
000074fc119d8560  vmovaps [rsp+0xE0], xmm15
000074fc119d8569  sub rsp, 0x30
000074fc119d856d  movaps [rsp], xmm9
000074fc119d8572  movaps [rsp+0x10], xmm3
000074fc119d8577  movaps [rsp+0x20], xmm1
000074fc119d857c  lea rdi, [rsp]
000074fc119d8580  mov esi, 0x00
000074fc119d8585  mov rax, 0x58C4C8091530
000074fc119d858f  call rax
000074fc119d8591  movaps xmm9, [rsp]
000074fc119d8596  add rsp, 0x30
000074fc119d859a  vmovaps xmm0, [rsp]
000074fc119d859f  vmovaps xmm1, [rsp+0x10]
000074fc119d85a5  vmovaps xmm2, [rsp+0x20]
000074fc119d85ab  vmovaps xmm3, [rsp+0x30]
000074fc119d85b1  vmovaps xmm4, [rsp+0x40]
000074fc119d85b7  vmovaps xmm5, [rsp+0x50]
000074fc119d85bd  vmovaps xmm6, [rsp+0x60]
000074fc119d85c3  vmovaps xmm7, [rsp+0x70]
000074fc119d85c9  vmovaps xmm8, [rsp+0x80]
000074fc119d85d2  vmovaps xmm10, [rsp+0x90]
000074fc119d85db  vmovaps xmm11, [rsp+0xA0]
000074fc119d85e4  vmovaps xmm12, [rsp+0xB0]
000074fc119d85ed  vmovaps xmm13, [rsp+0xC0]
000074fc119d85f6  vmovaps xmm14, [rsp+0xD0]
000074fc119d85ff  vmovaps xmm15, [rsp+0xE0]
000074fc119d8608  add rsp, 0xF0
000074fc119d860f  pop r11
000074fc119d8611  pop r10
000074fc119d8613  pop r9
000074fc119d8615  pop r8
000074fc119d8617  pop rsi
000074fc119d8618  pop rdi
000074fc119d8619  pop rdx
000074fc119d861a  pop rcx
000074fc119d861b  pop rax
000074fc119d861c  add rsp, 0x08
000074fc119d8620  jmp 0x000074FC119D5FF7
000074fc119d8625  call 0x000074FC118D64F0
000074fc119d862a  jmp 0x000074FC119D6004
000074fc119d862f  sub rsp, 0x08
000074fc119d8633  push rax
000074fc119d8634  push rcx
000074fc119d8635  push rdx
000074fc119d8636  push rdi
000074fc119d8637  push rsi
000074fc119d8638  push r8
000074fc119d863a  push r9
000074fc119d863c  push r10
000074fc119d863e  push r11
000074fc119d8640  sub rsp, 0xF0
000074fc119d8647  vmovaps [rsp], xmm0
000074fc119d864c  vmovaps [rsp+0x10], xmm1
000074fc119d8652  vmovaps [rsp+0x20], xmm2
000074fc119d8658  vmovaps [rsp+0x30], xmm3
000074fc119d865e  vmovaps [rsp+0x40], xmm4
000074fc119d8664  vmovaps [rsp+0x50], xmm5
000074fc119d866a  vmovaps [rsp+0x60], xmm6
000074fc119d8670  vmovaps [rsp+0x70], xmm7
000074fc119d8676  vmovaps [rsp+0x80], xmm8
000074fc119d867f  vmovaps [rsp+0x90], xmm9
000074fc119d8688  vmovaps [rsp+0xA0], xmm10
000074fc119d8691  vmovaps [rsp+0xB0], xmm11
000074fc119d869a  vmovaps [rsp+0xC0], xmm12
000074fc119d86a3  vmovaps [rsp+0xD0], xmm13
000074fc119d86ac  vmovaps [rsp+0xE0], xmm14
000074fc119d86b5  sub rsp, 0x30
000074fc119d86b9  movaps [rsp], xmm15
000074fc119d86be  movaps [rsp+0x10], xmm3
000074fc119d86c3  movaps [rsp+0x20], xmm7
000074fc119d86c8  lea rdi, [rsp]
000074fc119d86cc  mov esi, 0x00
000074fc119d86d1  mov rax, 0x58C4C8091530
000074fc119d86db  call rax
000074fc119d86dd  movaps xmm15, [rsp]
000074fc119d86e2  add rsp, 0x30
000074fc119d86e6  vmovaps xmm0, [rsp]
000074fc119d86eb  vmovaps xmm1, [rsp+0x10]
000074fc119d86f1  vmovaps xmm2, [rsp+0x20]
000074fc119d86f7  vmovaps xmm3, [rsp+0x30]
000074fc119d86fd  vmovaps xmm4, [rsp+0x40]
000074fc119d8703  vmovaps xmm5, [rsp+0x50]
000074fc119d8709  vmovaps xmm6, [rsp+0x60]
000074fc119d870f  vmovaps xmm7, [rsp+0x70]
000074fc119d8715  vmovaps xmm8, [rsp+0x80]
000074fc119d871e  vmovaps xmm9, [rsp+0x90]
000074fc119d8727  vmovaps xmm10, [rsp+0xA0]
000074fc119d8730  vmovaps xmm11, [rsp+0xB0]
000074fc119d8739  vmovaps xmm12, [rsp+0xC0]
000074fc119d8742  vmovaps xmm13, [rsp+0xD0]
000074fc119d874b  vmovaps xmm14, [rsp+0xE0]
000074fc119d8754  add rsp, 0xF0
000074fc119d875b  pop r11
000074fc119d875d  pop r10
000074fc119d875f  pop r9
000074fc119d8761  pop r8
000074fc119d8763  pop rsi
000074fc119d8764  pop rdi
000074fc119d8765  pop rdx
000074fc119d8766  pop rcx
000074fc119d8767  pop rax
000074fc119d8768  add rsp, 0x08
000074fc119d876c  jmp 0x000074FC119D6030
000074fc119d8771  sub rsp, 0x08
000074fc119d8775  push rax
000074fc119d8776  push rcx
000074fc119d8777  push rdx
000074fc119d8778  push rdi
000074fc119d8779  push rsi
000074fc119d877a  push r8
000074fc119d877c  push r9
000074fc119d877e  push r10
000074fc119d8780  push r11
000074fc119d8782  sub rsp, 0xF0
000074fc119d8789  vmovaps [rsp], xmm0
000074fc119d878e  vmovaps [rsp+0x10], xmm1
000074fc119d8794  vmovaps [rsp+0x20], xmm2
000074fc119d879a  vmovaps [rsp+0x30], xmm4
000074fc119d87a0  vmovaps [rsp+0x40], xmm5
000074fc119d87a6  vmovaps [rsp+0x50], xmm6
000074fc119d87ac  vmovaps [rsp+0x60], xmm7
000074fc119d87b2  vmovaps [rsp+0x70], xmm8
000074fc119d87b8  vmovaps [rsp+0x80], xmm9
000074fc119d87c1  vmovaps [rsp+0x90], xmm10
000074fc119d87ca  vmovaps [rsp+0xA0], xmm11
000074fc119d87d3  vmovaps [rsp+0xB0], xmm12
000074fc119d87dc  vmovaps [rsp+0xC0], xmm13
000074fc119d87e5  vmovaps [rsp+0xD0], xmm14
000074fc119d87ee  vmovaps [rsp+0xE0], xmm15
000074fc119d87f7  sub rsp, 0x30
000074fc119d87fb  movaps [rsp], xmm3
000074fc119d87ff  movaps [rsp+0x10], xmm1
000074fc119d8804  movaps [rsp+0x20], xmm15
000074fc119d880a  lea rdi, [rsp]
000074fc119d880e  mov esi, 0x00
000074fc119d8813  mov rax, 0x58C4C8091530
000074fc119d881d  call rax
000074fc119d881f  movaps xmm3, [rsp]
000074fc119d8823  add rsp, 0x30
000074fc119d8827  vmovaps xmm0, [rsp]
000074fc119d882c  vmovaps xmm1, [rsp+0x10]
000074fc119d8832  vmovaps xmm2, [rsp+0x20]
000074fc119d8838  vmovaps xmm4, [rsp+0x30]
000074fc119d883e  vmovaps xmm5, [rsp+0x40]
000074fc119d8844  vmovaps xmm6, [rsp+0x50]
000074fc119d884a  vmovaps xmm7, [rsp+0x60]
000074fc119d8850  vmovaps xmm8, [rsp+0x70]
000074fc119d8856  vmovaps xmm9, [rsp+0x80]
000074fc119d885f  vmovaps xmm10, [rsp+0x90]
000074fc119d8868  vmovaps xmm11, [rsp+0xA0]
000074fc119d8871  vmovaps xmm12, [rsp+0xB0]
000074fc119d887a  vmovaps xmm13, [rsp+0xC0]
000074fc119d8883  vmovaps xmm14, [rsp+0xD0]
000074fc119d888c  vmovaps xmm15, [rsp+0xE0]
000074fc119d8895  add rsp, 0xF0
000074fc119d889c  pop r11
000074fc119d889e  pop r10
000074fc119d88a0  pop r9
000074fc119d88a2  pop r8
000074fc119d88a4  pop rsi
000074fc119d88a5  pop rdi
000074fc119d88a6  pop rdx
000074fc119d88a7  pop rcx
000074fc119d88a8  pop rax
000074fc119d88a9  add rsp, 0x08
000074fc119d88ad  jmp 0x000074FC119D60BF
000074fc119d88b2  call 0x000074FC118D64F0
000074fc119d88b7  jmp 0x000074FC119D60C9
000074fc119d88bc  sub rsp, 0x08
000074fc119d88c0  push rax
000074fc119d88c1  push rcx
000074fc119d88c2  push rdx
000074fc119d88c3  push rdi
000074fc119d88c4  push rsi
000074fc119d88c5  push r8
000074fc119d88c7  push r9
000074fc119d88c9  push r10
000074fc119d88cb  push r11
000074fc119d88cd  sub rsp, 0xF0
000074fc119d88d4  vmovaps [rsp], xmm0
000074fc119d88d9  vmovaps [rsp+0x10], xmm1
000074fc119d88df  vmovaps [rsp+0x20], xmm2
000074fc119d88e5  vmovaps [rsp+0x30], xmm3
000074fc119d88eb  vmovaps [rsp+0x40], xmm4
000074fc119d88f1  vmovaps [rsp+0x50], xmm5
000074fc119d88f7  vmovaps [rsp+0x60], xmm6
000074fc119d88fd  vmovaps [rsp+0x70], xmm7
000074fc119d8903  vmovaps [rsp+0x80], xmm8
000074fc119d890c  vmovaps [rsp+0x90], xmm9
000074fc119d8915  vmovaps [rsp+0xA0], xmm10
000074fc119d891e  vmovaps [rsp+0xB0], xmm11
000074fc119d8927  vmovaps [rsp+0xC0], xmm12
000074fc119d8930  vmovaps [rsp+0xD0], xmm13
000074fc119d8939  vmovaps [rsp+0xE0], xmm14
000074fc119d8942  sub rsp, 0x30
000074fc119d8946  movaps [rsp], xmm15
000074fc119d894b  movaps [rsp+0x10], xmm14
000074fc119d8951  movaps [rsp+0x20], xmm4
000074fc119d8956  lea rdi, [rsp]
000074fc119d895a  mov esi, 0x00
000074fc119d895f  mov rax, 0x58C4C8091530
000074fc119d8969  call rax
000074fc119d896b  movaps xmm15, [rsp]
000074fc119d8970  add rsp, 0x30
000074fc119d8974  vmovaps xmm0, [rsp]
000074fc119d8979  vmovaps xmm1, [rsp+0x10]
000074fc119d897f  vmovaps xmm2, [rsp+0x20]
000074fc119d8985  vmovaps xmm3, [rsp+0x30]
000074fc119d898b  vmovaps xmm4, [rsp+0x40]
000074fc119d8991  vmovaps xmm5, [rsp+0x50]
000074fc119d8997  vmovaps xmm6, [rsp+0x60]
000074fc119d899d  vmovaps xmm7, [rsp+0x70]
000074fc119d89a3  vmovaps xmm8, [rsp+0x80]
000074fc119d89ac  vmovaps xmm9, [rsp+0x90]
000074fc119d89b5  vmovaps xmm10, [rsp+0xA0]
000074fc119d89be  vmovaps xmm11, [rsp+0xB0]
000074fc119d89c7  vmovaps xmm12, [rsp+0xC0]
000074fc119d89d0  vmovaps xmm13, [rsp+0xD0]
000074fc119d89d9  vmovaps xmm14, [rsp+0xE0]
000074fc119d89e2  add rsp, 0xF0
000074fc119d89e9  pop r11
000074fc119d89eb  pop r10
000074fc119d89ed  pop r9
000074fc119d89ef  pop r8
000074fc119d89f1  pop rsi
000074fc119d89f2  pop rdi
000074fc119d89f3  pop rdx
000074fc119d89f4  pop rcx
000074fc119d89f5  pop rax
000074fc119d89f6  add rsp, 0x08
000074fc119d89fa  jmp 0x000074FC119D60F7
000074fc119d89ff  sub rsp, 0x08
000074fc119d8a03  push rax
000074fc119d8a04  push rcx
000074fc119d8a05  push rdx
000074fc119d8a06  push rdi
000074fc119d8a07  push rsi
000074fc119d8a08  push r8
000074fc119d8a0a  push r9
000074fc119d8a0c  push r10
000074fc119d8a0e  push r11
000074fc119d8a10  sub rsp, 0xF0
000074fc119d8a17  vmovaps [rsp], xmm0
000074fc119d8a1c  vmovaps [rsp+0x10], xmm1
000074fc119d8a22  vmovaps [rsp+0x20], xmm2
000074fc119d8a28  vmovaps [rsp+0x30], xmm3
000074fc119d8a2e  vmovaps [rsp+0x40], xmm4
000074fc119d8a34  vmovaps [rsp+0x50], xmm5
000074fc119d8a3a  vmovaps [rsp+0x60], xmm6
000074fc119d8a40  vmovaps [rsp+0x70], xmm7
000074fc119d8a46  vmovaps [rsp+0x80], xmm8
000074fc119d8a4f  vmovaps [rsp+0x90], xmm9
000074fc119d8a58  vmovaps [rsp+0xA0], xmm10
000074fc119d8a61  vmovaps [rsp+0xB0], xmm11
000074fc119d8a6a  vmovaps [rsp+0xC0], xmm12
000074fc119d8a73  vmovaps [rsp+0xD0], xmm13
000074fc119d8a7c  vmovaps [rsp+0xE0], xmm15
000074fc119d8a85  sub rsp, 0x30
000074fc119d8a89  movaps [rsp], xmm14
000074fc119d8a8e  movaps [rsp+0x10], xmm2
000074fc119d8a93  movaps [rsp+0x20], xmm1
000074fc119d8a98  lea rdi, [rsp]
000074fc119d8a9c  mov esi, 0x00
000074fc119d8aa1  mov rax, 0x58C4C8091530
000074fc119d8aab  call rax
000074fc119d8aad  movaps xmm14, [rsp]
000074fc119d8ab2  add rsp, 0x30
000074fc119d8ab6  vmovaps xmm0, [rsp]
000074fc119d8abb  vmovaps xmm1, [rsp+0x10]
000074fc119d8ac1  vmovaps xmm2, [rsp+0x20]
000074fc119d8ac7  vmovaps xmm3, [rsp+0x30]
000074fc119d8acd  vmovaps xmm4, [rsp+0x40]
000074fc119d8ad3  vmovaps xmm5, [rsp+0x50]
000074fc119d8ad9  vmovaps xmm6, [rsp+0x60]
000074fc119d8adf  vmovaps xmm7, [rsp+0x70]
000074fc119d8ae5  vmovaps xmm8, [rsp+0x80]
000074fc119d8aee  vmovaps xmm9, [rsp+0x90]
000074fc119d8af7  vmovaps xmm10, [rsp+0xA0]
000074fc119d8b00  vmovaps xmm11, [rsp+0xB0]
000074fc119d8b09  vmovaps xmm12, [rsp+0xC0]
000074fc119d8b12  vmovaps xmm13, [rsp+0xD0]
000074fc119d8b1b  vmovaps xmm15, [rsp+0xE0]
000074fc119d8b24  add rsp, 0xF0
000074fc119d8b2b  pop r11
000074fc119d8b2d  pop r10
000074fc119d8b2f  pop r9
000074fc119d8b31  pop r8
000074fc119d8b33  pop rsi
000074fc119d8b34  pop rdi
000074fc119d8b35  pop rdx
000074fc119d8b36  pop rcx
000074fc119d8b37  pop rax
000074fc119d8b38  add rsp, 0x08
000074fc119d8b3c  jmp 0x000074FC119D611D
000074fc119d8b41  sub rsp, 0x08
000074fc119d8b45  push rax
000074fc119d8b46  push rcx
000074fc119d8b47  push rdx
000074fc119d8b48  push rdi
000074fc119d8b49  push rsi
000074fc119d8b4a  push r8
000074fc119d8b4c  push r9
000074fc119d8b4e  push r10
000074fc119d8b50  push r11
000074fc119d8b52  sub rsp, 0xF0
000074fc119d8b59  vmovaps [rsp], xmm0
000074fc119d8b5e  vmovaps [rsp+0x10], xmm2
000074fc119d8b64  vmovaps [rsp+0x20], xmm3
000074fc119d8b6a  vmovaps [rsp+0x30], xmm4
000074fc119d8b70  vmovaps [rsp+0x40], xmm5
000074fc119d8b76  vmovaps [rsp+0x50], xmm6
000074fc119d8b7c  vmovaps [rsp+0x60], xmm7
000074fc119d8b82  vmovaps [rsp+0x70], xmm8
000074fc119d8b88  vmovaps [rsp+0x80], xmm9
000074fc119d8b91  vmovaps [rsp+0x90], xmm10
000074fc119d8b9a  vmovaps [rsp+0xA0], xmm11
000074fc119d8ba3  vmovaps [rsp+0xB0], xmm12
000074fc119d8bac  vmovaps [rsp+0xC0], xmm13
000074fc119d8bb5  vmovaps [rsp+0xD0], xmm14
000074fc119d8bbe  vmovaps [rsp+0xE0], xmm15
000074fc119d8bc7  sub rsp, 0x30
000074fc119d8bcb  movaps [rsp], xmm1
000074fc119d8bcf  movaps [rsp+0x10], xmm4
000074fc119d8bd4  movaps [rsp+0x20], xmm9
000074fc119d8bda  lea rdi, [rsp]
000074fc119d8bde  mov esi, 0x00
000074fc119d8be3  mov rax, 0x58C4C8091530
000074fc119d8bed  call rax
000074fc119d8bef  movaps xmm1, [rsp]
000074fc119d8bf3  add rsp, 0x30
000074fc119d8bf7  vmovaps xmm0, [rsp]
000074fc119d8bfc  vmovaps xmm2, [rsp+0x10]
000074fc119d8c02  vmovaps xmm3, [rsp+0x20]
000074fc119d8c08  vmovaps xmm4, [rsp+0x30]
000074fc119d8c0e  vmovaps xmm5, [rsp+0x40]
000074fc119d8c14  vmovaps xmm6, [rsp+0x50]
000074fc119d8c1a  vmovaps xmm7, [rsp+0x60]
000074fc119d8c20  vmovaps xmm8, [rsp+0x70]
000074fc119d8c26  vmovaps xmm9, [rsp+0x80]
000074fc119d8c2f  vmovaps xmm10, [rsp+0x90]
000074fc119d8c38  vmovaps xmm11, [rsp+0xA0]
000074fc119d8c41  vmovaps xmm12, [rsp+0xB0]
000074fc119d8c4a  vmovaps xmm13, [rsp+0xC0]
000074fc119d8c53  vmovaps xmm14, [rsp+0xD0]
000074fc119d8c5c  vmovaps xmm15, [rsp+0xE0]
000074fc119d8c65  add rsp, 0xF0
000074fc119d8c6c  pop r11
000074fc119d8c6e  pop r10
000074fc119d8c70  pop r9
000074fc119d8c72  pop r8
000074fc119d8c74  pop rsi
000074fc119d8c75  pop rdi
000074fc119d8c76  pop rdx
000074fc119d8c77  pop rcx
000074fc119d8c78  pop rax
000074fc119d8c79  add rsp, 0x08
000074fc119d8c7d  jmp 0x000074FC119D613B
000074fc119d8c82  sub rsp, 0x08
000074fc119d8c86  push rax
000074fc119d8c87  push rcx
000074fc119d8c88  push rdx
000074fc119d8c89  push rdi
000074fc119d8c8a  push rsi
000074fc119d8c8b  push r8
000074fc119d8c8d  push r9
000074fc119d8c8f  push r10
000074fc119d8c91  push r11
000074fc119d8c93  sub rsp, 0xF0
000074fc119d8c9a  vmovaps [rsp], xmm0
000074fc119d8c9f  vmovaps [rsp+0x10], xmm1
000074fc119d8ca5  vmovaps [rsp+0x20], xmm2
000074fc119d8cab  vmovaps [rsp+0x30], xmm3
000074fc119d8cb1  vmovaps [rsp+0x40], xmm5
000074fc119d8cb7  vmovaps [rsp+0x50], xmm6
000074fc119d8cbd  vmovaps [rsp+0x60], xmm7
000074fc119d8cc3  vmovaps [rsp+0x70], xmm8
000074fc119d8cc9  vmovaps [rsp+0x80], xmm9
000074fc119d8cd2  vmovaps [rsp+0x90], xmm10
000074fc119d8cdb  vmovaps [rsp+0xA0], xmm11
000074fc119d8ce4  vmovaps [rsp+0xB0], xmm12
000074fc119d8ced  vmovaps [rsp+0xC0], xmm13
000074fc119d8cf6  vmovaps [rsp+0xD0], xmm14
000074fc119d8cff  vmovaps [rsp+0xE0], xmm15
000074fc119d8d08  sub rsp, 0x30
000074fc119d8d0c  movaps [rsp], xmm4
000074fc119d8d10  movaps [rsp+0x10], xmm2
000074fc119d8d15  movaps [rsp+0x20], xmm9
000074fc119d8d1b  lea rdi, [rsp]
000074fc119d8d1f  mov esi, 0x00
000074fc119d8d24  mov rax, 0x58C4C8091530
000074fc119d8d2e  call rax
000074fc119d8d30  movaps xmm4, [rsp]
000074fc119d8d34  add rsp, 0x30
000074fc119d8d38  vmovaps xmm0, [rsp]
000074fc119d8d3d  vmovaps xmm1, [rsp+0x10]
000074fc119d8d43  vmovaps xmm2, [rsp+0x20]
000074fc119d8d49  vmovaps xmm3, [rsp+0x30]
000074fc119d8d4f  vmovaps xmm5, [rsp+0x40]
000074fc119d8d55  vmovaps xmm6, [rsp+0x50]
000074fc119d8d5b  vmovaps xmm7, [rsp+0x60]
000074fc119d8d61  vmovaps xmm8, [rsp+0x70]
000074fc119d8d67  vmovaps xmm9, [rsp+0x80]
000074fc119d8d70  vmovaps xmm10, [rsp+0x90]
000074fc119d8d79  vmovaps xmm11, [rsp+0xA0]
000074fc119d8d82  vmovaps xmm12, [rsp+0xB0]
000074fc119d8d8b  vmovaps xmm13, [rsp+0xC0]
000074fc119d8d94  vmovaps xmm14, [rsp+0xD0]
000074fc119d8d9d  vmovaps xmm15, [rsp+0xE0]
000074fc119d8da6  add rsp, 0xF0
000074fc119d8dad  pop r11
000074fc119d8daf  pop r10
000074fc119d8db1  pop r9
000074fc119d8db3  pop r8
000074fc119d8db5  pop rsi
000074fc119d8db6  pop rdi
000074fc119d8db7  pop rdx
000074fc119d8db8  pop rcx
000074fc119d8db9  pop rax
000074fc119d8dba  add rsp, 0x08
000074fc119d8dbe  jmp 0x000074FC119D616B
000074fc119d8dc3  sub rsp, 0x08
000074fc119d8dc7  push rax
000074fc119d8dc8  push rcx
000074fc119d8dc9  push rdx
000074fc119d8dca  push rdi
000074fc119d8dcb  push rsi
000074fc119d8dcc  push r8
000074fc119d8dce  push r9
000074fc119d8dd0  push r10
000074fc119d8dd2  push r11
000074fc119d8dd4  sub rsp, 0xF0
000074fc119d8ddb  vmovaps [rsp], xmm0
000074fc119d8de0  vmovaps [rsp+0x10], xmm1
000074fc119d8de6  vmovaps [rsp+0x20], xmm2
000074fc119d8dec  vmovaps [rsp+0x30], xmm3
000074fc119d8df2  vmovaps [rsp+0x40], xmm4
000074fc119d8df8  vmovaps [rsp+0x50], xmm5
000074fc119d8dfe  vmovaps [rsp+0x60], xmm6
000074fc119d8e04  vmovaps [rsp+0x70], xmm7
000074fc119d8e0a  vmovaps [rsp+0x80], xmm8
000074fc119d8e13  vmovaps [rsp+0x90], xmm10
000074fc119d8e1c  vmovaps [rsp+0xA0], xmm11
000074fc119d8e25  vmovaps [rsp+0xB0], xmm12
000074fc119d8e2e  vmovaps [rsp+0xC0], xmm13
000074fc119d8e37  vmovaps [rsp+0xD0], xmm14
000074fc119d8e40  vmovaps [rsp+0xE0], xmm15
000074fc119d8e49  sub rsp, 0x30
000074fc119d8e4d  movaps [rsp], xmm9
000074fc119d8e52  movaps [rsp+0x10], xmm2
000074fc119d8e57  movaps [rsp+0x20], xmm1
000074fc119d8e5c  lea rdi, [rsp]
000074fc119d8e60  mov esi, 0x00
000074fc119d8e65  mov rax, 0x58C4C8091530
000074fc119d8e6f  call rax
000074fc119d8e71  movaps xmm9, [rsp]
000074fc119d8e76  add rsp, 0x30
000074fc119d8e7a  vmovaps xmm0, [rsp]
000074fc119d8e7f  vmovaps xmm1, [rsp+0x10]
000074fc119d8e85  vmovaps xmm2, [rsp+0x20]
000074fc119d8e8b  vmovaps xmm3, [rsp+0x30]
000074fc119d8e91  vmovaps xmm4, [rsp+0x40]
000074fc119d8e97  vmovaps xmm5, [rsp+0x50]
000074fc119d8e9d  vmovaps xmm6, [rsp+0x60]
000074fc119d8ea3  vmovaps xmm7, [rsp+0x70]
000074fc119d8ea9  vmovaps xmm8, [rsp+0x80]
000074fc119d8eb2  vmovaps xmm10, [rsp+0x90]
000074fc119d8ebb  vmovaps xmm11, [rsp+0xA0]
000074fc119d8ec4  vmovaps xmm12, [rsp+0xB0]
000074fc119d8ecd  vmovaps xmm13, [rsp+0xC0]
000074fc119d8ed6  vmovaps xmm14, [rsp+0xD0]
000074fc119d8edf  vmovaps xmm15, [rsp+0xE0]
000074fc119d8ee8  add rsp, 0xF0
000074fc119d8eef  pop r11
000074fc119d8ef1  pop r10
000074fc119d8ef3  pop r9
000074fc119d8ef5  pop r8
000074fc119d8ef7  pop rsi
000074fc119d8ef8  pop rdi
000074fc119d8ef9  pop rdx
000074fc119d8efa  pop rcx
000074fc119d8efb  pop rax
000074fc119d8efc  add rsp, 0x08
000074fc119d8f00  jmp 0x000074FC119D61A1
000074fc119d8f05  sub rsp, 0x08
000074fc119d8f09  push rax
000074fc119d8f0a  push rcx
000074fc119d8f0b  push rdx
000074fc119d8f0c  push rdi
000074fc119d8f0d  push rsi
000074fc119d8f0e  push r8
000074fc119d8f10  push r9
000074fc119d8f12  push r10
000074fc119d8f14  push r11
000074fc119d8f16  sub rsp, 0xF0
000074fc119d8f1d  vmovaps [rsp], xmm0
000074fc119d8f22  vmovaps [rsp+0x10], xmm2
000074fc119d8f28  vmovaps [rsp+0x20], xmm3
000074fc119d8f2e  vmovaps [rsp+0x30], xmm4
000074fc119d8f34  vmovaps [rsp+0x40], xmm5
000074fc119d8f3a  vmovaps [rsp+0x50], xmm6
000074fc119d8f40  vmovaps [rsp+0x60], xmm7
000074fc119d8f46  vmovaps [rsp+0x70], xmm8
000074fc119d8f4c  vmovaps [rsp+0x80], xmm9
000074fc119d8f55  vmovaps [rsp+0x90], xmm10
000074fc119d8f5e  vmovaps [rsp+0xA0], xmm11
000074fc119d8f67  vmovaps [rsp+0xB0], xmm12
000074fc119d8f70  vmovaps [rsp+0xC0], xmm13
000074fc119d8f79  vmovaps [rsp+0xD0], xmm14
000074fc119d8f82  vmovaps [rsp+0xE0], xmm15
000074fc119d8f8b  sub rsp, 0x30
000074fc119d8f8f  movaps [rsp], xmm1
000074fc119d8f93  movaps [rsp+0x10], xmm15
000074fc119d8f99  movaps [rsp+0x20], xmm6
000074fc119d8f9e  lea rdi, [rsp]
000074fc119d8fa2  mov esi, 0x00
000074fc119d8fa7  mov rax, 0x58C4C8091530
000074fc119d8fb1  call rax
000074fc119d8fb3  movaps xmm1, [rsp]
000074fc119d8fb7  add rsp, 0x30
000074fc119d8fbb  vmovaps xmm0, [rsp]
000074fc119d8fc0  vmovaps xmm2, [rsp+0x10]
000074fc119d8fc6  vmovaps xmm3, [rsp+0x20]
000074fc119d8fcc  vmovaps xmm4, [rsp+0x30]
000074fc119d8fd2  vmovaps xmm5, [rsp+0x40]
000074fc119d8fd8  vmovaps xmm6, [rsp+0x50]
000074fc119d8fde  vmovaps xmm7, [rsp+0x60]
000074fc119d8fe4  vmovaps xmm8, [rsp+0x70]
000074fc119d8fea  vmovaps xmm9, [rsp+0x80]
000074fc119d8ff3  vmovaps xmm10, [rsp+0x90]
000074fc119d8ffc  vmovaps xmm11, [rsp+0xA0]
000074fc119d9005  vmovaps xmm12, [rsp+0xB0]
000074fc119d900e  vmovaps xmm13, [rsp+0xC0]
000074fc119d9017  vmovaps xmm14, [rsp+0xD0]
000074fc119d9020  vmovaps xmm15, [rsp+0xE0]
000074fc119d9029  add rsp, 0xF0
000074fc119d9030  pop r11
000074fc119d9032  pop r10
000074fc119d9034  pop r9
000074fc119d9036  pop r8
000074fc119d9038  pop rsi
000074fc119d9039  pop rdi
000074fc119d903a  pop rdx
000074fc119d903b  pop rcx
000074fc119d903c  pop rax
000074fc119d903d  add rsp, 0x08
000074fc119d9041  jmp 0x000074FC119D61C2
000074fc119d9046  sub rsp, 0x08
000074fc119d904a  push rax
000074fc119d904b  push rcx
000074fc119d904c  push rdx
000074fc119d904d  push rdi
000074fc119d904e  push rsi
000074fc119d904f  push r8
000074fc119d9051  push r9
000074fc119d9053  push r10
000074fc119d9055  push r11
000074fc119d9057  sub rsp, 0xF0
000074fc119d905e  vmovaps [rsp], xmm0
000074fc119d9063  vmovaps [rsp+0x10], xmm1
000074fc119d9069  vmovaps [rsp+0x20], xmm2
000074fc119d906f  vmovaps [rsp+0x30], xmm3
000074fc119d9075  vmovaps [rsp+0x40], xmm4
000074fc119d907b  vmovaps [rsp+0x50], xmm5
000074fc119d9081  vmovaps [rsp+0x60], xmm6
000074fc119d9087  vmovaps [rsp+0x70], xmm7
000074fc119d908d  vmovaps [rsp+0x80], xmm8
000074fc119d9096  vmovaps [rsp+0x90], xmm9
000074fc119d909f  vmovaps [rsp+0xA0], xmm10
000074fc119d90a8  vmovaps [rsp+0xB0], xmm11
000074fc119d90b1  vmovaps [rsp+0xC0], xmm12
000074fc119d90ba  vmovaps [rsp+0xD0], xmm13
000074fc119d90c3  vmovaps [rsp+0xE0], xmm14
000074fc119d90cc  sub rsp, 0x30
000074fc119d90d0  movaps [rsp], xmm15
000074fc119d90d5  movaps [rsp+0x10], xmm5
000074fc119d90da  movaps [rsp+0x20], xmm3
000074fc119d90df  lea rdi, [rsp]
000074fc119d90e3  mov esi, 0x00
000074fc119d90e8  mov rax, 0x58C4C8091530
000074fc119d90f2  call rax
000074fc119d90f4  movaps xmm15, [rsp]
000074fc119d90f9  add rsp, 0x30
000074fc119d90fd  vmovaps xmm0, [rsp]
000074fc119d9102  vmovaps xmm1, [rsp+0x10]
000074fc119d9108  vmovaps xmm2, [rsp+0x20]
000074fc119d910e  vmovaps xmm3, [rsp+0x30]
000074fc119d9114  vmovaps xmm4, [rsp+0x40]
000074fc119d911a  vmovaps xmm5, [rsp+0x50]
000074fc119d9120  vmovaps xmm6, [rsp+0x60]
000074fc119d9126  vmovaps xmm7, [rsp+0x70]
000074fc119d912c  vmovaps xmm8, [rsp+0x80]
000074fc119d9135  vmovaps xmm9, [rsp+0x90]
000074fc119d913e  vmovaps xmm10, [rsp+0xA0]
000074fc119d9147  vmovaps xmm11, [rsp+0xB0]
000074fc119d9150  vmovaps xmm12, [rsp+0xC0]
000074fc119d9159  vmovaps xmm13, [rsp+0xD0]
000074fc119d9162  vmovaps xmm14, [rsp+0xE0]
000074fc119d916b  add rsp, 0xF0
000074fc119d9172  pop r11
000074fc119d9174  pop r10
000074fc119d9176  pop r9
000074fc119d9178  pop r8
000074fc119d917a  pop rsi
000074fc119d917b  pop rdi
000074fc119d917c  pop rdx
000074fc119d917d  pop rcx
000074fc119d917e  pop rax
000074fc119d917f  add rsp, 0x08
000074fc119d9183  jmp 0x000074FC119D61DC
000074fc119d9188  sub rsp, 0x08
000074fc119d918c  push rax
000074fc119d918d  push rcx
000074fc119d918e  push rdx
000074fc119d918f  push rdi
000074fc119d9190  push rsi
000074fc119d9191  push r8
000074fc119d9193  push r9
000074fc119d9195  push r10
000074fc119d9197  push r11
000074fc119d9199  sub rsp, 0xF0
000074fc119d91a0  vmovaps [rsp], xmm0
000074fc119d91a5  vmovaps [rsp+0x10], xmm1
000074fc119d91ab  vmovaps [rsp+0x20], xmm2
000074fc119d91b1  vmovaps [rsp+0x30], xmm3
000074fc119d91b7  vmovaps [rsp+0x40], xmm4
000074fc119d91bd  vmovaps [rsp+0x50], xmm6
000074fc119d91c3  vmovaps [rsp+0x60], xmm7
000074fc119d91c9  vmovaps [rsp+0x70], xmm8
000074fc119d91cf  vmovaps [rsp+0x80], xmm9
000074fc119d91d8  vmovaps [rsp+0x90], xmm10
000074fc119d91e1  vmovaps [rsp+0xA0], xmm11
000074fc119d91ea  vmovaps [rsp+0xB0], xmm12
000074fc119d91f3  vmovaps [rsp+0xC0], xmm13
000074fc119d91fc  vmovaps [rsp+0xD0], xmm14
000074fc119d9205  vmovaps [rsp+0xE0], xmm15
000074fc119d920e  sub rsp, 0x30
000074fc119d9212  movaps [rsp], xmm5
000074fc119d9216  movaps [rsp+0x10], xmm8
000074fc119d921c  movaps [rsp+0x20], xmm6
000074fc119d9221  lea rdi, [rsp]
000074fc119d9225  mov esi, 0x00
000074fc119d922a  mov rax, 0x58C4C8091530
000074fc119d9234  call rax
000074fc119d9236  movaps xmm5, [rsp]
000074fc119d923a  add rsp, 0x30
000074fc119d923e  vmovaps xmm0, [rsp]
000074fc119d9243  vmovaps xmm1, [rsp+0x10]
000074fc119d9249  vmovaps xmm2, [rsp+0x20]
000074fc119d924f  vmovaps xmm3, [rsp+0x30]
000074fc119d9255  vmovaps xmm4, [rsp+0x40]
000074fc119d925b  vmovaps xmm6, [rsp+0x50]
000074fc119d9261  vmovaps xmm7, [rsp+0x60]
000074fc119d9267  vmovaps xmm8, [rsp+0x70]
000074fc119d926d  vmovaps xmm9, [rsp+0x80]
000074fc119d9276  vmovaps xmm10, [rsp+0x90]
000074fc119d927f  vmovaps xmm11, [rsp+0xA0]
000074fc119d9288  vmovaps xmm12, [rsp+0xB0]
000074fc119d9291  vmovaps xmm13, [rsp+0xC0]
000074fc119d929a  vmovaps xmm14, [rsp+0xD0]
000074fc119d92a3  vmovaps xmm15, [rsp+0xE0]
000074fc119d92ac  add rsp, 0xF0
000074fc119d92b3  pop r11
000074fc119d92b5  pop r10
000074fc119d92b7  pop r9
000074fc119d92b9  pop r8
000074fc119d92bb  pop rsi
000074fc119d92bc  pop rdi
000074fc119d92bd  pop rdx
000074fc119d92be  pop rcx
000074fc119d92bf  pop rax
000074fc119d92c0  add rsp, 0x08
000074fc119d92c4  jmp 0x000074FC119D6200
000074fc119d92c9  sub rsp, 0x08
000074fc119d92cd  push rax
000074fc119d92ce  push rcx
000074fc119d92cf  push rdx
000074fc119d92d0  push rdi
000074fc119d92d1  push rsi
000074fc119d92d2  push r8
000074fc119d92d4  push r9
000074fc119d92d6  push r10
000074fc119d92d8  push r11
000074fc119d92da  sub rsp, 0xF0
000074fc119d92e1  vmovaps [rsp], xmm0
000074fc119d92e6  vmovaps [rsp+0x10], xmm1
000074fc119d92ec  vmovaps [rsp+0x20], xmm2
000074fc119d92f2  vmovaps [rsp+0x30], xmm3
000074fc119d92f8  vmovaps [rsp+0x40], xmm4
000074fc119d92fe  vmovaps [rsp+0x50], xmm5
000074fc119d9304  vmovaps [rsp+0x60], xmm7
000074fc119d930a  vmovaps [rsp+0x70], xmm8
000074fc119d9310  vmovaps [rsp+0x80], xmm9
000074fc119d9319  vmovaps [rsp+0x90], xmm10
000074fc119d9322  vmovaps [rsp+0xA0], xmm11
000074fc119d932b  vmovaps [rsp+0xB0], xmm12
000074fc119d9334  vmovaps [rsp+0xC0], xmm13
000074fc119d933d  vmovaps [rsp+0xD0], xmm14
000074fc119d9346  vmovaps [rsp+0xE0], xmm15
000074fc119d934f  sub rsp, 0x30
000074fc119d9353  movaps [rsp], xmm6
000074fc119d9357  movaps [rsp+0x10], xmm10
000074fc119d935d  movaps [rsp+0x20], xmm8
000074fc119d9363  lea rdi, [rsp]
000074fc119d9367  mov esi, 0x00
000074fc119d936c  mov rax, 0x58C4C8091530
000074fc119d9376  call rax
000074fc119d9378  movaps xmm6, [rsp]
000074fc119d937c  add rsp, 0x30
000074fc119d9380  vmovaps xmm0, [rsp]
000074fc119d9385  vmovaps xmm1, [rsp+0x10]
000074fc119d938b  vmovaps xmm2, [rsp+0x20]
000074fc119d9391  vmovaps xmm3, [rsp+0x30]
000074fc119d9397  vmovaps xmm4, [rsp+0x40]
000074fc119d939d  vmovaps xmm5, [rsp+0x50]
000074fc119d93a3  vmovaps xmm7, [rsp+0x60]
000074fc119d93a9  vmovaps xmm8, [rsp+0x70]
000074fc119d93af  vmovaps xmm9, [rsp+0x80]
000074fc119d93b8  vmovaps xmm10, [rsp+0x90]
000074fc119d93c1  vmovaps xmm11, [rsp+0xA0]
000074fc119d93ca  vmovaps xmm12, [rsp+0xB0]
000074fc119d93d3  vmovaps xmm13, [rsp+0xC0]
000074fc119d93dc  vmovaps xmm14, [rsp+0xD0]
000074fc119d93e5  vmovaps xmm15, [rsp+0xE0]
000074fc119d93ee  add rsp, 0xF0
000074fc119d93f5  pop r11
000074fc119d93f7  pop r10
000074fc119d93f9  pop r9
000074fc119d93fb  pop r8
000074fc119d93fd  pop rsi
000074fc119d93fe  pop rdi
000074fc119d93ff  pop rdx
000074fc119d9400  pop rcx
000074fc119d9401  pop rax
000074fc119d9402  add rsp, 0x08
000074fc119d9406  jmp 0x000074FC119D6225
000074fc119d940b  sub rsp, 0x08
000074fc119d940f  push rax
000074fc119d9410  push rcx
000074fc119d9411  push rdx
000074fc119d9412  push rdi
000074fc119d9413  push rsi
000074fc119d9414  push r8
000074fc119d9416  push r9
000074fc119d9418  push r10
000074fc119d941a  push r11
000074fc119d941c  sub rsp, 0xF0
000074fc119d9423  vmovaps [rsp], xmm0
000074fc119d9428  vmovaps [rsp+0x10], xmm1
000074fc119d942e  vmovaps [rsp+0x20], xmm2
000074fc119d9434  vmovaps [rsp+0x30], xmm3
000074fc119d943a  vmovaps [rsp+0x40], xmm4
000074fc119d9440  vmovaps [rsp+0x50], xmm5
000074fc119d9446  vmovaps [rsp+0x60], xmm6
000074fc119d944c  vmovaps [rsp+0x70], xmm7
000074fc119d9452  vmovaps [rsp+0x80], xmm8
000074fc119d945b  vmovaps [rsp+0x90], xmm9
000074fc119d9464  vmovaps [rsp+0xA0], xmm11
000074fc119d946d  vmovaps [rsp+0xB0], xmm12
000074fc119d9476  vmovaps [rsp+0xC0], xmm13
000074fc119d947f  vmovaps [rsp+0xD0], xmm14
000074fc119d9488  vmovaps [rsp+0xE0], xmm15
000074fc119d9491  sub rsp, 0x30
000074fc119d9495  movaps [rsp], xmm10
000074fc119d949a  movaps [rsp+0x10], xmm8
000074fc119d94a0  movaps [rsp+0x20], xmm14
000074fc119d94a6  lea rdi, [rsp]
000074fc119d94aa  mov esi, 0x00
000074fc119d94af  mov rax, 0x58C4C8091530
000074fc119d94b9  call rax
000074fc119d94bb  movaps xmm10, [rsp]
000074fc119d94c0  add rsp, 0x30
000074fc119d94c4  vmovaps xmm0, [rsp]
000074fc119d94c9  vmovaps xmm1, [rsp+0x10]
000074fc119d94cf  vmovaps xmm2, [rsp+0x20]
000074fc119d94d5  vmovaps xmm3, [rsp+0x30]
000074fc119d94db  vmovaps xmm4, [rsp+0x40]
000074fc119d94e1  vmovaps xmm5, [rsp+0x50]
000074fc119d94e7  vmovaps xmm6, [rsp+0x60]
000074fc119d94ed  vmovaps xmm7, [rsp+0x70]
000074fc119d94f3  vmovaps xmm8, [rsp+0x80]
000074fc119d94fc  vmovaps xmm9, [rsp+0x90]
000074fc119d9505  vmovaps xmm11, [rsp+0xA0]
000074fc119d950e  vmovaps xmm12, [rsp+0xB0]
000074fc119d9517  vmovaps xmm13, [rsp+0xC0]
000074fc119d9520  vmovaps xmm14, [rsp+0xD0]
000074fc119d9529  vmovaps xmm15, [rsp+0xE0]
000074fc119d9532  add rsp, 0xF0
000074fc119d9539  pop r11
000074fc119d953b  pop r10
000074fc119d953d  pop r9
000074fc119d953f  pop r8
000074fc119d9541  pop rsi
000074fc119d9542  pop rdi
000074fc119d9543  pop rdx
000074fc119d9544  pop rcx
000074fc119d9545  pop rax
000074fc119d9546  add rsp, 0x08
000074fc119d954a  jmp 0x000074FC119D6245
000074fc119d954f  sub rsp, 0x08
000074fc119d9553  push rax
000074fc119d9554  push rcx
000074fc119d9555  push rdx
000074fc119d9556  push rdi
000074fc119d9557  push rsi
000074fc119d9558  push r8
000074fc119d955a  push r9
000074fc119d955c  push r10
000074fc119d955e  push r11
000074fc119d9560  sub rsp, 0xF0
000074fc119d9567  vmovaps [rsp], xmm0
000074fc119d956c  vmovaps [rsp+0x10], xmm1
000074fc119d9572  vmovaps [rsp+0x20], xmm2
000074fc119d9578  vmovaps [rsp+0x30], xmm3
000074fc119d957e  vmovaps [rsp+0x40], xmm4
000074fc119d9584  vmovaps [rsp+0x50], xmm5
000074fc119d958a  vmovaps [rsp+0x60], xmm6
000074fc119d9590  vmovaps [rsp+0x70], xmm7
000074fc119d9596  vmovaps [rsp+0x80], xmm8
000074fc119d959f  vmovaps [rsp+0x90], xmm9
000074fc119d95a8  vmovaps [rsp+0xA0], xmm10
000074fc119d95b1  vmovaps [rsp+0xB0], xmm11
000074fc119d95ba  vmovaps [rsp+0xC0], xmm12
000074fc119d95c3  vmovaps [rsp+0xD0], xmm13
000074fc119d95cc  vmovaps [rsp+0xE0], xmm15
000074fc119d95d5  sub rsp, 0x30
000074fc119d95d9  movaps [rsp], xmm14
000074fc119d95de  movaps [rsp+0x10], xmm8
000074fc119d95e4  movaps [rsp+0x20], xmm4
000074fc119d95e9  lea rdi, [rsp]
000074fc119d95ed  mov esi, 0x00
000074fc119d95f2  mov rax, 0x58C4C8091530
000074fc119d95fc  call rax
000074fc119d95fe  movaps xmm14, [rsp]
000074fc119d9603  add rsp, 0x30
000074fc119d9607  vmovaps xmm0, [rsp]
000074fc119d960c  vmovaps xmm1, [rsp+0x10]
000074fc119d9612  vmovaps xmm2, [rsp+0x20]
000074fc119d9618  vmovaps xmm3, [rsp+0x30]
000074fc119d961e  vmovaps xmm4, [rsp+0x40]
000074fc119d9624  vmovaps xmm5, [rsp+0x50]
000074fc119d962a  vmovaps xmm6, [rsp+0x60]
000074fc119d9630  vmovaps xmm7, [rsp+0x70]
000074fc119d9636  vmovaps xmm8, [rsp+0x80]
000074fc119d963f  vmovaps xmm9, [rsp+0x90]
000074fc119d9648  vmovaps xmm10, [rsp+0xA0]
000074fc119d9651  vmovaps xmm11, [rsp+0xB0]
000074fc119d965a  vmovaps xmm12, [rsp+0xC0]
000074fc119d9663  vmovaps xmm13, [rsp+0xD0]
000074fc119d966c  vmovaps xmm15, [rsp+0xE0]
000074fc119d9675  add rsp, 0xF0
000074fc119d967c  pop r11
000074fc119d967e  pop r10
000074fc119d9680  pop r9
000074fc119d9682  pop r8
000074fc119d9684  pop rsi
000074fc119d9685  pop rdi
000074fc119d9686  pop rdx
000074fc119d9687  pop rcx
000074fc119d9688  pop rax
000074fc119d9689  add rsp, 0x08
000074fc119d968d  jmp 0x000074FC119D6265
000074fc119d9692  sub rsp, 0x08
000074fc119d9696  push rax
000074fc119d9697  push rcx
000074fc119d9698  push rdx
000074fc119d9699  push rdi
000074fc119d969a  push rsi
000074fc119d969b  push r8
000074fc119d969d  push r9
000074fc119d969f  push r10
000074fc119d96a1  push r11
000074fc119d96a3  sub rsp, 0xF0
000074fc119d96aa  vmovaps [rsp], xmm0
000074fc119d96af  vmovaps [rsp+0x10], xmm1
000074fc119d96b5  vmovaps [rsp+0x20], xmm2
000074fc119d96bb  vmovaps [rsp+0x30], xmm3
000074fc119d96c1  vmovaps [rsp+0x40], xmm5
000074fc119d96c7  vmovaps [rsp+0x50], xmm6
000074fc119d96cd  vmovaps [rsp+0x60], xmm7
000074fc119d96d3  vmovaps [rsp+0x70], xmm8
000074fc119d96d9  vmovaps [rsp+0x80], xmm9
000074fc119d96e2  vmovaps [rsp+0x90], xmm10
000074fc119d96eb  vmovaps [rsp+0xA0], xmm11
000074fc119d96f4  vmovaps [rsp+0xB0], xmm12
000074fc119d96fd  vmovaps [rsp+0xC0], xmm13
000074fc119d9706  vmovaps [rsp+0xD0], xmm14
000074fc119d970f  vmovaps [rsp+0xE0], xmm15
000074fc119d9718  sub rsp, 0x30
000074fc119d971c  movaps [rsp], xmm4
000074fc119d9720  movaps [rsp+0x10], xmm13
000074fc119d9726  movaps [rsp+0x20], xmm8
000074fc119d972c  lea rdi, [rsp]
000074fc119d9730  mov esi, 0x00
000074fc119d9735  mov rax, 0x58C4C8091530
000074fc119d973f  call rax
000074fc119d9741  movaps xmm4, [rsp]
000074fc119d9745  add rsp, 0x30
000074fc119d9749  vmovaps xmm0, [rsp]
000074fc119d974e  vmovaps xmm1, [rsp+0x10]
000074fc119d9754  vmovaps xmm2, [rsp+0x20]
000074fc119d975a  vmovaps xmm3, [rsp+0x30]
000074fc119d9760  vmovaps xmm5, [rsp+0x40]
000074fc119d9766  vmovaps xmm6, [rsp+0x50]
000074fc119d976c  vmovaps xmm7, [rsp+0x60]
000074fc119d9772  vmovaps xmm8, [rsp+0x70]
000074fc119d9778  vmovaps xmm9, [rsp+0x80]
000074fc119d9781  vmovaps xmm10, [rsp+0x90]
000074fc119d978a  vmovaps xmm11, [rsp+0xA0]
000074fc119d9793  vmovaps xmm12, [rsp+0xB0]
000074fc119d979c  vmovaps xmm13, [rsp+0xC0]
000074fc119d97a5  vmovaps xmm14, [rsp+0xD0]
000074fc119d97ae  vmovaps xmm15, [rsp+0xE0]
000074fc119d97b7  add rsp, 0xF0
000074fc119d97be  pop r11
000074fc119d97c0  pop r10
000074fc119d97c2  pop r9
000074fc119d97c4  pop r8
000074fc119d97c6  pop rsi
000074fc119d97c7  pop rdi
000074fc119d97c8  pop rdx
000074fc119d97c9  pop rcx
000074fc119d97ca  pop rax
000074fc119d97cb  add rsp, 0x08
000074fc119d97cf  jmp 0x000074FC119D628A
000074fc119d97d4  sub rsp, 0x08
000074fc119d97d8  push rax
000074fc119d97d9  push rcx
000074fc119d97da  push rdx
000074fc119d97db  push rdi
000074fc119d97dc  push rsi
000074fc119d97dd  push r8
000074fc119d97df  push r9
000074fc119d97e1  push r10
000074fc119d97e3  push r11
000074fc119d97e5  sub rsp, 0xF0
000074fc119d97ec  vmovaps [rsp], xmm0
000074fc119d97f1  vmovaps [rsp+0x10], xmm1
000074fc119d97f7  vmovaps [rsp+0x20], xmm2
000074fc119d97fd  vmovaps [rsp+0x30], xmm3
000074fc119d9803  vmovaps [rsp+0x40], xmm4
000074fc119d9809  vmovaps [rsp+0x50], xmm5
000074fc119d980f  vmovaps [rsp+0x60], xmm6
000074fc119d9815  vmovaps [rsp+0x70], xmm7
000074fc119d981b  vmovaps [rsp+0x80], xmm8
000074fc119d9824  vmovaps [rsp+0x90], xmm9
000074fc119d982d  vmovaps [rsp+0xA0], xmm10
000074fc119d9836  vmovaps [rsp+0xB0], xmm11
000074fc119d983f  vmovaps [rsp+0xC0], xmm12
000074fc119d9848  vmovaps [rsp+0xD0], xmm14
000074fc119d9851  vmovaps [rsp+0xE0], xmm15
000074fc119d985a  sub rsp, 0x30
000074fc119d985e  movaps [rsp], xmm13
000074fc119d9863  movaps [rsp+0x10], xmm15
000074fc119d9869  movaps [rsp+0x20], xmm9
000074fc119d986f  lea rdi, [rsp]
000074fc119d9873  mov esi, 0x00
000074fc119d9878  mov rax, 0x58C4C8091530
000074fc119d9882  call rax
000074fc119d9884  movaps xmm13, [rsp]
000074fc119d9889  add rsp, 0x30
000074fc119d988d  vmovaps xmm0, [rsp]
000074fc119d9892  vmovaps xmm1, [rsp+0x10]
000074fc119d9898  vmovaps xmm2, [rsp+0x20]
000074fc119d989e  vmovaps xmm3, [rsp+0x30]
000074fc119d98a4  vmovaps xmm4, [rsp+0x40]
000074fc119d98aa  vmovaps xmm5, [rsp+0x50]
000074fc119d98b0  vmovaps xmm6, [rsp+0x60]
000074fc119d98b6  vmovaps xmm7, [rsp+0x70]
000074fc119d98bc  vmovaps xmm8, [rsp+0x80]
000074fc119d98c5  vmovaps xmm9, [rsp+0x90]
000074fc119d98ce  vmovaps xmm10, [rsp+0xA0]
000074fc119d98d7  vmovaps xmm11, [rsp+0xB0]
000074fc119d98e0  vmovaps xmm12, [rsp+0xC0]
000074fc119d98e9  vmovaps xmm14, [rsp+0xD0]
000074fc119d98f2  vmovaps xmm15, [rsp+0xE0]
000074fc119d98fb  add rsp, 0xF0
000074fc119d9902  pop r11
000074fc119d9904  pop r10
000074fc119d9906  pop r9
000074fc119d9908  pop r8
000074fc119d990a  pop rsi
000074fc119d990b  pop rdi
000074fc119d990c  pop rdx
000074fc119d990d  pop rcx
000074fc119d990e  pop rax
000074fc119d990f  add rsp, 0x08
000074fc119d9913  jmp 0x000074FC119D62A5
000074fc119d9918  sub rsp, 0x08
000074fc119d991c  push rax
000074fc119d991d  push rcx
000074fc119d991e  push rdx
000074fc119d991f  push rdi
000074fc119d9920  push rsi
000074fc119d9921  push r8
000074fc119d9923  push r9
000074fc119d9925  push r10
000074fc119d9927  push r11
000074fc119d9929  sub rsp, 0xF0
000074fc119d9930  vmovaps [rsp], xmm0
000074fc119d9935  vmovaps [rsp+0x10], xmm1
000074fc119d993b  vmovaps [rsp+0x20], xmm2
000074fc119d9941  vmovaps [rsp+0x30], xmm3
000074fc119d9947  vmovaps [rsp+0x40], xmm4
000074fc119d994d  vmovaps [rsp+0x50], xmm5
000074fc119d9953  vmovaps [rsp+0x60], xmm6
000074fc119d9959  vmovaps [rsp+0x70], xmm7
000074fc119d995f  vmovaps [rsp+0x80], xmm8
000074fc119d9968  vmovaps [rsp+0x90], xmm9
000074fc119d9971  vmovaps [rsp+0xA0], xmm10
000074fc119d997a  vmovaps [rsp+0xB0], xmm11
000074fc119d9983  vmovaps [rsp+0xC0], xmm12
000074fc119d998c  vmovaps [rsp+0xD0], xmm13
000074fc119d9995  vmovaps [rsp+0xE0], xmm14
000074fc119d999e  sub rsp, 0x30
000074fc119d99a2  movaps [rsp], xmm15
000074fc119d99a7  movaps [rsp+0x10], xmm1
000074fc119d99ac  movaps [rsp+0x20], xmm5
000074fc119d99b1  lea rdi, [rsp]
000074fc119d99b5  mov esi, 0x00
000074fc119d99ba  mov rax, 0x58C4C8091530
000074fc119d99c4  call rax
000074fc119d99c6  movaps xmm15, [rsp]
000074fc119d99cb  add rsp, 0x30
000074fc119d99cf  vmovaps xmm0, [rsp]
000074fc119d99d4  vmovaps xmm1, [rsp+0x10]
000074fc119d99da  vmovaps xmm2, [rsp+0x20]
000074fc119d99e0  vmovaps xmm3, [rsp+0x30]
000074fc119d99e6  vmovaps xmm4, [rsp+0x40]
000074fc119d99ec  vmovaps xmm5, [rsp+0x50]
000074fc119d99f2  vmovaps xmm6, [rsp+0x60]
000074fc119d99f8  vmovaps xmm7, [rsp+0x70]
000074fc119d99fe  vmovaps xmm8, [rsp+0x80]
000074fc119d9a07  vmovaps xmm9, [rsp+0x90]
000074fc119d9a10  vmovaps xmm10, [rsp+0xA0]
000074fc119d9a19  vmovaps xmm11, [rsp+0xB0]
000074fc119d9a22  vmovaps xmm12, [rsp+0xC0]
000074fc119d9a2b  vmovaps xmm13, [rsp+0xD0]
000074fc119d9a34  vmovaps xmm14, [rsp+0xE0]
000074fc119d9a3d  add rsp, 0xF0
000074fc119d9a44  pop r11
000074fc119d9a46  pop r10
000074fc119d9a48  pop r9
000074fc119d9a4a  pop r8
000074fc119d9a4c  pop rsi
000074fc119d9a4d  pop rdi
000074fc119d9a4e  pop rdx
000074fc119d9a4f  pop rcx
000074fc119d9a50  pop rax
000074fc119d9a51  add rsp, 0x08
000074fc119d9a55  jmp 0x000074FC119D62C0
000074fc119d9a5a  call 0x000074FC118D64F0
000074fc119d9a5f  jmp 0x000074FC119D631B
000074fc119d9a64  sub rsp, 0x08
000074fc119d9a68  push rax
000074fc119d9a69  push rcx
000074fc119d9a6a  push rdx
000074fc119d9a6b  push rdi
000074fc119d9a6c  push rsi
000074fc119d9a6d  push r8
000074fc119d9a6f  push r9
000074fc119d9a71  push r10
000074fc119d9a73  push r11
000074fc119d9a75  sub rsp, 0xF0
000074fc119d9a7c  vmovaps [rsp], xmm0
000074fc119d9a81  vmovaps [rsp+0x10], xmm1
000074fc119d9a87  vmovaps [rsp+0x20], xmm2
000074fc119d9a8d  vmovaps [rsp+0x30], xmm3
000074fc119d9a93  vmovaps [rsp+0x40], xmm4
000074fc119d9a99  vmovaps [rsp+0x50], xmm5
000074fc119d9a9f  vmovaps [rsp+0x60], xmm6
000074fc119d9aa5  vmovaps [rsp+0x70], xmm7
000074fc119d9aab  vmovaps [rsp+0x80], xmm8
000074fc119d9ab4  vmovaps [rsp+0x90], xmm10
000074fc119d9abd  vmovaps [rsp+0xA0], xmm11
000074fc119d9ac6  vmovaps [rsp+0xB0], xmm12
000074fc119d9acf  vmovaps [rsp+0xC0], xmm13
000074fc119d9ad8  vmovaps [rsp+0xD0], xmm14
000074fc119d9ae1  vmovaps [rsp+0xE0], xmm15
000074fc119d9aea  sub rsp, 0x30
000074fc119d9aee  movaps [rsp], xmm9
000074fc119d9af3  movaps [rsp+0x10], xmm8
000074fc119d9af9  movaps [rsp+0x20], xmm11
000074fc119d9aff  lea rdi, [rsp]
000074fc119d9b03  mov esi, 0x00
000074fc119d9b08  mov rax, 0x58C4C8091530
000074fc119d9b12  call rax
000074fc119d9b14  movaps xmm9, [rsp]
000074fc119d9b19  add rsp, 0x30
000074fc119d9b1d  vmovaps xmm0, [rsp]
000074fc119d9b22  vmovaps xmm1, [rsp+0x10]
000074fc119d9b28  vmovaps xmm2, [rsp+0x20]
000074fc119d9b2e  vmovaps xmm3, [rsp+0x30]
000074fc119d9b34  vmovaps xmm4, [rsp+0x40]
000074fc119d9b3a  vmovaps xmm5, [rsp+0x50]
000074fc119d9b40  vmovaps xmm6, [rsp+0x60]
000074fc119d9b46  vmovaps xmm7, [rsp+0x70]
000074fc119d9b4c  vmovaps xmm8, [rsp+0x80]
000074fc119d9b55  vmovaps xmm10, [rsp+0x90]
000074fc119d9b5e  vmovaps xmm11, [rsp+0xA0]
000074fc119d9b67  vmovaps xmm12, [rsp+0xB0]
000074fc119d9b70  vmovaps xmm13, [rsp+0xC0]
000074fc119d9b79  vmovaps xmm14, [rsp+0xD0]
000074fc119d9b82  vmovaps xmm15, [rsp+0xE0]
000074fc119d9b8b  add rsp, 0xF0
000074fc119d9b92  pop r11
000074fc119d9b94  pop r10
000074fc119d9b96  pop r9
000074fc119d9b98  pop r8
000074fc119d9b9a  pop rsi
000074fc119d9b9b  pop rdi
000074fc119d9b9c  pop rdx
000074fc119d9b9d  pop rcx
000074fc119d9b9e  pop rax
000074fc119d9b9f  add rsp, 0x08
000074fc119d9ba3  jmp 0x000074FC119D6352
000074fc119d9ba8  sub rsp, 0x08
000074fc119d9bac  push rax
000074fc119d9bad  push rcx
000074fc119d9bae  push rdx
000074fc119d9baf  push rdi
000074fc119d9bb0  push rsi
000074fc119d9bb1  push r8
000074fc119d9bb3  push r9
000074fc119d9bb5  push r10
000074fc119d9bb7  push r11
000074fc119d9bb9  sub rsp, 0xF0
000074fc119d9bc0  vmovaps [rsp], xmm0
000074fc119d9bc5  vmovaps [rsp+0x10], xmm1
000074fc119d9bcb  vmovaps [rsp+0x20], xmm2
000074fc119d9bd1  vmovaps [rsp+0x30], xmm3
000074fc119d9bd7  vmovaps [rsp+0x40], xmm4
000074fc119d9bdd  vmovaps [rsp+0x50], xmm5
000074fc119d9be3  vmovaps [rsp+0x60], xmm6
000074fc119d9be9  vmovaps [rsp+0x70], xmm7
000074fc119d9bef  vmovaps [rsp+0x80], xmm8
000074fc119d9bf8  vmovaps [rsp+0x90], xmm9
000074fc119d9c01  vmovaps [rsp+0xA0], xmm10
000074fc119d9c0a  vmovaps [rsp+0xB0], xmm12
000074fc119d9c13  vmovaps [rsp+0xC0], xmm13
000074fc119d9c1c  vmovaps [rsp+0xD0], xmm14
000074fc119d9c25  vmovaps [rsp+0xE0], xmm15
000074fc119d9c2e  sub rsp, 0x30
000074fc119d9c32  movaps [rsp], xmm11
000074fc119d9c37  movaps [rsp+0x10], xmm10
000074fc119d9c3d  movaps [rsp+0x20], xmm6
000074fc119d9c42  lea rdi, [rsp]
000074fc119d9c46  mov esi, 0x00
000074fc119d9c4b  mov rax, 0x58C4C8091530
000074fc119d9c55  call rax
000074fc119d9c57  movaps xmm11, [rsp]
000074fc119d9c5c  add rsp, 0x30
000074fc119d9c60  vmovaps xmm0, [rsp]
000074fc119d9c65  vmovaps xmm1, [rsp+0x10]
000074fc119d9c6b  vmovaps xmm2, [rsp+0x20]
000074fc119d9c71  vmovaps xmm3, [rsp+0x30]
000074fc119d9c77  vmovaps xmm4, [rsp+0x40]
000074fc119d9c7d  vmovaps xmm5, [rsp+0x50]
000074fc119d9c83  vmovaps xmm6, [rsp+0x60]
000074fc119d9c89  vmovaps xmm7, [rsp+0x70]
000074fc119d9c8f  vmovaps xmm8, [rsp+0x80]
000074fc119d9c98  vmovaps xmm9, [rsp+0x90]
000074fc119d9ca1  vmovaps xmm10, [rsp+0xA0]
000074fc119d9caa  vmovaps xmm12, [rsp+0xB0]
000074fc119d9cb3  vmovaps xmm13, [rsp+0xC0]
000074fc119d9cbc  vmovaps xmm14, [rsp+0xD0]
000074fc119d9cc5  vmovaps xmm15, [rsp+0xE0]
000074fc119d9cce  add rsp, 0xF0
000074fc119d9cd5  pop r11
000074fc119d9cd7  pop r10
000074fc119d9cd9  pop r9
000074fc119d9cdb  pop r8
000074fc119d9cdd  pop rsi
000074fc119d9cde  pop rdi
000074fc119d9cdf  pop rdx
000074fc119d9ce0  pop rcx
000074fc119d9ce1  pop rax
000074fc119d9ce2  add rsp, 0x08
000074fc119d9ce6  jmp 0x000074FC119D636D
000074fc119d9ceb  sub rsp, 0x08
000074fc119d9cef  push rax
000074fc119d9cf0  push rcx
000074fc119d9cf1  push rdx
000074fc119d9cf2  push rdi
000074fc119d9cf3  push rsi
000074fc119d9cf4  push r8
000074fc119d9cf6  push r9
000074fc119d9cf8  push r10
000074fc119d9cfa  push r11
000074fc119d9cfc  sub rsp, 0xF0
000074fc119d9d03  vmovaps [rsp], xmm0
000074fc119d9d08  vmovaps [rsp+0x10], xmm1
000074fc119d9d0e  vmovaps [rsp+0x20], xmm2
000074fc119d9d14  vmovaps [rsp+0x30], xmm3
000074fc119d9d1a  vmovaps [rsp+0x40], xmm4
000074fc119d9d20  vmovaps [rsp+0x50], xmm5
000074fc119d9d26  vmovaps [rsp+0x60], xmm6
000074fc119d9d2c  vmovaps [rsp+0x70], xmm7
000074fc119d9d32  vmovaps [rsp+0x80], xmm8
000074fc119d9d3b  vmovaps [rsp+0x90], xmm9
000074fc119d9d44  vmovaps [rsp+0xA0], xmm11
000074fc119d9d4d  vmovaps [rsp+0xB0], xmm12
000074fc119d9d56  vmovaps [rsp+0xC0], xmm13
000074fc119d9d5f  vmovaps [rsp+0xD0], xmm14
000074fc119d9d68  vmovaps [rsp+0xE0], xmm15
000074fc119d9d71  sub rsp, 0x30
000074fc119d9d75  movaps [rsp], xmm10
000074fc119d9d7a  movaps [rsp+0x10], xmm14
000074fc119d9d80  movaps [rsp+0x20], xmm4
000074fc119d9d85  lea rdi, [rsp]
000074fc119d9d89  mov esi, 0x00
000074fc119d9d8e  mov rax, 0x58C4C8091530
000074fc119d9d98  call rax
000074fc119d9d9a  movaps xmm10, [rsp]
000074fc119d9d9f  add rsp, 0x30
000074fc119d9da3  vmovaps xmm0, [rsp]
000074fc119d9da8  vmovaps xmm1, [rsp+0x10]
000074fc119d9dae  vmovaps xmm2, [rsp+0x20]
000074fc119d9db4  vmovaps xmm3, [rsp+0x30]
000074fc119d9dba  vmovaps xmm4, [rsp+0x40]
000074fc119d9dc0  vmovaps xmm5, [rsp+0x50]
000074fc119d9dc6  vmovaps xmm6, [rsp+0x60]
000074fc119d9dcc  vmovaps xmm7, [rsp+0x70]
000074fc119d9dd2  vmovaps xmm8, [rsp+0x80]
000074fc119d9ddb  vmovaps xmm9, [rsp+0x90]
000074fc119d9de4  vmovaps xmm11, [rsp+0xA0]
000074fc119d9ded  vmovaps xmm12, [rsp+0xB0]
000074fc119d9df6  vmovaps xmm13, [rsp+0xC0]
000074fc119d9dff  vmovaps xmm14, [rsp+0xD0]
000074fc119d9e08  vmovaps xmm15, [rsp+0xE0]
000074fc119d9e11  add rsp, 0xF0
000074fc119d9e18  pop r11
000074fc119d9e1a  pop r10
000074fc119d9e1c  pop r9
000074fc119d9e1e  pop r8
000074fc119d9e20  pop rsi
000074fc119d9e21  pop rdi
000074fc119d9e22  pop rdx
000074fc119d9e23  pop rcx
000074fc119d9e24  pop rax
000074fc119d9e25  add rsp, 0x08
000074fc119d9e29  jmp 0x000074FC119D6388
000074fc119d9e2e  sub rsp, 0x08
000074fc119d9e32  push rax
000074fc119d9e33  push rcx
000074fc119d9e34  push rdx
000074fc119d9e35  push rdi
000074fc119d9e36  push rsi
000074fc119d9e37  push r8
000074fc119d9e39  push r9
000074fc119d9e3b  push r10
000074fc119d9e3d  push r11
000074fc119d9e3f  sub rsp, 0xF0
000074fc119d9e46  vmovaps [rsp], xmm0
000074fc119d9e4b  vmovaps [rsp+0x10], xmm1
000074fc119d9e51  vmovaps [rsp+0x20], xmm2
000074fc119d9e57  vmovaps [rsp+0x30], xmm3
000074fc119d9e5d  vmovaps [rsp+0x40], xmm4
000074fc119d9e63  vmovaps [rsp+0x50], xmm5
000074fc119d9e69  vmovaps [rsp+0x60], xmm6
000074fc119d9e6f  vmovaps [rsp+0x70], xmm7
000074fc119d9e75  vmovaps [rsp+0x80], xmm9
000074fc119d9e7e  vmovaps [rsp+0x90], xmm10
000074fc119d9e87  vmovaps [rsp+0xA0], xmm11
000074fc119d9e90  vmovaps [rsp+0xB0], xmm12
000074fc119d9e99  vmovaps [rsp+0xC0], xmm13
000074fc119d9ea2  vmovaps [rsp+0xD0], xmm14
000074fc119d9eab  vmovaps [rsp+0xE0], xmm15
000074fc119d9eb4  sub rsp, 0x30
000074fc119d9eb8  movaps [rsp], xmm8
000074fc119d9ebd  movaps [rsp+0x10], xmm1
000074fc119d9ec2  movaps [rsp+0x20], xmm14
000074fc119d9ec8  lea rdi, [rsp]
000074fc119d9ecc  mov esi, 0x00
000074fc119d9ed1  mov rax, 0x58C4C8091530
000074fc119d9edb  call rax
000074fc119d9edd  movaps xmm8, [rsp]
000074fc119d9ee2  add rsp, 0x30
000074fc119d9ee6  vmovaps xmm0, [rsp]
000074fc119d9eeb  vmovaps xmm1, [rsp+0x10]
000074fc119d9ef1  vmovaps xmm2, [rsp+0x20]
000074fc119d9ef7  vmovaps xmm3, [rsp+0x30]
000074fc119d9efd  vmovaps xmm4, [rsp+0x40]
000074fc119d9f03  vmovaps xmm5, [rsp+0x50]
000074fc119d9f09  vmovaps xmm6, [rsp+0x60]
000074fc119d9f0f  vmovaps xmm7, [rsp+0x70]
000074fc119d9f15  vmovaps xmm9, [rsp+0x80]
000074fc119d9f1e  vmovaps xmm10, [rsp+0x90]
000074fc119d9f27  vmovaps xmm11, [rsp+0xA0]
000074fc119d9f30  vmovaps xmm12, [rsp+0xB0]
000074fc119d9f39  vmovaps xmm13, [rsp+0xC0]
000074fc119d9f42  vmovaps xmm14, [rsp+0xD0]
000074fc119d9f4b  vmovaps xmm15, [rsp+0xE0]
000074fc119d9f54  add rsp, 0xF0
000074fc119d9f5b  pop r11
000074fc119d9f5d  pop r10
000074fc119d9f5f  pop r9
000074fc119d9f61  pop r8
000074fc119d9f63  pop rsi
000074fc119d9f64  pop rdi
000074fc119d9f65  pop rdx
000074fc119d9f66  pop rcx
000074fc119d9f67  pop rax
000074fc119d9f68  add rsp, 0x08
000074fc119d9f6c  jmp 0x000074FC119D63AE
000074fc119d9f71  sub rsp, 0x08
000074fc119d9f75  push rax
000074fc119d9f76  push rcx
000074fc119d9f77  push rdx
000074fc119d9f78  push rdi
000074fc119d9f79  push rsi
000074fc119d9f7a  push r8
000074fc119d9f7c  push r9
000074fc119d9f7e  push r10
000074fc119d9f80  push r11
000074fc119d9f82  sub rsp, 0xF0
000074fc119d9f89  vmovaps [rsp], xmm0
000074fc119d9f8e  vmovaps [rsp+0x10], xmm1
000074fc119d9f94  vmovaps [rsp+0x20], xmm2
000074fc119d9f9a  vmovaps [rsp+0x30], xmm3
000074fc119d9fa0  vmovaps [rsp+0x40], xmm4
000074fc119d9fa6  vmovaps [rsp+0x50], xmm5
000074fc119d9fac  vmovaps [rsp+0x60], xmm7
000074fc119d9fb2  vmovaps [rsp+0x70], xmm8
000074fc119d9fb8  vmovaps [rsp+0x80], xmm9
000074fc119d9fc1  vmovaps [rsp+0x90], xmm10
000074fc119d9fca  vmovaps [rsp+0xA0], xmm11
000074fc119d9fd3  vmovaps [rsp+0xB0], xmm12
000074fc119d9fdc  vmovaps [rsp+0xC0], xmm13
000074fc119d9fe5  vmovaps [rsp+0xD0], xmm14
000074fc119d9fee  vmovaps [rsp+0xE0], xmm15
000074fc119d9ff7  sub rsp, 0x30
000074fc119d9ffb  movaps [rsp], xmm6
000074fc119d9fff  movaps [rsp+0x10], xmm1
000074fc119da004  movaps [rsp+0x20], xmm14
000074fc119da00a  lea rdi, [rsp]
000074fc119da00e  mov esi, 0x00
000074fc119da013  mov rax, 0x58C4C8091530
000074fc119da01d  call rax
000074fc119da01f  movaps xmm6, [rsp]
000074fc119da023  add rsp, 0x30
000074fc119da027  vmovaps xmm0, [rsp]
000074fc119da02c  vmovaps xmm1, [rsp+0x10]
000074fc119da032  vmovaps xmm2, [rsp+0x20]
000074fc119da038  vmovaps xmm3, [rsp+0x30]
000074fc119da03e  vmovaps xmm4, [rsp+0x40]
000074fc119da044  vmovaps xmm5, [rsp+0x50]
000074fc119da04a  vmovaps xmm7, [rsp+0x60]
000074fc119da050  vmovaps xmm8, [rsp+0x70]
000074fc119da056  vmovaps xmm9, [rsp+0x80]
000074fc119da05f  vmovaps xmm10, [rsp+0x90]
000074fc119da068  vmovaps xmm11, [rsp+0xA0]
000074fc119da071  vmovaps xmm12, [rsp+0xB0]
000074fc119da07a  vmovaps xmm13, [rsp+0xC0]
000074fc119da083  vmovaps xmm14, [rsp+0xD0]
000074fc119da08c  vmovaps xmm15, [rsp+0xE0]
000074fc119da095  add rsp, 0xF0
000074fc119da09c  pop r11
000074fc119da09e  pop r10
000074fc119da0a0  pop r9
000074fc119da0a2  pop r8
000074fc119da0a4  pop rsi
000074fc119da0a5  pop rdi
000074fc119da0a6  pop rdx
000074fc119da0a7  pop rcx
000074fc119da0a8  pop rax
000074fc119da0a9  add rsp, 0x08
000074fc119da0ad  jmp 0x000074FC119D63DA
000074fc119da0b2  sub rsp, 0x08
000074fc119da0b6  push rax
000074fc119da0b7  push rcx
000074fc119da0b8  push rdx
000074fc119da0b9  push rdi
000074fc119da0ba  push rsi
000074fc119da0bb  push r8
000074fc119da0bd  push r9
000074fc119da0bf  push r10
000074fc119da0c1  push r11
000074fc119da0c3  sub rsp, 0xF0
000074fc119da0ca  vmovaps [rsp], xmm0
000074fc119da0cf  vmovaps [rsp+0x10], xmm1
000074fc119da0d5  vmovaps [rsp+0x20], xmm2
000074fc119da0db  vmovaps [rsp+0x30], xmm3
000074fc119da0e1  vmovaps [rsp+0x40], xmm4
000074fc119da0e7  vmovaps [rsp+0x50], xmm5
000074fc119da0ed  vmovaps [rsp+0x60], xmm6
000074fc119da0f3  vmovaps [rsp+0x70], xmm7
000074fc119da0f9  vmovaps [rsp+0x80], xmm8
000074fc119da102  vmovaps [rsp+0x90], xmm9
000074fc119da10b  vmovaps [rsp+0xA0], xmm10
000074fc119da114  vmovaps [rsp+0xB0], xmm11
000074fc119da11d  vmovaps [rsp+0xC0], xmm12
000074fc119da126  vmovaps [rsp+0xD0], xmm13
000074fc119da12f  vmovaps [rsp+0xE0], xmm15
000074fc119da138  sub rsp, 0x30
000074fc119da13c  movaps [rsp], xmm14
000074fc119da141  movaps [rsp+0x10], xmm12
000074fc119da147  movaps [rsp+0x20], xmm1
000074fc119da14c  lea rdi, [rsp]
000074fc119da150  mov esi, 0x00
000074fc119da155  mov rax, 0x58C4C8091530
000074fc119da15f  call rax
000074fc119da161  movaps xmm14, [rsp]
000074fc119da166  add rsp, 0x30
000074fc119da16a  vmovaps xmm0, [rsp]
000074fc119da16f  vmovaps xmm1, [rsp+0x10]
000074fc119da175  vmovaps xmm2, [rsp+0x20]
000074fc119da17b  vmovaps xmm3, [rsp+0x30]
000074fc119da181  vmovaps xmm4, [rsp+0x40]
000074fc119da187  vmovaps xmm5, [rsp+0x50]
000074fc119da18d  vmovaps xmm6, [rsp+0x60]
000074fc119da193  vmovaps xmm7, [rsp+0x70]
000074fc119da199  vmovaps xmm8, [rsp+0x80]
000074fc119da1a2  vmovaps xmm9, [rsp+0x90]
000074fc119da1ab  vmovaps xmm10, [rsp+0xA0]
000074fc119da1b4  vmovaps xmm11, [rsp+0xB0]
000074fc119da1bd  vmovaps xmm12, [rsp+0xC0]
000074fc119da1c6  vmovaps xmm13, [rsp+0xD0]
000074fc119da1cf  vmovaps xmm15, [rsp+0xE0]
000074fc119da1d8  add rsp, 0xF0
000074fc119da1df  pop r11
000074fc119da1e1  pop r10
000074fc119da1e3  pop r9
000074fc119da1e5  pop r8
000074fc119da1e7  pop rsi
000074fc119da1e8  pop rdi
000074fc119da1e9  pop rdx
000074fc119da1ea  pop rcx
000074fc119da1eb  pop rax
000074fc119da1ec  add rsp, 0x08
000074fc119da1f0  jmp 0x000074FC119D6400
000074fc119da1f5  sub rsp, 0x08
000074fc119da1f9  push rax
000074fc119da1fa  push rcx
000074fc119da1fb  push rdx
000074fc119da1fc  push rdi
000074fc119da1fd  push rsi
000074fc119da1fe  push r8
000074fc119da200  push r9
000074fc119da202  push r10
000074fc119da204  push r11
000074fc119da206  sub rsp, 0xF0
000074fc119da20d  vmovaps [rsp], xmm0
000074fc119da212  vmovaps [rsp+0x10], xmm2
000074fc119da218  vmovaps [rsp+0x20], xmm3
000074fc119da21e  vmovaps [rsp+0x30], xmm4
000074fc119da224  vmovaps [rsp+0x40], xmm5
000074fc119da22a  vmovaps [rsp+0x50], xmm6
000074fc119da230  vmovaps [rsp+0x60], xmm7
000074fc119da236  vmovaps [rsp+0x70], xmm8
000074fc119da23c  vmovaps [rsp+0x80], xmm9
000074fc119da245  vmovaps [rsp+0x90], xmm10
000074fc119da24e  vmovaps [rsp+0xA0], xmm11
000074fc119da257  vmovaps [rsp+0xB0], xmm12
000074fc119da260  vmovaps [rsp+0xC0], xmm13
000074fc119da269  vmovaps [rsp+0xD0], xmm14
000074fc119da272  vmovaps [rsp+0xE0], xmm15
000074fc119da27b  sub rsp, 0x30
000074fc119da27f  movaps [rsp], xmm1
000074fc119da283  movaps [rsp+0x10], xmm13
000074fc119da289  movaps [rsp+0x20], xmm9
000074fc119da28f  lea rdi, [rsp]
000074fc119da293  mov esi, 0x00
000074fc119da298  mov rax, 0x58C4C8091530
000074fc119da2a2  call rax
000074fc119da2a4  movaps xmm1, [rsp]
000074fc119da2a8  add rsp, 0x30
000074fc119da2ac  vmovaps xmm0, [rsp]
000074fc119da2b1  vmovaps xmm2, [rsp+0x10]
000074fc119da2b7  vmovaps xmm3, [rsp+0x20]
000074fc119da2bd  vmovaps xmm4, [rsp+0x30]
000074fc119da2c3  vmovaps xmm5, [rsp+0x40]
000074fc119da2c9  vmovaps xmm6, [rsp+0x50]
000074fc119da2cf  vmovaps xmm7, [rsp+0x60]
000074fc119da2d5  vmovaps xmm8, [rsp+0x70]
000074fc119da2db  vmovaps xmm9, [rsp+0x80]
000074fc119da2e4  vmovaps xmm10, [rsp+0x90]
000074fc119da2ed  vmovaps xmm11, [rsp+0xA0]
000074fc119da2f6  vmovaps xmm12, [rsp+0xB0]
000074fc119da2ff  vmovaps xmm13, [rsp+0xC0]
000074fc119da308  vmovaps xmm14, [rsp+0xD0]
000074fc119da311  vmovaps xmm15, [rsp+0xE0]
000074fc119da31a  add rsp, 0xF0
000074fc119da321  pop r11
000074fc119da323  pop r10
000074fc119da325  pop r9
000074fc119da327  pop r8
000074fc119da329  pop rsi
000074fc119da32a  pop rdi
000074fc119da32b  pop rdx
000074fc119da32c  pop rcx
000074fc119da32d  pop rax
000074fc119da32e  add rsp, 0x08
000074fc119da332  jmp 0x000074FC119D641A
000074fc119da337  sub rsp, 0x08
000074fc119da33b  push rax
000074fc119da33c  push rcx
000074fc119da33d  push rdx
000074fc119da33e  push rdi
000074fc119da33f  push rsi
000074fc119da340  push r8
000074fc119da342  push r9
000074fc119da344  push r10
000074fc119da346  push r11
000074fc119da348  sub rsp, 0xF0
000074fc119da34f  vmovaps [rsp], xmm0
000074fc119da354  vmovaps [rsp+0x10], xmm1
000074fc119da35a  vmovaps [rsp+0x20], xmm2
000074fc119da360  vmovaps [rsp+0x30], xmm3
000074fc119da366  vmovaps [rsp+0x40], xmm4
000074fc119da36c  vmovaps [rsp+0x50], xmm5
000074fc119da372  vmovaps [rsp+0x60], xmm6
000074fc119da378  vmovaps [rsp+0x70], xmm7
000074fc119da37e  vmovaps [rsp+0x80], xmm8
000074fc119da387  vmovaps [rsp+0x90], xmm9
000074fc119da390  vmovaps [rsp+0xA0], xmm10
000074fc119da399  vmovaps [rsp+0xB0], xmm11
000074fc119da3a2  vmovaps [rsp+0xC0], xmm13
000074fc119da3ab  vmovaps [rsp+0xD0], xmm14
000074fc119da3b4  vmovaps [rsp+0xE0], xmm15
000074fc119da3bd  sub rsp, 0x30
000074fc119da3c1  movaps [rsp], xmm12
000074fc119da3c6  movaps [rsp+0x10], xmm7
000074fc119da3cb  movaps [rsp+0x20], xmm13
000074fc119da3d1  lea rdi, [rsp]
000074fc119da3d5  mov esi, 0x00
000074fc119da3da  mov rax, 0x58C4C8091530
000074fc119da3e4  call rax
000074fc119da3e6  movaps xmm12, [rsp]
000074fc119da3eb  add rsp, 0x30
000074fc119da3ef  vmovaps xmm0, [rsp]
000074fc119da3f4  vmovaps xmm1, [rsp+0x10]
000074fc119da3fa  vmovaps xmm2, [rsp+0x20]
000074fc119da400  vmovaps xmm3, [rsp+0x30]
000074fc119da406  vmovaps xmm4, [rsp+0x40]
000074fc119da40c  vmovaps xmm5, [rsp+0x50]
000074fc119da412  vmovaps xmm6, [rsp+0x60]
000074fc119da418  vmovaps xmm7, [rsp+0x70]
000074fc119da41e  vmovaps xmm8, [rsp+0x80]
000074fc119da427  vmovaps xmm9, [rsp+0x90]
000074fc119da430  vmovaps xmm10, [rsp+0xA0]
000074fc119da439  vmovaps xmm11, [rsp+0xB0]
000074fc119da442  vmovaps xmm13, [rsp+0xC0]
000074fc119da44b  vmovaps xmm14, [rsp+0xD0]
000074fc119da454  vmovaps xmm15, [rsp+0xE0]
000074fc119da45d  add rsp, 0xF0
000074fc119da464  pop r11
000074fc119da466  pop r10
000074fc119da468  pop r9
000074fc119da46a  pop r8
000074fc119da46c  pop rsi
000074fc119da46d  pop rdi
000074fc119da46e  pop rdx
000074fc119da46f  pop rcx
000074fc119da470  pop rax
000074fc119da471  add rsp, 0x08
000074fc119da475  jmp 0x000074FC119D6441
000074fc119da47a  sub rsp, 0x08
000074fc119da47e  push rax
000074fc119da47f  push rcx
000074fc119da480  push rdx
000074fc119da481  push rdi
000074fc119da482  push rsi
000074fc119da483  push r8
000074fc119da485  push r9
000074fc119da487  push r10
000074fc119da489  push r11
000074fc119da48b  sub rsp, 0xF0
000074fc119da492  vmovaps [rsp], xmm0
000074fc119da497  vmovaps [rsp+0x10], xmm1
000074fc119da49d  vmovaps [rsp+0x20], xmm2
000074fc119da4a3  vmovaps [rsp+0x30], xmm3
000074fc119da4a9  vmovaps [rsp+0x40], xmm4
000074fc119da4af  vmovaps [rsp+0x50], xmm5
000074fc119da4b5  vmovaps [rsp+0x60], xmm6
000074fc119da4bb  vmovaps [rsp+0x70], xmm7
000074fc119da4c1  vmovaps [rsp+0x80], xmm8
000074fc119da4ca  vmovaps [rsp+0x90], xmm9
000074fc119da4d3  vmovaps [rsp+0xA0], xmm10
000074fc119da4dc  vmovaps [rsp+0xB0], xmm11
000074fc119da4e5  vmovaps [rsp+0xC0], xmm12
000074fc119da4ee  vmovaps [rsp+0xD0], xmm14
000074fc119da4f7  vmovaps [rsp+0xE0], xmm15
000074fc119da500  sub rsp, 0x30
000074fc119da504  movaps [rsp], xmm13
000074fc119da509  movaps [rsp+0x10], xmm15
000074fc119da50f  movaps [rsp+0x20], xmm8
000074fc119da515  lea rdi, [rsp]
000074fc119da519  mov esi, 0x00
000074fc119da51e  mov rax, 0x58C4C8091530
000074fc119da528  call rax
000074fc119da52a  movaps xmm13, [rsp]
000074fc119da52f  add rsp, 0x30
000074fc119da533  vmovaps xmm0, [rsp]
000074fc119da538  vmovaps xmm1, [rsp+0x10]
000074fc119da53e  vmovaps xmm2, [rsp+0x20]
000074fc119da544  vmovaps xmm3, [rsp+0x30]
000074fc119da54a  vmovaps xmm4, [rsp+0x40]
000074fc119da550  vmovaps xmm5, [rsp+0x50]
000074fc119da556  vmovaps xmm6, [rsp+0x60]
000074fc119da55c  vmovaps xmm7, [rsp+0x70]
000074fc119da562  vmovaps xmm8, [rsp+0x80]
000074fc119da56b  vmovaps xmm9, [rsp+0x90]
000074fc119da574  vmovaps xmm10, [rsp+0xA0]
000074fc119da57d  vmovaps xmm11, [rsp+0xB0]
000074fc119da586  vmovaps xmm12, [rsp+0xC0]
000074fc119da58f  vmovaps xmm14, [rsp+0xD0]
000074fc119da598  vmovaps xmm15, [rsp+0xE0]
000074fc119da5a1  add rsp, 0xF0
000074fc119da5a8  pop r11
000074fc119da5aa  pop r10
000074fc119da5ac  pop r9
000074fc119da5ae  pop r8
000074fc119da5b0  pop rsi
000074fc119da5b1  pop rdi
000074fc119da5b2  pop rdx
000074fc119da5b3  pop rcx
000074fc119da5b4  pop rax
000074fc119da5b5  add rsp, 0x08
000074fc119da5b9  jmp 0x000074FC119D645C
000074fc119da5be  sub rsp, 0x08
000074fc119da5c2  push rax
000074fc119da5c3  push rcx
000074fc119da5c4  push rdx
000074fc119da5c5  push rdi
000074fc119da5c6  push rsi
000074fc119da5c7  push r8
000074fc119da5c9  push r9
000074fc119da5cb  push r10
000074fc119da5cd  push r11
000074fc119da5cf  sub rsp, 0xF0
000074fc119da5d6  vmovaps [rsp], xmm0
000074fc119da5db  vmovaps [rsp+0x10], xmm1
000074fc119da5e1  vmovaps [rsp+0x20], xmm2
000074fc119da5e7  vmovaps [rsp+0x30], xmm3
000074fc119da5ed  vmovaps [rsp+0x40], xmm4
000074fc119da5f3  vmovaps [rsp+0x50], xmm5
000074fc119da5f9  vmovaps [rsp+0x60], xmm6
000074fc119da5ff  vmovaps [rsp+0x70], xmm7
000074fc119da605  vmovaps [rsp+0x80], xmm9
000074fc119da60e  vmovaps [rsp+0x90], xmm10
000074fc119da617  vmovaps [rsp+0xA0], xmm11
000074fc119da620  vmovaps [rsp+0xB0], xmm12
000074fc119da629  vmovaps [rsp+0xC0], xmm13
000074fc119da632  vmovaps [rsp+0xD0], xmm14
000074fc119da63b  vmovaps [rsp+0xE0], xmm15
000074fc119da644  sub rsp, 0x30
000074fc119da648  movaps [rsp], xmm8
000074fc119da64d  movaps [rsp+0x10], xmm15
000074fc119da653  movaps [rsp+0x20], xmm9
000074fc119da659  lea rdi, [rsp]
000074fc119da65d  mov esi, 0x00
000074fc119da662  mov rax, 0x58C4C8091530
000074fc119da66c  call rax
000074fc119da66e  movaps xmm8, [rsp]
000074fc119da673  add rsp, 0x30
000074fc119da677  vmovaps xmm0, [rsp]
000074fc119da67c  vmovaps xmm1, [rsp+0x10]
000074fc119da682  vmovaps xmm2, [rsp+0x20]
000074fc119da688  vmovaps xmm3, [rsp+0x30]
000074fc119da68e  vmovaps xmm4, [rsp+0x40]
000074fc119da694  vmovaps xmm5, [rsp+0x50]
000074fc119da69a  vmovaps xmm6, [rsp+0x60]
000074fc119da6a0  vmovaps xmm7, [rsp+0x70]
000074fc119da6a6  vmovaps xmm9, [rsp+0x80]
000074fc119da6af  vmovaps xmm10, [rsp+0x90]
000074fc119da6b8  vmovaps xmm11, [rsp+0xA0]
000074fc119da6c1  vmovaps xmm12, [rsp+0xB0]
000074fc119da6ca  vmovaps xmm13, [rsp+0xC0]
000074fc119da6d3  vmovaps xmm14, [rsp+0xD0]
000074fc119da6dc  vmovaps xmm15, [rsp+0xE0]
000074fc119da6e5  add rsp, 0xF0
000074fc119da6ec  pop r11
000074fc119da6ee  pop r10
000074fc119da6f0  pop r9
000074fc119da6f2  pop r8
000074fc119da6f4  pop rsi
000074fc119da6f5  pop rdi
000074fc119da6f6  pop rdx
000074fc119da6f7  pop rcx
000074fc119da6f8  pop rax
000074fc119da6f9  add rsp, 0x08
000074fc119da6fd  jmp 0x000074FC119D648A
000074fc119da702  sub rsp, 0x08
000074fc119da706  push rax
000074fc119da707  push rcx
000074fc119da708  push rdx
000074fc119da709  push rdi
000074fc119da70a  push rsi
000074fc119da70b  push r8
000074fc119da70d  push r9
000074fc119da70f  push r10
000074fc119da711  push r11
000074fc119da713  sub rsp, 0xF0
000074fc119da71a  vmovaps [rsp], xmm0
000074fc119da71f  vmovaps [rsp+0x10], xmm1
000074fc119da725  vmovaps [rsp+0x20], xmm2
000074fc119da72b  vmovaps [rsp+0x30], xmm3
000074fc119da731  vmovaps [rsp+0x40], xmm4
000074fc119da737  vmovaps [rsp+0x50], xmm5
000074fc119da73d  vmovaps [rsp+0x60], xmm6
000074fc119da743  vmovaps [rsp+0x70], xmm7
000074fc119da749  vmovaps [rsp+0x80], xmm8
000074fc119da752  vmovaps [rsp+0x90], xmm9
000074fc119da75b  vmovaps [rsp+0xA0], xmm10
000074fc119da764  vmovaps [rsp+0xB0], xmm11
000074fc119da76d  vmovaps [rsp+0xC0], xmm12
000074fc119da776  vmovaps [rsp+0xD0], xmm13
000074fc119da77f  vmovaps [rsp+0xE0], xmm14
000074fc119da788  sub rsp, 0x30
000074fc119da78c  movaps [rsp], xmm15
000074fc119da791  movaps [rsp+0x10], xmm11
000074fc119da797  movaps [rsp+0x20], xmm6
000074fc119da79c  lea rdi, [rsp]
000074fc119da7a0  mov esi, 0x00
000074fc119da7a5  mov rax, 0x58C4C8091530
000074fc119da7af  call rax
000074fc119da7b1  movaps xmm15, [rsp]
000074fc119da7b6  add rsp, 0x30
000074fc119da7ba  vmovaps xmm0, [rsp]
000074fc119da7bf  vmovaps xmm1, [rsp+0x10]
000074fc119da7c5  vmovaps xmm2, [rsp+0x20]
000074fc119da7cb  vmovaps xmm3, [rsp+0x30]
000074fc119da7d1  vmovaps xmm4, [rsp+0x40]
000074fc119da7d7  vmovaps xmm5, [rsp+0x50]
000074fc119da7dd  vmovaps xmm6, [rsp+0x60]
000074fc119da7e3  vmovaps xmm7, [rsp+0x70]
000074fc119da7e9  vmovaps xmm8, [rsp+0x80]
000074fc119da7f2  vmovaps xmm9, [rsp+0x90]
000074fc119da7fb  vmovaps xmm10, [rsp+0xA0]
000074fc119da804  vmovaps xmm11, [rsp+0xB0]
000074fc119da80d  vmovaps xmm12, [rsp+0xC0]
000074fc119da816  vmovaps xmm13, [rsp+0xD0]
000074fc119da81f  vmovaps xmm14, [rsp+0xE0]
000074fc119da828  add rsp, 0xF0
000074fc119da82f  pop r11
000074fc119da831  pop r10
000074fc119da833  pop r9
000074fc119da835  pop r8
000074fc119da837  pop rsi
000074fc119da838  pop rdi
000074fc119da839  pop rdx
000074fc119da83a  pop rcx
000074fc119da83b  pop rax
000074fc119da83c  add rsp, 0x08
000074fc119da840  jmp 0x000074FC119D64A5
000074fc119da845  sub rsp, 0x08
000074fc119da849  push rax
000074fc119da84a  push rcx
000074fc119da84b  push rdx
000074fc119da84c  push rdi
000074fc119da84d  push rsi
000074fc119da84e  push r8
000074fc119da850  push r9
000074fc119da852  push r10
000074fc119da854  push r11
000074fc119da856  sub rsp, 0xF0
000074fc119da85d  vmovaps [rsp], xmm0
000074fc119da862  vmovaps [rsp+0x10], xmm1
000074fc119da868  vmovaps [rsp+0x20], xmm2
000074fc119da86e  vmovaps [rsp+0x30], xmm3
000074fc119da874  vmovaps [rsp+0x40], xmm4
000074fc119da87a  vmovaps [rsp+0x50], xmm5
000074fc119da880  vmovaps [rsp+0x60], xmm6
000074fc119da886  vmovaps [rsp+0x70], xmm8
000074fc119da88c  vmovaps [rsp+0x80], xmm9
000074fc119da895  vmovaps [rsp+0x90], xmm10
000074fc119da89e  vmovaps [rsp+0xA0], xmm11
000074fc119da8a7  vmovaps [rsp+0xB0], xmm12
000074fc119da8b0  vmovaps [rsp+0xC0], xmm13
000074fc119da8b9  vmovaps [rsp+0xD0], xmm14
000074fc119da8c2  vmovaps [rsp+0xE0], xmm15
000074fc119da8cb  sub rsp, 0x30
000074fc119da8cf  movaps [rsp], xmm7
000074fc119da8d3  movaps [rsp+0x10], xmm11
000074fc119da8d9  movaps [rsp+0x20], xmm9
000074fc119da8df  lea rdi, [rsp]
000074fc119da8e3  mov esi, 0x00
000074fc119da8e8  mov rax, 0x58C4C8091530
000074fc119da8f2  call rax
000074fc119da8f4  movaps xmm7, [rsp]
000074fc119da8f8  add rsp, 0x30
000074fc119da8fc  vmovaps xmm0, [rsp]
000074fc119da901  vmovaps xmm1, [rsp+0x10]
000074fc119da907  vmovaps xmm2, [rsp+0x20]
000074fc119da90d  vmovaps xmm3, [rsp+0x30]
000074fc119da913  vmovaps xmm4, [rsp+0x40]
000074fc119da919  vmovaps xmm5, [rsp+0x50]
000074fc119da91f  vmovaps xmm6, [rsp+0x60]
000074fc119da925  vmovaps xmm8, [rsp+0x70]
000074fc119da92b  vmovaps xmm9, [rsp+0x80]
000074fc119da934  vmovaps xmm10, [rsp+0x90]
000074fc119da93d  vmovaps xmm11, [rsp+0xA0]
000074fc119da946  vmovaps xmm12, [rsp+0xB0]
000074fc119da94f  vmovaps xmm13, [rsp+0xC0]
000074fc119da958  vmovaps xmm14, [rsp+0xD0]
000074fc119da961  vmovaps xmm15, [rsp+0xE0]
000074fc119da96a  add rsp, 0xF0
000074fc119da971  pop r11
000074fc119da973  pop r10
000074fc119da975  pop r9
000074fc119da977  pop r8
000074fc119da979  pop rsi
000074fc119da97a  pop rdi
000074fc119da97b  pop rdx
000074fc119da97c  pop rcx
000074fc119da97d  pop rax
000074fc119da97e  add rsp, 0x08
000074fc119da982  jmp 0x000074FC119D64D2
000074fc119da987  sub rsp, 0x08
000074fc119da98b  push rax
000074fc119da98c  push rcx
000074fc119da98d  push rdx
000074fc119da98e  push rdi
000074fc119da98f  push rsi
000074fc119da990  push r8
000074fc119da992  push r9
000074fc119da994  push r10
000074fc119da996  push r11
000074fc119da998  sub rsp, 0xF0
000074fc119da99f  vmovaps [rsp], xmm0
000074fc119da9a4  vmovaps [rsp+0x10], xmm1
000074fc119da9aa  vmovaps [rsp+0x20], xmm2
000074fc119da9b0  vmovaps [rsp+0x30], xmm3
000074fc119da9b6  vmovaps [rsp+0x40], xmm4
000074fc119da9bc  vmovaps [rsp+0x50], xmm5
000074fc119da9c2  vmovaps [rsp+0x60], xmm6
000074fc119da9c8  vmovaps [rsp+0x70], xmm7
000074fc119da9ce  vmovaps [rsp+0x80], xmm8
000074fc119da9d7  vmovaps [rsp+0x90], xmm9
000074fc119da9e0  vmovaps [rsp+0xA0], xmm10
000074fc119da9e9  vmovaps [rsp+0xB0], xmm12
000074fc119da9f2  vmovaps [rsp+0xC0], xmm13
000074fc119da9fb  vmovaps [rsp+0xD0], xmm14
000074fc119daa04  vmovaps [rsp+0xE0], xmm15
000074fc119daa0d  sub rsp, 0x30
000074fc119daa11  movaps [rsp], xmm11
000074fc119daa16  movaps [rsp+0x10], xmm10
000074fc119daa1c  movaps [rsp+0x20], xmm14
000074fc119daa22  lea rdi, [rsp]
000074fc119daa26  mov esi, 0x00
000074fc119daa2b  mov rax, 0x58C4C8091530
000074fc119daa35  call rax
000074fc119daa37  movaps xmm11, [rsp]
000074fc119daa3c  add rsp, 0x30
000074fc119daa40  vmovaps xmm0, [rsp]
000074fc119daa45  vmovaps xmm1, [rsp+0x10]
000074fc119daa4b  vmovaps xmm2, [rsp+0x20]
000074fc119daa51  vmovaps xmm3, [rsp+0x30]
000074fc119daa57  vmovaps xmm4, [rsp+0x40]
000074fc119daa5d  vmovaps xmm5, [rsp+0x50]
000074fc119daa63  vmovaps xmm6, [rsp+0x60]
000074fc119daa69  vmovaps xmm7, [rsp+0x70]
000074fc119daa6f  vmovaps xmm8, [rsp+0x80]
000074fc119daa78  vmovaps xmm9, [rsp+0x90]
000074fc119daa81  vmovaps xmm10, [rsp+0xA0]
000074fc119daa8a  vmovaps xmm12, [rsp+0xB0]
000074fc119daa93  vmovaps xmm13, [rsp+0xC0]
000074fc119daa9c  vmovaps xmm14, [rsp+0xD0]
000074fc119daaa5  vmovaps xmm15, [rsp+0xE0]
000074fc119daaae  add rsp, 0xF0
000074fc119daab5  pop r11
000074fc119daab7  pop r10
000074fc119daab9  pop r9
000074fc119daabb  pop r8
000074fc119daabd  pop rsi
000074fc119daabe  pop rdi
000074fc119daabf  pop rdx
000074fc119daac0  pop rcx
000074fc119daac1  pop rax
000074fc119daac2  add rsp, 0x08
000074fc119daac6  jmp 0x000074FC119D64ED
000074fc119daacb  call 0x000074FC118E45A0
000074fc119daad0  jmp 0x000074FC119D64F7
000074fc119daad5  sub rsp, 0x08
000074fc119daad9  push rax
000074fc119daada  push rcx
000074fc119daadb  push rdx
000074fc119daadc  push rdi
000074fc119daadd  push rsi
000074fc119daade  push r8
000074fc119daae0  push r9
000074fc119daae2  push r10
000074fc119daae4  push r11
000074fc119daae6  sub rsp, 0xF0
000074fc119daaed  vmovaps [rsp], xmm0
000074fc119daaf2  vmovaps [rsp+0x10], xmm1
000074fc119daaf8  vmovaps [rsp+0x20], xmm2
000074fc119daafe  vmovaps [rsp+0x30], xmm3
000074fc119dab04  vmovaps [rsp+0x40], xmm4
000074fc119dab0a  vmovaps [rsp+0x50], xmm5
000074fc119dab10  vmovaps [rsp+0x60], xmm6
000074fc119dab16  vmovaps [rsp+0x70], xmm7
000074fc119dab1c  vmovaps [rsp+0x80], xmm8
000074fc119dab25  vmovaps [rsp+0x90], xmm9
000074fc119dab2e  vmovaps [rsp+0xA0], xmm11
000074fc119dab37  vmovaps [rsp+0xB0], xmm12
000074fc119dab40  vmovaps [rsp+0xC0], xmm13
000074fc119dab49  vmovaps [rsp+0xD0], xmm14
000074fc119dab52  vmovaps [rsp+0xE0], xmm15
000074fc119dab5b  sub rsp, 0x30
000074fc119dab5f  movaps [rsp], xmm10
000074fc119dab64  movaps [rsp+0x10], xmm1
000074fc119dab69  movaps [rsp+0x20], xmm12
000074fc119dab6f  lea rdi, [rsp]
000074fc119dab73  mov esi, 0x00
000074fc119dab78  mov rax, 0x58C4C8091530
000074fc119dab82  call rax
000074fc119dab84  movaps xmm10, [rsp]
000074fc119dab89  add rsp, 0x30
000074fc119dab8d  vmovaps xmm0, [rsp]
000074fc119dab92  vmovaps xmm1, [rsp+0x10]
000074fc119dab98  vmovaps xmm2, [rsp+0x20]
000074fc119dab9e  vmovaps xmm3, [rsp+0x30]
000074fc119daba4  vmovaps xmm4, [rsp+0x40]
000074fc119dabaa  vmovaps xmm5, [rsp+0x50]
000074fc119dabb0  vmovaps xmm6, [rsp+0x60]
000074fc119dabb6  vmovaps xmm7, [rsp+0x70]
000074fc119dabbc  vmovaps xmm8, [rsp+0x80]
000074fc119dabc5  vmovaps xmm9, [rsp+0x90]
000074fc119dabce  vmovaps xmm11, [rsp+0xA0]
000074fc119dabd7  vmovaps xmm12, [rsp+0xB0]
000074fc119dabe0  vmovaps xmm13, [rsp+0xC0]
000074fc119dabe9  vmovaps xmm14, [rsp+0xD0]
000074fc119dabf2  vmovaps xmm15, [rsp+0xE0]
000074fc119dabfb  add rsp, 0xF0
000074fc119dac02  pop r11
000074fc119dac04  pop r10
000074fc119dac06  pop r9
000074fc119dac08  pop r8
000074fc119dac0a  pop rsi
000074fc119dac0b  pop rdi
000074fc119dac0c  pop rdx
000074fc119dac0d  pop rcx
000074fc119dac0e  pop rax
000074fc119dac0f  add rsp, 0x08
000074fc119dac13  jmp 0x000074FC119D651A
000074fc119dac18  sub rsp, 0x08
000074fc119dac1c  push rax
000074fc119dac1d  push rcx
000074fc119dac1e  push rdx
000074fc119dac1f  push rdi
000074fc119dac20  push rsi
000074fc119dac21  push r8
000074fc119dac23  push r9
000074fc119dac25  push r10
000074fc119dac27  push r11
000074fc119dac29  sub rsp, 0xF0
000074fc119dac30  vmovaps [rsp], xmm0
000074fc119dac35  vmovaps [rsp+0x10], xmm1
000074fc119dac3b  vmovaps [rsp+0x20], xmm2
000074fc119dac41  vmovaps [rsp+0x30], xmm3
000074fc119dac47  vmovaps [rsp+0x40], xmm4
000074fc119dac4d  vmovaps [rsp+0x50], xmm5
000074fc119dac53  vmovaps [rsp+0x60], xmm6
000074fc119dac59  vmovaps [rsp+0x70], xmm7
000074fc119dac5f  vmovaps [rsp+0x80], xmm8
000074fc119dac68  vmovaps [rsp+0x90], xmm9
000074fc119dac71  vmovaps [rsp+0xA0], xmm10
000074fc119dac7a  vmovaps [rsp+0xB0], xmm11
000074fc119dac83  vmovaps [rsp+0xC0], xmm13
000074fc119dac8c  vmovaps [rsp+0xD0], xmm14
000074fc119dac95  vmovaps [rsp+0xE0], xmm15
000074fc119dac9e  sub rsp, 0x30
000074fc119daca2  movaps [rsp], xmm12
000074fc119daca7  movaps [rsp+0x10], xmm14
000074fc119dacad  movaps [rsp+0x20], xmm1
000074fc119dacb2  lea rdi, [rsp]
000074fc119dacb6  mov esi, 0x00
000074fc119dacbb  mov rax, 0x58C4C8091530
000074fc119dacc5  call rax
000074fc119dacc7  movaps xmm12, [rsp]
000074fc119daccc  add rsp, 0x30
000074fc119dacd0  vmovaps xmm0, [rsp]
000074fc119dacd5  vmovaps xmm1, [rsp+0x10]
000074fc119dacdb  vmovaps xmm2, [rsp+0x20]
000074fc119dace1  vmovaps xmm3, [rsp+0x30]
000074fc119dace7  vmovaps xmm4, [rsp+0x40]
000074fc119daced  vmovaps xmm5, [rsp+0x50]
000074fc119dacf3  vmovaps xmm6, [rsp+0x60]
000074fc119dacf9  vmovaps xmm7, [rsp+0x70]
000074fc119dacff  vmovaps xmm8, [rsp+0x80]
000074fc119dad08  vmovaps xmm9, [rsp+0x90]
000074fc119dad11  vmovaps xmm10, [rsp+0xA0]
000074fc119dad1a  vmovaps xmm11, [rsp+0xB0]
000074fc119dad23  vmovaps xmm13, [rsp+0xC0]
000074fc119dad2c  vmovaps xmm14, [rsp+0xD0]
000074fc119dad35  vmovaps xmm15, [rsp+0xE0]
000074fc119dad3e  add rsp, 0xF0
000074fc119dad45  pop r11
000074fc119dad47  pop r10
000074fc119dad49  pop r9
000074fc119dad4b  pop r8
000074fc119dad4d  pop rsi
000074fc119dad4e  pop rdi
000074fc119dad4f  pop rdx
000074fc119dad50  pop rcx
000074fc119dad51  pop rax
000074fc119dad52  add rsp, 0x08
000074fc119dad56  jmp 0x000074FC119D6549
000074fc119dad5b  sub rsp, 0x08
000074fc119dad5f  push rax
000074fc119dad60  push rcx
000074fc119dad61  push rdx
000074fc119dad62  push rdi
000074fc119dad63  push rsi
000074fc119dad64  push r8
000074fc119dad66  push r9
000074fc119dad68  push r10
000074fc119dad6a  push r11
000074fc119dad6c  sub rsp, 0xF0
000074fc119dad73  vmovaps [rsp], xmm0
000074fc119dad78  vmovaps [rsp+0x10], xmm1
000074fc119dad7e  vmovaps [rsp+0x20], xmm2
000074fc119dad84  vmovaps [rsp+0x30], xmm3
000074fc119dad8a  vmovaps [rsp+0x40], xmm4
000074fc119dad90  vmovaps [rsp+0x50], xmm5
000074fc119dad96  vmovaps [rsp+0x60], xmm6
000074fc119dad9c  vmovaps [rsp+0x70], xmm7
000074fc119dada2  vmovaps [rsp+0x80], xmm8
000074fc119dadab  vmovaps [rsp+0x90], xmm9
000074fc119dadb4  vmovaps [rsp+0xA0], xmm10
000074fc119dadbd  vmovaps [rsp+0xB0], xmm11
000074fc119dadc6  vmovaps [rsp+0xC0], xmm12
000074fc119dadcf  vmovaps [rsp+0xD0], xmm13
000074fc119dadd8  vmovaps [rsp+0xE0], xmm15
000074fc119dade1  sub rsp, 0x30
000074fc119dade5  movaps [rsp], xmm14
000074fc119dadea  movaps [rsp+0x10], xmm9
000074fc119dadf0  movaps [rsp+0x20], xmm1
000074fc119dadf5  lea rdi, [rsp]
000074fc119dadf9  mov esi, 0x00
000074fc119dadfe  mov rax, 0x58C4C8091530
000074fc119dae08  call rax
000074fc119dae0a  movaps xmm14, [rsp]
000074fc119dae0f  add rsp, 0x30
000074fc119dae13  vmovaps xmm0, [rsp]
000074fc119dae18  vmovaps xmm1, [rsp+0x10]
000074fc119dae1e  vmovaps xmm2, [rsp+0x20]
000074fc119dae24  vmovaps xmm3, [rsp+0x30]
000074fc119dae2a  vmovaps xmm4, [rsp+0x40]
000074fc119dae30  vmovaps xmm5, [rsp+0x50]
000074fc119dae36  vmovaps xmm6, [rsp+0x60]
000074fc119dae3c  vmovaps xmm7, [rsp+0x70]
000074fc119dae42  vmovaps xmm8, [rsp+0x80]
000074fc119dae4b  vmovaps xmm9, [rsp+0x90]
000074fc119dae54  vmovaps xmm10, [rsp+0xA0]
000074fc119dae5d  vmovaps xmm11, [rsp+0xB0]
000074fc119dae66  vmovaps xmm12, [rsp+0xC0]
000074fc119dae6f  vmovaps xmm13, [rsp+0xD0]
000074fc119dae78  vmovaps xmm15, [rsp+0xE0]
000074fc119dae81  add rsp, 0xF0
000074fc119dae88  pop r11
000074fc119dae8a  pop r10
000074fc119dae8c  pop r9
000074fc119dae8e  pop r8
000074fc119dae90  pop rsi
000074fc119dae91  pop rdi
000074fc119dae92  pop rdx
000074fc119dae93  pop rcx
000074fc119dae94  pop rax
000074fc119dae95  add rsp, 0x08
000074fc119dae99  jmp 0x000074FC119D6578
000074fc119dae9e  sub rsp, 0x08
000074fc119daea2  push rax
000074fc119daea3  push rcx
000074fc119daea4  push rdx
000074fc119daea5  push rdi
000074fc119daea6  push rsi
000074fc119daea7  push r8
000074fc119daea9  push r9
000074fc119daeab  push r10
000074fc119daead  push r11
000074fc119daeaf  sub rsp, 0xF0
000074fc119daeb6  vmovaps [rsp], xmm0
000074fc119daebb  vmovaps [rsp+0x10], xmm2
000074fc119daec1  vmovaps [rsp+0x20], xmm3
000074fc119daec7  vmovaps [rsp+0x30], xmm4
000074fc119daecd  vmovaps [rsp+0x40], xmm5
000074fc119daed3  vmovaps [rsp+0x50], xmm6
000074fc119daed9  vmovaps [rsp+0x60], xmm7
000074fc119daedf  vmovaps [rsp+0x70], xmm8
000074fc119daee5  vmovaps [rsp+0x80], xmm9
000074fc119daeee  vmovaps [rsp+0x90], xmm10
000074fc119daef7  vmovaps [rsp+0xA0], xmm11
000074fc119daf00  vmovaps [rsp+0xB0], xmm12
000074fc119daf09  vmovaps [rsp+0xC0], xmm13
000074fc119daf12  vmovaps [rsp+0xD0], xmm14
000074fc119daf1b  vmovaps [rsp+0xE0], xmm15
000074fc119daf24  sub rsp, 0x30
000074fc119daf28  movaps [rsp], xmm1
000074fc119daf2c  movaps [rsp+0x10], xmm13
000074fc119daf32  movaps [rsp+0x20], xmm8
000074fc119daf38  lea rdi, [rsp]
000074fc119daf3c  mov esi, 0x00
000074fc119daf41  mov rax, 0x58C4C8091530
000074fc119daf4b  call rax
000074fc119daf4d  movaps xmm1, [rsp]
000074fc119daf51  add rsp, 0x30
000074fc119daf55  vmovaps xmm0, [rsp]
000074fc119daf5a  vmovaps xmm2, [rsp+0x10]
000074fc119daf60  vmovaps xmm3, [rsp+0x20]
000074fc119daf66  vmovaps xmm4, [rsp+0x30]
000074fc119daf6c  vmovaps xmm5, [rsp+0x40]
000074fc119daf72  vmovaps xmm6, [rsp+0x50]
000074fc119daf78  vmovaps xmm7, [rsp+0x60]
000074fc119daf7e  vmovaps xmm8, [rsp+0x70]
000074fc119daf84  vmovaps xmm9, [rsp+0x80]
000074fc119daf8d  vmovaps xmm10, [rsp+0x90]
000074fc119daf96  vmovaps xmm11, [rsp+0xA0]
000074fc119daf9f  vmovaps xmm12, [rsp+0xB0]
000074fc119dafa8  vmovaps xmm13, [rsp+0xC0]
000074fc119dafb1  vmovaps xmm14, [rsp+0xD0]
000074fc119dafba  vmovaps xmm15, [rsp+0xE0]
000074fc119dafc3  add rsp, 0xF0
000074fc119dafca  pop r11
000074fc119dafcc  pop r10
000074fc119dafce  pop r9
000074fc119dafd0  pop r8
000074fc119dafd2  pop rsi
000074fc119dafd3  pop rdi
000074fc119dafd4  pop rdx
000074fc119dafd5  pop rcx
000074fc119dafd6  pop rax
000074fc119dafd7  add rsp, 0x08
000074fc119dafdb  jmp 0x000074FC119D659A
000074fc119dafe0  call 0x000074FC1180C260
000074fc119dafe5  jmp 0x000074FC119D65A8
000074fc119dafea  call 0x000074FC118DE950
000074fc119dafef  jmp 0x000074FC119D65B2
000074fc119daff4  sub rsp, 0x08
000074fc119daff8  push rax
000074fc119daff9  push rcx
000074fc119daffa  push rdx
000074fc119daffb  push rdi
000074fc119daffc  push rsi
000074fc119daffd  push r8
000074fc119dafff  push r9
000074fc119db001  push r10
000074fc119db003  push r11
000074fc119db005  sub rsp, 0xF0
000074fc119db00c  vmovaps [rsp], xmm0
000074fc119db011  vmovaps [rsp+0x10], xmm1
000074fc119db017  vmovaps [rsp+0x20], xmm2
000074fc119db01d  vmovaps [rsp+0x30], xmm3
000074fc119db023  vmovaps [rsp+0x40], xmm4
000074fc119db029  vmovaps [rsp+0x50], xmm5
000074fc119db02f  vmovaps [rsp+0x60], xmm6
000074fc119db035  vmovaps [rsp+0x70], xmm7
000074fc119db03b  vmovaps [rsp+0x80], xmm9
000074fc119db044  vmovaps [rsp+0x90], xmm10
000074fc119db04d  vmovaps [rsp+0xA0], xmm11
000074fc119db056  vmovaps [rsp+0xB0], xmm12
000074fc119db05f  vmovaps [rsp+0xC0], xmm13
000074fc119db068  vmovaps [rsp+0xD0], xmm14
000074fc119db071  vmovaps [rsp+0xE0], xmm15
000074fc119db07a  sub rsp, 0x30
000074fc119db07e  movaps [rsp], xmm8
000074fc119db083  movaps [rsp+0x10], xmm15
000074fc119db089  movaps [rsp+0x20], xmm7
000074fc119db08e  lea rdi, [rsp]
000074fc119db092  mov esi, 0x00
000074fc119db097  mov rax, 0x58C4C8091530
000074fc119db0a1  call rax
000074fc119db0a3  movaps xmm8, [rsp]
000074fc119db0a8  add rsp, 0x30
000074fc119db0ac  vmovaps xmm0, [rsp]
000074fc119db0b1  vmovaps xmm1, [rsp+0x10]
000074fc119db0b7  vmovaps xmm2, [rsp+0x20]
000074fc119db0bd  vmovaps xmm3, [rsp+0x30]
000074fc119db0c3  vmovaps xmm4, [rsp+0x40]
000074fc119db0c9  vmovaps xmm5, [rsp+0x50]
000074fc119db0cf  vmovaps xmm6, [rsp+0x60]
000074fc119db0d5  vmovaps xmm7, [rsp+0x70]
000074fc119db0db  vmovaps xmm9, [rsp+0x80]
000074fc119db0e4  vmovaps xmm10, [rsp+0x90]
000074fc119db0ed  vmovaps xmm11, [rsp+0xA0]
000074fc119db0f6  vmovaps xmm12, [rsp+0xB0]
000074fc119db0ff  vmovaps xmm13, [rsp+0xC0]
000074fc119db108  vmovaps xmm14, [rsp+0xD0]
000074fc119db111  vmovaps xmm15, [rsp+0xE0]
000074fc119db11a  add rsp, 0xF0
000074fc119db121  pop r11
000074fc119db123  pop r10
000074fc119db125  pop r9
000074fc119db127  pop r8
000074fc119db129  pop rsi
000074fc119db12a  pop rdi
000074fc119db12b  pop rdx
000074fc119db12c  pop rcx
000074fc119db12d  pop rax
000074fc119db12e  add rsp, 0x08
000074fc119db132  jmp 0x000074FC119D65D4
000074fc119db137  sub rsp, 0x08
000074fc119db13b  push rax
000074fc119db13c  push rcx
000074fc119db13d  push rdx
000074fc119db13e  push rdi
000074fc119db13f  push rsi
000074fc119db140  push r8
000074fc119db142  push r9
000074fc119db144  push r10
000074fc119db146  push r11
000074fc119db148  sub rsp, 0xF0
000074fc119db14f  vmovaps [rsp], xmm0
000074fc119db154  vmovaps [rsp+0x10], xmm1
000074fc119db15a  vmovaps [rsp+0x20], xmm2
000074fc119db160  vmovaps [rsp+0x30], xmm3
000074fc119db166  vmovaps [rsp+0x40], xmm4
000074fc119db16c  vmovaps [rsp+0x50], xmm5
000074fc119db172  vmovaps [rsp+0x60], xmm6
000074fc119db178  vmovaps [rsp+0x70], xmm8
000074fc119db17e  vmovaps [rsp+0x80], xmm9
000074fc119db187  vmovaps [rsp+0x90], xmm10
000074fc119db190  vmovaps [rsp+0xA0], xmm11
000074fc119db199  vmovaps [rsp+0xB0], xmm12
000074fc119db1a2  vmovaps [rsp+0xC0], xmm13
000074fc119db1ab  vmovaps [rsp+0xD0], xmm14
000074fc119db1b4  vmovaps [rsp+0xE0], xmm15
000074fc119db1bd  sub rsp, 0x30
000074fc119db1c1  movaps [rsp], xmm7
000074fc119db1c5  movaps [rsp+0x10], xmm9
000074fc119db1cb  movaps [rsp+0x20], xmm15
000074fc119db1d1  lea rdi, [rsp]
000074fc119db1d5  mov esi, 0x00
000074fc119db1da  mov rax, 0x58C4C8091530
000074fc119db1e4  call rax
000074fc119db1e6  movaps xmm7, [rsp]
000074fc119db1ea  add rsp, 0x30
000074fc119db1ee  vmovaps xmm0, [rsp]
000074fc119db1f3  vmovaps xmm1, [rsp+0x10]
000074fc119db1f9  vmovaps xmm2, [rsp+0x20]
000074fc119db1ff  vmovaps xmm3, [rsp+0x30]
000074fc119db205  vmovaps xmm4, [rsp+0x40]
000074fc119db20b  vmovaps xmm5, [rsp+0x50]
000074fc119db211  vmovaps xmm6, [rsp+0x60]
000074fc119db217  vmovaps xmm8, [rsp+0x70]
000074fc119db21d  vmovaps xmm9, [rsp+0x80]
000074fc119db226  vmovaps xmm10, [rsp+0x90]
000074fc119db22f  vmovaps xmm11, [rsp+0xA0]
000074fc119db238  vmovaps xmm12, [rsp+0xB0]
000074fc119db241  vmovaps xmm13, [rsp+0xC0]
000074fc119db24a  vmovaps xmm14, [rsp+0xD0]
000074fc119db253  vmovaps xmm15, [rsp+0xE0]
000074fc119db25c  add rsp, 0xF0
000074fc119db263  pop r11
000074fc119db265  pop r10
000074fc119db267  pop r9
000074fc119db269  pop r8
000074fc119db26b  pop rsi
000074fc119db26c  pop rdi
000074fc119db26d  pop rdx
000074fc119db26e  pop rcx
000074fc119db26f  pop rax
000074fc119db270  add rsp, 0x08
000074fc119db274  jmp 0x000074FC119D6601
000074fc119db279  sub rsp, 0x08
000074fc119db27d  push rax
000074fc119db27e  push rcx
000074fc119db27f  push rdx
000074fc119db280  push rdi
000074fc119db281  push rsi
000074fc119db282  push r8
000074fc119db284  push r9
000074fc119db286  push r10
000074fc119db288  push r11
000074fc119db28a  sub rsp, 0xF0
000074fc119db291  vmovaps [rsp], xmm0
000074fc119db296  vmovaps [rsp+0x10], xmm1
000074fc119db29c  vmovaps [rsp+0x20], xmm2
000074fc119db2a2  vmovaps [rsp+0x30], xmm3
000074fc119db2a8  vmovaps [rsp+0x40], xmm4
000074fc119db2ae  vmovaps [rsp+0x50], xmm5
000074fc119db2b4  vmovaps [rsp+0x60], xmm6
000074fc119db2ba  vmovaps [rsp+0x70], xmm7
000074fc119db2c0  vmovaps [rsp+0x80], xmm8
000074fc119db2c9  vmovaps [rsp+0x90], xmm10
000074fc119db2d2  vmovaps [rsp+0xA0], xmm11
000074fc119db2db  vmovaps [rsp+0xB0], xmm12
000074fc119db2e4  vmovaps [rsp+0xC0], xmm13
000074fc119db2ed  vmovaps [rsp+0xD0], xmm14
000074fc119db2f6  vmovaps [rsp+0xE0], xmm15
000074fc119db2ff  sub rsp, 0x30
000074fc119db303  movaps [rsp], xmm9
000074fc119db308  movaps [rsp+0x10], xmm13
000074fc119db30e  movaps [rsp+0x20], xmm15
000074fc119db314  lea rdi, [rsp]
000074fc119db318  mov esi, 0x00
000074fc119db31d  mov rax, 0x58C4C8091530
000074fc119db327  call rax
000074fc119db329  movaps xmm9, [rsp]
000074fc119db32e  add rsp, 0x30
000074fc119db332  vmovaps xmm0, [rsp]
000074fc119db337  vmovaps xmm1, [rsp+0x10]
000074fc119db33d  vmovaps xmm2, [rsp+0x20]
000074fc119db343  vmovaps xmm3, [rsp+0x30]
000074fc119db349  vmovaps xmm4, [rsp+0x40]
000074fc119db34f  vmovaps xmm5, [rsp+0x50]
000074fc119db355  vmovaps xmm6, [rsp+0x60]
000074fc119db35b  vmovaps xmm7, [rsp+0x70]
000074fc119db361  vmovaps xmm8, [rsp+0x80]
000074fc119db36a  vmovaps xmm10, [rsp+0x90]
000074fc119db373  vmovaps xmm11, [rsp+0xA0]
000074fc119db37c  vmovaps xmm12, [rsp+0xB0]
000074fc119db385  vmovaps xmm13, [rsp+0xC0]
000074fc119db38e  vmovaps xmm14, [rsp+0xD0]
000074fc119db397  vmovaps xmm15, [rsp+0xE0]
000074fc119db3a0  add rsp, 0xF0
000074fc119db3a7  pop r11
000074fc119db3a9  pop r10
000074fc119db3ab  pop r9
000074fc119db3ad  pop r8
000074fc119db3af  pop rsi
000074fc119db3b0  pop rdi
000074fc119db3b1  pop rdx
000074fc119db3b2  pop rcx
000074fc119db3b3  pop rax
000074fc119db3b4  add rsp, 0x08
000074fc119db3b8  jmp 0x000074FC119D662F
000074fc119db3bd  sub rsp, 0x08
000074fc119db3c1  push rax
000074fc119db3c2  push rcx
000074fc119db3c3  push rdx
000074fc119db3c4  push rdi
000074fc119db3c5  push rsi
000074fc119db3c6  push r8
000074fc119db3c8  push r9
000074fc119db3ca  push r10
000074fc119db3cc  push r11
000074fc119db3ce  sub rsp, 0xF0
000074fc119db3d5  vmovaps [rsp], xmm0
000074fc119db3da  vmovaps [rsp+0x10], xmm1
000074fc119db3e0  vmovaps [rsp+0x20], xmm2
000074fc119db3e6  vmovaps [rsp+0x30], xmm3
000074fc119db3ec  vmovaps [rsp+0x40], xmm4
000074fc119db3f2  vmovaps [rsp+0x50], xmm5
000074fc119db3f8  vmovaps [rsp+0x60], xmm6
000074fc119db3fe  vmovaps [rsp+0x70], xmm7
000074fc119db404  vmovaps [rsp+0x80], xmm8
000074fc119db40d  vmovaps [rsp+0x90], xmm9
000074fc119db416  vmovaps [rsp+0xA0], xmm10
000074fc119db41f  vmovaps [rsp+0xB0], xmm11
000074fc119db428  vmovaps [rsp+0xC0], xmm12
000074fc119db431  vmovaps [rsp+0xD0], xmm13
000074fc119db43a  vmovaps [rsp+0xE0], xmm14
000074fc119db443  sub rsp, 0x30
000074fc119db447  movaps [rsp], xmm15
000074fc119db44c  movaps [rsp+0x10], xmm11
000074fc119db452  movaps [rsp+0x20], xmm12
000074fc119db458  lea rdi, [rsp]
000074fc119db45c  mov esi, 0x00
000074fc119db461  mov rax, 0x58C4C8091530
000074fc119db46b  call rax
000074fc119db46d  movaps xmm15, [rsp]
000074fc119db472  add rsp, 0x30
000074fc119db476  vmovaps xmm0, [rsp]
000074fc119db47b  vmovaps xmm1, [rsp+0x10]
000074fc119db481  vmovaps xmm2, [rsp+0x20]
000074fc119db487  vmovaps xmm3, [rsp+0x30]
000074fc119db48d  vmovaps xmm4, [rsp+0x40]
000074fc119db493  vmovaps xmm5, [rsp+0x50]
000074fc119db499  vmovaps xmm6, [rsp+0x60]
000074fc119db49f  vmovaps xmm7, [rsp+0x70]
000074fc119db4a5  vmovaps xmm8, [rsp+0x80]
000074fc119db4ae  vmovaps xmm9, [rsp+0x90]
000074fc119db4b7  vmovaps xmm10, [rsp+0xA0]
000074fc119db4c0  vmovaps xmm11, [rsp+0xB0]
000074fc119db4c9  vmovaps xmm12, [rsp+0xC0]
000074fc119db4d2  vmovaps xmm13, [rsp+0xD0]
000074fc119db4db  vmovaps xmm14, [rsp+0xE0]
000074fc119db4e4  add rsp, 0xF0
000074fc119db4eb  pop r11
000074fc119db4ed  pop r10
000074fc119db4ef  pop r9
000074fc119db4f1  pop r8
000074fc119db4f3  pop rsi
000074fc119db4f4  pop rdi
000074fc119db4f5  pop rdx
000074fc119db4f6  pop rcx
000074fc119db4f7  pop rax
000074fc119db4f8  add rsp, 0x08
000074fc119db4fc  jmp 0x000074FC119D664A
000074fc119db501  sub rsp, 0x08
000074fc119db505  push rax
000074fc119db506  push rcx
000074fc119db507  push rdx
000074fc119db508  push rdi
000074fc119db509  push rsi
000074fc119db50a  push r8
000074fc119db50c  push r9
000074fc119db50e  push r10
000074fc119db510  push r11
000074fc119db512  sub rsp, 0xF0
000074fc119db519  vmovaps [rsp], xmm0
000074fc119db51e  vmovaps [rsp+0x10], xmm1
000074fc119db524  vmovaps [rsp+0x20], xmm2
000074fc119db52a  vmovaps [rsp+0x30], xmm3
000074fc119db530  vmovaps [rsp+0x40], xmm4
000074fc119db536  vmovaps [rsp+0x50], xmm5
000074fc119db53c  vmovaps [rsp+0x60], xmm6
000074fc119db542  vmovaps [rsp+0x70], xmm7
000074fc119db548  vmovaps [rsp+0x80], xmm8
000074fc119db551  vmovaps [rsp+0x90], xmm9
000074fc119db55a  vmovaps [rsp+0xA0], xmm10
000074fc119db563  vmovaps [rsp+0xB0], xmm11
000074fc119db56c  vmovaps [rsp+0xC0], xmm12
000074fc119db575  vmovaps [rsp+0xD0], xmm14
000074fc119db57e  vmovaps [rsp+0xE0], xmm15
000074fc119db587  sub rsp, 0x30
000074fc119db58b  movaps [rsp], xmm13
000074fc119db590  movaps [rsp+0x10], xmm10
000074fc119db596  movaps [rsp+0x20], xmm14
000074fc119db59c  lea rdi, [rsp]
000074fc119db5a0  mov esi, 0x00
000074fc119db5a5  mov rax, 0x58C4C8091530
000074fc119db5af  call rax
000074fc119db5b1  movaps xmm13, [rsp]
000074fc119db5b6  add rsp, 0x30
000074fc119db5ba  vmovaps xmm0, [rsp]
000074fc119db5bf  vmovaps xmm1, [rsp+0x10]
000074fc119db5c5  vmovaps xmm2, [rsp+0x20]
000074fc119db5cb  vmovaps xmm3, [rsp+0x30]
000074fc119db5d1  vmovaps xmm4, [rsp+0x40]
000074fc119db5d7  vmovaps xmm5, [rsp+0x50]
000074fc119db5dd  vmovaps xmm6, [rsp+0x60]
000074fc119db5e3  vmovaps xmm7, [rsp+0x70]
000074fc119db5e9  vmovaps xmm8, [rsp+0x80]
000074fc119db5f2  vmovaps xmm9, [rsp+0x90]
000074fc119db5fb  vmovaps xmm10, [rsp+0xA0]
000074fc119db604  vmovaps xmm11, [rsp+0xB0]
000074fc119db60d  vmovaps xmm12, [rsp+0xC0]
000074fc119db616  vmovaps xmm14, [rsp+0xD0]
000074fc119db61f  vmovaps xmm15, [rsp+0xE0]
000074fc119db628  add rsp, 0xF0
000074fc119db62f  pop r11
000074fc119db631  pop r10
000074fc119db633  pop r9
000074fc119db635  pop r8
000074fc119db637  pop rsi
000074fc119db638  pop rdi
000074fc119db639  pop rdx
000074fc119db63a  pop rcx
000074fc119db63b  pop rax
000074fc119db63c  add rsp, 0x08
000074fc119db640  jmp 0x000074FC119D666D
000074fc119db645  sub rsp, 0x08
000074fc119db649  push rax
000074fc119db64a  push rcx
000074fc119db64b  push rdx
000074fc119db64c  push rdi
000074fc119db64d  push rsi
000074fc119db64e  push r8
000074fc119db650  push r9
000074fc119db652  push r10
000074fc119db654  push r11
000074fc119db656  sub rsp, 0xF0
000074fc119db65d  vmovaps [rsp], xmm0
000074fc119db662  vmovaps [rsp+0x10], xmm1
000074fc119db668  vmovaps [rsp+0x20], xmm2
000074fc119db66e  vmovaps [rsp+0x30], xmm3
000074fc119db674  vmovaps [rsp+0x40], xmm4
000074fc119db67a  vmovaps [rsp+0x50], xmm5
000074fc119db680  vmovaps [rsp+0x60], xmm6
000074fc119db686  vmovaps [rsp+0x70], xmm7
000074fc119db68c  vmovaps [rsp+0x80], xmm8
000074fc119db695  vmovaps [rsp+0x90], xmm9
000074fc119db69e  vmovaps [rsp+0xA0], xmm10
000074fc119db6a7  vmovaps [rsp+0xB0], xmm11
000074fc119db6b0  vmovaps [rsp+0xC0], xmm12
000074fc119db6b9  vmovaps [rsp+0xD0], xmm13
000074fc119db6c2  vmovaps [rsp+0xE0], xmm15
000074fc119db6cb  sub rsp, 0x30
000074fc119db6cf  movaps [rsp], xmm14
000074fc119db6d4  movaps [rsp+0x10], xmm1
000074fc119db6d9  movaps [rsp+0x20], xmm7
000074fc119db6de  lea rdi, [rsp]
000074fc119db6e2  mov esi, 0x00
000074fc119db6e7  mov rax, 0x58C4C8091530
000074fc119db6f1  call rax
000074fc119db6f3  movaps xmm14, [rsp]
000074fc119db6f8  add rsp, 0x30
000074fc119db6fc  vmovaps xmm0, [rsp]
000074fc119db701  vmovaps xmm1, [rsp+0x10]
000074fc119db707  vmovaps xmm2, [rsp+0x20]
000074fc119db70d  vmovaps xmm3, [rsp+0x30]
000074fc119db713  vmovaps xmm4, [rsp+0x40]
000074fc119db719  vmovaps xmm5, [rsp+0x50]
000074fc119db71f  vmovaps xmm6, [rsp+0x60]
000074fc119db725  vmovaps xmm7, [rsp+0x70]
000074fc119db72b  vmovaps xmm8, [rsp+0x80]
000074fc119db734  vmovaps xmm9, [rsp+0x90]
000074fc119db73d  vmovaps xmm10, [rsp+0xA0]
000074fc119db746  vmovaps xmm11, [rsp+0xB0]
000074fc119db74f  vmovaps xmm12, [rsp+0xC0]
000074fc119db758  vmovaps xmm13, [rsp+0xD0]
000074fc119db761  vmovaps xmm15, [rsp+0xE0]
000074fc119db76a  add rsp, 0xF0
000074fc119db771  pop r11
000074fc119db773  pop r10
000074fc119db775  pop r9
000074fc119db777  pop r8
000074fc119db779  pop rsi
000074fc119db77a  pop rdi
000074fc119db77b  pop rdx
000074fc119db77c  pop rcx
000074fc119db77d  pop rax
000074fc119db77e  add rsp, 0x08
000074fc119db782  jmp 0x000074FC119D6690
000074fc119db787  sub rsp, 0x08
000074fc119db78b  push rax
000074fc119db78c  push rcx
000074fc119db78d  push rdx
000074fc119db78e  push rdi
000074fc119db78f  push rsi
000074fc119db790  push r8
000074fc119db792  push r9
000074fc119db794  push r10
000074fc119db796  push r11
000074fc119db798  sub rsp, 0xF0
000074fc119db79f  vmovaps [rsp], xmm0
000074fc119db7a4  vmovaps [rsp+0x10], xmm2
000074fc119db7aa  vmovaps [rsp+0x20], xmm3
000074fc119db7b0  vmovaps [rsp+0x30], xmm4
000074fc119db7b6  vmovaps [rsp+0x40], xmm5
000074fc119db7bc  vmovaps [rsp+0x50], xmm6
000074fc119db7c2  vmovaps [rsp+0x60], xmm7
000074fc119db7c8  vmovaps [rsp+0x70], xmm8
000074fc119db7ce  vmovaps [rsp+0x80], xmm9
000074fc119db7d7  vmovaps [rsp+0x90], xmm10
000074fc119db7e0  vmovaps [rsp+0xA0], xmm11
000074fc119db7e9  vmovaps [rsp+0xB0], xmm12
000074fc119db7f2  vmovaps [rsp+0xC0], xmm13
000074fc119db7fb  vmovaps [rsp+0xD0], xmm14
000074fc119db804  vmovaps [rsp+0xE0], xmm15
000074fc119db80d  sub rsp, 0x30
000074fc119db811  movaps [rsp], xmm1
000074fc119db815  movaps [rsp+0x10], xmm8
000074fc119db81b  movaps [rsp+0x20], xmm9
000074fc119db821  lea rdi, [rsp]
000074fc119db825  mov esi, 0x00
000074fc119db82a  mov rax, 0x58C4C8091530
000074fc119db834  call rax
000074fc119db836  movaps xmm1, [rsp]
000074fc119db83a  add rsp, 0x30
000074fc119db83e  vmovaps xmm0, [rsp]
000074fc119db843  vmovaps xmm2, [rsp+0x10]
000074fc119db849  vmovaps xmm3, [rsp+0x20]
000074fc119db84f  vmovaps xmm4, [rsp+0x30]
000074fc119db855  vmovaps xmm5, [rsp+0x40]
000074fc119db85b  vmovaps xmm6, [rsp+0x50]
000074fc119db861  vmovaps xmm7, [rsp+0x60]
000074fc119db867  vmovaps xmm8, [rsp+0x70]
000074fc119db86d  vmovaps xmm9, [rsp+0x80]
000074fc119db876  vmovaps xmm10, [rsp+0x90]
000074fc119db87f  vmovaps xmm11, [rsp+0xA0]
000074fc119db888  vmovaps xmm12, [rsp+0xB0]
000074fc119db891  vmovaps xmm13, [rsp+0xC0]
000074fc119db89a  vmovaps xmm14, [rsp+0xD0]
000074fc119db8a3  vmovaps xmm15, [rsp+0xE0]
000074fc119db8ac  add rsp, 0xF0
000074fc119db8b3  pop r11
000074fc119db8b5  pop r10
000074fc119db8b7  pop r9
000074fc119db8b9  pop r8
000074fc119db8bb  pop rsi
000074fc119db8bc  pop rdi
000074fc119db8bd  pop rdx
000074fc119db8be  pop rcx
000074fc119db8bf  pop rax
000074fc119db8c0  add rsp, 0x08
000074fc119db8c4  jmp 0x000074FC119D66B2
000074fc119db8c9  call 0x000074FC118B3E40
000074fc119db8ce  jmp 0x000074FC119D66C0
000074fc119db8d3  call 0x000074FC1180C380
000074fc119db8d8  jmp 0x000074FC119D66CA
000074fc119db8dd  call 0x000074FC1180D600
000074fc119db8e2  jmp 0x000074FC119D66D4
000074fc119db8e7  call 0x000074FC117FF540
000074fc119db8ec  jmp 0x000074FC119D66DE
000074fc119db8f1  int3
000074fc119db8f2  nop [rax+rax*1], ax
000074fc119db8fb  nop [rax+rax*1], eax
000074fc119db900  mov eax, [r15+0x48]
000074fc119db904  lea r14d, [eax+0x01]
000074fc119db909  mov [rsp+0x10], r14d
000074fc119db90e  mov r14d, r14d
000074fc119db911  mov [r15+0x48], r14
000074fc119db915  xor eax, eax
000074fc119db917  mov r14d, [rsp+0x10]
000074fc119db91c  cmp r14d, 0x1F4
000074fc119db923  cmc
000074fc119db924  lahf
000074fc119db925  seto al
000074fc119db928  mov [r15+0x108], eax
000074fc119db92f  mov eax, [r15+0x108]
000074fc119db936  sahf
000074fc119db937  jnz 0x000074FC119DB969
000074fc119db939  cmp dword ptr [r15+0x318], 0x00
000074fc119db941  jz 0x000074FC119E1AB0
000074fc119db947  nop [rax+rax*1], ax
000074fc119db950  nop [rax+rax*1], eax
000074fc119db958  mov eax, 0x410450
000074fc119db95d  mov [r15+0x100], rax
000074fc119db964  jmp 0x000074FC117FE110
000074fc119db969  cmp dword ptr [r15+0x318], 0x00
000074fc119db971  jz 0x000074FC119DB9A0
000074fc119db977  nop [rax+rax*1], ax
000074fc119db980  nop [rax+rax*1], eax
000074fc119db988  mov eax, 0x410274
000074fc119db98d  mov [r15+0x100], rax
000074fc119db994  jmp 0x000074FC117FE110
000074fc119db999  int3
000074fc119db99a  int3
000074fc119db99b  nop [rax+rax*1], eax
000074fc119db9a0  mov rax, [r15+0x40]
000074fc119db9a4  movaps xmm1, [r15+0x1D0]
000074fc119db9ac  vmovaps [rsp+0x10], xmm1
000074fc119db9b2  vmovaps xmm15, [rsp+0x10]
000074fc119db9b8  por xmm1, xmm15
000074fc119db9bd  movaps xmm14, [r15+0x1A0]
000074fc119db9c5  vmovaps [rsp+0x10], xmm14
000074fc119db9cb  vmovaps xmm13, [rsp+0x10]
000074fc119db9d1  por xmm14, xmm13
000074fc119db9d6  lea r14, [rax+0x30]
000074fc119db9da  mov r12, [r13+r14*1]
000074fc119db9df  lea r14, [rax+0x38]
000074fc119db9e3  mov r11, [r13+r14*1]
000074fc119db9e8  movq xmm13, r12
000074fc119db9ed  movq xmm12, r11
000074fc119db9f2  movq xmm13, xmm13
000074fc119db9f7  vmovaps [rsp+0x10], xmm13
000074fc119db9fd  movq xmm13, xmm13
000074fc119dba02  movaps [r15+0x130], xmm13
000074fc119dba0a  movq xmm12, xmm12
000074fc119dba0f  vmovaps [rsp+0x20], xmm12
000074fc119dba15  movq xmm12, xmm12
000074fc119dba1a  movaps [r15+0x280], xmm12
000074fc119dba22  movaps xmm13, [r15+0x270]
000074fc119dba2a  vmovaps [rsp+0x30], xmm13
000074fc119dba30  vmovaps xmm12, [rsp+0x30]
000074fc119dba36  por xmm13, xmm12
000074fc119dba3b  lea r14, [rax+0x20]
000074fc119dba3f  mov r12, [r13+r14*1]
000074fc119dba44  lea r14, [rax+0x28]
000074fc119dba48  mov r11, [r13+r14*1]
000074fc119dba4d  movq xmm12, r12
000074fc119dba52  movq xmm11, r11
000074fc119dba57  movq xmm12, xmm12
000074fc119dba5c  vmovaps [rsp+0x30], xmm12
000074fc119dba62  movq xmm12, xmm12
000074fc119dba67  movaps [r15+0x150], xmm12
000074fc119dba6f  movq xmm11, xmm11
000074fc119dba74  vmovaps [rsp+0x40], xmm11
000074fc119dba7a  movq xmm11, xmm11
000074fc119dba7f  movaps [r15+0x140], xmm11
000074fc119dba87  lea r14, [rax+0x10]
000074fc119dba8b  mov r12, [r13+r14*1]
000074fc119dba90  lea r14, [rax+0x18]
000074fc119dba94  mov r11, [r13+r14*1]
000074fc119dba99  movq xmm12, r12
000074fc119dba9e  movq xmm11, r11
000074fc119dbaa3  movq xmm12, xmm12
000074fc119dbaa8  vmovaps [rsp+0x50], xmm12
000074fc119dbaae  movq xmm12, xmm12
000074fc119dbab3  movaps [r15+0x170], xmm12
000074fc119dbabb  movq xmm11, xmm11
000074fc119dbac0  vmovaps [rsp+0x60], xmm11
000074fc119dbac6  movq xmm11, xmm11
000074fc119dbacb  movaps [r15+0x160], xmm11
000074fc119dbad3  mov r14, [r13+rax*1]
000074fc119dbad8  vmovq xmm12, r14
000074fc119dbadd  vpbroadcastq xmm12, xmm12
000074fc119dbae2  lea r14, [rax+0x08]
000074fc119dbae6  mov rax, [r13+r14*1]
000074fc119dbaeb  movq xmm11, rax
000074fc119dbaf0  movaps [r15+0x230], xmm11
000074fc119dbaf8  mov rax, [r15+0xF8]
000074fc119dbaff  lea r14, [rax+0x50]
000074fc119dbb03  movups xmm11, [r13+r14*1]
000074fc119dbb09  lea r14, [rax+0x60]
000074fc119dbb0d  movups xmm10, [r13+r14*1]
000074fc119dbb13  lea r14, [rax+0x30]
000074fc119dbb17  movups xmm9, [r13+r14*1]
000074fc119dbb1d  mov r14, [r15+0x50]
000074fc119dbb21  mov [r15+0x60], r14
000074fc119dbb25  mov qword ptr [r15+0x58], 0x40
000074fc119dbb2d  movaps xmm8, xmm12
000074fc119dbb31  mulpd xmm8, xmm15
000074fc119dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000074fc119dbb3c  ptest xmm7, xmm7
000074fc119dbb41  jnz 0x000074FC119DC96A
000074fc119dbb47  movq xmm15, qword ptr [r15+0x230]
000074fc119dbb50  vmovaps [rsp+0x70], xmm15
000074fc119dbb56  vpermilpd xmm15, xmm15, 0x00
000074fc119dbb5c  movaps xmm7, xmm9
000074fc119dbb60  mulpd xmm7, xmm15
000074fc119dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000074fc119dbb6a  ptest xmm6, xmm6
000074fc119dbb6f  jnz 0x000074FC119DCAAE
000074fc119dbb75  vxorps xmm15, xmm15, xmm15
000074fc119dbb7a  vpbroadcastq xmm15, xmm15
000074fc119dbb7f  movaps xmm9, xmm12
000074fc119dbb83  mulpd xmm9, xmm10
000074fc119dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000074fc119dbb8e  ptest xmm6, xmm6
000074fc119dbb93  jnz 0x000074FC119DCBF0
000074fc119dbb99  movaps xmm10, xmm12
000074fc119dbb9d  mulpd xmm10, xmm11
000074fc119dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000074fc119dbba8  ptest xmm6, xmm6
000074fc119dbbad  jnz 0x000074FC119DCD34
000074fc119dbbb3  movaps xmm11, [r15+0x1F0]
000074fc119dbbbb  movaps xmm6, xmm12
000074fc119dbbbf  mulpd xmm6, xmm11
000074fc119dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000074fc119dbbc9  ptest xmm5, xmm5
000074fc119dbbce  jnz 0x000074FC119DCE78
000074fc119dbbd4  movaps xmm12, [r15+0x2A0]
000074fc119dbbdc  vmovaps [rsp+0x80], xmm12
000074fc119dbbe5  vmovaps xmm11, [rsp+0x80]
000074fc119dbbee  por xmm12, xmm11
000074fc119dbbf3  movaps xmm11, [r15+0x250]
000074fc119dbbfb  vmovaps [rsp+0x80], xmm11
000074fc119dbc04  vmovaps xmm5, [rsp+0x80]
000074fc119dbc0d  por xmm11, xmm5
000074fc119dbc12  vmovaps xmm4, [rsp+0x70]
000074fc119dbc18  vpermilpd xmm4, xmm4, 0x00
000074fc119dbc1e  movaps xmm3, xmm5
000074fc119dbc21  mulpd xmm3, xmm4
000074fc119dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000074fc119dbc2a  ptest xmm2, xmm2
000074fc119dbc2f  jnz 0x000074FC119DCFBA
000074fc119dbc35  mov [rsp+0x80], rax
000074fc119dbc3d  xor eax, eax
000074fc119dbc3f  mov r12d, 0x40
000074fc119dbc45  mov r11d, 0x200
000074fc119dbc4b  cmp r12, r11
000074fc119dbc4e  cmc
000074fc119dbc4f  lahf
000074fc119dbc50  seto al
000074fc119dbc53  mov [r15+0x108], eax
000074fc119dbc5a  movaps xmm5, xmm8
000074fc119dbc5e  addpd xmm5, xmm15
000074fc119dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000074fc119dbc68  ptest xmm4, xmm4
000074fc119dbc6d  jnz 0x000074FC119DD0FA
000074fc119dbc73  movaps xmm8, [r15+0x1B0]
000074fc119dbc7b  movaps xmm4, xmm9
000074fc119dbc7f  addpd xmm4, xmm8
000074fc119dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000074fc119dbc89  ptest xmm2, xmm2
000074fc119dbc8e  jnz 0x000074FC119DD23C
000074fc119dbc94  movaps xmm9, xmm10
000074fc119dbc98  addpd xmm9, xmm8
000074fc119dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000074fc119dbca3  ptest xmm2, xmm2
000074fc119dbca8  jnz 0x000074FC119DD37E
000074fc119dbcae  movaps xmm10, [r15+0x2F0]
000074fc119dbcb6  vmovaps [rsp+0x90], xmm10
000074fc119dbcbf  vmovaps xmm8, [rsp+0x90]
000074fc119dbcc8  por xmm10, xmm8
000074fc119dbccd  movaps xmm8, [r15+0x2E0]
000074fc119dbcd5  vmovaps [rsp+0x90], xmm8
000074fc119dbcde  vmovaps xmm2, [rsp+0x90]
000074fc119dbce7  por xmm8, xmm2
000074fc119dbcec  movaps xmm2, [r15+0x2D0]
000074fc119dbcf4  vmovaps [rsp+0x90], xmm2
000074fc119dbcfd  vmovaps [rsp+0xA0], xmm1
000074fc119dbd06  vmovaps xmm1, [rsp+0x90]
000074fc119dbd0f  por xmm2, xmm1
000074fc119dbd13  movaps xmm1, [r15+0x200]
000074fc119dbd1b  vmovaps [rsp+0x90], xmm1
000074fc119dbd24  vmovaps [rsp+0xB0], xmm15
000074fc119dbd2d  vmovaps xmm15, [rsp+0x90]
000074fc119dbd36  por xmm1, xmm15
000074fc119dbd3b  movaps xmm15, [r15+0x1C0]
000074fc119dbd43  vmovaps [rsp+0x90], xmm15
000074fc119dbd4c  vmovaps [rsp+0xC0], xmm1
000074fc119dbd55  vmovaps xmm1, [rsp+0x90]
000074fc119dbd5e  por xmm15, xmm1
000074fc119dbd63  movaps xmm1, [r15+0x190]
000074fc119dbd6b  vmovaps [rsp+0x90], xmm1
000074fc119dbd74  vmovaps [rsp+0xD0], xmm15
000074fc119dbd7d  vmovaps xmm15, [rsp+0x90]
000074fc119dbd86  por xmm1, xmm15
000074fc119dbd8b  movaps xmm15, [r15+0x300]
000074fc119dbd93  vmovaps [rsp+0x90], xmm15
000074fc119dbd9c  vmovaps [rsp+0xE0], xmm1
000074fc119dbda5  vmovaps xmm1, [rsp+0x90]
000074fc119dbdae  por xmm15, xmm1
000074fc119dbdb3  mov rax, [rsp+0x80]
000074fc119dbdbb  lea r12, [rax+0xA0]
000074fc119dbdc2  movups xmm1, [r13+r12*1]
000074fc119dbdc8  lea r12, [rax+0xB0]
000074fc119dbdcf  vmovaps [rsp+0x80], xmm1
000074fc119dbdd8  movups xmm1, [r13+r12*1]
000074fc119dbdde  vmovaps [rsp+0x90], xmm1
000074fc119dbde7  vmovaps [rsp+0xF0], xmm15
000074fc119dbdf0  vmovaps xmm15, [rsp+0xB0]
000074fc119dbdf9  vmovaps [rsp+0xB0], xmm14
000074fc119dbe02  movaps xmm1, xmm6
000074fc119dbe05  addpd xmm1, xmm15
000074fc119dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000074fc119dbe0f  ptest xmm14, xmm14
000074fc119dbe15  jnz 0x000074FC119DD4D6
000074fc119dbe1b  lea r12, [rax+0xF0]
000074fc119dbe22  movups xmm15, [r13+r12*1]
000074fc119dbe28  movaps xmm14, xmm4
000074fc119dbe2c  addpd xmm14, xmm3
000074fc119dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000074fc119dbe37  ptest xmm6, xmm6
000074fc119dbe3c  jnz 0x000074FC119DD621
000074fc119dbe42  movaps xmm6, xmm9
000074fc119dbe46  addpd xmm6, xmm7
000074fc119dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000074fc119dbe4f  ptest xmm4, xmm4
000074fc119dbe54  jnz 0x000074FC119DD763
000074fc119dbe5a  vmovaps xmm9, [rsp+0x70]
000074fc119dbe60  vpermilpd xmm9, xmm9, 0x00
000074fc119dbe66  vmovaps xmm4, [rsp+0x90]
000074fc119dbe6f  movaps xmm7, xmm4
000074fc119dbe72  mulpd xmm7, xmm9
000074fc119dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000074fc119dbe7c  ptest xmm3, xmm3
000074fc119dbe81  jnz 0x000074FC119DD8A4
000074fc119dbe87  vmovaps xmm9, [rsp+0x50]
000074fc119dbe8d  vpermilpd xmm9, xmm9, 0x00
000074fc119dbe93  movaps xmm4, xmm15
000074fc119dbe97  mulpd xmm4, xmm9
000074fc119dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000074fc119dbea1  ptest xmm3, xmm3
000074fc119dbea6  jnz 0x000074FC119DD9E5
000074fc119dbeac  lea r12, [rax+0xE0]
000074fc119dbeb3  movups xmm15, [r13+r12*1]
000074fc119dbeb9  vmovaps xmm9, [rsp+0x70]
000074fc119dbebf  vpermilpd xmm9, xmm9, 0x00
000074fc119dbec5  vmovaps [rsp+0x70], xmm1
000074fc119dbecb  vmovaps xmm1, [rsp+0x80]
000074fc119dbed4  vmovaps [rsp+0x80], xmm15
000074fc119dbedd  movaps xmm3, xmm1
000074fc119dbee0  mulpd xmm3, xmm9
000074fc119dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000074fc119dbeea  ptest xmm15, xmm15
000074fc119dbef0  jnz 0x000074FC119DDB31
000074fc119dbef6  vmovaps xmm1, [rsp+0xF0]
000074fc119dbeff  vmovaps xmm15, [rsp+0xF0]
000074fc119dbf08  por xmm1, xmm15
000074fc119dbf0d  movaps [r15+0x300], xmm1
000074fc119dbf15  vmovaps xmm15, [rsp+0xE0]
000074fc119dbf1e  vmovaps xmm9, [rsp+0xE0]
000074fc119dbf27  por xmm15, xmm9
000074fc119dbf2c  movaps [r15+0x190], xmm15
000074fc119dbf34  vmovaps xmm9, [rsp+0x50]
000074fc119dbf3a  vpermilpd xmm9, xmm9, 0x00
000074fc119dbf40  vmovaps [rsp+0x90], xmm1
000074fc119dbf49  vmovaps [rsp+0xE0], xmm15
000074fc119dbf52  vmovaps xmm15, [rsp+0x80]
000074fc119dbf5b  vmovaps [rsp+0x80], xmm14
000074fc119dbf64  movaps xmm1, xmm15
000074fc119dbf68  mulpd xmm1, xmm9
000074fc119dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000074fc119dbf72  ptest xmm14, xmm14
000074fc119dbf78  jnz 0x000074FC119DDC72
000074fc119dbf7e  lea r12, [rax+0x90]
000074fc119dbf85  movups xmm15, [r13+r12*1]
000074fc119dbf8b  vmovaps xmm14, [rsp+0xD0]
000074fc119dbf94  vmovaps xmm9, [rsp+0xD0]
000074fc119dbf9d  por xmm14, xmm9
000074fc119dbfa2  movaps [r15+0x1C0], xmm14
000074fc119dbfaa  vmovaps xmm9, [rsp+0xC0]
000074fc119dbfb3  vmovaps [rsp+0xD0], xmm1
000074fc119dbfbc  vmovaps xmm1, [rsp+0xC0]
000074fc119dbfc5  por xmm9, xmm1
000074fc119dbfca  movaps [r15+0x200], xmm9
000074fc119dbfd2  vmovaps [rsp+0xC0], xmm2
000074fc119dbfdb  vmovaps xmm1, [rsp+0xC0]
000074fc119dbfe4  por xmm2, xmm1
000074fc119dbfe8  movaps [r15+0x2D0], xmm2
000074fc119dbff0  vmovaps [rsp+0xC0], xmm8
000074fc119dbff9  vmovaps xmm1, [rsp+0xC0]
000074fc119dc002  por xmm8, xmm1
000074fc119dc007  movaps [r15+0x2E0], xmm8
000074fc119dc00f  vmovaps [rsp+0xC0], xmm15
000074fc119dc018  movaps xmm1, xmm5
000074fc119dc01b  addpd xmm1, xmm7
000074fc119dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000074fc119dc024  ptest xmm15, xmm15
000074fc119dc02a  jnz 0x000074FC119DDDBE
000074fc119dc030  vmovaps xmm15, [rsp+0x50]
000074fc119dc036  vpermilpd xmm15, xmm15, 0x00
000074fc119dc03c  vmovaps xmm5, [rsp+0xC0]
000074fc119dc045  vmovaps [rsp+0xC0], xmm1
000074fc119dc04e  movaps xmm7, xmm5
000074fc119dc051  mulpd xmm7, xmm15
000074fc119dc056  vcmppd xmm1, xmm7, xmm7, 0x03
000074fc119dc05b  ptest xmm1, xmm1
000074fc119dc060  jnz 0x000074FC119DDEFE
000074fc119dc066  lea r12, [rax+0x80]
000074fc119dc06d  movups xmm1, [r13+r12*1]
000074fc119dc073  vmovaps xmm5, [rsp+0x70]
000074fc119dc079  vmovaps [rsp+0x70], xmm1
000074fc119dc07f  movaps xmm15, xmm5
000074fc119dc083  addpd xmm15, xmm3
000074fc119dc088  vcmppd xmm1, xmm15, xmm15, 0x03
000074fc119dc08e  ptest xmm1, xmm1
000074fc119dc093  jnz 0x000074FC119DE049
000074fc119dc099  vmovaps xmm5, [rsp+0x80]
000074fc119dc0a2  movaps xmm1, xmm5
000074fc119dc0a5  addpd xmm1, xmm4
000074fc119dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000074fc119dc0ae  ptest xmm3, xmm3
000074fc119dc0b3  jnz 0x000074FC119DE18B
000074fc119dc0b9  vmovaps [rsp+0x80], xmm10
000074fc119dc0c2  vmovaps xmm5, [rsp+0x80]
000074fc119dc0cb  por xmm10, xmm5
000074fc119dc0d0  movaps [r15+0x2F0], xmm10
000074fc119dc0d8  vmovaps xmm5, [rsp+0x50]
000074fc119dc0de  vpermilpd xmm5, xmm5, 0x00
000074fc119dc0e4  vmovaps xmm3, [rsp+0x70]
000074fc119dc0ea  vmovaps [rsp+0x50], xmm1
000074fc119dc0f0  movaps xmm4, xmm3
000074fc119dc0f3  mulpd xmm4, xmm5
000074fc119dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000074fc119dc0fc  ptest xmm1, xmm1
000074fc119dc101  jnz 0x000074FC119DE2CB
000074fc119dc107  lea r12, [rax+0xD0]
000074fc119dc10e  movups xmm1, [r13+r12*1]
000074fc119dc114  vmovaps xmm3, [rsp+0xD0]
000074fc119dc11d  vmovaps [rsp+0x70], xmm1
000074fc119dc123  movaps xmm5, xmm6
000074fc119dc126  addpd xmm5, xmm3
000074fc119dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000074fc119dc12f  ptest xmm1, xmm1
000074fc119dc134  jnz 0x000074FC119DE415
000074fc119dc13a  vmovaps xmm1, [rsp+0x60]
000074fc119dc140  vpermilpd xmm1, xmm1, 0x00
000074fc119dc146  movaps xmm6, xmm9
000074fc119dc14a  mulpd xmm6, xmm1
000074fc119dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000074fc119dc153  ptest xmm3, xmm3
000074fc119dc158  jnz 0x000074FC119DE555
000074fc119dc15e  movaps [r15+0x260], xmm6
000074fc119dc166  vxorps xmm1, xmm1, xmm1
000074fc119dc16a  vpbroadcastq xmm1, xmm1
000074fc119dc16f  movaps [r15+0x1B0], xmm1
000074fc119dc177  vmovaps xmm1, [rsp+0x60]
000074fc119dc17d  vpermilpd xmm1, xmm1, 0x00
000074fc119dc183  vmovaps xmm3, [rsp+0x70]
000074fc119dc189  vmovaps [rsp+0x70], xmm15
000074fc119dc18f  movaps xmm9, xmm3
000074fc119dc193  mulpd xmm9, xmm1
000074fc119dc198  vcmppd xmm15, xmm9, xmm9, 0x03
000074fc119dc19e  ptest xmm15, xmm15
000074fc119dc1a4  jnz 0x000074FC119DE696
000074fc119dc1aa  lea r12, [rax+0xC0]
000074fc119dc1b1  movups xmm1, [r13+r12*1]
000074fc119dc1b7  vmovaps xmm3, [rsp+0xC0]
000074fc119dc1c0  vmovaps [rsp+0x80], xmm1
000074fc119dc1c9  movaps xmm15, xmm3
000074fc119dc1cd  addpd xmm15, xmm7
000074fc119dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000074fc119dc1d8  ptest xmm1, xmm1
000074fc119dc1dd  jnz 0x000074FC119DE7E2
000074fc119dc1e3  vmovaps [rsp+0xC0], xmm13
000074fc119dc1ec  vmovaps xmm1, [rsp+0xC0]
000074fc119dc1f5  por xmm13, xmm1
000074fc119dc1fa  movaps [r15+0x270], xmm13
000074fc119dc202  vmovaps xmm1, [rsp+0xB0]
000074fc119dc20b  vmovaps xmm7, [rsp+0xB0]
000074fc119dc214  por xmm1, xmm7
000074fc119dc218  movaps [r15+0x1A0], xmm1
000074fc119dc220  vmovaps xmm1, [rsp+0x60]
000074fc119dc226  vpermilpd xmm1, xmm1, 0x00
000074fc119dc22c  vmovaps [rsp+0xB0], xmm1
000074fc119dc235  vmovaps xmm1, [rsp+0x80]
000074fc119dc23e  vmovaps [rsp+0x80], xmm15
000074fc119dc247  vmovaps xmm15, [rsp+0xB0]
000074fc119dc250  vmovaps [rsp+0xB0], xmm14
000074fc119dc259  movaps xmm3, xmm1
000074fc119dc25c  mulpd xmm3, xmm15
000074fc119dc261  vcmppd xmm14, xmm3, xmm3, 0x03
000074fc119dc266  ptest xmm14, xmm14
000074fc119dc26c  jnz 0x000074FC119DE924
000074fc119dc272  lea r12, [rax+0x20]
000074fc119dc276  movups xmm1, [r13+r12*1]
000074fc119dc27c  movaps [r15+0x110], xmm1
000074fc119dc284  vmovaps xmm14, [rsp+0x70]
000074fc119dc28a  vmovaps [rsp+0x70], xmm1
000074fc119dc290  movaps xmm15, xmm14
000074fc119dc294  addpd xmm15, xmm4
000074fc119dc299  vcmppd xmm1, xmm15, xmm15, 0x03
000074fc119dc29f  ptest xmm1, xmm1
000074fc119dc2a4  jnz 0x000074FC119DEA6F
000074fc119dc2aa  vmovaps xmm1, [rsp+0x60]
000074fc119dc2b0  vpermilpd xmm1, xmm1, 0x00
000074fc119dc2b6  movaps xmm14, xmm2
000074fc119dc2ba  mulpd xmm14, xmm1
000074fc119dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000074fc119dc2c5  ptest xmm4, xmm4
000074fc119dc2ca  jnz 0x000074FC119DEBB2
000074fc119dc2d0  vmovaps xmm4, [rsp+0x50]
000074fc119dc2d6  movaps xmm1, xmm4
000074fc119dc2d9  addpd xmm1, xmm9
000074fc119dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000074fc119dc2e3  ptest xmm2, xmm2
000074fc119dc2e8  jnz 0x000074FC119DECF4
000074fc119dc2ee  vmovaps xmm9, [rsp+0x30]
000074fc119dc2f4  vpermilpd xmm9, xmm9, 0x00
000074fc119dc2fa  vmovaps xmm2, [rsp+0x70]
000074fc119dc300  vmovaps [rsp+0x50], xmm1
000074fc119dc306  movaps xmm4, xmm2
000074fc119dc309  mulpd xmm4, xmm9
000074fc119dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000074fc119dc313  ptest xmm1, xmm1
000074fc119dc318  jnz 0x000074FC119DEE35
000074fc119dc31e  vmovaps xmm1, [rsp+0x30]
000074fc119dc324  vpermilpd xmm1, xmm1, 0x00
000074fc119dc32a  vmovaps xmm2, [rsp+0x90]
000074fc119dc333  vmovaps [rsp+0x60], xmm15
000074fc119dc339  movaps xmm9, xmm2
000074fc119dc33d  mulpd xmm9, xmm1
000074fc119dc342  vcmppd xmm15, xmm9, xmm9, 0x03
000074fc119dc348  ptest xmm15, xmm15
000074fc119dc34e  jnz 0x000074FC119DEF76
000074fc119dc354  vmovaps xmm15, [rsp+0x80]
000074fc119dc35d  movaps xmm1, xmm15
000074fc119dc361  addpd xmm1, xmm6
000074fc119dc365  vcmppd xmm2, xmm1, xmm1, 0x03
000074fc119dc36a  ptest xmm2, xmm2
000074fc119dc36f  jnz 0x000074FC119DF0B8
000074fc119dc375  movaps xmm15, xmm5
000074fc119dc379  addpd xmm15, xmm3
000074fc119dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000074fc119dc384  ptest xmm6, xmm6
000074fc119dc389  jnz 0x000074FC119DF1F9
000074fc119dc38f  vmovaps xmm6, [rsp+0x30]
000074fc119dc395  vpermilpd xmm6, xmm6, 0x00
000074fc119dc39b  movaps xmm5, xmm8
000074fc119dc39f  mulpd xmm5, xmm6
000074fc119dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000074fc119dc3a8  ptest xmm3, xmm3
000074fc119dc3ad  jnz 0x000074FC119DF33B
000074fc119dc3b3  vmovaps xmm8, [rsp+0x30]
000074fc119dc3b9  vpermilpd xmm8, xmm8, 0x00
000074fc119dc3bf  movaps xmm6, xmm10
000074fc119dc3c3  mulpd xmm6, xmm8
000074fc119dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000074fc119dc3cd  ptest xmm3, xmm3
000074fc119dc3d2  jnz 0x000074FC119DF47C
000074fc119dc3d8  vmovaps xmm8, [rsp+0x60]
000074fc119dc3de  movaps xmm10, xmm8
000074fc119dc3e2  addpd xmm10, xmm14
000074fc119dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000074fc119dc3ed  ptest xmm3, xmm3
000074fc119dc3f2  jnz 0x000074FC119DF5BE
000074fc119dc3f8  vmovaps xmm8, [rsp+0x50]
000074fc119dc3fe  movaps xmm14, xmm8
000074fc119dc402  addpd xmm14, xmm4
000074fc119dc407  vcmppd xmm3, xmm14, xmm14, 0x03
000074fc119dc40d  ptest xmm3, xmm3
000074fc119dc412  jnz 0x000074FC119DF702
000074fc119dc418  vmovaps xmm8, [rsp+0x40]
000074fc119dc41e  vpermilpd xmm8, xmm8, 0x00
000074fc119dc424  movaps xmm4, xmm13
000074fc119dc428  mulpd xmm4, xmm8
000074fc119dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000074fc119dc432  ptest xmm3, xmm3
000074fc119dc437  jnz 0x000074FC119DF845
000074fc119dc43d  movaps xmm13, xmm15
000074fc119dc441  addpd xmm13, xmm9
000074fc119dc446  vcmppd xmm8, xmm13, xmm13, 0x03
000074fc119dc44c  ptest xmm8, xmm8
000074fc119dc452  jnz 0x000074FC119DF987
000074fc119dc458  movaps xmm15, xmm1
000074fc119dc45c  addpd xmm15, xmm5
000074fc119dc461  vcmppd xmm9, xmm15, xmm15, 0x03
000074fc119dc467  ptest xmm9, xmm9
000074fc119dc46d  jnz 0x000074FC119DFACB
000074fc119dc473  vmovaps [rsp+0x30], xmm11
000074fc119dc479  vmovaps xmm1, [rsp+0x30]
000074fc119dc47f  por xmm11, xmm1
000074fc119dc484  movaps [r15+0x250], xmm11
000074fc119dc48c  vmovaps [rsp+0x30], xmm12
000074fc119dc492  vmovaps xmm1, [rsp+0x30]
000074fc119dc498  por xmm12, xmm1
000074fc119dc49d  movaps [r15+0x2A0], xmm12
000074fc119dc4a5  vmovaps xmm1, [rsp+0xA0]
000074fc119dc4ae  vmovaps xmm11, [rsp+0xA0]
000074fc119dc4b7  por xmm1, xmm11
000074fc119dc4bc  movaps [r15+0x1D0], xmm1
000074fc119dc4c4  lea r12, [rax+0x40]
000074fc119dc4c8  movups xmm1, [r13+r12*1]
000074fc119dc4ce  movaps [r15+0x2C0], xmm1
000074fc119dc4d6  vmovaps xmm11, [rsp+0x40]
000074fc119dc4dc  vpermilpd xmm11, xmm11, 0x00
000074fc119dc4e2  vmovaps xmm8, [rsp+0xE0]
000074fc119dc4eb  movaps xmm9, xmm8
000074fc119dc4ef  mulpd xmm9, xmm11
000074fc119dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000074fc119dc4fa  ptest xmm5, xmm5
000074fc119dc4ff  jnz 0x000074FC119DFC17
000074fc119dc505  movaps xmm11, xmm10
000074fc119dc509  addpd xmm11, xmm6
000074fc119dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000074fc119dc514  ptest xmm8, xmm8
000074fc119dc51a  jnz 0x000074FC119DFD5B
000074fc119dc520  movaps xmm10, xmm14
000074fc119dc524  addpd xmm10, xmm4
000074fc119dc529  vcmppd xmm8, xmm10, xmm10, 0x03
000074fc119dc52f  ptest xmm8, xmm8
000074fc119dc535  jnz 0x000074FC119DFE9E
000074fc119dc53b  vmovaps xmm14, [rsp+0x40]
000074fc119dc541  vpermilpd xmm14, xmm14, 0x00
000074fc119dc547  movaps xmm8, xmm1
000074fc119dc54b  mulpd xmm8, xmm14
000074fc119dc550  vcmppd xmm6, xmm8, xmm8, 0x03
000074fc119dc556  ptest xmm6, xmm6
000074fc119dc55b  jnz 0x000074FC119DFFE1
000074fc119dc561  movaps xmm1, [r15+0x2B0]
000074fc119dc569  vmovaps xmm14, [rsp+0x40]
000074fc119dc56f  vpermilpd xmm14, xmm14, 0x00
000074fc119dc575  movaps xmm6, xmm1
000074fc119dc578  mulpd xmm6, xmm14
000074fc119dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000074fc119dc582  ptest xmm5, xmm5
000074fc119dc587  jnz 0x000074FC119E0124
000074fc119dc58d  vmovaps xmm1, [rsp+0x10]
000074fc119dc593  vpermilpd xmm1, xmm1, 0x00
000074fc119dc599  movaps xmm14, xmm12
000074fc119dc59d  mulpd xmm14, xmm1
000074fc119dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000074fc119dc5a8  ptest xmm5, xmm5
000074fc119dc5ad  jnz 0x000074FC119E0265
000074fc119dc5b3  movaps xmm1, xmm13
000074fc119dc5b7  addpd xmm1, xmm9
000074fc119dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000074fc119dc5c1  ptest xmm12, xmm12
000074fc119dc5c7  jnz 0x000074FC119E03A8
000074fc119dc5cd  vmovaps xmm13, [rsp+0x10]
000074fc119dc5d3  vpermilpd xmm13, xmm13, 0x00
000074fc119dc5d9  movaps xmm12, xmm7
000074fc119dc5dd  mulpd xmm12, xmm13
000074fc119dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000074fc119dc5e8  ptest xmm9, xmm9
000074fc119dc5ee  jnz 0x000074FC119E04EA
000074fc119dc5f4  movaps xmm13, xmm15
000074fc119dc5f8  addpd xmm13, xmm8
000074fc119dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000074fc119dc603  ptest xmm9, xmm9
000074fc119dc609  jnz 0x000074FC119E062D
000074fc119dc60f  movaps xmm15, [r15+0x290]
000074fc119dc617  vmovaps xmm9, [rsp+0x10]
000074fc119dc61d  vpermilpd xmm9, xmm9, 0x00
000074fc119dc623  movaps xmm8, xmm15
000074fc119dc627  mulpd xmm8, xmm9
000074fc119dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000074fc119dc632  ptest xmm7, xmm7
000074fc119dc637  jnz 0x000074FC119E0771
000074fc119dc63d  movaps xmm15, xmm11
000074fc119dc641  addpd xmm15, xmm6
000074fc119dc646  vcmppd xmm9, xmm15, xmm15, 0x03
000074fc119dc64c  ptest xmm9, xmm9
000074fc119dc652  jnz 0x000074FC119E08B5
000074fc119dc658  movaps xmm11, [r15+0x1E0]
000074fc119dc660  vmovaps xmm9, [rsp+0x10]
000074fc119dc666  vpermilpd xmm9, xmm9, 0x00
000074fc119dc66c  movaps xmm7, xmm11
000074fc119dc670  mulpd xmm7, xmm9
000074fc119dc675  vcmppd xmm6, xmm7, xmm7, 0x03
000074fc119dc67a  ptest xmm6, xmm6
000074fc119dc67f  jnz 0x000074FC119E09F8
000074fc119dc685  movaps xmm11, xmm10
000074fc119dc689  addpd xmm11, xmm14
000074fc119dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000074fc119dc694  ptest xmm9, xmm9
000074fc119dc69a  jnz 0x000074FC119E0B3A
000074fc119dc6a0  lea r12, [rax+0x70]
000074fc119dc6a4  movups xmm14, [r13+r12*1]
000074fc119dc6aa  movaps [r15+0x240], xmm14
000074fc119dc6b2  movaps xmm10, xmm1
000074fc119dc6b6  addpd xmm10, xmm12
000074fc119dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000074fc119dc6c1  ptest xmm9, xmm9
000074fc119dc6c7  jnz 0x000074FC119E0C88
000074fc119dc6cd  movaps [r15+0x170], xmm10
000074fc119dc6d5  vmovaps xmm1, [rsp+0x20]
000074fc119dc6db  vpermilpd xmm1, xmm1, 0x00
000074fc119dc6e1  movaps xmm12, xmm14
000074fc119dc6e5  mulpd xmm12, xmm1
000074fc119dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000074fc119dc6f0  ptest xmm9, xmm9
000074fc119dc6f6  jnz 0x000074FC119E0DCB
000074fc119dc6fc  vmovaps xmm1, [rsp+0x20]
000074fc119dc702  vpermilpd xmm1, xmm1, 0x00
000074fc119dc708  vmovaps xmm9, [rsp+0xB0]
000074fc119dc711  movaps xmm14, xmm9
000074fc119dc715  mulpd xmm14, xmm1
000074fc119dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000074fc119dc720  ptest xmm6, xmm6
000074fc119dc725  jnz 0x000074FC119E0F0E
000074fc119dc72b  movaps [r15+0x180], xmm14
000074fc119dc733  movaps xmm1, xmm13
000074fc119dc737  addpd xmm1, xmm8
000074fc119dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000074fc119dc741  ptest xmm9, xmm9
000074fc119dc747  jnz 0x000074FC119E1051
000074fc119dc74d  movaps [r15+0x210], xmm1
000074fc119dc755  movups xmm13, [r13+rax*1]
000074fc119dc75b  lea r12, [rax+0x10]
000074fc119dc75f  movups xmm9, [r13+r12*1]
000074fc119dc765  movaps [r15+0x230], xmm9
000074fc119dc76d  movaps xmm8, xmm15
000074fc119dc771  addpd xmm8, xmm7
000074fc119dc776  vcmppd xmm6, xmm8, xmm8, 0x03
000074fc119dc77c  ptest xmm6, xmm6
000074fc119dc781  jnz 0x000074FC119E11A7
000074fc119dc787  movaps [r15+0x130], xmm8
000074fc119dc78f  vmovaps xmm15, [rsp+0x20]
000074fc119dc795  vpermilpd xmm15, xmm15, 0x00
000074fc119dc79b  movaps xmm7, xmm9
000074fc119dc79f  mulpd xmm7, xmm15
000074fc119dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000074fc119dc7a9  ptest xmm6, xmm6
000074fc119dc7ae  jnz 0x000074FC119E12EA
000074fc119dc7b4  movaps [r15+0x220], xmm7
000074fc119dc7bc  vmovaps xmm15, [rsp+0x20]
000074fc119dc7c2  vpermilpd xmm15, xmm15, 0x00
000074fc119dc7c8  movaps xmm9, xmm13
000074fc119dc7cc  mulpd xmm9, xmm15
000074fc119dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000074fc119dc7d7  ptest xmm6, xmm6
000074fc119dc7dc  jnz 0x000074FC119E142C
000074fc119dc7e2  movaps xmm15, xmm11
000074fc119dc7e6  addpd xmm15, xmm12
000074fc119dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000074fc119dc7f1  ptest xmm13, xmm13
000074fc119dc7f7  jnz 0x000074FC119E1570
000074fc119dc7fd  movaps [r15+0x140], xmm15
000074fc119dc805  movaps xmm13, xmm10
000074fc119dc809  addpd xmm13, xmm14
000074fc119dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000074fc119dc814  ptest xmm12, xmm12
000074fc119dc81a  jnz 0x000074FC119E16B4
000074fc119dc820  movaps [r15+0x150], xmm13
000074fc119dc828  movaps xmm14, xmm1
000074fc119dc82c  addpd xmm14, xmm7
000074fc119dc831  vcmppd xmm12, xmm14, xmm14, 0x03
000074fc119dc837  ptest xmm12, xmm12
000074fc119dc83d  jnz 0x000074FC119E17F8
000074fc119dc843  movaps [r15+0x160], xmm14
000074fc119dc84b  movaps xmm1, xmm8
000074fc119dc84f  addpd xmm1, xmm9
000074fc119dc854  vcmppd xmm12, xmm1, xmm1, 0x03
000074fc119dc859  ptest xmm12, xmm12
000074fc119dc85f  jnz 0x000074FC119E193A
000074fc119dc865  movaps [r15+0x120], xmm1
000074fc119dc86d  movups [r13+r14*1], xmm15
000074fc119dc873  lea rax, [r14+0x10]
000074fc119dc877  movups [r13+rax*1], xmm13
000074fc119dc87d  lea rax, [r14+0x20]
000074fc119dc881  movups [r13+rax*1], xmm14
000074fc119dc887  lea rax, [r14+0x30]
000074fc119dc88b  movups [r13+rax*1], xmm1
000074fc119dc891  mov eax, [r15+0x108]
000074fc119dc898  sahf
000074fc119dc899  jnz 0x000074FC119DC8CB
000074fc119dc89b  cmp dword ptr [r15+0x318], 0x00
000074fc119dc8a3  jz 0x000074FC119DB900
000074fc119dc8a9  nop [rax+rax*1], ax
000074fc119dc8b2  nop [rax+rax*1], eax
000074fc119dc8ba  mov eax, 0x410444
000074fc119dc8bf  mov [r15+0x100], rax
000074fc119dc8c6  jmp 0x000074FC117FE110
000074fc119dc8cb  cmp dword ptr [r15+0x318], 0x00
000074fc119dc8d3  jz 0x000074FC119D57E0
000074fc119dc8d9  nop [rax+rax*1], ax
000074fc119dc8e2  nop [rax+rax*1], eax
000074fc119dc8ea  mov eax, 0x410278
000074fc119dc8ef  mov [r15+0x100], rax
000074fc119dc8f6  jmp 0x000074FC117FE110
000074fc119dc8fb  int3
000074fc119dc8fc  call 0x000074FC118E27E0
000074fc119dc901  jmp 0x000074FC119DB9DF
000074fc119dc906  call 0x000074FC118E1570
000074fc119dc90b  jmp 0x000074FC119DB9E8
000074fc119dc910  call 0x000074FC118E27E0
000074fc119dc915  jmp 0x000074FC119DBA44
000074fc119dc91a  call 0x000074FC118E1570
000074fc119dc91f  jmp 0x000074FC119DBA4D
000074fc119dc924  call 0x000074FC118E27E0
000074fc119dc929  jmp 0x000074FC119DBA90
000074fc119dc92e  call 0x000074FC118E1570
000074fc119dc933  jmp 0x000074FC119DBA99
000074fc119dc938  call 0x000074FC1180DC20
000074fc119dc93d  jmp 0x000074FC119DBAD8
000074fc119dc942  call 0x000074FC118D59C0
000074fc119dc947  jmp 0x000074FC119DBAEB
000074fc119dc94c  call 0x000074FC118E0E30
000074fc119dc951  jmp 0x000074FC119DBB09
000074fc119dc956  call 0x000074FC118DFBC0
000074fc119dc95b  jmp 0x000074FC119DBB13
000074fc119dc960  call 0x000074FC118DE950
000074fc119dc965  jmp 0x000074FC119DBB1D
000074fc119dc96a  sub rsp, 0x08
000074fc119dc96e  push rax
000074fc119dc96f  push rcx
000074fc119dc970  push rdx
000074fc119dc971  push rdi
000074fc119dc972  push rsi
000074fc119dc973  push r8
000074fc119dc975  push r9
000074fc119dc977  push r10
000074fc119dc979  push r11
000074fc119dc97b  sub rsp, 0xF0
000074fc119dc982  vmovaps [rsp], xmm0
000074fc119dc987  vmovaps [rsp+0x10], xmm1
000074fc119dc98d  vmovaps [rsp+0x20], xmm2
000074fc119dc993  vmovaps [rsp+0x30], xmm3
000074fc119dc999  vmovaps [rsp+0x40], xmm4
000074fc119dc99f  vmovaps [rsp+0x50], xmm5
000074fc119dc9a5  vmovaps [rsp+0x60], xmm6
000074fc119dc9ab  vmovaps [rsp+0x70], xmm7
000074fc119dc9b1  vmovaps [rsp+0x80], xmm9
000074fc119dc9ba  vmovaps [rsp+0x90], xmm10
000074fc119dc9c3  vmovaps [rsp+0xA0], xmm11
000074fc119dc9cc  vmovaps [rsp+0xB0], xmm12
000074fc119dc9d5  vmovaps [rsp+0xC0], xmm13
000074fc119dc9de  vmovaps [rsp+0xD0], xmm14
000074fc119dc9e7  vmovaps [rsp+0xE0], xmm15
000074fc119dc9f0  sub rsp, 0x30
000074fc119dc9f4  movaps [rsp], xmm8
000074fc119dc9f9  movaps [rsp+0x10], xmm12
000074fc119dc9ff  movaps [rsp+0x20], xmm15
000074fc119dca05  lea rdi, [rsp]
000074fc119dca09  mov esi, 0x00
000074fc119dca0e  mov rax, 0x58C4C8091530
000074fc119dca18  call rax
000074fc119dca1a  movaps xmm8, [rsp]
000074fc119dca1f  add rsp, 0x30
000074fc119dca23  vmovaps xmm0, [rsp]
000074fc119dca28  vmovaps xmm1, [rsp+0x10]
000074fc119dca2e  vmovaps xmm2, [rsp+0x20]
000074fc119dca34  vmovaps xmm3, [rsp+0x30]
000074fc119dca3a  vmovaps xmm4, [rsp+0x40]
000074fc119dca40  vmovaps xmm5, [rsp+0x50]
000074fc119dca46  vmovaps xmm6, [rsp+0x60]
000074fc119dca4c  vmovaps xmm7, [rsp+0x70]
000074fc119dca52  vmovaps xmm9, [rsp+0x80]
000074fc119dca5b  vmovaps xmm10, [rsp+0x90]
000074fc119dca64  vmovaps xmm11, [rsp+0xA0]
000074fc119dca6d  vmovaps xmm12, [rsp+0xB0]
000074fc119dca76  vmovaps xmm13, [rsp+0xC0]
000074fc119dca7f  vmovaps xmm14, [rsp+0xD0]
000074fc119dca88  vmovaps xmm15, [rsp+0xE0]
000074fc119dca91  add rsp, 0xF0
000074fc119dca98  pop r11
000074fc119dca9a  pop r10
000074fc119dca9c  pop r9
000074fc119dca9e  pop r8
000074fc119dcaa0  pop rsi
000074fc119dcaa1  pop rdi
000074fc119dcaa2  pop rdx
000074fc119dcaa3  pop rcx
000074fc119dcaa4  pop rax
000074fc119dcaa5  add rsp, 0x08
000074fc119dcaa9  jmp 0x000074FC119DBB47
000074fc119dcaae  sub rsp, 0x08
000074fc119dcab2  push rax
000074fc119dcab3  push rcx
000074fc119dcab4  push rdx
000074fc119dcab5  push rdi
000074fc119dcab6  push rsi
000074fc119dcab7  push r8
000074fc119dcab9  push r9
000074fc119dcabb  push r10
000074fc119dcabd  push r11
000074fc119dcabf  sub rsp, 0xF0
000074fc119dcac6  vmovaps [rsp], xmm0
000074fc119dcacb  vmovaps [rsp+0x10], xmm1
000074fc119dcad1  vmovaps [rsp+0x20], xmm2
000074fc119dcad7  vmovaps [rsp+0x30], xmm3
000074fc119dcadd  vmovaps [rsp+0x40], xmm4
000074fc119dcae3  vmovaps [rsp+0x50], xmm5
000074fc119dcae9  vmovaps [rsp+0x60], xmm6
000074fc119dcaef  vmovaps [rsp+0x70], xmm8
000074fc119dcaf5  vmovaps [rsp+0x80], xmm9
000074fc119dcafe  vmovaps [rsp+0x90], xmm10
000074fc119dcb07  vmovaps [rsp+0xA0], xmm11
000074fc119dcb10  vmovaps [rsp+0xB0], xmm12
000074fc119dcb19  vmovaps [rsp+0xC0], xmm13
000074fc119dcb22  vmovaps [rsp+0xD0], xmm14
000074fc119dcb2b  vmovaps [rsp+0xE0], xmm15
000074fc119dcb34  sub rsp, 0x30
000074fc119dcb38  movaps [rsp], xmm7
000074fc119dcb3c  movaps [rsp+0x10], xmm9
000074fc119dcb42  movaps [rsp+0x20], xmm15
000074fc119dcb48  lea rdi, [rsp]
000074fc119dcb4c  mov esi, 0x00
000074fc119dcb51  mov rax, 0x58C4C8091530
000074fc119dcb5b  call rax
000074fc119dcb5d  movaps xmm7, [rsp]
000074fc119dcb61  add rsp, 0x30
000074fc119dcb65  vmovaps xmm0, [rsp]
000074fc119dcb6a  vmovaps xmm1, [rsp+0x10]
000074fc119dcb70  vmovaps xmm2, [rsp+0x20]
000074fc119dcb76  vmovaps xmm3, [rsp+0x30]
000074fc119dcb7c  vmovaps xmm4, [rsp+0x40]
000074fc119dcb82  vmovaps xmm5, [rsp+0x50]
000074fc119dcb88  vmovaps xmm6, [rsp+0x60]
000074fc119dcb8e  vmovaps xmm8, [rsp+0x70]
000074fc119dcb94  vmovaps xmm9, [rsp+0x80]
000074fc119dcb9d  vmovaps xmm10, [rsp+0x90]
000074fc119dcba6  vmovaps xmm11, [rsp+0xA0]
000074fc119dcbaf  vmovaps xmm12, [rsp+0xB0]
000074fc119dcbb8  vmovaps xmm13, [rsp+0xC0]
000074fc119dcbc1  vmovaps xmm14, [rsp+0xD0]
000074fc119dcbca  vmovaps xmm15, [rsp+0xE0]
000074fc119dcbd3  add rsp, 0xF0
000074fc119dcbda  pop r11
000074fc119dcbdc  pop r10
000074fc119dcbde  pop r9
000074fc119dcbe0  pop r8
000074fc119dcbe2  pop rsi
000074fc119dcbe3  pop rdi
000074fc119dcbe4  pop rdx
000074fc119dcbe5  pop rcx
000074fc119dcbe6  pop rax
000074fc119dcbe7  add rsp, 0x08
000074fc119dcbeb  jmp 0x000074FC119DBB75
000074fc119dcbf0  sub rsp, 0x08
000074fc119dcbf4  push rax
000074fc119dcbf5  push rcx
000074fc119dcbf6  push rdx
000074fc119dcbf7  push rdi
000074fc119dcbf8  push rsi
000074fc119dcbf9  push r8
000074fc119dcbfb  push r9
000074fc119dcbfd  push r10
000074fc119dcbff  push r11
000074fc119dcc01  sub rsp, 0xF0
000074fc119dcc08  vmovaps [rsp], xmm0
000074fc119dcc0d  vmovaps [rsp+0x10], xmm1
000074fc119dcc13  vmovaps [rsp+0x20], xmm2
000074fc119dcc19  vmovaps [rsp+0x30], xmm3
000074fc119dcc1f  vmovaps [rsp+0x40], xmm4
000074fc119dcc25  vmovaps [rsp+0x50], xmm5
000074fc119dcc2b  vmovaps [rsp+0x60], xmm6
000074fc119dcc31  vmovaps [rsp+0x70], xmm7
000074fc119dcc37  vmovaps [rsp+0x80], xmm8
000074fc119dcc40  vmovaps [rsp+0x90], xmm10
000074fc119dcc49  vmovaps [rsp+0xA0], xmm11
000074fc119dcc52  vmovaps [rsp+0xB0], xmm12
000074fc119dcc5b  vmovaps [rsp+0xC0], xmm13
000074fc119dcc64  vmovaps [rsp+0xD0], xmm14
000074fc119dcc6d  vmovaps [rsp+0xE0], xmm15
000074fc119dcc76  sub rsp, 0x30
000074fc119dcc7a  movaps [rsp], xmm9
000074fc119dcc7f  movaps [rsp+0x10], xmm12
000074fc119dcc85  movaps [rsp+0x20], xmm10
000074fc119dcc8b  lea rdi, [rsp]
000074fc119dcc8f  mov esi, 0x00
000074fc119dcc94  mov rax, 0x58C4C8091530
000074fc119dcc9e  call rax
000074fc119dcca0  movaps xmm9, [rsp]
000074fc119dcca5  add rsp, 0x30
000074fc119dcca9  vmovaps xmm0, [rsp]
000074fc119dccae  vmovaps xmm1, [rsp+0x10]
000074fc119dccb4  vmovaps xmm2, [rsp+0x20]
000074fc119dccba  vmovaps xmm3, [rsp+0x30]
000074fc119dccc0  vmovaps xmm4, [rsp+0x40]
000074fc119dccc6  vmovaps xmm5, [rsp+0x50]
000074fc119dcccc  vmovaps xmm6, [rsp+0x60]
000074fc119dccd2  vmovaps xmm7, [rsp+0x70]
000074fc119dccd8  vmovaps xmm8, [rsp+0x80]
000074fc119dcce1  vmovaps xmm10, [rsp+0x90]
000074fc119dccea  vmovaps xmm11, [rsp+0xA0]
000074fc119dccf3  vmovaps xmm12, [rsp+0xB0]
000074fc119dccfc  vmovaps xmm13, [rsp+0xC0]
000074fc119dcd05  vmovaps xmm14, [rsp+0xD0]
000074fc119dcd0e  vmovaps xmm15, [rsp+0xE0]
000074fc119dcd17  add rsp, 0xF0
000074fc119dcd1e  pop r11
000074fc119dcd20  pop r10
000074fc119dcd22  pop r9
000074fc119dcd24  pop r8
000074fc119dcd26  pop rsi
000074fc119dcd27  pop rdi
000074fc119dcd28  pop rdx
000074fc119dcd29  pop rcx
000074fc119dcd2a  pop rax
000074fc119dcd2b  add rsp, 0x08
000074fc119dcd2f  jmp 0x000074FC119DBB99
000074fc119dcd34  sub rsp, 0x08
000074fc119dcd38  push rax
000074fc119dcd39  push rcx
000074fc119dcd3a  push rdx
000074fc119dcd3b  push rdi
000074fc119dcd3c  push rsi
000074fc119dcd3d  push r8
000074fc119dcd3f  push r9
000074fc119dcd41  push r10
000074fc119dcd43  push r11
000074fc119dcd45  sub rsp, 0xF0
000074fc119dcd4c  vmovaps [rsp], xmm0
000074fc119dcd51  vmovaps [rsp+0x10], xmm1
000074fc119dcd57  vmovaps [rsp+0x20], xmm2
000074fc119dcd5d  vmovaps [rsp+0x30], xmm3
000074fc119dcd63  vmovaps [rsp+0x40], xmm4
000074fc119dcd69  vmovaps [rsp+0x50], xmm5
000074fc119dcd6f  vmovaps [rsp+0x60], xmm6
000074fc119dcd75  vmovaps [rsp+0x70], xmm7
000074fc119dcd7b  vmovaps [rsp+0x80], xmm8
000074fc119dcd84  vmovaps [rsp+0x90], xmm9
000074fc119dcd8d  vmovaps [rsp+0xA0], xmm11
000074fc119dcd96  vmovaps [rsp+0xB0], xmm12
000074fc119dcd9f  vmovaps [rsp+0xC0], xmm13
000074fc119dcda8  vmovaps [rsp+0xD0], xmm14
000074fc119dcdb1  vmovaps [rsp+0xE0], xmm15
000074fc119dcdba  sub rsp, 0x30
000074fc119dcdbe  movaps [rsp], xmm10
000074fc119dcdc3  movaps [rsp+0x10], xmm12
000074fc119dcdc9  movaps [rsp+0x20], xmm11
000074fc119dcdcf  lea rdi, [rsp]
000074fc119dcdd3  mov esi, 0x00
000074fc119dcdd8  mov rax, 0x58C4C8091530
000074fc119dcde2  call rax
000074fc119dcde4  movaps xmm10, [rsp]
000074fc119dcde9  add rsp, 0x30
000074fc119dcded  vmovaps xmm0, [rsp]
000074fc119dcdf2  vmovaps xmm1, [rsp+0x10]
000074fc119dcdf8  vmovaps xmm2, [rsp+0x20]
000074fc119dcdfe  vmovaps xmm3, [rsp+0x30]
000074fc119dce04  vmovaps xmm4, [rsp+0x40]
000074fc119dce0a  vmovaps xmm5, [rsp+0x50]
000074fc119dce10  vmovaps xmm6, [rsp+0x60]
000074fc119dce16  vmovaps xmm7, [rsp+0x70]
000074fc119dce1c  vmovaps xmm8, [rsp+0x80]
000074fc119dce25  vmovaps xmm9, [rsp+0x90]
000074fc119dce2e  vmovaps xmm11, [rsp+0xA0]
000074fc119dce37  vmovaps xmm12, [rsp+0xB0]
000074fc119dce40  vmovaps xmm13, [rsp+0xC0]
000074fc119dce49  vmovaps xmm14, [rsp+0xD0]
000074fc119dce52  vmovaps xmm15, [rsp+0xE0]
000074fc119dce5b  add rsp, 0xF0
000074fc119dce62  pop r11
000074fc119dce64  pop r10
000074fc119dce66  pop r9
000074fc119dce68  pop r8
000074fc119dce6a  pop rsi
000074fc119dce6b  pop rdi
000074fc119dce6c  pop rdx
000074fc119dce6d  pop rcx
000074fc119dce6e  pop rax
000074fc119dce6f  add rsp, 0x08
000074fc119dce73  jmp 0x000074FC119DBBB3
000074fc119dce78  sub rsp, 0x08
000074fc119dce7c  push rax
000074fc119dce7d  push rcx
000074fc119dce7e  push rdx
000074fc119dce7f  push rdi
000074fc119dce80  push rsi
000074fc119dce81  push r8
000074fc119dce83  push r9
000074fc119dce85  push r10
000074fc119dce87  push r11
000074fc119dce89  sub rsp, 0xF0
000074fc119dce90  vmovaps [rsp], xmm0
000074fc119dce95  vmovaps [rsp+0x10], xmm1
000074fc119dce9b  vmovaps [rsp+0x20], xmm2
000074fc119dcea1  vmovaps [rsp+0x30], xmm3
000074fc119dcea7  vmovaps [rsp+0x40], xmm4
000074fc119dcead  vmovaps [rsp+0x50], xmm5
000074fc119dceb3  vmovaps [rsp+0x60], xmm7
000074fc119dceb9  vmovaps [rsp+0x70], xmm8
000074fc119dcebf  vmovaps [rsp+0x80], xmm9
000074fc119dcec8  vmovaps [rsp+0x90], xmm10
000074fc119dced1  vmovaps [rsp+0xA0], xmm11
000074fc119dceda  vmovaps [rsp+0xB0], xmm12
000074fc119dcee3  vmovaps [rsp+0xC0], xmm13
000074fc119dceec  vmovaps [rsp+0xD0], xmm14
000074fc119dcef5  vmovaps [rsp+0xE0], xmm15
000074fc119dcefe  sub rsp, 0x30
000074fc119dcf02  movaps [rsp], xmm6
000074fc119dcf06  movaps [rsp+0x10], xmm12
000074fc119dcf0c  movaps [rsp+0x20], xmm11
000074fc119dcf12  lea rdi, [rsp]
000074fc119dcf16  mov esi, 0x00
000074fc119dcf1b  mov rax, 0x58C4C8091530
000074fc119dcf25  call rax
000074fc119dcf27  movaps xmm6, [rsp]
000074fc119dcf2b  add rsp, 0x30
000074fc119dcf2f  vmovaps xmm0, [rsp]
000074fc119dcf34  vmovaps xmm1, [rsp+0x10]
000074fc119dcf3a  vmovaps xmm2, [rsp+0x20]
000074fc119dcf40  vmovaps xmm3, [rsp+0x30]
000074fc119dcf46  vmovaps xmm4, [rsp+0x40]
000074fc119dcf4c  vmovaps xmm5, [rsp+0x50]
000074fc119dcf52  vmovaps xmm7, [rsp+0x60]
000074fc119dcf58  vmovaps xmm8, [rsp+0x70]
000074fc119dcf5e  vmovaps xmm9, [rsp+0x80]
000074fc119dcf67  vmovaps xmm10, [rsp+0x90]
000074fc119dcf70  vmovaps xmm11, [rsp+0xA0]
000074fc119dcf79  vmovaps xmm12, [rsp+0xB0]
000074fc119dcf82  vmovaps xmm13, [rsp+0xC0]
000074fc119dcf8b  vmovaps xmm14, [rsp+0xD0]
000074fc119dcf94  vmovaps xmm15, [rsp+0xE0]
000074fc119dcf9d  add rsp, 0xF0
000074fc119dcfa4  pop r11
000074fc119dcfa6  pop r10
000074fc119dcfa8  pop r9
000074fc119dcfaa  pop r8
000074fc119dcfac  pop rsi
000074fc119dcfad  pop rdi
000074fc119dcfae  pop rdx
000074fc119dcfaf  pop rcx
000074fc119dcfb0  pop rax
000074fc119dcfb1  add rsp, 0x08
000074fc119dcfb5  jmp 0x000074FC119DBBD4
000074fc119dcfba  sub rsp, 0x08
000074fc119dcfbe  push rax
000074fc119dcfbf  push rcx
000074fc119dcfc0  push rdx
000074fc119dcfc1  push rdi
000074fc119dcfc2  push rsi
000074fc119dcfc3  push r8
000074fc119dcfc5  push r9
000074fc119dcfc7  push r10
000074fc119dcfc9  push r11
000074fc119dcfcb  sub rsp, 0xF0
000074fc119dcfd2  vmovaps [rsp], xmm0
000074fc119dcfd7  vmovaps [rsp+0x10], xmm1
000074fc119dcfdd  vmovaps [rsp+0x20], xmm2
000074fc119dcfe3  vmovaps [rsp+0x30], xmm4
000074fc119dcfe9  vmovaps [rsp+0x40], xmm5
000074fc119dcfef  vmovaps [rsp+0x50], xmm6
000074fc119dcff5  vmovaps [rsp+0x60], xmm7
000074fc119dcffb  vmovaps [rsp+0x70], xmm8
000074fc119dd001  vmovaps [rsp+0x80], xmm9
000074fc119dd00a  vmovaps [rsp+0x90], xmm10
000074fc119dd013  vmovaps [rsp+0xA0], xmm11
000074fc119dd01c  vmovaps [rsp+0xB0], xmm12
000074fc119dd025  vmovaps [rsp+0xC0], xmm13
000074fc119dd02e  vmovaps [rsp+0xD0], xmm14
000074fc119dd037  vmovaps [rsp+0xE0], xmm15
000074fc119dd040  sub rsp, 0x30
000074fc119dd044  movaps [rsp], xmm3
000074fc119dd048  movaps [rsp+0x10], xmm5
000074fc119dd04d  movaps [rsp+0x20], xmm4
000074fc119dd052  lea rdi, [rsp]
000074fc119dd056  mov esi, 0x00
000074fc119dd05b  mov rax, 0x58C4C8091530
000074fc119dd065  call rax
000074fc119dd067  movaps xmm3, [rsp]
000074fc119dd06b  add rsp, 0x30
000074fc119dd06f  vmovaps xmm0, [rsp]
000074fc119dd074  vmovaps xmm1, [rsp+0x10]
000074fc119dd07a  vmovaps xmm2, [rsp+0x20]
000074fc119dd080  vmovaps xmm4, [rsp+0x30]
000074fc119dd086  vmovaps xmm5, [rsp+0x40]
000074fc119dd08c  vmovaps xmm6, [rsp+0x50]
000074fc119dd092  vmovaps xmm7, [rsp+0x60]
000074fc119dd098  vmovaps xmm8, [rsp+0x70]
000074fc119dd09e  vmovaps xmm9, [rsp+0x80]
000074fc119dd0a7  vmovaps xmm10, [rsp+0x90]
000074fc119dd0b0  vmovaps xmm11, [rsp+0xA0]
000074fc119dd0b9  vmovaps xmm12, [rsp+0xB0]
000074fc119dd0c2  vmovaps xmm13, [rsp+0xC0]
000074fc119dd0cb  vmovaps xmm14, [rsp+0xD0]
000074fc119dd0d4  vmovaps xmm15, [rsp+0xE0]
000074fc119dd0dd  add rsp, 0xF0
000074fc119dd0e4  pop r11
000074fc119dd0e6  pop r10
000074fc119dd0e8  pop r9
000074fc119dd0ea  pop r8
000074fc119dd0ec  pop rsi
000074fc119dd0ed  pop rdi
000074fc119dd0ee  pop rdx
000074fc119dd0ef  pop rcx
000074fc119dd0f0  pop rax
000074fc119dd0f1  add rsp, 0x08
000074fc119dd0f5  jmp 0x000074FC119DBC35
000074fc119dd0fa  sub rsp, 0x08
000074fc119dd0fe  push rax
000074fc119dd0ff  push rcx
000074fc119dd100  push rdx
000074fc119dd101  push rdi
000074fc119dd102  push rsi
000074fc119dd103  push r8
000074fc119dd105  push r9
000074fc119dd107  push r10
000074fc119dd109  push r11
000074fc119dd10b  sub rsp, 0xF0
000074fc119dd112  vmovaps [rsp], xmm0
000074fc119dd117  vmovaps [rsp+0x10], xmm1
000074fc119dd11d  vmovaps [rsp+0x20], xmm2
000074fc119dd123  vmovaps [rsp+0x30], xmm3
000074fc119dd129  vmovaps [rsp+0x40], xmm4
000074fc119dd12f  vmovaps [rsp+0x50], xmm6
000074fc119dd135  vmovaps [rsp+0x60], xmm7
000074fc119dd13b  vmovaps [rsp+0x70], xmm8
000074fc119dd141  vmovaps [rsp+0x80], xmm9
000074fc119dd14a  vmovaps [rsp+0x90], xmm10
000074fc119dd153  vmovaps [rsp+0xA0], xmm11
000074fc119dd15c  vmovaps [rsp+0xB0], xmm12
000074fc119dd165  vmovaps [rsp+0xC0], xmm13
000074fc119dd16e  vmovaps [rsp+0xD0], xmm14
000074fc119dd177  vmovaps [rsp+0xE0], xmm15
000074fc119dd180  sub rsp, 0x30
000074fc119dd184  movaps [rsp], xmm5
000074fc119dd188  movaps [rsp+0x10], xmm8
000074fc119dd18e  movaps [rsp+0x20], xmm15
000074fc119dd194  lea rdi, [rsp]
000074fc119dd198  mov esi, 0x00
000074fc119dd19d  mov rax, 0x58C4C8091530
000074fc119dd1a7  call rax
000074fc119dd1a9  movaps xmm5, [rsp]
000074fc119dd1ad  add rsp, 0x30
000074fc119dd1b1  vmovaps xmm0, [rsp]
000074fc119dd1b6  vmovaps xmm1, [rsp+0x10]
000074fc119dd1bc  vmovaps xmm2, [rsp+0x20]
000074fc119dd1c2  vmovaps xmm3, [rsp+0x30]
000074fc119dd1c8  vmovaps xmm4, [rsp+0x40]
000074fc119dd1ce  vmovaps xmm6, [rsp+0x50]
000074fc119dd1d4  vmovaps xmm7, [rsp+0x60]
000074fc119dd1da  vmovaps xmm8, [rsp+0x70]
000074fc119dd1e0  vmovaps xmm9, [rsp+0x80]
000074fc119dd1e9  vmovaps xmm10, [rsp+0x90]
000074fc119dd1f2  vmovaps xmm11, [rsp+0xA0]
000074fc119dd1fb  vmovaps xmm12, [rsp+0xB0]
000074fc119dd204  vmovaps xmm13, [rsp+0xC0]
000074fc119dd20d  vmovaps xmm14, [rsp+0xD0]
000074fc119dd216  vmovaps xmm15, [rsp+0xE0]
000074fc119dd21f  add rsp, 0xF0
000074fc119dd226  pop r11
000074fc119dd228  pop r10
000074fc119dd22a  pop r9
000074fc119dd22c  pop r8
000074fc119dd22e  pop rsi
000074fc119dd22f  pop rdi
000074fc119dd230  pop rdx
000074fc119dd231  pop rcx
000074fc119dd232  pop rax
000074fc119dd233  add rsp, 0x08
000074fc119dd237  jmp 0x000074FC119DBC73
000074fc119dd23c  sub rsp, 0x08
000074fc119dd240  push rax
000074fc119dd241  push rcx
000074fc119dd242  push rdx
000074fc119dd243  push rdi
000074fc119dd244  push rsi
000074fc119dd245  push r8
000074fc119dd247  push r9
000074fc119dd249  push r10
000074fc119dd24b  push r11
000074fc119dd24d  sub rsp, 0xF0
000074fc119dd254  vmovaps [rsp], xmm0
000074fc119dd259  vmovaps [rsp+0x10], xmm1
000074fc119dd25f  vmovaps [rsp+0x20], xmm2
000074fc119dd265  vmovaps [rsp+0x30], xmm3
000074fc119dd26b  vmovaps [rsp+0x40], xmm5
000074fc119dd271  vmovaps [rsp+0x50], xmm6
000074fc119dd277  vmovaps [rsp+0x60], xmm7
000074fc119dd27d  vmovaps [rsp+0x70], xmm8
000074fc119dd283  vmovaps [rsp+0x80], xmm9
000074fc119dd28c  vmovaps [rsp+0x90], xmm10
000074fc119dd295  vmovaps [rsp+0xA0], xmm11
000074fc119dd29e  vmovaps [rsp+0xB0], xmm12
000074fc119dd2a7  vmovaps [rsp+0xC0], xmm13
000074fc119dd2b0  vmovaps [rsp+0xD0], xmm14
000074fc119dd2b9  vmovaps [rsp+0xE0], xmm15
000074fc119dd2c2  sub rsp, 0x30
000074fc119dd2c6  movaps [rsp], xmm4
000074fc119dd2ca  movaps [rsp+0x10], xmm9
000074fc119dd2d0  movaps [rsp+0x20], xmm8
000074fc119dd2d6  lea rdi, [rsp]
000074fc119dd2da  mov esi, 0x00
000074fc119dd2df  mov rax, 0x58C4C8091530
000074fc119dd2e9  call rax
000074fc119dd2eb  movaps xmm4, [rsp]
000074fc119dd2ef  add rsp, 0x30
000074fc119dd2f3  vmovaps xmm0, [rsp]
000074fc119dd2f8  vmovaps xmm1, [rsp+0x10]
000074fc119dd2fe  vmovaps xmm2, [rsp+0x20]
000074fc119dd304  vmovaps xmm3, [rsp+0x30]
000074fc119dd30a  vmovaps xmm5, [rsp+0x40]
000074fc119dd310  vmovaps xmm6, [rsp+0x50]
000074fc119dd316  vmovaps xmm7, [rsp+0x60]
000074fc119dd31c  vmovaps xmm8, [rsp+0x70]
000074fc119dd322  vmovaps xmm9, [rsp+0x80]
000074fc119dd32b  vmovaps xmm10, [rsp+0x90]
000074fc119dd334  vmovaps xmm11, [rsp+0xA0]
000074fc119dd33d  vmovaps xmm12, [rsp+0xB0]
000074fc119dd346  vmovaps xmm13, [rsp+0xC0]
000074fc119dd34f  vmovaps xmm14, [rsp+0xD0]
000074fc119dd358  vmovaps xmm15, [rsp+0xE0]
000074fc119dd361  add rsp, 0xF0
000074fc119dd368  pop r11
000074fc119dd36a  pop r10
000074fc119dd36c  pop r9
000074fc119dd36e  pop r8
000074fc119dd370  pop rsi
000074fc119dd371  pop rdi
000074fc119dd372  pop rdx
000074fc119dd373  pop rcx
000074fc119dd374  pop rax
000074fc119dd375  add rsp, 0x08
000074fc119dd379  jmp 0x000074FC119DBC94
000074fc119dd37e  sub rsp, 0x08
000074fc119dd382  push rax
000074fc119dd383  push rcx
000074fc119dd384  push rdx
000074fc119dd385  push rdi
000074fc119dd386  push rsi
000074fc119dd387  push r8
000074fc119dd389  push r9
000074fc119dd38b  push r10
000074fc119dd38d  push r11
000074fc119dd38f  sub rsp, 0xF0
000074fc119dd396  vmovaps [rsp], xmm0
000074fc119dd39b  vmovaps [rsp+0x10], xmm1
000074fc119dd3a1  vmovaps [rsp+0x20], xmm2
000074fc119dd3a7  vmovaps [rsp+0x30], xmm3
000074fc119dd3ad  vmovaps [rsp+0x40], xmm4
000074fc119dd3b3  vmovaps [rsp+0x50], xmm5
000074fc119dd3b9  vmovaps [rsp+0x60], xmm6
000074fc119dd3bf  vmovaps [rsp+0x70], xmm7
000074fc119dd3c5  vmovaps [rsp+0x80], xmm8
000074fc119dd3ce  vmovaps [rsp+0x90], xmm10
000074fc119dd3d7  vmovaps [rsp+0xA0], xmm11
000074fc119dd3e0  vmovaps [rsp+0xB0], xmm12
000074fc119dd3e9  vmovaps [rsp+0xC0], xmm13
000074fc119dd3f2  vmovaps [rsp+0xD0], xmm14
000074fc119dd3fb  vmovaps [rsp+0xE0], xmm15
000074fc119dd404  sub rsp, 0x30
000074fc119dd408  movaps [rsp], xmm9
000074fc119dd40d  movaps [rsp+0x10], xmm10
000074fc119dd413  movaps [rsp+0x20], xmm8
000074fc119dd419  lea rdi, [rsp]
000074fc119dd41d  mov esi, 0x00
000074fc119dd422  mov rax, 0x58C4C8091530
000074fc119dd42c  call rax
000074fc119dd42e  movaps xmm9, [rsp]
000074fc119dd433  add rsp, 0x30
000074fc119dd437  vmovaps xmm0, [rsp]
000074fc119dd43c  vmovaps xmm1, [rsp+0x10]
000074fc119dd442  vmovaps xmm2, [rsp+0x20]
000074fc119dd448  vmovaps xmm3, [rsp+0x30]
000074fc119dd44e  vmovaps xmm4, [rsp+0x40]
000074fc119dd454  vmovaps xmm5, [rsp+0x50]
000074fc119dd45a  vmovaps xmm6, [rsp+0x60]
000074fc119dd460  vmovaps xmm7, [rsp+0x70]
000074fc119dd466  vmovaps xmm8, [rsp+0x80]
000074fc119dd46f  vmovaps xmm10, [rsp+0x90]
000074fc119dd478  vmovaps xmm11, [rsp+0xA0]
000074fc119dd481  vmovaps xmm12, [rsp+0xB0]
000074fc119dd48a  vmovaps xmm13, [rsp+0xC0]
000074fc119dd493  vmovaps xmm14, [rsp+0xD0]
000074fc119dd49c  vmovaps xmm15, [rsp+0xE0]
000074fc119dd4a5  add rsp, 0xF0
000074fc119dd4ac  pop r11
000074fc119dd4ae  pop r10
000074fc119dd4b0  pop r9
000074fc119dd4b2  pop r8
000074fc119dd4b4  pop rsi
000074fc119dd4b5  pop rdi
000074fc119dd4b6  pop rdx
000074fc119dd4b7  pop rcx
000074fc119dd4b8  pop rax
000074fc119dd4b9  add rsp, 0x08
000074fc119dd4bd  jmp 0x000074FC119DBCAE
000074fc119dd4c2  call 0x000074FC118B52F0
000074fc119dd4c7  jmp 0x000074FC119DBDC8
000074fc119dd4cc  call 0x000074FC118B52F0
000074fc119dd4d1  jmp 0x000074FC119DBDDE
000074fc119dd4d6  sub rsp, 0x08
000074fc119dd4da  push rax
000074fc119dd4db  push rcx
000074fc119dd4dc  push rdx
000074fc119dd4dd  push rdi
000074fc119dd4de  push rsi
000074fc119dd4df  push r8
000074fc119dd4e1  push r9
000074fc119dd4e3  push r10
000074fc119dd4e5  push r11
000074fc119dd4e7  sub rsp, 0xF0
000074fc119dd4ee  vmovaps [rsp], xmm0
000074fc119dd4f3  vmovaps [rsp+0x10], xmm2
000074fc119dd4f9  vmovaps [rsp+0x20], xmm3
000074fc119dd4ff  vmovaps [rsp+0x30], xmm4
000074fc119dd505  vmovaps [rsp+0x40], xmm5
000074fc119dd50b  vmovaps [rsp+0x50], xmm6
000074fc119dd511  vmovaps [rsp+0x60], xmm7
000074fc119dd517  vmovaps [rsp+0x70], xmm8
000074fc119dd51d  vmovaps [rsp+0x80], xmm9
000074fc119dd526  vmovaps [rsp+0x90], xmm10
000074fc119dd52f  vmovaps [rsp+0xA0], xmm11
000074fc119dd538  vmovaps [rsp+0xB0], xmm12
000074fc119dd541  vmovaps [rsp+0xC0], xmm13
000074fc119dd54a  vmovaps [rsp+0xD0], xmm14
000074fc119dd553  vmovaps [rsp+0xE0], xmm15
000074fc119dd55c  sub rsp, 0x30
000074fc119dd560  movaps [rsp], xmm1
000074fc119dd564  movaps [rsp+0x10], xmm6
000074fc119dd569  movaps [rsp+0x20], xmm15
000074fc119dd56f  lea rdi, [rsp]
000074fc119dd573  mov esi, 0x00
000074fc119dd578  mov rax, 0x58C4C8091530
000074fc119dd582  call rax
000074fc119dd584  movaps xmm1, [rsp]
000074fc119dd588  add rsp, 0x30
000074fc119dd58c  vmovaps xmm0, [rsp]
000074fc119dd591  vmovaps xmm2, [rsp+0x10]
000074fc119dd597  vmovaps xmm3, [rsp+0x20]
000074fc119dd59d  vmovaps xmm4, [rsp+0x30]
000074fc119dd5a3  vmovaps xmm5, [rsp+0x40]
000074fc119dd5a9  vmovaps xmm6, [rsp+0x50]
000074fc119dd5af  vmovaps xmm7, [rsp+0x60]
000074fc119dd5b5  vmovaps xmm8, [rsp+0x70]
000074fc119dd5bb  vmovaps xmm9, [rsp+0x80]
000074fc119dd5c4  vmovaps xmm10, [rsp+0x90]
000074fc119dd5cd  vmovaps xmm11, [rsp+0xA0]
000074fc119dd5d6  vmovaps xmm12, [rsp+0xB0]
000074fc119dd5df  vmovaps xmm13, [rsp+0xC0]
000074fc119dd5e8  vmovaps xmm14, [rsp+0xD0]
000074fc119dd5f1  vmovaps xmm15, [rsp+0xE0]
000074fc119dd5fa  add rsp, 0xF0
000074fc119dd601  pop r11
000074fc119dd603  pop r10
000074fc119dd605  pop r9
000074fc119dd607  pop r8
000074fc119dd609  pop rsi
000074fc119dd60a  pop rdi
000074fc119dd60b  pop rdx
000074fc119dd60c  pop rcx
000074fc119dd60d  pop rax
000074fc119dd60e  add rsp, 0x08
000074fc119dd612  jmp 0x000074FC119DBE1B
000074fc119dd617  call 0x000074FC118C4620
000074fc119dd61c  jmp 0x000074FC119DBE28
000074fc119dd621  sub rsp, 0x08
000074fc119dd625  push rax
000074fc119dd626  push rcx
000074fc119dd627  push rdx
000074fc119dd628  push rdi
000074fc119dd629  push rsi
000074fc119dd62a  push r8
000074fc119dd62c  push r9
000074fc119dd62e  push r10
000074fc119dd630  push r11
000074fc119dd632  sub rsp, 0xF0
000074fc119dd639  vmovaps [rsp], xmm0
000074fc119dd63e  vmovaps [rsp+0x10], xmm1
000074fc119dd644  vmovaps [rsp+0x20], xmm2
000074fc119dd64a  vmovaps [rsp+0x30], xmm3
000074fc119dd650  vmovaps [rsp+0x40], xmm4
000074fc119dd656  vmovaps [rsp+0x50], xmm5
000074fc119dd65c  vmovaps [rsp+0x60], xmm6
000074fc119dd662  vmovaps [rsp+0x70], xmm7
000074fc119dd668  vmovaps [rsp+0x80], xmm8
000074fc119dd671  vmovaps [rsp+0x90], xmm9
000074fc119dd67a  vmovaps [rsp+0xA0], xmm10
000074fc119dd683  vmovaps [rsp+0xB0], xmm11
000074fc119dd68c  vmovaps [rsp+0xC0], xmm12
000074fc119dd695  vmovaps [rsp+0xD0], xmm13
000074fc119dd69e  vmovaps [rsp+0xE0], xmm15
000074fc119dd6a7  sub rsp, 0x30
000074fc119dd6ab  movaps [rsp], xmm14
000074fc119dd6b0  movaps [rsp+0x10], xmm4
000074fc119dd6b5  movaps [rsp+0x20], xmm3
000074fc119dd6ba  lea rdi, [rsp]
000074fc119dd6be  mov esi, 0x00
000074fc119dd6c3  mov rax, 0x58C4C8091530
000074fc119dd6cd  call rax
000074fc119dd6cf  movaps xmm14, [rsp]
000074fc119dd6d4  add rsp, 0x30
000074fc119dd6d8  vmovaps xmm0, [rsp]
000074fc119dd6dd  vmovaps xmm1, [rsp+0x10]
000074fc119dd6e3  vmovaps xmm2, [rsp+0x20]
000074fc119dd6e9  vmovaps xmm3, [rsp+0x30]
000074fc119dd6ef  vmovaps xmm4, [rsp+0x40]
000074fc119dd6f5  vmovaps xmm5, [rsp+0x50]
000074fc119dd6fb  vmovaps xmm6, [rsp+0x60]
000074fc119dd701  vmovaps xmm7, [rsp+0x70]
000074fc119dd707  vmovaps xmm8, [rsp+0x80]
000074fc119dd710  vmovaps xmm9, [rsp+0x90]
000074fc119dd719  vmovaps xmm10, [rsp+0xA0]
000074fc119dd722  vmovaps xmm11, [rsp+0xB0]
000074fc119dd72b  vmovaps xmm12, [rsp+0xC0]
000074fc119dd734  vmovaps xmm13, [rsp+0xD0]
000074fc119dd73d  vmovaps xmm15, [rsp+0xE0]
000074fc119dd746  add rsp, 0xF0
000074fc119dd74d  pop r11
000074fc119dd74f  pop r10
000074fc119dd751  pop r9
000074fc119dd753  pop r8
000074fc119dd755  pop rsi
000074fc119dd756  pop rdi
000074fc119dd757  pop rdx
000074fc119dd758  pop rcx
000074fc119dd759  pop rax
000074fc119dd75a  add rsp, 0x08
000074fc119dd75e  jmp 0x000074FC119DBE42
000074fc119dd763  sub rsp, 0x08
000074fc119dd767  push rax
000074fc119dd768  push rcx
000074fc119dd769  push rdx
000074fc119dd76a  push rdi
000074fc119dd76b  push rsi
000074fc119dd76c  push r8
000074fc119dd76e  push r9
000074fc119dd770  push r10
000074fc119dd772  push r11
000074fc119dd774  sub rsp, 0xF0
000074fc119dd77b  vmovaps [rsp], xmm0
000074fc119dd780  vmovaps [rsp+0x10], xmm1
000074fc119dd786  vmovaps [rsp+0x20], xmm2
000074fc119dd78c  vmovaps [rsp+0x30], xmm3
000074fc119dd792  vmovaps [rsp+0x40], xmm4
000074fc119dd798  vmovaps [rsp+0x50], xmm5
000074fc119dd79e  vmovaps [rsp+0x60], xmm7
000074fc119dd7a4  vmovaps [rsp+0x70], xmm8
000074fc119dd7aa  vmovaps [rsp+0x80], xmm9
000074fc119dd7b3  vmovaps [rsp+0x90], xmm10
000074fc119dd7bc  vmovaps [rsp+0xA0], xmm11
000074fc119dd7c5  vmovaps [rsp+0xB0], xmm12
000074fc119dd7ce  vmovaps [rsp+0xC0], xmm13
000074fc119dd7d7  vmovaps [rsp+0xD0], xmm14
000074fc119dd7e0  vmovaps [rsp+0xE0], xmm15
000074fc119dd7e9  sub rsp, 0x30
000074fc119dd7ed  movaps [rsp], xmm6
000074fc119dd7f1  movaps [rsp+0x10], xmm9
000074fc119dd7f7  movaps [rsp+0x20], xmm7
000074fc119dd7fc  lea rdi, [rsp]
000074fc119dd800  mov esi, 0x00
000074fc119dd805  mov rax, 0x58C4C8091530
000074fc119dd80f  call rax
000074fc119dd811  movaps xmm6, [rsp]
000074fc119dd815  add rsp, 0x30
000074fc119dd819  vmovaps xmm0, [rsp]
000074fc119dd81e  vmovaps xmm1, [rsp+0x10]
000074fc119dd824  vmovaps xmm2, [rsp+0x20]
000074fc119dd82a  vmovaps xmm3, [rsp+0x30]
000074fc119dd830  vmovaps xmm4, [rsp+0x40]
000074fc119dd836  vmovaps xmm5, [rsp+0x50]
000074fc119dd83c  vmovaps xmm7, [rsp+0x60]
000074fc119dd842  vmovaps xmm8, [rsp+0x70]
000074fc119dd848  vmovaps xmm9, [rsp+0x80]
000074fc119dd851  vmovaps xmm10, [rsp+0x90]
000074fc119dd85a  vmovaps xmm11, [rsp+0xA0]
000074fc119dd863  vmovaps xmm12, [rsp+0xB0]
000074fc119dd86c  vmovaps xmm13, [rsp+0xC0]
000074fc119dd875  vmovaps xmm14, [rsp+0xD0]
000074fc119dd87e  vmovaps xmm15, [rsp+0xE0]
000074fc119dd887  add rsp, 0xF0
000074fc119dd88e  pop r11
000074fc119dd890  pop r10
000074fc119dd892  pop r9
000074fc119dd894  pop r8
000074fc119dd896  pop rsi
000074fc119dd897  pop rdi
000074fc119dd898  pop rdx
000074fc119dd899  pop rcx
000074fc119dd89a  pop rax
000074fc119dd89b  add rsp, 0x08
000074fc119dd89f  jmp 0x000074FC119DBE5A
000074fc119dd8a4  sub rsp, 0x08
000074fc119dd8a8  push rax
000074fc119dd8a9  push rcx
000074fc119dd8aa  push rdx
000074fc119dd8ab  push rdi
000074fc119dd8ac  push rsi
000074fc119dd8ad  push r8
000074fc119dd8af  push r9
000074fc119dd8b1  push r10
000074fc119dd8b3  push r11
000074fc119dd8b5  sub rsp, 0xF0
000074fc119dd8bc  vmovaps [rsp], xmm0
000074fc119dd8c1  vmovaps [rsp+0x10], xmm1
000074fc119dd8c7  vmovaps [rsp+0x20], xmm2
000074fc119dd8cd  vmovaps [rsp+0x30], xmm3
000074fc119dd8d3  vmovaps [rsp+0x40], xmm4
000074fc119dd8d9  vmovaps [rsp+0x50], xmm5
000074fc119dd8df  vmovaps [rsp+0x60], xmm6
000074fc119dd8e5  vmovaps [rsp+0x70], xmm8
000074fc119dd8eb  vmovaps [rsp+0x80], xmm9
000074fc119dd8f4  vmovaps [rsp+0x90], xmm10
000074fc119dd8fd  vmovaps [rsp+0xA0], xmm11
000074fc119dd906  vmovaps [rsp+0xB0], xmm12
000074fc119dd90f  vmovaps [rsp+0xC0], xmm13
000074fc119dd918  vmovaps [rsp+0xD0], xmm14
000074fc119dd921  vmovaps [rsp+0xE0], xmm15
000074fc119dd92a  sub rsp, 0x30
000074fc119dd92e  movaps [rsp], xmm7
000074fc119dd932  movaps [rsp+0x10], xmm4
000074fc119dd937  movaps [rsp+0x20], xmm9
000074fc119dd93d  lea rdi, [rsp]
000074fc119dd941  mov esi, 0x00
000074fc119dd946  mov rax, 0x58C4C8091530
000074fc119dd950  call rax
000074fc119dd952  movaps xmm7, [rsp]
000074fc119dd956  add rsp, 0x30
000074fc119dd95a  vmovaps xmm0, [rsp]
000074fc119dd95f  vmovaps xmm1, [rsp+0x10]
000074fc119dd965  vmovaps xmm2, [rsp+0x20]
000074fc119dd96b  vmovaps xmm3, [rsp+0x30]
000074fc119dd971  vmovaps xmm4, [rsp+0x40]
000074fc119dd977  vmovaps xmm5, [rsp+0x50]
000074fc119dd97d  vmovaps xmm6, [rsp+0x60]
000074fc119dd983  vmovaps xmm8, [rsp+0x70]
000074fc119dd989  vmovaps xmm9, [rsp+0x80]
000074fc119dd992  vmovaps xmm10, [rsp+0x90]
000074fc119dd99b  vmovaps xmm11, [rsp+0xA0]
000074fc119dd9a4  vmovaps xmm12, [rsp+0xB0]
000074fc119dd9ad  vmovaps xmm13, [rsp+0xC0]
000074fc119dd9b6  vmovaps xmm14, [rsp+0xD0]
000074fc119dd9bf  vmovaps xmm15, [rsp+0xE0]
000074fc119dd9c8  add rsp, 0xF0
000074fc119dd9cf  pop r11
000074fc119dd9d1  pop r10
000074fc119dd9d3  pop r9
000074fc119dd9d5  pop r8
000074fc119dd9d7  pop rsi
000074fc119dd9d8  pop rdi
000074fc119dd9d9  pop rdx
000074fc119dd9da  pop rcx
000074fc119dd9db  pop rax
000074fc119dd9dc  add rsp, 0x08
000074fc119dd9e0  jmp 0x000074FC119DBE87
000074fc119dd9e5  sub rsp, 0x08
000074fc119dd9e9  push rax
000074fc119dd9ea  push rcx
000074fc119dd9eb  push rdx
000074fc119dd9ec  push rdi
000074fc119dd9ed  push rsi
000074fc119dd9ee  push r8
000074fc119dd9f0  push r9
000074fc119dd9f2  push r10
000074fc119dd9f4  push r11
000074fc119dd9f6  sub rsp, 0xF0
000074fc119dd9fd  vmovaps [rsp], xmm0
000074fc119dda02  vmovaps [rsp+0x10], xmm1
000074fc119dda08  vmovaps [rsp+0x20], xmm2
000074fc119dda0e  vmovaps [rsp+0x30], xmm3
000074fc119dda14  vmovaps [rsp+0x40], xmm5
000074fc119dda1a  vmovaps [rsp+0x50], xmm6
000074fc119dda20  vmovaps [rsp+0x60], xmm7
000074fc119dda26  vmovaps [rsp+0x70], xmm8
000074fc119dda2c  vmovaps [rsp+0x80], xmm9
000074fc119dda35  vmovaps [rsp+0x90], xmm10
000074fc119dda3e  vmovaps [rsp+0xA0], xmm11
000074fc119dda47  vmovaps [rsp+0xB0], xmm12
000074fc119dda50  vmovaps [rsp+0xC0], xmm13
000074fc119dda59  vmovaps [rsp+0xD0], xmm14
000074fc119dda62  vmovaps [rsp+0xE0], xmm15
000074fc119dda6b  sub rsp, 0x30
000074fc119dda6f  movaps [rsp], xmm4
000074fc119dda73  movaps [rsp+0x10], xmm15
000074fc119dda79  movaps [rsp+0x20], xmm9
000074fc119dda7f  lea rdi, [rsp]
000074fc119dda83  mov esi, 0x00
000074fc119dda88  mov rax, 0x58C4C8091530
000074fc119dda92  call rax
000074fc119dda94  movaps xmm4, [rsp]
000074fc119dda98  add rsp, 0x30
000074fc119dda9c  vmovaps xmm0, [rsp]
000074fc119ddaa1  vmovaps xmm1, [rsp+0x10]
000074fc119ddaa7  vmovaps xmm2, [rsp+0x20]
000074fc119ddaad  vmovaps xmm3, [rsp+0x30]
000074fc119ddab3  vmovaps xmm5, [rsp+0x40]
000074fc119ddab9  vmovaps xmm6, [rsp+0x50]
000074fc119ddabf  vmovaps xmm7, [rsp+0x60]
000074fc119ddac5  vmovaps xmm8, [rsp+0x70]
000074fc119ddacb  vmovaps xmm9, [rsp+0x80]
000074fc119ddad4  vmovaps xmm10, [rsp+0x90]
000074fc119ddadd  vmovaps xmm11, [rsp+0xA0]
000074fc119ddae6  vmovaps xmm12, [rsp+0xB0]
000074fc119ddaef  vmovaps xmm13, [rsp+0xC0]
000074fc119ddaf8  vmovaps xmm14, [rsp+0xD0]
000074fc119ddb01  vmovaps xmm15, [rsp+0xE0]
000074fc119ddb0a  add rsp, 0xF0
000074fc119ddb11  pop r11
000074fc119ddb13  pop r10
000074fc119ddb15  pop r9
000074fc119ddb17  pop r8
000074fc119ddb19  pop rsi
000074fc119ddb1a  pop rdi
000074fc119ddb1b  pop rdx
000074fc119ddb1c  pop rcx
000074fc119ddb1d  pop rax
000074fc119ddb1e  add rsp, 0x08
000074fc119ddb22  jmp 0x000074FC119DBEAC
000074fc119ddb27  call 0x000074FC118C4620
000074fc119ddb2c  jmp 0x000074FC119DBEB9
000074fc119ddb31  sub rsp, 0x08
000074fc119ddb35  push rax
000074fc119ddb36  push rcx
000074fc119ddb37  push rdx
000074fc119ddb38  push rdi
000074fc119ddb39  push rsi
000074fc119ddb3a  push r8
000074fc119ddb3c  push r9
000074fc119ddb3e  push r10
000074fc119ddb40  push r11
000074fc119ddb42  sub rsp, 0xF0
000074fc119ddb49  vmovaps [rsp], xmm0
000074fc119ddb4e  vmovaps [rsp+0x10], xmm1
000074fc119ddb54  vmovaps [rsp+0x20], xmm2
000074fc119ddb5a  vmovaps [rsp+0x30], xmm4
000074fc119ddb60  vmovaps [rsp+0x40], xmm5
000074fc119ddb66  vmovaps [rsp+0x50], xmm6
000074fc119ddb6c  vmovaps [rsp+0x60], xmm7
000074fc119ddb72  vmovaps [rsp+0x70], xmm8
000074fc119ddb78  vmovaps [rsp+0x80], xmm9
000074fc119ddb81  vmovaps [rsp+0x90], xmm10
000074fc119ddb8a  vmovaps [rsp+0xA0], xmm11
000074fc119ddb93  vmovaps [rsp+0xB0], xmm12
000074fc119ddb9c  vmovaps [rsp+0xC0], xmm13
000074fc119ddba5  vmovaps [rsp+0xD0], xmm14
000074fc119ddbae  vmovaps [rsp+0xE0], xmm15
000074fc119ddbb7  sub rsp, 0x30
000074fc119ddbbb  movaps [rsp], xmm3
000074fc119ddbbf  movaps [rsp+0x10], xmm1
000074fc119ddbc4  movaps [rsp+0x20], xmm9
000074fc119ddbca  lea rdi, [rsp]
000074fc119ddbce  mov esi, 0x00
000074fc119ddbd3  mov rax, 0x58C4C8091530
000074fc119ddbdd  call rax
000074fc119ddbdf  movaps xmm3, [rsp]
000074fc119ddbe3  add rsp, 0x30
000074fc119ddbe7  vmovaps xmm0, [rsp]
000074fc119ddbec  vmovaps xmm1, [rsp+0x10]
000074fc119ddbf2  vmovaps xmm2, [rsp+0x20]
000074fc119ddbf8  vmovaps xmm4, [rsp+0x30]
000074fc119ddbfe  vmovaps xmm5, [rsp+0x40]
000074fc119ddc04  vmovaps xmm6, [rsp+0x50]
000074fc119ddc0a  vmovaps xmm7, [rsp+0x60]
000074fc119ddc10  vmovaps xmm8, [rsp+0x70]
000074fc119ddc16  vmovaps xmm9, [rsp+0x80]
000074fc119ddc1f  vmovaps xmm10, [rsp+0x90]
000074fc119ddc28  vmovaps xmm11, [rsp+0xA0]
000074fc119ddc31  vmovaps xmm12, [rsp+0xB0]
000074fc119ddc3a  vmovaps xmm13, [rsp+0xC0]
000074fc119ddc43  vmovaps xmm14, [rsp+0xD0]
000074fc119ddc4c  vmovaps xmm15, [rsp+0xE0]
000074fc119ddc55  add rsp, 0xF0
000074fc119ddc5c  pop r11
000074fc119ddc5e  pop r10
000074fc119ddc60  pop r9
000074fc119ddc62  pop r8
000074fc119ddc64  pop rsi
000074fc119ddc65  pop rdi
000074fc119ddc66  pop rdx
000074fc119ddc67  pop rcx
000074fc119ddc68  pop rax
000074fc119ddc69  add rsp, 0x08
000074fc119ddc6d  jmp 0x000074FC119DBEF6
000074fc119ddc72  sub rsp, 0x08
000074fc119ddc76  push rax
000074fc119ddc77  push rcx
000074fc119ddc78  push rdx
000074fc119ddc79  push rdi
000074fc119ddc7a  push rsi
000074fc119ddc7b  push r8
000074fc119ddc7d  push r9
000074fc119ddc7f  push r10
000074fc119ddc81  push r11
000074fc119ddc83  sub rsp, 0xF0
000074fc119ddc8a  vmovaps [rsp], xmm0
000074fc119ddc8f  vmovaps [rsp+0x10], xmm2
000074fc119ddc95  vmovaps [rsp+0x20], xmm3
000074fc119ddc9b  vmovaps [rsp+0x30], xmm4
000074fc119ddca1  vmovaps [rsp+0x40], xmm5
000074fc119ddca7  vmovaps [rsp+0x50], xmm6
000074fc119ddcad  vmovaps [rsp+0x60], xmm7
000074fc119ddcb3  vmovaps [rsp+0x70], xmm8
000074fc119ddcb9  vmovaps [rsp+0x80], xmm9
000074fc119ddcc2  vmovaps [rsp+0x90], xmm10
000074fc119ddccb  vmovaps [rsp+0xA0], xmm11
000074fc119ddcd4  vmovaps [rsp+0xB0], xmm12
000074fc119ddcdd  vmovaps [rsp+0xC0], xmm13
000074fc119ddce6  vmovaps [rsp+0xD0], xmm14
000074fc119ddcef  vmovaps [rsp+0xE0], xmm15
000074fc119ddcf8  sub rsp, 0x30
000074fc119ddcfc  movaps [rsp], xmm1
000074fc119ddd00  movaps [rsp+0x10], xmm15
000074fc119ddd06  movaps [rsp+0x20], xmm9
000074fc119ddd0c  lea rdi, [rsp]
000074fc119ddd10  mov esi, 0x00
000074fc119ddd15  mov rax, 0x58C4C8091530
000074fc119ddd1f  call rax
000074fc119ddd21  movaps xmm1, [rsp]
000074fc119ddd25  add rsp, 0x30
000074fc119ddd29  vmovaps xmm0, [rsp]
000074fc119ddd2e  vmovaps xmm2, [rsp+0x10]
000074fc119ddd34  vmovaps xmm3, [rsp+0x20]
000074fc119ddd3a  vmovaps xmm4, [rsp+0x30]
000074fc119ddd40  vmovaps xmm5, [rsp+0x40]
000074fc119ddd46  vmovaps xmm6, [rsp+0x50]
000074fc119ddd4c  vmovaps xmm7, [rsp+0x60]
000074fc119ddd52  vmovaps xmm8, [rsp+0x70]
000074fc119ddd58  vmovaps xmm9, [rsp+0x80]
000074fc119ddd61  vmovaps xmm10, [rsp+0x90]
000074fc119ddd6a  vmovaps xmm11, [rsp+0xA0]
000074fc119ddd73  vmovaps xmm12, [rsp+0xB0]
000074fc119ddd7c  vmovaps xmm13, [rsp+0xC0]
000074fc119ddd85  vmovaps xmm14, [rsp+0xD0]
000074fc119ddd8e  vmovaps xmm15, [rsp+0xE0]
000074fc119ddd97  add rsp, 0xF0
000074fc119ddd9e  pop r11
000074fc119ddda0  pop r10
000074fc119ddda2  pop r9
000074fc119ddda4  pop r8
000074fc119ddda6  pop rsi
000074fc119ddda7  pop rdi
000074fc119ddda8  pop rdx
000074fc119ddda9  pop rcx
000074fc119dddaa  pop rax
000074fc119dddab  add rsp, 0x08
000074fc119dddaf  jmp 0x000074FC119DBF7E
000074fc119dddb4  call 0x000074FC118C4620
000074fc119dddb9  jmp 0x000074FC119DBF8B
000074fc119dddbe  sub rsp, 0x08
000074fc119dddc2  push rax
000074fc119dddc3  push rcx
000074fc119dddc4  push rdx
000074fc119dddc5  push rdi
000074fc119dddc6  push rsi
000074fc119dddc7  push r8
000074fc119dddc9  push r9
000074fc119dddcb  push r10
000074fc119dddcd  push r11
000074fc119dddcf  sub rsp, 0xF0
000074fc119dddd6  vmovaps [rsp], xmm0
000074fc119ddddb  vmovaps [rsp+0x10], xmm2
000074fc119ddde1  vmovaps [rsp+0x20], xmm3
000074fc119ddde7  vmovaps [rsp+0x30], xmm4
000074fc119ddded  vmovaps [rsp+0x40], xmm5
000074fc119dddf3  vmovaps [rsp+0x50], xmm6
000074fc119dddf9  vmovaps [rsp+0x60], xmm7
000074fc119dddff  vmovaps [rsp+0x70], xmm8
000074fc119dde05  vmovaps [rsp+0x80], xmm9
000074fc119dde0e  vmovaps [rsp+0x90], xmm10
000074fc119dde17  vmovaps [rsp+0xA0], xmm11
000074fc119dde20  vmovaps [rsp+0xB0], xmm12
000074fc119dde29  vmovaps [rsp+0xC0], xmm13
000074fc119dde32  vmovaps [rsp+0xD0], xmm14
000074fc119dde3b  vmovaps [rsp+0xE0], xmm15
000074fc119dde44  sub rsp, 0x30
000074fc119dde48  movaps [rsp], xmm1
000074fc119dde4c  movaps [rsp+0x10], xmm5
000074fc119dde51  movaps [rsp+0x20], xmm7
000074fc119dde56  lea rdi, [rsp]
000074fc119dde5a  mov esi, 0x00
000074fc119dde5f  mov rax, 0x58C4C8091530
000074fc119dde69  call rax
000074fc119dde6b  movaps xmm1, [rsp]
000074fc119dde6f  add rsp, 0x30
000074fc119dde73  vmovaps xmm0, [rsp]
000074fc119dde78  vmovaps xmm2, [rsp+0x10]
000074fc119dde7e  vmovaps xmm3, [rsp+0x20]
000074fc119dde84  vmovaps xmm4, [rsp+0x30]
000074fc119dde8a  vmovaps xmm5, [rsp+0x40]
000074fc119dde90  vmovaps xmm6, [rsp+0x50]
000074fc119dde96  vmovaps xmm7, [rsp+0x60]
000074fc119dde9c  vmovaps xmm8, [rsp+0x70]
000074fc119ddea2  vmovaps xmm9, [rsp+0x80]
000074fc119ddeab  vmovaps xmm10, [rsp+0x90]
000074fc119ddeb4  vmovaps xmm11, [rsp+0xA0]
000074fc119ddebd  vmovaps xmm12, [rsp+0xB0]
000074fc119ddec6  vmovaps xmm13, [rsp+0xC0]
000074fc119ddecf  vmovaps xmm14, [rsp+0xD0]
000074fc119dded8  vmovaps xmm15, [rsp+0xE0]
000074fc119ddee1  add rsp, 0xF0
000074fc119ddee8  pop r11
000074fc119ddeea  pop r10
000074fc119ddeec  pop r9
000074fc119ddeee  pop r8
000074fc119ddef0  pop rsi
000074fc119ddef1  pop rdi
000074fc119ddef2  pop rdx
000074fc119ddef3  pop rcx
000074fc119ddef4  pop rax
000074fc119ddef5  add rsp, 0x08
000074fc119ddef9  jmp 0x000074FC119DC030
000074fc119ddefe  sub rsp, 0x08
000074fc119ddf02  push rax
000074fc119ddf03  push rcx
000074fc119ddf04  push rdx
000074fc119ddf05  push rdi
000074fc119ddf06  push rsi
000074fc119ddf07  push r8
000074fc119ddf09  push r9
000074fc119ddf0b  push r10
000074fc119ddf0d  push r11
000074fc119ddf0f  sub rsp, 0xF0
000074fc119ddf16  vmovaps [rsp], xmm0
000074fc119ddf1b  vmovaps [rsp+0x10], xmm1
000074fc119ddf21  vmovaps [rsp+0x20], xmm2
000074fc119ddf27  vmovaps [rsp+0x30], xmm3
000074fc119ddf2d  vmovaps [rsp+0x40], xmm4
000074fc119ddf33  vmovaps [rsp+0x50], xmm5
000074fc119ddf39  vmovaps [rsp+0x60], xmm6
000074fc119ddf3f  vmovaps [rsp+0x70], xmm8
000074fc119ddf45  vmovaps [rsp+0x80], xmm9
000074fc119ddf4e  vmovaps [rsp+0x90], xmm10
000074fc119ddf57  vmovaps [rsp+0xA0], xmm11
000074fc119ddf60  vmovaps [rsp+0xB0], xmm12
000074fc119ddf69  vmovaps [rsp+0xC0], xmm13
000074fc119ddf72  vmovaps [rsp+0xD0], xmm14
000074fc119ddf7b  vmovaps [rsp+0xE0], xmm15
000074fc119ddf84  sub rsp, 0x30
000074fc119ddf88  movaps [rsp], xmm7
000074fc119ddf8c  movaps [rsp+0x10], xmm5
000074fc119ddf91  movaps [rsp+0x20], xmm15
000074fc119ddf97  lea rdi, [rsp]
000074fc119ddf9b  mov esi, 0x00
000074fc119ddfa0  mov rax, 0x58C4C8091530
000074fc119ddfaa  call rax
000074fc119ddfac  movaps xmm7, [rsp]
000074fc119ddfb0  add rsp, 0x30
000074fc119ddfb4  vmovaps xmm0, [rsp]
000074fc119ddfb9  vmovaps xmm1, [rsp+0x10]
000074fc119ddfbf  vmovaps xmm2, [rsp+0x20]
000074fc119ddfc5  vmovaps xmm3, [rsp+0x30]
000074fc119ddfcb  vmovaps xmm4, [rsp+0x40]
000074fc119ddfd1  vmovaps xmm5, [rsp+0x50]
000074fc119ddfd7  vmovaps xmm6, [rsp+0x60]
000074fc119ddfdd  vmovaps xmm8, [rsp+0x70]
000074fc119ddfe3  vmovaps xmm9, [rsp+0x80]
000074fc119ddfec  vmovaps xmm10, [rsp+0x90]
000074fc119ddff5  vmovaps xmm11, [rsp+0xA0]
000074fc119ddffe  vmovaps xmm12, [rsp+0xB0]
000074fc119de007  vmovaps xmm13, [rsp+0xC0]
000074fc119de010  vmovaps xmm14, [rsp+0xD0]
000074fc119de019  vmovaps xmm15, [rsp+0xE0]
000074fc119de022  add rsp, 0xF0
000074fc119de029  pop r11
000074fc119de02b  pop r10
000074fc119de02d  pop r9
000074fc119de02f  pop r8
000074fc119de031  pop rsi
000074fc119de032  pop rdi
000074fc119de033  pop rdx
000074fc119de034  pop rcx
000074fc119de035  pop rax
000074fc119de036  add rsp, 0x08
000074fc119de03a  jmp 0x000074FC119DC066
000074fc119de03f  call 0x000074FC118B52F0
000074fc119de044  jmp 0x000074FC119DC073
000074fc119de049  sub rsp, 0x08
000074fc119de04d  push rax
000074fc119de04e  push rcx
000074fc119de04f  push rdx
000074fc119de050  push rdi
000074fc119de051  push rsi
000074fc119de052  push r8
000074fc119de054  push r9
000074fc119de056  push r10
000074fc119de058  push r11
000074fc119de05a  sub rsp, 0xF0
000074fc119de061  vmovaps [rsp], xmm0
000074fc119de066  vmovaps [rsp+0x10], xmm1
000074fc119de06c  vmovaps [rsp+0x20], xmm2
000074fc119de072  vmovaps [rsp+0x30], xmm3
000074fc119de078  vmovaps [rsp+0x40], xmm4
000074fc119de07e  vmovaps [rsp+0x50], xmm5
000074fc119de084  vmovaps [rsp+0x60], xmm6
000074fc119de08a  vmovaps [rsp+0x70], xmm7
000074fc119de090  vmovaps [rsp+0x80], xmm8
000074fc119de099  vmovaps [rsp+0x90], xmm9
000074fc119de0a2  vmovaps [rsp+0xA0], xmm10
000074fc119de0ab  vmovaps [rsp+0xB0], xmm11
000074fc119de0b4  vmovaps [rsp+0xC0], xmm12
000074fc119de0bd  vmovaps [rsp+0xD0], xmm13
000074fc119de0c6  vmovaps [rsp+0xE0], xmm14
000074fc119de0cf  sub rsp, 0x30
000074fc119de0d3  movaps [rsp], xmm15
000074fc119de0d8  movaps [rsp+0x10], xmm5
000074fc119de0dd  movaps [rsp+0x20], xmm3
000074fc119de0e2  lea rdi, [rsp]
000074fc119de0e6  mov esi, 0x00
000074fc119de0eb  mov rax, 0x58C4C8091530
000074fc119de0f5  call rax
000074fc119de0f7  movaps xmm15, [rsp]
000074fc119de0fc  add rsp, 0x30
000074fc119de100  vmovaps xmm0, [rsp]
000074fc119de105  vmovaps xmm1, [rsp+0x10]
000074fc119de10b  vmovaps xmm2, [rsp+0x20]
000074fc119de111  vmovaps xmm3, [rsp+0x30]
000074fc119de117  vmovaps xmm4, [rsp+0x40]
000074fc119de11d  vmovaps xmm5, [rsp+0x50]
000074fc119de123  vmovaps xmm6, [rsp+0x60]
000074fc119de129  vmovaps xmm7, [rsp+0x70]
000074fc119de12f  vmovaps xmm8, [rsp+0x80]
000074fc119de138  vmovaps xmm9, [rsp+0x90]
000074fc119de141  vmovaps xmm10, [rsp+0xA0]
000074fc119de14a  vmovaps xmm11, [rsp+0xB0]
000074fc119de153  vmovaps xmm12, [rsp+0xC0]
000074fc119de15c  vmovaps xmm13, [rsp+0xD0]
000074fc119de165  vmovaps xmm14, [rsp+0xE0]
000074fc119de16e  add rsp, 0xF0
000074fc119de175  pop r11
000074fc119de177  pop r10
000074fc119de179  pop r9
000074fc119de17b  pop r8
000074fc119de17d  pop rsi
000074fc119de17e  pop rdi
000074fc119de17f  pop rdx
000074fc119de180  pop rcx
000074fc119de181  pop rax
000074fc119de182  add rsp, 0x08
000074fc119de186  jmp 0x000074FC119DC099
000074fc119de18b  sub rsp, 0x08
000074fc119de18f  push rax
000074fc119de190  push rcx
000074fc119de191  push rdx
000074fc119de192  push rdi
000074fc119de193  push rsi
000074fc119de194  push r8
000074fc119de196  push r9
000074fc119de198  push r10
000074fc119de19a  push r11
000074fc119de19c  sub rsp, 0xF0
000074fc119de1a3  vmovaps [rsp], xmm0
000074fc119de1a8  vmovaps [rsp+0x10], xmm2
000074fc119de1ae  vmovaps [rsp+0x20], xmm3
000074fc119de1b4  vmovaps [rsp+0x30], xmm4
000074fc119de1ba  vmovaps [rsp+0x40], xmm5
000074fc119de1c0  vmovaps [rsp+0x50], xmm6
000074fc119de1c6  vmovaps [rsp+0x60], xmm7
000074fc119de1cc  vmovaps [rsp+0x70], xmm8
000074fc119de1d2  vmovaps [rsp+0x80], xmm9
000074fc119de1db  vmovaps [rsp+0x90], xmm10
000074fc119de1e4  vmovaps [rsp+0xA0], xmm11
000074fc119de1ed  vmovaps [rsp+0xB0], xmm12
000074fc119de1f6  vmovaps [rsp+0xC0], xmm13
000074fc119de1ff  vmovaps [rsp+0xD0], xmm14
000074fc119de208  vmovaps [rsp+0xE0], xmm15
000074fc119de211  sub rsp, 0x30
000074fc119de215  movaps [rsp], xmm1
000074fc119de219  movaps [rsp+0x10], xmm5
000074fc119de21e  movaps [rsp+0x20], xmm4
000074fc119de223  lea rdi, [rsp]
000074fc119de227  mov esi, 0x00
000074fc119de22c  mov rax, 0x58C4C8091530
000074fc119de236  call rax
000074fc119de238  movaps xmm1, [rsp]
000074fc119de23c  add rsp, 0x30
000074fc119de240  vmovaps xmm0, [rsp]
000074fc119de245  vmovaps xmm2, [rsp+0x10]
000074fc119de24b  vmovaps xmm3, [rsp+0x20]
000074fc119de251  vmovaps xmm4, [rsp+0x30]
000074fc119de257  vmovaps xmm5, [rsp+0x40]
000074fc119de25d  vmovaps xmm6, [rsp+0x50]
000074fc119de263  vmovaps xmm7, [rsp+0x60]
000074fc119de269  vmovaps xmm8, [rsp+0x70]
000074fc119de26f  vmovaps xmm9, [rsp+0x80]
000074fc119de278  vmovaps xmm10, [rsp+0x90]
000074fc119de281  vmovaps xmm11, [rsp+0xA0]
000074fc119de28a  vmovaps xmm12, [rsp+0xB0]
000074fc119de293  vmovaps xmm13, [rsp+0xC0]
000074fc119de29c  vmovaps xmm14, [rsp+0xD0]
000074fc119de2a5  vmovaps xmm15, [rsp+0xE0]
000074fc119de2ae  add rsp, 0xF0
000074fc119de2b5  pop r11
000074fc119de2b7  pop r10
000074fc119de2b9  pop r9
000074fc119de2bb  pop r8
000074fc119de2bd  pop rsi
000074fc119de2be  pop rdi
000074fc119de2bf  pop rdx
000074fc119de2c0  pop rcx
000074fc119de2c1  pop rax
000074fc119de2c2  add rsp, 0x08
000074fc119de2c6  jmp 0x000074FC119DC0B9
000074fc119de2cb  sub rsp, 0x08
000074fc119de2cf  push rax
000074fc119de2d0  push rcx
000074fc119de2d1  push rdx
000074fc119de2d2  push rdi
000074fc119de2d3  push rsi
000074fc119de2d4  push r8
000074fc119de2d6  push r9
000074fc119de2d8  push r10
000074fc119de2da  push r11
000074fc119de2dc  sub rsp, 0xF0
000074fc119de2e3  vmovaps [rsp], xmm0
000074fc119de2e8  vmovaps [rsp+0x10], xmm1
000074fc119de2ee  vmovaps [rsp+0x20], xmm2
000074fc119de2f4  vmovaps [rsp+0x30], xmm3
000074fc119de2fa  vmovaps [rsp+0x40], xmm5
000074fc119de300  vmovaps [rsp+0x50], xmm6
000074fc119de306  vmovaps [rsp+0x60], xmm7
000074fc119de30c  vmovaps [rsp+0x70], xmm8
000074fc119de312  vmovaps [rsp+0x80], xmm9
000074fc119de31b  vmovaps [rsp+0x90], xmm10
000074fc119de324  vmovaps [rsp+0xA0], xmm11
000074fc119de32d  vmovaps [rsp+0xB0], xmm12
000074fc119de336  vmovaps [rsp+0xC0], xmm13
000074fc119de33f  vmovaps [rsp+0xD0], xmm14
000074fc119de348  vmovaps [rsp+0xE0], xmm15
000074fc119de351  sub rsp, 0x30
000074fc119de355  movaps [rsp], xmm4
000074fc119de359  movaps [rsp+0x10], xmm3
000074fc119de35e  movaps [rsp+0x20], xmm5
000074fc119de363  lea rdi, [rsp]
000074fc119de367  mov esi, 0x00
000074fc119de36c  mov rax, 0x58C4C8091530
000074fc119de376  call rax
000074fc119de378  movaps xmm4, [rsp]
000074fc119de37c  add rsp, 0x30
000074fc119de380  vmovaps xmm0, [rsp]
000074fc119de385  vmovaps xmm1, [rsp+0x10]
000074fc119de38b  vmovaps xmm2, [rsp+0x20]
000074fc119de391  vmovaps xmm3, [rsp+0x30]
000074fc119de397  vmovaps xmm5, [rsp+0x40]
000074fc119de39d  vmovaps xmm6, [rsp+0x50]
000074fc119de3a3  vmovaps xmm7, [rsp+0x60]
000074fc119de3a9  vmovaps xmm8, [rsp+0x70]
000074fc119de3af  vmovaps xmm9, [rsp+0x80]
000074fc119de3b8  vmovaps xmm10, [rsp+0x90]
000074fc119de3c1  vmovaps xmm11, [rsp+0xA0]
000074fc119de3ca  vmovaps xmm12, [rsp+0xB0]
000074fc119de3d3  vmovaps xmm13, [rsp+0xC0]
000074fc119de3dc  vmovaps xmm14, [rsp+0xD0]
000074fc119de3e5  vmovaps xmm15, [rsp+0xE0]
000074fc119de3ee  add rsp, 0xF0
000074fc119de3f5  pop r11
000074fc119de3f7  pop r10
000074fc119de3f9  pop r9
000074fc119de3fb  pop r8
000074fc119de3fd  pop rsi
000074fc119de3fe  pop rdi
000074fc119de3ff  pop rdx
000074fc119de400  pop rcx
000074fc119de401  pop rax
000074fc119de402  add rsp, 0x08
000074fc119de406  jmp 0x000074FC119DC107
000074fc119de40b  call 0x000074FC118B52F0
000074fc119de410  jmp 0x000074FC119DC114
000074fc119de415  sub rsp, 0x08
000074fc119de419  push rax
000074fc119de41a  push rcx
000074fc119de41b  push rdx
000074fc119de41c  push rdi
000074fc119de41d  push rsi
000074fc119de41e  push r8
000074fc119de420  push r9
000074fc119de422  push r10
000074fc119de424  push r11
000074fc119de426  sub rsp, 0xF0
000074fc119de42d  vmovaps [rsp], xmm0
000074fc119de432  vmovaps [rsp+0x10], xmm1
000074fc119de438  vmovaps [rsp+0x20], xmm2
000074fc119de43e  vmovaps [rsp+0x30], xmm3
000074fc119de444  vmovaps [rsp+0x40], xmm4
000074fc119de44a  vmovaps [rsp+0x50], xmm6
000074fc119de450  vmovaps [rsp+0x60], xmm7
000074fc119de456  vmovaps [rsp+0x70], xmm8
000074fc119de45c  vmovaps [rsp+0x80], xmm9
000074fc119de465  vmovaps [rsp+0x90], xmm10
000074fc119de46e  vmovaps [rsp+0xA0], xmm11
000074fc119de477  vmovaps [rsp+0xB0], xmm12
000074fc119de480  vmovaps [rsp+0xC0], xmm13
000074fc119de489  vmovaps [rsp+0xD0], xmm14
000074fc119de492  vmovaps [rsp+0xE0], xmm15
000074fc119de49b  sub rsp, 0x30
000074fc119de49f  movaps [rsp], xmm5
000074fc119de4a3  movaps [rsp+0x10], xmm6
000074fc119de4a8  movaps [rsp+0x20], xmm3
000074fc119de4ad  lea rdi, [rsp]
000074fc119de4b1  mov esi, 0x00
000074fc119de4b6  mov rax, 0x58C4C8091530
000074fc119de4c0  call rax
000074fc119de4c2  movaps xmm5, [rsp]
000074fc119de4c6  add rsp, 0x30
000074fc119de4ca  vmovaps xmm0, [rsp]
000074fc119de4cf  vmovaps xmm1, [rsp+0x10]
000074fc119de4d5  vmovaps xmm2, [rsp+0x20]
000074fc119de4db  vmovaps xmm3, [rsp+0x30]
000074fc119de4e1  vmovaps xmm4, [rsp+0x40]
000074fc119de4e7  vmovaps xmm6, [rsp+0x50]
000074fc119de4ed  vmovaps xmm7, [rsp+0x60]
000074fc119de4f3  vmovaps xmm8, [rsp+0x70]
000074fc119de4f9  vmovaps xmm9, [rsp+0x80]
000074fc119de502  vmovaps xmm10, [rsp+0x90]
000074fc119de50b  vmovaps xmm11, [rsp+0xA0]
000074fc119de514  vmovaps xmm12, [rsp+0xB0]
000074fc119de51d  vmovaps xmm13, [rsp+0xC0]
000074fc119de526  vmovaps xmm14, [rsp+0xD0]
000074fc119de52f  vmovaps xmm15, [rsp+0xE0]
000074fc119de538  add rsp, 0xF0
000074fc119de53f  pop r11
000074fc119de541  pop r10
000074fc119de543  pop r9
000074fc119de545  pop r8
000074fc119de547  pop rsi
000074fc119de548  pop rdi
000074fc119de549  pop rdx
000074fc119de54a  pop rcx
000074fc119de54b  pop rax
000074fc119de54c  add rsp, 0x08
000074fc119de550  jmp 0x000074FC119DC13A
000074fc119de555  sub rsp, 0x08
000074fc119de559  push rax
000074fc119de55a  push rcx
000074fc119de55b  push rdx
000074fc119de55c  push rdi
000074fc119de55d  push rsi
000074fc119de55e  push r8
000074fc119de560  push r9
000074fc119de562  push r10
000074fc119de564  push r11
000074fc119de566  sub rsp, 0xF0
000074fc119de56d  vmovaps [rsp], xmm0
000074fc119de572  vmovaps [rsp+0x10], xmm1
000074fc119de578  vmovaps [rsp+0x20], xmm2
000074fc119de57e  vmovaps [rsp+0x30], xmm3
000074fc119de584  vmovaps [rsp+0x40], xmm4
000074fc119de58a  vmovaps [rsp+0x50], xmm5
000074fc119de590  vmovaps [rsp+0x60], xmm7
000074fc119de596  vmovaps [rsp+0x70], xmm8
000074fc119de59c  vmovaps [rsp+0x80], xmm9
000074fc119de5a5  vmovaps [rsp+0x90], xmm10
000074fc119de5ae  vmovaps [rsp+0xA0], xmm11
000074fc119de5b7  vmovaps [rsp+0xB0], xmm12
000074fc119de5c0  vmovaps [rsp+0xC0], xmm13
000074fc119de5c9  vmovaps [rsp+0xD0], xmm14
000074fc119de5d2  vmovaps [rsp+0xE0], xmm15
000074fc119de5db  sub rsp, 0x30
000074fc119de5df  movaps [rsp], xmm6
000074fc119de5e3  movaps [rsp+0x10], xmm9
000074fc119de5e9  movaps [rsp+0x20], xmm1
000074fc119de5ee  lea rdi, [rsp]
000074fc119de5f2  mov esi, 0x00
000074fc119de5f7  mov rax, 0x58C4C8091530
000074fc119de601  call rax
000074fc119de603  movaps xmm6, [rsp]
000074fc119de607  add rsp, 0x30
000074fc119de60b  vmovaps xmm0, [rsp]
000074fc119de610  vmovaps xmm1, [rsp+0x10]
000074fc119de616  vmovaps xmm2, [rsp+0x20]
000074fc119de61c  vmovaps xmm3, [rsp+0x30]
000074fc119de622  vmovaps xmm4, [rsp+0x40]
000074fc119de628  vmovaps xmm5, [rsp+0x50]
000074fc119de62e  vmovaps xmm7, [rsp+0x60]
000074fc119de634  vmovaps xmm8, [rsp+0x70]
000074fc119de63a  vmovaps xmm9, [rsp+0x80]
000074fc119de643  vmovaps xmm10, [rsp+0x90]
000074fc119de64c  vmovaps xmm11, [rsp+0xA0]
000074fc119de655  vmovaps xmm12, [rsp+0xB0]
000074fc119de65e  vmovaps xmm13, [rsp+0xC0]
000074fc119de667  vmovaps xmm14, [rsp+0xD0]
000074fc119de670  vmovaps xmm15, [rsp+0xE0]
000074fc119de679  add rsp, 0xF0
000074fc119de680  pop r11
000074fc119de682  pop r10
000074fc119de684  pop r9
000074fc119de686  pop r8
000074fc119de688  pop rsi
000074fc119de689  pop rdi
000074fc119de68a  pop rdx
000074fc119de68b  pop rcx
000074fc119de68c  pop rax
000074fc119de68d  add rsp, 0x08
000074fc119de691  jmp 0x000074FC119DC15E
000074fc119de696  sub rsp, 0x08
000074fc119de69a  push rax
000074fc119de69b  push rcx
000074fc119de69c  push rdx
000074fc119de69d  push rdi
000074fc119de69e  push rsi
000074fc119de69f  push r8
000074fc119de6a1  push r9
000074fc119de6a3  push r10
000074fc119de6a5  push r11
000074fc119de6a7  sub rsp, 0xF0
000074fc119de6ae  vmovaps [rsp], xmm0
000074fc119de6b3  vmovaps [rsp+0x10], xmm1
000074fc119de6b9  vmovaps [rsp+0x20], xmm2
000074fc119de6bf  vmovaps [rsp+0x30], xmm3
000074fc119de6c5  vmovaps [rsp+0x40], xmm4
000074fc119de6cb  vmovaps [rsp+0x50], xmm5
000074fc119de6d1  vmovaps [rsp+0x60], xmm6
000074fc119de6d7  vmovaps [rsp+0x70], xmm7
000074fc119de6dd  vmovaps [rsp+0x80], xmm8
000074fc119de6e6  vmovaps [rsp+0x90], xmm10
000074fc119de6ef  vmovaps [rsp+0xA0], xmm11
000074fc119de6f8  vmovaps [rsp+0xB0], xmm12
000074fc119de701  vmovaps [rsp+0xC0], xmm13
000074fc119de70a  vmovaps [rsp+0xD0], xmm14
000074fc119de713  vmovaps [rsp+0xE0], xmm15
000074fc119de71c  sub rsp, 0x30
000074fc119de720  movaps [rsp], xmm9
000074fc119de725  movaps [rsp+0x10], xmm3
000074fc119de72a  movaps [rsp+0x20], xmm1
000074fc119de72f  lea rdi, [rsp]
000074fc119de733  mov esi, 0x00
000074fc119de738  mov rax, 0x58C4C8091530
000074fc119de742  call rax
000074fc119de744  movaps xmm9, [rsp]
000074fc119de749  add rsp, 0x30
000074fc119de74d  vmovaps xmm0, [rsp]
000074fc119de752  vmovaps xmm1, [rsp+0x10]
000074fc119de758  vmovaps xmm2, [rsp+0x20]
000074fc119de75e  vmovaps xmm3, [rsp+0x30]
000074fc119de764  vmovaps xmm4, [rsp+0x40]
000074fc119de76a  vmovaps xmm5, [rsp+0x50]
000074fc119de770  vmovaps xmm6, [rsp+0x60]
000074fc119de776  vmovaps xmm7, [rsp+0x70]
000074fc119de77c  vmovaps xmm8, [rsp+0x80]
000074fc119de785  vmovaps xmm10, [rsp+0x90]
000074fc119de78e  vmovaps xmm11, [rsp+0xA0]
000074fc119de797  vmovaps xmm12, [rsp+0xB0]
000074fc119de7a0  vmovaps xmm13, [rsp+0xC0]
000074fc119de7a9  vmovaps xmm14, [rsp+0xD0]
000074fc119de7b2  vmovaps xmm15, [rsp+0xE0]
000074fc119de7bb  add rsp, 0xF0
000074fc119de7c2  pop r11
000074fc119de7c4  pop r10
000074fc119de7c6  pop r9
000074fc119de7c8  pop r8
000074fc119de7ca  pop rsi
000074fc119de7cb  pop rdi
000074fc119de7cc  pop rdx
000074fc119de7cd  pop rcx
000074fc119de7ce  pop rax
000074fc119de7cf  add rsp, 0x08
000074fc119de7d3  jmp 0x000074FC119DC1AA
000074fc119de7d8  call 0x000074FC118B52F0
000074fc119de7dd  jmp 0x000074FC119DC1B7
000074fc119de7e2  sub rsp, 0x08
000074fc119de7e6  push rax
000074fc119de7e7  push rcx
000074fc119de7e8  push rdx
000074fc119de7e9  push rdi
000074fc119de7ea  push rsi
000074fc119de7eb  push r8
000074fc119de7ed  push r9
000074fc119de7ef  push r10
000074fc119de7f1  push r11
000074fc119de7f3  sub rsp, 0xF0
000074fc119de7fa  vmovaps [rsp], xmm0
000074fc119de7ff  vmovaps [rsp+0x10], xmm1
000074fc119de805  vmovaps [rsp+0x20], xmm2
000074fc119de80b  vmovaps [rsp+0x30], xmm3
000074fc119de811  vmovaps [rsp+0x40], xmm4
000074fc119de817  vmovaps [rsp+0x50], xmm5
000074fc119de81d  vmovaps [rsp+0x60], xmm6
000074fc119de823  vmovaps [rsp+0x70], xmm7
000074fc119de829  vmovaps [rsp+0x80], xmm8
000074fc119de832  vmovaps [rsp+0x90], xmm9
000074fc119de83b  vmovaps [rsp+0xA0], xmm10
000074fc119de844  vmovaps [rsp+0xB0], xmm11
000074fc119de84d  vmovaps [rsp+0xC0], xmm12
000074fc119de856  vmovaps [rsp+0xD0], xmm13
000074fc119de85f  vmovaps [rsp+0xE0], xmm14
000074fc119de868  sub rsp, 0x30
000074fc119de86c  movaps [rsp], xmm15
000074fc119de871  movaps [rsp+0x10], xmm3
000074fc119de876  movaps [rsp+0x20], xmm7
000074fc119de87b  lea rdi, [rsp]
000074fc119de87f  mov esi, 0x00
000074fc119de884  mov rax, 0x58C4C8091530
000074fc119de88e  call rax
000074fc119de890  movaps xmm15, [rsp]
000074fc119de895  add rsp, 0x30
000074fc119de899  vmovaps xmm0, [rsp]
000074fc119de89e  vmovaps xmm1, [rsp+0x10]
000074fc119de8a4  vmovaps xmm2, [rsp+0x20]
000074fc119de8aa  vmovaps xmm3, [rsp+0x30]
000074fc119de8b0  vmovaps xmm4, [rsp+0x40]
000074fc119de8b6  vmovaps xmm5, [rsp+0x50]
000074fc119de8bc  vmovaps xmm6, [rsp+0x60]
000074fc119de8c2  vmovaps xmm7, [rsp+0x70]
000074fc119de8c8  vmovaps xmm8, [rsp+0x80]
000074fc119de8d1  vmovaps xmm9, [rsp+0x90]
000074fc119de8da  vmovaps xmm10, [rsp+0xA0]
000074fc119de8e3  vmovaps xmm11, [rsp+0xB0]
000074fc119de8ec  vmovaps xmm12, [rsp+0xC0]
000074fc119de8f5  vmovaps xmm13, [rsp+0xD0]
000074fc119de8fe  vmovaps xmm14, [rsp+0xE0]
000074fc119de907  add rsp, 0xF0
000074fc119de90e  pop r11
000074fc119de910  pop r10
000074fc119de912  pop r9
000074fc119de914  pop r8
000074fc119de916  pop rsi
000074fc119de917  pop rdi
000074fc119de918  pop rdx
000074fc119de919  pop rcx
000074fc119de91a  pop rax
000074fc119de91b  add rsp, 0x08
000074fc119de91f  jmp 0x000074FC119DC1E3
000074fc119de924  sub rsp, 0x08
000074fc119de928  push rax
000074fc119de929  push rcx
000074fc119de92a  push rdx
000074fc119de92b  push rdi
000074fc119de92c  push rsi
000074fc119de92d  push r8
000074fc119de92f  push r9
000074fc119de931  push r10
000074fc119de933  push r11
000074fc119de935  sub rsp, 0xF0
000074fc119de93c  vmovaps [rsp], xmm0
000074fc119de941  vmovaps [rsp+0x10], xmm1
000074fc119de947  vmovaps [rsp+0x20], xmm2
000074fc119de94d  vmovaps [rsp+0x30], xmm4
000074fc119de953  vmovaps [rsp+0x40], xmm5
000074fc119de959  vmovaps [rsp+0x50], xmm6
000074fc119de95f  vmovaps [rsp+0x60], xmm7
000074fc119de965  vmovaps [rsp+0x70], xmm8
000074fc119de96b  vmovaps [rsp+0x80], xmm9
000074fc119de974  vmovaps [rsp+0x90], xmm10
000074fc119de97d  vmovaps [rsp+0xA0], xmm11
000074fc119de986  vmovaps [rsp+0xB0], xmm12
000074fc119de98f  vmovaps [rsp+0xC0], xmm13
000074fc119de998  vmovaps [rsp+0xD0], xmm14
000074fc119de9a1  vmovaps [rsp+0xE0], xmm15
000074fc119de9aa  sub rsp, 0x30
000074fc119de9ae  movaps [rsp], xmm3
000074fc119de9b2  movaps [rsp+0x10], xmm1
000074fc119de9b7  movaps [rsp+0x20], xmm15
000074fc119de9bd  lea rdi, [rsp]
000074fc119de9c1  mov esi, 0x00
000074fc119de9c6  mov rax, 0x58C4C8091530
000074fc119de9d0  call rax
000074fc119de9d2  movaps xmm3, [rsp]
000074fc119de9d6  add rsp, 0x30
000074fc119de9da  vmovaps xmm0, [rsp]
000074fc119de9df  vmovaps xmm1, [rsp+0x10]
000074fc119de9e5  vmovaps xmm2, [rsp+0x20]
000074fc119de9eb  vmovaps xmm4, [rsp+0x30]
000074fc119de9f1  vmovaps xmm5, [rsp+0x40]
000074fc119de9f7  vmovaps xmm6, [rsp+0x50]
000074fc119de9fd  vmovaps xmm7, [rsp+0x60]
000074fc119dea03  vmovaps xmm8, [rsp+0x70]
000074fc119dea09  vmovaps xmm9, [rsp+0x80]
000074fc119dea12  vmovaps xmm10, [rsp+0x90]
000074fc119dea1b  vmovaps xmm11, [rsp+0xA0]
000074fc119dea24  vmovaps xmm12, [rsp+0xB0]
000074fc119dea2d  vmovaps xmm13, [rsp+0xC0]
000074fc119dea36  vmovaps xmm14, [rsp+0xD0]
000074fc119dea3f  vmovaps xmm15, [rsp+0xE0]
000074fc119dea48  add rsp, 0xF0
000074fc119dea4f  pop r11
000074fc119dea51  pop r10
000074fc119dea53  pop r9
000074fc119dea55  pop r8
000074fc119dea57  pop rsi
000074fc119dea58  pop rdi
000074fc119dea59  pop rdx
000074fc119dea5a  pop rcx
000074fc119dea5b  pop rax
000074fc119dea5c  add rsp, 0x08
000074fc119dea60  jmp 0x000074FC119DC272
000074fc119dea65  call 0x000074FC118B52F0
000074fc119dea6a  jmp 0x000074FC119DC27C
000074fc119dea6f  sub rsp, 0x08
000074fc119dea73  push rax
000074fc119dea74  push rcx
000074fc119dea75  push rdx
000074fc119dea76  push rdi
000074fc119dea77  push rsi
000074fc119dea78  push r8
000074fc119dea7a  push r9
000074fc119dea7c  push r10
000074fc119dea7e  push r11
000074fc119dea80  sub rsp, 0xF0
000074fc119dea87  vmovaps [rsp], xmm0
000074fc119dea8c  vmovaps [rsp+0x10], xmm1
000074fc119dea92  vmovaps [rsp+0x20], xmm2
000074fc119dea98  vmovaps [rsp+0x30], xmm3
000074fc119dea9e  vmovaps [rsp+0x40], xmm4
000074fc119deaa4  vmovaps [rsp+0x50], xmm5
000074fc119deaaa  vmovaps [rsp+0x60], xmm6
000074fc119deab0  vmovaps [rsp+0x70], xmm7
000074fc119deab6  vmovaps [rsp+0x80], xmm8
000074fc119deabf  vmovaps [rsp+0x90], xmm9
000074fc119deac8  vmovaps [rsp+0xA0], xmm10
000074fc119dead1  vmovaps [rsp+0xB0], xmm11
000074fc119deada  vmovaps [rsp+0xC0], xmm12
000074fc119deae3  vmovaps [rsp+0xD0], xmm13
000074fc119deaec  vmovaps [rsp+0xE0], xmm14
000074fc119deaf5  sub rsp, 0x30
000074fc119deaf9  movaps [rsp], xmm15
000074fc119deafe  movaps [rsp+0x10], xmm14
000074fc119deb04  movaps [rsp+0x20], xmm4
000074fc119deb09  lea rdi, [rsp]
000074fc119deb0d  mov esi, 0x00
000074fc119deb12  mov rax, 0x58C4C8091530
000074fc119deb1c  call rax
000074fc119deb1e  movaps xmm15, [rsp]
000074fc119deb23  add rsp, 0x30
000074fc119deb27  vmovaps xmm0, [rsp]
000074fc119deb2c  vmovaps xmm1, [rsp+0x10]
000074fc119deb32  vmovaps xmm2, [rsp+0x20]
000074fc119deb38  vmovaps xmm3, [rsp+0x30]
000074fc119deb3e  vmovaps xmm4, [rsp+0x40]
000074fc119deb44  vmovaps xmm5, [rsp+0x50]
000074fc119deb4a  vmovaps xmm6, [rsp+0x60]
000074fc119deb50  vmovaps xmm7, [rsp+0x70]
000074fc119deb56  vmovaps xmm8, [rsp+0x80]
000074fc119deb5f  vmovaps xmm9, [rsp+0x90]
000074fc119deb68  vmovaps xmm10, [rsp+0xA0]
000074fc119deb71  vmovaps xmm11, [rsp+0xB0]
000074fc119deb7a  vmovaps xmm12, [rsp+0xC0]
000074fc119deb83  vmovaps xmm13, [rsp+0xD0]
000074fc119deb8c  vmovaps xmm14, [rsp+0xE0]
000074fc119deb95  add rsp, 0xF0
000074fc119deb9c  pop r11
000074fc119deb9e  pop r10
000074fc119deba0  pop r9
000074fc119deba2  pop r8
000074fc119deba4  pop rsi
000074fc119deba5  pop rdi
000074fc119deba6  pop rdx
000074fc119deba7  pop rcx
000074fc119deba8  pop rax
000074fc119deba9  add rsp, 0x08
000074fc119debad  jmp 0x000074FC119DC2AA
000074fc119debb2  sub rsp, 0x08
000074fc119debb6  push rax
000074fc119debb7  push rcx
000074fc119debb8  push rdx
000074fc119debb9  push rdi
000074fc119debba  push rsi
000074fc119debbb  push r8
000074fc119debbd  push r9
000074fc119debbf  push r10
000074fc119debc1  push r11
000074fc119debc3  sub rsp, 0xF0
000074fc119debca  vmovaps [rsp], xmm0
000074fc119debcf  vmovaps [rsp+0x10], xmm1
000074fc119debd5  vmovaps [rsp+0x20], xmm2
000074fc119debdb  vmovaps [rsp+0x30], xmm3
000074fc119debe1  vmovaps [rsp+0x40], xmm4
000074fc119debe7  vmovaps [rsp+0x50], xmm5
000074fc119debed  vmovaps [rsp+0x60], xmm6
000074fc119debf3  vmovaps [rsp+0x70], xmm7
000074fc119debf9  vmovaps [rsp+0x80], xmm8
000074fc119dec02  vmovaps [rsp+0x90], xmm9
000074fc119dec0b  vmovaps [rsp+0xA0], xmm10
000074fc119dec14  vmovaps [rsp+0xB0], xmm11
000074fc119dec1d  vmovaps [rsp+0xC0], xmm12
000074fc119dec26  vmovaps [rsp+0xD0], xmm13
000074fc119dec2f  vmovaps [rsp+0xE0], xmm15
000074fc119dec38  sub rsp, 0x30
000074fc119dec3c  movaps [rsp], xmm14
000074fc119dec41  movaps [rsp+0x10], xmm2
000074fc119dec46  movaps [rsp+0x20], xmm1
000074fc119dec4b  lea rdi, [rsp]
000074fc119dec4f  mov esi, 0x00
000074fc119dec54  mov rax, 0x58C4C8091530
000074fc119dec5e  call rax
000074fc119dec60  movaps xmm14, [rsp]
000074fc119dec65  add rsp, 0x30
000074fc119dec69  vmovaps xmm0, [rsp]
000074fc119dec6e  vmovaps xmm1, [rsp+0x10]
000074fc119dec74  vmovaps xmm2, [rsp+0x20]
000074fc119dec7a  vmovaps xmm3, [rsp+0x30]
000074fc119dec80  vmovaps xmm4, [rsp+0x40]
000074fc119dec86  vmovaps xmm5, [rsp+0x50]
000074fc119dec8c  vmovaps xmm6, [rsp+0x60]
000074fc119dec92  vmovaps xmm7, [rsp+0x70]
000074fc119dec98  vmovaps xmm8, [rsp+0x80]
000074fc119deca1  vmovaps xmm9, [rsp+0x90]
000074fc119decaa  vmovaps xmm10, [rsp+0xA0]
000074fc119decb3  vmovaps xmm11, [rsp+0xB0]
000074fc119decbc  vmovaps xmm12, [rsp+0xC0]
000074fc119decc5  vmovaps xmm13, [rsp+0xD0]
000074fc119decce  vmovaps xmm15, [rsp+0xE0]
000074fc119decd7  add rsp, 0xF0
000074fc119decde  pop r11
000074fc119dece0  pop r10
000074fc119dece2  pop r9
000074fc119dece4  pop r8
000074fc119dece6  pop rsi
000074fc119dece7  pop rdi
000074fc119dece8  pop rdx
000074fc119dece9  pop rcx
000074fc119decea  pop rax
000074fc119deceb  add rsp, 0x08
000074fc119decef  jmp 0x000074FC119DC2D0
000074fc119decf4  sub rsp, 0x08
000074fc119decf8  push rax
000074fc119decf9  push rcx
000074fc119decfa  push rdx
000074fc119decfb  push rdi
000074fc119decfc  push rsi
000074fc119decfd  push r8
000074fc119decff  push r9
000074fc119ded01  push r10
000074fc119ded03  push r11
000074fc119ded05  sub rsp, 0xF0
000074fc119ded0c  vmovaps [rsp], xmm0
000074fc119ded11  vmovaps [rsp+0x10], xmm2
000074fc119ded17  vmovaps [rsp+0x20], xmm3
000074fc119ded1d  vmovaps [rsp+0x30], xmm4
000074fc119ded23  vmovaps [rsp+0x40], xmm5
000074fc119ded29  vmovaps [rsp+0x50], xmm6
000074fc119ded2f  vmovaps [rsp+0x60], xmm7
000074fc119ded35  vmovaps [rsp+0x70], xmm8
000074fc119ded3b  vmovaps [rsp+0x80], xmm9
000074fc119ded44  vmovaps [rsp+0x90], xmm10
000074fc119ded4d  vmovaps [rsp+0xA0], xmm11
000074fc119ded56  vmovaps [rsp+0xB0], xmm12
000074fc119ded5f  vmovaps [rsp+0xC0], xmm13
000074fc119ded68  vmovaps [rsp+0xD0], xmm14
000074fc119ded71  vmovaps [rsp+0xE0], xmm15
000074fc119ded7a  sub rsp, 0x30
000074fc119ded7e  movaps [rsp], xmm1
000074fc119ded82  movaps [rsp+0x10], xmm4
000074fc119ded87  movaps [rsp+0x20], xmm9
000074fc119ded8d  lea rdi, [rsp]
000074fc119ded91  mov esi, 0x00
000074fc119ded96  mov rax, 0x58C4C8091530
000074fc119deda0  call rax
000074fc119deda2  movaps xmm1, [rsp]
000074fc119deda6  add rsp, 0x30
000074fc119dedaa  vmovaps xmm0, [rsp]
000074fc119dedaf  vmovaps xmm2, [rsp+0x10]
000074fc119dedb5  vmovaps xmm3, [rsp+0x20]
000074fc119dedbb  vmovaps xmm4, [rsp+0x30]
000074fc119dedc1  vmovaps xmm5, [rsp+0x40]
000074fc119dedc7  vmovaps xmm6, [rsp+0x50]
000074fc119dedcd  vmovaps xmm7, [rsp+0x60]
000074fc119dedd3  vmovaps xmm8, [rsp+0x70]
000074fc119dedd9  vmovaps xmm9, [rsp+0x80]
000074fc119dede2  vmovaps xmm10, [rsp+0x90]
000074fc119dedeb  vmovaps xmm11, [rsp+0xA0]
000074fc119dedf4  vmovaps xmm12, [rsp+0xB0]
000074fc119dedfd  vmovaps xmm13, [rsp+0xC0]
000074fc119dee06  vmovaps xmm14, [rsp+0xD0]
000074fc119dee0f  vmovaps xmm15, [rsp+0xE0]
000074fc119dee18  add rsp, 0xF0
000074fc119dee1f  pop r11
000074fc119dee21  pop r10
000074fc119dee23  pop r9
000074fc119dee25  pop r8
000074fc119dee27  pop rsi
000074fc119dee28  pop rdi
000074fc119dee29  pop rdx
000074fc119dee2a  pop rcx
000074fc119dee2b  pop rax
000074fc119dee2c  add rsp, 0x08
000074fc119dee30  jmp 0x000074FC119DC2EE
000074fc119dee35  sub rsp, 0x08
000074fc119dee39  push rax
000074fc119dee3a  push rcx
000074fc119dee3b  push rdx
000074fc119dee3c  push rdi
000074fc119dee3d  push rsi
000074fc119dee3e  push r8
000074fc119dee40  push r9
000074fc119dee42  push r10
000074fc119dee44  push r11
000074fc119dee46  sub rsp, 0xF0
000074fc119dee4d  vmovaps [rsp], xmm0
000074fc119dee52  vmovaps [rsp+0x10], xmm1
000074fc119dee58  vmovaps [rsp+0x20], xmm2
000074fc119dee5e  vmovaps [rsp+0x30], xmm3
000074fc119dee64  vmovaps [rsp+0x40], xmm5
000074fc119dee6a  vmovaps [rsp+0x50], xmm6
000074fc119dee70  vmovaps [rsp+0x60], xmm7
000074fc119dee76  vmovaps [rsp+0x70], xmm8
000074fc119dee7c  vmovaps [rsp+0x80], xmm9
000074fc119dee85  vmovaps [rsp+0x90], xmm10
000074fc119dee8e  vmovaps [rsp+0xA0], xmm11
000074fc119dee97  vmovaps [rsp+0xB0], xmm12
000074fc119deea0  vmovaps [rsp+0xC0], xmm13
000074fc119deea9  vmovaps [rsp+0xD0], xmm14
000074fc119deeb2  vmovaps [rsp+0xE0], xmm15
000074fc119deebb  sub rsp, 0x30
000074fc119deebf  movaps [rsp], xmm4
000074fc119deec3  movaps [rsp+0x10], xmm2
000074fc119deec8  movaps [rsp+0x20], xmm9
000074fc119deece  lea rdi, [rsp]
000074fc119deed2  mov esi, 0x00
000074fc119deed7  mov rax, 0x58C4C8091530
000074fc119deee1  call rax
000074fc119deee3  movaps xmm4, [rsp]
000074fc119deee7  add rsp, 0x30
000074fc119deeeb  vmovaps xmm0, [rsp]
000074fc119deef0  vmovaps xmm1, [rsp+0x10]
000074fc119deef6  vmovaps xmm2, [rsp+0x20]
000074fc119deefc  vmovaps xmm3, [rsp+0x30]
000074fc119def02  vmovaps xmm5, [rsp+0x40]
000074fc119def08  vmovaps xmm6, [rsp+0x50]
000074fc119def0e  vmovaps xmm7, [rsp+0x60]
000074fc119def14  vmovaps xmm8, [rsp+0x70]
000074fc119def1a  vmovaps xmm9, [rsp+0x80]
000074fc119def23  vmovaps xmm10, [rsp+0x90]
000074fc119def2c  vmovaps xmm11, [rsp+0xA0]
000074fc119def35  vmovaps xmm12, [rsp+0xB0]
000074fc119def3e  vmovaps xmm13, [rsp+0xC0]
000074fc119def47  vmovaps xmm14, [rsp+0xD0]
000074fc119def50  vmovaps xmm15, [rsp+0xE0]
000074fc119def59  add rsp, 0xF0
000074fc119def60  pop r11
000074fc119def62  pop r10
000074fc119def64  pop r9
000074fc119def66  pop r8
000074fc119def68  pop rsi
000074fc119def69  pop rdi
000074fc119def6a  pop rdx
000074fc119def6b  pop rcx
000074fc119def6c  pop rax
000074fc119def6d  add rsp, 0x08
000074fc119def71  jmp 0x000074FC119DC31E
000074fc119def76  sub rsp, 0x08
000074fc119def7a  push rax
000074fc119def7b  push rcx
000074fc119def7c  push rdx
000074fc119def7d  push rdi
000074fc119def7e  push rsi
000074fc119def7f  push r8
000074fc119def81  push r9
000074fc119def83  push r10
000074fc119def85  push r11
000074fc119def87  sub rsp, 0xF0
000074fc119def8e  vmovaps [rsp], xmm0
000074fc119def93  vmovaps [rsp+0x10], xmm1
000074fc119def99  vmovaps [rsp+0x20], xmm2
000074fc119def9f  vmovaps [rsp+0x30], xmm3
000074fc119defa5  vmovaps [rsp+0x40], xmm4
000074fc119defab  vmovaps [rsp+0x50], xmm5
000074fc119defb1  vmovaps [rsp+0x60], xmm6
000074fc119defb7  vmovaps [rsp+0x70], xmm7
000074fc119defbd  vmovaps [rsp+0x80], xmm8
000074fc119defc6  vmovaps [rsp+0x90], xmm10
000074fc119defcf  vmovaps [rsp+0xA0], xmm11
000074fc119defd8  vmovaps [rsp+0xB0], xmm12
000074fc119defe1  vmovaps [rsp+0xC0], xmm13
000074fc119defea  vmovaps [rsp+0xD0], xmm14
000074fc119deff3  vmovaps [rsp+0xE0], xmm15
000074fc119deffc  sub rsp, 0x30
000074fc119df000  movaps [rsp], xmm9
000074fc119df005  movaps [rsp+0x10], xmm2
000074fc119df00a  movaps [rsp+0x20], xmm1
000074fc119df00f  lea rdi, [rsp]
000074fc119df013  mov esi, 0x00
000074fc119df018  mov rax, 0x58C4C8091530
000074fc119df022  call rax
000074fc119df024  movaps xmm9, [rsp]
000074fc119df029  add rsp, 0x30
000074fc119df02d  vmovaps xmm0, [rsp]
000074fc119df032  vmovaps xmm1, [rsp+0x10]
000074fc119df038  vmovaps xmm2, [rsp+0x20]
000074fc119df03e  vmovaps xmm3, [rsp+0x30]
000074fc119df044  vmovaps xmm4, [rsp+0x40]
000074fc119df04a  vmovaps xmm5, [rsp+0x50]
000074fc119df050  vmovaps xmm6, [rsp+0x60]
000074fc119df056  vmovaps xmm7, [rsp+0x70]
000074fc119df05c  vmovaps xmm8, [rsp+0x80]
000074fc119df065  vmovaps xmm10, [rsp+0x90]
000074fc119df06e  vmovaps xmm11, [rsp+0xA0]
000074fc119df077  vmovaps xmm12, [rsp+0xB0]
000074fc119df080  vmovaps xmm13, [rsp+0xC0]
000074fc119df089  vmovaps xmm14, [rsp+0xD0]
000074fc119df092  vmovaps xmm15, [rsp+0xE0]
000074fc119df09b  add rsp, 0xF0
000074fc119df0a2  pop r11
000074fc119df0a4  pop r10
000074fc119df0a6  pop r9
000074fc119df0a8  pop r8
000074fc119df0aa  pop rsi
000074fc119df0ab  pop rdi
000074fc119df0ac  pop rdx
000074fc119df0ad  pop rcx
000074fc119df0ae  pop rax
000074fc119df0af  add rsp, 0x08
000074fc119df0b3  jmp 0x000074FC119DC354
000074fc119df0b8  sub rsp, 0x08
000074fc119df0bc  push rax
000074fc119df0bd  push rcx
000074fc119df0be  push rdx
000074fc119df0bf  push rdi
000074fc119df0c0  push rsi
000074fc119df0c1  push r8
000074fc119df0c3  push r9
000074fc119df0c5  push r10
000074fc119df0c7  push r11
000074fc119df0c9  sub rsp, 0xF0
000074fc119df0d0  vmovaps [rsp], xmm0
000074fc119df0d5  vmovaps [rsp+0x10], xmm2
000074fc119df0db  vmovaps [rsp+0x20], xmm3
000074fc119df0e1  vmovaps [rsp+0x30], xmm4
000074fc119df0e7  vmovaps [rsp+0x40], xmm5
000074fc119df0ed  vmovaps [rsp+0x50], xmm6
000074fc119df0f3  vmovaps [rsp+0x60], xmm7
000074fc119df0f9  vmovaps [rsp+0x70], xmm8
000074fc119df0ff  vmovaps [rsp+0x80], xmm9
000074fc119df108  vmovaps [rsp+0x90], xmm10
000074fc119df111  vmovaps [rsp+0xA0], xmm11
000074fc119df11a  vmovaps [rsp+0xB0], xmm12
000074fc119df123  vmovaps [rsp+0xC0], xmm13
000074fc119df12c  vmovaps [rsp+0xD0], xmm14
000074fc119df135  vmovaps [rsp+0xE0], xmm15
000074fc119df13e  sub rsp, 0x30
000074fc119df142  movaps [rsp], xmm1
000074fc119df146  movaps [rsp+0x10], xmm15
000074fc119df14c  movaps [rsp+0x20], xmm6
000074fc119df151  lea rdi, [rsp]
000074fc119df155  mov esi, 0x00
000074fc119df15a  mov rax, 0x58C4C8091530
000074fc119df164  call rax
000074fc119df166  movaps xmm1, [rsp]
000074fc119df16a  add rsp, 0x30
000074fc119df16e  vmovaps xmm0, [rsp]
000074fc119df173  vmovaps xmm2, [rsp+0x10]
000074fc119df179  vmovaps xmm3, [rsp+0x20]
000074fc119df17f  vmovaps xmm4, [rsp+0x30]
000074fc119df185  vmovaps xmm5, [rsp+0x40]
000074fc119df18b  vmovaps xmm6, [rsp+0x50]
000074fc119df191  vmovaps xmm7, [rsp+0x60]
000074fc119df197  vmovaps xmm8, [rsp+0x70]
000074fc119df19d  vmovaps xmm9, [rsp+0x80]
000074fc119df1a6  vmovaps xmm10, [rsp+0x90]
000074fc119df1af  vmovaps xmm11, [rsp+0xA0]
000074fc119df1b8  vmovaps xmm12, [rsp+0xB0]
000074fc119df1c1  vmovaps xmm13, [rsp+0xC0]
000074fc119df1ca  vmovaps xmm14, [rsp+0xD0]
000074fc119df1d3  vmovaps xmm15, [rsp+0xE0]
000074fc119df1dc  add rsp, 0xF0
000074fc119df1e3  pop r11
000074fc119df1e5  pop r10
000074fc119df1e7  pop r9
000074fc119df1e9  pop r8
000074fc119df1eb  pop rsi
000074fc119df1ec  pop rdi
000074fc119df1ed  pop rdx
000074fc119df1ee  pop rcx
000074fc119df1ef  pop rax
000074fc119df1f0  add rsp, 0x08
000074fc119df1f4  jmp 0x000074FC119DC375
000074fc119df1f9  sub rsp, 0x08
000074fc119df1fd  push rax
000074fc119df1fe  push rcx
000074fc119df1ff  push rdx
000074fc119df200  push rdi
000074fc119df201  push rsi
000074fc119df202  push r8
000074fc119df204  push r9
000074fc119df206  push r10
000074fc119df208  push r11
000074fc119df20a  sub rsp, 0xF0
000074fc119df211  vmovaps [rsp], xmm0
000074fc119df216  vmovaps [rsp+0x10], xmm1
000074fc119df21c  vmovaps [rsp+0x20], xmm2
000074fc119df222  vmovaps [rsp+0x30], xmm3
000074fc119df228  vmovaps [rsp+0x40], xmm4
000074fc119df22e  vmovaps [rsp+0x50], xmm5
000074fc119df234  vmovaps [rsp+0x60], xmm6
000074fc119df23a  vmovaps [rsp+0x70], xmm7
000074fc119df240  vmovaps [rsp+0x80], xmm8
000074fc119df249  vmovaps [rsp+0x90], xmm9
000074fc119df252  vmovaps [rsp+0xA0], xmm10
000074fc119df25b  vmovaps [rsp+0xB0], xmm11
000074fc119df264  vmovaps [rsp+0xC0], xmm12
000074fc119df26d  vmovaps [rsp+0xD0], xmm13
000074fc119df276  vmovaps [rsp+0xE0], xmm14
000074fc119df27f  sub rsp, 0x30
000074fc119df283  movaps [rsp], xmm15
000074fc119df288  movaps [rsp+0x10], xmm5
000074fc119df28d  movaps [rsp+0x20], xmm3
000074fc119df292  lea rdi, [rsp]
000074fc119df296  mov esi, 0x00
000074fc119df29b  mov rax, 0x58C4C8091530
000074fc119df2a5  call rax
000074fc119df2a7  movaps xmm15, [rsp]
000074fc119df2ac  add rsp, 0x30
000074fc119df2b0  vmovaps xmm0, [rsp]
000074fc119df2b5  vmovaps xmm1, [rsp+0x10]
000074fc119df2bb  vmovaps xmm2, [rsp+0x20]
000074fc119df2c1  vmovaps xmm3, [rsp+0x30]
000074fc119df2c7  vmovaps xmm4, [rsp+0x40]
000074fc119df2cd  vmovaps xmm5, [rsp+0x50]
000074fc119df2d3  vmovaps xmm6, [rsp+0x60]
000074fc119df2d9  vmovaps xmm7, [rsp+0x70]
000074fc119df2df  vmovaps xmm8, [rsp+0x80]
000074fc119df2e8  vmovaps xmm9, [rsp+0x90]
000074fc119df2f1  vmovaps xmm10, [rsp+0xA0]
000074fc119df2fa  vmovaps xmm11, [rsp+0xB0]
000074fc119df303  vmovaps xmm12, [rsp+0xC0]
000074fc119df30c  vmovaps xmm13, [rsp+0xD0]
000074fc119df315  vmovaps xmm14, [rsp+0xE0]
000074fc119df31e  add rsp, 0xF0
000074fc119df325  pop r11
000074fc119df327  pop r10
000074fc119df329  pop r9
000074fc119df32b  pop r8
000074fc119df32d  pop rsi
000074fc119df32e  pop rdi
000074fc119df32f  pop rdx
000074fc119df330  pop rcx
000074fc119df331  pop rax
000074fc119df332  add rsp, 0x08
000074fc119df336  jmp 0x000074FC119DC38F
000074fc119df33b  sub rsp, 0x08
000074fc119df33f  push rax
000074fc119df340  push rcx
000074fc119df341  push rdx
000074fc119df342  push rdi
000074fc119df343  push rsi
000074fc119df344  push r8
000074fc119df346  push r9
000074fc119df348  push r10
000074fc119df34a  push r11
000074fc119df34c  sub rsp, 0xF0
000074fc119df353  vmovaps [rsp], xmm0
000074fc119df358  vmovaps [rsp+0x10], xmm1
000074fc119df35e  vmovaps [rsp+0x20], xmm2
000074fc119df364  vmovaps [rsp+0x30], xmm3
000074fc119df36a  vmovaps [rsp+0x40], xmm4
000074fc119df370  vmovaps [rsp+0x50], xmm6
000074fc119df376  vmovaps [rsp+0x60], xmm7
000074fc119df37c  vmovaps [rsp+0x70], xmm8
000074fc119df382  vmovaps [rsp+0x80], xmm9
000074fc119df38b  vmovaps [rsp+0x90], xmm10
000074fc119df394  vmovaps [rsp+0xA0], xmm11
000074fc119df39d  vmovaps [rsp+0xB0], xmm12
000074fc119df3a6  vmovaps [rsp+0xC0], xmm13
000074fc119df3af  vmovaps [rsp+0xD0], xmm14
000074fc119df3b8  vmovaps [rsp+0xE0], xmm15
000074fc119df3c1  sub rsp, 0x30
000074fc119df3c5  movaps [rsp], xmm5
000074fc119df3c9  movaps [rsp+0x10], xmm8
000074fc119df3cf  movaps [rsp+0x20], xmm6
000074fc119df3d4  lea rdi, [rsp]
000074fc119df3d8  mov esi, 0x00
000074fc119df3dd  mov rax, 0x58C4C8091530
000074fc119df3e7  call rax
000074fc119df3e9  movaps xmm5, [rsp]
000074fc119df3ed  add rsp, 0x30
000074fc119df3f1  vmovaps xmm0, [rsp]
000074fc119df3f6  vmovaps xmm1, [rsp+0x10]
000074fc119df3fc  vmovaps xmm2, [rsp+0x20]
000074fc119df402  vmovaps xmm3, [rsp+0x30]
000074fc119df408  vmovaps xmm4, [rsp+0x40]
000074fc119df40e  vmovaps xmm6, [rsp+0x50]
000074fc119df414  vmovaps xmm7, [rsp+0x60]
000074fc119df41a  vmovaps xmm8, [rsp+0x70]
000074fc119df420  vmovaps xmm9, [rsp+0x80]
000074fc119df429  vmovaps xmm10, [rsp+0x90]
000074fc119df432  vmovaps xmm11, [rsp+0xA0]
000074fc119df43b  vmovaps xmm12, [rsp+0xB0]
000074fc119df444  vmovaps xmm13, [rsp+0xC0]
000074fc119df44d  vmovaps xmm14, [rsp+0xD0]
000074fc119df456  vmovaps xmm15, [rsp+0xE0]
000074fc119df45f  add rsp, 0xF0
000074fc119df466  pop r11
000074fc119df468  pop r10
000074fc119df46a  pop r9
000074fc119df46c  pop r8
000074fc119df46e  pop rsi
000074fc119df46f  pop rdi
000074fc119df470  pop rdx
000074fc119df471  pop rcx
000074fc119df472  pop rax
000074fc119df473  add rsp, 0x08
000074fc119df477  jmp 0x000074FC119DC3B3
000074fc119df47c  sub rsp, 0x08
000074fc119df480  push rax
000074fc119df481  push rcx
000074fc119df482  push rdx
000074fc119df483  push rdi
000074fc119df484  push rsi
000074fc119df485  push r8
000074fc119df487  push r9
000074fc119df489  push r10
000074fc119df48b  push r11
000074fc119df48d  sub rsp, 0xF0
000074fc119df494  vmovaps [rsp], xmm0
000074fc119df499  vmovaps [rsp+0x10], xmm1
000074fc119df49f  vmovaps [rsp+0x20], xmm2
000074fc119df4a5  vmovaps [rsp+0x30], xmm3
000074fc119df4ab  vmovaps [rsp+0x40], xmm4
000074fc119df4b1  vmovaps [rsp+0x50], xmm5
000074fc119df4b7  vmovaps [rsp+0x60], xmm7
000074fc119df4bd  vmovaps [rsp+0x70], xmm8
000074fc119df4c3  vmovaps [rsp+0x80], xmm9
000074fc119df4cc  vmovaps [rsp+0x90], xmm10
000074fc119df4d5  vmovaps [rsp+0xA0], xmm11
000074fc119df4de  vmovaps [rsp+0xB0], xmm12
000074fc119df4e7  vmovaps [rsp+0xC0], xmm13
000074fc119df4f0  vmovaps [rsp+0xD0], xmm14
000074fc119df4f9  vmovaps [rsp+0xE0], xmm15
000074fc119df502  sub rsp, 0x30
000074fc119df506  movaps [rsp], xmm6
000074fc119df50a  movaps [rsp+0x10], xmm10
000074fc119df510  movaps [rsp+0x20], xmm8
000074fc119df516  lea rdi, [rsp]
000074fc119df51a  mov esi, 0x00
000074fc119df51f  mov rax, 0x58C4C8091530
000074fc119df529  call rax
000074fc119df52b  movaps xmm6, [rsp]
000074fc119df52f  add rsp, 0x30
000074fc119df533  vmovaps xmm0, [rsp]
000074fc119df538  vmovaps xmm1, [rsp+0x10]
000074fc119df53e  vmovaps xmm2, [rsp+0x20]
000074fc119df544  vmovaps xmm3, [rsp+0x30]
000074fc119df54a  vmovaps xmm4, [rsp+0x40]
000074fc119df550  vmovaps xmm5, [rsp+0x50]
000074fc119df556  vmovaps xmm7, [rsp+0x60]
000074fc119df55c  vmovaps xmm8, [rsp+0x70]
000074fc119df562  vmovaps xmm9, [rsp+0x80]
000074fc119df56b  vmovaps xmm10, [rsp+0x90]
000074fc119df574  vmovaps xmm11, [rsp+0xA0]
000074fc119df57d  vmovaps xmm12, [rsp+0xB0]
000074fc119df586  vmovaps xmm13, [rsp+0xC0]
000074fc119df58f  vmovaps xmm14, [rsp+0xD0]
000074fc119df598  vmovaps xmm15, [rsp+0xE0]
000074fc119df5a1  add rsp, 0xF0
000074fc119df5a8  pop r11
000074fc119df5aa  pop r10
000074fc119df5ac  pop r9
000074fc119df5ae  pop r8
000074fc119df5b0  pop rsi
000074fc119df5b1  pop rdi
000074fc119df5b2  pop rdx
000074fc119df5b3  pop rcx
000074fc119df5b4  pop rax
000074fc119df5b5  add rsp, 0x08
000074fc119df5b9  jmp 0x000074FC119DC3D8
000074fc119df5be  sub rsp, 0x08
000074fc119df5c2  push rax
000074fc119df5c3  push rcx
000074fc119df5c4  push rdx
000074fc119df5c5  push rdi
000074fc119df5c6  push rsi
000074fc119df5c7  push r8
000074fc119df5c9  push r9
000074fc119df5cb  push r10
000074fc119df5cd  push r11
000074fc119df5cf  sub rsp, 0xF0
000074fc119df5d6  vmovaps [rsp], xmm0
000074fc119df5db  vmovaps [rsp+0x10], xmm1
000074fc119df5e1  vmovaps [rsp+0x20], xmm2
000074fc119df5e7  vmovaps [rsp+0x30], xmm3
000074fc119df5ed  vmovaps [rsp+0x40], xmm4
000074fc119df5f3  vmovaps [rsp+0x50], xmm5
000074fc119df5f9  vmovaps [rsp+0x60], xmm6
000074fc119df5ff  vmovaps [rsp+0x70], xmm7
000074fc119df605  vmovaps [rsp+0x80], xmm8
000074fc119df60e  vmovaps [rsp+0x90], xmm9
000074fc119df617  vmovaps [rsp+0xA0], xmm11
000074fc119df620  vmovaps [rsp+0xB0], xmm12
000074fc119df629  vmovaps [rsp+0xC0], xmm13
000074fc119df632  vmovaps [rsp+0xD0], xmm14
000074fc119df63b  vmovaps [rsp+0xE0], xmm15
000074fc119df644  sub rsp, 0x30
000074fc119df648  movaps [rsp], xmm10
000074fc119df64d  movaps [rsp+0x10], xmm8
000074fc119df653  movaps [rsp+0x20], xmm14
000074fc119df659  lea rdi, [rsp]
000074fc119df65d  mov esi, 0x00
000074fc119df662  mov rax, 0x58C4C8091530
000074fc119df66c  call rax
000074fc119df66e  movaps xmm10, [rsp]
000074fc119df673  add rsp, 0x30
000074fc119df677  vmovaps xmm0, [rsp]
000074fc119df67c  vmovaps xmm1, [rsp+0x10]
000074fc119df682  vmovaps xmm2, [rsp+0x20]
000074fc119df688  vmovaps xmm3, [rsp+0x30]
000074fc119df68e  vmovaps xmm4, [rsp+0x40]
000074fc119df694  vmovaps xmm5, [rsp+0x50]
000074fc119df69a  vmovaps xmm6, [rsp+0x60]
000074fc119df6a0  vmovaps xmm7, [rsp+0x70]
000074fc119df6a6  vmovaps xmm8, [rsp+0x80]
000074fc119df6af  vmovaps xmm9, [rsp+0x90]
000074fc119df6b8  vmovaps xmm11, [rsp+0xA0]
000074fc119df6c1  vmovaps xmm12, [rsp+0xB0]
000074fc119df6ca  vmovaps xmm13, [rsp+0xC0]
000074fc119df6d3  vmovaps xmm14, [rsp+0xD0]
000074fc119df6dc  vmovaps xmm15, [rsp+0xE0]
000074fc119df6e5  add rsp, 0xF0
000074fc119df6ec  pop r11
000074fc119df6ee  pop r10
000074fc119df6f0  pop r9
000074fc119df6f2  pop r8
000074fc119df6f4  pop rsi
000074fc119df6f5  pop rdi
000074fc119df6f6  pop rdx
000074fc119df6f7  pop rcx
000074fc119df6f8  pop rax
000074fc119df6f9  add rsp, 0x08
000074fc119df6fd  jmp 0x000074FC119DC3F8
000074fc119df702  sub rsp, 0x08
000074fc119df706  push rax
000074fc119df707  push rcx
000074fc119df708  push rdx
000074fc119df709  push rdi
000074fc119df70a  push rsi
000074fc119df70b  push r8
000074fc119df70d  push r9
000074fc119df70f  push r10
000074fc119df711  push r11
000074fc119df713  sub rsp, 0xF0
000074fc119df71a  vmovaps [rsp], xmm0
000074fc119df71f  vmovaps [rsp+0x10], xmm1
000074fc119df725  vmovaps [rsp+0x20], xmm2
000074fc119df72b  vmovaps [rsp+0x30], xmm3
000074fc119df731  vmovaps [rsp+0x40], xmm4
000074fc119df737  vmovaps [rsp+0x50], xmm5
000074fc119df73d  vmovaps [rsp+0x60], xmm6
000074fc119df743  vmovaps [rsp+0x70], xmm7
000074fc119df749  vmovaps [rsp+0x80], xmm8
000074fc119df752  vmovaps [rsp+0x90], xmm9
000074fc119df75b  vmovaps [rsp+0xA0], xmm10
000074fc119df764  vmovaps [rsp+0xB0], xmm11
000074fc119df76d  vmovaps [rsp+0xC0], xmm12
000074fc119df776  vmovaps [rsp+0xD0], xmm13
000074fc119df77f  vmovaps [rsp+0xE0], xmm15
000074fc119df788  sub rsp, 0x30
000074fc119df78c  movaps [rsp], xmm14
000074fc119df791  movaps [rsp+0x10], xmm8
000074fc119df797  movaps [rsp+0x20], xmm4
000074fc119df79c  lea rdi, [rsp]
000074fc119df7a0  mov esi, 0x00
000074fc119df7a5  mov rax, 0x58C4C8091530
000074fc119df7af  call rax
000074fc119df7b1  movaps xmm14, [rsp]
000074fc119df7b6  add rsp, 0x30
000074fc119df7ba  vmovaps xmm0, [rsp]
000074fc119df7bf  vmovaps xmm1, [rsp+0x10]
000074fc119df7c5  vmovaps xmm2, [rsp+0x20]
000074fc119df7cb  vmovaps xmm3, [rsp+0x30]
000074fc119df7d1  vmovaps xmm4, [rsp+0x40]
000074fc119df7d7  vmovaps xmm5, [rsp+0x50]
000074fc119df7dd  vmovaps xmm6, [rsp+0x60]
000074fc119df7e3  vmovaps xmm7, [rsp+0x70]
000074fc119df7e9  vmovaps xmm8, [rsp+0x80]
000074fc119df7f2  vmovaps xmm9, [rsp+0x90]
000074fc119df7fb  vmovaps xmm10, [rsp+0xA0]
000074fc119df804  vmovaps xmm11, [rsp+0xB0]
000074fc119df80d  vmovaps xmm12, [rsp+0xC0]
000074fc119df816  vmovaps xmm13, [rsp+0xD0]
000074fc119df81f  vmovaps xmm15, [rsp+0xE0]
000074fc119df828  add rsp, 0xF0
000074fc119df82f  pop r11
000074fc119df831  pop r10
000074fc119df833  pop r9
000074fc119df835  pop r8
000074fc119df837  pop rsi
000074fc119df838  pop rdi
000074fc119df839  pop rdx
000074fc119df83a  pop rcx
000074fc119df83b  pop rax
000074fc119df83c  add rsp, 0x08
000074fc119df840  jmp 0x000074FC119DC418
000074fc119df845  sub rsp, 0x08
000074fc119df849  push rax
000074fc119df84a  push rcx
000074fc119df84b  push rdx
000074fc119df84c  push rdi
000074fc119df84d  push rsi
000074fc119df84e  push r8
000074fc119df850  push r9
000074fc119df852  push r10
000074fc119df854  push r11
000074fc119df856  sub rsp, 0xF0
000074fc119df85d  vmovaps [rsp], xmm0
000074fc119df862  vmovaps [rsp+0x10], xmm1
000074fc119df868  vmovaps [rsp+0x20], xmm2
000074fc119df86e  vmovaps [rsp+0x30], xmm3
000074fc119df874  vmovaps [rsp+0x40], xmm5
000074fc119df87a  vmovaps [rsp+0x50], xmm6
000074fc119df880  vmovaps [rsp+0x60], xmm7
000074fc119df886  vmovaps [rsp+0x70], xmm8
000074fc119df88c  vmovaps [rsp+0x80], xmm9
000074fc119df895  vmovaps [rsp+0x90], xmm10
000074fc119df89e  vmovaps [rsp+0xA0], xmm11
000074fc119df8a7  vmovaps [rsp+0xB0], xmm12
000074fc119df8b0  vmovaps [rsp+0xC0], xmm13
000074fc119df8b9  vmovaps [rsp+0xD0], xmm14
000074fc119df8c2  vmovaps [rsp+0xE0], xmm15
000074fc119df8cb  sub rsp, 0x30
000074fc119df8cf  movaps [rsp], xmm4
000074fc119df8d3  movaps [rsp+0x10], xmm13
000074fc119df8d9  movaps [rsp+0x20], xmm8
000074fc119df8df  lea rdi, [rsp]
000074fc119df8e3  mov esi, 0x00
000074fc119df8e8  mov rax, 0x58C4C8091530
000074fc119df8f2  call rax
000074fc119df8f4  movaps xmm4, [rsp]
000074fc119df8f8  add rsp, 0x30
000074fc119df8fc  vmovaps xmm0, [rsp]
000074fc119df901  vmovaps xmm1, [rsp+0x10]
000074fc119df907  vmovaps xmm2, [rsp+0x20]
000074fc119df90d  vmovaps xmm3, [rsp+0x30]
000074fc119df913  vmovaps xmm5, [rsp+0x40]
000074fc119df919  vmovaps xmm6, [rsp+0x50]
000074fc119df91f  vmovaps xmm7, [rsp+0x60]
000074fc119df925  vmovaps xmm8, [rsp+0x70]
000074fc119df92b  vmovaps xmm9, [rsp+0x80]
000074fc119df934  vmovaps xmm10, [rsp+0x90]
000074fc119df93d  vmovaps xmm11, [rsp+0xA0]
000074fc119df946  vmovaps xmm12, [rsp+0xB0]
000074fc119df94f  vmovaps xmm13, [rsp+0xC0]
000074fc119df958  vmovaps xmm14, [rsp+0xD0]
000074fc119df961  vmovaps xmm15, [rsp+0xE0]
000074fc119df96a  add rsp, 0xF0
000074fc119df971  pop r11
000074fc119df973  pop r10
000074fc119df975  pop r9
000074fc119df977  pop r8
000074fc119df979  pop rsi
000074fc119df97a  pop rdi
000074fc119df97b  pop rdx
000074fc119df97c  pop rcx
000074fc119df97d  pop rax
000074fc119df97e  add rsp, 0x08
000074fc119df982  jmp 0x000074FC119DC43D
000074fc119df987  sub rsp, 0x08
000074fc119df98b  push rax
000074fc119df98c  push rcx
000074fc119df98d  push rdx
000074fc119df98e  push rdi
000074fc119df98f  push rsi
000074fc119df990  push r8
000074fc119df992  push r9
000074fc119df994  push r10
000074fc119df996  push r11
000074fc119df998  sub rsp, 0xF0
000074fc119df99f  vmovaps [rsp], xmm0
000074fc119df9a4  vmovaps [rsp+0x10], xmm1
000074fc119df9aa  vmovaps [rsp+0x20], xmm2
000074fc119df9b0  vmovaps [rsp+0x30], xmm3
000074fc119df9b6  vmovaps [rsp+0x40], xmm4
000074fc119df9bc  vmovaps [rsp+0x50], xmm5
000074fc119df9c2  vmovaps [rsp+0x60], xmm6
000074fc119df9c8  vmovaps [rsp+0x70], xmm7
000074fc119df9ce  vmovaps [rsp+0x80], xmm8
000074fc119df9d7  vmovaps [rsp+0x90], xmm9
000074fc119df9e0  vmovaps [rsp+0xA0], xmm10
000074fc119df9e9  vmovaps [rsp+0xB0], xmm11
000074fc119df9f2  vmovaps [rsp+0xC0], xmm12
000074fc119df9fb  vmovaps [rsp+0xD0], xmm14
000074fc119dfa04  vmovaps [rsp+0xE0], xmm15
000074fc119dfa0d  sub rsp, 0x30
000074fc119dfa11  movaps [rsp], xmm13
000074fc119dfa16  movaps [rsp+0x10], xmm15
000074fc119dfa1c  movaps [rsp+0x20], xmm9
000074fc119dfa22  lea rdi, [rsp]
000074fc119dfa26  mov esi, 0x00
000074fc119dfa2b  mov rax, 0x58C4C8091530
000074fc119dfa35  call rax
000074fc119dfa37  movaps xmm13, [rsp]
000074fc119dfa3c  add rsp, 0x30
000074fc119dfa40  vmovaps xmm0, [rsp]
000074fc119dfa45  vmovaps xmm1, [rsp+0x10]
000074fc119dfa4b  vmovaps xmm2, [rsp+0x20]
000074fc119dfa51  vmovaps xmm3, [rsp+0x30]
000074fc119dfa57  vmovaps xmm4, [rsp+0x40]
000074fc119dfa5d  vmovaps xmm5, [rsp+0x50]
000074fc119dfa63  vmovaps xmm6, [rsp+0x60]
000074fc119dfa69  vmovaps xmm7, [rsp+0x70]
000074fc119dfa6f  vmovaps xmm8, [rsp+0x80]
000074fc119dfa78  vmovaps xmm9, [rsp+0x90]
000074fc119dfa81  vmovaps xmm10, [rsp+0xA0]
000074fc119dfa8a  vmovaps xmm11, [rsp+0xB0]
000074fc119dfa93  vmovaps xmm12, [rsp+0xC0]
000074fc119dfa9c  vmovaps xmm14, [rsp+0xD0]
000074fc119dfaa5  vmovaps xmm15, [rsp+0xE0]
000074fc119dfaae  add rsp, 0xF0
000074fc119dfab5  pop r11
000074fc119dfab7  pop r10
000074fc119dfab9  pop r9
000074fc119dfabb  pop r8
000074fc119dfabd  pop rsi
000074fc119dfabe  pop rdi
000074fc119dfabf  pop rdx
000074fc119dfac0  pop rcx
000074fc119dfac1  pop rax
000074fc119dfac2  add rsp, 0x08
000074fc119dfac6  jmp 0x000074FC119DC458
000074fc119dfacb  sub rsp, 0x08
000074fc119dfacf  push rax
000074fc119dfad0  push rcx
000074fc119dfad1  push rdx
000074fc119dfad2  push rdi
000074fc119dfad3  push rsi
000074fc119dfad4  push r8
000074fc119dfad6  push r9
000074fc119dfad8  push r10
000074fc119dfada  push r11
000074fc119dfadc  sub rsp, 0xF0
000074fc119dfae3  vmovaps [rsp], xmm0
000074fc119dfae8  vmovaps [rsp+0x10], xmm1
000074fc119dfaee  vmovaps [rsp+0x20], xmm2
000074fc119dfaf4  vmovaps [rsp+0x30], xmm3
000074fc119dfafa  vmovaps [rsp+0x40], xmm4
000074fc119dfb00  vmovaps [rsp+0x50], xmm5
000074fc119dfb06  vmovaps [rsp+0x60], xmm6
000074fc119dfb0c  vmovaps [rsp+0x70], xmm7
000074fc119dfb12  vmovaps [rsp+0x80], xmm8
000074fc119dfb1b  vmovaps [rsp+0x90], xmm9
000074fc119dfb24  vmovaps [rsp+0xA0], xmm10
000074fc119dfb2d  vmovaps [rsp+0xB0], xmm11
000074fc119dfb36  vmovaps [rsp+0xC0], xmm12
000074fc119dfb3f  vmovaps [rsp+0xD0], xmm13
000074fc119dfb48  vmovaps [rsp+0xE0], xmm14
000074fc119dfb51  sub rsp, 0x30
000074fc119dfb55  movaps [rsp], xmm15
000074fc119dfb5a  movaps [rsp+0x10], xmm1
000074fc119dfb5f  movaps [rsp+0x20], xmm5
000074fc119dfb64  lea rdi, [rsp]
000074fc119dfb68  mov esi, 0x00
000074fc119dfb6d  mov rax, 0x58C4C8091530
000074fc119dfb77  call rax
000074fc119dfb79  movaps xmm15, [rsp]
000074fc119dfb7e  add rsp, 0x30
000074fc119dfb82  vmovaps xmm0, [rsp]
000074fc119dfb87  vmovaps xmm1, [rsp+0x10]
000074fc119dfb8d  vmovaps xmm2, [rsp+0x20]
000074fc119dfb93  vmovaps xmm3, [rsp+0x30]
000074fc119dfb99  vmovaps xmm4, [rsp+0x40]
000074fc119dfb9f  vmovaps xmm5, [rsp+0x50]
000074fc119dfba5  vmovaps xmm6, [rsp+0x60]
000074fc119dfbab  vmovaps xmm7, [rsp+0x70]
000074fc119dfbb1  vmovaps xmm8, [rsp+0x80]
000074fc119dfbba  vmovaps xmm9, [rsp+0x90]
000074fc119dfbc3  vmovaps xmm10, [rsp+0xA0]
000074fc119dfbcc  vmovaps xmm11, [rsp+0xB0]
000074fc119dfbd5  vmovaps xmm12, [rsp+0xC0]
000074fc119dfbde  vmovaps xmm13, [rsp+0xD0]
000074fc119dfbe7  vmovaps xmm14, [rsp+0xE0]
000074fc119dfbf0  add rsp, 0xF0
000074fc119dfbf7  pop r11
000074fc119dfbf9  pop r10
000074fc119dfbfb  pop r9
000074fc119dfbfd  pop r8
000074fc119dfbff  pop rsi
000074fc119dfc00  pop rdi
000074fc119dfc01  pop rdx
000074fc119dfc02  pop rcx
000074fc119dfc03  pop rax
000074fc119dfc04  add rsp, 0x08
000074fc119dfc08  jmp 0x000074FC119DC473
000074fc119dfc0d  call 0x000074FC118B52F0
000074fc119dfc12  jmp 0x000074FC119DC4CE
000074fc119dfc17  sub rsp, 0x08
000074fc119dfc1b  push rax
000074fc119dfc1c  push rcx
000074fc119dfc1d  push rdx
000074fc119dfc1e  push rdi
000074fc119dfc1f  push rsi
000074fc119dfc20  push r8
000074fc119dfc22  push r9
000074fc119dfc24  push r10
000074fc119dfc26  push r11
000074fc119dfc28  sub rsp, 0xF0
000074fc119dfc2f  vmovaps [rsp], xmm0
000074fc119dfc34  vmovaps [rsp+0x10], xmm1
000074fc119dfc3a  vmovaps [rsp+0x20], xmm2
000074fc119dfc40  vmovaps [rsp+0x30], xmm3
000074fc119dfc46  vmovaps [rsp+0x40], xmm4
000074fc119dfc4c  vmovaps [rsp+0x50], xmm5
000074fc119dfc52  vmovaps [rsp+0x60], xmm6
000074fc119dfc58  vmovaps [rsp+0x70], xmm7
000074fc119dfc5e  vmovaps [rsp+0x80], xmm8
000074fc119dfc67  vmovaps [rsp+0x90], xmm10
000074fc119dfc70  vmovaps [rsp+0xA0], xmm11
000074fc119dfc79  vmovaps [rsp+0xB0], xmm12
000074fc119dfc82  vmovaps [rsp+0xC0], xmm13
000074fc119dfc8b  vmovaps [rsp+0xD0], xmm14
000074fc119dfc94  vmovaps [rsp+0xE0], xmm15
000074fc119dfc9d  sub rsp, 0x30
000074fc119dfca1  movaps [rsp], xmm9
000074fc119dfca6  movaps [rsp+0x10], xmm8
000074fc119dfcac  movaps [rsp+0x20], xmm11
000074fc119dfcb2  lea rdi, [rsp]
000074fc119dfcb6  mov esi, 0x00
000074fc119dfcbb  mov rax, 0x58C4C8091530
000074fc119dfcc5  call rax
000074fc119dfcc7  movaps xmm9, [rsp]
000074fc119dfccc  add rsp, 0x30
000074fc119dfcd0  vmovaps xmm0, [rsp]
000074fc119dfcd5  vmovaps xmm1, [rsp+0x10]
000074fc119dfcdb  vmovaps xmm2, [rsp+0x20]
000074fc119dfce1  vmovaps xmm3, [rsp+0x30]
000074fc119dfce7  vmovaps xmm4, [rsp+0x40]
000074fc119dfced  vmovaps xmm5, [rsp+0x50]
000074fc119dfcf3  vmovaps xmm6, [rsp+0x60]
000074fc119dfcf9  vmovaps xmm7, [rsp+0x70]
000074fc119dfcff  vmovaps xmm8, [rsp+0x80]
000074fc119dfd08  vmovaps xmm10, [rsp+0x90]
000074fc119dfd11  vmovaps xmm11, [rsp+0xA0]
000074fc119dfd1a  vmovaps xmm12, [rsp+0xB0]
000074fc119dfd23  vmovaps xmm13, [rsp+0xC0]
000074fc119dfd2c  vmovaps xmm14, [rsp+0xD0]
000074fc119dfd35  vmovaps xmm15, [rsp+0xE0]
000074fc119dfd3e  add rsp, 0xF0
000074fc119dfd45  pop r11
000074fc119dfd47  pop r10
000074fc119dfd49  pop r9
000074fc119dfd4b  pop r8
000074fc119dfd4d  pop rsi
000074fc119dfd4e  pop rdi
000074fc119dfd4f  pop rdx
000074fc119dfd50  pop rcx
000074fc119dfd51  pop rax
000074fc119dfd52  add rsp, 0x08
000074fc119dfd56  jmp 0x000074FC119DC505
000074fc119dfd5b  sub rsp, 0x08
000074fc119dfd5f  push rax
000074fc119dfd60  push rcx
000074fc119dfd61  push rdx
000074fc119dfd62  push rdi
000074fc119dfd63  push rsi
000074fc119dfd64  push r8
000074fc119dfd66  push r9
000074fc119dfd68  push r10
000074fc119dfd6a  push r11
000074fc119dfd6c  sub rsp, 0xF0
000074fc119dfd73  vmovaps [rsp], xmm0
000074fc119dfd78  vmovaps [rsp+0x10], xmm1
000074fc119dfd7e  vmovaps [rsp+0x20], xmm2
000074fc119dfd84  vmovaps [rsp+0x30], xmm3
000074fc119dfd8a  vmovaps [rsp+0x40], xmm4
000074fc119dfd90  vmovaps [rsp+0x50], xmm5
000074fc119dfd96  vmovaps [rsp+0x60], xmm6
000074fc119dfd9c  vmovaps [rsp+0x70], xmm7
000074fc119dfda2  vmovaps [rsp+0x80], xmm8
000074fc119dfdab  vmovaps [rsp+0x90], xmm9
000074fc119dfdb4  vmovaps [rsp+0xA0], xmm10
000074fc119dfdbd  vmovaps [rsp+0xB0], xmm12
000074fc119dfdc6  vmovaps [rsp+0xC0], xmm13
000074fc119dfdcf  vmovaps [rsp+0xD0], xmm14
000074fc119dfdd8  vmovaps [rsp+0xE0], xmm15
000074fc119dfde1  sub rsp, 0x30
000074fc119dfde5  movaps [rsp], xmm11
000074fc119dfdea  movaps [rsp+0x10], xmm10
000074fc119dfdf0  movaps [rsp+0x20], xmm6
000074fc119dfdf5  lea rdi, [rsp]
000074fc119dfdf9  mov esi, 0x00
000074fc119dfdfe  mov rax, 0x58C4C8091530
000074fc119dfe08  call rax
000074fc119dfe0a  movaps xmm11, [rsp]
000074fc119dfe0f  add rsp, 0x30
000074fc119dfe13  vmovaps xmm0, [rsp]
000074fc119dfe18  vmovaps xmm1, [rsp+0x10]
000074fc119dfe1e  vmovaps xmm2, [rsp+0x20]
000074fc119dfe24  vmovaps xmm3, [rsp+0x30]
000074fc119dfe2a  vmovaps xmm4, [rsp+0x40]
000074fc119dfe30  vmovaps xmm5, [rsp+0x50]
000074fc119dfe36  vmovaps xmm6, [rsp+0x60]
000074fc119dfe3c  vmovaps xmm7, [rsp+0x70]
000074fc119dfe42  vmovaps xmm8, [rsp+0x80]
000074fc119dfe4b  vmovaps xmm9, [rsp+0x90]
000074fc119dfe54  vmovaps xmm10, [rsp+0xA0]
000074fc119dfe5d  vmovaps xmm12, [rsp+0xB0]
000074fc119dfe66  vmovaps xmm13, [rsp+0xC0]
000074fc119dfe6f  vmovaps xmm14, [rsp+0xD0]
000074fc119dfe78  vmovaps xmm15, [rsp+0xE0]
000074fc119dfe81  add rsp, 0xF0
000074fc119dfe88  pop r11
000074fc119dfe8a  pop r10
000074fc119dfe8c  pop r9
000074fc119dfe8e  pop r8
000074fc119dfe90  pop rsi
000074fc119dfe91  pop rdi
000074fc119dfe92  pop rdx
000074fc119dfe93  pop rcx
000074fc119dfe94  pop rax
000074fc119dfe95  add rsp, 0x08
000074fc119dfe99  jmp 0x000074FC119DC520
000074fc119dfe9e  sub rsp, 0x08
000074fc119dfea2  push rax
000074fc119dfea3  push rcx
000074fc119dfea4  push rdx
000074fc119dfea5  push rdi
000074fc119dfea6  push rsi
000074fc119dfea7  push r8
000074fc119dfea9  push r9
000074fc119dfeab  push r10
000074fc119dfead  push r11
000074fc119dfeaf  sub rsp, 0xF0
000074fc119dfeb6  vmovaps [rsp], xmm0
000074fc119dfebb  vmovaps [rsp+0x10], xmm1
000074fc119dfec1  vmovaps [rsp+0x20], xmm2
000074fc119dfec7  vmovaps [rsp+0x30], xmm3
000074fc119dfecd  vmovaps [rsp+0x40], xmm4
000074fc119dfed3  vmovaps [rsp+0x50], xmm5
000074fc119dfed9  vmovaps [rsp+0x60], xmm6
000074fc119dfedf  vmovaps [rsp+0x70], xmm7
000074fc119dfee5  vmovaps [rsp+0x80], xmm8
000074fc119dfeee  vmovaps [rsp+0x90], xmm9
000074fc119dfef7  vmovaps [rsp+0xA0], xmm11
000074fc119dff00  vmovaps [rsp+0xB0], xmm12
000074fc119dff09  vmovaps [rsp+0xC0], xmm13
000074fc119dff12  vmovaps [rsp+0xD0], xmm14
000074fc119dff1b  vmovaps [rsp+0xE0], xmm15
000074fc119dff24  sub rsp, 0x30
000074fc119dff28  movaps [rsp], xmm10
000074fc119dff2d  movaps [rsp+0x10], xmm14
000074fc119dff33  movaps [rsp+0x20], xmm4
000074fc119dff38  lea rdi, [rsp]
000074fc119dff3c  mov esi, 0x00
000074fc119dff41  mov rax, 0x58C4C8091530
000074fc119dff4b  call rax
000074fc119dff4d  movaps xmm10, [rsp]
000074fc119dff52  add rsp, 0x30
000074fc119dff56  vmovaps xmm0, [rsp]
000074fc119dff5b  vmovaps xmm1, [rsp+0x10]
000074fc119dff61  vmovaps xmm2, [rsp+0x20]
000074fc119dff67  vmovaps xmm3, [rsp+0x30]
000074fc119dff6d  vmovaps xmm4, [rsp+0x40]
000074fc119dff73  vmovaps xmm5, [rsp+0x50]
000074fc119dff79  vmovaps xmm6, [rsp+0x60]
000074fc119dff7f  vmovaps xmm7, [rsp+0x70]
000074fc119dff85  vmovaps xmm8, [rsp+0x80]
000074fc119dff8e  vmovaps xmm9, [rsp+0x90]
000074fc119dff97  vmovaps xmm11, [rsp+0xA0]
000074fc119dffa0  vmovaps xmm12, [rsp+0xB0]
000074fc119dffa9  vmovaps xmm13, [rsp+0xC0]
000074fc119dffb2  vmovaps xmm14, [rsp+0xD0]
000074fc119dffbb  vmovaps xmm15, [rsp+0xE0]
000074fc119dffc4  add rsp, 0xF0
000074fc119dffcb  pop r11
000074fc119dffcd  pop r10
000074fc119dffcf  pop r9
000074fc119dffd1  pop r8
000074fc119dffd3  pop rsi
000074fc119dffd4  pop rdi
000074fc119dffd5  pop rdx
000074fc119dffd6  pop rcx
000074fc119dffd7  pop rax
000074fc119dffd8  add rsp, 0x08
000074fc119dffdc  jmp 0x000074FC119DC53B
000074fc119dffe1  sub rsp, 0x08
000074fc119dffe5  push rax
000074fc119dffe6  push rcx
000074fc119dffe7  push rdx
000074fc119dffe8  push rdi
000074fc119dffe9  push rsi
000074fc119dffea  push r8
000074fc119dffec  push r9
000074fc119dffee  push r10
000074fc119dfff0  push r11
000074fc119dfff2  sub rsp, 0xF0
000074fc119dfff9  vmovaps [rsp], xmm0
000074fc119dfffe  vmovaps [rsp+0x10], xmm1
000074fc119e0004  vmovaps [rsp+0x20], xmm2
000074fc119e000a  vmovaps [rsp+0x30], xmm3
000074fc119e0010  vmovaps [rsp+0x40], xmm4
000074fc119e0016  vmovaps [rsp+0x50], xmm5
000074fc119e001c  vmovaps [rsp+0x60], xmm6
000074fc119e0022  vmovaps [rsp+0x70], xmm7
000074fc119e0028  vmovaps [rsp+0x80], xmm9
000074fc119e0031  vmovaps [rsp+0x90], xmm10
000074fc119e003a  vmovaps [rsp+0xA0], xmm11
000074fc119e0043  vmovaps [rsp+0xB0], xmm12
000074fc119e004c  vmovaps [rsp+0xC0], xmm13
000074fc119e0055  vmovaps [rsp+0xD0], xmm14
000074fc119e005e  vmovaps [rsp+0xE0], xmm15
000074fc119e0067  sub rsp, 0x30
000074fc119e006b  movaps [rsp], xmm8
000074fc119e0070  movaps [rsp+0x10], xmm1
000074fc119e0075  movaps [rsp+0x20], xmm14
000074fc119e007b  lea rdi, [rsp]
000074fc119e007f  mov esi, 0x00
000074fc119e0084  mov rax, 0x58C4C8091530
000074fc119e008e  call rax
000074fc119e0090  movaps xmm8, [rsp]
000074fc119e0095  add rsp, 0x30
000074fc119e0099  vmovaps xmm0, [rsp]
000074fc119e009e  vmovaps xmm1, [rsp+0x10]
000074fc119e00a4  vmovaps xmm2, [rsp+0x20]
000074fc119e00aa  vmovaps xmm3, [rsp+0x30]
000074fc119e00b0  vmovaps xmm4, [rsp+0x40]
000074fc119e00b6  vmovaps xmm5, [rsp+0x50]
000074fc119e00bc  vmovaps xmm6, [rsp+0x60]
000074fc119e00c2  vmovaps xmm7, [rsp+0x70]
000074fc119e00c8  vmovaps xmm9, [rsp+0x80]
000074fc119e00d1  vmovaps xmm10, [rsp+0x90]
000074fc119e00da  vmovaps xmm11, [rsp+0xA0]
000074fc119e00e3  vmovaps xmm12, [rsp+0xB0]
000074fc119e00ec  vmovaps xmm13, [rsp+0xC0]
000074fc119e00f5  vmovaps xmm14, [rsp+0xD0]
000074fc119e00fe  vmovaps xmm15, [rsp+0xE0]
000074fc119e0107  add rsp, 0xF0
000074fc119e010e  pop r11
000074fc119e0110  pop r10
000074fc119e0112  pop r9
000074fc119e0114  pop r8
000074fc119e0116  pop rsi
000074fc119e0117  pop rdi
000074fc119e0118  pop rdx
000074fc119e0119  pop rcx
000074fc119e011a  pop rax
000074fc119e011b  add rsp, 0x08
000074fc119e011f  jmp 0x000074FC119DC561
000074fc119e0124  sub rsp, 0x08
000074fc119e0128  push rax
000074fc119e0129  push rcx
000074fc119e012a  push rdx
000074fc119e012b  push rdi
000074fc119e012c  push rsi
000074fc119e012d  push r8
000074fc119e012f  push r9
000074fc119e0131  push r10
000074fc119e0133  push r11
000074fc119e0135  sub rsp, 0xF0
000074fc119e013c  vmovaps [rsp], xmm0
000074fc119e0141  vmovaps [rsp+0x10], xmm1
000074fc119e0147  vmovaps [rsp+0x20], xmm2
000074fc119e014d  vmovaps [rsp+0x30], xmm3
000074fc119e0153  vmovaps [rsp+0x40], xmm4
000074fc119e0159  vmovaps [rsp+0x50], xmm5
000074fc119e015f  vmovaps [rsp+0x60], xmm7
000074fc119e0165  vmovaps [rsp+0x70], xmm8
000074fc119e016b  vmovaps [rsp+0x80], xmm9
000074fc119e0174  vmovaps [rsp+0x90], xmm10
000074fc119e017d  vmovaps [rsp+0xA0], xmm11
000074fc119e0186  vmovaps [rsp+0xB0], xmm12
000074fc119e018f  vmovaps [rsp+0xC0], xmm13
000074fc119e0198  vmovaps [rsp+0xD0], xmm14
000074fc119e01a1  vmovaps [rsp+0xE0], xmm15
000074fc119e01aa  sub rsp, 0x30
000074fc119e01ae  movaps [rsp], xmm6
000074fc119e01b2  movaps [rsp+0x10], xmm1
000074fc119e01b7  movaps [rsp+0x20], xmm14
000074fc119e01bd  lea rdi, [rsp]
000074fc119e01c1  mov esi, 0x00
000074fc119e01c6  mov rax, 0x58C4C8091530
000074fc119e01d0  call rax
000074fc119e01d2  movaps xmm6, [rsp]
000074fc119e01d6  add rsp, 0x30
000074fc119e01da  vmovaps xmm0, [rsp]
000074fc119e01df  vmovaps xmm1, [rsp+0x10]
000074fc119e01e5  vmovaps xmm2, [rsp+0x20]
000074fc119e01eb  vmovaps xmm3, [rsp+0x30]
000074fc119e01f1  vmovaps xmm4, [rsp+0x40]
000074fc119e01f7  vmovaps xmm5, [rsp+0x50]
000074fc119e01fd  vmovaps xmm7, [rsp+0x60]
000074fc119e0203  vmovaps xmm8, [rsp+0x70]
000074fc119e0209  vmovaps xmm9, [rsp+0x80]
000074fc119e0212  vmovaps xmm10, [rsp+0x90]
000074fc119e021b  vmovaps xmm11, [rsp+0xA0]
000074fc119e0224  vmovaps xmm12, [rsp+0xB0]
000074fc119e022d  vmovaps xmm13, [rsp+0xC0]
000074fc119e0236  vmovaps xmm14, [rsp+0xD0]
000074fc119e023f  vmovaps xmm15, [rsp+0xE0]
000074fc119e0248  add rsp, 0xF0
000074fc119e024f  pop r11
000074fc119e0251  pop r10
000074fc119e0253  pop r9
000074fc119e0255  pop r8
000074fc119e0257  pop rsi
000074fc119e0258  pop rdi
000074fc119e0259  pop rdx
000074fc119e025a  pop rcx
000074fc119e025b  pop rax
000074fc119e025c  add rsp, 0x08
000074fc119e0260  jmp 0x000074FC119DC58D
000074fc119e0265  sub rsp, 0x08
000074fc119e0269  push rax
000074fc119e026a  push rcx
000074fc119e026b  push rdx
000074fc119e026c  push rdi
000074fc119e026d  push rsi
000074fc119e026e  push r8
000074fc119e0270  push r9
000074fc119e0272  push r10
000074fc119e0274  push r11
000074fc119e0276  sub rsp, 0xF0
000074fc119e027d  vmovaps [rsp], xmm0
000074fc119e0282  vmovaps [rsp+0x10], xmm1
000074fc119e0288  vmovaps [rsp+0x20], xmm2
000074fc119e028e  vmovaps [rsp+0x30], xmm3
000074fc119e0294  vmovaps [rsp+0x40], xmm4
000074fc119e029a  vmovaps [rsp+0x50], xmm5
000074fc119e02a0  vmovaps [rsp+0x60], xmm6
000074fc119e02a6  vmovaps [rsp+0x70], xmm7
000074fc119e02ac  vmovaps [rsp+0x80], xmm8
000074fc119e02b5  vmovaps [rsp+0x90], xmm9
000074fc119e02be  vmovaps [rsp+0xA0], xmm10
000074fc119e02c7  vmovaps [rsp+0xB0], xmm11
000074fc119e02d0  vmovaps [rsp+0xC0], xmm12
000074fc119e02d9  vmovaps [rsp+0xD0], xmm13
000074fc119e02e2  vmovaps [rsp+0xE0], xmm15
000074fc119e02eb  sub rsp, 0x30
000074fc119e02ef  movaps [rsp], xmm14
000074fc119e02f4  movaps [rsp+0x10], xmm12
000074fc119e02fa  movaps [rsp+0x20], xmm1
000074fc119e02ff  lea rdi, [rsp]
000074fc119e0303  mov esi, 0x00
000074fc119e0308  mov rax, 0x58C4C8091530
000074fc119e0312  call rax
000074fc119e0314  movaps xmm14, [rsp]
000074fc119e0319  add rsp, 0x30
000074fc119e031d  vmovaps xmm0, [rsp]
000074fc119e0322  vmovaps xmm1, [rsp+0x10]
000074fc119e0328  vmovaps xmm2, [rsp+0x20]
000074fc119e032e  vmovaps xmm3, [rsp+0x30]
000074fc119e0334  vmovaps xmm4, [rsp+0x40]
000074fc119e033a  vmovaps xmm5, [rsp+0x50]
000074fc119e0340  vmovaps xmm6, [rsp+0x60]
000074fc119e0346  vmovaps xmm7, [rsp+0x70]
000074fc119e034c  vmovaps xmm8, [rsp+0x80]
000074fc119e0355  vmovaps xmm9, [rsp+0x90]
000074fc119e035e  vmovaps xmm10, [rsp+0xA0]
000074fc119e0367  vmovaps xmm11, [rsp+0xB0]
000074fc119e0370  vmovaps xmm12, [rsp+0xC0]
000074fc119e0379  vmovaps xmm13, [rsp+0xD0]
000074fc119e0382  vmovaps xmm15, [rsp+0xE0]
000074fc119e038b  add rsp, 0xF0
000074fc119e0392  pop r11
000074fc119e0394  pop r10
000074fc119e0396  pop r9
000074fc119e0398  pop r8
000074fc119e039a  pop rsi
000074fc119e039b  pop rdi
000074fc119e039c  pop rdx
000074fc119e039d  pop rcx
000074fc119e039e  pop rax
000074fc119e039f  add rsp, 0x08
000074fc119e03a3  jmp 0x000074FC119DC5B3
000074fc119e03a8  sub rsp, 0x08
000074fc119e03ac  push rax
000074fc119e03ad  push rcx
000074fc119e03ae  push rdx
000074fc119e03af  push rdi
000074fc119e03b0  push rsi
000074fc119e03b1  push r8
000074fc119e03b3  push r9
000074fc119e03b5  push r10
000074fc119e03b7  push r11
000074fc119e03b9  sub rsp, 0xF0
000074fc119e03c0  vmovaps [rsp], xmm0
000074fc119e03c5  vmovaps [rsp+0x10], xmm2
000074fc119e03cb  vmovaps [rsp+0x20], xmm3
000074fc119e03d1  vmovaps [rsp+0x30], xmm4
000074fc119e03d7  vmovaps [rsp+0x40], xmm5
000074fc119e03dd  vmovaps [rsp+0x50], xmm6
000074fc119e03e3  vmovaps [rsp+0x60], xmm7
000074fc119e03e9  vmovaps [rsp+0x70], xmm8
000074fc119e03ef  vmovaps [rsp+0x80], xmm9
000074fc119e03f8  vmovaps [rsp+0x90], xmm10
000074fc119e0401  vmovaps [rsp+0xA0], xmm11
000074fc119e040a  vmovaps [rsp+0xB0], xmm12
000074fc119e0413  vmovaps [rsp+0xC0], xmm13
000074fc119e041c  vmovaps [rsp+0xD0], xmm14
000074fc119e0425  vmovaps [rsp+0xE0], xmm15
000074fc119e042e  sub rsp, 0x30
000074fc119e0432  movaps [rsp], xmm1
000074fc119e0436  movaps [rsp+0x10], xmm13
000074fc119e043c  movaps [rsp+0x20], xmm9
000074fc119e0442  lea rdi, [rsp]
000074fc119e0446  mov esi, 0x00
000074fc119e044b  mov rax, 0x58C4C8091530
000074fc119e0455  call rax
000074fc119e0457  movaps xmm1, [rsp]
000074fc119e045b  add rsp, 0x30
000074fc119e045f  vmovaps xmm0, [rsp]
000074fc119e0464  vmovaps xmm2, [rsp+0x10]
000074fc119e046a  vmovaps xmm3, [rsp+0x20]
000074fc119e0470  vmovaps xmm4, [rsp+0x30]
000074fc119e0476  vmovaps xmm5, [rsp+0x40]
000074fc119e047c  vmovaps xmm6, [rsp+0x50]
000074fc119e0482  vmovaps xmm7, [rsp+0x60]
000074fc119e0488  vmovaps xmm8, [rsp+0x70]
000074fc119e048e  vmovaps xmm9, [rsp+0x80]
000074fc119e0497  vmovaps xmm10, [rsp+0x90]
000074fc119e04a0  vmovaps xmm11, [rsp+0xA0]
000074fc119e04a9  vmovaps xmm12, [rsp+0xB0]
000074fc119e04b2  vmovaps xmm13, [rsp+0xC0]
000074fc119e04bb  vmovaps xmm14, [rsp+0xD0]
000074fc119e04c4  vmovaps xmm15, [rsp+0xE0]
000074fc119e04cd  add rsp, 0xF0
000074fc119e04d4  pop r11
000074fc119e04d6  pop r10
000074fc119e04d8  pop r9
000074fc119e04da  pop r8
000074fc119e04dc  pop rsi
000074fc119e04dd  pop rdi
000074fc119e04de  pop rdx
000074fc119e04df  pop rcx
000074fc119e04e0  pop rax
000074fc119e04e1  add rsp, 0x08
000074fc119e04e5  jmp 0x000074FC119DC5CD
000074fc119e04ea  sub rsp, 0x08
000074fc119e04ee  push rax
000074fc119e04ef  push rcx
000074fc119e04f0  push rdx
000074fc119e04f1  push rdi
000074fc119e04f2  push rsi
000074fc119e04f3  push r8
000074fc119e04f5  push r9
000074fc119e04f7  push r10
000074fc119e04f9  push r11
000074fc119e04fb  sub rsp, 0xF0
000074fc119e0502  vmovaps [rsp], xmm0
000074fc119e0507  vmovaps [rsp+0x10], xmm1
000074fc119e050d  vmovaps [rsp+0x20], xmm2
000074fc119e0513  vmovaps [rsp+0x30], xmm3
000074fc119e0519  vmovaps [rsp+0x40], xmm4
000074fc119e051f  vmovaps [rsp+0x50], xmm5
000074fc119e0525  vmovaps [rsp+0x60], xmm6
000074fc119e052b  vmovaps [rsp+0x70], xmm7
000074fc119e0531  vmovaps [rsp+0x80], xmm8
000074fc119e053a  vmovaps [rsp+0x90], xmm9
000074fc119e0543  vmovaps [rsp+0xA0], xmm10
000074fc119e054c  vmovaps [rsp+0xB0], xmm11
000074fc119e0555  vmovaps [rsp+0xC0], xmm13
000074fc119e055e  vmovaps [rsp+0xD0], xmm14
000074fc119e0567  vmovaps [rsp+0xE0], xmm15
000074fc119e0570  sub rsp, 0x30
000074fc119e0574  movaps [rsp], xmm12
000074fc119e0579  movaps [rsp+0x10], xmm7
000074fc119e057e  movaps [rsp+0x20], xmm13
000074fc119e0584  lea rdi, [rsp]
000074fc119e0588  mov esi, 0x00
000074fc119e058d  mov rax, 0x58C4C8091530
000074fc119e0597  call rax
000074fc119e0599  movaps xmm12, [rsp]
000074fc119e059e  add rsp, 0x30
000074fc119e05a2  vmovaps xmm0, [rsp]
000074fc119e05a7  vmovaps xmm1, [rsp+0x10]
000074fc119e05ad  vmovaps xmm2, [rsp+0x20]
000074fc119e05b3  vmovaps xmm3, [rsp+0x30]
000074fc119e05b9  vmovaps xmm4, [rsp+0x40]
000074fc119e05bf  vmovaps xmm5, [rsp+0x50]
000074fc119e05c5  vmovaps xmm6, [rsp+0x60]
000074fc119e05cb  vmovaps xmm7, [rsp+0x70]
000074fc119e05d1  vmovaps xmm8, [rsp+0x80]
000074fc119e05da  vmovaps xmm9, [rsp+0x90]
000074fc119e05e3  vmovaps xmm10, [rsp+0xA0]
000074fc119e05ec  vmovaps xmm11, [rsp+0xB0]
000074fc119e05f5  vmovaps xmm13, [rsp+0xC0]
000074fc119e05fe  vmovaps xmm14, [rsp+0xD0]
000074fc119e0607  vmovaps xmm15, [rsp+0xE0]
000074fc119e0610  add rsp, 0xF0
000074fc119e0617  pop r11
000074fc119e0619  pop r10
000074fc119e061b  pop r9
000074fc119e061d  pop r8
000074fc119e061f  pop rsi
000074fc119e0620  pop rdi
000074fc119e0621  pop rdx
000074fc119e0622  pop rcx
000074fc119e0623  pop rax
000074fc119e0624  add rsp, 0x08
000074fc119e0628  jmp 0x000074FC119DC5F4
000074fc119e062d  sub rsp, 0x08
000074fc119e0631  push rax
000074fc119e0632  push rcx
000074fc119e0633  push rdx
000074fc119e0634  push rdi
000074fc119e0635  push rsi
000074fc119e0636  push r8
000074fc119e0638  push r9
000074fc119e063a  push r10
000074fc119e063c  push r11
000074fc119e063e  sub rsp, 0xF0
000074fc119e0645  vmovaps [rsp], xmm0
000074fc119e064a  vmovaps [rsp+0x10], xmm1
000074fc119e0650  vmovaps [rsp+0x20], xmm2
000074fc119e0656  vmovaps [rsp+0x30], xmm3
000074fc119e065c  vmovaps [rsp+0x40], xmm4
000074fc119e0662  vmovaps [rsp+0x50], xmm5
000074fc119e0668  vmovaps [rsp+0x60], xmm6
000074fc119e066e  vmovaps [rsp+0x70], xmm7
000074fc119e0674  vmovaps [rsp+0x80], xmm8
000074fc119e067d  vmovaps [rsp+0x90], xmm9
000074fc119e0686  vmovaps [rsp+0xA0], xmm10
000074fc119e068f  vmovaps [rsp+0xB0], xmm11
000074fc119e0698  vmovaps [rsp+0xC0], xmm12
000074fc119e06a1  vmovaps [rsp+0xD0], xmm14
000074fc119e06aa  vmovaps [rsp+0xE0], xmm15
000074fc119e06b3  sub rsp, 0x30
000074fc119e06b7  movaps [rsp], xmm13
000074fc119e06bc  movaps [rsp+0x10], xmm15
000074fc119e06c2  movaps [rsp+0x20], xmm8
000074fc119e06c8  lea rdi, [rsp]
000074fc119e06cc  mov esi, 0x00
000074fc119e06d1  mov rax, 0x58C4C8091530
000074fc119e06db  call rax
000074fc119e06dd  movaps xmm13, [rsp]
000074fc119e06e2  add rsp, 0x30
000074fc119e06e6  vmovaps xmm0, [rsp]
000074fc119e06eb  vmovaps xmm1, [rsp+0x10]
000074fc119e06f1  vmovaps xmm2, [rsp+0x20]
000074fc119e06f7  vmovaps xmm3, [rsp+0x30]
000074fc119e06fd  vmovaps xmm4, [rsp+0x40]
000074fc119e0703  vmovaps xmm5, [rsp+0x50]
000074fc119e0709  vmovaps xmm6, [rsp+0x60]
000074fc119e070f  vmovaps xmm7, [rsp+0x70]
000074fc119e0715  vmovaps xmm8, [rsp+0x80]
000074fc119e071e  vmovaps xmm9, [rsp+0x90]
000074fc119e0727  vmovaps xmm10, [rsp+0xA0]
000074fc119e0730  vmovaps xmm11, [rsp+0xB0]
000074fc119e0739  vmovaps xmm12, [rsp+0xC0]
000074fc119e0742  vmovaps xmm14, [rsp+0xD0]
000074fc119e074b  vmovaps xmm15, [rsp+0xE0]
000074fc119e0754  add rsp, 0xF0
000074fc119e075b  pop r11
000074fc119e075d  pop r10
000074fc119e075f  pop r9
000074fc119e0761  pop r8
000074fc119e0763  pop rsi
000074fc119e0764  pop rdi
000074fc119e0765  pop rdx
000074fc119e0766  pop rcx
000074fc119e0767  pop rax
000074fc119e0768  add rsp, 0x08
000074fc119e076c  jmp 0x000074FC119DC60F
000074fc119e0771  sub rsp, 0x08
000074fc119e0775  push rax
000074fc119e0776  push rcx
000074fc119e0777  push rdx
000074fc119e0778  push rdi
000074fc119e0779  push rsi
000074fc119e077a  push r8
000074fc119e077c  push r9
000074fc119e077e  push r10
000074fc119e0780  push r11
000074fc119e0782  sub rsp, 0xF0
000074fc119e0789  vmovaps [rsp], xmm0
000074fc119e078e  vmovaps [rsp+0x10], xmm1
000074fc119e0794  vmovaps [rsp+0x20], xmm2
000074fc119e079a  vmovaps [rsp+0x30], xmm3
000074fc119e07a0  vmovaps [rsp+0x40], xmm4
000074fc119e07a6  vmovaps [rsp+0x50], xmm5
000074fc119e07ac  vmovaps [rsp+0x60], xmm6
000074fc119e07b2  vmovaps [rsp+0x70], xmm7
000074fc119e07b8  vmovaps [rsp+0x80], xmm9
000074fc119e07c1  vmovaps [rsp+0x90], xmm10
000074fc119e07ca  vmovaps [rsp+0xA0], xmm11
000074fc119e07d3  vmovaps [rsp+0xB0], xmm12
000074fc119e07dc  vmovaps [rsp+0xC0], xmm13
000074fc119e07e5  vmovaps [rsp+0xD0], xmm14
000074fc119e07ee  vmovaps [rsp+0xE0], xmm15
000074fc119e07f7  sub rsp, 0x30
000074fc119e07fb  movaps [rsp], xmm8
000074fc119e0800  movaps [rsp+0x10], xmm15
000074fc119e0806  movaps [rsp+0x20], xmm9
000074fc119e080c  lea rdi, [rsp]
000074fc119e0810  mov esi, 0x00
000074fc119e0815  mov rax, 0x58C4C8091530
000074fc119e081f  call rax
000074fc119e0821  movaps xmm8, [rsp]
000074fc119e0826  add rsp, 0x30
000074fc119e082a  vmovaps xmm0, [rsp]
000074fc119e082f  vmovaps xmm1, [rsp+0x10]
000074fc119e0835  vmovaps xmm2, [rsp+0x20]
000074fc119e083b  vmovaps xmm3, [rsp+0x30]
000074fc119e0841  vmovaps xmm4, [rsp+0x40]
000074fc119e0847  vmovaps xmm5, [rsp+0x50]
000074fc119e084d  vmovaps xmm6, [rsp+0x60]
000074fc119e0853  vmovaps xmm7, [rsp+0x70]
000074fc119e0859  vmovaps xmm9, [rsp+0x80]
000074fc119e0862  vmovaps xmm10, [rsp+0x90]
000074fc119e086b  vmovaps xmm11, [rsp+0xA0]
000074fc119e0874  vmovaps xmm12, [rsp+0xB0]
000074fc119e087d  vmovaps xmm13, [rsp+0xC0]
000074fc119e0886  vmovaps xmm14, [rsp+0xD0]
000074fc119e088f  vmovaps xmm15, [rsp+0xE0]
000074fc119e0898  add rsp, 0xF0
000074fc119e089f  pop r11
000074fc119e08a1  pop r10
000074fc119e08a3  pop r9
000074fc119e08a5  pop r8
000074fc119e08a7  pop rsi
000074fc119e08a8  pop rdi
000074fc119e08a9  pop rdx
000074fc119e08aa  pop rcx
000074fc119e08ab  pop rax
000074fc119e08ac  add rsp, 0x08
000074fc119e08b0  jmp 0x000074FC119DC63D
000074fc119e08b5  sub rsp, 0x08
000074fc119e08b9  push rax
000074fc119e08ba  push rcx
000074fc119e08bb  push rdx
000074fc119e08bc  push rdi
000074fc119e08bd  push rsi
000074fc119e08be  push r8
000074fc119e08c0  push r9
000074fc119e08c2  push r10
000074fc119e08c4  push r11
000074fc119e08c6  sub rsp, 0xF0
000074fc119e08cd  vmovaps [rsp], xmm0
000074fc119e08d2  vmovaps [rsp+0x10], xmm1
000074fc119e08d8  vmovaps [rsp+0x20], xmm2
000074fc119e08de  vmovaps [rsp+0x30], xmm3
000074fc119e08e4  vmovaps [rsp+0x40], xmm4
000074fc119e08ea  vmovaps [rsp+0x50], xmm5
000074fc119e08f0  vmovaps [rsp+0x60], xmm6
000074fc119e08f6  vmovaps [rsp+0x70], xmm7
000074fc119e08fc  vmovaps [rsp+0x80], xmm8
000074fc119e0905  vmovaps [rsp+0x90], xmm9
000074fc119e090e  vmovaps [rsp+0xA0], xmm10
000074fc119e0917  vmovaps [rsp+0xB0], xmm11
000074fc119e0920  vmovaps [rsp+0xC0], xmm12
000074fc119e0929  vmovaps [rsp+0xD0], xmm13
000074fc119e0932  vmovaps [rsp+0xE0], xmm14
000074fc119e093b  sub rsp, 0x30
000074fc119e093f  movaps [rsp], xmm15
000074fc119e0944  movaps [rsp+0x10], xmm11
000074fc119e094a  movaps [rsp+0x20], xmm6
000074fc119e094f  lea rdi, [rsp]
000074fc119e0953  mov esi, 0x00
000074fc119e0958  mov rax, 0x58C4C8091530
000074fc119e0962  call rax
000074fc119e0964  movaps xmm15, [rsp]
000074fc119e0969  add rsp, 0x30
000074fc119e096d  vmovaps xmm0, [rsp]
000074fc119e0972  vmovaps xmm1, [rsp+0x10]
000074fc119e0978  vmovaps xmm2, [rsp+0x20]
000074fc119e097e  vmovaps xmm3, [rsp+0x30]
000074fc119e0984  vmovaps xmm4, [rsp+0x40]
000074fc119e098a  vmovaps xmm5, [rsp+0x50]
000074fc119e0990  vmovaps xmm6, [rsp+0x60]
000074fc119e0996  vmovaps xmm7, [rsp+0x70]
000074fc119e099c  vmovaps xmm8, [rsp+0x80]
000074fc119e09a5  vmovaps xmm9, [rsp+0x90]
000074fc119e09ae  vmovaps xmm10, [rsp+0xA0]
000074fc119e09b7  vmovaps xmm11, [rsp+0xB0]
000074fc119e09c0  vmovaps xmm12, [rsp+0xC0]
000074fc119e09c9  vmovaps xmm13, [rsp+0xD0]
000074fc119e09d2  vmovaps xmm14, [rsp+0xE0]
000074fc119e09db  add rsp, 0xF0
000074fc119e09e2  pop r11
000074fc119e09e4  pop r10
000074fc119e09e6  pop r9
000074fc119e09e8  pop r8
000074fc119e09ea  pop rsi
000074fc119e09eb  pop rdi
000074fc119e09ec  pop rdx
000074fc119e09ed  pop rcx
000074fc119e09ee  pop rax
000074fc119e09ef  add rsp, 0x08
000074fc119e09f3  jmp 0x000074FC119DC658
000074fc119e09f8  sub rsp, 0x08
000074fc119e09fc  push rax
000074fc119e09fd  push rcx
000074fc119e09fe  push rdx
000074fc119e09ff  push rdi
000074fc119e0a00  push rsi
000074fc119e0a01  push r8
000074fc119e0a03  push r9
000074fc119e0a05  push r10
000074fc119e0a07  push r11
000074fc119e0a09  sub rsp, 0xF0
000074fc119e0a10  vmovaps [rsp], xmm0
000074fc119e0a15  vmovaps [rsp+0x10], xmm1
000074fc119e0a1b  vmovaps [rsp+0x20], xmm2
000074fc119e0a21  vmovaps [rsp+0x30], xmm3
000074fc119e0a27  vmovaps [rsp+0x40], xmm4
000074fc119e0a2d  vmovaps [rsp+0x50], xmm5
000074fc119e0a33  vmovaps [rsp+0x60], xmm6
000074fc119e0a39  vmovaps [rsp+0x70], xmm8
000074fc119e0a3f  vmovaps [rsp+0x80], xmm9
000074fc119e0a48  vmovaps [rsp+0x90], xmm10
000074fc119e0a51  vmovaps [rsp+0xA0], xmm11
000074fc119e0a5a  vmovaps [rsp+0xB0], xmm12
000074fc119e0a63  vmovaps [rsp+0xC0], xmm13
000074fc119e0a6c  vmovaps [rsp+0xD0], xmm14
000074fc119e0a75  vmovaps [rsp+0xE0], xmm15
000074fc119e0a7e  sub rsp, 0x30
000074fc119e0a82  movaps [rsp], xmm7
000074fc119e0a86  movaps [rsp+0x10], xmm11
000074fc119e0a8c  movaps [rsp+0x20], xmm9
000074fc119e0a92  lea rdi, [rsp]
000074fc119e0a96  mov esi, 0x00
000074fc119e0a9b  mov rax, 0x58C4C8091530
000074fc119e0aa5  call rax
000074fc119e0aa7  movaps xmm7, [rsp]
000074fc119e0aab  add rsp, 0x30
000074fc119e0aaf  vmovaps xmm0, [rsp]
000074fc119e0ab4  vmovaps xmm1, [rsp+0x10]
000074fc119e0aba  vmovaps xmm2, [rsp+0x20]
000074fc119e0ac0  vmovaps xmm3, [rsp+0x30]
000074fc119e0ac6  vmovaps xmm4, [rsp+0x40]
000074fc119e0acc  vmovaps xmm5, [rsp+0x50]
000074fc119e0ad2  vmovaps xmm6, [rsp+0x60]
000074fc119e0ad8  vmovaps xmm8, [rsp+0x70]
000074fc119e0ade  vmovaps xmm9, [rsp+0x80]
000074fc119e0ae7  vmovaps xmm10, [rsp+0x90]
000074fc119e0af0  vmovaps xmm11, [rsp+0xA0]
000074fc119e0af9  vmovaps xmm12, [rsp+0xB0]
000074fc119e0b02  vmovaps xmm13, [rsp+0xC0]
000074fc119e0b0b  vmovaps xmm14, [rsp+0xD0]
000074fc119e0b14  vmovaps xmm15, [rsp+0xE0]
000074fc119e0b1d  add rsp, 0xF0
000074fc119e0b24  pop r11
000074fc119e0b26  pop r10
000074fc119e0b28  pop r9
000074fc119e0b2a  pop r8
000074fc119e0b2c  pop rsi
000074fc119e0b2d  pop rdi
000074fc119e0b2e  pop rdx
000074fc119e0b2f  pop rcx
000074fc119e0b30  pop rax
000074fc119e0b31  add rsp, 0x08
000074fc119e0b35  jmp 0x000074FC119DC685
000074fc119e0b3a  sub rsp, 0x08
000074fc119e0b3e  push rax
000074fc119e0b3f  push rcx
000074fc119e0b40  push rdx
000074fc119e0b41  push rdi
000074fc119e0b42  push rsi
000074fc119e0b43  push r8
000074fc119e0b45  push r9
000074fc119e0b47  push r10
000074fc119e0b49  push r11
000074fc119e0b4b  sub rsp, 0xF0
000074fc119e0b52  vmovaps [rsp], xmm0
000074fc119e0b57  vmovaps [rsp+0x10], xmm1
000074fc119e0b5d  vmovaps [rsp+0x20], xmm2
000074fc119e0b63  vmovaps [rsp+0x30], xmm3
000074fc119e0b69  vmovaps [rsp+0x40], xmm4
000074fc119e0b6f  vmovaps [rsp+0x50], xmm5
000074fc119e0b75  vmovaps [rsp+0x60], xmm6
000074fc119e0b7b  vmovaps [rsp+0x70], xmm7
000074fc119e0b81  vmovaps [rsp+0x80], xmm8
000074fc119e0b8a  vmovaps [rsp+0x90], xmm9
000074fc119e0b93  vmovaps [rsp+0xA0], xmm10
000074fc119e0b9c  vmovaps [rsp+0xB0], xmm12
000074fc119e0ba5  vmovaps [rsp+0xC0], xmm13
000074fc119e0bae  vmovaps [rsp+0xD0], xmm14
000074fc119e0bb7  vmovaps [rsp+0xE0], xmm15
000074fc119e0bc0  sub rsp, 0x30
000074fc119e0bc4  movaps [rsp], xmm11
000074fc119e0bc9  movaps [rsp+0x10], xmm10
000074fc119e0bcf  movaps [rsp+0x20], xmm14
000074fc119e0bd5  lea rdi, [rsp]
000074fc119e0bd9  mov esi, 0x00
000074fc119e0bde  mov rax, 0x58C4C8091530
000074fc119e0be8  call rax
000074fc119e0bea  movaps xmm11, [rsp]
000074fc119e0bef  add rsp, 0x30
000074fc119e0bf3  vmovaps xmm0, [rsp]
000074fc119e0bf8  vmovaps xmm1, [rsp+0x10]
000074fc119e0bfe  vmovaps xmm2, [rsp+0x20]
000074fc119e0c04  vmovaps xmm3, [rsp+0x30]
000074fc119e0c0a  vmovaps xmm4, [rsp+0x40]
000074fc119e0c10  vmovaps xmm5, [rsp+0x50]
000074fc119e0c16  vmovaps xmm6, [rsp+0x60]
000074fc119e0c1c  vmovaps xmm7, [rsp+0x70]
000074fc119e0c22  vmovaps xmm8, [rsp+0x80]
000074fc119e0c2b  vmovaps xmm9, [rsp+0x90]
000074fc119e0c34  vmovaps xmm10, [rsp+0xA0]
000074fc119e0c3d  vmovaps xmm12, [rsp+0xB0]
000074fc119e0c46  vmovaps xmm13, [rsp+0xC0]
000074fc119e0c4f  vmovaps xmm14, [rsp+0xD0]
000074fc119e0c58  vmovaps xmm15, [rsp+0xE0]
000074fc119e0c61  add rsp, 0xF0
000074fc119e0c68  pop r11
000074fc119e0c6a  pop r10
000074fc119e0c6c  pop r9
000074fc119e0c6e  pop r8
000074fc119e0c70  pop rsi
000074fc119e0c71  pop rdi
000074fc119e0c72  pop rdx
000074fc119e0c73  pop rcx
000074fc119e0c74  pop rax
000074fc119e0c75  add rsp, 0x08
000074fc119e0c79  jmp 0x000074FC119DC6A0
000074fc119e0c7e  call 0x000074FC118C33A0
000074fc119e0c83  jmp 0x000074FC119DC6AA
000074fc119e0c88  sub rsp, 0x08
000074fc119e0c8c  push rax
000074fc119e0c8d  push rcx
000074fc119e0c8e  push rdx
000074fc119e0c8f  push rdi
000074fc119e0c90  push rsi
000074fc119e0c91  push r8
000074fc119e0c93  push r9
000074fc119e0c95  push r10
000074fc119e0c97  push r11
000074fc119e0c99  sub rsp, 0xF0
000074fc119e0ca0  vmovaps [rsp], xmm0
000074fc119e0ca5  vmovaps [rsp+0x10], xmm1
000074fc119e0cab  vmovaps [rsp+0x20], xmm2
000074fc119e0cb1  vmovaps [rsp+0x30], xmm3
000074fc119e0cb7  vmovaps [rsp+0x40], xmm4
000074fc119e0cbd  vmovaps [rsp+0x50], xmm5
000074fc119e0cc3  vmovaps [rsp+0x60], xmm6
000074fc119e0cc9  vmovaps [rsp+0x70], xmm7
000074fc119e0ccf  vmovaps [rsp+0x80], xmm8
000074fc119e0cd8  vmovaps [rsp+0x90], xmm9
000074fc119e0ce1  vmovaps [rsp+0xA0], xmm11
000074fc119e0cea  vmovaps [rsp+0xB0], xmm12
000074fc119e0cf3  vmovaps [rsp+0xC0], xmm13
000074fc119e0cfc  vmovaps [rsp+0xD0], xmm14
000074fc119e0d05  vmovaps [rsp+0xE0], xmm15
000074fc119e0d0e  sub rsp, 0x30
000074fc119e0d12  movaps [rsp], xmm10
000074fc119e0d17  movaps [rsp+0x10], xmm1
000074fc119e0d1c  movaps [rsp+0x20], xmm12
000074fc119e0d22  lea rdi, [rsp]
000074fc119e0d26  mov esi, 0x00
000074fc119e0d2b  mov rax, 0x58C4C8091530
000074fc119e0d35  call rax
000074fc119e0d37  movaps xmm10, [rsp]
000074fc119e0d3c  add rsp, 0x30
000074fc119e0d40  vmovaps xmm0, [rsp]
000074fc119e0d45  vmovaps xmm1, [rsp+0x10]
000074fc119e0d4b  vmovaps xmm2, [rsp+0x20]
000074fc119e0d51  vmovaps xmm3, [rsp+0x30]
000074fc119e0d57  vmovaps xmm4, [rsp+0x40]
000074fc119e0d5d  vmovaps xmm5, [rsp+0x50]
000074fc119e0d63  vmovaps xmm6, [rsp+0x60]
000074fc119e0d69  vmovaps xmm7, [rsp+0x70]
000074fc119e0d6f  vmovaps xmm8, [rsp+0x80]
000074fc119e0d78  vmovaps xmm9, [rsp+0x90]
000074fc119e0d81  vmovaps xmm11, [rsp+0xA0]
000074fc119e0d8a  vmovaps xmm12, [rsp+0xB0]
000074fc119e0d93  vmovaps xmm13, [rsp+0xC0]
000074fc119e0d9c  vmovaps xmm14, [rsp+0xD0]
000074fc119e0da5  vmovaps xmm15, [rsp+0xE0]
000074fc119e0dae  add rsp, 0xF0
000074fc119e0db5  pop r11
000074fc119e0db7  pop r10
000074fc119e0db9  pop r9
000074fc119e0dbb  pop r8
000074fc119e0dbd  pop rsi
000074fc119e0dbe  pop rdi
000074fc119e0dbf  pop rdx
000074fc119e0dc0  pop rcx
000074fc119e0dc1  pop rax
000074fc119e0dc2  add rsp, 0x08
000074fc119e0dc6  jmp 0x000074FC119DC6CD
000074fc119e0dcb  sub rsp, 0x08
000074fc119e0dcf  push rax
000074fc119e0dd0  push rcx
000074fc119e0dd1  push rdx
000074fc119e0dd2  push rdi
000074fc119e0dd3  push rsi
000074fc119e0dd4  push r8
000074fc119e0dd6  push r9
000074fc119e0dd8  push r10
000074fc119e0dda  push r11
000074fc119e0ddc  sub rsp, 0xF0
000074fc119e0de3  vmovaps [rsp], xmm0
000074fc119e0de8  vmovaps [rsp+0x10], xmm1
000074fc119e0dee  vmovaps [rsp+0x20], xmm2
000074fc119e0df4  vmovaps [rsp+0x30], xmm3
000074fc119e0dfa  vmovaps [rsp+0x40], xmm4
000074fc119e0e00  vmovaps [rsp+0x50], xmm5
000074fc119e0e06  vmovaps [rsp+0x60], xmm6
000074fc119e0e0c  vmovaps [rsp+0x70], xmm7
000074fc119e0e12  vmovaps [rsp+0x80], xmm8
000074fc119e0e1b  vmovaps [rsp+0x90], xmm9
000074fc119e0e24  vmovaps [rsp+0xA0], xmm10
000074fc119e0e2d  vmovaps [rsp+0xB0], xmm11
000074fc119e0e36  vmovaps [rsp+0xC0], xmm13
000074fc119e0e3f  vmovaps [rsp+0xD0], xmm14
000074fc119e0e48  vmovaps [rsp+0xE0], xmm15
000074fc119e0e51  sub rsp, 0x30
000074fc119e0e55  movaps [rsp], xmm12
000074fc119e0e5a  movaps [rsp+0x10], xmm14
000074fc119e0e60  movaps [rsp+0x20], xmm1
000074fc119e0e65  lea rdi, [rsp]
000074fc119e0e69  mov esi, 0x00
000074fc119e0e6e  mov rax, 0x58C4C8091530
000074fc119e0e78  call rax
000074fc119e0e7a  movaps xmm12, [rsp]
000074fc119e0e7f  add rsp, 0x30
000074fc119e0e83  vmovaps xmm0, [rsp]
000074fc119e0e88  vmovaps xmm1, [rsp+0x10]
000074fc119e0e8e  vmovaps xmm2, [rsp+0x20]
000074fc119e0e94  vmovaps xmm3, [rsp+0x30]
000074fc119e0e9a  vmovaps xmm4, [rsp+0x40]
000074fc119e0ea0  vmovaps xmm5, [rsp+0x50]
000074fc119e0ea6  vmovaps xmm6, [rsp+0x60]
000074fc119e0eac  vmovaps xmm7, [rsp+0x70]
000074fc119e0eb2  vmovaps xmm8, [rsp+0x80]
000074fc119e0ebb  vmovaps xmm9, [rsp+0x90]
000074fc119e0ec4  vmovaps xmm10, [rsp+0xA0]
000074fc119e0ecd  vmovaps xmm11, [rsp+0xB0]
000074fc119e0ed6  vmovaps xmm13, [rsp+0xC0]
000074fc119e0edf  vmovaps xmm14, [rsp+0xD0]
000074fc119e0ee8  vmovaps xmm15, [rsp+0xE0]
000074fc119e0ef1  add rsp, 0xF0
000074fc119e0ef8  pop r11
000074fc119e0efa  pop r10
000074fc119e0efc  pop r9
000074fc119e0efe  pop r8
000074fc119e0f00  pop rsi
000074fc119e0f01  pop rdi
000074fc119e0f02  pop rdx
000074fc119e0f03  pop rcx
000074fc119e0f04  pop rax
000074fc119e0f05  add rsp, 0x08
000074fc119e0f09  jmp 0x000074FC119DC6FC
000074fc119e0f0e  sub rsp, 0x08
000074fc119e0f12  push rax
000074fc119e0f13  push rcx
000074fc119e0f14  push rdx
000074fc119e0f15  push rdi
000074fc119e0f16  push rsi
000074fc119e0f17  push r8
000074fc119e0f19  push r9
000074fc119e0f1b  push r10
000074fc119e0f1d  push r11
000074fc119e0f1f  sub rsp, 0xF0
000074fc119e0f26  vmovaps [rsp], xmm0
000074fc119e0f2b  vmovaps [rsp+0x10], xmm1
000074fc119e0f31  vmovaps [rsp+0x20], xmm2
000074fc119e0f37  vmovaps [rsp+0x30], xmm3
000074fc119e0f3d  vmovaps [rsp+0x40], xmm4
000074fc119e0f43  vmovaps [rsp+0x50], xmm5
000074fc119e0f49  vmovaps [rsp+0x60], xmm6
000074fc119e0f4f  vmovaps [rsp+0x70], xmm7
000074fc119e0f55  vmovaps [rsp+0x80], xmm8
000074fc119e0f5e  vmovaps [rsp+0x90], xmm9
000074fc119e0f67  vmovaps [rsp+0xA0], xmm10
000074fc119e0f70  vmovaps [rsp+0xB0], xmm11
000074fc119e0f79  vmovaps [rsp+0xC0], xmm12
000074fc119e0f82  vmovaps [rsp+0xD0], xmm13
000074fc119e0f8b  vmovaps [rsp+0xE0], xmm15
000074fc119e0f94  sub rsp, 0x30
000074fc119e0f98  movaps [rsp], xmm14
000074fc119e0f9d  movaps [rsp+0x10], xmm9
000074fc119e0fa3  movaps [rsp+0x20], xmm1
000074fc119e0fa8  lea rdi, [rsp]
000074fc119e0fac  mov esi, 0x00
000074fc119e0fb1  mov rax, 0x58C4C8091530
000074fc119e0fbb  call rax
000074fc119e0fbd  movaps xmm14, [rsp]
000074fc119e0fc2  add rsp, 0x30
000074fc119e0fc6  vmovaps xmm0, [rsp]
000074fc119e0fcb  vmovaps xmm1, [rsp+0x10]
000074fc119e0fd1  vmovaps xmm2, [rsp+0x20]
000074fc119e0fd7  vmovaps xmm3, [rsp+0x30]
000074fc119e0fdd  vmovaps xmm4, [rsp+0x40]
000074fc119e0fe3  vmovaps xmm5, [rsp+0x50]
000074fc119e0fe9  vmovaps xmm6, [rsp+0x60]
000074fc119e0fef  vmovaps xmm7, [rsp+0x70]
000074fc119e0ff5  vmovaps xmm8, [rsp+0x80]
000074fc119e0ffe  vmovaps xmm9, [rsp+0x90]
000074fc119e1007  vmovaps xmm10, [rsp+0xA0]
000074fc119e1010  vmovaps xmm11, [rsp+0xB0]
000074fc119e1019  vmovaps xmm12, [rsp+0xC0]
000074fc119e1022  vmovaps xmm13, [rsp+0xD0]
000074fc119e102b  vmovaps xmm15, [rsp+0xE0]
000074fc119e1034  add rsp, 0xF0
000074fc119e103b  pop r11
000074fc119e103d  pop r10
000074fc119e103f  pop r9
000074fc119e1041  pop r8
000074fc119e1043  pop rsi
000074fc119e1044  pop rdi
000074fc119e1045  pop rdx
000074fc119e1046  pop rcx
000074fc119e1047  pop rax
000074fc119e1048  add rsp, 0x08
000074fc119e104c  jmp 0x000074FC119DC72B
000074fc119e1051  sub rsp, 0x08
000074fc119e1055  push rax
000074fc119e1056  push rcx
000074fc119e1057  push rdx
000074fc119e1058  push rdi
000074fc119e1059  push rsi
000074fc119e105a  push r8
000074fc119e105c  push r9
000074fc119e105e  push r10
000074fc119e1060  push r11
000074fc119e1062  sub rsp, 0xF0
000074fc119e1069  vmovaps [rsp], xmm0
000074fc119e106e  vmovaps [rsp+0x10], xmm2
000074fc119e1074  vmovaps [rsp+0x20], xmm3
000074fc119e107a  vmovaps [rsp+0x30], xmm4
000074fc119e1080  vmovaps [rsp+0x40], xmm5
000074fc119e1086  vmovaps [rsp+0x50], xmm6
000074fc119e108c  vmovaps [rsp+0x60], xmm7
000074fc119e1092  vmovaps [rsp+0x70], xmm8
000074fc119e1098  vmovaps [rsp+0x80], xmm9
000074fc119e10a1  vmovaps [rsp+0x90], xmm10
000074fc119e10aa  vmovaps [rsp+0xA0], xmm11
000074fc119e10b3  vmovaps [rsp+0xB0], xmm12
000074fc119e10bc  vmovaps [rsp+0xC0], xmm13
000074fc119e10c5  vmovaps [rsp+0xD0], xmm14
000074fc119e10ce  vmovaps [rsp+0xE0], xmm15
000074fc119e10d7  sub rsp, 0x30
000074fc119e10db  movaps [rsp], xmm1
000074fc119e10df  movaps [rsp+0x10], xmm13
000074fc119e10e5  movaps [rsp+0x20], xmm8
000074fc119e10eb  lea rdi, [rsp]
000074fc119e10ef  mov esi, 0x00
000074fc119e10f4  mov rax, 0x58C4C8091530
000074fc119e10fe  call rax
000074fc119e1100  movaps xmm1, [rsp]
000074fc119e1104  add rsp, 0x30
000074fc119e1108  vmovaps xmm0, [rsp]
000074fc119e110d  vmovaps xmm2, [rsp+0x10]
000074fc119e1113  vmovaps xmm3, [rsp+0x20]
000074fc119e1119  vmovaps xmm4, [rsp+0x30]
000074fc119e111f  vmovaps xmm5, [rsp+0x40]
000074fc119e1125  vmovaps xmm6, [rsp+0x50]
000074fc119e112b  vmovaps xmm7, [rsp+0x60]
000074fc119e1131  vmovaps xmm8, [rsp+0x70]
000074fc119e1137  vmovaps xmm9, [rsp+0x80]
000074fc119e1140  vmovaps xmm10, [rsp+0x90]
000074fc119e1149  vmovaps xmm11, [rsp+0xA0]
000074fc119e1152  vmovaps xmm12, [rsp+0xB0]
000074fc119e115b  vmovaps xmm13, [rsp+0xC0]
000074fc119e1164  vmovaps xmm14, [rsp+0xD0]
000074fc119e116d  vmovaps xmm15, [rsp+0xE0]
000074fc119e1176  add rsp, 0xF0
000074fc119e117d  pop r11
000074fc119e117f  pop r10
000074fc119e1181  pop r9
000074fc119e1183  pop r8
000074fc119e1185  pop rsi
000074fc119e1186  pop rdi
000074fc119e1187  pop rdx
000074fc119e1188  pop rcx
000074fc119e1189  pop rax
000074fc119e118a  add rsp, 0x08
000074fc119e118e  jmp 0x000074FC119DC74D
000074fc119e1193  call 0x000074FC1180C260
000074fc119e1198  jmp 0x000074FC119DC75B
000074fc119e119d  call 0x000074FC118BD750
000074fc119e11a2  jmp 0x000074FC119DC765
000074fc119e11a7  sub rsp, 0x08
000074fc119e11ab  push rax
000074fc119e11ac  push rcx
000074fc119e11ad  push rdx
000074fc119e11ae  push rdi
000074fc119e11af  push rsi
000074fc119e11b0  push r8
000074fc119e11b2  push r9
000074fc119e11b4  push r10
000074fc119e11b6  push r11
000074fc119e11b8  sub rsp, 0xF0
000074fc119e11bf  vmovaps [rsp], xmm0
000074fc119e11c4  vmovaps [rsp+0x10], xmm1
000074fc119e11ca  vmovaps [rsp+0x20], xmm2
000074fc119e11d0  vmovaps [rsp+0x30], xmm3
000074fc119e11d6  vmovaps [rsp+0x40], xmm4
000074fc119e11dc  vmovaps [rsp+0x50], xmm5
000074fc119e11e2  vmovaps [rsp+0x60], xmm6
000074fc119e11e8  vmovaps [rsp+0x70], xmm7
000074fc119e11ee  vmovaps [rsp+0x80], xmm9
000074fc119e11f7  vmovaps [rsp+0x90], xmm10
000074fc119e1200  vmovaps [rsp+0xA0], xmm11
000074fc119e1209  vmovaps [rsp+0xB0], xmm12
000074fc119e1212  vmovaps [rsp+0xC0], xmm13
000074fc119e121b  vmovaps [rsp+0xD0], xmm14
000074fc119e1224  vmovaps [rsp+0xE0], xmm15
000074fc119e122d  sub rsp, 0x30
000074fc119e1231  movaps [rsp], xmm8
000074fc119e1236  movaps [rsp+0x10], xmm15
000074fc119e123c  movaps [rsp+0x20], xmm7
000074fc119e1241  lea rdi, [rsp]
000074fc119e1245  mov esi, 0x00
000074fc119e124a  mov rax, 0x58C4C8091530
000074fc119e1254  call rax
000074fc119e1256  movaps xmm8, [rsp]
000074fc119e125b  add rsp, 0x30
000074fc119e125f  vmovaps xmm0, [rsp]
000074fc119e1264  vmovaps xmm1, [rsp+0x10]
000074fc119e126a  vmovaps xmm2, [rsp+0x20]
000074fc119e1270  vmovaps xmm3, [rsp+0x30]
000074fc119e1276  vmovaps xmm4, [rsp+0x40]
000074fc119e127c  vmovaps xmm5, [rsp+0x50]
000074fc119e1282  vmovaps xmm6, [rsp+0x60]
000074fc119e1288  vmovaps xmm7, [rsp+0x70]
000074fc119e128e  vmovaps xmm9, [rsp+0x80]
000074fc119e1297  vmovaps xmm10, [rsp+0x90]
000074fc119e12a0  vmovaps xmm11, [rsp+0xA0]
000074fc119e12a9  vmovaps xmm12, [rsp+0xB0]
000074fc119e12b2  vmovaps xmm13, [rsp+0xC0]
000074fc119e12bb  vmovaps xmm14, [rsp+0xD0]
000074fc119e12c4  vmovaps xmm15, [rsp+0xE0]
000074fc119e12cd  add rsp, 0xF0
000074fc119e12d4  pop r11
000074fc119e12d6  pop r10
000074fc119e12d8  pop r9
000074fc119e12da  pop r8
000074fc119e12dc  pop rsi
000074fc119e12dd  pop rdi
000074fc119e12de  pop rdx
000074fc119e12df  pop rcx
000074fc119e12e0  pop rax
000074fc119e12e1  add rsp, 0x08
000074fc119e12e5  jmp 0x000074FC119DC787
000074fc119e12ea  sub rsp, 0x08
000074fc119e12ee  push rax
000074fc119e12ef  push rcx
000074fc119e12f0  push rdx
000074fc119e12f1  push rdi
000074fc119e12f2  push rsi
000074fc119e12f3  push r8
000074fc119e12f5  push r9
000074fc119e12f7  push r10
000074fc119e12f9  push r11
000074fc119e12fb  sub rsp, 0xF0
000074fc119e1302  vmovaps [rsp], xmm0
000074fc119e1307  vmovaps [rsp+0x10], xmm1
000074fc119e130d  vmovaps [rsp+0x20], xmm2
000074fc119e1313  vmovaps [rsp+0x30], xmm3
000074fc119e1319  vmovaps [rsp+0x40], xmm4
000074fc119e131f  vmovaps [rsp+0x50], xmm5
000074fc119e1325  vmovaps [rsp+0x60], xmm6
000074fc119e132b  vmovaps [rsp+0x70], xmm8
000074fc119e1331  vmovaps [rsp+0x80], xmm9
000074fc119e133a  vmovaps [rsp+0x90], xmm10
000074fc119e1343  vmovaps [rsp+0xA0], xmm11
000074fc119e134c  vmovaps [rsp+0xB0], xmm12
000074fc119e1355  vmovaps [rsp+0xC0], xmm13
000074fc119e135e  vmovaps [rsp+0xD0], xmm14
000074fc119e1367  vmovaps [rsp+0xE0], xmm15
000074fc119e1370  sub rsp, 0x30
000074fc119e1374  movaps [rsp], xmm7
000074fc119e1378  movaps [rsp+0x10], xmm9
000074fc119e137e  movaps [rsp+0x20], xmm15
000074fc119e1384  lea rdi, [rsp]
000074fc119e1388  mov esi, 0x00
000074fc119e138d  mov rax, 0x58C4C8091530
000074fc119e1397  call rax
000074fc119e1399  movaps xmm7, [rsp]
000074fc119e139d  add rsp, 0x30
000074fc119e13a1  vmovaps xmm0, [rsp]
000074fc119e13a6  vmovaps xmm1, [rsp+0x10]
000074fc119e13ac  vmovaps xmm2, [rsp+0x20]
000074fc119e13b2  vmovaps xmm3, [rsp+0x30]
000074fc119e13b8  vmovaps xmm4, [rsp+0x40]
000074fc119e13be  vmovaps xmm5, [rsp+0x50]
000074fc119e13c4  vmovaps xmm6, [rsp+0x60]
000074fc119e13ca  vmovaps xmm8, [rsp+0x70]
000074fc119e13d0  vmovaps xmm9, [rsp+0x80]
000074fc119e13d9  vmovaps xmm10, [rsp+0x90]
000074fc119e13e2  vmovaps xmm11, [rsp+0xA0]
000074fc119e13eb  vmovaps xmm12, [rsp+0xB0]
000074fc119e13f4  vmovaps xmm13, [rsp+0xC0]
000074fc119e13fd  vmovaps xmm14, [rsp+0xD0]
000074fc119e1406  vmovaps xmm15, [rsp+0xE0]
000074fc119e140f  add rsp, 0xF0
000074fc119e1416  pop r11
000074fc119e1418  pop r10
000074fc119e141a  pop r9
000074fc119e141c  pop r8
000074fc119e141e  pop rsi
000074fc119e141f  pop rdi
000074fc119e1420  pop rdx
000074fc119e1421  pop rcx
000074fc119e1422  pop rax
000074fc119e1423  add rsp, 0x08
000074fc119e1427  jmp 0x000074FC119DC7B4
000074fc119e142c  sub rsp, 0x08
000074fc119e1430  push rax
000074fc119e1431  push rcx
000074fc119e1432  push rdx
000074fc119e1433  push rdi
000074fc119e1434  push rsi
000074fc119e1435  push r8
000074fc119e1437  push r9
000074fc119e1439  push r10
000074fc119e143b  push r11
000074fc119e143d  sub rsp, 0xF0
000074fc119e1444  vmovaps [rsp], xmm0
000074fc119e1449  vmovaps [rsp+0x10], xmm1
000074fc119e144f  vmovaps [rsp+0x20], xmm2
000074fc119e1455  vmovaps [rsp+0x30], xmm3
000074fc119e145b  vmovaps [rsp+0x40], xmm4
000074fc119e1461  vmovaps [rsp+0x50], xmm5
000074fc119e1467  vmovaps [rsp+0x60], xmm6
000074fc119e146d  vmovaps [rsp+0x70], xmm7
000074fc119e1473  vmovaps [rsp+0x80], xmm8
000074fc119e147c  vmovaps [rsp+0x90], xmm10
000074fc119e1485  vmovaps [rsp+0xA0], xmm11
000074fc119e148e  vmovaps [rsp+0xB0], xmm12
000074fc119e1497  vmovaps [rsp+0xC0], xmm13
000074fc119e14a0  vmovaps [rsp+0xD0], xmm14
000074fc119e14a9  vmovaps [rsp+0xE0], xmm15
000074fc119e14b2  sub rsp, 0x30
000074fc119e14b6  movaps [rsp], xmm9
000074fc119e14bb  movaps [rsp+0x10], xmm13
000074fc119e14c1  movaps [rsp+0x20], xmm15
000074fc119e14c7  lea rdi, [rsp]
000074fc119e14cb  mov esi, 0x00
000074fc119e14d0  mov rax, 0x58C4C8091530
000074fc119e14da  call rax
000074fc119e14dc  movaps xmm9, [rsp]
000074fc119e14e1  add rsp, 0x30
000074fc119e14e5  vmovaps xmm0, [rsp]
000074fc119e14ea  vmovaps xmm1, [rsp+0x10]
000074fc119e14f0  vmovaps xmm2, [rsp+0x20]
000074fc119e14f6  vmovaps xmm3, [rsp+0x30]
000074fc119e14fc  vmovaps xmm4, [rsp+0x40]
000074fc119e1502  vmovaps xmm5, [rsp+0x50]
000074fc119e1508  vmovaps xmm6, [rsp+0x60]
000074fc119e150e  vmovaps xmm7, [rsp+0x70]
000074fc119e1514  vmovaps xmm8, [rsp+0x80]
000074fc119e151d  vmovaps xmm10, [rsp+0x90]
000074fc119e1526  vmovaps xmm11, [rsp+0xA0]
000074fc119e152f  vmovaps xmm12, [rsp+0xB0]
000074fc119e1538  vmovaps xmm13, [rsp+0xC0]
000074fc119e1541  vmovaps xmm14, [rsp+0xD0]
000074fc119e154a  vmovaps xmm15, [rsp+0xE0]
000074fc119e1553  add rsp, 0xF0
000074fc119e155a  pop r11
000074fc119e155c  pop r10
000074fc119e155e  pop r9
000074fc119e1560  pop r8
000074fc119e1562  pop rsi
000074fc119e1563  pop rdi
000074fc119e1564  pop rdx
000074fc119e1565  pop rcx
000074fc119e1566  pop rax
000074fc119e1567  add rsp, 0x08
000074fc119e156b  jmp 0x000074FC119DC7E2
000074fc119e1570  sub rsp, 0x08
000074fc119e1574  push rax
000074fc119e1575  push rcx
000074fc119e1576  push rdx
000074fc119e1577  push rdi
000074fc119e1578  push rsi
000074fc119e1579  push r8
000074fc119e157b  push r9
000074fc119e157d  push r10
000074fc119e157f  push r11
000074fc119e1581  sub rsp, 0xF0
000074fc119e1588  vmovaps [rsp], xmm0
000074fc119e158d  vmovaps [rsp+0x10], xmm1
000074fc119e1593  vmovaps [rsp+0x20], xmm2
000074fc119e1599  vmovaps [rsp+0x30], xmm3
000074fc119e159f  vmovaps [rsp+0x40], xmm4
000074fc119e15a5  vmovaps [rsp+0x50], xmm5
000074fc119e15ab  vmovaps [rsp+0x60], xmm6
000074fc119e15b1  vmovaps [rsp+0x70], xmm7
000074fc119e15b7  vmovaps [rsp+0x80], xmm8
000074fc119e15c0  vmovaps [rsp+0x90], xmm9
000074fc119e15c9  vmovaps [rsp+0xA0], xmm10
000074fc119e15d2  vmovaps [rsp+0xB0], xmm11
000074fc119e15db  vmovaps [rsp+0xC0], xmm12
000074fc119e15e4  vmovaps [rsp+0xD0], xmm13
000074fc119e15ed  vmovaps [rsp+0xE0], xmm14
000074fc119e15f6  sub rsp, 0x30
000074fc119e15fa  movaps [rsp], xmm15
000074fc119e15ff  movaps [rsp+0x10], xmm11
000074fc119e1605  movaps [rsp+0x20], xmm12
000074fc119e160b  lea rdi, [rsp]
000074fc119e160f  mov esi, 0x00
000074fc119e1614  mov rax, 0x58C4C8091530
000074fc119e161e  call rax
000074fc119e1620  movaps xmm15, [rsp]
000074fc119e1625  add rsp, 0x30
000074fc119e1629  vmovaps xmm0, [rsp]
000074fc119e162e  vmovaps xmm1, [rsp+0x10]
000074fc119e1634  vmovaps xmm2, [rsp+0x20]
000074fc119e163a  vmovaps xmm3, [rsp+0x30]
000074fc119e1640  vmovaps xmm4, [rsp+0x40]
000074fc119e1646  vmovaps xmm5, [rsp+0x50]
000074fc119e164c  vmovaps xmm6, [rsp+0x60]
000074fc119e1652  vmovaps xmm7, [rsp+0x70]
000074fc119e1658  vmovaps xmm8, [rsp+0x80]
000074fc119e1661  vmovaps xmm9, [rsp+0x90]
000074fc119e166a  vmovaps xmm10, [rsp+0xA0]
000074fc119e1673  vmovaps xmm11, [rsp+0xB0]
000074fc119e167c  vmovaps xmm12, [rsp+0xC0]
000074fc119e1685  vmovaps xmm13, [rsp+0xD0]
000074fc119e168e  vmovaps xmm14, [rsp+0xE0]
000074fc119e1697  add rsp, 0xF0
000074fc119e169e  pop r11
000074fc119e16a0  pop r10
000074fc119e16a2  pop r9
000074fc119e16a4  pop r8
000074fc119e16a6  pop rsi
000074fc119e16a7  pop rdi
000074fc119e16a8  pop rdx
000074fc119e16a9  pop rcx
000074fc119e16aa  pop rax
000074fc119e16ab  add rsp, 0x08
000074fc119e16af  jmp 0x000074FC119DC7FD
000074fc119e16b4  sub rsp, 0x08
000074fc119e16b8  push rax
000074fc119e16b9  push rcx
000074fc119e16ba  push rdx
000074fc119e16bb  push rdi
000074fc119e16bc  push rsi
000074fc119e16bd  push r8
000074fc119e16bf  push r9
000074fc119e16c1  push r10
000074fc119e16c3  push r11
000074fc119e16c5  sub rsp, 0xF0
000074fc119e16cc  vmovaps [rsp], xmm0
000074fc119e16d1  vmovaps [rsp+0x10], xmm1
000074fc119e16d7  vmovaps [rsp+0x20], xmm2
000074fc119e16dd  vmovaps [rsp+0x30], xmm3
000074fc119e16e3  vmovaps [rsp+0x40], xmm4
000074fc119e16e9  vmovaps [rsp+0x50], xmm5
000074fc119e16ef  vmovaps [rsp+0x60], xmm6
000074fc119e16f5  vmovaps [rsp+0x70], xmm7
000074fc119e16fb  vmovaps [rsp+0x80], xmm8
000074fc119e1704  vmovaps [rsp+0x90], xmm9
000074fc119e170d  vmovaps [rsp+0xA0], xmm10
000074fc119e1716  vmovaps [rsp+0xB0], xmm11
000074fc119e171f  vmovaps [rsp+0xC0], xmm12
000074fc119e1728  vmovaps [rsp+0xD0], xmm14
000074fc119e1731  vmovaps [rsp+0xE0], xmm15
000074fc119e173a  sub rsp, 0x30
000074fc119e173e  movaps [rsp], xmm13
000074fc119e1743  movaps [rsp+0x10], xmm10
000074fc119e1749  movaps [rsp+0x20], xmm14
000074fc119e174f  lea rdi, [rsp]
000074fc119e1753  mov esi, 0x00
000074fc119e1758  mov rax, 0x58C4C8091530
000074fc119e1762  call rax
000074fc119e1764  movaps xmm13, [rsp]
000074fc119e1769  add rsp, 0x30
000074fc119e176d  vmovaps xmm0, [rsp]
000074fc119e1772  vmovaps xmm1, [rsp+0x10]
000074fc119e1778  vmovaps xmm2, [rsp+0x20]
000074fc119e177e  vmovaps xmm3, [rsp+0x30]
000074fc119e1784  vmovaps xmm4, [rsp+0x40]
000074fc119e178a  vmovaps xmm5, [rsp+0x50]
000074fc119e1790  vmovaps xmm6, [rsp+0x60]
000074fc119e1796  vmovaps xmm7, [rsp+0x70]
000074fc119e179c  vmovaps xmm8, [rsp+0x80]
000074fc119e17a5  vmovaps xmm9, [rsp+0x90]
000074fc119e17ae  vmovaps xmm10, [rsp+0xA0]
000074fc119e17b7  vmovaps xmm11, [rsp+0xB0]
000074fc119e17c0  vmovaps xmm12, [rsp+0xC0]
000074fc119e17c9  vmovaps xmm14, [rsp+0xD0]
000074fc119e17d2  vmovaps xmm15, [rsp+0xE0]
000074fc119e17db  add rsp, 0xF0
000074fc119e17e2  pop r11
000074fc119e17e4  pop r10
000074fc119e17e6  pop r9
000074fc119e17e8  pop r8
000074fc119e17ea  pop rsi
000074fc119e17eb  pop rdi
000074fc119e17ec  pop rdx
000074fc119e17ed  pop rcx
000074fc119e17ee  pop rax
000074fc119e17ef  add rsp, 0x08
000074fc119e17f3  jmp 0x000074FC119DC820
000074fc119e17f8  sub rsp, 0x08
000074fc119e17fc  push rax
000074fc119e17fd  push rcx
000074fc119e17fe  push rdx
000074fc119e17ff  push rdi
000074fc119e1800  push rsi
000074fc119e1801  push r8
000074fc119e1803  push r9
000074fc119e1805  push r10
000074fc119e1807  push r11
000074fc119e1809  sub rsp, 0xF0
000074fc119e1810  vmovaps [rsp], xmm0
000074fc119e1815  vmovaps [rsp+0x10], xmm1
000074fc119e181b  vmovaps [rsp+0x20], xmm2
000074fc119e1821  vmovaps [rsp+0x30], xmm3
000074fc119e1827  vmovaps [rsp+0x40], xmm4
000074fc119e182d  vmovaps [rsp+0x50], xmm5
000074fc119e1833  vmovaps [rsp+0x60], xmm6
000074fc119e1839  vmovaps [rsp+0x70], xmm7
000074fc119e183f  vmovaps [rsp+0x80], xmm8
000074fc119e1848  vmovaps [rsp+0x90], xmm9
000074fc119e1851  vmovaps [rsp+0xA0], xmm10
000074fc119e185a  vmovaps [rsp+0xB0], xmm11
000074fc119e1863  vmovaps [rsp+0xC0], xmm12
000074fc119e186c  vmovaps [rsp+0xD0], xmm13
000074fc119e1875  vmovaps [rsp+0xE0], xmm15
000074fc119e187e  sub rsp, 0x30
000074fc119e1882  movaps [rsp], xmm14
000074fc119e1887  movaps [rsp+0x10], xmm1
000074fc119e188c  movaps [rsp+0x20], xmm7
000074fc119e1891  lea rdi, [rsp]
000074fc119e1895  mov esi, 0x00
000074fc119e189a  mov rax, 0x58C4C8091530
000074fc119e18a4  call rax
000074fc119e18a6  movaps xmm14, [rsp]
000074fc119e18ab  add rsp, 0x30
000074fc119e18af  vmovaps xmm0, [rsp]
000074fc119e18b4  vmovaps xmm1, [rsp+0x10]
000074fc119e18ba  vmovaps xmm2, [rsp+0x20]
000074fc119e18c0  vmovaps xmm3, [rsp+0x30]
000074fc119e18c6  vmovaps xmm4, [rsp+0x40]
000074fc119e18cc  vmovaps xmm5, [rsp+0x50]
000074fc119e18d2  vmovaps xmm6, [rsp+0x60]
000074fc119e18d8  vmovaps xmm7, [rsp+0x70]
000074fc119e18de  vmovaps xmm8, [rsp+0x80]
000074fc119e18e7  vmovaps xmm9, [rsp+0x90]
000074fc119e18f0  vmovaps xmm10, [rsp+0xA0]
000074fc119e18f9  vmovaps xmm11, [rsp+0xB0]
000074fc119e1902  vmovaps xmm12, [rsp+0xC0]
000074fc119e190b  vmovaps xmm13, [rsp+0xD0]
000074fc119e1914  vmovaps xmm15, [rsp+0xE0]
000074fc119e191d  add rsp, 0xF0
000074fc119e1924  pop r11
000074fc119e1926  pop r10
000074fc119e1928  pop r9
000074fc119e192a  pop r8
000074fc119e192c  pop rsi
000074fc119e192d  pop rdi
000074fc119e192e  pop rdx
000074fc119e192f  pop rcx
000074fc119e1930  pop rax
000074fc119e1931  add rsp, 0x08
000074fc119e1935  jmp 0x000074FC119DC843
000074fc119e193a  sub rsp, 0x08
000074fc119e193e  push rax
000074fc119e193f  push rcx
000074fc119e1940  push rdx
000074fc119e1941  push rdi
000074fc119e1942  push rsi
000074fc119e1943  push r8
000074fc119e1945  push r9
000074fc119e1947  push r10
000074fc119e1949  push r11
000074fc119e194b  sub rsp, 0xF0
000074fc119e1952  vmovaps [rsp], xmm0
000074fc119e1957  vmovaps [rsp+0x10], xmm2
000074fc119e195d  vmovaps [rsp+0x20], xmm3
000074fc119e1963  vmovaps [rsp+0x30], xmm4
000074fc119e1969  vmovaps [rsp+0x40], xmm5
000074fc119e196f  vmovaps [rsp+0x50], xmm6
000074fc119e1975  vmovaps [rsp+0x60], xmm7
000074fc119e197b  vmovaps [rsp+0x70], xmm8
000074fc119e1981  vmovaps [rsp+0x80], xmm9
000074fc119e198a  vmovaps [rsp+0x90], xmm10
000074fc119e1993  vmovaps [rsp+0xA0], xmm11
000074fc119e199c  vmovaps [rsp+0xB0], xmm12
000074fc119e19a5  vmovaps [rsp+0xC0], xmm13
000074fc119e19ae  vmovaps [rsp+0xD0], xmm14
000074fc119e19b7  vmovaps [rsp+0xE0], xmm15
000074fc119e19c0  sub rsp, 0x30
000074fc119e19c4  movaps [rsp], xmm1
000074fc119e19c8  movaps [rsp+0x10], xmm8
000074fc119e19ce  movaps [rsp+0x20], xmm9
000074fc119e19d4  lea rdi, [rsp]
000074fc119e19d8  mov esi, 0x00
000074fc119e19dd  mov rax, 0x58C4C8091530
000074fc119e19e7  call rax
000074fc119e19e9  movaps xmm1, [rsp]
000074fc119e19ed  add rsp, 0x30
000074fc119e19f1  vmovaps xmm0, [rsp]
000074fc119e19f6  vmovaps xmm2, [rsp+0x10]
000074fc119e19fc  vmovaps xmm3, [rsp+0x20]
000074fc119e1a02  vmovaps xmm4, [rsp+0x30]
000074fc119e1a08  vmovaps xmm5, [rsp+0x40]
000074fc119e1a0e  vmovaps xmm6, [rsp+0x50]
000074fc119e1a14  vmovaps xmm7, [rsp+0x60]
000074fc119e1a1a  vmovaps xmm8, [rsp+0x70]
000074fc119e1a20  vmovaps xmm9, [rsp+0x80]
000074fc119e1a29  vmovaps xmm10, [rsp+0x90]
000074fc119e1a32  vmovaps xmm11, [rsp+0xA0]
000074fc119e1a3b  vmovaps xmm12, [rsp+0xB0]
000074fc119e1a44  vmovaps xmm13, [rsp+0xC0]
000074fc119e1a4d  vmovaps xmm14, [rsp+0xD0]
000074fc119e1a56  vmovaps xmm15, [rsp+0xE0]
000074fc119e1a5f  add rsp, 0xF0
000074fc119e1a66  pop r11
000074fc119e1a68  pop r10
000074fc119e1a6a  pop r9
000074fc119e1a6c  pop r8
000074fc119e1a6e  pop rsi
000074fc119e1a6f  pop rdi
000074fc119e1a70  pop rdx
000074fc119e1a71  pop rcx
000074fc119e1a72  pop rax
000074fc119e1a73  add rsp, 0x08
000074fc119e1a77  jmp 0x000074FC119DC865
000074fc119e1a7c  call 0x000074FC118E5940
000074fc119e1a81  jmp 0x000074FC119DC873
000074fc119e1a86  call 0x000074FC1180C380
000074fc119e1a8b  jmp 0x000074FC119DC87D
000074fc119e1a90  call 0x000074FC1180D600
000074fc119e1a95  jmp 0x000074FC119DC887
000074fc119e1a9a  call 0x000074FC117FF540
000074fc119e1a9f  jmp 0x000074FC119DC891
000074fc119e1aa4  int3
000074fc119e1aa5  nop [rax+rax*1], ax
000074fc119e1aae  nop
000074fc119e1ab0  mov rax, [r15+0xF8]
000074fc119e1ab7  lea r14, [rax+0x140]
000074fc119e1abe  mov r12, [r13+r14*1]
000074fc119e1ac3  mov [r15+0xE8], r12
000074fc119e1aca  lea r14, [rax+0x130]
000074fc119e1ad1  mov r12, [r13+r14*1]
000074fc119e1ad6  lea r14, [rax+0x138]
000074fc119e1add  mov r11, [r13+r14*1]
000074fc119e1ae2  movq xmm1, r12
000074fc119e1ae7  movq xmm15, r11
000074fc119e1aec  movq xmm1, xmm1
000074fc119e1af0  movq xmm1, xmm1
000074fc119e1af4  movaps [r15+0x1A0], xmm1
000074fc119e1afc  movq xmm15, xmm15
000074fc119e1b01  movq xmm15, xmm15
000074fc119e1b06  movaps [r15+0x190], xmm15
000074fc119e1b0e  lea r14, [rax+0x120]
000074fc119e1b15  mov r12, [r13+r14*1]
000074fc119e1b1a  lea r14, [rax+0x128]
000074fc119e1b21  mov r11, [r13+r14*1]
000074fc119e1b26  movq xmm1, r12
000074fc119e1b2b  movq xmm15, r11
000074fc119e1b30  movq xmm1, xmm1
000074fc119e1b34  movq xmm1, xmm1
000074fc119e1b38  movaps [r15+0x1C0], xmm1
000074fc119e1b40  movq xmm15, xmm15
000074fc119e1b45  movq xmm15, xmm15
000074fc119e1b4a  movaps [r15+0x1B0], xmm15
000074fc119e1b52  lea r14, [rax+0x110]
000074fc119e1b59  mov r12, [r13+r14*1]
000074fc119e1b5e  lea r14, [rax+0x118]
000074fc119e1b65  mov r11, [r13+r14*1]
000074fc119e1b6a  movq xmm1, r12
000074fc119e1b6f  movq xmm15, r11
000074fc119e1b74  movq xmm1, xmm1
000074fc119e1b78  movq xmm1, xmm1
000074fc119e1b7c  movaps [r15+0x1E0], xmm1
000074fc119e1b84  movq xmm15, xmm15
000074fc119e1b89  movq xmm15, xmm15
000074fc119e1b8e  movaps [r15+0x1D0], xmm15
000074fc119e1b96  lea r14, [rax+0x100]
000074fc119e1b9d  mov r12, [r13+r14*1]
000074fc119e1ba2  lea r14, [rax+0x108]
000074fc119e1ba9  mov r11, [r13+r14*1]
000074fc119e1bae  movq xmm1, r12
000074fc119e1bb3  movq xmm15, r11
000074fc119e1bb8  movq xmm1, xmm1
000074fc119e1bbc  movq xmm1, xmm1
000074fc119e1bc0  movaps [r15+0x200], xmm1
000074fc119e1bc8  movq xmm15, xmm15
000074fc119e1bcd  movq xmm15, xmm15
000074fc119e1bd2  movaps [r15+0x1F0], xmm15
000074fc119e1bda  mov qword ptr [r15+0x40], 0x430000
000074fc119e1be2  mov r14d, 0x430510
000074fc119e1be8  mov r12, [r13+r14*1]
000074fc119e1bed  movq xmm1, r12
000074fc119e1bf2  lea r14, [rax+0x150]
000074fc119e1bf9  mov [r15+0xF8], r14
000074fc119e1c00  mov rax, [r15+0x50]
000074fc119e1c04  movups xmm15, [r13+rax*1]
000074fc119e1c0a  movaps [r15+0x120], xmm15
000074fc119e1c12  mov qword ptr [r15+0x48], 0x10
000074fc119e1c1a  xor eax, eax
000074fc119e1c1c  mov r14d, 0x10
000074fc119e1c22  mov r12d, 0x200
000074fc119e1c28  cmp r14, r12
000074fc119e1c2b  cmc
000074fc119e1c2c  lahf
000074fc119e1c2d  seto al
000074fc119e1c30  mov [r15+0x108], eax
000074fc119e1c37  pextrq rax, xmm15, 0x01
000074fc119e1c3e  movq xmm14, rax
000074fc119e1c43  movaps [r15+0x130], xmm14
000074fc119e1c4b  movq rax, xmm1
000074fc119e1c50  movq r14, xmm15
000074fc119e1c55  vmovq xmm1, rax
000074fc119e1c5a  vmovq xmm15, r14
000074fc119e1c5f  movaps xmm13, xmm1
000074fc119e1c63  addsd xmm13, xmm15
000074fc119e1c68  ucomisd xmm13, xmm13
000074fc119e1c6d  jp 0x000074FC119E1D86
000074fc119e1c73  movq xmm13, xmm13
000074fc119e1c78  movq rax, xmm13
000074fc119e1c7d  movq r14, xmm14
000074fc119e1c82  vmovq xmm1, rax
000074fc119e1c87  vmovq xmm15, r14
000074fc119e1c8c  movaps xmm14, xmm1
000074fc119e1c90  addsd xmm14, xmm15
000074fc119e1c95  ucomisd xmm14, xmm14
000074fc119e1c9a  jp 0x000074FC119E1DCE
000074fc119e1ca0  movq xmm14, xmm14
000074fc119e1ca5  movaps [r15+0x110], xmm14
000074fc119e1cad  mov eax, [r15+0x108]
000074fc119e1cb4  sahf
000074fc119e1cb5  jnz 0x000074FC119E1CE7
000074fc119e1cb7  cmp dword ptr [r15+0x318], 0x00
000074fc119e1cbf  jz 0x000074FC119E1FE0
000074fc119e1cc5  nop [rax+rax*1], ax
000074fc119e1cce  nop [rax+rax*1], eax
000074fc119e1cd6  mov eax, 0x410490
000074fc119e1cdb  mov [r15+0x100], rax
000074fc119e1ce2  jmp 0x000074FC117FE110
000074fc119e1ce7  cmp dword ptr [r15+0x318], 0x00
000074fc119e1cef  jz 0x000074FC119E1E20
000074fc119e1cf5  nop [rax+rax*1], ax
000074fc119e1cfe  nop [rax+rax*1], eax
000074fc119e1d06  mov eax, 0x410474
000074fc119e1d0b  mov [r15+0x100], rax
000074fc119e1d12  jmp 0x000074FC117FE110
000074fc119e1d17  int3
000074fc119e1d18  call 0x000074FC118E27E0
000074fc119e1d1d  jmp 0x000074FC119E1AC3
000074fc119e1d22  call 0x000074FC118E27E0
000074fc119e1d27  jmp 0x000074FC119E1AD6
000074fc119e1d2c  call 0x000074FC118E1570
000074fc119e1d31  jmp 0x000074FC119E1AE2
000074fc119e1d36  call 0x000074FC118E27E0
000074fc119e1d3b  jmp 0x000074FC119E1B1A
000074fc119e1d40  call 0x000074FC118E1570
000074fc119e1d45  jmp 0x000074FC119E1B26
000074fc119e1d4a  call 0x000074FC118E27E0
000074fc119e1d4f  jmp 0x000074FC119E1B5E
000074fc119e1d54  call 0x000074FC118E1570
000074fc119e1d59  jmp 0x000074FC119E1B6A
000074fc119e1d5e  call 0x000074FC118E27E0
000074fc119e1d63  jmp 0x000074FC119E1BA2
000074fc119e1d68  call 0x000074FC118E1570
000074fc119e1d6d  jmp 0x000074FC119E1BAE
000074fc119e1d72  call 0x000074FC118E27E0
000074fc119e1d77  jmp 0x000074FC119E1BED
000074fc119e1d7c  call 0x000074FC1180E760
000074fc119e1d81  jmp 0x000074FC119E1C0A
000074fc119e1d86  ucomisd xmm1, xmm15
000074fc119e1d8b  jp 0x000074FC119E1D9A
000074fc119e1d8d  movaps xmm13, [0x000074FC115FE060]
000074fc119e1d95  jmp 0x000074FC119E1C73
000074fc119e1d9a  vxorps xmm0, xmm1, xmm15
000074fc119e1d9f  pextrw eax, xmm0, 0x03
000074fc119e1da4  and eax, 0x7FF8
000074fc119e1da9  cmp eax, 0x08
000074fc119e1dac  jnz 0x000074FC119E1C73
000074fc119e1db2  movq rax, xmm15
000074fc119e1db7  shl rax, 0x0D
000074fc119e1dbb  jbe 0x000074FC119E1C73
000074fc119e1dc1  vorps xmm13, xmm15, [0x000074FC115FE070]
000074fc119e1dc9  jmp 0x000074FC119E1C73
000074fc119e1dce  ucomisd xmm1, xmm15
000074fc119e1dd3  jp 0x000074FC119E1DE2
000074fc119e1dd5  movaps xmm14, [0x000074FC115FE060]
000074fc119e1ddd  jmp 0x000074FC119E1CA0
000074fc119e1de2  vxorps xmm0, xmm1, xmm15
000074fc119e1de7  pextrw eax, xmm0, 0x03
000074fc119e1dec  and eax, 0x7FF8
000074fc119e1df1  cmp eax, 0x08
000074fc119e1df4  jnz 0x000074FC119E1CA0
000074fc119e1dfa  movq rax, xmm15
000074fc119e1dff  shl rax, 0x0D
000074fc119e1e03  jbe 0x000074FC119E1CA0
000074fc119e1e09  vorps xmm14, xmm15, [0x000074FC115FE070]
000074fc119e1e11  jmp 0x000074FC119E1CA0
000074fc119e1e16  int3
000074fc119e1e17  nop [rax+rax*1], ax
000074fc119e1e20  mov rax, [r15+0x48]
000074fc119e1e24  mov r14, [r15+0x50]
000074fc119e1e28  lea r12, [r14+rax*1]
000074fc119e1e2c  movups xmm1, [r13+r12*1]
000074fc119e1e32  movaps [r15+0x120], xmm1
000074fc119e1e3a  lea r14, [rax+0x10]
000074fc119e1e3e  mov [r15+0x48], r14
000074fc119e1e42  xor eax, eax
000074fc119e1e44  mov r12d, 0x200
000074fc119e1e4a  cmp r14, r12
000074fc119e1e4d  cmc
000074fc119e1e4e  lahf
000074fc119e1e4f  seto al
000074fc119e1e52  mov [r15+0x108], eax
000074fc119e1e59  pextrq rax, xmm1, 0x01
000074fc119e1e60  movq xmm15, rax
000074fc119e1e65  movaps [r15+0x130], xmm15
000074fc119e1e6d  movaps xmm14, [r15+0x110]
000074fc119e1e75  movq rax, xmm14
000074fc119e1e7a  movq r14, xmm1
000074fc119e1e7f  vmovq xmm1, rax
000074fc119e1e84  vmovq xmm14, r14
000074fc119e1e89  movaps xmm13, xmm1
000074fc119e1e8d  addsd xmm13, xmm14
000074fc119e1e92  ucomisd xmm13, xmm13
000074fc119e1e97  jp 0x000074FC119E1F4C
000074fc119e1e9d  movq xmm13, xmm13
000074fc119e1ea2  movq rax, xmm13
000074fc119e1ea7  movq r14, xmm15
000074fc119e1eac  vmovq xmm1, rax
000074fc119e1eb1  vmovq xmm15, r14
000074fc119e1eb6  movaps xmm14, xmm1
000074fc119e1eba  addsd xmm14, xmm15
000074fc119e1ebf  ucomisd xmm14, xmm14
000074fc119e1ec4  jp 0x000074FC119E1F94
000074fc119e1eca  movq xmm14, xmm14
000074fc119e1ecf  movaps [r15+0x110], xmm14
000074fc119e1ed7  mov eax, [r15+0x108]
000074fc119e1ede  sahf
000074fc119e1edf  jnz 0x000074FC119E1F11
000074fc119e1ee1  cmp dword ptr [r15+0x318], 0x00
000074fc119e1ee9  jz 0x000074FC119E1FE0
000074fc119e1eef  nop [rax+rax*1], ax
000074fc119e1ef8  nop [rax+rax*1], eax
000074fc119e1f00  mov eax, 0x410490
000074fc119e1f05  mov [r15+0x100], rax
000074fc119e1f0c  jmp 0x000074FC117FE110
000074fc119e1f11  cmp dword ptr [r15+0x318], 0x00
000074fc119e1f19  jz 0x000074FC119E1E20
000074fc119e1f1f  nop [rax+rax*1], ax
000074fc119e1f28  nop [rax+rax*1], eax
000074fc119e1f30  mov eax, 0x410474
000074fc119e1f35  mov [r15+0x100], rax
000074fc119e1f3c  jmp 0x000074FC117FE110
000074fc119e1f41  int3
000074fc119e1f42  call 0x000074FC118B52F0
000074fc119e1f47  jmp 0x000074FC119E1E32
000074fc119e1f4c  ucomisd xmm1, xmm14
000074fc119e1f51  jp 0x000074FC119E1F60
000074fc119e1f53  movaps xmm13, [0x000074FC115FE060]
000074fc119e1f5b  jmp 0x000074FC119E1E9D
000074fc119e1f60  vxorps xmm0, xmm1, xmm14
000074fc119e1f65  pextrw eax, xmm0, 0x03
000074fc119e1f6a  and eax, 0x7FF8
000074fc119e1f6f  cmp eax, 0x08
000074fc119e1f72  jnz 0x000074FC119E1E9D
000074fc119e1f78  movq rax, xmm14
000074fc119e1f7d  shl rax, 0x0D
000074fc119e1f81  jbe 0x000074FC119E1E9D
000074fc119e1f87  vorps xmm13, xmm14, [0x000074FC115FE070]
000074fc119e1f8f  jmp 0x000074FC119E1E9D
000074fc119e1f94  ucomisd xmm1, xmm15
000074fc119e1f99  jp 0x000074FC119E1FA8
000074fc119e1f9b  movaps xmm14, [0x000074FC115FE060]
000074fc119e1fa3  jmp 0x000074FC119E1ECA
000074fc119e1fa8  vxorps xmm0, xmm1, xmm15
000074fc119e1fad  pextrw eax, xmm0, 0x03
000074fc119e1fb2  and eax, 0x7FF8
000074fc119e1fb7  cmp eax, 0x08
000074fc119e1fba  jnz 0x000074FC119E1ECA
000074fc119e1fc0  movq rax, xmm15
000074fc119e1fc5  shl rax, 0x0D
000074fc119e1fc9  jbe 0x000074FC119E1ECA
000074fc119e1fcf  vorps xmm14, xmm15, [0x000074FC115FE070]
000074fc119e1fd7  jmp 0x000074FC119E1ECA
000074fc119e1fdc  int3
000074fc119e1fdd  nop [rax], eax
000074fc119e1fe0  mov rax, [r15+0x40]
000074fc119e1fe4  lea r14, [rax+0x510]
000074fc119e1feb  movaps xmm1, [r15+0x110]
000074fc119e1ff3  movq rax, xmm1
000074fc119e1ff8  mov [r13+r14*1], rax
000074fc119e1ffd  mov rax, [r15+0xF0]
000074fc119e2004  mov [r15+0x100], rax
000074fc119e200b  jmp 0x000074FC119CE5C0
000074fc119e2010  int3
000074fc119e2011  call 0x000074FC118D5EB0
000074fc119e2016  jmp 0x000074FC119E1FFD
000074fc119e201b  int3
000074fc119e201c  nop [rax], eax
000074fc119e2020  mov qword ptr [r15+0x100], 0x04
000074fc119e202b  mov esi, 0x00
000074fc119e2030  mov edx, 0x09
000074fc119e2035  mov rdi, 0x7FFC8D62D8B0
000074fc119e203f  mov rax, 0x58C4C7F24970
000074fc119e2049  call rax
000074fc119e204b  cmp dword ptr [r15+0x318], 0x00
000074fc119e2053  jnz 0x000074FC117FE110
000074fc119e2059  jmp 0x000074FC117FE0A0
000074fc119e205e  int3
000074fc119e205f  int3
