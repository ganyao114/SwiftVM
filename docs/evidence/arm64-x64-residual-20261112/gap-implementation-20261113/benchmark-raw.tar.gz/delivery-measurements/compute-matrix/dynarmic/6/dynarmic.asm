00007d3d957ce69b  nop [rax+rax*1], eax
00007d3d957ce6a0  vmovaps xmm1, [0x00007D3D953FE010]
00007d3d957ce6a8  movq xmm1, xmm1
00007d3d957ce6ac  movaps [r15+0x110], xmm1
00007d3d957ce6b4  vmovaps xmm1, [0x00007D3D953FE020]
00007d3d957ce6bc  movq xmm1, xmm1
00007d3d957ce6c0  movaps [r15+0x120], xmm1
00007d3d957ce6c8  mov eax, 0x4204C0
00007d3d957ce6cd  mov r14, [r13+rax*1]
00007d3d957ce6d2  movq xmm1, r14
00007d3d957ce6d7  movaps [r15+0x130], xmm1
00007d3d957ce6df  vmovaps xmm1, [0x00007D3D953FE030]
00007d3d957ce6e7  vpbroadcastq xmm1, xmm1
00007d3d957ce6ec  movaps [r15+0x140], xmm1
00007d3d957ce6f4  mov qword ptr [r15+0x40], 0x02
00007d3d957ce6fc  vmovaps xmm15, [0x00007D3D953FE040]
00007d3d957ce704  movq xmm15, xmm15
00007d3d957ce709  movaps [r15+0x150], xmm15
00007d3d957ce711  mov qword ptr [r15+0x58], 0x420000
00007d3d957ce719  vmovaps xmm15, [0x00007D3D953FE050]
00007d3d957ce721  vpbroadcastq xmm15, xmm15
00007d3d957ce726  movaps [r15+0x160], xmm15
00007d3d957ce72e  mov rax, [r15+0x40]
00007d3d957ce732  vmovq xmm14, rax
00007d3d957ce737  vpbroadcastq xmm14, xmm14
00007d3d957ce73c  movaps [r15+0x170], xmm14
00007d3d957ce744  mov eax, 0x4204D0
00007d3d957ce749  movups xmm13, [r13+rax*1]
00007d3d957ce74f  mov qword ptr [r15+0x40], 0x430518
00007d3d957ce757  mov qword ptr [r15+0x50], 0x430720
00007d3d957ce75f  vpmovqd xmm12, xmm13
00007d3d957ce765  pxor xmm11, xmm11
00007d3d957ce76a  punpcklqdq xmm12, xmm11
00007d3d957ce76f  movaps [r15+0x210], xmm12
00007d3d957ce777  movq xmm12, qword ptr [r15+0x120]
00007d3d957ce780  movq xmm11, qword ptr [r15+0x130]
00007d3d957ce789  psubd xmm12, xmm11
00007d3d957ce78e  movq xmm12, xmm12
00007d3d957ce793  paddq xmm13, xmm14
00007d3d957ce798  movaps [r15+0x180], xmm13
00007d3d957ce7a0  movq xmm14, qword ptr [r15+0x150]
00007d3d957ce7a9  paddd xmm11, xmm14
00007d3d957ce7ae  movq xmm11, xmm11
00007d3d957ce7b3  movq xmm11, xmm11
00007d3d957ce7b8  movaps [r15+0x130], xmm11
00007d3d957ce7c0  pmovzxdq xmm12, xmm12
00007d3d957ce7c6  psllq xmm12, 0x00
00007d3d957ce7cc  movq xmm14, qword ptr [r15+0x210]
00007d3d957ce7d5  movq xmm13, qword ptr [r15+0x110]
00007d3d957ce7de  paddd xmm14, xmm13
00007d3d957ce7e3  movq xmm14, xmm14
00007d3d957ce7e8  vcvtuqq2pd xmm12, xmm12
00007d3d957ce7ee  pmovzxdq xmm14, xmm14
00007d3d957ce7f4  psllq xmm14, 0x00
00007d3d957ce7fa  vcvtuqq2pd xmm14, xmm14
00007d3d957ce800  movaps xmm13, xmm12
00007d3d957ce804  mulpd xmm13, xmm1
00007d3d957ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007d3d957ce80f  ptest xmm11, xmm11
00007d3d957ce815  jnz 0x00007D3D957CE8FF
00007d3d957ce81b  movaps [r15+0x220], xmm13
00007d3d957ce823  mov eax, 0x430720
00007d3d957ce828  movups [r13+rax*1], xmm13
00007d3d957ce82e  movaps xmm1, xmm14
00007d3d957ce832  mulpd xmm1, xmm15
00007d3d957ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007d3d957ce83c  ptest xmm13, xmm13
00007d3d957ce842  jnz 0x00007D3D957CEA4C
00007d3d957ce848  movaps [r15+0x210], xmm1
00007d3d957ce850  mov eax, 0x430518
00007d3d957ce855  movups [r13+rax*1], xmm1
00007d3d957ce85b  mov qword ptr [r15+0x48], 0x10
00007d3d957ce863  xor eax, eax
00007d3d957ce865  mov r14d, 0x10
00007d3d957ce86b  mov r12d, 0x200
00007d3d957ce871  cmp r14, r12
00007d3d957ce874  cmc
00007d3d957ce875  lahf
00007d3d957ce876  seto al
00007d3d957ce879  mov [r15+0x108], eax
00007d3d957ce880  mov eax, [r15+0x108]
00007d3d957ce887  sahf
00007d3d957ce888  jnz 0x00007D3D957CE8BA
00007d3d957ce88a  cmp dword ptr [r15+0x318], 0x00
00007d3d957ce892  jz 0x00007D3D957CEFF0
00007d3d957ce898  nop [rax+rax*1], ax
00007d3d957ce8a1  nop [rax+rax*1], eax
00007d3d957ce8a9  mov eax, 0x4101EC
00007d3d957ce8ae  mov [r15+0x100], rax
00007d3d957ce8b5  jmp 0x00007D3D955FE110
00007d3d957ce8ba  cmp dword ptr [r15+0x318], 0x00
00007d3d957ce8c2  jz 0x00007D3D957CEBA0
00007d3d957ce8c8  nop [rax+rax*1], ax
00007d3d957ce8d1  nop [rax+rax*1], eax
00007d3d957ce8d9  mov eax, 0x4101AC
00007d3d957ce8de  mov [r15+0x100], rax
00007d3d957ce8e5  jmp 0x00007D3D955FE110
00007d3d957ce8ea  int3
00007d3d957ce8eb  call 0x00007D3D9560DC20
00007d3d957ce8f0  jmp 0x00007D3D957CE6D2
00007d3d957ce8f5  call 0x00007D3D9560C260
00007d3d957ce8fa  jmp 0x00007D3D957CE74F
00007d3d957ce8ff  sub rsp, 0x08
00007d3d957ce903  push rax
00007d3d957ce904  push rcx
00007d3d957ce905  push rdx
00007d3d957ce906  push rdi
00007d3d957ce907  push rsi
00007d3d957ce908  push r8
00007d3d957ce90a  push r9
00007d3d957ce90c  push r10
00007d3d957ce90e  push r11
00007d3d957ce910  sub rsp, 0xF0
00007d3d957ce917  vmovaps [rsp], xmm0
00007d3d957ce91c  vmovaps [rsp+0x10], xmm1
00007d3d957ce922  vmovaps [rsp+0x20], xmm2
00007d3d957ce928  vmovaps [rsp+0x30], xmm3
00007d3d957ce92e  vmovaps [rsp+0x40], xmm4
00007d3d957ce934  vmovaps [rsp+0x50], xmm5
00007d3d957ce93a  vmovaps [rsp+0x60], xmm6
00007d3d957ce940  vmovaps [rsp+0x70], xmm7
00007d3d957ce946  vmovaps [rsp+0x80], xmm8
00007d3d957ce94f  vmovaps [rsp+0x90], xmm9
00007d3d957ce958  vmovaps [rsp+0xA0], xmm10
00007d3d957ce961  vmovaps [rsp+0xB0], xmm11
00007d3d957ce96a  vmovaps [rsp+0xC0], xmm12
00007d3d957ce973  vmovaps [rsp+0xD0], xmm14
00007d3d957ce97c  vmovaps [rsp+0xE0], xmm15
00007d3d957ce985  sub rsp, 0x30
00007d3d957ce989  movaps [rsp], xmm13
00007d3d957ce98e  movaps [rsp+0x10], xmm12
00007d3d957ce994  movaps [rsp+0x20], xmm1
00007d3d957ce999  lea rdi, [rsp]
00007d3d957ce99d  mov esi, 0x00
00007d3d957ce9a2  mov rax, 0x56C27CB8A530
00007d3d957ce9ac  call rax
00007d3d957ce9ae  movaps xmm13, [rsp]
00007d3d957ce9b3  add rsp, 0x30
00007d3d957ce9b7  vmovaps xmm0, [rsp]
00007d3d957ce9bc  vmovaps xmm1, [rsp+0x10]
00007d3d957ce9c2  vmovaps xmm2, [rsp+0x20]
00007d3d957ce9c8  vmovaps xmm3, [rsp+0x30]
00007d3d957ce9ce  vmovaps xmm4, [rsp+0x40]
00007d3d957ce9d4  vmovaps xmm5, [rsp+0x50]
00007d3d957ce9da  vmovaps xmm6, [rsp+0x60]
00007d3d957ce9e0  vmovaps xmm7, [rsp+0x70]
00007d3d957ce9e6  vmovaps xmm8, [rsp+0x80]
00007d3d957ce9ef  vmovaps xmm9, [rsp+0x90]
00007d3d957ce9f8  vmovaps xmm10, [rsp+0xA0]
00007d3d957cea01  vmovaps xmm11, [rsp+0xB0]
00007d3d957cea0a  vmovaps xmm12, [rsp+0xC0]
00007d3d957cea13  vmovaps xmm14, [rsp+0xD0]
00007d3d957cea1c  vmovaps xmm15, [rsp+0xE0]
00007d3d957cea25  add rsp, 0xF0
00007d3d957cea2c  pop r11
00007d3d957cea2e  pop r10
00007d3d957cea30  pop r9
00007d3d957cea32  pop r8
00007d3d957cea34  pop rsi
00007d3d957cea35  pop rdi
00007d3d957cea36  pop rdx
00007d3d957cea37  pop rcx
00007d3d957cea38  pop rax
00007d3d957cea39  add rsp, 0x08
00007d3d957cea3d  jmp 0x00007D3D957CE81B
00007d3d957cea42  call 0x00007D3D9560C380
00007d3d957cea47  jmp 0x00007D3D957CE82E
00007d3d957cea4c  sub rsp, 0x08
00007d3d957cea50  push rax
00007d3d957cea51  push rcx
00007d3d957cea52  push rdx
00007d3d957cea53  push rdi
00007d3d957cea54  push rsi
00007d3d957cea55  push r8
00007d3d957cea57  push r9
00007d3d957cea59  push r10
00007d3d957cea5b  push r11
00007d3d957cea5d  sub rsp, 0xF0
00007d3d957cea64  vmovaps [rsp], xmm0
00007d3d957cea69  vmovaps [rsp+0x10], xmm2
00007d3d957cea6f  vmovaps [rsp+0x20], xmm3
00007d3d957cea75  vmovaps [rsp+0x30], xmm4
00007d3d957cea7b  vmovaps [rsp+0x40], xmm5
00007d3d957cea81  vmovaps [rsp+0x50], xmm6
00007d3d957cea87  vmovaps [rsp+0x60], xmm7
00007d3d957cea8d  vmovaps [rsp+0x70], xmm8
00007d3d957cea93  vmovaps [rsp+0x80], xmm9
00007d3d957cea9c  vmovaps [rsp+0x90], xmm10
00007d3d957ceaa5  vmovaps [rsp+0xA0], xmm11
00007d3d957ceaae  vmovaps [rsp+0xB0], xmm12
00007d3d957ceab7  vmovaps [rsp+0xC0], xmm13
00007d3d957ceac0  vmovaps [rsp+0xD0], xmm14
00007d3d957ceac9  vmovaps [rsp+0xE0], xmm15
00007d3d957cead2  sub rsp, 0x30
00007d3d957cead6  movaps [rsp], xmm1
00007d3d957ceada  movaps [rsp+0x10], xmm14
00007d3d957ceae0  movaps [rsp+0x20], xmm15
00007d3d957ceae6  lea rdi, [rsp]
00007d3d957ceaea  mov esi, 0x00
00007d3d957ceaef  mov rax, 0x56C27CB8A530
00007d3d957ceaf9  call rax
00007d3d957ceafb  movaps xmm1, [rsp]
00007d3d957ceaff  add rsp, 0x30
00007d3d957ceb03  vmovaps xmm0, [rsp]
00007d3d957ceb08  vmovaps xmm2, [rsp+0x10]
00007d3d957ceb0e  vmovaps xmm3, [rsp+0x20]
00007d3d957ceb14  vmovaps xmm4, [rsp+0x30]
00007d3d957ceb1a  vmovaps xmm5, [rsp+0x40]
00007d3d957ceb20  vmovaps xmm6, [rsp+0x50]
00007d3d957ceb26  vmovaps xmm7, [rsp+0x60]
00007d3d957ceb2c  vmovaps xmm8, [rsp+0x70]
00007d3d957ceb32  vmovaps xmm9, [rsp+0x80]
00007d3d957ceb3b  vmovaps xmm10, [rsp+0x90]
00007d3d957ceb44  vmovaps xmm11, [rsp+0xA0]
00007d3d957ceb4d  vmovaps xmm12, [rsp+0xB0]
00007d3d957ceb56  vmovaps xmm13, [rsp+0xC0]
00007d3d957ceb5f  vmovaps xmm14, [rsp+0xD0]
00007d3d957ceb68  vmovaps xmm15, [rsp+0xE0]
00007d3d957ceb71  add rsp, 0xF0
00007d3d957ceb78  pop r11
00007d3d957ceb7a  pop r10
00007d3d957ceb7c  pop r9
00007d3d957ceb7e  pop r8
00007d3d957ceb80  pop rsi
00007d3d957ceb81  pop rdi
00007d3d957ceb82  pop rdx
00007d3d957ceb83  pop rcx
00007d3d957ceb84  pop rax
00007d3d957ceb85  add rsp, 0x08
00007d3d957ceb89  jmp 0x00007D3D957CE848
00007d3d957ceb8e  call 0x00007D3D955FF540
00007d3d957ceb93  jmp 0x00007D3D957CE85B
00007d3d957ceb98  int3
00007d3d957ceb99  nop [rax], eax
00007d3d957ceba0  movaps xmm1, [r15+0x180]
00007d3d957ceba8  vpmovqd xmm15, xmm1
00007d3d957cebae  pxor xmm14, xmm14
00007d3d957cebb3  punpcklqdq xmm15, xmm14
00007d3d957cebb8  movaps [r15+0x210], xmm15
00007d3d957cebc0  movq xmm15, qword ptr [r15+0x120]
00007d3d957cebc9  movq xmm14, qword ptr [r15+0x130]
00007d3d957cebd2  psubd xmm15, xmm14
00007d3d957cebd7  movq xmm15, xmm15
00007d3d957cebdc  movaps xmm13, [r15+0x170]
00007d3d957cebe4  paddq xmm1, xmm13
00007d3d957cebe9  movaps [r15+0x180], xmm1
00007d3d957cebf1  movq xmm1, qword ptr [r15+0x150]
00007d3d957cebfa  paddd xmm14, xmm1
00007d3d957cebff  movq xmm14, xmm14
00007d3d957cec04  movq xmm14, xmm14
00007d3d957cec09  movaps [r15+0x130], xmm14
00007d3d957cec11  pmovzxdq xmm15, xmm15
00007d3d957cec17  psllq xmm15, 0x00
00007d3d957cec1d  movq xmm1, qword ptr [r15+0x210]
00007d3d957cec26  movq xmm14, qword ptr [r15+0x110]
00007d3d957cec2f  paddd xmm1, xmm14
00007d3d957cec34  movq xmm1, xmm1
00007d3d957cec38  vcvtuqq2pd xmm15, xmm15
00007d3d957cec3e  pmovzxdq xmm1, xmm1
00007d3d957cec43  psllq xmm1, 0x00
00007d3d957cec48  vcvtuqq2pd xmm1, xmm1
00007d3d957cec4e  movaps xmm14, [r15+0x140]
00007d3d957cec56  movaps xmm13, xmm15
00007d3d957cec5a  mulpd xmm13, xmm14
00007d3d957cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007d3d957cec65  ptest xmm12, xmm12
00007d3d957cec6b  jnz 0x00007D3D957CED4E
00007d3d957cec71  movaps [r15+0x220], xmm13
00007d3d957cec79  mov rax, [r15+0x48]
00007d3d957cec7d  mov r14, [r15+0x50]
00007d3d957cec81  lea r12, [r14+rax*1]
00007d3d957cec85  movups [r13+r12*1], xmm13
00007d3d957cec8b  movaps xmm15, [r15+0x160]
00007d3d957cec93  movaps xmm14, xmm1
00007d3d957cec97  mulpd xmm14, xmm15
00007d3d957cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007d3d957ceca2  ptest xmm13, xmm13
00007d3d957ceca8  jnz 0x00007D3D957CEE9C
00007d3d957cecae  movaps [r15+0x210], xmm14
00007d3d957cecb6  mov r14, [r15+0x40]
00007d3d957cecba  lea r12, [r14+rax*1]
00007d3d957cecbe  movups [r13+r12*1], xmm14
00007d3d957cecc4  lea r14, [rax+0x10]
00007d3d957cecc8  mov [r15+0x48], r14
00007d3d957ceccc  xor eax, eax
00007d3d957cecce  mov r12d, 0x200
00007d3d957cecd4  cmp r14, r12
00007d3d957cecd7  cmc
00007d3d957cecd8  lahf
00007d3d957cecd9  seto al
00007d3d957cecdc  mov [r15+0x108], eax
00007d3d957cece3  mov eax, [r15+0x108]
00007d3d957cecea  sahf
00007d3d957ceceb  jnz 0x00007D3D957CED1D
00007d3d957ceced  cmp dword ptr [r15+0x318], 0x00
00007d3d957cecf5  jz 0x00007D3D957CEFF0
00007d3d957cecfb  nop [rax+rax*1], ax
00007d3d957ced04  nop [rax+rax*1], eax
00007d3d957ced0c  mov eax, 0x4101EC
00007d3d957ced11  mov [r15+0x100], rax
00007d3d957ced18  jmp 0x00007D3D955FE110
00007d3d957ced1d  cmp dword ptr [r15+0x318], 0x00
00007d3d957ced25  jz 0x00007D3D957CEBA0
00007d3d957ced2b  nop [rax+rax*1], ax
00007d3d957ced34  nop [rax+rax*1], eax
00007d3d957ced3c  mov eax, 0x4101AC
00007d3d957ced41  mov [r15+0x100], rax
00007d3d957ced48  jmp 0x00007D3D955FE110
00007d3d957ced4d  int3
00007d3d957ced4e  sub rsp, 0x08
00007d3d957ced52  push rax
00007d3d957ced53  push rcx
00007d3d957ced54  push rdx
00007d3d957ced55  push rdi
00007d3d957ced56  push rsi
00007d3d957ced57  push r8
00007d3d957ced59  push r9
00007d3d957ced5b  push r10
00007d3d957ced5d  push r11
00007d3d957ced5f  sub rsp, 0xF0
00007d3d957ced66  vmovaps [rsp], xmm0
00007d3d957ced6b  vmovaps [rsp+0x10], xmm1
00007d3d957ced71  vmovaps [rsp+0x20], xmm2
00007d3d957ced77  vmovaps [rsp+0x30], xmm3
00007d3d957ced7d  vmovaps [rsp+0x40], xmm4
00007d3d957ced83  vmovaps [rsp+0x50], xmm5
00007d3d957ced89  vmovaps [rsp+0x60], xmm6
00007d3d957ced8f  vmovaps [rsp+0x70], xmm7
00007d3d957ced95  vmovaps [rsp+0x80], xmm8
00007d3d957ced9e  vmovaps [rsp+0x90], xmm9
00007d3d957ceda7  vmovaps [rsp+0xA0], xmm10
00007d3d957cedb0  vmovaps [rsp+0xB0], xmm11
00007d3d957cedb9  vmovaps [rsp+0xC0], xmm12
00007d3d957cedc2  vmovaps [rsp+0xD0], xmm14
00007d3d957cedcb  vmovaps [rsp+0xE0], xmm15
00007d3d957cedd4  sub rsp, 0x30
00007d3d957cedd8  movaps [rsp], xmm13
00007d3d957ceddd  movaps [rsp+0x10], xmm15
00007d3d957cede3  movaps [rsp+0x20], xmm14
00007d3d957cede9  lea rdi, [rsp]
00007d3d957ceded  mov esi, 0x00
00007d3d957cedf2  mov rax, 0x56C27CB8A530
00007d3d957cedfc  call rax
00007d3d957cedfe  movaps xmm13, [rsp]
00007d3d957cee03  add rsp, 0x30
00007d3d957cee07  vmovaps xmm0, [rsp]
00007d3d957cee0c  vmovaps xmm1, [rsp+0x10]
00007d3d957cee12  vmovaps xmm2, [rsp+0x20]
00007d3d957cee18  vmovaps xmm3, [rsp+0x30]
00007d3d957cee1e  vmovaps xmm4, [rsp+0x40]
00007d3d957cee24  vmovaps xmm5, [rsp+0x50]
00007d3d957cee2a  vmovaps xmm6, [rsp+0x60]
00007d3d957cee30  vmovaps xmm7, [rsp+0x70]
00007d3d957cee36  vmovaps xmm8, [rsp+0x80]
00007d3d957cee3f  vmovaps xmm9, [rsp+0x90]
00007d3d957cee48  vmovaps xmm10, [rsp+0xA0]
00007d3d957cee51  vmovaps xmm11, [rsp+0xB0]
00007d3d957cee5a  vmovaps xmm12, [rsp+0xC0]
00007d3d957cee63  vmovaps xmm14, [rsp+0xD0]
00007d3d957cee6c  vmovaps xmm15, [rsp+0xE0]
00007d3d957cee75  add rsp, 0xF0
00007d3d957cee7c  pop r11
00007d3d957cee7e  pop r10
00007d3d957cee80  pop r9
00007d3d957cee82  pop r8
00007d3d957cee84  pop rsi
00007d3d957cee85  pop rdi
00007d3d957cee86  pop rdx
00007d3d957cee87  pop rcx
00007d3d957cee88  pop rax
00007d3d957cee89  add rsp, 0x08
00007d3d957cee8d  jmp 0x00007D3D957CEC71
00007d3d957cee92  call 0x00007D3D956C2240
00007d3d957cee97  jmp 0x00007D3D957CEC8B
00007d3d957cee9c  sub rsp, 0x08
00007d3d957ceea0  push rax
00007d3d957ceea1  push rcx
00007d3d957ceea2  push rdx
00007d3d957ceea3  push rdi
00007d3d957ceea4  push rsi
00007d3d957ceea5  push r8
00007d3d957ceea7  push r9
00007d3d957ceea9  push r10
00007d3d957ceeab  push r11
00007d3d957ceead  sub rsp, 0xF0
00007d3d957ceeb4  vmovaps [rsp], xmm0
00007d3d957ceeb9  vmovaps [rsp+0x10], xmm1
00007d3d957ceebf  vmovaps [rsp+0x20], xmm2
00007d3d957ceec5  vmovaps [rsp+0x30], xmm3
00007d3d957ceecb  vmovaps [rsp+0x40], xmm4
00007d3d957ceed1  vmovaps [rsp+0x50], xmm5
00007d3d957ceed7  vmovaps [rsp+0x60], xmm6
00007d3d957ceedd  vmovaps [rsp+0x70], xmm7
00007d3d957ceee3  vmovaps [rsp+0x80], xmm8
00007d3d957ceeec  vmovaps [rsp+0x90], xmm9
00007d3d957ceef5  vmovaps [rsp+0xA0], xmm10
00007d3d957ceefe  vmovaps [rsp+0xB0], xmm11
00007d3d957cef07  vmovaps [rsp+0xC0], xmm12
00007d3d957cef10  vmovaps [rsp+0xD0], xmm13
00007d3d957cef19  vmovaps [rsp+0xE0], xmm15
00007d3d957cef22  sub rsp, 0x30
00007d3d957cef26  movaps [rsp], xmm14
00007d3d957cef2b  movaps [rsp+0x10], xmm1
00007d3d957cef30  movaps [rsp+0x20], xmm15
00007d3d957cef36  lea rdi, [rsp]
00007d3d957cef3a  mov esi, 0x00
00007d3d957cef3f  mov rax, 0x56C27CB8A530
00007d3d957cef49  call rax
00007d3d957cef4b  movaps xmm14, [rsp]
00007d3d957cef50  add rsp, 0x30
00007d3d957cef54  vmovaps xmm0, [rsp]
00007d3d957cef59  vmovaps xmm1, [rsp+0x10]
00007d3d957cef5f  vmovaps xmm2, [rsp+0x20]
00007d3d957cef65  vmovaps xmm3, [rsp+0x30]
00007d3d957cef6b  vmovaps xmm4, [rsp+0x40]
00007d3d957cef71  vmovaps xmm5, [rsp+0x50]
00007d3d957cef77  vmovaps xmm6, [rsp+0x60]
00007d3d957cef7d  vmovaps xmm7, [rsp+0x70]
00007d3d957cef83  vmovaps xmm8, [rsp+0x80]
00007d3d957cef8c  vmovaps xmm9, [rsp+0x90]
00007d3d957cef95  vmovaps xmm10, [rsp+0xA0]
00007d3d957cef9e  vmovaps xmm11, [rsp+0xB0]
00007d3d957cefa7  vmovaps xmm12, [rsp+0xC0]
00007d3d957cefb0  vmovaps xmm13, [rsp+0xD0]
00007d3d957cefb9  vmovaps xmm15, [rsp+0xE0]
00007d3d957cefc2  add rsp, 0xF0
00007d3d957cefc9  pop r11
00007d3d957cefcb  pop r10
00007d3d957cefcd  pop r9
00007d3d957cefcf  pop r8
00007d3d957cefd1  pop rsi
00007d3d957cefd2  pop rdi
00007d3d957cefd3  pop rdx
00007d3d957cefd4  pop rcx
00007d3d957cefd5  pop rax
00007d3d957cefd6  add rsp, 0x08
00007d3d957cefda  jmp 0x00007D3D957CECAE
00007d3d957cefdf  call 0x00007D3D956C34C0
00007d3d957cefe4  jmp 0x00007D3D957CECC4
00007d3d957cefe9  int3
00007d3d957cefea  nop [rax+rax*1], ax
00007d3d957ceff0  mov rax, [r15+0xF8]
00007d3d957ceff7  lea r14, [rax-0x150]
00007d3d957ceffe  mov [r15+0xF8], r14
00007d3d957cf005  mov rax, [r15+0x50]
00007d3d957cf009  lea r12, [rax+0x80]
00007d3d957cf010  movups xmm1, [r13+r12*1]
00007d3d957cf016  lea r12, [rax+0x90]
00007d3d957cf01d  movups xmm15, [r13+r12*1]
00007d3d957cf023  mov qword ptr [r15+0x48], 0x00
00007d3d957cf02b  lea r12, [rax+0x40]
00007d3d957cf02f  movups xmm14, [r13+r12*1]
00007d3d957cf035  lea r12, [rax+0x50]
00007d3d957cf039  movups xmm13, [r13+r12*1]
00007d3d957cf03f  lea r12, [r14+0x120]
00007d3d957cf046  movq xmm12, qword ptr [r15+0x1C0]
00007d3d957cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007d3d957cf058  movq r11, xmm12
00007d3d957cf05d  movq r10, xmm11
00007d3d957cf062  mov [r13+r12*1], r11
00007d3d957cf067  lea r12, [r14+0x128]
00007d3d957cf06e  mov [r13+r12*1], r10
00007d3d957cf073  vxorps xmm12, xmm12, xmm12
00007d3d957cf078  vpbroadcastq xmm12, xmm12
00007d3d957cf07d  lea r12, [r14+0x100]
00007d3d957cf084  movq xmm11, qword ptr [r15+0x200]
00007d3d957cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007d3d957cf096  movq r11, xmm11
00007d3d957cf09b  movq r10, xmm10
00007d3d957cf0a0  mov [r13+r12*1], r11
00007d3d957cf0a5  lea r12, [r14+0x108]
00007d3d957cf0ac  mov [r13+r12*1], r10
00007d3d957cf0b1  lea r12, [r14+0xE0]
00007d3d957cf0b8  movups [r13+r12*1], xmm15
00007d3d957cf0be  lea r12, [r14+0xF0]
00007d3d957cf0c5  movups [r13+r12*1], xmm1
00007d3d957cf0cb  lea r12, [rax+0xC0]
00007d3d957cf0d2  movups xmm1, [r13+r12*1]
00007d3d957cf0d8  lea r12, [rax+0xD0]
00007d3d957cf0df  movups xmm15, [r13+r12*1]
00007d3d957cf0e5  lea r12, [r14+0x110]
00007d3d957cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007d3d957cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007d3d957cf0fe  movq r11, xmm11
00007d3d957cf103  movq r10, xmm10
00007d3d957cf108  mov [r13+r12*1], r11
00007d3d957cf10d  lea r12, [r14+0x118]
00007d3d957cf114  mov [r13+r12*1], r10
00007d3d957cf119  movups xmm11, [r13+rax*1]
00007d3d957cf11f  lea r12, [rax+0x10]
00007d3d957cf123  movups xmm10, [r13+r12*1]
00007d3d957cf129  lea r12, [r14+0x130]
00007d3d957cf130  movq xmm9, qword ptr [r15+0x1A0]
00007d3d957cf139  movq xmm8, qword ptr [r15+0x190]
00007d3d957cf142  movq r11, xmm9
00007d3d957cf147  movq r10, xmm8
00007d3d957cf14c  mov [r13+r12*1], r11
00007d3d957cf151  lea r12, [r14+0x138]
00007d3d957cf158  mov [r13+r12*1], r10
00007d3d957cf15d  lea r12, [rax+0x140]
00007d3d957cf164  movups xmm9, [r13+r12*1]
00007d3d957cf16a  lea r12, [rax+0x150]
00007d3d957cf171  movups xmm8, [r13+r12*1]
00007d3d957cf177  lea r12, [r14+0xC0]
00007d3d957cf17e  movups [r13+r12*1], xmm15
00007d3d957cf184  lea r12, [r14+0xD0]
00007d3d957cf18b  movups [r13+r12*1], xmm1
00007d3d957cf191  lea r12, [rax+0x100]
00007d3d957cf198  movups xmm1, [r13+r12*1]
00007d3d957cf19e  lea r12, [rax+0x110]
00007d3d957cf1a5  movups xmm15, [r13+r12*1]
00007d3d957cf1ab  lea r12, [r14+0x140]
00007d3d957cf1b2  mov r11, [r15+0xE8]
00007d3d957cf1b9  mov [r13+r12*1], r11
00007d3d957cf1be  lea r12, [rax+0x180]
00007d3d957cf1c5  movups xmm7, [r13+r12*1]
00007d3d957cf1cb  lea r12, [rax+0x190]
00007d3d957cf1d2  movups xmm6, [r13+r12*1]
00007d3d957cf1d8  lea r12, [rax+0x1C0]
00007d3d957cf1df  movups xmm5, [r13+r12*1]
00007d3d957cf1e5  lea r12, [rax+0x1D0]
00007d3d957cf1ec  movups xmm4, [r13+r12*1]
00007d3d957cf1f2  lea r12, [r14+0x20]
00007d3d957cf1f6  movups [r13+r12*1], xmm1
00007d3d957cf1fc  lea r12, [r14+0x30]
00007d3d957cf200  movups [r13+r12*1], xmm13
00007d3d957cf206  lea r12, [rax+0x60]
00007d3d957cf20a  movups xmm1, [r13+r12*1]
00007d3d957cf210  lea r12, [rax+0x70]
00007d3d957cf214  movups xmm13, [r13+r12*1]
00007d3d957cf21a  lea r12, [rax+0x20]
00007d3d957cf21e  movups xmm3, [r13+r12*1]
00007d3d957cf224  lea r12, [rax+0x30]
00007d3d957cf228  movups xmm2, [r13+r12*1]
00007d3d957cf22e  movaps [r15+0x1F0], xmm2
00007d3d957cf236  lea r12, [r14+0x60]
00007d3d957cf23a  movups [r13+r12*1], xmm11
00007d3d957cf240  lea r12, [r14+0x70]
00007d3d957cf244  movups [r13+r12*1], xmm5
00007d3d957cf24a  lea r12, [rax+0xE0]
00007d3d957cf251  movups xmm11, [r13+r12*1]
00007d3d957cf257  lea r12, [rax+0xF0]
00007d3d957cf25e  movups xmm5, [r13+r12*1]
00007d3d957cf264  lea r12, [r14+0xA0]
00007d3d957cf26b  movups [r13+r12*1], xmm13
00007d3d957cf271  lea r12, [r14+0xB0]
00007d3d957cf278  movups [r13+r12*1], xmm1
00007d3d957cf27e  lea r12, [rax+0xA0]
00007d3d957cf285  movups xmm1, [r13+r12*1]
00007d3d957cf28b  lea r12, [rax+0xB0]
00007d3d957cf292  movups xmm13, [r13+r12*1]
00007d3d957cf298  lea r12, [rax+0x120]
00007d3d957cf29f  vmovaps [rsp+0x10], xmm1
00007d3d957cf2a5  movups xmm1, [r13+r12*1]
00007d3d957cf2ab  lea r12, [rax+0x130]
00007d3d957cf2b2  vmovaps [rsp+0x20], xmm1
00007d3d957cf2b8  movups xmm1, [r13+r12*1]
00007d3d957cf2be  lea r12, [rax+0x160]
00007d3d957cf2c5  vmovaps [rsp+0x30], xmm1
00007d3d957cf2cb  movups xmm1, [r13+r12*1]
00007d3d957cf2d1  lea r12, [rax+0x170]
00007d3d957cf2d8  vmovaps [rsp+0x40], xmm1
00007d3d957cf2de  movups xmm1, [r13+r12*1]
00007d3d957cf2e4  movaps [r15+0x2B0], xmm1
00007d3d957cf2ec  lea r12, [r14+0x80]
00007d3d957cf2f3  movups [r13+r12*1], xmm13
00007d3d957cf2f9  lea r12, [r14+0x90]
00007d3d957cf300  vmovaps xmm13, [rsp+0x10]
00007d3d957cf306  movups [r13+r12*1], xmm13
00007d3d957cf30c  lea r12, [rax+0x1A0]
00007d3d957cf313  movups xmm13, [r13+r12*1]
00007d3d957cf319  lea r12, [rax+0x1B0]
00007d3d957cf320  vmovaps [rsp+0x10], xmm1
00007d3d957cf326  movups xmm1, [r13+r12*1]
00007d3d957cf32c  movaps [r15+0x290], xmm13
00007d3d957cf334  movaps [r15+0x1E0], xmm1
00007d3d957cf33c  lea r12, [rax+0x1E0]
00007d3d957cf343  vmovaps [rsp+0x50], xmm1
00007d3d957cf349  movups xmm1, [r13+r12*1]
00007d3d957cf34f  lea r12, [rax+0x1F0]
00007d3d957cf356  vmovaps [rsp+0x60], xmm1
00007d3d957cf35c  movups xmm1, [r13+r12*1]
00007d3d957cf362  mov qword ptr [r15+0x50], 0x430920
00007d3d957cf36a  lea rax, [r14+0x40]
00007d3d957cf36e  vmovaps [rsp+0x70], xmm1
00007d3d957cf374  vmovaps xmm1, [rsp+0x40]
00007d3d957cf37a  movups [r13+rax*1], xmm1
00007d3d957cf380  lea rax, [r14+0x50]
00007d3d957cf384  movups [r13+rax*1], xmm10
00007d3d957cf38a  vmovaps xmm1, [rsp+0x70]
00007d3d957cf390  movups [r13+r14*1], xmm1
00007d3d957cf396  lea rax, [r14+0x10]
00007d3d957cf39a  vmovaps xmm1, [rsp+0x60]
00007d3d957cf3a0  movups [r13+rax*1], xmm1
00007d3d957cf3a6  mov rax, [r15+0x40]
00007d3d957cf3aa  vmovaps [rsp+0x40], xmm3
00007d3d957cf3b0  vmovaps xmm1, [rsp+0x40]
00007d3d957cf3b6  por xmm3, xmm1
00007d3d957cf3ba  vmovaps [rsp+0x40], xmm6
00007d3d957cf3c0  vmovaps xmm10, [rsp+0x40]
00007d3d957cf3c6  por xmm6, xmm10
00007d3d957cf3cb  lea r12, [rax+0x30]
00007d3d957cf3cf  mov r11, [r13+r12*1]
00007d3d957cf3d4  lea r12, [rax+0x38]
00007d3d957cf3d8  mov r10, [r13+r12*1]
00007d3d957cf3dd  movq xmm10, r11
00007d3d957cf3e2  vmovaps [rsp+0x40], xmm1
00007d3d957cf3e8  movq xmm1, r10
00007d3d957cf3ed  movq xmm10, xmm10
00007d3d957cf3f2  vmovaps [rsp+0x60], xmm10
00007d3d957cf3f8  movq xmm10, xmm10
00007d3d957cf3fd  movaps [r15+0x130], xmm10
00007d3d957cf405  movq xmm1, xmm1
00007d3d957cf409  vmovaps [rsp+0x70], xmm1
00007d3d957cf40f  movq xmm1, xmm1
00007d3d957cf413  movaps [r15+0x280], xmm1
00007d3d957cf41b  vmovaps [rsp+0x80], xmm9
00007d3d957cf424  vmovaps xmm1, [rsp+0x80]
00007d3d957cf42d  por xmm9, xmm1
00007d3d957cf432  lea r12, [rax+0x20]
00007d3d957cf436  mov r11, [r13+r12*1]
00007d3d957cf43b  lea r12, [rax+0x28]
00007d3d957cf43f  mov r10, [r13+r12*1]
00007d3d957cf444  movq xmm1, r11
00007d3d957cf449  movq xmm10, r10
00007d3d957cf44e  movq xmm1, xmm1
00007d3d957cf452  vmovaps [rsp+0x80], xmm1
00007d3d957cf45b  movq xmm1, xmm1
00007d3d957cf45f  movaps [r15+0x150], xmm1
00007d3d957cf467  movq xmm10, xmm10
00007d3d957cf46c  vmovaps [rsp+0x90], xmm10
00007d3d957cf475  movq xmm10, xmm10
00007d3d957cf47a  movaps [r15+0x140], xmm10
00007d3d957cf482  lea r12, [rax+0x10]
00007d3d957cf486  mov r11, [r13+r12*1]
00007d3d957cf48b  lea r12, [rax+0x18]
00007d3d957cf48f  mov r10, [r13+r12*1]
00007d3d957cf494  movq xmm1, r11
00007d3d957cf499  movq xmm10, r10
00007d3d957cf49e  movq xmm1, xmm1
00007d3d957cf4a2  vmovaps [rsp+0xA0], xmm1
00007d3d957cf4ab  movq xmm1, xmm1
00007d3d957cf4af  movaps [r15+0x170], xmm1
00007d3d957cf4b7  movq xmm10, xmm10
00007d3d957cf4bc  vmovaps [rsp+0xB0], xmm10
00007d3d957cf4c5  movq xmm10, xmm10
00007d3d957cf4ca  movaps [r15+0x160], xmm10
00007d3d957cf4d2  mov r12, [r13+rax*1]
00007d3d957cf4d7  vmovq xmm1, r12
00007d3d957cf4dc  vpbroadcastq xmm1, xmm1
00007d3d957cf4e1  lea r12, [rax+0x08]
00007d3d957cf4e5  mov rax, [r13+r12*1]
00007d3d957cf4ea  movq xmm10, rax
00007d3d957cf4ef  movaps [r15+0x230], xmm10
00007d3d957cf4f7  lea rax, [r14+0x50]
00007d3d957cf4fb  movups xmm10, [r13+rax*1]
00007d3d957cf501  lea rax, [r14+0x60]
00007d3d957cf505  vmovaps [rsp+0xC0], xmm1
00007d3d957cf50e  movups xmm1, [r13+rax*1]
00007d3d957cf514  lea rax, [r14+0x30]
00007d3d957cf518  vmovaps [rsp+0xD0], xmm1
00007d3d957cf521  movups xmm1, [r13+rax*1]
00007d3d957cf527  mov qword ptr [r15+0x60], 0x430920
00007d3d957cf52f  mov qword ptr [r15+0x58], 0x40
00007d3d957cf537  vmovaps [rsp+0xE0], xmm1
00007d3d957cf540  vmovaps [rsp+0xF0], xmm15
00007d3d957cf549  vmovaps xmm15, [rsp+0xC0]
00007d3d957cf552  vmovaps [rsp+0xC0], xmm14
00007d3d957cf55b  vmovaps xmm14, [rsp+0x40]
00007d3d957cf561  vmovaps [rsp+0x40], xmm13
00007d3d957cf567  movaps xmm1, xmm15
00007d3d957cf56b  mulpd xmm1, xmm14
00007d3d957cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007d3d957cf575  ptest xmm13, xmm13
00007d3d957cf57b  jnz 0x00007D3D957D0682
00007d3d957cf581  movq xmm14, qword ptr [r15+0x230]
00007d3d957cf58a  vmovaps [rsp+0x100], xmm14
00007d3d957cf593  vpermilpd xmm14, xmm14, 0x00
00007d3d957cf599  vmovaps [rsp+0x110], xmm1
00007d3d957cf5a2  vmovaps xmm1, [rsp+0xE0]
00007d3d957cf5ab  vmovaps [rsp+0xE0], xmm15
00007d3d957cf5b4  movaps xmm13, xmm1
00007d3d957cf5b8  mulpd xmm13, xmm14
00007d3d957cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007d3d957cf5c3  ptest xmm15, xmm15
00007d3d957cf5c9  jnz 0x00007D3D957D07C4
00007d3d957cf5cf  vxorps xmm1, xmm1, xmm1
00007d3d957cf5d3  vpbroadcastq xmm1, xmm1
00007d3d957cf5d8  vmovaps xmm14, [rsp+0xE0]
00007d3d957cf5e1  vmovaps [rsp+0xE0], xmm1
00007d3d957cf5ea  vmovaps xmm1, [rsp+0xD0]
00007d3d957cf5f3  vmovaps [rsp+0xD0], xmm13
00007d3d957cf5fc  movaps xmm15, xmm14
00007d3d957cf600  mulpd xmm15, xmm1
00007d3d957cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007d3d957cf60b  ptest xmm13, xmm13
00007d3d957cf611  jnz 0x00007D3D957D0907
00007d3d957cf617  movaps xmm1, xmm14
00007d3d957cf61b  mulpd xmm1, xmm10
00007d3d957cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007d3d957cf625  ptest xmm13, xmm13
00007d3d957cf62b  jnz 0x00007D3D957D0A4A
00007d3d957cf631  movaps xmm13, xmm14
00007d3d957cf635  mulpd xmm13, xmm2
00007d3d957cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007d3d957cf640  ptest xmm10, xmm10
00007d3d957cf646  jnz 0x00007D3D957D0B8C
00007d3d957cf64c  vmovaps [rsp+0x120], xmm7
00007d3d957cf655  vmovaps xmm14, [rsp+0x120]
00007d3d957cf65e  por xmm7, xmm14
00007d3d957cf663  vmovaps xmm14, [rsp+0xC0]
00007d3d957cf66c  vmovaps xmm10, [rsp+0xC0]
00007d3d957cf675  por xmm14, xmm10
00007d3d957cf67a  vmovaps xmm2, [rsp+0x100]
00007d3d957cf683  vpermilpd xmm2, xmm2, 0x00
00007d3d957cf689  vmovaps [rsp+0xC0], xmm1
00007d3d957cf692  vmovaps [rsp+0x120], xmm15
00007d3d957cf69b  movaps xmm1, xmm10
00007d3d957cf69f  mulpd xmm1, xmm2
00007d3d957cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007d3d957cf6a8  ptest xmm15, xmm15
00007d3d957cf6ae  jnz 0x00007D3D957D0CCF
00007d3d957cf6b4  xor eax, eax
00007d3d957cf6b6  mov r12d, 0x40
00007d3d957cf6bc  mov r11d, 0x200
00007d3d957cf6c2  cmp r12, r11
00007d3d957cf6c5  cmc
00007d3d957cf6c6  lahf
00007d3d957cf6c7  seto al
00007d3d957cf6ca  mov [r15+0x108], eax
00007d3d957cf6d1  vmovaps xmm10, [rsp+0x110]
00007d3d957cf6da  vmovaps xmm2, [rsp+0xE0]
00007d3d957cf6e3  vmovaps [rsp+0xE0], xmm1
00007d3d957cf6ec  movaps xmm15, xmm10
00007d3d957cf6f0  addpd xmm15, xmm2
00007d3d957cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007d3d957cf6fb  ptest xmm1, xmm1
00007d3d957cf700  jnz 0x00007D3D957D0E10
00007d3d957cf706  vmovaps xmm10, [rsp+0x120]
00007d3d957cf70f  vmovaps [rsp+0x110], xmm15
00007d3d957cf718  movaps xmm1, xmm10
00007d3d957cf71c  addpd xmm1, xmm12
00007d3d957cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007d3d957cf726  ptest xmm15, xmm15
00007d3d957cf72c  jnz 0x00007D3D957D0F53
00007d3d957cf732  vmovaps xmm10, [rsp+0xC0]
00007d3d957cf73b  vmovaps [rsp+0xC0], xmm1
00007d3d957cf744  movaps xmm15, xmm10
00007d3d957cf748  addpd xmm15, xmm12
00007d3d957cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007d3d957cf753  ptest xmm1, xmm1
00007d3d957cf758  jnz 0x00007D3D957D1095
00007d3d957cf75e  vmovaps xmm1, [rsp+0x30]
00007d3d957cf764  vmovaps xmm12, [rsp+0x30]
00007d3d957cf76a  por xmm1, xmm12
00007d3d957cf76f  vmovaps xmm12, [rsp+0x20]
00007d3d957cf775  vmovaps xmm10, [rsp+0x20]
00007d3d957cf77b  por xmm12, xmm10
00007d3d957cf780  vmovaps [rsp+0x20], xmm5
00007d3d957cf786  vmovaps xmm10, [rsp+0x20]
00007d3d957cf78c  por xmm5, xmm10
00007d3d957cf791  vmovaps [rsp+0x20], xmm11
00007d3d957cf797  vmovaps xmm10, [rsp+0x20]
00007d3d957cf79d  por xmm11, xmm10
00007d3d957cf7a2  vmovaps [rsp+0x20], xmm4
00007d3d957cf7a8  vmovaps xmm10, [rsp+0x20]
00007d3d957cf7ae  por xmm4, xmm10
00007d3d957cf7b3  vmovaps [rsp+0x20], xmm8
00007d3d957cf7b9  vmovaps xmm10, [rsp+0x20]
00007d3d957cf7bf  por xmm8, xmm10
00007d3d957cf7c4  vmovaps xmm10, [rsp+0xF0]
00007d3d957cf7cd  vmovaps [rsp+0x20], xmm1
00007d3d957cf7d3  vmovaps xmm1, [rsp+0xF0]
00007d3d957cf7dc  por xmm10, xmm1
00007d3d957cf7e1  lea rax, [r14+0xA0]
00007d3d957cf7e8  movups xmm1, [r13+rax*1]
00007d3d957cf7ee  lea rax, [r14+0xB0]
00007d3d957cf7f5  vmovaps [rsp+0x30], xmm1
00007d3d957cf7fb  movups xmm1, [r13+rax*1]
00007d3d957cf801  vmovaps [rsp+0xF0], xmm1
00007d3d957cf80a  vmovaps [rsp+0x120], xmm15
00007d3d957cf813  movaps xmm1, xmm13
00007d3d957cf817  addpd xmm1, xmm2
00007d3d957cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007d3d957cf820  ptest xmm15, xmm15
00007d3d957cf826  jnz 0x00007D3D957D11ED
00007d3d957cf82c  lea rax, [r14+0xF0]
00007d3d957cf833  movups xmm15, [r13+rax*1]
00007d3d957cf839  vmovaps xmm2, [rsp+0xC0]
00007d3d957cf842  vmovaps [rsp+0xC0], xmm1
00007d3d957cf84b  vmovaps xmm1, [rsp+0xE0]
00007d3d957cf854  vmovaps [rsp+0xE0], xmm15
00007d3d957cf85d  movaps xmm13, xmm2
00007d3d957cf861  addpd xmm13, xmm1
00007d3d957cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007d3d957cf86c  ptest xmm15, xmm15
00007d3d957cf872  jnz 0x00007D3D957D1338
00007d3d957cf878  vmovaps xmm15, [rsp+0x120]
00007d3d957cf881  vmovaps xmm2, [rsp+0xD0]
00007d3d957cf88a  vmovaps [rsp+0xD0], xmm14
00007d3d957cf893  movaps xmm1, xmm15
00007d3d957cf897  addpd xmm1, xmm2
00007d3d957cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007d3d957cf8a0  ptest xmm14, xmm14
00007d3d957cf8a6  jnz 0x00007D3D957D147A
00007d3d957cf8ac  vmovaps xmm15, [rsp+0x100]
00007d3d957cf8b5  vpermilpd xmm15, xmm15, 0x00
00007d3d957cf8bb  vmovaps xmm2, [rsp+0xF0]
00007d3d957cf8c4  vmovaps [rsp+0xF0], xmm1
00007d3d957cf8cd  movaps xmm14, xmm2
00007d3d957cf8d1  mulpd xmm14, xmm15
00007d3d957cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007d3d957cf8dc  ptest xmm1, xmm1
00007d3d957cf8e1  jnz 0x00007D3D957D15BB
00007d3d957cf8e7  vmovaps xmm1, [rsp+0xA0]
00007d3d957cf8f0  vpermilpd xmm1, xmm1, 0x00
00007d3d957cf8f6  vmovaps xmm2, [rsp+0xE0]
00007d3d957cf8ff  vmovaps [rsp+0xE0], xmm14
00007d3d957cf908  movaps xmm15, xmm2
00007d3d957cf90c  mulpd xmm15, xmm1
00007d3d957cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007d3d957cf917  ptest xmm14, xmm14
00007d3d957cf91d  jnz 0x00007D3D957D16FE
00007d3d957cf923  lea rax, [r14+0xE0]
00007d3d957cf92a  movups xmm1, [r13+rax*1]
00007d3d957cf930  vmovaps xmm14, [rsp+0x100]
00007d3d957cf939  vpermilpd xmm14, xmm14, 0x00
00007d3d957cf93f  vmovaps [rsp+0x100], xmm1
00007d3d957cf948  vmovaps xmm1, [rsp+0x30]
00007d3d957cf94e  vmovaps [rsp+0x30], xmm15
00007d3d957cf954  movaps xmm2, xmm1
00007d3d957cf957  mulpd xmm2, xmm14
00007d3d957cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007d3d957cf961  ptest xmm15, xmm15
00007d3d957cf967  jnz 0x00007D3D957D184A
00007d3d957cf96d  vmovaps [rsp+0x120], xmm10
00007d3d957cf976  vmovaps xmm1, [rsp+0x120]
00007d3d957cf97f  por xmm10, xmm1
00007d3d957cf984  movaps [r15+0x300], xmm10
00007d3d957cf98c  vmovaps [rsp+0x120], xmm8
00007d3d957cf995  vmovaps xmm1, [rsp+0x120]
00007d3d957cf99e  por xmm8, xmm1
00007d3d957cf9a3  movaps [r15+0x190], xmm8
00007d3d957cf9ab  vmovaps xmm1, [rsp+0xA0]
00007d3d957cf9b4  vpermilpd xmm1, xmm1, 0x00
00007d3d957cf9ba  vmovaps xmm14, [rsp+0x100]
00007d3d957cf9c3  vmovaps [rsp+0x100], xmm13
00007d3d957cf9cc  movaps xmm15, xmm14
00007d3d957cf9d0  mulpd xmm15, xmm1
00007d3d957cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007d3d957cf9db  ptest xmm13, xmm13
00007d3d957cf9e1  jnz 0x00007D3D957D198B
00007d3d957cf9e7  lea rax, [r14+0x90]
00007d3d957cf9ee  movups xmm1, [r13+rax*1]
00007d3d957cf9f4  vmovaps [rsp+0x120], xmm4
00007d3d957cf9fd  vmovaps xmm14, [rsp+0x120]
00007d3d957cfa06  por xmm4, xmm14
00007d3d957cfa0b  movaps [r15+0x1C0], xmm4
00007d3d957cfa13  vmovaps [rsp+0x120], xmm11
00007d3d957cfa1c  vmovaps xmm14, [rsp+0x120]
00007d3d957cfa25  por xmm11, xmm14
00007d3d957cfa2a  movaps [r15+0x200], xmm11
00007d3d957cfa32  vmovaps [rsp+0x120], xmm5
00007d3d957cfa3b  vmovaps xmm14, [rsp+0x120]
00007d3d957cfa44  por xmm5, xmm14
00007d3d957cfa49  movaps [r15+0x2D0], xmm5
00007d3d957cfa51  vmovaps [rsp+0x120], xmm12
00007d3d957cfa5a  vmovaps xmm14, [rsp+0x120]
00007d3d957cfa63  por xmm12, xmm14
00007d3d957cfa68  movaps [r15+0x2E0], xmm12
00007d3d957cfa70  vmovaps xmm13, [rsp+0x110]
00007d3d957cfa79  vmovaps [rsp+0x110], xmm1
00007d3d957cfa82  vmovaps xmm1, [rsp+0xE0]
00007d3d957cfa8b  vmovaps [rsp+0xE0], xmm15
00007d3d957cfa94  movaps xmm14, xmm13
00007d3d957cfa98  addpd xmm14, xmm1
00007d3d957cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007d3d957cfaa3  ptest xmm15, xmm15
00007d3d957cfaa9  jnz 0x00007D3D957D1AD8
00007d3d957cfaaf  vmovaps xmm1, [rsp+0xA0]
00007d3d957cfab8  vpermilpd xmm1, xmm1, 0x00
00007d3d957cfabe  vmovaps xmm13, [rsp+0x110]
00007d3d957cfac7  vmovaps [rsp+0x110], xmm14
00007d3d957cfad0  movaps xmm15, xmm13
00007d3d957cfad4  mulpd xmm15, xmm1
00007d3d957cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007d3d957cfadf  ptest xmm14, xmm14
00007d3d957cfae5  jnz 0x00007D3D957D1C1B
00007d3d957cfaeb  lea rax, [r14+0x80]
00007d3d957cfaf2  movups xmm1, [r13+rax*1]
00007d3d957cfaf8  vmovaps xmm13, [rsp+0xC0]
00007d3d957cfb01  vmovaps [rsp+0xC0], xmm1
00007d3d957cfb0a  movaps xmm14, xmm13
00007d3d957cfb0e  addpd xmm14, xmm2
00007d3d957cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007d3d957cfb19  ptest xmm1, xmm1
00007d3d957cfb1e  jnz 0x00007D3D957D1D68
00007d3d957cfb24  vmovaps xmm13, [rsp+0x100]
00007d3d957cfb2d  vmovaps xmm2, [rsp+0x30]
00007d3d957cfb33  vmovaps [rsp+0x30], xmm15
00007d3d957cfb39  movaps xmm1, xmm13
00007d3d957cfb3d  addpd xmm1, xmm2
00007d3d957cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007d3d957cfb46  ptest xmm15, xmm15
00007d3d957cfb4c  jnz 0x00007D3D957D1EAB
00007d3d957cfb52  vmovaps xmm15, [rsp+0x20]
00007d3d957cfb58  vmovaps xmm13, [rsp+0x20]
00007d3d957cfb5e  por xmm15, xmm13
00007d3d957cfb63  movaps [r15+0x2F0], xmm15
00007d3d957cfb6b  vmovaps xmm13, [rsp+0xA0]
00007d3d957cfb74  vpermilpd xmm13, xmm13, 0x00
00007d3d957cfb7a  vmovaps [rsp+0x20], xmm1
00007d3d957cfb80  vmovaps xmm1, [rsp+0xC0]
00007d3d957cfb89  vmovaps [rsp+0xA0], xmm15
00007d3d957cfb92  movaps xmm2, xmm1
00007d3d957cfb95  mulpd xmm2, xmm13
00007d3d957cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007d3d957cfb9f  ptest xmm15, xmm15
00007d3d957cfba5  jnz 0x00007D3D957D1FEC
00007d3d957cfbab  lea rax, [r14+0xD0]
00007d3d957cfbb2  movups xmm1, [r13+rax*1]
00007d3d957cfbb8  vmovaps xmm13, [rsp+0xF0]
00007d3d957cfbc1  vmovaps [rsp+0xC0], xmm1
00007d3d957cfbca  vmovaps xmm1, [rsp+0xE0]
00007d3d957cfbd3  vmovaps [rsp+0xE0], xmm14
00007d3d957cfbdc  movaps xmm15, xmm13
00007d3d957cfbe0  addpd xmm15, xmm1
00007d3d957cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007d3d957cfbeb  ptest xmm14, xmm14
00007d3d957cfbf1  jnz 0x00007D3D957D2137
00007d3d957cfbf7  vmovaps xmm1, [rsp+0xB0]
00007d3d957cfc00  vpermilpd xmm1, xmm1, 0x00
00007d3d957cfc06  movaps xmm14, xmm11
00007d3d957cfc0a  mulpd xmm14, xmm1
00007d3d957cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007d3d957cfc15  ptest xmm13, xmm13
00007d3d957cfc1b  jnz 0x00007D3D957D227A
00007d3d957cfc21  movaps [r15+0x260], xmm14
00007d3d957cfc29  vxorps xmm1, xmm1, xmm1
00007d3d957cfc2d  vpbroadcastq xmm1, xmm1
00007d3d957cfc32  movaps [r15+0x1B0], xmm1
00007d3d957cfc3a  vmovaps xmm1, [rsp+0xB0]
00007d3d957cfc43  vpermilpd xmm1, xmm1, 0x00
00007d3d957cfc49  vmovaps xmm11, [rsp+0xC0]
00007d3d957cfc52  vmovaps [rsp+0xC0], xmm15
00007d3d957cfc5b  movaps xmm13, xmm11
00007d3d957cfc5f  mulpd xmm13, xmm1
00007d3d957cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007d3d957cfc6a  ptest xmm15, xmm15
00007d3d957cfc70  jnz 0x00007D3D957D23BD
00007d3d957cfc76  lea rax, [r14+0xC0]
00007d3d957cfc7d  movups xmm1, [r13+rax*1]
00007d3d957cfc83  vmovaps xmm11, [rsp+0x110]
00007d3d957cfc8c  vmovaps [rsp+0xF0], xmm1
00007d3d957cfc95  vmovaps xmm1, [rsp+0x30]
00007d3d957cfc9b  vmovaps [rsp+0x30], xmm14
00007d3d957cfca1  movaps xmm15, xmm11
00007d3d957cfca5  addpd xmm15, xmm1
00007d3d957cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007d3d957cfcb0  ptest xmm14, xmm14
00007d3d957cfcb6  jnz 0x00007D3D957D250A
00007d3d957cfcbc  vmovaps [rsp+0x100], xmm9
00007d3d957cfcc5  vmovaps xmm1, [rsp+0x100]
00007d3d957cfcce  por xmm9, xmm1
00007d3d957cfcd3  movaps [r15+0x270], xmm9
00007d3d957cfcdb  vmovaps [rsp+0x100], xmm6
00007d3d957cfce4  vmovaps xmm1, [rsp+0x100]
00007d3d957cfced  por xmm6, xmm1
00007d3d957cfcf1  movaps [r15+0x1A0], xmm6
00007d3d957cfcf9  vmovaps xmm14, [rsp+0xB0]
00007d3d957cfd02  vpermilpd xmm14, xmm14, 0x00
00007d3d957cfd08  vmovaps xmm6, [rsp+0xF0]
00007d3d957cfd11  vmovaps [rsp+0xF0], xmm1
00007d3d957cfd1a  movaps xmm11, xmm6
00007d3d957cfd1e  mulpd xmm11, xmm14
00007d3d957cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007d3d957cfd29  ptest xmm1, xmm1
00007d3d957cfd2e  jnz 0x00007D3D957D264D
00007d3d957cfd34  lea rax, [r14+0x20]
00007d3d957cfd38  movups xmm1, [r13+rax*1]
00007d3d957cfd3e  movaps [r15+0x110], xmm1
00007d3d957cfd46  vmovaps xmm6, [rsp+0xE0]
00007d3d957cfd4f  vmovaps [rsp+0xE0], xmm1
00007d3d957cfd58  movaps xmm14, xmm6
00007d3d957cfd5c  addpd xmm14, xmm2
00007d3d957cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007d3d957cfd67  ptest xmm1, xmm1
00007d3d957cfd6c  jnz 0x00007D3D957D279A
00007d3d957cfd72  vmovaps xmm1, [rsp+0xB0]
00007d3d957cfd7b  vpermilpd xmm1, xmm1, 0x00
00007d3d957cfd81  movaps xmm6, xmm5
00007d3d957cfd84  mulpd xmm6, xmm1
00007d3d957cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007d3d957cfd8d  ptest xmm2, xmm2
00007d3d957cfd92  jnz 0x00007D3D957D28DC
00007d3d957cfd98  vmovaps xmm5, [rsp+0x20]
00007d3d957cfd9e  movaps xmm1, xmm5
00007d3d957cfda1  addpd xmm1, xmm13
00007d3d957cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007d3d957cfdab  ptest xmm2, xmm2
00007d3d957cfdb0  jnz 0x00007D3D957D2A1C
00007d3d957cfdb6  vmovaps xmm13, [rsp+0x80]
00007d3d957cfdbf  vpermilpd xmm13, xmm13, 0x00
00007d3d957cfdc5  vmovaps xmm2, [rsp+0xE0]
00007d3d957cfdce  vmovaps [rsp+0x20], xmm1
00007d3d957cfdd4  movaps xmm5, xmm2
00007d3d957cfdd7  mulpd xmm5, xmm13
00007d3d957cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007d3d957cfde1  ptest xmm1, xmm1
00007d3d957cfde6  jnz 0x00007D3D957D2B5D
00007d3d957cfdec  vmovaps xmm1, [rsp+0x80]
00007d3d957cfdf5  vpermilpd xmm1, xmm1, 0x00
00007d3d957cfdfb  movaps xmm13, xmm10
00007d3d957cfdff  mulpd xmm13, xmm1
00007d3d957cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007d3d957cfe0a  ptest xmm2, xmm2
00007d3d957cfe0f  jnz 0x00007D3D957D2C9E
00007d3d957cfe15  vmovaps xmm10, [rsp+0x30]
00007d3d957cfe1b  movaps xmm1, xmm15
00007d3d957cfe1f  addpd xmm1, xmm10
00007d3d957cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007d3d957cfe29  ptest xmm2, xmm2
00007d3d957cfe2e  jnz 0x00007D3D957D2DE1
00007d3d957cfe34  vmovaps xmm10, [rsp+0xC0]
00007d3d957cfe3d  movaps xmm15, xmm10
00007d3d957cfe41  addpd xmm15, xmm11
00007d3d957cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007d3d957cfe4c  ptest xmm2, xmm2
00007d3d957cfe51  jnz 0x00007D3D957D2F23
00007d3d957cfe57  vmovaps xmm11, [rsp+0x80]
00007d3d957cfe60  vpermilpd xmm11, xmm11, 0x00
00007d3d957cfe66  movaps xmm10, xmm12
00007d3d957cfe6a  mulpd xmm10, xmm11
00007d3d957cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007d3d957cfe75  ptest xmm2, xmm2
00007d3d957cfe7a  jnz 0x00007D3D957D3067
00007d3d957cfe80  vmovaps xmm12, [rsp+0x80]
00007d3d957cfe89  vpermilpd xmm12, xmm12, 0x00
00007d3d957cfe8f  vmovaps xmm2, [rsp+0xA0]
00007d3d957cfe98  vmovaps [rsp+0x30], xmm1
00007d3d957cfe9e  movaps xmm11, xmm2
00007d3d957cfea2  mulpd xmm11, xmm12
00007d3d957cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007d3d957cfead  ptest xmm1, xmm1
00007d3d957cfeb2  jnz 0x00007D3D957D31AB
00007d3d957cfeb8  movaps xmm1, xmm14
00007d3d957cfebc  addpd xmm1, xmm6
00007d3d957cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007d3d957cfec5  ptest xmm12, xmm12
00007d3d957cfecb  jnz 0x00007D3D957D32EE
00007d3d957cfed1  vmovaps xmm12, [rsp+0x20]
00007d3d957cfed7  movaps xmm14, xmm12
00007d3d957cfedb  addpd xmm14, xmm5
00007d3d957cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007d3d957cfee6  ptest xmm6, xmm6
00007d3d957cfeeb  jnz 0x00007D3D957D342F
00007d3d957cfef1  vmovaps xmm12, [rsp+0x90]
00007d3d957cfefa  vpermilpd xmm12, xmm12, 0x00
00007d3d957cff00  movaps xmm6, xmm9
00007d3d957cff04  mulpd xmm6, xmm12
00007d3d957cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007d3d957cff0e  ptest xmm5, xmm5
00007d3d957cff13  jnz 0x00007D3D957D3572
00007d3d957cff19  movaps xmm12, xmm15
00007d3d957cff1d  addpd xmm12, xmm13
00007d3d957cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007d3d957cff28  ptest xmm9, xmm9
00007d3d957cff2e  jnz 0x00007D3D957D36B4
00007d3d957cff34  vmovaps xmm13, [rsp+0x30]
00007d3d957cff3a  movaps xmm15, xmm13
00007d3d957cff3e  addpd xmm15, xmm10
00007d3d957cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007d3d957cff49  ptest xmm9, xmm9
00007d3d957cff4f  jnz 0x00007D3D957D37F8
00007d3d957cff55  vmovaps xmm13, [rsp+0xD0]
00007d3d957cff5e  vmovaps xmm10, [rsp+0xD0]
00007d3d957cff67  por xmm13, xmm10
00007d3d957cff6c  movaps [r15+0x250], xmm13
00007d3d957cff74  vmovaps [rsp+0x20], xmm7
00007d3d957cff7a  vmovaps xmm13, [rsp+0x20]
00007d3d957cff80  por xmm7, xmm13
00007d3d957cff85  movaps [r15+0x2A0], xmm7
00007d3d957cff8d  vmovaps [rsp+0x20], xmm3
00007d3d957cff93  vmovaps xmm13, [rsp+0x20]
00007d3d957cff99  por xmm3, xmm13
00007d3d957cff9e  movaps [r15+0x1D0], xmm3
00007d3d957cffa6  lea rax, [r14+0x40]
00007d3d957cffaa  movups xmm13, [r13+rax*1]
00007d3d957cffb0  movaps [r15+0x2C0], xmm13
00007d3d957cffb8  vmovaps xmm10, [rsp+0x90]
00007d3d957cffc1  vpermilpd xmm10, xmm10, 0x00
00007d3d957cffc7  movaps xmm9, xmm8
00007d3d957cffcb  mulpd xmm9, xmm10
00007d3d957cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007d3d957cffd6  ptest xmm5, xmm5
00007d3d957cffdb  jnz 0x00007D3D957D3946
00007d3d957cffe1  movaps xmm10, xmm1
00007d3d957cffe5  addpd xmm10, xmm11
00007d3d957cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007d3d957cfff0  ptest xmm8, xmm8
00007d3d957cfff6  jnz 0x00007D3D957D3A8A
00007d3d957cfffc  movaps xmm1, xmm14
00007d3d957d0000  addpd xmm1, xmm6
00007d3d957d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007d3d957d0009  ptest xmm11, xmm11
00007d3d957d000f  jnz 0x00007D3D957D3BCD
00007d3d957d0015  vmovaps xmm14, [rsp+0x90]
00007d3d957d001e  vpermilpd xmm14, xmm14, 0x00
00007d3d957d0024  movaps xmm11, xmm13
00007d3d957d0028  mulpd xmm11, xmm14
00007d3d957d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007d3d957d0033  ptest xmm8, xmm8
00007d3d957d0039  jnz 0x00007D3D957D3D0E
00007d3d957d003f  vmovaps xmm14, [rsp+0x90]
00007d3d957d0048  vpermilpd xmm14, xmm14, 0x00
00007d3d957d004e  vmovaps xmm8, [rsp+0x10]
00007d3d957d0054  movaps xmm13, xmm8
00007d3d957d0058  mulpd xmm13, xmm14
00007d3d957d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007d3d957d0063  ptest xmm6, xmm6
00007d3d957d0068  jnz 0x00007D3D957D3E52
00007d3d957d006e  vmovaps xmm14, [rsp+0x60]
00007d3d957d0074  vpermilpd xmm14, xmm14, 0x00
00007d3d957d007a  movaps xmm8, xmm7
00007d3d957d007e  mulpd xmm8, xmm14
00007d3d957d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007d3d957d0089  ptest xmm6, xmm6
00007d3d957d008e  jnz 0x00007D3D957D3F96
00007d3d957d0094  movaps xmm14, xmm12
00007d3d957d0098  addpd xmm14, xmm9
00007d3d957d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007d3d957d00a3  ptest xmm7, xmm7
00007d3d957d00a8  jnz 0x00007D3D957D40D9
00007d3d957d00ae  vmovaps xmm12, [rsp+0x60]
00007d3d957d00b4  vpermilpd xmm12, xmm12, 0x00
00007d3d957d00ba  vmovaps xmm7, [rsp+0xF0]
00007d3d957d00c3  movaps xmm9, xmm7
00007d3d957d00c7  mulpd xmm9, xmm12
00007d3d957d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007d3d957d00d2  ptest xmm6, xmm6
00007d3d957d00d7  jnz 0x00007D3D957D421D
00007d3d957d00dd  movaps xmm12, xmm15
00007d3d957d00e1  addpd xmm12, xmm11
00007d3d957d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007d3d957d00ec  ptest xmm7, xmm7
00007d3d957d00f1  jnz 0x00007D3D957D4360
00007d3d957d00f7  vmovaps xmm15, [rsp+0x60]
00007d3d957d00fd  vpermilpd xmm15, xmm15, 0x00
00007d3d957d0103  vmovaps xmm7, [rsp+0x40]
00007d3d957d0109  movaps xmm11, xmm7
00007d3d957d010d  mulpd xmm11, xmm15
00007d3d957d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007d3d957d0118  ptest xmm6, xmm6
00007d3d957d011d  jnz 0x00007D3D957D44A4
00007d3d957d0123  movaps xmm15, xmm10
00007d3d957d0127  addpd xmm15, xmm13
00007d3d957d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007d3d957d0132  ptest xmm7, xmm7
00007d3d957d0137  jnz 0x00007D3D957D45E7
00007d3d957d013d  vmovaps xmm13, [rsp+0x60]
00007d3d957d0143  vpermilpd xmm13, xmm13, 0x00
00007d3d957d0149  vmovaps xmm7, [rsp+0x50]
00007d3d957d014f  movaps xmm10, xmm7
00007d3d957d0153  mulpd xmm10, xmm13
00007d3d957d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007d3d957d015e  ptest xmm6, xmm6
00007d3d957d0163  jnz 0x00007D3D957D472B
00007d3d957d0169  movaps xmm13, xmm1
00007d3d957d016d  addpd xmm13, xmm8
00007d3d957d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007d3d957d0178  ptest xmm7, xmm7
00007d3d957d017d  jnz 0x00007D3D957D486E
00007d3d957d0183  lea rax, [r14+0x70]
00007d3d957d0187  movups xmm1, [r13+rax*1]
00007d3d957d018d  movaps [r15+0x240], xmm1
00007d3d957d0195  movaps xmm8, xmm14
00007d3d957d0199  addpd xmm8, xmm9
00007d3d957d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007d3d957d01a4  ptest xmm7, xmm7
00007d3d957d01a9  jnz 0x00007D3D957D49BB
00007d3d957d01af  movaps [r15+0x170], xmm8
00007d3d957d01b7  vmovaps xmm14, [rsp+0x70]
00007d3d957d01bd  vpermilpd xmm14, xmm14, 0x00
00007d3d957d01c3  movaps xmm9, xmm1
00007d3d957d01c7  mulpd xmm9, xmm14
00007d3d957d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007d3d957d01d2  ptest xmm7, xmm7
00007d3d957d01d7  jnz 0x00007D3D957D4AFF
00007d3d957d01dd  vmovaps xmm1, [rsp+0x70]
00007d3d957d01e3  vpermilpd xmm1, xmm1, 0x00
00007d3d957d01e9  movaps xmm14, xmm4
00007d3d957d01ed  mulpd xmm14, xmm1
00007d3d957d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007d3d957d01f8  ptest xmm7, xmm7
00007d3d957d01fd  jnz 0x00007D3D957D4C42
00007d3d957d0203  movaps [r15+0x180], xmm14
00007d3d957d020b  movaps xmm1, xmm12
00007d3d957d020f  addpd xmm1, xmm11
00007d3d957d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007d3d957d0219  ptest xmm7, xmm7
00007d3d957d021e  jnz 0x00007D3D957D4D84
00007d3d957d0224  movaps [r15+0x210], xmm1
00007d3d957d022c  movups xmm12, [r13+r14*1]
00007d3d957d0232  lea rax, [r14+0x10]
00007d3d957d0236  movups xmm11, [r13+rax*1]
00007d3d957d023c  movaps [r15+0x230], xmm11
00007d3d957d0244  movaps xmm7, xmm15
00007d3d957d0248  addpd xmm7, xmm10
00007d3d957d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007d3d957d0252  ptest xmm6, xmm6
00007d3d957d0257  jnz 0x00007D3D957D4EDA
00007d3d957d025d  movaps [r15+0x130], xmm7
00007d3d957d0265  vmovaps xmm15, [rsp+0x70]
00007d3d957d026b  vpermilpd xmm15, xmm15, 0x00
00007d3d957d0271  movaps xmm10, xmm11
00007d3d957d0275  mulpd xmm10, xmm15
00007d3d957d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007d3d957d0280  ptest xmm6, xmm6
00007d3d957d0285  jnz 0x00007D3D957D501C
00007d3d957d028b  movaps [r15+0x220], xmm10
00007d3d957d0293  vmovaps xmm15, [rsp+0x70]
00007d3d957d0299  vpermilpd xmm15, xmm15, 0x00
00007d3d957d029f  movaps xmm11, xmm12
00007d3d957d02a3  mulpd xmm11, xmm15
00007d3d957d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007d3d957d02ae  ptest xmm6, xmm6
00007d3d957d02b3  jnz 0x00007D3D957D5160
00007d3d957d02b9  movaps xmm15, xmm13
00007d3d957d02bd  addpd xmm15, xmm9
00007d3d957d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007d3d957d02c8  ptest xmm12, xmm12
00007d3d957d02ce  jnz 0x00007D3D957D52A4
00007d3d957d02d4  movaps [r15+0x140], xmm15
00007d3d957d02dc  movaps xmm13, xmm8
00007d3d957d02e0  addpd xmm13, xmm14
00007d3d957d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007d3d957d02eb  ptest xmm12, xmm12
00007d3d957d02f1  jnz 0x00007D3D957D53E8
00007d3d957d02f7  movaps [r15+0x150], xmm13
00007d3d957d02ff  movaps xmm14, xmm1
00007d3d957d0303  addpd xmm14, xmm10
00007d3d957d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007d3d957d030e  ptest xmm12, xmm12
00007d3d957d0314  jnz 0x00007D3D957D552C
00007d3d957d031a  movaps [r15+0x160], xmm14
00007d3d957d0322  movaps xmm1, xmm7
00007d3d957d0325  addpd xmm1, xmm11
00007d3d957d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007d3d957d032f  ptest xmm12, xmm12
00007d3d957d0335  jnz 0x00007D3D957D566F
00007d3d957d033b  movaps [r15+0x120], xmm1
00007d3d957d0343  mov eax, 0x430920
00007d3d957d0348  movups [r13+rax*1], xmm15
00007d3d957d034e  mov eax, 0x430930
00007d3d957d0353  movups [r13+rax*1], xmm13
00007d3d957d0359  mov eax, 0x430940
00007d3d957d035e  movups [r13+rax*1], xmm14
00007d3d957d0364  mov eax, 0x430950
00007d3d957d0369  movups [r13+rax*1], xmm1
00007d3d957d036f  mov eax, [r15+0x108]
00007d3d957d0376  sahf
00007d3d957d0377  jnz 0x00007D3D957D03A9
00007d3d957d0379  cmp dword ptr [r15+0x318], 0x00
00007d3d957d0381  jz 0x00007D3D957DB900
00007d3d957d0387  nop [rax+rax*1], ax
00007d3d957d0390  nop [rax+rax*1], eax
00007d3d957d0398  mov eax, 0x410444
00007d3d957d039d  mov [r15+0x100], rax
00007d3d957d03a4  jmp 0x00007D3D955FE110
00007d3d957d03a9  cmp dword ptr [r15+0x318], 0x00
00007d3d957d03b1  jz 0x00007D3D957D57E0
00007d3d957d03b7  nop [rax+rax*1], ax
00007d3d957d03c0  nop [rax+rax*1], eax
00007d3d957d03c8  mov eax, 0x410278
00007d3d957d03cd  mov [r15+0x100], rax
00007d3d957d03d4  jmp 0x00007D3D955FE110
00007d3d957d03d9  int3
00007d3d957d03da  call 0x00007D3D956B52F0
00007d3d957d03df  jmp 0x00007D3D957CF016
00007d3d957d03e4  call 0x00007D3D956C4620
00007d3d957d03e9  jmp 0x00007D3D957CF023
00007d3d957d03ee  call 0x00007D3D956C33A0
00007d3d957d03f3  jmp 0x00007D3D957CF035
00007d3d957d03f8  call 0x00007D3D956C2120
00007d3d957d03fd  jmp 0x00007D3D957CF03F
00007d3d957d0402  call 0x00007D3D956C0860
00007d3d957d0407  jmp 0x00007D3D957CF067
00007d3d957d040c  call 0x00007D3D956BF5F0
00007d3d957d0411  jmp 0x00007D3D957CF073
00007d3d957d0416  call 0x00007D3D956C0860
00007d3d957d041b  jmp 0x00007D3D957CF0A5
00007d3d957d0420  call 0x00007D3D956BF5F0
00007d3d957d0425  jmp 0x00007D3D957CF0B1
00007d3d957d042a  call 0x00007D3D956C4740
00007d3d957d042f  jmp 0x00007D3D957CF0BE
00007d3d957d0434  call 0x00007D3D956B5400
00007d3d957d0439  jmp 0x00007D3D957CF0CB
00007d3d957d043e  call 0x00007D3D956B52F0
00007d3d957d0443  jmp 0x00007D3D957CF0D8
00007d3d957d0448  call 0x00007D3D956C4620
00007d3d957d044d  jmp 0x00007D3D957CF0E5
00007d3d957d0452  call 0x00007D3D956C0860
00007d3d957d0457  jmp 0x00007D3D957CF10D
00007d3d957d045c  call 0x00007D3D956BF5F0
00007d3d957d0461  jmp 0x00007D3D957CF119
00007d3d957d0466  call 0x00007D3D95609D70
00007d3d957d046b  jmp 0x00007D3D957CF11F
00007d3d957d0470  call 0x00007D3D956BE9C0
00007d3d957d0475  jmp 0x00007D3D957CF129
00007d3d957d047a  call 0x00007D3D956C0860
00007d3d957d047f  jmp 0x00007D3D957CF151
00007d3d957d0484  call 0x00007D3D956BF5F0
00007d3d957d0489  jmp 0x00007D3D957CF15D
00007d3d957d048e  call 0x00007D3D956BD750
00007d3d957d0493  jmp 0x00007D3D957CF16A
00007d3d957d0498  call 0x00007D3D956BC4E0
00007d3d957d049d  jmp 0x00007D3D957CF177
00007d3d957d04a2  call 0x00007D3D956C4740
00007d3d957d04a7  jmp 0x00007D3D957CF184
00007d3d957d04ac  call 0x00007D3D956B5400
00007d3d957d04b1  jmp 0x00007D3D957CF191
00007d3d957d04b6  call 0x00007D3D956B52F0
00007d3d957d04bb  jmp 0x00007D3D957CF19E
00007d3d957d04c0  call 0x00007D3D956C4620
00007d3d957d04c5  jmp 0x00007D3D957CF1AB
00007d3d957d04ca  call 0x00007D3D956C0860
00007d3d957d04cf  jmp 0x00007D3D957CF1BE
00007d3d957d04d4  call 0x00007D3D956BB270
00007d3d957d04d9  jmp 0x00007D3D957CF1CB
00007d3d957d04de  call 0x00007D3D956BA000
00007d3d957d04e3  jmp 0x00007D3D957CF1D8
00007d3d957d04e8  call 0x00007D3D956B8D90
00007d3d957d04ed  jmp 0x00007D3D957CF1E5
00007d3d957d04f2  call 0x00007D3D956B8A20
00007d3d957d04f7  jmp 0x00007D3D957CF1F2
00007d3d957d04fc  call 0x00007D3D956B5400
00007d3d957d0501  jmp 0x00007D3D957CF1FC
00007d3d957d0506  call 0x00007D3D956C2240
00007d3d957d050b  jmp 0x00007D3D957CF206
00007d3d957d0510  call 0x00007D3D956B52F0
00007d3d957d0515  jmp 0x00007D3D957CF210
00007d3d957d051a  call 0x00007D3D956C2120
00007d3d957d051f  jmp 0x00007D3D957CF21A
00007d3d957d0524  call 0x00007D3D956B77B0
00007d3d957d0529  jmp 0x00007D3D957CF224
00007d3d957d052e  call 0x00007D3D956B6550
00007d3d957d0533  jmp 0x00007D3D957CF22E
00007d3d957d0538  call 0x00007D3D956BFD50
00007d3d957d053d  jmp 0x00007D3D957CF240
00007d3d957d0542  call 0x00007D3D956B8EA0
00007d3d957d0547  jmp 0x00007D3D957CF24A
00007d3d957d054c  call 0x00007D3D956BFC30
00007d3d957d0551  jmp 0x00007D3D957CF257
00007d3d957d0556  call 0x00007D3D956B8D90
00007d3d957d055b  jmp 0x00007D3D957CF264
00007d3d957d0560  call 0x00007D3D956C2240
00007d3d957d0565  jmp 0x00007D3D957CF271
00007d3d957d056a  call 0x00007D3D956B5400
00007d3d957d056f  jmp 0x00007D3D957CF27E
00007d3d957d0574  call 0x00007D3D956B52F0
00007d3d957d0579  jmp 0x00007D3D957CF28B
00007d3d957d057e  call 0x00007D3D956C2120
00007d3d957d0583  jmp 0x00007D3D957CF298
00007d3d957d0588  call 0x00007D3D956B52F0
00007d3d957d058d  jmp 0x00007D3D957CF2AB
00007d3d957d0592  call 0x00007D3D956B52F0
00007d3d957d0597  jmp 0x00007D3D957CF2BE
00007d3d957d059c  call 0x00007D3D956B52F0
00007d3d957d05a1  jmp 0x00007D3D957CF2D1
00007d3d957d05a6  call 0x00007D3D956B52F0
00007d3d957d05ab  jmp 0x00007D3D957CF2E4
00007d3d957d05b0  call 0x00007D3D956C2240
00007d3d957d05b5  jmp 0x00007D3D957CF2F9
00007d3d957d05ba  call 0x00007D3D956C2240
00007d3d957d05bf  jmp 0x00007D3D957CF30C
00007d3d957d05c4  call 0x00007D3D956C2120
00007d3d957d05c9  jmp 0x00007D3D957CF319
00007d3d957d05ce  call 0x00007D3D956B52F0
00007d3d957d05d3  jmp 0x00007D3D957CF32C
00007d3d957d05d8  call 0x00007D3D956B52F0
00007d3d957d05dd  jmp 0x00007D3D957CF34F
00007d3d957d05e2  call 0x00007D3D956B52F0
00007d3d957d05e7  jmp 0x00007D3D957CF362
00007d3d957d05ec  call 0x00007D3D955FF540
00007d3d957d05f1  jmp 0x00007D3D957CF380
00007d3d957d05f6  call 0x00007D3D95608C20
00007d3d957d05fb  jmp 0x00007D3D957CF38A
00007d3d957d0600  call 0x00007D3D956D6600
00007d3d957d0605  jmp 0x00007D3D957CF396
00007d3d957d060a  call 0x00007D3D955FF540
00007d3d957d060f  jmp 0x00007D3D957CF3A6
00007d3d957d0614  call 0x00007D3D956C0370
00007d3d957d0619  jmp 0x00007D3D957CF3D4
00007d3d957d061e  call 0x00007D3D956BF100
00007d3d957d0623  jmp 0x00007D3D957CF3DD
00007d3d957d0628  call 0x00007D3D956C0370
00007d3d957d062d  jmp 0x00007D3D957CF43B
00007d3d957d0632  call 0x00007D3D956BF100
00007d3d957d0637  jmp 0x00007D3D957CF444
00007d3d957d063c  call 0x00007D3D956C0370
00007d3d957d0641  jmp 0x00007D3D957CF48B
00007d3d957d0646  call 0x00007D3D956BF100
00007d3d957d064b  jmp 0x00007D3D957CF494
00007d3d957d0650  call 0x00007D3D9560B720
00007d3d957d0655  jmp 0x00007D3D957CF4D7
00007d3d957d065a  call 0x00007D3D956B47C0
00007d3d957d065f  jmp 0x00007D3D957CF4EA
00007d3d957d0664  call 0x00007D3D95608B00
00007d3d957d0669  jmp 0x00007D3D957CF501
00007d3d957d066e  call 0x00007D3D955FF430
00007d3d957d0673  jmp 0x00007D3D957CF514
00007d3d957d0678  call 0x00007D3D955FF430
00007d3d957d067d  jmp 0x00007D3D957CF527
00007d3d957d0682  sub rsp, 0x08
00007d3d957d0686  push rax
00007d3d957d0687  push rcx
00007d3d957d0688  push rdx
00007d3d957d0689  push rdi
00007d3d957d068a  push rsi
00007d3d957d068b  push r8
00007d3d957d068d  push r9
00007d3d957d068f  push r10
00007d3d957d0691  push r11
00007d3d957d0693  sub rsp, 0xF0
00007d3d957d069a  vmovaps [rsp], xmm0
00007d3d957d069f  vmovaps [rsp+0x10], xmm2
00007d3d957d06a5  vmovaps [rsp+0x20], xmm3
00007d3d957d06ab  vmovaps [rsp+0x30], xmm4
00007d3d957d06b1  vmovaps [rsp+0x40], xmm5
00007d3d957d06b7  vmovaps [rsp+0x50], xmm6
00007d3d957d06bd  vmovaps [rsp+0x60], xmm7
00007d3d957d06c3  vmovaps [rsp+0x70], xmm8
00007d3d957d06c9  vmovaps [rsp+0x80], xmm9
00007d3d957d06d2  vmovaps [rsp+0x90], xmm10
00007d3d957d06db  vmovaps [rsp+0xA0], xmm11
00007d3d957d06e4  vmovaps [rsp+0xB0], xmm12
00007d3d957d06ed  vmovaps [rsp+0xC0], xmm13
00007d3d957d06f6  vmovaps [rsp+0xD0], xmm14
00007d3d957d06ff  vmovaps [rsp+0xE0], xmm15
00007d3d957d0708  sub rsp, 0x30
00007d3d957d070c  movaps [rsp], xmm1
00007d3d957d0710  movaps [rsp+0x10], xmm15
00007d3d957d0716  movaps [rsp+0x20], xmm14
00007d3d957d071c  lea rdi, [rsp]
00007d3d957d0720  mov esi, 0x00
00007d3d957d0725  mov rax, 0x56C27CB8A530
00007d3d957d072f  call rax
00007d3d957d0731  movaps xmm1, [rsp]
00007d3d957d0735  add rsp, 0x30
00007d3d957d0739  vmovaps xmm0, [rsp]
00007d3d957d073e  vmovaps xmm2, [rsp+0x10]
00007d3d957d0744  vmovaps xmm3, [rsp+0x20]
00007d3d957d074a  vmovaps xmm4, [rsp+0x30]
00007d3d957d0750  vmovaps xmm5, [rsp+0x40]
00007d3d957d0756  vmovaps xmm6, [rsp+0x50]
00007d3d957d075c  vmovaps xmm7, [rsp+0x60]
00007d3d957d0762  vmovaps xmm8, [rsp+0x70]
00007d3d957d0768  vmovaps xmm9, [rsp+0x80]
00007d3d957d0771  vmovaps xmm10, [rsp+0x90]
00007d3d957d077a  vmovaps xmm11, [rsp+0xA0]
00007d3d957d0783  vmovaps xmm12, [rsp+0xB0]
00007d3d957d078c  vmovaps xmm13, [rsp+0xC0]
00007d3d957d0795  vmovaps xmm14, [rsp+0xD0]
00007d3d957d079e  vmovaps xmm15, [rsp+0xE0]
00007d3d957d07a7  add rsp, 0xF0
00007d3d957d07ae  pop r11
00007d3d957d07b0  pop r10
00007d3d957d07b2  pop r9
00007d3d957d07b4  pop r8
00007d3d957d07b6  pop rsi
00007d3d957d07b7  pop rdi
00007d3d957d07b8  pop rdx
00007d3d957d07b9  pop rcx
00007d3d957d07ba  pop rax
00007d3d957d07bb  add rsp, 0x08
00007d3d957d07bf  jmp 0x00007D3D957CF581
00007d3d957d07c4  sub rsp, 0x08
00007d3d957d07c8  push rax
00007d3d957d07c9  push rcx
00007d3d957d07ca  push rdx
00007d3d957d07cb  push rdi
00007d3d957d07cc  push rsi
00007d3d957d07cd  push r8
00007d3d957d07cf  push r9
00007d3d957d07d1  push r10
00007d3d957d07d3  push r11
00007d3d957d07d5  sub rsp, 0xF0
00007d3d957d07dc  vmovaps [rsp], xmm0
00007d3d957d07e1  vmovaps [rsp+0x10], xmm1
00007d3d957d07e7  vmovaps [rsp+0x20], xmm2
00007d3d957d07ed  vmovaps [rsp+0x30], xmm3
00007d3d957d07f3  vmovaps [rsp+0x40], xmm4
00007d3d957d07f9  vmovaps [rsp+0x50], xmm5
00007d3d957d07ff  vmovaps [rsp+0x60], xmm6
00007d3d957d0805  vmovaps [rsp+0x70], xmm7
00007d3d957d080b  vmovaps [rsp+0x80], xmm8
00007d3d957d0814  vmovaps [rsp+0x90], xmm9
00007d3d957d081d  vmovaps [rsp+0xA0], xmm10
00007d3d957d0826  vmovaps [rsp+0xB0], xmm11
00007d3d957d082f  vmovaps [rsp+0xC0], xmm12
00007d3d957d0838  vmovaps [rsp+0xD0], xmm14
00007d3d957d0841  vmovaps [rsp+0xE0], xmm15
00007d3d957d084a  sub rsp, 0x30
00007d3d957d084e  movaps [rsp], xmm13
00007d3d957d0853  movaps [rsp+0x10], xmm1
00007d3d957d0858  movaps [rsp+0x20], xmm14
00007d3d957d085e  lea rdi, [rsp]
00007d3d957d0862  mov esi, 0x00
00007d3d957d0867  mov rax, 0x56C27CB8A530
00007d3d957d0871  call rax
00007d3d957d0873  movaps xmm13, [rsp]
00007d3d957d0878  add rsp, 0x30
00007d3d957d087c  vmovaps xmm0, [rsp]
00007d3d957d0881  vmovaps xmm1, [rsp+0x10]
00007d3d957d0887  vmovaps xmm2, [rsp+0x20]
00007d3d957d088d  vmovaps xmm3, [rsp+0x30]
00007d3d957d0893  vmovaps xmm4, [rsp+0x40]
00007d3d957d0899  vmovaps xmm5, [rsp+0x50]
00007d3d957d089f  vmovaps xmm6, [rsp+0x60]
00007d3d957d08a5  vmovaps xmm7, [rsp+0x70]
00007d3d957d08ab  vmovaps xmm8, [rsp+0x80]
00007d3d957d08b4  vmovaps xmm9, [rsp+0x90]
00007d3d957d08bd  vmovaps xmm10, [rsp+0xA0]
00007d3d957d08c6  vmovaps xmm11, [rsp+0xB0]
00007d3d957d08cf  vmovaps xmm12, [rsp+0xC0]
00007d3d957d08d8  vmovaps xmm14, [rsp+0xD0]
00007d3d957d08e1  vmovaps xmm15, [rsp+0xE0]
00007d3d957d08ea  add rsp, 0xF0
00007d3d957d08f1  pop r11
00007d3d957d08f3  pop r10
00007d3d957d08f5  pop r9
00007d3d957d08f7  pop r8
00007d3d957d08f9  pop rsi
00007d3d957d08fa  pop rdi
00007d3d957d08fb  pop rdx
00007d3d957d08fc  pop rcx
00007d3d957d08fd  pop rax
00007d3d957d08fe  add rsp, 0x08
00007d3d957d0902  jmp 0x00007D3D957CF5CF
00007d3d957d0907  sub rsp, 0x08
00007d3d957d090b  push rax
00007d3d957d090c  push rcx
00007d3d957d090d  push rdx
00007d3d957d090e  push rdi
00007d3d957d090f  push rsi
00007d3d957d0910  push r8
00007d3d957d0912  push r9
00007d3d957d0914  push r10
00007d3d957d0916  push r11
00007d3d957d0918  sub rsp, 0xF0
00007d3d957d091f  vmovaps [rsp], xmm0
00007d3d957d0924  vmovaps [rsp+0x10], xmm1
00007d3d957d092a  vmovaps [rsp+0x20], xmm2
00007d3d957d0930  vmovaps [rsp+0x30], xmm3
00007d3d957d0936  vmovaps [rsp+0x40], xmm4
00007d3d957d093c  vmovaps [rsp+0x50], xmm5
00007d3d957d0942  vmovaps [rsp+0x60], xmm6
00007d3d957d0948  vmovaps [rsp+0x70], xmm7
00007d3d957d094e  vmovaps [rsp+0x80], xmm8
00007d3d957d0957  vmovaps [rsp+0x90], xmm9
00007d3d957d0960  vmovaps [rsp+0xA0], xmm10
00007d3d957d0969  vmovaps [rsp+0xB0], xmm11
00007d3d957d0972  vmovaps [rsp+0xC0], xmm12
00007d3d957d097b  vmovaps [rsp+0xD0], xmm13
00007d3d957d0984  vmovaps [rsp+0xE0], xmm14
00007d3d957d098d  sub rsp, 0x30
00007d3d957d0991  movaps [rsp], xmm15
00007d3d957d0996  movaps [rsp+0x10], xmm14
00007d3d957d099c  movaps [rsp+0x20], xmm1
00007d3d957d09a1  lea rdi, [rsp]
00007d3d957d09a5  mov esi, 0x00
00007d3d957d09aa  mov rax, 0x56C27CB8A530
00007d3d957d09b4  call rax
00007d3d957d09b6  movaps xmm15, [rsp]
00007d3d957d09bb  add rsp, 0x30
00007d3d957d09bf  vmovaps xmm0, [rsp]
00007d3d957d09c4  vmovaps xmm1, [rsp+0x10]
00007d3d957d09ca  vmovaps xmm2, [rsp+0x20]
00007d3d957d09d0  vmovaps xmm3, [rsp+0x30]
00007d3d957d09d6  vmovaps xmm4, [rsp+0x40]
00007d3d957d09dc  vmovaps xmm5, [rsp+0x50]
00007d3d957d09e2  vmovaps xmm6, [rsp+0x60]
00007d3d957d09e8  vmovaps xmm7, [rsp+0x70]
00007d3d957d09ee  vmovaps xmm8, [rsp+0x80]
00007d3d957d09f7  vmovaps xmm9, [rsp+0x90]
00007d3d957d0a00  vmovaps xmm10, [rsp+0xA0]
00007d3d957d0a09  vmovaps xmm11, [rsp+0xB0]
00007d3d957d0a12  vmovaps xmm12, [rsp+0xC0]
00007d3d957d0a1b  vmovaps xmm13, [rsp+0xD0]
00007d3d957d0a24  vmovaps xmm14, [rsp+0xE0]
00007d3d957d0a2d  add rsp, 0xF0
00007d3d957d0a34  pop r11
00007d3d957d0a36  pop r10
00007d3d957d0a38  pop r9
00007d3d957d0a3a  pop r8
00007d3d957d0a3c  pop rsi
00007d3d957d0a3d  pop rdi
00007d3d957d0a3e  pop rdx
00007d3d957d0a3f  pop rcx
00007d3d957d0a40  pop rax
00007d3d957d0a41  add rsp, 0x08
00007d3d957d0a45  jmp 0x00007D3D957CF617
00007d3d957d0a4a  sub rsp, 0x08
00007d3d957d0a4e  push rax
00007d3d957d0a4f  push rcx
00007d3d957d0a50  push rdx
00007d3d957d0a51  push rdi
00007d3d957d0a52  push rsi
00007d3d957d0a53  push r8
00007d3d957d0a55  push r9
00007d3d957d0a57  push r10
00007d3d957d0a59  push r11
00007d3d957d0a5b  sub rsp, 0xF0
00007d3d957d0a62  vmovaps [rsp], xmm0
00007d3d957d0a67  vmovaps [rsp+0x10], xmm2
00007d3d957d0a6d  vmovaps [rsp+0x20], xmm3
00007d3d957d0a73  vmovaps [rsp+0x30], xmm4
00007d3d957d0a79  vmovaps [rsp+0x40], xmm5
00007d3d957d0a7f  vmovaps [rsp+0x50], xmm6
00007d3d957d0a85  vmovaps [rsp+0x60], xmm7
00007d3d957d0a8b  vmovaps [rsp+0x70], xmm8
00007d3d957d0a91  vmovaps [rsp+0x80], xmm9
00007d3d957d0a9a  vmovaps [rsp+0x90], xmm10
00007d3d957d0aa3  vmovaps [rsp+0xA0], xmm11
00007d3d957d0aac  vmovaps [rsp+0xB0], xmm12
00007d3d957d0ab5  vmovaps [rsp+0xC0], xmm13
00007d3d957d0abe  vmovaps [rsp+0xD0], xmm14
00007d3d957d0ac7  vmovaps [rsp+0xE0], xmm15
00007d3d957d0ad0  sub rsp, 0x30
00007d3d957d0ad4  movaps [rsp], xmm1
00007d3d957d0ad8  movaps [rsp+0x10], xmm14
00007d3d957d0ade  movaps [rsp+0x20], xmm10
00007d3d957d0ae4  lea rdi, [rsp]
00007d3d957d0ae8  mov esi, 0x00
00007d3d957d0aed  mov rax, 0x56C27CB8A530
00007d3d957d0af7  call rax
00007d3d957d0af9  movaps xmm1, [rsp]
00007d3d957d0afd  add rsp, 0x30
00007d3d957d0b01  vmovaps xmm0, [rsp]
00007d3d957d0b06  vmovaps xmm2, [rsp+0x10]
00007d3d957d0b0c  vmovaps xmm3, [rsp+0x20]
00007d3d957d0b12  vmovaps xmm4, [rsp+0x30]
00007d3d957d0b18  vmovaps xmm5, [rsp+0x40]
00007d3d957d0b1e  vmovaps xmm6, [rsp+0x50]
00007d3d957d0b24  vmovaps xmm7, [rsp+0x60]
00007d3d957d0b2a  vmovaps xmm8, [rsp+0x70]
00007d3d957d0b30  vmovaps xmm9, [rsp+0x80]
00007d3d957d0b39  vmovaps xmm10, [rsp+0x90]
00007d3d957d0b42  vmovaps xmm11, [rsp+0xA0]
00007d3d957d0b4b  vmovaps xmm12, [rsp+0xB0]
00007d3d957d0b54  vmovaps xmm13, [rsp+0xC0]
00007d3d957d0b5d  vmovaps xmm14, [rsp+0xD0]
00007d3d957d0b66  vmovaps xmm15, [rsp+0xE0]
00007d3d957d0b6f  add rsp, 0xF0
00007d3d957d0b76  pop r11
00007d3d957d0b78  pop r10
00007d3d957d0b7a  pop r9
00007d3d957d0b7c  pop r8
00007d3d957d0b7e  pop rsi
00007d3d957d0b7f  pop rdi
00007d3d957d0b80  pop rdx
00007d3d957d0b81  pop rcx
00007d3d957d0b82  pop rax
00007d3d957d0b83  add rsp, 0x08
00007d3d957d0b87  jmp 0x00007D3D957CF631
00007d3d957d0b8c  sub rsp, 0x08
00007d3d957d0b90  push rax
00007d3d957d0b91  push rcx
00007d3d957d0b92  push rdx
00007d3d957d0b93  push rdi
00007d3d957d0b94  push rsi
00007d3d957d0b95  push r8
00007d3d957d0b97  push r9
00007d3d957d0b99  push r10
00007d3d957d0b9b  push r11
00007d3d957d0b9d  sub rsp, 0xF0
00007d3d957d0ba4  vmovaps [rsp], xmm0
00007d3d957d0ba9  vmovaps [rsp+0x10], xmm1
00007d3d957d0baf  vmovaps [rsp+0x20], xmm2
00007d3d957d0bb5  vmovaps [rsp+0x30], xmm3
00007d3d957d0bbb  vmovaps [rsp+0x40], xmm4
00007d3d957d0bc1  vmovaps [rsp+0x50], xmm5
00007d3d957d0bc7  vmovaps [rsp+0x60], xmm6
00007d3d957d0bcd  vmovaps [rsp+0x70], xmm7
00007d3d957d0bd3  vmovaps [rsp+0x80], xmm8
00007d3d957d0bdc  vmovaps [rsp+0x90], xmm9
00007d3d957d0be5  vmovaps [rsp+0xA0], xmm10
00007d3d957d0bee  vmovaps [rsp+0xB0], xmm11
00007d3d957d0bf7  vmovaps [rsp+0xC0], xmm12
00007d3d957d0c00  vmovaps [rsp+0xD0], xmm14
00007d3d957d0c09  vmovaps [rsp+0xE0], xmm15
00007d3d957d0c12  sub rsp, 0x30
00007d3d957d0c16  movaps [rsp], xmm13
00007d3d957d0c1b  movaps [rsp+0x10], xmm14
00007d3d957d0c21  movaps [rsp+0x20], xmm2
00007d3d957d0c26  lea rdi, [rsp]
00007d3d957d0c2a  mov esi, 0x00
00007d3d957d0c2f  mov rax, 0x56C27CB8A530
00007d3d957d0c39  call rax
00007d3d957d0c3b  movaps xmm13, [rsp]
00007d3d957d0c40  add rsp, 0x30
00007d3d957d0c44  vmovaps xmm0, [rsp]
00007d3d957d0c49  vmovaps xmm1, [rsp+0x10]
00007d3d957d0c4f  vmovaps xmm2, [rsp+0x20]
00007d3d957d0c55  vmovaps xmm3, [rsp+0x30]
00007d3d957d0c5b  vmovaps xmm4, [rsp+0x40]
00007d3d957d0c61  vmovaps xmm5, [rsp+0x50]
00007d3d957d0c67  vmovaps xmm6, [rsp+0x60]
00007d3d957d0c6d  vmovaps xmm7, [rsp+0x70]
00007d3d957d0c73  vmovaps xmm8, [rsp+0x80]
00007d3d957d0c7c  vmovaps xmm9, [rsp+0x90]
00007d3d957d0c85  vmovaps xmm10, [rsp+0xA0]
00007d3d957d0c8e  vmovaps xmm11, [rsp+0xB0]
00007d3d957d0c97  vmovaps xmm12, [rsp+0xC0]
00007d3d957d0ca0  vmovaps xmm14, [rsp+0xD0]
00007d3d957d0ca9  vmovaps xmm15, [rsp+0xE0]
00007d3d957d0cb2  add rsp, 0xF0
00007d3d957d0cb9  pop r11
00007d3d957d0cbb  pop r10
00007d3d957d0cbd  pop r9
00007d3d957d0cbf  pop r8
00007d3d957d0cc1  pop rsi
00007d3d957d0cc2  pop rdi
00007d3d957d0cc3  pop rdx
00007d3d957d0cc4  pop rcx
00007d3d957d0cc5  pop rax
00007d3d957d0cc6  add rsp, 0x08
00007d3d957d0cca  jmp 0x00007D3D957CF64C
00007d3d957d0ccf  sub rsp, 0x08
00007d3d957d0cd3  push rax
00007d3d957d0cd4  push rcx
00007d3d957d0cd5  push rdx
00007d3d957d0cd6  push rdi
00007d3d957d0cd7  push rsi
00007d3d957d0cd8  push r8
00007d3d957d0cda  push r9
00007d3d957d0cdc  push r10
00007d3d957d0cde  push r11
00007d3d957d0ce0  sub rsp, 0xF0
00007d3d957d0ce7  vmovaps [rsp], xmm0
00007d3d957d0cec  vmovaps [rsp+0x10], xmm2
00007d3d957d0cf2  vmovaps [rsp+0x20], xmm3
00007d3d957d0cf8  vmovaps [rsp+0x30], xmm4
00007d3d957d0cfe  vmovaps [rsp+0x40], xmm5
00007d3d957d0d04  vmovaps [rsp+0x50], xmm6
00007d3d957d0d0a  vmovaps [rsp+0x60], xmm7
00007d3d957d0d10  vmovaps [rsp+0x70], xmm8
00007d3d957d0d16  vmovaps [rsp+0x80], xmm9
00007d3d957d0d1f  vmovaps [rsp+0x90], xmm10
00007d3d957d0d28  vmovaps [rsp+0xA0], xmm11
00007d3d957d0d31  vmovaps [rsp+0xB0], xmm12
00007d3d957d0d3a  vmovaps [rsp+0xC0], xmm13
00007d3d957d0d43  vmovaps [rsp+0xD0], xmm14
00007d3d957d0d4c  vmovaps [rsp+0xE0], xmm15
00007d3d957d0d55  sub rsp, 0x30
00007d3d957d0d59  movaps [rsp], xmm1
00007d3d957d0d5d  movaps [rsp+0x10], xmm10
00007d3d957d0d63  movaps [rsp+0x20], xmm2
00007d3d957d0d68  lea rdi, [rsp]
00007d3d957d0d6c  mov esi, 0x00
00007d3d957d0d71  mov rax, 0x56C27CB8A530
00007d3d957d0d7b  call rax
00007d3d957d0d7d  movaps xmm1, [rsp]
00007d3d957d0d81  add rsp, 0x30
00007d3d957d0d85  vmovaps xmm0, [rsp]
00007d3d957d0d8a  vmovaps xmm2, [rsp+0x10]
00007d3d957d0d90  vmovaps xmm3, [rsp+0x20]
00007d3d957d0d96  vmovaps xmm4, [rsp+0x30]
00007d3d957d0d9c  vmovaps xmm5, [rsp+0x40]
00007d3d957d0da2  vmovaps xmm6, [rsp+0x50]
00007d3d957d0da8  vmovaps xmm7, [rsp+0x60]
00007d3d957d0dae  vmovaps xmm8, [rsp+0x70]
00007d3d957d0db4  vmovaps xmm9, [rsp+0x80]
00007d3d957d0dbd  vmovaps xmm10, [rsp+0x90]
00007d3d957d0dc6  vmovaps xmm11, [rsp+0xA0]
00007d3d957d0dcf  vmovaps xmm12, [rsp+0xB0]
00007d3d957d0dd8  vmovaps xmm13, [rsp+0xC0]
00007d3d957d0de1  vmovaps xmm14, [rsp+0xD0]
00007d3d957d0dea  vmovaps xmm15, [rsp+0xE0]
00007d3d957d0df3  add rsp, 0xF0
00007d3d957d0dfa  pop r11
00007d3d957d0dfc  pop r10
00007d3d957d0dfe  pop r9
00007d3d957d0e00  pop r8
00007d3d957d0e02  pop rsi
00007d3d957d0e03  pop rdi
00007d3d957d0e04  pop rdx
00007d3d957d0e05  pop rcx
00007d3d957d0e06  pop rax
00007d3d957d0e07  add rsp, 0x08
00007d3d957d0e0b  jmp 0x00007D3D957CF6B4
00007d3d957d0e10  sub rsp, 0x08
00007d3d957d0e14  push rax
00007d3d957d0e15  push rcx
00007d3d957d0e16  push rdx
00007d3d957d0e17  push rdi
00007d3d957d0e18  push rsi
00007d3d957d0e19  push r8
00007d3d957d0e1b  push r9
00007d3d957d0e1d  push r10
00007d3d957d0e1f  push r11
00007d3d957d0e21  sub rsp, 0xF0
00007d3d957d0e28  vmovaps [rsp], xmm0
00007d3d957d0e2d  vmovaps [rsp+0x10], xmm1
00007d3d957d0e33  vmovaps [rsp+0x20], xmm2
00007d3d957d0e39  vmovaps [rsp+0x30], xmm3
00007d3d957d0e3f  vmovaps [rsp+0x40], xmm4
00007d3d957d0e45  vmovaps [rsp+0x50], xmm5
00007d3d957d0e4b  vmovaps [rsp+0x60], xmm6
00007d3d957d0e51  vmovaps [rsp+0x70], xmm7
00007d3d957d0e57  vmovaps [rsp+0x80], xmm8
00007d3d957d0e60  vmovaps [rsp+0x90], xmm9
00007d3d957d0e69  vmovaps [rsp+0xA0], xmm10
00007d3d957d0e72  vmovaps [rsp+0xB0], xmm11
00007d3d957d0e7b  vmovaps [rsp+0xC0], xmm12
00007d3d957d0e84  vmovaps [rsp+0xD0], xmm13
00007d3d957d0e8d  vmovaps [rsp+0xE0], xmm14
00007d3d957d0e96  sub rsp, 0x30
00007d3d957d0e9a  movaps [rsp], xmm15
00007d3d957d0e9f  movaps [rsp+0x10], xmm10
00007d3d957d0ea5  movaps [rsp+0x20], xmm2
00007d3d957d0eaa  lea rdi, [rsp]
00007d3d957d0eae  mov esi, 0x00
00007d3d957d0eb3  mov rax, 0x56C27CB8A530
00007d3d957d0ebd  call rax
00007d3d957d0ebf  movaps xmm15, [rsp]
00007d3d957d0ec4  add rsp, 0x30
00007d3d957d0ec8  vmovaps xmm0, [rsp]
00007d3d957d0ecd  vmovaps xmm1, [rsp+0x10]
00007d3d957d0ed3  vmovaps xmm2, [rsp+0x20]
00007d3d957d0ed9  vmovaps xmm3, [rsp+0x30]
00007d3d957d0edf  vmovaps xmm4, [rsp+0x40]
00007d3d957d0ee5  vmovaps xmm5, [rsp+0x50]
00007d3d957d0eeb  vmovaps xmm6, [rsp+0x60]
00007d3d957d0ef1  vmovaps xmm7, [rsp+0x70]
00007d3d957d0ef7  vmovaps xmm8, [rsp+0x80]
00007d3d957d0f00  vmovaps xmm9, [rsp+0x90]
00007d3d957d0f09  vmovaps xmm10, [rsp+0xA0]
00007d3d957d0f12  vmovaps xmm11, [rsp+0xB0]
00007d3d957d0f1b  vmovaps xmm12, [rsp+0xC0]
00007d3d957d0f24  vmovaps xmm13, [rsp+0xD0]
00007d3d957d0f2d  vmovaps xmm14, [rsp+0xE0]
00007d3d957d0f36  add rsp, 0xF0
00007d3d957d0f3d  pop r11
00007d3d957d0f3f  pop r10
00007d3d957d0f41  pop r9
00007d3d957d0f43  pop r8
00007d3d957d0f45  pop rsi
00007d3d957d0f46  pop rdi
00007d3d957d0f47  pop rdx
00007d3d957d0f48  pop rcx
00007d3d957d0f49  pop rax
00007d3d957d0f4a  add rsp, 0x08
00007d3d957d0f4e  jmp 0x00007D3D957CF706
00007d3d957d0f53  sub rsp, 0x08
00007d3d957d0f57  push rax
00007d3d957d0f58  push rcx
00007d3d957d0f59  push rdx
00007d3d957d0f5a  push rdi
00007d3d957d0f5b  push rsi
00007d3d957d0f5c  push r8
00007d3d957d0f5e  push r9
00007d3d957d0f60  push r10
00007d3d957d0f62  push r11
00007d3d957d0f64  sub rsp, 0xF0
00007d3d957d0f6b  vmovaps [rsp], xmm0
00007d3d957d0f70  vmovaps [rsp+0x10], xmm2
00007d3d957d0f76  vmovaps [rsp+0x20], xmm3
00007d3d957d0f7c  vmovaps [rsp+0x30], xmm4
00007d3d957d0f82  vmovaps [rsp+0x40], xmm5
00007d3d957d0f88  vmovaps [rsp+0x50], xmm6
00007d3d957d0f8e  vmovaps [rsp+0x60], xmm7
00007d3d957d0f94  vmovaps [rsp+0x70], xmm8
00007d3d957d0f9a  vmovaps [rsp+0x80], xmm9
00007d3d957d0fa3  vmovaps [rsp+0x90], xmm10
00007d3d957d0fac  vmovaps [rsp+0xA0], xmm11
00007d3d957d0fb5  vmovaps [rsp+0xB0], xmm12
00007d3d957d0fbe  vmovaps [rsp+0xC0], xmm13
00007d3d957d0fc7  vmovaps [rsp+0xD0], xmm14
00007d3d957d0fd0  vmovaps [rsp+0xE0], xmm15
00007d3d957d0fd9  sub rsp, 0x30
00007d3d957d0fdd  movaps [rsp], xmm1
00007d3d957d0fe1  movaps [rsp+0x10], xmm10
00007d3d957d0fe7  movaps [rsp+0x20], xmm12
00007d3d957d0fed  lea rdi, [rsp]
00007d3d957d0ff1  mov esi, 0x00
00007d3d957d0ff6  mov rax, 0x56C27CB8A530
00007d3d957d1000  call rax
00007d3d957d1002  movaps xmm1, [rsp]
00007d3d957d1006  add rsp, 0x30
00007d3d957d100a  vmovaps xmm0, [rsp]
00007d3d957d100f  vmovaps xmm2, [rsp+0x10]
00007d3d957d1015  vmovaps xmm3, [rsp+0x20]
00007d3d957d101b  vmovaps xmm4, [rsp+0x30]
00007d3d957d1021  vmovaps xmm5, [rsp+0x40]
00007d3d957d1027  vmovaps xmm6, [rsp+0x50]
00007d3d957d102d  vmovaps xmm7, [rsp+0x60]
00007d3d957d1033  vmovaps xmm8, [rsp+0x70]
00007d3d957d1039  vmovaps xmm9, [rsp+0x80]
00007d3d957d1042  vmovaps xmm10, [rsp+0x90]
00007d3d957d104b  vmovaps xmm11, [rsp+0xA0]
00007d3d957d1054  vmovaps xmm12, [rsp+0xB0]
00007d3d957d105d  vmovaps xmm13, [rsp+0xC0]
00007d3d957d1066  vmovaps xmm14, [rsp+0xD0]
00007d3d957d106f  vmovaps xmm15, [rsp+0xE0]
00007d3d957d1078  add rsp, 0xF0
00007d3d957d107f  pop r11
00007d3d957d1081  pop r10
00007d3d957d1083  pop r9
00007d3d957d1085  pop r8
00007d3d957d1087  pop rsi
00007d3d957d1088  pop rdi
00007d3d957d1089  pop rdx
00007d3d957d108a  pop rcx
00007d3d957d108b  pop rax
00007d3d957d108c  add rsp, 0x08
00007d3d957d1090  jmp 0x00007D3D957CF732
00007d3d957d1095  sub rsp, 0x08
00007d3d957d1099  push rax
00007d3d957d109a  push rcx
00007d3d957d109b  push rdx
00007d3d957d109c  push rdi
00007d3d957d109d  push rsi
00007d3d957d109e  push r8
00007d3d957d10a0  push r9
00007d3d957d10a2  push r10
00007d3d957d10a4  push r11
00007d3d957d10a6  sub rsp, 0xF0
00007d3d957d10ad  vmovaps [rsp], xmm0
00007d3d957d10b2  vmovaps [rsp+0x10], xmm1
00007d3d957d10b8  vmovaps [rsp+0x20], xmm2
00007d3d957d10be  vmovaps [rsp+0x30], xmm3
00007d3d957d10c4  vmovaps [rsp+0x40], xmm4
00007d3d957d10ca  vmovaps [rsp+0x50], xmm5
00007d3d957d10d0  vmovaps [rsp+0x60], xmm6
00007d3d957d10d6  vmovaps [rsp+0x70], xmm7
00007d3d957d10dc  vmovaps [rsp+0x80], xmm8
00007d3d957d10e5  vmovaps [rsp+0x90], xmm9
00007d3d957d10ee  vmovaps [rsp+0xA0], xmm10
00007d3d957d10f7  vmovaps [rsp+0xB0], xmm11
00007d3d957d1100  vmovaps [rsp+0xC0], xmm12
00007d3d957d1109  vmovaps [rsp+0xD0], xmm13
00007d3d957d1112  vmovaps [rsp+0xE0], xmm14
00007d3d957d111b  sub rsp, 0x30
00007d3d957d111f  movaps [rsp], xmm15
00007d3d957d1124  movaps [rsp+0x10], xmm10
00007d3d957d112a  movaps [rsp+0x20], xmm12
00007d3d957d1130  lea rdi, [rsp]
00007d3d957d1134  mov esi, 0x00
00007d3d957d1139  mov rax, 0x56C27CB8A530
00007d3d957d1143  call rax
00007d3d957d1145  movaps xmm15, [rsp]
00007d3d957d114a  add rsp, 0x30
00007d3d957d114e  vmovaps xmm0, [rsp]
00007d3d957d1153  vmovaps xmm1, [rsp+0x10]
00007d3d957d1159  vmovaps xmm2, [rsp+0x20]
00007d3d957d115f  vmovaps xmm3, [rsp+0x30]
00007d3d957d1165  vmovaps xmm4, [rsp+0x40]
00007d3d957d116b  vmovaps xmm5, [rsp+0x50]
00007d3d957d1171  vmovaps xmm6, [rsp+0x60]
00007d3d957d1177  vmovaps xmm7, [rsp+0x70]
00007d3d957d117d  vmovaps xmm8, [rsp+0x80]
00007d3d957d1186  vmovaps xmm9, [rsp+0x90]
00007d3d957d118f  vmovaps xmm10, [rsp+0xA0]
00007d3d957d1198  vmovaps xmm11, [rsp+0xB0]
00007d3d957d11a1  vmovaps xmm12, [rsp+0xC0]
00007d3d957d11aa  vmovaps xmm13, [rsp+0xD0]
00007d3d957d11b3  vmovaps xmm14, [rsp+0xE0]
00007d3d957d11bc  add rsp, 0xF0
00007d3d957d11c3  pop r11
00007d3d957d11c5  pop r10
00007d3d957d11c7  pop r9
00007d3d957d11c9  pop r8
00007d3d957d11cb  pop rsi
00007d3d957d11cc  pop rdi
00007d3d957d11cd  pop rdx
00007d3d957d11ce  pop rcx
00007d3d957d11cf  pop rax
00007d3d957d11d0  add rsp, 0x08
00007d3d957d11d4  jmp 0x00007D3D957CF75E
00007d3d957d11d9  call 0x00007D3D955FF430
00007d3d957d11de  jmp 0x00007D3D957CF7EE
00007d3d957d11e3  call 0x00007D3D955FF430
00007d3d957d11e8  jmp 0x00007D3D957CF801
00007d3d957d11ed  sub rsp, 0x08
00007d3d957d11f1  push rax
00007d3d957d11f2  push rcx
00007d3d957d11f3  push rdx
00007d3d957d11f4  push rdi
00007d3d957d11f5  push rsi
00007d3d957d11f6  push r8
00007d3d957d11f8  push r9
00007d3d957d11fa  push r10
00007d3d957d11fc  push r11
00007d3d957d11fe  sub rsp, 0xF0
00007d3d957d1205  vmovaps [rsp], xmm0
00007d3d957d120a  vmovaps [rsp+0x10], xmm2
00007d3d957d1210  vmovaps [rsp+0x20], xmm3
00007d3d957d1216  vmovaps [rsp+0x30], xmm4
00007d3d957d121c  vmovaps [rsp+0x40], xmm5
00007d3d957d1222  vmovaps [rsp+0x50], xmm6
00007d3d957d1228  vmovaps [rsp+0x60], xmm7
00007d3d957d122e  vmovaps [rsp+0x70], xmm8
00007d3d957d1234  vmovaps [rsp+0x80], xmm9
00007d3d957d123d  vmovaps [rsp+0x90], xmm10
00007d3d957d1246  vmovaps [rsp+0xA0], xmm11
00007d3d957d124f  vmovaps [rsp+0xB0], xmm12
00007d3d957d1258  vmovaps [rsp+0xC0], xmm13
00007d3d957d1261  vmovaps [rsp+0xD0], xmm14
00007d3d957d126a  vmovaps [rsp+0xE0], xmm15
00007d3d957d1273  sub rsp, 0x30
00007d3d957d1277  movaps [rsp], xmm1
00007d3d957d127b  movaps [rsp+0x10], xmm13
00007d3d957d1281  movaps [rsp+0x20], xmm2
00007d3d957d1286  lea rdi, [rsp]
00007d3d957d128a  mov esi, 0x00
00007d3d957d128f  mov rax, 0x56C27CB8A530
00007d3d957d1299  call rax
00007d3d957d129b  movaps xmm1, [rsp]
00007d3d957d129f  add rsp, 0x30
00007d3d957d12a3  vmovaps xmm0, [rsp]
00007d3d957d12a8  vmovaps xmm2, [rsp+0x10]
00007d3d957d12ae  vmovaps xmm3, [rsp+0x20]
00007d3d957d12b4  vmovaps xmm4, [rsp+0x30]
00007d3d957d12ba  vmovaps xmm5, [rsp+0x40]
00007d3d957d12c0  vmovaps xmm6, [rsp+0x50]
00007d3d957d12c6  vmovaps xmm7, [rsp+0x60]
00007d3d957d12cc  vmovaps xmm8, [rsp+0x70]
00007d3d957d12d2  vmovaps xmm9, [rsp+0x80]
00007d3d957d12db  vmovaps xmm10, [rsp+0x90]
00007d3d957d12e4  vmovaps xmm11, [rsp+0xA0]
00007d3d957d12ed  vmovaps xmm12, [rsp+0xB0]
00007d3d957d12f6  vmovaps xmm13, [rsp+0xC0]
00007d3d957d12ff  vmovaps xmm14, [rsp+0xD0]
00007d3d957d1308  vmovaps xmm15, [rsp+0xE0]
00007d3d957d1311  add rsp, 0xF0
00007d3d957d1318  pop r11
00007d3d957d131a  pop r10
00007d3d957d131c  pop r9
00007d3d957d131e  pop r8
00007d3d957d1320  pop rsi
00007d3d957d1321  pop rdi
00007d3d957d1322  pop rdx
00007d3d957d1323  pop rcx
00007d3d957d1324  pop rax
00007d3d957d1325  add rsp, 0x08
00007d3d957d1329  jmp 0x00007D3D957CF82C
00007d3d957d132e  call 0x00007D3D9560E760
00007d3d957d1333  jmp 0x00007D3D957CF839
00007d3d957d1338  sub rsp, 0x08
00007d3d957d133c  push rax
00007d3d957d133d  push rcx
00007d3d957d133e  push rdx
00007d3d957d133f  push rdi
00007d3d957d1340  push rsi
00007d3d957d1341  push r8
00007d3d957d1343  push r9
00007d3d957d1345  push r10
00007d3d957d1347  push r11
00007d3d957d1349  sub rsp, 0xF0
00007d3d957d1350  vmovaps [rsp], xmm0
00007d3d957d1355  vmovaps [rsp+0x10], xmm1
00007d3d957d135b  vmovaps [rsp+0x20], xmm2
00007d3d957d1361  vmovaps [rsp+0x30], xmm3
00007d3d957d1367  vmovaps [rsp+0x40], xmm4
00007d3d957d136d  vmovaps [rsp+0x50], xmm5
00007d3d957d1373  vmovaps [rsp+0x60], xmm6
00007d3d957d1379  vmovaps [rsp+0x70], xmm7
00007d3d957d137f  vmovaps [rsp+0x80], xmm8
00007d3d957d1388  vmovaps [rsp+0x90], xmm9
00007d3d957d1391  vmovaps [rsp+0xA0], xmm10
00007d3d957d139a  vmovaps [rsp+0xB0], xmm11
00007d3d957d13a3  vmovaps [rsp+0xC0], xmm12
00007d3d957d13ac  vmovaps [rsp+0xD0], xmm14
00007d3d957d13b5  vmovaps [rsp+0xE0], xmm15
00007d3d957d13be  sub rsp, 0x30
00007d3d957d13c2  movaps [rsp], xmm13
00007d3d957d13c7  movaps [rsp+0x10], xmm2
00007d3d957d13cc  movaps [rsp+0x20], xmm1
00007d3d957d13d1  lea rdi, [rsp]
00007d3d957d13d5  mov esi, 0x00
00007d3d957d13da  mov rax, 0x56C27CB8A530
00007d3d957d13e4  call rax
00007d3d957d13e6  movaps xmm13, [rsp]
00007d3d957d13eb  add rsp, 0x30
00007d3d957d13ef  vmovaps xmm0, [rsp]
00007d3d957d13f4  vmovaps xmm1, [rsp+0x10]
00007d3d957d13fa  vmovaps xmm2, [rsp+0x20]
00007d3d957d1400  vmovaps xmm3, [rsp+0x30]
00007d3d957d1406  vmovaps xmm4, [rsp+0x40]
00007d3d957d140c  vmovaps xmm5, [rsp+0x50]
00007d3d957d1412  vmovaps xmm6, [rsp+0x60]
00007d3d957d1418  vmovaps xmm7, [rsp+0x70]
00007d3d957d141e  vmovaps xmm8, [rsp+0x80]
00007d3d957d1427  vmovaps xmm9, [rsp+0x90]
00007d3d957d1430  vmovaps xmm10, [rsp+0xA0]
00007d3d957d1439  vmovaps xmm11, [rsp+0xB0]
00007d3d957d1442  vmovaps xmm12, [rsp+0xC0]
00007d3d957d144b  vmovaps xmm14, [rsp+0xD0]
00007d3d957d1454  vmovaps xmm15, [rsp+0xE0]
00007d3d957d145d  add rsp, 0xF0
00007d3d957d1464  pop r11
00007d3d957d1466  pop r10
00007d3d957d1468  pop r9
00007d3d957d146a  pop r8
00007d3d957d146c  pop rsi
00007d3d957d146d  pop rdi
00007d3d957d146e  pop rdx
00007d3d957d146f  pop rcx
00007d3d957d1470  pop rax
00007d3d957d1471  add rsp, 0x08
00007d3d957d1475  jmp 0x00007D3D957CF878
00007d3d957d147a  sub rsp, 0x08
00007d3d957d147e  push rax
00007d3d957d147f  push rcx
00007d3d957d1480  push rdx
00007d3d957d1481  push rdi
00007d3d957d1482  push rsi
00007d3d957d1483  push r8
00007d3d957d1485  push r9
00007d3d957d1487  push r10
00007d3d957d1489  push r11
00007d3d957d148b  sub rsp, 0xF0
00007d3d957d1492  vmovaps [rsp], xmm0
00007d3d957d1497  vmovaps [rsp+0x10], xmm2
00007d3d957d149d  vmovaps [rsp+0x20], xmm3
00007d3d957d14a3  vmovaps [rsp+0x30], xmm4
00007d3d957d14a9  vmovaps [rsp+0x40], xmm5
00007d3d957d14af  vmovaps [rsp+0x50], xmm6
00007d3d957d14b5  vmovaps [rsp+0x60], xmm7
00007d3d957d14bb  vmovaps [rsp+0x70], xmm8
00007d3d957d14c1  vmovaps [rsp+0x80], xmm9
00007d3d957d14ca  vmovaps [rsp+0x90], xmm10
00007d3d957d14d3  vmovaps [rsp+0xA0], xmm11
00007d3d957d14dc  vmovaps [rsp+0xB0], xmm12
00007d3d957d14e5  vmovaps [rsp+0xC0], xmm13
00007d3d957d14ee  vmovaps [rsp+0xD0], xmm14
00007d3d957d14f7  vmovaps [rsp+0xE0], xmm15
00007d3d957d1500  sub rsp, 0x30
00007d3d957d1504  movaps [rsp], xmm1
00007d3d957d1508  movaps [rsp+0x10], xmm15
00007d3d957d150e  movaps [rsp+0x20], xmm2
00007d3d957d1513  lea rdi, [rsp]
00007d3d957d1517  mov esi, 0x00
00007d3d957d151c  mov rax, 0x56C27CB8A530
00007d3d957d1526  call rax
00007d3d957d1528  movaps xmm1, [rsp]
00007d3d957d152c  add rsp, 0x30
00007d3d957d1530  vmovaps xmm0, [rsp]
00007d3d957d1535  vmovaps xmm2, [rsp+0x10]
00007d3d957d153b  vmovaps xmm3, [rsp+0x20]
00007d3d957d1541  vmovaps xmm4, [rsp+0x30]
00007d3d957d1547  vmovaps xmm5, [rsp+0x40]
00007d3d957d154d  vmovaps xmm6, [rsp+0x50]
00007d3d957d1553  vmovaps xmm7, [rsp+0x60]
00007d3d957d1559  vmovaps xmm8, [rsp+0x70]
00007d3d957d155f  vmovaps xmm9, [rsp+0x80]
00007d3d957d1568  vmovaps xmm10, [rsp+0x90]
00007d3d957d1571  vmovaps xmm11, [rsp+0xA0]
00007d3d957d157a  vmovaps xmm12, [rsp+0xB0]
00007d3d957d1583  vmovaps xmm13, [rsp+0xC0]
00007d3d957d158c  vmovaps xmm14, [rsp+0xD0]
00007d3d957d1595  vmovaps xmm15, [rsp+0xE0]
00007d3d957d159e  add rsp, 0xF0
00007d3d957d15a5  pop r11
00007d3d957d15a7  pop r10
00007d3d957d15a9  pop r9
00007d3d957d15ab  pop r8
00007d3d957d15ad  pop rsi
00007d3d957d15ae  pop rdi
00007d3d957d15af  pop rdx
00007d3d957d15b0  pop rcx
00007d3d957d15b1  pop rax
00007d3d957d15b2  add rsp, 0x08
00007d3d957d15b6  jmp 0x00007D3D957CF8AC
00007d3d957d15bb  sub rsp, 0x08
00007d3d957d15bf  push rax
00007d3d957d15c0  push rcx
00007d3d957d15c1  push rdx
00007d3d957d15c2  push rdi
00007d3d957d15c3  push rsi
00007d3d957d15c4  push r8
00007d3d957d15c6  push r9
00007d3d957d15c8  push r10
00007d3d957d15ca  push r11
00007d3d957d15cc  sub rsp, 0xF0
00007d3d957d15d3  vmovaps [rsp], xmm0
00007d3d957d15d8  vmovaps [rsp+0x10], xmm1
00007d3d957d15de  vmovaps [rsp+0x20], xmm2
00007d3d957d15e4  vmovaps [rsp+0x30], xmm3
00007d3d957d15ea  vmovaps [rsp+0x40], xmm4
00007d3d957d15f0  vmovaps [rsp+0x50], xmm5
00007d3d957d15f6  vmovaps [rsp+0x60], xmm6
00007d3d957d15fc  vmovaps [rsp+0x70], xmm7
00007d3d957d1602  vmovaps [rsp+0x80], xmm8
00007d3d957d160b  vmovaps [rsp+0x90], xmm9
00007d3d957d1614  vmovaps [rsp+0xA0], xmm10
00007d3d957d161d  vmovaps [rsp+0xB0], xmm11
00007d3d957d1626  vmovaps [rsp+0xC0], xmm12
00007d3d957d162f  vmovaps [rsp+0xD0], xmm13
00007d3d957d1638  vmovaps [rsp+0xE0], xmm15
00007d3d957d1641  sub rsp, 0x30
00007d3d957d1645  movaps [rsp], xmm14
00007d3d957d164a  movaps [rsp+0x10], xmm2
00007d3d957d164f  movaps [rsp+0x20], xmm15
00007d3d957d1655  lea rdi, [rsp]
00007d3d957d1659  mov esi, 0x00
00007d3d957d165e  mov rax, 0x56C27CB8A530
00007d3d957d1668  call rax
00007d3d957d166a  movaps xmm14, [rsp]
00007d3d957d166f  add rsp, 0x30
00007d3d957d1673  vmovaps xmm0, [rsp]
00007d3d957d1678  vmovaps xmm1, [rsp+0x10]
00007d3d957d167e  vmovaps xmm2, [rsp+0x20]
00007d3d957d1684  vmovaps xmm3, [rsp+0x30]
00007d3d957d168a  vmovaps xmm4, [rsp+0x40]
00007d3d957d1690  vmovaps xmm5, [rsp+0x50]
00007d3d957d1696  vmovaps xmm6, [rsp+0x60]
00007d3d957d169c  vmovaps xmm7, [rsp+0x70]
00007d3d957d16a2  vmovaps xmm8, [rsp+0x80]
00007d3d957d16ab  vmovaps xmm9, [rsp+0x90]
00007d3d957d16b4  vmovaps xmm10, [rsp+0xA0]
00007d3d957d16bd  vmovaps xmm11, [rsp+0xB0]
00007d3d957d16c6  vmovaps xmm12, [rsp+0xC0]
00007d3d957d16cf  vmovaps xmm13, [rsp+0xD0]
00007d3d957d16d8  vmovaps xmm15, [rsp+0xE0]
00007d3d957d16e1  add rsp, 0xF0
00007d3d957d16e8  pop r11
00007d3d957d16ea  pop r10
00007d3d957d16ec  pop r9
00007d3d957d16ee  pop r8
00007d3d957d16f0  pop rsi
00007d3d957d16f1  pop rdi
00007d3d957d16f2  pop rdx
00007d3d957d16f3  pop rcx
00007d3d957d16f4  pop rax
00007d3d957d16f5  add rsp, 0x08
00007d3d957d16f9  jmp 0x00007D3D957CF8E7
00007d3d957d16fe  sub rsp, 0x08
00007d3d957d1702  push rax
00007d3d957d1703  push rcx
00007d3d957d1704  push rdx
00007d3d957d1705  push rdi
00007d3d957d1706  push rsi
00007d3d957d1707  push r8
00007d3d957d1709  push r9
00007d3d957d170b  push r10
00007d3d957d170d  push r11
00007d3d957d170f  sub rsp, 0xF0
00007d3d957d1716  vmovaps [rsp], xmm0
00007d3d957d171b  vmovaps [rsp+0x10], xmm1
00007d3d957d1721  vmovaps [rsp+0x20], xmm2
00007d3d957d1727  vmovaps [rsp+0x30], xmm3
00007d3d957d172d  vmovaps [rsp+0x40], xmm4
00007d3d957d1733  vmovaps [rsp+0x50], xmm5
00007d3d957d1739  vmovaps [rsp+0x60], xmm6
00007d3d957d173f  vmovaps [rsp+0x70], xmm7
00007d3d957d1745  vmovaps [rsp+0x80], xmm8
00007d3d957d174e  vmovaps [rsp+0x90], xmm9
00007d3d957d1757  vmovaps [rsp+0xA0], xmm10
00007d3d957d1760  vmovaps [rsp+0xB0], xmm11
00007d3d957d1769  vmovaps [rsp+0xC0], xmm12
00007d3d957d1772  vmovaps [rsp+0xD0], xmm13
00007d3d957d177b  vmovaps [rsp+0xE0], xmm14
00007d3d957d1784  sub rsp, 0x30
00007d3d957d1788  movaps [rsp], xmm15
00007d3d957d178d  movaps [rsp+0x10], xmm2
00007d3d957d1792  movaps [rsp+0x20], xmm1
00007d3d957d1797  lea rdi, [rsp]
00007d3d957d179b  mov esi, 0x00
00007d3d957d17a0  mov rax, 0x56C27CB8A530
00007d3d957d17aa  call rax
00007d3d957d17ac  movaps xmm15, [rsp]
00007d3d957d17b1  add rsp, 0x30
00007d3d957d17b5  vmovaps xmm0, [rsp]
00007d3d957d17ba  vmovaps xmm1, [rsp+0x10]
00007d3d957d17c0  vmovaps xmm2, [rsp+0x20]
00007d3d957d17c6  vmovaps xmm3, [rsp+0x30]
00007d3d957d17cc  vmovaps xmm4, [rsp+0x40]
00007d3d957d17d2  vmovaps xmm5, [rsp+0x50]
00007d3d957d17d8  vmovaps xmm6, [rsp+0x60]
00007d3d957d17de  vmovaps xmm7, [rsp+0x70]
00007d3d957d17e4  vmovaps xmm8, [rsp+0x80]
00007d3d957d17ed  vmovaps xmm9, [rsp+0x90]
00007d3d957d17f6  vmovaps xmm10, [rsp+0xA0]
00007d3d957d17ff  vmovaps xmm11, [rsp+0xB0]
00007d3d957d1808  vmovaps xmm12, [rsp+0xC0]
00007d3d957d1811  vmovaps xmm13, [rsp+0xD0]
00007d3d957d181a  vmovaps xmm14, [rsp+0xE0]
00007d3d957d1823  add rsp, 0xF0
00007d3d957d182a  pop r11
00007d3d957d182c  pop r10
00007d3d957d182e  pop r9
00007d3d957d1830  pop r8
00007d3d957d1832  pop rsi
00007d3d957d1833  pop rdi
00007d3d957d1834  pop rdx
00007d3d957d1835  pop rcx
00007d3d957d1836  pop rax
00007d3d957d1837  add rsp, 0x08
00007d3d957d183b  jmp 0x00007D3D957CF923
00007d3d957d1840  call 0x00007D3D955FF430
00007d3d957d1845  jmp 0x00007D3D957CF930
00007d3d957d184a  sub rsp, 0x08
00007d3d957d184e  push rax
00007d3d957d184f  push rcx
00007d3d957d1850  push rdx
00007d3d957d1851  push rdi
00007d3d957d1852  push rsi
00007d3d957d1853  push r8
00007d3d957d1855  push r9
00007d3d957d1857  push r10
00007d3d957d1859  push r11
00007d3d957d185b  sub rsp, 0xF0
00007d3d957d1862  vmovaps [rsp], xmm0
00007d3d957d1867  vmovaps [rsp+0x10], xmm1
00007d3d957d186d  vmovaps [rsp+0x20], xmm3
00007d3d957d1873  vmovaps [rsp+0x30], xmm4
00007d3d957d1879  vmovaps [rsp+0x40], xmm5
00007d3d957d187f  vmovaps [rsp+0x50], xmm6
00007d3d957d1885  vmovaps [rsp+0x60], xmm7
00007d3d957d188b  vmovaps [rsp+0x70], xmm8
00007d3d957d1891  vmovaps [rsp+0x80], xmm9
00007d3d957d189a  vmovaps [rsp+0x90], xmm10
00007d3d957d18a3  vmovaps [rsp+0xA0], xmm11
00007d3d957d18ac  vmovaps [rsp+0xB0], xmm12
00007d3d957d18b5  vmovaps [rsp+0xC0], xmm13
00007d3d957d18be  vmovaps [rsp+0xD0], xmm14
00007d3d957d18c7  vmovaps [rsp+0xE0], xmm15
00007d3d957d18d0  sub rsp, 0x30
00007d3d957d18d4  movaps [rsp], xmm2
00007d3d957d18d8  movaps [rsp+0x10], xmm1
00007d3d957d18dd  movaps [rsp+0x20], xmm14
00007d3d957d18e3  lea rdi, [rsp]
00007d3d957d18e7  mov esi, 0x00
00007d3d957d18ec  mov rax, 0x56C27CB8A530
00007d3d957d18f6  call rax
00007d3d957d18f8  movaps xmm2, [rsp]
00007d3d957d18fc  add rsp, 0x30
00007d3d957d1900  vmovaps xmm0, [rsp]
00007d3d957d1905  vmovaps xmm1, [rsp+0x10]
00007d3d957d190b  vmovaps xmm3, [rsp+0x20]
00007d3d957d1911  vmovaps xmm4, [rsp+0x30]
00007d3d957d1917  vmovaps xmm5, [rsp+0x40]
00007d3d957d191d  vmovaps xmm6, [rsp+0x50]
00007d3d957d1923  vmovaps xmm7, [rsp+0x60]
00007d3d957d1929  vmovaps xmm8, [rsp+0x70]
00007d3d957d192f  vmovaps xmm9, [rsp+0x80]
00007d3d957d1938  vmovaps xmm10, [rsp+0x90]
00007d3d957d1941  vmovaps xmm11, [rsp+0xA0]
00007d3d957d194a  vmovaps xmm12, [rsp+0xB0]
00007d3d957d1953  vmovaps xmm13, [rsp+0xC0]
00007d3d957d195c  vmovaps xmm14, [rsp+0xD0]
00007d3d957d1965  vmovaps xmm15, [rsp+0xE0]
00007d3d957d196e  add rsp, 0xF0
00007d3d957d1975  pop r11
00007d3d957d1977  pop r10
00007d3d957d1979  pop r9
00007d3d957d197b  pop r8
00007d3d957d197d  pop rsi
00007d3d957d197e  pop rdi
00007d3d957d197f  pop rdx
00007d3d957d1980  pop rcx
00007d3d957d1981  pop rax
00007d3d957d1982  add rsp, 0x08
00007d3d957d1986  jmp 0x00007D3D957CF96D
00007d3d957d198b  sub rsp, 0x08
00007d3d957d198f  push rax
00007d3d957d1990  push rcx
00007d3d957d1991  push rdx
00007d3d957d1992  push rdi
00007d3d957d1993  push rsi
00007d3d957d1994  push r8
00007d3d957d1996  push r9
00007d3d957d1998  push r10
00007d3d957d199a  push r11
00007d3d957d199c  sub rsp, 0xF0
00007d3d957d19a3  vmovaps [rsp], xmm0
00007d3d957d19a8  vmovaps [rsp+0x10], xmm1
00007d3d957d19ae  vmovaps [rsp+0x20], xmm2
00007d3d957d19b4  vmovaps [rsp+0x30], xmm3
00007d3d957d19ba  vmovaps [rsp+0x40], xmm4
00007d3d957d19c0  vmovaps [rsp+0x50], xmm5
00007d3d957d19c6  vmovaps [rsp+0x60], xmm6
00007d3d957d19cc  vmovaps [rsp+0x70], xmm7
00007d3d957d19d2  vmovaps [rsp+0x80], xmm8
00007d3d957d19db  vmovaps [rsp+0x90], xmm9
00007d3d957d19e4  vmovaps [rsp+0xA0], xmm10
00007d3d957d19ed  vmovaps [rsp+0xB0], xmm11
00007d3d957d19f6  vmovaps [rsp+0xC0], xmm12
00007d3d957d19ff  vmovaps [rsp+0xD0], xmm13
00007d3d957d1a08  vmovaps [rsp+0xE0], xmm14
00007d3d957d1a11  sub rsp, 0x30
00007d3d957d1a15  movaps [rsp], xmm15
00007d3d957d1a1a  movaps [rsp+0x10], xmm14
00007d3d957d1a20  movaps [rsp+0x20], xmm1
00007d3d957d1a25  lea rdi, [rsp]
00007d3d957d1a29  mov esi, 0x00
00007d3d957d1a2e  mov rax, 0x56C27CB8A530
00007d3d957d1a38  call rax
00007d3d957d1a3a  movaps xmm15, [rsp]
00007d3d957d1a3f  add rsp, 0x30
00007d3d957d1a43  vmovaps xmm0, [rsp]
00007d3d957d1a48  vmovaps xmm1, [rsp+0x10]
00007d3d957d1a4e  vmovaps xmm2, [rsp+0x20]
00007d3d957d1a54  vmovaps xmm3, [rsp+0x30]
00007d3d957d1a5a  vmovaps xmm4, [rsp+0x40]
00007d3d957d1a60  vmovaps xmm5, [rsp+0x50]
00007d3d957d1a66  vmovaps xmm6, [rsp+0x60]
00007d3d957d1a6c  vmovaps xmm7, [rsp+0x70]
00007d3d957d1a72  vmovaps xmm8, [rsp+0x80]
00007d3d957d1a7b  vmovaps xmm9, [rsp+0x90]
00007d3d957d1a84  vmovaps xmm10, [rsp+0xA0]
00007d3d957d1a8d  vmovaps xmm11, [rsp+0xB0]
00007d3d957d1a96  vmovaps xmm12, [rsp+0xC0]
00007d3d957d1a9f  vmovaps xmm13, [rsp+0xD0]
00007d3d957d1aa8  vmovaps xmm14, [rsp+0xE0]
00007d3d957d1ab1  add rsp, 0xF0
00007d3d957d1ab8  pop r11
00007d3d957d1aba  pop r10
00007d3d957d1abc  pop r9
00007d3d957d1abe  pop r8
00007d3d957d1ac0  pop rsi
00007d3d957d1ac1  pop rdi
00007d3d957d1ac2  pop rdx
00007d3d957d1ac3  pop rcx
00007d3d957d1ac4  pop rax
00007d3d957d1ac5  add rsp, 0x08
00007d3d957d1ac9  jmp 0x00007D3D957CF9E7
00007d3d957d1ace  call 0x00007D3D955FF430
00007d3d957d1ad3  jmp 0x00007D3D957CF9F4
00007d3d957d1ad8  sub rsp, 0x08
00007d3d957d1adc  push rax
00007d3d957d1add  push rcx
00007d3d957d1ade  push rdx
00007d3d957d1adf  push rdi
00007d3d957d1ae0  push rsi
00007d3d957d1ae1  push r8
00007d3d957d1ae3  push r9
00007d3d957d1ae5  push r10
00007d3d957d1ae7  push r11
00007d3d957d1ae9  sub rsp, 0xF0
00007d3d957d1af0  vmovaps [rsp], xmm0
00007d3d957d1af5  vmovaps [rsp+0x10], xmm1
00007d3d957d1afb  vmovaps [rsp+0x20], xmm2
00007d3d957d1b01  vmovaps [rsp+0x30], xmm3
00007d3d957d1b07  vmovaps [rsp+0x40], xmm4
00007d3d957d1b0d  vmovaps [rsp+0x50], xmm5
00007d3d957d1b13  vmovaps [rsp+0x60], xmm6
00007d3d957d1b19  vmovaps [rsp+0x70], xmm7
00007d3d957d1b1f  vmovaps [rsp+0x80], xmm8
00007d3d957d1b28  vmovaps [rsp+0x90], xmm9
00007d3d957d1b31  vmovaps [rsp+0xA0], xmm10
00007d3d957d1b3a  vmovaps [rsp+0xB0], xmm11
00007d3d957d1b43  vmovaps [rsp+0xC0], xmm12
00007d3d957d1b4c  vmovaps [rsp+0xD0], xmm13
00007d3d957d1b55  vmovaps [rsp+0xE0], xmm15
00007d3d957d1b5e  sub rsp, 0x30
00007d3d957d1b62  movaps [rsp], xmm14
00007d3d957d1b67  movaps [rsp+0x10], xmm13
00007d3d957d1b6d  movaps [rsp+0x20], xmm1
00007d3d957d1b72  lea rdi, [rsp]
00007d3d957d1b76  mov esi, 0x00
00007d3d957d1b7b  mov rax, 0x56C27CB8A530
00007d3d957d1b85  call rax
00007d3d957d1b87  movaps xmm14, [rsp]
00007d3d957d1b8c  add rsp, 0x30
00007d3d957d1b90  vmovaps xmm0, [rsp]
00007d3d957d1b95  vmovaps xmm1, [rsp+0x10]
00007d3d957d1b9b  vmovaps xmm2, [rsp+0x20]
00007d3d957d1ba1  vmovaps xmm3, [rsp+0x30]
00007d3d957d1ba7  vmovaps xmm4, [rsp+0x40]
00007d3d957d1bad  vmovaps xmm5, [rsp+0x50]
00007d3d957d1bb3  vmovaps xmm6, [rsp+0x60]
00007d3d957d1bb9  vmovaps xmm7, [rsp+0x70]
00007d3d957d1bbf  vmovaps xmm8, [rsp+0x80]
00007d3d957d1bc8  vmovaps xmm9, [rsp+0x90]
00007d3d957d1bd1  vmovaps xmm10, [rsp+0xA0]
00007d3d957d1bda  vmovaps xmm11, [rsp+0xB0]
00007d3d957d1be3  vmovaps xmm12, [rsp+0xC0]
00007d3d957d1bec  vmovaps xmm13, [rsp+0xD0]
00007d3d957d1bf5  vmovaps xmm15, [rsp+0xE0]
00007d3d957d1bfe  add rsp, 0xF0
00007d3d957d1c05  pop r11
00007d3d957d1c07  pop r10
00007d3d957d1c09  pop r9
00007d3d957d1c0b  pop r8
00007d3d957d1c0d  pop rsi
00007d3d957d1c0e  pop rdi
00007d3d957d1c0f  pop rdx
00007d3d957d1c10  pop rcx
00007d3d957d1c11  pop rax
00007d3d957d1c12  add rsp, 0x08
00007d3d957d1c16  jmp 0x00007D3D957CFAAF
00007d3d957d1c1b  sub rsp, 0x08
00007d3d957d1c1f  push rax
00007d3d957d1c20  push rcx
00007d3d957d1c21  push rdx
00007d3d957d1c22  push rdi
00007d3d957d1c23  push rsi
00007d3d957d1c24  push r8
00007d3d957d1c26  push r9
00007d3d957d1c28  push r10
00007d3d957d1c2a  push r11
00007d3d957d1c2c  sub rsp, 0xF0
00007d3d957d1c33  vmovaps [rsp], xmm0
00007d3d957d1c38  vmovaps [rsp+0x10], xmm1
00007d3d957d1c3e  vmovaps [rsp+0x20], xmm2
00007d3d957d1c44  vmovaps [rsp+0x30], xmm3
00007d3d957d1c4a  vmovaps [rsp+0x40], xmm4
00007d3d957d1c50  vmovaps [rsp+0x50], xmm5
00007d3d957d1c56  vmovaps [rsp+0x60], xmm6
00007d3d957d1c5c  vmovaps [rsp+0x70], xmm7
00007d3d957d1c62  vmovaps [rsp+0x80], xmm8
00007d3d957d1c6b  vmovaps [rsp+0x90], xmm9
00007d3d957d1c74  vmovaps [rsp+0xA0], xmm10
00007d3d957d1c7d  vmovaps [rsp+0xB0], xmm11
00007d3d957d1c86  vmovaps [rsp+0xC0], xmm12
00007d3d957d1c8f  vmovaps [rsp+0xD0], xmm13
00007d3d957d1c98  vmovaps [rsp+0xE0], xmm14
00007d3d957d1ca1  sub rsp, 0x30
00007d3d957d1ca5  movaps [rsp], xmm15
00007d3d957d1caa  movaps [rsp+0x10], xmm13
00007d3d957d1cb0  movaps [rsp+0x20], xmm1
00007d3d957d1cb5  lea rdi, [rsp]
00007d3d957d1cb9  mov esi, 0x00
00007d3d957d1cbe  mov rax, 0x56C27CB8A530
00007d3d957d1cc8  call rax
00007d3d957d1cca  movaps xmm15, [rsp]
00007d3d957d1ccf  add rsp, 0x30
00007d3d957d1cd3  vmovaps xmm0, [rsp]
00007d3d957d1cd8  vmovaps xmm1, [rsp+0x10]
00007d3d957d1cde  vmovaps xmm2, [rsp+0x20]
00007d3d957d1ce4  vmovaps xmm3, [rsp+0x30]
00007d3d957d1cea  vmovaps xmm4, [rsp+0x40]
00007d3d957d1cf0  vmovaps xmm5, [rsp+0x50]
00007d3d957d1cf6  vmovaps xmm6, [rsp+0x60]
00007d3d957d1cfc  vmovaps xmm7, [rsp+0x70]
00007d3d957d1d02  vmovaps xmm8, [rsp+0x80]
00007d3d957d1d0b  vmovaps xmm9, [rsp+0x90]
00007d3d957d1d14  vmovaps xmm10, [rsp+0xA0]
00007d3d957d1d1d  vmovaps xmm11, [rsp+0xB0]
00007d3d957d1d26  vmovaps xmm12, [rsp+0xC0]
00007d3d957d1d2f  vmovaps xmm13, [rsp+0xD0]
00007d3d957d1d38  vmovaps xmm14, [rsp+0xE0]
00007d3d957d1d41  add rsp, 0xF0
00007d3d957d1d48  pop r11
00007d3d957d1d4a  pop r10
00007d3d957d1d4c  pop r9
00007d3d957d1d4e  pop r8
00007d3d957d1d50  pop rsi
00007d3d957d1d51  pop rdi
00007d3d957d1d52  pop rdx
00007d3d957d1d53  pop rcx
00007d3d957d1d54  pop rax
00007d3d957d1d55  add rsp, 0x08
00007d3d957d1d59  jmp 0x00007D3D957CFAEB
00007d3d957d1d5e  call 0x00007D3D955FF430
00007d3d957d1d63  jmp 0x00007D3D957CFAF8
00007d3d957d1d68  sub rsp, 0x08
00007d3d957d1d6c  push rax
00007d3d957d1d6d  push rcx
00007d3d957d1d6e  push rdx
00007d3d957d1d6f  push rdi
00007d3d957d1d70  push rsi
00007d3d957d1d71  push r8
00007d3d957d1d73  push r9
00007d3d957d1d75  push r10
00007d3d957d1d77  push r11
00007d3d957d1d79  sub rsp, 0xF0
00007d3d957d1d80  vmovaps [rsp], xmm0
00007d3d957d1d85  vmovaps [rsp+0x10], xmm1
00007d3d957d1d8b  vmovaps [rsp+0x20], xmm2
00007d3d957d1d91  vmovaps [rsp+0x30], xmm3
00007d3d957d1d97  vmovaps [rsp+0x40], xmm4
00007d3d957d1d9d  vmovaps [rsp+0x50], xmm5
00007d3d957d1da3  vmovaps [rsp+0x60], xmm6
00007d3d957d1da9  vmovaps [rsp+0x70], xmm7
00007d3d957d1daf  vmovaps [rsp+0x80], xmm8
00007d3d957d1db8  vmovaps [rsp+0x90], xmm9
00007d3d957d1dc1  vmovaps [rsp+0xA0], xmm10
00007d3d957d1dca  vmovaps [rsp+0xB0], xmm11
00007d3d957d1dd3  vmovaps [rsp+0xC0], xmm12
00007d3d957d1ddc  vmovaps [rsp+0xD0], xmm13
00007d3d957d1de5  vmovaps [rsp+0xE0], xmm15
00007d3d957d1dee  sub rsp, 0x30
00007d3d957d1df2  movaps [rsp], xmm14
00007d3d957d1df7  movaps [rsp+0x10], xmm13
00007d3d957d1dfd  movaps [rsp+0x20], xmm2
00007d3d957d1e02  lea rdi, [rsp]
00007d3d957d1e06  mov esi, 0x00
00007d3d957d1e0b  mov rax, 0x56C27CB8A530
00007d3d957d1e15  call rax
00007d3d957d1e17  movaps xmm14, [rsp]
00007d3d957d1e1c  add rsp, 0x30
00007d3d957d1e20  vmovaps xmm0, [rsp]
00007d3d957d1e25  vmovaps xmm1, [rsp+0x10]
00007d3d957d1e2b  vmovaps xmm2, [rsp+0x20]
00007d3d957d1e31  vmovaps xmm3, [rsp+0x30]
00007d3d957d1e37  vmovaps xmm4, [rsp+0x40]
00007d3d957d1e3d  vmovaps xmm5, [rsp+0x50]
00007d3d957d1e43  vmovaps xmm6, [rsp+0x60]
00007d3d957d1e49  vmovaps xmm7, [rsp+0x70]
00007d3d957d1e4f  vmovaps xmm8, [rsp+0x80]
00007d3d957d1e58  vmovaps xmm9, [rsp+0x90]
00007d3d957d1e61  vmovaps xmm10, [rsp+0xA0]
00007d3d957d1e6a  vmovaps xmm11, [rsp+0xB0]
00007d3d957d1e73  vmovaps xmm12, [rsp+0xC0]
00007d3d957d1e7c  vmovaps xmm13, [rsp+0xD0]
00007d3d957d1e85  vmovaps xmm15, [rsp+0xE0]
00007d3d957d1e8e  add rsp, 0xF0
00007d3d957d1e95  pop r11
00007d3d957d1e97  pop r10
00007d3d957d1e99  pop r9
00007d3d957d1e9b  pop r8
00007d3d957d1e9d  pop rsi
00007d3d957d1e9e  pop rdi
00007d3d957d1e9f  pop rdx
00007d3d957d1ea0  pop rcx
00007d3d957d1ea1  pop rax
00007d3d957d1ea2  add rsp, 0x08
00007d3d957d1ea6  jmp 0x00007D3D957CFB24
00007d3d957d1eab  sub rsp, 0x08
00007d3d957d1eaf  push rax
00007d3d957d1eb0  push rcx
00007d3d957d1eb1  push rdx
00007d3d957d1eb2  push rdi
00007d3d957d1eb3  push rsi
00007d3d957d1eb4  push r8
00007d3d957d1eb6  push r9
00007d3d957d1eb8  push r10
00007d3d957d1eba  push r11
00007d3d957d1ebc  sub rsp, 0xF0
00007d3d957d1ec3  vmovaps [rsp], xmm0
00007d3d957d1ec8  vmovaps [rsp+0x10], xmm2
00007d3d957d1ece  vmovaps [rsp+0x20], xmm3
00007d3d957d1ed4  vmovaps [rsp+0x30], xmm4
00007d3d957d1eda  vmovaps [rsp+0x40], xmm5
00007d3d957d1ee0  vmovaps [rsp+0x50], xmm6
00007d3d957d1ee6  vmovaps [rsp+0x60], xmm7
00007d3d957d1eec  vmovaps [rsp+0x70], xmm8
00007d3d957d1ef2  vmovaps [rsp+0x80], xmm9
00007d3d957d1efb  vmovaps [rsp+0x90], xmm10
00007d3d957d1f04  vmovaps [rsp+0xA0], xmm11
00007d3d957d1f0d  vmovaps [rsp+0xB0], xmm12
00007d3d957d1f16  vmovaps [rsp+0xC0], xmm13
00007d3d957d1f1f  vmovaps [rsp+0xD0], xmm14
00007d3d957d1f28  vmovaps [rsp+0xE0], xmm15
00007d3d957d1f31  sub rsp, 0x30
00007d3d957d1f35  movaps [rsp], xmm1
00007d3d957d1f39  movaps [rsp+0x10], xmm13
00007d3d957d1f3f  movaps [rsp+0x20], xmm2
00007d3d957d1f44  lea rdi, [rsp]
00007d3d957d1f48  mov esi, 0x00
00007d3d957d1f4d  mov rax, 0x56C27CB8A530
00007d3d957d1f57  call rax
00007d3d957d1f59  movaps xmm1, [rsp]
00007d3d957d1f5d  add rsp, 0x30
00007d3d957d1f61  vmovaps xmm0, [rsp]
00007d3d957d1f66  vmovaps xmm2, [rsp+0x10]
00007d3d957d1f6c  vmovaps xmm3, [rsp+0x20]
00007d3d957d1f72  vmovaps xmm4, [rsp+0x30]
00007d3d957d1f78  vmovaps xmm5, [rsp+0x40]
00007d3d957d1f7e  vmovaps xmm6, [rsp+0x50]
00007d3d957d1f84  vmovaps xmm7, [rsp+0x60]
00007d3d957d1f8a  vmovaps xmm8, [rsp+0x70]
00007d3d957d1f90  vmovaps xmm9, [rsp+0x80]
00007d3d957d1f99  vmovaps xmm10, [rsp+0x90]
00007d3d957d1fa2  vmovaps xmm11, [rsp+0xA0]
00007d3d957d1fab  vmovaps xmm12, [rsp+0xB0]
00007d3d957d1fb4  vmovaps xmm13, [rsp+0xC0]
00007d3d957d1fbd  vmovaps xmm14, [rsp+0xD0]
00007d3d957d1fc6  vmovaps xmm15, [rsp+0xE0]
00007d3d957d1fcf  add rsp, 0xF0
00007d3d957d1fd6  pop r11
00007d3d957d1fd8  pop r10
00007d3d957d1fda  pop r9
00007d3d957d1fdc  pop r8
00007d3d957d1fde  pop rsi
00007d3d957d1fdf  pop rdi
00007d3d957d1fe0  pop rdx
00007d3d957d1fe1  pop rcx
00007d3d957d1fe2  pop rax
00007d3d957d1fe3  add rsp, 0x08
00007d3d957d1fe7  jmp 0x00007D3D957CFB52
00007d3d957d1fec  sub rsp, 0x08
00007d3d957d1ff0  push rax
00007d3d957d1ff1  push rcx
00007d3d957d1ff2  push rdx
00007d3d957d1ff3  push rdi
00007d3d957d1ff4  push rsi
00007d3d957d1ff5  push r8
00007d3d957d1ff7  push r9
00007d3d957d1ff9  push r10
00007d3d957d1ffb  push r11
00007d3d957d1ffd  sub rsp, 0xF0
00007d3d957d2004  vmovaps [rsp], xmm0
00007d3d957d2009  vmovaps [rsp+0x10], xmm1
00007d3d957d200f  vmovaps [rsp+0x20], xmm3
00007d3d957d2015  vmovaps [rsp+0x30], xmm4
00007d3d957d201b  vmovaps [rsp+0x40], xmm5
00007d3d957d2021  vmovaps [rsp+0x50], xmm6
00007d3d957d2027  vmovaps [rsp+0x60], xmm7
00007d3d957d202d  vmovaps [rsp+0x70], xmm8
00007d3d957d2033  vmovaps [rsp+0x80], xmm9
00007d3d957d203c  vmovaps [rsp+0x90], xmm10
00007d3d957d2045  vmovaps [rsp+0xA0], xmm11
00007d3d957d204e  vmovaps [rsp+0xB0], xmm12
00007d3d957d2057  vmovaps [rsp+0xC0], xmm13
00007d3d957d2060  vmovaps [rsp+0xD0], xmm14
00007d3d957d2069  vmovaps [rsp+0xE0], xmm15
00007d3d957d2072  sub rsp, 0x30
00007d3d957d2076  movaps [rsp], xmm2
00007d3d957d207a  movaps [rsp+0x10], xmm1
00007d3d957d207f  movaps [rsp+0x20], xmm13
00007d3d957d2085  lea rdi, [rsp]
00007d3d957d2089  mov esi, 0x00
00007d3d957d208e  mov rax, 0x56C27CB8A530
00007d3d957d2098  call rax
00007d3d957d209a  movaps xmm2, [rsp]
00007d3d957d209e  add rsp, 0x30
00007d3d957d20a2  vmovaps xmm0, [rsp]
00007d3d957d20a7  vmovaps xmm1, [rsp+0x10]
00007d3d957d20ad  vmovaps xmm3, [rsp+0x20]
00007d3d957d20b3  vmovaps xmm4, [rsp+0x30]
00007d3d957d20b9  vmovaps xmm5, [rsp+0x40]
00007d3d957d20bf  vmovaps xmm6, [rsp+0x50]
00007d3d957d20c5  vmovaps xmm7, [rsp+0x60]
00007d3d957d20cb  vmovaps xmm8, [rsp+0x70]
00007d3d957d20d1  vmovaps xmm9, [rsp+0x80]
00007d3d957d20da  vmovaps xmm10, [rsp+0x90]
00007d3d957d20e3  vmovaps xmm11, [rsp+0xA0]
00007d3d957d20ec  vmovaps xmm12, [rsp+0xB0]
00007d3d957d20f5  vmovaps xmm13, [rsp+0xC0]
00007d3d957d20fe  vmovaps xmm14, [rsp+0xD0]
00007d3d957d2107  vmovaps xmm15, [rsp+0xE0]
00007d3d957d2110  add rsp, 0xF0
00007d3d957d2117  pop r11
00007d3d957d2119  pop r10
00007d3d957d211b  pop r9
00007d3d957d211d  pop r8
00007d3d957d211f  pop rsi
00007d3d957d2120  pop rdi
00007d3d957d2121  pop rdx
00007d3d957d2122  pop rcx
00007d3d957d2123  pop rax
00007d3d957d2124  add rsp, 0x08
00007d3d957d2128  jmp 0x00007D3D957CFBAB
00007d3d957d212d  call 0x00007D3D955FF430
00007d3d957d2132  jmp 0x00007D3D957CFBB8
00007d3d957d2137  sub rsp, 0x08
00007d3d957d213b  push rax
00007d3d957d213c  push rcx
00007d3d957d213d  push rdx
00007d3d957d213e  push rdi
00007d3d957d213f  push rsi
00007d3d957d2140  push r8
00007d3d957d2142  push r9
00007d3d957d2144  push r10
00007d3d957d2146  push r11
00007d3d957d2148  sub rsp, 0xF0
00007d3d957d214f  vmovaps [rsp], xmm0
00007d3d957d2154  vmovaps [rsp+0x10], xmm1
00007d3d957d215a  vmovaps [rsp+0x20], xmm2
00007d3d957d2160  vmovaps [rsp+0x30], xmm3
00007d3d957d2166  vmovaps [rsp+0x40], xmm4
00007d3d957d216c  vmovaps [rsp+0x50], xmm5
00007d3d957d2172  vmovaps [rsp+0x60], xmm6
00007d3d957d2178  vmovaps [rsp+0x70], xmm7
00007d3d957d217e  vmovaps [rsp+0x80], xmm8
00007d3d957d2187  vmovaps [rsp+0x90], xmm9
00007d3d957d2190  vmovaps [rsp+0xA0], xmm10
00007d3d957d2199  vmovaps [rsp+0xB0], xmm11
00007d3d957d21a2  vmovaps [rsp+0xC0], xmm12
00007d3d957d21ab  vmovaps [rsp+0xD0], xmm13
00007d3d957d21b4  vmovaps [rsp+0xE0], xmm14
00007d3d957d21bd  sub rsp, 0x30
00007d3d957d21c1  movaps [rsp], xmm15
00007d3d957d21c6  movaps [rsp+0x10], xmm13
00007d3d957d21cc  movaps [rsp+0x20], xmm1
00007d3d957d21d1  lea rdi, [rsp]
00007d3d957d21d5  mov esi, 0x00
00007d3d957d21da  mov rax, 0x56C27CB8A530
00007d3d957d21e4  call rax
00007d3d957d21e6  movaps xmm15, [rsp]
00007d3d957d21eb  add rsp, 0x30
00007d3d957d21ef  vmovaps xmm0, [rsp]
00007d3d957d21f4  vmovaps xmm1, [rsp+0x10]
00007d3d957d21fa  vmovaps xmm2, [rsp+0x20]
00007d3d957d2200  vmovaps xmm3, [rsp+0x30]
00007d3d957d2206  vmovaps xmm4, [rsp+0x40]
00007d3d957d220c  vmovaps xmm5, [rsp+0x50]
00007d3d957d2212  vmovaps xmm6, [rsp+0x60]
00007d3d957d2218  vmovaps xmm7, [rsp+0x70]
00007d3d957d221e  vmovaps xmm8, [rsp+0x80]
00007d3d957d2227  vmovaps xmm9, [rsp+0x90]
00007d3d957d2230  vmovaps xmm10, [rsp+0xA0]
00007d3d957d2239  vmovaps xmm11, [rsp+0xB0]
00007d3d957d2242  vmovaps xmm12, [rsp+0xC0]
00007d3d957d224b  vmovaps xmm13, [rsp+0xD0]
00007d3d957d2254  vmovaps xmm14, [rsp+0xE0]
00007d3d957d225d  add rsp, 0xF0
00007d3d957d2264  pop r11
00007d3d957d2266  pop r10
00007d3d957d2268  pop r9
00007d3d957d226a  pop r8
00007d3d957d226c  pop rsi
00007d3d957d226d  pop rdi
00007d3d957d226e  pop rdx
00007d3d957d226f  pop rcx
00007d3d957d2270  pop rax
00007d3d957d2271  add rsp, 0x08
00007d3d957d2275  jmp 0x00007D3D957CFBF7
00007d3d957d227a  sub rsp, 0x08
00007d3d957d227e  push rax
00007d3d957d227f  push rcx
00007d3d957d2280  push rdx
00007d3d957d2281  push rdi
00007d3d957d2282  push rsi
00007d3d957d2283  push r8
00007d3d957d2285  push r9
00007d3d957d2287  push r10
00007d3d957d2289  push r11
00007d3d957d228b  sub rsp, 0xF0
00007d3d957d2292  vmovaps [rsp], xmm0
00007d3d957d2297  vmovaps [rsp+0x10], xmm1
00007d3d957d229d  vmovaps [rsp+0x20], xmm2
00007d3d957d22a3  vmovaps [rsp+0x30], xmm3
00007d3d957d22a9  vmovaps [rsp+0x40], xmm4
00007d3d957d22af  vmovaps [rsp+0x50], xmm5
00007d3d957d22b5  vmovaps [rsp+0x60], xmm6
00007d3d957d22bb  vmovaps [rsp+0x70], xmm7
00007d3d957d22c1  vmovaps [rsp+0x80], xmm8
00007d3d957d22ca  vmovaps [rsp+0x90], xmm9
00007d3d957d22d3  vmovaps [rsp+0xA0], xmm10
00007d3d957d22dc  vmovaps [rsp+0xB0], xmm11
00007d3d957d22e5  vmovaps [rsp+0xC0], xmm12
00007d3d957d22ee  vmovaps [rsp+0xD0], xmm13
00007d3d957d22f7  vmovaps [rsp+0xE0], xmm15
00007d3d957d2300  sub rsp, 0x30
00007d3d957d2304  movaps [rsp], xmm14
00007d3d957d2309  movaps [rsp+0x10], xmm11
00007d3d957d230f  movaps [rsp+0x20], xmm1
00007d3d957d2314  lea rdi, [rsp]
00007d3d957d2318  mov esi, 0x00
00007d3d957d231d  mov rax, 0x56C27CB8A530
00007d3d957d2327  call rax
00007d3d957d2329  movaps xmm14, [rsp]
00007d3d957d232e  add rsp, 0x30
00007d3d957d2332  vmovaps xmm0, [rsp]
00007d3d957d2337  vmovaps xmm1, [rsp+0x10]
00007d3d957d233d  vmovaps xmm2, [rsp+0x20]
00007d3d957d2343  vmovaps xmm3, [rsp+0x30]
00007d3d957d2349  vmovaps xmm4, [rsp+0x40]
00007d3d957d234f  vmovaps xmm5, [rsp+0x50]
00007d3d957d2355  vmovaps xmm6, [rsp+0x60]
00007d3d957d235b  vmovaps xmm7, [rsp+0x70]
00007d3d957d2361  vmovaps xmm8, [rsp+0x80]
00007d3d957d236a  vmovaps xmm9, [rsp+0x90]
00007d3d957d2373  vmovaps xmm10, [rsp+0xA0]
00007d3d957d237c  vmovaps xmm11, [rsp+0xB0]
00007d3d957d2385  vmovaps xmm12, [rsp+0xC0]
00007d3d957d238e  vmovaps xmm13, [rsp+0xD0]
00007d3d957d2397  vmovaps xmm15, [rsp+0xE0]
00007d3d957d23a0  add rsp, 0xF0
00007d3d957d23a7  pop r11
00007d3d957d23a9  pop r10
00007d3d957d23ab  pop r9
00007d3d957d23ad  pop r8
00007d3d957d23af  pop rsi
00007d3d957d23b0  pop rdi
00007d3d957d23b1  pop rdx
00007d3d957d23b2  pop rcx
00007d3d957d23b3  pop rax
00007d3d957d23b4  add rsp, 0x08
00007d3d957d23b8  jmp 0x00007D3D957CFC21
00007d3d957d23bd  sub rsp, 0x08
00007d3d957d23c1  push rax
00007d3d957d23c2  push rcx
00007d3d957d23c3  push rdx
00007d3d957d23c4  push rdi
00007d3d957d23c5  push rsi
00007d3d957d23c6  push r8
00007d3d957d23c8  push r9
00007d3d957d23ca  push r10
00007d3d957d23cc  push r11
00007d3d957d23ce  sub rsp, 0xF0
00007d3d957d23d5  vmovaps [rsp], xmm0
00007d3d957d23da  vmovaps [rsp+0x10], xmm1
00007d3d957d23e0  vmovaps [rsp+0x20], xmm2
00007d3d957d23e6  vmovaps [rsp+0x30], xmm3
00007d3d957d23ec  vmovaps [rsp+0x40], xmm4
00007d3d957d23f2  vmovaps [rsp+0x50], xmm5
00007d3d957d23f8  vmovaps [rsp+0x60], xmm6
00007d3d957d23fe  vmovaps [rsp+0x70], xmm7
00007d3d957d2404  vmovaps [rsp+0x80], xmm8
00007d3d957d240d  vmovaps [rsp+0x90], xmm9
00007d3d957d2416  vmovaps [rsp+0xA0], xmm10
00007d3d957d241f  vmovaps [rsp+0xB0], xmm11
00007d3d957d2428  vmovaps [rsp+0xC0], xmm12
00007d3d957d2431  vmovaps [rsp+0xD0], xmm14
00007d3d957d243a  vmovaps [rsp+0xE0], xmm15
00007d3d957d2443  sub rsp, 0x30
00007d3d957d2447  movaps [rsp], xmm13
00007d3d957d244c  movaps [rsp+0x10], xmm11
00007d3d957d2452  movaps [rsp+0x20], xmm1
00007d3d957d2457  lea rdi, [rsp]
00007d3d957d245b  mov esi, 0x00
00007d3d957d2460  mov rax, 0x56C27CB8A530
00007d3d957d246a  call rax
00007d3d957d246c  movaps xmm13, [rsp]
00007d3d957d2471  add rsp, 0x30
00007d3d957d2475  vmovaps xmm0, [rsp]
00007d3d957d247a  vmovaps xmm1, [rsp+0x10]
00007d3d957d2480  vmovaps xmm2, [rsp+0x20]
00007d3d957d2486  vmovaps xmm3, [rsp+0x30]
00007d3d957d248c  vmovaps xmm4, [rsp+0x40]
00007d3d957d2492  vmovaps xmm5, [rsp+0x50]
00007d3d957d2498  vmovaps xmm6, [rsp+0x60]
00007d3d957d249e  vmovaps xmm7, [rsp+0x70]
00007d3d957d24a4  vmovaps xmm8, [rsp+0x80]
00007d3d957d24ad  vmovaps xmm9, [rsp+0x90]
00007d3d957d24b6  vmovaps xmm10, [rsp+0xA0]
00007d3d957d24bf  vmovaps xmm11, [rsp+0xB0]
00007d3d957d24c8  vmovaps xmm12, [rsp+0xC0]
00007d3d957d24d1  vmovaps xmm14, [rsp+0xD0]
00007d3d957d24da  vmovaps xmm15, [rsp+0xE0]
00007d3d957d24e3  add rsp, 0xF0
00007d3d957d24ea  pop r11
00007d3d957d24ec  pop r10
00007d3d957d24ee  pop r9
00007d3d957d24f0  pop r8
00007d3d957d24f2  pop rsi
00007d3d957d24f3  pop rdi
00007d3d957d24f4  pop rdx
00007d3d957d24f5  pop rcx
00007d3d957d24f6  pop rax
00007d3d957d24f7  add rsp, 0x08
00007d3d957d24fb  jmp 0x00007D3D957CFC76
00007d3d957d2500  call 0x00007D3D955FF430
00007d3d957d2505  jmp 0x00007D3D957CFC83
00007d3d957d250a  sub rsp, 0x08
00007d3d957d250e  push rax
00007d3d957d250f  push rcx
00007d3d957d2510  push rdx
00007d3d957d2511  push rdi
00007d3d957d2512  push rsi
00007d3d957d2513  push r8
00007d3d957d2515  push r9
00007d3d957d2517  push r10
00007d3d957d2519  push r11
00007d3d957d251b  sub rsp, 0xF0
00007d3d957d2522  vmovaps [rsp], xmm0
00007d3d957d2527  vmovaps [rsp+0x10], xmm1
00007d3d957d252d  vmovaps [rsp+0x20], xmm2
00007d3d957d2533  vmovaps [rsp+0x30], xmm3
00007d3d957d2539  vmovaps [rsp+0x40], xmm4
00007d3d957d253f  vmovaps [rsp+0x50], xmm5
00007d3d957d2545  vmovaps [rsp+0x60], xmm6
00007d3d957d254b  vmovaps [rsp+0x70], xmm7
00007d3d957d2551  vmovaps [rsp+0x80], xmm8
00007d3d957d255a  vmovaps [rsp+0x90], xmm9
00007d3d957d2563  vmovaps [rsp+0xA0], xmm10
00007d3d957d256c  vmovaps [rsp+0xB0], xmm11
00007d3d957d2575  vmovaps [rsp+0xC0], xmm12
00007d3d957d257e  vmovaps [rsp+0xD0], xmm13
00007d3d957d2587  vmovaps [rsp+0xE0], xmm14
00007d3d957d2590  sub rsp, 0x30
00007d3d957d2594  movaps [rsp], xmm15
00007d3d957d2599  movaps [rsp+0x10], xmm11
00007d3d957d259f  movaps [rsp+0x20], xmm1
00007d3d957d25a4  lea rdi, [rsp]
00007d3d957d25a8  mov esi, 0x00
00007d3d957d25ad  mov rax, 0x56C27CB8A530
00007d3d957d25b7  call rax
00007d3d957d25b9  movaps xmm15, [rsp]
00007d3d957d25be  add rsp, 0x30
00007d3d957d25c2  vmovaps xmm0, [rsp]
00007d3d957d25c7  vmovaps xmm1, [rsp+0x10]
00007d3d957d25cd  vmovaps xmm2, [rsp+0x20]
00007d3d957d25d3  vmovaps xmm3, [rsp+0x30]
00007d3d957d25d9  vmovaps xmm4, [rsp+0x40]
00007d3d957d25df  vmovaps xmm5, [rsp+0x50]
00007d3d957d25e5  vmovaps xmm6, [rsp+0x60]
00007d3d957d25eb  vmovaps xmm7, [rsp+0x70]
00007d3d957d25f1  vmovaps xmm8, [rsp+0x80]
00007d3d957d25fa  vmovaps xmm9, [rsp+0x90]
00007d3d957d2603  vmovaps xmm10, [rsp+0xA0]
00007d3d957d260c  vmovaps xmm11, [rsp+0xB0]
00007d3d957d2615  vmovaps xmm12, [rsp+0xC0]
00007d3d957d261e  vmovaps xmm13, [rsp+0xD0]
00007d3d957d2627  vmovaps xmm14, [rsp+0xE0]
00007d3d957d2630  add rsp, 0xF0
00007d3d957d2637  pop r11
00007d3d957d2639  pop r10
00007d3d957d263b  pop r9
00007d3d957d263d  pop r8
00007d3d957d263f  pop rsi
00007d3d957d2640  pop rdi
00007d3d957d2641  pop rdx
00007d3d957d2642  pop rcx
00007d3d957d2643  pop rax
00007d3d957d2644  add rsp, 0x08
00007d3d957d2648  jmp 0x00007D3D957CFCBC
00007d3d957d264d  sub rsp, 0x08
00007d3d957d2651  push rax
00007d3d957d2652  push rcx
00007d3d957d2653  push rdx
00007d3d957d2654  push rdi
00007d3d957d2655  push rsi
00007d3d957d2656  push r8
00007d3d957d2658  push r9
00007d3d957d265a  push r10
00007d3d957d265c  push r11
00007d3d957d265e  sub rsp, 0xF0
00007d3d957d2665  vmovaps [rsp], xmm0
00007d3d957d266a  vmovaps [rsp+0x10], xmm1
00007d3d957d2670  vmovaps [rsp+0x20], xmm2
00007d3d957d2676  vmovaps [rsp+0x30], xmm3
00007d3d957d267c  vmovaps [rsp+0x40], xmm4
00007d3d957d2682  vmovaps [rsp+0x50], xmm5
00007d3d957d2688  vmovaps [rsp+0x60], xmm6
00007d3d957d268e  vmovaps [rsp+0x70], xmm7
00007d3d957d2694  vmovaps [rsp+0x80], xmm8
00007d3d957d269d  vmovaps [rsp+0x90], xmm9
00007d3d957d26a6  vmovaps [rsp+0xA0], xmm10
00007d3d957d26af  vmovaps [rsp+0xB0], xmm12
00007d3d957d26b8  vmovaps [rsp+0xC0], xmm13
00007d3d957d26c1  vmovaps [rsp+0xD0], xmm14
00007d3d957d26ca  vmovaps [rsp+0xE0], xmm15
00007d3d957d26d3  sub rsp, 0x30
00007d3d957d26d7  movaps [rsp], xmm11
00007d3d957d26dc  movaps [rsp+0x10], xmm6
00007d3d957d26e1  movaps [rsp+0x20], xmm14
00007d3d957d26e7  lea rdi, [rsp]
00007d3d957d26eb  mov esi, 0x00
00007d3d957d26f0  mov rax, 0x56C27CB8A530
00007d3d957d26fa  call rax
00007d3d957d26fc  movaps xmm11, [rsp]
00007d3d957d2701  add rsp, 0x30
00007d3d957d2705  vmovaps xmm0, [rsp]
00007d3d957d270a  vmovaps xmm1, [rsp+0x10]
00007d3d957d2710  vmovaps xmm2, [rsp+0x20]
00007d3d957d2716  vmovaps xmm3, [rsp+0x30]
00007d3d957d271c  vmovaps xmm4, [rsp+0x40]
00007d3d957d2722  vmovaps xmm5, [rsp+0x50]
00007d3d957d2728  vmovaps xmm6, [rsp+0x60]
00007d3d957d272e  vmovaps xmm7, [rsp+0x70]
00007d3d957d2734  vmovaps xmm8, [rsp+0x80]
00007d3d957d273d  vmovaps xmm9, [rsp+0x90]
00007d3d957d2746  vmovaps xmm10, [rsp+0xA0]
00007d3d957d274f  vmovaps xmm12, [rsp+0xB0]
00007d3d957d2758  vmovaps xmm13, [rsp+0xC0]
00007d3d957d2761  vmovaps xmm14, [rsp+0xD0]
00007d3d957d276a  vmovaps xmm15, [rsp+0xE0]
00007d3d957d2773  add rsp, 0xF0
00007d3d957d277a  pop r11
00007d3d957d277c  pop r10
00007d3d957d277e  pop r9
00007d3d957d2780  pop r8
00007d3d957d2782  pop rsi
00007d3d957d2783  pop rdi
00007d3d957d2784  pop rdx
00007d3d957d2785  pop rcx
00007d3d957d2786  pop rax
00007d3d957d2787  add rsp, 0x08
00007d3d957d278b  jmp 0x00007D3D957CFD34
00007d3d957d2790  call 0x00007D3D955FF430
00007d3d957d2795  jmp 0x00007D3D957CFD3E
00007d3d957d279a  sub rsp, 0x08
00007d3d957d279e  push rax
00007d3d957d279f  push rcx
00007d3d957d27a0  push rdx
00007d3d957d27a1  push rdi
00007d3d957d27a2  push rsi
00007d3d957d27a3  push r8
00007d3d957d27a5  push r9
00007d3d957d27a7  push r10
00007d3d957d27a9  push r11
00007d3d957d27ab  sub rsp, 0xF0
00007d3d957d27b2  vmovaps [rsp], xmm0
00007d3d957d27b7  vmovaps [rsp+0x10], xmm1
00007d3d957d27bd  vmovaps [rsp+0x20], xmm2
00007d3d957d27c3  vmovaps [rsp+0x30], xmm3
00007d3d957d27c9  vmovaps [rsp+0x40], xmm4
00007d3d957d27cf  vmovaps [rsp+0x50], xmm5
00007d3d957d27d5  vmovaps [rsp+0x60], xmm6
00007d3d957d27db  vmovaps [rsp+0x70], xmm7
00007d3d957d27e1  vmovaps [rsp+0x80], xmm8
00007d3d957d27ea  vmovaps [rsp+0x90], xmm9
00007d3d957d27f3  vmovaps [rsp+0xA0], xmm10
00007d3d957d27fc  vmovaps [rsp+0xB0], xmm11
00007d3d957d2805  vmovaps [rsp+0xC0], xmm12
00007d3d957d280e  vmovaps [rsp+0xD0], xmm13
00007d3d957d2817  vmovaps [rsp+0xE0], xmm15
00007d3d957d2820  sub rsp, 0x30
00007d3d957d2824  movaps [rsp], xmm14
00007d3d957d2829  movaps [rsp+0x10], xmm6
00007d3d957d282e  movaps [rsp+0x20], xmm2
00007d3d957d2833  lea rdi, [rsp]
00007d3d957d2837  mov esi, 0x00
00007d3d957d283c  mov rax, 0x56C27CB8A530
00007d3d957d2846  call rax
00007d3d957d2848  movaps xmm14, [rsp]
00007d3d957d284d  add rsp, 0x30
00007d3d957d2851  vmovaps xmm0, [rsp]
00007d3d957d2856  vmovaps xmm1, [rsp+0x10]
00007d3d957d285c  vmovaps xmm2, [rsp+0x20]
00007d3d957d2862  vmovaps xmm3, [rsp+0x30]
00007d3d957d2868  vmovaps xmm4, [rsp+0x40]
00007d3d957d286e  vmovaps xmm5, [rsp+0x50]
00007d3d957d2874  vmovaps xmm6, [rsp+0x60]
00007d3d957d287a  vmovaps xmm7, [rsp+0x70]
00007d3d957d2880  vmovaps xmm8, [rsp+0x80]
00007d3d957d2889  vmovaps xmm9, [rsp+0x90]
00007d3d957d2892  vmovaps xmm10, [rsp+0xA0]
00007d3d957d289b  vmovaps xmm11, [rsp+0xB0]
00007d3d957d28a4  vmovaps xmm12, [rsp+0xC0]
00007d3d957d28ad  vmovaps xmm13, [rsp+0xD0]
00007d3d957d28b6  vmovaps xmm15, [rsp+0xE0]
00007d3d957d28bf  add rsp, 0xF0
00007d3d957d28c6  pop r11
00007d3d957d28c8  pop r10
00007d3d957d28ca  pop r9
00007d3d957d28cc  pop r8
00007d3d957d28ce  pop rsi
00007d3d957d28cf  pop rdi
00007d3d957d28d0  pop rdx
00007d3d957d28d1  pop rcx
00007d3d957d28d2  pop rax
00007d3d957d28d3  add rsp, 0x08
00007d3d957d28d7  jmp 0x00007D3D957CFD72
00007d3d957d28dc  sub rsp, 0x08
00007d3d957d28e0  push rax
00007d3d957d28e1  push rcx
00007d3d957d28e2  push rdx
00007d3d957d28e3  push rdi
00007d3d957d28e4  push rsi
00007d3d957d28e5  push r8
00007d3d957d28e7  push r9
00007d3d957d28e9  push r10
00007d3d957d28eb  push r11
00007d3d957d28ed  sub rsp, 0xF0
00007d3d957d28f4  vmovaps [rsp], xmm0
00007d3d957d28f9  vmovaps [rsp+0x10], xmm1
00007d3d957d28ff  vmovaps [rsp+0x20], xmm2
00007d3d957d2905  vmovaps [rsp+0x30], xmm3
00007d3d957d290b  vmovaps [rsp+0x40], xmm4
00007d3d957d2911  vmovaps [rsp+0x50], xmm5
00007d3d957d2917  vmovaps [rsp+0x60], xmm7
00007d3d957d291d  vmovaps [rsp+0x70], xmm8
00007d3d957d2923  vmovaps [rsp+0x80], xmm9
00007d3d957d292c  vmovaps [rsp+0x90], xmm10
00007d3d957d2935  vmovaps [rsp+0xA0], xmm11
00007d3d957d293e  vmovaps [rsp+0xB0], xmm12
00007d3d957d2947  vmovaps [rsp+0xC0], xmm13
00007d3d957d2950  vmovaps [rsp+0xD0], xmm14
00007d3d957d2959  vmovaps [rsp+0xE0], xmm15
00007d3d957d2962  sub rsp, 0x30
00007d3d957d2966  movaps [rsp], xmm6
00007d3d957d296a  movaps [rsp+0x10], xmm5
00007d3d957d296f  movaps [rsp+0x20], xmm1
00007d3d957d2974  lea rdi, [rsp]
00007d3d957d2978  mov esi, 0x00
00007d3d957d297d  mov rax, 0x56C27CB8A530
00007d3d957d2987  call rax
00007d3d957d2989  movaps xmm6, [rsp]
00007d3d957d298d  add rsp, 0x30
00007d3d957d2991  vmovaps xmm0, [rsp]
00007d3d957d2996  vmovaps xmm1, [rsp+0x10]
00007d3d957d299c  vmovaps xmm2, [rsp+0x20]
00007d3d957d29a2  vmovaps xmm3, [rsp+0x30]
00007d3d957d29a8  vmovaps xmm4, [rsp+0x40]
00007d3d957d29ae  vmovaps xmm5, [rsp+0x50]
00007d3d957d29b4  vmovaps xmm7, [rsp+0x60]
00007d3d957d29ba  vmovaps xmm8, [rsp+0x70]
00007d3d957d29c0  vmovaps xmm9, [rsp+0x80]
00007d3d957d29c9  vmovaps xmm10, [rsp+0x90]
00007d3d957d29d2  vmovaps xmm11, [rsp+0xA0]
00007d3d957d29db  vmovaps xmm12, [rsp+0xB0]
00007d3d957d29e4  vmovaps xmm13, [rsp+0xC0]
00007d3d957d29ed  vmovaps xmm14, [rsp+0xD0]
00007d3d957d29f6  vmovaps xmm15, [rsp+0xE0]
00007d3d957d29ff  add rsp, 0xF0
00007d3d957d2a06  pop r11
00007d3d957d2a08  pop r10
00007d3d957d2a0a  pop r9
00007d3d957d2a0c  pop r8
00007d3d957d2a0e  pop rsi
00007d3d957d2a0f  pop rdi
00007d3d957d2a10  pop rdx
00007d3d957d2a11  pop rcx
00007d3d957d2a12  pop rax
00007d3d957d2a13  add rsp, 0x08
00007d3d957d2a17  jmp 0x00007D3D957CFD98
00007d3d957d2a1c  sub rsp, 0x08
00007d3d957d2a20  push rax
00007d3d957d2a21  push rcx
00007d3d957d2a22  push rdx
00007d3d957d2a23  push rdi
00007d3d957d2a24  push rsi
00007d3d957d2a25  push r8
00007d3d957d2a27  push r9
00007d3d957d2a29  push r10
00007d3d957d2a2b  push r11
00007d3d957d2a2d  sub rsp, 0xF0
00007d3d957d2a34  vmovaps [rsp], xmm0
00007d3d957d2a39  vmovaps [rsp+0x10], xmm2
00007d3d957d2a3f  vmovaps [rsp+0x20], xmm3
00007d3d957d2a45  vmovaps [rsp+0x30], xmm4
00007d3d957d2a4b  vmovaps [rsp+0x40], xmm5
00007d3d957d2a51  vmovaps [rsp+0x50], xmm6
00007d3d957d2a57  vmovaps [rsp+0x60], xmm7
00007d3d957d2a5d  vmovaps [rsp+0x70], xmm8
00007d3d957d2a63  vmovaps [rsp+0x80], xmm9
00007d3d957d2a6c  vmovaps [rsp+0x90], xmm10
00007d3d957d2a75  vmovaps [rsp+0xA0], xmm11
00007d3d957d2a7e  vmovaps [rsp+0xB0], xmm12
00007d3d957d2a87  vmovaps [rsp+0xC0], xmm13
00007d3d957d2a90  vmovaps [rsp+0xD0], xmm14
00007d3d957d2a99  vmovaps [rsp+0xE0], xmm15
00007d3d957d2aa2  sub rsp, 0x30
00007d3d957d2aa6  movaps [rsp], xmm1
00007d3d957d2aaa  movaps [rsp+0x10], xmm5
00007d3d957d2aaf  movaps [rsp+0x20], xmm13
00007d3d957d2ab5  lea rdi, [rsp]
00007d3d957d2ab9  mov esi, 0x00
00007d3d957d2abe  mov rax, 0x56C27CB8A530
00007d3d957d2ac8  call rax
00007d3d957d2aca  movaps xmm1, [rsp]
00007d3d957d2ace  add rsp, 0x30
00007d3d957d2ad2  vmovaps xmm0, [rsp]
00007d3d957d2ad7  vmovaps xmm2, [rsp+0x10]
00007d3d957d2add  vmovaps xmm3, [rsp+0x20]
00007d3d957d2ae3  vmovaps xmm4, [rsp+0x30]
00007d3d957d2ae9  vmovaps xmm5, [rsp+0x40]
00007d3d957d2aef  vmovaps xmm6, [rsp+0x50]
00007d3d957d2af5  vmovaps xmm7, [rsp+0x60]
00007d3d957d2afb  vmovaps xmm8, [rsp+0x70]
00007d3d957d2b01  vmovaps xmm9, [rsp+0x80]
00007d3d957d2b0a  vmovaps xmm10, [rsp+0x90]
00007d3d957d2b13  vmovaps xmm11, [rsp+0xA0]
00007d3d957d2b1c  vmovaps xmm12, [rsp+0xB0]
00007d3d957d2b25  vmovaps xmm13, [rsp+0xC0]
00007d3d957d2b2e  vmovaps xmm14, [rsp+0xD0]
00007d3d957d2b37  vmovaps xmm15, [rsp+0xE0]
00007d3d957d2b40  add rsp, 0xF0
00007d3d957d2b47  pop r11
00007d3d957d2b49  pop r10
00007d3d957d2b4b  pop r9
00007d3d957d2b4d  pop r8
00007d3d957d2b4f  pop rsi
00007d3d957d2b50  pop rdi
00007d3d957d2b51  pop rdx
00007d3d957d2b52  pop rcx
00007d3d957d2b53  pop rax
00007d3d957d2b54  add rsp, 0x08
00007d3d957d2b58  jmp 0x00007D3D957CFDB6
00007d3d957d2b5d  sub rsp, 0x08
00007d3d957d2b61  push rax
00007d3d957d2b62  push rcx
00007d3d957d2b63  push rdx
00007d3d957d2b64  push rdi
00007d3d957d2b65  push rsi
00007d3d957d2b66  push r8
00007d3d957d2b68  push r9
00007d3d957d2b6a  push r10
00007d3d957d2b6c  push r11
00007d3d957d2b6e  sub rsp, 0xF0
00007d3d957d2b75  vmovaps [rsp], xmm0
00007d3d957d2b7a  vmovaps [rsp+0x10], xmm1
00007d3d957d2b80  vmovaps [rsp+0x20], xmm2
00007d3d957d2b86  vmovaps [rsp+0x30], xmm3
00007d3d957d2b8c  vmovaps [rsp+0x40], xmm4
00007d3d957d2b92  vmovaps [rsp+0x50], xmm6
00007d3d957d2b98  vmovaps [rsp+0x60], xmm7
00007d3d957d2b9e  vmovaps [rsp+0x70], xmm8
00007d3d957d2ba4  vmovaps [rsp+0x80], xmm9
00007d3d957d2bad  vmovaps [rsp+0x90], xmm10
00007d3d957d2bb6  vmovaps [rsp+0xA0], xmm11
00007d3d957d2bbf  vmovaps [rsp+0xB0], xmm12
00007d3d957d2bc8  vmovaps [rsp+0xC0], xmm13
00007d3d957d2bd1  vmovaps [rsp+0xD0], xmm14
00007d3d957d2bda  vmovaps [rsp+0xE0], xmm15
00007d3d957d2be3  sub rsp, 0x30
00007d3d957d2be7  movaps [rsp], xmm5
00007d3d957d2beb  movaps [rsp+0x10], xmm2
00007d3d957d2bf0  movaps [rsp+0x20], xmm13
00007d3d957d2bf6  lea rdi, [rsp]
00007d3d957d2bfa  mov esi, 0x00
00007d3d957d2bff  mov rax, 0x56C27CB8A530
00007d3d957d2c09  call rax
00007d3d957d2c0b  movaps xmm5, [rsp]
00007d3d957d2c0f  add rsp, 0x30
00007d3d957d2c13  vmovaps xmm0, [rsp]
00007d3d957d2c18  vmovaps xmm1, [rsp+0x10]
00007d3d957d2c1e  vmovaps xmm2, [rsp+0x20]
00007d3d957d2c24  vmovaps xmm3, [rsp+0x30]
00007d3d957d2c2a  vmovaps xmm4, [rsp+0x40]
00007d3d957d2c30  vmovaps xmm6, [rsp+0x50]
00007d3d957d2c36  vmovaps xmm7, [rsp+0x60]
00007d3d957d2c3c  vmovaps xmm8, [rsp+0x70]
00007d3d957d2c42  vmovaps xmm9, [rsp+0x80]
00007d3d957d2c4b  vmovaps xmm10, [rsp+0x90]
00007d3d957d2c54  vmovaps xmm11, [rsp+0xA0]
00007d3d957d2c5d  vmovaps xmm12, [rsp+0xB0]
00007d3d957d2c66  vmovaps xmm13, [rsp+0xC0]
00007d3d957d2c6f  vmovaps xmm14, [rsp+0xD0]
00007d3d957d2c78  vmovaps xmm15, [rsp+0xE0]
00007d3d957d2c81  add rsp, 0xF0
00007d3d957d2c88  pop r11
00007d3d957d2c8a  pop r10
00007d3d957d2c8c  pop r9
00007d3d957d2c8e  pop r8
00007d3d957d2c90  pop rsi
00007d3d957d2c91  pop rdi
00007d3d957d2c92  pop rdx
00007d3d957d2c93  pop rcx
00007d3d957d2c94  pop rax
00007d3d957d2c95  add rsp, 0x08
00007d3d957d2c99  jmp 0x00007D3D957CFDEC
00007d3d957d2c9e  sub rsp, 0x08
00007d3d957d2ca2  push rax
00007d3d957d2ca3  push rcx
00007d3d957d2ca4  push rdx
00007d3d957d2ca5  push rdi
00007d3d957d2ca6  push rsi
00007d3d957d2ca7  push r8
00007d3d957d2ca9  push r9
00007d3d957d2cab  push r10
00007d3d957d2cad  push r11
00007d3d957d2caf  sub rsp, 0xF0
00007d3d957d2cb6  vmovaps [rsp], xmm0
00007d3d957d2cbb  vmovaps [rsp+0x10], xmm1
00007d3d957d2cc1  vmovaps [rsp+0x20], xmm2
00007d3d957d2cc7  vmovaps [rsp+0x30], xmm3
00007d3d957d2ccd  vmovaps [rsp+0x40], xmm4
00007d3d957d2cd3  vmovaps [rsp+0x50], xmm5
00007d3d957d2cd9  vmovaps [rsp+0x60], xmm6
00007d3d957d2cdf  vmovaps [rsp+0x70], xmm7
00007d3d957d2ce5  vmovaps [rsp+0x80], xmm8
00007d3d957d2cee  vmovaps [rsp+0x90], xmm9
00007d3d957d2cf7  vmovaps [rsp+0xA0], xmm10
00007d3d957d2d00  vmovaps [rsp+0xB0], xmm11
00007d3d957d2d09  vmovaps [rsp+0xC0], xmm12
00007d3d957d2d12  vmovaps [rsp+0xD0], xmm14
00007d3d957d2d1b  vmovaps [rsp+0xE0], xmm15
00007d3d957d2d24  sub rsp, 0x30
00007d3d957d2d28  movaps [rsp], xmm13
00007d3d957d2d2d  movaps [rsp+0x10], xmm10
00007d3d957d2d33  movaps [rsp+0x20], xmm1
00007d3d957d2d38  lea rdi, [rsp]
00007d3d957d2d3c  mov esi, 0x00
00007d3d957d2d41  mov rax, 0x56C27CB8A530
00007d3d957d2d4b  call rax
00007d3d957d2d4d  movaps xmm13, [rsp]
00007d3d957d2d52  add rsp, 0x30
00007d3d957d2d56  vmovaps xmm0, [rsp]
00007d3d957d2d5b  vmovaps xmm1, [rsp+0x10]
00007d3d957d2d61  vmovaps xmm2, [rsp+0x20]
00007d3d957d2d67  vmovaps xmm3, [rsp+0x30]
00007d3d957d2d6d  vmovaps xmm4, [rsp+0x40]
00007d3d957d2d73  vmovaps xmm5, [rsp+0x50]
00007d3d957d2d79  vmovaps xmm6, [rsp+0x60]
00007d3d957d2d7f  vmovaps xmm7, [rsp+0x70]
00007d3d957d2d85  vmovaps xmm8, [rsp+0x80]
00007d3d957d2d8e  vmovaps xmm9, [rsp+0x90]
00007d3d957d2d97  vmovaps xmm10, [rsp+0xA0]
00007d3d957d2da0  vmovaps xmm11, [rsp+0xB0]
00007d3d957d2da9  vmovaps xmm12, [rsp+0xC0]
00007d3d957d2db2  vmovaps xmm14, [rsp+0xD0]
00007d3d957d2dbb  vmovaps xmm15, [rsp+0xE0]
00007d3d957d2dc4  add rsp, 0xF0
00007d3d957d2dcb  pop r11
00007d3d957d2dcd  pop r10
00007d3d957d2dcf  pop r9
00007d3d957d2dd1  pop r8
00007d3d957d2dd3  pop rsi
00007d3d957d2dd4  pop rdi
00007d3d957d2dd5  pop rdx
00007d3d957d2dd6  pop rcx
00007d3d957d2dd7  pop rax
00007d3d957d2dd8  add rsp, 0x08
00007d3d957d2ddc  jmp 0x00007D3D957CFE15
00007d3d957d2de1  sub rsp, 0x08
00007d3d957d2de5  push rax
00007d3d957d2de6  push rcx
00007d3d957d2de7  push rdx
00007d3d957d2de8  push rdi
00007d3d957d2de9  push rsi
00007d3d957d2dea  push r8
00007d3d957d2dec  push r9
00007d3d957d2dee  push r10
00007d3d957d2df0  push r11
00007d3d957d2df2  sub rsp, 0xF0
00007d3d957d2df9  vmovaps [rsp], xmm0
00007d3d957d2dfe  vmovaps [rsp+0x10], xmm2
00007d3d957d2e04  vmovaps [rsp+0x20], xmm3
00007d3d957d2e0a  vmovaps [rsp+0x30], xmm4
00007d3d957d2e10  vmovaps [rsp+0x40], xmm5
00007d3d957d2e16  vmovaps [rsp+0x50], xmm6
00007d3d957d2e1c  vmovaps [rsp+0x60], xmm7
00007d3d957d2e22  vmovaps [rsp+0x70], xmm8
00007d3d957d2e28  vmovaps [rsp+0x80], xmm9
00007d3d957d2e31  vmovaps [rsp+0x90], xmm10
00007d3d957d2e3a  vmovaps [rsp+0xA0], xmm11
00007d3d957d2e43  vmovaps [rsp+0xB0], xmm12
00007d3d957d2e4c  vmovaps [rsp+0xC0], xmm13
00007d3d957d2e55  vmovaps [rsp+0xD0], xmm14
00007d3d957d2e5e  vmovaps [rsp+0xE0], xmm15
00007d3d957d2e67  sub rsp, 0x30
00007d3d957d2e6b  movaps [rsp], xmm1
00007d3d957d2e6f  movaps [rsp+0x10], xmm15
00007d3d957d2e75  movaps [rsp+0x20], xmm10
00007d3d957d2e7b  lea rdi, [rsp]
00007d3d957d2e7f  mov esi, 0x00
00007d3d957d2e84  mov rax, 0x56C27CB8A530
00007d3d957d2e8e  call rax
00007d3d957d2e90  movaps xmm1, [rsp]
00007d3d957d2e94  add rsp, 0x30
00007d3d957d2e98  vmovaps xmm0, [rsp]
00007d3d957d2e9d  vmovaps xmm2, [rsp+0x10]
00007d3d957d2ea3  vmovaps xmm3, [rsp+0x20]
00007d3d957d2ea9  vmovaps xmm4, [rsp+0x30]
00007d3d957d2eaf  vmovaps xmm5, [rsp+0x40]
00007d3d957d2eb5  vmovaps xmm6, [rsp+0x50]
00007d3d957d2ebb  vmovaps xmm7, [rsp+0x60]
00007d3d957d2ec1  vmovaps xmm8, [rsp+0x70]
00007d3d957d2ec7  vmovaps xmm9, [rsp+0x80]
00007d3d957d2ed0  vmovaps xmm10, [rsp+0x90]
00007d3d957d2ed9  vmovaps xmm11, [rsp+0xA0]
00007d3d957d2ee2  vmovaps xmm12, [rsp+0xB0]
00007d3d957d2eeb  vmovaps xmm13, [rsp+0xC0]
00007d3d957d2ef4  vmovaps xmm14, [rsp+0xD0]
00007d3d957d2efd  vmovaps xmm15, [rsp+0xE0]
00007d3d957d2f06  add rsp, 0xF0
00007d3d957d2f0d  pop r11
00007d3d957d2f0f  pop r10
00007d3d957d2f11  pop r9
00007d3d957d2f13  pop r8
00007d3d957d2f15  pop rsi
00007d3d957d2f16  pop rdi
00007d3d957d2f17  pop rdx
00007d3d957d2f18  pop rcx
00007d3d957d2f19  pop rax
00007d3d957d2f1a  add rsp, 0x08
00007d3d957d2f1e  jmp 0x00007D3D957CFE34
00007d3d957d2f23  sub rsp, 0x08
00007d3d957d2f27  push rax
00007d3d957d2f28  push rcx
00007d3d957d2f29  push rdx
00007d3d957d2f2a  push rdi
00007d3d957d2f2b  push rsi
00007d3d957d2f2c  push r8
00007d3d957d2f2e  push r9
00007d3d957d2f30  push r10
00007d3d957d2f32  push r11
00007d3d957d2f34  sub rsp, 0xF0
00007d3d957d2f3b  vmovaps [rsp], xmm0
00007d3d957d2f40  vmovaps [rsp+0x10], xmm1
00007d3d957d2f46  vmovaps [rsp+0x20], xmm2
00007d3d957d2f4c  vmovaps [rsp+0x30], xmm3
00007d3d957d2f52  vmovaps [rsp+0x40], xmm4
00007d3d957d2f58  vmovaps [rsp+0x50], xmm5
00007d3d957d2f5e  vmovaps [rsp+0x60], xmm6
00007d3d957d2f64  vmovaps [rsp+0x70], xmm7
00007d3d957d2f6a  vmovaps [rsp+0x80], xmm8
00007d3d957d2f73  vmovaps [rsp+0x90], xmm9
00007d3d957d2f7c  vmovaps [rsp+0xA0], xmm10
00007d3d957d2f85  vmovaps [rsp+0xB0], xmm11
00007d3d957d2f8e  vmovaps [rsp+0xC0], xmm12
00007d3d957d2f97  vmovaps [rsp+0xD0], xmm13
00007d3d957d2fa0  vmovaps [rsp+0xE0], xmm14
00007d3d957d2fa9  sub rsp, 0x30
00007d3d957d2fad  movaps [rsp], xmm15
00007d3d957d2fb2  movaps [rsp+0x10], xmm10
00007d3d957d2fb8  movaps [rsp+0x20], xmm11
00007d3d957d2fbe  lea rdi, [rsp]
00007d3d957d2fc2  mov esi, 0x00
00007d3d957d2fc7  mov rax, 0x56C27CB8A530
00007d3d957d2fd1  call rax
00007d3d957d2fd3  movaps xmm15, [rsp]
00007d3d957d2fd8  add rsp, 0x30
00007d3d957d2fdc  vmovaps xmm0, [rsp]
00007d3d957d2fe1  vmovaps xmm1, [rsp+0x10]
00007d3d957d2fe7  vmovaps xmm2, [rsp+0x20]
00007d3d957d2fed  vmovaps xmm3, [rsp+0x30]
00007d3d957d2ff3  vmovaps xmm4, [rsp+0x40]
00007d3d957d2ff9  vmovaps xmm5, [rsp+0x50]
00007d3d957d2fff  vmovaps xmm6, [rsp+0x60]
00007d3d957d3005  vmovaps xmm7, [rsp+0x70]
00007d3d957d300b  vmovaps xmm8, [rsp+0x80]
00007d3d957d3014  vmovaps xmm9, [rsp+0x90]
00007d3d957d301d  vmovaps xmm10, [rsp+0xA0]
00007d3d957d3026  vmovaps xmm11, [rsp+0xB0]
00007d3d957d302f  vmovaps xmm12, [rsp+0xC0]
00007d3d957d3038  vmovaps xmm13, [rsp+0xD0]
00007d3d957d3041  vmovaps xmm14, [rsp+0xE0]
00007d3d957d304a  add rsp, 0xF0
00007d3d957d3051  pop r11
00007d3d957d3053  pop r10
00007d3d957d3055  pop r9
00007d3d957d3057  pop r8
00007d3d957d3059  pop rsi
00007d3d957d305a  pop rdi
00007d3d957d305b  pop rdx
00007d3d957d305c  pop rcx
00007d3d957d305d  pop rax
00007d3d957d305e  add rsp, 0x08
00007d3d957d3062  jmp 0x00007D3D957CFE57
00007d3d957d3067  sub rsp, 0x08
00007d3d957d306b  push rax
00007d3d957d306c  push rcx
00007d3d957d306d  push rdx
00007d3d957d306e  push rdi
00007d3d957d306f  push rsi
00007d3d957d3070  push r8
00007d3d957d3072  push r9
00007d3d957d3074  push r10
00007d3d957d3076  push r11
00007d3d957d3078  sub rsp, 0xF0
00007d3d957d307f  vmovaps [rsp], xmm0
00007d3d957d3084  vmovaps [rsp+0x10], xmm1
00007d3d957d308a  vmovaps [rsp+0x20], xmm2
00007d3d957d3090  vmovaps [rsp+0x30], xmm3
00007d3d957d3096  vmovaps [rsp+0x40], xmm4
00007d3d957d309c  vmovaps [rsp+0x50], xmm5
00007d3d957d30a2  vmovaps [rsp+0x60], xmm6
00007d3d957d30a8  vmovaps [rsp+0x70], xmm7
00007d3d957d30ae  vmovaps [rsp+0x80], xmm8
00007d3d957d30b7  vmovaps [rsp+0x90], xmm9
00007d3d957d30c0  vmovaps [rsp+0xA0], xmm11
00007d3d957d30c9  vmovaps [rsp+0xB0], xmm12
00007d3d957d30d2  vmovaps [rsp+0xC0], xmm13
00007d3d957d30db  vmovaps [rsp+0xD0], xmm14
00007d3d957d30e4  vmovaps [rsp+0xE0], xmm15
00007d3d957d30ed  sub rsp, 0x30
00007d3d957d30f1  movaps [rsp], xmm10
00007d3d957d30f6  movaps [rsp+0x10], xmm12
00007d3d957d30fc  movaps [rsp+0x20], xmm11
00007d3d957d3102  lea rdi, [rsp]
00007d3d957d3106  mov esi, 0x00
00007d3d957d310b  mov rax, 0x56C27CB8A530
00007d3d957d3115  call rax
00007d3d957d3117  movaps xmm10, [rsp]
00007d3d957d311c  add rsp, 0x30
00007d3d957d3120  vmovaps xmm0, [rsp]
00007d3d957d3125  vmovaps xmm1, [rsp+0x10]
00007d3d957d312b  vmovaps xmm2, [rsp+0x20]
00007d3d957d3131  vmovaps xmm3, [rsp+0x30]
00007d3d957d3137  vmovaps xmm4, [rsp+0x40]
00007d3d957d313d  vmovaps xmm5, [rsp+0x50]
00007d3d957d3143  vmovaps xmm6, [rsp+0x60]
00007d3d957d3149  vmovaps xmm7, [rsp+0x70]
00007d3d957d314f  vmovaps xmm8, [rsp+0x80]
00007d3d957d3158  vmovaps xmm9, [rsp+0x90]
00007d3d957d3161  vmovaps xmm11, [rsp+0xA0]
00007d3d957d316a  vmovaps xmm12, [rsp+0xB0]
00007d3d957d3173  vmovaps xmm13, [rsp+0xC0]
00007d3d957d317c  vmovaps xmm14, [rsp+0xD0]
00007d3d957d3185  vmovaps xmm15, [rsp+0xE0]
00007d3d957d318e  add rsp, 0xF0
00007d3d957d3195  pop r11
00007d3d957d3197  pop r10
00007d3d957d3199  pop r9
00007d3d957d319b  pop r8
00007d3d957d319d  pop rsi
00007d3d957d319e  pop rdi
00007d3d957d319f  pop rdx
00007d3d957d31a0  pop rcx
00007d3d957d31a1  pop rax
00007d3d957d31a2  add rsp, 0x08
00007d3d957d31a6  jmp 0x00007D3D957CFE80
00007d3d957d31ab  sub rsp, 0x08
00007d3d957d31af  push rax
00007d3d957d31b0  push rcx
00007d3d957d31b1  push rdx
00007d3d957d31b2  push rdi
00007d3d957d31b3  push rsi
00007d3d957d31b4  push r8
00007d3d957d31b6  push r9
00007d3d957d31b8  push r10
00007d3d957d31ba  push r11
00007d3d957d31bc  sub rsp, 0xF0
00007d3d957d31c3  vmovaps [rsp], xmm0
00007d3d957d31c8  vmovaps [rsp+0x10], xmm1
00007d3d957d31ce  vmovaps [rsp+0x20], xmm2
00007d3d957d31d4  vmovaps [rsp+0x30], xmm3
00007d3d957d31da  vmovaps [rsp+0x40], xmm4
00007d3d957d31e0  vmovaps [rsp+0x50], xmm5
00007d3d957d31e6  vmovaps [rsp+0x60], xmm6
00007d3d957d31ec  vmovaps [rsp+0x70], xmm7
00007d3d957d31f2  vmovaps [rsp+0x80], xmm8
00007d3d957d31fb  vmovaps [rsp+0x90], xmm9
00007d3d957d3204  vmovaps [rsp+0xA0], xmm10
00007d3d957d320d  vmovaps [rsp+0xB0], xmm12
00007d3d957d3216  vmovaps [rsp+0xC0], xmm13
00007d3d957d321f  vmovaps [rsp+0xD0], xmm14
00007d3d957d3228  vmovaps [rsp+0xE0], xmm15
00007d3d957d3231  sub rsp, 0x30
00007d3d957d3235  movaps [rsp], xmm11
00007d3d957d323a  movaps [rsp+0x10], xmm2
00007d3d957d323f  movaps [rsp+0x20], xmm12
00007d3d957d3245  lea rdi, [rsp]
00007d3d957d3249  mov esi, 0x00
00007d3d957d324e  mov rax, 0x56C27CB8A530
00007d3d957d3258  call rax
00007d3d957d325a  movaps xmm11, [rsp]
00007d3d957d325f  add rsp, 0x30
00007d3d957d3263  vmovaps xmm0, [rsp]
00007d3d957d3268  vmovaps xmm1, [rsp+0x10]
00007d3d957d326e  vmovaps xmm2, [rsp+0x20]
00007d3d957d3274  vmovaps xmm3, [rsp+0x30]
00007d3d957d327a  vmovaps xmm4, [rsp+0x40]
00007d3d957d3280  vmovaps xmm5, [rsp+0x50]
00007d3d957d3286  vmovaps xmm6, [rsp+0x60]
00007d3d957d328c  vmovaps xmm7, [rsp+0x70]
00007d3d957d3292  vmovaps xmm8, [rsp+0x80]
00007d3d957d329b  vmovaps xmm9, [rsp+0x90]
00007d3d957d32a4  vmovaps xmm10, [rsp+0xA0]
00007d3d957d32ad  vmovaps xmm12, [rsp+0xB0]
00007d3d957d32b6  vmovaps xmm13, [rsp+0xC0]
00007d3d957d32bf  vmovaps xmm14, [rsp+0xD0]
00007d3d957d32c8  vmovaps xmm15, [rsp+0xE0]
00007d3d957d32d1  add rsp, 0xF0
00007d3d957d32d8  pop r11
00007d3d957d32da  pop r10
00007d3d957d32dc  pop r9
00007d3d957d32de  pop r8
00007d3d957d32e0  pop rsi
00007d3d957d32e1  pop rdi
00007d3d957d32e2  pop rdx
00007d3d957d32e3  pop rcx
00007d3d957d32e4  pop rax
00007d3d957d32e5  add rsp, 0x08
00007d3d957d32e9  jmp 0x00007D3D957CFEB8
00007d3d957d32ee  sub rsp, 0x08
00007d3d957d32f2  push rax
00007d3d957d32f3  push rcx
00007d3d957d32f4  push rdx
00007d3d957d32f5  push rdi
00007d3d957d32f6  push rsi
00007d3d957d32f7  push r8
00007d3d957d32f9  push r9
00007d3d957d32fb  push r10
00007d3d957d32fd  push r11
00007d3d957d32ff  sub rsp, 0xF0
00007d3d957d3306  vmovaps [rsp], xmm0
00007d3d957d330b  vmovaps [rsp+0x10], xmm2
00007d3d957d3311  vmovaps [rsp+0x20], xmm3
00007d3d957d3317  vmovaps [rsp+0x30], xmm4
00007d3d957d331d  vmovaps [rsp+0x40], xmm5
00007d3d957d3323  vmovaps [rsp+0x50], xmm6
00007d3d957d3329  vmovaps [rsp+0x60], xmm7
00007d3d957d332f  vmovaps [rsp+0x70], xmm8
00007d3d957d3335  vmovaps [rsp+0x80], xmm9
00007d3d957d333e  vmovaps [rsp+0x90], xmm10
00007d3d957d3347  vmovaps [rsp+0xA0], xmm11
00007d3d957d3350  vmovaps [rsp+0xB0], xmm12
00007d3d957d3359  vmovaps [rsp+0xC0], xmm13
00007d3d957d3362  vmovaps [rsp+0xD0], xmm14
00007d3d957d336b  vmovaps [rsp+0xE0], xmm15
00007d3d957d3374  sub rsp, 0x30
00007d3d957d3378  movaps [rsp], xmm1
00007d3d957d337c  movaps [rsp+0x10], xmm14
00007d3d957d3382  movaps [rsp+0x20], xmm6
00007d3d957d3387  lea rdi, [rsp]
00007d3d957d338b  mov esi, 0x00
00007d3d957d3390  mov rax, 0x56C27CB8A530
00007d3d957d339a  call rax
00007d3d957d339c  movaps xmm1, [rsp]
00007d3d957d33a0  add rsp, 0x30
00007d3d957d33a4  vmovaps xmm0, [rsp]
00007d3d957d33a9  vmovaps xmm2, [rsp+0x10]
00007d3d957d33af  vmovaps xmm3, [rsp+0x20]
00007d3d957d33b5  vmovaps xmm4, [rsp+0x30]
00007d3d957d33bb  vmovaps xmm5, [rsp+0x40]
00007d3d957d33c1  vmovaps xmm6, [rsp+0x50]
00007d3d957d33c7  vmovaps xmm7, [rsp+0x60]
00007d3d957d33cd  vmovaps xmm8, [rsp+0x70]
00007d3d957d33d3  vmovaps xmm9, [rsp+0x80]
00007d3d957d33dc  vmovaps xmm10, [rsp+0x90]
00007d3d957d33e5  vmovaps xmm11, [rsp+0xA0]
00007d3d957d33ee  vmovaps xmm12, [rsp+0xB0]
00007d3d957d33f7  vmovaps xmm13, [rsp+0xC0]
00007d3d957d3400  vmovaps xmm14, [rsp+0xD0]
00007d3d957d3409  vmovaps xmm15, [rsp+0xE0]
00007d3d957d3412  add rsp, 0xF0
00007d3d957d3419  pop r11
00007d3d957d341b  pop r10
00007d3d957d341d  pop r9
00007d3d957d341f  pop r8
00007d3d957d3421  pop rsi
00007d3d957d3422  pop rdi
00007d3d957d3423  pop rdx
00007d3d957d3424  pop rcx
00007d3d957d3425  pop rax
00007d3d957d3426  add rsp, 0x08
00007d3d957d342a  jmp 0x00007D3D957CFED1
00007d3d957d342f  sub rsp, 0x08
00007d3d957d3433  push rax
00007d3d957d3434  push rcx
00007d3d957d3435  push rdx
00007d3d957d3436  push rdi
00007d3d957d3437  push rsi
00007d3d957d3438  push r8
00007d3d957d343a  push r9
00007d3d957d343c  push r10
00007d3d957d343e  push r11
00007d3d957d3440  sub rsp, 0xF0
00007d3d957d3447  vmovaps [rsp], xmm0
00007d3d957d344c  vmovaps [rsp+0x10], xmm1
00007d3d957d3452  vmovaps [rsp+0x20], xmm2
00007d3d957d3458  vmovaps [rsp+0x30], xmm3
00007d3d957d345e  vmovaps [rsp+0x40], xmm4
00007d3d957d3464  vmovaps [rsp+0x50], xmm5
00007d3d957d346a  vmovaps [rsp+0x60], xmm6
00007d3d957d3470  vmovaps [rsp+0x70], xmm7
00007d3d957d3476  vmovaps [rsp+0x80], xmm8
00007d3d957d347f  vmovaps [rsp+0x90], xmm9
00007d3d957d3488  vmovaps [rsp+0xA0], xmm10
00007d3d957d3491  vmovaps [rsp+0xB0], xmm11
00007d3d957d349a  vmovaps [rsp+0xC0], xmm12
00007d3d957d34a3  vmovaps [rsp+0xD0], xmm13
00007d3d957d34ac  vmovaps [rsp+0xE0], xmm15
00007d3d957d34b5  sub rsp, 0x30
00007d3d957d34b9  movaps [rsp], xmm14
00007d3d957d34be  movaps [rsp+0x10], xmm12
00007d3d957d34c4  movaps [rsp+0x20], xmm5
00007d3d957d34c9  lea rdi, [rsp]
00007d3d957d34cd  mov esi, 0x00
00007d3d957d34d2  mov rax, 0x56C27CB8A530
00007d3d957d34dc  call rax
00007d3d957d34de  movaps xmm14, [rsp]
00007d3d957d34e3  add rsp, 0x30
00007d3d957d34e7  vmovaps xmm0, [rsp]
00007d3d957d34ec  vmovaps xmm1, [rsp+0x10]
00007d3d957d34f2  vmovaps xmm2, [rsp+0x20]
00007d3d957d34f8  vmovaps xmm3, [rsp+0x30]
00007d3d957d34fe  vmovaps xmm4, [rsp+0x40]
00007d3d957d3504  vmovaps xmm5, [rsp+0x50]
00007d3d957d350a  vmovaps xmm6, [rsp+0x60]
00007d3d957d3510  vmovaps xmm7, [rsp+0x70]
00007d3d957d3516  vmovaps xmm8, [rsp+0x80]
00007d3d957d351f  vmovaps xmm9, [rsp+0x90]
00007d3d957d3528  vmovaps xmm10, [rsp+0xA0]
00007d3d957d3531  vmovaps xmm11, [rsp+0xB0]
00007d3d957d353a  vmovaps xmm12, [rsp+0xC0]
00007d3d957d3543  vmovaps xmm13, [rsp+0xD0]
00007d3d957d354c  vmovaps xmm15, [rsp+0xE0]
00007d3d957d3555  add rsp, 0xF0
00007d3d957d355c  pop r11
00007d3d957d355e  pop r10
00007d3d957d3560  pop r9
00007d3d957d3562  pop r8
00007d3d957d3564  pop rsi
00007d3d957d3565  pop rdi
00007d3d957d3566  pop rdx
00007d3d957d3567  pop rcx
00007d3d957d3568  pop rax
00007d3d957d3569  add rsp, 0x08
00007d3d957d356d  jmp 0x00007D3D957CFEF1
00007d3d957d3572  sub rsp, 0x08
00007d3d957d3576  push rax
00007d3d957d3577  push rcx
00007d3d957d3578  push rdx
00007d3d957d3579  push rdi
00007d3d957d357a  push rsi
00007d3d957d357b  push r8
00007d3d957d357d  push r9
00007d3d957d357f  push r10
00007d3d957d3581  push r11
00007d3d957d3583  sub rsp, 0xF0
00007d3d957d358a  vmovaps [rsp], xmm0
00007d3d957d358f  vmovaps [rsp+0x10], xmm1
00007d3d957d3595  vmovaps [rsp+0x20], xmm2
00007d3d957d359b  vmovaps [rsp+0x30], xmm3
00007d3d957d35a1  vmovaps [rsp+0x40], xmm4
00007d3d957d35a7  vmovaps [rsp+0x50], xmm5
00007d3d957d35ad  vmovaps [rsp+0x60], xmm7
00007d3d957d35b3  vmovaps [rsp+0x70], xmm8
00007d3d957d35b9  vmovaps [rsp+0x80], xmm9
00007d3d957d35c2  vmovaps [rsp+0x90], xmm10
00007d3d957d35cb  vmovaps [rsp+0xA0], xmm11
00007d3d957d35d4  vmovaps [rsp+0xB0], xmm12
00007d3d957d35dd  vmovaps [rsp+0xC0], xmm13
00007d3d957d35e6  vmovaps [rsp+0xD0], xmm14
00007d3d957d35ef  vmovaps [rsp+0xE0], xmm15
00007d3d957d35f8  sub rsp, 0x30
00007d3d957d35fc  movaps [rsp], xmm6
00007d3d957d3600  movaps [rsp+0x10], xmm9
00007d3d957d3606  movaps [rsp+0x20], xmm12
00007d3d957d360c  lea rdi, [rsp]
00007d3d957d3610  mov esi, 0x00
00007d3d957d3615  mov rax, 0x56C27CB8A530
00007d3d957d361f  call rax
00007d3d957d3621  movaps xmm6, [rsp]
00007d3d957d3625  add rsp, 0x30
00007d3d957d3629  vmovaps xmm0, [rsp]
00007d3d957d362e  vmovaps xmm1, [rsp+0x10]
00007d3d957d3634  vmovaps xmm2, [rsp+0x20]
00007d3d957d363a  vmovaps xmm3, [rsp+0x30]
00007d3d957d3640  vmovaps xmm4, [rsp+0x40]
00007d3d957d3646  vmovaps xmm5, [rsp+0x50]
00007d3d957d364c  vmovaps xmm7, [rsp+0x60]
00007d3d957d3652  vmovaps xmm8, [rsp+0x70]
00007d3d957d3658  vmovaps xmm9, [rsp+0x80]
00007d3d957d3661  vmovaps xmm10, [rsp+0x90]
00007d3d957d366a  vmovaps xmm11, [rsp+0xA0]
00007d3d957d3673  vmovaps xmm12, [rsp+0xB0]
00007d3d957d367c  vmovaps xmm13, [rsp+0xC0]
00007d3d957d3685  vmovaps xmm14, [rsp+0xD0]
00007d3d957d368e  vmovaps xmm15, [rsp+0xE0]
00007d3d957d3697  add rsp, 0xF0
00007d3d957d369e  pop r11
00007d3d957d36a0  pop r10
00007d3d957d36a2  pop r9
00007d3d957d36a4  pop r8
00007d3d957d36a6  pop rsi
00007d3d957d36a7  pop rdi
00007d3d957d36a8  pop rdx
00007d3d957d36a9  pop rcx
00007d3d957d36aa  pop rax
00007d3d957d36ab  add rsp, 0x08
00007d3d957d36af  jmp 0x00007D3D957CFF19
00007d3d957d36b4  sub rsp, 0x08
00007d3d957d36b8  push rax
00007d3d957d36b9  push rcx
00007d3d957d36ba  push rdx
00007d3d957d36bb  push rdi
00007d3d957d36bc  push rsi
00007d3d957d36bd  push r8
00007d3d957d36bf  push r9
00007d3d957d36c1  push r10
00007d3d957d36c3  push r11
00007d3d957d36c5  sub rsp, 0xF0
00007d3d957d36cc  vmovaps [rsp], xmm0
00007d3d957d36d1  vmovaps [rsp+0x10], xmm1
00007d3d957d36d7  vmovaps [rsp+0x20], xmm2
00007d3d957d36dd  vmovaps [rsp+0x30], xmm3
00007d3d957d36e3  vmovaps [rsp+0x40], xmm4
00007d3d957d36e9  vmovaps [rsp+0x50], xmm5
00007d3d957d36ef  vmovaps [rsp+0x60], xmm6
00007d3d957d36f5  vmovaps [rsp+0x70], xmm7
00007d3d957d36fb  vmovaps [rsp+0x80], xmm8
00007d3d957d3704  vmovaps [rsp+0x90], xmm9
00007d3d957d370d  vmovaps [rsp+0xA0], xmm10
00007d3d957d3716  vmovaps [rsp+0xB0], xmm11
00007d3d957d371f  vmovaps [rsp+0xC0], xmm13
00007d3d957d3728  vmovaps [rsp+0xD0], xmm14
00007d3d957d3731  vmovaps [rsp+0xE0], xmm15
00007d3d957d373a  sub rsp, 0x30
00007d3d957d373e  movaps [rsp], xmm12
00007d3d957d3743  movaps [rsp+0x10], xmm15
00007d3d957d3749  movaps [rsp+0x20], xmm13
00007d3d957d374f  lea rdi, [rsp]
00007d3d957d3753  mov esi, 0x00
00007d3d957d3758  mov rax, 0x56C27CB8A530
00007d3d957d3762  call rax
00007d3d957d3764  movaps xmm12, [rsp]
00007d3d957d3769  add rsp, 0x30
00007d3d957d376d  vmovaps xmm0, [rsp]
00007d3d957d3772  vmovaps xmm1, [rsp+0x10]
00007d3d957d3778  vmovaps xmm2, [rsp+0x20]
00007d3d957d377e  vmovaps xmm3, [rsp+0x30]
00007d3d957d3784  vmovaps xmm4, [rsp+0x40]
00007d3d957d378a  vmovaps xmm5, [rsp+0x50]
00007d3d957d3790  vmovaps xmm6, [rsp+0x60]
00007d3d957d3796  vmovaps xmm7, [rsp+0x70]
00007d3d957d379c  vmovaps xmm8, [rsp+0x80]
00007d3d957d37a5  vmovaps xmm9, [rsp+0x90]
00007d3d957d37ae  vmovaps xmm10, [rsp+0xA0]
00007d3d957d37b7  vmovaps xmm11, [rsp+0xB0]
00007d3d957d37c0  vmovaps xmm13, [rsp+0xC0]
00007d3d957d37c9  vmovaps xmm14, [rsp+0xD0]
00007d3d957d37d2  vmovaps xmm15, [rsp+0xE0]
00007d3d957d37db  add rsp, 0xF0
00007d3d957d37e2  pop r11
00007d3d957d37e4  pop r10
00007d3d957d37e6  pop r9
00007d3d957d37e8  pop r8
00007d3d957d37ea  pop rsi
00007d3d957d37eb  pop rdi
00007d3d957d37ec  pop rdx
00007d3d957d37ed  pop rcx
00007d3d957d37ee  pop rax
00007d3d957d37ef  add rsp, 0x08
00007d3d957d37f3  jmp 0x00007D3D957CFF34
00007d3d957d37f8  sub rsp, 0x08
00007d3d957d37fc  push rax
00007d3d957d37fd  push rcx
00007d3d957d37fe  push rdx
00007d3d957d37ff  push rdi
00007d3d957d3800  push rsi
00007d3d957d3801  push r8
00007d3d957d3803  push r9
00007d3d957d3805  push r10
00007d3d957d3807  push r11
00007d3d957d3809  sub rsp, 0xF0
00007d3d957d3810  vmovaps [rsp], xmm0
00007d3d957d3815  vmovaps [rsp+0x10], xmm1
00007d3d957d381b  vmovaps [rsp+0x20], xmm2
00007d3d957d3821  vmovaps [rsp+0x30], xmm3
00007d3d957d3827  vmovaps [rsp+0x40], xmm4
00007d3d957d382d  vmovaps [rsp+0x50], xmm5
00007d3d957d3833  vmovaps [rsp+0x60], xmm6
00007d3d957d3839  vmovaps [rsp+0x70], xmm7
00007d3d957d383f  vmovaps [rsp+0x80], xmm8
00007d3d957d3848  vmovaps [rsp+0x90], xmm9
00007d3d957d3851  vmovaps [rsp+0xA0], xmm10
00007d3d957d385a  vmovaps [rsp+0xB0], xmm11
00007d3d957d3863  vmovaps [rsp+0xC0], xmm12
00007d3d957d386c  vmovaps [rsp+0xD0], xmm13
00007d3d957d3875  vmovaps [rsp+0xE0], xmm14
00007d3d957d387e  sub rsp, 0x30
00007d3d957d3882  movaps [rsp], xmm15
00007d3d957d3887  movaps [rsp+0x10], xmm13
00007d3d957d388d  movaps [rsp+0x20], xmm10
00007d3d957d3893  lea rdi, [rsp]
00007d3d957d3897  mov esi, 0x00
00007d3d957d389c  mov rax, 0x56C27CB8A530
00007d3d957d38a6  call rax
00007d3d957d38a8  movaps xmm15, [rsp]
00007d3d957d38ad  add rsp, 0x30
00007d3d957d38b1  vmovaps xmm0, [rsp]
00007d3d957d38b6  vmovaps xmm1, [rsp+0x10]
00007d3d957d38bc  vmovaps xmm2, [rsp+0x20]
00007d3d957d38c2  vmovaps xmm3, [rsp+0x30]
00007d3d957d38c8  vmovaps xmm4, [rsp+0x40]
00007d3d957d38ce  vmovaps xmm5, [rsp+0x50]
00007d3d957d38d4  vmovaps xmm6, [rsp+0x60]
00007d3d957d38da  vmovaps xmm7, [rsp+0x70]
00007d3d957d38e0  vmovaps xmm8, [rsp+0x80]
00007d3d957d38e9  vmovaps xmm9, [rsp+0x90]
00007d3d957d38f2  vmovaps xmm10, [rsp+0xA0]
00007d3d957d38fb  vmovaps xmm11, [rsp+0xB0]
00007d3d957d3904  vmovaps xmm12, [rsp+0xC0]
00007d3d957d390d  vmovaps xmm13, [rsp+0xD0]
00007d3d957d3916  vmovaps xmm14, [rsp+0xE0]
00007d3d957d391f  add rsp, 0xF0
00007d3d957d3926  pop r11
00007d3d957d3928  pop r10
00007d3d957d392a  pop r9
00007d3d957d392c  pop r8
00007d3d957d392e  pop rsi
00007d3d957d392f  pop rdi
00007d3d957d3930  pop rdx
00007d3d957d3931  pop rcx
00007d3d957d3932  pop rax
00007d3d957d3933  add rsp, 0x08
00007d3d957d3937  jmp 0x00007D3D957CFF55
00007d3d957d393c  call 0x00007D3D9560C260
00007d3d957d3941  jmp 0x00007D3D957CFFB0
00007d3d957d3946  sub rsp, 0x08
00007d3d957d394a  push rax
00007d3d957d394b  push rcx
00007d3d957d394c  push rdx
00007d3d957d394d  push rdi
00007d3d957d394e  push rsi
00007d3d957d394f  push r8
00007d3d957d3951  push r9
00007d3d957d3953  push r10
00007d3d957d3955  push r11
00007d3d957d3957  sub rsp, 0xF0
00007d3d957d395e  vmovaps [rsp], xmm0
00007d3d957d3963  vmovaps [rsp+0x10], xmm1
00007d3d957d3969  vmovaps [rsp+0x20], xmm2
00007d3d957d396f  vmovaps [rsp+0x30], xmm3
00007d3d957d3975  vmovaps [rsp+0x40], xmm4
00007d3d957d397b  vmovaps [rsp+0x50], xmm5
00007d3d957d3981  vmovaps [rsp+0x60], xmm6
00007d3d957d3987  vmovaps [rsp+0x70], xmm7
00007d3d957d398d  vmovaps [rsp+0x80], xmm8
00007d3d957d3996  vmovaps [rsp+0x90], xmm10
00007d3d957d399f  vmovaps [rsp+0xA0], xmm11
00007d3d957d39a8  vmovaps [rsp+0xB0], xmm12
00007d3d957d39b1  vmovaps [rsp+0xC0], xmm13
00007d3d957d39ba  vmovaps [rsp+0xD0], xmm14
00007d3d957d39c3  vmovaps [rsp+0xE0], xmm15
00007d3d957d39cc  sub rsp, 0x30
00007d3d957d39d0  movaps [rsp], xmm9
00007d3d957d39d5  movaps [rsp+0x10], xmm8
00007d3d957d39db  movaps [rsp+0x20], xmm10
00007d3d957d39e1  lea rdi, [rsp]
00007d3d957d39e5  mov esi, 0x00
00007d3d957d39ea  mov rax, 0x56C27CB8A530
00007d3d957d39f4  call rax
00007d3d957d39f6  movaps xmm9, [rsp]
00007d3d957d39fb  add rsp, 0x30
00007d3d957d39ff  vmovaps xmm0, [rsp]
00007d3d957d3a04  vmovaps xmm1, [rsp+0x10]
00007d3d957d3a0a  vmovaps xmm2, [rsp+0x20]
00007d3d957d3a10  vmovaps xmm3, [rsp+0x30]
00007d3d957d3a16  vmovaps xmm4, [rsp+0x40]
00007d3d957d3a1c  vmovaps xmm5, [rsp+0x50]
00007d3d957d3a22  vmovaps xmm6, [rsp+0x60]
00007d3d957d3a28  vmovaps xmm7, [rsp+0x70]
00007d3d957d3a2e  vmovaps xmm8, [rsp+0x80]
00007d3d957d3a37  vmovaps xmm10, [rsp+0x90]
00007d3d957d3a40  vmovaps xmm11, [rsp+0xA0]
00007d3d957d3a49  vmovaps xmm12, [rsp+0xB0]
00007d3d957d3a52  vmovaps xmm13, [rsp+0xC0]
00007d3d957d3a5b  vmovaps xmm14, [rsp+0xD0]
00007d3d957d3a64  vmovaps xmm15, [rsp+0xE0]
00007d3d957d3a6d  add rsp, 0xF0
00007d3d957d3a74  pop r11
00007d3d957d3a76  pop r10
00007d3d957d3a78  pop r9
00007d3d957d3a7a  pop r8
00007d3d957d3a7c  pop rsi
00007d3d957d3a7d  pop rdi
00007d3d957d3a7e  pop rdx
00007d3d957d3a7f  pop rcx
00007d3d957d3a80  pop rax
00007d3d957d3a81  add rsp, 0x08
00007d3d957d3a85  jmp 0x00007D3D957CFFE1
00007d3d957d3a8a  sub rsp, 0x08
00007d3d957d3a8e  push rax
00007d3d957d3a8f  push rcx
00007d3d957d3a90  push rdx
00007d3d957d3a91  push rdi
00007d3d957d3a92  push rsi
00007d3d957d3a93  push r8
00007d3d957d3a95  push r9
00007d3d957d3a97  push r10
00007d3d957d3a99  push r11
00007d3d957d3a9b  sub rsp, 0xF0
00007d3d957d3aa2  vmovaps [rsp], xmm0
00007d3d957d3aa7  vmovaps [rsp+0x10], xmm1
00007d3d957d3aad  vmovaps [rsp+0x20], xmm2
00007d3d957d3ab3  vmovaps [rsp+0x30], xmm3
00007d3d957d3ab9  vmovaps [rsp+0x40], xmm4
00007d3d957d3abf  vmovaps [rsp+0x50], xmm5
00007d3d957d3ac5  vmovaps [rsp+0x60], xmm6
00007d3d957d3acb  vmovaps [rsp+0x70], xmm7
00007d3d957d3ad1  vmovaps [rsp+0x80], xmm8
00007d3d957d3ada  vmovaps [rsp+0x90], xmm9
00007d3d957d3ae3  vmovaps [rsp+0xA0], xmm11
00007d3d957d3aec  vmovaps [rsp+0xB0], xmm12
00007d3d957d3af5  vmovaps [rsp+0xC0], xmm13
00007d3d957d3afe  vmovaps [rsp+0xD0], xmm14
00007d3d957d3b07  vmovaps [rsp+0xE0], xmm15
00007d3d957d3b10  sub rsp, 0x30
00007d3d957d3b14  movaps [rsp], xmm10
00007d3d957d3b19  movaps [rsp+0x10], xmm1
00007d3d957d3b1e  movaps [rsp+0x20], xmm11
00007d3d957d3b24  lea rdi, [rsp]
00007d3d957d3b28  mov esi, 0x00
00007d3d957d3b2d  mov rax, 0x56C27CB8A530
00007d3d957d3b37  call rax
00007d3d957d3b39  movaps xmm10, [rsp]
00007d3d957d3b3e  add rsp, 0x30
00007d3d957d3b42  vmovaps xmm0, [rsp]
00007d3d957d3b47  vmovaps xmm1, [rsp+0x10]
00007d3d957d3b4d  vmovaps xmm2, [rsp+0x20]
00007d3d957d3b53  vmovaps xmm3, [rsp+0x30]
00007d3d957d3b59  vmovaps xmm4, [rsp+0x40]
00007d3d957d3b5f  vmovaps xmm5, [rsp+0x50]
00007d3d957d3b65  vmovaps xmm6, [rsp+0x60]
00007d3d957d3b6b  vmovaps xmm7, [rsp+0x70]
00007d3d957d3b71  vmovaps xmm8, [rsp+0x80]
00007d3d957d3b7a  vmovaps xmm9, [rsp+0x90]
00007d3d957d3b83  vmovaps xmm11, [rsp+0xA0]
00007d3d957d3b8c  vmovaps xmm12, [rsp+0xB0]
00007d3d957d3b95  vmovaps xmm13, [rsp+0xC0]
00007d3d957d3b9e  vmovaps xmm14, [rsp+0xD0]
00007d3d957d3ba7  vmovaps xmm15, [rsp+0xE0]
00007d3d957d3bb0  add rsp, 0xF0
00007d3d957d3bb7  pop r11
00007d3d957d3bb9  pop r10
00007d3d957d3bbb  pop r9
00007d3d957d3bbd  pop r8
00007d3d957d3bbf  pop rsi
00007d3d957d3bc0  pop rdi
00007d3d957d3bc1  pop rdx
00007d3d957d3bc2  pop rcx
00007d3d957d3bc3  pop rax
00007d3d957d3bc4  add rsp, 0x08
00007d3d957d3bc8  jmp 0x00007D3D957CFFFC
00007d3d957d3bcd  sub rsp, 0x08
00007d3d957d3bd1  push rax
00007d3d957d3bd2  push rcx
00007d3d957d3bd3  push rdx
00007d3d957d3bd4  push rdi
00007d3d957d3bd5  push rsi
00007d3d957d3bd6  push r8
00007d3d957d3bd8  push r9
00007d3d957d3bda  push r10
00007d3d957d3bdc  push r11
00007d3d957d3bde  sub rsp, 0xF0
00007d3d957d3be5  vmovaps [rsp], xmm0
00007d3d957d3bea  vmovaps [rsp+0x10], xmm2
00007d3d957d3bf0  vmovaps [rsp+0x20], xmm3
00007d3d957d3bf6  vmovaps [rsp+0x30], xmm4
00007d3d957d3bfc  vmovaps [rsp+0x40], xmm5
00007d3d957d3c02  vmovaps [rsp+0x50], xmm6
00007d3d957d3c08  vmovaps [rsp+0x60], xmm7
00007d3d957d3c0e  vmovaps [rsp+0x70], xmm8
00007d3d957d3c14  vmovaps [rsp+0x80], xmm9
00007d3d957d3c1d  vmovaps [rsp+0x90], xmm10
00007d3d957d3c26  vmovaps [rsp+0xA0], xmm11
00007d3d957d3c2f  vmovaps [rsp+0xB0], xmm12
00007d3d957d3c38  vmovaps [rsp+0xC0], xmm13
00007d3d957d3c41  vmovaps [rsp+0xD0], xmm14
00007d3d957d3c4a  vmovaps [rsp+0xE0], xmm15
00007d3d957d3c53  sub rsp, 0x30
00007d3d957d3c57  movaps [rsp], xmm1
00007d3d957d3c5b  movaps [rsp+0x10], xmm14
00007d3d957d3c61  movaps [rsp+0x20], xmm6
00007d3d957d3c66  lea rdi, [rsp]
00007d3d957d3c6a  mov esi, 0x00
00007d3d957d3c6f  mov rax, 0x56C27CB8A530
00007d3d957d3c79  call rax
00007d3d957d3c7b  movaps xmm1, [rsp]
00007d3d957d3c7f  add rsp, 0x30
00007d3d957d3c83  vmovaps xmm0, [rsp]
00007d3d957d3c88  vmovaps xmm2, [rsp+0x10]
00007d3d957d3c8e  vmovaps xmm3, [rsp+0x20]
00007d3d957d3c94  vmovaps xmm4, [rsp+0x30]
00007d3d957d3c9a  vmovaps xmm5, [rsp+0x40]
00007d3d957d3ca0  vmovaps xmm6, [rsp+0x50]
00007d3d957d3ca6  vmovaps xmm7, [rsp+0x60]
00007d3d957d3cac  vmovaps xmm8, [rsp+0x70]
00007d3d957d3cb2  vmovaps xmm9, [rsp+0x80]
00007d3d957d3cbb  vmovaps xmm10, [rsp+0x90]
00007d3d957d3cc4  vmovaps xmm11, [rsp+0xA0]
00007d3d957d3ccd  vmovaps xmm12, [rsp+0xB0]
00007d3d957d3cd6  vmovaps xmm13, [rsp+0xC0]
00007d3d957d3cdf  vmovaps xmm14, [rsp+0xD0]
00007d3d957d3ce8  vmovaps xmm15, [rsp+0xE0]
00007d3d957d3cf1  add rsp, 0xF0
00007d3d957d3cf8  pop r11
00007d3d957d3cfa  pop r10
00007d3d957d3cfc  pop r9
00007d3d957d3cfe  pop r8
00007d3d957d3d00  pop rsi
00007d3d957d3d01  pop rdi
00007d3d957d3d02  pop rdx
00007d3d957d3d03  pop rcx
00007d3d957d3d04  pop rax
00007d3d957d3d05  add rsp, 0x08
00007d3d957d3d09  jmp 0x00007D3D957D0015
00007d3d957d3d0e  sub rsp, 0x08
00007d3d957d3d12  push rax
00007d3d957d3d13  push rcx
00007d3d957d3d14  push rdx
00007d3d957d3d15  push rdi
00007d3d957d3d16  push rsi
00007d3d957d3d17  push r8
00007d3d957d3d19  push r9
00007d3d957d3d1b  push r10
00007d3d957d3d1d  push r11
00007d3d957d3d1f  sub rsp, 0xF0
00007d3d957d3d26  vmovaps [rsp], xmm0
00007d3d957d3d2b  vmovaps [rsp+0x10], xmm1
00007d3d957d3d31  vmovaps [rsp+0x20], xmm2
00007d3d957d3d37  vmovaps [rsp+0x30], xmm3
00007d3d957d3d3d  vmovaps [rsp+0x40], xmm4
00007d3d957d3d43  vmovaps [rsp+0x50], xmm5
00007d3d957d3d49  vmovaps [rsp+0x60], xmm6
00007d3d957d3d4f  vmovaps [rsp+0x70], xmm7
00007d3d957d3d55  vmovaps [rsp+0x80], xmm8
00007d3d957d3d5e  vmovaps [rsp+0x90], xmm9
00007d3d957d3d67  vmovaps [rsp+0xA0], xmm10
00007d3d957d3d70  vmovaps [rsp+0xB0], xmm12
00007d3d957d3d79  vmovaps [rsp+0xC0], xmm13
00007d3d957d3d82  vmovaps [rsp+0xD0], xmm14
00007d3d957d3d8b  vmovaps [rsp+0xE0], xmm15
00007d3d957d3d94  sub rsp, 0x30
00007d3d957d3d98  movaps [rsp], xmm11
00007d3d957d3d9d  movaps [rsp+0x10], xmm13
00007d3d957d3da3  movaps [rsp+0x20], xmm14
00007d3d957d3da9  lea rdi, [rsp]
00007d3d957d3dad  mov esi, 0x00
00007d3d957d3db2  mov rax, 0x56C27CB8A530
00007d3d957d3dbc  call rax
00007d3d957d3dbe  movaps xmm11, [rsp]
00007d3d957d3dc3  add rsp, 0x30
00007d3d957d3dc7  vmovaps xmm0, [rsp]
00007d3d957d3dcc  vmovaps xmm1, [rsp+0x10]
00007d3d957d3dd2  vmovaps xmm2, [rsp+0x20]
00007d3d957d3dd8  vmovaps xmm3, [rsp+0x30]
00007d3d957d3dde  vmovaps xmm4, [rsp+0x40]
00007d3d957d3de4  vmovaps xmm5, [rsp+0x50]
00007d3d957d3dea  vmovaps xmm6, [rsp+0x60]
00007d3d957d3df0  vmovaps xmm7, [rsp+0x70]
00007d3d957d3df6  vmovaps xmm8, [rsp+0x80]
00007d3d957d3dff  vmovaps xmm9, [rsp+0x90]
00007d3d957d3e08  vmovaps xmm10, [rsp+0xA0]
00007d3d957d3e11  vmovaps xmm12, [rsp+0xB0]
00007d3d957d3e1a  vmovaps xmm13, [rsp+0xC0]
00007d3d957d3e23  vmovaps xmm14, [rsp+0xD0]
00007d3d957d3e2c  vmovaps xmm15, [rsp+0xE0]
00007d3d957d3e35  add rsp, 0xF0
00007d3d957d3e3c  pop r11
00007d3d957d3e3e  pop r10
00007d3d957d3e40  pop r9
00007d3d957d3e42  pop r8
00007d3d957d3e44  pop rsi
00007d3d957d3e45  pop rdi
00007d3d957d3e46  pop rdx
00007d3d957d3e47  pop rcx
00007d3d957d3e48  pop rax
00007d3d957d3e49  add rsp, 0x08
00007d3d957d3e4d  jmp 0x00007D3D957D003F
00007d3d957d3e52  sub rsp, 0x08
00007d3d957d3e56  push rax
00007d3d957d3e57  push rcx
00007d3d957d3e58  push rdx
00007d3d957d3e59  push rdi
00007d3d957d3e5a  push rsi
00007d3d957d3e5b  push r8
00007d3d957d3e5d  push r9
00007d3d957d3e5f  push r10
00007d3d957d3e61  push r11
00007d3d957d3e63  sub rsp, 0xF0
00007d3d957d3e6a  vmovaps [rsp], xmm0
00007d3d957d3e6f  vmovaps [rsp+0x10], xmm1
00007d3d957d3e75  vmovaps [rsp+0x20], xmm2
00007d3d957d3e7b  vmovaps [rsp+0x30], xmm3
00007d3d957d3e81  vmovaps [rsp+0x40], xmm4
00007d3d957d3e87  vmovaps [rsp+0x50], xmm5
00007d3d957d3e8d  vmovaps [rsp+0x60], xmm6
00007d3d957d3e93  vmovaps [rsp+0x70], xmm7
00007d3d957d3e99  vmovaps [rsp+0x80], xmm8
00007d3d957d3ea2  vmovaps [rsp+0x90], xmm9
00007d3d957d3eab  vmovaps [rsp+0xA0], xmm10
00007d3d957d3eb4  vmovaps [rsp+0xB0], xmm11
00007d3d957d3ebd  vmovaps [rsp+0xC0], xmm12
00007d3d957d3ec6  vmovaps [rsp+0xD0], xmm14
00007d3d957d3ecf  vmovaps [rsp+0xE0], xmm15
00007d3d957d3ed8  sub rsp, 0x30
00007d3d957d3edc  movaps [rsp], xmm13
00007d3d957d3ee1  movaps [rsp+0x10], xmm8
00007d3d957d3ee7  movaps [rsp+0x20], xmm14
00007d3d957d3eed  lea rdi, [rsp]
00007d3d957d3ef1  mov esi, 0x00
00007d3d957d3ef6  mov rax, 0x56C27CB8A530
00007d3d957d3f00  call rax
00007d3d957d3f02  movaps xmm13, [rsp]
00007d3d957d3f07  add rsp, 0x30
00007d3d957d3f0b  vmovaps xmm0, [rsp]
00007d3d957d3f10  vmovaps xmm1, [rsp+0x10]
00007d3d957d3f16  vmovaps xmm2, [rsp+0x20]
00007d3d957d3f1c  vmovaps xmm3, [rsp+0x30]
00007d3d957d3f22  vmovaps xmm4, [rsp+0x40]
00007d3d957d3f28  vmovaps xmm5, [rsp+0x50]
00007d3d957d3f2e  vmovaps xmm6, [rsp+0x60]
00007d3d957d3f34  vmovaps xmm7, [rsp+0x70]
00007d3d957d3f3a  vmovaps xmm8, [rsp+0x80]
00007d3d957d3f43  vmovaps xmm9, [rsp+0x90]
00007d3d957d3f4c  vmovaps xmm10, [rsp+0xA0]
00007d3d957d3f55  vmovaps xmm11, [rsp+0xB0]
00007d3d957d3f5e  vmovaps xmm12, [rsp+0xC0]
00007d3d957d3f67  vmovaps xmm14, [rsp+0xD0]
00007d3d957d3f70  vmovaps xmm15, [rsp+0xE0]
00007d3d957d3f79  add rsp, 0xF0
00007d3d957d3f80  pop r11
00007d3d957d3f82  pop r10
00007d3d957d3f84  pop r9
00007d3d957d3f86  pop r8
00007d3d957d3f88  pop rsi
00007d3d957d3f89  pop rdi
00007d3d957d3f8a  pop rdx
00007d3d957d3f8b  pop rcx
00007d3d957d3f8c  pop rax
00007d3d957d3f8d  add rsp, 0x08
00007d3d957d3f91  jmp 0x00007D3D957D006E
00007d3d957d3f96  sub rsp, 0x08
00007d3d957d3f9a  push rax
00007d3d957d3f9b  push rcx
00007d3d957d3f9c  push rdx
00007d3d957d3f9d  push rdi
00007d3d957d3f9e  push rsi
00007d3d957d3f9f  push r8
00007d3d957d3fa1  push r9
00007d3d957d3fa3  push r10
00007d3d957d3fa5  push r11
00007d3d957d3fa7  sub rsp, 0xF0
00007d3d957d3fae  vmovaps [rsp], xmm0
00007d3d957d3fb3  vmovaps [rsp+0x10], xmm1
00007d3d957d3fb9  vmovaps [rsp+0x20], xmm2
00007d3d957d3fbf  vmovaps [rsp+0x30], xmm3
00007d3d957d3fc5  vmovaps [rsp+0x40], xmm4
00007d3d957d3fcb  vmovaps [rsp+0x50], xmm5
00007d3d957d3fd1  vmovaps [rsp+0x60], xmm6
00007d3d957d3fd7  vmovaps [rsp+0x70], xmm7
00007d3d957d3fdd  vmovaps [rsp+0x80], xmm9
00007d3d957d3fe6  vmovaps [rsp+0x90], xmm10
00007d3d957d3fef  vmovaps [rsp+0xA0], xmm11
00007d3d957d3ff8  vmovaps [rsp+0xB0], xmm12
00007d3d957d4001  vmovaps [rsp+0xC0], xmm13
00007d3d957d400a  vmovaps [rsp+0xD0], xmm14
00007d3d957d4013  vmovaps [rsp+0xE0], xmm15
00007d3d957d401c  sub rsp, 0x30
00007d3d957d4020  movaps [rsp], xmm8
00007d3d957d4025  movaps [rsp+0x10], xmm7
00007d3d957d402a  movaps [rsp+0x20], xmm14
00007d3d957d4030  lea rdi, [rsp]
00007d3d957d4034  mov esi, 0x00
00007d3d957d4039  mov rax, 0x56C27CB8A530
00007d3d957d4043  call rax
00007d3d957d4045  movaps xmm8, [rsp]
00007d3d957d404a  add rsp, 0x30
00007d3d957d404e  vmovaps xmm0, [rsp]
00007d3d957d4053  vmovaps xmm1, [rsp+0x10]
00007d3d957d4059  vmovaps xmm2, [rsp+0x20]
00007d3d957d405f  vmovaps xmm3, [rsp+0x30]
00007d3d957d4065  vmovaps xmm4, [rsp+0x40]
00007d3d957d406b  vmovaps xmm5, [rsp+0x50]
00007d3d957d4071  vmovaps xmm6, [rsp+0x60]
00007d3d957d4077  vmovaps xmm7, [rsp+0x70]
00007d3d957d407d  vmovaps xmm9, [rsp+0x80]
00007d3d957d4086  vmovaps xmm10, [rsp+0x90]
00007d3d957d408f  vmovaps xmm11, [rsp+0xA0]
00007d3d957d4098  vmovaps xmm12, [rsp+0xB0]
00007d3d957d40a1  vmovaps xmm13, [rsp+0xC0]
00007d3d957d40aa  vmovaps xmm14, [rsp+0xD0]
00007d3d957d40b3  vmovaps xmm15, [rsp+0xE0]
00007d3d957d40bc  add rsp, 0xF0
00007d3d957d40c3  pop r11
00007d3d957d40c5  pop r10
00007d3d957d40c7  pop r9
00007d3d957d40c9  pop r8
00007d3d957d40cb  pop rsi
00007d3d957d40cc  pop rdi
00007d3d957d40cd  pop rdx
00007d3d957d40ce  pop rcx
00007d3d957d40cf  pop rax
00007d3d957d40d0  add rsp, 0x08
00007d3d957d40d4  jmp 0x00007D3D957D0094
00007d3d957d40d9  sub rsp, 0x08
00007d3d957d40dd  push rax
00007d3d957d40de  push rcx
00007d3d957d40df  push rdx
00007d3d957d40e0  push rdi
00007d3d957d40e1  push rsi
00007d3d957d40e2  push r8
00007d3d957d40e4  push r9
00007d3d957d40e6  push r10
00007d3d957d40e8  push r11
00007d3d957d40ea  sub rsp, 0xF0
00007d3d957d40f1  vmovaps [rsp], xmm0
00007d3d957d40f6  vmovaps [rsp+0x10], xmm1
00007d3d957d40fc  vmovaps [rsp+0x20], xmm2
00007d3d957d4102  vmovaps [rsp+0x30], xmm3
00007d3d957d4108  vmovaps [rsp+0x40], xmm4
00007d3d957d410e  vmovaps [rsp+0x50], xmm5
00007d3d957d4114  vmovaps [rsp+0x60], xmm6
00007d3d957d411a  vmovaps [rsp+0x70], xmm7
00007d3d957d4120  vmovaps [rsp+0x80], xmm8
00007d3d957d4129  vmovaps [rsp+0x90], xmm9
00007d3d957d4132  vmovaps [rsp+0xA0], xmm10
00007d3d957d413b  vmovaps [rsp+0xB0], xmm11
00007d3d957d4144  vmovaps [rsp+0xC0], xmm12
00007d3d957d414d  vmovaps [rsp+0xD0], xmm13
00007d3d957d4156  vmovaps [rsp+0xE0], xmm15
00007d3d957d415f  sub rsp, 0x30
00007d3d957d4163  movaps [rsp], xmm14
00007d3d957d4168  movaps [rsp+0x10], xmm12
00007d3d957d416e  movaps [rsp+0x20], xmm9
00007d3d957d4174  lea rdi, [rsp]
00007d3d957d4178  mov esi, 0x00
00007d3d957d417d  mov rax, 0x56C27CB8A530
00007d3d957d4187  call rax
00007d3d957d4189  movaps xmm14, [rsp]
00007d3d957d418e  add rsp, 0x30
00007d3d957d4192  vmovaps xmm0, [rsp]
00007d3d957d4197  vmovaps xmm1, [rsp+0x10]
00007d3d957d419d  vmovaps xmm2, [rsp+0x20]
00007d3d957d41a3  vmovaps xmm3, [rsp+0x30]
00007d3d957d41a9  vmovaps xmm4, [rsp+0x40]
00007d3d957d41af  vmovaps xmm5, [rsp+0x50]
00007d3d957d41b5  vmovaps xmm6, [rsp+0x60]
00007d3d957d41bb  vmovaps xmm7, [rsp+0x70]
00007d3d957d41c1  vmovaps xmm8, [rsp+0x80]
00007d3d957d41ca  vmovaps xmm9, [rsp+0x90]
00007d3d957d41d3  vmovaps xmm10, [rsp+0xA0]
00007d3d957d41dc  vmovaps xmm11, [rsp+0xB0]
00007d3d957d41e5  vmovaps xmm12, [rsp+0xC0]
00007d3d957d41ee  vmovaps xmm13, [rsp+0xD0]
00007d3d957d41f7  vmovaps xmm15, [rsp+0xE0]
00007d3d957d4200  add rsp, 0xF0
00007d3d957d4207  pop r11
00007d3d957d4209  pop r10
00007d3d957d420b  pop r9
00007d3d957d420d  pop r8
00007d3d957d420f  pop rsi
00007d3d957d4210  pop rdi
00007d3d957d4211  pop rdx
00007d3d957d4212  pop rcx
00007d3d957d4213  pop rax
00007d3d957d4214  add rsp, 0x08
00007d3d957d4218  jmp 0x00007D3D957D00AE
00007d3d957d421d  sub rsp, 0x08
00007d3d957d4221  push rax
00007d3d957d4222  push rcx
00007d3d957d4223  push rdx
00007d3d957d4224  push rdi
00007d3d957d4225  push rsi
00007d3d957d4226  push r8
00007d3d957d4228  push r9
00007d3d957d422a  push r10
00007d3d957d422c  push r11
00007d3d957d422e  sub rsp, 0xF0
00007d3d957d4235  vmovaps [rsp], xmm0
00007d3d957d423a  vmovaps [rsp+0x10], xmm1
00007d3d957d4240  vmovaps [rsp+0x20], xmm2
00007d3d957d4246  vmovaps [rsp+0x30], xmm3
00007d3d957d424c  vmovaps [rsp+0x40], xmm4
00007d3d957d4252  vmovaps [rsp+0x50], xmm5
00007d3d957d4258  vmovaps [rsp+0x60], xmm6
00007d3d957d425e  vmovaps [rsp+0x70], xmm7
00007d3d957d4264  vmovaps [rsp+0x80], xmm8
00007d3d957d426d  vmovaps [rsp+0x90], xmm10
00007d3d957d4276  vmovaps [rsp+0xA0], xmm11
00007d3d957d427f  vmovaps [rsp+0xB0], xmm12
00007d3d957d4288  vmovaps [rsp+0xC0], xmm13
00007d3d957d4291  vmovaps [rsp+0xD0], xmm14
00007d3d957d429a  vmovaps [rsp+0xE0], xmm15
00007d3d957d42a3  sub rsp, 0x30
00007d3d957d42a7  movaps [rsp], xmm9
00007d3d957d42ac  movaps [rsp+0x10], xmm7
00007d3d957d42b1  movaps [rsp+0x20], xmm12
00007d3d957d42b7  lea rdi, [rsp]
00007d3d957d42bb  mov esi, 0x00
00007d3d957d42c0  mov rax, 0x56C27CB8A530
00007d3d957d42ca  call rax
00007d3d957d42cc  movaps xmm9, [rsp]
00007d3d957d42d1  add rsp, 0x30
00007d3d957d42d5  vmovaps xmm0, [rsp]
00007d3d957d42da  vmovaps xmm1, [rsp+0x10]
00007d3d957d42e0  vmovaps xmm2, [rsp+0x20]
00007d3d957d42e6  vmovaps xmm3, [rsp+0x30]
00007d3d957d42ec  vmovaps xmm4, [rsp+0x40]
00007d3d957d42f2  vmovaps xmm5, [rsp+0x50]
00007d3d957d42f8  vmovaps xmm6, [rsp+0x60]
00007d3d957d42fe  vmovaps xmm7, [rsp+0x70]
00007d3d957d4304  vmovaps xmm8, [rsp+0x80]
00007d3d957d430d  vmovaps xmm10, [rsp+0x90]
00007d3d957d4316  vmovaps xmm11, [rsp+0xA0]
00007d3d957d431f  vmovaps xmm12, [rsp+0xB0]
00007d3d957d4328  vmovaps xmm13, [rsp+0xC0]
00007d3d957d4331  vmovaps xmm14, [rsp+0xD0]
00007d3d957d433a  vmovaps xmm15, [rsp+0xE0]
00007d3d957d4343  add rsp, 0xF0
00007d3d957d434a  pop r11
00007d3d957d434c  pop r10
00007d3d957d434e  pop r9
00007d3d957d4350  pop r8
00007d3d957d4352  pop rsi
00007d3d957d4353  pop rdi
00007d3d957d4354  pop rdx
00007d3d957d4355  pop rcx
00007d3d957d4356  pop rax
00007d3d957d4357  add rsp, 0x08
00007d3d957d435b  jmp 0x00007D3D957D00DD
00007d3d957d4360  sub rsp, 0x08
00007d3d957d4364  push rax
00007d3d957d4365  push rcx
00007d3d957d4366  push rdx
00007d3d957d4367  push rdi
00007d3d957d4368  push rsi
00007d3d957d4369  push r8
00007d3d957d436b  push r9
00007d3d957d436d  push r10
00007d3d957d436f  push r11
00007d3d957d4371  sub rsp, 0xF0
00007d3d957d4378  vmovaps [rsp], xmm0
00007d3d957d437d  vmovaps [rsp+0x10], xmm1
00007d3d957d4383  vmovaps [rsp+0x20], xmm2
00007d3d957d4389  vmovaps [rsp+0x30], xmm3
00007d3d957d438f  vmovaps [rsp+0x40], xmm4
00007d3d957d4395  vmovaps [rsp+0x50], xmm5
00007d3d957d439b  vmovaps [rsp+0x60], xmm6
00007d3d957d43a1  vmovaps [rsp+0x70], xmm7
00007d3d957d43a7  vmovaps [rsp+0x80], xmm8
00007d3d957d43b0  vmovaps [rsp+0x90], xmm9
00007d3d957d43b9  vmovaps [rsp+0xA0], xmm10
00007d3d957d43c2  vmovaps [rsp+0xB0], xmm11
00007d3d957d43cb  vmovaps [rsp+0xC0], xmm13
00007d3d957d43d4  vmovaps [rsp+0xD0], xmm14
00007d3d957d43dd  vmovaps [rsp+0xE0], xmm15
00007d3d957d43e6  sub rsp, 0x30
00007d3d957d43ea  movaps [rsp], xmm12
00007d3d957d43ef  movaps [rsp+0x10], xmm15
00007d3d957d43f5  movaps [rsp+0x20], xmm11
00007d3d957d43fb  lea rdi, [rsp]
00007d3d957d43ff  mov esi, 0x00
00007d3d957d4404  mov rax, 0x56C27CB8A530
00007d3d957d440e  call rax
00007d3d957d4410  movaps xmm12, [rsp]
00007d3d957d4415  add rsp, 0x30
00007d3d957d4419  vmovaps xmm0, [rsp]
00007d3d957d441e  vmovaps xmm1, [rsp+0x10]
00007d3d957d4424  vmovaps xmm2, [rsp+0x20]
00007d3d957d442a  vmovaps xmm3, [rsp+0x30]
00007d3d957d4430  vmovaps xmm4, [rsp+0x40]
00007d3d957d4436  vmovaps xmm5, [rsp+0x50]
00007d3d957d443c  vmovaps xmm6, [rsp+0x60]
00007d3d957d4442  vmovaps xmm7, [rsp+0x70]
00007d3d957d4448  vmovaps xmm8, [rsp+0x80]
00007d3d957d4451  vmovaps xmm9, [rsp+0x90]
00007d3d957d445a  vmovaps xmm10, [rsp+0xA0]
00007d3d957d4463  vmovaps xmm11, [rsp+0xB0]
00007d3d957d446c  vmovaps xmm13, [rsp+0xC0]
00007d3d957d4475  vmovaps xmm14, [rsp+0xD0]
00007d3d957d447e  vmovaps xmm15, [rsp+0xE0]
00007d3d957d4487  add rsp, 0xF0
00007d3d957d448e  pop r11
00007d3d957d4490  pop r10
00007d3d957d4492  pop r9
00007d3d957d4494  pop r8
00007d3d957d4496  pop rsi
00007d3d957d4497  pop rdi
00007d3d957d4498  pop rdx
00007d3d957d4499  pop rcx
00007d3d957d449a  pop rax
00007d3d957d449b  add rsp, 0x08
00007d3d957d449f  jmp 0x00007D3D957D00F7
00007d3d957d44a4  sub rsp, 0x08
00007d3d957d44a8  push rax
00007d3d957d44a9  push rcx
00007d3d957d44aa  push rdx
00007d3d957d44ab  push rdi
00007d3d957d44ac  push rsi
00007d3d957d44ad  push r8
00007d3d957d44af  push r9
00007d3d957d44b1  push r10
00007d3d957d44b3  push r11
00007d3d957d44b5  sub rsp, 0xF0
00007d3d957d44bc  vmovaps [rsp], xmm0
00007d3d957d44c1  vmovaps [rsp+0x10], xmm1
00007d3d957d44c7  vmovaps [rsp+0x20], xmm2
00007d3d957d44cd  vmovaps [rsp+0x30], xmm3
00007d3d957d44d3  vmovaps [rsp+0x40], xmm4
00007d3d957d44d9  vmovaps [rsp+0x50], xmm5
00007d3d957d44df  vmovaps [rsp+0x60], xmm6
00007d3d957d44e5  vmovaps [rsp+0x70], xmm7
00007d3d957d44eb  vmovaps [rsp+0x80], xmm8
00007d3d957d44f4  vmovaps [rsp+0x90], xmm9
00007d3d957d44fd  vmovaps [rsp+0xA0], xmm10
00007d3d957d4506  vmovaps [rsp+0xB0], xmm12
00007d3d957d450f  vmovaps [rsp+0xC0], xmm13
00007d3d957d4518  vmovaps [rsp+0xD0], xmm14
00007d3d957d4521  vmovaps [rsp+0xE0], xmm15
00007d3d957d452a  sub rsp, 0x30
00007d3d957d452e  movaps [rsp], xmm11
00007d3d957d4533  movaps [rsp+0x10], xmm7
00007d3d957d4538  movaps [rsp+0x20], xmm15
00007d3d957d453e  lea rdi, [rsp]
00007d3d957d4542  mov esi, 0x00
00007d3d957d4547  mov rax, 0x56C27CB8A530
00007d3d957d4551  call rax
00007d3d957d4553  movaps xmm11, [rsp]
00007d3d957d4558  add rsp, 0x30
00007d3d957d455c  vmovaps xmm0, [rsp]
00007d3d957d4561  vmovaps xmm1, [rsp+0x10]
00007d3d957d4567  vmovaps xmm2, [rsp+0x20]
00007d3d957d456d  vmovaps xmm3, [rsp+0x30]
00007d3d957d4573  vmovaps xmm4, [rsp+0x40]
00007d3d957d4579  vmovaps xmm5, [rsp+0x50]
00007d3d957d457f  vmovaps xmm6, [rsp+0x60]
00007d3d957d4585  vmovaps xmm7, [rsp+0x70]
00007d3d957d458b  vmovaps xmm8, [rsp+0x80]
00007d3d957d4594  vmovaps xmm9, [rsp+0x90]
00007d3d957d459d  vmovaps xmm10, [rsp+0xA0]
00007d3d957d45a6  vmovaps xmm12, [rsp+0xB0]
00007d3d957d45af  vmovaps xmm13, [rsp+0xC0]
00007d3d957d45b8  vmovaps xmm14, [rsp+0xD0]
00007d3d957d45c1  vmovaps xmm15, [rsp+0xE0]
00007d3d957d45ca  add rsp, 0xF0
00007d3d957d45d1  pop r11
00007d3d957d45d3  pop r10
00007d3d957d45d5  pop r9
00007d3d957d45d7  pop r8
00007d3d957d45d9  pop rsi
00007d3d957d45da  pop rdi
00007d3d957d45db  pop rdx
00007d3d957d45dc  pop rcx
00007d3d957d45dd  pop rax
00007d3d957d45de  add rsp, 0x08
00007d3d957d45e2  jmp 0x00007D3D957D0123
00007d3d957d45e7  sub rsp, 0x08
00007d3d957d45eb  push rax
00007d3d957d45ec  push rcx
00007d3d957d45ed  push rdx
00007d3d957d45ee  push rdi
00007d3d957d45ef  push rsi
00007d3d957d45f0  push r8
00007d3d957d45f2  push r9
00007d3d957d45f4  push r10
00007d3d957d45f6  push r11
00007d3d957d45f8  sub rsp, 0xF0
00007d3d957d45ff  vmovaps [rsp], xmm0
00007d3d957d4604  vmovaps [rsp+0x10], xmm1
00007d3d957d460a  vmovaps [rsp+0x20], xmm2
00007d3d957d4610  vmovaps [rsp+0x30], xmm3
00007d3d957d4616  vmovaps [rsp+0x40], xmm4
00007d3d957d461c  vmovaps [rsp+0x50], xmm5
00007d3d957d4622  vmovaps [rsp+0x60], xmm6
00007d3d957d4628  vmovaps [rsp+0x70], xmm7
00007d3d957d462e  vmovaps [rsp+0x80], xmm8
00007d3d957d4637  vmovaps [rsp+0x90], xmm9
00007d3d957d4640  vmovaps [rsp+0xA0], xmm10
00007d3d957d4649  vmovaps [rsp+0xB0], xmm11
00007d3d957d4652  vmovaps [rsp+0xC0], xmm12
00007d3d957d465b  vmovaps [rsp+0xD0], xmm13
00007d3d957d4664  vmovaps [rsp+0xE0], xmm14
00007d3d957d466d  sub rsp, 0x30
00007d3d957d4671  movaps [rsp], xmm15
00007d3d957d4676  movaps [rsp+0x10], xmm10
00007d3d957d467c  movaps [rsp+0x20], xmm13
00007d3d957d4682  lea rdi, [rsp]
00007d3d957d4686  mov esi, 0x00
00007d3d957d468b  mov rax, 0x56C27CB8A530
00007d3d957d4695  call rax
00007d3d957d4697  movaps xmm15, [rsp]
00007d3d957d469c  add rsp, 0x30
00007d3d957d46a0  vmovaps xmm0, [rsp]
00007d3d957d46a5  vmovaps xmm1, [rsp+0x10]
00007d3d957d46ab  vmovaps xmm2, [rsp+0x20]
00007d3d957d46b1  vmovaps xmm3, [rsp+0x30]
00007d3d957d46b7  vmovaps xmm4, [rsp+0x40]
00007d3d957d46bd  vmovaps xmm5, [rsp+0x50]
00007d3d957d46c3  vmovaps xmm6, [rsp+0x60]
00007d3d957d46c9  vmovaps xmm7, [rsp+0x70]
00007d3d957d46cf  vmovaps xmm8, [rsp+0x80]
00007d3d957d46d8  vmovaps xmm9, [rsp+0x90]
00007d3d957d46e1  vmovaps xmm10, [rsp+0xA0]
00007d3d957d46ea  vmovaps xmm11, [rsp+0xB0]
00007d3d957d46f3  vmovaps xmm12, [rsp+0xC0]
00007d3d957d46fc  vmovaps xmm13, [rsp+0xD0]
00007d3d957d4705  vmovaps xmm14, [rsp+0xE0]
00007d3d957d470e  add rsp, 0xF0
00007d3d957d4715  pop r11
00007d3d957d4717  pop r10
00007d3d957d4719  pop r9
00007d3d957d471b  pop r8
00007d3d957d471d  pop rsi
00007d3d957d471e  pop rdi
00007d3d957d471f  pop rdx
00007d3d957d4720  pop rcx
00007d3d957d4721  pop rax
00007d3d957d4722  add rsp, 0x08
00007d3d957d4726  jmp 0x00007D3D957D013D
00007d3d957d472b  sub rsp, 0x08
00007d3d957d472f  push rax
00007d3d957d4730  push rcx
00007d3d957d4731  push rdx
00007d3d957d4732  push rdi
00007d3d957d4733  push rsi
00007d3d957d4734  push r8
00007d3d957d4736  push r9
00007d3d957d4738  push r10
00007d3d957d473a  push r11
00007d3d957d473c  sub rsp, 0xF0
00007d3d957d4743  vmovaps [rsp], xmm0
00007d3d957d4748  vmovaps [rsp+0x10], xmm1
00007d3d957d474e  vmovaps [rsp+0x20], xmm2
00007d3d957d4754  vmovaps [rsp+0x30], xmm3
00007d3d957d475a  vmovaps [rsp+0x40], xmm4
00007d3d957d4760  vmovaps [rsp+0x50], xmm5
00007d3d957d4766  vmovaps [rsp+0x60], xmm6
00007d3d957d476c  vmovaps [rsp+0x70], xmm7
00007d3d957d4772  vmovaps [rsp+0x80], xmm8
00007d3d957d477b  vmovaps [rsp+0x90], xmm9
00007d3d957d4784  vmovaps [rsp+0xA0], xmm11
00007d3d957d478d  vmovaps [rsp+0xB0], xmm12
00007d3d957d4796  vmovaps [rsp+0xC0], xmm13
00007d3d957d479f  vmovaps [rsp+0xD0], xmm14
00007d3d957d47a8  vmovaps [rsp+0xE0], xmm15
00007d3d957d47b1  sub rsp, 0x30
00007d3d957d47b5  movaps [rsp], xmm10
00007d3d957d47ba  movaps [rsp+0x10], xmm7
00007d3d957d47bf  movaps [rsp+0x20], xmm13
00007d3d957d47c5  lea rdi, [rsp]
00007d3d957d47c9  mov esi, 0x00
00007d3d957d47ce  mov rax, 0x56C27CB8A530
00007d3d957d47d8  call rax
00007d3d957d47da  movaps xmm10, [rsp]
00007d3d957d47df  add rsp, 0x30
00007d3d957d47e3  vmovaps xmm0, [rsp]
00007d3d957d47e8  vmovaps xmm1, [rsp+0x10]
00007d3d957d47ee  vmovaps xmm2, [rsp+0x20]
00007d3d957d47f4  vmovaps xmm3, [rsp+0x30]
00007d3d957d47fa  vmovaps xmm4, [rsp+0x40]
00007d3d957d4800  vmovaps xmm5, [rsp+0x50]
00007d3d957d4806  vmovaps xmm6, [rsp+0x60]
00007d3d957d480c  vmovaps xmm7, [rsp+0x70]
00007d3d957d4812  vmovaps xmm8, [rsp+0x80]
00007d3d957d481b  vmovaps xmm9, [rsp+0x90]
00007d3d957d4824  vmovaps xmm11, [rsp+0xA0]
00007d3d957d482d  vmovaps xmm12, [rsp+0xB0]
00007d3d957d4836  vmovaps xmm13, [rsp+0xC0]
00007d3d957d483f  vmovaps xmm14, [rsp+0xD0]
00007d3d957d4848  vmovaps xmm15, [rsp+0xE0]
00007d3d957d4851  add rsp, 0xF0
00007d3d957d4858  pop r11
00007d3d957d485a  pop r10
00007d3d957d485c  pop r9
00007d3d957d485e  pop r8
00007d3d957d4860  pop rsi
00007d3d957d4861  pop rdi
00007d3d957d4862  pop rdx
00007d3d957d4863  pop rcx
00007d3d957d4864  pop rax
00007d3d957d4865  add rsp, 0x08
00007d3d957d4869  jmp 0x00007D3D957D0169
00007d3d957d486e  sub rsp, 0x08
00007d3d957d4872  push rax
00007d3d957d4873  push rcx
00007d3d957d4874  push rdx
00007d3d957d4875  push rdi
00007d3d957d4876  push rsi
00007d3d957d4877  push r8
00007d3d957d4879  push r9
00007d3d957d487b  push r10
00007d3d957d487d  push r11
00007d3d957d487f  sub rsp, 0xF0
00007d3d957d4886  vmovaps [rsp], xmm0
00007d3d957d488b  vmovaps [rsp+0x10], xmm1
00007d3d957d4891  vmovaps [rsp+0x20], xmm2
00007d3d957d4897  vmovaps [rsp+0x30], xmm3
00007d3d957d489d  vmovaps [rsp+0x40], xmm4
00007d3d957d48a3  vmovaps [rsp+0x50], xmm5
00007d3d957d48a9  vmovaps [rsp+0x60], xmm6
00007d3d957d48af  vmovaps [rsp+0x70], xmm7
00007d3d957d48b5  vmovaps [rsp+0x80], xmm8
00007d3d957d48be  vmovaps [rsp+0x90], xmm9
00007d3d957d48c7  vmovaps [rsp+0xA0], xmm10
00007d3d957d48d0  vmovaps [rsp+0xB0], xmm11
00007d3d957d48d9  vmovaps [rsp+0xC0], xmm12
00007d3d957d48e2  vmovaps [rsp+0xD0], xmm14
00007d3d957d48eb  vmovaps [rsp+0xE0], xmm15
00007d3d957d48f4  sub rsp, 0x30
00007d3d957d48f8  movaps [rsp], xmm13
00007d3d957d48fd  movaps [rsp+0x10], xmm1
00007d3d957d4902  movaps [rsp+0x20], xmm8
00007d3d957d4908  lea rdi, [rsp]
00007d3d957d490c  mov esi, 0x00
00007d3d957d4911  mov rax, 0x56C27CB8A530
00007d3d957d491b  call rax
00007d3d957d491d  movaps xmm13, [rsp]
00007d3d957d4922  add rsp, 0x30
00007d3d957d4926  vmovaps xmm0, [rsp]
00007d3d957d492b  vmovaps xmm1, [rsp+0x10]
00007d3d957d4931  vmovaps xmm2, [rsp+0x20]
00007d3d957d4937  vmovaps xmm3, [rsp+0x30]
00007d3d957d493d  vmovaps xmm4, [rsp+0x40]
00007d3d957d4943  vmovaps xmm5, [rsp+0x50]
00007d3d957d4949  vmovaps xmm6, [rsp+0x60]
00007d3d957d494f  vmovaps xmm7, [rsp+0x70]
00007d3d957d4955  vmovaps xmm8, [rsp+0x80]
00007d3d957d495e  vmovaps xmm9, [rsp+0x90]
00007d3d957d4967  vmovaps xmm10, [rsp+0xA0]
00007d3d957d4970  vmovaps xmm11, [rsp+0xB0]
00007d3d957d4979  vmovaps xmm12, [rsp+0xC0]
00007d3d957d4982  vmovaps xmm14, [rsp+0xD0]
00007d3d957d498b  vmovaps xmm15, [rsp+0xE0]
00007d3d957d4994  add rsp, 0xF0
00007d3d957d499b  pop r11
00007d3d957d499d  pop r10
00007d3d957d499f  pop r9
00007d3d957d49a1  pop r8
00007d3d957d49a3  pop rsi
00007d3d957d49a4  pop rdi
00007d3d957d49a5  pop rdx
00007d3d957d49a6  pop rcx
00007d3d957d49a7  pop rax
00007d3d957d49a8  add rsp, 0x08
00007d3d957d49ac  jmp 0x00007D3D957D0183
00007d3d957d49b1  call 0x00007D3D955FF430
00007d3d957d49b6  jmp 0x00007D3D957D018D
00007d3d957d49bb  sub rsp, 0x08
00007d3d957d49bf  push rax
00007d3d957d49c0  push rcx
00007d3d957d49c1  push rdx
00007d3d957d49c2  push rdi
00007d3d957d49c3  push rsi
00007d3d957d49c4  push r8
00007d3d957d49c6  push r9
00007d3d957d49c8  push r10
00007d3d957d49ca  push r11
00007d3d957d49cc  sub rsp, 0xF0
00007d3d957d49d3  vmovaps [rsp], xmm0
00007d3d957d49d8  vmovaps [rsp+0x10], xmm1
00007d3d957d49de  vmovaps [rsp+0x20], xmm2
00007d3d957d49e4  vmovaps [rsp+0x30], xmm3
00007d3d957d49ea  vmovaps [rsp+0x40], xmm4
00007d3d957d49f0  vmovaps [rsp+0x50], xmm5
00007d3d957d49f6  vmovaps [rsp+0x60], xmm6
00007d3d957d49fc  vmovaps [rsp+0x70], xmm7
00007d3d957d4a02  vmovaps [rsp+0x80], xmm9
00007d3d957d4a0b  vmovaps [rsp+0x90], xmm10
00007d3d957d4a14  vmovaps [rsp+0xA0], xmm11
00007d3d957d4a1d  vmovaps [rsp+0xB0], xmm12
00007d3d957d4a26  vmovaps [rsp+0xC0], xmm13
00007d3d957d4a2f  vmovaps [rsp+0xD0], xmm14
00007d3d957d4a38  vmovaps [rsp+0xE0], xmm15
00007d3d957d4a41  sub rsp, 0x30
00007d3d957d4a45  movaps [rsp], xmm8
00007d3d957d4a4a  movaps [rsp+0x10], xmm14
00007d3d957d4a50  movaps [rsp+0x20], xmm9
00007d3d957d4a56  lea rdi, [rsp]
00007d3d957d4a5a  mov esi, 0x00
00007d3d957d4a5f  mov rax, 0x56C27CB8A530
00007d3d957d4a69  call rax
00007d3d957d4a6b  movaps xmm8, [rsp]
00007d3d957d4a70  add rsp, 0x30
00007d3d957d4a74  vmovaps xmm0, [rsp]
00007d3d957d4a79  vmovaps xmm1, [rsp+0x10]
00007d3d957d4a7f  vmovaps xmm2, [rsp+0x20]
00007d3d957d4a85  vmovaps xmm3, [rsp+0x30]
00007d3d957d4a8b  vmovaps xmm4, [rsp+0x40]
00007d3d957d4a91  vmovaps xmm5, [rsp+0x50]
00007d3d957d4a97  vmovaps xmm6, [rsp+0x60]
00007d3d957d4a9d  vmovaps xmm7, [rsp+0x70]
00007d3d957d4aa3  vmovaps xmm9, [rsp+0x80]
00007d3d957d4aac  vmovaps xmm10, [rsp+0x90]
00007d3d957d4ab5  vmovaps xmm11, [rsp+0xA0]
00007d3d957d4abe  vmovaps xmm12, [rsp+0xB0]
00007d3d957d4ac7  vmovaps xmm13, [rsp+0xC0]
00007d3d957d4ad0  vmovaps xmm14, [rsp+0xD0]
00007d3d957d4ad9  vmovaps xmm15, [rsp+0xE0]
00007d3d957d4ae2  add rsp, 0xF0
00007d3d957d4ae9  pop r11
00007d3d957d4aeb  pop r10
00007d3d957d4aed  pop r9
00007d3d957d4aef  pop r8
00007d3d957d4af1  pop rsi
00007d3d957d4af2  pop rdi
00007d3d957d4af3  pop rdx
00007d3d957d4af4  pop rcx
00007d3d957d4af5  pop rax
00007d3d957d4af6  add rsp, 0x08
00007d3d957d4afa  jmp 0x00007D3D957D01AF
00007d3d957d4aff  sub rsp, 0x08
00007d3d957d4b03  push rax
00007d3d957d4b04  push rcx
00007d3d957d4b05  push rdx
00007d3d957d4b06  push rdi
00007d3d957d4b07  push rsi
00007d3d957d4b08  push r8
00007d3d957d4b0a  push r9
00007d3d957d4b0c  push r10
00007d3d957d4b0e  push r11
00007d3d957d4b10  sub rsp, 0xF0
00007d3d957d4b17  vmovaps [rsp], xmm0
00007d3d957d4b1c  vmovaps [rsp+0x10], xmm1
00007d3d957d4b22  vmovaps [rsp+0x20], xmm2
00007d3d957d4b28  vmovaps [rsp+0x30], xmm3
00007d3d957d4b2e  vmovaps [rsp+0x40], xmm4
00007d3d957d4b34  vmovaps [rsp+0x50], xmm5
00007d3d957d4b3a  vmovaps [rsp+0x60], xmm6
00007d3d957d4b40  vmovaps [rsp+0x70], xmm7
00007d3d957d4b46  vmovaps [rsp+0x80], xmm8
00007d3d957d4b4f  vmovaps [rsp+0x90], xmm10
00007d3d957d4b58  vmovaps [rsp+0xA0], xmm11
00007d3d957d4b61  vmovaps [rsp+0xB0], xmm12
00007d3d957d4b6a  vmovaps [rsp+0xC0], xmm13
00007d3d957d4b73  vmovaps [rsp+0xD0], xmm14
00007d3d957d4b7c  vmovaps [rsp+0xE0], xmm15
00007d3d957d4b85  sub rsp, 0x30
00007d3d957d4b89  movaps [rsp], xmm9
00007d3d957d4b8e  movaps [rsp+0x10], xmm1
00007d3d957d4b93  movaps [rsp+0x20], xmm14
00007d3d957d4b99  lea rdi, [rsp]
00007d3d957d4b9d  mov esi, 0x00
00007d3d957d4ba2  mov rax, 0x56C27CB8A530
00007d3d957d4bac  call rax
00007d3d957d4bae  movaps xmm9, [rsp]
00007d3d957d4bb3  add rsp, 0x30
00007d3d957d4bb7  vmovaps xmm0, [rsp]
00007d3d957d4bbc  vmovaps xmm1, [rsp+0x10]
00007d3d957d4bc2  vmovaps xmm2, [rsp+0x20]
00007d3d957d4bc8  vmovaps xmm3, [rsp+0x30]
00007d3d957d4bce  vmovaps xmm4, [rsp+0x40]
00007d3d957d4bd4  vmovaps xmm5, [rsp+0x50]
00007d3d957d4bda  vmovaps xmm6, [rsp+0x60]
00007d3d957d4be0  vmovaps xmm7, [rsp+0x70]
00007d3d957d4be6  vmovaps xmm8, [rsp+0x80]
00007d3d957d4bef  vmovaps xmm10, [rsp+0x90]
00007d3d957d4bf8  vmovaps xmm11, [rsp+0xA0]
00007d3d957d4c01  vmovaps xmm12, [rsp+0xB0]
00007d3d957d4c0a  vmovaps xmm13, [rsp+0xC0]
00007d3d957d4c13  vmovaps xmm14, [rsp+0xD0]
00007d3d957d4c1c  vmovaps xmm15, [rsp+0xE0]
00007d3d957d4c25  add rsp, 0xF0
00007d3d957d4c2c  pop r11
00007d3d957d4c2e  pop r10
00007d3d957d4c30  pop r9
00007d3d957d4c32  pop r8
00007d3d957d4c34  pop rsi
00007d3d957d4c35  pop rdi
00007d3d957d4c36  pop rdx
00007d3d957d4c37  pop rcx
00007d3d957d4c38  pop rax
00007d3d957d4c39  add rsp, 0x08
00007d3d957d4c3d  jmp 0x00007D3D957D01DD
00007d3d957d4c42  sub rsp, 0x08
00007d3d957d4c46  push rax
00007d3d957d4c47  push rcx
00007d3d957d4c48  push rdx
00007d3d957d4c49  push rdi
00007d3d957d4c4a  push rsi
00007d3d957d4c4b  push r8
00007d3d957d4c4d  push r9
00007d3d957d4c4f  push r10
00007d3d957d4c51  push r11
00007d3d957d4c53  sub rsp, 0xF0
00007d3d957d4c5a  vmovaps [rsp], xmm0
00007d3d957d4c5f  vmovaps [rsp+0x10], xmm1
00007d3d957d4c65  vmovaps [rsp+0x20], xmm2
00007d3d957d4c6b  vmovaps [rsp+0x30], xmm3
00007d3d957d4c71  vmovaps [rsp+0x40], xmm4
00007d3d957d4c77  vmovaps [rsp+0x50], xmm5
00007d3d957d4c7d  vmovaps [rsp+0x60], xmm6
00007d3d957d4c83  vmovaps [rsp+0x70], xmm7
00007d3d957d4c89  vmovaps [rsp+0x80], xmm8
00007d3d957d4c92  vmovaps [rsp+0x90], xmm9
00007d3d957d4c9b  vmovaps [rsp+0xA0], xmm10
00007d3d957d4ca4  vmovaps [rsp+0xB0], xmm11
00007d3d957d4cad  vmovaps [rsp+0xC0], xmm12
00007d3d957d4cb6  vmovaps [rsp+0xD0], xmm13
00007d3d957d4cbf  vmovaps [rsp+0xE0], xmm15
00007d3d957d4cc8  sub rsp, 0x30
00007d3d957d4ccc  movaps [rsp], xmm14
00007d3d957d4cd1  movaps [rsp+0x10], xmm4
00007d3d957d4cd6  movaps [rsp+0x20], xmm1
00007d3d957d4cdb  lea rdi, [rsp]
00007d3d957d4cdf  mov esi, 0x00
00007d3d957d4ce4  mov rax, 0x56C27CB8A530
00007d3d957d4cee  call rax
00007d3d957d4cf0  movaps xmm14, [rsp]
00007d3d957d4cf5  add rsp, 0x30
00007d3d957d4cf9  vmovaps xmm0, [rsp]
00007d3d957d4cfe  vmovaps xmm1, [rsp+0x10]
00007d3d957d4d04  vmovaps xmm2, [rsp+0x20]
00007d3d957d4d0a  vmovaps xmm3, [rsp+0x30]
00007d3d957d4d10  vmovaps xmm4, [rsp+0x40]
00007d3d957d4d16  vmovaps xmm5, [rsp+0x50]
00007d3d957d4d1c  vmovaps xmm6, [rsp+0x60]
00007d3d957d4d22  vmovaps xmm7, [rsp+0x70]
00007d3d957d4d28  vmovaps xmm8, [rsp+0x80]
00007d3d957d4d31  vmovaps xmm9, [rsp+0x90]
00007d3d957d4d3a  vmovaps xmm10, [rsp+0xA0]
00007d3d957d4d43  vmovaps xmm11, [rsp+0xB0]
00007d3d957d4d4c  vmovaps xmm12, [rsp+0xC0]
00007d3d957d4d55  vmovaps xmm13, [rsp+0xD0]
00007d3d957d4d5e  vmovaps xmm15, [rsp+0xE0]
00007d3d957d4d67  add rsp, 0xF0
00007d3d957d4d6e  pop r11
00007d3d957d4d70  pop r10
00007d3d957d4d72  pop r9
00007d3d957d4d74  pop r8
00007d3d957d4d76  pop rsi
00007d3d957d4d77  pop rdi
00007d3d957d4d78  pop rdx
00007d3d957d4d79  pop rcx
00007d3d957d4d7a  pop rax
00007d3d957d4d7b  add rsp, 0x08
00007d3d957d4d7f  jmp 0x00007D3D957D0203
00007d3d957d4d84  sub rsp, 0x08
00007d3d957d4d88  push rax
00007d3d957d4d89  push rcx
00007d3d957d4d8a  push rdx
00007d3d957d4d8b  push rdi
00007d3d957d4d8c  push rsi
00007d3d957d4d8d  push r8
00007d3d957d4d8f  push r9
00007d3d957d4d91  push r10
00007d3d957d4d93  push r11
00007d3d957d4d95  sub rsp, 0xF0
00007d3d957d4d9c  vmovaps [rsp], xmm0
00007d3d957d4da1  vmovaps [rsp+0x10], xmm2
00007d3d957d4da7  vmovaps [rsp+0x20], xmm3
00007d3d957d4dad  vmovaps [rsp+0x30], xmm4
00007d3d957d4db3  vmovaps [rsp+0x40], xmm5
00007d3d957d4db9  vmovaps [rsp+0x50], xmm6
00007d3d957d4dbf  vmovaps [rsp+0x60], xmm7
00007d3d957d4dc5  vmovaps [rsp+0x70], xmm8
00007d3d957d4dcb  vmovaps [rsp+0x80], xmm9
00007d3d957d4dd4  vmovaps [rsp+0x90], xmm10
00007d3d957d4ddd  vmovaps [rsp+0xA0], xmm11
00007d3d957d4de6  vmovaps [rsp+0xB0], xmm12
00007d3d957d4def  vmovaps [rsp+0xC0], xmm13
00007d3d957d4df8  vmovaps [rsp+0xD0], xmm14
00007d3d957d4e01  vmovaps [rsp+0xE0], xmm15
00007d3d957d4e0a  sub rsp, 0x30
00007d3d957d4e0e  movaps [rsp], xmm1
00007d3d957d4e12  movaps [rsp+0x10], xmm12
00007d3d957d4e18  movaps [rsp+0x20], xmm11
00007d3d957d4e1e  lea rdi, [rsp]
00007d3d957d4e22  mov esi, 0x00
00007d3d957d4e27  mov rax, 0x56C27CB8A530
00007d3d957d4e31  call rax
00007d3d957d4e33  movaps xmm1, [rsp]
00007d3d957d4e37  add rsp, 0x30
00007d3d957d4e3b  vmovaps xmm0, [rsp]
00007d3d957d4e40  vmovaps xmm2, [rsp+0x10]
00007d3d957d4e46  vmovaps xmm3, [rsp+0x20]
00007d3d957d4e4c  vmovaps xmm4, [rsp+0x30]
00007d3d957d4e52  vmovaps xmm5, [rsp+0x40]
00007d3d957d4e58  vmovaps xmm6, [rsp+0x50]
00007d3d957d4e5e  vmovaps xmm7, [rsp+0x60]
00007d3d957d4e64  vmovaps xmm8, [rsp+0x70]
00007d3d957d4e6a  vmovaps xmm9, [rsp+0x80]
00007d3d957d4e73  vmovaps xmm10, [rsp+0x90]
00007d3d957d4e7c  vmovaps xmm11, [rsp+0xA0]
00007d3d957d4e85  vmovaps xmm12, [rsp+0xB0]
00007d3d957d4e8e  vmovaps xmm13, [rsp+0xC0]
00007d3d957d4e97  vmovaps xmm14, [rsp+0xD0]
00007d3d957d4ea0  vmovaps xmm15, [rsp+0xE0]
00007d3d957d4ea9  add rsp, 0xF0
00007d3d957d4eb0  pop r11
00007d3d957d4eb2  pop r10
00007d3d957d4eb4  pop r9
00007d3d957d4eb6  pop r8
00007d3d957d4eb8  pop rsi
00007d3d957d4eb9  pop rdi
00007d3d957d4eba  pop rdx
00007d3d957d4ebb  pop rcx
00007d3d957d4ebc  pop rax
00007d3d957d4ebd  add rsp, 0x08
00007d3d957d4ec1  jmp 0x00007D3D957D0224
00007d3d957d4ec6  call 0x00007D3D956E20A0
00007d3d957d4ecb  jmp 0x00007D3D957D0232
00007d3d957d4ed0  call 0x00007D3D95609D70
00007d3d957d4ed5  jmp 0x00007D3D957D023C
00007d3d957d4eda  sub rsp, 0x08
00007d3d957d4ede  push rax
00007d3d957d4edf  push rcx
00007d3d957d4ee0  push rdx
00007d3d957d4ee1  push rdi
00007d3d957d4ee2  push rsi
00007d3d957d4ee3  push r8
00007d3d957d4ee5  push r9
00007d3d957d4ee7  push r10
00007d3d957d4ee9  push r11
00007d3d957d4eeb  sub rsp, 0xF0
00007d3d957d4ef2  vmovaps [rsp], xmm0
00007d3d957d4ef7  vmovaps [rsp+0x10], xmm1
00007d3d957d4efd  vmovaps [rsp+0x20], xmm2
00007d3d957d4f03  vmovaps [rsp+0x30], xmm3
00007d3d957d4f09  vmovaps [rsp+0x40], xmm4
00007d3d957d4f0f  vmovaps [rsp+0x50], xmm5
00007d3d957d4f15  vmovaps [rsp+0x60], xmm6
00007d3d957d4f1b  vmovaps [rsp+0x70], xmm8
00007d3d957d4f21  vmovaps [rsp+0x80], xmm9
00007d3d957d4f2a  vmovaps [rsp+0x90], xmm10
00007d3d957d4f33  vmovaps [rsp+0xA0], xmm11
00007d3d957d4f3c  vmovaps [rsp+0xB0], xmm12
00007d3d957d4f45  vmovaps [rsp+0xC0], xmm13
00007d3d957d4f4e  vmovaps [rsp+0xD0], xmm14
00007d3d957d4f57  vmovaps [rsp+0xE0], xmm15
00007d3d957d4f60  sub rsp, 0x30
00007d3d957d4f64  movaps [rsp], xmm7
00007d3d957d4f68  movaps [rsp+0x10], xmm15
00007d3d957d4f6e  movaps [rsp+0x20], xmm10
00007d3d957d4f74  lea rdi, [rsp]
00007d3d957d4f78  mov esi, 0x00
00007d3d957d4f7d  mov rax, 0x56C27CB8A530
00007d3d957d4f87  call rax
00007d3d957d4f89  movaps xmm7, [rsp]
00007d3d957d4f8d  add rsp, 0x30
00007d3d957d4f91  vmovaps xmm0, [rsp]
00007d3d957d4f96  vmovaps xmm1, [rsp+0x10]
00007d3d957d4f9c  vmovaps xmm2, [rsp+0x20]
00007d3d957d4fa2  vmovaps xmm3, [rsp+0x30]
00007d3d957d4fa8  vmovaps xmm4, [rsp+0x40]
00007d3d957d4fae  vmovaps xmm5, [rsp+0x50]
00007d3d957d4fb4  vmovaps xmm6, [rsp+0x60]
00007d3d957d4fba  vmovaps xmm8, [rsp+0x70]
00007d3d957d4fc0  vmovaps xmm9, [rsp+0x80]
00007d3d957d4fc9  vmovaps xmm10, [rsp+0x90]
00007d3d957d4fd2  vmovaps xmm11, [rsp+0xA0]
00007d3d957d4fdb  vmovaps xmm12, [rsp+0xB0]
00007d3d957d4fe4  vmovaps xmm13, [rsp+0xC0]
00007d3d957d4fed  vmovaps xmm14, [rsp+0xD0]
00007d3d957d4ff6  vmovaps xmm15, [rsp+0xE0]
00007d3d957d4fff  add rsp, 0xF0
00007d3d957d5006  pop r11
00007d3d957d5008  pop r10
00007d3d957d500a  pop r9
00007d3d957d500c  pop r8
00007d3d957d500e  pop rsi
00007d3d957d500f  pop rdi
00007d3d957d5010  pop rdx
00007d3d957d5011  pop rcx
00007d3d957d5012  pop rax
00007d3d957d5013  add rsp, 0x08
00007d3d957d5017  jmp 0x00007D3D957D025D
00007d3d957d501c  sub rsp, 0x08
00007d3d957d5020  push rax
00007d3d957d5021  push rcx
00007d3d957d5022  push rdx
00007d3d957d5023  push rdi
00007d3d957d5024  push rsi
00007d3d957d5025  push r8
00007d3d957d5027  push r9
00007d3d957d5029  push r10
00007d3d957d502b  push r11
00007d3d957d502d  sub rsp, 0xF0
00007d3d957d5034  vmovaps [rsp], xmm0
00007d3d957d5039  vmovaps [rsp+0x10], xmm1
00007d3d957d503f  vmovaps [rsp+0x20], xmm2
00007d3d957d5045  vmovaps [rsp+0x30], xmm3
00007d3d957d504b  vmovaps [rsp+0x40], xmm4
00007d3d957d5051  vmovaps [rsp+0x50], xmm5
00007d3d957d5057  vmovaps [rsp+0x60], xmm6
00007d3d957d505d  vmovaps [rsp+0x70], xmm7
00007d3d957d5063  vmovaps [rsp+0x80], xmm8
00007d3d957d506c  vmovaps [rsp+0x90], xmm9
00007d3d957d5075  vmovaps [rsp+0xA0], xmm11
00007d3d957d507e  vmovaps [rsp+0xB0], xmm12
00007d3d957d5087  vmovaps [rsp+0xC0], xmm13
00007d3d957d5090  vmovaps [rsp+0xD0], xmm14
00007d3d957d5099  vmovaps [rsp+0xE0], xmm15
00007d3d957d50a2  sub rsp, 0x30
00007d3d957d50a6  movaps [rsp], xmm10
00007d3d957d50ab  movaps [rsp+0x10], xmm11
00007d3d957d50b1  movaps [rsp+0x20], xmm15
00007d3d957d50b7  lea rdi, [rsp]
00007d3d957d50bb  mov esi, 0x00
00007d3d957d50c0  mov rax, 0x56C27CB8A530
00007d3d957d50ca  call rax
00007d3d957d50cc  movaps xmm10, [rsp]
00007d3d957d50d1  add rsp, 0x30
00007d3d957d50d5  vmovaps xmm0, [rsp]
00007d3d957d50da  vmovaps xmm1, [rsp+0x10]
00007d3d957d50e0  vmovaps xmm2, [rsp+0x20]
00007d3d957d50e6  vmovaps xmm3, [rsp+0x30]
00007d3d957d50ec  vmovaps xmm4, [rsp+0x40]
00007d3d957d50f2  vmovaps xmm5, [rsp+0x50]
00007d3d957d50f8  vmovaps xmm6, [rsp+0x60]
00007d3d957d50fe  vmovaps xmm7, [rsp+0x70]
00007d3d957d5104  vmovaps xmm8, [rsp+0x80]
00007d3d957d510d  vmovaps xmm9, [rsp+0x90]
00007d3d957d5116  vmovaps xmm11, [rsp+0xA0]
00007d3d957d511f  vmovaps xmm12, [rsp+0xB0]
00007d3d957d5128  vmovaps xmm13, [rsp+0xC0]
00007d3d957d5131  vmovaps xmm14, [rsp+0xD0]
00007d3d957d513a  vmovaps xmm15, [rsp+0xE0]
00007d3d957d5143  add rsp, 0xF0
00007d3d957d514a  pop r11
00007d3d957d514c  pop r10
00007d3d957d514e  pop r9
00007d3d957d5150  pop r8
00007d3d957d5152  pop rsi
00007d3d957d5153  pop rdi
00007d3d957d5154  pop rdx
00007d3d957d5155  pop rcx
00007d3d957d5156  pop rax
00007d3d957d5157  add rsp, 0x08
00007d3d957d515b  jmp 0x00007D3D957D028B
00007d3d957d5160  sub rsp, 0x08
00007d3d957d5164  push rax
00007d3d957d5165  push rcx
00007d3d957d5166  push rdx
00007d3d957d5167  push rdi
00007d3d957d5168  push rsi
00007d3d957d5169  push r8
00007d3d957d516b  push r9
00007d3d957d516d  push r10
00007d3d957d516f  push r11
00007d3d957d5171  sub rsp, 0xF0
00007d3d957d5178  vmovaps [rsp], xmm0
00007d3d957d517d  vmovaps [rsp+0x10], xmm1
00007d3d957d5183  vmovaps [rsp+0x20], xmm2
00007d3d957d5189  vmovaps [rsp+0x30], xmm3
00007d3d957d518f  vmovaps [rsp+0x40], xmm4
00007d3d957d5195  vmovaps [rsp+0x50], xmm5
00007d3d957d519b  vmovaps [rsp+0x60], xmm6
00007d3d957d51a1  vmovaps [rsp+0x70], xmm7
00007d3d957d51a7  vmovaps [rsp+0x80], xmm8
00007d3d957d51b0  vmovaps [rsp+0x90], xmm9
00007d3d957d51b9  vmovaps [rsp+0xA0], xmm10
00007d3d957d51c2  vmovaps [rsp+0xB0], xmm12
00007d3d957d51cb  vmovaps [rsp+0xC0], xmm13
00007d3d957d51d4  vmovaps [rsp+0xD0], xmm14
00007d3d957d51dd  vmovaps [rsp+0xE0], xmm15
00007d3d957d51e6  sub rsp, 0x30
00007d3d957d51ea  movaps [rsp], xmm11
00007d3d957d51ef  movaps [rsp+0x10], xmm12
00007d3d957d51f5  movaps [rsp+0x20], xmm15
00007d3d957d51fb  lea rdi, [rsp]
00007d3d957d51ff  mov esi, 0x00
00007d3d957d5204  mov rax, 0x56C27CB8A530
00007d3d957d520e  call rax
00007d3d957d5210  movaps xmm11, [rsp]
00007d3d957d5215  add rsp, 0x30
00007d3d957d5219  vmovaps xmm0, [rsp]
00007d3d957d521e  vmovaps xmm1, [rsp+0x10]
00007d3d957d5224  vmovaps xmm2, [rsp+0x20]
00007d3d957d522a  vmovaps xmm3, [rsp+0x30]
00007d3d957d5230  vmovaps xmm4, [rsp+0x40]
00007d3d957d5236  vmovaps xmm5, [rsp+0x50]
00007d3d957d523c  vmovaps xmm6, [rsp+0x60]
00007d3d957d5242  vmovaps xmm7, [rsp+0x70]
00007d3d957d5248  vmovaps xmm8, [rsp+0x80]
00007d3d957d5251  vmovaps xmm9, [rsp+0x90]
00007d3d957d525a  vmovaps xmm10, [rsp+0xA0]
00007d3d957d5263  vmovaps xmm12, [rsp+0xB0]
00007d3d957d526c  vmovaps xmm13, [rsp+0xC0]
00007d3d957d5275  vmovaps xmm14, [rsp+0xD0]
00007d3d957d527e  vmovaps xmm15, [rsp+0xE0]
00007d3d957d5287  add rsp, 0xF0
00007d3d957d528e  pop r11
00007d3d957d5290  pop r10
00007d3d957d5292  pop r9
00007d3d957d5294  pop r8
00007d3d957d5296  pop rsi
00007d3d957d5297  pop rdi
00007d3d957d5298  pop rdx
00007d3d957d5299  pop rcx
00007d3d957d529a  pop rax
00007d3d957d529b  add rsp, 0x08
00007d3d957d529f  jmp 0x00007D3D957D02B9
00007d3d957d52a4  sub rsp, 0x08
00007d3d957d52a8  push rax
00007d3d957d52a9  push rcx
00007d3d957d52aa  push rdx
00007d3d957d52ab  push rdi
00007d3d957d52ac  push rsi
00007d3d957d52ad  push r8
00007d3d957d52af  push r9
00007d3d957d52b1  push r10
00007d3d957d52b3  push r11
00007d3d957d52b5  sub rsp, 0xF0
00007d3d957d52bc  vmovaps [rsp], xmm0
00007d3d957d52c1  vmovaps [rsp+0x10], xmm1
00007d3d957d52c7  vmovaps [rsp+0x20], xmm2
00007d3d957d52cd  vmovaps [rsp+0x30], xmm3
00007d3d957d52d3  vmovaps [rsp+0x40], xmm4
00007d3d957d52d9  vmovaps [rsp+0x50], xmm5
00007d3d957d52df  vmovaps [rsp+0x60], xmm6
00007d3d957d52e5  vmovaps [rsp+0x70], xmm7
00007d3d957d52eb  vmovaps [rsp+0x80], xmm8
00007d3d957d52f4  vmovaps [rsp+0x90], xmm9
00007d3d957d52fd  vmovaps [rsp+0xA0], xmm10
00007d3d957d5306  vmovaps [rsp+0xB0], xmm11
00007d3d957d530f  vmovaps [rsp+0xC0], xmm12
00007d3d957d5318  vmovaps [rsp+0xD0], xmm13
00007d3d957d5321  vmovaps [rsp+0xE0], xmm14
00007d3d957d532a  sub rsp, 0x30
00007d3d957d532e  movaps [rsp], xmm15
00007d3d957d5333  movaps [rsp+0x10], xmm13
00007d3d957d5339  movaps [rsp+0x20], xmm9
00007d3d957d533f  lea rdi, [rsp]
00007d3d957d5343  mov esi, 0x00
00007d3d957d5348  mov rax, 0x56C27CB8A530
00007d3d957d5352  call rax
00007d3d957d5354  movaps xmm15, [rsp]
00007d3d957d5359  add rsp, 0x30
00007d3d957d535d  vmovaps xmm0, [rsp]
00007d3d957d5362  vmovaps xmm1, [rsp+0x10]
00007d3d957d5368  vmovaps xmm2, [rsp+0x20]
00007d3d957d536e  vmovaps xmm3, [rsp+0x30]
00007d3d957d5374  vmovaps xmm4, [rsp+0x40]
00007d3d957d537a  vmovaps xmm5, [rsp+0x50]
00007d3d957d5380  vmovaps xmm6, [rsp+0x60]
00007d3d957d5386  vmovaps xmm7, [rsp+0x70]
00007d3d957d538c  vmovaps xmm8, [rsp+0x80]
00007d3d957d5395  vmovaps xmm9, [rsp+0x90]
00007d3d957d539e  vmovaps xmm10, [rsp+0xA0]
00007d3d957d53a7  vmovaps xmm11, [rsp+0xB0]
00007d3d957d53b0  vmovaps xmm12, [rsp+0xC0]
00007d3d957d53b9  vmovaps xmm13, [rsp+0xD0]
00007d3d957d53c2  vmovaps xmm14, [rsp+0xE0]
00007d3d957d53cb  add rsp, 0xF0
00007d3d957d53d2  pop r11
00007d3d957d53d4  pop r10
00007d3d957d53d6  pop r9
00007d3d957d53d8  pop r8
00007d3d957d53da  pop rsi
00007d3d957d53db  pop rdi
00007d3d957d53dc  pop rdx
00007d3d957d53dd  pop rcx
00007d3d957d53de  pop rax
00007d3d957d53df  add rsp, 0x08
00007d3d957d53e3  jmp 0x00007D3D957D02D4
00007d3d957d53e8  sub rsp, 0x08
00007d3d957d53ec  push rax
00007d3d957d53ed  push rcx
00007d3d957d53ee  push rdx
00007d3d957d53ef  push rdi
00007d3d957d53f0  push rsi
00007d3d957d53f1  push r8
00007d3d957d53f3  push r9
00007d3d957d53f5  push r10
00007d3d957d53f7  push r11
00007d3d957d53f9  sub rsp, 0xF0
00007d3d957d5400  vmovaps [rsp], xmm0
00007d3d957d5405  vmovaps [rsp+0x10], xmm1
00007d3d957d540b  vmovaps [rsp+0x20], xmm2
00007d3d957d5411  vmovaps [rsp+0x30], xmm3
00007d3d957d5417  vmovaps [rsp+0x40], xmm4
00007d3d957d541d  vmovaps [rsp+0x50], xmm5
00007d3d957d5423  vmovaps [rsp+0x60], xmm6
00007d3d957d5429  vmovaps [rsp+0x70], xmm7
00007d3d957d542f  vmovaps [rsp+0x80], xmm8
00007d3d957d5438  vmovaps [rsp+0x90], xmm9
00007d3d957d5441  vmovaps [rsp+0xA0], xmm10
00007d3d957d544a  vmovaps [rsp+0xB0], xmm11
00007d3d957d5453  vmovaps [rsp+0xC0], xmm12
00007d3d957d545c  vmovaps [rsp+0xD0], xmm14
00007d3d957d5465  vmovaps [rsp+0xE0], xmm15
00007d3d957d546e  sub rsp, 0x30
00007d3d957d5472  movaps [rsp], xmm13
00007d3d957d5477  movaps [rsp+0x10], xmm8
00007d3d957d547d  movaps [rsp+0x20], xmm14
00007d3d957d5483  lea rdi, [rsp]
00007d3d957d5487  mov esi, 0x00
00007d3d957d548c  mov rax, 0x56C27CB8A530
00007d3d957d5496  call rax
00007d3d957d5498  movaps xmm13, [rsp]
00007d3d957d549d  add rsp, 0x30
00007d3d957d54a1  vmovaps xmm0, [rsp]
00007d3d957d54a6  vmovaps xmm1, [rsp+0x10]
00007d3d957d54ac  vmovaps xmm2, [rsp+0x20]
00007d3d957d54b2  vmovaps xmm3, [rsp+0x30]
00007d3d957d54b8  vmovaps xmm4, [rsp+0x40]
00007d3d957d54be  vmovaps xmm5, [rsp+0x50]
00007d3d957d54c4  vmovaps xmm6, [rsp+0x60]
00007d3d957d54ca  vmovaps xmm7, [rsp+0x70]
00007d3d957d54d0  vmovaps xmm8, [rsp+0x80]
00007d3d957d54d9  vmovaps xmm9, [rsp+0x90]
00007d3d957d54e2  vmovaps xmm10, [rsp+0xA0]
00007d3d957d54eb  vmovaps xmm11, [rsp+0xB0]
00007d3d957d54f4  vmovaps xmm12, [rsp+0xC0]
00007d3d957d54fd  vmovaps xmm14, [rsp+0xD0]
00007d3d957d5506  vmovaps xmm15, [rsp+0xE0]
00007d3d957d550f  add rsp, 0xF0
00007d3d957d5516  pop r11
00007d3d957d5518  pop r10
00007d3d957d551a  pop r9
00007d3d957d551c  pop r8
00007d3d957d551e  pop rsi
00007d3d957d551f  pop rdi
00007d3d957d5520  pop rdx
00007d3d957d5521  pop rcx
00007d3d957d5522  pop rax
00007d3d957d5523  add rsp, 0x08
00007d3d957d5527  jmp 0x00007D3D957D02F7
00007d3d957d552c  sub rsp, 0x08
00007d3d957d5530  push rax
00007d3d957d5531  push rcx
00007d3d957d5532  push rdx
00007d3d957d5533  push rdi
00007d3d957d5534  push rsi
00007d3d957d5535  push r8
00007d3d957d5537  push r9
00007d3d957d5539  push r10
00007d3d957d553b  push r11
00007d3d957d553d  sub rsp, 0xF0
00007d3d957d5544  vmovaps [rsp], xmm0
00007d3d957d5549  vmovaps [rsp+0x10], xmm1
00007d3d957d554f  vmovaps [rsp+0x20], xmm2
00007d3d957d5555  vmovaps [rsp+0x30], xmm3
00007d3d957d555b  vmovaps [rsp+0x40], xmm4
00007d3d957d5561  vmovaps [rsp+0x50], xmm5
00007d3d957d5567  vmovaps [rsp+0x60], xmm6
00007d3d957d556d  vmovaps [rsp+0x70], xmm7
00007d3d957d5573  vmovaps [rsp+0x80], xmm8
00007d3d957d557c  vmovaps [rsp+0x90], xmm9
00007d3d957d5585  vmovaps [rsp+0xA0], xmm10
00007d3d957d558e  vmovaps [rsp+0xB0], xmm11
00007d3d957d5597  vmovaps [rsp+0xC0], xmm12
00007d3d957d55a0  vmovaps [rsp+0xD0], xmm13
00007d3d957d55a9  vmovaps [rsp+0xE0], xmm15
00007d3d957d55b2  sub rsp, 0x30
00007d3d957d55b6  movaps [rsp], xmm14
00007d3d957d55bb  movaps [rsp+0x10], xmm1
00007d3d957d55c0  movaps [rsp+0x20], xmm10
00007d3d957d55c6  lea rdi, [rsp]
00007d3d957d55ca  mov esi, 0x00
00007d3d957d55cf  mov rax, 0x56C27CB8A530
00007d3d957d55d9  call rax
00007d3d957d55db  movaps xmm14, [rsp]
00007d3d957d55e0  add rsp, 0x30
00007d3d957d55e4  vmovaps xmm0, [rsp]
00007d3d957d55e9  vmovaps xmm1, [rsp+0x10]
00007d3d957d55ef  vmovaps xmm2, [rsp+0x20]
00007d3d957d55f5  vmovaps xmm3, [rsp+0x30]
00007d3d957d55fb  vmovaps xmm4, [rsp+0x40]
00007d3d957d5601  vmovaps xmm5, [rsp+0x50]
00007d3d957d5607  vmovaps xmm6, [rsp+0x60]
00007d3d957d560d  vmovaps xmm7, [rsp+0x70]
00007d3d957d5613  vmovaps xmm8, [rsp+0x80]
00007d3d957d561c  vmovaps xmm9, [rsp+0x90]
00007d3d957d5625  vmovaps xmm10, [rsp+0xA0]
00007d3d957d562e  vmovaps xmm11, [rsp+0xB0]
00007d3d957d5637  vmovaps xmm12, [rsp+0xC0]
00007d3d957d5640  vmovaps xmm13, [rsp+0xD0]
00007d3d957d5649  vmovaps xmm15, [rsp+0xE0]
00007d3d957d5652  add rsp, 0xF0
00007d3d957d5659  pop r11
00007d3d957d565b  pop r10
00007d3d957d565d  pop r9
00007d3d957d565f  pop r8
00007d3d957d5661  pop rsi
00007d3d957d5662  pop rdi
00007d3d957d5663  pop rdx
00007d3d957d5664  pop rcx
00007d3d957d5665  pop rax
00007d3d957d5666  add rsp, 0x08
00007d3d957d566a  jmp 0x00007D3D957D031A
00007d3d957d566f  sub rsp, 0x08
00007d3d957d5673  push rax
00007d3d957d5674  push rcx
00007d3d957d5675  push rdx
00007d3d957d5676  push rdi
00007d3d957d5677  push rsi
00007d3d957d5678  push r8
00007d3d957d567a  push r9
00007d3d957d567c  push r10
00007d3d957d567e  push r11
00007d3d957d5680  sub rsp, 0xF0
00007d3d957d5687  vmovaps [rsp], xmm0
00007d3d957d568c  vmovaps [rsp+0x10], xmm2
00007d3d957d5692  vmovaps [rsp+0x20], xmm3
00007d3d957d5698  vmovaps [rsp+0x30], xmm4
00007d3d957d569e  vmovaps [rsp+0x40], xmm5
00007d3d957d56a4  vmovaps [rsp+0x50], xmm6
00007d3d957d56aa  vmovaps [rsp+0x60], xmm7
00007d3d957d56b0  vmovaps [rsp+0x70], xmm8
00007d3d957d56b6  vmovaps [rsp+0x80], xmm9
00007d3d957d56bf  vmovaps [rsp+0x90], xmm10
00007d3d957d56c8  vmovaps [rsp+0xA0], xmm11
00007d3d957d56d1  vmovaps [rsp+0xB0], xmm12
00007d3d957d56da  vmovaps [rsp+0xC0], xmm13
00007d3d957d56e3  vmovaps [rsp+0xD0], xmm14
00007d3d957d56ec  vmovaps [rsp+0xE0], xmm15
00007d3d957d56f5  sub rsp, 0x30
00007d3d957d56f9  movaps [rsp], xmm1
00007d3d957d56fd  movaps [rsp+0x10], xmm7
00007d3d957d5702  movaps [rsp+0x20], xmm11
00007d3d957d5708  lea rdi, [rsp]
00007d3d957d570c  mov esi, 0x00
00007d3d957d5711  mov rax, 0x56C27CB8A530
00007d3d957d571b  call rax
00007d3d957d571d  movaps xmm1, [rsp]
00007d3d957d5721  add rsp, 0x30
00007d3d957d5725  vmovaps xmm0, [rsp]
00007d3d957d572a  vmovaps xmm2, [rsp+0x10]
00007d3d957d5730  vmovaps xmm3, [rsp+0x20]
00007d3d957d5736  vmovaps xmm4, [rsp+0x30]
00007d3d957d573c  vmovaps xmm5, [rsp+0x40]
00007d3d957d5742  vmovaps xmm6, [rsp+0x50]
00007d3d957d5748  vmovaps xmm7, [rsp+0x60]
00007d3d957d574e  vmovaps xmm8, [rsp+0x70]
00007d3d957d5754  vmovaps xmm9, [rsp+0x80]
00007d3d957d575d  vmovaps xmm10, [rsp+0x90]
00007d3d957d5766  vmovaps xmm11, [rsp+0xA0]
00007d3d957d576f  vmovaps xmm12, [rsp+0xB0]
00007d3d957d5778  vmovaps xmm13, [rsp+0xC0]
00007d3d957d5781  vmovaps xmm14, [rsp+0xD0]
00007d3d957d578a  vmovaps xmm15, [rsp+0xE0]
00007d3d957d5793  add rsp, 0xF0
00007d3d957d579a  pop r11
00007d3d957d579c  pop r10
00007d3d957d579e  pop r9
00007d3d957d57a0  pop r8
00007d3d957d57a2  pop rsi
00007d3d957d57a3  pop rdi
00007d3d957d57a4  pop rdx
00007d3d957d57a5  pop rcx
00007d3d957d57a6  pop rax
00007d3d957d57a7  add rsp, 0x08
00007d3d957d57ab  jmp 0x00007D3D957D033B
00007d3d957d57b0  call 0x00007D3D9560E880
00007d3d957d57b5  jmp 0x00007D3D957D034E
00007d3d957d57ba  call 0x00007D3D9560C380
00007d3d957d57bf  jmp 0x00007D3D957D0359
00007d3d957d57c4  call 0x00007D3D9560D600
00007d3d957d57c9  jmp 0x00007D3D957D0364
00007d3d957d57ce  call 0x00007D3D955FF540
00007d3d957d57d3  jmp 0x00007D3D957D036F
00007d3d957d57d8  int3
00007d3d957d57d9  nop [rax], eax
00007d3d957d57e0  mov rax, [r15+0x40]
00007d3d957d57e4  mov r14, [r15+0x58]
00007d3d957d57e8  lea r12, [rax+r14*1]
00007d3d957d57ec  movaps xmm1, [r15+0x1D0]
00007d3d957d57f4  vmovaps [rsp+0x10], xmm1
00007d3d957d57fa  vmovaps xmm15, [rsp+0x10]
00007d3d957d5800  por xmm1, xmm15
00007d3d957d5805  movaps xmm14, [r15+0x1A0]
00007d3d957d580d  vmovaps [rsp+0x10], xmm14
00007d3d957d5813  vmovaps xmm13, [rsp+0x10]
00007d3d957d5819  por xmm14, xmm13
00007d3d957d581e  lea rax, [r12+0x30]
00007d3d957d5823  mov r11, [r13+rax*1]
00007d3d957d5828  lea rax, [r12+0x38]
00007d3d957d582d  mov r10, [r13+rax*1]
00007d3d957d5832  movq xmm13, r11
00007d3d957d5837  movq xmm12, r10
00007d3d957d583c  movq xmm13, xmm13
00007d3d957d5841  vmovaps [rsp+0x10], xmm13
00007d3d957d5847  movq xmm13, xmm13
00007d3d957d584c  movaps [r15+0x130], xmm13
00007d3d957d5854  movq xmm12, xmm12
00007d3d957d5859  vmovaps [rsp+0x20], xmm12
00007d3d957d585f  movq xmm12, xmm12
00007d3d957d5864  movaps [r15+0x280], xmm12
00007d3d957d586c  movaps xmm13, [r15+0x270]
00007d3d957d5874  vmovaps [rsp+0x30], xmm13
00007d3d957d587a  vmovaps xmm12, [rsp+0x30]
00007d3d957d5880  por xmm13, xmm12
00007d3d957d5885  lea rax, [r12+0x20]
00007d3d957d588a  mov r11, [r13+rax*1]
00007d3d957d588f  lea rax, [r12+0x28]
00007d3d957d5894  mov r10, [r13+rax*1]
00007d3d957d5899  movq xmm12, r11
00007d3d957d589e  movq xmm11, r10
00007d3d957d58a3  movq xmm12, xmm12
00007d3d957d58a8  vmovaps [rsp+0x30], xmm12
00007d3d957d58ae  movq xmm12, xmm12
00007d3d957d58b3  movaps [r15+0x150], xmm12
00007d3d957d58bb  movq xmm11, xmm11
00007d3d957d58c0  vmovaps [rsp+0x40], xmm11
00007d3d957d58c6  movq xmm11, xmm11
00007d3d957d58cb  movaps [r15+0x140], xmm11
00007d3d957d58d3  lea rax, [r12+0x10]
00007d3d957d58d8  mov r11, [r13+rax*1]
00007d3d957d58dd  lea rax, [r12+0x18]
00007d3d957d58e2  mov r10, [r13+rax*1]
00007d3d957d58e7  movq xmm12, r11
00007d3d957d58ec  movq xmm11, r10
00007d3d957d58f1  movq xmm12, xmm12
00007d3d957d58f6  vmovaps [rsp+0x50], xmm12
00007d3d957d58fc  movq xmm12, xmm12
00007d3d957d5901  movaps [r15+0x170], xmm12
00007d3d957d5909  movq xmm11, xmm11
00007d3d957d590e  vmovaps [rsp+0x60], xmm11
00007d3d957d5914  movq xmm11, xmm11
00007d3d957d5919  movaps [r15+0x160], xmm11
00007d3d957d5921  mov rax, [r13+r12*1]
00007d3d957d5926  vmovq xmm12, rax
00007d3d957d592b  vpbroadcastq xmm12, xmm12
00007d3d957d5930  lea rax, [r12+0x08]
00007d3d957d5935  mov r12, [r13+rax*1]
00007d3d957d593a  movq xmm11, r12
00007d3d957d593f  movaps [r15+0x230], xmm11
00007d3d957d5947  mov rax, [r15+0xF8]
00007d3d957d594e  lea r12, [rax+0x50]
00007d3d957d5952  movups xmm11, [r13+r12*1]
00007d3d957d5958  lea r12, [rax+0x60]
00007d3d957d595c  movups xmm10, [r13+r12*1]
00007d3d957d5962  lea r12, [rax+0x30]
00007d3d957d5966  movups xmm9, [r13+r12*1]
00007d3d957d596c  mov r12, [r15+0x50]
00007d3d957d5970  lea r11, [r12+r14*1]
00007d3d957d5974  mov [r15+0x60], r11
00007d3d957d5978  lea r12, [r14+0x40]
00007d3d957d597c  mov [r15+0x58], r12
00007d3d957d5980  movaps xmm8, xmm12
00007d3d957d5984  mulpd xmm8, xmm15
00007d3d957d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007d3d957d598f  ptest xmm7, xmm7
00007d3d957d5994  jnz 0x00007D3D957D67B7
00007d3d957d599a  movq xmm15, qword ptr [r15+0x230]
00007d3d957d59a3  vmovaps [rsp+0x70], xmm15
00007d3d957d59a9  vpermilpd xmm15, xmm15, 0x00
00007d3d957d59af  movaps xmm7, xmm9
00007d3d957d59b3  mulpd xmm7, xmm15
00007d3d957d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007d3d957d59bd  ptest xmm6, xmm6
00007d3d957d59c2  jnz 0x00007D3D957D68FB
00007d3d957d59c8  vxorps xmm15, xmm15, xmm15
00007d3d957d59cd  vpbroadcastq xmm15, xmm15
00007d3d957d59d2  movaps xmm9, xmm12
00007d3d957d59d6  mulpd xmm9, xmm10
00007d3d957d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007d3d957d59e1  ptest xmm6, xmm6
00007d3d957d59e6  jnz 0x00007D3D957D6A3D
00007d3d957d59ec  movaps xmm10, xmm12
00007d3d957d59f0  mulpd xmm10, xmm11
00007d3d957d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007d3d957d59fb  ptest xmm6, xmm6
00007d3d957d5a00  jnz 0x00007D3D957D6B81
00007d3d957d5a06  movaps xmm11, [r15+0x1F0]
00007d3d957d5a0e  movaps xmm6, xmm12
00007d3d957d5a12  mulpd xmm6, xmm11
00007d3d957d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007d3d957d5a1c  ptest xmm5, xmm5
00007d3d957d5a21  jnz 0x00007D3D957D6CC5
00007d3d957d5a27  movaps xmm12, [r15+0x2A0]
00007d3d957d5a2f  vmovaps [rsp+0x80], xmm12
00007d3d957d5a38  vmovaps xmm11, [rsp+0x80]
00007d3d957d5a41  por xmm12, xmm11
00007d3d957d5a46  movaps xmm11, [r15+0x250]
00007d3d957d5a4e  vmovaps [rsp+0x80], xmm11
00007d3d957d5a57  vmovaps xmm5, [rsp+0x80]
00007d3d957d5a60  por xmm11, xmm5
00007d3d957d5a65  vmovaps xmm4, [rsp+0x70]
00007d3d957d5a6b  vpermilpd xmm4, xmm4, 0x00
00007d3d957d5a71  movaps xmm3, xmm5
00007d3d957d5a74  mulpd xmm3, xmm4
00007d3d957d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007d3d957d5a7d  ptest xmm2, xmm2
00007d3d957d5a82  jnz 0x00007D3D957D6E07
00007d3d957d5a88  mov [rsp+0x80], rax
00007d3d957d5a90  xor eax, eax
00007d3d957d5a92  mov r14d, 0x200
00007d3d957d5a98  cmp r12, r14
00007d3d957d5a9b  cmc
00007d3d957d5a9c  lahf
00007d3d957d5a9d  seto al
00007d3d957d5aa0  mov [r15+0x108], eax
00007d3d957d5aa7  movaps xmm5, xmm8
00007d3d957d5aab  addpd xmm5, xmm15
00007d3d957d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007d3d957d5ab5  ptest xmm4, xmm4
00007d3d957d5aba  jnz 0x00007D3D957D6F47
00007d3d957d5ac0  movaps xmm8, [r15+0x1B0]
00007d3d957d5ac8  movaps xmm4, xmm9
00007d3d957d5acc  addpd xmm4, xmm8
00007d3d957d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007d3d957d5ad6  ptest xmm2, xmm2
00007d3d957d5adb  jnz 0x00007D3D957D7089
00007d3d957d5ae1  movaps xmm9, xmm10
00007d3d957d5ae5  addpd xmm9, xmm8
00007d3d957d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007d3d957d5af0  ptest xmm2, xmm2
00007d3d957d5af5  jnz 0x00007D3D957D71CB
00007d3d957d5afb  movaps xmm10, [r15+0x2F0]
00007d3d957d5b03  vmovaps [rsp+0x90], xmm10
00007d3d957d5b0c  vmovaps xmm8, [rsp+0x90]
00007d3d957d5b15  por xmm10, xmm8
00007d3d957d5b1a  movaps xmm8, [r15+0x2E0]
00007d3d957d5b22  vmovaps [rsp+0x90], xmm8
00007d3d957d5b2b  vmovaps xmm2, [rsp+0x90]
00007d3d957d5b34  por xmm8, xmm2
00007d3d957d5b39  movaps xmm2, [r15+0x2D0]
00007d3d957d5b41  vmovaps [rsp+0x90], xmm2
00007d3d957d5b4a  vmovaps [rsp+0xA0], xmm1
00007d3d957d5b53  vmovaps xmm1, [rsp+0x90]
00007d3d957d5b5c  por xmm2, xmm1
00007d3d957d5b60  movaps xmm1, [r15+0x200]
00007d3d957d5b68  vmovaps [rsp+0x90], xmm1
00007d3d957d5b71  vmovaps [rsp+0xB0], xmm15
00007d3d957d5b7a  vmovaps xmm15, [rsp+0x90]
00007d3d957d5b83  por xmm1, xmm15
00007d3d957d5b88  movaps xmm15, [r15+0x1C0]
00007d3d957d5b90  vmovaps [rsp+0x90], xmm15
00007d3d957d5b99  vmovaps [rsp+0xC0], xmm1
00007d3d957d5ba2  vmovaps xmm1, [rsp+0x90]
00007d3d957d5bab  por xmm15, xmm1
00007d3d957d5bb0  movaps xmm1, [r15+0x190]
00007d3d957d5bb8  vmovaps [rsp+0x90], xmm1
00007d3d957d5bc1  vmovaps [rsp+0xD0], xmm15
00007d3d957d5bca  vmovaps xmm15, [rsp+0x90]
00007d3d957d5bd3  por xmm1, xmm15
00007d3d957d5bd8  movaps xmm15, [r15+0x300]
00007d3d957d5be0  vmovaps [rsp+0x90], xmm15
00007d3d957d5be9  vmovaps [rsp+0xE0], xmm1
00007d3d957d5bf2  vmovaps xmm1, [rsp+0x90]
00007d3d957d5bfb  por xmm15, xmm1
00007d3d957d5c00  mov rax, [rsp+0x80]
00007d3d957d5c08  lea r14, [rax+0xA0]
00007d3d957d5c0f  movups xmm1, [r13+r14*1]
00007d3d957d5c15  lea r14, [rax+0xB0]
00007d3d957d5c1c  vmovaps [rsp+0x80], xmm1
00007d3d957d5c25  movups xmm1, [r13+r14*1]
00007d3d957d5c2b  vmovaps [rsp+0x90], xmm1
00007d3d957d5c34  vmovaps [rsp+0xF0], xmm15
00007d3d957d5c3d  vmovaps xmm15, [rsp+0xB0]
00007d3d957d5c46  vmovaps [rsp+0xB0], xmm14
00007d3d957d5c4f  movaps xmm1, xmm6
00007d3d957d5c52  addpd xmm1, xmm15
00007d3d957d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007d3d957d5c5c  ptest xmm14, xmm14
00007d3d957d5c62  jnz 0x00007D3D957D7323
00007d3d957d5c68  lea r14, [rax+0xF0]
00007d3d957d5c6f  movups xmm15, [r13+r14*1]
00007d3d957d5c75  movaps xmm14, xmm4
00007d3d957d5c79  addpd xmm14, xmm3
00007d3d957d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007d3d957d5c84  ptest xmm6, xmm6
00007d3d957d5c89  jnz 0x00007D3D957D746E
00007d3d957d5c8f  movaps xmm6, xmm9
00007d3d957d5c93  addpd xmm6, xmm7
00007d3d957d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007d3d957d5c9c  ptest xmm4, xmm4
00007d3d957d5ca1  jnz 0x00007D3D957D75B0
00007d3d957d5ca7  vmovaps xmm9, [rsp+0x70]
00007d3d957d5cad  vpermilpd xmm9, xmm9, 0x00
00007d3d957d5cb3  vmovaps xmm4, [rsp+0x90]
00007d3d957d5cbc  movaps xmm7, xmm4
00007d3d957d5cbf  mulpd xmm7, xmm9
00007d3d957d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007d3d957d5cc9  ptest xmm3, xmm3
00007d3d957d5cce  jnz 0x00007D3D957D76F1
00007d3d957d5cd4  vmovaps xmm9, [rsp+0x50]
00007d3d957d5cda  vpermilpd xmm9, xmm9, 0x00
00007d3d957d5ce0  movaps xmm4, xmm15
00007d3d957d5ce4  mulpd xmm4, xmm9
00007d3d957d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007d3d957d5cee  ptest xmm3, xmm3
00007d3d957d5cf3  jnz 0x00007D3D957D7832
00007d3d957d5cf9  lea r14, [rax+0xE0]
00007d3d957d5d00  movups xmm15, [r13+r14*1]
00007d3d957d5d06  vmovaps xmm9, [rsp+0x70]
00007d3d957d5d0c  vpermilpd xmm9, xmm9, 0x00
00007d3d957d5d12  vmovaps [rsp+0x70], xmm1
00007d3d957d5d18  vmovaps xmm1, [rsp+0x80]
00007d3d957d5d21  vmovaps [rsp+0x80], xmm15
00007d3d957d5d2a  movaps xmm3, xmm1
00007d3d957d5d2d  mulpd xmm3, xmm9
00007d3d957d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007d3d957d5d37  ptest xmm15, xmm15
00007d3d957d5d3d  jnz 0x00007D3D957D797E
00007d3d957d5d43  vmovaps xmm1, [rsp+0xF0]
00007d3d957d5d4c  vmovaps xmm15, [rsp+0xF0]
00007d3d957d5d55  por xmm1, xmm15
00007d3d957d5d5a  movaps [r15+0x300], xmm1
00007d3d957d5d62  vmovaps xmm15, [rsp+0xE0]
00007d3d957d5d6b  vmovaps xmm9, [rsp+0xE0]
00007d3d957d5d74  por xmm15, xmm9
00007d3d957d5d79  movaps [r15+0x190], xmm15
00007d3d957d5d81  vmovaps xmm9, [rsp+0x50]
00007d3d957d5d87  vpermilpd xmm9, xmm9, 0x00
00007d3d957d5d8d  vmovaps [rsp+0x90], xmm1
00007d3d957d5d96  vmovaps [rsp+0xE0], xmm15
00007d3d957d5d9f  vmovaps xmm15, [rsp+0x80]
00007d3d957d5da8  vmovaps [rsp+0x80], xmm14
00007d3d957d5db1  movaps xmm1, xmm15
00007d3d957d5db5  mulpd xmm1, xmm9
00007d3d957d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007d3d957d5dbf  ptest xmm14, xmm14
00007d3d957d5dc5  jnz 0x00007D3D957D7ABF
00007d3d957d5dcb  lea r14, [rax+0x90]
00007d3d957d5dd2  movups xmm15, [r13+r14*1]
00007d3d957d5dd8  vmovaps xmm14, [rsp+0xD0]
00007d3d957d5de1  vmovaps xmm9, [rsp+0xD0]
00007d3d957d5dea  por xmm14, xmm9
00007d3d957d5def  movaps [r15+0x1C0], xmm14
00007d3d957d5df7  vmovaps xmm9, [rsp+0xC0]
00007d3d957d5e00  vmovaps [rsp+0xD0], xmm1
00007d3d957d5e09  vmovaps xmm1, [rsp+0xC0]
00007d3d957d5e12  por xmm9, xmm1
00007d3d957d5e17  movaps [r15+0x200], xmm9
00007d3d957d5e1f  vmovaps [rsp+0xC0], xmm2
00007d3d957d5e28  vmovaps xmm1, [rsp+0xC0]
00007d3d957d5e31  por xmm2, xmm1
00007d3d957d5e35  movaps [r15+0x2D0], xmm2
00007d3d957d5e3d  vmovaps [rsp+0xC0], xmm8
00007d3d957d5e46  vmovaps xmm1, [rsp+0xC0]
00007d3d957d5e4f  por xmm8, xmm1
00007d3d957d5e54  movaps [r15+0x2E0], xmm8
00007d3d957d5e5c  vmovaps [rsp+0xC0], xmm15
00007d3d957d5e65  movaps xmm1, xmm5
00007d3d957d5e68  addpd xmm1, xmm7
00007d3d957d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007d3d957d5e71  ptest xmm15, xmm15
00007d3d957d5e77  jnz 0x00007D3D957D7C0B
00007d3d957d5e7d  vmovaps xmm15, [rsp+0x50]
00007d3d957d5e83  vpermilpd xmm15, xmm15, 0x00
00007d3d957d5e89  vmovaps xmm5, [rsp+0xC0]
00007d3d957d5e92  vmovaps [rsp+0xC0], xmm1
00007d3d957d5e9b  movaps xmm7, xmm5
00007d3d957d5e9e  mulpd xmm7, xmm15
00007d3d957d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007d3d957d5ea8  ptest xmm1, xmm1
00007d3d957d5ead  jnz 0x00007D3D957D7D4B
00007d3d957d5eb3  lea r14, [rax+0x80]
00007d3d957d5eba  movups xmm1, [r13+r14*1]
00007d3d957d5ec0  vmovaps xmm5, [rsp+0x70]
00007d3d957d5ec6  vmovaps [rsp+0x70], xmm1
00007d3d957d5ecc  movaps xmm15, xmm5
00007d3d957d5ed0  addpd xmm15, xmm3
00007d3d957d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007d3d957d5edb  ptest xmm1, xmm1
00007d3d957d5ee0  jnz 0x00007D3D957D7E96
00007d3d957d5ee6  vmovaps xmm5, [rsp+0x80]
00007d3d957d5eef  movaps xmm1, xmm5
00007d3d957d5ef2  addpd xmm1, xmm4
00007d3d957d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007d3d957d5efb  ptest xmm3, xmm3
00007d3d957d5f00  jnz 0x00007D3D957D7FD8
00007d3d957d5f06  vmovaps [rsp+0x80], xmm10
00007d3d957d5f0f  vmovaps xmm5, [rsp+0x80]
00007d3d957d5f18  por xmm10, xmm5
00007d3d957d5f1d  movaps [r15+0x2F0], xmm10
00007d3d957d5f25  vmovaps xmm5, [rsp+0x50]
00007d3d957d5f2b  vpermilpd xmm5, xmm5, 0x00
00007d3d957d5f31  vmovaps xmm3, [rsp+0x70]
00007d3d957d5f37  vmovaps [rsp+0x50], xmm1
00007d3d957d5f3d  movaps xmm4, xmm3
00007d3d957d5f40  mulpd xmm4, xmm5
00007d3d957d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007d3d957d5f49  ptest xmm1, xmm1
00007d3d957d5f4e  jnz 0x00007D3D957D8118
00007d3d957d5f54  lea r14, [rax+0xD0]
00007d3d957d5f5b  movups xmm1, [r13+r14*1]
00007d3d957d5f61  vmovaps xmm3, [rsp+0xD0]
00007d3d957d5f6a  vmovaps [rsp+0x70], xmm1
00007d3d957d5f70  movaps xmm5, xmm6
00007d3d957d5f73  addpd xmm5, xmm3
00007d3d957d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007d3d957d5f7c  ptest xmm1, xmm1
00007d3d957d5f81  jnz 0x00007D3D957D8262
00007d3d957d5f87  vmovaps xmm1, [rsp+0x60]
00007d3d957d5f8d  vpermilpd xmm1, xmm1, 0x00
00007d3d957d5f93  movaps xmm6, xmm9
00007d3d957d5f97  mulpd xmm6, xmm1
00007d3d957d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007d3d957d5fa0  ptest xmm3, xmm3
00007d3d957d5fa5  jnz 0x00007D3D957D83A2
00007d3d957d5fab  movaps [r15+0x260], xmm6
00007d3d957d5fb3  vxorps xmm1, xmm1, xmm1
00007d3d957d5fb7  vpbroadcastq xmm1, xmm1
00007d3d957d5fbc  movaps [r15+0x1B0], xmm1
00007d3d957d5fc4  vmovaps xmm1, [rsp+0x60]
00007d3d957d5fca  vpermilpd xmm1, xmm1, 0x00
00007d3d957d5fd0  vmovaps xmm3, [rsp+0x70]
00007d3d957d5fd6  vmovaps [rsp+0x70], xmm15
00007d3d957d5fdc  movaps xmm9, xmm3
00007d3d957d5fe0  mulpd xmm9, xmm1
00007d3d957d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007d3d957d5feb  ptest xmm15, xmm15
00007d3d957d5ff1  jnz 0x00007D3D957D84E3
00007d3d957d5ff7  lea r14, [rax+0xC0]
00007d3d957d5ffe  movups xmm1, [r13+r14*1]
00007d3d957d6004  vmovaps xmm3, [rsp+0xC0]
00007d3d957d600d  vmovaps [rsp+0x80], xmm1
00007d3d957d6016  movaps xmm15, xmm3
00007d3d957d601a  addpd xmm15, xmm7
00007d3d957d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007d3d957d6025  ptest xmm1, xmm1
00007d3d957d602a  jnz 0x00007D3D957D862F
00007d3d957d6030  vmovaps [rsp+0xC0], xmm13
00007d3d957d6039  vmovaps xmm1, [rsp+0xC0]
00007d3d957d6042  por xmm13, xmm1
00007d3d957d6047  movaps [r15+0x270], xmm13
00007d3d957d604f  vmovaps xmm1, [rsp+0xB0]
00007d3d957d6058  vmovaps xmm7, [rsp+0xB0]
00007d3d957d6061  por xmm1, xmm7
00007d3d957d6065  movaps [r15+0x1A0], xmm1
00007d3d957d606d  vmovaps xmm1, [rsp+0x60]
00007d3d957d6073  vpermilpd xmm1, xmm1, 0x00
00007d3d957d6079  vmovaps [rsp+0xB0], xmm1
00007d3d957d6082  vmovaps xmm1, [rsp+0x80]
00007d3d957d608b  vmovaps [rsp+0x80], xmm15
00007d3d957d6094  vmovaps xmm15, [rsp+0xB0]
00007d3d957d609d  vmovaps [rsp+0xB0], xmm14
00007d3d957d60a6  movaps xmm3, xmm1
00007d3d957d60a9  mulpd xmm3, xmm15
00007d3d957d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007d3d957d60b3  ptest xmm14, xmm14
00007d3d957d60b9  jnz 0x00007D3D957D8771
00007d3d957d60bf  lea r14, [rax+0x20]
00007d3d957d60c3  movups xmm1, [r13+r14*1]
00007d3d957d60c9  movaps [r15+0x110], xmm1
00007d3d957d60d1  vmovaps xmm14, [rsp+0x70]
00007d3d957d60d7  vmovaps [rsp+0x70], xmm1
00007d3d957d60dd  movaps xmm15, xmm14
00007d3d957d60e1  addpd xmm15, xmm4
00007d3d957d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007d3d957d60ec  ptest xmm1, xmm1
00007d3d957d60f1  jnz 0x00007D3D957D88BC
00007d3d957d60f7  vmovaps xmm1, [rsp+0x60]
00007d3d957d60fd  vpermilpd xmm1, xmm1, 0x00
00007d3d957d6103  movaps xmm14, xmm2
00007d3d957d6107  mulpd xmm14, xmm1
00007d3d957d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007d3d957d6112  ptest xmm4, xmm4
00007d3d957d6117  jnz 0x00007D3D957D89FF
00007d3d957d611d  vmovaps xmm4, [rsp+0x50]
00007d3d957d6123  movaps xmm1, xmm4
00007d3d957d6126  addpd xmm1, xmm9
00007d3d957d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007d3d957d6130  ptest xmm2, xmm2
00007d3d957d6135  jnz 0x00007D3D957D8B41
00007d3d957d613b  vmovaps xmm9, [rsp+0x30]
00007d3d957d6141  vpermilpd xmm9, xmm9, 0x00
00007d3d957d6147  vmovaps xmm2, [rsp+0x70]
00007d3d957d614d  vmovaps [rsp+0x50], xmm1
00007d3d957d6153  movaps xmm4, xmm2
00007d3d957d6156  mulpd xmm4, xmm9
00007d3d957d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007d3d957d6160  ptest xmm1, xmm1
00007d3d957d6165  jnz 0x00007D3D957D8C82
00007d3d957d616b  vmovaps xmm1, [rsp+0x30]
00007d3d957d6171  vpermilpd xmm1, xmm1, 0x00
00007d3d957d6177  vmovaps xmm2, [rsp+0x90]
00007d3d957d6180  vmovaps [rsp+0x60], xmm15
00007d3d957d6186  movaps xmm9, xmm2
00007d3d957d618a  mulpd xmm9, xmm1
00007d3d957d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007d3d957d6195  ptest xmm15, xmm15
00007d3d957d619b  jnz 0x00007D3D957D8DC3
00007d3d957d61a1  vmovaps xmm15, [rsp+0x80]
00007d3d957d61aa  movaps xmm1, xmm15
00007d3d957d61ae  addpd xmm1, xmm6
00007d3d957d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007d3d957d61b7  ptest xmm2, xmm2
00007d3d957d61bc  jnz 0x00007D3D957D8F05
00007d3d957d61c2  movaps xmm15, xmm5
00007d3d957d61c6  addpd xmm15, xmm3
00007d3d957d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007d3d957d61d1  ptest xmm6, xmm6
00007d3d957d61d6  jnz 0x00007D3D957D9046
00007d3d957d61dc  vmovaps xmm6, [rsp+0x30]
00007d3d957d61e2  vpermilpd xmm6, xmm6, 0x00
00007d3d957d61e8  movaps xmm5, xmm8
00007d3d957d61ec  mulpd xmm5, xmm6
00007d3d957d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007d3d957d61f5  ptest xmm3, xmm3
00007d3d957d61fa  jnz 0x00007D3D957D9188
00007d3d957d6200  vmovaps xmm8, [rsp+0x30]
00007d3d957d6206  vpermilpd xmm8, xmm8, 0x00
00007d3d957d620c  movaps xmm6, xmm10
00007d3d957d6210  mulpd xmm6, xmm8
00007d3d957d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007d3d957d621a  ptest xmm3, xmm3
00007d3d957d621f  jnz 0x00007D3D957D92C9
00007d3d957d6225  vmovaps xmm8, [rsp+0x60]
00007d3d957d622b  movaps xmm10, xmm8
00007d3d957d622f  addpd xmm10, xmm14
00007d3d957d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007d3d957d623a  ptest xmm3, xmm3
00007d3d957d623f  jnz 0x00007D3D957D940B
00007d3d957d6245  vmovaps xmm8, [rsp+0x50]
00007d3d957d624b  movaps xmm14, xmm8
00007d3d957d624f  addpd xmm14, xmm4
00007d3d957d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007d3d957d625a  ptest xmm3, xmm3
00007d3d957d625f  jnz 0x00007D3D957D954F
00007d3d957d6265  vmovaps xmm8, [rsp+0x40]
00007d3d957d626b  vpermilpd xmm8, xmm8, 0x00
00007d3d957d6271  movaps xmm4, xmm13
00007d3d957d6275  mulpd xmm4, xmm8
00007d3d957d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007d3d957d627f  ptest xmm3, xmm3
00007d3d957d6284  jnz 0x00007D3D957D9692
00007d3d957d628a  movaps xmm13, xmm15
00007d3d957d628e  addpd xmm13, xmm9
00007d3d957d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007d3d957d6299  ptest xmm8, xmm8
00007d3d957d629f  jnz 0x00007D3D957D97D4
00007d3d957d62a5  movaps xmm15, xmm1
00007d3d957d62a9  addpd xmm15, xmm5
00007d3d957d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007d3d957d62b4  ptest xmm9, xmm9
00007d3d957d62ba  jnz 0x00007D3D957D9918
00007d3d957d62c0  vmovaps [rsp+0x30], xmm11
00007d3d957d62c6  vmovaps xmm1, [rsp+0x30]
00007d3d957d62cc  por xmm11, xmm1
00007d3d957d62d1  movaps [r15+0x250], xmm11
00007d3d957d62d9  vmovaps [rsp+0x30], xmm12
00007d3d957d62df  vmovaps xmm1, [rsp+0x30]
00007d3d957d62e5  por xmm12, xmm1
00007d3d957d62ea  movaps [r15+0x2A0], xmm12
00007d3d957d62f2  vmovaps xmm1, [rsp+0xA0]
00007d3d957d62fb  vmovaps xmm11, [rsp+0xA0]
00007d3d957d6304  por xmm1, xmm11
00007d3d957d6309  movaps [r15+0x1D0], xmm1
00007d3d957d6311  lea r14, [rax+0x40]
00007d3d957d6315  movups xmm1, [r13+r14*1]
00007d3d957d631b  movaps [r15+0x2C0], xmm1
00007d3d957d6323  vmovaps xmm11, [rsp+0x40]
00007d3d957d6329  vpermilpd xmm11, xmm11, 0x00
00007d3d957d632f  vmovaps xmm8, [rsp+0xE0]
00007d3d957d6338  movaps xmm9, xmm8
00007d3d957d633c  mulpd xmm9, xmm11
00007d3d957d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007d3d957d6347  ptest xmm5, xmm5
00007d3d957d634c  jnz 0x00007D3D957D9A64
00007d3d957d6352  movaps xmm11, xmm10
00007d3d957d6356  addpd xmm11, xmm6
00007d3d957d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007d3d957d6361  ptest xmm8, xmm8
00007d3d957d6367  jnz 0x00007D3D957D9BA8
00007d3d957d636d  movaps xmm10, xmm14
00007d3d957d6371  addpd xmm10, xmm4
00007d3d957d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007d3d957d637c  ptest xmm8, xmm8
00007d3d957d6382  jnz 0x00007D3D957D9CEB
00007d3d957d6388  vmovaps xmm14, [rsp+0x40]
00007d3d957d638e  vpermilpd xmm14, xmm14, 0x00
00007d3d957d6394  movaps xmm8, xmm1
00007d3d957d6398  mulpd xmm8, xmm14
00007d3d957d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007d3d957d63a3  ptest xmm6, xmm6
00007d3d957d63a8  jnz 0x00007D3D957D9E2E
00007d3d957d63ae  movaps xmm1, [r15+0x2B0]
00007d3d957d63b6  vmovaps xmm14, [rsp+0x40]
00007d3d957d63bc  vpermilpd xmm14, xmm14, 0x00
00007d3d957d63c2  movaps xmm6, xmm1
00007d3d957d63c5  mulpd xmm6, xmm14
00007d3d957d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007d3d957d63cf  ptest xmm5, xmm5
00007d3d957d63d4  jnz 0x00007D3D957D9F71
00007d3d957d63da  vmovaps xmm1, [rsp+0x10]
00007d3d957d63e0  vpermilpd xmm1, xmm1, 0x00
00007d3d957d63e6  movaps xmm14, xmm12
00007d3d957d63ea  mulpd xmm14, xmm1
00007d3d957d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007d3d957d63f5  ptest xmm5, xmm5
00007d3d957d63fa  jnz 0x00007D3D957DA0B2
00007d3d957d6400  movaps xmm1, xmm13
00007d3d957d6404  addpd xmm1, xmm9
00007d3d957d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007d3d957d640e  ptest xmm12, xmm12
00007d3d957d6414  jnz 0x00007D3D957DA1F5
00007d3d957d641a  vmovaps xmm13, [rsp+0x10]
00007d3d957d6420  vpermilpd xmm13, xmm13, 0x00
00007d3d957d6426  movaps xmm12, xmm7
00007d3d957d642a  mulpd xmm12, xmm13
00007d3d957d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007d3d957d6435  ptest xmm9, xmm9
00007d3d957d643b  jnz 0x00007D3D957DA337
00007d3d957d6441  movaps xmm13, xmm15
00007d3d957d6445  addpd xmm13, xmm8
00007d3d957d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007d3d957d6450  ptest xmm9, xmm9
00007d3d957d6456  jnz 0x00007D3D957DA47A
00007d3d957d645c  movaps xmm15, [r15+0x290]
00007d3d957d6464  vmovaps xmm9, [rsp+0x10]
00007d3d957d646a  vpermilpd xmm9, xmm9, 0x00
00007d3d957d6470  movaps xmm8, xmm15
00007d3d957d6474  mulpd xmm8, xmm9
00007d3d957d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007d3d957d647f  ptest xmm7, xmm7
00007d3d957d6484  jnz 0x00007D3D957DA5BE
00007d3d957d648a  movaps xmm15, xmm11
00007d3d957d648e  addpd xmm15, xmm6
00007d3d957d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007d3d957d6499  ptest xmm9, xmm9
00007d3d957d649f  jnz 0x00007D3D957DA702
00007d3d957d64a5  movaps xmm11, [r15+0x1E0]
00007d3d957d64ad  vmovaps xmm9, [rsp+0x10]
00007d3d957d64b3  vpermilpd xmm9, xmm9, 0x00
00007d3d957d64b9  movaps xmm7, xmm11
00007d3d957d64bd  mulpd xmm7, xmm9
00007d3d957d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007d3d957d64c7  ptest xmm6, xmm6
00007d3d957d64cc  jnz 0x00007D3D957DA845
00007d3d957d64d2  movaps xmm11, xmm10
00007d3d957d64d6  addpd xmm11, xmm14
00007d3d957d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007d3d957d64e1  ptest xmm9, xmm9
00007d3d957d64e7  jnz 0x00007D3D957DA987
00007d3d957d64ed  lea r14, [rax+0x70]
00007d3d957d64f1  movups xmm14, [r13+r14*1]
00007d3d957d64f7  movaps [r15+0x240], xmm14
00007d3d957d64ff  movaps xmm10, xmm1
00007d3d957d6503  addpd xmm10, xmm12
00007d3d957d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007d3d957d650e  ptest xmm9, xmm9
00007d3d957d6514  jnz 0x00007D3D957DAAD5
00007d3d957d651a  movaps [r15+0x170], xmm10
00007d3d957d6522  vmovaps xmm1, [rsp+0x20]
00007d3d957d6528  vpermilpd xmm1, xmm1, 0x00
00007d3d957d652e  movaps xmm12, xmm14
00007d3d957d6532  mulpd xmm12, xmm1
00007d3d957d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007d3d957d653d  ptest xmm9, xmm9
00007d3d957d6543  jnz 0x00007D3D957DAC18
00007d3d957d6549  vmovaps xmm1, [rsp+0x20]
00007d3d957d654f  vpermilpd xmm1, xmm1, 0x00
00007d3d957d6555  vmovaps xmm9, [rsp+0xB0]
00007d3d957d655e  movaps xmm14, xmm9
00007d3d957d6562  mulpd xmm14, xmm1
00007d3d957d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007d3d957d656d  ptest xmm6, xmm6
00007d3d957d6572  jnz 0x00007D3D957DAD5B
00007d3d957d6578  movaps [r15+0x180], xmm14
00007d3d957d6580  movaps xmm1, xmm13
00007d3d957d6584  addpd xmm1, xmm8
00007d3d957d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007d3d957d658e  ptest xmm9, xmm9
00007d3d957d6594  jnz 0x00007D3D957DAE9E
00007d3d957d659a  movaps [r15+0x210], xmm1
00007d3d957d65a2  movups xmm13, [r13+rax*1]
00007d3d957d65a8  lea r14, [rax+0x10]
00007d3d957d65ac  movups xmm9, [r13+r14*1]
00007d3d957d65b2  movaps [r15+0x230], xmm9
00007d3d957d65ba  movaps xmm8, xmm15
00007d3d957d65be  addpd xmm8, xmm7
00007d3d957d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007d3d957d65c9  ptest xmm6, xmm6
00007d3d957d65ce  jnz 0x00007D3D957DAFF4
00007d3d957d65d4  movaps [r15+0x130], xmm8
00007d3d957d65dc  vmovaps xmm15, [rsp+0x20]
00007d3d957d65e2  vpermilpd xmm15, xmm15, 0x00
00007d3d957d65e8  movaps xmm7, xmm9
00007d3d957d65ec  mulpd xmm7, xmm15
00007d3d957d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007d3d957d65f6  ptest xmm6, xmm6
00007d3d957d65fb  jnz 0x00007D3D957DB137
00007d3d957d6601  movaps [r15+0x220], xmm7
00007d3d957d6609  vmovaps xmm15, [rsp+0x20]
00007d3d957d660f  vpermilpd xmm15, xmm15, 0x00
00007d3d957d6615  movaps xmm9, xmm13
00007d3d957d6619  mulpd xmm9, xmm15
00007d3d957d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007d3d957d6624  ptest xmm6, xmm6
00007d3d957d6629  jnz 0x00007D3D957DB279
00007d3d957d662f  movaps xmm15, xmm11
00007d3d957d6633  addpd xmm15, xmm12
00007d3d957d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007d3d957d663e  ptest xmm13, xmm13
00007d3d957d6644  jnz 0x00007D3D957DB3BD
00007d3d957d664a  movaps [r15+0x140], xmm15
00007d3d957d6652  movaps xmm13, xmm10
00007d3d957d6656  addpd xmm13, xmm14
00007d3d957d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007d3d957d6661  ptest xmm12, xmm12
00007d3d957d6667  jnz 0x00007D3D957DB501
00007d3d957d666d  movaps [r15+0x150], xmm13
00007d3d957d6675  movaps xmm14, xmm1
00007d3d957d6679  addpd xmm14, xmm7
00007d3d957d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007d3d957d6684  ptest xmm12, xmm12
00007d3d957d668a  jnz 0x00007D3D957DB645
00007d3d957d6690  movaps [r15+0x160], xmm14
00007d3d957d6698  movaps xmm1, xmm8
00007d3d957d669c  addpd xmm1, xmm9
00007d3d957d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007d3d957d66a6  ptest xmm12, xmm12
00007d3d957d66ac  jnz 0x00007D3D957DB787
00007d3d957d66b2  movaps [r15+0x120], xmm1
00007d3d957d66ba  movups [r13+r11*1], xmm15
00007d3d957d66c0  lea rax, [r11+0x10]
00007d3d957d66c4  movups [r13+rax*1], xmm13
00007d3d957d66ca  lea rax, [r11+0x20]
00007d3d957d66ce  movups [r13+rax*1], xmm14
00007d3d957d66d4  lea rax, [r11+0x30]
00007d3d957d66d8  movups [r13+rax*1], xmm1
00007d3d957d66de  mov eax, [r15+0x108]
00007d3d957d66e5  sahf
00007d3d957d66e6  jnz 0x00007D3D957D6718
00007d3d957d66e8  cmp dword ptr [r15+0x318], 0x00
00007d3d957d66f0  jz 0x00007D3D957DB900
00007d3d957d66f6  nop [rax+rax*1], ax
00007d3d957d66ff  nop [rax+rax*1], eax
00007d3d957d6707  mov eax, 0x410444
00007d3d957d670c  mov [r15+0x100], rax
00007d3d957d6713  jmp 0x00007D3D955FE110
00007d3d957d6718  cmp dword ptr [r15+0x318], 0x00
00007d3d957d6720  jz 0x00007D3D957D57E0
00007d3d957d6726  nop [rax+rax*1], ax
00007d3d957d672f  nop [rax+rax*1], eax
00007d3d957d6737  mov eax, 0x410278
00007d3d957d673c  mov [r15+0x100], rax
00007d3d957d6743  jmp 0x00007D3D955FE110
00007d3d957d6748  int3
00007d3d957d6749  call 0x00007D3D9560A4B0
00007d3d957d674e  jmp 0x00007D3D957D5828
00007d3d957d6753  call 0x00007D3D95609240
00007d3d957d6758  jmp 0x00007D3D957D5832
00007d3d957d675d  call 0x00007D3D9560A4B0
00007d3d957d6762  jmp 0x00007D3D957D588F
00007d3d957d6767  call 0x00007D3D95609240
00007d3d957d676c  jmp 0x00007D3D957D5899
00007d3d957d6771  call 0x00007D3D9560A4B0
00007d3d957d6776  jmp 0x00007D3D957D58DD
00007d3d957d677b  call 0x00007D3D95609240
00007d3d957d6780  jmp 0x00007D3D957D58E7
00007d3d957d6785  call 0x00007D3D956B47C0
00007d3d957d678a  jmp 0x00007D3D957D5926
00007d3d957d678f  call 0x00007D3D9560B720
00007d3d957d6794  jmp 0x00007D3D957D593A
00007d3d957d6799  call 0x00007D3D956BFC30
00007d3d957d679e  jmp 0x00007D3D957D5958
00007d3d957d67a3  call 0x00007D3D956BE9C0
00007d3d957d67a8  jmp 0x00007D3D957D5962
00007d3d957d67ad  call 0x00007D3D956BD750
00007d3d957d67b2  jmp 0x00007D3D957D596C
00007d3d957d67b7  sub rsp, 0x08
00007d3d957d67bb  push rax
00007d3d957d67bc  push rcx
00007d3d957d67bd  push rdx
00007d3d957d67be  push rdi
00007d3d957d67bf  push rsi
00007d3d957d67c0  push r8
00007d3d957d67c2  push r9
00007d3d957d67c4  push r10
00007d3d957d67c6  push r11
00007d3d957d67c8  sub rsp, 0xF0
00007d3d957d67cf  vmovaps [rsp], xmm0
00007d3d957d67d4  vmovaps [rsp+0x10], xmm1
00007d3d957d67da  vmovaps [rsp+0x20], xmm2
00007d3d957d67e0  vmovaps [rsp+0x30], xmm3
00007d3d957d67e6  vmovaps [rsp+0x40], xmm4
00007d3d957d67ec  vmovaps [rsp+0x50], xmm5
00007d3d957d67f2  vmovaps [rsp+0x60], xmm6
00007d3d957d67f8  vmovaps [rsp+0x70], xmm7
00007d3d957d67fe  vmovaps [rsp+0x80], xmm9
00007d3d957d6807  vmovaps [rsp+0x90], xmm10
00007d3d957d6810  vmovaps [rsp+0xA0], xmm11
00007d3d957d6819  vmovaps [rsp+0xB0], xmm12
00007d3d957d6822  vmovaps [rsp+0xC0], xmm13
00007d3d957d682b  vmovaps [rsp+0xD0], xmm14
00007d3d957d6834  vmovaps [rsp+0xE0], xmm15
00007d3d957d683d  sub rsp, 0x30
00007d3d957d6841  movaps [rsp], xmm8
00007d3d957d6846  movaps [rsp+0x10], xmm12
00007d3d957d684c  movaps [rsp+0x20], xmm15
00007d3d957d6852  lea rdi, [rsp]
00007d3d957d6856  mov esi, 0x00
00007d3d957d685b  mov rax, 0x56C27CB8A530
00007d3d957d6865  call rax
00007d3d957d6867  movaps xmm8, [rsp]
00007d3d957d686c  add rsp, 0x30
00007d3d957d6870  vmovaps xmm0, [rsp]
00007d3d957d6875  vmovaps xmm1, [rsp+0x10]
00007d3d957d687b  vmovaps xmm2, [rsp+0x20]
00007d3d957d6881  vmovaps xmm3, [rsp+0x30]
00007d3d957d6887  vmovaps xmm4, [rsp+0x40]
00007d3d957d688d  vmovaps xmm5, [rsp+0x50]
00007d3d957d6893  vmovaps xmm6, [rsp+0x60]
00007d3d957d6899  vmovaps xmm7, [rsp+0x70]
00007d3d957d689f  vmovaps xmm9, [rsp+0x80]
00007d3d957d68a8  vmovaps xmm10, [rsp+0x90]
00007d3d957d68b1  vmovaps xmm11, [rsp+0xA0]
00007d3d957d68ba  vmovaps xmm12, [rsp+0xB0]
00007d3d957d68c3  vmovaps xmm13, [rsp+0xC0]
00007d3d957d68cc  vmovaps xmm14, [rsp+0xD0]
00007d3d957d68d5  vmovaps xmm15, [rsp+0xE0]
00007d3d957d68de  add rsp, 0xF0
00007d3d957d68e5  pop r11
00007d3d957d68e7  pop r10
00007d3d957d68e9  pop r9
00007d3d957d68eb  pop r8
00007d3d957d68ed  pop rsi
00007d3d957d68ee  pop rdi
00007d3d957d68ef  pop rdx
00007d3d957d68f0  pop rcx
00007d3d957d68f1  pop rax
00007d3d957d68f2  add rsp, 0x08
00007d3d957d68f6  jmp 0x00007D3D957D599A
00007d3d957d68fb  sub rsp, 0x08
00007d3d957d68ff  push rax
00007d3d957d6900  push rcx
00007d3d957d6901  push rdx
00007d3d957d6902  push rdi
00007d3d957d6903  push rsi
00007d3d957d6904  push r8
00007d3d957d6906  push r9
00007d3d957d6908  push r10
00007d3d957d690a  push r11
00007d3d957d690c  sub rsp, 0xF0
00007d3d957d6913  vmovaps [rsp], xmm0
00007d3d957d6918  vmovaps [rsp+0x10], xmm1
00007d3d957d691e  vmovaps [rsp+0x20], xmm2
00007d3d957d6924  vmovaps [rsp+0x30], xmm3
00007d3d957d692a  vmovaps [rsp+0x40], xmm4
00007d3d957d6930  vmovaps [rsp+0x50], xmm5
00007d3d957d6936  vmovaps [rsp+0x60], xmm6
00007d3d957d693c  vmovaps [rsp+0x70], xmm8
00007d3d957d6942  vmovaps [rsp+0x80], xmm9
00007d3d957d694b  vmovaps [rsp+0x90], xmm10
00007d3d957d6954  vmovaps [rsp+0xA0], xmm11
00007d3d957d695d  vmovaps [rsp+0xB0], xmm12
00007d3d957d6966  vmovaps [rsp+0xC0], xmm13
00007d3d957d696f  vmovaps [rsp+0xD0], xmm14
00007d3d957d6978  vmovaps [rsp+0xE0], xmm15
00007d3d957d6981  sub rsp, 0x30
00007d3d957d6985  movaps [rsp], xmm7
00007d3d957d6989  movaps [rsp+0x10], xmm9
00007d3d957d698f  movaps [rsp+0x20], xmm15
00007d3d957d6995  lea rdi, [rsp]
00007d3d957d6999  mov esi, 0x00
00007d3d957d699e  mov rax, 0x56C27CB8A530
00007d3d957d69a8  call rax
00007d3d957d69aa  movaps xmm7, [rsp]
00007d3d957d69ae  add rsp, 0x30
00007d3d957d69b2  vmovaps xmm0, [rsp]
00007d3d957d69b7  vmovaps xmm1, [rsp+0x10]
00007d3d957d69bd  vmovaps xmm2, [rsp+0x20]
00007d3d957d69c3  vmovaps xmm3, [rsp+0x30]
00007d3d957d69c9  vmovaps xmm4, [rsp+0x40]
00007d3d957d69cf  vmovaps xmm5, [rsp+0x50]
00007d3d957d69d5  vmovaps xmm6, [rsp+0x60]
00007d3d957d69db  vmovaps xmm8, [rsp+0x70]
00007d3d957d69e1  vmovaps xmm9, [rsp+0x80]
00007d3d957d69ea  vmovaps xmm10, [rsp+0x90]
00007d3d957d69f3  vmovaps xmm11, [rsp+0xA0]
00007d3d957d69fc  vmovaps xmm12, [rsp+0xB0]
00007d3d957d6a05  vmovaps xmm13, [rsp+0xC0]
00007d3d957d6a0e  vmovaps xmm14, [rsp+0xD0]
00007d3d957d6a17  vmovaps xmm15, [rsp+0xE0]
00007d3d957d6a20  add rsp, 0xF0
00007d3d957d6a27  pop r11
00007d3d957d6a29  pop r10
00007d3d957d6a2b  pop r9
00007d3d957d6a2d  pop r8
00007d3d957d6a2f  pop rsi
00007d3d957d6a30  pop rdi
00007d3d957d6a31  pop rdx
00007d3d957d6a32  pop rcx
00007d3d957d6a33  pop rax
00007d3d957d6a34  add rsp, 0x08
00007d3d957d6a38  jmp 0x00007D3D957D59C8
00007d3d957d6a3d  sub rsp, 0x08
00007d3d957d6a41  push rax
00007d3d957d6a42  push rcx
00007d3d957d6a43  push rdx
00007d3d957d6a44  push rdi
00007d3d957d6a45  push rsi
00007d3d957d6a46  push r8
00007d3d957d6a48  push r9
00007d3d957d6a4a  push r10
00007d3d957d6a4c  push r11
00007d3d957d6a4e  sub rsp, 0xF0
00007d3d957d6a55  vmovaps [rsp], xmm0
00007d3d957d6a5a  vmovaps [rsp+0x10], xmm1
00007d3d957d6a60  vmovaps [rsp+0x20], xmm2
00007d3d957d6a66  vmovaps [rsp+0x30], xmm3
00007d3d957d6a6c  vmovaps [rsp+0x40], xmm4
00007d3d957d6a72  vmovaps [rsp+0x50], xmm5
00007d3d957d6a78  vmovaps [rsp+0x60], xmm6
00007d3d957d6a7e  vmovaps [rsp+0x70], xmm7
00007d3d957d6a84  vmovaps [rsp+0x80], xmm8
00007d3d957d6a8d  vmovaps [rsp+0x90], xmm10
00007d3d957d6a96  vmovaps [rsp+0xA0], xmm11
00007d3d957d6a9f  vmovaps [rsp+0xB0], xmm12
00007d3d957d6aa8  vmovaps [rsp+0xC0], xmm13
00007d3d957d6ab1  vmovaps [rsp+0xD0], xmm14
00007d3d957d6aba  vmovaps [rsp+0xE0], xmm15
00007d3d957d6ac3  sub rsp, 0x30
00007d3d957d6ac7  movaps [rsp], xmm9
00007d3d957d6acc  movaps [rsp+0x10], xmm12
00007d3d957d6ad2  movaps [rsp+0x20], xmm10
00007d3d957d6ad8  lea rdi, [rsp]
00007d3d957d6adc  mov esi, 0x00
00007d3d957d6ae1  mov rax, 0x56C27CB8A530
00007d3d957d6aeb  call rax
00007d3d957d6aed  movaps xmm9, [rsp]
00007d3d957d6af2  add rsp, 0x30
00007d3d957d6af6  vmovaps xmm0, [rsp]
00007d3d957d6afb  vmovaps xmm1, [rsp+0x10]
00007d3d957d6b01  vmovaps xmm2, [rsp+0x20]
00007d3d957d6b07  vmovaps xmm3, [rsp+0x30]
00007d3d957d6b0d  vmovaps xmm4, [rsp+0x40]
00007d3d957d6b13  vmovaps xmm5, [rsp+0x50]
00007d3d957d6b19  vmovaps xmm6, [rsp+0x60]
00007d3d957d6b1f  vmovaps xmm7, [rsp+0x70]
00007d3d957d6b25  vmovaps xmm8, [rsp+0x80]
00007d3d957d6b2e  vmovaps xmm10, [rsp+0x90]
00007d3d957d6b37  vmovaps xmm11, [rsp+0xA0]
00007d3d957d6b40  vmovaps xmm12, [rsp+0xB0]
00007d3d957d6b49  vmovaps xmm13, [rsp+0xC0]
00007d3d957d6b52  vmovaps xmm14, [rsp+0xD0]
00007d3d957d6b5b  vmovaps xmm15, [rsp+0xE0]
00007d3d957d6b64  add rsp, 0xF0
00007d3d957d6b6b  pop r11
00007d3d957d6b6d  pop r10
00007d3d957d6b6f  pop r9
00007d3d957d6b71  pop r8
00007d3d957d6b73  pop rsi
00007d3d957d6b74  pop rdi
00007d3d957d6b75  pop rdx
00007d3d957d6b76  pop rcx
00007d3d957d6b77  pop rax
00007d3d957d6b78  add rsp, 0x08
00007d3d957d6b7c  jmp 0x00007D3D957D59EC
00007d3d957d6b81  sub rsp, 0x08
00007d3d957d6b85  push rax
00007d3d957d6b86  push rcx
00007d3d957d6b87  push rdx
00007d3d957d6b88  push rdi
00007d3d957d6b89  push rsi
00007d3d957d6b8a  push r8
00007d3d957d6b8c  push r9
00007d3d957d6b8e  push r10
00007d3d957d6b90  push r11
00007d3d957d6b92  sub rsp, 0xF0
00007d3d957d6b99  vmovaps [rsp], xmm0
00007d3d957d6b9e  vmovaps [rsp+0x10], xmm1
00007d3d957d6ba4  vmovaps [rsp+0x20], xmm2
00007d3d957d6baa  vmovaps [rsp+0x30], xmm3
00007d3d957d6bb0  vmovaps [rsp+0x40], xmm4
00007d3d957d6bb6  vmovaps [rsp+0x50], xmm5
00007d3d957d6bbc  vmovaps [rsp+0x60], xmm6
00007d3d957d6bc2  vmovaps [rsp+0x70], xmm7
00007d3d957d6bc8  vmovaps [rsp+0x80], xmm8
00007d3d957d6bd1  vmovaps [rsp+0x90], xmm9
00007d3d957d6bda  vmovaps [rsp+0xA0], xmm11
00007d3d957d6be3  vmovaps [rsp+0xB0], xmm12
00007d3d957d6bec  vmovaps [rsp+0xC0], xmm13
00007d3d957d6bf5  vmovaps [rsp+0xD0], xmm14
00007d3d957d6bfe  vmovaps [rsp+0xE0], xmm15
00007d3d957d6c07  sub rsp, 0x30
00007d3d957d6c0b  movaps [rsp], xmm10
00007d3d957d6c10  movaps [rsp+0x10], xmm12
00007d3d957d6c16  movaps [rsp+0x20], xmm11
00007d3d957d6c1c  lea rdi, [rsp]
00007d3d957d6c20  mov esi, 0x00
00007d3d957d6c25  mov rax, 0x56C27CB8A530
00007d3d957d6c2f  call rax
00007d3d957d6c31  movaps xmm10, [rsp]
00007d3d957d6c36  add rsp, 0x30
00007d3d957d6c3a  vmovaps xmm0, [rsp]
00007d3d957d6c3f  vmovaps xmm1, [rsp+0x10]
00007d3d957d6c45  vmovaps xmm2, [rsp+0x20]
00007d3d957d6c4b  vmovaps xmm3, [rsp+0x30]
00007d3d957d6c51  vmovaps xmm4, [rsp+0x40]
00007d3d957d6c57  vmovaps xmm5, [rsp+0x50]
00007d3d957d6c5d  vmovaps xmm6, [rsp+0x60]
00007d3d957d6c63  vmovaps xmm7, [rsp+0x70]
00007d3d957d6c69  vmovaps xmm8, [rsp+0x80]
00007d3d957d6c72  vmovaps xmm9, [rsp+0x90]
00007d3d957d6c7b  vmovaps xmm11, [rsp+0xA0]
00007d3d957d6c84  vmovaps xmm12, [rsp+0xB0]
00007d3d957d6c8d  vmovaps xmm13, [rsp+0xC0]
00007d3d957d6c96  vmovaps xmm14, [rsp+0xD0]
00007d3d957d6c9f  vmovaps xmm15, [rsp+0xE0]
00007d3d957d6ca8  add rsp, 0xF0
00007d3d957d6caf  pop r11
00007d3d957d6cb1  pop r10
00007d3d957d6cb3  pop r9
00007d3d957d6cb5  pop r8
00007d3d957d6cb7  pop rsi
00007d3d957d6cb8  pop rdi
00007d3d957d6cb9  pop rdx
00007d3d957d6cba  pop rcx
00007d3d957d6cbb  pop rax
00007d3d957d6cbc  add rsp, 0x08
00007d3d957d6cc0  jmp 0x00007D3D957D5A06
00007d3d957d6cc5  sub rsp, 0x08
00007d3d957d6cc9  push rax
00007d3d957d6cca  push rcx
00007d3d957d6ccb  push rdx
00007d3d957d6ccc  push rdi
00007d3d957d6ccd  push rsi
00007d3d957d6cce  push r8
00007d3d957d6cd0  push r9
00007d3d957d6cd2  push r10
00007d3d957d6cd4  push r11
00007d3d957d6cd6  sub rsp, 0xF0
00007d3d957d6cdd  vmovaps [rsp], xmm0
00007d3d957d6ce2  vmovaps [rsp+0x10], xmm1
00007d3d957d6ce8  vmovaps [rsp+0x20], xmm2
00007d3d957d6cee  vmovaps [rsp+0x30], xmm3
00007d3d957d6cf4  vmovaps [rsp+0x40], xmm4
00007d3d957d6cfa  vmovaps [rsp+0x50], xmm5
00007d3d957d6d00  vmovaps [rsp+0x60], xmm7
00007d3d957d6d06  vmovaps [rsp+0x70], xmm8
00007d3d957d6d0c  vmovaps [rsp+0x80], xmm9
00007d3d957d6d15  vmovaps [rsp+0x90], xmm10
00007d3d957d6d1e  vmovaps [rsp+0xA0], xmm11
00007d3d957d6d27  vmovaps [rsp+0xB0], xmm12
00007d3d957d6d30  vmovaps [rsp+0xC0], xmm13
00007d3d957d6d39  vmovaps [rsp+0xD0], xmm14
00007d3d957d6d42  vmovaps [rsp+0xE0], xmm15
00007d3d957d6d4b  sub rsp, 0x30
00007d3d957d6d4f  movaps [rsp], xmm6
00007d3d957d6d53  movaps [rsp+0x10], xmm12
00007d3d957d6d59  movaps [rsp+0x20], xmm11
00007d3d957d6d5f  lea rdi, [rsp]
00007d3d957d6d63  mov esi, 0x00
00007d3d957d6d68  mov rax, 0x56C27CB8A530
00007d3d957d6d72  call rax
00007d3d957d6d74  movaps xmm6, [rsp]
00007d3d957d6d78  add rsp, 0x30
00007d3d957d6d7c  vmovaps xmm0, [rsp]
00007d3d957d6d81  vmovaps xmm1, [rsp+0x10]
00007d3d957d6d87  vmovaps xmm2, [rsp+0x20]
00007d3d957d6d8d  vmovaps xmm3, [rsp+0x30]
00007d3d957d6d93  vmovaps xmm4, [rsp+0x40]
00007d3d957d6d99  vmovaps xmm5, [rsp+0x50]
00007d3d957d6d9f  vmovaps xmm7, [rsp+0x60]
00007d3d957d6da5  vmovaps xmm8, [rsp+0x70]
00007d3d957d6dab  vmovaps xmm9, [rsp+0x80]
00007d3d957d6db4  vmovaps xmm10, [rsp+0x90]
00007d3d957d6dbd  vmovaps xmm11, [rsp+0xA0]
00007d3d957d6dc6  vmovaps xmm12, [rsp+0xB0]
00007d3d957d6dcf  vmovaps xmm13, [rsp+0xC0]
00007d3d957d6dd8  vmovaps xmm14, [rsp+0xD0]
00007d3d957d6de1  vmovaps xmm15, [rsp+0xE0]
00007d3d957d6dea  add rsp, 0xF0
00007d3d957d6df1  pop r11
00007d3d957d6df3  pop r10
00007d3d957d6df5  pop r9
00007d3d957d6df7  pop r8
00007d3d957d6df9  pop rsi
00007d3d957d6dfa  pop rdi
00007d3d957d6dfb  pop rdx
00007d3d957d6dfc  pop rcx
00007d3d957d6dfd  pop rax
00007d3d957d6dfe  add rsp, 0x08
00007d3d957d6e02  jmp 0x00007D3D957D5A27
00007d3d957d6e07  sub rsp, 0x08
00007d3d957d6e0b  push rax
00007d3d957d6e0c  push rcx
00007d3d957d6e0d  push rdx
00007d3d957d6e0e  push rdi
00007d3d957d6e0f  push rsi
00007d3d957d6e10  push r8
00007d3d957d6e12  push r9
00007d3d957d6e14  push r10
00007d3d957d6e16  push r11
00007d3d957d6e18  sub rsp, 0xF0
00007d3d957d6e1f  vmovaps [rsp], xmm0
00007d3d957d6e24  vmovaps [rsp+0x10], xmm1
00007d3d957d6e2a  vmovaps [rsp+0x20], xmm2
00007d3d957d6e30  vmovaps [rsp+0x30], xmm4
00007d3d957d6e36  vmovaps [rsp+0x40], xmm5
00007d3d957d6e3c  vmovaps [rsp+0x50], xmm6
00007d3d957d6e42  vmovaps [rsp+0x60], xmm7
00007d3d957d6e48  vmovaps [rsp+0x70], xmm8
00007d3d957d6e4e  vmovaps [rsp+0x80], xmm9
00007d3d957d6e57  vmovaps [rsp+0x90], xmm10
00007d3d957d6e60  vmovaps [rsp+0xA0], xmm11
00007d3d957d6e69  vmovaps [rsp+0xB0], xmm12
00007d3d957d6e72  vmovaps [rsp+0xC0], xmm13
00007d3d957d6e7b  vmovaps [rsp+0xD0], xmm14
00007d3d957d6e84  vmovaps [rsp+0xE0], xmm15
00007d3d957d6e8d  sub rsp, 0x30
00007d3d957d6e91  movaps [rsp], xmm3
00007d3d957d6e95  movaps [rsp+0x10], xmm5
00007d3d957d6e9a  movaps [rsp+0x20], xmm4
00007d3d957d6e9f  lea rdi, [rsp]
00007d3d957d6ea3  mov esi, 0x00
00007d3d957d6ea8  mov rax, 0x56C27CB8A530
00007d3d957d6eb2  call rax
00007d3d957d6eb4  movaps xmm3, [rsp]
00007d3d957d6eb8  add rsp, 0x30
00007d3d957d6ebc  vmovaps xmm0, [rsp]
00007d3d957d6ec1  vmovaps xmm1, [rsp+0x10]
00007d3d957d6ec7  vmovaps xmm2, [rsp+0x20]
00007d3d957d6ecd  vmovaps xmm4, [rsp+0x30]
00007d3d957d6ed3  vmovaps xmm5, [rsp+0x40]
00007d3d957d6ed9  vmovaps xmm6, [rsp+0x50]
00007d3d957d6edf  vmovaps xmm7, [rsp+0x60]
00007d3d957d6ee5  vmovaps xmm8, [rsp+0x70]
00007d3d957d6eeb  vmovaps xmm9, [rsp+0x80]
00007d3d957d6ef4  vmovaps xmm10, [rsp+0x90]
00007d3d957d6efd  vmovaps xmm11, [rsp+0xA0]
00007d3d957d6f06  vmovaps xmm12, [rsp+0xB0]
00007d3d957d6f0f  vmovaps xmm13, [rsp+0xC0]
00007d3d957d6f18  vmovaps xmm14, [rsp+0xD0]
00007d3d957d6f21  vmovaps xmm15, [rsp+0xE0]
00007d3d957d6f2a  add rsp, 0xF0
00007d3d957d6f31  pop r11
00007d3d957d6f33  pop r10
00007d3d957d6f35  pop r9
00007d3d957d6f37  pop r8
00007d3d957d6f39  pop rsi
00007d3d957d6f3a  pop rdi
00007d3d957d6f3b  pop rdx
00007d3d957d6f3c  pop rcx
00007d3d957d6f3d  pop rax
00007d3d957d6f3e  add rsp, 0x08
00007d3d957d6f42  jmp 0x00007D3D957D5A88
00007d3d957d6f47  sub rsp, 0x08
00007d3d957d6f4b  push rax
00007d3d957d6f4c  push rcx
00007d3d957d6f4d  push rdx
00007d3d957d6f4e  push rdi
00007d3d957d6f4f  push rsi
00007d3d957d6f50  push r8
00007d3d957d6f52  push r9
00007d3d957d6f54  push r10
00007d3d957d6f56  push r11
00007d3d957d6f58  sub rsp, 0xF0
00007d3d957d6f5f  vmovaps [rsp], xmm0
00007d3d957d6f64  vmovaps [rsp+0x10], xmm1
00007d3d957d6f6a  vmovaps [rsp+0x20], xmm2
00007d3d957d6f70  vmovaps [rsp+0x30], xmm3
00007d3d957d6f76  vmovaps [rsp+0x40], xmm4
00007d3d957d6f7c  vmovaps [rsp+0x50], xmm6
00007d3d957d6f82  vmovaps [rsp+0x60], xmm7
00007d3d957d6f88  vmovaps [rsp+0x70], xmm8
00007d3d957d6f8e  vmovaps [rsp+0x80], xmm9
00007d3d957d6f97  vmovaps [rsp+0x90], xmm10
00007d3d957d6fa0  vmovaps [rsp+0xA0], xmm11
00007d3d957d6fa9  vmovaps [rsp+0xB0], xmm12
00007d3d957d6fb2  vmovaps [rsp+0xC0], xmm13
00007d3d957d6fbb  vmovaps [rsp+0xD0], xmm14
00007d3d957d6fc4  vmovaps [rsp+0xE0], xmm15
00007d3d957d6fcd  sub rsp, 0x30
00007d3d957d6fd1  movaps [rsp], xmm5
00007d3d957d6fd5  movaps [rsp+0x10], xmm8
00007d3d957d6fdb  movaps [rsp+0x20], xmm15
00007d3d957d6fe1  lea rdi, [rsp]
00007d3d957d6fe5  mov esi, 0x00
00007d3d957d6fea  mov rax, 0x56C27CB8A530
00007d3d957d6ff4  call rax
00007d3d957d6ff6  movaps xmm5, [rsp]
00007d3d957d6ffa  add rsp, 0x30
00007d3d957d6ffe  vmovaps xmm0, [rsp]
00007d3d957d7003  vmovaps xmm1, [rsp+0x10]
00007d3d957d7009  vmovaps xmm2, [rsp+0x20]
00007d3d957d700f  vmovaps xmm3, [rsp+0x30]
00007d3d957d7015  vmovaps xmm4, [rsp+0x40]
00007d3d957d701b  vmovaps xmm6, [rsp+0x50]
00007d3d957d7021  vmovaps xmm7, [rsp+0x60]
00007d3d957d7027  vmovaps xmm8, [rsp+0x70]
00007d3d957d702d  vmovaps xmm9, [rsp+0x80]
00007d3d957d7036  vmovaps xmm10, [rsp+0x90]
00007d3d957d703f  vmovaps xmm11, [rsp+0xA0]
00007d3d957d7048  vmovaps xmm12, [rsp+0xB0]
00007d3d957d7051  vmovaps xmm13, [rsp+0xC0]
00007d3d957d705a  vmovaps xmm14, [rsp+0xD0]
00007d3d957d7063  vmovaps xmm15, [rsp+0xE0]
00007d3d957d706c  add rsp, 0xF0
00007d3d957d7073  pop r11
00007d3d957d7075  pop r10
00007d3d957d7077  pop r9
00007d3d957d7079  pop r8
00007d3d957d707b  pop rsi
00007d3d957d707c  pop rdi
00007d3d957d707d  pop rdx
00007d3d957d707e  pop rcx
00007d3d957d707f  pop rax
00007d3d957d7080  add rsp, 0x08
00007d3d957d7084  jmp 0x00007D3D957D5AC0
00007d3d957d7089  sub rsp, 0x08
00007d3d957d708d  push rax
00007d3d957d708e  push rcx
00007d3d957d708f  push rdx
00007d3d957d7090  push rdi
00007d3d957d7091  push rsi
00007d3d957d7092  push r8
00007d3d957d7094  push r9
00007d3d957d7096  push r10
00007d3d957d7098  push r11
00007d3d957d709a  sub rsp, 0xF0
00007d3d957d70a1  vmovaps [rsp], xmm0
00007d3d957d70a6  vmovaps [rsp+0x10], xmm1
00007d3d957d70ac  vmovaps [rsp+0x20], xmm2
00007d3d957d70b2  vmovaps [rsp+0x30], xmm3
00007d3d957d70b8  vmovaps [rsp+0x40], xmm5
00007d3d957d70be  vmovaps [rsp+0x50], xmm6
00007d3d957d70c4  vmovaps [rsp+0x60], xmm7
00007d3d957d70ca  vmovaps [rsp+0x70], xmm8
00007d3d957d70d0  vmovaps [rsp+0x80], xmm9
00007d3d957d70d9  vmovaps [rsp+0x90], xmm10
00007d3d957d70e2  vmovaps [rsp+0xA0], xmm11
00007d3d957d70eb  vmovaps [rsp+0xB0], xmm12
00007d3d957d70f4  vmovaps [rsp+0xC0], xmm13
00007d3d957d70fd  vmovaps [rsp+0xD0], xmm14
00007d3d957d7106  vmovaps [rsp+0xE0], xmm15
00007d3d957d710f  sub rsp, 0x30
00007d3d957d7113  movaps [rsp], xmm4
00007d3d957d7117  movaps [rsp+0x10], xmm9
00007d3d957d711d  movaps [rsp+0x20], xmm8
00007d3d957d7123  lea rdi, [rsp]
00007d3d957d7127  mov esi, 0x00
00007d3d957d712c  mov rax, 0x56C27CB8A530
00007d3d957d7136  call rax
00007d3d957d7138  movaps xmm4, [rsp]
00007d3d957d713c  add rsp, 0x30
00007d3d957d7140  vmovaps xmm0, [rsp]
00007d3d957d7145  vmovaps xmm1, [rsp+0x10]
00007d3d957d714b  vmovaps xmm2, [rsp+0x20]
00007d3d957d7151  vmovaps xmm3, [rsp+0x30]
00007d3d957d7157  vmovaps xmm5, [rsp+0x40]
00007d3d957d715d  vmovaps xmm6, [rsp+0x50]
00007d3d957d7163  vmovaps xmm7, [rsp+0x60]
00007d3d957d7169  vmovaps xmm8, [rsp+0x70]
00007d3d957d716f  vmovaps xmm9, [rsp+0x80]
00007d3d957d7178  vmovaps xmm10, [rsp+0x90]
00007d3d957d7181  vmovaps xmm11, [rsp+0xA0]
00007d3d957d718a  vmovaps xmm12, [rsp+0xB0]
00007d3d957d7193  vmovaps xmm13, [rsp+0xC0]
00007d3d957d719c  vmovaps xmm14, [rsp+0xD0]
00007d3d957d71a5  vmovaps xmm15, [rsp+0xE0]
00007d3d957d71ae  add rsp, 0xF0
00007d3d957d71b5  pop r11
00007d3d957d71b7  pop r10
00007d3d957d71b9  pop r9
00007d3d957d71bb  pop r8
00007d3d957d71bd  pop rsi
00007d3d957d71be  pop rdi
00007d3d957d71bf  pop rdx
00007d3d957d71c0  pop rcx
00007d3d957d71c1  pop rax
00007d3d957d71c2  add rsp, 0x08
00007d3d957d71c6  jmp 0x00007D3D957D5AE1
00007d3d957d71cb  sub rsp, 0x08
00007d3d957d71cf  push rax
00007d3d957d71d0  push rcx
00007d3d957d71d1  push rdx
00007d3d957d71d2  push rdi
00007d3d957d71d3  push rsi
00007d3d957d71d4  push r8
00007d3d957d71d6  push r9
00007d3d957d71d8  push r10
00007d3d957d71da  push r11
00007d3d957d71dc  sub rsp, 0xF0
00007d3d957d71e3  vmovaps [rsp], xmm0
00007d3d957d71e8  vmovaps [rsp+0x10], xmm1
00007d3d957d71ee  vmovaps [rsp+0x20], xmm2
00007d3d957d71f4  vmovaps [rsp+0x30], xmm3
00007d3d957d71fa  vmovaps [rsp+0x40], xmm4
00007d3d957d7200  vmovaps [rsp+0x50], xmm5
00007d3d957d7206  vmovaps [rsp+0x60], xmm6
00007d3d957d720c  vmovaps [rsp+0x70], xmm7
00007d3d957d7212  vmovaps [rsp+0x80], xmm8
00007d3d957d721b  vmovaps [rsp+0x90], xmm10
00007d3d957d7224  vmovaps [rsp+0xA0], xmm11
00007d3d957d722d  vmovaps [rsp+0xB0], xmm12
00007d3d957d7236  vmovaps [rsp+0xC0], xmm13
00007d3d957d723f  vmovaps [rsp+0xD0], xmm14
00007d3d957d7248  vmovaps [rsp+0xE0], xmm15
00007d3d957d7251  sub rsp, 0x30
00007d3d957d7255  movaps [rsp], xmm9
00007d3d957d725a  movaps [rsp+0x10], xmm10
00007d3d957d7260  movaps [rsp+0x20], xmm8
00007d3d957d7266  lea rdi, [rsp]
00007d3d957d726a  mov esi, 0x00
00007d3d957d726f  mov rax, 0x56C27CB8A530
00007d3d957d7279  call rax
00007d3d957d727b  movaps xmm9, [rsp]
00007d3d957d7280  add rsp, 0x30
00007d3d957d7284  vmovaps xmm0, [rsp]
00007d3d957d7289  vmovaps xmm1, [rsp+0x10]
00007d3d957d728f  vmovaps xmm2, [rsp+0x20]
00007d3d957d7295  vmovaps xmm3, [rsp+0x30]
00007d3d957d729b  vmovaps xmm4, [rsp+0x40]
00007d3d957d72a1  vmovaps xmm5, [rsp+0x50]
00007d3d957d72a7  vmovaps xmm6, [rsp+0x60]
00007d3d957d72ad  vmovaps xmm7, [rsp+0x70]
00007d3d957d72b3  vmovaps xmm8, [rsp+0x80]
00007d3d957d72bc  vmovaps xmm10, [rsp+0x90]
00007d3d957d72c5  vmovaps xmm11, [rsp+0xA0]
00007d3d957d72ce  vmovaps xmm12, [rsp+0xB0]
00007d3d957d72d7  vmovaps xmm13, [rsp+0xC0]
00007d3d957d72e0  vmovaps xmm14, [rsp+0xD0]
00007d3d957d72e9  vmovaps xmm15, [rsp+0xE0]
00007d3d957d72f2  add rsp, 0xF0
00007d3d957d72f9  pop r11
00007d3d957d72fb  pop r10
00007d3d957d72fd  pop r9
00007d3d957d72ff  pop r8
00007d3d957d7301  pop rsi
00007d3d957d7302  pop rdi
00007d3d957d7303  pop rdx
00007d3d957d7304  pop rcx
00007d3d957d7305  pop rax
00007d3d957d7306  add rsp, 0x08
00007d3d957d730a  jmp 0x00007D3D957D5AFB
00007d3d957d730f  call 0x00007D3D956D64F0
00007d3d957d7314  jmp 0x00007D3D957D5C15
00007d3d957d7319  call 0x00007D3D956D64F0
00007d3d957d731e  jmp 0x00007D3D957D5C2B
00007d3d957d7323  sub rsp, 0x08
00007d3d957d7327  push rax
00007d3d957d7328  push rcx
00007d3d957d7329  push rdx
00007d3d957d732a  push rdi
00007d3d957d732b  push rsi
00007d3d957d732c  push r8
00007d3d957d732e  push r9
00007d3d957d7330  push r10
00007d3d957d7332  push r11
00007d3d957d7334  sub rsp, 0xF0
00007d3d957d733b  vmovaps [rsp], xmm0
00007d3d957d7340  vmovaps [rsp+0x10], xmm2
00007d3d957d7346  vmovaps [rsp+0x20], xmm3
00007d3d957d734c  vmovaps [rsp+0x30], xmm4
00007d3d957d7352  vmovaps [rsp+0x40], xmm5
00007d3d957d7358  vmovaps [rsp+0x50], xmm6
00007d3d957d735e  vmovaps [rsp+0x60], xmm7
00007d3d957d7364  vmovaps [rsp+0x70], xmm8
00007d3d957d736a  vmovaps [rsp+0x80], xmm9
00007d3d957d7373  vmovaps [rsp+0x90], xmm10
00007d3d957d737c  vmovaps [rsp+0xA0], xmm11
00007d3d957d7385  vmovaps [rsp+0xB0], xmm12
00007d3d957d738e  vmovaps [rsp+0xC0], xmm13
00007d3d957d7397  vmovaps [rsp+0xD0], xmm14
00007d3d957d73a0  vmovaps [rsp+0xE0], xmm15
00007d3d957d73a9  sub rsp, 0x30
00007d3d957d73ad  movaps [rsp], xmm1
00007d3d957d73b1  movaps [rsp+0x10], xmm6
00007d3d957d73b6  movaps [rsp+0x20], xmm15
00007d3d957d73bc  lea rdi, [rsp]
00007d3d957d73c0  mov esi, 0x00
00007d3d957d73c5  mov rax, 0x56C27CB8A530
00007d3d957d73cf  call rax
00007d3d957d73d1  movaps xmm1, [rsp]
00007d3d957d73d5  add rsp, 0x30
00007d3d957d73d9  vmovaps xmm0, [rsp]
00007d3d957d73de  vmovaps xmm2, [rsp+0x10]
00007d3d957d73e4  vmovaps xmm3, [rsp+0x20]
00007d3d957d73ea  vmovaps xmm4, [rsp+0x30]
00007d3d957d73f0  vmovaps xmm5, [rsp+0x40]
00007d3d957d73f6  vmovaps xmm6, [rsp+0x50]
00007d3d957d73fc  vmovaps xmm7, [rsp+0x60]
00007d3d957d7402  vmovaps xmm8, [rsp+0x70]
00007d3d957d7408  vmovaps xmm9, [rsp+0x80]
00007d3d957d7411  vmovaps xmm10, [rsp+0x90]
00007d3d957d741a  vmovaps xmm11, [rsp+0xA0]
00007d3d957d7423  vmovaps xmm12, [rsp+0xB0]
00007d3d957d742c  vmovaps xmm13, [rsp+0xC0]
00007d3d957d7435  vmovaps xmm14, [rsp+0xD0]
00007d3d957d743e  vmovaps xmm15, [rsp+0xE0]
00007d3d957d7447  add rsp, 0xF0
00007d3d957d744e  pop r11
00007d3d957d7450  pop r10
00007d3d957d7452  pop r9
00007d3d957d7454  pop r8
00007d3d957d7456  pop rsi
00007d3d957d7457  pop rdi
00007d3d957d7458  pop rdx
00007d3d957d7459  pop rcx
00007d3d957d745a  pop rax
00007d3d957d745b  add rsp, 0x08
00007d3d957d745f  jmp 0x00007D3D957D5C68
00007d3d957d7464  call 0x00007D3D956E5820
00007d3d957d7469  jmp 0x00007D3D957D5C75
00007d3d957d746e  sub rsp, 0x08
00007d3d957d7472  push rax
00007d3d957d7473  push rcx
00007d3d957d7474  push rdx
00007d3d957d7475  push rdi
00007d3d957d7476  push rsi
00007d3d957d7477  push r8
00007d3d957d7479  push r9
00007d3d957d747b  push r10
00007d3d957d747d  push r11
00007d3d957d747f  sub rsp, 0xF0
00007d3d957d7486  vmovaps [rsp], xmm0
00007d3d957d748b  vmovaps [rsp+0x10], xmm1
00007d3d957d7491  vmovaps [rsp+0x20], xmm2
00007d3d957d7497  vmovaps [rsp+0x30], xmm3
00007d3d957d749d  vmovaps [rsp+0x40], xmm4
00007d3d957d74a3  vmovaps [rsp+0x50], xmm5
00007d3d957d74a9  vmovaps [rsp+0x60], xmm6
00007d3d957d74af  vmovaps [rsp+0x70], xmm7
00007d3d957d74b5  vmovaps [rsp+0x80], xmm8
00007d3d957d74be  vmovaps [rsp+0x90], xmm9
00007d3d957d74c7  vmovaps [rsp+0xA0], xmm10
00007d3d957d74d0  vmovaps [rsp+0xB0], xmm11
00007d3d957d74d9  vmovaps [rsp+0xC0], xmm12
00007d3d957d74e2  vmovaps [rsp+0xD0], xmm13
00007d3d957d74eb  vmovaps [rsp+0xE0], xmm15
00007d3d957d74f4  sub rsp, 0x30
00007d3d957d74f8  movaps [rsp], xmm14
00007d3d957d74fd  movaps [rsp+0x10], xmm4
00007d3d957d7502  movaps [rsp+0x20], xmm3
00007d3d957d7507  lea rdi, [rsp]
00007d3d957d750b  mov esi, 0x00
00007d3d957d7510  mov rax, 0x56C27CB8A530
00007d3d957d751a  call rax
00007d3d957d751c  movaps xmm14, [rsp]
00007d3d957d7521  add rsp, 0x30
00007d3d957d7525  vmovaps xmm0, [rsp]
00007d3d957d752a  vmovaps xmm1, [rsp+0x10]
00007d3d957d7530  vmovaps xmm2, [rsp+0x20]
00007d3d957d7536  vmovaps xmm3, [rsp+0x30]
00007d3d957d753c  vmovaps xmm4, [rsp+0x40]
00007d3d957d7542  vmovaps xmm5, [rsp+0x50]
00007d3d957d7548  vmovaps xmm6, [rsp+0x60]
00007d3d957d754e  vmovaps xmm7, [rsp+0x70]
00007d3d957d7554  vmovaps xmm8, [rsp+0x80]
00007d3d957d755d  vmovaps xmm9, [rsp+0x90]
00007d3d957d7566  vmovaps xmm10, [rsp+0xA0]
00007d3d957d756f  vmovaps xmm11, [rsp+0xB0]
00007d3d957d7578  vmovaps xmm12, [rsp+0xC0]
00007d3d957d7581  vmovaps xmm13, [rsp+0xD0]
00007d3d957d758a  vmovaps xmm15, [rsp+0xE0]
00007d3d957d7593  add rsp, 0xF0
00007d3d957d759a  pop r11
00007d3d957d759c  pop r10
00007d3d957d759e  pop r9
00007d3d957d75a0  pop r8
00007d3d957d75a2  pop rsi
00007d3d957d75a3  pop rdi
00007d3d957d75a4  pop rdx
00007d3d957d75a5  pop rcx
00007d3d957d75a6  pop rax
00007d3d957d75a7  add rsp, 0x08
00007d3d957d75ab  jmp 0x00007D3D957D5C8F
00007d3d957d75b0  sub rsp, 0x08
00007d3d957d75b4  push rax
00007d3d957d75b5  push rcx
00007d3d957d75b6  push rdx
00007d3d957d75b7  push rdi
00007d3d957d75b8  push rsi
00007d3d957d75b9  push r8
00007d3d957d75bb  push r9
00007d3d957d75bd  push r10
00007d3d957d75bf  push r11
00007d3d957d75c1  sub rsp, 0xF0
00007d3d957d75c8  vmovaps [rsp], xmm0
00007d3d957d75cd  vmovaps [rsp+0x10], xmm1
00007d3d957d75d3  vmovaps [rsp+0x20], xmm2
00007d3d957d75d9  vmovaps [rsp+0x30], xmm3
00007d3d957d75df  vmovaps [rsp+0x40], xmm4
00007d3d957d75e5  vmovaps [rsp+0x50], xmm5
00007d3d957d75eb  vmovaps [rsp+0x60], xmm7
00007d3d957d75f1  vmovaps [rsp+0x70], xmm8
00007d3d957d75f7  vmovaps [rsp+0x80], xmm9
00007d3d957d7600  vmovaps [rsp+0x90], xmm10
00007d3d957d7609  vmovaps [rsp+0xA0], xmm11
00007d3d957d7612  vmovaps [rsp+0xB0], xmm12
00007d3d957d761b  vmovaps [rsp+0xC0], xmm13
00007d3d957d7624  vmovaps [rsp+0xD0], xmm14
00007d3d957d762d  vmovaps [rsp+0xE0], xmm15
00007d3d957d7636  sub rsp, 0x30
00007d3d957d763a  movaps [rsp], xmm6
00007d3d957d763e  movaps [rsp+0x10], xmm9
00007d3d957d7644  movaps [rsp+0x20], xmm7
00007d3d957d7649  lea rdi, [rsp]
00007d3d957d764d  mov esi, 0x00
00007d3d957d7652  mov rax, 0x56C27CB8A530
00007d3d957d765c  call rax
00007d3d957d765e  movaps xmm6, [rsp]
00007d3d957d7662  add rsp, 0x30
00007d3d957d7666  vmovaps xmm0, [rsp]
00007d3d957d766b  vmovaps xmm1, [rsp+0x10]
00007d3d957d7671  vmovaps xmm2, [rsp+0x20]
00007d3d957d7677  vmovaps xmm3, [rsp+0x30]
00007d3d957d767d  vmovaps xmm4, [rsp+0x40]
00007d3d957d7683  vmovaps xmm5, [rsp+0x50]
00007d3d957d7689  vmovaps xmm7, [rsp+0x60]
00007d3d957d768f  vmovaps xmm8, [rsp+0x70]
00007d3d957d7695  vmovaps xmm9, [rsp+0x80]
00007d3d957d769e  vmovaps xmm10, [rsp+0x90]
00007d3d957d76a7  vmovaps xmm11, [rsp+0xA0]
00007d3d957d76b0  vmovaps xmm12, [rsp+0xB0]
00007d3d957d76b9  vmovaps xmm13, [rsp+0xC0]
00007d3d957d76c2  vmovaps xmm14, [rsp+0xD0]
00007d3d957d76cb  vmovaps xmm15, [rsp+0xE0]
00007d3d957d76d4  add rsp, 0xF0
00007d3d957d76db  pop r11
00007d3d957d76dd  pop r10
00007d3d957d76df  pop r9
00007d3d957d76e1  pop r8
00007d3d957d76e3  pop rsi
00007d3d957d76e4  pop rdi
00007d3d957d76e5  pop rdx
00007d3d957d76e6  pop rcx
00007d3d957d76e7  pop rax
00007d3d957d76e8  add rsp, 0x08
00007d3d957d76ec  jmp 0x00007D3D957D5CA7
00007d3d957d76f1  sub rsp, 0x08
00007d3d957d76f5  push rax
00007d3d957d76f6  push rcx
00007d3d957d76f7  push rdx
00007d3d957d76f8  push rdi
00007d3d957d76f9  push rsi
00007d3d957d76fa  push r8
00007d3d957d76fc  push r9
00007d3d957d76fe  push r10
00007d3d957d7700  push r11
00007d3d957d7702  sub rsp, 0xF0
00007d3d957d7709  vmovaps [rsp], xmm0
00007d3d957d770e  vmovaps [rsp+0x10], xmm1
00007d3d957d7714  vmovaps [rsp+0x20], xmm2
00007d3d957d771a  vmovaps [rsp+0x30], xmm3
00007d3d957d7720  vmovaps [rsp+0x40], xmm4
00007d3d957d7726  vmovaps [rsp+0x50], xmm5
00007d3d957d772c  vmovaps [rsp+0x60], xmm6
00007d3d957d7732  vmovaps [rsp+0x70], xmm8
00007d3d957d7738  vmovaps [rsp+0x80], xmm9
00007d3d957d7741  vmovaps [rsp+0x90], xmm10
00007d3d957d774a  vmovaps [rsp+0xA0], xmm11
00007d3d957d7753  vmovaps [rsp+0xB0], xmm12
00007d3d957d775c  vmovaps [rsp+0xC0], xmm13
00007d3d957d7765  vmovaps [rsp+0xD0], xmm14
00007d3d957d776e  vmovaps [rsp+0xE0], xmm15
00007d3d957d7777  sub rsp, 0x30
00007d3d957d777b  movaps [rsp], xmm7
00007d3d957d777f  movaps [rsp+0x10], xmm4
00007d3d957d7784  movaps [rsp+0x20], xmm9
00007d3d957d778a  lea rdi, [rsp]
00007d3d957d778e  mov esi, 0x00
00007d3d957d7793  mov rax, 0x56C27CB8A530
00007d3d957d779d  call rax
00007d3d957d779f  movaps xmm7, [rsp]
00007d3d957d77a3  add rsp, 0x30
00007d3d957d77a7  vmovaps xmm0, [rsp]
00007d3d957d77ac  vmovaps xmm1, [rsp+0x10]
00007d3d957d77b2  vmovaps xmm2, [rsp+0x20]
00007d3d957d77b8  vmovaps xmm3, [rsp+0x30]
00007d3d957d77be  vmovaps xmm4, [rsp+0x40]
00007d3d957d77c4  vmovaps xmm5, [rsp+0x50]
00007d3d957d77ca  vmovaps xmm6, [rsp+0x60]
00007d3d957d77d0  vmovaps xmm8, [rsp+0x70]
00007d3d957d77d6  vmovaps xmm9, [rsp+0x80]
00007d3d957d77df  vmovaps xmm10, [rsp+0x90]
00007d3d957d77e8  vmovaps xmm11, [rsp+0xA0]
00007d3d957d77f1  vmovaps xmm12, [rsp+0xB0]
00007d3d957d77fa  vmovaps xmm13, [rsp+0xC0]
00007d3d957d7803  vmovaps xmm14, [rsp+0xD0]
00007d3d957d780c  vmovaps xmm15, [rsp+0xE0]
00007d3d957d7815  add rsp, 0xF0
00007d3d957d781c  pop r11
00007d3d957d781e  pop r10
00007d3d957d7820  pop r9
00007d3d957d7822  pop r8
00007d3d957d7824  pop rsi
00007d3d957d7825  pop rdi
00007d3d957d7826  pop rdx
00007d3d957d7827  pop rcx
00007d3d957d7828  pop rax
00007d3d957d7829  add rsp, 0x08
00007d3d957d782d  jmp 0x00007D3D957D5CD4
00007d3d957d7832  sub rsp, 0x08
00007d3d957d7836  push rax
00007d3d957d7837  push rcx
00007d3d957d7838  push rdx
00007d3d957d7839  push rdi
00007d3d957d783a  push rsi
00007d3d957d783b  push r8
00007d3d957d783d  push r9
00007d3d957d783f  push r10
00007d3d957d7841  push r11
00007d3d957d7843  sub rsp, 0xF0
00007d3d957d784a  vmovaps [rsp], xmm0
00007d3d957d784f  vmovaps [rsp+0x10], xmm1
00007d3d957d7855  vmovaps [rsp+0x20], xmm2
00007d3d957d785b  vmovaps [rsp+0x30], xmm3
00007d3d957d7861  vmovaps [rsp+0x40], xmm5
00007d3d957d7867  vmovaps [rsp+0x50], xmm6
00007d3d957d786d  vmovaps [rsp+0x60], xmm7
00007d3d957d7873  vmovaps [rsp+0x70], xmm8
00007d3d957d7879  vmovaps [rsp+0x80], xmm9
00007d3d957d7882  vmovaps [rsp+0x90], xmm10
00007d3d957d788b  vmovaps [rsp+0xA0], xmm11
00007d3d957d7894  vmovaps [rsp+0xB0], xmm12
00007d3d957d789d  vmovaps [rsp+0xC0], xmm13
00007d3d957d78a6  vmovaps [rsp+0xD0], xmm14
00007d3d957d78af  vmovaps [rsp+0xE0], xmm15
00007d3d957d78b8  sub rsp, 0x30
00007d3d957d78bc  movaps [rsp], xmm4
00007d3d957d78c0  movaps [rsp+0x10], xmm15
00007d3d957d78c6  movaps [rsp+0x20], xmm9
00007d3d957d78cc  lea rdi, [rsp]
00007d3d957d78d0  mov esi, 0x00
00007d3d957d78d5  mov rax, 0x56C27CB8A530
00007d3d957d78df  call rax
00007d3d957d78e1  movaps xmm4, [rsp]
00007d3d957d78e5  add rsp, 0x30
00007d3d957d78e9  vmovaps xmm0, [rsp]
00007d3d957d78ee  vmovaps xmm1, [rsp+0x10]
00007d3d957d78f4  vmovaps xmm2, [rsp+0x20]
00007d3d957d78fa  vmovaps xmm3, [rsp+0x30]
00007d3d957d7900  vmovaps xmm5, [rsp+0x40]
00007d3d957d7906  vmovaps xmm6, [rsp+0x50]
00007d3d957d790c  vmovaps xmm7, [rsp+0x60]
00007d3d957d7912  vmovaps xmm8, [rsp+0x70]
00007d3d957d7918  vmovaps xmm9, [rsp+0x80]
00007d3d957d7921  vmovaps xmm10, [rsp+0x90]
00007d3d957d792a  vmovaps xmm11, [rsp+0xA0]
00007d3d957d7933  vmovaps xmm12, [rsp+0xB0]
00007d3d957d793c  vmovaps xmm13, [rsp+0xC0]
00007d3d957d7945  vmovaps xmm14, [rsp+0xD0]
00007d3d957d794e  vmovaps xmm15, [rsp+0xE0]
00007d3d957d7957  add rsp, 0xF0
00007d3d957d795e  pop r11
00007d3d957d7960  pop r10
00007d3d957d7962  pop r9
00007d3d957d7964  pop r8
00007d3d957d7966  pop rsi
00007d3d957d7967  pop rdi
00007d3d957d7968  pop rdx
00007d3d957d7969  pop rcx
00007d3d957d796a  pop rax
00007d3d957d796b  add rsp, 0x08
00007d3d957d796f  jmp 0x00007D3D957D5CF9
00007d3d957d7974  call 0x00007D3D956E5820
00007d3d957d7979  jmp 0x00007D3D957D5D06
00007d3d957d797e  sub rsp, 0x08
00007d3d957d7982  push rax
00007d3d957d7983  push rcx
00007d3d957d7984  push rdx
00007d3d957d7985  push rdi
00007d3d957d7986  push rsi
00007d3d957d7987  push r8
00007d3d957d7989  push r9
00007d3d957d798b  push r10
00007d3d957d798d  push r11
00007d3d957d798f  sub rsp, 0xF0
00007d3d957d7996  vmovaps [rsp], xmm0
00007d3d957d799b  vmovaps [rsp+0x10], xmm1
00007d3d957d79a1  vmovaps [rsp+0x20], xmm2
00007d3d957d79a7  vmovaps [rsp+0x30], xmm4
00007d3d957d79ad  vmovaps [rsp+0x40], xmm5
00007d3d957d79b3  vmovaps [rsp+0x50], xmm6
00007d3d957d79b9  vmovaps [rsp+0x60], xmm7
00007d3d957d79bf  vmovaps [rsp+0x70], xmm8
00007d3d957d79c5  vmovaps [rsp+0x80], xmm9
00007d3d957d79ce  vmovaps [rsp+0x90], xmm10
00007d3d957d79d7  vmovaps [rsp+0xA0], xmm11
00007d3d957d79e0  vmovaps [rsp+0xB0], xmm12
00007d3d957d79e9  vmovaps [rsp+0xC0], xmm13
00007d3d957d79f2  vmovaps [rsp+0xD0], xmm14
00007d3d957d79fb  vmovaps [rsp+0xE0], xmm15
00007d3d957d7a04  sub rsp, 0x30
00007d3d957d7a08  movaps [rsp], xmm3
00007d3d957d7a0c  movaps [rsp+0x10], xmm1
00007d3d957d7a11  movaps [rsp+0x20], xmm9
00007d3d957d7a17  lea rdi, [rsp]
00007d3d957d7a1b  mov esi, 0x00
00007d3d957d7a20  mov rax, 0x56C27CB8A530
00007d3d957d7a2a  call rax
00007d3d957d7a2c  movaps xmm3, [rsp]
00007d3d957d7a30  add rsp, 0x30
00007d3d957d7a34  vmovaps xmm0, [rsp]
00007d3d957d7a39  vmovaps xmm1, [rsp+0x10]
00007d3d957d7a3f  vmovaps xmm2, [rsp+0x20]
00007d3d957d7a45  vmovaps xmm4, [rsp+0x30]
00007d3d957d7a4b  vmovaps xmm5, [rsp+0x40]
00007d3d957d7a51  vmovaps xmm6, [rsp+0x50]
00007d3d957d7a57  vmovaps xmm7, [rsp+0x60]
00007d3d957d7a5d  vmovaps xmm8, [rsp+0x70]
00007d3d957d7a63  vmovaps xmm9, [rsp+0x80]
00007d3d957d7a6c  vmovaps xmm10, [rsp+0x90]
00007d3d957d7a75  vmovaps xmm11, [rsp+0xA0]
00007d3d957d7a7e  vmovaps xmm12, [rsp+0xB0]
00007d3d957d7a87  vmovaps xmm13, [rsp+0xC0]
00007d3d957d7a90  vmovaps xmm14, [rsp+0xD0]
00007d3d957d7a99  vmovaps xmm15, [rsp+0xE0]
00007d3d957d7aa2  add rsp, 0xF0
00007d3d957d7aa9  pop r11
00007d3d957d7aab  pop r10
00007d3d957d7aad  pop r9
00007d3d957d7aaf  pop r8
00007d3d957d7ab1  pop rsi
00007d3d957d7ab2  pop rdi
00007d3d957d7ab3  pop rdx
00007d3d957d7ab4  pop rcx
00007d3d957d7ab5  pop rax
00007d3d957d7ab6  add rsp, 0x08
00007d3d957d7aba  jmp 0x00007D3D957D5D43
00007d3d957d7abf  sub rsp, 0x08
00007d3d957d7ac3  push rax
00007d3d957d7ac4  push rcx
00007d3d957d7ac5  push rdx
00007d3d957d7ac6  push rdi
00007d3d957d7ac7  push rsi
00007d3d957d7ac8  push r8
00007d3d957d7aca  push r9
00007d3d957d7acc  push r10
00007d3d957d7ace  push r11
00007d3d957d7ad0  sub rsp, 0xF0
00007d3d957d7ad7  vmovaps [rsp], xmm0
00007d3d957d7adc  vmovaps [rsp+0x10], xmm2
00007d3d957d7ae2  vmovaps [rsp+0x20], xmm3
00007d3d957d7ae8  vmovaps [rsp+0x30], xmm4
00007d3d957d7aee  vmovaps [rsp+0x40], xmm5
00007d3d957d7af4  vmovaps [rsp+0x50], xmm6
00007d3d957d7afa  vmovaps [rsp+0x60], xmm7
00007d3d957d7b00  vmovaps [rsp+0x70], xmm8
00007d3d957d7b06  vmovaps [rsp+0x80], xmm9
00007d3d957d7b0f  vmovaps [rsp+0x90], xmm10
00007d3d957d7b18  vmovaps [rsp+0xA0], xmm11
00007d3d957d7b21  vmovaps [rsp+0xB0], xmm12
00007d3d957d7b2a  vmovaps [rsp+0xC0], xmm13
00007d3d957d7b33  vmovaps [rsp+0xD0], xmm14
00007d3d957d7b3c  vmovaps [rsp+0xE0], xmm15
00007d3d957d7b45  sub rsp, 0x30
00007d3d957d7b49  movaps [rsp], xmm1
00007d3d957d7b4d  movaps [rsp+0x10], xmm15
00007d3d957d7b53  movaps [rsp+0x20], xmm9
00007d3d957d7b59  lea rdi, [rsp]
00007d3d957d7b5d  mov esi, 0x00
00007d3d957d7b62  mov rax, 0x56C27CB8A530
00007d3d957d7b6c  call rax
00007d3d957d7b6e  movaps xmm1, [rsp]
00007d3d957d7b72  add rsp, 0x30
00007d3d957d7b76  vmovaps xmm0, [rsp]
00007d3d957d7b7b  vmovaps xmm2, [rsp+0x10]
00007d3d957d7b81  vmovaps xmm3, [rsp+0x20]
00007d3d957d7b87  vmovaps xmm4, [rsp+0x30]
00007d3d957d7b8d  vmovaps xmm5, [rsp+0x40]
00007d3d957d7b93  vmovaps xmm6, [rsp+0x50]
00007d3d957d7b99  vmovaps xmm7, [rsp+0x60]
00007d3d957d7b9f  vmovaps xmm8, [rsp+0x70]
00007d3d957d7ba5  vmovaps xmm9, [rsp+0x80]
00007d3d957d7bae  vmovaps xmm10, [rsp+0x90]
00007d3d957d7bb7  vmovaps xmm11, [rsp+0xA0]
00007d3d957d7bc0  vmovaps xmm12, [rsp+0xB0]
00007d3d957d7bc9  vmovaps xmm13, [rsp+0xC0]
00007d3d957d7bd2  vmovaps xmm14, [rsp+0xD0]
00007d3d957d7bdb  vmovaps xmm15, [rsp+0xE0]
00007d3d957d7be4  add rsp, 0xF0
00007d3d957d7beb  pop r11
00007d3d957d7bed  pop r10
00007d3d957d7bef  pop r9
00007d3d957d7bf1  pop r8
00007d3d957d7bf3  pop rsi
00007d3d957d7bf4  pop rdi
00007d3d957d7bf5  pop rdx
00007d3d957d7bf6  pop rcx
00007d3d957d7bf7  pop rax
00007d3d957d7bf8  add rsp, 0x08
00007d3d957d7bfc  jmp 0x00007D3D957D5DCB
00007d3d957d7c01  call 0x00007D3D956E5820
00007d3d957d7c06  jmp 0x00007D3D957D5DD8
00007d3d957d7c0b  sub rsp, 0x08
00007d3d957d7c0f  push rax
00007d3d957d7c10  push rcx
00007d3d957d7c11  push rdx
00007d3d957d7c12  push rdi
00007d3d957d7c13  push rsi
00007d3d957d7c14  push r8
00007d3d957d7c16  push r9
00007d3d957d7c18  push r10
00007d3d957d7c1a  push r11
00007d3d957d7c1c  sub rsp, 0xF0
00007d3d957d7c23  vmovaps [rsp], xmm0
00007d3d957d7c28  vmovaps [rsp+0x10], xmm2
00007d3d957d7c2e  vmovaps [rsp+0x20], xmm3
00007d3d957d7c34  vmovaps [rsp+0x30], xmm4
00007d3d957d7c3a  vmovaps [rsp+0x40], xmm5
00007d3d957d7c40  vmovaps [rsp+0x50], xmm6
00007d3d957d7c46  vmovaps [rsp+0x60], xmm7
00007d3d957d7c4c  vmovaps [rsp+0x70], xmm8
00007d3d957d7c52  vmovaps [rsp+0x80], xmm9
00007d3d957d7c5b  vmovaps [rsp+0x90], xmm10
00007d3d957d7c64  vmovaps [rsp+0xA0], xmm11
00007d3d957d7c6d  vmovaps [rsp+0xB0], xmm12
00007d3d957d7c76  vmovaps [rsp+0xC0], xmm13
00007d3d957d7c7f  vmovaps [rsp+0xD0], xmm14
00007d3d957d7c88  vmovaps [rsp+0xE0], xmm15
00007d3d957d7c91  sub rsp, 0x30
00007d3d957d7c95  movaps [rsp], xmm1
00007d3d957d7c99  movaps [rsp+0x10], xmm5
00007d3d957d7c9e  movaps [rsp+0x20], xmm7
00007d3d957d7ca3  lea rdi, [rsp]
00007d3d957d7ca7  mov esi, 0x00
00007d3d957d7cac  mov rax, 0x56C27CB8A530
00007d3d957d7cb6  call rax
00007d3d957d7cb8  movaps xmm1, [rsp]
00007d3d957d7cbc  add rsp, 0x30
00007d3d957d7cc0  vmovaps xmm0, [rsp]
00007d3d957d7cc5  vmovaps xmm2, [rsp+0x10]
00007d3d957d7ccb  vmovaps xmm3, [rsp+0x20]
00007d3d957d7cd1  vmovaps xmm4, [rsp+0x30]
00007d3d957d7cd7  vmovaps xmm5, [rsp+0x40]
00007d3d957d7cdd  vmovaps xmm6, [rsp+0x50]
00007d3d957d7ce3  vmovaps xmm7, [rsp+0x60]
00007d3d957d7ce9  vmovaps xmm8, [rsp+0x70]
00007d3d957d7cef  vmovaps xmm9, [rsp+0x80]
00007d3d957d7cf8  vmovaps xmm10, [rsp+0x90]
00007d3d957d7d01  vmovaps xmm11, [rsp+0xA0]
00007d3d957d7d0a  vmovaps xmm12, [rsp+0xB0]
00007d3d957d7d13  vmovaps xmm13, [rsp+0xC0]
00007d3d957d7d1c  vmovaps xmm14, [rsp+0xD0]
00007d3d957d7d25  vmovaps xmm15, [rsp+0xE0]
00007d3d957d7d2e  add rsp, 0xF0
00007d3d957d7d35  pop r11
00007d3d957d7d37  pop r10
00007d3d957d7d39  pop r9
00007d3d957d7d3b  pop r8
00007d3d957d7d3d  pop rsi
00007d3d957d7d3e  pop rdi
00007d3d957d7d3f  pop rdx
00007d3d957d7d40  pop rcx
00007d3d957d7d41  pop rax
00007d3d957d7d42  add rsp, 0x08
00007d3d957d7d46  jmp 0x00007D3D957D5E7D
00007d3d957d7d4b  sub rsp, 0x08
00007d3d957d7d4f  push rax
00007d3d957d7d50  push rcx
00007d3d957d7d51  push rdx
00007d3d957d7d52  push rdi
00007d3d957d7d53  push rsi
00007d3d957d7d54  push r8
00007d3d957d7d56  push r9
00007d3d957d7d58  push r10
00007d3d957d7d5a  push r11
00007d3d957d7d5c  sub rsp, 0xF0
00007d3d957d7d63  vmovaps [rsp], xmm0
00007d3d957d7d68  vmovaps [rsp+0x10], xmm1
00007d3d957d7d6e  vmovaps [rsp+0x20], xmm2
00007d3d957d7d74  vmovaps [rsp+0x30], xmm3
00007d3d957d7d7a  vmovaps [rsp+0x40], xmm4
00007d3d957d7d80  vmovaps [rsp+0x50], xmm5
00007d3d957d7d86  vmovaps [rsp+0x60], xmm6
00007d3d957d7d8c  vmovaps [rsp+0x70], xmm8
00007d3d957d7d92  vmovaps [rsp+0x80], xmm9
00007d3d957d7d9b  vmovaps [rsp+0x90], xmm10
00007d3d957d7da4  vmovaps [rsp+0xA0], xmm11
00007d3d957d7dad  vmovaps [rsp+0xB0], xmm12
00007d3d957d7db6  vmovaps [rsp+0xC0], xmm13
00007d3d957d7dbf  vmovaps [rsp+0xD0], xmm14
00007d3d957d7dc8  vmovaps [rsp+0xE0], xmm15
00007d3d957d7dd1  sub rsp, 0x30
00007d3d957d7dd5  movaps [rsp], xmm7
00007d3d957d7dd9  movaps [rsp+0x10], xmm5
00007d3d957d7dde  movaps [rsp+0x20], xmm15
00007d3d957d7de4  lea rdi, [rsp]
00007d3d957d7de8  mov esi, 0x00
00007d3d957d7ded  mov rax, 0x56C27CB8A530
00007d3d957d7df7  call rax
00007d3d957d7df9  movaps xmm7, [rsp]
00007d3d957d7dfd  add rsp, 0x30
00007d3d957d7e01  vmovaps xmm0, [rsp]
00007d3d957d7e06  vmovaps xmm1, [rsp+0x10]
00007d3d957d7e0c  vmovaps xmm2, [rsp+0x20]
00007d3d957d7e12  vmovaps xmm3, [rsp+0x30]
00007d3d957d7e18  vmovaps xmm4, [rsp+0x40]
00007d3d957d7e1e  vmovaps xmm5, [rsp+0x50]
00007d3d957d7e24  vmovaps xmm6, [rsp+0x60]
00007d3d957d7e2a  vmovaps xmm8, [rsp+0x70]
00007d3d957d7e30  vmovaps xmm9, [rsp+0x80]
00007d3d957d7e39  vmovaps xmm10, [rsp+0x90]
00007d3d957d7e42  vmovaps xmm11, [rsp+0xA0]
00007d3d957d7e4b  vmovaps xmm12, [rsp+0xB0]
00007d3d957d7e54  vmovaps xmm13, [rsp+0xC0]
00007d3d957d7e5d  vmovaps xmm14, [rsp+0xD0]
00007d3d957d7e66  vmovaps xmm15, [rsp+0xE0]
00007d3d957d7e6f  add rsp, 0xF0
00007d3d957d7e76  pop r11
00007d3d957d7e78  pop r10
00007d3d957d7e7a  pop r9
00007d3d957d7e7c  pop r8
00007d3d957d7e7e  pop rsi
00007d3d957d7e7f  pop rdi
00007d3d957d7e80  pop rdx
00007d3d957d7e81  pop rcx
00007d3d957d7e82  pop rax
00007d3d957d7e83  add rsp, 0x08
00007d3d957d7e87  jmp 0x00007D3D957D5EB3
00007d3d957d7e8c  call 0x00007D3D956D64F0
00007d3d957d7e91  jmp 0x00007D3D957D5EC0
00007d3d957d7e96  sub rsp, 0x08
00007d3d957d7e9a  push rax
00007d3d957d7e9b  push rcx
00007d3d957d7e9c  push rdx
00007d3d957d7e9d  push rdi
00007d3d957d7e9e  push rsi
00007d3d957d7e9f  push r8
00007d3d957d7ea1  push r9
00007d3d957d7ea3  push r10
00007d3d957d7ea5  push r11
00007d3d957d7ea7  sub rsp, 0xF0
00007d3d957d7eae  vmovaps [rsp], xmm0
00007d3d957d7eb3  vmovaps [rsp+0x10], xmm1
00007d3d957d7eb9  vmovaps [rsp+0x20], xmm2
00007d3d957d7ebf  vmovaps [rsp+0x30], xmm3
00007d3d957d7ec5  vmovaps [rsp+0x40], xmm4
00007d3d957d7ecb  vmovaps [rsp+0x50], xmm5
00007d3d957d7ed1  vmovaps [rsp+0x60], xmm6
00007d3d957d7ed7  vmovaps [rsp+0x70], xmm7
00007d3d957d7edd  vmovaps [rsp+0x80], xmm8
00007d3d957d7ee6  vmovaps [rsp+0x90], xmm9
00007d3d957d7eef  vmovaps [rsp+0xA0], xmm10
00007d3d957d7ef8  vmovaps [rsp+0xB0], xmm11
00007d3d957d7f01  vmovaps [rsp+0xC0], xmm12
00007d3d957d7f0a  vmovaps [rsp+0xD0], xmm13
00007d3d957d7f13  vmovaps [rsp+0xE0], xmm14
00007d3d957d7f1c  sub rsp, 0x30
00007d3d957d7f20  movaps [rsp], xmm15
00007d3d957d7f25  movaps [rsp+0x10], xmm5
00007d3d957d7f2a  movaps [rsp+0x20], xmm3
00007d3d957d7f2f  lea rdi, [rsp]
00007d3d957d7f33  mov esi, 0x00
00007d3d957d7f38  mov rax, 0x56C27CB8A530
00007d3d957d7f42  call rax
00007d3d957d7f44  movaps xmm15, [rsp]
00007d3d957d7f49  add rsp, 0x30
00007d3d957d7f4d  vmovaps xmm0, [rsp]
00007d3d957d7f52  vmovaps xmm1, [rsp+0x10]
00007d3d957d7f58  vmovaps xmm2, [rsp+0x20]
00007d3d957d7f5e  vmovaps xmm3, [rsp+0x30]
00007d3d957d7f64  vmovaps xmm4, [rsp+0x40]
00007d3d957d7f6a  vmovaps xmm5, [rsp+0x50]
00007d3d957d7f70  vmovaps xmm6, [rsp+0x60]
00007d3d957d7f76  vmovaps xmm7, [rsp+0x70]
00007d3d957d7f7c  vmovaps xmm8, [rsp+0x80]
00007d3d957d7f85  vmovaps xmm9, [rsp+0x90]
00007d3d957d7f8e  vmovaps xmm10, [rsp+0xA0]
00007d3d957d7f97  vmovaps xmm11, [rsp+0xB0]
00007d3d957d7fa0  vmovaps xmm12, [rsp+0xC0]
00007d3d957d7fa9  vmovaps xmm13, [rsp+0xD0]
00007d3d957d7fb2  vmovaps xmm14, [rsp+0xE0]
00007d3d957d7fbb  add rsp, 0xF0
00007d3d957d7fc2  pop r11
00007d3d957d7fc4  pop r10
00007d3d957d7fc6  pop r9
00007d3d957d7fc8  pop r8
00007d3d957d7fca  pop rsi
00007d3d957d7fcb  pop rdi
00007d3d957d7fcc  pop rdx
00007d3d957d7fcd  pop rcx
00007d3d957d7fce  pop rax
00007d3d957d7fcf  add rsp, 0x08
00007d3d957d7fd3  jmp 0x00007D3D957D5EE6
00007d3d957d7fd8  sub rsp, 0x08
00007d3d957d7fdc  push rax
00007d3d957d7fdd  push rcx
00007d3d957d7fde  push rdx
00007d3d957d7fdf  push rdi
00007d3d957d7fe0  push rsi
00007d3d957d7fe1  push r8
00007d3d957d7fe3  push r9
00007d3d957d7fe5  push r10
00007d3d957d7fe7  push r11
00007d3d957d7fe9  sub rsp, 0xF0
00007d3d957d7ff0  vmovaps [rsp], xmm0
00007d3d957d7ff5  vmovaps [rsp+0x10], xmm2
00007d3d957d7ffb  vmovaps [rsp+0x20], xmm3
00007d3d957d8001  vmovaps [rsp+0x30], xmm4
00007d3d957d8007  vmovaps [rsp+0x40], xmm5
00007d3d957d800d  vmovaps [rsp+0x50], xmm6
00007d3d957d8013  vmovaps [rsp+0x60], xmm7
00007d3d957d8019  vmovaps [rsp+0x70], xmm8
00007d3d957d801f  vmovaps [rsp+0x80], xmm9
00007d3d957d8028  vmovaps [rsp+0x90], xmm10
00007d3d957d8031  vmovaps [rsp+0xA0], xmm11
00007d3d957d803a  vmovaps [rsp+0xB0], xmm12
00007d3d957d8043  vmovaps [rsp+0xC0], xmm13
00007d3d957d804c  vmovaps [rsp+0xD0], xmm14
00007d3d957d8055  vmovaps [rsp+0xE0], xmm15
00007d3d957d805e  sub rsp, 0x30
00007d3d957d8062  movaps [rsp], xmm1
00007d3d957d8066  movaps [rsp+0x10], xmm5
00007d3d957d806b  movaps [rsp+0x20], xmm4
00007d3d957d8070  lea rdi, [rsp]
00007d3d957d8074  mov esi, 0x00
00007d3d957d8079  mov rax, 0x56C27CB8A530
00007d3d957d8083  call rax
00007d3d957d8085  movaps xmm1, [rsp]
00007d3d957d8089  add rsp, 0x30
00007d3d957d808d  vmovaps xmm0, [rsp]
00007d3d957d8092  vmovaps xmm2, [rsp+0x10]
00007d3d957d8098  vmovaps xmm3, [rsp+0x20]
00007d3d957d809e  vmovaps xmm4, [rsp+0x30]
00007d3d957d80a4  vmovaps xmm5, [rsp+0x40]
00007d3d957d80aa  vmovaps xmm6, [rsp+0x50]
00007d3d957d80b0  vmovaps xmm7, [rsp+0x60]
00007d3d957d80b6  vmovaps xmm8, [rsp+0x70]
00007d3d957d80bc  vmovaps xmm9, [rsp+0x80]
00007d3d957d80c5  vmovaps xmm10, [rsp+0x90]
00007d3d957d80ce  vmovaps xmm11, [rsp+0xA0]
00007d3d957d80d7  vmovaps xmm12, [rsp+0xB0]
00007d3d957d80e0  vmovaps xmm13, [rsp+0xC0]
00007d3d957d80e9  vmovaps xmm14, [rsp+0xD0]
00007d3d957d80f2  vmovaps xmm15, [rsp+0xE0]
00007d3d957d80fb  add rsp, 0xF0
00007d3d957d8102  pop r11
00007d3d957d8104  pop r10
00007d3d957d8106  pop r9
00007d3d957d8108  pop r8
00007d3d957d810a  pop rsi
00007d3d957d810b  pop rdi
00007d3d957d810c  pop rdx
00007d3d957d810d  pop rcx
00007d3d957d810e  pop rax
00007d3d957d810f  add rsp, 0x08
00007d3d957d8113  jmp 0x00007D3D957D5F06
00007d3d957d8118  sub rsp, 0x08
00007d3d957d811c  push rax
00007d3d957d811d  push rcx
00007d3d957d811e  push rdx
00007d3d957d811f  push rdi
00007d3d957d8120  push rsi
00007d3d957d8121  push r8
00007d3d957d8123  push r9
00007d3d957d8125  push r10
00007d3d957d8127  push r11
00007d3d957d8129  sub rsp, 0xF0
00007d3d957d8130  vmovaps [rsp], xmm0
00007d3d957d8135  vmovaps [rsp+0x10], xmm1
00007d3d957d813b  vmovaps [rsp+0x20], xmm2
00007d3d957d8141  vmovaps [rsp+0x30], xmm3
00007d3d957d8147  vmovaps [rsp+0x40], xmm5
00007d3d957d814d  vmovaps [rsp+0x50], xmm6
00007d3d957d8153  vmovaps [rsp+0x60], xmm7
00007d3d957d8159  vmovaps [rsp+0x70], xmm8
00007d3d957d815f  vmovaps [rsp+0x80], xmm9
00007d3d957d8168  vmovaps [rsp+0x90], xmm10
00007d3d957d8171  vmovaps [rsp+0xA0], xmm11
00007d3d957d817a  vmovaps [rsp+0xB0], xmm12
00007d3d957d8183  vmovaps [rsp+0xC0], xmm13
00007d3d957d818c  vmovaps [rsp+0xD0], xmm14
00007d3d957d8195  vmovaps [rsp+0xE0], xmm15
00007d3d957d819e  sub rsp, 0x30
00007d3d957d81a2  movaps [rsp], xmm4
00007d3d957d81a6  movaps [rsp+0x10], xmm3
00007d3d957d81ab  movaps [rsp+0x20], xmm5
00007d3d957d81b0  lea rdi, [rsp]
00007d3d957d81b4  mov esi, 0x00
00007d3d957d81b9  mov rax, 0x56C27CB8A530
00007d3d957d81c3  call rax
00007d3d957d81c5  movaps xmm4, [rsp]
00007d3d957d81c9  add rsp, 0x30
00007d3d957d81cd  vmovaps xmm0, [rsp]
00007d3d957d81d2  vmovaps xmm1, [rsp+0x10]
00007d3d957d81d8  vmovaps xmm2, [rsp+0x20]
00007d3d957d81de  vmovaps xmm3, [rsp+0x30]
00007d3d957d81e4  vmovaps xmm5, [rsp+0x40]
00007d3d957d81ea  vmovaps xmm6, [rsp+0x50]
00007d3d957d81f0  vmovaps xmm7, [rsp+0x60]
00007d3d957d81f6  vmovaps xmm8, [rsp+0x70]
00007d3d957d81fc  vmovaps xmm9, [rsp+0x80]
00007d3d957d8205  vmovaps xmm10, [rsp+0x90]
00007d3d957d820e  vmovaps xmm11, [rsp+0xA0]
00007d3d957d8217  vmovaps xmm12, [rsp+0xB0]
00007d3d957d8220  vmovaps xmm13, [rsp+0xC0]
00007d3d957d8229  vmovaps xmm14, [rsp+0xD0]
00007d3d957d8232  vmovaps xmm15, [rsp+0xE0]
00007d3d957d823b  add rsp, 0xF0
00007d3d957d8242  pop r11
00007d3d957d8244  pop r10
00007d3d957d8246  pop r9
00007d3d957d8248  pop r8
00007d3d957d824a  pop rsi
00007d3d957d824b  pop rdi
00007d3d957d824c  pop rdx
00007d3d957d824d  pop rcx
00007d3d957d824e  pop rax
00007d3d957d824f  add rsp, 0x08
00007d3d957d8253  jmp 0x00007D3D957D5F54
00007d3d957d8258  call 0x00007D3D956D64F0
00007d3d957d825d  jmp 0x00007D3D957D5F61
00007d3d957d8262  sub rsp, 0x08
00007d3d957d8266  push rax
00007d3d957d8267  push rcx
00007d3d957d8268  push rdx
00007d3d957d8269  push rdi
00007d3d957d826a  push rsi
00007d3d957d826b  push r8
00007d3d957d826d  push r9
00007d3d957d826f  push r10
00007d3d957d8271  push r11
00007d3d957d8273  sub rsp, 0xF0
00007d3d957d827a  vmovaps [rsp], xmm0
00007d3d957d827f  vmovaps [rsp+0x10], xmm1
00007d3d957d8285  vmovaps [rsp+0x20], xmm2
00007d3d957d828b  vmovaps [rsp+0x30], xmm3
00007d3d957d8291  vmovaps [rsp+0x40], xmm4
00007d3d957d8297  vmovaps [rsp+0x50], xmm6
00007d3d957d829d  vmovaps [rsp+0x60], xmm7
00007d3d957d82a3  vmovaps [rsp+0x70], xmm8
00007d3d957d82a9  vmovaps [rsp+0x80], xmm9
00007d3d957d82b2  vmovaps [rsp+0x90], xmm10
00007d3d957d82bb  vmovaps [rsp+0xA0], xmm11
00007d3d957d82c4  vmovaps [rsp+0xB0], xmm12
00007d3d957d82cd  vmovaps [rsp+0xC0], xmm13
00007d3d957d82d6  vmovaps [rsp+0xD0], xmm14
00007d3d957d82df  vmovaps [rsp+0xE0], xmm15
00007d3d957d82e8  sub rsp, 0x30
00007d3d957d82ec  movaps [rsp], xmm5
00007d3d957d82f0  movaps [rsp+0x10], xmm6
00007d3d957d82f5  movaps [rsp+0x20], xmm3
00007d3d957d82fa  lea rdi, [rsp]
00007d3d957d82fe  mov esi, 0x00
00007d3d957d8303  mov rax, 0x56C27CB8A530
00007d3d957d830d  call rax
00007d3d957d830f  movaps xmm5, [rsp]
00007d3d957d8313  add rsp, 0x30
00007d3d957d8317  vmovaps xmm0, [rsp]
00007d3d957d831c  vmovaps xmm1, [rsp+0x10]
00007d3d957d8322  vmovaps xmm2, [rsp+0x20]
00007d3d957d8328  vmovaps xmm3, [rsp+0x30]
00007d3d957d832e  vmovaps xmm4, [rsp+0x40]
00007d3d957d8334  vmovaps xmm6, [rsp+0x50]
00007d3d957d833a  vmovaps xmm7, [rsp+0x60]
00007d3d957d8340  vmovaps xmm8, [rsp+0x70]
00007d3d957d8346  vmovaps xmm9, [rsp+0x80]
00007d3d957d834f  vmovaps xmm10, [rsp+0x90]
00007d3d957d8358  vmovaps xmm11, [rsp+0xA0]
00007d3d957d8361  vmovaps xmm12, [rsp+0xB0]
00007d3d957d836a  vmovaps xmm13, [rsp+0xC0]
00007d3d957d8373  vmovaps xmm14, [rsp+0xD0]
00007d3d957d837c  vmovaps xmm15, [rsp+0xE0]
00007d3d957d8385  add rsp, 0xF0
00007d3d957d838c  pop r11
00007d3d957d838e  pop r10
00007d3d957d8390  pop r9
00007d3d957d8392  pop r8
00007d3d957d8394  pop rsi
00007d3d957d8395  pop rdi
00007d3d957d8396  pop rdx
00007d3d957d8397  pop rcx
00007d3d957d8398  pop rax
00007d3d957d8399  add rsp, 0x08
00007d3d957d839d  jmp 0x00007D3D957D5F87
00007d3d957d83a2  sub rsp, 0x08
00007d3d957d83a6  push rax
00007d3d957d83a7  push rcx
00007d3d957d83a8  push rdx
00007d3d957d83a9  push rdi
00007d3d957d83aa  push rsi
00007d3d957d83ab  push r8
00007d3d957d83ad  push r9
00007d3d957d83af  push r10
00007d3d957d83b1  push r11
00007d3d957d83b3  sub rsp, 0xF0
00007d3d957d83ba  vmovaps [rsp], xmm0
00007d3d957d83bf  vmovaps [rsp+0x10], xmm1
00007d3d957d83c5  vmovaps [rsp+0x20], xmm2
00007d3d957d83cb  vmovaps [rsp+0x30], xmm3
00007d3d957d83d1  vmovaps [rsp+0x40], xmm4
00007d3d957d83d7  vmovaps [rsp+0x50], xmm5
00007d3d957d83dd  vmovaps [rsp+0x60], xmm7
00007d3d957d83e3  vmovaps [rsp+0x70], xmm8
00007d3d957d83e9  vmovaps [rsp+0x80], xmm9
00007d3d957d83f2  vmovaps [rsp+0x90], xmm10
00007d3d957d83fb  vmovaps [rsp+0xA0], xmm11
00007d3d957d8404  vmovaps [rsp+0xB0], xmm12
00007d3d957d840d  vmovaps [rsp+0xC0], xmm13
00007d3d957d8416  vmovaps [rsp+0xD0], xmm14
00007d3d957d841f  vmovaps [rsp+0xE0], xmm15
00007d3d957d8428  sub rsp, 0x30
00007d3d957d842c  movaps [rsp], xmm6
00007d3d957d8430  movaps [rsp+0x10], xmm9
00007d3d957d8436  movaps [rsp+0x20], xmm1
00007d3d957d843b  lea rdi, [rsp]
00007d3d957d843f  mov esi, 0x00
00007d3d957d8444  mov rax, 0x56C27CB8A530
00007d3d957d844e  call rax
00007d3d957d8450  movaps xmm6, [rsp]
00007d3d957d8454  add rsp, 0x30
00007d3d957d8458  vmovaps xmm0, [rsp]
00007d3d957d845d  vmovaps xmm1, [rsp+0x10]
00007d3d957d8463  vmovaps xmm2, [rsp+0x20]
00007d3d957d8469  vmovaps xmm3, [rsp+0x30]
00007d3d957d846f  vmovaps xmm4, [rsp+0x40]
00007d3d957d8475  vmovaps xmm5, [rsp+0x50]
00007d3d957d847b  vmovaps xmm7, [rsp+0x60]
00007d3d957d8481  vmovaps xmm8, [rsp+0x70]
00007d3d957d8487  vmovaps xmm9, [rsp+0x80]
00007d3d957d8490  vmovaps xmm10, [rsp+0x90]
00007d3d957d8499  vmovaps xmm11, [rsp+0xA0]
00007d3d957d84a2  vmovaps xmm12, [rsp+0xB0]
00007d3d957d84ab  vmovaps xmm13, [rsp+0xC0]
00007d3d957d84b4  vmovaps xmm14, [rsp+0xD0]
00007d3d957d84bd  vmovaps xmm15, [rsp+0xE0]
00007d3d957d84c6  add rsp, 0xF0
00007d3d957d84cd  pop r11
00007d3d957d84cf  pop r10
00007d3d957d84d1  pop r9
00007d3d957d84d3  pop r8
00007d3d957d84d5  pop rsi
00007d3d957d84d6  pop rdi
00007d3d957d84d7  pop rdx
00007d3d957d84d8  pop rcx
00007d3d957d84d9  pop rax
00007d3d957d84da  add rsp, 0x08
00007d3d957d84de  jmp 0x00007D3D957D5FAB
00007d3d957d84e3  sub rsp, 0x08
00007d3d957d84e7  push rax
00007d3d957d84e8  push rcx
00007d3d957d84e9  push rdx
00007d3d957d84ea  push rdi
00007d3d957d84eb  push rsi
00007d3d957d84ec  push r8
00007d3d957d84ee  push r9
00007d3d957d84f0  push r10
00007d3d957d84f2  push r11
00007d3d957d84f4  sub rsp, 0xF0
00007d3d957d84fb  vmovaps [rsp], xmm0
00007d3d957d8500  vmovaps [rsp+0x10], xmm1
00007d3d957d8506  vmovaps [rsp+0x20], xmm2
00007d3d957d850c  vmovaps [rsp+0x30], xmm3
00007d3d957d8512  vmovaps [rsp+0x40], xmm4
00007d3d957d8518  vmovaps [rsp+0x50], xmm5
00007d3d957d851e  vmovaps [rsp+0x60], xmm6
00007d3d957d8524  vmovaps [rsp+0x70], xmm7
00007d3d957d852a  vmovaps [rsp+0x80], xmm8
00007d3d957d8533  vmovaps [rsp+0x90], xmm10
00007d3d957d853c  vmovaps [rsp+0xA0], xmm11
00007d3d957d8545  vmovaps [rsp+0xB0], xmm12
00007d3d957d854e  vmovaps [rsp+0xC0], xmm13
00007d3d957d8557  vmovaps [rsp+0xD0], xmm14
00007d3d957d8560  vmovaps [rsp+0xE0], xmm15
00007d3d957d8569  sub rsp, 0x30
00007d3d957d856d  movaps [rsp], xmm9
00007d3d957d8572  movaps [rsp+0x10], xmm3
00007d3d957d8577  movaps [rsp+0x20], xmm1
00007d3d957d857c  lea rdi, [rsp]
00007d3d957d8580  mov esi, 0x00
00007d3d957d8585  mov rax, 0x56C27CB8A530
00007d3d957d858f  call rax
00007d3d957d8591  movaps xmm9, [rsp]
00007d3d957d8596  add rsp, 0x30
00007d3d957d859a  vmovaps xmm0, [rsp]
00007d3d957d859f  vmovaps xmm1, [rsp+0x10]
00007d3d957d85a5  vmovaps xmm2, [rsp+0x20]
00007d3d957d85ab  vmovaps xmm3, [rsp+0x30]
00007d3d957d85b1  vmovaps xmm4, [rsp+0x40]
00007d3d957d85b7  vmovaps xmm5, [rsp+0x50]
00007d3d957d85bd  vmovaps xmm6, [rsp+0x60]
00007d3d957d85c3  vmovaps xmm7, [rsp+0x70]
00007d3d957d85c9  vmovaps xmm8, [rsp+0x80]
00007d3d957d85d2  vmovaps xmm10, [rsp+0x90]
00007d3d957d85db  vmovaps xmm11, [rsp+0xA0]
00007d3d957d85e4  vmovaps xmm12, [rsp+0xB0]
00007d3d957d85ed  vmovaps xmm13, [rsp+0xC0]
00007d3d957d85f6  vmovaps xmm14, [rsp+0xD0]
00007d3d957d85ff  vmovaps xmm15, [rsp+0xE0]
00007d3d957d8608  add rsp, 0xF0
00007d3d957d860f  pop r11
00007d3d957d8611  pop r10
00007d3d957d8613  pop r9
00007d3d957d8615  pop r8
00007d3d957d8617  pop rsi
00007d3d957d8618  pop rdi
00007d3d957d8619  pop rdx
00007d3d957d861a  pop rcx
00007d3d957d861b  pop rax
00007d3d957d861c  add rsp, 0x08
00007d3d957d8620  jmp 0x00007D3D957D5FF7
00007d3d957d8625  call 0x00007D3D956D64F0
00007d3d957d862a  jmp 0x00007D3D957D6004
00007d3d957d862f  sub rsp, 0x08
00007d3d957d8633  push rax
00007d3d957d8634  push rcx
00007d3d957d8635  push rdx
00007d3d957d8636  push rdi
00007d3d957d8637  push rsi
00007d3d957d8638  push r8
00007d3d957d863a  push r9
00007d3d957d863c  push r10
00007d3d957d863e  push r11
00007d3d957d8640  sub rsp, 0xF0
00007d3d957d8647  vmovaps [rsp], xmm0
00007d3d957d864c  vmovaps [rsp+0x10], xmm1
00007d3d957d8652  vmovaps [rsp+0x20], xmm2
00007d3d957d8658  vmovaps [rsp+0x30], xmm3
00007d3d957d865e  vmovaps [rsp+0x40], xmm4
00007d3d957d8664  vmovaps [rsp+0x50], xmm5
00007d3d957d866a  vmovaps [rsp+0x60], xmm6
00007d3d957d8670  vmovaps [rsp+0x70], xmm7
00007d3d957d8676  vmovaps [rsp+0x80], xmm8
00007d3d957d867f  vmovaps [rsp+0x90], xmm9
00007d3d957d8688  vmovaps [rsp+0xA0], xmm10
00007d3d957d8691  vmovaps [rsp+0xB0], xmm11
00007d3d957d869a  vmovaps [rsp+0xC0], xmm12
00007d3d957d86a3  vmovaps [rsp+0xD0], xmm13
00007d3d957d86ac  vmovaps [rsp+0xE0], xmm14
00007d3d957d86b5  sub rsp, 0x30
00007d3d957d86b9  movaps [rsp], xmm15
00007d3d957d86be  movaps [rsp+0x10], xmm3
00007d3d957d86c3  movaps [rsp+0x20], xmm7
00007d3d957d86c8  lea rdi, [rsp]
00007d3d957d86cc  mov esi, 0x00
00007d3d957d86d1  mov rax, 0x56C27CB8A530
00007d3d957d86db  call rax
00007d3d957d86dd  movaps xmm15, [rsp]
00007d3d957d86e2  add rsp, 0x30
00007d3d957d86e6  vmovaps xmm0, [rsp]
00007d3d957d86eb  vmovaps xmm1, [rsp+0x10]
00007d3d957d86f1  vmovaps xmm2, [rsp+0x20]
00007d3d957d86f7  vmovaps xmm3, [rsp+0x30]
00007d3d957d86fd  vmovaps xmm4, [rsp+0x40]
00007d3d957d8703  vmovaps xmm5, [rsp+0x50]
00007d3d957d8709  vmovaps xmm6, [rsp+0x60]
00007d3d957d870f  vmovaps xmm7, [rsp+0x70]
00007d3d957d8715  vmovaps xmm8, [rsp+0x80]
00007d3d957d871e  vmovaps xmm9, [rsp+0x90]
00007d3d957d8727  vmovaps xmm10, [rsp+0xA0]
00007d3d957d8730  vmovaps xmm11, [rsp+0xB0]
00007d3d957d8739  vmovaps xmm12, [rsp+0xC0]
00007d3d957d8742  vmovaps xmm13, [rsp+0xD0]
00007d3d957d874b  vmovaps xmm14, [rsp+0xE0]
00007d3d957d8754  add rsp, 0xF0
00007d3d957d875b  pop r11
00007d3d957d875d  pop r10
00007d3d957d875f  pop r9
00007d3d957d8761  pop r8
00007d3d957d8763  pop rsi
00007d3d957d8764  pop rdi
00007d3d957d8765  pop rdx
00007d3d957d8766  pop rcx
00007d3d957d8767  pop rax
00007d3d957d8768  add rsp, 0x08
00007d3d957d876c  jmp 0x00007D3D957D6030
00007d3d957d8771  sub rsp, 0x08
00007d3d957d8775  push rax
00007d3d957d8776  push rcx
00007d3d957d8777  push rdx
00007d3d957d8778  push rdi
00007d3d957d8779  push rsi
00007d3d957d877a  push r8
00007d3d957d877c  push r9
00007d3d957d877e  push r10
00007d3d957d8780  push r11
00007d3d957d8782  sub rsp, 0xF0
00007d3d957d8789  vmovaps [rsp], xmm0
00007d3d957d878e  vmovaps [rsp+0x10], xmm1
00007d3d957d8794  vmovaps [rsp+0x20], xmm2
00007d3d957d879a  vmovaps [rsp+0x30], xmm4
00007d3d957d87a0  vmovaps [rsp+0x40], xmm5
00007d3d957d87a6  vmovaps [rsp+0x50], xmm6
00007d3d957d87ac  vmovaps [rsp+0x60], xmm7
00007d3d957d87b2  vmovaps [rsp+0x70], xmm8
00007d3d957d87b8  vmovaps [rsp+0x80], xmm9
00007d3d957d87c1  vmovaps [rsp+0x90], xmm10
00007d3d957d87ca  vmovaps [rsp+0xA0], xmm11
00007d3d957d87d3  vmovaps [rsp+0xB0], xmm12
00007d3d957d87dc  vmovaps [rsp+0xC0], xmm13
00007d3d957d87e5  vmovaps [rsp+0xD0], xmm14
00007d3d957d87ee  vmovaps [rsp+0xE0], xmm15
00007d3d957d87f7  sub rsp, 0x30
00007d3d957d87fb  movaps [rsp], xmm3
00007d3d957d87ff  movaps [rsp+0x10], xmm1
00007d3d957d8804  movaps [rsp+0x20], xmm15
00007d3d957d880a  lea rdi, [rsp]
00007d3d957d880e  mov esi, 0x00
00007d3d957d8813  mov rax, 0x56C27CB8A530
00007d3d957d881d  call rax
00007d3d957d881f  movaps xmm3, [rsp]
00007d3d957d8823  add rsp, 0x30
00007d3d957d8827  vmovaps xmm0, [rsp]
00007d3d957d882c  vmovaps xmm1, [rsp+0x10]
00007d3d957d8832  vmovaps xmm2, [rsp+0x20]
00007d3d957d8838  vmovaps xmm4, [rsp+0x30]
00007d3d957d883e  vmovaps xmm5, [rsp+0x40]
00007d3d957d8844  vmovaps xmm6, [rsp+0x50]
00007d3d957d884a  vmovaps xmm7, [rsp+0x60]
00007d3d957d8850  vmovaps xmm8, [rsp+0x70]
00007d3d957d8856  vmovaps xmm9, [rsp+0x80]
00007d3d957d885f  vmovaps xmm10, [rsp+0x90]
00007d3d957d8868  vmovaps xmm11, [rsp+0xA0]
00007d3d957d8871  vmovaps xmm12, [rsp+0xB0]
00007d3d957d887a  vmovaps xmm13, [rsp+0xC0]
00007d3d957d8883  vmovaps xmm14, [rsp+0xD0]
00007d3d957d888c  vmovaps xmm15, [rsp+0xE0]
00007d3d957d8895  add rsp, 0xF0
00007d3d957d889c  pop r11
00007d3d957d889e  pop r10
00007d3d957d88a0  pop r9
00007d3d957d88a2  pop r8
00007d3d957d88a4  pop rsi
00007d3d957d88a5  pop rdi
00007d3d957d88a6  pop rdx
00007d3d957d88a7  pop rcx
00007d3d957d88a8  pop rax
00007d3d957d88a9  add rsp, 0x08
00007d3d957d88ad  jmp 0x00007D3D957D60BF
00007d3d957d88b2  call 0x00007D3D956D64F0
00007d3d957d88b7  jmp 0x00007D3D957D60C9
00007d3d957d88bc  sub rsp, 0x08
00007d3d957d88c0  push rax
00007d3d957d88c1  push rcx
00007d3d957d88c2  push rdx
00007d3d957d88c3  push rdi
00007d3d957d88c4  push rsi
00007d3d957d88c5  push r8
00007d3d957d88c7  push r9
00007d3d957d88c9  push r10
00007d3d957d88cb  push r11
00007d3d957d88cd  sub rsp, 0xF0
00007d3d957d88d4  vmovaps [rsp], xmm0
00007d3d957d88d9  vmovaps [rsp+0x10], xmm1
00007d3d957d88df  vmovaps [rsp+0x20], xmm2
00007d3d957d88e5  vmovaps [rsp+0x30], xmm3
00007d3d957d88eb  vmovaps [rsp+0x40], xmm4
00007d3d957d88f1  vmovaps [rsp+0x50], xmm5
00007d3d957d88f7  vmovaps [rsp+0x60], xmm6
00007d3d957d88fd  vmovaps [rsp+0x70], xmm7
00007d3d957d8903  vmovaps [rsp+0x80], xmm8
00007d3d957d890c  vmovaps [rsp+0x90], xmm9
00007d3d957d8915  vmovaps [rsp+0xA0], xmm10
00007d3d957d891e  vmovaps [rsp+0xB0], xmm11
00007d3d957d8927  vmovaps [rsp+0xC0], xmm12
00007d3d957d8930  vmovaps [rsp+0xD0], xmm13
00007d3d957d8939  vmovaps [rsp+0xE0], xmm14
00007d3d957d8942  sub rsp, 0x30
00007d3d957d8946  movaps [rsp], xmm15
00007d3d957d894b  movaps [rsp+0x10], xmm14
00007d3d957d8951  movaps [rsp+0x20], xmm4
00007d3d957d8956  lea rdi, [rsp]
00007d3d957d895a  mov esi, 0x00
00007d3d957d895f  mov rax, 0x56C27CB8A530
00007d3d957d8969  call rax
00007d3d957d896b  movaps xmm15, [rsp]
00007d3d957d8970  add rsp, 0x30
00007d3d957d8974  vmovaps xmm0, [rsp]
00007d3d957d8979  vmovaps xmm1, [rsp+0x10]
00007d3d957d897f  vmovaps xmm2, [rsp+0x20]
00007d3d957d8985  vmovaps xmm3, [rsp+0x30]
00007d3d957d898b  vmovaps xmm4, [rsp+0x40]
00007d3d957d8991  vmovaps xmm5, [rsp+0x50]
00007d3d957d8997  vmovaps xmm6, [rsp+0x60]
00007d3d957d899d  vmovaps xmm7, [rsp+0x70]
00007d3d957d89a3  vmovaps xmm8, [rsp+0x80]
00007d3d957d89ac  vmovaps xmm9, [rsp+0x90]
00007d3d957d89b5  vmovaps xmm10, [rsp+0xA0]
00007d3d957d89be  vmovaps xmm11, [rsp+0xB0]
00007d3d957d89c7  vmovaps xmm12, [rsp+0xC0]
00007d3d957d89d0  vmovaps xmm13, [rsp+0xD0]
00007d3d957d89d9  vmovaps xmm14, [rsp+0xE0]
00007d3d957d89e2  add rsp, 0xF0
00007d3d957d89e9  pop r11
00007d3d957d89eb  pop r10
00007d3d957d89ed  pop r9
00007d3d957d89ef  pop r8
00007d3d957d89f1  pop rsi
00007d3d957d89f2  pop rdi
00007d3d957d89f3  pop rdx
00007d3d957d89f4  pop rcx
00007d3d957d89f5  pop rax
00007d3d957d89f6  add rsp, 0x08
00007d3d957d89fa  jmp 0x00007D3D957D60F7
00007d3d957d89ff  sub rsp, 0x08
00007d3d957d8a03  push rax
00007d3d957d8a04  push rcx
00007d3d957d8a05  push rdx
00007d3d957d8a06  push rdi
00007d3d957d8a07  push rsi
00007d3d957d8a08  push r8
00007d3d957d8a0a  push r9
00007d3d957d8a0c  push r10
00007d3d957d8a0e  push r11
00007d3d957d8a10  sub rsp, 0xF0
00007d3d957d8a17  vmovaps [rsp], xmm0
00007d3d957d8a1c  vmovaps [rsp+0x10], xmm1
00007d3d957d8a22  vmovaps [rsp+0x20], xmm2
00007d3d957d8a28  vmovaps [rsp+0x30], xmm3
00007d3d957d8a2e  vmovaps [rsp+0x40], xmm4
00007d3d957d8a34  vmovaps [rsp+0x50], xmm5
00007d3d957d8a3a  vmovaps [rsp+0x60], xmm6
00007d3d957d8a40  vmovaps [rsp+0x70], xmm7
00007d3d957d8a46  vmovaps [rsp+0x80], xmm8
00007d3d957d8a4f  vmovaps [rsp+0x90], xmm9
00007d3d957d8a58  vmovaps [rsp+0xA0], xmm10
00007d3d957d8a61  vmovaps [rsp+0xB0], xmm11
00007d3d957d8a6a  vmovaps [rsp+0xC0], xmm12
00007d3d957d8a73  vmovaps [rsp+0xD0], xmm13
00007d3d957d8a7c  vmovaps [rsp+0xE0], xmm15
00007d3d957d8a85  sub rsp, 0x30
00007d3d957d8a89  movaps [rsp], xmm14
00007d3d957d8a8e  movaps [rsp+0x10], xmm2
00007d3d957d8a93  movaps [rsp+0x20], xmm1
00007d3d957d8a98  lea rdi, [rsp]
00007d3d957d8a9c  mov esi, 0x00
00007d3d957d8aa1  mov rax, 0x56C27CB8A530
00007d3d957d8aab  call rax
00007d3d957d8aad  movaps xmm14, [rsp]
00007d3d957d8ab2  add rsp, 0x30
00007d3d957d8ab6  vmovaps xmm0, [rsp]
00007d3d957d8abb  vmovaps xmm1, [rsp+0x10]
00007d3d957d8ac1  vmovaps xmm2, [rsp+0x20]
00007d3d957d8ac7  vmovaps xmm3, [rsp+0x30]
00007d3d957d8acd  vmovaps xmm4, [rsp+0x40]
00007d3d957d8ad3  vmovaps xmm5, [rsp+0x50]
00007d3d957d8ad9  vmovaps xmm6, [rsp+0x60]
00007d3d957d8adf  vmovaps xmm7, [rsp+0x70]
00007d3d957d8ae5  vmovaps xmm8, [rsp+0x80]
00007d3d957d8aee  vmovaps xmm9, [rsp+0x90]
00007d3d957d8af7  vmovaps xmm10, [rsp+0xA0]
00007d3d957d8b00  vmovaps xmm11, [rsp+0xB0]
00007d3d957d8b09  vmovaps xmm12, [rsp+0xC0]
00007d3d957d8b12  vmovaps xmm13, [rsp+0xD0]
00007d3d957d8b1b  vmovaps xmm15, [rsp+0xE0]
00007d3d957d8b24  add rsp, 0xF0
00007d3d957d8b2b  pop r11
00007d3d957d8b2d  pop r10
00007d3d957d8b2f  pop r9
00007d3d957d8b31  pop r8
00007d3d957d8b33  pop rsi
00007d3d957d8b34  pop rdi
00007d3d957d8b35  pop rdx
00007d3d957d8b36  pop rcx
00007d3d957d8b37  pop rax
00007d3d957d8b38  add rsp, 0x08
00007d3d957d8b3c  jmp 0x00007D3D957D611D
00007d3d957d8b41  sub rsp, 0x08
00007d3d957d8b45  push rax
00007d3d957d8b46  push rcx
00007d3d957d8b47  push rdx
00007d3d957d8b48  push rdi
00007d3d957d8b49  push rsi
00007d3d957d8b4a  push r8
00007d3d957d8b4c  push r9
00007d3d957d8b4e  push r10
00007d3d957d8b50  push r11
00007d3d957d8b52  sub rsp, 0xF0
00007d3d957d8b59  vmovaps [rsp], xmm0
00007d3d957d8b5e  vmovaps [rsp+0x10], xmm2
00007d3d957d8b64  vmovaps [rsp+0x20], xmm3
00007d3d957d8b6a  vmovaps [rsp+0x30], xmm4
00007d3d957d8b70  vmovaps [rsp+0x40], xmm5
00007d3d957d8b76  vmovaps [rsp+0x50], xmm6
00007d3d957d8b7c  vmovaps [rsp+0x60], xmm7
00007d3d957d8b82  vmovaps [rsp+0x70], xmm8
00007d3d957d8b88  vmovaps [rsp+0x80], xmm9
00007d3d957d8b91  vmovaps [rsp+0x90], xmm10
00007d3d957d8b9a  vmovaps [rsp+0xA0], xmm11
00007d3d957d8ba3  vmovaps [rsp+0xB0], xmm12
00007d3d957d8bac  vmovaps [rsp+0xC0], xmm13
00007d3d957d8bb5  vmovaps [rsp+0xD0], xmm14
00007d3d957d8bbe  vmovaps [rsp+0xE0], xmm15
00007d3d957d8bc7  sub rsp, 0x30
00007d3d957d8bcb  movaps [rsp], xmm1
00007d3d957d8bcf  movaps [rsp+0x10], xmm4
00007d3d957d8bd4  movaps [rsp+0x20], xmm9
00007d3d957d8bda  lea rdi, [rsp]
00007d3d957d8bde  mov esi, 0x00
00007d3d957d8be3  mov rax, 0x56C27CB8A530
00007d3d957d8bed  call rax
00007d3d957d8bef  movaps xmm1, [rsp]
00007d3d957d8bf3  add rsp, 0x30
00007d3d957d8bf7  vmovaps xmm0, [rsp]
00007d3d957d8bfc  vmovaps xmm2, [rsp+0x10]
00007d3d957d8c02  vmovaps xmm3, [rsp+0x20]
00007d3d957d8c08  vmovaps xmm4, [rsp+0x30]
00007d3d957d8c0e  vmovaps xmm5, [rsp+0x40]
00007d3d957d8c14  vmovaps xmm6, [rsp+0x50]
00007d3d957d8c1a  vmovaps xmm7, [rsp+0x60]
00007d3d957d8c20  vmovaps xmm8, [rsp+0x70]
00007d3d957d8c26  vmovaps xmm9, [rsp+0x80]
00007d3d957d8c2f  vmovaps xmm10, [rsp+0x90]
00007d3d957d8c38  vmovaps xmm11, [rsp+0xA0]
00007d3d957d8c41  vmovaps xmm12, [rsp+0xB0]
00007d3d957d8c4a  vmovaps xmm13, [rsp+0xC0]
00007d3d957d8c53  vmovaps xmm14, [rsp+0xD0]
00007d3d957d8c5c  vmovaps xmm15, [rsp+0xE0]
00007d3d957d8c65  add rsp, 0xF0
00007d3d957d8c6c  pop r11
00007d3d957d8c6e  pop r10
00007d3d957d8c70  pop r9
00007d3d957d8c72  pop r8
00007d3d957d8c74  pop rsi
00007d3d957d8c75  pop rdi
00007d3d957d8c76  pop rdx
00007d3d957d8c77  pop rcx
00007d3d957d8c78  pop rax
00007d3d957d8c79  add rsp, 0x08
00007d3d957d8c7d  jmp 0x00007D3D957D613B
00007d3d957d8c82  sub rsp, 0x08
00007d3d957d8c86  push rax
00007d3d957d8c87  push rcx
00007d3d957d8c88  push rdx
00007d3d957d8c89  push rdi
00007d3d957d8c8a  push rsi
00007d3d957d8c8b  push r8
00007d3d957d8c8d  push r9
00007d3d957d8c8f  push r10
00007d3d957d8c91  push r11
00007d3d957d8c93  sub rsp, 0xF0
00007d3d957d8c9a  vmovaps [rsp], xmm0
00007d3d957d8c9f  vmovaps [rsp+0x10], xmm1
00007d3d957d8ca5  vmovaps [rsp+0x20], xmm2
00007d3d957d8cab  vmovaps [rsp+0x30], xmm3
00007d3d957d8cb1  vmovaps [rsp+0x40], xmm5
00007d3d957d8cb7  vmovaps [rsp+0x50], xmm6
00007d3d957d8cbd  vmovaps [rsp+0x60], xmm7
00007d3d957d8cc3  vmovaps [rsp+0x70], xmm8
00007d3d957d8cc9  vmovaps [rsp+0x80], xmm9
00007d3d957d8cd2  vmovaps [rsp+0x90], xmm10
00007d3d957d8cdb  vmovaps [rsp+0xA0], xmm11
00007d3d957d8ce4  vmovaps [rsp+0xB0], xmm12
00007d3d957d8ced  vmovaps [rsp+0xC0], xmm13
00007d3d957d8cf6  vmovaps [rsp+0xD0], xmm14
00007d3d957d8cff  vmovaps [rsp+0xE0], xmm15
00007d3d957d8d08  sub rsp, 0x30
00007d3d957d8d0c  movaps [rsp], xmm4
00007d3d957d8d10  movaps [rsp+0x10], xmm2
00007d3d957d8d15  movaps [rsp+0x20], xmm9
00007d3d957d8d1b  lea rdi, [rsp]
00007d3d957d8d1f  mov esi, 0x00
00007d3d957d8d24  mov rax, 0x56C27CB8A530
00007d3d957d8d2e  call rax
00007d3d957d8d30  movaps xmm4, [rsp]
00007d3d957d8d34  add rsp, 0x30
00007d3d957d8d38  vmovaps xmm0, [rsp]
00007d3d957d8d3d  vmovaps xmm1, [rsp+0x10]
00007d3d957d8d43  vmovaps xmm2, [rsp+0x20]
00007d3d957d8d49  vmovaps xmm3, [rsp+0x30]
00007d3d957d8d4f  vmovaps xmm5, [rsp+0x40]
00007d3d957d8d55  vmovaps xmm6, [rsp+0x50]
00007d3d957d8d5b  vmovaps xmm7, [rsp+0x60]
00007d3d957d8d61  vmovaps xmm8, [rsp+0x70]
00007d3d957d8d67  vmovaps xmm9, [rsp+0x80]
00007d3d957d8d70  vmovaps xmm10, [rsp+0x90]
00007d3d957d8d79  vmovaps xmm11, [rsp+0xA0]
00007d3d957d8d82  vmovaps xmm12, [rsp+0xB0]
00007d3d957d8d8b  vmovaps xmm13, [rsp+0xC0]
00007d3d957d8d94  vmovaps xmm14, [rsp+0xD0]
00007d3d957d8d9d  vmovaps xmm15, [rsp+0xE0]
00007d3d957d8da6  add rsp, 0xF0
00007d3d957d8dad  pop r11
00007d3d957d8daf  pop r10
00007d3d957d8db1  pop r9
00007d3d957d8db3  pop r8
00007d3d957d8db5  pop rsi
00007d3d957d8db6  pop rdi
00007d3d957d8db7  pop rdx
00007d3d957d8db8  pop rcx
00007d3d957d8db9  pop rax
00007d3d957d8dba  add rsp, 0x08
00007d3d957d8dbe  jmp 0x00007D3D957D616B
00007d3d957d8dc3  sub rsp, 0x08
00007d3d957d8dc7  push rax
00007d3d957d8dc8  push rcx
00007d3d957d8dc9  push rdx
00007d3d957d8dca  push rdi
00007d3d957d8dcb  push rsi
00007d3d957d8dcc  push r8
00007d3d957d8dce  push r9
00007d3d957d8dd0  push r10
00007d3d957d8dd2  push r11
00007d3d957d8dd4  sub rsp, 0xF0
00007d3d957d8ddb  vmovaps [rsp], xmm0
00007d3d957d8de0  vmovaps [rsp+0x10], xmm1
00007d3d957d8de6  vmovaps [rsp+0x20], xmm2
00007d3d957d8dec  vmovaps [rsp+0x30], xmm3
00007d3d957d8df2  vmovaps [rsp+0x40], xmm4
00007d3d957d8df8  vmovaps [rsp+0x50], xmm5
00007d3d957d8dfe  vmovaps [rsp+0x60], xmm6
00007d3d957d8e04  vmovaps [rsp+0x70], xmm7
00007d3d957d8e0a  vmovaps [rsp+0x80], xmm8
00007d3d957d8e13  vmovaps [rsp+0x90], xmm10
00007d3d957d8e1c  vmovaps [rsp+0xA0], xmm11
00007d3d957d8e25  vmovaps [rsp+0xB0], xmm12
00007d3d957d8e2e  vmovaps [rsp+0xC0], xmm13
00007d3d957d8e37  vmovaps [rsp+0xD0], xmm14
00007d3d957d8e40  vmovaps [rsp+0xE0], xmm15
00007d3d957d8e49  sub rsp, 0x30
00007d3d957d8e4d  movaps [rsp], xmm9
00007d3d957d8e52  movaps [rsp+0x10], xmm2
00007d3d957d8e57  movaps [rsp+0x20], xmm1
00007d3d957d8e5c  lea rdi, [rsp]
00007d3d957d8e60  mov esi, 0x00
00007d3d957d8e65  mov rax, 0x56C27CB8A530
00007d3d957d8e6f  call rax
00007d3d957d8e71  movaps xmm9, [rsp]
00007d3d957d8e76  add rsp, 0x30
00007d3d957d8e7a  vmovaps xmm0, [rsp]
00007d3d957d8e7f  vmovaps xmm1, [rsp+0x10]
00007d3d957d8e85  vmovaps xmm2, [rsp+0x20]
00007d3d957d8e8b  vmovaps xmm3, [rsp+0x30]
00007d3d957d8e91  vmovaps xmm4, [rsp+0x40]
00007d3d957d8e97  vmovaps xmm5, [rsp+0x50]
00007d3d957d8e9d  vmovaps xmm6, [rsp+0x60]
00007d3d957d8ea3  vmovaps xmm7, [rsp+0x70]
00007d3d957d8ea9  vmovaps xmm8, [rsp+0x80]
00007d3d957d8eb2  vmovaps xmm10, [rsp+0x90]
00007d3d957d8ebb  vmovaps xmm11, [rsp+0xA0]
00007d3d957d8ec4  vmovaps xmm12, [rsp+0xB0]
00007d3d957d8ecd  vmovaps xmm13, [rsp+0xC0]
00007d3d957d8ed6  vmovaps xmm14, [rsp+0xD0]
00007d3d957d8edf  vmovaps xmm15, [rsp+0xE0]
00007d3d957d8ee8  add rsp, 0xF0
00007d3d957d8eef  pop r11
00007d3d957d8ef1  pop r10
00007d3d957d8ef3  pop r9
00007d3d957d8ef5  pop r8
00007d3d957d8ef7  pop rsi
00007d3d957d8ef8  pop rdi
00007d3d957d8ef9  pop rdx
00007d3d957d8efa  pop rcx
00007d3d957d8efb  pop rax
00007d3d957d8efc  add rsp, 0x08
00007d3d957d8f00  jmp 0x00007D3D957D61A1
00007d3d957d8f05  sub rsp, 0x08
00007d3d957d8f09  push rax
00007d3d957d8f0a  push rcx
00007d3d957d8f0b  push rdx
00007d3d957d8f0c  push rdi
00007d3d957d8f0d  push rsi
00007d3d957d8f0e  push r8
00007d3d957d8f10  push r9
00007d3d957d8f12  push r10
00007d3d957d8f14  push r11
00007d3d957d8f16  sub rsp, 0xF0
00007d3d957d8f1d  vmovaps [rsp], xmm0
00007d3d957d8f22  vmovaps [rsp+0x10], xmm2
00007d3d957d8f28  vmovaps [rsp+0x20], xmm3
00007d3d957d8f2e  vmovaps [rsp+0x30], xmm4
00007d3d957d8f34  vmovaps [rsp+0x40], xmm5
00007d3d957d8f3a  vmovaps [rsp+0x50], xmm6
00007d3d957d8f40  vmovaps [rsp+0x60], xmm7
00007d3d957d8f46  vmovaps [rsp+0x70], xmm8
00007d3d957d8f4c  vmovaps [rsp+0x80], xmm9
00007d3d957d8f55  vmovaps [rsp+0x90], xmm10
00007d3d957d8f5e  vmovaps [rsp+0xA0], xmm11
00007d3d957d8f67  vmovaps [rsp+0xB0], xmm12
00007d3d957d8f70  vmovaps [rsp+0xC0], xmm13
00007d3d957d8f79  vmovaps [rsp+0xD0], xmm14
00007d3d957d8f82  vmovaps [rsp+0xE0], xmm15
00007d3d957d8f8b  sub rsp, 0x30
00007d3d957d8f8f  movaps [rsp], xmm1
00007d3d957d8f93  movaps [rsp+0x10], xmm15
00007d3d957d8f99  movaps [rsp+0x20], xmm6
00007d3d957d8f9e  lea rdi, [rsp]
00007d3d957d8fa2  mov esi, 0x00
00007d3d957d8fa7  mov rax, 0x56C27CB8A530
00007d3d957d8fb1  call rax
00007d3d957d8fb3  movaps xmm1, [rsp]
00007d3d957d8fb7  add rsp, 0x30
00007d3d957d8fbb  vmovaps xmm0, [rsp]
00007d3d957d8fc0  vmovaps xmm2, [rsp+0x10]
00007d3d957d8fc6  vmovaps xmm3, [rsp+0x20]
00007d3d957d8fcc  vmovaps xmm4, [rsp+0x30]
00007d3d957d8fd2  vmovaps xmm5, [rsp+0x40]
00007d3d957d8fd8  vmovaps xmm6, [rsp+0x50]
00007d3d957d8fde  vmovaps xmm7, [rsp+0x60]
00007d3d957d8fe4  vmovaps xmm8, [rsp+0x70]
00007d3d957d8fea  vmovaps xmm9, [rsp+0x80]
00007d3d957d8ff3  vmovaps xmm10, [rsp+0x90]
00007d3d957d8ffc  vmovaps xmm11, [rsp+0xA0]
00007d3d957d9005  vmovaps xmm12, [rsp+0xB0]
00007d3d957d900e  vmovaps xmm13, [rsp+0xC0]
00007d3d957d9017  vmovaps xmm14, [rsp+0xD0]
00007d3d957d9020  vmovaps xmm15, [rsp+0xE0]
00007d3d957d9029  add rsp, 0xF0
00007d3d957d9030  pop r11
00007d3d957d9032  pop r10
00007d3d957d9034  pop r9
00007d3d957d9036  pop r8
00007d3d957d9038  pop rsi
00007d3d957d9039  pop rdi
00007d3d957d903a  pop rdx
00007d3d957d903b  pop rcx
00007d3d957d903c  pop rax
00007d3d957d903d  add rsp, 0x08
00007d3d957d9041  jmp 0x00007D3D957D61C2
00007d3d957d9046  sub rsp, 0x08
00007d3d957d904a  push rax
00007d3d957d904b  push rcx
00007d3d957d904c  push rdx
00007d3d957d904d  push rdi
00007d3d957d904e  push rsi
00007d3d957d904f  push r8
00007d3d957d9051  push r9
00007d3d957d9053  push r10
00007d3d957d9055  push r11
00007d3d957d9057  sub rsp, 0xF0
00007d3d957d905e  vmovaps [rsp], xmm0
00007d3d957d9063  vmovaps [rsp+0x10], xmm1
00007d3d957d9069  vmovaps [rsp+0x20], xmm2
00007d3d957d906f  vmovaps [rsp+0x30], xmm3
00007d3d957d9075  vmovaps [rsp+0x40], xmm4
00007d3d957d907b  vmovaps [rsp+0x50], xmm5
00007d3d957d9081  vmovaps [rsp+0x60], xmm6
00007d3d957d9087  vmovaps [rsp+0x70], xmm7
00007d3d957d908d  vmovaps [rsp+0x80], xmm8
00007d3d957d9096  vmovaps [rsp+0x90], xmm9
00007d3d957d909f  vmovaps [rsp+0xA0], xmm10
00007d3d957d90a8  vmovaps [rsp+0xB0], xmm11
00007d3d957d90b1  vmovaps [rsp+0xC0], xmm12
00007d3d957d90ba  vmovaps [rsp+0xD0], xmm13
00007d3d957d90c3  vmovaps [rsp+0xE0], xmm14
00007d3d957d90cc  sub rsp, 0x30
00007d3d957d90d0  movaps [rsp], xmm15
00007d3d957d90d5  movaps [rsp+0x10], xmm5
00007d3d957d90da  movaps [rsp+0x20], xmm3
00007d3d957d90df  lea rdi, [rsp]
00007d3d957d90e3  mov esi, 0x00
00007d3d957d90e8  mov rax, 0x56C27CB8A530
00007d3d957d90f2  call rax
00007d3d957d90f4  movaps xmm15, [rsp]
00007d3d957d90f9  add rsp, 0x30
00007d3d957d90fd  vmovaps xmm0, [rsp]
00007d3d957d9102  vmovaps xmm1, [rsp+0x10]
00007d3d957d9108  vmovaps xmm2, [rsp+0x20]
00007d3d957d910e  vmovaps xmm3, [rsp+0x30]
00007d3d957d9114  vmovaps xmm4, [rsp+0x40]
00007d3d957d911a  vmovaps xmm5, [rsp+0x50]
00007d3d957d9120  vmovaps xmm6, [rsp+0x60]
00007d3d957d9126  vmovaps xmm7, [rsp+0x70]
00007d3d957d912c  vmovaps xmm8, [rsp+0x80]
00007d3d957d9135  vmovaps xmm9, [rsp+0x90]
00007d3d957d913e  vmovaps xmm10, [rsp+0xA0]
00007d3d957d9147  vmovaps xmm11, [rsp+0xB0]
00007d3d957d9150  vmovaps xmm12, [rsp+0xC0]
00007d3d957d9159  vmovaps xmm13, [rsp+0xD0]
00007d3d957d9162  vmovaps xmm14, [rsp+0xE0]
00007d3d957d916b  add rsp, 0xF0
00007d3d957d9172  pop r11
00007d3d957d9174  pop r10
00007d3d957d9176  pop r9
00007d3d957d9178  pop r8
00007d3d957d917a  pop rsi
00007d3d957d917b  pop rdi
00007d3d957d917c  pop rdx
00007d3d957d917d  pop rcx
00007d3d957d917e  pop rax
00007d3d957d917f  add rsp, 0x08
00007d3d957d9183  jmp 0x00007D3D957D61DC
00007d3d957d9188  sub rsp, 0x08
00007d3d957d918c  push rax
00007d3d957d918d  push rcx
00007d3d957d918e  push rdx
00007d3d957d918f  push rdi
00007d3d957d9190  push rsi
00007d3d957d9191  push r8
00007d3d957d9193  push r9
00007d3d957d9195  push r10
00007d3d957d9197  push r11
00007d3d957d9199  sub rsp, 0xF0
00007d3d957d91a0  vmovaps [rsp], xmm0
00007d3d957d91a5  vmovaps [rsp+0x10], xmm1
00007d3d957d91ab  vmovaps [rsp+0x20], xmm2
00007d3d957d91b1  vmovaps [rsp+0x30], xmm3
00007d3d957d91b7  vmovaps [rsp+0x40], xmm4
00007d3d957d91bd  vmovaps [rsp+0x50], xmm6
00007d3d957d91c3  vmovaps [rsp+0x60], xmm7
00007d3d957d91c9  vmovaps [rsp+0x70], xmm8
00007d3d957d91cf  vmovaps [rsp+0x80], xmm9
00007d3d957d91d8  vmovaps [rsp+0x90], xmm10
00007d3d957d91e1  vmovaps [rsp+0xA0], xmm11
00007d3d957d91ea  vmovaps [rsp+0xB0], xmm12
00007d3d957d91f3  vmovaps [rsp+0xC0], xmm13
00007d3d957d91fc  vmovaps [rsp+0xD0], xmm14
00007d3d957d9205  vmovaps [rsp+0xE0], xmm15
00007d3d957d920e  sub rsp, 0x30
00007d3d957d9212  movaps [rsp], xmm5
00007d3d957d9216  movaps [rsp+0x10], xmm8
00007d3d957d921c  movaps [rsp+0x20], xmm6
00007d3d957d9221  lea rdi, [rsp]
00007d3d957d9225  mov esi, 0x00
00007d3d957d922a  mov rax, 0x56C27CB8A530
00007d3d957d9234  call rax
00007d3d957d9236  movaps xmm5, [rsp]
00007d3d957d923a  add rsp, 0x30
00007d3d957d923e  vmovaps xmm0, [rsp]
00007d3d957d9243  vmovaps xmm1, [rsp+0x10]
00007d3d957d9249  vmovaps xmm2, [rsp+0x20]
00007d3d957d924f  vmovaps xmm3, [rsp+0x30]
00007d3d957d9255  vmovaps xmm4, [rsp+0x40]
00007d3d957d925b  vmovaps xmm6, [rsp+0x50]
00007d3d957d9261  vmovaps xmm7, [rsp+0x60]
00007d3d957d9267  vmovaps xmm8, [rsp+0x70]
00007d3d957d926d  vmovaps xmm9, [rsp+0x80]
00007d3d957d9276  vmovaps xmm10, [rsp+0x90]
00007d3d957d927f  vmovaps xmm11, [rsp+0xA0]
00007d3d957d9288  vmovaps xmm12, [rsp+0xB0]
00007d3d957d9291  vmovaps xmm13, [rsp+0xC0]
00007d3d957d929a  vmovaps xmm14, [rsp+0xD0]
00007d3d957d92a3  vmovaps xmm15, [rsp+0xE0]
00007d3d957d92ac  add rsp, 0xF0
00007d3d957d92b3  pop r11
00007d3d957d92b5  pop r10
00007d3d957d92b7  pop r9
00007d3d957d92b9  pop r8
00007d3d957d92bb  pop rsi
00007d3d957d92bc  pop rdi
00007d3d957d92bd  pop rdx
00007d3d957d92be  pop rcx
00007d3d957d92bf  pop rax
00007d3d957d92c0  add rsp, 0x08
00007d3d957d92c4  jmp 0x00007D3D957D6200
00007d3d957d92c9  sub rsp, 0x08
00007d3d957d92cd  push rax
00007d3d957d92ce  push rcx
00007d3d957d92cf  push rdx
00007d3d957d92d0  push rdi
00007d3d957d92d1  push rsi
00007d3d957d92d2  push r8
00007d3d957d92d4  push r9
00007d3d957d92d6  push r10
00007d3d957d92d8  push r11
00007d3d957d92da  sub rsp, 0xF0
00007d3d957d92e1  vmovaps [rsp], xmm0
00007d3d957d92e6  vmovaps [rsp+0x10], xmm1
00007d3d957d92ec  vmovaps [rsp+0x20], xmm2
00007d3d957d92f2  vmovaps [rsp+0x30], xmm3
00007d3d957d92f8  vmovaps [rsp+0x40], xmm4
00007d3d957d92fe  vmovaps [rsp+0x50], xmm5
00007d3d957d9304  vmovaps [rsp+0x60], xmm7
00007d3d957d930a  vmovaps [rsp+0x70], xmm8
00007d3d957d9310  vmovaps [rsp+0x80], xmm9
00007d3d957d9319  vmovaps [rsp+0x90], xmm10
00007d3d957d9322  vmovaps [rsp+0xA0], xmm11
00007d3d957d932b  vmovaps [rsp+0xB0], xmm12
00007d3d957d9334  vmovaps [rsp+0xC0], xmm13
00007d3d957d933d  vmovaps [rsp+0xD0], xmm14
00007d3d957d9346  vmovaps [rsp+0xE0], xmm15
00007d3d957d934f  sub rsp, 0x30
00007d3d957d9353  movaps [rsp], xmm6
00007d3d957d9357  movaps [rsp+0x10], xmm10
00007d3d957d935d  movaps [rsp+0x20], xmm8
00007d3d957d9363  lea rdi, [rsp]
00007d3d957d9367  mov esi, 0x00
00007d3d957d936c  mov rax, 0x56C27CB8A530
00007d3d957d9376  call rax
00007d3d957d9378  movaps xmm6, [rsp]
00007d3d957d937c  add rsp, 0x30
00007d3d957d9380  vmovaps xmm0, [rsp]
00007d3d957d9385  vmovaps xmm1, [rsp+0x10]
00007d3d957d938b  vmovaps xmm2, [rsp+0x20]
00007d3d957d9391  vmovaps xmm3, [rsp+0x30]
00007d3d957d9397  vmovaps xmm4, [rsp+0x40]
00007d3d957d939d  vmovaps xmm5, [rsp+0x50]
00007d3d957d93a3  vmovaps xmm7, [rsp+0x60]
00007d3d957d93a9  vmovaps xmm8, [rsp+0x70]
00007d3d957d93af  vmovaps xmm9, [rsp+0x80]
00007d3d957d93b8  vmovaps xmm10, [rsp+0x90]
00007d3d957d93c1  vmovaps xmm11, [rsp+0xA0]
00007d3d957d93ca  vmovaps xmm12, [rsp+0xB0]
00007d3d957d93d3  vmovaps xmm13, [rsp+0xC0]
00007d3d957d93dc  vmovaps xmm14, [rsp+0xD0]
00007d3d957d93e5  vmovaps xmm15, [rsp+0xE0]
00007d3d957d93ee  add rsp, 0xF0
00007d3d957d93f5  pop r11
00007d3d957d93f7  pop r10
00007d3d957d93f9  pop r9
00007d3d957d93fb  pop r8
00007d3d957d93fd  pop rsi
00007d3d957d93fe  pop rdi
00007d3d957d93ff  pop rdx
00007d3d957d9400  pop rcx
00007d3d957d9401  pop rax
00007d3d957d9402  add rsp, 0x08
00007d3d957d9406  jmp 0x00007D3D957D6225
00007d3d957d940b  sub rsp, 0x08
00007d3d957d940f  push rax
00007d3d957d9410  push rcx
00007d3d957d9411  push rdx
00007d3d957d9412  push rdi
00007d3d957d9413  push rsi
00007d3d957d9414  push r8
00007d3d957d9416  push r9
00007d3d957d9418  push r10
00007d3d957d941a  push r11
00007d3d957d941c  sub rsp, 0xF0
00007d3d957d9423  vmovaps [rsp], xmm0
00007d3d957d9428  vmovaps [rsp+0x10], xmm1
00007d3d957d942e  vmovaps [rsp+0x20], xmm2
00007d3d957d9434  vmovaps [rsp+0x30], xmm3
00007d3d957d943a  vmovaps [rsp+0x40], xmm4
00007d3d957d9440  vmovaps [rsp+0x50], xmm5
00007d3d957d9446  vmovaps [rsp+0x60], xmm6
00007d3d957d944c  vmovaps [rsp+0x70], xmm7
00007d3d957d9452  vmovaps [rsp+0x80], xmm8
00007d3d957d945b  vmovaps [rsp+0x90], xmm9
00007d3d957d9464  vmovaps [rsp+0xA0], xmm11
00007d3d957d946d  vmovaps [rsp+0xB0], xmm12
00007d3d957d9476  vmovaps [rsp+0xC0], xmm13
00007d3d957d947f  vmovaps [rsp+0xD0], xmm14
00007d3d957d9488  vmovaps [rsp+0xE0], xmm15
00007d3d957d9491  sub rsp, 0x30
00007d3d957d9495  movaps [rsp], xmm10
00007d3d957d949a  movaps [rsp+0x10], xmm8
00007d3d957d94a0  movaps [rsp+0x20], xmm14
00007d3d957d94a6  lea rdi, [rsp]
00007d3d957d94aa  mov esi, 0x00
00007d3d957d94af  mov rax, 0x56C27CB8A530
00007d3d957d94b9  call rax
00007d3d957d94bb  movaps xmm10, [rsp]
00007d3d957d94c0  add rsp, 0x30
00007d3d957d94c4  vmovaps xmm0, [rsp]
00007d3d957d94c9  vmovaps xmm1, [rsp+0x10]
00007d3d957d94cf  vmovaps xmm2, [rsp+0x20]
00007d3d957d94d5  vmovaps xmm3, [rsp+0x30]
00007d3d957d94db  vmovaps xmm4, [rsp+0x40]
00007d3d957d94e1  vmovaps xmm5, [rsp+0x50]
00007d3d957d94e7  vmovaps xmm6, [rsp+0x60]
00007d3d957d94ed  vmovaps xmm7, [rsp+0x70]
00007d3d957d94f3  vmovaps xmm8, [rsp+0x80]
00007d3d957d94fc  vmovaps xmm9, [rsp+0x90]
00007d3d957d9505  vmovaps xmm11, [rsp+0xA0]
00007d3d957d950e  vmovaps xmm12, [rsp+0xB0]
00007d3d957d9517  vmovaps xmm13, [rsp+0xC0]
00007d3d957d9520  vmovaps xmm14, [rsp+0xD0]
00007d3d957d9529  vmovaps xmm15, [rsp+0xE0]
00007d3d957d9532  add rsp, 0xF0
00007d3d957d9539  pop r11
00007d3d957d953b  pop r10
00007d3d957d953d  pop r9
00007d3d957d953f  pop r8
00007d3d957d9541  pop rsi
00007d3d957d9542  pop rdi
00007d3d957d9543  pop rdx
00007d3d957d9544  pop rcx
00007d3d957d9545  pop rax
00007d3d957d9546  add rsp, 0x08
00007d3d957d954a  jmp 0x00007D3D957D6245
00007d3d957d954f  sub rsp, 0x08
00007d3d957d9553  push rax
00007d3d957d9554  push rcx
00007d3d957d9555  push rdx
00007d3d957d9556  push rdi
00007d3d957d9557  push rsi
00007d3d957d9558  push r8
00007d3d957d955a  push r9
00007d3d957d955c  push r10
00007d3d957d955e  push r11
00007d3d957d9560  sub rsp, 0xF0
00007d3d957d9567  vmovaps [rsp], xmm0
00007d3d957d956c  vmovaps [rsp+0x10], xmm1
00007d3d957d9572  vmovaps [rsp+0x20], xmm2
00007d3d957d9578  vmovaps [rsp+0x30], xmm3
00007d3d957d957e  vmovaps [rsp+0x40], xmm4
00007d3d957d9584  vmovaps [rsp+0x50], xmm5
00007d3d957d958a  vmovaps [rsp+0x60], xmm6
00007d3d957d9590  vmovaps [rsp+0x70], xmm7
00007d3d957d9596  vmovaps [rsp+0x80], xmm8
00007d3d957d959f  vmovaps [rsp+0x90], xmm9
00007d3d957d95a8  vmovaps [rsp+0xA0], xmm10
00007d3d957d95b1  vmovaps [rsp+0xB0], xmm11
00007d3d957d95ba  vmovaps [rsp+0xC0], xmm12
00007d3d957d95c3  vmovaps [rsp+0xD0], xmm13
00007d3d957d95cc  vmovaps [rsp+0xE0], xmm15
00007d3d957d95d5  sub rsp, 0x30
00007d3d957d95d9  movaps [rsp], xmm14
00007d3d957d95de  movaps [rsp+0x10], xmm8
00007d3d957d95e4  movaps [rsp+0x20], xmm4
00007d3d957d95e9  lea rdi, [rsp]
00007d3d957d95ed  mov esi, 0x00
00007d3d957d95f2  mov rax, 0x56C27CB8A530
00007d3d957d95fc  call rax
00007d3d957d95fe  movaps xmm14, [rsp]
00007d3d957d9603  add rsp, 0x30
00007d3d957d9607  vmovaps xmm0, [rsp]
00007d3d957d960c  vmovaps xmm1, [rsp+0x10]
00007d3d957d9612  vmovaps xmm2, [rsp+0x20]
00007d3d957d9618  vmovaps xmm3, [rsp+0x30]
00007d3d957d961e  vmovaps xmm4, [rsp+0x40]
00007d3d957d9624  vmovaps xmm5, [rsp+0x50]
00007d3d957d962a  vmovaps xmm6, [rsp+0x60]
00007d3d957d9630  vmovaps xmm7, [rsp+0x70]
00007d3d957d9636  vmovaps xmm8, [rsp+0x80]
00007d3d957d963f  vmovaps xmm9, [rsp+0x90]
00007d3d957d9648  vmovaps xmm10, [rsp+0xA0]
00007d3d957d9651  vmovaps xmm11, [rsp+0xB0]
00007d3d957d965a  vmovaps xmm12, [rsp+0xC0]
00007d3d957d9663  vmovaps xmm13, [rsp+0xD0]
00007d3d957d966c  vmovaps xmm15, [rsp+0xE0]
00007d3d957d9675  add rsp, 0xF0
00007d3d957d967c  pop r11
00007d3d957d967e  pop r10
00007d3d957d9680  pop r9
00007d3d957d9682  pop r8
00007d3d957d9684  pop rsi
00007d3d957d9685  pop rdi
00007d3d957d9686  pop rdx
00007d3d957d9687  pop rcx
00007d3d957d9688  pop rax
00007d3d957d9689  add rsp, 0x08
00007d3d957d968d  jmp 0x00007D3D957D6265
00007d3d957d9692  sub rsp, 0x08
00007d3d957d9696  push rax
00007d3d957d9697  push rcx
00007d3d957d9698  push rdx
00007d3d957d9699  push rdi
00007d3d957d969a  push rsi
00007d3d957d969b  push r8
00007d3d957d969d  push r9
00007d3d957d969f  push r10
00007d3d957d96a1  push r11
00007d3d957d96a3  sub rsp, 0xF0
00007d3d957d96aa  vmovaps [rsp], xmm0
00007d3d957d96af  vmovaps [rsp+0x10], xmm1
00007d3d957d96b5  vmovaps [rsp+0x20], xmm2
00007d3d957d96bb  vmovaps [rsp+0x30], xmm3
00007d3d957d96c1  vmovaps [rsp+0x40], xmm5
00007d3d957d96c7  vmovaps [rsp+0x50], xmm6
00007d3d957d96cd  vmovaps [rsp+0x60], xmm7
00007d3d957d96d3  vmovaps [rsp+0x70], xmm8
00007d3d957d96d9  vmovaps [rsp+0x80], xmm9
00007d3d957d96e2  vmovaps [rsp+0x90], xmm10
00007d3d957d96eb  vmovaps [rsp+0xA0], xmm11
00007d3d957d96f4  vmovaps [rsp+0xB0], xmm12
00007d3d957d96fd  vmovaps [rsp+0xC0], xmm13
00007d3d957d9706  vmovaps [rsp+0xD0], xmm14
00007d3d957d970f  vmovaps [rsp+0xE0], xmm15
00007d3d957d9718  sub rsp, 0x30
00007d3d957d971c  movaps [rsp], xmm4
00007d3d957d9720  movaps [rsp+0x10], xmm13
00007d3d957d9726  movaps [rsp+0x20], xmm8
00007d3d957d972c  lea rdi, [rsp]
00007d3d957d9730  mov esi, 0x00
00007d3d957d9735  mov rax, 0x56C27CB8A530
00007d3d957d973f  call rax
00007d3d957d9741  movaps xmm4, [rsp]
00007d3d957d9745  add rsp, 0x30
00007d3d957d9749  vmovaps xmm0, [rsp]
00007d3d957d974e  vmovaps xmm1, [rsp+0x10]
00007d3d957d9754  vmovaps xmm2, [rsp+0x20]
00007d3d957d975a  vmovaps xmm3, [rsp+0x30]
00007d3d957d9760  vmovaps xmm5, [rsp+0x40]
00007d3d957d9766  vmovaps xmm6, [rsp+0x50]
00007d3d957d976c  vmovaps xmm7, [rsp+0x60]
00007d3d957d9772  vmovaps xmm8, [rsp+0x70]
00007d3d957d9778  vmovaps xmm9, [rsp+0x80]
00007d3d957d9781  vmovaps xmm10, [rsp+0x90]
00007d3d957d978a  vmovaps xmm11, [rsp+0xA0]
00007d3d957d9793  vmovaps xmm12, [rsp+0xB0]
00007d3d957d979c  vmovaps xmm13, [rsp+0xC0]
00007d3d957d97a5  vmovaps xmm14, [rsp+0xD0]
00007d3d957d97ae  vmovaps xmm15, [rsp+0xE0]
00007d3d957d97b7  add rsp, 0xF0
00007d3d957d97be  pop r11
00007d3d957d97c0  pop r10
00007d3d957d97c2  pop r9
00007d3d957d97c4  pop r8
00007d3d957d97c6  pop rsi
00007d3d957d97c7  pop rdi
00007d3d957d97c8  pop rdx
00007d3d957d97c9  pop rcx
00007d3d957d97ca  pop rax
00007d3d957d97cb  add rsp, 0x08
00007d3d957d97cf  jmp 0x00007D3D957D628A
00007d3d957d97d4  sub rsp, 0x08
00007d3d957d97d8  push rax
00007d3d957d97d9  push rcx
00007d3d957d97da  push rdx
00007d3d957d97db  push rdi
00007d3d957d97dc  push rsi
00007d3d957d97dd  push r8
00007d3d957d97df  push r9
00007d3d957d97e1  push r10
00007d3d957d97e3  push r11
00007d3d957d97e5  sub rsp, 0xF0
00007d3d957d97ec  vmovaps [rsp], xmm0
00007d3d957d97f1  vmovaps [rsp+0x10], xmm1
00007d3d957d97f7  vmovaps [rsp+0x20], xmm2
00007d3d957d97fd  vmovaps [rsp+0x30], xmm3
00007d3d957d9803  vmovaps [rsp+0x40], xmm4
00007d3d957d9809  vmovaps [rsp+0x50], xmm5
00007d3d957d980f  vmovaps [rsp+0x60], xmm6
00007d3d957d9815  vmovaps [rsp+0x70], xmm7
00007d3d957d981b  vmovaps [rsp+0x80], xmm8
00007d3d957d9824  vmovaps [rsp+0x90], xmm9
00007d3d957d982d  vmovaps [rsp+0xA0], xmm10
00007d3d957d9836  vmovaps [rsp+0xB0], xmm11
00007d3d957d983f  vmovaps [rsp+0xC0], xmm12
00007d3d957d9848  vmovaps [rsp+0xD0], xmm14
00007d3d957d9851  vmovaps [rsp+0xE0], xmm15
00007d3d957d985a  sub rsp, 0x30
00007d3d957d985e  movaps [rsp], xmm13
00007d3d957d9863  movaps [rsp+0x10], xmm15
00007d3d957d9869  movaps [rsp+0x20], xmm9
00007d3d957d986f  lea rdi, [rsp]
00007d3d957d9873  mov esi, 0x00
00007d3d957d9878  mov rax, 0x56C27CB8A530
00007d3d957d9882  call rax
00007d3d957d9884  movaps xmm13, [rsp]
00007d3d957d9889  add rsp, 0x30
00007d3d957d988d  vmovaps xmm0, [rsp]
00007d3d957d9892  vmovaps xmm1, [rsp+0x10]
00007d3d957d9898  vmovaps xmm2, [rsp+0x20]
00007d3d957d989e  vmovaps xmm3, [rsp+0x30]
00007d3d957d98a4  vmovaps xmm4, [rsp+0x40]
00007d3d957d98aa  vmovaps xmm5, [rsp+0x50]
00007d3d957d98b0  vmovaps xmm6, [rsp+0x60]
00007d3d957d98b6  vmovaps xmm7, [rsp+0x70]
00007d3d957d98bc  vmovaps xmm8, [rsp+0x80]
00007d3d957d98c5  vmovaps xmm9, [rsp+0x90]
00007d3d957d98ce  vmovaps xmm10, [rsp+0xA0]
00007d3d957d98d7  vmovaps xmm11, [rsp+0xB0]
00007d3d957d98e0  vmovaps xmm12, [rsp+0xC0]
00007d3d957d98e9  vmovaps xmm14, [rsp+0xD0]
00007d3d957d98f2  vmovaps xmm15, [rsp+0xE0]
00007d3d957d98fb  add rsp, 0xF0
00007d3d957d9902  pop r11
00007d3d957d9904  pop r10
00007d3d957d9906  pop r9
00007d3d957d9908  pop r8
00007d3d957d990a  pop rsi
00007d3d957d990b  pop rdi
00007d3d957d990c  pop rdx
00007d3d957d990d  pop rcx
00007d3d957d990e  pop rax
00007d3d957d990f  add rsp, 0x08
00007d3d957d9913  jmp 0x00007D3D957D62A5
00007d3d957d9918  sub rsp, 0x08
00007d3d957d991c  push rax
00007d3d957d991d  push rcx
00007d3d957d991e  push rdx
00007d3d957d991f  push rdi
00007d3d957d9920  push rsi
00007d3d957d9921  push r8
00007d3d957d9923  push r9
00007d3d957d9925  push r10
00007d3d957d9927  push r11
00007d3d957d9929  sub rsp, 0xF0
00007d3d957d9930  vmovaps [rsp], xmm0
00007d3d957d9935  vmovaps [rsp+0x10], xmm1
00007d3d957d993b  vmovaps [rsp+0x20], xmm2
00007d3d957d9941  vmovaps [rsp+0x30], xmm3
00007d3d957d9947  vmovaps [rsp+0x40], xmm4
00007d3d957d994d  vmovaps [rsp+0x50], xmm5
00007d3d957d9953  vmovaps [rsp+0x60], xmm6
00007d3d957d9959  vmovaps [rsp+0x70], xmm7
00007d3d957d995f  vmovaps [rsp+0x80], xmm8
00007d3d957d9968  vmovaps [rsp+0x90], xmm9
00007d3d957d9971  vmovaps [rsp+0xA0], xmm10
00007d3d957d997a  vmovaps [rsp+0xB0], xmm11
00007d3d957d9983  vmovaps [rsp+0xC0], xmm12
00007d3d957d998c  vmovaps [rsp+0xD0], xmm13
00007d3d957d9995  vmovaps [rsp+0xE0], xmm14
00007d3d957d999e  sub rsp, 0x30
00007d3d957d99a2  movaps [rsp], xmm15
00007d3d957d99a7  movaps [rsp+0x10], xmm1
00007d3d957d99ac  movaps [rsp+0x20], xmm5
00007d3d957d99b1  lea rdi, [rsp]
00007d3d957d99b5  mov esi, 0x00
00007d3d957d99ba  mov rax, 0x56C27CB8A530
00007d3d957d99c4  call rax
00007d3d957d99c6  movaps xmm15, [rsp]
00007d3d957d99cb  add rsp, 0x30
00007d3d957d99cf  vmovaps xmm0, [rsp]
00007d3d957d99d4  vmovaps xmm1, [rsp+0x10]
00007d3d957d99da  vmovaps xmm2, [rsp+0x20]
00007d3d957d99e0  vmovaps xmm3, [rsp+0x30]
00007d3d957d99e6  vmovaps xmm4, [rsp+0x40]
00007d3d957d99ec  vmovaps xmm5, [rsp+0x50]
00007d3d957d99f2  vmovaps xmm6, [rsp+0x60]
00007d3d957d99f8  vmovaps xmm7, [rsp+0x70]
00007d3d957d99fe  vmovaps xmm8, [rsp+0x80]
00007d3d957d9a07  vmovaps xmm9, [rsp+0x90]
00007d3d957d9a10  vmovaps xmm10, [rsp+0xA0]
00007d3d957d9a19  vmovaps xmm11, [rsp+0xB0]
00007d3d957d9a22  vmovaps xmm12, [rsp+0xC0]
00007d3d957d9a2b  vmovaps xmm13, [rsp+0xD0]
00007d3d957d9a34  vmovaps xmm14, [rsp+0xE0]
00007d3d957d9a3d  add rsp, 0xF0
00007d3d957d9a44  pop r11
00007d3d957d9a46  pop r10
00007d3d957d9a48  pop r9
00007d3d957d9a4a  pop r8
00007d3d957d9a4c  pop rsi
00007d3d957d9a4d  pop rdi
00007d3d957d9a4e  pop rdx
00007d3d957d9a4f  pop rcx
00007d3d957d9a50  pop rax
00007d3d957d9a51  add rsp, 0x08
00007d3d957d9a55  jmp 0x00007D3D957D62C0
00007d3d957d9a5a  call 0x00007D3D956D64F0
00007d3d957d9a5f  jmp 0x00007D3D957D631B
00007d3d957d9a64  sub rsp, 0x08
00007d3d957d9a68  push rax
00007d3d957d9a69  push rcx
00007d3d957d9a6a  push rdx
00007d3d957d9a6b  push rdi
00007d3d957d9a6c  push rsi
00007d3d957d9a6d  push r8
00007d3d957d9a6f  push r9
00007d3d957d9a71  push r10
00007d3d957d9a73  push r11
00007d3d957d9a75  sub rsp, 0xF0
00007d3d957d9a7c  vmovaps [rsp], xmm0
00007d3d957d9a81  vmovaps [rsp+0x10], xmm1
00007d3d957d9a87  vmovaps [rsp+0x20], xmm2
00007d3d957d9a8d  vmovaps [rsp+0x30], xmm3
00007d3d957d9a93  vmovaps [rsp+0x40], xmm4
00007d3d957d9a99  vmovaps [rsp+0x50], xmm5
00007d3d957d9a9f  vmovaps [rsp+0x60], xmm6
00007d3d957d9aa5  vmovaps [rsp+0x70], xmm7
00007d3d957d9aab  vmovaps [rsp+0x80], xmm8
00007d3d957d9ab4  vmovaps [rsp+0x90], xmm10
00007d3d957d9abd  vmovaps [rsp+0xA0], xmm11
00007d3d957d9ac6  vmovaps [rsp+0xB0], xmm12
00007d3d957d9acf  vmovaps [rsp+0xC0], xmm13
00007d3d957d9ad8  vmovaps [rsp+0xD0], xmm14
00007d3d957d9ae1  vmovaps [rsp+0xE0], xmm15
00007d3d957d9aea  sub rsp, 0x30
00007d3d957d9aee  movaps [rsp], xmm9
00007d3d957d9af3  movaps [rsp+0x10], xmm8
00007d3d957d9af9  movaps [rsp+0x20], xmm11
00007d3d957d9aff  lea rdi, [rsp]
00007d3d957d9b03  mov esi, 0x00
00007d3d957d9b08  mov rax, 0x56C27CB8A530
00007d3d957d9b12  call rax
00007d3d957d9b14  movaps xmm9, [rsp]
00007d3d957d9b19  add rsp, 0x30
00007d3d957d9b1d  vmovaps xmm0, [rsp]
00007d3d957d9b22  vmovaps xmm1, [rsp+0x10]
00007d3d957d9b28  vmovaps xmm2, [rsp+0x20]
00007d3d957d9b2e  vmovaps xmm3, [rsp+0x30]
00007d3d957d9b34  vmovaps xmm4, [rsp+0x40]
00007d3d957d9b3a  vmovaps xmm5, [rsp+0x50]
00007d3d957d9b40  vmovaps xmm6, [rsp+0x60]
00007d3d957d9b46  vmovaps xmm7, [rsp+0x70]
00007d3d957d9b4c  vmovaps xmm8, [rsp+0x80]
00007d3d957d9b55  vmovaps xmm10, [rsp+0x90]
00007d3d957d9b5e  vmovaps xmm11, [rsp+0xA0]
00007d3d957d9b67  vmovaps xmm12, [rsp+0xB0]
00007d3d957d9b70  vmovaps xmm13, [rsp+0xC0]
00007d3d957d9b79  vmovaps xmm14, [rsp+0xD0]
00007d3d957d9b82  vmovaps xmm15, [rsp+0xE0]
00007d3d957d9b8b  add rsp, 0xF0
00007d3d957d9b92  pop r11
00007d3d957d9b94  pop r10
00007d3d957d9b96  pop r9
00007d3d957d9b98  pop r8
00007d3d957d9b9a  pop rsi
00007d3d957d9b9b  pop rdi
00007d3d957d9b9c  pop rdx
00007d3d957d9b9d  pop rcx
00007d3d957d9b9e  pop rax
00007d3d957d9b9f  add rsp, 0x08
00007d3d957d9ba3  jmp 0x00007D3D957D6352
00007d3d957d9ba8  sub rsp, 0x08
00007d3d957d9bac  push rax
00007d3d957d9bad  push rcx
00007d3d957d9bae  push rdx
00007d3d957d9baf  push rdi
00007d3d957d9bb0  push rsi
00007d3d957d9bb1  push r8
00007d3d957d9bb3  push r9
00007d3d957d9bb5  push r10
00007d3d957d9bb7  push r11
00007d3d957d9bb9  sub rsp, 0xF0
00007d3d957d9bc0  vmovaps [rsp], xmm0
00007d3d957d9bc5  vmovaps [rsp+0x10], xmm1
00007d3d957d9bcb  vmovaps [rsp+0x20], xmm2
00007d3d957d9bd1  vmovaps [rsp+0x30], xmm3
00007d3d957d9bd7  vmovaps [rsp+0x40], xmm4
00007d3d957d9bdd  vmovaps [rsp+0x50], xmm5
00007d3d957d9be3  vmovaps [rsp+0x60], xmm6
00007d3d957d9be9  vmovaps [rsp+0x70], xmm7
00007d3d957d9bef  vmovaps [rsp+0x80], xmm8
00007d3d957d9bf8  vmovaps [rsp+0x90], xmm9
00007d3d957d9c01  vmovaps [rsp+0xA0], xmm10
00007d3d957d9c0a  vmovaps [rsp+0xB0], xmm12
00007d3d957d9c13  vmovaps [rsp+0xC0], xmm13
00007d3d957d9c1c  vmovaps [rsp+0xD0], xmm14
00007d3d957d9c25  vmovaps [rsp+0xE0], xmm15
00007d3d957d9c2e  sub rsp, 0x30
00007d3d957d9c32  movaps [rsp], xmm11
00007d3d957d9c37  movaps [rsp+0x10], xmm10
00007d3d957d9c3d  movaps [rsp+0x20], xmm6
00007d3d957d9c42  lea rdi, [rsp]
00007d3d957d9c46  mov esi, 0x00
00007d3d957d9c4b  mov rax, 0x56C27CB8A530
00007d3d957d9c55  call rax
00007d3d957d9c57  movaps xmm11, [rsp]
00007d3d957d9c5c  add rsp, 0x30
00007d3d957d9c60  vmovaps xmm0, [rsp]
00007d3d957d9c65  vmovaps xmm1, [rsp+0x10]
00007d3d957d9c6b  vmovaps xmm2, [rsp+0x20]
00007d3d957d9c71  vmovaps xmm3, [rsp+0x30]
00007d3d957d9c77  vmovaps xmm4, [rsp+0x40]
00007d3d957d9c7d  vmovaps xmm5, [rsp+0x50]
00007d3d957d9c83  vmovaps xmm6, [rsp+0x60]
00007d3d957d9c89  vmovaps xmm7, [rsp+0x70]
00007d3d957d9c8f  vmovaps xmm8, [rsp+0x80]
00007d3d957d9c98  vmovaps xmm9, [rsp+0x90]
00007d3d957d9ca1  vmovaps xmm10, [rsp+0xA0]
00007d3d957d9caa  vmovaps xmm12, [rsp+0xB0]
00007d3d957d9cb3  vmovaps xmm13, [rsp+0xC0]
00007d3d957d9cbc  vmovaps xmm14, [rsp+0xD0]
00007d3d957d9cc5  vmovaps xmm15, [rsp+0xE0]
00007d3d957d9cce  add rsp, 0xF0
00007d3d957d9cd5  pop r11
00007d3d957d9cd7  pop r10
00007d3d957d9cd9  pop r9
00007d3d957d9cdb  pop r8
00007d3d957d9cdd  pop rsi
00007d3d957d9cde  pop rdi
00007d3d957d9cdf  pop rdx
00007d3d957d9ce0  pop rcx
00007d3d957d9ce1  pop rax
00007d3d957d9ce2  add rsp, 0x08
00007d3d957d9ce6  jmp 0x00007D3D957D636D
00007d3d957d9ceb  sub rsp, 0x08
00007d3d957d9cef  push rax
00007d3d957d9cf0  push rcx
00007d3d957d9cf1  push rdx
00007d3d957d9cf2  push rdi
00007d3d957d9cf3  push rsi
00007d3d957d9cf4  push r8
00007d3d957d9cf6  push r9
00007d3d957d9cf8  push r10
00007d3d957d9cfa  push r11
00007d3d957d9cfc  sub rsp, 0xF0
00007d3d957d9d03  vmovaps [rsp], xmm0
00007d3d957d9d08  vmovaps [rsp+0x10], xmm1
00007d3d957d9d0e  vmovaps [rsp+0x20], xmm2
00007d3d957d9d14  vmovaps [rsp+0x30], xmm3
00007d3d957d9d1a  vmovaps [rsp+0x40], xmm4
00007d3d957d9d20  vmovaps [rsp+0x50], xmm5
00007d3d957d9d26  vmovaps [rsp+0x60], xmm6
00007d3d957d9d2c  vmovaps [rsp+0x70], xmm7
00007d3d957d9d32  vmovaps [rsp+0x80], xmm8
00007d3d957d9d3b  vmovaps [rsp+0x90], xmm9
00007d3d957d9d44  vmovaps [rsp+0xA0], xmm11
00007d3d957d9d4d  vmovaps [rsp+0xB0], xmm12
00007d3d957d9d56  vmovaps [rsp+0xC0], xmm13
00007d3d957d9d5f  vmovaps [rsp+0xD0], xmm14
00007d3d957d9d68  vmovaps [rsp+0xE0], xmm15
00007d3d957d9d71  sub rsp, 0x30
00007d3d957d9d75  movaps [rsp], xmm10
00007d3d957d9d7a  movaps [rsp+0x10], xmm14
00007d3d957d9d80  movaps [rsp+0x20], xmm4
00007d3d957d9d85  lea rdi, [rsp]
00007d3d957d9d89  mov esi, 0x00
00007d3d957d9d8e  mov rax, 0x56C27CB8A530
00007d3d957d9d98  call rax
00007d3d957d9d9a  movaps xmm10, [rsp]
00007d3d957d9d9f  add rsp, 0x30
00007d3d957d9da3  vmovaps xmm0, [rsp]
00007d3d957d9da8  vmovaps xmm1, [rsp+0x10]
00007d3d957d9dae  vmovaps xmm2, [rsp+0x20]
00007d3d957d9db4  vmovaps xmm3, [rsp+0x30]
00007d3d957d9dba  vmovaps xmm4, [rsp+0x40]
00007d3d957d9dc0  vmovaps xmm5, [rsp+0x50]
00007d3d957d9dc6  vmovaps xmm6, [rsp+0x60]
00007d3d957d9dcc  vmovaps xmm7, [rsp+0x70]
00007d3d957d9dd2  vmovaps xmm8, [rsp+0x80]
00007d3d957d9ddb  vmovaps xmm9, [rsp+0x90]
00007d3d957d9de4  vmovaps xmm11, [rsp+0xA0]
00007d3d957d9ded  vmovaps xmm12, [rsp+0xB0]
00007d3d957d9df6  vmovaps xmm13, [rsp+0xC0]
00007d3d957d9dff  vmovaps xmm14, [rsp+0xD0]
00007d3d957d9e08  vmovaps xmm15, [rsp+0xE0]
00007d3d957d9e11  add rsp, 0xF0
00007d3d957d9e18  pop r11
00007d3d957d9e1a  pop r10
00007d3d957d9e1c  pop r9
00007d3d957d9e1e  pop r8
00007d3d957d9e20  pop rsi
00007d3d957d9e21  pop rdi
00007d3d957d9e22  pop rdx
00007d3d957d9e23  pop rcx
00007d3d957d9e24  pop rax
00007d3d957d9e25  add rsp, 0x08
00007d3d957d9e29  jmp 0x00007D3D957D6388
00007d3d957d9e2e  sub rsp, 0x08
00007d3d957d9e32  push rax
00007d3d957d9e33  push rcx
00007d3d957d9e34  push rdx
00007d3d957d9e35  push rdi
00007d3d957d9e36  push rsi
00007d3d957d9e37  push r8
00007d3d957d9e39  push r9
00007d3d957d9e3b  push r10
00007d3d957d9e3d  push r11
00007d3d957d9e3f  sub rsp, 0xF0
00007d3d957d9e46  vmovaps [rsp], xmm0
00007d3d957d9e4b  vmovaps [rsp+0x10], xmm1
00007d3d957d9e51  vmovaps [rsp+0x20], xmm2
00007d3d957d9e57  vmovaps [rsp+0x30], xmm3
00007d3d957d9e5d  vmovaps [rsp+0x40], xmm4
00007d3d957d9e63  vmovaps [rsp+0x50], xmm5
00007d3d957d9e69  vmovaps [rsp+0x60], xmm6
00007d3d957d9e6f  vmovaps [rsp+0x70], xmm7
00007d3d957d9e75  vmovaps [rsp+0x80], xmm9
00007d3d957d9e7e  vmovaps [rsp+0x90], xmm10
00007d3d957d9e87  vmovaps [rsp+0xA0], xmm11
00007d3d957d9e90  vmovaps [rsp+0xB0], xmm12
00007d3d957d9e99  vmovaps [rsp+0xC0], xmm13
00007d3d957d9ea2  vmovaps [rsp+0xD0], xmm14
00007d3d957d9eab  vmovaps [rsp+0xE0], xmm15
00007d3d957d9eb4  sub rsp, 0x30
00007d3d957d9eb8  movaps [rsp], xmm8
00007d3d957d9ebd  movaps [rsp+0x10], xmm1
00007d3d957d9ec2  movaps [rsp+0x20], xmm14
00007d3d957d9ec8  lea rdi, [rsp]
00007d3d957d9ecc  mov esi, 0x00
00007d3d957d9ed1  mov rax, 0x56C27CB8A530
00007d3d957d9edb  call rax
00007d3d957d9edd  movaps xmm8, [rsp]
00007d3d957d9ee2  add rsp, 0x30
00007d3d957d9ee6  vmovaps xmm0, [rsp]
00007d3d957d9eeb  vmovaps xmm1, [rsp+0x10]
00007d3d957d9ef1  vmovaps xmm2, [rsp+0x20]
00007d3d957d9ef7  vmovaps xmm3, [rsp+0x30]
00007d3d957d9efd  vmovaps xmm4, [rsp+0x40]
00007d3d957d9f03  vmovaps xmm5, [rsp+0x50]
00007d3d957d9f09  vmovaps xmm6, [rsp+0x60]
00007d3d957d9f0f  vmovaps xmm7, [rsp+0x70]
00007d3d957d9f15  vmovaps xmm9, [rsp+0x80]
00007d3d957d9f1e  vmovaps xmm10, [rsp+0x90]
00007d3d957d9f27  vmovaps xmm11, [rsp+0xA0]
00007d3d957d9f30  vmovaps xmm12, [rsp+0xB0]
00007d3d957d9f39  vmovaps xmm13, [rsp+0xC0]
00007d3d957d9f42  vmovaps xmm14, [rsp+0xD0]
00007d3d957d9f4b  vmovaps xmm15, [rsp+0xE0]
00007d3d957d9f54  add rsp, 0xF0
00007d3d957d9f5b  pop r11
00007d3d957d9f5d  pop r10
00007d3d957d9f5f  pop r9
00007d3d957d9f61  pop r8
00007d3d957d9f63  pop rsi
00007d3d957d9f64  pop rdi
00007d3d957d9f65  pop rdx
00007d3d957d9f66  pop rcx
00007d3d957d9f67  pop rax
00007d3d957d9f68  add rsp, 0x08
00007d3d957d9f6c  jmp 0x00007D3D957D63AE
00007d3d957d9f71  sub rsp, 0x08
00007d3d957d9f75  push rax
00007d3d957d9f76  push rcx
00007d3d957d9f77  push rdx
00007d3d957d9f78  push rdi
00007d3d957d9f79  push rsi
00007d3d957d9f7a  push r8
00007d3d957d9f7c  push r9
00007d3d957d9f7e  push r10
00007d3d957d9f80  push r11
00007d3d957d9f82  sub rsp, 0xF0
00007d3d957d9f89  vmovaps [rsp], xmm0
00007d3d957d9f8e  vmovaps [rsp+0x10], xmm1
00007d3d957d9f94  vmovaps [rsp+0x20], xmm2
00007d3d957d9f9a  vmovaps [rsp+0x30], xmm3
00007d3d957d9fa0  vmovaps [rsp+0x40], xmm4
00007d3d957d9fa6  vmovaps [rsp+0x50], xmm5
00007d3d957d9fac  vmovaps [rsp+0x60], xmm7
00007d3d957d9fb2  vmovaps [rsp+0x70], xmm8
00007d3d957d9fb8  vmovaps [rsp+0x80], xmm9
00007d3d957d9fc1  vmovaps [rsp+0x90], xmm10
00007d3d957d9fca  vmovaps [rsp+0xA0], xmm11
00007d3d957d9fd3  vmovaps [rsp+0xB0], xmm12
00007d3d957d9fdc  vmovaps [rsp+0xC0], xmm13
00007d3d957d9fe5  vmovaps [rsp+0xD0], xmm14
00007d3d957d9fee  vmovaps [rsp+0xE0], xmm15
00007d3d957d9ff7  sub rsp, 0x30
00007d3d957d9ffb  movaps [rsp], xmm6
00007d3d957d9fff  movaps [rsp+0x10], xmm1
00007d3d957da004  movaps [rsp+0x20], xmm14
00007d3d957da00a  lea rdi, [rsp]
00007d3d957da00e  mov esi, 0x00
00007d3d957da013  mov rax, 0x56C27CB8A530
00007d3d957da01d  call rax
00007d3d957da01f  movaps xmm6, [rsp]
00007d3d957da023  add rsp, 0x30
00007d3d957da027  vmovaps xmm0, [rsp]
00007d3d957da02c  vmovaps xmm1, [rsp+0x10]
00007d3d957da032  vmovaps xmm2, [rsp+0x20]
00007d3d957da038  vmovaps xmm3, [rsp+0x30]
00007d3d957da03e  vmovaps xmm4, [rsp+0x40]
00007d3d957da044  vmovaps xmm5, [rsp+0x50]
00007d3d957da04a  vmovaps xmm7, [rsp+0x60]
00007d3d957da050  vmovaps xmm8, [rsp+0x70]
00007d3d957da056  vmovaps xmm9, [rsp+0x80]
00007d3d957da05f  vmovaps xmm10, [rsp+0x90]
00007d3d957da068  vmovaps xmm11, [rsp+0xA0]
00007d3d957da071  vmovaps xmm12, [rsp+0xB0]
00007d3d957da07a  vmovaps xmm13, [rsp+0xC0]
00007d3d957da083  vmovaps xmm14, [rsp+0xD0]
00007d3d957da08c  vmovaps xmm15, [rsp+0xE0]
00007d3d957da095  add rsp, 0xF0
00007d3d957da09c  pop r11
00007d3d957da09e  pop r10
00007d3d957da0a0  pop r9
00007d3d957da0a2  pop r8
00007d3d957da0a4  pop rsi
00007d3d957da0a5  pop rdi
00007d3d957da0a6  pop rdx
00007d3d957da0a7  pop rcx
00007d3d957da0a8  pop rax
00007d3d957da0a9  add rsp, 0x08
00007d3d957da0ad  jmp 0x00007D3D957D63DA
00007d3d957da0b2  sub rsp, 0x08
00007d3d957da0b6  push rax
00007d3d957da0b7  push rcx
00007d3d957da0b8  push rdx
00007d3d957da0b9  push rdi
00007d3d957da0ba  push rsi
00007d3d957da0bb  push r8
00007d3d957da0bd  push r9
00007d3d957da0bf  push r10
00007d3d957da0c1  push r11
00007d3d957da0c3  sub rsp, 0xF0
00007d3d957da0ca  vmovaps [rsp], xmm0
00007d3d957da0cf  vmovaps [rsp+0x10], xmm1
00007d3d957da0d5  vmovaps [rsp+0x20], xmm2
00007d3d957da0db  vmovaps [rsp+0x30], xmm3
00007d3d957da0e1  vmovaps [rsp+0x40], xmm4
00007d3d957da0e7  vmovaps [rsp+0x50], xmm5
00007d3d957da0ed  vmovaps [rsp+0x60], xmm6
00007d3d957da0f3  vmovaps [rsp+0x70], xmm7
00007d3d957da0f9  vmovaps [rsp+0x80], xmm8
00007d3d957da102  vmovaps [rsp+0x90], xmm9
00007d3d957da10b  vmovaps [rsp+0xA0], xmm10
00007d3d957da114  vmovaps [rsp+0xB0], xmm11
00007d3d957da11d  vmovaps [rsp+0xC0], xmm12
00007d3d957da126  vmovaps [rsp+0xD0], xmm13
00007d3d957da12f  vmovaps [rsp+0xE0], xmm15
00007d3d957da138  sub rsp, 0x30
00007d3d957da13c  movaps [rsp], xmm14
00007d3d957da141  movaps [rsp+0x10], xmm12
00007d3d957da147  movaps [rsp+0x20], xmm1
00007d3d957da14c  lea rdi, [rsp]
00007d3d957da150  mov esi, 0x00
00007d3d957da155  mov rax, 0x56C27CB8A530
00007d3d957da15f  call rax
00007d3d957da161  movaps xmm14, [rsp]
00007d3d957da166  add rsp, 0x30
00007d3d957da16a  vmovaps xmm0, [rsp]
00007d3d957da16f  vmovaps xmm1, [rsp+0x10]
00007d3d957da175  vmovaps xmm2, [rsp+0x20]
00007d3d957da17b  vmovaps xmm3, [rsp+0x30]
00007d3d957da181  vmovaps xmm4, [rsp+0x40]
00007d3d957da187  vmovaps xmm5, [rsp+0x50]
00007d3d957da18d  vmovaps xmm6, [rsp+0x60]
00007d3d957da193  vmovaps xmm7, [rsp+0x70]
00007d3d957da199  vmovaps xmm8, [rsp+0x80]
00007d3d957da1a2  vmovaps xmm9, [rsp+0x90]
00007d3d957da1ab  vmovaps xmm10, [rsp+0xA0]
00007d3d957da1b4  vmovaps xmm11, [rsp+0xB0]
00007d3d957da1bd  vmovaps xmm12, [rsp+0xC0]
00007d3d957da1c6  vmovaps xmm13, [rsp+0xD0]
00007d3d957da1cf  vmovaps xmm15, [rsp+0xE0]
00007d3d957da1d8  add rsp, 0xF0
00007d3d957da1df  pop r11
00007d3d957da1e1  pop r10
00007d3d957da1e3  pop r9
00007d3d957da1e5  pop r8
00007d3d957da1e7  pop rsi
00007d3d957da1e8  pop rdi
00007d3d957da1e9  pop rdx
00007d3d957da1ea  pop rcx
00007d3d957da1eb  pop rax
00007d3d957da1ec  add rsp, 0x08
00007d3d957da1f0  jmp 0x00007D3D957D6400
00007d3d957da1f5  sub rsp, 0x08
00007d3d957da1f9  push rax
00007d3d957da1fa  push rcx
00007d3d957da1fb  push rdx
00007d3d957da1fc  push rdi
00007d3d957da1fd  push rsi
00007d3d957da1fe  push r8
00007d3d957da200  push r9
00007d3d957da202  push r10
00007d3d957da204  push r11
00007d3d957da206  sub rsp, 0xF0
00007d3d957da20d  vmovaps [rsp], xmm0
00007d3d957da212  vmovaps [rsp+0x10], xmm2
00007d3d957da218  vmovaps [rsp+0x20], xmm3
00007d3d957da21e  vmovaps [rsp+0x30], xmm4
00007d3d957da224  vmovaps [rsp+0x40], xmm5
00007d3d957da22a  vmovaps [rsp+0x50], xmm6
00007d3d957da230  vmovaps [rsp+0x60], xmm7
00007d3d957da236  vmovaps [rsp+0x70], xmm8
00007d3d957da23c  vmovaps [rsp+0x80], xmm9
00007d3d957da245  vmovaps [rsp+0x90], xmm10
00007d3d957da24e  vmovaps [rsp+0xA0], xmm11
00007d3d957da257  vmovaps [rsp+0xB0], xmm12
00007d3d957da260  vmovaps [rsp+0xC0], xmm13
00007d3d957da269  vmovaps [rsp+0xD0], xmm14
00007d3d957da272  vmovaps [rsp+0xE0], xmm15
00007d3d957da27b  sub rsp, 0x30
00007d3d957da27f  movaps [rsp], xmm1
00007d3d957da283  movaps [rsp+0x10], xmm13
00007d3d957da289  movaps [rsp+0x20], xmm9
00007d3d957da28f  lea rdi, [rsp]
00007d3d957da293  mov esi, 0x00
00007d3d957da298  mov rax, 0x56C27CB8A530
00007d3d957da2a2  call rax
00007d3d957da2a4  movaps xmm1, [rsp]
00007d3d957da2a8  add rsp, 0x30
00007d3d957da2ac  vmovaps xmm0, [rsp]
00007d3d957da2b1  vmovaps xmm2, [rsp+0x10]
00007d3d957da2b7  vmovaps xmm3, [rsp+0x20]
00007d3d957da2bd  vmovaps xmm4, [rsp+0x30]
00007d3d957da2c3  vmovaps xmm5, [rsp+0x40]
00007d3d957da2c9  vmovaps xmm6, [rsp+0x50]
00007d3d957da2cf  vmovaps xmm7, [rsp+0x60]
00007d3d957da2d5  vmovaps xmm8, [rsp+0x70]
00007d3d957da2db  vmovaps xmm9, [rsp+0x80]
00007d3d957da2e4  vmovaps xmm10, [rsp+0x90]
00007d3d957da2ed  vmovaps xmm11, [rsp+0xA0]
00007d3d957da2f6  vmovaps xmm12, [rsp+0xB0]
00007d3d957da2ff  vmovaps xmm13, [rsp+0xC0]
00007d3d957da308  vmovaps xmm14, [rsp+0xD0]
00007d3d957da311  vmovaps xmm15, [rsp+0xE0]
00007d3d957da31a  add rsp, 0xF0
00007d3d957da321  pop r11
00007d3d957da323  pop r10
00007d3d957da325  pop r9
00007d3d957da327  pop r8
00007d3d957da329  pop rsi
00007d3d957da32a  pop rdi
00007d3d957da32b  pop rdx
00007d3d957da32c  pop rcx
00007d3d957da32d  pop rax
00007d3d957da32e  add rsp, 0x08
00007d3d957da332  jmp 0x00007D3D957D641A
00007d3d957da337  sub rsp, 0x08
00007d3d957da33b  push rax
00007d3d957da33c  push rcx
00007d3d957da33d  push rdx
00007d3d957da33e  push rdi
00007d3d957da33f  push rsi
00007d3d957da340  push r8
00007d3d957da342  push r9
00007d3d957da344  push r10
00007d3d957da346  push r11
00007d3d957da348  sub rsp, 0xF0
00007d3d957da34f  vmovaps [rsp], xmm0
00007d3d957da354  vmovaps [rsp+0x10], xmm1
00007d3d957da35a  vmovaps [rsp+0x20], xmm2
00007d3d957da360  vmovaps [rsp+0x30], xmm3
00007d3d957da366  vmovaps [rsp+0x40], xmm4
00007d3d957da36c  vmovaps [rsp+0x50], xmm5
00007d3d957da372  vmovaps [rsp+0x60], xmm6
00007d3d957da378  vmovaps [rsp+0x70], xmm7
00007d3d957da37e  vmovaps [rsp+0x80], xmm8
00007d3d957da387  vmovaps [rsp+0x90], xmm9
00007d3d957da390  vmovaps [rsp+0xA0], xmm10
00007d3d957da399  vmovaps [rsp+0xB0], xmm11
00007d3d957da3a2  vmovaps [rsp+0xC0], xmm13
00007d3d957da3ab  vmovaps [rsp+0xD0], xmm14
00007d3d957da3b4  vmovaps [rsp+0xE0], xmm15
00007d3d957da3bd  sub rsp, 0x30
00007d3d957da3c1  movaps [rsp], xmm12
00007d3d957da3c6  movaps [rsp+0x10], xmm7
00007d3d957da3cb  movaps [rsp+0x20], xmm13
00007d3d957da3d1  lea rdi, [rsp]
00007d3d957da3d5  mov esi, 0x00
00007d3d957da3da  mov rax, 0x56C27CB8A530
00007d3d957da3e4  call rax
00007d3d957da3e6  movaps xmm12, [rsp]
00007d3d957da3eb  add rsp, 0x30
00007d3d957da3ef  vmovaps xmm0, [rsp]
00007d3d957da3f4  vmovaps xmm1, [rsp+0x10]
00007d3d957da3fa  vmovaps xmm2, [rsp+0x20]
00007d3d957da400  vmovaps xmm3, [rsp+0x30]
00007d3d957da406  vmovaps xmm4, [rsp+0x40]
00007d3d957da40c  vmovaps xmm5, [rsp+0x50]
00007d3d957da412  vmovaps xmm6, [rsp+0x60]
00007d3d957da418  vmovaps xmm7, [rsp+0x70]
00007d3d957da41e  vmovaps xmm8, [rsp+0x80]
00007d3d957da427  vmovaps xmm9, [rsp+0x90]
00007d3d957da430  vmovaps xmm10, [rsp+0xA0]
00007d3d957da439  vmovaps xmm11, [rsp+0xB0]
00007d3d957da442  vmovaps xmm13, [rsp+0xC0]
00007d3d957da44b  vmovaps xmm14, [rsp+0xD0]
00007d3d957da454  vmovaps xmm15, [rsp+0xE0]
00007d3d957da45d  add rsp, 0xF0
00007d3d957da464  pop r11
00007d3d957da466  pop r10
00007d3d957da468  pop r9
00007d3d957da46a  pop r8
00007d3d957da46c  pop rsi
00007d3d957da46d  pop rdi
00007d3d957da46e  pop rdx
00007d3d957da46f  pop rcx
00007d3d957da470  pop rax
00007d3d957da471  add rsp, 0x08
00007d3d957da475  jmp 0x00007D3D957D6441
00007d3d957da47a  sub rsp, 0x08
00007d3d957da47e  push rax
00007d3d957da47f  push rcx
00007d3d957da480  push rdx
00007d3d957da481  push rdi
00007d3d957da482  push rsi
00007d3d957da483  push r8
00007d3d957da485  push r9
00007d3d957da487  push r10
00007d3d957da489  push r11
00007d3d957da48b  sub rsp, 0xF0
00007d3d957da492  vmovaps [rsp], xmm0
00007d3d957da497  vmovaps [rsp+0x10], xmm1
00007d3d957da49d  vmovaps [rsp+0x20], xmm2
00007d3d957da4a3  vmovaps [rsp+0x30], xmm3
00007d3d957da4a9  vmovaps [rsp+0x40], xmm4
00007d3d957da4af  vmovaps [rsp+0x50], xmm5
00007d3d957da4b5  vmovaps [rsp+0x60], xmm6
00007d3d957da4bb  vmovaps [rsp+0x70], xmm7
00007d3d957da4c1  vmovaps [rsp+0x80], xmm8
00007d3d957da4ca  vmovaps [rsp+0x90], xmm9
00007d3d957da4d3  vmovaps [rsp+0xA0], xmm10
00007d3d957da4dc  vmovaps [rsp+0xB0], xmm11
00007d3d957da4e5  vmovaps [rsp+0xC0], xmm12
00007d3d957da4ee  vmovaps [rsp+0xD0], xmm14
00007d3d957da4f7  vmovaps [rsp+0xE0], xmm15
00007d3d957da500  sub rsp, 0x30
00007d3d957da504  movaps [rsp], xmm13
00007d3d957da509  movaps [rsp+0x10], xmm15
00007d3d957da50f  movaps [rsp+0x20], xmm8
00007d3d957da515  lea rdi, [rsp]
00007d3d957da519  mov esi, 0x00
00007d3d957da51e  mov rax, 0x56C27CB8A530
00007d3d957da528  call rax
00007d3d957da52a  movaps xmm13, [rsp]
00007d3d957da52f  add rsp, 0x30
00007d3d957da533  vmovaps xmm0, [rsp]
00007d3d957da538  vmovaps xmm1, [rsp+0x10]
00007d3d957da53e  vmovaps xmm2, [rsp+0x20]
00007d3d957da544  vmovaps xmm3, [rsp+0x30]
00007d3d957da54a  vmovaps xmm4, [rsp+0x40]
00007d3d957da550  vmovaps xmm5, [rsp+0x50]
00007d3d957da556  vmovaps xmm6, [rsp+0x60]
00007d3d957da55c  vmovaps xmm7, [rsp+0x70]
00007d3d957da562  vmovaps xmm8, [rsp+0x80]
00007d3d957da56b  vmovaps xmm9, [rsp+0x90]
00007d3d957da574  vmovaps xmm10, [rsp+0xA0]
00007d3d957da57d  vmovaps xmm11, [rsp+0xB0]
00007d3d957da586  vmovaps xmm12, [rsp+0xC0]
00007d3d957da58f  vmovaps xmm14, [rsp+0xD0]
00007d3d957da598  vmovaps xmm15, [rsp+0xE0]
00007d3d957da5a1  add rsp, 0xF0
00007d3d957da5a8  pop r11
00007d3d957da5aa  pop r10
00007d3d957da5ac  pop r9
00007d3d957da5ae  pop r8
00007d3d957da5b0  pop rsi
00007d3d957da5b1  pop rdi
00007d3d957da5b2  pop rdx
00007d3d957da5b3  pop rcx
00007d3d957da5b4  pop rax
00007d3d957da5b5  add rsp, 0x08
00007d3d957da5b9  jmp 0x00007D3D957D645C
00007d3d957da5be  sub rsp, 0x08
00007d3d957da5c2  push rax
00007d3d957da5c3  push rcx
00007d3d957da5c4  push rdx
00007d3d957da5c5  push rdi
00007d3d957da5c6  push rsi
00007d3d957da5c7  push r8
00007d3d957da5c9  push r9
00007d3d957da5cb  push r10
00007d3d957da5cd  push r11
00007d3d957da5cf  sub rsp, 0xF0
00007d3d957da5d6  vmovaps [rsp], xmm0
00007d3d957da5db  vmovaps [rsp+0x10], xmm1
00007d3d957da5e1  vmovaps [rsp+0x20], xmm2
00007d3d957da5e7  vmovaps [rsp+0x30], xmm3
00007d3d957da5ed  vmovaps [rsp+0x40], xmm4
00007d3d957da5f3  vmovaps [rsp+0x50], xmm5
00007d3d957da5f9  vmovaps [rsp+0x60], xmm6
00007d3d957da5ff  vmovaps [rsp+0x70], xmm7
00007d3d957da605  vmovaps [rsp+0x80], xmm9
00007d3d957da60e  vmovaps [rsp+0x90], xmm10
00007d3d957da617  vmovaps [rsp+0xA0], xmm11
00007d3d957da620  vmovaps [rsp+0xB0], xmm12
00007d3d957da629  vmovaps [rsp+0xC0], xmm13
00007d3d957da632  vmovaps [rsp+0xD0], xmm14
00007d3d957da63b  vmovaps [rsp+0xE0], xmm15
00007d3d957da644  sub rsp, 0x30
00007d3d957da648  movaps [rsp], xmm8
00007d3d957da64d  movaps [rsp+0x10], xmm15
00007d3d957da653  movaps [rsp+0x20], xmm9
00007d3d957da659  lea rdi, [rsp]
00007d3d957da65d  mov esi, 0x00
00007d3d957da662  mov rax, 0x56C27CB8A530
00007d3d957da66c  call rax
00007d3d957da66e  movaps xmm8, [rsp]
00007d3d957da673  add rsp, 0x30
00007d3d957da677  vmovaps xmm0, [rsp]
00007d3d957da67c  vmovaps xmm1, [rsp+0x10]
00007d3d957da682  vmovaps xmm2, [rsp+0x20]
00007d3d957da688  vmovaps xmm3, [rsp+0x30]
00007d3d957da68e  vmovaps xmm4, [rsp+0x40]
00007d3d957da694  vmovaps xmm5, [rsp+0x50]
00007d3d957da69a  vmovaps xmm6, [rsp+0x60]
00007d3d957da6a0  vmovaps xmm7, [rsp+0x70]
00007d3d957da6a6  vmovaps xmm9, [rsp+0x80]
00007d3d957da6af  vmovaps xmm10, [rsp+0x90]
00007d3d957da6b8  vmovaps xmm11, [rsp+0xA0]
00007d3d957da6c1  vmovaps xmm12, [rsp+0xB0]
00007d3d957da6ca  vmovaps xmm13, [rsp+0xC0]
00007d3d957da6d3  vmovaps xmm14, [rsp+0xD0]
00007d3d957da6dc  vmovaps xmm15, [rsp+0xE0]
00007d3d957da6e5  add rsp, 0xF0
00007d3d957da6ec  pop r11
00007d3d957da6ee  pop r10
00007d3d957da6f0  pop r9
00007d3d957da6f2  pop r8
00007d3d957da6f4  pop rsi
00007d3d957da6f5  pop rdi
00007d3d957da6f6  pop rdx
00007d3d957da6f7  pop rcx
00007d3d957da6f8  pop rax
00007d3d957da6f9  add rsp, 0x08
00007d3d957da6fd  jmp 0x00007D3D957D648A
00007d3d957da702  sub rsp, 0x08
00007d3d957da706  push rax
00007d3d957da707  push rcx
00007d3d957da708  push rdx
00007d3d957da709  push rdi
00007d3d957da70a  push rsi
00007d3d957da70b  push r8
00007d3d957da70d  push r9
00007d3d957da70f  push r10
00007d3d957da711  push r11
00007d3d957da713  sub rsp, 0xF0
00007d3d957da71a  vmovaps [rsp], xmm0
00007d3d957da71f  vmovaps [rsp+0x10], xmm1
00007d3d957da725  vmovaps [rsp+0x20], xmm2
00007d3d957da72b  vmovaps [rsp+0x30], xmm3
00007d3d957da731  vmovaps [rsp+0x40], xmm4
00007d3d957da737  vmovaps [rsp+0x50], xmm5
00007d3d957da73d  vmovaps [rsp+0x60], xmm6
00007d3d957da743  vmovaps [rsp+0x70], xmm7
00007d3d957da749  vmovaps [rsp+0x80], xmm8
00007d3d957da752  vmovaps [rsp+0x90], xmm9
00007d3d957da75b  vmovaps [rsp+0xA0], xmm10
00007d3d957da764  vmovaps [rsp+0xB0], xmm11
00007d3d957da76d  vmovaps [rsp+0xC0], xmm12
00007d3d957da776  vmovaps [rsp+0xD0], xmm13
00007d3d957da77f  vmovaps [rsp+0xE0], xmm14
00007d3d957da788  sub rsp, 0x30
00007d3d957da78c  movaps [rsp], xmm15
00007d3d957da791  movaps [rsp+0x10], xmm11
00007d3d957da797  movaps [rsp+0x20], xmm6
00007d3d957da79c  lea rdi, [rsp]
00007d3d957da7a0  mov esi, 0x00
00007d3d957da7a5  mov rax, 0x56C27CB8A530
00007d3d957da7af  call rax
00007d3d957da7b1  movaps xmm15, [rsp]
00007d3d957da7b6  add rsp, 0x30
00007d3d957da7ba  vmovaps xmm0, [rsp]
00007d3d957da7bf  vmovaps xmm1, [rsp+0x10]
00007d3d957da7c5  vmovaps xmm2, [rsp+0x20]
00007d3d957da7cb  vmovaps xmm3, [rsp+0x30]
00007d3d957da7d1  vmovaps xmm4, [rsp+0x40]
00007d3d957da7d7  vmovaps xmm5, [rsp+0x50]
00007d3d957da7dd  vmovaps xmm6, [rsp+0x60]
00007d3d957da7e3  vmovaps xmm7, [rsp+0x70]
00007d3d957da7e9  vmovaps xmm8, [rsp+0x80]
00007d3d957da7f2  vmovaps xmm9, [rsp+0x90]
00007d3d957da7fb  vmovaps xmm10, [rsp+0xA0]
00007d3d957da804  vmovaps xmm11, [rsp+0xB0]
00007d3d957da80d  vmovaps xmm12, [rsp+0xC0]
00007d3d957da816  vmovaps xmm13, [rsp+0xD0]
00007d3d957da81f  vmovaps xmm14, [rsp+0xE0]
00007d3d957da828  add rsp, 0xF0
00007d3d957da82f  pop r11
00007d3d957da831  pop r10
00007d3d957da833  pop r9
00007d3d957da835  pop r8
00007d3d957da837  pop rsi
00007d3d957da838  pop rdi
00007d3d957da839  pop rdx
00007d3d957da83a  pop rcx
00007d3d957da83b  pop rax
00007d3d957da83c  add rsp, 0x08
00007d3d957da840  jmp 0x00007D3D957D64A5
00007d3d957da845  sub rsp, 0x08
00007d3d957da849  push rax
00007d3d957da84a  push rcx
00007d3d957da84b  push rdx
00007d3d957da84c  push rdi
00007d3d957da84d  push rsi
00007d3d957da84e  push r8
00007d3d957da850  push r9
00007d3d957da852  push r10
00007d3d957da854  push r11
00007d3d957da856  sub rsp, 0xF0
00007d3d957da85d  vmovaps [rsp], xmm0
00007d3d957da862  vmovaps [rsp+0x10], xmm1
00007d3d957da868  vmovaps [rsp+0x20], xmm2
00007d3d957da86e  vmovaps [rsp+0x30], xmm3
00007d3d957da874  vmovaps [rsp+0x40], xmm4
00007d3d957da87a  vmovaps [rsp+0x50], xmm5
00007d3d957da880  vmovaps [rsp+0x60], xmm6
00007d3d957da886  vmovaps [rsp+0x70], xmm8
00007d3d957da88c  vmovaps [rsp+0x80], xmm9
00007d3d957da895  vmovaps [rsp+0x90], xmm10
00007d3d957da89e  vmovaps [rsp+0xA0], xmm11
00007d3d957da8a7  vmovaps [rsp+0xB0], xmm12
00007d3d957da8b0  vmovaps [rsp+0xC0], xmm13
00007d3d957da8b9  vmovaps [rsp+0xD0], xmm14
00007d3d957da8c2  vmovaps [rsp+0xE0], xmm15
00007d3d957da8cb  sub rsp, 0x30
00007d3d957da8cf  movaps [rsp], xmm7
00007d3d957da8d3  movaps [rsp+0x10], xmm11
00007d3d957da8d9  movaps [rsp+0x20], xmm9
00007d3d957da8df  lea rdi, [rsp]
00007d3d957da8e3  mov esi, 0x00
00007d3d957da8e8  mov rax, 0x56C27CB8A530
00007d3d957da8f2  call rax
00007d3d957da8f4  movaps xmm7, [rsp]
00007d3d957da8f8  add rsp, 0x30
00007d3d957da8fc  vmovaps xmm0, [rsp]
00007d3d957da901  vmovaps xmm1, [rsp+0x10]
00007d3d957da907  vmovaps xmm2, [rsp+0x20]
00007d3d957da90d  vmovaps xmm3, [rsp+0x30]
00007d3d957da913  vmovaps xmm4, [rsp+0x40]
00007d3d957da919  vmovaps xmm5, [rsp+0x50]
00007d3d957da91f  vmovaps xmm6, [rsp+0x60]
00007d3d957da925  vmovaps xmm8, [rsp+0x70]
00007d3d957da92b  vmovaps xmm9, [rsp+0x80]
00007d3d957da934  vmovaps xmm10, [rsp+0x90]
00007d3d957da93d  vmovaps xmm11, [rsp+0xA0]
00007d3d957da946  vmovaps xmm12, [rsp+0xB0]
00007d3d957da94f  vmovaps xmm13, [rsp+0xC0]
00007d3d957da958  vmovaps xmm14, [rsp+0xD0]
00007d3d957da961  vmovaps xmm15, [rsp+0xE0]
00007d3d957da96a  add rsp, 0xF0
00007d3d957da971  pop r11
00007d3d957da973  pop r10
00007d3d957da975  pop r9
00007d3d957da977  pop r8
00007d3d957da979  pop rsi
00007d3d957da97a  pop rdi
00007d3d957da97b  pop rdx
00007d3d957da97c  pop rcx
00007d3d957da97d  pop rax
00007d3d957da97e  add rsp, 0x08
00007d3d957da982  jmp 0x00007D3D957D64D2
00007d3d957da987  sub rsp, 0x08
00007d3d957da98b  push rax
00007d3d957da98c  push rcx
00007d3d957da98d  push rdx
00007d3d957da98e  push rdi
00007d3d957da98f  push rsi
00007d3d957da990  push r8
00007d3d957da992  push r9
00007d3d957da994  push r10
00007d3d957da996  push r11
00007d3d957da998  sub rsp, 0xF0
00007d3d957da99f  vmovaps [rsp], xmm0
00007d3d957da9a4  vmovaps [rsp+0x10], xmm1
00007d3d957da9aa  vmovaps [rsp+0x20], xmm2
00007d3d957da9b0  vmovaps [rsp+0x30], xmm3
00007d3d957da9b6  vmovaps [rsp+0x40], xmm4
00007d3d957da9bc  vmovaps [rsp+0x50], xmm5
00007d3d957da9c2  vmovaps [rsp+0x60], xmm6
00007d3d957da9c8  vmovaps [rsp+0x70], xmm7
00007d3d957da9ce  vmovaps [rsp+0x80], xmm8
00007d3d957da9d7  vmovaps [rsp+0x90], xmm9
00007d3d957da9e0  vmovaps [rsp+0xA0], xmm10
00007d3d957da9e9  vmovaps [rsp+0xB0], xmm12
00007d3d957da9f2  vmovaps [rsp+0xC0], xmm13
00007d3d957da9fb  vmovaps [rsp+0xD0], xmm14
00007d3d957daa04  vmovaps [rsp+0xE0], xmm15
00007d3d957daa0d  sub rsp, 0x30
00007d3d957daa11  movaps [rsp], xmm11
00007d3d957daa16  movaps [rsp+0x10], xmm10
00007d3d957daa1c  movaps [rsp+0x20], xmm14
00007d3d957daa22  lea rdi, [rsp]
00007d3d957daa26  mov esi, 0x00
00007d3d957daa2b  mov rax, 0x56C27CB8A530
00007d3d957daa35  call rax
00007d3d957daa37  movaps xmm11, [rsp]
00007d3d957daa3c  add rsp, 0x30
00007d3d957daa40  vmovaps xmm0, [rsp]
00007d3d957daa45  vmovaps xmm1, [rsp+0x10]
00007d3d957daa4b  vmovaps xmm2, [rsp+0x20]
00007d3d957daa51  vmovaps xmm3, [rsp+0x30]
00007d3d957daa57  vmovaps xmm4, [rsp+0x40]
00007d3d957daa5d  vmovaps xmm5, [rsp+0x50]
00007d3d957daa63  vmovaps xmm6, [rsp+0x60]
00007d3d957daa69  vmovaps xmm7, [rsp+0x70]
00007d3d957daa6f  vmovaps xmm8, [rsp+0x80]
00007d3d957daa78  vmovaps xmm9, [rsp+0x90]
00007d3d957daa81  vmovaps xmm10, [rsp+0xA0]
00007d3d957daa8a  vmovaps xmm12, [rsp+0xB0]
00007d3d957daa93  vmovaps xmm13, [rsp+0xC0]
00007d3d957daa9c  vmovaps xmm14, [rsp+0xD0]
00007d3d957daaa5  vmovaps xmm15, [rsp+0xE0]
00007d3d957daaae  add rsp, 0xF0
00007d3d957daab5  pop r11
00007d3d957daab7  pop r10
00007d3d957daab9  pop r9
00007d3d957daabb  pop r8
00007d3d957daabd  pop rsi
00007d3d957daabe  pop rdi
00007d3d957daabf  pop rdx
00007d3d957daac0  pop rcx
00007d3d957daac1  pop rax
00007d3d957daac2  add rsp, 0x08
00007d3d957daac6  jmp 0x00007D3D957D64ED
00007d3d957daacb  call 0x00007D3D956E45A0
00007d3d957daad0  jmp 0x00007D3D957D64F7
00007d3d957daad5  sub rsp, 0x08
00007d3d957daad9  push rax
00007d3d957daada  push rcx
00007d3d957daadb  push rdx
00007d3d957daadc  push rdi
00007d3d957daadd  push rsi
00007d3d957daade  push r8
00007d3d957daae0  push r9
00007d3d957daae2  push r10
00007d3d957daae4  push r11
00007d3d957daae6  sub rsp, 0xF0
00007d3d957daaed  vmovaps [rsp], xmm0
00007d3d957daaf2  vmovaps [rsp+0x10], xmm1
00007d3d957daaf8  vmovaps [rsp+0x20], xmm2
00007d3d957daafe  vmovaps [rsp+0x30], xmm3
00007d3d957dab04  vmovaps [rsp+0x40], xmm4
00007d3d957dab0a  vmovaps [rsp+0x50], xmm5
00007d3d957dab10  vmovaps [rsp+0x60], xmm6
00007d3d957dab16  vmovaps [rsp+0x70], xmm7
00007d3d957dab1c  vmovaps [rsp+0x80], xmm8
00007d3d957dab25  vmovaps [rsp+0x90], xmm9
00007d3d957dab2e  vmovaps [rsp+0xA0], xmm11
00007d3d957dab37  vmovaps [rsp+0xB0], xmm12
00007d3d957dab40  vmovaps [rsp+0xC0], xmm13
00007d3d957dab49  vmovaps [rsp+0xD0], xmm14
00007d3d957dab52  vmovaps [rsp+0xE0], xmm15
00007d3d957dab5b  sub rsp, 0x30
00007d3d957dab5f  movaps [rsp], xmm10
00007d3d957dab64  movaps [rsp+0x10], xmm1
00007d3d957dab69  movaps [rsp+0x20], xmm12
00007d3d957dab6f  lea rdi, [rsp]
00007d3d957dab73  mov esi, 0x00
00007d3d957dab78  mov rax, 0x56C27CB8A530
00007d3d957dab82  call rax
00007d3d957dab84  movaps xmm10, [rsp]
00007d3d957dab89  add rsp, 0x30
00007d3d957dab8d  vmovaps xmm0, [rsp]
00007d3d957dab92  vmovaps xmm1, [rsp+0x10]
00007d3d957dab98  vmovaps xmm2, [rsp+0x20]
00007d3d957dab9e  vmovaps xmm3, [rsp+0x30]
00007d3d957daba4  vmovaps xmm4, [rsp+0x40]
00007d3d957dabaa  vmovaps xmm5, [rsp+0x50]
00007d3d957dabb0  vmovaps xmm6, [rsp+0x60]
00007d3d957dabb6  vmovaps xmm7, [rsp+0x70]
00007d3d957dabbc  vmovaps xmm8, [rsp+0x80]
00007d3d957dabc5  vmovaps xmm9, [rsp+0x90]
00007d3d957dabce  vmovaps xmm11, [rsp+0xA0]
00007d3d957dabd7  vmovaps xmm12, [rsp+0xB0]
00007d3d957dabe0  vmovaps xmm13, [rsp+0xC0]
00007d3d957dabe9  vmovaps xmm14, [rsp+0xD0]
00007d3d957dabf2  vmovaps xmm15, [rsp+0xE0]
00007d3d957dabfb  add rsp, 0xF0
00007d3d957dac02  pop r11
00007d3d957dac04  pop r10
00007d3d957dac06  pop r9
00007d3d957dac08  pop r8
00007d3d957dac0a  pop rsi
00007d3d957dac0b  pop rdi
00007d3d957dac0c  pop rdx
00007d3d957dac0d  pop rcx
00007d3d957dac0e  pop rax
00007d3d957dac0f  add rsp, 0x08
00007d3d957dac13  jmp 0x00007D3D957D651A
00007d3d957dac18  sub rsp, 0x08
00007d3d957dac1c  push rax
00007d3d957dac1d  push rcx
00007d3d957dac1e  push rdx
00007d3d957dac1f  push rdi
00007d3d957dac20  push rsi
00007d3d957dac21  push r8
00007d3d957dac23  push r9
00007d3d957dac25  push r10
00007d3d957dac27  push r11
00007d3d957dac29  sub rsp, 0xF0
00007d3d957dac30  vmovaps [rsp], xmm0
00007d3d957dac35  vmovaps [rsp+0x10], xmm1
00007d3d957dac3b  vmovaps [rsp+0x20], xmm2
00007d3d957dac41  vmovaps [rsp+0x30], xmm3
00007d3d957dac47  vmovaps [rsp+0x40], xmm4
00007d3d957dac4d  vmovaps [rsp+0x50], xmm5
00007d3d957dac53  vmovaps [rsp+0x60], xmm6
00007d3d957dac59  vmovaps [rsp+0x70], xmm7
00007d3d957dac5f  vmovaps [rsp+0x80], xmm8
00007d3d957dac68  vmovaps [rsp+0x90], xmm9
00007d3d957dac71  vmovaps [rsp+0xA0], xmm10
00007d3d957dac7a  vmovaps [rsp+0xB0], xmm11
00007d3d957dac83  vmovaps [rsp+0xC0], xmm13
00007d3d957dac8c  vmovaps [rsp+0xD0], xmm14
00007d3d957dac95  vmovaps [rsp+0xE0], xmm15
00007d3d957dac9e  sub rsp, 0x30
00007d3d957daca2  movaps [rsp], xmm12
00007d3d957daca7  movaps [rsp+0x10], xmm14
00007d3d957dacad  movaps [rsp+0x20], xmm1
00007d3d957dacb2  lea rdi, [rsp]
00007d3d957dacb6  mov esi, 0x00
00007d3d957dacbb  mov rax, 0x56C27CB8A530
00007d3d957dacc5  call rax
00007d3d957dacc7  movaps xmm12, [rsp]
00007d3d957daccc  add rsp, 0x30
00007d3d957dacd0  vmovaps xmm0, [rsp]
00007d3d957dacd5  vmovaps xmm1, [rsp+0x10]
00007d3d957dacdb  vmovaps xmm2, [rsp+0x20]
00007d3d957dace1  vmovaps xmm3, [rsp+0x30]
00007d3d957dace7  vmovaps xmm4, [rsp+0x40]
00007d3d957daced  vmovaps xmm5, [rsp+0x50]
00007d3d957dacf3  vmovaps xmm6, [rsp+0x60]
00007d3d957dacf9  vmovaps xmm7, [rsp+0x70]
00007d3d957dacff  vmovaps xmm8, [rsp+0x80]
00007d3d957dad08  vmovaps xmm9, [rsp+0x90]
00007d3d957dad11  vmovaps xmm10, [rsp+0xA0]
00007d3d957dad1a  vmovaps xmm11, [rsp+0xB0]
00007d3d957dad23  vmovaps xmm13, [rsp+0xC0]
00007d3d957dad2c  vmovaps xmm14, [rsp+0xD0]
00007d3d957dad35  vmovaps xmm15, [rsp+0xE0]
00007d3d957dad3e  add rsp, 0xF0
00007d3d957dad45  pop r11
00007d3d957dad47  pop r10
00007d3d957dad49  pop r9
00007d3d957dad4b  pop r8
00007d3d957dad4d  pop rsi
00007d3d957dad4e  pop rdi
00007d3d957dad4f  pop rdx
00007d3d957dad50  pop rcx
00007d3d957dad51  pop rax
00007d3d957dad52  add rsp, 0x08
00007d3d957dad56  jmp 0x00007D3D957D6549
00007d3d957dad5b  sub rsp, 0x08
00007d3d957dad5f  push rax
00007d3d957dad60  push rcx
00007d3d957dad61  push rdx
00007d3d957dad62  push rdi
00007d3d957dad63  push rsi
00007d3d957dad64  push r8
00007d3d957dad66  push r9
00007d3d957dad68  push r10
00007d3d957dad6a  push r11
00007d3d957dad6c  sub rsp, 0xF0
00007d3d957dad73  vmovaps [rsp], xmm0
00007d3d957dad78  vmovaps [rsp+0x10], xmm1
00007d3d957dad7e  vmovaps [rsp+0x20], xmm2
00007d3d957dad84  vmovaps [rsp+0x30], xmm3
00007d3d957dad8a  vmovaps [rsp+0x40], xmm4
00007d3d957dad90  vmovaps [rsp+0x50], xmm5
00007d3d957dad96  vmovaps [rsp+0x60], xmm6
00007d3d957dad9c  vmovaps [rsp+0x70], xmm7
00007d3d957dada2  vmovaps [rsp+0x80], xmm8
00007d3d957dadab  vmovaps [rsp+0x90], xmm9
00007d3d957dadb4  vmovaps [rsp+0xA0], xmm10
00007d3d957dadbd  vmovaps [rsp+0xB0], xmm11
00007d3d957dadc6  vmovaps [rsp+0xC0], xmm12
00007d3d957dadcf  vmovaps [rsp+0xD0], xmm13
00007d3d957dadd8  vmovaps [rsp+0xE0], xmm15
00007d3d957dade1  sub rsp, 0x30
00007d3d957dade5  movaps [rsp], xmm14
00007d3d957dadea  movaps [rsp+0x10], xmm9
00007d3d957dadf0  movaps [rsp+0x20], xmm1
00007d3d957dadf5  lea rdi, [rsp]
00007d3d957dadf9  mov esi, 0x00
00007d3d957dadfe  mov rax, 0x56C27CB8A530
00007d3d957dae08  call rax
00007d3d957dae0a  movaps xmm14, [rsp]
00007d3d957dae0f  add rsp, 0x30
00007d3d957dae13  vmovaps xmm0, [rsp]
00007d3d957dae18  vmovaps xmm1, [rsp+0x10]
00007d3d957dae1e  vmovaps xmm2, [rsp+0x20]
00007d3d957dae24  vmovaps xmm3, [rsp+0x30]
00007d3d957dae2a  vmovaps xmm4, [rsp+0x40]
00007d3d957dae30  vmovaps xmm5, [rsp+0x50]
00007d3d957dae36  vmovaps xmm6, [rsp+0x60]
00007d3d957dae3c  vmovaps xmm7, [rsp+0x70]
00007d3d957dae42  vmovaps xmm8, [rsp+0x80]
00007d3d957dae4b  vmovaps xmm9, [rsp+0x90]
00007d3d957dae54  vmovaps xmm10, [rsp+0xA0]
00007d3d957dae5d  vmovaps xmm11, [rsp+0xB0]
00007d3d957dae66  vmovaps xmm12, [rsp+0xC0]
00007d3d957dae6f  vmovaps xmm13, [rsp+0xD0]
00007d3d957dae78  vmovaps xmm15, [rsp+0xE0]
00007d3d957dae81  add rsp, 0xF0
00007d3d957dae88  pop r11
00007d3d957dae8a  pop r10
00007d3d957dae8c  pop r9
00007d3d957dae8e  pop r8
00007d3d957dae90  pop rsi
00007d3d957dae91  pop rdi
00007d3d957dae92  pop rdx
00007d3d957dae93  pop rcx
00007d3d957dae94  pop rax
00007d3d957dae95  add rsp, 0x08
00007d3d957dae99  jmp 0x00007D3D957D6578
00007d3d957dae9e  sub rsp, 0x08
00007d3d957daea2  push rax
00007d3d957daea3  push rcx
00007d3d957daea4  push rdx
00007d3d957daea5  push rdi
00007d3d957daea6  push rsi
00007d3d957daea7  push r8
00007d3d957daea9  push r9
00007d3d957daeab  push r10
00007d3d957daead  push r11
00007d3d957daeaf  sub rsp, 0xF0
00007d3d957daeb6  vmovaps [rsp], xmm0
00007d3d957daebb  vmovaps [rsp+0x10], xmm2
00007d3d957daec1  vmovaps [rsp+0x20], xmm3
00007d3d957daec7  vmovaps [rsp+0x30], xmm4
00007d3d957daecd  vmovaps [rsp+0x40], xmm5
00007d3d957daed3  vmovaps [rsp+0x50], xmm6
00007d3d957daed9  vmovaps [rsp+0x60], xmm7
00007d3d957daedf  vmovaps [rsp+0x70], xmm8
00007d3d957daee5  vmovaps [rsp+0x80], xmm9
00007d3d957daeee  vmovaps [rsp+0x90], xmm10
00007d3d957daef7  vmovaps [rsp+0xA0], xmm11
00007d3d957daf00  vmovaps [rsp+0xB0], xmm12
00007d3d957daf09  vmovaps [rsp+0xC0], xmm13
00007d3d957daf12  vmovaps [rsp+0xD0], xmm14
00007d3d957daf1b  vmovaps [rsp+0xE0], xmm15
00007d3d957daf24  sub rsp, 0x30
00007d3d957daf28  movaps [rsp], xmm1
00007d3d957daf2c  movaps [rsp+0x10], xmm13
00007d3d957daf32  movaps [rsp+0x20], xmm8
00007d3d957daf38  lea rdi, [rsp]
00007d3d957daf3c  mov esi, 0x00
00007d3d957daf41  mov rax, 0x56C27CB8A530
00007d3d957daf4b  call rax
00007d3d957daf4d  movaps xmm1, [rsp]
00007d3d957daf51  add rsp, 0x30
00007d3d957daf55  vmovaps xmm0, [rsp]
00007d3d957daf5a  vmovaps xmm2, [rsp+0x10]
00007d3d957daf60  vmovaps xmm3, [rsp+0x20]
00007d3d957daf66  vmovaps xmm4, [rsp+0x30]
00007d3d957daf6c  vmovaps xmm5, [rsp+0x40]
00007d3d957daf72  vmovaps xmm6, [rsp+0x50]
00007d3d957daf78  vmovaps xmm7, [rsp+0x60]
00007d3d957daf7e  vmovaps xmm8, [rsp+0x70]
00007d3d957daf84  vmovaps xmm9, [rsp+0x80]
00007d3d957daf8d  vmovaps xmm10, [rsp+0x90]
00007d3d957daf96  vmovaps xmm11, [rsp+0xA0]
00007d3d957daf9f  vmovaps xmm12, [rsp+0xB0]
00007d3d957dafa8  vmovaps xmm13, [rsp+0xC0]
00007d3d957dafb1  vmovaps xmm14, [rsp+0xD0]
00007d3d957dafba  vmovaps xmm15, [rsp+0xE0]
00007d3d957dafc3  add rsp, 0xF0
00007d3d957dafca  pop r11
00007d3d957dafcc  pop r10
00007d3d957dafce  pop r9
00007d3d957dafd0  pop r8
00007d3d957dafd2  pop rsi
00007d3d957dafd3  pop rdi
00007d3d957dafd4  pop rdx
00007d3d957dafd5  pop rcx
00007d3d957dafd6  pop rax
00007d3d957dafd7  add rsp, 0x08
00007d3d957dafdb  jmp 0x00007D3D957D659A
00007d3d957dafe0  call 0x00007D3D9560C260
00007d3d957dafe5  jmp 0x00007D3D957D65A8
00007d3d957dafea  call 0x00007D3D956DE950
00007d3d957dafef  jmp 0x00007D3D957D65B2
00007d3d957daff4  sub rsp, 0x08
00007d3d957daff8  push rax
00007d3d957daff9  push rcx
00007d3d957daffa  push rdx
00007d3d957daffb  push rdi
00007d3d957daffc  push rsi
00007d3d957daffd  push r8
00007d3d957dafff  push r9
00007d3d957db001  push r10
00007d3d957db003  push r11
00007d3d957db005  sub rsp, 0xF0
00007d3d957db00c  vmovaps [rsp], xmm0
00007d3d957db011  vmovaps [rsp+0x10], xmm1
00007d3d957db017  vmovaps [rsp+0x20], xmm2
00007d3d957db01d  vmovaps [rsp+0x30], xmm3
00007d3d957db023  vmovaps [rsp+0x40], xmm4
00007d3d957db029  vmovaps [rsp+0x50], xmm5
00007d3d957db02f  vmovaps [rsp+0x60], xmm6
00007d3d957db035  vmovaps [rsp+0x70], xmm7
00007d3d957db03b  vmovaps [rsp+0x80], xmm9
00007d3d957db044  vmovaps [rsp+0x90], xmm10
00007d3d957db04d  vmovaps [rsp+0xA0], xmm11
00007d3d957db056  vmovaps [rsp+0xB0], xmm12
00007d3d957db05f  vmovaps [rsp+0xC0], xmm13
00007d3d957db068  vmovaps [rsp+0xD0], xmm14
00007d3d957db071  vmovaps [rsp+0xE0], xmm15
00007d3d957db07a  sub rsp, 0x30
00007d3d957db07e  movaps [rsp], xmm8
00007d3d957db083  movaps [rsp+0x10], xmm15
00007d3d957db089  movaps [rsp+0x20], xmm7
00007d3d957db08e  lea rdi, [rsp]
00007d3d957db092  mov esi, 0x00
00007d3d957db097  mov rax, 0x56C27CB8A530
00007d3d957db0a1  call rax
00007d3d957db0a3  movaps xmm8, [rsp]
00007d3d957db0a8  add rsp, 0x30
00007d3d957db0ac  vmovaps xmm0, [rsp]
00007d3d957db0b1  vmovaps xmm1, [rsp+0x10]
00007d3d957db0b7  vmovaps xmm2, [rsp+0x20]
00007d3d957db0bd  vmovaps xmm3, [rsp+0x30]
00007d3d957db0c3  vmovaps xmm4, [rsp+0x40]
00007d3d957db0c9  vmovaps xmm5, [rsp+0x50]
00007d3d957db0cf  vmovaps xmm6, [rsp+0x60]
00007d3d957db0d5  vmovaps xmm7, [rsp+0x70]
00007d3d957db0db  vmovaps xmm9, [rsp+0x80]
00007d3d957db0e4  vmovaps xmm10, [rsp+0x90]
00007d3d957db0ed  vmovaps xmm11, [rsp+0xA0]
00007d3d957db0f6  vmovaps xmm12, [rsp+0xB0]
00007d3d957db0ff  vmovaps xmm13, [rsp+0xC0]
00007d3d957db108  vmovaps xmm14, [rsp+0xD0]
00007d3d957db111  vmovaps xmm15, [rsp+0xE0]
00007d3d957db11a  add rsp, 0xF0
00007d3d957db121  pop r11
00007d3d957db123  pop r10
00007d3d957db125  pop r9
00007d3d957db127  pop r8
00007d3d957db129  pop rsi
00007d3d957db12a  pop rdi
00007d3d957db12b  pop rdx
00007d3d957db12c  pop rcx
00007d3d957db12d  pop rax
00007d3d957db12e  add rsp, 0x08
00007d3d957db132  jmp 0x00007D3D957D65D4
00007d3d957db137  sub rsp, 0x08
00007d3d957db13b  push rax
00007d3d957db13c  push rcx
00007d3d957db13d  push rdx
00007d3d957db13e  push rdi
00007d3d957db13f  push rsi
00007d3d957db140  push r8
00007d3d957db142  push r9
00007d3d957db144  push r10
00007d3d957db146  push r11
00007d3d957db148  sub rsp, 0xF0
00007d3d957db14f  vmovaps [rsp], xmm0
00007d3d957db154  vmovaps [rsp+0x10], xmm1
00007d3d957db15a  vmovaps [rsp+0x20], xmm2
00007d3d957db160  vmovaps [rsp+0x30], xmm3
00007d3d957db166  vmovaps [rsp+0x40], xmm4
00007d3d957db16c  vmovaps [rsp+0x50], xmm5
00007d3d957db172  vmovaps [rsp+0x60], xmm6
00007d3d957db178  vmovaps [rsp+0x70], xmm8
00007d3d957db17e  vmovaps [rsp+0x80], xmm9
00007d3d957db187  vmovaps [rsp+0x90], xmm10
00007d3d957db190  vmovaps [rsp+0xA0], xmm11
00007d3d957db199  vmovaps [rsp+0xB0], xmm12
00007d3d957db1a2  vmovaps [rsp+0xC0], xmm13
00007d3d957db1ab  vmovaps [rsp+0xD0], xmm14
00007d3d957db1b4  vmovaps [rsp+0xE0], xmm15
00007d3d957db1bd  sub rsp, 0x30
00007d3d957db1c1  movaps [rsp], xmm7
00007d3d957db1c5  movaps [rsp+0x10], xmm9
00007d3d957db1cb  movaps [rsp+0x20], xmm15
00007d3d957db1d1  lea rdi, [rsp]
00007d3d957db1d5  mov esi, 0x00
00007d3d957db1da  mov rax, 0x56C27CB8A530
00007d3d957db1e4  call rax
00007d3d957db1e6  movaps xmm7, [rsp]
00007d3d957db1ea  add rsp, 0x30
00007d3d957db1ee  vmovaps xmm0, [rsp]
00007d3d957db1f3  vmovaps xmm1, [rsp+0x10]
00007d3d957db1f9  vmovaps xmm2, [rsp+0x20]
00007d3d957db1ff  vmovaps xmm3, [rsp+0x30]
00007d3d957db205  vmovaps xmm4, [rsp+0x40]
00007d3d957db20b  vmovaps xmm5, [rsp+0x50]
00007d3d957db211  vmovaps xmm6, [rsp+0x60]
00007d3d957db217  vmovaps xmm8, [rsp+0x70]
00007d3d957db21d  vmovaps xmm9, [rsp+0x80]
00007d3d957db226  vmovaps xmm10, [rsp+0x90]
00007d3d957db22f  vmovaps xmm11, [rsp+0xA0]
00007d3d957db238  vmovaps xmm12, [rsp+0xB0]
00007d3d957db241  vmovaps xmm13, [rsp+0xC0]
00007d3d957db24a  vmovaps xmm14, [rsp+0xD0]
00007d3d957db253  vmovaps xmm15, [rsp+0xE0]
00007d3d957db25c  add rsp, 0xF0
00007d3d957db263  pop r11
00007d3d957db265  pop r10
00007d3d957db267  pop r9
00007d3d957db269  pop r8
00007d3d957db26b  pop rsi
00007d3d957db26c  pop rdi
00007d3d957db26d  pop rdx
00007d3d957db26e  pop rcx
00007d3d957db26f  pop rax
00007d3d957db270  add rsp, 0x08
00007d3d957db274  jmp 0x00007D3D957D6601
00007d3d957db279  sub rsp, 0x08
00007d3d957db27d  push rax
00007d3d957db27e  push rcx
00007d3d957db27f  push rdx
00007d3d957db280  push rdi
00007d3d957db281  push rsi
00007d3d957db282  push r8
00007d3d957db284  push r9
00007d3d957db286  push r10
00007d3d957db288  push r11
00007d3d957db28a  sub rsp, 0xF0
00007d3d957db291  vmovaps [rsp], xmm0
00007d3d957db296  vmovaps [rsp+0x10], xmm1
00007d3d957db29c  vmovaps [rsp+0x20], xmm2
00007d3d957db2a2  vmovaps [rsp+0x30], xmm3
00007d3d957db2a8  vmovaps [rsp+0x40], xmm4
00007d3d957db2ae  vmovaps [rsp+0x50], xmm5
00007d3d957db2b4  vmovaps [rsp+0x60], xmm6
00007d3d957db2ba  vmovaps [rsp+0x70], xmm7
00007d3d957db2c0  vmovaps [rsp+0x80], xmm8
00007d3d957db2c9  vmovaps [rsp+0x90], xmm10
00007d3d957db2d2  vmovaps [rsp+0xA0], xmm11
00007d3d957db2db  vmovaps [rsp+0xB0], xmm12
00007d3d957db2e4  vmovaps [rsp+0xC0], xmm13
00007d3d957db2ed  vmovaps [rsp+0xD0], xmm14
00007d3d957db2f6  vmovaps [rsp+0xE0], xmm15
00007d3d957db2ff  sub rsp, 0x30
00007d3d957db303  movaps [rsp], xmm9
00007d3d957db308  movaps [rsp+0x10], xmm13
00007d3d957db30e  movaps [rsp+0x20], xmm15
00007d3d957db314  lea rdi, [rsp]
00007d3d957db318  mov esi, 0x00
00007d3d957db31d  mov rax, 0x56C27CB8A530
00007d3d957db327  call rax
00007d3d957db329  movaps xmm9, [rsp]
00007d3d957db32e  add rsp, 0x30
00007d3d957db332  vmovaps xmm0, [rsp]
00007d3d957db337  vmovaps xmm1, [rsp+0x10]
00007d3d957db33d  vmovaps xmm2, [rsp+0x20]
00007d3d957db343  vmovaps xmm3, [rsp+0x30]
00007d3d957db349  vmovaps xmm4, [rsp+0x40]
00007d3d957db34f  vmovaps xmm5, [rsp+0x50]
00007d3d957db355  vmovaps xmm6, [rsp+0x60]
00007d3d957db35b  vmovaps xmm7, [rsp+0x70]
00007d3d957db361  vmovaps xmm8, [rsp+0x80]
00007d3d957db36a  vmovaps xmm10, [rsp+0x90]
00007d3d957db373  vmovaps xmm11, [rsp+0xA0]
00007d3d957db37c  vmovaps xmm12, [rsp+0xB0]
00007d3d957db385  vmovaps xmm13, [rsp+0xC0]
00007d3d957db38e  vmovaps xmm14, [rsp+0xD0]
00007d3d957db397  vmovaps xmm15, [rsp+0xE0]
00007d3d957db3a0  add rsp, 0xF0
00007d3d957db3a7  pop r11
00007d3d957db3a9  pop r10
00007d3d957db3ab  pop r9
00007d3d957db3ad  pop r8
00007d3d957db3af  pop rsi
00007d3d957db3b0  pop rdi
00007d3d957db3b1  pop rdx
00007d3d957db3b2  pop rcx
00007d3d957db3b3  pop rax
00007d3d957db3b4  add rsp, 0x08
00007d3d957db3b8  jmp 0x00007D3D957D662F
00007d3d957db3bd  sub rsp, 0x08
00007d3d957db3c1  push rax
00007d3d957db3c2  push rcx
00007d3d957db3c3  push rdx
00007d3d957db3c4  push rdi
00007d3d957db3c5  push rsi
00007d3d957db3c6  push r8
00007d3d957db3c8  push r9
00007d3d957db3ca  push r10
00007d3d957db3cc  push r11
00007d3d957db3ce  sub rsp, 0xF0
00007d3d957db3d5  vmovaps [rsp], xmm0
00007d3d957db3da  vmovaps [rsp+0x10], xmm1
00007d3d957db3e0  vmovaps [rsp+0x20], xmm2
00007d3d957db3e6  vmovaps [rsp+0x30], xmm3
00007d3d957db3ec  vmovaps [rsp+0x40], xmm4
00007d3d957db3f2  vmovaps [rsp+0x50], xmm5
00007d3d957db3f8  vmovaps [rsp+0x60], xmm6
00007d3d957db3fe  vmovaps [rsp+0x70], xmm7
00007d3d957db404  vmovaps [rsp+0x80], xmm8
00007d3d957db40d  vmovaps [rsp+0x90], xmm9
00007d3d957db416  vmovaps [rsp+0xA0], xmm10
00007d3d957db41f  vmovaps [rsp+0xB0], xmm11
00007d3d957db428  vmovaps [rsp+0xC0], xmm12
00007d3d957db431  vmovaps [rsp+0xD0], xmm13
00007d3d957db43a  vmovaps [rsp+0xE0], xmm14
00007d3d957db443  sub rsp, 0x30
00007d3d957db447  movaps [rsp], xmm15
00007d3d957db44c  movaps [rsp+0x10], xmm11
00007d3d957db452  movaps [rsp+0x20], xmm12
00007d3d957db458  lea rdi, [rsp]
00007d3d957db45c  mov esi, 0x00
00007d3d957db461  mov rax, 0x56C27CB8A530
00007d3d957db46b  call rax
00007d3d957db46d  movaps xmm15, [rsp]
00007d3d957db472  add rsp, 0x30
00007d3d957db476  vmovaps xmm0, [rsp]
00007d3d957db47b  vmovaps xmm1, [rsp+0x10]
00007d3d957db481  vmovaps xmm2, [rsp+0x20]
00007d3d957db487  vmovaps xmm3, [rsp+0x30]
00007d3d957db48d  vmovaps xmm4, [rsp+0x40]
00007d3d957db493  vmovaps xmm5, [rsp+0x50]
00007d3d957db499  vmovaps xmm6, [rsp+0x60]
00007d3d957db49f  vmovaps xmm7, [rsp+0x70]
00007d3d957db4a5  vmovaps xmm8, [rsp+0x80]
00007d3d957db4ae  vmovaps xmm9, [rsp+0x90]
00007d3d957db4b7  vmovaps xmm10, [rsp+0xA0]
00007d3d957db4c0  vmovaps xmm11, [rsp+0xB0]
00007d3d957db4c9  vmovaps xmm12, [rsp+0xC0]
00007d3d957db4d2  vmovaps xmm13, [rsp+0xD0]
00007d3d957db4db  vmovaps xmm14, [rsp+0xE0]
00007d3d957db4e4  add rsp, 0xF0
00007d3d957db4eb  pop r11
00007d3d957db4ed  pop r10
00007d3d957db4ef  pop r9
00007d3d957db4f1  pop r8
00007d3d957db4f3  pop rsi
00007d3d957db4f4  pop rdi
00007d3d957db4f5  pop rdx
00007d3d957db4f6  pop rcx
00007d3d957db4f7  pop rax
00007d3d957db4f8  add rsp, 0x08
00007d3d957db4fc  jmp 0x00007D3D957D664A
00007d3d957db501  sub rsp, 0x08
00007d3d957db505  push rax
00007d3d957db506  push rcx
00007d3d957db507  push rdx
00007d3d957db508  push rdi
00007d3d957db509  push rsi
00007d3d957db50a  push r8
00007d3d957db50c  push r9
00007d3d957db50e  push r10
00007d3d957db510  push r11
00007d3d957db512  sub rsp, 0xF0
00007d3d957db519  vmovaps [rsp], xmm0
00007d3d957db51e  vmovaps [rsp+0x10], xmm1
00007d3d957db524  vmovaps [rsp+0x20], xmm2
00007d3d957db52a  vmovaps [rsp+0x30], xmm3
00007d3d957db530  vmovaps [rsp+0x40], xmm4
00007d3d957db536  vmovaps [rsp+0x50], xmm5
00007d3d957db53c  vmovaps [rsp+0x60], xmm6
00007d3d957db542  vmovaps [rsp+0x70], xmm7
00007d3d957db548  vmovaps [rsp+0x80], xmm8
00007d3d957db551  vmovaps [rsp+0x90], xmm9
00007d3d957db55a  vmovaps [rsp+0xA0], xmm10
00007d3d957db563  vmovaps [rsp+0xB0], xmm11
00007d3d957db56c  vmovaps [rsp+0xC0], xmm12
00007d3d957db575  vmovaps [rsp+0xD0], xmm14
00007d3d957db57e  vmovaps [rsp+0xE0], xmm15
00007d3d957db587  sub rsp, 0x30
00007d3d957db58b  movaps [rsp], xmm13
00007d3d957db590  movaps [rsp+0x10], xmm10
00007d3d957db596  movaps [rsp+0x20], xmm14
00007d3d957db59c  lea rdi, [rsp]
00007d3d957db5a0  mov esi, 0x00
00007d3d957db5a5  mov rax, 0x56C27CB8A530
00007d3d957db5af  call rax
00007d3d957db5b1  movaps xmm13, [rsp]
00007d3d957db5b6  add rsp, 0x30
00007d3d957db5ba  vmovaps xmm0, [rsp]
00007d3d957db5bf  vmovaps xmm1, [rsp+0x10]
00007d3d957db5c5  vmovaps xmm2, [rsp+0x20]
00007d3d957db5cb  vmovaps xmm3, [rsp+0x30]
00007d3d957db5d1  vmovaps xmm4, [rsp+0x40]
00007d3d957db5d7  vmovaps xmm5, [rsp+0x50]
00007d3d957db5dd  vmovaps xmm6, [rsp+0x60]
00007d3d957db5e3  vmovaps xmm7, [rsp+0x70]
00007d3d957db5e9  vmovaps xmm8, [rsp+0x80]
00007d3d957db5f2  vmovaps xmm9, [rsp+0x90]
00007d3d957db5fb  vmovaps xmm10, [rsp+0xA0]
00007d3d957db604  vmovaps xmm11, [rsp+0xB0]
00007d3d957db60d  vmovaps xmm12, [rsp+0xC0]
00007d3d957db616  vmovaps xmm14, [rsp+0xD0]
00007d3d957db61f  vmovaps xmm15, [rsp+0xE0]
00007d3d957db628  add rsp, 0xF0
00007d3d957db62f  pop r11
00007d3d957db631  pop r10
00007d3d957db633  pop r9
00007d3d957db635  pop r8
00007d3d957db637  pop rsi
00007d3d957db638  pop rdi
00007d3d957db639  pop rdx
00007d3d957db63a  pop rcx
00007d3d957db63b  pop rax
00007d3d957db63c  add rsp, 0x08
00007d3d957db640  jmp 0x00007D3D957D666D
00007d3d957db645  sub rsp, 0x08
00007d3d957db649  push rax
00007d3d957db64a  push rcx
00007d3d957db64b  push rdx
00007d3d957db64c  push rdi
00007d3d957db64d  push rsi
00007d3d957db64e  push r8
00007d3d957db650  push r9
00007d3d957db652  push r10
00007d3d957db654  push r11
00007d3d957db656  sub rsp, 0xF0
00007d3d957db65d  vmovaps [rsp], xmm0
00007d3d957db662  vmovaps [rsp+0x10], xmm1
00007d3d957db668  vmovaps [rsp+0x20], xmm2
00007d3d957db66e  vmovaps [rsp+0x30], xmm3
00007d3d957db674  vmovaps [rsp+0x40], xmm4
00007d3d957db67a  vmovaps [rsp+0x50], xmm5
00007d3d957db680  vmovaps [rsp+0x60], xmm6
00007d3d957db686  vmovaps [rsp+0x70], xmm7
00007d3d957db68c  vmovaps [rsp+0x80], xmm8
00007d3d957db695  vmovaps [rsp+0x90], xmm9
00007d3d957db69e  vmovaps [rsp+0xA0], xmm10
00007d3d957db6a7  vmovaps [rsp+0xB0], xmm11
00007d3d957db6b0  vmovaps [rsp+0xC0], xmm12
00007d3d957db6b9  vmovaps [rsp+0xD0], xmm13
00007d3d957db6c2  vmovaps [rsp+0xE0], xmm15
00007d3d957db6cb  sub rsp, 0x30
00007d3d957db6cf  movaps [rsp], xmm14
00007d3d957db6d4  movaps [rsp+0x10], xmm1
00007d3d957db6d9  movaps [rsp+0x20], xmm7
00007d3d957db6de  lea rdi, [rsp]
00007d3d957db6e2  mov esi, 0x00
00007d3d957db6e7  mov rax, 0x56C27CB8A530
00007d3d957db6f1  call rax
00007d3d957db6f3  movaps xmm14, [rsp]
00007d3d957db6f8  add rsp, 0x30
00007d3d957db6fc  vmovaps xmm0, [rsp]
00007d3d957db701  vmovaps xmm1, [rsp+0x10]
00007d3d957db707  vmovaps xmm2, [rsp+0x20]
00007d3d957db70d  vmovaps xmm3, [rsp+0x30]
00007d3d957db713  vmovaps xmm4, [rsp+0x40]
00007d3d957db719  vmovaps xmm5, [rsp+0x50]
00007d3d957db71f  vmovaps xmm6, [rsp+0x60]
00007d3d957db725  vmovaps xmm7, [rsp+0x70]
00007d3d957db72b  vmovaps xmm8, [rsp+0x80]
00007d3d957db734  vmovaps xmm9, [rsp+0x90]
00007d3d957db73d  vmovaps xmm10, [rsp+0xA0]
00007d3d957db746  vmovaps xmm11, [rsp+0xB0]
00007d3d957db74f  vmovaps xmm12, [rsp+0xC0]
00007d3d957db758  vmovaps xmm13, [rsp+0xD0]
00007d3d957db761  vmovaps xmm15, [rsp+0xE0]
00007d3d957db76a  add rsp, 0xF0
00007d3d957db771  pop r11
00007d3d957db773  pop r10
00007d3d957db775  pop r9
00007d3d957db777  pop r8
00007d3d957db779  pop rsi
00007d3d957db77a  pop rdi
00007d3d957db77b  pop rdx
00007d3d957db77c  pop rcx
00007d3d957db77d  pop rax
00007d3d957db77e  add rsp, 0x08
00007d3d957db782  jmp 0x00007D3D957D6690
00007d3d957db787  sub rsp, 0x08
00007d3d957db78b  push rax
00007d3d957db78c  push rcx
00007d3d957db78d  push rdx
00007d3d957db78e  push rdi
00007d3d957db78f  push rsi
00007d3d957db790  push r8
00007d3d957db792  push r9
00007d3d957db794  push r10
00007d3d957db796  push r11
00007d3d957db798  sub rsp, 0xF0
00007d3d957db79f  vmovaps [rsp], xmm0
00007d3d957db7a4  vmovaps [rsp+0x10], xmm2
00007d3d957db7aa  vmovaps [rsp+0x20], xmm3
00007d3d957db7b0  vmovaps [rsp+0x30], xmm4
00007d3d957db7b6  vmovaps [rsp+0x40], xmm5
00007d3d957db7bc  vmovaps [rsp+0x50], xmm6
00007d3d957db7c2  vmovaps [rsp+0x60], xmm7
00007d3d957db7c8  vmovaps [rsp+0x70], xmm8
00007d3d957db7ce  vmovaps [rsp+0x80], xmm9
00007d3d957db7d7  vmovaps [rsp+0x90], xmm10
00007d3d957db7e0  vmovaps [rsp+0xA0], xmm11
00007d3d957db7e9  vmovaps [rsp+0xB0], xmm12
00007d3d957db7f2  vmovaps [rsp+0xC0], xmm13
00007d3d957db7fb  vmovaps [rsp+0xD0], xmm14
00007d3d957db804  vmovaps [rsp+0xE0], xmm15
00007d3d957db80d  sub rsp, 0x30
00007d3d957db811  movaps [rsp], xmm1
00007d3d957db815  movaps [rsp+0x10], xmm8
00007d3d957db81b  movaps [rsp+0x20], xmm9
00007d3d957db821  lea rdi, [rsp]
00007d3d957db825  mov esi, 0x00
00007d3d957db82a  mov rax, 0x56C27CB8A530
00007d3d957db834  call rax
00007d3d957db836  movaps xmm1, [rsp]
00007d3d957db83a  add rsp, 0x30
00007d3d957db83e  vmovaps xmm0, [rsp]
00007d3d957db843  vmovaps xmm2, [rsp+0x10]
00007d3d957db849  vmovaps xmm3, [rsp+0x20]
00007d3d957db84f  vmovaps xmm4, [rsp+0x30]
00007d3d957db855  vmovaps xmm5, [rsp+0x40]
00007d3d957db85b  vmovaps xmm6, [rsp+0x50]
00007d3d957db861  vmovaps xmm7, [rsp+0x60]
00007d3d957db867  vmovaps xmm8, [rsp+0x70]
00007d3d957db86d  vmovaps xmm9, [rsp+0x80]
00007d3d957db876  vmovaps xmm10, [rsp+0x90]
00007d3d957db87f  vmovaps xmm11, [rsp+0xA0]
00007d3d957db888  vmovaps xmm12, [rsp+0xB0]
00007d3d957db891  vmovaps xmm13, [rsp+0xC0]
00007d3d957db89a  vmovaps xmm14, [rsp+0xD0]
00007d3d957db8a3  vmovaps xmm15, [rsp+0xE0]
00007d3d957db8ac  add rsp, 0xF0
00007d3d957db8b3  pop r11
00007d3d957db8b5  pop r10
00007d3d957db8b7  pop r9
00007d3d957db8b9  pop r8
00007d3d957db8bb  pop rsi
00007d3d957db8bc  pop rdi
00007d3d957db8bd  pop rdx
00007d3d957db8be  pop rcx
00007d3d957db8bf  pop rax
00007d3d957db8c0  add rsp, 0x08
00007d3d957db8c4  jmp 0x00007D3D957D66B2
00007d3d957db8c9  call 0x00007D3D956B3E40
00007d3d957db8ce  jmp 0x00007D3D957D66C0
00007d3d957db8d3  call 0x00007D3D9560C380
00007d3d957db8d8  jmp 0x00007D3D957D66CA
00007d3d957db8dd  call 0x00007D3D9560D600
00007d3d957db8e2  jmp 0x00007D3D957D66D4
00007d3d957db8e7  call 0x00007D3D955FF540
00007d3d957db8ec  jmp 0x00007D3D957D66DE
00007d3d957db8f1  int3
00007d3d957db8f2  nop [rax+rax*1], ax
00007d3d957db8fb  nop [rax+rax*1], eax
00007d3d957db900  mov eax, [r15+0x48]
00007d3d957db904  lea r14d, [eax+0x01]
00007d3d957db909  mov [rsp+0x10], r14d
00007d3d957db90e  mov r14d, r14d
00007d3d957db911  mov [r15+0x48], r14
00007d3d957db915  xor eax, eax
00007d3d957db917  mov r14d, [rsp+0x10]
00007d3d957db91c  cmp r14d, 0x1F4
00007d3d957db923  cmc
00007d3d957db924  lahf
00007d3d957db925  seto al
00007d3d957db928  mov [r15+0x108], eax
00007d3d957db92f  mov eax, [r15+0x108]
00007d3d957db936  sahf
00007d3d957db937  jnz 0x00007D3D957DB969
00007d3d957db939  cmp dword ptr [r15+0x318], 0x00
00007d3d957db941  jz 0x00007D3D957E1AB0
00007d3d957db947  nop [rax+rax*1], ax
00007d3d957db950  nop [rax+rax*1], eax
00007d3d957db958  mov eax, 0x410450
00007d3d957db95d  mov [r15+0x100], rax
00007d3d957db964  jmp 0x00007D3D955FE110
00007d3d957db969  cmp dword ptr [r15+0x318], 0x00
00007d3d957db971  jz 0x00007D3D957DB9A0
00007d3d957db977  nop [rax+rax*1], ax
00007d3d957db980  nop [rax+rax*1], eax
00007d3d957db988  mov eax, 0x410274
00007d3d957db98d  mov [r15+0x100], rax
00007d3d957db994  jmp 0x00007D3D955FE110
00007d3d957db999  int3
00007d3d957db99a  int3
00007d3d957db99b  nop [rax+rax*1], eax
00007d3d957db9a0  mov rax, [r15+0x40]
00007d3d957db9a4  movaps xmm1, [r15+0x1D0]
00007d3d957db9ac  vmovaps [rsp+0x10], xmm1
00007d3d957db9b2  vmovaps xmm15, [rsp+0x10]
00007d3d957db9b8  por xmm1, xmm15
00007d3d957db9bd  movaps xmm14, [r15+0x1A0]
00007d3d957db9c5  vmovaps [rsp+0x10], xmm14
00007d3d957db9cb  vmovaps xmm13, [rsp+0x10]
00007d3d957db9d1  por xmm14, xmm13
00007d3d957db9d6  lea r14, [rax+0x30]
00007d3d957db9da  mov r12, [r13+r14*1]
00007d3d957db9df  lea r14, [rax+0x38]
00007d3d957db9e3  mov r11, [r13+r14*1]
00007d3d957db9e8  movq xmm13, r12
00007d3d957db9ed  movq xmm12, r11
00007d3d957db9f2  movq xmm13, xmm13
00007d3d957db9f7  vmovaps [rsp+0x10], xmm13
00007d3d957db9fd  movq xmm13, xmm13
00007d3d957dba02  movaps [r15+0x130], xmm13
00007d3d957dba0a  movq xmm12, xmm12
00007d3d957dba0f  vmovaps [rsp+0x20], xmm12
00007d3d957dba15  movq xmm12, xmm12
00007d3d957dba1a  movaps [r15+0x280], xmm12
00007d3d957dba22  movaps xmm13, [r15+0x270]
00007d3d957dba2a  vmovaps [rsp+0x30], xmm13
00007d3d957dba30  vmovaps xmm12, [rsp+0x30]
00007d3d957dba36  por xmm13, xmm12
00007d3d957dba3b  lea r14, [rax+0x20]
00007d3d957dba3f  mov r12, [r13+r14*1]
00007d3d957dba44  lea r14, [rax+0x28]
00007d3d957dba48  mov r11, [r13+r14*1]
00007d3d957dba4d  movq xmm12, r12
00007d3d957dba52  movq xmm11, r11
00007d3d957dba57  movq xmm12, xmm12
00007d3d957dba5c  vmovaps [rsp+0x30], xmm12
00007d3d957dba62  movq xmm12, xmm12
00007d3d957dba67  movaps [r15+0x150], xmm12
00007d3d957dba6f  movq xmm11, xmm11
00007d3d957dba74  vmovaps [rsp+0x40], xmm11
00007d3d957dba7a  movq xmm11, xmm11
00007d3d957dba7f  movaps [r15+0x140], xmm11
00007d3d957dba87  lea r14, [rax+0x10]
00007d3d957dba8b  mov r12, [r13+r14*1]
00007d3d957dba90  lea r14, [rax+0x18]
00007d3d957dba94  mov r11, [r13+r14*1]
00007d3d957dba99  movq xmm12, r12
00007d3d957dba9e  movq xmm11, r11
00007d3d957dbaa3  movq xmm12, xmm12
00007d3d957dbaa8  vmovaps [rsp+0x50], xmm12
00007d3d957dbaae  movq xmm12, xmm12
00007d3d957dbab3  movaps [r15+0x170], xmm12
00007d3d957dbabb  movq xmm11, xmm11
00007d3d957dbac0  vmovaps [rsp+0x60], xmm11
00007d3d957dbac6  movq xmm11, xmm11
00007d3d957dbacb  movaps [r15+0x160], xmm11
00007d3d957dbad3  mov r14, [r13+rax*1]
00007d3d957dbad8  vmovq xmm12, r14
00007d3d957dbadd  vpbroadcastq xmm12, xmm12
00007d3d957dbae2  lea r14, [rax+0x08]
00007d3d957dbae6  mov rax, [r13+r14*1]
00007d3d957dbaeb  movq xmm11, rax
00007d3d957dbaf0  movaps [r15+0x230], xmm11
00007d3d957dbaf8  mov rax, [r15+0xF8]
00007d3d957dbaff  lea r14, [rax+0x50]
00007d3d957dbb03  movups xmm11, [r13+r14*1]
00007d3d957dbb09  lea r14, [rax+0x60]
00007d3d957dbb0d  movups xmm10, [r13+r14*1]
00007d3d957dbb13  lea r14, [rax+0x30]
00007d3d957dbb17  movups xmm9, [r13+r14*1]
00007d3d957dbb1d  mov r14, [r15+0x50]
00007d3d957dbb21  mov [r15+0x60], r14
00007d3d957dbb25  mov qword ptr [r15+0x58], 0x40
00007d3d957dbb2d  movaps xmm8, xmm12
00007d3d957dbb31  mulpd xmm8, xmm15
00007d3d957dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007d3d957dbb3c  ptest xmm7, xmm7
00007d3d957dbb41  jnz 0x00007D3D957DC96A
00007d3d957dbb47  movq xmm15, qword ptr [r15+0x230]
00007d3d957dbb50  vmovaps [rsp+0x70], xmm15
00007d3d957dbb56  vpermilpd xmm15, xmm15, 0x00
00007d3d957dbb5c  movaps xmm7, xmm9
00007d3d957dbb60  mulpd xmm7, xmm15
00007d3d957dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007d3d957dbb6a  ptest xmm6, xmm6
00007d3d957dbb6f  jnz 0x00007D3D957DCAAE
00007d3d957dbb75  vxorps xmm15, xmm15, xmm15
00007d3d957dbb7a  vpbroadcastq xmm15, xmm15
00007d3d957dbb7f  movaps xmm9, xmm12
00007d3d957dbb83  mulpd xmm9, xmm10
00007d3d957dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007d3d957dbb8e  ptest xmm6, xmm6
00007d3d957dbb93  jnz 0x00007D3D957DCBF0
00007d3d957dbb99  movaps xmm10, xmm12
00007d3d957dbb9d  mulpd xmm10, xmm11
00007d3d957dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007d3d957dbba8  ptest xmm6, xmm6
00007d3d957dbbad  jnz 0x00007D3D957DCD34
00007d3d957dbbb3  movaps xmm11, [r15+0x1F0]
00007d3d957dbbbb  movaps xmm6, xmm12
00007d3d957dbbbf  mulpd xmm6, xmm11
00007d3d957dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007d3d957dbbc9  ptest xmm5, xmm5
00007d3d957dbbce  jnz 0x00007D3D957DCE78
00007d3d957dbbd4  movaps xmm12, [r15+0x2A0]
00007d3d957dbbdc  vmovaps [rsp+0x80], xmm12
00007d3d957dbbe5  vmovaps xmm11, [rsp+0x80]
00007d3d957dbbee  por xmm12, xmm11
00007d3d957dbbf3  movaps xmm11, [r15+0x250]
00007d3d957dbbfb  vmovaps [rsp+0x80], xmm11
00007d3d957dbc04  vmovaps xmm5, [rsp+0x80]
00007d3d957dbc0d  por xmm11, xmm5
00007d3d957dbc12  vmovaps xmm4, [rsp+0x70]
00007d3d957dbc18  vpermilpd xmm4, xmm4, 0x00
00007d3d957dbc1e  movaps xmm3, xmm5
00007d3d957dbc21  mulpd xmm3, xmm4
00007d3d957dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007d3d957dbc2a  ptest xmm2, xmm2
00007d3d957dbc2f  jnz 0x00007D3D957DCFBA
00007d3d957dbc35  mov [rsp+0x80], rax
00007d3d957dbc3d  xor eax, eax
00007d3d957dbc3f  mov r12d, 0x40
00007d3d957dbc45  mov r11d, 0x200
00007d3d957dbc4b  cmp r12, r11
00007d3d957dbc4e  cmc
00007d3d957dbc4f  lahf
00007d3d957dbc50  seto al
00007d3d957dbc53  mov [r15+0x108], eax
00007d3d957dbc5a  movaps xmm5, xmm8
00007d3d957dbc5e  addpd xmm5, xmm15
00007d3d957dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007d3d957dbc68  ptest xmm4, xmm4
00007d3d957dbc6d  jnz 0x00007D3D957DD0FA
00007d3d957dbc73  movaps xmm8, [r15+0x1B0]
00007d3d957dbc7b  movaps xmm4, xmm9
00007d3d957dbc7f  addpd xmm4, xmm8
00007d3d957dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007d3d957dbc89  ptest xmm2, xmm2
00007d3d957dbc8e  jnz 0x00007D3D957DD23C
00007d3d957dbc94  movaps xmm9, xmm10
00007d3d957dbc98  addpd xmm9, xmm8
00007d3d957dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007d3d957dbca3  ptest xmm2, xmm2
00007d3d957dbca8  jnz 0x00007D3D957DD37E
00007d3d957dbcae  movaps xmm10, [r15+0x2F0]
00007d3d957dbcb6  vmovaps [rsp+0x90], xmm10
00007d3d957dbcbf  vmovaps xmm8, [rsp+0x90]
00007d3d957dbcc8  por xmm10, xmm8
00007d3d957dbccd  movaps xmm8, [r15+0x2E0]
00007d3d957dbcd5  vmovaps [rsp+0x90], xmm8
00007d3d957dbcde  vmovaps xmm2, [rsp+0x90]
00007d3d957dbce7  por xmm8, xmm2
00007d3d957dbcec  movaps xmm2, [r15+0x2D0]
00007d3d957dbcf4  vmovaps [rsp+0x90], xmm2
00007d3d957dbcfd  vmovaps [rsp+0xA0], xmm1
00007d3d957dbd06  vmovaps xmm1, [rsp+0x90]
00007d3d957dbd0f  por xmm2, xmm1
00007d3d957dbd13  movaps xmm1, [r15+0x200]
00007d3d957dbd1b  vmovaps [rsp+0x90], xmm1
00007d3d957dbd24  vmovaps [rsp+0xB0], xmm15
00007d3d957dbd2d  vmovaps xmm15, [rsp+0x90]
00007d3d957dbd36  por xmm1, xmm15
00007d3d957dbd3b  movaps xmm15, [r15+0x1C0]
00007d3d957dbd43  vmovaps [rsp+0x90], xmm15
00007d3d957dbd4c  vmovaps [rsp+0xC0], xmm1
00007d3d957dbd55  vmovaps xmm1, [rsp+0x90]
00007d3d957dbd5e  por xmm15, xmm1
00007d3d957dbd63  movaps xmm1, [r15+0x190]
00007d3d957dbd6b  vmovaps [rsp+0x90], xmm1
00007d3d957dbd74  vmovaps [rsp+0xD0], xmm15
00007d3d957dbd7d  vmovaps xmm15, [rsp+0x90]
00007d3d957dbd86  por xmm1, xmm15
00007d3d957dbd8b  movaps xmm15, [r15+0x300]
00007d3d957dbd93  vmovaps [rsp+0x90], xmm15
00007d3d957dbd9c  vmovaps [rsp+0xE0], xmm1
00007d3d957dbda5  vmovaps xmm1, [rsp+0x90]
00007d3d957dbdae  por xmm15, xmm1
00007d3d957dbdb3  mov rax, [rsp+0x80]
00007d3d957dbdbb  lea r12, [rax+0xA0]
00007d3d957dbdc2  movups xmm1, [r13+r12*1]
00007d3d957dbdc8  lea r12, [rax+0xB0]
00007d3d957dbdcf  vmovaps [rsp+0x80], xmm1
00007d3d957dbdd8  movups xmm1, [r13+r12*1]
00007d3d957dbdde  vmovaps [rsp+0x90], xmm1
00007d3d957dbde7  vmovaps [rsp+0xF0], xmm15
00007d3d957dbdf0  vmovaps xmm15, [rsp+0xB0]
00007d3d957dbdf9  vmovaps [rsp+0xB0], xmm14
00007d3d957dbe02  movaps xmm1, xmm6
00007d3d957dbe05  addpd xmm1, xmm15
00007d3d957dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007d3d957dbe0f  ptest xmm14, xmm14
00007d3d957dbe15  jnz 0x00007D3D957DD4D6
00007d3d957dbe1b  lea r12, [rax+0xF0]
00007d3d957dbe22  movups xmm15, [r13+r12*1]
00007d3d957dbe28  movaps xmm14, xmm4
00007d3d957dbe2c  addpd xmm14, xmm3
00007d3d957dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007d3d957dbe37  ptest xmm6, xmm6
00007d3d957dbe3c  jnz 0x00007D3D957DD621
00007d3d957dbe42  movaps xmm6, xmm9
00007d3d957dbe46  addpd xmm6, xmm7
00007d3d957dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007d3d957dbe4f  ptest xmm4, xmm4
00007d3d957dbe54  jnz 0x00007D3D957DD763
00007d3d957dbe5a  vmovaps xmm9, [rsp+0x70]
00007d3d957dbe60  vpermilpd xmm9, xmm9, 0x00
00007d3d957dbe66  vmovaps xmm4, [rsp+0x90]
00007d3d957dbe6f  movaps xmm7, xmm4
00007d3d957dbe72  mulpd xmm7, xmm9
00007d3d957dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007d3d957dbe7c  ptest xmm3, xmm3
00007d3d957dbe81  jnz 0x00007D3D957DD8A4
00007d3d957dbe87  vmovaps xmm9, [rsp+0x50]
00007d3d957dbe8d  vpermilpd xmm9, xmm9, 0x00
00007d3d957dbe93  movaps xmm4, xmm15
00007d3d957dbe97  mulpd xmm4, xmm9
00007d3d957dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007d3d957dbea1  ptest xmm3, xmm3
00007d3d957dbea6  jnz 0x00007D3D957DD9E5
00007d3d957dbeac  lea r12, [rax+0xE0]
00007d3d957dbeb3  movups xmm15, [r13+r12*1]
00007d3d957dbeb9  vmovaps xmm9, [rsp+0x70]
00007d3d957dbebf  vpermilpd xmm9, xmm9, 0x00
00007d3d957dbec5  vmovaps [rsp+0x70], xmm1
00007d3d957dbecb  vmovaps xmm1, [rsp+0x80]
00007d3d957dbed4  vmovaps [rsp+0x80], xmm15
00007d3d957dbedd  movaps xmm3, xmm1
00007d3d957dbee0  mulpd xmm3, xmm9
00007d3d957dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007d3d957dbeea  ptest xmm15, xmm15
00007d3d957dbef0  jnz 0x00007D3D957DDB31
00007d3d957dbef6  vmovaps xmm1, [rsp+0xF0]
00007d3d957dbeff  vmovaps xmm15, [rsp+0xF0]
00007d3d957dbf08  por xmm1, xmm15
00007d3d957dbf0d  movaps [r15+0x300], xmm1
00007d3d957dbf15  vmovaps xmm15, [rsp+0xE0]
00007d3d957dbf1e  vmovaps xmm9, [rsp+0xE0]
00007d3d957dbf27  por xmm15, xmm9
00007d3d957dbf2c  movaps [r15+0x190], xmm15
00007d3d957dbf34  vmovaps xmm9, [rsp+0x50]
00007d3d957dbf3a  vpermilpd xmm9, xmm9, 0x00
00007d3d957dbf40  vmovaps [rsp+0x90], xmm1
00007d3d957dbf49  vmovaps [rsp+0xE0], xmm15
00007d3d957dbf52  vmovaps xmm15, [rsp+0x80]
00007d3d957dbf5b  vmovaps [rsp+0x80], xmm14
00007d3d957dbf64  movaps xmm1, xmm15
00007d3d957dbf68  mulpd xmm1, xmm9
00007d3d957dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007d3d957dbf72  ptest xmm14, xmm14
00007d3d957dbf78  jnz 0x00007D3D957DDC72
00007d3d957dbf7e  lea r12, [rax+0x90]
00007d3d957dbf85  movups xmm15, [r13+r12*1]
00007d3d957dbf8b  vmovaps xmm14, [rsp+0xD0]
00007d3d957dbf94  vmovaps xmm9, [rsp+0xD0]
00007d3d957dbf9d  por xmm14, xmm9
00007d3d957dbfa2  movaps [r15+0x1C0], xmm14
00007d3d957dbfaa  vmovaps xmm9, [rsp+0xC0]
00007d3d957dbfb3  vmovaps [rsp+0xD0], xmm1
00007d3d957dbfbc  vmovaps xmm1, [rsp+0xC0]
00007d3d957dbfc5  por xmm9, xmm1
00007d3d957dbfca  movaps [r15+0x200], xmm9
00007d3d957dbfd2  vmovaps [rsp+0xC0], xmm2
00007d3d957dbfdb  vmovaps xmm1, [rsp+0xC0]
00007d3d957dbfe4  por xmm2, xmm1
00007d3d957dbfe8  movaps [r15+0x2D0], xmm2
00007d3d957dbff0  vmovaps [rsp+0xC0], xmm8
00007d3d957dbff9  vmovaps xmm1, [rsp+0xC0]
00007d3d957dc002  por xmm8, xmm1
00007d3d957dc007  movaps [r15+0x2E0], xmm8
00007d3d957dc00f  vmovaps [rsp+0xC0], xmm15
00007d3d957dc018  movaps xmm1, xmm5
00007d3d957dc01b  addpd xmm1, xmm7
00007d3d957dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007d3d957dc024  ptest xmm15, xmm15
00007d3d957dc02a  jnz 0x00007D3D957DDDBE
00007d3d957dc030  vmovaps xmm15, [rsp+0x50]
00007d3d957dc036  vpermilpd xmm15, xmm15, 0x00
00007d3d957dc03c  vmovaps xmm5, [rsp+0xC0]
00007d3d957dc045  vmovaps [rsp+0xC0], xmm1
00007d3d957dc04e  movaps xmm7, xmm5
00007d3d957dc051  mulpd xmm7, xmm15
00007d3d957dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007d3d957dc05b  ptest xmm1, xmm1
00007d3d957dc060  jnz 0x00007D3D957DDEFE
00007d3d957dc066  lea r12, [rax+0x80]
00007d3d957dc06d  movups xmm1, [r13+r12*1]
00007d3d957dc073  vmovaps xmm5, [rsp+0x70]
00007d3d957dc079  vmovaps [rsp+0x70], xmm1
00007d3d957dc07f  movaps xmm15, xmm5
00007d3d957dc083  addpd xmm15, xmm3
00007d3d957dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007d3d957dc08e  ptest xmm1, xmm1
00007d3d957dc093  jnz 0x00007D3D957DE049
00007d3d957dc099  vmovaps xmm5, [rsp+0x80]
00007d3d957dc0a2  movaps xmm1, xmm5
00007d3d957dc0a5  addpd xmm1, xmm4
00007d3d957dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007d3d957dc0ae  ptest xmm3, xmm3
00007d3d957dc0b3  jnz 0x00007D3D957DE18B
00007d3d957dc0b9  vmovaps [rsp+0x80], xmm10
00007d3d957dc0c2  vmovaps xmm5, [rsp+0x80]
00007d3d957dc0cb  por xmm10, xmm5
00007d3d957dc0d0  movaps [r15+0x2F0], xmm10
00007d3d957dc0d8  vmovaps xmm5, [rsp+0x50]
00007d3d957dc0de  vpermilpd xmm5, xmm5, 0x00
00007d3d957dc0e4  vmovaps xmm3, [rsp+0x70]
00007d3d957dc0ea  vmovaps [rsp+0x50], xmm1
00007d3d957dc0f0  movaps xmm4, xmm3
00007d3d957dc0f3  mulpd xmm4, xmm5
00007d3d957dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007d3d957dc0fc  ptest xmm1, xmm1
00007d3d957dc101  jnz 0x00007D3D957DE2CB
00007d3d957dc107  lea r12, [rax+0xD0]
00007d3d957dc10e  movups xmm1, [r13+r12*1]
00007d3d957dc114  vmovaps xmm3, [rsp+0xD0]
00007d3d957dc11d  vmovaps [rsp+0x70], xmm1
00007d3d957dc123  movaps xmm5, xmm6
00007d3d957dc126  addpd xmm5, xmm3
00007d3d957dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007d3d957dc12f  ptest xmm1, xmm1
00007d3d957dc134  jnz 0x00007D3D957DE415
00007d3d957dc13a  vmovaps xmm1, [rsp+0x60]
00007d3d957dc140  vpermilpd xmm1, xmm1, 0x00
00007d3d957dc146  movaps xmm6, xmm9
00007d3d957dc14a  mulpd xmm6, xmm1
00007d3d957dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007d3d957dc153  ptest xmm3, xmm3
00007d3d957dc158  jnz 0x00007D3D957DE555
00007d3d957dc15e  movaps [r15+0x260], xmm6
00007d3d957dc166  vxorps xmm1, xmm1, xmm1
00007d3d957dc16a  vpbroadcastq xmm1, xmm1
00007d3d957dc16f  movaps [r15+0x1B0], xmm1
00007d3d957dc177  vmovaps xmm1, [rsp+0x60]
00007d3d957dc17d  vpermilpd xmm1, xmm1, 0x00
00007d3d957dc183  vmovaps xmm3, [rsp+0x70]
00007d3d957dc189  vmovaps [rsp+0x70], xmm15
00007d3d957dc18f  movaps xmm9, xmm3
00007d3d957dc193  mulpd xmm9, xmm1
00007d3d957dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007d3d957dc19e  ptest xmm15, xmm15
00007d3d957dc1a4  jnz 0x00007D3D957DE696
00007d3d957dc1aa  lea r12, [rax+0xC0]
00007d3d957dc1b1  movups xmm1, [r13+r12*1]
00007d3d957dc1b7  vmovaps xmm3, [rsp+0xC0]
00007d3d957dc1c0  vmovaps [rsp+0x80], xmm1
00007d3d957dc1c9  movaps xmm15, xmm3
00007d3d957dc1cd  addpd xmm15, xmm7
00007d3d957dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007d3d957dc1d8  ptest xmm1, xmm1
00007d3d957dc1dd  jnz 0x00007D3D957DE7E2
00007d3d957dc1e3  vmovaps [rsp+0xC0], xmm13
00007d3d957dc1ec  vmovaps xmm1, [rsp+0xC0]
00007d3d957dc1f5  por xmm13, xmm1
00007d3d957dc1fa  movaps [r15+0x270], xmm13
00007d3d957dc202  vmovaps xmm1, [rsp+0xB0]
00007d3d957dc20b  vmovaps xmm7, [rsp+0xB0]
00007d3d957dc214  por xmm1, xmm7
00007d3d957dc218  movaps [r15+0x1A0], xmm1
00007d3d957dc220  vmovaps xmm1, [rsp+0x60]
00007d3d957dc226  vpermilpd xmm1, xmm1, 0x00
00007d3d957dc22c  vmovaps [rsp+0xB0], xmm1
00007d3d957dc235  vmovaps xmm1, [rsp+0x80]
00007d3d957dc23e  vmovaps [rsp+0x80], xmm15
00007d3d957dc247  vmovaps xmm15, [rsp+0xB0]
00007d3d957dc250  vmovaps [rsp+0xB0], xmm14
00007d3d957dc259  movaps xmm3, xmm1
00007d3d957dc25c  mulpd xmm3, xmm15
00007d3d957dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007d3d957dc266  ptest xmm14, xmm14
00007d3d957dc26c  jnz 0x00007D3D957DE924
00007d3d957dc272  lea r12, [rax+0x20]
00007d3d957dc276  movups xmm1, [r13+r12*1]
00007d3d957dc27c  movaps [r15+0x110], xmm1
00007d3d957dc284  vmovaps xmm14, [rsp+0x70]
00007d3d957dc28a  vmovaps [rsp+0x70], xmm1
00007d3d957dc290  movaps xmm15, xmm14
00007d3d957dc294  addpd xmm15, xmm4
00007d3d957dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007d3d957dc29f  ptest xmm1, xmm1
00007d3d957dc2a4  jnz 0x00007D3D957DEA6F
00007d3d957dc2aa  vmovaps xmm1, [rsp+0x60]
00007d3d957dc2b0  vpermilpd xmm1, xmm1, 0x00
00007d3d957dc2b6  movaps xmm14, xmm2
00007d3d957dc2ba  mulpd xmm14, xmm1
00007d3d957dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007d3d957dc2c5  ptest xmm4, xmm4
00007d3d957dc2ca  jnz 0x00007D3D957DEBB2
00007d3d957dc2d0  vmovaps xmm4, [rsp+0x50]
00007d3d957dc2d6  movaps xmm1, xmm4
00007d3d957dc2d9  addpd xmm1, xmm9
00007d3d957dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007d3d957dc2e3  ptest xmm2, xmm2
00007d3d957dc2e8  jnz 0x00007D3D957DECF4
00007d3d957dc2ee  vmovaps xmm9, [rsp+0x30]
00007d3d957dc2f4  vpermilpd xmm9, xmm9, 0x00
00007d3d957dc2fa  vmovaps xmm2, [rsp+0x70]
00007d3d957dc300  vmovaps [rsp+0x50], xmm1
00007d3d957dc306  movaps xmm4, xmm2
00007d3d957dc309  mulpd xmm4, xmm9
00007d3d957dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007d3d957dc313  ptest xmm1, xmm1
00007d3d957dc318  jnz 0x00007D3D957DEE35
00007d3d957dc31e  vmovaps xmm1, [rsp+0x30]
00007d3d957dc324  vpermilpd xmm1, xmm1, 0x00
00007d3d957dc32a  vmovaps xmm2, [rsp+0x90]
00007d3d957dc333  vmovaps [rsp+0x60], xmm15
00007d3d957dc339  movaps xmm9, xmm2
00007d3d957dc33d  mulpd xmm9, xmm1
00007d3d957dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007d3d957dc348  ptest xmm15, xmm15
00007d3d957dc34e  jnz 0x00007D3D957DEF76
00007d3d957dc354  vmovaps xmm15, [rsp+0x80]
00007d3d957dc35d  movaps xmm1, xmm15
00007d3d957dc361  addpd xmm1, xmm6
00007d3d957dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007d3d957dc36a  ptest xmm2, xmm2
00007d3d957dc36f  jnz 0x00007D3D957DF0B8
00007d3d957dc375  movaps xmm15, xmm5
00007d3d957dc379  addpd xmm15, xmm3
00007d3d957dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007d3d957dc384  ptest xmm6, xmm6
00007d3d957dc389  jnz 0x00007D3D957DF1F9
00007d3d957dc38f  vmovaps xmm6, [rsp+0x30]
00007d3d957dc395  vpermilpd xmm6, xmm6, 0x00
00007d3d957dc39b  movaps xmm5, xmm8
00007d3d957dc39f  mulpd xmm5, xmm6
00007d3d957dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007d3d957dc3a8  ptest xmm3, xmm3
00007d3d957dc3ad  jnz 0x00007D3D957DF33B
00007d3d957dc3b3  vmovaps xmm8, [rsp+0x30]
00007d3d957dc3b9  vpermilpd xmm8, xmm8, 0x00
00007d3d957dc3bf  movaps xmm6, xmm10
00007d3d957dc3c3  mulpd xmm6, xmm8
00007d3d957dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007d3d957dc3cd  ptest xmm3, xmm3
00007d3d957dc3d2  jnz 0x00007D3D957DF47C
00007d3d957dc3d8  vmovaps xmm8, [rsp+0x60]
00007d3d957dc3de  movaps xmm10, xmm8
00007d3d957dc3e2  addpd xmm10, xmm14
00007d3d957dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007d3d957dc3ed  ptest xmm3, xmm3
00007d3d957dc3f2  jnz 0x00007D3D957DF5BE
00007d3d957dc3f8  vmovaps xmm8, [rsp+0x50]
00007d3d957dc3fe  movaps xmm14, xmm8
00007d3d957dc402  addpd xmm14, xmm4
00007d3d957dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007d3d957dc40d  ptest xmm3, xmm3
00007d3d957dc412  jnz 0x00007D3D957DF702
00007d3d957dc418  vmovaps xmm8, [rsp+0x40]
00007d3d957dc41e  vpermilpd xmm8, xmm8, 0x00
00007d3d957dc424  movaps xmm4, xmm13
00007d3d957dc428  mulpd xmm4, xmm8
00007d3d957dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007d3d957dc432  ptest xmm3, xmm3
00007d3d957dc437  jnz 0x00007D3D957DF845
00007d3d957dc43d  movaps xmm13, xmm15
00007d3d957dc441  addpd xmm13, xmm9
00007d3d957dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007d3d957dc44c  ptest xmm8, xmm8
00007d3d957dc452  jnz 0x00007D3D957DF987
00007d3d957dc458  movaps xmm15, xmm1
00007d3d957dc45c  addpd xmm15, xmm5
00007d3d957dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007d3d957dc467  ptest xmm9, xmm9
00007d3d957dc46d  jnz 0x00007D3D957DFACB
00007d3d957dc473  vmovaps [rsp+0x30], xmm11
00007d3d957dc479  vmovaps xmm1, [rsp+0x30]
00007d3d957dc47f  por xmm11, xmm1
00007d3d957dc484  movaps [r15+0x250], xmm11
00007d3d957dc48c  vmovaps [rsp+0x30], xmm12
00007d3d957dc492  vmovaps xmm1, [rsp+0x30]
00007d3d957dc498  por xmm12, xmm1
00007d3d957dc49d  movaps [r15+0x2A0], xmm12
00007d3d957dc4a5  vmovaps xmm1, [rsp+0xA0]
00007d3d957dc4ae  vmovaps xmm11, [rsp+0xA0]
00007d3d957dc4b7  por xmm1, xmm11
00007d3d957dc4bc  movaps [r15+0x1D0], xmm1
00007d3d957dc4c4  lea r12, [rax+0x40]
00007d3d957dc4c8  movups xmm1, [r13+r12*1]
00007d3d957dc4ce  movaps [r15+0x2C0], xmm1
00007d3d957dc4d6  vmovaps xmm11, [rsp+0x40]
00007d3d957dc4dc  vpermilpd xmm11, xmm11, 0x00
00007d3d957dc4e2  vmovaps xmm8, [rsp+0xE0]
00007d3d957dc4eb  movaps xmm9, xmm8
00007d3d957dc4ef  mulpd xmm9, xmm11
00007d3d957dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007d3d957dc4fa  ptest xmm5, xmm5
00007d3d957dc4ff  jnz 0x00007D3D957DFC17
00007d3d957dc505  movaps xmm11, xmm10
00007d3d957dc509  addpd xmm11, xmm6
00007d3d957dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007d3d957dc514  ptest xmm8, xmm8
00007d3d957dc51a  jnz 0x00007D3D957DFD5B
00007d3d957dc520  movaps xmm10, xmm14
00007d3d957dc524  addpd xmm10, xmm4
00007d3d957dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007d3d957dc52f  ptest xmm8, xmm8
00007d3d957dc535  jnz 0x00007D3D957DFE9E
00007d3d957dc53b  vmovaps xmm14, [rsp+0x40]
00007d3d957dc541  vpermilpd xmm14, xmm14, 0x00
00007d3d957dc547  movaps xmm8, xmm1
00007d3d957dc54b  mulpd xmm8, xmm14
00007d3d957dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007d3d957dc556  ptest xmm6, xmm6
00007d3d957dc55b  jnz 0x00007D3D957DFFE1
00007d3d957dc561  movaps xmm1, [r15+0x2B0]
00007d3d957dc569  vmovaps xmm14, [rsp+0x40]
00007d3d957dc56f  vpermilpd xmm14, xmm14, 0x00
00007d3d957dc575  movaps xmm6, xmm1
00007d3d957dc578  mulpd xmm6, xmm14
00007d3d957dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007d3d957dc582  ptest xmm5, xmm5
00007d3d957dc587  jnz 0x00007D3D957E0124
00007d3d957dc58d  vmovaps xmm1, [rsp+0x10]
00007d3d957dc593  vpermilpd xmm1, xmm1, 0x00
00007d3d957dc599  movaps xmm14, xmm12
00007d3d957dc59d  mulpd xmm14, xmm1
00007d3d957dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007d3d957dc5a8  ptest xmm5, xmm5
00007d3d957dc5ad  jnz 0x00007D3D957E0265
00007d3d957dc5b3  movaps xmm1, xmm13
00007d3d957dc5b7  addpd xmm1, xmm9
00007d3d957dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007d3d957dc5c1  ptest xmm12, xmm12
00007d3d957dc5c7  jnz 0x00007D3D957E03A8
00007d3d957dc5cd  vmovaps xmm13, [rsp+0x10]
00007d3d957dc5d3  vpermilpd xmm13, xmm13, 0x00
00007d3d957dc5d9  movaps xmm12, xmm7
00007d3d957dc5dd  mulpd xmm12, xmm13
00007d3d957dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007d3d957dc5e8  ptest xmm9, xmm9
00007d3d957dc5ee  jnz 0x00007D3D957E04EA
00007d3d957dc5f4  movaps xmm13, xmm15
00007d3d957dc5f8  addpd xmm13, xmm8
00007d3d957dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007d3d957dc603  ptest xmm9, xmm9
00007d3d957dc609  jnz 0x00007D3D957E062D
00007d3d957dc60f  movaps xmm15, [r15+0x290]
00007d3d957dc617  vmovaps xmm9, [rsp+0x10]
00007d3d957dc61d  vpermilpd xmm9, xmm9, 0x00
00007d3d957dc623  movaps xmm8, xmm15
00007d3d957dc627  mulpd xmm8, xmm9
00007d3d957dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007d3d957dc632  ptest xmm7, xmm7
00007d3d957dc637  jnz 0x00007D3D957E0771
00007d3d957dc63d  movaps xmm15, xmm11
00007d3d957dc641  addpd xmm15, xmm6
00007d3d957dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007d3d957dc64c  ptest xmm9, xmm9
00007d3d957dc652  jnz 0x00007D3D957E08B5
00007d3d957dc658  movaps xmm11, [r15+0x1E0]
00007d3d957dc660  vmovaps xmm9, [rsp+0x10]
00007d3d957dc666  vpermilpd xmm9, xmm9, 0x00
00007d3d957dc66c  movaps xmm7, xmm11
00007d3d957dc670  mulpd xmm7, xmm9
00007d3d957dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007d3d957dc67a  ptest xmm6, xmm6
00007d3d957dc67f  jnz 0x00007D3D957E09F8
00007d3d957dc685  movaps xmm11, xmm10
00007d3d957dc689  addpd xmm11, xmm14
00007d3d957dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007d3d957dc694  ptest xmm9, xmm9
00007d3d957dc69a  jnz 0x00007D3D957E0B3A
00007d3d957dc6a0  lea r12, [rax+0x70]
00007d3d957dc6a4  movups xmm14, [r13+r12*1]
00007d3d957dc6aa  movaps [r15+0x240], xmm14
00007d3d957dc6b2  movaps xmm10, xmm1
00007d3d957dc6b6  addpd xmm10, xmm12
00007d3d957dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007d3d957dc6c1  ptest xmm9, xmm9
00007d3d957dc6c7  jnz 0x00007D3D957E0C88
00007d3d957dc6cd  movaps [r15+0x170], xmm10
00007d3d957dc6d5  vmovaps xmm1, [rsp+0x20]
00007d3d957dc6db  vpermilpd xmm1, xmm1, 0x00
00007d3d957dc6e1  movaps xmm12, xmm14
00007d3d957dc6e5  mulpd xmm12, xmm1
00007d3d957dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007d3d957dc6f0  ptest xmm9, xmm9
00007d3d957dc6f6  jnz 0x00007D3D957E0DCB
00007d3d957dc6fc  vmovaps xmm1, [rsp+0x20]
00007d3d957dc702  vpermilpd xmm1, xmm1, 0x00
00007d3d957dc708  vmovaps xmm9, [rsp+0xB0]
00007d3d957dc711  movaps xmm14, xmm9
00007d3d957dc715  mulpd xmm14, xmm1
00007d3d957dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007d3d957dc720  ptest xmm6, xmm6
00007d3d957dc725  jnz 0x00007D3D957E0F0E
00007d3d957dc72b  movaps [r15+0x180], xmm14
00007d3d957dc733  movaps xmm1, xmm13
00007d3d957dc737  addpd xmm1, xmm8
00007d3d957dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007d3d957dc741  ptest xmm9, xmm9
00007d3d957dc747  jnz 0x00007D3D957E1051
00007d3d957dc74d  movaps [r15+0x210], xmm1
00007d3d957dc755  movups xmm13, [r13+rax*1]
00007d3d957dc75b  lea r12, [rax+0x10]
00007d3d957dc75f  movups xmm9, [r13+r12*1]
00007d3d957dc765  movaps [r15+0x230], xmm9
00007d3d957dc76d  movaps xmm8, xmm15
00007d3d957dc771  addpd xmm8, xmm7
00007d3d957dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007d3d957dc77c  ptest xmm6, xmm6
00007d3d957dc781  jnz 0x00007D3D957E11A7
00007d3d957dc787  movaps [r15+0x130], xmm8
00007d3d957dc78f  vmovaps xmm15, [rsp+0x20]
00007d3d957dc795  vpermilpd xmm15, xmm15, 0x00
00007d3d957dc79b  movaps xmm7, xmm9
00007d3d957dc79f  mulpd xmm7, xmm15
00007d3d957dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007d3d957dc7a9  ptest xmm6, xmm6
00007d3d957dc7ae  jnz 0x00007D3D957E12EA
00007d3d957dc7b4  movaps [r15+0x220], xmm7
00007d3d957dc7bc  vmovaps xmm15, [rsp+0x20]
00007d3d957dc7c2  vpermilpd xmm15, xmm15, 0x00
00007d3d957dc7c8  movaps xmm9, xmm13
00007d3d957dc7cc  mulpd xmm9, xmm15
00007d3d957dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007d3d957dc7d7  ptest xmm6, xmm6
00007d3d957dc7dc  jnz 0x00007D3D957E142C
00007d3d957dc7e2  movaps xmm15, xmm11
00007d3d957dc7e6  addpd xmm15, xmm12
00007d3d957dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007d3d957dc7f1  ptest xmm13, xmm13
00007d3d957dc7f7  jnz 0x00007D3D957E1570
00007d3d957dc7fd  movaps [r15+0x140], xmm15
00007d3d957dc805  movaps xmm13, xmm10
00007d3d957dc809  addpd xmm13, xmm14
00007d3d957dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007d3d957dc814  ptest xmm12, xmm12
00007d3d957dc81a  jnz 0x00007D3D957E16B4
00007d3d957dc820  movaps [r15+0x150], xmm13
00007d3d957dc828  movaps xmm14, xmm1
00007d3d957dc82c  addpd xmm14, xmm7
00007d3d957dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007d3d957dc837  ptest xmm12, xmm12
00007d3d957dc83d  jnz 0x00007D3D957E17F8
00007d3d957dc843  movaps [r15+0x160], xmm14
00007d3d957dc84b  movaps xmm1, xmm8
00007d3d957dc84f  addpd xmm1, xmm9
00007d3d957dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007d3d957dc859  ptest xmm12, xmm12
00007d3d957dc85f  jnz 0x00007D3D957E193A
00007d3d957dc865  movaps [r15+0x120], xmm1
00007d3d957dc86d  movups [r13+r14*1], xmm15
00007d3d957dc873  lea rax, [r14+0x10]
00007d3d957dc877  movups [r13+rax*1], xmm13
00007d3d957dc87d  lea rax, [r14+0x20]
00007d3d957dc881  movups [r13+rax*1], xmm14
00007d3d957dc887  lea rax, [r14+0x30]
00007d3d957dc88b  movups [r13+rax*1], xmm1
00007d3d957dc891  mov eax, [r15+0x108]
00007d3d957dc898  sahf
00007d3d957dc899  jnz 0x00007D3D957DC8CB
00007d3d957dc89b  cmp dword ptr [r15+0x318], 0x00
00007d3d957dc8a3  jz 0x00007D3D957DB900
00007d3d957dc8a9  nop [rax+rax*1], ax
00007d3d957dc8b2  nop [rax+rax*1], eax
00007d3d957dc8ba  mov eax, 0x410444
00007d3d957dc8bf  mov [r15+0x100], rax
00007d3d957dc8c6  jmp 0x00007D3D955FE110
00007d3d957dc8cb  cmp dword ptr [r15+0x318], 0x00
00007d3d957dc8d3  jz 0x00007D3D957D57E0
00007d3d957dc8d9  nop [rax+rax*1], ax
00007d3d957dc8e2  nop [rax+rax*1], eax
00007d3d957dc8ea  mov eax, 0x410278
00007d3d957dc8ef  mov [r15+0x100], rax
00007d3d957dc8f6  jmp 0x00007D3D955FE110
00007d3d957dc8fb  int3
00007d3d957dc8fc  call 0x00007D3D956E27E0
00007d3d957dc901  jmp 0x00007D3D957DB9DF
00007d3d957dc906  call 0x00007D3D956E1570
00007d3d957dc90b  jmp 0x00007D3D957DB9E8
00007d3d957dc910  call 0x00007D3D956E27E0
00007d3d957dc915  jmp 0x00007D3D957DBA44
00007d3d957dc91a  call 0x00007D3D956E1570
00007d3d957dc91f  jmp 0x00007D3D957DBA4D
00007d3d957dc924  call 0x00007D3D956E27E0
00007d3d957dc929  jmp 0x00007D3D957DBA90
00007d3d957dc92e  call 0x00007D3D956E1570
00007d3d957dc933  jmp 0x00007D3D957DBA99
00007d3d957dc938  call 0x00007D3D9560DC20
00007d3d957dc93d  jmp 0x00007D3D957DBAD8
00007d3d957dc942  call 0x00007D3D956D59C0
00007d3d957dc947  jmp 0x00007D3D957DBAEB
00007d3d957dc94c  call 0x00007D3D956E0E30
00007d3d957dc951  jmp 0x00007D3D957DBB09
00007d3d957dc956  call 0x00007D3D956DFBC0
00007d3d957dc95b  jmp 0x00007D3D957DBB13
00007d3d957dc960  call 0x00007D3D956DE950
00007d3d957dc965  jmp 0x00007D3D957DBB1D
00007d3d957dc96a  sub rsp, 0x08
00007d3d957dc96e  push rax
00007d3d957dc96f  push rcx
00007d3d957dc970  push rdx
00007d3d957dc971  push rdi
00007d3d957dc972  push rsi
00007d3d957dc973  push r8
00007d3d957dc975  push r9
00007d3d957dc977  push r10
00007d3d957dc979  push r11
00007d3d957dc97b  sub rsp, 0xF0
00007d3d957dc982  vmovaps [rsp], xmm0
00007d3d957dc987  vmovaps [rsp+0x10], xmm1
00007d3d957dc98d  vmovaps [rsp+0x20], xmm2
00007d3d957dc993  vmovaps [rsp+0x30], xmm3
00007d3d957dc999  vmovaps [rsp+0x40], xmm4
00007d3d957dc99f  vmovaps [rsp+0x50], xmm5
00007d3d957dc9a5  vmovaps [rsp+0x60], xmm6
00007d3d957dc9ab  vmovaps [rsp+0x70], xmm7
00007d3d957dc9b1  vmovaps [rsp+0x80], xmm9
00007d3d957dc9ba  vmovaps [rsp+0x90], xmm10
00007d3d957dc9c3  vmovaps [rsp+0xA0], xmm11
00007d3d957dc9cc  vmovaps [rsp+0xB0], xmm12
00007d3d957dc9d5  vmovaps [rsp+0xC0], xmm13
00007d3d957dc9de  vmovaps [rsp+0xD0], xmm14
00007d3d957dc9e7  vmovaps [rsp+0xE0], xmm15
00007d3d957dc9f0  sub rsp, 0x30
00007d3d957dc9f4  movaps [rsp], xmm8
00007d3d957dc9f9  movaps [rsp+0x10], xmm12
00007d3d957dc9ff  movaps [rsp+0x20], xmm15
00007d3d957dca05  lea rdi, [rsp]
00007d3d957dca09  mov esi, 0x00
00007d3d957dca0e  mov rax, 0x56C27CB8A530
00007d3d957dca18  call rax
00007d3d957dca1a  movaps xmm8, [rsp]
00007d3d957dca1f  add rsp, 0x30
00007d3d957dca23  vmovaps xmm0, [rsp]
00007d3d957dca28  vmovaps xmm1, [rsp+0x10]
00007d3d957dca2e  vmovaps xmm2, [rsp+0x20]
00007d3d957dca34  vmovaps xmm3, [rsp+0x30]
00007d3d957dca3a  vmovaps xmm4, [rsp+0x40]
00007d3d957dca40  vmovaps xmm5, [rsp+0x50]
00007d3d957dca46  vmovaps xmm6, [rsp+0x60]
00007d3d957dca4c  vmovaps xmm7, [rsp+0x70]
00007d3d957dca52  vmovaps xmm9, [rsp+0x80]
00007d3d957dca5b  vmovaps xmm10, [rsp+0x90]
00007d3d957dca64  vmovaps xmm11, [rsp+0xA0]
00007d3d957dca6d  vmovaps xmm12, [rsp+0xB0]
00007d3d957dca76  vmovaps xmm13, [rsp+0xC0]
00007d3d957dca7f  vmovaps xmm14, [rsp+0xD0]
00007d3d957dca88  vmovaps xmm15, [rsp+0xE0]
00007d3d957dca91  add rsp, 0xF0
00007d3d957dca98  pop r11
00007d3d957dca9a  pop r10
00007d3d957dca9c  pop r9
00007d3d957dca9e  pop r8
00007d3d957dcaa0  pop rsi
00007d3d957dcaa1  pop rdi
00007d3d957dcaa2  pop rdx
00007d3d957dcaa3  pop rcx
00007d3d957dcaa4  pop rax
00007d3d957dcaa5  add rsp, 0x08
00007d3d957dcaa9  jmp 0x00007D3D957DBB47
00007d3d957dcaae  sub rsp, 0x08
00007d3d957dcab2  push rax
00007d3d957dcab3  push rcx
00007d3d957dcab4  push rdx
00007d3d957dcab5  push rdi
00007d3d957dcab6  push rsi
00007d3d957dcab7  push r8
00007d3d957dcab9  push r9
00007d3d957dcabb  push r10
00007d3d957dcabd  push r11
00007d3d957dcabf  sub rsp, 0xF0
00007d3d957dcac6  vmovaps [rsp], xmm0
00007d3d957dcacb  vmovaps [rsp+0x10], xmm1
00007d3d957dcad1  vmovaps [rsp+0x20], xmm2
00007d3d957dcad7  vmovaps [rsp+0x30], xmm3
00007d3d957dcadd  vmovaps [rsp+0x40], xmm4
00007d3d957dcae3  vmovaps [rsp+0x50], xmm5
00007d3d957dcae9  vmovaps [rsp+0x60], xmm6
00007d3d957dcaef  vmovaps [rsp+0x70], xmm8
00007d3d957dcaf5  vmovaps [rsp+0x80], xmm9
00007d3d957dcafe  vmovaps [rsp+0x90], xmm10
00007d3d957dcb07  vmovaps [rsp+0xA0], xmm11
00007d3d957dcb10  vmovaps [rsp+0xB0], xmm12
00007d3d957dcb19  vmovaps [rsp+0xC0], xmm13
00007d3d957dcb22  vmovaps [rsp+0xD0], xmm14
00007d3d957dcb2b  vmovaps [rsp+0xE0], xmm15
00007d3d957dcb34  sub rsp, 0x30
00007d3d957dcb38  movaps [rsp], xmm7
00007d3d957dcb3c  movaps [rsp+0x10], xmm9
00007d3d957dcb42  movaps [rsp+0x20], xmm15
00007d3d957dcb48  lea rdi, [rsp]
00007d3d957dcb4c  mov esi, 0x00
00007d3d957dcb51  mov rax, 0x56C27CB8A530
00007d3d957dcb5b  call rax
00007d3d957dcb5d  movaps xmm7, [rsp]
00007d3d957dcb61  add rsp, 0x30
00007d3d957dcb65  vmovaps xmm0, [rsp]
00007d3d957dcb6a  vmovaps xmm1, [rsp+0x10]
00007d3d957dcb70  vmovaps xmm2, [rsp+0x20]
00007d3d957dcb76  vmovaps xmm3, [rsp+0x30]
00007d3d957dcb7c  vmovaps xmm4, [rsp+0x40]
00007d3d957dcb82  vmovaps xmm5, [rsp+0x50]
00007d3d957dcb88  vmovaps xmm6, [rsp+0x60]
00007d3d957dcb8e  vmovaps xmm8, [rsp+0x70]
00007d3d957dcb94  vmovaps xmm9, [rsp+0x80]
00007d3d957dcb9d  vmovaps xmm10, [rsp+0x90]
00007d3d957dcba6  vmovaps xmm11, [rsp+0xA0]
00007d3d957dcbaf  vmovaps xmm12, [rsp+0xB0]
00007d3d957dcbb8  vmovaps xmm13, [rsp+0xC0]
00007d3d957dcbc1  vmovaps xmm14, [rsp+0xD0]
00007d3d957dcbca  vmovaps xmm15, [rsp+0xE0]
00007d3d957dcbd3  add rsp, 0xF0
00007d3d957dcbda  pop r11
00007d3d957dcbdc  pop r10
00007d3d957dcbde  pop r9
00007d3d957dcbe0  pop r8
00007d3d957dcbe2  pop rsi
00007d3d957dcbe3  pop rdi
00007d3d957dcbe4  pop rdx
00007d3d957dcbe5  pop rcx
00007d3d957dcbe6  pop rax
00007d3d957dcbe7  add rsp, 0x08
00007d3d957dcbeb  jmp 0x00007D3D957DBB75
00007d3d957dcbf0  sub rsp, 0x08
00007d3d957dcbf4  push rax
00007d3d957dcbf5  push rcx
00007d3d957dcbf6  push rdx
00007d3d957dcbf7  push rdi
00007d3d957dcbf8  push rsi
00007d3d957dcbf9  push r8
00007d3d957dcbfb  push r9
00007d3d957dcbfd  push r10
00007d3d957dcbff  push r11
00007d3d957dcc01  sub rsp, 0xF0
00007d3d957dcc08  vmovaps [rsp], xmm0
00007d3d957dcc0d  vmovaps [rsp+0x10], xmm1
00007d3d957dcc13  vmovaps [rsp+0x20], xmm2
00007d3d957dcc19  vmovaps [rsp+0x30], xmm3
00007d3d957dcc1f  vmovaps [rsp+0x40], xmm4
00007d3d957dcc25  vmovaps [rsp+0x50], xmm5
00007d3d957dcc2b  vmovaps [rsp+0x60], xmm6
00007d3d957dcc31  vmovaps [rsp+0x70], xmm7
00007d3d957dcc37  vmovaps [rsp+0x80], xmm8
00007d3d957dcc40  vmovaps [rsp+0x90], xmm10
00007d3d957dcc49  vmovaps [rsp+0xA0], xmm11
00007d3d957dcc52  vmovaps [rsp+0xB0], xmm12
00007d3d957dcc5b  vmovaps [rsp+0xC0], xmm13
00007d3d957dcc64  vmovaps [rsp+0xD0], xmm14
00007d3d957dcc6d  vmovaps [rsp+0xE0], xmm15
00007d3d957dcc76  sub rsp, 0x30
00007d3d957dcc7a  movaps [rsp], xmm9
00007d3d957dcc7f  movaps [rsp+0x10], xmm12
00007d3d957dcc85  movaps [rsp+0x20], xmm10
00007d3d957dcc8b  lea rdi, [rsp]
00007d3d957dcc8f  mov esi, 0x00
00007d3d957dcc94  mov rax, 0x56C27CB8A530
00007d3d957dcc9e  call rax
00007d3d957dcca0  movaps xmm9, [rsp]
00007d3d957dcca5  add rsp, 0x30
00007d3d957dcca9  vmovaps xmm0, [rsp]
00007d3d957dccae  vmovaps xmm1, [rsp+0x10]
00007d3d957dccb4  vmovaps xmm2, [rsp+0x20]
00007d3d957dccba  vmovaps xmm3, [rsp+0x30]
00007d3d957dccc0  vmovaps xmm4, [rsp+0x40]
00007d3d957dccc6  vmovaps xmm5, [rsp+0x50]
00007d3d957dcccc  vmovaps xmm6, [rsp+0x60]
00007d3d957dccd2  vmovaps xmm7, [rsp+0x70]
00007d3d957dccd8  vmovaps xmm8, [rsp+0x80]
00007d3d957dcce1  vmovaps xmm10, [rsp+0x90]
00007d3d957dccea  vmovaps xmm11, [rsp+0xA0]
00007d3d957dccf3  vmovaps xmm12, [rsp+0xB0]
00007d3d957dccfc  vmovaps xmm13, [rsp+0xC0]
00007d3d957dcd05  vmovaps xmm14, [rsp+0xD0]
00007d3d957dcd0e  vmovaps xmm15, [rsp+0xE0]
00007d3d957dcd17  add rsp, 0xF0
00007d3d957dcd1e  pop r11
00007d3d957dcd20  pop r10
00007d3d957dcd22  pop r9
00007d3d957dcd24  pop r8
00007d3d957dcd26  pop rsi
00007d3d957dcd27  pop rdi
00007d3d957dcd28  pop rdx
00007d3d957dcd29  pop rcx
00007d3d957dcd2a  pop rax
00007d3d957dcd2b  add rsp, 0x08
00007d3d957dcd2f  jmp 0x00007D3D957DBB99
00007d3d957dcd34  sub rsp, 0x08
00007d3d957dcd38  push rax
00007d3d957dcd39  push rcx
00007d3d957dcd3a  push rdx
00007d3d957dcd3b  push rdi
00007d3d957dcd3c  push rsi
00007d3d957dcd3d  push r8
00007d3d957dcd3f  push r9
00007d3d957dcd41  push r10
00007d3d957dcd43  push r11
00007d3d957dcd45  sub rsp, 0xF0
00007d3d957dcd4c  vmovaps [rsp], xmm0
00007d3d957dcd51  vmovaps [rsp+0x10], xmm1
00007d3d957dcd57  vmovaps [rsp+0x20], xmm2
00007d3d957dcd5d  vmovaps [rsp+0x30], xmm3
00007d3d957dcd63  vmovaps [rsp+0x40], xmm4
00007d3d957dcd69  vmovaps [rsp+0x50], xmm5
00007d3d957dcd6f  vmovaps [rsp+0x60], xmm6
00007d3d957dcd75  vmovaps [rsp+0x70], xmm7
00007d3d957dcd7b  vmovaps [rsp+0x80], xmm8
00007d3d957dcd84  vmovaps [rsp+0x90], xmm9
00007d3d957dcd8d  vmovaps [rsp+0xA0], xmm11
00007d3d957dcd96  vmovaps [rsp+0xB0], xmm12
00007d3d957dcd9f  vmovaps [rsp+0xC0], xmm13
00007d3d957dcda8  vmovaps [rsp+0xD0], xmm14
00007d3d957dcdb1  vmovaps [rsp+0xE0], xmm15
00007d3d957dcdba  sub rsp, 0x30
00007d3d957dcdbe  movaps [rsp], xmm10
00007d3d957dcdc3  movaps [rsp+0x10], xmm12
00007d3d957dcdc9  movaps [rsp+0x20], xmm11
00007d3d957dcdcf  lea rdi, [rsp]
00007d3d957dcdd3  mov esi, 0x00
00007d3d957dcdd8  mov rax, 0x56C27CB8A530
00007d3d957dcde2  call rax
00007d3d957dcde4  movaps xmm10, [rsp]
00007d3d957dcde9  add rsp, 0x30
00007d3d957dcded  vmovaps xmm0, [rsp]
00007d3d957dcdf2  vmovaps xmm1, [rsp+0x10]
00007d3d957dcdf8  vmovaps xmm2, [rsp+0x20]
00007d3d957dcdfe  vmovaps xmm3, [rsp+0x30]
00007d3d957dce04  vmovaps xmm4, [rsp+0x40]
00007d3d957dce0a  vmovaps xmm5, [rsp+0x50]
00007d3d957dce10  vmovaps xmm6, [rsp+0x60]
00007d3d957dce16  vmovaps xmm7, [rsp+0x70]
00007d3d957dce1c  vmovaps xmm8, [rsp+0x80]
00007d3d957dce25  vmovaps xmm9, [rsp+0x90]
00007d3d957dce2e  vmovaps xmm11, [rsp+0xA0]
00007d3d957dce37  vmovaps xmm12, [rsp+0xB0]
00007d3d957dce40  vmovaps xmm13, [rsp+0xC0]
00007d3d957dce49  vmovaps xmm14, [rsp+0xD0]
00007d3d957dce52  vmovaps xmm15, [rsp+0xE0]
00007d3d957dce5b  add rsp, 0xF0
00007d3d957dce62  pop r11
00007d3d957dce64  pop r10
00007d3d957dce66  pop r9
00007d3d957dce68  pop r8
00007d3d957dce6a  pop rsi
00007d3d957dce6b  pop rdi
00007d3d957dce6c  pop rdx
00007d3d957dce6d  pop rcx
00007d3d957dce6e  pop rax
00007d3d957dce6f  add rsp, 0x08
00007d3d957dce73  jmp 0x00007D3D957DBBB3
00007d3d957dce78  sub rsp, 0x08
00007d3d957dce7c  push rax
00007d3d957dce7d  push rcx
00007d3d957dce7e  push rdx
00007d3d957dce7f  push rdi
00007d3d957dce80  push rsi
00007d3d957dce81  push r8
00007d3d957dce83  push r9
00007d3d957dce85  push r10
00007d3d957dce87  push r11
00007d3d957dce89  sub rsp, 0xF0
00007d3d957dce90  vmovaps [rsp], xmm0
00007d3d957dce95  vmovaps [rsp+0x10], xmm1
00007d3d957dce9b  vmovaps [rsp+0x20], xmm2
00007d3d957dcea1  vmovaps [rsp+0x30], xmm3
00007d3d957dcea7  vmovaps [rsp+0x40], xmm4
00007d3d957dcead  vmovaps [rsp+0x50], xmm5
00007d3d957dceb3  vmovaps [rsp+0x60], xmm7
00007d3d957dceb9  vmovaps [rsp+0x70], xmm8
00007d3d957dcebf  vmovaps [rsp+0x80], xmm9
00007d3d957dcec8  vmovaps [rsp+0x90], xmm10
00007d3d957dced1  vmovaps [rsp+0xA0], xmm11
00007d3d957dceda  vmovaps [rsp+0xB0], xmm12
00007d3d957dcee3  vmovaps [rsp+0xC0], xmm13
00007d3d957dceec  vmovaps [rsp+0xD0], xmm14
00007d3d957dcef5  vmovaps [rsp+0xE0], xmm15
00007d3d957dcefe  sub rsp, 0x30
00007d3d957dcf02  movaps [rsp], xmm6
00007d3d957dcf06  movaps [rsp+0x10], xmm12
00007d3d957dcf0c  movaps [rsp+0x20], xmm11
00007d3d957dcf12  lea rdi, [rsp]
00007d3d957dcf16  mov esi, 0x00
00007d3d957dcf1b  mov rax, 0x56C27CB8A530
00007d3d957dcf25  call rax
00007d3d957dcf27  movaps xmm6, [rsp]
00007d3d957dcf2b  add rsp, 0x30
00007d3d957dcf2f  vmovaps xmm0, [rsp]
00007d3d957dcf34  vmovaps xmm1, [rsp+0x10]
00007d3d957dcf3a  vmovaps xmm2, [rsp+0x20]
00007d3d957dcf40  vmovaps xmm3, [rsp+0x30]
00007d3d957dcf46  vmovaps xmm4, [rsp+0x40]
00007d3d957dcf4c  vmovaps xmm5, [rsp+0x50]
00007d3d957dcf52  vmovaps xmm7, [rsp+0x60]
00007d3d957dcf58  vmovaps xmm8, [rsp+0x70]
00007d3d957dcf5e  vmovaps xmm9, [rsp+0x80]
00007d3d957dcf67  vmovaps xmm10, [rsp+0x90]
00007d3d957dcf70  vmovaps xmm11, [rsp+0xA0]
00007d3d957dcf79  vmovaps xmm12, [rsp+0xB0]
00007d3d957dcf82  vmovaps xmm13, [rsp+0xC0]
00007d3d957dcf8b  vmovaps xmm14, [rsp+0xD0]
00007d3d957dcf94  vmovaps xmm15, [rsp+0xE0]
00007d3d957dcf9d  add rsp, 0xF0
00007d3d957dcfa4  pop r11
00007d3d957dcfa6  pop r10
00007d3d957dcfa8  pop r9
00007d3d957dcfaa  pop r8
00007d3d957dcfac  pop rsi
00007d3d957dcfad  pop rdi
00007d3d957dcfae  pop rdx
00007d3d957dcfaf  pop rcx
00007d3d957dcfb0  pop rax
00007d3d957dcfb1  add rsp, 0x08
00007d3d957dcfb5  jmp 0x00007D3D957DBBD4
00007d3d957dcfba  sub rsp, 0x08
00007d3d957dcfbe  push rax
00007d3d957dcfbf  push rcx
00007d3d957dcfc0  push rdx
00007d3d957dcfc1  push rdi
00007d3d957dcfc2  push rsi
00007d3d957dcfc3  push r8
00007d3d957dcfc5  push r9
00007d3d957dcfc7  push r10
00007d3d957dcfc9  push r11
00007d3d957dcfcb  sub rsp, 0xF0
00007d3d957dcfd2  vmovaps [rsp], xmm0
00007d3d957dcfd7  vmovaps [rsp+0x10], xmm1
00007d3d957dcfdd  vmovaps [rsp+0x20], xmm2
00007d3d957dcfe3  vmovaps [rsp+0x30], xmm4
00007d3d957dcfe9  vmovaps [rsp+0x40], xmm5
00007d3d957dcfef  vmovaps [rsp+0x50], xmm6
00007d3d957dcff5  vmovaps [rsp+0x60], xmm7
00007d3d957dcffb  vmovaps [rsp+0x70], xmm8
00007d3d957dd001  vmovaps [rsp+0x80], xmm9
00007d3d957dd00a  vmovaps [rsp+0x90], xmm10
00007d3d957dd013  vmovaps [rsp+0xA0], xmm11
00007d3d957dd01c  vmovaps [rsp+0xB0], xmm12
00007d3d957dd025  vmovaps [rsp+0xC0], xmm13
00007d3d957dd02e  vmovaps [rsp+0xD0], xmm14
00007d3d957dd037  vmovaps [rsp+0xE0], xmm15
00007d3d957dd040  sub rsp, 0x30
00007d3d957dd044  movaps [rsp], xmm3
00007d3d957dd048  movaps [rsp+0x10], xmm5
00007d3d957dd04d  movaps [rsp+0x20], xmm4
00007d3d957dd052  lea rdi, [rsp]
00007d3d957dd056  mov esi, 0x00
00007d3d957dd05b  mov rax, 0x56C27CB8A530
00007d3d957dd065  call rax
00007d3d957dd067  movaps xmm3, [rsp]
00007d3d957dd06b  add rsp, 0x30
00007d3d957dd06f  vmovaps xmm0, [rsp]
00007d3d957dd074  vmovaps xmm1, [rsp+0x10]
00007d3d957dd07a  vmovaps xmm2, [rsp+0x20]
00007d3d957dd080  vmovaps xmm4, [rsp+0x30]
00007d3d957dd086  vmovaps xmm5, [rsp+0x40]
00007d3d957dd08c  vmovaps xmm6, [rsp+0x50]
00007d3d957dd092  vmovaps xmm7, [rsp+0x60]
00007d3d957dd098  vmovaps xmm8, [rsp+0x70]
00007d3d957dd09e  vmovaps xmm9, [rsp+0x80]
00007d3d957dd0a7  vmovaps xmm10, [rsp+0x90]
00007d3d957dd0b0  vmovaps xmm11, [rsp+0xA0]
00007d3d957dd0b9  vmovaps xmm12, [rsp+0xB0]
00007d3d957dd0c2  vmovaps xmm13, [rsp+0xC0]
00007d3d957dd0cb  vmovaps xmm14, [rsp+0xD0]
00007d3d957dd0d4  vmovaps xmm15, [rsp+0xE0]
00007d3d957dd0dd  add rsp, 0xF0
00007d3d957dd0e4  pop r11
00007d3d957dd0e6  pop r10
00007d3d957dd0e8  pop r9
00007d3d957dd0ea  pop r8
00007d3d957dd0ec  pop rsi
00007d3d957dd0ed  pop rdi
00007d3d957dd0ee  pop rdx
00007d3d957dd0ef  pop rcx
00007d3d957dd0f0  pop rax
00007d3d957dd0f1  add rsp, 0x08
00007d3d957dd0f5  jmp 0x00007D3D957DBC35
00007d3d957dd0fa  sub rsp, 0x08
00007d3d957dd0fe  push rax
00007d3d957dd0ff  push rcx
00007d3d957dd100  push rdx
00007d3d957dd101  push rdi
00007d3d957dd102  push rsi
00007d3d957dd103  push r8
00007d3d957dd105  push r9
00007d3d957dd107  push r10
00007d3d957dd109  push r11
00007d3d957dd10b  sub rsp, 0xF0
00007d3d957dd112  vmovaps [rsp], xmm0
00007d3d957dd117  vmovaps [rsp+0x10], xmm1
00007d3d957dd11d  vmovaps [rsp+0x20], xmm2
00007d3d957dd123  vmovaps [rsp+0x30], xmm3
00007d3d957dd129  vmovaps [rsp+0x40], xmm4
00007d3d957dd12f  vmovaps [rsp+0x50], xmm6
00007d3d957dd135  vmovaps [rsp+0x60], xmm7
00007d3d957dd13b  vmovaps [rsp+0x70], xmm8
00007d3d957dd141  vmovaps [rsp+0x80], xmm9
00007d3d957dd14a  vmovaps [rsp+0x90], xmm10
00007d3d957dd153  vmovaps [rsp+0xA0], xmm11
00007d3d957dd15c  vmovaps [rsp+0xB0], xmm12
00007d3d957dd165  vmovaps [rsp+0xC0], xmm13
00007d3d957dd16e  vmovaps [rsp+0xD0], xmm14
00007d3d957dd177  vmovaps [rsp+0xE0], xmm15
00007d3d957dd180  sub rsp, 0x30
00007d3d957dd184  movaps [rsp], xmm5
00007d3d957dd188  movaps [rsp+0x10], xmm8
00007d3d957dd18e  movaps [rsp+0x20], xmm15
00007d3d957dd194  lea rdi, [rsp]
00007d3d957dd198  mov esi, 0x00
00007d3d957dd19d  mov rax, 0x56C27CB8A530
00007d3d957dd1a7  call rax
00007d3d957dd1a9  movaps xmm5, [rsp]
00007d3d957dd1ad  add rsp, 0x30
00007d3d957dd1b1  vmovaps xmm0, [rsp]
00007d3d957dd1b6  vmovaps xmm1, [rsp+0x10]
00007d3d957dd1bc  vmovaps xmm2, [rsp+0x20]
00007d3d957dd1c2  vmovaps xmm3, [rsp+0x30]
00007d3d957dd1c8  vmovaps xmm4, [rsp+0x40]
00007d3d957dd1ce  vmovaps xmm6, [rsp+0x50]
00007d3d957dd1d4  vmovaps xmm7, [rsp+0x60]
00007d3d957dd1da  vmovaps xmm8, [rsp+0x70]
00007d3d957dd1e0  vmovaps xmm9, [rsp+0x80]
00007d3d957dd1e9  vmovaps xmm10, [rsp+0x90]
00007d3d957dd1f2  vmovaps xmm11, [rsp+0xA0]
00007d3d957dd1fb  vmovaps xmm12, [rsp+0xB0]
00007d3d957dd204  vmovaps xmm13, [rsp+0xC0]
00007d3d957dd20d  vmovaps xmm14, [rsp+0xD0]
00007d3d957dd216  vmovaps xmm15, [rsp+0xE0]
00007d3d957dd21f  add rsp, 0xF0
00007d3d957dd226  pop r11
00007d3d957dd228  pop r10
00007d3d957dd22a  pop r9
00007d3d957dd22c  pop r8
00007d3d957dd22e  pop rsi
00007d3d957dd22f  pop rdi
00007d3d957dd230  pop rdx
00007d3d957dd231  pop rcx
00007d3d957dd232  pop rax
00007d3d957dd233  add rsp, 0x08
00007d3d957dd237  jmp 0x00007D3D957DBC73
00007d3d957dd23c  sub rsp, 0x08
00007d3d957dd240  push rax
00007d3d957dd241  push rcx
00007d3d957dd242  push rdx
00007d3d957dd243  push rdi
00007d3d957dd244  push rsi
00007d3d957dd245  push r8
00007d3d957dd247  push r9
00007d3d957dd249  push r10
00007d3d957dd24b  push r11
00007d3d957dd24d  sub rsp, 0xF0
00007d3d957dd254  vmovaps [rsp], xmm0
00007d3d957dd259  vmovaps [rsp+0x10], xmm1
00007d3d957dd25f  vmovaps [rsp+0x20], xmm2
00007d3d957dd265  vmovaps [rsp+0x30], xmm3
00007d3d957dd26b  vmovaps [rsp+0x40], xmm5
00007d3d957dd271  vmovaps [rsp+0x50], xmm6
00007d3d957dd277  vmovaps [rsp+0x60], xmm7
00007d3d957dd27d  vmovaps [rsp+0x70], xmm8
00007d3d957dd283  vmovaps [rsp+0x80], xmm9
00007d3d957dd28c  vmovaps [rsp+0x90], xmm10
00007d3d957dd295  vmovaps [rsp+0xA0], xmm11
00007d3d957dd29e  vmovaps [rsp+0xB0], xmm12
00007d3d957dd2a7  vmovaps [rsp+0xC0], xmm13
00007d3d957dd2b0  vmovaps [rsp+0xD0], xmm14
00007d3d957dd2b9  vmovaps [rsp+0xE0], xmm15
00007d3d957dd2c2  sub rsp, 0x30
00007d3d957dd2c6  movaps [rsp], xmm4
00007d3d957dd2ca  movaps [rsp+0x10], xmm9
00007d3d957dd2d0  movaps [rsp+0x20], xmm8
00007d3d957dd2d6  lea rdi, [rsp]
00007d3d957dd2da  mov esi, 0x00
00007d3d957dd2df  mov rax, 0x56C27CB8A530
00007d3d957dd2e9  call rax
00007d3d957dd2eb  movaps xmm4, [rsp]
00007d3d957dd2ef  add rsp, 0x30
00007d3d957dd2f3  vmovaps xmm0, [rsp]
00007d3d957dd2f8  vmovaps xmm1, [rsp+0x10]
00007d3d957dd2fe  vmovaps xmm2, [rsp+0x20]
00007d3d957dd304  vmovaps xmm3, [rsp+0x30]
00007d3d957dd30a  vmovaps xmm5, [rsp+0x40]
00007d3d957dd310  vmovaps xmm6, [rsp+0x50]
00007d3d957dd316  vmovaps xmm7, [rsp+0x60]
00007d3d957dd31c  vmovaps xmm8, [rsp+0x70]
00007d3d957dd322  vmovaps xmm9, [rsp+0x80]
00007d3d957dd32b  vmovaps xmm10, [rsp+0x90]
00007d3d957dd334  vmovaps xmm11, [rsp+0xA0]
00007d3d957dd33d  vmovaps xmm12, [rsp+0xB0]
00007d3d957dd346  vmovaps xmm13, [rsp+0xC0]
00007d3d957dd34f  vmovaps xmm14, [rsp+0xD0]
00007d3d957dd358  vmovaps xmm15, [rsp+0xE0]
00007d3d957dd361  add rsp, 0xF0
00007d3d957dd368  pop r11
00007d3d957dd36a  pop r10
00007d3d957dd36c  pop r9
00007d3d957dd36e  pop r8
00007d3d957dd370  pop rsi
00007d3d957dd371  pop rdi
00007d3d957dd372  pop rdx
00007d3d957dd373  pop rcx
00007d3d957dd374  pop rax
00007d3d957dd375  add rsp, 0x08
00007d3d957dd379  jmp 0x00007D3D957DBC94
00007d3d957dd37e  sub rsp, 0x08
00007d3d957dd382  push rax
00007d3d957dd383  push rcx
00007d3d957dd384  push rdx
00007d3d957dd385  push rdi
00007d3d957dd386  push rsi
00007d3d957dd387  push r8
00007d3d957dd389  push r9
00007d3d957dd38b  push r10
00007d3d957dd38d  push r11
00007d3d957dd38f  sub rsp, 0xF0
00007d3d957dd396  vmovaps [rsp], xmm0
00007d3d957dd39b  vmovaps [rsp+0x10], xmm1
00007d3d957dd3a1  vmovaps [rsp+0x20], xmm2
00007d3d957dd3a7  vmovaps [rsp+0x30], xmm3
00007d3d957dd3ad  vmovaps [rsp+0x40], xmm4
00007d3d957dd3b3  vmovaps [rsp+0x50], xmm5
00007d3d957dd3b9  vmovaps [rsp+0x60], xmm6
00007d3d957dd3bf  vmovaps [rsp+0x70], xmm7
00007d3d957dd3c5  vmovaps [rsp+0x80], xmm8
00007d3d957dd3ce  vmovaps [rsp+0x90], xmm10
00007d3d957dd3d7  vmovaps [rsp+0xA0], xmm11
00007d3d957dd3e0  vmovaps [rsp+0xB0], xmm12
00007d3d957dd3e9  vmovaps [rsp+0xC0], xmm13
00007d3d957dd3f2  vmovaps [rsp+0xD0], xmm14
00007d3d957dd3fb  vmovaps [rsp+0xE0], xmm15
00007d3d957dd404  sub rsp, 0x30
00007d3d957dd408  movaps [rsp], xmm9
00007d3d957dd40d  movaps [rsp+0x10], xmm10
00007d3d957dd413  movaps [rsp+0x20], xmm8
00007d3d957dd419  lea rdi, [rsp]
00007d3d957dd41d  mov esi, 0x00
00007d3d957dd422  mov rax, 0x56C27CB8A530
00007d3d957dd42c  call rax
00007d3d957dd42e  movaps xmm9, [rsp]
00007d3d957dd433  add rsp, 0x30
00007d3d957dd437  vmovaps xmm0, [rsp]
00007d3d957dd43c  vmovaps xmm1, [rsp+0x10]
00007d3d957dd442  vmovaps xmm2, [rsp+0x20]
00007d3d957dd448  vmovaps xmm3, [rsp+0x30]
00007d3d957dd44e  vmovaps xmm4, [rsp+0x40]
00007d3d957dd454  vmovaps xmm5, [rsp+0x50]
00007d3d957dd45a  vmovaps xmm6, [rsp+0x60]
00007d3d957dd460  vmovaps xmm7, [rsp+0x70]
00007d3d957dd466  vmovaps xmm8, [rsp+0x80]
00007d3d957dd46f  vmovaps xmm10, [rsp+0x90]
00007d3d957dd478  vmovaps xmm11, [rsp+0xA0]
00007d3d957dd481  vmovaps xmm12, [rsp+0xB0]
00007d3d957dd48a  vmovaps xmm13, [rsp+0xC0]
00007d3d957dd493  vmovaps xmm14, [rsp+0xD0]
00007d3d957dd49c  vmovaps xmm15, [rsp+0xE0]
00007d3d957dd4a5  add rsp, 0xF0
00007d3d957dd4ac  pop r11
00007d3d957dd4ae  pop r10
00007d3d957dd4b0  pop r9
00007d3d957dd4b2  pop r8
00007d3d957dd4b4  pop rsi
00007d3d957dd4b5  pop rdi
00007d3d957dd4b6  pop rdx
00007d3d957dd4b7  pop rcx
00007d3d957dd4b8  pop rax
00007d3d957dd4b9  add rsp, 0x08
00007d3d957dd4bd  jmp 0x00007D3D957DBCAE
00007d3d957dd4c2  call 0x00007D3D956B52F0
00007d3d957dd4c7  jmp 0x00007D3D957DBDC8
00007d3d957dd4cc  call 0x00007D3D956B52F0
00007d3d957dd4d1  jmp 0x00007D3D957DBDDE
00007d3d957dd4d6  sub rsp, 0x08
00007d3d957dd4da  push rax
00007d3d957dd4db  push rcx
00007d3d957dd4dc  push rdx
00007d3d957dd4dd  push rdi
00007d3d957dd4de  push rsi
00007d3d957dd4df  push r8
00007d3d957dd4e1  push r9
00007d3d957dd4e3  push r10
00007d3d957dd4e5  push r11
00007d3d957dd4e7  sub rsp, 0xF0
00007d3d957dd4ee  vmovaps [rsp], xmm0
00007d3d957dd4f3  vmovaps [rsp+0x10], xmm2
00007d3d957dd4f9  vmovaps [rsp+0x20], xmm3
00007d3d957dd4ff  vmovaps [rsp+0x30], xmm4
00007d3d957dd505  vmovaps [rsp+0x40], xmm5
00007d3d957dd50b  vmovaps [rsp+0x50], xmm6
00007d3d957dd511  vmovaps [rsp+0x60], xmm7
00007d3d957dd517  vmovaps [rsp+0x70], xmm8
00007d3d957dd51d  vmovaps [rsp+0x80], xmm9
00007d3d957dd526  vmovaps [rsp+0x90], xmm10
00007d3d957dd52f  vmovaps [rsp+0xA0], xmm11
00007d3d957dd538  vmovaps [rsp+0xB0], xmm12
00007d3d957dd541  vmovaps [rsp+0xC0], xmm13
00007d3d957dd54a  vmovaps [rsp+0xD0], xmm14
00007d3d957dd553  vmovaps [rsp+0xE0], xmm15
00007d3d957dd55c  sub rsp, 0x30
00007d3d957dd560  movaps [rsp], xmm1
00007d3d957dd564  movaps [rsp+0x10], xmm6
00007d3d957dd569  movaps [rsp+0x20], xmm15
00007d3d957dd56f  lea rdi, [rsp]
00007d3d957dd573  mov esi, 0x00
00007d3d957dd578  mov rax, 0x56C27CB8A530
00007d3d957dd582  call rax
00007d3d957dd584  movaps xmm1, [rsp]
00007d3d957dd588  add rsp, 0x30
00007d3d957dd58c  vmovaps xmm0, [rsp]
00007d3d957dd591  vmovaps xmm2, [rsp+0x10]
00007d3d957dd597  vmovaps xmm3, [rsp+0x20]
00007d3d957dd59d  vmovaps xmm4, [rsp+0x30]
00007d3d957dd5a3  vmovaps xmm5, [rsp+0x40]
00007d3d957dd5a9  vmovaps xmm6, [rsp+0x50]
00007d3d957dd5af  vmovaps xmm7, [rsp+0x60]
00007d3d957dd5b5  vmovaps xmm8, [rsp+0x70]
00007d3d957dd5bb  vmovaps xmm9, [rsp+0x80]
00007d3d957dd5c4  vmovaps xmm10, [rsp+0x90]
00007d3d957dd5cd  vmovaps xmm11, [rsp+0xA0]
00007d3d957dd5d6  vmovaps xmm12, [rsp+0xB0]
00007d3d957dd5df  vmovaps xmm13, [rsp+0xC0]
00007d3d957dd5e8  vmovaps xmm14, [rsp+0xD0]
00007d3d957dd5f1  vmovaps xmm15, [rsp+0xE0]
00007d3d957dd5fa  add rsp, 0xF0
00007d3d957dd601  pop r11
00007d3d957dd603  pop r10
00007d3d957dd605  pop r9
00007d3d957dd607  pop r8
00007d3d957dd609  pop rsi
00007d3d957dd60a  pop rdi
00007d3d957dd60b  pop rdx
00007d3d957dd60c  pop rcx
00007d3d957dd60d  pop rax
00007d3d957dd60e  add rsp, 0x08
00007d3d957dd612  jmp 0x00007D3D957DBE1B
00007d3d957dd617  call 0x00007D3D956C4620
00007d3d957dd61c  jmp 0x00007D3D957DBE28
00007d3d957dd621  sub rsp, 0x08
00007d3d957dd625  push rax
00007d3d957dd626  push rcx
00007d3d957dd627  push rdx
00007d3d957dd628  push rdi
00007d3d957dd629  push rsi
00007d3d957dd62a  push r8
00007d3d957dd62c  push r9
00007d3d957dd62e  push r10
00007d3d957dd630  push r11
00007d3d957dd632  sub rsp, 0xF0
00007d3d957dd639  vmovaps [rsp], xmm0
00007d3d957dd63e  vmovaps [rsp+0x10], xmm1
00007d3d957dd644  vmovaps [rsp+0x20], xmm2
00007d3d957dd64a  vmovaps [rsp+0x30], xmm3
00007d3d957dd650  vmovaps [rsp+0x40], xmm4
00007d3d957dd656  vmovaps [rsp+0x50], xmm5
00007d3d957dd65c  vmovaps [rsp+0x60], xmm6
00007d3d957dd662  vmovaps [rsp+0x70], xmm7
00007d3d957dd668  vmovaps [rsp+0x80], xmm8
00007d3d957dd671  vmovaps [rsp+0x90], xmm9
00007d3d957dd67a  vmovaps [rsp+0xA0], xmm10
00007d3d957dd683  vmovaps [rsp+0xB0], xmm11
00007d3d957dd68c  vmovaps [rsp+0xC0], xmm12
00007d3d957dd695  vmovaps [rsp+0xD0], xmm13
00007d3d957dd69e  vmovaps [rsp+0xE0], xmm15
00007d3d957dd6a7  sub rsp, 0x30
00007d3d957dd6ab  movaps [rsp], xmm14
00007d3d957dd6b0  movaps [rsp+0x10], xmm4
00007d3d957dd6b5  movaps [rsp+0x20], xmm3
00007d3d957dd6ba  lea rdi, [rsp]
00007d3d957dd6be  mov esi, 0x00
00007d3d957dd6c3  mov rax, 0x56C27CB8A530
00007d3d957dd6cd  call rax
00007d3d957dd6cf  movaps xmm14, [rsp]
00007d3d957dd6d4  add rsp, 0x30
00007d3d957dd6d8  vmovaps xmm0, [rsp]
00007d3d957dd6dd  vmovaps xmm1, [rsp+0x10]
00007d3d957dd6e3  vmovaps xmm2, [rsp+0x20]
00007d3d957dd6e9  vmovaps xmm3, [rsp+0x30]
00007d3d957dd6ef  vmovaps xmm4, [rsp+0x40]
00007d3d957dd6f5  vmovaps xmm5, [rsp+0x50]
00007d3d957dd6fb  vmovaps xmm6, [rsp+0x60]
00007d3d957dd701  vmovaps xmm7, [rsp+0x70]
00007d3d957dd707  vmovaps xmm8, [rsp+0x80]
00007d3d957dd710  vmovaps xmm9, [rsp+0x90]
00007d3d957dd719  vmovaps xmm10, [rsp+0xA0]
00007d3d957dd722  vmovaps xmm11, [rsp+0xB0]
00007d3d957dd72b  vmovaps xmm12, [rsp+0xC0]
00007d3d957dd734  vmovaps xmm13, [rsp+0xD0]
00007d3d957dd73d  vmovaps xmm15, [rsp+0xE0]
00007d3d957dd746  add rsp, 0xF0
00007d3d957dd74d  pop r11
00007d3d957dd74f  pop r10
00007d3d957dd751  pop r9
00007d3d957dd753  pop r8
00007d3d957dd755  pop rsi
00007d3d957dd756  pop rdi
00007d3d957dd757  pop rdx
00007d3d957dd758  pop rcx
00007d3d957dd759  pop rax
00007d3d957dd75a  add rsp, 0x08
00007d3d957dd75e  jmp 0x00007D3D957DBE42
00007d3d957dd763  sub rsp, 0x08
00007d3d957dd767  push rax
00007d3d957dd768  push rcx
00007d3d957dd769  push rdx
00007d3d957dd76a  push rdi
00007d3d957dd76b  push rsi
00007d3d957dd76c  push r8
00007d3d957dd76e  push r9
00007d3d957dd770  push r10
00007d3d957dd772  push r11
00007d3d957dd774  sub rsp, 0xF0
00007d3d957dd77b  vmovaps [rsp], xmm0
00007d3d957dd780  vmovaps [rsp+0x10], xmm1
00007d3d957dd786  vmovaps [rsp+0x20], xmm2
00007d3d957dd78c  vmovaps [rsp+0x30], xmm3
00007d3d957dd792  vmovaps [rsp+0x40], xmm4
00007d3d957dd798  vmovaps [rsp+0x50], xmm5
00007d3d957dd79e  vmovaps [rsp+0x60], xmm7
00007d3d957dd7a4  vmovaps [rsp+0x70], xmm8
00007d3d957dd7aa  vmovaps [rsp+0x80], xmm9
00007d3d957dd7b3  vmovaps [rsp+0x90], xmm10
00007d3d957dd7bc  vmovaps [rsp+0xA0], xmm11
00007d3d957dd7c5  vmovaps [rsp+0xB0], xmm12
00007d3d957dd7ce  vmovaps [rsp+0xC0], xmm13
00007d3d957dd7d7  vmovaps [rsp+0xD0], xmm14
00007d3d957dd7e0  vmovaps [rsp+0xE0], xmm15
00007d3d957dd7e9  sub rsp, 0x30
00007d3d957dd7ed  movaps [rsp], xmm6
00007d3d957dd7f1  movaps [rsp+0x10], xmm9
00007d3d957dd7f7  movaps [rsp+0x20], xmm7
00007d3d957dd7fc  lea rdi, [rsp]
00007d3d957dd800  mov esi, 0x00
00007d3d957dd805  mov rax, 0x56C27CB8A530
00007d3d957dd80f  call rax
00007d3d957dd811  movaps xmm6, [rsp]
00007d3d957dd815  add rsp, 0x30
00007d3d957dd819  vmovaps xmm0, [rsp]
00007d3d957dd81e  vmovaps xmm1, [rsp+0x10]
00007d3d957dd824  vmovaps xmm2, [rsp+0x20]
00007d3d957dd82a  vmovaps xmm3, [rsp+0x30]
00007d3d957dd830  vmovaps xmm4, [rsp+0x40]
00007d3d957dd836  vmovaps xmm5, [rsp+0x50]
00007d3d957dd83c  vmovaps xmm7, [rsp+0x60]
00007d3d957dd842  vmovaps xmm8, [rsp+0x70]
00007d3d957dd848  vmovaps xmm9, [rsp+0x80]
00007d3d957dd851  vmovaps xmm10, [rsp+0x90]
00007d3d957dd85a  vmovaps xmm11, [rsp+0xA0]
00007d3d957dd863  vmovaps xmm12, [rsp+0xB0]
00007d3d957dd86c  vmovaps xmm13, [rsp+0xC0]
00007d3d957dd875  vmovaps xmm14, [rsp+0xD0]
00007d3d957dd87e  vmovaps xmm15, [rsp+0xE0]
00007d3d957dd887  add rsp, 0xF0
00007d3d957dd88e  pop r11
00007d3d957dd890  pop r10
00007d3d957dd892  pop r9
00007d3d957dd894  pop r8
00007d3d957dd896  pop rsi
00007d3d957dd897  pop rdi
00007d3d957dd898  pop rdx
00007d3d957dd899  pop rcx
00007d3d957dd89a  pop rax
00007d3d957dd89b  add rsp, 0x08
00007d3d957dd89f  jmp 0x00007D3D957DBE5A
00007d3d957dd8a4  sub rsp, 0x08
00007d3d957dd8a8  push rax
00007d3d957dd8a9  push rcx
00007d3d957dd8aa  push rdx
00007d3d957dd8ab  push rdi
00007d3d957dd8ac  push rsi
00007d3d957dd8ad  push r8
00007d3d957dd8af  push r9
00007d3d957dd8b1  push r10
00007d3d957dd8b3  push r11
00007d3d957dd8b5  sub rsp, 0xF0
00007d3d957dd8bc  vmovaps [rsp], xmm0
00007d3d957dd8c1  vmovaps [rsp+0x10], xmm1
00007d3d957dd8c7  vmovaps [rsp+0x20], xmm2
00007d3d957dd8cd  vmovaps [rsp+0x30], xmm3
00007d3d957dd8d3  vmovaps [rsp+0x40], xmm4
00007d3d957dd8d9  vmovaps [rsp+0x50], xmm5
00007d3d957dd8df  vmovaps [rsp+0x60], xmm6
00007d3d957dd8e5  vmovaps [rsp+0x70], xmm8
00007d3d957dd8eb  vmovaps [rsp+0x80], xmm9
00007d3d957dd8f4  vmovaps [rsp+0x90], xmm10
00007d3d957dd8fd  vmovaps [rsp+0xA0], xmm11
00007d3d957dd906  vmovaps [rsp+0xB0], xmm12
00007d3d957dd90f  vmovaps [rsp+0xC0], xmm13
00007d3d957dd918  vmovaps [rsp+0xD0], xmm14
00007d3d957dd921  vmovaps [rsp+0xE0], xmm15
00007d3d957dd92a  sub rsp, 0x30
00007d3d957dd92e  movaps [rsp], xmm7
00007d3d957dd932  movaps [rsp+0x10], xmm4
00007d3d957dd937  movaps [rsp+0x20], xmm9
00007d3d957dd93d  lea rdi, [rsp]
00007d3d957dd941  mov esi, 0x00
00007d3d957dd946  mov rax, 0x56C27CB8A530
00007d3d957dd950  call rax
00007d3d957dd952  movaps xmm7, [rsp]
00007d3d957dd956  add rsp, 0x30
00007d3d957dd95a  vmovaps xmm0, [rsp]
00007d3d957dd95f  vmovaps xmm1, [rsp+0x10]
00007d3d957dd965  vmovaps xmm2, [rsp+0x20]
00007d3d957dd96b  vmovaps xmm3, [rsp+0x30]
00007d3d957dd971  vmovaps xmm4, [rsp+0x40]
00007d3d957dd977  vmovaps xmm5, [rsp+0x50]
00007d3d957dd97d  vmovaps xmm6, [rsp+0x60]
00007d3d957dd983  vmovaps xmm8, [rsp+0x70]
00007d3d957dd989  vmovaps xmm9, [rsp+0x80]
00007d3d957dd992  vmovaps xmm10, [rsp+0x90]
00007d3d957dd99b  vmovaps xmm11, [rsp+0xA0]
00007d3d957dd9a4  vmovaps xmm12, [rsp+0xB0]
00007d3d957dd9ad  vmovaps xmm13, [rsp+0xC0]
00007d3d957dd9b6  vmovaps xmm14, [rsp+0xD0]
00007d3d957dd9bf  vmovaps xmm15, [rsp+0xE0]
00007d3d957dd9c8  add rsp, 0xF0
00007d3d957dd9cf  pop r11
00007d3d957dd9d1  pop r10
00007d3d957dd9d3  pop r9
00007d3d957dd9d5  pop r8
00007d3d957dd9d7  pop rsi
00007d3d957dd9d8  pop rdi
00007d3d957dd9d9  pop rdx
00007d3d957dd9da  pop rcx
00007d3d957dd9db  pop rax
00007d3d957dd9dc  add rsp, 0x08
00007d3d957dd9e0  jmp 0x00007D3D957DBE87
00007d3d957dd9e5  sub rsp, 0x08
00007d3d957dd9e9  push rax
00007d3d957dd9ea  push rcx
00007d3d957dd9eb  push rdx
00007d3d957dd9ec  push rdi
00007d3d957dd9ed  push rsi
00007d3d957dd9ee  push r8
00007d3d957dd9f0  push r9
00007d3d957dd9f2  push r10
00007d3d957dd9f4  push r11
00007d3d957dd9f6  sub rsp, 0xF0
00007d3d957dd9fd  vmovaps [rsp], xmm0
00007d3d957dda02  vmovaps [rsp+0x10], xmm1
00007d3d957dda08  vmovaps [rsp+0x20], xmm2
00007d3d957dda0e  vmovaps [rsp+0x30], xmm3
00007d3d957dda14  vmovaps [rsp+0x40], xmm5
00007d3d957dda1a  vmovaps [rsp+0x50], xmm6
00007d3d957dda20  vmovaps [rsp+0x60], xmm7
00007d3d957dda26  vmovaps [rsp+0x70], xmm8
00007d3d957dda2c  vmovaps [rsp+0x80], xmm9
00007d3d957dda35  vmovaps [rsp+0x90], xmm10
00007d3d957dda3e  vmovaps [rsp+0xA0], xmm11
00007d3d957dda47  vmovaps [rsp+0xB0], xmm12
00007d3d957dda50  vmovaps [rsp+0xC0], xmm13
00007d3d957dda59  vmovaps [rsp+0xD0], xmm14
00007d3d957dda62  vmovaps [rsp+0xE0], xmm15
00007d3d957dda6b  sub rsp, 0x30
00007d3d957dda6f  movaps [rsp], xmm4
00007d3d957dda73  movaps [rsp+0x10], xmm15
00007d3d957dda79  movaps [rsp+0x20], xmm9
00007d3d957dda7f  lea rdi, [rsp]
00007d3d957dda83  mov esi, 0x00
00007d3d957dda88  mov rax, 0x56C27CB8A530
00007d3d957dda92  call rax
00007d3d957dda94  movaps xmm4, [rsp]
00007d3d957dda98  add rsp, 0x30
00007d3d957dda9c  vmovaps xmm0, [rsp]
00007d3d957ddaa1  vmovaps xmm1, [rsp+0x10]
00007d3d957ddaa7  vmovaps xmm2, [rsp+0x20]
00007d3d957ddaad  vmovaps xmm3, [rsp+0x30]
00007d3d957ddab3  vmovaps xmm5, [rsp+0x40]
00007d3d957ddab9  vmovaps xmm6, [rsp+0x50]
00007d3d957ddabf  vmovaps xmm7, [rsp+0x60]
00007d3d957ddac5  vmovaps xmm8, [rsp+0x70]
00007d3d957ddacb  vmovaps xmm9, [rsp+0x80]
00007d3d957ddad4  vmovaps xmm10, [rsp+0x90]
00007d3d957ddadd  vmovaps xmm11, [rsp+0xA0]
00007d3d957ddae6  vmovaps xmm12, [rsp+0xB0]
00007d3d957ddaef  vmovaps xmm13, [rsp+0xC0]
00007d3d957ddaf8  vmovaps xmm14, [rsp+0xD0]
00007d3d957ddb01  vmovaps xmm15, [rsp+0xE0]
00007d3d957ddb0a  add rsp, 0xF0
00007d3d957ddb11  pop r11
00007d3d957ddb13  pop r10
00007d3d957ddb15  pop r9
00007d3d957ddb17  pop r8
00007d3d957ddb19  pop rsi
00007d3d957ddb1a  pop rdi
00007d3d957ddb1b  pop rdx
00007d3d957ddb1c  pop rcx
00007d3d957ddb1d  pop rax
00007d3d957ddb1e  add rsp, 0x08
00007d3d957ddb22  jmp 0x00007D3D957DBEAC
00007d3d957ddb27  call 0x00007D3D956C4620
00007d3d957ddb2c  jmp 0x00007D3D957DBEB9
00007d3d957ddb31  sub rsp, 0x08
00007d3d957ddb35  push rax
00007d3d957ddb36  push rcx
00007d3d957ddb37  push rdx
00007d3d957ddb38  push rdi
00007d3d957ddb39  push rsi
00007d3d957ddb3a  push r8
00007d3d957ddb3c  push r9
00007d3d957ddb3e  push r10
00007d3d957ddb40  push r11
00007d3d957ddb42  sub rsp, 0xF0
00007d3d957ddb49  vmovaps [rsp], xmm0
00007d3d957ddb4e  vmovaps [rsp+0x10], xmm1
00007d3d957ddb54  vmovaps [rsp+0x20], xmm2
00007d3d957ddb5a  vmovaps [rsp+0x30], xmm4
00007d3d957ddb60  vmovaps [rsp+0x40], xmm5
00007d3d957ddb66  vmovaps [rsp+0x50], xmm6
00007d3d957ddb6c  vmovaps [rsp+0x60], xmm7
00007d3d957ddb72  vmovaps [rsp+0x70], xmm8
00007d3d957ddb78  vmovaps [rsp+0x80], xmm9
00007d3d957ddb81  vmovaps [rsp+0x90], xmm10
00007d3d957ddb8a  vmovaps [rsp+0xA0], xmm11
00007d3d957ddb93  vmovaps [rsp+0xB0], xmm12
00007d3d957ddb9c  vmovaps [rsp+0xC0], xmm13
00007d3d957ddba5  vmovaps [rsp+0xD0], xmm14
00007d3d957ddbae  vmovaps [rsp+0xE0], xmm15
00007d3d957ddbb7  sub rsp, 0x30
00007d3d957ddbbb  movaps [rsp], xmm3
00007d3d957ddbbf  movaps [rsp+0x10], xmm1
00007d3d957ddbc4  movaps [rsp+0x20], xmm9
00007d3d957ddbca  lea rdi, [rsp]
00007d3d957ddbce  mov esi, 0x00
00007d3d957ddbd3  mov rax, 0x56C27CB8A530
00007d3d957ddbdd  call rax
00007d3d957ddbdf  movaps xmm3, [rsp]
00007d3d957ddbe3  add rsp, 0x30
00007d3d957ddbe7  vmovaps xmm0, [rsp]
00007d3d957ddbec  vmovaps xmm1, [rsp+0x10]
00007d3d957ddbf2  vmovaps xmm2, [rsp+0x20]
00007d3d957ddbf8  vmovaps xmm4, [rsp+0x30]
00007d3d957ddbfe  vmovaps xmm5, [rsp+0x40]
00007d3d957ddc04  vmovaps xmm6, [rsp+0x50]
00007d3d957ddc0a  vmovaps xmm7, [rsp+0x60]
00007d3d957ddc10  vmovaps xmm8, [rsp+0x70]
00007d3d957ddc16  vmovaps xmm9, [rsp+0x80]
00007d3d957ddc1f  vmovaps xmm10, [rsp+0x90]
00007d3d957ddc28  vmovaps xmm11, [rsp+0xA0]
00007d3d957ddc31  vmovaps xmm12, [rsp+0xB0]
00007d3d957ddc3a  vmovaps xmm13, [rsp+0xC0]
00007d3d957ddc43  vmovaps xmm14, [rsp+0xD0]
00007d3d957ddc4c  vmovaps xmm15, [rsp+0xE0]
00007d3d957ddc55  add rsp, 0xF0
00007d3d957ddc5c  pop r11
00007d3d957ddc5e  pop r10
00007d3d957ddc60  pop r9
00007d3d957ddc62  pop r8
00007d3d957ddc64  pop rsi
00007d3d957ddc65  pop rdi
00007d3d957ddc66  pop rdx
00007d3d957ddc67  pop rcx
00007d3d957ddc68  pop rax
00007d3d957ddc69  add rsp, 0x08
00007d3d957ddc6d  jmp 0x00007D3D957DBEF6
00007d3d957ddc72  sub rsp, 0x08
00007d3d957ddc76  push rax
00007d3d957ddc77  push rcx
00007d3d957ddc78  push rdx
00007d3d957ddc79  push rdi
00007d3d957ddc7a  push rsi
00007d3d957ddc7b  push r8
00007d3d957ddc7d  push r9
00007d3d957ddc7f  push r10
00007d3d957ddc81  push r11
00007d3d957ddc83  sub rsp, 0xF0
00007d3d957ddc8a  vmovaps [rsp], xmm0
00007d3d957ddc8f  vmovaps [rsp+0x10], xmm2
00007d3d957ddc95  vmovaps [rsp+0x20], xmm3
00007d3d957ddc9b  vmovaps [rsp+0x30], xmm4
00007d3d957ddca1  vmovaps [rsp+0x40], xmm5
00007d3d957ddca7  vmovaps [rsp+0x50], xmm6
00007d3d957ddcad  vmovaps [rsp+0x60], xmm7
00007d3d957ddcb3  vmovaps [rsp+0x70], xmm8
00007d3d957ddcb9  vmovaps [rsp+0x80], xmm9
00007d3d957ddcc2  vmovaps [rsp+0x90], xmm10
00007d3d957ddccb  vmovaps [rsp+0xA0], xmm11
00007d3d957ddcd4  vmovaps [rsp+0xB0], xmm12
00007d3d957ddcdd  vmovaps [rsp+0xC0], xmm13
00007d3d957ddce6  vmovaps [rsp+0xD0], xmm14
00007d3d957ddcef  vmovaps [rsp+0xE0], xmm15
00007d3d957ddcf8  sub rsp, 0x30
00007d3d957ddcfc  movaps [rsp], xmm1
00007d3d957ddd00  movaps [rsp+0x10], xmm15
00007d3d957ddd06  movaps [rsp+0x20], xmm9
00007d3d957ddd0c  lea rdi, [rsp]
00007d3d957ddd10  mov esi, 0x00
00007d3d957ddd15  mov rax, 0x56C27CB8A530
00007d3d957ddd1f  call rax
00007d3d957ddd21  movaps xmm1, [rsp]
00007d3d957ddd25  add rsp, 0x30
00007d3d957ddd29  vmovaps xmm0, [rsp]
00007d3d957ddd2e  vmovaps xmm2, [rsp+0x10]
00007d3d957ddd34  vmovaps xmm3, [rsp+0x20]
00007d3d957ddd3a  vmovaps xmm4, [rsp+0x30]
00007d3d957ddd40  vmovaps xmm5, [rsp+0x40]
00007d3d957ddd46  vmovaps xmm6, [rsp+0x50]
00007d3d957ddd4c  vmovaps xmm7, [rsp+0x60]
00007d3d957ddd52  vmovaps xmm8, [rsp+0x70]
00007d3d957ddd58  vmovaps xmm9, [rsp+0x80]
00007d3d957ddd61  vmovaps xmm10, [rsp+0x90]
00007d3d957ddd6a  vmovaps xmm11, [rsp+0xA0]
00007d3d957ddd73  vmovaps xmm12, [rsp+0xB0]
00007d3d957ddd7c  vmovaps xmm13, [rsp+0xC0]
00007d3d957ddd85  vmovaps xmm14, [rsp+0xD0]
00007d3d957ddd8e  vmovaps xmm15, [rsp+0xE0]
00007d3d957ddd97  add rsp, 0xF0
00007d3d957ddd9e  pop r11
00007d3d957ddda0  pop r10
00007d3d957ddda2  pop r9
00007d3d957ddda4  pop r8
00007d3d957ddda6  pop rsi
00007d3d957ddda7  pop rdi
00007d3d957ddda8  pop rdx
00007d3d957ddda9  pop rcx
00007d3d957dddaa  pop rax
00007d3d957dddab  add rsp, 0x08
00007d3d957dddaf  jmp 0x00007D3D957DBF7E
00007d3d957dddb4  call 0x00007D3D956C4620
00007d3d957dddb9  jmp 0x00007D3D957DBF8B
00007d3d957dddbe  sub rsp, 0x08
00007d3d957dddc2  push rax
00007d3d957dddc3  push rcx
00007d3d957dddc4  push rdx
00007d3d957dddc5  push rdi
00007d3d957dddc6  push rsi
00007d3d957dddc7  push r8
00007d3d957dddc9  push r9
00007d3d957dddcb  push r10
00007d3d957dddcd  push r11
00007d3d957dddcf  sub rsp, 0xF0
00007d3d957dddd6  vmovaps [rsp], xmm0
00007d3d957ddddb  vmovaps [rsp+0x10], xmm2
00007d3d957ddde1  vmovaps [rsp+0x20], xmm3
00007d3d957ddde7  vmovaps [rsp+0x30], xmm4
00007d3d957ddded  vmovaps [rsp+0x40], xmm5
00007d3d957dddf3  vmovaps [rsp+0x50], xmm6
00007d3d957dddf9  vmovaps [rsp+0x60], xmm7
00007d3d957dddff  vmovaps [rsp+0x70], xmm8
00007d3d957dde05  vmovaps [rsp+0x80], xmm9
00007d3d957dde0e  vmovaps [rsp+0x90], xmm10
00007d3d957dde17  vmovaps [rsp+0xA0], xmm11
00007d3d957dde20  vmovaps [rsp+0xB0], xmm12
00007d3d957dde29  vmovaps [rsp+0xC0], xmm13
00007d3d957dde32  vmovaps [rsp+0xD0], xmm14
00007d3d957dde3b  vmovaps [rsp+0xE0], xmm15
00007d3d957dde44  sub rsp, 0x30
00007d3d957dde48  movaps [rsp], xmm1
00007d3d957dde4c  movaps [rsp+0x10], xmm5
00007d3d957dde51  movaps [rsp+0x20], xmm7
00007d3d957dde56  lea rdi, [rsp]
00007d3d957dde5a  mov esi, 0x00
00007d3d957dde5f  mov rax, 0x56C27CB8A530
00007d3d957dde69  call rax
00007d3d957dde6b  movaps xmm1, [rsp]
00007d3d957dde6f  add rsp, 0x30
00007d3d957dde73  vmovaps xmm0, [rsp]
00007d3d957dde78  vmovaps xmm2, [rsp+0x10]
00007d3d957dde7e  vmovaps xmm3, [rsp+0x20]
00007d3d957dde84  vmovaps xmm4, [rsp+0x30]
00007d3d957dde8a  vmovaps xmm5, [rsp+0x40]
00007d3d957dde90  vmovaps xmm6, [rsp+0x50]
00007d3d957dde96  vmovaps xmm7, [rsp+0x60]
00007d3d957dde9c  vmovaps xmm8, [rsp+0x70]
00007d3d957ddea2  vmovaps xmm9, [rsp+0x80]
00007d3d957ddeab  vmovaps xmm10, [rsp+0x90]
00007d3d957ddeb4  vmovaps xmm11, [rsp+0xA0]
00007d3d957ddebd  vmovaps xmm12, [rsp+0xB0]
00007d3d957ddec6  vmovaps xmm13, [rsp+0xC0]
00007d3d957ddecf  vmovaps xmm14, [rsp+0xD0]
00007d3d957dded8  vmovaps xmm15, [rsp+0xE0]
00007d3d957ddee1  add rsp, 0xF0
00007d3d957ddee8  pop r11
00007d3d957ddeea  pop r10
00007d3d957ddeec  pop r9
00007d3d957ddeee  pop r8
00007d3d957ddef0  pop rsi
00007d3d957ddef1  pop rdi
00007d3d957ddef2  pop rdx
00007d3d957ddef3  pop rcx
00007d3d957ddef4  pop rax
00007d3d957ddef5  add rsp, 0x08
00007d3d957ddef9  jmp 0x00007D3D957DC030
00007d3d957ddefe  sub rsp, 0x08
00007d3d957ddf02  push rax
00007d3d957ddf03  push rcx
00007d3d957ddf04  push rdx
00007d3d957ddf05  push rdi
00007d3d957ddf06  push rsi
00007d3d957ddf07  push r8
00007d3d957ddf09  push r9
00007d3d957ddf0b  push r10
00007d3d957ddf0d  push r11
00007d3d957ddf0f  sub rsp, 0xF0
00007d3d957ddf16  vmovaps [rsp], xmm0
00007d3d957ddf1b  vmovaps [rsp+0x10], xmm1
00007d3d957ddf21  vmovaps [rsp+0x20], xmm2
00007d3d957ddf27  vmovaps [rsp+0x30], xmm3
00007d3d957ddf2d  vmovaps [rsp+0x40], xmm4
00007d3d957ddf33  vmovaps [rsp+0x50], xmm5
00007d3d957ddf39  vmovaps [rsp+0x60], xmm6
00007d3d957ddf3f  vmovaps [rsp+0x70], xmm8
00007d3d957ddf45  vmovaps [rsp+0x80], xmm9
00007d3d957ddf4e  vmovaps [rsp+0x90], xmm10
00007d3d957ddf57  vmovaps [rsp+0xA0], xmm11
00007d3d957ddf60  vmovaps [rsp+0xB0], xmm12
00007d3d957ddf69  vmovaps [rsp+0xC0], xmm13
00007d3d957ddf72  vmovaps [rsp+0xD0], xmm14
00007d3d957ddf7b  vmovaps [rsp+0xE0], xmm15
00007d3d957ddf84  sub rsp, 0x30
00007d3d957ddf88  movaps [rsp], xmm7
00007d3d957ddf8c  movaps [rsp+0x10], xmm5
00007d3d957ddf91  movaps [rsp+0x20], xmm15
00007d3d957ddf97  lea rdi, [rsp]
00007d3d957ddf9b  mov esi, 0x00
00007d3d957ddfa0  mov rax, 0x56C27CB8A530
00007d3d957ddfaa  call rax
00007d3d957ddfac  movaps xmm7, [rsp]
00007d3d957ddfb0  add rsp, 0x30
00007d3d957ddfb4  vmovaps xmm0, [rsp]
00007d3d957ddfb9  vmovaps xmm1, [rsp+0x10]
00007d3d957ddfbf  vmovaps xmm2, [rsp+0x20]
00007d3d957ddfc5  vmovaps xmm3, [rsp+0x30]
00007d3d957ddfcb  vmovaps xmm4, [rsp+0x40]
00007d3d957ddfd1  vmovaps xmm5, [rsp+0x50]
00007d3d957ddfd7  vmovaps xmm6, [rsp+0x60]
00007d3d957ddfdd  vmovaps xmm8, [rsp+0x70]
00007d3d957ddfe3  vmovaps xmm9, [rsp+0x80]
00007d3d957ddfec  vmovaps xmm10, [rsp+0x90]
00007d3d957ddff5  vmovaps xmm11, [rsp+0xA0]
00007d3d957ddffe  vmovaps xmm12, [rsp+0xB0]
00007d3d957de007  vmovaps xmm13, [rsp+0xC0]
00007d3d957de010  vmovaps xmm14, [rsp+0xD0]
00007d3d957de019  vmovaps xmm15, [rsp+0xE0]
00007d3d957de022  add rsp, 0xF0
00007d3d957de029  pop r11
00007d3d957de02b  pop r10
00007d3d957de02d  pop r9
00007d3d957de02f  pop r8
00007d3d957de031  pop rsi
00007d3d957de032  pop rdi
00007d3d957de033  pop rdx
00007d3d957de034  pop rcx
00007d3d957de035  pop rax
00007d3d957de036  add rsp, 0x08
00007d3d957de03a  jmp 0x00007D3D957DC066
00007d3d957de03f  call 0x00007D3D956B52F0
00007d3d957de044  jmp 0x00007D3D957DC073
00007d3d957de049  sub rsp, 0x08
00007d3d957de04d  push rax
00007d3d957de04e  push rcx
00007d3d957de04f  push rdx
00007d3d957de050  push rdi
00007d3d957de051  push rsi
00007d3d957de052  push r8
00007d3d957de054  push r9
00007d3d957de056  push r10
00007d3d957de058  push r11
00007d3d957de05a  sub rsp, 0xF0
00007d3d957de061  vmovaps [rsp], xmm0
00007d3d957de066  vmovaps [rsp+0x10], xmm1
00007d3d957de06c  vmovaps [rsp+0x20], xmm2
00007d3d957de072  vmovaps [rsp+0x30], xmm3
00007d3d957de078  vmovaps [rsp+0x40], xmm4
00007d3d957de07e  vmovaps [rsp+0x50], xmm5
00007d3d957de084  vmovaps [rsp+0x60], xmm6
00007d3d957de08a  vmovaps [rsp+0x70], xmm7
00007d3d957de090  vmovaps [rsp+0x80], xmm8
00007d3d957de099  vmovaps [rsp+0x90], xmm9
00007d3d957de0a2  vmovaps [rsp+0xA0], xmm10
00007d3d957de0ab  vmovaps [rsp+0xB0], xmm11
00007d3d957de0b4  vmovaps [rsp+0xC0], xmm12
00007d3d957de0bd  vmovaps [rsp+0xD0], xmm13
00007d3d957de0c6  vmovaps [rsp+0xE0], xmm14
00007d3d957de0cf  sub rsp, 0x30
00007d3d957de0d3  movaps [rsp], xmm15
00007d3d957de0d8  movaps [rsp+0x10], xmm5
00007d3d957de0dd  movaps [rsp+0x20], xmm3
00007d3d957de0e2  lea rdi, [rsp]
00007d3d957de0e6  mov esi, 0x00
00007d3d957de0eb  mov rax, 0x56C27CB8A530
00007d3d957de0f5  call rax
00007d3d957de0f7  movaps xmm15, [rsp]
00007d3d957de0fc  add rsp, 0x30
00007d3d957de100  vmovaps xmm0, [rsp]
00007d3d957de105  vmovaps xmm1, [rsp+0x10]
00007d3d957de10b  vmovaps xmm2, [rsp+0x20]
00007d3d957de111  vmovaps xmm3, [rsp+0x30]
00007d3d957de117  vmovaps xmm4, [rsp+0x40]
00007d3d957de11d  vmovaps xmm5, [rsp+0x50]
00007d3d957de123  vmovaps xmm6, [rsp+0x60]
00007d3d957de129  vmovaps xmm7, [rsp+0x70]
00007d3d957de12f  vmovaps xmm8, [rsp+0x80]
00007d3d957de138  vmovaps xmm9, [rsp+0x90]
00007d3d957de141  vmovaps xmm10, [rsp+0xA0]
00007d3d957de14a  vmovaps xmm11, [rsp+0xB0]
00007d3d957de153  vmovaps xmm12, [rsp+0xC0]
00007d3d957de15c  vmovaps xmm13, [rsp+0xD0]
00007d3d957de165  vmovaps xmm14, [rsp+0xE0]
00007d3d957de16e  add rsp, 0xF0
00007d3d957de175  pop r11
00007d3d957de177  pop r10
00007d3d957de179  pop r9
00007d3d957de17b  pop r8
00007d3d957de17d  pop rsi
00007d3d957de17e  pop rdi
00007d3d957de17f  pop rdx
00007d3d957de180  pop rcx
00007d3d957de181  pop rax
00007d3d957de182  add rsp, 0x08
00007d3d957de186  jmp 0x00007D3D957DC099
00007d3d957de18b  sub rsp, 0x08
00007d3d957de18f  push rax
00007d3d957de190  push rcx
00007d3d957de191  push rdx
00007d3d957de192  push rdi
00007d3d957de193  push rsi
00007d3d957de194  push r8
00007d3d957de196  push r9
00007d3d957de198  push r10
00007d3d957de19a  push r11
00007d3d957de19c  sub rsp, 0xF0
00007d3d957de1a3  vmovaps [rsp], xmm0
00007d3d957de1a8  vmovaps [rsp+0x10], xmm2
00007d3d957de1ae  vmovaps [rsp+0x20], xmm3
00007d3d957de1b4  vmovaps [rsp+0x30], xmm4
00007d3d957de1ba  vmovaps [rsp+0x40], xmm5
00007d3d957de1c0  vmovaps [rsp+0x50], xmm6
00007d3d957de1c6  vmovaps [rsp+0x60], xmm7
00007d3d957de1cc  vmovaps [rsp+0x70], xmm8
00007d3d957de1d2  vmovaps [rsp+0x80], xmm9
00007d3d957de1db  vmovaps [rsp+0x90], xmm10
00007d3d957de1e4  vmovaps [rsp+0xA0], xmm11
00007d3d957de1ed  vmovaps [rsp+0xB0], xmm12
00007d3d957de1f6  vmovaps [rsp+0xC0], xmm13
00007d3d957de1ff  vmovaps [rsp+0xD0], xmm14
00007d3d957de208  vmovaps [rsp+0xE0], xmm15
00007d3d957de211  sub rsp, 0x30
00007d3d957de215  movaps [rsp], xmm1
00007d3d957de219  movaps [rsp+0x10], xmm5
00007d3d957de21e  movaps [rsp+0x20], xmm4
00007d3d957de223  lea rdi, [rsp]
00007d3d957de227  mov esi, 0x00
00007d3d957de22c  mov rax, 0x56C27CB8A530
00007d3d957de236  call rax
00007d3d957de238  movaps xmm1, [rsp]
00007d3d957de23c  add rsp, 0x30
00007d3d957de240  vmovaps xmm0, [rsp]
00007d3d957de245  vmovaps xmm2, [rsp+0x10]
00007d3d957de24b  vmovaps xmm3, [rsp+0x20]
00007d3d957de251  vmovaps xmm4, [rsp+0x30]
00007d3d957de257  vmovaps xmm5, [rsp+0x40]
00007d3d957de25d  vmovaps xmm6, [rsp+0x50]
00007d3d957de263  vmovaps xmm7, [rsp+0x60]
00007d3d957de269  vmovaps xmm8, [rsp+0x70]
00007d3d957de26f  vmovaps xmm9, [rsp+0x80]
00007d3d957de278  vmovaps xmm10, [rsp+0x90]
00007d3d957de281  vmovaps xmm11, [rsp+0xA0]
00007d3d957de28a  vmovaps xmm12, [rsp+0xB0]
00007d3d957de293  vmovaps xmm13, [rsp+0xC0]
00007d3d957de29c  vmovaps xmm14, [rsp+0xD0]
00007d3d957de2a5  vmovaps xmm15, [rsp+0xE0]
00007d3d957de2ae  add rsp, 0xF0
00007d3d957de2b5  pop r11
00007d3d957de2b7  pop r10
00007d3d957de2b9  pop r9
00007d3d957de2bb  pop r8
00007d3d957de2bd  pop rsi
00007d3d957de2be  pop rdi
00007d3d957de2bf  pop rdx
00007d3d957de2c0  pop rcx
00007d3d957de2c1  pop rax
00007d3d957de2c2  add rsp, 0x08
00007d3d957de2c6  jmp 0x00007D3D957DC0B9
00007d3d957de2cb  sub rsp, 0x08
00007d3d957de2cf  push rax
00007d3d957de2d0  push rcx
00007d3d957de2d1  push rdx
00007d3d957de2d2  push rdi
00007d3d957de2d3  push rsi
00007d3d957de2d4  push r8
00007d3d957de2d6  push r9
00007d3d957de2d8  push r10
00007d3d957de2da  push r11
00007d3d957de2dc  sub rsp, 0xF0
00007d3d957de2e3  vmovaps [rsp], xmm0
00007d3d957de2e8  vmovaps [rsp+0x10], xmm1
00007d3d957de2ee  vmovaps [rsp+0x20], xmm2
00007d3d957de2f4  vmovaps [rsp+0x30], xmm3
00007d3d957de2fa  vmovaps [rsp+0x40], xmm5
00007d3d957de300  vmovaps [rsp+0x50], xmm6
00007d3d957de306  vmovaps [rsp+0x60], xmm7
00007d3d957de30c  vmovaps [rsp+0x70], xmm8
00007d3d957de312  vmovaps [rsp+0x80], xmm9
00007d3d957de31b  vmovaps [rsp+0x90], xmm10
00007d3d957de324  vmovaps [rsp+0xA0], xmm11
00007d3d957de32d  vmovaps [rsp+0xB0], xmm12
00007d3d957de336  vmovaps [rsp+0xC0], xmm13
00007d3d957de33f  vmovaps [rsp+0xD0], xmm14
00007d3d957de348  vmovaps [rsp+0xE0], xmm15
00007d3d957de351  sub rsp, 0x30
00007d3d957de355  movaps [rsp], xmm4
00007d3d957de359  movaps [rsp+0x10], xmm3
00007d3d957de35e  movaps [rsp+0x20], xmm5
00007d3d957de363  lea rdi, [rsp]
00007d3d957de367  mov esi, 0x00
00007d3d957de36c  mov rax, 0x56C27CB8A530
00007d3d957de376  call rax
00007d3d957de378  movaps xmm4, [rsp]
00007d3d957de37c  add rsp, 0x30
00007d3d957de380  vmovaps xmm0, [rsp]
00007d3d957de385  vmovaps xmm1, [rsp+0x10]
00007d3d957de38b  vmovaps xmm2, [rsp+0x20]
00007d3d957de391  vmovaps xmm3, [rsp+0x30]
00007d3d957de397  vmovaps xmm5, [rsp+0x40]
00007d3d957de39d  vmovaps xmm6, [rsp+0x50]
00007d3d957de3a3  vmovaps xmm7, [rsp+0x60]
00007d3d957de3a9  vmovaps xmm8, [rsp+0x70]
00007d3d957de3af  vmovaps xmm9, [rsp+0x80]
00007d3d957de3b8  vmovaps xmm10, [rsp+0x90]
00007d3d957de3c1  vmovaps xmm11, [rsp+0xA0]
00007d3d957de3ca  vmovaps xmm12, [rsp+0xB0]
00007d3d957de3d3  vmovaps xmm13, [rsp+0xC0]
00007d3d957de3dc  vmovaps xmm14, [rsp+0xD0]
00007d3d957de3e5  vmovaps xmm15, [rsp+0xE0]
00007d3d957de3ee  add rsp, 0xF0
00007d3d957de3f5  pop r11
00007d3d957de3f7  pop r10
00007d3d957de3f9  pop r9
00007d3d957de3fb  pop r8
00007d3d957de3fd  pop rsi
00007d3d957de3fe  pop rdi
00007d3d957de3ff  pop rdx
00007d3d957de400  pop rcx
00007d3d957de401  pop rax
00007d3d957de402  add rsp, 0x08
00007d3d957de406  jmp 0x00007D3D957DC107
00007d3d957de40b  call 0x00007D3D956B52F0
00007d3d957de410  jmp 0x00007D3D957DC114
00007d3d957de415  sub rsp, 0x08
00007d3d957de419  push rax
00007d3d957de41a  push rcx
00007d3d957de41b  push rdx
00007d3d957de41c  push rdi
00007d3d957de41d  push rsi
00007d3d957de41e  push r8
00007d3d957de420  push r9
00007d3d957de422  push r10
00007d3d957de424  push r11
00007d3d957de426  sub rsp, 0xF0
00007d3d957de42d  vmovaps [rsp], xmm0
00007d3d957de432  vmovaps [rsp+0x10], xmm1
00007d3d957de438  vmovaps [rsp+0x20], xmm2
00007d3d957de43e  vmovaps [rsp+0x30], xmm3
00007d3d957de444  vmovaps [rsp+0x40], xmm4
00007d3d957de44a  vmovaps [rsp+0x50], xmm6
00007d3d957de450  vmovaps [rsp+0x60], xmm7
00007d3d957de456  vmovaps [rsp+0x70], xmm8
00007d3d957de45c  vmovaps [rsp+0x80], xmm9
00007d3d957de465  vmovaps [rsp+0x90], xmm10
00007d3d957de46e  vmovaps [rsp+0xA0], xmm11
00007d3d957de477  vmovaps [rsp+0xB0], xmm12
00007d3d957de480  vmovaps [rsp+0xC0], xmm13
00007d3d957de489  vmovaps [rsp+0xD0], xmm14
00007d3d957de492  vmovaps [rsp+0xE0], xmm15
00007d3d957de49b  sub rsp, 0x30
00007d3d957de49f  movaps [rsp], xmm5
00007d3d957de4a3  movaps [rsp+0x10], xmm6
00007d3d957de4a8  movaps [rsp+0x20], xmm3
00007d3d957de4ad  lea rdi, [rsp]
00007d3d957de4b1  mov esi, 0x00
00007d3d957de4b6  mov rax, 0x56C27CB8A530
00007d3d957de4c0  call rax
00007d3d957de4c2  movaps xmm5, [rsp]
00007d3d957de4c6  add rsp, 0x30
00007d3d957de4ca  vmovaps xmm0, [rsp]
00007d3d957de4cf  vmovaps xmm1, [rsp+0x10]
00007d3d957de4d5  vmovaps xmm2, [rsp+0x20]
00007d3d957de4db  vmovaps xmm3, [rsp+0x30]
00007d3d957de4e1  vmovaps xmm4, [rsp+0x40]
00007d3d957de4e7  vmovaps xmm6, [rsp+0x50]
00007d3d957de4ed  vmovaps xmm7, [rsp+0x60]
00007d3d957de4f3  vmovaps xmm8, [rsp+0x70]
00007d3d957de4f9  vmovaps xmm9, [rsp+0x80]
00007d3d957de502  vmovaps xmm10, [rsp+0x90]
00007d3d957de50b  vmovaps xmm11, [rsp+0xA0]
00007d3d957de514  vmovaps xmm12, [rsp+0xB0]
00007d3d957de51d  vmovaps xmm13, [rsp+0xC0]
00007d3d957de526  vmovaps xmm14, [rsp+0xD0]
00007d3d957de52f  vmovaps xmm15, [rsp+0xE0]
00007d3d957de538  add rsp, 0xF0
00007d3d957de53f  pop r11
00007d3d957de541  pop r10
00007d3d957de543  pop r9
00007d3d957de545  pop r8
00007d3d957de547  pop rsi
00007d3d957de548  pop rdi
00007d3d957de549  pop rdx
00007d3d957de54a  pop rcx
00007d3d957de54b  pop rax
00007d3d957de54c  add rsp, 0x08
00007d3d957de550  jmp 0x00007D3D957DC13A
00007d3d957de555  sub rsp, 0x08
00007d3d957de559  push rax
00007d3d957de55a  push rcx
00007d3d957de55b  push rdx
00007d3d957de55c  push rdi
00007d3d957de55d  push rsi
00007d3d957de55e  push r8
00007d3d957de560  push r9
00007d3d957de562  push r10
00007d3d957de564  push r11
00007d3d957de566  sub rsp, 0xF0
00007d3d957de56d  vmovaps [rsp], xmm0
00007d3d957de572  vmovaps [rsp+0x10], xmm1
00007d3d957de578  vmovaps [rsp+0x20], xmm2
00007d3d957de57e  vmovaps [rsp+0x30], xmm3
00007d3d957de584  vmovaps [rsp+0x40], xmm4
00007d3d957de58a  vmovaps [rsp+0x50], xmm5
00007d3d957de590  vmovaps [rsp+0x60], xmm7
00007d3d957de596  vmovaps [rsp+0x70], xmm8
00007d3d957de59c  vmovaps [rsp+0x80], xmm9
00007d3d957de5a5  vmovaps [rsp+0x90], xmm10
00007d3d957de5ae  vmovaps [rsp+0xA0], xmm11
00007d3d957de5b7  vmovaps [rsp+0xB0], xmm12
00007d3d957de5c0  vmovaps [rsp+0xC0], xmm13
00007d3d957de5c9  vmovaps [rsp+0xD0], xmm14
00007d3d957de5d2  vmovaps [rsp+0xE0], xmm15
00007d3d957de5db  sub rsp, 0x30
00007d3d957de5df  movaps [rsp], xmm6
00007d3d957de5e3  movaps [rsp+0x10], xmm9
00007d3d957de5e9  movaps [rsp+0x20], xmm1
00007d3d957de5ee  lea rdi, [rsp]
00007d3d957de5f2  mov esi, 0x00
00007d3d957de5f7  mov rax, 0x56C27CB8A530
00007d3d957de601  call rax
00007d3d957de603  movaps xmm6, [rsp]
00007d3d957de607  add rsp, 0x30
00007d3d957de60b  vmovaps xmm0, [rsp]
00007d3d957de610  vmovaps xmm1, [rsp+0x10]
00007d3d957de616  vmovaps xmm2, [rsp+0x20]
00007d3d957de61c  vmovaps xmm3, [rsp+0x30]
00007d3d957de622  vmovaps xmm4, [rsp+0x40]
00007d3d957de628  vmovaps xmm5, [rsp+0x50]
00007d3d957de62e  vmovaps xmm7, [rsp+0x60]
00007d3d957de634  vmovaps xmm8, [rsp+0x70]
00007d3d957de63a  vmovaps xmm9, [rsp+0x80]
00007d3d957de643  vmovaps xmm10, [rsp+0x90]
00007d3d957de64c  vmovaps xmm11, [rsp+0xA0]
00007d3d957de655  vmovaps xmm12, [rsp+0xB0]
00007d3d957de65e  vmovaps xmm13, [rsp+0xC0]
00007d3d957de667  vmovaps xmm14, [rsp+0xD0]
00007d3d957de670  vmovaps xmm15, [rsp+0xE0]
00007d3d957de679  add rsp, 0xF0
00007d3d957de680  pop r11
00007d3d957de682  pop r10
00007d3d957de684  pop r9
00007d3d957de686  pop r8
00007d3d957de688  pop rsi
00007d3d957de689  pop rdi
00007d3d957de68a  pop rdx
00007d3d957de68b  pop rcx
00007d3d957de68c  pop rax
00007d3d957de68d  add rsp, 0x08
00007d3d957de691  jmp 0x00007D3D957DC15E
00007d3d957de696  sub rsp, 0x08
00007d3d957de69a  push rax
00007d3d957de69b  push rcx
00007d3d957de69c  push rdx
00007d3d957de69d  push rdi
00007d3d957de69e  push rsi
00007d3d957de69f  push r8
00007d3d957de6a1  push r9
00007d3d957de6a3  push r10
00007d3d957de6a5  push r11
00007d3d957de6a7  sub rsp, 0xF0
00007d3d957de6ae  vmovaps [rsp], xmm0
00007d3d957de6b3  vmovaps [rsp+0x10], xmm1
00007d3d957de6b9  vmovaps [rsp+0x20], xmm2
00007d3d957de6bf  vmovaps [rsp+0x30], xmm3
00007d3d957de6c5  vmovaps [rsp+0x40], xmm4
00007d3d957de6cb  vmovaps [rsp+0x50], xmm5
00007d3d957de6d1  vmovaps [rsp+0x60], xmm6
00007d3d957de6d7  vmovaps [rsp+0x70], xmm7
00007d3d957de6dd  vmovaps [rsp+0x80], xmm8
00007d3d957de6e6  vmovaps [rsp+0x90], xmm10
00007d3d957de6ef  vmovaps [rsp+0xA0], xmm11
00007d3d957de6f8  vmovaps [rsp+0xB0], xmm12
00007d3d957de701  vmovaps [rsp+0xC0], xmm13
00007d3d957de70a  vmovaps [rsp+0xD0], xmm14
00007d3d957de713  vmovaps [rsp+0xE0], xmm15
00007d3d957de71c  sub rsp, 0x30
00007d3d957de720  movaps [rsp], xmm9
00007d3d957de725  movaps [rsp+0x10], xmm3
00007d3d957de72a  movaps [rsp+0x20], xmm1
00007d3d957de72f  lea rdi, [rsp]
00007d3d957de733  mov esi, 0x00
00007d3d957de738  mov rax, 0x56C27CB8A530
00007d3d957de742  call rax
00007d3d957de744  movaps xmm9, [rsp]
00007d3d957de749  add rsp, 0x30
00007d3d957de74d  vmovaps xmm0, [rsp]
00007d3d957de752  vmovaps xmm1, [rsp+0x10]
00007d3d957de758  vmovaps xmm2, [rsp+0x20]
00007d3d957de75e  vmovaps xmm3, [rsp+0x30]
00007d3d957de764  vmovaps xmm4, [rsp+0x40]
00007d3d957de76a  vmovaps xmm5, [rsp+0x50]
00007d3d957de770  vmovaps xmm6, [rsp+0x60]
00007d3d957de776  vmovaps xmm7, [rsp+0x70]
00007d3d957de77c  vmovaps xmm8, [rsp+0x80]
00007d3d957de785  vmovaps xmm10, [rsp+0x90]
00007d3d957de78e  vmovaps xmm11, [rsp+0xA0]
00007d3d957de797  vmovaps xmm12, [rsp+0xB0]
00007d3d957de7a0  vmovaps xmm13, [rsp+0xC0]
00007d3d957de7a9  vmovaps xmm14, [rsp+0xD0]
00007d3d957de7b2  vmovaps xmm15, [rsp+0xE0]
00007d3d957de7bb  add rsp, 0xF0
00007d3d957de7c2  pop r11
00007d3d957de7c4  pop r10
00007d3d957de7c6  pop r9
00007d3d957de7c8  pop r8
00007d3d957de7ca  pop rsi
00007d3d957de7cb  pop rdi
00007d3d957de7cc  pop rdx
00007d3d957de7cd  pop rcx
00007d3d957de7ce  pop rax
00007d3d957de7cf  add rsp, 0x08
00007d3d957de7d3  jmp 0x00007D3D957DC1AA
00007d3d957de7d8  call 0x00007D3D956B52F0
00007d3d957de7dd  jmp 0x00007D3D957DC1B7
00007d3d957de7e2  sub rsp, 0x08
00007d3d957de7e6  push rax
00007d3d957de7e7  push rcx
00007d3d957de7e8  push rdx
00007d3d957de7e9  push rdi
00007d3d957de7ea  push rsi
00007d3d957de7eb  push r8
00007d3d957de7ed  push r9
00007d3d957de7ef  push r10
00007d3d957de7f1  push r11
00007d3d957de7f3  sub rsp, 0xF0
00007d3d957de7fa  vmovaps [rsp], xmm0
00007d3d957de7ff  vmovaps [rsp+0x10], xmm1
00007d3d957de805  vmovaps [rsp+0x20], xmm2
00007d3d957de80b  vmovaps [rsp+0x30], xmm3
00007d3d957de811  vmovaps [rsp+0x40], xmm4
00007d3d957de817  vmovaps [rsp+0x50], xmm5
00007d3d957de81d  vmovaps [rsp+0x60], xmm6
00007d3d957de823  vmovaps [rsp+0x70], xmm7
00007d3d957de829  vmovaps [rsp+0x80], xmm8
00007d3d957de832  vmovaps [rsp+0x90], xmm9
00007d3d957de83b  vmovaps [rsp+0xA0], xmm10
00007d3d957de844  vmovaps [rsp+0xB0], xmm11
00007d3d957de84d  vmovaps [rsp+0xC0], xmm12
00007d3d957de856  vmovaps [rsp+0xD0], xmm13
00007d3d957de85f  vmovaps [rsp+0xE0], xmm14
00007d3d957de868  sub rsp, 0x30
00007d3d957de86c  movaps [rsp], xmm15
00007d3d957de871  movaps [rsp+0x10], xmm3
00007d3d957de876  movaps [rsp+0x20], xmm7
00007d3d957de87b  lea rdi, [rsp]
00007d3d957de87f  mov esi, 0x00
00007d3d957de884  mov rax, 0x56C27CB8A530
00007d3d957de88e  call rax
00007d3d957de890  movaps xmm15, [rsp]
00007d3d957de895  add rsp, 0x30
00007d3d957de899  vmovaps xmm0, [rsp]
00007d3d957de89e  vmovaps xmm1, [rsp+0x10]
00007d3d957de8a4  vmovaps xmm2, [rsp+0x20]
00007d3d957de8aa  vmovaps xmm3, [rsp+0x30]
00007d3d957de8b0  vmovaps xmm4, [rsp+0x40]
00007d3d957de8b6  vmovaps xmm5, [rsp+0x50]
00007d3d957de8bc  vmovaps xmm6, [rsp+0x60]
00007d3d957de8c2  vmovaps xmm7, [rsp+0x70]
00007d3d957de8c8  vmovaps xmm8, [rsp+0x80]
00007d3d957de8d1  vmovaps xmm9, [rsp+0x90]
00007d3d957de8da  vmovaps xmm10, [rsp+0xA0]
00007d3d957de8e3  vmovaps xmm11, [rsp+0xB0]
00007d3d957de8ec  vmovaps xmm12, [rsp+0xC0]
00007d3d957de8f5  vmovaps xmm13, [rsp+0xD0]
00007d3d957de8fe  vmovaps xmm14, [rsp+0xE0]
00007d3d957de907  add rsp, 0xF0
00007d3d957de90e  pop r11
00007d3d957de910  pop r10
00007d3d957de912  pop r9
00007d3d957de914  pop r8
00007d3d957de916  pop rsi
00007d3d957de917  pop rdi
00007d3d957de918  pop rdx
00007d3d957de919  pop rcx
00007d3d957de91a  pop rax
00007d3d957de91b  add rsp, 0x08
00007d3d957de91f  jmp 0x00007D3D957DC1E3
00007d3d957de924  sub rsp, 0x08
00007d3d957de928  push rax
00007d3d957de929  push rcx
00007d3d957de92a  push rdx
00007d3d957de92b  push rdi
00007d3d957de92c  push rsi
00007d3d957de92d  push r8
00007d3d957de92f  push r9
00007d3d957de931  push r10
00007d3d957de933  push r11
00007d3d957de935  sub rsp, 0xF0
00007d3d957de93c  vmovaps [rsp], xmm0
00007d3d957de941  vmovaps [rsp+0x10], xmm1
00007d3d957de947  vmovaps [rsp+0x20], xmm2
00007d3d957de94d  vmovaps [rsp+0x30], xmm4
00007d3d957de953  vmovaps [rsp+0x40], xmm5
00007d3d957de959  vmovaps [rsp+0x50], xmm6
00007d3d957de95f  vmovaps [rsp+0x60], xmm7
00007d3d957de965  vmovaps [rsp+0x70], xmm8
00007d3d957de96b  vmovaps [rsp+0x80], xmm9
00007d3d957de974  vmovaps [rsp+0x90], xmm10
00007d3d957de97d  vmovaps [rsp+0xA0], xmm11
00007d3d957de986  vmovaps [rsp+0xB0], xmm12
00007d3d957de98f  vmovaps [rsp+0xC0], xmm13
00007d3d957de998  vmovaps [rsp+0xD0], xmm14
00007d3d957de9a1  vmovaps [rsp+0xE0], xmm15
00007d3d957de9aa  sub rsp, 0x30
00007d3d957de9ae  movaps [rsp], xmm3
00007d3d957de9b2  movaps [rsp+0x10], xmm1
00007d3d957de9b7  movaps [rsp+0x20], xmm15
00007d3d957de9bd  lea rdi, [rsp]
00007d3d957de9c1  mov esi, 0x00
00007d3d957de9c6  mov rax, 0x56C27CB8A530
00007d3d957de9d0  call rax
00007d3d957de9d2  movaps xmm3, [rsp]
00007d3d957de9d6  add rsp, 0x30
00007d3d957de9da  vmovaps xmm0, [rsp]
00007d3d957de9df  vmovaps xmm1, [rsp+0x10]
00007d3d957de9e5  vmovaps xmm2, [rsp+0x20]
00007d3d957de9eb  vmovaps xmm4, [rsp+0x30]
00007d3d957de9f1  vmovaps xmm5, [rsp+0x40]
00007d3d957de9f7  vmovaps xmm6, [rsp+0x50]
00007d3d957de9fd  vmovaps xmm7, [rsp+0x60]
00007d3d957dea03  vmovaps xmm8, [rsp+0x70]
00007d3d957dea09  vmovaps xmm9, [rsp+0x80]
00007d3d957dea12  vmovaps xmm10, [rsp+0x90]
00007d3d957dea1b  vmovaps xmm11, [rsp+0xA0]
00007d3d957dea24  vmovaps xmm12, [rsp+0xB0]
00007d3d957dea2d  vmovaps xmm13, [rsp+0xC0]
00007d3d957dea36  vmovaps xmm14, [rsp+0xD0]
00007d3d957dea3f  vmovaps xmm15, [rsp+0xE0]
00007d3d957dea48  add rsp, 0xF0
00007d3d957dea4f  pop r11
00007d3d957dea51  pop r10
00007d3d957dea53  pop r9
00007d3d957dea55  pop r8
00007d3d957dea57  pop rsi
00007d3d957dea58  pop rdi
00007d3d957dea59  pop rdx
00007d3d957dea5a  pop rcx
00007d3d957dea5b  pop rax
00007d3d957dea5c  add rsp, 0x08
00007d3d957dea60  jmp 0x00007D3D957DC272
00007d3d957dea65  call 0x00007D3D956B52F0
00007d3d957dea6a  jmp 0x00007D3D957DC27C
00007d3d957dea6f  sub rsp, 0x08
00007d3d957dea73  push rax
00007d3d957dea74  push rcx
00007d3d957dea75  push rdx
00007d3d957dea76  push rdi
00007d3d957dea77  push rsi
00007d3d957dea78  push r8
00007d3d957dea7a  push r9
00007d3d957dea7c  push r10
00007d3d957dea7e  push r11
00007d3d957dea80  sub rsp, 0xF0
00007d3d957dea87  vmovaps [rsp], xmm0
00007d3d957dea8c  vmovaps [rsp+0x10], xmm1
00007d3d957dea92  vmovaps [rsp+0x20], xmm2
00007d3d957dea98  vmovaps [rsp+0x30], xmm3
00007d3d957dea9e  vmovaps [rsp+0x40], xmm4
00007d3d957deaa4  vmovaps [rsp+0x50], xmm5
00007d3d957deaaa  vmovaps [rsp+0x60], xmm6
00007d3d957deab0  vmovaps [rsp+0x70], xmm7
00007d3d957deab6  vmovaps [rsp+0x80], xmm8
00007d3d957deabf  vmovaps [rsp+0x90], xmm9
00007d3d957deac8  vmovaps [rsp+0xA0], xmm10
00007d3d957dead1  vmovaps [rsp+0xB0], xmm11
00007d3d957deada  vmovaps [rsp+0xC0], xmm12
00007d3d957deae3  vmovaps [rsp+0xD0], xmm13
00007d3d957deaec  vmovaps [rsp+0xE0], xmm14
00007d3d957deaf5  sub rsp, 0x30
00007d3d957deaf9  movaps [rsp], xmm15
00007d3d957deafe  movaps [rsp+0x10], xmm14
00007d3d957deb04  movaps [rsp+0x20], xmm4
00007d3d957deb09  lea rdi, [rsp]
00007d3d957deb0d  mov esi, 0x00
00007d3d957deb12  mov rax, 0x56C27CB8A530
00007d3d957deb1c  call rax
00007d3d957deb1e  movaps xmm15, [rsp]
00007d3d957deb23  add rsp, 0x30
00007d3d957deb27  vmovaps xmm0, [rsp]
00007d3d957deb2c  vmovaps xmm1, [rsp+0x10]
00007d3d957deb32  vmovaps xmm2, [rsp+0x20]
00007d3d957deb38  vmovaps xmm3, [rsp+0x30]
00007d3d957deb3e  vmovaps xmm4, [rsp+0x40]
00007d3d957deb44  vmovaps xmm5, [rsp+0x50]
00007d3d957deb4a  vmovaps xmm6, [rsp+0x60]
00007d3d957deb50  vmovaps xmm7, [rsp+0x70]
00007d3d957deb56  vmovaps xmm8, [rsp+0x80]
00007d3d957deb5f  vmovaps xmm9, [rsp+0x90]
00007d3d957deb68  vmovaps xmm10, [rsp+0xA0]
00007d3d957deb71  vmovaps xmm11, [rsp+0xB0]
00007d3d957deb7a  vmovaps xmm12, [rsp+0xC0]
00007d3d957deb83  vmovaps xmm13, [rsp+0xD0]
00007d3d957deb8c  vmovaps xmm14, [rsp+0xE0]
00007d3d957deb95  add rsp, 0xF0
00007d3d957deb9c  pop r11
00007d3d957deb9e  pop r10
00007d3d957deba0  pop r9
00007d3d957deba2  pop r8
00007d3d957deba4  pop rsi
00007d3d957deba5  pop rdi
00007d3d957deba6  pop rdx
00007d3d957deba7  pop rcx
00007d3d957deba8  pop rax
00007d3d957deba9  add rsp, 0x08
00007d3d957debad  jmp 0x00007D3D957DC2AA
00007d3d957debb2  sub rsp, 0x08
00007d3d957debb6  push rax
00007d3d957debb7  push rcx
00007d3d957debb8  push rdx
00007d3d957debb9  push rdi
00007d3d957debba  push rsi
00007d3d957debbb  push r8
00007d3d957debbd  push r9
00007d3d957debbf  push r10
00007d3d957debc1  push r11
00007d3d957debc3  sub rsp, 0xF0
00007d3d957debca  vmovaps [rsp], xmm0
00007d3d957debcf  vmovaps [rsp+0x10], xmm1
00007d3d957debd5  vmovaps [rsp+0x20], xmm2
00007d3d957debdb  vmovaps [rsp+0x30], xmm3
00007d3d957debe1  vmovaps [rsp+0x40], xmm4
00007d3d957debe7  vmovaps [rsp+0x50], xmm5
00007d3d957debed  vmovaps [rsp+0x60], xmm6
00007d3d957debf3  vmovaps [rsp+0x70], xmm7
00007d3d957debf9  vmovaps [rsp+0x80], xmm8
00007d3d957dec02  vmovaps [rsp+0x90], xmm9
00007d3d957dec0b  vmovaps [rsp+0xA0], xmm10
00007d3d957dec14  vmovaps [rsp+0xB0], xmm11
00007d3d957dec1d  vmovaps [rsp+0xC0], xmm12
00007d3d957dec26  vmovaps [rsp+0xD0], xmm13
00007d3d957dec2f  vmovaps [rsp+0xE0], xmm15
00007d3d957dec38  sub rsp, 0x30
00007d3d957dec3c  movaps [rsp], xmm14
00007d3d957dec41  movaps [rsp+0x10], xmm2
00007d3d957dec46  movaps [rsp+0x20], xmm1
00007d3d957dec4b  lea rdi, [rsp]
00007d3d957dec4f  mov esi, 0x00
00007d3d957dec54  mov rax, 0x56C27CB8A530
00007d3d957dec5e  call rax
00007d3d957dec60  movaps xmm14, [rsp]
00007d3d957dec65  add rsp, 0x30
00007d3d957dec69  vmovaps xmm0, [rsp]
00007d3d957dec6e  vmovaps xmm1, [rsp+0x10]
00007d3d957dec74  vmovaps xmm2, [rsp+0x20]
00007d3d957dec7a  vmovaps xmm3, [rsp+0x30]
00007d3d957dec80  vmovaps xmm4, [rsp+0x40]
00007d3d957dec86  vmovaps xmm5, [rsp+0x50]
00007d3d957dec8c  vmovaps xmm6, [rsp+0x60]
00007d3d957dec92  vmovaps xmm7, [rsp+0x70]
00007d3d957dec98  vmovaps xmm8, [rsp+0x80]
00007d3d957deca1  vmovaps xmm9, [rsp+0x90]
00007d3d957decaa  vmovaps xmm10, [rsp+0xA0]
00007d3d957decb3  vmovaps xmm11, [rsp+0xB0]
00007d3d957decbc  vmovaps xmm12, [rsp+0xC0]
00007d3d957decc5  vmovaps xmm13, [rsp+0xD0]
00007d3d957decce  vmovaps xmm15, [rsp+0xE0]
00007d3d957decd7  add rsp, 0xF0
00007d3d957decde  pop r11
00007d3d957dece0  pop r10
00007d3d957dece2  pop r9
00007d3d957dece4  pop r8
00007d3d957dece6  pop rsi
00007d3d957dece7  pop rdi
00007d3d957dece8  pop rdx
00007d3d957dece9  pop rcx
00007d3d957decea  pop rax
00007d3d957deceb  add rsp, 0x08
00007d3d957decef  jmp 0x00007D3D957DC2D0
00007d3d957decf4  sub rsp, 0x08
00007d3d957decf8  push rax
00007d3d957decf9  push rcx
00007d3d957decfa  push rdx
00007d3d957decfb  push rdi
00007d3d957decfc  push rsi
00007d3d957decfd  push r8
00007d3d957decff  push r9
00007d3d957ded01  push r10
00007d3d957ded03  push r11
00007d3d957ded05  sub rsp, 0xF0
00007d3d957ded0c  vmovaps [rsp], xmm0
00007d3d957ded11  vmovaps [rsp+0x10], xmm2
00007d3d957ded17  vmovaps [rsp+0x20], xmm3
00007d3d957ded1d  vmovaps [rsp+0x30], xmm4
00007d3d957ded23  vmovaps [rsp+0x40], xmm5
00007d3d957ded29  vmovaps [rsp+0x50], xmm6
00007d3d957ded2f  vmovaps [rsp+0x60], xmm7
00007d3d957ded35  vmovaps [rsp+0x70], xmm8
00007d3d957ded3b  vmovaps [rsp+0x80], xmm9
00007d3d957ded44  vmovaps [rsp+0x90], xmm10
00007d3d957ded4d  vmovaps [rsp+0xA0], xmm11
00007d3d957ded56  vmovaps [rsp+0xB0], xmm12
00007d3d957ded5f  vmovaps [rsp+0xC0], xmm13
00007d3d957ded68  vmovaps [rsp+0xD0], xmm14
00007d3d957ded71  vmovaps [rsp+0xE0], xmm15
00007d3d957ded7a  sub rsp, 0x30
00007d3d957ded7e  movaps [rsp], xmm1
00007d3d957ded82  movaps [rsp+0x10], xmm4
00007d3d957ded87  movaps [rsp+0x20], xmm9
00007d3d957ded8d  lea rdi, [rsp]
00007d3d957ded91  mov esi, 0x00
00007d3d957ded96  mov rax, 0x56C27CB8A530
00007d3d957deda0  call rax
00007d3d957deda2  movaps xmm1, [rsp]
00007d3d957deda6  add rsp, 0x30
00007d3d957dedaa  vmovaps xmm0, [rsp]
00007d3d957dedaf  vmovaps xmm2, [rsp+0x10]
00007d3d957dedb5  vmovaps xmm3, [rsp+0x20]
00007d3d957dedbb  vmovaps xmm4, [rsp+0x30]
00007d3d957dedc1  vmovaps xmm5, [rsp+0x40]
00007d3d957dedc7  vmovaps xmm6, [rsp+0x50]
00007d3d957dedcd  vmovaps xmm7, [rsp+0x60]
00007d3d957dedd3  vmovaps xmm8, [rsp+0x70]
00007d3d957dedd9  vmovaps xmm9, [rsp+0x80]
00007d3d957dede2  vmovaps xmm10, [rsp+0x90]
00007d3d957dedeb  vmovaps xmm11, [rsp+0xA0]
00007d3d957dedf4  vmovaps xmm12, [rsp+0xB0]
00007d3d957dedfd  vmovaps xmm13, [rsp+0xC0]
00007d3d957dee06  vmovaps xmm14, [rsp+0xD0]
00007d3d957dee0f  vmovaps xmm15, [rsp+0xE0]
00007d3d957dee18  add rsp, 0xF0
00007d3d957dee1f  pop r11
00007d3d957dee21  pop r10
00007d3d957dee23  pop r9
00007d3d957dee25  pop r8
00007d3d957dee27  pop rsi
00007d3d957dee28  pop rdi
00007d3d957dee29  pop rdx
00007d3d957dee2a  pop rcx
00007d3d957dee2b  pop rax
00007d3d957dee2c  add rsp, 0x08
00007d3d957dee30  jmp 0x00007D3D957DC2EE
00007d3d957dee35  sub rsp, 0x08
00007d3d957dee39  push rax
00007d3d957dee3a  push rcx
00007d3d957dee3b  push rdx
00007d3d957dee3c  push rdi
00007d3d957dee3d  push rsi
00007d3d957dee3e  push r8
00007d3d957dee40  push r9
00007d3d957dee42  push r10
00007d3d957dee44  push r11
00007d3d957dee46  sub rsp, 0xF0
00007d3d957dee4d  vmovaps [rsp], xmm0
00007d3d957dee52  vmovaps [rsp+0x10], xmm1
00007d3d957dee58  vmovaps [rsp+0x20], xmm2
00007d3d957dee5e  vmovaps [rsp+0x30], xmm3
00007d3d957dee64  vmovaps [rsp+0x40], xmm5
00007d3d957dee6a  vmovaps [rsp+0x50], xmm6
00007d3d957dee70  vmovaps [rsp+0x60], xmm7
00007d3d957dee76  vmovaps [rsp+0x70], xmm8
00007d3d957dee7c  vmovaps [rsp+0x80], xmm9
00007d3d957dee85  vmovaps [rsp+0x90], xmm10
00007d3d957dee8e  vmovaps [rsp+0xA0], xmm11
00007d3d957dee97  vmovaps [rsp+0xB0], xmm12
00007d3d957deea0  vmovaps [rsp+0xC0], xmm13
00007d3d957deea9  vmovaps [rsp+0xD0], xmm14
00007d3d957deeb2  vmovaps [rsp+0xE0], xmm15
00007d3d957deebb  sub rsp, 0x30
00007d3d957deebf  movaps [rsp], xmm4
00007d3d957deec3  movaps [rsp+0x10], xmm2
00007d3d957deec8  movaps [rsp+0x20], xmm9
00007d3d957deece  lea rdi, [rsp]
00007d3d957deed2  mov esi, 0x00
00007d3d957deed7  mov rax, 0x56C27CB8A530
00007d3d957deee1  call rax
00007d3d957deee3  movaps xmm4, [rsp]
00007d3d957deee7  add rsp, 0x30
00007d3d957deeeb  vmovaps xmm0, [rsp]
00007d3d957deef0  vmovaps xmm1, [rsp+0x10]
00007d3d957deef6  vmovaps xmm2, [rsp+0x20]
00007d3d957deefc  vmovaps xmm3, [rsp+0x30]
00007d3d957def02  vmovaps xmm5, [rsp+0x40]
00007d3d957def08  vmovaps xmm6, [rsp+0x50]
00007d3d957def0e  vmovaps xmm7, [rsp+0x60]
00007d3d957def14  vmovaps xmm8, [rsp+0x70]
00007d3d957def1a  vmovaps xmm9, [rsp+0x80]
00007d3d957def23  vmovaps xmm10, [rsp+0x90]
00007d3d957def2c  vmovaps xmm11, [rsp+0xA0]
00007d3d957def35  vmovaps xmm12, [rsp+0xB0]
00007d3d957def3e  vmovaps xmm13, [rsp+0xC0]
00007d3d957def47  vmovaps xmm14, [rsp+0xD0]
00007d3d957def50  vmovaps xmm15, [rsp+0xE0]
00007d3d957def59  add rsp, 0xF0
00007d3d957def60  pop r11
00007d3d957def62  pop r10
00007d3d957def64  pop r9
00007d3d957def66  pop r8
00007d3d957def68  pop rsi
00007d3d957def69  pop rdi
00007d3d957def6a  pop rdx
00007d3d957def6b  pop rcx
00007d3d957def6c  pop rax
00007d3d957def6d  add rsp, 0x08
00007d3d957def71  jmp 0x00007D3D957DC31E
00007d3d957def76  sub rsp, 0x08
00007d3d957def7a  push rax
00007d3d957def7b  push rcx
00007d3d957def7c  push rdx
00007d3d957def7d  push rdi
00007d3d957def7e  push rsi
00007d3d957def7f  push r8
00007d3d957def81  push r9
00007d3d957def83  push r10
00007d3d957def85  push r11
00007d3d957def87  sub rsp, 0xF0
00007d3d957def8e  vmovaps [rsp], xmm0
00007d3d957def93  vmovaps [rsp+0x10], xmm1
00007d3d957def99  vmovaps [rsp+0x20], xmm2
00007d3d957def9f  vmovaps [rsp+0x30], xmm3
00007d3d957defa5  vmovaps [rsp+0x40], xmm4
00007d3d957defab  vmovaps [rsp+0x50], xmm5
00007d3d957defb1  vmovaps [rsp+0x60], xmm6
00007d3d957defb7  vmovaps [rsp+0x70], xmm7
00007d3d957defbd  vmovaps [rsp+0x80], xmm8
00007d3d957defc6  vmovaps [rsp+0x90], xmm10
00007d3d957defcf  vmovaps [rsp+0xA0], xmm11
00007d3d957defd8  vmovaps [rsp+0xB0], xmm12
00007d3d957defe1  vmovaps [rsp+0xC0], xmm13
00007d3d957defea  vmovaps [rsp+0xD0], xmm14
00007d3d957deff3  vmovaps [rsp+0xE0], xmm15
00007d3d957deffc  sub rsp, 0x30
00007d3d957df000  movaps [rsp], xmm9
00007d3d957df005  movaps [rsp+0x10], xmm2
00007d3d957df00a  movaps [rsp+0x20], xmm1
00007d3d957df00f  lea rdi, [rsp]
00007d3d957df013  mov esi, 0x00
00007d3d957df018  mov rax, 0x56C27CB8A530
00007d3d957df022  call rax
00007d3d957df024  movaps xmm9, [rsp]
00007d3d957df029  add rsp, 0x30
00007d3d957df02d  vmovaps xmm0, [rsp]
00007d3d957df032  vmovaps xmm1, [rsp+0x10]
00007d3d957df038  vmovaps xmm2, [rsp+0x20]
00007d3d957df03e  vmovaps xmm3, [rsp+0x30]
00007d3d957df044  vmovaps xmm4, [rsp+0x40]
00007d3d957df04a  vmovaps xmm5, [rsp+0x50]
00007d3d957df050  vmovaps xmm6, [rsp+0x60]
00007d3d957df056  vmovaps xmm7, [rsp+0x70]
00007d3d957df05c  vmovaps xmm8, [rsp+0x80]
00007d3d957df065  vmovaps xmm10, [rsp+0x90]
00007d3d957df06e  vmovaps xmm11, [rsp+0xA0]
00007d3d957df077  vmovaps xmm12, [rsp+0xB0]
00007d3d957df080  vmovaps xmm13, [rsp+0xC0]
00007d3d957df089  vmovaps xmm14, [rsp+0xD0]
00007d3d957df092  vmovaps xmm15, [rsp+0xE0]
00007d3d957df09b  add rsp, 0xF0
00007d3d957df0a2  pop r11
00007d3d957df0a4  pop r10
00007d3d957df0a6  pop r9
00007d3d957df0a8  pop r8
00007d3d957df0aa  pop rsi
00007d3d957df0ab  pop rdi
00007d3d957df0ac  pop rdx
00007d3d957df0ad  pop rcx
00007d3d957df0ae  pop rax
00007d3d957df0af  add rsp, 0x08
00007d3d957df0b3  jmp 0x00007D3D957DC354
00007d3d957df0b8  sub rsp, 0x08
00007d3d957df0bc  push rax
00007d3d957df0bd  push rcx
00007d3d957df0be  push rdx
00007d3d957df0bf  push rdi
00007d3d957df0c0  push rsi
00007d3d957df0c1  push r8
00007d3d957df0c3  push r9
00007d3d957df0c5  push r10
00007d3d957df0c7  push r11
00007d3d957df0c9  sub rsp, 0xF0
00007d3d957df0d0  vmovaps [rsp], xmm0
00007d3d957df0d5  vmovaps [rsp+0x10], xmm2
00007d3d957df0db  vmovaps [rsp+0x20], xmm3
00007d3d957df0e1  vmovaps [rsp+0x30], xmm4
00007d3d957df0e7  vmovaps [rsp+0x40], xmm5
00007d3d957df0ed  vmovaps [rsp+0x50], xmm6
00007d3d957df0f3  vmovaps [rsp+0x60], xmm7
00007d3d957df0f9  vmovaps [rsp+0x70], xmm8
00007d3d957df0ff  vmovaps [rsp+0x80], xmm9
00007d3d957df108  vmovaps [rsp+0x90], xmm10
00007d3d957df111  vmovaps [rsp+0xA0], xmm11
00007d3d957df11a  vmovaps [rsp+0xB0], xmm12
00007d3d957df123  vmovaps [rsp+0xC0], xmm13
00007d3d957df12c  vmovaps [rsp+0xD0], xmm14
00007d3d957df135  vmovaps [rsp+0xE0], xmm15
00007d3d957df13e  sub rsp, 0x30
00007d3d957df142  movaps [rsp], xmm1
00007d3d957df146  movaps [rsp+0x10], xmm15
00007d3d957df14c  movaps [rsp+0x20], xmm6
00007d3d957df151  lea rdi, [rsp]
00007d3d957df155  mov esi, 0x00
00007d3d957df15a  mov rax, 0x56C27CB8A530
00007d3d957df164  call rax
00007d3d957df166  movaps xmm1, [rsp]
00007d3d957df16a  add rsp, 0x30
00007d3d957df16e  vmovaps xmm0, [rsp]
00007d3d957df173  vmovaps xmm2, [rsp+0x10]
00007d3d957df179  vmovaps xmm3, [rsp+0x20]
00007d3d957df17f  vmovaps xmm4, [rsp+0x30]
00007d3d957df185  vmovaps xmm5, [rsp+0x40]
00007d3d957df18b  vmovaps xmm6, [rsp+0x50]
00007d3d957df191  vmovaps xmm7, [rsp+0x60]
00007d3d957df197  vmovaps xmm8, [rsp+0x70]
00007d3d957df19d  vmovaps xmm9, [rsp+0x80]
00007d3d957df1a6  vmovaps xmm10, [rsp+0x90]
00007d3d957df1af  vmovaps xmm11, [rsp+0xA0]
00007d3d957df1b8  vmovaps xmm12, [rsp+0xB0]
00007d3d957df1c1  vmovaps xmm13, [rsp+0xC0]
00007d3d957df1ca  vmovaps xmm14, [rsp+0xD0]
00007d3d957df1d3  vmovaps xmm15, [rsp+0xE0]
00007d3d957df1dc  add rsp, 0xF0
00007d3d957df1e3  pop r11
00007d3d957df1e5  pop r10
00007d3d957df1e7  pop r9
00007d3d957df1e9  pop r8
00007d3d957df1eb  pop rsi
00007d3d957df1ec  pop rdi
00007d3d957df1ed  pop rdx
00007d3d957df1ee  pop rcx
00007d3d957df1ef  pop rax
00007d3d957df1f0  add rsp, 0x08
00007d3d957df1f4  jmp 0x00007D3D957DC375
00007d3d957df1f9  sub rsp, 0x08
00007d3d957df1fd  push rax
00007d3d957df1fe  push rcx
00007d3d957df1ff  push rdx
00007d3d957df200  push rdi
00007d3d957df201  push rsi
00007d3d957df202  push r8
00007d3d957df204  push r9
00007d3d957df206  push r10
00007d3d957df208  push r11
00007d3d957df20a  sub rsp, 0xF0
00007d3d957df211  vmovaps [rsp], xmm0
00007d3d957df216  vmovaps [rsp+0x10], xmm1
00007d3d957df21c  vmovaps [rsp+0x20], xmm2
00007d3d957df222  vmovaps [rsp+0x30], xmm3
00007d3d957df228  vmovaps [rsp+0x40], xmm4
00007d3d957df22e  vmovaps [rsp+0x50], xmm5
00007d3d957df234  vmovaps [rsp+0x60], xmm6
00007d3d957df23a  vmovaps [rsp+0x70], xmm7
00007d3d957df240  vmovaps [rsp+0x80], xmm8
00007d3d957df249  vmovaps [rsp+0x90], xmm9
00007d3d957df252  vmovaps [rsp+0xA0], xmm10
00007d3d957df25b  vmovaps [rsp+0xB0], xmm11
00007d3d957df264  vmovaps [rsp+0xC0], xmm12
00007d3d957df26d  vmovaps [rsp+0xD0], xmm13
00007d3d957df276  vmovaps [rsp+0xE0], xmm14
00007d3d957df27f  sub rsp, 0x30
00007d3d957df283  movaps [rsp], xmm15
00007d3d957df288  movaps [rsp+0x10], xmm5
00007d3d957df28d  movaps [rsp+0x20], xmm3
00007d3d957df292  lea rdi, [rsp]
00007d3d957df296  mov esi, 0x00
00007d3d957df29b  mov rax, 0x56C27CB8A530
00007d3d957df2a5  call rax
00007d3d957df2a7  movaps xmm15, [rsp]
00007d3d957df2ac  add rsp, 0x30
00007d3d957df2b0  vmovaps xmm0, [rsp]
00007d3d957df2b5  vmovaps xmm1, [rsp+0x10]
00007d3d957df2bb  vmovaps xmm2, [rsp+0x20]
00007d3d957df2c1  vmovaps xmm3, [rsp+0x30]
00007d3d957df2c7  vmovaps xmm4, [rsp+0x40]
00007d3d957df2cd  vmovaps xmm5, [rsp+0x50]
00007d3d957df2d3  vmovaps xmm6, [rsp+0x60]
00007d3d957df2d9  vmovaps xmm7, [rsp+0x70]
00007d3d957df2df  vmovaps xmm8, [rsp+0x80]
00007d3d957df2e8  vmovaps xmm9, [rsp+0x90]
00007d3d957df2f1  vmovaps xmm10, [rsp+0xA0]
00007d3d957df2fa  vmovaps xmm11, [rsp+0xB0]
00007d3d957df303  vmovaps xmm12, [rsp+0xC0]
00007d3d957df30c  vmovaps xmm13, [rsp+0xD0]
00007d3d957df315  vmovaps xmm14, [rsp+0xE0]
00007d3d957df31e  add rsp, 0xF0
00007d3d957df325  pop r11
00007d3d957df327  pop r10
00007d3d957df329  pop r9
00007d3d957df32b  pop r8
00007d3d957df32d  pop rsi
00007d3d957df32e  pop rdi
00007d3d957df32f  pop rdx
00007d3d957df330  pop rcx
00007d3d957df331  pop rax
00007d3d957df332  add rsp, 0x08
00007d3d957df336  jmp 0x00007D3D957DC38F
00007d3d957df33b  sub rsp, 0x08
00007d3d957df33f  push rax
00007d3d957df340  push rcx
00007d3d957df341  push rdx
00007d3d957df342  push rdi
00007d3d957df343  push rsi
00007d3d957df344  push r8
00007d3d957df346  push r9
00007d3d957df348  push r10
00007d3d957df34a  push r11
00007d3d957df34c  sub rsp, 0xF0
00007d3d957df353  vmovaps [rsp], xmm0
00007d3d957df358  vmovaps [rsp+0x10], xmm1
00007d3d957df35e  vmovaps [rsp+0x20], xmm2
00007d3d957df364  vmovaps [rsp+0x30], xmm3
00007d3d957df36a  vmovaps [rsp+0x40], xmm4
00007d3d957df370  vmovaps [rsp+0x50], xmm6
00007d3d957df376  vmovaps [rsp+0x60], xmm7
00007d3d957df37c  vmovaps [rsp+0x70], xmm8
00007d3d957df382  vmovaps [rsp+0x80], xmm9
00007d3d957df38b  vmovaps [rsp+0x90], xmm10
00007d3d957df394  vmovaps [rsp+0xA0], xmm11
00007d3d957df39d  vmovaps [rsp+0xB0], xmm12
00007d3d957df3a6  vmovaps [rsp+0xC0], xmm13
00007d3d957df3af  vmovaps [rsp+0xD0], xmm14
00007d3d957df3b8  vmovaps [rsp+0xE0], xmm15
00007d3d957df3c1  sub rsp, 0x30
00007d3d957df3c5  movaps [rsp], xmm5
00007d3d957df3c9  movaps [rsp+0x10], xmm8
00007d3d957df3cf  movaps [rsp+0x20], xmm6
00007d3d957df3d4  lea rdi, [rsp]
00007d3d957df3d8  mov esi, 0x00
00007d3d957df3dd  mov rax, 0x56C27CB8A530
00007d3d957df3e7  call rax
00007d3d957df3e9  movaps xmm5, [rsp]
00007d3d957df3ed  add rsp, 0x30
00007d3d957df3f1  vmovaps xmm0, [rsp]
00007d3d957df3f6  vmovaps xmm1, [rsp+0x10]
00007d3d957df3fc  vmovaps xmm2, [rsp+0x20]
00007d3d957df402  vmovaps xmm3, [rsp+0x30]
00007d3d957df408  vmovaps xmm4, [rsp+0x40]
00007d3d957df40e  vmovaps xmm6, [rsp+0x50]
00007d3d957df414  vmovaps xmm7, [rsp+0x60]
00007d3d957df41a  vmovaps xmm8, [rsp+0x70]
00007d3d957df420  vmovaps xmm9, [rsp+0x80]
00007d3d957df429  vmovaps xmm10, [rsp+0x90]
00007d3d957df432  vmovaps xmm11, [rsp+0xA0]
00007d3d957df43b  vmovaps xmm12, [rsp+0xB0]
00007d3d957df444  vmovaps xmm13, [rsp+0xC0]
00007d3d957df44d  vmovaps xmm14, [rsp+0xD0]
00007d3d957df456  vmovaps xmm15, [rsp+0xE0]
00007d3d957df45f  add rsp, 0xF0
00007d3d957df466  pop r11
00007d3d957df468  pop r10
00007d3d957df46a  pop r9
00007d3d957df46c  pop r8
00007d3d957df46e  pop rsi
00007d3d957df46f  pop rdi
00007d3d957df470  pop rdx
00007d3d957df471  pop rcx
00007d3d957df472  pop rax
00007d3d957df473  add rsp, 0x08
00007d3d957df477  jmp 0x00007D3D957DC3B3
00007d3d957df47c  sub rsp, 0x08
00007d3d957df480  push rax
00007d3d957df481  push rcx
00007d3d957df482  push rdx
00007d3d957df483  push rdi
00007d3d957df484  push rsi
00007d3d957df485  push r8
00007d3d957df487  push r9
00007d3d957df489  push r10
00007d3d957df48b  push r11
00007d3d957df48d  sub rsp, 0xF0
00007d3d957df494  vmovaps [rsp], xmm0
00007d3d957df499  vmovaps [rsp+0x10], xmm1
00007d3d957df49f  vmovaps [rsp+0x20], xmm2
00007d3d957df4a5  vmovaps [rsp+0x30], xmm3
00007d3d957df4ab  vmovaps [rsp+0x40], xmm4
00007d3d957df4b1  vmovaps [rsp+0x50], xmm5
00007d3d957df4b7  vmovaps [rsp+0x60], xmm7
00007d3d957df4bd  vmovaps [rsp+0x70], xmm8
00007d3d957df4c3  vmovaps [rsp+0x80], xmm9
00007d3d957df4cc  vmovaps [rsp+0x90], xmm10
00007d3d957df4d5  vmovaps [rsp+0xA0], xmm11
00007d3d957df4de  vmovaps [rsp+0xB0], xmm12
00007d3d957df4e7  vmovaps [rsp+0xC0], xmm13
00007d3d957df4f0  vmovaps [rsp+0xD0], xmm14
00007d3d957df4f9  vmovaps [rsp+0xE0], xmm15
00007d3d957df502  sub rsp, 0x30
00007d3d957df506  movaps [rsp], xmm6
00007d3d957df50a  movaps [rsp+0x10], xmm10
00007d3d957df510  movaps [rsp+0x20], xmm8
00007d3d957df516  lea rdi, [rsp]
00007d3d957df51a  mov esi, 0x00
00007d3d957df51f  mov rax, 0x56C27CB8A530
00007d3d957df529  call rax
00007d3d957df52b  movaps xmm6, [rsp]
00007d3d957df52f  add rsp, 0x30
00007d3d957df533  vmovaps xmm0, [rsp]
00007d3d957df538  vmovaps xmm1, [rsp+0x10]
00007d3d957df53e  vmovaps xmm2, [rsp+0x20]
00007d3d957df544  vmovaps xmm3, [rsp+0x30]
00007d3d957df54a  vmovaps xmm4, [rsp+0x40]
00007d3d957df550  vmovaps xmm5, [rsp+0x50]
00007d3d957df556  vmovaps xmm7, [rsp+0x60]
00007d3d957df55c  vmovaps xmm8, [rsp+0x70]
00007d3d957df562  vmovaps xmm9, [rsp+0x80]
00007d3d957df56b  vmovaps xmm10, [rsp+0x90]
00007d3d957df574  vmovaps xmm11, [rsp+0xA0]
00007d3d957df57d  vmovaps xmm12, [rsp+0xB0]
00007d3d957df586  vmovaps xmm13, [rsp+0xC0]
00007d3d957df58f  vmovaps xmm14, [rsp+0xD0]
00007d3d957df598  vmovaps xmm15, [rsp+0xE0]
00007d3d957df5a1  add rsp, 0xF0
00007d3d957df5a8  pop r11
00007d3d957df5aa  pop r10
00007d3d957df5ac  pop r9
00007d3d957df5ae  pop r8
00007d3d957df5b0  pop rsi
00007d3d957df5b1  pop rdi
00007d3d957df5b2  pop rdx
00007d3d957df5b3  pop rcx
00007d3d957df5b4  pop rax
00007d3d957df5b5  add rsp, 0x08
00007d3d957df5b9  jmp 0x00007D3D957DC3D8
00007d3d957df5be  sub rsp, 0x08
00007d3d957df5c2  push rax
00007d3d957df5c3  push rcx
00007d3d957df5c4  push rdx
00007d3d957df5c5  push rdi
00007d3d957df5c6  push rsi
00007d3d957df5c7  push r8
00007d3d957df5c9  push r9
00007d3d957df5cb  push r10
00007d3d957df5cd  push r11
00007d3d957df5cf  sub rsp, 0xF0
00007d3d957df5d6  vmovaps [rsp], xmm0
00007d3d957df5db  vmovaps [rsp+0x10], xmm1
00007d3d957df5e1  vmovaps [rsp+0x20], xmm2
00007d3d957df5e7  vmovaps [rsp+0x30], xmm3
00007d3d957df5ed  vmovaps [rsp+0x40], xmm4
00007d3d957df5f3  vmovaps [rsp+0x50], xmm5
00007d3d957df5f9  vmovaps [rsp+0x60], xmm6
00007d3d957df5ff  vmovaps [rsp+0x70], xmm7
00007d3d957df605  vmovaps [rsp+0x80], xmm8
00007d3d957df60e  vmovaps [rsp+0x90], xmm9
00007d3d957df617  vmovaps [rsp+0xA0], xmm11
00007d3d957df620  vmovaps [rsp+0xB0], xmm12
00007d3d957df629  vmovaps [rsp+0xC0], xmm13
00007d3d957df632  vmovaps [rsp+0xD0], xmm14
00007d3d957df63b  vmovaps [rsp+0xE0], xmm15
00007d3d957df644  sub rsp, 0x30
00007d3d957df648  movaps [rsp], xmm10
00007d3d957df64d  movaps [rsp+0x10], xmm8
00007d3d957df653  movaps [rsp+0x20], xmm14
00007d3d957df659  lea rdi, [rsp]
00007d3d957df65d  mov esi, 0x00
00007d3d957df662  mov rax, 0x56C27CB8A530
00007d3d957df66c  call rax
00007d3d957df66e  movaps xmm10, [rsp]
00007d3d957df673  add rsp, 0x30
00007d3d957df677  vmovaps xmm0, [rsp]
00007d3d957df67c  vmovaps xmm1, [rsp+0x10]
00007d3d957df682  vmovaps xmm2, [rsp+0x20]
00007d3d957df688  vmovaps xmm3, [rsp+0x30]
00007d3d957df68e  vmovaps xmm4, [rsp+0x40]
00007d3d957df694  vmovaps xmm5, [rsp+0x50]
00007d3d957df69a  vmovaps xmm6, [rsp+0x60]
00007d3d957df6a0  vmovaps xmm7, [rsp+0x70]
00007d3d957df6a6  vmovaps xmm8, [rsp+0x80]
00007d3d957df6af  vmovaps xmm9, [rsp+0x90]
00007d3d957df6b8  vmovaps xmm11, [rsp+0xA0]
00007d3d957df6c1  vmovaps xmm12, [rsp+0xB0]
00007d3d957df6ca  vmovaps xmm13, [rsp+0xC0]
00007d3d957df6d3  vmovaps xmm14, [rsp+0xD0]
00007d3d957df6dc  vmovaps xmm15, [rsp+0xE0]
00007d3d957df6e5  add rsp, 0xF0
00007d3d957df6ec  pop r11
00007d3d957df6ee  pop r10
00007d3d957df6f0  pop r9
00007d3d957df6f2  pop r8
00007d3d957df6f4  pop rsi
00007d3d957df6f5  pop rdi
00007d3d957df6f6  pop rdx
00007d3d957df6f7  pop rcx
00007d3d957df6f8  pop rax
00007d3d957df6f9  add rsp, 0x08
00007d3d957df6fd  jmp 0x00007D3D957DC3F8
00007d3d957df702  sub rsp, 0x08
00007d3d957df706  push rax
00007d3d957df707  push rcx
00007d3d957df708  push rdx
00007d3d957df709  push rdi
00007d3d957df70a  push rsi
00007d3d957df70b  push r8
00007d3d957df70d  push r9
00007d3d957df70f  push r10
00007d3d957df711  push r11
00007d3d957df713  sub rsp, 0xF0
00007d3d957df71a  vmovaps [rsp], xmm0
00007d3d957df71f  vmovaps [rsp+0x10], xmm1
00007d3d957df725  vmovaps [rsp+0x20], xmm2
00007d3d957df72b  vmovaps [rsp+0x30], xmm3
00007d3d957df731  vmovaps [rsp+0x40], xmm4
00007d3d957df737  vmovaps [rsp+0x50], xmm5
00007d3d957df73d  vmovaps [rsp+0x60], xmm6
00007d3d957df743  vmovaps [rsp+0x70], xmm7
00007d3d957df749  vmovaps [rsp+0x80], xmm8
00007d3d957df752  vmovaps [rsp+0x90], xmm9
00007d3d957df75b  vmovaps [rsp+0xA0], xmm10
00007d3d957df764  vmovaps [rsp+0xB0], xmm11
00007d3d957df76d  vmovaps [rsp+0xC0], xmm12
00007d3d957df776  vmovaps [rsp+0xD0], xmm13
00007d3d957df77f  vmovaps [rsp+0xE0], xmm15
00007d3d957df788  sub rsp, 0x30
00007d3d957df78c  movaps [rsp], xmm14
00007d3d957df791  movaps [rsp+0x10], xmm8
00007d3d957df797  movaps [rsp+0x20], xmm4
00007d3d957df79c  lea rdi, [rsp]
00007d3d957df7a0  mov esi, 0x00
00007d3d957df7a5  mov rax, 0x56C27CB8A530
00007d3d957df7af  call rax
00007d3d957df7b1  movaps xmm14, [rsp]
00007d3d957df7b6  add rsp, 0x30
00007d3d957df7ba  vmovaps xmm0, [rsp]
00007d3d957df7bf  vmovaps xmm1, [rsp+0x10]
00007d3d957df7c5  vmovaps xmm2, [rsp+0x20]
00007d3d957df7cb  vmovaps xmm3, [rsp+0x30]
00007d3d957df7d1  vmovaps xmm4, [rsp+0x40]
00007d3d957df7d7  vmovaps xmm5, [rsp+0x50]
00007d3d957df7dd  vmovaps xmm6, [rsp+0x60]
00007d3d957df7e3  vmovaps xmm7, [rsp+0x70]
00007d3d957df7e9  vmovaps xmm8, [rsp+0x80]
00007d3d957df7f2  vmovaps xmm9, [rsp+0x90]
00007d3d957df7fb  vmovaps xmm10, [rsp+0xA0]
00007d3d957df804  vmovaps xmm11, [rsp+0xB0]
00007d3d957df80d  vmovaps xmm12, [rsp+0xC0]
00007d3d957df816  vmovaps xmm13, [rsp+0xD0]
00007d3d957df81f  vmovaps xmm15, [rsp+0xE0]
00007d3d957df828  add rsp, 0xF0
00007d3d957df82f  pop r11
00007d3d957df831  pop r10
00007d3d957df833  pop r9
00007d3d957df835  pop r8
00007d3d957df837  pop rsi
00007d3d957df838  pop rdi
00007d3d957df839  pop rdx
00007d3d957df83a  pop rcx
00007d3d957df83b  pop rax
00007d3d957df83c  add rsp, 0x08
00007d3d957df840  jmp 0x00007D3D957DC418
00007d3d957df845  sub rsp, 0x08
00007d3d957df849  push rax
00007d3d957df84a  push rcx
00007d3d957df84b  push rdx
00007d3d957df84c  push rdi
00007d3d957df84d  push rsi
00007d3d957df84e  push r8
00007d3d957df850  push r9
00007d3d957df852  push r10
00007d3d957df854  push r11
00007d3d957df856  sub rsp, 0xF0
00007d3d957df85d  vmovaps [rsp], xmm0
00007d3d957df862  vmovaps [rsp+0x10], xmm1
00007d3d957df868  vmovaps [rsp+0x20], xmm2
00007d3d957df86e  vmovaps [rsp+0x30], xmm3
00007d3d957df874  vmovaps [rsp+0x40], xmm5
00007d3d957df87a  vmovaps [rsp+0x50], xmm6
00007d3d957df880  vmovaps [rsp+0x60], xmm7
00007d3d957df886  vmovaps [rsp+0x70], xmm8
00007d3d957df88c  vmovaps [rsp+0x80], xmm9
00007d3d957df895  vmovaps [rsp+0x90], xmm10
00007d3d957df89e  vmovaps [rsp+0xA0], xmm11
00007d3d957df8a7  vmovaps [rsp+0xB0], xmm12
00007d3d957df8b0  vmovaps [rsp+0xC0], xmm13
00007d3d957df8b9  vmovaps [rsp+0xD0], xmm14
00007d3d957df8c2  vmovaps [rsp+0xE0], xmm15
00007d3d957df8cb  sub rsp, 0x30
00007d3d957df8cf  movaps [rsp], xmm4
00007d3d957df8d3  movaps [rsp+0x10], xmm13
00007d3d957df8d9  movaps [rsp+0x20], xmm8
00007d3d957df8df  lea rdi, [rsp]
00007d3d957df8e3  mov esi, 0x00
00007d3d957df8e8  mov rax, 0x56C27CB8A530
00007d3d957df8f2  call rax
00007d3d957df8f4  movaps xmm4, [rsp]
00007d3d957df8f8  add rsp, 0x30
00007d3d957df8fc  vmovaps xmm0, [rsp]
00007d3d957df901  vmovaps xmm1, [rsp+0x10]
00007d3d957df907  vmovaps xmm2, [rsp+0x20]
00007d3d957df90d  vmovaps xmm3, [rsp+0x30]
00007d3d957df913  vmovaps xmm5, [rsp+0x40]
00007d3d957df919  vmovaps xmm6, [rsp+0x50]
00007d3d957df91f  vmovaps xmm7, [rsp+0x60]
00007d3d957df925  vmovaps xmm8, [rsp+0x70]
00007d3d957df92b  vmovaps xmm9, [rsp+0x80]
00007d3d957df934  vmovaps xmm10, [rsp+0x90]
00007d3d957df93d  vmovaps xmm11, [rsp+0xA0]
00007d3d957df946  vmovaps xmm12, [rsp+0xB0]
00007d3d957df94f  vmovaps xmm13, [rsp+0xC0]
00007d3d957df958  vmovaps xmm14, [rsp+0xD0]
00007d3d957df961  vmovaps xmm15, [rsp+0xE0]
00007d3d957df96a  add rsp, 0xF0
00007d3d957df971  pop r11
00007d3d957df973  pop r10
00007d3d957df975  pop r9
00007d3d957df977  pop r8
00007d3d957df979  pop rsi
00007d3d957df97a  pop rdi
00007d3d957df97b  pop rdx
00007d3d957df97c  pop rcx
00007d3d957df97d  pop rax
00007d3d957df97e  add rsp, 0x08
00007d3d957df982  jmp 0x00007D3D957DC43D
00007d3d957df987  sub rsp, 0x08
00007d3d957df98b  push rax
00007d3d957df98c  push rcx
00007d3d957df98d  push rdx
00007d3d957df98e  push rdi
00007d3d957df98f  push rsi
00007d3d957df990  push r8
00007d3d957df992  push r9
00007d3d957df994  push r10
00007d3d957df996  push r11
00007d3d957df998  sub rsp, 0xF0
00007d3d957df99f  vmovaps [rsp], xmm0
00007d3d957df9a4  vmovaps [rsp+0x10], xmm1
00007d3d957df9aa  vmovaps [rsp+0x20], xmm2
00007d3d957df9b0  vmovaps [rsp+0x30], xmm3
00007d3d957df9b6  vmovaps [rsp+0x40], xmm4
00007d3d957df9bc  vmovaps [rsp+0x50], xmm5
00007d3d957df9c2  vmovaps [rsp+0x60], xmm6
00007d3d957df9c8  vmovaps [rsp+0x70], xmm7
00007d3d957df9ce  vmovaps [rsp+0x80], xmm8
00007d3d957df9d7  vmovaps [rsp+0x90], xmm9
00007d3d957df9e0  vmovaps [rsp+0xA0], xmm10
00007d3d957df9e9  vmovaps [rsp+0xB0], xmm11
00007d3d957df9f2  vmovaps [rsp+0xC0], xmm12
00007d3d957df9fb  vmovaps [rsp+0xD0], xmm14
00007d3d957dfa04  vmovaps [rsp+0xE0], xmm15
00007d3d957dfa0d  sub rsp, 0x30
00007d3d957dfa11  movaps [rsp], xmm13
00007d3d957dfa16  movaps [rsp+0x10], xmm15
00007d3d957dfa1c  movaps [rsp+0x20], xmm9
00007d3d957dfa22  lea rdi, [rsp]
00007d3d957dfa26  mov esi, 0x00
00007d3d957dfa2b  mov rax, 0x56C27CB8A530
00007d3d957dfa35  call rax
00007d3d957dfa37  movaps xmm13, [rsp]
00007d3d957dfa3c  add rsp, 0x30
00007d3d957dfa40  vmovaps xmm0, [rsp]
00007d3d957dfa45  vmovaps xmm1, [rsp+0x10]
00007d3d957dfa4b  vmovaps xmm2, [rsp+0x20]
00007d3d957dfa51  vmovaps xmm3, [rsp+0x30]
00007d3d957dfa57  vmovaps xmm4, [rsp+0x40]
00007d3d957dfa5d  vmovaps xmm5, [rsp+0x50]
00007d3d957dfa63  vmovaps xmm6, [rsp+0x60]
00007d3d957dfa69  vmovaps xmm7, [rsp+0x70]
00007d3d957dfa6f  vmovaps xmm8, [rsp+0x80]
00007d3d957dfa78  vmovaps xmm9, [rsp+0x90]
00007d3d957dfa81  vmovaps xmm10, [rsp+0xA0]
00007d3d957dfa8a  vmovaps xmm11, [rsp+0xB0]
00007d3d957dfa93  vmovaps xmm12, [rsp+0xC0]
00007d3d957dfa9c  vmovaps xmm14, [rsp+0xD0]
00007d3d957dfaa5  vmovaps xmm15, [rsp+0xE0]
00007d3d957dfaae  add rsp, 0xF0
00007d3d957dfab5  pop r11
00007d3d957dfab7  pop r10
00007d3d957dfab9  pop r9
00007d3d957dfabb  pop r8
00007d3d957dfabd  pop rsi
00007d3d957dfabe  pop rdi
00007d3d957dfabf  pop rdx
00007d3d957dfac0  pop rcx
00007d3d957dfac1  pop rax
00007d3d957dfac2  add rsp, 0x08
00007d3d957dfac6  jmp 0x00007D3D957DC458
00007d3d957dfacb  sub rsp, 0x08
00007d3d957dfacf  push rax
00007d3d957dfad0  push rcx
00007d3d957dfad1  push rdx
00007d3d957dfad2  push rdi
00007d3d957dfad3  push rsi
00007d3d957dfad4  push r8
00007d3d957dfad6  push r9
00007d3d957dfad8  push r10
00007d3d957dfada  push r11
00007d3d957dfadc  sub rsp, 0xF0
00007d3d957dfae3  vmovaps [rsp], xmm0
00007d3d957dfae8  vmovaps [rsp+0x10], xmm1
00007d3d957dfaee  vmovaps [rsp+0x20], xmm2
00007d3d957dfaf4  vmovaps [rsp+0x30], xmm3
00007d3d957dfafa  vmovaps [rsp+0x40], xmm4
00007d3d957dfb00  vmovaps [rsp+0x50], xmm5
00007d3d957dfb06  vmovaps [rsp+0x60], xmm6
00007d3d957dfb0c  vmovaps [rsp+0x70], xmm7
00007d3d957dfb12  vmovaps [rsp+0x80], xmm8
00007d3d957dfb1b  vmovaps [rsp+0x90], xmm9
00007d3d957dfb24  vmovaps [rsp+0xA0], xmm10
00007d3d957dfb2d  vmovaps [rsp+0xB0], xmm11
00007d3d957dfb36  vmovaps [rsp+0xC0], xmm12
00007d3d957dfb3f  vmovaps [rsp+0xD0], xmm13
00007d3d957dfb48  vmovaps [rsp+0xE0], xmm14
00007d3d957dfb51  sub rsp, 0x30
00007d3d957dfb55  movaps [rsp], xmm15
00007d3d957dfb5a  movaps [rsp+0x10], xmm1
00007d3d957dfb5f  movaps [rsp+0x20], xmm5
00007d3d957dfb64  lea rdi, [rsp]
00007d3d957dfb68  mov esi, 0x00
00007d3d957dfb6d  mov rax, 0x56C27CB8A530
00007d3d957dfb77  call rax
00007d3d957dfb79  movaps xmm15, [rsp]
00007d3d957dfb7e  add rsp, 0x30
00007d3d957dfb82  vmovaps xmm0, [rsp]
00007d3d957dfb87  vmovaps xmm1, [rsp+0x10]
00007d3d957dfb8d  vmovaps xmm2, [rsp+0x20]
00007d3d957dfb93  vmovaps xmm3, [rsp+0x30]
00007d3d957dfb99  vmovaps xmm4, [rsp+0x40]
00007d3d957dfb9f  vmovaps xmm5, [rsp+0x50]
00007d3d957dfba5  vmovaps xmm6, [rsp+0x60]
00007d3d957dfbab  vmovaps xmm7, [rsp+0x70]
00007d3d957dfbb1  vmovaps xmm8, [rsp+0x80]
00007d3d957dfbba  vmovaps xmm9, [rsp+0x90]
00007d3d957dfbc3  vmovaps xmm10, [rsp+0xA0]
00007d3d957dfbcc  vmovaps xmm11, [rsp+0xB0]
00007d3d957dfbd5  vmovaps xmm12, [rsp+0xC0]
00007d3d957dfbde  vmovaps xmm13, [rsp+0xD0]
00007d3d957dfbe7  vmovaps xmm14, [rsp+0xE0]
00007d3d957dfbf0  add rsp, 0xF0
00007d3d957dfbf7  pop r11
00007d3d957dfbf9  pop r10
00007d3d957dfbfb  pop r9
00007d3d957dfbfd  pop r8
00007d3d957dfbff  pop rsi
00007d3d957dfc00  pop rdi
00007d3d957dfc01  pop rdx
00007d3d957dfc02  pop rcx
00007d3d957dfc03  pop rax
00007d3d957dfc04  add rsp, 0x08
00007d3d957dfc08  jmp 0x00007D3D957DC473
00007d3d957dfc0d  call 0x00007D3D956B52F0
00007d3d957dfc12  jmp 0x00007D3D957DC4CE
00007d3d957dfc17  sub rsp, 0x08
00007d3d957dfc1b  push rax
00007d3d957dfc1c  push rcx
00007d3d957dfc1d  push rdx
00007d3d957dfc1e  push rdi
00007d3d957dfc1f  push rsi
00007d3d957dfc20  push r8
00007d3d957dfc22  push r9
00007d3d957dfc24  push r10
00007d3d957dfc26  push r11
00007d3d957dfc28  sub rsp, 0xF0
00007d3d957dfc2f  vmovaps [rsp], xmm0
00007d3d957dfc34  vmovaps [rsp+0x10], xmm1
00007d3d957dfc3a  vmovaps [rsp+0x20], xmm2
00007d3d957dfc40  vmovaps [rsp+0x30], xmm3
00007d3d957dfc46  vmovaps [rsp+0x40], xmm4
00007d3d957dfc4c  vmovaps [rsp+0x50], xmm5
00007d3d957dfc52  vmovaps [rsp+0x60], xmm6
00007d3d957dfc58  vmovaps [rsp+0x70], xmm7
00007d3d957dfc5e  vmovaps [rsp+0x80], xmm8
00007d3d957dfc67  vmovaps [rsp+0x90], xmm10
00007d3d957dfc70  vmovaps [rsp+0xA0], xmm11
00007d3d957dfc79  vmovaps [rsp+0xB0], xmm12
00007d3d957dfc82  vmovaps [rsp+0xC0], xmm13
00007d3d957dfc8b  vmovaps [rsp+0xD0], xmm14
00007d3d957dfc94  vmovaps [rsp+0xE0], xmm15
00007d3d957dfc9d  sub rsp, 0x30
00007d3d957dfca1  movaps [rsp], xmm9
00007d3d957dfca6  movaps [rsp+0x10], xmm8
00007d3d957dfcac  movaps [rsp+0x20], xmm11
00007d3d957dfcb2  lea rdi, [rsp]
00007d3d957dfcb6  mov esi, 0x00
00007d3d957dfcbb  mov rax, 0x56C27CB8A530
00007d3d957dfcc5  call rax
00007d3d957dfcc7  movaps xmm9, [rsp]
00007d3d957dfccc  add rsp, 0x30
00007d3d957dfcd0  vmovaps xmm0, [rsp]
00007d3d957dfcd5  vmovaps xmm1, [rsp+0x10]
00007d3d957dfcdb  vmovaps xmm2, [rsp+0x20]
00007d3d957dfce1  vmovaps xmm3, [rsp+0x30]
00007d3d957dfce7  vmovaps xmm4, [rsp+0x40]
00007d3d957dfced  vmovaps xmm5, [rsp+0x50]
00007d3d957dfcf3  vmovaps xmm6, [rsp+0x60]
00007d3d957dfcf9  vmovaps xmm7, [rsp+0x70]
00007d3d957dfcff  vmovaps xmm8, [rsp+0x80]
00007d3d957dfd08  vmovaps xmm10, [rsp+0x90]
00007d3d957dfd11  vmovaps xmm11, [rsp+0xA0]
00007d3d957dfd1a  vmovaps xmm12, [rsp+0xB0]
00007d3d957dfd23  vmovaps xmm13, [rsp+0xC0]
00007d3d957dfd2c  vmovaps xmm14, [rsp+0xD0]
00007d3d957dfd35  vmovaps xmm15, [rsp+0xE0]
00007d3d957dfd3e  add rsp, 0xF0
00007d3d957dfd45  pop r11
00007d3d957dfd47  pop r10
00007d3d957dfd49  pop r9
00007d3d957dfd4b  pop r8
00007d3d957dfd4d  pop rsi
00007d3d957dfd4e  pop rdi
00007d3d957dfd4f  pop rdx
00007d3d957dfd50  pop rcx
00007d3d957dfd51  pop rax
00007d3d957dfd52  add rsp, 0x08
00007d3d957dfd56  jmp 0x00007D3D957DC505
00007d3d957dfd5b  sub rsp, 0x08
00007d3d957dfd5f  push rax
00007d3d957dfd60  push rcx
00007d3d957dfd61  push rdx
00007d3d957dfd62  push rdi
00007d3d957dfd63  push rsi
00007d3d957dfd64  push r8
00007d3d957dfd66  push r9
00007d3d957dfd68  push r10
00007d3d957dfd6a  push r11
00007d3d957dfd6c  sub rsp, 0xF0
00007d3d957dfd73  vmovaps [rsp], xmm0
00007d3d957dfd78  vmovaps [rsp+0x10], xmm1
00007d3d957dfd7e  vmovaps [rsp+0x20], xmm2
00007d3d957dfd84  vmovaps [rsp+0x30], xmm3
00007d3d957dfd8a  vmovaps [rsp+0x40], xmm4
00007d3d957dfd90  vmovaps [rsp+0x50], xmm5
00007d3d957dfd96  vmovaps [rsp+0x60], xmm6
00007d3d957dfd9c  vmovaps [rsp+0x70], xmm7
00007d3d957dfda2  vmovaps [rsp+0x80], xmm8
00007d3d957dfdab  vmovaps [rsp+0x90], xmm9
00007d3d957dfdb4  vmovaps [rsp+0xA0], xmm10
00007d3d957dfdbd  vmovaps [rsp+0xB0], xmm12
00007d3d957dfdc6  vmovaps [rsp+0xC0], xmm13
00007d3d957dfdcf  vmovaps [rsp+0xD0], xmm14
00007d3d957dfdd8  vmovaps [rsp+0xE0], xmm15
00007d3d957dfde1  sub rsp, 0x30
00007d3d957dfde5  movaps [rsp], xmm11
00007d3d957dfdea  movaps [rsp+0x10], xmm10
00007d3d957dfdf0  movaps [rsp+0x20], xmm6
00007d3d957dfdf5  lea rdi, [rsp]
00007d3d957dfdf9  mov esi, 0x00
00007d3d957dfdfe  mov rax, 0x56C27CB8A530
00007d3d957dfe08  call rax
00007d3d957dfe0a  movaps xmm11, [rsp]
00007d3d957dfe0f  add rsp, 0x30
00007d3d957dfe13  vmovaps xmm0, [rsp]
00007d3d957dfe18  vmovaps xmm1, [rsp+0x10]
00007d3d957dfe1e  vmovaps xmm2, [rsp+0x20]
00007d3d957dfe24  vmovaps xmm3, [rsp+0x30]
00007d3d957dfe2a  vmovaps xmm4, [rsp+0x40]
00007d3d957dfe30  vmovaps xmm5, [rsp+0x50]
00007d3d957dfe36  vmovaps xmm6, [rsp+0x60]
00007d3d957dfe3c  vmovaps xmm7, [rsp+0x70]
00007d3d957dfe42  vmovaps xmm8, [rsp+0x80]
00007d3d957dfe4b  vmovaps xmm9, [rsp+0x90]
00007d3d957dfe54  vmovaps xmm10, [rsp+0xA0]
00007d3d957dfe5d  vmovaps xmm12, [rsp+0xB0]
00007d3d957dfe66  vmovaps xmm13, [rsp+0xC0]
00007d3d957dfe6f  vmovaps xmm14, [rsp+0xD0]
00007d3d957dfe78  vmovaps xmm15, [rsp+0xE0]
00007d3d957dfe81  add rsp, 0xF0
00007d3d957dfe88  pop r11
00007d3d957dfe8a  pop r10
00007d3d957dfe8c  pop r9
00007d3d957dfe8e  pop r8
00007d3d957dfe90  pop rsi
00007d3d957dfe91  pop rdi
00007d3d957dfe92  pop rdx
00007d3d957dfe93  pop rcx
00007d3d957dfe94  pop rax
00007d3d957dfe95  add rsp, 0x08
00007d3d957dfe99  jmp 0x00007D3D957DC520
00007d3d957dfe9e  sub rsp, 0x08
00007d3d957dfea2  push rax
00007d3d957dfea3  push rcx
00007d3d957dfea4  push rdx
00007d3d957dfea5  push rdi
00007d3d957dfea6  push rsi
00007d3d957dfea7  push r8
00007d3d957dfea9  push r9
00007d3d957dfeab  push r10
00007d3d957dfead  push r11
00007d3d957dfeaf  sub rsp, 0xF0
00007d3d957dfeb6  vmovaps [rsp], xmm0
00007d3d957dfebb  vmovaps [rsp+0x10], xmm1
00007d3d957dfec1  vmovaps [rsp+0x20], xmm2
00007d3d957dfec7  vmovaps [rsp+0x30], xmm3
00007d3d957dfecd  vmovaps [rsp+0x40], xmm4
00007d3d957dfed3  vmovaps [rsp+0x50], xmm5
00007d3d957dfed9  vmovaps [rsp+0x60], xmm6
00007d3d957dfedf  vmovaps [rsp+0x70], xmm7
00007d3d957dfee5  vmovaps [rsp+0x80], xmm8
00007d3d957dfeee  vmovaps [rsp+0x90], xmm9
00007d3d957dfef7  vmovaps [rsp+0xA0], xmm11
00007d3d957dff00  vmovaps [rsp+0xB0], xmm12
00007d3d957dff09  vmovaps [rsp+0xC0], xmm13
00007d3d957dff12  vmovaps [rsp+0xD0], xmm14
00007d3d957dff1b  vmovaps [rsp+0xE0], xmm15
00007d3d957dff24  sub rsp, 0x30
00007d3d957dff28  movaps [rsp], xmm10
00007d3d957dff2d  movaps [rsp+0x10], xmm14
00007d3d957dff33  movaps [rsp+0x20], xmm4
00007d3d957dff38  lea rdi, [rsp]
00007d3d957dff3c  mov esi, 0x00
00007d3d957dff41  mov rax, 0x56C27CB8A530
00007d3d957dff4b  call rax
00007d3d957dff4d  movaps xmm10, [rsp]
00007d3d957dff52  add rsp, 0x30
00007d3d957dff56  vmovaps xmm0, [rsp]
00007d3d957dff5b  vmovaps xmm1, [rsp+0x10]
00007d3d957dff61  vmovaps xmm2, [rsp+0x20]
00007d3d957dff67  vmovaps xmm3, [rsp+0x30]
00007d3d957dff6d  vmovaps xmm4, [rsp+0x40]
00007d3d957dff73  vmovaps xmm5, [rsp+0x50]
00007d3d957dff79  vmovaps xmm6, [rsp+0x60]
00007d3d957dff7f  vmovaps xmm7, [rsp+0x70]
00007d3d957dff85  vmovaps xmm8, [rsp+0x80]
00007d3d957dff8e  vmovaps xmm9, [rsp+0x90]
00007d3d957dff97  vmovaps xmm11, [rsp+0xA0]
00007d3d957dffa0  vmovaps xmm12, [rsp+0xB0]
00007d3d957dffa9  vmovaps xmm13, [rsp+0xC0]
00007d3d957dffb2  vmovaps xmm14, [rsp+0xD0]
00007d3d957dffbb  vmovaps xmm15, [rsp+0xE0]
00007d3d957dffc4  add rsp, 0xF0
00007d3d957dffcb  pop r11
00007d3d957dffcd  pop r10
00007d3d957dffcf  pop r9
00007d3d957dffd1  pop r8
00007d3d957dffd3  pop rsi
00007d3d957dffd4  pop rdi
00007d3d957dffd5  pop rdx
00007d3d957dffd6  pop rcx
00007d3d957dffd7  pop rax
00007d3d957dffd8  add rsp, 0x08
00007d3d957dffdc  jmp 0x00007D3D957DC53B
00007d3d957dffe1  sub rsp, 0x08
00007d3d957dffe5  push rax
00007d3d957dffe6  push rcx
00007d3d957dffe7  push rdx
00007d3d957dffe8  push rdi
00007d3d957dffe9  push rsi
00007d3d957dffea  push r8
00007d3d957dffec  push r9
00007d3d957dffee  push r10
00007d3d957dfff0  push r11
00007d3d957dfff2  sub rsp, 0xF0
00007d3d957dfff9  vmovaps [rsp], xmm0
00007d3d957dfffe  vmovaps [rsp+0x10], xmm1
00007d3d957e0004  vmovaps [rsp+0x20], xmm2
00007d3d957e000a  vmovaps [rsp+0x30], xmm3
00007d3d957e0010  vmovaps [rsp+0x40], xmm4
00007d3d957e0016  vmovaps [rsp+0x50], xmm5
00007d3d957e001c  vmovaps [rsp+0x60], xmm6
00007d3d957e0022  vmovaps [rsp+0x70], xmm7
00007d3d957e0028  vmovaps [rsp+0x80], xmm9
00007d3d957e0031  vmovaps [rsp+0x90], xmm10
00007d3d957e003a  vmovaps [rsp+0xA0], xmm11
00007d3d957e0043  vmovaps [rsp+0xB0], xmm12
00007d3d957e004c  vmovaps [rsp+0xC0], xmm13
00007d3d957e0055  vmovaps [rsp+0xD0], xmm14
00007d3d957e005e  vmovaps [rsp+0xE0], xmm15
00007d3d957e0067  sub rsp, 0x30
00007d3d957e006b  movaps [rsp], xmm8
00007d3d957e0070  movaps [rsp+0x10], xmm1
00007d3d957e0075  movaps [rsp+0x20], xmm14
00007d3d957e007b  lea rdi, [rsp]
00007d3d957e007f  mov esi, 0x00
00007d3d957e0084  mov rax, 0x56C27CB8A530
00007d3d957e008e  call rax
00007d3d957e0090  movaps xmm8, [rsp]
00007d3d957e0095  add rsp, 0x30
00007d3d957e0099  vmovaps xmm0, [rsp]
00007d3d957e009e  vmovaps xmm1, [rsp+0x10]
00007d3d957e00a4  vmovaps xmm2, [rsp+0x20]
00007d3d957e00aa  vmovaps xmm3, [rsp+0x30]
00007d3d957e00b0  vmovaps xmm4, [rsp+0x40]
00007d3d957e00b6  vmovaps xmm5, [rsp+0x50]
00007d3d957e00bc  vmovaps xmm6, [rsp+0x60]
00007d3d957e00c2  vmovaps xmm7, [rsp+0x70]
00007d3d957e00c8  vmovaps xmm9, [rsp+0x80]
00007d3d957e00d1  vmovaps xmm10, [rsp+0x90]
00007d3d957e00da  vmovaps xmm11, [rsp+0xA0]
00007d3d957e00e3  vmovaps xmm12, [rsp+0xB0]
00007d3d957e00ec  vmovaps xmm13, [rsp+0xC0]
00007d3d957e00f5  vmovaps xmm14, [rsp+0xD0]
00007d3d957e00fe  vmovaps xmm15, [rsp+0xE0]
00007d3d957e0107  add rsp, 0xF0
00007d3d957e010e  pop r11
00007d3d957e0110  pop r10
00007d3d957e0112  pop r9
00007d3d957e0114  pop r8
00007d3d957e0116  pop rsi
00007d3d957e0117  pop rdi
00007d3d957e0118  pop rdx
00007d3d957e0119  pop rcx
00007d3d957e011a  pop rax
00007d3d957e011b  add rsp, 0x08
00007d3d957e011f  jmp 0x00007D3D957DC561
00007d3d957e0124  sub rsp, 0x08
00007d3d957e0128  push rax
00007d3d957e0129  push rcx
00007d3d957e012a  push rdx
00007d3d957e012b  push rdi
00007d3d957e012c  push rsi
00007d3d957e012d  push r8
00007d3d957e012f  push r9
00007d3d957e0131  push r10
00007d3d957e0133  push r11
00007d3d957e0135  sub rsp, 0xF0
00007d3d957e013c  vmovaps [rsp], xmm0
00007d3d957e0141  vmovaps [rsp+0x10], xmm1
00007d3d957e0147  vmovaps [rsp+0x20], xmm2
00007d3d957e014d  vmovaps [rsp+0x30], xmm3
00007d3d957e0153  vmovaps [rsp+0x40], xmm4
00007d3d957e0159  vmovaps [rsp+0x50], xmm5
00007d3d957e015f  vmovaps [rsp+0x60], xmm7
00007d3d957e0165  vmovaps [rsp+0x70], xmm8
00007d3d957e016b  vmovaps [rsp+0x80], xmm9
00007d3d957e0174  vmovaps [rsp+0x90], xmm10
00007d3d957e017d  vmovaps [rsp+0xA0], xmm11
00007d3d957e0186  vmovaps [rsp+0xB0], xmm12
00007d3d957e018f  vmovaps [rsp+0xC0], xmm13
00007d3d957e0198  vmovaps [rsp+0xD0], xmm14
00007d3d957e01a1  vmovaps [rsp+0xE0], xmm15
00007d3d957e01aa  sub rsp, 0x30
00007d3d957e01ae  movaps [rsp], xmm6
00007d3d957e01b2  movaps [rsp+0x10], xmm1
00007d3d957e01b7  movaps [rsp+0x20], xmm14
00007d3d957e01bd  lea rdi, [rsp]
00007d3d957e01c1  mov esi, 0x00
00007d3d957e01c6  mov rax, 0x56C27CB8A530
00007d3d957e01d0  call rax
00007d3d957e01d2  movaps xmm6, [rsp]
00007d3d957e01d6  add rsp, 0x30
00007d3d957e01da  vmovaps xmm0, [rsp]
00007d3d957e01df  vmovaps xmm1, [rsp+0x10]
00007d3d957e01e5  vmovaps xmm2, [rsp+0x20]
00007d3d957e01eb  vmovaps xmm3, [rsp+0x30]
00007d3d957e01f1  vmovaps xmm4, [rsp+0x40]
00007d3d957e01f7  vmovaps xmm5, [rsp+0x50]
00007d3d957e01fd  vmovaps xmm7, [rsp+0x60]
00007d3d957e0203  vmovaps xmm8, [rsp+0x70]
00007d3d957e0209  vmovaps xmm9, [rsp+0x80]
00007d3d957e0212  vmovaps xmm10, [rsp+0x90]
00007d3d957e021b  vmovaps xmm11, [rsp+0xA0]
00007d3d957e0224  vmovaps xmm12, [rsp+0xB0]
00007d3d957e022d  vmovaps xmm13, [rsp+0xC0]
00007d3d957e0236  vmovaps xmm14, [rsp+0xD0]
00007d3d957e023f  vmovaps xmm15, [rsp+0xE0]
00007d3d957e0248  add rsp, 0xF0
00007d3d957e024f  pop r11
00007d3d957e0251  pop r10
00007d3d957e0253  pop r9
00007d3d957e0255  pop r8
00007d3d957e0257  pop rsi
00007d3d957e0258  pop rdi
00007d3d957e0259  pop rdx
00007d3d957e025a  pop rcx
00007d3d957e025b  pop rax
00007d3d957e025c  add rsp, 0x08
00007d3d957e0260  jmp 0x00007D3D957DC58D
00007d3d957e0265  sub rsp, 0x08
00007d3d957e0269  push rax
00007d3d957e026a  push rcx
00007d3d957e026b  push rdx
00007d3d957e026c  push rdi
00007d3d957e026d  push rsi
00007d3d957e026e  push r8
00007d3d957e0270  push r9
00007d3d957e0272  push r10
00007d3d957e0274  push r11
00007d3d957e0276  sub rsp, 0xF0
00007d3d957e027d  vmovaps [rsp], xmm0
00007d3d957e0282  vmovaps [rsp+0x10], xmm1
00007d3d957e0288  vmovaps [rsp+0x20], xmm2
00007d3d957e028e  vmovaps [rsp+0x30], xmm3
00007d3d957e0294  vmovaps [rsp+0x40], xmm4
00007d3d957e029a  vmovaps [rsp+0x50], xmm5
00007d3d957e02a0  vmovaps [rsp+0x60], xmm6
00007d3d957e02a6  vmovaps [rsp+0x70], xmm7
00007d3d957e02ac  vmovaps [rsp+0x80], xmm8
00007d3d957e02b5  vmovaps [rsp+0x90], xmm9
00007d3d957e02be  vmovaps [rsp+0xA0], xmm10
00007d3d957e02c7  vmovaps [rsp+0xB0], xmm11
00007d3d957e02d0  vmovaps [rsp+0xC0], xmm12
00007d3d957e02d9  vmovaps [rsp+0xD0], xmm13
00007d3d957e02e2  vmovaps [rsp+0xE0], xmm15
00007d3d957e02eb  sub rsp, 0x30
00007d3d957e02ef  movaps [rsp], xmm14
00007d3d957e02f4  movaps [rsp+0x10], xmm12
00007d3d957e02fa  movaps [rsp+0x20], xmm1
00007d3d957e02ff  lea rdi, [rsp]
00007d3d957e0303  mov esi, 0x00
00007d3d957e0308  mov rax, 0x56C27CB8A530
00007d3d957e0312  call rax
00007d3d957e0314  movaps xmm14, [rsp]
00007d3d957e0319  add rsp, 0x30
00007d3d957e031d  vmovaps xmm0, [rsp]
00007d3d957e0322  vmovaps xmm1, [rsp+0x10]
00007d3d957e0328  vmovaps xmm2, [rsp+0x20]
00007d3d957e032e  vmovaps xmm3, [rsp+0x30]
00007d3d957e0334  vmovaps xmm4, [rsp+0x40]
00007d3d957e033a  vmovaps xmm5, [rsp+0x50]
00007d3d957e0340  vmovaps xmm6, [rsp+0x60]
00007d3d957e0346  vmovaps xmm7, [rsp+0x70]
00007d3d957e034c  vmovaps xmm8, [rsp+0x80]
00007d3d957e0355  vmovaps xmm9, [rsp+0x90]
00007d3d957e035e  vmovaps xmm10, [rsp+0xA0]
00007d3d957e0367  vmovaps xmm11, [rsp+0xB0]
00007d3d957e0370  vmovaps xmm12, [rsp+0xC0]
00007d3d957e0379  vmovaps xmm13, [rsp+0xD0]
00007d3d957e0382  vmovaps xmm15, [rsp+0xE0]
00007d3d957e038b  add rsp, 0xF0
00007d3d957e0392  pop r11
00007d3d957e0394  pop r10
00007d3d957e0396  pop r9
00007d3d957e0398  pop r8
00007d3d957e039a  pop rsi
00007d3d957e039b  pop rdi
00007d3d957e039c  pop rdx
00007d3d957e039d  pop rcx
00007d3d957e039e  pop rax
00007d3d957e039f  add rsp, 0x08
00007d3d957e03a3  jmp 0x00007D3D957DC5B3
00007d3d957e03a8  sub rsp, 0x08
00007d3d957e03ac  push rax
00007d3d957e03ad  push rcx
00007d3d957e03ae  push rdx
00007d3d957e03af  push rdi
00007d3d957e03b0  push rsi
00007d3d957e03b1  push r8
00007d3d957e03b3  push r9
00007d3d957e03b5  push r10
00007d3d957e03b7  push r11
00007d3d957e03b9  sub rsp, 0xF0
00007d3d957e03c0  vmovaps [rsp], xmm0
00007d3d957e03c5  vmovaps [rsp+0x10], xmm2
00007d3d957e03cb  vmovaps [rsp+0x20], xmm3
00007d3d957e03d1  vmovaps [rsp+0x30], xmm4
00007d3d957e03d7  vmovaps [rsp+0x40], xmm5
00007d3d957e03dd  vmovaps [rsp+0x50], xmm6
00007d3d957e03e3  vmovaps [rsp+0x60], xmm7
00007d3d957e03e9  vmovaps [rsp+0x70], xmm8
00007d3d957e03ef  vmovaps [rsp+0x80], xmm9
00007d3d957e03f8  vmovaps [rsp+0x90], xmm10
00007d3d957e0401  vmovaps [rsp+0xA0], xmm11
00007d3d957e040a  vmovaps [rsp+0xB0], xmm12
00007d3d957e0413  vmovaps [rsp+0xC0], xmm13
00007d3d957e041c  vmovaps [rsp+0xD0], xmm14
00007d3d957e0425  vmovaps [rsp+0xE0], xmm15
00007d3d957e042e  sub rsp, 0x30
00007d3d957e0432  movaps [rsp], xmm1
00007d3d957e0436  movaps [rsp+0x10], xmm13
00007d3d957e043c  movaps [rsp+0x20], xmm9
00007d3d957e0442  lea rdi, [rsp]
00007d3d957e0446  mov esi, 0x00
00007d3d957e044b  mov rax, 0x56C27CB8A530
00007d3d957e0455  call rax
00007d3d957e0457  movaps xmm1, [rsp]
00007d3d957e045b  add rsp, 0x30
00007d3d957e045f  vmovaps xmm0, [rsp]
00007d3d957e0464  vmovaps xmm2, [rsp+0x10]
00007d3d957e046a  vmovaps xmm3, [rsp+0x20]
00007d3d957e0470  vmovaps xmm4, [rsp+0x30]
00007d3d957e0476  vmovaps xmm5, [rsp+0x40]
00007d3d957e047c  vmovaps xmm6, [rsp+0x50]
00007d3d957e0482  vmovaps xmm7, [rsp+0x60]
00007d3d957e0488  vmovaps xmm8, [rsp+0x70]
00007d3d957e048e  vmovaps xmm9, [rsp+0x80]
00007d3d957e0497  vmovaps xmm10, [rsp+0x90]
00007d3d957e04a0  vmovaps xmm11, [rsp+0xA0]
00007d3d957e04a9  vmovaps xmm12, [rsp+0xB0]
00007d3d957e04b2  vmovaps xmm13, [rsp+0xC0]
00007d3d957e04bb  vmovaps xmm14, [rsp+0xD0]
00007d3d957e04c4  vmovaps xmm15, [rsp+0xE0]
00007d3d957e04cd  add rsp, 0xF0
00007d3d957e04d4  pop r11
00007d3d957e04d6  pop r10
00007d3d957e04d8  pop r9
00007d3d957e04da  pop r8
00007d3d957e04dc  pop rsi
00007d3d957e04dd  pop rdi
00007d3d957e04de  pop rdx
00007d3d957e04df  pop rcx
00007d3d957e04e0  pop rax
00007d3d957e04e1  add rsp, 0x08
00007d3d957e04e5  jmp 0x00007D3D957DC5CD
00007d3d957e04ea  sub rsp, 0x08
00007d3d957e04ee  push rax
00007d3d957e04ef  push rcx
00007d3d957e04f0  push rdx
00007d3d957e04f1  push rdi
00007d3d957e04f2  push rsi
00007d3d957e04f3  push r8
00007d3d957e04f5  push r9
00007d3d957e04f7  push r10
00007d3d957e04f9  push r11
00007d3d957e04fb  sub rsp, 0xF0
00007d3d957e0502  vmovaps [rsp], xmm0
00007d3d957e0507  vmovaps [rsp+0x10], xmm1
00007d3d957e050d  vmovaps [rsp+0x20], xmm2
00007d3d957e0513  vmovaps [rsp+0x30], xmm3
00007d3d957e0519  vmovaps [rsp+0x40], xmm4
00007d3d957e051f  vmovaps [rsp+0x50], xmm5
00007d3d957e0525  vmovaps [rsp+0x60], xmm6
00007d3d957e052b  vmovaps [rsp+0x70], xmm7
00007d3d957e0531  vmovaps [rsp+0x80], xmm8
00007d3d957e053a  vmovaps [rsp+0x90], xmm9
00007d3d957e0543  vmovaps [rsp+0xA0], xmm10
00007d3d957e054c  vmovaps [rsp+0xB0], xmm11
00007d3d957e0555  vmovaps [rsp+0xC0], xmm13
00007d3d957e055e  vmovaps [rsp+0xD0], xmm14
00007d3d957e0567  vmovaps [rsp+0xE0], xmm15
00007d3d957e0570  sub rsp, 0x30
00007d3d957e0574  movaps [rsp], xmm12
00007d3d957e0579  movaps [rsp+0x10], xmm7
00007d3d957e057e  movaps [rsp+0x20], xmm13
00007d3d957e0584  lea rdi, [rsp]
00007d3d957e0588  mov esi, 0x00
00007d3d957e058d  mov rax, 0x56C27CB8A530
00007d3d957e0597  call rax
00007d3d957e0599  movaps xmm12, [rsp]
00007d3d957e059e  add rsp, 0x30
00007d3d957e05a2  vmovaps xmm0, [rsp]
00007d3d957e05a7  vmovaps xmm1, [rsp+0x10]
00007d3d957e05ad  vmovaps xmm2, [rsp+0x20]
00007d3d957e05b3  vmovaps xmm3, [rsp+0x30]
00007d3d957e05b9  vmovaps xmm4, [rsp+0x40]
00007d3d957e05bf  vmovaps xmm5, [rsp+0x50]
00007d3d957e05c5  vmovaps xmm6, [rsp+0x60]
00007d3d957e05cb  vmovaps xmm7, [rsp+0x70]
00007d3d957e05d1  vmovaps xmm8, [rsp+0x80]
00007d3d957e05da  vmovaps xmm9, [rsp+0x90]
00007d3d957e05e3  vmovaps xmm10, [rsp+0xA0]
00007d3d957e05ec  vmovaps xmm11, [rsp+0xB0]
00007d3d957e05f5  vmovaps xmm13, [rsp+0xC0]
00007d3d957e05fe  vmovaps xmm14, [rsp+0xD0]
00007d3d957e0607  vmovaps xmm15, [rsp+0xE0]
00007d3d957e0610  add rsp, 0xF0
00007d3d957e0617  pop r11
00007d3d957e0619  pop r10
00007d3d957e061b  pop r9
00007d3d957e061d  pop r8
00007d3d957e061f  pop rsi
00007d3d957e0620  pop rdi
00007d3d957e0621  pop rdx
00007d3d957e0622  pop rcx
00007d3d957e0623  pop rax
00007d3d957e0624  add rsp, 0x08
00007d3d957e0628  jmp 0x00007D3D957DC5F4
00007d3d957e062d  sub rsp, 0x08
00007d3d957e0631  push rax
00007d3d957e0632  push rcx
00007d3d957e0633  push rdx
00007d3d957e0634  push rdi
00007d3d957e0635  push rsi
00007d3d957e0636  push r8
00007d3d957e0638  push r9
00007d3d957e063a  push r10
00007d3d957e063c  push r11
00007d3d957e063e  sub rsp, 0xF0
00007d3d957e0645  vmovaps [rsp], xmm0
00007d3d957e064a  vmovaps [rsp+0x10], xmm1
00007d3d957e0650  vmovaps [rsp+0x20], xmm2
00007d3d957e0656  vmovaps [rsp+0x30], xmm3
00007d3d957e065c  vmovaps [rsp+0x40], xmm4
00007d3d957e0662  vmovaps [rsp+0x50], xmm5
00007d3d957e0668  vmovaps [rsp+0x60], xmm6
00007d3d957e066e  vmovaps [rsp+0x70], xmm7
00007d3d957e0674  vmovaps [rsp+0x80], xmm8
00007d3d957e067d  vmovaps [rsp+0x90], xmm9
00007d3d957e0686  vmovaps [rsp+0xA0], xmm10
00007d3d957e068f  vmovaps [rsp+0xB0], xmm11
00007d3d957e0698  vmovaps [rsp+0xC0], xmm12
00007d3d957e06a1  vmovaps [rsp+0xD0], xmm14
00007d3d957e06aa  vmovaps [rsp+0xE0], xmm15
00007d3d957e06b3  sub rsp, 0x30
00007d3d957e06b7  movaps [rsp], xmm13
00007d3d957e06bc  movaps [rsp+0x10], xmm15
00007d3d957e06c2  movaps [rsp+0x20], xmm8
00007d3d957e06c8  lea rdi, [rsp]
00007d3d957e06cc  mov esi, 0x00
00007d3d957e06d1  mov rax, 0x56C27CB8A530
00007d3d957e06db  call rax
00007d3d957e06dd  movaps xmm13, [rsp]
00007d3d957e06e2  add rsp, 0x30
00007d3d957e06e6  vmovaps xmm0, [rsp]
00007d3d957e06eb  vmovaps xmm1, [rsp+0x10]
00007d3d957e06f1  vmovaps xmm2, [rsp+0x20]
00007d3d957e06f7  vmovaps xmm3, [rsp+0x30]
00007d3d957e06fd  vmovaps xmm4, [rsp+0x40]
00007d3d957e0703  vmovaps xmm5, [rsp+0x50]
00007d3d957e0709  vmovaps xmm6, [rsp+0x60]
00007d3d957e070f  vmovaps xmm7, [rsp+0x70]
00007d3d957e0715  vmovaps xmm8, [rsp+0x80]
00007d3d957e071e  vmovaps xmm9, [rsp+0x90]
00007d3d957e0727  vmovaps xmm10, [rsp+0xA0]
00007d3d957e0730  vmovaps xmm11, [rsp+0xB0]
00007d3d957e0739  vmovaps xmm12, [rsp+0xC0]
00007d3d957e0742  vmovaps xmm14, [rsp+0xD0]
00007d3d957e074b  vmovaps xmm15, [rsp+0xE0]
00007d3d957e0754  add rsp, 0xF0
00007d3d957e075b  pop r11
00007d3d957e075d  pop r10
00007d3d957e075f  pop r9
00007d3d957e0761  pop r8
00007d3d957e0763  pop rsi
00007d3d957e0764  pop rdi
00007d3d957e0765  pop rdx
00007d3d957e0766  pop rcx
00007d3d957e0767  pop rax
00007d3d957e0768  add rsp, 0x08
00007d3d957e076c  jmp 0x00007D3D957DC60F
00007d3d957e0771  sub rsp, 0x08
00007d3d957e0775  push rax
00007d3d957e0776  push rcx
00007d3d957e0777  push rdx
00007d3d957e0778  push rdi
00007d3d957e0779  push rsi
00007d3d957e077a  push r8
00007d3d957e077c  push r9
00007d3d957e077e  push r10
00007d3d957e0780  push r11
00007d3d957e0782  sub rsp, 0xF0
00007d3d957e0789  vmovaps [rsp], xmm0
00007d3d957e078e  vmovaps [rsp+0x10], xmm1
00007d3d957e0794  vmovaps [rsp+0x20], xmm2
00007d3d957e079a  vmovaps [rsp+0x30], xmm3
00007d3d957e07a0  vmovaps [rsp+0x40], xmm4
00007d3d957e07a6  vmovaps [rsp+0x50], xmm5
00007d3d957e07ac  vmovaps [rsp+0x60], xmm6
00007d3d957e07b2  vmovaps [rsp+0x70], xmm7
00007d3d957e07b8  vmovaps [rsp+0x80], xmm9
00007d3d957e07c1  vmovaps [rsp+0x90], xmm10
00007d3d957e07ca  vmovaps [rsp+0xA0], xmm11
00007d3d957e07d3  vmovaps [rsp+0xB0], xmm12
00007d3d957e07dc  vmovaps [rsp+0xC0], xmm13
00007d3d957e07e5  vmovaps [rsp+0xD0], xmm14
00007d3d957e07ee  vmovaps [rsp+0xE0], xmm15
00007d3d957e07f7  sub rsp, 0x30
00007d3d957e07fb  movaps [rsp], xmm8
00007d3d957e0800  movaps [rsp+0x10], xmm15
00007d3d957e0806  movaps [rsp+0x20], xmm9
00007d3d957e080c  lea rdi, [rsp]
00007d3d957e0810  mov esi, 0x00
00007d3d957e0815  mov rax, 0x56C27CB8A530
00007d3d957e081f  call rax
00007d3d957e0821  movaps xmm8, [rsp]
00007d3d957e0826  add rsp, 0x30
00007d3d957e082a  vmovaps xmm0, [rsp]
00007d3d957e082f  vmovaps xmm1, [rsp+0x10]
00007d3d957e0835  vmovaps xmm2, [rsp+0x20]
00007d3d957e083b  vmovaps xmm3, [rsp+0x30]
00007d3d957e0841  vmovaps xmm4, [rsp+0x40]
00007d3d957e0847  vmovaps xmm5, [rsp+0x50]
00007d3d957e084d  vmovaps xmm6, [rsp+0x60]
00007d3d957e0853  vmovaps xmm7, [rsp+0x70]
00007d3d957e0859  vmovaps xmm9, [rsp+0x80]
00007d3d957e0862  vmovaps xmm10, [rsp+0x90]
00007d3d957e086b  vmovaps xmm11, [rsp+0xA0]
00007d3d957e0874  vmovaps xmm12, [rsp+0xB0]
00007d3d957e087d  vmovaps xmm13, [rsp+0xC0]
00007d3d957e0886  vmovaps xmm14, [rsp+0xD0]
00007d3d957e088f  vmovaps xmm15, [rsp+0xE0]
00007d3d957e0898  add rsp, 0xF0
00007d3d957e089f  pop r11
00007d3d957e08a1  pop r10
00007d3d957e08a3  pop r9
00007d3d957e08a5  pop r8
00007d3d957e08a7  pop rsi
00007d3d957e08a8  pop rdi
00007d3d957e08a9  pop rdx
00007d3d957e08aa  pop rcx
00007d3d957e08ab  pop rax
00007d3d957e08ac  add rsp, 0x08
00007d3d957e08b0  jmp 0x00007D3D957DC63D
00007d3d957e08b5  sub rsp, 0x08
00007d3d957e08b9  push rax
00007d3d957e08ba  push rcx
00007d3d957e08bb  push rdx
00007d3d957e08bc  push rdi
00007d3d957e08bd  push rsi
00007d3d957e08be  push r8
00007d3d957e08c0  push r9
00007d3d957e08c2  push r10
00007d3d957e08c4  push r11
00007d3d957e08c6  sub rsp, 0xF0
00007d3d957e08cd  vmovaps [rsp], xmm0
00007d3d957e08d2  vmovaps [rsp+0x10], xmm1
00007d3d957e08d8  vmovaps [rsp+0x20], xmm2
00007d3d957e08de  vmovaps [rsp+0x30], xmm3
00007d3d957e08e4  vmovaps [rsp+0x40], xmm4
00007d3d957e08ea  vmovaps [rsp+0x50], xmm5
00007d3d957e08f0  vmovaps [rsp+0x60], xmm6
00007d3d957e08f6  vmovaps [rsp+0x70], xmm7
00007d3d957e08fc  vmovaps [rsp+0x80], xmm8
00007d3d957e0905  vmovaps [rsp+0x90], xmm9
00007d3d957e090e  vmovaps [rsp+0xA0], xmm10
00007d3d957e0917  vmovaps [rsp+0xB0], xmm11
00007d3d957e0920  vmovaps [rsp+0xC0], xmm12
00007d3d957e0929  vmovaps [rsp+0xD0], xmm13
00007d3d957e0932  vmovaps [rsp+0xE0], xmm14
00007d3d957e093b  sub rsp, 0x30
00007d3d957e093f  movaps [rsp], xmm15
00007d3d957e0944  movaps [rsp+0x10], xmm11
00007d3d957e094a  movaps [rsp+0x20], xmm6
00007d3d957e094f  lea rdi, [rsp]
00007d3d957e0953  mov esi, 0x00
00007d3d957e0958  mov rax, 0x56C27CB8A530
00007d3d957e0962  call rax
00007d3d957e0964  movaps xmm15, [rsp]
00007d3d957e0969  add rsp, 0x30
00007d3d957e096d  vmovaps xmm0, [rsp]
00007d3d957e0972  vmovaps xmm1, [rsp+0x10]
00007d3d957e0978  vmovaps xmm2, [rsp+0x20]
00007d3d957e097e  vmovaps xmm3, [rsp+0x30]
00007d3d957e0984  vmovaps xmm4, [rsp+0x40]
00007d3d957e098a  vmovaps xmm5, [rsp+0x50]
00007d3d957e0990  vmovaps xmm6, [rsp+0x60]
00007d3d957e0996  vmovaps xmm7, [rsp+0x70]
00007d3d957e099c  vmovaps xmm8, [rsp+0x80]
00007d3d957e09a5  vmovaps xmm9, [rsp+0x90]
00007d3d957e09ae  vmovaps xmm10, [rsp+0xA0]
00007d3d957e09b7  vmovaps xmm11, [rsp+0xB0]
00007d3d957e09c0  vmovaps xmm12, [rsp+0xC0]
00007d3d957e09c9  vmovaps xmm13, [rsp+0xD0]
00007d3d957e09d2  vmovaps xmm14, [rsp+0xE0]
00007d3d957e09db  add rsp, 0xF0
00007d3d957e09e2  pop r11
00007d3d957e09e4  pop r10
00007d3d957e09e6  pop r9
00007d3d957e09e8  pop r8
00007d3d957e09ea  pop rsi
00007d3d957e09eb  pop rdi
00007d3d957e09ec  pop rdx
00007d3d957e09ed  pop rcx
00007d3d957e09ee  pop rax
00007d3d957e09ef  add rsp, 0x08
00007d3d957e09f3  jmp 0x00007D3D957DC658
00007d3d957e09f8  sub rsp, 0x08
00007d3d957e09fc  push rax
00007d3d957e09fd  push rcx
00007d3d957e09fe  push rdx
00007d3d957e09ff  push rdi
00007d3d957e0a00  push rsi
00007d3d957e0a01  push r8
00007d3d957e0a03  push r9
00007d3d957e0a05  push r10
00007d3d957e0a07  push r11
00007d3d957e0a09  sub rsp, 0xF0
00007d3d957e0a10  vmovaps [rsp], xmm0
00007d3d957e0a15  vmovaps [rsp+0x10], xmm1
00007d3d957e0a1b  vmovaps [rsp+0x20], xmm2
00007d3d957e0a21  vmovaps [rsp+0x30], xmm3
00007d3d957e0a27  vmovaps [rsp+0x40], xmm4
00007d3d957e0a2d  vmovaps [rsp+0x50], xmm5
00007d3d957e0a33  vmovaps [rsp+0x60], xmm6
00007d3d957e0a39  vmovaps [rsp+0x70], xmm8
00007d3d957e0a3f  vmovaps [rsp+0x80], xmm9
00007d3d957e0a48  vmovaps [rsp+0x90], xmm10
00007d3d957e0a51  vmovaps [rsp+0xA0], xmm11
00007d3d957e0a5a  vmovaps [rsp+0xB0], xmm12
00007d3d957e0a63  vmovaps [rsp+0xC0], xmm13
00007d3d957e0a6c  vmovaps [rsp+0xD0], xmm14
00007d3d957e0a75  vmovaps [rsp+0xE0], xmm15
00007d3d957e0a7e  sub rsp, 0x30
00007d3d957e0a82  movaps [rsp], xmm7
00007d3d957e0a86  movaps [rsp+0x10], xmm11
00007d3d957e0a8c  movaps [rsp+0x20], xmm9
00007d3d957e0a92  lea rdi, [rsp]
00007d3d957e0a96  mov esi, 0x00
00007d3d957e0a9b  mov rax, 0x56C27CB8A530
00007d3d957e0aa5  call rax
00007d3d957e0aa7  movaps xmm7, [rsp]
00007d3d957e0aab  add rsp, 0x30
00007d3d957e0aaf  vmovaps xmm0, [rsp]
00007d3d957e0ab4  vmovaps xmm1, [rsp+0x10]
00007d3d957e0aba  vmovaps xmm2, [rsp+0x20]
00007d3d957e0ac0  vmovaps xmm3, [rsp+0x30]
00007d3d957e0ac6  vmovaps xmm4, [rsp+0x40]
00007d3d957e0acc  vmovaps xmm5, [rsp+0x50]
00007d3d957e0ad2  vmovaps xmm6, [rsp+0x60]
00007d3d957e0ad8  vmovaps xmm8, [rsp+0x70]
00007d3d957e0ade  vmovaps xmm9, [rsp+0x80]
00007d3d957e0ae7  vmovaps xmm10, [rsp+0x90]
00007d3d957e0af0  vmovaps xmm11, [rsp+0xA0]
00007d3d957e0af9  vmovaps xmm12, [rsp+0xB0]
00007d3d957e0b02  vmovaps xmm13, [rsp+0xC0]
00007d3d957e0b0b  vmovaps xmm14, [rsp+0xD0]
00007d3d957e0b14  vmovaps xmm15, [rsp+0xE0]
00007d3d957e0b1d  add rsp, 0xF0
00007d3d957e0b24  pop r11
00007d3d957e0b26  pop r10
00007d3d957e0b28  pop r9
00007d3d957e0b2a  pop r8
00007d3d957e0b2c  pop rsi
00007d3d957e0b2d  pop rdi
00007d3d957e0b2e  pop rdx
00007d3d957e0b2f  pop rcx
00007d3d957e0b30  pop rax
00007d3d957e0b31  add rsp, 0x08
00007d3d957e0b35  jmp 0x00007D3D957DC685
00007d3d957e0b3a  sub rsp, 0x08
00007d3d957e0b3e  push rax
00007d3d957e0b3f  push rcx
00007d3d957e0b40  push rdx
00007d3d957e0b41  push rdi
00007d3d957e0b42  push rsi
00007d3d957e0b43  push r8
00007d3d957e0b45  push r9
00007d3d957e0b47  push r10
00007d3d957e0b49  push r11
00007d3d957e0b4b  sub rsp, 0xF0
00007d3d957e0b52  vmovaps [rsp], xmm0
00007d3d957e0b57  vmovaps [rsp+0x10], xmm1
00007d3d957e0b5d  vmovaps [rsp+0x20], xmm2
00007d3d957e0b63  vmovaps [rsp+0x30], xmm3
00007d3d957e0b69  vmovaps [rsp+0x40], xmm4
00007d3d957e0b6f  vmovaps [rsp+0x50], xmm5
00007d3d957e0b75  vmovaps [rsp+0x60], xmm6
00007d3d957e0b7b  vmovaps [rsp+0x70], xmm7
00007d3d957e0b81  vmovaps [rsp+0x80], xmm8
00007d3d957e0b8a  vmovaps [rsp+0x90], xmm9
00007d3d957e0b93  vmovaps [rsp+0xA0], xmm10
00007d3d957e0b9c  vmovaps [rsp+0xB0], xmm12
00007d3d957e0ba5  vmovaps [rsp+0xC0], xmm13
00007d3d957e0bae  vmovaps [rsp+0xD0], xmm14
00007d3d957e0bb7  vmovaps [rsp+0xE0], xmm15
00007d3d957e0bc0  sub rsp, 0x30
00007d3d957e0bc4  movaps [rsp], xmm11
00007d3d957e0bc9  movaps [rsp+0x10], xmm10
00007d3d957e0bcf  movaps [rsp+0x20], xmm14
00007d3d957e0bd5  lea rdi, [rsp]
00007d3d957e0bd9  mov esi, 0x00
00007d3d957e0bde  mov rax, 0x56C27CB8A530
00007d3d957e0be8  call rax
00007d3d957e0bea  movaps xmm11, [rsp]
00007d3d957e0bef  add rsp, 0x30
00007d3d957e0bf3  vmovaps xmm0, [rsp]
00007d3d957e0bf8  vmovaps xmm1, [rsp+0x10]
00007d3d957e0bfe  vmovaps xmm2, [rsp+0x20]
00007d3d957e0c04  vmovaps xmm3, [rsp+0x30]
00007d3d957e0c0a  vmovaps xmm4, [rsp+0x40]
00007d3d957e0c10  vmovaps xmm5, [rsp+0x50]
00007d3d957e0c16  vmovaps xmm6, [rsp+0x60]
00007d3d957e0c1c  vmovaps xmm7, [rsp+0x70]
00007d3d957e0c22  vmovaps xmm8, [rsp+0x80]
00007d3d957e0c2b  vmovaps xmm9, [rsp+0x90]
00007d3d957e0c34  vmovaps xmm10, [rsp+0xA0]
00007d3d957e0c3d  vmovaps xmm12, [rsp+0xB0]
00007d3d957e0c46  vmovaps xmm13, [rsp+0xC0]
00007d3d957e0c4f  vmovaps xmm14, [rsp+0xD0]
00007d3d957e0c58  vmovaps xmm15, [rsp+0xE0]
00007d3d957e0c61  add rsp, 0xF0
00007d3d957e0c68  pop r11
00007d3d957e0c6a  pop r10
00007d3d957e0c6c  pop r9
00007d3d957e0c6e  pop r8
00007d3d957e0c70  pop rsi
00007d3d957e0c71  pop rdi
00007d3d957e0c72  pop rdx
00007d3d957e0c73  pop rcx
00007d3d957e0c74  pop rax
00007d3d957e0c75  add rsp, 0x08
00007d3d957e0c79  jmp 0x00007D3D957DC6A0
00007d3d957e0c7e  call 0x00007D3D956C33A0
00007d3d957e0c83  jmp 0x00007D3D957DC6AA
00007d3d957e0c88  sub rsp, 0x08
00007d3d957e0c8c  push rax
00007d3d957e0c8d  push rcx
00007d3d957e0c8e  push rdx
00007d3d957e0c8f  push rdi
00007d3d957e0c90  push rsi
00007d3d957e0c91  push r8
00007d3d957e0c93  push r9
00007d3d957e0c95  push r10
00007d3d957e0c97  push r11
00007d3d957e0c99  sub rsp, 0xF0
00007d3d957e0ca0  vmovaps [rsp], xmm0
00007d3d957e0ca5  vmovaps [rsp+0x10], xmm1
00007d3d957e0cab  vmovaps [rsp+0x20], xmm2
00007d3d957e0cb1  vmovaps [rsp+0x30], xmm3
00007d3d957e0cb7  vmovaps [rsp+0x40], xmm4
00007d3d957e0cbd  vmovaps [rsp+0x50], xmm5
00007d3d957e0cc3  vmovaps [rsp+0x60], xmm6
00007d3d957e0cc9  vmovaps [rsp+0x70], xmm7
00007d3d957e0ccf  vmovaps [rsp+0x80], xmm8
00007d3d957e0cd8  vmovaps [rsp+0x90], xmm9
00007d3d957e0ce1  vmovaps [rsp+0xA0], xmm11
00007d3d957e0cea  vmovaps [rsp+0xB0], xmm12
00007d3d957e0cf3  vmovaps [rsp+0xC0], xmm13
00007d3d957e0cfc  vmovaps [rsp+0xD0], xmm14
00007d3d957e0d05  vmovaps [rsp+0xE0], xmm15
00007d3d957e0d0e  sub rsp, 0x30
00007d3d957e0d12  movaps [rsp], xmm10
00007d3d957e0d17  movaps [rsp+0x10], xmm1
00007d3d957e0d1c  movaps [rsp+0x20], xmm12
00007d3d957e0d22  lea rdi, [rsp]
00007d3d957e0d26  mov esi, 0x00
00007d3d957e0d2b  mov rax, 0x56C27CB8A530
00007d3d957e0d35  call rax
00007d3d957e0d37  movaps xmm10, [rsp]
00007d3d957e0d3c  add rsp, 0x30
00007d3d957e0d40  vmovaps xmm0, [rsp]
00007d3d957e0d45  vmovaps xmm1, [rsp+0x10]
00007d3d957e0d4b  vmovaps xmm2, [rsp+0x20]
00007d3d957e0d51  vmovaps xmm3, [rsp+0x30]
00007d3d957e0d57  vmovaps xmm4, [rsp+0x40]
00007d3d957e0d5d  vmovaps xmm5, [rsp+0x50]
00007d3d957e0d63  vmovaps xmm6, [rsp+0x60]
00007d3d957e0d69  vmovaps xmm7, [rsp+0x70]
00007d3d957e0d6f  vmovaps xmm8, [rsp+0x80]
00007d3d957e0d78  vmovaps xmm9, [rsp+0x90]
00007d3d957e0d81  vmovaps xmm11, [rsp+0xA0]
00007d3d957e0d8a  vmovaps xmm12, [rsp+0xB0]
00007d3d957e0d93  vmovaps xmm13, [rsp+0xC0]
00007d3d957e0d9c  vmovaps xmm14, [rsp+0xD0]
00007d3d957e0da5  vmovaps xmm15, [rsp+0xE0]
00007d3d957e0dae  add rsp, 0xF0
00007d3d957e0db5  pop r11
00007d3d957e0db7  pop r10
00007d3d957e0db9  pop r9
00007d3d957e0dbb  pop r8
00007d3d957e0dbd  pop rsi
00007d3d957e0dbe  pop rdi
00007d3d957e0dbf  pop rdx
00007d3d957e0dc0  pop rcx
00007d3d957e0dc1  pop rax
00007d3d957e0dc2  add rsp, 0x08
00007d3d957e0dc6  jmp 0x00007D3D957DC6CD
00007d3d957e0dcb  sub rsp, 0x08
00007d3d957e0dcf  push rax
00007d3d957e0dd0  push rcx
00007d3d957e0dd1  push rdx
00007d3d957e0dd2  push rdi
00007d3d957e0dd3  push rsi
00007d3d957e0dd4  push r8
00007d3d957e0dd6  push r9
00007d3d957e0dd8  push r10
00007d3d957e0dda  push r11
00007d3d957e0ddc  sub rsp, 0xF0
00007d3d957e0de3  vmovaps [rsp], xmm0
00007d3d957e0de8  vmovaps [rsp+0x10], xmm1
00007d3d957e0dee  vmovaps [rsp+0x20], xmm2
00007d3d957e0df4  vmovaps [rsp+0x30], xmm3
00007d3d957e0dfa  vmovaps [rsp+0x40], xmm4
00007d3d957e0e00  vmovaps [rsp+0x50], xmm5
00007d3d957e0e06  vmovaps [rsp+0x60], xmm6
00007d3d957e0e0c  vmovaps [rsp+0x70], xmm7
00007d3d957e0e12  vmovaps [rsp+0x80], xmm8
00007d3d957e0e1b  vmovaps [rsp+0x90], xmm9
00007d3d957e0e24  vmovaps [rsp+0xA0], xmm10
00007d3d957e0e2d  vmovaps [rsp+0xB0], xmm11
00007d3d957e0e36  vmovaps [rsp+0xC0], xmm13
00007d3d957e0e3f  vmovaps [rsp+0xD0], xmm14
00007d3d957e0e48  vmovaps [rsp+0xE0], xmm15
00007d3d957e0e51  sub rsp, 0x30
00007d3d957e0e55  movaps [rsp], xmm12
00007d3d957e0e5a  movaps [rsp+0x10], xmm14
00007d3d957e0e60  movaps [rsp+0x20], xmm1
00007d3d957e0e65  lea rdi, [rsp]
00007d3d957e0e69  mov esi, 0x00
00007d3d957e0e6e  mov rax, 0x56C27CB8A530
00007d3d957e0e78  call rax
00007d3d957e0e7a  movaps xmm12, [rsp]
00007d3d957e0e7f  add rsp, 0x30
00007d3d957e0e83  vmovaps xmm0, [rsp]
00007d3d957e0e88  vmovaps xmm1, [rsp+0x10]
00007d3d957e0e8e  vmovaps xmm2, [rsp+0x20]
00007d3d957e0e94  vmovaps xmm3, [rsp+0x30]
00007d3d957e0e9a  vmovaps xmm4, [rsp+0x40]
00007d3d957e0ea0  vmovaps xmm5, [rsp+0x50]
00007d3d957e0ea6  vmovaps xmm6, [rsp+0x60]
00007d3d957e0eac  vmovaps xmm7, [rsp+0x70]
00007d3d957e0eb2  vmovaps xmm8, [rsp+0x80]
00007d3d957e0ebb  vmovaps xmm9, [rsp+0x90]
00007d3d957e0ec4  vmovaps xmm10, [rsp+0xA0]
00007d3d957e0ecd  vmovaps xmm11, [rsp+0xB0]
00007d3d957e0ed6  vmovaps xmm13, [rsp+0xC0]
00007d3d957e0edf  vmovaps xmm14, [rsp+0xD0]
00007d3d957e0ee8  vmovaps xmm15, [rsp+0xE0]
00007d3d957e0ef1  add rsp, 0xF0
00007d3d957e0ef8  pop r11
00007d3d957e0efa  pop r10
00007d3d957e0efc  pop r9
00007d3d957e0efe  pop r8
00007d3d957e0f00  pop rsi
00007d3d957e0f01  pop rdi
00007d3d957e0f02  pop rdx
00007d3d957e0f03  pop rcx
00007d3d957e0f04  pop rax
00007d3d957e0f05  add rsp, 0x08
00007d3d957e0f09  jmp 0x00007D3D957DC6FC
00007d3d957e0f0e  sub rsp, 0x08
00007d3d957e0f12  push rax
00007d3d957e0f13  push rcx
00007d3d957e0f14  push rdx
00007d3d957e0f15  push rdi
00007d3d957e0f16  push rsi
00007d3d957e0f17  push r8
00007d3d957e0f19  push r9
00007d3d957e0f1b  push r10
00007d3d957e0f1d  push r11
00007d3d957e0f1f  sub rsp, 0xF0
00007d3d957e0f26  vmovaps [rsp], xmm0
00007d3d957e0f2b  vmovaps [rsp+0x10], xmm1
00007d3d957e0f31  vmovaps [rsp+0x20], xmm2
00007d3d957e0f37  vmovaps [rsp+0x30], xmm3
00007d3d957e0f3d  vmovaps [rsp+0x40], xmm4
00007d3d957e0f43  vmovaps [rsp+0x50], xmm5
00007d3d957e0f49  vmovaps [rsp+0x60], xmm6
00007d3d957e0f4f  vmovaps [rsp+0x70], xmm7
00007d3d957e0f55  vmovaps [rsp+0x80], xmm8
00007d3d957e0f5e  vmovaps [rsp+0x90], xmm9
00007d3d957e0f67  vmovaps [rsp+0xA0], xmm10
00007d3d957e0f70  vmovaps [rsp+0xB0], xmm11
00007d3d957e0f79  vmovaps [rsp+0xC0], xmm12
00007d3d957e0f82  vmovaps [rsp+0xD0], xmm13
00007d3d957e0f8b  vmovaps [rsp+0xE0], xmm15
00007d3d957e0f94  sub rsp, 0x30
00007d3d957e0f98  movaps [rsp], xmm14
00007d3d957e0f9d  movaps [rsp+0x10], xmm9
00007d3d957e0fa3  movaps [rsp+0x20], xmm1
00007d3d957e0fa8  lea rdi, [rsp]
00007d3d957e0fac  mov esi, 0x00
00007d3d957e0fb1  mov rax, 0x56C27CB8A530
00007d3d957e0fbb  call rax
00007d3d957e0fbd  movaps xmm14, [rsp]
00007d3d957e0fc2  add rsp, 0x30
00007d3d957e0fc6  vmovaps xmm0, [rsp]
00007d3d957e0fcb  vmovaps xmm1, [rsp+0x10]
00007d3d957e0fd1  vmovaps xmm2, [rsp+0x20]
00007d3d957e0fd7  vmovaps xmm3, [rsp+0x30]
00007d3d957e0fdd  vmovaps xmm4, [rsp+0x40]
00007d3d957e0fe3  vmovaps xmm5, [rsp+0x50]
00007d3d957e0fe9  vmovaps xmm6, [rsp+0x60]
00007d3d957e0fef  vmovaps xmm7, [rsp+0x70]
00007d3d957e0ff5  vmovaps xmm8, [rsp+0x80]
00007d3d957e0ffe  vmovaps xmm9, [rsp+0x90]
00007d3d957e1007  vmovaps xmm10, [rsp+0xA0]
00007d3d957e1010  vmovaps xmm11, [rsp+0xB0]
00007d3d957e1019  vmovaps xmm12, [rsp+0xC0]
00007d3d957e1022  vmovaps xmm13, [rsp+0xD0]
00007d3d957e102b  vmovaps xmm15, [rsp+0xE0]
00007d3d957e1034  add rsp, 0xF0
00007d3d957e103b  pop r11
00007d3d957e103d  pop r10
00007d3d957e103f  pop r9
00007d3d957e1041  pop r8
00007d3d957e1043  pop rsi
00007d3d957e1044  pop rdi
00007d3d957e1045  pop rdx
00007d3d957e1046  pop rcx
00007d3d957e1047  pop rax
00007d3d957e1048  add rsp, 0x08
00007d3d957e104c  jmp 0x00007D3D957DC72B
00007d3d957e1051  sub rsp, 0x08
00007d3d957e1055  push rax
00007d3d957e1056  push rcx
00007d3d957e1057  push rdx
00007d3d957e1058  push rdi
00007d3d957e1059  push rsi
00007d3d957e105a  push r8
00007d3d957e105c  push r9
00007d3d957e105e  push r10
00007d3d957e1060  push r11
00007d3d957e1062  sub rsp, 0xF0
00007d3d957e1069  vmovaps [rsp], xmm0
00007d3d957e106e  vmovaps [rsp+0x10], xmm2
00007d3d957e1074  vmovaps [rsp+0x20], xmm3
00007d3d957e107a  vmovaps [rsp+0x30], xmm4
00007d3d957e1080  vmovaps [rsp+0x40], xmm5
00007d3d957e1086  vmovaps [rsp+0x50], xmm6
00007d3d957e108c  vmovaps [rsp+0x60], xmm7
00007d3d957e1092  vmovaps [rsp+0x70], xmm8
00007d3d957e1098  vmovaps [rsp+0x80], xmm9
00007d3d957e10a1  vmovaps [rsp+0x90], xmm10
00007d3d957e10aa  vmovaps [rsp+0xA0], xmm11
00007d3d957e10b3  vmovaps [rsp+0xB0], xmm12
00007d3d957e10bc  vmovaps [rsp+0xC0], xmm13
00007d3d957e10c5  vmovaps [rsp+0xD0], xmm14
00007d3d957e10ce  vmovaps [rsp+0xE0], xmm15
00007d3d957e10d7  sub rsp, 0x30
00007d3d957e10db  movaps [rsp], xmm1
00007d3d957e10df  movaps [rsp+0x10], xmm13
00007d3d957e10e5  movaps [rsp+0x20], xmm8
00007d3d957e10eb  lea rdi, [rsp]
00007d3d957e10ef  mov esi, 0x00
00007d3d957e10f4  mov rax, 0x56C27CB8A530
00007d3d957e10fe  call rax
00007d3d957e1100  movaps xmm1, [rsp]
00007d3d957e1104  add rsp, 0x30
00007d3d957e1108  vmovaps xmm0, [rsp]
00007d3d957e110d  vmovaps xmm2, [rsp+0x10]
00007d3d957e1113  vmovaps xmm3, [rsp+0x20]
00007d3d957e1119  vmovaps xmm4, [rsp+0x30]
00007d3d957e111f  vmovaps xmm5, [rsp+0x40]
00007d3d957e1125  vmovaps xmm6, [rsp+0x50]
00007d3d957e112b  vmovaps xmm7, [rsp+0x60]
00007d3d957e1131  vmovaps xmm8, [rsp+0x70]
00007d3d957e1137  vmovaps xmm9, [rsp+0x80]
00007d3d957e1140  vmovaps xmm10, [rsp+0x90]
00007d3d957e1149  vmovaps xmm11, [rsp+0xA0]
00007d3d957e1152  vmovaps xmm12, [rsp+0xB0]
00007d3d957e115b  vmovaps xmm13, [rsp+0xC0]
00007d3d957e1164  vmovaps xmm14, [rsp+0xD0]
00007d3d957e116d  vmovaps xmm15, [rsp+0xE0]
00007d3d957e1176  add rsp, 0xF0
00007d3d957e117d  pop r11
00007d3d957e117f  pop r10
00007d3d957e1181  pop r9
00007d3d957e1183  pop r8
00007d3d957e1185  pop rsi
00007d3d957e1186  pop rdi
00007d3d957e1187  pop rdx
00007d3d957e1188  pop rcx
00007d3d957e1189  pop rax
00007d3d957e118a  add rsp, 0x08
00007d3d957e118e  jmp 0x00007D3D957DC74D
00007d3d957e1193  call 0x00007D3D9560C260
00007d3d957e1198  jmp 0x00007D3D957DC75B
00007d3d957e119d  call 0x00007D3D956BD750
00007d3d957e11a2  jmp 0x00007D3D957DC765
00007d3d957e11a7  sub rsp, 0x08
00007d3d957e11ab  push rax
00007d3d957e11ac  push rcx
00007d3d957e11ad  push rdx
00007d3d957e11ae  push rdi
00007d3d957e11af  push rsi
00007d3d957e11b0  push r8
00007d3d957e11b2  push r9
00007d3d957e11b4  push r10
00007d3d957e11b6  push r11
00007d3d957e11b8  sub rsp, 0xF0
00007d3d957e11bf  vmovaps [rsp], xmm0
00007d3d957e11c4  vmovaps [rsp+0x10], xmm1
00007d3d957e11ca  vmovaps [rsp+0x20], xmm2
00007d3d957e11d0  vmovaps [rsp+0x30], xmm3
00007d3d957e11d6  vmovaps [rsp+0x40], xmm4
00007d3d957e11dc  vmovaps [rsp+0x50], xmm5
00007d3d957e11e2  vmovaps [rsp+0x60], xmm6
00007d3d957e11e8  vmovaps [rsp+0x70], xmm7
00007d3d957e11ee  vmovaps [rsp+0x80], xmm9
00007d3d957e11f7  vmovaps [rsp+0x90], xmm10
00007d3d957e1200  vmovaps [rsp+0xA0], xmm11
00007d3d957e1209  vmovaps [rsp+0xB0], xmm12
00007d3d957e1212  vmovaps [rsp+0xC0], xmm13
00007d3d957e121b  vmovaps [rsp+0xD0], xmm14
00007d3d957e1224  vmovaps [rsp+0xE0], xmm15
00007d3d957e122d  sub rsp, 0x30
00007d3d957e1231  movaps [rsp], xmm8
00007d3d957e1236  movaps [rsp+0x10], xmm15
00007d3d957e123c  movaps [rsp+0x20], xmm7
00007d3d957e1241  lea rdi, [rsp]
00007d3d957e1245  mov esi, 0x00
00007d3d957e124a  mov rax, 0x56C27CB8A530
00007d3d957e1254  call rax
00007d3d957e1256  movaps xmm8, [rsp]
00007d3d957e125b  add rsp, 0x30
00007d3d957e125f  vmovaps xmm0, [rsp]
00007d3d957e1264  vmovaps xmm1, [rsp+0x10]
00007d3d957e126a  vmovaps xmm2, [rsp+0x20]
00007d3d957e1270  vmovaps xmm3, [rsp+0x30]
00007d3d957e1276  vmovaps xmm4, [rsp+0x40]
00007d3d957e127c  vmovaps xmm5, [rsp+0x50]
00007d3d957e1282  vmovaps xmm6, [rsp+0x60]
00007d3d957e1288  vmovaps xmm7, [rsp+0x70]
00007d3d957e128e  vmovaps xmm9, [rsp+0x80]
00007d3d957e1297  vmovaps xmm10, [rsp+0x90]
00007d3d957e12a0  vmovaps xmm11, [rsp+0xA0]
00007d3d957e12a9  vmovaps xmm12, [rsp+0xB0]
00007d3d957e12b2  vmovaps xmm13, [rsp+0xC0]
00007d3d957e12bb  vmovaps xmm14, [rsp+0xD0]
00007d3d957e12c4  vmovaps xmm15, [rsp+0xE0]
00007d3d957e12cd  add rsp, 0xF0
00007d3d957e12d4  pop r11
00007d3d957e12d6  pop r10
00007d3d957e12d8  pop r9
00007d3d957e12da  pop r8
00007d3d957e12dc  pop rsi
00007d3d957e12dd  pop rdi
00007d3d957e12de  pop rdx
00007d3d957e12df  pop rcx
00007d3d957e12e0  pop rax
00007d3d957e12e1  add rsp, 0x08
00007d3d957e12e5  jmp 0x00007D3D957DC787
00007d3d957e12ea  sub rsp, 0x08
00007d3d957e12ee  push rax
00007d3d957e12ef  push rcx
00007d3d957e12f0  push rdx
00007d3d957e12f1  push rdi
00007d3d957e12f2  push rsi
00007d3d957e12f3  push r8
00007d3d957e12f5  push r9
00007d3d957e12f7  push r10
00007d3d957e12f9  push r11
00007d3d957e12fb  sub rsp, 0xF0
00007d3d957e1302  vmovaps [rsp], xmm0
00007d3d957e1307  vmovaps [rsp+0x10], xmm1
00007d3d957e130d  vmovaps [rsp+0x20], xmm2
00007d3d957e1313  vmovaps [rsp+0x30], xmm3
00007d3d957e1319  vmovaps [rsp+0x40], xmm4
00007d3d957e131f  vmovaps [rsp+0x50], xmm5
00007d3d957e1325  vmovaps [rsp+0x60], xmm6
00007d3d957e132b  vmovaps [rsp+0x70], xmm8
00007d3d957e1331  vmovaps [rsp+0x80], xmm9
00007d3d957e133a  vmovaps [rsp+0x90], xmm10
00007d3d957e1343  vmovaps [rsp+0xA0], xmm11
00007d3d957e134c  vmovaps [rsp+0xB0], xmm12
00007d3d957e1355  vmovaps [rsp+0xC0], xmm13
00007d3d957e135e  vmovaps [rsp+0xD0], xmm14
00007d3d957e1367  vmovaps [rsp+0xE0], xmm15
00007d3d957e1370  sub rsp, 0x30
00007d3d957e1374  movaps [rsp], xmm7
00007d3d957e1378  movaps [rsp+0x10], xmm9
00007d3d957e137e  movaps [rsp+0x20], xmm15
00007d3d957e1384  lea rdi, [rsp]
00007d3d957e1388  mov esi, 0x00
00007d3d957e138d  mov rax, 0x56C27CB8A530
00007d3d957e1397  call rax
00007d3d957e1399  movaps xmm7, [rsp]
00007d3d957e139d  add rsp, 0x30
00007d3d957e13a1  vmovaps xmm0, [rsp]
00007d3d957e13a6  vmovaps xmm1, [rsp+0x10]
00007d3d957e13ac  vmovaps xmm2, [rsp+0x20]
00007d3d957e13b2  vmovaps xmm3, [rsp+0x30]
00007d3d957e13b8  vmovaps xmm4, [rsp+0x40]
00007d3d957e13be  vmovaps xmm5, [rsp+0x50]
00007d3d957e13c4  vmovaps xmm6, [rsp+0x60]
00007d3d957e13ca  vmovaps xmm8, [rsp+0x70]
00007d3d957e13d0  vmovaps xmm9, [rsp+0x80]
00007d3d957e13d9  vmovaps xmm10, [rsp+0x90]
00007d3d957e13e2  vmovaps xmm11, [rsp+0xA0]
00007d3d957e13eb  vmovaps xmm12, [rsp+0xB0]
00007d3d957e13f4  vmovaps xmm13, [rsp+0xC0]
00007d3d957e13fd  vmovaps xmm14, [rsp+0xD0]
00007d3d957e1406  vmovaps xmm15, [rsp+0xE0]
00007d3d957e140f  add rsp, 0xF0
00007d3d957e1416  pop r11
00007d3d957e1418  pop r10
00007d3d957e141a  pop r9
00007d3d957e141c  pop r8
00007d3d957e141e  pop rsi
00007d3d957e141f  pop rdi
00007d3d957e1420  pop rdx
00007d3d957e1421  pop rcx
00007d3d957e1422  pop rax
00007d3d957e1423  add rsp, 0x08
00007d3d957e1427  jmp 0x00007D3D957DC7B4
00007d3d957e142c  sub rsp, 0x08
00007d3d957e1430  push rax
00007d3d957e1431  push rcx
00007d3d957e1432  push rdx
00007d3d957e1433  push rdi
00007d3d957e1434  push rsi
00007d3d957e1435  push r8
00007d3d957e1437  push r9
00007d3d957e1439  push r10
00007d3d957e143b  push r11
00007d3d957e143d  sub rsp, 0xF0
00007d3d957e1444  vmovaps [rsp], xmm0
00007d3d957e1449  vmovaps [rsp+0x10], xmm1
00007d3d957e144f  vmovaps [rsp+0x20], xmm2
00007d3d957e1455  vmovaps [rsp+0x30], xmm3
00007d3d957e145b  vmovaps [rsp+0x40], xmm4
00007d3d957e1461  vmovaps [rsp+0x50], xmm5
00007d3d957e1467  vmovaps [rsp+0x60], xmm6
00007d3d957e146d  vmovaps [rsp+0x70], xmm7
00007d3d957e1473  vmovaps [rsp+0x80], xmm8
00007d3d957e147c  vmovaps [rsp+0x90], xmm10
00007d3d957e1485  vmovaps [rsp+0xA0], xmm11
00007d3d957e148e  vmovaps [rsp+0xB0], xmm12
00007d3d957e1497  vmovaps [rsp+0xC0], xmm13
00007d3d957e14a0  vmovaps [rsp+0xD0], xmm14
00007d3d957e14a9  vmovaps [rsp+0xE0], xmm15
00007d3d957e14b2  sub rsp, 0x30
00007d3d957e14b6  movaps [rsp], xmm9
00007d3d957e14bb  movaps [rsp+0x10], xmm13
00007d3d957e14c1  movaps [rsp+0x20], xmm15
00007d3d957e14c7  lea rdi, [rsp]
00007d3d957e14cb  mov esi, 0x00
00007d3d957e14d0  mov rax, 0x56C27CB8A530
00007d3d957e14da  call rax
00007d3d957e14dc  movaps xmm9, [rsp]
00007d3d957e14e1  add rsp, 0x30
00007d3d957e14e5  vmovaps xmm0, [rsp]
00007d3d957e14ea  vmovaps xmm1, [rsp+0x10]
00007d3d957e14f0  vmovaps xmm2, [rsp+0x20]
00007d3d957e14f6  vmovaps xmm3, [rsp+0x30]
00007d3d957e14fc  vmovaps xmm4, [rsp+0x40]
00007d3d957e1502  vmovaps xmm5, [rsp+0x50]
00007d3d957e1508  vmovaps xmm6, [rsp+0x60]
00007d3d957e150e  vmovaps xmm7, [rsp+0x70]
00007d3d957e1514  vmovaps xmm8, [rsp+0x80]
00007d3d957e151d  vmovaps xmm10, [rsp+0x90]
00007d3d957e1526  vmovaps xmm11, [rsp+0xA0]
00007d3d957e152f  vmovaps xmm12, [rsp+0xB0]
00007d3d957e1538  vmovaps xmm13, [rsp+0xC0]
00007d3d957e1541  vmovaps xmm14, [rsp+0xD0]
00007d3d957e154a  vmovaps xmm15, [rsp+0xE0]
00007d3d957e1553  add rsp, 0xF0
00007d3d957e155a  pop r11
00007d3d957e155c  pop r10
00007d3d957e155e  pop r9
00007d3d957e1560  pop r8
00007d3d957e1562  pop rsi
00007d3d957e1563  pop rdi
00007d3d957e1564  pop rdx
00007d3d957e1565  pop rcx
00007d3d957e1566  pop rax
00007d3d957e1567  add rsp, 0x08
00007d3d957e156b  jmp 0x00007D3D957DC7E2
00007d3d957e1570  sub rsp, 0x08
00007d3d957e1574  push rax
00007d3d957e1575  push rcx
00007d3d957e1576  push rdx
00007d3d957e1577  push rdi
00007d3d957e1578  push rsi
00007d3d957e1579  push r8
00007d3d957e157b  push r9
00007d3d957e157d  push r10
00007d3d957e157f  push r11
00007d3d957e1581  sub rsp, 0xF0
00007d3d957e1588  vmovaps [rsp], xmm0
00007d3d957e158d  vmovaps [rsp+0x10], xmm1
00007d3d957e1593  vmovaps [rsp+0x20], xmm2
00007d3d957e1599  vmovaps [rsp+0x30], xmm3
00007d3d957e159f  vmovaps [rsp+0x40], xmm4
00007d3d957e15a5  vmovaps [rsp+0x50], xmm5
00007d3d957e15ab  vmovaps [rsp+0x60], xmm6
00007d3d957e15b1  vmovaps [rsp+0x70], xmm7
00007d3d957e15b7  vmovaps [rsp+0x80], xmm8
00007d3d957e15c0  vmovaps [rsp+0x90], xmm9
00007d3d957e15c9  vmovaps [rsp+0xA0], xmm10
00007d3d957e15d2  vmovaps [rsp+0xB0], xmm11
00007d3d957e15db  vmovaps [rsp+0xC0], xmm12
00007d3d957e15e4  vmovaps [rsp+0xD0], xmm13
00007d3d957e15ed  vmovaps [rsp+0xE0], xmm14
00007d3d957e15f6  sub rsp, 0x30
00007d3d957e15fa  movaps [rsp], xmm15
00007d3d957e15ff  movaps [rsp+0x10], xmm11
00007d3d957e1605  movaps [rsp+0x20], xmm12
00007d3d957e160b  lea rdi, [rsp]
00007d3d957e160f  mov esi, 0x00
00007d3d957e1614  mov rax, 0x56C27CB8A530
00007d3d957e161e  call rax
00007d3d957e1620  movaps xmm15, [rsp]
00007d3d957e1625  add rsp, 0x30
00007d3d957e1629  vmovaps xmm0, [rsp]
00007d3d957e162e  vmovaps xmm1, [rsp+0x10]
00007d3d957e1634  vmovaps xmm2, [rsp+0x20]
00007d3d957e163a  vmovaps xmm3, [rsp+0x30]
00007d3d957e1640  vmovaps xmm4, [rsp+0x40]
00007d3d957e1646  vmovaps xmm5, [rsp+0x50]
00007d3d957e164c  vmovaps xmm6, [rsp+0x60]
00007d3d957e1652  vmovaps xmm7, [rsp+0x70]
00007d3d957e1658  vmovaps xmm8, [rsp+0x80]
00007d3d957e1661  vmovaps xmm9, [rsp+0x90]
00007d3d957e166a  vmovaps xmm10, [rsp+0xA0]
00007d3d957e1673  vmovaps xmm11, [rsp+0xB0]
00007d3d957e167c  vmovaps xmm12, [rsp+0xC0]
00007d3d957e1685  vmovaps xmm13, [rsp+0xD0]
00007d3d957e168e  vmovaps xmm14, [rsp+0xE0]
00007d3d957e1697  add rsp, 0xF0
00007d3d957e169e  pop r11
00007d3d957e16a0  pop r10
00007d3d957e16a2  pop r9
00007d3d957e16a4  pop r8
00007d3d957e16a6  pop rsi
00007d3d957e16a7  pop rdi
00007d3d957e16a8  pop rdx
00007d3d957e16a9  pop rcx
00007d3d957e16aa  pop rax
00007d3d957e16ab  add rsp, 0x08
00007d3d957e16af  jmp 0x00007D3D957DC7FD
00007d3d957e16b4  sub rsp, 0x08
00007d3d957e16b8  push rax
00007d3d957e16b9  push rcx
00007d3d957e16ba  push rdx
00007d3d957e16bb  push rdi
00007d3d957e16bc  push rsi
00007d3d957e16bd  push r8
00007d3d957e16bf  push r9
00007d3d957e16c1  push r10
00007d3d957e16c3  push r11
00007d3d957e16c5  sub rsp, 0xF0
00007d3d957e16cc  vmovaps [rsp], xmm0
00007d3d957e16d1  vmovaps [rsp+0x10], xmm1
00007d3d957e16d7  vmovaps [rsp+0x20], xmm2
00007d3d957e16dd  vmovaps [rsp+0x30], xmm3
00007d3d957e16e3  vmovaps [rsp+0x40], xmm4
00007d3d957e16e9  vmovaps [rsp+0x50], xmm5
00007d3d957e16ef  vmovaps [rsp+0x60], xmm6
00007d3d957e16f5  vmovaps [rsp+0x70], xmm7
00007d3d957e16fb  vmovaps [rsp+0x80], xmm8
00007d3d957e1704  vmovaps [rsp+0x90], xmm9
00007d3d957e170d  vmovaps [rsp+0xA0], xmm10
00007d3d957e1716  vmovaps [rsp+0xB0], xmm11
00007d3d957e171f  vmovaps [rsp+0xC0], xmm12
00007d3d957e1728  vmovaps [rsp+0xD0], xmm14
00007d3d957e1731  vmovaps [rsp+0xE0], xmm15
00007d3d957e173a  sub rsp, 0x30
00007d3d957e173e  movaps [rsp], xmm13
00007d3d957e1743  movaps [rsp+0x10], xmm10
00007d3d957e1749  movaps [rsp+0x20], xmm14
00007d3d957e174f  lea rdi, [rsp]
00007d3d957e1753  mov esi, 0x00
00007d3d957e1758  mov rax, 0x56C27CB8A530
00007d3d957e1762  call rax
00007d3d957e1764  movaps xmm13, [rsp]
00007d3d957e1769  add rsp, 0x30
00007d3d957e176d  vmovaps xmm0, [rsp]
00007d3d957e1772  vmovaps xmm1, [rsp+0x10]
00007d3d957e1778  vmovaps xmm2, [rsp+0x20]
00007d3d957e177e  vmovaps xmm3, [rsp+0x30]
00007d3d957e1784  vmovaps xmm4, [rsp+0x40]
00007d3d957e178a  vmovaps xmm5, [rsp+0x50]
00007d3d957e1790  vmovaps xmm6, [rsp+0x60]
00007d3d957e1796  vmovaps xmm7, [rsp+0x70]
00007d3d957e179c  vmovaps xmm8, [rsp+0x80]
00007d3d957e17a5  vmovaps xmm9, [rsp+0x90]
00007d3d957e17ae  vmovaps xmm10, [rsp+0xA0]
00007d3d957e17b7  vmovaps xmm11, [rsp+0xB0]
00007d3d957e17c0  vmovaps xmm12, [rsp+0xC0]
00007d3d957e17c9  vmovaps xmm14, [rsp+0xD0]
00007d3d957e17d2  vmovaps xmm15, [rsp+0xE0]
00007d3d957e17db  add rsp, 0xF0
00007d3d957e17e2  pop r11
00007d3d957e17e4  pop r10
00007d3d957e17e6  pop r9
00007d3d957e17e8  pop r8
00007d3d957e17ea  pop rsi
00007d3d957e17eb  pop rdi
00007d3d957e17ec  pop rdx
00007d3d957e17ed  pop rcx
00007d3d957e17ee  pop rax
00007d3d957e17ef  add rsp, 0x08
00007d3d957e17f3  jmp 0x00007D3D957DC820
00007d3d957e17f8  sub rsp, 0x08
00007d3d957e17fc  push rax
00007d3d957e17fd  push rcx
00007d3d957e17fe  push rdx
00007d3d957e17ff  push rdi
00007d3d957e1800  push rsi
00007d3d957e1801  push r8
00007d3d957e1803  push r9
00007d3d957e1805  push r10
00007d3d957e1807  push r11
00007d3d957e1809  sub rsp, 0xF0
00007d3d957e1810  vmovaps [rsp], xmm0
00007d3d957e1815  vmovaps [rsp+0x10], xmm1
00007d3d957e181b  vmovaps [rsp+0x20], xmm2
00007d3d957e1821  vmovaps [rsp+0x30], xmm3
00007d3d957e1827  vmovaps [rsp+0x40], xmm4
00007d3d957e182d  vmovaps [rsp+0x50], xmm5
00007d3d957e1833  vmovaps [rsp+0x60], xmm6
00007d3d957e1839  vmovaps [rsp+0x70], xmm7
00007d3d957e183f  vmovaps [rsp+0x80], xmm8
00007d3d957e1848  vmovaps [rsp+0x90], xmm9
00007d3d957e1851  vmovaps [rsp+0xA0], xmm10
00007d3d957e185a  vmovaps [rsp+0xB0], xmm11
00007d3d957e1863  vmovaps [rsp+0xC0], xmm12
00007d3d957e186c  vmovaps [rsp+0xD0], xmm13
00007d3d957e1875  vmovaps [rsp+0xE0], xmm15
00007d3d957e187e  sub rsp, 0x30
00007d3d957e1882  movaps [rsp], xmm14
00007d3d957e1887  movaps [rsp+0x10], xmm1
00007d3d957e188c  movaps [rsp+0x20], xmm7
00007d3d957e1891  lea rdi, [rsp]
00007d3d957e1895  mov esi, 0x00
00007d3d957e189a  mov rax, 0x56C27CB8A530
00007d3d957e18a4  call rax
00007d3d957e18a6  movaps xmm14, [rsp]
00007d3d957e18ab  add rsp, 0x30
00007d3d957e18af  vmovaps xmm0, [rsp]
00007d3d957e18b4  vmovaps xmm1, [rsp+0x10]
00007d3d957e18ba  vmovaps xmm2, [rsp+0x20]
00007d3d957e18c0  vmovaps xmm3, [rsp+0x30]
00007d3d957e18c6  vmovaps xmm4, [rsp+0x40]
00007d3d957e18cc  vmovaps xmm5, [rsp+0x50]
00007d3d957e18d2  vmovaps xmm6, [rsp+0x60]
00007d3d957e18d8  vmovaps xmm7, [rsp+0x70]
00007d3d957e18de  vmovaps xmm8, [rsp+0x80]
00007d3d957e18e7  vmovaps xmm9, [rsp+0x90]
00007d3d957e18f0  vmovaps xmm10, [rsp+0xA0]
00007d3d957e18f9  vmovaps xmm11, [rsp+0xB0]
00007d3d957e1902  vmovaps xmm12, [rsp+0xC0]
00007d3d957e190b  vmovaps xmm13, [rsp+0xD0]
00007d3d957e1914  vmovaps xmm15, [rsp+0xE0]
00007d3d957e191d  add rsp, 0xF0
00007d3d957e1924  pop r11
00007d3d957e1926  pop r10
00007d3d957e1928  pop r9
00007d3d957e192a  pop r8
00007d3d957e192c  pop rsi
00007d3d957e192d  pop rdi
00007d3d957e192e  pop rdx
00007d3d957e192f  pop rcx
00007d3d957e1930  pop rax
00007d3d957e1931  add rsp, 0x08
00007d3d957e1935  jmp 0x00007D3D957DC843
00007d3d957e193a  sub rsp, 0x08
00007d3d957e193e  push rax
00007d3d957e193f  push rcx
00007d3d957e1940  push rdx
00007d3d957e1941  push rdi
00007d3d957e1942  push rsi
00007d3d957e1943  push r8
00007d3d957e1945  push r9
00007d3d957e1947  push r10
00007d3d957e1949  push r11
00007d3d957e194b  sub rsp, 0xF0
00007d3d957e1952  vmovaps [rsp], xmm0
00007d3d957e1957  vmovaps [rsp+0x10], xmm2
00007d3d957e195d  vmovaps [rsp+0x20], xmm3
00007d3d957e1963  vmovaps [rsp+0x30], xmm4
00007d3d957e1969  vmovaps [rsp+0x40], xmm5
00007d3d957e196f  vmovaps [rsp+0x50], xmm6
00007d3d957e1975  vmovaps [rsp+0x60], xmm7
00007d3d957e197b  vmovaps [rsp+0x70], xmm8
00007d3d957e1981  vmovaps [rsp+0x80], xmm9
00007d3d957e198a  vmovaps [rsp+0x90], xmm10
00007d3d957e1993  vmovaps [rsp+0xA0], xmm11
00007d3d957e199c  vmovaps [rsp+0xB0], xmm12
00007d3d957e19a5  vmovaps [rsp+0xC0], xmm13
00007d3d957e19ae  vmovaps [rsp+0xD0], xmm14
00007d3d957e19b7  vmovaps [rsp+0xE0], xmm15
00007d3d957e19c0  sub rsp, 0x30
00007d3d957e19c4  movaps [rsp], xmm1
00007d3d957e19c8  movaps [rsp+0x10], xmm8
00007d3d957e19ce  movaps [rsp+0x20], xmm9
00007d3d957e19d4  lea rdi, [rsp]
00007d3d957e19d8  mov esi, 0x00
00007d3d957e19dd  mov rax, 0x56C27CB8A530
00007d3d957e19e7  call rax
00007d3d957e19e9  movaps xmm1, [rsp]
00007d3d957e19ed  add rsp, 0x30
00007d3d957e19f1  vmovaps xmm0, [rsp]
00007d3d957e19f6  vmovaps xmm2, [rsp+0x10]
00007d3d957e19fc  vmovaps xmm3, [rsp+0x20]
00007d3d957e1a02  vmovaps xmm4, [rsp+0x30]
00007d3d957e1a08  vmovaps xmm5, [rsp+0x40]
00007d3d957e1a0e  vmovaps xmm6, [rsp+0x50]
00007d3d957e1a14  vmovaps xmm7, [rsp+0x60]
00007d3d957e1a1a  vmovaps xmm8, [rsp+0x70]
00007d3d957e1a20  vmovaps xmm9, [rsp+0x80]
00007d3d957e1a29  vmovaps xmm10, [rsp+0x90]
00007d3d957e1a32  vmovaps xmm11, [rsp+0xA0]
00007d3d957e1a3b  vmovaps xmm12, [rsp+0xB0]
00007d3d957e1a44  vmovaps xmm13, [rsp+0xC0]
00007d3d957e1a4d  vmovaps xmm14, [rsp+0xD0]
00007d3d957e1a56  vmovaps xmm15, [rsp+0xE0]
00007d3d957e1a5f  add rsp, 0xF0
00007d3d957e1a66  pop r11
00007d3d957e1a68  pop r10
00007d3d957e1a6a  pop r9
00007d3d957e1a6c  pop r8
00007d3d957e1a6e  pop rsi
00007d3d957e1a6f  pop rdi
00007d3d957e1a70  pop rdx
00007d3d957e1a71  pop rcx
00007d3d957e1a72  pop rax
00007d3d957e1a73  add rsp, 0x08
00007d3d957e1a77  jmp 0x00007D3D957DC865
00007d3d957e1a7c  call 0x00007D3D956E5940
00007d3d957e1a81  jmp 0x00007D3D957DC873
00007d3d957e1a86  call 0x00007D3D9560C380
00007d3d957e1a8b  jmp 0x00007D3D957DC87D
00007d3d957e1a90  call 0x00007D3D9560D600
00007d3d957e1a95  jmp 0x00007D3D957DC887
00007d3d957e1a9a  call 0x00007D3D955FF540
00007d3d957e1a9f  jmp 0x00007D3D957DC891
00007d3d957e1aa4  int3
00007d3d957e1aa5  nop [rax+rax*1], ax
00007d3d957e1aae  nop
00007d3d957e1ab0  mov rax, [r15+0xF8]
00007d3d957e1ab7  lea r14, [rax+0x140]
00007d3d957e1abe  mov r12, [r13+r14*1]
00007d3d957e1ac3  mov [r15+0xE8], r12
00007d3d957e1aca  lea r14, [rax+0x130]
00007d3d957e1ad1  mov r12, [r13+r14*1]
00007d3d957e1ad6  lea r14, [rax+0x138]
00007d3d957e1add  mov r11, [r13+r14*1]
00007d3d957e1ae2  movq xmm1, r12
00007d3d957e1ae7  movq xmm15, r11
00007d3d957e1aec  movq xmm1, xmm1
00007d3d957e1af0  movq xmm1, xmm1
00007d3d957e1af4  movaps [r15+0x1A0], xmm1
00007d3d957e1afc  movq xmm15, xmm15
00007d3d957e1b01  movq xmm15, xmm15
00007d3d957e1b06  movaps [r15+0x190], xmm15
00007d3d957e1b0e  lea r14, [rax+0x120]
00007d3d957e1b15  mov r12, [r13+r14*1]
00007d3d957e1b1a  lea r14, [rax+0x128]
00007d3d957e1b21  mov r11, [r13+r14*1]
00007d3d957e1b26  movq xmm1, r12
00007d3d957e1b2b  movq xmm15, r11
00007d3d957e1b30  movq xmm1, xmm1
00007d3d957e1b34  movq xmm1, xmm1
00007d3d957e1b38  movaps [r15+0x1C0], xmm1
00007d3d957e1b40  movq xmm15, xmm15
00007d3d957e1b45  movq xmm15, xmm15
00007d3d957e1b4a  movaps [r15+0x1B0], xmm15
00007d3d957e1b52  lea r14, [rax+0x110]
00007d3d957e1b59  mov r12, [r13+r14*1]
00007d3d957e1b5e  lea r14, [rax+0x118]
00007d3d957e1b65  mov r11, [r13+r14*1]
00007d3d957e1b6a  movq xmm1, r12
00007d3d957e1b6f  movq xmm15, r11
00007d3d957e1b74  movq xmm1, xmm1
00007d3d957e1b78  movq xmm1, xmm1
00007d3d957e1b7c  movaps [r15+0x1E0], xmm1
00007d3d957e1b84  movq xmm15, xmm15
00007d3d957e1b89  movq xmm15, xmm15
00007d3d957e1b8e  movaps [r15+0x1D0], xmm15
00007d3d957e1b96  lea r14, [rax+0x100]
00007d3d957e1b9d  mov r12, [r13+r14*1]
00007d3d957e1ba2  lea r14, [rax+0x108]
00007d3d957e1ba9  mov r11, [r13+r14*1]
00007d3d957e1bae  movq xmm1, r12
00007d3d957e1bb3  movq xmm15, r11
00007d3d957e1bb8  movq xmm1, xmm1
00007d3d957e1bbc  movq xmm1, xmm1
00007d3d957e1bc0  movaps [r15+0x200], xmm1
00007d3d957e1bc8  movq xmm15, xmm15
00007d3d957e1bcd  movq xmm15, xmm15
00007d3d957e1bd2  movaps [r15+0x1F0], xmm15
00007d3d957e1bda  mov qword ptr [r15+0x40], 0x430000
00007d3d957e1be2  mov r14d, 0x430510
00007d3d957e1be8  mov r12, [r13+r14*1]
00007d3d957e1bed  movq xmm1, r12
00007d3d957e1bf2  lea r14, [rax+0x150]
00007d3d957e1bf9  mov [r15+0xF8], r14
00007d3d957e1c00  mov rax, [r15+0x50]
00007d3d957e1c04  movups xmm15, [r13+rax*1]
00007d3d957e1c0a  movaps [r15+0x120], xmm15
00007d3d957e1c12  mov qword ptr [r15+0x48], 0x10
00007d3d957e1c1a  xor eax, eax
00007d3d957e1c1c  mov r14d, 0x10
00007d3d957e1c22  mov r12d, 0x200
00007d3d957e1c28  cmp r14, r12
00007d3d957e1c2b  cmc
00007d3d957e1c2c  lahf
00007d3d957e1c2d  seto al
00007d3d957e1c30  mov [r15+0x108], eax
00007d3d957e1c37  pextrq rax, xmm15, 0x01
00007d3d957e1c3e  movq xmm14, rax
00007d3d957e1c43  movaps [r15+0x130], xmm14
00007d3d957e1c4b  movq rax, xmm1
00007d3d957e1c50  movq r14, xmm15
00007d3d957e1c55  vmovq xmm1, rax
00007d3d957e1c5a  vmovq xmm15, r14
00007d3d957e1c5f  movaps xmm13, xmm1
00007d3d957e1c63  addsd xmm13, xmm15
00007d3d957e1c68  ucomisd xmm13, xmm13
00007d3d957e1c6d  jp 0x00007D3D957E1D86
00007d3d957e1c73  movq xmm13, xmm13
00007d3d957e1c78  movq rax, xmm13
00007d3d957e1c7d  movq r14, xmm14
00007d3d957e1c82  vmovq xmm1, rax
00007d3d957e1c87  vmovq xmm15, r14
00007d3d957e1c8c  movaps xmm14, xmm1
00007d3d957e1c90  addsd xmm14, xmm15
00007d3d957e1c95  ucomisd xmm14, xmm14
00007d3d957e1c9a  jp 0x00007D3D957E1DCE
00007d3d957e1ca0  movq xmm14, xmm14
00007d3d957e1ca5  movaps [r15+0x110], xmm14
00007d3d957e1cad  mov eax, [r15+0x108]
00007d3d957e1cb4  sahf
00007d3d957e1cb5  jnz 0x00007D3D957E1CE7
00007d3d957e1cb7  cmp dword ptr [r15+0x318], 0x00
00007d3d957e1cbf  jz 0x00007D3D957E1FE0
00007d3d957e1cc5  nop [rax+rax*1], ax
00007d3d957e1cce  nop [rax+rax*1], eax
00007d3d957e1cd6  mov eax, 0x410490
00007d3d957e1cdb  mov [r15+0x100], rax
00007d3d957e1ce2  jmp 0x00007D3D955FE110
00007d3d957e1ce7  cmp dword ptr [r15+0x318], 0x00
00007d3d957e1cef  jz 0x00007D3D957E1E20
00007d3d957e1cf5  nop [rax+rax*1], ax
00007d3d957e1cfe  nop [rax+rax*1], eax
00007d3d957e1d06  mov eax, 0x410474
00007d3d957e1d0b  mov [r15+0x100], rax
00007d3d957e1d12  jmp 0x00007D3D955FE110
00007d3d957e1d17  int3
00007d3d957e1d18  call 0x00007D3D956E27E0
00007d3d957e1d1d  jmp 0x00007D3D957E1AC3
00007d3d957e1d22  call 0x00007D3D956E27E0
00007d3d957e1d27  jmp 0x00007D3D957E1AD6
00007d3d957e1d2c  call 0x00007D3D956E1570
00007d3d957e1d31  jmp 0x00007D3D957E1AE2
00007d3d957e1d36  call 0x00007D3D956E27E0
00007d3d957e1d3b  jmp 0x00007D3D957E1B1A
00007d3d957e1d40  call 0x00007D3D956E1570
00007d3d957e1d45  jmp 0x00007D3D957E1B26
00007d3d957e1d4a  call 0x00007D3D956E27E0
00007d3d957e1d4f  jmp 0x00007D3D957E1B5E
00007d3d957e1d54  call 0x00007D3D956E1570
00007d3d957e1d59  jmp 0x00007D3D957E1B6A
00007d3d957e1d5e  call 0x00007D3D956E27E0
00007d3d957e1d63  jmp 0x00007D3D957E1BA2
00007d3d957e1d68  call 0x00007D3D956E1570
00007d3d957e1d6d  jmp 0x00007D3D957E1BAE
00007d3d957e1d72  call 0x00007D3D956E27E0
00007d3d957e1d77  jmp 0x00007D3D957E1BED
00007d3d957e1d7c  call 0x00007D3D9560E760
00007d3d957e1d81  jmp 0x00007D3D957E1C0A
00007d3d957e1d86  ucomisd xmm1, xmm15
00007d3d957e1d8b  jp 0x00007D3D957E1D9A
00007d3d957e1d8d  movaps xmm13, [0x00007D3D953FE060]
00007d3d957e1d95  jmp 0x00007D3D957E1C73
00007d3d957e1d9a  vxorps xmm0, xmm1, xmm15
00007d3d957e1d9f  pextrw eax, xmm0, 0x03
00007d3d957e1da4  and eax, 0x7FF8
00007d3d957e1da9  cmp eax, 0x08
00007d3d957e1dac  jnz 0x00007D3D957E1C73
00007d3d957e1db2  movq rax, xmm15
00007d3d957e1db7  shl rax, 0x0D
00007d3d957e1dbb  jbe 0x00007D3D957E1C73
00007d3d957e1dc1  vorps xmm13, xmm15, [0x00007D3D953FE070]
00007d3d957e1dc9  jmp 0x00007D3D957E1C73
00007d3d957e1dce  ucomisd xmm1, xmm15
00007d3d957e1dd3  jp 0x00007D3D957E1DE2
00007d3d957e1dd5  movaps xmm14, [0x00007D3D953FE060]
00007d3d957e1ddd  jmp 0x00007D3D957E1CA0
00007d3d957e1de2  vxorps xmm0, xmm1, xmm15
00007d3d957e1de7  pextrw eax, xmm0, 0x03
00007d3d957e1dec  and eax, 0x7FF8
00007d3d957e1df1  cmp eax, 0x08
00007d3d957e1df4  jnz 0x00007D3D957E1CA0
00007d3d957e1dfa  movq rax, xmm15
00007d3d957e1dff  shl rax, 0x0D
00007d3d957e1e03  jbe 0x00007D3D957E1CA0
00007d3d957e1e09  vorps xmm14, xmm15, [0x00007D3D953FE070]
00007d3d957e1e11  jmp 0x00007D3D957E1CA0
00007d3d957e1e16  int3
00007d3d957e1e17  nop [rax+rax*1], ax
00007d3d957e1e20  mov rax, [r15+0x48]
00007d3d957e1e24  mov r14, [r15+0x50]
00007d3d957e1e28  lea r12, [r14+rax*1]
00007d3d957e1e2c  movups xmm1, [r13+r12*1]
00007d3d957e1e32  movaps [r15+0x120], xmm1
00007d3d957e1e3a  lea r14, [rax+0x10]
00007d3d957e1e3e  mov [r15+0x48], r14
00007d3d957e1e42  xor eax, eax
00007d3d957e1e44  mov r12d, 0x200
00007d3d957e1e4a  cmp r14, r12
00007d3d957e1e4d  cmc
00007d3d957e1e4e  lahf
00007d3d957e1e4f  seto al
00007d3d957e1e52  mov [r15+0x108], eax
00007d3d957e1e59  pextrq rax, xmm1, 0x01
00007d3d957e1e60  movq xmm15, rax
00007d3d957e1e65  movaps [r15+0x130], xmm15
00007d3d957e1e6d  movaps xmm14, [r15+0x110]
00007d3d957e1e75  movq rax, xmm14
00007d3d957e1e7a  movq r14, xmm1
00007d3d957e1e7f  vmovq xmm1, rax
00007d3d957e1e84  vmovq xmm14, r14
00007d3d957e1e89  movaps xmm13, xmm1
00007d3d957e1e8d  addsd xmm13, xmm14
00007d3d957e1e92  ucomisd xmm13, xmm13
00007d3d957e1e97  jp 0x00007D3D957E1F4C
00007d3d957e1e9d  movq xmm13, xmm13
00007d3d957e1ea2  movq rax, xmm13
00007d3d957e1ea7  movq r14, xmm15
00007d3d957e1eac  vmovq xmm1, rax
00007d3d957e1eb1  vmovq xmm15, r14
00007d3d957e1eb6  movaps xmm14, xmm1
00007d3d957e1eba  addsd xmm14, xmm15
00007d3d957e1ebf  ucomisd xmm14, xmm14
00007d3d957e1ec4  jp 0x00007D3D957E1F94
00007d3d957e1eca  movq xmm14, xmm14
00007d3d957e1ecf  movaps [r15+0x110], xmm14
00007d3d957e1ed7  mov eax, [r15+0x108]
00007d3d957e1ede  sahf
00007d3d957e1edf  jnz 0x00007D3D957E1F11
00007d3d957e1ee1  cmp dword ptr [r15+0x318], 0x00
00007d3d957e1ee9  jz 0x00007D3D957E1FE0
00007d3d957e1eef  nop [rax+rax*1], ax
00007d3d957e1ef8  nop [rax+rax*1], eax
00007d3d957e1f00  mov eax, 0x410490
00007d3d957e1f05  mov [r15+0x100], rax
00007d3d957e1f0c  jmp 0x00007D3D955FE110
00007d3d957e1f11  cmp dword ptr [r15+0x318], 0x00
00007d3d957e1f19  jz 0x00007D3D957E1E20
00007d3d957e1f1f  nop [rax+rax*1], ax
00007d3d957e1f28  nop [rax+rax*1], eax
00007d3d957e1f30  mov eax, 0x410474
00007d3d957e1f35  mov [r15+0x100], rax
00007d3d957e1f3c  jmp 0x00007D3D955FE110
00007d3d957e1f41  int3
00007d3d957e1f42  call 0x00007D3D956B52F0
00007d3d957e1f47  jmp 0x00007D3D957E1E32
00007d3d957e1f4c  ucomisd xmm1, xmm14
00007d3d957e1f51  jp 0x00007D3D957E1F60
00007d3d957e1f53  movaps xmm13, [0x00007D3D953FE060]
00007d3d957e1f5b  jmp 0x00007D3D957E1E9D
00007d3d957e1f60  vxorps xmm0, xmm1, xmm14
00007d3d957e1f65  pextrw eax, xmm0, 0x03
00007d3d957e1f6a  and eax, 0x7FF8
00007d3d957e1f6f  cmp eax, 0x08
00007d3d957e1f72  jnz 0x00007D3D957E1E9D
00007d3d957e1f78  movq rax, xmm14
00007d3d957e1f7d  shl rax, 0x0D
00007d3d957e1f81  jbe 0x00007D3D957E1E9D
00007d3d957e1f87  vorps xmm13, xmm14, [0x00007D3D953FE070]
00007d3d957e1f8f  jmp 0x00007D3D957E1E9D
00007d3d957e1f94  ucomisd xmm1, xmm15
00007d3d957e1f99  jp 0x00007D3D957E1FA8
00007d3d957e1f9b  movaps xmm14, [0x00007D3D953FE060]
00007d3d957e1fa3  jmp 0x00007D3D957E1ECA
00007d3d957e1fa8  vxorps xmm0, xmm1, xmm15
00007d3d957e1fad  pextrw eax, xmm0, 0x03
00007d3d957e1fb2  and eax, 0x7FF8
00007d3d957e1fb7  cmp eax, 0x08
00007d3d957e1fba  jnz 0x00007D3D957E1ECA
00007d3d957e1fc0  movq rax, xmm15
00007d3d957e1fc5  shl rax, 0x0D
00007d3d957e1fc9  jbe 0x00007D3D957E1ECA
00007d3d957e1fcf  vorps xmm14, xmm15, [0x00007D3D953FE070]
00007d3d957e1fd7  jmp 0x00007D3D957E1ECA
00007d3d957e1fdc  int3
00007d3d957e1fdd  nop [rax], eax
00007d3d957e1fe0  mov rax, [r15+0x40]
00007d3d957e1fe4  lea r14, [rax+0x510]
00007d3d957e1feb  movaps xmm1, [r15+0x110]
00007d3d957e1ff3  movq rax, xmm1
00007d3d957e1ff8  mov [r13+r14*1], rax
00007d3d957e1ffd  mov rax, [r15+0xF0]
00007d3d957e2004  mov [r15+0x100], rax
00007d3d957e200b  jmp 0x00007D3D957CE5C0
00007d3d957e2010  int3
00007d3d957e2011  call 0x00007D3D956D5EB0
00007d3d957e2016  jmp 0x00007D3D957E1FFD
00007d3d957e201b  int3
00007d3d957e201c  nop [rax], eax
00007d3d957e2020  mov qword ptr [r15+0x100], 0x04
00007d3d957e202b  mov esi, 0x00
00007d3d957e2030  mov edx, 0x09
00007d3d957e2035  mov rdi, 0x7FFF1EB3B8F0
00007d3d957e203f  mov rax, 0x56C27CA1D970
00007d3d957e2049  call rax
00007d3d957e204b  cmp dword ptr [r15+0x318], 0x00
00007d3d957e2053  jnz 0x00007D3D955FE110
00007d3d957e2059  jmp 0x00007D3D955FE0A0
00007d3d957e205e  int3
00007d3d957e205f  int3
