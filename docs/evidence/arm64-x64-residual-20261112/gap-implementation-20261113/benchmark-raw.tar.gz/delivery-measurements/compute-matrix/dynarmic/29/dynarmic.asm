000077a70fdce69b  nop [rax+rax*1], eax
000077a70fdce6a0  vmovaps xmm1, [0x000077A70F9FE010]
000077a70fdce6a8  movq xmm1, xmm1
000077a70fdce6ac  movaps [r15+0x110], xmm1
000077a70fdce6b4  vmovaps xmm1, [0x000077A70F9FE020]
000077a70fdce6bc  movq xmm1, xmm1
000077a70fdce6c0  movaps [r15+0x120], xmm1
000077a70fdce6c8  mov eax, 0x4204C0
000077a70fdce6cd  mov r14, [r13+rax*1]
000077a70fdce6d2  movq xmm1, r14
000077a70fdce6d7  movaps [r15+0x130], xmm1
000077a70fdce6df  vmovaps xmm1, [0x000077A70F9FE030]
000077a70fdce6e7  vpbroadcastq xmm1, xmm1
000077a70fdce6ec  movaps [r15+0x140], xmm1
000077a70fdce6f4  mov qword ptr [r15+0x40], 0x02
000077a70fdce6fc  vmovaps xmm15, [0x000077A70F9FE040]
000077a70fdce704  movq xmm15, xmm15
000077a70fdce709  movaps [r15+0x150], xmm15
000077a70fdce711  mov qword ptr [r15+0x58], 0x420000
000077a70fdce719  vmovaps xmm15, [0x000077A70F9FE050]
000077a70fdce721  vpbroadcastq xmm15, xmm15
000077a70fdce726  movaps [r15+0x160], xmm15
000077a70fdce72e  mov rax, [r15+0x40]
000077a70fdce732  vmovq xmm14, rax
000077a70fdce737  vpbroadcastq xmm14, xmm14
000077a70fdce73c  movaps [r15+0x170], xmm14
000077a70fdce744  mov eax, 0x4204D0
000077a70fdce749  movups xmm13, [r13+rax*1]
000077a70fdce74f  mov qword ptr [r15+0x40], 0x430518
000077a70fdce757  mov qword ptr [r15+0x50], 0x430720
000077a70fdce75f  vpmovqd xmm12, xmm13
000077a70fdce765  pxor xmm11, xmm11
000077a70fdce76a  punpcklqdq xmm12, xmm11
000077a70fdce76f  movaps [r15+0x210], xmm12
000077a70fdce777  movq xmm12, qword ptr [r15+0x120]
000077a70fdce780  movq xmm11, qword ptr [r15+0x130]
000077a70fdce789  psubd xmm12, xmm11
000077a70fdce78e  movq xmm12, xmm12
000077a70fdce793  paddq xmm13, xmm14
000077a70fdce798  movaps [r15+0x180], xmm13
000077a70fdce7a0  movq xmm14, qword ptr [r15+0x150]
000077a70fdce7a9  paddd xmm11, xmm14
000077a70fdce7ae  movq xmm11, xmm11
000077a70fdce7b3  movq xmm11, xmm11
000077a70fdce7b8  movaps [r15+0x130], xmm11
000077a70fdce7c0  pmovzxdq xmm12, xmm12
000077a70fdce7c6  psllq xmm12, 0x00
000077a70fdce7cc  movq xmm14, qword ptr [r15+0x210]
000077a70fdce7d5  movq xmm13, qword ptr [r15+0x110]
000077a70fdce7de  paddd xmm14, xmm13
000077a70fdce7e3  movq xmm14, xmm14
000077a70fdce7e8  vcvtuqq2pd xmm12, xmm12
000077a70fdce7ee  pmovzxdq xmm14, xmm14
000077a70fdce7f4  psllq xmm14, 0x00
000077a70fdce7fa  vcvtuqq2pd xmm14, xmm14
000077a70fdce800  movaps xmm13, xmm12
000077a70fdce804  mulpd xmm13, xmm1
000077a70fdce809  vcmppd xmm11, xmm13, xmm13, 0x03
000077a70fdce80f  ptest xmm11, xmm11
000077a70fdce815  jnz 0x000077A70FDCE8FF
000077a70fdce81b  movaps [r15+0x220], xmm13
000077a70fdce823  mov eax, 0x430720
000077a70fdce828  movups [r13+rax*1], xmm13
000077a70fdce82e  movaps xmm1, xmm14
000077a70fdce832  mulpd xmm1, xmm15
000077a70fdce837  vcmppd xmm13, xmm1, xmm1, 0x03
000077a70fdce83c  ptest xmm13, xmm13
000077a70fdce842  jnz 0x000077A70FDCEA4C
000077a70fdce848  movaps [r15+0x210], xmm1
000077a70fdce850  mov eax, 0x430518
000077a70fdce855  movups [r13+rax*1], xmm1
000077a70fdce85b  mov qword ptr [r15+0x48], 0x10
000077a70fdce863  xor eax, eax
000077a70fdce865  mov r14d, 0x10
000077a70fdce86b  mov r12d, 0x200
000077a70fdce871  cmp r14, r12
000077a70fdce874  cmc
000077a70fdce875  lahf
000077a70fdce876  seto al
000077a70fdce879  mov [r15+0x108], eax
000077a70fdce880  mov eax, [r15+0x108]
000077a70fdce887  sahf
000077a70fdce888  jnz 0x000077A70FDCE8BA
000077a70fdce88a  cmp dword ptr [r15+0x318], 0x00
000077a70fdce892  jz 0x000077A70FDCEFF0
000077a70fdce898  nop [rax+rax*1], ax
000077a70fdce8a1  nop [rax+rax*1], eax
000077a70fdce8a9  mov eax, 0x4101EC
000077a70fdce8ae  mov [r15+0x100], rax
000077a70fdce8b5  jmp 0x000077A70FBFE110
000077a70fdce8ba  cmp dword ptr [r15+0x318], 0x00
000077a70fdce8c2  jz 0x000077A70FDCEBA0
000077a70fdce8c8  nop [rax+rax*1], ax
000077a70fdce8d1  nop [rax+rax*1], eax
000077a70fdce8d9  mov eax, 0x4101AC
000077a70fdce8de  mov [r15+0x100], rax
000077a70fdce8e5  jmp 0x000077A70FBFE110
000077a70fdce8ea  int3
000077a70fdce8eb  call 0x000077A70FC0DC20
000077a70fdce8f0  jmp 0x000077A70FDCE6D2
000077a70fdce8f5  call 0x000077A70FC0C260
000077a70fdce8fa  jmp 0x000077A70FDCE74F
000077a70fdce8ff  sub rsp, 0x08
000077a70fdce903  push rax
000077a70fdce904  push rcx
000077a70fdce905  push rdx
000077a70fdce906  push rdi
000077a70fdce907  push rsi
000077a70fdce908  push r8
000077a70fdce90a  push r9
000077a70fdce90c  push r10
000077a70fdce90e  push r11
000077a70fdce910  sub rsp, 0xF0
000077a70fdce917  vmovaps [rsp], xmm0
000077a70fdce91c  vmovaps [rsp+0x10], xmm1
000077a70fdce922  vmovaps [rsp+0x20], xmm2
000077a70fdce928  vmovaps [rsp+0x30], xmm3
000077a70fdce92e  vmovaps [rsp+0x40], xmm4
000077a70fdce934  vmovaps [rsp+0x50], xmm5
000077a70fdce93a  vmovaps [rsp+0x60], xmm6
000077a70fdce940  vmovaps [rsp+0x70], xmm7
000077a70fdce946  vmovaps [rsp+0x80], xmm8
000077a70fdce94f  vmovaps [rsp+0x90], xmm9
000077a70fdce958  vmovaps [rsp+0xA0], xmm10
000077a70fdce961  vmovaps [rsp+0xB0], xmm11
000077a70fdce96a  vmovaps [rsp+0xC0], xmm12
000077a70fdce973  vmovaps [rsp+0xD0], xmm14
000077a70fdce97c  vmovaps [rsp+0xE0], xmm15
000077a70fdce985  sub rsp, 0x30
000077a70fdce989  movaps [rsp], xmm13
000077a70fdce98e  movaps [rsp+0x10], xmm12
000077a70fdce994  movaps [rsp+0x20], xmm1
000077a70fdce999  lea rdi, [rsp]
000077a70fdce99d  mov esi, 0x00
000077a70fdce9a2  mov rax, 0x6294188EF530
000077a70fdce9ac  call rax
000077a70fdce9ae  movaps xmm13, [rsp]
000077a70fdce9b3  add rsp, 0x30
000077a70fdce9b7  vmovaps xmm0, [rsp]
000077a70fdce9bc  vmovaps xmm1, [rsp+0x10]
000077a70fdce9c2  vmovaps xmm2, [rsp+0x20]
000077a70fdce9c8  vmovaps xmm3, [rsp+0x30]
000077a70fdce9ce  vmovaps xmm4, [rsp+0x40]
000077a70fdce9d4  vmovaps xmm5, [rsp+0x50]
000077a70fdce9da  vmovaps xmm6, [rsp+0x60]
000077a70fdce9e0  vmovaps xmm7, [rsp+0x70]
000077a70fdce9e6  vmovaps xmm8, [rsp+0x80]
000077a70fdce9ef  vmovaps xmm9, [rsp+0x90]
000077a70fdce9f8  vmovaps xmm10, [rsp+0xA0]
000077a70fdcea01  vmovaps xmm11, [rsp+0xB0]
000077a70fdcea0a  vmovaps xmm12, [rsp+0xC0]
000077a70fdcea13  vmovaps xmm14, [rsp+0xD0]
000077a70fdcea1c  vmovaps xmm15, [rsp+0xE0]
000077a70fdcea25  add rsp, 0xF0
000077a70fdcea2c  pop r11
000077a70fdcea2e  pop r10
000077a70fdcea30  pop r9
000077a70fdcea32  pop r8
000077a70fdcea34  pop rsi
000077a70fdcea35  pop rdi
000077a70fdcea36  pop rdx
000077a70fdcea37  pop rcx
000077a70fdcea38  pop rax
000077a70fdcea39  add rsp, 0x08
000077a70fdcea3d  jmp 0x000077A70FDCE81B
000077a70fdcea42  call 0x000077A70FC0C380
000077a70fdcea47  jmp 0x000077A70FDCE82E
000077a70fdcea4c  sub rsp, 0x08
000077a70fdcea50  push rax
000077a70fdcea51  push rcx
000077a70fdcea52  push rdx
000077a70fdcea53  push rdi
000077a70fdcea54  push rsi
000077a70fdcea55  push r8
000077a70fdcea57  push r9
000077a70fdcea59  push r10
000077a70fdcea5b  push r11
000077a70fdcea5d  sub rsp, 0xF0
000077a70fdcea64  vmovaps [rsp], xmm0
000077a70fdcea69  vmovaps [rsp+0x10], xmm2
000077a70fdcea6f  vmovaps [rsp+0x20], xmm3
000077a70fdcea75  vmovaps [rsp+0x30], xmm4
000077a70fdcea7b  vmovaps [rsp+0x40], xmm5
000077a70fdcea81  vmovaps [rsp+0x50], xmm6
000077a70fdcea87  vmovaps [rsp+0x60], xmm7
000077a70fdcea8d  vmovaps [rsp+0x70], xmm8
000077a70fdcea93  vmovaps [rsp+0x80], xmm9
000077a70fdcea9c  vmovaps [rsp+0x90], xmm10
000077a70fdceaa5  vmovaps [rsp+0xA0], xmm11
000077a70fdceaae  vmovaps [rsp+0xB0], xmm12
000077a70fdceab7  vmovaps [rsp+0xC0], xmm13
000077a70fdceac0  vmovaps [rsp+0xD0], xmm14
000077a70fdceac9  vmovaps [rsp+0xE0], xmm15
000077a70fdcead2  sub rsp, 0x30
000077a70fdcead6  movaps [rsp], xmm1
000077a70fdceada  movaps [rsp+0x10], xmm14
000077a70fdceae0  movaps [rsp+0x20], xmm15
000077a70fdceae6  lea rdi, [rsp]
000077a70fdceaea  mov esi, 0x00
000077a70fdceaef  mov rax, 0x6294188EF530
000077a70fdceaf9  call rax
000077a70fdceafb  movaps xmm1, [rsp]
000077a70fdceaff  add rsp, 0x30
000077a70fdceb03  vmovaps xmm0, [rsp]
000077a70fdceb08  vmovaps xmm2, [rsp+0x10]
000077a70fdceb0e  vmovaps xmm3, [rsp+0x20]
000077a70fdceb14  vmovaps xmm4, [rsp+0x30]
000077a70fdceb1a  vmovaps xmm5, [rsp+0x40]
000077a70fdceb20  vmovaps xmm6, [rsp+0x50]
000077a70fdceb26  vmovaps xmm7, [rsp+0x60]
000077a70fdceb2c  vmovaps xmm8, [rsp+0x70]
000077a70fdceb32  vmovaps xmm9, [rsp+0x80]
000077a70fdceb3b  vmovaps xmm10, [rsp+0x90]
000077a70fdceb44  vmovaps xmm11, [rsp+0xA0]
000077a70fdceb4d  vmovaps xmm12, [rsp+0xB0]
000077a70fdceb56  vmovaps xmm13, [rsp+0xC0]
000077a70fdceb5f  vmovaps xmm14, [rsp+0xD0]
000077a70fdceb68  vmovaps xmm15, [rsp+0xE0]
000077a70fdceb71  add rsp, 0xF0
000077a70fdceb78  pop r11
000077a70fdceb7a  pop r10
000077a70fdceb7c  pop r9
000077a70fdceb7e  pop r8
000077a70fdceb80  pop rsi
000077a70fdceb81  pop rdi
000077a70fdceb82  pop rdx
000077a70fdceb83  pop rcx
000077a70fdceb84  pop rax
000077a70fdceb85  add rsp, 0x08
000077a70fdceb89  jmp 0x000077A70FDCE848
000077a70fdceb8e  call 0x000077A70FBFF540
000077a70fdceb93  jmp 0x000077A70FDCE85B
000077a70fdceb98  int3
000077a70fdceb99  nop [rax], eax
000077a70fdceba0  movaps xmm1, [r15+0x180]
000077a70fdceba8  vpmovqd xmm15, xmm1
000077a70fdcebae  pxor xmm14, xmm14
000077a70fdcebb3  punpcklqdq xmm15, xmm14
000077a70fdcebb8  movaps [r15+0x210], xmm15
000077a70fdcebc0  movq xmm15, qword ptr [r15+0x120]
000077a70fdcebc9  movq xmm14, qword ptr [r15+0x130]
000077a70fdcebd2  psubd xmm15, xmm14
000077a70fdcebd7  movq xmm15, xmm15
000077a70fdcebdc  movaps xmm13, [r15+0x170]
000077a70fdcebe4  paddq xmm1, xmm13
000077a70fdcebe9  movaps [r15+0x180], xmm1
000077a70fdcebf1  movq xmm1, qword ptr [r15+0x150]
000077a70fdcebfa  paddd xmm14, xmm1
000077a70fdcebff  movq xmm14, xmm14
000077a70fdcec04  movq xmm14, xmm14
000077a70fdcec09  movaps [r15+0x130], xmm14
000077a70fdcec11  pmovzxdq xmm15, xmm15
000077a70fdcec17  psllq xmm15, 0x00
000077a70fdcec1d  movq xmm1, qword ptr [r15+0x210]
000077a70fdcec26  movq xmm14, qword ptr [r15+0x110]
000077a70fdcec2f  paddd xmm1, xmm14
000077a70fdcec34  movq xmm1, xmm1
000077a70fdcec38  vcvtuqq2pd xmm15, xmm15
000077a70fdcec3e  pmovzxdq xmm1, xmm1
000077a70fdcec43  psllq xmm1, 0x00
000077a70fdcec48  vcvtuqq2pd xmm1, xmm1
000077a70fdcec4e  movaps xmm14, [r15+0x140]
000077a70fdcec56  movaps xmm13, xmm15
000077a70fdcec5a  mulpd xmm13, xmm14
000077a70fdcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000077a70fdcec65  ptest xmm12, xmm12
000077a70fdcec6b  jnz 0x000077A70FDCED4E
000077a70fdcec71  movaps [r15+0x220], xmm13
000077a70fdcec79  mov rax, [r15+0x48]
000077a70fdcec7d  mov r14, [r15+0x50]
000077a70fdcec81  lea r12, [r14+rax*1]
000077a70fdcec85  movups [r13+r12*1], xmm13
000077a70fdcec8b  movaps xmm15, [r15+0x160]
000077a70fdcec93  movaps xmm14, xmm1
000077a70fdcec97  mulpd xmm14, xmm15
000077a70fdcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000077a70fdceca2  ptest xmm13, xmm13
000077a70fdceca8  jnz 0x000077A70FDCEE9C
000077a70fdcecae  movaps [r15+0x210], xmm14
000077a70fdcecb6  mov r14, [r15+0x40]
000077a70fdcecba  lea r12, [r14+rax*1]
000077a70fdcecbe  movups [r13+r12*1], xmm14
000077a70fdcecc4  lea r14, [rax+0x10]
000077a70fdcecc8  mov [r15+0x48], r14
000077a70fdceccc  xor eax, eax
000077a70fdcecce  mov r12d, 0x200
000077a70fdcecd4  cmp r14, r12
000077a70fdcecd7  cmc
000077a70fdcecd8  lahf
000077a70fdcecd9  seto al
000077a70fdcecdc  mov [r15+0x108], eax
000077a70fdcece3  mov eax, [r15+0x108]
000077a70fdcecea  sahf
000077a70fdceceb  jnz 0x000077A70FDCED1D
000077a70fdceced  cmp dword ptr [r15+0x318], 0x00
000077a70fdcecf5  jz 0x000077A70FDCEFF0
000077a70fdcecfb  nop [rax+rax*1], ax
000077a70fdced04  nop [rax+rax*1], eax
000077a70fdced0c  mov eax, 0x4101EC
000077a70fdced11  mov [r15+0x100], rax
000077a70fdced18  jmp 0x000077A70FBFE110
000077a70fdced1d  cmp dword ptr [r15+0x318], 0x00
000077a70fdced25  jz 0x000077A70FDCEBA0
000077a70fdced2b  nop [rax+rax*1], ax
000077a70fdced34  nop [rax+rax*1], eax
000077a70fdced3c  mov eax, 0x4101AC
000077a70fdced41  mov [r15+0x100], rax
000077a70fdced48  jmp 0x000077A70FBFE110
000077a70fdced4d  int3
000077a70fdced4e  sub rsp, 0x08
000077a70fdced52  push rax
000077a70fdced53  push rcx
000077a70fdced54  push rdx
000077a70fdced55  push rdi
000077a70fdced56  push rsi
000077a70fdced57  push r8
000077a70fdced59  push r9
000077a70fdced5b  push r10
000077a70fdced5d  push r11
000077a70fdced5f  sub rsp, 0xF0
000077a70fdced66  vmovaps [rsp], xmm0
000077a70fdced6b  vmovaps [rsp+0x10], xmm1
000077a70fdced71  vmovaps [rsp+0x20], xmm2
000077a70fdced77  vmovaps [rsp+0x30], xmm3
000077a70fdced7d  vmovaps [rsp+0x40], xmm4
000077a70fdced83  vmovaps [rsp+0x50], xmm5
000077a70fdced89  vmovaps [rsp+0x60], xmm6
000077a70fdced8f  vmovaps [rsp+0x70], xmm7
000077a70fdced95  vmovaps [rsp+0x80], xmm8
000077a70fdced9e  vmovaps [rsp+0x90], xmm9
000077a70fdceda7  vmovaps [rsp+0xA0], xmm10
000077a70fdcedb0  vmovaps [rsp+0xB0], xmm11
000077a70fdcedb9  vmovaps [rsp+0xC0], xmm12
000077a70fdcedc2  vmovaps [rsp+0xD0], xmm14
000077a70fdcedcb  vmovaps [rsp+0xE0], xmm15
000077a70fdcedd4  sub rsp, 0x30
000077a70fdcedd8  movaps [rsp], xmm13
000077a70fdceddd  movaps [rsp+0x10], xmm15
000077a70fdcede3  movaps [rsp+0x20], xmm14
000077a70fdcede9  lea rdi, [rsp]
000077a70fdceded  mov esi, 0x00
000077a70fdcedf2  mov rax, 0x6294188EF530
000077a70fdcedfc  call rax
000077a70fdcedfe  movaps xmm13, [rsp]
000077a70fdcee03  add rsp, 0x30
000077a70fdcee07  vmovaps xmm0, [rsp]
000077a70fdcee0c  vmovaps xmm1, [rsp+0x10]
000077a70fdcee12  vmovaps xmm2, [rsp+0x20]
000077a70fdcee18  vmovaps xmm3, [rsp+0x30]
000077a70fdcee1e  vmovaps xmm4, [rsp+0x40]
000077a70fdcee24  vmovaps xmm5, [rsp+0x50]
000077a70fdcee2a  vmovaps xmm6, [rsp+0x60]
000077a70fdcee30  vmovaps xmm7, [rsp+0x70]
000077a70fdcee36  vmovaps xmm8, [rsp+0x80]
000077a70fdcee3f  vmovaps xmm9, [rsp+0x90]
000077a70fdcee48  vmovaps xmm10, [rsp+0xA0]
000077a70fdcee51  vmovaps xmm11, [rsp+0xB0]
000077a70fdcee5a  vmovaps xmm12, [rsp+0xC0]
000077a70fdcee63  vmovaps xmm14, [rsp+0xD0]
000077a70fdcee6c  vmovaps xmm15, [rsp+0xE0]
000077a70fdcee75  add rsp, 0xF0
000077a70fdcee7c  pop r11
000077a70fdcee7e  pop r10
000077a70fdcee80  pop r9
000077a70fdcee82  pop r8
000077a70fdcee84  pop rsi
000077a70fdcee85  pop rdi
000077a70fdcee86  pop rdx
000077a70fdcee87  pop rcx
000077a70fdcee88  pop rax
000077a70fdcee89  add rsp, 0x08
000077a70fdcee8d  jmp 0x000077A70FDCEC71
000077a70fdcee92  call 0x000077A70FCC2240
000077a70fdcee97  jmp 0x000077A70FDCEC8B
000077a70fdcee9c  sub rsp, 0x08
000077a70fdceea0  push rax
000077a70fdceea1  push rcx
000077a70fdceea2  push rdx
000077a70fdceea3  push rdi
000077a70fdceea4  push rsi
000077a70fdceea5  push r8
000077a70fdceea7  push r9
000077a70fdceea9  push r10
000077a70fdceeab  push r11
000077a70fdceead  sub rsp, 0xF0
000077a70fdceeb4  vmovaps [rsp], xmm0
000077a70fdceeb9  vmovaps [rsp+0x10], xmm1
000077a70fdceebf  vmovaps [rsp+0x20], xmm2
000077a70fdceec5  vmovaps [rsp+0x30], xmm3
000077a70fdceecb  vmovaps [rsp+0x40], xmm4
000077a70fdceed1  vmovaps [rsp+0x50], xmm5
000077a70fdceed7  vmovaps [rsp+0x60], xmm6
000077a70fdceedd  vmovaps [rsp+0x70], xmm7
000077a70fdceee3  vmovaps [rsp+0x80], xmm8
000077a70fdceeec  vmovaps [rsp+0x90], xmm9
000077a70fdceef5  vmovaps [rsp+0xA0], xmm10
000077a70fdceefe  vmovaps [rsp+0xB0], xmm11
000077a70fdcef07  vmovaps [rsp+0xC0], xmm12
000077a70fdcef10  vmovaps [rsp+0xD0], xmm13
000077a70fdcef19  vmovaps [rsp+0xE0], xmm15
000077a70fdcef22  sub rsp, 0x30
000077a70fdcef26  movaps [rsp], xmm14
000077a70fdcef2b  movaps [rsp+0x10], xmm1
000077a70fdcef30  movaps [rsp+0x20], xmm15
000077a70fdcef36  lea rdi, [rsp]
000077a70fdcef3a  mov esi, 0x00
000077a70fdcef3f  mov rax, 0x6294188EF530
000077a70fdcef49  call rax
000077a70fdcef4b  movaps xmm14, [rsp]
000077a70fdcef50  add rsp, 0x30
000077a70fdcef54  vmovaps xmm0, [rsp]
000077a70fdcef59  vmovaps xmm1, [rsp+0x10]
000077a70fdcef5f  vmovaps xmm2, [rsp+0x20]
000077a70fdcef65  vmovaps xmm3, [rsp+0x30]
000077a70fdcef6b  vmovaps xmm4, [rsp+0x40]
000077a70fdcef71  vmovaps xmm5, [rsp+0x50]
000077a70fdcef77  vmovaps xmm6, [rsp+0x60]
000077a70fdcef7d  vmovaps xmm7, [rsp+0x70]
000077a70fdcef83  vmovaps xmm8, [rsp+0x80]
000077a70fdcef8c  vmovaps xmm9, [rsp+0x90]
000077a70fdcef95  vmovaps xmm10, [rsp+0xA0]
000077a70fdcef9e  vmovaps xmm11, [rsp+0xB0]
000077a70fdcefa7  vmovaps xmm12, [rsp+0xC0]
000077a70fdcefb0  vmovaps xmm13, [rsp+0xD0]
000077a70fdcefb9  vmovaps xmm15, [rsp+0xE0]
000077a70fdcefc2  add rsp, 0xF0
000077a70fdcefc9  pop r11
000077a70fdcefcb  pop r10
000077a70fdcefcd  pop r9
000077a70fdcefcf  pop r8
000077a70fdcefd1  pop rsi
000077a70fdcefd2  pop rdi
000077a70fdcefd3  pop rdx
000077a70fdcefd4  pop rcx
000077a70fdcefd5  pop rax
000077a70fdcefd6  add rsp, 0x08
000077a70fdcefda  jmp 0x000077A70FDCECAE
000077a70fdcefdf  call 0x000077A70FCC34C0
000077a70fdcefe4  jmp 0x000077A70FDCECC4
000077a70fdcefe9  int3
000077a70fdcefea  nop [rax+rax*1], ax
000077a70fdceff0  mov rax, [r15+0xF8]
000077a70fdceff7  lea r14, [rax-0x150]
000077a70fdceffe  mov [r15+0xF8], r14
000077a70fdcf005  mov rax, [r15+0x50]
000077a70fdcf009  lea r12, [rax+0x80]
000077a70fdcf010  movups xmm1, [r13+r12*1]
000077a70fdcf016  lea r12, [rax+0x90]
000077a70fdcf01d  movups xmm15, [r13+r12*1]
000077a70fdcf023  mov qword ptr [r15+0x48], 0x00
000077a70fdcf02b  lea r12, [rax+0x40]
000077a70fdcf02f  movups xmm14, [r13+r12*1]
000077a70fdcf035  lea r12, [rax+0x50]
000077a70fdcf039  movups xmm13, [r13+r12*1]
000077a70fdcf03f  lea r12, [r14+0x120]
000077a70fdcf046  movq xmm12, qword ptr [r15+0x1C0]
000077a70fdcf04f  movq xmm11, qword ptr [r15+0x1B0]
000077a70fdcf058  movq r11, xmm12
000077a70fdcf05d  movq r10, xmm11
000077a70fdcf062  mov [r13+r12*1], r11
000077a70fdcf067  lea r12, [r14+0x128]
000077a70fdcf06e  mov [r13+r12*1], r10
000077a70fdcf073  vxorps xmm12, xmm12, xmm12
000077a70fdcf078  vpbroadcastq xmm12, xmm12
000077a70fdcf07d  lea r12, [r14+0x100]
000077a70fdcf084  movq xmm11, qword ptr [r15+0x200]
000077a70fdcf08d  movq xmm10, qword ptr [r15+0x1F0]
000077a70fdcf096  movq r11, xmm11
000077a70fdcf09b  movq r10, xmm10
000077a70fdcf0a0  mov [r13+r12*1], r11
000077a70fdcf0a5  lea r12, [r14+0x108]
000077a70fdcf0ac  mov [r13+r12*1], r10
000077a70fdcf0b1  lea r12, [r14+0xE0]
000077a70fdcf0b8  movups [r13+r12*1], xmm15
000077a70fdcf0be  lea r12, [r14+0xF0]
000077a70fdcf0c5  movups [r13+r12*1], xmm1
000077a70fdcf0cb  lea r12, [rax+0xC0]
000077a70fdcf0d2  movups xmm1, [r13+r12*1]
000077a70fdcf0d8  lea r12, [rax+0xD0]
000077a70fdcf0df  movups xmm15, [r13+r12*1]
000077a70fdcf0e5  lea r12, [r14+0x110]
000077a70fdcf0ec  movq xmm11, qword ptr [r15+0x1E0]
000077a70fdcf0f5  movq xmm10, qword ptr [r15+0x1D0]
000077a70fdcf0fe  movq r11, xmm11
000077a70fdcf103  movq r10, xmm10
000077a70fdcf108  mov [r13+r12*1], r11
000077a70fdcf10d  lea r12, [r14+0x118]
000077a70fdcf114  mov [r13+r12*1], r10
000077a70fdcf119  movups xmm11, [r13+rax*1]
000077a70fdcf11f  lea r12, [rax+0x10]
000077a70fdcf123  movups xmm10, [r13+r12*1]
000077a70fdcf129  lea r12, [r14+0x130]
000077a70fdcf130  movq xmm9, qword ptr [r15+0x1A0]
000077a70fdcf139  movq xmm8, qword ptr [r15+0x190]
000077a70fdcf142  movq r11, xmm9
000077a70fdcf147  movq r10, xmm8
000077a70fdcf14c  mov [r13+r12*1], r11
000077a70fdcf151  lea r12, [r14+0x138]
000077a70fdcf158  mov [r13+r12*1], r10
000077a70fdcf15d  lea r12, [rax+0x140]
000077a70fdcf164  movups xmm9, [r13+r12*1]
000077a70fdcf16a  lea r12, [rax+0x150]
000077a70fdcf171  movups xmm8, [r13+r12*1]
000077a70fdcf177  lea r12, [r14+0xC0]
000077a70fdcf17e  movups [r13+r12*1], xmm15
000077a70fdcf184  lea r12, [r14+0xD0]
000077a70fdcf18b  movups [r13+r12*1], xmm1
000077a70fdcf191  lea r12, [rax+0x100]
000077a70fdcf198  movups xmm1, [r13+r12*1]
000077a70fdcf19e  lea r12, [rax+0x110]
000077a70fdcf1a5  movups xmm15, [r13+r12*1]
000077a70fdcf1ab  lea r12, [r14+0x140]
000077a70fdcf1b2  mov r11, [r15+0xE8]
000077a70fdcf1b9  mov [r13+r12*1], r11
000077a70fdcf1be  lea r12, [rax+0x180]
000077a70fdcf1c5  movups xmm7, [r13+r12*1]
000077a70fdcf1cb  lea r12, [rax+0x190]
000077a70fdcf1d2  movups xmm6, [r13+r12*1]
000077a70fdcf1d8  lea r12, [rax+0x1C0]
000077a70fdcf1df  movups xmm5, [r13+r12*1]
000077a70fdcf1e5  lea r12, [rax+0x1D0]
000077a70fdcf1ec  movups xmm4, [r13+r12*1]
000077a70fdcf1f2  lea r12, [r14+0x20]
000077a70fdcf1f6  movups [r13+r12*1], xmm1
000077a70fdcf1fc  lea r12, [r14+0x30]
000077a70fdcf200  movups [r13+r12*1], xmm13
000077a70fdcf206  lea r12, [rax+0x60]
000077a70fdcf20a  movups xmm1, [r13+r12*1]
000077a70fdcf210  lea r12, [rax+0x70]
000077a70fdcf214  movups xmm13, [r13+r12*1]
000077a70fdcf21a  lea r12, [rax+0x20]
000077a70fdcf21e  movups xmm3, [r13+r12*1]
000077a70fdcf224  lea r12, [rax+0x30]
000077a70fdcf228  movups xmm2, [r13+r12*1]
000077a70fdcf22e  movaps [r15+0x1F0], xmm2
000077a70fdcf236  lea r12, [r14+0x60]
000077a70fdcf23a  movups [r13+r12*1], xmm11
000077a70fdcf240  lea r12, [r14+0x70]
000077a70fdcf244  movups [r13+r12*1], xmm5
000077a70fdcf24a  lea r12, [rax+0xE0]
000077a70fdcf251  movups xmm11, [r13+r12*1]
000077a70fdcf257  lea r12, [rax+0xF0]
000077a70fdcf25e  movups xmm5, [r13+r12*1]
000077a70fdcf264  lea r12, [r14+0xA0]
000077a70fdcf26b  movups [r13+r12*1], xmm13
000077a70fdcf271  lea r12, [r14+0xB0]
000077a70fdcf278  movups [r13+r12*1], xmm1
000077a70fdcf27e  lea r12, [rax+0xA0]
000077a70fdcf285  movups xmm1, [r13+r12*1]
000077a70fdcf28b  lea r12, [rax+0xB0]
000077a70fdcf292  movups xmm13, [r13+r12*1]
000077a70fdcf298  lea r12, [rax+0x120]
000077a70fdcf29f  vmovaps [rsp+0x10], xmm1
000077a70fdcf2a5  movups xmm1, [r13+r12*1]
000077a70fdcf2ab  lea r12, [rax+0x130]
000077a70fdcf2b2  vmovaps [rsp+0x20], xmm1
000077a70fdcf2b8  movups xmm1, [r13+r12*1]
000077a70fdcf2be  lea r12, [rax+0x160]
000077a70fdcf2c5  vmovaps [rsp+0x30], xmm1
000077a70fdcf2cb  movups xmm1, [r13+r12*1]
000077a70fdcf2d1  lea r12, [rax+0x170]
000077a70fdcf2d8  vmovaps [rsp+0x40], xmm1
000077a70fdcf2de  movups xmm1, [r13+r12*1]
000077a70fdcf2e4  movaps [r15+0x2B0], xmm1
000077a70fdcf2ec  lea r12, [r14+0x80]
000077a70fdcf2f3  movups [r13+r12*1], xmm13
000077a70fdcf2f9  lea r12, [r14+0x90]
000077a70fdcf300  vmovaps xmm13, [rsp+0x10]
000077a70fdcf306  movups [r13+r12*1], xmm13
000077a70fdcf30c  lea r12, [rax+0x1A0]
000077a70fdcf313  movups xmm13, [r13+r12*1]
000077a70fdcf319  lea r12, [rax+0x1B0]
000077a70fdcf320  vmovaps [rsp+0x10], xmm1
000077a70fdcf326  movups xmm1, [r13+r12*1]
000077a70fdcf32c  movaps [r15+0x290], xmm13
000077a70fdcf334  movaps [r15+0x1E0], xmm1
000077a70fdcf33c  lea r12, [rax+0x1E0]
000077a70fdcf343  vmovaps [rsp+0x50], xmm1
000077a70fdcf349  movups xmm1, [r13+r12*1]
000077a70fdcf34f  lea r12, [rax+0x1F0]
000077a70fdcf356  vmovaps [rsp+0x60], xmm1
000077a70fdcf35c  movups xmm1, [r13+r12*1]
000077a70fdcf362  mov qword ptr [r15+0x50], 0x430920
000077a70fdcf36a  lea rax, [r14+0x40]
000077a70fdcf36e  vmovaps [rsp+0x70], xmm1
000077a70fdcf374  vmovaps xmm1, [rsp+0x40]
000077a70fdcf37a  movups [r13+rax*1], xmm1
000077a70fdcf380  lea rax, [r14+0x50]
000077a70fdcf384  movups [r13+rax*1], xmm10
000077a70fdcf38a  vmovaps xmm1, [rsp+0x70]
000077a70fdcf390  movups [r13+r14*1], xmm1
000077a70fdcf396  lea rax, [r14+0x10]
000077a70fdcf39a  vmovaps xmm1, [rsp+0x60]
000077a70fdcf3a0  movups [r13+rax*1], xmm1
000077a70fdcf3a6  mov rax, [r15+0x40]
000077a70fdcf3aa  vmovaps [rsp+0x40], xmm3
000077a70fdcf3b0  vmovaps xmm1, [rsp+0x40]
000077a70fdcf3b6  por xmm3, xmm1
000077a70fdcf3ba  vmovaps [rsp+0x40], xmm6
000077a70fdcf3c0  vmovaps xmm10, [rsp+0x40]
000077a70fdcf3c6  por xmm6, xmm10
000077a70fdcf3cb  lea r12, [rax+0x30]
000077a70fdcf3cf  mov r11, [r13+r12*1]
000077a70fdcf3d4  lea r12, [rax+0x38]
000077a70fdcf3d8  mov r10, [r13+r12*1]
000077a70fdcf3dd  movq xmm10, r11
000077a70fdcf3e2  vmovaps [rsp+0x40], xmm1
000077a70fdcf3e8  movq xmm1, r10
000077a70fdcf3ed  movq xmm10, xmm10
000077a70fdcf3f2  vmovaps [rsp+0x60], xmm10
000077a70fdcf3f8  movq xmm10, xmm10
000077a70fdcf3fd  movaps [r15+0x130], xmm10
000077a70fdcf405  movq xmm1, xmm1
000077a70fdcf409  vmovaps [rsp+0x70], xmm1
000077a70fdcf40f  movq xmm1, xmm1
000077a70fdcf413  movaps [r15+0x280], xmm1
000077a70fdcf41b  vmovaps [rsp+0x80], xmm9
000077a70fdcf424  vmovaps xmm1, [rsp+0x80]
000077a70fdcf42d  por xmm9, xmm1
000077a70fdcf432  lea r12, [rax+0x20]
000077a70fdcf436  mov r11, [r13+r12*1]
000077a70fdcf43b  lea r12, [rax+0x28]
000077a70fdcf43f  mov r10, [r13+r12*1]
000077a70fdcf444  movq xmm1, r11
000077a70fdcf449  movq xmm10, r10
000077a70fdcf44e  movq xmm1, xmm1
000077a70fdcf452  vmovaps [rsp+0x80], xmm1
000077a70fdcf45b  movq xmm1, xmm1
000077a70fdcf45f  movaps [r15+0x150], xmm1
000077a70fdcf467  movq xmm10, xmm10
000077a70fdcf46c  vmovaps [rsp+0x90], xmm10
000077a70fdcf475  movq xmm10, xmm10
000077a70fdcf47a  movaps [r15+0x140], xmm10
000077a70fdcf482  lea r12, [rax+0x10]
000077a70fdcf486  mov r11, [r13+r12*1]
000077a70fdcf48b  lea r12, [rax+0x18]
000077a70fdcf48f  mov r10, [r13+r12*1]
000077a70fdcf494  movq xmm1, r11
000077a70fdcf499  movq xmm10, r10
000077a70fdcf49e  movq xmm1, xmm1
000077a70fdcf4a2  vmovaps [rsp+0xA0], xmm1
000077a70fdcf4ab  movq xmm1, xmm1
000077a70fdcf4af  movaps [r15+0x170], xmm1
000077a70fdcf4b7  movq xmm10, xmm10
000077a70fdcf4bc  vmovaps [rsp+0xB0], xmm10
000077a70fdcf4c5  movq xmm10, xmm10
000077a70fdcf4ca  movaps [r15+0x160], xmm10
000077a70fdcf4d2  mov r12, [r13+rax*1]
000077a70fdcf4d7  vmovq xmm1, r12
000077a70fdcf4dc  vpbroadcastq xmm1, xmm1
000077a70fdcf4e1  lea r12, [rax+0x08]
000077a70fdcf4e5  mov rax, [r13+r12*1]
000077a70fdcf4ea  movq xmm10, rax
000077a70fdcf4ef  movaps [r15+0x230], xmm10
000077a70fdcf4f7  lea rax, [r14+0x50]
000077a70fdcf4fb  movups xmm10, [r13+rax*1]
000077a70fdcf501  lea rax, [r14+0x60]
000077a70fdcf505  vmovaps [rsp+0xC0], xmm1
000077a70fdcf50e  movups xmm1, [r13+rax*1]
000077a70fdcf514  lea rax, [r14+0x30]
000077a70fdcf518  vmovaps [rsp+0xD0], xmm1
000077a70fdcf521  movups xmm1, [r13+rax*1]
000077a70fdcf527  mov qword ptr [r15+0x60], 0x430920
000077a70fdcf52f  mov qword ptr [r15+0x58], 0x40
000077a70fdcf537  vmovaps [rsp+0xE0], xmm1
000077a70fdcf540  vmovaps [rsp+0xF0], xmm15
000077a70fdcf549  vmovaps xmm15, [rsp+0xC0]
000077a70fdcf552  vmovaps [rsp+0xC0], xmm14
000077a70fdcf55b  vmovaps xmm14, [rsp+0x40]
000077a70fdcf561  vmovaps [rsp+0x40], xmm13
000077a70fdcf567  movaps xmm1, xmm15
000077a70fdcf56b  mulpd xmm1, xmm14
000077a70fdcf570  vcmppd xmm13, xmm1, xmm1, 0x03
000077a70fdcf575  ptest xmm13, xmm13
000077a70fdcf57b  jnz 0x000077A70FDD0682
000077a70fdcf581  movq xmm14, qword ptr [r15+0x230]
000077a70fdcf58a  vmovaps [rsp+0x100], xmm14
000077a70fdcf593  vpermilpd xmm14, xmm14, 0x00
000077a70fdcf599  vmovaps [rsp+0x110], xmm1
000077a70fdcf5a2  vmovaps xmm1, [rsp+0xE0]
000077a70fdcf5ab  vmovaps [rsp+0xE0], xmm15
000077a70fdcf5b4  movaps xmm13, xmm1
000077a70fdcf5b8  mulpd xmm13, xmm14
000077a70fdcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000077a70fdcf5c3  ptest xmm15, xmm15
000077a70fdcf5c9  jnz 0x000077A70FDD07C4
000077a70fdcf5cf  vxorps xmm1, xmm1, xmm1
000077a70fdcf5d3  vpbroadcastq xmm1, xmm1
000077a70fdcf5d8  vmovaps xmm14, [rsp+0xE0]
000077a70fdcf5e1  vmovaps [rsp+0xE0], xmm1
000077a70fdcf5ea  vmovaps xmm1, [rsp+0xD0]
000077a70fdcf5f3  vmovaps [rsp+0xD0], xmm13
000077a70fdcf5fc  movaps xmm15, xmm14
000077a70fdcf600  mulpd xmm15, xmm1
000077a70fdcf605  vcmppd xmm13, xmm15, xmm15, 0x03
000077a70fdcf60b  ptest xmm13, xmm13
000077a70fdcf611  jnz 0x000077A70FDD0907
000077a70fdcf617  movaps xmm1, xmm14
000077a70fdcf61b  mulpd xmm1, xmm10
000077a70fdcf620  vcmppd xmm13, xmm1, xmm1, 0x03
000077a70fdcf625  ptest xmm13, xmm13
000077a70fdcf62b  jnz 0x000077A70FDD0A4A
000077a70fdcf631  movaps xmm13, xmm14
000077a70fdcf635  mulpd xmm13, xmm2
000077a70fdcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000077a70fdcf640  ptest xmm10, xmm10
000077a70fdcf646  jnz 0x000077A70FDD0B8C
000077a70fdcf64c  vmovaps [rsp+0x120], xmm7
000077a70fdcf655  vmovaps xmm14, [rsp+0x120]
000077a70fdcf65e  por xmm7, xmm14
000077a70fdcf663  vmovaps xmm14, [rsp+0xC0]
000077a70fdcf66c  vmovaps xmm10, [rsp+0xC0]
000077a70fdcf675  por xmm14, xmm10
000077a70fdcf67a  vmovaps xmm2, [rsp+0x100]
000077a70fdcf683  vpermilpd xmm2, xmm2, 0x00
000077a70fdcf689  vmovaps [rsp+0xC0], xmm1
000077a70fdcf692  vmovaps [rsp+0x120], xmm15
000077a70fdcf69b  movaps xmm1, xmm10
000077a70fdcf69f  mulpd xmm1, xmm2
000077a70fdcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000077a70fdcf6a8  ptest xmm15, xmm15
000077a70fdcf6ae  jnz 0x000077A70FDD0CCF
000077a70fdcf6b4  xor eax, eax
000077a70fdcf6b6  mov r12d, 0x40
000077a70fdcf6bc  mov r11d, 0x200
000077a70fdcf6c2  cmp r12, r11
000077a70fdcf6c5  cmc
000077a70fdcf6c6  lahf
000077a70fdcf6c7  seto al
000077a70fdcf6ca  mov [r15+0x108], eax
000077a70fdcf6d1  vmovaps xmm10, [rsp+0x110]
000077a70fdcf6da  vmovaps xmm2, [rsp+0xE0]
000077a70fdcf6e3  vmovaps [rsp+0xE0], xmm1
000077a70fdcf6ec  movaps xmm15, xmm10
000077a70fdcf6f0  addpd xmm15, xmm2
000077a70fdcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000077a70fdcf6fb  ptest xmm1, xmm1
000077a70fdcf700  jnz 0x000077A70FDD0E10
000077a70fdcf706  vmovaps xmm10, [rsp+0x120]
000077a70fdcf70f  vmovaps [rsp+0x110], xmm15
000077a70fdcf718  movaps xmm1, xmm10
000077a70fdcf71c  addpd xmm1, xmm12
000077a70fdcf721  vcmppd xmm15, xmm1, xmm1, 0x03
000077a70fdcf726  ptest xmm15, xmm15
000077a70fdcf72c  jnz 0x000077A70FDD0F53
000077a70fdcf732  vmovaps xmm10, [rsp+0xC0]
000077a70fdcf73b  vmovaps [rsp+0xC0], xmm1
000077a70fdcf744  movaps xmm15, xmm10
000077a70fdcf748  addpd xmm15, xmm12
000077a70fdcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000077a70fdcf753  ptest xmm1, xmm1
000077a70fdcf758  jnz 0x000077A70FDD1095
000077a70fdcf75e  vmovaps xmm1, [rsp+0x30]
000077a70fdcf764  vmovaps xmm12, [rsp+0x30]
000077a70fdcf76a  por xmm1, xmm12
000077a70fdcf76f  vmovaps xmm12, [rsp+0x20]
000077a70fdcf775  vmovaps xmm10, [rsp+0x20]
000077a70fdcf77b  por xmm12, xmm10
000077a70fdcf780  vmovaps [rsp+0x20], xmm5
000077a70fdcf786  vmovaps xmm10, [rsp+0x20]
000077a70fdcf78c  por xmm5, xmm10
000077a70fdcf791  vmovaps [rsp+0x20], xmm11
000077a70fdcf797  vmovaps xmm10, [rsp+0x20]
000077a70fdcf79d  por xmm11, xmm10
000077a70fdcf7a2  vmovaps [rsp+0x20], xmm4
000077a70fdcf7a8  vmovaps xmm10, [rsp+0x20]
000077a70fdcf7ae  por xmm4, xmm10
000077a70fdcf7b3  vmovaps [rsp+0x20], xmm8
000077a70fdcf7b9  vmovaps xmm10, [rsp+0x20]
000077a70fdcf7bf  por xmm8, xmm10
000077a70fdcf7c4  vmovaps xmm10, [rsp+0xF0]
000077a70fdcf7cd  vmovaps [rsp+0x20], xmm1
000077a70fdcf7d3  vmovaps xmm1, [rsp+0xF0]
000077a70fdcf7dc  por xmm10, xmm1
000077a70fdcf7e1  lea rax, [r14+0xA0]
000077a70fdcf7e8  movups xmm1, [r13+rax*1]
000077a70fdcf7ee  lea rax, [r14+0xB0]
000077a70fdcf7f5  vmovaps [rsp+0x30], xmm1
000077a70fdcf7fb  movups xmm1, [r13+rax*1]
000077a70fdcf801  vmovaps [rsp+0xF0], xmm1
000077a70fdcf80a  vmovaps [rsp+0x120], xmm15
000077a70fdcf813  movaps xmm1, xmm13
000077a70fdcf817  addpd xmm1, xmm2
000077a70fdcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000077a70fdcf820  ptest xmm15, xmm15
000077a70fdcf826  jnz 0x000077A70FDD11ED
000077a70fdcf82c  lea rax, [r14+0xF0]
000077a70fdcf833  movups xmm15, [r13+rax*1]
000077a70fdcf839  vmovaps xmm2, [rsp+0xC0]
000077a70fdcf842  vmovaps [rsp+0xC0], xmm1
000077a70fdcf84b  vmovaps xmm1, [rsp+0xE0]
000077a70fdcf854  vmovaps [rsp+0xE0], xmm15
000077a70fdcf85d  movaps xmm13, xmm2
000077a70fdcf861  addpd xmm13, xmm1
000077a70fdcf866  vcmppd xmm15, xmm13, xmm13, 0x03
000077a70fdcf86c  ptest xmm15, xmm15
000077a70fdcf872  jnz 0x000077A70FDD1338
000077a70fdcf878  vmovaps xmm15, [rsp+0x120]
000077a70fdcf881  vmovaps xmm2, [rsp+0xD0]
000077a70fdcf88a  vmovaps [rsp+0xD0], xmm14
000077a70fdcf893  movaps xmm1, xmm15
000077a70fdcf897  addpd xmm1, xmm2
000077a70fdcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000077a70fdcf8a0  ptest xmm14, xmm14
000077a70fdcf8a6  jnz 0x000077A70FDD147A
000077a70fdcf8ac  vmovaps xmm15, [rsp+0x100]
000077a70fdcf8b5  vpermilpd xmm15, xmm15, 0x00
000077a70fdcf8bb  vmovaps xmm2, [rsp+0xF0]
000077a70fdcf8c4  vmovaps [rsp+0xF0], xmm1
000077a70fdcf8cd  movaps xmm14, xmm2
000077a70fdcf8d1  mulpd xmm14, xmm15
000077a70fdcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000077a70fdcf8dc  ptest xmm1, xmm1
000077a70fdcf8e1  jnz 0x000077A70FDD15BB
000077a70fdcf8e7  vmovaps xmm1, [rsp+0xA0]
000077a70fdcf8f0  vpermilpd xmm1, xmm1, 0x00
000077a70fdcf8f6  vmovaps xmm2, [rsp+0xE0]
000077a70fdcf8ff  vmovaps [rsp+0xE0], xmm14
000077a70fdcf908  movaps xmm15, xmm2
000077a70fdcf90c  mulpd xmm15, xmm1
000077a70fdcf911  vcmppd xmm14, xmm15, xmm15, 0x03
000077a70fdcf917  ptest xmm14, xmm14
000077a70fdcf91d  jnz 0x000077A70FDD16FE
000077a70fdcf923  lea rax, [r14+0xE0]
000077a70fdcf92a  movups xmm1, [r13+rax*1]
000077a70fdcf930  vmovaps xmm14, [rsp+0x100]
000077a70fdcf939  vpermilpd xmm14, xmm14, 0x00
000077a70fdcf93f  vmovaps [rsp+0x100], xmm1
000077a70fdcf948  vmovaps xmm1, [rsp+0x30]
000077a70fdcf94e  vmovaps [rsp+0x30], xmm15
000077a70fdcf954  movaps xmm2, xmm1
000077a70fdcf957  mulpd xmm2, xmm14
000077a70fdcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000077a70fdcf961  ptest xmm15, xmm15
000077a70fdcf967  jnz 0x000077A70FDD184A
000077a70fdcf96d  vmovaps [rsp+0x120], xmm10
000077a70fdcf976  vmovaps xmm1, [rsp+0x120]
000077a70fdcf97f  por xmm10, xmm1
000077a70fdcf984  movaps [r15+0x300], xmm10
000077a70fdcf98c  vmovaps [rsp+0x120], xmm8
000077a70fdcf995  vmovaps xmm1, [rsp+0x120]
000077a70fdcf99e  por xmm8, xmm1
000077a70fdcf9a3  movaps [r15+0x190], xmm8
000077a70fdcf9ab  vmovaps xmm1, [rsp+0xA0]
000077a70fdcf9b4  vpermilpd xmm1, xmm1, 0x00
000077a70fdcf9ba  vmovaps xmm14, [rsp+0x100]
000077a70fdcf9c3  vmovaps [rsp+0x100], xmm13
000077a70fdcf9cc  movaps xmm15, xmm14
000077a70fdcf9d0  mulpd xmm15, xmm1
000077a70fdcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000077a70fdcf9db  ptest xmm13, xmm13
000077a70fdcf9e1  jnz 0x000077A70FDD198B
000077a70fdcf9e7  lea rax, [r14+0x90]
000077a70fdcf9ee  movups xmm1, [r13+rax*1]
000077a70fdcf9f4  vmovaps [rsp+0x120], xmm4
000077a70fdcf9fd  vmovaps xmm14, [rsp+0x120]
000077a70fdcfa06  por xmm4, xmm14
000077a70fdcfa0b  movaps [r15+0x1C0], xmm4
000077a70fdcfa13  vmovaps [rsp+0x120], xmm11
000077a70fdcfa1c  vmovaps xmm14, [rsp+0x120]
000077a70fdcfa25  por xmm11, xmm14
000077a70fdcfa2a  movaps [r15+0x200], xmm11
000077a70fdcfa32  vmovaps [rsp+0x120], xmm5
000077a70fdcfa3b  vmovaps xmm14, [rsp+0x120]
000077a70fdcfa44  por xmm5, xmm14
000077a70fdcfa49  movaps [r15+0x2D0], xmm5
000077a70fdcfa51  vmovaps [rsp+0x120], xmm12
000077a70fdcfa5a  vmovaps xmm14, [rsp+0x120]
000077a70fdcfa63  por xmm12, xmm14
000077a70fdcfa68  movaps [r15+0x2E0], xmm12
000077a70fdcfa70  vmovaps xmm13, [rsp+0x110]
000077a70fdcfa79  vmovaps [rsp+0x110], xmm1
000077a70fdcfa82  vmovaps xmm1, [rsp+0xE0]
000077a70fdcfa8b  vmovaps [rsp+0xE0], xmm15
000077a70fdcfa94  movaps xmm14, xmm13
000077a70fdcfa98  addpd xmm14, xmm1
000077a70fdcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000077a70fdcfaa3  ptest xmm15, xmm15
000077a70fdcfaa9  jnz 0x000077A70FDD1AD8
000077a70fdcfaaf  vmovaps xmm1, [rsp+0xA0]
000077a70fdcfab8  vpermilpd xmm1, xmm1, 0x00
000077a70fdcfabe  vmovaps xmm13, [rsp+0x110]
000077a70fdcfac7  vmovaps [rsp+0x110], xmm14
000077a70fdcfad0  movaps xmm15, xmm13
000077a70fdcfad4  mulpd xmm15, xmm1
000077a70fdcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000077a70fdcfadf  ptest xmm14, xmm14
000077a70fdcfae5  jnz 0x000077A70FDD1C1B
000077a70fdcfaeb  lea rax, [r14+0x80]
000077a70fdcfaf2  movups xmm1, [r13+rax*1]
000077a70fdcfaf8  vmovaps xmm13, [rsp+0xC0]
000077a70fdcfb01  vmovaps [rsp+0xC0], xmm1
000077a70fdcfb0a  movaps xmm14, xmm13
000077a70fdcfb0e  addpd xmm14, xmm2
000077a70fdcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000077a70fdcfb19  ptest xmm1, xmm1
000077a70fdcfb1e  jnz 0x000077A70FDD1D68
000077a70fdcfb24  vmovaps xmm13, [rsp+0x100]
000077a70fdcfb2d  vmovaps xmm2, [rsp+0x30]
000077a70fdcfb33  vmovaps [rsp+0x30], xmm15
000077a70fdcfb39  movaps xmm1, xmm13
000077a70fdcfb3d  addpd xmm1, xmm2
000077a70fdcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000077a70fdcfb46  ptest xmm15, xmm15
000077a70fdcfb4c  jnz 0x000077A70FDD1EAB
000077a70fdcfb52  vmovaps xmm15, [rsp+0x20]
000077a70fdcfb58  vmovaps xmm13, [rsp+0x20]
000077a70fdcfb5e  por xmm15, xmm13
000077a70fdcfb63  movaps [r15+0x2F0], xmm15
000077a70fdcfb6b  vmovaps xmm13, [rsp+0xA0]
000077a70fdcfb74  vpermilpd xmm13, xmm13, 0x00
000077a70fdcfb7a  vmovaps [rsp+0x20], xmm1
000077a70fdcfb80  vmovaps xmm1, [rsp+0xC0]
000077a70fdcfb89  vmovaps [rsp+0xA0], xmm15
000077a70fdcfb92  movaps xmm2, xmm1
000077a70fdcfb95  mulpd xmm2, xmm13
000077a70fdcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000077a70fdcfb9f  ptest xmm15, xmm15
000077a70fdcfba5  jnz 0x000077A70FDD1FEC
000077a70fdcfbab  lea rax, [r14+0xD0]
000077a70fdcfbb2  movups xmm1, [r13+rax*1]
000077a70fdcfbb8  vmovaps xmm13, [rsp+0xF0]
000077a70fdcfbc1  vmovaps [rsp+0xC0], xmm1
000077a70fdcfbca  vmovaps xmm1, [rsp+0xE0]
000077a70fdcfbd3  vmovaps [rsp+0xE0], xmm14
000077a70fdcfbdc  movaps xmm15, xmm13
000077a70fdcfbe0  addpd xmm15, xmm1
000077a70fdcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000077a70fdcfbeb  ptest xmm14, xmm14
000077a70fdcfbf1  jnz 0x000077A70FDD2137
000077a70fdcfbf7  vmovaps xmm1, [rsp+0xB0]
000077a70fdcfc00  vpermilpd xmm1, xmm1, 0x00
000077a70fdcfc06  movaps xmm14, xmm11
000077a70fdcfc0a  mulpd xmm14, xmm1
000077a70fdcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000077a70fdcfc15  ptest xmm13, xmm13
000077a70fdcfc1b  jnz 0x000077A70FDD227A
000077a70fdcfc21  movaps [r15+0x260], xmm14
000077a70fdcfc29  vxorps xmm1, xmm1, xmm1
000077a70fdcfc2d  vpbroadcastq xmm1, xmm1
000077a70fdcfc32  movaps [r15+0x1B0], xmm1
000077a70fdcfc3a  vmovaps xmm1, [rsp+0xB0]
000077a70fdcfc43  vpermilpd xmm1, xmm1, 0x00
000077a70fdcfc49  vmovaps xmm11, [rsp+0xC0]
000077a70fdcfc52  vmovaps [rsp+0xC0], xmm15
000077a70fdcfc5b  movaps xmm13, xmm11
000077a70fdcfc5f  mulpd xmm13, xmm1
000077a70fdcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000077a70fdcfc6a  ptest xmm15, xmm15
000077a70fdcfc70  jnz 0x000077A70FDD23BD
000077a70fdcfc76  lea rax, [r14+0xC0]
000077a70fdcfc7d  movups xmm1, [r13+rax*1]
000077a70fdcfc83  vmovaps xmm11, [rsp+0x110]
000077a70fdcfc8c  vmovaps [rsp+0xF0], xmm1
000077a70fdcfc95  vmovaps xmm1, [rsp+0x30]
000077a70fdcfc9b  vmovaps [rsp+0x30], xmm14
000077a70fdcfca1  movaps xmm15, xmm11
000077a70fdcfca5  addpd xmm15, xmm1
000077a70fdcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000077a70fdcfcb0  ptest xmm14, xmm14
000077a70fdcfcb6  jnz 0x000077A70FDD250A
000077a70fdcfcbc  vmovaps [rsp+0x100], xmm9
000077a70fdcfcc5  vmovaps xmm1, [rsp+0x100]
000077a70fdcfcce  por xmm9, xmm1
000077a70fdcfcd3  movaps [r15+0x270], xmm9
000077a70fdcfcdb  vmovaps [rsp+0x100], xmm6
000077a70fdcfce4  vmovaps xmm1, [rsp+0x100]
000077a70fdcfced  por xmm6, xmm1
000077a70fdcfcf1  movaps [r15+0x1A0], xmm6
000077a70fdcfcf9  vmovaps xmm14, [rsp+0xB0]
000077a70fdcfd02  vpermilpd xmm14, xmm14, 0x00
000077a70fdcfd08  vmovaps xmm6, [rsp+0xF0]
000077a70fdcfd11  vmovaps [rsp+0xF0], xmm1
000077a70fdcfd1a  movaps xmm11, xmm6
000077a70fdcfd1e  mulpd xmm11, xmm14
000077a70fdcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000077a70fdcfd29  ptest xmm1, xmm1
000077a70fdcfd2e  jnz 0x000077A70FDD264D
000077a70fdcfd34  lea rax, [r14+0x20]
000077a70fdcfd38  movups xmm1, [r13+rax*1]
000077a70fdcfd3e  movaps [r15+0x110], xmm1
000077a70fdcfd46  vmovaps xmm6, [rsp+0xE0]
000077a70fdcfd4f  vmovaps [rsp+0xE0], xmm1
000077a70fdcfd58  movaps xmm14, xmm6
000077a70fdcfd5c  addpd xmm14, xmm2
000077a70fdcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000077a70fdcfd67  ptest xmm1, xmm1
000077a70fdcfd6c  jnz 0x000077A70FDD279A
000077a70fdcfd72  vmovaps xmm1, [rsp+0xB0]
000077a70fdcfd7b  vpermilpd xmm1, xmm1, 0x00
000077a70fdcfd81  movaps xmm6, xmm5
000077a70fdcfd84  mulpd xmm6, xmm1
000077a70fdcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000077a70fdcfd8d  ptest xmm2, xmm2
000077a70fdcfd92  jnz 0x000077A70FDD28DC
000077a70fdcfd98  vmovaps xmm5, [rsp+0x20]
000077a70fdcfd9e  movaps xmm1, xmm5
000077a70fdcfda1  addpd xmm1, xmm13
000077a70fdcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000077a70fdcfdab  ptest xmm2, xmm2
000077a70fdcfdb0  jnz 0x000077A70FDD2A1C
000077a70fdcfdb6  vmovaps xmm13, [rsp+0x80]
000077a70fdcfdbf  vpermilpd xmm13, xmm13, 0x00
000077a70fdcfdc5  vmovaps xmm2, [rsp+0xE0]
000077a70fdcfdce  vmovaps [rsp+0x20], xmm1
000077a70fdcfdd4  movaps xmm5, xmm2
000077a70fdcfdd7  mulpd xmm5, xmm13
000077a70fdcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000077a70fdcfde1  ptest xmm1, xmm1
000077a70fdcfde6  jnz 0x000077A70FDD2B5D
000077a70fdcfdec  vmovaps xmm1, [rsp+0x80]
000077a70fdcfdf5  vpermilpd xmm1, xmm1, 0x00
000077a70fdcfdfb  movaps xmm13, xmm10
000077a70fdcfdff  mulpd xmm13, xmm1
000077a70fdcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000077a70fdcfe0a  ptest xmm2, xmm2
000077a70fdcfe0f  jnz 0x000077A70FDD2C9E
000077a70fdcfe15  vmovaps xmm10, [rsp+0x30]
000077a70fdcfe1b  movaps xmm1, xmm15
000077a70fdcfe1f  addpd xmm1, xmm10
000077a70fdcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000077a70fdcfe29  ptest xmm2, xmm2
000077a70fdcfe2e  jnz 0x000077A70FDD2DE1
000077a70fdcfe34  vmovaps xmm10, [rsp+0xC0]
000077a70fdcfe3d  movaps xmm15, xmm10
000077a70fdcfe41  addpd xmm15, xmm11
000077a70fdcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000077a70fdcfe4c  ptest xmm2, xmm2
000077a70fdcfe51  jnz 0x000077A70FDD2F23
000077a70fdcfe57  vmovaps xmm11, [rsp+0x80]
000077a70fdcfe60  vpermilpd xmm11, xmm11, 0x00
000077a70fdcfe66  movaps xmm10, xmm12
000077a70fdcfe6a  mulpd xmm10, xmm11
000077a70fdcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000077a70fdcfe75  ptest xmm2, xmm2
000077a70fdcfe7a  jnz 0x000077A70FDD3067
000077a70fdcfe80  vmovaps xmm12, [rsp+0x80]
000077a70fdcfe89  vpermilpd xmm12, xmm12, 0x00
000077a70fdcfe8f  vmovaps xmm2, [rsp+0xA0]
000077a70fdcfe98  vmovaps [rsp+0x30], xmm1
000077a70fdcfe9e  movaps xmm11, xmm2
000077a70fdcfea2  mulpd xmm11, xmm12
000077a70fdcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000077a70fdcfead  ptest xmm1, xmm1
000077a70fdcfeb2  jnz 0x000077A70FDD31AB
000077a70fdcfeb8  movaps xmm1, xmm14
000077a70fdcfebc  addpd xmm1, xmm6
000077a70fdcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000077a70fdcfec5  ptest xmm12, xmm12
000077a70fdcfecb  jnz 0x000077A70FDD32EE
000077a70fdcfed1  vmovaps xmm12, [rsp+0x20]
000077a70fdcfed7  movaps xmm14, xmm12
000077a70fdcfedb  addpd xmm14, xmm5
000077a70fdcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000077a70fdcfee6  ptest xmm6, xmm6
000077a70fdcfeeb  jnz 0x000077A70FDD342F
000077a70fdcfef1  vmovaps xmm12, [rsp+0x90]
000077a70fdcfefa  vpermilpd xmm12, xmm12, 0x00
000077a70fdcff00  movaps xmm6, xmm9
000077a70fdcff04  mulpd xmm6, xmm12
000077a70fdcff09  vcmppd xmm5, xmm6, xmm6, 0x03
000077a70fdcff0e  ptest xmm5, xmm5
000077a70fdcff13  jnz 0x000077A70FDD3572
000077a70fdcff19  movaps xmm12, xmm15
000077a70fdcff1d  addpd xmm12, xmm13
000077a70fdcff22  vcmppd xmm9, xmm12, xmm12, 0x03
000077a70fdcff28  ptest xmm9, xmm9
000077a70fdcff2e  jnz 0x000077A70FDD36B4
000077a70fdcff34  vmovaps xmm13, [rsp+0x30]
000077a70fdcff3a  movaps xmm15, xmm13
000077a70fdcff3e  addpd xmm15, xmm10
000077a70fdcff43  vcmppd xmm9, xmm15, xmm15, 0x03
000077a70fdcff49  ptest xmm9, xmm9
000077a70fdcff4f  jnz 0x000077A70FDD37F8
000077a70fdcff55  vmovaps xmm13, [rsp+0xD0]
000077a70fdcff5e  vmovaps xmm10, [rsp+0xD0]
000077a70fdcff67  por xmm13, xmm10
000077a70fdcff6c  movaps [r15+0x250], xmm13
000077a70fdcff74  vmovaps [rsp+0x20], xmm7
000077a70fdcff7a  vmovaps xmm13, [rsp+0x20]
000077a70fdcff80  por xmm7, xmm13
000077a70fdcff85  movaps [r15+0x2A0], xmm7
000077a70fdcff8d  vmovaps [rsp+0x20], xmm3
000077a70fdcff93  vmovaps xmm13, [rsp+0x20]
000077a70fdcff99  por xmm3, xmm13
000077a70fdcff9e  movaps [r15+0x1D0], xmm3
000077a70fdcffa6  lea rax, [r14+0x40]
000077a70fdcffaa  movups xmm13, [r13+rax*1]
000077a70fdcffb0  movaps [r15+0x2C0], xmm13
000077a70fdcffb8  vmovaps xmm10, [rsp+0x90]
000077a70fdcffc1  vpermilpd xmm10, xmm10, 0x00
000077a70fdcffc7  movaps xmm9, xmm8
000077a70fdcffcb  mulpd xmm9, xmm10
000077a70fdcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000077a70fdcffd6  ptest xmm5, xmm5
000077a70fdcffdb  jnz 0x000077A70FDD3946
000077a70fdcffe1  movaps xmm10, xmm1
000077a70fdcffe5  addpd xmm10, xmm11
000077a70fdcffea  vcmppd xmm8, xmm10, xmm10, 0x03
000077a70fdcfff0  ptest xmm8, xmm8
000077a70fdcfff6  jnz 0x000077A70FDD3A8A
000077a70fdcfffc  movaps xmm1, xmm14
000077a70fdd0000  addpd xmm1, xmm6
000077a70fdd0004  vcmppd xmm11, xmm1, xmm1, 0x03
000077a70fdd0009  ptest xmm11, xmm11
000077a70fdd000f  jnz 0x000077A70FDD3BCD
000077a70fdd0015  vmovaps xmm14, [rsp+0x90]
000077a70fdd001e  vpermilpd xmm14, xmm14, 0x00
000077a70fdd0024  movaps xmm11, xmm13
000077a70fdd0028  mulpd xmm11, xmm14
000077a70fdd002d  vcmppd xmm8, xmm11, xmm11, 0x03
000077a70fdd0033  ptest xmm8, xmm8
000077a70fdd0039  jnz 0x000077A70FDD3D0E
000077a70fdd003f  vmovaps xmm14, [rsp+0x90]
000077a70fdd0048  vpermilpd xmm14, xmm14, 0x00
000077a70fdd004e  vmovaps xmm8, [rsp+0x10]
000077a70fdd0054  movaps xmm13, xmm8
000077a70fdd0058  mulpd xmm13, xmm14
000077a70fdd005d  vcmppd xmm6, xmm13, xmm13, 0x03
000077a70fdd0063  ptest xmm6, xmm6
000077a70fdd0068  jnz 0x000077A70FDD3E52
000077a70fdd006e  vmovaps xmm14, [rsp+0x60]
000077a70fdd0074  vpermilpd xmm14, xmm14, 0x00
000077a70fdd007a  movaps xmm8, xmm7
000077a70fdd007e  mulpd xmm8, xmm14
000077a70fdd0083  vcmppd xmm6, xmm8, xmm8, 0x03
000077a70fdd0089  ptest xmm6, xmm6
000077a70fdd008e  jnz 0x000077A70FDD3F96
000077a70fdd0094  movaps xmm14, xmm12
000077a70fdd0098  addpd xmm14, xmm9
000077a70fdd009d  vcmppd xmm7, xmm14, xmm14, 0x03
000077a70fdd00a3  ptest xmm7, xmm7
000077a70fdd00a8  jnz 0x000077A70FDD40D9
000077a70fdd00ae  vmovaps xmm12, [rsp+0x60]
000077a70fdd00b4  vpermilpd xmm12, xmm12, 0x00
000077a70fdd00ba  vmovaps xmm7, [rsp+0xF0]
000077a70fdd00c3  movaps xmm9, xmm7
000077a70fdd00c7  mulpd xmm9, xmm12
000077a70fdd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000077a70fdd00d2  ptest xmm6, xmm6
000077a70fdd00d7  jnz 0x000077A70FDD421D
000077a70fdd00dd  movaps xmm12, xmm15
000077a70fdd00e1  addpd xmm12, xmm11
000077a70fdd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000077a70fdd00ec  ptest xmm7, xmm7
000077a70fdd00f1  jnz 0x000077A70FDD4360
000077a70fdd00f7  vmovaps xmm15, [rsp+0x60]
000077a70fdd00fd  vpermilpd xmm15, xmm15, 0x00
000077a70fdd0103  vmovaps xmm7, [rsp+0x40]
000077a70fdd0109  movaps xmm11, xmm7
000077a70fdd010d  mulpd xmm11, xmm15
000077a70fdd0112  vcmppd xmm6, xmm11, xmm11, 0x03
000077a70fdd0118  ptest xmm6, xmm6
000077a70fdd011d  jnz 0x000077A70FDD44A4
000077a70fdd0123  movaps xmm15, xmm10
000077a70fdd0127  addpd xmm15, xmm13
000077a70fdd012c  vcmppd xmm7, xmm15, xmm15, 0x03
000077a70fdd0132  ptest xmm7, xmm7
000077a70fdd0137  jnz 0x000077A70FDD45E7
000077a70fdd013d  vmovaps xmm13, [rsp+0x60]
000077a70fdd0143  vpermilpd xmm13, xmm13, 0x00
000077a70fdd0149  vmovaps xmm7, [rsp+0x50]
000077a70fdd014f  movaps xmm10, xmm7
000077a70fdd0153  mulpd xmm10, xmm13
000077a70fdd0158  vcmppd xmm6, xmm10, xmm10, 0x03
000077a70fdd015e  ptest xmm6, xmm6
000077a70fdd0163  jnz 0x000077A70FDD472B
000077a70fdd0169  movaps xmm13, xmm1
000077a70fdd016d  addpd xmm13, xmm8
000077a70fdd0172  vcmppd xmm7, xmm13, xmm13, 0x03
000077a70fdd0178  ptest xmm7, xmm7
000077a70fdd017d  jnz 0x000077A70FDD486E
000077a70fdd0183  lea rax, [r14+0x70]
000077a70fdd0187  movups xmm1, [r13+rax*1]
000077a70fdd018d  movaps [r15+0x240], xmm1
000077a70fdd0195  movaps xmm8, xmm14
000077a70fdd0199  addpd xmm8, xmm9
000077a70fdd019e  vcmppd xmm7, xmm8, xmm8, 0x03
000077a70fdd01a4  ptest xmm7, xmm7
000077a70fdd01a9  jnz 0x000077A70FDD49BB
000077a70fdd01af  movaps [r15+0x170], xmm8
000077a70fdd01b7  vmovaps xmm14, [rsp+0x70]
000077a70fdd01bd  vpermilpd xmm14, xmm14, 0x00
000077a70fdd01c3  movaps xmm9, xmm1
000077a70fdd01c7  mulpd xmm9, xmm14
000077a70fdd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000077a70fdd01d2  ptest xmm7, xmm7
000077a70fdd01d7  jnz 0x000077A70FDD4AFF
000077a70fdd01dd  vmovaps xmm1, [rsp+0x70]
000077a70fdd01e3  vpermilpd xmm1, xmm1, 0x00
000077a70fdd01e9  movaps xmm14, xmm4
000077a70fdd01ed  mulpd xmm14, xmm1
000077a70fdd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000077a70fdd01f8  ptest xmm7, xmm7
000077a70fdd01fd  jnz 0x000077A70FDD4C42
000077a70fdd0203  movaps [r15+0x180], xmm14
000077a70fdd020b  movaps xmm1, xmm12
000077a70fdd020f  addpd xmm1, xmm11
000077a70fdd0214  vcmppd xmm7, xmm1, xmm1, 0x03
000077a70fdd0219  ptest xmm7, xmm7
000077a70fdd021e  jnz 0x000077A70FDD4D84
000077a70fdd0224  movaps [r15+0x210], xmm1
000077a70fdd022c  movups xmm12, [r13+r14*1]
000077a70fdd0232  lea rax, [r14+0x10]
000077a70fdd0236  movups xmm11, [r13+rax*1]
000077a70fdd023c  movaps [r15+0x230], xmm11
000077a70fdd0244  movaps xmm7, xmm15
000077a70fdd0248  addpd xmm7, xmm10
000077a70fdd024d  vcmppd xmm6, xmm7, xmm7, 0x03
000077a70fdd0252  ptest xmm6, xmm6
000077a70fdd0257  jnz 0x000077A70FDD4EDA
000077a70fdd025d  movaps [r15+0x130], xmm7
000077a70fdd0265  vmovaps xmm15, [rsp+0x70]
000077a70fdd026b  vpermilpd xmm15, xmm15, 0x00
000077a70fdd0271  movaps xmm10, xmm11
000077a70fdd0275  mulpd xmm10, xmm15
000077a70fdd027a  vcmppd xmm6, xmm10, xmm10, 0x03
000077a70fdd0280  ptest xmm6, xmm6
000077a70fdd0285  jnz 0x000077A70FDD501C
000077a70fdd028b  movaps [r15+0x220], xmm10
000077a70fdd0293  vmovaps xmm15, [rsp+0x70]
000077a70fdd0299  vpermilpd xmm15, xmm15, 0x00
000077a70fdd029f  movaps xmm11, xmm12
000077a70fdd02a3  mulpd xmm11, xmm15
000077a70fdd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000077a70fdd02ae  ptest xmm6, xmm6
000077a70fdd02b3  jnz 0x000077A70FDD5160
000077a70fdd02b9  movaps xmm15, xmm13
000077a70fdd02bd  addpd xmm15, xmm9
000077a70fdd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000077a70fdd02c8  ptest xmm12, xmm12
000077a70fdd02ce  jnz 0x000077A70FDD52A4
000077a70fdd02d4  movaps [r15+0x140], xmm15
000077a70fdd02dc  movaps xmm13, xmm8
000077a70fdd02e0  addpd xmm13, xmm14
000077a70fdd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000077a70fdd02eb  ptest xmm12, xmm12
000077a70fdd02f1  jnz 0x000077A70FDD53E8
000077a70fdd02f7  movaps [r15+0x150], xmm13
000077a70fdd02ff  movaps xmm14, xmm1
000077a70fdd0303  addpd xmm14, xmm10
000077a70fdd0308  vcmppd xmm12, xmm14, xmm14, 0x03
000077a70fdd030e  ptest xmm12, xmm12
000077a70fdd0314  jnz 0x000077A70FDD552C
000077a70fdd031a  movaps [r15+0x160], xmm14
000077a70fdd0322  movaps xmm1, xmm7
000077a70fdd0325  addpd xmm1, xmm11
000077a70fdd032a  vcmppd xmm12, xmm1, xmm1, 0x03
000077a70fdd032f  ptest xmm12, xmm12
000077a70fdd0335  jnz 0x000077A70FDD566F
000077a70fdd033b  movaps [r15+0x120], xmm1
000077a70fdd0343  mov eax, 0x430920
000077a70fdd0348  movups [r13+rax*1], xmm15
000077a70fdd034e  mov eax, 0x430930
000077a70fdd0353  movups [r13+rax*1], xmm13
000077a70fdd0359  mov eax, 0x430940
000077a70fdd035e  movups [r13+rax*1], xmm14
000077a70fdd0364  mov eax, 0x430950
000077a70fdd0369  movups [r13+rax*1], xmm1
000077a70fdd036f  mov eax, [r15+0x108]
000077a70fdd0376  sahf
000077a70fdd0377  jnz 0x000077A70FDD03A9
000077a70fdd0379  cmp dword ptr [r15+0x318], 0x00
000077a70fdd0381  jz 0x000077A70FDDB900
000077a70fdd0387  nop [rax+rax*1], ax
000077a70fdd0390  nop [rax+rax*1], eax
000077a70fdd0398  mov eax, 0x410444
000077a70fdd039d  mov [r15+0x100], rax
000077a70fdd03a4  jmp 0x000077A70FBFE110
000077a70fdd03a9  cmp dword ptr [r15+0x318], 0x00
000077a70fdd03b1  jz 0x000077A70FDD57E0
000077a70fdd03b7  nop [rax+rax*1], ax
000077a70fdd03c0  nop [rax+rax*1], eax
000077a70fdd03c8  mov eax, 0x410278
000077a70fdd03cd  mov [r15+0x100], rax
000077a70fdd03d4  jmp 0x000077A70FBFE110
000077a70fdd03d9  int3
000077a70fdd03da  call 0x000077A70FCB52F0
000077a70fdd03df  jmp 0x000077A70FDCF016
000077a70fdd03e4  call 0x000077A70FCC4620
000077a70fdd03e9  jmp 0x000077A70FDCF023
000077a70fdd03ee  call 0x000077A70FCC33A0
000077a70fdd03f3  jmp 0x000077A70FDCF035
000077a70fdd03f8  call 0x000077A70FCC2120
000077a70fdd03fd  jmp 0x000077A70FDCF03F
000077a70fdd0402  call 0x000077A70FCC0860
000077a70fdd0407  jmp 0x000077A70FDCF067
000077a70fdd040c  call 0x000077A70FCBF5F0
000077a70fdd0411  jmp 0x000077A70FDCF073
000077a70fdd0416  call 0x000077A70FCC0860
000077a70fdd041b  jmp 0x000077A70FDCF0A5
000077a70fdd0420  call 0x000077A70FCBF5F0
000077a70fdd0425  jmp 0x000077A70FDCF0B1
000077a70fdd042a  call 0x000077A70FCC4740
000077a70fdd042f  jmp 0x000077A70FDCF0BE
000077a70fdd0434  call 0x000077A70FCB5400
000077a70fdd0439  jmp 0x000077A70FDCF0CB
000077a70fdd043e  call 0x000077A70FCB52F0
000077a70fdd0443  jmp 0x000077A70FDCF0D8
000077a70fdd0448  call 0x000077A70FCC4620
000077a70fdd044d  jmp 0x000077A70FDCF0E5
000077a70fdd0452  call 0x000077A70FCC0860
000077a70fdd0457  jmp 0x000077A70FDCF10D
000077a70fdd045c  call 0x000077A70FCBF5F0
000077a70fdd0461  jmp 0x000077A70FDCF119
000077a70fdd0466  call 0x000077A70FC09D70
000077a70fdd046b  jmp 0x000077A70FDCF11F
000077a70fdd0470  call 0x000077A70FCBE9C0
000077a70fdd0475  jmp 0x000077A70FDCF129
000077a70fdd047a  call 0x000077A70FCC0860
000077a70fdd047f  jmp 0x000077A70FDCF151
000077a70fdd0484  call 0x000077A70FCBF5F0
000077a70fdd0489  jmp 0x000077A70FDCF15D
000077a70fdd048e  call 0x000077A70FCBD750
000077a70fdd0493  jmp 0x000077A70FDCF16A
000077a70fdd0498  call 0x000077A70FCBC4E0
000077a70fdd049d  jmp 0x000077A70FDCF177
000077a70fdd04a2  call 0x000077A70FCC4740
000077a70fdd04a7  jmp 0x000077A70FDCF184
000077a70fdd04ac  call 0x000077A70FCB5400
000077a70fdd04b1  jmp 0x000077A70FDCF191
000077a70fdd04b6  call 0x000077A70FCB52F0
000077a70fdd04bb  jmp 0x000077A70FDCF19E
000077a70fdd04c0  call 0x000077A70FCC4620
000077a70fdd04c5  jmp 0x000077A70FDCF1AB
000077a70fdd04ca  call 0x000077A70FCC0860
000077a70fdd04cf  jmp 0x000077A70FDCF1BE
000077a70fdd04d4  call 0x000077A70FCBB270
000077a70fdd04d9  jmp 0x000077A70FDCF1CB
000077a70fdd04de  call 0x000077A70FCBA000
000077a70fdd04e3  jmp 0x000077A70FDCF1D8
000077a70fdd04e8  call 0x000077A70FCB8D90
000077a70fdd04ed  jmp 0x000077A70FDCF1E5
000077a70fdd04f2  call 0x000077A70FCB8A20
000077a70fdd04f7  jmp 0x000077A70FDCF1F2
000077a70fdd04fc  call 0x000077A70FCB5400
000077a70fdd0501  jmp 0x000077A70FDCF1FC
000077a70fdd0506  call 0x000077A70FCC2240
000077a70fdd050b  jmp 0x000077A70FDCF206
000077a70fdd0510  call 0x000077A70FCB52F0
000077a70fdd0515  jmp 0x000077A70FDCF210
000077a70fdd051a  call 0x000077A70FCC2120
000077a70fdd051f  jmp 0x000077A70FDCF21A
000077a70fdd0524  call 0x000077A70FCB77B0
000077a70fdd0529  jmp 0x000077A70FDCF224
000077a70fdd052e  call 0x000077A70FCB6550
000077a70fdd0533  jmp 0x000077A70FDCF22E
000077a70fdd0538  call 0x000077A70FCBFD50
000077a70fdd053d  jmp 0x000077A70FDCF240
000077a70fdd0542  call 0x000077A70FCB8EA0
000077a70fdd0547  jmp 0x000077A70FDCF24A
000077a70fdd054c  call 0x000077A70FCBFC30
000077a70fdd0551  jmp 0x000077A70FDCF257
000077a70fdd0556  call 0x000077A70FCB8D90
000077a70fdd055b  jmp 0x000077A70FDCF264
000077a70fdd0560  call 0x000077A70FCC2240
000077a70fdd0565  jmp 0x000077A70FDCF271
000077a70fdd056a  call 0x000077A70FCB5400
000077a70fdd056f  jmp 0x000077A70FDCF27E
000077a70fdd0574  call 0x000077A70FCB52F0
000077a70fdd0579  jmp 0x000077A70FDCF28B
000077a70fdd057e  call 0x000077A70FCC2120
000077a70fdd0583  jmp 0x000077A70FDCF298
000077a70fdd0588  call 0x000077A70FCB52F0
000077a70fdd058d  jmp 0x000077A70FDCF2AB
000077a70fdd0592  call 0x000077A70FCB52F0
000077a70fdd0597  jmp 0x000077A70FDCF2BE
000077a70fdd059c  call 0x000077A70FCB52F0
000077a70fdd05a1  jmp 0x000077A70FDCF2D1
000077a70fdd05a6  call 0x000077A70FCB52F0
000077a70fdd05ab  jmp 0x000077A70FDCF2E4
000077a70fdd05b0  call 0x000077A70FCC2240
000077a70fdd05b5  jmp 0x000077A70FDCF2F9
000077a70fdd05ba  call 0x000077A70FCC2240
000077a70fdd05bf  jmp 0x000077A70FDCF30C
000077a70fdd05c4  call 0x000077A70FCC2120
000077a70fdd05c9  jmp 0x000077A70FDCF319
000077a70fdd05ce  call 0x000077A70FCB52F0
000077a70fdd05d3  jmp 0x000077A70FDCF32C
000077a70fdd05d8  call 0x000077A70FCB52F0
000077a70fdd05dd  jmp 0x000077A70FDCF34F
000077a70fdd05e2  call 0x000077A70FCB52F0
000077a70fdd05e7  jmp 0x000077A70FDCF362
000077a70fdd05ec  call 0x000077A70FBFF540
000077a70fdd05f1  jmp 0x000077A70FDCF380
000077a70fdd05f6  call 0x000077A70FC08C20
000077a70fdd05fb  jmp 0x000077A70FDCF38A
000077a70fdd0600  call 0x000077A70FCD6600
000077a70fdd0605  jmp 0x000077A70FDCF396
000077a70fdd060a  call 0x000077A70FBFF540
000077a70fdd060f  jmp 0x000077A70FDCF3A6
000077a70fdd0614  call 0x000077A70FCC0370
000077a70fdd0619  jmp 0x000077A70FDCF3D4
000077a70fdd061e  call 0x000077A70FCBF100
000077a70fdd0623  jmp 0x000077A70FDCF3DD
000077a70fdd0628  call 0x000077A70FCC0370
000077a70fdd062d  jmp 0x000077A70FDCF43B
000077a70fdd0632  call 0x000077A70FCBF100
000077a70fdd0637  jmp 0x000077A70FDCF444
000077a70fdd063c  call 0x000077A70FCC0370
000077a70fdd0641  jmp 0x000077A70FDCF48B
000077a70fdd0646  call 0x000077A70FCBF100
000077a70fdd064b  jmp 0x000077A70FDCF494
000077a70fdd0650  call 0x000077A70FC0B720
000077a70fdd0655  jmp 0x000077A70FDCF4D7
000077a70fdd065a  call 0x000077A70FCB47C0
000077a70fdd065f  jmp 0x000077A70FDCF4EA
000077a70fdd0664  call 0x000077A70FC08B00
000077a70fdd0669  jmp 0x000077A70FDCF501
000077a70fdd066e  call 0x000077A70FBFF430
000077a70fdd0673  jmp 0x000077A70FDCF514
000077a70fdd0678  call 0x000077A70FBFF430
000077a70fdd067d  jmp 0x000077A70FDCF527
000077a70fdd0682  sub rsp, 0x08
000077a70fdd0686  push rax
000077a70fdd0687  push rcx
000077a70fdd0688  push rdx
000077a70fdd0689  push rdi
000077a70fdd068a  push rsi
000077a70fdd068b  push r8
000077a70fdd068d  push r9
000077a70fdd068f  push r10
000077a70fdd0691  push r11
000077a70fdd0693  sub rsp, 0xF0
000077a70fdd069a  vmovaps [rsp], xmm0
000077a70fdd069f  vmovaps [rsp+0x10], xmm2
000077a70fdd06a5  vmovaps [rsp+0x20], xmm3
000077a70fdd06ab  vmovaps [rsp+0x30], xmm4
000077a70fdd06b1  vmovaps [rsp+0x40], xmm5
000077a70fdd06b7  vmovaps [rsp+0x50], xmm6
000077a70fdd06bd  vmovaps [rsp+0x60], xmm7
000077a70fdd06c3  vmovaps [rsp+0x70], xmm8
000077a70fdd06c9  vmovaps [rsp+0x80], xmm9
000077a70fdd06d2  vmovaps [rsp+0x90], xmm10
000077a70fdd06db  vmovaps [rsp+0xA0], xmm11
000077a70fdd06e4  vmovaps [rsp+0xB0], xmm12
000077a70fdd06ed  vmovaps [rsp+0xC0], xmm13
000077a70fdd06f6  vmovaps [rsp+0xD0], xmm14
000077a70fdd06ff  vmovaps [rsp+0xE0], xmm15
000077a70fdd0708  sub rsp, 0x30
000077a70fdd070c  movaps [rsp], xmm1
000077a70fdd0710  movaps [rsp+0x10], xmm15
000077a70fdd0716  movaps [rsp+0x20], xmm14
000077a70fdd071c  lea rdi, [rsp]
000077a70fdd0720  mov esi, 0x00
000077a70fdd0725  mov rax, 0x6294188EF530
000077a70fdd072f  call rax
000077a70fdd0731  movaps xmm1, [rsp]
000077a70fdd0735  add rsp, 0x30
000077a70fdd0739  vmovaps xmm0, [rsp]
000077a70fdd073e  vmovaps xmm2, [rsp+0x10]
000077a70fdd0744  vmovaps xmm3, [rsp+0x20]
000077a70fdd074a  vmovaps xmm4, [rsp+0x30]
000077a70fdd0750  vmovaps xmm5, [rsp+0x40]
000077a70fdd0756  vmovaps xmm6, [rsp+0x50]
000077a70fdd075c  vmovaps xmm7, [rsp+0x60]
000077a70fdd0762  vmovaps xmm8, [rsp+0x70]
000077a70fdd0768  vmovaps xmm9, [rsp+0x80]
000077a70fdd0771  vmovaps xmm10, [rsp+0x90]
000077a70fdd077a  vmovaps xmm11, [rsp+0xA0]
000077a70fdd0783  vmovaps xmm12, [rsp+0xB0]
000077a70fdd078c  vmovaps xmm13, [rsp+0xC0]
000077a70fdd0795  vmovaps xmm14, [rsp+0xD0]
000077a70fdd079e  vmovaps xmm15, [rsp+0xE0]
000077a70fdd07a7  add rsp, 0xF0
000077a70fdd07ae  pop r11
000077a70fdd07b0  pop r10
000077a70fdd07b2  pop r9
000077a70fdd07b4  pop r8
000077a70fdd07b6  pop rsi
000077a70fdd07b7  pop rdi
000077a70fdd07b8  pop rdx
000077a70fdd07b9  pop rcx
000077a70fdd07ba  pop rax
000077a70fdd07bb  add rsp, 0x08
000077a70fdd07bf  jmp 0x000077A70FDCF581
000077a70fdd07c4  sub rsp, 0x08
000077a70fdd07c8  push rax
000077a70fdd07c9  push rcx
000077a70fdd07ca  push rdx
000077a70fdd07cb  push rdi
000077a70fdd07cc  push rsi
000077a70fdd07cd  push r8
000077a70fdd07cf  push r9
000077a70fdd07d1  push r10
000077a70fdd07d3  push r11
000077a70fdd07d5  sub rsp, 0xF0
000077a70fdd07dc  vmovaps [rsp], xmm0
000077a70fdd07e1  vmovaps [rsp+0x10], xmm1
000077a70fdd07e7  vmovaps [rsp+0x20], xmm2
000077a70fdd07ed  vmovaps [rsp+0x30], xmm3
000077a70fdd07f3  vmovaps [rsp+0x40], xmm4
000077a70fdd07f9  vmovaps [rsp+0x50], xmm5
000077a70fdd07ff  vmovaps [rsp+0x60], xmm6
000077a70fdd0805  vmovaps [rsp+0x70], xmm7
000077a70fdd080b  vmovaps [rsp+0x80], xmm8
000077a70fdd0814  vmovaps [rsp+0x90], xmm9
000077a70fdd081d  vmovaps [rsp+0xA0], xmm10
000077a70fdd0826  vmovaps [rsp+0xB0], xmm11
000077a70fdd082f  vmovaps [rsp+0xC0], xmm12
000077a70fdd0838  vmovaps [rsp+0xD0], xmm14
000077a70fdd0841  vmovaps [rsp+0xE0], xmm15
000077a70fdd084a  sub rsp, 0x30
000077a70fdd084e  movaps [rsp], xmm13
000077a70fdd0853  movaps [rsp+0x10], xmm1
000077a70fdd0858  movaps [rsp+0x20], xmm14
000077a70fdd085e  lea rdi, [rsp]
000077a70fdd0862  mov esi, 0x00
000077a70fdd0867  mov rax, 0x6294188EF530
000077a70fdd0871  call rax
000077a70fdd0873  movaps xmm13, [rsp]
000077a70fdd0878  add rsp, 0x30
000077a70fdd087c  vmovaps xmm0, [rsp]
000077a70fdd0881  vmovaps xmm1, [rsp+0x10]
000077a70fdd0887  vmovaps xmm2, [rsp+0x20]
000077a70fdd088d  vmovaps xmm3, [rsp+0x30]
000077a70fdd0893  vmovaps xmm4, [rsp+0x40]
000077a70fdd0899  vmovaps xmm5, [rsp+0x50]
000077a70fdd089f  vmovaps xmm6, [rsp+0x60]
000077a70fdd08a5  vmovaps xmm7, [rsp+0x70]
000077a70fdd08ab  vmovaps xmm8, [rsp+0x80]
000077a70fdd08b4  vmovaps xmm9, [rsp+0x90]
000077a70fdd08bd  vmovaps xmm10, [rsp+0xA0]
000077a70fdd08c6  vmovaps xmm11, [rsp+0xB0]
000077a70fdd08cf  vmovaps xmm12, [rsp+0xC0]
000077a70fdd08d8  vmovaps xmm14, [rsp+0xD0]
000077a70fdd08e1  vmovaps xmm15, [rsp+0xE0]
000077a70fdd08ea  add rsp, 0xF0
000077a70fdd08f1  pop r11
000077a70fdd08f3  pop r10
000077a70fdd08f5  pop r9
000077a70fdd08f7  pop r8
000077a70fdd08f9  pop rsi
000077a70fdd08fa  pop rdi
000077a70fdd08fb  pop rdx
000077a70fdd08fc  pop rcx
000077a70fdd08fd  pop rax
000077a70fdd08fe  add rsp, 0x08
000077a70fdd0902  jmp 0x000077A70FDCF5CF
000077a70fdd0907  sub rsp, 0x08
000077a70fdd090b  push rax
000077a70fdd090c  push rcx
000077a70fdd090d  push rdx
000077a70fdd090e  push rdi
000077a70fdd090f  push rsi
000077a70fdd0910  push r8
000077a70fdd0912  push r9
000077a70fdd0914  push r10
000077a70fdd0916  push r11
000077a70fdd0918  sub rsp, 0xF0
000077a70fdd091f  vmovaps [rsp], xmm0
000077a70fdd0924  vmovaps [rsp+0x10], xmm1
000077a70fdd092a  vmovaps [rsp+0x20], xmm2
000077a70fdd0930  vmovaps [rsp+0x30], xmm3
000077a70fdd0936  vmovaps [rsp+0x40], xmm4
000077a70fdd093c  vmovaps [rsp+0x50], xmm5
000077a70fdd0942  vmovaps [rsp+0x60], xmm6
000077a70fdd0948  vmovaps [rsp+0x70], xmm7
000077a70fdd094e  vmovaps [rsp+0x80], xmm8
000077a70fdd0957  vmovaps [rsp+0x90], xmm9
000077a70fdd0960  vmovaps [rsp+0xA0], xmm10
000077a70fdd0969  vmovaps [rsp+0xB0], xmm11
000077a70fdd0972  vmovaps [rsp+0xC0], xmm12
000077a70fdd097b  vmovaps [rsp+0xD0], xmm13
000077a70fdd0984  vmovaps [rsp+0xE0], xmm14
000077a70fdd098d  sub rsp, 0x30
000077a70fdd0991  movaps [rsp], xmm15
000077a70fdd0996  movaps [rsp+0x10], xmm14
000077a70fdd099c  movaps [rsp+0x20], xmm1
000077a70fdd09a1  lea rdi, [rsp]
000077a70fdd09a5  mov esi, 0x00
000077a70fdd09aa  mov rax, 0x6294188EF530
000077a70fdd09b4  call rax
000077a70fdd09b6  movaps xmm15, [rsp]
000077a70fdd09bb  add rsp, 0x30
000077a70fdd09bf  vmovaps xmm0, [rsp]
000077a70fdd09c4  vmovaps xmm1, [rsp+0x10]
000077a70fdd09ca  vmovaps xmm2, [rsp+0x20]
000077a70fdd09d0  vmovaps xmm3, [rsp+0x30]
000077a70fdd09d6  vmovaps xmm4, [rsp+0x40]
000077a70fdd09dc  vmovaps xmm5, [rsp+0x50]
000077a70fdd09e2  vmovaps xmm6, [rsp+0x60]
000077a70fdd09e8  vmovaps xmm7, [rsp+0x70]
000077a70fdd09ee  vmovaps xmm8, [rsp+0x80]
000077a70fdd09f7  vmovaps xmm9, [rsp+0x90]
000077a70fdd0a00  vmovaps xmm10, [rsp+0xA0]
000077a70fdd0a09  vmovaps xmm11, [rsp+0xB0]
000077a70fdd0a12  vmovaps xmm12, [rsp+0xC0]
000077a70fdd0a1b  vmovaps xmm13, [rsp+0xD0]
000077a70fdd0a24  vmovaps xmm14, [rsp+0xE0]
000077a70fdd0a2d  add rsp, 0xF0
000077a70fdd0a34  pop r11
000077a70fdd0a36  pop r10
000077a70fdd0a38  pop r9
000077a70fdd0a3a  pop r8
000077a70fdd0a3c  pop rsi
000077a70fdd0a3d  pop rdi
000077a70fdd0a3e  pop rdx
000077a70fdd0a3f  pop rcx
000077a70fdd0a40  pop rax
000077a70fdd0a41  add rsp, 0x08
000077a70fdd0a45  jmp 0x000077A70FDCF617
000077a70fdd0a4a  sub rsp, 0x08
000077a70fdd0a4e  push rax
000077a70fdd0a4f  push rcx
000077a70fdd0a50  push rdx
000077a70fdd0a51  push rdi
000077a70fdd0a52  push rsi
000077a70fdd0a53  push r8
000077a70fdd0a55  push r9
000077a70fdd0a57  push r10
000077a70fdd0a59  push r11
000077a70fdd0a5b  sub rsp, 0xF0
000077a70fdd0a62  vmovaps [rsp], xmm0
000077a70fdd0a67  vmovaps [rsp+0x10], xmm2
000077a70fdd0a6d  vmovaps [rsp+0x20], xmm3
000077a70fdd0a73  vmovaps [rsp+0x30], xmm4
000077a70fdd0a79  vmovaps [rsp+0x40], xmm5
000077a70fdd0a7f  vmovaps [rsp+0x50], xmm6
000077a70fdd0a85  vmovaps [rsp+0x60], xmm7
000077a70fdd0a8b  vmovaps [rsp+0x70], xmm8
000077a70fdd0a91  vmovaps [rsp+0x80], xmm9
000077a70fdd0a9a  vmovaps [rsp+0x90], xmm10
000077a70fdd0aa3  vmovaps [rsp+0xA0], xmm11
000077a70fdd0aac  vmovaps [rsp+0xB0], xmm12
000077a70fdd0ab5  vmovaps [rsp+0xC0], xmm13
000077a70fdd0abe  vmovaps [rsp+0xD0], xmm14
000077a70fdd0ac7  vmovaps [rsp+0xE0], xmm15
000077a70fdd0ad0  sub rsp, 0x30
000077a70fdd0ad4  movaps [rsp], xmm1
000077a70fdd0ad8  movaps [rsp+0x10], xmm14
000077a70fdd0ade  movaps [rsp+0x20], xmm10
000077a70fdd0ae4  lea rdi, [rsp]
000077a70fdd0ae8  mov esi, 0x00
000077a70fdd0aed  mov rax, 0x6294188EF530
000077a70fdd0af7  call rax
000077a70fdd0af9  movaps xmm1, [rsp]
000077a70fdd0afd  add rsp, 0x30
000077a70fdd0b01  vmovaps xmm0, [rsp]
000077a70fdd0b06  vmovaps xmm2, [rsp+0x10]
000077a70fdd0b0c  vmovaps xmm3, [rsp+0x20]
000077a70fdd0b12  vmovaps xmm4, [rsp+0x30]
000077a70fdd0b18  vmovaps xmm5, [rsp+0x40]
000077a70fdd0b1e  vmovaps xmm6, [rsp+0x50]
000077a70fdd0b24  vmovaps xmm7, [rsp+0x60]
000077a70fdd0b2a  vmovaps xmm8, [rsp+0x70]
000077a70fdd0b30  vmovaps xmm9, [rsp+0x80]
000077a70fdd0b39  vmovaps xmm10, [rsp+0x90]
000077a70fdd0b42  vmovaps xmm11, [rsp+0xA0]
000077a70fdd0b4b  vmovaps xmm12, [rsp+0xB0]
000077a70fdd0b54  vmovaps xmm13, [rsp+0xC0]
000077a70fdd0b5d  vmovaps xmm14, [rsp+0xD0]
000077a70fdd0b66  vmovaps xmm15, [rsp+0xE0]
000077a70fdd0b6f  add rsp, 0xF0
000077a70fdd0b76  pop r11
000077a70fdd0b78  pop r10
000077a70fdd0b7a  pop r9
000077a70fdd0b7c  pop r8
000077a70fdd0b7e  pop rsi
000077a70fdd0b7f  pop rdi
000077a70fdd0b80  pop rdx
000077a70fdd0b81  pop rcx
000077a70fdd0b82  pop rax
000077a70fdd0b83  add rsp, 0x08
000077a70fdd0b87  jmp 0x000077A70FDCF631
000077a70fdd0b8c  sub rsp, 0x08
000077a70fdd0b90  push rax
000077a70fdd0b91  push rcx
000077a70fdd0b92  push rdx
000077a70fdd0b93  push rdi
000077a70fdd0b94  push rsi
000077a70fdd0b95  push r8
000077a70fdd0b97  push r9
000077a70fdd0b99  push r10
000077a70fdd0b9b  push r11
000077a70fdd0b9d  sub rsp, 0xF0
000077a70fdd0ba4  vmovaps [rsp], xmm0
000077a70fdd0ba9  vmovaps [rsp+0x10], xmm1
000077a70fdd0baf  vmovaps [rsp+0x20], xmm2
000077a70fdd0bb5  vmovaps [rsp+0x30], xmm3
000077a70fdd0bbb  vmovaps [rsp+0x40], xmm4
000077a70fdd0bc1  vmovaps [rsp+0x50], xmm5
000077a70fdd0bc7  vmovaps [rsp+0x60], xmm6
000077a70fdd0bcd  vmovaps [rsp+0x70], xmm7
000077a70fdd0bd3  vmovaps [rsp+0x80], xmm8
000077a70fdd0bdc  vmovaps [rsp+0x90], xmm9
000077a70fdd0be5  vmovaps [rsp+0xA0], xmm10
000077a70fdd0bee  vmovaps [rsp+0xB0], xmm11
000077a70fdd0bf7  vmovaps [rsp+0xC0], xmm12
000077a70fdd0c00  vmovaps [rsp+0xD0], xmm14
000077a70fdd0c09  vmovaps [rsp+0xE0], xmm15
000077a70fdd0c12  sub rsp, 0x30
000077a70fdd0c16  movaps [rsp], xmm13
000077a70fdd0c1b  movaps [rsp+0x10], xmm14
000077a70fdd0c21  movaps [rsp+0x20], xmm2
000077a70fdd0c26  lea rdi, [rsp]
000077a70fdd0c2a  mov esi, 0x00
000077a70fdd0c2f  mov rax, 0x6294188EF530
000077a70fdd0c39  call rax
000077a70fdd0c3b  movaps xmm13, [rsp]
000077a70fdd0c40  add rsp, 0x30
000077a70fdd0c44  vmovaps xmm0, [rsp]
000077a70fdd0c49  vmovaps xmm1, [rsp+0x10]
000077a70fdd0c4f  vmovaps xmm2, [rsp+0x20]
000077a70fdd0c55  vmovaps xmm3, [rsp+0x30]
000077a70fdd0c5b  vmovaps xmm4, [rsp+0x40]
000077a70fdd0c61  vmovaps xmm5, [rsp+0x50]
000077a70fdd0c67  vmovaps xmm6, [rsp+0x60]
000077a70fdd0c6d  vmovaps xmm7, [rsp+0x70]
000077a70fdd0c73  vmovaps xmm8, [rsp+0x80]
000077a70fdd0c7c  vmovaps xmm9, [rsp+0x90]
000077a70fdd0c85  vmovaps xmm10, [rsp+0xA0]
000077a70fdd0c8e  vmovaps xmm11, [rsp+0xB0]
000077a70fdd0c97  vmovaps xmm12, [rsp+0xC0]
000077a70fdd0ca0  vmovaps xmm14, [rsp+0xD0]
000077a70fdd0ca9  vmovaps xmm15, [rsp+0xE0]
000077a70fdd0cb2  add rsp, 0xF0
000077a70fdd0cb9  pop r11
000077a70fdd0cbb  pop r10
000077a70fdd0cbd  pop r9
000077a70fdd0cbf  pop r8
000077a70fdd0cc1  pop rsi
000077a70fdd0cc2  pop rdi
000077a70fdd0cc3  pop rdx
000077a70fdd0cc4  pop rcx
000077a70fdd0cc5  pop rax
000077a70fdd0cc6  add rsp, 0x08
000077a70fdd0cca  jmp 0x000077A70FDCF64C
000077a70fdd0ccf  sub rsp, 0x08
000077a70fdd0cd3  push rax
000077a70fdd0cd4  push rcx
000077a70fdd0cd5  push rdx
000077a70fdd0cd6  push rdi
000077a70fdd0cd7  push rsi
000077a70fdd0cd8  push r8
000077a70fdd0cda  push r9
000077a70fdd0cdc  push r10
000077a70fdd0cde  push r11
000077a70fdd0ce0  sub rsp, 0xF0
000077a70fdd0ce7  vmovaps [rsp], xmm0
000077a70fdd0cec  vmovaps [rsp+0x10], xmm2
000077a70fdd0cf2  vmovaps [rsp+0x20], xmm3
000077a70fdd0cf8  vmovaps [rsp+0x30], xmm4
000077a70fdd0cfe  vmovaps [rsp+0x40], xmm5
000077a70fdd0d04  vmovaps [rsp+0x50], xmm6
000077a70fdd0d0a  vmovaps [rsp+0x60], xmm7
000077a70fdd0d10  vmovaps [rsp+0x70], xmm8
000077a70fdd0d16  vmovaps [rsp+0x80], xmm9
000077a70fdd0d1f  vmovaps [rsp+0x90], xmm10
000077a70fdd0d28  vmovaps [rsp+0xA0], xmm11
000077a70fdd0d31  vmovaps [rsp+0xB0], xmm12
000077a70fdd0d3a  vmovaps [rsp+0xC0], xmm13
000077a70fdd0d43  vmovaps [rsp+0xD0], xmm14
000077a70fdd0d4c  vmovaps [rsp+0xE0], xmm15
000077a70fdd0d55  sub rsp, 0x30
000077a70fdd0d59  movaps [rsp], xmm1
000077a70fdd0d5d  movaps [rsp+0x10], xmm10
000077a70fdd0d63  movaps [rsp+0x20], xmm2
000077a70fdd0d68  lea rdi, [rsp]
000077a70fdd0d6c  mov esi, 0x00
000077a70fdd0d71  mov rax, 0x6294188EF530
000077a70fdd0d7b  call rax
000077a70fdd0d7d  movaps xmm1, [rsp]
000077a70fdd0d81  add rsp, 0x30
000077a70fdd0d85  vmovaps xmm0, [rsp]
000077a70fdd0d8a  vmovaps xmm2, [rsp+0x10]
000077a70fdd0d90  vmovaps xmm3, [rsp+0x20]
000077a70fdd0d96  vmovaps xmm4, [rsp+0x30]
000077a70fdd0d9c  vmovaps xmm5, [rsp+0x40]
000077a70fdd0da2  vmovaps xmm6, [rsp+0x50]
000077a70fdd0da8  vmovaps xmm7, [rsp+0x60]
000077a70fdd0dae  vmovaps xmm8, [rsp+0x70]
000077a70fdd0db4  vmovaps xmm9, [rsp+0x80]
000077a70fdd0dbd  vmovaps xmm10, [rsp+0x90]
000077a70fdd0dc6  vmovaps xmm11, [rsp+0xA0]
000077a70fdd0dcf  vmovaps xmm12, [rsp+0xB0]
000077a70fdd0dd8  vmovaps xmm13, [rsp+0xC0]
000077a70fdd0de1  vmovaps xmm14, [rsp+0xD0]
000077a70fdd0dea  vmovaps xmm15, [rsp+0xE0]
000077a70fdd0df3  add rsp, 0xF0
000077a70fdd0dfa  pop r11
000077a70fdd0dfc  pop r10
000077a70fdd0dfe  pop r9
000077a70fdd0e00  pop r8
000077a70fdd0e02  pop rsi
000077a70fdd0e03  pop rdi
000077a70fdd0e04  pop rdx
000077a70fdd0e05  pop rcx
000077a70fdd0e06  pop rax
000077a70fdd0e07  add rsp, 0x08
000077a70fdd0e0b  jmp 0x000077A70FDCF6B4
000077a70fdd0e10  sub rsp, 0x08
000077a70fdd0e14  push rax
000077a70fdd0e15  push rcx
000077a70fdd0e16  push rdx
000077a70fdd0e17  push rdi
000077a70fdd0e18  push rsi
000077a70fdd0e19  push r8
000077a70fdd0e1b  push r9
000077a70fdd0e1d  push r10
000077a70fdd0e1f  push r11
000077a70fdd0e21  sub rsp, 0xF0
000077a70fdd0e28  vmovaps [rsp], xmm0
000077a70fdd0e2d  vmovaps [rsp+0x10], xmm1
000077a70fdd0e33  vmovaps [rsp+0x20], xmm2
000077a70fdd0e39  vmovaps [rsp+0x30], xmm3
000077a70fdd0e3f  vmovaps [rsp+0x40], xmm4
000077a70fdd0e45  vmovaps [rsp+0x50], xmm5
000077a70fdd0e4b  vmovaps [rsp+0x60], xmm6
000077a70fdd0e51  vmovaps [rsp+0x70], xmm7
000077a70fdd0e57  vmovaps [rsp+0x80], xmm8
000077a70fdd0e60  vmovaps [rsp+0x90], xmm9
000077a70fdd0e69  vmovaps [rsp+0xA0], xmm10
000077a70fdd0e72  vmovaps [rsp+0xB0], xmm11
000077a70fdd0e7b  vmovaps [rsp+0xC0], xmm12
000077a70fdd0e84  vmovaps [rsp+0xD0], xmm13
000077a70fdd0e8d  vmovaps [rsp+0xE0], xmm14
000077a70fdd0e96  sub rsp, 0x30
000077a70fdd0e9a  movaps [rsp], xmm15
000077a70fdd0e9f  movaps [rsp+0x10], xmm10
000077a70fdd0ea5  movaps [rsp+0x20], xmm2
000077a70fdd0eaa  lea rdi, [rsp]
000077a70fdd0eae  mov esi, 0x00
000077a70fdd0eb3  mov rax, 0x6294188EF530
000077a70fdd0ebd  call rax
000077a70fdd0ebf  movaps xmm15, [rsp]
000077a70fdd0ec4  add rsp, 0x30
000077a70fdd0ec8  vmovaps xmm0, [rsp]
000077a70fdd0ecd  vmovaps xmm1, [rsp+0x10]
000077a70fdd0ed3  vmovaps xmm2, [rsp+0x20]
000077a70fdd0ed9  vmovaps xmm3, [rsp+0x30]
000077a70fdd0edf  vmovaps xmm4, [rsp+0x40]
000077a70fdd0ee5  vmovaps xmm5, [rsp+0x50]
000077a70fdd0eeb  vmovaps xmm6, [rsp+0x60]
000077a70fdd0ef1  vmovaps xmm7, [rsp+0x70]
000077a70fdd0ef7  vmovaps xmm8, [rsp+0x80]
000077a70fdd0f00  vmovaps xmm9, [rsp+0x90]
000077a70fdd0f09  vmovaps xmm10, [rsp+0xA0]
000077a70fdd0f12  vmovaps xmm11, [rsp+0xB0]
000077a70fdd0f1b  vmovaps xmm12, [rsp+0xC0]
000077a70fdd0f24  vmovaps xmm13, [rsp+0xD0]
000077a70fdd0f2d  vmovaps xmm14, [rsp+0xE0]
000077a70fdd0f36  add rsp, 0xF0
000077a70fdd0f3d  pop r11
000077a70fdd0f3f  pop r10
000077a70fdd0f41  pop r9
000077a70fdd0f43  pop r8
000077a70fdd0f45  pop rsi
000077a70fdd0f46  pop rdi
000077a70fdd0f47  pop rdx
000077a70fdd0f48  pop rcx
000077a70fdd0f49  pop rax
000077a70fdd0f4a  add rsp, 0x08
000077a70fdd0f4e  jmp 0x000077A70FDCF706
000077a70fdd0f53  sub rsp, 0x08
000077a70fdd0f57  push rax
000077a70fdd0f58  push rcx
000077a70fdd0f59  push rdx
000077a70fdd0f5a  push rdi
000077a70fdd0f5b  push rsi
000077a70fdd0f5c  push r8
000077a70fdd0f5e  push r9
000077a70fdd0f60  push r10
000077a70fdd0f62  push r11
000077a70fdd0f64  sub rsp, 0xF0
000077a70fdd0f6b  vmovaps [rsp], xmm0
000077a70fdd0f70  vmovaps [rsp+0x10], xmm2
000077a70fdd0f76  vmovaps [rsp+0x20], xmm3
000077a70fdd0f7c  vmovaps [rsp+0x30], xmm4
000077a70fdd0f82  vmovaps [rsp+0x40], xmm5
000077a70fdd0f88  vmovaps [rsp+0x50], xmm6
000077a70fdd0f8e  vmovaps [rsp+0x60], xmm7
000077a70fdd0f94  vmovaps [rsp+0x70], xmm8
000077a70fdd0f9a  vmovaps [rsp+0x80], xmm9
000077a70fdd0fa3  vmovaps [rsp+0x90], xmm10
000077a70fdd0fac  vmovaps [rsp+0xA0], xmm11
000077a70fdd0fb5  vmovaps [rsp+0xB0], xmm12
000077a70fdd0fbe  vmovaps [rsp+0xC0], xmm13
000077a70fdd0fc7  vmovaps [rsp+0xD0], xmm14
000077a70fdd0fd0  vmovaps [rsp+0xE0], xmm15
000077a70fdd0fd9  sub rsp, 0x30
000077a70fdd0fdd  movaps [rsp], xmm1
000077a70fdd0fe1  movaps [rsp+0x10], xmm10
000077a70fdd0fe7  movaps [rsp+0x20], xmm12
000077a70fdd0fed  lea rdi, [rsp]
000077a70fdd0ff1  mov esi, 0x00
000077a70fdd0ff6  mov rax, 0x6294188EF530
000077a70fdd1000  call rax
000077a70fdd1002  movaps xmm1, [rsp]
000077a70fdd1006  add rsp, 0x30
000077a70fdd100a  vmovaps xmm0, [rsp]
000077a70fdd100f  vmovaps xmm2, [rsp+0x10]
000077a70fdd1015  vmovaps xmm3, [rsp+0x20]
000077a70fdd101b  vmovaps xmm4, [rsp+0x30]
000077a70fdd1021  vmovaps xmm5, [rsp+0x40]
000077a70fdd1027  vmovaps xmm6, [rsp+0x50]
000077a70fdd102d  vmovaps xmm7, [rsp+0x60]
000077a70fdd1033  vmovaps xmm8, [rsp+0x70]
000077a70fdd1039  vmovaps xmm9, [rsp+0x80]
000077a70fdd1042  vmovaps xmm10, [rsp+0x90]
000077a70fdd104b  vmovaps xmm11, [rsp+0xA0]
000077a70fdd1054  vmovaps xmm12, [rsp+0xB0]
000077a70fdd105d  vmovaps xmm13, [rsp+0xC0]
000077a70fdd1066  vmovaps xmm14, [rsp+0xD0]
000077a70fdd106f  vmovaps xmm15, [rsp+0xE0]
000077a70fdd1078  add rsp, 0xF0
000077a70fdd107f  pop r11
000077a70fdd1081  pop r10
000077a70fdd1083  pop r9
000077a70fdd1085  pop r8
000077a70fdd1087  pop rsi
000077a70fdd1088  pop rdi
000077a70fdd1089  pop rdx
000077a70fdd108a  pop rcx
000077a70fdd108b  pop rax
000077a70fdd108c  add rsp, 0x08
000077a70fdd1090  jmp 0x000077A70FDCF732
000077a70fdd1095  sub rsp, 0x08
000077a70fdd1099  push rax
000077a70fdd109a  push rcx
000077a70fdd109b  push rdx
000077a70fdd109c  push rdi
000077a70fdd109d  push rsi
000077a70fdd109e  push r8
000077a70fdd10a0  push r9
000077a70fdd10a2  push r10
000077a70fdd10a4  push r11
000077a70fdd10a6  sub rsp, 0xF0
000077a70fdd10ad  vmovaps [rsp], xmm0
000077a70fdd10b2  vmovaps [rsp+0x10], xmm1
000077a70fdd10b8  vmovaps [rsp+0x20], xmm2
000077a70fdd10be  vmovaps [rsp+0x30], xmm3
000077a70fdd10c4  vmovaps [rsp+0x40], xmm4
000077a70fdd10ca  vmovaps [rsp+0x50], xmm5
000077a70fdd10d0  vmovaps [rsp+0x60], xmm6
000077a70fdd10d6  vmovaps [rsp+0x70], xmm7
000077a70fdd10dc  vmovaps [rsp+0x80], xmm8
000077a70fdd10e5  vmovaps [rsp+0x90], xmm9
000077a70fdd10ee  vmovaps [rsp+0xA0], xmm10
000077a70fdd10f7  vmovaps [rsp+0xB0], xmm11
000077a70fdd1100  vmovaps [rsp+0xC0], xmm12
000077a70fdd1109  vmovaps [rsp+0xD0], xmm13
000077a70fdd1112  vmovaps [rsp+0xE0], xmm14
000077a70fdd111b  sub rsp, 0x30
000077a70fdd111f  movaps [rsp], xmm15
000077a70fdd1124  movaps [rsp+0x10], xmm10
000077a70fdd112a  movaps [rsp+0x20], xmm12
000077a70fdd1130  lea rdi, [rsp]
000077a70fdd1134  mov esi, 0x00
000077a70fdd1139  mov rax, 0x6294188EF530
000077a70fdd1143  call rax
000077a70fdd1145  movaps xmm15, [rsp]
000077a70fdd114a  add rsp, 0x30
000077a70fdd114e  vmovaps xmm0, [rsp]
000077a70fdd1153  vmovaps xmm1, [rsp+0x10]
000077a70fdd1159  vmovaps xmm2, [rsp+0x20]
000077a70fdd115f  vmovaps xmm3, [rsp+0x30]
000077a70fdd1165  vmovaps xmm4, [rsp+0x40]
000077a70fdd116b  vmovaps xmm5, [rsp+0x50]
000077a70fdd1171  vmovaps xmm6, [rsp+0x60]
000077a70fdd1177  vmovaps xmm7, [rsp+0x70]
000077a70fdd117d  vmovaps xmm8, [rsp+0x80]
000077a70fdd1186  vmovaps xmm9, [rsp+0x90]
000077a70fdd118f  vmovaps xmm10, [rsp+0xA0]
000077a70fdd1198  vmovaps xmm11, [rsp+0xB0]
000077a70fdd11a1  vmovaps xmm12, [rsp+0xC0]
000077a70fdd11aa  vmovaps xmm13, [rsp+0xD0]
000077a70fdd11b3  vmovaps xmm14, [rsp+0xE0]
000077a70fdd11bc  add rsp, 0xF0
000077a70fdd11c3  pop r11
000077a70fdd11c5  pop r10
000077a70fdd11c7  pop r9
000077a70fdd11c9  pop r8
000077a70fdd11cb  pop rsi
000077a70fdd11cc  pop rdi
000077a70fdd11cd  pop rdx
000077a70fdd11ce  pop rcx
000077a70fdd11cf  pop rax
000077a70fdd11d0  add rsp, 0x08
000077a70fdd11d4  jmp 0x000077A70FDCF75E
000077a70fdd11d9  call 0x000077A70FBFF430
000077a70fdd11de  jmp 0x000077A70FDCF7EE
000077a70fdd11e3  call 0x000077A70FBFF430
000077a70fdd11e8  jmp 0x000077A70FDCF801
000077a70fdd11ed  sub rsp, 0x08
000077a70fdd11f1  push rax
000077a70fdd11f2  push rcx
000077a70fdd11f3  push rdx
000077a70fdd11f4  push rdi
000077a70fdd11f5  push rsi
000077a70fdd11f6  push r8
000077a70fdd11f8  push r9
000077a70fdd11fa  push r10
000077a70fdd11fc  push r11
000077a70fdd11fe  sub rsp, 0xF0
000077a70fdd1205  vmovaps [rsp], xmm0
000077a70fdd120a  vmovaps [rsp+0x10], xmm2
000077a70fdd1210  vmovaps [rsp+0x20], xmm3
000077a70fdd1216  vmovaps [rsp+0x30], xmm4
000077a70fdd121c  vmovaps [rsp+0x40], xmm5
000077a70fdd1222  vmovaps [rsp+0x50], xmm6
000077a70fdd1228  vmovaps [rsp+0x60], xmm7
000077a70fdd122e  vmovaps [rsp+0x70], xmm8
000077a70fdd1234  vmovaps [rsp+0x80], xmm9
000077a70fdd123d  vmovaps [rsp+0x90], xmm10
000077a70fdd1246  vmovaps [rsp+0xA0], xmm11
000077a70fdd124f  vmovaps [rsp+0xB0], xmm12
000077a70fdd1258  vmovaps [rsp+0xC0], xmm13
000077a70fdd1261  vmovaps [rsp+0xD0], xmm14
000077a70fdd126a  vmovaps [rsp+0xE0], xmm15
000077a70fdd1273  sub rsp, 0x30
000077a70fdd1277  movaps [rsp], xmm1
000077a70fdd127b  movaps [rsp+0x10], xmm13
000077a70fdd1281  movaps [rsp+0x20], xmm2
000077a70fdd1286  lea rdi, [rsp]
000077a70fdd128a  mov esi, 0x00
000077a70fdd128f  mov rax, 0x6294188EF530
000077a70fdd1299  call rax
000077a70fdd129b  movaps xmm1, [rsp]
000077a70fdd129f  add rsp, 0x30
000077a70fdd12a3  vmovaps xmm0, [rsp]
000077a70fdd12a8  vmovaps xmm2, [rsp+0x10]
000077a70fdd12ae  vmovaps xmm3, [rsp+0x20]
000077a70fdd12b4  vmovaps xmm4, [rsp+0x30]
000077a70fdd12ba  vmovaps xmm5, [rsp+0x40]
000077a70fdd12c0  vmovaps xmm6, [rsp+0x50]
000077a70fdd12c6  vmovaps xmm7, [rsp+0x60]
000077a70fdd12cc  vmovaps xmm8, [rsp+0x70]
000077a70fdd12d2  vmovaps xmm9, [rsp+0x80]
000077a70fdd12db  vmovaps xmm10, [rsp+0x90]
000077a70fdd12e4  vmovaps xmm11, [rsp+0xA0]
000077a70fdd12ed  vmovaps xmm12, [rsp+0xB0]
000077a70fdd12f6  vmovaps xmm13, [rsp+0xC0]
000077a70fdd12ff  vmovaps xmm14, [rsp+0xD0]
000077a70fdd1308  vmovaps xmm15, [rsp+0xE0]
000077a70fdd1311  add rsp, 0xF0
000077a70fdd1318  pop r11
000077a70fdd131a  pop r10
000077a70fdd131c  pop r9
000077a70fdd131e  pop r8
000077a70fdd1320  pop rsi
000077a70fdd1321  pop rdi
000077a70fdd1322  pop rdx
000077a70fdd1323  pop rcx
000077a70fdd1324  pop rax
000077a70fdd1325  add rsp, 0x08
000077a70fdd1329  jmp 0x000077A70FDCF82C
000077a70fdd132e  call 0x000077A70FC0E760
000077a70fdd1333  jmp 0x000077A70FDCF839
000077a70fdd1338  sub rsp, 0x08
000077a70fdd133c  push rax
000077a70fdd133d  push rcx
000077a70fdd133e  push rdx
000077a70fdd133f  push rdi
000077a70fdd1340  push rsi
000077a70fdd1341  push r8
000077a70fdd1343  push r9
000077a70fdd1345  push r10
000077a70fdd1347  push r11
000077a70fdd1349  sub rsp, 0xF0
000077a70fdd1350  vmovaps [rsp], xmm0
000077a70fdd1355  vmovaps [rsp+0x10], xmm1
000077a70fdd135b  vmovaps [rsp+0x20], xmm2
000077a70fdd1361  vmovaps [rsp+0x30], xmm3
000077a70fdd1367  vmovaps [rsp+0x40], xmm4
000077a70fdd136d  vmovaps [rsp+0x50], xmm5
000077a70fdd1373  vmovaps [rsp+0x60], xmm6
000077a70fdd1379  vmovaps [rsp+0x70], xmm7
000077a70fdd137f  vmovaps [rsp+0x80], xmm8
000077a70fdd1388  vmovaps [rsp+0x90], xmm9
000077a70fdd1391  vmovaps [rsp+0xA0], xmm10
000077a70fdd139a  vmovaps [rsp+0xB0], xmm11
000077a70fdd13a3  vmovaps [rsp+0xC0], xmm12
000077a70fdd13ac  vmovaps [rsp+0xD0], xmm14
000077a70fdd13b5  vmovaps [rsp+0xE0], xmm15
000077a70fdd13be  sub rsp, 0x30
000077a70fdd13c2  movaps [rsp], xmm13
000077a70fdd13c7  movaps [rsp+0x10], xmm2
000077a70fdd13cc  movaps [rsp+0x20], xmm1
000077a70fdd13d1  lea rdi, [rsp]
000077a70fdd13d5  mov esi, 0x00
000077a70fdd13da  mov rax, 0x6294188EF530
000077a70fdd13e4  call rax
000077a70fdd13e6  movaps xmm13, [rsp]
000077a70fdd13eb  add rsp, 0x30
000077a70fdd13ef  vmovaps xmm0, [rsp]
000077a70fdd13f4  vmovaps xmm1, [rsp+0x10]
000077a70fdd13fa  vmovaps xmm2, [rsp+0x20]
000077a70fdd1400  vmovaps xmm3, [rsp+0x30]
000077a70fdd1406  vmovaps xmm4, [rsp+0x40]
000077a70fdd140c  vmovaps xmm5, [rsp+0x50]
000077a70fdd1412  vmovaps xmm6, [rsp+0x60]
000077a70fdd1418  vmovaps xmm7, [rsp+0x70]
000077a70fdd141e  vmovaps xmm8, [rsp+0x80]
000077a70fdd1427  vmovaps xmm9, [rsp+0x90]
000077a70fdd1430  vmovaps xmm10, [rsp+0xA0]
000077a70fdd1439  vmovaps xmm11, [rsp+0xB0]
000077a70fdd1442  vmovaps xmm12, [rsp+0xC0]
000077a70fdd144b  vmovaps xmm14, [rsp+0xD0]
000077a70fdd1454  vmovaps xmm15, [rsp+0xE0]
000077a70fdd145d  add rsp, 0xF0
000077a70fdd1464  pop r11
000077a70fdd1466  pop r10
000077a70fdd1468  pop r9
000077a70fdd146a  pop r8
000077a70fdd146c  pop rsi
000077a70fdd146d  pop rdi
000077a70fdd146e  pop rdx
000077a70fdd146f  pop rcx
000077a70fdd1470  pop rax
000077a70fdd1471  add rsp, 0x08
000077a70fdd1475  jmp 0x000077A70FDCF878
000077a70fdd147a  sub rsp, 0x08
000077a70fdd147e  push rax
000077a70fdd147f  push rcx
000077a70fdd1480  push rdx
000077a70fdd1481  push rdi
000077a70fdd1482  push rsi
000077a70fdd1483  push r8
000077a70fdd1485  push r9
000077a70fdd1487  push r10
000077a70fdd1489  push r11
000077a70fdd148b  sub rsp, 0xF0
000077a70fdd1492  vmovaps [rsp], xmm0
000077a70fdd1497  vmovaps [rsp+0x10], xmm2
000077a70fdd149d  vmovaps [rsp+0x20], xmm3
000077a70fdd14a3  vmovaps [rsp+0x30], xmm4
000077a70fdd14a9  vmovaps [rsp+0x40], xmm5
000077a70fdd14af  vmovaps [rsp+0x50], xmm6
000077a70fdd14b5  vmovaps [rsp+0x60], xmm7
000077a70fdd14bb  vmovaps [rsp+0x70], xmm8
000077a70fdd14c1  vmovaps [rsp+0x80], xmm9
000077a70fdd14ca  vmovaps [rsp+0x90], xmm10
000077a70fdd14d3  vmovaps [rsp+0xA0], xmm11
000077a70fdd14dc  vmovaps [rsp+0xB0], xmm12
000077a70fdd14e5  vmovaps [rsp+0xC0], xmm13
000077a70fdd14ee  vmovaps [rsp+0xD0], xmm14
000077a70fdd14f7  vmovaps [rsp+0xE0], xmm15
000077a70fdd1500  sub rsp, 0x30
000077a70fdd1504  movaps [rsp], xmm1
000077a70fdd1508  movaps [rsp+0x10], xmm15
000077a70fdd150e  movaps [rsp+0x20], xmm2
000077a70fdd1513  lea rdi, [rsp]
000077a70fdd1517  mov esi, 0x00
000077a70fdd151c  mov rax, 0x6294188EF530
000077a70fdd1526  call rax
000077a70fdd1528  movaps xmm1, [rsp]
000077a70fdd152c  add rsp, 0x30
000077a70fdd1530  vmovaps xmm0, [rsp]
000077a70fdd1535  vmovaps xmm2, [rsp+0x10]
000077a70fdd153b  vmovaps xmm3, [rsp+0x20]
000077a70fdd1541  vmovaps xmm4, [rsp+0x30]
000077a70fdd1547  vmovaps xmm5, [rsp+0x40]
000077a70fdd154d  vmovaps xmm6, [rsp+0x50]
000077a70fdd1553  vmovaps xmm7, [rsp+0x60]
000077a70fdd1559  vmovaps xmm8, [rsp+0x70]
000077a70fdd155f  vmovaps xmm9, [rsp+0x80]
000077a70fdd1568  vmovaps xmm10, [rsp+0x90]
000077a70fdd1571  vmovaps xmm11, [rsp+0xA0]
000077a70fdd157a  vmovaps xmm12, [rsp+0xB0]
000077a70fdd1583  vmovaps xmm13, [rsp+0xC0]
000077a70fdd158c  vmovaps xmm14, [rsp+0xD0]
000077a70fdd1595  vmovaps xmm15, [rsp+0xE0]
000077a70fdd159e  add rsp, 0xF0
000077a70fdd15a5  pop r11
000077a70fdd15a7  pop r10
000077a70fdd15a9  pop r9
000077a70fdd15ab  pop r8
000077a70fdd15ad  pop rsi
000077a70fdd15ae  pop rdi
000077a70fdd15af  pop rdx
000077a70fdd15b0  pop rcx
000077a70fdd15b1  pop rax
000077a70fdd15b2  add rsp, 0x08
000077a70fdd15b6  jmp 0x000077A70FDCF8AC
000077a70fdd15bb  sub rsp, 0x08
000077a70fdd15bf  push rax
000077a70fdd15c0  push rcx
000077a70fdd15c1  push rdx
000077a70fdd15c2  push rdi
000077a70fdd15c3  push rsi
000077a70fdd15c4  push r8
000077a70fdd15c6  push r9
000077a70fdd15c8  push r10
000077a70fdd15ca  push r11
000077a70fdd15cc  sub rsp, 0xF0
000077a70fdd15d3  vmovaps [rsp], xmm0
000077a70fdd15d8  vmovaps [rsp+0x10], xmm1
000077a70fdd15de  vmovaps [rsp+0x20], xmm2
000077a70fdd15e4  vmovaps [rsp+0x30], xmm3
000077a70fdd15ea  vmovaps [rsp+0x40], xmm4
000077a70fdd15f0  vmovaps [rsp+0x50], xmm5
000077a70fdd15f6  vmovaps [rsp+0x60], xmm6
000077a70fdd15fc  vmovaps [rsp+0x70], xmm7
000077a70fdd1602  vmovaps [rsp+0x80], xmm8
000077a70fdd160b  vmovaps [rsp+0x90], xmm9
000077a70fdd1614  vmovaps [rsp+0xA0], xmm10
000077a70fdd161d  vmovaps [rsp+0xB0], xmm11
000077a70fdd1626  vmovaps [rsp+0xC0], xmm12
000077a70fdd162f  vmovaps [rsp+0xD0], xmm13
000077a70fdd1638  vmovaps [rsp+0xE0], xmm15
000077a70fdd1641  sub rsp, 0x30
000077a70fdd1645  movaps [rsp], xmm14
000077a70fdd164a  movaps [rsp+0x10], xmm2
000077a70fdd164f  movaps [rsp+0x20], xmm15
000077a70fdd1655  lea rdi, [rsp]
000077a70fdd1659  mov esi, 0x00
000077a70fdd165e  mov rax, 0x6294188EF530
000077a70fdd1668  call rax
000077a70fdd166a  movaps xmm14, [rsp]
000077a70fdd166f  add rsp, 0x30
000077a70fdd1673  vmovaps xmm0, [rsp]
000077a70fdd1678  vmovaps xmm1, [rsp+0x10]
000077a70fdd167e  vmovaps xmm2, [rsp+0x20]
000077a70fdd1684  vmovaps xmm3, [rsp+0x30]
000077a70fdd168a  vmovaps xmm4, [rsp+0x40]
000077a70fdd1690  vmovaps xmm5, [rsp+0x50]
000077a70fdd1696  vmovaps xmm6, [rsp+0x60]
000077a70fdd169c  vmovaps xmm7, [rsp+0x70]
000077a70fdd16a2  vmovaps xmm8, [rsp+0x80]
000077a70fdd16ab  vmovaps xmm9, [rsp+0x90]
000077a70fdd16b4  vmovaps xmm10, [rsp+0xA0]
000077a70fdd16bd  vmovaps xmm11, [rsp+0xB0]
000077a70fdd16c6  vmovaps xmm12, [rsp+0xC0]
000077a70fdd16cf  vmovaps xmm13, [rsp+0xD0]
000077a70fdd16d8  vmovaps xmm15, [rsp+0xE0]
000077a70fdd16e1  add rsp, 0xF0
000077a70fdd16e8  pop r11
000077a70fdd16ea  pop r10
000077a70fdd16ec  pop r9
000077a70fdd16ee  pop r8
000077a70fdd16f0  pop rsi
000077a70fdd16f1  pop rdi
000077a70fdd16f2  pop rdx
000077a70fdd16f3  pop rcx
000077a70fdd16f4  pop rax
000077a70fdd16f5  add rsp, 0x08
000077a70fdd16f9  jmp 0x000077A70FDCF8E7
000077a70fdd16fe  sub rsp, 0x08
000077a70fdd1702  push rax
000077a70fdd1703  push rcx
000077a70fdd1704  push rdx
000077a70fdd1705  push rdi
000077a70fdd1706  push rsi
000077a70fdd1707  push r8
000077a70fdd1709  push r9
000077a70fdd170b  push r10
000077a70fdd170d  push r11
000077a70fdd170f  sub rsp, 0xF0
000077a70fdd1716  vmovaps [rsp], xmm0
000077a70fdd171b  vmovaps [rsp+0x10], xmm1
000077a70fdd1721  vmovaps [rsp+0x20], xmm2
000077a70fdd1727  vmovaps [rsp+0x30], xmm3
000077a70fdd172d  vmovaps [rsp+0x40], xmm4
000077a70fdd1733  vmovaps [rsp+0x50], xmm5
000077a70fdd1739  vmovaps [rsp+0x60], xmm6
000077a70fdd173f  vmovaps [rsp+0x70], xmm7
000077a70fdd1745  vmovaps [rsp+0x80], xmm8
000077a70fdd174e  vmovaps [rsp+0x90], xmm9
000077a70fdd1757  vmovaps [rsp+0xA0], xmm10
000077a70fdd1760  vmovaps [rsp+0xB0], xmm11
000077a70fdd1769  vmovaps [rsp+0xC0], xmm12
000077a70fdd1772  vmovaps [rsp+0xD0], xmm13
000077a70fdd177b  vmovaps [rsp+0xE0], xmm14
000077a70fdd1784  sub rsp, 0x30
000077a70fdd1788  movaps [rsp], xmm15
000077a70fdd178d  movaps [rsp+0x10], xmm2
000077a70fdd1792  movaps [rsp+0x20], xmm1
000077a70fdd1797  lea rdi, [rsp]
000077a70fdd179b  mov esi, 0x00
000077a70fdd17a0  mov rax, 0x6294188EF530
000077a70fdd17aa  call rax
000077a70fdd17ac  movaps xmm15, [rsp]
000077a70fdd17b1  add rsp, 0x30
000077a70fdd17b5  vmovaps xmm0, [rsp]
000077a70fdd17ba  vmovaps xmm1, [rsp+0x10]
000077a70fdd17c0  vmovaps xmm2, [rsp+0x20]
000077a70fdd17c6  vmovaps xmm3, [rsp+0x30]
000077a70fdd17cc  vmovaps xmm4, [rsp+0x40]
000077a70fdd17d2  vmovaps xmm5, [rsp+0x50]
000077a70fdd17d8  vmovaps xmm6, [rsp+0x60]
000077a70fdd17de  vmovaps xmm7, [rsp+0x70]
000077a70fdd17e4  vmovaps xmm8, [rsp+0x80]
000077a70fdd17ed  vmovaps xmm9, [rsp+0x90]
000077a70fdd17f6  vmovaps xmm10, [rsp+0xA0]
000077a70fdd17ff  vmovaps xmm11, [rsp+0xB0]
000077a70fdd1808  vmovaps xmm12, [rsp+0xC0]
000077a70fdd1811  vmovaps xmm13, [rsp+0xD0]
000077a70fdd181a  vmovaps xmm14, [rsp+0xE0]
000077a70fdd1823  add rsp, 0xF0
000077a70fdd182a  pop r11
000077a70fdd182c  pop r10
000077a70fdd182e  pop r9
000077a70fdd1830  pop r8
000077a70fdd1832  pop rsi
000077a70fdd1833  pop rdi
000077a70fdd1834  pop rdx
000077a70fdd1835  pop rcx
000077a70fdd1836  pop rax
000077a70fdd1837  add rsp, 0x08
000077a70fdd183b  jmp 0x000077A70FDCF923
000077a70fdd1840  call 0x000077A70FBFF430
000077a70fdd1845  jmp 0x000077A70FDCF930
000077a70fdd184a  sub rsp, 0x08
000077a70fdd184e  push rax
000077a70fdd184f  push rcx
000077a70fdd1850  push rdx
000077a70fdd1851  push rdi
000077a70fdd1852  push rsi
000077a70fdd1853  push r8
000077a70fdd1855  push r9
000077a70fdd1857  push r10
000077a70fdd1859  push r11
000077a70fdd185b  sub rsp, 0xF0
000077a70fdd1862  vmovaps [rsp], xmm0
000077a70fdd1867  vmovaps [rsp+0x10], xmm1
000077a70fdd186d  vmovaps [rsp+0x20], xmm3
000077a70fdd1873  vmovaps [rsp+0x30], xmm4
000077a70fdd1879  vmovaps [rsp+0x40], xmm5
000077a70fdd187f  vmovaps [rsp+0x50], xmm6
000077a70fdd1885  vmovaps [rsp+0x60], xmm7
000077a70fdd188b  vmovaps [rsp+0x70], xmm8
000077a70fdd1891  vmovaps [rsp+0x80], xmm9
000077a70fdd189a  vmovaps [rsp+0x90], xmm10
000077a70fdd18a3  vmovaps [rsp+0xA0], xmm11
000077a70fdd18ac  vmovaps [rsp+0xB0], xmm12
000077a70fdd18b5  vmovaps [rsp+0xC0], xmm13
000077a70fdd18be  vmovaps [rsp+0xD0], xmm14
000077a70fdd18c7  vmovaps [rsp+0xE0], xmm15
000077a70fdd18d0  sub rsp, 0x30
000077a70fdd18d4  movaps [rsp], xmm2
000077a70fdd18d8  movaps [rsp+0x10], xmm1
000077a70fdd18dd  movaps [rsp+0x20], xmm14
000077a70fdd18e3  lea rdi, [rsp]
000077a70fdd18e7  mov esi, 0x00
000077a70fdd18ec  mov rax, 0x6294188EF530
000077a70fdd18f6  call rax
000077a70fdd18f8  movaps xmm2, [rsp]
000077a70fdd18fc  add rsp, 0x30
000077a70fdd1900  vmovaps xmm0, [rsp]
000077a70fdd1905  vmovaps xmm1, [rsp+0x10]
000077a70fdd190b  vmovaps xmm3, [rsp+0x20]
000077a70fdd1911  vmovaps xmm4, [rsp+0x30]
000077a70fdd1917  vmovaps xmm5, [rsp+0x40]
000077a70fdd191d  vmovaps xmm6, [rsp+0x50]
000077a70fdd1923  vmovaps xmm7, [rsp+0x60]
000077a70fdd1929  vmovaps xmm8, [rsp+0x70]
000077a70fdd192f  vmovaps xmm9, [rsp+0x80]
000077a70fdd1938  vmovaps xmm10, [rsp+0x90]
000077a70fdd1941  vmovaps xmm11, [rsp+0xA0]
000077a70fdd194a  vmovaps xmm12, [rsp+0xB0]
000077a70fdd1953  vmovaps xmm13, [rsp+0xC0]
000077a70fdd195c  vmovaps xmm14, [rsp+0xD0]
000077a70fdd1965  vmovaps xmm15, [rsp+0xE0]
000077a70fdd196e  add rsp, 0xF0
000077a70fdd1975  pop r11
000077a70fdd1977  pop r10
000077a70fdd1979  pop r9
000077a70fdd197b  pop r8
000077a70fdd197d  pop rsi
000077a70fdd197e  pop rdi
000077a70fdd197f  pop rdx
000077a70fdd1980  pop rcx
000077a70fdd1981  pop rax
000077a70fdd1982  add rsp, 0x08
000077a70fdd1986  jmp 0x000077A70FDCF96D
000077a70fdd198b  sub rsp, 0x08
000077a70fdd198f  push rax
000077a70fdd1990  push rcx
000077a70fdd1991  push rdx
000077a70fdd1992  push rdi
000077a70fdd1993  push rsi
000077a70fdd1994  push r8
000077a70fdd1996  push r9
000077a70fdd1998  push r10
000077a70fdd199a  push r11
000077a70fdd199c  sub rsp, 0xF0
000077a70fdd19a3  vmovaps [rsp], xmm0
000077a70fdd19a8  vmovaps [rsp+0x10], xmm1
000077a70fdd19ae  vmovaps [rsp+0x20], xmm2
000077a70fdd19b4  vmovaps [rsp+0x30], xmm3
000077a70fdd19ba  vmovaps [rsp+0x40], xmm4
000077a70fdd19c0  vmovaps [rsp+0x50], xmm5
000077a70fdd19c6  vmovaps [rsp+0x60], xmm6
000077a70fdd19cc  vmovaps [rsp+0x70], xmm7
000077a70fdd19d2  vmovaps [rsp+0x80], xmm8
000077a70fdd19db  vmovaps [rsp+0x90], xmm9
000077a70fdd19e4  vmovaps [rsp+0xA0], xmm10
000077a70fdd19ed  vmovaps [rsp+0xB0], xmm11
000077a70fdd19f6  vmovaps [rsp+0xC0], xmm12
000077a70fdd19ff  vmovaps [rsp+0xD0], xmm13
000077a70fdd1a08  vmovaps [rsp+0xE0], xmm14
000077a70fdd1a11  sub rsp, 0x30
000077a70fdd1a15  movaps [rsp], xmm15
000077a70fdd1a1a  movaps [rsp+0x10], xmm14
000077a70fdd1a20  movaps [rsp+0x20], xmm1
000077a70fdd1a25  lea rdi, [rsp]
000077a70fdd1a29  mov esi, 0x00
000077a70fdd1a2e  mov rax, 0x6294188EF530
000077a70fdd1a38  call rax
000077a70fdd1a3a  movaps xmm15, [rsp]
000077a70fdd1a3f  add rsp, 0x30
000077a70fdd1a43  vmovaps xmm0, [rsp]
000077a70fdd1a48  vmovaps xmm1, [rsp+0x10]
000077a70fdd1a4e  vmovaps xmm2, [rsp+0x20]
000077a70fdd1a54  vmovaps xmm3, [rsp+0x30]
000077a70fdd1a5a  vmovaps xmm4, [rsp+0x40]
000077a70fdd1a60  vmovaps xmm5, [rsp+0x50]
000077a70fdd1a66  vmovaps xmm6, [rsp+0x60]
000077a70fdd1a6c  vmovaps xmm7, [rsp+0x70]
000077a70fdd1a72  vmovaps xmm8, [rsp+0x80]
000077a70fdd1a7b  vmovaps xmm9, [rsp+0x90]
000077a70fdd1a84  vmovaps xmm10, [rsp+0xA0]
000077a70fdd1a8d  vmovaps xmm11, [rsp+0xB0]
000077a70fdd1a96  vmovaps xmm12, [rsp+0xC0]
000077a70fdd1a9f  vmovaps xmm13, [rsp+0xD0]
000077a70fdd1aa8  vmovaps xmm14, [rsp+0xE0]
000077a70fdd1ab1  add rsp, 0xF0
000077a70fdd1ab8  pop r11
000077a70fdd1aba  pop r10
000077a70fdd1abc  pop r9
000077a70fdd1abe  pop r8
000077a70fdd1ac0  pop rsi
000077a70fdd1ac1  pop rdi
000077a70fdd1ac2  pop rdx
000077a70fdd1ac3  pop rcx
000077a70fdd1ac4  pop rax
000077a70fdd1ac5  add rsp, 0x08
000077a70fdd1ac9  jmp 0x000077A70FDCF9E7
000077a70fdd1ace  call 0x000077A70FBFF430
000077a70fdd1ad3  jmp 0x000077A70FDCF9F4
000077a70fdd1ad8  sub rsp, 0x08
000077a70fdd1adc  push rax
000077a70fdd1add  push rcx
000077a70fdd1ade  push rdx
000077a70fdd1adf  push rdi
000077a70fdd1ae0  push rsi
000077a70fdd1ae1  push r8
000077a70fdd1ae3  push r9
000077a70fdd1ae5  push r10
000077a70fdd1ae7  push r11
000077a70fdd1ae9  sub rsp, 0xF0
000077a70fdd1af0  vmovaps [rsp], xmm0
000077a70fdd1af5  vmovaps [rsp+0x10], xmm1
000077a70fdd1afb  vmovaps [rsp+0x20], xmm2
000077a70fdd1b01  vmovaps [rsp+0x30], xmm3
000077a70fdd1b07  vmovaps [rsp+0x40], xmm4
000077a70fdd1b0d  vmovaps [rsp+0x50], xmm5
000077a70fdd1b13  vmovaps [rsp+0x60], xmm6
000077a70fdd1b19  vmovaps [rsp+0x70], xmm7
000077a70fdd1b1f  vmovaps [rsp+0x80], xmm8
000077a70fdd1b28  vmovaps [rsp+0x90], xmm9
000077a70fdd1b31  vmovaps [rsp+0xA0], xmm10
000077a70fdd1b3a  vmovaps [rsp+0xB0], xmm11
000077a70fdd1b43  vmovaps [rsp+0xC0], xmm12
000077a70fdd1b4c  vmovaps [rsp+0xD0], xmm13
000077a70fdd1b55  vmovaps [rsp+0xE0], xmm15
000077a70fdd1b5e  sub rsp, 0x30
000077a70fdd1b62  movaps [rsp], xmm14
000077a70fdd1b67  movaps [rsp+0x10], xmm13
000077a70fdd1b6d  movaps [rsp+0x20], xmm1
000077a70fdd1b72  lea rdi, [rsp]
000077a70fdd1b76  mov esi, 0x00
000077a70fdd1b7b  mov rax, 0x6294188EF530
000077a70fdd1b85  call rax
000077a70fdd1b87  movaps xmm14, [rsp]
000077a70fdd1b8c  add rsp, 0x30
000077a70fdd1b90  vmovaps xmm0, [rsp]
000077a70fdd1b95  vmovaps xmm1, [rsp+0x10]
000077a70fdd1b9b  vmovaps xmm2, [rsp+0x20]
000077a70fdd1ba1  vmovaps xmm3, [rsp+0x30]
000077a70fdd1ba7  vmovaps xmm4, [rsp+0x40]
000077a70fdd1bad  vmovaps xmm5, [rsp+0x50]
000077a70fdd1bb3  vmovaps xmm6, [rsp+0x60]
000077a70fdd1bb9  vmovaps xmm7, [rsp+0x70]
000077a70fdd1bbf  vmovaps xmm8, [rsp+0x80]
000077a70fdd1bc8  vmovaps xmm9, [rsp+0x90]
000077a70fdd1bd1  vmovaps xmm10, [rsp+0xA0]
000077a70fdd1bda  vmovaps xmm11, [rsp+0xB0]
000077a70fdd1be3  vmovaps xmm12, [rsp+0xC0]
000077a70fdd1bec  vmovaps xmm13, [rsp+0xD0]
000077a70fdd1bf5  vmovaps xmm15, [rsp+0xE0]
000077a70fdd1bfe  add rsp, 0xF0
000077a70fdd1c05  pop r11
000077a70fdd1c07  pop r10
000077a70fdd1c09  pop r9
000077a70fdd1c0b  pop r8
000077a70fdd1c0d  pop rsi
000077a70fdd1c0e  pop rdi
000077a70fdd1c0f  pop rdx
000077a70fdd1c10  pop rcx
000077a70fdd1c11  pop rax
000077a70fdd1c12  add rsp, 0x08
000077a70fdd1c16  jmp 0x000077A70FDCFAAF
000077a70fdd1c1b  sub rsp, 0x08
000077a70fdd1c1f  push rax
000077a70fdd1c20  push rcx
000077a70fdd1c21  push rdx
000077a70fdd1c22  push rdi
000077a70fdd1c23  push rsi
000077a70fdd1c24  push r8
000077a70fdd1c26  push r9
000077a70fdd1c28  push r10
000077a70fdd1c2a  push r11
000077a70fdd1c2c  sub rsp, 0xF0
000077a70fdd1c33  vmovaps [rsp], xmm0
000077a70fdd1c38  vmovaps [rsp+0x10], xmm1
000077a70fdd1c3e  vmovaps [rsp+0x20], xmm2
000077a70fdd1c44  vmovaps [rsp+0x30], xmm3
000077a70fdd1c4a  vmovaps [rsp+0x40], xmm4
000077a70fdd1c50  vmovaps [rsp+0x50], xmm5
000077a70fdd1c56  vmovaps [rsp+0x60], xmm6
000077a70fdd1c5c  vmovaps [rsp+0x70], xmm7
000077a70fdd1c62  vmovaps [rsp+0x80], xmm8
000077a70fdd1c6b  vmovaps [rsp+0x90], xmm9
000077a70fdd1c74  vmovaps [rsp+0xA0], xmm10
000077a70fdd1c7d  vmovaps [rsp+0xB0], xmm11
000077a70fdd1c86  vmovaps [rsp+0xC0], xmm12
000077a70fdd1c8f  vmovaps [rsp+0xD0], xmm13
000077a70fdd1c98  vmovaps [rsp+0xE0], xmm14
000077a70fdd1ca1  sub rsp, 0x30
000077a70fdd1ca5  movaps [rsp], xmm15
000077a70fdd1caa  movaps [rsp+0x10], xmm13
000077a70fdd1cb0  movaps [rsp+0x20], xmm1
000077a70fdd1cb5  lea rdi, [rsp]
000077a70fdd1cb9  mov esi, 0x00
000077a70fdd1cbe  mov rax, 0x6294188EF530
000077a70fdd1cc8  call rax
000077a70fdd1cca  movaps xmm15, [rsp]
000077a70fdd1ccf  add rsp, 0x30
000077a70fdd1cd3  vmovaps xmm0, [rsp]
000077a70fdd1cd8  vmovaps xmm1, [rsp+0x10]
000077a70fdd1cde  vmovaps xmm2, [rsp+0x20]
000077a70fdd1ce4  vmovaps xmm3, [rsp+0x30]
000077a70fdd1cea  vmovaps xmm4, [rsp+0x40]
000077a70fdd1cf0  vmovaps xmm5, [rsp+0x50]
000077a70fdd1cf6  vmovaps xmm6, [rsp+0x60]
000077a70fdd1cfc  vmovaps xmm7, [rsp+0x70]
000077a70fdd1d02  vmovaps xmm8, [rsp+0x80]
000077a70fdd1d0b  vmovaps xmm9, [rsp+0x90]
000077a70fdd1d14  vmovaps xmm10, [rsp+0xA0]
000077a70fdd1d1d  vmovaps xmm11, [rsp+0xB0]
000077a70fdd1d26  vmovaps xmm12, [rsp+0xC0]
000077a70fdd1d2f  vmovaps xmm13, [rsp+0xD0]
000077a70fdd1d38  vmovaps xmm14, [rsp+0xE0]
000077a70fdd1d41  add rsp, 0xF0
000077a70fdd1d48  pop r11
000077a70fdd1d4a  pop r10
000077a70fdd1d4c  pop r9
000077a70fdd1d4e  pop r8
000077a70fdd1d50  pop rsi
000077a70fdd1d51  pop rdi
000077a70fdd1d52  pop rdx
000077a70fdd1d53  pop rcx
000077a70fdd1d54  pop rax
000077a70fdd1d55  add rsp, 0x08
000077a70fdd1d59  jmp 0x000077A70FDCFAEB
000077a70fdd1d5e  call 0x000077A70FBFF430
000077a70fdd1d63  jmp 0x000077A70FDCFAF8
000077a70fdd1d68  sub rsp, 0x08
000077a70fdd1d6c  push rax
000077a70fdd1d6d  push rcx
000077a70fdd1d6e  push rdx
000077a70fdd1d6f  push rdi
000077a70fdd1d70  push rsi
000077a70fdd1d71  push r8
000077a70fdd1d73  push r9
000077a70fdd1d75  push r10
000077a70fdd1d77  push r11
000077a70fdd1d79  sub rsp, 0xF0
000077a70fdd1d80  vmovaps [rsp], xmm0
000077a70fdd1d85  vmovaps [rsp+0x10], xmm1
000077a70fdd1d8b  vmovaps [rsp+0x20], xmm2
000077a70fdd1d91  vmovaps [rsp+0x30], xmm3
000077a70fdd1d97  vmovaps [rsp+0x40], xmm4
000077a70fdd1d9d  vmovaps [rsp+0x50], xmm5
000077a70fdd1da3  vmovaps [rsp+0x60], xmm6
000077a70fdd1da9  vmovaps [rsp+0x70], xmm7
000077a70fdd1daf  vmovaps [rsp+0x80], xmm8
000077a70fdd1db8  vmovaps [rsp+0x90], xmm9
000077a70fdd1dc1  vmovaps [rsp+0xA0], xmm10
000077a70fdd1dca  vmovaps [rsp+0xB0], xmm11
000077a70fdd1dd3  vmovaps [rsp+0xC0], xmm12
000077a70fdd1ddc  vmovaps [rsp+0xD0], xmm13
000077a70fdd1de5  vmovaps [rsp+0xE0], xmm15
000077a70fdd1dee  sub rsp, 0x30
000077a70fdd1df2  movaps [rsp], xmm14
000077a70fdd1df7  movaps [rsp+0x10], xmm13
000077a70fdd1dfd  movaps [rsp+0x20], xmm2
000077a70fdd1e02  lea rdi, [rsp]
000077a70fdd1e06  mov esi, 0x00
000077a70fdd1e0b  mov rax, 0x6294188EF530
000077a70fdd1e15  call rax
000077a70fdd1e17  movaps xmm14, [rsp]
000077a70fdd1e1c  add rsp, 0x30
000077a70fdd1e20  vmovaps xmm0, [rsp]
000077a70fdd1e25  vmovaps xmm1, [rsp+0x10]
000077a70fdd1e2b  vmovaps xmm2, [rsp+0x20]
000077a70fdd1e31  vmovaps xmm3, [rsp+0x30]
000077a70fdd1e37  vmovaps xmm4, [rsp+0x40]
000077a70fdd1e3d  vmovaps xmm5, [rsp+0x50]
000077a70fdd1e43  vmovaps xmm6, [rsp+0x60]
000077a70fdd1e49  vmovaps xmm7, [rsp+0x70]
000077a70fdd1e4f  vmovaps xmm8, [rsp+0x80]
000077a70fdd1e58  vmovaps xmm9, [rsp+0x90]
000077a70fdd1e61  vmovaps xmm10, [rsp+0xA0]
000077a70fdd1e6a  vmovaps xmm11, [rsp+0xB0]
000077a70fdd1e73  vmovaps xmm12, [rsp+0xC0]
000077a70fdd1e7c  vmovaps xmm13, [rsp+0xD0]
000077a70fdd1e85  vmovaps xmm15, [rsp+0xE0]
000077a70fdd1e8e  add rsp, 0xF0
000077a70fdd1e95  pop r11
000077a70fdd1e97  pop r10
000077a70fdd1e99  pop r9
000077a70fdd1e9b  pop r8
000077a70fdd1e9d  pop rsi
000077a70fdd1e9e  pop rdi
000077a70fdd1e9f  pop rdx
000077a70fdd1ea0  pop rcx
000077a70fdd1ea1  pop rax
000077a70fdd1ea2  add rsp, 0x08
000077a70fdd1ea6  jmp 0x000077A70FDCFB24
000077a70fdd1eab  sub rsp, 0x08
000077a70fdd1eaf  push rax
000077a70fdd1eb0  push rcx
000077a70fdd1eb1  push rdx
000077a70fdd1eb2  push rdi
000077a70fdd1eb3  push rsi
000077a70fdd1eb4  push r8
000077a70fdd1eb6  push r9
000077a70fdd1eb8  push r10
000077a70fdd1eba  push r11
000077a70fdd1ebc  sub rsp, 0xF0
000077a70fdd1ec3  vmovaps [rsp], xmm0
000077a70fdd1ec8  vmovaps [rsp+0x10], xmm2
000077a70fdd1ece  vmovaps [rsp+0x20], xmm3
000077a70fdd1ed4  vmovaps [rsp+0x30], xmm4
000077a70fdd1eda  vmovaps [rsp+0x40], xmm5
000077a70fdd1ee0  vmovaps [rsp+0x50], xmm6
000077a70fdd1ee6  vmovaps [rsp+0x60], xmm7
000077a70fdd1eec  vmovaps [rsp+0x70], xmm8
000077a70fdd1ef2  vmovaps [rsp+0x80], xmm9
000077a70fdd1efb  vmovaps [rsp+0x90], xmm10
000077a70fdd1f04  vmovaps [rsp+0xA0], xmm11
000077a70fdd1f0d  vmovaps [rsp+0xB0], xmm12
000077a70fdd1f16  vmovaps [rsp+0xC0], xmm13
000077a70fdd1f1f  vmovaps [rsp+0xD0], xmm14
000077a70fdd1f28  vmovaps [rsp+0xE0], xmm15
000077a70fdd1f31  sub rsp, 0x30
000077a70fdd1f35  movaps [rsp], xmm1
000077a70fdd1f39  movaps [rsp+0x10], xmm13
000077a70fdd1f3f  movaps [rsp+0x20], xmm2
000077a70fdd1f44  lea rdi, [rsp]
000077a70fdd1f48  mov esi, 0x00
000077a70fdd1f4d  mov rax, 0x6294188EF530
000077a70fdd1f57  call rax
000077a70fdd1f59  movaps xmm1, [rsp]
000077a70fdd1f5d  add rsp, 0x30
000077a70fdd1f61  vmovaps xmm0, [rsp]
000077a70fdd1f66  vmovaps xmm2, [rsp+0x10]
000077a70fdd1f6c  vmovaps xmm3, [rsp+0x20]
000077a70fdd1f72  vmovaps xmm4, [rsp+0x30]
000077a70fdd1f78  vmovaps xmm5, [rsp+0x40]
000077a70fdd1f7e  vmovaps xmm6, [rsp+0x50]
000077a70fdd1f84  vmovaps xmm7, [rsp+0x60]
000077a70fdd1f8a  vmovaps xmm8, [rsp+0x70]
000077a70fdd1f90  vmovaps xmm9, [rsp+0x80]
000077a70fdd1f99  vmovaps xmm10, [rsp+0x90]
000077a70fdd1fa2  vmovaps xmm11, [rsp+0xA0]
000077a70fdd1fab  vmovaps xmm12, [rsp+0xB0]
000077a70fdd1fb4  vmovaps xmm13, [rsp+0xC0]
000077a70fdd1fbd  vmovaps xmm14, [rsp+0xD0]
000077a70fdd1fc6  vmovaps xmm15, [rsp+0xE0]
000077a70fdd1fcf  add rsp, 0xF0
000077a70fdd1fd6  pop r11
000077a70fdd1fd8  pop r10
000077a70fdd1fda  pop r9
000077a70fdd1fdc  pop r8
000077a70fdd1fde  pop rsi
000077a70fdd1fdf  pop rdi
000077a70fdd1fe0  pop rdx
000077a70fdd1fe1  pop rcx
000077a70fdd1fe2  pop rax
000077a70fdd1fe3  add rsp, 0x08
000077a70fdd1fe7  jmp 0x000077A70FDCFB52
000077a70fdd1fec  sub rsp, 0x08
000077a70fdd1ff0  push rax
000077a70fdd1ff1  push rcx
000077a70fdd1ff2  push rdx
000077a70fdd1ff3  push rdi
000077a70fdd1ff4  push rsi
000077a70fdd1ff5  push r8
000077a70fdd1ff7  push r9
000077a70fdd1ff9  push r10
000077a70fdd1ffb  push r11
000077a70fdd1ffd  sub rsp, 0xF0
000077a70fdd2004  vmovaps [rsp], xmm0
000077a70fdd2009  vmovaps [rsp+0x10], xmm1
000077a70fdd200f  vmovaps [rsp+0x20], xmm3
000077a70fdd2015  vmovaps [rsp+0x30], xmm4
000077a70fdd201b  vmovaps [rsp+0x40], xmm5
000077a70fdd2021  vmovaps [rsp+0x50], xmm6
000077a70fdd2027  vmovaps [rsp+0x60], xmm7
000077a70fdd202d  vmovaps [rsp+0x70], xmm8
000077a70fdd2033  vmovaps [rsp+0x80], xmm9
000077a70fdd203c  vmovaps [rsp+0x90], xmm10
000077a70fdd2045  vmovaps [rsp+0xA0], xmm11
000077a70fdd204e  vmovaps [rsp+0xB0], xmm12
000077a70fdd2057  vmovaps [rsp+0xC0], xmm13
000077a70fdd2060  vmovaps [rsp+0xD0], xmm14
000077a70fdd2069  vmovaps [rsp+0xE0], xmm15
000077a70fdd2072  sub rsp, 0x30
000077a70fdd2076  movaps [rsp], xmm2
000077a70fdd207a  movaps [rsp+0x10], xmm1
000077a70fdd207f  movaps [rsp+0x20], xmm13
000077a70fdd2085  lea rdi, [rsp]
000077a70fdd2089  mov esi, 0x00
000077a70fdd208e  mov rax, 0x6294188EF530
000077a70fdd2098  call rax
000077a70fdd209a  movaps xmm2, [rsp]
000077a70fdd209e  add rsp, 0x30
000077a70fdd20a2  vmovaps xmm0, [rsp]
000077a70fdd20a7  vmovaps xmm1, [rsp+0x10]
000077a70fdd20ad  vmovaps xmm3, [rsp+0x20]
000077a70fdd20b3  vmovaps xmm4, [rsp+0x30]
000077a70fdd20b9  vmovaps xmm5, [rsp+0x40]
000077a70fdd20bf  vmovaps xmm6, [rsp+0x50]
000077a70fdd20c5  vmovaps xmm7, [rsp+0x60]
000077a70fdd20cb  vmovaps xmm8, [rsp+0x70]
000077a70fdd20d1  vmovaps xmm9, [rsp+0x80]
000077a70fdd20da  vmovaps xmm10, [rsp+0x90]
000077a70fdd20e3  vmovaps xmm11, [rsp+0xA0]
000077a70fdd20ec  vmovaps xmm12, [rsp+0xB0]
000077a70fdd20f5  vmovaps xmm13, [rsp+0xC0]
000077a70fdd20fe  vmovaps xmm14, [rsp+0xD0]
000077a70fdd2107  vmovaps xmm15, [rsp+0xE0]
000077a70fdd2110  add rsp, 0xF0
000077a70fdd2117  pop r11
000077a70fdd2119  pop r10
000077a70fdd211b  pop r9
000077a70fdd211d  pop r8
000077a70fdd211f  pop rsi
000077a70fdd2120  pop rdi
000077a70fdd2121  pop rdx
000077a70fdd2122  pop rcx
000077a70fdd2123  pop rax
000077a70fdd2124  add rsp, 0x08
000077a70fdd2128  jmp 0x000077A70FDCFBAB
000077a70fdd212d  call 0x000077A70FBFF430
000077a70fdd2132  jmp 0x000077A70FDCFBB8
000077a70fdd2137  sub rsp, 0x08
000077a70fdd213b  push rax
000077a70fdd213c  push rcx
000077a70fdd213d  push rdx
000077a70fdd213e  push rdi
000077a70fdd213f  push rsi
000077a70fdd2140  push r8
000077a70fdd2142  push r9
000077a70fdd2144  push r10
000077a70fdd2146  push r11
000077a70fdd2148  sub rsp, 0xF0
000077a70fdd214f  vmovaps [rsp], xmm0
000077a70fdd2154  vmovaps [rsp+0x10], xmm1
000077a70fdd215a  vmovaps [rsp+0x20], xmm2
000077a70fdd2160  vmovaps [rsp+0x30], xmm3
000077a70fdd2166  vmovaps [rsp+0x40], xmm4
000077a70fdd216c  vmovaps [rsp+0x50], xmm5
000077a70fdd2172  vmovaps [rsp+0x60], xmm6
000077a70fdd2178  vmovaps [rsp+0x70], xmm7
000077a70fdd217e  vmovaps [rsp+0x80], xmm8
000077a70fdd2187  vmovaps [rsp+0x90], xmm9
000077a70fdd2190  vmovaps [rsp+0xA0], xmm10
000077a70fdd2199  vmovaps [rsp+0xB0], xmm11
000077a70fdd21a2  vmovaps [rsp+0xC0], xmm12
000077a70fdd21ab  vmovaps [rsp+0xD0], xmm13
000077a70fdd21b4  vmovaps [rsp+0xE0], xmm14
000077a70fdd21bd  sub rsp, 0x30
000077a70fdd21c1  movaps [rsp], xmm15
000077a70fdd21c6  movaps [rsp+0x10], xmm13
000077a70fdd21cc  movaps [rsp+0x20], xmm1
000077a70fdd21d1  lea rdi, [rsp]
000077a70fdd21d5  mov esi, 0x00
000077a70fdd21da  mov rax, 0x6294188EF530
000077a70fdd21e4  call rax
000077a70fdd21e6  movaps xmm15, [rsp]
000077a70fdd21eb  add rsp, 0x30
000077a70fdd21ef  vmovaps xmm0, [rsp]
000077a70fdd21f4  vmovaps xmm1, [rsp+0x10]
000077a70fdd21fa  vmovaps xmm2, [rsp+0x20]
000077a70fdd2200  vmovaps xmm3, [rsp+0x30]
000077a70fdd2206  vmovaps xmm4, [rsp+0x40]
000077a70fdd220c  vmovaps xmm5, [rsp+0x50]
000077a70fdd2212  vmovaps xmm6, [rsp+0x60]
000077a70fdd2218  vmovaps xmm7, [rsp+0x70]
000077a70fdd221e  vmovaps xmm8, [rsp+0x80]
000077a70fdd2227  vmovaps xmm9, [rsp+0x90]
000077a70fdd2230  vmovaps xmm10, [rsp+0xA0]
000077a70fdd2239  vmovaps xmm11, [rsp+0xB0]
000077a70fdd2242  vmovaps xmm12, [rsp+0xC0]
000077a70fdd224b  vmovaps xmm13, [rsp+0xD0]
000077a70fdd2254  vmovaps xmm14, [rsp+0xE0]
000077a70fdd225d  add rsp, 0xF0
000077a70fdd2264  pop r11
000077a70fdd2266  pop r10
000077a70fdd2268  pop r9
000077a70fdd226a  pop r8
000077a70fdd226c  pop rsi
000077a70fdd226d  pop rdi
000077a70fdd226e  pop rdx
000077a70fdd226f  pop rcx
000077a70fdd2270  pop rax
000077a70fdd2271  add rsp, 0x08
000077a70fdd2275  jmp 0x000077A70FDCFBF7
000077a70fdd227a  sub rsp, 0x08
000077a70fdd227e  push rax
000077a70fdd227f  push rcx
000077a70fdd2280  push rdx
000077a70fdd2281  push rdi
000077a70fdd2282  push rsi
000077a70fdd2283  push r8
000077a70fdd2285  push r9
000077a70fdd2287  push r10
000077a70fdd2289  push r11
000077a70fdd228b  sub rsp, 0xF0
000077a70fdd2292  vmovaps [rsp], xmm0
000077a70fdd2297  vmovaps [rsp+0x10], xmm1
000077a70fdd229d  vmovaps [rsp+0x20], xmm2
000077a70fdd22a3  vmovaps [rsp+0x30], xmm3
000077a70fdd22a9  vmovaps [rsp+0x40], xmm4
000077a70fdd22af  vmovaps [rsp+0x50], xmm5
000077a70fdd22b5  vmovaps [rsp+0x60], xmm6
000077a70fdd22bb  vmovaps [rsp+0x70], xmm7
000077a70fdd22c1  vmovaps [rsp+0x80], xmm8
000077a70fdd22ca  vmovaps [rsp+0x90], xmm9
000077a70fdd22d3  vmovaps [rsp+0xA0], xmm10
000077a70fdd22dc  vmovaps [rsp+0xB0], xmm11
000077a70fdd22e5  vmovaps [rsp+0xC0], xmm12
000077a70fdd22ee  vmovaps [rsp+0xD0], xmm13
000077a70fdd22f7  vmovaps [rsp+0xE0], xmm15
000077a70fdd2300  sub rsp, 0x30
000077a70fdd2304  movaps [rsp], xmm14
000077a70fdd2309  movaps [rsp+0x10], xmm11
000077a70fdd230f  movaps [rsp+0x20], xmm1
000077a70fdd2314  lea rdi, [rsp]
000077a70fdd2318  mov esi, 0x00
000077a70fdd231d  mov rax, 0x6294188EF530
000077a70fdd2327  call rax
000077a70fdd2329  movaps xmm14, [rsp]
000077a70fdd232e  add rsp, 0x30
000077a70fdd2332  vmovaps xmm0, [rsp]
000077a70fdd2337  vmovaps xmm1, [rsp+0x10]
000077a70fdd233d  vmovaps xmm2, [rsp+0x20]
000077a70fdd2343  vmovaps xmm3, [rsp+0x30]
000077a70fdd2349  vmovaps xmm4, [rsp+0x40]
000077a70fdd234f  vmovaps xmm5, [rsp+0x50]
000077a70fdd2355  vmovaps xmm6, [rsp+0x60]
000077a70fdd235b  vmovaps xmm7, [rsp+0x70]
000077a70fdd2361  vmovaps xmm8, [rsp+0x80]
000077a70fdd236a  vmovaps xmm9, [rsp+0x90]
000077a70fdd2373  vmovaps xmm10, [rsp+0xA0]
000077a70fdd237c  vmovaps xmm11, [rsp+0xB0]
000077a70fdd2385  vmovaps xmm12, [rsp+0xC0]
000077a70fdd238e  vmovaps xmm13, [rsp+0xD0]
000077a70fdd2397  vmovaps xmm15, [rsp+0xE0]
000077a70fdd23a0  add rsp, 0xF0
000077a70fdd23a7  pop r11
000077a70fdd23a9  pop r10
000077a70fdd23ab  pop r9
000077a70fdd23ad  pop r8
000077a70fdd23af  pop rsi
000077a70fdd23b0  pop rdi
000077a70fdd23b1  pop rdx
000077a70fdd23b2  pop rcx
000077a70fdd23b3  pop rax
000077a70fdd23b4  add rsp, 0x08
000077a70fdd23b8  jmp 0x000077A70FDCFC21
000077a70fdd23bd  sub rsp, 0x08
000077a70fdd23c1  push rax
000077a70fdd23c2  push rcx
000077a70fdd23c3  push rdx
000077a70fdd23c4  push rdi
000077a70fdd23c5  push rsi
000077a70fdd23c6  push r8
000077a70fdd23c8  push r9
000077a70fdd23ca  push r10
000077a70fdd23cc  push r11
000077a70fdd23ce  sub rsp, 0xF0
000077a70fdd23d5  vmovaps [rsp], xmm0
000077a70fdd23da  vmovaps [rsp+0x10], xmm1
000077a70fdd23e0  vmovaps [rsp+0x20], xmm2
000077a70fdd23e6  vmovaps [rsp+0x30], xmm3
000077a70fdd23ec  vmovaps [rsp+0x40], xmm4
000077a70fdd23f2  vmovaps [rsp+0x50], xmm5
000077a70fdd23f8  vmovaps [rsp+0x60], xmm6
000077a70fdd23fe  vmovaps [rsp+0x70], xmm7
000077a70fdd2404  vmovaps [rsp+0x80], xmm8
000077a70fdd240d  vmovaps [rsp+0x90], xmm9
000077a70fdd2416  vmovaps [rsp+0xA0], xmm10
000077a70fdd241f  vmovaps [rsp+0xB0], xmm11
000077a70fdd2428  vmovaps [rsp+0xC0], xmm12
000077a70fdd2431  vmovaps [rsp+0xD0], xmm14
000077a70fdd243a  vmovaps [rsp+0xE0], xmm15
000077a70fdd2443  sub rsp, 0x30
000077a70fdd2447  movaps [rsp], xmm13
000077a70fdd244c  movaps [rsp+0x10], xmm11
000077a70fdd2452  movaps [rsp+0x20], xmm1
000077a70fdd2457  lea rdi, [rsp]
000077a70fdd245b  mov esi, 0x00
000077a70fdd2460  mov rax, 0x6294188EF530
000077a70fdd246a  call rax
000077a70fdd246c  movaps xmm13, [rsp]
000077a70fdd2471  add rsp, 0x30
000077a70fdd2475  vmovaps xmm0, [rsp]
000077a70fdd247a  vmovaps xmm1, [rsp+0x10]
000077a70fdd2480  vmovaps xmm2, [rsp+0x20]
000077a70fdd2486  vmovaps xmm3, [rsp+0x30]
000077a70fdd248c  vmovaps xmm4, [rsp+0x40]
000077a70fdd2492  vmovaps xmm5, [rsp+0x50]
000077a70fdd2498  vmovaps xmm6, [rsp+0x60]
000077a70fdd249e  vmovaps xmm7, [rsp+0x70]
000077a70fdd24a4  vmovaps xmm8, [rsp+0x80]
000077a70fdd24ad  vmovaps xmm9, [rsp+0x90]
000077a70fdd24b6  vmovaps xmm10, [rsp+0xA0]
000077a70fdd24bf  vmovaps xmm11, [rsp+0xB0]
000077a70fdd24c8  vmovaps xmm12, [rsp+0xC0]
000077a70fdd24d1  vmovaps xmm14, [rsp+0xD0]
000077a70fdd24da  vmovaps xmm15, [rsp+0xE0]
000077a70fdd24e3  add rsp, 0xF0
000077a70fdd24ea  pop r11
000077a70fdd24ec  pop r10
000077a70fdd24ee  pop r9
000077a70fdd24f0  pop r8
000077a70fdd24f2  pop rsi
000077a70fdd24f3  pop rdi
000077a70fdd24f4  pop rdx
000077a70fdd24f5  pop rcx
000077a70fdd24f6  pop rax
000077a70fdd24f7  add rsp, 0x08
000077a70fdd24fb  jmp 0x000077A70FDCFC76
000077a70fdd2500  call 0x000077A70FBFF430
000077a70fdd2505  jmp 0x000077A70FDCFC83
000077a70fdd250a  sub rsp, 0x08
000077a70fdd250e  push rax
000077a70fdd250f  push rcx
000077a70fdd2510  push rdx
000077a70fdd2511  push rdi
000077a70fdd2512  push rsi
000077a70fdd2513  push r8
000077a70fdd2515  push r9
000077a70fdd2517  push r10
000077a70fdd2519  push r11
000077a70fdd251b  sub rsp, 0xF0
000077a70fdd2522  vmovaps [rsp], xmm0
000077a70fdd2527  vmovaps [rsp+0x10], xmm1
000077a70fdd252d  vmovaps [rsp+0x20], xmm2
000077a70fdd2533  vmovaps [rsp+0x30], xmm3
000077a70fdd2539  vmovaps [rsp+0x40], xmm4
000077a70fdd253f  vmovaps [rsp+0x50], xmm5
000077a70fdd2545  vmovaps [rsp+0x60], xmm6
000077a70fdd254b  vmovaps [rsp+0x70], xmm7
000077a70fdd2551  vmovaps [rsp+0x80], xmm8
000077a70fdd255a  vmovaps [rsp+0x90], xmm9
000077a70fdd2563  vmovaps [rsp+0xA0], xmm10
000077a70fdd256c  vmovaps [rsp+0xB0], xmm11
000077a70fdd2575  vmovaps [rsp+0xC0], xmm12
000077a70fdd257e  vmovaps [rsp+0xD0], xmm13
000077a70fdd2587  vmovaps [rsp+0xE0], xmm14
000077a70fdd2590  sub rsp, 0x30
000077a70fdd2594  movaps [rsp], xmm15
000077a70fdd2599  movaps [rsp+0x10], xmm11
000077a70fdd259f  movaps [rsp+0x20], xmm1
000077a70fdd25a4  lea rdi, [rsp]
000077a70fdd25a8  mov esi, 0x00
000077a70fdd25ad  mov rax, 0x6294188EF530
000077a70fdd25b7  call rax
000077a70fdd25b9  movaps xmm15, [rsp]
000077a70fdd25be  add rsp, 0x30
000077a70fdd25c2  vmovaps xmm0, [rsp]
000077a70fdd25c7  vmovaps xmm1, [rsp+0x10]
000077a70fdd25cd  vmovaps xmm2, [rsp+0x20]
000077a70fdd25d3  vmovaps xmm3, [rsp+0x30]
000077a70fdd25d9  vmovaps xmm4, [rsp+0x40]
000077a70fdd25df  vmovaps xmm5, [rsp+0x50]
000077a70fdd25e5  vmovaps xmm6, [rsp+0x60]
000077a70fdd25eb  vmovaps xmm7, [rsp+0x70]
000077a70fdd25f1  vmovaps xmm8, [rsp+0x80]
000077a70fdd25fa  vmovaps xmm9, [rsp+0x90]
000077a70fdd2603  vmovaps xmm10, [rsp+0xA0]
000077a70fdd260c  vmovaps xmm11, [rsp+0xB0]
000077a70fdd2615  vmovaps xmm12, [rsp+0xC0]
000077a70fdd261e  vmovaps xmm13, [rsp+0xD0]
000077a70fdd2627  vmovaps xmm14, [rsp+0xE0]
000077a70fdd2630  add rsp, 0xF0
000077a70fdd2637  pop r11
000077a70fdd2639  pop r10
000077a70fdd263b  pop r9
000077a70fdd263d  pop r8
000077a70fdd263f  pop rsi
000077a70fdd2640  pop rdi
000077a70fdd2641  pop rdx
000077a70fdd2642  pop rcx
000077a70fdd2643  pop rax
000077a70fdd2644  add rsp, 0x08
000077a70fdd2648  jmp 0x000077A70FDCFCBC
000077a70fdd264d  sub rsp, 0x08
000077a70fdd2651  push rax
000077a70fdd2652  push rcx
000077a70fdd2653  push rdx
000077a70fdd2654  push rdi
000077a70fdd2655  push rsi
000077a70fdd2656  push r8
000077a70fdd2658  push r9
000077a70fdd265a  push r10
000077a70fdd265c  push r11
000077a70fdd265e  sub rsp, 0xF0
000077a70fdd2665  vmovaps [rsp], xmm0
000077a70fdd266a  vmovaps [rsp+0x10], xmm1
000077a70fdd2670  vmovaps [rsp+0x20], xmm2
000077a70fdd2676  vmovaps [rsp+0x30], xmm3
000077a70fdd267c  vmovaps [rsp+0x40], xmm4
000077a70fdd2682  vmovaps [rsp+0x50], xmm5
000077a70fdd2688  vmovaps [rsp+0x60], xmm6
000077a70fdd268e  vmovaps [rsp+0x70], xmm7
000077a70fdd2694  vmovaps [rsp+0x80], xmm8
000077a70fdd269d  vmovaps [rsp+0x90], xmm9
000077a70fdd26a6  vmovaps [rsp+0xA0], xmm10
000077a70fdd26af  vmovaps [rsp+0xB0], xmm12
000077a70fdd26b8  vmovaps [rsp+0xC0], xmm13
000077a70fdd26c1  vmovaps [rsp+0xD0], xmm14
000077a70fdd26ca  vmovaps [rsp+0xE0], xmm15
000077a70fdd26d3  sub rsp, 0x30
000077a70fdd26d7  movaps [rsp], xmm11
000077a70fdd26dc  movaps [rsp+0x10], xmm6
000077a70fdd26e1  movaps [rsp+0x20], xmm14
000077a70fdd26e7  lea rdi, [rsp]
000077a70fdd26eb  mov esi, 0x00
000077a70fdd26f0  mov rax, 0x6294188EF530
000077a70fdd26fa  call rax
000077a70fdd26fc  movaps xmm11, [rsp]
000077a70fdd2701  add rsp, 0x30
000077a70fdd2705  vmovaps xmm0, [rsp]
000077a70fdd270a  vmovaps xmm1, [rsp+0x10]
000077a70fdd2710  vmovaps xmm2, [rsp+0x20]
000077a70fdd2716  vmovaps xmm3, [rsp+0x30]
000077a70fdd271c  vmovaps xmm4, [rsp+0x40]
000077a70fdd2722  vmovaps xmm5, [rsp+0x50]
000077a70fdd2728  vmovaps xmm6, [rsp+0x60]
000077a70fdd272e  vmovaps xmm7, [rsp+0x70]
000077a70fdd2734  vmovaps xmm8, [rsp+0x80]
000077a70fdd273d  vmovaps xmm9, [rsp+0x90]
000077a70fdd2746  vmovaps xmm10, [rsp+0xA0]
000077a70fdd274f  vmovaps xmm12, [rsp+0xB0]
000077a70fdd2758  vmovaps xmm13, [rsp+0xC0]
000077a70fdd2761  vmovaps xmm14, [rsp+0xD0]
000077a70fdd276a  vmovaps xmm15, [rsp+0xE0]
000077a70fdd2773  add rsp, 0xF0
000077a70fdd277a  pop r11
000077a70fdd277c  pop r10
000077a70fdd277e  pop r9
000077a70fdd2780  pop r8
000077a70fdd2782  pop rsi
000077a70fdd2783  pop rdi
000077a70fdd2784  pop rdx
000077a70fdd2785  pop rcx
000077a70fdd2786  pop rax
000077a70fdd2787  add rsp, 0x08
000077a70fdd278b  jmp 0x000077A70FDCFD34
000077a70fdd2790  call 0x000077A70FBFF430
000077a70fdd2795  jmp 0x000077A70FDCFD3E
000077a70fdd279a  sub rsp, 0x08
000077a70fdd279e  push rax
000077a70fdd279f  push rcx
000077a70fdd27a0  push rdx
000077a70fdd27a1  push rdi
000077a70fdd27a2  push rsi
000077a70fdd27a3  push r8
000077a70fdd27a5  push r9
000077a70fdd27a7  push r10
000077a70fdd27a9  push r11
000077a70fdd27ab  sub rsp, 0xF0
000077a70fdd27b2  vmovaps [rsp], xmm0
000077a70fdd27b7  vmovaps [rsp+0x10], xmm1
000077a70fdd27bd  vmovaps [rsp+0x20], xmm2
000077a70fdd27c3  vmovaps [rsp+0x30], xmm3
000077a70fdd27c9  vmovaps [rsp+0x40], xmm4
000077a70fdd27cf  vmovaps [rsp+0x50], xmm5
000077a70fdd27d5  vmovaps [rsp+0x60], xmm6
000077a70fdd27db  vmovaps [rsp+0x70], xmm7
000077a70fdd27e1  vmovaps [rsp+0x80], xmm8
000077a70fdd27ea  vmovaps [rsp+0x90], xmm9
000077a70fdd27f3  vmovaps [rsp+0xA0], xmm10
000077a70fdd27fc  vmovaps [rsp+0xB0], xmm11
000077a70fdd2805  vmovaps [rsp+0xC0], xmm12
000077a70fdd280e  vmovaps [rsp+0xD0], xmm13
000077a70fdd2817  vmovaps [rsp+0xE0], xmm15
000077a70fdd2820  sub rsp, 0x30
000077a70fdd2824  movaps [rsp], xmm14
000077a70fdd2829  movaps [rsp+0x10], xmm6
000077a70fdd282e  movaps [rsp+0x20], xmm2
000077a70fdd2833  lea rdi, [rsp]
000077a70fdd2837  mov esi, 0x00
000077a70fdd283c  mov rax, 0x6294188EF530
000077a70fdd2846  call rax
000077a70fdd2848  movaps xmm14, [rsp]
000077a70fdd284d  add rsp, 0x30
000077a70fdd2851  vmovaps xmm0, [rsp]
000077a70fdd2856  vmovaps xmm1, [rsp+0x10]
000077a70fdd285c  vmovaps xmm2, [rsp+0x20]
000077a70fdd2862  vmovaps xmm3, [rsp+0x30]
000077a70fdd2868  vmovaps xmm4, [rsp+0x40]
000077a70fdd286e  vmovaps xmm5, [rsp+0x50]
000077a70fdd2874  vmovaps xmm6, [rsp+0x60]
000077a70fdd287a  vmovaps xmm7, [rsp+0x70]
000077a70fdd2880  vmovaps xmm8, [rsp+0x80]
000077a70fdd2889  vmovaps xmm9, [rsp+0x90]
000077a70fdd2892  vmovaps xmm10, [rsp+0xA0]
000077a70fdd289b  vmovaps xmm11, [rsp+0xB0]
000077a70fdd28a4  vmovaps xmm12, [rsp+0xC0]
000077a70fdd28ad  vmovaps xmm13, [rsp+0xD0]
000077a70fdd28b6  vmovaps xmm15, [rsp+0xE0]
000077a70fdd28bf  add rsp, 0xF0
000077a70fdd28c6  pop r11
000077a70fdd28c8  pop r10
000077a70fdd28ca  pop r9
000077a70fdd28cc  pop r8
000077a70fdd28ce  pop rsi
000077a70fdd28cf  pop rdi
000077a70fdd28d0  pop rdx
000077a70fdd28d1  pop rcx
000077a70fdd28d2  pop rax
000077a70fdd28d3  add rsp, 0x08
000077a70fdd28d7  jmp 0x000077A70FDCFD72
000077a70fdd28dc  sub rsp, 0x08
000077a70fdd28e0  push rax
000077a70fdd28e1  push rcx
000077a70fdd28e2  push rdx
000077a70fdd28e3  push rdi
000077a70fdd28e4  push rsi
000077a70fdd28e5  push r8
000077a70fdd28e7  push r9
000077a70fdd28e9  push r10
000077a70fdd28eb  push r11
000077a70fdd28ed  sub rsp, 0xF0
000077a70fdd28f4  vmovaps [rsp], xmm0
000077a70fdd28f9  vmovaps [rsp+0x10], xmm1
000077a70fdd28ff  vmovaps [rsp+0x20], xmm2
000077a70fdd2905  vmovaps [rsp+0x30], xmm3
000077a70fdd290b  vmovaps [rsp+0x40], xmm4
000077a70fdd2911  vmovaps [rsp+0x50], xmm5
000077a70fdd2917  vmovaps [rsp+0x60], xmm7
000077a70fdd291d  vmovaps [rsp+0x70], xmm8
000077a70fdd2923  vmovaps [rsp+0x80], xmm9
000077a70fdd292c  vmovaps [rsp+0x90], xmm10
000077a70fdd2935  vmovaps [rsp+0xA0], xmm11
000077a70fdd293e  vmovaps [rsp+0xB0], xmm12
000077a70fdd2947  vmovaps [rsp+0xC0], xmm13
000077a70fdd2950  vmovaps [rsp+0xD0], xmm14
000077a70fdd2959  vmovaps [rsp+0xE0], xmm15
000077a70fdd2962  sub rsp, 0x30
000077a70fdd2966  movaps [rsp], xmm6
000077a70fdd296a  movaps [rsp+0x10], xmm5
000077a70fdd296f  movaps [rsp+0x20], xmm1
000077a70fdd2974  lea rdi, [rsp]
000077a70fdd2978  mov esi, 0x00
000077a70fdd297d  mov rax, 0x6294188EF530
000077a70fdd2987  call rax
000077a70fdd2989  movaps xmm6, [rsp]
000077a70fdd298d  add rsp, 0x30
000077a70fdd2991  vmovaps xmm0, [rsp]
000077a70fdd2996  vmovaps xmm1, [rsp+0x10]
000077a70fdd299c  vmovaps xmm2, [rsp+0x20]
000077a70fdd29a2  vmovaps xmm3, [rsp+0x30]
000077a70fdd29a8  vmovaps xmm4, [rsp+0x40]
000077a70fdd29ae  vmovaps xmm5, [rsp+0x50]
000077a70fdd29b4  vmovaps xmm7, [rsp+0x60]
000077a70fdd29ba  vmovaps xmm8, [rsp+0x70]
000077a70fdd29c0  vmovaps xmm9, [rsp+0x80]
000077a70fdd29c9  vmovaps xmm10, [rsp+0x90]
000077a70fdd29d2  vmovaps xmm11, [rsp+0xA0]
000077a70fdd29db  vmovaps xmm12, [rsp+0xB0]
000077a70fdd29e4  vmovaps xmm13, [rsp+0xC0]
000077a70fdd29ed  vmovaps xmm14, [rsp+0xD0]
000077a70fdd29f6  vmovaps xmm15, [rsp+0xE0]
000077a70fdd29ff  add rsp, 0xF0
000077a70fdd2a06  pop r11
000077a70fdd2a08  pop r10
000077a70fdd2a0a  pop r9
000077a70fdd2a0c  pop r8
000077a70fdd2a0e  pop rsi
000077a70fdd2a0f  pop rdi
000077a70fdd2a10  pop rdx
000077a70fdd2a11  pop rcx
000077a70fdd2a12  pop rax
000077a70fdd2a13  add rsp, 0x08
000077a70fdd2a17  jmp 0x000077A70FDCFD98
000077a70fdd2a1c  sub rsp, 0x08
000077a70fdd2a20  push rax
000077a70fdd2a21  push rcx
000077a70fdd2a22  push rdx
000077a70fdd2a23  push rdi
000077a70fdd2a24  push rsi
000077a70fdd2a25  push r8
000077a70fdd2a27  push r9
000077a70fdd2a29  push r10
000077a70fdd2a2b  push r11
000077a70fdd2a2d  sub rsp, 0xF0
000077a70fdd2a34  vmovaps [rsp], xmm0
000077a70fdd2a39  vmovaps [rsp+0x10], xmm2
000077a70fdd2a3f  vmovaps [rsp+0x20], xmm3
000077a70fdd2a45  vmovaps [rsp+0x30], xmm4
000077a70fdd2a4b  vmovaps [rsp+0x40], xmm5
000077a70fdd2a51  vmovaps [rsp+0x50], xmm6
000077a70fdd2a57  vmovaps [rsp+0x60], xmm7
000077a70fdd2a5d  vmovaps [rsp+0x70], xmm8
000077a70fdd2a63  vmovaps [rsp+0x80], xmm9
000077a70fdd2a6c  vmovaps [rsp+0x90], xmm10
000077a70fdd2a75  vmovaps [rsp+0xA0], xmm11
000077a70fdd2a7e  vmovaps [rsp+0xB0], xmm12
000077a70fdd2a87  vmovaps [rsp+0xC0], xmm13
000077a70fdd2a90  vmovaps [rsp+0xD0], xmm14
000077a70fdd2a99  vmovaps [rsp+0xE0], xmm15
000077a70fdd2aa2  sub rsp, 0x30
000077a70fdd2aa6  movaps [rsp], xmm1
000077a70fdd2aaa  movaps [rsp+0x10], xmm5
000077a70fdd2aaf  movaps [rsp+0x20], xmm13
000077a70fdd2ab5  lea rdi, [rsp]
000077a70fdd2ab9  mov esi, 0x00
000077a70fdd2abe  mov rax, 0x6294188EF530
000077a70fdd2ac8  call rax
000077a70fdd2aca  movaps xmm1, [rsp]
000077a70fdd2ace  add rsp, 0x30
000077a70fdd2ad2  vmovaps xmm0, [rsp]
000077a70fdd2ad7  vmovaps xmm2, [rsp+0x10]
000077a70fdd2add  vmovaps xmm3, [rsp+0x20]
000077a70fdd2ae3  vmovaps xmm4, [rsp+0x30]
000077a70fdd2ae9  vmovaps xmm5, [rsp+0x40]
000077a70fdd2aef  vmovaps xmm6, [rsp+0x50]
000077a70fdd2af5  vmovaps xmm7, [rsp+0x60]
000077a70fdd2afb  vmovaps xmm8, [rsp+0x70]
000077a70fdd2b01  vmovaps xmm9, [rsp+0x80]
000077a70fdd2b0a  vmovaps xmm10, [rsp+0x90]
000077a70fdd2b13  vmovaps xmm11, [rsp+0xA0]
000077a70fdd2b1c  vmovaps xmm12, [rsp+0xB0]
000077a70fdd2b25  vmovaps xmm13, [rsp+0xC0]
000077a70fdd2b2e  vmovaps xmm14, [rsp+0xD0]
000077a70fdd2b37  vmovaps xmm15, [rsp+0xE0]
000077a70fdd2b40  add rsp, 0xF0
000077a70fdd2b47  pop r11
000077a70fdd2b49  pop r10
000077a70fdd2b4b  pop r9
000077a70fdd2b4d  pop r8
000077a70fdd2b4f  pop rsi
000077a70fdd2b50  pop rdi
000077a70fdd2b51  pop rdx
000077a70fdd2b52  pop rcx
000077a70fdd2b53  pop rax
000077a70fdd2b54  add rsp, 0x08
000077a70fdd2b58  jmp 0x000077A70FDCFDB6
000077a70fdd2b5d  sub rsp, 0x08
000077a70fdd2b61  push rax
000077a70fdd2b62  push rcx
000077a70fdd2b63  push rdx
000077a70fdd2b64  push rdi
000077a70fdd2b65  push rsi
000077a70fdd2b66  push r8
000077a70fdd2b68  push r9
000077a70fdd2b6a  push r10
000077a70fdd2b6c  push r11
000077a70fdd2b6e  sub rsp, 0xF0
000077a70fdd2b75  vmovaps [rsp], xmm0
000077a70fdd2b7a  vmovaps [rsp+0x10], xmm1
000077a70fdd2b80  vmovaps [rsp+0x20], xmm2
000077a70fdd2b86  vmovaps [rsp+0x30], xmm3
000077a70fdd2b8c  vmovaps [rsp+0x40], xmm4
000077a70fdd2b92  vmovaps [rsp+0x50], xmm6
000077a70fdd2b98  vmovaps [rsp+0x60], xmm7
000077a70fdd2b9e  vmovaps [rsp+0x70], xmm8
000077a70fdd2ba4  vmovaps [rsp+0x80], xmm9
000077a70fdd2bad  vmovaps [rsp+0x90], xmm10
000077a70fdd2bb6  vmovaps [rsp+0xA0], xmm11
000077a70fdd2bbf  vmovaps [rsp+0xB0], xmm12
000077a70fdd2bc8  vmovaps [rsp+0xC0], xmm13
000077a70fdd2bd1  vmovaps [rsp+0xD0], xmm14
000077a70fdd2bda  vmovaps [rsp+0xE0], xmm15
000077a70fdd2be3  sub rsp, 0x30
000077a70fdd2be7  movaps [rsp], xmm5
000077a70fdd2beb  movaps [rsp+0x10], xmm2
000077a70fdd2bf0  movaps [rsp+0x20], xmm13
000077a70fdd2bf6  lea rdi, [rsp]
000077a70fdd2bfa  mov esi, 0x00
000077a70fdd2bff  mov rax, 0x6294188EF530
000077a70fdd2c09  call rax
000077a70fdd2c0b  movaps xmm5, [rsp]
000077a70fdd2c0f  add rsp, 0x30
000077a70fdd2c13  vmovaps xmm0, [rsp]
000077a70fdd2c18  vmovaps xmm1, [rsp+0x10]
000077a70fdd2c1e  vmovaps xmm2, [rsp+0x20]
000077a70fdd2c24  vmovaps xmm3, [rsp+0x30]
000077a70fdd2c2a  vmovaps xmm4, [rsp+0x40]
000077a70fdd2c30  vmovaps xmm6, [rsp+0x50]
000077a70fdd2c36  vmovaps xmm7, [rsp+0x60]
000077a70fdd2c3c  vmovaps xmm8, [rsp+0x70]
000077a70fdd2c42  vmovaps xmm9, [rsp+0x80]
000077a70fdd2c4b  vmovaps xmm10, [rsp+0x90]
000077a70fdd2c54  vmovaps xmm11, [rsp+0xA0]
000077a70fdd2c5d  vmovaps xmm12, [rsp+0xB0]
000077a70fdd2c66  vmovaps xmm13, [rsp+0xC0]
000077a70fdd2c6f  vmovaps xmm14, [rsp+0xD0]
000077a70fdd2c78  vmovaps xmm15, [rsp+0xE0]
000077a70fdd2c81  add rsp, 0xF0
000077a70fdd2c88  pop r11
000077a70fdd2c8a  pop r10
000077a70fdd2c8c  pop r9
000077a70fdd2c8e  pop r8
000077a70fdd2c90  pop rsi
000077a70fdd2c91  pop rdi
000077a70fdd2c92  pop rdx
000077a70fdd2c93  pop rcx
000077a70fdd2c94  pop rax
000077a70fdd2c95  add rsp, 0x08
000077a70fdd2c99  jmp 0x000077A70FDCFDEC
000077a70fdd2c9e  sub rsp, 0x08
000077a70fdd2ca2  push rax
000077a70fdd2ca3  push rcx
000077a70fdd2ca4  push rdx
000077a70fdd2ca5  push rdi
000077a70fdd2ca6  push rsi
000077a70fdd2ca7  push r8
000077a70fdd2ca9  push r9
000077a70fdd2cab  push r10
000077a70fdd2cad  push r11
000077a70fdd2caf  sub rsp, 0xF0
000077a70fdd2cb6  vmovaps [rsp], xmm0
000077a70fdd2cbb  vmovaps [rsp+0x10], xmm1
000077a70fdd2cc1  vmovaps [rsp+0x20], xmm2
000077a70fdd2cc7  vmovaps [rsp+0x30], xmm3
000077a70fdd2ccd  vmovaps [rsp+0x40], xmm4
000077a70fdd2cd3  vmovaps [rsp+0x50], xmm5
000077a70fdd2cd9  vmovaps [rsp+0x60], xmm6
000077a70fdd2cdf  vmovaps [rsp+0x70], xmm7
000077a70fdd2ce5  vmovaps [rsp+0x80], xmm8
000077a70fdd2cee  vmovaps [rsp+0x90], xmm9
000077a70fdd2cf7  vmovaps [rsp+0xA0], xmm10
000077a70fdd2d00  vmovaps [rsp+0xB0], xmm11
000077a70fdd2d09  vmovaps [rsp+0xC0], xmm12
000077a70fdd2d12  vmovaps [rsp+0xD0], xmm14
000077a70fdd2d1b  vmovaps [rsp+0xE0], xmm15
000077a70fdd2d24  sub rsp, 0x30
000077a70fdd2d28  movaps [rsp], xmm13
000077a70fdd2d2d  movaps [rsp+0x10], xmm10
000077a70fdd2d33  movaps [rsp+0x20], xmm1
000077a70fdd2d38  lea rdi, [rsp]
000077a70fdd2d3c  mov esi, 0x00
000077a70fdd2d41  mov rax, 0x6294188EF530
000077a70fdd2d4b  call rax
000077a70fdd2d4d  movaps xmm13, [rsp]
000077a70fdd2d52  add rsp, 0x30
000077a70fdd2d56  vmovaps xmm0, [rsp]
000077a70fdd2d5b  vmovaps xmm1, [rsp+0x10]
000077a70fdd2d61  vmovaps xmm2, [rsp+0x20]
000077a70fdd2d67  vmovaps xmm3, [rsp+0x30]
000077a70fdd2d6d  vmovaps xmm4, [rsp+0x40]
000077a70fdd2d73  vmovaps xmm5, [rsp+0x50]
000077a70fdd2d79  vmovaps xmm6, [rsp+0x60]
000077a70fdd2d7f  vmovaps xmm7, [rsp+0x70]
000077a70fdd2d85  vmovaps xmm8, [rsp+0x80]
000077a70fdd2d8e  vmovaps xmm9, [rsp+0x90]
000077a70fdd2d97  vmovaps xmm10, [rsp+0xA0]
000077a70fdd2da0  vmovaps xmm11, [rsp+0xB0]
000077a70fdd2da9  vmovaps xmm12, [rsp+0xC0]
000077a70fdd2db2  vmovaps xmm14, [rsp+0xD0]
000077a70fdd2dbb  vmovaps xmm15, [rsp+0xE0]
000077a70fdd2dc4  add rsp, 0xF0
000077a70fdd2dcb  pop r11
000077a70fdd2dcd  pop r10
000077a70fdd2dcf  pop r9
000077a70fdd2dd1  pop r8
000077a70fdd2dd3  pop rsi
000077a70fdd2dd4  pop rdi
000077a70fdd2dd5  pop rdx
000077a70fdd2dd6  pop rcx
000077a70fdd2dd7  pop rax
000077a70fdd2dd8  add rsp, 0x08
000077a70fdd2ddc  jmp 0x000077A70FDCFE15
000077a70fdd2de1  sub rsp, 0x08
000077a70fdd2de5  push rax
000077a70fdd2de6  push rcx
000077a70fdd2de7  push rdx
000077a70fdd2de8  push rdi
000077a70fdd2de9  push rsi
000077a70fdd2dea  push r8
000077a70fdd2dec  push r9
000077a70fdd2dee  push r10
000077a70fdd2df0  push r11
000077a70fdd2df2  sub rsp, 0xF0
000077a70fdd2df9  vmovaps [rsp], xmm0
000077a70fdd2dfe  vmovaps [rsp+0x10], xmm2
000077a70fdd2e04  vmovaps [rsp+0x20], xmm3
000077a70fdd2e0a  vmovaps [rsp+0x30], xmm4
000077a70fdd2e10  vmovaps [rsp+0x40], xmm5
000077a70fdd2e16  vmovaps [rsp+0x50], xmm6
000077a70fdd2e1c  vmovaps [rsp+0x60], xmm7
000077a70fdd2e22  vmovaps [rsp+0x70], xmm8
000077a70fdd2e28  vmovaps [rsp+0x80], xmm9
000077a70fdd2e31  vmovaps [rsp+0x90], xmm10
000077a70fdd2e3a  vmovaps [rsp+0xA0], xmm11
000077a70fdd2e43  vmovaps [rsp+0xB0], xmm12
000077a70fdd2e4c  vmovaps [rsp+0xC0], xmm13
000077a70fdd2e55  vmovaps [rsp+0xD0], xmm14
000077a70fdd2e5e  vmovaps [rsp+0xE0], xmm15
000077a70fdd2e67  sub rsp, 0x30
000077a70fdd2e6b  movaps [rsp], xmm1
000077a70fdd2e6f  movaps [rsp+0x10], xmm15
000077a70fdd2e75  movaps [rsp+0x20], xmm10
000077a70fdd2e7b  lea rdi, [rsp]
000077a70fdd2e7f  mov esi, 0x00
000077a70fdd2e84  mov rax, 0x6294188EF530
000077a70fdd2e8e  call rax
000077a70fdd2e90  movaps xmm1, [rsp]
000077a70fdd2e94  add rsp, 0x30
000077a70fdd2e98  vmovaps xmm0, [rsp]
000077a70fdd2e9d  vmovaps xmm2, [rsp+0x10]
000077a70fdd2ea3  vmovaps xmm3, [rsp+0x20]
000077a70fdd2ea9  vmovaps xmm4, [rsp+0x30]
000077a70fdd2eaf  vmovaps xmm5, [rsp+0x40]
000077a70fdd2eb5  vmovaps xmm6, [rsp+0x50]
000077a70fdd2ebb  vmovaps xmm7, [rsp+0x60]
000077a70fdd2ec1  vmovaps xmm8, [rsp+0x70]
000077a70fdd2ec7  vmovaps xmm9, [rsp+0x80]
000077a70fdd2ed0  vmovaps xmm10, [rsp+0x90]
000077a70fdd2ed9  vmovaps xmm11, [rsp+0xA0]
000077a70fdd2ee2  vmovaps xmm12, [rsp+0xB0]
000077a70fdd2eeb  vmovaps xmm13, [rsp+0xC0]
000077a70fdd2ef4  vmovaps xmm14, [rsp+0xD0]
000077a70fdd2efd  vmovaps xmm15, [rsp+0xE0]
000077a70fdd2f06  add rsp, 0xF0
000077a70fdd2f0d  pop r11
000077a70fdd2f0f  pop r10
000077a70fdd2f11  pop r9
000077a70fdd2f13  pop r8
000077a70fdd2f15  pop rsi
000077a70fdd2f16  pop rdi
000077a70fdd2f17  pop rdx
000077a70fdd2f18  pop rcx
000077a70fdd2f19  pop rax
000077a70fdd2f1a  add rsp, 0x08
000077a70fdd2f1e  jmp 0x000077A70FDCFE34
000077a70fdd2f23  sub rsp, 0x08
000077a70fdd2f27  push rax
000077a70fdd2f28  push rcx
000077a70fdd2f29  push rdx
000077a70fdd2f2a  push rdi
000077a70fdd2f2b  push rsi
000077a70fdd2f2c  push r8
000077a70fdd2f2e  push r9
000077a70fdd2f30  push r10
000077a70fdd2f32  push r11
000077a70fdd2f34  sub rsp, 0xF0
000077a70fdd2f3b  vmovaps [rsp], xmm0
000077a70fdd2f40  vmovaps [rsp+0x10], xmm1
000077a70fdd2f46  vmovaps [rsp+0x20], xmm2
000077a70fdd2f4c  vmovaps [rsp+0x30], xmm3
000077a70fdd2f52  vmovaps [rsp+0x40], xmm4
000077a70fdd2f58  vmovaps [rsp+0x50], xmm5
000077a70fdd2f5e  vmovaps [rsp+0x60], xmm6
000077a70fdd2f64  vmovaps [rsp+0x70], xmm7
000077a70fdd2f6a  vmovaps [rsp+0x80], xmm8
000077a70fdd2f73  vmovaps [rsp+0x90], xmm9
000077a70fdd2f7c  vmovaps [rsp+0xA0], xmm10
000077a70fdd2f85  vmovaps [rsp+0xB0], xmm11
000077a70fdd2f8e  vmovaps [rsp+0xC0], xmm12
000077a70fdd2f97  vmovaps [rsp+0xD0], xmm13
000077a70fdd2fa0  vmovaps [rsp+0xE0], xmm14
000077a70fdd2fa9  sub rsp, 0x30
000077a70fdd2fad  movaps [rsp], xmm15
000077a70fdd2fb2  movaps [rsp+0x10], xmm10
000077a70fdd2fb8  movaps [rsp+0x20], xmm11
000077a70fdd2fbe  lea rdi, [rsp]
000077a70fdd2fc2  mov esi, 0x00
000077a70fdd2fc7  mov rax, 0x6294188EF530
000077a70fdd2fd1  call rax
000077a70fdd2fd3  movaps xmm15, [rsp]
000077a70fdd2fd8  add rsp, 0x30
000077a70fdd2fdc  vmovaps xmm0, [rsp]
000077a70fdd2fe1  vmovaps xmm1, [rsp+0x10]
000077a70fdd2fe7  vmovaps xmm2, [rsp+0x20]
000077a70fdd2fed  vmovaps xmm3, [rsp+0x30]
000077a70fdd2ff3  vmovaps xmm4, [rsp+0x40]
000077a70fdd2ff9  vmovaps xmm5, [rsp+0x50]
000077a70fdd2fff  vmovaps xmm6, [rsp+0x60]
000077a70fdd3005  vmovaps xmm7, [rsp+0x70]
000077a70fdd300b  vmovaps xmm8, [rsp+0x80]
000077a70fdd3014  vmovaps xmm9, [rsp+0x90]
000077a70fdd301d  vmovaps xmm10, [rsp+0xA0]
000077a70fdd3026  vmovaps xmm11, [rsp+0xB0]
000077a70fdd302f  vmovaps xmm12, [rsp+0xC0]
000077a70fdd3038  vmovaps xmm13, [rsp+0xD0]
000077a70fdd3041  vmovaps xmm14, [rsp+0xE0]
000077a70fdd304a  add rsp, 0xF0
000077a70fdd3051  pop r11
000077a70fdd3053  pop r10
000077a70fdd3055  pop r9
000077a70fdd3057  pop r8
000077a70fdd3059  pop rsi
000077a70fdd305a  pop rdi
000077a70fdd305b  pop rdx
000077a70fdd305c  pop rcx
000077a70fdd305d  pop rax
000077a70fdd305e  add rsp, 0x08
000077a70fdd3062  jmp 0x000077A70FDCFE57
000077a70fdd3067  sub rsp, 0x08
000077a70fdd306b  push rax
000077a70fdd306c  push rcx
000077a70fdd306d  push rdx
000077a70fdd306e  push rdi
000077a70fdd306f  push rsi
000077a70fdd3070  push r8
000077a70fdd3072  push r9
000077a70fdd3074  push r10
000077a70fdd3076  push r11
000077a70fdd3078  sub rsp, 0xF0
000077a70fdd307f  vmovaps [rsp], xmm0
000077a70fdd3084  vmovaps [rsp+0x10], xmm1
000077a70fdd308a  vmovaps [rsp+0x20], xmm2
000077a70fdd3090  vmovaps [rsp+0x30], xmm3
000077a70fdd3096  vmovaps [rsp+0x40], xmm4
000077a70fdd309c  vmovaps [rsp+0x50], xmm5
000077a70fdd30a2  vmovaps [rsp+0x60], xmm6
000077a70fdd30a8  vmovaps [rsp+0x70], xmm7
000077a70fdd30ae  vmovaps [rsp+0x80], xmm8
000077a70fdd30b7  vmovaps [rsp+0x90], xmm9
000077a70fdd30c0  vmovaps [rsp+0xA0], xmm11
000077a70fdd30c9  vmovaps [rsp+0xB0], xmm12
000077a70fdd30d2  vmovaps [rsp+0xC0], xmm13
000077a70fdd30db  vmovaps [rsp+0xD0], xmm14
000077a70fdd30e4  vmovaps [rsp+0xE0], xmm15
000077a70fdd30ed  sub rsp, 0x30
000077a70fdd30f1  movaps [rsp], xmm10
000077a70fdd30f6  movaps [rsp+0x10], xmm12
000077a70fdd30fc  movaps [rsp+0x20], xmm11
000077a70fdd3102  lea rdi, [rsp]
000077a70fdd3106  mov esi, 0x00
000077a70fdd310b  mov rax, 0x6294188EF530
000077a70fdd3115  call rax
000077a70fdd3117  movaps xmm10, [rsp]
000077a70fdd311c  add rsp, 0x30
000077a70fdd3120  vmovaps xmm0, [rsp]
000077a70fdd3125  vmovaps xmm1, [rsp+0x10]
000077a70fdd312b  vmovaps xmm2, [rsp+0x20]
000077a70fdd3131  vmovaps xmm3, [rsp+0x30]
000077a70fdd3137  vmovaps xmm4, [rsp+0x40]
000077a70fdd313d  vmovaps xmm5, [rsp+0x50]
000077a70fdd3143  vmovaps xmm6, [rsp+0x60]
000077a70fdd3149  vmovaps xmm7, [rsp+0x70]
000077a70fdd314f  vmovaps xmm8, [rsp+0x80]
000077a70fdd3158  vmovaps xmm9, [rsp+0x90]
000077a70fdd3161  vmovaps xmm11, [rsp+0xA0]
000077a70fdd316a  vmovaps xmm12, [rsp+0xB0]
000077a70fdd3173  vmovaps xmm13, [rsp+0xC0]
000077a70fdd317c  vmovaps xmm14, [rsp+0xD0]
000077a70fdd3185  vmovaps xmm15, [rsp+0xE0]
000077a70fdd318e  add rsp, 0xF0
000077a70fdd3195  pop r11
000077a70fdd3197  pop r10
000077a70fdd3199  pop r9
000077a70fdd319b  pop r8
000077a70fdd319d  pop rsi
000077a70fdd319e  pop rdi
000077a70fdd319f  pop rdx
000077a70fdd31a0  pop rcx
000077a70fdd31a1  pop rax
000077a70fdd31a2  add rsp, 0x08
000077a70fdd31a6  jmp 0x000077A70FDCFE80
000077a70fdd31ab  sub rsp, 0x08
000077a70fdd31af  push rax
000077a70fdd31b0  push rcx
000077a70fdd31b1  push rdx
000077a70fdd31b2  push rdi
000077a70fdd31b3  push rsi
000077a70fdd31b4  push r8
000077a70fdd31b6  push r9
000077a70fdd31b8  push r10
000077a70fdd31ba  push r11
000077a70fdd31bc  sub rsp, 0xF0
000077a70fdd31c3  vmovaps [rsp], xmm0
000077a70fdd31c8  vmovaps [rsp+0x10], xmm1
000077a70fdd31ce  vmovaps [rsp+0x20], xmm2
000077a70fdd31d4  vmovaps [rsp+0x30], xmm3
000077a70fdd31da  vmovaps [rsp+0x40], xmm4
000077a70fdd31e0  vmovaps [rsp+0x50], xmm5
000077a70fdd31e6  vmovaps [rsp+0x60], xmm6
000077a70fdd31ec  vmovaps [rsp+0x70], xmm7
000077a70fdd31f2  vmovaps [rsp+0x80], xmm8
000077a70fdd31fb  vmovaps [rsp+0x90], xmm9
000077a70fdd3204  vmovaps [rsp+0xA0], xmm10
000077a70fdd320d  vmovaps [rsp+0xB0], xmm12
000077a70fdd3216  vmovaps [rsp+0xC0], xmm13
000077a70fdd321f  vmovaps [rsp+0xD0], xmm14
000077a70fdd3228  vmovaps [rsp+0xE0], xmm15
000077a70fdd3231  sub rsp, 0x30
000077a70fdd3235  movaps [rsp], xmm11
000077a70fdd323a  movaps [rsp+0x10], xmm2
000077a70fdd323f  movaps [rsp+0x20], xmm12
000077a70fdd3245  lea rdi, [rsp]
000077a70fdd3249  mov esi, 0x00
000077a70fdd324e  mov rax, 0x6294188EF530
000077a70fdd3258  call rax
000077a70fdd325a  movaps xmm11, [rsp]
000077a70fdd325f  add rsp, 0x30
000077a70fdd3263  vmovaps xmm0, [rsp]
000077a70fdd3268  vmovaps xmm1, [rsp+0x10]
000077a70fdd326e  vmovaps xmm2, [rsp+0x20]
000077a70fdd3274  vmovaps xmm3, [rsp+0x30]
000077a70fdd327a  vmovaps xmm4, [rsp+0x40]
000077a70fdd3280  vmovaps xmm5, [rsp+0x50]
000077a70fdd3286  vmovaps xmm6, [rsp+0x60]
000077a70fdd328c  vmovaps xmm7, [rsp+0x70]
000077a70fdd3292  vmovaps xmm8, [rsp+0x80]
000077a70fdd329b  vmovaps xmm9, [rsp+0x90]
000077a70fdd32a4  vmovaps xmm10, [rsp+0xA0]
000077a70fdd32ad  vmovaps xmm12, [rsp+0xB0]
000077a70fdd32b6  vmovaps xmm13, [rsp+0xC0]
000077a70fdd32bf  vmovaps xmm14, [rsp+0xD0]
000077a70fdd32c8  vmovaps xmm15, [rsp+0xE0]
000077a70fdd32d1  add rsp, 0xF0
000077a70fdd32d8  pop r11
000077a70fdd32da  pop r10
000077a70fdd32dc  pop r9
000077a70fdd32de  pop r8
000077a70fdd32e0  pop rsi
000077a70fdd32e1  pop rdi
000077a70fdd32e2  pop rdx
000077a70fdd32e3  pop rcx
000077a70fdd32e4  pop rax
000077a70fdd32e5  add rsp, 0x08
000077a70fdd32e9  jmp 0x000077A70FDCFEB8
000077a70fdd32ee  sub rsp, 0x08
000077a70fdd32f2  push rax
000077a70fdd32f3  push rcx
000077a70fdd32f4  push rdx
000077a70fdd32f5  push rdi
000077a70fdd32f6  push rsi
000077a70fdd32f7  push r8
000077a70fdd32f9  push r9
000077a70fdd32fb  push r10
000077a70fdd32fd  push r11
000077a70fdd32ff  sub rsp, 0xF0
000077a70fdd3306  vmovaps [rsp], xmm0
000077a70fdd330b  vmovaps [rsp+0x10], xmm2
000077a70fdd3311  vmovaps [rsp+0x20], xmm3
000077a70fdd3317  vmovaps [rsp+0x30], xmm4
000077a70fdd331d  vmovaps [rsp+0x40], xmm5
000077a70fdd3323  vmovaps [rsp+0x50], xmm6
000077a70fdd3329  vmovaps [rsp+0x60], xmm7
000077a70fdd332f  vmovaps [rsp+0x70], xmm8
000077a70fdd3335  vmovaps [rsp+0x80], xmm9
000077a70fdd333e  vmovaps [rsp+0x90], xmm10
000077a70fdd3347  vmovaps [rsp+0xA0], xmm11
000077a70fdd3350  vmovaps [rsp+0xB0], xmm12
000077a70fdd3359  vmovaps [rsp+0xC0], xmm13
000077a70fdd3362  vmovaps [rsp+0xD0], xmm14
000077a70fdd336b  vmovaps [rsp+0xE0], xmm15
000077a70fdd3374  sub rsp, 0x30
000077a70fdd3378  movaps [rsp], xmm1
000077a70fdd337c  movaps [rsp+0x10], xmm14
000077a70fdd3382  movaps [rsp+0x20], xmm6
000077a70fdd3387  lea rdi, [rsp]
000077a70fdd338b  mov esi, 0x00
000077a70fdd3390  mov rax, 0x6294188EF530
000077a70fdd339a  call rax
000077a70fdd339c  movaps xmm1, [rsp]
000077a70fdd33a0  add rsp, 0x30
000077a70fdd33a4  vmovaps xmm0, [rsp]
000077a70fdd33a9  vmovaps xmm2, [rsp+0x10]
000077a70fdd33af  vmovaps xmm3, [rsp+0x20]
000077a70fdd33b5  vmovaps xmm4, [rsp+0x30]
000077a70fdd33bb  vmovaps xmm5, [rsp+0x40]
000077a70fdd33c1  vmovaps xmm6, [rsp+0x50]
000077a70fdd33c7  vmovaps xmm7, [rsp+0x60]
000077a70fdd33cd  vmovaps xmm8, [rsp+0x70]
000077a70fdd33d3  vmovaps xmm9, [rsp+0x80]
000077a70fdd33dc  vmovaps xmm10, [rsp+0x90]
000077a70fdd33e5  vmovaps xmm11, [rsp+0xA0]
000077a70fdd33ee  vmovaps xmm12, [rsp+0xB0]
000077a70fdd33f7  vmovaps xmm13, [rsp+0xC0]
000077a70fdd3400  vmovaps xmm14, [rsp+0xD0]
000077a70fdd3409  vmovaps xmm15, [rsp+0xE0]
000077a70fdd3412  add rsp, 0xF0
000077a70fdd3419  pop r11
000077a70fdd341b  pop r10
000077a70fdd341d  pop r9
000077a70fdd341f  pop r8
000077a70fdd3421  pop rsi
000077a70fdd3422  pop rdi
000077a70fdd3423  pop rdx
000077a70fdd3424  pop rcx
000077a70fdd3425  pop rax
000077a70fdd3426  add rsp, 0x08
000077a70fdd342a  jmp 0x000077A70FDCFED1
000077a70fdd342f  sub rsp, 0x08
000077a70fdd3433  push rax
000077a70fdd3434  push rcx
000077a70fdd3435  push rdx
000077a70fdd3436  push rdi
000077a70fdd3437  push rsi
000077a70fdd3438  push r8
000077a70fdd343a  push r9
000077a70fdd343c  push r10
000077a70fdd343e  push r11
000077a70fdd3440  sub rsp, 0xF0
000077a70fdd3447  vmovaps [rsp], xmm0
000077a70fdd344c  vmovaps [rsp+0x10], xmm1
000077a70fdd3452  vmovaps [rsp+0x20], xmm2
000077a70fdd3458  vmovaps [rsp+0x30], xmm3
000077a70fdd345e  vmovaps [rsp+0x40], xmm4
000077a70fdd3464  vmovaps [rsp+0x50], xmm5
000077a70fdd346a  vmovaps [rsp+0x60], xmm6
000077a70fdd3470  vmovaps [rsp+0x70], xmm7
000077a70fdd3476  vmovaps [rsp+0x80], xmm8
000077a70fdd347f  vmovaps [rsp+0x90], xmm9
000077a70fdd3488  vmovaps [rsp+0xA0], xmm10
000077a70fdd3491  vmovaps [rsp+0xB0], xmm11
000077a70fdd349a  vmovaps [rsp+0xC0], xmm12
000077a70fdd34a3  vmovaps [rsp+0xD0], xmm13
000077a70fdd34ac  vmovaps [rsp+0xE0], xmm15
000077a70fdd34b5  sub rsp, 0x30
000077a70fdd34b9  movaps [rsp], xmm14
000077a70fdd34be  movaps [rsp+0x10], xmm12
000077a70fdd34c4  movaps [rsp+0x20], xmm5
000077a70fdd34c9  lea rdi, [rsp]
000077a70fdd34cd  mov esi, 0x00
000077a70fdd34d2  mov rax, 0x6294188EF530
000077a70fdd34dc  call rax
000077a70fdd34de  movaps xmm14, [rsp]
000077a70fdd34e3  add rsp, 0x30
000077a70fdd34e7  vmovaps xmm0, [rsp]
000077a70fdd34ec  vmovaps xmm1, [rsp+0x10]
000077a70fdd34f2  vmovaps xmm2, [rsp+0x20]
000077a70fdd34f8  vmovaps xmm3, [rsp+0x30]
000077a70fdd34fe  vmovaps xmm4, [rsp+0x40]
000077a70fdd3504  vmovaps xmm5, [rsp+0x50]
000077a70fdd350a  vmovaps xmm6, [rsp+0x60]
000077a70fdd3510  vmovaps xmm7, [rsp+0x70]
000077a70fdd3516  vmovaps xmm8, [rsp+0x80]
000077a70fdd351f  vmovaps xmm9, [rsp+0x90]
000077a70fdd3528  vmovaps xmm10, [rsp+0xA0]
000077a70fdd3531  vmovaps xmm11, [rsp+0xB0]
000077a70fdd353a  vmovaps xmm12, [rsp+0xC0]
000077a70fdd3543  vmovaps xmm13, [rsp+0xD0]
000077a70fdd354c  vmovaps xmm15, [rsp+0xE0]
000077a70fdd3555  add rsp, 0xF0
000077a70fdd355c  pop r11
000077a70fdd355e  pop r10
000077a70fdd3560  pop r9
000077a70fdd3562  pop r8
000077a70fdd3564  pop rsi
000077a70fdd3565  pop rdi
000077a70fdd3566  pop rdx
000077a70fdd3567  pop rcx
000077a70fdd3568  pop rax
000077a70fdd3569  add rsp, 0x08
000077a70fdd356d  jmp 0x000077A70FDCFEF1
000077a70fdd3572  sub rsp, 0x08
000077a70fdd3576  push rax
000077a70fdd3577  push rcx
000077a70fdd3578  push rdx
000077a70fdd3579  push rdi
000077a70fdd357a  push rsi
000077a70fdd357b  push r8
000077a70fdd357d  push r9
000077a70fdd357f  push r10
000077a70fdd3581  push r11
000077a70fdd3583  sub rsp, 0xF0
000077a70fdd358a  vmovaps [rsp], xmm0
000077a70fdd358f  vmovaps [rsp+0x10], xmm1
000077a70fdd3595  vmovaps [rsp+0x20], xmm2
000077a70fdd359b  vmovaps [rsp+0x30], xmm3
000077a70fdd35a1  vmovaps [rsp+0x40], xmm4
000077a70fdd35a7  vmovaps [rsp+0x50], xmm5
000077a70fdd35ad  vmovaps [rsp+0x60], xmm7
000077a70fdd35b3  vmovaps [rsp+0x70], xmm8
000077a70fdd35b9  vmovaps [rsp+0x80], xmm9
000077a70fdd35c2  vmovaps [rsp+0x90], xmm10
000077a70fdd35cb  vmovaps [rsp+0xA0], xmm11
000077a70fdd35d4  vmovaps [rsp+0xB0], xmm12
000077a70fdd35dd  vmovaps [rsp+0xC0], xmm13
000077a70fdd35e6  vmovaps [rsp+0xD0], xmm14
000077a70fdd35ef  vmovaps [rsp+0xE0], xmm15
000077a70fdd35f8  sub rsp, 0x30
000077a70fdd35fc  movaps [rsp], xmm6
000077a70fdd3600  movaps [rsp+0x10], xmm9
000077a70fdd3606  movaps [rsp+0x20], xmm12
000077a70fdd360c  lea rdi, [rsp]
000077a70fdd3610  mov esi, 0x00
000077a70fdd3615  mov rax, 0x6294188EF530
000077a70fdd361f  call rax
000077a70fdd3621  movaps xmm6, [rsp]
000077a70fdd3625  add rsp, 0x30
000077a70fdd3629  vmovaps xmm0, [rsp]
000077a70fdd362e  vmovaps xmm1, [rsp+0x10]
000077a70fdd3634  vmovaps xmm2, [rsp+0x20]
000077a70fdd363a  vmovaps xmm3, [rsp+0x30]
000077a70fdd3640  vmovaps xmm4, [rsp+0x40]
000077a70fdd3646  vmovaps xmm5, [rsp+0x50]
000077a70fdd364c  vmovaps xmm7, [rsp+0x60]
000077a70fdd3652  vmovaps xmm8, [rsp+0x70]
000077a70fdd3658  vmovaps xmm9, [rsp+0x80]
000077a70fdd3661  vmovaps xmm10, [rsp+0x90]
000077a70fdd366a  vmovaps xmm11, [rsp+0xA0]
000077a70fdd3673  vmovaps xmm12, [rsp+0xB0]
000077a70fdd367c  vmovaps xmm13, [rsp+0xC0]
000077a70fdd3685  vmovaps xmm14, [rsp+0xD0]
000077a70fdd368e  vmovaps xmm15, [rsp+0xE0]
000077a70fdd3697  add rsp, 0xF0
000077a70fdd369e  pop r11
000077a70fdd36a0  pop r10
000077a70fdd36a2  pop r9
000077a70fdd36a4  pop r8
000077a70fdd36a6  pop rsi
000077a70fdd36a7  pop rdi
000077a70fdd36a8  pop rdx
000077a70fdd36a9  pop rcx
000077a70fdd36aa  pop rax
000077a70fdd36ab  add rsp, 0x08
000077a70fdd36af  jmp 0x000077A70FDCFF19
000077a70fdd36b4  sub rsp, 0x08
000077a70fdd36b8  push rax
000077a70fdd36b9  push rcx
000077a70fdd36ba  push rdx
000077a70fdd36bb  push rdi
000077a70fdd36bc  push rsi
000077a70fdd36bd  push r8
000077a70fdd36bf  push r9
000077a70fdd36c1  push r10
000077a70fdd36c3  push r11
000077a70fdd36c5  sub rsp, 0xF0
000077a70fdd36cc  vmovaps [rsp], xmm0
000077a70fdd36d1  vmovaps [rsp+0x10], xmm1
000077a70fdd36d7  vmovaps [rsp+0x20], xmm2
000077a70fdd36dd  vmovaps [rsp+0x30], xmm3
000077a70fdd36e3  vmovaps [rsp+0x40], xmm4
000077a70fdd36e9  vmovaps [rsp+0x50], xmm5
000077a70fdd36ef  vmovaps [rsp+0x60], xmm6
000077a70fdd36f5  vmovaps [rsp+0x70], xmm7
000077a70fdd36fb  vmovaps [rsp+0x80], xmm8
000077a70fdd3704  vmovaps [rsp+0x90], xmm9
000077a70fdd370d  vmovaps [rsp+0xA0], xmm10
000077a70fdd3716  vmovaps [rsp+0xB0], xmm11
000077a70fdd371f  vmovaps [rsp+0xC0], xmm13
000077a70fdd3728  vmovaps [rsp+0xD0], xmm14
000077a70fdd3731  vmovaps [rsp+0xE0], xmm15
000077a70fdd373a  sub rsp, 0x30
000077a70fdd373e  movaps [rsp], xmm12
000077a70fdd3743  movaps [rsp+0x10], xmm15
000077a70fdd3749  movaps [rsp+0x20], xmm13
000077a70fdd374f  lea rdi, [rsp]
000077a70fdd3753  mov esi, 0x00
000077a70fdd3758  mov rax, 0x6294188EF530
000077a70fdd3762  call rax
000077a70fdd3764  movaps xmm12, [rsp]
000077a70fdd3769  add rsp, 0x30
000077a70fdd376d  vmovaps xmm0, [rsp]
000077a70fdd3772  vmovaps xmm1, [rsp+0x10]
000077a70fdd3778  vmovaps xmm2, [rsp+0x20]
000077a70fdd377e  vmovaps xmm3, [rsp+0x30]
000077a70fdd3784  vmovaps xmm4, [rsp+0x40]
000077a70fdd378a  vmovaps xmm5, [rsp+0x50]
000077a70fdd3790  vmovaps xmm6, [rsp+0x60]
000077a70fdd3796  vmovaps xmm7, [rsp+0x70]
000077a70fdd379c  vmovaps xmm8, [rsp+0x80]
000077a70fdd37a5  vmovaps xmm9, [rsp+0x90]
000077a70fdd37ae  vmovaps xmm10, [rsp+0xA0]
000077a70fdd37b7  vmovaps xmm11, [rsp+0xB0]
000077a70fdd37c0  vmovaps xmm13, [rsp+0xC0]
000077a70fdd37c9  vmovaps xmm14, [rsp+0xD0]
000077a70fdd37d2  vmovaps xmm15, [rsp+0xE0]
000077a70fdd37db  add rsp, 0xF0
000077a70fdd37e2  pop r11
000077a70fdd37e4  pop r10
000077a70fdd37e6  pop r9
000077a70fdd37e8  pop r8
000077a70fdd37ea  pop rsi
000077a70fdd37eb  pop rdi
000077a70fdd37ec  pop rdx
000077a70fdd37ed  pop rcx
000077a70fdd37ee  pop rax
000077a70fdd37ef  add rsp, 0x08
000077a70fdd37f3  jmp 0x000077A70FDCFF34
000077a70fdd37f8  sub rsp, 0x08
000077a70fdd37fc  push rax
000077a70fdd37fd  push rcx
000077a70fdd37fe  push rdx
000077a70fdd37ff  push rdi
000077a70fdd3800  push rsi
000077a70fdd3801  push r8
000077a70fdd3803  push r9
000077a70fdd3805  push r10
000077a70fdd3807  push r11
000077a70fdd3809  sub rsp, 0xF0
000077a70fdd3810  vmovaps [rsp], xmm0
000077a70fdd3815  vmovaps [rsp+0x10], xmm1
000077a70fdd381b  vmovaps [rsp+0x20], xmm2
000077a70fdd3821  vmovaps [rsp+0x30], xmm3
000077a70fdd3827  vmovaps [rsp+0x40], xmm4
000077a70fdd382d  vmovaps [rsp+0x50], xmm5
000077a70fdd3833  vmovaps [rsp+0x60], xmm6
000077a70fdd3839  vmovaps [rsp+0x70], xmm7
000077a70fdd383f  vmovaps [rsp+0x80], xmm8
000077a70fdd3848  vmovaps [rsp+0x90], xmm9
000077a70fdd3851  vmovaps [rsp+0xA0], xmm10
000077a70fdd385a  vmovaps [rsp+0xB0], xmm11
000077a70fdd3863  vmovaps [rsp+0xC0], xmm12
000077a70fdd386c  vmovaps [rsp+0xD0], xmm13
000077a70fdd3875  vmovaps [rsp+0xE0], xmm14
000077a70fdd387e  sub rsp, 0x30
000077a70fdd3882  movaps [rsp], xmm15
000077a70fdd3887  movaps [rsp+0x10], xmm13
000077a70fdd388d  movaps [rsp+0x20], xmm10
000077a70fdd3893  lea rdi, [rsp]
000077a70fdd3897  mov esi, 0x00
000077a70fdd389c  mov rax, 0x6294188EF530
000077a70fdd38a6  call rax
000077a70fdd38a8  movaps xmm15, [rsp]
000077a70fdd38ad  add rsp, 0x30
000077a70fdd38b1  vmovaps xmm0, [rsp]
000077a70fdd38b6  vmovaps xmm1, [rsp+0x10]
000077a70fdd38bc  vmovaps xmm2, [rsp+0x20]
000077a70fdd38c2  vmovaps xmm3, [rsp+0x30]
000077a70fdd38c8  vmovaps xmm4, [rsp+0x40]
000077a70fdd38ce  vmovaps xmm5, [rsp+0x50]
000077a70fdd38d4  vmovaps xmm6, [rsp+0x60]
000077a70fdd38da  vmovaps xmm7, [rsp+0x70]
000077a70fdd38e0  vmovaps xmm8, [rsp+0x80]
000077a70fdd38e9  vmovaps xmm9, [rsp+0x90]
000077a70fdd38f2  vmovaps xmm10, [rsp+0xA0]
000077a70fdd38fb  vmovaps xmm11, [rsp+0xB0]
000077a70fdd3904  vmovaps xmm12, [rsp+0xC0]
000077a70fdd390d  vmovaps xmm13, [rsp+0xD0]
000077a70fdd3916  vmovaps xmm14, [rsp+0xE0]
000077a70fdd391f  add rsp, 0xF0
000077a70fdd3926  pop r11
000077a70fdd3928  pop r10
000077a70fdd392a  pop r9
000077a70fdd392c  pop r8
000077a70fdd392e  pop rsi
000077a70fdd392f  pop rdi
000077a70fdd3930  pop rdx
000077a70fdd3931  pop rcx
000077a70fdd3932  pop rax
000077a70fdd3933  add rsp, 0x08
000077a70fdd3937  jmp 0x000077A70FDCFF55
000077a70fdd393c  call 0x000077A70FC0C260
000077a70fdd3941  jmp 0x000077A70FDCFFB0
000077a70fdd3946  sub rsp, 0x08
000077a70fdd394a  push rax
000077a70fdd394b  push rcx
000077a70fdd394c  push rdx
000077a70fdd394d  push rdi
000077a70fdd394e  push rsi
000077a70fdd394f  push r8
000077a70fdd3951  push r9
000077a70fdd3953  push r10
000077a70fdd3955  push r11
000077a70fdd3957  sub rsp, 0xF0
000077a70fdd395e  vmovaps [rsp], xmm0
000077a70fdd3963  vmovaps [rsp+0x10], xmm1
000077a70fdd3969  vmovaps [rsp+0x20], xmm2
000077a70fdd396f  vmovaps [rsp+0x30], xmm3
000077a70fdd3975  vmovaps [rsp+0x40], xmm4
000077a70fdd397b  vmovaps [rsp+0x50], xmm5
000077a70fdd3981  vmovaps [rsp+0x60], xmm6
000077a70fdd3987  vmovaps [rsp+0x70], xmm7
000077a70fdd398d  vmovaps [rsp+0x80], xmm8
000077a70fdd3996  vmovaps [rsp+0x90], xmm10
000077a70fdd399f  vmovaps [rsp+0xA0], xmm11
000077a70fdd39a8  vmovaps [rsp+0xB0], xmm12
000077a70fdd39b1  vmovaps [rsp+0xC0], xmm13
000077a70fdd39ba  vmovaps [rsp+0xD0], xmm14
000077a70fdd39c3  vmovaps [rsp+0xE0], xmm15
000077a70fdd39cc  sub rsp, 0x30
000077a70fdd39d0  movaps [rsp], xmm9
000077a70fdd39d5  movaps [rsp+0x10], xmm8
000077a70fdd39db  movaps [rsp+0x20], xmm10
000077a70fdd39e1  lea rdi, [rsp]
000077a70fdd39e5  mov esi, 0x00
000077a70fdd39ea  mov rax, 0x6294188EF530
000077a70fdd39f4  call rax
000077a70fdd39f6  movaps xmm9, [rsp]
000077a70fdd39fb  add rsp, 0x30
000077a70fdd39ff  vmovaps xmm0, [rsp]
000077a70fdd3a04  vmovaps xmm1, [rsp+0x10]
000077a70fdd3a0a  vmovaps xmm2, [rsp+0x20]
000077a70fdd3a10  vmovaps xmm3, [rsp+0x30]
000077a70fdd3a16  vmovaps xmm4, [rsp+0x40]
000077a70fdd3a1c  vmovaps xmm5, [rsp+0x50]
000077a70fdd3a22  vmovaps xmm6, [rsp+0x60]
000077a70fdd3a28  vmovaps xmm7, [rsp+0x70]
000077a70fdd3a2e  vmovaps xmm8, [rsp+0x80]
000077a70fdd3a37  vmovaps xmm10, [rsp+0x90]
000077a70fdd3a40  vmovaps xmm11, [rsp+0xA0]
000077a70fdd3a49  vmovaps xmm12, [rsp+0xB0]
000077a70fdd3a52  vmovaps xmm13, [rsp+0xC0]
000077a70fdd3a5b  vmovaps xmm14, [rsp+0xD0]
000077a70fdd3a64  vmovaps xmm15, [rsp+0xE0]
000077a70fdd3a6d  add rsp, 0xF0
000077a70fdd3a74  pop r11
000077a70fdd3a76  pop r10
000077a70fdd3a78  pop r9
000077a70fdd3a7a  pop r8
000077a70fdd3a7c  pop rsi
000077a70fdd3a7d  pop rdi
000077a70fdd3a7e  pop rdx
000077a70fdd3a7f  pop rcx
000077a70fdd3a80  pop rax
000077a70fdd3a81  add rsp, 0x08
000077a70fdd3a85  jmp 0x000077A70FDCFFE1
000077a70fdd3a8a  sub rsp, 0x08
000077a70fdd3a8e  push rax
000077a70fdd3a8f  push rcx
000077a70fdd3a90  push rdx
000077a70fdd3a91  push rdi
000077a70fdd3a92  push rsi
000077a70fdd3a93  push r8
000077a70fdd3a95  push r9
000077a70fdd3a97  push r10
000077a70fdd3a99  push r11
000077a70fdd3a9b  sub rsp, 0xF0
000077a70fdd3aa2  vmovaps [rsp], xmm0
000077a70fdd3aa7  vmovaps [rsp+0x10], xmm1
000077a70fdd3aad  vmovaps [rsp+0x20], xmm2
000077a70fdd3ab3  vmovaps [rsp+0x30], xmm3
000077a70fdd3ab9  vmovaps [rsp+0x40], xmm4
000077a70fdd3abf  vmovaps [rsp+0x50], xmm5
000077a70fdd3ac5  vmovaps [rsp+0x60], xmm6
000077a70fdd3acb  vmovaps [rsp+0x70], xmm7
000077a70fdd3ad1  vmovaps [rsp+0x80], xmm8
000077a70fdd3ada  vmovaps [rsp+0x90], xmm9
000077a70fdd3ae3  vmovaps [rsp+0xA0], xmm11
000077a70fdd3aec  vmovaps [rsp+0xB0], xmm12
000077a70fdd3af5  vmovaps [rsp+0xC0], xmm13
000077a70fdd3afe  vmovaps [rsp+0xD0], xmm14
000077a70fdd3b07  vmovaps [rsp+0xE0], xmm15
000077a70fdd3b10  sub rsp, 0x30
000077a70fdd3b14  movaps [rsp], xmm10
000077a70fdd3b19  movaps [rsp+0x10], xmm1
000077a70fdd3b1e  movaps [rsp+0x20], xmm11
000077a70fdd3b24  lea rdi, [rsp]
000077a70fdd3b28  mov esi, 0x00
000077a70fdd3b2d  mov rax, 0x6294188EF530
000077a70fdd3b37  call rax
000077a70fdd3b39  movaps xmm10, [rsp]
000077a70fdd3b3e  add rsp, 0x30
000077a70fdd3b42  vmovaps xmm0, [rsp]
000077a70fdd3b47  vmovaps xmm1, [rsp+0x10]
000077a70fdd3b4d  vmovaps xmm2, [rsp+0x20]
000077a70fdd3b53  vmovaps xmm3, [rsp+0x30]
000077a70fdd3b59  vmovaps xmm4, [rsp+0x40]
000077a70fdd3b5f  vmovaps xmm5, [rsp+0x50]
000077a70fdd3b65  vmovaps xmm6, [rsp+0x60]
000077a70fdd3b6b  vmovaps xmm7, [rsp+0x70]
000077a70fdd3b71  vmovaps xmm8, [rsp+0x80]
000077a70fdd3b7a  vmovaps xmm9, [rsp+0x90]
000077a70fdd3b83  vmovaps xmm11, [rsp+0xA0]
000077a70fdd3b8c  vmovaps xmm12, [rsp+0xB0]
000077a70fdd3b95  vmovaps xmm13, [rsp+0xC0]
000077a70fdd3b9e  vmovaps xmm14, [rsp+0xD0]
000077a70fdd3ba7  vmovaps xmm15, [rsp+0xE0]
000077a70fdd3bb0  add rsp, 0xF0
000077a70fdd3bb7  pop r11
000077a70fdd3bb9  pop r10
000077a70fdd3bbb  pop r9
000077a70fdd3bbd  pop r8
000077a70fdd3bbf  pop rsi
000077a70fdd3bc0  pop rdi
000077a70fdd3bc1  pop rdx
000077a70fdd3bc2  pop rcx
000077a70fdd3bc3  pop rax
000077a70fdd3bc4  add rsp, 0x08
000077a70fdd3bc8  jmp 0x000077A70FDCFFFC
000077a70fdd3bcd  sub rsp, 0x08
000077a70fdd3bd1  push rax
000077a70fdd3bd2  push rcx
000077a70fdd3bd3  push rdx
000077a70fdd3bd4  push rdi
000077a70fdd3bd5  push rsi
000077a70fdd3bd6  push r8
000077a70fdd3bd8  push r9
000077a70fdd3bda  push r10
000077a70fdd3bdc  push r11
000077a70fdd3bde  sub rsp, 0xF0
000077a70fdd3be5  vmovaps [rsp], xmm0
000077a70fdd3bea  vmovaps [rsp+0x10], xmm2
000077a70fdd3bf0  vmovaps [rsp+0x20], xmm3
000077a70fdd3bf6  vmovaps [rsp+0x30], xmm4
000077a70fdd3bfc  vmovaps [rsp+0x40], xmm5
000077a70fdd3c02  vmovaps [rsp+0x50], xmm6
000077a70fdd3c08  vmovaps [rsp+0x60], xmm7
000077a70fdd3c0e  vmovaps [rsp+0x70], xmm8
000077a70fdd3c14  vmovaps [rsp+0x80], xmm9
000077a70fdd3c1d  vmovaps [rsp+0x90], xmm10
000077a70fdd3c26  vmovaps [rsp+0xA0], xmm11
000077a70fdd3c2f  vmovaps [rsp+0xB0], xmm12
000077a70fdd3c38  vmovaps [rsp+0xC0], xmm13
000077a70fdd3c41  vmovaps [rsp+0xD0], xmm14
000077a70fdd3c4a  vmovaps [rsp+0xE0], xmm15
000077a70fdd3c53  sub rsp, 0x30
000077a70fdd3c57  movaps [rsp], xmm1
000077a70fdd3c5b  movaps [rsp+0x10], xmm14
000077a70fdd3c61  movaps [rsp+0x20], xmm6
000077a70fdd3c66  lea rdi, [rsp]
000077a70fdd3c6a  mov esi, 0x00
000077a70fdd3c6f  mov rax, 0x6294188EF530
000077a70fdd3c79  call rax
000077a70fdd3c7b  movaps xmm1, [rsp]
000077a70fdd3c7f  add rsp, 0x30
000077a70fdd3c83  vmovaps xmm0, [rsp]
000077a70fdd3c88  vmovaps xmm2, [rsp+0x10]
000077a70fdd3c8e  vmovaps xmm3, [rsp+0x20]
000077a70fdd3c94  vmovaps xmm4, [rsp+0x30]
000077a70fdd3c9a  vmovaps xmm5, [rsp+0x40]
000077a70fdd3ca0  vmovaps xmm6, [rsp+0x50]
000077a70fdd3ca6  vmovaps xmm7, [rsp+0x60]
000077a70fdd3cac  vmovaps xmm8, [rsp+0x70]
000077a70fdd3cb2  vmovaps xmm9, [rsp+0x80]
000077a70fdd3cbb  vmovaps xmm10, [rsp+0x90]
000077a70fdd3cc4  vmovaps xmm11, [rsp+0xA0]
000077a70fdd3ccd  vmovaps xmm12, [rsp+0xB0]
000077a70fdd3cd6  vmovaps xmm13, [rsp+0xC0]
000077a70fdd3cdf  vmovaps xmm14, [rsp+0xD0]
000077a70fdd3ce8  vmovaps xmm15, [rsp+0xE0]
000077a70fdd3cf1  add rsp, 0xF0
000077a70fdd3cf8  pop r11
000077a70fdd3cfa  pop r10
000077a70fdd3cfc  pop r9
000077a70fdd3cfe  pop r8
000077a70fdd3d00  pop rsi
000077a70fdd3d01  pop rdi
000077a70fdd3d02  pop rdx
000077a70fdd3d03  pop rcx
000077a70fdd3d04  pop rax
000077a70fdd3d05  add rsp, 0x08
000077a70fdd3d09  jmp 0x000077A70FDD0015
000077a70fdd3d0e  sub rsp, 0x08
000077a70fdd3d12  push rax
000077a70fdd3d13  push rcx
000077a70fdd3d14  push rdx
000077a70fdd3d15  push rdi
000077a70fdd3d16  push rsi
000077a70fdd3d17  push r8
000077a70fdd3d19  push r9
000077a70fdd3d1b  push r10
000077a70fdd3d1d  push r11
000077a70fdd3d1f  sub rsp, 0xF0
000077a70fdd3d26  vmovaps [rsp], xmm0
000077a70fdd3d2b  vmovaps [rsp+0x10], xmm1
000077a70fdd3d31  vmovaps [rsp+0x20], xmm2
000077a70fdd3d37  vmovaps [rsp+0x30], xmm3
000077a70fdd3d3d  vmovaps [rsp+0x40], xmm4
000077a70fdd3d43  vmovaps [rsp+0x50], xmm5
000077a70fdd3d49  vmovaps [rsp+0x60], xmm6
000077a70fdd3d4f  vmovaps [rsp+0x70], xmm7
000077a70fdd3d55  vmovaps [rsp+0x80], xmm8
000077a70fdd3d5e  vmovaps [rsp+0x90], xmm9
000077a70fdd3d67  vmovaps [rsp+0xA0], xmm10
000077a70fdd3d70  vmovaps [rsp+0xB0], xmm12
000077a70fdd3d79  vmovaps [rsp+0xC0], xmm13
000077a70fdd3d82  vmovaps [rsp+0xD0], xmm14
000077a70fdd3d8b  vmovaps [rsp+0xE0], xmm15
000077a70fdd3d94  sub rsp, 0x30
000077a70fdd3d98  movaps [rsp], xmm11
000077a70fdd3d9d  movaps [rsp+0x10], xmm13
000077a70fdd3da3  movaps [rsp+0x20], xmm14
000077a70fdd3da9  lea rdi, [rsp]
000077a70fdd3dad  mov esi, 0x00
000077a70fdd3db2  mov rax, 0x6294188EF530
000077a70fdd3dbc  call rax
000077a70fdd3dbe  movaps xmm11, [rsp]
000077a70fdd3dc3  add rsp, 0x30
000077a70fdd3dc7  vmovaps xmm0, [rsp]
000077a70fdd3dcc  vmovaps xmm1, [rsp+0x10]
000077a70fdd3dd2  vmovaps xmm2, [rsp+0x20]
000077a70fdd3dd8  vmovaps xmm3, [rsp+0x30]
000077a70fdd3dde  vmovaps xmm4, [rsp+0x40]
000077a70fdd3de4  vmovaps xmm5, [rsp+0x50]
000077a70fdd3dea  vmovaps xmm6, [rsp+0x60]
000077a70fdd3df0  vmovaps xmm7, [rsp+0x70]
000077a70fdd3df6  vmovaps xmm8, [rsp+0x80]
000077a70fdd3dff  vmovaps xmm9, [rsp+0x90]
000077a70fdd3e08  vmovaps xmm10, [rsp+0xA0]
000077a70fdd3e11  vmovaps xmm12, [rsp+0xB0]
000077a70fdd3e1a  vmovaps xmm13, [rsp+0xC0]
000077a70fdd3e23  vmovaps xmm14, [rsp+0xD0]
000077a70fdd3e2c  vmovaps xmm15, [rsp+0xE0]
000077a70fdd3e35  add rsp, 0xF0
000077a70fdd3e3c  pop r11
000077a70fdd3e3e  pop r10
000077a70fdd3e40  pop r9
000077a70fdd3e42  pop r8
000077a70fdd3e44  pop rsi
000077a70fdd3e45  pop rdi
000077a70fdd3e46  pop rdx
000077a70fdd3e47  pop rcx
000077a70fdd3e48  pop rax
000077a70fdd3e49  add rsp, 0x08
000077a70fdd3e4d  jmp 0x000077A70FDD003F
000077a70fdd3e52  sub rsp, 0x08
000077a70fdd3e56  push rax
000077a70fdd3e57  push rcx
000077a70fdd3e58  push rdx
000077a70fdd3e59  push rdi
000077a70fdd3e5a  push rsi
000077a70fdd3e5b  push r8
000077a70fdd3e5d  push r9
000077a70fdd3e5f  push r10
000077a70fdd3e61  push r11
000077a70fdd3e63  sub rsp, 0xF0
000077a70fdd3e6a  vmovaps [rsp], xmm0
000077a70fdd3e6f  vmovaps [rsp+0x10], xmm1
000077a70fdd3e75  vmovaps [rsp+0x20], xmm2
000077a70fdd3e7b  vmovaps [rsp+0x30], xmm3
000077a70fdd3e81  vmovaps [rsp+0x40], xmm4
000077a70fdd3e87  vmovaps [rsp+0x50], xmm5
000077a70fdd3e8d  vmovaps [rsp+0x60], xmm6
000077a70fdd3e93  vmovaps [rsp+0x70], xmm7
000077a70fdd3e99  vmovaps [rsp+0x80], xmm8
000077a70fdd3ea2  vmovaps [rsp+0x90], xmm9
000077a70fdd3eab  vmovaps [rsp+0xA0], xmm10
000077a70fdd3eb4  vmovaps [rsp+0xB0], xmm11
000077a70fdd3ebd  vmovaps [rsp+0xC0], xmm12
000077a70fdd3ec6  vmovaps [rsp+0xD0], xmm14
000077a70fdd3ecf  vmovaps [rsp+0xE0], xmm15
000077a70fdd3ed8  sub rsp, 0x30
000077a70fdd3edc  movaps [rsp], xmm13
000077a70fdd3ee1  movaps [rsp+0x10], xmm8
000077a70fdd3ee7  movaps [rsp+0x20], xmm14
000077a70fdd3eed  lea rdi, [rsp]
000077a70fdd3ef1  mov esi, 0x00
000077a70fdd3ef6  mov rax, 0x6294188EF530
000077a70fdd3f00  call rax
000077a70fdd3f02  movaps xmm13, [rsp]
000077a70fdd3f07  add rsp, 0x30
000077a70fdd3f0b  vmovaps xmm0, [rsp]
000077a70fdd3f10  vmovaps xmm1, [rsp+0x10]
000077a70fdd3f16  vmovaps xmm2, [rsp+0x20]
000077a70fdd3f1c  vmovaps xmm3, [rsp+0x30]
000077a70fdd3f22  vmovaps xmm4, [rsp+0x40]
000077a70fdd3f28  vmovaps xmm5, [rsp+0x50]
000077a70fdd3f2e  vmovaps xmm6, [rsp+0x60]
000077a70fdd3f34  vmovaps xmm7, [rsp+0x70]
000077a70fdd3f3a  vmovaps xmm8, [rsp+0x80]
000077a70fdd3f43  vmovaps xmm9, [rsp+0x90]
000077a70fdd3f4c  vmovaps xmm10, [rsp+0xA0]
000077a70fdd3f55  vmovaps xmm11, [rsp+0xB0]
000077a70fdd3f5e  vmovaps xmm12, [rsp+0xC0]
000077a70fdd3f67  vmovaps xmm14, [rsp+0xD0]
000077a70fdd3f70  vmovaps xmm15, [rsp+0xE0]
000077a70fdd3f79  add rsp, 0xF0
000077a70fdd3f80  pop r11
000077a70fdd3f82  pop r10
000077a70fdd3f84  pop r9
000077a70fdd3f86  pop r8
000077a70fdd3f88  pop rsi
000077a70fdd3f89  pop rdi
000077a70fdd3f8a  pop rdx
000077a70fdd3f8b  pop rcx
000077a70fdd3f8c  pop rax
000077a70fdd3f8d  add rsp, 0x08
000077a70fdd3f91  jmp 0x000077A70FDD006E
000077a70fdd3f96  sub rsp, 0x08
000077a70fdd3f9a  push rax
000077a70fdd3f9b  push rcx
000077a70fdd3f9c  push rdx
000077a70fdd3f9d  push rdi
000077a70fdd3f9e  push rsi
000077a70fdd3f9f  push r8
000077a70fdd3fa1  push r9
000077a70fdd3fa3  push r10
000077a70fdd3fa5  push r11
000077a70fdd3fa7  sub rsp, 0xF0
000077a70fdd3fae  vmovaps [rsp], xmm0
000077a70fdd3fb3  vmovaps [rsp+0x10], xmm1
000077a70fdd3fb9  vmovaps [rsp+0x20], xmm2
000077a70fdd3fbf  vmovaps [rsp+0x30], xmm3
000077a70fdd3fc5  vmovaps [rsp+0x40], xmm4
000077a70fdd3fcb  vmovaps [rsp+0x50], xmm5
000077a70fdd3fd1  vmovaps [rsp+0x60], xmm6
000077a70fdd3fd7  vmovaps [rsp+0x70], xmm7
000077a70fdd3fdd  vmovaps [rsp+0x80], xmm9
000077a70fdd3fe6  vmovaps [rsp+0x90], xmm10
000077a70fdd3fef  vmovaps [rsp+0xA0], xmm11
000077a70fdd3ff8  vmovaps [rsp+0xB0], xmm12
000077a70fdd4001  vmovaps [rsp+0xC0], xmm13
000077a70fdd400a  vmovaps [rsp+0xD0], xmm14
000077a70fdd4013  vmovaps [rsp+0xE0], xmm15
000077a70fdd401c  sub rsp, 0x30
000077a70fdd4020  movaps [rsp], xmm8
000077a70fdd4025  movaps [rsp+0x10], xmm7
000077a70fdd402a  movaps [rsp+0x20], xmm14
000077a70fdd4030  lea rdi, [rsp]
000077a70fdd4034  mov esi, 0x00
000077a70fdd4039  mov rax, 0x6294188EF530
000077a70fdd4043  call rax
000077a70fdd4045  movaps xmm8, [rsp]
000077a70fdd404a  add rsp, 0x30
000077a70fdd404e  vmovaps xmm0, [rsp]
000077a70fdd4053  vmovaps xmm1, [rsp+0x10]
000077a70fdd4059  vmovaps xmm2, [rsp+0x20]
000077a70fdd405f  vmovaps xmm3, [rsp+0x30]
000077a70fdd4065  vmovaps xmm4, [rsp+0x40]
000077a70fdd406b  vmovaps xmm5, [rsp+0x50]
000077a70fdd4071  vmovaps xmm6, [rsp+0x60]
000077a70fdd4077  vmovaps xmm7, [rsp+0x70]
000077a70fdd407d  vmovaps xmm9, [rsp+0x80]
000077a70fdd4086  vmovaps xmm10, [rsp+0x90]
000077a70fdd408f  vmovaps xmm11, [rsp+0xA0]
000077a70fdd4098  vmovaps xmm12, [rsp+0xB0]
000077a70fdd40a1  vmovaps xmm13, [rsp+0xC0]
000077a70fdd40aa  vmovaps xmm14, [rsp+0xD0]
000077a70fdd40b3  vmovaps xmm15, [rsp+0xE0]
000077a70fdd40bc  add rsp, 0xF0
000077a70fdd40c3  pop r11
000077a70fdd40c5  pop r10
000077a70fdd40c7  pop r9
000077a70fdd40c9  pop r8
000077a70fdd40cb  pop rsi
000077a70fdd40cc  pop rdi
000077a70fdd40cd  pop rdx
000077a70fdd40ce  pop rcx
000077a70fdd40cf  pop rax
000077a70fdd40d0  add rsp, 0x08
000077a70fdd40d4  jmp 0x000077A70FDD0094
000077a70fdd40d9  sub rsp, 0x08
000077a70fdd40dd  push rax
000077a70fdd40de  push rcx
000077a70fdd40df  push rdx
000077a70fdd40e0  push rdi
000077a70fdd40e1  push rsi
000077a70fdd40e2  push r8
000077a70fdd40e4  push r9
000077a70fdd40e6  push r10
000077a70fdd40e8  push r11
000077a70fdd40ea  sub rsp, 0xF0
000077a70fdd40f1  vmovaps [rsp], xmm0
000077a70fdd40f6  vmovaps [rsp+0x10], xmm1
000077a70fdd40fc  vmovaps [rsp+0x20], xmm2
000077a70fdd4102  vmovaps [rsp+0x30], xmm3
000077a70fdd4108  vmovaps [rsp+0x40], xmm4
000077a70fdd410e  vmovaps [rsp+0x50], xmm5
000077a70fdd4114  vmovaps [rsp+0x60], xmm6
000077a70fdd411a  vmovaps [rsp+0x70], xmm7
000077a70fdd4120  vmovaps [rsp+0x80], xmm8
000077a70fdd4129  vmovaps [rsp+0x90], xmm9
000077a70fdd4132  vmovaps [rsp+0xA0], xmm10
000077a70fdd413b  vmovaps [rsp+0xB0], xmm11
000077a70fdd4144  vmovaps [rsp+0xC0], xmm12
000077a70fdd414d  vmovaps [rsp+0xD0], xmm13
000077a70fdd4156  vmovaps [rsp+0xE0], xmm15
000077a70fdd415f  sub rsp, 0x30
000077a70fdd4163  movaps [rsp], xmm14
000077a70fdd4168  movaps [rsp+0x10], xmm12
000077a70fdd416e  movaps [rsp+0x20], xmm9
000077a70fdd4174  lea rdi, [rsp]
000077a70fdd4178  mov esi, 0x00
000077a70fdd417d  mov rax, 0x6294188EF530
000077a70fdd4187  call rax
000077a70fdd4189  movaps xmm14, [rsp]
000077a70fdd418e  add rsp, 0x30
000077a70fdd4192  vmovaps xmm0, [rsp]
000077a70fdd4197  vmovaps xmm1, [rsp+0x10]
000077a70fdd419d  vmovaps xmm2, [rsp+0x20]
000077a70fdd41a3  vmovaps xmm3, [rsp+0x30]
000077a70fdd41a9  vmovaps xmm4, [rsp+0x40]
000077a70fdd41af  vmovaps xmm5, [rsp+0x50]
000077a70fdd41b5  vmovaps xmm6, [rsp+0x60]
000077a70fdd41bb  vmovaps xmm7, [rsp+0x70]
000077a70fdd41c1  vmovaps xmm8, [rsp+0x80]
000077a70fdd41ca  vmovaps xmm9, [rsp+0x90]
000077a70fdd41d3  vmovaps xmm10, [rsp+0xA0]
000077a70fdd41dc  vmovaps xmm11, [rsp+0xB0]
000077a70fdd41e5  vmovaps xmm12, [rsp+0xC0]
000077a70fdd41ee  vmovaps xmm13, [rsp+0xD0]
000077a70fdd41f7  vmovaps xmm15, [rsp+0xE0]
000077a70fdd4200  add rsp, 0xF0
000077a70fdd4207  pop r11
000077a70fdd4209  pop r10
000077a70fdd420b  pop r9
000077a70fdd420d  pop r8
000077a70fdd420f  pop rsi
000077a70fdd4210  pop rdi
000077a70fdd4211  pop rdx
000077a70fdd4212  pop rcx
000077a70fdd4213  pop rax
000077a70fdd4214  add rsp, 0x08
000077a70fdd4218  jmp 0x000077A70FDD00AE
000077a70fdd421d  sub rsp, 0x08
000077a70fdd4221  push rax
000077a70fdd4222  push rcx
000077a70fdd4223  push rdx
000077a70fdd4224  push rdi
000077a70fdd4225  push rsi
000077a70fdd4226  push r8
000077a70fdd4228  push r9
000077a70fdd422a  push r10
000077a70fdd422c  push r11
000077a70fdd422e  sub rsp, 0xF0
000077a70fdd4235  vmovaps [rsp], xmm0
000077a70fdd423a  vmovaps [rsp+0x10], xmm1
000077a70fdd4240  vmovaps [rsp+0x20], xmm2
000077a70fdd4246  vmovaps [rsp+0x30], xmm3
000077a70fdd424c  vmovaps [rsp+0x40], xmm4
000077a70fdd4252  vmovaps [rsp+0x50], xmm5
000077a70fdd4258  vmovaps [rsp+0x60], xmm6
000077a70fdd425e  vmovaps [rsp+0x70], xmm7
000077a70fdd4264  vmovaps [rsp+0x80], xmm8
000077a70fdd426d  vmovaps [rsp+0x90], xmm10
000077a70fdd4276  vmovaps [rsp+0xA0], xmm11
000077a70fdd427f  vmovaps [rsp+0xB0], xmm12
000077a70fdd4288  vmovaps [rsp+0xC0], xmm13
000077a70fdd4291  vmovaps [rsp+0xD0], xmm14
000077a70fdd429a  vmovaps [rsp+0xE0], xmm15
000077a70fdd42a3  sub rsp, 0x30
000077a70fdd42a7  movaps [rsp], xmm9
000077a70fdd42ac  movaps [rsp+0x10], xmm7
000077a70fdd42b1  movaps [rsp+0x20], xmm12
000077a70fdd42b7  lea rdi, [rsp]
000077a70fdd42bb  mov esi, 0x00
000077a70fdd42c0  mov rax, 0x6294188EF530
000077a70fdd42ca  call rax
000077a70fdd42cc  movaps xmm9, [rsp]
000077a70fdd42d1  add rsp, 0x30
000077a70fdd42d5  vmovaps xmm0, [rsp]
000077a70fdd42da  vmovaps xmm1, [rsp+0x10]
000077a70fdd42e0  vmovaps xmm2, [rsp+0x20]
000077a70fdd42e6  vmovaps xmm3, [rsp+0x30]
000077a70fdd42ec  vmovaps xmm4, [rsp+0x40]
000077a70fdd42f2  vmovaps xmm5, [rsp+0x50]
000077a70fdd42f8  vmovaps xmm6, [rsp+0x60]
000077a70fdd42fe  vmovaps xmm7, [rsp+0x70]
000077a70fdd4304  vmovaps xmm8, [rsp+0x80]
000077a70fdd430d  vmovaps xmm10, [rsp+0x90]
000077a70fdd4316  vmovaps xmm11, [rsp+0xA0]
000077a70fdd431f  vmovaps xmm12, [rsp+0xB0]
000077a70fdd4328  vmovaps xmm13, [rsp+0xC0]
000077a70fdd4331  vmovaps xmm14, [rsp+0xD0]
000077a70fdd433a  vmovaps xmm15, [rsp+0xE0]
000077a70fdd4343  add rsp, 0xF0
000077a70fdd434a  pop r11
000077a70fdd434c  pop r10
000077a70fdd434e  pop r9
000077a70fdd4350  pop r8
000077a70fdd4352  pop rsi
000077a70fdd4353  pop rdi
000077a70fdd4354  pop rdx
000077a70fdd4355  pop rcx
000077a70fdd4356  pop rax
000077a70fdd4357  add rsp, 0x08
000077a70fdd435b  jmp 0x000077A70FDD00DD
000077a70fdd4360  sub rsp, 0x08
000077a70fdd4364  push rax
000077a70fdd4365  push rcx
000077a70fdd4366  push rdx
000077a70fdd4367  push rdi
000077a70fdd4368  push rsi
000077a70fdd4369  push r8
000077a70fdd436b  push r9
000077a70fdd436d  push r10
000077a70fdd436f  push r11
000077a70fdd4371  sub rsp, 0xF0
000077a70fdd4378  vmovaps [rsp], xmm0
000077a70fdd437d  vmovaps [rsp+0x10], xmm1
000077a70fdd4383  vmovaps [rsp+0x20], xmm2
000077a70fdd4389  vmovaps [rsp+0x30], xmm3
000077a70fdd438f  vmovaps [rsp+0x40], xmm4
000077a70fdd4395  vmovaps [rsp+0x50], xmm5
000077a70fdd439b  vmovaps [rsp+0x60], xmm6
000077a70fdd43a1  vmovaps [rsp+0x70], xmm7
000077a70fdd43a7  vmovaps [rsp+0x80], xmm8
000077a70fdd43b0  vmovaps [rsp+0x90], xmm9
000077a70fdd43b9  vmovaps [rsp+0xA0], xmm10
000077a70fdd43c2  vmovaps [rsp+0xB0], xmm11
000077a70fdd43cb  vmovaps [rsp+0xC0], xmm13
000077a70fdd43d4  vmovaps [rsp+0xD0], xmm14
000077a70fdd43dd  vmovaps [rsp+0xE0], xmm15
000077a70fdd43e6  sub rsp, 0x30
000077a70fdd43ea  movaps [rsp], xmm12
000077a70fdd43ef  movaps [rsp+0x10], xmm15
000077a70fdd43f5  movaps [rsp+0x20], xmm11
000077a70fdd43fb  lea rdi, [rsp]
000077a70fdd43ff  mov esi, 0x00
000077a70fdd4404  mov rax, 0x6294188EF530
000077a70fdd440e  call rax
000077a70fdd4410  movaps xmm12, [rsp]
000077a70fdd4415  add rsp, 0x30
000077a70fdd4419  vmovaps xmm0, [rsp]
000077a70fdd441e  vmovaps xmm1, [rsp+0x10]
000077a70fdd4424  vmovaps xmm2, [rsp+0x20]
000077a70fdd442a  vmovaps xmm3, [rsp+0x30]
000077a70fdd4430  vmovaps xmm4, [rsp+0x40]
000077a70fdd4436  vmovaps xmm5, [rsp+0x50]
000077a70fdd443c  vmovaps xmm6, [rsp+0x60]
000077a70fdd4442  vmovaps xmm7, [rsp+0x70]
000077a70fdd4448  vmovaps xmm8, [rsp+0x80]
000077a70fdd4451  vmovaps xmm9, [rsp+0x90]
000077a70fdd445a  vmovaps xmm10, [rsp+0xA0]
000077a70fdd4463  vmovaps xmm11, [rsp+0xB0]
000077a70fdd446c  vmovaps xmm13, [rsp+0xC0]
000077a70fdd4475  vmovaps xmm14, [rsp+0xD0]
000077a70fdd447e  vmovaps xmm15, [rsp+0xE0]
000077a70fdd4487  add rsp, 0xF0
000077a70fdd448e  pop r11
000077a70fdd4490  pop r10
000077a70fdd4492  pop r9
000077a70fdd4494  pop r8
000077a70fdd4496  pop rsi
000077a70fdd4497  pop rdi
000077a70fdd4498  pop rdx
000077a70fdd4499  pop rcx
000077a70fdd449a  pop rax
000077a70fdd449b  add rsp, 0x08
000077a70fdd449f  jmp 0x000077A70FDD00F7
000077a70fdd44a4  sub rsp, 0x08
000077a70fdd44a8  push rax
000077a70fdd44a9  push rcx
000077a70fdd44aa  push rdx
000077a70fdd44ab  push rdi
000077a70fdd44ac  push rsi
000077a70fdd44ad  push r8
000077a70fdd44af  push r9
000077a70fdd44b1  push r10
000077a70fdd44b3  push r11
000077a70fdd44b5  sub rsp, 0xF0
000077a70fdd44bc  vmovaps [rsp], xmm0
000077a70fdd44c1  vmovaps [rsp+0x10], xmm1
000077a70fdd44c7  vmovaps [rsp+0x20], xmm2
000077a70fdd44cd  vmovaps [rsp+0x30], xmm3
000077a70fdd44d3  vmovaps [rsp+0x40], xmm4
000077a70fdd44d9  vmovaps [rsp+0x50], xmm5
000077a70fdd44df  vmovaps [rsp+0x60], xmm6
000077a70fdd44e5  vmovaps [rsp+0x70], xmm7
000077a70fdd44eb  vmovaps [rsp+0x80], xmm8
000077a70fdd44f4  vmovaps [rsp+0x90], xmm9
000077a70fdd44fd  vmovaps [rsp+0xA0], xmm10
000077a70fdd4506  vmovaps [rsp+0xB0], xmm12
000077a70fdd450f  vmovaps [rsp+0xC0], xmm13
000077a70fdd4518  vmovaps [rsp+0xD0], xmm14
000077a70fdd4521  vmovaps [rsp+0xE0], xmm15
000077a70fdd452a  sub rsp, 0x30
000077a70fdd452e  movaps [rsp], xmm11
000077a70fdd4533  movaps [rsp+0x10], xmm7
000077a70fdd4538  movaps [rsp+0x20], xmm15
000077a70fdd453e  lea rdi, [rsp]
000077a70fdd4542  mov esi, 0x00
000077a70fdd4547  mov rax, 0x6294188EF530
000077a70fdd4551  call rax
000077a70fdd4553  movaps xmm11, [rsp]
000077a70fdd4558  add rsp, 0x30
000077a70fdd455c  vmovaps xmm0, [rsp]
000077a70fdd4561  vmovaps xmm1, [rsp+0x10]
000077a70fdd4567  vmovaps xmm2, [rsp+0x20]
000077a70fdd456d  vmovaps xmm3, [rsp+0x30]
000077a70fdd4573  vmovaps xmm4, [rsp+0x40]
000077a70fdd4579  vmovaps xmm5, [rsp+0x50]
000077a70fdd457f  vmovaps xmm6, [rsp+0x60]
000077a70fdd4585  vmovaps xmm7, [rsp+0x70]
000077a70fdd458b  vmovaps xmm8, [rsp+0x80]
000077a70fdd4594  vmovaps xmm9, [rsp+0x90]
000077a70fdd459d  vmovaps xmm10, [rsp+0xA0]
000077a70fdd45a6  vmovaps xmm12, [rsp+0xB0]
000077a70fdd45af  vmovaps xmm13, [rsp+0xC0]
000077a70fdd45b8  vmovaps xmm14, [rsp+0xD0]
000077a70fdd45c1  vmovaps xmm15, [rsp+0xE0]
000077a70fdd45ca  add rsp, 0xF0
000077a70fdd45d1  pop r11
000077a70fdd45d3  pop r10
000077a70fdd45d5  pop r9
000077a70fdd45d7  pop r8
000077a70fdd45d9  pop rsi
000077a70fdd45da  pop rdi
000077a70fdd45db  pop rdx
000077a70fdd45dc  pop rcx
000077a70fdd45dd  pop rax
000077a70fdd45de  add rsp, 0x08
000077a70fdd45e2  jmp 0x000077A70FDD0123
000077a70fdd45e7  sub rsp, 0x08
000077a70fdd45eb  push rax
000077a70fdd45ec  push rcx
000077a70fdd45ed  push rdx
000077a70fdd45ee  push rdi
000077a70fdd45ef  push rsi
000077a70fdd45f0  push r8
000077a70fdd45f2  push r9
000077a70fdd45f4  push r10
000077a70fdd45f6  push r11
000077a70fdd45f8  sub rsp, 0xF0
000077a70fdd45ff  vmovaps [rsp], xmm0
000077a70fdd4604  vmovaps [rsp+0x10], xmm1
000077a70fdd460a  vmovaps [rsp+0x20], xmm2
000077a70fdd4610  vmovaps [rsp+0x30], xmm3
000077a70fdd4616  vmovaps [rsp+0x40], xmm4
000077a70fdd461c  vmovaps [rsp+0x50], xmm5
000077a70fdd4622  vmovaps [rsp+0x60], xmm6
000077a70fdd4628  vmovaps [rsp+0x70], xmm7
000077a70fdd462e  vmovaps [rsp+0x80], xmm8
000077a70fdd4637  vmovaps [rsp+0x90], xmm9
000077a70fdd4640  vmovaps [rsp+0xA0], xmm10
000077a70fdd4649  vmovaps [rsp+0xB0], xmm11
000077a70fdd4652  vmovaps [rsp+0xC0], xmm12
000077a70fdd465b  vmovaps [rsp+0xD0], xmm13
000077a70fdd4664  vmovaps [rsp+0xE0], xmm14
000077a70fdd466d  sub rsp, 0x30
000077a70fdd4671  movaps [rsp], xmm15
000077a70fdd4676  movaps [rsp+0x10], xmm10
000077a70fdd467c  movaps [rsp+0x20], xmm13
000077a70fdd4682  lea rdi, [rsp]
000077a70fdd4686  mov esi, 0x00
000077a70fdd468b  mov rax, 0x6294188EF530
000077a70fdd4695  call rax
000077a70fdd4697  movaps xmm15, [rsp]
000077a70fdd469c  add rsp, 0x30
000077a70fdd46a0  vmovaps xmm0, [rsp]
000077a70fdd46a5  vmovaps xmm1, [rsp+0x10]
000077a70fdd46ab  vmovaps xmm2, [rsp+0x20]
000077a70fdd46b1  vmovaps xmm3, [rsp+0x30]
000077a70fdd46b7  vmovaps xmm4, [rsp+0x40]
000077a70fdd46bd  vmovaps xmm5, [rsp+0x50]
000077a70fdd46c3  vmovaps xmm6, [rsp+0x60]
000077a70fdd46c9  vmovaps xmm7, [rsp+0x70]
000077a70fdd46cf  vmovaps xmm8, [rsp+0x80]
000077a70fdd46d8  vmovaps xmm9, [rsp+0x90]
000077a70fdd46e1  vmovaps xmm10, [rsp+0xA0]
000077a70fdd46ea  vmovaps xmm11, [rsp+0xB0]
000077a70fdd46f3  vmovaps xmm12, [rsp+0xC0]
000077a70fdd46fc  vmovaps xmm13, [rsp+0xD0]
000077a70fdd4705  vmovaps xmm14, [rsp+0xE0]
000077a70fdd470e  add rsp, 0xF0
000077a70fdd4715  pop r11
000077a70fdd4717  pop r10
000077a70fdd4719  pop r9
000077a70fdd471b  pop r8
000077a70fdd471d  pop rsi
000077a70fdd471e  pop rdi
000077a70fdd471f  pop rdx
000077a70fdd4720  pop rcx
000077a70fdd4721  pop rax
000077a70fdd4722  add rsp, 0x08
000077a70fdd4726  jmp 0x000077A70FDD013D
000077a70fdd472b  sub rsp, 0x08
000077a70fdd472f  push rax
000077a70fdd4730  push rcx
000077a70fdd4731  push rdx
000077a70fdd4732  push rdi
000077a70fdd4733  push rsi
000077a70fdd4734  push r8
000077a70fdd4736  push r9
000077a70fdd4738  push r10
000077a70fdd473a  push r11
000077a70fdd473c  sub rsp, 0xF0
000077a70fdd4743  vmovaps [rsp], xmm0
000077a70fdd4748  vmovaps [rsp+0x10], xmm1
000077a70fdd474e  vmovaps [rsp+0x20], xmm2
000077a70fdd4754  vmovaps [rsp+0x30], xmm3
000077a70fdd475a  vmovaps [rsp+0x40], xmm4
000077a70fdd4760  vmovaps [rsp+0x50], xmm5
000077a70fdd4766  vmovaps [rsp+0x60], xmm6
000077a70fdd476c  vmovaps [rsp+0x70], xmm7
000077a70fdd4772  vmovaps [rsp+0x80], xmm8
000077a70fdd477b  vmovaps [rsp+0x90], xmm9
000077a70fdd4784  vmovaps [rsp+0xA0], xmm11
000077a70fdd478d  vmovaps [rsp+0xB0], xmm12
000077a70fdd4796  vmovaps [rsp+0xC0], xmm13
000077a70fdd479f  vmovaps [rsp+0xD0], xmm14
000077a70fdd47a8  vmovaps [rsp+0xE0], xmm15
000077a70fdd47b1  sub rsp, 0x30
000077a70fdd47b5  movaps [rsp], xmm10
000077a70fdd47ba  movaps [rsp+0x10], xmm7
000077a70fdd47bf  movaps [rsp+0x20], xmm13
000077a70fdd47c5  lea rdi, [rsp]
000077a70fdd47c9  mov esi, 0x00
000077a70fdd47ce  mov rax, 0x6294188EF530
000077a70fdd47d8  call rax
000077a70fdd47da  movaps xmm10, [rsp]
000077a70fdd47df  add rsp, 0x30
000077a70fdd47e3  vmovaps xmm0, [rsp]
000077a70fdd47e8  vmovaps xmm1, [rsp+0x10]
000077a70fdd47ee  vmovaps xmm2, [rsp+0x20]
000077a70fdd47f4  vmovaps xmm3, [rsp+0x30]
000077a70fdd47fa  vmovaps xmm4, [rsp+0x40]
000077a70fdd4800  vmovaps xmm5, [rsp+0x50]
000077a70fdd4806  vmovaps xmm6, [rsp+0x60]
000077a70fdd480c  vmovaps xmm7, [rsp+0x70]
000077a70fdd4812  vmovaps xmm8, [rsp+0x80]
000077a70fdd481b  vmovaps xmm9, [rsp+0x90]
000077a70fdd4824  vmovaps xmm11, [rsp+0xA0]
000077a70fdd482d  vmovaps xmm12, [rsp+0xB0]
000077a70fdd4836  vmovaps xmm13, [rsp+0xC0]
000077a70fdd483f  vmovaps xmm14, [rsp+0xD0]
000077a70fdd4848  vmovaps xmm15, [rsp+0xE0]
000077a70fdd4851  add rsp, 0xF0
000077a70fdd4858  pop r11
000077a70fdd485a  pop r10
000077a70fdd485c  pop r9
000077a70fdd485e  pop r8
000077a70fdd4860  pop rsi
000077a70fdd4861  pop rdi
000077a70fdd4862  pop rdx
000077a70fdd4863  pop rcx
000077a70fdd4864  pop rax
000077a70fdd4865  add rsp, 0x08
000077a70fdd4869  jmp 0x000077A70FDD0169
000077a70fdd486e  sub rsp, 0x08
000077a70fdd4872  push rax
000077a70fdd4873  push rcx
000077a70fdd4874  push rdx
000077a70fdd4875  push rdi
000077a70fdd4876  push rsi
000077a70fdd4877  push r8
000077a70fdd4879  push r9
000077a70fdd487b  push r10
000077a70fdd487d  push r11
000077a70fdd487f  sub rsp, 0xF0
000077a70fdd4886  vmovaps [rsp], xmm0
000077a70fdd488b  vmovaps [rsp+0x10], xmm1
000077a70fdd4891  vmovaps [rsp+0x20], xmm2
000077a70fdd4897  vmovaps [rsp+0x30], xmm3
000077a70fdd489d  vmovaps [rsp+0x40], xmm4
000077a70fdd48a3  vmovaps [rsp+0x50], xmm5
000077a70fdd48a9  vmovaps [rsp+0x60], xmm6
000077a70fdd48af  vmovaps [rsp+0x70], xmm7
000077a70fdd48b5  vmovaps [rsp+0x80], xmm8
000077a70fdd48be  vmovaps [rsp+0x90], xmm9
000077a70fdd48c7  vmovaps [rsp+0xA0], xmm10
000077a70fdd48d0  vmovaps [rsp+0xB0], xmm11
000077a70fdd48d9  vmovaps [rsp+0xC0], xmm12
000077a70fdd48e2  vmovaps [rsp+0xD0], xmm14
000077a70fdd48eb  vmovaps [rsp+0xE0], xmm15
000077a70fdd48f4  sub rsp, 0x30
000077a70fdd48f8  movaps [rsp], xmm13
000077a70fdd48fd  movaps [rsp+0x10], xmm1
000077a70fdd4902  movaps [rsp+0x20], xmm8
000077a70fdd4908  lea rdi, [rsp]
000077a70fdd490c  mov esi, 0x00
000077a70fdd4911  mov rax, 0x6294188EF530
000077a70fdd491b  call rax
000077a70fdd491d  movaps xmm13, [rsp]
000077a70fdd4922  add rsp, 0x30
000077a70fdd4926  vmovaps xmm0, [rsp]
000077a70fdd492b  vmovaps xmm1, [rsp+0x10]
000077a70fdd4931  vmovaps xmm2, [rsp+0x20]
000077a70fdd4937  vmovaps xmm3, [rsp+0x30]
000077a70fdd493d  vmovaps xmm4, [rsp+0x40]
000077a70fdd4943  vmovaps xmm5, [rsp+0x50]
000077a70fdd4949  vmovaps xmm6, [rsp+0x60]
000077a70fdd494f  vmovaps xmm7, [rsp+0x70]
000077a70fdd4955  vmovaps xmm8, [rsp+0x80]
000077a70fdd495e  vmovaps xmm9, [rsp+0x90]
000077a70fdd4967  vmovaps xmm10, [rsp+0xA0]
000077a70fdd4970  vmovaps xmm11, [rsp+0xB0]
000077a70fdd4979  vmovaps xmm12, [rsp+0xC0]
000077a70fdd4982  vmovaps xmm14, [rsp+0xD0]
000077a70fdd498b  vmovaps xmm15, [rsp+0xE0]
000077a70fdd4994  add rsp, 0xF0
000077a70fdd499b  pop r11
000077a70fdd499d  pop r10
000077a70fdd499f  pop r9
000077a70fdd49a1  pop r8
000077a70fdd49a3  pop rsi
000077a70fdd49a4  pop rdi
000077a70fdd49a5  pop rdx
000077a70fdd49a6  pop rcx
000077a70fdd49a7  pop rax
000077a70fdd49a8  add rsp, 0x08
000077a70fdd49ac  jmp 0x000077A70FDD0183
000077a70fdd49b1  call 0x000077A70FBFF430
000077a70fdd49b6  jmp 0x000077A70FDD018D
000077a70fdd49bb  sub rsp, 0x08
000077a70fdd49bf  push rax
000077a70fdd49c0  push rcx
000077a70fdd49c1  push rdx
000077a70fdd49c2  push rdi
000077a70fdd49c3  push rsi
000077a70fdd49c4  push r8
000077a70fdd49c6  push r9
000077a70fdd49c8  push r10
000077a70fdd49ca  push r11
000077a70fdd49cc  sub rsp, 0xF0
000077a70fdd49d3  vmovaps [rsp], xmm0
000077a70fdd49d8  vmovaps [rsp+0x10], xmm1
000077a70fdd49de  vmovaps [rsp+0x20], xmm2
000077a70fdd49e4  vmovaps [rsp+0x30], xmm3
000077a70fdd49ea  vmovaps [rsp+0x40], xmm4
000077a70fdd49f0  vmovaps [rsp+0x50], xmm5
000077a70fdd49f6  vmovaps [rsp+0x60], xmm6
000077a70fdd49fc  vmovaps [rsp+0x70], xmm7
000077a70fdd4a02  vmovaps [rsp+0x80], xmm9
000077a70fdd4a0b  vmovaps [rsp+0x90], xmm10
000077a70fdd4a14  vmovaps [rsp+0xA0], xmm11
000077a70fdd4a1d  vmovaps [rsp+0xB0], xmm12
000077a70fdd4a26  vmovaps [rsp+0xC0], xmm13
000077a70fdd4a2f  vmovaps [rsp+0xD0], xmm14
000077a70fdd4a38  vmovaps [rsp+0xE0], xmm15
000077a70fdd4a41  sub rsp, 0x30
000077a70fdd4a45  movaps [rsp], xmm8
000077a70fdd4a4a  movaps [rsp+0x10], xmm14
000077a70fdd4a50  movaps [rsp+0x20], xmm9
000077a70fdd4a56  lea rdi, [rsp]
000077a70fdd4a5a  mov esi, 0x00
000077a70fdd4a5f  mov rax, 0x6294188EF530
000077a70fdd4a69  call rax
000077a70fdd4a6b  movaps xmm8, [rsp]
000077a70fdd4a70  add rsp, 0x30
000077a70fdd4a74  vmovaps xmm0, [rsp]
000077a70fdd4a79  vmovaps xmm1, [rsp+0x10]
000077a70fdd4a7f  vmovaps xmm2, [rsp+0x20]
000077a70fdd4a85  vmovaps xmm3, [rsp+0x30]
000077a70fdd4a8b  vmovaps xmm4, [rsp+0x40]
000077a70fdd4a91  vmovaps xmm5, [rsp+0x50]
000077a70fdd4a97  vmovaps xmm6, [rsp+0x60]
000077a70fdd4a9d  vmovaps xmm7, [rsp+0x70]
000077a70fdd4aa3  vmovaps xmm9, [rsp+0x80]
000077a70fdd4aac  vmovaps xmm10, [rsp+0x90]
000077a70fdd4ab5  vmovaps xmm11, [rsp+0xA0]
000077a70fdd4abe  vmovaps xmm12, [rsp+0xB0]
000077a70fdd4ac7  vmovaps xmm13, [rsp+0xC0]
000077a70fdd4ad0  vmovaps xmm14, [rsp+0xD0]
000077a70fdd4ad9  vmovaps xmm15, [rsp+0xE0]
000077a70fdd4ae2  add rsp, 0xF0
000077a70fdd4ae9  pop r11
000077a70fdd4aeb  pop r10
000077a70fdd4aed  pop r9
000077a70fdd4aef  pop r8
000077a70fdd4af1  pop rsi
000077a70fdd4af2  pop rdi
000077a70fdd4af3  pop rdx
000077a70fdd4af4  pop rcx
000077a70fdd4af5  pop rax
000077a70fdd4af6  add rsp, 0x08
000077a70fdd4afa  jmp 0x000077A70FDD01AF
000077a70fdd4aff  sub rsp, 0x08
000077a70fdd4b03  push rax
000077a70fdd4b04  push rcx
000077a70fdd4b05  push rdx
000077a70fdd4b06  push rdi
000077a70fdd4b07  push rsi
000077a70fdd4b08  push r8
000077a70fdd4b0a  push r9
000077a70fdd4b0c  push r10
000077a70fdd4b0e  push r11
000077a70fdd4b10  sub rsp, 0xF0
000077a70fdd4b17  vmovaps [rsp], xmm0
000077a70fdd4b1c  vmovaps [rsp+0x10], xmm1
000077a70fdd4b22  vmovaps [rsp+0x20], xmm2
000077a70fdd4b28  vmovaps [rsp+0x30], xmm3
000077a70fdd4b2e  vmovaps [rsp+0x40], xmm4
000077a70fdd4b34  vmovaps [rsp+0x50], xmm5
000077a70fdd4b3a  vmovaps [rsp+0x60], xmm6
000077a70fdd4b40  vmovaps [rsp+0x70], xmm7
000077a70fdd4b46  vmovaps [rsp+0x80], xmm8
000077a70fdd4b4f  vmovaps [rsp+0x90], xmm10
000077a70fdd4b58  vmovaps [rsp+0xA0], xmm11
000077a70fdd4b61  vmovaps [rsp+0xB0], xmm12
000077a70fdd4b6a  vmovaps [rsp+0xC0], xmm13
000077a70fdd4b73  vmovaps [rsp+0xD0], xmm14
000077a70fdd4b7c  vmovaps [rsp+0xE0], xmm15
000077a70fdd4b85  sub rsp, 0x30
000077a70fdd4b89  movaps [rsp], xmm9
000077a70fdd4b8e  movaps [rsp+0x10], xmm1
000077a70fdd4b93  movaps [rsp+0x20], xmm14
000077a70fdd4b99  lea rdi, [rsp]
000077a70fdd4b9d  mov esi, 0x00
000077a70fdd4ba2  mov rax, 0x6294188EF530
000077a70fdd4bac  call rax
000077a70fdd4bae  movaps xmm9, [rsp]
000077a70fdd4bb3  add rsp, 0x30
000077a70fdd4bb7  vmovaps xmm0, [rsp]
000077a70fdd4bbc  vmovaps xmm1, [rsp+0x10]
000077a70fdd4bc2  vmovaps xmm2, [rsp+0x20]
000077a70fdd4bc8  vmovaps xmm3, [rsp+0x30]
000077a70fdd4bce  vmovaps xmm4, [rsp+0x40]
000077a70fdd4bd4  vmovaps xmm5, [rsp+0x50]
000077a70fdd4bda  vmovaps xmm6, [rsp+0x60]
000077a70fdd4be0  vmovaps xmm7, [rsp+0x70]
000077a70fdd4be6  vmovaps xmm8, [rsp+0x80]
000077a70fdd4bef  vmovaps xmm10, [rsp+0x90]
000077a70fdd4bf8  vmovaps xmm11, [rsp+0xA0]
000077a70fdd4c01  vmovaps xmm12, [rsp+0xB0]
000077a70fdd4c0a  vmovaps xmm13, [rsp+0xC0]
000077a70fdd4c13  vmovaps xmm14, [rsp+0xD0]
000077a70fdd4c1c  vmovaps xmm15, [rsp+0xE0]
000077a70fdd4c25  add rsp, 0xF0
000077a70fdd4c2c  pop r11
000077a70fdd4c2e  pop r10
000077a70fdd4c30  pop r9
000077a70fdd4c32  pop r8
000077a70fdd4c34  pop rsi
000077a70fdd4c35  pop rdi
000077a70fdd4c36  pop rdx
000077a70fdd4c37  pop rcx
000077a70fdd4c38  pop rax
000077a70fdd4c39  add rsp, 0x08
000077a70fdd4c3d  jmp 0x000077A70FDD01DD
000077a70fdd4c42  sub rsp, 0x08
000077a70fdd4c46  push rax
000077a70fdd4c47  push rcx
000077a70fdd4c48  push rdx
000077a70fdd4c49  push rdi
000077a70fdd4c4a  push rsi
000077a70fdd4c4b  push r8
000077a70fdd4c4d  push r9
000077a70fdd4c4f  push r10
000077a70fdd4c51  push r11
000077a70fdd4c53  sub rsp, 0xF0
000077a70fdd4c5a  vmovaps [rsp], xmm0
000077a70fdd4c5f  vmovaps [rsp+0x10], xmm1
000077a70fdd4c65  vmovaps [rsp+0x20], xmm2
000077a70fdd4c6b  vmovaps [rsp+0x30], xmm3
000077a70fdd4c71  vmovaps [rsp+0x40], xmm4
000077a70fdd4c77  vmovaps [rsp+0x50], xmm5
000077a70fdd4c7d  vmovaps [rsp+0x60], xmm6
000077a70fdd4c83  vmovaps [rsp+0x70], xmm7
000077a70fdd4c89  vmovaps [rsp+0x80], xmm8
000077a70fdd4c92  vmovaps [rsp+0x90], xmm9
000077a70fdd4c9b  vmovaps [rsp+0xA0], xmm10
000077a70fdd4ca4  vmovaps [rsp+0xB0], xmm11
000077a70fdd4cad  vmovaps [rsp+0xC0], xmm12
000077a70fdd4cb6  vmovaps [rsp+0xD0], xmm13
000077a70fdd4cbf  vmovaps [rsp+0xE0], xmm15
000077a70fdd4cc8  sub rsp, 0x30
000077a70fdd4ccc  movaps [rsp], xmm14
000077a70fdd4cd1  movaps [rsp+0x10], xmm4
000077a70fdd4cd6  movaps [rsp+0x20], xmm1
000077a70fdd4cdb  lea rdi, [rsp]
000077a70fdd4cdf  mov esi, 0x00
000077a70fdd4ce4  mov rax, 0x6294188EF530
000077a70fdd4cee  call rax
000077a70fdd4cf0  movaps xmm14, [rsp]
000077a70fdd4cf5  add rsp, 0x30
000077a70fdd4cf9  vmovaps xmm0, [rsp]
000077a70fdd4cfe  vmovaps xmm1, [rsp+0x10]
000077a70fdd4d04  vmovaps xmm2, [rsp+0x20]
000077a70fdd4d0a  vmovaps xmm3, [rsp+0x30]
000077a70fdd4d10  vmovaps xmm4, [rsp+0x40]
000077a70fdd4d16  vmovaps xmm5, [rsp+0x50]
000077a70fdd4d1c  vmovaps xmm6, [rsp+0x60]
000077a70fdd4d22  vmovaps xmm7, [rsp+0x70]
000077a70fdd4d28  vmovaps xmm8, [rsp+0x80]
000077a70fdd4d31  vmovaps xmm9, [rsp+0x90]
000077a70fdd4d3a  vmovaps xmm10, [rsp+0xA0]
000077a70fdd4d43  vmovaps xmm11, [rsp+0xB0]
000077a70fdd4d4c  vmovaps xmm12, [rsp+0xC0]
000077a70fdd4d55  vmovaps xmm13, [rsp+0xD0]
000077a70fdd4d5e  vmovaps xmm15, [rsp+0xE0]
000077a70fdd4d67  add rsp, 0xF0
000077a70fdd4d6e  pop r11
000077a70fdd4d70  pop r10
000077a70fdd4d72  pop r9
000077a70fdd4d74  pop r8
000077a70fdd4d76  pop rsi
000077a70fdd4d77  pop rdi
000077a70fdd4d78  pop rdx
000077a70fdd4d79  pop rcx
000077a70fdd4d7a  pop rax
000077a70fdd4d7b  add rsp, 0x08
000077a70fdd4d7f  jmp 0x000077A70FDD0203
000077a70fdd4d84  sub rsp, 0x08
000077a70fdd4d88  push rax
000077a70fdd4d89  push rcx
000077a70fdd4d8a  push rdx
000077a70fdd4d8b  push rdi
000077a70fdd4d8c  push rsi
000077a70fdd4d8d  push r8
000077a70fdd4d8f  push r9
000077a70fdd4d91  push r10
000077a70fdd4d93  push r11
000077a70fdd4d95  sub rsp, 0xF0
000077a70fdd4d9c  vmovaps [rsp], xmm0
000077a70fdd4da1  vmovaps [rsp+0x10], xmm2
000077a70fdd4da7  vmovaps [rsp+0x20], xmm3
000077a70fdd4dad  vmovaps [rsp+0x30], xmm4
000077a70fdd4db3  vmovaps [rsp+0x40], xmm5
000077a70fdd4db9  vmovaps [rsp+0x50], xmm6
000077a70fdd4dbf  vmovaps [rsp+0x60], xmm7
000077a70fdd4dc5  vmovaps [rsp+0x70], xmm8
000077a70fdd4dcb  vmovaps [rsp+0x80], xmm9
000077a70fdd4dd4  vmovaps [rsp+0x90], xmm10
000077a70fdd4ddd  vmovaps [rsp+0xA0], xmm11
000077a70fdd4de6  vmovaps [rsp+0xB0], xmm12
000077a70fdd4def  vmovaps [rsp+0xC0], xmm13
000077a70fdd4df8  vmovaps [rsp+0xD0], xmm14
000077a70fdd4e01  vmovaps [rsp+0xE0], xmm15
000077a70fdd4e0a  sub rsp, 0x30
000077a70fdd4e0e  movaps [rsp], xmm1
000077a70fdd4e12  movaps [rsp+0x10], xmm12
000077a70fdd4e18  movaps [rsp+0x20], xmm11
000077a70fdd4e1e  lea rdi, [rsp]
000077a70fdd4e22  mov esi, 0x00
000077a70fdd4e27  mov rax, 0x6294188EF530
000077a70fdd4e31  call rax
000077a70fdd4e33  movaps xmm1, [rsp]
000077a70fdd4e37  add rsp, 0x30
000077a70fdd4e3b  vmovaps xmm0, [rsp]
000077a70fdd4e40  vmovaps xmm2, [rsp+0x10]
000077a70fdd4e46  vmovaps xmm3, [rsp+0x20]
000077a70fdd4e4c  vmovaps xmm4, [rsp+0x30]
000077a70fdd4e52  vmovaps xmm5, [rsp+0x40]
000077a70fdd4e58  vmovaps xmm6, [rsp+0x50]
000077a70fdd4e5e  vmovaps xmm7, [rsp+0x60]
000077a70fdd4e64  vmovaps xmm8, [rsp+0x70]
000077a70fdd4e6a  vmovaps xmm9, [rsp+0x80]
000077a70fdd4e73  vmovaps xmm10, [rsp+0x90]
000077a70fdd4e7c  vmovaps xmm11, [rsp+0xA0]
000077a70fdd4e85  vmovaps xmm12, [rsp+0xB0]
000077a70fdd4e8e  vmovaps xmm13, [rsp+0xC0]
000077a70fdd4e97  vmovaps xmm14, [rsp+0xD0]
000077a70fdd4ea0  vmovaps xmm15, [rsp+0xE0]
000077a70fdd4ea9  add rsp, 0xF0
000077a70fdd4eb0  pop r11
000077a70fdd4eb2  pop r10
000077a70fdd4eb4  pop r9
000077a70fdd4eb6  pop r8
000077a70fdd4eb8  pop rsi
000077a70fdd4eb9  pop rdi
000077a70fdd4eba  pop rdx
000077a70fdd4ebb  pop rcx
000077a70fdd4ebc  pop rax
000077a70fdd4ebd  add rsp, 0x08
000077a70fdd4ec1  jmp 0x000077A70FDD0224
000077a70fdd4ec6  call 0x000077A70FCE20A0
000077a70fdd4ecb  jmp 0x000077A70FDD0232
000077a70fdd4ed0  call 0x000077A70FC09D70
000077a70fdd4ed5  jmp 0x000077A70FDD023C
000077a70fdd4eda  sub rsp, 0x08
000077a70fdd4ede  push rax
000077a70fdd4edf  push rcx
000077a70fdd4ee0  push rdx
000077a70fdd4ee1  push rdi
000077a70fdd4ee2  push rsi
000077a70fdd4ee3  push r8
000077a70fdd4ee5  push r9
000077a70fdd4ee7  push r10
000077a70fdd4ee9  push r11
000077a70fdd4eeb  sub rsp, 0xF0
000077a70fdd4ef2  vmovaps [rsp], xmm0
000077a70fdd4ef7  vmovaps [rsp+0x10], xmm1
000077a70fdd4efd  vmovaps [rsp+0x20], xmm2
000077a70fdd4f03  vmovaps [rsp+0x30], xmm3
000077a70fdd4f09  vmovaps [rsp+0x40], xmm4
000077a70fdd4f0f  vmovaps [rsp+0x50], xmm5
000077a70fdd4f15  vmovaps [rsp+0x60], xmm6
000077a70fdd4f1b  vmovaps [rsp+0x70], xmm8
000077a70fdd4f21  vmovaps [rsp+0x80], xmm9
000077a70fdd4f2a  vmovaps [rsp+0x90], xmm10
000077a70fdd4f33  vmovaps [rsp+0xA0], xmm11
000077a70fdd4f3c  vmovaps [rsp+0xB0], xmm12
000077a70fdd4f45  vmovaps [rsp+0xC0], xmm13
000077a70fdd4f4e  vmovaps [rsp+0xD0], xmm14
000077a70fdd4f57  vmovaps [rsp+0xE0], xmm15
000077a70fdd4f60  sub rsp, 0x30
000077a70fdd4f64  movaps [rsp], xmm7
000077a70fdd4f68  movaps [rsp+0x10], xmm15
000077a70fdd4f6e  movaps [rsp+0x20], xmm10
000077a70fdd4f74  lea rdi, [rsp]
000077a70fdd4f78  mov esi, 0x00
000077a70fdd4f7d  mov rax, 0x6294188EF530
000077a70fdd4f87  call rax
000077a70fdd4f89  movaps xmm7, [rsp]
000077a70fdd4f8d  add rsp, 0x30
000077a70fdd4f91  vmovaps xmm0, [rsp]
000077a70fdd4f96  vmovaps xmm1, [rsp+0x10]
000077a70fdd4f9c  vmovaps xmm2, [rsp+0x20]
000077a70fdd4fa2  vmovaps xmm3, [rsp+0x30]
000077a70fdd4fa8  vmovaps xmm4, [rsp+0x40]
000077a70fdd4fae  vmovaps xmm5, [rsp+0x50]
000077a70fdd4fb4  vmovaps xmm6, [rsp+0x60]
000077a70fdd4fba  vmovaps xmm8, [rsp+0x70]
000077a70fdd4fc0  vmovaps xmm9, [rsp+0x80]
000077a70fdd4fc9  vmovaps xmm10, [rsp+0x90]
000077a70fdd4fd2  vmovaps xmm11, [rsp+0xA0]
000077a70fdd4fdb  vmovaps xmm12, [rsp+0xB0]
000077a70fdd4fe4  vmovaps xmm13, [rsp+0xC0]
000077a70fdd4fed  vmovaps xmm14, [rsp+0xD0]
000077a70fdd4ff6  vmovaps xmm15, [rsp+0xE0]
000077a70fdd4fff  add rsp, 0xF0
000077a70fdd5006  pop r11
000077a70fdd5008  pop r10
000077a70fdd500a  pop r9
000077a70fdd500c  pop r8
000077a70fdd500e  pop rsi
000077a70fdd500f  pop rdi
000077a70fdd5010  pop rdx
000077a70fdd5011  pop rcx
000077a70fdd5012  pop rax
000077a70fdd5013  add rsp, 0x08
000077a70fdd5017  jmp 0x000077A70FDD025D
000077a70fdd501c  sub rsp, 0x08
000077a70fdd5020  push rax
000077a70fdd5021  push rcx
000077a70fdd5022  push rdx
000077a70fdd5023  push rdi
000077a70fdd5024  push rsi
000077a70fdd5025  push r8
000077a70fdd5027  push r9
000077a70fdd5029  push r10
000077a70fdd502b  push r11
000077a70fdd502d  sub rsp, 0xF0
000077a70fdd5034  vmovaps [rsp], xmm0
000077a70fdd5039  vmovaps [rsp+0x10], xmm1
000077a70fdd503f  vmovaps [rsp+0x20], xmm2
000077a70fdd5045  vmovaps [rsp+0x30], xmm3
000077a70fdd504b  vmovaps [rsp+0x40], xmm4
000077a70fdd5051  vmovaps [rsp+0x50], xmm5
000077a70fdd5057  vmovaps [rsp+0x60], xmm6
000077a70fdd505d  vmovaps [rsp+0x70], xmm7
000077a70fdd5063  vmovaps [rsp+0x80], xmm8
000077a70fdd506c  vmovaps [rsp+0x90], xmm9
000077a70fdd5075  vmovaps [rsp+0xA0], xmm11
000077a70fdd507e  vmovaps [rsp+0xB0], xmm12
000077a70fdd5087  vmovaps [rsp+0xC0], xmm13
000077a70fdd5090  vmovaps [rsp+0xD0], xmm14
000077a70fdd5099  vmovaps [rsp+0xE0], xmm15
000077a70fdd50a2  sub rsp, 0x30
000077a70fdd50a6  movaps [rsp], xmm10
000077a70fdd50ab  movaps [rsp+0x10], xmm11
000077a70fdd50b1  movaps [rsp+0x20], xmm15
000077a70fdd50b7  lea rdi, [rsp]
000077a70fdd50bb  mov esi, 0x00
000077a70fdd50c0  mov rax, 0x6294188EF530
000077a70fdd50ca  call rax
000077a70fdd50cc  movaps xmm10, [rsp]
000077a70fdd50d1  add rsp, 0x30
000077a70fdd50d5  vmovaps xmm0, [rsp]
000077a70fdd50da  vmovaps xmm1, [rsp+0x10]
000077a70fdd50e0  vmovaps xmm2, [rsp+0x20]
000077a70fdd50e6  vmovaps xmm3, [rsp+0x30]
000077a70fdd50ec  vmovaps xmm4, [rsp+0x40]
000077a70fdd50f2  vmovaps xmm5, [rsp+0x50]
000077a70fdd50f8  vmovaps xmm6, [rsp+0x60]
000077a70fdd50fe  vmovaps xmm7, [rsp+0x70]
000077a70fdd5104  vmovaps xmm8, [rsp+0x80]
000077a70fdd510d  vmovaps xmm9, [rsp+0x90]
000077a70fdd5116  vmovaps xmm11, [rsp+0xA0]
000077a70fdd511f  vmovaps xmm12, [rsp+0xB0]
000077a70fdd5128  vmovaps xmm13, [rsp+0xC0]
000077a70fdd5131  vmovaps xmm14, [rsp+0xD0]
000077a70fdd513a  vmovaps xmm15, [rsp+0xE0]
000077a70fdd5143  add rsp, 0xF0
000077a70fdd514a  pop r11
000077a70fdd514c  pop r10
000077a70fdd514e  pop r9
000077a70fdd5150  pop r8
000077a70fdd5152  pop rsi
000077a70fdd5153  pop rdi
000077a70fdd5154  pop rdx
000077a70fdd5155  pop rcx
000077a70fdd5156  pop rax
000077a70fdd5157  add rsp, 0x08
000077a70fdd515b  jmp 0x000077A70FDD028B
000077a70fdd5160  sub rsp, 0x08
000077a70fdd5164  push rax
000077a70fdd5165  push rcx
000077a70fdd5166  push rdx
000077a70fdd5167  push rdi
000077a70fdd5168  push rsi
000077a70fdd5169  push r8
000077a70fdd516b  push r9
000077a70fdd516d  push r10
000077a70fdd516f  push r11
000077a70fdd5171  sub rsp, 0xF0
000077a70fdd5178  vmovaps [rsp], xmm0
000077a70fdd517d  vmovaps [rsp+0x10], xmm1
000077a70fdd5183  vmovaps [rsp+0x20], xmm2
000077a70fdd5189  vmovaps [rsp+0x30], xmm3
000077a70fdd518f  vmovaps [rsp+0x40], xmm4
000077a70fdd5195  vmovaps [rsp+0x50], xmm5
000077a70fdd519b  vmovaps [rsp+0x60], xmm6
000077a70fdd51a1  vmovaps [rsp+0x70], xmm7
000077a70fdd51a7  vmovaps [rsp+0x80], xmm8
000077a70fdd51b0  vmovaps [rsp+0x90], xmm9
000077a70fdd51b9  vmovaps [rsp+0xA0], xmm10
000077a70fdd51c2  vmovaps [rsp+0xB0], xmm12
000077a70fdd51cb  vmovaps [rsp+0xC0], xmm13
000077a70fdd51d4  vmovaps [rsp+0xD0], xmm14
000077a70fdd51dd  vmovaps [rsp+0xE0], xmm15
000077a70fdd51e6  sub rsp, 0x30
000077a70fdd51ea  movaps [rsp], xmm11
000077a70fdd51ef  movaps [rsp+0x10], xmm12
000077a70fdd51f5  movaps [rsp+0x20], xmm15
000077a70fdd51fb  lea rdi, [rsp]
000077a70fdd51ff  mov esi, 0x00
000077a70fdd5204  mov rax, 0x6294188EF530
000077a70fdd520e  call rax
000077a70fdd5210  movaps xmm11, [rsp]
000077a70fdd5215  add rsp, 0x30
000077a70fdd5219  vmovaps xmm0, [rsp]
000077a70fdd521e  vmovaps xmm1, [rsp+0x10]
000077a70fdd5224  vmovaps xmm2, [rsp+0x20]
000077a70fdd522a  vmovaps xmm3, [rsp+0x30]
000077a70fdd5230  vmovaps xmm4, [rsp+0x40]
000077a70fdd5236  vmovaps xmm5, [rsp+0x50]
000077a70fdd523c  vmovaps xmm6, [rsp+0x60]
000077a70fdd5242  vmovaps xmm7, [rsp+0x70]
000077a70fdd5248  vmovaps xmm8, [rsp+0x80]
000077a70fdd5251  vmovaps xmm9, [rsp+0x90]
000077a70fdd525a  vmovaps xmm10, [rsp+0xA0]
000077a70fdd5263  vmovaps xmm12, [rsp+0xB0]
000077a70fdd526c  vmovaps xmm13, [rsp+0xC0]
000077a70fdd5275  vmovaps xmm14, [rsp+0xD0]
000077a70fdd527e  vmovaps xmm15, [rsp+0xE0]
000077a70fdd5287  add rsp, 0xF0
000077a70fdd528e  pop r11
000077a70fdd5290  pop r10
000077a70fdd5292  pop r9
000077a70fdd5294  pop r8
000077a70fdd5296  pop rsi
000077a70fdd5297  pop rdi
000077a70fdd5298  pop rdx
000077a70fdd5299  pop rcx
000077a70fdd529a  pop rax
000077a70fdd529b  add rsp, 0x08
000077a70fdd529f  jmp 0x000077A70FDD02B9
000077a70fdd52a4  sub rsp, 0x08
000077a70fdd52a8  push rax
000077a70fdd52a9  push rcx
000077a70fdd52aa  push rdx
000077a70fdd52ab  push rdi
000077a70fdd52ac  push rsi
000077a70fdd52ad  push r8
000077a70fdd52af  push r9
000077a70fdd52b1  push r10
000077a70fdd52b3  push r11
000077a70fdd52b5  sub rsp, 0xF0
000077a70fdd52bc  vmovaps [rsp], xmm0
000077a70fdd52c1  vmovaps [rsp+0x10], xmm1
000077a70fdd52c7  vmovaps [rsp+0x20], xmm2
000077a70fdd52cd  vmovaps [rsp+0x30], xmm3
000077a70fdd52d3  vmovaps [rsp+0x40], xmm4
000077a70fdd52d9  vmovaps [rsp+0x50], xmm5
000077a70fdd52df  vmovaps [rsp+0x60], xmm6
000077a70fdd52e5  vmovaps [rsp+0x70], xmm7
000077a70fdd52eb  vmovaps [rsp+0x80], xmm8
000077a70fdd52f4  vmovaps [rsp+0x90], xmm9
000077a70fdd52fd  vmovaps [rsp+0xA0], xmm10
000077a70fdd5306  vmovaps [rsp+0xB0], xmm11
000077a70fdd530f  vmovaps [rsp+0xC0], xmm12
000077a70fdd5318  vmovaps [rsp+0xD0], xmm13
000077a70fdd5321  vmovaps [rsp+0xE0], xmm14
000077a70fdd532a  sub rsp, 0x30
000077a70fdd532e  movaps [rsp], xmm15
000077a70fdd5333  movaps [rsp+0x10], xmm13
000077a70fdd5339  movaps [rsp+0x20], xmm9
000077a70fdd533f  lea rdi, [rsp]
000077a70fdd5343  mov esi, 0x00
000077a70fdd5348  mov rax, 0x6294188EF530
000077a70fdd5352  call rax
000077a70fdd5354  movaps xmm15, [rsp]
000077a70fdd5359  add rsp, 0x30
000077a70fdd535d  vmovaps xmm0, [rsp]
000077a70fdd5362  vmovaps xmm1, [rsp+0x10]
000077a70fdd5368  vmovaps xmm2, [rsp+0x20]
000077a70fdd536e  vmovaps xmm3, [rsp+0x30]
000077a70fdd5374  vmovaps xmm4, [rsp+0x40]
000077a70fdd537a  vmovaps xmm5, [rsp+0x50]
000077a70fdd5380  vmovaps xmm6, [rsp+0x60]
000077a70fdd5386  vmovaps xmm7, [rsp+0x70]
000077a70fdd538c  vmovaps xmm8, [rsp+0x80]
000077a70fdd5395  vmovaps xmm9, [rsp+0x90]
000077a70fdd539e  vmovaps xmm10, [rsp+0xA0]
000077a70fdd53a7  vmovaps xmm11, [rsp+0xB0]
000077a70fdd53b0  vmovaps xmm12, [rsp+0xC0]
000077a70fdd53b9  vmovaps xmm13, [rsp+0xD0]
000077a70fdd53c2  vmovaps xmm14, [rsp+0xE0]
000077a70fdd53cb  add rsp, 0xF0
000077a70fdd53d2  pop r11
000077a70fdd53d4  pop r10
000077a70fdd53d6  pop r9
000077a70fdd53d8  pop r8
000077a70fdd53da  pop rsi
000077a70fdd53db  pop rdi
000077a70fdd53dc  pop rdx
000077a70fdd53dd  pop rcx
000077a70fdd53de  pop rax
000077a70fdd53df  add rsp, 0x08
000077a70fdd53e3  jmp 0x000077A70FDD02D4
000077a70fdd53e8  sub rsp, 0x08
000077a70fdd53ec  push rax
000077a70fdd53ed  push rcx
000077a70fdd53ee  push rdx
000077a70fdd53ef  push rdi
000077a70fdd53f0  push rsi
000077a70fdd53f1  push r8
000077a70fdd53f3  push r9
000077a70fdd53f5  push r10
000077a70fdd53f7  push r11
000077a70fdd53f9  sub rsp, 0xF0
000077a70fdd5400  vmovaps [rsp], xmm0
000077a70fdd5405  vmovaps [rsp+0x10], xmm1
000077a70fdd540b  vmovaps [rsp+0x20], xmm2
000077a70fdd5411  vmovaps [rsp+0x30], xmm3
000077a70fdd5417  vmovaps [rsp+0x40], xmm4
000077a70fdd541d  vmovaps [rsp+0x50], xmm5
000077a70fdd5423  vmovaps [rsp+0x60], xmm6
000077a70fdd5429  vmovaps [rsp+0x70], xmm7
000077a70fdd542f  vmovaps [rsp+0x80], xmm8
000077a70fdd5438  vmovaps [rsp+0x90], xmm9
000077a70fdd5441  vmovaps [rsp+0xA0], xmm10
000077a70fdd544a  vmovaps [rsp+0xB0], xmm11
000077a70fdd5453  vmovaps [rsp+0xC0], xmm12
000077a70fdd545c  vmovaps [rsp+0xD0], xmm14
000077a70fdd5465  vmovaps [rsp+0xE0], xmm15
000077a70fdd546e  sub rsp, 0x30
000077a70fdd5472  movaps [rsp], xmm13
000077a70fdd5477  movaps [rsp+0x10], xmm8
000077a70fdd547d  movaps [rsp+0x20], xmm14
000077a70fdd5483  lea rdi, [rsp]
000077a70fdd5487  mov esi, 0x00
000077a70fdd548c  mov rax, 0x6294188EF530
000077a70fdd5496  call rax
000077a70fdd5498  movaps xmm13, [rsp]
000077a70fdd549d  add rsp, 0x30
000077a70fdd54a1  vmovaps xmm0, [rsp]
000077a70fdd54a6  vmovaps xmm1, [rsp+0x10]
000077a70fdd54ac  vmovaps xmm2, [rsp+0x20]
000077a70fdd54b2  vmovaps xmm3, [rsp+0x30]
000077a70fdd54b8  vmovaps xmm4, [rsp+0x40]
000077a70fdd54be  vmovaps xmm5, [rsp+0x50]
000077a70fdd54c4  vmovaps xmm6, [rsp+0x60]
000077a70fdd54ca  vmovaps xmm7, [rsp+0x70]
000077a70fdd54d0  vmovaps xmm8, [rsp+0x80]
000077a70fdd54d9  vmovaps xmm9, [rsp+0x90]
000077a70fdd54e2  vmovaps xmm10, [rsp+0xA0]
000077a70fdd54eb  vmovaps xmm11, [rsp+0xB0]
000077a70fdd54f4  vmovaps xmm12, [rsp+0xC0]
000077a70fdd54fd  vmovaps xmm14, [rsp+0xD0]
000077a70fdd5506  vmovaps xmm15, [rsp+0xE0]
000077a70fdd550f  add rsp, 0xF0
000077a70fdd5516  pop r11
000077a70fdd5518  pop r10
000077a70fdd551a  pop r9
000077a70fdd551c  pop r8
000077a70fdd551e  pop rsi
000077a70fdd551f  pop rdi
000077a70fdd5520  pop rdx
000077a70fdd5521  pop rcx
000077a70fdd5522  pop rax
000077a70fdd5523  add rsp, 0x08
000077a70fdd5527  jmp 0x000077A70FDD02F7
000077a70fdd552c  sub rsp, 0x08
000077a70fdd5530  push rax
000077a70fdd5531  push rcx
000077a70fdd5532  push rdx
000077a70fdd5533  push rdi
000077a70fdd5534  push rsi
000077a70fdd5535  push r8
000077a70fdd5537  push r9
000077a70fdd5539  push r10
000077a70fdd553b  push r11
000077a70fdd553d  sub rsp, 0xF0
000077a70fdd5544  vmovaps [rsp], xmm0
000077a70fdd5549  vmovaps [rsp+0x10], xmm1
000077a70fdd554f  vmovaps [rsp+0x20], xmm2
000077a70fdd5555  vmovaps [rsp+0x30], xmm3
000077a70fdd555b  vmovaps [rsp+0x40], xmm4
000077a70fdd5561  vmovaps [rsp+0x50], xmm5
000077a70fdd5567  vmovaps [rsp+0x60], xmm6
000077a70fdd556d  vmovaps [rsp+0x70], xmm7
000077a70fdd5573  vmovaps [rsp+0x80], xmm8
000077a70fdd557c  vmovaps [rsp+0x90], xmm9
000077a70fdd5585  vmovaps [rsp+0xA0], xmm10
000077a70fdd558e  vmovaps [rsp+0xB0], xmm11
000077a70fdd5597  vmovaps [rsp+0xC0], xmm12
000077a70fdd55a0  vmovaps [rsp+0xD0], xmm13
000077a70fdd55a9  vmovaps [rsp+0xE0], xmm15
000077a70fdd55b2  sub rsp, 0x30
000077a70fdd55b6  movaps [rsp], xmm14
000077a70fdd55bb  movaps [rsp+0x10], xmm1
000077a70fdd55c0  movaps [rsp+0x20], xmm10
000077a70fdd55c6  lea rdi, [rsp]
000077a70fdd55ca  mov esi, 0x00
000077a70fdd55cf  mov rax, 0x6294188EF530
000077a70fdd55d9  call rax
000077a70fdd55db  movaps xmm14, [rsp]
000077a70fdd55e0  add rsp, 0x30
000077a70fdd55e4  vmovaps xmm0, [rsp]
000077a70fdd55e9  vmovaps xmm1, [rsp+0x10]
000077a70fdd55ef  vmovaps xmm2, [rsp+0x20]
000077a70fdd55f5  vmovaps xmm3, [rsp+0x30]
000077a70fdd55fb  vmovaps xmm4, [rsp+0x40]
000077a70fdd5601  vmovaps xmm5, [rsp+0x50]
000077a70fdd5607  vmovaps xmm6, [rsp+0x60]
000077a70fdd560d  vmovaps xmm7, [rsp+0x70]
000077a70fdd5613  vmovaps xmm8, [rsp+0x80]
000077a70fdd561c  vmovaps xmm9, [rsp+0x90]
000077a70fdd5625  vmovaps xmm10, [rsp+0xA0]
000077a70fdd562e  vmovaps xmm11, [rsp+0xB0]
000077a70fdd5637  vmovaps xmm12, [rsp+0xC0]
000077a70fdd5640  vmovaps xmm13, [rsp+0xD0]
000077a70fdd5649  vmovaps xmm15, [rsp+0xE0]
000077a70fdd5652  add rsp, 0xF0
000077a70fdd5659  pop r11
000077a70fdd565b  pop r10
000077a70fdd565d  pop r9
000077a70fdd565f  pop r8
000077a70fdd5661  pop rsi
000077a70fdd5662  pop rdi
000077a70fdd5663  pop rdx
000077a70fdd5664  pop rcx
000077a70fdd5665  pop rax
000077a70fdd5666  add rsp, 0x08
000077a70fdd566a  jmp 0x000077A70FDD031A
000077a70fdd566f  sub rsp, 0x08
000077a70fdd5673  push rax
000077a70fdd5674  push rcx
000077a70fdd5675  push rdx
000077a70fdd5676  push rdi
000077a70fdd5677  push rsi
000077a70fdd5678  push r8
000077a70fdd567a  push r9
000077a70fdd567c  push r10
000077a70fdd567e  push r11
000077a70fdd5680  sub rsp, 0xF0
000077a70fdd5687  vmovaps [rsp], xmm0
000077a70fdd568c  vmovaps [rsp+0x10], xmm2
000077a70fdd5692  vmovaps [rsp+0x20], xmm3
000077a70fdd5698  vmovaps [rsp+0x30], xmm4
000077a70fdd569e  vmovaps [rsp+0x40], xmm5
000077a70fdd56a4  vmovaps [rsp+0x50], xmm6
000077a70fdd56aa  vmovaps [rsp+0x60], xmm7
000077a70fdd56b0  vmovaps [rsp+0x70], xmm8
000077a70fdd56b6  vmovaps [rsp+0x80], xmm9
000077a70fdd56bf  vmovaps [rsp+0x90], xmm10
000077a70fdd56c8  vmovaps [rsp+0xA0], xmm11
000077a70fdd56d1  vmovaps [rsp+0xB0], xmm12
000077a70fdd56da  vmovaps [rsp+0xC0], xmm13
000077a70fdd56e3  vmovaps [rsp+0xD0], xmm14
000077a70fdd56ec  vmovaps [rsp+0xE0], xmm15
000077a70fdd56f5  sub rsp, 0x30
000077a70fdd56f9  movaps [rsp], xmm1
000077a70fdd56fd  movaps [rsp+0x10], xmm7
000077a70fdd5702  movaps [rsp+0x20], xmm11
000077a70fdd5708  lea rdi, [rsp]
000077a70fdd570c  mov esi, 0x00
000077a70fdd5711  mov rax, 0x6294188EF530
000077a70fdd571b  call rax
000077a70fdd571d  movaps xmm1, [rsp]
000077a70fdd5721  add rsp, 0x30
000077a70fdd5725  vmovaps xmm0, [rsp]
000077a70fdd572a  vmovaps xmm2, [rsp+0x10]
000077a70fdd5730  vmovaps xmm3, [rsp+0x20]
000077a70fdd5736  vmovaps xmm4, [rsp+0x30]
000077a70fdd573c  vmovaps xmm5, [rsp+0x40]
000077a70fdd5742  vmovaps xmm6, [rsp+0x50]
000077a70fdd5748  vmovaps xmm7, [rsp+0x60]
000077a70fdd574e  vmovaps xmm8, [rsp+0x70]
000077a70fdd5754  vmovaps xmm9, [rsp+0x80]
000077a70fdd575d  vmovaps xmm10, [rsp+0x90]
000077a70fdd5766  vmovaps xmm11, [rsp+0xA0]
000077a70fdd576f  vmovaps xmm12, [rsp+0xB0]
000077a70fdd5778  vmovaps xmm13, [rsp+0xC0]
000077a70fdd5781  vmovaps xmm14, [rsp+0xD0]
000077a70fdd578a  vmovaps xmm15, [rsp+0xE0]
000077a70fdd5793  add rsp, 0xF0
000077a70fdd579a  pop r11
000077a70fdd579c  pop r10
000077a70fdd579e  pop r9
000077a70fdd57a0  pop r8
000077a70fdd57a2  pop rsi
000077a70fdd57a3  pop rdi
000077a70fdd57a4  pop rdx
000077a70fdd57a5  pop rcx
000077a70fdd57a6  pop rax
000077a70fdd57a7  add rsp, 0x08
000077a70fdd57ab  jmp 0x000077A70FDD033B
000077a70fdd57b0  call 0x000077A70FC0E880
000077a70fdd57b5  jmp 0x000077A70FDD034E
000077a70fdd57ba  call 0x000077A70FC0C380
000077a70fdd57bf  jmp 0x000077A70FDD0359
000077a70fdd57c4  call 0x000077A70FC0D600
000077a70fdd57c9  jmp 0x000077A70FDD0364
000077a70fdd57ce  call 0x000077A70FBFF540
000077a70fdd57d3  jmp 0x000077A70FDD036F
000077a70fdd57d8  int3
000077a70fdd57d9  nop [rax], eax
000077a70fdd57e0  mov rax, [r15+0x40]
000077a70fdd57e4  mov r14, [r15+0x58]
000077a70fdd57e8  lea r12, [rax+r14*1]
000077a70fdd57ec  movaps xmm1, [r15+0x1D0]
000077a70fdd57f4  vmovaps [rsp+0x10], xmm1
000077a70fdd57fa  vmovaps xmm15, [rsp+0x10]
000077a70fdd5800  por xmm1, xmm15
000077a70fdd5805  movaps xmm14, [r15+0x1A0]
000077a70fdd580d  vmovaps [rsp+0x10], xmm14
000077a70fdd5813  vmovaps xmm13, [rsp+0x10]
000077a70fdd5819  por xmm14, xmm13
000077a70fdd581e  lea rax, [r12+0x30]
000077a70fdd5823  mov r11, [r13+rax*1]
000077a70fdd5828  lea rax, [r12+0x38]
000077a70fdd582d  mov r10, [r13+rax*1]
000077a70fdd5832  movq xmm13, r11
000077a70fdd5837  movq xmm12, r10
000077a70fdd583c  movq xmm13, xmm13
000077a70fdd5841  vmovaps [rsp+0x10], xmm13
000077a70fdd5847  movq xmm13, xmm13
000077a70fdd584c  movaps [r15+0x130], xmm13
000077a70fdd5854  movq xmm12, xmm12
000077a70fdd5859  vmovaps [rsp+0x20], xmm12
000077a70fdd585f  movq xmm12, xmm12
000077a70fdd5864  movaps [r15+0x280], xmm12
000077a70fdd586c  movaps xmm13, [r15+0x270]
000077a70fdd5874  vmovaps [rsp+0x30], xmm13
000077a70fdd587a  vmovaps xmm12, [rsp+0x30]
000077a70fdd5880  por xmm13, xmm12
000077a70fdd5885  lea rax, [r12+0x20]
000077a70fdd588a  mov r11, [r13+rax*1]
000077a70fdd588f  lea rax, [r12+0x28]
000077a70fdd5894  mov r10, [r13+rax*1]
000077a70fdd5899  movq xmm12, r11
000077a70fdd589e  movq xmm11, r10
000077a70fdd58a3  movq xmm12, xmm12
000077a70fdd58a8  vmovaps [rsp+0x30], xmm12
000077a70fdd58ae  movq xmm12, xmm12
000077a70fdd58b3  movaps [r15+0x150], xmm12
000077a70fdd58bb  movq xmm11, xmm11
000077a70fdd58c0  vmovaps [rsp+0x40], xmm11
000077a70fdd58c6  movq xmm11, xmm11
000077a70fdd58cb  movaps [r15+0x140], xmm11
000077a70fdd58d3  lea rax, [r12+0x10]
000077a70fdd58d8  mov r11, [r13+rax*1]
000077a70fdd58dd  lea rax, [r12+0x18]
000077a70fdd58e2  mov r10, [r13+rax*1]
000077a70fdd58e7  movq xmm12, r11
000077a70fdd58ec  movq xmm11, r10
000077a70fdd58f1  movq xmm12, xmm12
000077a70fdd58f6  vmovaps [rsp+0x50], xmm12
000077a70fdd58fc  movq xmm12, xmm12
000077a70fdd5901  movaps [r15+0x170], xmm12
000077a70fdd5909  movq xmm11, xmm11
000077a70fdd590e  vmovaps [rsp+0x60], xmm11
000077a70fdd5914  movq xmm11, xmm11
000077a70fdd5919  movaps [r15+0x160], xmm11
000077a70fdd5921  mov rax, [r13+r12*1]
000077a70fdd5926  vmovq xmm12, rax
000077a70fdd592b  vpbroadcastq xmm12, xmm12
000077a70fdd5930  lea rax, [r12+0x08]
000077a70fdd5935  mov r12, [r13+rax*1]
000077a70fdd593a  movq xmm11, r12
000077a70fdd593f  movaps [r15+0x230], xmm11
000077a70fdd5947  mov rax, [r15+0xF8]
000077a70fdd594e  lea r12, [rax+0x50]
000077a70fdd5952  movups xmm11, [r13+r12*1]
000077a70fdd5958  lea r12, [rax+0x60]
000077a70fdd595c  movups xmm10, [r13+r12*1]
000077a70fdd5962  lea r12, [rax+0x30]
000077a70fdd5966  movups xmm9, [r13+r12*1]
000077a70fdd596c  mov r12, [r15+0x50]
000077a70fdd5970  lea r11, [r12+r14*1]
000077a70fdd5974  mov [r15+0x60], r11
000077a70fdd5978  lea r12, [r14+0x40]
000077a70fdd597c  mov [r15+0x58], r12
000077a70fdd5980  movaps xmm8, xmm12
000077a70fdd5984  mulpd xmm8, xmm15
000077a70fdd5989  vcmppd xmm7, xmm8, xmm8, 0x03
000077a70fdd598f  ptest xmm7, xmm7
000077a70fdd5994  jnz 0x000077A70FDD67B7
000077a70fdd599a  movq xmm15, qword ptr [r15+0x230]
000077a70fdd59a3  vmovaps [rsp+0x70], xmm15
000077a70fdd59a9  vpermilpd xmm15, xmm15, 0x00
000077a70fdd59af  movaps xmm7, xmm9
000077a70fdd59b3  mulpd xmm7, xmm15
000077a70fdd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000077a70fdd59bd  ptest xmm6, xmm6
000077a70fdd59c2  jnz 0x000077A70FDD68FB
000077a70fdd59c8  vxorps xmm15, xmm15, xmm15
000077a70fdd59cd  vpbroadcastq xmm15, xmm15
000077a70fdd59d2  movaps xmm9, xmm12
000077a70fdd59d6  mulpd xmm9, xmm10
000077a70fdd59db  vcmppd xmm6, xmm9, xmm9, 0x03
000077a70fdd59e1  ptest xmm6, xmm6
000077a70fdd59e6  jnz 0x000077A70FDD6A3D
000077a70fdd59ec  movaps xmm10, xmm12
000077a70fdd59f0  mulpd xmm10, xmm11
000077a70fdd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000077a70fdd59fb  ptest xmm6, xmm6
000077a70fdd5a00  jnz 0x000077A70FDD6B81
000077a70fdd5a06  movaps xmm11, [r15+0x1F0]
000077a70fdd5a0e  movaps xmm6, xmm12
000077a70fdd5a12  mulpd xmm6, xmm11
000077a70fdd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000077a70fdd5a1c  ptest xmm5, xmm5
000077a70fdd5a21  jnz 0x000077A70FDD6CC5
000077a70fdd5a27  movaps xmm12, [r15+0x2A0]
000077a70fdd5a2f  vmovaps [rsp+0x80], xmm12
000077a70fdd5a38  vmovaps xmm11, [rsp+0x80]
000077a70fdd5a41  por xmm12, xmm11
000077a70fdd5a46  movaps xmm11, [r15+0x250]
000077a70fdd5a4e  vmovaps [rsp+0x80], xmm11
000077a70fdd5a57  vmovaps xmm5, [rsp+0x80]
000077a70fdd5a60  por xmm11, xmm5
000077a70fdd5a65  vmovaps xmm4, [rsp+0x70]
000077a70fdd5a6b  vpermilpd xmm4, xmm4, 0x00
000077a70fdd5a71  movaps xmm3, xmm5
000077a70fdd5a74  mulpd xmm3, xmm4
000077a70fdd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000077a70fdd5a7d  ptest xmm2, xmm2
000077a70fdd5a82  jnz 0x000077A70FDD6E07
000077a70fdd5a88  mov [rsp+0x80], rax
000077a70fdd5a90  xor eax, eax
000077a70fdd5a92  mov r14d, 0x200
000077a70fdd5a98  cmp r12, r14
000077a70fdd5a9b  cmc
000077a70fdd5a9c  lahf
000077a70fdd5a9d  seto al
000077a70fdd5aa0  mov [r15+0x108], eax
000077a70fdd5aa7  movaps xmm5, xmm8
000077a70fdd5aab  addpd xmm5, xmm15
000077a70fdd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000077a70fdd5ab5  ptest xmm4, xmm4
000077a70fdd5aba  jnz 0x000077A70FDD6F47
000077a70fdd5ac0  movaps xmm8, [r15+0x1B0]
000077a70fdd5ac8  movaps xmm4, xmm9
000077a70fdd5acc  addpd xmm4, xmm8
000077a70fdd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000077a70fdd5ad6  ptest xmm2, xmm2
000077a70fdd5adb  jnz 0x000077A70FDD7089
000077a70fdd5ae1  movaps xmm9, xmm10
000077a70fdd5ae5  addpd xmm9, xmm8
000077a70fdd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000077a70fdd5af0  ptest xmm2, xmm2
000077a70fdd5af5  jnz 0x000077A70FDD71CB
000077a70fdd5afb  movaps xmm10, [r15+0x2F0]
000077a70fdd5b03  vmovaps [rsp+0x90], xmm10
000077a70fdd5b0c  vmovaps xmm8, [rsp+0x90]
000077a70fdd5b15  por xmm10, xmm8
000077a70fdd5b1a  movaps xmm8, [r15+0x2E0]
000077a70fdd5b22  vmovaps [rsp+0x90], xmm8
000077a70fdd5b2b  vmovaps xmm2, [rsp+0x90]
000077a70fdd5b34  por xmm8, xmm2
000077a70fdd5b39  movaps xmm2, [r15+0x2D0]
000077a70fdd5b41  vmovaps [rsp+0x90], xmm2
000077a70fdd5b4a  vmovaps [rsp+0xA0], xmm1
000077a70fdd5b53  vmovaps xmm1, [rsp+0x90]
000077a70fdd5b5c  por xmm2, xmm1
000077a70fdd5b60  movaps xmm1, [r15+0x200]
000077a70fdd5b68  vmovaps [rsp+0x90], xmm1
000077a70fdd5b71  vmovaps [rsp+0xB0], xmm15
000077a70fdd5b7a  vmovaps xmm15, [rsp+0x90]
000077a70fdd5b83  por xmm1, xmm15
000077a70fdd5b88  movaps xmm15, [r15+0x1C0]
000077a70fdd5b90  vmovaps [rsp+0x90], xmm15
000077a70fdd5b99  vmovaps [rsp+0xC0], xmm1
000077a70fdd5ba2  vmovaps xmm1, [rsp+0x90]
000077a70fdd5bab  por xmm15, xmm1
000077a70fdd5bb0  movaps xmm1, [r15+0x190]
000077a70fdd5bb8  vmovaps [rsp+0x90], xmm1
000077a70fdd5bc1  vmovaps [rsp+0xD0], xmm15
000077a70fdd5bca  vmovaps xmm15, [rsp+0x90]
000077a70fdd5bd3  por xmm1, xmm15
000077a70fdd5bd8  movaps xmm15, [r15+0x300]
000077a70fdd5be0  vmovaps [rsp+0x90], xmm15
000077a70fdd5be9  vmovaps [rsp+0xE0], xmm1
000077a70fdd5bf2  vmovaps xmm1, [rsp+0x90]
000077a70fdd5bfb  por xmm15, xmm1
000077a70fdd5c00  mov rax, [rsp+0x80]
000077a70fdd5c08  lea r14, [rax+0xA0]
000077a70fdd5c0f  movups xmm1, [r13+r14*1]
000077a70fdd5c15  lea r14, [rax+0xB0]
000077a70fdd5c1c  vmovaps [rsp+0x80], xmm1
000077a70fdd5c25  movups xmm1, [r13+r14*1]
000077a70fdd5c2b  vmovaps [rsp+0x90], xmm1
000077a70fdd5c34  vmovaps [rsp+0xF0], xmm15
000077a70fdd5c3d  vmovaps xmm15, [rsp+0xB0]
000077a70fdd5c46  vmovaps [rsp+0xB0], xmm14
000077a70fdd5c4f  movaps xmm1, xmm6
000077a70fdd5c52  addpd xmm1, xmm15
000077a70fdd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000077a70fdd5c5c  ptest xmm14, xmm14
000077a70fdd5c62  jnz 0x000077A70FDD7323
000077a70fdd5c68  lea r14, [rax+0xF0]
000077a70fdd5c6f  movups xmm15, [r13+r14*1]
000077a70fdd5c75  movaps xmm14, xmm4
000077a70fdd5c79  addpd xmm14, xmm3
000077a70fdd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000077a70fdd5c84  ptest xmm6, xmm6
000077a70fdd5c89  jnz 0x000077A70FDD746E
000077a70fdd5c8f  movaps xmm6, xmm9
000077a70fdd5c93  addpd xmm6, xmm7
000077a70fdd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000077a70fdd5c9c  ptest xmm4, xmm4
000077a70fdd5ca1  jnz 0x000077A70FDD75B0
000077a70fdd5ca7  vmovaps xmm9, [rsp+0x70]
000077a70fdd5cad  vpermilpd xmm9, xmm9, 0x00
000077a70fdd5cb3  vmovaps xmm4, [rsp+0x90]
000077a70fdd5cbc  movaps xmm7, xmm4
000077a70fdd5cbf  mulpd xmm7, xmm9
000077a70fdd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000077a70fdd5cc9  ptest xmm3, xmm3
000077a70fdd5cce  jnz 0x000077A70FDD76F1
000077a70fdd5cd4  vmovaps xmm9, [rsp+0x50]
000077a70fdd5cda  vpermilpd xmm9, xmm9, 0x00
000077a70fdd5ce0  movaps xmm4, xmm15
000077a70fdd5ce4  mulpd xmm4, xmm9
000077a70fdd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000077a70fdd5cee  ptest xmm3, xmm3
000077a70fdd5cf3  jnz 0x000077A70FDD7832
000077a70fdd5cf9  lea r14, [rax+0xE0]
000077a70fdd5d00  movups xmm15, [r13+r14*1]
000077a70fdd5d06  vmovaps xmm9, [rsp+0x70]
000077a70fdd5d0c  vpermilpd xmm9, xmm9, 0x00
000077a70fdd5d12  vmovaps [rsp+0x70], xmm1
000077a70fdd5d18  vmovaps xmm1, [rsp+0x80]
000077a70fdd5d21  vmovaps [rsp+0x80], xmm15
000077a70fdd5d2a  movaps xmm3, xmm1
000077a70fdd5d2d  mulpd xmm3, xmm9
000077a70fdd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000077a70fdd5d37  ptest xmm15, xmm15
000077a70fdd5d3d  jnz 0x000077A70FDD797E
000077a70fdd5d43  vmovaps xmm1, [rsp+0xF0]
000077a70fdd5d4c  vmovaps xmm15, [rsp+0xF0]
000077a70fdd5d55  por xmm1, xmm15
000077a70fdd5d5a  movaps [r15+0x300], xmm1
000077a70fdd5d62  vmovaps xmm15, [rsp+0xE0]
000077a70fdd5d6b  vmovaps xmm9, [rsp+0xE0]
000077a70fdd5d74  por xmm15, xmm9
000077a70fdd5d79  movaps [r15+0x190], xmm15
000077a70fdd5d81  vmovaps xmm9, [rsp+0x50]
000077a70fdd5d87  vpermilpd xmm9, xmm9, 0x00
000077a70fdd5d8d  vmovaps [rsp+0x90], xmm1
000077a70fdd5d96  vmovaps [rsp+0xE0], xmm15
000077a70fdd5d9f  vmovaps xmm15, [rsp+0x80]
000077a70fdd5da8  vmovaps [rsp+0x80], xmm14
000077a70fdd5db1  movaps xmm1, xmm15
000077a70fdd5db5  mulpd xmm1, xmm9
000077a70fdd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000077a70fdd5dbf  ptest xmm14, xmm14
000077a70fdd5dc5  jnz 0x000077A70FDD7ABF
000077a70fdd5dcb  lea r14, [rax+0x90]
000077a70fdd5dd2  movups xmm15, [r13+r14*1]
000077a70fdd5dd8  vmovaps xmm14, [rsp+0xD0]
000077a70fdd5de1  vmovaps xmm9, [rsp+0xD0]
000077a70fdd5dea  por xmm14, xmm9
000077a70fdd5def  movaps [r15+0x1C0], xmm14
000077a70fdd5df7  vmovaps xmm9, [rsp+0xC0]
000077a70fdd5e00  vmovaps [rsp+0xD0], xmm1
000077a70fdd5e09  vmovaps xmm1, [rsp+0xC0]
000077a70fdd5e12  por xmm9, xmm1
000077a70fdd5e17  movaps [r15+0x200], xmm9
000077a70fdd5e1f  vmovaps [rsp+0xC0], xmm2
000077a70fdd5e28  vmovaps xmm1, [rsp+0xC0]
000077a70fdd5e31  por xmm2, xmm1
000077a70fdd5e35  movaps [r15+0x2D0], xmm2
000077a70fdd5e3d  vmovaps [rsp+0xC0], xmm8
000077a70fdd5e46  vmovaps xmm1, [rsp+0xC0]
000077a70fdd5e4f  por xmm8, xmm1
000077a70fdd5e54  movaps [r15+0x2E0], xmm8
000077a70fdd5e5c  vmovaps [rsp+0xC0], xmm15
000077a70fdd5e65  movaps xmm1, xmm5
000077a70fdd5e68  addpd xmm1, xmm7
000077a70fdd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000077a70fdd5e71  ptest xmm15, xmm15
000077a70fdd5e77  jnz 0x000077A70FDD7C0B
000077a70fdd5e7d  vmovaps xmm15, [rsp+0x50]
000077a70fdd5e83  vpermilpd xmm15, xmm15, 0x00
000077a70fdd5e89  vmovaps xmm5, [rsp+0xC0]
000077a70fdd5e92  vmovaps [rsp+0xC0], xmm1
000077a70fdd5e9b  movaps xmm7, xmm5
000077a70fdd5e9e  mulpd xmm7, xmm15
000077a70fdd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000077a70fdd5ea8  ptest xmm1, xmm1
000077a70fdd5ead  jnz 0x000077A70FDD7D4B
000077a70fdd5eb3  lea r14, [rax+0x80]
000077a70fdd5eba  movups xmm1, [r13+r14*1]
000077a70fdd5ec0  vmovaps xmm5, [rsp+0x70]
000077a70fdd5ec6  vmovaps [rsp+0x70], xmm1
000077a70fdd5ecc  movaps xmm15, xmm5
000077a70fdd5ed0  addpd xmm15, xmm3
000077a70fdd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000077a70fdd5edb  ptest xmm1, xmm1
000077a70fdd5ee0  jnz 0x000077A70FDD7E96
000077a70fdd5ee6  vmovaps xmm5, [rsp+0x80]
000077a70fdd5eef  movaps xmm1, xmm5
000077a70fdd5ef2  addpd xmm1, xmm4
000077a70fdd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000077a70fdd5efb  ptest xmm3, xmm3
000077a70fdd5f00  jnz 0x000077A70FDD7FD8
000077a70fdd5f06  vmovaps [rsp+0x80], xmm10
000077a70fdd5f0f  vmovaps xmm5, [rsp+0x80]
000077a70fdd5f18  por xmm10, xmm5
000077a70fdd5f1d  movaps [r15+0x2F0], xmm10
000077a70fdd5f25  vmovaps xmm5, [rsp+0x50]
000077a70fdd5f2b  vpermilpd xmm5, xmm5, 0x00
000077a70fdd5f31  vmovaps xmm3, [rsp+0x70]
000077a70fdd5f37  vmovaps [rsp+0x50], xmm1
000077a70fdd5f3d  movaps xmm4, xmm3
000077a70fdd5f40  mulpd xmm4, xmm5
000077a70fdd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000077a70fdd5f49  ptest xmm1, xmm1
000077a70fdd5f4e  jnz 0x000077A70FDD8118
000077a70fdd5f54  lea r14, [rax+0xD0]
000077a70fdd5f5b  movups xmm1, [r13+r14*1]
000077a70fdd5f61  vmovaps xmm3, [rsp+0xD0]
000077a70fdd5f6a  vmovaps [rsp+0x70], xmm1
000077a70fdd5f70  movaps xmm5, xmm6
000077a70fdd5f73  addpd xmm5, xmm3
000077a70fdd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000077a70fdd5f7c  ptest xmm1, xmm1
000077a70fdd5f81  jnz 0x000077A70FDD8262
000077a70fdd5f87  vmovaps xmm1, [rsp+0x60]
000077a70fdd5f8d  vpermilpd xmm1, xmm1, 0x00
000077a70fdd5f93  movaps xmm6, xmm9
000077a70fdd5f97  mulpd xmm6, xmm1
000077a70fdd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000077a70fdd5fa0  ptest xmm3, xmm3
000077a70fdd5fa5  jnz 0x000077A70FDD83A2
000077a70fdd5fab  movaps [r15+0x260], xmm6
000077a70fdd5fb3  vxorps xmm1, xmm1, xmm1
000077a70fdd5fb7  vpbroadcastq xmm1, xmm1
000077a70fdd5fbc  movaps [r15+0x1B0], xmm1
000077a70fdd5fc4  vmovaps xmm1, [rsp+0x60]
000077a70fdd5fca  vpermilpd xmm1, xmm1, 0x00
000077a70fdd5fd0  vmovaps xmm3, [rsp+0x70]
000077a70fdd5fd6  vmovaps [rsp+0x70], xmm15
000077a70fdd5fdc  movaps xmm9, xmm3
000077a70fdd5fe0  mulpd xmm9, xmm1
000077a70fdd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000077a70fdd5feb  ptest xmm15, xmm15
000077a70fdd5ff1  jnz 0x000077A70FDD84E3
000077a70fdd5ff7  lea r14, [rax+0xC0]
000077a70fdd5ffe  movups xmm1, [r13+r14*1]
000077a70fdd6004  vmovaps xmm3, [rsp+0xC0]
000077a70fdd600d  vmovaps [rsp+0x80], xmm1
000077a70fdd6016  movaps xmm15, xmm3
000077a70fdd601a  addpd xmm15, xmm7
000077a70fdd601f  vcmppd xmm1, xmm15, xmm15, 0x03
000077a70fdd6025  ptest xmm1, xmm1
000077a70fdd602a  jnz 0x000077A70FDD862F
000077a70fdd6030  vmovaps [rsp+0xC0], xmm13
000077a70fdd6039  vmovaps xmm1, [rsp+0xC0]
000077a70fdd6042  por xmm13, xmm1
000077a70fdd6047  movaps [r15+0x270], xmm13
000077a70fdd604f  vmovaps xmm1, [rsp+0xB0]
000077a70fdd6058  vmovaps xmm7, [rsp+0xB0]
000077a70fdd6061  por xmm1, xmm7
000077a70fdd6065  movaps [r15+0x1A0], xmm1
000077a70fdd606d  vmovaps xmm1, [rsp+0x60]
000077a70fdd6073  vpermilpd xmm1, xmm1, 0x00
000077a70fdd6079  vmovaps [rsp+0xB0], xmm1
000077a70fdd6082  vmovaps xmm1, [rsp+0x80]
000077a70fdd608b  vmovaps [rsp+0x80], xmm15
000077a70fdd6094  vmovaps xmm15, [rsp+0xB0]
000077a70fdd609d  vmovaps [rsp+0xB0], xmm14
000077a70fdd60a6  movaps xmm3, xmm1
000077a70fdd60a9  mulpd xmm3, xmm15
000077a70fdd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000077a70fdd60b3  ptest xmm14, xmm14
000077a70fdd60b9  jnz 0x000077A70FDD8771
000077a70fdd60bf  lea r14, [rax+0x20]
000077a70fdd60c3  movups xmm1, [r13+r14*1]
000077a70fdd60c9  movaps [r15+0x110], xmm1
000077a70fdd60d1  vmovaps xmm14, [rsp+0x70]
000077a70fdd60d7  vmovaps [rsp+0x70], xmm1
000077a70fdd60dd  movaps xmm15, xmm14
000077a70fdd60e1  addpd xmm15, xmm4
000077a70fdd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000077a70fdd60ec  ptest xmm1, xmm1
000077a70fdd60f1  jnz 0x000077A70FDD88BC
000077a70fdd60f7  vmovaps xmm1, [rsp+0x60]
000077a70fdd60fd  vpermilpd xmm1, xmm1, 0x00
000077a70fdd6103  movaps xmm14, xmm2
000077a70fdd6107  mulpd xmm14, xmm1
000077a70fdd610c  vcmppd xmm4, xmm14, xmm14, 0x03
000077a70fdd6112  ptest xmm4, xmm4
000077a70fdd6117  jnz 0x000077A70FDD89FF
000077a70fdd611d  vmovaps xmm4, [rsp+0x50]
000077a70fdd6123  movaps xmm1, xmm4
000077a70fdd6126  addpd xmm1, xmm9
000077a70fdd612b  vcmppd xmm2, xmm1, xmm1, 0x03
000077a70fdd6130  ptest xmm2, xmm2
000077a70fdd6135  jnz 0x000077A70FDD8B41
000077a70fdd613b  vmovaps xmm9, [rsp+0x30]
000077a70fdd6141  vpermilpd xmm9, xmm9, 0x00
000077a70fdd6147  vmovaps xmm2, [rsp+0x70]
000077a70fdd614d  vmovaps [rsp+0x50], xmm1
000077a70fdd6153  movaps xmm4, xmm2
000077a70fdd6156  mulpd xmm4, xmm9
000077a70fdd615b  vcmppd xmm1, xmm4, xmm4, 0x03
000077a70fdd6160  ptest xmm1, xmm1
000077a70fdd6165  jnz 0x000077A70FDD8C82
000077a70fdd616b  vmovaps xmm1, [rsp+0x30]
000077a70fdd6171  vpermilpd xmm1, xmm1, 0x00
000077a70fdd6177  vmovaps xmm2, [rsp+0x90]
000077a70fdd6180  vmovaps [rsp+0x60], xmm15
000077a70fdd6186  movaps xmm9, xmm2
000077a70fdd618a  mulpd xmm9, xmm1
000077a70fdd618f  vcmppd xmm15, xmm9, xmm9, 0x03
000077a70fdd6195  ptest xmm15, xmm15
000077a70fdd619b  jnz 0x000077A70FDD8DC3
000077a70fdd61a1  vmovaps xmm15, [rsp+0x80]
000077a70fdd61aa  movaps xmm1, xmm15
000077a70fdd61ae  addpd xmm1, xmm6
000077a70fdd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000077a70fdd61b7  ptest xmm2, xmm2
000077a70fdd61bc  jnz 0x000077A70FDD8F05
000077a70fdd61c2  movaps xmm15, xmm5
000077a70fdd61c6  addpd xmm15, xmm3
000077a70fdd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000077a70fdd61d1  ptest xmm6, xmm6
000077a70fdd61d6  jnz 0x000077A70FDD9046
000077a70fdd61dc  vmovaps xmm6, [rsp+0x30]
000077a70fdd61e2  vpermilpd xmm6, xmm6, 0x00
000077a70fdd61e8  movaps xmm5, xmm8
000077a70fdd61ec  mulpd xmm5, xmm6
000077a70fdd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000077a70fdd61f5  ptest xmm3, xmm3
000077a70fdd61fa  jnz 0x000077A70FDD9188
000077a70fdd6200  vmovaps xmm8, [rsp+0x30]
000077a70fdd6206  vpermilpd xmm8, xmm8, 0x00
000077a70fdd620c  movaps xmm6, xmm10
000077a70fdd6210  mulpd xmm6, xmm8
000077a70fdd6215  vcmppd xmm3, xmm6, xmm6, 0x03
000077a70fdd621a  ptest xmm3, xmm3
000077a70fdd621f  jnz 0x000077A70FDD92C9
000077a70fdd6225  vmovaps xmm8, [rsp+0x60]
000077a70fdd622b  movaps xmm10, xmm8
000077a70fdd622f  addpd xmm10, xmm14
000077a70fdd6234  vcmppd xmm3, xmm10, xmm10, 0x03
000077a70fdd623a  ptest xmm3, xmm3
000077a70fdd623f  jnz 0x000077A70FDD940B
000077a70fdd6245  vmovaps xmm8, [rsp+0x50]
000077a70fdd624b  movaps xmm14, xmm8
000077a70fdd624f  addpd xmm14, xmm4
000077a70fdd6254  vcmppd xmm3, xmm14, xmm14, 0x03
000077a70fdd625a  ptest xmm3, xmm3
000077a70fdd625f  jnz 0x000077A70FDD954F
000077a70fdd6265  vmovaps xmm8, [rsp+0x40]
000077a70fdd626b  vpermilpd xmm8, xmm8, 0x00
000077a70fdd6271  movaps xmm4, xmm13
000077a70fdd6275  mulpd xmm4, xmm8
000077a70fdd627a  vcmppd xmm3, xmm4, xmm4, 0x03
000077a70fdd627f  ptest xmm3, xmm3
000077a70fdd6284  jnz 0x000077A70FDD9692
000077a70fdd628a  movaps xmm13, xmm15
000077a70fdd628e  addpd xmm13, xmm9
000077a70fdd6293  vcmppd xmm8, xmm13, xmm13, 0x03
000077a70fdd6299  ptest xmm8, xmm8
000077a70fdd629f  jnz 0x000077A70FDD97D4
000077a70fdd62a5  movaps xmm15, xmm1
000077a70fdd62a9  addpd xmm15, xmm5
000077a70fdd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000077a70fdd62b4  ptest xmm9, xmm9
000077a70fdd62ba  jnz 0x000077A70FDD9918
000077a70fdd62c0  vmovaps [rsp+0x30], xmm11
000077a70fdd62c6  vmovaps xmm1, [rsp+0x30]
000077a70fdd62cc  por xmm11, xmm1
000077a70fdd62d1  movaps [r15+0x250], xmm11
000077a70fdd62d9  vmovaps [rsp+0x30], xmm12
000077a70fdd62df  vmovaps xmm1, [rsp+0x30]
000077a70fdd62e5  por xmm12, xmm1
000077a70fdd62ea  movaps [r15+0x2A0], xmm12
000077a70fdd62f2  vmovaps xmm1, [rsp+0xA0]
000077a70fdd62fb  vmovaps xmm11, [rsp+0xA0]
000077a70fdd6304  por xmm1, xmm11
000077a70fdd6309  movaps [r15+0x1D0], xmm1
000077a70fdd6311  lea r14, [rax+0x40]
000077a70fdd6315  movups xmm1, [r13+r14*1]
000077a70fdd631b  movaps [r15+0x2C0], xmm1
000077a70fdd6323  vmovaps xmm11, [rsp+0x40]
000077a70fdd6329  vpermilpd xmm11, xmm11, 0x00
000077a70fdd632f  vmovaps xmm8, [rsp+0xE0]
000077a70fdd6338  movaps xmm9, xmm8
000077a70fdd633c  mulpd xmm9, xmm11
000077a70fdd6341  vcmppd xmm5, xmm9, xmm9, 0x03
000077a70fdd6347  ptest xmm5, xmm5
000077a70fdd634c  jnz 0x000077A70FDD9A64
000077a70fdd6352  movaps xmm11, xmm10
000077a70fdd6356  addpd xmm11, xmm6
000077a70fdd635b  vcmppd xmm8, xmm11, xmm11, 0x03
000077a70fdd6361  ptest xmm8, xmm8
000077a70fdd6367  jnz 0x000077A70FDD9BA8
000077a70fdd636d  movaps xmm10, xmm14
000077a70fdd6371  addpd xmm10, xmm4
000077a70fdd6376  vcmppd xmm8, xmm10, xmm10, 0x03
000077a70fdd637c  ptest xmm8, xmm8
000077a70fdd6382  jnz 0x000077A70FDD9CEB
000077a70fdd6388  vmovaps xmm14, [rsp+0x40]
000077a70fdd638e  vpermilpd xmm14, xmm14, 0x00
000077a70fdd6394  movaps xmm8, xmm1
000077a70fdd6398  mulpd xmm8, xmm14
000077a70fdd639d  vcmppd xmm6, xmm8, xmm8, 0x03
000077a70fdd63a3  ptest xmm6, xmm6
000077a70fdd63a8  jnz 0x000077A70FDD9E2E
000077a70fdd63ae  movaps xmm1, [r15+0x2B0]
000077a70fdd63b6  vmovaps xmm14, [rsp+0x40]
000077a70fdd63bc  vpermilpd xmm14, xmm14, 0x00
000077a70fdd63c2  movaps xmm6, xmm1
000077a70fdd63c5  mulpd xmm6, xmm14
000077a70fdd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000077a70fdd63cf  ptest xmm5, xmm5
000077a70fdd63d4  jnz 0x000077A70FDD9F71
000077a70fdd63da  vmovaps xmm1, [rsp+0x10]
000077a70fdd63e0  vpermilpd xmm1, xmm1, 0x00
000077a70fdd63e6  movaps xmm14, xmm12
000077a70fdd63ea  mulpd xmm14, xmm1
000077a70fdd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000077a70fdd63f5  ptest xmm5, xmm5
000077a70fdd63fa  jnz 0x000077A70FDDA0B2
000077a70fdd6400  movaps xmm1, xmm13
000077a70fdd6404  addpd xmm1, xmm9
000077a70fdd6409  vcmppd xmm12, xmm1, xmm1, 0x03
000077a70fdd640e  ptest xmm12, xmm12
000077a70fdd6414  jnz 0x000077A70FDDA1F5
000077a70fdd641a  vmovaps xmm13, [rsp+0x10]
000077a70fdd6420  vpermilpd xmm13, xmm13, 0x00
000077a70fdd6426  movaps xmm12, xmm7
000077a70fdd642a  mulpd xmm12, xmm13
000077a70fdd642f  vcmppd xmm9, xmm12, xmm12, 0x03
000077a70fdd6435  ptest xmm9, xmm9
000077a70fdd643b  jnz 0x000077A70FDDA337
000077a70fdd6441  movaps xmm13, xmm15
000077a70fdd6445  addpd xmm13, xmm8
000077a70fdd644a  vcmppd xmm9, xmm13, xmm13, 0x03
000077a70fdd6450  ptest xmm9, xmm9
000077a70fdd6456  jnz 0x000077A70FDDA47A
000077a70fdd645c  movaps xmm15, [r15+0x290]
000077a70fdd6464  vmovaps xmm9, [rsp+0x10]
000077a70fdd646a  vpermilpd xmm9, xmm9, 0x00
000077a70fdd6470  movaps xmm8, xmm15
000077a70fdd6474  mulpd xmm8, xmm9
000077a70fdd6479  vcmppd xmm7, xmm8, xmm8, 0x03
000077a70fdd647f  ptest xmm7, xmm7
000077a70fdd6484  jnz 0x000077A70FDDA5BE
000077a70fdd648a  movaps xmm15, xmm11
000077a70fdd648e  addpd xmm15, xmm6
000077a70fdd6493  vcmppd xmm9, xmm15, xmm15, 0x03
000077a70fdd6499  ptest xmm9, xmm9
000077a70fdd649f  jnz 0x000077A70FDDA702
000077a70fdd64a5  movaps xmm11, [r15+0x1E0]
000077a70fdd64ad  vmovaps xmm9, [rsp+0x10]
000077a70fdd64b3  vpermilpd xmm9, xmm9, 0x00
000077a70fdd64b9  movaps xmm7, xmm11
000077a70fdd64bd  mulpd xmm7, xmm9
000077a70fdd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000077a70fdd64c7  ptest xmm6, xmm6
000077a70fdd64cc  jnz 0x000077A70FDDA845
000077a70fdd64d2  movaps xmm11, xmm10
000077a70fdd64d6  addpd xmm11, xmm14
000077a70fdd64db  vcmppd xmm9, xmm11, xmm11, 0x03
000077a70fdd64e1  ptest xmm9, xmm9
000077a70fdd64e7  jnz 0x000077A70FDDA987
000077a70fdd64ed  lea r14, [rax+0x70]
000077a70fdd64f1  movups xmm14, [r13+r14*1]
000077a70fdd64f7  movaps [r15+0x240], xmm14
000077a70fdd64ff  movaps xmm10, xmm1
000077a70fdd6503  addpd xmm10, xmm12
000077a70fdd6508  vcmppd xmm9, xmm10, xmm10, 0x03
000077a70fdd650e  ptest xmm9, xmm9
000077a70fdd6514  jnz 0x000077A70FDDAAD5
000077a70fdd651a  movaps [r15+0x170], xmm10
000077a70fdd6522  vmovaps xmm1, [rsp+0x20]
000077a70fdd6528  vpermilpd xmm1, xmm1, 0x00
000077a70fdd652e  movaps xmm12, xmm14
000077a70fdd6532  mulpd xmm12, xmm1
000077a70fdd6537  vcmppd xmm9, xmm12, xmm12, 0x03
000077a70fdd653d  ptest xmm9, xmm9
000077a70fdd6543  jnz 0x000077A70FDDAC18
000077a70fdd6549  vmovaps xmm1, [rsp+0x20]
000077a70fdd654f  vpermilpd xmm1, xmm1, 0x00
000077a70fdd6555  vmovaps xmm9, [rsp+0xB0]
000077a70fdd655e  movaps xmm14, xmm9
000077a70fdd6562  mulpd xmm14, xmm1
000077a70fdd6567  vcmppd xmm6, xmm14, xmm14, 0x03
000077a70fdd656d  ptest xmm6, xmm6
000077a70fdd6572  jnz 0x000077A70FDDAD5B
000077a70fdd6578  movaps [r15+0x180], xmm14
000077a70fdd6580  movaps xmm1, xmm13
000077a70fdd6584  addpd xmm1, xmm8
000077a70fdd6589  vcmppd xmm9, xmm1, xmm1, 0x03
000077a70fdd658e  ptest xmm9, xmm9
000077a70fdd6594  jnz 0x000077A70FDDAE9E
000077a70fdd659a  movaps [r15+0x210], xmm1
000077a70fdd65a2  movups xmm13, [r13+rax*1]
000077a70fdd65a8  lea r14, [rax+0x10]
000077a70fdd65ac  movups xmm9, [r13+r14*1]
000077a70fdd65b2  movaps [r15+0x230], xmm9
000077a70fdd65ba  movaps xmm8, xmm15
000077a70fdd65be  addpd xmm8, xmm7
000077a70fdd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000077a70fdd65c9  ptest xmm6, xmm6
000077a70fdd65ce  jnz 0x000077A70FDDAFF4
000077a70fdd65d4  movaps [r15+0x130], xmm8
000077a70fdd65dc  vmovaps xmm15, [rsp+0x20]
000077a70fdd65e2  vpermilpd xmm15, xmm15, 0x00
000077a70fdd65e8  movaps xmm7, xmm9
000077a70fdd65ec  mulpd xmm7, xmm15
000077a70fdd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000077a70fdd65f6  ptest xmm6, xmm6
000077a70fdd65fb  jnz 0x000077A70FDDB137
000077a70fdd6601  movaps [r15+0x220], xmm7
000077a70fdd6609  vmovaps xmm15, [rsp+0x20]
000077a70fdd660f  vpermilpd xmm15, xmm15, 0x00
000077a70fdd6615  movaps xmm9, xmm13
000077a70fdd6619  mulpd xmm9, xmm15
000077a70fdd661e  vcmppd xmm6, xmm9, xmm9, 0x03
000077a70fdd6624  ptest xmm6, xmm6
000077a70fdd6629  jnz 0x000077A70FDDB279
000077a70fdd662f  movaps xmm15, xmm11
000077a70fdd6633  addpd xmm15, xmm12
000077a70fdd6638  vcmppd xmm13, xmm15, xmm15, 0x03
000077a70fdd663e  ptest xmm13, xmm13
000077a70fdd6644  jnz 0x000077A70FDDB3BD
000077a70fdd664a  movaps [r15+0x140], xmm15
000077a70fdd6652  movaps xmm13, xmm10
000077a70fdd6656  addpd xmm13, xmm14
000077a70fdd665b  vcmppd xmm12, xmm13, xmm13, 0x03
000077a70fdd6661  ptest xmm12, xmm12
000077a70fdd6667  jnz 0x000077A70FDDB501
000077a70fdd666d  movaps [r15+0x150], xmm13
000077a70fdd6675  movaps xmm14, xmm1
000077a70fdd6679  addpd xmm14, xmm7
000077a70fdd667e  vcmppd xmm12, xmm14, xmm14, 0x03
000077a70fdd6684  ptest xmm12, xmm12
000077a70fdd668a  jnz 0x000077A70FDDB645
000077a70fdd6690  movaps [r15+0x160], xmm14
000077a70fdd6698  movaps xmm1, xmm8
000077a70fdd669c  addpd xmm1, xmm9
000077a70fdd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000077a70fdd66a6  ptest xmm12, xmm12
000077a70fdd66ac  jnz 0x000077A70FDDB787
000077a70fdd66b2  movaps [r15+0x120], xmm1
000077a70fdd66ba  movups [r13+r11*1], xmm15
000077a70fdd66c0  lea rax, [r11+0x10]
000077a70fdd66c4  movups [r13+rax*1], xmm13
000077a70fdd66ca  lea rax, [r11+0x20]
000077a70fdd66ce  movups [r13+rax*1], xmm14
000077a70fdd66d4  lea rax, [r11+0x30]
000077a70fdd66d8  movups [r13+rax*1], xmm1
000077a70fdd66de  mov eax, [r15+0x108]
000077a70fdd66e5  sahf
000077a70fdd66e6  jnz 0x000077A70FDD6718
000077a70fdd66e8  cmp dword ptr [r15+0x318], 0x00
000077a70fdd66f0  jz 0x000077A70FDDB900
000077a70fdd66f6  nop [rax+rax*1], ax
000077a70fdd66ff  nop [rax+rax*1], eax
000077a70fdd6707  mov eax, 0x410444
000077a70fdd670c  mov [r15+0x100], rax
000077a70fdd6713  jmp 0x000077A70FBFE110
000077a70fdd6718  cmp dword ptr [r15+0x318], 0x00
000077a70fdd6720  jz 0x000077A70FDD57E0
000077a70fdd6726  nop [rax+rax*1], ax
000077a70fdd672f  nop [rax+rax*1], eax
000077a70fdd6737  mov eax, 0x410278
000077a70fdd673c  mov [r15+0x100], rax
000077a70fdd6743  jmp 0x000077A70FBFE110
000077a70fdd6748  int3
000077a70fdd6749  call 0x000077A70FC0A4B0
000077a70fdd674e  jmp 0x000077A70FDD5828
000077a70fdd6753  call 0x000077A70FC09240
000077a70fdd6758  jmp 0x000077A70FDD5832
000077a70fdd675d  call 0x000077A70FC0A4B0
000077a70fdd6762  jmp 0x000077A70FDD588F
000077a70fdd6767  call 0x000077A70FC09240
000077a70fdd676c  jmp 0x000077A70FDD5899
000077a70fdd6771  call 0x000077A70FC0A4B0
000077a70fdd6776  jmp 0x000077A70FDD58DD
000077a70fdd677b  call 0x000077A70FC09240
000077a70fdd6780  jmp 0x000077A70FDD58E7
000077a70fdd6785  call 0x000077A70FCB47C0
000077a70fdd678a  jmp 0x000077A70FDD5926
000077a70fdd678f  call 0x000077A70FC0B720
000077a70fdd6794  jmp 0x000077A70FDD593A
000077a70fdd6799  call 0x000077A70FCBFC30
000077a70fdd679e  jmp 0x000077A70FDD5958
000077a70fdd67a3  call 0x000077A70FCBE9C0
000077a70fdd67a8  jmp 0x000077A70FDD5962
000077a70fdd67ad  call 0x000077A70FCBD750
000077a70fdd67b2  jmp 0x000077A70FDD596C
000077a70fdd67b7  sub rsp, 0x08
000077a70fdd67bb  push rax
000077a70fdd67bc  push rcx
000077a70fdd67bd  push rdx
000077a70fdd67be  push rdi
000077a70fdd67bf  push rsi
000077a70fdd67c0  push r8
000077a70fdd67c2  push r9
000077a70fdd67c4  push r10
000077a70fdd67c6  push r11
000077a70fdd67c8  sub rsp, 0xF0
000077a70fdd67cf  vmovaps [rsp], xmm0
000077a70fdd67d4  vmovaps [rsp+0x10], xmm1
000077a70fdd67da  vmovaps [rsp+0x20], xmm2
000077a70fdd67e0  vmovaps [rsp+0x30], xmm3
000077a70fdd67e6  vmovaps [rsp+0x40], xmm4
000077a70fdd67ec  vmovaps [rsp+0x50], xmm5
000077a70fdd67f2  vmovaps [rsp+0x60], xmm6
000077a70fdd67f8  vmovaps [rsp+0x70], xmm7
000077a70fdd67fe  vmovaps [rsp+0x80], xmm9
000077a70fdd6807  vmovaps [rsp+0x90], xmm10
000077a70fdd6810  vmovaps [rsp+0xA0], xmm11
000077a70fdd6819  vmovaps [rsp+0xB0], xmm12
000077a70fdd6822  vmovaps [rsp+0xC0], xmm13
000077a70fdd682b  vmovaps [rsp+0xD0], xmm14
000077a70fdd6834  vmovaps [rsp+0xE0], xmm15
000077a70fdd683d  sub rsp, 0x30
000077a70fdd6841  movaps [rsp], xmm8
000077a70fdd6846  movaps [rsp+0x10], xmm12
000077a70fdd684c  movaps [rsp+0x20], xmm15
000077a70fdd6852  lea rdi, [rsp]
000077a70fdd6856  mov esi, 0x00
000077a70fdd685b  mov rax, 0x6294188EF530
000077a70fdd6865  call rax
000077a70fdd6867  movaps xmm8, [rsp]
000077a70fdd686c  add rsp, 0x30
000077a70fdd6870  vmovaps xmm0, [rsp]
000077a70fdd6875  vmovaps xmm1, [rsp+0x10]
000077a70fdd687b  vmovaps xmm2, [rsp+0x20]
000077a70fdd6881  vmovaps xmm3, [rsp+0x30]
000077a70fdd6887  vmovaps xmm4, [rsp+0x40]
000077a70fdd688d  vmovaps xmm5, [rsp+0x50]
000077a70fdd6893  vmovaps xmm6, [rsp+0x60]
000077a70fdd6899  vmovaps xmm7, [rsp+0x70]
000077a70fdd689f  vmovaps xmm9, [rsp+0x80]
000077a70fdd68a8  vmovaps xmm10, [rsp+0x90]
000077a70fdd68b1  vmovaps xmm11, [rsp+0xA0]
000077a70fdd68ba  vmovaps xmm12, [rsp+0xB0]
000077a70fdd68c3  vmovaps xmm13, [rsp+0xC0]
000077a70fdd68cc  vmovaps xmm14, [rsp+0xD0]
000077a70fdd68d5  vmovaps xmm15, [rsp+0xE0]
000077a70fdd68de  add rsp, 0xF0
000077a70fdd68e5  pop r11
000077a70fdd68e7  pop r10
000077a70fdd68e9  pop r9
000077a70fdd68eb  pop r8
000077a70fdd68ed  pop rsi
000077a70fdd68ee  pop rdi
000077a70fdd68ef  pop rdx
000077a70fdd68f0  pop rcx
000077a70fdd68f1  pop rax
000077a70fdd68f2  add rsp, 0x08
000077a70fdd68f6  jmp 0x000077A70FDD599A
000077a70fdd68fb  sub rsp, 0x08
000077a70fdd68ff  push rax
000077a70fdd6900  push rcx
000077a70fdd6901  push rdx
000077a70fdd6902  push rdi
000077a70fdd6903  push rsi
000077a70fdd6904  push r8
000077a70fdd6906  push r9
000077a70fdd6908  push r10
000077a70fdd690a  push r11
000077a70fdd690c  sub rsp, 0xF0
000077a70fdd6913  vmovaps [rsp], xmm0
000077a70fdd6918  vmovaps [rsp+0x10], xmm1
000077a70fdd691e  vmovaps [rsp+0x20], xmm2
000077a70fdd6924  vmovaps [rsp+0x30], xmm3
000077a70fdd692a  vmovaps [rsp+0x40], xmm4
000077a70fdd6930  vmovaps [rsp+0x50], xmm5
000077a70fdd6936  vmovaps [rsp+0x60], xmm6
000077a70fdd693c  vmovaps [rsp+0x70], xmm8
000077a70fdd6942  vmovaps [rsp+0x80], xmm9
000077a70fdd694b  vmovaps [rsp+0x90], xmm10
000077a70fdd6954  vmovaps [rsp+0xA0], xmm11
000077a70fdd695d  vmovaps [rsp+0xB0], xmm12
000077a70fdd6966  vmovaps [rsp+0xC0], xmm13
000077a70fdd696f  vmovaps [rsp+0xD0], xmm14
000077a70fdd6978  vmovaps [rsp+0xE0], xmm15
000077a70fdd6981  sub rsp, 0x30
000077a70fdd6985  movaps [rsp], xmm7
000077a70fdd6989  movaps [rsp+0x10], xmm9
000077a70fdd698f  movaps [rsp+0x20], xmm15
000077a70fdd6995  lea rdi, [rsp]
000077a70fdd6999  mov esi, 0x00
000077a70fdd699e  mov rax, 0x6294188EF530
000077a70fdd69a8  call rax
000077a70fdd69aa  movaps xmm7, [rsp]
000077a70fdd69ae  add rsp, 0x30
000077a70fdd69b2  vmovaps xmm0, [rsp]
000077a70fdd69b7  vmovaps xmm1, [rsp+0x10]
000077a70fdd69bd  vmovaps xmm2, [rsp+0x20]
000077a70fdd69c3  vmovaps xmm3, [rsp+0x30]
000077a70fdd69c9  vmovaps xmm4, [rsp+0x40]
000077a70fdd69cf  vmovaps xmm5, [rsp+0x50]
000077a70fdd69d5  vmovaps xmm6, [rsp+0x60]
000077a70fdd69db  vmovaps xmm8, [rsp+0x70]
000077a70fdd69e1  vmovaps xmm9, [rsp+0x80]
000077a70fdd69ea  vmovaps xmm10, [rsp+0x90]
000077a70fdd69f3  vmovaps xmm11, [rsp+0xA0]
000077a70fdd69fc  vmovaps xmm12, [rsp+0xB0]
000077a70fdd6a05  vmovaps xmm13, [rsp+0xC0]
000077a70fdd6a0e  vmovaps xmm14, [rsp+0xD0]
000077a70fdd6a17  vmovaps xmm15, [rsp+0xE0]
000077a70fdd6a20  add rsp, 0xF0
000077a70fdd6a27  pop r11
000077a70fdd6a29  pop r10
000077a70fdd6a2b  pop r9
000077a70fdd6a2d  pop r8
000077a70fdd6a2f  pop rsi
000077a70fdd6a30  pop rdi
000077a70fdd6a31  pop rdx
000077a70fdd6a32  pop rcx
000077a70fdd6a33  pop rax
000077a70fdd6a34  add rsp, 0x08
000077a70fdd6a38  jmp 0x000077A70FDD59C8
000077a70fdd6a3d  sub rsp, 0x08
000077a70fdd6a41  push rax
000077a70fdd6a42  push rcx
000077a70fdd6a43  push rdx
000077a70fdd6a44  push rdi
000077a70fdd6a45  push rsi
000077a70fdd6a46  push r8
000077a70fdd6a48  push r9
000077a70fdd6a4a  push r10
000077a70fdd6a4c  push r11
000077a70fdd6a4e  sub rsp, 0xF0
000077a70fdd6a55  vmovaps [rsp], xmm0
000077a70fdd6a5a  vmovaps [rsp+0x10], xmm1
000077a70fdd6a60  vmovaps [rsp+0x20], xmm2
000077a70fdd6a66  vmovaps [rsp+0x30], xmm3
000077a70fdd6a6c  vmovaps [rsp+0x40], xmm4
000077a70fdd6a72  vmovaps [rsp+0x50], xmm5
000077a70fdd6a78  vmovaps [rsp+0x60], xmm6
000077a70fdd6a7e  vmovaps [rsp+0x70], xmm7
000077a70fdd6a84  vmovaps [rsp+0x80], xmm8
000077a70fdd6a8d  vmovaps [rsp+0x90], xmm10
000077a70fdd6a96  vmovaps [rsp+0xA0], xmm11
000077a70fdd6a9f  vmovaps [rsp+0xB0], xmm12
000077a70fdd6aa8  vmovaps [rsp+0xC0], xmm13
000077a70fdd6ab1  vmovaps [rsp+0xD0], xmm14
000077a70fdd6aba  vmovaps [rsp+0xE0], xmm15
000077a70fdd6ac3  sub rsp, 0x30
000077a70fdd6ac7  movaps [rsp], xmm9
000077a70fdd6acc  movaps [rsp+0x10], xmm12
000077a70fdd6ad2  movaps [rsp+0x20], xmm10
000077a70fdd6ad8  lea rdi, [rsp]
000077a70fdd6adc  mov esi, 0x00
000077a70fdd6ae1  mov rax, 0x6294188EF530
000077a70fdd6aeb  call rax
000077a70fdd6aed  movaps xmm9, [rsp]
000077a70fdd6af2  add rsp, 0x30
000077a70fdd6af6  vmovaps xmm0, [rsp]
000077a70fdd6afb  vmovaps xmm1, [rsp+0x10]
000077a70fdd6b01  vmovaps xmm2, [rsp+0x20]
000077a70fdd6b07  vmovaps xmm3, [rsp+0x30]
000077a70fdd6b0d  vmovaps xmm4, [rsp+0x40]
000077a70fdd6b13  vmovaps xmm5, [rsp+0x50]
000077a70fdd6b19  vmovaps xmm6, [rsp+0x60]
000077a70fdd6b1f  vmovaps xmm7, [rsp+0x70]
000077a70fdd6b25  vmovaps xmm8, [rsp+0x80]
000077a70fdd6b2e  vmovaps xmm10, [rsp+0x90]
000077a70fdd6b37  vmovaps xmm11, [rsp+0xA0]
000077a70fdd6b40  vmovaps xmm12, [rsp+0xB0]
000077a70fdd6b49  vmovaps xmm13, [rsp+0xC0]
000077a70fdd6b52  vmovaps xmm14, [rsp+0xD0]
000077a70fdd6b5b  vmovaps xmm15, [rsp+0xE0]
000077a70fdd6b64  add rsp, 0xF0
000077a70fdd6b6b  pop r11
000077a70fdd6b6d  pop r10
000077a70fdd6b6f  pop r9
000077a70fdd6b71  pop r8
000077a70fdd6b73  pop rsi
000077a70fdd6b74  pop rdi
000077a70fdd6b75  pop rdx
000077a70fdd6b76  pop rcx
000077a70fdd6b77  pop rax
000077a70fdd6b78  add rsp, 0x08
000077a70fdd6b7c  jmp 0x000077A70FDD59EC
000077a70fdd6b81  sub rsp, 0x08
000077a70fdd6b85  push rax
000077a70fdd6b86  push rcx
000077a70fdd6b87  push rdx
000077a70fdd6b88  push rdi
000077a70fdd6b89  push rsi
000077a70fdd6b8a  push r8
000077a70fdd6b8c  push r9
000077a70fdd6b8e  push r10
000077a70fdd6b90  push r11
000077a70fdd6b92  sub rsp, 0xF0
000077a70fdd6b99  vmovaps [rsp], xmm0
000077a70fdd6b9e  vmovaps [rsp+0x10], xmm1
000077a70fdd6ba4  vmovaps [rsp+0x20], xmm2
000077a70fdd6baa  vmovaps [rsp+0x30], xmm3
000077a70fdd6bb0  vmovaps [rsp+0x40], xmm4
000077a70fdd6bb6  vmovaps [rsp+0x50], xmm5
000077a70fdd6bbc  vmovaps [rsp+0x60], xmm6
000077a70fdd6bc2  vmovaps [rsp+0x70], xmm7
000077a70fdd6bc8  vmovaps [rsp+0x80], xmm8
000077a70fdd6bd1  vmovaps [rsp+0x90], xmm9
000077a70fdd6bda  vmovaps [rsp+0xA0], xmm11
000077a70fdd6be3  vmovaps [rsp+0xB0], xmm12
000077a70fdd6bec  vmovaps [rsp+0xC0], xmm13
000077a70fdd6bf5  vmovaps [rsp+0xD0], xmm14
000077a70fdd6bfe  vmovaps [rsp+0xE0], xmm15
000077a70fdd6c07  sub rsp, 0x30
000077a70fdd6c0b  movaps [rsp], xmm10
000077a70fdd6c10  movaps [rsp+0x10], xmm12
000077a70fdd6c16  movaps [rsp+0x20], xmm11
000077a70fdd6c1c  lea rdi, [rsp]
000077a70fdd6c20  mov esi, 0x00
000077a70fdd6c25  mov rax, 0x6294188EF530
000077a70fdd6c2f  call rax
000077a70fdd6c31  movaps xmm10, [rsp]
000077a70fdd6c36  add rsp, 0x30
000077a70fdd6c3a  vmovaps xmm0, [rsp]
000077a70fdd6c3f  vmovaps xmm1, [rsp+0x10]
000077a70fdd6c45  vmovaps xmm2, [rsp+0x20]
000077a70fdd6c4b  vmovaps xmm3, [rsp+0x30]
000077a70fdd6c51  vmovaps xmm4, [rsp+0x40]
000077a70fdd6c57  vmovaps xmm5, [rsp+0x50]
000077a70fdd6c5d  vmovaps xmm6, [rsp+0x60]
000077a70fdd6c63  vmovaps xmm7, [rsp+0x70]
000077a70fdd6c69  vmovaps xmm8, [rsp+0x80]
000077a70fdd6c72  vmovaps xmm9, [rsp+0x90]
000077a70fdd6c7b  vmovaps xmm11, [rsp+0xA0]
000077a70fdd6c84  vmovaps xmm12, [rsp+0xB0]
000077a70fdd6c8d  vmovaps xmm13, [rsp+0xC0]
000077a70fdd6c96  vmovaps xmm14, [rsp+0xD0]
000077a70fdd6c9f  vmovaps xmm15, [rsp+0xE0]
000077a70fdd6ca8  add rsp, 0xF0
000077a70fdd6caf  pop r11
000077a70fdd6cb1  pop r10
000077a70fdd6cb3  pop r9
000077a70fdd6cb5  pop r8
000077a70fdd6cb7  pop rsi
000077a70fdd6cb8  pop rdi
000077a70fdd6cb9  pop rdx
000077a70fdd6cba  pop rcx
000077a70fdd6cbb  pop rax
000077a70fdd6cbc  add rsp, 0x08
000077a70fdd6cc0  jmp 0x000077A70FDD5A06
000077a70fdd6cc5  sub rsp, 0x08
000077a70fdd6cc9  push rax
000077a70fdd6cca  push rcx
000077a70fdd6ccb  push rdx
000077a70fdd6ccc  push rdi
000077a70fdd6ccd  push rsi
000077a70fdd6cce  push r8
000077a70fdd6cd0  push r9
000077a70fdd6cd2  push r10
000077a70fdd6cd4  push r11
000077a70fdd6cd6  sub rsp, 0xF0
000077a70fdd6cdd  vmovaps [rsp], xmm0
000077a70fdd6ce2  vmovaps [rsp+0x10], xmm1
000077a70fdd6ce8  vmovaps [rsp+0x20], xmm2
000077a70fdd6cee  vmovaps [rsp+0x30], xmm3
000077a70fdd6cf4  vmovaps [rsp+0x40], xmm4
000077a70fdd6cfa  vmovaps [rsp+0x50], xmm5
000077a70fdd6d00  vmovaps [rsp+0x60], xmm7
000077a70fdd6d06  vmovaps [rsp+0x70], xmm8
000077a70fdd6d0c  vmovaps [rsp+0x80], xmm9
000077a70fdd6d15  vmovaps [rsp+0x90], xmm10
000077a70fdd6d1e  vmovaps [rsp+0xA0], xmm11
000077a70fdd6d27  vmovaps [rsp+0xB0], xmm12
000077a70fdd6d30  vmovaps [rsp+0xC0], xmm13
000077a70fdd6d39  vmovaps [rsp+0xD0], xmm14
000077a70fdd6d42  vmovaps [rsp+0xE0], xmm15
000077a70fdd6d4b  sub rsp, 0x30
000077a70fdd6d4f  movaps [rsp], xmm6
000077a70fdd6d53  movaps [rsp+0x10], xmm12
000077a70fdd6d59  movaps [rsp+0x20], xmm11
000077a70fdd6d5f  lea rdi, [rsp]
000077a70fdd6d63  mov esi, 0x00
000077a70fdd6d68  mov rax, 0x6294188EF530
000077a70fdd6d72  call rax
000077a70fdd6d74  movaps xmm6, [rsp]
000077a70fdd6d78  add rsp, 0x30
000077a70fdd6d7c  vmovaps xmm0, [rsp]
000077a70fdd6d81  vmovaps xmm1, [rsp+0x10]
000077a70fdd6d87  vmovaps xmm2, [rsp+0x20]
000077a70fdd6d8d  vmovaps xmm3, [rsp+0x30]
000077a70fdd6d93  vmovaps xmm4, [rsp+0x40]
000077a70fdd6d99  vmovaps xmm5, [rsp+0x50]
000077a70fdd6d9f  vmovaps xmm7, [rsp+0x60]
000077a70fdd6da5  vmovaps xmm8, [rsp+0x70]
000077a70fdd6dab  vmovaps xmm9, [rsp+0x80]
000077a70fdd6db4  vmovaps xmm10, [rsp+0x90]
000077a70fdd6dbd  vmovaps xmm11, [rsp+0xA0]
000077a70fdd6dc6  vmovaps xmm12, [rsp+0xB0]
000077a70fdd6dcf  vmovaps xmm13, [rsp+0xC0]
000077a70fdd6dd8  vmovaps xmm14, [rsp+0xD0]
000077a70fdd6de1  vmovaps xmm15, [rsp+0xE0]
000077a70fdd6dea  add rsp, 0xF0
000077a70fdd6df1  pop r11
000077a70fdd6df3  pop r10
000077a70fdd6df5  pop r9
000077a70fdd6df7  pop r8
000077a70fdd6df9  pop rsi
000077a70fdd6dfa  pop rdi
000077a70fdd6dfb  pop rdx
000077a70fdd6dfc  pop rcx
000077a70fdd6dfd  pop rax
000077a70fdd6dfe  add rsp, 0x08
000077a70fdd6e02  jmp 0x000077A70FDD5A27
000077a70fdd6e07  sub rsp, 0x08
000077a70fdd6e0b  push rax
000077a70fdd6e0c  push rcx
000077a70fdd6e0d  push rdx
000077a70fdd6e0e  push rdi
000077a70fdd6e0f  push rsi
000077a70fdd6e10  push r8
000077a70fdd6e12  push r9
000077a70fdd6e14  push r10
000077a70fdd6e16  push r11
000077a70fdd6e18  sub rsp, 0xF0
000077a70fdd6e1f  vmovaps [rsp], xmm0
000077a70fdd6e24  vmovaps [rsp+0x10], xmm1
000077a70fdd6e2a  vmovaps [rsp+0x20], xmm2
000077a70fdd6e30  vmovaps [rsp+0x30], xmm4
000077a70fdd6e36  vmovaps [rsp+0x40], xmm5
000077a70fdd6e3c  vmovaps [rsp+0x50], xmm6
000077a70fdd6e42  vmovaps [rsp+0x60], xmm7
000077a70fdd6e48  vmovaps [rsp+0x70], xmm8
000077a70fdd6e4e  vmovaps [rsp+0x80], xmm9
000077a70fdd6e57  vmovaps [rsp+0x90], xmm10
000077a70fdd6e60  vmovaps [rsp+0xA0], xmm11
000077a70fdd6e69  vmovaps [rsp+0xB0], xmm12
000077a70fdd6e72  vmovaps [rsp+0xC0], xmm13
000077a70fdd6e7b  vmovaps [rsp+0xD0], xmm14
000077a70fdd6e84  vmovaps [rsp+0xE0], xmm15
000077a70fdd6e8d  sub rsp, 0x30
000077a70fdd6e91  movaps [rsp], xmm3
000077a70fdd6e95  movaps [rsp+0x10], xmm5
000077a70fdd6e9a  movaps [rsp+0x20], xmm4
000077a70fdd6e9f  lea rdi, [rsp]
000077a70fdd6ea3  mov esi, 0x00
000077a70fdd6ea8  mov rax, 0x6294188EF530
000077a70fdd6eb2  call rax
000077a70fdd6eb4  movaps xmm3, [rsp]
000077a70fdd6eb8  add rsp, 0x30
000077a70fdd6ebc  vmovaps xmm0, [rsp]
000077a70fdd6ec1  vmovaps xmm1, [rsp+0x10]
000077a70fdd6ec7  vmovaps xmm2, [rsp+0x20]
000077a70fdd6ecd  vmovaps xmm4, [rsp+0x30]
000077a70fdd6ed3  vmovaps xmm5, [rsp+0x40]
000077a70fdd6ed9  vmovaps xmm6, [rsp+0x50]
000077a70fdd6edf  vmovaps xmm7, [rsp+0x60]
000077a70fdd6ee5  vmovaps xmm8, [rsp+0x70]
000077a70fdd6eeb  vmovaps xmm9, [rsp+0x80]
000077a70fdd6ef4  vmovaps xmm10, [rsp+0x90]
000077a70fdd6efd  vmovaps xmm11, [rsp+0xA0]
000077a70fdd6f06  vmovaps xmm12, [rsp+0xB0]
000077a70fdd6f0f  vmovaps xmm13, [rsp+0xC0]
000077a70fdd6f18  vmovaps xmm14, [rsp+0xD0]
000077a70fdd6f21  vmovaps xmm15, [rsp+0xE0]
000077a70fdd6f2a  add rsp, 0xF0
000077a70fdd6f31  pop r11
000077a70fdd6f33  pop r10
000077a70fdd6f35  pop r9
000077a70fdd6f37  pop r8
000077a70fdd6f39  pop rsi
000077a70fdd6f3a  pop rdi
000077a70fdd6f3b  pop rdx
000077a70fdd6f3c  pop rcx
000077a70fdd6f3d  pop rax
000077a70fdd6f3e  add rsp, 0x08
000077a70fdd6f42  jmp 0x000077A70FDD5A88
000077a70fdd6f47  sub rsp, 0x08
000077a70fdd6f4b  push rax
000077a70fdd6f4c  push rcx
000077a70fdd6f4d  push rdx
000077a70fdd6f4e  push rdi
000077a70fdd6f4f  push rsi
000077a70fdd6f50  push r8
000077a70fdd6f52  push r9
000077a70fdd6f54  push r10
000077a70fdd6f56  push r11
000077a70fdd6f58  sub rsp, 0xF0
000077a70fdd6f5f  vmovaps [rsp], xmm0
000077a70fdd6f64  vmovaps [rsp+0x10], xmm1
000077a70fdd6f6a  vmovaps [rsp+0x20], xmm2
000077a70fdd6f70  vmovaps [rsp+0x30], xmm3
000077a70fdd6f76  vmovaps [rsp+0x40], xmm4
000077a70fdd6f7c  vmovaps [rsp+0x50], xmm6
000077a70fdd6f82  vmovaps [rsp+0x60], xmm7
000077a70fdd6f88  vmovaps [rsp+0x70], xmm8
000077a70fdd6f8e  vmovaps [rsp+0x80], xmm9
000077a70fdd6f97  vmovaps [rsp+0x90], xmm10
000077a70fdd6fa0  vmovaps [rsp+0xA0], xmm11
000077a70fdd6fa9  vmovaps [rsp+0xB0], xmm12
000077a70fdd6fb2  vmovaps [rsp+0xC0], xmm13
000077a70fdd6fbb  vmovaps [rsp+0xD0], xmm14
000077a70fdd6fc4  vmovaps [rsp+0xE0], xmm15
000077a70fdd6fcd  sub rsp, 0x30
000077a70fdd6fd1  movaps [rsp], xmm5
000077a70fdd6fd5  movaps [rsp+0x10], xmm8
000077a70fdd6fdb  movaps [rsp+0x20], xmm15
000077a70fdd6fe1  lea rdi, [rsp]
000077a70fdd6fe5  mov esi, 0x00
000077a70fdd6fea  mov rax, 0x6294188EF530
000077a70fdd6ff4  call rax
000077a70fdd6ff6  movaps xmm5, [rsp]
000077a70fdd6ffa  add rsp, 0x30
000077a70fdd6ffe  vmovaps xmm0, [rsp]
000077a70fdd7003  vmovaps xmm1, [rsp+0x10]
000077a70fdd7009  vmovaps xmm2, [rsp+0x20]
000077a70fdd700f  vmovaps xmm3, [rsp+0x30]
000077a70fdd7015  vmovaps xmm4, [rsp+0x40]
000077a70fdd701b  vmovaps xmm6, [rsp+0x50]
000077a70fdd7021  vmovaps xmm7, [rsp+0x60]
000077a70fdd7027  vmovaps xmm8, [rsp+0x70]
000077a70fdd702d  vmovaps xmm9, [rsp+0x80]
000077a70fdd7036  vmovaps xmm10, [rsp+0x90]
000077a70fdd703f  vmovaps xmm11, [rsp+0xA0]
000077a70fdd7048  vmovaps xmm12, [rsp+0xB0]
000077a70fdd7051  vmovaps xmm13, [rsp+0xC0]
000077a70fdd705a  vmovaps xmm14, [rsp+0xD0]
000077a70fdd7063  vmovaps xmm15, [rsp+0xE0]
000077a70fdd706c  add rsp, 0xF0
000077a70fdd7073  pop r11
000077a70fdd7075  pop r10
000077a70fdd7077  pop r9
000077a70fdd7079  pop r8
000077a70fdd707b  pop rsi
000077a70fdd707c  pop rdi
000077a70fdd707d  pop rdx
000077a70fdd707e  pop rcx
000077a70fdd707f  pop rax
000077a70fdd7080  add rsp, 0x08
000077a70fdd7084  jmp 0x000077A70FDD5AC0
000077a70fdd7089  sub rsp, 0x08
000077a70fdd708d  push rax
000077a70fdd708e  push rcx
000077a70fdd708f  push rdx
000077a70fdd7090  push rdi
000077a70fdd7091  push rsi
000077a70fdd7092  push r8
000077a70fdd7094  push r9
000077a70fdd7096  push r10
000077a70fdd7098  push r11
000077a70fdd709a  sub rsp, 0xF0
000077a70fdd70a1  vmovaps [rsp], xmm0
000077a70fdd70a6  vmovaps [rsp+0x10], xmm1
000077a70fdd70ac  vmovaps [rsp+0x20], xmm2
000077a70fdd70b2  vmovaps [rsp+0x30], xmm3
000077a70fdd70b8  vmovaps [rsp+0x40], xmm5
000077a70fdd70be  vmovaps [rsp+0x50], xmm6
000077a70fdd70c4  vmovaps [rsp+0x60], xmm7
000077a70fdd70ca  vmovaps [rsp+0x70], xmm8
000077a70fdd70d0  vmovaps [rsp+0x80], xmm9
000077a70fdd70d9  vmovaps [rsp+0x90], xmm10
000077a70fdd70e2  vmovaps [rsp+0xA0], xmm11
000077a70fdd70eb  vmovaps [rsp+0xB0], xmm12
000077a70fdd70f4  vmovaps [rsp+0xC0], xmm13
000077a70fdd70fd  vmovaps [rsp+0xD0], xmm14
000077a70fdd7106  vmovaps [rsp+0xE0], xmm15
000077a70fdd710f  sub rsp, 0x30
000077a70fdd7113  movaps [rsp], xmm4
000077a70fdd7117  movaps [rsp+0x10], xmm9
000077a70fdd711d  movaps [rsp+0x20], xmm8
000077a70fdd7123  lea rdi, [rsp]
000077a70fdd7127  mov esi, 0x00
000077a70fdd712c  mov rax, 0x6294188EF530
000077a70fdd7136  call rax
000077a70fdd7138  movaps xmm4, [rsp]
000077a70fdd713c  add rsp, 0x30
000077a70fdd7140  vmovaps xmm0, [rsp]
000077a70fdd7145  vmovaps xmm1, [rsp+0x10]
000077a70fdd714b  vmovaps xmm2, [rsp+0x20]
000077a70fdd7151  vmovaps xmm3, [rsp+0x30]
000077a70fdd7157  vmovaps xmm5, [rsp+0x40]
000077a70fdd715d  vmovaps xmm6, [rsp+0x50]
000077a70fdd7163  vmovaps xmm7, [rsp+0x60]
000077a70fdd7169  vmovaps xmm8, [rsp+0x70]
000077a70fdd716f  vmovaps xmm9, [rsp+0x80]
000077a70fdd7178  vmovaps xmm10, [rsp+0x90]
000077a70fdd7181  vmovaps xmm11, [rsp+0xA0]
000077a70fdd718a  vmovaps xmm12, [rsp+0xB0]
000077a70fdd7193  vmovaps xmm13, [rsp+0xC0]
000077a70fdd719c  vmovaps xmm14, [rsp+0xD0]
000077a70fdd71a5  vmovaps xmm15, [rsp+0xE0]
000077a70fdd71ae  add rsp, 0xF0
000077a70fdd71b5  pop r11
000077a70fdd71b7  pop r10
000077a70fdd71b9  pop r9
000077a70fdd71bb  pop r8
000077a70fdd71bd  pop rsi
000077a70fdd71be  pop rdi
000077a70fdd71bf  pop rdx
000077a70fdd71c0  pop rcx
000077a70fdd71c1  pop rax
000077a70fdd71c2  add rsp, 0x08
000077a70fdd71c6  jmp 0x000077A70FDD5AE1
000077a70fdd71cb  sub rsp, 0x08
000077a70fdd71cf  push rax
000077a70fdd71d0  push rcx
000077a70fdd71d1  push rdx
000077a70fdd71d2  push rdi
000077a70fdd71d3  push rsi
000077a70fdd71d4  push r8
000077a70fdd71d6  push r9
000077a70fdd71d8  push r10
000077a70fdd71da  push r11
000077a70fdd71dc  sub rsp, 0xF0
000077a70fdd71e3  vmovaps [rsp], xmm0
000077a70fdd71e8  vmovaps [rsp+0x10], xmm1
000077a70fdd71ee  vmovaps [rsp+0x20], xmm2
000077a70fdd71f4  vmovaps [rsp+0x30], xmm3
000077a70fdd71fa  vmovaps [rsp+0x40], xmm4
000077a70fdd7200  vmovaps [rsp+0x50], xmm5
000077a70fdd7206  vmovaps [rsp+0x60], xmm6
000077a70fdd720c  vmovaps [rsp+0x70], xmm7
000077a70fdd7212  vmovaps [rsp+0x80], xmm8
000077a70fdd721b  vmovaps [rsp+0x90], xmm10
000077a70fdd7224  vmovaps [rsp+0xA0], xmm11
000077a70fdd722d  vmovaps [rsp+0xB0], xmm12
000077a70fdd7236  vmovaps [rsp+0xC0], xmm13
000077a70fdd723f  vmovaps [rsp+0xD0], xmm14
000077a70fdd7248  vmovaps [rsp+0xE0], xmm15
000077a70fdd7251  sub rsp, 0x30
000077a70fdd7255  movaps [rsp], xmm9
000077a70fdd725a  movaps [rsp+0x10], xmm10
000077a70fdd7260  movaps [rsp+0x20], xmm8
000077a70fdd7266  lea rdi, [rsp]
000077a70fdd726a  mov esi, 0x00
000077a70fdd726f  mov rax, 0x6294188EF530
000077a70fdd7279  call rax
000077a70fdd727b  movaps xmm9, [rsp]
000077a70fdd7280  add rsp, 0x30
000077a70fdd7284  vmovaps xmm0, [rsp]
000077a70fdd7289  vmovaps xmm1, [rsp+0x10]
000077a70fdd728f  vmovaps xmm2, [rsp+0x20]
000077a70fdd7295  vmovaps xmm3, [rsp+0x30]
000077a70fdd729b  vmovaps xmm4, [rsp+0x40]
000077a70fdd72a1  vmovaps xmm5, [rsp+0x50]
000077a70fdd72a7  vmovaps xmm6, [rsp+0x60]
000077a70fdd72ad  vmovaps xmm7, [rsp+0x70]
000077a70fdd72b3  vmovaps xmm8, [rsp+0x80]
000077a70fdd72bc  vmovaps xmm10, [rsp+0x90]
000077a70fdd72c5  vmovaps xmm11, [rsp+0xA0]
000077a70fdd72ce  vmovaps xmm12, [rsp+0xB0]
000077a70fdd72d7  vmovaps xmm13, [rsp+0xC0]
000077a70fdd72e0  vmovaps xmm14, [rsp+0xD0]
000077a70fdd72e9  vmovaps xmm15, [rsp+0xE0]
000077a70fdd72f2  add rsp, 0xF0
000077a70fdd72f9  pop r11
000077a70fdd72fb  pop r10
000077a70fdd72fd  pop r9
000077a70fdd72ff  pop r8
000077a70fdd7301  pop rsi
000077a70fdd7302  pop rdi
000077a70fdd7303  pop rdx
000077a70fdd7304  pop rcx
000077a70fdd7305  pop rax
000077a70fdd7306  add rsp, 0x08
000077a70fdd730a  jmp 0x000077A70FDD5AFB
000077a70fdd730f  call 0x000077A70FCD64F0
000077a70fdd7314  jmp 0x000077A70FDD5C15
000077a70fdd7319  call 0x000077A70FCD64F0
000077a70fdd731e  jmp 0x000077A70FDD5C2B
000077a70fdd7323  sub rsp, 0x08
000077a70fdd7327  push rax
000077a70fdd7328  push rcx
000077a70fdd7329  push rdx
000077a70fdd732a  push rdi
000077a70fdd732b  push rsi
000077a70fdd732c  push r8
000077a70fdd732e  push r9
000077a70fdd7330  push r10
000077a70fdd7332  push r11
000077a70fdd7334  sub rsp, 0xF0
000077a70fdd733b  vmovaps [rsp], xmm0
000077a70fdd7340  vmovaps [rsp+0x10], xmm2
000077a70fdd7346  vmovaps [rsp+0x20], xmm3
000077a70fdd734c  vmovaps [rsp+0x30], xmm4
000077a70fdd7352  vmovaps [rsp+0x40], xmm5
000077a70fdd7358  vmovaps [rsp+0x50], xmm6
000077a70fdd735e  vmovaps [rsp+0x60], xmm7
000077a70fdd7364  vmovaps [rsp+0x70], xmm8
000077a70fdd736a  vmovaps [rsp+0x80], xmm9
000077a70fdd7373  vmovaps [rsp+0x90], xmm10
000077a70fdd737c  vmovaps [rsp+0xA0], xmm11
000077a70fdd7385  vmovaps [rsp+0xB0], xmm12
000077a70fdd738e  vmovaps [rsp+0xC0], xmm13
000077a70fdd7397  vmovaps [rsp+0xD0], xmm14
000077a70fdd73a0  vmovaps [rsp+0xE0], xmm15
000077a70fdd73a9  sub rsp, 0x30
000077a70fdd73ad  movaps [rsp], xmm1
000077a70fdd73b1  movaps [rsp+0x10], xmm6
000077a70fdd73b6  movaps [rsp+0x20], xmm15
000077a70fdd73bc  lea rdi, [rsp]
000077a70fdd73c0  mov esi, 0x00
000077a70fdd73c5  mov rax, 0x6294188EF530
000077a70fdd73cf  call rax
000077a70fdd73d1  movaps xmm1, [rsp]
000077a70fdd73d5  add rsp, 0x30
000077a70fdd73d9  vmovaps xmm0, [rsp]
000077a70fdd73de  vmovaps xmm2, [rsp+0x10]
000077a70fdd73e4  vmovaps xmm3, [rsp+0x20]
000077a70fdd73ea  vmovaps xmm4, [rsp+0x30]
000077a70fdd73f0  vmovaps xmm5, [rsp+0x40]
000077a70fdd73f6  vmovaps xmm6, [rsp+0x50]
000077a70fdd73fc  vmovaps xmm7, [rsp+0x60]
000077a70fdd7402  vmovaps xmm8, [rsp+0x70]
000077a70fdd7408  vmovaps xmm9, [rsp+0x80]
000077a70fdd7411  vmovaps xmm10, [rsp+0x90]
000077a70fdd741a  vmovaps xmm11, [rsp+0xA0]
000077a70fdd7423  vmovaps xmm12, [rsp+0xB0]
000077a70fdd742c  vmovaps xmm13, [rsp+0xC0]
000077a70fdd7435  vmovaps xmm14, [rsp+0xD0]
000077a70fdd743e  vmovaps xmm15, [rsp+0xE0]
000077a70fdd7447  add rsp, 0xF0
000077a70fdd744e  pop r11
000077a70fdd7450  pop r10
000077a70fdd7452  pop r9
000077a70fdd7454  pop r8
000077a70fdd7456  pop rsi
000077a70fdd7457  pop rdi
000077a70fdd7458  pop rdx
000077a70fdd7459  pop rcx
000077a70fdd745a  pop rax
000077a70fdd745b  add rsp, 0x08
000077a70fdd745f  jmp 0x000077A70FDD5C68
000077a70fdd7464  call 0x000077A70FCE5820
000077a70fdd7469  jmp 0x000077A70FDD5C75
000077a70fdd746e  sub rsp, 0x08
000077a70fdd7472  push rax
000077a70fdd7473  push rcx
000077a70fdd7474  push rdx
000077a70fdd7475  push rdi
000077a70fdd7476  push rsi
000077a70fdd7477  push r8
000077a70fdd7479  push r9
000077a70fdd747b  push r10
000077a70fdd747d  push r11
000077a70fdd747f  sub rsp, 0xF0
000077a70fdd7486  vmovaps [rsp], xmm0
000077a70fdd748b  vmovaps [rsp+0x10], xmm1
000077a70fdd7491  vmovaps [rsp+0x20], xmm2
000077a70fdd7497  vmovaps [rsp+0x30], xmm3
000077a70fdd749d  vmovaps [rsp+0x40], xmm4
000077a70fdd74a3  vmovaps [rsp+0x50], xmm5
000077a70fdd74a9  vmovaps [rsp+0x60], xmm6
000077a70fdd74af  vmovaps [rsp+0x70], xmm7
000077a70fdd74b5  vmovaps [rsp+0x80], xmm8
000077a70fdd74be  vmovaps [rsp+0x90], xmm9
000077a70fdd74c7  vmovaps [rsp+0xA0], xmm10
000077a70fdd74d0  vmovaps [rsp+0xB0], xmm11
000077a70fdd74d9  vmovaps [rsp+0xC0], xmm12
000077a70fdd74e2  vmovaps [rsp+0xD0], xmm13
000077a70fdd74eb  vmovaps [rsp+0xE0], xmm15
000077a70fdd74f4  sub rsp, 0x30
000077a70fdd74f8  movaps [rsp], xmm14
000077a70fdd74fd  movaps [rsp+0x10], xmm4
000077a70fdd7502  movaps [rsp+0x20], xmm3
000077a70fdd7507  lea rdi, [rsp]
000077a70fdd750b  mov esi, 0x00
000077a70fdd7510  mov rax, 0x6294188EF530
000077a70fdd751a  call rax
000077a70fdd751c  movaps xmm14, [rsp]
000077a70fdd7521  add rsp, 0x30
000077a70fdd7525  vmovaps xmm0, [rsp]
000077a70fdd752a  vmovaps xmm1, [rsp+0x10]
000077a70fdd7530  vmovaps xmm2, [rsp+0x20]
000077a70fdd7536  vmovaps xmm3, [rsp+0x30]
000077a70fdd753c  vmovaps xmm4, [rsp+0x40]
000077a70fdd7542  vmovaps xmm5, [rsp+0x50]
000077a70fdd7548  vmovaps xmm6, [rsp+0x60]
000077a70fdd754e  vmovaps xmm7, [rsp+0x70]
000077a70fdd7554  vmovaps xmm8, [rsp+0x80]
000077a70fdd755d  vmovaps xmm9, [rsp+0x90]
000077a70fdd7566  vmovaps xmm10, [rsp+0xA0]
000077a70fdd756f  vmovaps xmm11, [rsp+0xB0]
000077a70fdd7578  vmovaps xmm12, [rsp+0xC0]
000077a70fdd7581  vmovaps xmm13, [rsp+0xD0]
000077a70fdd758a  vmovaps xmm15, [rsp+0xE0]
000077a70fdd7593  add rsp, 0xF0
000077a70fdd759a  pop r11
000077a70fdd759c  pop r10
000077a70fdd759e  pop r9
000077a70fdd75a0  pop r8
000077a70fdd75a2  pop rsi
000077a70fdd75a3  pop rdi
000077a70fdd75a4  pop rdx
000077a70fdd75a5  pop rcx
000077a70fdd75a6  pop rax
000077a70fdd75a7  add rsp, 0x08
000077a70fdd75ab  jmp 0x000077A70FDD5C8F
000077a70fdd75b0  sub rsp, 0x08
000077a70fdd75b4  push rax
000077a70fdd75b5  push rcx
000077a70fdd75b6  push rdx
000077a70fdd75b7  push rdi
000077a70fdd75b8  push rsi
000077a70fdd75b9  push r8
000077a70fdd75bb  push r9
000077a70fdd75bd  push r10
000077a70fdd75bf  push r11
000077a70fdd75c1  sub rsp, 0xF0
000077a70fdd75c8  vmovaps [rsp], xmm0
000077a70fdd75cd  vmovaps [rsp+0x10], xmm1
000077a70fdd75d3  vmovaps [rsp+0x20], xmm2
000077a70fdd75d9  vmovaps [rsp+0x30], xmm3
000077a70fdd75df  vmovaps [rsp+0x40], xmm4
000077a70fdd75e5  vmovaps [rsp+0x50], xmm5
000077a70fdd75eb  vmovaps [rsp+0x60], xmm7
000077a70fdd75f1  vmovaps [rsp+0x70], xmm8
000077a70fdd75f7  vmovaps [rsp+0x80], xmm9
000077a70fdd7600  vmovaps [rsp+0x90], xmm10
000077a70fdd7609  vmovaps [rsp+0xA0], xmm11
000077a70fdd7612  vmovaps [rsp+0xB0], xmm12
000077a70fdd761b  vmovaps [rsp+0xC0], xmm13
000077a70fdd7624  vmovaps [rsp+0xD0], xmm14
000077a70fdd762d  vmovaps [rsp+0xE0], xmm15
000077a70fdd7636  sub rsp, 0x30
000077a70fdd763a  movaps [rsp], xmm6
000077a70fdd763e  movaps [rsp+0x10], xmm9
000077a70fdd7644  movaps [rsp+0x20], xmm7
000077a70fdd7649  lea rdi, [rsp]
000077a70fdd764d  mov esi, 0x00
000077a70fdd7652  mov rax, 0x6294188EF530
000077a70fdd765c  call rax
000077a70fdd765e  movaps xmm6, [rsp]
000077a70fdd7662  add rsp, 0x30
000077a70fdd7666  vmovaps xmm0, [rsp]
000077a70fdd766b  vmovaps xmm1, [rsp+0x10]
000077a70fdd7671  vmovaps xmm2, [rsp+0x20]
000077a70fdd7677  vmovaps xmm3, [rsp+0x30]
000077a70fdd767d  vmovaps xmm4, [rsp+0x40]
000077a70fdd7683  vmovaps xmm5, [rsp+0x50]
000077a70fdd7689  vmovaps xmm7, [rsp+0x60]
000077a70fdd768f  vmovaps xmm8, [rsp+0x70]
000077a70fdd7695  vmovaps xmm9, [rsp+0x80]
000077a70fdd769e  vmovaps xmm10, [rsp+0x90]
000077a70fdd76a7  vmovaps xmm11, [rsp+0xA0]
000077a70fdd76b0  vmovaps xmm12, [rsp+0xB0]
000077a70fdd76b9  vmovaps xmm13, [rsp+0xC0]
000077a70fdd76c2  vmovaps xmm14, [rsp+0xD0]
000077a70fdd76cb  vmovaps xmm15, [rsp+0xE0]
000077a70fdd76d4  add rsp, 0xF0
000077a70fdd76db  pop r11
000077a70fdd76dd  pop r10
000077a70fdd76df  pop r9
000077a70fdd76e1  pop r8
000077a70fdd76e3  pop rsi
000077a70fdd76e4  pop rdi
000077a70fdd76e5  pop rdx
000077a70fdd76e6  pop rcx
000077a70fdd76e7  pop rax
000077a70fdd76e8  add rsp, 0x08
000077a70fdd76ec  jmp 0x000077A70FDD5CA7
000077a70fdd76f1  sub rsp, 0x08
000077a70fdd76f5  push rax
000077a70fdd76f6  push rcx
000077a70fdd76f7  push rdx
000077a70fdd76f8  push rdi
000077a70fdd76f9  push rsi
000077a70fdd76fa  push r8
000077a70fdd76fc  push r9
000077a70fdd76fe  push r10
000077a70fdd7700  push r11
000077a70fdd7702  sub rsp, 0xF0
000077a70fdd7709  vmovaps [rsp], xmm0
000077a70fdd770e  vmovaps [rsp+0x10], xmm1
000077a70fdd7714  vmovaps [rsp+0x20], xmm2
000077a70fdd771a  vmovaps [rsp+0x30], xmm3
000077a70fdd7720  vmovaps [rsp+0x40], xmm4
000077a70fdd7726  vmovaps [rsp+0x50], xmm5
000077a70fdd772c  vmovaps [rsp+0x60], xmm6
000077a70fdd7732  vmovaps [rsp+0x70], xmm8
000077a70fdd7738  vmovaps [rsp+0x80], xmm9
000077a70fdd7741  vmovaps [rsp+0x90], xmm10
000077a70fdd774a  vmovaps [rsp+0xA0], xmm11
000077a70fdd7753  vmovaps [rsp+0xB0], xmm12
000077a70fdd775c  vmovaps [rsp+0xC0], xmm13
000077a70fdd7765  vmovaps [rsp+0xD0], xmm14
000077a70fdd776e  vmovaps [rsp+0xE0], xmm15
000077a70fdd7777  sub rsp, 0x30
000077a70fdd777b  movaps [rsp], xmm7
000077a70fdd777f  movaps [rsp+0x10], xmm4
000077a70fdd7784  movaps [rsp+0x20], xmm9
000077a70fdd778a  lea rdi, [rsp]
000077a70fdd778e  mov esi, 0x00
000077a70fdd7793  mov rax, 0x6294188EF530
000077a70fdd779d  call rax
000077a70fdd779f  movaps xmm7, [rsp]
000077a70fdd77a3  add rsp, 0x30
000077a70fdd77a7  vmovaps xmm0, [rsp]
000077a70fdd77ac  vmovaps xmm1, [rsp+0x10]
000077a70fdd77b2  vmovaps xmm2, [rsp+0x20]
000077a70fdd77b8  vmovaps xmm3, [rsp+0x30]
000077a70fdd77be  vmovaps xmm4, [rsp+0x40]
000077a70fdd77c4  vmovaps xmm5, [rsp+0x50]
000077a70fdd77ca  vmovaps xmm6, [rsp+0x60]
000077a70fdd77d0  vmovaps xmm8, [rsp+0x70]
000077a70fdd77d6  vmovaps xmm9, [rsp+0x80]
000077a70fdd77df  vmovaps xmm10, [rsp+0x90]
000077a70fdd77e8  vmovaps xmm11, [rsp+0xA0]
000077a70fdd77f1  vmovaps xmm12, [rsp+0xB0]
000077a70fdd77fa  vmovaps xmm13, [rsp+0xC0]
000077a70fdd7803  vmovaps xmm14, [rsp+0xD0]
000077a70fdd780c  vmovaps xmm15, [rsp+0xE0]
000077a70fdd7815  add rsp, 0xF0
000077a70fdd781c  pop r11
000077a70fdd781e  pop r10
000077a70fdd7820  pop r9
000077a70fdd7822  pop r8
000077a70fdd7824  pop rsi
000077a70fdd7825  pop rdi
000077a70fdd7826  pop rdx
000077a70fdd7827  pop rcx
000077a70fdd7828  pop rax
000077a70fdd7829  add rsp, 0x08
000077a70fdd782d  jmp 0x000077A70FDD5CD4
000077a70fdd7832  sub rsp, 0x08
000077a70fdd7836  push rax
000077a70fdd7837  push rcx
000077a70fdd7838  push rdx
000077a70fdd7839  push rdi
000077a70fdd783a  push rsi
000077a70fdd783b  push r8
000077a70fdd783d  push r9
000077a70fdd783f  push r10
000077a70fdd7841  push r11
000077a70fdd7843  sub rsp, 0xF0
000077a70fdd784a  vmovaps [rsp], xmm0
000077a70fdd784f  vmovaps [rsp+0x10], xmm1
000077a70fdd7855  vmovaps [rsp+0x20], xmm2
000077a70fdd785b  vmovaps [rsp+0x30], xmm3
000077a70fdd7861  vmovaps [rsp+0x40], xmm5
000077a70fdd7867  vmovaps [rsp+0x50], xmm6
000077a70fdd786d  vmovaps [rsp+0x60], xmm7
000077a70fdd7873  vmovaps [rsp+0x70], xmm8
000077a70fdd7879  vmovaps [rsp+0x80], xmm9
000077a70fdd7882  vmovaps [rsp+0x90], xmm10
000077a70fdd788b  vmovaps [rsp+0xA0], xmm11
000077a70fdd7894  vmovaps [rsp+0xB0], xmm12
000077a70fdd789d  vmovaps [rsp+0xC0], xmm13
000077a70fdd78a6  vmovaps [rsp+0xD0], xmm14
000077a70fdd78af  vmovaps [rsp+0xE0], xmm15
000077a70fdd78b8  sub rsp, 0x30
000077a70fdd78bc  movaps [rsp], xmm4
000077a70fdd78c0  movaps [rsp+0x10], xmm15
000077a70fdd78c6  movaps [rsp+0x20], xmm9
000077a70fdd78cc  lea rdi, [rsp]
000077a70fdd78d0  mov esi, 0x00
000077a70fdd78d5  mov rax, 0x6294188EF530
000077a70fdd78df  call rax
000077a70fdd78e1  movaps xmm4, [rsp]
000077a70fdd78e5  add rsp, 0x30
000077a70fdd78e9  vmovaps xmm0, [rsp]
000077a70fdd78ee  vmovaps xmm1, [rsp+0x10]
000077a70fdd78f4  vmovaps xmm2, [rsp+0x20]
000077a70fdd78fa  vmovaps xmm3, [rsp+0x30]
000077a70fdd7900  vmovaps xmm5, [rsp+0x40]
000077a70fdd7906  vmovaps xmm6, [rsp+0x50]
000077a70fdd790c  vmovaps xmm7, [rsp+0x60]
000077a70fdd7912  vmovaps xmm8, [rsp+0x70]
000077a70fdd7918  vmovaps xmm9, [rsp+0x80]
000077a70fdd7921  vmovaps xmm10, [rsp+0x90]
000077a70fdd792a  vmovaps xmm11, [rsp+0xA0]
000077a70fdd7933  vmovaps xmm12, [rsp+0xB0]
000077a70fdd793c  vmovaps xmm13, [rsp+0xC0]
000077a70fdd7945  vmovaps xmm14, [rsp+0xD0]
000077a70fdd794e  vmovaps xmm15, [rsp+0xE0]
000077a70fdd7957  add rsp, 0xF0
000077a70fdd795e  pop r11
000077a70fdd7960  pop r10
000077a70fdd7962  pop r9
000077a70fdd7964  pop r8
000077a70fdd7966  pop rsi
000077a70fdd7967  pop rdi
000077a70fdd7968  pop rdx
000077a70fdd7969  pop rcx
000077a70fdd796a  pop rax
000077a70fdd796b  add rsp, 0x08
000077a70fdd796f  jmp 0x000077A70FDD5CF9
000077a70fdd7974  call 0x000077A70FCE5820
000077a70fdd7979  jmp 0x000077A70FDD5D06
000077a70fdd797e  sub rsp, 0x08
000077a70fdd7982  push rax
000077a70fdd7983  push rcx
000077a70fdd7984  push rdx
000077a70fdd7985  push rdi
000077a70fdd7986  push rsi
000077a70fdd7987  push r8
000077a70fdd7989  push r9
000077a70fdd798b  push r10
000077a70fdd798d  push r11
000077a70fdd798f  sub rsp, 0xF0
000077a70fdd7996  vmovaps [rsp], xmm0
000077a70fdd799b  vmovaps [rsp+0x10], xmm1
000077a70fdd79a1  vmovaps [rsp+0x20], xmm2
000077a70fdd79a7  vmovaps [rsp+0x30], xmm4
000077a70fdd79ad  vmovaps [rsp+0x40], xmm5
000077a70fdd79b3  vmovaps [rsp+0x50], xmm6
000077a70fdd79b9  vmovaps [rsp+0x60], xmm7
000077a70fdd79bf  vmovaps [rsp+0x70], xmm8
000077a70fdd79c5  vmovaps [rsp+0x80], xmm9
000077a70fdd79ce  vmovaps [rsp+0x90], xmm10
000077a70fdd79d7  vmovaps [rsp+0xA0], xmm11
000077a70fdd79e0  vmovaps [rsp+0xB0], xmm12
000077a70fdd79e9  vmovaps [rsp+0xC0], xmm13
000077a70fdd79f2  vmovaps [rsp+0xD0], xmm14
000077a70fdd79fb  vmovaps [rsp+0xE0], xmm15
000077a70fdd7a04  sub rsp, 0x30
000077a70fdd7a08  movaps [rsp], xmm3
000077a70fdd7a0c  movaps [rsp+0x10], xmm1
000077a70fdd7a11  movaps [rsp+0x20], xmm9
000077a70fdd7a17  lea rdi, [rsp]
000077a70fdd7a1b  mov esi, 0x00
000077a70fdd7a20  mov rax, 0x6294188EF530
000077a70fdd7a2a  call rax
000077a70fdd7a2c  movaps xmm3, [rsp]
000077a70fdd7a30  add rsp, 0x30
000077a70fdd7a34  vmovaps xmm0, [rsp]
000077a70fdd7a39  vmovaps xmm1, [rsp+0x10]
000077a70fdd7a3f  vmovaps xmm2, [rsp+0x20]
000077a70fdd7a45  vmovaps xmm4, [rsp+0x30]
000077a70fdd7a4b  vmovaps xmm5, [rsp+0x40]
000077a70fdd7a51  vmovaps xmm6, [rsp+0x50]
000077a70fdd7a57  vmovaps xmm7, [rsp+0x60]
000077a70fdd7a5d  vmovaps xmm8, [rsp+0x70]
000077a70fdd7a63  vmovaps xmm9, [rsp+0x80]
000077a70fdd7a6c  vmovaps xmm10, [rsp+0x90]
000077a70fdd7a75  vmovaps xmm11, [rsp+0xA0]
000077a70fdd7a7e  vmovaps xmm12, [rsp+0xB0]
000077a70fdd7a87  vmovaps xmm13, [rsp+0xC0]
000077a70fdd7a90  vmovaps xmm14, [rsp+0xD0]
000077a70fdd7a99  vmovaps xmm15, [rsp+0xE0]
000077a70fdd7aa2  add rsp, 0xF0
000077a70fdd7aa9  pop r11
000077a70fdd7aab  pop r10
000077a70fdd7aad  pop r9
000077a70fdd7aaf  pop r8
000077a70fdd7ab1  pop rsi
000077a70fdd7ab2  pop rdi
000077a70fdd7ab3  pop rdx
000077a70fdd7ab4  pop rcx
000077a70fdd7ab5  pop rax
000077a70fdd7ab6  add rsp, 0x08
000077a70fdd7aba  jmp 0x000077A70FDD5D43
000077a70fdd7abf  sub rsp, 0x08
000077a70fdd7ac3  push rax
000077a70fdd7ac4  push rcx
000077a70fdd7ac5  push rdx
000077a70fdd7ac6  push rdi
000077a70fdd7ac7  push rsi
000077a70fdd7ac8  push r8
000077a70fdd7aca  push r9
000077a70fdd7acc  push r10
000077a70fdd7ace  push r11
000077a70fdd7ad0  sub rsp, 0xF0
000077a70fdd7ad7  vmovaps [rsp], xmm0
000077a70fdd7adc  vmovaps [rsp+0x10], xmm2
000077a70fdd7ae2  vmovaps [rsp+0x20], xmm3
000077a70fdd7ae8  vmovaps [rsp+0x30], xmm4
000077a70fdd7aee  vmovaps [rsp+0x40], xmm5
000077a70fdd7af4  vmovaps [rsp+0x50], xmm6
000077a70fdd7afa  vmovaps [rsp+0x60], xmm7
000077a70fdd7b00  vmovaps [rsp+0x70], xmm8
000077a70fdd7b06  vmovaps [rsp+0x80], xmm9
000077a70fdd7b0f  vmovaps [rsp+0x90], xmm10
000077a70fdd7b18  vmovaps [rsp+0xA0], xmm11
000077a70fdd7b21  vmovaps [rsp+0xB0], xmm12
000077a70fdd7b2a  vmovaps [rsp+0xC0], xmm13
000077a70fdd7b33  vmovaps [rsp+0xD0], xmm14
000077a70fdd7b3c  vmovaps [rsp+0xE0], xmm15
000077a70fdd7b45  sub rsp, 0x30
000077a70fdd7b49  movaps [rsp], xmm1
000077a70fdd7b4d  movaps [rsp+0x10], xmm15
000077a70fdd7b53  movaps [rsp+0x20], xmm9
000077a70fdd7b59  lea rdi, [rsp]
000077a70fdd7b5d  mov esi, 0x00
000077a70fdd7b62  mov rax, 0x6294188EF530
000077a70fdd7b6c  call rax
000077a70fdd7b6e  movaps xmm1, [rsp]
000077a70fdd7b72  add rsp, 0x30
000077a70fdd7b76  vmovaps xmm0, [rsp]
000077a70fdd7b7b  vmovaps xmm2, [rsp+0x10]
000077a70fdd7b81  vmovaps xmm3, [rsp+0x20]
000077a70fdd7b87  vmovaps xmm4, [rsp+0x30]
000077a70fdd7b8d  vmovaps xmm5, [rsp+0x40]
000077a70fdd7b93  vmovaps xmm6, [rsp+0x50]
000077a70fdd7b99  vmovaps xmm7, [rsp+0x60]
000077a70fdd7b9f  vmovaps xmm8, [rsp+0x70]
000077a70fdd7ba5  vmovaps xmm9, [rsp+0x80]
000077a70fdd7bae  vmovaps xmm10, [rsp+0x90]
000077a70fdd7bb7  vmovaps xmm11, [rsp+0xA0]
000077a70fdd7bc0  vmovaps xmm12, [rsp+0xB0]
000077a70fdd7bc9  vmovaps xmm13, [rsp+0xC0]
000077a70fdd7bd2  vmovaps xmm14, [rsp+0xD0]
000077a70fdd7bdb  vmovaps xmm15, [rsp+0xE0]
000077a70fdd7be4  add rsp, 0xF0
000077a70fdd7beb  pop r11
000077a70fdd7bed  pop r10
000077a70fdd7bef  pop r9
000077a70fdd7bf1  pop r8
000077a70fdd7bf3  pop rsi
000077a70fdd7bf4  pop rdi
000077a70fdd7bf5  pop rdx
000077a70fdd7bf6  pop rcx
000077a70fdd7bf7  pop rax
000077a70fdd7bf8  add rsp, 0x08
000077a70fdd7bfc  jmp 0x000077A70FDD5DCB
000077a70fdd7c01  call 0x000077A70FCE5820
000077a70fdd7c06  jmp 0x000077A70FDD5DD8
000077a70fdd7c0b  sub rsp, 0x08
000077a70fdd7c0f  push rax
000077a70fdd7c10  push rcx
000077a70fdd7c11  push rdx
000077a70fdd7c12  push rdi
000077a70fdd7c13  push rsi
000077a70fdd7c14  push r8
000077a70fdd7c16  push r9
000077a70fdd7c18  push r10
000077a70fdd7c1a  push r11
000077a70fdd7c1c  sub rsp, 0xF0
000077a70fdd7c23  vmovaps [rsp], xmm0
000077a70fdd7c28  vmovaps [rsp+0x10], xmm2
000077a70fdd7c2e  vmovaps [rsp+0x20], xmm3
000077a70fdd7c34  vmovaps [rsp+0x30], xmm4
000077a70fdd7c3a  vmovaps [rsp+0x40], xmm5
000077a70fdd7c40  vmovaps [rsp+0x50], xmm6
000077a70fdd7c46  vmovaps [rsp+0x60], xmm7
000077a70fdd7c4c  vmovaps [rsp+0x70], xmm8
000077a70fdd7c52  vmovaps [rsp+0x80], xmm9
000077a70fdd7c5b  vmovaps [rsp+0x90], xmm10
000077a70fdd7c64  vmovaps [rsp+0xA0], xmm11
000077a70fdd7c6d  vmovaps [rsp+0xB0], xmm12
000077a70fdd7c76  vmovaps [rsp+0xC0], xmm13
000077a70fdd7c7f  vmovaps [rsp+0xD0], xmm14
000077a70fdd7c88  vmovaps [rsp+0xE0], xmm15
000077a70fdd7c91  sub rsp, 0x30
000077a70fdd7c95  movaps [rsp], xmm1
000077a70fdd7c99  movaps [rsp+0x10], xmm5
000077a70fdd7c9e  movaps [rsp+0x20], xmm7
000077a70fdd7ca3  lea rdi, [rsp]
000077a70fdd7ca7  mov esi, 0x00
000077a70fdd7cac  mov rax, 0x6294188EF530
000077a70fdd7cb6  call rax
000077a70fdd7cb8  movaps xmm1, [rsp]
000077a70fdd7cbc  add rsp, 0x30
000077a70fdd7cc0  vmovaps xmm0, [rsp]
000077a70fdd7cc5  vmovaps xmm2, [rsp+0x10]
000077a70fdd7ccb  vmovaps xmm3, [rsp+0x20]
000077a70fdd7cd1  vmovaps xmm4, [rsp+0x30]
000077a70fdd7cd7  vmovaps xmm5, [rsp+0x40]
000077a70fdd7cdd  vmovaps xmm6, [rsp+0x50]
000077a70fdd7ce3  vmovaps xmm7, [rsp+0x60]
000077a70fdd7ce9  vmovaps xmm8, [rsp+0x70]
000077a70fdd7cef  vmovaps xmm9, [rsp+0x80]
000077a70fdd7cf8  vmovaps xmm10, [rsp+0x90]
000077a70fdd7d01  vmovaps xmm11, [rsp+0xA0]
000077a70fdd7d0a  vmovaps xmm12, [rsp+0xB0]
000077a70fdd7d13  vmovaps xmm13, [rsp+0xC0]
000077a70fdd7d1c  vmovaps xmm14, [rsp+0xD0]
000077a70fdd7d25  vmovaps xmm15, [rsp+0xE0]
000077a70fdd7d2e  add rsp, 0xF0
000077a70fdd7d35  pop r11
000077a70fdd7d37  pop r10
000077a70fdd7d39  pop r9
000077a70fdd7d3b  pop r8
000077a70fdd7d3d  pop rsi
000077a70fdd7d3e  pop rdi
000077a70fdd7d3f  pop rdx
000077a70fdd7d40  pop rcx
000077a70fdd7d41  pop rax
000077a70fdd7d42  add rsp, 0x08
000077a70fdd7d46  jmp 0x000077A70FDD5E7D
000077a70fdd7d4b  sub rsp, 0x08
000077a70fdd7d4f  push rax
000077a70fdd7d50  push rcx
000077a70fdd7d51  push rdx
000077a70fdd7d52  push rdi
000077a70fdd7d53  push rsi
000077a70fdd7d54  push r8
000077a70fdd7d56  push r9
000077a70fdd7d58  push r10
000077a70fdd7d5a  push r11
000077a70fdd7d5c  sub rsp, 0xF0
000077a70fdd7d63  vmovaps [rsp], xmm0
000077a70fdd7d68  vmovaps [rsp+0x10], xmm1
000077a70fdd7d6e  vmovaps [rsp+0x20], xmm2
000077a70fdd7d74  vmovaps [rsp+0x30], xmm3
000077a70fdd7d7a  vmovaps [rsp+0x40], xmm4
000077a70fdd7d80  vmovaps [rsp+0x50], xmm5
000077a70fdd7d86  vmovaps [rsp+0x60], xmm6
000077a70fdd7d8c  vmovaps [rsp+0x70], xmm8
000077a70fdd7d92  vmovaps [rsp+0x80], xmm9
000077a70fdd7d9b  vmovaps [rsp+0x90], xmm10
000077a70fdd7da4  vmovaps [rsp+0xA0], xmm11
000077a70fdd7dad  vmovaps [rsp+0xB0], xmm12
000077a70fdd7db6  vmovaps [rsp+0xC0], xmm13
000077a70fdd7dbf  vmovaps [rsp+0xD0], xmm14
000077a70fdd7dc8  vmovaps [rsp+0xE0], xmm15
000077a70fdd7dd1  sub rsp, 0x30
000077a70fdd7dd5  movaps [rsp], xmm7
000077a70fdd7dd9  movaps [rsp+0x10], xmm5
000077a70fdd7dde  movaps [rsp+0x20], xmm15
000077a70fdd7de4  lea rdi, [rsp]
000077a70fdd7de8  mov esi, 0x00
000077a70fdd7ded  mov rax, 0x6294188EF530
000077a70fdd7df7  call rax
000077a70fdd7df9  movaps xmm7, [rsp]
000077a70fdd7dfd  add rsp, 0x30
000077a70fdd7e01  vmovaps xmm0, [rsp]
000077a70fdd7e06  vmovaps xmm1, [rsp+0x10]
000077a70fdd7e0c  vmovaps xmm2, [rsp+0x20]
000077a70fdd7e12  vmovaps xmm3, [rsp+0x30]
000077a70fdd7e18  vmovaps xmm4, [rsp+0x40]
000077a70fdd7e1e  vmovaps xmm5, [rsp+0x50]
000077a70fdd7e24  vmovaps xmm6, [rsp+0x60]
000077a70fdd7e2a  vmovaps xmm8, [rsp+0x70]
000077a70fdd7e30  vmovaps xmm9, [rsp+0x80]
000077a70fdd7e39  vmovaps xmm10, [rsp+0x90]
000077a70fdd7e42  vmovaps xmm11, [rsp+0xA0]
000077a70fdd7e4b  vmovaps xmm12, [rsp+0xB0]
000077a70fdd7e54  vmovaps xmm13, [rsp+0xC0]
000077a70fdd7e5d  vmovaps xmm14, [rsp+0xD0]
000077a70fdd7e66  vmovaps xmm15, [rsp+0xE0]
000077a70fdd7e6f  add rsp, 0xF0
000077a70fdd7e76  pop r11
000077a70fdd7e78  pop r10
000077a70fdd7e7a  pop r9
000077a70fdd7e7c  pop r8
000077a70fdd7e7e  pop rsi
000077a70fdd7e7f  pop rdi
000077a70fdd7e80  pop rdx
000077a70fdd7e81  pop rcx
000077a70fdd7e82  pop rax
000077a70fdd7e83  add rsp, 0x08
000077a70fdd7e87  jmp 0x000077A70FDD5EB3
000077a70fdd7e8c  call 0x000077A70FCD64F0
000077a70fdd7e91  jmp 0x000077A70FDD5EC0
000077a70fdd7e96  sub rsp, 0x08
000077a70fdd7e9a  push rax
000077a70fdd7e9b  push rcx
000077a70fdd7e9c  push rdx
000077a70fdd7e9d  push rdi
000077a70fdd7e9e  push rsi
000077a70fdd7e9f  push r8
000077a70fdd7ea1  push r9
000077a70fdd7ea3  push r10
000077a70fdd7ea5  push r11
000077a70fdd7ea7  sub rsp, 0xF0
000077a70fdd7eae  vmovaps [rsp], xmm0
000077a70fdd7eb3  vmovaps [rsp+0x10], xmm1
000077a70fdd7eb9  vmovaps [rsp+0x20], xmm2
000077a70fdd7ebf  vmovaps [rsp+0x30], xmm3
000077a70fdd7ec5  vmovaps [rsp+0x40], xmm4
000077a70fdd7ecb  vmovaps [rsp+0x50], xmm5
000077a70fdd7ed1  vmovaps [rsp+0x60], xmm6
000077a70fdd7ed7  vmovaps [rsp+0x70], xmm7
000077a70fdd7edd  vmovaps [rsp+0x80], xmm8
000077a70fdd7ee6  vmovaps [rsp+0x90], xmm9
000077a70fdd7eef  vmovaps [rsp+0xA0], xmm10
000077a70fdd7ef8  vmovaps [rsp+0xB0], xmm11
000077a70fdd7f01  vmovaps [rsp+0xC0], xmm12
000077a70fdd7f0a  vmovaps [rsp+0xD0], xmm13
000077a70fdd7f13  vmovaps [rsp+0xE0], xmm14
000077a70fdd7f1c  sub rsp, 0x30
000077a70fdd7f20  movaps [rsp], xmm15
000077a70fdd7f25  movaps [rsp+0x10], xmm5
000077a70fdd7f2a  movaps [rsp+0x20], xmm3
000077a70fdd7f2f  lea rdi, [rsp]
000077a70fdd7f33  mov esi, 0x00
000077a70fdd7f38  mov rax, 0x6294188EF530
000077a70fdd7f42  call rax
000077a70fdd7f44  movaps xmm15, [rsp]
000077a70fdd7f49  add rsp, 0x30
000077a70fdd7f4d  vmovaps xmm0, [rsp]
000077a70fdd7f52  vmovaps xmm1, [rsp+0x10]
000077a70fdd7f58  vmovaps xmm2, [rsp+0x20]
000077a70fdd7f5e  vmovaps xmm3, [rsp+0x30]
000077a70fdd7f64  vmovaps xmm4, [rsp+0x40]
000077a70fdd7f6a  vmovaps xmm5, [rsp+0x50]
000077a70fdd7f70  vmovaps xmm6, [rsp+0x60]
000077a70fdd7f76  vmovaps xmm7, [rsp+0x70]
000077a70fdd7f7c  vmovaps xmm8, [rsp+0x80]
000077a70fdd7f85  vmovaps xmm9, [rsp+0x90]
000077a70fdd7f8e  vmovaps xmm10, [rsp+0xA0]
000077a70fdd7f97  vmovaps xmm11, [rsp+0xB0]
000077a70fdd7fa0  vmovaps xmm12, [rsp+0xC0]
000077a70fdd7fa9  vmovaps xmm13, [rsp+0xD0]
000077a70fdd7fb2  vmovaps xmm14, [rsp+0xE0]
000077a70fdd7fbb  add rsp, 0xF0
000077a70fdd7fc2  pop r11
000077a70fdd7fc4  pop r10
000077a70fdd7fc6  pop r9
000077a70fdd7fc8  pop r8
000077a70fdd7fca  pop rsi
000077a70fdd7fcb  pop rdi
000077a70fdd7fcc  pop rdx
000077a70fdd7fcd  pop rcx
000077a70fdd7fce  pop rax
000077a70fdd7fcf  add rsp, 0x08
000077a70fdd7fd3  jmp 0x000077A70FDD5EE6
000077a70fdd7fd8  sub rsp, 0x08
000077a70fdd7fdc  push rax
000077a70fdd7fdd  push rcx
000077a70fdd7fde  push rdx
000077a70fdd7fdf  push rdi
000077a70fdd7fe0  push rsi
000077a70fdd7fe1  push r8
000077a70fdd7fe3  push r9
000077a70fdd7fe5  push r10
000077a70fdd7fe7  push r11
000077a70fdd7fe9  sub rsp, 0xF0
000077a70fdd7ff0  vmovaps [rsp], xmm0
000077a70fdd7ff5  vmovaps [rsp+0x10], xmm2
000077a70fdd7ffb  vmovaps [rsp+0x20], xmm3
000077a70fdd8001  vmovaps [rsp+0x30], xmm4
000077a70fdd8007  vmovaps [rsp+0x40], xmm5
000077a70fdd800d  vmovaps [rsp+0x50], xmm6
000077a70fdd8013  vmovaps [rsp+0x60], xmm7
000077a70fdd8019  vmovaps [rsp+0x70], xmm8
000077a70fdd801f  vmovaps [rsp+0x80], xmm9
000077a70fdd8028  vmovaps [rsp+0x90], xmm10
000077a70fdd8031  vmovaps [rsp+0xA0], xmm11
000077a70fdd803a  vmovaps [rsp+0xB0], xmm12
000077a70fdd8043  vmovaps [rsp+0xC0], xmm13
000077a70fdd804c  vmovaps [rsp+0xD0], xmm14
000077a70fdd8055  vmovaps [rsp+0xE0], xmm15
000077a70fdd805e  sub rsp, 0x30
000077a70fdd8062  movaps [rsp], xmm1
000077a70fdd8066  movaps [rsp+0x10], xmm5
000077a70fdd806b  movaps [rsp+0x20], xmm4
000077a70fdd8070  lea rdi, [rsp]
000077a70fdd8074  mov esi, 0x00
000077a70fdd8079  mov rax, 0x6294188EF530
000077a70fdd8083  call rax
000077a70fdd8085  movaps xmm1, [rsp]
000077a70fdd8089  add rsp, 0x30
000077a70fdd808d  vmovaps xmm0, [rsp]
000077a70fdd8092  vmovaps xmm2, [rsp+0x10]
000077a70fdd8098  vmovaps xmm3, [rsp+0x20]
000077a70fdd809e  vmovaps xmm4, [rsp+0x30]
000077a70fdd80a4  vmovaps xmm5, [rsp+0x40]
000077a70fdd80aa  vmovaps xmm6, [rsp+0x50]
000077a70fdd80b0  vmovaps xmm7, [rsp+0x60]
000077a70fdd80b6  vmovaps xmm8, [rsp+0x70]
000077a70fdd80bc  vmovaps xmm9, [rsp+0x80]
000077a70fdd80c5  vmovaps xmm10, [rsp+0x90]
000077a70fdd80ce  vmovaps xmm11, [rsp+0xA0]
000077a70fdd80d7  vmovaps xmm12, [rsp+0xB0]
000077a70fdd80e0  vmovaps xmm13, [rsp+0xC0]
000077a70fdd80e9  vmovaps xmm14, [rsp+0xD0]
000077a70fdd80f2  vmovaps xmm15, [rsp+0xE0]
000077a70fdd80fb  add rsp, 0xF0
000077a70fdd8102  pop r11
000077a70fdd8104  pop r10
000077a70fdd8106  pop r9
000077a70fdd8108  pop r8
000077a70fdd810a  pop rsi
000077a70fdd810b  pop rdi
000077a70fdd810c  pop rdx
000077a70fdd810d  pop rcx
000077a70fdd810e  pop rax
000077a70fdd810f  add rsp, 0x08
000077a70fdd8113  jmp 0x000077A70FDD5F06
000077a70fdd8118  sub rsp, 0x08
000077a70fdd811c  push rax
000077a70fdd811d  push rcx
000077a70fdd811e  push rdx
000077a70fdd811f  push rdi
000077a70fdd8120  push rsi
000077a70fdd8121  push r8
000077a70fdd8123  push r9
000077a70fdd8125  push r10
000077a70fdd8127  push r11
000077a70fdd8129  sub rsp, 0xF0
000077a70fdd8130  vmovaps [rsp], xmm0
000077a70fdd8135  vmovaps [rsp+0x10], xmm1
000077a70fdd813b  vmovaps [rsp+0x20], xmm2
000077a70fdd8141  vmovaps [rsp+0x30], xmm3
000077a70fdd8147  vmovaps [rsp+0x40], xmm5
000077a70fdd814d  vmovaps [rsp+0x50], xmm6
000077a70fdd8153  vmovaps [rsp+0x60], xmm7
000077a70fdd8159  vmovaps [rsp+0x70], xmm8
000077a70fdd815f  vmovaps [rsp+0x80], xmm9
000077a70fdd8168  vmovaps [rsp+0x90], xmm10
000077a70fdd8171  vmovaps [rsp+0xA0], xmm11
000077a70fdd817a  vmovaps [rsp+0xB0], xmm12
000077a70fdd8183  vmovaps [rsp+0xC0], xmm13
000077a70fdd818c  vmovaps [rsp+0xD0], xmm14
000077a70fdd8195  vmovaps [rsp+0xE0], xmm15
000077a70fdd819e  sub rsp, 0x30
000077a70fdd81a2  movaps [rsp], xmm4
000077a70fdd81a6  movaps [rsp+0x10], xmm3
000077a70fdd81ab  movaps [rsp+0x20], xmm5
000077a70fdd81b0  lea rdi, [rsp]
000077a70fdd81b4  mov esi, 0x00
000077a70fdd81b9  mov rax, 0x6294188EF530
000077a70fdd81c3  call rax
000077a70fdd81c5  movaps xmm4, [rsp]
000077a70fdd81c9  add rsp, 0x30
000077a70fdd81cd  vmovaps xmm0, [rsp]
000077a70fdd81d2  vmovaps xmm1, [rsp+0x10]
000077a70fdd81d8  vmovaps xmm2, [rsp+0x20]
000077a70fdd81de  vmovaps xmm3, [rsp+0x30]
000077a70fdd81e4  vmovaps xmm5, [rsp+0x40]
000077a70fdd81ea  vmovaps xmm6, [rsp+0x50]
000077a70fdd81f0  vmovaps xmm7, [rsp+0x60]
000077a70fdd81f6  vmovaps xmm8, [rsp+0x70]
000077a70fdd81fc  vmovaps xmm9, [rsp+0x80]
000077a70fdd8205  vmovaps xmm10, [rsp+0x90]
000077a70fdd820e  vmovaps xmm11, [rsp+0xA0]
000077a70fdd8217  vmovaps xmm12, [rsp+0xB0]
000077a70fdd8220  vmovaps xmm13, [rsp+0xC0]
000077a70fdd8229  vmovaps xmm14, [rsp+0xD0]
000077a70fdd8232  vmovaps xmm15, [rsp+0xE0]
000077a70fdd823b  add rsp, 0xF0
000077a70fdd8242  pop r11
000077a70fdd8244  pop r10
000077a70fdd8246  pop r9
000077a70fdd8248  pop r8
000077a70fdd824a  pop rsi
000077a70fdd824b  pop rdi
000077a70fdd824c  pop rdx
000077a70fdd824d  pop rcx
000077a70fdd824e  pop rax
000077a70fdd824f  add rsp, 0x08
000077a70fdd8253  jmp 0x000077A70FDD5F54
000077a70fdd8258  call 0x000077A70FCD64F0
000077a70fdd825d  jmp 0x000077A70FDD5F61
000077a70fdd8262  sub rsp, 0x08
000077a70fdd8266  push rax
000077a70fdd8267  push rcx
000077a70fdd8268  push rdx
000077a70fdd8269  push rdi
000077a70fdd826a  push rsi
000077a70fdd826b  push r8
000077a70fdd826d  push r9
000077a70fdd826f  push r10
000077a70fdd8271  push r11
000077a70fdd8273  sub rsp, 0xF0
000077a70fdd827a  vmovaps [rsp], xmm0
000077a70fdd827f  vmovaps [rsp+0x10], xmm1
000077a70fdd8285  vmovaps [rsp+0x20], xmm2
000077a70fdd828b  vmovaps [rsp+0x30], xmm3
000077a70fdd8291  vmovaps [rsp+0x40], xmm4
000077a70fdd8297  vmovaps [rsp+0x50], xmm6
000077a70fdd829d  vmovaps [rsp+0x60], xmm7
000077a70fdd82a3  vmovaps [rsp+0x70], xmm8
000077a70fdd82a9  vmovaps [rsp+0x80], xmm9
000077a70fdd82b2  vmovaps [rsp+0x90], xmm10
000077a70fdd82bb  vmovaps [rsp+0xA0], xmm11
000077a70fdd82c4  vmovaps [rsp+0xB0], xmm12
000077a70fdd82cd  vmovaps [rsp+0xC0], xmm13
000077a70fdd82d6  vmovaps [rsp+0xD0], xmm14
000077a70fdd82df  vmovaps [rsp+0xE0], xmm15
000077a70fdd82e8  sub rsp, 0x30
000077a70fdd82ec  movaps [rsp], xmm5
000077a70fdd82f0  movaps [rsp+0x10], xmm6
000077a70fdd82f5  movaps [rsp+0x20], xmm3
000077a70fdd82fa  lea rdi, [rsp]
000077a70fdd82fe  mov esi, 0x00
000077a70fdd8303  mov rax, 0x6294188EF530
000077a70fdd830d  call rax
000077a70fdd830f  movaps xmm5, [rsp]
000077a70fdd8313  add rsp, 0x30
000077a70fdd8317  vmovaps xmm0, [rsp]
000077a70fdd831c  vmovaps xmm1, [rsp+0x10]
000077a70fdd8322  vmovaps xmm2, [rsp+0x20]
000077a70fdd8328  vmovaps xmm3, [rsp+0x30]
000077a70fdd832e  vmovaps xmm4, [rsp+0x40]
000077a70fdd8334  vmovaps xmm6, [rsp+0x50]
000077a70fdd833a  vmovaps xmm7, [rsp+0x60]
000077a70fdd8340  vmovaps xmm8, [rsp+0x70]
000077a70fdd8346  vmovaps xmm9, [rsp+0x80]
000077a70fdd834f  vmovaps xmm10, [rsp+0x90]
000077a70fdd8358  vmovaps xmm11, [rsp+0xA0]
000077a70fdd8361  vmovaps xmm12, [rsp+0xB0]
000077a70fdd836a  vmovaps xmm13, [rsp+0xC0]
000077a70fdd8373  vmovaps xmm14, [rsp+0xD0]
000077a70fdd837c  vmovaps xmm15, [rsp+0xE0]
000077a70fdd8385  add rsp, 0xF0
000077a70fdd838c  pop r11
000077a70fdd838e  pop r10
000077a70fdd8390  pop r9
000077a70fdd8392  pop r8
000077a70fdd8394  pop rsi
000077a70fdd8395  pop rdi
000077a70fdd8396  pop rdx
000077a70fdd8397  pop rcx
000077a70fdd8398  pop rax
000077a70fdd8399  add rsp, 0x08
000077a70fdd839d  jmp 0x000077A70FDD5F87
000077a70fdd83a2  sub rsp, 0x08
000077a70fdd83a6  push rax
000077a70fdd83a7  push rcx
000077a70fdd83a8  push rdx
000077a70fdd83a9  push rdi
000077a70fdd83aa  push rsi
000077a70fdd83ab  push r8
000077a70fdd83ad  push r9
000077a70fdd83af  push r10
000077a70fdd83b1  push r11
000077a70fdd83b3  sub rsp, 0xF0
000077a70fdd83ba  vmovaps [rsp], xmm0
000077a70fdd83bf  vmovaps [rsp+0x10], xmm1
000077a70fdd83c5  vmovaps [rsp+0x20], xmm2
000077a70fdd83cb  vmovaps [rsp+0x30], xmm3
000077a70fdd83d1  vmovaps [rsp+0x40], xmm4
000077a70fdd83d7  vmovaps [rsp+0x50], xmm5
000077a70fdd83dd  vmovaps [rsp+0x60], xmm7
000077a70fdd83e3  vmovaps [rsp+0x70], xmm8
000077a70fdd83e9  vmovaps [rsp+0x80], xmm9
000077a70fdd83f2  vmovaps [rsp+0x90], xmm10
000077a70fdd83fb  vmovaps [rsp+0xA0], xmm11
000077a70fdd8404  vmovaps [rsp+0xB0], xmm12
000077a70fdd840d  vmovaps [rsp+0xC0], xmm13
000077a70fdd8416  vmovaps [rsp+0xD0], xmm14
000077a70fdd841f  vmovaps [rsp+0xE0], xmm15
000077a70fdd8428  sub rsp, 0x30
000077a70fdd842c  movaps [rsp], xmm6
000077a70fdd8430  movaps [rsp+0x10], xmm9
000077a70fdd8436  movaps [rsp+0x20], xmm1
000077a70fdd843b  lea rdi, [rsp]
000077a70fdd843f  mov esi, 0x00
000077a70fdd8444  mov rax, 0x6294188EF530
000077a70fdd844e  call rax
000077a70fdd8450  movaps xmm6, [rsp]
000077a70fdd8454  add rsp, 0x30
000077a70fdd8458  vmovaps xmm0, [rsp]
000077a70fdd845d  vmovaps xmm1, [rsp+0x10]
000077a70fdd8463  vmovaps xmm2, [rsp+0x20]
000077a70fdd8469  vmovaps xmm3, [rsp+0x30]
000077a70fdd846f  vmovaps xmm4, [rsp+0x40]
000077a70fdd8475  vmovaps xmm5, [rsp+0x50]
000077a70fdd847b  vmovaps xmm7, [rsp+0x60]
000077a70fdd8481  vmovaps xmm8, [rsp+0x70]
000077a70fdd8487  vmovaps xmm9, [rsp+0x80]
000077a70fdd8490  vmovaps xmm10, [rsp+0x90]
000077a70fdd8499  vmovaps xmm11, [rsp+0xA0]
000077a70fdd84a2  vmovaps xmm12, [rsp+0xB0]
000077a70fdd84ab  vmovaps xmm13, [rsp+0xC0]
000077a70fdd84b4  vmovaps xmm14, [rsp+0xD0]
000077a70fdd84bd  vmovaps xmm15, [rsp+0xE0]
000077a70fdd84c6  add rsp, 0xF0
000077a70fdd84cd  pop r11
000077a70fdd84cf  pop r10
000077a70fdd84d1  pop r9
000077a70fdd84d3  pop r8
000077a70fdd84d5  pop rsi
000077a70fdd84d6  pop rdi
000077a70fdd84d7  pop rdx
000077a70fdd84d8  pop rcx
000077a70fdd84d9  pop rax
000077a70fdd84da  add rsp, 0x08
000077a70fdd84de  jmp 0x000077A70FDD5FAB
000077a70fdd84e3  sub rsp, 0x08
000077a70fdd84e7  push rax
000077a70fdd84e8  push rcx
000077a70fdd84e9  push rdx
000077a70fdd84ea  push rdi
000077a70fdd84eb  push rsi
000077a70fdd84ec  push r8
000077a70fdd84ee  push r9
000077a70fdd84f0  push r10
000077a70fdd84f2  push r11
000077a70fdd84f4  sub rsp, 0xF0
000077a70fdd84fb  vmovaps [rsp], xmm0
000077a70fdd8500  vmovaps [rsp+0x10], xmm1
000077a70fdd8506  vmovaps [rsp+0x20], xmm2
000077a70fdd850c  vmovaps [rsp+0x30], xmm3
000077a70fdd8512  vmovaps [rsp+0x40], xmm4
000077a70fdd8518  vmovaps [rsp+0x50], xmm5
000077a70fdd851e  vmovaps [rsp+0x60], xmm6
000077a70fdd8524  vmovaps [rsp+0x70], xmm7
000077a70fdd852a  vmovaps [rsp+0x80], xmm8
000077a70fdd8533  vmovaps [rsp+0x90], xmm10
000077a70fdd853c  vmovaps [rsp+0xA0], xmm11
000077a70fdd8545  vmovaps [rsp+0xB0], xmm12
000077a70fdd854e  vmovaps [rsp+0xC0], xmm13
000077a70fdd8557  vmovaps [rsp+0xD0], xmm14
000077a70fdd8560  vmovaps [rsp+0xE0], xmm15
000077a70fdd8569  sub rsp, 0x30
000077a70fdd856d  movaps [rsp], xmm9
000077a70fdd8572  movaps [rsp+0x10], xmm3
000077a70fdd8577  movaps [rsp+0x20], xmm1
000077a70fdd857c  lea rdi, [rsp]
000077a70fdd8580  mov esi, 0x00
000077a70fdd8585  mov rax, 0x6294188EF530
000077a70fdd858f  call rax
000077a70fdd8591  movaps xmm9, [rsp]
000077a70fdd8596  add rsp, 0x30
000077a70fdd859a  vmovaps xmm0, [rsp]
000077a70fdd859f  vmovaps xmm1, [rsp+0x10]
000077a70fdd85a5  vmovaps xmm2, [rsp+0x20]
000077a70fdd85ab  vmovaps xmm3, [rsp+0x30]
000077a70fdd85b1  vmovaps xmm4, [rsp+0x40]
000077a70fdd85b7  vmovaps xmm5, [rsp+0x50]
000077a70fdd85bd  vmovaps xmm6, [rsp+0x60]
000077a70fdd85c3  vmovaps xmm7, [rsp+0x70]
000077a70fdd85c9  vmovaps xmm8, [rsp+0x80]
000077a70fdd85d2  vmovaps xmm10, [rsp+0x90]
000077a70fdd85db  vmovaps xmm11, [rsp+0xA0]
000077a70fdd85e4  vmovaps xmm12, [rsp+0xB0]
000077a70fdd85ed  vmovaps xmm13, [rsp+0xC0]
000077a70fdd85f6  vmovaps xmm14, [rsp+0xD0]
000077a70fdd85ff  vmovaps xmm15, [rsp+0xE0]
000077a70fdd8608  add rsp, 0xF0
000077a70fdd860f  pop r11
000077a70fdd8611  pop r10
000077a70fdd8613  pop r9
000077a70fdd8615  pop r8
000077a70fdd8617  pop rsi
000077a70fdd8618  pop rdi
000077a70fdd8619  pop rdx
000077a70fdd861a  pop rcx
000077a70fdd861b  pop rax
000077a70fdd861c  add rsp, 0x08
000077a70fdd8620  jmp 0x000077A70FDD5FF7
000077a70fdd8625  call 0x000077A70FCD64F0
000077a70fdd862a  jmp 0x000077A70FDD6004
000077a70fdd862f  sub rsp, 0x08
000077a70fdd8633  push rax
000077a70fdd8634  push rcx
000077a70fdd8635  push rdx
000077a70fdd8636  push rdi
000077a70fdd8637  push rsi
000077a70fdd8638  push r8
000077a70fdd863a  push r9
000077a70fdd863c  push r10
000077a70fdd863e  push r11
000077a70fdd8640  sub rsp, 0xF0
000077a70fdd8647  vmovaps [rsp], xmm0
000077a70fdd864c  vmovaps [rsp+0x10], xmm1
000077a70fdd8652  vmovaps [rsp+0x20], xmm2
000077a70fdd8658  vmovaps [rsp+0x30], xmm3
000077a70fdd865e  vmovaps [rsp+0x40], xmm4
000077a70fdd8664  vmovaps [rsp+0x50], xmm5
000077a70fdd866a  vmovaps [rsp+0x60], xmm6
000077a70fdd8670  vmovaps [rsp+0x70], xmm7
000077a70fdd8676  vmovaps [rsp+0x80], xmm8
000077a70fdd867f  vmovaps [rsp+0x90], xmm9
000077a70fdd8688  vmovaps [rsp+0xA0], xmm10
000077a70fdd8691  vmovaps [rsp+0xB0], xmm11
000077a70fdd869a  vmovaps [rsp+0xC0], xmm12
000077a70fdd86a3  vmovaps [rsp+0xD0], xmm13
000077a70fdd86ac  vmovaps [rsp+0xE0], xmm14
000077a70fdd86b5  sub rsp, 0x30
000077a70fdd86b9  movaps [rsp], xmm15
000077a70fdd86be  movaps [rsp+0x10], xmm3
000077a70fdd86c3  movaps [rsp+0x20], xmm7
000077a70fdd86c8  lea rdi, [rsp]
000077a70fdd86cc  mov esi, 0x00
000077a70fdd86d1  mov rax, 0x6294188EF530
000077a70fdd86db  call rax
000077a70fdd86dd  movaps xmm15, [rsp]
000077a70fdd86e2  add rsp, 0x30
000077a70fdd86e6  vmovaps xmm0, [rsp]
000077a70fdd86eb  vmovaps xmm1, [rsp+0x10]
000077a70fdd86f1  vmovaps xmm2, [rsp+0x20]
000077a70fdd86f7  vmovaps xmm3, [rsp+0x30]
000077a70fdd86fd  vmovaps xmm4, [rsp+0x40]
000077a70fdd8703  vmovaps xmm5, [rsp+0x50]
000077a70fdd8709  vmovaps xmm6, [rsp+0x60]
000077a70fdd870f  vmovaps xmm7, [rsp+0x70]
000077a70fdd8715  vmovaps xmm8, [rsp+0x80]
000077a70fdd871e  vmovaps xmm9, [rsp+0x90]
000077a70fdd8727  vmovaps xmm10, [rsp+0xA0]
000077a70fdd8730  vmovaps xmm11, [rsp+0xB0]
000077a70fdd8739  vmovaps xmm12, [rsp+0xC0]
000077a70fdd8742  vmovaps xmm13, [rsp+0xD0]
000077a70fdd874b  vmovaps xmm14, [rsp+0xE0]
000077a70fdd8754  add rsp, 0xF0
000077a70fdd875b  pop r11
000077a70fdd875d  pop r10
000077a70fdd875f  pop r9
000077a70fdd8761  pop r8
000077a70fdd8763  pop rsi
000077a70fdd8764  pop rdi
000077a70fdd8765  pop rdx
000077a70fdd8766  pop rcx
000077a70fdd8767  pop rax
000077a70fdd8768  add rsp, 0x08
000077a70fdd876c  jmp 0x000077A70FDD6030
000077a70fdd8771  sub rsp, 0x08
000077a70fdd8775  push rax
000077a70fdd8776  push rcx
000077a70fdd8777  push rdx
000077a70fdd8778  push rdi
000077a70fdd8779  push rsi
000077a70fdd877a  push r8
000077a70fdd877c  push r9
000077a70fdd877e  push r10
000077a70fdd8780  push r11
000077a70fdd8782  sub rsp, 0xF0
000077a70fdd8789  vmovaps [rsp], xmm0
000077a70fdd878e  vmovaps [rsp+0x10], xmm1
000077a70fdd8794  vmovaps [rsp+0x20], xmm2
000077a70fdd879a  vmovaps [rsp+0x30], xmm4
000077a70fdd87a0  vmovaps [rsp+0x40], xmm5
000077a70fdd87a6  vmovaps [rsp+0x50], xmm6
000077a70fdd87ac  vmovaps [rsp+0x60], xmm7
000077a70fdd87b2  vmovaps [rsp+0x70], xmm8
000077a70fdd87b8  vmovaps [rsp+0x80], xmm9
000077a70fdd87c1  vmovaps [rsp+0x90], xmm10
000077a70fdd87ca  vmovaps [rsp+0xA0], xmm11
000077a70fdd87d3  vmovaps [rsp+0xB0], xmm12
000077a70fdd87dc  vmovaps [rsp+0xC0], xmm13
000077a70fdd87e5  vmovaps [rsp+0xD0], xmm14
000077a70fdd87ee  vmovaps [rsp+0xE0], xmm15
000077a70fdd87f7  sub rsp, 0x30
000077a70fdd87fb  movaps [rsp], xmm3
000077a70fdd87ff  movaps [rsp+0x10], xmm1
000077a70fdd8804  movaps [rsp+0x20], xmm15
000077a70fdd880a  lea rdi, [rsp]
000077a70fdd880e  mov esi, 0x00
000077a70fdd8813  mov rax, 0x6294188EF530
000077a70fdd881d  call rax
000077a70fdd881f  movaps xmm3, [rsp]
000077a70fdd8823  add rsp, 0x30
000077a70fdd8827  vmovaps xmm0, [rsp]
000077a70fdd882c  vmovaps xmm1, [rsp+0x10]
000077a70fdd8832  vmovaps xmm2, [rsp+0x20]
000077a70fdd8838  vmovaps xmm4, [rsp+0x30]
000077a70fdd883e  vmovaps xmm5, [rsp+0x40]
000077a70fdd8844  vmovaps xmm6, [rsp+0x50]
000077a70fdd884a  vmovaps xmm7, [rsp+0x60]
000077a70fdd8850  vmovaps xmm8, [rsp+0x70]
000077a70fdd8856  vmovaps xmm9, [rsp+0x80]
000077a70fdd885f  vmovaps xmm10, [rsp+0x90]
000077a70fdd8868  vmovaps xmm11, [rsp+0xA0]
000077a70fdd8871  vmovaps xmm12, [rsp+0xB0]
000077a70fdd887a  vmovaps xmm13, [rsp+0xC0]
000077a70fdd8883  vmovaps xmm14, [rsp+0xD0]
000077a70fdd888c  vmovaps xmm15, [rsp+0xE0]
000077a70fdd8895  add rsp, 0xF0
000077a70fdd889c  pop r11
000077a70fdd889e  pop r10
000077a70fdd88a0  pop r9
000077a70fdd88a2  pop r8
000077a70fdd88a4  pop rsi
000077a70fdd88a5  pop rdi
000077a70fdd88a6  pop rdx
000077a70fdd88a7  pop rcx
000077a70fdd88a8  pop rax
000077a70fdd88a9  add rsp, 0x08
000077a70fdd88ad  jmp 0x000077A70FDD60BF
000077a70fdd88b2  call 0x000077A70FCD64F0
000077a70fdd88b7  jmp 0x000077A70FDD60C9
000077a70fdd88bc  sub rsp, 0x08
000077a70fdd88c0  push rax
000077a70fdd88c1  push rcx
000077a70fdd88c2  push rdx
000077a70fdd88c3  push rdi
000077a70fdd88c4  push rsi
000077a70fdd88c5  push r8
000077a70fdd88c7  push r9
000077a70fdd88c9  push r10
000077a70fdd88cb  push r11
000077a70fdd88cd  sub rsp, 0xF0
000077a70fdd88d4  vmovaps [rsp], xmm0
000077a70fdd88d9  vmovaps [rsp+0x10], xmm1
000077a70fdd88df  vmovaps [rsp+0x20], xmm2
000077a70fdd88e5  vmovaps [rsp+0x30], xmm3
000077a70fdd88eb  vmovaps [rsp+0x40], xmm4
000077a70fdd88f1  vmovaps [rsp+0x50], xmm5
000077a70fdd88f7  vmovaps [rsp+0x60], xmm6
000077a70fdd88fd  vmovaps [rsp+0x70], xmm7
000077a70fdd8903  vmovaps [rsp+0x80], xmm8
000077a70fdd890c  vmovaps [rsp+0x90], xmm9
000077a70fdd8915  vmovaps [rsp+0xA0], xmm10
000077a70fdd891e  vmovaps [rsp+0xB0], xmm11
000077a70fdd8927  vmovaps [rsp+0xC0], xmm12
000077a70fdd8930  vmovaps [rsp+0xD0], xmm13
000077a70fdd8939  vmovaps [rsp+0xE0], xmm14
000077a70fdd8942  sub rsp, 0x30
000077a70fdd8946  movaps [rsp], xmm15
000077a70fdd894b  movaps [rsp+0x10], xmm14
000077a70fdd8951  movaps [rsp+0x20], xmm4
000077a70fdd8956  lea rdi, [rsp]
000077a70fdd895a  mov esi, 0x00
000077a70fdd895f  mov rax, 0x6294188EF530
000077a70fdd8969  call rax
000077a70fdd896b  movaps xmm15, [rsp]
000077a70fdd8970  add rsp, 0x30
000077a70fdd8974  vmovaps xmm0, [rsp]
000077a70fdd8979  vmovaps xmm1, [rsp+0x10]
000077a70fdd897f  vmovaps xmm2, [rsp+0x20]
000077a70fdd8985  vmovaps xmm3, [rsp+0x30]
000077a70fdd898b  vmovaps xmm4, [rsp+0x40]
000077a70fdd8991  vmovaps xmm5, [rsp+0x50]
000077a70fdd8997  vmovaps xmm6, [rsp+0x60]
000077a70fdd899d  vmovaps xmm7, [rsp+0x70]
000077a70fdd89a3  vmovaps xmm8, [rsp+0x80]
000077a70fdd89ac  vmovaps xmm9, [rsp+0x90]
000077a70fdd89b5  vmovaps xmm10, [rsp+0xA0]
000077a70fdd89be  vmovaps xmm11, [rsp+0xB0]
000077a70fdd89c7  vmovaps xmm12, [rsp+0xC0]
000077a70fdd89d0  vmovaps xmm13, [rsp+0xD0]
000077a70fdd89d9  vmovaps xmm14, [rsp+0xE0]
000077a70fdd89e2  add rsp, 0xF0
000077a70fdd89e9  pop r11
000077a70fdd89eb  pop r10
000077a70fdd89ed  pop r9
000077a70fdd89ef  pop r8
000077a70fdd89f1  pop rsi
000077a70fdd89f2  pop rdi
000077a70fdd89f3  pop rdx
000077a70fdd89f4  pop rcx
000077a70fdd89f5  pop rax
000077a70fdd89f6  add rsp, 0x08
000077a70fdd89fa  jmp 0x000077A70FDD60F7
000077a70fdd89ff  sub rsp, 0x08
000077a70fdd8a03  push rax
000077a70fdd8a04  push rcx
000077a70fdd8a05  push rdx
000077a70fdd8a06  push rdi
000077a70fdd8a07  push rsi
000077a70fdd8a08  push r8
000077a70fdd8a0a  push r9
000077a70fdd8a0c  push r10
000077a70fdd8a0e  push r11
000077a70fdd8a10  sub rsp, 0xF0
000077a70fdd8a17  vmovaps [rsp], xmm0
000077a70fdd8a1c  vmovaps [rsp+0x10], xmm1
000077a70fdd8a22  vmovaps [rsp+0x20], xmm2
000077a70fdd8a28  vmovaps [rsp+0x30], xmm3
000077a70fdd8a2e  vmovaps [rsp+0x40], xmm4
000077a70fdd8a34  vmovaps [rsp+0x50], xmm5
000077a70fdd8a3a  vmovaps [rsp+0x60], xmm6
000077a70fdd8a40  vmovaps [rsp+0x70], xmm7
000077a70fdd8a46  vmovaps [rsp+0x80], xmm8
000077a70fdd8a4f  vmovaps [rsp+0x90], xmm9
000077a70fdd8a58  vmovaps [rsp+0xA0], xmm10
000077a70fdd8a61  vmovaps [rsp+0xB0], xmm11
000077a70fdd8a6a  vmovaps [rsp+0xC0], xmm12
000077a70fdd8a73  vmovaps [rsp+0xD0], xmm13
000077a70fdd8a7c  vmovaps [rsp+0xE0], xmm15
000077a70fdd8a85  sub rsp, 0x30
000077a70fdd8a89  movaps [rsp], xmm14
000077a70fdd8a8e  movaps [rsp+0x10], xmm2
000077a70fdd8a93  movaps [rsp+0x20], xmm1
000077a70fdd8a98  lea rdi, [rsp]
000077a70fdd8a9c  mov esi, 0x00
000077a70fdd8aa1  mov rax, 0x6294188EF530
000077a70fdd8aab  call rax
000077a70fdd8aad  movaps xmm14, [rsp]
000077a70fdd8ab2  add rsp, 0x30
000077a70fdd8ab6  vmovaps xmm0, [rsp]
000077a70fdd8abb  vmovaps xmm1, [rsp+0x10]
000077a70fdd8ac1  vmovaps xmm2, [rsp+0x20]
000077a70fdd8ac7  vmovaps xmm3, [rsp+0x30]
000077a70fdd8acd  vmovaps xmm4, [rsp+0x40]
000077a70fdd8ad3  vmovaps xmm5, [rsp+0x50]
000077a70fdd8ad9  vmovaps xmm6, [rsp+0x60]
000077a70fdd8adf  vmovaps xmm7, [rsp+0x70]
000077a70fdd8ae5  vmovaps xmm8, [rsp+0x80]
000077a70fdd8aee  vmovaps xmm9, [rsp+0x90]
000077a70fdd8af7  vmovaps xmm10, [rsp+0xA0]
000077a70fdd8b00  vmovaps xmm11, [rsp+0xB0]
000077a70fdd8b09  vmovaps xmm12, [rsp+0xC0]
000077a70fdd8b12  vmovaps xmm13, [rsp+0xD0]
000077a70fdd8b1b  vmovaps xmm15, [rsp+0xE0]
000077a70fdd8b24  add rsp, 0xF0
000077a70fdd8b2b  pop r11
000077a70fdd8b2d  pop r10
000077a70fdd8b2f  pop r9
000077a70fdd8b31  pop r8
000077a70fdd8b33  pop rsi
000077a70fdd8b34  pop rdi
000077a70fdd8b35  pop rdx
000077a70fdd8b36  pop rcx
000077a70fdd8b37  pop rax
000077a70fdd8b38  add rsp, 0x08
000077a70fdd8b3c  jmp 0x000077A70FDD611D
000077a70fdd8b41  sub rsp, 0x08
000077a70fdd8b45  push rax
000077a70fdd8b46  push rcx
000077a70fdd8b47  push rdx
000077a70fdd8b48  push rdi
000077a70fdd8b49  push rsi
000077a70fdd8b4a  push r8
000077a70fdd8b4c  push r9
000077a70fdd8b4e  push r10
000077a70fdd8b50  push r11
000077a70fdd8b52  sub rsp, 0xF0
000077a70fdd8b59  vmovaps [rsp], xmm0
000077a70fdd8b5e  vmovaps [rsp+0x10], xmm2
000077a70fdd8b64  vmovaps [rsp+0x20], xmm3
000077a70fdd8b6a  vmovaps [rsp+0x30], xmm4
000077a70fdd8b70  vmovaps [rsp+0x40], xmm5
000077a70fdd8b76  vmovaps [rsp+0x50], xmm6
000077a70fdd8b7c  vmovaps [rsp+0x60], xmm7
000077a70fdd8b82  vmovaps [rsp+0x70], xmm8
000077a70fdd8b88  vmovaps [rsp+0x80], xmm9
000077a70fdd8b91  vmovaps [rsp+0x90], xmm10
000077a70fdd8b9a  vmovaps [rsp+0xA0], xmm11
000077a70fdd8ba3  vmovaps [rsp+0xB0], xmm12
000077a70fdd8bac  vmovaps [rsp+0xC0], xmm13
000077a70fdd8bb5  vmovaps [rsp+0xD0], xmm14
000077a70fdd8bbe  vmovaps [rsp+0xE0], xmm15
000077a70fdd8bc7  sub rsp, 0x30
000077a70fdd8bcb  movaps [rsp], xmm1
000077a70fdd8bcf  movaps [rsp+0x10], xmm4
000077a70fdd8bd4  movaps [rsp+0x20], xmm9
000077a70fdd8bda  lea rdi, [rsp]
000077a70fdd8bde  mov esi, 0x00
000077a70fdd8be3  mov rax, 0x6294188EF530
000077a70fdd8bed  call rax
000077a70fdd8bef  movaps xmm1, [rsp]
000077a70fdd8bf3  add rsp, 0x30
000077a70fdd8bf7  vmovaps xmm0, [rsp]
000077a70fdd8bfc  vmovaps xmm2, [rsp+0x10]
000077a70fdd8c02  vmovaps xmm3, [rsp+0x20]
000077a70fdd8c08  vmovaps xmm4, [rsp+0x30]
000077a70fdd8c0e  vmovaps xmm5, [rsp+0x40]
000077a70fdd8c14  vmovaps xmm6, [rsp+0x50]
000077a70fdd8c1a  vmovaps xmm7, [rsp+0x60]
000077a70fdd8c20  vmovaps xmm8, [rsp+0x70]
000077a70fdd8c26  vmovaps xmm9, [rsp+0x80]
000077a70fdd8c2f  vmovaps xmm10, [rsp+0x90]
000077a70fdd8c38  vmovaps xmm11, [rsp+0xA0]
000077a70fdd8c41  vmovaps xmm12, [rsp+0xB0]
000077a70fdd8c4a  vmovaps xmm13, [rsp+0xC0]
000077a70fdd8c53  vmovaps xmm14, [rsp+0xD0]
000077a70fdd8c5c  vmovaps xmm15, [rsp+0xE0]
000077a70fdd8c65  add rsp, 0xF0
000077a70fdd8c6c  pop r11
000077a70fdd8c6e  pop r10
000077a70fdd8c70  pop r9
000077a70fdd8c72  pop r8
000077a70fdd8c74  pop rsi
000077a70fdd8c75  pop rdi
000077a70fdd8c76  pop rdx
000077a70fdd8c77  pop rcx
000077a70fdd8c78  pop rax
000077a70fdd8c79  add rsp, 0x08
000077a70fdd8c7d  jmp 0x000077A70FDD613B
000077a70fdd8c82  sub rsp, 0x08
000077a70fdd8c86  push rax
000077a70fdd8c87  push rcx
000077a70fdd8c88  push rdx
000077a70fdd8c89  push rdi
000077a70fdd8c8a  push rsi
000077a70fdd8c8b  push r8
000077a70fdd8c8d  push r9
000077a70fdd8c8f  push r10
000077a70fdd8c91  push r11
000077a70fdd8c93  sub rsp, 0xF0
000077a70fdd8c9a  vmovaps [rsp], xmm0
000077a70fdd8c9f  vmovaps [rsp+0x10], xmm1
000077a70fdd8ca5  vmovaps [rsp+0x20], xmm2
000077a70fdd8cab  vmovaps [rsp+0x30], xmm3
000077a70fdd8cb1  vmovaps [rsp+0x40], xmm5
000077a70fdd8cb7  vmovaps [rsp+0x50], xmm6
000077a70fdd8cbd  vmovaps [rsp+0x60], xmm7
000077a70fdd8cc3  vmovaps [rsp+0x70], xmm8
000077a70fdd8cc9  vmovaps [rsp+0x80], xmm9
000077a70fdd8cd2  vmovaps [rsp+0x90], xmm10
000077a70fdd8cdb  vmovaps [rsp+0xA0], xmm11
000077a70fdd8ce4  vmovaps [rsp+0xB0], xmm12
000077a70fdd8ced  vmovaps [rsp+0xC0], xmm13
000077a70fdd8cf6  vmovaps [rsp+0xD0], xmm14
000077a70fdd8cff  vmovaps [rsp+0xE0], xmm15
000077a70fdd8d08  sub rsp, 0x30
000077a70fdd8d0c  movaps [rsp], xmm4
000077a70fdd8d10  movaps [rsp+0x10], xmm2
000077a70fdd8d15  movaps [rsp+0x20], xmm9
000077a70fdd8d1b  lea rdi, [rsp]
000077a70fdd8d1f  mov esi, 0x00
000077a70fdd8d24  mov rax, 0x6294188EF530
000077a70fdd8d2e  call rax
000077a70fdd8d30  movaps xmm4, [rsp]
000077a70fdd8d34  add rsp, 0x30
000077a70fdd8d38  vmovaps xmm0, [rsp]
000077a70fdd8d3d  vmovaps xmm1, [rsp+0x10]
000077a70fdd8d43  vmovaps xmm2, [rsp+0x20]
000077a70fdd8d49  vmovaps xmm3, [rsp+0x30]
000077a70fdd8d4f  vmovaps xmm5, [rsp+0x40]
000077a70fdd8d55  vmovaps xmm6, [rsp+0x50]
000077a70fdd8d5b  vmovaps xmm7, [rsp+0x60]
000077a70fdd8d61  vmovaps xmm8, [rsp+0x70]
000077a70fdd8d67  vmovaps xmm9, [rsp+0x80]
000077a70fdd8d70  vmovaps xmm10, [rsp+0x90]
000077a70fdd8d79  vmovaps xmm11, [rsp+0xA0]
000077a70fdd8d82  vmovaps xmm12, [rsp+0xB0]
000077a70fdd8d8b  vmovaps xmm13, [rsp+0xC0]
000077a70fdd8d94  vmovaps xmm14, [rsp+0xD0]
000077a70fdd8d9d  vmovaps xmm15, [rsp+0xE0]
000077a70fdd8da6  add rsp, 0xF0
000077a70fdd8dad  pop r11
000077a70fdd8daf  pop r10
000077a70fdd8db1  pop r9
000077a70fdd8db3  pop r8
000077a70fdd8db5  pop rsi
000077a70fdd8db6  pop rdi
000077a70fdd8db7  pop rdx
000077a70fdd8db8  pop rcx
000077a70fdd8db9  pop rax
000077a70fdd8dba  add rsp, 0x08
000077a70fdd8dbe  jmp 0x000077A70FDD616B
000077a70fdd8dc3  sub rsp, 0x08
000077a70fdd8dc7  push rax
000077a70fdd8dc8  push rcx
000077a70fdd8dc9  push rdx
000077a70fdd8dca  push rdi
000077a70fdd8dcb  push rsi
000077a70fdd8dcc  push r8
000077a70fdd8dce  push r9
000077a70fdd8dd0  push r10
000077a70fdd8dd2  push r11
000077a70fdd8dd4  sub rsp, 0xF0
000077a70fdd8ddb  vmovaps [rsp], xmm0
000077a70fdd8de0  vmovaps [rsp+0x10], xmm1
000077a70fdd8de6  vmovaps [rsp+0x20], xmm2
000077a70fdd8dec  vmovaps [rsp+0x30], xmm3
000077a70fdd8df2  vmovaps [rsp+0x40], xmm4
000077a70fdd8df8  vmovaps [rsp+0x50], xmm5
000077a70fdd8dfe  vmovaps [rsp+0x60], xmm6
000077a70fdd8e04  vmovaps [rsp+0x70], xmm7
000077a70fdd8e0a  vmovaps [rsp+0x80], xmm8
000077a70fdd8e13  vmovaps [rsp+0x90], xmm10
000077a70fdd8e1c  vmovaps [rsp+0xA0], xmm11
000077a70fdd8e25  vmovaps [rsp+0xB0], xmm12
000077a70fdd8e2e  vmovaps [rsp+0xC0], xmm13
000077a70fdd8e37  vmovaps [rsp+0xD0], xmm14
000077a70fdd8e40  vmovaps [rsp+0xE0], xmm15
000077a70fdd8e49  sub rsp, 0x30
000077a70fdd8e4d  movaps [rsp], xmm9
000077a70fdd8e52  movaps [rsp+0x10], xmm2
000077a70fdd8e57  movaps [rsp+0x20], xmm1
000077a70fdd8e5c  lea rdi, [rsp]
000077a70fdd8e60  mov esi, 0x00
000077a70fdd8e65  mov rax, 0x6294188EF530
000077a70fdd8e6f  call rax
000077a70fdd8e71  movaps xmm9, [rsp]
000077a70fdd8e76  add rsp, 0x30
000077a70fdd8e7a  vmovaps xmm0, [rsp]
000077a70fdd8e7f  vmovaps xmm1, [rsp+0x10]
000077a70fdd8e85  vmovaps xmm2, [rsp+0x20]
000077a70fdd8e8b  vmovaps xmm3, [rsp+0x30]
000077a70fdd8e91  vmovaps xmm4, [rsp+0x40]
000077a70fdd8e97  vmovaps xmm5, [rsp+0x50]
000077a70fdd8e9d  vmovaps xmm6, [rsp+0x60]
000077a70fdd8ea3  vmovaps xmm7, [rsp+0x70]
000077a70fdd8ea9  vmovaps xmm8, [rsp+0x80]
000077a70fdd8eb2  vmovaps xmm10, [rsp+0x90]
000077a70fdd8ebb  vmovaps xmm11, [rsp+0xA0]
000077a70fdd8ec4  vmovaps xmm12, [rsp+0xB0]
000077a70fdd8ecd  vmovaps xmm13, [rsp+0xC0]
000077a70fdd8ed6  vmovaps xmm14, [rsp+0xD0]
000077a70fdd8edf  vmovaps xmm15, [rsp+0xE0]
000077a70fdd8ee8  add rsp, 0xF0
000077a70fdd8eef  pop r11
000077a70fdd8ef1  pop r10
000077a70fdd8ef3  pop r9
000077a70fdd8ef5  pop r8
000077a70fdd8ef7  pop rsi
000077a70fdd8ef8  pop rdi
000077a70fdd8ef9  pop rdx
000077a70fdd8efa  pop rcx
000077a70fdd8efb  pop rax
000077a70fdd8efc  add rsp, 0x08
000077a70fdd8f00  jmp 0x000077A70FDD61A1
000077a70fdd8f05  sub rsp, 0x08
000077a70fdd8f09  push rax
000077a70fdd8f0a  push rcx
000077a70fdd8f0b  push rdx
000077a70fdd8f0c  push rdi
000077a70fdd8f0d  push rsi
000077a70fdd8f0e  push r8
000077a70fdd8f10  push r9
000077a70fdd8f12  push r10
000077a70fdd8f14  push r11
000077a70fdd8f16  sub rsp, 0xF0
000077a70fdd8f1d  vmovaps [rsp], xmm0
000077a70fdd8f22  vmovaps [rsp+0x10], xmm2
000077a70fdd8f28  vmovaps [rsp+0x20], xmm3
000077a70fdd8f2e  vmovaps [rsp+0x30], xmm4
000077a70fdd8f34  vmovaps [rsp+0x40], xmm5
000077a70fdd8f3a  vmovaps [rsp+0x50], xmm6
000077a70fdd8f40  vmovaps [rsp+0x60], xmm7
000077a70fdd8f46  vmovaps [rsp+0x70], xmm8
000077a70fdd8f4c  vmovaps [rsp+0x80], xmm9
000077a70fdd8f55  vmovaps [rsp+0x90], xmm10
000077a70fdd8f5e  vmovaps [rsp+0xA0], xmm11
000077a70fdd8f67  vmovaps [rsp+0xB0], xmm12
000077a70fdd8f70  vmovaps [rsp+0xC0], xmm13
000077a70fdd8f79  vmovaps [rsp+0xD0], xmm14
000077a70fdd8f82  vmovaps [rsp+0xE0], xmm15
000077a70fdd8f8b  sub rsp, 0x30
000077a70fdd8f8f  movaps [rsp], xmm1
000077a70fdd8f93  movaps [rsp+0x10], xmm15
000077a70fdd8f99  movaps [rsp+0x20], xmm6
000077a70fdd8f9e  lea rdi, [rsp]
000077a70fdd8fa2  mov esi, 0x00
000077a70fdd8fa7  mov rax, 0x6294188EF530
000077a70fdd8fb1  call rax
000077a70fdd8fb3  movaps xmm1, [rsp]
000077a70fdd8fb7  add rsp, 0x30
000077a70fdd8fbb  vmovaps xmm0, [rsp]
000077a70fdd8fc0  vmovaps xmm2, [rsp+0x10]
000077a70fdd8fc6  vmovaps xmm3, [rsp+0x20]
000077a70fdd8fcc  vmovaps xmm4, [rsp+0x30]
000077a70fdd8fd2  vmovaps xmm5, [rsp+0x40]
000077a70fdd8fd8  vmovaps xmm6, [rsp+0x50]
000077a70fdd8fde  vmovaps xmm7, [rsp+0x60]
000077a70fdd8fe4  vmovaps xmm8, [rsp+0x70]
000077a70fdd8fea  vmovaps xmm9, [rsp+0x80]
000077a70fdd8ff3  vmovaps xmm10, [rsp+0x90]
000077a70fdd8ffc  vmovaps xmm11, [rsp+0xA0]
000077a70fdd9005  vmovaps xmm12, [rsp+0xB0]
000077a70fdd900e  vmovaps xmm13, [rsp+0xC0]
000077a70fdd9017  vmovaps xmm14, [rsp+0xD0]
000077a70fdd9020  vmovaps xmm15, [rsp+0xE0]
000077a70fdd9029  add rsp, 0xF0
000077a70fdd9030  pop r11
000077a70fdd9032  pop r10
000077a70fdd9034  pop r9
000077a70fdd9036  pop r8
000077a70fdd9038  pop rsi
000077a70fdd9039  pop rdi
000077a70fdd903a  pop rdx
000077a70fdd903b  pop rcx
000077a70fdd903c  pop rax
000077a70fdd903d  add rsp, 0x08
000077a70fdd9041  jmp 0x000077A70FDD61C2
000077a70fdd9046  sub rsp, 0x08
000077a70fdd904a  push rax
000077a70fdd904b  push rcx
000077a70fdd904c  push rdx
000077a70fdd904d  push rdi
000077a70fdd904e  push rsi
000077a70fdd904f  push r8
000077a70fdd9051  push r9
000077a70fdd9053  push r10
000077a70fdd9055  push r11
000077a70fdd9057  sub rsp, 0xF0
000077a70fdd905e  vmovaps [rsp], xmm0
000077a70fdd9063  vmovaps [rsp+0x10], xmm1
000077a70fdd9069  vmovaps [rsp+0x20], xmm2
000077a70fdd906f  vmovaps [rsp+0x30], xmm3
000077a70fdd9075  vmovaps [rsp+0x40], xmm4
000077a70fdd907b  vmovaps [rsp+0x50], xmm5
000077a70fdd9081  vmovaps [rsp+0x60], xmm6
000077a70fdd9087  vmovaps [rsp+0x70], xmm7
000077a70fdd908d  vmovaps [rsp+0x80], xmm8
000077a70fdd9096  vmovaps [rsp+0x90], xmm9
000077a70fdd909f  vmovaps [rsp+0xA0], xmm10
000077a70fdd90a8  vmovaps [rsp+0xB0], xmm11
000077a70fdd90b1  vmovaps [rsp+0xC0], xmm12
000077a70fdd90ba  vmovaps [rsp+0xD0], xmm13
000077a70fdd90c3  vmovaps [rsp+0xE0], xmm14
000077a70fdd90cc  sub rsp, 0x30
000077a70fdd90d0  movaps [rsp], xmm15
000077a70fdd90d5  movaps [rsp+0x10], xmm5
000077a70fdd90da  movaps [rsp+0x20], xmm3
000077a70fdd90df  lea rdi, [rsp]
000077a70fdd90e3  mov esi, 0x00
000077a70fdd90e8  mov rax, 0x6294188EF530
000077a70fdd90f2  call rax
000077a70fdd90f4  movaps xmm15, [rsp]
000077a70fdd90f9  add rsp, 0x30
000077a70fdd90fd  vmovaps xmm0, [rsp]
000077a70fdd9102  vmovaps xmm1, [rsp+0x10]
000077a70fdd9108  vmovaps xmm2, [rsp+0x20]
000077a70fdd910e  vmovaps xmm3, [rsp+0x30]
000077a70fdd9114  vmovaps xmm4, [rsp+0x40]
000077a70fdd911a  vmovaps xmm5, [rsp+0x50]
000077a70fdd9120  vmovaps xmm6, [rsp+0x60]
000077a70fdd9126  vmovaps xmm7, [rsp+0x70]
000077a70fdd912c  vmovaps xmm8, [rsp+0x80]
000077a70fdd9135  vmovaps xmm9, [rsp+0x90]
000077a70fdd913e  vmovaps xmm10, [rsp+0xA0]
000077a70fdd9147  vmovaps xmm11, [rsp+0xB0]
000077a70fdd9150  vmovaps xmm12, [rsp+0xC0]
000077a70fdd9159  vmovaps xmm13, [rsp+0xD0]
000077a70fdd9162  vmovaps xmm14, [rsp+0xE0]
000077a70fdd916b  add rsp, 0xF0
000077a70fdd9172  pop r11
000077a70fdd9174  pop r10
000077a70fdd9176  pop r9
000077a70fdd9178  pop r8
000077a70fdd917a  pop rsi
000077a70fdd917b  pop rdi
000077a70fdd917c  pop rdx
000077a70fdd917d  pop rcx
000077a70fdd917e  pop rax
000077a70fdd917f  add rsp, 0x08
000077a70fdd9183  jmp 0x000077A70FDD61DC
000077a70fdd9188  sub rsp, 0x08
000077a70fdd918c  push rax
000077a70fdd918d  push rcx
000077a70fdd918e  push rdx
000077a70fdd918f  push rdi
000077a70fdd9190  push rsi
000077a70fdd9191  push r8
000077a70fdd9193  push r9
000077a70fdd9195  push r10
000077a70fdd9197  push r11
000077a70fdd9199  sub rsp, 0xF0
000077a70fdd91a0  vmovaps [rsp], xmm0
000077a70fdd91a5  vmovaps [rsp+0x10], xmm1
000077a70fdd91ab  vmovaps [rsp+0x20], xmm2
000077a70fdd91b1  vmovaps [rsp+0x30], xmm3
000077a70fdd91b7  vmovaps [rsp+0x40], xmm4
000077a70fdd91bd  vmovaps [rsp+0x50], xmm6
000077a70fdd91c3  vmovaps [rsp+0x60], xmm7
000077a70fdd91c9  vmovaps [rsp+0x70], xmm8
000077a70fdd91cf  vmovaps [rsp+0x80], xmm9
000077a70fdd91d8  vmovaps [rsp+0x90], xmm10
000077a70fdd91e1  vmovaps [rsp+0xA0], xmm11
000077a70fdd91ea  vmovaps [rsp+0xB0], xmm12
000077a70fdd91f3  vmovaps [rsp+0xC0], xmm13
000077a70fdd91fc  vmovaps [rsp+0xD0], xmm14
000077a70fdd9205  vmovaps [rsp+0xE0], xmm15
000077a70fdd920e  sub rsp, 0x30
000077a70fdd9212  movaps [rsp], xmm5
000077a70fdd9216  movaps [rsp+0x10], xmm8
000077a70fdd921c  movaps [rsp+0x20], xmm6
000077a70fdd9221  lea rdi, [rsp]
000077a70fdd9225  mov esi, 0x00
000077a70fdd922a  mov rax, 0x6294188EF530
000077a70fdd9234  call rax
000077a70fdd9236  movaps xmm5, [rsp]
000077a70fdd923a  add rsp, 0x30
000077a70fdd923e  vmovaps xmm0, [rsp]
000077a70fdd9243  vmovaps xmm1, [rsp+0x10]
000077a70fdd9249  vmovaps xmm2, [rsp+0x20]
000077a70fdd924f  vmovaps xmm3, [rsp+0x30]
000077a70fdd9255  vmovaps xmm4, [rsp+0x40]
000077a70fdd925b  vmovaps xmm6, [rsp+0x50]
000077a70fdd9261  vmovaps xmm7, [rsp+0x60]
000077a70fdd9267  vmovaps xmm8, [rsp+0x70]
000077a70fdd926d  vmovaps xmm9, [rsp+0x80]
000077a70fdd9276  vmovaps xmm10, [rsp+0x90]
000077a70fdd927f  vmovaps xmm11, [rsp+0xA0]
000077a70fdd9288  vmovaps xmm12, [rsp+0xB0]
000077a70fdd9291  vmovaps xmm13, [rsp+0xC0]
000077a70fdd929a  vmovaps xmm14, [rsp+0xD0]
000077a70fdd92a3  vmovaps xmm15, [rsp+0xE0]
000077a70fdd92ac  add rsp, 0xF0
000077a70fdd92b3  pop r11
000077a70fdd92b5  pop r10
000077a70fdd92b7  pop r9
000077a70fdd92b9  pop r8
000077a70fdd92bb  pop rsi
000077a70fdd92bc  pop rdi
000077a70fdd92bd  pop rdx
000077a70fdd92be  pop rcx
000077a70fdd92bf  pop rax
000077a70fdd92c0  add rsp, 0x08
000077a70fdd92c4  jmp 0x000077A70FDD6200
000077a70fdd92c9  sub rsp, 0x08
000077a70fdd92cd  push rax
000077a70fdd92ce  push rcx
000077a70fdd92cf  push rdx
000077a70fdd92d0  push rdi
000077a70fdd92d1  push rsi
000077a70fdd92d2  push r8
000077a70fdd92d4  push r9
000077a70fdd92d6  push r10
000077a70fdd92d8  push r11
000077a70fdd92da  sub rsp, 0xF0
000077a70fdd92e1  vmovaps [rsp], xmm0
000077a70fdd92e6  vmovaps [rsp+0x10], xmm1
000077a70fdd92ec  vmovaps [rsp+0x20], xmm2
000077a70fdd92f2  vmovaps [rsp+0x30], xmm3
000077a70fdd92f8  vmovaps [rsp+0x40], xmm4
000077a70fdd92fe  vmovaps [rsp+0x50], xmm5
000077a70fdd9304  vmovaps [rsp+0x60], xmm7
000077a70fdd930a  vmovaps [rsp+0x70], xmm8
000077a70fdd9310  vmovaps [rsp+0x80], xmm9
000077a70fdd9319  vmovaps [rsp+0x90], xmm10
000077a70fdd9322  vmovaps [rsp+0xA0], xmm11
000077a70fdd932b  vmovaps [rsp+0xB0], xmm12
000077a70fdd9334  vmovaps [rsp+0xC0], xmm13
000077a70fdd933d  vmovaps [rsp+0xD0], xmm14
000077a70fdd9346  vmovaps [rsp+0xE0], xmm15
000077a70fdd934f  sub rsp, 0x30
000077a70fdd9353  movaps [rsp], xmm6
000077a70fdd9357  movaps [rsp+0x10], xmm10
000077a70fdd935d  movaps [rsp+0x20], xmm8
000077a70fdd9363  lea rdi, [rsp]
000077a70fdd9367  mov esi, 0x00
000077a70fdd936c  mov rax, 0x6294188EF530
000077a70fdd9376  call rax
000077a70fdd9378  movaps xmm6, [rsp]
000077a70fdd937c  add rsp, 0x30
000077a70fdd9380  vmovaps xmm0, [rsp]
000077a70fdd9385  vmovaps xmm1, [rsp+0x10]
000077a70fdd938b  vmovaps xmm2, [rsp+0x20]
000077a70fdd9391  vmovaps xmm3, [rsp+0x30]
000077a70fdd9397  vmovaps xmm4, [rsp+0x40]
000077a70fdd939d  vmovaps xmm5, [rsp+0x50]
000077a70fdd93a3  vmovaps xmm7, [rsp+0x60]
000077a70fdd93a9  vmovaps xmm8, [rsp+0x70]
000077a70fdd93af  vmovaps xmm9, [rsp+0x80]
000077a70fdd93b8  vmovaps xmm10, [rsp+0x90]
000077a70fdd93c1  vmovaps xmm11, [rsp+0xA0]
000077a70fdd93ca  vmovaps xmm12, [rsp+0xB0]
000077a70fdd93d3  vmovaps xmm13, [rsp+0xC0]
000077a70fdd93dc  vmovaps xmm14, [rsp+0xD0]
000077a70fdd93e5  vmovaps xmm15, [rsp+0xE0]
000077a70fdd93ee  add rsp, 0xF0
000077a70fdd93f5  pop r11
000077a70fdd93f7  pop r10
000077a70fdd93f9  pop r9
000077a70fdd93fb  pop r8
000077a70fdd93fd  pop rsi
000077a70fdd93fe  pop rdi
000077a70fdd93ff  pop rdx
000077a70fdd9400  pop rcx
000077a70fdd9401  pop rax
000077a70fdd9402  add rsp, 0x08
000077a70fdd9406  jmp 0x000077A70FDD6225
000077a70fdd940b  sub rsp, 0x08
000077a70fdd940f  push rax
000077a70fdd9410  push rcx
000077a70fdd9411  push rdx
000077a70fdd9412  push rdi
000077a70fdd9413  push rsi
000077a70fdd9414  push r8
000077a70fdd9416  push r9
000077a70fdd9418  push r10
000077a70fdd941a  push r11
000077a70fdd941c  sub rsp, 0xF0
000077a70fdd9423  vmovaps [rsp], xmm0
000077a70fdd9428  vmovaps [rsp+0x10], xmm1
000077a70fdd942e  vmovaps [rsp+0x20], xmm2
000077a70fdd9434  vmovaps [rsp+0x30], xmm3
000077a70fdd943a  vmovaps [rsp+0x40], xmm4
000077a70fdd9440  vmovaps [rsp+0x50], xmm5
000077a70fdd9446  vmovaps [rsp+0x60], xmm6
000077a70fdd944c  vmovaps [rsp+0x70], xmm7
000077a70fdd9452  vmovaps [rsp+0x80], xmm8
000077a70fdd945b  vmovaps [rsp+0x90], xmm9
000077a70fdd9464  vmovaps [rsp+0xA0], xmm11
000077a70fdd946d  vmovaps [rsp+0xB0], xmm12
000077a70fdd9476  vmovaps [rsp+0xC0], xmm13
000077a70fdd947f  vmovaps [rsp+0xD0], xmm14
000077a70fdd9488  vmovaps [rsp+0xE0], xmm15
000077a70fdd9491  sub rsp, 0x30
000077a70fdd9495  movaps [rsp], xmm10
000077a70fdd949a  movaps [rsp+0x10], xmm8
000077a70fdd94a0  movaps [rsp+0x20], xmm14
000077a70fdd94a6  lea rdi, [rsp]
000077a70fdd94aa  mov esi, 0x00
000077a70fdd94af  mov rax, 0x6294188EF530
000077a70fdd94b9  call rax
000077a70fdd94bb  movaps xmm10, [rsp]
000077a70fdd94c0  add rsp, 0x30
000077a70fdd94c4  vmovaps xmm0, [rsp]
000077a70fdd94c9  vmovaps xmm1, [rsp+0x10]
000077a70fdd94cf  vmovaps xmm2, [rsp+0x20]
000077a70fdd94d5  vmovaps xmm3, [rsp+0x30]
000077a70fdd94db  vmovaps xmm4, [rsp+0x40]
000077a70fdd94e1  vmovaps xmm5, [rsp+0x50]
000077a70fdd94e7  vmovaps xmm6, [rsp+0x60]
000077a70fdd94ed  vmovaps xmm7, [rsp+0x70]
000077a70fdd94f3  vmovaps xmm8, [rsp+0x80]
000077a70fdd94fc  vmovaps xmm9, [rsp+0x90]
000077a70fdd9505  vmovaps xmm11, [rsp+0xA0]
000077a70fdd950e  vmovaps xmm12, [rsp+0xB0]
000077a70fdd9517  vmovaps xmm13, [rsp+0xC0]
000077a70fdd9520  vmovaps xmm14, [rsp+0xD0]
000077a70fdd9529  vmovaps xmm15, [rsp+0xE0]
000077a70fdd9532  add rsp, 0xF0
000077a70fdd9539  pop r11
000077a70fdd953b  pop r10
000077a70fdd953d  pop r9
000077a70fdd953f  pop r8
000077a70fdd9541  pop rsi
000077a70fdd9542  pop rdi
000077a70fdd9543  pop rdx
000077a70fdd9544  pop rcx
000077a70fdd9545  pop rax
000077a70fdd9546  add rsp, 0x08
000077a70fdd954a  jmp 0x000077A70FDD6245
000077a70fdd954f  sub rsp, 0x08
000077a70fdd9553  push rax
000077a70fdd9554  push rcx
000077a70fdd9555  push rdx
000077a70fdd9556  push rdi
000077a70fdd9557  push rsi
000077a70fdd9558  push r8
000077a70fdd955a  push r9
000077a70fdd955c  push r10
000077a70fdd955e  push r11
000077a70fdd9560  sub rsp, 0xF0
000077a70fdd9567  vmovaps [rsp], xmm0
000077a70fdd956c  vmovaps [rsp+0x10], xmm1
000077a70fdd9572  vmovaps [rsp+0x20], xmm2
000077a70fdd9578  vmovaps [rsp+0x30], xmm3
000077a70fdd957e  vmovaps [rsp+0x40], xmm4
000077a70fdd9584  vmovaps [rsp+0x50], xmm5
000077a70fdd958a  vmovaps [rsp+0x60], xmm6
000077a70fdd9590  vmovaps [rsp+0x70], xmm7
000077a70fdd9596  vmovaps [rsp+0x80], xmm8
000077a70fdd959f  vmovaps [rsp+0x90], xmm9
000077a70fdd95a8  vmovaps [rsp+0xA0], xmm10
000077a70fdd95b1  vmovaps [rsp+0xB0], xmm11
000077a70fdd95ba  vmovaps [rsp+0xC0], xmm12
000077a70fdd95c3  vmovaps [rsp+0xD0], xmm13
000077a70fdd95cc  vmovaps [rsp+0xE0], xmm15
000077a70fdd95d5  sub rsp, 0x30
000077a70fdd95d9  movaps [rsp], xmm14
000077a70fdd95de  movaps [rsp+0x10], xmm8
000077a70fdd95e4  movaps [rsp+0x20], xmm4
000077a70fdd95e9  lea rdi, [rsp]
000077a70fdd95ed  mov esi, 0x00
000077a70fdd95f2  mov rax, 0x6294188EF530
000077a70fdd95fc  call rax
000077a70fdd95fe  movaps xmm14, [rsp]
000077a70fdd9603  add rsp, 0x30
000077a70fdd9607  vmovaps xmm0, [rsp]
000077a70fdd960c  vmovaps xmm1, [rsp+0x10]
000077a70fdd9612  vmovaps xmm2, [rsp+0x20]
000077a70fdd9618  vmovaps xmm3, [rsp+0x30]
000077a70fdd961e  vmovaps xmm4, [rsp+0x40]
000077a70fdd9624  vmovaps xmm5, [rsp+0x50]
000077a70fdd962a  vmovaps xmm6, [rsp+0x60]
000077a70fdd9630  vmovaps xmm7, [rsp+0x70]
000077a70fdd9636  vmovaps xmm8, [rsp+0x80]
000077a70fdd963f  vmovaps xmm9, [rsp+0x90]
000077a70fdd9648  vmovaps xmm10, [rsp+0xA0]
000077a70fdd9651  vmovaps xmm11, [rsp+0xB0]
000077a70fdd965a  vmovaps xmm12, [rsp+0xC0]
000077a70fdd9663  vmovaps xmm13, [rsp+0xD0]
000077a70fdd966c  vmovaps xmm15, [rsp+0xE0]
000077a70fdd9675  add rsp, 0xF0
000077a70fdd967c  pop r11
000077a70fdd967e  pop r10
000077a70fdd9680  pop r9
000077a70fdd9682  pop r8
000077a70fdd9684  pop rsi
000077a70fdd9685  pop rdi
000077a70fdd9686  pop rdx
000077a70fdd9687  pop rcx
000077a70fdd9688  pop rax
000077a70fdd9689  add rsp, 0x08
000077a70fdd968d  jmp 0x000077A70FDD6265
000077a70fdd9692  sub rsp, 0x08
000077a70fdd9696  push rax
000077a70fdd9697  push rcx
000077a70fdd9698  push rdx
000077a70fdd9699  push rdi
000077a70fdd969a  push rsi
000077a70fdd969b  push r8
000077a70fdd969d  push r9
000077a70fdd969f  push r10
000077a70fdd96a1  push r11
000077a70fdd96a3  sub rsp, 0xF0
000077a70fdd96aa  vmovaps [rsp], xmm0
000077a70fdd96af  vmovaps [rsp+0x10], xmm1
000077a70fdd96b5  vmovaps [rsp+0x20], xmm2
000077a70fdd96bb  vmovaps [rsp+0x30], xmm3
000077a70fdd96c1  vmovaps [rsp+0x40], xmm5
000077a70fdd96c7  vmovaps [rsp+0x50], xmm6
000077a70fdd96cd  vmovaps [rsp+0x60], xmm7
000077a70fdd96d3  vmovaps [rsp+0x70], xmm8
000077a70fdd96d9  vmovaps [rsp+0x80], xmm9
000077a70fdd96e2  vmovaps [rsp+0x90], xmm10
000077a70fdd96eb  vmovaps [rsp+0xA0], xmm11
000077a70fdd96f4  vmovaps [rsp+0xB0], xmm12
000077a70fdd96fd  vmovaps [rsp+0xC0], xmm13
000077a70fdd9706  vmovaps [rsp+0xD0], xmm14
000077a70fdd970f  vmovaps [rsp+0xE0], xmm15
000077a70fdd9718  sub rsp, 0x30
000077a70fdd971c  movaps [rsp], xmm4
000077a70fdd9720  movaps [rsp+0x10], xmm13
000077a70fdd9726  movaps [rsp+0x20], xmm8
000077a70fdd972c  lea rdi, [rsp]
000077a70fdd9730  mov esi, 0x00
000077a70fdd9735  mov rax, 0x6294188EF530
000077a70fdd973f  call rax
000077a70fdd9741  movaps xmm4, [rsp]
000077a70fdd9745  add rsp, 0x30
000077a70fdd9749  vmovaps xmm0, [rsp]
000077a70fdd974e  vmovaps xmm1, [rsp+0x10]
000077a70fdd9754  vmovaps xmm2, [rsp+0x20]
000077a70fdd975a  vmovaps xmm3, [rsp+0x30]
000077a70fdd9760  vmovaps xmm5, [rsp+0x40]
000077a70fdd9766  vmovaps xmm6, [rsp+0x50]
000077a70fdd976c  vmovaps xmm7, [rsp+0x60]
000077a70fdd9772  vmovaps xmm8, [rsp+0x70]
000077a70fdd9778  vmovaps xmm9, [rsp+0x80]
000077a70fdd9781  vmovaps xmm10, [rsp+0x90]
000077a70fdd978a  vmovaps xmm11, [rsp+0xA0]
000077a70fdd9793  vmovaps xmm12, [rsp+0xB0]
000077a70fdd979c  vmovaps xmm13, [rsp+0xC0]
000077a70fdd97a5  vmovaps xmm14, [rsp+0xD0]
000077a70fdd97ae  vmovaps xmm15, [rsp+0xE0]
000077a70fdd97b7  add rsp, 0xF0
000077a70fdd97be  pop r11
000077a70fdd97c0  pop r10
000077a70fdd97c2  pop r9
000077a70fdd97c4  pop r8
000077a70fdd97c6  pop rsi
000077a70fdd97c7  pop rdi
000077a70fdd97c8  pop rdx
000077a70fdd97c9  pop rcx
000077a70fdd97ca  pop rax
000077a70fdd97cb  add rsp, 0x08
000077a70fdd97cf  jmp 0x000077A70FDD628A
000077a70fdd97d4  sub rsp, 0x08
000077a70fdd97d8  push rax
000077a70fdd97d9  push rcx
000077a70fdd97da  push rdx
000077a70fdd97db  push rdi
000077a70fdd97dc  push rsi
000077a70fdd97dd  push r8
000077a70fdd97df  push r9
000077a70fdd97e1  push r10
000077a70fdd97e3  push r11
000077a70fdd97e5  sub rsp, 0xF0
000077a70fdd97ec  vmovaps [rsp], xmm0
000077a70fdd97f1  vmovaps [rsp+0x10], xmm1
000077a70fdd97f7  vmovaps [rsp+0x20], xmm2
000077a70fdd97fd  vmovaps [rsp+0x30], xmm3
000077a70fdd9803  vmovaps [rsp+0x40], xmm4
000077a70fdd9809  vmovaps [rsp+0x50], xmm5
000077a70fdd980f  vmovaps [rsp+0x60], xmm6
000077a70fdd9815  vmovaps [rsp+0x70], xmm7
000077a70fdd981b  vmovaps [rsp+0x80], xmm8
000077a70fdd9824  vmovaps [rsp+0x90], xmm9
000077a70fdd982d  vmovaps [rsp+0xA0], xmm10
000077a70fdd9836  vmovaps [rsp+0xB0], xmm11
000077a70fdd983f  vmovaps [rsp+0xC0], xmm12
000077a70fdd9848  vmovaps [rsp+0xD0], xmm14
000077a70fdd9851  vmovaps [rsp+0xE0], xmm15
000077a70fdd985a  sub rsp, 0x30
000077a70fdd985e  movaps [rsp], xmm13
000077a70fdd9863  movaps [rsp+0x10], xmm15
000077a70fdd9869  movaps [rsp+0x20], xmm9
000077a70fdd986f  lea rdi, [rsp]
000077a70fdd9873  mov esi, 0x00
000077a70fdd9878  mov rax, 0x6294188EF530
000077a70fdd9882  call rax
000077a70fdd9884  movaps xmm13, [rsp]
000077a70fdd9889  add rsp, 0x30
000077a70fdd988d  vmovaps xmm0, [rsp]
000077a70fdd9892  vmovaps xmm1, [rsp+0x10]
000077a70fdd9898  vmovaps xmm2, [rsp+0x20]
000077a70fdd989e  vmovaps xmm3, [rsp+0x30]
000077a70fdd98a4  vmovaps xmm4, [rsp+0x40]
000077a70fdd98aa  vmovaps xmm5, [rsp+0x50]
000077a70fdd98b0  vmovaps xmm6, [rsp+0x60]
000077a70fdd98b6  vmovaps xmm7, [rsp+0x70]
000077a70fdd98bc  vmovaps xmm8, [rsp+0x80]
000077a70fdd98c5  vmovaps xmm9, [rsp+0x90]
000077a70fdd98ce  vmovaps xmm10, [rsp+0xA0]
000077a70fdd98d7  vmovaps xmm11, [rsp+0xB0]
000077a70fdd98e0  vmovaps xmm12, [rsp+0xC0]
000077a70fdd98e9  vmovaps xmm14, [rsp+0xD0]
000077a70fdd98f2  vmovaps xmm15, [rsp+0xE0]
000077a70fdd98fb  add rsp, 0xF0
000077a70fdd9902  pop r11
000077a70fdd9904  pop r10
000077a70fdd9906  pop r9
000077a70fdd9908  pop r8
000077a70fdd990a  pop rsi
000077a70fdd990b  pop rdi
000077a70fdd990c  pop rdx
000077a70fdd990d  pop rcx
000077a70fdd990e  pop rax
000077a70fdd990f  add rsp, 0x08
000077a70fdd9913  jmp 0x000077A70FDD62A5
000077a70fdd9918  sub rsp, 0x08
000077a70fdd991c  push rax
000077a70fdd991d  push rcx
000077a70fdd991e  push rdx
000077a70fdd991f  push rdi
000077a70fdd9920  push rsi
000077a70fdd9921  push r8
000077a70fdd9923  push r9
000077a70fdd9925  push r10
000077a70fdd9927  push r11
000077a70fdd9929  sub rsp, 0xF0
000077a70fdd9930  vmovaps [rsp], xmm0
000077a70fdd9935  vmovaps [rsp+0x10], xmm1
000077a70fdd993b  vmovaps [rsp+0x20], xmm2
000077a70fdd9941  vmovaps [rsp+0x30], xmm3
000077a70fdd9947  vmovaps [rsp+0x40], xmm4
000077a70fdd994d  vmovaps [rsp+0x50], xmm5
000077a70fdd9953  vmovaps [rsp+0x60], xmm6
000077a70fdd9959  vmovaps [rsp+0x70], xmm7
000077a70fdd995f  vmovaps [rsp+0x80], xmm8
000077a70fdd9968  vmovaps [rsp+0x90], xmm9
000077a70fdd9971  vmovaps [rsp+0xA0], xmm10
000077a70fdd997a  vmovaps [rsp+0xB0], xmm11
000077a70fdd9983  vmovaps [rsp+0xC0], xmm12
000077a70fdd998c  vmovaps [rsp+0xD0], xmm13
000077a70fdd9995  vmovaps [rsp+0xE0], xmm14
000077a70fdd999e  sub rsp, 0x30
000077a70fdd99a2  movaps [rsp], xmm15
000077a70fdd99a7  movaps [rsp+0x10], xmm1
000077a70fdd99ac  movaps [rsp+0x20], xmm5
000077a70fdd99b1  lea rdi, [rsp]
000077a70fdd99b5  mov esi, 0x00
000077a70fdd99ba  mov rax, 0x6294188EF530
000077a70fdd99c4  call rax
000077a70fdd99c6  movaps xmm15, [rsp]
000077a70fdd99cb  add rsp, 0x30
000077a70fdd99cf  vmovaps xmm0, [rsp]
000077a70fdd99d4  vmovaps xmm1, [rsp+0x10]
000077a70fdd99da  vmovaps xmm2, [rsp+0x20]
000077a70fdd99e0  vmovaps xmm3, [rsp+0x30]
000077a70fdd99e6  vmovaps xmm4, [rsp+0x40]
000077a70fdd99ec  vmovaps xmm5, [rsp+0x50]
000077a70fdd99f2  vmovaps xmm6, [rsp+0x60]
000077a70fdd99f8  vmovaps xmm7, [rsp+0x70]
000077a70fdd99fe  vmovaps xmm8, [rsp+0x80]
000077a70fdd9a07  vmovaps xmm9, [rsp+0x90]
000077a70fdd9a10  vmovaps xmm10, [rsp+0xA0]
000077a70fdd9a19  vmovaps xmm11, [rsp+0xB0]
000077a70fdd9a22  vmovaps xmm12, [rsp+0xC0]
000077a70fdd9a2b  vmovaps xmm13, [rsp+0xD0]
000077a70fdd9a34  vmovaps xmm14, [rsp+0xE0]
000077a70fdd9a3d  add rsp, 0xF0
000077a70fdd9a44  pop r11
000077a70fdd9a46  pop r10
000077a70fdd9a48  pop r9
000077a70fdd9a4a  pop r8
000077a70fdd9a4c  pop rsi
000077a70fdd9a4d  pop rdi
000077a70fdd9a4e  pop rdx
000077a70fdd9a4f  pop rcx
000077a70fdd9a50  pop rax
000077a70fdd9a51  add rsp, 0x08
000077a70fdd9a55  jmp 0x000077A70FDD62C0
000077a70fdd9a5a  call 0x000077A70FCD64F0
000077a70fdd9a5f  jmp 0x000077A70FDD631B
000077a70fdd9a64  sub rsp, 0x08
000077a70fdd9a68  push rax
000077a70fdd9a69  push rcx
000077a70fdd9a6a  push rdx
000077a70fdd9a6b  push rdi
000077a70fdd9a6c  push rsi
000077a70fdd9a6d  push r8
000077a70fdd9a6f  push r9
000077a70fdd9a71  push r10
000077a70fdd9a73  push r11
000077a70fdd9a75  sub rsp, 0xF0
000077a70fdd9a7c  vmovaps [rsp], xmm0
000077a70fdd9a81  vmovaps [rsp+0x10], xmm1
000077a70fdd9a87  vmovaps [rsp+0x20], xmm2
000077a70fdd9a8d  vmovaps [rsp+0x30], xmm3
000077a70fdd9a93  vmovaps [rsp+0x40], xmm4
000077a70fdd9a99  vmovaps [rsp+0x50], xmm5
000077a70fdd9a9f  vmovaps [rsp+0x60], xmm6
000077a70fdd9aa5  vmovaps [rsp+0x70], xmm7
000077a70fdd9aab  vmovaps [rsp+0x80], xmm8
000077a70fdd9ab4  vmovaps [rsp+0x90], xmm10
000077a70fdd9abd  vmovaps [rsp+0xA0], xmm11
000077a70fdd9ac6  vmovaps [rsp+0xB0], xmm12
000077a70fdd9acf  vmovaps [rsp+0xC0], xmm13
000077a70fdd9ad8  vmovaps [rsp+0xD0], xmm14
000077a70fdd9ae1  vmovaps [rsp+0xE0], xmm15
000077a70fdd9aea  sub rsp, 0x30
000077a70fdd9aee  movaps [rsp], xmm9
000077a70fdd9af3  movaps [rsp+0x10], xmm8
000077a70fdd9af9  movaps [rsp+0x20], xmm11
000077a70fdd9aff  lea rdi, [rsp]
000077a70fdd9b03  mov esi, 0x00
000077a70fdd9b08  mov rax, 0x6294188EF530
000077a70fdd9b12  call rax
000077a70fdd9b14  movaps xmm9, [rsp]
000077a70fdd9b19  add rsp, 0x30
000077a70fdd9b1d  vmovaps xmm0, [rsp]
000077a70fdd9b22  vmovaps xmm1, [rsp+0x10]
000077a70fdd9b28  vmovaps xmm2, [rsp+0x20]
000077a70fdd9b2e  vmovaps xmm3, [rsp+0x30]
000077a70fdd9b34  vmovaps xmm4, [rsp+0x40]
000077a70fdd9b3a  vmovaps xmm5, [rsp+0x50]
000077a70fdd9b40  vmovaps xmm6, [rsp+0x60]
000077a70fdd9b46  vmovaps xmm7, [rsp+0x70]
000077a70fdd9b4c  vmovaps xmm8, [rsp+0x80]
000077a70fdd9b55  vmovaps xmm10, [rsp+0x90]
000077a70fdd9b5e  vmovaps xmm11, [rsp+0xA0]
000077a70fdd9b67  vmovaps xmm12, [rsp+0xB0]
000077a70fdd9b70  vmovaps xmm13, [rsp+0xC0]
000077a70fdd9b79  vmovaps xmm14, [rsp+0xD0]
000077a70fdd9b82  vmovaps xmm15, [rsp+0xE0]
000077a70fdd9b8b  add rsp, 0xF0
000077a70fdd9b92  pop r11
000077a70fdd9b94  pop r10
000077a70fdd9b96  pop r9
000077a70fdd9b98  pop r8
000077a70fdd9b9a  pop rsi
000077a70fdd9b9b  pop rdi
000077a70fdd9b9c  pop rdx
000077a70fdd9b9d  pop rcx
000077a70fdd9b9e  pop rax
000077a70fdd9b9f  add rsp, 0x08
000077a70fdd9ba3  jmp 0x000077A70FDD6352
000077a70fdd9ba8  sub rsp, 0x08
000077a70fdd9bac  push rax
000077a70fdd9bad  push rcx
000077a70fdd9bae  push rdx
000077a70fdd9baf  push rdi
000077a70fdd9bb0  push rsi
000077a70fdd9bb1  push r8
000077a70fdd9bb3  push r9
000077a70fdd9bb5  push r10
000077a70fdd9bb7  push r11
000077a70fdd9bb9  sub rsp, 0xF0
000077a70fdd9bc0  vmovaps [rsp], xmm0
000077a70fdd9bc5  vmovaps [rsp+0x10], xmm1
000077a70fdd9bcb  vmovaps [rsp+0x20], xmm2
000077a70fdd9bd1  vmovaps [rsp+0x30], xmm3
000077a70fdd9bd7  vmovaps [rsp+0x40], xmm4
000077a70fdd9bdd  vmovaps [rsp+0x50], xmm5
000077a70fdd9be3  vmovaps [rsp+0x60], xmm6
000077a70fdd9be9  vmovaps [rsp+0x70], xmm7
000077a70fdd9bef  vmovaps [rsp+0x80], xmm8
000077a70fdd9bf8  vmovaps [rsp+0x90], xmm9
000077a70fdd9c01  vmovaps [rsp+0xA0], xmm10
000077a70fdd9c0a  vmovaps [rsp+0xB0], xmm12
000077a70fdd9c13  vmovaps [rsp+0xC0], xmm13
000077a70fdd9c1c  vmovaps [rsp+0xD0], xmm14
000077a70fdd9c25  vmovaps [rsp+0xE0], xmm15
000077a70fdd9c2e  sub rsp, 0x30
000077a70fdd9c32  movaps [rsp], xmm11
000077a70fdd9c37  movaps [rsp+0x10], xmm10
000077a70fdd9c3d  movaps [rsp+0x20], xmm6
000077a70fdd9c42  lea rdi, [rsp]
000077a70fdd9c46  mov esi, 0x00
000077a70fdd9c4b  mov rax, 0x6294188EF530
000077a70fdd9c55  call rax
000077a70fdd9c57  movaps xmm11, [rsp]
000077a70fdd9c5c  add rsp, 0x30
000077a70fdd9c60  vmovaps xmm0, [rsp]
000077a70fdd9c65  vmovaps xmm1, [rsp+0x10]
000077a70fdd9c6b  vmovaps xmm2, [rsp+0x20]
000077a70fdd9c71  vmovaps xmm3, [rsp+0x30]
000077a70fdd9c77  vmovaps xmm4, [rsp+0x40]
000077a70fdd9c7d  vmovaps xmm5, [rsp+0x50]
000077a70fdd9c83  vmovaps xmm6, [rsp+0x60]
000077a70fdd9c89  vmovaps xmm7, [rsp+0x70]
000077a70fdd9c8f  vmovaps xmm8, [rsp+0x80]
000077a70fdd9c98  vmovaps xmm9, [rsp+0x90]
000077a70fdd9ca1  vmovaps xmm10, [rsp+0xA0]
000077a70fdd9caa  vmovaps xmm12, [rsp+0xB0]
000077a70fdd9cb3  vmovaps xmm13, [rsp+0xC0]
000077a70fdd9cbc  vmovaps xmm14, [rsp+0xD0]
000077a70fdd9cc5  vmovaps xmm15, [rsp+0xE0]
000077a70fdd9cce  add rsp, 0xF0
000077a70fdd9cd5  pop r11
000077a70fdd9cd7  pop r10
000077a70fdd9cd9  pop r9
000077a70fdd9cdb  pop r8
000077a70fdd9cdd  pop rsi
000077a70fdd9cde  pop rdi
000077a70fdd9cdf  pop rdx
000077a70fdd9ce0  pop rcx
000077a70fdd9ce1  pop rax
000077a70fdd9ce2  add rsp, 0x08
000077a70fdd9ce6  jmp 0x000077A70FDD636D
000077a70fdd9ceb  sub rsp, 0x08
000077a70fdd9cef  push rax
000077a70fdd9cf0  push rcx
000077a70fdd9cf1  push rdx
000077a70fdd9cf2  push rdi
000077a70fdd9cf3  push rsi
000077a70fdd9cf4  push r8
000077a70fdd9cf6  push r9
000077a70fdd9cf8  push r10
000077a70fdd9cfa  push r11
000077a70fdd9cfc  sub rsp, 0xF0
000077a70fdd9d03  vmovaps [rsp], xmm0
000077a70fdd9d08  vmovaps [rsp+0x10], xmm1
000077a70fdd9d0e  vmovaps [rsp+0x20], xmm2
000077a70fdd9d14  vmovaps [rsp+0x30], xmm3
000077a70fdd9d1a  vmovaps [rsp+0x40], xmm4
000077a70fdd9d20  vmovaps [rsp+0x50], xmm5
000077a70fdd9d26  vmovaps [rsp+0x60], xmm6
000077a70fdd9d2c  vmovaps [rsp+0x70], xmm7
000077a70fdd9d32  vmovaps [rsp+0x80], xmm8
000077a70fdd9d3b  vmovaps [rsp+0x90], xmm9
000077a70fdd9d44  vmovaps [rsp+0xA0], xmm11
000077a70fdd9d4d  vmovaps [rsp+0xB0], xmm12
000077a70fdd9d56  vmovaps [rsp+0xC0], xmm13
000077a70fdd9d5f  vmovaps [rsp+0xD0], xmm14
000077a70fdd9d68  vmovaps [rsp+0xE0], xmm15
000077a70fdd9d71  sub rsp, 0x30
000077a70fdd9d75  movaps [rsp], xmm10
000077a70fdd9d7a  movaps [rsp+0x10], xmm14
000077a70fdd9d80  movaps [rsp+0x20], xmm4
000077a70fdd9d85  lea rdi, [rsp]
000077a70fdd9d89  mov esi, 0x00
000077a70fdd9d8e  mov rax, 0x6294188EF530
000077a70fdd9d98  call rax
000077a70fdd9d9a  movaps xmm10, [rsp]
000077a70fdd9d9f  add rsp, 0x30
000077a70fdd9da3  vmovaps xmm0, [rsp]
000077a70fdd9da8  vmovaps xmm1, [rsp+0x10]
000077a70fdd9dae  vmovaps xmm2, [rsp+0x20]
000077a70fdd9db4  vmovaps xmm3, [rsp+0x30]
000077a70fdd9dba  vmovaps xmm4, [rsp+0x40]
000077a70fdd9dc0  vmovaps xmm5, [rsp+0x50]
000077a70fdd9dc6  vmovaps xmm6, [rsp+0x60]
000077a70fdd9dcc  vmovaps xmm7, [rsp+0x70]
000077a70fdd9dd2  vmovaps xmm8, [rsp+0x80]
000077a70fdd9ddb  vmovaps xmm9, [rsp+0x90]
000077a70fdd9de4  vmovaps xmm11, [rsp+0xA0]
000077a70fdd9ded  vmovaps xmm12, [rsp+0xB0]
000077a70fdd9df6  vmovaps xmm13, [rsp+0xC0]
000077a70fdd9dff  vmovaps xmm14, [rsp+0xD0]
000077a70fdd9e08  vmovaps xmm15, [rsp+0xE0]
000077a70fdd9e11  add rsp, 0xF0
000077a70fdd9e18  pop r11
000077a70fdd9e1a  pop r10
000077a70fdd9e1c  pop r9
000077a70fdd9e1e  pop r8
000077a70fdd9e20  pop rsi
000077a70fdd9e21  pop rdi
000077a70fdd9e22  pop rdx
000077a70fdd9e23  pop rcx
000077a70fdd9e24  pop rax
000077a70fdd9e25  add rsp, 0x08
000077a70fdd9e29  jmp 0x000077A70FDD6388
000077a70fdd9e2e  sub rsp, 0x08
000077a70fdd9e32  push rax
000077a70fdd9e33  push rcx
000077a70fdd9e34  push rdx
000077a70fdd9e35  push rdi
000077a70fdd9e36  push rsi
000077a70fdd9e37  push r8
000077a70fdd9e39  push r9
000077a70fdd9e3b  push r10
000077a70fdd9e3d  push r11
000077a70fdd9e3f  sub rsp, 0xF0
000077a70fdd9e46  vmovaps [rsp], xmm0
000077a70fdd9e4b  vmovaps [rsp+0x10], xmm1
000077a70fdd9e51  vmovaps [rsp+0x20], xmm2
000077a70fdd9e57  vmovaps [rsp+0x30], xmm3
000077a70fdd9e5d  vmovaps [rsp+0x40], xmm4
000077a70fdd9e63  vmovaps [rsp+0x50], xmm5
000077a70fdd9e69  vmovaps [rsp+0x60], xmm6
000077a70fdd9e6f  vmovaps [rsp+0x70], xmm7
000077a70fdd9e75  vmovaps [rsp+0x80], xmm9
000077a70fdd9e7e  vmovaps [rsp+0x90], xmm10
000077a70fdd9e87  vmovaps [rsp+0xA0], xmm11
000077a70fdd9e90  vmovaps [rsp+0xB0], xmm12
000077a70fdd9e99  vmovaps [rsp+0xC0], xmm13
000077a70fdd9ea2  vmovaps [rsp+0xD0], xmm14
000077a70fdd9eab  vmovaps [rsp+0xE0], xmm15
000077a70fdd9eb4  sub rsp, 0x30
000077a70fdd9eb8  movaps [rsp], xmm8
000077a70fdd9ebd  movaps [rsp+0x10], xmm1
000077a70fdd9ec2  movaps [rsp+0x20], xmm14
000077a70fdd9ec8  lea rdi, [rsp]
000077a70fdd9ecc  mov esi, 0x00
000077a70fdd9ed1  mov rax, 0x6294188EF530
000077a70fdd9edb  call rax
000077a70fdd9edd  movaps xmm8, [rsp]
000077a70fdd9ee2  add rsp, 0x30
000077a70fdd9ee6  vmovaps xmm0, [rsp]
000077a70fdd9eeb  vmovaps xmm1, [rsp+0x10]
000077a70fdd9ef1  vmovaps xmm2, [rsp+0x20]
000077a70fdd9ef7  vmovaps xmm3, [rsp+0x30]
000077a70fdd9efd  vmovaps xmm4, [rsp+0x40]
000077a70fdd9f03  vmovaps xmm5, [rsp+0x50]
000077a70fdd9f09  vmovaps xmm6, [rsp+0x60]
000077a70fdd9f0f  vmovaps xmm7, [rsp+0x70]
000077a70fdd9f15  vmovaps xmm9, [rsp+0x80]
000077a70fdd9f1e  vmovaps xmm10, [rsp+0x90]
000077a70fdd9f27  vmovaps xmm11, [rsp+0xA0]
000077a70fdd9f30  vmovaps xmm12, [rsp+0xB0]
000077a70fdd9f39  vmovaps xmm13, [rsp+0xC0]
000077a70fdd9f42  vmovaps xmm14, [rsp+0xD0]
000077a70fdd9f4b  vmovaps xmm15, [rsp+0xE0]
000077a70fdd9f54  add rsp, 0xF0
000077a70fdd9f5b  pop r11
000077a70fdd9f5d  pop r10
000077a70fdd9f5f  pop r9
000077a70fdd9f61  pop r8
000077a70fdd9f63  pop rsi
000077a70fdd9f64  pop rdi
000077a70fdd9f65  pop rdx
000077a70fdd9f66  pop rcx
000077a70fdd9f67  pop rax
000077a70fdd9f68  add rsp, 0x08
000077a70fdd9f6c  jmp 0x000077A70FDD63AE
000077a70fdd9f71  sub rsp, 0x08
000077a70fdd9f75  push rax
000077a70fdd9f76  push rcx
000077a70fdd9f77  push rdx
000077a70fdd9f78  push rdi
000077a70fdd9f79  push rsi
000077a70fdd9f7a  push r8
000077a70fdd9f7c  push r9
000077a70fdd9f7e  push r10
000077a70fdd9f80  push r11
000077a70fdd9f82  sub rsp, 0xF0
000077a70fdd9f89  vmovaps [rsp], xmm0
000077a70fdd9f8e  vmovaps [rsp+0x10], xmm1
000077a70fdd9f94  vmovaps [rsp+0x20], xmm2
000077a70fdd9f9a  vmovaps [rsp+0x30], xmm3
000077a70fdd9fa0  vmovaps [rsp+0x40], xmm4
000077a70fdd9fa6  vmovaps [rsp+0x50], xmm5
000077a70fdd9fac  vmovaps [rsp+0x60], xmm7
000077a70fdd9fb2  vmovaps [rsp+0x70], xmm8
000077a70fdd9fb8  vmovaps [rsp+0x80], xmm9
000077a70fdd9fc1  vmovaps [rsp+0x90], xmm10
000077a70fdd9fca  vmovaps [rsp+0xA0], xmm11
000077a70fdd9fd3  vmovaps [rsp+0xB0], xmm12
000077a70fdd9fdc  vmovaps [rsp+0xC0], xmm13
000077a70fdd9fe5  vmovaps [rsp+0xD0], xmm14
000077a70fdd9fee  vmovaps [rsp+0xE0], xmm15
000077a70fdd9ff7  sub rsp, 0x30
000077a70fdd9ffb  movaps [rsp], xmm6
000077a70fdd9fff  movaps [rsp+0x10], xmm1
000077a70fdda004  movaps [rsp+0x20], xmm14
000077a70fdda00a  lea rdi, [rsp]
000077a70fdda00e  mov esi, 0x00
000077a70fdda013  mov rax, 0x6294188EF530
000077a70fdda01d  call rax
000077a70fdda01f  movaps xmm6, [rsp]
000077a70fdda023  add rsp, 0x30
000077a70fdda027  vmovaps xmm0, [rsp]
000077a70fdda02c  vmovaps xmm1, [rsp+0x10]
000077a70fdda032  vmovaps xmm2, [rsp+0x20]
000077a70fdda038  vmovaps xmm3, [rsp+0x30]
000077a70fdda03e  vmovaps xmm4, [rsp+0x40]
000077a70fdda044  vmovaps xmm5, [rsp+0x50]
000077a70fdda04a  vmovaps xmm7, [rsp+0x60]
000077a70fdda050  vmovaps xmm8, [rsp+0x70]
000077a70fdda056  vmovaps xmm9, [rsp+0x80]
000077a70fdda05f  vmovaps xmm10, [rsp+0x90]
000077a70fdda068  vmovaps xmm11, [rsp+0xA0]
000077a70fdda071  vmovaps xmm12, [rsp+0xB0]
000077a70fdda07a  vmovaps xmm13, [rsp+0xC0]
000077a70fdda083  vmovaps xmm14, [rsp+0xD0]
000077a70fdda08c  vmovaps xmm15, [rsp+0xE0]
000077a70fdda095  add rsp, 0xF0
000077a70fdda09c  pop r11
000077a70fdda09e  pop r10
000077a70fdda0a0  pop r9
000077a70fdda0a2  pop r8
000077a70fdda0a4  pop rsi
000077a70fdda0a5  pop rdi
000077a70fdda0a6  pop rdx
000077a70fdda0a7  pop rcx
000077a70fdda0a8  pop rax
000077a70fdda0a9  add rsp, 0x08
000077a70fdda0ad  jmp 0x000077A70FDD63DA
000077a70fdda0b2  sub rsp, 0x08
000077a70fdda0b6  push rax
000077a70fdda0b7  push rcx
000077a70fdda0b8  push rdx
000077a70fdda0b9  push rdi
000077a70fdda0ba  push rsi
000077a70fdda0bb  push r8
000077a70fdda0bd  push r9
000077a70fdda0bf  push r10
000077a70fdda0c1  push r11
000077a70fdda0c3  sub rsp, 0xF0
000077a70fdda0ca  vmovaps [rsp], xmm0
000077a70fdda0cf  vmovaps [rsp+0x10], xmm1
000077a70fdda0d5  vmovaps [rsp+0x20], xmm2
000077a70fdda0db  vmovaps [rsp+0x30], xmm3
000077a70fdda0e1  vmovaps [rsp+0x40], xmm4
000077a70fdda0e7  vmovaps [rsp+0x50], xmm5
000077a70fdda0ed  vmovaps [rsp+0x60], xmm6
000077a70fdda0f3  vmovaps [rsp+0x70], xmm7
000077a70fdda0f9  vmovaps [rsp+0x80], xmm8
000077a70fdda102  vmovaps [rsp+0x90], xmm9
000077a70fdda10b  vmovaps [rsp+0xA0], xmm10
000077a70fdda114  vmovaps [rsp+0xB0], xmm11
000077a70fdda11d  vmovaps [rsp+0xC0], xmm12
000077a70fdda126  vmovaps [rsp+0xD0], xmm13
000077a70fdda12f  vmovaps [rsp+0xE0], xmm15
000077a70fdda138  sub rsp, 0x30
000077a70fdda13c  movaps [rsp], xmm14
000077a70fdda141  movaps [rsp+0x10], xmm12
000077a70fdda147  movaps [rsp+0x20], xmm1
000077a70fdda14c  lea rdi, [rsp]
000077a70fdda150  mov esi, 0x00
000077a70fdda155  mov rax, 0x6294188EF530
000077a70fdda15f  call rax
000077a70fdda161  movaps xmm14, [rsp]
000077a70fdda166  add rsp, 0x30
000077a70fdda16a  vmovaps xmm0, [rsp]
000077a70fdda16f  vmovaps xmm1, [rsp+0x10]
000077a70fdda175  vmovaps xmm2, [rsp+0x20]
000077a70fdda17b  vmovaps xmm3, [rsp+0x30]
000077a70fdda181  vmovaps xmm4, [rsp+0x40]
000077a70fdda187  vmovaps xmm5, [rsp+0x50]
000077a70fdda18d  vmovaps xmm6, [rsp+0x60]
000077a70fdda193  vmovaps xmm7, [rsp+0x70]
000077a70fdda199  vmovaps xmm8, [rsp+0x80]
000077a70fdda1a2  vmovaps xmm9, [rsp+0x90]
000077a70fdda1ab  vmovaps xmm10, [rsp+0xA0]
000077a70fdda1b4  vmovaps xmm11, [rsp+0xB0]
000077a70fdda1bd  vmovaps xmm12, [rsp+0xC0]
000077a70fdda1c6  vmovaps xmm13, [rsp+0xD0]
000077a70fdda1cf  vmovaps xmm15, [rsp+0xE0]
000077a70fdda1d8  add rsp, 0xF0
000077a70fdda1df  pop r11
000077a70fdda1e1  pop r10
000077a70fdda1e3  pop r9
000077a70fdda1e5  pop r8
000077a70fdda1e7  pop rsi
000077a70fdda1e8  pop rdi
000077a70fdda1e9  pop rdx
000077a70fdda1ea  pop rcx
000077a70fdda1eb  pop rax
000077a70fdda1ec  add rsp, 0x08
000077a70fdda1f0  jmp 0x000077A70FDD6400
000077a70fdda1f5  sub rsp, 0x08
000077a70fdda1f9  push rax
000077a70fdda1fa  push rcx
000077a70fdda1fb  push rdx
000077a70fdda1fc  push rdi
000077a70fdda1fd  push rsi
000077a70fdda1fe  push r8
000077a70fdda200  push r9
000077a70fdda202  push r10
000077a70fdda204  push r11
000077a70fdda206  sub rsp, 0xF0
000077a70fdda20d  vmovaps [rsp], xmm0
000077a70fdda212  vmovaps [rsp+0x10], xmm2
000077a70fdda218  vmovaps [rsp+0x20], xmm3
000077a70fdda21e  vmovaps [rsp+0x30], xmm4
000077a70fdda224  vmovaps [rsp+0x40], xmm5
000077a70fdda22a  vmovaps [rsp+0x50], xmm6
000077a70fdda230  vmovaps [rsp+0x60], xmm7
000077a70fdda236  vmovaps [rsp+0x70], xmm8
000077a70fdda23c  vmovaps [rsp+0x80], xmm9
000077a70fdda245  vmovaps [rsp+0x90], xmm10
000077a70fdda24e  vmovaps [rsp+0xA0], xmm11
000077a70fdda257  vmovaps [rsp+0xB0], xmm12
000077a70fdda260  vmovaps [rsp+0xC0], xmm13
000077a70fdda269  vmovaps [rsp+0xD0], xmm14
000077a70fdda272  vmovaps [rsp+0xE0], xmm15
000077a70fdda27b  sub rsp, 0x30
000077a70fdda27f  movaps [rsp], xmm1
000077a70fdda283  movaps [rsp+0x10], xmm13
000077a70fdda289  movaps [rsp+0x20], xmm9
000077a70fdda28f  lea rdi, [rsp]
000077a70fdda293  mov esi, 0x00
000077a70fdda298  mov rax, 0x6294188EF530
000077a70fdda2a2  call rax
000077a70fdda2a4  movaps xmm1, [rsp]
000077a70fdda2a8  add rsp, 0x30
000077a70fdda2ac  vmovaps xmm0, [rsp]
000077a70fdda2b1  vmovaps xmm2, [rsp+0x10]
000077a70fdda2b7  vmovaps xmm3, [rsp+0x20]
000077a70fdda2bd  vmovaps xmm4, [rsp+0x30]
000077a70fdda2c3  vmovaps xmm5, [rsp+0x40]
000077a70fdda2c9  vmovaps xmm6, [rsp+0x50]
000077a70fdda2cf  vmovaps xmm7, [rsp+0x60]
000077a70fdda2d5  vmovaps xmm8, [rsp+0x70]
000077a70fdda2db  vmovaps xmm9, [rsp+0x80]
000077a70fdda2e4  vmovaps xmm10, [rsp+0x90]
000077a70fdda2ed  vmovaps xmm11, [rsp+0xA0]
000077a70fdda2f6  vmovaps xmm12, [rsp+0xB0]
000077a70fdda2ff  vmovaps xmm13, [rsp+0xC0]
000077a70fdda308  vmovaps xmm14, [rsp+0xD0]
000077a70fdda311  vmovaps xmm15, [rsp+0xE0]
000077a70fdda31a  add rsp, 0xF0
000077a70fdda321  pop r11
000077a70fdda323  pop r10
000077a70fdda325  pop r9
000077a70fdda327  pop r8
000077a70fdda329  pop rsi
000077a70fdda32a  pop rdi
000077a70fdda32b  pop rdx
000077a70fdda32c  pop rcx
000077a70fdda32d  pop rax
000077a70fdda32e  add rsp, 0x08
000077a70fdda332  jmp 0x000077A70FDD641A
000077a70fdda337  sub rsp, 0x08
000077a70fdda33b  push rax
000077a70fdda33c  push rcx
000077a70fdda33d  push rdx
000077a70fdda33e  push rdi
000077a70fdda33f  push rsi
000077a70fdda340  push r8
000077a70fdda342  push r9
000077a70fdda344  push r10
000077a70fdda346  push r11
000077a70fdda348  sub rsp, 0xF0
000077a70fdda34f  vmovaps [rsp], xmm0
000077a70fdda354  vmovaps [rsp+0x10], xmm1
000077a70fdda35a  vmovaps [rsp+0x20], xmm2
000077a70fdda360  vmovaps [rsp+0x30], xmm3
000077a70fdda366  vmovaps [rsp+0x40], xmm4
000077a70fdda36c  vmovaps [rsp+0x50], xmm5
000077a70fdda372  vmovaps [rsp+0x60], xmm6
000077a70fdda378  vmovaps [rsp+0x70], xmm7
000077a70fdda37e  vmovaps [rsp+0x80], xmm8
000077a70fdda387  vmovaps [rsp+0x90], xmm9
000077a70fdda390  vmovaps [rsp+0xA0], xmm10
000077a70fdda399  vmovaps [rsp+0xB0], xmm11
000077a70fdda3a2  vmovaps [rsp+0xC0], xmm13
000077a70fdda3ab  vmovaps [rsp+0xD0], xmm14
000077a70fdda3b4  vmovaps [rsp+0xE0], xmm15
000077a70fdda3bd  sub rsp, 0x30
000077a70fdda3c1  movaps [rsp], xmm12
000077a70fdda3c6  movaps [rsp+0x10], xmm7
000077a70fdda3cb  movaps [rsp+0x20], xmm13
000077a70fdda3d1  lea rdi, [rsp]
000077a70fdda3d5  mov esi, 0x00
000077a70fdda3da  mov rax, 0x6294188EF530
000077a70fdda3e4  call rax
000077a70fdda3e6  movaps xmm12, [rsp]
000077a70fdda3eb  add rsp, 0x30
000077a70fdda3ef  vmovaps xmm0, [rsp]
000077a70fdda3f4  vmovaps xmm1, [rsp+0x10]
000077a70fdda3fa  vmovaps xmm2, [rsp+0x20]
000077a70fdda400  vmovaps xmm3, [rsp+0x30]
000077a70fdda406  vmovaps xmm4, [rsp+0x40]
000077a70fdda40c  vmovaps xmm5, [rsp+0x50]
000077a70fdda412  vmovaps xmm6, [rsp+0x60]
000077a70fdda418  vmovaps xmm7, [rsp+0x70]
000077a70fdda41e  vmovaps xmm8, [rsp+0x80]
000077a70fdda427  vmovaps xmm9, [rsp+0x90]
000077a70fdda430  vmovaps xmm10, [rsp+0xA0]
000077a70fdda439  vmovaps xmm11, [rsp+0xB0]
000077a70fdda442  vmovaps xmm13, [rsp+0xC0]
000077a70fdda44b  vmovaps xmm14, [rsp+0xD0]
000077a70fdda454  vmovaps xmm15, [rsp+0xE0]
000077a70fdda45d  add rsp, 0xF0
000077a70fdda464  pop r11
000077a70fdda466  pop r10
000077a70fdda468  pop r9
000077a70fdda46a  pop r8
000077a70fdda46c  pop rsi
000077a70fdda46d  pop rdi
000077a70fdda46e  pop rdx
000077a70fdda46f  pop rcx
000077a70fdda470  pop rax
000077a70fdda471  add rsp, 0x08
000077a70fdda475  jmp 0x000077A70FDD6441
000077a70fdda47a  sub rsp, 0x08
000077a70fdda47e  push rax
000077a70fdda47f  push rcx
000077a70fdda480  push rdx
000077a70fdda481  push rdi
000077a70fdda482  push rsi
000077a70fdda483  push r8
000077a70fdda485  push r9
000077a70fdda487  push r10
000077a70fdda489  push r11
000077a70fdda48b  sub rsp, 0xF0
000077a70fdda492  vmovaps [rsp], xmm0
000077a70fdda497  vmovaps [rsp+0x10], xmm1
000077a70fdda49d  vmovaps [rsp+0x20], xmm2
000077a70fdda4a3  vmovaps [rsp+0x30], xmm3
000077a70fdda4a9  vmovaps [rsp+0x40], xmm4
000077a70fdda4af  vmovaps [rsp+0x50], xmm5
000077a70fdda4b5  vmovaps [rsp+0x60], xmm6
000077a70fdda4bb  vmovaps [rsp+0x70], xmm7
000077a70fdda4c1  vmovaps [rsp+0x80], xmm8
000077a70fdda4ca  vmovaps [rsp+0x90], xmm9
000077a70fdda4d3  vmovaps [rsp+0xA0], xmm10
000077a70fdda4dc  vmovaps [rsp+0xB0], xmm11
000077a70fdda4e5  vmovaps [rsp+0xC0], xmm12
000077a70fdda4ee  vmovaps [rsp+0xD0], xmm14
000077a70fdda4f7  vmovaps [rsp+0xE0], xmm15
000077a70fdda500  sub rsp, 0x30
000077a70fdda504  movaps [rsp], xmm13
000077a70fdda509  movaps [rsp+0x10], xmm15
000077a70fdda50f  movaps [rsp+0x20], xmm8
000077a70fdda515  lea rdi, [rsp]
000077a70fdda519  mov esi, 0x00
000077a70fdda51e  mov rax, 0x6294188EF530
000077a70fdda528  call rax
000077a70fdda52a  movaps xmm13, [rsp]
000077a70fdda52f  add rsp, 0x30
000077a70fdda533  vmovaps xmm0, [rsp]
000077a70fdda538  vmovaps xmm1, [rsp+0x10]
000077a70fdda53e  vmovaps xmm2, [rsp+0x20]
000077a70fdda544  vmovaps xmm3, [rsp+0x30]
000077a70fdda54a  vmovaps xmm4, [rsp+0x40]
000077a70fdda550  vmovaps xmm5, [rsp+0x50]
000077a70fdda556  vmovaps xmm6, [rsp+0x60]
000077a70fdda55c  vmovaps xmm7, [rsp+0x70]
000077a70fdda562  vmovaps xmm8, [rsp+0x80]
000077a70fdda56b  vmovaps xmm9, [rsp+0x90]
000077a70fdda574  vmovaps xmm10, [rsp+0xA0]
000077a70fdda57d  vmovaps xmm11, [rsp+0xB0]
000077a70fdda586  vmovaps xmm12, [rsp+0xC0]
000077a70fdda58f  vmovaps xmm14, [rsp+0xD0]
000077a70fdda598  vmovaps xmm15, [rsp+0xE0]
000077a70fdda5a1  add rsp, 0xF0
000077a70fdda5a8  pop r11
000077a70fdda5aa  pop r10
000077a70fdda5ac  pop r9
000077a70fdda5ae  pop r8
000077a70fdda5b0  pop rsi
000077a70fdda5b1  pop rdi
000077a70fdda5b2  pop rdx
000077a70fdda5b3  pop rcx
000077a70fdda5b4  pop rax
000077a70fdda5b5  add rsp, 0x08
000077a70fdda5b9  jmp 0x000077A70FDD645C
000077a70fdda5be  sub rsp, 0x08
000077a70fdda5c2  push rax
000077a70fdda5c3  push rcx
000077a70fdda5c4  push rdx
000077a70fdda5c5  push rdi
000077a70fdda5c6  push rsi
000077a70fdda5c7  push r8
000077a70fdda5c9  push r9
000077a70fdda5cb  push r10
000077a70fdda5cd  push r11
000077a70fdda5cf  sub rsp, 0xF0
000077a70fdda5d6  vmovaps [rsp], xmm0
000077a70fdda5db  vmovaps [rsp+0x10], xmm1
000077a70fdda5e1  vmovaps [rsp+0x20], xmm2
000077a70fdda5e7  vmovaps [rsp+0x30], xmm3
000077a70fdda5ed  vmovaps [rsp+0x40], xmm4
000077a70fdda5f3  vmovaps [rsp+0x50], xmm5
000077a70fdda5f9  vmovaps [rsp+0x60], xmm6
000077a70fdda5ff  vmovaps [rsp+0x70], xmm7
000077a70fdda605  vmovaps [rsp+0x80], xmm9
000077a70fdda60e  vmovaps [rsp+0x90], xmm10
000077a70fdda617  vmovaps [rsp+0xA0], xmm11
000077a70fdda620  vmovaps [rsp+0xB0], xmm12
000077a70fdda629  vmovaps [rsp+0xC0], xmm13
000077a70fdda632  vmovaps [rsp+0xD0], xmm14
000077a70fdda63b  vmovaps [rsp+0xE0], xmm15
000077a70fdda644  sub rsp, 0x30
000077a70fdda648  movaps [rsp], xmm8
000077a70fdda64d  movaps [rsp+0x10], xmm15
000077a70fdda653  movaps [rsp+0x20], xmm9
000077a70fdda659  lea rdi, [rsp]
000077a70fdda65d  mov esi, 0x00
000077a70fdda662  mov rax, 0x6294188EF530
000077a70fdda66c  call rax
000077a70fdda66e  movaps xmm8, [rsp]
000077a70fdda673  add rsp, 0x30
000077a70fdda677  vmovaps xmm0, [rsp]
000077a70fdda67c  vmovaps xmm1, [rsp+0x10]
000077a70fdda682  vmovaps xmm2, [rsp+0x20]
000077a70fdda688  vmovaps xmm3, [rsp+0x30]
000077a70fdda68e  vmovaps xmm4, [rsp+0x40]
000077a70fdda694  vmovaps xmm5, [rsp+0x50]
000077a70fdda69a  vmovaps xmm6, [rsp+0x60]
000077a70fdda6a0  vmovaps xmm7, [rsp+0x70]
000077a70fdda6a6  vmovaps xmm9, [rsp+0x80]
000077a70fdda6af  vmovaps xmm10, [rsp+0x90]
000077a70fdda6b8  vmovaps xmm11, [rsp+0xA0]
000077a70fdda6c1  vmovaps xmm12, [rsp+0xB0]
000077a70fdda6ca  vmovaps xmm13, [rsp+0xC0]
000077a70fdda6d3  vmovaps xmm14, [rsp+0xD0]
000077a70fdda6dc  vmovaps xmm15, [rsp+0xE0]
000077a70fdda6e5  add rsp, 0xF0
000077a70fdda6ec  pop r11
000077a70fdda6ee  pop r10
000077a70fdda6f0  pop r9
000077a70fdda6f2  pop r8
000077a70fdda6f4  pop rsi
000077a70fdda6f5  pop rdi
000077a70fdda6f6  pop rdx
000077a70fdda6f7  pop rcx
000077a70fdda6f8  pop rax
000077a70fdda6f9  add rsp, 0x08
000077a70fdda6fd  jmp 0x000077A70FDD648A
000077a70fdda702  sub rsp, 0x08
000077a70fdda706  push rax
000077a70fdda707  push rcx
000077a70fdda708  push rdx
000077a70fdda709  push rdi
000077a70fdda70a  push rsi
000077a70fdda70b  push r8
000077a70fdda70d  push r9
000077a70fdda70f  push r10
000077a70fdda711  push r11
000077a70fdda713  sub rsp, 0xF0
000077a70fdda71a  vmovaps [rsp], xmm0
000077a70fdda71f  vmovaps [rsp+0x10], xmm1
000077a70fdda725  vmovaps [rsp+0x20], xmm2
000077a70fdda72b  vmovaps [rsp+0x30], xmm3
000077a70fdda731  vmovaps [rsp+0x40], xmm4
000077a70fdda737  vmovaps [rsp+0x50], xmm5
000077a70fdda73d  vmovaps [rsp+0x60], xmm6
000077a70fdda743  vmovaps [rsp+0x70], xmm7
000077a70fdda749  vmovaps [rsp+0x80], xmm8
000077a70fdda752  vmovaps [rsp+0x90], xmm9
000077a70fdda75b  vmovaps [rsp+0xA0], xmm10
000077a70fdda764  vmovaps [rsp+0xB0], xmm11
000077a70fdda76d  vmovaps [rsp+0xC0], xmm12
000077a70fdda776  vmovaps [rsp+0xD0], xmm13
000077a70fdda77f  vmovaps [rsp+0xE0], xmm14
000077a70fdda788  sub rsp, 0x30
000077a70fdda78c  movaps [rsp], xmm15
000077a70fdda791  movaps [rsp+0x10], xmm11
000077a70fdda797  movaps [rsp+0x20], xmm6
000077a70fdda79c  lea rdi, [rsp]
000077a70fdda7a0  mov esi, 0x00
000077a70fdda7a5  mov rax, 0x6294188EF530
000077a70fdda7af  call rax
000077a70fdda7b1  movaps xmm15, [rsp]
000077a70fdda7b6  add rsp, 0x30
000077a70fdda7ba  vmovaps xmm0, [rsp]
000077a70fdda7bf  vmovaps xmm1, [rsp+0x10]
000077a70fdda7c5  vmovaps xmm2, [rsp+0x20]
000077a70fdda7cb  vmovaps xmm3, [rsp+0x30]
000077a70fdda7d1  vmovaps xmm4, [rsp+0x40]
000077a70fdda7d7  vmovaps xmm5, [rsp+0x50]
000077a70fdda7dd  vmovaps xmm6, [rsp+0x60]
000077a70fdda7e3  vmovaps xmm7, [rsp+0x70]
000077a70fdda7e9  vmovaps xmm8, [rsp+0x80]
000077a70fdda7f2  vmovaps xmm9, [rsp+0x90]
000077a70fdda7fb  vmovaps xmm10, [rsp+0xA0]
000077a70fdda804  vmovaps xmm11, [rsp+0xB0]
000077a70fdda80d  vmovaps xmm12, [rsp+0xC0]
000077a70fdda816  vmovaps xmm13, [rsp+0xD0]
000077a70fdda81f  vmovaps xmm14, [rsp+0xE0]
000077a70fdda828  add rsp, 0xF0
000077a70fdda82f  pop r11
000077a70fdda831  pop r10
000077a70fdda833  pop r9
000077a70fdda835  pop r8
000077a70fdda837  pop rsi
000077a70fdda838  pop rdi
000077a70fdda839  pop rdx
000077a70fdda83a  pop rcx
000077a70fdda83b  pop rax
000077a70fdda83c  add rsp, 0x08
000077a70fdda840  jmp 0x000077A70FDD64A5
000077a70fdda845  sub rsp, 0x08
000077a70fdda849  push rax
000077a70fdda84a  push rcx
000077a70fdda84b  push rdx
000077a70fdda84c  push rdi
000077a70fdda84d  push rsi
000077a70fdda84e  push r8
000077a70fdda850  push r9
000077a70fdda852  push r10
000077a70fdda854  push r11
000077a70fdda856  sub rsp, 0xF0
000077a70fdda85d  vmovaps [rsp], xmm0
000077a70fdda862  vmovaps [rsp+0x10], xmm1
000077a70fdda868  vmovaps [rsp+0x20], xmm2
000077a70fdda86e  vmovaps [rsp+0x30], xmm3
000077a70fdda874  vmovaps [rsp+0x40], xmm4
000077a70fdda87a  vmovaps [rsp+0x50], xmm5
000077a70fdda880  vmovaps [rsp+0x60], xmm6
000077a70fdda886  vmovaps [rsp+0x70], xmm8
000077a70fdda88c  vmovaps [rsp+0x80], xmm9
000077a70fdda895  vmovaps [rsp+0x90], xmm10
000077a70fdda89e  vmovaps [rsp+0xA0], xmm11
000077a70fdda8a7  vmovaps [rsp+0xB0], xmm12
000077a70fdda8b0  vmovaps [rsp+0xC0], xmm13
000077a70fdda8b9  vmovaps [rsp+0xD0], xmm14
000077a70fdda8c2  vmovaps [rsp+0xE0], xmm15
000077a70fdda8cb  sub rsp, 0x30
000077a70fdda8cf  movaps [rsp], xmm7
000077a70fdda8d3  movaps [rsp+0x10], xmm11
000077a70fdda8d9  movaps [rsp+0x20], xmm9
000077a70fdda8df  lea rdi, [rsp]
000077a70fdda8e3  mov esi, 0x00
000077a70fdda8e8  mov rax, 0x6294188EF530
000077a70fdda8f2  call rax
000077a70fdda8f4  movaps xmm7, [rsp]
000077a70fdda8f8  add rsp, 0x30
000077a70fdda8fc  vmovaps xmm0, [rsp]
000077a70fdda901  vmovaps xmm1, [rsp+0x10]
000077a70fdda907  vmovaps xmm2, [rsp+0x20]
000077a70fdda90d  vmovaps xmm3, [rsp+0x30]
000077a70fdda913  vmovaps xmm4, [rsp+0x40]
000077a70fdda919  vmovaps xmm5, [rsp+0x50]
000077a70fdda91f  vmovaps xmm6, [rsp+0x60]
000077a70fdda925  vmovaps xmm8, [rsp+0x70]
000077a70fdda92b  vmovaps xmm9, [rsp+0x80]
000077a70fdda934  vmovaps xmm10, [rsp+0x90]
000077a70fdda93d  vmovaps xmm11, [rsp+0xA0]
000077a70fdda946  vmovaps xmm12, [rsp+0xB0]
000077a70fdda94f  vmovaps xmm13, [rsp+0xC0]
000077a70fdda958  vmovaps xmm14, [rsp+0xD0]
000077a70fdda961  vmovaps xmm15, [rsp+0xE0]
000077a70fdda96a  add rsp, 0xF0
000077a70fdda971  pop r11
000077a70fdda973  pop r10
000077a70fdda975  pop r9
000077a70fdda977  pop r8
000077a70fdda979  pop rsi
000077a70fdda97a  pop rdi
000077a70fdda97b  pop rdx
000077a70fdda97c  pop rcx
000077a70fdda97d  pop rax
000077a70fdda97e  add rsp, 0x08
000077a70fdda982  jmp 0x000077A70FDD64D2
000077a70fdda987  sub rsp, 0x08
000077a70fdda98b  push rax
000077a70fdda98c  push rcx
000077a70fdda98d  push rdx
000077a70fdda98e  push rdi
000077a70fdda98f  push rsi
000077a70fdda990  push r8
000077a70fdda992  push r9
000077a70fdda994  push r10
000077a70fdda996  push r11
000077a70fdda998  sub rsp, 0xF0
000077a70fdda99f  vmovaps [rsp], xmm0
000077a70fdda9a4  vmovaps [rsp+0x10], xmm1
000077a70fdda9aa  vmovaps [rsp+0x20], xmm2
000077a70fdda9b0  vmovaps [rsp+0x30], xmm3
000077a70fdda9b6  vmovaps [rsp+0x40], xmm4
000077a70fdda9bc  vmovaps [rsp+0x50], xmm5
000077a70fdda9c2  vmovaps [rsp+0x60], xmm6
000077a70fdda9c8  vmovaps [rsp+0x70], xmm7
000077a70fdda9ce  vmovaps [rsp+0x80], xmm8
000077a70fdda9d7  vmovaps [rsp+0x90], xmm9
000077a70fdda9e0  vmovaps [rsp+0xA0], xmm10
000077a70fdda9e9  vmovaps [rsp+0xB0], xmm12
000077a70fdda9f2  vmovaps [rsp+0xC0], xmm13
000077a70fdda9fb  vmovaps [rsp+0xD0], xmm14
000077a70fddaa04  vmovaps [rsp+0xE0], xmm15
000077a70fddaa0d  sub rsp, 0x30
000077a70fddaa11  movaps [rsp], xmm11
000077a70fddaa16  movaps [rsp+0x10], xmm10
000077a70fddaa1c  movaps [rsp+0x20], xmm14
000077a70fddaa22  lea rdi, [rsp]
000077a70fddaa26  mov esi, 0x00
000077a70fddaa2b  mov rax, 0x6294188EF530
000077a70fddaa35  call rax
000077a70fddaa37  movaps xmm11, [rsp]
000077a70fddaa3c  add rsp, 0x30
000077a70fddaa40  vmovaps xmm0, [rsp]
000077a70fddaa45  vmovaps xmm1, [rsp+0x10]
000077a70fddaa4b  vmovaps xmm2, [rsp+0x20]
000077a70fddaa51  vmovaps xmm3, [rsp+0x30]
000077a70fddaa57  vmovaps xmm4, [rsp+0x40]
000077a70fddaa5d  vmovaps xmm5, [rsp+0x50]
000077a70fddaa63  vmovaps xmm6, [rsp+0x60]
000077a70fddaa69  vmovaps xmm7, [rsp+0x70]
000077a70fddaa6f  vmovaps xmm8, [rsp+0x80]
000077a70fddaa78  vmovaps xmm9, [rsp+0x90]
000077a70fddaa81  vmovaps xmm10, [rsp+0xA0]
000077a70fddaa8a  vmovaps xmm12, [rsp+0xB0]
000077a70fddaa93  vmovaps xmm13, [rsp+0xC0]
000077a70fddaa9c  vmovaps xmm14, [rsp+0xD0]
000077a70fddaaa5  vmovaps xmm15, [rsp+0xE0]
000077a70fddaaae  add rsp, 0xF0
000077a70fddaab5  pop r11
000077a70fddaab7  pop r10
000077a70fddaab9  pop r9
000077a70fddaabb  pop r8
000077a70fddaabd  pop rsi
000077a70fddaabe  pop rdi
000077a70fddaabf  pop rdx
000077a70fddaac0  pop rcx
000077a70fddaac1  pop rax
000077a70fddaac2  add rsp, 0x08
000077a70fddaac6  jmp 0x000077A70FDD64ED
000077a70fddaacb  call 0x000077A70FCE45A0
000077a70fddaad0  jmp 0x000077A70FDD64F7
000077a70fddaad5  sub rsp, 0x08
000077a70fddaad9  push rax
000077a70fddaada  push rcx
000077a70fddaadb  push rdx
000077a70fddaadc  push rdi
000077a70fddaadd  push rsi
000077a70fddaade  push r8
000077a70fddaae0  push r9
000077a70fddaae2  push r10
000077a70fddaae4  push r11
000077a70fddaae6  sub rsp, 0xF0
000077a70fddaaed  vmovaps [rsp], xmm0
000077a70fddaaf2  vmovaps [rsp+0x10], xmm1
000077a70fddaaf8  vmovaps [rsp+0x20], xmm2
000077a70fddaafe  vmovaps [rsp+0x30], xmm3
000077a70fddab04  vmovaps [rsp+0x40], xmm4
000077a70fddab0a  vmovaps [rsp+0x50], xmm5
000077a70fddab10  vmovaps [rsp+0x60], xmm6
000077a70fddab16  vmovaps [rsp+0x70], xmm7
000077a70fddab1c  vmovaps [rsp+0x80], xmm8
000077a70fddab25  vmovaps [rsp+0x90], xmm9
000077a70fddab2e  vmovaps [rsp+0xA0], xmm11
000077a70fddab37  vmovaps [rsp+0xB0], xmm12
000077a70fddab40  vmovaps [rsp+0xC0], xmm13
000077a70fddab49  vmovaps [rsp+0xD0], xmm14
000077a70fddab52  vmovaps [rsp+0xE0], xmm15
000077a70fddab5b  sub rsp, 0x30
000077a70fddab5f  movaps [rsp], xmm10
000077a70fddab64  movaps [rsp+0x10], xmm1
000077a70fddab69  movaps [rsp+0x20], xmm12
000077a70fddab6f  lea rdi, [rsp]
000077a70fddab73  mov esi, 0x00
000077a70fddab78  mov rax, 0x6294188EF530
000077a70fddab82  call rax
000077a70fddab84  movaps xmm10, [rsp]
000077a70fddab89  add rsp, 0x30
000077a70fddab8d  vmovaps xmm0, [rsp]
000077a70fddab92  vmovaps xmm1, [rsp+0x10]
000077a70fddab98  vmovaps xmm2, [rsp+0x20]
000077a70fddab9e  vmovaps xmm3, [rsp+0x30]
000077a70fddaba4  vmovaps xmm4, [rsp+0x40]
000077a70fddabaa  vmovaps xmm5, [rsp+0x50]
000077a70fddabb0  vmovaps xmm6, [rsp+0x60]
000077a70fddabb6  vmovaps xmm7, [rsp+0x70]
000077a70fddabbc  vmovaps xmm8, [rsp+0x80]
000077a70fddabc5  vmovaps xmm9, [rsp+0x90]
000077a70fddabce  vmovaps xmm11, [rsp+0xA0]
000077a70fddabd7  vmovaps xmm12, [rsp+0xB0]
000077a70fddabe0  vmovaps xmm13, [rsp+0xC0]
000077a70fddabe9  vmovaps xmm14, [rsp+0xD0]
000077a70fddabf2  vmovaps xmm15, [rsp+0xE0]
000077a70fddabfb  add rsp, 0xF0
000077a70fddac02  pop r11
000077a70fddac04  pop r10
000077a70fddac06  pop r9
000077a70fddac08  pop r8
000077a70fddac0a  pop rsi
000077a70fddac0b  pop rdi
000077a70fddac0c  pop rdx
000077a70fddac0d  pop rcx
000077a70fddac0e  pop rax
000077a70fddac0f  add rsp, 0x08
000077a70fddac13  jmp 0x000077A70FDD651A
000077a70fddac18  sub rsp, 0x08
000077a70fddac1c  push rax
000077a70fddac1d  push rcx
000077a70fddac1e  push rdx
000077a70fddac1f  push rdi
000077a70fddac20  push rsi
000077a70fddac21  push r8
000077a70fddac23  push r9
000077a70fddac25  push r10
000077a70fddac27  push r11
000077a70fddac29  sub rsp, 0xF0
000077a70fddac30  vmovaps [rsp], xmm0
000077a70fddac35  vmovaps [rsp+0x10], xmm1
000077a70fddac3b  vmovaps [rsp+0x20], xmm2
000077a70fddac41  vmovaps [rsp+0x30], xmm3
000077a70fddac47  vmovaps [rsp+0x40], xmm4
000077a70fddac4d  vmovaps [rsp+0x50], xmm5
000077a70fddac53  vmovaps [rsp+0x60], xmm6
000077a70fddac59  vmovaps [rsp+0x70], xmm7
000077a70fddac5f  vmovaps [rsp+0x80], xmm8
000077a70fddac68  vmovaps [rsp+0x90], xmm9
000077a70fddac71  vmovaps [rsp+0xA0], xmm10
000077a70fddac7a  vmovaps [rsp+0xB0], xmm11
000077a70fddac83  vmovaps [rsp+0xC0], xmm13
000077a70fddac8c  vmovaps [rsp+0xD0], xmm14
000077a70fddac95  vmovaps [rsp+0xE0], xmm15
000077a70fddac9e  sub rsp, 0x30
000077a70fddaca2  movaps [rsp], xmm12
000077a70fddaca7  movaps [rsp+0x10], xmm14
000077a70fddacad  movaps [rsp+0x20], xmm1
000077a70fddacb2  lea rdi, [rsp]
000077a70fddacb6  mov esi, 0x00
000077a70fddacbb  mov rax, 0x6294188EF530
000077a70fddacc5  call rax
000077a70fddacc7  movaps xmm12, [rsp]
000077a70fddaccc  add rsp, 0x30
000077a70fddacd0  vmovaps xmm0, [rsp]
000077a70fddacd5  vmovaps xmm1, [rsp+0x10]
000077a70fddacdb  vmovaps xmm2, [rsp+0x20]
000077a70fddace1  vmovaps xmm3, [rsp+0x30]
000077a70fddace7  vmovaps xmm4, [rsp+0x40]
000077a70fddaced  vmovaps xmm5, [rsp+0x50]
000077a70fddacf3  vmovaps xmm6, [rsp+0x60]
000077a70fddacf9  vmovaps xmm7, [rsp+0x70]
000077a70fddacff  vmovaps xmm8, [rsp+0x80]
000077a70fddad08  vmovaps xmm9, [rsp+0x90]
000077a70fddad11  vmovaps xmm10, [rsp+0xA0]
000077a70fddad1a  vmovaps xmm11, [rsp+0xB0]
000077a70fddad23  vmovaps xmm13, [rsp+0xC0]
000077a70fddad2c  vmovaps xmm14, [rsp+0xD0]
000077a70fddad35  vmovaps xmm15, [rsp+0xE0]
000077a70fddad3e  add rsp, 0xF0
000077a70fddad45  pop r11
000077a70fddad47  pop r10
000077a70fddad49  pop r9
000077a70fddad4b  pop r8
000077a70fddad4d  pop rsi
000077a70fddad4e  pop rdi
000077a70fddad4f  pop rdx
000077a70fddad50  pop rcx
000077a70fddad51  pop rax
000077a70fddad52  add rsp, 0x08
000077a70fddad56  jmp 0x000077A70FDD6549
000077a70fddad5b  sub rsp, 0x08
000077a70fddad5f  push rax
000077a70fddad60  push rcx
000077a70fddad61  push rdx
000077a70fddad62  push rdi
000077a70fddad63  push rsi
000077a70fddad64  push r8
000077a70fddad66  push r9
000077a70fddad68  push r10
000077a70fddad6a  push r11
000077a70fddad6c  sub rsp, 0xF0
000077a70fddad73  vmovaps [rsp], xmm0
000077a70fddad78  vmovaps [rsp+0x10], xmm1
000077a70fddad7e  vmovaps [rsp+0x20], xmm2
000077a70fddad84  vmovaps [rsp+0x30], xmm3
000077a70fddad8a  vmovaps [rsp+0x40], xmm4
000077a70fddad90  vmovaps [rsp+0x50], xmm5
000077a70fddad96  vmovaps [rsp+0x60], xmm6
000077a70fddad9c  vmovaps [rsp+0x70], xmm7
000077a70fddada2  vmovaps [rsp+0x80], xmm8
000077a70fddadab  vmovaps [rsp+0x90], xmm9
000077a70fddadb4  vmovaps [rsp+0xA0], xmm10
000077a70fddadbd  vmovaps [rsp+0xB0], xmm11
000077a70fddadc6  vmovaps [rsp+0xC0], xmm12
000077a70fddadcf  vmovaps [rsp+0xD0], xmm13
000077a70fddadd8  vmovaps [rsp+0xE0], xmm15
000077a70fddade1  sub rsp, 0x30
000077a70fddade5  movaps [rsp], xmm14
000077a70fddadea  movaps [rsp+0x10], xmm9
000077a70fddadf0  movaps [rsp+0x20], xmm1
000077a70fddadf5  lea rdi, [rsp]
000077a70fddadf9  mov esi, 0x00
000077a70fddadfe  mov rax, 0x6294188EF530
000077a70fddae08  call rax
000077a70fddae0a  movaps xmm14, [rsp]
000077a70fddae0f  add rsp, 0x30
000077a70fddae13  vmovaps xmm0, [rsp]
000077a70fddae18  vmovaps xmm1, [rsp+0x10]
000077a70fddae1e  vmovaps xmm2, [rsp+0x20]
000077a70fddae24  vmovaps xmm3, [rsp+0x30]
000077a70fddae2a  vmovaps xmm4, [rsp+0x40]
000077a70fddae30  vmovaps xmm5, [rsp+0x50]
000077a70fddae36  vmovaps xmm6, [rsp+0x60]
000077a70fddae3c  vmovaps xmm7, [rsp+0x70]
000077a70fddae42  vmovaps xmm8, [rsp+0x80]
000077a70fddae4b  vmovaps xmm9, [rsp+0x90]
000077a70fddae54  vmovaps xmm10, [rsp+0xA0]
000077a70fddae5d  vmovaps xmm11, [rsp+0xB0]
000077a70fddae66  vmovaps xmm12, [rsp+0xC0]
000077a70fddae6f  vmovaps xmm13, [rsp+0xD0]
000077a70fddae78  vmovaps xmm15, [rsp+0xE0]
000077a70fddae81  add rsp, 0xF0
000077a70fddae88  pop r11
000077a70fddae8a  pop r10
000077a70fddae8c  pop r9
000077a70fddae8e  pop r8
000077a70fddae90  pop rsi
000077a70fddae91  pop rdi
000077a70fddae92  pop rdx
000077a70fddae93  pop rcx
000077a70fddae94  pop rax
000077a70fddae95  add rsp, 0x08
000077a70fddae99  jmp 0x000077A70FDD6578
000077a70fddae9e  sub rsp, 0x08
000077a70fddaea2  push rax
000077a70fddaea3  push rcx
000077a70fddaea4  push rdx
000077a70fddaea5  push rdi
000077a70fddaea6  push rsi
000077a70fddaea7  push r8
000077a70fddaea9  push r9
000077a70fddaeab  push r10
000077a70fddaead  push r11
000077a70fddaeaf  sub rsp, 0xF0
000077a70fddaeb6  vmovaps [rsp], xmm0
000077a70fddaebb  vmovaps [rsp+0x10], xmm2
000077a70fddaec1  vmovaps [rsp+0x20], xmm3
000077a70fddaec7  vmovaps [rsp+0x30], xmm4
000077a70fddaecd  vmovaps [rsp+0x40], xmm5
000077a70fddaed3  vmovaps [rsp+0x50], xmm6
000077a70fddaed9  vmovaps [rsp+0x60], xmm7
000077a70fddaedf  vmovaps [rsp+0x70], xmm8
000077a70fddaee5  vmovaps [rsp+0x80], xmm9
000077a70fddaeee  vmovaps [rsp+0x90], xmm10
000077a70fddaef7  vmovaps [rsp+0xA0], xmm11
000077a70fddaf00  vmovaps [rsp+0xB0], xmm12
000077a70fddaf09  vmovaps [rsp+0xC0], xmm13
000077a70fddaf12  vmovaps [rsp+0xD0], xmm14
000077a70fddaf1b  vmovaps [rsp+0xE0], xmm15
000077a70fddaf24  sub rsp, 0x30
000077a70fddaf28  movaps [rsp], xmm1
000077a70fddaf2c  movaps [rsp+0x10], xmm13
000077a70fddaf32  movaps [rsp+0x20], xmm8
000077a70fddaf38  lea rdi, [rsp]
000077a70fddaf3c  mov esi, 0x00
000077a70fddaf41  mov rax, 0x6294188EF530
000077a70fddaf4b  call rax
000077a70fddaf4d  movaps xmm1, [rsp]
000077a70fddaf51  add rsp, 0x30
000077a70fddaf55  vmovaps xmm0, [rsp]
000077a70fddaf5a  vmovaps xmm2, [rsp+0x10]
000077a70fddaf60  vmovaps xmm3, [rsp+0x20]
000077a70fddaf66  vmovaps xmm4, [rsp+0x30]
000077a70fddaf6c  vmovaps xmm5, [rsp+0x40]
000077a70fddaf72  vmovaps xmm6, [rsp+0x50]
000077a70fddaf78  vmovaps xmm7, [rsp+0x60]
000077a70fddaf7e  vmovaps xmm8, [rsp+0x70]
000077a70fddaf84  vmovaps xmm9, [rsp+0x80]
000077a70fddaf8d  vmovaps xmm10, [rsp+0x90]
000077a70fddaf96  vmovaps xmm11, [rsp+0xA0]
000077a70fddaf9f  vmovaps xmm12, [rsp+0xB0]
000077a70fddafa8  vmovaps xmm13, [rsp+0xC0]
000077a70fddafb1  vmovaps xmm14, [rsp+0xD0]
000077a70fddafba  vmovaps xmm15, [rsp+0xE0]
000077a70fddafc3  add rsp, 0xF0
000077a70fddafca  pop r11
000077a70fddafcc  pop r10
000077a70fddafce  pop r9
000077a70fddafd0  pop r8
000077a70fddafd2  pop rsi
000077a70fddafd3  pop rdi
000077a70fddafd4  pop rdx
000077a70fddafd5  pop rcx
000077a70fddafd6  pop rax
000077a70fddafd7  add rsp, 0x08
000077a70fddafdb  jmp 0x000077A70FDD659A
000077a70fddafe0  call 0x000077A70FC0C260
000077a70fddafe5  jmp 0x000077A70FDD65A8
000077a70fddafea  call 0x000077A70FCDE950
000077a70fddafef  jmp 0x000077A70FDD65B2
000077a70fddaff4  sub rsp, 0x08
000077a70fddaff8  push rax
000077a70fddaff9  push rcx
000077a70fddaffa  push rdx
000077a70fddaffb  push rdi
000077a70fddaffc  push rsi
000077a70fddaffd  push r8
000077a70fddafff  push r9
000077a70fddb001  push r10
000077a70fddb003  push r11
000077a70fddb005  sub rsp, 0xF0
000077a70fddb00c  vmovaps [rsp], xmm0
000077a70fddb011  vmovaps [rsp+0x10], xmm1
000077a70fddb017  vmovaps [rsp+0x20], xmm2
000077a70fddb01d  vmovaps [rsp+0x30], xmm3
000077a70fddb023  vmovaps [rsp+0x40], xmm4
000077a70fddb029  vmovaps [rsp+0x50], xmm5
000077a70fddb02f  vmovaps [rsp+0x60], xmm6
000077a70fddb035  vmovaps [rsp+0x70], xmm7
000077a70fddb03b  vmovaps [rsp+0x80], xmm9
000077a70fddb044  vmovaps [rsp+0x90], xmm10
000077a70fddb04d  vmovaps [rsp+0xA0], xmm11
000077a70fddb056  vmovaps [rsp+0xB0], xmm12
000077a70fddb05f  vmovaps [rsp+0xC0], xmm13
000077a70fddb068  vmovaps [rsp+0xD0], xmm14
000077a70fddb071  vmovaps [rsp+0xE0], xmm15
000077a70fddb07a  sub rsp, 0x30
000077a70fddb07e  movaps [rsp], xmm8
000077a70fddb083  movaps [rsp+0x10], xmm15
000077a70fddb089  movaps [rsp+0x20], xmm7
000077a70fddb08e  lea rdi, [rsp]
000077a70fddb092  mov esi, 0x00
000077a70fddb097  mov rax, 0x6294188EF530
000077a70fddb0a1  call rax
000077a70fddb0a3  movaps xmm8, [rsp]
000077a70fddb0a8  add rsp, 0x30
000077a70fddb0ac  vmovaps xmm0, [rsp]
000077a70fddb0b1  vmovaps xmm1, [rsp+0x10]
000077a70fddb0b7  vmovaps xmm2, [rsp+0x20]
000077a70fddb0bd  vmovaps xmm3, [rsp+0x30]
000077a70fddb0c3  vmovaps xmm4, [rsp+0x40]
000077a70fddb0c9  vmovaps xmm5, [rsp+0x50]
000077a70fddb0cf  vmovaps xmm6, [rsp+0x60]
000077a70fddb0d5  vmovaps xmm7, [rsp+0x70]
000077a70fddb0db  vmovaps xmm9, [rsp+0x80]
000077a70fddb0e4  vmovaps xmm10, [rsp+0x90]
000077a70fddb0ed  vmovaps xmm11, [rsp+0xA0]
000077a70fddb0f6  vmovaps xmm12, [rsp+0xB0]
000077a70fddb0ff  vmovaps xmm13, [rsp+0xC0]
000077a70fddb108  vmovaps xmm14, [rsp+0xD0]
000077a70fddb111  vmovaps xmm15, [rsp+0xE0]
000077a70fddb11a  add rsp, 0xF0
000077a70fddb121  pop r11
000077a70fddb123  pop r10
000077a70fddb125  pop r9
000077a70fddb127  pop r8
000077a70fddb129  pop rsi
000077a70fddb12a  pop rdi
000077a70fddb12b  pop rdx
000077a70fddb12c  pop rcx
000077a70fddb12d  pop rax
000077a70fddb12e  add rsp, 0x08
000077a70fddb132  jmp 0x000077A70FDD65D4
000077a70fddb137  sub rsp, 0x08
000077a70fddb13b  push rax
000077a70fddb13c  push rcx
000077a70fddb13d  push rdx
000077a70fddb13e  push rdi
000077a70fddb13f  push rsi
000077a70fddb140  push r8
000077a70fddb142  push r9
000077a70fddb144  push r10
000077a70fddb146  push r11
000077a70fddb148  sub rsp, 0xF0
000077a70fddb14f  vmovaps [rsp], xmm0
000077a70fddb154  vmovaps [rsp+0x10], xmm1
000077a70fddb15a  vmovaps [rsp+0x20], xmm2
000077a70fddb160  vmovaps [rsp+0x30], xmm3
000077a70fddb166  vmovaps [rsp+0x40], xmm4
000077a70fddb16c  vmovaps [rsp+0x50], xmm5
000077a70fddb172  vmovaps [rsp+0x60], xmm6
000077a70fddb178  vmovaps [rsp+0x70], xmm8
000077a70fddb17e  vmovaps [rsp+0x80], xmm9
000077a70fddb187  vmovaps [rsp+0x90], xmm10
000077a70fddb190  vmovaps [rsp+0xA0], xmm11
000077a70fddb199  vmovaps [rsp+0xB0], xmm12
000077a70fddb1a2  vmovaps [rsp+0xC0], xmm13
000077a70fddb1ab  vmovaps [rsp+0xD0], xmm14
000077a70fddb1b4  vmovaps [rsp+0xE0], xmm15
000077a70fddb1bd  sub rsp, 0x30
000077a70fddb1c1  movaps [rsp], xmm7
000077a70fddb1c5  movaps [rsp+0x10], xmm9
000077a70fddb1cb  movaps [rsp+0x20], xmm15
000077a70fddb1d1  lea rdi, [rsp]
000077a70fddb1d5  mov esi, 0x00
000077a70fddb1da  mov rax, 0x6294188EF530
000077a70fddb1e4  call rax
000077a70fddb1e6  movaps xmm7, [rsp]
000077a70fddb1ea  add rsp, 0x30
000077a70fddb1ee  vmovaps xmm0, [rsp]
000077a70fddb1f3  vmovaps xmm1, [rsp+0x10]
000077a70fddb1f9  vmovaps xmm2, [rsp+0x20]
000077a70fddb1ff  vmovaps xmm3, [rsp+0x30]
000077a70fddb205  vmovaps xmm4, [rsp+0x40]
000077a70fddb20b  vmovaps xmm5, [rsp+0x50]
000077a70fddb211  vmovaps xmm6, [rsp+0x60]
000077a70fddb217  vmovaps xmm8, [rsp+0x70]
000077a70fddb21d  vmovaps xmm9, [rsp+0x80]
000077a70fddb226  vmovaps xmm10, [rsp+0x90]
000077a70fddb22f  vmovaps xmm11, [rsp+0xA0]
000077a70fddb238  vmovaps xmm12, [rsp+0xB0]
000077a70fddb241  vmovaps xmm13, [rsp+0xC0]
000077a70fddb24a  vmovaps xmm14, [rsp+0xD0]
000077a70fddb253  vmovaps xmm15, [rsp+0xE0]
000077a70fddb25c  add rsp, 0xF0
000077a70fddb263  pop r11
000077a70fddb265  pop r10
000077a70fddb267  pop r9
000077a70fddb269  pop r8
000077a70fddb26b  pop rsi
000077a70fddb26c  pop rdi
000077a70fddb26d  pop rdx
000077a70fddb26e  pop rcx
000077a70fddb26f  pop rax
000077a70fddb270  add rsp, 0x08
000077a70fddb274  jmp 0x000077A70FDD6601
000077a70fddb279  sub rsp, 0x08
000077a70fddb27d  push rax
000077a70fddb27e  push rcx
000077a70fddb27f  push rdx
000077a70fddb280  push rdi
000077a70fddb281  push rsi
000077a70fddb282  push r8
000077a70fddb284  push r9
000077a70fddb286  push r10
000077a70fddb288  push r11
000077a70fddb28a  sub rsp, 0xF0
000077a70fddb291  vmovaps [rsp], xmm0
000077a70fddb296  vmovaps [rsp+0x10], xmm1
000077a70fddb29c  vmovaps [rsp+0x20], xmm2
000077a70fddb2a2  vmovaps [rsp+0x30], xmm3
000077a70fddb2a8  vmovaps [rsp+0x40], xmm4
000077a70fddb2ae  vmovaps [rsp+0x50], xmm5
000077a70fddb2b4  vmovaps [rsp+0x60], xmm6
000077a70fddb2ba  vmovaps [rsp+0x70], xmm7
000077a70fddb2c0  vmovaps [rsp+0x80], xmm8
000077a70fddb2c9  vmovaps [rsp+0x90], xmm10
000077a70fddb2d2  vmovaps [rsp+0xA0], xmm11
000077a70fddb2db  vmovaps [rsp+0xB0], xmm12
000077a70fddb2e4  vmovaps [rsp+0xC0], xmm13
000077a70fddb2ed  vmovaps [rsp+0xD0], xmm14
000077a70fddb2f6  vmovaps [rsp+0xE0], xmm15
000077a70fddb2ff  sub rsp, 0x30
000077a70fddb303  movaps [rsp], xmm9
000077a70fddb308  movaps [rsp+0x10], xmm13
000077a70fddb30e  movaps [rsp+0x20], xmm15
000077a70fddb314  lea rdi, [rsp]
000077a70fddb318  mov esi, 0x00
000077a70fddb31d  mov rax, 0x6294188EF530
000077a70fddb327  call rax
000077a70fddb329  movaps xmm9, [rsp]
000077a70fddb32e  add rsp, 0x30
000077a70fddb332  vmovaps xmm0, [rsp]
000077a70fddb337  vmovaps xmm1, [rsp+0x10]
000077a70fddb33d  vmovaps xmm2, [rsp+0x20]
000077a70fddb343  vmovaps xmm3, [rsp+0x30]
000077a70fddb349  vmovaps xmm4, [rsp+0x40]
000077a70fddb34f  vmovaps xmm5, [rsp+0x50]
000077a70fddb355  vmovaps xmm6, [rsp+0x60]
000077a70fddb35b  vmovaps xmm7, [rsp+0x70]
000077a70fddb361  vmovaps xmm8, [rsp+0x80]
000077a70fddb36a  vmovaps xmm10, [rsp+0x90]
000077a70fddb373  vmovaps xmm11, [rsp+0xA0]
000077a70fddb37c  vmovaps xmm12, [rsp+0xB0]
000077a70fddb385  vmovaps xmm13, [rsp+0xC0]
000077a70fddb38e  vmovaps xmm14, [rsp+0xD0]
000077a70fddb397  vmovaps xmm15, [rsp+0xE0]
000077a70fddb3a0  add rsp, 0xF0
000077a70fddb3a7  pop r11
000077a70fddb3a9  pop r10
000077a70fddb3ab  pop r9
000077a70fddb3ad  pop r8
000077a70fddb3af  pop rsi
000077a70fddb3b0  pop rdi
000077a70fddb3b1  pop rdx
000077a70fddb3b2  pop rcx
000077a70fddb3b3  pop rax
000077a70fddb3b4  add rsp, 0x08
000077a70fddb3b8  jmp 0x000077A70FDD662F
000077a70fddb3bd  sub rsp, 0x08
000077a70fddb3c1  push rax
000077a70fddb3c2  push rcx
000077a70fddb3c3  push rdx
000077a70fddb3c4  push rdi
000077a70fddb3c5  push rsi
000077a70fddb3c6  push r8
000077a70fddb3c8  push r9
000077a70fddb3ca  push r10
000077a70fddb3cc  push r11
000077a70fddb3ce  sub rsp, 0xF0
000077a70fddb3d5  vmovaps [rsp], xmm0
000077a70fddb3da  vmovaps [rsp+0x10], xmm1
000077a70fddb3e0  vmovaps [rsp+0x20], xmm2
000077a70fddb3e6  vmovaps [rsp+0x30], xmm3
000077a70fddb3ec  vmovaps [rsp+0x40], xmm4
000077a70fddb3f2  vmovaps [rsp+0x50], xmm5
000077a70fddb3f8  vmovaps [rsp+0x60], xmm6
000077a70fddb3fe  vmovaps [rsp+0x70], xmm7
000077a70fddb404  vmovaps [rsp+0x80], xmm8
000077a70fddb40d  vmovaps [rsp+0x90], xmm9
000077a70fddb416  vmovaps [rsp+0xA0], xmm10
000077a70fddb41f  vmovaps [rsp+0xB0], xmm11
000077a70fddb428  vmovaps [rsp+0xC0], xmm12
000077a70fddb431  vmovaps [rsp+0xD0], xmm13
000077a70fddb43a  vmovaps [rsp+0xE0], xmm14
000077a70fddb443  sub rsp, 0x30
000077a70fddb447  movaps [rsp], xmm15
000077a70fddb44c  movaps [rsp+0x10], xmm11
000077a70fddb452  movaps [rsp+0x20], xmm12
000077a70fddb458  lea rdi, [rsp]
000077a70fddb45c  mov esi, 0x00
000077a70fddb461  mov rax, 0x6294188EF530
000077a70fddb46b  call rax
000077a70fddb46d  movaps xmm15, [rsp]
000077a70fddb472  add rsp, 0x30
000077a70fddb476  vmovaps xmm0, [rsp]
000077a70fddb47b  vmovaps xmm1, [rsp+0x10]
000077a70fddb481  vmovaps xmm2, [rsp+0x20]
000077a70fddb487  vmovaps xmm3, [rsp+0x30]
000077a70fddb48d  vmovaps xmm4, [rsp+0x40]
000077a70fddb493  vmovaps xmm5, [rsp+0x50]
000077a70fddb499  vmovaps xmm6, [rsp+0x60]
000077a70fddb49f  vmovaps xmm7, [rsp+0x70]
000077a70fddb4a5  vmovaps xmm8, [rsp+0x80]
000077a70fddb4ae  vmovaps xmm9, [rsp+0x90]
000077a70fddb4b7  vmovaps xmm10, [rsp+0xA0]
000077a70fddb4c0  vmovaps xmm11, [rsp+0xB0]
000077a70fddb4c9  vmovaps xmm12, [rsp+0xC0]
000077a70fddb4d2  vmovaps xmm13, [rsp+0xD0]
000077a70fddb4db  vmovaps xmm14, [rsp+0xE0]
000077a70fddb4e4  add rsp, 0xF0
000077a70fddb4eb  pop r11
000077a70fddb4ed  pop r10
000077a70fddb4ef  pop r9
000077a70fddb4f1  pop r8
000077a70fddb4f3  pop rsi
000077a70fddb4f4  pop rdi
000077a70fddb4f5  pop rdx
000077a70fddb4f6  pop rcx
000077a70fddb4f7  pop rax
000077a70fddb4f8  add rsp, 0x08
000077a70fddb4fc  jmp 0x000077A70FDD664A
000077a70fddb501  sub rsp, 0x08
000077a70fddb505  push rax
000077a70fddb506  push rcx
000077a70fddb507  push rdx
000077a70fddb508  push rdi
000077a70fddb509  push rsi
000077a70fddb50a  push r8
000077a70fddb50c  push r9
000077a70fddb50e  push r10
000077a70fddb510  push r11
000077a70fddb512  sub rsp, 0xF0
000077a70fddb519  vmovaps [rsp], xmm0
000077a70fddb51e  vmovaps [rsp+0x10], xmm1
000077a70fddb524  vmovaps [rsp+0x20], xmm2
000077a70fddb52a  vmovaps [rsp+0x30], xmm3
000077a70fddb530  vmovaps [rsp+0x40], xmm4
000077a70fddb536  vmovaps [rsp+0x50], xmm5
000077a70fddb53c  vmovaps [rsp+0x60], xmm6
000077a70fddb542  vmovaps [rsp+0x70], xmm7
000077a70fddb548  vmovaps [rsp+0x80], xmm8
000077a70fddb551  vmovaps [rsp+0x90], xmm9
000077a70fddb55a  vmovaps [rsp+0xA0], xmm10
000077a70fddb563  vmovaps [rsp+0xB0], xmm11
000077a70fddb56c  vmovaps [rsp+0xC0], xmm12
000077a70fddb575  vmovaps [rsp+0xD0], xmm14
000077a70fddb57e  vmovaps [rsp+0xE0], xmm15
000077a70fddb587  sub rsp, 0x30
000077a70fddb58b  movaps [rsp], xmm13
000077a70fddb590  movaps [rsp+0x10], xmm10
000077a70fddb596  movaps [rsp+0x20], xmm14
000077a70fddb59c  lea rdi, [rsp]
000077a70fddb5a0  mov esi, 0x00
000077a70fddb5a5  mov rax, 0x6294188EF530
000077a70fddb5af  call rax
000077a70fddb5b1  movaps xmm13, [rsp]
000077a70fddb5b6  add rsp, 0x30
000077a70fddb5ba  vmovaps xmm0, [rsp]
000077a70fddb5bf  vmovaps xmm1, [rsp+0x10]
000077a70fddb5c5  vmovaps xmm2, [rsp+0x20]
000077a70fddb5cb  vmovaps xmm3, [rsp+0x30]
000077a70fddb5d1  vmovaps xmm4, [rsp+0x40]
000077a70fddb5d7  vmovaps xmm5, [rsp+0x50]
000077a70fddb5dd  vmovaps xmm6, [rsp+0x60]
000077a70fddb5e3  vmovaps xmm7, [rsp+0x70]
000077a70fddb5e9  vmovaps xmm8, [rsp+0x80]
000077a70fddb5f2  vmovaps xmm9, [rsp+0x90]
000077a70fddb5fb  vmovaps xmm10, [rsp+0xA0]
000077a70fddb604  vmovaps xmm11, [rsp+0xB0]
000077a70fddb60d  vmovaps xmm12, [rsp+0xC0]
000077a70fddb616  vmovaps xmm14, [rsp+0xD0]
000077a70fddb61f  vmovaps xmm15, [rsp+0xE0]
000077a70fddb628  add rsp, 0xF0
000077a70fddb62f  pop r11
000077a70fddb631  pop r10
000077a70fddb633  pop r9
000077a70fddb635  pop r8
000077a70fddb637  pop rsi
000077a70fddb638  pop rdi
000077a70fddb639  pop rdx
000077a70fddb63a  pop rcx
000077a70fddb63b  pop rax
000077a70fddb63c  add rsp, 0x08
000077a70fddb640  jmp 0x000077A70FDD666D
000077a70fddb645  sub rsp, 0x08
000077a70fddb649  push rax
000077a70fddb64a  push rcx
000077a70fddb64b  push rdx
000077a70fddb64c  push rdi
000077a70fddb64d  push rsi
000077a70fddb64e  push r8
000077a70fddb650  push r9
000077a70fddb652  push r10
000077a70fddb654  push r11
000077a70fddb656  sub rsp, 0xF0
000077a70fddb65d  vmovaps [rsp], xmm0
000077a70fddb662  vmovaps [rsp+0x10], xmm1
000077a70fddb668  vmovaps [rsp+0x20], xmm2
000077a70fddb66e  vmovaps [rsp+0x30], xmm3
000077a70fddb674  vmovaps [rsp+0x40], xmm4
000077a70fddb67a  vmovaps [rsp+0x50], xmm5
000077a70fddb680  vmovaps [rsp+0x60], xmm6
000077a70fddb686  vmovaps [rsp+0x70], xmm7
000077a70fddb68c  vmovaps [rsp+0x80], xmm8
000077a70fddb695  vmovaps [rsp+0x90], xmm9
000077a70fddb69e  vmovaps [rsp+0xA0], xmm10
000077a70fddb6a7  vmovaps [rsp+0xB0], xmm11
000077a70fddb6b0  vmovaps [rsp+0xC0], xmm12
000077a70fddb6b9  vmovaps [rsp+0xD0], xmm13
000077a70fddb6c2  vmovaps [rsp+0xE0], xmm15
000077a70fddb6cb  sub rsp, 0x30
000077a70fddb6cf  movaps [rsp], xmm14
000077a70fddb6d4  movaps [rsp+0x10], xmm1
000077a70fddb6d9  movaps [rsp+0x20], xmm7
000077a70fddb6de  lea rdi, [rsp]
000077a70fddb6e2  mov esi, 0x00
000077a70fddb6e7  mov rax, 0x6294188EF530
000077a70fddb6f1  call rax
000077a70fddb6f3  movaps xmm14, [rsp]
000077a70fddb6f8  add rsp, 0x30
000077a70fddb6fc  vmovaps xmm0, [rsp]
000077a70fddb701  vmovaps xmm1, [rsp+0x10]
000077a70fddb707  vmovaps xmm2, [rsp+0x20]
000077a70fddb70d  vmovaps xmm3, [rsp+0x30]
000077a70fddb713  vmovaps xmm4, [rsp+0x40]
000077a70fddb719  vmovaps xmm5, [rsp+0x50]
000077a70fddb71f  vmovaps xmm6, [rsp+0x60]
000077a70fddb725  vmovaps xmm7, [rsp+0x70]
000077a70fddb72b  vmovaps xmm8, [rsp+0x80]
000077a70fddb734  vmovaps xmm9, [rsp+0x90]
000077a70fddb73d  vmovaps xmm10, [rsp+0xA0]
000077a70fddb746  vmovaps xmm11, [rsp+0xB0]
000077a70fddb74f  vmovaps xmm12, [rsp+0xC0]
000077a70fddb758  vmovaps xmm13, [rsp+0xD0]
000077a70fddb761  vmovaps xmm15, [rsp+0xE0]
000077a70fddb76a  add rsp, 0xF0
000077a70fddb771  pop r11
000077a70fddb773  pop r10
000077a70fddb775  pop r9
000077a70fddb777  pop r8
000077a70fddb779  pop rsi
000077a70fddb77a  pop rdi
000077a70fddb77b  pop rdx
000077a70fddb77c  pop rcx
000077a70fddb77d  pop rax
000077a70fddb77e  add rsp, 0x08
000077a70fddb782  jmp 0x000077A70FDD6690
000077a70fddb787  sub rsp, 0x08
000077a70fddb78b  push rax
000077a70fddb78c  push rcx
000077a70fddb78d  push rdx
000077a70fddb78e  push rdi
000077a70fddb78f  push rsi
000077a70fddb790  push r8
000077a70fddb792  push r9
000077a70fddb794  push r10
000077a70fddb796  push r11
000077a70fddb798  sub rsp, 0xF0
000077a70fddb79f  vmovaps [rsp], xmm0
000077a70fddb7a4  vmovaps [rsp+0x10], xmm2
000077a70fddb7aa  vmovaps [rsp+0x20], xmm3
000077a70fddb7b0  vmovaps [rsp+0x30], xmm4
000077a70fddb7b6  vmovaps [rsp+0x40], xmm5
000077a70fddb7bc  vmovaps [rsp+0x50], xmm6
000077a70fddb7c2  vmovaps [rsp+0x60], xmm7
000077a70fddb7c8  vmovaps [rsp+0x70], xmm8
000077a70fddb7ce  vmovaps [rsp+0x80], xmm9
000077a70fddb7d7  vmovaps [rsp+0x90], xmm10
000077a70fddb7e0  vmovaps [rsp+0xA0], xmm11
000077a70fddb7e9  vmovaps [rsp+0xB0], xmm12
000077a70fddb7f2  vmovaps [rsp+0xC0], xmm13
000077a70fddb7fb  vmovaps [rsp+0xD0], xmm14
000077a70fddb804  vmovaps [rsp+0xE0], xmm15
000077a70fddb80d  sub rsp, 0x30
000077a70fddb811  movaps [rsp], xmm1
000077a70fddb815  movaps [rsp+0x10], xmm8
000077a70fddb81b  movaps [rsp+0x20], xmm9
000077a70fddb821  lea rdi, [rsp]
000077a70fddb825  mov esi, 0x00
000077a70fddb82a  mov rax, 0x6294188EF530
000077a70fddb834  call rax
000077a70fddb836  movaps xmm1, [rsp]
000077a70fddb83a  add rsp, 0x30
000077a70fddb83e  vmovaps xmm0, [rsp]
000077a70fddb843  vmovaps xmm2, [rsp+0x10]
000077a70fddb849  vmovaps xmm3, [rsp+0x20]
000077a70fddb84f  vmovaps xmm4, [rsp+0x30]
000077a70fddb855  vmovaps xmm5, [rsp+0x40]
000077a70fddb85b  vmovaps xmm6, [rsp+0x50]
000077a70fddb861  vmovaps xmm7, [rsp+0x60]
000077a70fddb867  vmovaps xmm8, [rsp+0x70]
000077a70fddb86d  vmovaps xmm9, [rsp+0x80]
000077a70fddb876  vmovaps xmm10, [rsp+0x90]
000077a70fddb87f  vmovaps xmm11, [rsp+0xA0]
000077a70fddb888  vmovaps xmm12, [rsp+0xB0]
000077a70fddb891  vmovaps xmm13, [rsp+0xC0]
000077a70fddb89a  vmovaps xmm14, [rsp+0xD0]
000077a70fddb8a3  vmovaps xmm15, [rsp+0xE0]
000077a70fddb8ac  add rsp, 0xF0
000077a70fddb8b3  pop r11
000077a70fddb8b5  pop r10
000077a70fddb8b7  pop r9
000077a70fddb8b9  pop r8
000077a70fddb8bb  pop rsi
000077a70fddb8bc  pop rdi
000077a70fddb8bd  pop rdx
000077a70fddb8be  pop rcx
000077a70fddb8bf  pop rax
000077a70fddb8c0  add rsp, 0x08
000077a70fddb8c4  jmp 0x000077A70FDD66B2
000077a70fddb8c9  call 0x000077A70FCB3E40
000077a70fddb8ce  jmp 0x000077A70FDD66C0
000077a70fddb8d3  call 0x000077A70FC0C380
000077a70fddb8d8  jmp 0x000077A70FDD66CA
000077a70fddb8dd  call 0x000077A70FC0D600
000077a70fddb8e2  jmp 0x000077A70FDD66D4
000077a70fddb8e7  call 0x000077A70FBFF540
000077a70fddb8ec  jmp 0x000077A70FDD66DE
000077a70fddb8f1  int3
000077a70fddb8f2  nop [rax+rax*1], ax
000077a70fddb8fb  nop [rax+rax*1], eax
000077a70fddb900  mov eax, [r15+0x48]
000077a70fddb904  lea r14d, [eax+0x01]
000077a70fddb909  mov [rsp+0x10], r14d
000077a70fddb90e  mov r14d, r14d
000077a70fddb911  mov [r15+0x48], r14
000077a70fddb915  xor eax, eax
000077a70fddb917  mov r14d, [rsp+0x10]
000077a70fddb91c  cmp r14d, 0x1F4
000077a70fddb923  cmc
000077a70fddb924  lahf
000077a70fddb925  seto al
000077a70fddb928  mov [r15+0x108], eax
000077a70fddb92f  mov eax, [r15+0x108]
000077a70fddb936  sahf
000077a70fddb937  jnz 0x000077A70FDDB969
000077a70fddb939  cmp dword ptr [r15+0x318], 0x00
000077a70fddb941  jz 0x000077A70FDE1AB0
000077a70fddb947  nop [rax+rax*1], ax
000077a70fddb950  nop [rax+rax*1], eax
000077a70fddb958  mov eax, 0x410450
000077a70fddb95d  mov [r15+0x100], rax
000077a70fddb964  jmp 0x000077A70FBFE110
000077a70fddb969  cmp dword ptr [r15+0x318], 0x00
000077a70fddb971  jz 0x000077A70FDDB9A0
000077a70fddb977  nop [rax+rax*1], ax
000077a70fddb980  nop [rax+rax*1], eax
000077a70fddb988  mov eax, 0x410274
000077a70fddb98d  mov [r15+0x100], rax
000077a70fddb994  jmp 0x000077A70FBFE110
000077a70fddb999  int3
000077a70fddb99a  int3
000077a70fddb99b  nop [rax+rax*1], eax
000077a70fddb9a0  mov rax, [r15+0x40]
000077a70fddb9a4  movaps xmm1, [r15+0x1D0]
000077a70fddb9ac  vmovaps [rsp+0x10], xmm1
000077a70fddb9b2  vmovaps xmm15, [rsp+0x10]
000077a70fddb9b8  por xmm1, xmm15
000077a70fddb9bd  movaps xmm14, [r15+0x1A0]
000077a70fddb9c5  vmovaps [rsp+0x10], xmm14
000077a70fddb9cb  vmovaps xmm13, [rsp+0x10]
000077a70fddb9d1  por xmm14, xmm13
000077a70fddb9d6  lea r14, [rax+0x30]
000077a70fddb9da  mov r12, [r13+r14*1]
000077a70fddb9df  lea r14, [rax+0x38]
000077a70fddb9e3  mov r11, [r13+r14*1]
000077a70fddb9e8  movq xmm13, r12
000077a70fddb9ed  movq xmm12, r11
000077a70fddb9f2  movq xmm13, xmm13
000077a70fddb9f7  vmovaps [rsp+0x10], xmm13
000077a70fddb9fd  movq xmm13, xmm13
000077a70fddba02  movaps [r15+0x130], xmm13
000077a70fddba0a  movq xmm12, xmm12
000077a70fddba0f  vmovaps [rsp+0x20], xmm12
000077a70fddba15  movq xmm12, xmm12
000077a70fddba1a  movaps [r15+0x280], xmm12
000077a70fddba22  movaps xmm13, [r15+0x270]
000077a70fddba2a  vmovaps [rsp+0x30], xmm13
000077a70fddba30  vmovaps xmm12, [rsp+0x30]
000077a70fddba36  por xmm13, xmm12
000077a70fddba3b  lea r14, [rax+0x20]
000077a70fddba3f  mov r12, [r13+r14*1]
000077a70fddba44  lea r14, [rax+0x28]
000077a70fddba48  mov r11, [r13+r14*1]
000077a70fddba4d  movq xmm12, r12
000077a70fddba52  movq xmm11, r11
000077a70fddba57  movq xmm12, xmm12
000077a70fddba5c  vmovaps [rsp+0x30], xmm12
000077a70fddba62  movq xmm12, xmm12
000077a70fddba67  movaps [r15+0x150], xmm12
000077a70fddba6f  movq xmm11, xmm11
000077a70fddba74  vmovaps [rsp+0x40], xmm11
000077a70fddba7a  movq xmm11, xmm11
000077a70fddba7f  movaps [r15+0x140], xmm11
000077a70fddba87  lea r14, [rax+0x10]
000077a70fddba8b  mov r12, [r13+r14*1]
000077a70fddba90  lea r14, [rax+0x18]
000077a70fddba94  mov r11, [r13+r14*1]
000077a70fddba99  movq xmm12, r12
000077a70fddba9e  movq xmm11, r11
000077a70fddbaa3  movq xmm12, xmm12
000077a70fddbaa8  vmovaps [rsp+0x50], xmm12
000077a70fddbaae  movq xmm12, xmm12
000077a70fddbab3  movaps [r15+0x170], xmm12
000077a70fddbabb  movq xmm11, xmm11
000077a70fddbac0  vmovaps [rsp+0x60], xmm11
000077a70fddbac6  movq xmm11, xmm11
000077a70fddbacb  movaps [r15+0x160], xmm11
000077a70fddbad3  mov r14, [r13+rax*1]
000077a70fddbad8  vmovq xmm12, r14
000077a70fddbadd  vpbroadcastq xmm12, xmm12
000077a70fddbae2  lea r14, [rax+0x08]
000077a70fddbae6  mov rax, [r13+r14*1]
000077a70fddbaeb  movq xmm11, rax
000077a70fddbaf0  movaps [r15+0x230], xmm11
000077a70fddbaf8  mov rax, [r15+0xF8]
000077a70fddbaff  lea r14, [rax+0x50]
000077a70fddbb03  movups xmm11, [r13+r14*1]
000077a70fddbb09  lea r14, [rax+0x60]
000077a70fddbb0d  movups xmm10, [r13+r14*1]
000077a70fddbb13  lea r14, [rax+0x30]
000077a70fddbb17  movups xmm9, [r13+r14*1]
000077a70fddbb1d  mov r14, [r15+0x50]
000077a70fddbb21  mov [r15+0x60], r14
000077a70fddbb25  mov qword ptr [r15+0x58], 0x40
000077a70fddbb2d  movaps xmm8, xmm12
000077a70fddbb31  mulpd xmm8, xmm15
000077a70fddbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000077a70fddbb3c  ptest xmm7, xmm7
000077a70fddbb41  jnz 0x000077A70FDDC96A
000077a70fddbb47  movq xmm15, qword ptr [r15+0x230]
000077a70fddbb50  vmovaps [rsp+0x70], xmm15
000077a70fddbb56  vpermilpd xmm15, xmm15, 0x00
000077a70fddbb5c  movaps xmm7, xmm9
000077a70fddbb60  mulpd xmm7, xmm15
000077a70fddbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000077a70fddbb6a  ptest xmm6, xmm6
000077a70fddbb6f  jnz 0x000077A70FDDCAAE
000077a70fddbb75  vxorps xmm15, xmm15, xmm15
000077a70fddbb7a  vpbroadcastq xmm15, xmm15
000077a70fddbb7f  movaps xmm9, xmm12
000077a70fddbb83  mulpd xmm9, xmm10
000077a70fddbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000077a70fddbb8e  ptest xmm6, xmm6
000077a70fddbb93  jnz 0x000077A70FDDCBF0
000077a70fddbb99  movaps xmm10, xmm12
000077a70fddbb9d  mulpd xmm10, xmm11
000077a70fddbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000077a70fddbba8  ptest xmm6, xmm6
000077a70fddbbad  jnz 0x000077A70FDDCD34
000077a70fddbbb3  movaps xmm11, [r15+0x1F0]
000077a70fddbbbb  movaps xmm6, xmm12
000077a70fddbbbf  mulpd xmm6, xmm11
000077a70fddbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000077a70fddbbc9  ptest xmm5, xmm5
000077a70fddbbce  jnz 0x000077A70FDDCE78
000077a70fddbbd4  movaps xmm12, [r15+0x2A0]
000077a70fddbbdc  vmovaps [rsp+0x80], xmm12
000077a70fddbbe5  vmovaps xmm11, [rsp+0x80]
000077a70fddbbee  por xmm12, xmm11
000077a70fddbbf3  movaps xmm11, [r15+0x250]
000077a70fddbbfb  vmovaps [rsp+0x80], xmm11
000077a70fddbc04  vmovaps xmm5, [rsp+0x80]
000077a70fddbc0d  por xmm11, xmm5
000077a70fddbc12  vmovaps xmm4, [rsp+0x70]
000077a70fddbc18  vpermilpd xmm4, xmm4, 0x00
000077a70fddbc1e  movaps xmm3, xmm5
000077a70fddbc21  mulpd xmm3, xmm4
000077a70fddbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000077a70fddbc2a  ptest xmm2, xmm2
000077a70fddbc2f  jnz 0x000077A70FDDCFBA
000077a70fddbc35  mov [rsp+0x80], rax
000077a70fddbc3d  xor eax, eax
000077a70fddbc3f  mov r12d, 0x40
000077a70fddbc45  mov r11d, 0x200
000077a70fddbc4b  cmp r12, r11
000077a70fddbc4e  cmc
000077a70fddbc4f  lahf
000077a70fddbc50  seto al
000077a70fddbc53  mov [r15+0x108], eax
000077a70fddbc5a  movaps xmm5, xmm8
000077a70fddbc5e  addpd xmm5, xmm15
000077a70fddbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000077a70fddbc68  ptest xmm4, xmm4
000077a70fddbc6d  jnz 0x000077A70FDDD0FA
000077a70fddbc73  movaps xmm8, [r15+0x1B0]
000077a70fddbc7b  movaps xmm4, xmm9
000077a70fddbc7f  addpd xmm4, xmm8
000077a70fddbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000077a70fddbc89  ptest xmm2, xmm2
000077a70fddbc8e  jnz 0x000077A70FDDD23C
000077a70fddbc94  movaps xmm9, xmm10
000077a70fddbc98  addpd xmm9, xmm8
000077a70fddbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000077a70fddbca3  ptest xmm2, xmm2
000077a70fddbca8  jnz 0x000077A70FDDD37E
000077a70fddbcae  movaps xmm10, [r15+0x2F0]
000077a70fddbcb6  vmovaps [rsp+0x90], xmm10
000077a70fddbcbf  vmovaps xmm8, [rsp+0x90]
000077a70fddbcc8  por xmm10, xmm8
000077a70fddbccd  movaps xmm8, [r15+0x2E0]
000077a70fddbcd5  vmovaps [rsp+0x90], xmm8
000077a70fddbcde  vmovaps xmm2, [rsp+0x90]
000077a70fddbce7  por xmm8, xmm2
000077a70fddbcec  movaps xmm2, [r15+0x2D0]
000077a70fddbcf4  vmovaps [rsp+0x90], xmm2
000077a70fddbcfd  vmovaps [rsp+0xA0], xmm1
000077a70fddbd06  vmovaps xmm1, [rsp+0x90]
000077a70fddbd0f  por xmm2, xmm1
000077a70fddbd13  movaps xmm1, [r15+0x200]
000077a70fddbd1b  vmovaps [rsp+0x90], xmm1
000077a70fddbd24  vmovaps [rsp+0xB0], xmm15
000077a70fddbd2d  vmovaps xmm15, [rsp+0x90]
000077a70fddbd36  por xmm1, xmm15
000077a70fddbd3b  movaps xmm15, [r15+0x1C0]
000077a70fddbd43  vmovaps [rsp+0x90], xmm15
000077a70fddbd4c  vmovaps [rsp+0xC0], xmm1
000077a70fddbd55  vmovaps xmm1, [rsp+0x90]
000077a70fddbd5e  por xmm15, xmm1
000077a70fddbd63  movaps xmm1, [r15+0x190]
000077a70fddbd6b  vmovaps [rsp+0x90], xmm1
000077a70fddbd74  vmovaps [rsp+0xD0], xmm15
000077a70fddbd7d  vmovaps xmm15, [rsp+0x90]
000077a70fddbd86  por xmm1, xmm15
000077a70fddbd8b  movaps xmm15, [r15+0x300]
000077a70fddbd93  vmovaps [rsp+0x90], xmm15
000077a70fddbd9c  vmovaps [rsp+0xE0], xmm1
000077a70fddbda5  vmovaps xmm1, [rsp+0x90]
000077a70fddbdae  por xmm15, xmm1
000077a70fddbdb3  mov rax, [rsp+0x80]
000077a70fddbdbb  lea r12, [rax+0xA0]
000077a70fddbdc2  movups xmm1, [r13+r12*1]
000077a70fddbdc8  lea r12, [rax+0xB0]
000077a70fddbdcf  vmovaps [rsp+0x80], xmm1
000077a70fddbdd8  movups xmm1, [r13+r12*1]
000077a70fddbdde  vmovaps [rsp+0x90], xmm1
000077a70fddbde7  vmovaps [rsp+0xF0], xmm15
000077a70fddbdf0  vmovaps xmm15, [rsp+0xB0]
000077a70fddbdf9  vmovaps [rsp+0xB0], xmm14
000077a70fddbe02  movaps xmm1, xmm6
000077a70fddbe05  addpd xmm1, xmm15
000077a70fddbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000077a70fddbe0f  ptest xmm14, xmm14
000077a70fddbe15  jnz 0x000077A70FDDD4D6
000077a70fddbe1b  lea r12, [rax+0xF0]
000077a70fddbe22  movups xmm15, [r13+r12*1]
000077a70fddbe28  movaps xmm14, xmm4
000077a70fddbe2c  addpd xmm14, xmm3
000077a70fddbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000077a70fddbe37  ptest xmm6, xmm6
000077a70fddbe3c  jnz 0x000077A70FDDD621
000077a70fddbe42  movaps xmm6, xmm9
000077a70fddbe46  addpd xmm6, xmm7
000077a70fddbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000077a70fddbe4f  ptest xmm4, xmm4
000077a70fddbe54  jnz 0x000077A70FDDD763
000077a70fddbe5a  vmovaps xmm9, [rsp+0x70]
000077a70fddbe60  vpermilpd xmm9, xmm9, 0x00
000077a70fddbe66  vmovaps xmm4, [rsp+0x90]
000077a70fddbe6f  movaps xmm7, xmm4
000077a70fddbe72  mulpd xmm7, xmm9
000077a70fddbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000077a70fddbe7c  ptest xmm3, xmm3
000077a70fddbe81  jnz 0x000077A70FDDD8A4
000077a70fddbe87  vmovaps xmm9, [rsp+0x50]
000077a70fddbe8d  vpermilpd xmm9, xmm9, 0x00
000077a70fddbe93  movaps xmm4, xmm15
000077a70fddbe97  mulpd xmm4, xmm9
000077a70fddbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000077a70fddbea1  ptest xmm3, xmm3
000077a70fddbea6  jnz 0x000077A70FDDD9E5
000077a70fddbeac  lea r12, [rax+0xE0]
000077a70fddbeb3  movups xmm15, [r13+r12*1]
000077a70fddbeb9  vmovaps xmm9, [rsp+0x70]
000077a70fddbebf  vpermilpd xmm9, xmm9, 0x00
000077a70fddbec5  vmovaps [rsp+0x70], xmm1
000077a70fddbecb  vmovaps xmm1, [rsp+0x80]
000077a70fddbed4  vmovaps [rsp+0x80], xmm15
000077a70fddbedd  movaps xmm3, xmm1
000077a70fddbee0  mulpd xmm3, xmm9
000077a70fddbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000077a70fddbeea  ptest xmm15, xmm15
000077a70fddbef0  jnz 0x000077A70FDDDB31
000077a70fddbef6  vmovaps xmm1, [rsp+0xF0]
000077a70fddbeff  vmovaps xmm15, [rsp+0xF0]
000077a70fddbf08  por xmm1, xmm15
000077a70fddbf0d  movaps [r15+0x300], xmm1
000077a70fddbf15  vmovaps xmm15, [rsp+0xE0]
000077a70fddbf1e  vmovaps xmm9, [rsp+0xE0]
000077a70fddbf27  por xmm15, xmm9
000077a70fddbf2c  movaps [r15+0x190], xmm15
000077a70fddbf34  vmovaps xmm9, [rsp+0x50]
000077a70fddbf3a  vpermilpd xmm9, xmm9, 0x00
000077a70fddbf40  vmovaps [rsp+0x90], xmm1
000077a70fddbf49  vmovaps [rsp+0xE0], xmm15
000077a70fddbf52  vmovaps xmm15, [rsp+0x80]
000077a70fddbf5b  vmovaps [rsp+0x80], xmm14
000077a70fddbf64  movaps xmm1, xmm15
000077a70fddbf68  mulpd xmm1, xmm9
000077a70fddbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000077a70fddbf72  ptest xmm14, xmm14
000077a70fddbf78  jnz 0x000077A70FDDDC72
000077a70fddbf7e  lea r12, [rax+0x90]
000077a70fddbf85  movups xmm15, [r13+r12*1]
000077a70fddbf8b  vmovaps xmm14, [rsp+0xD0]
000077a70fddbf94  vmovaps xmm9, [rsp+0xD0]
000077a70fddbf9d  por xmm14, xmm9
000077a70fddbfa2  movaps [r15+0x1C0], xmm14
000077a70fddbfaa  vmovaps xmm9, [rsp+0xC0]
000077a70fddbfb3  vmovaps [rsp+0xD0], xmm1
000077a70fddbfbc  vmovaps xmm1, [rsp+0xC0]
000077a70fddbfc5  por xmm9, xmm1
000077a70fddbfca  movaps [r15+0x200], xmm9
000077a70fddbfd2  vmovaps [rsp+0xC0], xmm2
000077a70fddbfdb  vmovaps xmm1, [rsp+0xC0]
000077a70fddbfe4  por xmm2, xmm1
000077a70fddbfe8  movaps [r15+0x2D0], xmm2
000077a70fddbff0  vmovaps [rsp+0xC0], xmm8
000077a70fddbff9  vmovaps xmm1, [rsp+0xC0]
000077a70fddc002  por xmm8, xmm1
000077a70fddc007  movaps [r15+0x2E0], xmm8
000077a70fddc00f  vmovaps [rsp+0xC0], xmm15
000077a70fddc018  movaps xmm1, xmm5
000077a70fddc01b  addpd xmm1, xmm7
000077a70fddc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000077a70fddc024  ptest xmm15, xmm15
000077a70fddc02a  jnz 0x000077A70FDDDDBE
000077a70fddc030  vmovaps xmm15, [rsp+0x50]
000077a70fddc036  vpermilpd xmm15, xmm15, 0x00
000077a70fddc03c  vmovaps xmm5, [rsp+0xC0]
000077a70fddc045  vmovaps [rsp+0xC0], xmm1
000077a70fddc04e  movaps xmm7, xmm5
000077a70fddc051  mulpd xmm7, xmm15
000077a70fddc056  vcmppd xmm1, xmm7, xmm7, 0x03
000077a70fddc05b  ptest xmm1, xmm1
000077a70fddc060  jnz 0x000077A70FDDDEFE
000077a70fddc066  lea r12, [rax+0x80]
000077a70fddc06d  movups xmm1, [r13+r12*1]
000077a70fddc073  vmovaps xmm5, [rsp+0x70]
000077a70fddc079  vmovaps [rsp+0x70], xmm1
000077a70fddc07f  movaps xmm15, xmm5
000077a70fddc083  addpd xmm15, xmm3
000077a70fddc088  vcmppd xmm1, xmm15, xmm15, 0x03
000077a70fddc08e  ptest xmm1, xmm1
000077a70fddc093  jnz 0x000077A70FDDE049
000077a70fddc099  vmovaps xmm5, [rsp+0x80]
000077a70fddc0a2  movaps xmm1, xmm5
000077a70fddc0a5  addpd xmm1, xmm4
000077a70fddc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000077a70fddc0ae  ptest xmm3, xmm3
000077a70fddc0b3  jnz 0x000077A70FDDE18B
000077a70fddc0b9  vmovaps [rsp+0x80], xmm10
000077a70fddc0c2  vmovaps xmm5, [rsp+0x80]
000077a70fddc0cb  por xmm10, xmm5
000077a70fddc0d0  movaps [r15+0x2F0], xmm10
000077a70fddc0d8  vmovaps xmm5, [rsp+0x50]
000077a70fddc0de  vpermilpd xmm5, xmm5, 0x00
000077a70fddc0e4  vmovaps xmm3, [rsp+0x70]
000077a70fddc0ea  vmovaps [rsp+0x50], xmm1
000077a70fddc0f0  movaps xmm4, xmm3
000077a70fddc0f3  mulpd xmm4, xmm5
000077a70fddc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000077a70fddc0fc  ptest xmm1, xmm1
000077a70fddc101  jnz 0x000077A70FDDE2CB
000077a70fddc107  lea r12, [rax+0xD0]
000077a70fddc10e  movups xmm1, [r13+r12*1]
000077a70fddc114  vmovaps xmm3, [rsp+0xD0]
000077a70fddc11d  vmovaps [rsp+0x70], xmm1
000077a70fddc123  movaps xmm5, xmm6
000077a70fddc126  addpd xmm5, xmm3
000077a70fddc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000077a70fddc12f  ptest xmm1, xmm1
000077a70fddc134  jnz 0x000077A70FDDE415
000077a70fddc13a  vmovaps xmm1, [rsp+0x60]
000077a70fddc140  vpermilpd xmm1, xmm1, 0x00
000077a70fddc146  movaps xmm6, xmm9
000077a70fddc14a  mulpd xmm6, xmm1
000077a70fddc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000077a70fddc153  ptest xmm3, xmm3
000077a70fddc158  jnz 0x000077A70FDDE555
000077a70fddc15e  movaps [r15+0x260], xmm6
000077a70fddc166  vxorps xmm1, xmm1, xmm1
000077a70fddc16a  vpbroadcastq xmm1, xmm1
000077a70fddc16f  movaps [r15+0x1B0], xmm1
000077a70fddc177  vmovaps xmm1, [rsp+0x60]
000077a70fddc17d  vpermilpd xmm1, xmm1, 0x00
000077a70fddc183  vmovaps xmm3, [rsp+0x70]
000077a70fddc189  vmovaps [rsp+0x70], xmm15
000077a70fddc18f  movaps xmm9, xmm3
000077a70fddc193  mulpd xmm9, xmm1
000077a70fddc198  vcmppd xmm15, xmm9, xmm9, 0x03
000077a70fddc19e  ptest xmm15, xmm15
000077a70fddc1a4  jnz 0x000077A70FDDE696
000077a70fddc1aa  lea r12, [rax+0xC0]
000077a70fddc1b1  movups xmm1, [r13+r12*1]
000077a70fddc1b7  vmovaps xmm3, [rsp+0xC0]
000077a70fddc1c0  vmovaps [rsp+0x80], xmm1
000077a70fddc1c9  movaps xmm15, xmm3
000077a70fddc1cd  addpd xmm15, xmm7
000077a70fddc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000077a70fddc1d8  ptest xmm1, xmm1
000077a70fddc1dd  jnz 0x000077A70FDDE7E2
000077a70fddc1e3  vmovaps [rsp+0xC0], xmm13
000077a70fddc1ec  vmovaps xmm1, [rsp+0xC0]
000077a70fddc1f5  por xmm13, xmm1
000077a70fddc1fa  movaps [r15+0x270], xmm13
000077a70fddc202  vmovaps xmm1, [rsp+0xB0]
000077a70fddc20b  vmovaps xmm7, [rsp+0xB0]
000077a70fddc214  por xmm1, xmm7
000077a70fddc218  movaps [r15+0x1A0], xmm1
000077a70fddc220  vmovaps xmm1, [rsp+0x60]
000077a70fddc226  vpermilpd xmm1, xmm1, 0x00
000077a70fddc22c  vmovaps [rsp+0xB0], xmm1
000077a70fddc235  vmovaps xmm1, [rsp+0x80]
000077a70fddc23e  vmovaps [rsp+0x80], xmm15
000077a70fddc247  vmovaps xmm15, [rsp+0xB0]
000077a70fddc250  vmovaps [rsp+0xB0], xmm14
000077a70fddc259  movaps xmm3, xmm1
000077a70fddc25c  mulpd xmm3, xmm15
000077a70fddc261  vcmppd xmm14, xmm3, xmm3, 0x03
000077a70fddc266  ptest xmm14, xmm14
000077a70fddc26c  jnz 0x000077A70FDDE924
000077a70fddc272  lea r12, [rax+0x20]
000077a70fddc276  movups xmm1, [r13+r12*1]
000077a70fddc27c  movaps [r15+0x110], xmm1
000077a70fddc284  vmovaps xmm14, [rsp+0x70]
000077a70fddc28a  vmovaps [rsp+0x70], xmm1
000077a70fddc290  movaps xmm15, xmm14
000077a70fddc294  addpd xmm15, xmm4
000077a70fddc299  vcmppd xmm1, xmm15, xmm15, 0x03
000077a70fddc29f  ptest xmm1, xmm1
000077a70fddc2a4  jnz 0x000077A70FDDEA6F
000077a70fddc2aa  vmovaps xmm1, [rsp+0x60]
000077a70fddc2b0  vpermilpd xmm1, xmm1, 0x00
000077a70fddc2b6  movaps xmm14, xmm2
000077a70fddc2ba  mulpd xmm14, xmm1
000077a70fddc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000077a70fddc2c5  ptest xmm4, xmm4
000077a70fddc2ca  jnz 0x000077A70FDDEBB2
000077a70fddc2d0  vmovaps xmm4, [rsp+0x50]
000077a70fddc2d6  movaps xmm1, xmm4
000077a70fddc2d9  addpd xmm1, xmm9
000077a70fddc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000077a70fddc2e3  ptest xmm2, xmm2
000077a70fddc2e8  jnz 0x000077A70FDDECF4
000077a70fddc2ee  vmovaps xmm9, [rsp+0x30]
000077a70fddc2f4  vpermilpd xmm9, xmm9, 0x00
000077a70fddc2fa  vmovaps xmm2, [rsp+0x70]
000077a70fddc300  vmovaps [rsp+0x50], xmm1
000077a70fddc306  movaps xmm4, xmm2
000077a70fddc309  mulpd xmm4, xmm9
000077a70fddc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000077a70fddc313  ptest xmm1, xmm1
000077a70fddc318  jnz 0x000077A70FDDEE35
000077a70fddc31e  vmovaps xmm1, [rsp+0x30]
000077a70fddc324  vpermilpd xmm1, xmm1, 0x00
000077a70fddc32a  vmovaps xmm2, [rsp+0x90]
000077a70fddc333  vmovaps [rsp+0x60], xmm15
000077a70fddc339  movaps xmm9, xmm2
000077a70fddc33d  mulpd xmm9, xmm1
000077a70fddc342  vcmppd xmm15, xmm9, xmm9, 0x03
000077a70fddc348  ptest xmm15, xmm15
000077a70fddc34e  jnz 0x000077A70FDDEF76
000077a70fddc354  vmovaps xmm15, [rsp+0x80]
000077a70fddc35d  movaps xmm1, xmm15
000077a70fddc361  addpd xmm1, xmm6
000077a70fddc365  vcmppd xmm2, xmm1, xmm1, 0x03
000077a70fddc36a  ptest xmm2, xmm2
000077a70fddc36f  jnz 0x000077A70FDDF0B8
000077a70fddc375  movaps xmm15, xmm5
000077a70fddc379  addpd xmm15, xmm3
000077a70fddc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000077a70fddc384  ptest xmm6, xmm6
000077a70fddc389  jnz 0x000077A70FDDF1F9
000077a70fddc38f  vmovaps xmm6, [rsp+0x30]
000077a70fddc395  vpermilpd xmm6, xmm6, 0x00
000077a70fddc39b  movaps xmm5, xmm8
000077a70fddc39f  mulpd xmm5, xmm6
000077a70fddc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000077a70fddc3a8  ptest xmm3, xmm3
000077a70fddc3ad  jnz 0x000077A70FDDF33B
000077a70fddc3b3  vmovaps xmm8, [rsp+0x30]
000077a70fddc3b9  vpermilpd xmm8, xmm8, 0x00
000077a70fddc3bf  movaps xmm6, xmm10
000077a70fddc3c3  mulpd xmm6, xmm8
000077a70fddc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000077a70fddc3cd  ptest xmm3, xmm3
000077a70fddc3d2  jnz 0x000077A70FDDF47C
000077a70fddc3d8  vmovaps xmm8, [rsp+0x60]
000077a70fddc3de  movaps xmm10, xmm8
000077a70fddc3e2  addpd xmm10, xmm14
000077a70fddc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000077a70fddc3ed  ptest xmm3, xmm3
000077a70fddc3f2  jnz 0x000077A70FDDF5BE
000077a70fddc3f8  vmovaps xmm8, [rsp+0x50]
000077a70fddc3fe  movaps xmm14, xmm8
000077a70fddc402  addpd xmm14, xmm4
000077a70fddc407  vcmppd xmm3, xmm14, xmm14, 0x03
000077a70fddc40d  ptest xmm3, xmm3
000077a70fddc412  jnz 0x000077A70FDDF702
000077a70fddc418  vmovaps xmm8, [rsp+0x40]
000077a70fddc41e  vpermilpd xmm8, xmm8, 0x00
000077a70fddc424  movaps xmm4, xmm13
000077a70fddc428  mulpd xmm4, xmm8
000077a70fddc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000077a70fddc432  ptest xmm3, xmm3
000077a70fddc437  jnz 0x000077A70FDDF845
000077a70fddc43d  movaps xmm13, xmm15
000077a70fddc441  addpd xmm13, xmm9
000077a70fddc446  vcmppd xmm8, xmm13, xmm13, 0x03
000077a70fddc44c  ptest xmm8, xmm8
000077a70fddc452  jnz 0x000077A70FDDF987
000077a70fddc458  movaps xmm15, xmm1
000077a70fddc45c  addpd xmm15, xmm5
000077a70fddc461  vcmppd xmm9, xmm15, xmm15, 0x03
000077a70fddc467  ptest xmm9, xmm9
000077a70fddc46d  jnz 0x000077A70FDDFACB
000077a70fddc473  vmovaps [rsp+0x30], xmm11
000077a70fddc479  vmovaps xmm1, [rsp+0x30]
000077a70fddc47f  por xmm11, xmm1
000077a70fddc484  movaps [r15+0x250], xmm11
000077a70fddc48c  vmovaps [rsp+0x30], xmm12
000077a70fddc492  vmovaps xmm1, [rsp+0x30]
000077a70fddc498  por xmm12, xmm1
000077a70fddc49d  movaps [r15+0x2A0], xmm12
000077a70fddc4a5  vmovaps xmm1, [rsp+0xA0]
000077a70fddc4ae  vmovaps xmm11, [rsp+0xA0]
000077a70fddc4b7  por xmm1, xmm11
000077a70fddc4bc  movaps [r15+0x1D0], xmm1
000077a70fddc4c4  lea r12, [rax+0x40]
000077a70fddc4c8  movups xmm1, [r13+r12*1]
000077a70fddc4ce  movaps [r15+0x2C0], xmm1
000077a70fddc4d6  vmovaps xmm11, [rsp+0x40]
000077a70fddc4dc  vpermilpd xmm11, xmm11, 0x00
000077a70fddc4e2  vmovaps xmm8, [rsp+0xE0]
000077a70fddc4eb  movaps xmm9, xmm8
000077a70fddc4ef  mulpd xmm9, xmm11
000077a70fddc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000077a70fddc4fa  ptest xmm5, xmm5
000077a70fddc4ff  jnz 0x000077A70FDDFC17
000077a70fddc505  movaps xmm11, xmm10
000077a70fddc509  addpd xmm11, xmm6
000077a70fddc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000077a70fddc514  ptest xmm8, xmm8
000077a70fddc51a  jnz 0x000077A70FDDFD5B
000077a70fddc520  movaps xmm10, xmm14
000077a70fddc524  addpd xmm10, xmm4
000077a70fddc529  vcmppd xmm8, xmm10, xmm10, 0x03
000077a70fddc52f  ptest xmm8, xmm8
000077a70fddc535  jnz 0x000077A70FDDFE9E
000077a70fddc53b  vmovaps xmm14, [rsp+0x40]
000077a70fddc541  vpermilpd xmm14, xmm14, 0x00
000077a70fddc547  movaps xmm8, xmm1
000077a70fddc54b  mulpd xmm8, xmm14
000077a70fddc550  vcmppd xmm6, xmm8, xmm8, 0x03
000077a70fddc556  ptest xmm6, xmm6
000077a70fddc55b  jnz 0x000077A70FDDFFE1
000077a70fddc561  movaps xmm1, [r15+0x2B0]
000077a70fddc569  vmovaps xmm14, [rsp+0x40]
000077a70fddc56f  vpermilpd xmm14, xmm14, 0x00
000077a70fddc575  movaps xmm6, xmm1
000077a70fddc578  mulpd xmm6, xmm14
000077a70fddc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000077a70fddc582  ptest xmm5, xmm5
000077a70fddc587  jnz 0x000077A70FDE0124
000077a70fddc58d  vmovaps xmm1, [rsp+0x10]
000077a70fddc593  vpermilpd xmm1, xmm1, 0x00
000077a70fddc599  movaps xmm14, xmm12
000077a70fddc59d  mulpd xmm14, xmm1
000077a70fddc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000077a70fddc5a8  ptest xmm5, xmm5
000077a70fddc5ad  jnz 0x000077A70FDE0265
000077a70fddc5b3  movaps xmm1, xmm13
000077a70fddc5b7  addpd xmm1, xmm9
000077a70fddc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000077a70fddc5c1  ptest xmm12, xmm12
000077a70fddc5c7  jnz 0x000077A70FDE03A8
000077a70fddc5cd  vmovaps xmm13, [rsp+0x10]
000077a70fddc5d3  vpermilpd xmm13, xmm13, 0x00
000077a70fddc5d9  movaps xmm12, xmm7
000077a70fddc5dd  mulpd xmm12, xmm13
000077a70fddc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000077a70fddc5e8  ptest xmm9, xmm9
000077a70fddc5ee  jnz 0x000077A70FDE04EA
000077a70fddc5f4  movaps xmm13, xmm15
000077a70fddc5f8  addpd xmm13, xmm8
000077a70fddc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000077a70fddc603  ptest xmm9, xmm9
000077a70fddc609  jnz 0x000077A70FDE062D
000077a70fddc60f  movaps xmm15, [r15+0x290]
000077a70fddc617  vmovaps xmm9, [rsp+0x10]
000077a70fddc61d  vpermilpd xmm9, xmm9, 0x00
000077a70fddc623  movaps xmm8, xmm15
000077a70fddc627  mulpd xmm8, xmm9
000077a70fddc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000077a70fddc632  ptest xmm7, xmm7
000077a70fddc637  jnz 0x000077A70FDE0771
000077a70fddc63d  movaps xmm15, xmm11
000077a70fddc641  addpd xmm15, xmm6
000077a70fddc646  vcmppd xmm9, xmm15, xmm15, 0x03
000077a70fddc64c  ptest xmm9, xmm9
000077a70fddc652  jnz 0x000077A70FDE08B5
000077a70fddc658  movaps xmm11, [r15+0x1E0]
000077a70fddc660  vmovaps xmm9, [rsp+0x10]
000077a70fddc666  vpermilpd xmm9, xmm9, 0x00
000077a70fddc66c  movaps xmm7, xmm11
000077a70fddc670  mulpd xmm7, xmm9
000077a70fddc675  vcmppd xmm6, xmm7, xmm7, 0x03
000077a70fddc67a  ptest xmm6, xmm6
000077a70fddc67f  jnz 0x000077A70FDE09F8
000077a70fddc685  movaps xmm11, xmm10
000077a70fddc689  addpd xmm11, xmm14
000077a70fddc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000077a70fddc694  ptest xmm9, xmm9
000077a70fddc69a  jnz 0x000077A70FDE0B3A
000077a70fddc6a0  lea r12, [rax+0x70]
000077a70fddc6a4  movups xmm14, [r13+r12*1]
000077a70fddc6aa  movaps [r15+0x240], xmm14
000077a70fddc6b2  movaps xmm10, xmm1
000077a70fddc6b6  addpd xmm10, xmm12
000077a70fddc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000077a70fddc6c1  ptest xmm9, xmm9
000077a70fddc6c7  jnz 0x000077A70FDE0C88
000077a70fddc6cd  movaps [r15+0x170], xmm10
000077a70fddc6d5  vmovaps xmm1, [rsp+0x20]
000077a70fddc6db  vpermilpd xmm1, xmm1, 0x00
000077a70fddc6e1  movaps xmm12, xmm14
000077a70fddc6e5  mulpd xmm12, xmm1
000077a70fddc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000077a70fddc6f0  ptest xmm9, xmm9
000077a70fddc6f6  jnz 0x000077A70FDE0DCB
000077a70fddc6fc  vmovaps xmm1, [rsp+0x20]
000077a70fddc702  vpermilpd xmm1, xmm1, 0x00
000077a70fddc708  vmovaps xmm9, [rsp+0xB0]
000077a70fddc711  movaps xmm14, xmm9
000077a70fddc715  mulpd xmm14, xmm1
000077a70fddc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000077a70fddc720  ptest xmm6, xmm6
000077a70fddc725  jnz 0x000077A70FDE0F0E
000077a70fddc72b  movaps [r15+0x180], xmm14
000077a70fddc733  movaps xmm1, xmm13
000077a70fddc737  addpd xmm1, xmm8
000077a70fddc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000077a70fddc741  ptest xmm9, xmm9
000077a70fddc747  jnz 0x000077A70FDE1051
000077a70fddc74d  movaps [r15+0x210], xmm1
000077a70fddc755  movups xmm13, [r13+rax*1]
000077a70fddc75b  lea r12, [rax+0x10]
000077a70fddc75f  movups xmm9, [r13+r12*1]
000077a70fddc765  movaps [r15+0x230], xmm9
000077a70fddc76d  movaps xmm8, xmm15
000077a70fddc771  addpd xmm8, xmm7
000077a70fddc776  vcmppd xmm6, xmm8, xmm8, 0x03
000077a70fddc77c  ptest xmm6, xmm6
000077a70fddc781  jnz 0x000077A70FDE11A7
000077a70fddc787  movaps [r15+0x130], xmm8
000077a70fddc78f  vmovaps xmm15, [rsp+0x20]
000077a70fddc795  vpermilpd xmm15, xmm15, 0x00
000077a70fddc79b  movaps xmm7, xmm9
000077a70fddc79f  mulpd xmm7, xmm15
000077a70fddc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000077a70fddc7a9  ptest xmm6, xmm6
000077a70fddc7ae  jnz 0x000077A70FDE12EA
000077a70fddc7b4  movaps [r15+0x220], xmm7
000077a70fddc7bc  vmovaps xmm15, [rsp+0x20]
000077a70fddc7c2  vpermilpd xmm15, xmm15, 0x00
000077a70fddc7c8  movaps xmm9, xmm13
000077a70fddc7cc  mulpd xmm9, xmm15
000077a70fddc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000077a70fddc7d7  ptest xmm6, xmm6
000077a70fddc7dc  jnz 0x000077A70FDE142C
000077a70fddc7e2  movaps xmm15, xmm11
000077a70fddc7e6  addpd xmm15, xmm12
000077a70fddc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000077a70fddc7f1  ptest xmm13, xmm13
000077a70fddc7f7  jnz 0x000077A70FDE1570
000077a70fddc7fd  movaps [r15+0x140], xmm15
000077a70fddc805  movaps xmm13, xmm10
000077a70fddc809  addpd xmm13, xmm14
000077a70fddc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000077a70fddc814  ptest xmm12, xmm12
000077a70fddc81a  jnz 0x000077A70FDE16B4
000077a70fddc820  movaps [r15+0x150], xmm13
000077a70fddc828  movaps xmm14, xmm1
000077a70fddc82c  addpd xmm14, xmm7
000077a70fddc831  vcmppd xmm12, xmm14, xmm14, 0x03
000077a70fddc837  ptest xmm12, xmm12
000077a70fddc83d  jnz 0x000077A70FDE17F8
000077a70fddc843  movaps [r15+0x160], xmm14
000077a70fddc84b  movaps xmm1, xmm8
000077a70fddc84f  addpd xmm1, xmm9
000077a70fddc854  vcmppd xmm12, xmm1, xmm1, 0x03
000077a70fddc859  ptest xmm12, xmm12
000077a70fddc85f  jnz 0x000077A70FDE193A
000077a70fddc865  movaps [r15+0x120], xmm1
000077a70fddc86d  movups [r13+r14*1], xmm15
000077a70fddc873  lea rax, [r14+0x10]
000077a70fddc877  movups [r13+rax*1], xmm13
000077a70fddc87d  lea rax, [r14+0x20]
000077a70fddc881  movups [r13+rax*1], xmm14
000077a70fddc887  lea rax, [r14+0x30]
000077a70fddc88b  movups [r13+rax*1], xmm1
000077a70fddc891  mov eax, [r15+0x108]
000077a70fddc898  sahf
000077a70fddc899  jnz 0x000077A70FDDC8CB
000077a70fddc89b  cmp dword ptr [r15+0x318], 0x00
000077a70fddc8a3  jz 0x000077A70FDDB900
000077a70fddc8a9  nop [rax+rax*1], ax
000077a70fddc8b2  nop [rax+rax*1], eax
000077a70fddc8ba  mov eax, 0x410444
000077a70fddc8bf  mov [r15+0x100], rax
000077a70fddc8c6  jmp 0x000077A70FBFE110
000077a70fddc8cb  cmp dword ptr [r15+0x318], 0x00
000077a70fddc8d3  jz 0x000077A70FDD57E0
000077a70fddc8d9  nop [rax+rax*1], ax
000077a70fddc8e2  nop [rax+rax*1], eax
000077a70fddc8ea  mov eax, 0x410278
000077a70fddc8ef  mov [r15+0x100], rax
000077a70fddc8f6  jmp 0x000077A70FBFE110
000077a70fddc8fb  int3
000077a70fddc8fc  call 0x000077A70FCE27E0
000077a70fddc901  jmp 0x000077A70FDDB9DF
000077a70fddc906  call 0x000077A70FCE1570
000077a70fddc90b  jmp 0x000077A70FDDB9E8
000077a70fddc910  call 0x000077A70FCE27E0
000077a70fddc915  jmp 0x000077A70FDDBA44
000077a70fddc91a  call 0x000077A70FCE1570
000077a70fddc91f  jmp 0x000077A70FDDBA4D
000077a70fddc924  call 0x000077A70FCE27E0
000077a70fddc929  jmp 0x000077A70FDDBA90
000077a70fddc92e  call 0x000077A70FCE1570
000077a70fddc933  jmp 0x000077A70FDDBA99
000077a70fddc938  call 0x000077A70FC0DC20
000077a70fddc93d  jmp 0x000077A70FDDBAD8
000077a70fddc942  call 0x000077A70FCD59C0
000077a70fddc947  jmp 0x000077A70FDDBAEB
000077a70fddc94c  call 0x000077A70FCE0E30
000077a70fddc951  jmp 0x000077A70FDDBB09
000077a70fddc956  call 0x000077A70FCDFBC0
000077a70fddc95b  jmp 0x000077A70FDDBB13
000077a70fddc960  call 0x000077A70FCDE950
000077a70fddc965  jmp 0x000077A70FDDBB1D
000077a70fddc96a  sub rsp, 0x08
000077a70fddc96e  push rax
000077a70fddc96f  push rcx
000077a70fddc970  push rdx
000077a70fddc971  push rdi
000077a70fddc972  push rsi
000077a70fddc973  push r8
000077a70fddc975  push r9
000077a70fddc977  push r10
000077a70fddc979  push r11
000077a70fddc97b  sub rsp, 0xF0
000077a70fddc982  vmovaps [rsp], xmm0
000077a70fddc987  vmovaps [rsp+0x10], xmm1
000077a70fddc98d  vmovaps [rsp+0x20], xmm2
000077a70fddc993  vmovaps [rsp+0x30], xmm3
000077a70fddc999  vmovaps [rsp+0x40], xmm4
000077a70fddc99f  vmovaps [rsp+0x50], xmm5
000077a70fddc9a5  vmovaps [rsp+0x60], xmm6
000077a70fddc9ab  vmovaps [rsp+0x70], xmm7
000077a70fddc9b1  vmovaps [rsp+0x80], xmm9
000077a70fddc9ba  vmovaps [rsp+0x90], xmm10
000077a70fddc9c3  vmovaps [rsp+0xA0], xmm11
000077a70fddc9cc  vmovaps [rsp+0xB0], xmm12
000077a70fddc9d5  vmovaps [rsp+0xC0], xmm13
000077a70fddc9de  vmovaps [rsp+0xD0], xmm14
000077a70fddc9e7  vmovaps [rsp+0xE0], xmm15
000077a70fddc9f0  sub rsp, 0x30
000077a70fddc9f4  movaps [rsp], xmm8
000077a70fddc9f9  movaps [rsp+0x10], xmm12
000077a70fddc9ff  movaps [rsp+0x20], xmm15
000077a70fddca05  lea rdi, [rsp]
000077a70fddca09  mov esi, 0x00
000077a70fddca0e  mov rax, 0x6294188EF530
000077a70fddca18  call rax
000077a70fddca1a  movaps xmm8, [rsp]
000077a70fddca1f  add rsp, 0x30
000077a70fddca23  vmovaps xmm0, [rsp]
000077a70fddca28  vmovaps xmm1, [rsp+0x10]
000077a70fddca2e  vmovaps xmm2, [rsp+0x20]
000077a70fddca34  vmovaps xmm3, [rsp+0x30]
000077a70fddca3a  vmovaps xmm4, [rsp+0x40]
000077a70fddca40  vmovaps xmm5, [rsp+0x50]
000077a70fddca46  vmovaps xmm6, [rsp+0x60]
000077a70fddca4c  vmovaps xmm7, [rsp+0x70]
000077a70fddca52  vmovaps xmm9, [rsp+0x80]
000077a70fddca5b  vmovaps xmm10, [rsp+0x90]
000077a70fddca64  vmovaps xmm11, [rsp+0xA0]
000077a70fddca6d  vmovaps xmm12, [rsp+0xB0]
000077a70fddca76  vmovaps xmm13, [rsp+0xC0]
000077a70fddca7f  vmovaps xmm14, [rsp+0xD0]
000077a70fddca88  vmovaps xmm15, [rsp+0xE0]
000077a70fddca91  add rsp, 0xF0
000077a70fddca98  pop r11
000077a70fddca9a  pop r10
000077a70fddca9c  pop r9
000077a70fddca9e  pop r8
000077a70fddcaa0  pop rsi
000077a70fddcaa1  pop rdi
000077a70fddcaa2  pop rdx
000077a70fddcaa3  pop rcx
000077a70fddcaa4  pop rax
000077a70fddcaa5  add rsp, 0x08
000077a70fddcaa9  jmp 0x000077A70FDDBB47
000077a70fddcaae  sub rsp, 0x08
000077a70fddcab2  push rax
000077a70fddcab3  push rcx
000077a70fddcab4  push rdx
000077a70fddcab5  push rdi
000077a70fddcab6  push rsi
000077a70fddcab7  push r8
000077a70fddcab9  push r9
000077a70fddcabb  push r10
000077a70fddcabd  push r11
000077a70fddcabf  sub rsp, 0xF0
000077a70fddcac6  vmovaps [rsp], xmm0
000077a70fddcacb  vmovaps [rsp+0x10], xmm1
000077a70fddcad1  vmovaps [rsp+0x20], xmm2
000077a70fddcad7  vmovaps [rsp+0x30], xmm3
000077a70fddcadd  vmovaps [rsp+0x40], xmm4
000077a70fddcae3  vmovaps [rsp+0x50], xmm5
000077a70fddcae9  vmovaps [rsp+0x60], xmm6
000077a70fddcaef  vmovaps [rsp+0x70], xmm8
000077a70fddcaf5  vmovaps [rsp+0x80], xmm9
000077a70fddcafe  vmovaps [rsp+0x90], xmm10
000077a70fddcb07  vmovaps [rsp+0xA0], xmm11
000077a70fddcb10  vmovaps [rsp+0xB0], xmm12
000077a70fddcb19  vmovaps [rsp+0xC0], xmm13
000077a70fddcb22  vmovaps [rsp+0xD0], xmm14
000077a70fddcb2b  vmovaps [rsp+0xE0], xmm15
000077a70fddcb34  sub rsp, 0x30
000077a70fddcb38  movaps [rsp], xmm7
000077a70fddcb3c  movaps [rsp+0x10], xmm9
000077a70fddcb42  movaps [rsp+0x20], xmm15
000077a70fddcb48  lea rdi, [rsp]
000077a70fddcb4c  mov esi, 0x00
000077a70fddcb51  mov rax, 0x6294188EF530
000077a70fddcb5b  call rax
000077a70fddcb5d  movaps xmm7, [rsp]
000077a70fddcb61  add rsp, 0x30
000077a70fddcb65  vmovaps xmm0, [rsp]
000077a70fddcb6a  vmovaps xmm1, [rsp+0x10]
000077a70fddcb70  vmovaps xmm2, [rsp+0x20]
000077a70fddcb76  vmovaps xmm3, [rsp+0x30]
000077a70fddcb7c  vmovaps xmm4, [rsp+0x40]
000077a70fddcb82  vmovaps xmm5, [rsp+0x50]
000077a70fddcb88  vmovaps xmm6, [rsp+0x60]
000077a70fddcb8e  vmovaps xmm8, [rsp+0x70]
000077a70fddcb94  vmovaps xmm9, [rsp+0x80]
000077a70fddcb9d  vmovaps xmm10, [rsp+0x90]
000077a70fddcba6  vmovaps xmm11, [rsp+0xA0]
000077a70fddcbaf  vmovaps xmm12, [rsp+0xB0]
000077a70fddcbb8  vmovaps xmm13, [rsp+0xC0]
000077a70fddcbc1  vmovaps xmm14, [rsp+0xD0]
000077a70fddcbca  vmovaps xmm15, [rsp+0xE0]
000077a70fddcbd3  add rsp, 0xF0
000077a70fddcbda  pop r11
000077a70fddcbdc  pop r10
000077a70fddcbde  pop r9
000077a70fddcbe0  pop r8
000077a70fddcbe2  pop rsi
000077a70fddcbe3  pop rdi
000077a70fddcbe4  pop rdx
000077a70fddcbe5  pop rcx
000077a70fddcbe6  pop rax
000077a70fddcbe7  add rsp, 0x08
000077a70fddcbeb  jmp 0x000077A70FDDBB75
000077a70fddcbf0  sub rsp, 0x08
000077a70fddcbf4  push rax
000077a70fddcbf5  push rcx
000077a70fddcbf6  push rdx
000077a70fddcbf7  push rdi
000077a70fddcbf8  push rsi
000077a70fddcbf9  push r8
000077a70fddcbfb  push r9
000077a70fddcbfd  push r10
000077a70fddcbff  push r11
000077a70fddcc01  sub rsp, 0xF0
000077a70fddcc08  vmovaps [rsp], xmm0
000077a70fddcc0d  vmovaps [rsp+0x10], xmm1
000077a70fddcc13  vmovaps [rsp+0x20], xmm2
000077a70fddcc19  vmovaps [rsp+0x30], xmm3
000077a70fddcc1f  vmovaps [rsp+0x40], xmm4
000077a70fddcc25  vmovaps [rsp+0x50], xmm5
000077a70fddcc2b  vmovaps [rsp+0x60], xmm6
000077a70fddcc31  vmovaps [rsp+0x70], xmm7
000077a70fddcc37  vmovaps [rsp+0x80], xmm8
000077a70fddcc40  vmovaps [rsp+0x90], xmm10
000077a70fddcc49  vmovaps [rsp+0xA0], xmm11
000077a70fddcc52  vmovaps [rsp+0xB0], xmm12
000077a70fddcc5b  vmovaps [rsp+0xC0], xmm13
000077a70fddcc64  vmovaps [rsp+0xD0], xmm14
000077a70fddcc6d  vmovaps [rsp+0xE0], xmm15
000077a70fddcc76  sub rsp, 0x30
000077a70fddcc7a  movaps [rsp], xmm9
000077a70fddcc7f  movaps [rsp+0x10], xmm12
000077a70fddcc85  movaps [rsp+0x20], xmm10
000077a70fddcc8b  lea rdi, [rsp]
000077a70fddcc8f  mov esi, 0x00
000077a70fddcc94  mov rax, 0x6294188EF530
000077a70fddcc9e  call rax
000077a70fddcca0  movaps xmm9, [rsp]
000077a70fddcca5  add rsp, 0x30
000077a70fddcca9  vmovaps xmm0, [rsp]
000077a70fddccae  vmovaps xmm1, [rsp+0x10]
000077a70fddccb4  vmovaps xmm2, [rsp+0x20]
000077a70fddccba  vmovaps xmm3, [rsp+0x30]
000077a70fddccc0  vmovaps xmm4, [rsp+0x40]
000077a70fddccc6  vmovaps xmm5, [rsp+0x50]
000077a70fddcccc  vmovaps xmm6, [rsp+0x60]
000077a70fddccd2  vmovaps xmm7, [rsp+0x70]
000077a70fddccd8  vmovaps xmm8, [rsp+0x80]
000077a70fddcce1  vmovaps xmm10, [rsp+0x90]
000077a70fddccea  vmovaps xmm11, [rsp+0xA0]
000077a70fddccf3  vmovaps xmm12, [rsp+0xB0]
000077a70fddccfc  vmovaps xmm13, [rsp+0xC0]
000077a70fddcd05  vmovaps xmm14, [rsp+0xD0]
000077a70fddcd0e  vmovaps xmm15, [rsp+0xE0]
000077a70fddcd17  add rsp, 0xF0
000077a70fddcd1e  pop r11
000077a70fddcd20  pop r10
000077a70fddcd22  pop r9
000077a70fddcd24  pop r8
000077a70fddcd26  pop rsi
000077a70fddcd27  pop rdi
000077a70fddcd28  pop rdx
000077a70fddcd29  pop rcx
000077a70fddcd2a  pop rax
000077a70fddcd2b  add rsp, 0x08
000077a70fddcd2f  jmp 0x000077A70FDDBB99
000077a70fddcd34  sub rsp, 0x08
000077a70fddcd38  push rax
000077a70fddcd39  push rcx
000077a70fddcd3a  push rdx
000077a70fddcd3b  push rdi
000077a70fddcd3c  push rsi
000077a70fddcd3d  push r8
000077a70fddcd3f  push r9
000077a70fddcd41  push r10
000077a70fddcd43  push r11
000077a70fddcd45  sub rsp, 0xF0
000077a70fddcd4c  vmovaps [rsp], xmm0
000077a70fddcd51  vmovaps [rsp+0x10], xmm1
000077a70fddcd57  vmovaps [rsp+0x20], xmm2
000077a70fddcd5d  vmovaps [rsp+0x30], xmm3
000077a70fddcd63  vmovaps [rsp+0x40], xmm4
000077a70fddcd69  vmovaps [rsp+0x50], xmm5
000077a70fddcd6f  vmovaps [rsp+0x60], xmm6
000077a70fddcd75  vmovaps [rsp+0x70], xmm7
000077a70fddcd7b  vmovaps [rsp+0x80], xmm8
000077a70fddcd84  vmovaps [rsp+0x90], xmm9
000077a70fddcd8d  vmovaps [rsp+0xA0], xmm11
000077a70fddcd96  vmovaps [rsp+0xB0], xmm12
000077a70fddcd9f  vmovaps [rsp+0xC0], xmm13
000077a70fddcda8  vmovaps [rsp+0xD0], xmm14
000077a70fddcdb1  vmovaps [rsp+0xE0], xmm15
000077a70fddcdba  sub rsp, 0x30
000077a70fddcdbe  movaps [rsp], xmm10
000077a70fddcdc3  movaps [rsp+0x10], xmm12
000077a70fddcdc9  movaps [rsp+0x20], xmm11
000077a70fddcdcf  lea rdi, [rsp]
000077a70fddcdd3  mov esi, 0x00
000077a70fddcdd8  mov rax, 0x6294188EF530
000077a70fddcde2  call rax
000077a70fddcde4  movaps xmm10, [rsp]
000077a70fddcde9  add rsp, 0x30
000077a70fddcded  vmovaps xmm0, [rsp]
000077a70fddcdf2  vmovaps xmm1, [rsp+0x10]
000077a70fddcdf8  vmovaps xmm2, [rsp+0x20]
000077a70fddcdfe  vmovaps xmm3, [rsp+0x30]
000077a70fddce04  vmovaps xmm4, [rsp+0x40]
000077a70fddce0a  vmovaps xmm5, [rsp+0x50]
000077a70fddce10  vmovaps xmm6, [rsp+0x60]
000077a70fddce16  vmovaps xmm7, [rsp+0x70]
000077a70fddce1c  vmovaps xmm8, [rsp+0x80]
000077a70fddce25  vmovaps xmm9, [rsp+0x90]
000077a70fddce2e  vmovaps xmm11, [rsp+0xA0]
000077a70fddce37  vmovaps xmm12, [rsp+0xB0]
000077a70fddce40  vmovaps xmm13, [rsp+0xC0]
000077a70fddce49  vmovaps xmm14, [rsp+0xD0]
000077a70fddce52  vmovaps xmm15, [rsp+0xE0]
000077a70fddce5b  add rsp, 0xF0
000077a70fddce62  pop r11
000077a70fddce64  pop r10
000077a70fddce66  pop r9
000077a70fddce68  pop r8
000077a70fddce6a  pop rsi
000077a70fddce6b  pop rdi
000077a70fddce6c  pop rdx
000077a70fddce6d  pop rcx
000077a70fddce6e  pop rax
000077a70fddce6f  add rsp, 0x08
000077a70fddce73  jmp 0x000077A70FDDBBB3
000077a70fddce78  sub rsp, 0x08
000077a70fddce7c  push rax
000077a70fddce7d  push rcx
000077a70fddce7e  push rdx
000077a70fddce7f  push rdi
000077a70fddce80  push rsi
000077a70fddce81  push r8
000077a70fddce83  push r9
000077a70fddce85  push r10
000077a70fddce87  push r11
000077a70fddce89  sub rsp, 0xF0
000077a70fddce90  vmovaps [rsp], xmm0
000077a70fddce95  vmovaps [rsp+0x10], xmm1
000077a70fddce9b  vmovaps [rsp+0x20], xmm2
000077a70fddcea1  vmovaps [rsp+0x30], xmm3
000077a70fddcea7  vmovaps [rsp+0x40], xmm4
000077a70fddcead  vmovaps [rsp+0x50], xmm5
000077a70fddceb3  vmovaps [rsp+0x60], xmm7
000077a70fddceb9  vmovaps [rsp+0x70], xmm8
000077a70fddcebf  vmovaps [rsp+0x80], xmm9
000077a70fddcec8  vmovaps [rsp+0x90], xmm10
000077a70fddced1  vmovaps [rsp+0xA0], xmm11
000077a70fddceda  vmovaps [rsp+0xB0], xmm12
000077a70fddcee3  vmovaps [rsp+0xC0], xmm13
000077a70fddceec  vmovaps [rsp+0xD0], xmm14
000077a70fddcef5  vmovaps [rsp+0xE0], xmm15
000077a70fddcefe  sub rsp, 0x30
000077a70fddcf02  movaps [rsp], xmm6
000077a70fddcf06  movaps [rsp+0x10], xmm12
000077a70fddcf0c  movaps [rsp+0x20], xmm11
000077a70fddcf12  lea rdi, [rsp]
000077a70fddcf16  mov esi, 0x00
000077a70fddcf1b  mov rax, 0x6294188EF530
000077a70fddcf25  call rax
000077a70fddcf27  movaps xmm6, [rsp]
000077a70fddcf2b  add rsp, 0x30
000077a70fddcf2f  vmovaps xmm0, [rsp]
000077a70fddcf34  vmovaps xmm1, [rsp+0x10]
000077a70fddcf3a  vmovaps xmm2, [rsp+0x20]
000077a70fddcf40  vmovaps xmm3, [rsp+0x30]
000077a70fddcf46  vmovaps xmm4, [rsp+0x40]
000077a70fddcf4c  vmovaps xmm5, [rsp+0x50]
000077a70fddcf52  vmovaps xmm7, [rsp+0x60]
000077a70fddcf58  vmovaps xmm8, [rsp+0x70]
000077a70fddcf5e  vmovaps xmm9, [rsp+0x80]
000077a70fddcf67  vmovaps xmm10, [rsp+0x90]
000077a70fddcf70  vmovaps xmm11, [rsp+0xA0]
000077a70fddcf79  vmovaps xmm12, [rsp+0xB0]
000077a70fddcf82  vmovaps xmm13, [rsp+0xC0]
000077a70fddcf8b  vmovaps xmm14, [rsp+0xD0]
000077a70fddcf94  vmovaps xmm15, [rsp+0xE0]
000077a70fddcf9d  add rsp, 0xF0
000077a70fddcfa4  pop r11
000077a70fddcfa6  pop r10
000077a70fddcfa8  pop r9
000077a70fddcfaa  pop r8
000077a70fddcfac  pop rsi
000077a70fddcfad  pop rdi
000077a70fddcfae  pop rdx
000077a70fddcfaf  pop rcx
000077a70fddcfb0  pop rax
000077a70fddcfb1  add rsp, 0x08
000077a70fddcfb5  jmp 0x000077A70FDDBBD4
000077a70fddcfba  sub rsp, 0x08
000077a70fddcfbe  push rax
000077a70fddcfbf  push rcx
000077a70fddcfc0  push rdx
000077a70fddcfc1  push rdi
000077a70fddcfc2  push rsi
000077a70fddcfc3  push r8
000077a70fddcfc5  push r9
000077a70fddcfc7  push r10
000077a70fddcfc9  push r11
000077a70fddcfcb  sub rsp, 0xF0
000077a70fddcfd2  vmovaps [rsp], xmm0
000077a70fddcfd7  vmovaps [rsp+0x10], xmm1
000077a70fddcfdd  vmovaps [rsp+0x20], xmm2
000077a70fddcfe3  vmovaps [rsp+0x30], xmm4
000077a70fddcfe9  vmovaps [rsp+0x40], xmm5
000077a70fddcfef  vmovaps [rsp+0x50], xmm6
000077a70fddcff5  vmovaps [rsp+0x60], xmm7
000077a70fddcffb  vmovaps [rsp+0x70], xmm8
000077a70fddd001  vmovaps [rsp+0x80], xmm9
000077a70fddd00a  vmovaps [rsp+0x90], xmm10
000077a70fddd013  vmovaps [rsp+0xA0], xmm11
000077a70fddd01c  vmovaps [rsp+0xB0], xmm12
000077a70fddd025  vmovaps [rsp+0xC0], xmm13
000077a70fddd02e  vmovaps [rsp+0xD0], xmm14
000077a70fddd037  vmovaps [rsp+0xE0], xmm15
000077a70fddd040  sub rsp, 0x30
000077a70fddd044  movaps [rsp], xmm3
000077a70fddd048  movaps [rsp+0x10], xmm5
000077a70fddd04d  movaps [rsp+0x20], xmm4
000077a70fddd052  lea rdi, [rsp]
000077a70fddd056  mov esi, 0x00
000077a70fddd05b  mov rax, 0x6294188EF530
000077a70fddd065  call rax
000077a70fddd067  movaps xmm3, [rsp]
000077a70fddd06b  add rsp, 0x30
000077a70fddd06f  vmovaps xmm0, [rsp]
000077a70fddd074  vmovaps xmm1, [rsp+0x10]
000077a70fddd07a  vmovaps xmm2, [rsp+0x20]
000077a70fddd080  vmovaps xmm4, [rsp+0x30]
000077a70fddd086  vmovaps xmm5, [rsp+0x40]
000077a70fddd08c  vmovaps xmm6, [rsp+0x50]
000077a70fddd092  vmovaps xmm7, [rsp+0x60]
000077a70fddd098  vmovaps xmm8, [rsp+0x70]
000077a70fddd09e  vmovaps xmm9, [rsp+0x80]
000077a70fddd0a7  vmovaps xmm10, [rsp+0x90]
000077a70fddd0b0  vmovaps xmm11, [rsp+0xA0]
000077a70fddd0b9  vmovaps xmm12, [rsp+0xB0]
000077a70fddd0c2  vmovaps xmm13, [rsp+0xC0]
000077a70fddd0cb  vmovaps xmm14, [rsp+0xD0]
000077a70fddd0d4  vmovaps xmm15, [rsp+0xE0]
000077a70fddd0dd  add rsp, 0xF0
000077a70fddd0e4  pop r11
000077a70fddd0e6  pop r10
000077a70fddd0e8  pop r9
000077a70fddd0ea  pop r8
000077a70fddd0ec  pop rsi
000077a70fddd0ed  pop rdi
000077a70fddd0ee  pop rdx
000077a70fddd0ef  pop rcx
000077a70fddd0f0  pop rax
000077a70fddd0f1  add rsp, 0x08
000077a70fddd0f5  jmp 0x000077A70FDDBC35
000077a70fddd0fa  sub rsp, 0x08
000077a70fddd0fe  push rax
000077a70fddd0ff  push rcx
000077a70fddd100  push rdx
000077a70fddd101  push rdi
000077a70fddd102  push rsi
000077a70fddd103  push r8
000077a70fddd105  push r9
000077a70fddd107  push r10
000077a70fddd109  push r11
000077a70fddd10b  sub rsp, 0xF0
000077a70fddd112  vmovaps [rsp], xmm0
000077a70fddd117  vmovaps [rsp+0x10], xmm1
000077a70fddd11d  vmovaps [rsp+0x20], xmm2
000077a70fddd123  vmovaps [rsp+0x30], xmm3
000077a70fddd129  vmovaps [rsp+0x40], xmm4
000077a70fddd12f  vmovaps [rsp+0x50], xmm6
000077a70fddd135  vmovaps [rsp+0x60], xmm7
000077a70fddd13b  vmovaps [rsp+0x70], xmm8
000077a70fddd141  vmovaps [rsp+0x80], xmm9
000077a70fddd14a  vmovaps [rsp+0x90], xmm10
000077a70fddd153  vmovaps [rsp+0xA0], xmm11
000077a70fddd15c  vmovaps [rsp+0xB0], xmm12
000077a70fddd165  vmovaps [rsp+0xC0], xmm13
000077a70fddd16e  vmovaps [rsp+0xD0], xmm14
000077a70fddd177  vmovaps [rsp+0xE0], xmm15
000077a70fddd180  sub rsp, 0x30
000077a70fddd184  movaps [rsp], xmm5
000077a70fddd188  movaps [rsp+0x10], xmm8
000077a70fddd18e  movaps [rsp+0x20], xmm15
000077a70fddd194  lea rdi, [rsp]
000077a70fddd198  mov esi, 0x00
000077a70fddd19d  mov rax, 0x6294188EF530
000077a70fddd1a7  call rax
000077a70fddd1a9  movaps xmm5, [rsp]
000077a70fddd1ad  add rsp, 0x30
000077a70fddd1b1  vmovaps xmm0, [rsp]
000077a70fddd1b6  vmovaps xmm1, [rsp+0x10]
000077a70fddd1bc  vmovaps xmm2, [rsp+0x20]
000077a70fddd1c2  vmovaps xmm3, [rsp+0x30]
000077a70fddd1c8  vmovaps xmm4, [rsp+0x40]
000077a70fddd1ce  vmovaps xmm6, [rsp+0x50]
000077a70fddd1d4  vmovaps xmm7, [rsp+0x60]
000077a70fddd1da  vmovaps xmm8, [rsp+0x70]
000077a70fddd1e0  vmovaps xmm9, [rsp+0x80]
000077a70fddd1e9  vmovaps xmm10, [rsp+0x90]
000077a70fddd1f2  vmovaps xmm11, [rsp+0xA0]
000077a70fddd1fb  vmovaps xmm12, [rsp+0xB0]
000077a70fddd204  vmovaps xmm13, [rsp+0xC0]
000077a70fddd20d  vmovaps xmm14, [rsp+0xD0]
000077a70fddd216  vmovaps xmm15, [rsp+0xE0]
000077a70fddd21f  add rsp, 0xF0
000077a70fddd226  pop r11
000077a70fddd228  pop r10
000077a70fddd22a  pop r9
000077a70fddd22c  pop r8
000077a70fddd22e  pop rsi
000077a70fddd22f  pop rdi
000077a70fddd230  pop rdx
000077a70fddd231  pop rcx
000077a70fddd232  pop rax
000077a70fddd233  add rsp, 0x08
000077a70fddd237  jmp 0x000077A70FDDBC73
000077a70fddd23c  sub rsp, 0x08
000077a70fddd240  push rax
000077a70fddd241  push rcx
000077a70fddd242  push rdx
000077a70fddd243  push rdi
000077a70fddd244  push rsi
000077a70fddd245  push r8
000077a70fddd247  push r9
000077a70fddd249  push r10
000077a70fddd24b  push r11
000077a70fddd24d  sub rsp, 0xF0
000077a70fddd254  vmovaps [rsp], xmm0
000077a70fddd259  vmovaps [rsp+0x10], xmm1
000077a70fddd25f  vmovaps [rsp+0x20], xmm2
000077a70fddd265  vmovaps [rsp+0x30], xmm3
000077a70fddd26b  vmovaps [rsp+0x40], xmm5
000077a70fddd271  vmovaps [rsp+0x50], xmm6
000077a70fddd277  vmovaps [rsp+0x60], xmm7
000077a70fddd27d  vmovaps [rsp+0x70], xmm8
000077a70fddd283  vmovaps [rsp+0x80], xmm9
000077a70fddd28c  vmovaps [rsp+0x90], xmm10
000077a70fddd295  vmovaps [rsp+0xA0], xmm11
000077a70fddd29e  vmovaps [rsp+0xB0], xmm12
000077a70fddd2a7  vmovaps [rsp+0xC0], xmm13
000077a70fddd2b0  vmovaps [rsp+0xD0], xmm14
000077a70fddd2b9  vmovaps [rsp+0xE0], xmm15
000077a70fddd2c2  sub rsp, 0x30
000077a70fddd2c6  movaps [rsp], xmm4
000077a70fddd2ca  movaps [rsp+0x10], xmm9
000077a70fddd2d0  movaps [rsp+0x20], xmm8
000077a70fddd2d6  lea rdi, [rsp]
000077a70fddd2da  mov esi, 0x00
000077a70fddd2df  mov rax, 0x6294188EF530
000077a70fddd2e9  call rax
000077a70fddd2eb  movaps xmm4, [rsp]
000077a70fddd2ef  add rsp, 0x30
000077a70fddd2f3  vmovaps xmm0, [rsp]
000077a70fddd2f8  vmovaps xmm1, [rsp+0x10]
000077a70fddd2fe  vmovaps xmm2, [rsp+0x20]
000077a70fddd304  vmovaps xmm3, [rsp+0x30]
000077a70fddd30a  vmovaps xmm5, [rsp+0x40]
000077a70fddd310  vmovaps xmm6, [rsp+0x50]
000077a70fddd316  vmovaps xmm7, [rsp+0x60]
000077a70fddd31c  vmovaps xmm8, [rsp+0x70]
000077a70fddd322  vmovaps xmm9, [rsp+0x80]
000077a70fddd32b  vmovaps xmm10, [rsp+0x90]
000077a70fddd334  vmovaps xmm11, [rsp+0xA0]
000077a70fddd33d  vmovaps xmm12, [rsp+0xB0]
000077a70fddd346  vmovaps xmm13, [rsp+0xC0]
000077a70fddd34f  vmovaps xmm14, [rsp+0xD0]
000077a70fddd358  vmovaps xmm15, [rsp+0xE0]
000077a70fddd361  add rsp, 0xF0
000077a70fddd368  pop r11
000077a70fddd36a  pop r10
000077a70fddd36c  pop r9
000077a70fddd36e  pop r8
000077a70fddd370  pop rsi
000077a70fddd371  pop rdi
000077a70fddd372  pop rdx
000077a70fddd373  pop rcx
000077a70fddd374  pop rax
000077a70fddd375  add rsp, 0x08
000077a70fddd379  jmp 0x000077A70FDDBC94
000077a70fddd37e  sub rsp, 0x08
000077a70fddd382  push rax
000077a70fddd383  push rcx
000077a70fddd384  push rdx
000077a70fddd385  push rdi
000077a70fddd386  push rsi
000077a70fddd387  push r8
000077a70fddd389  push r9
000077a70fddd38b  push r10
000077a70fddd38d  push r11
000077a70fddd38f  sub rsp, 0xF0
000077a70fddd396  vmovaps [rsp], xmm0
000077a70fddd39b  vmovaps [rsp+0x10], xmm1
000077a70fddd3a1  vmovaps [rsp+0x20], xmm2
000077a70fddd3a7  vmovaps [rsp+0x30], xmm3
000077a70fddd3ad  vmovaps [rsp+0x40], xmm4
000077a70fddd3b3  vmovaps [rsp+0x50], xmm5
000077a70fddd3b9  vmovaps [rsp+0x60], xmm6
000077a70fddd3bf  vmovaps [rsp+0x70], xmm7
000077a70fddd3c5  vmovaps [rsp+0x80], xmm8
000077a70fddd3ce  vmovaps [rsp+0x90], xmm10
000077a70fddd3d7  vmovaps [rsp+0xA0], xmm11
000077a70fddd3e0  vmovaps [rsp+0xB0], xmm12
000077a70fddd3e9  vmovaps [rsp+0xC0], xmm13
000077a70fddd3f2  vmovaps [rsp+0xD0], xmm14
000077a70fddd3fb  vmovaps [rsp+0xE0], xmm15
000077a70fddd404  sub rsp, 0x30
000077a70fddd408  movaps [rsp], xmm9
000077a70fddd40d  movaps [rsp+0x10], xmm10
000077a70fddd413  movaps [rsp+0x20], xmm8
000077a70fddd419  lea rdi, [rsp]
000077a70fddd41d  mov esi, 0x00
000077a70fddd422  mov rax, 0x6294188EF530
000077a70fddd42c  call rax
000077a70fddd42e  movaps xmm9, [rsp]
000077a70fddd433  add rsp, 0x30
000077a70fddd437  vmovaps xmm0, [rsp]
000077a70fddd43c  vmovaps xmm1, [rsp+0x10]
000077a70fddd442  vmovaps xmm2, [rsp+0x20]
000077a70fddd448  vmovaps xmm3, [rsp+0x30]
000077a70fddd44e  vmovaps xmm4, [rsp+0x40]
000077a70fddd454  vmovaps xmm5, [rsp+0x50]
000077a70fddd45a  vmovaps xmm6, [rsp+0x60]
000077a70fddd460  vmovaps xmm7, [rsp+0x70]
000077a70fddd466  vmovaps xmm8, [rsp+0x80]
000077a70fddd46f  vmovaps xmm10, [rsp+0x90]
000077a70fddd478  vmovaps xmm11, [rsp+0xA0]
000077a70fddd481  vmovaps xmm12, [rsp+0xB0]
000077a70fddd48a  vmovaps xmm13, [rsp+0xC0]
000077a70fddd493  vmovaps xmm14, [rsp+0xD0]
000077a70fddd49c  vmovaps xmm15, [rsp+0xE0]
000077a70fddd4a5  add rsp, 0xF0
000077a70fddd4ac  pop r11
000077a70fddd4ae  pop r10
000077a70fddd4b0  pop r9
000077a70fddd4b2  pop r8
000077a70fddd4b4  pop rsi
000077a70fddd4b5  pop rdi
000077a70fddd4b6  pop rdx
000077a70fddd4b7  pop rcx
000077a70fddd4b8  pop rax
000077a70fddd4b9  add rsp, 0x08
000077a70fddd4bd  jmp 0x000077A70FDDBCAE
000077a70fddd4c2  call 0x000077A70FCB52F0
000077a70fddd4c7  jmp 0x000077A70FDDBDC8
000077a70fddd4cc  call 0x000077A70FCB52F0
000077a70fddd4d1  jmp 0x000077A70FDDBDDE
000077a70fddd4d6  sub rsp, 0x08
000077a70fddd4da  push rax
000077a70fddd4db  push rcx
000077a70fddd4dc  push rdx
000077a70fddd4dd  push rdi
000077a70fddd4de  push rsi
000077a70fddd4df  push r8
000077a70fddd4e1  push r9
000077a70fddd4e3  push r10
000077a70fddd4e5  push r11
000077a70fddd4e7  sub rsp, 0xF0
000077a70fddd4ee  vmovaps [rsp], xmm0
000077a70fddd4f3  vmovaps [rsp+0x10], xmm2
000077a70fddd4f9  vmovaps [rsp+0x20], xmm3
000077a70fddd4ff  vmovaps [rsp+0x30], xmm4
000077a70fddd505  vmovaps [rsp+0x40], xmm5
000077a70fddd50b  vmovaps [rsp+0x50], xmm6
000077a70fddd511  vmovaps [rsp+0x60], xmm7
000077a70fddd517  vmovaps [rsp+0x70], xmm8
000077a70fddd51d  vmovaps [rsp+0x80], xmm9
000077a70fddd526  vmovaps [rsp+0x90], xmm10
000077a70fddd52f  vmovaps [rsp+0xA0], xmm11
000077a70fddd538  vmovaps [rsp+0xB0], xmm12
000077a70fddd541  vmovaps [rsp+0xC0], xmm13
000077a70fddd54a  vmovaps [rsp+0xD0], xmm14
000077a70fddd553  vmovaps [rsp+0xE0], xmm15
000077a70fddd55c  sub rsp, 0x30
000077a70fddd560  movaps [rsp], xmm1
000077a70fddd564  movaps [rsp+0x10], xmm6
000077a70fddd569  movaps [rsp+0x20], xmm15
000077a70fddd56f  lea rdi, [rsp]
000077a70fddd573  mov esi, 0x00
000077a70fddd578  mov rax, 0x6294188EF530
000077a70fddd582  call rax
000077a70fddd584  movaps xmm1, [rsp]
000077a70fddd588  add rsp, 0x30
000077a70fddd58c  vmovaps xmm0, [rsp]
000077a70fddd591  vmovaps xmm2, [rsp+0x10]
000077a70fddd597  vmovaps xmm3, [rsp+0x20]
000077a70fddd59d  vmovaps xmm4, [rsp+0x30]
000077a70fddd5a3  vmovaps xmm5, [rsp+0x40]
000077a70fddd5a9  vmovaps xmm6, [rsp+0x50]
000077a70fddd5af  vmovaps xmm7, [rsp+0x60]
000077a70fddd5b5  vmovaps xmm8, [rsp+0x70]
000077a70fddd5bb  vmovaps xmm9, [rsp+0x80]
000077a70fddd5c4  vmovaps xmm10, [rsp+0x90]
000077a70fddd5cd  vmovaps xmm11, [rsp+0xA0]
000077a70fddd5d6  vmovaps xmm12, [rsp+0xB0]
000077a70fddd5df  vmovaps xmm13, [rsp+0xC0]
000077a70fddd5e8  vmovaps xmm14, [rsp+0xD0]
000077a70fddd5f1  vmovaps xmm15, [rsp+0xE0]
000077a70fddd5fa  add rsp, 0xF0
000077a70fddd601  pop r11
000077a70fddd603  pop r10
000077a70fddd605  pop r9
000077a70fddd607  pop r8
000077a70fddd609  pop rsi
000077a70fddd60a  pop rdi
000077a70fddd60b  pop rdx
000077a70fddd60c  pop rcx
000077a70fddd60d  pop rax
000077a70fddd60e  add rsp, 0x08
000077a70fddd612  jmp 0x000077A70FDDBE1B
000077a70fddd617  call 0x000077A70FCC4620
000077a70fddd61c  jmp 0x000077A70FDDBE28
000077a70fddd621  sub rsp, 0x08
000077a70fddd625  push rax
000077a70fddd626  push rcx
000077a70fddd627  push rdx
000077a70fddd628  push rdi
000077a70fddd629  push rsi
000077a70fddd62a  push r8
000077a70fddd62c  push r9
000077a70fddd62e  push r10
000077a70fddd630  push r11
000077a70fddd632  sub rsp, 0xF0
000077a70fddd639  vmovaps [rsp], xmm0
000077a70fddd63e  vmovaps [rsp+0x10], xmm1
000077a70fddd644  vmovaps [rsp+0x20], xmm2
000077a70fddd64a  vmovaps [rsp+0x30], xmm3
000077a70fddd650  vmovaps [rsp+0x40], xmm4
000077a70fddd656  vmovaps [rsp+0x50], xmm5
000077a70fddd65c  vmovaps [rsp+0x60], xmm6
000077a70fddd662  vmovaps [rsp+0x70], xmm7
000077a70fddd668  vmovaps [rsp+0x80], xmm8
000077a70fddd671  vmovaps [rsp+0x90], xmm9
000077a70fddd67a  vmovaps [rsp+0xA0], xmm10
000077a70fddd683  vmovaps [rsp+0xB0], xmm11
000077a70fddd68c  vmovaps [rsp+0xC0], xmm12
000077a70fddd695  vmovaps [rsp+0xD0], xmm13
000077a70fddd69e  vmovaps [rsp+0xE0], xmm15
000077a70fddd6a7  sub rsp, 0x30
000077a70fddd6ab  movaps [rsp], xmm14
000077a70fddd6b0  movaps [rsp+0x10], xmm4
000077a70fddd6b5  movaps [rsp+0x20], xmm3
000077a70fddd6ba  lea rdi, [rsp]
000077a70fddd6be  mov esi, 0x00
000077a70fddd6c3  mov rax, 0x6294188EF530
000077a70fddd6cd  call rax
000077a70fddd6cf  movaps xmm14, [rsp]
000077a70fddd6d4  add rsp, 0x30
000077a70fddd6d8  vmovaps xmm0, [rsp]
000077a70fddd6dd  vmovaps xmm1, [rsp+0x10]
000077a70fddd6e3  vmovaps xmm2, [rsp+0x20]
000077a70fddd6e9  vmovaps xmm3, [rsp+0x30]
000077a70fddd6ef  vmovaps xmm4, [rsp+0x40]
000077a70fddd6f5  vmovaps xmm5, [rsp+0x50]
000077a70fddd6fb  vmovaps xmm6, [rsp+0x60]
000077a70fddd701  vmovaps xmm7, [rsp+0x70]
000077a70fddd707  vmovaps xmm8, [rsp+0x80]
000077a70fddd710  vmovaps xmm9, [rsp+0x90]
000077a70fddd719  vmovaps xmm10, [rsp+0xA0]
000077a70fddd722  vmovaps xmm11, [rsp+0xB0]
000077a70fddd72b  vmovaps xmm12, [rsp+0xC0]
000077a70fddd734  vmovaps xmm13, [rsp+0xD0]
000077a70fddd73d  vmovaps xmm15, [rsp+0xE0]
000077a70fddd746  add rsp, 0xF0
000077a70fddd74d  pop r11
000077a70fddd74f  pop r10
000077a70fddd751  pop r9
000077a70fddd753  pop r8
000077a70fddd755  pop rsi
000077a70fddd756  pop rdi
000077a70fddd757  pop rdx
000077a70fddd758  pop rcx
000077a70fddd759  pop rax
000077a70fddd75a  add rsp, 0x08
000077a70fddd75e  jmp 0x000077A70FDDBE42
000077a70fddd763  sub rsp, 0x08
000077a70fddd767  push rax
000077a70fddd768  push rcx
000077a70fddd769  push rdx
000077a70fddd76a  push rdi
000077a70fddd76b  push rsi
000077a70fddd76c  push r8
000077a70fddd76e  push r9
000077a70fddd770  push r10
000077a70fddd772  push r11
000077a70fddd774  sub rsp, 0xF0
000077a70fddd77b  vmovaps [rsp], xmm0
000077a70fddd780  vmovaps [rsp+0x10], xmm1
000077a70fddd786  vmovaps [rsp+0x20], xmm2
000077a70fddd78c  vmovaps [rsp+0x30], xmm3
000077a70fddd792  vmovaps [rsp+0x40], xmm4
000077a70fddd798  vmovaps [rsp+0x50], xmm5
000077a70fddd79e  vmovaps [rsp+0x60], xmm7
000077a70fddd7a4  vmovaps [rsp+0x70], xmm8
000077a70fddd7aa  vmovaps [rsp+0x80], xmm9
000077a70fddd7b3  vmovaps [rsp+0x90], xmm10
000077a70fddd7bc  vmovaps [rsp+0xA0], xmm11
000077a70fddd7c5  vmovaps [rsp+0xB0], xmm12
000077a70fddd7ce  vmovaps [rsp+0xC0], xmm13
000077a70fddd7d7  vmovaps [rsp+0xD0], xmm14
000077a70fddd7e0  vmovaps [rsp+0xE0], xmm15
000077a70fddd7e9  sub rsp, 0x30
000077a70fddd7ed  movaps [rsp], xmm6
000077a70fddd7f1  movaps [rsp+0x10], xmm9
000077a70fddd7f7  movaps [rsp+0x20], xmm7
000077a70fddd7fc  lea rdi, [rsp]
000077a70fddd800  mov esi, 0x00
000077a70fddd805  mov rax, 0x6294188EF530
000077a70fddd80f  call rax
000077a70fddd811  movaps xmm6, [rsp]
000077a70fddd815  add rsp, 0x30
000077a70fddd819  vmovaps xmm0, [rsp]
000077a70fddd81e  vmovaps xmm1, [rsp+0x10]
000077a70fddd824  vmovaps xmm2, [rsp+0x20]
000077a70fddd82a  vmovaps xmm3, [rsp+0x30]
000077a70fddd830  vmovaps xmm4, [rsp+0x40]
000077a70fddd836  vmovaps xmm5, [rsp+0x50]
000077a70fddd83c  vmovaps xmm7, [rsp+0x60]
000077a70fddd842  vmovaps xmm8, [rsp+0x70]
000077a70fddd848  vmovaps xmm9, [rsp+0x80]
000077a70fddd851  vmovaps xmm10, [rsp+0x90]
000077a70fddd85a  vmovaps xmm11, [rsp+0xA0]
000077a70fddd863  vmovaps xmm12, [rsp+0xB0]
000077a70fddd86c  vmovaps xmm13, [rsp+0xC0]
000077a70fddd875  vmovaps xmm14, [rsp+0xD0]
000077a70fddd87e  vmovaps xmm15, [rsp+0xE0]
000077a70fddd887  add rsp, 0xF0
000077a70fddd88e  pop r11
000077a70fddd890  pop r10
000077a70fddd892  pop r9
000077a70fddd894  pop r8
000077a70fddd896  pop rsi
000077a70fddd897  pop rdi
000077a70fddd898  pop rdx
000077a70fddd899  pop rcx
000077a70fddd89a  pop rax
000077a70fddd89b  add rsp, 0x08
000077a70fddd89f  jmp 0x000077A70FDDBE5A
000077a70fddd8a4  sub rsp, 0x08
000077a70fddd8a8  push rax
000077a70fddd8a9  push rcx
000077a70fddd8aa  push rdx
000077a70fddd8ab  push rdi
000077a70fddd8ac  push rsi
000077a70fddd8ad  push r8
000077a70fddd8af  push r9
000077a70fddd8b1  push r10
000077a70fddd8b3  push r11
000077a70fddd8b5  sub rsp, 0xF0
000077a70fddd8bc  vmovaps [rsp], xmm0
000077a70fddd8c1  vmovaps [rsp+0x10], xmm1
000077a70fddd8c7  vmovaps [rsp+0x20], xmm2
000077a70fddd8cd  vmovaps [rsp+0x30], xmm3
000077a70fddd8d3  vmovaps [rsp+0x40], xmm4
000077a70fddd8d9  vmovaps [rsp+0x50], xmm5
000077a70fddd8df  vmovaps [rsp+0x60], xmm6
000077a70fddd8e5  vmovaps [rsp+0x70], xmm8
000077a70fddd8eb  vmovaps [rsp+0x80], xmm9
000077a70fddd8f4  vmovaps [rsp+0x90], xmm10
000077a70fddd8fd  vmovaps [rsp+0xA0], xmm11
000077a70fddd906  vmovaps [rsp+0xB0], xmm12
000077a70fddd90f  vmovaps [rsp+0xC0], xmm13
000077a70fddd918  vmovaps [rsp+0xD0], xmm14
000077a70fddd921  vmovaps [rsp+0xE0], xmm15
000077a70fddd92a  sub rsp, 0x30
000077a70fddd92e  movaps [rsp], xmm7
000077a70fddd932  movaps [rsp+0x10], xmm4
000077a70fddd937  movaps [rsp+0x20], xmm9
000077a70fddd93d  lea rdi, [rsp]
000077a70fddd941  mov esi, 0x00
000077a70fddd946  mov rax, 0x6294188EF530
000077a70fddd950  call rax
000077a70fddd952  movaps xmm7, [rsp]
000077a70fddd956  add rsp, 0x30
000077a70fddd95a  vmovaps xmm0, [rsp]
000077a70fddd95f  vmovaps xmm1, [rsp+0x10]
000077a70fddd965  vmovaps xmm2, [rsp+0x20]
000077a70fddd96b  vmovaps xmm3, [rsp+0x30]
000077a70fddd971  vmovaps xmm4, [rsp+0x40]
000077a70fddd977  vmovaps xmm5, [rsp+0x50]
000077a70fddd97d  vmovaps xmm6, [rsp+0x60]
000077a70fddd983  vmovaps xmm8, [rsp+0x70]
000077a70fddd989  vmovaps xmm9, [rsp+0x80]
000077a70fddd992  vmovaps xmm10, [rsp+0x90]
000077a70fddd99b  vmovaps xmm11, [rsp+0xA0]
000077a70fddd9a4  vmovaps xmm12, [rsp+0xB0]
000077a70fddd9ad  vmovaps xmm13, [rsp+0xC0]
000077a70fddd9b6  vmovaps xmm14, [rsp+0xD0]
000077a70fddd9bf  vmovaps xmm15, [rsp+0xE0]
000077a70fddd9c8  add rsp, 0xF0
000077a70fddd9cf  pop r11
000077a70fddd9d1  pop r10
000077a70fddd9d3  pop r9
000077a70fddd9d5  pop r8
000077a70fddd9d7  pop rsi
000077a70fddd9d8  pop rdi
000077a70fddd9d9  pop rdx
000077a70fddd9da  pop rcx
000077a70fddd9db  pop rax
000077a70fddd9dc  add rsp, 0x08
000077a70fddd9e0  jmp 0x000077A70FDDBE87
000077a70fddd9e5  sub rsp, 0x08
000077a70fddd9e9  push rax
000077a70fddd9ea  push rcx
000077a70fddd9eb  push rdx
000077a70fddd9ec  push rdi
000077a70fddd9ed  push rsi
000077a70fddd9ee  push r8
000077a70fddd9f0  push r9
000077a70fddd9f2  push r10
000077a70fddd9f4  push r11
000077a70fddd9f6  sub rsp, 0xF0
000077a70fddd9fd  vmovaps [rsp], xmm0
000077a70fddda02  vmovaps [rsp+0x10], xmm1
000077a70fddda08  vmovaps [rsp+0x20], xmm2
000077a70fddda0e  vmovaps [rsp+0x30], xmm3
000077a70fddda14  vmovaps [rsp+0x40], xmm5
000077a70fddda1a  vmovaps [rsp+0x50], xmm6
000077a70fddda20  vmovaps [rsp+0x60], xmm7
000077a70fddda26  vmovaps [rsp+0x70], xmm8
000077a70fddda2c  vmovaps [rsp+0x80], xmm9
000077a70fddda35  vmovaps [rsp+0x90], xmm10
000077a70fddda3e  vmovaps [rsp+0xA0], xmm11
000077a70fddda47  vmovaps [rsp+0xB0], xmm12
000077a70fddda50  vmovaps [rsp+0xC0], xmm13
000077a70fddda59  vmovaps [rsp+0xD0], xmm14
000077a70fddda62  vmovaps [rsp+0xE0], xmm15
000077a70fddda6b  sub rsp, 0x30
000077a70fddda6f  movaps [rsp], xmm4
000077a70fddda73  movaps [rsp+0x10], xmm15
000077a70fddda79  movaps [rsp+0x20], xmm9
000077a70fddda7f  lea rdi, [rsp]
000077a70fddda83  mov esi, 0x00
000077a70fddda88  mov rax, 0x6294188EF530
000077a70fddda92  call rax
000077a70fddda94  movaps xmm4, [rsp]
000077a70fddda98  add rsp, 0x30
000077a70fddda9c  vmovaps xmm0, [rsp]
000077a70fdddaa1  vmovaps xmm1, [rsp+0x10]
000077a70fdddaa7  vmovaps xmm2, [rsp+0x20]
000077a70fdddaad  vmovaps xmm3, [rsp+0x30]
000077a70fdddab3  vmovaps xmm5, [rsp+0x40]
000077a70fdddab9  vmovaps xmm6, [rsp+0x50]
000077a70fdddabf  vmovaps xmm7, [rsp+0x60]
000077a70fdddac5  vmovaps xmm8, [rsp+0x70]
000077a70fdddacb  vmovaps xmm9, [rsp+0x80]
000077a70fdddad4  vmovaps xmm10, [rsp+0x90]
000077a70fdddadd  vmovaps xmm11, [rsp+0xA0]
000077a70fdddae6  vmovaps xmm12, [rsp+0xB0]
000077a70fdddaef  vmovaps xmm13, [rsp+0xC0]
000077a70fdddaf8  vmovaps xmm14, [rsp+0xD0]
000077a70fdddb01  vmovaps xmm15, [rsp+0xE0]
000077a70fdddb0a  add rsp, 0xF0
000077a70fdddb11  pop r11
000077a70fdddb13  pop r10
000077a70fdddb15  pop r9
000077a70fdddb17  pop r8
000077a70fdddb19  pop rsi
000077a70fdddb1a  pop rdi
000077a70fdddb1b  pop rdx
000077a70fdddb1c  pop rcx
000077a70fdddb1d  pop rax
000077a70fdddb1e  add rsp, 0x08
000077a70fdddb22  jmp 0x000077A70FDDBEAC
000077a70fdddb27  call 0x000077A70FCC4620
000077a70fdddb2c  jmp 0x000077A70FDDBEB9
000077a70fdddb31  sub rsp, 0x08
000077a70fdddb35  push rax
000077a70fdddb36  push rcx
000077a70fdddb37  push rdx
000077a70fdddb38  push rdi
000077a70fdddb39  push rsi
000077a70fdddb3a  push r8
000077a70fdddb3c  push r9
000077a70fdddb3e  push r10
000077a70fdddb40  push r11
000077a70fdddb42  sub rsp, 0xF0
000077a70fdddb49  vmovaps [rsp], xmm0
000077a70fdddb4e  vmovaps [rsp+0x10], xmm1
000077a70fdddb54  vmovaps [rsp+0x20], xmm2
000077a70fdddb5a  vmovaps [rsp+0x30], xmm4
000077a70fdddb60  vmovaps [rsp+0x40], xmm5
000077a70fdddb66  vmovaps [rsp+0x50], xmm6
000077a70fdddb6c  vmovaps [rsp+0x60], xmm7
000077a70fdddb72  vmovaps [rsp+0x70], xmm8
000077a70fdddb78  vmovaps [rsp+0x80], xmm9
000077a70fdddb81  vmovaps [rsp+0x90], xmm10
000077a70fdddb8a  vmovaps [rsp+0xA0], xmm11
000077a70fdddb93  vmovaps [rsp+0xB0], xmm12
000077a70fdddb9c  vmovaps [rsp+0xC0], xmm13
000077a70fdddba5  vmovaps [rsp+0xD0], xmm14
000077a70fdddbae  vmovaps [rsp+0xE0], xmm15
000077a70fdddbb7  sub rsp, 0x30
000077a70fdddbbb  movaps [rsp], xmm3
000077a70fdddbbf  movaps [rsp+0x10], xmm1
000077a70fdddbc4  movaps [rsp+0x20], xmm9
000077a70fdddbca  lea rdi, [rsp]
000077a70fdddbce  mov esi, 0x00
000077a70fdddbd3  mov rax, 0x6294188EF530
000077a70fdddbdd  call rax
000077a70fdddbdf  movaps xmm3, [rsp]
000077a70fdddbe3  add rsp, 0x30
000077a70fdddbe7  vmovaps xmm0, [rsp]
000077a70fdddbec  vmovaps xmm1, [rsp+0x10]
000077a70fdddbf2  vmovaps xmm2, [rsp+0x20]
000077a70fdddbf8  vmovaps xmm4, [rsp+0x30]
000077a70fdddbfe  vmovaps xmm5, [rsp+0x40]
000077a70fdddc04  vmovaps xmm6, [rsp+0x50]
000077a70fdddc0a  vmovaps xmm7, [rsp+0x60]
000077a70fdddc10  vmovaps xmm8, [rsp+0x70]
000077a70fdddc16  vmovaps xmm9, [rsp+0x80]
000077a70fdddc1f  vmovaps xmm10, [rsp+0x90]
000077a70fdddc28  vmovaps xmm11, [rsp+0xA0]
000077a70fdddc31  vmovaps xmm12, [rsp+0xB0]
000077a70fdddc3a  vmovaps xmm13, [rsp+0xC0]
000077a70fdddc43  vmovaps xmm14, [rsp+0xD0]
000077a70fdddc4c  vmovaps xmm15, [rsp+0xE0]
000077a70fdddc55  add rsp, 0xF0
000077a70fdddc5c  pop r11
000077a70fdddc5e  pop r10
000077a70fdddc60  pop r9
000077a70fdddc62  pop r8
000077a70fdddc64  pop rsi
000077a70fdddc65  pop rdi
000077a70fdddc66  pop rdx
000077a70fdddc67  pop rcx
000077a70fdddc68  pop rax
000077a70fdddc69  add rsp, 0x08
000077a70fdddc6d  jmp 0x000077A70FDDBEF6
000077a70fdddc72  sub rsp, 0x08
000077a70fdddc76  push rax
000077a70fdddc77  push rcx
000077a70fdddc78  push rdx
000077a70fdddc79  push rdi
000077a70fdddc7a  push rsi
000077a70fdddc7b  push r8
000077a70fdddc7d  push r9
000077a70fdddc7f  push r10
000077a70fdddc81  push r11
000077a70fdddc83  sub rsp, 0xF0
000077a70fdddc8a  vmovaps [rsp], xmm0
000077a70fdddc8f  vmovaps [rsp+0x10], xmm2
000077a70fdddc95  vmovaps [rsp+0x20], xmm3
000077a70fdddc9b  vmovaps [rsp+0x30], xmm4
000077a70fdddca1  vmovaps [rsp+0x40], xmm5
000077a70fdddca7  vmovaps [rsp+0x50], xmm6
000077a70fdddcad  vmovaps [rsp+0x60], xmm7
000077a70fdddcb3  vmovaps [rsp+0x70], xmm8
000077a70fdddcb9  vmovaps [rsp+0x80], xmm9
000077a70fdddcc2  vmovaps [rsp+0x90], xmm10
000077a70fdddccb  vmovaps [rsp+0xA0], xmm11
000077a70fdddcd4  vmovaps [rsp+0xB0], xmm12
000077a70fdddcdd  vmovaps [rsp+0xC0], xmm13
000077a70fdddce6  vmovaps [rsp+0xD0], xmm14
000077a70fdddcef  vmovaps [rsp+0xE0], xmm15
000077a70fdddcf8  sub rsp, 0x30
000077a70fdddcfc  movaps [rsp], xmm1
000077a70fdddd00  movaps [rsp+0x10], xmm15
000077a70fdddd06  movaps [rsp+0x20], xmm9
000077a70fdddd0c  lea rdi, [rsp]
000077a70fdddd10  mov esi, 0x00
000077a70fdddd15  mov rax, 0x6294188EF530
000077a70fdddd1f  call rax
000077a70fdddd21  movaps xmm1, [rsp]
000077a70fdddd25  add rsp, 0x30
000077a70fdddd29  vmovaps xmm0, [rsp]
000077a70fdddd2e  vmovaps xmm2, [rsp+0x10]
000077a70fdddd34  vmovaps xmm3, [rsp+0x20]
000077a70fdddd3a  vmovaps xmm4, [rsp+0x30]
000077a70fdddd40  vmovaps xmm5, [rsp+0x40]
000077a70fdddd46  vmovaps xmm6, [rsp+0x50]
000077a70fdddd4c  vmovaps xmm7, [rsp+0x60]
000077a70fdddd52  vmovaps xmm8, [rsp+0x70]
000077a70fdddd58  vmovaps xmm9, [rsp+0x80]
000077a70fdddd61  vmovaps xmm10, [rsp+0x90]
000077a70fdddd6a  vmovaps xmm11, [rsp+0xA0]
000077a70fdddd73  vmovaps xmm12, [rsp+0xB0]
000077a70fdddd7c  vmovaps xmm13, [rsp+0xC0]
000077a70fdddd85  vmovaps xmm14, [rsp+0xD0]
000077a70fdddd8e  vmovaps xmm15, [rsp+0xE0]
000077a70fdddd97  add rsp, 0xF0
000077a70fdddd9e  pop r11
000077a70fdddda0  pop r10
000077a70fdddda2  pop r9
000077a70fdddda4  pop r8
000077a70fdddda6  pop rsi
000077a70fdddda7  pop rdi
000077a70fdddda8  pop rdx
000077a70fdddda9  pop rcx
000077a70fddddaa  pop rax
000077a70fddddab  add rsp, 0x08
000077a70fddddaf  jmp 0x000077A70FDDBF7E
000077a70fddddb4  call 0x000077A70FCC4620
000077a70fddddb9  jmp 0x000077A70FDDBF8B
000077a70fddddbe  sub rsp, 0x08
000077a70fddddc2  push rax
000077a70fddddc3  push rcx
000077a70fddddc4  push rdx
000077a70fddddc5  push rdi
000077a70fddddc6  push rsi
000077a70fddddc7  push r8
000077a70fddddc9  push r9
000077a70fddddcb  push r10
000077a70fddddcd  push r11
000077a70fddddcf  sub rsp, 0xF0
000077a70fddddd6  vmovaps [rsp], xmm0
000077a70fdddddb  vmovaps [rsp+0x10], xmm2
000077a70fdddde1  vmovaps [rsp+0x20], xmm3
000077a70fdddde7  vmovaps [rsp+0x30], xmm4
000077a70fdddded  vmovaps [rsp+0x40], xmm5
000077a70fddddf3  vmovaps [rsp+0x50], xmm6
000077a70fddddf9  vmovaps [rsp+0x60], xmm7
000077a70fddddff  vmovaps [rsp+0x70], xmm8
000077a70fddde05  vmovaps [rsp+0x80], xmm9
000077a70fddde0e  vmovaps [rsp+0x90], xmm10
000077a70fddde17  vmovaps [rsp+0xA0], xmm11
000077a70fddde20  vmovaps [rsp+0xB0], xmm12
000077a70fddde29  vmovaps [rsp+0xC0], xmm13
000077a70fddde32  vmovaps [rsp+0xD0], xmm14
000077a70fddde3b  vmovaps [rsp+0xE0], xmm15
000077a70fddde44  sub rsp, 0x30
000077a70fddde48  movaps [rsp], xmm1
000077a70fddde4c  movaps [rsp+0x10], xmm5
000077a70fddde51  movaps [rsp+0x20], xmm7
000077a70fddde56  lea rdi, [rsp]
000077a70fddde5a  mov esi, 0x00
000077a70fddde5f  mov rax, 0x6294188EF530
000077a70fddde69  call rax
000077a70fddde6b  movaps xmm1, [rsp]
000077a70fddde6f  add rsp, 0x30
000077a70fddde73  vmovaps xmm0, [rsp]
000077a70fddde78  vmovaps xmm2, [rsp+0x10]
000077a70fddde7e  vmovaps xmm3, [rsp+0x20]
000077a70fddde84  vmovaps xmm4, [rsp+0x30]
000077a70fddde8a  vmovaps xmm5, [rsp+0x40]
000077a70fddde90  vmovaps xmm6, [rsp+0x50]
000077a70fddde96  vmovaps xmm7, [rsp+0x60]
000077a70fddde9c  vmovaps xmm8, [rsp+0x70]
000077a70fdddea2  vmovaps xmm9, [rsp+0x80]
000077a70fdddeab  vmovaps xmm10, [rsp+0x90]
000077a70fdddeb4  vmovaps xmm11, [rsp+0xA0]
000077a70fdddebd  vmovaps xmm12, [rsp+0xB0]
000077a70fdddec6  vmovaps xmm13, [rsp+0xC0]
000077a70fdddecf  vmovaps xmm14, [rsp+0xD0]
000077a70fddded8  vmovaps xmm15, [rsp+0xE0]
000077a70fdddee1  add rsp, 0xF0
000077a70fdddee8  pop r11
000077a70fdddeea  pop r10
000077a70fdddeec  pop r9
000077a70fdddeee  pop r8
000077a70fdddef0  pop rsi
000077a70fdddef1  pop rdi
000077a70fdddef2  pop rdx
000077a70fdddef3  pop rcx
000077a70fdddef4  pop rax
000077a70fdddef5  add rsp, 0x08
000077a70fdddef9  jmp 0x000077A70FDDC030
000077a70fdddefe  sub rsp, 0x08
000077a70fdddf02  push rax
000077a70fdddf03  push rcx
000077a70fdddf04  push rdx
000077a70fdddf05  push rdi
000077a70fdddf06  push rsi
000077a70fdddf07  push r8
000077a70fdddf09  push r9
000077a70fdddf0b  push r10
000077a70fdddf0d  push r11
000077a70fdddf0f  sub rsp, 0xF0
000077a70fdddf16  vmovaps [rsp], xmm0
000077a70fdddf1b  vmovaps [rsp+0x10], xmm1
000077a70fdddf21  vmovaps [rsp+0x20], xmm2
000077a70fdddf27  vmovaps [rsp+0x30], xmm3
000077a70fdddf2d  vmovaps [rsp+0x40], xmm4
000077a70fdddf33  vmovaps [rsp+0x50], xmm5
000077a70fdddf39  vmovaps [rsp+0x60], xmm6
000077a70fdddf3f  vmovaps [rsp+0x70], xmm8
000077a70fdddf45  vmovaps [rsp+0x80], xmm9
000077a70fdddf4e  vmovaps [rsp+0x90], xmm10
000077a70fdddf57  vmovaps [rsp+0xA0], xmm11
000077a70fdddf60  vmovaps [rsp+0xB0], xmm12
000077a70fdddf69  vmovaps [rsp+0xC0], xmm13
000077a70fdddf72  vmovaps [rsp+0xD0], xmm14
000077a70fdddf7b  vmovaps [rsp+0xE0], xmm15
000077a70fdddf84  sub rsp, 0x30
000077a70fdddf88  movaps [rsp], xmm7
000077a70fdddf8c  movaps [rsp+0x10], xmm5
000077a70fdddf91  movaps [rsp+0x20], xmm15
000077a70fdddf97  lea rdi, [rsp]
000077a70fdddf9b  mov esi, 0x00
000077a70fdddfa0  mov rax, 0x6294188EF530
000077a70fdddfaa  call rax
000077a70fdddfac  movaps xmm7, [rsp]
000077a70fdddfb0  add rsp, 0x30
000077a70fdddfb4  vmovaps xmm0, [rsp]
000077a70fdddfb9  vmovaps xmm1, [rsp+0x10]
000077a70fdddfbf  vmovaps xmm2, [rsp+0x20]
000077a70fdddfc5  vmovaps xmm3, [rsp+0x30]
000077a70fdddfcb  vmovaps xmm4, [rsp+0x40]
000077a70fdddfd1  vmovaps xmm5, [rsp+0x50]
000077a70fdddfd7  vmovaps xmm6, [rsp+0x60]
000077a70fdddfdd  vmovaps xmm8, [rsp+0x70]
000077a70fdddfe3  vmovaps xmm9, [rsp+0x80]
000077a70fdddfec  vmovaps xmm10, [rsp+0x90]
000077a70fdddff5  vmovaps xmm11, [rsp+0xA0]
000077a70fdddffe  vmovaps xmm12, [rsp+0xB0]
000077a70fdde007  vmovaps xmm13, [rsp+0xC0]
000077a70fdde010  vmovaps xmm14, [rsp+0xD0]
000077a70fdde019  vmovaps xmm15, [rsp+0xE0]
000077a70fdde022  add rsp, 0xF0
000077a70fdde029  pop r11
000077a70fdde02b  pop r10
000077a70fdde02d  pop r9
000077a70fdde02f  pop r8
000077a70fdde031  pop rsi
000077a70fdde032  pop rdi
000077a70fdde033  pop rdx
000077a70fdde034  pop rcx
000077a70fdde035  pop rax
000077a70fdde036  add rsp, 0x08
000077a70fdde03a  jmp 0x000077A70FDDC066
000077a70fdde03f  call 0x000077A70FCB52F0
000077a70fdde044  jmp 0x000077A70FDDC073
000077a70fdde049  sub rsp, 0x08
000077a70fdde04d  push rax
000077a70fdde04e  push rcx
000077a70fdde04f  push rdx
000077a70fdde050  push rdi
000077a70fdde051  push rsi
000077a70fdde052  push r8
000077a70fdde054  push r9
000077a70fdde056  push r10
000077a70fdde058  push r11
000077a70fdde05a  sub rsp, 0xF0
000077a70fdde061  vmovaps [rsp], xmm0
000077a70fdde066  vmovaps [rsp+0x10], xmm1
000077a70fdde06c  vmovaps [rsp+0x20], xmm2
000077a70fdde072  vmovaps [rsp+0x30], xmm3
000077a70fdde078  vmovaps [rsp+0x40], xmm4
000077a70fdde07e  vmovaps [rsp+0x50], xmm5
000077a70fdde084  vmovaps [rsp+0x60], xmm6
000077a70fdde08a  vmovaps [rsp+0x70], xmm7
000077a70fdde090  vmovaps [rsp+0x80], xmm8
000077a70fdde099  vmovaps [rsp+0x90], xmm9
000077a70fdde0a2  vmovaps [rsp+0xA0], xmm10
000077a70fdde0ab  vmovaps [rsp+0xB0], xmm11
000077a70fdde0b4  vmovaps [rsp+0xC0], xmm12
000077a70fdde0bd  vmovaps [rsp+0xD0], xmm13
000077a70fdde0c6  vmovaps [rsp+0xE0], xmm14
000077a70fdde0cf  sub rsp, 0x30
000077a70fdde0d3  movaps [rsp], xmm15
000077a70fdde0d8  movaps [rsp+0x10], xmm5
000077a70fdde0dd  movaps [rsp+0x20], xmm3
000077a70fdde0e2  lea rdi, [rsp]
000077a70fdde0e6  mov esi, 0x00
000077a70fdde0eb  mov rax, 0x6294188EF530
000077a70fdde0f5  call rax
000077a70fdde0f7  movaps xmm15, [rsp]
000077a70fdde0fc  add rsp, 0x30
000077a70fdde100  vmovaps xmm0, [rsp]
000077a70fdde105  vmovaps xmm1, [rsp+0x10]
000077a70fdde10b  vmovaps xmm2, [rsp+0x20]
000077a70fdde111  vmovaps xmm3, [rsp+0x30]
000077a70fdde117  vmovaps xmm4, [rsp+0x40]
000077a70fdde11d  vmovaps xmm5, [rsp+0x50]
000077a70fdde123  vmovaps xmm6, [rsp+0x60]
000077a70fdde129  vmovaps xmm7, [rsp+0x70]
000077a70fdde12f  vmovaps xmm8, [rsp+0x80]
000077a70fdde138  vmovaps xmm9, [rsp+0x90]
000077a70fdde141  vmovaps xmm10, [rsp+0xA0]
000077a70fdde14a  vmovaps xmm11, [rsp+0xB0]
000077a70fdde153  vmovaps xmm12, [rsp+0xC0]
000077a70fdde15c  vmovaps xmm13, [rsp+0xD0]
000077a70fdde165  vmovaps xmm14, [rsp+0xE0]
000077a70fdde16e  add rsp, 0xF0
000077a70fdde175  pop r11
000077a70fdde177  pop r10
000077a70fdde179  pop r9
000077a70fdde17b  pop r8
000077a70fdde17d  pop rsi
000077a70fdde17e  pop rdi
000077a70fdde17f  pop rdx
000077a70fdde180  pop rcx
000077a70fdde181  pop rax
000077a70fdde182  add rsp, 0x08
000077a70fdde186  jmp 0x000077A70FDDC099
000077a70fdde18b  sub rsp, 0x08
000077a70fdde18f  push rax
000077a70fdde190  push rcx
000077a70fdde191  push rdx
000077a70fdde192  push rdi
000077a70fdde193  push rsi
000077a70fdde194  push r8
000077a70fdde196  push r9
000077a70fdde198  push r10
000077a70fdde19a  push r11
000077a70fdde19c  sub rsp, 0xF0
000077a70fdde1a3  vmovaps [rsp], xmm0
000077a70fdde1a8  vmovaps [rsp+0x10], xmm2
000077a70fdde1ae  vmovaps [rsp+0x20], xmm3
000077a70fdde1b4  vmovaps [rsp+0x30], xmm4
000077a70fdde1ba  vmovaps [rsp+0x40], xmm5
000077a70fdde1c0  vmovaps [rsp+0x50], xmm6
000077a70fdde1c6  vmovaps [rsp+0x60], xmm7
000077a70fdde1cc  vmovaps [rsp+0x70], xmm8
000077a70fdde1d2  vmovaps [rsp+0x80], xmm9
000077a70fdde1db  vmovaps [rsp+0x90], xmm10
000077a70fdde1e4  vmovaps [rsp+0xA0], xmm11
000077a70fdde1ed  vmovaps [rsp+0xB0], xmm12
000077a70fdde1f6  vmovaps [rsp+0xC0], xmm13
000077a70fdde1ff  vmovaps [rsp+0xD0], xmm14
000077a70fdde208  vmovaps [rsp+0xE0], xmm15
000077a70fdde211  sub rsp, 0x30
000077a70fdde215  movaps [rsp], xmm1
000077a70fdde219  movaps [rsp+0x10], xmm5
000077a70fdde21e  movaps [rsp+0x20], xmm4
000077a70fdde223  lea rdi, [rsp]
000077a70fdde227  mov esi, 0x00
000077a70fdde22c  mov rax, 0x6294188EF530
000077a70fdde236  call rax
000077a70fdde238  movaps xmm1, [rsp]
000077a70fdde23c  add rsp, 0x30
000077a70fdde240  vmovaps xmm0, [rsp]
000077a70fdde245  vmovaps xmm2, [rsp+0x10]
000077a70fdde24b  vmovaps xmm3, [rsp+0x20]
000077a70fdde251  vmovaps xmm4, [rsp+0x30]
000077a70fdde257  vmovaps xmm5, [rsp+0x40]
000077a70fdde25d  vmovaps xmm6, [rsp+0x50]
000077a70fdde263  vmovaps xmm7, [rsp+0x60]
000077a70fdde269  vmovaps xmm8, [rsp+0x70]
000077a70fdde26f  vmovaps xmm9, [rsp+0x80]
000077a70fdde278  vmovaps xmm10, [rsp+0x90]
000077a70fdde281  vmovaps xmm11, [rsp+0xA0]
000077a70fdde28a  vmovaps xmm12, [rsp+0xB0]
000077a70fdde293  vmovaps xmm13, [rsp+0xC0]
000077a70fdde29c  vmovaps xmm14, [rsp+0xD0]
000077a70fdde2a5  vmovaps xmm15, [rsp+0xE0]
000077a70fdde2ae  add rsp, 0xF0
000077a70fdde2b5  pop r11
000077a70fdde2b7  pop r10
000077a70fdde2b9  pop r9
000077a70fdde2bb  pop r8
000077a70fdde2bd  pop rsi
000077a70fdde2be  pop rdi
000077a70fdde2bf  pop rdx
000077a70fdde2c0  pop rcx
000077a70fdde2c1  pop rax
000077a70fdde2c2  add rsp, 0x08
000077a70fdde2c6  jmp 0x000077A70FDDC0B9
000077a70fdde2cb  sub rsp, 0x08
000077a70fdde2cf  push rax
000077a70fdde2d0  push rcx
000077a70fdde2d1  push rdx
000077a70fdde2d2  push rdi
000077a70fdde2d3  push rsi
000077a70fdde2d4  push r8
000077a70fdde2d6  push r9
000077a70fdde2d8  push r10
000077a70fdde2da  push r11
000077a70fdde2dc  sub rsp, 0xF0
000077a70fdde2e3  vmovaps [rsp], xmm0
000077a70fdde2e8  vmovaps [rsp+0x10], xmm1
000077a70fdde2ee  vmovaps [rsp+0x20], xmm2
000077a70fdde2f4  vmovaps [rsp+0x30], xmm3
000077a70fdde2fa  vmovaps [rsp+0x40], xmm5
000077a70fdde300  vmovaps [rsp+0x50], xmm6
000077a70fdde306  vmovaps [rsp+0x60], xmm7
000077a70fdde30c  vmovaps [rsp+0x70], xmm8
000077a70fdde312  vmovaps [rsp+0x80], xmm9
000077a70fdde31b  vmovaps [rsp+0x90], xmm10
000077a70fdde324  vmovaps [rsp+0xA0], xmm11
000077a70fdde32d  vmovaps [rsp+0xB0], xmm12
000077a70fdde336  vmovaps [rsp+0xC0], xmm13
000077a70fdde33f  vmovaps [rsp+0xD0], xmm14
000077a70fdde348  vmovaps [rsp+0xE0], xmm15
000077a70fdde351  sub rsp, 0x30
000077a70fdde355  movaps [rsp], xmm4
000077a70fdde359  movaps [rsp+0x10], xmm3
000077a70fdde35e  movaps [rsp+0x20], xmm5
000077a70fdde363  lea rdi, [rsp]
000077a70fdde367  mov esi, 0x00
000077a70fdde36c  mov rax, 0x6294188EF530
000077a70fdde376  call rax
000077a70fdde378  movaps xmm4, [rsp]
000077a70fdde37c  add rsp, 0x30
000077a70fdde380  vmovaps xmm0, [rsp]
000077a70fdde385  vmovaps xmm1, [rsp+0x10]
000077a70fdde38b  vmovaps xmm2, [rsp+0x20]
000077a70fdde391  vmovaps xmm3, [rsp+0x30]
000077a70fdde397  vmovaps xmm5, [rsp+0x40]
000077a70fdde39d  vmovaps xmm6, [rsp+0x50]
000077a70fdde3a3  vmovaps xmm7, [rsp+0x60]
000077a70fdde3a9  vmovaps xmm8, [rsp+0x70]
000077a70fdde3af  vmovaps xmm9, [rsp+0x80]
000077a70fdde3b8  vmovaps xmm10, [rsp+0x90]
000077a70fdde3c1  vmovaps xmm11, [rsp+0xA0]
000077a70fdde3ca  vmovaps xmm12, [rsp+0xB0]
000077a70fdde3d3  vmovaps xmm13, [rsp+0xC0]
000077a70fdde3dc  vmovaps xmm14, [rsp+0xD0]
000077a70fdde3e5  vmovaps xmm15, [rsp+0xE0]
000077a70fdde3ee  add rsp, 0xF0
000077a70fdde3f5  pop r11
000077a70fdde3f7  pop r10
000077a70fdde3f9  pop r9
000077a70fdde3fb  pop r8
000077a70fdde3fd  pop rsi
000077a70fdde3fe  pop rdi
000077a70fdde3ff  pop rdx
000077a70fdde400  pop rcx
000077a70fdde401  pop rax
000077a70fdde402  add rsp, 0x08
000077a70fdde406  jmp 0x000077A70FDDC107
000077a70fdde40b  call 0x000077A70FCB52F0
000077a70fdde410  jmp 0x000077A70FDDC114
000077a70fdde415  sub rsp, 0x08
000077a70fdde419  push rax
000077a70fdde41a  push rcx
000077a70fdde41b  push rdx
000077a70fdde41c  push rdi
000077a70fdde41d  push rsi
000077a70fdde41e  push r8
000077a70fdde420  push r9
000077a70fdde422  push r10
000077a70fdde424  push r11
000077a70fdde426  sub rsp, 0xF0
000077a70fdde42d  vmovaps [rsp], xmm0
000077a70fdde432  vmovaps [rsp+0x10], xmm1
000077a70fdde438  vmovaps [rsp+0x20], xmm2
000077a70fdde43e  vmovaps [rsp+0x30], xmm3
000077a70fdde444  vmovaps [rsp+0x40], xmm4
000077a70fdde44a  vmovaps [rsp+0x50], xmm6
000077a70fdde450  vmovaps [rsp+0x60], xmm7
000077a70fdde456  vmovaps [rsp+0x70], xmm8
000077a70fdde45c  vmovaps [rsp+0x80], xmm9
000077a70fdde465  vmovaps [rsp+0x90], xmm10
000077a70fdde46e  vmovaps [rsp+0xA0], xmm11
000077a70fdde477  vmovaps [rsp+0xB0], xmm12
000077a70fdde480  vmovaps [rsp+0xC0], xmm13
000077a70fdde489  vmovaps [rsp+0xD0], xmm14
000077a70fdde492  vmovaps [rsp+0xE0], xmm15
000077a70fdde49b  sub rsp, 0x30
000077a70fdde49f  movaps [rsp], xmm5
000077a70fdde4a3  movaps [rsp+0x10], xmm6
000077a70fdde4a8  movaps [rsp+0x20], xmm3
000077a70fdde4ad  lea rdi, [rsp]
000077a70fdde4b1  mov esi, 0x00
000077a70fdde4b6  mov rax, 0x6294188EF530
000077a70fdde4c0  call rax
000077a70fdde4c2  movaps xmm5, [rsp]
000077a70fdde4c6  add rsp, 0x30
000077a70fdde4ca  vmovaps xmm0, [rsp]
000077a70fdde4cf  vmovaps xmm1, [rsp+0x10]
000077a70fdde4d5  vmovaps xmm2, [rsp+0x20]
000077a70fdde4db  vmovaps xmm3, [rsp+0x30]
000077a70fdde4e1  vmovaps xmm4, [rsp+0x40]
000077a70fdde4e7  vmovaps xmm6, [rsp+0x50]
000077a70fdde4ed  vmovaps xmm7, [rsp+0x60]
000077a70fdde4f3  vmovaps xmm8, [rsp+0x70]
000077a70fdde4f9  vmovaps xmm9, [rsp+0x80]
000077a70fdde502  vmovaps xmm10, [rsp+0x90]
000077a70fdde50b  vmovaps xmm11, [rsp+0xA0]
000077a70fdde514  vmovaps xmm12, [rsp+0xB0]
000077a70fdde51d  vmovaps xmm13, [rsp+0xC0]
000077a70fdde526  vmovaps xmm14, [rsp+0xD0]
000077a70fdde52f  vmovaps xmm15, [rsp+0xE0]
000077a70fdde538  add rsp, 0xF0
000077a70fdde53f  pop r11
000077a70fdde541  pop r10
000077a70fdde543  pop r9
000077a70fdde545  pop r8
000077a70fdde547  pop rsi
000077a70fdde548  pop rdi
000077a70fdde549  pop rdx
000077a70fdde54a  pop rcx
000077a70fdde54b  pop rax
000077a70fdde54c  add rsp, 0x08
000077a70fdde550  jmp 0x000077A70FDDC13A
000077a70fdde555  sub rsp, 0x08
000077a70fdde559  push rax
000077a70fdde55a  push rcx
000077a70fdde55b  push rdx
000077a70fdde55c  push rdi
000077a70fdde55d  push rsi
000077a70fdde55e  push r8
000077a70fdde560  push r9
000077a70fdde562  push r10
000077a70fdde564  push r11
000077a70fdde566  sub rsp, 0xF0
000077a70fdde56d  vmovaps [rsp], xmm0
000077a70fdde572  vmovaps [rsp+0x10], xmm1
000077a70fdde578  vmovaps [rsp+0x20], xmm2
000077a70fdde57e  vmovaps [rsp+0x30], xmm3
000077a70fdde584  vmovaps [rsp+0x40], xmm4
000077a70fdde58a  vmovaps [rsp+0x50], xmm5
000077a70fdde590  vmovaps [rsp+0x60], xmm7
000077a70fdde596  vmovaps [rsp+0x70], xmm8
000077a70fdde59c  vmovaps [rsp+0x80], xmm9
000077a70fdde5a5  vmovaps [rsp+0x90], xmm10
000077a70fdde5ae  vmovaps [rsp+0xA0], xmm11
000077a70fdde5b7  vmovaps [rsp+0xB0], xmm12
000077a70fdde5c0  vmovaps [rsp+0xC0], xmm13
000077a70fdde5c9  vmovaps [rsp+0xD0], xmm14
000077a70fdde5d2  vmovaps [rsp+0xE0], xmm15
000077a70fdde5db  sub rsp, 0x30
000077a70fdde5df  movaps [rsp], xmm6
000077a70fdde5e3  movaps [rsp+0x10], xmm9
000077a70fdde5e9  movaps [rsp+0x20], xmm1
000077a70fdde5ee  lea rdi, [rsp]
000077a70fdde5f2  mov esi, 0x00
000077a70fdde5f7  mov rax, 0x6294188EF530
000077a70fdde601  call rax
000077a70fdde603  movaps xmm6, [rsp]
000077a70fdde607  add rsp, 0x30
000077a70fdde60b  vmovaps xmm0, [rsp]
000077a70fdde610  vmovaps xmm1, [rsp+0x10]
000077a70fdde616  vmovaps xmm2, [rsp+0x20]
000077a70fdde61c  vmovaps xmm3, [rsp+0x30]
000077a70fdde622  vmovaps xmm4, [rsp+0x40]
000077a70fdde628  vmovaps xmm5, [rsp+0x50]
000077a70fdde62e  vmovaps xmm7, [rsp+0x60]
000077a70fdde634  vmovaps xmm8, [rsp+0x70]
000077a70fdde63a  vmovaps xmm9, [rsp+0x80]
000077a70fdde643  vmovaps xmm10, [rsp+0x90]
000077a70fdde64c  vmovaps xmm11, [rsp+0xA0]
000077a70fdde655  vmovaps xmm12, [rsp+0xB0]
000077a70fdde65e  vmovaps xmm13, [rsp+0xC0]
000077a70fdde667  vmovaps xmm14, [rsp+0xD0]
000077a70fdde670  vmovaps xmm15, [rsp+0xE0]
000077a70fdde679  add rsp, 0xF0
000077a70fdde680  pop r11
000077a70fdde682  pop r10
000077a70fdde684  pop r9
000077a70fdde686  pop r8
000077a70fdde688  pop rsi
000077a70fdde689  pop rdi
000077a70fdde68a  pop rdx
000077a70fdde68b  pop rcx
000077a70fdde68c  pop rax
000077a70fdde68d  add rsp, 0x08
000077a70fdde691  jmp 0x000077A70FDDC15E
000077a70fdde696  sub rsp, 0x08
000077a70fdde69a  push rax
000077a70fdde69b  push rcx
000077a70fdde69c  push rdx
000077a70fdde69d  push rdi
000077a70fdde69e  push rsi
000077a70fdde69f  push r8
000077a70fdde6a1  push r9
000077a70fdde6a3  push r10
000077a70fdde6a5  push r11
000077a70fdde6a7  sub rsp, 0xF0
000077a70fdde6ae  vmovaps [rsp], xmm0
000077a70fdde6b3  vmovaps [rsp+0x10], xmm1
000077a70fdde6b9  vmovaps [rsp+0x20], xmm2
000077a70fdde6bf  vmovaps [rsp+0x30], xmm3
000077a70fdde6c5  vmovaps [rsp+0x40], xmm4
000077a70fdde6cb  vmovaps [rsp+0x50], xmm5
000077a70fdde6d1  vmovaps [rsp+0x60], xmm6
000077a70fdde6d7  vmovaps [rsp+0x70], xmm7
000077a70fdde6dd  vmovaps [rsp+0x80], xmm8
000077a70fdde6e6  vmovaps [rsp+0x90], xmm10
000077a70fdde6ef  vmovaps [rsp+0xA0], xmm11
000077a70fdde6f8  vmovaps [rsp+0xB0], xmm12
000077a70fdde701  vmovaps [rsp+0xC0], xmm13
000077a70fdde70a  vmovaps [rsp+0xD0], xmm14
000077a70fdde713  vmovaps [rsp+0xE0], xmm15
000077a70fdde71c  sub rsp, 0x30
000077a70fdde720  movaps [rsp], xmm9
000077a70fdde725  movaps [rsp+0x10], xmm3
000077a70fdde72a  movaps [rsp+0x20], xmm1
000077a70fdde72f  lea rdi, [rsp]
000077a70fdde733  mov esi, 0x00
000077a70fdde738  mov rax, 0x6294188EF530
000077a70fdde742  call rax
000077a70fdde744  movaps xmm9, [rsp]
000077a70fdde749  add rsp, 0x30
000077a70fdde74d  vmovaps xmm0, [rsp]
000077a70fdde752  vmovaps xmm1, [rsp+0x10]
000077a70fdde758  vmovaps xmm2, [rsp+0x20]
000077a70fdde75e  vmovaps xmm3, [rsp+0x30]
000077a70fdde764  vmovaps xmm4, [rsp+0x40]
000077a70fdde76a  vmovaps xmm5, [rsp+0x50]
000077a70fdde770  vmovaps xmm6, [rsp+0x60]
000077a70fdde776  vmovaps xmm7, [rsp+0x70]
000077a70fdde77c  vmovaps xmm8, [rsp+0x80]
000077a70fdde785  vmovaps xmm10, [rsp+0x90]
000077a70fdde78e  vmovaps xmm11, [rsp+0xA0]
000077a70fdde797  vmovaps xmm12, [rsp+0xB0]
000077a70fdde7a0  vmovaps xmm13, [rsp+0xC0]
000077a70fdde7a9  vmovaps xmm14, [rsp+0xD0]
000077a70fdde7b2  vmovaps xmm15, [rsp+0xE0]
000077a70fdde7bb  add rsp, 0xF0
000077a70fdde7c2  pop r11
000077a70fdde7c4  pop r10
000077a70fdde7c6  pop r9
000077a70fdde7c8  pop r8
000077a70fdde7ca  pop rsi
000077a70fdde7cb  pop rdi
000077a70fdde7cc  pop rdx
000077a70fdde7cd  pop rcx
000077a70fdde7ce  pop rax
000077a70fdde7cf  add rsp, 0x08
000077a70fdde7d3  jmp 0x000077A70FDDC1AA
000077a70fdde7d8  call 0x000077A70FCB52F0
000077a70fdde7dd  jmp 0x000077A70FDDC1B7
000077a70fdde7e2  sub rsp, 0x08
000077a70fdde7e6  push rax
000077a70fdde7e7  push rcx
000077a70fdde7e8  push rdx
000077a70fdde7e9  push rdi
000077a70fdde7ea  push rsi
000077a70fdde7eb  push r8
000077a70fdde7ed  push r9
000077a70fdde7ef  push r10
000077a70fdde7f1  push r11
000077a70fdde7f3  sub rsp, 0xF0
000077a70fdde7fa  vmovaps [rsp], xmm0
000077a70fdde7ff  vmovaps [rsp+0x10], xmm1
000077a70fdde805  vmovaps [rsp+0x20], xmm2
000077a70fdde80b  vmovaps [rsp+0x30], xmm3
000077a70fdde811  vmovaps [rsp+0x40], xmm4
000077a70fdde817  vmovaps [rsp+0x50], xmm5
000077a70fdde81d  vmovaps [rsp+0x60], xmm6
000077a70fdde823  vmovaps [rsp+0x70], xmm7
000077a70fdde829  vmovaps [rsp+0x80], xmm8
000077a70fdde832  vmovaps [rsp+0x90], xmm9
000077a70fdde83b  vmovaps [rsp+0xA0], xmm10
000077a70fdde844  vmovaps [rsp+0xB0], xmm11
000077a70fdde84d  vmovaps [rsp+0xC0], xmm12
000077a70fdde856  vmovaps [rsp+0xD0], xmm13
000077a70fdde85f  vmovaps [rsp+0xE0], xmm14
000077a70fdde868  sub rsp, 0x30
000077a70fdde86c  movaps [rsp], xmm15
000077a70fdde871  movaps [rsp+0x10], xmm3
000077a70fdde876  movaps [rsp+0x20], xmm7
000077a70fdde87b  lea rdi, [rsp]
000077a70fdde87f  mov esi, 0x00
000077a70fdde884  mov rax, 0x6294188EF530
000077a70fdde88e  call rax
000077a70fdde890  movaps xmm15, [rsp]
000077a70fdde895  add rsp, 0x30
000077a70fdde899  vmovaps xmm0, [rsp]
000077a70fdde89e  vmovaps xmm1, [rsp+0x10]
000077a70fdde8a4  vmovaps xmm2, [rsp+0x20]
000077a70fdde8aa  vmovaps xmm3, [rsp+0x30]
000077a70fdde8b0  vmovaps xmm4, [rsp+0x40]
000077a70fdde8b6  vmovaps xmm5, [rsp+0x50]
000077a70fdde8bc  vmovaps xmm6, [rsp+0x60]
000077a70fdde8c2  vmovaps xmm7, [rsp+0x70]
000077a70fdde8c8  vmovaps xmm8, [rsp+0x80]
000077a70fdde8d1  vmovaps xmm9, [rsp+0x90]
000077a70fdde8da  vmovaps xmm10, [rsp+0xA0]
000077a70fdde8e3  vmovaps xmm11, [rsp+0xB0]
000077a70fdde8ec  vmovaps xmm12, [rsp+0xC0]
000077a70fdde8f5  vmovaps xmm13, [rsp+0xD0]
000077a70fdde8fe  vmovaps xmm14, [rsp+0xE0]
000077a70fdde907  add rsp, 0xF0
000077a70fdde90e  pop r11
000077a70fdde910  pop r10
000077a70fdde912  pop r9
000077a70fdde914  pop r8
000077a70fdde916  pop rsi
000077a70fdde917  pop rdi
000077a70fdde918  pop rdx
000077a70fdde919  pop rcx
000077a70fdde91a  pop rax
000077a70fdde91b  add rsp, 0x08
000077a70fdde91f  jmp 0x000077A70FDDC1E3
000077a70fdde924  sub rsp, 0x08
000077a70fdde928  push rax
000077a70fdde929  push rcx
000077a70fdde92a  push rdx
000077a70fdde92b  push rdi
000077a70fdde92c  push rsi
000077a70fdde92d  push r8
000077a70fdde92f  push r9
000077a70fdde931  push r10
000077a70fdde933  push r11
000077a70fdde935  sub rsp, 0xF0
000077a70fdde93c  vmovaps [rsp], xmm0
000077a70fdde941  vmovaps [rsp+0x10], xmm1
000077a70fdde947  vmovaps [rsp+0x20], xmm2
000077a70fdde94d  vmovaps [rsp+0x30], xmm4
000077a70fdde953  vmovaps [rsp+0x40], xmm5
000077a70fdde959  vmovaps [rsp+0x50], xmm6
000077a70fdde95f  vmovaps [rsp+0x60], xmm7
000077a70fdde965  vmovaps [rsp+0x70], xmm8
000077a70fdde96b  vmovaps [rsp+0x80], xmm9
000077a70fdde974  vmovaps [rsp+0x90], xmm10
000077a70fdde97d  vmovaps [rsp+0xA0], xmm11
000077a70fdde986  vmovaps [rsp+0xB0], xmm12
000077a70fdde98f  vmovaps [rsp+0xC0], xmm13
000077a70fdde998  vmovaps [rsp+0xD0], xmm14
000077a70fdde9a1  vmovaps [rsp+0xE0], xmm15
000077a70fdde9aa  sub rsp, 0x30
000077a70fdde9ae  movaps [rsp], xmm3
000077a70fdde9b2  movaps [rsp+0x10], xmm1
000077a70fdde9b7  movaps [rsp+0x20], xmm15
000077a70fdde9bd  lea rdi, [rsp]
000077a70fdde9c1  mov esi, 0x00
000077a70fdde9c6  mov rax, 0x6294188EF530
000077a70fdde9d0  call rax
000077a70fdde9d2  movaps xmm3, [rsp]
000077a70fdde9d6  add rsp, 0x30
000077a70fdde9da  vmovaps xmm0, [rsp]
000077a70fdde9df  vmovaps xmm1, [rsp+0x10]
000077a70fdde9e5  vmovaps xmm2, [rsp+0x20]
000077a70fdde9eb  vmovaps xmm4, [rsp+0x30]
000077a70fdde9f1  vmovaps xmm5, [rsp+0x40]
000077a70fdde9f7  vmovaps xmm6, [rsp+0x50]
000077a70fdde9fd  vmovaps xmm7, [rsp+0x60]
000077a70fddea03  vmovaps xmm8, [rsp+0x70]
000077a70fddea09  vmovaps xmm9, [rsp+0x80]
000077a70fddea12  vmovaps xmm10, [rsp+0x90]
000077a70fddea1b  vmovaps xmm11, [rsp+0xA0]
000077a70fddea24  vmovaps xmm12, [rsp+0xB0]
000077a70fddea2d  vmovaps xmm13, [rsp+0xC0]
000077a70fddea36  vmovaps xmm14, [rsp+0xD0]
000077a70fddea3f  vmovaps xmm15, [rsp+0xE0]
000077a70fddea48  add rsp, 0xF0
000077a70fddea4f  pop r11
000077a70fddea51  pop r10
000077a70fddea53  pop r9
000077a70fddea55  pop r8
000077a70fddea57  pop rsi
000077a70fddea58  pop rdi
000077a70fddea59  pop rdx
000077a70fddea5a  pop rcx
000077a70fddea5b  pop rax
000077a70fddea5c  add rsp, 0x08
000077a70fddea60  jmp 0x000077A70FDDC272
000077a70fddea65  call 0x000077A70FCB52F0
000077a70fddea6a  jmp 0x000077A70FDDC27C
000077a70fddea6f  sub rsp, 0x08
000077a70fddea73  push rax
000077a70fddea74  push rcx
000077a70fddea75  push rdx
000077a70fddea76  push rdi
000077a70fddea77  push rsi
000077a70fddea78  push r8
000077a70fddea7a  push r9
000077a70fddea7c  push r10
000077a70fddea7e  push r11
000077a70fddea80  sub rsp, 0xF0
000077a70fddea87  vmovaps [rsp], xmm0
000077a70fddea8c  vmovaps [rsp+0x10], xmm1
000077a70fddea92  vmovaps [rsp+0x20], xmm2
000077a70fddea98  vmovaps [rsp+0x30], xmm3
000077a70fddea9e  vmovaps [rsp+0x40], xmm4
000077a70fddeaa4  vmovaps [rsp+0x50], xmm5
000077a70fddeaaa  vmovaps [rsp+0x60], xmm6
000077a70fddeab0  vmovaps [rsp+0x70], xmm7
000077a70fddeab6  vmovaps [rsp+0x80], xmm8
000077a70fddeabf  vmovaps [rsp+0x90], xmm9
000077a70fddeac8  vmovaps [rsp+0xA0], xmm10
000077a70fddead1  vmovaps [rsp+0xB0], xmm11
000077a70fddeada  vmovaps [rsp+0xC0], xmm12
000077a70fddeae3  vmovaps [rsp+0xD0], xmm13
000077a70fddeaec  vmovaps [rsp+0xE0], xmm14
000077a70fddeaf5  sub rsp, 0x30
000077a70fddeaf9  movaps [rsp], xmm15
000077a70fddeafe  movaps [rsp+0x10], xmm14
000077a70fddeb04  movaps [rsp+0x20], xmm4
000077a70fddeb09  lea rdi, [rsp]
000077a70fddeb0d  mov esi, 0x00
000077a70fddeb12  mov rax, 0x6294188EF530
000077a70fddeb1c  call rax
000077a70fddeb1e  movaps xmm15, [rsp]
000077a70fddeb23  add rsp, 0x30
000077a70fddeb27  vmovaps xmm0, [rsp]
000077a70fddeb2c  vmovaps xmm1, [rsp+0x10]
000077a70fddeb32  vmovaps xmm2, [rsp+0x20]
000077a70fddeb38  vmovaps xmm3, [rsp+0x30]
000077a70fddeb3e  vmovaps xmm4, [rsp+0x40]
000077a70fddeb44  vmovaps xmm5, [rsp+0x50]
000077a70fddeb4a  vmovaps xmm6, [rsp+0x60]
000077a70fddeb50  vmovaps xmm7, [rsp+0x70]
000077a70fddeb56  vmovaps xmm8, [rsp+0x80]
000077a70fddeb5f  vmovaps xmm9, [rsp+0x90]
000077a70fddeb68  vmovaps xmm10, [rsp+0xA0]
000077a70fddeb71  vmovaps xmm11, [rsp+0xB0]
000077a70fddeb7a  vmovaps xmm12, [rsp+0xC0]
000077a70fddeb83  vmovaps xmm13, [rsp+0xD0]
000077a70fddeb8c  vmovaps xmm14, [rsp+0xE0]
000077a70fddeb95  add rsp, 0xF0
000077a70fddeb9c  pop r11
000077a70fddeb9e  pop r10
000077a70fddeba0  pop r9
000077a70fddeba2  pop r8
000077a70fddeba4  pop rsi
000077a70fddeba5  pop rdi
000077a70fddeba6  pop rdx
000077a70fddeba7  pop rcx
000077a70fddeba8  pop rax
000077a70fddeba9  add rsp, 0x08
000077a70fddebad  jmp 0x000077A70FDDC2AA
000077a70fddebb2  sub rsp, 0x08
000077a70fddebb6  push rax
000077a70fddebb7  push rcx
000077a70fddebb8  push rdx
000077a70fddebb9  push rdi
000077a70fddebba  push rsi
000077a70fddebbb  push r8
000077a70fddebbd  push r9
000077a70fddebbf  push r10
000077a70fddebc1  push r11
000077a70fddebc3  sub rsp, 0xF0
000077a70fddebca  vmovaps [rsp], xmm0
000077a70fddebcf  vmovaps [rsp+0x10], xmm1
000077a70fddebd5  vmovaps [rsp+0x20], xmm2
000077a70fddebdb  vmovaps [rsp+0x30], xmm3
000077a70fddebe1  vmovaps [rsp+0x40], xmm4
000077a70fddebe7  vmovaps [rsp+0x50], xmm5
000077a70fddebed  vmovaps [rsp+0x60], xmm6
000077a70fddebf3  vmovaps [rsp+0x70], xmm7
000077a70fddebf9  vmovaps [rsp+0x80], xmm8
000077a70fddec02  vmovaps [rsp+0x90], xmm9
000077a70fddec0b  vmovaps [rsp+0xA0], xmm10
000077a70fddec14  vmovaps [rsp+0xB0], xmm11
000077a70fddec1d  vmovaps [rsp+0xC0], xmm12
000077a70fddec26  vmovaps [rsp+0xD0], xmm13
000077a70fddec2f  vmovaps [rsp+0xE0], xmm15
000077a70fddec38  sub rsp, 0x30
000077a70fddec3c  movaps [rsp], xmm14
000077a70fddec41  movaps [rsp+0x10], xmm2
000077a70fddec46  movaps [rsp+0x20], xmm1
000077a70fddec4b  lea rdi, [rsp]
000077a70fddec4f  mov esi, 0x00
000077a70fddec54  mov rax, 0x6294188EF530
000077a70fddec5e  call rax
000077a70fddec60  movaps xmm14, [rsp]
000077a70fddec65  add rsp, 0x30
000077a70fddec69  vmovaps xmm0, [rsp]
000077a70fddec6e  vmovaps xmm1, [rsp+0x10]
000077a70fddec74  vmovaps xmm2, [rsp+0x20]
000077a70fddec7a  vmovaps xmm3, [rsp+0x30]
000077a70fddec80  vmovaps xmm4, [rsp+0x40]
000077a70fddec86  vmovaps xmm5, [rsp+0x50]
000077a70fddec8c  vmovaps xmm6, [rsp+0x60]
000077a70fddec92  vmovaps xmm7, [rsp+0x70]
000077a70fddec98  vmovaps xmm8, [rsp+0x80]
000077a70fddeca1  vmovaps xmm9, [rsp+0x90]
000077a70fddecaa  vmovaps xmm10, [rsp+0xA0]
000077a70fddecb3  vmovaps xmm11, [rsp+0xB0]
000077a70fddecbc  vmovaps xmm12, [rsp+0xC0]
000077a70fddecc5  vmovaps xmm13, [rsp+0xD0]
000077a70fddecce  vmovaps xmm15, [rsp+0xE0]
000077a70fddecd7  add rsp, 0xF0
000077a70fddecde  pop r11
000077a70fddece0  pop r10
000077a70fddece2  pop r9
000077a70fddece4  pop r8
000077a70fddece6  pop rsi
000077a70fddece7  pop rdi
000077a70fddece8  pop rdx
000077a70fddece9  pop rcx
000077a70fddecea  pop rax
000077a70fddeceb  add rsp, 0x08
000077a70fddecef  jmp 0x000077A70FDDC2D0
000077a70fddecf4  sub rsp, 0x08
000077a70fddecf8  push rax
000077a70fddecf9  push rcx
000077a70fddecfa  push rdx
000077a70fddecfb  push rdi
000077a70fddecfc  push rsi
000077a70fddecfd  push r8
000077a70fddecff  push r9
000077a70fdded01  push r10
000077a70fdded03  push r11
000077a70fdded05  sub rsp, 0xF0
000077a70fdded0c  vmovaps [rsp], xmm0
000077a70fdded11  vmovaps [rsp+0x10], xmm2
000077a70fdded17  vmovaps [rsp+0x20], xmm3
000077a70fdded1d  vmovaps [rsp+0x30], xmm4
000077a70fdded23  vmovaps [rsp+0x40], xmm5
000077a70fdded29  vmovaps [rsp+0x50], xmm6
000077a70fdded2f  vmovaps [rsp+0x60], xmm7
000077a70fdded35  vmovaps [rsp+0x70], xmm8
000077a70fdded3b  vmovaps [rsp+0x80], xmm9
000077a70fdded44  vmovaps [rsp+0x90], xmm10
000077a70fdded4d  vmovaps [rsp+0xA0], xmm11
000077a70fdded56  vmovaps [rsp+0xB0], xmm12
000077a70fdded5f  vmovaps [rsp+0xC0], xmm13
000077a70fdded68  vmovaps [rsp+0xD0], xmm14
000077a70fdded71  vmovaps [rsp+0xE0], xmm15
000077a70fdded7a  sub rsp, 0x30
000077a70fdded7e  movaps [rsp], xmm1
000077a70fdded82  movaps [rsp+0x10], xmm4
000077a70fdded87  movaps [rsp+0x20], xmm9
000077a70fdded8d  lea rdi, [rsp]
000077a70fdded91  mov esi, 0x00
000077a70fdded96  mov rax, 0x6294188EF530
000077a70fddeda0  call rax
000077a70fddeda2  movaps xmm1, [rsp]
000077a70fddeda6  add rsp, 0x30
000077a70fddedaa  vmovaps xmm0, [rsp]
000077a70fddedaf  vmovaps xmm2, [rsp+0x10]
000077a70fddedb5  vmovaps xmm3, [rsp+0x20]
000077a70fddedbb  vmovaps xmm4, [rsp+0x30]
000077a70fddedc1  vmovaps xmm5, [rsp+0x40]
000077a70fddedc7  vmovaps xmm6, [rsp+0x50]
000077a70fddedcd  vmovaps xmm7, [rsp+0x60]
000077a70fddedd3  vmovaps xmm8, [rsp+0x70]
000077a70fddedd9  vmovaps xmm9, [rsp+0x80]
000077a70fddede2  vmovaps xmm10, [rsp+0x90]
000077a70fddedeb  vmovaps xmm11, [rsp+0xA0]
000077a70fddedf4  vmovaps xmm12, [rsp+0xB0]
000077a70fddedfd  vmovaps xmm13, [rsp+0xC0]
000077a70fddee06  vmovaps xmm14, [rsp+0xD0]
000077a70fddee0f  vmovaps xmm15, [rsp+0xE0]
000077a70fddee18  add rsp, 0xF0
000077a70fddee1f  pop r11
000077a70fddee21  pop r10
000077a70fddee23  pop r9
000077a70fddee25  pop r8
000077a70fddee27  pop rsi
000077a70fddee28  pop rdi
000077a70fddee29  pop rdx
000077a70fddee2a  pop rcx
000077a70fddee2b  pop rax
000077a70fddee2c  add rsp, 0x08
000077a70fddee30  jmp 0x000077A70FDDC2EE
000077a70fddee35  sub rsp, 0x08
000077a70fddee39  push rax
000077a70fddee3a  push rcx
000077a70fddee3b  push rdx
000077a70fddee3c  push rdi
000077a70fddee3d  push rsi
000077a70fddee3e  push r8
000077a70fddee40  push r9
000077a70fddee42  push r10
000077a70fddee44  push r11
000077a70fddee46  sub rsp, 0xF0
000077a70fddee4d  vmovaps [rsp], xmm0
000077a70fddee52  vmovaps [rsp+0x10], xmm1
000077a70fddee58  vmovaps [rsp+0x20], xmm2
000077a70fddee5e  vmovaps [rsp+0x30], xmm3
000077a70fddee64  vmovaps [rsp+0x40], xmm5
000077a70fddee6a  vmovaps [rsp+0x50], xmm6
000077a70fddee70  vmovaps [rsp+0x60], xmm7
000077a70fddee76  vmovaps [rsp+0x70], xmm8
000077a70fddee7c  vmovaps [rsp+0x80], xmm9
000077a70fddee85  vmovaps [rsp+0x90], xmm10
000077a70fddee8e  vmovaps [rsp+0xA0], xmm11
000077a70fddee97  vmovaps [rsp+0xB0], xmm12
000077a70fddeea0  vmovaps [rsp+0xC0], xmm13
000077a70fddeea9  vmovaps [rsp+0xD0], xmm14
000077a70fddeeb2  vmovaps [rsp+0xE0], xmm15
000077a70fddeebb  sub rsp, 0x30
000077a70fddeebf  movaps [rsp], xmm4
000077a70fddeec3  movaps [rsp+0x10], xmm2
000077a70fddeec8  movaps [rsp+0x20], xmm9
000077a70fddeece  lea rdi, [rsp]
000077a70fddeed2  mov esi, 0x00
000077a70fddeed7  mov rax, 0x6294188EF530
000077a70fddeee1  call rax
000077a70fddeee3  movaps xmm4, [rsp]
000077a70fddeee7  add rsp, 0x30
000077a70fddeeeb  vmovaps xmm0, [rsp]
000077a70fddeef0  vmovaps xmm1, [rsp+0x10]
000077a70fddeef6  vmovaps xmm2, [rsp+0x20]
000077a70fddeefc  vmovaps xmm3, [rsp+0x30]
000077a70fddef02  vmovaps xmm5, [rsp+0x40]
000077a70fddef08  vmovaps xmm6, [rsp+0x50]
000077a70fddef0e  vmovaps xmm7, [rsp+0x60]
000077a70fddef14  vmovaps xmm8, [rsp+0x70]
000077a70fddef1a  vmovaps xmm9, [rsp+0x80]
000077a70fddef23  vmovaps xmm10, [rsp+0x90]
000077a70fddef2c  vmovaps xmm11, [rsp+0xA0]
000077a70fddef35  vmovaps xmm12, [rsp+0xB0]
000077a70fddef3e  vmovaps xmm13, [rsp+0xC0]
000077a70fddef47  vmovaps xmm14, [rsp+0xD0]
000077a70fddef50  vmovaps xmm15, [rsp+0xE0]
000077a70fddef59  add rsp, 0xF0
000077a70fddef60  pop r11
000077a70fddef62  pop r10
000077a70fddef64  pop r9
000077a70fddef66  pop r8
000077a70fddef68  pop rsi
000077a70fddef69  pop rdi
000077a70fddef6a  pop rdx
000077a70fddef6b  pop rcx
000077a70fddef6c  pop rax
000077a70fddef6d  add rsp, 0x08
000077a70fddef71  jmp 0x000077A70FDDC31E
000077a70fddef76  sub rsp, 0x08
000077a70fddef7a  push rax
000077a70fddef7b  push rcx
000077a70fddef7c  push rdx
000077a70fddef7d  push rdi
000077a70fddef7e  push rsi
000077a70fddef7f  push r8
000077a70fddef81  push r9
000077a70fddef83  push r10
000077a70fddef85  push r11
000077a70fddef87  sub rsp, 0xF0
000077a70fddef8e  vmovaps [rsp], xmm0
000077a70fddef93  vmovaps [rsp+0x10], xmm1
000077a70fddef99  vmovaps [rsp+0x20], xmm2
000077a70fddef9f  vmovaps [rsp+0x30], xmm3
000077a70fddefa5  vmovaps [rsp+0x40], xmm4
000077a70fddefab  vmovaps [rsp+0x50], xmm5
000077a70fddefb1  vmovaps [rsp+0x60], xmm6
000077a70fddefb7  vmovaps [rsp+0x70], xmm7
000077a70fddefbd  vmovaps [rsp+0x80], xmm8
000077a70fddefc6  vmovaps [rsp+0x90], xmm10
000077a70fddefcf  vmovaps [rsp+0xA0], xmm11
000077a70fddefd8  vmovaps [rsp+0xB0], xmm12
000077a70fddefe1  vmovaps [rsp+0xC0], xmm13
000077a70fddefea  vmovaps [rsp+0xD0], xmm14
000077a70fddeff3  vmovaps [rsp+0xE0], xmm15
000077a70fddeffc  sub rsp, 0x30
000077a70fddf000  movaps [rsp], xmm9
000077a70fddf005  movaps [rsp+0x10], xmm2
000077a70fddf00a  movaps [rsp+0x20], xmm1
000077a70fddf00f  lea rdi, [rsp]
000077a70fddf013  mov esi, 0x00
000077a70fddf018  mov rax, 0x6294188EF530
000077a70fddf022  call rax
000077a70fddf024  movaps xmm9, [rsp]
000077a70fddf029  add rsp, 0x30
000077a70fddf02d  vmovaps xmm0, [rsp]
000077a70fddf032  vmovaps xmm1, [rsp+0x10]
000077a70fddf038  vmovaps xmm2, [rsp+0x20]
000077a70fddf03e  vmovaps xmm3, [rsp+0x30]
000077a70fddf044  vmovaps xmm4, [rsp+0x40]
000077a70fddf04a  vmovaps xmm5, [rsp+0x50]
000077a70fddf050  vmovaps xmm6, [rsp+0x60]
000077a70fddf056  vmovaps xmm7, [rsp+0x70]
000077a70fddf05c  vmovaps xmm8, [rsp+0x80]
000077a70fddf065  vmovaps xmm10, [rsp+0x90]
000077a70fddf06e  vmovaps xmm11, [rsp+0xA0]
000077a70fddf077  vmovaps xmm12, [rsp+0xB0]
000077a70fddf080  vmovaps xmm13, [rsp+0xC0]
000077a70fddf089  vmovaps xmm14, [rsp+0xD0]
000077a70fddf092  vmovaps xmm15, [rsp+0xE0]
000077a70fddf09b  add rsp, 0xF0
000077a70fddf0a2  pop r11
000077a70fddf0a4  pop r10
000077a70fddf0a6  pop r9
000077a70fddf0a8  pop r8
000077a70fddf0aa  pop rsi
000077a70fddf0ab  pop rdi
000077a70fddf0ac  pop rdx
000077a70fddf0ad  pop rcx
000077a70fddf0ae  pop rax
000077a70fddf0af  add rsp, 0x08
000077a70fddf0b3  jmp 0x000077A70FDDC354
000077a70fddf0b8  sub rsp, 0x08
000077a70fddf0bc  push rax
000077a70fddf0bd  push rcx
000077a70fddf0be  push rdx
000077a70fddf0bf  push rdi
000077a70fddf0c0  push rsi
000077a70fddf0c1  push r8
000077a70fddf0c3  push r9
000077a70fddf0c5  push r10
000077a70fddf0c7  push r11
000077a70fddf0c9  sub rsp, 0xF0
000077a70fddf0d0  vmovaps [rsp], xmm0
000077a70fddf0d5  vmovaps [rsp+0x10], xmm2
000077a70fddf0db  vmovaps [rsp+0x20], xmm3
000077a70fddf0e1  vmovaps [rsp+0x30], xmm4
000077a70fddf0e7  vmovaps [rsp+0x40], xmm5
000077a70fddf0ed  vmovaps [rsp+0x50], xmm6
000077a70fddf0f3  vmovaps [rsp+0x60], xmm7
000077a70fddf0f9  vmovaps [rsp+0x70], xmm8
000077a70fddf0ff  vmovaps [rsp+0x80], xmm9
000077a70fddf108  vmovaps [rsp+0x90], xmm10
000077a70fddf111  vmovaps [rsp+0xA0], xmm11
000077a70fddf11a  vmovaps [rsp+0xB0], xmm12
000077a70fddf123  vmovaps [rsp+0xC0], xmm13
000077a70fddf12c  vmovaps [rsp+0xD0], xmm14
000077a70fddf135  vmovaps [rsp+0xE0], xmm15
000077a70fddf13e  sub rsp, 0x30
000077a70fddf142  movaps [rsp], xmm1
000077a70fddf146  movaps [rsp+0x10], xmm15
000077a70fddf14c  movaps [rsp+0x20], xmm6
000077a70fddf151  lea rdi, [rsp]
000077a70fddf155  mov esi, 0x00
000077a70fddf15a  mov rax, 0x6294188EF530
000077a70fddf164  call rax
000077a70fddf166  movaps xmm1, [rsp]
000077a70fddf16a  add rsp, 0x30
000077a70fddf16e  vmovaps xmm0, [rsp]
000077a70fddf173  vmovaps xmm2, [rsp+0x10]
000077a70fddf179  vmovaps xmm3, [rsp+0x20]
000077a70fddf17f  vmovaps xmm4, [rsp+0x30]
000077a70fddf185  vmovaps xmm5, [rsp+0x40]
000077a70fddf18b  vmovaps xmm6, [rsp+0x50]
000077a70fddf191  vmovaps xmm7, [rsp+0x60]
000077a70fddf197  vmovaps xmm8, [rsp+0x70]
000077a70fddf19d  vmovaps xmm9, [rsp+0x80]
000077a70fddf1a6  vmovaps xmm10, [rsp+0x90]
000077a70fddf1af  vmovaps xmm11, [rsp+0xA0]
000077a70fddf1b8  vmovaps xmm12, [rsp+0xB0]
000077a70fddf1c1  vmovaps xmm13, [rsp+0xC0]
000077a70fddf1ca  vmovaps xmm14, [rsp+0xD0]
000077a70fddf1d3  vmovaps xmm15, [rsp+0xE0]
000077a70fddf1dc  add rsp, 0xF0
000077a70fddf1e3  pop r11
000077a70fddf1e5  pop r10
000077a70fddf1e7  pop r9
000077a70fddf1e9  pop r8
000077a70fddf1eb  pop rsi
000077a70fddf1ec  pop rdi
000077a70fddf1ed  pop rdx
000077a70fddf1ee  pop rcx
000077a70fddf1ef  pop rax
000077a70fddf1f0  add rsp, 0x08
000077a70fddf1f4  jmp 0x000077A70FDDC375
000077a70fddf1f9  sub rsp, 0x08
000077a70fddf1fd  push rax
000077a70fddf1fe  push rcx
000077a70fddf1ff  push rdx
000077a70fddf200  push rdi
000077a70fddf201  push rsi
000077a70fddf202  push r8
000077a70fddf204  push r9
000077a70fddf206  push r10
000077a70fddf208  push r11
000077a70fddf20a  sub rsp, 0xF0
000077a70fddf211  vmovaps [rsp], xmm0
000077a70fddf216  vmovaps [rsp+0x10], xmm1
000077a70fddf21c  vmovaps [rsp+0x20], xmm2
000077a70fddf222  vmovaps [rsp+0x30], xmm3
000077a70fddf228  vmovaps [rsp+0x40], xmm4
000077a70fddf22e  vmovaps [rsp+0x50], xmm5
000077a70fddf234  vmovaps [rsp+0x60], xmm6
000077a70fddf23a  vmovaps [rsp+0x70], xmm7
000077a70fddf240  vmovaps [rsp+0x80], xmm8
000077a70fddf249  vmovaps [rsp+0x90], xmm9
000077a70fddf252  vmovaps [rsp+0xA0], xmm10
000077a70fddf25b  vmovaps [rsp+0xB0], xmm11
000077a70fddf264  vmovaps [rsp+0xC0], xmm12
000077a70fddf26d  vmovaps [rsp+0xD0], xmm13
000077a70fddf276  vmovaps [rsp+0xE0], xmm14
000077a70fddf27f  sub rsp, 0x30
000077a70fddf283  movaps [rsp], xmm15
000077a70fddf288  movaps [rsp+0x10], xmm5
000077a70fddf28d  movaps [rsp+0x20], xmm3
000077a70fddf292  lea rdi, [rsp]
000077a70fddf296  mov esi, 0x00
000077a70fddf29b  mov rax, 0x6294188EF530
000077a70fddf2a5  call rax
000077a70fddf2a7  movaps xmm15, [rsp]
000077a70fddf2ac  add rsp, 0x30
000077a70fddf2b0  vmovaps xmm0, [rsp]
000077a70fddf2b5  vmovaps xmm1, [rsp+0x10]
000077a70fddf2bb  vmovaps xmm2, [rsp+0x20]
000077a70fddf2c1  vmovaps xmm3, [rsp+0x30]
000077a70fddf2c7  vmovaps xmm4, [rsp+0x40]
000077a70fddf2cd  vmovaps xmm5, [rsp+0x50]
000077a70fddf2d3  vmovaps xmm6, [rsp+0x60]
000077a70fddf2d9  vmovaps xmm7, [rsp+0x70]
000077a70fddf2df  vmovaps xmm8, [rsp+0x80]
000077a70fddf2e8  vmovaps xmm9, [rsp+0x90]
000077a70fddf2f1  vmovaps xmm10, [rsp+0xA0]
000077a70fddf2fa  vmovaps xmm11, [rsp+0xB0]
000077a70fddf303  vmovaps xmm12, [rsp+0xC0]
000077a70fddf30c  vmovaps xmm13, [rsp+0xD0]
000077a70fddf315  vmovaps xmm14, [rsp+0xE0]
000077a70fddf31e  add rsp, 0xF0
000077a70fddf325  pop r11
000077a70fddf327  pop r10
000077a70fddf329  pop r9
000077a70fddf32b  pop r8
000077a70fddf32d  pop rsi
000077a70fddf32e  pop rdi
000077a70fddf32f  pop rdx
000077a70fddf330  pop rcx
000077a70fddf331  pop rax
000077a70fddf332  add rsp, 0x08
000077a70fddf336  jmp 0x000077A70FDDC38F
000077a70fddf33b  sub rsp, 0x08
000077a70fddf33f  push rax
000077a70fddf340  push rcx
000077a70fddf341  push rdx
000077a70fddf342  push rdi
000077a70fddf343  push rsi
000077a70fddf344  push r8
000077a70fddf346  push r9
000077a70fddf348  push r10
000077a70fddf34a  push r11
000077a70fddf34c  sub rsp, 0xF0
000077a70fddf353  vmovaps [rsp], xmm0
000077a70fddf358  vmovaps [rsp+0x10], xmm1
000077a70fddf35e  vmovaps [rsp+0x20], xmm2
000077a70fddf364  vmovaps [rsp+0x30], xmm3
000077a70fddf36a  vmovaps [rsp+0x40], xmm4
000077a70fddf370  vmovaps [rsp+0x50], xmm6
000077a70fddf376  vmovaps [rsp+0x60], xmm7
000077a70fddf37c  vmovaps [rsp+0x70], xmm8
000077a70fddf382  vmovaps [rsp+0x80], xmm9
000077a70fddf38b  vmovaps [rsp+0x90], xmm10
000077a70fddf394  vmovaps [rsp+0xA0], xmm11
000077a70fddf39d  vmovaps [rsp+0xB0], xmm12
000077a70fddf3a6  vmovaps [rsp+0xC0], xmm13
000077a70fddf3af  vmovaps [rsp+0xD0], xmm14
000077a70fddf3b8  vmovaps [rsp+0xE0], xmm15
000077a70fddf3c1  sub rsp, 0x30
000077a70fddf3c5  movaps [rsp], xmm5
000077a70fddf3c9  movaps [rsp+0x10], xmm8
000077a70fddf3cf  movaps [rsp+0x20], xmm6
000077a70fddf3d4  lea rdi, [rsp]
000077a70fddf3d8  mov esi, 0x00
000077a70fddf3dd  mov rax, 0x6294188EF530
000077a70fddf3e7  call rax
000077a70fddf3e9  movaps xmm5, [rsp]
000077a70fddf3ed  add rsp, 0x30
000077a70fddf3f1  vmovaps xmm0, [rsp]
000077a70fddf3f6  vmovaps xmm1, [rsp+0x10]
000077a70fddf3fc  vmovaps xmm2, [rsp+0x20]
000077a70fddf402  vmovaps xmm3, [rsp+0x30]
000077a70fddf408  vmovaps xmm4, [rsp+0x40]
000077a70fddf40e  vmovaps xmm6, [rsp+0x50]
000077a70fddf414  vmovaps xmm7, [rsp+0x60]
000077a70fddf41a  vmovaps xmm8, [rsp+0x70]
000077a70fddf420  vmovaps xmm9, [rsp+0x80]
000077a70fddf429  vmovaps xmm10, [rsp+0x90]
000077a70fddf432  vmovaps xmm11, [rsp+0xA0]
000077a70fddf43b  vmovaps xmm12, [rsp+0xB0]
000077a70fddf444  vmovaps xmm13, [rsp+0xC0]
000077a70fddf44d  vmovaps xmm14, [rsp+0xD0]
000077a70fddf456  vmovaps xmm15, [rsp+0xE0]
000077a70fddf45f  add rsp, 0xF0
000077a70fddf466  pop r11
000077a70fddf468  pop r10
000077a70fddf46a  pop r9
000077a70fddf46c  pop r8
000077a70fddf46e  pop rsi
000077a70fddf46f  pop rdi
000077a70fddf470  pop rdx
000077a70fddf471  pop rcx
000077a70fddf472  pop rax
000077a70fddf473  add rsp, 0x08
000077a70fddf477  jmp 0x000077A70FDDC3B3
000077a70fddf47c  sub rsp, 0x08
000077a70fddf480  push rax
000077a70fddf481  push rcx
000077a70fddf482  push rdx
000077a70fddf483  push rdi
000077a70fddf484  push rsi
000077a70fddf485  push r8
000077a70fddf487  push r9
000077a70fddf489  push r10
000077a70fddf48b  push r11
000077a70fddf48d  sub rsp, 0xF0
000077a70fddf494  vmovaps [rsp], xmm0
000077a70fddf499  vmovaps [rsp+0x10], xmm1
000077a70fddf49f  vmovaps [rsp+0x20], xmm2
000077a70fddf4a5  vmovaps [rsp+0x30], xmm3
000077a70fddf4ab  vmovaps [rsp+0x40], xmm4
000077a70fddf4b1  vmovaps [rsp+0x50], xmm5
000077a70fddf4b7  vmovaps [rsp+0x60], xmm7
000077a70fddf4bd  vmovaps [rsp+0x70], xmm8
000077a70fddf4c3  vmovaps [rsp+0x80], xmm9
000077a70fddf4cc  vmovaps [rsp+0x90], xmm10
000077a70fddf4d5  vmovaps [rsp+0xA0], xmm11
000077a70fddf4de  vmovaps [rsp+0xB0], xmm12
000077a70fddf4e7  vmovaps [rsp+0xC0], xmm13
000077a70fddf4f0  vmovaps [rsp+0xD0], xmm14
000077a70fddf4f9  vmovaps [rsp+0xE0], xmm15
000077a70fddf502  sub rsp, 0x30
000077a70fddf506  movaps [rsp], xmm6
000077a70fddf50a  movaps [rsp+0x10], xmm10
000077a70fddf510  movaps [rsp+0x20], xmm8
000077a70fddf516  lea rdi, [rsp]
000077a70fddf51a  mov esi, 0x00
000077a70fddf51f  mov rax, 0x6294188EF530
000077a70fddf529  call rax
000077a70fddf52b  movaps xmm6, [rsp]
000077a70fddf52f  add rsp, 0x30
000077a70fddf533  vmovaps xmm0, [rsp]
000077a70fddf538  vmovaps xmm1, [rsp+0x10]
000077a70fddf53e  vmovaps xmm2, [rsp+0x20]
000077a70fddf544  vmovaps xmm3, [rsp+0x30]
000077a70fddf54a  vmovaps xmm4, [rsp+0x40]
000077a70fddf550  vmovaps xmm5, [rsp+0x50]
000077a70fddf556  vmovaps xmm7, [rsp+0x60]
000077a70fddf55c  vmovaps xmm8, [rsp+0x70]
000077a70fddf562  vmovaps xmm9, [rsp+0x80]
000077a70fddf56b  vmovaps xmm10, [rsp+0x90]
000077a70fddf574  vmovaps xmm11, [rsp+0xA0]
000077a70fddf57d  vmovaps xmm12, [rsp+0xB0]
000077a70fddf586  vmovaps xmm13, [rsp+0xC0]
000077a70fddf58f  vmovaps xmm14, [rsp+0xD0]
000077a70fddf598  vmovaps xmm15, [rsp+0xE0]
000077a70fddf5a1  add rsp, 0xF0
000077a70fddf5a8  pop r11
000077a70fddf5aa  pop r10
000077a70fddf5ac  pop r9
000077a70fddf5ae  pop r8
000077a70fddf5b0  pop rsi
000077a70fddf5b1  pop rdi
000077a70fddf5b2  pop rdx
000077a70fddf5b3  pop rcx
000077a70fddf5b4  pop rax
000077a70fddf5b5  add rsp, 0x08
000077a70fddf5b9  jmp 0x000077A70FDDC3D8
000077a70fddf5be  sub rsp, 0x08
000077a70fddf5c2  push rax
000077a70fddf5c3  push rcx
000077a70fddf5c4  push rdx
000077a70fddf5c5  push rdi
000077a70fddf5c6  push rsi
000077a70fddf5c7  push r8
000077a70fddf5c9  push r9
000077a70fddf5cb  push r10
000077a70fddf5cd  push r11
000077a70fddf5cf  sub rsp, 0xF0
000077a70fddf5d6  vmovaps [rsp], xmm0
000077a70fddf5db  vmovaps [rsp+0x10], xmm1
000077a70fddf5e1  vmovaps [rsp+0x20], xmm2
000077a70fddf5e7  vmovaps [rsp+0x30], xmm3
000077a70fddf5ed  vmovaps [rsp+0x40], xmm4
000077a70fddf5f3  vmovaps [rsp+0x50], xmm5
000077a70fddf5f9  vmovaps [rsp+0x60], xmm6
000077a70fddf5ff  vmovaps [rsp+0x70], xmm7
000077a70fddf605  vmovaps [rsp+0x80], xmm8
000077a70fddf60e  vmovaps [rsp+0x90], xmm9
000077a70fddf617  vmovaps [rsp+0xA0], xmm11
000077a70fddf620  vmovaps [rsp+0xB0], xmm12
000077a70fddf629  vmovaps [rsp+0xC0], xmm13
000077a70fddf632  vmovaps [rsp+0xD0], xmm14
000077a70fddf63b  vmovaps [rsp+0xE0], xmm15
000077a70fddf644  sub rsp, 0x30
000077a70fddf648  movaps [rsp], xmm10
000077a70fddf64d  movaps [rsp+0x10], xmm8
000077a70fddf653  movaps [rsp+0x20], xmm14
000077a70fddf659  lea rdi, [rsp]
000077a70fddf65d  mov esi, 0x00
000077a70fddf662  mov rax, 0x6294188EF530
000077a70fddf66c  call rax
000077a70fddf66e  movaps xmm10, [rsp]
000077a70fddf673  add rsp, 0x30
000077a70fddf677  vmovaps xmm0, [rsp]
000077a70fddf67c  vmovaps xmm1, [rsp+0x10]
000077a70fddf682  vmovaps xmm2, [rsp+0x20]
000077a70fddf688  vmovaps xmm3, [rsp+0x30]
000077a70fddf68e  vmovaps xmm4, [rsp+0x40]
000077a70fddf694  vmovaps xmm5, [rsp+0x50]
000077a70fddf69a  vmovaps xmm6, [rsp+0x60]
000077a70fddf6a0  vmovaps xmm7, [rsp+0x70]
000077a70fddf6a6  vmovaps xmm8, [rsp+0x80]
000077a70fddf6af  vmovaps xmm9, [rsp+0x90]
000077a70fddf6b8  vmovaps xmm11, [rsp+0xA0]
000077a70fddf6c1  vmovaps xmm12, [rsp+0xB0]
000077a70fddf6ca  vmovaps xmm13, [rsp+0xC0]
000077a70fddf6d3  vmovaps xmm14, [rsp+0xD0]
000077a70fddf6dc  vmovaps xmm15, [rsp+0xE0]
000077a70fddf6e5  add rsp, 0xF0
000077a70fddf6ec  pop r11
000077a70fddf6ee  pop r10
000077a70fddf6f0  pop r9
000077a70fddf6f2  pop r8
000077a70fddf6f4  pop rsi
000077a70fddf6f5  pop rdi
000077a70fddf6f6  pop rdx
000077a70fddf6f7  pop rcx
000077a70fddf6f8  pop rax
000077a70fddf6f9  add rsp, 0x08
000077a70fddf6fd  jmp 0x000077A70FDDC3F8
000077a70fddf702  sub rsp, 0x08
000077a70fddf706  push rax
000077a70fddf707  push rcx
000077a70fddf708  push rdx
000077a70fddf709  push rdi
000077a70fddf70a  push rsi
000077a70fddf70b  push r8
000077a70fddf70d  push r9
000077a70fddf70f  push r10
000077a70fddf711  push r11
000077a70fddf713  sub rsp, 0xF0
000077a70fddf71a  vmovaps [rsp], xmm0
000077a70fddf71f  vmovaps [rsp+0x10], xmm1
000077a70fddf725  vmovaps [rsp+0x20], xmm2
000077a70fddf72b  vmovaps [rsp+0x30], xmm3
000077a70fddf731  vmovaps [rsp+0x40], xmm4
000077a70fddf737  vmovaps [rsp+0x50], xmm5
000077a70fddf73d  vmovaps [rsp+0x60], xmm6
000077a70fddf743  vmovaps [rsp+0x70], xmm7
000077a70fddf749  vmovaps [rsp+0x80], xmm8
000077a70fddf752  vmovaps [rsp+0x90], xmm9
000077a70fddf75b  vmovaps [rsp+0xA0], xmm10
000077a70fddf764  vmovaps [rsp+0xB0], xmm11
000077a70fddf76d  vmovaps [rsp+0xC0], xmm12
000077a70fddf776  vmovaps [rsp+0xD0], xmm13
000077a70fddf77f  vmovaps [rsp+0xE0], xmm15
000077a70fddf788  sub rsp, 0x30
000077a70fddf78c  movaps [rsp], xmm14
000077a70fddf791  movaps [rsp+0x10], xmm8
000077a70fddf797  movaps [rsp+0x20], xmm4
000077a70fddf79c  lea rdi, [rsp]
000077a70fddf7a0  mov esi, 0x00
000077a70fddf7a5  mov rax, 0x6294188EF530
000077a70fddf7af  call rax
000077a70fddf7b1  movaps xmm14, [rsp]
000077a70fddf7b6  add rsp, 0x30
000077a70fddf7ba  vmovaps xmm0, [rsp]
000077a70fddf7bf  vmovaps xmm1, [rsp+0x10]
000077a70fddf7c5  vmovaps xmm2, [rsp+0x20]
000077a70fddf7cb  vmovaps xmm3, [rsp+0x30]
000077a70fddf7d1  vmovaps xmm4, [rsp+0x40]
000077a70fddf7d7  vmovaps xmm5, [rsp+0x50]
000077a70fddf7dd  vmovaps xmm6, [rsp+0x60]
000077a70fddf7e3  vmovaps xmm7, [rsp+0x70]
000077a70fddf7e9  vmovaps xmm8, [rsp+0x80]
000077a70fddf7f2  vmovaps xmm9, [rsp+0x90]
000077a70fddf7fb  vmovaps xmm10, [rsp+0xA0]
000077a70fddf804  vmovaps xmm11, [rsp+0xB0]
000077a70fddf80d  vmovaps xmm12, [rsp+0xC0]
000077a70fddf816  vmovaps xmm13, [rsp+0xD0]
000077a70fddf81f  vmovaps xmm15, [rsp+0xE0]
000077a70fddf828  add rsp, 0xF0
000077a70fddf82f  pop r11
000077a70fddf831  pop r10
000077a70fddf833  pop r9
000077a70fddf835  pop r8
000077a70fddf837  pop rsi
000077a70fddf838  pop rdi
000077a70fddf839  pop rdx
000077a70fddf83a  pop rcx
000077a70fddf83b  pop rax
000077a70fddf83c  add rsp, 0x08
000077a70fddf840  jmp 0x000077A70FDDC418
000077a70fddf845  sub rsp, 0x08
000077a70fddf849  push rax
000077a70fddf84a  push rcx
000077a70fddf84b  push rdx
000077a70fddf84c  push rdi
000077a70fddf84d  push rsi
000077a70fddf84e  push r8
000077a70fddf850  push r9
000077a70fddf852  push r10
000077a70fddf854  push r11
000077a70fddf856  sub rsp, 0xF0
000077a70fddf85d  vmovaps [rsp], xmm0
000077a70fddf862  vmovaps [rsp+0x10], xmm1
000077a70fddf868  vmovaps [rsp+0x20], xmm2
000077a70fddf86e  vmovaps [rsp+0x30], xmm3
000077a70fddf874  vmovaps [rsp+0x40], xmm5
000077a70fddf87a  vmovaps [rsp+0x50], xmm6
000077a70fddf880  vmovaps [rsp+0x60], xmm7
000077a70fddf886  vmovaps [rsp+0x70], xmm8
000077a70fddf88c  vmovaps [rsp+0x80], xmm9
000077a70fddf895  vmovaps [rsp+0x90], xmm10
000077a70fddf89e  vmovaps [rsp+0xA0], xmm11
000077a70fddf8a7  vmovaps [rsp+0xB0], xmm12
000077a70fddf8b0  vmovaps [rsp+0xC0], xmm13
000077a70fddf8b9  vmovaps [rsp+0xD0], xmm14
000077a70fddf8c2  vmovaps [rsp+0xE0], xmm15
000077a70fddf8cb  sub rsp, 0x30
000077a70fddf8cf  movaps [rsp], xmm4
000077a70fddf8d3  movaps [rsp+0x10], xmm13
000077a70fddf8d9  movaps [rsp+0x20], xmm8
000077a70fddf8df  lea rdi, [rsp]
000077a70fddf8e3  mov esi, 0x00
000077a70fddf8e8  mov rax, 0x6294188EF530
000077a70fddf8f2  call rax
000077a70fddf8f4  movaps xmm4, [rsp]
000077a70fddf8f8  add rsp, 0x30
000077a70fddf8fc  vmovaps xmm0, [rsp]
000077a70fddf901  vmovaps xmm1, [rsp+0x10]
000077a70fddf907  vmovaps xmm2, [rsp+0x20]
000077a70fddf90d  vmovaps xmm3, [rsp+0x30]
000077a70fddf913  vmovaps xmm5, [rsp+0x40]
000077a70fddf919  vmovaps xmm6, [rsp+0x50]
000077a70fddf91f  vmovaps xmm7, [rsp+0x60]
000077a70fddf925  vmovaps xmm8, [rsp+0x70]
000077a70fddf92b  vmovaps xmm9, [rsp+0x80]
000077a70fddf934  vmovaps xmm10, [rsp+0x90]
000077a70fddf93d  vmovaps xmm11, [rsp+0xA0]
000077a70fddf946  vmovaps xmm12, [rsp+0xB0]
000077a70fddf94f  vmovaps xmm13, [rsp+0xC0]
000077a70fddf958  vmovaps xmm14, [rsp+0xD0]
000077a70fddf961  vmovaps xmm15, [rsp+0xE0]
000077a70fddf96a  add rsp, 0xF0
000077a70fddf971  pop r11
000077a70fddf973  pop r10
000077a70fddf975  pop r9
000077a70fddf977  pop r8
000077a70fddf979  pop rsi
000077a70fddf97a  pop rdi
000077a70fddf97b  pop rdx
000077a70fddf97c  pop rcx
000077a70fddf97d  pop rax
000077a70fddf97e  add rsp, 0x08
000077a70fddf982  jmp 0x000077A70FDDC43D
000077a70fddf987  sub rsp, 0x08
000077a70fddf98b  push rax
000077a70fddf98c  push rcx
000077a70fddf98d  push rdx
000077a70fddf98e  push rdi
000077a70fddf98f  push rsi
000077a70fddf990  push r8
000077a70fddf992  push r9
000077a70fddf994  push r10
000077a70fddf996  push r11
000077a70fddf998  sub rsp, 0xF0
000077a70fddf99f  vmovaps [rsp], xmm0
000077a70fddf9a4  vmovaps [rsp+0x10], xmm1
000077a70fddf9aa  vmovaps [rsp+0x20], xmm2
000077a70fddf9b0  vmovaps [rsp+0x30], xmm3
000077a70fddf9b6  vmovaps [rsp+0x40], xmm4
000077a70fddf9bc  vmovaps [rsp+0x50], xmm5
000077a70fddf9c2  vmovaps [rsp+0x60], xmm6
000077a70fddf9c8  vmovaps [rsp+0x70], xmm7
000077a70fddf9ce  vmovaps [rsp+0x80], xmm8
000077a70fddf9d7  vmovaps [rsp+0x90], xmm9
000077a70fddf9e0  vmovaps [rsp+0xA0], xmm10
000077a70fddf9e9  vmovaps [rsp+0xB0], xmm11
000077a70fddf9f2  vmovaps [rsp+0xC0], xmm12
000077a70fddf9fb  vmovaps [rsp+0xD0], xmm14
000077a70fddfa04  vmovaps [rsp+0xE0], xmm15
000077a70fddfa0d  sub rsp, 0x30
000077a70fddfa11  movaps [rsp], xmm13
000077a70fddfa16  movaps [rsp+0x10], xmm15
000077a70fddfa1c  movaps [rsp+0x20], xmm9
000077a70fddfa22  lea rdi, [rsp]
000077a70fddfa26  mov esi, 0x00
000077a70fddfa2b  mov rax, 0x6294188EF530
000077a70fddfa35  call rax
000077a70fddfa37  movaps xmm13, [rsp]
000077a70fddfa3c  add rsp, 0x30
000077a70fddfa40  vmovaps xmm0, [rsp]
000077a70fddfa45  vmovaps xmm1, [rsp+0x10]
000077a70fddfa4b  vmovaps xmm2, [rsp+0x20]
000077a70fddfa51  vmovaps xmm3, [rsp+0x30]
000077a70fddfa57  vmovaps xmm4, [rsp+0x40]
000077a70fddfa5d  vmovaps xmm5, [rsp+0x50]
000077a70fddfa63  vmovaps xmm6, [rsp+0x60]
000077a70fddfa69  vmovaps xmm7, [rsp+0x70]
000077a70fddfa6f  vmovaps xmm8, [rsp+0x80]
000077a70fddfa78  vmovaps xmm9, [rsp+0x90]
000077a70fddfa81  vmovaps xmm10, [rsp+0xA0]
000077a70fddfa8a  vmovaps xmm11, [rsp+0xB0]
000077a70fddfa93  vmovaps xmm12, [rsp+0xC0]
000077a70fddfa9c  vmovaps xmm14, [rsp+0xD0]
000077a70fddfaa5  vmovaps xmm15, [rsp+0xE0]
000077a70fddfaae  add rsp, 0xF0
000077a70fddfab5  pop r11
000077a70fddfab7  pop r10
000077a70fddfab9  pop r9
000077a70fddfabb  pop r8
000077a70fddfabd  pop rsi
000077a70fddfabe  pop rdi
000077a70fddfabf  pop rdx
000077a70fddfac0  pop rcx
000077a70fddfac1  pop rax
000077a70fddfac2  add rsp, 0x08
000077a70fddfac6  jmp 0x000077A70FDDC458
000077a70fddfacb  sub rsp, 0x08
000077a70fddfacf  push rax
000077a70fddfad0  push rcx
000077a70fddfad1  push rdx
000077a70fddfad2  push rdi
000077a70fddfad3  push rsi
000077a70fddfad4  push r8
000077a70fddfad6  push r9
000077a70fddfad8  push r10
000077a70fddfada  push r11
000077a70fddfadc  sub rsp, 0xF0
000077a70fddfae3  vmovaps [rsp], xmm0
000077a70fddfae8  vmovaps [rsp+0x10], xmm1
000077a70fddfaee  vmovaps [rsp+0x20], xmm2
000077a70fddfaf4  vmovaps [rsp+0x30], xmm3
000077a70fddfafa  vmovaps [rsp+0x40], xmm4
000077a70fddfb00  vmovaps [rsp+0x50], xmm5
000077a70fddfb06  vmovaps [rsp+0x60], xmm6
000077a70fddfb0c  vmovaps [rsp+0x70], xmm7
000077a70fddfb12  vmovaps [rsp+0x80], xmm8
000077a70fddfb1b  vmovaps [rsp+0x90], xmm9
000077a70fddfb24  vmovaps [rsp+0xA0], xmm10
000077a70fddfb2d  vmovaps [rsp+0xB0], xmm11
000077a70fddfb36  vmovaps [rsp+0xC0], xmm12
000077a70fddfb3f  vmovaps [rsp+0xD0], xmm13
000077a70fddfb48  vmovaps [rsp+0xE0], xmm14
000077a70fddfb51  sub rsp, 0x30
000077a70fddfb55  movaps [rsp], xmm15
000077a70fddfb5a  movaps [rsp+0x10], xmm1
000077a70fddfb5f  movaps [rsp+0x20], xmm5
000077a70fddfb64  lea rdi, [rsp]
000077a70fddfb68  mov esi, 0x00
000077a70fddfb6d  mov rax, 0x6294188EF530
000077a70fddfb77  call rax
000077a70fddfb79  movaps xmm15, [rsp]
000077a70fddfb7e  add rsp, 0x30
000077a70fddfb82  vmovaps xmm0, [rsp]
000077a70fddfb87  vmovaps xmm1, [rsp+0x10]
000077a70fddfb8d  vmovaps xmm2, [rsp+0x20]
000077a70fddfb93  vmovaps xmm3, [rsp+0x30]
000077a70fddfb99  vmovaps xmm4, [rsp+0x40]
000077a70fddfb9f  vmovaps xmm5, [rsp+0x50]
000077a70fddfba5  vmovaps xmm6, [rsp+0x60]
000077a70fddfbab  vmovaps xmm7, [rsp+0x70]
000077a70fddfbb1  vmovaps xmm8, [rsp+0x80]
000077a70fddfbba  vmovaps xmm9, [rsp+0x90]
000077a70fddfbc3  vmovaps xmm10, [rsp+0xA0]
000077a70fddfbcc  vmovaps xmm11, [rsp+0xB0]
000077a70fddfbd5  vmovaps xmm12, [rsp+0xC0]
000077a70fddfbde  vmovaps xmm13, [rsp+0xD0]
000077a70fddfbe7  vmovaps xmm14, [rsp+0xE0]
000077a70fddfbf0  add rsp, 0xF0
000077a70fddfbf7  pop r11
000077a70fddfbf9  pop r10
000077a70fddfbfb  pop r9
000077a70fddfbfd  pop r8
000077a70fddfbff  pop rsi
000077a70fddfc00  pop rdi
000077a70fddfc01  pop rdx
000077a70fddfc02  pop rcx
000077a70fddfc03  pop rax
000077a70fddfc04  add rsp, 0x08
000077a70fddfc08  jmp 0x000077A70FDDC473
000077a70fddfc0d  call 0x000077A70FCB52F0
000077a70fddfc12  jmp 0x000077A70FDDC4CE
000077a70fddfc17  sub rsp, 0x08
000077a70fddfc1b  push rax
000077a70fddfc1c  push rcx
000077a70fddfc1d  push rdx
000077a70fddfc1e  push rdi
000077a70fddfc1f  push rsi
000077a70fddfc20  push r8
000077a70fddfc22  push r9
000077a70fddfc24  push r10
000077a70fddfc26  push r11
000077a70fddfc28  sub rsp, 0xF0
000077a70fddfc2f  vmovaps [rsp], xmm0
000077a70fddfc34  vmovaps [rsp+0x10], xmm1
000077a70fddfc3a  vmovaps [rsp+0x20], xmm2
000077a70fddfc40  vmovaps [rsp+0x30], xmm3
000077a70fddfc46  vmovaps [rsp+0x40], xmm4
000077a70fddfc4c  vmovaps [rsp+0x50], xmm5
000077a70fddfc52  vmovaps [rsp+0x60], xmm6
000077a70fddfc58  vmovaps [rsp+0x70], xmm7
000077a70fddfc5e  vmovaps [rsp+0x80], xmm8
000077a70fddfc67  vmovaps [rsp+0x90], xmm10
000077a70fddfc70  vmovaps [rsp+0xA0], xmm11
000077a70fddfc79  vmovaps [rsp+0xB0], xmm12
000077a70fddfc82  vmovaps [rsp+0xC0], xmm13
000077a70fddfc8b  vmovaps [rsp+0xD0], xmm14
000077a70fddfc94  vmovaps [rsp+0xE0], xmm15
000077a70fddfc9d  sub rsp, 0x30
000077a70fddfca1  movaps [rsp], xmm9
000077a70fddfca6  movaps [rsp+0x10], xmm8
000077a70fddfcac  movaps [rsp+0x20], xmm11
000077a70fddfcb2  lea rdi, [rsp]
000077a70fddfcb6  mov esi, 0x00
000077a70fddfcbb  mov rax, 0x6294188EF530
000077a70fddfcc5  call rax
000077a70fddfcc7  movaps xmm9, [rsp]
000077a70fddfccc  add rsp, 0x30
000077a70fddfcd0  vmovaps xmm0, [rsp]
000077a70fddfcd5  vmovaps xmm1, [rsp+0x10]
000077a70fddfcdb  vmovaps xmm2, [rsp+0x20]
000077a70fddfce1  vmovaps xmm3, [rsp+0x30]
000077a70fddfce7  vmovaps xmm4, [rsp+0x40]
000077a70fddfced  vmovaps xmm5, [rsp+0x50]
000077a70fddfcf3  vmovaps xmm6, [rsp+0x60]
000077a70fddfcf9  vmovaps xmm7, [rsp+0x70]
000077a70fddfcff  vmovaps xmm8, [rsp+0x80]
000077a70fddfd08  vmovaps xmm10, [rsp+0x90]
000077a70fddfd11  vmovaps xmm11, [rsp+0xA0]
000077a70fddfd1a  vmovaps xmm12, [rsp+0xB0]
000077a70fddfd23  vmovaps xmm13, [rsp+0xC0]
000077a70fddfd2c  vmovaps xmm14, [rsp+0xD0]
000077a70fddfd35  vmovaps xmm15, [rsp+0xE0]
000077a70fddfd3e  add rsp, 0xF0
000077a70fddfd45  pop r11
000077a70fddfd47  pop r10
000077a70fddfd49  pop r9
000077a70fddfd4b  pop r8
000077a70fddfd4d  pop rsi
000077a70fddfd4e  pop rdi
000077a70fddfd4f  pop rdx
000077a70fddfd50  pop rcx
000077a70fddfd51  pop rax
000077a70fddfd52  add rsp, 0x08
000077a70fddfd56  jmp 0x000077A70FDDC505
000077a70fddfd5b  sub rsp, 0x08
000077a70fddfd5f  push rax
000077a70fddfd60  push rcx
000077a70fddfd61  push rdx
000077a70fddfd62  push rdi
000077a70fddfd63  push rsi
000077a70fddfd64  push r8
000077a70fddfd66  push r9
000077a70fddfd68  push r10
000077a70fddfd6a  push r11
000077a70fddfd6c  sub rsp, 0xF0
000077a70fddfd73  vmovaps [rsp], xmm0
000077a70fddfd78  vmovaps [rsp+0x10], xmm1
000077a70fddfd7e  vmovaps [rsp+0x20], xmm2
000077a70fddfd84  vmovaps [rsp+0x30], xmm3
000077a70fddfd8a  vmovaps [rsp+0x40], xmm4
000077a70fddfd90  vmovaps [rsp+0x50], xmm5
000077a70fddfd96  vmovaps [rsp+0x60], xmm6
000077a70fddfd9c  vmovaps [rsp+0x70], xmm7
000077a70fddfda2  vmovaps [rsp+0x80], xmm8
000077a70fddfdab  vmovaps [rsp+0x90], xmm9
000077a70fddfdb4  vmovaps [rsp+0xA0], xmm10
000077a70fddfdbd  vmovaps [rsp+0xB0], xmm12
000077a70fddfdc6  vmovaps [rsp+0xC0], xmm13
000077a70fddfdcf  vmovaps [rsp+0xD0], xmm14
000077a70fddfdd8  vmovaps [rsp+0xE0], xmm15
000077a70fddfde1  sub rsp, 0x30
000077a70fddfde5  movaps [rsp], xmm11
000077a70fddfdea  movaps [rsp+0x10], xmm10
000077a70fddfdf0  movaps [rsp+0x20], xmm6
000077a70fddfdf5  lea rdi, [rsp]
000077a70fddfdf9  mov esi, 0x00
000077a70fddfdfe  mov rax, 0x6294188EF530
000077a70fddfe08  call rax
000077a70fddfe0a  movaps xmm11, [rsp]
000077a70fddfe0f  add rsp, 0x30
000077a70fddfe13  vmovaps xmm0, [rsp]
000077a70fddfe18  vmovaps xmm1, [rsp+0x10]
000077a70fddfe1e  vmovaps xmm2, [rsp+0x20]
000077a70fddfe24  vmovaps xmm3, [rsp+0x30]
000077a70fddfe2a  vmovaps xmm4, [rsp+0x40]
000077a70fddfe30  vmovaps xmm5, [rsp+0x50]
000077a70fddfe36  vmovaps xmm6, [rsp+0x60]
000077a70fddfe3c  vmovaps xmm7, [rsp+0x70]
000077a70fddfe42  vmovaps xmm8, [rsp+0x80]
000077a70fddfe4b  vmovaps xmm9, [rsp+0x90]
000077a70fddfe54  vmovaps xmm10, [rsp+0xA0]
000077a70fddfe5d  vmovaps xmm12, [rsp+0xB0]
000077a70fddfe66  vmovaps xmm13, [rsp+0xC0]
000077a70fddfe6f  vmovaps xmm14, [rsp+0xD0]
000077a70fddfe78  vmovaps xmm15, [rsp+0xE0]
000077a70fddfe81  add rsp, 0xF0
000077a70fddfe88  pop r11
000077a70fddfe8a  pop r10
000077a70fddfe8c  pop r9
000077a70fddfe8e  pop r8
000077a70fddfe90  pop rsi
000077a70fddfe91  pop rdi
000077a70fddfe92  pop rdx
000077a70fddfe93  pop rcx
000077a70fddfe94  pop rax
000077a70fddfe95  add rsp, 0x08
000077a70fddfe99  jmp 0x000077A70FDDC520
000077a70fddfe9e  sub rsp, 0x08
000077a70fddfea2  push rax
000077a70fddfea3  push rcx
000077a70fddfea4  push rdx
000077a70fddfea5  push rdi
000077a70fddfea6  push rsi
000077a70fddfea7  push r8
000077a70fddfea9  push r9
000077a70fddfeab  push r10
000077a70fddfead  push r11
000077a70fddfeaf  sub rsp, 0xF0
000077a70fddfeb6  vmovaps [rsp], xmm0
000077a70fddfebb  vmovaps [rsp+0x10], xmm1
000077a70fddfec1  vmovaps [rsp+0x20], xmm2
000077a70fddfec7  vmovaps [rsp+0x30], xmm3
000077a70fddfecd  vmovaps [rsp+0x40], xmm4
000077a70fddfed3  vmovaps [rsp+0x50], xmm5
000077a70fddfed9  vmovaps [rsp+0x60], xmm6
000077a70fddfedf  vmovaps [rsp+0x70], xmm7
000077a70fddfee5  vmovaps [rsp+0x80], xmm8
000077a70fddfeee  vmovaps [rsp+0x90], xmm9
000077a70fddfef7  vmovaps [rsp+0xA0], xmm11
000077a70fddff00  vmovaps [rsp+0xB0], xmm12
000077a70fddff09  vmovaps [rsp+0xC0], xmm13
000077a70fddff12  vmovaps [rsp+0xD0], xmm14
000077a70fddff1b  vmovaps [rsp+0xE0], xmm15
000077a70fddff24  sub rsp, 0x30
000077a70fddff28  movaps [rsp], xmm10
000077a70fddff2d  movaps [rsp+0x10], xmm14
000077a70fddff33  movaps [rsp+0x20], xmm4
000077a70fddff38  lea rdi, [rsp]
000077a70fddff3c  mov esi, 0x00
000077a70fddff41  mov rax, 0x6294188EF530
000077a70fddff4b  call rax
000077a70fddff4d  movaps xmm10, [rsp]
000077a70fddff52  add rsp, 0x30
000077a70fddff56  vmovaps xmm0, [rsp]
000077a70fddff5b  vmovaps xmm1, [rsp+0x10]
000077a70fddff61  vmovaps xmm2, [rsp+0x20]
000077a70fddff67  vmovaps xmm3, [rsp+0x30]
000077a70fddff6d  vmovaps xmm4, [rsp+0x40]
000077a70fddff73  vmovaps xmm5, [rsp+0x50]
000077a70fddff79  vmovaps xmm6, [rsp+0x60]
000077a70fddff7f  vmovaps xmm7, [rsp+0x70]
000077a70fddff85  vmovaps xmm8, [rsp+0x80]
000077a70fddff8e  vmovaps xmm9, [rsp+0x90]
000077a70fddff97  vmovaps xmm11, [rsp+0xA0]
000077a70fddffa0  vmovaps xmm12, [rsp+0xB0]
000077a70fddffa9  vmovaps xmm13, [rsp+0xC0]
000077a70fddffb2  vmovaps xmm14, [rsp+0xD0]
000077a70fddffbb  vmovaps xmm15, [rsp+0xE0]
000077a70fddffc4  add rsp, 0xF0
000077a70fddffcb  pop r11
000077a70fddffcd  pop r10
000077a70fddffcf  pop r9
000077a70fddffd1  pop r8
000077a70fddffd3  pop rsi
000077a70fddffd4  pop rdi
000077a70fddffd5  pop rdx
000077a70fddffd6  pop rcx
000077a70fddffd7  pop rax
000077a70fddffd8  add rsp, 0x08
000077a70fddffdc  jmp 0x000077A70FDDC53B
000077a70fddffe1  sub rsp, 0x08
000077a70fddffe5  push rax
000077a70fddffe6  push rcx
000077a70fddffe7  push rdx
000077a70fddffe8  push rdi
000077a70fddffe9  push rsi
000077a70fddffea  push r8
000077a70fddffec  push r9
000077a70fddffee  push r10
000077a70fddfff0  push r11
000077a70fddfff2  sub rsp, 0xF0
000077a70fddfff9  vmovaps [rsp], xmm0
000077a70fddfffe  vmovaps [rsp+0x10], xmm1
000077a70fde0004  vmovaps [rsp+0x20], xmm2
000077a70fde000a  vmovaps [rsp+0x30], xmm3
000077a70fde0010  vmovaps [rsp+0x40], xmm4
000077a70fde0016  vmovaps [rsp+0x50], xmm5
000077a70fde001c  vmovaps [rsp+0x60], xmm6
000077a70fde0022  vmovaps [rsp+0x70], xmm7
000077a70fde0028  vmovaps [rsp+0x80], xmm9
000077a70fde0031  vmovaps [rsp+0x90], xmm10
000077a70fde003a  vmovaps [rsp+0xA0], xmm11
000077a70fde0043  vmovaps [rsp+0xB0], xmm12
000077a70fde004c  vmovaps [rsp+0xC0], xmm13
000077a70fde0055  vmovaps [rsp+0xD0], xmm14
000077a70fde005e  vmovaps [rsp+0xE0], xmm15
000077a70fde0067  sub rsp, 0x30
000077a70fde006b  movaps [rsp], xmm8
000077a70fde0070  movaps [rsp+0x10], xmm1
000077a70fde0075  movaps [rsp+0x20], xmm14
000077a70fde007b  lea rdi, [rsp]
000077a70fde007f  mov esi, 0x00
000077a70fde0084  mov rax, 0x6294188EF530
000077a70fde008e  call rax
000077a70fde0090  movaps xmm8, [rsp]
000077a70fde0095  add rsp, 0x30
000077a70fde0099  vmovaps xmm0, [rsp]
000077a70fde009e  vmovaps xmm1, [rsp+0x10]
000077a70fde00a4  vmovaps xmm2, [rsp+0x20]
000077a70fde00aa  vmovaps xmm3, [rsp+0x30]
000077a70fde00b0  vmovaps xmm4, [rsp+0x40]
000077a70fde00b6  vmovaps xmm5, [rsp+0x50]
000077a70fde00bc  vmovaps xmm6, [rsp+0x60]
000077a70fde00c2  vmovaps xmm7, [rsp+0x70]
000077a70fde00c8  vmovaps xmm9, [rsp+0x80]
000077a70fde00d1  vmovaps xmm10, [rsp+0x90]
000077a70fde00da  vmovaps xmm11, [rsp+0xA0]
000077a70fde00e3  vmovaps xmm12, [rsp+0xB0]
000077a70fde00ec  vmovaps xmm13, [rsp+0xC0]
000077a70fde00f5  vmovaps xmm14, [rsp+0xD0]
000077a70fde00fe  vmovaps xmm15, [rsp+0xE0]
000077a70fde0107  add rsp, 0xF0
000077a70fde010e  pop r11
000077a70fde0110  pop r10
000077a70fde0112  pop r9
000077a70fde0114  pop r8
000077a70fde0116  pop rsi
000077a70fde0117  pop rdi
000077a70fde0118  pop rdx
000077a70fde0119  pop rcx
000077a70fde011a  pop rax
000077a70fde011b  add rsp, 0x08
000077a70fde011f  jmp 0x000077A70FDDC561
000077a70fde0124  sub rsp, 0x08
000077a70fde0128  push rax
000077a70fde0129  push rcx
000077a70fde012a  push rdx
000077a70fde012b  push rdi
000077a70fde012c  push rsi
000077a70fde012d  push r8
000077a70fde012f  push r9
000077a70fde0131  push r10
000077a70fde0133  push r11
000077a70fde0135  sub rsp, 0xF0
000077a70fde013c  vmovaps [rsp], xmm0
000077a70fde0141  vmovaps [rsp+0x10], xmm1
000077a70fde0147  vmovaps [rsp+0x20], xmm2
000077a70fde014d  vmovaps [rsp+0x30], xmm3
000077a70fde0153  vmovaps [rsp+0x40], xmm4
000077a70fde0159  vmovaps [rsp+0x50], xmm5
000077a70fde015f  vmovaps [rsp+0x60], xmm7
000077a70fde0165  vmovaps [rsp+0x70], xmm8
000077a70fde016b  vmovaps [rsp+0x80], xmm9
000077a70fde0174  vmovaps [rsp+0x90], xmm10
000077a70fde017d  vmovaps [rsp+0xA0], xmm11
000077a70fde0186  vmovaps [rsp+0xB0], xmm12
000077a70fde018f  vmovaps [rsp+0xC0], xmm13
000077a70fde0198  vmovaps [rsp+0xD0], xmm14
000077a70fde01a1  vmovaps [rsp+0xE0], xmm15
000077a70fde01aa  sub rsp, 0x30
000077a70fde01ae  movaps [rsp], xmm6
000077a70fde01b2  movaps [rsp+0x10], xmm1
000077a70fde01b7  movaps [rsp+0x20], xmm14
000077a70fde01bd  lea rdi, [rsp]
000077a70fde01c1  mov esi, 0x00
000077a70fde01c6  mov rax, 0x6294188EF530
000077a70fde01d0  call rax
000077a70fde01d2  movaps xmm6, [rsp]
000077a70fde01d6  add rsp, 0x30
000077a70fde01da  vmovaps xmm0, [rsp]
000077a70fde01df  vmovaps xmm1, [rsp+0x10]
000077a70fde01e5  vmovaps xmm2, [rsp+0x20]
000077a70fde01eb  vmovaps xmm3, [rsp+0x30]
000077a70fde01f1  vmovaps xmm4, [rsp+0x40]
000077a70fde01f7  vmovaps xmm5, [rsp+0x50]
000077a70fde01fd  vmovaps xmm7, [rsp+0x60]
000077a70fde0203  vmovaps xmm8, [rsp+0x70]
000077a70fde0209  vmovaps xmm9, [rsp+0x80]
000077a70fde0212  vmovaps xmm10, [rsp+0x90]
000077a70fde021b  vmovaps xmm11, [rsp+0xA0]
000077a70fde0224  vmovaps xmm12, [rsp+0xB0]
000077a70fde022d  vmovaps xmm13, [rsp+0xC0]
000077a70fde0236  vmovaps xmm14, [rsp+0xD0]
000077a70fde023f  vmovaps xmm15, [rsp+0xE0]
000077a70fde0248  add rsp, 0xF0
000077a70fde024f  pop r11
000077a70fde0251  pop r10
000077a70fde0253  pop r9
000077a70fde0255  pop r8
000077a70fde0257  pop rsi
000077a70fde0258  pop rdi
000077a70fde0259  pop rdx
000077a70fde025a  pop rcx
000077a70fde025b  pop rax
000077a70fde025c  add rsp, 0x08
000077a70fde0260  jmp 0x000077A70FDDC58D
000077a70fde0265  sub rsp, 0x08
000077a70fde0269  push rax
000077a70fde026a  push rcx
000077a70fde026b  push rdx
000077a70fde026c  push rdi
000077a70fde026d  push rsi
000077a70fde026e  push r8
000077a70fde0270  push r9
000077a70fde0272  push r10
000077a70fde0274  push r11
000077a70fde0276  sub rsp, 0xF0
000077a70fde027d  vmovaps [rsp], xmm0
000077a70fde0282  vmovaps [rsp+0x10], xmm1
000077a70fde0288  vmovaps [rsp+0x20], xmm2
000077a70fde028e  vmovaps [rsp+0x30], xmm3
000077a70fde0294  vmovaps [rsp+0x40], xmm4
000077a70fde029a  vmovaps [rsp+0x50], xmm5
000077a70fde02a0  vmovaps [rsp+0x60], xmm6
000077a70fde02a6  vmovaps [rsp+0x70], xmm7
000077a70fde02ac  vmovaps [rsp+0x80], xmm8
000077a70fde02b5  vmovaps [rsp+0x90], xmm9
000077a70fde02be  vmovaps [rsp+0xA0], xmm10
000077a70fde02c7  vmovaps [rsp+0xB0], xmm11
000077a70fde02d0  vmovaps [rsp+0xC0], xmm12
000077a70fde02d9  vmovaps [rsp+0xD0], xmm13
000077a70fde02e2  vmovaps [rsp+0xE0], xmm15
000077a70fde02eb  sub rsp, 0x30
000077a70fde02ef  movaps [rsp], xmm14
000077a70fde02f4  movaps [rsp+0x10], xmm12
000077a70fde02fa  movaps [rsp+0x20], xmm1
000077a70fde02ff  lea rdi, [rsp]
000077a70fde0303  mov esi, 0x00
000077a70fde0308  mov rax, 0x6294188EF530
000077a70fde0312  call rax
000077a70fde0314  movaps xmm14, [rsp]
000077a70fde0319  add rsp, 0x30
000077a70fde031d  vmovaps xmm0, [rsp]
000077a70fde0322  vmovaps xmm1, [rsp+0x10]
000077a70fde0328  vmovaps xmm2, [rsp+0x20]
000077a70fde032e  vmovaps xmm3, [rsp+0x30]
000077a70fde0334  vmovaps xmm4, [rsp+0x40]
000077a70fde033a  vmovaps xmm5, [rsp+0x50]
000077a70fde0340  vmovaps xmm6, [rsp+0x60]
000077a70fde0346  vmovaps xmm7, [rsp+0x70]
000077a70fde034c  vmovaps xmm8, [rsp+0x80]
000077a70fde0355  vmovaps xmm9, [rsp+0x90]
000077a70fde035e  vmovaps xmm10, [rsp+0xA0]
000077a70fde0367  vmovaps xmm11, [rsp+0xB0]
000077a70fde0370  vmovaps xmm12, [rsp+0xC0]
000077a70fde0379  vmovaps xmm13, [rsp+0xD0]
000077a70fde0382  vmovaps xmm15, [rsp+0xE0]
000077a70fde038b  add rsp, 0xF0
000077a70fde0392  pop r11
000077a70fde0394  pop r10
000077a70fde0396  pop r9
000077a70fde0398  pop r8
000077a70fde039a  pop rsi
000077a70fde039b  pop rdi
000077a70fde039c  pop rdx
000077a70fde039d  pop rcx
000077a70fde039e  pop rax
000077a70fde039f  add rsp, 0x08
000077a70fde03a3  jmp 0x000077A70FDDC5B3
000077a70fde03a8  sub rsp, 0x08
000077a70fde03ac  push rax
000077a70fde03ad  push rcx
000077a70fde03ae  push rdx
000077a70fde03af  push rdi
000077a70fde03b0  push rsi
000077a70fde03b1  push r8
000077a70fde03b3  push r9
000077a70fde03b5  push r10
000077a70fde03b7  push r11
000077a70fde03b9  sub rsp, 0xF0
000077a70fde03c0  vmovaps [rsp], xmm0
000077a70fde03c5  vmovaps [rsp+0x10], xmm2
000077a70fde03cb  vmovaps [rsp+0x20], xmm3
000077a70fde03d1  vmovaps [rsp+0x30], xmm4
000077a70fde03d7  vmovaps [rsp+0x40], xmm5
000077a70fde03dd  vmovaps [rsp+0x50], xmm6
000077a70fde03e3  vmovaps [rsp+0x60], xmm7
000077a70fde03e9  vmovaps [rsp+0x70], xmm8
000077a70fde03ef  vmovaps [rsp+0x80], xmm9
000077a70fde03f8  vmovaps [rsp+0x90], xmm10
000077a70fde0401  vmovaps [rsp+0xA0], xmm11
000077a70fde040a  vmovaps [rsp+0xB0], xmm12
000077a70fde0413  vmovaps [rsp+0xC0], xmm13
000077a70fde041c  vmovaps [rsp+0xD0], xmm14
000077a70fde0425  vmovaps [rsp+0xE0], xmm15
000077a70fde042e  sub rsp, 0x30
000077a70fde0432  movaps [rsp], xmm1
000077a70fde0436  movaps [rsp+0x10], xmm13
000077a70fde043c  movaps [rsp+0x20], xmm9
000077a70fde0442  lea rdi, [rsp]
000077a70fde0446  mov esi, 0x00
000077a70fde044b  mov rax, 0x6294188EF530
000077a70fde0455  call rax
000077a70fde0457  movaps xmm1, [rsp]
000077a70fde045b  add rsp, 0x30
000077a70fde045f  vmovaps xmm0, [rsp]
000077a70fde0464  vmovaps xmm2, [rsp+0x10]
000077a70fde046a  vmovaps xmm3, [rsp+0x20]
000077a70fde0470  vmovaps xmm4, [rsp+0x30]
000077a70fde0476  vmovaps xmm5, [rsp+0x40]
000077a70fde047c  vmovaps xmm6, [rsp+0x50]
000077a70fde0482  vmovaps xmm7, [rsp+0x60]
000077a70fde0488  vmovaps xmm8, [rsp+0x70]
000077a70fde048e  vmovaps xmm9, [rsp+0x80]
000077a70fde0497  vmovaps xmm10, [rsp+0x90]
000077a70fde04a0  vmovaps xmm11, [rsp+0xA0]
000077a70fde04a9  vmovaps xmm12, [rsp+0xB0]
000077a70fde04b2  vmovaps xmm13, [rsp+0xC0]
000077a70fde04bb  vmovaps xmm14, [rsp+0xD0]
000077a70fde04c4  vmovaps xmm15, [rsp+0xE0]
000077a70fde04cd  add rsp, 0xF0
000077a70fde04d4  pop r11
000077a70fde04d6  pop r10
000077a70fde04d8  pop r9
000077a70fde04da  pop r8
000077a70fde04dc  pop rsi
000077a70fde04dd  pop rdi
000077a70fde04de  pop rdx
000077a70fde04df  pop rcx
000077a70fde04e0  pop rax
000077a70fde04e1  add rsp, 0x08
000077a70fde04e5  jmp 0x000077A70FDDC5CD
000077a70fde04ea  sub rsp, 0x08
000077a70fde04ee  push rax
000077a70fde04ef  push rcx
000077a70fde04f0  push rdx
000077a70fde04f1  push rdi
000077a70fde04f2  push rsi
000077a70fde04f3  push r8
000077a70fde04f5  push r9
000077a70fde04f7  push r10
000077a70fde04f9  push r11
000077a70fde04fb  sub rsp, 0xF0
000077a70fde0502  vmovaps [rsp], xmm0
000077a70fde0507  vmovaps [rsp+0x10], xmm1
000077a70fde050d  vmovaps [rsp+0x20], xmm2
000077a70fde0513  vmovaps [rsp+0x30], xmm3
000077a70fde0519  vmovaps [rsp+0x40], xmm4
000077a70fde051f  vmovaps [rsp+0x50], xmm5
000077a70fde0525  vmovaps [rsp+0x60], xmm6
000077a70fde052b  vmovaps [rsp+0x70], xmm7
000077a70fde0531  vmovaps [rsp+0x80], xmm8
000077a70fde053a  vmovaps [rsp+0x90], xmm9
000077a70fde0543  vmovaps [rsp+0xA0], xmm10
000077a70fde054c  vmovaps [rsp+0xB0], xmm11
000077a70fde0555  vmovaps [rsp+0xC0], xmm13
000077a70fde055e  vmovaps [rsp+0xD0], xmm14
000077a70fde0567  vmovaps [rsp+0xE0], xmm15
000077a70fde0570  sub rsp, 0x30
000077a70fde0574  movaps [rsp], xmm12
000077a70fde0579  movaps [rsp+0x10], xmm7
000077a70fde057e  movaps [rsp+0x20], xmm13
000077a70fde0584  lea rdi, [rsp]
000077a70fde0588  mov esi, 0x00
000077a70fde058d  mov rax, 0x6294188EF530
000077a70fde0597  call rax
000077a70fde0599  movaps xmm12, [rsp]
000077a70fde059e  add rsp, 0x30
000077a70fde05a2  vmovaps xmm0, [rsp]
000077a70fde05a7  vmovaps xmm1, [rsp+0x10]
000077a70fde05ad  vmovaps xmm2, [rsp+0x20]
000077a70fde05b3  vmovaps xmm3, [rsp+0x30]
000077a70fde05b9  vmovaps xmm4, [rsp+0x40]
000077a70fde05bf  vmovaps xmm5, [rsp+0x50]
000077a70fde05c5  vmovaps xmm6, [rsp+0x60]
000077a70fde05cb  vmovaps xmm7, [rsp+0x70]
000077a70fde05d1  vmovaps xmm8, [rsp+0x80]
000077a70fde05da  vmovaps xmm9, [rsp+0x90]
000077a70fde05e3  vmovaps xmm10, [rsp+0xA0]
000077a70fde05ec  vmovaps xmm11, [rsp+0xB0]
000077a70fde05f5  vmovaps xmm13, [rsp+0xC0]
000077a70fde05fe  vmovaps xmm14, [rsp+0xD0]
000077a70fde0607  vmovaps xmm15, [rsp+0xE0]
000077a70fde0610  add rsp, 0xF0
000077a70fde0617  pop r11
000077a70fde0619  pop r10
000077a70fde061b  pop r9
000077a70fde061d  pop r8
000077a70fde061f  pop rsi
000077a70fde0620  pop rdi
000077a70fde0621  pop rdx
000077a70fde0622  pop rcx
000077a70fde0623  pop rax
000077a70fde0624  add rsp, 0x08
000077a70fde0628  jmp 0x000077A70FDDC5F4
000077a70fde062d  sub rsp, 0x08
000077a70fde0631  push rax
000077a70fde0632  push rcx
000077a70fde0633  push rdx
000077a70fde0634  push rdi
000077a70fde0635  push rsi
000077a70fde0636  push r8
000077a70fde0638  push r9
000077a70fde063a  push r10
000077a70fde063c  push r11
000077a70fde063e  sub rsp, 0xF0
000077a70fde0645  vmovaps [rsp], xmm0
000077a70fde064a  vmovaps [rsp+0x10], xmm1
000077a70fde0650  vmovaps [rsp+0x20], xmm2
000077a70fde0656  vmovaps [rsp+0x30], xmm3
000077a70fde065c  vmovaps [rsp+0x40], xmm4
000077a70fde0662  vmovaps [rsp+0x50], xmm5
000077a70fde0668  vmovaps [rsp+0x60], xmm6
000077a70fde066e  vmovaps [rsp+0x70], xmm7
000077a70fde0674  vmovaps [rsp+0x80], xmm8
000077a70fde067d  vmovaps [rsp+0x90], xmm9
000077a70fde0686  vmovaps [rsp+0xA0], xmm10
000077a70fde068f  vmovaps [rsp+0xB0], xmm11
000077a70fde0698  vmovaps [rsp+0xC0], xmm12
000077a70fde06a1  vmovaps [rsp+0xD0], xmm14
000077a70fde06aa  vmovaps [rsp+0xE0], xmm15
000077a70fde06b3  sub rsp, 0x30
000077a70fde06b7  movaps [rsp], xmm13
000077a70fde06bc  movaps [rsp+0x10], xmm15
000077a70fde06c2  movaps [rsp+0x20], xmm8
000077a70fde06c8  lea rdi, [rsp]
000077a70fde06cc  mov esi, 0x00
000077a70fde06d1  mov rax, 0x6294188EF530
000077a70fde06db  call rax
000077a70fde06dd  movaps xmm13, [rsp]
000077a70fde06e2  add rsp, 0x30
000077a70fde06e6  vmovaps xmm0, [rsp]
000077a70fde06eb  vmovaps xmm1, [rsp+0x10]
000077a70fde06f1  vmovaps xmm2, [rsp+0x20]
000077a70fde06f7  vmovaps xmm3, [rsp+0x30]
000077a70fde06fd  vmovaps xmm4, [rsp+0x40]
000077a70fde0703  vmovaps xmm5, [rsp+0x50]
000077a70fde0709  vmovaps xmm6, [rsp+0x60]
000077a70fde070f  vmovaps xmm7, [rsp+0x70]
000077a70fde0715  vmovaps xmm8, [rsp+0x80]
000077a70fde071e  vmovaps xmm9, [rsp+0x90]
000077a70fde0727  vmovaps xmm10, [rsp+0xA0]
000077a70fde0730  vmovaps xmm11, [rsp+0xB0]
000077a70fde0739  vmovaps xmm12, [rsp+0xC0]
000077a70fde0742  vmovaps xmm14, [rsp+0xD0]
000077a70fde074b  vmovaps xmm15, [rsp+0xE0]
000077a70fde0754  add rsp, 0xF0
000077a70fde075b  pop r11
000077a70fde075d  pop r10
000077a70fde075f  pop r9
000077a70fde0761  pop r8
000077a70fde0763  pop rsi
000077a70fde0764  pop rdi
000077a70fde0765  pop rdx
000077a70fde0766  pop rcx
000077a70fde0767  pop rax
000077a70fde0768  add rsp, 0x08
000077a70fde076c  jmp 0x000077A70FDDC60F
000077a70fde0771  sub rsp, 0x08
000077a70fde0775  push rax
000077a70fde0776  push rcx
000077a70fde0777  push rdx
000077a70fde0778  push rdi
000077a70fde0779  push rsi
000077a70fde077a  push r8
000077a70fde077c  push r9
000077a70fde077e  push r10
000077a70fde0780  push r11
000077a70fde0782  sub rsp, 0xF0
000077a70fde0789  vmovaps [rsp], xmm0
000077a70fde078e  vmovaps [rsp+0x10], xmm1
000077a70fde0794  vmovaps [rsp+0x20], xmm2
000077a70fde079a  vmovaps [rsp+0x30], xmm3
000077a70fde07a0  vmovaps [rsp+0x40], xmm4
000077a70fde07a6  vmovaps [rsp+0x50], xmm5
000077a70fde07ac  vmovaps [rsp+0x60], xmm6
000077a70fde07b2  vmovaps [rsp+0x70], xmm7
000077a70fde07b8  vmovaps [rsp+0x80], xmm9
000077a70fde07c1  vmovaps [rsp+0x90], xmm10
000077a70fde07ca  vmovaps [rsp+0xA0], xmm11
000077a70fde07d3  vmovaps [rsp+0xB0], xmm12
000077a70fde07dc  vmovaps [rsp+0xC0], xmm13
000077a70fde07e5  vmovaps [rsp+0xD0], xmm14
000077a70fde07ee  vmovaps [rsp+0xE0], xmm15
000077a70fde07f7  sub rsp, 0x30
000077a70fde07fb  movaps [rsp], xmm8
000077a70fde0800  movaps [rsp+0x10], xmm15
000077a70fde0806  movaps [rsp+0x20], xmm9
000077a70fde080c  lea rdi, [rsp]
000077a70fde0810  mov esi, 0x00
000077a70fde0815  mov rax, 0x6294188EF530
000077a70fde081f  call rax
000077a70fde0821  movaps xmm8, [rsp]
000077a70fde0826  add rsp, 0x30
000077a70fde082a  vmovaps xmm0, [rsp]
000077a70fde082f  vmovaps xmm1, [rsp+0x10]
000077a70fde0835  vmovaps xmm2, [rsp+0x20]
000077a70fde083b  vmovaps xmm3, [rsp+0x30]
000077a70fde0841  vmovaps xmm4, [rsp+0x40]
000077a70fde0847  vmovaps xmm5, [rsp+0x50]
000077a70fde084d  vmovaps xmm6, [rsp+0x60]
000077a70fde0853  vmovaps xmm7, [rsp+0x70]
000077a70fde0859  vmovaps xmm9, [rsp+0x80]
000077a70fde0862  vmovaps xmm10, [rsp+0x90]
000077a70fde086b  vmovaps xmm11, [rsp+0xA0]
000077a70fde0874  vmovaps xmm12, [rsp+0xB0]
000077a70fde087d  vmovaps xmm13, [rsp+0xC0]
000077a70fde0886  vmovaps xmm14, [rsp+0xD0]
000077a70fde088f  vmovaps xmm15, [rsp+0xE0]
000077a70fde0898  add rsp, 0xF0
000077a70fde089f  pop r11
000077a70fde08a1  pop r10
000077a70fde08a3  pop r9
000077a70fde08a5  pop r8
000077a70fde08a7  pop rsi
000077a70fde08a8  pop rdi
000077a70fde08a9  pop rdx
000077a70fde08aa  pop rcx
000077a70fde08ab  pop rax
000077a70fde08ac  add rsp, 0x08
000077a70fde08b0  jmp 0x000077A70FDDC63D
000077a70fde08b5  sub rsp, 0x08
000077a70fde08b9  push rax
000077a70fde08ba  push rcx
000077a70fde08bb  push rdx
000077a70fde08bc  push rdi
000077a70fde08bd  push rsi
000077a70fde08be  push r8
000077a70fde08c0  push r9
000077a70fde08c2  push r10
000077a70fde08c4  push r11
000077a70fde08c6  sub rsp, 0xF0
000077a70fde08cd  vmovaps [rsp], xmm0
000077a70fde08d2  vmovaps [rsp+0x10], xmm1
000077a70fde08d8  vmovaps [rsp+0x20], xmm2
000077a70fde08de  vmovaps [rsp+0x30], xmm3
000077a70fde08e4  vmovaps [rsp+0x40], xmm4
000077a70fde08ea  vmovaps [rsp+0x50], xmm5
000077a70fde08f0  vmovaps [rsp+0x60], xmm6
000077a70fde08f6  vmovaps [rsp+0x70], xmm7
000077a70fde08fc  vmovaps [rsp+0x80], xmm8
000077a70fde0905  vmovaps [rsp+0x90], xmm9
000077a70fde090e  vmovaps [rsp+0xA0], xmm10
000077a70fde0917  vmovaps [rsp+0xB0], xmm11
000077a70fde0920  vmovaps [rsp+0xC0], xmm12
000077a70fde0929  vmovaps [rsp+0xD0], xmm13
000077a70fde0932  vmovaps [rsp+0xE0], xmm14
000077a70fde093b  sub rsp, 0x30
000077a70fde093f  movaps [rsp], xmm15
000077a70fde0944  movaps [rsp+0x10], xmm11
000077a70fde094a  movaps [rsp+0x20], xmm6
000077a70fde094f  lea rdi, [rsp]
000077a70fde0953  mov esi, 0x00
000077a70fde0958  mov rax, 0x6294188EF530
000077a70fde0962  call rax
000077a70fde0964  movaps xmm15, [rsp]
000077a70fde0969  add rsp, 0x30
000077a70fde096d  vmovaps xmm0, [rsp]
000077a70fde0972  vmovaps xmm1, [rsp+0x10]
000077a70fde0978  vmovaps xmm2, [rsp+0x20]
000077a70fde097e  vmovaps xmm3, [rsp+0x30]
000077a70fde0984  vmovaps xmm4, [rsp+0x40]
000077a70fde098a  vmovaps xmm5, [rsp+0x50]
000077a70fde0990  vmovaps xmm6, [rsp+0x60]
000077a70fde0996  vmovaps xmm7, [rsp+0x70]
000077a70fde099c  vmovaps xmm8, [rsp+0x80]
000077a70fde09a5  vmovaps xmm9, [rsp+0x90]
000077a70fde09ae  vmovaps xmm10, [rsp+0xA0]
000077a70fde09b7  vmovaps xmm11, [rsp+0xB0]
000077a70fde09c0  vmovaps xmm12, [rsp+0xC0]
000077a70fde09c9  vmovaps xmm13, [rsp+0xD0]
000077a70fde09d2  vmovaps xmm14, [rsp+0xE0]
000077a70fde09db  add rsp, 0xF0
000077a70fde09e2  pop r11
000077a70fde09e4  pop r10
000077a70fde09e6  pop r9
000077a70fde09e8  pop r8
000077a70fde09ea  pop rsi
000077a70fde09eb  pop rdi
000077a70fde09ec  pop rdx
000077a70fde09ed  pop rcx
000077a70fde09ee  pop rax
000077a70fde09ef  add rsp, 0x08
000077a70fde09f3  jmp 0x000077A70FDDC658
000077a70fde09f8  sub rsp, 0x08
000077a70fde09fc  push rax
000077a70fde09fd  push rcx
000077a70fde09fe  push rdx
000077a70fde09ff  push rdi
000077a70fde0a00  push rsi
000077a70fde0a01  push r8
000077a70fde0a03  push r9
000077a70fde0a05  push r10
000077a70fde0a07  push r11
000077a70fde0a09  sub rsp, 0xF0
000077a70fde0a10  vmovaps [rsp], xmm0
000077a70fde0a15  vmovaps [rsp+0x10], xmm1
000077a70fde0a1b  vmovaps [rsp+0x20], xmm2
000077a70fde0a21  vmovaps [rsp+0x30], xmm3
000077a70fde0a27  vmovaps [rsp+0x40], xmm4
000077a70fde0a2d  vmovaps [rsp+0x50], xmm5
000077a70fde0a33  vmovaps [rsp+0x60], xmm6
000077a70fde0a39  vmovaps [rsp+0x70], xmm8
000077a70fde0a3f  vmovaps [rsp+0x80], xmm9
000077a70fde0a48  vmovaps [rsp+0x90], xmm10
000077a70fde0a51  vmovaps [rsp+0xA0], xmm11
000077a70fde0a5a  vmovaps [rsp+0xB0], xmm12
000077a70fde0a63  vmovaps [rsp+0xC0], xmm13
000077a70fde0a6c  vmovaps [rsp+0xD0], xmm14
000077a70fde0a75  vmovaps [rsp+0xE0], xmm15
000077a70fde0a7e  sub rsp, 0x30
000077a70fde0a82  movaps [rsp], xmm7
000077a70fde0a86  movaps [rsp+0x10], xmm11
000077a70fde0a8c  movaps [rsp+0x20], xmm9
000077a70fde0a92  lea rdi, [rsp]
000077a70fde0a96  mov esi, 0x00
000077a70fde0a9b  mov rax, 0x6294188EF530
000077a70fde0aa5  call rax
000077a70fde0aa7  movaps xmm7, [rsp]
000077a70fde0aab  add rsp, 0x30
000077a70fde0aaf  vmovaps xmm0, [rsp]
000077a70fde0ab4  vmovaps xmm1, [rsp+0x10]
000077a70fde0aba  vmovaps xmm2, [rsp+0x20]
000077a70fde0ac0  vmovaps xmm3, [rsp+0x30]
000077a70fde0ac6  vmovaps xmm4, [rsp+0x40]
000077a70fde0acc  vmovaps xmm5, [rsp+0x50]
000077a70fde0ad2  vmovaps xmm6, [rsp+0x60]
000077a70fde0ad8  vmovaps xmm8, [rsp+0x70]
000077a70fde0ade  vmovaps xmm9, [rsp+0x80]
000077a70fde0ae7  vmovaps xmm10, [rsp+0x90]
000077a70fde0af0  vmovaps xmm11, [rsp+0xA0]
000077a70fde0af9  vmovaps xmm12, [rsp+0xB0]
000077a70fde0b02  vmovaps xmm13, [rsp+0xC0]
000077a70fde0b0b  vmovaps xmm14, [rsp+0xD0]
000077a70fde0b14  vmovaps xmm15, [rsp+0xE0]
000077a70fde0b1d  add rsp, 0xF0
000077a70fde0b24  pop r11
000077a70fde0b26  pop r10
000077a70fde0b28  pop r9
000077a70fde0b2a  pop r8
000077a70fde0b2c  pop rsi
000077a70fde0b2d  pop rdi
000077a70fde0b2e  pop rdx
000077a70fde0b2f  pop rcx
000077a70fde0b30  pop rax
000077a70fde0b31  add rsp, 0x08
000077a70fde0b35  jmp 0x000077A70FDDC685
000077a70fde0b3a  sub rsp, 0x08
000077a70fde0b3e  push rax
000077a70fde0b3f  push rcx
000077a70fde0b40  push rdx
000077a70fde0b41  push rdi
000077a70fde0b42  push rsi
000077a70fde0b43  push r8
000077a70fde0b45  push r9
000077a70fde0b47  push r10
000077a70fde0b49  push r11
000077a70fde0b4b  sub rsp, 0xF0
000077a70fde0b52  vmovaps [rsp], xmm0
000077a70fde0b57  vmovaps [rsp+0x10], xmm1
000077a70fde0b5d  vmovaps [rsp+0x20], xmm2
000077a70fde0b63  vmovaps [rsp+0x30], xmm3
000077a70fde0b69  vmovaps [rsp+0x40], xmm4
000077a70fde0b6f  vmovaps [rsp+0x50], xmm5
000077a70fde0b75  vmovaps [rsp+0x60], xmm6
000077a70fde0b7b  vmovaps [rsp+0x70], xmm7
000077a70fde0b81  vmovaps [rsp+0x80], xmm8
000077a70fde0b8a  vmovaps [rsp+0x90], xmm9
000077a70fde0b93  vmovaps [rsp+0xA0], xmm10
000077a70fde0b9c  vmovaps [rsp+0xB0], xmm12
000077a70fde0ba5  vmovaps [rsp+0xC0], xmm13
000077a70fde0bae  vmovaps [rsp+0xD0], xmm14
000077a70fde0bb7  vmovaps [rsp+0xE0], xmm15
000077a70fde0bc0  sub rsp, 0x30
000077a70fde0bc4  movaps [rsp], xmm11
000077a70fde0bc9  movaps [rsp+0x10], xmm10
000077a70fde0bcf  movaps [rsp+0x20], xmm14
000077a70fde0bd5  lea rdi, [rsp]
000077a70fde0bd9  mov esi, 0x00
000077a70fde0bde  mov rax, 0x6294188EF530
000077a70fde0be8  call rax
000077a70fde0bea  movaps xmm11, [rsp]
000077a70fde0bef  add rsp, 0x30
000077a70fde0bf3  vmovaps xmm0, [rsp]
000077a70fde0bf8  vmovaps xmm1, [rsp+0x10]
000077a70fde0bfe  vmovaps xmm2, [rsp+0x20]
000077a70fde0c04  vmovaps xmm3, [rsp+0x30]
000077a70fde0c0a  vmovaps xmm4, [rsp+0x40]
000077a70fde0c10  vmovaps xmm5, [rsp+0x50]
000077a70fde0c16  vmovaps xmm6, [rsp+0x60]
000077a70fde0c1c  vmovaps xmm7, [rsp+0x70]
000077a70fde0c22  vmovaps xmm8, [rsp+0x80]
000077a70fde0c2b  vmovaps xmm9, [rsp+0x90]
000077a70fde0c34  vmovaps xmm10, [rsp+0xA0]
000077a70fde0c3d  vmovaps xmm12, [rsp+0xB0]
000077a70fde0c46  vmovaps xmm13, [rsp+0xC0]
000077a70fde0c4f  vmovaps xmm14, [rsp+0xD0]
000077a70fde0c58  vmovaps xmm15, [rsp+0xE0]
000077a70fde0c61  add rsp, 0xF0
000077a70fde0c68  pop r11
000077a70fde0c6a  pop r10
000077a70fde0c6c  pop r9
000077a70fde0c6e  pop r8
000077a70fde0c70  pop rsi
000077a70fde0c71  pop rdi
000077a70fde0c72  pop rdx
000077a70fde0c73  pop rcx
000077a70fde0c74  pop rax
000077a70fde0c75  add rsp, 0x08
000077a70fde0c79  jmp 0x000077A70FDDC6A0
000077a70fde0c7e  call 0x000077A70FCC33A0
000077a70fde0c83  jmp 0x000077A70FDDC6AA
000077a70fde0c88  sub rsp, 0x08
000077a70fde0c8c  push rax
000077a70fde0c8d  push rcx
000077a70fde0c8e  push rdx
000077a70fde0c8f  push rdi
000077a70fde0c90  push rsi
000077a70fde0c91  push r8
000077a70fde0c93  push r9
000077a70fde0c95  push r10
000077a70fde0c97  push r11
000077a70fde0c99  sub rsp, 0xF0
000077a70fde0ca0  vmovaps [rsp], xmm0
000077a70fde0ca5  vmovaps [rsp+0x10], xmm1
000077a70fde0cab  vmovaps [rsp+0x20], xmm2
000077a70fde0cb1  vmovaps [rsp+0x30], xmm3
000077a70fde0cb7  vmovaps [rsp+0x40], xmm4
000077a70fde0cbd  vmovaps [rsp+0x50], xmm5
000077a70fde0cc3  vmovaps [rsp+0x60], xmm6
000077a70fde0cc9  vmovaps [rsp+0x70], xmm7
000077a70fde0ccf  vmovaps [rsp+0x80], xmm8
000077a70fde0cd8  vmovaps [rsp+0x90], xmm9
000077a70fde0ce1  vmovaps [rsp+0xA0], xmm11
000077a70fde0cea  vmovaps [rsp+0xB0], xmm12
000077a70fde0cf3  vmovaps [rsp+0xC0], xmm13
000077a70fde0cfc  vmovaps [rsp+0xD0], xmm14
000077a70fde0d05  vmovaps [rsp+0xE0], xmm15
000077a70fde0d0e  sub rsp, 0x30
000077a70fde0d12  movaps [rsp], xmm10
000077a70fde0d17  movaps [rsp+0x10], xmm1
000077a70fde0d1c  movaps [rsp+0x20], xmm12
000077a70fde0d22  lea rdi, [rsp]
000077a70fde0d26  mov esi, 0x00
000077a70fde0d2b  mov rax, 0x6294188EF530
000077a70fde0d35  call rax
000077a70fde0d37  movaps xmm10, [rsp]
000077a70fde0d3c  add rsp, 0x30
000077a70fde0d40  vmovaps xmm0, [rsp]
000077a70fde0d45  vmovaps xmm1, [rsp+0x10]
000077a70fde0d4b  vmovaps xmm2, [rsp+0x20]
000077a70fde0d51  vmovaps xmm3, [rsp+0x30]
000077a70fde0d57  vmovaps xmm4, [rsp+0x40]
000077a70fde0d5d  vmovaps xmm5, [rsp+0x50]
000077a70fde0d63  vmovaps xmm6, [rsp+0x60]
000077a70fde0d69  vmovaps xmm7, [rsp+0x70]
000077a70fde0d6f  vmovaps xmm8, [rsp+0x80]
000077a70fde0d78  vmovaps xmm9, [rsp+0x90]
000077a70fde0d81  vmovaps xmm11, [rsp+0xA0]
000077a70fde0d8a  vmovaps xmm12, [rsp+0xB0]
000077a70fde0d93  vmovaps xmm13, [rsp+0xC0]
000077a70fde0d9c  vmovaps xmm14, [rsp+0xD0]
000077a70fde0da5  vmovaps xmm15, [rsp+0xE0]
000077a70fde0dae  add rsp, 0xF0
000077a70fde0db5  pop r11
000077a70fde0db7  pop r10
000077a70fde0db9  pop r9
000077a70fde0dbb  pop r8
000077a70fde0dbd  pop rsi
000077a70fde0dbe  pop rdi
000077a70fde0dbf  pop rdx
000077a70fde0dc0  pop rcx
000077a70fde0dc1  pop rax
000077a70fde0dc2  add rsp, 0x08
000077a70fde0dc6  jmp 0x000077A70FDDC6CD
000077a70fde0dcb  sub rsp, 0x08
000077a70fde0dcf  push rax
000077a70fde0dd0  push rcx
000077a70fde0dd1  push rdx
000077a70fde0dd2  push rdi
000077a70fde0dd3  push rsi
000077a70fde0dd4  push r8
000077a70fde0dd6  push r9
000077a70fde0dd8  push r10
000077a70fde0dda  push r11
000077a70fde0ddc  sub rsp, 0xF0
000077a70fde0de3  vmovaps [rsp], xmm0
000077a70fde0de8  vmovaps [rsp+0x10], xmm1
000077a70fde0dee  vmovaps [rsp+0x20], xmm2
000077a70fde0df4  vmovaps [rsp+0x30], xmm3
000077a70fde0dfa  vmovaps [rsp+0x40], xmm4
000077a70fde0e00  vmovaps [rsp+0x50], xmm5
000077a70fde0e06  vmovaps [rsp+0x60], xmm6
000077a70fde0e0c  vmovaps [rsp+0x70], xmm7
000077a70fde0e12  vmovaps [rsp+0x80], xmm8
000077a70fde0e1b  vmovaps [rsp+0x90], xmm9
000077a70fde0e24  vmovaps [rsp+0xA0], xmm10
000077a70fde0e2d  vmovaps [rsp+0xB0], xmm11
000077a70fde0e36  vmovaps [rsp+0xC0], xmm13
000077a70fde0e3f  vmovaps [rsp+0xD0], xmm14
000077a70fde0e48  vmovaps [rsp+0xE0], xmm15
000077a70fde0e51  sub rsp, 0x30
000077a70fde0e55  movaps [rsp], xmm12
000077a70fde0e5a  movaps [rsp+0x10], xmm14
000077a70fde0e60  movaps [rsp+0x20], xmm1
000077a70fde0e65  lea rdi, [rsp]
000077a70fde0e69  mov esi, 0x00
000077a70fde0e6e  mov rax, 0x6294188EF530
000077a70fde0e78  call rax
000077a70fde0e7a  movaps xmm12, [rsp]
000077a70fde0e7f  add rsp, 0x30
000077a70fde0e83  vmovaps xmm0, [rsp]
000077a70fde0e88  vmovaps xmm1, [rsp+0x10]
000077a70fde0e8e  vmovaps xmm2, [rsp+0x20]
000077a70fde0e94  vmovaps xmm3, [rsp+0x30]
000077a70fde0e9a  vmovaps xmm4, [rsp+0x40]
000077a70fde0ea0  vmovaps xmm5, [rsp+0x50]
000077a70fde0ea6  vmovaps xmm6, [rsp+0x60]
000077a70fde0eac  vmovaps xmm7, [rsp+0x70]
000077a70fde0eb2  vmovaps xmm8, [rsp+0x80]
000077a70fde0ebb  vmovaps xmm9, [rsp+0x90]
000077a70fde0ec4  vmovaps xmm10, [rsp+0xA0]
000077a70fde0ecd  vmovaps xmm11, [rsp+0xB0]
000077a70fde0ed6  vmovaps xmm13, [rsp+0xC0]
000077a70fde0edf  vmovaps xmm14, [rsp+0xD0]
000077a70fde0ee8  vmovaps xmm15, [rsp+0xE0]
000077a70fde0ef1  add rsp, 0xF0
000077a70fde0ef8  pop r11
000077a70fde0efa  pop r10
000077a70fde0efc  pop r9
000077a70fde0efe  pop r8
000077a70fde0f00  pop rsi
000077a70fde0f01  pop rdi
000077a70fde0f02  pop rdx
000077a70fde0f03  pop rcx
000077a70fde0f04  pop rax
000077a70fde0f05  add rsp, 0x08
000077a70fde0f09  jmp 0x000077A70FDDC6FC
000077a70fde0f0e  sub rsp, 0x08
000077a70fde0f12  push rax
000077a70fde0f13  push rcx
000077a70fde0f14  push rdx
000077a70fde0f15  push rdi
000077a70fde0f16  push rsi
000077a70fde0f17  push r8
000077a70fde0f19  push r9
000077a70fde0f1b  push r10
000077a70fde0f1d  push r11
000077a70fde0f1f  sub rsp, 0xF0
000077a70fde0f26  vmovaps [rsp], xmm0
000077a70fde0f2b  vmovaps [rsp+0x10], xmm1
000077a70fde0f31  vmovaps [rsp+0x20], xmm2
000077a70fde0f37  vmovaps [rsp+0x30], xmm3
000077a70fde0f3d  vmovaps [rsp+0x40], xmm4
000077a70fde0f43  vmovaps [rsp+0x50], xmm5
000077a70fde0f49  vmovaps [rsp+0x60], xmm6
000077a70fde0f4f  vmovaps [rsp+0x70], xmm7
000077a70fde0f55  vmovaps [rsp+0x80], xmm8
000077a70fde0f5e  vmovaps [rsp+0x90], xmm9
000077a70fde0f67  vmovaps [rsp+0xA0], xmm10
000077a70fde0f70  vmovaps [rsp+0xB0], xmm11
000077a70fde0f79  vmovaps [rsp+0xC0], xmm12
000077a70fde0f82  vmovaps [rsp+0xD0], xmm13
000077a70fde0f8b  vmovaps [rsp+0xE0], xmm15
000077a70fde0f94  sub rsp, 0x30
000077a70fde0f98  movaps [rsp], xmm14
000077a70fde0f9d  movaps [rsp+0x10], xmm9
000077a70fde0fa3  movaps [rsp+0x20], xmm1
000077a70fde0fa8  lea rdi, [rsp]
000077a70fde0fac  mov esi, 0x00
000077a70fde0fb1  mov rax, 0x6294188EF530
000077a70fde0fbb  call rax
000077a70fde0fbd  movaps xmm14, [rsp]
000077a70fde0fc2  add rsp, 0x30
000077a70fde0fc6  vmovaps xmm0, [rsp]
000077a70fde0fcb  vmovaps xmm1, [rsp+0x10]
000077a70fde0fd1  vmovaps xmm2, [rsp+0x20]
000077a70fde0fd7  vmovaps xmm3, [rsp+0x30]
000077a70fde0fdd  vmovaps xmm4, [rsp+0x40]
000077a70fde0fe3  vmovaps xmm5, [rsp+0x50]
000077a70fde0fe9  vmovaps xmm6, [rsp+0x60]
000077a70fde0fef  vmovaps xmm7, [rsp+0x70]
000077a70fde0ff5  vmovaps xmm8, [rsp+0x80]
000077a70fde0ffe  vmovaps xmm9, [rsp+0x90]
000077a70fde1007  vmovaps xmm10, [rsp+0xA0]
000077a70fde1010  vmovaps xmm11, [rsp+0xB0]
000077a70fde1019  vmovaps xmm12, [rsp+0xC0]
000077a70fde1022  vmovaps xmm13, [rsp+0xD0]
000077a70fde102b  vmovaps xmm15, [rsp+0xE0]
000077a70fde1034  add rsp, 0xF0
000077a70fde103b  pop r11
000077a70fde103d  pop r10
000077a70fde103f  pop r9
000077a70fde1041  pop r8
000077a70fde1043  pop rsi
000077a70fde1044  pop rdi
000077a70fde1045  pop rdx
000077a70fde1046  pop rcx
000077a70fde1047  pop rax
000077a70fde1048  add rsp, 0x08
000077a70fde104c  jmp 0x000077A70FDDC72B
000077a70fde1051  sub rsp, 0x08
000077a70fde1055  push rax
000077a70fde1056  push rcx
000077a70fde1057  push rdx
000077a70fde1058  push rdi
000077a70fde1059  push rsi
000077a70fde105a  push r8
000077a70fde105c  push r9
000077a70fde105e  push r10
000077a70fde1060  push r11
000077a70fde1062  sub rsp, 0xF0
000077a70fde1069  vmovaps [rsp], xmm0
000077a70fde106e  vmovaps [rsp+0x10], xmm2
000077a70fde1074  vmovaps [rsp+0x20], xmm3
000077a70fde107a  vmovaps [rsp+0x30], xmm4
000077a70fde1080  vmovaps [rsp+0x40], xmm5
000077a70fde1086  vmovaps [rsp+0x50], xmm6
000077a70fde108c  vmovaps [rsp+0x60], xmm7
000077a70fde1092  vmovaps [rsp+0x70], xmm8
000077a70fde1098  vmovaps [rsp+0x80], xmm9
000077a70fde10a1  vmovaps [rsp+0x90], xmm10
000077a70fde10aa  vmovaps [rsp+0xA0], xmm11
000077a70fde10b3  vmovaps [rsp+0xB0], xmm12
000077a70fde10bc  vmovaps [rsp+0xC0], xmm13
000077a70fde10c5  vmovaps [rsp+0xD0], xmm14
000077a70fde10ce  vmovaps [rsp+0xE0], xmm15
000077a70fde10d7  sub rsp, 0x30
000077a70fde10db  movaps [rsp], xmm1
000077a70fde10df  movaps [rsp+0x10], xmm13
000077a70fde10e5  movaps [rsp+0x20], xmm8
000077a70fde10eb  lea rdi, [rsp]
000077a70fde10ef  mov esi, 0x00
000077a70fde10f4  mov rax, 0x6294188EF530
000077a70fde10fe  call rax
000077a70fde1100  movaps xmm1, [rsp]
000077a70fde1104  add rsp, 0x30
000077a70fde1108  vmovaps xmm0, [rsp]
000077a70fde110d  vmovaps xmm2, [rsp+0x10]
000077a70fde1113  vmovaps xmm3, [rsp+0x20]
000077a70fde1119  vmovaps xmm4, [rsp+0x30]
000077a70fde111f  vmovaps xmm5, [rsp+0x40]
000077a70fde1125  vmovaps xmm6, [rsp+0x50]
000077a70fde112b  vmovaps xmm7, [rsp+0x60]
000077a70fde1131  vmovaps xmm8, [rsp+0x70]
000077a70fde1137  vmovaps xmm9, [rsp+0x80]
000077a70fde1140  vmovaps xmm10, [rsp+0x90]
000077a70fde1149  vmovaps xmm11, [rsp+0xA0]
000077a70fde1152  vmovaps xmm12, [rsp+0xB0]
000077a70fde115b  vmovaps xmm13, [rsp+0xC0]
000077a70fde1164  vmovaps xmm14, [rsp+0xD0]
000077a70fde116d  vmovaps xmm15, [rsp+0xE0]
000077a70fde1176  add rsp, 0xF0
000077a70fde117d  pop r11
000077a70fde117f  pop r10
000077a70fde1181  pop r9
000077a70fde1183  pop r8
000077a70fde1185  pop rsi
000077a70fde1186  pop rdi
000077a70fde1187  pop rdx
000077a70fde1188  pop rcx
000077a70fde1189  pop rax
000077a70fde118a  add rsp, 0x08
000077a70fde118e  jmp 0x000077A70FDDC74D
000077a70fde1193  call 0x000077A70FC0C260
000077a70fde1198  jmp 0x000077A70FDDC75B
000077a70fde119d  call 0x000077A70FCBD750
000077a70fde11a2  jmp 0x000077A70FDDC765
000077a70fde11a7  sub rsp, 0x08
000077a70fde11ab  push rax
000077a70fde11ac  push rcx
000077a70fde11ad  push rdx
000077a70fde11ae  push rdi
000077a70fde11af  push rsi
000077a70fde11b0  push r8
000077a70fde11b2  push r9
000077a70fde11b4  push r10
000077a70fde11b6  push r11
000077a70fde11b8  sub rsp, 0xF0
000077a70fde11bf  vmovaps [rsp], xmm0
000077a70fde11c4  vmovaps [rsp+0x10], xmm1
000077a70fde11ca  vmovaps [rsp+0x20], xmm2
000077a70fde11d0  vmovaps [rsp+0x30], xmm3
000077a70fde11d6  vmovaps [rsp+0x40], xmm4
000077a70fde11dc  vmovaps [rsp+0x50], xmm5
000077a70fde11e2  vmovaps [rsp+0x60], xmm6
000077a70fde11e8  vmovaps [rsp+0x70], xmm7
000077a70fde11ee  vmovaps [rsp+0x80], xmm9
000077a70fde11f7  vmovaps [rsp+0x90], xmm10
000077a70fde1200  vmovaps [rsp+0xA0], xmm11
000077a70fde1209  vmovaps [rsp+0xB0], xmm12
000077a70fde1212  vmovaps [rsp+0xC0], xmm13
000077a70fde121b  vmovaps [rsp+0xD0], xmm14
000077a70fde1224  vmovaps [rsp+0xE0], xmm15
000077a70fde122d  sub rsp, 0x30
000077a70fde1231  movaps [rsp], xmm8
000077a70fde1236  movaps [rsp+0x10], xmm15
000077a70fde123c  movaps [rsp+0x20], xmm7
000077a70fde1241  lea rdi, [rsp]
000077a70fde1245  mov esi, 0x00
000077a70fde124a  mov rax, 0x6294188EF530
000077a70fde1254  call rax
000077a70fde1256  movaps xmm8, [rsp]
000077a70fde125b  add rsp, 0x30
000077a70fde125f  vmovaps xmm0, [rsp]
000077a70fde1264  vmovaps xmm1, [rsp+0x10]
000077a70fde126a  vmovaps xmm2, [rsp+0x20]
000077a70fde1270  vmovaps xmm3, [rsp+0x30]
000077a70fde1276  vmovaps xmm4, [rsp+0x40]
000077a70fde127c  vmovaps xmm5, [rsp+0x50]
000077a70fde1282  vmovaps xmm6, [rsp+0x60]
000077a70fde1288  vmovaps xmm7, [rsp+0x70]
000077a70fde128e  vmovaps xmm9, [rsp+0x80]
000077a70fde1297  vmovaps xmm10, [rsp+0x90]
000077a70fde12a0  vmovaps xmm11, [rsp+0xA0]
000077a70fde12a9  vmovaps xmm12, [rsp+0xB0]
000077a70fde12b2  vmovaps xmm13, [rsp+0xC0]
000077a70fde12bb  vmovaps xmm14, [rsp+0xD0]
000077a70fde12c4  vmovaps xmm15, [rsp+0xE0]
000077a70fde12cd  add rsp, 0xF0
000077a70fde12d4  pop r11
000077a70fde12d6  pop r10
000077a70fde12d8  pop r9
000077a70fde12da  pop r8
000077a70fde12dc  pop rsi
000077a70fde12dd  pop rdi
000077a70fde12de  pop rdx
000077a70fde12df  pop rcx
000077a70fde12e0  pop rax
000077a70fde12e1  add rsp, 0x08
000077a70fde12e5  jmp 0x000077A70FDDC787
000077a70fde12ea  sub rsp, 0x08
000077a70fde12ee  push rax
000077a70fde12ef  push rcx
000077a70fde12f0  push rdx
000077a70fde12f1  push rdi
000077a70fde12f2  push rsi
000077a70fde12f3  push r8
000077a70fde12f5  push r9
000077a70fde12f7  push r10
000077a70fde12f9  push r11
000077a70fde12fb  sub rsp, 0xF0
000077a70fde1302  vmovaps [rsp], xmm0
000077a70fde1307  vmovaps [rsp+0x10], xmm1
000077a70fde130d  vmovaps [rsp+0x20], xmm2
000077a70fde1313  vmovaps [rsp+0x30], xmm3
000077a70fde1319  vmovaps [rsp+0x40], xmm4
000077a70fde131f  vmovaps [rsp+0x50], xmm5
000077a70fde1325  vmovaps [rsp+0x60], xmm6
000077a70fde132b  vmovaps [rsp+0x70], xmm8
000077a70fde1331  vmovaps [rsp+0x80], xmm9
000077a70fde133a  vmovaps [rsp+0x90], xmm10
000077a70fde1343  vmovaps [rsp+0xA0], xmm11
000077a70fde134c  vmovaps [rsp+0xB0], xmm12
000077a70fde1355  vmovaps [rsp+0xC0], xmm13
000077a70fde135e  vmovaps [rsp+0xD0], xmm14
000077a70fde1367  vmovaps [rsp+0xE0], xmm15
000077a70fde1370  sub rsp, 0x30
000077a70fde1374  movaps [rsp], xmm7
000077a70fde1378  movaps [rsp+0x10], xmm9
000077a70fde137e  movaps [rsp+0x20], xmm15
000077a70fde1384  lea rdi, [rsp]
000077a70fde1388  mov esi, 0x00
000077a70fde138d  mov rax, 0x6294188EF530
000077a70fde1397  call rax
000077a70fde1399  movaps xmm7, [rsp]
000077a70fde139d  add rsp, 0x30
000077a70fde13a1  vmovaps xmm0, [rsp]
000077a70fde13a6  vmovaps xmm1, [rsp+0x10]
000077a70fde13ac  vmovaps xmm2, [rsp+0x20]
000077a70fde13b2  vmovaps xmm3, [rsp+0x30]
000077a70fde13b8  vmovaps xmm4, [rsp+0x40]
000077a70fde13be  vmovaps xmm5, [rsp+0x50]
000077a70fde13c4  vmovaps xmm6, [rsp+0x60]
000077a70fde13ca  vmovaps xmm8, [rsp+0x70]
000077a70fde13d0  vmovaps xmm9, [rsp+0x80]
000077a70fde13d9  vmovaps xmm10, [rsp+0x90]
000077a70fde13e2  vmovaps xmm11, [rsp+0xA0]
000077a70fde13eb  vmovaps xmm12, [rsp+0xB0]
000077a70fde13f4  vmovaps xmm13, [rsp+0xC0]
000077a70fde13fd  vmovaps xmm14, [rsp+0xD0]
000077a70fde1406  vmovaps xmm15, [rsp+0xE0]
000077a70fde140f  add rsp, 0xF0
000077a70fde1416  pop r11
000077a70fde1418  pop r10
000077a70fde141a  pop r9
000077a70fde141c  pop r8
000077a70fde141e  pop rsi
000077a70fde141f  pop rdi
000077a70fde1420  pop rdx
000077a70fde1421  pop rcx
000077a70fde1422  pop rax
000077a70fde1423  add rsp, 0x08
000077a70fde1427  jmp 0x000077A70FDDC7B4
000077a70fde142c  sub rsp, 0x08
000077a70fde1430  push rax
000077a70fde1431  push rcx
000077a70fde1432  push rdx
000077a70fde1433  push rdi
000077a70fde1434  push rsi
000077a70fde1435  push r8
000077a70fde1437  push r9
000077a70fde1439  push r10
000077a70fde143b  push r11
000077a70fde143d  sub rsp, 0xF0
000077a70fde1444  vmovaps [rsp], xmm0
000077a70fde1449  vmovaps [rsp+0x10], xmm1
000077a70fde144f  vmovaps [rsp+0x20], xmm2
000077a70fde1455  vmovaps [rsp+0x30], xmm3
000077a70fde145b  vmovaps [rsp+0x40], xmm4
000077a70fde1461  vmovaps [rsp+0x50], xmm5
000077a70fde1467  vmovaps [rsp+0x60], xmm6
000077a70fde146d  vmovaps [rsp+0x70], xmm7
000077a70fde1473  vmovaps [rsp+0x80], xmm8
000077a70fde147c  vmovaps [rsp+0x90], xmm10
000077a70fde1485  vmovaps [rsp+0xA0], xmm11
000077a70fde148e  vmovaps [rsp+0xB0], xmm12
000077a70fde1497  vmovaps [rsp+0xC0], xmm13
000077a70fde14a0  vmovaps [rsp+0xD0], xmm14
000077a70fde14a9  vmovaps [rsp+0xE0], xmm15
000077a70fde14b2  sub rsp, 0x30
000077a70fde14b6  movaps [rsp], xmm9
000077a70fde14bb  movaps [rsp+0x10], xmm13
000077a70fde14c1  movaps [rsp+0x20], xmm15
000077a70fde14c7  lea rdi, [rsp]
000077a70fde14cb  mov esi, 0x00
000077a70fde14d0  mov rax, 0x6294188EF530
000077a70fde14da  call rax
000077a70fde14dc  movaps xmm9, [rsp]
000077a70fde14e1  add rsp, 0x30
000077a70fde14e5  vmovaps xmm0, [rsp]
000077a70fde14ea  vmovaps xmm1, [rsp+0x10]
000077a70fde14f0  vmovaps xmm2, [rsp+0x20]
000077a70fde14f6  vmovaps xmm3, [rsp+0x30]
000077a70fde14fc  vmovaps xmm4, [rsp+0x40]
000077a70fde1502  vmovaps xmm5, [rsp+0x50]
000077a70fde1508  vmovaps xmm6, [rsp+0x60]
000077a70fde150e  vmovaps xmm7, [rsp+0x70]
000077a70fde1514  vmovaps xmm8, [rsp+0x80]
000077a70fde151d  vmovaps xmm10, [rsp+0x90]
000077a70fde1526  vmovaps xmm11, [rsp+0xA0]
000077a70fde152f  vmovaps xmm12, [rsp+0xB0]
000077a70fde1538  vmovaps xmm13, [rsp+0xC0]
000077a70fde1541  vmovaps xmm14, [rsp+0xD0]
000077a70fde154a  vmovaps xmm15, [rsp+0xE0]
000077a70fde1553  add rsp, 0xF0
000077a70fde155a  pop r11
000077a70fde155c  pop r10
000077a70fde155e  pop r9
000077a70fde1560  pop r8
000077a70fde1562  pop rsi
000077a70fde1563  pop rdi
000077a70fde1564  pop rdx
000077a70fde1565  pop rcx
000077a70fde1566  pop rax
000077a70fde1567  add rsp, 0x08
000077a70fde156b  jmp 0x000077A70FDDC7E2
000077a70fde1570  sub rsp, 0x08
000077a70fde1574  push rax
000077a70fde1575  push rcx
000077a70fde1576  push rdx
000077a70fde1577  push rdi
000077a70fde1578  push rsi
000077a70fde1579  push r8
000077a70fde157b  push r9
000077a70fde157d  push r10
000077a70fde157f  push r11
000077a70fde1581  sub rsp, 0xF0
000077a70fde1588  vmovaps [rsp], xmm0
000077a70fde158d  vmovaps [rsp+0x10], xmm1
000077a70fde1593  vmovaps [rsp+0x20], xmm2
000077a70fde1599  vmovaps [rsp+0x30], xmm3
000077a70fde159f  vmovaps [rsp+0x40], xmm4
000077a70fde15a5  vmovaps [rsp+0x50], xmm5
000077a70fde15ab  vmovaps [rsp+0x60], xmm6
000077a70fde15b1  vmovaps [rsp+0x70], xmm7
000077a70fde15b7  vmovaps [rsp+0x80], xmm8
000077a70fde15c0  vmovaps [rsp+0x90], xmm9
000077a70fde15c9  vmovaps [rsp+0xA0], xmm10
000077a70fde15d2  vmovaps [rsp+0xB0], xmm11
000077a70fde15db  vmovaps [rsp+0xC0], xmm12
000077a70fde15e4  vmovaps [rsp+0xD0], xmm13
000077a70fde15ed  vmovaps [rsp+0xE0], xmm14
000077a70fde15f6  sub rsp, 0x30
000077a70fde15fa  movaps [rsp], xmm15
000077a70fde15ff  movaps [rsp+0x10], xmm11
000077a70fde1605  movaps [rsp+0x20], xmm12
000077a70fde160b  lea rdi, [rsp]
000077a70fde160f  mov esi, 0x00
000077a70fde1614  mov rax, 0x6294188EF530
000077a70fde161e  call rax
000077a70fde1620  movaps xmm15, [rsp]
000077a70fde1625  add rsp, 0x30
000077a70fde1629  vmovaps xmm0, [rsp]
000077a70fde162e  vmovaps xmm1, [rsp+0x10]
000077a70fde1634  vmovaps xmm2, [rsp+0x20]
000077a70fde163a  vmovaps xmm3, [rsp+0x30]
000077a70fde1640  vmovaps xmm4, [rsp+0x40]
000077a70fde1646  vmovaps xmm5, [rsp+0x50]
000077a70fde164c  vmovaps xmm6, [rsp+0x60]
000077a70fde1652  vmovaps xmm7, [rsp+0x70]
000077a70fde1658  vmovaps xmm8, [rsp+0x80]
000077a70fde1661  vmovaps xmm9, [rsp+0x90]
000077a70fde166a  vmovaps xmm10, [rsp+0xA0]
000077a70fde1673  vmovaps xmm11, [rsp+0xB0]
000077a70fde167c  vmovaps xmm12, [rsp+0xC0]
000077a70fde1685  vmovaps xmm13, [rsp+0xD0]
000077a70fde168e  vmovaps xmm14, [rsp+0xE0]
000077a70fde1697  add rsp, 0xF0
000077a70fde169e  pop r11
000077a70fde16a0  pop r10
000077a70fde16a2  pop r9
000077a70fde16a4  pop r8
000077a70fde16a6  pop rsi
000077a70fde16a7  pop rdi
000077a70fde16a8  pop rdx
000077a70fde16a9  pop rcx
000077a70fde16aa  pop rax
000077a70fde16ab  add rsp, 0x08
000077a70fde16af  jmp 0x000077A70FDDC7FD
000077a70fde16b4  sub rsp, 0x08
000077a70fde16b8  push rax
000077a70fde16b9  push rcx
000077a70fde16ba  push rdx
000077a70fde16bb  push rdi
000077a70fde16bc  push rsi
000077a70fde16bd  push r8
000077a70fde16bf  push r9
000077a70fde16c1  push r10
000077a70fde16c3  push r11
000077a70fde16c5  sub rsp, 0xF0
000077a70fde16cc  vmovaps [rsp], xmm0
000077a70fde16d1  vmovaps [rsp+0x10], xmm1
000077a70fde16d7  vmovaps [rsp+0x20], xmm2
000077a70fde16dd  vmovaps [rsp+0x30], xmm3
000077a70fde16e3  vmovaps [rsp+0x40], xmm4
000077a70fde16e9  vmovaps [rsp+0x50], xmm5
000077a70fde16ef  vmovaps [rsp+0x60], xmm6
000077a70fde16f5  vmovaps [rsp+0x70], xmm7
000077a70fde16fb  vmovaps [rsp+0x80], xmm8
000077a70fde1704  vmovaps [rsp+0x90], xmm9
000077a70fde170d  vmovaps [rsp+0xA0], xmm10
000077a70fde1716  vmovaps [rsp+0xB0], xmm11
000077a70fde171f  vmovaps [rsp+0xC0], xmm12
000077a70fde1728  vmovaps [rsp+0xD0], xmm14
000077a70fde1731  vmovaps [rsp+0xE0], xmm15
000077a70fde173a  sub rsp, 0x30
000077a70fde173e  movaps [rsp], xmm13
000077a70fde1743  movaps [rsp+0x10], xmm10
000077a70fde1749  movaps [rsp+0x20], xmm14
000077a70fde174f  lea rdi, [rsp]
000077a70fde1753  mov esi, 0x00
000077a70fde1758  mov rax, 0x6294188EF530
000077a70fde1762  call rax
000077a70fde1764  movaps xmm13, [rsp]
000077a70fde1769  add rsp, 0x30
000077a70fde176d  vmovaps xmm0, [rsp]
000077a70fde1772  vmovaps xmm1, [rsp+0x10]
000077a70fde1778  vmovaps xmm2, [rsp+0x20]
000077a70fde177e  vmovaps xmm3, [rsp+0x30]
000077a70fde1784  vmovaps xmm4, [rsp+0x40]
000077a70fde178a  vmovaps xmm5, [rsp+0x50]
000077a70fde1790  vmovaps xmm6, [rsp+0x60]
000077a70fde1796  vmovaps xmm7, [rsp+0x70]
000077a70fde179c  vmovaps xmm8, [rsp+0x80]
000077a70fde17a5  vmovaps xmm9, [rsp+0x90]
000077a70fde17ae  vmovaps xmm10, [rsp+0xA0]
000077a70fde17b7  vmovaps xmm11, [rsp+0xB0]
000077a70fde17c0  vmovaps xmm12, [rsp+0xC0]
000077a70fde17c9  vmovaps xmm14, [rsp+0xD0]
000077a70fde17d2  vmovaps xmm15, [rsp+0xE0]
000077a70fde17db  add rsp, 0xF0
000077a70fde17e2  pop r11
000077a70fde17e4  pop r10
000077a70fde17e6  pop r9
000077a70fde17e8  pop r8
000077a70fde17ea  pop rsi
000077a70fde17eb  pop rdi
000077a70fde17ec  pop rdx
000077a70fde17ed  pop rcx
000077a70fde17ee  pop rax
000077a70fde17ef  add rsp, 0x08
000077a70fde17f3  jmp 0x000077A70FDDC820
000077a70fde17f8  sub rsp, 0x08
000077a70fde17fc  push rax
000077a70fde17fd  push rcx
000077a70fde17fe  push rdx
000077a70fde17ff  push rdi
000077a70fde1800  push rsi
000077a70fde1801  push r8
000077a70fde1803  push r9
000077a70fde1805  push r10
000077a70fde1807  push r11
000077a70fde1809  sub rsp, 0xF0
000077a70fde1810  vmovaps [rsp], xmm0
000077a70fde1815  vmovaps [rsp+0x10], xmm1
000077a70fde181b  vmovaps [rsp+0x20], xmm2
000077a70fde1821  vmovaps [rsp+0x30], xmm3
000077a70fde1827  vmovaps [rsp+0x40], xmm4
000077a70fde182d  vmovaps [rsp+0x50], xmm5
000077a70fde1833  vmovaps [rsp+0x60], xmm6
000077a70fde1839  vmovaps [rsp+0x70], xmm7
000077a70fde183f  vmovaps [rsp+0x80], xmm8
000077a70fde1848  vmovaps [rsp+0x90], xmm9
000077a70fde1851  vmovaps [rsp+0xA0], xmm10
000077a70fde185a  vmovaps [rsp+0xB0], xmm11
000077a70fde1863  vmovaps [rsp+0xC0], xmm12
000077a70fde186c  vmovaps [rsp+0xD0], xmm13
000077a70fde1875  vmovaps [rsp+0xE0], xmm15
000077a70fde187e  sub rsp, 0x30
000077a70fde1882  movaps [rsp], xmm14
000077a70fde1887  movaps [rsp+0x10], xmm1
000077a70fde188c  movaps [rsp+0x20], xmm7
000077a70fde1891  lea rdi, [rsp]
000077a70fde1895  mov esi, 0x00
000077a70fde189a  mov rax, 0x6294188EF530
000077a70fde18a4  call rax
000077a70fde18a6  movaps xmm14, [rsp]
000077a70fde18ab  add rsp, 0x30
000077a70fde18af  vmovaps xmm0, [rsp]
000077a70fde18b4  vmovaps xmm1, [rsp+0x10]
000077a70fde18ba  vmovaps xmm2, [rsp+0x20]
000077a70fde18c0  vmovaps xmm3, [rsp+0x30]
000077a70fde18c6  vmovaps xmm4, [rsp+0x40]
000077a70fde18cc  vmovaps xmm5, [rsp+0x50]
000077a70fde18d2  vmovaps xmm6, [rsp+0x60]
000077a70fde18d8  vmovaps xmm7, [rsp+0x70]
000077a70fde18de  vmovaps xmm8, [rsp+0x80]
000077a70fde18e7  vmovaps xmm9, [rsp+0x90]
000077a70fde18f0  vmovaps xmm10, [rsp+0xA0]
000077a70fde18f9  vmovaps xmm11, [rsp+0xB0]
000077a70fde1902  vmovaps xmm12, [rsp+0xC0]
000077a70fde190b  vmovaps xmm13, [rsp+0xD0]
000077a70fde1914  vmovaps xmm15, [rsp+0xE0]
000077a70fde191d  add rsp, 0xF0
000077a70fde1924  pop r11
000077a70fde1926  pop r10
000077a70fde1928  pop r9
000077a70fde192a  pop r8
000077a70fde192c  pop rsi
000077a70fde192d  pop rdi
000077a70fde192e  pop rdx
000077a70fde192f  pop rcx
000077a70fde1930  pop rax
000077a70fde1931  add rsp, 0x08
000077a70fde1935  jmp 0x000077A70FDDC843
000077a70fde193a  sub rsp, 0x08
000077a70fde193e  push rax
000077a70fde193f  push rcx
000077a70fde1940  push rdx
000077a70fde1941  push rdi
000077a70fde1942  push rsi
000077a70fde1943  push r8
000077a70fde1945  push r9
000077a70fde1947  push r10
000077a70fde1949  push r11
000077a70fde194b  sub rsp, 0xF0
000077a70fde1952  vmovaps [rsp], xmm0
000077a70fde1957  vmovaps [rsp+0x10], xmm2
000077a70fde195d  vmovaps [rsp+0x20], xmm3
000077a70fde1963  vmovaps [rsp+0x30], xmm4
000077a70fde1969  vmovaps [rsp+0x40], xmm5
000077a70fde196f  vmovaps [rsp+0x50], xmm6
000077a70fde1975  vmovaps [rsp+0x60], xmm7
000077a70fde197b  vmovaps [rsp+0x70], xmm8
000077a70fde1981  vmovaps [rsp+0x80], xmm9
000077a70fde198a  vmovaps [rsp+0x90], xmm10
000077a70fde1993  vmovaps [rsp+0xA0], xmm11
000077a70fde199c  vmovaps [rsp+0xB0], xmm12
000077a70fde19a5  vmovaps [rsp+0xC0], xmm13
000077a70fde19ae  vmovaps [rsp+0xD0], xmm14
000077a70fde19b7  vmovaps [rsp+0xE0], xmm15
000077a70fde19c0  sub rsp, 0x30
000077a70fde19c4  movaps [rsp], xmm1
000077a70fde19c8  movaps [rsp+0x10], xmm8
000077a70fde19ce  movaps [rsp+0x20], xmm9
000077a70fde19d4  lea rdi, [rsp]
000077a70fde19d8  mov esi, 0x00
000077a70fde19dd  mov rax, 0x6294188EF530
000077a70fde19e7  call rax
000077a70fde19e9  movaps xmm1, [rsp]
000077a70fde19ed  add rsp, 0x30
000077a70fde19f1  vmovaps xmm0, [rsp]
000077a70fde19f6  vmovaps xmm2, [rsp+0x10]
000077a70fde19fc  vmovaps xmm3, [rsp+0x20]
000077a70fde1a02  vmovaps xmm4, [rsp+0x30]
000077a70fde1a08  vmovaps xmm5, [rsp+0x40]
000077a70fde1a0e  vmovaps xmm6, [rsp+0x50]
000077a70fde1a14  vmovaps xmm7, [rsp+0x60]
000077a70fde1a1a  vmovaps xmm8, [rsp+0x70]
000077a70fde1a20  vmovaps xmm9, [rsp+0x80]
000077a70fde1a29  vmovaps xmm10, [rsp+0x90]
000077a70fde1a32  vmovaps xmm11, [rsp+0xA0]
000077a70fde1a3b  vmovaps xmm12, [rsp+0xB0]
000077a70fde1a44  vmovaps xmm13, [rsp+0xC0]
000077a70fde1a4d  vmovaps xmm14, [rsp+0xD0]
000077a70fde1a56  vmovaps xmm15, [rsp+0xE0]
000077a70fde1a5f  add rsp, 0xF0
000077a70fde1a66  pop r11
000077a70fde1a68  pop r10
000077a70fde1a6a  pop r9
000077a70fde1a6c  pop r8
000077a70fde1a6e  pop rsi
000077a70fde1a6f  pop rdi
000077a70fde1a70  pop rdx
000077a70fde1a71  pop rcx
000077a70fde1a72  pop rax
000077a70fde1a73  add rsp, 0x08
000077a70fde1a77  jmp 0x000077A70FDDC865
000077a70fde1a7c  call 0x000077A70FCE5940
000077a70fde1a81  jmp 0x000077A70FDDC873
000077a70fde1a86  call 0x000077A70FC0C380
000077a70fde1a8b  jmp 0x000077A70FDDC87D
000077a70fde1a90  call 0x000077A70FC0D600
000077a70fde1a95  jmp 0x000077A70FDDC887
000077a70fde1a9a  call 0x000077A70FBFF540
000077a70fde1a9f  jmp 0x000077A70FDDC891
000077a70fde1aa4  int3
000077a70fde1aa5  nop [rax+rax*1], ax
000077a70fde1aae  nop
000077a70fde1ab0  mov rax, [r15+0xF8]
000077a70fde1ab7  lea r14, [rax+0x140]
000077a70fde1abe  mov r12, [r13+r14*1]
000077a70fde1ac3  mov [r15+0xE8], r12
000077a70fde1aca  lea r14, [rax+0x130]
000077a70fde1ad1  mov r12, [r13+r14*1]
000077a70fde1ad6  lea r14, [rax+0x138]
000077a70fde1add  mov r11, [r13+r14*1]
000077a70fde1ae2  movq xmm1, r12
000077a70fde1ae7  movq xmm15, r11
000077a70fde1aec  movq xmm1, xmm1
000077a70fde1af0  movq xmm1, xmm1
000077a70fde1af4  movaps [r15+0x1A0], xmm1
000077a70fde1afc  movq xmm15, xmm15
000077a70fde1b01  movq xmm15, xmm15
000077a70fde1b06  movaps [r15+0x190], xmm15
000077a70fde1b0e  lea r14, [rax+0x120]
000077a70fde1b15  mov r12, [r13+r14*1]
000077a70fde1b1a  lea r14, [rax+0x128]
000077a70fde1b21  mov r11, [r13+r14*1]
000077a70fde1b26  movq xmm1, r12
000077a70fde1b2b  movq xmm15, r11
000077a70fde1b30  movq xmm1, xmm1
000077a70fde1b34  movq xmm1, xmm1
000077a70fde1b38  movaps [r15+0x1C0], xmm1
000077a70fde1b40  movq xmm15, xmm15
000077a70fde1b45  movq xmm15, xmm15
000077a70fde1b4a  movaps [r15+0x1B0], xmm15
000077a70fde1b52  lea r14, [rax+0x110]
000077a70fde1b59  mov r12, [r13+r14*1]
000077a70fde1b5e  lea r14, [rax+0x118]
000077a70fde1b65  mov r11, [r13+r14*1]
000077a70fde1b6a  movq xmm1, r12
000077a70fde1b6f  movq xmm15, r11
000077a70fde1b74  movq xmm1, xmm1
000077a70fde1b78  movq xmm1, xmm1
000077a70fde1b7c  movaps [r15+0x1E0], xmm1
000077a70fde1b84  movq xmm15, xmm15
000077a70fde1b89  movq xmm15, xmm15
000077a70fde1b8e  movaps [r15+0x1D0], xmm15
000077a70fde1b96  lea r14, [rax+0x100]
000077a70fde1b9d  mov r12, [r13+r14*1]
000077a70fde1ba2  lea r14, [rax+0x108]
000077a70fde1ba9  mov r11, [r13+r14*1]
000077a70fde1bae  movq xmm1, r12
000077a70fde1bb3  movq xmm15, r11
000077a70fde1bb8  movq xmm1, xmm1
000077a70fde1bbc  movq xmm1, xmm1
000077a70fde1bc0  movaps [r15+0x200], xmm1
000077a70fde1bc8  movq xmm15, xmm15
000077a70fde1bcd  movq xmm15, xmm15
000077a70fde1bd2  movaps [r15+0x1F0], xmm15
000077a70fde1bda  mov qword ptr [r15+0x40], 0x430000
000077a70fde1be2  mov r14d, 0x430510
000077a70fde1be8  mov r12, [r13+r14*1]
000077a70fde1bed  movq xmm1, r12
000077a70fde1bf2  lea r14, [rax+0x150]
000077a70fde1bf9  mov [r15+0xF8], r14
000077a70fde1c00  mov rax, [r15+0x50]
000077a70fde1c04  movups xmm15, [r13+rax*1]
000077a70fde1c0a  movaps [r15+0x120], xmm15
000077a70fde1c12  mov qword ptr [r15+0x48], 0x10
000077a70fde1c1a  xor eax, eax
000077a70fde1c1c  mov r14d, 0x10
000077a70fde1c22  mov r12d, 0x200
000077a70fde1c28  cmp r14, r12
000077a70fde1c2b  cmc
000077a70fde1c2c  lahf
000077a70fde1c2d  seto al
000077a70fde1c30  mov [r15+0x108], eax
000077a70fde1c37  pextrq rax, xmm15, 0x01
000077a70fde1c3e  movq xmm14, rax
000077a70fde1c43  movaps [r15+0x130], xmm14
000077a70fde1c4b  movq rax, xmm1
000077a70fde1c50  movq r14, xmm15
000077a70fde1c55  vmovq xmm1, rax
000077a70fde1c5a  vmovq xmm15, r14
000077a70fde1c5f  movaps xmm13, xmm1
000077a70fde1c63  addsd xmm13, xmm15
000077a70fde1c68  ucomisd xmm13, xmm13
000077a70fde1c6d  jp 0x000077A70FDE1D86
000077a70fde1c73  movq xmm13, xmm13
000077a70fde1c78  movq rax, xmm13
000077a70fde1c7d  movq r14, xmm14
000077a70fde1c82  vmovq xmm1, rax
000077a70fde1c87  vmovq xmm15, r14
000077a70fde1c8c  movaps xmm14, xmm1
000077a70fde1c90  addsd xmm14, xmm15
000077a70fde1c95  ucomisd xmm14, xmm14
000077a70fde1c9a  jp 0x000077A70FDE1DCE
000077a70fde1ca0  movq xmm14, xmm14
000077a70fde1ca5  movaps [r15+0x110], xmm14
000077a70fde1cad  mov eax, [r15+0x108]
000077a70fde1cb4  sahf
000077a70fde1cb5  jnz 0x000077A70FDE1CE7
000077a70fde1cb7  cmp dword ptr [r15+0x318], 0x00
000077a70fde1cbf  jz 0x000077A70FDE1FE0
000077a70fde1cc5  nop [rax+rax*1], ax
000077a70fde1cce  nop [rax+rax*1], eax
000077a70fde1cd6  mov eax, 0x410490
000077a70fde1cdb  mov [r15+0x100], rax
000077a70fde1ce2  jmp 0x000077A70FBFE110
000077a70fde1ce7  cmp dword ptr [r15+0x318], 0x00
000077a70fde1cef  jz 0x000077A70FDE1E20
000077a70fde1cf5  nop [rax+rax*1], ax
000077a70fde1cfe  nop [rax+rax*1], eax
000077a70fde1d06  mov eax, 0x410474
000077a70fde1d0b  mov [r15+0x100], rax
000077a70fde1d12  jmp 0x000077A70FBFE110
000077a70fde1d17  int3
000077a70fde1d18  call 0x000077A70FCE27E0
000077a70fde1d1d  jmp 0x000077A70FDE1AC3
000077a70fde1d22  call 0x000077A70FCE27E0
000077a70fde1d27  jmp 0x000077A70FDE1AD6
000077a70fde1d2c  call 0x000077A70FCE1570
000077a70fde1d31  jmp 0x000077A70FDE1AE2
000077a70fde1d36  call 0x000077A70FCE27E0
000077a70fde1d3b  jmp 0x000077A70FDE1B1A
000077a70fde1d40  call 0x000077A70FCE1570
000077a70fde1d45  jmp 0x000077A70FDE1B26
000077a70fde1d4a  call 0x000077A70FCE27E0
000077a70fde1d4f  jmp 0x000077A70FDE1B5E
000077a70fde1d54  call 0x000077A70FCE1570
000077a70fde1d59  jmp 0x000077A70FDE1B6A
000077a70fde1d5e  call 0x000077A70FCE27E0
000077a70fde1d63  jmp 0x000077A70FDE1BA2
000077a70fde1d68  call 0x000077A70FCE1570
000077a70fde1d6d  jmp 0x000077A70FDE1BAE
000077a70fde1d72  call 0x000077A70FCE27E0
000077a70fde1d77  jmp 0x000077A70FDE1BED
000077a70fde1d7c  call 0x000077A70FC0E760
000077a70fde1d81  jmp 0x000077A70FDE1C0A
000077a70fde1d86  ucomisd xmm1, xmm15
000077a70fde1d8b  jp 0x000077A70FDE1D9A
000077a70fde1d8d  movaps xmm13, [0x000077A70F9FE060]
000077a70fde1d95  jmp 0x000077A70FDE1C73
000077a70fde1d9a  vxorps xmm0, xmm1, xmm15
000077a70fde1d9f  pextrw eax, xmm0, 0x03
000077a70fde1da4  and eax, 0x7FF8
000077a70fde1da9  cmp eax, 0x08
000077a70fde1dac  jnz 0x000077A70FDE1C73
000077a70fde1db2  movq rax, xmm15
000077a70fde1db7  shl rax, 0x0D
000077a70fde1dbb  jbe 0x000077A70FDE1C73
000077a70fde1dc1  vorps xmm13, xmm15, [0x000077A70F9FE070]
000077a70fde1dc9  jmp 0x000077A70FDE1C73
000077a70fde1dce  ucomisd xmm1, xmm15
000077a70fde1dd3  jp 0x000077A70FDE1DE2
000077a70fde1dd5  movaps xmm14, [0x000077A70F9FE060]
000077a70fde1ddd  jmp 0x000077A70FDE1CA0
000077a70fde1de2  vxorps xmm0, xmm1, xmm15
000077a70fde1de7  pextrw eax, xmm0, 0x03
000077a70fde1dec  and eax, 0x7FF8
000077a70fde1df1  cmp eax, 0x08
000077a70fde1df4  jnz 0x000077A70FDE1CA0
000077a70fde1dfa  movq rax, xmm15
000077a70fde1dff  shl rax, 0x0D
000077a70fde1e03  jbe 0x000077A70FDE1CA0
000077a70fde1e09  vorps xmm14, xmm15, [0x000077A70F9FE070]
000077a70fde1e11  jmp 0x000077A70FDE1CA0
000077a70fde1e16  int3
000077a70fde1e17  nop [rax+rax*1], ax
000077a70fde1e20  mov rax, [r15+0x48]
000077a70fde1e24  mov r14, [r15+0x50]
000077a70fde1e28  lea r12, [r14+rax*1]
000077a70fde1e2c  movups xmm1, [r13+r12*1]
000077a70fde1e32  movaps [r15+0x120], xmm1
000077a70fde1e3a  lea r14, [rax+0x10]
000077a70fde1e3e  mov [r15+0x48], r14
000077a70fde1e42  xor eax, eax
000077a70fde1e44  mov r12d, 0x200
000077a70fde1e4a  cmp r14, r12
000077a70fde1e4d  cmc
000077a70fde1e4e  lahf
000077a70fde1e4f  seto al
000077a70fde1e52  mov [r15+0x108], eax
000077a70fde1e59  pextrq rax, xmm1, 0x01
000077a70fde1e60  movq xmm15, rax
000077a70fde1e65  movaps [r15+0x130], xmm15
000077a70fde1e6d  movaps xmm14, [r15+0x110]
000077a70fde1e75  movq rax, xmm14
000077a70fde1e7a  movq r14, xmm1
000077a70fde1e7f  vmovq xmm1, rax
000077a70fde1e84  vmovq xmm14, r14
000077a70fde1e89  movaps xmm13, xmm1
000077a70fde1e8d  addsd xmm13, xmm14
000077a70fde1e92  ucomisd xmm13, xmm13
000077a70fde1e97  jp 0x000077A70FDE1F4C
000077a70fde1e9d  movq xmm13, xmm13
000077a70fde1ea2  movq rax, xmm13
000077a70fde1ea7  movq r14, xmm15
000077a70fde1eac  vmovq xmm1, rax
000077a70fde1eb1  vmovq xmm15, r14
000077a70fde1eb6  movaps xmm14, xmm1
000077a70fde1eba  addsd xmm14, xmm15
000077a70fde1ebf  ucomisd xmm14, xmm14
000077a70fde1ec4  jp 0x000077A70FDE1F94
000077a70fde1eca  movq xmm14, xmm14
000077a70fde1ecf  movaps [r15+0x110], xmm14
000077a70fde1ed7  mov eax, [r15+0x108]
000077a70fde1ede  sahf
000077a70fde1edf  jnz 0x000077A70FDE1F11
000077a70fde1ee1  cmp dword ptr [r15+0x318], 0x00
000077a70fde1ee9  jz 0x000077A70FDE1FE0
000077a70fde1eef  nop [rax+rax*1], ax
000077a70fde1ef8  nop [rax+rax*1], eax
000077a70fde1f00  mov eax, 0x410490
000077a70fde1f05  mov [r15+0x100], rax
000077a70fde1f0c  jmp 0x000077A70FBFE110
000077a70fde1f11  cmp dword ptr [r15+0x318], 0x00
000077a70fde1f19  jz 0x000077A70FDE1E20
000077a70fde1f1f  nop [rax+rax*1], ax
000077a70fde1f28  nop [rax+rax*1], eax
000077a70fde1f30  mov eax, 0x410474
000077a70fde1f35  mov [r15+0x100], rax
000077a70fde1f3c  jmp 0x000077A70FBFE110
000077a70fde1f41  int3
000077a70fde1f42  call 0x000077A70FCB52F0
000077a70fde1f47  jmp 0x000077A70FDE1E32
000077a70fde1f4c  ucomisd xmm1, xmm14
000077a70fde1f51  jp 0x000077A70FDE1F60
000077a70fde1f53  movaps xmm13, [0x000077A70F9FE060]
000077a70fde1f5b  jmp 0x000077A70FDE1E9D
000077a70fde1f60  vxorps xmm0, xmm1, xmm14
000077a70fde1f65  pextrw eax, xmm0, 0x03
000077a70fde1f6a  and eax, 0x7FF8
000077a70fde1f6f  cmp eax, 0x08
000077a70fde1f72  jnz 0x000077A70FDE1E9D
000077a70fde1f78  movq rax, xmm14
000077a70fde1f7d  shl rax, 0x0D
000077a70fde1f81  jbe 0x000077A70FDE1E9D
000077a70fde1f87  vorps xmm13, xmm14, [0x000077A70F9FE070]
000077a70fde1f8f  jmp 0x000077A70FDE1E9D
000077a70fde1f94  ucomisd xmm1, xmm15
000077a70fde1f99  jp 0x000077A70FDE1FA8
000077a70fde1f9b  movaps xmm14, [0x000077A70F9FE060]
000077a70fde1fa3  jmp 0x000077A70FDE1ECA
000077a70fde1fa8  vxorps xmm0, xmm1, xmm15
000077a70fde1fad  pextrw eax, xmm0, 0x03
000077a70fde1fb2  and eax, 0x7FF8
000077a70fde1fb7  cmp eax, 0x08
000077a70fde1fba  jnz 0x000077A70FDE1ECA
000077a70fde1fc0  movq rax, xmm15
000077a70fde1fc5  shl rax, 0x0D
000077a70fde1fc9  jbe 0x000077A70FDE1ECA
000077a70fde1fcf  vorps xmm14, xmm15, [0x000077A70F9FE070]
000077a70fde1fd7  jmp 0x000077A70FDE1ECA
000077a70fde1fdc  int3
000077a70fde1fdd  nop [rax], eax
000077a70fde1fe0  mov rax, [r15+0x40]
000077a70fde1fe4  lea r14, [rax+0x510]
000077a70fde1feb  movaps xmm1, [r15+0x110]
000077a70fde1ff3  movq rax, xmm1
000077a70fde1ff8  mov [r13+r14*1], rax
000077a70fde1ffd  mov rax, [r15+0xF0]
000077a70fde2004  mov [r15+0x100], rax
000077a70fde200b  jmp 0x000077A70FDCE5C0
000077a70fde2010  int3
000077a70fde2011  call 0x000077A70FCD5EB0
000077a70fde2016  jmp 0x000077A70FDE1FFD
000077a70fde201b  int3
000077a70fde201c  nop [rax], eax
000077a70fde2020  mov qword ptr [r15+0x100], 0x04
000077a70fde202b  mov esi, 0x00
000077a70fde2030  mov edx, 0x09
000077a70fde2035  mov rdi, 0x7FFC98A85F40
000077a70fde203f  mov rax, 0x629418782970
000077a70fde2049  call rax
000077a70fde204b  cmp dword ptr [r15+0x318], 0x00
000077a70fde2053  jnz 0x000077A70FBFE110
000077a70fde2059  jmp 0x000077A70FBFE0A0
000077a70fde205e  int3
000077a70fde205f  int3
