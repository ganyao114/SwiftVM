000073307ffce69b  nop [rax+rax*1], eax
000073307ffce6a0  vmovaps xmm1, [0x000073307FBFE010]
000073307ffce6a8  movq xmm1, xmm1
000073307ffce6ac  movaps [r15+0x110], xmm1
000073307ffce6b4  vmovaps xmm1, [0x000073307FBFE020]
000073307ffce6bc  movq xmm1, xmm1
000073307ffce6c0  movaps [r15+0x120], xmm1
000073307ffce6c8  mov eax, 0x4204C0
000073307ffce6cd  mov r14, [r13+rax*1]
000073307ffce6d2  movq xmm1, r14
000073307ffce6d7  movaps [r15+0x130], xmm1
000073307ffce6df  vmovaps xmm1, [0x000073307FBFE030]
000073307ffce6e7  vpbroadcastq xmm1, xmm1
000073307ffce6ec  movaps [r15+0x140], xmm1
000073307ffce6f4  mov qword ptr [r15+0x40], 0x02
000073307ffce6fc  vmovaps xmm15, [0x000073307FBFE040]
000073307ffce704  movq xmm15, xmm15
000073307ffce709  movaps [r15+0x150], xmm15
000073307ffce711  mov qword ptr [r15+0x58], 0x420000
000073307ffce719  vmovaps xmm15, [0x000073307FBFE050]
000073307ffce721  vpbroadcastq xmm15, xmm15
000073307ffce726  movaps [r15+0x160], xmm15
000073307ffce72e  mov rax, [r15+0x40]
000073307ffce732  vmovq xmm14, rax
000073307ffce737  vpbroadcastq xmm14, xmm14
000073307ffce73c  movaps [r15+0x170], xmm14
000073307ffce744  mov eax, 0x4204D0
000073307ffce749  movups xmm13, [r13+rax*1]
000073307ffce74f  mov qword ptr [r15+0x40], 0x430518
000073307ffce757  mov qword ptr [r15+0x50], 0x430720
000073307ffce75f  vpmovqd xmm12, xmm13
000073307ffce765  pxor xmm11, xmm11
000073307ffce76a  punpcklqdq xmm12, xmm11
000073307ffce76f  movaps [r15+0x210], xmm12
000073307ffce777  movq xmm12, qword ptr [r15+0x120]
000073307ffce780  movq xmm11, qword ptr [r15+0x130]
000073307ffce789  psubd xmm12, xmm11
000073307ffce78e  movq xmm12, xmm12
000073307ffce793  paddq xmm13, xmm14
000073307ffce798  movaps [r15+0x180], xmm13
000073307ffce7a0  movq xmm14, qword ptr [r15+0x150]
000073307ffce7a9  paddd xmm11, xmm14
000073307ffce7ae  movq xmm11, xmm11
000073307ffce7b3  movq xmm11, xmm11
000073307ffce7b8  movaps [r15+0x130], xmm11
000073307ffce7c0  pmovzxdq xmm12, xmm12
000073307ffce7c6  psllq xmm12, 0x00
000073307ffce7cc  movq xmm14, qword ptr [r15+0x210]
000073307ffce7d5  movq xmm13, qword ptr [r15+0x110]
000073307ffce7de  paddd xmm14, xmm13
000073307ffce7e3  movq xmm14, xmm14
000073307ffce7e8  vcvtuqq2pd xmm12, xmm12
000073307ffce7ee  pmovzxdq xmm14, xmm14
000073307ffce7f4  psllq xmm14, 0x00
000073307ffce7fa  vcvtuqq2pd xmm14, xmm14
000073307ffce800  movaps xmm13, xmm12
000073307ffce804  mulpd xmm13, xmm1
000073307ffce809  vcmppd xmm11, xmm13, xmm13, 0x03
000073307ffce80f  ptest xmm11, xmm11
000073307ffce815  jnz 0x000073307FFCE8FF
000073307ffce81b  movaps [r15+0x220], xmm13
000073307ffce823  mov eax, 0x430720
000073307ffce828  movups [r13+rax*1], xmm13
000073307ffce82e  movaps xmm1, xmm14
000073307ffce832  mulpd xmm1, xmm15
000073307ffce837  vcmppd xmm13, xmm1, xmm1, 0x03
000073307ffce83c  ptest xmm13, xmm13
000073307ffce842  jnz 0x000073307FFCEA4C
000073307ffce848  movaps [r15+0x210], xmm1
000073307ffce850  mov eax, 0x430518
000073307ffce855  movups [r13+rax*1], xmm1
000073307ffce85b  mov qword ptr [r15+0x48], 0x10
000073307ffce863  xor eax, eax
000073307ffce865  mov r14d, 0x10
000073307ffce86b  mov r12d, 0x200
000073307ffce871  cmp r14, r12
000073307ffce874  cmc
000073307ffce875  lahf
000073307ffce876  seto al
000073307ffce879  mov [r15+0x108], eax
000073307ffce880  mov eax, [r15+0x108]
000073307ffce887  sahf
000073307ffce888  jnz 0x000073307FFCE8BA
000073307ffce88a  cmp dword ptr [r15+0x318], 0x00
000073307ffce892  jz 0x000073307FFCEFF0
000073307ffce898  nop [rax+rax*1], ax
000073307ffce8a1  nop [rax+rax*1], eax
000073307ffce8a9  mov eax, 0x4101EC
000073307ffce8ae  mov [r15+0x100], rax
000073307ffce8b5  jmp 0x000073307FDFE110
000073307ffce8ba  cmp dword ptr [r15+0x318], 0x00
000073307ffce8c2  jz 0x000073307FFCEBA0
000073307ffce8c8  nop [rax+rax*1], ax
000073307ffce8d1  nop [rax+rax*1], eax
000073307ffce8d9  mov eax, 0x4101AC
000073307ffce8de  mov [r15+0x100], rax
000073307ffce8e5  jmp 0x000073307FDFE110
000073307ffce8ea  int3
000073307ffce8eb  call 0x000073307FE0DC20
000073307ffce8f0  jmp 0x000073307FFCE6D2
000073307ffce8f5  call 0x000073307FE0C260
000073307ffce8fa  jmp 0x000073307FFCE74F
000073307ffce8ff  sub rsp, 0x08
000073307ffce903  push rax
000073307ffce904  push rcx
000073307ffce905  push rdx
000073307ffce906  push rdi
000073307ffce907  push rsi
000073307ffce908  push r8
000073307ffce90a  push r9
000073307ffce90c  push r10
000073307ffce90e  push r11
000073307ffce910  sub rsp, 0xF0
000073307ffce917  vmovaps [rsp], xmm0
000073307ffce91c  vmovaps [rsp+0x10], xmm1
000073307ffce922  vmovaps [rsp+0x20], xmm2
000073307ffce928  vmovaps [rsp+0x30], xmm3
000073307ffce92e  vmovaps [rsp+0x40], xmm4
000073307ffce934  vmovaps [rsp+0x50], xmm5
000073307ffce93a  vmovaps [rsp+0x60], xmm6
000073307ffce940  vmovaps [rsp+0x70], xmm7
000073307ffce946  vmovaps [rsp+0x80], xmm8
000073307ffce94f  vmovaps [rsp+0x90], xmm9
000073307ffce958  vmovaps [rsp+0xA0], xmm10
000073307ffce961  vmovaps [rsp+0xB0], xmm11
000073307ffce96a  vmovaps [rsp+0xC0], xmm12
000073307ffce973  vmovaps [rsp+0xD0], xmm14
000073307ffce97c  vmovaps [rsp+0xE0], xmm15
000073307ffce985  sub rsp, 0x30
000073307ffce989  movaps [rsp], xmm13
000073307ffce98e  movaps [rsp+0x10], xmm12
000073307ffce994  movaps [rsp+0x20], xmm1
000073307ffce999  lea rdi, [rsp]
000073307ffce99d  mov esi, 0x00
000073307ffce9a2  mov rax, 0x600DE0EC8530
000073307ffce9ac  call rax
000073307ffce9ae  movaps xmm13, [rsp]
000073307ffce9b3  add rsp, 0x30
000073307ffce9b7  vmovaps xmm0, [rsp]
000073307ffce9bc  vmovaps xmm1, [rsp+0x10]
000073307ffce9c2  vmovaps xmm2, [rsp+0x20]
000073307ffce9c8  vmovaps xmm3, [rsp+0x30]
000073307ffce9ce  vmovaps xmm4, [rsp+0x40]
000073307ffce9d4  vmovaps xmm5, [rsp+0x50]
000073307ffce9da  vmovaps xmm6, [rsp+0x60]
000073307ffce9e0  vmovaps xmm7, [rsp+0x70]
000073307ffce9e6  vmovaps xmm8, [rsp+0x80]
000073307ffce9ef  vmovaps xmm9, [rsp+0x90]
000073307ffce9f8  vmovaps xmm10, [rsp+0xA0]
000073307ffcea01  vmovaps xmm11, [rsp+0xB0]
000073307ffcea0a  vmovaps xmm12, [rsp+0xC0]
000073307ffcea13  vmovaps xmm14, [rsp+0xD0]
000073307ffcea1c  vmovaps xmm15, [rsp+0xE0]
000073307ffcea25  add rsp, 0xF0
000073307ffcea2c  pop r11
000073307ffcea2e  pop r10
000073307ffcea30  pop r9
000073307ffcea32  pop r8
000073307ffcea34  pop rsi
000073307ffcea35  pop rdi
000073307ffcea36  pop rdx
000073307ffcea37  pop rcx
000073307ffcea38  pop rax
000073307ffcea39  add rsp, 0x08
000073307ffcea3d  jmp 0x000073307FFCE81B
000073307ffcea42  call 0x000073307FE0C380
000073307ffcea47  jmp 0x000073307FFCE82E
000073307ffcea4c  sub rsp, 0x08
000073307ffcea50  push rax
000073307ffcea51  push rcx
000073307ffcea52  push rdx
000073307ffcea53  push rdi
000073307ffcea54  push rsi
000073307ffcea55  push r8
000073307ffcea57  push r9
000073307ffcea59  push r10
000073307ffcea5b  push r11
000073307ffcea5d  sub rsp, 0xF0
000073307ffcea64  vmovaps [rsp], xmm0
000073307ffcea69  vmovaps [rsp+0x10], xmm2
000073307ffcea6f  vmovaps [rsp+0x20], xmm3
000073307ffcea75  vmovaps [rsp+0x30], xmm4
000073307ffcea7b  vmovaps [rsp+0x40], xmm5
000073307ffcea81  vmovaps [rsp+0x50], xmm6
000073307ffcea87  vmovaps [rsp+0x60], xmm7
000073307ffcea8d  vmovaps [rsp+0x70], xmm8
000073307ffcea93  vmovaps [rsp+0x80], xmm9
000073307ffcea9c  vmovaps [rsp+0x90], xmm10
000073307ffceaa5  vmovaps [rsp+0xA0], xmm11
000073307ffceaae  vmovaps [rsp+0xB0], xmm12
000073307ffceab7  vmovaps [rsp+0xC0], xmm13
000073307ffceac0  vmovaps [rsp+0xD0], xmm14
000073307ffceac9  vmovaps [rsp+0xE0], xmm15
000073307ffcead2  sub rsp, 0x30
000073307ffcead6  movaps [rsp], xmm1
000073307ffceada  movaps [rsp+0x10], xmm14
000073307ffceae0  movaps [rsp+0x20], xmm15
000073307ffceae6  lea rdi, [rsp]
000073307ffceaea  mov esi, 0x00
000073307ffceaef  mov rax, 0x600DE0EC8530
000073307ffceaf9  call rax
000073307ffceafb  movaps xmm1, [rsp]
000073307ffceaff  add rsp, 0x30
000073307ffceb03  vmovaps xmm0, [rsp]
000073307ffceb08  vmovaps xmm2, [rsp+0x10]
000073307ffceb0e  vmovaps xmm3, [rsp+0x20]
000073307ffceb14  vmovaps xmm4, [rsp+0x30]
000073307ffceb1a  vmovaps xmm5, [rsp+0x40]
000073307ffceb20  vmovaps xmm6, [rsp+0x50]
000073307ffceb26  vmovaps xmm7, [rsp+0x60]
000073307ffceb2c  vmovaps xmm8, [rsp+0x70]
000073307ffceb32  vmovaps xmm9, [rsp+0x80]
000073307ffceb3b  vmovaps xmm10, [rsp+0x90]
000073307ffceb44  vmovaps xmm11, [rsp+0xA0]
000073307ffceb4d  vmovaps xmm12, [rsp+0xB0]
000073307ffceb56  vmovaps xmm13, [rsp+0xC0]
000073307ffceb5f  vmovaps xmm14, [rsp+0xD0]
000073307ffceb68  vmovaps xmm15, [rsp+0xE0]
000073307ffceb71  add rsp, 0xF0
000073307ffceb78  pop r11
000073307ffceb7a  pop r10
000073307ffceb7c  pop r9
000073307ffceb7e  pop r8
000073307ffceb80  pop rsi
000073307ffceb81  pop rdi
000073307ffceb82  pop rdx
000073307ffceb83  pop rcx
000073307ffceb84  pop rax
000073307ffceb85  add rsp, 0x08
000073307ffceb89  jmp 0x000073307FFCE848
000073307ffceb8e  call 0x000073307FDFF540
000073307ffceb93  jmp 0x000073307FFCE85B
000073307ffceb98  int3
000073307ffceb99  nop [rax], eax
000073307ffceba0  movaps xmm1, [r15+0x180]
000073307ffceba8  vpmovqd xmm15, xmm1
000073307ffcebae  pxor xmm14, xmm14
000073307ffcebb3  punpcklqdq xmm15, xmm14
000073307ffcebb8  movaps [r15+0x210], xmm15
000073307ffcebc0  movq xmm15, qword ptr [r15+0x120]
000073307ffcebc9  movq xmm14, qword ptr [r15+0x130]
000073307ffcebd2  psubd xmm15, xmm14
000073307ffcebd7  movq xmm15, xmm15
000073307ffcebdc  movaps xmm13, [r15+0x170]
000073307ffcebe4  paddq xmm1, xmm13
000073307ffcebe9  movaps [r15+0x180], xmm1
000073307ffcebf1  movq xmm1, qword ptr [r15+0x150]
000073307ffcebfa  paddd xmm14, xmm1
000073307ffcebff  movq xmm14, xmm14
000073307ffcec04  movq xmm14, xmm14
000073307ffcec09  movaps [r15+0x130], xmm14
000073307ffcec11  pmovzxdq xmm15, xmm15
000073307ffcec17  psllq xmm15, 0x00
000073307ffcec1d  movq xmm1, qword ptr [r15+0x210]
000073307ffcec26  movq xmm14, qword ptr [r15+0x110]
000073307ffcec2f  paddd xmm1, xmm14
000073307ffcec34  movq xmm1, xmm1
000073307ffcec38  vcvtuqq2pd xmm15, xmm15
000073307ffcec3e  pmovzxdq xmm1, xmm1
000073307ffcec43  psllq xmm1, 0x00
000073307ffcec48  vcvtuqq2pd xmm1, xmm1
000073307ffcec4e  movaps xmm14, [r15+0x140]
000073307ffcec56  movaps xmm13, xmm15
000073307ffcec5a  mulpd xmm13, xmm14
000073307ffcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
000073307ffcec65  ptest xmm12, xmm12
000073307ffcec6b  jnz 0x000073307FFCED4E
000073307ffcec71  movaps [r15+0x220], xmm13
000073307ffcec79  mov rax, [r15+0x48]
000073307ffcec7d  mov r14, [r15+0x50]
000073307ffcec81  lea r12, [r14+rax*1]
000073307ffcec85  movups [r13+r12*1], xmm13
000073307ffcec8b  movaps xmm15, [r15+0x160]
000073307ffcec93  movaps xmm14, xmm1
000073307ffcec97  mulpd xmm14, xmm15
000073307ffcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
000073307ffceca2  ptest xmm13, xmm13
000073307ffceca8  jnz 0x000073307FFCEE9C
000073307ffcecae  movaps [r15+0x210], xmm14
000073307ffcecb6  mov r14, [r15+0x40]
000073307ffcecba  lea r12, [r14+rax*1]
000073307ffcecbe  movups [r13+r12*1], xmm14
000073307ffcecc4  lea r14, [rax+0x10]
000073307ffcecc8  mov [r15+0x48], r14
000073307ffceccc  xor eax, eax
000073307ffcecce  mov r12d, 0x200
000073307ffcecd4  cmp r14, r12
000073307ffcecd7  cmc
000073307ffcecd8  lahf
000073307ffcecd9  seto al
000073307ffcecdc  mov [r15+0x108], eax
000073307ffcece3  mov eax, [r15+0x108]
000073307ffcecea  sahf
000073307ffceceb  jnz 0x000073307FFCED1D
000073307ffceced  cmp dword ptr [r15+0x318], 0x00
000073307ffcecf5  jz 0x000073307FFCEFF0
000073307ffcecfb  nop [rax+rax*1], ax
000073307ffced04  nop [rax+rax*1], eax
000073307ffced0c  mov eax, 0x4101EC
000073307ffced11  mov [r15+0x100], rax
000073307ffced18  jmp 0x000073307FDFE110
000073307ffced1d  cmp dword ptr [r15+0x318], 0x00
000073307ffced25  jz 0x000073307FFCEBA0
000073307ffced2b  nop [rax+rax*1], ax
000073307ffced34  nop [rax+rax*1], eax
000073307ffced3c  mov eax, 0x4101AC
000073307ffced41  mov [r15+0x100], rax
000073307ffced48  jmp 0x000073307FDFE110
000073307ffced4d  int3
000073307ffced4e  sub rsp, 0x08
000073307ffced52  push rax
000073307ffced53  push rcx
000073307ffced54  push rdx
000073307ffced55  push rdi
000073307ffced56  push rsi
000073307ffced57  push r8
000073307ffced59  push r9
000073307ffced5b  push r10
000073307ffced5d  push r11
000073307ffced5f  sub rsp, 0xF0
000073307ffced66  vmovaps [rsp], xmm0
000073307ffced6b  vmovaps [rsp+0x10], xmm1
000073307ffced71  vmovaps [rsp+0x20], xmm2
000073307ffced77  vmovaps [rsp+0x30], xmm3
000073307ffced7d  vmovaps [rsp+0x40], xmm4
000073307ffced83  vmovaps [rsp+0x50], xmm5
000073307ffced89  vmovaps [rsp+0x60], xmm6
000073307ffced8f  vmovaps [rsp+0x70], xmm7
000073307ffced95  vmovaps [rsp+0x80], xmm8
000073307ffced9e  vmovaps [rsp+0x90], xmm9
000073307ffceda7  vmovaps [rsp+0xA0], xmm10
000073307ffcedb0  vmovaps [rsp+0xB0], xmm11
000073307ffcedb9  vmovaps [rsp+0xC0], xmm12
000073307ffcedc2  vmovaps [rsp+0xD0], xmm14
000073307ffcedcb  vmovaps [rsp+0xE0], xmm15
000073307ffcedd4  sub rsp, 0x30
000073307ffcedd8  movaps [rsp], xmm13
000073307ffceddd  movaps [rsp+0x10], xmm15
000073307ffcede3  movaps [rsp+0x20], xmm14
000073307ffcede9  lea rdi, [rsp]
000073307ffceded  mov esi, 0x00
000073307ffcedf2  mov rax, 0x600DE0EC8530
000073307ffcedfc  call rax
000073307ffcedfe  movaps xmm13, [rsp]
000073307ffcee03  add rsp, 0x30
000073307ffcee07  vmovaps xmm0, [rsp]
000073307ffcee0c  vmovaps xmm1, [rsp+0x10]
000073307ffcee12  vmovaps xmm2, [rsp+0x20]
000073307ffcee18  vmovaps xmm3, [rsp+0x30]
000073307ffcee1e  vmovaps xmm4, [rsp+0x40]
000073307ffcee24  vmovaps xmm5, [rsp+0x50]
000073307ffcee2a  vmovaps xmm6, [rsp+0x60]
000073307ffcee30  vmovaps xmm7, [rsp+0x70]
000073307ffcee36  vmovaps xmm8, [rsp+0x80]
000073307ffcee3f  vmovaps xmm9, [rsp+0x90]
000073307ffcee48  vmovaps xmm10, [rsp+0xA0]
000073307ffcee51  vmovaps xmm11, [rsp+0xB0]
000073307ffcee5a  vmovaps xmm12, [rsp+0xC0]
000073307ffcee63  vmovaps xmm14, [rsp+0xD0]
000073307ffcee6c  vmovaps xmm15, [rsp+0xE0]
000073307ffcee75  add rsp, 0xF0
000073307ffcee7c  pop r11
000073307ffcee7e  pop r10
000073307ffcee80  pop r9
000073307ffcee82  pop r8
000073307ffcee84  pop rsi
000073307ffcee85  pop rdi
000073307ffcee86  pop rdx
000073307ffcee87  pop rcx
000073307ffcee88  pop rax
000073307ffcee89  add rsp, 0x08
000073307ffcee8d  jmp 0x000073307FFCEC71
000073307ffcee92  call 0x000073307FEC2240
000073307ffcee97  jmp 0x000073307FFCEC8B
000073307ffcee9c  sub rsp, 0x08
000073307ffceea0  push rax
000073307ffceea1  push rcx
000073307ffceea2  push rdx
000073307ffceea3  push rdi
000073307ffceea4  push rsi
000073307ffceea5  push r8
000073307ffceea7  push r9
000073307ffceea9  push r10
000073307ffceeab  push r11
000073307ffceead  sub rsp, 0xF0
000073307ffceeb4  vmovaps [rsp], xmm0
000073307ffceeb9  vmovaps [rsp+0x10], xmm1
000073307ffceebf  vmovaps [rsp+0x20], xmm2
000073307ffceec5  vmovaps [rsp+0x30], xmm3
000073307ffceecb  vmovaps [rsp+0x40], xmm4
000073307ffceed1  vmovaps [rsp+0x50], xmm5
000073307ffceed7  vmovaps [rsp+0x60], xmm6
000073307ffceedd  vmovaps [rsp+0x70], xmm7
000073307ffceee3  vmovaps [rsp+0x80], xmm8
000073307ffceeec  vmovaps [rsp+0x90], xmm9
000073307ffceef5  vmovaps [rsp+0xA0], xmm10
000073307ffceefe  vmovaps [rsp+0xB0], xmm11
000073307ffcef07  vmovaps [rsp+0xC0], xmm12
000073307ffcef10  vmovaps [rsp+0xD0], xmm13
000073307ffcef19  vmovaps [rsp+0xE0], xmm15
000073307ffcef22  sub rsp, 0x30
000073307ffcef26  movaps [rsp], xmm14
000073307ffcef2b  movaps [rsp+0x10], xmm1
000073307ffcef30  movaps [rsp+0x20], xmm15
000073307ffcef36  lea rdi, [rsp]
000073307ffcef3a  mov esi, 0x00
000073307ffcef3f  mov rax, 0x600DE0EC8530
000073307ffcef49  call rax
000073307ffcef4b  movaps xmm14, [rsp]
000073307ffcef50  add rsp, 0x30
000073307ffcef54  vmovaps xmm0, [rsp]
000073307ffcef59  vmovaps xmm1, [rsp+0x10]
000073307ffcef5f  vmovaps xmm2, [rsp+0x20]
000073307ffcef65  vmovaps xmm3, [rsp+0x30]
000073307ffcef6b  vmovaps xmm4, [rsp+0x40]
000073307ffcef71  vmovaps xmm5, [rsp+0x50]
000073307ffcef77  vmovaps xmm6, [rsp+0x60]
000073307ffcef7d  vmovaps xmm7, [rsp+0x70]
000073307ffcef83  vmovaps xmm8, [rsp+0x80]
000073307ffcef8c  vmovaps xmm9, [rsp+0x90]
000073307ffcef95  vmovaps xmm10, [rsp+0xA0]
000073307ffcef9e  vmovaps xmm11, [rsp+0xB0]
000073307ffcefa7  vmovaps xmm12, [rsp+0xC0]
000073307ffcefb0  vmovaps xmm13, [rsp+0xD0]
000073307ffcefb9  vmovaps xmm15, [rsp+0xE0]
000073307ffcefc2  add rsp, 0xF0
000073307ffcefc9  pop r11
000073307ffcefcb  pop r10
000073307ffcefcd  pop r9
000073307ffcefcf  pop r8
000073307ffcefd1  pop rsi
000073307ffcefd2  pop rdi
000073307ffcefd3  pop rdx
000073307ffcefd4  pop rcx
000073307ffcefd5  pop rax
000073307ffcefd6  add rsp, 0x08
000073307ffcefda  jmp 0x000073307FFCECAE
000073307ffcefdf  call 0x000073307FEC34C0
000073307ffcefe4  jmp 0x000073307FFCECC4
000073307ffcefe9  int3
000073307ffcefea  nop [rax+rax*1], ax
000073307ffceff0  mov rax, [r15+0xF8]
000073307ffceff7  lea r14, [rax-0x150]
000073307ffceffe  mov [r15+0xF8], r14
000073307ffcf005  mov rax, [r15+0x50]
000073307ffcf009  lea r12, [rax+0x80]
000073307ffcf010  movups xmm1, [r13+r12*1]
000073307ffcf016  lea r12, [rax+0x90]
000073307ffcf01d  movups xmm15, [r13+r12*1]
000073307ffcf023  mov qword ptr [r15+0x48], 0x00
000073307ffcf02b  lea r12, [rax+0x40]
000073307ffcf02f  movups xmm14, [r13+r12*1]
000073307ffcf035  lea r12, [rax+0x50]
000073307ffcf039  movups xmm13, [r13+r12*1]
000073307ffcf03f  lea r12, [r14+0x120]
000073307ffcf046  movq xmm12, qword ptr [r15+0x1C0]
000073307ffcf04f  movq xmm11, qword ptr [r15+0x1B0]
000073307ffcf058  movq r11, xmm12
000073307ffcf05d  movq r10, xmm11
000073307ffcf062  mov [r13+r12*1], r11
000073307ffcf067  lea r12, [r14+0x128]
000073307ffcf06e  mov [r13+r12*1], r10
000073307ffcf073  vxorps xmm12, xmm12, xmm12
000073307ffcf078  vpbroadcastq xmm12, xmm12
000073307ffcf07d  lea r12, [r14+0x100]
000073307ffcf084  movq xmm11, qword ptr [r15+0x200]
000073307ffcf08d  movq xmm10, qword ptr [r15+0x1F0]
000073307ffcf096  movq r11, xmm11
000073307ffcf09b  movq r10, xmm10
000073307ffcf0a0  mov [r13+r12*1], r11
000073307ffcf0a5  lea r12, [r14+0x108]
000073307ffcf0ac  mov [r13+r12*1], r10
000073307ffcf0b1  lea r12, [r14+0xE0]
000073307ffcf0b8  movups [r13+r12*1], xmm15
000073307ffcf0be  lea r12, [r14+0xF0]
000073307ffcf0c5  movups [r13+r12*1], xmm1
000073307ffcf0cb  lea r12, [rax+0xC0]
000073307ffcf0d2  movups xmm1, [r13+r12*1]
000073307ffcf0d8  lea r12, [rax+0xD0]
000073307ffcf0df  movups xmm15, [r13+r12*1]
000073307ffcf0e5  lea r12, [r14+0x110]
000073307ffcf0ec  movq xmm11, qword ptr [r15+0x1E0]
000073307ffcf0f5  movq xmm10, qword ptr [r15+0x1D0]
000073307ffcf0fe  movq r11, xmm11
000073307ffcf103  movq r10, xmm10
000073307ffcf108  mov [r13+r12*1], r11
000073307ffcf10d  lea r12, [r14+0x118]
000073307ffcf114  mov [r13+r12*1], r10
000073307ffcf119  movups xmm11, [r13+rax*1]
000073307ffcf11f  lea r12, [rax+0x10]
000073307ffcf123  movups xmm10, [r13+r12*1]
000073307ffcf129  lea r12, [r14+0x130]
000073307ffcf130  movq xmm9, qword ptr [r15+0x1A0]
000073307ffcf139  movq xmm8, qword ptr [r15+0x190]
000073307ffcf142  movq r11, xmm9
000073307ffcf147  movq r10, xmm8
000073307ffcf14c  mov [r13+r12*1], r11
000073307ffcf151  lea r12, [r14+0x138]
000073307ffcf158  mov [r13+r12*1], r10
000073307ffcf15d  lea r12, [rax+0x140]
000073307ffcf164  movups xmm9, [r13+r12*1]
000073307ffcf16a  lea r12, [rax+0x150]
000073307ffcf171  movups xmm8, [r13+r12*1]
000073307ffcf177  lea r12, [r14+0xC0]
000073307ffcf17e  movups [r13+r12*1], xmm15
000073307ffcf184  lea r12, [r14+0xD0]
000073307ffcf18b  movups [r13+r12*1], xmm1
000073307ffcf191  lea r12, [rax+0x100]
000073307ffcf198  movups xmm1, [r13+r12*1]
000073307ffcf19e  lea r12, [rax+0x110]
000073307ffcf1a5  movups xmm15, [r13+r12*1]
000073307ffcf1ab  lea r12, [r14+0x140]
000073307ffcf1b2  mov r11, [r15+0xE8]
000073307ffcf1b9  mov [r13+r12*1], r11
000073307ffcf1be  lea r12, [rax+0x180]
000073307ffcf1c5  movups xmm7, [r13+r12*1]
000073307ffcf1cb  lea r12, [rax+0x190]
000073307ffcf1d2  movups xmm6, [r13+r12*1]
000073307ffcf1d8  lea r12, [rax+0x1C0]
000073307ffcf1df  movups xmm5, [r13+r12*1]
000073307ffcf1e5  lea r12, [rax+0x1D0]
000073307ffcf1ec  movups xmm4, [r13+r12*1]
000073307ffcf1f2  lea r12, [r14+0x20]
000073307ffcf1f6  movups [r13+r12*1], xmm1
000073307ffcf1fc  lea r12, [r14+0x30]
000073307ffcf200  movups [r13+r12*1], xmm13
000073307ffcf206  lea r12, [rax+0x60]
000073307ffcf20a  movups xmm1, [r13+r12*1]
000073307ffcf210  lea r12, [rax+0x70]
000073307ffcf214  movups xmm13, [r13+r12*1]
000073307ffcf21a  lea r12, [rax+0x20]
000073307ffcf21e  movups xmm3, [r13+r12*1]
000073307ffcf224  lea r12, [rax+0x30]
000073307ffcf228  movups xmm2, [r13+r12*1]
000073307ffcf22e  movaps [r15+0x1F0], xmm2
000073307ffcf236  lea r12, [r14+0x60]
000073307ffcf23a  movups [r13+r12*1], xmm11
000073307ffcf240  lea r12, [r14+0x70]
000073307ffcf244  movups [r13+r12*1], xmm5
000073307ffcf24a  lea r12, [rax+0xE0]
000073307ffcf251  movups xmm11, [r13+r12*1]
000073307ffcf257  lea r12, [rax+0xF0]
000073307ffcf25e  movups xmm5, [r13+r12*1]
000073307ffcf264  lea r12, [r14+0xA0]
000073307ffcf26b  movups [r13+r12*1], xmm13
000073307ffcf271  lea r12, [r14+0xB0]
000073307ffcf278  movups [r13+r12*1], xmm1
000073307ffcf27e  lea r12, [rax+0xA0]
000073307ffcf285  movups xmm1, [r13+r12*1]
000073307ffcf28b  lea r12, [rax+0xB0]
000073307ffcf292  movups xmm13, [r13+r12*1]
000073307ffcf298  lea r12, [rax+0x120]
000073307ffcf29f  vmovaps [rsp+0x10], xmm1
000073307ffcf2a5  movups xmm1, [r13+r12*1]
000073307ffcf2ab  lea r12, [rax+0x130]
000073307ffcf2b2  vmovaps [rsp+0x20], xmm1
000073307ffcf2b8  movups xmm1, [r13+r12*1]
000073307ffcf2be  lea r12, [rax+0x160]
000073307ffcf2c5  vmovaps [rsp+0x30], xmm1
000073307ffcf2cb  movups xmm1, [r13+r12*1]
000073307ffcf2d1  lea r12, [rax+0x170]
000073307ffcf2d8  vmovaps [rsp+0x40], xmm1
000073307ffcf2de  movups xmm1, [r13+r12*1]
000073307ffcf2e4  movaps [r15+0x2B0], xmm1
000073307ffcf2ec  lea r12, [r14+0x80]
000073307ffcf2f3  movups [r13+r12*1], xmm13
000073307ffcf2f9  lea r12, [r14+0x90]
000073307ffcf300  vmovaps xmm13, [rsp+0x10]
000073307ffcf306  movups [r13+r12*1], xmm13
000073307ffcf30c  lea r12, [rax+0x1A0]
000073307ffcf313  movups xmm13, [r13+r12*1]
000073307ffcf319  lea r12, [rax+0x1B0]
000073307ffcf320  vmovaps [rsp+0x10], xmm1
000073307ffcf326  movups xmm1, [r13+r12*1]
000073307ffcf32c  movaps [r15+0x290], xmm13
000073307ffcf334  movaps [r15+0x1E0], xmm1
000073307ffcf33c  lea r12, [rax+0x1E0]
000073307ffcf343  vmovaps [rsp+0x50], xmm1
000073307ffcf349  movups xmm1, [r13+r12*1]
000073307ffcf34f  lea r12, [rax+0x1F0]
000073307ffcf356  vmovaps [rsp+0x60], xmm1
000073307ffcf35c  movups xmm1, [r13+r12*1]
000073307ffcf362  mov qword ptr [r15+0x50], 0x430920
000073307ffcf36a  lea rax, [r14+0x40]
000073307ffcf36e  vmovaps [rsp+0x70], xmm1
000073307ffcf374  vmovaps xmm1, [rsp+0x40]
000073307ffcf37a  movups [r13+rax*1], xmm1
000073307ffcf380  lea rax, [r14+0x50]
000073307ffcf384  movups [r13+rax*1], xmm10
000073307ffcf38a  vmovaps xmm1, [rsp+0x70]
000073307ffcf390  movups [r13+r14*1], xmm1
000073307ffcf396  lea rax, [r14+0x10]
000073307ffcf39a  vmovaps xmm1, [rsp+0x60]
000073307ffcf3a0  movups [r13+rax*1], xmm1
000073307ffcf3a6  mov rax, [r15+0x40]
000073307ffcf3aa  vmovaps [rsp+0x40], xmm3
000073307ffcf3b0  vmovaps xmm1, [rsp+0x40]
000073307ffcf3b6  por xmm3, xmm1
000073307ffcf3ba  vmovaps [rsp+0x40], xmm6
000073307ffcf3c0  vmovaps xmm10, [rsp+0x40]
000073307ffcf3c6  por xmm6, xmm10
000073307ffcf3cb  lea r12, [rax+0x30]
000073307ffcf3cf  mov r11, [r13+r12*1]
000073307ffcf3d4  lea r12, [rax+0x38]
000073307ffcf3d8  mov r10, [r13+r12*1]
000073307ffcf3dd  movq xmm10, r11
000073307ffcf3e2  vmovaps [rsp+0x40], xmm1
000073307ffcf3e8  movq xmm1, r10
000073307ffcf3ed  movq xmm10, xmm10
000073307ffcf3f2  vmovaps [rsp+0x60], xmm10
000073307ffcf3f8  movq xmm10, xmm10
000073307ffcf3fd  movaps [r15+0x130], xmm10
000073307ffcf405  movq xmm1, xmm1
000073307ffcf409  vmovaps [rsp+0x70], xmm1
000073307ffcf40f  movq xmm1, xmm1
000073307ffcf413  movaps [r15+0x280], xmm1
000073307ffcf41b  vmovaps [rsp+0x80], xmm9
000073307ffcf424  vmovaps xmm1, [rsp+0x80]
000073307ffcf42d  por xmm9, xmm1
000073307ffcf432  lea r12, [rax+0x20]
000073307ffcf436  mov r11, [r13+r12*1]
000073307ffcf43b  lea r12, [rax+0x28]
000073307ffcf43f  mov r10, [r13+r12*1]
000073307ffcf444  movq xmm1, r11
000073307ffcf449  movq xmm10, r10
000073307ffcf44e  movq xmm1, xmm1
000073307ffcf452  vmovaps [rsp+0x80], xmm1
000073307ffcf45b  movq xmm1, xmm1
000073307ffcf45f  movaps [r15+0x150], xmm1
000073307ffcf467  movq xmm10, xmm10
000073307ffcf46c  vmovaps [rsp+0x90], xmm10
000073307ffcf475  movq xmm10, xmm10
000073307ffcf47a  movaps [r15+0x140], xmm10
000073307ffcf482  lea r12, [rax+0x10]
000073307ffcf486  mov r11, [r13+r12*1]
000073307ffcf48b  lea r12, [rax+0x18]
000073307ffcf48f  mov r10, [r13+r12*1]
000073307ffcf494  movq xmm1, r11
000073307ffcf499  movq xmm10, r10
000073307ffcf49e  movq xmm1, xmm1
000073307ffcf4a2  vmovaps [rsp+0xA0], xmm1
000073307ffcf4ab  movq xmm1, xmm1
000073307ffcf4af  movaps [r15+0x170], xmm1
000073307ffcf4b7  movq xmm10, xmm10
000073307ffcf4bc  vmovaps [rsp+0xB0], xmm10
000073307ffcf4c5  movq xmm10, xmm10
000073307ffcf4ca  movaps [r15+0x160], xmm10
000073307ffcf4d2  mov r12, [r13+rax*1]
000073307ffcf4d7  vmovq xmm1, r12
000073307ffcf4dc  vpbroadcastq xmm1, xmm1
000073307ffcf4e1  lea r12, [rax+0x08]
000073307ffcf4e5  mov rax, [r13+r12*1]
000073307ffcf4ea  movq xmm10, rax
000073307ffcf4ef  movaps [r15+0x230], xmm10
000073307ffcf4f7  lea rax, [r14+0x50]
000073307ffcf4fb  movups xmm10, [r13+rax*1]
000073307ffcf501  lea rax, [r14+0x60]
000073307ffcf505  vmovaps [rsp+0xC0], xmm1
000073307ffcf50e  movups xmm1, [r13+rax*1]
000073307ffcf514  lea rax, [r14+0x30]
000073307ffcf518  vmovaps [rsp+0xD0], xmm1
000073307ffcf521  movups xmm1, [r13+rax*1]
000073307ffcf527  mov qword ptr [r15+0x60], 0x430920
000073307ffcf52f  mov qword ptr [r15+0x58], 0x40
000073307ffcf537  vmovaps [rsp+0xE0], xmm1
000073307ffcf540  vmovaps [rsp+0xF0], xmm15
000073307ffcf549  vmovaps xmm15, [rsp+0xC0]
000073307ffcf552  vmovaps [rsp+0xC0], xmm14
000073307ffcf55b  vmovaps xmm14, [rsp+0x40]
000073307ffcf561  vmovaps [rsp+0x40], xmm13
000073307ffcf567  movaps xmm1, xmm15
000073307ffcf56b  mulpd xmm1, xmm14
000073307ffcf570  vcmppd xmm13, xmm1, xmm1, 0x03
000073307ffcf575  ptest xmm13, xmm13
000073307ffcf57b  jnz 0x000073307FFD0682
000073307ffcf581  movq xmm14, qword ptr [r15+0x230]
000073307ffcf58a  vmovaps [rsp+0x100], xmm14
000073307ffcf593  vpermilpd xmm14, xmm14, 0x00
000073307ffcf599  vmovaps [rsp+0x110], xmm1
000073307ffcf5a2  vmovaps xmm1, [rsp+0xE0]
000073307ffcf5ab  vmovaps [rsp+0xE0], xmm15
000073307ffcf5b4  movaps xmm13, xmm1
000073307ffcf5b8  mulpd xmm13, xmm14
000073307ffcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
000073307ffcf5c3  ptest xmm15, xmm15
000073307ffcf5c9  jnz 0x000073307FFD07C4
000073307ffcf5cf  vxorps xmm1, xmm1, xmm1
000073307ffcf5d3  vpbroadcastq xmm1, xmm1
000073307ffcf5d8  vmovaps xmm14, [rsp+0xE0]
000073307ffcf5e1  vmovaps [rsp+0xE0], xmm1
000073307ffcf5ea  vmovaps xmm1, [rsp+0xD0]
000073307ffcf5f3  vmovaps [rsp+0xD0], xmm13
000073307ffcf5fc  movaps xmm15, xmm14
000073307ffcf600  mulpd xmm15, xmm1
000073307ffcf605  vcmppd xmm13, xmm15, xmm15, 0x03
000073307ffcf60b  ptest xmm13, xmm13
000073307ffcf611  jnz 0x000073307FFD0907
000073307ffcf617  movaps xmm1, xmm14
000073307ffcf61b  mulpd xmm1, xmm10
000073307ffcf620  vcmppd xmm13, xmm1, xmm1, 0x03
000073307ffcf625  ptest xmm13, xmm13
000073307ffcf62b  jnz 0x000073307FFD0A4A
000073307ffcf631  movaps xmm13, xmm14
000073307ffcf635  mulpd xmm13, xmm2
000073307ffcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
000073307ffcf640  ptest xmm10, xmm10
000073307ffcf646  jnz 0x000073307FFD0B8C
000073307ffcf64c  vmovaps [rsp+0x120], xmm7
000073307ffcf655  vmovaps xmm14, [rsp+0x120]
000073307ffcf65e  por xmm7, xmm14
000073307ffcf663  vmovaps xmm14, [rsp+0xC0]
000073307ffcf66c  vmovaps xmm10, [rsp+0xC0]
000073307ffcf675  por xmm14, xmm10
000073307ffcf67a  vmovaps xmm2, [rsp+0x100]
000073307ffcf683  vpermilpd xmm2, xmm2, 0x00
000073307ffcf689  vmovaps [rsp+0xC0], xmm1
000073307ffcf692  vmovaps [rsp+0x120], xmm15
000073307ffcf69b  movaps xmm1, xmm10
000073307ffcf69f  mulpd xmm1, xmm2
000073307ffcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
000073307ffcf6a8  ptest xmm15, xmm15
000073307ffcf6ae  jnz 0x000073307FFD0CCF
000073307ffcf6b4  xor eax, eax
000073307ffcf6b6  mov r12d, 0x40
000073307ffcf6bc  mov r11d, 0x200
000073307ffcf6c2  cmp r12, r11
000073307ffcf6c5  cmc
000073307ffcf6c6  lahf
000073307ffcf6c7  seto al
000073307ffcf6ca  mov [r15+0x108], eax
000073307ffcf6d1  vmovaps xmm10, [rsp+0x110]
000073307ffcf6da  vmovaps xmm2, [rsp+0xE0]
000073307ffcf6e3  vmovaps [rsp+0xE0], xmm1
000073307ffcf6ec  movaps xmm15, xmm10
000073307ffcf6f0  addpd xmm15, xmm2
000073307ffcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
000073307ffcf6fb  ptest xmm1, xmm1
000073307ffcf700  jnz 0x000073307FFD0E10
000073307ffcf706  vmovaps xmm10, [rsp+0x120]
000073307ffcf70f  vmovaps [rsp+0x110], xmm15
000073307ffcf718  movaps xmm1, xmm10
000073307ffcf71c  addpd xmm1, xmm12
000073307ffcf721  vcmppd xmm15, xmm1, xmm1, 0x03
000073307ffcf726  ptest xmm15, xmm15
000073307ffcf72c  jnz 0x000073307FFD0F53
000073307ffcf732  vmovaps xmm10, [rsp+0xC0]
000073307ffcf73b  vmovaps [rsp+0xC0], xmm1
000073307ffcf744  movaps xmm15, xmm10
000073307ffcf748  addpd xmm15, xmm12
000073307ffcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
000073307ffcf753  ptest xmm1, xmm1
000073307ffcf758  jnz 0x000073307FFD1095
000073307ffcf75e  vmovaps xmm1, [rsp+0x30]
000073307ffcf764  vmovaps xmm12, [rsp+0x30]
000073307ffcf76a  por xmm1, xmm12
000073307ffcf76f  vmovaps xmm12, [rsp+0x20]
000073307ffcf775  vmovaps xmm10, [rsp+0x20]
000073307ffcf77b  por xmm12, xmm10
000073307ffcf780  vmovaps [rsp+0x20], xmm5
000073307ffcf786  vmovaps xmm10, [rsp+0x20]
000073307ffcf78c  por xmm5, xmm10
000073307ffcf791  vmovaps [rsp+0x20], xmm11
000073307ffcf797  vmovaps xmm10, [rsp+0x20]
000073307ffcf79d  por xmm11, xmm10
000073307ffcf7a2  vmovaps [rsp+0x20], xmm4
000073307ffcf7a8  vmovaps xmm10, [rsp+0x20]
000073307ffcf7ae  por xmm4, xmm10
000073307ffcf7b3  vmovaps [rsp+0x20], xmm8
000073307ffcf7b9  vmovaps xmm10, [rsp+0x20]
000073307ffcf7bf  por xmm8, xmm10
000073307ffcf7c4  vmovaps xmm10, [rsp+0xF0]
000073307ffcf7cd  vmovaps [rsp+0x20], xmm1
000073307ffcf7d3  vmovaps xmm1, [rsp+0xF0]
000073307ffcf7dc  por xmm10, xmm1
000073307ffcf7e1  lea rax, [r14+0xA0]
000073307ffcf7e8  movups xmm1, [r13+rax*1]
000073307ffcf7ee  lea rax, [r14+0xB0]
000073307ffcf7f5  vmovaps [rsp+0x30], xmm1
000073307ffcf7fb  movups xmm1, [r13+rax*1]
000073307ffcf801  vmovaps [rsp+0xF0], xmm1
000073307ffcf80a  vmovaps [rsp+0x120], xmm15
000073307ffcf813  movaps xmm1, xmm13
000073307ffcf817  addpd xmm1, xmm2
000073307ffcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
000073307ffcf820  ptest xmm15, xmm15
000073307ffcf826  jnz 0x000073307FFD11ED
000073307ffcf82c  lea rax, [r14+0xF0]
000073307ffcf833  movups xmm15, [r13+rax*1]
000073307ffcf839  vmovaps xmm2, [rsp+0xC0]
000073307ffcf842  vmovaps [rsp+0xC0], xmm1
000073307ffcf84b  vmovaps xmm1, [rsp+0xE0]
000073307ffcf854  vmovaps [rsp+0xE0], xmm15
000073307ffcf85d  movaps xmm13, xmm2
000073307ffcf861  addpd xmm13, xmm1
000073307ffcf866  vcmppd xmm15, xmm13, xmm13, 0x03
000073307ffcf86c  ptest xmm15, xmm15
000073307ffcf872  jnz 0x000073307FFD1338
000073307ffcf878  vmovaps xmm15, [rsp+0x120]
000073307ffcf881  vmovaps xmm2, [rsp+0xD0]
000073307ffcf88a  vmovaps [rsp+0xD0], xmm14
000073307ffcf893  movaps xmm1, xmm15
000073307ffcf897  addpd xmm1, xmm2
000073307ffcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
000073307ffcf8a0  ptest xmm14, xmm14
000073307ffcf8a6  jnz 0x000073307FFD147A
000073307ffcf8ac  vmovaps xmm15, [rsp+0x100]
000073307ffcf8b5  vpermilpd xmm15, xmm15, 0x00
000073307ffcf8bb  vmovaps xmm2, [rsp+0xF0]
000073307ffcf8c4  vmovaps [rsp+0xF0], xmm1
000073307ffcf8cd  movaps xmm14, xmm2
000073307ffcf8d1  mulpd xmm14, xmm15
000073307ffcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
000073307ffcf8dc  ptest xmm1, xmm1
000073307ffcf8e1  jnz 0x000073307FFD15BB
000073307ffcf8e7  vmovaps xmm1, [rsp+0xA0]
000073307ffcf8f0  vpermilpd xmm1, xmm1, 0x00
000073307ffcf8f6  vmovaps xmm2, [rsp+0xE0]
000073307ffcf8ff  vmovaps [rsp+0xE0], xmm14
000073307ffcf908  movaps xmm15, xmm2
000073307ffcf90c  mulpd xmm15, xmm1
000073307ffcf911  vcmppd xmm14, xmm15, xmm15, 0x03
000073307ffcf917  ptest xmm14, xmm14
000073307ffcf91d  jnz 0x000073307FFD16FE
000073307ffcf923  lea rax, [r14+0xE0]
000073307ffcf92a  movups xmm1, [r13+rax*1]
000073307ffcf930  vmovaps xmm14, [rsp+0x100]
000073307ffcf939  vpermilpd xmm14, xmm14, 0x00
000073307ffcf93f  vmovaps [rsp+0x100], xmm1
000073307ffcf948  vmovaps xmm1, [rsp+0x30]
000073307ffcf94e  vmovaps [rsp+0x30], xmm15
000073307ffcf954  movaps xmm2, xmm1
000073307ffcf957  mulpd xmm2, xmm14
000073307ffcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
000073307ffcf961  ptest xmm15, xmm15
000073307ffcf967  jnz 0x000073307FFD184A
000073307ffcf96d  vmovaps [rsp+0x120], xmm10
000073307ffcf976  vmovaps xmm1, [rsp+0x120]
000073307ffcf97f  por xmm10, xmm1
000073307ffcf984  movaps [r15+0x300], xmm10
000073307ffcf98c  vmovaps [rsp+0x120], xmm8
000073307ffcf995  vmovaps xmm1, [rsp+0x120]
000073307ffcf99e  por xmm8, xmm1
000073307ffcf9a3  movaps [r15+0x190], xmm8
000073307ffcf9ab  vmovaps xmm1, [rsp+0xA0]
000073307ffcf9b4  vpermilpd xmm1, xmm1, 0x00
000073307ffcf9ba  vmovaps xmm14, [rsp+0x100]
000073307ffcf9c3  vmovaps [rsp+0x100], xmm13
000073307ffcf9cc  movaps xmm15, xmm14
000073307ffcf9d0  mulpd xmm15, xmm1
000073307ffcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
000073307ffcf9db  ptest xmm13, xmm13
000073307ffcf9e1  jnz 0x000073307FFD198B
000073307ffcf9e7  lea rax, [r14+0x90]
000073307ffcf9ee  movups xmm1, [r13+rax*1]
000073307ffcf9f4  vmovaps [rsp+0x120], xmm4
000073307ffcf9fd  vmovaps xmm14, [rsp+0x120]
000073307ffcfa06  por xmm4, xmm14
000073307ffcfa0b  movaps [r15+0x1C0], xmm4
000073307ffcfa13  vmovaps [rsp+0x120], xmm11
000073307ffcfa1c  vmovaps xmm14, [rsp+0x120]
000073307ffcfa25  por xmm11, xmm14
000073307ffcfa2a  movaps [r15+0x200], xmm11
000073307ffcfa32  vmovaps [rsp+0x120], xmm5
000073307ffcfa3b  vmovaps xmm14, [rsp+0x120]
000073307ffcfa44  por xmm5, xmm14
000073307ffcfa49  movaps [r15+0x2D0], xmm5
000073307ffcfa51  vmovaps [rsp+0x120], xmm12
000073307ffcfa5a  vmovaps xmm14, [rsp+0x120]
000073307ffcfa63  por xmm12, xmm14
000073307ffcfa68  movaps [r15+0x2E0], xmm12
000073307ffcfa70  vmovaps xmm13, [rsp+0x110]
000073307ffcfa79  vmovaps [rsp+0x110], xmm1
000073307ffcfa82  vmovaps xmm1, [rsp+0xE0]
000073307ffcfa8b  vmovaps [rsp+0xE0], xmm15
000073307ffcfa94  movaps xmm14, xmm13
000073307ffcfa98  addpd xmm14, xmm1
000073307ffcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
000073307ffcfaa3  ptest xmm15, xmm15
000073307ffcfaa9  jnz 0x000073307FFD1AD8
000073307ffcfaaf  vmovaps xmm1, [rsp+0xA0]
000073307ffcfab8  vpermilpd xmm1, xmm1, 0x00
000073307ffcfabe  vmovaps xmm13, [rsp+0x110]
000073307ffcfac7  vmovaps [rsp+0x110], xmm14
000073307ffcfad0  movaps xmm15, xmm13
000073307ffcfad4  mulpd xmm15, xmm1
000073307ffcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
000073307ffcfadf  ptest xmm14, xmm14
000073307ffcfae5  jnz 0x000073307FFD1C1B
000073307ffcfaeb  lea rax, [r14+0x80]
000073307ffcfaf2  movups xmm1, [r13+rax*1]
000073307ffcfaf8  vmovaps xmm13, [rsp+0xC0]
000073307ffcfb01  vmovaps [rsp+0xC0], xmm1
000073307ffcfb0a  movaps xmm14, xmm13
000073307ffcfb0e  addpd xmm14, xmm2
000073307ffcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
000073307ffcfb19  ptest xmm1, xmm1
000073307ffcfb1e  jnz 0x000073307FFD1D68
000073307ffcfb24  vmovaps xmm13, [rsp+0x100]
000073307ffcfb2d  vmovaps xmm2, [rsp+0x30]
000073307ffcfb33  vmovaps [rsp+0x30], xmm15
000073307ffcfb39  movaps xmm1, xmm13
000073307ffcfb3d  addpd xmm1, xmm2
000073307ffcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
000073307ffcfb46  ptest xmm15, xmm15
000073307ffcfb4c  jnz 0x000073307FFD1EAB
000073307ffcfb52  vmovaps xmm15, [rsp+0x20]
000073307ffcfb58  vmovaps xmm13, [rsp+0x20]
000073307ffcfb5e  por xmm15, xmm13
000073307ffcfb63  movaps [r15+0x2F0], xmm15
000073307ffcfb6b  vmovaps xmm13, [rsp+0xA0]
000073307ffcfb74  vpermilpd xmm13, xmm13, 0x00
000073307ffcfb7a  vmovaps [rsp+0x20], xmm1
000073307ffcfb80  vmovaps xmm1, [rsp+0xC0]
000073307ffcfb89  vmovaps [rsp+0xA0], xmm15
000073307ffcfb92  movaps xmm2, xmm1
000073307ffcfb95  mulpd xmm2, xmm13
000073307ffcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
000073307ffcfb9f  ptest xmm15, xmm15
000073307ffcfba5  jnz 0x000073307FFD1FEC
000073307ffcfbab  lea rax, [r14+0xD0]
000073307ffcfbb2  movups xmm1, [r13+rax*1]
000073307ffcfbb8  vmovaps xmm13, [rsp+0xF0]
000073307ffcfbc1  vmovaps [rsp+0xC0], xmm1
000073307ffcfbca  vmovaps xmm1, [rsp+0xE0]
000073307ffcfbd3  vmovaps [rsp+0xE0], xmm14
000073307ffcfbdc  movaps xmm15, xmm13
000073307ffcfbe0  addpd xmm15, xmm1
000073307ffcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
000073307ffcfbeb  ptest xmm14, xmm14
000073307ffcfbf1  jnz 0x000073307FFD2137
000073307ffcfbf7  vmovaps xmm1, [rsp+0xB0]
000073307ffcfc00  vpermilpd xmm1, xmm1, 0x00
000073307ffcfc06  movaps xmm14, xmm11
000073307ffcfc0a  mulpd xmm14, xmm1
000073307ffcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
000073307ffcfc15  ptest xmm13, xmm13
000073307ffcfc1b  jnz 0x000073307FFD227A
000073307ffcfc21  movaps [r15+0x260], xmm14
000073307ffcfc29  vxorps xmm1, xmm1, xmm1
000073307ffcfc2d  vpbroadcastq xmm1, xmm1
000073307ffcfc32  movaps [r15+0x1B0], xmm1
000073307ffcfc3a  vmovaps xmm1, [rsp+0xB0]
000073307ffcfc43  vpermilpd xmm1, xmm1, 0x00
000073307ffcfc49  vmovaps xmm11, [rsp+0xC0]
000073307ffcfc52  vmovaps [rsp+0xC0], xmm15
000073307ffcfc5b  movaps xmm13, xmm11
000073307ffcfc5f  mulpd xmm13, xmm1
000073307ffcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
000073307ffcfc6a  ptest xmm15, xmm15
000073307ffcfc70  jnz 0x000073307FFD23BD
000073307ffcfc76  lea rax, [r14+0xC0]
000073307ffcfc7d  movups xmm1, [r13+rax*1]
000073307ffcfc83  vmovaps xmm11, [rsp+0x110]
000073307ffcfc8c  vmovaps [rsp+0xF0], xmm1
000073307ffcfc95  vmovaps xmm1, [rsp+0x30]
000073307ffcfc9b  vmovaps [rsp+0x30], xmm14
000073307ffcfca1  movaps xmm15, xmm11
000073307ffcfca5  addpd xmm15, xmm1
000073307ffcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
000073307ffcfcb0  ptest xmm14, xmm14
000073307ffcfcb6  jnz 0x000073307FFD250A
000073307ffcfcbc  vmovaps [rsp+0x100], xmm9
000073307ffcfcc5  vmovaps xmm1, [rsp+0x100]
000073307ffcfcce  por xmm9, xmm1
000073307ffcfcd3  movaps [r15+0x270], xmm9
000073307ffcfcdb  vmovaps [rsp+0x100], xmm6
000073307ffcfce4  vmovaps xmm1, [rsp+0x100]
000073307ffcfced  por xmm6, xmm1
000073307ffcfcf1  movaps [r15+0x1A0], xmm6
000073307ffcfcf9  vmovaps xmm14, [rsp+0xB0]
000073307ffcfd02  vpermilpd xmm14, xmm14, 0x00
000073307ffcfd08  vmovaps xmm6, [rsp+0xF0]
000073307ffcfd11  vmovaps [rsp+0xF0], xmm1
000073307ffcfd1a  movaps xmm11, xmm6
000073307ffcfd1e  mulpd xmm11, xmm14
000073307ffcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
000073307ffcfd29  ptest xmm1, xmm1
000073307ffcfd2e  jnz 0x000073307FFD264D
000073307ffcfd34  lea rax, [r14+0x20]
000073307ffcfd38  movups xmm1, [r13+rax*1]
000073307ffcfd3e  movaps [r15+0x110], xmm1
000073307ffcfd46  vmovaps xmm6, [rsp+0xE0]
000073307ffcfd4f  vmovaps [rsp+0xE0], xmm1
000073307ffcfd58  movaps xmm14, xmm6
000073307ffcfd5c  addpd xmm14, xmm2
000073307ffcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
000073307ffcfd67  ptest xmm1, xmm1
000073307ffcfd6c  jnz 0x000073307FFD279A
000073307ffcfd72  vmovaps xmm1, [rsp+0xB0]
000073307ffcfd7b  vpermilpd xmm1, xmm1, 0x00
000073307ffcfd81  movaps xmm6, xmm5
000073307ffcfd84  mulpd xmm6, xmm1
000073307ffcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
000073307ffcfd8d  ptest xmm2, xmm2
000073307ffcfd92  jnz 0x000073307FFD28DC
000073307ffcfd98  vmovaps xmm5, [rsp+0x20]
000073307ffcfd9e  movaps xmm1, xmm5
000073307ffcfda1  addpd xmm1, xmm13
000073307ffcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
000073307ffcfdab  ptest xmm2, xmm2
000073307ffcfdb0  jnz 0x000073307FFD2A1C
000073307ffcfdb6  vmovaps xmm13, [rsp+0x80]
000073307ffcfdbf  vpermilpd xmm13, xmm13, 0x00
000073307ffcfdc5  vmovaps xmm2, [rsp+0xE0]
000073307ffcfdce  vmovaps [rsp+0x20], xmm1
000073307ffcfdd4  movaps xmm5, xmm2
000073307ffcfdd7  mulpd xmm5, xmm13
000073307ffcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
000073307ffcfde1  ptest xmm1, xmm1
000073307ffcfde6  jnz 0x000073307FFD2B5D
000073307ffcfdec  vmovaps xmm1, [rsp+0x80]
000073307ffcfdf5  vpermilpd xmm1, xmm1, 0x00
000073307ffcfdfb  movaps xmm13, xmm10
000073307ffcfdff  mulpd xmm13, xmm1
000073307ffcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
000073307ffcfe0a  ptest xmm2, xmm2
000073307ffcfe0f  jnz 0x000073307FFD2C9E
000073307ffcfe15  vmovaps xmm10, [rsp+0x30]
000073307ffcfe1b  movaps xmm1, xmm15
000073307ffcfe1f  addpd xmm1, xmm10
000073307ffcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
000073307ffcfe29  ptest xmm2, xmm2
000073307ffcfe2e  jnz 0x000073307FFD2DE1
000073307ffcfe34  vmovaps xmm10, [rsp+0xC0]
000073307ffcfe3d  movaps xmm15, xmm10
000073307ffcfe41  addpd xmm15, xmm11
000073307ffcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
000073307ffcfe4c  ptest xmm2, xmm2
000073307ffcfe51  jnz 0x000073307FFD2F23
000073307ffcfe57  vmovaps xmm11, [rsp+0x80]
000073307ffcfe60  vpermilpd xmm11, xmm11, 0x00
000073307ffcfe66  movaps xmm10, xmm12
000073307ffcfe6a  mulpd xmm10, xmm11
000073307ffcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
000073307ffcfe75  ptest xmm2, xmm2
000073307ffcfe7a  jnz 0x000073307FFD3067
000073307ffcfe80  vmovaps xmm12, [rsp+0x80]
000073307ffcfe89  vpermilpd xmm12, xmm12, 0x00
000073307ffcfe8f  vmovaps xmm2, [rsp+0xA0]
000073307ffcfe98  vmovaps [rsp+0x30], xmm1
000073307ffcfe9e  movaps xmm11, xmm2
000073307ffcfea2  mulpd xmm11, xmm12
000073307ffcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
000073307ffcfead  ptest xmm1, xmm1
000073307ffcfeb2  jnz 0x000073307FFD31AB
000073307ffcfeb8  movaps xmm1, xmm14
000073307ffcfebc  addpd xmm1, xmm6
000073307ffcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
000073307ffcfec5  ptest xmm12, xmm12
000073307ffcfecb  jnz 0x000073307FFD32EE
000073307ffcfed1  vmovaps xmm12, [rsp+0x20]
000073307ffcfed7  movaps xmm14, xmm12
000073307ffcfedb  addpd xmm14, xmm5
000073307ffcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
000073307ffcfee6  ptest xmm6, xmm6
000073307ffcfeeb  jnz 0x000073307FFD342F
000073307ffcfef1  vmovaps xmm12, [rsp+0x90]
000073307ffcfefa  vpermilpd xmm12, xmm12, 0x00
000073307ffcff00  movaps xmm6, xmm9
000073307ffcff04  mulpd xmm6, xmm12
000073307ffcff09  vcmppd xmm5, xmm6, xmm6, 0x03
000073307ffcff0e  ptest xmm5, xmm5
000073307ffcff13  jnz 0x000073307FFD3572
000073307ffcff19  movaps xmm12, xmm15
000073307ffcff1d  addpd xmm12, xmm13
000073307ffcff22  vcmppd xmm9, xmm12, xmm12, 0x03
000073307ffcff28  ptest xmm9, xmm9
000073307ffcff2e  jnz 0x000073307FFD36B4
000073307ffcff34  vmovaps xmm13, [rsp+0x30]
000073307ffcff3a  movaps xmm15, xmm13
000073307ffcff3e  addpd xmm15, xmm10
000073307ffcff43  vcmppd xmm9, xmm15, xmm15, 0x03
000073307ffcff49  ptest xmm9, xmm9
000073307ffcff4f  jnz 0x000073307FFD37F8
000073307ffcff55  vmovaps xmm13, [rsp+0xD0]
000073307ffcff5e  vmovaps xmm10, [rsp+0xD0]
000073307ffcff67  por xmm13, xmm10
000073307ffcff6c  movaps [r15+0x250], xmm13
000073307ffcff74  vmovaps [rsp+0x20], xmm7
000073307ffcff7a  vmovaps xmm13, [rsp+0x20]
000073307ffcff80  por xmm7, xmm13
000073307ffcff85  movaps [r15+0x2A0], xmm7
000073307ffcff8d  vmovaps [rsp+0x20], xmm3
000073307ffcff93  vmovaps xmm13, [rsp+0x20]
000073307ffcff99  por xmm3, xmm13
000073307ffcff9e  movaps [r15+0x1D0], xmm3
000073307ffcffa6  lea rax, [r14+0x40]
000073307ffcffaa  movups xmm13, [r13+rax*1]
000073307ffcffb0  movaps [r15+0x2C0], xmm13
000073307ffcffb8  vmovaps xmm10, [rsp+0x90]
000073307ffcffc1  vpermilpd xmm10, xmm10, 0x00
000073307ffcffc7  movaps xmm9, xmm8
000073307ffcffcb  mulpd xmm9, xmm10
000073307ffcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
000073307ffcffd6  ptest xmm5, xmm5
000073307ffcffdb  jnz 0x000073307FFD3946
000073307ffcffe1  movaps xmm10, xmm1
000073307ffcffe5  addpd xmm10, xmm11
000073307ffcffea  vcmppd xmm8, xmm10, xmm10, 0x03
000073307ffcfff0  ptest xmm8, xmm8
000073307ffcfff6  jnz 0x000073307FFD3A8A
000073307ffcfffc  movaps xmm1, xmm14
000073307ffd0000  addpd xmm1, xmm6
000073307ffd0004  vcmppd xmm11, xmm1, xmm1, 0x03
000073307ffd0009  ptest xmm11, xmm11
000073307ffd000f  jnz 0x000073307FFD3BCD
000073307ffd0015  vmovaps xmm14, [rsp+0x90]
000073307ffd001e  vpermilpd xmm14, xmm14, 0x00
000073307ffd0024  movaps xmm11, xmm13
000073307ffd0028  mulpd xmm11, xmm14
000073307ffd002d  vcmppd xmm8, xmm11, xmm11, 0x03
000073307ffd0033  ptest xmm8, xmm8
000073307ffd0039  jnz 0x000073307FFD3D0E
000073307ffd003f  vmovaps xmm14, [rsp+0x90]
000073307ffd0048  vpermilpd xmm14, xmm14, 0x00
000073307ffd004e  vmovaps xmm8, [rsp+0x10]
000073307ffd0054  movaps xmm13, xmm8
000073307ffd0058  mulpd xmm13, xmm14
000073307ffd005d  vcmppd xmm6, xmm13, xmm13, 0x03
000073307ffd0063  ptest xmm6, xmm6
000073307ffd0068  jnz 0x000073307FFD3E52
000073307ffd006e  vmovaps xmm14, [rsp+0x60]
000073307ffd0074  vpermilpd xmm14, xmm14, 0x00
000073307ffd007a  movaps xmm8, xmm7
000073307ffd007e  mulpd xmm8, xmm14
000073307ffd0083  vcmppd xmm6, xmm8, xmm8, 0x03
000073307ffd0089  ptest xmm6, xmm6
000073307ffd008e  jnz 0x000073307FFD3F96
000073307ffd0094  movaps xmm14, xmm12
000073307ffd0098  addpd xmm14, xmm9
000073307ffd009d  vcmppd xmm7, xmm14, xmm14, 0x03
000073307ffd00a3  ptest xmm7, xmm7
000073307ffd00a8  jnz 0x000073307FFD40D9
000073307ffd00ae  vmovaps xmm12, [rsp+0x60]
000073307ffd00b4  vpermilpd xmm12, xmm12, 0x00
000073307ffd00ba  vmovaps xmm7, [rsp+0xF0]
000073307ffd00c3  movaps xmm9, xmm7
000073307ffd00c7  mulpd xmm9, xmm12
000073307ffd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
000073307ffd00d2  ptest xmm6, xmm6
000073307ffd00d7  jnz 0x000073307FFD421D
000073307ffd00dd  movaps xmm12, xmm15
000073307ffd00e1  addpd xmm12, xmm11
000073307ffd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
000073307ffd00ec  ptest xmm7, xmm7
000073307ffd00f1  jnz 0x000073307FFD4360
000073307ffd00f7  vmovaps xmm15, [rsp+0x60]
000073307ffd00fd  vpermilpd xmm15, xmm15, 0x00
000073307ffd0103  vmovaps xmm7, [rsp+0x40]
000073307ffd0109  movaps xmm11, xmm7
000073307ffd010d  mulpd xmm11, xmm15
000073307ffd0112  vcmppd xmm6, xmm11, xmm11, 0x03
000073307ffd0118  ptest xmm6, xmm6
000073307ffd011d  jnz 0x000073307FFD44A4
000073307ffd0123  movaps xmm15, xmm10
000073307ffd0127  addpd xmm15, xmm13
000073307ffd012c  vcmppd xmm7, xmm15, xmm15, 0x03
000073307ffd0132  ptest xmm7, xmm7
000073307ffd0137  jnz 0x000073307FFD45E7
000073307ffd013d  vmovaps xmm13, [rsp+0x60]
000073307ffd0143  vpermilpd xmm13, xmm13, 0x00
000073307ffd0149  vmovaps xmm7, [rsp+0x50]
000073307ffd014f  movaps xmm10, xmm7
000073307ffd0153  mulpd xmm10, xmm13
000073307ffd0158  vcmppd xmm6, xmm10, xmm10, 0x03
000073307ffd015e  ptest xmm6, xmm6
000073307ffd0163  jnz 0x000073307FFD472B
000073307ffd0169  movaps xmm13, xmm1
000073307ffd016d  addpd xmm13, xmm8
000073307ffd0172  vcmppd xmm7, xmm13, xmm13, 0x03
000073307ffd0178  ptest xmm7, xmm7
000073307ffd017d  jnz 0x000073307FFD486E
000073307ffd0183  lea rax, [r14+0x70]
000073307ffd0187  movups xmm1, [r13+rax*1]
000073307ffd018d  movaps [r15+0x240], xmm1
000073307ffd0195  movaps xmm8, xmm14
000073307ffd0199  addpd xmm8, xmm9
000073307ffd019e  vcmppd xmm7, xmm8, xmm8, 0x03
000073307ffd01a4  ptest xmm7, xmm7
000073307ffd01a9  jnz 0x000073307FFD49BB
000073307ffd01af  movaps [r15+0x170], xmm8
000073307ffd01b7  vmovaps xmm14, [rsp+0x70]
000073307ffd01bd  vpermilpd xmm14, xmm14, 0x00
000073307ffd01c3  movaps xmm9, xmm1
000073307ffd01c7  mulpd xmm9, xmm14
000073307ffd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
000073307ffd01d2  ptest xmm7, xmm7
000073307ffd01d7  jnz 0x000073307FFD4AFF
000073307ffd01dd  vmovaps xmm1, [rsp+0x70]
000073307ffd01e3  vpermilpd xmm1, xmm1, 0x00
000073307ffd01e9  movaps xmm14, xmm4
000073307ffd01ed  mulpd xmm14, xmm1
000073307ffd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
000073307ffd01f8  ptest xmm7, xmm7
000073307ffd01fd  jnz 0x000073307FFD4C42
000073307ffd0203  movaps [r15+0x180], xmm14
000073307ffd020b  movaps xmm1, xmm12
000073307ffd020f  addpd xmm1, xmm11
000073307ffd0214  vcmppd xmm7, xmm1, xmm1, 0x03
000073307ffd0219  ptest xmm7, xmm7
000073307ffd021e  jnz 0x000073307FFD4D84
000073307ffd0224  movaps [r15+0x210], xmm1
000073307ffd022c  movups xmm12, [r13+r14*1]
000073307ffd0232  lea rax, [r14+0x10]
000073307ffd0236  movups xmm11, [r13+rax*1]
000073307ffd023c  movaps [r15+0x230], xmm11
000073307ffd0244  movaps xmm7, xmm15
000073307ffd0248  addpd xmm7, xmm10
000073307ffd024d  vcmppd xmm6, xmm7, xmm7, 0x03
000073307ffd0252  ptest xmm6, xmm6
000073307ffd0257  jnz 0x000073307FFD4EDA
000073307ffd025d  movaps [r15+0x130], xmm7
000073307ffd0265  vmovaps xmm15, [rsp+0x70]
000073307ffd026b  vpermilpd xmm15, xmm15, 0x00
000073307ffd0271  movaps xmm10, xmm11
000073307ffd0275  mulpd xmm10, xmm15
000073307ffd027a  vcmppd xmm6, xmm10, xmm10, 0x03
000073307ffd0280  ptest xmm6, xmm6
000073307ffd0285  jnz 0x000073307FFD501C
000073307ffd028b  movaps [r15+0x220], xmm10
000073307ffd0293  vmovaps xmm15, [rsp+0x70]
000073307ffd0299  vpermilpd xmm15, xmm15, 0x00
000073307ffd029f  movaps xmm11, xmm12
000073307ffd02a3  mulpd xmm11, xmm15
000073307ffd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
000073307ffd02ae  ptest xmm6, xmm6
000073307ffd02b3  jnz 0x000073307FFD5160
000073307ffd02b9  movaps xmm15, xmm13
000073307ffd02bd  addpd xmm15, xmm9
000073307ffd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
000073307ffd02c8  ptest xmm12, xmm12
000073307ffd02ce  jnz 0x000073307FFD52A4
000073307ffd02d4  movaps [r15+0x140], xmm15
000073307ffd02dc  movaps xmm13, xmm8
000073307ffd02e0  addpd xmm13, xmm14
000073307ffd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
000073307ffd02eb  ptest xmm12, xmm12
000073307ffd02f1  jnz 0x000073307FFD53E8
000073307ffd02f7  movaps [r15+0x150], xmm13
000073307ffd02ff  movaps xmm14, xmm1
000073307ffd0303  addpd xmm14, xmm10
000073307ffd0308  vcmppd xmm12, xmm14, xmm14, 0x03
000073307ffd030e  ptest xmm12, xmm12
000073307ffd0314  jnz 0x000073307FFD552C
000073307ffd031a  movaps [r15+0x160], xmm14
000073307ffd0322  movaps xmm1, xmm7
000073307ffd0325  addpd xmm1, xmm11
000073307ffd032a  vcmppd xmm12, xmm1, xmm1, 0x03
000073307ffd032f  ptest xmm12, xmm12
000073307ffd0335  jnz 0x000073307FFD566F
000073307ffd033b  movaps [r15+0x120], xmm1
000073307ffd0343  mov eax, 0x430920
000073307ffd0348  movups [r13+rax*1], xmm15
000073307ffd034e  mov eax, 0x430930
000073307ffd0353  movups [r13+rax*1], xmm13
000073307ffd0359  mov eax, 0x430940
000073307ffd035e  movups [r13+rax*1], xmm14
000073307ffd0364  mov eax, 0x430950
000073307ffd0369  movups [r13+rax*1], xmm1
000073307ffd036f  mov eax, [r15+0x108]
000073307ffd0376  sahf
000073307ffd0377  jnz 0x000073307FFD03A9
000073307ffd0379  cmp dword ptr [r15+0x318], 0x00
000073307ffd0381  jz 0x000073307FFDB900
000073307ffd0387  nop [rax+rax*1], ax
000073307ffd0390  nop [rax+rax*1], eax
000073307ffd0398  mov eax, 0x410444
000073307ffd039d  mov [r15+0x100], rax
000073307ffd03a4  jmp 0x000073307FDFE110
000073307ffd03a9  cmp dword ptr [r15+0x318], 0x00
000073307ffd03b1  jz 0x000073307FFD57E0
000073307ffd03b7  nop [rax+rax*1], ax
000073307ffd03c0  nop [rax+rax*1], eax
000073307ffd03c8  mov eax, 0x410278
000073307ffd03cd  mov [r15+0x100], rax
000073307ffd03d4  jmp 0x000073307FDFE110
000073307ffd03d9  int3
000073307ffd03da  call 0x000073307FEB52F0
000073307ffd03df  jmp 0x000073307FFCF016
000073307ffd03e4  call 0x000073307FEC4620
000073307ffd03e9  jmp 0x000073307FFCF023
000073307ffd03ee  call 0x000073307FEC33A0
000073307ffd03f3  jmp 0x000073307FFCF035
000073307ffd03f8  call 0x000073307FEC2120
000073307ffd03fd  jmp 0x000073307FFCF03F
000073307ffd0402  call 0x000073307FEC0860
000073307ffd0407  jmp 0x000073307FFCF067
000073307ffd040c  call 0x000073307FEBF5F0
000073307ffd0411  jmp 0x000073307FFCF073
000073307ffd0416  call 0x000073307FEC0860
000073307ffd041b  jmp 0x000073307FFCF0A5
000073307ffd0420  call 0x000073307FEBF5F0
000073307ffd0425  jmp 0x000073307FFCF0B1
000073307ffd042a  call 0x000073307FEC4740
000073307ffd042f  jmp 0x000073307FFCF0BE
000073307ffd0434  call 0x000073307FEB5400
000073307ffd0439  jmp 0x000073307FFCF0CB
000073307ffd043e  call 0x000073307FEB52F0
000073307ffd0443  jmp 0x000073307FFCF0D8
000073307ffd0448  call 0x000073307FEC4620
000073307ffd044d  jmp 0x000073307FFCF0E5
000073307ffd0452  call 0x000073307FEC0860
000073307ffd0457  jmp 0x000073307FFCF10D
000073307ffd045c  call 0x000073307FEBF5F0
000073307ffd0461  jmp 0x000073307FFCF119
000073307ffd0466  call 0x000073307FE09D70
000073307ffd046b  jmp 0x000073307FFCF11F
000073307ffd0470  call 0x000073307FEBE9C0
000073307ffd0475  jmp 0x000073307FFCF129
000073307ffd047a  call 0x000073307FEC0860
000073307ffd047f  jmp 0x000073307FFCF151
000073307ffd0484  call 0x000073307FEBF5F0
000073307ffd0489  jmp 0x000073307FFCF15D
000073307ffd048e  call 0x000073307FEBD750
000073307ffd0493  jmp 0x000073307FFCF16A
000073307ffd0498  call 0x000073307FEBC4E0
000073307ffd049d  jmp 0x000073307FFCF177
000073307ffd04a2  call 0x000073307FEC4740
000073307ffd04a7  jmp 0x000073307FFCF184
000073307ffd04ac  call 0x000073307FEB5400
000073307ffd04b1  jmp 0x000073307FFCF191
000073307ffd04b6  call 0x000073307FEB52F0
000073307ffd04bb  jmp 0x000073307FFCF19E
000073307ffd04c0  call 0x000073307FEC4620
000073307ffd04c5  jmp 0x000073307FFCF1AB
000073307ffd04ca  call 0x000073307FEC0860
000073307ffd04cf  jmp 0x000073307FFCF1BE
000073307ffd04d4  call 0x000073307FEBB270
000073307ffd04d9  jmp 0x000073307FFCF1CB
000073307ffd04de  call 0x000073307FEBA000
000073307ffd04e3  jmp 0x000073307FFCF1D8
000073307ffd04e8  call 0x000073307FEB8D90
000073307ffd04ed  jmp 0x000073307FFCF1E5
000073307ffd04f2  call 0x000073307FEB8A20
000073307ffd04f7  jmp 0x000073307FFCF1F2
000073307ffd04fc  call 0x000073307FEB5400
000073307ffd0501  jmp 0x000073307FFCF1FC
000073307ffd0506  call 0x000073307FEC2240
000073307ffd050b  jmp 0x000073307FFCF206
000073307ffd0510  call 0x000073307FEB52F0
000073307ffd0515  jmp 0x000073307FFCF210
000073307ffd051a  call 0x000073307FEC2120
000073307ffd051f  jmp 0x000073307FFCF21A
000073307ffd0524  call 0x000073307FEB77B0
000073307ffd0529  jmp 0x000073307FFCF224
000073307ffd052e  call 0x000073307FEB6550
000073307ffd0533  jmp 0x000073307FFCF22E
000073307ffd0538  call 0x000073307FEBFD50
000073307ffd053d  jmp 0x000073307FFCF240
000073307ffd0542  call 0x000073307FEB8EA0
000073307ffd0547  jmp 0x000073307FFCF24A
000073307ffd054c  call 0x000073307FEBFC30
000073307ffd0551  jmp 0x000073307FFCF257
000073307ffd0556  call 0x000073307FEB8D90
000073307ffd055b  jmp 0x000073307FFCF264
000073307ffd0560  call 0x000073307FEC2240
000073307ffd0565  jmp 0x000073307FFCF271
000073307ffd056a  call 0x000073307FEB5400
000073307ffd056f  jmp 0x000073307FFCF27E
000073307ffd0574  call 0x000073307FEB52F0
000073307ffd0579  jmp 0x000073307FFCF28B
000073307ffd057e  call 0x000073307FEC2120
000073307ffd0583  jmp 0x000073307FFCF298
000073307ffd0588  call 0x000073307FEB52F0
000073307ffd058d  jmp 0x000073307FFCF2AB
000073307ffd0592  call 0x000073307FEB52F0
000073307ffd0597  jmp 0x000073307FFCF2BE
000073307ffd059c  call 0x000073307FEB52F0
000073307ffd05a1  jmp 0x000073307FFCF2D1
000073307ffd05a6  call 0x000073307FEB52F0
000073307ffd05ab  jmp 0x000073307FFCF2E4
000073307ffd05b0  call 0x000073307FEC2240
000073307ffd05b5  jmp 0x000073307FFCF2F9
000073307ffd05ba  call 0x000073307FEC2240
000073307ffd05bf  jmp 0x000073307FFCF30C
000073307ffd05c4  call 0x000073307FEC2120
000073307ffd05c9  jmp 0x000073307FFCF319
000073307ffd05ce  call 0x000073307FEB52F0
000073307ffd05d3  jmp 0x000073307FFCF32C
000073307ffd05d8  call 0x000073307FEB52F0
000073307ffd05dd  jmp 0x000073307FFCF34F
000073307ffd05e2  call 0x000073307FEB52F0
000073307ffd05e7  jmp 0x000073307FFCF362
000073307ffd05ec  call 0x000073307FDFF540
000073307ffd05f1  jmp 0x000073307FFCF380
000073307ffd05f6  call 0x000073307FE08C20
000073307ffd05fb  jmp 0x000073307FFCF38A
000073307ffd0600  call 0x000073307FED6600
000073307ffd0605  jmp 0x000073307FFCF396
000073307ffd060a  call 0x000073307FDFF540
000073307ffd060f  jmp 0x000073307FFCF3A6
000073307ffd0614  call 0x000073307FEC0370
000073307ffd0619  jmp 0x000073307FFCF3D4
000073307ffd061e  call 0x000073307FEBF100
000073307ffd0623  jmp 0x000073307FFCF3DD
000073307ffd0628  call 0x000073307FEC0370
000073307ffd062d  jmp 0x000073307FFCF43B
000073307ffd0632  call 0x000073307FEBF100
000073307ffd0637  jmp 0x000073307FFCF444
000073307ffd063c  call 0x000073307FEC0370
000073307ffd0641  jmp 0x000073307FFCF48B
000073307ffd0646  call 0x000073307FEBF100
000073307ffd064b  jmp 0x000073307FFCF494
000073307ffd0650  call 0x000073307FE0B720
000073307ffd0655  jmp 0x000073307FFCF4D7
000073307ffd065a  call 0x000073307FEB47C0
000073307ffd065f  jmp 0x000073307FFCF4EA
000073307ffd0664  call 0x000073307FE08B00
000073307ffd0669  jmp 0x000073307FFCF501
000073307ffd066e  call 0x000073307FDFF430
000073307ffd0673  jmp 0x000073307FFCF514
000073307ffd0678  call 0x000073307FDFF430
000073307ffd067d  jmp 0x000073307FFCF527
000073307ffd0682  sub rsp, 0x08
000073307ffd0686  push rax
000073307ffd0687  push rcx
000073307ffd0688  push rdx
000073307ffd0689  push rdi
000073307ffd068a  push rsi
000073307ffd068b  push r8
000073307ffd068d  push r9
000073307ffd068f  push r10
000073307ffd0691  push r11
000073307ffd0693  sub rsp, 0xF0
000073307ffd069a  vmovaps [rsp], xmm0
000073307ffd069f  vmovaps [rsp+0x10], xmm2
000073307ffd06a5  vmovaps [rsp+0x20], xmm3
000073307ffd06ab  vmovaps [rsp+0x30], xmm4
000073307ffd06b1  vmovaps [rsp+0x40], xmm5
000073307ffd06b7  vmovaps [rsp+0x50], xmm6
000073307ffd06bd  vmovaps [rsp+0x60], xmm7
000073307ffd06c3  vmovaps [rsp+0x70], xmm8
000073307ffd06c9  vmovaps [rsp+0x80], xmm9
000073307ffd06d2  vmovaps [rsp+0x90], xmm10
000073307ffd06db  vmovaps [rsp+0xA0], xmm11
000073307ffd06e4  vmovaps [rsp+0xB0], xmm12
000073307ffd06ed  vmovaps [rsp+0xC0], xmm13
000073307ffd06f6  vmovaps [rsp+0xD0], xmm14
000073307ffd06ff  vmovaps [rsp+0xE0], xmm15
000073307ffd0708  sub rsp, 0x30
000073307ffd070c  movaps [rsp], xmm1
000073307ffd0710  movaps [rsp+0x10], xmm15
000073307ffd0716  movaps [rsp+0x20], xmm14
000073307ffd071c  lea rdi, [rsp]
000073307ffd0720  mov esi, 0x00
000073307ffd0725  mov rax, 0x600DE0EC8530
000073307ffd072f  call rax
000073307ffd0731  movaps xmm1, [rsp]
000073307ffd0735  add rsp, 0x30
000073307ffd0739  vmovaps xmm0, [rsp]
000073307ffd073e  vmovaps xmm2, [rsp+0x10]
000073307ffd0744  vmovaps xmm3, [rsp+0x20]
000073307ffd074a  vmovaps xmm4, [rsp+0x30]
000073307ffd0750  vmovaps xmm5, [rsp+0x40]
000073307ffd0756  vmovaps xmm6, [rsp+0x50]
000073307ffd075c  vmovaps xmm7, [rsp+0x60]
000073307ffd0762  vmovaps xmm8, [rsp+0x70]
000073307ffd0768  vmovaps xmm9, [rsp+0x80]
000073307ffd0771  vmovaps xmm10, [rsp+0x90]
000073307ffd077a  vmovaps xmm11, [rsp+0xA0]
000073307ffd0783  vmovaps xmm12, [rsp+0xB0]
000073307ffd078c  vmovaps xmm13, [rsp+0xC0]
000073307ffd0795  vmovaps xmm14, [rsp+0xD0]
000073307ffd079e  vmovaps xmm15, [rsp+0xE0]
000073307ffd07a7  add rsp, 0xF0
000073307ffd07ae  pop r11
000073307ffd07b0  pop r10
000073307ffd07b2  pop r9
000073307ffd07b4  pop r8
000073307ffd07b6  pop rsi
000073307ffd07b7  pop rdi
000073307ffd07b8  pop rdx
000073307ffd07b9  pop rcx
000073307ffd07ba  pop rax
000073307ffd07bb  add rsp, 0x08
000073307ffd07bf  jmp 0x000073307FFCF581
000073307ffd07c4  sub rsp, 0x08
000073307ffd07c8  push rax
000073307ffd07c9  push rcx
000073307ffd07ca  push rdx
000073307ffd07cb  push rdi
000073307ffd07cc  push rsi
000073307ffd07cd  push r8
000073307ffd07cf  push r9
000073307ffd07d1  push r10
000073307ffd07d3  push r11
000073307ffd07d5  sub rsp, 0xF0
000073307ffd07dc  vmovaps [rsp], xmm0
000073307ffd07e1  vmovaps [rsp+0x10], xmm1
000073307ffd07e7  vmovaps [rsp+0x20], xmm2
000073307ffd07ed  vmovaps [rsp+0x30], xmm3
000073307ffd07f3  vmovaps [rsp+0x40], xmm4
000073307ffd07f9  vmovaps [rsp+0x50], xmm5
000073307ffd07ff  vmovaps [rsp+0x60], xmm6
000073307ffd0805  vmovaps [rsp+0x70], xmm7
000073307ffd080b  vmovaps [rsp+0x80], xmm8
000073307ffd0814  vmovaps [rsp+0x90], xmm9
000073307ffd081d  vmovaps [rsp+0xA0], xmm10
000073307ffd0826  vmovaps [rsp+0xB0], xmm11
000073307ffd082f  vmovaps [rsp+0xC0], xmm12
000073307ffd0838  vmovaps [rsp+0xD0], xmm14
000073307ffd0841  vmovaps [rsp+0xE0], xmm15
000073307ffd084a  sub rsp, 0x30
000073307ffd084e  movaps [rsp], xmm13
000073307ffd0853  movaps [rsp+0x10], xmm1
000073307ffd0858  movaps [rsp+0x20], xmm14
000073307ffd085e  lea rdi, [rsp]
000073307ffd0862  mov esi, 0x00
000073307ffd0867  mov rax, 0x600DE0EC8530
000073307ffd0871  call rax
000073307ffd0873  movaps xmm13, [rsp]
000073307ffd0878  add rsp, 0x30
000073307ffd087c  vmovaps xmm0, [rsp]
000073307ffd0881  vmovaps xmm1, [rsp+0x10]
000073307ffd0887  vmovaps xmm2, [rsp+0x20]
000073307ffd088d  vmovaps xmm3, [rsp+0x30]
000073307ffd0893  vmovaps xmm4, [rsp+0x40]
000073307ffd0899  vmovaps xmm5, [rsp+0x50]
000073307ffd089f  vmovaps xmm6, [rsp+0x60]
000073307ffd08a5  vmovaps xmm7, [rsp+0x70]
000073307ffd08ab  vmovaps xmm8, [rsp+0x80]
000073307ffd08b4  vmovaps xmm9, [rsp+0x90]
000073307ffd08bd  vmovaps xmm10, [rsp+0xA0]
000073307ffd08c6  vmovaps xmm11, [rsp+0xB0]
000073307ffd08cf  vmovaps xmm12, [rsp+0xC0]
000073307ffd08d8  vmovaps xmm14, [rsp+0xD0]
000073307ffd08e1  vmovaps xmm15, [rsp+0xE0]
000073307ffd08ea  add rsp, 0xF0
000073307ffd08f1  pop r11
000073307ffd08f3  pop r10
000073307ffd08f5  pop r9
000073307ffd08f7  pop r8
000073307ffd08f9  pop rsi
000073307ffd08fa  pop rdi
000073307ffd08fb  pop rdx
000073307ffd08fc  pop rcx
000073307ffd08fd  pop rax
000073307ffd08fe  add rsp, 0x08
000073307ffd0902  jmp 0x000073307FFCF5CF
000073307ffd0907  sub rsp, 0x08
000073307ffd090b  push rax
000073307ffd090c  push rcx
000073307ffd090d  push rdx
000073307ffd090e  push rdi
000073307ffd090f  push rsi
000073307ffd0910  push r8
000073307ffd0912  push r9
000073307ffd0914  push r10
000073307ffd0916  push r11
000073307ffd0918  sub rsp, 0xF0
000073307ffd091f  vmovaps [rsp], xmm0
000073307ffd0924  vmovaps [rsp+0x10], xmm1
000073307ffd092a  vmovaps [rsp+0x20], xmm2
000073307ffd0930  vmovaps [rsp+0x30], xmm3
000073307ffd0936  vmovaps [rsp+0x40], xmm4
000073307ffd093c  vmovaps [rsp+0x50], xmm5
000073307ffd0942  vmovaps [rsp+0x60], xmm6
000073307ffd0948  vmovaps [rsp+0x70], xmm7
000073307ffd094e  vmovaps [rsp+0x80], xmm8
000073307ffd0957  vmovaps [rsp+0x90], xmm9
000073307ffd0960  vmovaps [rsp+0xA0], xmm10
000073307ffd0969  vmovaps [rsp+0xB0], xmm11
000073307ffd0972  vmovaps [rsp+0xC0], xmm12
000073307ffd097b  vmovaps [rsp+0xD0], xmm13
000073307ffd0984  vmovaps [rsp+0xE0], xmm14
000073307ffd098d  sub rsp, 0x30
000073307ffd0991  movaps [rsp], xmm15
000073307ffd0996  movaps [rsp+0x10], xmm14
000073307ffd099c  movaps [rsp+0x20], xmm1
000073307ffd09a1  lea rdi, [rsp]
000073307ffd09a5  mov esi, 0x00
000073307ffd09aa  mov rax, 0x600DE0EC8530
000073307ffd09b4  call rax
000073307ffd09b6  movaps xmm15, [rsp]
000073307ffd09bb  add rsp, 0x30
000073307ffd09bf  vmovaps xmm0, [rsp]
000073307ffd09c4  vmovaps xmm1, [rsp+0x10]
000073307ffd09ca  vmovaps xmm2, [rsp+0x20]
000073307ffd09d0  vmovaps xmm3, [rsp+0x30]
000073307ffd09d6  vmovaps xmm4, [rsp+0x40]
000073307ffd09dc  vmovaps xmm5, [rsp+0x50]
000073307ffd09e2  vmovaps xmm6, [rsp+0x60]
000073307ffd09e8  vmovaps xmm7, [rsp+0x70]
000073307ffd09ee  vmovaps xmm8, [rsp+0x80]
000073307ffd09f7  vmovaps xmm9, [rsp+0x90]
000073307ffd0a00  vmovaps xmm10, [rsp+0xA0]
000073307ffd0a09  vmovaps xmm11, [rsp+0xB0]
000073307ffd0a12  vmovaps xmm12, [rsp+0xC0]
000073307ffd0a1b  vmovaps xmm13, [rsp+0xD0]
000073307ffd0a24  vmovaps xmm14, [rsp+0xE0]
000073307ffd0a2d  add rsp, 0xF0
000073307ffd0a34  pop r11
000073307ffd0a36  pop r10
000073307ffd0a38  pop r9
000073307ffd0a3a  pop r8
000073307ffd0a3c  pop rsi
000073307ffd0a3d  pop rdi
000073307ffd0a3e  pop rdx
000073307ffd0a3f  pop rcx
000073307ffd0a40  pop rax
000073307ffd0a41  add rsp, 0x08
000073307ffd0a45  jmp 0x000073307FFCF617
000073307ffd0a4a  sub rsp, 0x08
000073307ffd0a4e  push rax
000073307ffd0a4f  push rcx
000073307ffd0a50  push rdx
000073307ffd0a51  push rdi
000073307ffd0a52  push rsi
000073307ffd0a53  push r8
000073307ffd0a55  push r9
000073307ffd0a57  push r10
000073307ffd0a59  push r11
000073307ffd0a5b  sub rsp, 0xF0
000073307ffd0a62  vmovaps [rsp], xmm0
000073307ffd0a67  vmovaps [rsp+0x10], xmm2
000073307ffd0a6d  vmovaps [rsp+0x20], xmm3
000073307ffd0a73  vmovaps [rsp+0x30], xmm4
000073307ffd0a79  vmovaps [rsp+0x40], xmm5
000073307ffd0a7f  vmovaps [rsp+0x50], xmm6
000073307ffd0a85  vmovaps [rsp+0x60], xmm7
000073307ffd0a8b  vmovaps [rsp+0x70], xmm8
000073307ffd0a91  vmovaps [rsp+0x80], xmm9
000073307ffd0a9a  vmovaps [rsp+0x90], xmm10
000073307ffd0aa3  vmovaps [rsp+0xA0], xmm11
000073307ffd0aac  vmovaps [rsp+0xB0], xmm12
000073307ffd0ab5  vmovaps [rsp+0xC0], xmm13
000073307ffd0abe  vmovaps [rsp+0xD0], xmm14
000073307ffd0ac7  vmovaps [rsp+0xE0], xmm15
000073307ffd0ad0  sub rsp, 0x30
000073307ffd0ad4  movaps [rsp], xmm1
000073307ffd0ad8  movaps [rsp+0x10], xmm14
000073307ffd0ade  movaps [rsp+0x20], xmm10
000073307ffd0ae4  lea rdi, [rsp]
000073307ffd0ae8  mov esi, 0x00
000073307ffd0aed  mov rax, 0x600DE0EC8530
000073307ffd0af7  call rax
000073307ffd0af9  movaps xmm1, [rsp]
000073307ffd0afd  add rsp, 0x30
000073307ffd0b01  vmovaps xmm0, [rsp]
000073307ffd0b06  vmovaps xmm2, [rsp+0x10]
000073307ffd0b0c  vmovaps xmm3, [rsp+0x20]
000073307ffd0b12  vmovaps xmm4, [rsp+0x30]
000073307ffd0b18  vmovaps xmm5, [rsp+0x40]
000073307ffd0b1e  vmovaps xmm6, [rsp+0x50]
000073307ffd0b24  vmovaps xmm7, [rsp+0x60]
000073307ffd0b2a  vmovaps xmm8, [rsp+0x70]
000073307ffd0b30  vmovaps xmm9, [rsp+0x80]
000073307ffd0b39  vmovaps xmm10, [rsp+0x90]
000073307ffd0b42  vmovaps xmm11, [rsp+0xA0]
000073307ffd0b4b  vmovaps xmm12, [rsp+0xB0]
000073307ffd0b54  vmovaps xmm13, [rsp+0xC0]
000073307ffd0b5d  vmovaps xmm14, [rsp+0xD0]
000073307ffd0b66  vmovaps xmm15, [rsp+0xE0]
000073307ffd0b6f  add rsp, 0xF0
000073307ffd0b76  pop r11
000073307ffd0b78  pop r10
000073307ffd0b7a  pop r9
000073307ffd0b7c  pop r8
000073307ffd0b7e  pop rsi
000073307ffd0b7f  pop rdi
000073307ffd0b80  pop rdx
000073307ffd0b81  pop rcx
000073307ffd0b82  pop rax
000073307ffd0b83  add rsp, 0x08
000073307ffd0b87  jmp 0x000073307FFCF631
000073307ffd0b8c  sub rsp, 0x08
000073307ffd0b90  push rax
000073307ffd0b91  push rcx
000073307ffd0b92  push rdx
000073307ffd0b93  push rdi
000073307ffd0b94  push rsi
000073307ffd0b95  push r8
000073307ffd0b97  push r9
000073307ffd0b99  push r10
000073307ffd0b9b  push r11
000073307ffd0b9d  sub rsp, 0xF0
000073307ffd0ba4  vmovaps [rsp], xmm0
000073307ffd0ba9  vmovaps [rsp+0x10], xmm1
000073307ffd0baf  vmovaps [rsp+0x20], xmm2
000073307ffd0bb5  vmovaps [rsp+0x30], xmm3
000073307ffd0bbb  vmovaps [rsp+0x40], xmm4
000073307ffd0bc1  vmovaps [rsp+0x50], xmm5
000073307ffd0bc7  vmovaps [rsp+0x60], xmm6
000073307ffd0bcd  vmovaps [rsp+0x70], xmm7
000073307ffd0bd3  vmovaps [rsp+0x80], xmm8
000073307ffd0bdc  vmovaps [rsp+0x90], xmm9
000073307ffd0be5  vmovaps [rsp+0xA0], xmm10
000073307ffd0bee  vmovaps [rsp+0xB0], xmm11
000073307ffd0bf7  vmovaps [rsp+0xC0], xmm12
000073307ffd0c00  vmovaps [rsp+0xD0], xmm14
000073307ffd0c09  vmovaps [rsp+0xE0], xmm15
000073307ffd0c12  sub rsp, 0x30
000073307ffd0c16  movaps [rsp], xmm13
000073307ffd0c1b  movaps [rsp+0x10], xmm14
000073307ffd0c21  movaps [rsp+0x20], xmm2
000073307ffd0c26  lea rdi, [rsp]
000073307ffd0c2a  mov esi, 0x00
000073307ffd0c2f  mov rax, 0x600DE0EC8530
000073307ffd0c39  call rax
000073307ffd0c3b  movaps xmm13, [rsp]
000073307ffd0c40  add rsp, 0x30
000073307ffd0c44  vmovaps xmm0, [rsp]
000073307ffd0c49  vmovaps xmm1, [rsp+0x10]
000073307ffd0c4f  vmovaps xmm2, [rsp+0x20]
000073307ffd0c55  vmovaps xmm3, [rsp+0x30]
000073307ffd0c5b  vmovaps xmm4, [rsp+0x40]
000073307ffd0c61  vmovaps xmm5, [rsp+0x50]
000073307ffd0c67  vmovaps xmm6, [rsp+0x60]
000073307ffd0c6d  vmovaps xmm7, [rsp+0x70]
000073307ffd0c73  vmovaps xmm8, [rsp+0x80]
000073307ffd0c7c  vmovaps xmm9, [rsp+0x90]
000073307ffd0c85  vmovaps xmm10, [rsp+0xA0]
000073307ffd0c8e  vmovaps xmm11, [rsp+0xB0]
000073307ffd0c97  vmovaps xmm12, [rsp+0xC0]
000073307ffd0ca0  vmovaps xmm14, [rsp+0xD0]
000073307ffd0ca9  vmovaps xmm15, [rsp+0xE0]
000073307ffd0cb2  add rsp, 0xF0
000073307ffd0cb9  pop r11
000073307ffd0cbb  pop r10
000073307ffd0cbd  pop r9
000073307ffd0cbf  pop r8
000073307ffd0cc1  pop rsi
000073307ffd0cc2  pop rdi
000073307ffd0cc3  pop rdx
000073307ffd0cc4  pop rcx
000073307ffd0cc5  pop rax
000073307ffd0cc6  add rsp, 0x08
000073307ffd0cca  jmp 0x000073307FFCF64C
000073307ffd0ccf  sub rsp, 0x08
000073307ffd0cd3  push rax
000073307ffd0cd4  push rcx
000073307ffd0cd5  push rdx
000073307ffd0cd6  push rdi
000073307ffd0cd7  push rsi
000073307ffd0cd8  push r8
000073307ffd0cda  push r9
000073307ffd0cdc  push r10
000073307ffd0cde  push r11
000073307ffd0ce0  sub rsp, 0xF0
000073307ffd0ce7  vmovaps [rsp], xmm0
000073307ffd0cec  vmovaps [rsp+0x10], xmm2
000073307ffd0cf2  vmovaps [rsp+0x20], xmm3
000073307ffd0cf8  vmovaps [rsp+0x30], xmm4
000073307ffd0cfe  vmovaps [rsp+0x40], xmm5
000073307ffd0d04  vmovaps [rsp+0x50], xmm6
000073307ffd0d0a  vmovaps [rsp+0x60], xmm7
000073307ffd0d10  vmovaps [rsp+0x70], xmm8
000073307ffd0d16  vmovaps [rsp+0x80], xmm9
000073307ffd0d1f  vmovaps [rsp+0x90], xmm10
000073307ffd0d28  vmovaps [rsp+0xA0], xmm11
000073307ffd0d31  vmovaps [rsp+0xB0], xmm12
000073307ffd0d3a  vmovaps [rsp+0xC0], xmm13
000073307ffd0d43  vmovaps [rsp+0xD0], xmm14
000073307ffd0d4c  vmovaps [rsp+0xE0], xmm15
000073307ffd0d55  sub rsp, 0x30
000073307ffd0d59  movaps [rsp], xmm1
000073307ffd0d5d  movaps [rsp+0x10], xmm10
000073307ffd0d63  movaps [rsp+0x20], xmm2
000073307ffd0d68  lea rdi, [rsp]
000073307ffd0d6c  mov esi, 0x00
000073307ffd0d71  mov rax, 0x600DE0EC8530
000073307ffd0d7b  call rax
000073307ffd0d7d  movaps xmm1, [rsp]
000073307ffd0d81  add rsp, 0x30
000073307ffd0d85  vmovaps xmm0, [rsp]
000073307ffd0d8a  vmovaps xmm2, [rsp+0x10]
000073307ffd0d90  vmovaps xmm3, [rsp+0x20]
000073307ffd0d96  vmovaps xmm4, [rsp+0x30]
000073307ffd0d9c  vmovaps xmm5, [rsp+0x40]
000073307ffd0da2  vmovaps xmm6, [rsp+0x50]
000073307ffd0da8  vmovaps xmm7, [rsp+0x60]
000073307ffd0dae  vmovaps xmm8, [rsp+0x70]
000073307ffd0db4  vmovaps xmm9, [rsp+0x80]
000073307ffd0dbd  vmovaps xmm10, [rsp+0x90]
000073307ffd0dc6  vmovaps xmm11, [rsp+0xA0]
000073307ffd0dcf  vmovaps xmm12, [rsp+0xB0]
000073307ffd0dd8  vmovaps xmm13, [rsp+0xC0]
000073307ffd0de1  vmovaps xmm14, [rsp+0xD0]
000073307ffd0dea  vmovaps xmm15, [rsp+0xE0]
000073307ffd0df3  add rsp, 0xF0
000073307ffd0dfa  pop r11
000073307ffd0dfc  pop r10
000073307ffd0dfe  pop r9
000073307ffd0e00  pop r8
000073307ffd0e02  pop rsi
000073307ffd0e03  pop rdi
000073307ffd0e04  pop rdx
000073307ffd0e05  pop rcx
000073307ffd0e06  pop rax
000073307ffd0e07  add rsp, 0x08
000073307ffd0e0b  jmp 0x000073307FFCF6B4
000073307ffd0e10  sub rsp, 0x08
000073307ffd0e14  push rax
000073307ffd0e15  push rcx
000073307ffd0e16  push rdx
000073307ffd0e17  push rdi
000073307ffd0e18  push rsi
000073307ffd0e19  push r8
000073307ffd0e1b  push r9
000073307ffd0e1d  push r10
000073307ffd0e1f  push r11
000073307ffd0e21  sub rsp, 0xF0
000073307ffd0e28  vmovaps [rsp], xmm0
000073307ffd0e2d  vmovaps [rsp+0x10], xmm1
000073307ffd0e33  vmovaps [rsp+0x20], xmm2
000073307ffd0e39  vmovaps [rsp+0x30], xmm3
000073307ffd0e3f  vmovaps [rsp+0x40], xmm4
000073307ffd0e45  vmovaps [rsp+0x50], xmm5
000073307ffd0e4b  vmovaps [rsp+0x60], xmm6
000073307ffd0e51  vmovaps [rsp+0x70], xmm7
000073307ffd0e57  vmovaps [rsp+0x80], xmm8
000073307ffd0e60  vmovaps [rsp+0x90], xmm9
000073307ffd0e69  vmovaps [rsp+0xA0], xmm10
000073307ffd0e72  vmovaps [rsp+0xB0], xmm11
000073307ffd0e7b  vmovaps [rsp+0xC0], xmm12
000073307ffd0e84  vmovaps [rsp+0xD0], xmm13
000073307ffd0e8d  vmovaps [rsp+0xE0], xmm14
000073307ffd0e96  sub rsp, 0x30
000073307ffd0e9a  movaps [rsp], xmm15
000073307ffd0e9f  movaps [rsp+0x10], xmm10
000073307ffd0ea5  movaps [rsp+0x20], xmm2
000073307ffd0eaa  lea rdi, [rsp]
000073307ffd0eae  mov esi, 0x00
000073307ffd0eb3  mov rax, 0x600DE0EC8530
000073307ffd0ebd  call rax
000073307ffd0ebf  movaps xmm15, [rsp]
000073307ffd0ec4  add rsp, 0x30
000073307ffd0ec8  vmovaps xmm0, [rsp]
000073307ffd0ecd  vmovaps xmm1, [rsp+0x10]
000073307ffd0ed3  vmovaps xmm2, [rsp+0x20]
000073307ffd0ed9  vmovaps xmm3, [rsp+0x30]
000073307ffd0edf  vmovaps xmm4, [rsp+0x40]
000073307ffd0ee5  vmovaps xmm5, [rsp+0x50]
000073307ffd0eeb  vmovaps xmm6, [rsp+0x60]
000073307ffd0ef1  vmovaps xmm7, [rsp+0x70]
000073307ffd0ef7  vmovaps xmm8, [rsp+0x80]
000073307ffd0f00  vmovaps xmm9, [rsp+0x90]
000073307ffd0f09  vmovaps xmm10, [rsp+0xA0]
000073307ffd0f12  vmovaps xmm11, [rsp+0xB0]
000073307ffd0f1b  vmovaps xmm12, [rsp+0xC0]
000073307ffd0f24  vmovaps xmm13, [rsp+0xD0]
000073307ffd0f2d  vmovaps xmm14, [rsp+0xE0]
000073307ffd0f36  add rsp, 0xF0
000073307ffd0f3d  pop r11
000073307ffd0f3f  pop r10
000073307ffd0f41  pop r9
000073307ffd0f43  pop r8
000073307ffd0f45  pop rsi
000073307ffd0f46  pop rdi
000073307ffd0f47  pop rdx
000073307ffd0f48  pop rcx
000073307ffd0f49  pop rax
000073307ffd0f4a  add rsp, 0x08
000073307ffd0f4e  jmp 0x000073307FFCF706
000073307ffd0f53  sub rsp, 0x08
000073307ffd0f57  push rax
000073307ffd0f58  push rcx
000073307ffd0f59  push rdx
000073307ffd0f5a  push rdi
000073307ffd0f5b  push rsi
000073307ffd0f5c  push r8
000073307ffd0f5e  push r9
000073307ffd0f60  push r10
000073307ffd0f62  push r11
000073307ffd0f64  sub rsp, 0xF0
000073307ffd0f6b  vmovaps [rsp], xmm0
000073307ffd0f70  vmovaps [rsp+0x10], xmm2
000073307ffd0f76  vmovaps [rsp+0x20], xmm3
000073307ffd0f7c  vmovaps [rsp+0x30], xmm4
000073307ffd0f82  vmovaps [rsp+0x40], xmm5
000073307ffd0f88  vmovaps [rsp+0x50], xmm6
000073307ffd0f8e  vmovaps [rsp+0x60], xmm7
000073307ffd0f94  vmovaps [rsp+0x70], xmm8
000073307ffd0f9a  vmovaps [rsp+0x80], xmm9
000073307ffd0fa3  vmovaps [rsp+0x90], xmm10
000073307ffd0fac  vmovaps [rsp+0xA0], xmm11
000073307ffd0fb5  vmovaps [rsp+0xB0], xmm12
000073307ffd0fbe  vmovaps [rsp+0xC0], xmm13
000073307ffd0fc7  vmovaps [rsp+0xD0], xmm14
000073307ffd0fd0  vmovaps [rsp+0xE0], xmm15
000073307ffd0fd9  sub rsp, 0x30
000073307ffd0fdd  movaps [rsp], xmm1
000073307ffd0fe1  movaps [rsp+0x10], xmm10
000073307ffd0fe7  movaps [rsp+0x20], xmm12
000073307ffd0fed  lea rdi, [rsp]
000073307ffd0ff1  mov esi, 0x00
000073307ffd0ff6  mov rax, 0x600DE0EC8530
000073307ffd1000  call rax
000073307ffd1002  movaps xmm1, [rsp]
000073307ffd1006  add rsp, 0x30
000073307ffd100a  vmovaps xmm0, [rsp]
000073307ffd100f  vmovaps xmm2, [rsp+0x10]
000073307ffd1015  vmovaps xmm3, [rsp+0x20]
000073307ffd101b  vmovaps xmm4, [rsp+0x30]
000073307ffd1021  vmovaps xmm5, [rsp+0x40]
000073307ffd1027  vmovaps xmm6, [rsp+0x50]
000073307ffd102d  vmovaps xmm7, [rsp+0x60]
000073307ffd1033  vmovaps xmm8, [rsp+0x70]
000073307ffd1039  vmovaps xmm9, [rsp+0x80]
000073307ffd1042  vmovaps xmm10, [rsp+0x90]
000073307ffd104b  vmovaps xmm11, [rsp+0xA0]
000073307ffd1054  vmovaps xmm12, [rsp+0xB0]
000073307ffd105d  vmovaps xmm13, [rsp+0xC0]
000073307ffd1066  vmovaps xmm14, [rsp+0xD0]
000073307ffd106f  vmovaps xmm15, [rsp+0xE0]
000073307ffd1078  add rsp, 0xF0
000073307ffd107f  pop r11
000073307ffd1081  pop r10
000073307ffd1083  pop r9
000073307ffd1085  pop r8
000073307ffd1087  pop rsi
000073307ffd1088  pop rdi
000073307ffd1089  pop rdx
000073307ffd108a  pop rcx
000073307ffd108b  pop rax
000073307ffd108c  add rsp, 0x08
000073307ffd1090  jmp 0x000073307FFCF732
000073307ffd1095  sub rsp, 0x08
000073307ffd1099  push rax
000073307ffd109a  push rcx
000073307ffd109b  push rdx
000073307ffd109c  push rdi
000073307ffd109d  push rsi
000073307ffd109e  push r8
000073307ffd10a0  push r9
000073307ffd10a2  push r10
000073307ffd10a4  push r11
000073307ffd10a6  sub rsp, 0xF0
000073307ffd10ad  vmovaps [rsp], xmm0
000073307ffd10b2  vmovaps [rsp+0x10], xmm1
000073307ffd10b8  vmovaps [rsp+0x20], xmm2
000073307ffd10be  vmovaps [rsp+0x30], xmm3
000073307ffd10c4  vmovaps [rsp+0x40], xmm4
000073307ffd10ca  vmovaps [rsp+0x50], xmm5
000073307ffd10d0  vmovaps [rsp+0x60], xmm6
000073307ffd10d6  vmovaps [rsp+0x70], xmm7
000073307ffd10dc  vmovaps [rsp+0x80], xmm8
000073307ffd10e5  vmovaps [rsp+0x90], xmm9
000073307ffd10ee  vmovaps [rsp+0xA0], xmm10
000073307ffd10f7  vmovaps [rsp+0xB0], xmm11
000073307ffd1100  vmovaps [rsp+0xC0], xmm12
000073307ffd1109  vmovaps [rsp+0xD0], xmm13
000073307ffd1112  vmovaps [rsp+0xE0], xmm14
000073307ffd111b  sub rsp, 0x30
000073307ffd111f  movaps [rsp], xmm15
000073307ffd1124  movaps [rsp+0x10], xmm10
000073307ffd112a  movaps [rsp+0x20], xmm12
000073307ffd1130  lea rdi, [rsp]
000073307ffd1134  mov esi, 0x00
000073307ffd1139  mov rax, 0x600DE0EC8530
000073307ffd1143  call rax
000073307ffd1145  movaps xmm15, [rsp]
000073307ffd114a  add rsp, 0x30
000073307ffd114e  vmovaps xmm0, [rsp]
000073307ffd1153  vmovaps xmm1, [rsp+0x10]
000073307ffd1159  vmovaps xmm2, [rsp+0x20]
000073307ffd115f  vmovaps xmm3, [rsp+0x30]
000073307ffd1165  vmovaps xmm4, [rsp+0x40]
000073307ffd116b  vmovaps xmm5, [rsp+0x50]
000073307ffd1171  vmovaps xmm6, [rsp+0x60]
000073307ffd1177  vmovaps xmm7, [rsp+0x70]
000073307ffd117d  vmovaps xmm8, [rsp+0x80]
000073307ffd1186  vmovaps xmm9, [rsp+0x90]
000073307ffd118f  vmovaps xmm10, [rsp+0xA0]
000073307ffd1198  vmovaps xmm11, [rsp+0xB0]
000073307ffd11a1  vmovaps xmm12, [rsp+0xC0]
000073307ffd11aa  vmovaps xmm13, [rsp+0xD0]
000073307ffd11b3  vmovaps xmm14, [rsp+0xE0]
000073307ffd11bc  add rsp, 0xF0
000073307ffd11c3  pop r11
000073307ffd11c5  pop r10
000073307ffd11c7  pop r9
000073307ffd11c9  pop r8
000073307ffd11cb  pop rsi
000073307ffd11cc  pop rdi
000073307ffd11cd  pop rdx
000073307ffd11ce  pop rcx
000073307ffd11cf  pop rax
000073307ffd11d0  add rsp, 0x08
000073307ffd11d4  jmp 0x000073307FFCF75E
000073307ffd11d9  call 0x000073307FDFF430
000073307ffd11de  jmp 0x000073307FFCF7EE
000073307ffd11e3  call 0x000073307FDFF430
000073307ffd11e8  jmp 0x000073307FFCF801
000073307ffd11ed  sub rsp, 0x08
000073307ffd11f1  push rax
000073307ffd11f2  push rcx
000073307ffd11f3  push rdx
000073307ffd11f4  push rdi
000073307ffd11f5  push rsi
000073307ffd11f6  push r8
000073307ffd11f8  push r9
000073307ffd11fa  push r10
000073307ffd11fc  push r11
000073307ffd11fe  sub rsp, 0xF0
000073307ffd1205  vmovaps [rsp], xmm0
000073307ffd120a  vmovaps [rsp+0x10], xmm2
000073307ffd1210  vmovaps [rsp+0x20], xmm3
000073307ffd1216  vmovaps [rsp+0x30], xmm4
000073307ffd121c  vmovaps [rsp+0x40], xmm5
000073307ffd1222  vmovaps [rsp+0x50], xmm6
000073307ffd1228  vmovaps [rsp+0x60], xmm7
000073307ffd122e  vmovaps [rsp+0x70], xmm8
000073307ffd1234  vmovaps [rsp+0x80], xmm9
000073307ffd123d  vmovaps [rsp+0x90], xmm10
000073307ffd1246  vmovaps [rsp+0xA0], xmm11
000073307ffd124f  vmovaps [rsp+0xB0], xmm12
000073307ffd1258  vmovaps [rsp+0xC0], xmm13
000073307ffd1261  vmovaps [rsp+0xD0], xmm14
000073307ffd126a  vmovaps [rsp+0xE0], xmm15
000073307ffd1273  sub rsp, 0x30
000073307ffd1277  movaps [rsp], xmm1
000073307ffd127b  movaps [rsp+0x10], xmm13
000073307ffd1281  movaps [rsp+0x20], xmm2
000073307ffd1286  lea rdi, [rsp]
000073307ffd128a  mov esi, 0x00
000073307ffd128f  mov rax, 0x600DE0EC8530
000073307ffd1299  call rax
000073307ffd129b  movaps xmm1, [rsp]
000073307ffd129f  add rsp, 0x30
000073307ffd12a3  vmovaps xmm0, [rsp]
000073307ffd12a8  vmovaps xmm2, [rsp+0x10]
000073307ffd12ae  vmovaps xmm3, [rsp+0x20]
000073307ffd12b4  vmovaps xmm4, [rsp+0x30]
000073307ffd12ba  vmovaps xmm5, [rsp+0x40]
000073307ffd12c0  vmovaps xmm6, [rsp+0x50]
000073307ffd12c6  vmovaps xmm7, [rsp+0x60]
000073307ffd12cc  vmovaps xmm8, [rsp+0x70]
000073307ffd12d2  vmovaps xmm9, [rsp+0x80]
000073307ffd12db  vmovaps xmm10, [rsp+0x90]
000073307ffd12e4  vmovaps xmm11, [rsp+0xA0]
000073307ffd12ed  vmovaps xmm12, [rsp+0xB0]
000073307ffd12f6  vmovaps xmm13, [rsp+0xC0]
000073307ffd12ff  vmovaps xmm14, [rsp+0xD0]
000073307ffd1308  vmovaps xmm15, [rsp+0xE0]
000073307ffd1311  add rsp, 0xF0
000073307ffd1318  pop r11
000073307ffd131a  pop r10
000073307ffd131c  pop r9
000073307ffd131e  pop r8
000073307ffd1320  pop rsi
000073307ffd1321  pop rdi
000073307ffd1322  pop rdx
000073307ffd1323  pop rcx
000073307ffd1324  pop rax
000073307ffd1325  add rsp, 0x08
000073307ffd1329  jmp 0x000073307FFCF82C
000073307ffd132e  call 0x000073307FE0E760
000073307ffd1333  jmp 0x000073307FFCF839
000073307ffd1338  sub rsp, 0x08
000073307ffd133c  push rax
000073307ffd133d  push rcx
000073307ffd133e  push rdx
000073307ffd133f  push rdi
000073307ffd1340  push rsi
000073307ffd1341  push r8
000073307ffd1343  push r9
000073307ffd1345  push r10
000073307ffd1347  push r11
000073307ffd1349  sub rsp, 0xF0
000073307ffd1350  vmovaps [rsp], xmm0
000073307ffd1355  vmovaps [rsp+0x10], xmm1
000073307ffd135b  vmovaps [rsp+0x20], xmm2
000073307ffd1361  vmovaps [rsp+0x30], xmm3
000073307ffd1367  vmovaps [rsp+0x40], xmm4
000073307ffd136d  vmovaps [rsp+0x50], xmm5
000073307ffd1373  vmovaps [rsp+0x60], xmm6
000073307ffd1379  vmovaps [rsp+0x70], xmm7
000073307ffd137f  vmovaps [rsp+0x80], xmm8
000073307ffd1388  vmovaps [rsp+0x90], xmm9
000073307ffd1391  vmovaps [rsp+0xA0], xmm10
000073307ffd139a  vmovaps [rsp+0xB0], xmm11
000073307ffd13a3  vmovaps [rsp+0xC0], xmm12
000073307ffd13ac  vmovaps [rsp+0xD0], xmm14
000073307ffd13b5  vmovaps [rsp+0xE0], xmm15
000073307ffd13be  sub rsp, 0x30
000073307ffd13c2  movaps [rsp], xmm13
000073307ffd13c7  movaps [rsp+0x10], xmm2
000073307ffd13cc  movaps [rsp+0x20], xmm1
000073307ffd13d1  lea rdi, [rsp]
000073307ffd13d5  mov esi, 0x00
000073307ffd13da  mov rax, 0x600DE0EC8530
000073307ffd13e4  call rax
000073307ffd13e6  movaps xmm13, [rsp]
000073307ffd13eb  add rsp, 0x30
000073307ffd13ef  vmovaps xmm0, [rsp]
000073307ffd13f4  vmovaps xmm1, [rsp+0x10]
000073307ffd13fa  vmovaps xmm2, [rsp+0x20]
000073307ffd1400  vmovaps xmm3, [rsp+0x30]
000073307ffd1406  vmovaps xmm4, [rsp+0x40]
000073307ffd140c  vmovaps xmm5, [rsp+0x50]
000073307ffd1412  vmovaps xmm6, [rsp+0x60]
000073307ffd1418  vmovaps xmm7, [rsp+0x70]
000073307ffd141e  vmovaps xmm8, [rsp+0x80]
000073307ffd1427  vmovaps xmm9, [rsp+0x90]
000073307ffd1430  vmovaps xmm10, [rsp+0xA0]
000073307ffd1439  vmovaps xmm11, [rsp+0xB0]
000073307ffd1442  vmovaps xmm12, [rsp+0xC0]
000073307ffd144b  vmovaps xmm14, [rsp+0xD0]
000073307ffd1454  vmovaps xmm15, [rsp+0xE0]
000073307ffd145d  add rsp, 0xF0
000073307ffd1464  pop r11
000073307ffd1466  pop r10
000073307ffd1468  pop r9
000073307ffd146a  pop r8
000073307ffd146c  pop rsi
000073307ffd146d  pop rdi
000073307ffd146e  pop rdx
000073307ffd146f  pop rcx
000073307ffd1470  pop rax
000073307ffd1471  add rsp, 0x08
000073307ffd1475  jmp 0x000073307FFCF878
000073307ffd147a  sub rsp, 0x08
000073307ffd147e  push rax
000073307ffd147f  push rcx
000073307ffd1480  push rdx
000073307ffd1481  push rdi
000073307ffd1482  push rsi
000073307ffd1483  push r8
000073307ffd1485  push r9
000073307ffd1487  push r10
000073307ffd1489  push r11
000073307ffd148b  sub rsp, 0xF0
000073307ffd1492  vmovaps [rsp], xmm0
000073307ffd1497  vmovaps [rsp+0x10], xmm2
000073307ffd149d  vmovaps [rsp+0x20], xmm3
000073307ffd14a3  vmovaps [rsp+0x30], xmm4
000073307ffd14a9  vmovaps [rsp+0x40], xmm5
000073307ffd14af  vmovaps [rsp+0x50], xmm6
000073307ffd14b5  vmovaps [rsp+0x60], xmm7
000073307ffd14bb  vmovaps [rsp+0x70], xmm8
000073307ffd14c1  vmovaps [rsp+0x80], xmm9
000073307ffd14ca  vmovaps [rsp+0x90], xmm10
000073307ffd14d3  vmovaps [rsp+0xA0], xmm11
000073307ffd14dc  vmovaps [rsp+0xB0], xmm12
000073307ffd14e5  vmovaps [rsp+0xC0], xmm13
000073307ffd14ee  vmovaps [rsp+0xD0], xmm14
000073307ffd14f7  vmovaps [rsp+0xE0], xmm15
000073307ffd1500  sub rsp, 0x30
000073307ffd1504  movaps [rsp], xmm1
000073307ffd1508  movaps [rsp+0x10], xmm15
000073307ffd150e  movaps [rsp+0x20], xmm2
000073307ffd1513  lea rdi, [rsp]
000073307ffd1517  mov esi, 0x00
000073307ffd151c  mov rax, 0x600DE0EC8530
000073307ffd1526  call rax
000073307ffd1528  movaps xmm1, [rsp]
000073307ffd152c  add rsp, 0x30
000073307ffd1530  vmovaps xmm0, [rsp]
000073307ffd1535  vmovaps xmm2, [rsp+0x10]
000073307ffd153b  vmovaps xmm3, [rsp+0x20]
000073307ffd1541  vmovaps xmm4, [rsp+0x30]
000073307ffd1547  vmovaps xmm5, [rsp+0x40]
000073307ffd154d  vmovaps xmm6, [rsp+0x50]
000073307ffd1553  vmovaps xmm7, [rsp+0x60]
000073307ffd1559  vmovaps xmm8, [rsp+0x70]
000073307ffd155f  vmovaps xmm9, [rsp+0x80]
000073307ffd1568  vmovaps xmm10, [rsp+0x90]
000073307ffd1571  vmovaps xmm11, [rsp+0xA0]
000073307ffd157a  vmovaps xmm12, [rsp+0xB0]
000073307ffd1583  vmovaps xmm13, [rsp+0xC0]
000073307ffd158c  vmovaps xmm14, [rsp+0xD0]
000073307ffd1595  vmovaps xmm15, [rsp+0xE0]
000073307ffd159e  add rsp, 0xF0
000073307ffd15a5  pop r11
000073307ffd15a7  pop r10
000073307ffd15a9  pop r9
000073307ffd15ab  pop r8
000073307ffd15ad  pop rsi
000073307ffd15ae  pop rdi
000073307ffd15af  pop rdx
000073307ffd15b0  pop rcx
000073307ffd15b1  pop rax
000073307ffd15b2  add rsp, 0x08
000073307ffd15b6  jmp 0x000073307FFCF8AC
000073307ffd15bb  sub rsp, 0x08
000073307ffd15bf  push rax
000073307ffd15c0  push rcx
000073307ffd15c1  push rdx
000073307ffd15c2  push rdi
000073307ffd15c3  push rsi
000073307ffd15c4  push r8
000073307ffd15c6  push r9
000073307ffd15c8  push r10
000073307ffd15ca  push r11
000073307ffd15cc  sub rsp, 0xF0
000073307ffd15d3  vmovaps [rsp], xmm0
000073307ffd15d8  vmovaps [rsp+0x10], xmm1
000073307ffd15de  vmovaps [rsp+0x20], xmm2
000073307ffd15e4  vmovaps [rsp+0x30], xmm3
000073307ffd15ea  vmovaps [rsp+0x40], xmm4
000073307ffd15f0  vmovaps [rsp+0x50], xmm5
000073307ffd15f6  vmovaps [rsp+0x60], xmm6
000073307ffd15fc  vmovaps [rsp+0x70], xmm7
000073307ffd1602  vmovaps [rsp+0x80], xmm8
000073307ffd160b  vmovaps [rsp+0x90], xmm9
000073307ffd1614  vmovaps [rsp+0xA0], xmm10
000073307ffd161d  vmovaps [rsp+0xB0], xmm11
000073307ffd1626  vmovaps [rsp+0xC0], xmm12
000073307ffd162f  vmovaps [rsp+0xD0], xmm13
000073307ffd1638  vmovaps [rsp+0xE0], xmm15
000073307ffd1641  sub rsp, 0x30
000073307ffd1645  movaps [rsp], xmm14
000073307ffd164a  movaps [rsp+0x10], xmm2
000073307ffd164f  movaps [rsp+0x20], xmm15
000073307ffd1655  lea rdi, [rsp]
000073307ffd1659  mov esi, 0x00
000073307ffd165e  mov rax, 0x600DE0EC8530
000073307ffd1668  call rax
000073307ffd166a  movaps xmm14, [rsp]
000073307ffd166f  add rsp, 0x30
000073307ffd1673  vmovaps xmm0, [rsp]
000073307ffd1678  vmovaps xmm1, [rsp+0x10]
000073307ffd167e  vmovaps xmm2, [rsp+0x20]
000073307ffd1684  vmovaps xmm3, [rsp+0x30]
000073307ffd168a  vmovaps xmm4, [rsp+0x40]
000073307ffd1690  vmovaps xmm5, [rsp+0x50]
000073307ffd1696  vmovaps xmm6, [rsp+0x60]
000073307ffd169c  vmovaps xmm7, [rsp+0x70]
000073307ffd16a2  vmovaps xmm8, [rsp+0x80]
000073307ffd16ab  vmovaps xmm9, [rsp+0x90]
000073307ffd16b4  vmovaps xmm10, [rsp+0xA0]
000073307ffd16bd  vmovaps xmm11, [rsp+0xB0]
000073307ffd16c6  vmovaps xmm12, [rsp+0xC0]
000073307ffd16cf  vmovaps xmm13, [rsp+0xD0]
000073307ffd16d8  vmovaps xmm15, [rsp+0xE0]
000073307ffd16e1  add rsp, 0xF0
000073307ffd16e8  pop r11
000073307ffd16ea  pop r10
000073307ffd16ec  pop r9
000073307ffd16ee  pop r8
000073307ffd16f0  pop rsi
000073307ffd16f1  pop rdi
000073307ffd16f2  pop rdx
000073307ffd16f3  pop rcx
000073307ffd16f4  pop rax
000073307ffd16f5  add rsp, 0x08
000073307ffd16f9  jmp 0x000073307FFCF8E7
000073307ffd16fe  sub rsp, 0x08
000073307ffd1702  push rax
000073307ffd1703  push rcx
000073307ffd1704  push rdx
000073307ffd1705  push rdi
000073307ffd1706  push rsi
000073307ffd1707  push r8
000073307ffd1709  push r9
000073307ffd170b  push r10
000073307ffd170d  push r11
000073307ffd170f  sub rsp, 0xF0
000073307ffd1716  vmovaps [rsp], xmm0
000073307ffd171b  vmovaps [rsp+0x10], xmm1
000073307ffd1721  vmovaps [rsp+0x20], xmm2
000073307ffd1727  vmovaps [rsp+0x30], xmm3
000073307ffd172d  vmovaps [rsp+0x40], xmm4
000073307ffd1733  vmovaps [rsp+0x50], xmm5
000073307ffd1739  vmovaps [rsp+0x60], xmm6
000073307ffd173f  vmovaps [rsp+0x70], xmm7
000073307ffd1745  vmovaps [rsp+0x80], xmm8
000073307ffd174e  vmovaps [rsp+0x90], xmm9
000073307ffd1757  vmovaps [rsp+0xA0], xmm10
000073307ffd1760  vmovaps [rsp+0xB0], xmm11
000073307ffd1769  vmovaps [rsp+0xC0], xmm12
000073307ffd1772  vmovaps [rsp+0xD0], xmm13
000073307ffd177b  vmovaps [rsp+0xE0], xmm14
000073307ffd1784  sub rsp, 0x30
000073307ffd1788  movaps [rsp], xmm15
000073307ffd178d  movaps [rsp+0x10], xmm2
000073307ffd1792  movaps [rsp+0x20], xmm1
000073307ffd1797  lea rdi, [rsp]
000073307ffd179b  mov esi, 0x00
000073307ffd17a0  mov rax, 0x600DE0EC8530
000073307ffd17aa  call rax
000073307ffd17ac  movaps xmm15, [rsp]
000073307ffd17b1  add rsp, 0x30
000073307ffd17b5  vmovaps xmm0, [rsp]
000073307ffd17ba  vmovaps xmm1, [rsp+0x10]
000073307ffd17c0  vmovaps xmm2, [rsp+0x20]
000073307ffd17c6  vmovaps xmm3, [rsp+0x30]
000073307ffd17cc  vmovaps xmm4, [rsp+0x40]
000073307ffd17d2  vmovaps xmm5, [rsp+0x50]
000073307ffd17d8  vmovaps xmm6, [rsp+0x60]
000073307ffd17de  vmovaps xmm7, [rsp+0x70]
000073307ffd17e4  vmovaps xmm8, [rsp+0x80]
000073307ffd17ed  vmovaps xmm9, [rsp+0x90]
000073307ffd17f6  vmovaps xmm10, [rsp+0xA0]
000073307ffd17ff  vmovaps xmm11, [rsp+0xB0]
000073307ffd1808  vmovaps xmm12, [rsp+0xC0]
000073307ffd1811  vmovaps xmm13, [rsp+0xD0]
000073307ffd181a  vmovaps xmm14, [rsp+0xE0]
000073307ffd1823  add rsp, 0xF0
000073307ffd182a  pop r11
000073307ffd182c  pop r10
000073307ffd182e  pop r9
000073307ffd1830  pop r8
000073307ffd1832  pop rsi
000073307ffd1833  pop rdi
000073307ffd1834  pop rdx
000073307ffd1835  pop rcx
000073307ffd1836  pop rax
000073307ffd1837  add rsp, 0x08
000073307ffd183b  jmp 0x000073307FFCF923
000073307ffd1840  call 0x000073307FDFF430
000073307ffd1845  jmp 0x000073307FFCF930
000073307ffd184a  sub rsp, 0x08
000073307ffd184e  push rax
000073307ffd184f  push rcx
000073307ffd1850  push rdx
000073307ffd1851  push rdi
000073307ffd1852  push rsi
000073307ffd1853  push r8
000073307ffd1855  push r9
000073307ffd1857  push r10
000073307ffd1859  push r11
000073307ffd185b  sub rsp, 0xF0
000073307ffd1862  vmovaps [rsp], xmm0
000073307ffd1867  vmovaps [rsp+0x10], xmm1
000073307ffd186d  vmovaps [rsp+0x20], xmm3
000073307ffd1873  vmovaps [rsp+0x30], xmm4
000073307ffd1879  vmovaps [rsp+0x40], xmm5
000073307ffd187f  vmovaps [rsp+0x50], xmm6
000073307ffd1885  vmovaps [rsp+0x60], xmm7
000073307ffd188b  vmovaps [rsp+0x70], xmm8
000073307ffd1891  vmovaps [rsp+0x80], xmm9
000073307ffd189a  vmovaps [rsp+0x90], xmm10
000073307ffd18a3  vmovaps [rsp+0xA0], xmm11
000073307ffd18ac  vmovaps [rsp+0xB0], xmm12
000073307ffd18b5  vmovaps [rsp+0xC0], xmm13
000073307ffd18be  vmovaps [rsp+0xD0], xmm14
000073307ffd18c7  vmovaps [rsp+0xE0], xmm15
000073307ffd18d0  sub rsp, 0x30
000073307ffd18d4  movaps [rsp], xmm2
000073307ffd18d8  movaps [rsp+0x10], xmm1
000073307ffd18dd  movaps [rsp+0x20], xmm14
000073307ffd18e3  lea rdi, [rsp]
000073307ffd18e7  mov esi, 0x00
000073307ffd18ec  mov rax, 0x600DE0EC8530
000073307ffd18f6  call rax
000073307ffd18f8  movaps xmm2, [rsp]
000073307ffd18fc  add rsp, 0x30
000073307ffd1900  vmovaps xmm0, [rsp]
000073307ffd1905  vmovaps xmm1, [rsp+0x10]
000073307ffd190b  vmovaps xmm3, [rsp+0x20]
000073307ffd1911  vmovaps xmm4, [rsp+0x30]
000073307ffd1917  vmovaps xmm5, [rsp+0x40]
000073307ffd191d  vmovaps xmm6, [rsp+0x50]
000073307ffd1923  vmovaps xmm7, [rsp+0x60]
000073307ffd1929  vmovaps xmm8, [rsp+0x70]
000073307ffd192f  vmovaps xmm9, [rsp+0x80]
000073307ffd1938  vmovaps xmm10, [rsp+0x90]
000073307ffd1941  vmovaps xmm11, [rsp+0xA0]
000073307ffd194a  vmovaps xmm12, [rsp+0xB0]
000073307ffd1953  vmovaps xmm13, [rsp+0xC0]
000073307ffd195c  vmovaps xmm14, [rsp+0xD0]
000073307ffd1965  vmovaps xmm15, [rsp+0xE0]
000073307ffd196e  add rsp, 0xF0
000073307ffd1975  pop r11
000073307ffd1977  pop r10
000073307ffd1979  pop r9
000073307ffd197b  pop r8
000073307ffd197d  pop rsi
000073307ffd197e  pop rdi
000073307ffd197f  pop rdx
000073307ffd1980  pop rcx
000073307ffd1981  pop rax
000073307ffd1982  add rsp, 0x08
000073307ffd1986  jmp 0x000073307FFCF96D
000073307ffd198b  sub rsp, 0x08
000073307ffd198f  push rax
000073307ffd1990  push rcx
000073307ffd1991  push rdx
000073307ffd1992  push rdi
000073307ffd1993  push rsi
000073307ffd1994  push r8
000073307ffd1996  push r9
000073307ffd1998  push r10
000073307ffd199a  push r11
000073307ffd199c  sub rsp, 0xF0
000073307ffd19a3  vmovaps [rsp], xmm0
000073307ffd19a8  vmovaps [rsp+0x10], xmm1
000073307ffd19ae  vmovaps [rsp+0x20], xmm2
000073307ffd19b4  vmovaps [rsp+0x30], xmm3
000073307ffd19ba  vmovaps [rsp+0x40], xmm4
000073307ffd19c0  vmovaps [rsp+0x50], xmm5
000073307ffd19c6  vmovaps [rsp+0x60], xmm6
000073307ffd19cc  vmovaps [rsp+0x70], xmm7
000073307ffd19d2  vmovaps [rsp+0x80], xmm8
000073307ffd19db  vmovaps [rsp+0x90], xmm9
000073307ffd19e4  vmovaps [rsp+0xA0], xmm10
000073307ffd19ed  vmovaps [rsp+0xB0], xmm11
000073307ffd19f6  vmovaps [rsp+0xC0], xmm12
000073307ffd19ff  vmovaps [rsp+0xD0], xmm13
000073307ffd1a08  vmovaps [rsp+0xE0], xmm14
000073307ffd1a11  sub rsp, 0x30
000073307ffd1a15  movaps [rsp], xmm15
000073307ffd1a1a  movaps [rsp+0x10], xmm14
000073307ffd1a20  movaps [rsp+0x20], xmm1
000073307ffd1a25  lea rdi, [rsp]
000073307ffd1a29  mov esi, 0x00
000073307ffd1a2e  mov rax, 0x600DE0EC8530
000073307ffd1a38  call rax
000073307ffd1a3a  movaps xmm15, [rsp]
000073307ffd1a3f  add rsp, 0x30
000073307ffd1a43  vmovaps xmm0, [rsp]
000073307ffd1a48  vmovaps xmm1, [rsp+0x10]
000073307ffd1a4e  vmovaps xmm2, [rsp+0x20]
000073307ffd1a54  vmovaps xmm3, [rsp+0x30]
000073307ffd1a5a  vmovaps xmm4, [rsp+0x40]
000073307ffd1a60  vmovaps xmm5, [rsp+0x50]
000073307ffd1a66  vmovaps xmm6, [rsp+0x60]
000073307ffd1a6c  vmovaps xmm7, [rsp+0x70]
000073307ffd1a72  vmovaps xmm8, [rsp+0x80]
000073307ffd1a7b  vmovaps xmm9, [rsp+0x90]
000073307ffd1a84  vmovaps xmm10, [rsp+0xA0]
000073307ffd1a8d  vmovaps xmm11, [rsp+0xB0]
000073307ffd1a96  vmovaps xmm12, [rsp+0xC0]
000073307ffd1a9f  vmovaps xmm13, [rsp+0xD0]
000073307ffd1aa8  vmovaps xmm14, [rsp+0xE0]
000073307ffd1ab1  add rsp, 0xF0
000073307ffd1ab8  pop r11
000073307ffd1aba  pop r10
000073307ffd1abc  pop r9
000073307ffd1abe  pop r8
000073307ffd1ac0  pop rsi
000073307ffd1ac1  pop rdi
000073307ffd1ac2  pop rdx
000073307ffd1ac3  pop rcx
000073307ffd1ac4  pop rax
000073307ffd1ac5  add rsp, 0x08
000073307ffd1ac9  jmp 0x000073307FFCF9E7
000073307ffd1ace  call 0x000073307FDFF430
000073307ffd1ad3  jmp 0x000073307FFCF9F4
000073307ffd1ad8  sub rsp, 0x08
000073307ffd1adc  push rax
000073307ffd1add  push rcx
000073307ffd1ade  push rdx
000073307ffd1adf  push rdi
000073307ffd1ae0  push rsi
000073307ffd1ae1  push r8
000073307ffd1ae3  push r9
000073307ffd1ae5  push r10
000073307ffd1ae7  push r11
000073307ffd1ae9  sub rsp, 0xF0
000073307ffd1af0  vmovaps [rsp], xmm0
000073307ffd1af5  vmovaps [rsp+0x10], xmm1
000073307ffd1afb  vmovaps [rsp+0x20], xmm2
000073307ffd1b01  vmovaps [rsp+0x30], xmm3
000073307ffd1b07  vmovaps [rsp+0x40], xmm4
000073307ffd1b0d  vmovaps [rsp+0x50], xmm5
000073307ffd1b13  vmovaps [rsp+0x60], xmm6
000073307ffd1b19  vmovaps [rsp+0x70], xmm7
000073307ffd1b1f  vmovaps [rsp+0x80], xmm8
000073307ffd1b28  vmovaps [rsp+0x90], xmm9
000073307ffd1b31  vmovaps [rsp+0xA0], xmm10
000073307ffd1b3a  vmovaps [rsp+0xB0], xmm11
000073307ffd1b43  vmovaps [rsp+0xC0], xmm12
000073307ffd1b4c  vmovaps [rsp+0xD0], xmm13
000073307ffd1b55  vmovaps [rsp+0xE0], xmm15
000073307ffd1b5e  sub rsp, 0x30
000073307ffd1b62  movaps [rsp], xmm14
000073307ffd1b67  movaps [rsp+0x10], xmm13
000073307ffd1b6d  movaps [rsp+0x20], xmm1
000073307ffd1b72  lea rdi, [rsp]
000073307ffd1b76  mov esi, 0x00
000073307ffd1b7b  mov rax, 0x600DE0EC8530
000073307ffd1b85  call rax
000073307ffd1b87  movaps xmm14, [rsp]
000073307ffd1b8c  add rsp, 0x30
000073307ffd1b90  vmovaps xmm0, [rsp]
000073307ffd1b95  vmovaps xmm1, [rsp+0x10]
000073307ffd1b9b  vmovaps xmm2, [rsp+0x20]
000073307ffd1ba1  vmovaps xmm3, [rsp+0x30]
000073307ffd1ba7  vmovaps xmm4, [rsp+0x40]
000073307ffd1bad  vmovaps xmm5, [rsp+0x50]
000073307ffd1bb3  vmovaps xmm6, [rsp+0x60]
000073307ffd1bb9  vmovaps xmm7, [rsp+0x70]
000073307ffd1bbf  vmovaps xmm8, [rsp+0x80]
000073307ffd1bc8  vmovaps xmm9, [rsp+0x90]
000073307ffd1bd1  vmovaps xmm10, [rsp+0xA0]
000073307ffd1bda  vmovaps xmm11, [rsp+0xB0]
000073307ffd1be3  vmovaps xmm12, [rsp+0xC0]
000073307ffd1bec  vmovaps xmm13, [rsp+0xD0]
000073307ffd1bf5  vmovaps xmm15, [rsp+0xE0]
000073307ffd1bfe  add rsp, 0xF0
000073307ffd1c05  pop r11
000073307ffd1c07  pop r10
000073307ffd1c09  pop r9
000073307ffd1c0b  pop r8
000073307ffd1c0d  pop rsi
000073307ffd1c0e  pop rdi
000073307ffd1c0f  pop rdx
000073307ffd1c10  pop rcx
000073307ffd1c11  pop rax
000073307ffd1c12  add rsp, 0x08
000073307ffd1c16  jmp 0x000073307FFCFAAF
000073307ffd1c1b  sub rsp, 0x08
000073307ffd1c1f  push rax
000073307ffd1c20  push rcx
000073307ffd1c21  push rdx
000073307ffd1c22  push rdi
000073307ffd1c23  push rsi
000073307ffd1c24  push r8
000073307ffd1c26  push r9
000073307ffd1c28  push r10
000073307ffd1c2a  push r11
000073307ffd1c2c  sub rsp, 0xF0
000073307ffd1c33  vmovaps [rsp], xmm0
000073307ffd1c38  vmovaps [rsp+0x10], xmm1
000073307ffd1c3e  vmovaps [rsp+0x20], xmm2
000073307ffd1c44  vmovaps [rsp+0x30], xmm3
000073307ffd1c4a  vmovaps [rsp+0x40], xmm4
000073307ffd1c50  vmovaps [rsp+0x50], xmm5
000073307ffd1c56  vmovaps [rsp+0x60], xmm6
000073307ffd1c5c  vmovaps [rsp+0x70], xmm7
000073307ffd1c62  vmovaps [rsp+0x80], xmm8
000073307ffd1c6b  vmovaps [rsp+0x90], xmm9
000073307ffd1c74  vmovaps [rsp+0xA0], xmm10
000073307ffd1c7d  vmovaps [rsp+0xB0], xmm11
000073307ffd1c86  vmovaps [rsp+0xC0], xmm12
000073307ffd1c8f  vmovaps [rsp+0xD0], xmm13
000073307ffd1c98  vmovaps [rsp+0xE0], xmm14
000073307ffd1ca1  sub rsp, 0x30
000073307ffd1ca5  movaps [rsp], xmm15
000073307ffd1caa  movaps [rsp+0x10], xmm13
000073307ffd1cb0  movaps [rsp+0x20], xmm1
000073307ffd1cb5  lea rdi, [rsp]
000073307ffd1cb9  mov esi, 0x00
000073307ffd1cbe  mov rax, 0x600DE0EC8530
000073307ffd1cc8  call rax
000073307ffd1cca  movaps xmm15, [rsp]
000073307ffd1ccf  add rsp, 0x30
000073307ffd1cd3  vmovaps xmm0, [rsp]
000073307ffd1cd8  vmovaps xmm1, [rsp+0x10]
000073307ffd1cde  vmovaps xmm2, [rsp+0x20]
000073307ffd1ce4  vmovaps xmm3, [rsp+0x30]
000073307ffd1cea  vmovaps xmm4, [rsp+0x40]
000073307ffd1cf0  vmovaps xmm5, [rsp+0x50]
000073307ffd1cf6  vmovaps xmm6, [rsp+0x60]
000073307ffd1cfc  vmovaps xmm7, [rsp+0x70]
000073307ffd1d02  vmovaps xmm8, [rsp+0x80]
000073307ffd1d0b  vmovaps xmm9, [rsp+0x90]
000073307ffd1d14  vmovaps xmm10, [rsp+0xA0]
000073307ffd1d1d  vmovaps xmm11, [rsp+0xB0]
000073307ffd1d26  vmovaps xmm12, [rsp+0xC0]
000073307ffd1d2f  vmovaps xmm13, [rsp+0xD0]
000073307ffd1d38  vmovaps xmm14, [rsp+0xE0]
000073307ffd1d41  add rsp, 0xF0
000073307ffd1d48  pop r11
000073307ffd1d4a  pop r10
000073307ffd1d4c  pop r9
000073307ffd1d4e  pop r8
000073307ffd1d50  pop rsi
000073307ffd1d51  pop rdi
000073307ffd1d52  pop rdx
000073307ffd1d53  pop rcx
000073307ffd1d54  pop rax
000073307ffd1d55  add rsp, 0x08
000073307ffd1d59  jmp 0x000073307FFCFAEB
000073307ffd1d5e  call 0x000073307FDFF430
000073307ffd1d63  jmp 0x000073307FFCFAF8
000073307ffd1d68  sub rsp, 0x08
000073307ffd1d6c  push rax
000073307ffd1d6d  push rcx
000073307ffd1d6e  push rdx
000073307ffd1d6f  push rdi
000073307ffd1d70  push rsi
000073307ffd1d71  push r8
000073307ffd1d73  push r9
000073307ffd1d75  push r10
000073307ffd1d77  push r11
000073307ffd1d79  sub rsp, 0xF0
000073307ffd1d80  vmovaps [rsp], xmm0
000073307ffd1d85  vmovaps [rsp+0x10], xmm1
000073307ffd1d8b  vmovaps [rsp+0x20], xmm2
000073307ffd1d91  vmovaps [rsp+0x30], xmm3
000073307ffd1d97  vmovaps [rsp+0x40], xmm4
000073307ffd1d9d  vmovaps [rsp+0x50], xmm5
000073307ffd1da3  vmovaps [rsp+0x60], xmm6
000073307ffd1da9  vmovaps [rsp+0x70], xmm7
000073307ffd1daf  vmovaps [rsp+0x80], xmm8
000073307ffd1db8  vmovaps [rsp+0x90], xmm9
000073307ffd1dc1  vmovaps [rsp+0xA0], xmm10
000073307ffd1dca  vmovaps [rsp+0xB0], xmm11
000073307ffd1dd3  vmovaps [rsp+0xC0], xmm12
000073307ffd1ddc  vmovaps [rsp+0xD0], xmm13
000073307ffd1de5  vmovaps [rsp+0xE0], xmm15
000073307ffd1dee  sub rsp, 0x30
000073307ffd1df2  movaps [rsp], xmm14
000073307ffd1df7  movaps [rsp+0x10], xmm13
000073307ffd1dfd  movaps [rsp+0x20], xmm2
000073307ffd1e02  lea rdi, [rsp]
000073307ffd1e06  mov esi, 0x00
000073307ffd1e0b  mov rax, 0x600DE0EC8530
000073307ffd1e15  call rax
000073307ffd1e17  movaps xmm14, [rsp]
000073307ffd1e1c  add rsp, 0x30
000073307ffd1e20  vmovaps xmm0, [rsp]
000073307ffd1e25  vmovaps xmm1, [rsp+0x10]
000073307ffd1e2b  vmovaps xmm2, [rsp+0x20]
000073307ffd1e31  vmovaps xmm3, [rsp+0x30]
000073307ffd1e37  vmovaps xmm4, [rsp+0x40]
000073307ffd1e3d  vmovaps xmm5, [rsp+0x50]
000073307ffd1e43  vmovaps xmm6, [rsp+0x60]
000073307ffd1e49  vmovaps xmm7, [rsp+0x70]
000073307ffd1e4f  vmovaps xmm8, [rsp+0x80]
000073307ffd1e58  vmovaps xmm9, [rsp+0x90]
000073307ffd1e61  vmovaps xmm10, [rsp+0xA0]
000073307ffd1e6a  vmovaps xmm11, [rsp+0xB0]
000073307ffd1e73  vmovaps xmm12, [rsp+0xC0]
000073307ffd1e7c  vmovaps xmm13, [rsp+0xD0]
000073307ffd1e85  vmovaps xmm15, [rsp+0xE0]
000073307ffd1e8e  add rsp, 0xF0
000073307ffd1e95  pop r11
000073307ffd1e97  pop r10
000073307ffd1e99  pop r9
000073307ffd1e9b  pop r8
000073307ffd1e9d  pop rsi
000073307ffd1e9e  pop rdi
000073307ffd1e9f  pop rdx
000073307ffd1ea0  pop rcx
000073307ffd1ea1  pop rax
000073307ffd1ea2  add rsp, 0x08
000073307ffd1ea6  jmp 0x000073307FFCFB24
000073307ffd1eab  sub rsp, 0x08
000073307ffd1eaf  push rax
000073307ffd1eb0  push rcx
000073307ffd1eb1  push rdx
000073307ffd1eb2  push rdi
000073307ffd1eb3  push rsi
000073307ffd1eb4  push r8
000073307ffd1eb6  push r9
000073307ffd1eb8  push r10
000073307ffd1eba  push r11
000073307ffd1ebc  sub rsp, 0xF0
000073307ffd1ec3  vmovaps [rsp], xmm0
000073307ffd1ec8  vmovaps [rsp+0x10], xmm2
000073307ffd1ece  vmovaps [rsp+0x20], xmm3
000073307ffd1ed4  vmovaps [rsp+0x30], xmm4
000073307ffd1eda  vmovaps [rsp+0x40], xmm5
000073307ffd1ee0  vmovaps [rsp+0x50], xmm6
000073307ffd1ee6  vmovaps [rsp+0x60], xmm7
000073307ffd1eec  vmovaps [rsp+0x70], xmm8
000073307ffd1ef2  vmovaps [rsp+0x80], xmm9
000073307ffd1efb  vmovaps [rsp+0x90], xmm10
000073307ffd1f04  vmovaps [rsp+0xA0], xmm11
000073307ffd1f0d  vmovaps [rsp+0xB0], xmm12
000073307ffd1f16  vmovaps [rsp+0xC0], xmm13
000073307ffd1f1f  vmovaps [rsp+0xD0], xmm14
000073307ffd1f28  vmovaps [rsp+0xE0], xmm15
000073307ffd1f31  sub rsp, 0x30
000073307ffd1f35  movaps [rsp], xmm1
000073307ffd1f39  movaps [rsp+0x10], xmm13
000073307ffd1f3f  movaps [rsp+0x20], xmm2
000073307ffd1f44  lea rdi, [rsp]
000073307ffd1f48  mov esi, 0x00
000073307ffd1f4d  mov rax, 0x600DE0EC8530
000073307ffd1f57  call rax
000073307ffd1f59  movaps xmm1, [rsp]
000073307ffd1f5d  add rsp, 0x30
000073307ffd1f61  vmovaps xmm0, [rsp]
000073307ffd1f66  vmovaps xmm2, [rsp+0x10]
000073307ffd1f6c  vmovaps xmm3, [rsp+0x20]
000073307ffd1f72  vmovaps xmm4, [rsp+0x30]
000073307ffd1f78  vmovaps xmm5, [rsp+0x40]
000073307ffd1f7e  vmovaps xmm6, [rsp+0x50]
000073307ffd1f84  vmovaps xmm7, [rsp+0x60]
000073307ffd1f8a  vmovaps xmm8, [rsp+0x70]
000073307ffd1f90  vmovaps xmm9, [rsp+0x80]
000073307ffd1f99  vmovaps xmm10, [rsp+0x90]
000073307ffd1fa2  vmovaps xmm11, [rsp+0xA0]
000073307ffd1fab  vmovaps xmm12, [rsp+0xB0]
000073307ffd1fb4  vmovaps xmm13, [rsp+0xC0]
000073307ffd1fbd  vmovaps xmm14, [rsp+0xD0]
000073307ffd1fc6  vmovaps xmm15, [rsp+0xE0]
000073307ffd1fcf  add rsp, 0xF0
000073307ffd1fd6  pop r11
000073307ffd1fd8  pop r10
000073307ffd1fda  pop r9
000073307ffd1fdc  pop r8
000073307ffd1fde  pop rsi
000073307ffd1fdf  pop rdi
000073307ffd1fe0  pop rdx
000073307ffd1fe1  pop rcx
000073307ffd1fe2  pop rax
000073307ffd1fe3  add rsp, 0x08
000073307ffd1fe7  jmp 0x000073307FFCFB52
000073307ffd1fec  sub rsp, 0x08
000073307ffd1ff0  push rax
000073307ffd1ff1  push rcx
000073307ffd1ff2  push rdx
000073307ffd1ff3  push rdi
000073307ffd1ff4  push rsi
000073307ffd1ff5  push r8
000073307ffd1ff7  push r9
000073307ffd1ff9  push r10
000073307ffd1ffb  push r11
000073307ffd1ffd  sub rsp, 0xF0
000073307ffd2004  vmovaps [rsp], xmm0
000073307ffd2009  vmovaps [rsp+0x10], xmm1
000073307ffd200f  vmovaps [rsp+0x20], xmm3
000073307ffd2015  vmovaps [rsp+0x30], xmm4
000073307ffd201b  vmovaps [rsp+0x40], xmm5
000073307ffd2021  vmovaps [rsp+0x50], xmm6
000073307ffd2027  vmovaps [rsp+0x60], xmm7
000073307ffd202d  vmovaps [rsp+0x70], xmm8
000073307ffd2033  vmovaps [rsp+0x80], xmm9
000073307ffd203c  vmovaps [rsp+0x90], xmm10
000073307ffd2045  vmovaps [rsp+0xA0], xmm11
000073307ffd204e  vmovaps [rsp+0xB0], xmm12
000073307ffd2057  vmovaps [rsp+0xC0], xmm13
000073307ffd2060  vmovaps [rsp+0xD0], xmm14
000073307ffd2069  vmovaps [rsp+0xE0], xmm15
000073307ffd2072  sub rsp, 0x30
000073307ffd2076  movaps [rsp], xmm2
000073307ffd207a  movaps [rsp+0x10], xmm1
000073307ffd207f  movaps [rsp+0x20], xmm13
000073307ffd2085  lea rdi, [rsp]
000073307ffd2089  mov esi, 0x00
000073307ffd208e  mov rax, 0x600DE0EC8530
000073307ffd2098  call rax
000073307ffd209a  movaps xmm2, [rsp]
000073307ffd209e  add rsp, 0x30
000073307ffd20a2  vmovaps xmm0, [rsp]
000073307ffd20a7  vmovaps xmm1, [rsp+0x10]
000073307ffd20ad  vmovaps xmm3, [rsp+0x20]
000073307ffd20b3  vmovaps xmm4, [rsp+0x30]
000073307ffd20b9  vmovaps xmm5, [rsp+0x40]
000073307ffd20bf  vmovaps xmm6, [rsp+0x50]
000073307ffd20c5  vmovaps xmm7, [rsp+0x60]
000073307ffd20cb  vmovaps xmm8, [rsp+0x70]
000073307ffd20d1  vmovaps xmm9, [rsp+0x80]
000073307ffd20da  vmovaps xmm10, [rsp+0x90]
000073307ffd20e3  vmovaps xmm11, [rsp+0xA0]
000073307ffd20ec  vmovaps xmm12, [rsp+0xB0]
000073307ffd20f5  vmovaps xmm13, [rsp+0xC0]
000073307ffd20fe  vmovaps xmm14, [rsp+0xD0]
000073307ffd2107  vmovaps xmm15, [rsp+0xE0]
000073307ffd2110  add rsp, 0xF0
000073307ffd2117  pop r11
000073307ffd2119  pop r10
000073307ffd211b  pop r9
000073307ffd211d  pop r8
000073307ffd211f  pop rsi
000073307ffd2120  pop rdi
000073307ffd2121  pop rdx
000073307ffd2122  pop rcx
000073307ffd2123  pop rax
000073307ffd2124  add rsp, 0x08
000073307ffd2128  jmp 0x000073307FFCFBAB
000073307ffd212d  call 0x000073307FDFF430
000073307ffd2132  jmp 0x000073307FFCFBB8
000073307ffd2137  sub rsp, 0x08
000073307ffd213b  push rax
000073307ffd213c  push rcx
000073307ffd213d  push rdx
000073307ffd213e  push rdi
000073307ffd213f  push rsi
000073307ffd2140  push r8
000073307ffd2142  push r9
000073307ffd2144  push r10
000073307ffd2146  push r11
000073307ffd2148  sub rsp, 0xF0
000073307ffd214f  vmovaps [rsp], xmm0
000073307ffd2154  vmovaps [rsp+0x10], xmm1
000073307ffd215a  vmovaps [rsp+0x20], xmm2
000073307ffd2160  vmovaps [rsp+0x30], xmm3
000073307ffd2166  vmovaps [rsp+0x40], xmm4
000073307ffd216c  vmovaps [rsp+0x50], xmm5
000073307ffd2172  vmovaps [rsp+0x60], xmm6
000073307ffd2178  vmovaps [rsp+0x70], xmm7
000073307ffd217e  vmovaps [rsp+0x80], xmm8
000073307ffd2187  vmovaps [rsp+0x90], xmm9
000073307ffd2190  vmovaps [rsp+0xA0], xmm10
000073307ffd2199  vmovaps [rsp+0xB0], xmm11
000073307ffd21a2  vmovaps [rsp+0xC0], xmm12
000073307ffd21ab  vmovaps [rsp+0xD0], xmm13
000073307ffd21b4  vmovaps [rsp+0xE0], xmm14
000073307ffd21bd  sub rsp, 0x30
000073307ffd21c1  movaps [rsp], xmm15
000073307ffd21c6  movaps [rsp+0x10], xmm13
000073307ffd21cc  movaps [rsp+0x20], xmm1
000073307ffd21d1  lea rdi, [rsp]
000073307ffd21d5  mov esi, 0x00
000073307ffd21da  mov rax, 0x600DE0EC8530
000073307ffd21e4  call rax
000073307ffd21e6  movaps xmm15, [rsp]
000073307ffd21eb  add rsp, 0x30
000073307ffd21ef  vmovaps xmm0, [rsp]
000073307ffd21f4  vmovaps xmm1, [rsp+0x10]
000073307ffd21fa  vmovaps xmm2, [rsp+0x20]
000073307ffd2200  vmovaps xmm3, [rsp+0x30]
000073307ffd2206  vmovaps xmm4, [rsp+0x40]
000073307ffd220c  vmovaps xmm5, [rsp+0x50]
000073307ffd2212  vmovaps xmm6, [rsp+0x60]
000073307ffd2218  vmovaps xmm7, [rsp+0x70]
000073307ffd221e  vmovaps xmm8, [rsp+0x80]
000073307ffd2227  vmovaps xmm9, [rsp+0x90]
000073307ffd2230  vmovaps xmm10, [rsp+0xA0]
000073307ffd2239  vmovaps xmm11, [rsp+0xB0]
000073307ffd2242  vmovaps xmm12, [rsp+0xC0]
000073307ffd224b  vmovaps xmm13, [rsp+0xD0]
000073307ffd2254  vmovaps xmm14, [rsp+0xE0]
000073307ffd225d  add rsp, 0xF0
000073307ffd2264  pop r11
000073307ffd2266  pop r10
000073307ffd2268  pop r9
000073307ffd226a  pop r8
000073307ffd226c  pop rsi
000073307ffd226d  pop rdi
000073307ffd226e  pop rdx
000073307ffd226f  pop rcx
000073307ffd2270  pop rax
000073307ffd2271  add rsp, 0x08
000073307ffd2275  jmp 0x000073307FFCFBF7
000073307ffd227a  sub rsp, 0x08
000073307ffd227e  push rax
000073307ffd227f  push rcx
000073307ffd2280  push rdx
000073307ffd2281  push rdi
000073307ffd2282  push rsi
000073307ffd2283  push r8
000073307ffd2285  push r9
000073307ffd2287  push r10
000073307ffd2289  push r11
000073307ffd228b  sub rsp, 0xF0
000073307ffd2292  vmovaps [rsp], xmm0
000073307ffd2297  vmovaps [rsp+0x10], xmm1
000073307ffd229d  vmovaps [rsp+0x20], xmm2
000073307ffd22a3  vmovaps [rsp+0x30], xmm3
000073307ffd22a9  vmovaps [rsp+0x40], xmm4
000073307ffd22af  vmovaps [rsp+0x50], xmm5
000073307ffd22b5  vmovaps [rsp+0x60], xmm6
000073307ffd22bb  vmovaps [rsp+0x70], xmm7
000073307ffd22c1  vmovaps [rsp+0x80], xmm8
000073307ffd22ca  vmovaps [rsp+0x90], xmm9
000073307ffd22d3  vmovaps [rsp+0xA0], xmm10
000073307ffd22dc  vmovaps [rsp+0xB0], xmm11
000073307ffd22e5  vmovaps [rsp+0xC0], xmm12
000073307ffd22ee  vmovaps [rsp+0xD0], xmm13
000073307ffd22f7  vmovaps [rsp+0xE0], xmm15
000073307ffd2300  sub rsp, 0x30
000073307ffd2304  movaps [rsp], xmm14
000073307ffd2309  movaps [rsp+0x10], xmm11
000073307ffd230f  movaps [rsp+0x20], xmm1
000073307ffd2314  lea rdi, [rsp]
000073307ffd2318  mov esi, 0x00
000073307ffd231d  mov rax, 0x600DE0EC8530
000073307ffd2327  call rax
000073307ffd2329  movaps xmm14, [rsp]
000073307ffd232e  add rsp, 0x30
000073307ffd2332  vmovaps xmm0, [rsp]
000073307ffd2337  vmovaps xmm1, [rsp+0x10]
000073307ffd233d  vmovaps xmm2, [rsp+0x20]
000073307ffd2343  vmovaps xmm3, [rsp+0x30]
000073307ffd2349  vmovaps xmm4, [rsp+0x40]
000073307ffd234f  vmovaps xmm5, [rsp+0x50]
000073307ffd2355  vmovaps xmm6, [rsp+0x60]
000073307ffd235b  vmovaps xmm7, [rsp+0x70]
000073307ffd2361  vmovaps xmm8, [rsp+0x80]
000073307ffd236a  vmovaps xmm9, [rsp+0x90]
000073307ffd2373  vmovaps xmm10, [rsp+0xA0]
000073307ffd237c  vmovaps xmm11, [rsp+0xB0]
000073307ffd2385  vmovaps xmm12, [rsp+0xC0]
000073307ffd238e  vmovaps xmm13, [rsp+0xD0]
000073307ffd2397  vmovaps xmm15, [rsp+0xE0]
000073307ffd23a0  add rsp, 0xF0
000073307ffd23a7  pop r11
000073307ffd23a9  pop r10
000073307ffd23ab  pop r9
000073307ffd23ad  pop r8
000073307ffd23af  pop rsi
000073307ffd23b0  pop rdi
000073307ffd23b1  pop rdx
000073307ffd23b2  pop rcx
000073307ffd23b3  pop rax
000073307ffd23b4  add rsp, 0x08
000073307ffd23b8  jmp 0x000073307FFCFC21
000073307ffd23bd  sub rsp, 0x08
000073307ffd23c1  push rax
000073307ffd23c2  push rcx
000073307ffd23c3  push rdx
000073307ffd23c4  push rdi
000073307ffd23c5  push rsi
000073307ffd23c6  push r8
000073307ffd23c8  push r9
000073307ffd23ca  push r10
000073307ffd23cc  push r11
000073307ffd23ce  sub rsp, 0xF0
000073307ffd23d5  vmovaps [rsp], xmm0
000073307ffd23da  vmovaps [rsp+0x10], xmm1
000073307ffd23e0  vmovaps [rsp+0x20], xmm2
000073307ffd23e6  vmovaps [rsp+0x30], xmm3
000073307ffd23ec  vmovaps [rsp+0x40], xmm4
000073307ffd23f2  vmovaps [rsp+0x50], xmm5
000073307ffd23f8  vmovaps [rsp+0x60], xmm6
000073307ffd23fe  vmovaps [rsp+0x70], xmm7
000073307ffd2404  vmovaps [rsp+0x80], xmm8
000073307ffd240d  vmovaps [rsp+0x90], xmm9
000073307ffd2416  vmovaps [rsp+0xA0], xmm10
000073307ffd241f  vmovaps [rsp+0xB0], xmm11
000073307ffd2428  vmovaps [rsp+0xC0], xmm12
000073307ffd2431  vmovaps [rsp+0xD0], xmm14
000073307ffd243a  vmovaps [rsp+0xE0], xmm15
000073307ffd2443  sub rsp, 0x30
000073307ffd2447  movaps [rsp], xmm13
000073307ffd244c  movaps [rsp+0x10], xmm11
000073307ffd2452  movaps [rsp+0x20], xmm1
000073307ffd2457  lea rdi, [rsp]
000073307ffd245b  mov esi, 0x00
000073307ffd2460  mov rax, 0x600DE0EC8530
000073307ffd246a  call rax
000073307ffd246c  movaps xmm13, [rsp]
000073307ffd2471  add rsp, 0x30
000073307ffd2475  vmovaps xmm0, [rsp]
000073307ffd247a  vmovaps xmm1, [rsp+0x10]
000073307ffd2480  vmovaps xmm2, [rsp+0x20]
000073307ffd2486  vmovaps xmm3, [rsp+0x30]
000073307ffd248c  vmovaps xmm4, [rsp+0x40]
000073307ffd2492  vmovaps xmm5, [rsp+0x50]
000073307ffd2498  vmovaps xmm6, [rsp+0x60]
000073307ffd249e  vmovaps xmm7, [rsp+0x70]
000073307ffd24a4  vmovaps xmm8, [rsp+0x80]
000073307ffd24ad  vmovaps xmm9, [rsp+0x90]
000073307ffd24b6  vmovaps xmm10, [rsp+0xA0]
000073307ffd24bf  vmovaps xmm11, [rsp+0xB0]
000073307ffd24c8  vmovaps xmm12, [rsp+0xC0]
000073307ffd24d1  vmovaps xmm14, [rsp+0xD0]
000073307ffd24da  vmovaps xmm15, [rsp+0xE0]
000073307ffd24e3  add rsp, 0xF0
000073307ffd24ea  pop r11
000073307ffd24ec  pop r10
000073307ffd24ee  pop r9
000073307ffd24f0  pop r8
000073307ffd24f2  pop rsi
000073307ffd24f3  pop rdi
000073307ffd24f4  pop rdx
000073307ffd24f5  pop rcx
000073307ffd24f6  pop rax
000073307ffd24f7  add rsp, 0x08
000073307ffd24fb  jmp 0x000073307FFCFC76
000073307ffd2500  call 0x000073307FDFF430
000073307ffd2505  jmp 0x000073307FFCFC83
000073307ffd250a  sub rsp, 0x08
000073307ffd250e  push rax
000073307ffd250f  push rcx
000073307ffd2510  push rdx
000073307ffd2511  push rdi
000073307ffd2512  push rsi
000073307ffd2513  push r8
000073307ffd2515  push r9
000073307ffd2517  push r10
000073307ffd2519  push r11
000073307ffd251b  sub rsp, 0xF0
000073307ffd2522  vmovaps [rsp], xmm0
000073307ffd2527  vmovaps [rsp+0x10], xmm1
000073307ffd252d  vmovaps [rsp+0x20], xmm2
000073307ffd2533  vmovaps [rsp+0x30], xmm3
000073307ffd2539  vmovaps [rsp+0x40], xmm4
000073307ffd253f  vmovaps [rsp+0x50], xmm5
000073307ffd2545  vmovaps [rsp+0x60], xmm6
000073307ffd254b  vmovaps [rsp+0x70], xmm7
000073307ffd2551  vmovaps [rsp+0x80], xmm8
000073307ffd255a  vmovaps [rsp+0x90], xmm9
000073307ffd2563  vmovaps [rsp+0xA0], xmm10
000073307ffd256c  vmovaps [rsp+0xB0], xmm11
000073307ffd2575  vmovaps [rsp+0xC0], xmm12
000073307ffd257e  vmovaps [rsp+0xD0], xmm13
000073307ffd2587  vmovaps [rsp+0xE0], xmm14
000073307ffd2590  sub rsp, 0x30
000073307ffd2594  movaps [rsp], xmm15
000073307ffd2599  movaps [rsp+0x10], xmm11
000073307ffd259f  movaps [rsp+0x20], xmm1
000073307ffd25a4  lea rdi, [rsp]
000073307ffd25a8  mov esi, 0x00
000073307ffd25ad  mov rax, 0x600DE0EC8530
000073307ffd25b7  call rax
000073307ffd25b9  movaps xmm15, [rsp]
000073307ffd25be  add rsp, 0x30
000073307ffd25c2  vmovaps xmm0, [rsp]
000073307ffd25c7  vmovaps xmm1, [rsp+0x10]
000073307ffd25cd  vmovaps xmm2, [rsp+0x20]
000073307ffd25d3  vmovaps xmm3, [rsp+0x30]
000073307ffd25d9  vmovaps xmm4, [rsp+0x40]
000073307ffd25df  vmovaps xmm5, [rsp+0x50]
000073307ffd25e5  vmovaps xmm6, [rsp+0x60]
000073307ffd25eb  vmovaps xmm7, [rsp+0x70]
000073307ffd25f1  vmovaps xmm8, [rsp+0x80]
000073307ffd25fa  vmovaps xmm9, [rsp+0x90]
000073307ffd2603  vmovaps xmm10, [rsp+0xA0]
000073307ffd260c  vmovaps xmm11, [rsp+0xB0]
000073307ffd2615  vmovaps xmm12, [rsp+0xC0]
000073307ffd261e  vmovaps xmm13, [rsp+0xD0]
000073307ffd2627  vmovaps xmm14, [rsp+0xE0]
000073307ffd2630  add rsp, 0xF0
000073307ffd2637  pop r11
000073307ffd2639  pop r10
000073307ffd263b  pop r9
000073307ffd263d  pop r8
000073307ffd263f  pop rsi
000073307ffd2640  pop rdi
000073307ffd2641  pop rdx
000073307ffd2642  pop rcx
000073307ffd2643  pop rax
000073307ffd2644  add rsp, 0x08
000073307ffd2648  jmp 0x000073307FFCFCBC
000073307ffd264d  sub rsp, 0x08
000073307ffd2651  push rax
000073307ffd2652  push rcx
000073307ffd2653  push rdx
000073307ffd2654  push rdi
000073307ffd2655  push rsi
000073307ffd2656  push r8
000073307ffd2658  push r9
000073307ffd265a  push r10
000073307ffd265c  push r11
000073307ffd265e  sub rsp, 0xF0
000073307ffd2665  vmovaps [rsp], xmm0
000073307ffd266a  vmovaps [rsp+0x10], xmm1
000073307ffd2670  vmovaps [rsp+0x20], xmm2
000073307ffd2676  vmovaps [rsp+0x30], xmm3
000073307ffd267c  vmovaps [rsp+0x40], xmm4
000073307ffd2682  vmovaps [rsp+0x50], xmm5
000073307ffd2688  vmovaps [rsp+0x60], xmm6
000073307ffd268e  vmovaps [rsp+0x70], xmm7
000073307ffd2694  vmovaps [rsp+0x80], xmm8
000073307ffd269d  vmovaps [rsp+0x90], xmm9
000073307ffd26a6  vmovaps [rsp+0xA0], xmm10
000073307ffd26af  vmovaps [rsp+0xB0], xmm12
000073307ffd26b8  vmovaps [rsp+0xC0], xmm13
000073307ffd26c1  vmovaps [rsp+0xD0], xmm14
000073307ffd26ca  vmovaps [rsp+0xE0], xmm15
000073307ffd26d3  sub rsp, 0x30
000073307ffd26d7  movaps [rsp], xmm11
000073307ffd26dc  movaps [rsp+0x10], xmm6
000073307ffd26e1  movaps [rsp+0x20], xmm14
000073307ffd26e7  lea rdi, [rsp]
000073307ffd26eb  mov esi, 0x00
000073307ffd26f0  mov rax, 0x600DE0EC8530
000073307ffd26fa  call rax
000073307ffd26fc  movaps xmm11, [rsp]
000073307ffd2701  add rsp, 0x30
000073307ffd2705  vmovaps xmm0, [rsp]
000073307ffd270a  vmovaps xmm1, [rsp+0x10]
000073307ffd2710  vmovaps xmm2, [rsp+0x20]
000073307ffd2716  vmovaps xmm3, [rsp+0x30]
000073307ffd271c  vmovaps xmm4, [rsp+0x40]
000073307ffd2722  vmovaps xmm5, [rsp+0x50]
000073307ffd2728  vmovaps xmm6, [rsp+0x60]
000073307ffd272e  vmovaps xmm7, [rsp+0x70]
000073307ffd2734  vmovaps xmm8, [rsp+0x80]
000073307ffd273d  vmovaps xmm9, [rsp+0x90]
000073307ffd2746  vmovaps xmm10, [rsp+0xA0]
000073307ffd274f  vmovaps xmm12, [rsp+0xB0]
000073307ffd2758  vmovaps xmm13, [rsp+0xC0]
000073307ffd2761  vmovaps xmm14, [rsp+0xD0]
000073307ffd276a  vmovaps xmm15, [rsp+0xE0]
000073307ffd2773  add rsp, 0xF0
000073307ffd277a  pop r11
000073307ffd277c  pop r10
000073307ffd277e  pop r9
000073307ffd2780  pop r8
000073307ffd2782  pop rsi
000073307ffd2783  pop rdi
000073307ffd2784  pop rdx
000073307ffd2785  pop rcx
000073307ffd2786  pop rax
000073307ffd2787  add rsp, 0x08
000073307ffd278b  jmp 0x000073307FFCFD34
000073307ffd2790  call 0x000073307FDFF430
000073307ffd2795  jmp 0x000073307FFCFD3E
000073307ffd279a  sub rsp, 0x08
000073307ffd279e  push rax
000073307ffd279f  push rcx
000073307ffd27a0  push rdx
000073307ffd27a1  push rdi
000073307ffd27a2  push rsi
000073307ffd27a3  push r8
000073307ffd27a5  push r9
000073307ffd27a7  push r10
000073307ffd27a9  push r11
000073307ffd27ab  sub rsp, 0xF0
000073307ffd27b2  vmovaps [rsp], xmm0
000073307ffd27b7  vmovaps [rsp+0x10], xmm1
000073307ffd27bd  vmovaps [rsp+0x20], xmm2
000073307ffd27c3  vmovaps [rsp+0x30], xmm3
000073307ffd27c9  vmovaps [rsp+0x40], xmm4
000073307ffd27cf  vmovaps [rsp+0x50], xmm5
000073307ffd27d5  vmovaps [rsp+0x60], xmm6
000073307ffd27db  vmovaps [rsp+0x70], xmm7
000073307ffd27e1  vmovaps [rsp+0x80], xmm8
000073307ffd27ea  vmovaps [rsp+0x90], xmm9
000073307ffd27f3  vmovaps [rsp+0xA0], xmm10
000073307ffd27fc  vmovaps [rsp+0xB0], xmm11
000073307ffd2805  vmovaps [rsp+0xC0], xmm12
000073307ffd280e  vmovaps [rsp+0xD0], xmm13
000073307ffd2817  vmovaps [rsp+0xE0], xmm15
000073307ffd2820  sub rsp, 0x30
000073307ffd2824  movaps [rsp], xmm14
000073307ffd2829  movaps [rsp+0x10], xmm6
000073307ffd282e  movaps [rsp+0x20], xmm2
000073307ffd2833  lea rdi, [rsp]
000073307ffd2837  mov esi, 0x00
000073307ffd283c  mov rax, 0x600DE0EC8530
000073307ffd2846  call rax
000073307ffd2848  movaps xmm14, [rsp]
000073307ffd284d  add rsp, 0x30
000073307ffd2851  vmovaps xmm0, [rsp]
000073307ffd2856  vmovaps xmm1, [rsp+0x10]
000073307ffd285c  vmovaps xmm2, [rsp+0x20]
000073307ffd2862  vmovaps xmm3, [rsp+0x30]
000073307ffd2868  vmovaps xmm4, [rsp+0x40]
000073307ffd286e  vmovaps xmm5, [rsp+0x50]
000073307ffd2874  vmovaps xmm6, [rsp+0x60]
000073307ffd287a  vmovaps xmm7, [rsp+0x70]
000073307ffd2880  vmovaps xmm8, [rsp+0x80]
000073307ffd2889  vmovaps xmm9, [rsp+0x90]
000073307ffd2892  vmovaps xmm10, [rsp+0xA0]
000073307ffd289b  vmovaps xmm11, [rsp+0xB0]
000073307ffd28a4  vmovaps xmm12, [rsp+0xC0]
000073307ffd28ad  vmovaps xmm13, [rsp+0xD0]
000073307ffd28b6  vmovaps xmm15, [rsp+0xE0]
000073307ffd28bf  add rsp, 0xF0
000073307ffd28c6  pop r11
000073307ffd28c8  pop r10
000073307ffd28ca  pop r9
000073307ffd28cc  pop r8
000073307ffd28ce  pop rsi
000073307ffd28cf  pop rdi
000073307ffd28d0  pop rdx
000073307ffd28d1  pop rcx
000073307ffd28d2  pop rax
000073307ffd28d3  add rsp, 0x08
000073307ffd28d7  jmp 0x000073307FFCFD72
000073307ffd28dc  sub rsp, 0x08
000073307ffd28e0  push rax
000073307ffd28e1  push rcx
000073307ffd28e2  push rdx
000073307ffd28e3  push rdi
000073307ffd28e4  push rsi
000073307ffd28e5  push r8
000073307ffd28e7  push r9
000073307ffd28e9  push r10
000073307ffd28eb  push r11
000073307ffd28ed  sub rsp, 0xF0
000073307ffd28f4  vmovaps [rsp], xmm0
000073307ffd28f9  vmovaps [rsp+0x10], xmm1
000073307ffd28ff  vmovaps [rsp+0x20], xmm2
000073307ffd2905  vmovaps [rsp+0x30], xmm3
000073307ffd290b  vmovaps [rsp+0x40], xmm4
000073307ffd2911  vmovaps [rsp+0x50], xmm5
000073307ffd2917  vmovaps [rsp+0x60], xmm7
000073307ffd291d  vmovaps [rsp+0x70], xmm8
000073307ffd2923  vmovaps [rsp+0x80], xmm9
000073307ffd292c  vmovaps [rsp+0x90], xmm10
000073307ffd2935  vmovaps [rsp+0xA0], xmm11
000073307ffd293e  vmovaps [rsp+0xB0], xmm12
000073307ffd2947  vmovaps [rsp+0xC0], xmm13
000073307ffd2950  vmovaps [rsp+0xD0], xmm14
000073307ffd2959  vmovaps [rsp+0xE0], xmm15
000073307ffd2962  sub rsp, 0x30
000073307ffd2966  movaps [rsp], xmm6
000073307ffd296a  movaps [rsp+0x10], xmm5
000073307ffd296f  movaps [rsp+0x20], xmm1
000073307ffd2974  lea rdi, [rsp]
000073307ffd2978  mov esi, 0x00
000073307ffd297d  mov rax, 0x600DE0EC8530
000073307ffd2987  call rax
000073307ffd2989  movaps xmm6, [rsp]
000073307ffd298d  add rsp, 0x30
000073307ffd2991  vmovaps xmm0, [rsp]
000073307ffd2996  vmovaps xmm1, [rsp+0x10]
000073307ffd299c  vmovaps xmm2, [rsp+0x20]
000073307ffd29a2  vmovaps xmm3, [rsp+0x30]
000073307ffd29a8  vmovaps xmm4, [rsp+0x40]
000073307ffd29ae  vmovaps xmm5, [rsp+0x50]
000073307ffd29b4  vmovaps xmm7, [rsp+0x60]
000073307ffd29ba  vmovaps xmm8, [rsp+0x70]
000073307ffd29c0  vmovaps xmm9, [rsp+0x80]
000073307ffd29c9  vmovaps xmm10, [rsp+0x90]
000073307ffd29d2  vmovaps xmm11, [rsp+0xA0]
000073307ffd29db  vmovaps xmm12, [rsp+0xB0]
000073307ffd29e4  vmovaps xmm13, [rsp+0xC0]
000073307ffd29ed  vmovaps xmm14, [rsp+0xD0]
000073307ffd29f6  vmovaps xmm15, [rsp+0xE0]
000073307ffd29ff  add rsp, 0xF0
000073307ffd2a06  pop r11
000073307ffd2a08  pop r10
000073307ffd2a0a  pop r9
000073307ffd2a0c  pop r8
000073307ffd2a0e  pop rsi
000073307ffd2a0f  pop rdi
000073307ffd2a10  pop rdx
000073307ffd2a11  pop rcx
000073307ffd2a12  pop rax
000073307ffd2a13  add rsp, 0x08
000073307ffd2a17  jmp 0x000073307FFCFD98
000073307ffd2a1c  sub rsp, 0x08
000073307ffd2a20  push rax
000073307ffd2a21  push rcx
000073307ffd2a22  push rdx
000073307ffd2a23  push rdi
000073307ffd2a24  push rsi
000073307ffd2a25  push r8
000073307ffd2a27  push r9
000073307ffd2a29  push r10
000073307ffd2a2b  push r11
000073307ffd2a2d  sub rsp, 0xF0
000073307ffd2a34  vmovaps [rsp], xmm0
000073307ffd2a39  vmovaps [rsp+0x10], xmm2
000073307ffd2a3f  vmovaps [rsp+0x20], xmm3
000073307ffd2a45  vmovaps [rsp+0x30], xmm4
000073307ffd2a4b  vmovaps [rsp+0x40], xmm5
000073307ffd2a51  vmovaps [rsp+0x50], xmm6
000073307ffd2a57  vmovaps [rsp+0x60], xmm7
000073307ffd2a5d  vmovaps [rsp+0x70], xmm8
000073307ffd2a63  vmovaps [rsp+0x80], xmm9
000073307ffd2a6c  vmovaps [rsp+0x90], xmm10
000073307ffd2a75  vmovaps [rsp+0xA0], xmm11
000073307ffd2a7e  vmovaps [rsp+0xB0], xmm12
000073307ffd2a87  vmovaps [rsp+0xC0], xmm13
000073307ffd2a90  vmovaps [rsp+0xD0], xmm14
000073307ffd2a99  vmovaps [rsp+0xE0], xmm15
000073307ffd2aa2  sub rsp, 0x30
000073307ffd2aa6  movaps [rsp], xmm1
000073307ffd2aaa  movaps [rsp+0x10], xmm5
000073307ffd2aaf  movaps [rsp+0x20], xmm13
000073307ffd2ab5  lea rdi, [rsp]
000073307ffd2ab9  mov esi, 0x00
000073307ffd2abe  mov rax, 0x600DE0EC8530
000073307ffd2ac8  call rax
000073307ffd2aca  movaps xmm1, [rsp]
000073307ffd2ace  add rsp, 0x30
000073307ffd2ad2  vmovaps xmm0, [rsp]
000073307ffd2ad7  vmovaps xmm2, [rsp+0x10]
000073307ffd2add  vmovaps xmm3, [rsp+0x20]
000073307ffd2ae3  vmovaps xmm4, [rsp+0x30]
000073307ffd2ae9  vmovaps xmm5, [rsp+0x40]
000073307ffd2aef  vmovaps xmm6, [rsp+0x50]
000073307ffd2af5  vmovaps xmm7, [rsp+0x60]
000073307ffd2afb  vmovaps xmm8, [rsp+0x70]
000073307ffd2b01  vmovaps xmm9, [rsp+0x80]
000073307ffd2b0a  vmovaps xmm10, [rsp+0x90]
000073307ffd2b13  vmovaps xmm11, [rsp+0xA0]
000073307ffd2b1c  vmovaps xmm12, [rsp+0xB0]
000073307ffd2b25  vmovaps xmm13, [rsp+0xC0]
000073307ffd2b2e  vmovaps xmm14, [rsp+0xD0]
000073307ffd2b37  vmovaps xmm15, [rsp+0xE0]
000073307ffd2b40  add rsp, 0xF0
000073307ffd2b47  pop r11
000073307ffd2b49  pop r10
000073307ffd2b4b  pop r9
000073307ffd2b4d  pop r8
000073307ffd2b4f  pop rsi
000073307ffd2b50  pop rdi
000073307ffd2b51  pop rdx
000073307ffd2b52  pop rcx
000073307ffd2b53  pop rax
000073307ffd2b54  add rsp, 0x08
000073307ffd2b58  jmp 0x000073307FFCFDB6
000073307ffd2b5d  sub rsp, 0x08
000073307ffd2b61  push rax
000073307ffd2b62  push rcx
000073307ffd2b63  push rdx
000073307ffd2b64  push rdi
000073307ffd2b65  push rsi
000073307ffd2b66  push r8
000073307ffd2b68  push r9
000073307ffd2b6a  push r10
000073307ffd2b6c  push r11
000073307ffd2b6e  sub rsp, 0xF0
000073307ffd2b75  vmovaps [rsp], xmm0
000073307ffd2b7a  vmovaps [rsp+0x10], xmm1
000073307ffd2b80  vmovaps [rsp+0x20], xmm2
000073307ffd2b86  vmovaps [rsp+0x30], xmm3
000073307ffd2b8c  vmovaps [rsp+0x40], xmm4
000073307ffd2b92  vmovaps [rsp+0x50], xmm6
000073307ffd2b98  vmovaps [rsp+0x60], xmm7
000073307ffd2b9e  vmovaps [rsp+0x70], xmm8
000073307ffd2ba4  vmovaps [rsp+0x80], xmm9
000073307ffd2bad  vmovaps [rsp+0x90], xmm10
000073307ffd2bb6  vmovaps [rsp+0xA0], xmm11
000073307ffd2bbf  vmovaps [rsp+0xB0], xmm12
000073307ffd2bc8  vmovaps [rsp+0xC0], xmm13
000073307ffd2bd1  vmovaps [rsp+0xD0], xmm14
000073307ffd2bda  vmovaps [rsp+0xE0], xmm15
000073307ffd2be3  sub rsp, 0x30
000073307ffd2be7  movaps [rsp], xmm5
000073307ffd2beb  movaps [rsp+0x10], xmm2
000073307ffd2bf0  movaps [rsp+0x20], xmm13
000073307ffd2bf6  lea rdi, [rsp]
000073307ffd2bfa  mov esi, 0x00
000073307ffd2bff  mov rax, 0x600DE0EC8530
000073307ffd2c09  call rax
000073307ffd2c0b  movaps xmm5, [rsp]
000073307ffd2c0f  add rsp, 0x30
000073307ffd2c13  vmovaps xmm0, [rsp]
000073307ffd2c18  vmovaps xmm1, [rsp+0x10]
000073307ffd2c1e  vmovaps xmm2, [rsp+0x20]
000073307ffd2c24  vmovaps xmm3, [rsp+0x30]
000073307ffd2c2a  vmovaps xmm4, [rsp+0x40]
000073307ffd2c30  vmovaps xmm6, [rsp+0x50]
000073307ffd2c36  vmovaps xmm7, [rsp+0x60]
000073307ffd2c3c  vmovaps xmm8, [rsp+0x70]
000073307ffd2c42  vmovaps xmm9, [rsp+0x80]
000073307ffd2c4b  vmovaps xmm10, [rsp+0x90]
000073307ffd2c54  vmovaps xmm11, [rsp+0xA0]
000073307ffd2c5d  vmovaps xmm12, [rsp+0xB0]
000073307ffd2c66  vmovaps xmm13, [rsp+0xC0]
000073307ffd2c6f  vmovaps xmm14, [rsp+0xD0]
000073307ffd2c78  vmovaps xmm15, [rsp+0xE0]
000073307ffd2c81  add rsp, 0xF0
000073307ffd2c88  pop r11
000073307ffd2c8a  pop r10
000073307ffd2c8c  pop r9
000073307ffd2c8e  pop r8
000073307ffd2c90  pop rsi
000073307ffd2c91  pop rdi
000073307ffd2c92  pop rdx
000073307ffd2c93  pop rcx
000073307ffd2c94  pop rax
000073307ffd2c95  add rsp, 0x08
000073307ffd2c99  jmp 0x000073307FFCFDEC
000073307ffd2c9e  sub rsp, 0x08
000073307ffd2ca2  push rax
000073307ffd2ca3  push rcx
000073307ffd2ca4  push rdx
000073307ffd2ca5  push rdi
000073307ffd2ca6  push rsi
000073307ffd2ca7  push r8
000073307ffd2ca9  push r9
000073307ffd2cab  push r10
000073307ffd2cad  push r11
000073307ffd2caf  sub rsp, 0xF0
000073307ffd2cb6  vmovaps [rsp], xmm0
000073307ffd2cbb  vmovaps [rsp+0x10], xmm1
000073307ffd2cc1  vmovaps [rsp+0x20], xmm2
000073307ffd2cc7  vmovaps [rsp+0x30], xmm3
000073307ffd2ccd  vmovaps [rsp+0x40], xmm4
000073307ffd2cd3  vmovaps [rsp+0x50], xmm5
000073307ffd2cd9  vmovaps [rsp+0x60], xmm6
000073307ffd2cdf  vmovaps [rsp+0x70], xmm7
000073307ffd2ce5  vmovaps [rsp+0x80], xmm8
000073307ffd2cee  vmovaps [rsp+0x90], xmm9
000073307ffd2cf7  vmovaps [rsp+0xA0], xmm10
000073307ffd2d00  vmovaps [rsp+0xB0], xmm11
000073307ffd2d09  vmovaps [rsp+0xC0], xmm12
000073307ffd2d12  vmovaps [rsp+0xD0], xmm14
000073307ffd2d1b  vmovaps [rsp+0xE0], xmm15
000073307ffd2d24  sub rsp, 0x30
000073307ffd2d28  movaps [rsp], xmm13
000073307ffd2d2d  movaps [rsp+0x10], xmm10
000073307ffd2d33  movaps [rsp+0x20], xmm1
000073307ffd2d38  lea rdi, [rsp]
000073307ffd2d3c  mov esi, 0x00
000073307ffd2d41  mov rax, 0x600DE0EC8530
000073307ffd2d4b  call rax
000073307ffd2d4d  movaps xmm13, [rsp]
000073307ffd2d52  add rsp, 0x30
000073307ffd2d56  vmovaps xmm0, [rsp]
000073307ffd2d5b  vmovaps xmm1, [rsp+0x10]
000073307ffd2d61  vmovaps xmm2, [rsp+0x20]
000073307ffd2d67  vmovaps xmm3, [rsp+0x30]
000073307ffd2d6d  vmovaps xmm4, [rsp+0x40]
000073307ffd2d73  vmovaps xmm5, [rsp+0x50]
000073307ffd2d79  vmovaps xmm6, [rsp+0x60]
000073307ffd2d7f  vmovaps xmm7, [rsp+0x70]
000073307ffd2d85  vmovaps xmm8, [rsp+0x80]
000073307ffd2d8e  vmovaps xmm9, [rsp+0x90]
000073307ffd2d97  vmovaps xmm10, [rsp+0xA0]
000073307ffd2da0  vmovaps xmm11, [rsp+0xB0]
000073307ffd2da9  vmovaps xmm12, [rsp+0xC0]
000073307ffd2db2  vmovaps xmm14, [rsp+0xD0]
000073307ffd2dbb  vmovaps xmm15, [rsp+0xE0]
000073307ffd2dc4  add rsp, 0xF0
000073307ffd2dcb  pop r11
000073307ffd2dcd  pop r10
000073307ffd2dcf  pop r9
000073307ffd2dd1  pop r8
000073307ffd2dd3  pop rsi
000073307ffd2dd4  pop rdi
000073307ffd2dd5  pop rdx
000073307ffd2dd6  pop rcx
000073307ffd2dd7  pop rax
000073307ffd2dd8  add rsp, 0x08
000073307ffd2ddc  jmp 0x000073307FFCFE15
000073307ffd2de1  sub rsp, 0x08
000073307ffd2de5  push rax
000073307ffd2de6  push rcx
000073307ffd2de7  push rdx
000073307ffd2de8  push rdi
000073307ffd2de9  push rsi
000073307ffd2dea  push r8
000073307ffd2dec  push r9
000073307ffd2dee  push r10
000073307ffd2df0  push r11
000073307ffd2df2  sub rsp, 0xF0
000073307ffd2df9  vmovaps [rsp], xmm0
000073307ffd2dfe  vmovaps [rsp+0x10], xmm2
000073307ffd2e04  vmovaps [rsp+0x20], xmm3
000073307ffd2e0a  vmovaps [rsp+0x30], xmm4
000073307ffd2e10  vmovaps [rsp+0x40], xmm5
000073307ffd2e16  vmovaps [rsp+0x50], xmm6
000073307ffd2e1c  vmovaps [rsp+0x60], xmm7
000073307ffd2e22  vmovaps [rsp+0x70], xmm8
000073307ffd2e28  vmovaps [rsp+0x80], xmm9
000073307ffd2e31  vmovaps [rsp+0x90], xmm10
000073307ffd2e3a  vmovaps [rsp+0xA0], xmm11
000073307ffd2e43  vmovaps [rsp+0xB0], xmm12
000073307ffd2e4c  vmovaps [rsp+0xC0], xmm13
000073307ffd2e55  vmovaps [rsp+0xD0], xmm14
000073307ffd2e5e  vmovaps [rsp+0xE0], xmm15
000073307ffd2e67  sub rsp, 0x30
000073307ffd2e6b  movaps [rsp], xmm1
000073307ffd2e6f  movaps [rsp+0x10], xmm15
000073307ffd2e75  movaps [rsp+0x20], xmm10
000073307ffd2e7b  lea rdi, [rsp]
000073307ffd2e7f  mov esi, 0x00
000073307ffd2e84  mov rax, 0x600DE0EC8530
000073307ffd2e8e  call rax
000073307ffd2e90  movaps xmm1, [rsp]
000073307ffd2e94  add rsp, 0x30
000073307ffd2e98  vmovaps xmm0, [rsp]
000073307ffd2e9d  vmovaps xmm2, [rsp+0x10]
000073307ffd2ea3  vmovaps xmm3, [rsp+0x20]
000073307ffd2ea9  vmovaps xmm4, [rsp+0x30]
000073307ffd2eaf  vmovaps xmm5, [rsp+0x40]
000073307ffd2eb5  vmovaps xmm6, [rsp+0x50]
000073307ffd2ebb  vmovaps xmm7, [rsp+0x60]
000073307ffd2ec1  vmovaps xmm8, [rsp+0x70]
000073307ffd2ec7  vmovaps xmm9, [rsp+0x80]
000073307ffd2ed0  vmovaps xmm10, [rsp+0x90]
000073307ffd2ed9  vmovaps xmm11, [rsp+0xA0]
000073307ffd2ee2  vmovaps xmm12, [rsp+0xB0]
000073307ffd2eeb  vmovaps xmm13, [rsp+0xC0]
000073307ffd2ef4  vmovaps xmm14, [rsp+0xD0]
000073307ffd2efd  vmovaps xmm15, [rsp+0xE0]
000073307ffd2f06  add rsp, 0xF0
000073307ffd2f0d  pop r11
000073307ffd2f0f  pop r10
000073307ffd2f11  pop r9
000073307ffd2f13  pop r8
000073307ffd2f15  pop rsi
000073307ffd2f16  pop rdi
000073307ffd2f17  pop rdx
000073307ffd2f18  pop rcx
000073307ffd2f19  pop rax
000073307ffd2f1a  add rsp, 0x08
000073307ffd2f1e  jmp 0x000073307FFCFE34
000073307ffd2f23  sub rsp, 0x08
000073307ffd2f27  push rax
000073307ffd2f28  push rcx
000073307ffd2f29  push rdx
000073307ffd2f2a  push rdi
000073307ffd2f2b  push rsi
000073307ffd2f2c  push r8
000073307ffd2f2e  push r9
000073307ffd2f30  push r10
000073307ffd2f32  push r11
000073307ffd2f34  sub rsp, 0xF0
000073307ffd2f3b  vmovaps [rsp], xmm0
000073307ffd2f40  vmovaps [rsp+0x10], xmm1
000073307ffd2f46  vmovaps [rsp+0x20], xmm2
000073307ffd2f4c  vmovaps [rsp+0x30], xmm3
000073307ffd2f52  vmovaps [rsp+0x40], xmm4
000073307ffd2f58  vmovaps [rsp+0x50], xmm5
000073307ffd2f5e  vmovaps [rsp+0x60], xmm6
000073307ffd2f64  vmovaps [rsp+0x70], xmm7
000073307ffd2f6a  vmovaps [rsp+0x80], xmm8
000073307ffd2f73  vmovaps [rsp+0x90], xmm9
000073307ffd2f7c  vmovaps [rsp+0xA0], xmm10
000073307ffd2f85  vmovaps [rsp+0xB0], xmm11
000073307ffd2f8e  vmovaps [rsp+0xC0], xmm12
000073307ffd2f97  vmovaps [rsp+0xD0], xmm13
000073307ffd2fa0  vmovaps [rsp+0xE0], xmm14
000073307ffd2fa9  sub rsp, 0x30
000073307ffd2fad  movaps [rsp], xmm15
000073307ffd2fb2  movaps [rsp+0x10], xmm10
000073307ffd2fb8  movaps [rsp+0x20], xmm11
000073307ffd2fbe  lea rdi, [rsp]
000073307ffd2fc2  mov esi, 0x00
000073307ffd2fc7  mov rax, 0x600DE0EC8530
000073307ffd2fd1  call rax
000073307ffd2fd3  movaps xmm15, [rsp]
000073307ffd2fd8  add rsp, 0x30
000073307ffd2fdc  vmovaps xmm0, [rsp]
000073307ffd2fe1  vmovaps xmm1, [rsp+0x10]
000073307ffd2fe7  vmovaps xmm2, [rsp+0x20]
000073307ffd2fed  vmovaps xmm3, [rsp+0x30]
000073307ffd2ff3  vmovaps xmm4, [rsp+0x40]
000073307ffd2ff9  vmovaps xmm5, [rsp+0x50]
000073307ffd2fff  vmovaps xmm6, [rsp+0x60]
000073307ffd3005  vmovaps xmm7, [rsp+0x70]
000073307ffd300b  vmovaps xmm8, [rsp+0x80]
000073307ffd3014  vmovaps xmm9, [rsp+0x90]
000073307ffd301d  vmovaps xmm10, [rsp+0xA0]
000073307ffd3026  vmovaps xmm11, [rsp+0xB0]
000073307ffd302f  vmovaps xmm12, [rsp+0xC0]
000073307ffd3038  vmovaps xmm13, [rsp+0xD0]
000073307ffd3041  vmovaps xmm14, [rsp+0xE0]
000073307ffd304a  add rsp, 0xF0
000073307ffd3051  pop r11
000073307ffd3053  pop r10
000073307ffd3055  pop r9
000073307ffd3057  pop r8
000073307ffd3059  pop rsi
000073307ffd305a  pop rdi
000073307ffd305b  pop rdx
000073307ffd305c  pop rcx
000073307ffd305d  pop rax
000073307ffd305e  add rsp, 0x08
000073307ffd3062  jmp 0x000073307FFCFE57
000073307ffd3067  sub rsp, 0x08
000073307ffd306b  push rax
000073307ffd306c  push rcx
000073307ffd306d  push rdx
000073307ffd306e  push rdi
000073307ffd306f  push rsi
000073307ffd3070  push r8
000073307ffd3072  push r9
000073307ffd3074  push r10
000073307ffd3076  push r11
000073307ffd3078  sub rsp, 0xF0
000073307ffd307f  vmovaps [rsp], xmm0
000073307ffd3084  vmovaps [rsp+0x10], xmm1
000073307ffd308a  vmovaps [rsp+0x20], xmm2
000073307ffd3090  vmovaps [rsp+0x30], xmm3
000073307ffd3096  vmovaps [rsp+0x40], xmm4
000073307ffd309c  vmovaps [rsp+0x50], xmm5
000073307ffd30a2  vmovaps [rsp+0x60], xmm6
000073307ffd30a8  vmovaps [rsp+0x70], xmm7
000073307ffd30ae  vmovaps [rsp+0x80], xmm8
000073307ffd30b7  vmovaps [rsp+0x90], xmm9
000073307ffd30c0  vmovaps [rsp+0xA0], xmm11
000073307ffd30c9  vmovaps [rsp+0xB0], xmm12
000073307ffd30d2  vmovaps [rsp+0xC0], xmm13
000073307ffd30db  vmovaps [rsp+0xD0], xmm14
000073307ffd30e4  vmovaps [rsp+0xE0], xmm15
000073307ffd30ed  sub rsp, 0x30
000073307ffd30f1  movaps [rsp], xmm10
000073307ffd30f6  movaps [rsp+0x10], xmm12
000073307ffd30fc  movaps [rsp+0x20], xmm11
000073307ffd3102  lea rdi, [rsp]
000073307ffd3106  mov esi, 0x00
000073307ffd310b  mov rax, 0x600DE0EC8530
000073307ffd3115  call rax
000073307ffd3117  movaps xmm10, [rsp]
000073307ffd311c  add rsp, 0x30
000073307ffd3120  vmovaps xmm0, [rsp]
000073307ffd3125  vmovaps xmm1, [rsp+0x10]
000073307ffd312b  vmovaps xmm2, [rsp+0x20]
000073307ffd3131  vmovaps xmm3, [rsp+0x30]
000073307ffd3137  vmovaps xmm4, [rsp+0x40]
000073307ffd313d  vmovaps xmm5, [rsp+0x50]
000073307ffd3143  vmovaps xmm6, [rsp+0x60]
000073307ffd3149  vmovaps xmm7, [rsp+0x70]
000073307ffd314f  vmovaps xmm8, [rsp+0x80]
000073307ffd3158  vmovaps xmm9, [rsp+0x90]
000073307ffd3161  vmovaps xmm11, [rsp+0xA0]
000073307ffd316a  vmovaps xmm12, [rsp+0xB0]
000073307ffd3173  vmovaps xmm13, [rsp+0xC0]
000073307ffd317c  vmovaps xmm14, [rsp+0xD0]
000073307ffd3185  vmovaps xmm15, [rsp+0xE0]
000073307ffd318e  add rsp, 0xF0
000073307ffd3195  pop r11
000073307ffd3197  pop r10
000073307ffd3199  pop r9
000073307ffd319b  pop r8
000073307ffd319d  pop rsi
000073307ffd319e  pop rdi
000073307ffd319f  pop rdx
000073307ffd31a0  pop rcx
000073307ffd31a1  pop rax
000073307ffd31a2  add rsp, 0x08
000073307ffd31a6  jmp 0x000073307FFCFE80
000073307ffd31ab  sub rsp, 0x08
000073307ffd31af  push rax
000073307ffd31b0  push rcx
000073307ffd31b1  push rdx
000073307ffd31b2  push rdi
000073307ffd31b3  push rsi
000073307ffd31b4  push r8
000073307ffd31b6  push r9
000073307ffd31b8  push r10
000073307ffd31ba  push r11
000073307ffd31bc  sub rsp, 0xF0
000073307ffd31c3  vmovaps [rsp], xmm0
000073307ffd31c8  vmovaps [rsp+0x10], xmm1
000073307ffd31ce  vmovaps [rsp+0x20], xmm2
000073307ffd31d4  vmovaps [rsp+0x30], xmm3
000073307ffd31da  vmovaps [rsp+0x40], xmm4
000073307ffd31e0  vmovaps [rsp+0x50], xmm5
000073307ffd31e6  vmovaps [rsp+0x60], xmm6
000073307ffd31ec  vmovaps [rsp+0x70], xmm7
000073307ffd31f2  vmovaps [rsp+0x80], xmm8
000073307ffd31fb  vmovaps [rsp+0x90], xmm9
000073307ffd3204  vmovaps [rsp+0xA0], xmm10
000073307ffd320d  vmovaps [rsp+0xB0], xmm12
000073307ffd3216  vmovaps [rsp+0xC0], xmm13
000073307ffd321f  vmovaps [rsp+0xD0], xmm14
000073307ffd3228  vmovaps [rsp+0xE0], xmm15
000073307ffd3231  sub rsp, 0x30
000073307ffd3235  movaps [rsp], xmm11
000073307ffd323a  movaps [rsp+0x10], xmm2
000073307ffd323f  movaps [rsp+0x20], xmm12
000073307ffd3245  lea rdi, [rsp]
000073307ffd3249  mov esi, 0x00
000073307ffd324e  mov rax, 0x600DE0EC8530
000073307ffd3258  call rax
000073307ffd325a  movaps xmm11, [rsp]
000073307ffd325f  add rsp, 0x30
000073307ffd3263  vmovaps xmm0, [rsp]
000073307ffd3268  vmovaps xmm1, [rsp+0x10]
000073307ffd326e  vmovaps xmm2, [rsp+0x20]
000073307ffd3274  vmovaps xmm3, [rsp+0x30]
000073307ffd327a  vmovaps xmm4, [rsp+0x40]
000073307ffd3280  vmovaps xmm5, [rsp+0x50]
000073307ffd3286  vmovaps xmm6, [rsp+0x60]
000073307ffd328c  vmovaps xmm7, [rsp+0x70]
000073307ffd3292  vmovaps xmm8, [rsp+0x80]
000073307ffd329b  vmovaps xmm9, [rsp+0x90]
000073307ffd32a4  vmovaps xmm10, [rsp+0xA0]
000073307ffd32ad  vmovaps xmm12, [rsp+0xB0]
000073307ffd32b6  vmovaps xmm13, [rsp+0xC0]
000073307ffd32bf  vmovaps xmm14, [rsp+0xD0]
000073307ffd32c8  vmovaps xmm15, [rsp+0xE0]
000073307ffd32d1  add rsp, 0xF0
000073307ffd32d8  pop r11
000073307ffd32da  pop r10
000073307ffd32dc  pop r9
000073307ffd32de  pop r8
000073307ffd32e0  pop rsi
000073307ffd32e1  pop rdi
000073307ffd32e2  pop rdx
000073307ffd32e3  pop rcx
000073307ffd32e4  pop rax
000073307ffd32e5  add rsp, 0x08
000073307ffd32e9  jmp 0x000073307FFCFEB8
000073307ffd32ee  sub rsp, 0x08
000073307ffd32f2  push rax
000073307ffd32f3  push rcx
000073307ffd32f4  push rdx
000073307ffd32f5  push rdi
000073307ffd32f6  push rsi
000073307ffd32f7  push r8
000073307ffd32f9  push r9
000073307ffd32fb  push r10
000073307ffd32fd  push r11
000073307ffd32ff  sub rsp, 0xF0
000073307ffd3306  vmovaps [rsp], xmm0
000073307ffd330b  vmovaps [rsp+0x10], xmm2
000073307ffd3311  vmovaps [rsp+0x20], xmm3
000073307ffd3317  vmovaps [rsp+0x30], xmm4
000073307ffd331d  vmovaps [rsp+0x40], xmm5
000073307ffd3323  vmovaps [rsp+0x50], xmm6
000073307ffd3329  vmovaps [rsp+0x60], xmm7
000073307ffd332f  vmovaps [rsp+0x70], xmm8
000073307ffd3335  vmovaps [rsp+0x80], xmm9
000073307ffd333e  vmovaps [rsp+0x90], xmm10
000073307ffd3347  vmovaps [rsp+0xA0], xmm11
000073307ffd3350  vmovaps [rsp+0xB0], xmm12
000073307ffd3359  vmovaps [rsp+0xC0], xmm13
000073307ffd3362  vmovaps [rsp+0xD0], xmm14
000073307ffd336b  vmovaps [rsp+0xE0], xmm15
000073307ffd3374  sub rsp, 0x30
000073307ffd3378  movaps [rsp], xmm1
000073307ffd337c  movaps [rsp+0x10], xmm14
000073307ffd3382  movaps [rsp+0x20], xmm6
000073307ffd3387  lea rdi, [rsp]
000073307ffd338b  mov esi, 0x00
000073307ffd3390  mov rax, 0x600DE0EC8530
000073307ffd339a  call rax
000073307ffd339c  movaps xmm1, [rsp]
000073307ffd33a0  add rsp, 0x30
000073307ffd33a4  vmovaps xmm0, [rsp]
000073307ffd33a9  vmovaps xmm2, [rsp+0x10]
000073307ffd33af  vmovaps xmm3, [rsp+0x20]
000073307ffd33b5  vmovaps xmm4, [rsp+0x30]
000073307ffd33bb  vmovaps xmm5, [rsp+0x40]
000073307ffd33c1  vmovaps xmm6, [rsp+0x50]
000073307ffd33c7  vmovaps xmm7, [rsp+0x60]
000073307ffd33cd  vmovaps xmm8, [rsp+0x70]
000073307ffd33d3  vmovaps xmm9, [rsp+0x80]
000073307ffd33dc  vmovaps xmm10, [rsp+0x90]
000073307ffd33e5  vmovaps xmm11, [rsp+0xA0]
000073307ffd33ee  vmovaps xmm12, [rsp+0xB0]
000073307ffd33f7  vmovaps xmm13, [rsp+0xC0]
000073307ffd3400  vmovaps xmm14, [rsp+0xD0]
000073307ffd3409  vmovaps xmm15, [rsp+0xE0]
000073307ffd3412  add rsp, 0xF0
000073307ffd3419  pop r11
000073307ffd341b  pop r10
000073307ffd341d  pop r9
000073307ffd341f  pop r8
000073307ffd3421  pop rsi
000073307ffd3422  pop rdi
000073307ffd3423  pop rdx
000073307ffd3424  pop rcx
000073307ffd3425  pop rax
000073307ffd3426  add rsp, 0x08
000073307ffd342a  jmp 0x000073307FFCFED1
000073307ffd342f  sub rsp, 0x08
000073307ffd3433  push rax
000073307ffd3434  push rcx
000073307ffd3435  push rdx
000073307ffd3436  push rdi
000073307ffd3437  push rsi
000073307ffd3438  push r8
000073307ffd343a  push r9
000073307ffd343c  push r10
000073307ffd343e  push r11
000073307ffd3440  sub rsp, 0xF0
000073307ffd3447  vmovaps [rsp], xmm0
000073307ffd344c  vmovaps [rsp+0x10], xmm1
000073307ffd3452  vmovaps [rsp+0x20], xmm2
000073307ffd3458  vmovaps [rsp+0x30], xmm3
000073307ffd345e  vmovaps [rsp+0x40], xmm4
000073307ffd3464  vmovaps [rsp+0x50], xmm5
000073307ffd346a  vmovaps [rsp+0x60], xmm6
000073307ffd3470  vmovaps [rsp+0x70], xmm7
000073307ffd3476  vmovaps [rsp+0x80], xmm8
000073307ffd347f  vmovaps [rsp+0x90], xmm9
000073307ffd3488  vmovaps [rsp+0xA0], xmm10
000073307ffd3491  vmovaps [rsp+0xB0], xmm11
000073307ffd349a  vmovaps [rsp+0xC0], xmm12
000073307ffd34a3  vmovaps [rsp+0xD0], xmm13
000073307ffd34ac  vmovaps [rsp+0xE0], xmm15
000073307ffd34b5  sub rsp, 0x30
000073307ffd34b9  movaps [rsp], xmm14
000073307ffd34be  movaps [rsp+0x10], xmm12
000073307ffd34c4  movaps [rsp+0x20], xmm5
000073307ffd34c9  lea rdi, [rsp]
000073307ffd34cd  mov esi, 0x00
000073307ffd34d2  mov rax, 0x600DE0EC8530
000073307ffd34dc  call rax
000073307ffd34de  movaps xmm14, [rsp]
000073307ffd34e3  add rsp, 0x30
000073307ffd34e7  vmovaps xmm0, [rsp]
000073307ffd34ec  vmovaps xmm1, [rsp+0x10]
000073307ffd34f2  vmovaps xmm2, [rsp+0x20]
000073307ffd34f8  vmovaps xmm3, [rsp+0x30]
000073307ffd34fe  vmovaps xmm4, [rsp+0x40]
000073307ffd3504  vmovaps xmm5, [rsp+0x50]
000073307ffd350a  vmovaps xmm6, [rsp+0x60]
000073307ffd3510  vmovaps xmm7, [rsp+0x70]
000073307ffd3516  vmovaps xmm8, [rsp+0x80]
000073307ffd351f  vmovaps xmm9, [rsp+0x90]
000073307ffd3528  vmovaps xmm10, [rsp+0xA0]
000073307ffd3531  vmovaps xmm11, [rsp+0xB0]
000073307ffd353a  vmovaps xmm12, [rsp+0xC0]
000073307ffd3543  vmovaps xmm13, [rsp+0xD0]
000073307ffd354c  vmovaps xmm15, [rsp+0xE0]
000073307ffd3555  add rsp, 0xF0
000073307ffd355c  pop r11
000073307ffd355e  pop r10
000073307ffd3560  pop r9
000073307ffd3562  pop r8
000073307ffd3564  pop rsi
000073307ffd3565  pop rdi
000073307ffd3566  pop rdx
000073307ffd3567  pop rcx
000073307ffd3568  pop rax
000073307ffd3569  add rsp, 0x08
000073307ffd356d  jmp 0x000073307FFCFEF1
000073307ffd3572  sub rsp, 0x08
000073307ffd3576  push rax
000073307ffd3577  push rcx
000073307ffd3578  push rdx
000073307ffd3579  push rdi
000073307ffd357a  push rsi
000073307ffd357b  push r8
000073307ffd357d  push r9
000073307ffd357f  push r10
000073307ffd3581  push r11
000073307ffd3583  sub rsp, 0xF0
000073307ffd358a  vmovaps [rsp], xmm0
000073307ffd358f  vmovaps [rsp+0x10], xmm1
000073307ffd3595  vmovaps [rsp+0x20], xmm2
000073307ffd359b  vmovaps [rsp+0x30], xmm3
000073307ffd35a1  vmovaps [rsp+0x40], xmm4
000073307ffd35a7  vmovaps [rsp+0x50], xmm5
000073307ffd35ad  vmovaps [rsp+0x60], xmm7
000073307ffd35b3  vmovaps [rsp+0x70], xmm8
000073307ffd35b9  vmovaps [rsp+0x80], xmm9
000073307ffd35c2  vmovaps [rsp+0x90], xmm10
000073307ffd35cb  vmovaps [rsp+0xA0], xmm11
000073307ffd35d4  vmovaps [rsp+0xB0], xmm12
000073307ffd35dd  vmovaps [rsp+0xC0], xmm13
000073307ffd35e6  vmovaps [rsp+0xD0], xmm14
000073307ffd35ef  vmovaps [rsp+0xE0], xmm15
000073307ffd35f8  sub rsp, 0x30
000073307ffd35fc  movaps [rsp], xmm6
000073307ffd3600  movaps [rsp+0x10], xmm9
000073307ffd3606  movaps [rsp+0x20], xmm12
000073307ffd360c  lea rdi, [rsp]
000073307ffd3610  mov esi, 0x00
000073307ffd3615  mov rax, 0x600DE0EC8530
000073307ffd361f  call rax
000073307ffd3621  movaps xmm6, [rsp]
000073307ffd3625  add rsp, 0x30
000073307ffd3629  vmovaps xmm0, [rsp]
000073307ffd362e  vmovaps xmm1, [rsp+0x10]
000073307ffd3634  vmovaps xmm2, [rsp+0x20]
000073307ffd363a  vmovaps xmm3, [rsp+0x30]
000073307ffd3640  vmovaps xmm4, [rsp+0x40]
000073307ffd3646  vmovaps xmm5, [rsp+0x50]
000073307ffd364c  vmovaps xmm7, [rsp+0x60]
000073307ffd3652  vmovaps xmm8, [rsp+0x70]
000073307ffd3658  vmovaps xmm9, [rsp+0x80]
000073307ffd3661  vmovaps xmm10, [rsp+0x90]
000073307ffd366a  vmovaps xmm11, [rsp+0xA0]
000073307ffd3673  vmovaps xmm12, [rsp+0xB0]
000073307ffd367c  vmovaps xmm13, [rsp+0xC0]
000073307ffd3685  vmovaps xmm14, [rsp+0xD0]
000073307ffd368e  vmovaps xmm15, [rsp+0xE0]
000073307ffd3697  add rsp, 0xF0
000073307ffd369e  pop r11
000073307ffd36a0  pop r10
000073307ffd36a2  pop r9
000073307ffd36a4  pop r8
000073307ffd36a6  pop rsi
000073307ffd36a7  pop rdi
000073307ffd36a8  pop rdx
000073307ffd36a9  pop rcx
000073307ffd36aa  pop rax
000073307ffd36ab  add rsp, 0x08
000073307ffd36af  jmp 0x000073307FFCFF19
000073307ffd36b4  sub rsp, 0x08
000073307ffd36b8  push rax
000073307ffd36b9  push rcx
000073307ffd36ba  push rdx
000073307ffd36bb  push rdi
000073307ffd36bc  push rsi
000073307ffd36bd  push r8
000073307ffd36bf  push r9
000073307ffd36c1  push r10
000073307ffd36c3  push r11
000073307ffd36c5  sub rsp, 0xF0
000073307ffd36cc  vmovaps [rsp], xmm0
000073307ffd36d1  vmovaps [rsp+0x10], xmm1
000073307ffd36d7  vmovaps [rsp+0x20], xmm2
000073307ffd36dd  vmovaps [rsp+0x30], xmm3
000073307ffd36e3  vmovaps [rsp+0x40], xmm4
000073307ffd36e9  vmovaps [rsp+0x50], xmm5
000073307ffd36ef  vmovaps [rsp+0x60], xmm6
000073307ffd36f5  vmovaps [rsp+0x70], xmm7
000073307ffd36fb  vmovaps [rsp+0x80], xmm8
000073307ffd3704  vmovaps [rsp+0x90], xmm9
000073307ffd370d  vmovaps [rsp+0xA0], xmm10
000073307ffd3716  vmovaps [rsp+0xB0], xmm11
000073307ffd371f  vmovaps [rsp+0xC0], xmm13
000073307ffd3728  vmovaps [rsp+0xD0], xmm14
000073307ffd3731  vmovaps [rsp+0xE0], xmm15
000073307ffd373a  sub rsp, 0x30
000073307ffd373e  movaps [rsp], xmm12
000073307ffd3743  movaps [rsp+0x10], xmm15
000073307ffd3749  movaps [rsp+0x20], xmm13
000073307ffd374f  lea rdi, [rsp]
000073307ffd3753  mov esi, 0x00
000073307ffd3758  mov rax, 0x600DE0EC8530
000073307ffd3762  call rax
000073307ffd3764  movaps xmm12, [rsp]
000073307ffd3769  add rsp, 0x30
000073307ffd376d  vmovaps xmm0, [rsp]
000073307ffd3772  vmovaps xmm1, [rsp+0x10]
000073307ffd3778  vmovaps xmm2, [rsp+0x20]
000073307ffd377e  vmovaps xmm3, [rsp+0x30]
000073307ffd3784  vmovaps xmm4, [rsp+0x40]
000073307ffd378a  vmovaps xmm5, [rsp+0x50]
000073307ffd3790  vmovaps xmm6, [rsp+0x60]
000073307ffd3796  vmovaps xmm7, [rsp+0x70]
000073307ffd379c  vmovaps xmm8, [rsp+0x80]
000073307ffd37a5  vmovaps xmm9, [rsp+0x90]
000073307ffd37ae  vmovaps xmm10, [rsp+0xA0]
000073307ffd37b7  vmovaps xmm11, [rsp+0xB0]
000073307ffd37c0  vmovaps xmm13, [rsp+0xC0]
000073307ffd37c9  vmovaps xmm14, [rsp+0xD0]
000073307ffd37d2  vmovaps xmm15, [rsp+0xE0]
000073307ffd37db  add rsp, 0xF0
000073307ffd37e2  pop r11
000073307ffd37e4  pop r10
000073307ffd37e6  pop r9
000073307ffd37e8  pop r8
000073307ffd37ea  pop rsi
000073307ffd37eb  pop rdi
000073307ffd37ec  pop rdx
000073307ffd37ed  pop rcx
000073307ffd37ee  pop rax
000073307ffd37ef  add rsp, 0x08
000073307ffd37f3  jmp 0x000073307FFCFF34
000073307ffd37f8  sub rsp, 0x08
000073307ffd37fc  push rax
000073307ffd37fd  push rcx
000073307ffd37fe  push rdx
000073307ffd37ff  push rdi
000073307ffd3800  push rsi
000073307ffd3801  push r8
000073307ffd3803  push r9
000073307ffd3805  push r10
000073307ffd3807  push r11
000073307ffd3809  sub rsp, 0xF0
000073307ffd3810  vmovaps [rsp], xmm0
000073307ffd3815  vmovaps [rsp+0x10], xmm1
000073307ffd381b  vmovaps [rsp+0x20], xmm2
000073307ffd3821  vmovaps [rsp+0x30], xmm3
000073307ffd3827  vmovaps [rsp+0x40], xmm4
000073307ffd382d  vmovaps [rsp+0x50], xmm5
000073307ffd3833  vmovaps [rsp+0x60], xmm6
000073307ffd3839  vmovaps [rsp+0x70], xmm7
000073307ffd383f  vmovaps [rsp+0x80], xmm8
000073307ffd3848  vmovaps [rsp+0x90], xmm9
000073307ffd3851  vmovaps [rsp+0xA0], xmm10
000073307ffd385a  vmovaps [rsp+0xB0], xmm11
000073307ffd3863  vmovaps [rsp+0xC0], xmm12
000073307ffd386c  vmovaps [rsp+0xD0], xmm13
000073307ffd3875  vmovaps [rsp+0xE0], xmm14
000073307ffd387e  sub rsp, 0x30
000073307ffd3882  movaps [rsp], xmm15
000073307ffd3887  movaps [rsp+0x10], xmm13
000073307ffd388d  movaps [rsp+0x20], xmm10
000073307ffd3893  lea rdi, [rsp]
000073307ffd3897  mov esi, 0x00
000073307ffd389c  mov rax, 0x600DE0EC8530
000073307ffd38a6  call rax
000073307ffd38a8  movaps xmm15, [rsp]
000073307ffd38ad  add rsp, 0x30
000073307ffd38b1  vmovaps xmm0, [rsp]
000073307ffd38b6  vmovaps xmm1, [rsp+0x10]
000073307ffd38bc  vmovaps xmm2, [rsp+0x20]
000073307ffd38c2  vmovaps xmm3, [rsp+0x30]
000073307ffd38c8  vmovaps xmm4, [rsp+0x40]
000073307ffd38ce  vmovaps xmm5, [rsp+0x50]
000073307ffd38d4  vmovaps xmm6, [rsp+0x60]
000073307ffd38da  vmovaps xmm7, [rsp+0x70]
000073307ffd38e0  vmovaps xmm8, [rsp+0x80]
000073307ffd38e9  vmovaps xmm9, [rsp+0x90]
000073307ffd38f2  vmovaps xmm10, [rsp+0xA0]
000073307ffd38fb  vmovaps xmm11, [rsp+0xB0]
000073307ffd3904  vmovaps xmm12, [rsp+0xC0]
000073307ffd390d  vmovaps xmm13, [rsp+0xD0]
000073307ffd3916  vmovaps xmm14, [rsp+0xE0]
000073307ffd391f  add rsp, 0xF0
000073307ffd3926  pop r11
000073307ffd3928  pop r10
000073307ffd392a  pop r9
000073307ffd392c  pop r8
000073307ffd392e  pop rsi
000073307ffd392f  pop rdi
000073307ffd3930  pop rdx
000073307ffd3931  pop rcx
000073307ffd3932  pop rax
000073307ffd3933  add rsp, 0x08
000073307ffd3937  jmp 0x000073307FFCFF55
000073307ffd393c  call 0x000073307FE0C260
000073307ffd3941  jmp 0x000073307FFCFFB0
000073307ffd3946  sub rsp, 0x08
000073307ffd394a  push rax
000073307ffd394b  push rcx
000073307ffd394c  push rdx
000073307ffd394d  push rdi
000073307ffd394e  push rsi
000073307ffd394f  push r8
000073307ffd3951  push r9
000073307ffd3953  push r10
000073307ffd3955  push r11
000073307ffd3957  sub rsp, 0xF0
000073307ffd395e  vmovaps [rsp], xmm0
000073307ffd3963  vmovaps [rsp+0x10], xmm1
000073307ffd3969  vmovaps [rsp+0x20], xmm2
000073307ffd396f  vmovaps [rsp+0x30], xmm3
000073307ffd3975  vmovaps [rsp+0x40], xmm4
000073307ffd397b  vmovaps [rsp+0x50], xmm5
000073307ffd3981  vmovaps [rsp+0x60], xmm6
000073307ffd3987  vmovaps [rsp+0x70], xmm7
000073307ffd398d  vmovaps [rsp+0x80], xmm8
000073307ffd3996  vmovaps [rsp+0x90], xmm10
000073307ffd399f  vmovaps [rsp+0xA0], xmm11
000073307ffd39a8  vmovaps [rsp+0xB0], xmm12
000073307ffd39b1  vmovaps [rsp+0xC0], xmm13
000073307ffd39ba  vmovaps [rsp+0xD0], xmm14
000073307ffd39c3  vmovaps [rsp+0xE0], xmm15
000073307ffd39cc  sub rsp, 0x30
000073307ffd39d0  movaps [rsp], xmm9
000073307ffd39d5  movaps [rsp+0x10], xmm8
000073307ffd39db  movaps [rsp+0x20], xmm10
000073307ffd39e1  lea rdi, [rsp]
000073307ffd39e5  mov esi, 0x00
000073307ffd39ea  mov rax, 0x600DE0EC8530
000073307ffd39f4  call rax
000073307ffd39f6  movaps xmm9, [rsp]
000073307ffd39fb  add rsp, 0x30
000073307ffd39ff  vmovaps xmm0, [rsp]
000073307ffd3a04  vmovaps xmm1, [rsp+0x10]
000073307ffd3a0a  vmovaps xmm2, [rsp+0x20]
000073307ffd3a10  vmovaps xmm3, [rsp+0x30]
000073307ffd3a16  vmovaps xmm4, [rsp+0x40]
000073307ffd3a1c  vmovaps xmm5, [rsp+0x50]
000073307ffd3a22  vmovaps xmm6, [rsp+0x60]
000073307ffd3a28  vmovaps xmm7, [rsp+0x70]
000073307ffd3a2e  vmovaps xmm8, [rsp+0x80]
000073307ffd3a37  vmovaps xmm10, [rsp+0x90]
000073307ffd3a40  vmovaps xmm11, [rsp+0xA0]
000073307ffd3a49  vmovaps xmm12, [rsp+0xB0]
000073307ffd3a52  vmovaps xmm13, [rsp+0xC0]
000073307ffd3a5b  vmovaps xmm14, [rsp+0xD0]
000073307ffd3a64  vmovaps xmm15, [rsp+0xE0]
000073307ffd3a6d  add rsp, 0xF0
000073307ffd3a74  pop r11
000073307ffd3a76  pop r10
000073307ffd3a78  pop r9
000073307ffd3a7a  pop r8
000073307ffd3a7c  pop rsi
000073307ffd3a7d  pop rdi
000073307ffd3a7e  pop rdx
000073307ffd3a7f  pop rcx
000073307ffd3a80  pop rax
000073307ffd3a81  add rsp, 0x08
000073307ffd3a85  jmp 0x000073307FFCFFE1
000073307ffd3a8a  sub rsp, 0x08
000073307ffd3a8e  push rax
000073307ffd3a8f  push rcx
000073307ffd3a90  push rdx
000073307ffd3a91  push rdi
000073307ffd3a92  push rsi
000073307ffd3a93  push r8
000073307ffd3a95  push r9
000073307ffd3a97  push r10
000073307ffd3a99  push r11
000073307ffd3a9b  sub rsp, 0xF0
000073307ffd3aa2  vmovaps [rsp], xmm0
000073307ffd3aa7  vmovaps [rsp+0x10], xmm1
000073307ffd3aad  vmovaps [rsp+0x20], xmm2
000073307ffd3ab3  vmovaps [rsp+0x30], xmm3
000073307ffd3ab9  vmovaps [rsp+0x40], xmm4
000073307ffd3abf  vmovaps [rsp+0x50], xmm5
000073307ffd3ac5  vmovaps [rsp+0x60], xmm6
000073307ffd3acb  vmovaps [rsp+0x70], xmm7
000073307ffd3ad1  vmovaps [rsp+0x80], xmm8
000073307ffd3ada  vmovaps [rsp+0x90], xmm9
000073307ffd3ae3  vmovaps [rsp+0xA0], xmm11
000073307ffd3aec  vmovaps [rsp+0xB0], xmm12
000073307ffd3af5  vmovaps [rsp+0xC0], xmm13
000073307ffd3afe  vmovaps [rsp+0xD0], xmm14
000073307ffd3b07  vmovaps [rsp+0xE0], xmm15
000073307ffd3b10  sub rsp, 0x30
000073307ffd3b14  movaps [rsp], xmm10
000073307ffd3b19  movaps [rsp+0x10], xmm1
000073307ffd3b1e  movaps [rsp+0x20], xmm11
000073307ffd3b24  lea rdi, [rsp]
000073307ffd3b28  mov esi, 0x00
000073307ffd3b2d  mov rax, 0x600DE0EC8530
000073307ffd3b37  call rax
000073307ffd3b39  movaps xmm10, [rsp]
000073307ffd3b3e  add rsp, 0x30
000073307ffd3b42  vmovaps xmm0, [rsp]
000073307ffd3b47  vmovaps xmm1, [rsp+0x10]
000073307ffd3b4d  vmovaps xmm2, [rsp+0x20]
000073307ffd3b53  vmovaps xmm3, [rsp+0x30]
000073307ffd3b59  vmovaps xmm4, [rsp+0x40]
000073307ffd3b5f  vmovaps xmm5, [rsp+0x50]
000073307ffd3b65  vmovaps xmm6, [rsp+0x60]
000073307ffd3b6b  vmovaps xmm7, [rsp+0x70]
000073307ffd3b71  vmovaps xmm8, [rsp+0x80]
000073307ffd3b7a  vmovaps xmm9, [rsp+0x90]
000073307ffd3b83  vmovaps xmm11, [rsp+0xA0]
000073307ffd3b8c  vmovaps xmm12, [rsp+0xB0]
000073307ffd3b95  vmovaps xmm13, [rsp+0xC0]
000073307ffd3b9e  vmovaps xmm14, [rsp+0xD0]
000073307ffd3ba7  vmovaps xmm15, [rsp+0xE0]
000073307ffd3bb0  add rsp, 0xF0
000073307ffd3bb7  pop r11
000073307ffd3bb9  pop r10
000073307ffd3bbb  pop r9
000073307ffd3bbd  pop r8
000073307ffd3bbf  pop rsi
000073307ffd3bc0  pop rdi
000073307ffd3bc1  pop rdx
000073307ffd3bc2  pop rcx
000073307ffd3bc3  pop rax
000073307ffd3bc4  add rsp, 0x08
000073307ffd3bc8  jmp 0x000073307FFCFFFC
000073307ffd3bcd  sub rsp, 0x08
000073307ffd3bd1  push rax
000073307ffd3bd2  push rcx
000073307ffd3bd3  push rdx
000073307ffd3bd4  push rdi
000073307ffd3bd5  push rsi
000073307ffd3bd6  push r8
000073307ffd3bd8  push r9
000073307ffd3bda  push r10
000073307ffd3bdc  push r11
000073307ffd3bde  sub rsp, 0xF0
000073307ffd3be5  vmovaps [rsp], xmm0
000073307ffd3bea  vmovaps [rsp+0x10], xmm2
000073307ffd3bf0  vmovaps [rsp+0x20], xmm3
000073307ffd3bf6  vmovaps [rsp+0x30], xmm4
000073307ffd3bfc  vmovaps [rsp+0x40], xmm5
000073307ffd3c02  vmovaps [rsp+0x50], xmm6
000073307ffd3c08  vmovaps [rsp+0x60], xmm7
000073307ffd3c0e  vmovaps [rsp+0x70], xmm8
000073307ffd3c14  vmovaps [rsp+0x80], xmm9
000073307ffd3c1d  vmovaps [rsp+0x90], xmm10
000073307ffd3c26  vmovaps [rsp+0xA0], xmm11
000073307ffd3c2f  vmovaps [rsp+0xB0], xmm12
000073307ffd3c38  vmovaps [rsp+0xC0], xmm13
000073307ffd3c41  vmovaps [rsp+0xD0], xmm14
000073307ffd3c4a  vmovaps [rsp+0xE0], xmm15
000073307ffd3c53  sub rsp, 0x30
000073307ffd3c57  movaps [rsp], xmm1
000073307ffd3c5b  movaps [rsp+0x10], xmm14
000073307ffd3c61  movaps [rsp+0x20], xmm6
000073307ffd3c66  lea rdi, [rsp]
000073307ffd3c6a  mov esi, 0x00
000073307ffd3c6f  mov rax, 0x600DE0EC8530
000073307ffd3c79  call rax
000073307ffd3c7b  movaps xmm1, [rsp]
000073307ffd3c7f  add rsp, 0x30
000073307ffd3c83  vmovaps xmm0, [rsp]
000073307ffd3c88  vmovaps xmm2, [rsp+0x10]
000073307ffd3c8e  vmovaps xmm3, [rsp+0x20]
000073307ffd3c94  vmovaps xmm4, [rsp+0x30]
000073307ffd3c9a  vmovaps xmm5, [rsp+0x40]
000073307ffd3ca0  vmovaps xmm6, [rsp+0x50]
000073307ffd3ca6  vmovaps xmm7, [rsp+0x60]
000073307ffd3cac  vmovaps xmm8, [rsp+0x70]
000073307ffd3cb2  vmovaps xmm9, [rsp+0x80]
000073307ffd3cbb  vmovaps xmm10, [rsp+0x90]
000073307ffd3cc4  vmovaps xmm11, [rsp+0xA0]
000073307ffd3ccd  vmovaps xmm12, [rsp+0xB0]
000073307ffd3cd6  vmovaps xmm13, [rsp+0xC0]
000073307ffd3cdf  vmovaps xmm14, [rsp+0xD0]
000073307ffd3ce8  vmovaps xmm15, [rsp+0xE0]
000073307ffd3cf1  add rsp, 0xF0
000073307ffd3cf8  pop r11
000073307ffd3cfa  pop r10
000073307ffd3cfc  pop r9
000073307ffd3cfe  pop r8
000073307ffd3d00  pop rsi
000073307ffd3d01  pop rdi
000073307ffd3d02  pop rdx
000073307ffd3d03  pop rcx
000073307ffd3d04  pop rax
000073307ffd3d05  add rsp, 0x08
000073307ffd3d09  jmp 0x000073307FFD0015
000073307ffd3d0e  sub rsp, 0x08
000073307ffd3d12  push rax
000073307ffd3d13  push rcx
000073307ffd3d14  push rdx
000073307ffd3d15  push rdi
000073307ffd3d16  push rsi
000073307ffd3d17  push r8
000073307ffd3d19  push r9
000073307ffd3d1b  push r10
000073307ffd3d1d  push r11
000073307ffd3d1f  sub rsp, 0xF0
000073307ffd3d26  vmovaps [rsp], xmm0
000073307ffd3d2b  vmovaps [rsp+0x10], xmm1
000073307ffd3d31  vmovaps [rsp+0x20], xmm2
000073307ffd3d37  vmovaps [rsp+0x30], xmm3
000073307ffd3d3d  vmovaps [rsp+0x40], xmm4
000073307ffd3d43  vmovaps [rsp+0x50], xmm5
000073307ffd3d49  vmovaps [rsp+0x60], xmm6
000073307ffd3d4f  vmovaps [rsp+0x70], xmm7
000073307ffd3d55  vmovaps [rsp+0x80], xmm8
000073307ffd3d5e  vmovaps [rsp+0x90], xmm9
000073307ffd3d67  vmovaps [rsp+0xA0], xmm10
000073307ffd3d70  vmovaps [rsp+0xB0], xmm12
000073307ffd3d79  vmovaps [rsp+0xC0], xmm13
000073307ffd3d82  vmovaps [rsp+0xD0], xmm14
000073307ffd3d8b  vmovaps [rsp+0xE0], xmm15
000073307ffd3d94  sub rsp, 0x30
000073307ffd3d98  movaps [rsp], xmm11
000073307ffd3d9d  movaps [rsp+0x10], xmm13
000073307ffd3da3  movaps [rsp+0x20], xmm14
000073307ffd3da9  lea rdi, [rsp]
000073307ffd3dad  mov esi, 0x00
000073307ffd3db2  mov rax, 0x600DE0EC8530
000073307ffd3dbc  call rax
000073307ffd3dbe  movaps xmm11, [rsp]
000073307ffd3dc3  add rsp, 0x30
000073307ffd3dc7  vmovaps xmm0, [rsp]
000073307ffd3dcc  vmovaps xmm1, [rsp+0x10]
000073307ffd3dd2  vmovaps xmm2, [rsp+0x20]
000073307ffd3dd8  vmovaps xmm3, [rsp+0x30]
000073307ffd3dde  vmovaps xmm4, [rsp+0x40]
000073307ffd3de4  vmovaps xmm5, [rsp+0x50]
000073307ffd3dea  vmovaps xmm6, [rsp+0x60]
000073307ffd3df0  vmovaps xmm7, [rsp+0x70]
000073307ffd3df6  vmovaps xmm8, [rsp+0x80]
000073307ffd3dff  vmovaps xmm9, [rsp+0x90]
000073307ffd3e08  vmovaps xmm10, [rsp+0xA0]
000073307ffd3e11  vmovaps xmm12, [rsp+0xB0]
000073307ffd3e1a  vmovaps xmm13, [rsp+0xC0]
000073307ffd3e23  vmovaps xmm14, [rsp+0xD0]
000073307ffd3e2c  vmovaps xmm15, [rsp+0xE0]
000073307ffd3e35  add rsp, 0xF0
000073307ffd3e3c  pop r11
000073307ffd3e3e  pop r10
000073307ffd3e40  pop r9
000073307ffd3e42  pop r8
000073307ffd3e44  pop rsi
000073307ffd3e45  pop rdi
000073307ffd3e46  pop rdx
000073307ffd3e47  pop rcx
000073307ffd3e48  pop rax
000073307ffd3e49  add rsp, 0x08
000073307ffd3e4d  jmp 0x000073307FFD003F
000073307ffd3e52  sub rsp, 0x08
000073307ffd3e56  push rax
000073307ffd3e57  push rcx
000073307ffd3e58  push rdx
000073307ffd3e59  push rdi
000073307ffd3e5a  push rsi
000073307ffd3e5b  push r8
000073307ffd3e5d  push r9
000073307ffd3e5f  push r10
000073307ffd3e61  push r11
000073307ffd3e63  sub rsp, 0xF0
000073307ffd3e6a  vmovaps [rsp], xmm0
000073307ffd3e6f  vmovaps [rsp+0x10], xmm1
000073307ffd3e75  vmovaps [rsp+0x20], xmm2
000073307ffd3e7b  vmovaps [rsp+0x30], xmm3
000073307ffd3e81  vmovaps [rsp+0x40], xmm4
000073307ffd3e87  vmovaps [rsp+0x50], xmm5
000073307ffd3e8d  vmovaps [rsp+0x60], xmm6
000073307ffd3e93  vmovaps [rsp+0x70], xmm7
000073307ffd3e99  vmovaps [rsp+0x80], xmm8
000073307ffd3ea2  vmovaps [rsp+0x90], xmm9
000073307ffd3eab  vmovaps [rsp+0xA0], xmm10
000073307ffd3eb4  vmovaps [rsp+0xB0], xmm11
000073307ffd3ebd  vmovaps [rsp+0xC0], xmm12
000073307ffd3ec6  vmovaps [rsp+0xD0], xmm14
000073307ffd3ecf  vmovaps [rsp+0xE0], xmm15
000073307ffd3ed8  sub rsp, 0x30
000073307ffd3edc  movaps [rsp], xmm13
000073307ffd3ee1  movaps [rsp+0x10], xmm8
000073307ffd3ee7  movaps [rsp+0x20], xmm14
000073307ffd3eed  lea rdi, [rsp]
000073307ffd3ef1  mov esi, 0x00
000073307ffd3ef6  mov rax, 0x600DE0EC8530
000073307ffd3f00  call rax
000073307ffd3f02  movaps xmm13, [rsp]
000073307ffd3f07  add rsp, 0x30
000073307ffd3f0b  vmovaps xmm0, [rsp]
000073307ffd3f10  vmovaps xmm1, [rsp+0x10]
000073307ffd3f16  vmovaps xmm2, [rsp+0x20]
000073307ffd3f1c  vmovaps xmm3, [rsp+0x30]
000073307ffd3f22  vmovaps xmm4, [rsp+0x40]
000073307ffd3f28  vmovaps xmm5, [rsp+0x50]
000073307ffd3f2e  vmovaps xmm6, [rsp+0x60]
000073307ffd3f34  vmovaps xmm7, [rsp+0x70]
000073307ffd3f3a  vmovaps xmm8, [rsp+0x80]
000073307ffd3f43  vmovaps xmm9, [rsp+0x90]
000073307ffd3f4c  vmovaps xmm10, [rsp+0xA0]
000073307ffd3f55  vmovaps xmm11, [rsp+0xB0]
000073307ffd3f5e  vmovaps xmm12, [rsp+0xC0]
000073307ffd3f67  vmovaps xmm14, [rsp+0xD0]
000073307ffd3f70  vmovaps xmm15, [rsp+0xE0]
000073307ffd3f79  add rsp, 0xF0
000073307ffd3f80  pop r11
000073307ffd3f82  pop r10
000073307ffd3f84  pop r9
000073307ffd3f86  pop r8
000073307ffd3f88  pop rsi
000073307ffd3f89  pop rdi
000073307ffd3f8a  pop rdx
000073307ffd3f8b  pop rcx
000073307ffd3f8c  pop rax
000073307ffd3f8d  add rsp, 0x08
000073307ffd3f91  jmp 0x000073307FFD006E
000073307ffd3f96  sub rsp, 0x08
000073307ffd3f9a  push rax
000073307ffd3f9b  push rcx
000073307ffd3f9c  push rdx
000073307ffd3f9d  push rdi
000073307ffd3f9e  push rsi
000073307ffd3f9f  push r8
000073307ffd3fa1  push r9
000073307ffd3fa3  push r10
000073307ffd3fa5  push r11
000073307ffd3fa7  sub rsp, 0xF0
000073307ffd3fae  vmovaps [rsp], xmm0
000073307ffd3fb3  vmovaps [rsp+0x10], xmm1
000073307ffd3fb9  vmovaps [rsp+0x20], xmm2
000073307ffd3fbf  vmovaps [rsp+0x30], xmm3
000073307ffd3fc5  vmovaps [rsp+0x40], xmm4
000073307ffd3fcb  vmovaps [rsp+0x50], xmm5
000073307ffd3fd1  vmovaps [rsp+0x60], xmm6
000073307ffd3fd7  vmovaps [rsp+0x70], xmm7
000073307ffd3fdd  vmovaps [rsp+0x80], xmm9
000073307ffd3fe6  vmovaps [rsp+0x90], xmm10
000073307ffd3fef  vmovaps [rsp+0xA0], xmm11
000073307ffd3ff8  vmovaps [rsp+0xB0], xmm12
000073307ffd4001  vmovaps [rsp+0xC0], xmm13
000073307ffd400a  vmovaps [rsp+0xD0], xmm14
000073307ffd4013  vmovaps [rsp+0xE0], xmm15
000073307ffd401c  sub rsp, 0x30
000073307ffd4020  movaps [rsp], xmm8
000073307ffd4025  movaps [rsp+0x10], xmm7
000073307ffd402a  movaps [rsp+0x20], xmm14
000073307ffd4030  lea rdi, [rsp]
000073307ffd4034  mov esi, 0x00
000073307ffd4039  mov rax, 0x600DE0EC8530
000073307ffd4043  call rax
000073307ffd4045  movaps xmm8, [rsp]
000073307ffd404a  add rsp, 0x30
000073307ffd404e  vmovaps xmm0, [rsp]
000073307ffd4053  vmovaps xmm1, [rsp+0x10]
000073307ffd4059  vmovaps xmm2, [rsp+0x20]
000073307ffd405f  vmovaps xmm3, [rsp+0x30]
000073307ffd4065  vmovaps xmm4, [rsp+0x40]
000073307ffd406b  vmovaps xmm5, [rsp+0x50]
000073307ffd4071  vmovaps xmm6, [rsp+0x60]
000073307ffd4077  vmovaps xmm7, [rsp+0x70]
000073307ffd407d  vmovaps xmm9, [rsp+0x80]
000073307ffd4086  vmovaps xmm10, [rsp+0x90]
000073307ffd408f  vmovaps xmm11, [rsp+0xA0]
000073307ffd4098  vmovaps xmm12, [rsp+0xB0]
000073307ffd40a1  vmovaps xmm13, [rsp+0xC0]
000073307ffd40aa  vmovaps xmm14, [rsp+0xD0]
000073307ffd40b3  vmovaps xmm15, [rsp+0xE0]
000073307ffd40bc  add rsp, 0xF0
000073307ffd40c3  pop r11
000073307ffd40c5  pop r10
000073307ffd40c7  pop r9
000073307ffd40c9  pop r8
000073307ffd40cb  pop rsi
000073307ffd40cc  pop rdi
000073307ffd40cd  pop rdx
000073307ffd40ce  pop rcx
000073307ffd40cf  pop rax
000073307ffd40d0  add rsp, 0x08
000073307ffd40d4  jmp 0x000073307FFD0094
000073307ffd40d9  sub rsp, 0x08
000073307ffd40dd  push rax
000073307ffd40de  push rcx
000073307ffd40df  push rdx
000073307ffd40e0  push rdi
000073307ffd40e1  push rsi
000073307ffd40e2  push r8
000073307ffd40e4  push r9
000073307ffd40e6  push r10
000073307ffd40e8  push r11
000073307ffd40ea  sub rsp, 0xF0
000073307ffd40f1  vmovaps [rsp], xmm0
000073307ffd40f6  vmovaps [rsp+0x10], xmm1
000073307ffd40fc  vmovaps [rsp+0x20], xmm2
000073307ffd4102  vmovaps [rsp+0x30], xmm3
000073307ffd4108  vmovaps [rsp+0x40], xmm4
000073307ffd410e  vmovaps [rsp+0x50], xmm5
000073307ffd4114  vmovaps [rsp+0x60], xmm6
000073307ffd411a  vmovaps [rsp+0x70], xmm7
000073307ffd4120  vmovaps [rsp+0x80], xmm8
000073307ffd4129  vmovaps [rsp+0x90], xmm9
000073307ffd4132  vmovaps [rsp+0xA0], xmm10
000073307ffd413b  vmovaps [rsp+0xB0], xmm11
000073307ffd4144  vmovaps [rsp+0xC0], xmm12
000073307ffd414d  vmovaps [rsp+0xD0], xmm13
000073307ffd4156  vmovaps [rsp+0xE0], xmm15
000073307ffd415f  sub rsp, 0x30
000073307ffd4163  movaps [rsp], xmm14
000073307ffd4168  movaps [rsp+0x10], xmm12
000073307ffd416e  movaps [rsp+0x20], xmm9
000073307ffd4174  lea rdi, [rsp]
000073307ffd4178  mov esi, 0x00
000073307ffd417d  mov rax, 0x600DE0EC8530
000073307ffd4187  call rax
000073307ffd4189  movaps xmm14, [rsp]
000073307ffd418e  add rsp, 0x30
000073307ffd4192  vmovaps xmm0, [rsp]
000073307ffd4197  vmovaps xmm1, [rsp+0x10]
000073307ffd419d  vmovaps xmm2, [rsp+0x20]
000073307ffd41a3  vmovaps xmm3, [rsp+0x30]
000073307ffd41a9  vmovaps xmm4, [rsp+0x40]
000073307ffd41af  vmovaps xmm5, [rsp+0x50]
000073307ffd41b5  vmovaps xmm6, [rsp+0x60]
000073307ffd41bb  vmovaps xmm7, [rsp+0x70]
000073307ffd41c1  vmovaps xmm8, [rsp+0x80]
000073307ffd41ca  vmovaps xmm9, [rsp+0x90]
000073307ffd41d3  vmovaps xmm10, [rsp+0xA0]
000073307ffd41dc  vmovaps xmm11, [rsp+0xB0]
000073307ffd41e5  vmovaps xmm12, [rsp+0xC0]
000073307ffd41ee  vmovaps xmm13, [rsp+0xD0]
000073307ffd41f7  vmovaps xmm15, [rsp+0xE0]
000073307ffd4200  add rsp, 0xF0
000073307ffd4207  pop r11
000073307ffd4209  pop r10
000073307ffd420b  pop r9
000073307ffd420d  pop r8
000073307ffd420f  pop rsi
000073307ffd4210  pop rdi
000073307ffd4211  pop rdx
000073307ffd4212  pop rcx
000073307ffd4213  pop rax
000073307ffd4214  add rsp, 0x08
000073307ffd4218  jmp 0x000073307FFD00AE
000073307ffd421d  sub rsp, 0x08
000073307ffd4221  push rax
000073307ffd4222  push rcx
000073307ffd4223  push rdx
000073307ffd4224  push rdi
000073307ffd4225  push rsi
000073307ffd4226  push r8
000073307ffd4228  push r9
000073307ffd422a  push r10
000073307ffd422c  push r11
000073307ffd422e  sub rsp, 0xF0
000073307ffd4235  vmovaps [rsp], xmm0
000073307ffd423a  vmovaps [rsp+0x10], xmm1
000073307ffd4240  vmovaps [rsp+0x20], xmm2
000073307ffd4246  vmovaps [rsp+0x30], xmm3
000073307ffd424c  vmovaps [rsp+0x40], xmm4
000073307ffd4252  vmovaps [rsp+0x50], xmm5
000073307ffd4258  vmovaps [rsp+0x60], xmm6
000073307ffd425e  vmovaps [rsp+0x70], xmm7
000073307ffd4264  vmovaps [rsp+0x80], xmm8
000073307ffd426d  vmovaps [rsp+0x90], xmm10
000073307ffd4276  vmovaps [rsp+0xA0], xmm11
000073307ffd427f  vmovaps [rsp+0xB0], xmm12
000073307ffd4288  vmovaps [rsp+0xC0], xmm13
000073307ffd4291  vmovaps [rsp+0xD0], xmm14
000073307ffd429a  vmovaps [rsp+0xE0], xmm15
000073307ffd42a3  sub rsp, 0x30
000073307ffd42a7  movaps [rsp], xmm9
000073307ffd42ac  movaps [rsp+0x10], xmm7
000073307ffd42b1  movaps [rsp+0x20], xmm12
000073307ffd42b7  lea rdi, [rsp]
000073307ffd42bb  mov esi, 0x00
000073307ffd42c0  mov rax, 0x600DE0EC8530
000073307ffd42ca  call rax
000073307ffd42cc  movaps xmm9, [rsp]
000073307ffd42d1  add rsp, 0x30
000073307ffd42d5  vmovaps xmm0, [rsp]
000073307ffd42da  vmovaps xmm1, [rsp+0x10]
000073307ffd42e0  vmovaps xmm2, [rsp+0x20]
000073307ffd42e6  vmovaps xmm3, [rsp+0x30]
000073307ffd42ec  vmovaps xmm4, [rsp+0x40]
000073307ffd42f2  vmovaps xmm5, [rsp+0x50]
000073307ffd42f8  vmovaps xmm6, [rsp+0x60]
000073307ffd42fe  vmovaps xmm7, [rsp+0x70]
000073307ffd4304  vmovaps xmm8, [rsp+0x80]
000073307ffd430d  vmovaps xmm10, [rsp+0x90]
000073307ffd4316  vmovaps xmm11, [rsp+0xA0]
000073307ffd431f  vmovaps xmm12, [rsp+0xB0]
000073307ffd4328  vmovaps xmm13, [rsp+0xC0]
000073307ffd4331  vmovaps xmm14, [rsp+0xD0]
000073307ffd433a  vmovaps xmm15, [rsp+0xE0]
000073307ffd4343  add rsp, 0xF0
000073307ffd434a  pop r11
000073307ffd434c  pop r10
000073307ffd434e  pop r9
000073307ffd4350  pop r8
000073307ffd4352  pop rsi
000073307ffd4353  pop rdi
000073307ffd4354  pop rdx
000073307ffd4355  pop rcx
000073307ffd4356  pop rax
000073307ffd4357  add rsp, 0x08
000073307ffd435b  jmp 0x000073307FFD00DD
000073307ffd4360  sub rsp, 0x08
000073307ffd4364  push rax
000073307ffd4365  push rcx
000073307ffd4366  push rdx
000073307ffd4367  push rdi
000073307ffd4368  push rsi
000073307ffd4369  push r8
000073307ffd436b  push r9
000073307ffd436d  push r10
000073307ffd436f  push r11
000073307ffd4371  sub rsp, 0xF0
000073307ffd4378  vmovaps [rsp], xmm0
000073307ffd437d  vmovaps [rsp+0x10], xmm1
000073307ffd4383  vmovaps [rsp+0x20], xmm2
000073307ffd4389  vmovaps [rsp+0x30], xmm3
000073307ffd438f  vmovaps [rsp+0x40], xmm4
000073307ffd4395  vmovaps [rsp+0x50], xmm5
000073307ffd439b  vmovaps [rsp+0x60], xmm6
000073307ffd43a1  vmovaps [rsp+0x70], xmm7
000073307ffd43a7  vmovaps [rsp+0x80], xmm8
000073307ffd43b0  vmovaps [rsp+0x90], xmm9
000073307ffd43b9  vmovaps [rsp+0xA0], xmm10
000073307ffd43c2  vmovaps [rsp+0xB0], xmm11
000073307ffd43cb  vmovaps [rsp+0xC0], xmm13
000073307ffd43d4  vmovaps [rsp+0xD0], xmm14
000073307ffd43dd  vmovaps [rsp+0xE0], xmm15
000073307ffd43e6  sub rsp, 0x30
000073307ffd43ea  movaps [rsp], xmm12
000073307ffd43ef  movaps [rsp+0x10], xmm15
000073307ffd43f5  movaps [rsp+0x20], xmm11
000073307ffd43fb  lea rdi, [rsp]
000073307ffd43ff  mov esi, 0x00
000073307ffd4404  mov rax, 0x600DE0EC8530
000073307ffd440e  call rax
000073307ffd4410  movaps xmm12, [rsp]
000073307ffd4415  add rsp, 0x30
000073307ffd4419  vmovaps xmm0, [rsp]
000073307ffd441e  vmovaps xmm1, [rsp+0x10]
000073307ffd4424  vmovaps xmm2, [rsp+0x20]
000073307ffd442a  vmovaps xmm3, [rsp+0x30]
000073307ffd4430  vmovaps xmm4, [rsp+0x40]
000073307ffd4436  vmovaps xmm5, [rsp+0x50]
000073307ffd443c  vmovaps xmm6, [rsp+0x60]
000073307ffd4442  vmovaps xmm7, [rsp+0x70]
000073307ffd4448  vmovaps xmm8, [rsp+0x80]
000073307ffd4451  vmovaps xmm9, [rsp+0x90]
000073307ffd445a  vmovaps xmm10, [rsp+0xA0]
000073307ffd4463  vmovaps xmm11, [rsp+0xB0]
000073307ffd446c  vmovaps xmm13, [rsp+0xC0]
000073307ffd4475  vmovaps xmm14, [rsp+0xD0]
000073307ffd447e  vmovaps xmm15, [rsp+0xE0]
000073307ffd4487  add rsp, 0xF0
000073307ffd448e  pop r11
000073307ffd4490  pop r10
000073307ffd4492  pop r9
000073307ffd4494  pop r8
000073307ffd4496  pop rsi
000073307ffd4497  pop rdi
000073307ffd4498  pop rdx
000073307ffd4499  pop rcx
000073307ffd449a  pop rax
000073307ffd449b  add rsp, 0x08
000073307ffd449f  jmp 0x000073307FFD00F7
000073307ffd44a4  sub rsp, 0x08
000073307ffd44a8  push rax
000073307ffd44a9  push rcx
000073307ffd44aa  push rdx
000073307ffd44ab  push rdi
000073307ffd44ac  push rsi
000073307ffd44ad  push r8
000073307ffd44af  push r9
000073307ffd44b1  push r10
000073307ffd44b3  push r11
000073307ffd44b5  sub rsp, 0xF0
000073307ffd44bc  vmovaps [rsp], xmm0
000073307ffd44c1  vmovaps [rsp+0x10], xmm1
000073307ffd44c7  vmovaps [rsp+0x20], xmm2
000073307ffd44cd  vmovaps [rsp+0x30], xmm3
000073307ffd44d3  vmovaps [rsp+0x40], xmm4
000073307ffd44d9  vmovaps [rsp+0x50], xmm5
000073307ffd44df  vmovaps [rsp+0x60], xmm6
000073307ffd44e5  vmovaps [rsp+0x70], xmm7
000073307ffd44eb  vmovaps [rsp+0x80], xmm8
000073307ffd44f4  vmovaps [rsp+0x90], xmm9
000073307ffd44fd  vmovaps [rsp+0xA0], xmm10
000073307ffd4506  vmovaps [rsp+0xB0], xmm12
000073307ffd450f  vmovaps [rsp+0xC0], xmm13
000073307ffd4518  vmovaps [rsp+0xD0], xmm14
000073307ffd4521  vmovaps [rsp+0xE0], xmm15
000073307ffd452a  sub rsp, 0x30
000073307ffd452e  movaps [rsp], xmm11
000073307ffd4533  movaps [rsp+0x10], xmm7
000073307ffd4538  movaps [rsp+0x20], xmm15
000073307ffd453e  lea rdi, [rsp]
000073307ffd4542  mov esi, 0x00
000073307ffd4547  mov rax, 0x600DE0EC8530
000073307ffd4551  call rax
000073307ffd4553  movaps xmm11, [rsp]
000073307ffd4558  add rsp, 0x30
000073307ffd455c  vmovaps xmm0, [rsp]
000073307ffd4561  vmovaps xmm1, [rsp+0x10]
000073307ffd4567  vmovaps xmm2, [rsp+0x20]
000073307ffd456d  vmovaps xmm3, [rsp+0x30]
000073307ffd4573  vmovaps xmm4, [rsp+0x40]
000073307ffd4579  vmovaps xmm5, [rsp+0x50]
000073307ffd457f  vmovaps xmm6, [rsp+0x60]
000073307ffd4585  vmovaps xmm7, [rsp+0x70]
000073307ffd458b  vmovaps xmm8, [rsp+0x80]
000073307ffd4594  vmovaps xmm9, [rsp+0x90]
000073307ffd459d  vmovaps xmm10, [rsp+0xA0]
000073307ffd45a6  vmovaps xmm12, [rsp+0xB0]
000073307ffd45af  vmovaps xmm13, [rsp+0xC0]
000073307ffd45b8  vmovaps xmm14, [rsp+0xD0]
000073307ffd45c1  vmovaps xmm15, [rsp+0xE0]
000073307ffd45ca  add rsp, 0xF0
000073307ffd45d1  pop r11
000073307ffd45d3  pop r10
000073307ffd45d5  pop r9
000073307ffd45d7  pop r8
000073307ffd45d9  pop rsi
000073307ffd45da  pop rdi
000073307ffd45db  pop rdx
000073307ffd45dc  pop rcx
000073307ffd45dd  pop rax
000073307ffd45de  add rsp, 0x08
000073307ffd45e2  jmp 0x000073307FFD0123
000073307ffd45e7  sub rsp, 0x08
000073307ffd45eb  push rax
000073307ffd45ec  push rcx
000073307ffd45ed  push rdx
000073307ffd45ee  push rdi
000073307ffd45ef  push rsi
000073307ffd45f0  push r8
000073307ffd45f2  push r9
000073307ffd45f4  push r10
000073307ffd45f6  push r11
000073307ffd45f8  sub rsp, 0xF0
000073307ffd45ff  vmovaps [rsp], xmm0
000073307ffd4604  vmovaps [rsp+0x10], xmm1
000073307ffd460a  vmovaps [rsp+0x20], xmm2
000073307ffd4610  vmovaps [rsp+0x30], xmm3
000073307ffd4616  vmovaps [rsp+0x40], xmm4
000073307ffd461c  vmovaps [rsp+0x50], xmm5
000073307ffd4622  vmovaps [rsp+0x60], xmm6
000073307ffd4628  vmovaps [rsp+0x70], xmm7
000073307ffd462e  vmovaps [rsp+0x80], xmm8
000073307ffd4637  vmovaps [rsp+0x90], xmm9
000073307ffd4640  vmovaps [rsp+0xA0], xmm10
000073307ffd4649  vmovaps [rsp+0xB0], xmm11
000073307ffd4652  vmovaps [rsp+0xC0], xmm12
000073307ffd465b  vmovaps [rsp+0xD0], xmm13
000073307ffd4664  vmovaps [rsp+0xE0], xmm14
000073307ffd466d  sub rsp, 0x30
000073307ffd4671  movaps [rsp], xmm15
000073307ffd4676  movaps [rsp+0x10], xmm10
000073307ffd467c  movaps [rsp+0x20], xmm13
000073307ffd4682  lea rdi, [rsp]
000073307ffd4686  mov esi, 0x00
000073307ffd468b  mov rax, 0x600DE0EC8530
000073307ffd4695  call rax
000073307ffd4697  movaps xmm15, [rsp]
000073307ffd469c  add rsp, 0x30
000073307ffd46a0  vmovaps xmm0, [rsp]
000073307ffd46a5  vmovaps xmm1, [rsp+0x10]
000073307ffd46ab  vmovaps xmm2, [rsp+0x20]
000073307ffd46b1  vmovaps xmm3, [rsp+0x30]
000073307ffd46b7  vmovaps xmm4, [rsp+0x40]
000073307ffd46bd  vmovaps xmm5, [rsp+0x50]
000073307ffd46c3  vmovaps xmm6, [rsp+0x60]
000073307ffd46c9  vmovaps xmm7, [rsp+0x70]
000073307ffd46cf  vmovaps xmm8, [rsp+0x80]
000073307ffd46d8  vmovaps xmm9, [rsp+0x90]
000073307ffd46e1  vmovaps xmm10, [rsp+0xA0]
000073307ffd46ea  vmovaps xmm11, [rsp+0xB0]
000073307ffd46f3  vmovaps xmm12, [rsp+0xC0]
000073307ffd46fc  vmovaps xmm13, [rsp+0xD0]
000073307ffd4705  vmovaps xmm14, [rsp+0xE0]
000073307ffd470e  add rsp, 0xF0
000073307ffd4715  pop r11
000073307ffd4717  pop r10
000073307ffd4719  pop r9
000073307ffd471b  pop r8
000073307ffd471d  pop rsi
000073307ffd471e  pop rdi
000073307ffd471f  pop rdx
000073307ffd4720  pop rcx
000073307ffd4721  pop rax
000073307ffd4722  add rsp, 0x08
000073307ffd4726  jmp 0x000073307FFD013D
000073307ffd472b  sub rsp, 0x08
000073307ffd472f  push rax
000073307ffd4730  push rcx
000073307ffd4731  push rdx
000073307ffd4732  push rdi
000073307ffd4733  push rsi
000073307ffd4734  push r8
000073307ffd4736  push r9
000073307ffd4738  push r10
000073307ffd473a  push r11
000073307ffd473c  sub rsp, 0xF0
000073307ffd4743  vmovaps [rsp], xmm0
000073307ffd4748  vmovaps [rsp+0x10], xmm1
000073307ffd474e  vmovaps [rsp+0x20], xmm2
000073307ffd4754  vmovaps [rsp+0x30], xmm3
000073307ffd475a  vmovaps [rsp+0x40], xmm4
000073307ffd4760  vmovaps [rsp+0x50], xmm5
000073307ffd4766  vmovaps [rsp+0x60], xmm6
000073307ffd476c  vmovaps [rsp+0x70], xmm7
000073307ffd4772  vmovaps [rsp+0x80], xmm8
000073307ffd477b  vmovaps [rsp+0x90], xmm9
000073307ffd4784  vmovaps [rsp+0xA0], xmm11
000073307ffd478d  vmovaps [rsp+0xB0], xmm12
000073307ffd4796  vmovaps [rsp+0xC0], xmm13
000073307ffd479f  vmovaps [rsp+0xD0], xmm14
000073307ffd47a8  vmovaps [rsp+0xE0], xmm15
000073307ffd47b1  sub rsp, 0x30
000073307ffd47b5  movaps [rsp], xmm10
000073307ffd47ba  movaps [rsp+0x10], xmm7
000073307ffd47bf  movaps [rsp+0x20], xmm13
000073307ffd47c5  lea rdi, [rsp]
000073307ffd47c9  mov esi, 0x00
000073307ffd47ce  mov rax, 0x600DE0EC8530
000073307ffd47d8  call rax
000073307ffd47da  movaps xmm10, [rsp]
000073307ffd47df  add rsp, 0x30
000073307ffd47e3  vmovaps xmm0, [rsp]
000073307ffd47e8  vmovaps xmm1, [rsp+0x10]
000073307ffd47ee  vmovaps xmm2, [rsp+0x20]
000073307ffd47f4  vmovaps xmm3, [rsp+0x30]
000073307ffd47fa  vmovaps xmm4, [rsp+0x40]
000073307ffd4800  vmovaps xmm5, [rsp+0x50]
000073307ffd4806  vmovaps xmm6, [rsp+0x60]
000073307ffd480c  vmovaps xmm7, [rsp+0x70]
000073307ffd4812  vmovaps xmm8, [rsp+0x80]
000073307ffd481b  vmovaps xmm9, [rsp+0x90]
000073307ffd4824  vmovaps xmm11, [rsp+0xA0]
000073307ffd482d  vmovaps xmm12, [rsp+0xB0]
000073307ffd4836  vmovaps xmm13, [rsp+0xC0]
000073307ffd483f  vmovaps xmm14, [rsp+0xD0]
000073307ffd4848  vmovaps xmm15, [rsp+0xE0]
000073307ffd4851  add rsp, 0xF0
000073307ffd4858  pop r11
000073307ffd485a  pop r10
000073307ffd485c  pop r9
000073307ffd485e  pop r8
000073307ffd4860  pop rsi
000073307ffd4861  pop rdi
000073307ffd4862  pop rdx
000073307ffd4863  pop rcx
000073307ffd4864  pop rax
000073307ffd4865  add rsp, 0x08
000073307ffd4869  jmp 0x000073307FFD0169
000073307ffd486e  sub rsp, 0x08
000073307ffd4872  push rax
000073307ffd4873  push rcx
000073307ffd4874  push rdx
000073307ffd4875  push rdi
000073307ffd4876  push rsi
000073307ffd4877  push r8
000073307ffd4879  push r9
000073307ffd487b  push r10
000073307ffd487d  push r11
000073307ffd487f  sub rsp, 0xF0
000073307ffd4886  vmovaps [rsp], xmm0
000073307ffd488b  vmovaps [rsp+0x10], xmm1
000073307ffd4891  vmovaps [rsp+0x20], xmm2
000073307ffd4897  vmovaps [rsp+0x30], xmm3
000073307ffd489d  vmovaps [rsp+0x40], xmm4
000073307ffd48a3  vmovaps [rsp+0x50], xmm5
000073307ffd48a9  vmovaps [rsp+0x60], xmm6
000073307ffd48af  vmovaps [rsp+0x70], xmm7
000073307ffd48b5  vmovaps [rsp+0x80], xmm8
000073307ffd48be  vmovaps [rsp+0x90], xmm9
000073307ffd48c7  vmovaps [rsp+0xA0], xmm10
000073307ffd48d0  vmovaps [rsp+0xB0], xmm11
000073307ffd48d9  vmovaps [rsp+0xC0], xmm12
000073307ffd48e2  vmovaps [rsp+0xD0], xmm14
000073307ffd48eb  vmovaps [rsp+0xE0], xmm15
000073307ffd48f4  sub rsp, 0x30
000073307ffd48f8  movaps [rsp], xmm13
000073307ffd48fd  movaps [rsp+0x10], xmm1
000073307ffd4902  movaps [rsp+0x20], xmm8
000073307ffd4908  lea rdi, [rsp]
000073307ffd490c  mov esi, 0x00
000073307ffd4911  mov rax, 0x600DE0EC8530
000073307ffd491b  call rax
000073307ffd491d  movaps xmm13, [rsp]
000073307ffd4922  add rsp, 0x30
000073307ffd4926  vmovaps xmm0, [rsp]
000073307ffd492b  vmovaps xmm1, [rsp+0x10]
000073307ffd4931  vmovaps xmm2, [rsp+0x20]
000073307ffd4937  vmovaps xmm3, [rsp+0x30]
000073307ffd493d  vmovaps xmm4, [rsp+0x40]
000073307ffd4943  vmovaps xmm5, [rsp+0x50]
000073307ffd4949  vmovaps xmm6, [rsp+0x60]
000073307ffd494f  vmovaps xmm7, [rsp+0x70]
000073307ffd4955  vmovaps xmm8, [rsp+0x80]
000073307ffd495e  vmovaps xmm9, [rsp+0x90]
000073307ffd4967  vmovaps xmm10, [rsp+0xA0]
000073307ffd4970  vmovaps xmm11, [rsp+0xB0]
000073307ffd4979  vmovaps xmm12, [rsp+0xC0]
000073307ffd4982  vmovaps xmm14, [rsp+0xD0]
000073307ffd498b  vmovaps xmm15, [rsp+0xE0]
000073307ffd4994  add rsp, 0xF0
000073307ffd499b  pop r11
000073307ffd499d  pop r10
000073307ffd499f  pop r9
000073307ffd49a1  pop r8
000073307ffd49a3  pop rsi
000073307ffd49a4  pop rdi
000073307ffd49a5  pop rdx
000073307ffd49a6  pop rcx
000073307ffd49a7  pop rax
000073307ffd49a8  add rsp, 0x08
000073307ffd49ac  jmp 0x000073307FFD0183
000073307ffd49b1  call 0x000073307FDFF430
000073307ffd49b6  jmp 0x000073307FFD018D
000073307ffd49bb  sub rsp, 0x08
000073307ffd49bf  push rax
000073307ffd49c0  push rcx
000073307ffd49c1  push rdx
000073307ffd49c2  push rdi
000073307ffd49c3  push rsi
000073307ffd49c4  push r8
000073307ffd49c6  push r9
000073307ffd49c8  push r10
000073307ffd49ca  push r11
000073307ffd49cc  sub rsp, 0xF0
000073307ffd49d3  vmovaps [rsp], xmm0
000073307ffd49d8  vmovaps [rsp+0x10], xmm1
000073307ffd49de  vmovaps [rsp+0x20], xmm2
000073307ffd49e4  vmovaps [rsp+0x30], xmm3
000073307ffd49ea  vmovaps [rsp+0x40], xmm4
000073307ffd49f0  vmovaps [rsp+0x50], xmm5
000073307ffd49f6  vmovaps [rsp+0x60], xmm6
000073307ffd49fc  vmovaps [rsp+0x70], xmm7
000073307ffd4a02  vmovaps [rsp+0x80], xmm9
000073307ffd4a0b  vmovaps [rsp+0x90], xmm10
000073307ffd4a14  vmovaps [rsp+0xA0], xmm11
000073307ffd4a1d  vmovaps [rsp+0xB0], xmm12
000073307ffd4a26  vmovaps [rsp+0xC0], xmm13
000073307ffd4a2f  vmovaps [rsp+0xD0], xmm14
000073307ffd4a38  vmovaps [rsp+0xE0], xmm15
000073307ffd4a41  sub rsp, 0x30
000073307ffd4a45  movaps [rsp], xmm8
000073307ffd4a4a  movaps [rsp+0x10], xmm14
000073307ffd4a50  movaps [rsp+0x20], xmm9
000073307ffd4a56  lea rdi, [rsp]
000073307ffd4a5a  mov esi, 0x00
000073307ffd4a5f  mov rax, 0x600DE0EC8530
000073307ffd4a69  call rax
000073307ffd4a6b  movaps xmm8, [rsp]
000073307ffd4a70  add rsp, 0x30
000073307ffd4a74  vmovaps xmm0, [rsp]
000073307ffd4a79  vmovaps xmm1, [rsp+0x10]
000073307ffd4a7f  vmovaps xmm2, [rsp+0x20]
000073307ffd4a85  vmovaps xmm3, [rsp+0x30]
000073307ffd4a8b  vmovaps xmm4, [rsp+0x40]
000073307ffd4a91  vmovaps xmm5, [rsp+0x50]
000073307ffd4a97  vmovaps xmm6, [rsp+0x60]
000073307ffd4a9d  vmovaps xmm7, [rsp+0x70]
000073307ffd4aa3  vmovaps xmm9, [rsp+0x80]
000073307ffd4aac  vmovaps xmm10, [rsp+0x90]
000073307ffd4ab5  vmovaps xmm11, [rsp+0xA0]
000073307ffd4abe  vmovaps xmm12, [rsp+0xB0]
000073307ffd4ac7  vmovaps xmm13, [rsp+0xC0]
000073307ffd4ad0  vmovaps xmm14, [rsp+0xD0]
000073307ffd4ad9  vmovaps xmm15, [rsp+0xE0]
000073307ffd4ae2  add rsp, 0xF0
000073307ffd4ae9  pop r11
000073307ffd4aeb  pop r10
000073307ffd4aed  pop r9
000073307ffd4aef  pop r8
000073307ffd4af1  pop rsi
000073307ffd4af2  pop rdi
000073307ffd4af3  pop rdx
000073307ffd4af4  pop rcx
000073307ffd4af5  pop rax
000073307ffd4af6  add rsp, 0x08
000073307ffd4afa  jmp 0x000073307FFD01AF
000073307ffd4aff  sub rsp, 0x08
000073307ffd4b03  push rax
000073307ffd4b04  push rcx
000073307ffd4b05  push rdx
000073307ffd4b06  push rdi
000073307ffd4b07  push rsi
000073307ffd4b08  push r8
000073307ffd4b0a  push r9
000073307ffd4b0c  push r10
000073307ffd4b0e  push r11
000073307ffd4b10  sub rsp, 0xF0
000073307ffd4b17  vmovaps [rsp], xmm0
000073307ffd4b1c  vmovaps [rsp+0x10], xmm1
000073307ffd4b22  vmovaps [rsp+0x20], xmm2
000073307ffd4b28  vmovaps [rsp+0x30], xmm3
000073307ffd4b2e  vmovaps [rsp+0x40], xmm4
000073307ffd4b34  vmovaps [rsp+0x50], xmm5
000073307ffd4b3a  vmovaps [rsp+0x60], xmm6
000073307ffd4b40  vmovaps [rsp+0x70], xmm7
000073307ffd4b46  vmovaps [rsp+0x80], xmm8
000073307ffd4b4f  vmovaps [rsp+0x90], xmm10
000073307ffd4b58  vmovaps [rsp+0xA0], xmm11
000073307ffd4b61  vmovaps [rsp+0xB0], xmm12
000073307ffd4b6a  vmovaps [rsp+0xC0], xmm13
000073307ffd4b73  vmovaps [rsp+0xD0], xmm14
000073307ffd4b7c  vmovaps [rsp+0xE0], xmm15
000073307ffd4b85  sub rsp, 0x30
000073307ffd4b89  movaps [rsp], xmm9
000073307ffd4b8e  movaps [rsp+0x10], xmm1
000073307ffd4b93  movaps [rsp+0x20], xmm14
000073307ffd4b99  lea rdi, [rsp]
000073307ffd4b9d  mov esi, 0x00
000073307ffd4ba2  mov rax, 0x600DE0EC8530
000073307ffd4bac  call rax
000073307ffd4bae  movaps xmm9, [rsp]
000073307ffd4bb3  add rsp, 0x30
000073307ffd4bb7  vmovaps xmm0, [rsp]
000073307ffd4bbc  vmovaps xmm1, [rsp+0x10]
000073307ffd4bc2  vmovaps xmm2, [rsp+0x20]
000073307ffd4bc8  vmovaps xmm3, [rsp+0x30]
000073307ffd4bce  vmovaps xmm4, [rsp+0x40]
000073307ffd4bd4  vmovaps xmm5, [rsp+0x50]
000073307ffd4bda  vmovaps xmm6, [rsp+0x60]
000073307ffd4be0  vmovaps xmm7, [rsp+0x70]
000073307ffd4be6  vmovaps xmm8, [rsp+0x80]
000073307ffd4bef  vmovaps xmm10, [rsp+0x90]
000073307ffd4bf8  vmovaps xmm11, [rsp+0xA0]
000073307ffd4c01  vmovaps xmm12, [rsp+0xB0]
000073307ffd4c0a  vmovaps xmm13, [rsp+0xC0]
000073307ffd4c13  vmovaps xmm14, [rsp+0xD0]
000073307ffd4c1c  vmovaps xmm15, [rsp+0xE0]
000073307ffd4c25  add rsp, 0xF0
000073307ffd4c2c  pop r11
000073307ffd4c2e  pop r10
000073307ffd4c30  pop r9
000073307ffd4c32  pop r8
000073307ffd4c34  pop rsi
000073307ffd4c35  pop rdi
000073307ffd4c36  pop rdx
000073307ffd4c37  pop rcx
000073307ffd4c38  pop rax
000073307ffd4c39  add rsp, 0x08
000073307ffd4c3d  jmp 0x000073307FFD01DD
000073307ffd4c42  sub rsp, 0x08
000073307ffd4c46  push rax
000073307ffd4c47  push rcx
000073307ffd4c48  push rdx
000073307ffd4c49  push rdi
000073307ffd4c4a  push rsi
000073307ffd4c4b  push r8
000073307ffd4c4d  push r9
000073307ffd4c4f  push r10
000073307ffd4c51  push r11
000073307ffd4c53  sub rsp, 0xF0
000073307ffd4c5a  vmovaps [rsp], xmm0
000073307ffd4c5f  vmovaps [rsp+0x10], xmm1
000073307ffd4c65  vmovaps [rsp+0x20], xmm2
000073307ffd4c6b  vmovaps [rsp+0x30], xmm3
000073307ffd4c71  vmovaps [rsp+0x40], xmm4
000073307ffd4c77  vmovaps [rsp+0x50], xmm5
000073307ffd4c7d  vmovaps [rsp+0x60], xmm6
000073307ffd4c83  vmovaps [rsp+0x70], xmm7
000073307ffd4c89  vmovaps [rsp+0x80], xmm8
000073307ffd4c92  vmovaps [rsp+0x90], xmm9
000073307ffd4c9b  vmovaps [rsp+0xA0], xmm10
000073307ffd4ca4  vmovaps [rsp+0xB0], xmm11
000073307ffd4cad  vmovaps [rsp+0xC0], xmm12
000073307ffd4cb6  vmovaps [rsp+0xD0], xmm13
000073307ffd4cbf  vmovaps [rsp+0xE0], xmm15
000073307ffd4cc8  sub rsp, 0x30
000073307ffd4ccc  movaps [rsp], xmm14
000073307ffd4cd1  movaps [rsp+0x10], xmm4
000073307ffd4cd6  movaps [rsp+0x20], xmm1
000073307ffd4cdb  lea rdi, [rsp]
000073307ffd4cdf  mov esi, 0x00
000073307ffd4ce4  mov rax, 0x600DE0EC8530
000073307ffd4cee  call rax
000073307ffd4cf0  movaps xmm14, [rsp]
000073307ffd4cf5  add rsp, 0x30
000073307ffd4cf9  vmovaps xmm0, [rsp]
000073307ffd4cfe  vmovaps xmm1, [rsp+0x10]
000073307ffd4d04  vmovaps xmm2, [rsp+0x20]
000073307ffd4d0a  vmovaps xmm3, [rsp+0x30]
000073307ffd4d10  vmovaps xmm4, [rsp+0x40]
000073307ffd4d16  vmovaps xmm5, [rsp+0x50]
000073307ffd4d1c  vmovaps xmm6, [rsp+0x60]
000073307ffd4d22  vmovaps xmm7, [rsp+0x70]
000073307ffd4d28  vmovaps xmm8, [rsp+0x80]
000073307ffd4d31  vmovaps xmm9, [rsp+0x90]
000073307ffd4d3a  vmovaps xmm10, [rsp+0xA0]
000073307ffd4d43  vmovaps xmm11, [rsp+0xB0]
000073307ffd4d4c  vmovaps xmm12, [rsp+0xC0]
000073307ffd4d55  vmovaps xmm13, [rsp+0xD0]
000073307ffd4d5e  vmovaps xmm15, [rsp+0xE0]
000073307ffd4d67  add rsp, 0xF0
000073307ffd4d6e  pop r11
000073307ffd4d70  pop r10
000073307ffd4d72  pop r9
000073307ffd4d74  pop r8
000073307ffd4d76  pop rsi
000073307ffd4d77  pop rdi
000073307ffd4d78  pop rdx
000073307ffd4d79  pop rcx
000073307ffd4d7a  pop rax
000073307ffd4d7b  add rsp, 0x08
000073307ffd4d7f  jmp 0x000073307FFD0203
000073307ffd4d84  sub rsp, 0x08
000073307ffd4d88  push rax
000073307ffd4d89  push rcx
000073307ffd4d8a  push rdx
000073307ffd4d8b  push rdi
000073307ffd4d8c  push rsi
000073307ffd4d8d  push r8
000073307ffd4d8f  push r9
000073307ffd4d91  push r10
000073307ffd4d93  push r11
000073307ffd4d95  sub rsp, 0xF0
000073307ffd4d9c  vmovaps [rsp], xmm0
000073307ffd4da1  vmovaps [rsp+0x10], xmm2
000073307ffd4da7  vmovaps [rsp+0x20], xmm3
000073307ffd4dad  vmovaps [rsp+0x30], xmm4
000073307ffd4db3  vmovaps [rsp+0x40], xmm5
000073307ffd4db9  vmovaps [rsp+0x50], xmm6
000073307ffd4dbf  vmovaps [rsp+0x60], xmm7
000073307ffd4dc5  vmovaps [rsp+0x70], xmm8
000073307ffd4dcb  vmovaps [rsp+0x80], xmm9
000073307ffd4dd4  vmovaps [rsp+0x90], xmm10
000073307ffd4ddd  vmovaps [rsp+0xA0], xmm11
000073307ffd4de6  vmovaps [rsp+0xB0], xmm12
000073307ffd4def  vmovaps [rsp+0xC0], xmm13
000073307ffd4df8  vmovaps [rsp+0xD0], xmm14
000073307ffd4e01  vmovaps [rsp+0xE0], xmm15
000073307ffd4e0a  sub rsp, 0x30
000073307ffd4e0e  movaps [rsp], xmm1
000073307ffd4e12  movaps [rsp+0x10], xmm12
000073307ffd4e18  movaps [rsp+0x20], xmm11
000073307ffd4e1e  lea rdi, [rsp]
000073307ffd4e22  mov esi, 0x00
000073307ffd4e27  mov rax, 0x600DE0EC8530
000073307ffd4e31  call rax
000073307ffd4e33  movaps xmm1, [rsp]
000073307ffd4e37  add rsp, 0x30
000073307ffd4e3b  vmovaps xmm0, [rsp]
000073307ffd4e40  vmovaps xmm2, [rsp+0x10]
000073307ffd4e46  vmovaps xmm3, [rsp+0x20]
000073307ffd4e4c  vmovaps xmm4, [rsp+0x30]
000073307ffd4e52  vmovaps xmm5, [rsp+0x40]
000073307ffd4e58  vmovaps xmm6, [rsp+0x50]
000073307ffd4e5e  vmovaps xmm7, [rsp+0x60]
000073307ffd4e64  vmovaps xmm8, [rsp+0x70]
000073307ffd4e6a  vmovaps xmm9, [rsp+0x80]
000073307ffd4e73  vmovaps xmm10, [rsp+0x90]
000073307ffd4e7c  vmovaps xmm11, [rsp+0xA0]
000073307ffd4e85  vmovaps xmm12, [rsp+0xB0]
000073307ffd4e8e  vmovaps xmm13, [rsp+0xC0]
000073307ffd4e97  vmovaps xmm14, [rsp+0xD0]
000073307ffd4ea0  vmovaps xmm15, [rsp+0xE0]
000073307ffd4ea9  add rsp, 0xF0
000073307ffd4eb0  pop r11
000073307ffd4eb2  pop r10
000073307ffd4eb4  pop r9
000073307ffd4eb6  pop r8
000073307ffd4eb8  pop rsi
000073307ffd4eb9  pop rdi
000073307ffd4eba  pop rdx
000073307ffd4ebb  pop rcx
000073307ffd4ebc  pop rax
000073307ffd4ebd  add rsp, 0x08
000073307ffd4ec1  jmp 0x000073307FFD0224
000073307ffd4ec6  call 0x000073307FEE20A0
000073307ffd4ecb  jmp 0x000073307FFD0232
000073307ffd4ed0  call 0x000073307FE09D70
000073307ffd4ed5  jmp 0x000073307FFD023C
000073307ffd4eda  sub rsp, 0x08
000073307ffd4ede  push rax
000073307ffd4edf  push rcx
000073307ffd4ee0  push rdx
000073307ffd4ee1  push rdi
000073307ffd4ee2  push rsi
000073307ffd4ee3  push r8
000073307ffd4ee5  push r9
000073307ffd4ee7  push r10
000073307ffd4ee9  push r11
000073307ffd4eeb  sub rsp, 0xF0
000073307ffd4ef2  vmovaps [rsp], xmm0
000073307ffd4ef7  vmovaps [rsp+0x10], xmm1
000073307ffd4efd  vmovaps [rsp+0x20], xmm2
000073307ffd4f03  vmovaps [rsp+0x30], xmm3
000073307ffd4f09  vmovaps [rsp+0x40], xmm4
000073307ffd4f0f  vmovaps [rsp+0x50], xmm5
000073307ffd4f15  vmovaps [rsp+0x60], xmm6
000073307ffd4f1b  vmovaps [rsp+0x70], xmm8
000073307ffd4f21  vmovaps [rsp+0x80], xmm9
000073307ffd4f2a  vmovaps [rsp+0x90], xmm10
000073307ffd4f33  vmovaps [rsp+0xA0], xmm11
000073307ffd4f3c  vmovaps [rsp+0xB0], xmm12
000073307ffd4f45  vmovaps [rsp+0xC0], xmm13
000073307ffd4f4e  vmovaps [rsp+0xD0], xmm14
000073307ffd4f57  vmovaps [rsp+0xE0], xmm15
000073307ffd4f60  sub rsp, 0x30
000073307ffd4f64  movaps [rsp], xmm7
000073307ffd4f68  movaps [rsp+0x10], xmm15
000073307ffd4f6e  movaps [rsp+0x20], xmm10
000073307ffd4f74  lea rdi, [rsp]
000073307ffd4f78  mov esi, 0x00
000073307ffd4f7d  mov rax, 0x600DE0EC8530
000073307ffd4f87  call rax
000073307ffd4f89  movaps xmm7, [rsp]
000073307ffd4f8d  add rsp, 0x30
000073307ffd4f91  vmovaps xmm0, [rsp]
000073307ffd4f96  vmovaps xmm1, [rsp+0x10]
000073307ffd4f9c  vmovaps xmm2, [rsp+0x20]
000073307ffd4fa2  vmovaps xmm3, [rsp+0x30]
000073307ffd4fa8  vmovaps xmm4, [rsp+0x40]
000073307ffd4fae  vmovaps xmm5, [rsp+0x50]
000073307ffd4fb4  vmovaps xmm6, [rsp+0x60]
000073307ffd4fba  vmovaps xmm8, [rsp+0x70]
000073307ffd4fc0  vmovaps xmm9, [rsp+0x80]
000073307ffd4fc9  vmovaps xmm10, [rsp+0x90]
000073307ffd4fd2  vmovaps xmm11, [rsp+0xA0]
000073307ffd4fdb  vmovaps xmm12, [rsp+0xB0]
000073307ffd4fe4  vmovaps xmm13, [rsp+0xC0]
000073307ffd4fed  vmovaps xmm14, [rsp+0xD0]
000073307ffd4ff6  vmovaps xmm15, [rsp+0xE0]
000073307ffd4fff  add rsp, 0xF0
000073307ffd5006  pop r11
000073307ffd5008  pop r10
000073307ffd500a  pop r9
000073307ffd500c  pop r8
000073307ffd500e  pop rsi
000073307ffd500f  pop rdi
000073307ffd5010  pop rdx
000073307ffd5011  pop rcx
000073307ffd5012  pop rax
000073307ffd5013  add rsp, 0x08
000073307ffd5017  jmp 0x000073307FFD025D
000073307ffd501c  sub rsp, 0x08
000073307ffd5020  push rax
000073307ffd5021  push rcx
000073307ffd5022  push rdx
000073307ffd5023  push rdi
000073307ffd5024  push rsi
000073307ffd5025  push r8
000073307ffd5027  push r9
000073307ffd5029  push r10
000073307ffd502b  push r11
000073307ffd502d  sub rsp, 0xF0
000073307ffd5034  vmovaps [rsp], xmm0
000073307ffd5039  vmovaps [rsp+0x10], xmm1
000073307ffd503f  vmovaps [rsp+0x20], xmm2
000073307ffd5045  vmovaps [rsp+0x30], xmm3
000073307ffd504b  vmovaps [rsp+0x40], xmm4
000073307ffd5051  vmovaps [rsp+0x50], xmm5
000073307ffd5057  vmovaps [rsp+0x60], xmm6
000073307ffd505d  vmovaps [rsp+0x70], xmm7
000073307ffd5063  vmovaps [rsp+0x80], xmm8
000073307ffd506c  vmovaps [rsp+0x90], xmm9
000073307ffd5075  vmovaps [rsp+0xA0], xmm11
000073307ffd507e  vmovaps [rsp+0xB0], xmm12
000073307ffd5087  vmovaps [rsp+0xC0], xmm13
000073307ffd5090  vmovaps [rsp+0xD0], xmm14
000073307ffd5099  vmovaps [rsp+0xE0], xmm15
000073307ffd50a2  sub rsp, 0x30
000073307ffd50a6  movaps [rsp], xmm10
000073307ffd50ab  movaps [rsp+0x10], xmm11
000073307ffd50b1  movaps [rsp+0x20], xmm15
000073307ffd50b7  lea rdi, [rsp]
000073307ffd50bb  mov esi, 0x00
000073307ffd50c0  mov rax, 0x600DE0EC8530
000073307ffd50ca  call rax
000073307ffd50cc  movaps xmm10, [rsp]
000073307ffd50d1  add rsp, 0x30
000073307ffd50d5  vmovaps xmm0, [rsp]
000073307ffd50da  vmovaps xmm1, [rsp+0x10]
000073307ffd50e0  vmovaps xmm2, [rsp+0x20]
000073307ffd50e6  vmovaps xmm3, [rsp+0x30]
000073307ffd50ec  vmovaps xmm4, [rsp+0x40]
000073307ffd50f2  vmovaps xmm5, [rsp+0x50]
000073307ffd50f8  vmovaps xmm6, [rsp+0x60]
000073307ffd50fe  vmovaps xmm7, [rsp+0x70]
000073307ffd5104  vmovaps xmm8, [rsp+0x80]
000073307ffd510d  vmovaps xmm9, [rsp+0x90]
000073307ffd5116  vmovaps xmm11, [rsp+0xA0]
000073307ffd511f  vmovaps xmm12, [rsp+0xB0]
000073307ffd5128  vmovaps xmm13, [rsp+0xC0]
000073307ffd5131  vmovaps xmm14, [rsp+0xD0]
000073307ffd513a  vmovaps xmm15, [rsp+0xE0]
000073307ffd5143  add rsp, 0xF0
000073307ffd514a  pop r11
000073307ffd514c  pop r10
000073307ffd514e  pop r9
000073307ffd5150  pop r8
000073307ffd5152  pop rsi
000073307ffd5153  pop rdi
000073307ffd5154  pop rdx
000073307ffd5155  pop rcx
000073307ffd5156  pop rax
000073307ffd5157  add rsp, 0x08
000073307ffd515b  jmp 0x000073307FFD028B
000073307ffd5160  sub rsp, 0x08
000073307ffd5164  push rax
000073307ffd5165  push rcx
000073307ffd5166  push rdx
000073307ffd5167  push rdi
000073307ffd5168  push rsi
000073307ffd5169  push r8
000073307ffd516b  push r9
000073307ffd516d  push r10
000073307ffd516f  push r11
000073307ffd5171  sub rsp, 0xF0
000073307ffd5178  vmovaps [rsp], xmm0
000073307ffd517d  vmovaps [rsp+0x10], xmm1
000073307ffd5183  vmovaps [rsp+0x20], xmm2
000073307ffd5189  vmovaps [rsp+0x30], xmm3
000073307ffd518f  vmovaps [rsp+0x40], xmm4
000073307ffd5195  vmovaps [rsp+0x50], xmm5
000073307ffd519b  vmovaps [rsp+0x60], xmm6
000073307ffd51a1  vmovaps [rsp+0x70], xmm7
000073307ffd51a7  vmovaps [rsp+0x80], xmm8
000073307ffd51b0  vmovaps [rsp+0x90], xmm9
000073307ffd51b9  vmovaps [rsp+0xA0], xmm10
000073307ffd51c2  vmovaps [rsp+0xB0], xmm12
000073307ffd51cb  vmovaps [rsp+0xC0], xmm13
000073307ffd51d4  vmovaps [rsp+0xD0], xmm14
000073307ffd51dd  vmovaps [rsp+0xE0], xmm15
000073307ffd51e6  sub rsp, 0x30
000073307ffd51ea  movaps [rsp], xmm11
000073307ffd51ef  movaps [rsp+0x10], xmm12
000073307ffd51f5  movaps [rsp+0x20], xmm15
000073307ffd51fb  lea rdi, [rsp]
000073307ffd51ff  mov esi, 0x00
000073307ffd5204  mov rax, 0x600DE0EC8530
000073307ffd520e  call rax
000073307ffd5210  movaps xmm11, [rsp]
000073307ffd5215  add rsp, 0x30
000073307ffd5219  vmovaps xmm0, [rsp]
000073307ffd521e  vmovaps xmm1, [rsp+0x10]
000073307ffd5224  vmovaps xmm2, [rsp+0x20]
000073307ffd522a  vmovaps xmm3, [rsp+0x30]
000073307ffd5230  vmovaps xmm4, [rsp+0x40]
000073307ffd5236  vmovaps xmm5, [rsp+0x50]
000073307ffd523c  vmovaps xmm6, [rsp+0x60]
000073307ffd5242  vmovaps xmm7, [rsp+0x70]
000073307ffd5248  vmovaps xmm8, [rsp+0x80]
000073307ffd5251  vmovaps xmm9, [rsp+0x90]
000073307ffd525a  vmovaps xmm10, [rsp+0xA0]
000073307ffd5263  vmovaps xmm12, [rsp+0xB0]
000073307ffd526c  vmovaps xmm13, [rsp+0xC0]
000073307ffd5275  vmovaps xmm14, [rsp+0xD0]
000073307ffd527e  vmovaps xmm15, [rsp+0xE0]
000073307ffd5287  add rsp, 0xF0
000073307ffd528e  pop r11
000073307ffd5290  pop r10
000073307ffd5292  pop r9
000073307ffd5294  pop r8
000073307ffd5296  pop rsi
000073307ffd5297  pop rdi
000073307ffd5298  pop rdx
000073307ffd5299  pop rcx
000073307ffd529a  pop rax
000073307ffd529b  add rsp, 0x08
000073307ffd529f  jmp 0x000073307FFD02B9
000073307ffd52a4  sub rsp, 0x08
000073307ffd52a8  push rax
000073307ffd52a9  push rcx
000073307ffd52aa  push rdx
000073307ffd52ab  push rdi
000073307ffd52ac  push rsi
000073307ffd52ad  push r8
000073307ffd52af  push r9
000073307ffd52b1  push r10
000073307ffd52b3  push r11
000073307ffd52b5  sub rsp, 0xF0
000073307ffd52bc  vmovaps [rsp], xmm0
000073307ffd52c1  vmovaps [rsp+0x10], xmm1
000073307ffd52c7  vmovaps [rsp+0x20], xmm2
000073307ffd52cd  vmovaps [rsp+0x30], xmm3
000073307ffd52d3  vmovaps [rsp+0x40], xmm4
000073307ffd52d9  vmovaps [rsp+0x50], xmm5
000073307ffd52df  vmovaps [rsp+0x60], xmm6
000073307ffd52e5  vmovaps [rsp+0x70], xmm7
000073307ffd52eb  vmovaps [rsp+0x80], xmm8
000073307ffd52f4  vmovaps [rsp+0x90], xmm9
000073307ffd52fd  vmovaps [rsp+0xA0], xmm10
000073307ffd5306  vmovaps [rsp+0xB0], xmm11
000073307ffd530f  vmovaps [rsp+0xC0], xmm12
000073307ffd5318  vmovaps [rsp+0xD0], xmm13
000073307ffd5321  vmovaps [rsp+0xE0], xmm14
000073307ffd532a  sub rsp, 0x30
000073307ffd532e  movaps [rsp], xmm15
000073307ffd5333  movaps [rsp+0x10], xmm13
000073307ffd5339  movaps [rsp+0x20], xmm9
000073307ffd533f  lea rdi, [rsp]
000073307ffd5343  mov esi, 0x00
000073307ffd5348  mov rax, 0x600DE0EC8530
000073307ffd5352  call rax
000073307ffd5354  movaps xmm15, [rsp]
000073307ffd5359  add rsp, 0x30
000073307ffd535d  vmovaps xmm0, [rsp]
000073307ffd5362  vmovaps xmm1, [rsp+0x10]
000073307ffd5368  vmovaps xmm2, [rsp+0x20]
000073307ffd536e  vmovaps xmm3, [rsp+0x30]
000073307ffd5374  vmovaps xmm4, [rsp+0x40]
000073307ffd537a  vmovaps xmm5, [rsp+0x50]
000073307ffd5380  vmovaps xmm6, [rsp+0x60]
000073307ffd5386  vmovaps xmm7, [rsp+0x70]
000073307ffd538c  vmovaps xmm8, [rsp+0x80]
000073307ffd5395  vmovaps xmm9, [rsp+0x90]
000073307ffd539e  vmovaps xmm10, [rsp+0xA0]
000073307ffd53a7  vmovaps xmm11, [rsp+0xB0]
000073307ffd53b0  vmovaps xmm12, [rsp+0xC0]
000073307ffd53b9  vmovaps xmm13, [rsp+0xD0]
000073307ffd53c2  vmovaps xmm14, [rsp+0xE0]
000073307ffd53cb  add rsp, 0xF0
000073307ffd53d2  pop r11
000073307ffd53d4  pop r10
000073307ffd53d6  pop r9
000073307ffd53d8  pop r8
000073307ffd53da  pop rsi
000073307ffd53db  pop rdi
000073307ffd53dc  pop rdx
000073307ffd53dd  pop rcx
000073307ffd53de  pop rax
000073307ffd53df  add rsp, 0x08
000073307ffd53e3  jmp 0x000073307FFD02D4
000073307ffd53e8  sub rsp, 0x08
000073307ffd53ec  push rax
000073307ffd53ed  push rcx
000073307ffd53ee  push rdx
000073307ffd53ef  push rdi
000073307ffd53f0  push rsi
000073307ffd53f1  push r8
000073307ffd53f3  push r9
000073307ffd53f5  push r10
000073307ffd53f7  push r11
000073307ffd53f9  sub rsp, 0xF0
000073307ffd5400  vmovaps [rsp], xmm0
000073307ffd5405  vmovaps [rsp+0x10], xmm1
000073307ffd540b  vmovaps [rsp+0x20], xmm2
000073307ffd5411  vmovaps [rsp+0x30], xmm3
000073307ffd5417  vmovaps [rsp+0x40], xmm4
000073307ffd541d  vmovaps [rsp+0x50], xmm5
000073307ffd5423  vmovaps [rsp+0x60], xmm6
000073307ffd5429  vmovaps [rsp+0x70], xmm7
000073307ffd542f  vmovaps [rsp+0x80], xmm8
000073307ffd5438  vmovaps [rsp+0x90], xmm9
000073307ffd5441  vmovaps [rsp+0xA0], xmm10
000073307ffd544a  vmovaps [rsp+0xB0], xmm11
000073307ffd5453  vmovaps [rsp+0xC0], xmm12
000073307ffd545c  vmovaps [rsp+0xD0], xmm14
000073307ffd5465  vmovaps [rsp+0xE0], xmm15
000073307ffd546e  sub rsp, 0x30
000073307ffd5472  movaps [rsp], xmm13
000073307ffd5477  movaps [rsp+0x10], xmm8
000073307ffd547d  movaps [rsp+0x20], xmm14
000073307ffd5483  lea rdi, [rsp]
000073307ffd5487  mov esi, 0x00
000073307ffd548c  mov rax, 0x600DE0EC8530
000073307ffd5496  call rax
000073307ffd5498  movaps xmm13, [rsp]
000073307ffd549d  add rsp, 0x30
000073307ffd54a1  vmovaps xmm0, [rsp]
000073307ffd54a6  vmovaps xmm1, [rsp+0x10]
000073307ffd54ac  vmovaps xmm2, [rsp+0x20]
000073307ffd54b2  vmovaps xmm3, [rsp+0x30]
000073307ffd54b8  vmovaps xmm4, [rsp+0x40]
000073307ffd54be  vmovaps xmm5, [rsp+0x50]
000073307ffd54c4  vmovaps xmm6, [rsp+0x60]
000073307ffd54ca  vmovaps xmm7, [rsp+0x70]
000073307ffd54d0  vmovaps xmm8, [rsp+0x80]
000073307ffd54d9  vmovaps xmm9, [rsp+0x90]
000073307ffd54e2  vmovaps xmm10, [rsp+0xA0]
000073307ffd54eb  vmovaps xmm11, [rsp+0xB0]
000073307ffd54f4  vmovaps xmm12, [rsp+0xC0]
000073307ffd54fd  vmovaps xmm14, [rsp+0xD0]
000073307ffd5506  vmovaps xmm15, [rsp+0xE0]
000073307ffd550f  add rsp, 0xF0
000073307ffd5516  pop r11
000073307ffd5518  pop r10
000073307ffd551a  pop r9
000073307ffd551c  pop r8
000073307ffd551e  pop rsi
000073307ffd551f  pop rdi
000073307ffd5520  pop rdx
000073307ffd5521  pop rcx
000073307ffd5522  pop rax
000073307ffd5523  add rsp, 0x08
000073307ffd5527  jmp 0x000073307FFD02F7
000073307ffd552c  sub rsp, 0x08
000073307ffd5530  push rax
000073307ffd5531  push rcx
000073307ffd5532  push rdx
000073307ffd5533  push rdi
000073307ffd5534  push rsi
000073307ffd5535  push r8
000073307ffd5537  push r9
000073307ffd5539  push r10
000073307ffd553b  push r11
000073307ffd553d  sub rsp, 0xF0
000073307ffd5544  vmovaps [rsp], xmm0
000073307ffd5549  vmovaps [rsp+0x10], xmm1
000073307ffd554f  vmovaps [rsp+0x20], xmm2
000073307ffd5555  vmovaps [rsp+0x30], xmm3
000073307ffd555b  vmovaps [rsp+0x40], xmm4
000073307ffd5561  vmovaps [rsp+0x50], xmm5
000073307ffd5567  vmovaps [rsp+0x60], xmm6
000073307ffd556d  vmovaps [rsp+0x70], xmm7
000073307ffd5573  vmovaps [rsp+0x80], xmm8
000073307ffd557c  vmovaps [rsp+0x90], xmm9
000073307ffd5585  vmovaps [rsp+0xA0], xmm10
000073307ffd558e  vmovaps [rsp+0xB0], xmm11
000073307ffd5597  vmovaps [rsp+0xC0], xmm12
000073307ffd55a0  vmovaps [rsp+0xD0], xmm13
000073307ffd55a9  vmovaps [rsp+0xE0], xmm15
000073307ffd55b2  sub rsp, 0x30
000073307ffd55b6  movaps [rsp], xmm14
000073307ffd55bb  movaps [rsp+0x10], xmm1
000073307ffd55c0  movaps [rsp+0x20], xmm10
000073307ffd55c6  lea rdi, [rsp]
000073307ffd55ca  mov esi, 0x00
000073307ffd55cf  mov rax, 0x600DE0EC8530
000073307ffd55d9  call rax
000073307ffd55db  movaps xmm14, [rsp]
000073307ffd55e0  add rsp, 0x30
000073307ffd55e4  vmovaps xmm0, [rsp]
000073307ffd55e9  vmovaps xmm1, [rsp+0x10]
000073307ffd55ef  vmovaps xmm2, [rsp+0x20]
000073307ffd55f5  vmovaps xmm3, [rsp+0x30]
000073307ffd55fb  vmovaps xmm4, [rsp+0x40]
000073307ffd5601  vmovaps xmm5, [rsp+0x50]
000073307ffd5607  vmovaps xmm6, [rsp+0x60]
000073307ffd560d  vmovaps xmm7, [rsp+0x70]
000073307ffd5613  vmovaps xmm8, [rsp+0x80]
000073307ffd561c  vmovaps xmm9, [rsp+0x90]
000073307ffd5625  vmovaps xmm10, [rsp+0xA0]
000073307ffd562e  vmovaps xmm11, [rsp+0xB0]
000073307ffd5637  vmovaps xmm12, [rsp+0xC0]
000073307ffd5640  vmovaps xmm13, [rsp+0xD0]
000073307ffd5649  vmovaps xmm15, [rsp+0xE0]
000073307ffd5652  add rsp, 0xF0
000073307ffd5659  pop r11
000073307ffd565b  pop r10
000073307ffd565d  pop r9
000073307ffd565f  pop r8
000073307ffd5661  pop rsi
000073307ffd5662  pop rdi
000073307ffd5663  pop rdx
000073307ffd5664  pop rcx
000073307ffd5665  pop rax
000073307ffd5666  add rsp, 0x08
000073307ffd566a  jmp 0x000073307FFD031A
000073307ffd566f  sub rsp, 0x08
000073307ffd5673  push rax
000073307ffd5674  push rcx
000073307ffd5675  push rdx
000073307ffd5676  push rdi
000073307ffd5677  push rsi
000073307ffd5678  push r8
000073307ffd567a  push r9
000073307ffd567c  push r10
000073307ffd567e  push r11
000073307ffd5680  sub rsp, 0xF0
000073307ffd5687  vmovaps [rsp], xmm0
000073307ffd568c  vmovaps [rsp+0x10], xmm2
000073307ffd5692  vmovaps [rsp+0x20], xmm3
000073307ffd5698  vmovaps [rsp+0x30], xmm4
000073307ffd569e  vmovaps [rsp+0x40], xmm5
000073307ffd56a4  vmovaps [rsp+0x50], xmm6
000073307ffd56aa  vmovaps [rsp+0x60], xmm7
000073307ffd56b0  vmovaps [rsp+0x70], xmm8
000073307ffd56b6  vmovaps [rsp+0x80], xmm9
000073307ffd56bf  vmovaps [rsp+0x90], xmm10
000073307ffd56c8  vmovaps [rsp+0xA0], xmm11
000073307ffd56d1  vmovaps [rsp+0xB0], xmm12
000073307ffd56da  vmovaps [rsp+0xC0], xmm13
000073307ffd56e3  vmovaps [rsp+0xD0], xmm14
000073307ffd56ec  vmovaps [rsp+0xE0], xmm15
000073307ffd56f5  sub rsp, 0x30
000073307ffd56f9  movaps [rsp], xmm1
000073307ffd56fd  movaps [rsp+0x10], xmm7
000073307ffd5702  movaps [rsp+0x20], xmm11
000073307ffd5708  lea rdi, [rsp]
000073307ffd570c  mov esi, 0x00
000073307ffd5711  mov rax, 0x600DE0EC8530
000073307ffd571b  call rax
000073307ffd571d  movaps xmm1, [rsp]
000073307ffd5721  add rsp, 0x30
000073307ffd5725  vmovaps xmm0, [rsp]
000073307ffd572a  vmovaps xmm2, [rsp+0x10]
000073307ffd5730  vmovaps xmm3, [rsp+0x20]
000073307ffd5736  vmovaps xmm4, [rsp+0x30]
000073307ffd573c  vmovaps xmm5, [rsp+0x40]
000073307ffd5742  vmovaps xmm6, [rsp+0x50]
000073307ffd5748  vmovaps xmm7, [rsp+0x60]
000073307ffd574e  vmovaps xmm8, [rsp+0x70]
000073307ffd5754  vmovaps xmm9, [rsp+0x80]
000073307ffd575d  vmovaps xmm10, [rsp+0x90]
000073307ffd5766  vmovaps xmm11, [rsp+0xA0]
000073307ffd576f  vmovaps xmm12, [rsp+0xB0]
000073307ffd5778  vmovaps xmm13, [rsp+0xC0]
000073307ffd5781  vmovaps xmm14, [rsp+0xD0]
000073307ffd578a  vmovaps xmm15, [rsp+0xE0]
000073307ffd5793  add rsp, 0xF0
000073307ffd579a  pop r11
000073307ffd579c  pop r10
000073307ffd579e  pop r9
000073307ffd57a0  pop r8
000073307ffd57a2  pop rsi
000073307ffd57a3  pop rdi
000073307ffd57a4  pop rdx
000073307ffd57a5  pop rcx
000073307ffd57a6  pop rax
000073307ffd57a7  add rsp, 0x08
000073307ffd57ab  jmp 0x000073307FFD033B
000073307ffd57b0  call 0x000073307FE0E880
000073307ffd57b5  jmp 0x000073307FFD034E
000073307ffd57ba  call 0x000073307FE0C380
000073307ffd57bf  jmp 0x000073307FFD0359
000073307ffd57c4  call 0x000073307FE0D600
000073307ffd57c9  jmp 0x000073307FFD0364
000073307ffd57ce  call 0x000073307FDFF540
000073307ffd57d3  jmp 0x000073307FFD036F
000073307ffd57d8  int3
000073307ffd57d9  nop [rax], eax
000073307ffd57e0  mov rax, [r15+0x40]
000073307ffd57e4  mov r14, [r15+0x58]
000073307ffd57e8  lea r12, [rax+r14*1]
000073307ffd57ec  movaps xmm1, [r15+0x1D0]
000073307ffd57f4  vmovaps [rsp+0x10], xmm1
000073307ffd57fa  vmovaps xmm15, [rsp+0x10]
000073307ffd5800  por xmm1, xmm15
000073307ffd5805  movaps xmm14, [r15+0x1A0]
000073307ffd580d  vmovaps [rsp+0x10], xmm14
000073307ffd5813  vmovaps xmm13, [rsp+0x10]
000073307ffd5819  por xmm14, xmm13
000073307ffd581e  lea rax, [r12+0x30]
000073307ffd5823  mov r11, [r13+rax*1]
000073307ffd5828  lea rax, [r12+0x38]
000073307ffd582d  mov r10, [r13+rax*1]
000073307ffd5832  movq xmm13, r11
000073307ffd5837  movq xmm12, r10
000073307ffd583c  movq xmm13, xmm13
000073307ffd5841  vmovaps [rsp+0x10], xmm13
000073307ffd5847  movq xmm13, xmm13
000073307ffd584c  movaps [r15+0x130], xmm13
000073307ffd5854  movq xmm12, xmm12
000073307ffd5859  vmovaps [rsp+0x20], xmm12
000073307ffd585f  movq xmm12, xmm12
000073307ffd5864  movaps [r15+0x280], xmm12
000073307ffd586c  movaps xmm13, [r15+0x270]
000073307ffd5874  vmovaps [rsp+0x30], xmm13
000073307ffd587a  vmovaps xmm12, [rsp+0x30]
000073307ffd5880  por xmm13, xmm12
000073307ffd5885  lea rax, [r12+0x20]
000073307ffd588a  mov r11, [r13+rax*1]
000073307ffd588f  lea rax, [r12+0x28]
000073307ffd5894  mov r10, [r13+rax*1]
000073307ffd5899  movq xmm12, r11
000073307ffd589e  movq xmm11, r10
000073307ffd58a3  movq xmm12, xmm12
000073307ffd58a8  vmovaps [rsp+0x30], xmm12
000073307ffd58ae  movq xmm12, xmm12
000073307ffd58b3  movaps [r15+0x150], xmm12
000073307ffd58bb  movq xmm11, xmm11
000073307ffd58c0  vmovaps [rsp+0x40], xmm11
000073307ffd58c6  movq xmm11, xmm11
000073307ffd58cb  movaps [r15+0x140], xmm11
000073307ffd58d3  lea rax, [r12+0x10]
000073307ffd58d8  mov r11, [r13+rax*1]
000073307ffd58dd  lea rax, [r12+0x18]
000073307ffd58e2  mov r10, [r13+rax*1]
000073307ffd58e7  movq xmm12, r11
000073307ffd58ec  movq xmm11, r10
000073307ffd58f1  movq xmm12, xmm12
000073307ffd58f6  vmovaps [rsp+0x50], xmm12
000073307ffd58fc  movq xmm12, xmm12
000073307ffd5901  movaps [r15+0x170], xmm12
000073307ffd5909  movq xmm11, xmm11
000073307ffd590e  vmovaps [rsp+0x60], xmm11
000073307ffd5914  movq xmm11, xmm11
000073307ffd5919  movaps [r15+0x160], xmm11
000073307ffd5921  mov rax, [r13+r12*1]
000073307ffd5926  vmovq xmm12, rax
000073307ffd592b  vpbroadcastq xmm12, xmm12
000073307ffd5930  lea rax, [r12+0x08]
000073307ffd5935  mov r12, [r13+rax*1]
000073307ffd593a  movq xmm11, r12
000073307ffd593f  movaps [r15+0x230], xmm11
000073307ffd5947  mov rax, [r15+0xF8]
000073307ffd594e  lea r12, [rax+0x50]
000073307ffd5952  movups xmm11, [r13+r12*1]
000073307ffd5958  lea r12, [rax+0x60]
000073307ffd595c  movups xmm10, [r13+r12*1]
000073307ffd5962  lea r12, [rax+0x30]
000073307ffd5966  movups xmm9, [r13+r12*1]
000073307ffd596c  mov r12, [r15+0x50]
000073307ffd5970  lea r11, [r12+r14*1]
000073307ffd5974  mov [r15+0x60], r11
000073307ffd5978  lea r12, [r14+0x40]
000073307ffd597c  mov [r15+0x58], r12
000073307ffd5980  movaps xmm8, xmm12
000073307ffd5984  mulpd xmm8, xmm15
000073307ffd5989  vcmppd xmm7, xmm8, xmm8, 0x03
000073307ffd598f  ptest xmm7, xmm7
000073307ffd5994  jnz 0x000073307FFD67B7
000073307ffd599a  movq xmm15, qword ptr [r15+0x230]
000073307ffd59a3  vmovaps [rsp+0x70], xmm15
000073307ffd59a9  vpermilpd xmm15, xmm15, 0x00
000073307ffd59af  movaps xmm7, xmm9
000073307ffd59b3  mulpd xmm7, xmm15
000073307ffd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
000073307ffd59bd  ptest xmm6, xmm6
000073307ffd59c2  jnz 0x000073307FFD68FB
000073307ffd59c8  vxorps xmm15, xmm15, xmm15
000073307ffd59cd  vpbroadcastq xmm15, xmm15
000073307ffd59d2  movaps xmm9, xmm12
000073307ffd59d6  mulpd xmm9, xmm10
000073307ffd59db  vcmppd xmm6, xmm9, xmm9, 0x03
000073307ffd59e1  ptest xmm6, xmm6
000073307ffd59e6  jnz 0x000073307FFD6A3D
000073307ffd59ec  movaps xmm10, xmm12
000073307ffd59f0  mulpd xmm10, xmm11
000073307ffd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
000073307ffd59fb  ptest xmm6, xmm6
000073307ffd5a00  jnz 0x000073307FFD6B81
000073307ffd5a06  movaps xmm11, [r15+0x1F0]
000073307ffd5a0e  movaps xmm6, xmm12
000073307ffd5a12  mulpd xmm6, xmm11
000073307ffd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
000073307ffd5a1c  ptest xmm5, xmm5
000073307ffd5a21  jnz 0x000073307FFD6CC5
000073307ffd5a27  movaps xmm12, [r15+0x2A0]
000073307ffd5a2f  vmovaps [rsp+0x80], xmm12
000073307ffd5a38  vmovaps xmm11, [rsp+0x80]
000073307ffd5a41  por xmm12, xmm11
000073307ffd5a46  movaps xmm11, [r15+0x250]
000073307ffd5a4e  vmovaps [rsp+0x80], xmm11
000073307ffd5a57  vmovaps xmm5, [rsp+0x80]
000073307ffd5a60  por xmm11, xmm5
000073307ffd5a65  vmovaps xmm4, [rsp+0x70]
000073307ffd5a6b  vpermilpd xmm4, xmm4, 0x00
000073307ffd5a71  movaps xmm3, xmm5
000073307ffd5a74  mulpd xmm3, xmm4
000073307ffd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
000073307ffd5a7d  ptest xmm2, xmm2
000073307ffd5a82  jnz 0x000073307FFD6E07
000073307ffd5a88  mov [rsp+0x80], rax
000073307ffd5a90  xor eax, eax
000073307ffd5a92  mov r14d, 0x200
000073307ffd5a98  cmp r12, r14
000073307ffd5a9b  cmc
000073307ffd5a9c  lahf
000073307ffd5a9d  seto al
000073307ffd5aa0  mov [r15+0x108], eax
000073307ffd5aa7  movaps xmm5, xmm8
000073307ffd5aab  addpd xmm5, xmm15
000073307ffd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
000073307ffd5ab5  ptest xmm4, xmm4
000073307ffd5aba  jnz 0x000073307FFD6F47
000073307ffd5ac0  movaps xmm8, [r15+0x1B0]
000073307ffd5ac8  movaps xmm4, xmm9
000073307ffd5acc  addpd xmm4, xmm8
000073307ffd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
000073307ffd5ad6  ptest xmm2, xmm2
000073307ffd5adb  jnz 0x000073307FFD7089
000073307ffd5ae1  movaps xmm9, xmm10
000073307ffd5ae5  addpd xmm9, xmm8
000073307ffd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
000073307ffd5af0  ptest xmm2, xmm2
000073307ffd5af5  jnz 0x000073307FFD71CB
000073307ffd5afb  movaps xmm10, [r15+0x2F0]
000073307ffd5b03  vmovaps [rsp+0x90], xmm10
000073307ffd5b0c  vmovaps xmm8, [rsp+0x90]
000073307ffd5b15  por xmm10, xmm8
000073307ffd5b1a  movaps xmm8, [r15+0x2E0]
000073307ffd5b22  vmovaps [rsp+0x90], xmm8
000073307ffd5b2b  vmovaps xmm2, [rsp+0x90]
000073307ffd5b34  por xmm8, xmm2
000073307ffd5b39  movaps xmm2, [r15+0x2D0]
000073307ffd5b41  vmovaps [rsp+0x90], xmm2
000073307ffd5b4a  vmovaps [rsp+0xA0], xmm1
000073307ffd5b53  vmovaps xmm1, [rsp+0x90]
000073307ffd5b5c  por xmm2, xmm1
000073307ffd5b60  movaps xmm1, [r15+0x200]
000073307ffd5b68  vmovaps [rsp+0x90], xmm1
000073307ffd5b71  vmovaps [rsp+0xB0], xmm15
000073307ffd5b7a  vmovaps xmm15, [rsp+0x90]
000073307ffd5b83  por xmm1, xmm15
000073307ffd5b88  movaps xmm15, [r15+0x1C0]
000073307ffd5b90  vmovaps [rsp+0x90], xmm15
000073307ffd5b99  vmovaps [rsp+0xC0], xmm1
000073307ffd5ba2  vmovaps xmm1, [rsp+0x90]
000073307ffd5bab  por xmm15, xmm1
000073307ffd5bb0  movaps xmm1, [r15+0x190]
000073307ffd5bb8  vmovaps [rsp+0x90], xmm1
000073307ffd5bc1  vmovaps [rsp+0xD0], xmm15
000073307ffd5bca  vmovaps xmm15, [rsp+0x90]
000073307ffd5bd3  por xmm1, xmm15
000073307ffd5bd8  movaps xmm15, [r15+0x300]
000073307ffd5be0  vmovaps [rsp+0x90], xmm15
000073307ffd5be9  vmovaps [rsp+0xE0], xmm1
000073307ffd5bf2  vmovaps xmm1, [rsp+0x90]
000073307ffd5bfb  por xmm15, xmm1
000073307ffd5c00  mov rax, [rsp+0x80]
000073307ffd5c08  lea r14, [rax+0xA0]
000073307ffd5c0f  movups xmm1, [r13+r14*1]
000073307ffd5c15  lea r14, [rax+0xB0]
000073307ffd5c1c  vmovaps [rsp+0x80], xmm1
000073307ffd5c25  movups xmm1, [r13+r14*1]
000073307ffd5c2b  vmovaps [rsp+0x90], xmm1
000073307ffd5c34  vmovaps [rsp+0xF0], xmm15
000073307ffd5c3d  vmovaps xmm15, [rsp+0xB0]
000073307ffd5c46  vmovaps [rsp+0xB0], xmm14
000073307ffd5c4f  movaps xmm1, xmm6
000073307ffd5c52  addpd xmm1, xmm15
000073307ffd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
000073307ffd5c5c  ptest xmm14, xmm14
000073307ffd5c62  jnz 0x000073307FFD7323
000073307ffd5c68  lea r14, [rax+0xF0]
000073307ffd5c6f  movups xmm15, [r13+r14*1]
000073307ffd5c75  movaps xmm14, xmm4
000073307ffd5c79  addpd xmm14, xmm3
000073307ffd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
000073307ffd5c84  ptest xmm6, xmm6
000073307ffd5c89  jnz 0x000073307FFD746E
000073307ffd5c8f  movaps xmm6, xmm9
000073307ffd5c93  addpd xmm6, xmm7
000073307ffd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
000073307ffd5c9c  ptest xmm4, xmm4
000073307ffd5ca1  jnz 0x000073307FFD75B0
000073307ffd5ca7  vmovaps xmm9, [rsp+0x70]
000073307ffd5cad  vpermilpd xmm9, xmm9, 0x00
000073307ffd5cb3  vmovaps xmm4, [rsp+0x90]
000073307ffd5cbc  movaps xmm7, xmm4
000073307ffd5cbf  mulpd xmm7, xmm9
000073307ffd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
000073307ffd5cc9  ptest xmm3, xmm3
000073307ffd5cce  jnz 0x000073307FFD76F1
000073307ffd5cd4  vmovaps xmm9, [rsp+0x50]
000073307ffd5cda  vpermilpd xmm9, xmm9, 0x00
000073307ffd5ce0  movaps xmm4, xmm15
000073307ffd5ce4  mulpd xmm4, xmm9
000073307ffd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
000073307ffd5cee  ptest xmm3, xmm3
000073307ffd5cf3  jnz 0x000073307FFD7832
000073307ffd5cf9  lea r14, [rax+0xE0]
000073307ffd5d00  movups xmm15, [r13+r14*1]
000073307ffd5d06  vmovaps xmm9, [rsp+0x70]
000073307ffd5d0c  vpermilpd xmm9, xmm9, 0x00
000073307ffd5d12  vmovaps [rsp+0x70], xmm1
000073307ffd5d18  vmovaps xmm1, [rsp+0x80]
000073307ffd5d21  vmovaps [rsp+0x80], xmm15
000073307ffd5d2a  movaps xmm3, xmm1
000073307ffd5d2d  mulpd xmm3, xmm9
000073307ffd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
000073307ffd5d37  ptest xmm15, xmm15
000073307ffd5d3d  jnz 0x000073307FFD797E
000073307ffd5d43  vmovaps xmm1, [rsp+0xF0]
000073307ffd5d4c  vmovaps xmm15, [rsp+0xF0]
000073307ffd5d55  por xmm1, xmm15
000073307ffd5d5a  movaps [r15+0x300], xmm1
000073307ffd5d62  vmovaps xmm15, [rsp+0xE0]
000073307ffd5d6b  vmovaps xmm9, [rsp+0xE0]
000073307ffd5d74  por xmm15, xmm9
000073307ffd5d79  movaps [r15+0x190], xmm15
000073307ffd5d81  vmovaps xmm9, [rsp+0x50]
000073307ffd5d87  vpermilpd xmm9, xmm9, 0x00
000073307ffd5d8d  vmovaps [rsp+0x90], xmm1
000073307ffd5d96  vmovaps [rsp+0xE0], xmm15
000073307ffd5d9f  vmovaps xmm15, [rsp+0x80]
000073307ffd5da8  vmovaps [rsp+0x80], xmm14
000073307ffd5db1  movaps xmm1, xmm15
000073307ffd5db5  mulpd xmm1, xmm9
000073307ffd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
000073307ffd5dbf  ptest xmm14, xmm14
000073307ffd5dc5  jnz 0x000073307FFD7ABF
000073307ffd5dcb  lea r14, [rax+0x90]
000073307ffd5dd2  movups xmm15, [r13+r14*1]
000073307ffd5dd8  vmovaps xmm14, [rsp+0xD0]
000073307ffd5de1  vmovaps xmm9, [rsp+0xD0]
000073307ffd5dea  por xmm14, xmm9
000073307ffd5def  movaps [r15+0x1C0], xmm14
000073307ffd5df7  vmovaps xmm9, [rsp+0xC0]
000073307ffd5e00  vmovaps [rsp+0xD0], xmm1
000073307ffd5e09  vmovaps xmm1, [rsp+0xC0]
000073307ffd5e12  por xmm9, xmm1
000073307ffd5e17  movaps [r15+0x200], xmm9
000073307ffd5e1f  vmovaps [rsp+0xC0], xmm2
000073307ffd5e28  vmovaps xmm1, [rsp+0xC0]
000073307ffd5e31  por xmm2, xmm1
000073307ffd5e35  movaps [r15+0x2D0], xmm2
000073307ffd5e3d  vmovaps [rsp+0xC0], xmm8
000073307ffd5e46  vmovaps xmm1, [rsp+0xC0]
000073307ffd5e4f  por xmm8, xmm1
000073307ffd5e54  movaps [r15+0x2E0], xmm8
000073307ffd5e5c  vmovaps [rsp+0xC0], xmm15
000073307ffd5e65  movaps xmm1, xmm5
000073307ffd5e68  addpd xmm1, xmm7
000073307ffd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
000073307ffd5e71  ptest xmm15, xmm15
000073307ffd5e77  jnz 0x000073307FFD7C0B
000073307ffd5e7d  vmovaps xmm15, [rsp+0x50]
000073307ffd5e83  vpermilpd xmm15, xmm15, 0x00
000073307ffd5e89  vmovaps xmm5, [rsp+0xC0]
000073307ffd5e92  vmovaps [rsp+0xC0], xmm1
000073307ffd5e9b  movaps xmm7, xmm5
000073307ffd5e9e  mulpd xmm7, xmm15
000073307ffd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
000073307ffd5ea8  ptest xmm1, xmm1
000073307ffd5ead  jnz 0x000073307FFD7D4B
000073307ffd5eb3  lea r14, [rax+0x80]
000073307ffd5eba  movups xmm1, [r13+r14*1]
000073307ffd5ec0  vmovaps xmm5, [rsp+0x70]
000073307ffd5ec6  vmovaps [rsp+0x70], xmm1
000073307ffd5ecc  movaps xmm15, xmm5
000073307ffd5ed0  addpd xmm15, xmm3
000073307ffd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
000073307ffd5edb  ptest xmm1, xmm1
000073307ffd5ee0  jnz 0x000073307FFD7E96
000073307ffd5ee6  vmovaps xmm5, [rsp+0x80]
000073307ffd5eef  movaps xmm1, xmm5
000073307ffd5ef2  addpd xmm1, xmm4
000073307ffd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
000073307ffd5efb  ptest xmm3, xmm3
000073307ffd5f00  jnz 0x000073307FFD7FD8
000073307ffd5f06  vmovaps [rsp+0x80], xmm10
000073307ffd5f0f  vmovaps xmm5, [rsp+0x80]
000073307ffd5f18  por xmm10, xmm5
000073307ffd5f1d  movaps [r15+0x2F0], xmm10
000073307ffd5f25  vmovaps xmm5, [rsp+0x50]
000073307ffd5f2b  vpermilpd xmm5, xmm5, 0x00
000073307ffd5f31  vmovaps xmm3, [rsp+0x70]
000073307ffd5f37  vmovaps [rsp+0x50], xmm1
000073307ffd5f3d  movaps xmm4, xmm3
000073307ffd5f40  mulpd xmm4, xmm5
000073307ffd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
000073307ffd5f49  ptest xmm1, xmm1
000073307ffd5f4e  jnz 0x000073307FFD8118
000073307ffd5f54  lea r14, [rax+0xD0]
000073307ffd5f5b  movups xmm1, [r13+r14*1]
000073307ffd5f61  vmovaps xmm3, [rsp+0xD0]
000073307ffd5f6a  vmovaps [rsp+0x70], xmm1
000073307ffd5f70  movaps xmm5, xmm6
000073307ffd5f73  addpd xmm5, xmm3
000073307ffd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
000073307ffd5f7c  ptest xmm1, xmm1
000073307ffd5f81  jnz 0x000073307FFD8262
000073307ffd5f87  vmovaps xmm1, [rsp+0x60]
000073307ffd5f8d  vpermilpd xmm1, xmm1, 0x00
000073307ffd5f93  movaps xmm6, xmm9
000073307ffd5f97  mulpd xmm6, xmm1
000073307ffd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
000073307ffd5fa0  ptest xmm3, xmm3
000073307ffd5fa5  jnz 0x000073307FFD83A2
000073307ffd5fab  movaps [r15+0x260], xmm6
000073307ffd5fb3  vxorps xmm1, xmm1, xmm1
000073307ffd5fb7  vpbroadcastq xmm1, xmm1
000073307ffd5fbc  movaps [r15+0x1B0], xmm1
000073307ffd5fc4  vmovaps xmm1, [rsp+0x60]
000073307ffd5fca  vpermilpd xmm1, xmm1, 0x00
000073307ffd5fd0  vmovaps xmm3, [rsp+0x70]
000073307ffd5fd6  vmovaps [rsp+0x70], xmm15
000073307ffd5fdc  movaps xmm9, xmm3
000073307ffd5fe0  mulpd xmm9, xmm1
000073307ffd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
000073307ffd5feb  ptest xmm15, xmm15
000073307ffd5ff1  jnz 0x000073307FFD84E3
000073307ffd5ff7  lea r14, [rax+0xC0]
000073307ffd5ffe  movups xmm1, [r13+r14*1]
000073307ffd6004  vmovaps xmm3, [rsp+0xC0]
000073307ffd600d  vmovaps [rsp+0x80], xmm1
000073307ffd6016  movaps xmm15, xmm3
000073307ffd601a  addpd xmm15, xmm7
000073307ffd601f  vcmppd xmm1, xmm15, xmm15, 0x03
000073307ffd6025  ptest xmm1, xmm1
000073307ffd602a  jnz 0x000073307FFD862F
000073307ffd6030  vmovaps [rsp+0xC0], xmm13
000073307ffd6039  vmovaps xmm1, [rsp+0xC0]
000073307ffd6042  por xmm13, xmm1
000073307ffd6047  movaps [r15+0x270], xmm13
000073307ffd604f  vmovaps xmm1, [rsp+0xB0]
000073307ffd6058  vmovaps xmm7, [rsp+0xB0]
000073307ffd6061  por xmm1, xmm7
000073307ffd6065  movaps [r15+0x1A0], xmm1
000073307ffd606d  vmovaps xmm1, [rsp+0x60]
000073307ffd6073  vpermilpd xmm1, xmm1, 0x00
000073307ffd6079  vmovaps [rsp+0xB0], xmm1
000073307ffd6082  vmovaps xmm1, [rsp+0x80]
000073307ffd608b  vmovaps [rsp+0x80], xmm15
000073307ffd6094  vmovaps xmm15, [rsp+0xB0]
000073307ffd609d  vmovaps [rsp+0xB0], xmm14
000073307ffd60a6  movaps xmm3, xmm1
000073307ffd60a9  mulpd xmm3, xmm15
000073307ffd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
000073307ffd60b3  ptest xmm14, xmm14
000073307ffd60b9  jnz 0x000073307FFD8771
000073307ffd60bf  lea r14, [rax+0x20]
000073307ffd60c3  movups xmm1, [r13+r14*1]
000073307ffd60c9  movaps [r15+0x110], xmm1
000073307ffd60d1  vmovaps xmm14, [rsp+0x70]
000073307ffd60d7  vmovaps [rsp+0x70], xmm1
000073307ffd60dd  movaps xmm15, xmm14
000073307ffd60e1  addpd xmm15, xmm4
000073307ffd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
000073307ffd60ec  ptest xmm1, xmm1
000073307ffd60f1  jnz 0x000073307FFD88BC
000073307ffd60f7  vmovaps xmm1, [rsp+0x60]
000073307ffd60fd  vpermilpd xmm1, xmm1, 0x00
000073307ffd6103  movaps xmm14, xmm2
000073307ffd6107  mulpd xmm14, xmm1
000073307ffd610c  vcmppd xmm4, xmm14, xmm14, 0x03
000073307ffd6112  ptest xmm4, xmm4
000073307ffd6117  jnz 0x000073307FFD89FF
000073307ffd611d  vmovaps xmm4, [rsp+0x50]
000073307ffd6123  movaps xmm1, xmm4
000073307ffd6126  addpd xmm1, xmm9
000073307ffd612b  vcmppd xmm2, xmm1, xmm1, 0x03
000073307ffd6130  ptest xmm2, xmm2
000073307ffd6135  jnz 0x000073307FFD8B41
000073307ffd613b  vmovaps xmm9, [rsp+0x30]
000073307ffd6141  vpermilpd xmm9, xmm9, 0x00
000073307ffd6147  vmovaps xmm2, [rsp+0x70]
000073307ffd614d  vmovaps [rsp+0x50], xmm1
000073307ffd6153  movaps xmm4, xmm2
000073307ffd6156  mulpd xmm4, xmm9
000073307ffd615b  vcmppd xmm1, xmm4, xmm4, 0x03
000073307ffd6160  ptest xmm1, xmm1
000073307ffd6165  jnz 0x000073307FFD8C82
000073307ffd616b  vmovaps xmm1, [rsp+0x30]
000073307ffd6171  vpermilpd xmm1, xmm1, 0x00
000073307ffd6177  vmovaps xmm2, [rsp+0x90]
000073307ffd6180  vmovaps [rsp+0x60], xmm15
000073307ffd6186  movaps xmm9, xmm2
000073307ffd618a  mulpd xmm9, xmm1
000073307ffd618f  vcmppd xmm15, xmm9, xmm9, 0x03
000073307ffd6195  ptest xmm15, xmm15
000073307ffd619b  jnz 0x000073307FFD8DC3
000073307ffd61a1  vmovaps xmm15, [rsp+0x80]
000073307ffd61aa  movaps xmm1, xmm15
000073307ffd61ae  addpd xmm1, xmm6
000073307ffd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
000073307ffd61b7  ptest xmm2, xmm2
000073307ffd61bc  jnz 0x000073307FFD8F05
000073307ffd61c2  movaps xmm15, xmm5
000073307ffd61c6  addpd xmm15, xmm3
000073307ffd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
000073307ffd61d1  ptest xmm6, xmm6
000073307ffd61d6  jnz 0x000073307FFD9046
000073307ffd61dc  vmovaps xmm6, [rsp+0x30]
000073307ffd61e2  vpermilpd xmm6, xmm6, 0x00
000073307ffd61e8  movaps xmm5, xmm8
000073307ffd61ec  mulpd xmm5, xmm6
000073307ffd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
000073307ffd61f5  ptest xmm3, xmm3
000073307ffd61fa  jnz 0x000073307FFD9188
000073307ffd6200  vmovaps xmm8, [rsp+0x30]
000073307ffd6206  vpermilpd xmm8, xmm8, 0x00
000073307ffd620c  movaps xmm6, xmm10
000073307ffd6210  mulpd xmm6, xmm8
000073307ffd6215  vcmppd xmm3, xmm6, xmm6, 0x03
000073307ffd621a  ptest xmm3, xmm3
000073307ffd621f  jnz 0x000073307FFD92C9
000073307ffd6225  vmovaps xmm8, [rsp+0x60]
000073307ffd622b  movaps xmm10, xmm8
000073307ffd622f  addpd xmm10, xmm14
000073307ffd6234  vcmppd xmm3, xmm10, xmm10, 0x03
000073307ffd623a  ptest xmm3, xmm3
000073307ffd623f  jnz 0x000073307FFD940B
000073307ffd6245  vmovaps xmm8, [rsp+0x50]
000073307ffd624b  movaps xmm14, xmm8
000073307ffd624f  addpd xmm14, xmm4
000073307ffd6254  vcmppd xmm3, xmm14, xmm14, 0x03
000073307ffd625a  ptest xmm3, xmm3
000073307ffd625f  jnz 0x000073307FFD954F
000073307ffd6265  vmovaps xmm8, [rsp+0x40]
000073307ffd626b  vpermilpd xmm8, xmm8, 0x00
000073307ffd6271  movaps xmm4, xmm13
000073307ffd6275  mulpd xmm4, xmm8
000073307ffd627a  vcmppd xmm3, xmm4, xmm4, 0x03
000073307ffd627f  ptest xmm3, xmm3
000073307ffd6284  jnz 0x000073307FFD9692
000073307ffd628a  movaps xmm13, xmm15
000073307ffd628e  addpd xmm13, xmm9
000073307ffd6293  vcmppd xmm8, xmm13, xmm13, 0x03
000073307ffd6299  ptest xmm8, xmm8
000073307ffd629f  jnz 0x000073307FFD97D4
000073307ffd62a5  movaps xmm15, xmm1
000073307ffd62a9  addpd xmm15, xmm5
000073307ffd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
000073307ffd62b4  ptest xmm9, xmm9
000073307ffd62ba  jnz 0x000073307FFD9918
000073307ffd62c0  vmovaps [rsp+0x30], xmm11
000073307ffd62c6  vmovaps xmm1, [rsp+0x30]
000073307ffd62cc  por xmm11, xmm1
000073307ffd62d1  movaps [r15+0x250], xmm11
000073307ffd62d9  vmovaps [rsp+0x30], xmm12
000073307ffd62df  vmovaps xmm1, [rsp+0x30]
000073307ffd62e5  por xmm12, xmm1
000073307ffd62ea  movaps [r15+0x2A0], xmm12
000073307ffd62f2  vmovaps xmm1, [rsp+0xA0]
000073307ffd62fb  vmovaps xmm11, [rsp+0xA0]
000073307ffd6304  por xmm1, xmm11
000073307ffd6309  movaps [r15+0x1D0], xmm1
000073307ffd6311  lea r14, [rax+0x40]
000073307ffd6315  movups xmm1, [r13+r14*1]
000073307ffd631b  movaps [r15+0x2C0], xmm1
000073307ffd6323  vmovaps xmm11, [rsp+0x40]
000073307ffd6329  vpermilpd xmm11, xmm11, 0x00
000073307ffd632f  vmovaps xmm8, [rsp+0xE0]
000073307ffd6338  movaps xmm9, xmm8
000073307ffd633c  mulpd xmm9, xmm11
000073307ffd6341  vcmppd xmm5, xmm9, xmm9, 0x03
000073307ffd6347  ptest xmm5, xmm5
000073307ffd634c  jnz 0x000073307FFD9A64
000073307ffd6352  movaps xmm11, xmm10
000073307ffd6356  addpd xmm11, xmm6
000073307ffd635b  vcmppd xmm8, xmm11, xmm11, 0x03
000073307ffd6361  ptest xmm8, xmm8
000073307ffd6367  jnz 0x000073307FFD9BA8
000073307ffd636d  movaps xmm10, xmm14
000073307ffd6371  addpd xmm10, xmm4
000073307ffd6376  vcmppd xmm8, xmm10, xmm10, 0x03
000073307ffd637c  ptest xmm8, xmm8
000073307ffd6382  jnz 0x000073307FFD9CEB
000073307ffd6388  vmovaps xmm14, [rsp+0x40]
000073307ffd638e  vpermilpd xmm14, xmm14, 0x00
000073307ffd6394  movaps xmm8, xmm1
000073307ffd6398  mulpd xmm8, xmm14
000073307ffd639d  vcmppd xmm6, xmm8, xmm8, 0x03
000073307ffd63a3  ptest xmm6, xmm6
000073307ffd63a8  jnz 0x000073307FFD9E2E
000073307ffd63ae  movaps xmm1, [r15+0x2B0]
000073307ffd63b6  vmovaps xmm14, [rsp+0x40]
000073307ffd63bc  vpermilpd xmm14, xmm14, 0x00
000073307ffd63c2  movaps xmm6, xmm1
000073307ffd63c5  mulpd xmm6, xmm14
000073307ffd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
000073307ffd63cf  ptest xmm5, xmm5
000073307ffd63d4  jnz 0x000073307FFD9F71
000073307ffd63da  vmovaps xmm1, [rsp+0x10]
000073307ffd63e0  vpermilpd xmm1, xmm1, 0x00
000073307ffd63e6  movaps xmm14, xmm12
000073307ffd63ea  mulpd xmm14, xmm1
000073307ffd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
000073307ffd63f5  ptest xmm5, xmm5
000073307ffd63fa  jnz 0x000073307FFDA0B2
000073307ffd6400  movaps xmm1, xmm13
000073307ffd6404  addpd xmm1, xmm9
000073307ffd6409  vcmppd xmm12, xmm1, xmm1, 0x03
000073307ffd640e  ptest xmm12, xmm12
000073307ffd6414  jnz 0x000073307FFDA1F5
000073307ffd641a  vmovaps xmm13, [rsp+0x10]
000073307ffd6420  vpermilpd xmm13, xmm13, 0x00
000073307ffd6426  movaps xmm12, xmm7
000073307ffd642a  mulpd xmm12, xmm13
000073307ffd642f  vcmppd xmm9, xmm12, xmm12, 0x03
000073307ffd6435  ptest xmm9, xmm9
000073307ffd643b  jnz 0x000073307FFDA337
000073307ffd6441  movaps xmm13, xmm15
000073307ffd6445  addpd xmm13, xmm8
000073307ffd644a  vcmppd xmm9, xmm13, xmm13, 0x03
000073307ffd6450  ptest xmm9, xmm9
000073307ffd6456  jnz 0x000073307FFDA47A
000073307ffd645c  movaps xmm15, [r15+0x290]
000073307ffd6464  vmovaps xmm9, [rsp+0x10]
000073307ffd646a  vpermilpd xmm9, xmm9, 0x00
000073307ffd6470  movaps xmm8, xmm15
000073307ffd6474  mulpd xmm8, xmm9
000073307ffd6479  vcmppd xmm7, xmm8, xmm8, 0x03
000073307ffd647f  ptest xmm7, xmm7
000073307ffd6484  jnz 0x000073307FFDA5BE
000073307ffd648a  movaps xmm15, xmm11
000073307ffd648e  addpd xmm15, xmm6
000073307ffd6493  vcmppd xmm9, xmm15, xmm15, 0x03
000073307ffd6499  ptest xmm9, xmm9
000073307ffd649f  jnz 0x000073307FFDA702
000073307ffd64a5  movaps xmm11, [r15+0x1E0]
000073307ffd64ad  vmovaps xmm9, [rsp+0x10]
000073307ffd64b3  vpermilpd xmm9, xmm9, 0x00
000073307ffd64b9  movaps xmm7, xmm11
000073307ffd64bd  mulpd xmm7, xmm9
000073307ffd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
000073307ffd64c7  ptest xmm6, xmm6
000073307ffd64cc  jnz 0x000073307FFDA845
000073307ffd64d2  movaps xmm11, xmm10
000073307ffd64d6  addpd xmm11, xmm14
000073307ffd64db  vcmppd xmm9, xmm11, xmm11, 0x03
000073307ffd64e1  ptest xmm9, xmm9
000073307ffd64e7  jnz 0x000073307FFDA987
000073307ffd64ed  lea r14, [rax+0x70]
000073307ffd64f1  movups xmm14, [r13+r14*1]
000073307ffd64f7  movaps [r15+0x240], xmm14
000073307ffd64ff  movaps xmm10, xmm1
000073307ffd6503  addpd xmm10, xmm12
000073307ffd6508  vcmppd xmm9, xmm10, xmm10, 0x03
000073307ffd650e  ptest xmm9, xmm9
000073307ffd6514  jnz 0x000073307FFDAAD5
000073307ffd651a  movaps [r15+0x170], xmm10
000073307ffd6522  vmovaps xmm1, [rsp+0x20]
000073307ffd6528  vpermilpd xmm1, xmm1, 0x00
000073307ffd652e  movaps xmm12, xmm14
000073307ffd6532  mulpd xmm12, xmm1
000073307ffd6537  vcmppd xmm9, xmm12, xmm12, 0x03
000073307ffd653d  ptest xmm9, xmm9
000073307ffd6543  jnz 0x000073307FFDAC18
000073307ffd6549  vmovaps xmm1, [rsp+0x20]
000073307ffd654f  vpermilpd xmm1, xmm1, 0x00
000073307ffd6555  vmovaps xmm9, [rsp+0xB0]
000073307ffd655e  movaps xmm14, xmm9
000073307ffd6562  mulpd xmm14, xmm1
000073307ffd6567  vcmppd xmm6, xmm14, xmm14, 0x03
000073307ffd656d  ptest xmm6, xmm6
000073307ffd6572  jnz 0x000073307FFDAD5B
000073307ffd6578  movaps [r15+0x180], xmm14
000073307ffd6580  movaps xmm1, xmm13
000073307ffd6584  addpd xmm1, xmm8
000073307ffd6589  vcmppd xmm9, xmm1, xmm1, 0x03
000073307ffd658e  ptest xmm9, xmm9
000073307ffd6594  jnz 0x000073307FFDAE9E
000073307ffd659a  movaps [r15+0x210], xmm1
000073307ffd65a2  movups xmm13, [r13+rax*1]
000073307ffd65a8  lea r14, [rax+0x10]
000073307ffd65ac  movups xmm9, [r13+r14*1]
000073307ffd65b2  movaps [r15+0x230], xmm9
000073307ffd65ba  movaps xmm8, xmm15
000073307ffd65be  addpd xmm8, xmm7
000073307ffd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
000073307ffd65c9  ptest xmm6, xmm6
000073307ffd65ce  jnz 0x000073307FFDAFF4
000073307ffd65d4  movaps [r15+0x130], xmm8
000073307ffd65dc  vmovaps xmm15, [rsp+0x20]
000073307ffd65e2  vpermilpd xmm15, xmm15, 0x00
000073307ffd65e8  movaps xmm7, xmm9
000073307ffd65ec  mulpd xmm7, xmm15
000073307ffd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
000073307ffd65f6  ptest xmm6, xmm6
000073307ffd65fb  jnz 0x000073307FFDB137
000073307ffd6601  movaps [r15+0x220], xmm7
000073307ffd6609  vmovaps xmm15, [rsp+0x20]
000073307ffd660f  vpermilpd xmm15, xmm15, 0x00
000073307ffd6615  movaps xmm9, xmm13
000073307ffd6619  mulpd xmm9, xmm15
000073307ffd661e  vcmppd xmm6, xmm9, xmm9, 0x03
000073307ffd6624  ptest xmm6, xmm6
000073307ffd6629  jnz 0x000073307FFDB279
000073307ffd662f  movaps xmm15, xmm11
000073307ffd6633  addpd xmm15, xmm12
000073307ffd6638  vcmppd xmm13, xmm15, xmm15, 0x03
000073307ffd663e  ptest xmm13, xmm13
000073307ffd6644  jnz 0x000073307FFDB3BD
000073307ffd664a  movaps [r15+0x140], xmm15
000073307ffd6652  movaps xmm13, xmm10
000073307ffd6656  addpd xmm13, xmm14
000073307ffd665b  vcmppd xmm12, xmm13, xmm13, 0x03
000073307ffd6661  ptest xmm12, xmm12
000073307ffd6667  jnz 0x000073307FFDB501
000073307ffd666d  movaps [r15+0x150], xmm13
000073307ffd6675  movaps xmm14, xmm1
000073307ffd6679  addpd xmm14, xmm7
000073307ffd667e  vcmppd xmm12, xmm14, xmm14, 0x03
000073307ffd6684  ptest xmm12, xmm12
000073307ffd668a  jnz 0x000073307FFDB645
000073307ffd6690  movaps [r15+0x160], xmm14
000073307ffd6698  movaps xmm1, xmm8
000073307ffd669c  addpd xmm1, xmm9
000073307ffd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
000073307ffd66a6  ptest xmm12, xmm12
000073307ffd66ac  jnz 0x000073307FFDB787
000073307ffd66b2  movaps [r15+0x120], xmm1
000073307ffd66ba  movups [r13+r11*1], xmm15
000073307ffd66c0  lea rax, [r11+0x10]
000073307ffd66c4  movups [r13+rax*1], xmm13
000073307ffd66ca  lea rax, [r11+0x20]
000073307ffd66ce  movups [r13+rax*1], xmm14
000073307ffd66d4  lea rax, [r11+0x30]
000073307ffd66d8  movups [r13+rax*1], xmm1
000073307ffd66de  mov eax, [r15+0x108]
000073307ffd66e5  sahf
000073307ffd66e6  jnz 0x000073307FFD6718
000073307ffd66e8  cmp dword ptr [r15+0x318], 0x00
000073307ffd66f0  jz 0x000073307FFDB900
000073307ffd66f6  nop [rax+rax*1], ax
000073307ffd66ff  nop [rax+rax*1], eax
000073307ffd6707  mov eax, 0x410444
000073307ffd670c  mov [r15+0x100], rax
000073307ffd6713  jmp 0x000073307FDFE110
000073307ffd6718  cmp dword ptr [r15+0x318], 0x00
000073307ffd6720  jz 0x000073307FFD57E0
000073307ffd6726  nop [rax+rax*1], ax
000073307ffd672f  nop [rax+rax*1], eax
000073307ffd6737  mov eax, 0x410278
000073307ffd673c  mov [r15+0x100], rax
000073307ffd6743  jmp 0x000073307FDFE110
000073307ffd6748  int3
000073307ffd6749  call 0x000073307FE0A4B0
000073307ffd674e  jmp 0x000073307FFD5828
000073307ffd6753  call 0x000073307FE09240
000073307ffd6758  jmp 0x000073307FFD5832
000073307ffd675d  call 0x000073307FE0A4B0
000073307ffd6762  jmp 0x000073307FFD588F
000073307ffd6767  call 0x000073307FE09240
000073307ffd676c  jmp 0x000073307FFD5899
000073307ffd6771  call 0x000073307FE0A4B0
000073307ffd6776  jmp 0x000073307FFD58DD
000073307ffd677b  call 0x000073307FE09240
000073307ffd6780  jmp 0x000073307FFD58E7
000073307ffd6785  call 0x000073307FEB47C0
000073307ffd678a  jmp 0x000073307FFD5926
000073307ffd678f  call 0x000073307FE0B720
000073307ffd6794  jmp 0x000073307FFD593A
000073307ffd6799  call 0x000073307FEBFC30
000073307ffd679e  jmp 0x000073307FFD5958
000073307ffd67a3  call 0x000073307FEBE9C0
000073307ffd67a8  jmp 0x000073307FFD5962
000073307ffd67ad  call 0x000073307FEBD750
000073307ffd67b2  jmp 0x000073307FFD596C
000073307ffd67b7  sub rsp, 0x08
000073307ffd67bb  push rax
000073307ffd67bc  push rcx
000073307ffd67bd  push rdx
000073307ffd67be  push rdi
000073307ffd67bf  push rsi
000073307ffd67c0  push r8
000073307ffd67c2  push r9
000073307ffd67c4  push r10
000073307ffd67c6  push r11
000073307ffd67c8  sub rsp, 0xF0
000073307ffd67cf  vmovaps [rsp], xmm0
000073307ffd67d4  vmovaps [rsp+0x10], xmm1
000073307ffd67da  vmovaps [rsp+0x20], xmm2
000073307ffd67e0  vmovaps [rsp+0x30], xmm3
000073307ffd67e6  vmovaps [rsp+0x40], xmm4
000073307ffd67ec  vmovaps [rsp+0x50], xmm5
000073307ffd67f2  vmovaps [rsp+0x60], xmm6
000073307ffd67f8  vmovaps [rsp+0x70], xmm7
000073307ffd67fe  vmovaps [rsp+0x80], xmm9
000073307ffd6807  vmovaps [rsp+0x90], xmm10
000073307ffd6810  vmovaps [rsp+0xA0], xmm11
000073307ffd6819  vmovaps [rsp+0xB0], xmm12
000073307ffd6822  vmovaps [rsp+0xC0], xmm13
000073307ffd682b  vmovaps [rsp+0xD0], xmm14
000073307ffd6834  vmovaps [rsp+0xE0], xmm15
000073307ffd683d  sub rsp, 0x30
000073307ffd6841  movaps [rsp], xmm8
000073307ffd6846  movaps [rsp+0x10], xmm12
000073307ffd684c  movaps [rsp+0x20], xmm15
000073307ffd6852  lea rdi, [rsp]
000073307ffd6856  mov esi, 0x00
000073307ffd685b  mov rax, 0x600DE0EC8530
000073307ffd6865  call rax
000073307ffd6867  movaps xmm8, [rsp]
000073307ffd686c  add rsp, 0x30
000073307ffd6870  vmovaps xmm0, [rsp]
000073307ffd6875  vmovaps xmm1, [rsp+0x10]
000073307ffd687b  vmovaps xmm2, [rsp+0x20]
000073307ffd6881  vmovaps xmm3, [rsp+0x30]
000073307ffd6887  vmovaps xmm4, [rsp+0x40]
000073307ffd688d  vmovaps xmm5, [rsp+0x50]
000073307ffd6893  vmovaps xmm6, [rsp+0x60]
000073307ffd6899  vmovaps xmm7, [rsp+0x70]
000073307ffd689f  vmovaps xmm9, [rsp+0x80]
000073307ffd68a8  vmovaps xmm10, [rsp+0x90]
000073307ffd68b1  vmovaps xmm11, [rsp+0xA0]
000073307ffd68ba  vmovaps xmm12, [rsp+0xB0]
000073307ffd68c3  vmovaps xmm13, [rsp+0xC0]
000073307ffd68cc  vmovaps xmm14, [rsp+0xD0]
000073307ffd68d5  vmovaps xmm15, [rsp+0xE0]
000073307ffd68de  add rsp, 0xF0
000073307ffd68e5  pop r11
000073307ffd68e7  pop r10
000073307ffd68e9  pop r9
000073307ffd68eb  pop r8
000073307ffd68ed  pop rsi
000073307ffd68ee  pop rdi
000073307ffd68ef  pop rdx
000073307ffd68f0  pop rcx
000073307ffd68f1  pop rax
000073307ffd68f2  add rsp, 0x08
000073307ffd68f6  jmp 0x000073307FFD599A
000073307ffd68fb  sub rsp, 0x08
000073307ffd68ff  push rax
000073307ffd6900  push rcx
000073307ffd6901  push rdx
000073307ffd6902  push rdi
000073307ffd6903  push rsi
000073307ffd6904  push r8
000073307ffd6906  push r9
000073307ffd6908  push r10
000073307ffd690a  push r11
000073307ffd690c  sub rsp, 0xF0
000073307ffd6913  vmovaps [rsp], xmm0
000073307ffd6918  vmovaps [rsp+0x10], xmm1
000073307ffd691e  vmovaps [rsp+0x20], xmm2
000073307ffd6924  vmovaps [rsp+0x30], xmm3
000073307ffd692a  vmovaps [rsp+0x40], xmm4
000073307ffd6930  vmovaps [rsp+0x50], xmm5
000073307ffd6936  vmovaps [rsp+0x60], xmm6
000073307ffd693c  vmovaps [rsp+0x70], xmm8
000073307ffd6942  vmovaps [rsp+0x80], xmm9
000073307ffd694b  vmovaps [rsp+0x90], xmm10
000073307ffd6954  vmovaps [rsp+0xA0], xmm11
000073307ffd695d  vmovaps [rsp+0xB0], xmm12
000073307ffd6966  vmovaps [rsp+0xC0], xmm13
000073307ffd696f  vmovaps [rsp+0xD0], xmm14
000073307ffd6978  vmovaps [rsp+0xE0], xmm15
000073307ffd6981  sub rsp, 0x30
000073307ffd6985  movaps [rsp], xmm7
000073307ffd6989  movaps [rsp+0x10], xmm9
000073307ffd698f  movaps [rsp+0x20], xmm15
000073307ffd6995  lea rdi, [rsp]
000073307ffd6999  mov esi, 0x00
000073307ffd699e  mov rax, 0x600DE0EC8530
000073307ffd69a8  call rax
000073307ffd69aa  movaps xmm7, [rsp]
000073307ffd69ae  add rsp, 0x30
000073307ffd69b2  vmovaps xmm0, [rsp]
000073307ffd69b7  vmovaps xmm1, [rsp+0x10]
000073307ffd69bd  vmovaps xmm2, [rsp+0x20]
000073307ffd69c3  vmovaps xmm3, [rsp+0x30]
000073307ffd69c9  vmovaps xmm4, [rsp+0x40]
000073307ffd69cf  vmovaps xmm5, [rsp+0x50]
000073307ffd69d5  vmovaps xmm6, [rsp+0x60]
000073307ffd69db  vmovaps xmm8, [rsp+0x70]
000073307ffd69e1  vmovaps xmm9, [rsp+0x80]
000073307ffd69ea  vmovaps xmm10, [rsp+0x90]
000073307ffd69f3  vmovaps xmm11, [rsp+0xA0]
000073307ffd69fc  vmovaps xmm12, [rsp+0xB0]
000073307ffd6a05  vmovaps xmm13, [rsp+0xC0]
000073307ffd6a0e  vmovaps xmm14, [rsp+0xD0]
000073307ffd6a17  vmovaps xmm15, [rsp+0xE0]
000073307ffd6a20  add rsp, 0xF0
000073307ffd6a27  pop r11
000073307ffd6a29  pop r10
000073307ffd6a2b  pop r9
000073307ffd6a2d  pop r8
000073307ffd6a2f  pop rsi
000073307ffd6a30  pop rdi
000073307ffd6a31  pop rdx
000073307ffd6a32  pop rcx
000073307ffd6a33  pop rax
000073307ffd6a34  add rsp, 0x08
000073307ffd6a38  jmp 0x000073307FFD59C8
000073307ffd6a3d  sub rsp, 0x08
000073307ffd6a41  push rax
000073307ffd6a42  push rcx
000073307ffd6a43  push rdx
000073307ffd6a44  push rdi
000073307ffd6a45  push rsi
000073307ffd6a46  push r8
000073307ffd6a48  push r9
000073307ffd6a4a  push r10
000073307ffd6a4c  push r11
000073307ffd6a4e  sub rsp, 0xF0
000073307ffd6a55  vmovaps [rsp], xmm0
000073307ffd6a5a  vmovaps [rsp+0x10], xmm1
000073307ffd6a60  vmovaps [rsp+0x20], xmm2
000073307ffd6a66  vmovaps [rsp+0x30], xmm3
000073307ffd6a6c  vmovaps [rsp+0x40], xmm4
000073307ffd6a72  vmovaps [rsp+0x50], xmm5
000073307ffd6a78  vmovaps [rsp+0x60], xmm6
000073307ffd6a7e  vmovaps [rsp+0x70], xmm7
000073307ffd6a84  vmovaps [rsp+0x80], xmm8
000073307ffd6a8d  vmovaps [rsp+0x90], xmm10
000073307ffd6a96  vmovaps [rsp+0xA0], xmm11
000073307ffd6a9f  vmovaps [rsp+0xB0], xmm12
000073307ffd6aa8  vmovaps [rsp+0xC0], xmm13
000073307ffd6ab1  vmovaps [rsp+0xD0], xmm14
000073307ffd6aba  vmovaps [rsp+0xE0], xmm15
000073307ffd6ac3  sub rsp, 0x30
000073307ffd6ac7  movaps [rsp], xmm9
000073307ffd6acc  movaps [rsp+0x10], xmm12
000073307ffd6ad2  movaps [rsp+0x20], xmm10
000073307ffd6ad8  lea rdi, [rsp]
000073307ffd6adc  mov esi, 0x00
000073307ffd6ae1  mov rax, 0x600DE0EC8530
000073307ffd6aeb  call rax
000073307ffd6aed  movaps xmm9, [rsp]
000073307ffd6af2  add rsp, 0x30
000073307ffd6af6  vmovaps xmm0, [rsp]
000073307ffd6afb  vmovaps xmm1, [rsp+0x10]
000073307ffd6b01  vmovaps xmm2, [rsp+0x20]
000073307ffd6b07  vmovaps xmm3, [rsp+0x30]
000073307ffd6b0d  vmovaps xmm4, [rsp+0x40]
000073307ffd6b13  vmovaps xmm5, [rsp+0x50]
000073307ffd6b19  vmovaps xmm6, [rsp+0x60]
000073307ffd6b1f  vmovaps xmm7, [rsp+0x70]
000073307ffd6b25  vmovaps xmm8, [rsp+0x80]
000073307ffd6b2e  vmovaps xmm10, [rsp+0x90]
000073307ffd6b37  vmovaps xmm11, [rsp+0xA0]
000073307ffd6b40  vmovaps xmm12, [rsp+0xB0]
000073307ffd6b49  vmovaps xmm13, [rsp+0xC0]
000073307ffd6b52  vmovaps xmm14, [rsp+0xD0]
000073307ffd6b5b  vmovaps xmm15, [rsp+0xE0]
000073307ffd6b64  add rsp, 0xF0
000073307ffd6b6b  pop r11
000073307ffd6b6d  pop r10
000073307ffd6b6f  pop r9
000073307ffd6b71  pop r8
000073307ffd6b73  pop rsi
000073307ffd6b74  pop rdi
000073307ffd6b75  pop rdx
000073307ffd6b76  pop rcx
000073307ffd6b77  pop rax
000073307ffd6b78  add rsp, 0x08
000073307ffd6b7c  jmp 0x000073307FFD59EC
000073307ffd6b81  sub rsp, 0x08
000073307ffd6b85  push rax
000073307ffd6b86  push rcx
000073307ffd6b87  push rdx
000073307ffd6b88  push rdi
000073307ffd6b89  push rsi
000073307ffd6b8a  push r8
000073307ffd6b8c  push r9
000073307ffd6b8e  push r10
000073307ffd6b90  push r11
000073307ffd6b92  sub rsp, 0xF0
000073307ffd6b99  vmovaps [rsp], xmm0
000073307ffd6b9e  vmovaps [rsp+0x10], xmm1
000073307ffd6ba4  vmovaps [rsp+0x20], xmm2
000073307ffd6baa  vmovaps [rsp+0x30], xmm3
000073307ffd6bb0  vmovaps [rsp+0x40], xmm4
000073307ffd6bb6  vmovaps [rsp+0x50], xmm5
000073307ffd6bbc  vmovaps [rsp+0x60], xmm6
000073307ffd6bc2  vmovaps [rsp+0x70], xmm7
000073307ffd6bc8  vmovaps [rsp+0x80], xmm8
000073307ffd6bd1  vmovaps [rsp+0x90], xmm9
000073307ffd6bda  vmovaps [rsp+0xA0], xmm11
000073307ffd6be3  vmovaps [rsp+0xB0], xmm12
000073307ffd6bec  vmovaps [rsp+0xC0], xmm13
000073307ffd6bf5  vmovaps [rsp+0xD0], xmm14
000073307ffd6bfe  vmovaps [rsp+0xE0], xmm15
000073307ffd6c07  sub rsp, 0x30
000073307ffd6c0b  movaps [rsp], xmm10
000073307ffd6c10  movaps [rsp+0x10], xmm12
000073307ffd6c16  movaps [rsp+0x20], xmm11
000073307ffd6c1c  lea rdi, [rsp]
000073307ffd6c20  mov esi, 0x00
000073307ffd6c25  mov rax, 0x600DE0EC8530
000073307ffd6c2f  call rax
000073307ffd6c31  movaps xmm10, [rsp]
000073307ffd6c36  add rsp, 0x30
000073307ffd6c3a  vmovaps xmm0, [rsp]
000073307ffd6c3f  vmovaps xmm1, [rsp+0x10]
000073307ffd6c45  vmovaps xmm2, [rsp+0x20]
000073307ffd6c4b  vmovaps xmm3, [rsp+0x30]
000073307ffd6c51  vmovaps xmm4, [rsp+0x40]
000073307ffd6c57  vmovaps xmm5, [rsp+0x50]
000073307ffd6c5d  vmovaps xmm6, [rsp+0x60]
000073307ffd6c63  vmovaps xmm7, [rsp+0x70]
000073307ffd6c69  vmovaps xmm8, [rsp+0x80]
000073307ffd6c72  vmovaps xmm9, [rsp+0x90]
000073307ffd6c7b  vmovaps xmm11, [rsp+0xA0]
000073307ffd6c84  vmovaps xmm12, [rsp+0xB0]
000073307ffd6c8d  vmovaps xmm13, [rsp+0xC0]
000073307ffd6c96  vmovaps xmm14, [rsp+0xD0]
000073307ffd6c9f  vmovaps xmm15, [rsp+0xE0]
000073307ffd6ca8  add rsp, 0xF0
000073307ffd6caf  pop r11
000073307ffd6cb1  pop r10
000073307ffd6cb3  pop r9
000073307ffd6cb5  pop r8
000073307ffd6cb7  pop rsi
000073307ffd6cb8  pop rdi
000073307ffd6cb9  pop rdx
000073307ffd6cba  pop rcx
000073307ffd6cbb  pop rax
000073307ffd6cbc  add rsp, 0x08
000073307ffd6cc0  jmp 0x000073307FFD5A06
000073307ffd6cc5  sub rsp, 0x08
000073307ffd6cc9  push rax
000073307ffd6cca  push rcx
000073307ffd6ccb  push rdx
000073307ffd6ccc  push rdi
000073307ffd6ccd  push rsi
000073307ffd6cce  push r8
000073307ffd6cd0  push r9
000073307ffd6cd2  push r10
000073307ffd6cd4  push r11
000073307ffd6cd6  sub rsp, 0xF0
000073307ffd6cdd  vmovaps [rsp], xmm0
000073307ffd6ce2  vmovaps [rsp+0x10], xmm1
000073307ffd6ce8  vmovaps [rsp+0x20], xmm2
000073307ffd6cee  vmovaps [rsp+0x30], xmm3
000073307ffd6cf4  vmovaps [rsp+0x40], xmm4
000073307ffd6cfa  vmovaps [rsp+0x50], xmm5
000073307ffd6d00  vmovaps [rsp+0x60], xmm7
000073307ffd6d06  vmovaps [rsp+0x70], xmm8
000073307ffd6d0c  vmovaps [rsp+0x80], xmm9
000073307ffd6d15  vmovaps [rsp+0x90], xmm10
000073307ffd6d1e  vmovaps [rsp+0xA0], xmm11
000073307ffd6d27  vmovaps [rsp+0xB0], xmm12
000073307ffd6d30  vmovaps [rsp+0xC0], xmm13
000073307ffd6d39  vmovaps [rsp+0xD0], xmm14
000073307ffd6d42  vmovaps [rsp+0xE0], xmm15
000073307ffd6d4b  sub rsp, 0x30
000073307ffd6d4f  movaps [rsp], xmm6
000073307ffd6d53  movaps [rsp+0x10], xmm12
000073307ffd6d59  movaps [rsp+0x20], xmm11
000073307ffd6d5f  lea rdi, [rsp]
000073307ffd6d63  mov esi, 0x00
000073307ffd6d68  mov rax, 0x600DE0EC8530
000073307ffd6d72  call rax
000073307ffd6d74  movaps xmm6, [rsp]
000073307ffd6d78  add rsp, 0x30
000073307ffd6d7c  vmovaps xmm0, [rsp]
000073307ffd6d81  vmovaps xmm1, [rsp+0x10]
000073307ffd6d87  vmovaps xmm2, [rsp+0x20]
000073307ffd6d8d  vmovaps xmm3, [rsp+0x30]
000073307ffd6d93  vmovaps xmm4, [rsp+0x40]
000073307ffd6d99  vmovaps xmm5, [rsp+0x50]
000073307ffd6d9f  vmovaps xmm7, [rsp+0x60]
000073307ffd6da5  vmovaps xmm8, [rsp+0x70]
000073307ffd6dab  vmovaps xmm9, [rsp+0x80]
000073307ffd6db4  vmovaps xmm10, [rsp+0x90]
000073307ffd6dbd  vmovaps xmm11, [rsp+0xA0]
000073307ffd6dc6  vmovaps xmm12, [rsp+0xB0]
000073307ffd6dcf  vmovaps xmm13, [rsp+0xC0]
000073307ffd6dd8  vmovaps xmm14, [rsp+0xD0]
000073307ffd6de1  vmovaps xmm15, [rsp+0xE0]
000073307ffd6dea  add rsp, 0xF0
000073307ffd6df1  pop r11
000073307ffd6df3  pop r10
000073307ffd6df5  pop r9
000073307ffd6df7  pop r8
000073307ffd6df9  pop rsi
000073307ffd6dfa  pop rdi
000073307ffd6dfb  pop rdx
000073307ffd6dfc  pop rcx
000073307ffd6dfd  pop rax
000073307ffd6dfe  add rsp, 0x08
000073307ffd6e02  jmp 0x000073307FFD5A27
000073307ffd6e07  sub rsp, 0x08
000073307ffd6e0b  push rax
000073307ffd6e0c  push rcx
000073307ffd6e0d  push rdx
000073307ffd6e0e  push rdi
000073307ffd6e0f  push rsi
000073307ffd6e10  push r8
000073307ffd6e12  push r9
000073307ffd6e14  push r10
000073307ffd6e16  push r11
000073307ffd6e18  sub rsp, 0xF0
000073307ffd6e1f  vmovaps [rsp], xmm0
000073307ffd6e24  vmovaps [rsp+0x10], xmm1
000073307ffd6e2a  vmovaps [rsp+0x20], xmm2
000073307ffd6e30  vmovaps [rsp+0x30], xmm4
000073307ffd6e36  vmovaps [rsp+0x40], xmm5
000073307ffd6e3c  vmovaps [rsp+0x50], xmm6
000073307ffd6e42  vmovaps [rsp+0x60], xmm7
000073307ffd6e48  vmovaps [rsp+0x70], xmm8
000073307ffd6e4e  vmovaps [rsp+0x80], xmm9
000073307ffd6e57  vmovaps [rsp+0x90], xmm10
000073307ffd6e60  vmovaps [rsp+0xA0], xmm11
000073307ffd6e69  vmovaps [rsp+0xB0], xmm12
000073307ffd6e72  vmovaps [rsp+0xC0], xmm13
000073307ffd6e7b  vmovaps [rsp+0xD0], xmm14
000073307ffd6e84  vmovaps [rsp+0xE0], xmm15
000073307ffd6e8d  sub rsp, 0x30
000073307ffd6e91  movaps [rsp], xmm3
000073307ffd6e95  movaps [rsp+0x10], xmm5
000073307ffd6e9a  movaps [rsp+0x20], xmm4
000073307ffd6e9f  lea rdi, [rsp]
000073307ffd6ea3  mov esi, 0x00
000073307ffd6ea8  mov rax, 0x600DE0EC8530
000073307ffd6eb2  call rax
000073307ffd6eb4  movaps xmm3, [rsp]
000073307ffd6eb8  add rsp, 0x30
000073307ffd6ebc  vmovaps xmm0, [rsp]
000073307ffd6ec1  vmovaps xmm1, [rsp+0x10]
000073307ffd6ec7  vmovaps xmm2, [rsp+0x20]
000073307ffd6ecd  vmovaps xmm4, [rsp+0x30]
000073307ffd6ed3  vmovaps xmm5, [rsp+0x40]
000073307ffd6ed9  vmovaps xmm6, [rsp+0x50]
000073307ffd6edf  vmovaps xmm7, [rsp+0x60]
000073307ffd6ee5  vmovaps xmm8, [rsp+0x70]
000073307ffd6eeb  vmovaps xmm9, [rsp+0x80]
000073307ffd6ef4  vmovaps xmm10, [rsp+0x90]
000073307ffd6efd  vmovaps xmm11, [rsp+0xA0]
000073307ffd6f06  vmovaps xmm12, [rsp+0xB0]
000073307ffd6f0f  vmovaps xmm13, [rsp+0xC0]
000073307ffd6f18  vmovaps xmm14, [rsp+0xD0]
000073307ffd6f21  vmovaps xmm15, [rsp+0xE0]
000073307ffd6f2a  add rsp, 0xF0
000073307ffd6f31  pop r11
000073307ffd6f33  pop r10
000073307ffd6f35  pop r9
000073307ffd6f37  pop r8
000073307ffd6f39  pop rsi
000073307ffd6f3a  pop rdi
000073307ffd6f3b  pop rdx
000073307ffd6f3c  pop rcx
000073307ffd6f3d  pop rax
000073307ffd6f3e  add rsp, 0x08
000073307ffd6f42  jmp 0x000073307FFD5A88
000073307ffd6f47  sub rsp, 0x08
000073307ffd6f4b  push rax
000073307ffd6f4c  push rcx
000073307ffd6f4d  push rdx
000073307ffd6f4e  push rdi
000073307ffd6f4f  push rsi
000073307ffd6f50  push r8
000073307ffd6f52  push r9
000073307ffd6f54  push r10
000073307ffd6f56  push r11
000073307ffd6f58  sub rsp, 0xF0
000073307ffd6f5f  vmovaps [rsp], xmm0
000073307ffd6f64  vmovaps [rsp+0x10], xmm1
000073307ffd6f6a  vmovaps [rsp+0x20], xmm2
000073307ffd6f70  vmovaps [rsp+0x30], xmm3
000073307ffd6f76  vmovaps [rsp+0x40], xmm4
000073307ffd6f7c  vmovaps [rsp+0x50], xmm6
000073307ffd6f82  vmovaps [rsp+0x60], xmm7
000073307ffd6f88  vmovaps [rsp+0x70], xmm8
000073307ffd6f8e  vmovaps [rsp+0x80], xmm9
000073307ffd6f97  vmovaps [rsp+0x90], xmm10
000073307ffd6fa0  vmovaps [rsp+0xA0], xmm11
000073307ffd6fa9  vmovaps [rsp+0xB0], xmm12
000073307ffd6fb2  vmovaps [rsp+0xC0], xmm13
000073307ffd6fbb  vmovaps [rsp+0xD0], xmm14
000073307ffd6fc4  vmovaps [rsp+0xE0], xmm15
000073307ffd6fcd  sub rsp, 0x30
000073307ffd6fd1  movaps [rsp], xmm5
000073307ffd6fd5  movaps [rsp+0x10], xmm8
000073307ffd6fdb  movaps [rsp+0x20], xmm15
000073307ffd6fe1  lea rdi, [rsp]
000073307ffd6fe5  mov esi, 0x00
000073307ffd6fea  mov rax, 0x600DE0EC8530
000073307ffd6ff4  call rax
000073307ffd6ff6  movaps xmm5, [rsp]
000073307ffd6ffa  add rsp, 0x30
000073307ffd6ffe  vmovaps xmm0, [rsp]
000073307ffd7003  vmovaps xmm1, [rsp+0x10]
000073307ffd7009  vmovaps xmm2, [rsp+0x20]
000073307ffd700f  vmovaps xmm3, [rsp+0x30]
000073307ffd7015  vmovaps xmm4, [rsp+0x40]
000073307ffd701b  vmovaps xmm6, [rsp+0x50]
000073307ffd7021  vmovaps xmm7, [rsp+0x60]
000073307ffd7027  vmovaps xmm8, [rsp+0x70]
000073307ffd702d  vmovaps xmm9, [rsp+0x80]
000073307ffd7036  vmovaps xmm10, [rsp+0x90]
000073307ffd703f  vmovaps xmm11, [rsp+0xA0]
000073307ffd7048  vmovaps xmm12, [rsp+0xB0]
000073307ffd7051  vmovaps xmm13, [rsp+0xC0]
000073307ffd705a  vmovaps xmm14, [rsp+0xD0]
000073307ffd7063  vmovaps xmm15, [rsp+0xE0]
000073307ffd706c  add rsp, 0xF0
000073307ffd7073  pop r11
000073307ffd7075  pop r10
000073307ffd7077  pop r9
000073307ffd7079  pop r8
000073307ffd707b  pop rsi
000073307ffd707c  pop rdi
000073307ffd707d  pop rdx
000073307ffd707e  pop rcx
000073307ffd707f  pop rax
000073307ffd7080  add rsp, 0x08
000073307ffd7084  jmp 0x000073307FFD5AC0
000073307ffd7089  sub rsp, 0x08
000073307ffd708d  push rax
000073307ffd708e  push rcx
000073307ffd708f  push rdx
000073307ffd7090  push rdi
000073307ffd7091  push rsi
000073307ffd7092  push r8
000073307ffd7094  push r9
000073307ffd7096  push r10
000073307ffd7098  push r11
000073307ffd709a  sub rsp, 0xF0
000073307ffd70a1  vmovaps [rsp], xmm0
000073307ffd70a6  vmovaps [rsp+0x10], xmm1
000073307ffd70ac  vmovaps [rsp+0x20], xmm2
000073307ffd70b2  vmovaps [rsp+0x30], xmm3
000073307ffd70b8  vmovaps [rsp+0x40], xmm5
000073307ffd70be  vmovaps [rsp+0x50], xmm6
000073307ffd70c4  vmovaps [rsp+0x60], xmm7
000073307ffd70ca  vmovaps [rsp+0x70], xmm8
000073307ffd70d0  vmovaps [rsp+0x80], xmm9
000073307ffd70d9  vmovaps [rsp+0x90], xmm10
000073307ffd70e2  vmovaps [rsp+0xA0], xmm11
000073307ffd70eb  vmovaps [rsp+0xB0], xmm12
000073307ffd70f4  vmovaps [rsp+0xC0], xmm13
000073307ffd70fd  vmovaps [rsp+0xD0], xmm14
000073307ffd7106  vmovaps [rsp+0xE0], xmm15
000073307ffd710f  sub rsp, 0x30
000073307ffd7113  movaps [rsp], xmm4
000073307ffd7117  movaps [rsp+0x10], xmm9
000073307ffd711d  movaps [rsp+0x20], xmm8
000073307ffd7123  lea rdi, [rsp]
000073307ffd7127  mov esi, 0x00
000073307ffd712c  mov rax, 0x600DE0EC8530
000073307ffd7136  call rax
000073307ffd7138  movaps xmm4, [rsp]
000073307ffd713c  add rsp, 0x30
000073307ffd7140  vmovaps xmm0, [rsp]
000073307ffd7145  vmovaps xmm1, [rsp+0x10]
000073307ffd714b  vmovaps xmm2, [rsp+0x20]
000073307ffd7151  vmovaps xmm3, [rsp+0x30]
000073307ffd7157  vmovaps xmm5, [rsp+0x40]
000073307ffd715d  vmovaps xmm6, [rsp+0x50]
000073307ffd7163  vmovaps xmm7, [rsp+0x60]
000073307ffd7169  vmovaps xmm8, [rsp+0x70]
000073307ffd716f  vmovaps xmm9, [rsp+0x80]
000073307ffd7178  vmovaps xmm10, [rsp+0x90]
000073307ffd7181  vmovaps xmm11, [rsp+0xA0]
000073307ffd718a  vmovaps xmm12, [rsp+0xB0]
000073307ffd7193  vmovaps xmm13, [rsp+0xC0]
000073307ffd719c  vmovaps xmm14, [rsp+0xD0]
000073307ffd71a5  vmovaps xmm15, [rsp+0xE0]
000073307ffd71ae  add rsp, 0xF0
000073307ffd71b5  pop r11
000073307ffd71b7  pop r10
000073307ffd71b9  pop r9
000073307ffd71bb  pop r8
000073307ffd71bd  pop rsi
000073307ffd71be  pop rdi
000073307ffd71bf  pop rdx
000073307ffd71c0  pop rcx
000073307ffd71c1  pop rax
000073307ffd71c2  add rsp, 0x08
000073307ffd71c6  jmp 0x000073307FFD5AE1
000073307ffd71cb  sub rsp, 0x08
000073307ffd71cf  push rax
000073307ffd71d0  push rcx
000073307ffd71d1  push rdx
000073307ffd71d2  push rdi
000073307ffd71d3  push rsi
000073307ffd71d4  push r8
000073307ffd71d6  push r9
000073307ffd71d8  push r10
000073307ffd71da  push r11
000073307ffd71dc  sub rsp, 0xF0
000073307ffd71e3  vmovaps [rsp], xmm0
000073307ffd71e8  vmovaps [rsp+0x10], xmm1
000073307ffd71ee  vmovaps [rsp+0x20], xmm2
000073307ffd71f4  vmovaps [rsp+0x30], xmm3
000073307ffd71fa  vmovaps [rsp+0x40], xmm4
000073307ffd7200  vmovaps [rsp+0x50], xmm5
000073307ffd7206  vmovaps [rsp+0x60], xmm6
000073307ffd720c  vmovaps [rsp+0x70], xmm7
000073307ffd7212  vmovaps [rsp+0x80], xmm8
000073307ffd721b  vmovaps [rsp+0x90], xmm10
000073307ffd7224  vmovaps [rsp+0xA0], xmm11
000073307ffd722d  vmovaps [rsp+0xB0], xmm12
000073307ffd7236  vmovaps [rsp+0xC0], xmm13
000073307ffd723f  vmovaps [rsp+0xD0], xmm14
000073307ffd7248  vmovaps [rsp+0xE0], xmm15
000073307ffd7251  sub rsp, 0x30
000073307ffd7255  movaps [rsp], xmm9
000073307ffd725a  movaps [rsp+0x10], xmm10
000073307ffd7260  movaps [rsp+0x20], xmm8
000073307ffd7266  lea rdi, [rsp]
000073307ffd726a  mov esi, 0x00
000073307ffd726f  mov rax, 0x600DE0EC8530
000073307ffd7279  call rax
000073307ffd727b  movaps xmm9, [rsp]
000073307ffd7280  add rsp, 0x30
000073307ffd7284  vmovaps xmm0, [rsp]
000073307ffd7289  vmovaps xmm1, [rsp+0x10]
000073307ffd728f  vmovaps xmm2, [rsp+0x20]
000073307ffd7295  vmovaps xmm3, [rsp+0x30]
000073307ffd729b  vmovaps xmm4, [rsp+0x40]
000073307ffd72a1  vmovaps xmm5, [rsp+0x50]
000073307ffd72a7  vmovaps xmm6, [rsp+0x60]
000073307ffd72ad  vmovaps xmm7, [rsp+0x70]
000073307ffd72b3  vmovaps xmm8, [rsp+0x80]
000073307ffd72bc  vmovaps xmm10, [rsp+0x90]
000073307ffd72c5  vmovaps xmm11, [rsp+0xA0]
000073307ffd72ce  vmovaps xmm12, [rsp+0xB0]
000073307ffd72d7  vmovaps xmm13, [rsp+0xC0]
000073307ffd72e0  vmovaps xmm14, [rsp+0xD0]
000073307ffd72e9  vmovaps xmm15, [rsp+0xE0]
000073307ffd72f2  add rsp, 0xF0
000073307ffd72f9  pop r11
000073307ffd72fb  pop r10
000073307ffd72fd  pop r9
000073307ffd72ff  pop r8
000073307ffd7301  pop rsi
000073307ffd7302  pop rdi
000073307ffd7303  pop rdx
000073307ffd7304  pop rcx
000073307ffd7305  pop rax
000073307ffd7306  add rsp, 0x08
000073307ffd730a  jmp 0x000073307FFD5AFB
000073307ffd730f  call 0x000073307FED64F0
000073307ffd7314  jmp 0x000073307FFD5C15
000073307ffd7319  call 0x000073307FED64F0
000073307ffd731e  jmp 0x000073307FFD5C2B
000073307ffd7323  sub rsp, 0x08
000073307ffd7327  push rax
000073307ffd7328  push rcx
000073307ffd7329  push rdx
000073307ffd732a  push rdi
000073307ffd732b  push rsi
000073307ffd732c  push r8
000073307ffd732e  push r9
000073307ffd7330  push r10
000073307ffd7332  push r11
000073307ffd7334  sub rsp, 0xF0
000073307ffd733b  vmovaps [rsp], xmm0
000073307ffd7340  vmovaps [rsp+0x10], xmm2
000073307ffd7346  vmovaps [rsp+0x20], xmm3
000073307ffd734c  vmovaps [rsp+0x30], xmm4
000073307ffd7352  vmovaps [rsp+0x40], xmm5
000073307ffd7358  vmovaps [rsp+0x50], xmm6
000073307ffd735e  vmovaps [rsp+0x60], xmm7
000073307ffd7364  vmovaps [rsp+0x70], xmm8
000073307ffd736a  vmovaps [rsp+0x80], xmm9
000073307ffd7373  vmovaps [rsp+0x90], xmm10
000073307ffd737c  vmovaps [rsp+0xA0], xmm11
000073307ffd7385  vmovaps [rsp+0xB0], xmm12
000073307ffd738e  vmovaps [rsp+0xC0], xmm13
000073307ffd7397  vmovaps [rsp+0xD0], xmm14
000073307ffd73a0  vmovaps [rsp+0xE0], xmm15
000073307ffd73a9  sub rsp, 0x30
000073307ffd73ad  movaps [rsp], xmm1
000073307ffd73b1  movaps [rsp+0x10], xmm6
000073307ffd73b6  movaps [rsp+0x20], xmm15
000073307ffd73bc  lea rdi, [rsp]
000073307ffd73c0  mov esi, 0x00
000073307ffd73c5  mov rax, 0x600DE0EC8530
000073307ffd73cf  call rax
000073307ffd73d1  movaps xmm1, [rsp]
000073307ffd73d5  add rsp, 0x30
000073307ffd73d9  vmovaps xmm0, [rsp]
000073307ffd73de  vmovaps xmm2, [rsp+0x10]
000073307ffd73e4  vmovaps xmm3, [rsp+0x20]
000073307ffd73ea  vmovaps xmm4, [rsp+0x30]
000073307ffd73f0  vmovaps xmm5, [rsp+0x40]
000073307ffd73f6  vmovaps xmm6, [rsp+0x50]
000073307ffd73fc  vmovaps xmm7, [rsp+0x60]
000073307ffd7402  vmovaps xmm8, [rsp+0x70]
000073307ffd7408  vmovaps xmm9, [rsp+0x80]
000073307ffd7411  vmovaps xmm10, [rsp+0x90]
000073307ffd741a  vmovaps xmm11, [rsp+0xA0]
000073307ffd7423  vmovaps xmm12, [rsp+0xB0]
000073307ffd742c  vmovaps xmm13, [rsp+0xC0]
000073307ffd7435  vmovaps xmm14, [rsp+0xD0]
000073307ffd743e  vmovaps xmm15, [rsp+0xE0]
000073307ffd7447  add rsp, 0xF0
000073307ffd744e  pop r11
000073307ffd7450  pop r10
000073307ffd7452  pop r9
000073307ffd7454  pop r8
000073307ffd7456  pop rsi
000073307ffd7457  pop rdi
000073307ffd7458  pop rdx
000073307ffd7459  pop rcx
000073307ffd745a  pop rax
000073307ffd745b  add rsp, 0x08
000073307ffd745f  jmp 0x000073307FFD5C68
000073307ffd7464  call 0x000073307FEE5820
000073307ffd7469  jmp 0x000073307FFD5C75
000073307ffd746e  sub rsp, 0x08
000073307ffd7472  push rax
000073307ffd7473  push rcx
000073307ffd7474  push rdx
000073307ffd7475  push rdi
000073307ffd7476  push rsi
000073307ffd7477  push r8
000073307ffd7479  push r9
000073307ffd747b  push r10
000073307ffd747d  push r11
000073307ffd747f  sub rsp, 0xF0
000073307ffd7486  vmovaps [rsp], xmm0
000073307ffd748b  vmovaps [rsp+0x10], xmm1
000073307ffd7491  vmovaps [rsp+0x20], xmm2
000073307ffd7497  vmovaps [rsp+0x30], xmm3
000073307ffd749d  vmovaps [rsp+0x40], xmm4
000073307ffd74a3  vmovaps [rsp+0x50], xmm5
000073307ffd74a9  vmovaps [rsp+0x60], xmm6
000073307ffd74af  vmovaps [rsp+0x70], xmm7
000073307ffd74b5  vmovaps [rsp+0x80], xmm8
000073307ffd74be  vmovaps [rsp+0x90], xmm9
000073307ffd74c7  vmovaps [rsp+0xA0], xmm10
000073307ffd74d0  vmovaps [rsp+0xB0], xmm11
000073307ffd74d9  vmovaps [rsp+0xC0], xmm12
000073307ffd74e2  vmovaps [rsp+0xD0], xmm13
000073307ffd74eb  vmovaps [rsp+0xE0], xmm15
000073307ffd74f4  sub rsp, 0x30
000073307ffd74f8  movaps [rsp], xmm14
000073307ffd74fd  movaps [rsp+0x10], xmm4
000073307ffd7502  movaps [rsp+0x20], xmm3
000073307ffd7507  lea rdi, [rsp]
000073307ffd750b  mov esi, 0x00
000073307ffd7510  mov rax, 0x600DE0EC8530
000073307ffd751a  call rax
000073307ffd751c  movaps xmm14, [rsp]
000073307ffd7521  add rsp, 0x30
000073307ffd7525  vmovaps xmm0, [rsp]
000073307ffd752a  vmovaps xmm1, [rsp+0x10]
000073307ffd7530  vmovaps xmm2, [rsp+0x20]
000073307ffd7536  vmovaps xmm3, [rsp+0x30]
000073307ffd753c  vmovaps xmm4, [rsp+0x40]
000073307ffd7542  vmovaps xmm5, [rsp+0x50]
000073307ffd7548  vmovaps xmm6, [rsp+0x60]
000073307ffd754e  vmovaps xmm7, [rsp+0x70]
000073307ffd7554  vmovaps xmm8, [rsp+0x80]
000073307ffd755d  vmovaps xmm9, [rsp+0x90]
000073307ffd7566  vmovaps xmm10, [rsp+0xA0]
000073307ffd756f  vmovaps xmm11, [rsp+0xB0]
000073307ffd7578  vmovaps xmm12, [rsp+0xC0]
000073307ffd7581  vmovaps xmm13, [rsp+0xD0]
000073307ffd758a  vmovaps xmm15, [rsp+0xE0]
000073307ffd7593  add rsp, 0xF0
000073307ffd759a  pop r11
000073307ffd759c  pop r10
000073307ffd759e  pop r9
000073307ffd75a0  pop r8
000073307ffd75a2  pop rsi
000073307ffd75a3  pop rdi
000073307ffd75a4  pop rdx
000073307ffd75a5  pop rcx
000073307ffd75a6  pop rax
000073307ffd75a7  add rsp, 0x08
000073307ffd75ab  jmp 0x000073307FFD5C8F
000073307ffd75b0  sub rsp, 0x08
000073307ffd75b4  push rax
000073307ffd75b5  push rcx
000073307ffd75b6  push rdx
000073307ffd75b7  push rdi
000073307ffd75b8  push rsi
000073307ffd75b9  push r8
000073307ffd75bb  push r9
000073307ffd75bd  push r10
000073307ffd75bf  push r11
000073307ffd75c1  sub rsp, 0xF0
000073307ffd75c8  vmovaps [rsp], xmm0
000073307ffd75cd  vmovaps [rsp+0x10], xmm1
000073307ffd75d3  vmovaps [rsp+0x20], xmm2
000073307ffd75d9  vmovaps [rsp+0x30], xmm3
000073307ffd75df  vmovaps [rsp+0x40], xmm4
000073307ffd75e5  vmovaps [rsp+0x50], xmm5
000073307ffd75eb  vmovaps [rsp+0x60], xmm7
000073307ffd75f1  vmovaps [rsp+0x70], xmm8
000073307ffd75f7  vmovaps [rsp+0x80], xmm9
000073307ffd7600  vmovaps [rsp+0x90], xmm10
000073307ffd7609  vmovaps [rsp+0xA0], xmm11
000073307ffd7612  vmovaps [rsp+0xB0], xmm12
000073307ffd761b  vmovaps [rsp+0xC0], xmm13
000073307ffd7624  vmovaps [rsp+0xD0], xmm14
000073307ffd762d  vmovaps [rsp+0xE0], xmm15
000073307ffd7636  sub rsp, 0x30
000073307ffd763a  movaps [rsp], xmm6
000073307ffd763e  movaps [rsp+0x10], xmm9
000073307ffd7644  movaps [rsp+0x20], xmm7
000073307ffd7649  lea rdi, [rsp]
000073307ffd764d  mov esi, 0x00
000073307ffd7652  mov rax, 0x600DE0EC8530
000073307ffd765c  call rax
000073307ffd765e  movaps xmm6, [rsp]
000073307ffd7662  add rsp, 0x30
000073307ffd7666  vmovaps xmm0, [rsp]
000073307ffd766b  vmovaps xmm1, [rsp+0x10]
000073307ffd7671  vmovaps xmm2, [rsp+0x20]
000073307ffd7677  vmovaps xmm3, [rsp+0x30]
000073307ffd767d  vmovaps xmm4, [rsp+0x40]
000073307ffd7683  vmovaps xmm5, [rsp+0x50]
000073307ffd7689  vmovaps xmm7, [rsp+0x60]
000073307ffd768f  vmovaps xmm8, [rsp+0x70]
000073307ffd7695  vmovaps xmm9, [rsp+0x80]
000073307ffd769e  vmovaps xmm10, [rsp+0x90]
000073307ffd76a7  vmovaps xmm11, [rsp+0xA0]
000073307ffd76b0  vmovaps xmm12, [rsp+0xB0]
000073307ffd76b9  vmovaps xmm13, [rsp+0xC0]
000073307ffd76c2  vmovaps xmm14, [rsp+0xD0]
000073307ffd76cb  vmovaps xmm15, [rsp+0xE0]
000073307ffd76d4  add rsp, 0xF0
000073307ffd76db  pop r11
000073307ffd76dd  pop r10
000073307ffd76df  pop r9
000073307ffd76e1  pop r8
000073307ffd76e3  pop rsi
000073307ffd76e4  pop rdi
000073307ffd76e5  pop rdx
000073307ffd76e6  pop rcx
000073307ffd76e7  pop rax
000073307ffd76e8  add rsp, 0x08
000073307ffd76ec  jmp 0x000073307FFD5CA7
000073307ffd76f1  sub rsp, 0x08
000073307ffd76f5  push rax
000073307ffd76f6  push rcx
000073307ffd76f7  push rdx
000073307ffd76f8  push rdi
000073307ffd76f9  push rsi
000073307ffd76fa  push r8
000073307ffd76fc  push r9
000073307ffd76fe  push r10
000073307ffd7700  push r11
000073307ffd7702  sub rsp, 0xF0
000073307ffd7709  vmovaps [rsp], xmm0
000073307ffd770e  vmovaps [rsp+0x10], xmm1
000073307ffd7714  vmovaps [rsp+0x20], xmm2
000073307ffd771a  vmovaps [rsp+0x30], xmm3
000073307ffd7720  vmovaps [rsp+0x40], xmm4
000073307ffd7726  vmovaps [rsp+0x50], xmm5
000073307ffd772c  vmovaps [rsp+0x60], xmm6
000073307ffd7732  vmovaps [rsp+0x70], xmm8
000073307ffd7738  vmovaps [rsp+0x80], xmm9
000073307ffd7741  vmovaps [rsp+0x90], xmm10
000073307ffd774a  vmovaps [rsp+0xA0], xmm11
000073307ffd7753  vmovaps [rsp+0xB0], xmm12
000073307ffd775c  vmovaps [rsp+0xC0], xmm13
000073307ffd7765  vmovaps [rsp+0xD0], xmm14
000073307ffd776e  vmovaps [rsp+0xE0], xmm15
000073307ffd7777  sub rsp, 0x30
000073307ffd777b  movaps [rsp], xmm7
000073307ffd777f  movaps [rsp+0x10], xmm4
000073307ffd7784  movaps [rsp+0x20], xmm9
000073307ffd778a  lea rdi, [rsp]
000073307ffd778e  mov esi, 0x00
000073307ffd7793  mov rax, 0x600DE0EC8530
000073307ffd779d  call rax
000073307ffd779f  movaps xmm7, [rsp]
000073307ffd77a3  add rsp, 0x30
000073307ffd77a7  vmovaps xmm0, [rsp]
000073307ffd77ac  vmovaps xmm1, [rsp+0x10]
000073307ffd77b2  vmovaps xmm2, [rsp+0x20]
000073307ffd77b8  vmovaps xmm3, [rsp+0x30]
000073307ffd77be  vmovaps xmm4, [rsp+0x40]
000073307ffd77c4  vmovaps xmm5, [rsp+0x50]
000073307ffd77ca  vmovaps xmm6, [rsp+0x60]
000073307ffd77d0  vmovaps xmm8, [rsp+0x70]
000073307ffd77d6  vmovaps xmm9, [rsp+0x80]
000073307ffd77df  vmovaps xmm10, [rsp+0x90]
000073307ffd77e8  vmovaps xmm11, [rsp+0xA0]
000073307ffd77f1  vmovaps xmm12, [rsp+0xB0]
000073307ffd77fa  vmovaps xmm13, [rsp+0xC0]
000073307ffd7803  vmovaps xmm14, [rsp+0xD0]
000073307ffd780c  vmovaps xmm15, [rsp+0xE0]
000073307ffd7815  add rsp, 0xF0
000073307ffd781c  pop r11
000073307ffd781e  pop r10
000073307ffd7820  pop r9
000073307ffd7822  pop r8
000073307ffd7824  pop rsi
000073307ffd7825  pop rdi
000073307ffd7826  pop rdx
000073307ffd7827  pop rcx
000073307ffd7828  pop rax
000073307ffd7829  add rsp, 0x08
000073307ffd782d  jmp 0x000073307FFD5CD4
000073307ffd7832  sub rsp, 0x08
000073307ffd7836  push rax
000073307ffd7837  push rcx
000073307ffd7838  push rdx
000073307ffd7839  push rdi
000073307ffd783a  push rsi
000073307ffd783b  push r8
000073307ffd783d  push r9
000073307ffd783f  push r10
000073307ffd7841  push r11
000073307ffd7843  sub rsp, 0xF0
000073307ffd784a  vmovaps [rsp], xmm0
000073307ffd784f  vmovaps [rsp+0x10], xmm1
000073307ffd7855  vmovaps [rsp+0x20], xmm2
000073307ffd785b  vmovaps [rsp+0x30], xmm3
000073307ffd7861  vmovaps [rsp+0x40], xmm5
000073307ffd7867  vmovaps [rsp+0x50], xmm6
000073307ffd786d  vmovaps [rsp+0x60], xmm7
000073307ffd7873  vmovaps [rsp+0x70], xmm8
000073307ffd7879  vmovaps [rsp+0x80], xmm9
000073307ffd7882  vmovaps [rsp+0x90], xmm10
000073307ffd788b  vmovaps [rsp+0xA0], xmm11
000073307ffd7894  vmovaps [rsp+0xB0], xmm12
000073307ffd789d  vmovaps [rsp+0xC0], xmm13
000073307ffd78a6  vmovaps [rsp+0xD0], xmm14
000073307ffd78af  vmovaps [rsp+0xE0], xmm15
000073307ffd78b8  sub rsp, 0x30
000073307ffd78bc  movaps [rsp], xmm4
000073307ffd78c0  movaps [rsp+0x10], xmm15
000073307ffd78c6  movaps [rsp+0x20], xmm9
000073307ffd78cc  lea rdi, [rsp]
000073307ffd78d0  mov esi, 0x00
000073307ffd78d5  mov rax, 0x600DE0EC8530
000073307ffd78df  call rax
000073307ffd78e1  movaps xmm4, [rsp]
000073307ffd78e5  add rsp, 0x30
000073307ffd78e9  vmovaps xmm0, [rsp]
000073307ffd78ee  vmovaps xmm1, [rsp+0x10]
000073307ffd78f4  vmovaps xmm2, [rsp+0x20]
000073307ffd78fa  vmovaps xmm3, [rsp+0x30]
000073307ffd7900  vmovaps xmm5, [rsp+0x40]
000073307ffd7906  vmovaps xmm6, [rsp+0x50]
000073307ffd790c  vmovaps xmm7, [rsp+0x60]
000073307ffd7912  vmovaps xmm8, [rsp+0x70]
000073307ffd7918  vmovaps xmm9, [rsp+0x80]
000073307ffd7921  vmovaps xmm10, [rsp+0x90]
000073307ffd792a  vmovaps xmm11, [rsp+0xA0]
000073307ffd7933  vmovaps xmm12, [rsp+0xB0]
000073307ffd793c  vmovaps xmm13, [rsp+0xC0]
000073307ffd7945  vmovaps xmm14, [rsp+0xD0]
000073307ffd794e  vmovaps xmm15, [rsp+0xE0]
000073307ffd7957  add rsp, 0xF0
000073307ffd795e  pop r11
000073307ffd7960  pop r10
000073307ffd7962  pop r9
000073307ffd7964  pop r8
000073307ffd7966  pop rsi
000073307ffd7967  pop rdi
000073307ffd7968  pop rdx
000073307ffd7969  pop rcx
000073307ffd796a  pop rax
000073307ffd796b  add rsp, 0x08
000073307ffd796f  jmp 0x000073307FFD5CF9
000073307ffd7974  call 0x000073307FEE5820
000073307ffd7979  jmp 0x000073307FFD5D06
000073307ffd797e  sub rsp, 0x08
000073307ffd7982  push rax
000073307ffd7983  push rcx
000073307ffd7984  push rdx
000073307ffd7985  push rdi
000073307ffd7986  push rsi
000073307ffd7987  push r8
000073307ffd7989  push r9
000073307ffd798b  push r10
000073307ffd798d  push r11
000073307ffd798f  sub rsp, 0xF0
000073307ffd7996  vmovaps [rsp], xmm0
000073307ffd799b  vmovaps [rsp+0x10], xmm1
000073307ffd79a1  vmovaps [rsp+0x20], xmm2
000073307ffd79a7  vmovaps [rsp+0x30], xmm4
000073307ffd79ad  vmovaps [rsp+0x40], xmm5
000073307ffd79b3  vmovaps [rsp+0x50], xmm6
000073307ffd79b9  vmovaps [rsp+0x60], xmm7
000073307ffd79bf  vmovaps [rsp+0x70], xmm8
000073307ffd79c5  vmovaps [rsp+0x80], xmm9
000073307ffd79ce  vmovaps [rsp+0x90], xmm10
000073307ffd79d7  vmovaps [rsp+0xA0], xmm11
000073307ffd79e0  vmovaps [rsp+0xB0], xmm12
000073307ffd79e9  vmovaps [rsp+0xC0], xmm13
000073307ffd79f2  vmovaps [rsp+0xD0], xmm14
000073307ffd79fb  vmovaps [rsp+0xE0], xmm15
000073307ffd7a04  sub rsp, 0x30
000073307ffd7a08  movaps [rsp], xmm3
000073307ffd7a0c  movaps [rsp+0x10], xmm1
000073307ffd7a11  movaps [rsp+0x20], xmm9
000073307ffd7a17  lea rdi, [rsp]
000073307ffd7a1b  mov esi, 0x00
000073307ffd7a20  mov rax, 0x600DE0EC8530
000073307ffd7a2a  call rax
000073307ffd7a2c  movaps xmm3, [rsp]
000073307ffd7a30  add rsp, 0x30
000073307ffd7a34  vmovaps xmm0, [rsp]
000073307ffd7a39  vmovaps xmm1, [rsp+0x10]
000073307ffd7a3f  vmovaps xmm2, [rsp+0x20]
000073307ffd7a45  vmovaps xmm4, [rsp+0x30]
000073307ffd7a4b  vmovaps xmm5, [rsp+0x40]
000073307ffd7a51  vmovaps xmm6, [rsp+0x50]
000073307ffd7a57  vmovaps xmm7, [rsp+0x60]
000073307ffd7a5d  vmovaps xmm8, [rsp+0x70]
000073307ffd7a63  vmovaps xmm9, [rsp+0x80]
000073307ffd7a6c  vmovaps xmm10, [rsp+0x90]
000073307ffd7a75  vmovaps xmm11, [rsp+0xA0]
000073307ffd7a7e  vmovaps xmm12, [rsp+0xB0]
000073307ffd7a87  vmovaps xmm13, [rsp+0xC0]
000073307ffd7a90  vmovaps xmm14, [rsp+0xD0]
000073307ffd7a99  vmovaps xmm15, [rsp+0xE0]
000073307ffd7aa2  add rsp, 0xF0
000073307ffd7aa9  pop r11
000073307ffd7aab  pop r10
000073307ffd7aad  pop r9
000073307ffd7aaf  pop r8
000073307ffd7ab1  pop rsi
000073307ffd7ab2  pop rdi
000073307ffd7ab3  pop rdx
000073307ffd7ab4  pop rcx
000073307ffd7ab5  pop rax
000073307ffd7ab6  add rsp, 0x08
000073307ffd7aba  jmp 0x000073307FFD5D43
000073307ffd7abf  sub rsp, 0x08
000073307ffd7ac3  push rax
000073307ffd7ac4  push rcx
000073307ffd7ac5  push rdx
000073307ffd7ac6  push rdi
000073307ffd7ac7  push rsi
000073307ffd7ac8  push r8
000073307ffd7aca  push r9
000073307ffd7acc  push r10
000073307ffd7ace  push r11
000073307ffd7ad0  sub rsp, 0xF0
000073307ffd7ad7  vmovaps [rsp], xmm0
000073307ffd7adc  vmovaps [rsp+0x10], xmm2
000073307ffd7ae2  vmovaps [rsp+0x20], xmm3
000073307ffd7ae8  vmovaps [rsp+0x30], xmm4
000073307ffd7aee  vmovaps [rsp+0x40], xmm5
000073307ffd7af4  vmovaps [rsp+0x50], xmm6
000073307ffd7afa  vmovaps [rsp+0x60], xmm7
000073307ffd7b00  vmovaps [rsp+0x70], xmm8
000073307ffd7b06  vmovaps [rsp+0x80], xmm9
000073307ffd7b0f  vmovaps [rsp+0x90], xmm10
000073307ffd7b18  vmovaps [rsp+0xA0], xmm11
000073307ffd7b21  vmovaps [rsp+0xB0], xmm12
000073307ffd7b2a  vmovaps [rsp+0xC0], xmm13
000073307ffd7b33  vmovaps [rsp+0xD0], xmm14
000073307ffd7b3c  vmovaps [rsp+0xE0], xmm15
000073307ffd7b45  sub rsp, 0x30
000073307ffd7b49  movaps [rsp], xmm1
000073307ffd7b4d  movaps [rsp+0x10], xmm15
000073307ffd7b53  movaps [rsp+0x20], xmm9
000073307ffd7b59  lea rdi, [rsp]
000073307ffd7b5d  mov esi, 0x00
000073307ffd7b62  mov rax, 0x600DE0EC8530
000073307ffd7b6c  call rax
000073307ffd7b6e  movaps xmm1, [rsp]
000073307ffd7b72  add rsp, 0x30
000073307ffd7b76  vmovaps xmm0, [rsp]
000073307ffd7b7b  vmovaps xmm2, [rsp+0x10]
000073307ffd7b81  vmovaps xmm3, [rsp+0x20]
000073307ffd7b87  vmovaps xmm4, [rsp+0x30]
000073307ffd7b8d  vmovaps xmm5, [rsp+0x40]
000073307ffd7b93  vmovaps xmm6, [rsp+0x50]
000073307ffd7b99  vmovaps xmm7, [rsp+0x60]
000073307ffd7b9f  vmovaps xmm8, [rsp+0x70]
000073307ffd7ba5  vmovaps xmm9, [rsp+0x80]
000073307ffd7bae  vmovaps xmm10, [rsp+0x90]
000073307ffd7bb7  vmovaps xmm11, [rsp+0xA0]
000073307ffd7bc0  vmovaps xmm12, [rsp+0xB0]
000073307ffd7bc9  vmovaps xmm13, [rsp+0xC0]
000073307ffd7bd2  vmovaps xmm14, [rsp+0xD0]
000073307ffd7bdb  vmovaps xmm15, [rsp+0xE0]
000073307ffd7be4  add rsp, 0xF0
000073307ffd7beb  pop r11
000073307ffd7bed  pop r10
000073307ffd7bef  pop r9
000073307ffd7bf1  pop r8
000073307ffd7bf3  pop rsi
000073307ffd7bf4  pop rdi
000073307ffd7bf5  pop rdx
000073307ffd7bf6  pop rcx
000073307ffd7bf7  pop rax
000073307ffd7bf8  add rsp, 0x08
000073307ffd7bfc  jmp 0x000073307FFD5DCB
000073307ffd7c01  call 0x000073307FEE5820
000073307ffd7c06  jmp 0x000073307FFD5DD8
000073307ffd7c0b  sub rsp, 0x08
000073307ffd7c0f  push rax
000073307ffd7c10  push rcx
000073307ffd7c11  push rdx
000073307ffd7c12  push rdi
000073307ffd7c13  push rsi
000073307ffd7c14  push r8
000073307ffd7c16  push r9
000073307ffd7c18  push r10
000073307ffd7c1a  push r11
000073307ffd7c1c  sub rsp, 0xF0
000073307ffd7c23  vmovaps [rsp], xmm0
000073307ffd7c28  vmovaps [rsp+0x10], xmm2
000073307ffd7c2e  vmovaps [rsp+0x20], xmm3
000073307ffd7c34  vmovaps [rsp+0x30], xmm4
000073307ffd7c3a  vmovaps [rsp+0x40], xmm5
000073307ffd7c40  vmovaps [rsp+0x50], xmm6
000073307ffd7c46  vmovaps [rsp+0x60], xmm7
000073307ffd7c4c  vmovaps [rsp+0x70], xmm8
000073307ffd7c52  vmovaps [rsp+0x80], xmm9
000073307ffd7c5b  vmovaps [rsp+0x90], xmm10
000073307ffd7c64  vmovaps [rsp+0xA0], xmm11
000073307ffd7c6d  vmovaps [rsp+0xB0], xmm12
000073307ffd7c76  vmovaps [rsp+0xC0], xmm13
000073307ffd7c7f  vmovaps [rsp+0xD0], xmm14
000073307ffd7c88  vmovaps [rsp+0xE0], xmm15
000073307ffd7c91  sub rsp, 0x30
000073307ffd7c95  movaps [rsp], xmm1
000073307ffd7c99  movaps [rsp+0x10], xmm5
000073307ffd7c9e  movaps [rsp+0x20], xmm7
000073307ffd7ca3  lea rdi, [rsp]
000073307ffd7ca7  mov esi, 0x00
000073307ffd7cac  mov rax, 0x600DE0EC8530
000073307ffd7cb6  call rax
000073307ffd7cb8  movaps xmm1, [rsp]
000073307ffd7cbc  add rsp, 0x30
000073307ffd7cc0  vmovaps xmm0, [rsp]
000073307ffd7cc5  vmovaps xmm2, [rsp+0x10]
000073307ffd7ccb  vmovaps xmm3, [rsp+0x20]
000073307ffd7cd1  vmovaps xmm4, [rsp+0x30]
000073307ffd7cd7  vmovaps xmm5, [rsp+0x40]
000073307ffd7cdd  vmovaps xmm6, [rsp+0x50]
000073307ffd7ce3  vmovaps xmm7, [rsp+0x60]
000073307ffd7ce9  vmovaps xmm8, [rsp+0x70]
000073307ffd7cef  vmovaps xmm9, [rsp+0x80]
000073307ffd7cf8  vmovaps xmm10, [rsp+0x90]
000073307ffd7d01  vmovaps xmm11, [rsp+0xA0]
000073307ffd7d0a  vmovaps xmm12, [rsp+0xB0]
000073307ffd7d13  vmovaps xmm13, [rsp+0xC0]
000073307ffd7d1c  vmovaps xmm14, [rsp+0xD0]
000073307ffd7d25  vmovaps xmm15, [rsp+0xE0]
000073307ffd7d2e  add rsp, 0xF0
000073307ffd7d35  pop r11
000073307ffd7d37  pop r10
000073307ffd7d39  pop r9
000073307ffd7d3b  pop r8
000073307ffd7d3d  pop rsi
000073307ffd7d3e  pop rdi
000073307ffd7d3f  pop rdx
000073307ffd7d40  pop rcx
000073307ffd7d41  pop rax
000073307ffd7d42  add rsp, 0x08
000073307ffd7d46  jmp 0x000073307FFD5E7D
000073307ffd7d4b  sub rsp, 0x08
000073307ffd7d4f  push rax
000073307ffd7d50  push rcx
000073307ffd7d51  push rdx
000073307ffd7d52  push rdi
000073307ffd7d53  push rsi
000073307ffd7d54  push r8
000073307ffd7d56  push r9
000073307ffd7d58  push r10
000073307ffd7d5a  push r11
000073307ffd7d5c  sub rsp, 0xF0
000073307ffd7d63  vmovaps [rsp], xmm0
000073307ffd7d68  vmovaps [rsp+0x10], xmm1
000073307ffd7d6e  vmovaps [rsp+0x20], xmm2
000073307ffd7d74  vmovaps [rsp+0x30], xmm3
000073307ffd7d7a  vmovaps [rsp+0x40], xmm4
000073307ffd7d80  vmovaps [rsp+0x50], xmm5
000073307ffd7d86  vmovaps [rsp+0x60], xmm6
000073307ffd7d8c  vmovaps [rsp+0x70], xmm8
000073307ffd7d92  vmovaps [rsp+0x80], xmm9
000073307ffd7d9b  vmovaps [rsp+0x90], xmm10
000073307ffd7da4  vmovaps [rsp+0xA0], xmm11
000073307ffd7dad  vmovaps [rsp+0xB0], xmm12
000073307ffd7db6  vmovaps [rsp+0xC0], xmm13
000073307ffd7dbf  vmovaps [rsp+0xD0], xmm14
000073307ffd7dc8  vmovaps [rsp+0xE0], xmm15
000073307ffd7dd1  sub rsp, 0x30
000073307ffd7dd5  movaps [rsp], xmm7
000073307ffd7dd9  movaps [rsp+0x10], xmm5
000073307ffd7dde  movaps [rsp+0x20], xmm15
000073307ffd7de4  lea rdi, [rsp]
000073307ffd7de8  mov esi, 0x00
000073307ffd7ded  mov rax, 0x600DE0EC8530
000073307ffd7df7  call rax
000073307ffd7df9  movaps xmm7, [rsp]
000073307ffd7dfd  add rsp, 0x30
000073307ffd7e01  vmovaps xmm0, [rsp]
000073307ffd7e06  vmovaps xmm1, [rsp+0x10]
000073307ffd7e0c  vmovaps xmm2, [rsp+0x20]
000073307ffd7e12  vmovaps xmm3, [rsp+0x30]
000073307ffd7e18  vmovaps xmm4, [rsp+0x40]
000073307ffd7e1e  vmovaps xmm5, [rsp+0x50]
000073307ffd7e24  vmovaps xmm6, [rsp+0x60]
000073307ffd7e2a  vmovaps xmm8, [rsp+0x70]
000073307ffd7e30  vmovaps xmm9, [rsp+0x80]
000073307ffd7e39  vmovaps xmm10, [rsp+0x90]
000073307ffd7e42  vmovaps xmm11, [rsp+0xA0]
000073307ffd7e4b  vmovaps xmm12, [rsp+0xB0]
000073307ffd7e54  vmovaps xmm13, [rsp+0xC0]
000073307ffd7e5d  vmovaps xmm14, [rsp+0xD0]
000073307ffd7e66  vmovaps xmm15, [rsp+0xE0]
000073307ffd7e6f  add rsp, 0xF0
000073307ffd7e76  pop r11
000073307ffd7e78  pop r10
000073307ffd7e7a  pop r9
000073307ffd7e7c  pop r8
000073307ffd7e7e  pop rsi
000073307ffd7e7f  pop rdi
000073307ffd7e80  pop rdx
000073307ffd7e81  pop rcx
000073307ffd7e82  pop rax
000073307ffd7e83  add rsp, 0x08
000073307ffd7e87  jmp 0x000073307FFD5EB3
000073307ffd7e8c  call 0x000073307FED64F0
000073307ffd7e91  jmp 0x000073307FFD5EC0
000073307ffd7e96  sub rsp, 0x08
000073307ffd7e9a  push rax
000073307ffd7e9b  push rcx
000073307ffd7e9c  push rdx
000073307ffd7e9d  push rdi
000073307ffd7e9e  push rsi
000073307ffd7e9f  push r8
000073307ffd7ea1  push r9
000073307ffd7ea3  push r10
000073307ffd7ea5  push r11
000073307ffd7ea7  sub rsp, 0xF0
000073307ffd7eae  vmovaps [rsp], xmm0
000073307ffd7eb3  vmovaps [rsp+0x10], xmm1
000073307ffd7eb9  vmovaps [rsp+0x20], xmm2
000073307ffd7ebf  vmovaps [rsp+0x30], xmm3
000073307ffd7ec5  vmovaps [rsp+0x40], xmm4
000073307ffd7ecb  vmovaps [rsp+0x50], xmm5
000073307ffd7ed1  vmovaps [rsp+0x60], xmm6
000073307ffd7ed7  vmovaps [rsp+0x70], xmm7
000073307ffd7edd  vmovaps [rsp+0x80], xmm8
000073307ffd7ee6  vmovaps [rsp+0x90], xmm9
000073307ffd7eef  vmovaps [rsp+0xA0], xmm10
000073307ffd7ef8  vmovaps [rsp+0xB0], xmm11
000073307ffd7f01  vmovaps [rsp+0xC0], xmm12
000073307ffd7f0a  vmovaps [rsp+0xD0], xmm13
000073307ffd7f13  vmovaps [rsp+0xE0], xmm14
000073307ffd7f1c  sub rsp, 0x30
000073307ffd7f20  movaps [rsp], xmm15
000073307ffd7f25  movaps [rsp+0x10], xmm5
000073307ffd7f2a  movaps [rsp+0x20], xmm3
000073307ffd7f2f  lea rdi, [rsp]
000073307ffd7f33  mov esi, 0x00
000073307ffd7f38  mov rax, 0x600DE0EC8530
000073307ffd7f42  call rax
000073307ffd7f44  movaps xmm15, [rsp]
000073307ffd7f49  add rsp, 0x30
000073307ffd7f4d  vmovaps xmm0, [rsp]
000073307ffd7f52  vmovaps xmm1, [rsp+0x10]
000073307ffd7f58  vmovaps xmm2, [rsp+0x20]
000073307ffd7f5e  vmovaps xmm3, [rsp+0x30]
000073307ffd7f64  vmovaps xmm4, [rsp+0x40]
000073307ffd7f6a  vmovaps xmm5, [rsp+0x50]
000073307ffd7f70  vmovaps xmm6, [rsp+0x60]
000073307ffd7f76  vmovaps xmm7, [rsp+0x70]
000073307ffd7f7c  vmovaps xmm8, [rsp+0x80]
000073307ffd7f85  vmovaps xmm9, [rsp+0x90]
000073307ffd7f8e  vmovaps xmm10, [rsp+0xA0]
000073307ffd7f97  vmovaps xmm11, [rsp+0xB0]
000073307ffd7fa0  vmovaps xmm12, [rsp+0xC0]
000073307ffd7fa9  vmovaps xmm13, [rsp+0xD0]
000073307ffd7fb2  vmovaps xmm14, [rsp+0xE0]
000073307ffd7fbb  add rsp, 0xF0
000073307ffd7fc2  pop r11
000073307ffd7fc4  pop r10
000073307ffd7fc6  pop r9
000073307ffd7fc8  pop r8
000073307ffd7fca  pop rsi
000073307ffd7fcb  pop rdi
000073307ffd7fcc  pop rdx
000073307ffd7fcd  pop rcx
000073307ffd7fce  pop rax
000073307ffd7fcf  add rsp, 0x08
000073307ffd7fd3  jmp 0x000073307FFD5EE6
000073307ffd7fd8  sub rsp, 0x08
000073307ffd7fdc  push rax
000073307ffd7fdd  push rcx
000073307ffd7fde  push rdx
000073307ffd7fdf  push rdi
000073307ffd7fe0  push rsi
000073307ffd7fe1  push r8
000073307ffd7fe3  push r9
000073307ffd7fe5  push r10
000073307ffd7fe7  push r11
000073307ffd7fe9  sub rsp, 0xF0
000073307ffd7ff0  vmovaps [rsp], xmm0
000073307ffd7ff5  vmovaps [rsp+0x10], xmm2
000073307ffd7ffb  vmovaps [rsp+0x20], xmm3
000073307ffd8001  vmovaps [rsp+0x30], xmm4
000073307ffd8007  vmovaps [rsp+0x40], xmm5
000073307ffd800d  vmovaps [rsp+0x50], xmm6
000073307ffd8013  vmovaps [rsp+0x60], xmm7
000073307ffd8019  vmovaps [rsp+0x70], xmm8
000073307ffd801f  vmovaps [rsp+0x80], xmm9
000073307ffd8028  vmovaps [rsp+0x90], xmm10
000073307ffd8031  vmovaps [rsp+0xA0], xmm11
000073307ffd803a  vmovaps [rsp+0xB0], xmm12
000073307ffd8043  vmovaps [rsp+0xC0], xmm13
000073307ffd804c  vmovaps [rsp+0xD0], xmm14
000073307ffd8055  vmovaps [rsp+0xE0], xmm15
000073307ffd805e  sub rsp, 0x30
000073307ffd8062  movaps [rsp], xmm1
000073307ffd8066  movaps [rsp+0x10], xmm5
000073307ffd806b  movaps [rsp+0x20], xmm4
000073307ffd8070  lea rdi, [rsp]
000073307ffd8074  mov esi, 0x00
000073307ffd8079  mov rax, 0x600DE0EC8530
000073307ffd8083  call rax
000073307ffd8085  movaps xmm1, [rsp]
000073307ffd8089  add rsp, 0x30
000073307ffd808d  vmovaps xmm0, [rsp]
000073307ffd8092  vmovaps xmm2, [rsp+0x10]
000073307ffd8098  vmovaps xmm3, [rsp+0x20]
000073307ffd809e  vmovaps xmm4, [rsp+0x30]
000073307ffd80a4  vmovaps xmm5, [rsp+0x40]
000073307ffd80aa  vmovaps xmm6, [rsp+0x50]
000073307ffd80b0  vmovaps xmm7, [rsp+0x60]
000073307ffd80b6  vmovaps xmm8, [rsp+0x70]
000073307ffd80bc  vmovaps xmm9, [rsp+0x80]
000073307ffd80c5  vmovaps xmm10, [rsp+0x90]
000073307ffd80ce  vmovaps xmm11, [rsp+0xA0]
000073307ffd80d7  vmovaps xmm12, [rsp+0xB0]
000073307ffd80e0  vmovaps xmm13, [rsp+0xC0]
000073307ffd80e9  vmovaps xmm14, [rsp+0xD0]
000073307ffd80f2  vmovaps xmm15, [rsp+0xE0]
000073307ffd80fb  add rsp, 0xF0
000073307ffd8102  pop r11
000073307ffd8104  pop r10
000073307ffd8106  pop r9
000073307ffd8108  pop r8
000073307ffd810a  pop rsi
000073307ffd810b  pop rdi
000073307ffd810c  pop rdx
000073307ffd810d  pop rcx
000073307ffd810e  pop rax
000073307ffd810f  add rsp, 0x08
000073307ffd8113  jmp 0x000073307FFD5F06
000073307ffd8118  sub rsp, 0x08
000073307ffd811c  push rax
000073307ffd811d  push rcx
000073307ffd811e  push rdx
000073307ffd811f  push rdi
000073307ffd8120  push rsi
000073307ffd8121  push r8
000073307ffd8123  push r9
000073307ffd8125  push r10
000073307ffd8127  push r11
000073307ffd8129  sub rsp, 0xF0
000073307ffd8130  vmovaps [rsp], xmm0
000073307ffd8135  vmovaps [rsp+0x10], xmm1
000073307ffd813b  vmovaps [rsp+0x20], xmm2
000073307ffd8141  vmovaps [rsp+0x30], xmm3
000073307ffd8147  vmovaps [rsp+0x40], xmm5
000073307ffd814d  vmovaps [rsp+0x50], xmm6
000073307ffd8153  vmovaps [rsp+0x60], xmm7
000073307ffd8159  vmovaps [rsp+0x70], xmm8
000073307ffd815f  vmovaps [rsp+0x80], xmm9
000073307ffd8168  vmovaps [rsp+0x90], xmm10
000073307ffd8171  vmovaps [rsp+0xA0], xmm11
000073307ffd817a  vmovaps [rsp+0xB0], xmm12
000073307ffd8183  vmovaps [rsp+0xC0], xmm13
000073307ffd818c  vmovaps [rsp+0xD0], xmm14
000073307ffd8195  vmovaps [rsp+0xE0], xmm15
000073307ffd819e  sub rsp, 0x30
000073307ffd81a2  movaps [rsp], xmm4
000073307ffd81a6  movaps [rsp+0x10], xmm3
000073307ffd81ab  movaps [rsp+0x20], xmm5
000073307ffd81b0  lea rdi, [rsp]
000073307ffd81b4  mov esi, 0x00
000073307ffd81b9  mov rax, 0x600DE0EC8530
000073307ffd81c3  call rax
000073307ffd81c5  movaps xmm4, [rsp]
000073307ffd81c9  add rsp, 0x30
000073307ffd81cd  vmovaps xmm0, [rsp]
000073307ffd81d2  vmovaps xmm1, [rsp+0x10]
000073307ffd81d8  vmovaps xmm2, [rsp+0x20]
000073307ffd81de  vmovaps xmm3, [rsp+0x30]
000073307ffd81e4  vmovaps xmm5, [rsp+0x40]
000073307ffd81ea  vmovaps xmm6, [rsp+0x50]
000073307ffd81f0  vmovaps xmm7, [rsp+0x60]
000073307ffd81f6  vmovaps xmm8, [rsp+0x70]
000073307ffd81fc  vmovaps xmm9, [rsp+0x80]
000073307ffd8205  vmovaps xmm10, [rsp+0x90]
000073307ffd820e  vmovaps xmm11, [rsp+0xA0]
000073307ffd8217  vmovaps xmm12, [rsp+0xB0]
000073307ffd8220  vmovaps xmm13, [rsp+0xC0]
000073307ffd8229  vmovaps xmm14, [rsp+0xD0]
000073307ffd8232  vmovaps xmm15, [rsp+0xE0]
000073307ffd823b  add rsp, 0xF0
000073307ffd8242  pop r11
000073307ffd8244  pop r10
000073307ffd8246  pop r9
000073307ffd8248  pop r8
000073307ffd824a  pop rsi
000073307ffd824b  pop rdi
000073307ffd824c  pop rdx
000073307ffd824d  pop rcx
000073307ffd824e  pop rax
000073307ffd824f  add rsp, 0x08
000073307ffd8253  jmp 0x000073307FFD5F54
000073307ffd8258  call 0x000073307FED64F0
000073307ffd825d  jmp 0x000073307FFD5F61
000073307ffd8262  sub rsp, 0x08
000073307ffd8266  push rax
000073307ffd8267  push rcx
000073307ffd8268  push rdx
000073307ffd8269  push rdi
000073307ffd826a  push rsi
000073307ffd826b  push r8
000073307ffd826d  push r9
000073307ffd826f  push r10
000073307ffd8271  push r11
000073307ffd8273  sub rsp, 0xF0
000073307ffd827a  vmovaps [rsp], xmm0
000073307ffd827f  vmovaps [rsp+0x10], xmm1
000073307ffd8285  vmovaps [rsp+0x20], xmm2
000073307ffd828b  vmovaps [rsp+0x30], xmm3
000073307ffd8291  vmovaps [rsp+0x40], xmm4
000073307ffd8297  vmovaps [rsp+0x50], xmm6
000073307ffd829d  vmovaps [rsp+0x60], xmm7
000073307ffd82a3  vmovaps [rsp+0x70], xmm8
000073307ffd82a9  vmovaps [rsp+0x80], xmm9
000073307ffd82b2  vmovaps [rsp+0x90], xmm10
000073307ffd82bb  vmovaps [rsp+0xA0], xmm11
000073307ffd82c4  vmovaps [rsp+0xB0], xmm12
000073307ffd82cd  vmovaps [rsp+0xC0], xmm13
000073307ffd82d6  vmovaps [rsp+0xD0], xmm14
000073307ffd82df  vmovaps [rsp+0xE0], xmm15
000073307ffd82e8  sub rsp, 0x30
000073307ffd82ec  movaps [rsp], xmm5
000073307ffd82f0  movaps [rsp+0x10], xmm6
000073307ffd82f5  movaps [rsp+0x20], xmm3
000073307ffd82fa  lea rdi, [rsp]
000073307ffd82fe  mov esi, 0x00
000073307ffd8303  mov rax, 0x600DE0EC8530
000073307ffd830d  call rax
000073307ffd830f  movaps xmm5, [rsp]
000073307ffd8313  add rsp, 0x30
000073307ffd8317  vmovaps xmm0, [rsp]
000073307ffd831c  vmovaps xmm1, [rsp+0x10]
000073307ffd8322  vmovaps xmm2, [rsp+0x20]
000073307ffd8328  vmovaps xmm3, [rsp+0x30]
000073307ffd832e  vmovaps xmm4, [rsp+0x40]
000073307ffd8334  vmovaps xmm6, [rsp+0x50]
000073307ffd833a  vmovaps xmm7, [rsp+0x60]
000073307ffd8340  vmovaps xmm8, [rsp+0x70]
000073307ffd8346  vmovaps xmm9, [rsp+0x80]
000073307ffd834f  vmovaps xmm10, [rsp+0x90]
000073307ffd8358  vmovaps xmm11, [rsp+0xA0]
000073307ffd8361  vmovaps xmm12, [rsp+0xB0]
000073307ffd836a  vmovaps xmm13, [rsp+0xC0]
000073307ffd8373  vmovaps xmm14, [rsp+0xD0]
000073307ffd837c  vmovaps xmm15, [rsp+0xE0]
000073307ffd8385  add rsp, 0xF0
000073307ffd838c  pop r11
000073307ffd838e  pop r10
000073307ffd8390  pop r9
000073307ffd8392  pop r8
000073307ffd8394  pop rsi
000073307ffd8395  pop rdi
000073307ffd8396  pop rdx
000073307ffd8397  pop rcx
000073307ffd8398  pop rax
000073307ffd8399  add rsp, 0x08
000073307ffd839d  jmp 0x000073307FFD5F87
000073307ffd83a2  sub rsp, 0x08
000073307ffd83a6  push rax
000073307ffd83a7  push rcx
000073307ffd83a8  push rdx
000073307ffd83a9  push rdi
000073307ffd83aa  push rsi
000073307ffd83ab  push r8
000073307ffd83ad  push r9
000073307ffd83af  push r10
000073307ffd83b1  push r11
000073307ffd83b3  sub rsp, 0xF0
000073307ffd83ba  vmovaps [rsp], xmm0
000073307ffd83bf  vmovaps [rsp+0x10], xmm1
000073307ffd83c5  vmovaps [rsp+0x20], xmm2
000073307ffd83cb  vmovaps [rsp+0x30], xmm3
000073307ffd83d1  vmovaps [rsp+0x40], xmm4
000073307ffd83d7  vmovaps [rsp+0x50], xmm5
000073307ffd83dd  vmovaps [rsp+0x60], xmm7
000073307ffd83e3  vmovaps [rsp+0x70], xmm8
000073307ffd83e9  vmovaps [rsp+0x80], xmm9
000073307ffd83f2  vmovaps [rsp+0x90], xmm10
000073307ffd83fb  vmovaps [rsp+0xA0], xmm11
000073307ffd8404  vmovaps [rsp+0xB0], xmm12
000073307ffd840d  vmovaps [rsp+0xC0], xmm13
000073307ffd8416  vmovaps [rsp+0xD0], xmm14
000073307ffd841f  vmovaps [rsp+0xE0], xmm15
000073307ffd8428  sub rsp, 0x30
000073307ffd842c  movaps [rsp], xmm6
000073307ffd8430  movaps [rsp+0x10], xmm9
000073307ffd8436  movaps [rsp+0x20], xmm1
000073307ffd843b  lea rdi, [rsp]
000073307ffd843f  mov esi, 0x00
000073307ffd8444  mov rax, 0x600DE0EC8530
000073307ffd844e  call rax
000073307ffd8450  movaps xmm6, [rsp]
000073307ffd8454  add rsp, 0x30
000073307ffd8458  vmovaps xmm0, [rsp]
000073307ffd845d  vmovaps xmm1, [rsp+0x10]
000073307ffd8463  vmovaps xmm2, [rsp+0x20]
000073307ffd8469  vmovaps xmm3, [rsp+0x30]
000073307ffd846f  vmovaps xmm4, [rsp+0x40]
000073307ffd8475  vmovaps xmm5, [rsp+0x50]
000073307ffd847b  vmovaps xmm7, [rsp+0x60]
000073307ffd8481  vmovaps xmm8, [rsp+0x70]
000073307ffd8487  vmovaps xmm9, [rsp+0x80]
000073307ffd8490  vmovaps xmm10, [rsp+0x90]
000073307ffd8499  vmovaps xmm11, [rsp+0xA0]
000073307ffd84a2  vmovaps xmm12, [rsp+0xB0]
000073307ffd84ab  vmovaps xmm13, [rsp+0xC0]
000073307ffd84b4  vmovaps xmm14, [rsp+0xD0]
000073307ffd84bd  vmovaps xmm15, [rsp+0xE0]
000073307ffd84c6  add rsp, 0xF0
000073307ffd84cd  pop r11
000073307ffd84cf  pop r10
000073307ffd84d1  pop r9
000073307ffd84d3  pop r8
000073307ffd84d5  pop rsi
000073307ffd84d6  pop rdi
000073307ffd84d7  pop rdx
000073307ffd84d8  pop rcx
000073307ffd84d9  pop rax
000073307ffd84da  add rsp, 0x08
000073307ffd84de  jmp 0x000073307FFD5FAB
000073307ffd84e3  sub rsp, 0x08
000073307ffd84e7  push rax
000073307ffd84e8  push rcx
000073307ffd84e9  push rdx
000073307ffd84ea  push rdi
000073307ffd84eb  push rsi
000073307ffd84ec  push r8
000073307ffd84ee  push r9
000073307ffd84f0  push r10
000073307ffd84f2  push r11
000073307ffd84f4  sub rsp, 0xF0
000073307ffd84fb  vmovaps [rsp], xmm0
000073307ffd8500  vmovaps [rsp+0x10], xmm1
000073307ffd8506  vmovaps [rsp+0x20], xmm2
000073307ffd850c  vmovaps [rsp+0x30], xmm3
000073307ffd8512  vmovaps [rsp+0x40], xmm4
000073307ffd8518  vmovaps [rsp+0x50], xmm5
000073307ffd851e  vmovaps [rsp+0x60], xmm6
000073307ffd8524  vmovaps [rsp+0x70], xmm7
000073307ffd852a  vmovaps [rsp+0x80], xmm8
000073307ffd8533  vmovaps [rsp+0x90], xmm10
000073307ffd853c  vmovaps [rsp+0xA0], xmm11
000073307ffd8545  vmovaps [rsp+0xB0], xmm12
000073307ffd854e  vmovaps [rsp+0xC0], xmm13
000073307ffd8557  vmovaps [rsp+0xD0], xmm14
000073307ffd8560  vmovaps [rsp+0xE0], xmm15
000073307ffd8569  sub rsp, 0x30
000073307ffd856d  movaps [rsp], xmm9
000073307ffd8572  movaps [rsp+0x10], xmm3
000073307ffd8577  movaps [rsp+0x20], xmm1
000073307ffd857c  lea rdi, [rsp]
000073307ffd8580  mov esi, 0x00
000073307ffd8585  mov rax, 0x600DE0EC8530
000073307ffd858f  call rax
000073307ffd8591  movaps xmm9, [rsp]
000073307ffd8596  add rsp, 0x30
000073307ffd859a  vmovaps xmm0, [rsp]
000073307ffd859f  vmovaps xmm1, [rsp+0x10]
000073307ffd85a5  vmovaps xmm2, [rsp+0x20]
000073307ffd85ab  vmovaps xmm3, [rsp+0x30]
000073307ffd85b1  vmovaps xmm4, [rsp+0x40]
000073307ffd85b7  vmovaps xmm5, [rsp+0x50]
000073307ffd85bd  vmovaps xmm6, [rsp+0x60]
000073307ffd85c3  vmovaps xmm7, [rsp+0x70]
000073307ffd85c9  vmovaps xmm8, [rsp+0x80]
000073307ffd85d2  vmovaps xmm10, [rsp+0x90]
000073307ffd85db  vmovaps xmm11, [rsp+0xA0]
000073307ffd85e4  vmovaps xmm12, [rsp+0xB0]
000073307ffd85ed  vmovaps xmm13, [rsp+0xC0]
000073307ffd85f6  vmovaps xmm14, [rsp+0xD0]
000073307ffd85ff  vmovaps xmm15, [rsp+0xE0]
000073307ffd8608  add rsp, 0xF0
000073307ffd860f  pop r11
000073307ffd8611  pop r10
000073307ffd8613  pop r9
000073307ffd8615  pop r8
000073307ffd8617  pop rsi
000073307ffd8618  pop rdi
000073307ffd8619  pop rdx
000073307ffd861a  pop rcx
000073307ffd861b  pop rax
000073307ffd861c  add rsp, 0x08
000073307ffd8620  jmp 0x000073307FFD5FF7
000073307ffd8625  call 0x000073307FED64F0
000073307ffd862a  jmp 0x000073307FFD6004
000073307ffd862f  sub rsp, 0x08
000073307ffd8633  push rax
000073307ffd8634  push rcx
000073307ffd8635  push rdx
000073307ffd8636  push rdi
000073307ffd8637  push rsi
000073307ffd8638  push r8
000073307ffd863a  push r9
000073307ffd863c  push r10
000073307ffd863e  push r11
000073307ffd8640  sub rsp, 0xF0
000073307ffd8647  vmovaps [rsp], xmm0
000073307ffd864c  vmovaps [rsp+0x10], xmm1
000073307ffd8652  vmovaps [rsp+0x20], xmm2
000073307ffd8658  vmovaps [rsp+0x30], xmm3
000073307ffd865e  vmovaps [rsp+0x40], xmm4
000073307ffd8664  vmovaps [rsp+0x50], xmm5
000073307ffd866a  vmovaps [rsp+0x60], xmm6
000073307ffd8670  vmovaps [rsp+0x70], xmm7
000073307ffd8676  vmovaps [rsp+0x80], xmm8
000073307ffd867f  vmovaps [rsp+0x90], xmm9
000073307ffd8688  vmovaps [rsp+0xA0], xmm10
000073307ffd8691  vmovaps [rsp+0xB0], xmm11
000073307ffd869a  vmovaps [rsp+0xC0], xmm12
000073307ffd86a3  vmovaps [rsp+0xD0], xmm13
000073307ffd86ac  vmovaps [rsp+0xE0], xmm14
000073307ffd86b5  sub rsp, 0x30
000073307ffd86b9  movaps [rsp], xmm15
000073307ffd86be  movaps [rsp+0x10], xmm3
000073307ffd86c3  movaps [rsp+0x20], xmm7
000073307ffd86c8  lea rdi, [rsp]
000073307ffd86cc  mov esi, 0x00
000073307ffd86d1  mov rax, 0x600DE0EC8530
000073307ffd86db  call rax
000073307ffd86dd  movaps xmm15, [rsp]
000073307ffd86e2  add rsp, 0x30
000073307ffd86e6  vmovaps xmm0, [rsp]
000073307ffd86eb  vmovaps xmm1, [rsp+0x10]
000073307ffd86f1  vmovaps xmm2, [rsp+0x20]
000073307ffd86f7  vmovaps xmm3, [rsp+0x30]
000073307ffd86fd  vmovaps xmm4, [rsp+0x40]
000073307ffd8703  vmovaps xmm5, [rsp+0x50]
000073307ffd8709  vmovaps xmm6, [rsp+0x60]
000073307ffd870f  vmovaps xmm7, [rsp+0x70]
000073307ffd8715  vmovaps xmm8, [rsp+0x80]
000073307ffd871e  vmovaps xmm9, [rsp+0x90]
000073307ffd8727  vmovaps xmm10, [rsp+0xA0]
000073307ffd8730  vmovaps xmm11, [rsp+0xB0]
000073307ffd8739  vmovaps xmm12, [rsp+0xC0]
000073307ffd8742  vmovaps xmm13, [rsp+0xD0]
000073307ffd874b  vmovaps xmm14, [rsp+0xE0]
000073307ffd8754  add rsp, 0xF0
000073307ffd875b  pop r11
000073307ffd875d  pop r10
000073307ffd875f  pop r9
000073307ffd8761  pop r8
000073307ffd8763  pop rsi
000073307ffd8764  pop rdi
000073307ffd8765  pop rdx
000073307ffd8766  pop rcx
000073307ffd8767  pop rax
000073307ffd8768  add rsp, 0x08
000073307ffd876c  jmp 0x000073307FFD6030
000073307ffd8771  sub rsp, 0x08
000073307ffd8775  push rax
000073307ffd8776  push rcx
000073307ffd8777  push rdx
000073307ffd8778  push rdi
000073307ffd8779  push rsi
000073307ffd877a  push r8
000073307ffd877c  push r9
000073307ffd877e  push r10
000073307ffd8780  push r11
000073307ffd8782  sub rsp, 0xF0
000073307ffd8789  vmovaps [rsp], xmm0
000073307ffd878e  vmovaps [rsp+0x10], xmm1
000073307ffd8794  vmovaps [rsp+0x20], xmm2
000073307ffd879a  vmovaps [rsp+0x30], xmm4
000073307ffd87a0  vmovaps [rsp+0x40], xmm5
000073307ffd87a6  vmovaps [rsp+0x50], xmm6
000073307ffd87ac  vmovaps [rsp+0x60], xmm7
000073307ffd87b2  vmovaps [rsp+0x70], xmm8
000073307ffd87b8  vmovaps [rsp+0x80], xmm9
000073307ffd87c1  vmovaps [rsp+0x90], xmm10
000073307ffd87ca  vmovaps [rsp+0xA0], xmm11
000073307ffd87d3  vmovaps [rsp+0xB0], xmm12
000073307ffd87dc  vmovaps [rsp+0xC0], xmm13
000073307ffd87e5  vmovaps [rsp+0xD0], xmm14
000073307ffd87ee  vmovaps [rsp+0xE0], xmm15
000073307ffd87f7  sub rsp, 0x30
000073307ffd87fb  movaps [rsp], xmm3
000073307ffd87ff  movaps [rsp+0x10], xmm1
000073307ffd8804  movaps [rsp+0x20], xmm15
000073307ffd880a  lea rdi, [rsp]
000073307ffd880e  mov esi, 0x00
000073307ffd8813  mov rax, 0x600DE0EC8530
000073307ffd881d  call rax
000073307ffd881f  movaps xmm3, [rsp]
000073307ffd8823  add rsp, 0x30
000073307ffd8827  vmovaps xmm0, [rsp]
000073307ffd882c  vmovaps xmm1, [rsp+0x10]
000073307ffd8832  vmovaps xmm2, [rsp+0x20]
000073307ffd8838  vmovaps xmm4, [rsp+0x30]
000073307ffd883e  vmovaps xmm5, [rsp+0x40]
000073307ffd8844  vmovaps xmm6, [rsp+0x50]
000073307ffd884a  vmovaps xmm7, [rsp+0x60]
000073307ffd8850  vmovaps xmm8, [rsp+0x70]
000073307ffd8856  vmovaps xmm9, [rsp+0x80]
000073307ffd885f  vmovaps xmm10, [rsp+0x90]
000073307ffd8868  vmovaps xmm11, [rsp+0xA0]
000073307ffd8871  vmovaps xmm12, [rsp+0xB0]
000073307ffd887a  vmovaps xmm13, [rsp+0xC0]
000073307ffd8883  vmovaps xmm14, [rsp+0xD0]
000073307ffd888c  vmovaps xmm15, [rsp+0xE0]
000073307ffd8895  add rsp, 0xF0
000073307ffd889c  pop r11
000073307ffd889e  pop r10
000073307ffd88a0  pop r9
000073307ffd88a2  pop r8
000073307ffd88a4  pop rsi
000073307ffd88a5  pop rdi
000073307ffd88a6  pop rdx
000073307ffd88a7  pop rcx
000073307ffd88a8  pop rax
000073307ffd88a9  add rsp, 0x08
000073307ffd88ad  jmp 0x000073307FFD60BF
000073307ffd88b2  call 0x000073307FED64F0
000073307ffd88b7  jmp 0x000073307FFD60C9
000073307ffd88bc  sub rsp, 0x08
000073307ffd88c0  push rax
000073307ffd88c1  push rcx
000073307ffd88c2  push rdx
000073307ffd88c3  push rdi
000073307ffd88c4  push rsi
000073307ffd88c5  push r8
000073307ffd88c7  push r9
000073307ffd88c9  push r10
000073307ffd88cb  push r11
000073307ffd88cd  sub rsp, 0xF0
000073307ffd88d4  vmovaps [rsp], xmm0
000073307ffd88d9  vmovaps [rsp+0x10], xmm1
000073307ffd88df  vmovaps [rsp+0x20], xmm2
000073307ffd88e5  vmovaps [rsp+0x30], xmm3
000073307ffd88eb  vmovaps [rsp+0x40], xmm4
000073307ffd88f1  vmovaps [rsp+0x50], xmm5
000073307ffd88f7  vmovaps [rsp+0x60], xmm6
000073307ffd88fd  vmovaps [rsp+0x70], xmm7
000073307ffd8903  vmovaps [rsp+0x80], xmm8
000073307ffd890c  vmovaps [rsp+0x90], xmm9
000073307ffd8915  vmovaps [rsp+0xA0], xmm10
000073307ffd891e  vmovaps [rsp+0xB0], xmm11
000073307ffd8927  vmovaps [rsp+0xC0], xmm12
000073307ffd8930  vmovaps [rsp+0xD0], xmm13
000073307ffd8939  vmovaps [rsp+0xE0], xmm14
000073307ffd8942  sub rsp, 0x30
000073307ffd8946  movaps [rsp], xmm15
000073307ffd894b  movaps [rsp+0x10], xmm14
000073307ffd8951  movaps [rsp+0x20], xmm4
000073307ffd8956  lea rdi, [rsp]
000073307ffd895a  mov esi, 0x00
000073307ffd895f  mov rax, 0x600DE0EC8530
000073307ffd8969  call rax
000073307ffd896b  movaps xmm15, [rsp]
000073307ffd8970  add rsp, 0x30
000073307ffd8974  vmovaps xmm0, [rsp]
000073307ffd8979  vmovaps xmm1, [rsp+0x10]
000073307ffd897f  vmovaps xmm2, [rsp+0x20]
000073307ffd8985  vmovaps xmm3, [rsp+0x30]
000073307ffd898b  vmovaps xmm4, [rsp+0x40]
000073307ffd8991  vmovaps xmm5, [rsp+0x50]
000073307ffd8997  vmovaps xmm6, [rsp+0x60]
000073307ffd899d  vmovaps xmm7, [rsp+0x70]
000073307ffd89a3  vmovaps xmm8, [rsp+0x80]
000073307ffd89ac  vmovaps xmm9, [rsp+0x90]
000073307ffd89b5  vmovaps xmm10, [rsp+0xA0]
000073307ffd89be  vmovaps xmm11, [rsp+0xB0]
000073307ffd89c7  vmovaps xmm12, [rsp+0xC0]
000073307ffd89d0  vmovaps xmm13, [rsp+0xD0]
000073307ffd89d9  vmovaps xmm14, [rsp+0xE0]
000073307ffd89e2  add rsp, 0xF0
000073307ffd89e9  pop r11
000073307ffd89eb  pop r10
000073307ffd89ed  pop r9
000073307ffd89ef  pop r8
000073307ffd89f1  pop rsi
000073307ffd89f2  pop rdi
000073307ffd89f3  pop rdx
000073307ffd89f4  pop rcx
000073307ffd89f5  pop rax
000073307ffd89f6  add rsp, 0x08
000073307ffd89fa  jmp 0x000073307FFD60F7
000073307ffd89ff  sub rsp, 0x08
000073307ffd8a03  push rax
000073307ffd8a04  push rcx
000073307ffd8a05  push rdx
000073307ffd8a06  push rdi
000073307ffd8a07  push rsi
000073307ffd8a08  push r8
000073307ffd8a0a  push r9
000073307ffd8a0c  push r10
000073307ffd8a0e  push r11
000073307ffd8a10  sub rsp, 0xF0
000073307ffd8a17  vmovaps [rsp], xmm0
000073307ffd8a1c  vmovaps [rsp+0x10], xmm1
000073307ffd8a22  vmovaps [rsp+0x20], xmm2
000073307ffd8a28  vmovaps [rsp+0x30], xmm3
000073307ffd8a2e  vmovaps [rsp+0x40], xmm4
000073307ffd8a34  vmovaps [rsp+0x50], xmm5
000073307ffd8a3a  vmovaps [rsp+0x60], xmm6
000073307ffd8a40  vmovaps [rsp+0x70], xmm7
000073307ffd8a46  vmovaps [rsp+0x80], xmm8
000073307ffd8a4f  vmovaps [rsp+0x90], xmm9
000073307ffd8a58  vmovaps [rsp+0xA0], xmm10
000073307ffd8a61  vmovaps [rsp+0xB0], xmm11
000073307ffd8a6a  vmovaps [rsp+0xC0], xmm12
000073307ffd8a73  vmovaps [rsp+0xD0], xmm13
000073307ffd8a7c  vmovaps [rsp+0xE0], xmm15
000073307ffd8a85  sub rsp, 0x30
000073307ffd8a89  movaps [rsp], xmm14
000073307ffd8a8e  movaps [rsp+0x10], xmm2
000073307ffd8a93  movaps [rsp+0x20], xmm1
000073307ffd8a98  lea rdi, [rsp]
000073307ffd8a9c  mov esi, 0x00
000073307ffd8aa1  mov rax, 0x600DE0EC8530
000073307ffd8aab  call rax
000073307ffd8aad  movaps xmm14, [rsp]
000073307ffd8ab2  add rsp, 0x30
000073307ffd8ab6  vmovaps xmm0, [rsp]
000073307ffd8abb  vmovaps xmm1, [rsp+0x10]
000073307ffd8ac1  vmovaps xmm2, [rsp+0x20]
000073307ffd8ac7  vmovaps xmm3, [rsp+0x30]
000073307ffd8acd  vmovaps xmm4, [rsp+0x40]
000073307ffd8ad3  vmovaps xmm5, [rsp+0x50]
000073307ffd8ad9  vmovaps xmm6, [rsp+0x60]
000073307ffd8adf  vmovaps xmm7, [rsp+0x70]
000073307ffd8ae5  vmovaps xmm8, [rsp+0x80]
000073307ffd8aee  vmovaps xmm9, [rsp+0x90]
000073307ffd8af7  vmovaps xmm10, [rsp+0xA0]
000073307ffd8b00  vmovaps xmm11, [rsp+0xB0]
000073307ffd8b09  vmovaps xmm12, [rsp+0xC0]
000073307ffd8b12  vmovaps xmm13, [rsp+0xD0]
000073307ffd8b1b  vmovaps xmm15, [rsp+0xE0]
000073307ffd8b24  add rsp, 0xF0
000073307ffd8b2b  pop r11
000073307ffd8b2d  pop r10
000073307ffd8b2f  pop r9
000073307ffd8b31  pop r8
000073307ffd8b33  pop rsi
000073307ffd8b34  pop rdi
000073307ffd8b35  pop rdx
000073307ffd8b36  pop rcx
000073307ffd8b37  pop rax
000073307ffd8b38  add rsp, 0x08
000073307ffd8b3c  jmp 0x000073307FFD611D
000073307ffd8b41  sub rsp, 0x08
000073307ffd8b45  push rax
000073307ffd8b46  push rcx
000073307ffd8b47  push rdx
000073307ffd8b48  push rdi
000073307ffd8b49  push rsi
000073307ffd8b4a  push r8
000073307ffd8b4c  push r9
000073307ffd8b4e  push r10
000073307ffd8b50  push r11
000073307ffd8b52  sub rsp, 0xF0
000073307ffd8b59  vmovaps [rsp], xmm0
000073307ffd8b5e  vmovaps [rsp+0x10], xmm2
000073307ffd8b64  vmovaps [rsp+0x20], xmm3
000073307ffd8b6a  vmovaps [rsp+0x30], xmm4
000073307ffd8b70  vmovaps [rsp+0x40], xmm5
000073307ffd8b76  vmovaps [rsp+0x50], xmm6
000073307ffd8b7c  vmovaps [rsp+0x60], xmm7
000073307ffd8b82  vmovaps [rsp+0x70], xmm8
000073307ffd8b88  vmovaps [rsp+0x80], xmm9
000073307ffd8b91  vmovaps [rsp+0x90], xmm10
000073307ffd8b9a  vmovaps [rsp+0xA0], xmm11
000073307ffd8ba3  vmovaps [rsp+0xB0], xmm12
000073307ffd8bac  vmovaps [rsp+0xC0], xmm13
000073307ffd8bb5  vmovaps [rsp+0xD0], xmm14
000073307ffd8bbe  vmovaps [rsp+0xE0], xmm15
000073307ffd8bc7  sub rsp, 0x30
000073307ffd8bcb  movaps [rsp], xmm1
000073307ffd8bcf  movaps [rsp+0x10], xmm4
000073307ffd8bd4  movaps [rsp+0x20], xmm9
000073307ffd8bda  lea rdi, [rsp]
000073307ffd8bde  mov esi, 0x00
000073307ffd8be3  mov rax, 0x600DE0EC8530
000073307ffd8bed  call rax
000073307ffd8bef  movaps xmm1, [rsp]
000073307ffd8bf3  add rsp, 0x30
000073307ffd8bf7  vmovaps xmm0, [rsp]
000073307ffd8bfc  vmovaps xmm2, [rsp+0x10]
000073307ffd8c02  vmovaps xmm3, [rsp+0x20]
000073307ffd8c08  vmovaps xmm4, [rsp+0x30]
000073307ffd8c0e  vmovaps xmm5, [rsp+0x40]
000073307ffd8c14  vmovaps xmm6, [rsp+0x50]
000073307ffd8c1a  vmovaps xmm7, [rsp+0x60]
000073307ffd8c20  vmovaps xmm8, [rsp+0x70]
000073307ffd8c26  vmovaps xmm9, [rsp+0x80]
000073307ffd8c2f  vmovaps xmm10, [rsp+0x90]
000073307ffd8c38  vmovaps xmm11, [rsp+0xA0]
000073307ffd8c41  vmovaps xmm12, [rsp+0xB0]
000073307ffd8c4a  vmovaps xmm13, [rsp+0xC0]
000073307ffd8c53  vmovaps xmm14, [rsp+0xD0]
000073307ffd8c5c  vmovaps xmm15, [rsp+0xE0]
000073307ffd8c65  add rsp, 0xF0
000073307ffd8c6c  pop r11
000073307ffd8c6e  pop r10
000073307ffd8c70  pop r9
000073307ffd8c72  pop r8
000073307ffd8c74  pop rsi
000073307ffd8c75  pop rdi
000073307ffd8c76  pop rdx
000073307ffd8c77  pop rcx
000073307ffd8c78  pop rax
000073307ffd8c79  add rsp, 0x08
000073307ffd8c7d  jmp 0x000073307FFD613B
000073307ffd8c82  sub rsp, 0x08
000073307ffd8c86  push rax
000073307ffd8c87  push rcx
000073307ffd8c88  push rdx
000073307ffd8c89  push rdi
000073307ffd8c8a  push rsi
000073307ffd8c8b  push r8
000073307ffd8c8d  push r9
000073307ffd8c8f  push r10
000073307ffd8c91  push r11
000073307ffd8c93  sub rsp, 0xF0
000073307ffd8c9a  vmovaps [rsp], xmm0
000073307ffd8c9f  vmovaps [rsp+0x10], xmm1
000073307ffd8ca5  vmovaps [rsp+0x20], xmm2
000073307ffd8cab  vmovaps [rsp+0x30], xmm3
000073307ffd8cb1  vmovaps [rsp+0x40], xmm5
000073307ffd8cb7  vmovaps [rsp+0x50], xmm6
000073307ffd8cbd  vmovaps [rsp+0x60], xmm7
000073307ffd8cc3  vmovaps [rsp+0x70], xmm8
000073307ffd8cc9  vmovaps [rsp+0x80], xmm9
000073307ffd8cd2  vmovaps [rsp+0x90], xmm10
000073307ffd8cdb  vmovaps [rsp+0xA0], xmm11
000073307ffd8ce4  vmovaps [rsp+0xB0], xmm12
000073307ffd8ced  vmovaps [rsp+0xC0], xmm13
000073307ffd8cf6  vmovaps [rsp+0xD0], xmm14
000073307ffd8cff  vmovaps [rsp+0xE0], xmm15
000073307ffd8d08  sub rsp, 0x30
000073307ffd8d0c  movaps [rsp], xmm4
000073307ffd8d10  movaps [rsp+0x10], xmm2
000073307ffd8d15  movaps [rsp+0x20], xmm9
000073307ffd8d1b  lea rdi, [rsp]
000073307ffd8d1f  mov esi, 0x00
000073307ffd8d24  mov rax, 0x600DE0EC8530
000073307ffd8d2e  call rax
000073307ffd8d30  movaps xmm4, [rsp]
000073307ffd8d34  add rsp, 0x30
000073307ffd8d38  vmovaps xmm0, [rsp]
000073307ffd8d3d  vmovaps xmm1, [rsp+0x10]
000073307ffd8d43  vmovaps xmm2, [rsp+0x20]
000073307ffd8d49  vmovaps xmm3, [rsp+0x30]
000073307ffd8d4f  vmovaps xmm5, [rsp+0x40]
000073307ffd8d55  vmovaps xmm6, [rsp+0x50]
000073307ffd8d5b  vmovaps xmm7, [rsp+0x60]
000073307ffd8d61  vmovaps xmm8, [rsp+0x70]
000073307ffd8d67  vmovaps xmm9, [rsp+0x80]
000073307ffd8d70  vmovaps xmm10, [rsp+0x90]
000073307ffd8d79  vmovaps xmm11, [rsp+0xA0]
000073307ffd8d82  vmovaps xmm12, [rsp+0xB0]
000073307ffd8d8b  vmovaps xmm13, [rsp+0xC0]
000073307ffd8d94  vmovaps xmm14, [rsp+0xD0]
000073307ffd8d9d  vmovaps xmm15, [rsp+0xE0]
000073307ffd8da6  add rsp, 0xF0
000073307ffd8dad  pop r11
000073307ffd8daf  pop r10
000073307ffd8db1  pop r9
000073307ffd8db3  pop r8
000073307ffd8db5  pop rsi
000073307ffd8db6  pop rdi
000073307ffd8db7  pop rdx
000073307ffd8db8  pop rcx
000073307ffd8db9  pop rax
000073307ffd8dba  add rsp, 0x08
000073307ffd8dbe  jmp 0x000073307FFD616B
000073307ffd8dc3  sub rsp, 0x08
000073307ffd8dc7  push rax
000073307ffd8dc8  push rcx
000073307ffd8dc9  push rdx
000073307ffd8dca  push rdi
000073307ffd8dcb  push rsi
000073307ffd8dcc  push r8
000073307ffd8dce  push r9
000073307ffd8dd0  push r10
000073307ffd8dd2  push r11
000073307ffd8dd4  sub rsp, 0xF0
000073307ffd8ddb  vmovaps [rsp], xmm0
000073307ffd8de0  vmovaps [rsp+0x10], xmm1
000073307ffd8de6  vmovaps [rsp+0x20], xmm2
000073307ffd8dec  vmovaps [rsp+0x30], xmm3
000073307ffd8df2  vmovaps [rsp+0x40], xmm4
000073307ffd8df8  vmovaps [rsp+0x50], xmm5
000073307ffd8dfe  vmovaps [rsp+0x60], xmm6
000073307ffd8e04  vmovaps [rsp+0x70], xmm7
000073307ffd8e0a  vmovaps [rsp+0x80], xmm8
000073307ffd8e13  vmovaps [rsp+0x90], xmm10
000073307ffd8e1c  vmovaps [rsp+0xA0], xmm11
000073307ffd8e25  vmovaps [rsp+0xB0], xmm12
000073307ffd8e2e  vmovaps [rsp+0xC0], xmm13
000073307ffd8e37  vmovaps [rsp+0xD0], xmm14
000073307ffd8e40  vmovaps [rsp+0xE0], xmm15
000073307ffd8e49  sub rsp, 0x30
000073307ffd8e4d  movaps [rsp], xmm9
000073307ffd8e52  movaps [rsp+0x10], xmm2
000073307ffd8e57  movaps [rsp+0x20], xmm1
000073307ffd8e5c  lea rdi, [rsp]
000073307ffd8e60  mov esi, 0x00
000073307ffd8e65  mov rax, 0x600DE0EC8530
000073307ffd8e6f  call rax
000073307ffd8e71  movaps xmm9, [rsp]
000073307ffd8e76  add rsp, 0x30
000073307ffd8e7a  vmovaps xmm0, [rsp]
000073307ffd8e7f  vmovaps xmm1, [rsp+0x10]
000073307ffd8e85  vmovaps xmm2, [rsp+0x20]
000073307ffd8e8b  vmovaps xmm3, [rsp+0x30]
000073307ffd8e91  vmovaps xmm4, [rsp+0x40]
000073307ffd8e97  vmovaps xmm5, [rsp+0x50]
000073307ffd8e9d  vmovaps xmm6, [rsp+0x60]
000073307ffd8ea3  vmovaps xmm7, [rsp+0x70]
000073307ffd8ea9  vmovaps xmm8, [rsp+0x80]
000073307ffd8eb2  vmovaps xmm10, [rsp+0x90]
000073307ffd8ebb  vmovaps xmm11, [rsp+0xA0]
000073307ffd8ec4  vmovaps xmm12, [rsp+0xB0]
000073307ffd8ecd  vmovaps xmm13, [rsp+0xC0]
000073307ffd8ed6  vmovaps xmm14, [rsp+0xD0]
000073307ffd8edf  vmovaps xmm15, [rsp+0xE0]
000073307ffd8ee8  add rsp, 0xF0
000073307ffd8eef  pop r11
000073307ffd8ef1  pop r10
000073307ffd8ef3  pop r9
000073307ffd8ef5  pop r8
000073307ffd8ef7  pop rsi
000073307ffd8ef8  pop rdi
000073307ffd8ef9  pop rdx
000073307ffd8efa  pop rcx
000073307ffd8efb  pop rax
000073307ffd8efc  add rsp, 0x08
000073307ffd8f00  jmp 0x000073307FFD61A1
000073307ffd8f05  sub rsp, 0x08
000073307ffd8f09  push rax
000073307ffd8f0a  push rcx
000073307ffd8f0b  push rdx
000073307ffd8f0c  push rdi
000073307ffd8f0d  push rsi
000073307ffd8f0e  push r8
000073307ffd8f10  push r9
000073307ffd8f12  push r10
000073307ffd8f14  push r11
000073307ffd8f16  sub rsp, 0xF0
000073307ffd8f1d  vmovaps [rsp], xmm0
000073307ffd8f22  vmovaps [rsp+0x10], xmm2
000073307ffd8f28  vmovaps [rsp+0x20], xmm3
000073307ffd8f2e  vmovaps [rsp+0x30], xmm4
000073307ffd8f34  vmovaps [rsp+0x40], xmm5
000073307ffd8f3a  vmovaps [rsp+0x50], xmm6
000073307ffd8f40  vmovaps [rsp+0x60], xmm7
000073307ffd8f46  vmovaps [rsp+0x70], xmm8
000073307ffd8f4c  vmovaps [rsp+0x80], xmm9
000073307ffd8f55  vmovaps [rsp+0x90], xmm10
000073307ffd8f5e  vmovaps [rsp+0xA0], xmm11
000073307ffd8f67  vmovaps [rsp+0xB0], xmm12
000073307ffd8f70  vmovaps [rsp+0xC0], xmm13
000073307ffd8f79  vmovaps [rsp+0xD0], xmm14
000073307ffd8f82  vmovaps [rsp+0xE0], xmm15
000073307ffd8f8b  sub rsp, 0x30
000073307ffd8f8f  movaps [rsp], xmm1
000073307ffd8f93  movaps [rsp+0x10], xmm15
000073307ffd8f99  movaps [rsp+0x20], xmm6
000073307ffd8f9e  lea rdi, [rsp]
000073307ffd8fa2  mov esi, 0x00
000073307ffd8fa7  mov rax, 0x600DE0EC8530
000073307ffd8fb1  call rax
000073307ffd8fb3  movaps xmm1, [rsp]
000073307ffd8fb7  add rsp, 0x30
000073307ffd8fbb  vmovaps xmm0, [rsp]
000073307ffd8fc0  vmovaps xmm2, [rsp+0x10]
000073307ffd8fc6  vmovaps xmm3, [rsp+0x20]
000073307ffd8fcc  vmovaps xmm4, [rsp+0x30]
000073307ffd8fd2  vmovaps xmm5, [rsp+0x40]
000073307ffd8fd8  vmovaps xmm6, [rsp+0x50]
000073307ffd8fde  vmovaps xmm7, [rsp+0x60]
000073307ffd8fe4  vmovaps xmm8, [rsp+0x70]
000073307ffd8fea  vmovaps xmm9, [rsp+0x80]
000073307ffd8ff3  vmovaps xmm10, [rsp+0x90]
000073307ffd8ffc  vmovaps xmm11, [rsp+0xA0]
000073307ffd9005  vmovaps xmm12, [rsp+0xB0]
000073307ffd900e  vmovaps xmm13, [rsp+0xC0]
000073307ffd9017  vmovaps xmm14, [rsp+0xD0]
000073307ffd9020  vmovaps xmm15, [rsp+0xE0]
000073307ffd9029  add rsp, 0xF0
000073307ffd9030  pop r11
000073307ffd9032  pop r10
000073307ffd9034  pop r9
000073307ffd9036  pop r8
000073307ffd9038  pop rsi
000073307ffd9039  pop rdi
000073307ffd903a  pop rdx
000073307ffd903b  pop rcx
000073307ffd903c  pop rax
000073307ffd903d  add rsp, 0x08
000073307ffd9041  jmp 0x000073307FFD61C2
000073307ffd9046  sub rsp, 0x08
000073307ffd904a  push rax
000073307ffd904b  push rcx
000073307ffd904c  push rdx
000073307ffd904d  push rdi
000073307ffd904e  push rsi
000073307ffd904f  push r8
000073307ffd9051  push r9
000073307ffd9053  push r10
000073307ffd9055  push r11
000073307ffd9057  sub rsp, 0xF0
000073307ffd905e  vmovaps [rsp], xmm0
000073307ffd9063  vmovaps [rsp+0x10], xmm1
000073307ffd9069  vmovaps [rsp+0x20], xmm2
000073307ffd906f  vmovaps [rsp+0x30], xmm3
000073307ffd9075  vmovaps [rsp+0x40], xmm4
000073307ffd907b  vmovaps [rsp+0x50], xmm5
000073307ffd9081  vmovaps [rsp+0x60], xmm6
000073307ffd9087  vmovaps [rsp+0x70], xmm7
000073307ffd908d  vmovaps [rsp+0x80], xmm8
000073307ffd9096  vmovaps [rsp+0x90], xmm9
000073307ffd909f  vmovaps [rsp+0xA0], xmm10
000073307ffd90a8  vmovaps [rsp+0xB0], xmm11
000073307ffd90b1  vmovaps [rsp+0xC0], xmm12
000073307ffd90ba  vmovaps [rsp+0xD0], xmm13
000073307ffd90c3  vmovaps [rsp+0xE0], xmm14
000073307ffd90cc  sub rsp, 0x30
000073307ffd90d0  movaps [rsp], xmm15
000073307ffd90d5  movaps [rsp+0x10], xmm5
000073307ffd90da  movaps [rsp+0x20], xmm3
000073307ffd90df  lea rdi, [rsp]
000073307ffd90e3  mov esi, 0x00
000073307ffd90e8  mov rax, 0x600DE0EC8530
000073307ffd90f2  call rax
000073307ffd90f4  movaps xmm15, [rsp]
000073307ffd90f9  add rsp, 0x30
000073307ffd90fd  vmovaps xmm0, [rsp]
000073307ffd9102  vmovaps xmm1, [rsp+0x10]
000073307ffd9108  vmovaps xmm2, [rsp+0x20]
000073307ffd910e  vmovaps xmm3, [rsp+0x30]
000073307ffd9114  vmovaps xmm4, [rsp+0x40]
000073307ffd911a  vmovaps xmm5, [rsp+0x50]
000073307ffd9120  vmovaps xmm6, [rsp+0x60]
000073307ffd9126  vmovaps xmm7, [rsp+0x70]
000073307ffd912c  vmovaps xmm8, [rsp+0x80]
000073307ffd9135  vmovaps xmm9, [rsp+0x90]
000073307ffd913e  vmovaps xmm10, [rsp+0xA0]
000073307ffd9147  vmovaps xmm11, [rsp+0xB0]
000073307ffd9150  vmovaps xmm12, [rsp+0xC0]
000073307ffd9159  vmovaps xmm13, [rsp+0xD0]
000073307ffd9162  vmovaps xmm14, [rsp+0xE0]
000073307ffd916b  add rsp, 0xF0
000073307ffd9172  pop r11
000073307ffd9174  pop r10
000073307ffd9176  pop r9
000073307ffd9178  pop r8
000073307ffd917a  pop rsi
000073307ffd917b  pop rdi
000073307ffd917c  pop rdx
000073307ffd917d  pop rcx
000073307ffd917e  pop rax
000073307ffd917f  add rsp, 0x08
000073307ffd9183  jmp 0x000073307FFD61DC
000073307ffd9188  sub rsp, 0x08
000073307ffd918c  push rax
000073307ffd918d  push rcx
000073307ffd918e  push rdx
000073307ffd918f  push rdi
000073307ffd9190  push rsi
000073307ffd9191  push r8
000073307ffd9193  push r9
000073307ffd9195  push r10
000073307ffd9197  push r11
000073307ffd9199  sub rsp, 0xF0
000073307ffd91a0  vmovaps [rsp], xmm0
000073307ffd91a5  vmovaps [rsp+0x10], xmm1
000073307ffd91ab  vmovaps [rsp+0x20], xmm2
000073307ffd91b1  vmovaps [rsp+0x30], xmm3
000073307ffd91b7  vmovaps [rsp+0x40], xmm4
000073307ffd91bd  vmovaps [rsp+0x50], xmm6
000073307ffd91c3  vmovaps [rsp+0x60], xmm7
000073307ffd91c9  vmovaps [rsp+0x70], xmm8
000073307ffd91cf  vmovaps [rsp+0x80], xmm9
000073307ffd91d8  vmovaps [rsp+0x90], xmm10
000073307ffd91e1  vmovaps [rsp+0xA0], xmm11
000073307ffd91ea  vmovaps [rsp+0xB0], xmm12
000073307ffd91f3  vmovaps [rsp+0xC0], xmm13
000073307ffd91fc  vmovaps [rsp+0xD0], xmm14
000073307ffd9205  vmovaps [rsp+0xE0], xmm15
000073307ffd920e  sub rsp, 0x30
000073307ffd9212  movaps [rsp], xmm5
000073307ffd9216  movaps [rsp+0x10], xmm8
000073307ffd921c  movaps [rsp+0x20], xmm6
000073307ffd9221  lea rdi, [rsp]
000073307ffd9225  mov esi, 0x00
000073307ffd922a  mov rax, 0x600DE0EC8530
000073307ffd9234  call rax
000073307ffd9236  movaps xmm5, [rsp]
000073307ffd923a  add rsp, 0x30
000073307ffd923e  vmovaps xmm0, [rsp]
000073307ffd9243  vmovaps xmm1, [rsp+0x10]
000073307ffd9249  vmovaps xmm2, [rsp+0x20]
000073307ffd924f  vmovaps xmm3, [rsp+0x30]
000073307ffd9255  vmovaps xmm4, [rsp+0x40]
000073307ffd925b  vmovaps xmm6, [rsp+0x50]
000073307ffd9261  vmovaps xmm7, [rsp+0x60]
000073307ffd9267  vmovaps xmm8, [rsp+0x70]
000073307ffd926d  vmovaps xmm9, [rsp+0x80]
000073307ffd9276  vmovaps xmm10, [rsp+0x90]
000073307ffd927f  vmovaps xmm11, [rsp+0xA0]
000073307ffd9288  vmovaps xmm12, [rsp+0xB0]
000073307ffd9291  vmovaps xmm13, [rsp+0xC0]
000073307ffd929a  vmovaps xmm14, [rsp+0xD0]
000073307ffd92a3  vmovaps xmm15, [rsp+0xE0]
000073307ffd92ac  add rsp, 0xF0
000073307ffd92b3  pop r11
000073307ffd92b5  pop r10
000073307ffd92b7  pop r9
000073307ffd92b9  pop r8
000073307ffd92bb  pop rsi
000073307ffd92bc  pop rdi
000073307ffd92bd  pop rdx
000073307ffd92be  pop rcx
000073307ffd92bf  pop rax
000073307ffd92c0  add rsp, 0x08
000073307ffd92c4  jmp 0x000073307FFD6200
000073307ffd92c9  sub rsp, 0x08
000073307ffd92cd  push rax
000073307ffd92ce  push rcx
000073307ffd92cf  push rdx
000073307ffd92d0  push rdi
000073307ffd92d1  push rsi
000073307ffd92d2  push r8
000073307ffd92d4  push r9
000073307ffd92d6  push r10
000073307ffd92d8  push r11
000073307ffd92da  sub rsp, 0xF0
000073307ffd92e1  vmovaps [rsp], xmm0
000073307ffd92e6  vmovaps [rsp+0x10], xmm1
000073307ffd92ec  vmovaps [rsp+0x20], xmm2
000073307ffd92f2  vmovaps [rsp+0x30], xmm3
000073307ffd92f8  vmovaps [rsp+0x40], xmm4
000073307ffd92fe  vmovaps [rsp+0x50], xmm5
000073307ffd9304  vmovaps [rsp+0x60], xmm7
000073307ffd930a  vmovaps [rsp+0x70], xmm8
000073307ffd9310  vmovaps [rsp+0x80], xmm9
000073307ffd9319  vmovaps [rsp+0x90], xmm10
000073307ffd9322  vmovaps [rsp+0xA0], xmm11
000073307ffd932b  vmovaps [rsp+0xB0], xmm12
000073307ffd9334  vmovaps [rsp+0xC0], xmm13
000073307ffd933d  vmovaps [rsp+0xD0], xmm14
000073307ffd9346  vmovaps [rsp+0xE0], xmm15
000073307ffd934f  sub rsp, 0x30
000073307ffd9353  movaps [rsp], xmm6
000073307ffd9357  movaps [rsp+0x10], xmm10
000073307ffd935d  movaps [rsp+0x20], xmm8
000073307ffd9363  lea rdi, [rsp]
000073307ffd9367  mov esi, 0x00
000073307ffd936c  mov rax, 0x600DE0EC8530
000073307ffd9376  call rax
000073307ffd9378  movaps xmm6, [rsp]
000073307ffd937c  add rsp, 0x30
000073307ffd9380  vmovaps xmm0, [rsp]
000073307ffd9385  vmovaps xmm1, [rsp+0x10]
000073307ffd938b  vmovaps xmm2, [rsp+0x20]
000073307ffd9391  vmovaps xmm3, [rsp+0x30]
000073307ffd9397  vmovaps xmm4, [rsp+0x40]
000073307ffd939d  vmovaps xmm5, [rsp+0x50]
000073307ffd93a3  vmovaps xmm7, [rsp+0x60]
000073307ffd93a9  vmovaps xmm8, [rsp+0x70]
000073307ffd93af  vmovaps xmm9, [rsp+0x80]
000073307ffd93b8  vmovaps xmm10, [rsp+0x90]
000073307ffd93c1  vmovaps xmm11, [rsp+0xA0]
000073307ffd93ca  vmovaps xmm12, [rsp+0xB0]
000073307ffd93d3  vmovaps xmm13, [rsp+0xC0]
000073307ffd93dc  vmovaps xmm14, [rsp+0xD0]
000073307ffd93e5  vmovaps xmm15, [rsp+0xE0]
000073307ffd93ee  add rsp, 0xF0
000073307ffd93f5  pop r11
000073307ffd93f7  pop r10
000073307ffd93f9  pop r9
000073307ffd93fb  pop r8
000073307ffd93fd  pop rsi
000073307ffd93fe  pop rdi
000073307ffd93ff  pop rdx
000073307ffd9400  pop rcx
000073307ffd9401  pop rax
000073307ffd9402  add rsp, 0x08
000073307ffd9406  jmp 0x000073307FFD6225
000073307ffd940b  sub rsp, 0x08
000073307ffd940f  push rax
000073307ffd9410  push rcx
000073307ffd9411  push rdx
000073307ffd9412  push rdi
000073307ffd9413  push rsi
000073307ffd9414  push r8
000073307ffd9416  push r9
000073307ffd9418  push r10
000073307ffd941a  push r11
000073307ffd941c  sub rsp, 0xF0
000073307ffd9423  vmovaps [rsp], xmm0
000073307ffd9428  vmovaps [rsp+0x10], xmm1
000073307ffd942e  vmovaps [rsp+0x20], xmm2
000073307ffd9434  vmovaps [rsp+0x30], xmm3
000073307ffd943a  vmovaps [rsp+0x40], xmm4
000073307ffd9440  vmovaps [rsp+0x50], xmm5
000073307ffd9446  vmovaps [rsp+0x60], xmm6
000073307ffd944c  vmovaps [rsp+0x70], xmm7
000073307ffd9452  vmovaps [rsp+0x80], xmm8
000073307ffd945b  vmovaps [rsp+0x90], xmm9
000073307ffd9464  vmovaps [rsp+0xA0], xmm11
000073307ffd946d  vmovaps [rsp+0xB0], xmm12
000073307ffd9476  vmovaps [rsp+0xC0], xmm13
000073307ffd947f  vmovaps [rsp+0xD0], xmm14
000073307ffd9488  vmovaps [rsp+0xE0], xmm15
000073307ffd9491  sub rsp, 0x30
000073307ffd9495  movaps [rsp], xmm10
000073307ffd949a  movaps [rsp+0x10], xmm8
000073307ffd94a0  movaps [rsp+0x20], xmm14
000073307ffd94a6  lea rdi, [rsp]
000073307ffd94aa  mov esi, 0x00
000073307ffd94af  mov rax, 0x600DE0EC8530
000073307ffd94b9  call rax
000073307ffd94bb  movaps xmm10, [rsp]
000073307ffd94c0  add rsp, 0x30
000073307ffd94c4  vmovaps xmm0, [rsp]
000073307ffd94c9  vmovaps xmm1, [rsp+0x10]
000073307ffd94cf  vmovaps xmm2, [rsp+0x20]
000073307ffd94d5  vmovaps xmm3, [rsp+0x30]
000073307ffd94db  vmovaps xmm4, [rsp+0x40]
000073307ffd94e1  vmovaps xmm5, [rsp+0x50]
000073307ffd94e7  vmovaps xmm6, [rsp+0x60]
000073307ffd94ed  vmovaps xmm7, [rsp+0x70]
000073307ffd94f3  vmovaps xmm8, [rsp+0x80]
000073307ffd94fc  vmovaps xmm9, [rsp+0x90]
000073307ffd9505  vmovaps xmm11, [rsp+0xA0]
000073307ffd950e  vmovaps xmm12, [rsp+0xB0]
000073307ffd9517  vmovaps xmm13, [rsp+0xC0]
000073307ffd9520  vmovaps xmm14, [rsp+0xD0]
000073307ffd9529  vmovaps xmm15, [rsp+0xE0]
000073307ffd9532  add rsp, 0xF0
000073307ffd9539  pop r11
000073307ffd953b  pop r10
000073307ffd953d  pop r9
000073307ffd953f  pop r8
000073307ffd9541  pop rsi
000073307ffd9542  pop rdi
000073307ffd9543  pop rdx
000073307ffd9544  pop rcx
000073307ffd9545  pop rax
000073307ffd9546  add rsp, 0x08
000073307ffd954a  jmp 0x000073307FFD6245
000073307ffd954f  sub rsp, 0x08
000073307ffd9553  push rax
000073307ffd9554  push rcx
000073307ffd9555  push rdx
000073307ffd9556  push rdi
000073307ffd9557  push rsi
000073307ffd9558  push r8
000073307ffd955a  push r9
000073307ffd955c  push r10
000073307ffd955e  push r11
000073307ffd9560  sub rsp, 0xF0
000073307ffd9567  vmovaps [rsp], xmm0
000073307ffd956c  vmovaps [rsp+0x10], xmm1
000073307ffd9572  vmovaps [rsp+0x20], xmm2
000073307ffd9578  vmovaps [rsp+0x30], xmm3
000073307ffd957e  vmovaps [rsp+0x40], xmm4
000073307ffd9584  vmovaps [rsp+0x50], xmm5
000073307ffd958a  vmovaps [rsp+0x60], xmm6
000073307ffd9590  vmovaps [rsp+0x70], xmm7
000073307ffd9596  vmovaps [rsp+0x80], xmm8
000073307ffd959f  vmovaps [rsp+0x90], xmm9
000073307ffd95a8  vmovaps [rsp+0xA0], xmm10
000073307ffd95b1  vmovaps [rsp+0xB0], xmm11
000073307ffd95ba  vmovaps [rsp+0xC0], xmm12
000073307ffd95c3  vmovaps [rsp+0xD0], xmm13
000073307ffd95cc  vmovaps [rsp+0xE0], xmm15
000073307ffd95d5  sub rsp, 0x30
000073307ffd95d9  movaps [rsp], xmm14
000073307ffd95de  movaps [rsp+0x10], xmm8
000073307ffd95e4  movaps [rsp+0x20], xmm4
000073307ffd95e9  lea rdi, [rsp]
000073307ffd95ed  mov esi, 0x00
000073307ffd95f2  mov rax, 0x600DE0EC8530
000073307ffd95fc  call rax
000073307ffd95fe  movaps xmm14, [rsp]
000073307ffd9603  add rsp, 0x30
000073307ffd9607  vmovaps xmm0, [rsp]
000073307ffd960c  vmovaps xmm1, [rsp+0x10]
000073307ffd9612  vmovaps xmm2, [rsp+0x20]
000073307ffd9618  vmovaps xmm3, [rsp+0x30]
000073307ffd961e  vmovaps xmm4, [rsp+0x40]
000073307ffd9624  vmovaps xmm5, [rsp+0x50]
000073307ffd962a  vmovaps xmm6, [rsp+0x60]
000073307ffd9630  vmovaps xmm7, [rsp+0x70]
000073307ffd9636  vmovaps xmm8, [rsp+0x80]
000073307ffd963f  vmovaps xmm9, [rsp+0x90]
000073307ffd9648  vmovaps xmm10, [rsp+0xA0]
000073307ffd9651  vmovaps xmm11, [rsp+0xB0]
000073307ffd965a  vmovaps xmm12, [rsp+0xC0]
000073307ffd9663  vmovaps xmm13, [rsp+0xD0]
000073307ffd966c  vmovaps xmm15, [rsp+0xE0]
000073307ffd9675  add rsp, 0xF0
000073307ffd967c  pop r11
000073307ffd967e  pop r10
000073307ffd9680  pop r9
000073307ffd9682  pop r8
000073307ffd9684  pop rsi
000073307ffd9685  pop rdi
000073307ffd9686  pop rdx
000073307ffd9687  pop rcx
000073307ffd9688  pop rax
000073307ffd9689  add rsp, 0x08
000073307ffd968d  jmp 0x000073307FFD6265
000073307ffd9692  sub rsp, 0x08
000073307ffd9696  push rax
000073307ffd9697  push rcx
000073307ffd9698  push rdx
000073307ffd9699  push rdi
000073307ffd969a  push rsi
000073307ffd969b  push r8
000073307ffd969d  push r9
000073307ffd969f  push r10
000073307ffd96a1  push r11
000073307ffd96a3  sub rsp, 0xF0
000073307ffd96aa  vmovaps [rsp], xmm0
000073307ffd96af  vmovaps [rsp+0x10], xmm1
000073307ffd96b5  vmovaps [rsp+0x20], xmm2
000073307ffd96bb  vmovaps [rsp+0x30], xmm3
000073307ffd96c1  vmovaps [rsp+0x40], xmm5
000073307ffd96c7  vmovaps [rsp+0x50], xmm6
000073307ffd96cd  vmovaps [rsp+0x60], xmm7
000073307ffd96d3  vmovaps [rsp+0x70], xmm8
000073307ffd96d9  vmovaps [rsp+0x80], xmm9
000073307ffd96e2  vmovaps [rsp+0x90], xmm10
000073307ffd96eb  vmovaps [rsp+0xA0], xmm11
000073307ffd96f4  vmovaps [rsp+0xB0], xmm12
000073307ffd96fd  vmovaps [rsp+0xC0], xmm13
000073307ffd9706  vmovaps [rsp+0xD0], xmm14
000073307ffd970f  vmovaps [rsp+0xE0], xmm15
000073307ffd9718  sub rsp, 0x30
000073307ffd971c  movaps [rsp], xmm4
000073307ffd9720  movaps [rsp+0x10], xmm13
000073307ffd9726  movaps [rsp+0x20], xmm8
000073307ffd972c  lea rdi, [rsp]
000073307ffd9730  mov esi, 0x00
000073307ffd9735  mov rax, 0x600DE0EC8530
000073307ffd973f  call rax
000073307ffd9741  movaps xmm4, [rsp]
000073307ffd9745  add rsp, 0x30
000073307ffd9749  vmovaps xmm0, [rsp]
000073307ffd974e  vmovaps xmm1, [rsp+0x10]
000073307ffd9754  vmovaps xmm2, [rsp+0x20]
000073307ffd975a  vmovaps xmm3, [rsp+0x30]
000073307ffd9760  vmovaps xmm5, [rsp+0x40]
000073307ffd9766  vmovaps xmm6, [rsp+0x50]
000073307ffd976c  vmovaps xmm7, [rsp+0x60]
000073307ffd9772  vmovaps xmm8, [rsp+0x70]
000073307ffd9778  vmovaps xmm9, [rsp+0x80]
000073307ffd9781  vmovaps xmm10, [rsp+0x90]
000073307ffd978a  vmovaps xmm11, [rsp+0xA0]
000073307ffd9793  vmovaps xmm12, [rsp+0xB0]
000073307ffd979c  vmovaps xmm13, [rsp+0xC0]
000073307ffd97a5  vmovaps xmm14, [rsp+0xD0]
000073307ffd97ae  vmovaps xmm15, [rsp+0xE0]
000073307ffd97b7  add rsp, 0xF0
000073307ffd97be  pop r11
000073307ffd97c0  pop r10
000073307ffd97c2  pop r9
000073307ffd97c4  pop r8
000073307ffd97c6  pop rsi
000073307ffd97c7  pop rdi
000073307ffd97c8  pop rdx
000073307ffd97c9  pop rcx
000073307ffd97ca  pop rax
000073307ffd97cb  add rsp, 0x08
000073307ffd97cf  jmp 0x000073307FFD628A
000073307ffd97d4  sub rsp, 0x08
000073307ffd97d8  push rax
000073307ffd97d9  push rcx
000073307ffd97da  push rdx
000073307ffd97db  push rdi
000073307ffd97dc  push rsi
000073307ffd97dd  push r8
000073307ffd97df  push r9
000073307ffd97e1  push r10
000073307ffd97e3  push r11
000073307ffd97e5  sub rsp, 0xF0
000073307ffd97ec  vmovaps [rsp], xmm0
000073307ffd97f1  vmovaps [rsp+0x10], xmm1
000073307ffd97f7  vmovaps [rsp+0x20], xmm2
000073307ffd97fd  vmovaps [rsp+0x30], xmm3
000073307ffd9803  vmovaps [rsp+0x40], xmm4
000073307ffd9809  vmovaps [rsp+0x50], xmm5
000073307ffd980f  vmovaps [rsp+0x60], xmm6
000073307ffd9815  vmovaps [rsp+0x70], xmm7
000073307ffd981b  vmovaps [rsp+0x80], xmm8
000073307ffd9824  vmovaps [rsp+0x90], xmm9
000073307ffd982d  vmovaps [rsp+0xA0], xmm10
000073307ffd9836  vmovaps [rsp+0xB0], xmm11
000073307ffd983f  vmovaps [rsp+0xC0], xmm12
000073307ffd9848  vmovaps [rsp+0xD0], xmm14
000073307ffd9851  vmovaps [rsp+0xE0], xmm15
000073307ffd985a  sub rsp, 0x30
000073307ffd985e  movaps [rsp], xmm13
000073307ffd9863  movaps [rsp+0x10], xmm15
000073307ffd9869  movaps [rsp+0x20], xmm9
000073307ffd986f  lea rdi, [rsp]
000073307ffd9873  mov esi, 0x00
000073307ffd9878  mov rax, 0x600DE0EC8530
000073307ffd9882  call rax
000073307ffd9884  movaps xmm13, [rsp]
000073307ffd9889  add rsp, 0x30
000073307ffd988d  vmovaps xmm0, [rsp]
000073307ffd9892  vmovaps xmm1, [rsp+0x10]
000073307ffd9898  vmovaps xmm2, [rsp+0x20]
000073307ffd989e  vmovaps xmm3, [rsp+0x30]
000073307ffd98a4  vmovaps xmm4, [rsp+0x40]
000073307ffd98aa  vmovaps xmm5, [rsp+0x50]
000073307ffd98b0  vmovaps xmm6, [rsp+0x60]
000073307ffd98b6  vmovaps xmm7, [rsp+0x70]
000073307ffd98bc  vmovaps xmm8, [rsp+0x80]
000073307ffd98c5  vmovaps xmm9, [rsp+0x90]
000073307ffd98ce  vmovaps xmm10, [rsp+0xA0]
000073307ffd98d7  vmovaps xmm11, [rsp+0xB0]
000073307ffd98e0  vmovaps xmm12, [rsp+0xC0]
000073307ffd98e9  vmovaps xmm14, [rsp+0xD0]
000073307ffd98f2  vmovaps xmm15, [rsp+0xE0]
000073307ffd98fb  add rsp, 0xF0
000073307ffd9902  pop r11
000073307ffd9904  pop r10
000073307ffd9906  pop r9
000073307ffd9908  pop r8
000073307ffd990a  pop rsi
000073307ffd990b  pop rdi
000073307ffd990c  pop rdx
000073307ffd990d  pop rcx
000073307ffd990e  pop rax
000073307ffd990f  add rsp, 0x08
000073307ffd9913  jmp 0x000073307FFD62A5
000073307ffd9918  sub rsp, 0x08
000073307ffd991c  push rax
000073307ffd991d  push rcx
000073307ffd991e  push rdx
000073307ffd991f  push rdi
000073307ffd9920  push rsi
000073307ffd9921  push r8
000073307ffd9923  push r9
000073307ffd9925  push r10
000073307ffd9927  push r11
000073307ffd9929  sub rsp, 0xF0
000073307ffd9930  vmovaps [rsp], xmm0
000073307ffd9935  vmovaps [rsp+0x10], xmm1
000073307ffd993b  vmovaps [rsp+0x20], xmm2
000073307ffd9941  vmovaps [rsp+0x30], xmm3
000073307ffd9947  vmovaps [rsp+0x40], xmm4
000073307ffd994d  vmovaps [rsp+0x50], xmm5
000073307ffd9953  vmovaps [rsp+0x60], xmm6
000073307ffd9959  vmovaps [rsp+0x70], xmm7
000073307ffd995f  vmovaps [rsp+0x80], xmm8
000073307ffd9968  vmovaps [rsp+0x90], xmm9
000073307ffd9971  vmovaps [rsp+0xA0], xmm10
000073307ffd997a  vmovaps [rsp+0xB0], xmm11
000073307ffd9983  vmovaps [rsp+0xC0], xmm12
000073307ffd998c  vmovaps [rsp+0xD0], xmm13
000073307ffd9995  vmovaps [rsp+0xE0], xmm14
000073307ffd999e  sub rsp, 0x30
000073307ffd99a2  movaps [rsp], xmm15
000073307ffd99a7  movaps [rsp+0x10], xmm1
000073307ffd99ac  movaps [rsp+0x20], xmm5
000073307ffd99b1  lea rdi, [rsp]
000073307ffd99b5  mov esi, 0x00
000073307ffd99ba  mov rax, 0x600DE0EC8530
000073307ffd99c4  call rax
000073307ffd99c6  movaps xmm15, [rsp]
000073307ffd99cb  add rsp, 0x30
000073307ffd99cf  vmovaps xmm0, [rsp]
000073307ffd99d4  vmovaps xmm1, [rsp+0x10]
000073307ffd99da  vmovaps xmm2, [rsp+0x20]
000073307ffd99e0  vmovaps xmm3, [rsp+0x30]
000073307ffd99e6  vmovaps xmm4, [rsp+0x40]
000073307ffd99ec  vmovaps xmm5, [rsp+0x50]
000073307ffd99f2  vmovaps xmm6, [rsp+0x60]
000073307ffd99f8  vmovaps xmm7, [rsp+0x70]
000073307ffd99fe  vmovaps xmm8, [rsp+0x80]
000073307ffd9a07  vmovaps xmm9, [rsp+0x90]
000073307ffd9a10  vmovaps xmm10, [rsp+0xA0]
000073307ffd9a19  vmovaps xmm11, [rsp+0xB0]
000073307ffd9a22  vmovaps xmm12, [rsp+0xC0]
000073307ffd9a2b  vmovaps xmm13, [rsp+0xD0]
000073307ffd9a34  vmovaps xmm14, [rsp+0xE0]
000073307ffd9a3d  add rsp, 0xF0
000073307ffd9a44  pop r11
000073307ffd9a46  pop r10
000073307ffd9a48  pop r9
000073307ffd9a4a  pop r8
000073307ffd9a4c  pop rsi
000073307ffd9a4d  pop rdi
000073307ffd9a4e  pop rdx
000073307ffd9a4f  pop rcx
000073307ffd9a50  pop rax
000073307ffd9a51  add rsp, 0x08
000073307ffd9a55  jmp 0x000073307FFD62C0
000073307ffd9a5a  call 0x000073307FED64F0
000073307ffd9a5f  jmp 0x000073307FFD631B
000073307ffd9a64  sub rsp, 0x08
000073307ffd9a68  push rax
000073307ffd9a69  push rcx
000073307ffd9a6a  push rdx
000073307ffd9a6b  push rdi
000073307ffd9a6c  push rsi
000073307ffd9a6d  push r8
000073307ffd9a6f  push r9
000073307ffd9a71  push r10
000073307ffd9a73  push r11
000073307ffd9a75  sub rsp, 0xF0
000073307ffd9a7c  vmovaps [rsp], xmm0
000073307ffd9a81  vmovaps [rsp+0x10], xmm1
000073307ffd9a87  vmovaps [rsp+0x20], xmm2
000073307ffd9a8d  vmovaps [rsp+0x30], xmm3
000073307ffd9a93  vmovaps [rsp+0x40], xmm4
000073307ffd9a99  vmovaps [rsp+0x50], xmm5
000073307ffd9a9f  vmovaps [rsp+0x60], xmm6
000073307ffd9aa5  vmovaps [rsp+0x70], xmm7
000073307ffd9aab  vmovaps [rsp+0x80], xmm8
000073307ffd9ab4  vmovaps [rsp+0x90], xmm10
000073307ffd9abd  vmovaps [rsp+0xA0], xmm11
000073307ffd9ac6  vmovaps [rsp+0xB0], xmm12
000073307ffd9acf  vmovaps [rsp+0xC0], xmm13
000073307ffd9ad8  vmovaps [rsp+0xD0], xmm14
000073307ffd9ae1  vmovaps [rsp+0xE0], xmm15
000073307ffd9aea  sub rsp, 0x30
000073307ffd9aee  movaps [rsp], xmm9
000073307ffd9af3  movaps [rsp+0x10], xmm8
000073307ffd9af9  movaps [rsp+0x20], xmm11
000073307ffd9aff  lea rdi, [rsp]
000073307ffd9b03  mov esi, 0x00
000073307ffd9b08  mov rax, 0x600DE0EC8530
000073307ffd9b12  call rax
000073307ffd9b14  movaps xmm9, [rsp]
000073307ffd9b19  add rsp, 0x30
000073307ffd9b1d  vmovaps xmm0, [rsp]
000073307ffd9b22  vmovaps xmm1, [rsp+0x10]
000073307ffd9b28  vmovaps xmm2, [rsp+0x20]
000073307ffd9b2e  vmovaps xmm3, [rsp+0x30]
000073307ffd9b34  vmovaps xmm4, [rsp+0x40]
000073307ffd9b3a  vmovaps xmm5, [rsp+0x50]
000073307ffd9b40  vmovaps xmm6, [rsp+0x60]
000073307ffd9b46  vmovaps xmm7, [rsp+0x70]
000073307ffd9b4c  vmovaps xmm8, [rsp+0x80]
000073307ffd9b55  vmovaps xmm10, [rsp+0x90]
000073307ffd9b5e  vmovaps xmm11, [rsp+0xA0]
000073307ffd9b67  vmovaps xmm12, [rsp+0xB0]
000073307ffd9b70  vmovaps xmm13, [rsp+0xC0]
000073307ffd9b79  vmovaps xmm14, [rsp+0xD0]
000073307ffd9b82  vmovaps xmm15, [rsp+0xE0]
000073307ffd9b8b  add rsp, 0xF0
000073307ffd9b92  pop r11
000073307ffd9b94  pop r10
000073307ffd9b96  pop r9
000073307ffd9b98  pop r8
000073307ffd9b9a  pop rsi
000073307ffd9b9b  pop rdi
000073307ffd9b9c  pop rdx
000073307ffd9b9d  pop rcx
000073307ffd9b9e  pop rax
000073307ffd9b9f  add rsp, 0x08
000073307ffd9ba3  jmp 0x000073307FFD6352
000073307ffd9ba8  sub rsp, 0x08
000073307ffd9bac  push rax
000073307ffd9bad  push rcx
000073307ffd9bae  push rdx
000073307ffd9baf  push rdi
000073307ffd9bb0  push rsi
000073307ffd9bb1  push r8
000073307ffd9bb3  push r9
000073307ffd9bb5  push r10
000073307ffd9bb7  push r11
000073307ffd9bb9  sub rsp, 0xF0
000073307ffd9bc0  vmovaps [rsp], xmm0
000073307ffd9bc5  vmovaps [rsp+0x10], xmm1
000073307ffd9bcb  vmovaps [rsp+0x20], xmm2
000073307ffd9bd1  vmovaps [rsp+0x30], xmm3
000073307ffd9bd7  vmovaps [rsp+0x40], xmm4
000073307ffd9bdd  vmovaps [rsp+0x50], xmm5
000073307ffd9be3  vmovaps [rsp+0x60], xmm6
000073307ffd9be9  vmovaps [rsp+0x70], xmm7
000073307ffd9bef  vmovaps [rsp+0x80], xmm8
000073307ffd9bf8  vmovaps [rsp+0x90], xmm9
000073307ffd9c01  vmovaps [rsp+0xA0], xmm10
000073307ffd9c0a  vmovaps [rsp+0xB0], xmm12
000073307ffd9c13  vmovaps [rsp+0xC0], xmm13
000073307ffd9c1c  vmovaps [rsp+0xD0], xmm14
000073307ffd9c25  vmovaps [rsp+0xE0], xmm15
000073307ffd9c2e  sub rsp, 0x30
000073307ffd9c32  movaps [rsp], xmm11
000073307ffd9c37  movaps [rsp+0x10], xmm10
000073307ffd9c3d  movaps [rsp+0x20], xmm6
000073307ffd9c42  lea rdi, [rsp]
000073307ffd9c46  mov esi, 0x00
000073307ffd9c4b  mov rax, 0x600DE0EC8530
000073307ffd9c55  call rax
000073307ffd9c57  movaps xmm11, [rsp]
000073307ffd9c5c  add rsp, 0x30
000073307ffd9c60  vmovaps xmm0, [rsp]
000073307ffd9c65  vmovaps xmm1, [rsp+0x10]
000073307ffd9c6b  vmovaps xmm2, [rsp+0x20]
000073307ffd9c71  vmovaps xmm3, [rsp+0x30]
000073307ffd9c77  vmovaps xmm4, [rsp+0x40]
000073307ffd9c7d  vmovaps xmm5, [rsp+0x50]
000073307ffd9c83  vmovaps xmm6, [rsp+0x60]
000073307ffd9c89  vmovaps xmm7, [rsp+0x70]
000073307ffd9c8f  vmovaps xmm8, [rsp+0x80]
000073307ffd9c98  vmovaps xmm9, [rsp+0x90]
000073307ffd9ca1  vmovaps xmm10, [rsp+0xA0]
000073307ffd9caa  vmovaps xmm12, [rsp+0xB0]
000073307ffd9cb3  vmovaps xmm13, [rsp+0xC0]
000073307ffd9cbc  vmovaps xmm14, [rsp+0xD0]
000073307ffd9cc5  vmovaps xmm15, [rsp+0xE0]
000073307ffd9cce  add rsp, 0xF0
000073307ffd9cd5  pop r11
000073307ffd9cd7  pop r10
000073307ffd9cd9  pop r9
000073307ffd9cdb  pop r8
000073307ffd9cdd  pop rsi
000073307ffd9cde  pop rdi
000073307ffd9cdf  pop rdx
000073307ffd9ce0  pop rcx
000073307ffd9ce1  pop rax
000073307ffd9ce2  add rsp, 0x08
000073307ffd9ce6  jmp 0x000073307FFD636D
000073307ffd9ceb  sub rsp, 0x08
000073307ffd9cef  push rax
000073307ffd9cf0  push rcx
000073307ffd9cf1  push rdx
000073307ffd9cf2  push rdi
000073307ffd9cf3  push rsi
000073307ffd9cf4  push r8
000073307ffd9cf6  push r9
000073307ffd9cf8  push r10
000073307ffd9cfa  push r11
000073307ffd9cfc  sub rsp, 0xF0
000073307ffd9d03  vmovaps [rsp], xmm0
000073307ffd9d08  vmovaps [rsp+0x10], xmm1
000073307ffd9d0e  vmovaps [rsp+0x20], xmm2
000073307ffd9d14  vmovaps [rsp+0x30], xmm3
000073307ffd9d1a  vmovaps [rsp+0x40], xmm4
000073307ffd9d20  vmovaps [rsp+0x50], xmm5
000073307ffd9d26  vmovaps [rsp+0x60], xmm6
000073307ffd9d2c  vmovaps [rsp+0x70], xmm7
000073307ffd9d32  vmovaps [rsp+0x80], xmm8
000073307ffd9d3b  vmovaps [rsp+0x90], xmm9
000073307ffd9d44  vmovaps [rsp+0xA0], xmm11
000073307ffd9d4d  vmovaps [rsp+0xB0], xmm12
000073307ffd9d56  vmovaps [rsp+0xC0], xmm13
000073307ffd9d5f  vmovaps [rsp+0xD0], xmm14
000073307ffd9d68  vmovaps [rsp+0xE0], xmm15
000073307ffd9d71  sub rsp, 0x30
000073307ffd9d75  movaps [rsp], xmm10
000073307ffd9d7a  movaps [rsp+0x10], xmm14
000073307ffd9d80  movaps [rsp+0x20], xmm4
000073307ffd9d85  lea rdi, [rsp]
000073307ffd9d89  mov esi, 0x00
000073307ffd9d8e  mov rax, 0x600DE0EC8530
000073307ffd9d98  call rax
000073307ffd9d9a  movaps xmm10, [rsp]
000073307ffd9d9f  add rsp, 0x30
000073307ffd9da3  vmovaps xmm0, [rsp]
000073307ffd9da8  vmovaps xmm1, [rsp+0x10]
000073307ffd9dae  vmovaps xmm2, [rsp+0x20]
000073307ffd9db4  vmovaps xmm3, [rsp+0x30]
000073307ffd9dba  vmovaps xmm4, [rsp+0x40]
000073307ffd9dc0  vmovaps xmm5, [rsp+0x50]
000073307ffd9dc6  vmovaps xmm6, [rsp+0x60]
000073307ffd9dcc  vmovaps xmm7, [rsp+0x70]
000073307ffd9dd2  vmovaps xmm8, [rsp+0x80]
000073307ffd9ddb  vmovaps xmm9, [rsp+0x90]
000073307ffd9de4  vmovaps xmm11, [rsp+0xA0]
000073307ffd9ded  vmovaps xmm12, [rsp+0xB0]
000073307ffd9df6  vmovaps xmm13, [rsp+0xC0]
000073307ffd9dff  vmovaps xmm14, [rsp+0xD0]
000073307ffd9e08  vmovaps xmm15, [rsp+0xE0]
000073307ffd9e11  add rsp, 0xF0
000073307ffd9e18  pop r11
000073307ffd9e1a  pop r10
000073307ffd9e1c  pop r9
000073307ffd9e1e  pop r8
000073307ffd9e20  pop rsi
000073307ffd9e21  pop rdi
000073307ffd9e22  pop rdx
000073307ffd9e23  pop rcx
000073307ffd9e24  pop rax
000073307ffd9e25  add rsp, 0x08
000073307ffd9e29  jmp 0x000073307FFD6388
000073307ffd9e2e  sub rsp, 0x08
000073307ffd9e32  push rax
000073307ffd9e33  push rcx
000073307ffd9e34  push rdx
000073307ffd9e35  push rdi
000073307ffd9e36  push rsi
000073307ffd9e37  push r8
000073307ffd9e39  push r9
000073307ffd9e3b  push r10
000073307ffd9e3d  push r11
000073307ffd9e3f  sub rsp, 0xF0
000073307ffd9e46  vmovaps [rsp], xmm0
000073307ffd9e4b  vmovaps [rsp+0x10], xmm1
000073307ffd9e51  vmovaps [rsp+0x20], xmm2
000073307ffd9e57  vmovaps [rsp+0x30], xmm3
000073307ffd9e5d  vmovaps [rsp+0x40], xmm4
000073307ffd9e63  vmovaps [rsp+0x50], xmm5
000073307ffd9e69  vmovaps [rsp+0x60], xmm6
000073307ffd9e6f  vmovaps [rsp+0x70], xmm7
000073307ffd9e75  vmovaps [rsp+0x80], xmm9
000073307ffd9e7e  vmovaps [rsp+0x90], xmm10
000073307ffd9e87  vmovaps [rsp+0xA0], xmm11
000073307ffd9e90  vmovaps [rsp+0xB0], xmm12
000073307ffd9e99  vmovaps [rsp+0xC0], xmm13
000073307ffd9ea2  vmovaps [rsp+0xD0], xmm14
000073307ffd9eab  vmovaps [rsp+0xE0], xmm15
000073307ffd9eb4  sub rsp, 0x30
000073307ffd9eb8  movaps [rsp], xmm8
000073307ffd9ebd  movaps [rsp+0x10], xmm1
000073307ffd9ec2  movaps [rsp+0x20], xmm14
000073307ffd9ec8  lea rdi, [rsp]
000073307ffd9ecc  mov esi, 0x00
000073307ffd9ed1  mov rax, 0x600DE0EC8530
000073307ffd9edb  call rax
000073307ffd9edd  movaps xmm8, [rsp]
000073307ffd9ee2  add rsp, 0x30
000073307ffd9ee6  vmovaps xmm0, [rsp]
000073307ffd9eeb  vmovaps xmm1, [rsp+0x10]
000073307ffd9ef1  vmovaps xmm2, [rsp+0x20]
000073307ffd9ef7  vmovaps xmm3, [rsp+0x30]
000073307ffd9efd  vmovaps xmm4, [rsp+0x40]
000073307ffd9f03  vmovaps xmm5, [rsp+0x50]
000073307ffd9f09  vmovaps xmm6, [rsp+0x60]
000073307ffd9f0f  vmovaps xmm7, [rsp+0x70]
000073307ffd9f15  vmovaps xmm9, [rsp+0x80]
000073307ffd9f1e  vmovaps xmm10, [rsp+0x90]
000073307ffd9f27  vmovaps xmm11, [rsp+0xA0]
000073307ffd9f30  vmovaps xmm12, [rsp+0xB0]
000073307ffd9f39  vmovaps xmm13, [rsp+0xC0]
000073307ffd9f42  vmovaps xmm14, [rsp+0xD0]
000073307ffd9f4b  vmovaps xmm15, [rsp+0xE0]
000073307ffd9f54  add rsp, 0xF0
000073307ffd9f5b  pop r11
000073307ffd9f5d  pop r10
000073307ffd9f5f  pop r9
000073307ffd9f61  pop r8
000073307ffd9f63  pop rsi
000073307ffd9f64  pop rdi
000073307ffd9f65  pop rdx
000073307ffd9f66  pop rcx
000073307ffd9f67  pop rax
000073307ffd9f68  add rsp, 0x08
000073307ffd9f6c  jmp 0x000073307FFD63AE
000073307ffd9f71  sub rsp, 0x08
000073307ffd9f75  push rax
000073307ffd9f76  push rcx
000073307ffd9f77  push rdx
000073307ffd9f78  push rdi
000073307ffd9f79  push rsi
000073307ffd9f7a  push r8
000073307ffd9f7c  push r9
000073307ffd9f7e  push r10
000073307ffd9f80  push r11
000073307ffd9f82  sub rsp, 0xF0
000073307ffd9f89  vmovaps [rsp], xmm0
000073307ffd9f8e  vmovaps [rsp+0x10], xmm1
000073307ffd9f94  vmovaps [rsp+0x20], xmm2
000073307ffd9f9a  vmovaps [rsp+0x30], xmm3
000073307ffd9fa0  vmovaps [rsp+0x40], xmm4
000073307ffd9fa6  vmovaps [rsp+0x50], xmm5
000073307ffd9fac  vmovaps [rsp+0x60], xmm7
000073307ffd9fb2  vmovaps [rsp+0x70], xmm8
000073307ffd9fb8  vmovaps [rsp+0x80], xmm9
000073307ffd9fc1  vmovaps [rsp+0x90], xmm10
000073307ffd9fca  vmovaps [rsp+0xA0], xmm11
000073307ffd9fd3  vmovaps [rsp+0xB0], xmm12
000073307ffd9fdc  vmovaps [rsp+0xC0], xmm13
000073307ffd9fe5  vmovaps [rsp+0xD0], xmm14
000073307ffd9fee  vmovaps [rsp+0xE0], xmm15
000073307ffd9ff7  sub rsp, 0x30
000073307ffd9ffb  movaps [rsp], xmm6
000073307ffd9fff  movaps [rsp+0x10], xmm1
000073307ffda004  movaps [rsp+0x20], xmm14
000073307ffda00a  lea rdi, [rsp]
000073307ffda00e  mov esi, 0x00
000073307ffda013  mov rax, 0x600DE0EC8530
000073307ffda01d  call rax
000073307ffda01f  movaps xmm6, [rsp]
000073307ffda023  add rsp, 0x30
000073307ffda027  vmovaps xmm0, [rsp]
000073307ffda02c  vmovaps xmm1, [rsp+0x10]
000073307ffda032  vmovaps xmm2, [rsp+0x20]
000073307ffda038  vmovaps xmm3, [rsp+0x30]
000073307ffda03e  vmovaps xmm4, [rsp+0x40]
000073307ffda044  vmovaps xmm5, [rsp+0x50]
000073307ffda04a  vmovaps xmm7, [rsp+0x60]
000073307ffda050  vmovaps xmm8, [rsp+0x70]
000073307ffda056  vmovaps xmm9, [rsp+0x80]
000073307ffda05f  vmovaps xmm10, [rsp+0x90]
000073307ffda068  vmovaps xmm11, [rsp+0xA0]
000073307ffda071  vmovaps xmm12, [rsp+0xB0]
000073307ffda07a  vmovaps xmm13, [rsp+0xC0]
000073307ffda083  vmovaps xmm14, [rsp+0xD0]
000073307ffda08c  vmovaps xmm15, [rsp+0xE0]
000073307ffda095  add rsp, 0xF0
000073307ffda09c  pop r11
000073307ffda09e  pop r10
000073307ffda0a0  pop r9
000073307ffda0a2  pop r8
000073307ffda0a4  pop rsi
000073307ffda0a5  pop rdi
000073307ffda0a6  pop rdx
000073307ffda0a7  pop rcx
000073307ffda0a8  pop rax
000073307ffda0a9  add rsp, 0x08
000073307ffda0ad  jmp 0x000073307FFD63DA
000073307ffda0b2  sub rsp, 0x08
000073307ffda0b6  push rax
000073307ffda0b7  push rcx
000073307ffda0b8  push rdx
000073307ffda0b9  push rdi
000073307ffda0ba  push rsi
000073307ffda0bb  push r8
000073307ffda0bd  push r9
000073307ffda0bf  push r10
000073307ffda0c1  push r11
000073307ffda0c3  sub rsp, 0xF0
000073307ffda0ca  vmovaps [rsp], xmm0
000073307ffda0cf  vmovaps [rsp+0x10], xmm1
000073307ffda0d5  vmovaps [rsp+0x20], xmm2
000073307ffda0db  vmovaps [rsp+0x30], xmm3
000073307ffda0e1  vmovaps [rsp+0x40], xmm4
000073307ffda0e7  vmovaps [rsp+0x50], xmm5
000073307ffda0ed  vmovaps [rsp+0x60], xmm6
000073307ffda0f3  vmovaps [rsp+0x70], xmm7
000073307ffda0f9  vmovaps [rsp+0x80], xmm8
000073307ffda102  vmovaps [rsp+0x90], xmm9
000073307ffda10b  vmovaps [rsp+0xA0], xmm10
000073307ffda114  vmovaps [rsp+0xB0], xmm11
000073307ffda11d  vmovaps [rsp+0xC0], xmm12
000073307ffda126  vmovaps [rsp+0xD0], xmm13
000073307ffda12f  vmovaps [rsp+0xE0], xmm15
000073307ffda138  sub rsp, 0x30
000073307ffda13c  movaps [rsp], xmm14
000073307ffda141  movaps [rsp+0x10], xmm12
000073307ffda147  movaps [rsp+0x20], xmm1
000073307ffda14c  lea rdi, [rsp]
000073307ffda150  mov esi, 0x00
000073307ffda155  mov rax, 0x600DE0EC8530
000073307ffda15f  call rax
000073307ffda161  movaps xmm14, [rsp]
000073307ffda166  add rsp, 0x30
000073307ffda16a  vmovaps xmm0, [rsp]
000073307ffda16f  vmovaps xmm1, [rsp+0x10]
000073307ffda175  vmovaps xmm2, [rsp+0x20]
000073307ffda17b  vmovaps xmm3, [rsp+0x30]
000073307ffda181  vmovaps xmm4, [rsp+0x40]
000073307ffda187  vmovaps xmm5, [rsp+0x50]
000073307ffda18d  vmovaps xmm6, [rsp+0x60]
000073307ffda193  vmovaps xmm7, [rsp+0x70]
000073307ffda199  vmovaps xmm8, [rsp+0x80]
000073307ffda1a2  vmovaps xmm9, [rsp+0x90]
000073307ffda1ab  vmovaps xmm10, [rsp+0xA0]
000073307ffda1b4  vmovaps xmm11, [rsp+0xB0]
000073307ffda1bd  vmovaps xmm12, [rsp+0xC0]
000073307ffda1c6  vmovaps xmm13, [rsp+0xD0]
000073307ffda1cf  vmovaps xmm15, [rsp+0xE0]
000073307ffda1d8  add rsp, 0xF0
000073307ffda1df  pop r11
000073307ffda1e1  pop r10
000073307ffda1e3  pop r9
000073307ffda1e5  pop r8
000073307ffda1e7  pop rsi
000073307ffda1e8  pop rdi
000073307ffda1e9  pop rdx
000073307ffda1ea  pop rcx
000073307ffda1eb  pop rax
000073307ffda1ec  add rsp, 0x08
000073307ffda1f0  jmp 0x000073307FFD6400
000073307ffda1f5  sub rsp, 0x08
000073307ffda1f9  push rax
000073307ffda1fa  push rcx
000073307ffda1fb  push rdx
000073307ffda1fc  push rdi
000073307ffda1fd  push rsi
000073307ffda1fe  push r8
000073307ffda200  push r9
000073307ffda202  push r10
000073307ffda204  push r11
000073307ffda206  sub rsp, 0xF0
000073307ffda20d  vmovaps [rsp], xmm0
000073307ffda212  vmovaps [rsp+0x10], xmm2
000073307ffda218  vmovaps [rsp+0x20], xmm3
000073307ffda21e  vmovaps [rsp+0x30], xmm4
000073307ffda224  vmovaps [rsp+0x40], xmm5
000073307ffda22a  vmovaps [rsp+0x50], xmm6
000073307ffda230  vmovaps [rsp+0x60], xmm7
000073307ffda236  vmovaps [rsp+0x70], xmm8
000073307ffda23c  vmovaps [rsp+0x80], xmm9
000073307ffda245  vmovaps [rsp+0x90], xmm10
000073307ffda24e  vmovaps [rsp+0xA0], xmm11
000073307ffda257  vmovaps [rsp+0xB0], xmm12
000073307ffda260  vmovaps [rsp+0xC0], xmm13
000073307ffda269  vmovaps [rsp+0xD0], xmm14
000073307ffda272  vmovaps [rsp+0xE0], xmm15
000073307ffda27b  sub rsp, 0x30
000073307ffda27f  movaps [rsp], xmm1
000073307ffda283  movaps [rsp+0x10], xmm13
000073307ffda289  movaps [rsp+0x20], xmm9
000073307ffda28f  lea rdi, [rsp]
000073307ffda293  mov esi, 0x00
000073307ffda298  mov rax, 0x600DE0EC8530
000073307ffda2a2  call rax
000073307ffda2a4  movaps xmm1, [rsp]
000073307ffda2a8  add rsp, 0x30
000073307ffda2ac  vmovaps xmm0, [rsp]
000073307ffda2b1  vmovaps xmm2, [rsp+0x10]
000073307ffda2b7  vmovaps xmm3, [rsp+0x20]
000073307ffda2bd  vmovaps xmm4, [rsp+0x30]
000073307ffda2c3  vmovaps xmm5, [rsp+0x40]
000073307ffda2c9  vmovaps xmm6, [rsp+0x50]
000073307ffda2cf  vmovaps xmm7, [rsp+0x60]
000073307ffda2d5  vmovaps xmm8, [rsp+0x70]
000073307ffda2db  vmovaps xmm9, [rsp+0x80]
000073307ffda2e4  vmovaps xmm10, [rsp+0x90]
000073307ffda2ed  vmovaps xmm11, [rsp+0xA0]
000073307ffda2f6  vmovaps xmm12, [rsp+0xB0]
000073307ffda2ff  vmovaps xmm13, [rsp+0xC0]
000073307ffda308  vmovaps xmm14, [rsp+0xD0]
000073307ffda311  vmovaps xmm15, [rsp+0xE0]
000073307ffda31a  add rsp, 0xF0
000073307ffda321  pop r11
000073307ffda323  pop r10
000073307ffda325  pop r9
000073307ffda327  pop r8
000073307ffda329  pop rsi
000073307ffda32a  pop rdi
000073307ffda32b  pop rdx
000073307ffda32c  pop rcx
000073307ffda32d  pop rax
000073307ffda32e  add rsp, 0x08
000073307ffda332  jmp 0x000073307FFD641A
000073307ffda337  sub rsp, 0x08
000073307ffda33b  push rax
000073307ffda33c  push rcx
000073307ffda33d  push rdx
000073307ffda33e  push rdi
000073307ffda33f  push rsi
000073307ffda340  push r8
000073307ffda342  push r9
000073307ffda344  push r10
000073307ffda346  push r11
000073307ffda348  sub rsp, 0xF0
000073307ffda34f  vmovaps [rsp], xmm0
000073307ffda354  vmovaps [rsp+0x10], xmm1
000073307ffda35a  vmovaps [rsp+0x20], xmm2
000073307ffda360  vmovaps [rsp+0x30], xmm3
000073307ffda366  vmovaps [rsp+0x40], xmm4
000073307ffda36c  vmovaps [rsp+0x50], xmm5
000073307ffda372  vmovaps [rsp+0x60], xmm6
000073307ffda378  vmovaps [rsp+0x70], xmm7
000073307ffda37e  vmovaps [rsp+0x80], xmm8
000073307ffda387  vmovaps [rsp+0x90], xmm9
000073307ffda390  vmovaps [rsp+0xA0], xmm10
000073307ffda399  vmovaps [rsp+0xB0], xmm11
000073307ffda3a2  vmovaps [rsp+0xC0], xmm13
000073307ffda3ab  vmovaps [rsp+0xD0], xmm14
000073307ffda3b4  vmovaps [rsp+0xE0], xmm15
000073307ffda3bd  sub rsp, 0x30
000073307ffda3c1  movaps [rsp], xmm12
000073307ffda3c6  movaps [rsp+0x10], xmm7
000073307ffda3cb  movaps [rsp+0x20], xmm13
000073307ffda3d1  lea rdi, [rsp]
000073307ffda3d5  mov esi, 0x00
000073307ffda3da  mov rax, 0x600DE0EC8530
000073307ffda3e4  call rax
000073307ffda3e6  movaps xmm12, [rsp]
000073307ffda3eb  add rsp, 0x30
000073307ffda3ef  vmovaps xmm0, [rsp]
000073307ffda3f4  vmovaps xmm1, [rsp+0x10]
000073307ffda3fa  vmovaps xmm2, [rsp+0x20]
000073307ffda400  vmovaps xmm3, [rsp+0x30]
000073307ffda406  vmovaps xmm4, [rsp+0x40]
000073307ffda40c  vmovaps xmm5, [rsp+0x50]
000073307ffda412  vmovaps xmm6, [rsp+0x60]
000073307ffda418  vmovaps xmm7, [rsp+0x70]
000073307ffda41e  vmovaps xmm8, [rsp+0x80]
000073307ffda427  vmovaps xmm9, [rsp+0x90]
000073307ffda430  vmovaps xmm10, [rsp+0xA0]
000073307ffda439  vmovaps xmm11, [rsp+0xB0]
000073307ffda442  vmovaps xmm13, [rsp+0xC0]
000073307ffda44b  vmovaps xmm14, [rsp+0xD0]
000073307ffda454  vmovaps xmm15, [rsp+0xE0]
000073307ffda45d  add rsp, 0xF0
000073307ffda464  pop r11
000073307ffda466  pop r10
000073307ffda468  pop r9
000073307ffda46a  pop r8
000073307ffda46c  pop rsi
000073307ffda46d  pop rdi
000073307ffda46e  pop rdx
000073307ffda46f  pop rcx
000073307ffda470  pop rax
000073307ffda471  add rsp, 0x08
000073307ffda475  jmp 0x000073307FFD6441
000073307ffda47a  sub rsp, 0x08
000073307ffda47e  push rax
000073307ffda47f  push rcx
000073307ffda480  push rdx
000073307ffda481  push rdi
000073307ffda482  push rsi
000073307ffda483  push r8
000073307ffda485  push r9
000073307ffda487  push r10
000073307ffda489  push r11
000073307ffda48b  sub rsp, 0xF0
000073307ffda492  vmovaps [rsp], xmm0
000073307ffda497  vmovaps [rsp+0x10], xmm1
000073307ffda49d  vmovaps [rsp+0x20], xmm2
000073307ffda4a3  vmovaps [rsp+0x30], xmm3
000073307ffda4a9  vmovaps [rsp+0x40], xmm4
000073307ffda4af  vmovaps [rsp+0x50], xmm5
000073307ffda4b5  vmovaps [rsp+0x60], xmm6
000073307ffda4bb  vmovaps [rsp+0x70], xmm7
000073307ffda4c1  vmovaps [rsp+0x80], xmm8
000073307ffda4ca  vmovaps [rsp+0x90], xmm9
000073307ffda4d3  vmovaps [rsp+0xA0], xmm10
000073307ffda4dc  vmovaps [rsp+0xB0], xmm11
000073307ffda4e5  vmovaps [rsp+0xC0], xmm12
000073307ffda4ee  vmovaps [rsp+0xD0], xmm14
000073307ffda4f7  vmovaps [rsp+0xE0], xmm15
000073307ffda500  sub rsp, 0x30
000073307ffda504  movaps [rsp], xmm13
000073307ffda509  movaps [rsp+0x10], xmm15
000073307ffda50f  movaps [rsp+0x20], xmm8
000073307ffda515  lea rdi, [rsp]
000073307ffda519  mov esi, 0x00
000073307ffda51e  mov rax, 0x600DE0EC8530
000073307ffda528  call rax
000073307ffda52a  movaps xmm13, [rsp]
000073307ffda52f  add rsp, 0x30
000073307ffda533  vmovaps xmm0, [rsp]
000073307ffda538  vmovaps xmm1, [rsp+0x10]
000073307ffda53e  vmovaps xmm2, [rsp+0x20]
000073307ffda544  vmovaps xmm3, [rsp+0x30]
000073307ffda54a  vmovaps xmm4, [rsp+0x40]
000073307ffda550  vmovaps xmm5, [rsp+0x50]
000073307ffda556  vmovaps xmm6, [rsp+0x60]
000073307ffda55c  vmovaps xmm7, [rsp+0x70]
000073307ffda562  vmovaps xmm8, [rsp+0x80]
000073307ffda56b  vmovaps xmm9, [rsp+0x90]
000073307ffda574  vmovaps xmm10, [rsp+0xA0]
000073307ffda57d  vmovaps xmm11, [rsp+0xB0]
000073307ffda586  vmovaps xmm12, [rsp+0xC0]
000073307ffda58f  vmovaps xmm14, [rsp+0xD0]
000073307ffda598  vmovaps xmm15, [rsp+0xE0]
000073307ffda5a1  add rsp, 0xF0
000073307ffda5a8  pop r11
000073307ffda5aa  pop r10
000073307ffda5ac  pop r9
000073307ffda5ae  pop r8
000073307ffda5b0  pop rsi
000073307ffda5b1  pop rdi
000073307ffda5b2  pop rdx
000073307ffda5b3  pop rcx
000073307ffda5b4  pop rax
000073307ffda5b5  add rsp, 0x08
000073307ffda5b9  jmp 0x000073307FFD645C
000073307ffda5be  sub rsp, 0x08
000073307ffda5c2  push rax
000073307ffda5c3  push rcx
000073307ffda5c4  push rdx
000073307ffda5c5  push rdi
000073307ffda5c6  push rsi
000073307ffda5c7  push r8
000073307ffda5c9  push r9
000073307ffda5cb  push r10
000073307ffda5cd  push r11
000073307ffda5cf  sub rsp, 0xF0
000073307ffda5d6  vmovaps [rsp], xmm0
000073307ffda5db  vmovaps [rsp+0x10], xmm1
000073307ffda5e1  vmovaps [rsp+0x20], xmm2
000073307ffda5e7  vmovaps [rsp+0x30], xmm3
000073307ffda5ed  vmovaps [rsp+0x40], xmm4
000073307ffda5f3  vmovaps [rsp+0x50], xmm5
000073307ffda5f9  vmovaps [rsp+0x60], xmm6
000073307ffda5ff  vmovaps [rsp+0x70], xmm7
000073307ffda605  vmovaps [rsp+0x80], xmm9
000073307ffda60e  vmovaps [rsp+0x90], xmm10
000073307ffda617  vmovaps [rsp+0xA0], xmm11
000073307ffda620  vmovaps [rsp+0xB0], xmm12
000073307ffda629  vmovaps [rsp+0xC0], xmm13
000073307ffda632  vmovaps [rsp+0xD0], xmm14
000073307ffda63b  vmovaps [rsp+0xE0], xmm15
000073307ffda644  sub rsp, 0x30
000073307ffda648  movaps [rsp], xmm8
000073307ffda64d  movaps [rsp+0x10], xmm15
000073307ffda653  movaps [rsp+0x20], xmm9
000073307ffda659  lea rdi, [rsp]
000073307ffda65d  mov esi, 0x00
000073307ffda662  mov rax, 0x600DE0EC8530
000073307ffda66c  call rax
000073307ffda66e  movaps xmm8, [rsp]
000073307ffda673  add rsp, 0x30
000073307ffda677  vmovaps xmm0, [rsp]
000073307ffda67c  vmovaps xmm1, [rsp+0x10]
000073307ffda682  vmovaps xmm2, [rsp+0x20]
000073307ffda688  vmovaps xmm3, [rsp+0x30]
000073307ffda68e  vmovaps xmm4, [rsp+0x40]
000073307ffda694  vmovaps xmm5, [rsp+0x50]
000073307ffda69a  vmovaps xmm6, [rsp+0x60]
000073307ffda6a0  vmovaps xmm7, [rsp+0x70]
000073307ffda6a6  vmovaps xmm9, [rsp+0x80]
000073307ffda6af  vmovaps xmm10, [rsp+0x90]
000073307ffda6b8  vmovaps xmm11, [rsp+0xA0]
000073307ffda6c1  vmovaps xmm12, [rsp+0xB0]
000073307ffda6ca  vmovaps xmm13, [rsp+0xC0]
000073307ffda6d3  vmovaps xmm14, [rsp+0xD0]
000073307ffda6dc  vmovaps xmm15, [rsp+0xE0]
000073307ffda6e5  add rsp, 0xF0
000073307ffda6ec  pop r11
000073307ffda6ee  pop r10
000073307ffda6f0  pop r9
000073307ffda6f2  pop r8
000073307ffda6f4  pop rsi
000073307ffda6f5  pop rdi
000073307ffda6f6  pop rdx
000073307ffda6f7  pop rcx
000073307ffda6f8  pop rax
000073307ffda6f9  add rsp, 0x08
000073307ffda6fd  jmp 0x000073307FFD648A
000073307ffda702  sub rsp, 0x08
000073307ffda706  push rax
000073307ffda707  push rcx
000073307ffda708  push rdx
000073307ffda709  push rdi
000073307ffda70a  push rsi
000073307ffda70b  push r8
000073307ffda70d  push r9
000073307ffda70f  push r10
000073307ffda711  push r11
000073307ffda713  sub rsp, 0xF0
000073307ffda71a  vmovaps [rsp], xmm0
000073307ffda71f  vmovaps [rsp+0x10], xmm1
000073307ffda725  vmovaps [rsp+0x20], xmm2
000073307ffda72b  vmovaps [rsp+0x30], xmm3
000073307ffda731  vmovaps [rsp+0x40], xmm4
000073307ffda737  vmovaps [rsp+0x50], xmm5
000073307ffda73d  vmovaps [rsp+0x60], xmm6
000073307ffda743  vmovaps [rsp+0x70], xmm7
000073307ffda749  vmovaps [rsp+0x80], xmm8
000073307ffda752  vmovaps [rsp+0x90], xmm9
000073307ffda75b  vmovaps [rsp+0xA0], xmm10
000073307ffda764  vmovaps [rsp+0xB0], xmm11
000073307ffda76d  vmovaps [rsp+0xC0], xmm12
000073307ffda776  vmovaps [rsp+0xD0], xmm13
000073307ffda77f  vmovaps [rsp+0xE0], xmm14
000073307ffda788  sub rsp, 0x30
000073307ffda78c  movaps [rsp], xmm15
000073307ffda791  movaps [rsp+0x10], xmm11
000073307ffda797  movaps [rsp+0x20], xmm6
000073307ffda79c  lea rdi, [rsp]
000073307ffda7a0  mov esi, 0x00
000073307ffda7a5  mov rax, 0x600DE0EC8530
000073307ffda7af  call rax
000073307ffda7b1  movaps xmm15, [rsp]
000073307ffda7b6  add rsp, 0x30
000073307ffda7ba  vmovaps xmm0, [rsp]
000073307ffda7bf  vmovaps xmm1, [rsp+0x10]
000073307ffda7c5  vmovaps xmm2, [rsp+0x20]
000073307ffda7cb  vmovaps xmm3, [rsp+0x30]
000073307ffda7d1  vmovaps xmm4, [rsp+0x40]
000073307ffda7d7  vmovaps xmm5, [rsp+0x50]
000073307ffda7dd  vmovaps xmm6, [rsp+0x60]
000073307ffda7e3  vmovaps xmm7, [rsp+0x70]
000073307ffda7e9  vmovaps xmm8, [rsp+0x80]
000073307ffda7f2  vmovaps xmm9, [rsp+0x90]
000073307ffda7fb  vmovaps xmm10, [rsp+0xA0]
000073307ffda804  vmovaps xmm11, [rsp+0xB0]
000073307ffda80d  vmovaps xmm12, [rsp+0xC0]
000073307ffda816  vmovaps xmm13, [rsp+0xD0]
000073307ffda81f  vmovaps xmm14, [rsp+0xE0]
000073307ffda828  add rsp, 0xF0
000073307ffda82f  pop r11
000073307ffda831  pop r10
000073307ffda833  pop r9
000073307ffda835  pop r8
000073307ffda837  pop rsi
000073307ffda838  pop rdi
000073307ffda839  pop rdx
000073307ffda83a  pop rcx
000073307ffda83b  pop rax
000073307ffda83c  add rsp, 0x08
000073307ffda840  jmp 0x000073307FFD64A5
000073307ffda845  sub rsp, 0x08
000073307ffda849  push rax
000073307ffda84a  push rcx
000073307ffda84b  push rdx
000073307ffda84c  push rdi
000073307ffda84d  push rsi
000073307ffda84e  push r8
000073307ffda850  push r9
000073307ffda852  push r10
000073307ffda854  push r11
000073307ffda856  sub rsp, 0xF0
000073307ffda85d  vmovaps [rsp], xmm0
000073307ffda862  vmovaps [rsp+0x10], xmm1
000073307ffda868  vmovaps [rsp+0x20], xmm2
000073307ffda86e  vmovaps [rsp+0x30], xmm3
000073307ffda874  vmovaps [rsp+0x40], xmm4
000073307ffda87a  vmovaps [rsp+0x50], xmm5
000073307ffda880  vmovaps [rsp+0x60], xmm6
000073307ffda886  vmovaps [rsp+0x70], xmm8
000073307ffda88c  vmovaps [rsp+0x80], xmm9
000073307ffda895  vmovaps [rsp+0x90], xmm10
000073307ffda89e  vmovaps [rsp+0xA0], xmm11
000073307ffda8a7  vmovaps [rsp+0xB0], xmm12
000073307ffda8b0  vmovaps [rsp+0xC0], xmm13
000073307ffda8b9  vmovaps [rsp+0xD0], xmm14
000073307ffda8c2  vmovaps [rsp+0xE0], xmm15
000073307ffda8cb  sub rsp, 0x30
000073307ffda8cf  movaps [rsp], xmm7
000073307ffda8d3  movaps [rsp+0x10], xmm11
000073307ffda8d9  movaps [rsp+0x20], xmm9
000073307ffda8df  lea rdi, [rsp]
000073307ffda8e3  mov esi, 0x00
000073307ffda8e8  mov rax, 0x600DE0EC8530
000073307ffda8f2  call rax
000073307ffda8f4  movaps xmm7, [rsp]
000073307ffda8f8  add rsp, 0x30
000073307ffda8fc  vmovaps xmm0, [rsp]
000073307ffda901  vmovaps xmm1, [rsp+0x10]
000073307ffda907  vmovaps xmm2, [rsp+0x20]
000073307ffda90d  vmovaps xmm3, [rsp+0x30]
000073307ffda913  vmovaps xmm4, [rsp+0x40]
000073307ffda919  vmovaps xmm5, [rsp+0x50]
000073307ffda91f  vmovaps xmm6, [rsp+0x60]
000073307ffda925  vmovaps xmm8, [rsp+0x70]
000073307ffda92b  vmovaps xmm9, [rsp+0x80]
000073307ffda934  vmovaps xmm10, [rsp+0x90]
000073307ffda93d  vmovaps xmm11, [rsp+0xA0]
000073307ffda946  vmovaps xmm12, [rsp+0xB0]
000073307ffda94f  vmovaps xmm13, [rsp+0xC0]
000073307ffda958  vmovaps xmm14, [rsp+0xD0]
000073307ffda961  vmovaps xmm15, [rsp+0xE0]
000073307ffda96a  add rsp, 0xF0
000073307ffda971  pop r11
000073307ffda973  pop r10
000073307ffda975  pop r9
000073307ffda977  pop r8
000073307ffda979  pop rsi
000073307ffda97a  pop rdi
000073307ffda97b  pop rdx
000073307ffda97c  pop rcx
000073307ffda97d  pop rax
000073307ffda97e  add rsp, 0x08
000073307ffda982  jmp 0x000073307FFD64D2
000073307ffda987  sub rsp, 0x08
000073307ffda98b  push rax
000073307ffda98c  push rcx
000073307ffda98d  push rdx
000073307ffda98e  push rdi
000073307ffda98f  push rsi
000073307ffda990  push r8
000073307ffda992  push r9
000073307ffda994  push r10
000073307ffda996  push r11
000073307ffda998  sub rsp, 0xF0
000073307ffda99f  vmovaps [rsp], xmm0
000073307ffda9a4  vmovaps [rsp+0x10], xmm1
000073307ffda9aa  vmovaps [rsp+0x20], xmm2
000073307ffda9b0  vmovaps [rsp+0x30], xmm3
000073307ffda9b6  vmovaps [rsp+0x40], xmm4
000073307ffda9bc  vmovaps [rsp+0x50], xmm5
000073307ffda9c2  vmovaps [rsp+0x60], xmm6
000073307ffda9c8  vmovaps [rsp+0x70], xmm7
000073307ffda9ce  vmovaps [rsp+0x80], xmm8
000073307ffda9d7  vmovaps [rsp+0x90], xmm9
000073307ffda9e0  vmovaps [rsp+0xA0], xmm10
000073307ffda9e9  vmovaps [rsp+0xB0], xmm12
000073307ffda9f2  vmovaps [rsp+0xC0], xmm13
000073307ffda9fb  vmovaps [rsp+0xD0], xmm14
000073307ffdaa04  vmovaps [rsp+0xE0], xmm15
000073307ffdaa0d  sub rsp, 0x30
000073307ffdaa11  movaps [rsp], xmm11
000073307ffdaa16  movaps [rsp+0x10], xmm10
000073307ffdaa1c  movaps [rsp+0x20], xmm14
000073307ffdaa22  lea rdi, [rsp]
000073307ffdaa26  mov esi, 0x00
000073307ffdaa2b  mov rax, 0x600DE0EC8530
000073307ffdaa35  call rax
000073307ffdaa37  movaps xmm11, [rsp]
000073307ffdaa3c  add rsp, 0x30
000073307ffdaa40  vmovaps xmm0, [rsp]
000073307ffdaa45  vmovaps xmm1, [rsp+0x10]
000073307ffdaa4b  vmovaps xmm2, [rsp+0x20]
000073307ffdaa51  vmovaps xmm3, [rsp+0x30]
000073307ffdaa57  vmovaps xmm4, [rsp+0x40]
000073307ffdaa5d  vmovaps xmm5, [rsp+0x50]
000073307ffdaa63  vmovaps xmm6, [rsp+0x60]
000073307ffdaa69  vmovaps xmm7, [rsp+0x70]
000073307ffdaa6f  vmovaps xmm8, [rsp+0x80]
000073307ffdaa78  vmovaps xmm9, [rsp+0x90]
000073307ffdaa81  vmovaps xmm10, [rsp+0xA0]
000073307ffdaa8a  vmovaps xmm12, [rsp+0xB0]
000073307ffdaa93  vmovaps xmm13, [rsp+0xC0]
000073307ffdaa9c  vmovaps xmm14, [rsp+0xD0]
000073307ffdaaa5  vmovaps xmm15, [rsp+0xE0]
000073307ffdaaae  add rsp, 0xF0
000073307ffdaab5  pop r11
000073307ffdaab7  pop r10
000073307ffdaab9  pop r9
000073307ffdaabb  pop r8
000073307ffdaabd  pop rsi
000073307ffdaabe  pop rdi
000073307ffdaabf  pop rdx
000073307ffdaac0  pop rcx
000073307ffdaac1  pop rax
000073307ffdaac2  add rsp, 0x08
000073307ffdaac6  jmp 0x000073307FFD64ED
000073307ffdaacb  call 0x000073307FEE45A0
000073307ffdaad0  jmp 0x000073307FFD64F7
000073307ffdaad5  sub rsp, 0x08
000073307ffdaad9  push rax
000073307ffdaada  push rcx
000073307ffdaadb  push rdx
000073307ffdaadc  push rdi
000073307ffdaadd  push rsi
000073307ffdaade  push r8
000073307ffdaae0  push r9
000073307ffdaae2  push r10
000073307ffdaae4  push r11
000073307ffdaae6  sub rsp, 0xF0
000073307ffdaaed  vmovaps [rsp], xmm0
000073307ffdaaf2  vmovaps [rsp+0x10], xmm1
000073307ffdaaf8  vmovaps [rsp+0x20], xmm2
000073307ffdaafe  vmovaps [rsp+0x30], xmm3
000073307ffdab04  vmovaps [rsp+0x40], xmm4
000073307ffdab0a  vmovaps [rsp+0x50], xmm5
000073307ffdab10  vmovaps [rsp+0x60], xmm6
000073307ffdab16  vmovaps [rsp+0x70], xmm7
000073307ffdab1c  vmovaps [rsp+0x80], xmm8
000073307ffdab25  vmovaps [rsp+0x90], xmm9
000073307ffdab2e  vmovaps [rsp+0xA0], xmm11
000073307ffdab37  vmovaps [rsp+0xB0], xmm12
000073307ffdab40  vmovaps [rsp+0xC0], xmm13
000073307ffdab49  vmovaps [rsp+0xD0], xmm14
000073307ffdab52  vmovaps [rsp+0xE0], xmm15
000073307ffdab5b  sub rsp, 0x30
000073307ffdab5f  movaps [rsp], xmm10
000073307ffdab64  movaps [rsp+0x10], xmm1
000073307ffdab69  movaps [rsp+0x20], xmm12
000073307ffdab6f  lea rdi, [rsp]
000073307ffdab73  mov esi, 0x00
000073307ffdab78  mov rax, 0x600DE0EC8530
000073307ffdab82  call rax
000073307ffdab84  movaps xmm10, [rsp]
000073307ffdab89  add rsp, 0x30
000073307ffdab8d  vmovaps xmm0, [rsp]
000073307ffdab92  vmovaps xmm1, [rsp+0x10]
000073307ffdab98  vmovaps xmm2, [rsp+0x20]
000073307ffdab9e  vmovaps xmm3, [rsp+0x30]
000073307ffdaba4  vmovaps xmm4, [rsp+0x40]
000073307ffdabaa  vmovaps xmm5, [rsp+0x50]
000073307ffdabb0  vmovaps xmm6, [rsp+0x60]
000073307ffdabb6  vmovaps xmm7, [rsp+0x70]
000073307ffdabbc  vmovaps xmm8, [rsp+0x80]
000073307ffdabc5  vmovaps xmm9, [rsp+0x90]
000073307ffdabce  vmovaps xmm11, [rsp+0xA0]
000073307ffdabd7  vmovaps xmm12, [rsp+0xB0]
000073307ffdabe0  vmovaps xmm13, [rsp+0xC0]
000073307ffdabe9  vmovaps xmm14, [rsp+0xD0]
000073307ffdabf2  vmovaps xmm15, [rsp+0xE0]
000073307ffdabfb  add rsp, 0xF0
000073307ffdac02  pop r11
000073307ffdac04  pop r10
000073307ffdac06  pop r9
000073307ffdac08  pop r8
000073307ffdac0a  pop rsi
000073307ffdac0b  pop rdi
000073307ffdac0c  pop rdx
000073307ffdac0d  pop rcx
000073307ffdac0e  pop rax
000073307ffdac0f  add rsp, 0x08
000073307ffdac13  jmp 0x000073307FFD651A
000073307ffdac18  sub rsp, 0x08
000073307ffdac1c  push rax
000073307ffdac1d  push rcx
000073307ffdac1e  push rdx
000073307ffdac1f  push rdi
000073307ffdac20  push rsi
000073307ffdac21  push r8
000073307ffdac23  push r9
000073307ffdac25  push r10
000073307ffdac27  push r11
000073307ffdac29  sub rsp, 0xF0
000073307ffdac30  vmovaps [rsp], xmm0
000073307ffdac35  vmovaps [rsp+0x10], xmm1
000073307ffdac3b  vmovaps [rsp+0x20], xmm2
000073307ffdac41  vmovaps [rsp+0x30], xmm3
000073307ffdac47  vmovaps [rsp+0x40], xmm4
000073307ffdac4d  vmovaps [rsp+0x50], xmm5
000073307ffdac53  vmovaps [rsp+0x60], xmm6
000073307ffdac59  vmovaps [rsp+0x70], xmm7
000073307ffdac5f  vmovaps [rsp+0x80], xmm8
000073307ffdac68  vmovaps [rsp+0x90], xmm9
000073307ffdac71  vmovaps [rsp+0xA0], xmm10
000073307ffdac7a  vmovaps [rsp+0xB0], xmm11
000073307ffdac83  vmovaps [rsp+0xC0], xmm13
000073307ffdac8c  vmovaps [rsp+0xD0], xmm14
000073307ffdac95  vmovaps [rsp+0xE0], xmm15
000073307ffdac9e  sub rsp, 0x30
000073307ffdaca2  movaps [rsp], xmm12
000073307ffdaca7  movaps [rsp+0x10], xmm14
000073307ffdacad  movaps [rsp+0x20], xmm1
000073307ffdacb2  lea rdi, [rsp]
000073307ffdacb6  mov esi, 0x00
000073307ffdacbb  mov rax, 0x600DE0EC8530
000073307ffdacc5  call rax
000073307ffdacc7  movaps xmm12, [rsp]
000073307ffdaccc  add rsp, 0x30
000073307ffdacd0  vmovaps xmm0, [rsp]
000073307ffdacd5  vmovaps xmm1, [rsp+0x10]
000073307ffdacdb  vmovaps xmm2, [rsp+0x20]
000073307ffdace1  vmovaps xmm3, [rsp+0x30]
000073307ffdace7  vmovaps xmm4, [rsp+0x40]
000073307ffdaced  vmovaps xmm5, [rsp+0x50]
000073307ffdacf3  vmovaps xmm6, [rsp+0x60]
000073307ffdacf9  vmovaps xmm7, [rsp+0x70]
000073307ffdacff  vmovaps xmm8, [rsp+0x80]
000073307ffdad08  vmovaps xmm9, [rsp+0x90]
000073307ffdad11  vmovaps xmm10, [rsp+0xA0]
000073307ffdad1a  vmovaps xmm11, [rsp+0xB0]
000073307ffdad23  vmovaps xmm13, [rsp+0xC0]
000073307ffdad2c  vmovaps xmm14, [rsp+0xD0]
000073307ffdad35  vmovaps xmm15, [rsp+0xE0]
000073307ffdad3e  add rsp, 0xF0
000073307ffdad45  pop r11
000073307ffdad47  pop r10
000073307ffdad49  pop r9
000073307ffdad4b  pop r8
000073307ffdad4d  pop rsi
000073307ffdad4e  pop rdi
000073307ffdad4f  pop rdx
000073307ffdad50  pop rcx
000073307ffdad51  pop rax
000073307ffdad52  add rsp, 0x08
000073307ffdad56  jmp 0x000073307FFD6549
000073307ffdad5b  sub rsp, 0x08
000073307ffdad5f  push rax
000073307ffdad60  push rcx
000073307ffdad61  push rdx
000073307ffdad62  push rdi
000073307ffdad63  push rsi
000073307ffdad64  push r8
000073307ffdad66  push r9
000073307ffdad68  push r10
000073307ffdad6a  push r11
000073307ffdad6c  sub rsp, 0xF0
000073307ffdad73  vmovaps [rsp], xmm0
000073307ffdad78  vmovaps [rsp+0x10], xmm1
000073307ffdad7e  vmovaps [rsp+0x20], xmm2
000073307ffdad84  vmovaps [rsp+0x30], xmm3
000073307ffdad8a  vmovaps [rsp+0x40], xmm4
000073307ffdad90  vmovaps [rsp+0x50], xmm5
000073307ffdad96  vmovaps [rsp+0x60], xmm6
000073307ffdad9c  vmovaps [rsp+0x70], xmm7
000073307ffdada2  vmovaps [rsp+0x80], xmm8
000073307ffdadab  vmovaps [rsp+0x90], xmm9
000073307ffdadb4  vmovaps [rsp+0xA0], xmm10
000073307ffdadbd  vmovaps [rsp+0xB0], xmm11
000073307ffdadc6  vmovaps [rsp+0xC0], xmm12
000073307ffdadcf  vmovaps [rsp+0xD0], xmm13
000073307ffdadd8  vmovaps [rsp+0xE0], xmm15
000073307ffdade1  sub rsp, 0x30
000073307ffdade5  movaps [rsp], xmm14
000073307ffdadea  movaps [rsp+0x10], xmm9
000073307ffdadf0  movaps [rsp+0x20], xmm1
000073307ffdadf5  lea rdi, [rsp]
000073307ffdadf9  mov esi, 0x00
000073307ffdadfe  mov rax, 0x600DE0EC8530
000073307ffdae08  call rax
000073307ffdae0a  movaps xmm14, [rsp]
000073307ffdae0f  add rsp, 0x30
000073307ffdae13  vmovaps xmm0, [rsp]
000073307ffdae18  vmovaps xmm1, [rsp+0x10]
000073307ffdae1e  vmovaps xmm2, [rsp+0x20]
000073307ffdae24  vmovaps xmm3, [rsp+0x30]
000073307ffdae2a  vmovaps xmm4, [rsp+0x40]
000073307ffdae30  vmovaps xmm5, [rsp+0x50]
000073307ffdae36  vmovaps xmm6, [rsp+0x60]
000073307ffdae3c  vmovaps xmm7, [rsp+0x70]
000073307ffdae42  vmovaps xmm8, [rsp+0x80]
000073307ffdae4b  vmovaps xmm9, [rsp+0x90]
000073307ffdae54  vmovaps xmm10, [rsp+0xA0]
000073307ffdae5d  vmovaps xmm11, [rsp+0xB0]
000073307ffdae66  vmovaps xmm12, [rsp+0xC0]
000073307ffdae6f  vmovaps xmm13, [rsp+0xD0]
000073307ffdae78  vmovaps xmm15, [rsp+0xE0]
000073307ffdae81  add rsp, 0xF0
000073307ffdae88  pop r11
000073307ffdae8a  pop r10
000073307ffdae8c  pop r9
000073307ffdae8e  pop r8
000073307ffdae90  pop rsi
000073307ffdae91  pop rdi
000073307ffdae92  pop rdx
000073307ffdae93  pop rcx
000073307ffdae94  pop rax
000073307ffdae95  add rsp, 0x08
000073307ffdae99  jmp 0x000073307FFD6578
000073307ffdae9e  sub rsp, 0x08
000073307ffdaea2  push rax
000073307ffdaea3  push rcx
000073307ffdaea4  push rdx
000073307ffdaea5  push rdi
000073307ffdaea6  push rsi
000073307ffdaea7  push r8
000073307ffdaea9  push r9
000073307ffdaeab  push r10
000073307ffdaead  push r11
000073307ffdaeaf  sub rsp, 0xF0
000073307ffdaeb6  vmovaps [rsp], xmm0
000073307ffdaebb  vmovaps [rsp+0x10], xmm2
000073307ffdaec1  vmovaps [rsp+0x20], xmm3
000073307ffdaec7  vmovaps [rsp+0x30], xmm4
000073307ffdaecd  vmovaps [rsp+0x40], xmm5
000073307ffdaed3  vmovaps [rsp+0x50], xmm6
000073307ffdaed9  vmovaps [rsp+0x60], xmm7
000073307ffdaedf  vmovaps [rsp+0x70], xmm8
000073307ffdaee5  vmovaps [rsp+0x80], xmm9
000073307ffdaeee  vmovaps [rsp+0x90], xmm10
000073307ffdaef7  vmovaps [rsp+0xA0], xmm11
000073307ffdaf00  vmovaps [rsp+0xB0], xmm12
000073307ffdaf09  vmovaps [rsp+0xC0], xmm13
000073307ffdaf12  vmovaps [rsp+0xD0], xmm14
000073307ffdaf1b  vmovaps [rsp+0xE0], xmm15
000073307ffdaf24  sub rsp, 0x30
000073307ffdaf28  movaps [rsp], xmm1
000073307ffdaf2c  movaps [rsp+0x10], xmm13
000073307ffdaf32  movaps [rsp+0x20], xmm8
000073307ffdaf38  lea rdi, [rsp]
000073307ffdaf3c  mov esi, 0x00
000073307ffdaf41  mov rax, 0x600DE0EC8530
000073307ffdaf4b  call rax
000073307ffdaf4d  movaps xmm1, [rsp]
000073307ffdaf51  add rsp, 0x30
000073307ffdaf55  vmovaps xmm0, [rsp]
000073307ffdaf5a  vmovaps xmm2, [rsp+0x10]
000073307ffdaf60  vmovaps xmm3, [rsp+0x20]
000073307ffdaf66  vmovaps xmm4, [rsp+0x30]
000073307ffdaf6c  vmovaps xmm5, [rsp+0x40]
000073307ffdaf72  vmovaps xmm6, [rsp+0x50]
000073307ffdaf78  vmovaps xmm7, [rsp+0x60]
000073307ffdaf7e  vmovaps xmm8, [rsp+0x70]
000073307ffdaf84  vmovaps xmm9, [rsp+0x80]
000073307ffdaf8d  vmovaps xmm10, [rsp+0x90]
000073307ffdaf96  vmovaps xmm11, [rsp+0xA0]
000073307ffdaf9f  vmovaps xmm12, [rsp+0xB0]
000073307ffdafa8  vmovaps xmm13, [rsp+0xC0]
000073307ffdafb1  vmovaps xmm14, [rsp+0xD0]
000073307ffdafba  vmovaps xmm15, [rsp+0xE0]
000073307ffdafc3  add rsp, 0xF0
000073307ffdafca  pop r11
000073307ffdafcc  pop r10
000073307ffdafce  pop r9
000073307ffdafd0  pop r8
000073307ffdafd2  pop rsi
000073307ffdafd3  pop rdi
000073307ffdafd4  pop rdx
000073307ffdafd5  pop rcx
000073307ffdafd6  pop rax
000073307ffdafd7  add rsp, 0x08
000073307ffdafdb  jmp 0x000073307FFD659A
000073307ffdafe0  call 0x000073307FE0C260
000073307ffdafe5  jmp 0x000073307FFD65A8
000073307ffdafea  call 0x000073307FEDE950
000073307ffdafef  jmp 0x000073307FFD65B2
000073307ffdaff4  sub rsp, 0x08
000073307ffdaff8  push rax
000073307ffdaff9  push rcx
000073307ffdaffa  push rdx
000073307ffdaffb  push rdi
000073307ffdaffc  push rsi
000073307ffdaffd  push r8
000073307ffdafff  push r9
000073307ffdb001  push r10
000073307ffdb003  push r11
000073307ffdb005  sub rsp, 0xF0
000073307ffdb00c  vmovaps [rsp], xmm0
000073307ffdb011  vmovaps [rsp+0x10], xmm1
000073307ffdb017  vmovaps [rsp+0x20], xmm2
000073307ffdb01d  vmovaps [rsp+0x30], xmm3
000073307ffdb023  vmovaps [rsp+0x40], xmm4
000073307ffdb029  vmovaps [rsp+0x50], xmm5
000073307ffdb02f  vmovaps [rsp+0x60], xmm6
000073307ffdb035  vmovaps [rsp+0x70], xmm7
000073307ffdb03b  vmovaps [rsp+0x80], xmm9
000073307ffdb044  vmovaps [rsp+0x90], xmm10
000073307ffdb04d  vmovaps [rsp+0xA0], xmm11
000073307ffdb056  vmovaps [rsp+0xB0], xmm12
000073307ffdb05f  vmovaps [rsp+0xC0], xmm13
000073307ffdb068  vmovaps [rsp+0xD0], xmm14
000073307ffdb071  vmovaps [rsp+0xE0], xmm15
000073307ffdb07a  sub rsp, 0x30
000073307ffdb07e  movaps [rsp], xmm8
000073307ffdb083  movaps [rsp+0x10], xmm15
000073307ffdb089  movaps [rsp+0x20], xmm7
000073307ffdb08e  lea rdi, [rsp]
000073307ffdb092  mov esi, 0x00
000073307ffdb097  mov rax, 0x600DE0EC8530
000073307ffdb0a1  call rax
000073307ffdb0a3  movaps xmm8, [rsp]
000073307ffdb0a8  add rsp, 0x30
000073307ffdb0ac  vmovaps xmm0, [rsp]
000073307ffdb0b1  vmovaps xmm1, [rsp+0x10]
000073307ffdb0b7  vmovaps xmm2, [rsp+0x20]
000073307ffdb0bd  vmovaps xmm3, [rsp+0x30]
000073307ffdb0c3  vmovaps xmm4, [rsp+0x40]
000073307ffdb0c9  vmovaps xmm5, [rsp+0x50]
000073307ffdb0cf  vmovaps xmm6, [rsp+0x60]
000073307ffdb0d5  vmovaps xmm7, [rsp+0x70]
000073307ffdb0db  vmovaps xmm9, [rsp+0x80]
000073307ffdb0e4  vmovaps xmm10, [rsp+0x90]
000073307ffdb0ed  vmovaps xmm11, [rsp+0xA0]
000073307ffdb0f6  vmovaps xmm12, [rsp+0xB0]
000073307ffdb0ff  vmovaps xmm13, [rsp+0xC0]
000073307ffdb108  vmovaps xmm14, [rsp+0xD0]
000073307ffdb111  vmovaps xmm15, [rsp+0xE0]
000073307ffdb11a  add rsp, 0xF0
000073307ffdb121  pop r11
000073307ffdb123  pop r10
000073307ffdb125  pop r9
000073307ffdb127  pop r8
000073307ffdb129  pop rsi
000073307ffdb12a  pop rdi
000073307ffdb12b  pop rdx
000073307ffdb12c  pop rcx
000073307ffdb12d  pop rax
000073307ffdb12e  add rsp, 0x08
000073307ffdb132  jmp 0x000073307FFD65D4
000073307ffdb137  sub rsp, 0x08
000073307ffdb13b  push rax
000073307ffdb13c  push rcx
000073307ffdb13d  push rdx
000073307ffdb13e  push rdi
000073307ffdb13f  push rsi
000073307ffdb140  push r8
000073307ffdb142  push r9
000073307ffdb144  push r10
000073307ffdb146  push r11
000073307ffdb148  sub rsp, 0xF0
000073307ffdb14f  vmovaps [rsp], xmm0
000073307ffdb154  vmovaps [rsp+0x10], xmm1
000073307ffdb15a  vmovaps [rsp+0x20], xmm2
000073307ffdb160  vmovaps [rsp+0x30], xmm3
000073307ffdb166  vmovaps [rsp+0x40], xmm4
000073307ffdb16c  vmovaps [rsp+0x50], xmm5
000073307ffdb172  vmovaps [rsp+0x60], xmm6
000073307ffdb178  vmovaps [rsp+0x70], xmm8
000073307ffdb17e  vmovaps [rsp+0x80], xmm9
000073307ffdb187  vmovaps [rsp+0x90], xmm10
000073307ffdb190  vmovaps [rsp+0xA0], xmm11
000073307ffdb199  vmovaps [rsp+0xB0], xmm12
000073307ffdb1a2  vmovaps [rsp+0xC0], xmm13
000073307ffdb1ab  vmovaps [rsp+0xD0], xmm14
000073307ffdb1b4  vmovaps [rsp+0xE0], xmm15
000073307ffdb1bd  sub rsp, 0x30
000073307ffdb1c1  movaps [rsp], xmm7
000073307ffdb1c5  movaps [rsp+0x10], xmm9
000073307ffdb1cb  movaps [rsp+0x20], xmm15
000073307ffdb1d1  lea rdi, [rsp]
000073307ffdb1d5  mov esi, 0x00
000073307ffdb1da  mov rax, 0x600DE0EC8530
000073307ffdb1e4  call rax
000073307ffdb1e6  movaps xmm7, [rsp]
000073307ffdb1ea  add rsp, 0x30
000073307ffdb1ee  vmovaps xmm0, [rsp]
000073307ffdb1f3  vmovaps xmm1, [rsp+0x10]
000073307ffdb1f9  vmovaps xmm2, [rsp+0x20]
000073307ffdb1ff  vmovaps xmm3, [rsp+0x30]
000073307ffdb205  vmovaps xmm4, [rsp+0x40]
000073307ffdb20b  vmovaps xmm5, [rsp+0x50]
000073307ffdb211  vmovaps xmm6, [rsp+0x60]
000073307ffdb217  vmovaps xmm8, [rsp+0x70]
000073307ffdb21d  vmovaps xmm9, [rsp+0x80]
000073307ffdb226  vmovaps xmm10, [rsp+0x90]
000073307ffdb22f  vmovaps xmm11, [rsp+0xA0]
000073307ffdb238  vmovaps xmm12, [rsp+0xB0]
000073307ffdb241  vmovaps xmm13, [rsp+0xC0]
000073307ffdb24a  vmovaps xmm14, [rsp+0xD0]
000073307ffdb253  vmovaps xmm15, [rsp+0xE0]
000073307ffdb25c  add rsp, 0xF0
000073307ffdb263  pop r11
000073307ffdb265  pop r10
000073307ffdb267  pop r9
000073307ffdb269  pop r8
000073307ffdb26b  pop rsi
000073307ffdb26c  pop rdi
000073307ffdb26d  pop rdx
000073307ffdb26e  pop rcx
000073307ffdb26f  pop rax
000073307ffdb270  add rsp, 0x08
000073307ffdb274  jmp 0x000073307FFD6601
000073307ffdb279  sub rsp, 0x08
000073307ffdb27d  push rax
000073307ffdb27e  push rcx
000073307ffdb27f  push rdx
000073307ffdb280  push rdi
000073307ffdb281  push rsi
000073307ffdb282  push r8
000073307ffdb284  push r9
000073307ffdb286  push r10
000073307ffdb288  push r11
000073307ffdb28a  sub rsp, 0xF0
000073307ffdb291  vmovaps [rsp], xmm0
000073307ffdb296  vmovaps [rsp+0x10], xmm1
000073307ffdb29c  vmovaps [rsp+0x20], xmm2
000073307ffdb2a2  vmovaps [rsp+0x30], xmm3
000073307ffdb2a8  vmovaps [rsp+0x40], xmm4
000073307ffdb2ae  vmovaps [rsp+0x50], xmm5
000073307ffdb2b4  vmovaps [rsp+0x60], xmm6
000073307ffdb2ba  vmovaps [rsp+0x70], xmm7
000073307ffdb2c0  vmovaps [rsp+0x80], xmm8
000073307ffdb2c9  vmovaps [rsp+0x90], xmm10
000073307ffdb2d2  vmovaps [rsp+0xA0], xmm11
000073307ffdb2db  vmovaps [rsp+0xB0], xmm12
000073307ffdb2e4  vmovaps [rsp+0xC0], xmm13
000073307ffdb2ed  vmovaps [rsp+0xD0], xmm14
000073307ffdb2f6  vmovaps [rsp+0xE0], xmm15
000073307ffdb2ff  sub rsp, 0x30
000073307ffdb303  movaps [rsp], xmm9
000073307ffdb308  movaps [rsp+0x10], xmm13
000073307ffdb30e  movaps [rsp+0x20], xmm15
000073307ffdb314  lea rdi, [rsp]
000073307ffdb318  mov esi, 0x00
000073307ffdb31d  mov rax, 0x600DE0EC8530
000073307ffdb327  call rax
000073307ffdb329  movaps xmm9, [rsp]
000073307ffdb32e  add rsp, 0x30
000073307ffdb332  vmovaps xmm0, [rsp]
000073307ffdb337  vmovaps xmm1, [rsp+0x10]
000073307ffdb33d  vmovaps xmm2, [rsp+0x20]
000073307ffdb343  vmovaps xmm3, [rsp+0x30]
000073307ffdb349  vmovaps xmm4, [rsp+0x40]
000073307ffdb34f  vmovaps xmm5, [rsp+0x50]
000073307ffdb355  vmovaps xmm6, [rsp+0x60]
000073307ffdb35b  vmovaps xmm7, [rsp+0x70]
000073307ffdb361  vmovaps xmm8, [rsp+0x80]
000073307ffdb36a  vmovaps xmm10, [rsp+0x90]
000073307ffdb373  vmovaps xmm11, [rsp+0xA0]
000073307ffdb37c  vmovaps xmm12, [rsp+0xB0]
000073307ffdb385  vmovaps xmm13, [rsp+0xC0]
000073307ffdb38e  vmovaps xmm14, [rsp+0xD0]
000073307ffdb397  vmovaps xmm15, [rsp+0xE0]
000073307ffdb3a0  add rsp, 0xF0
000073307ffdb3a7  pop r11
000073307ffdb3a9  pop r10
000073307ffdb3ab  pop r9
000073307ffdb3ad  pop r8
000073307ffdb3af  pop rsi
000073307ffdb3b0  pop rdi
000073307ffdb3b1  pop rdx
000073307ffdb3b2  pop rcx
000073307ffdb3b3  pop rax
000073307ffdb3b4  add rsp, 0x08
000073307ffdb3b8  jmp 0x000073307FFD662F
000073307ffdb3bd  sub rsp, 0x08
000073307ffdb3c1  push rax
000073307ffdb3c2  push rcx
000073307ffdb3c3  push rdx
000073307ffdb3c4  push rdi
000073307ffdb3c5  push rsi
000073307ffdb3c6  push r8
000073307ffdb3c8  push r9
000073307ffdb3ca  push r10
000073307ffdb3cc  push r11
000073307ffdb3ce  sub rsp, 0xF0
000073307ffdb3d5  vmovaps [rsp], xmm0
000073307ffdb3da  vmovaps [rsp+0x10], xmm1
000073307ffdb3e0  vmovaps [rsp+0x20], xmm2
000073307ffdb3e6  vmovaps [rsp+0x30], xmm3
000073307ffdb3ec  vmovaps [rsp+0x40], xmm4
000073307ffdb3f2  vmovaps [rsp+0x50], xmm5
000073307ffdb3f8  vmovaps [rsp+0x60], xmm6
000073307ffdb3fe  vmovaps [rsp+0x70], xmm7
000073307ffdb404  vmovaps [rsp+0x80], xmm8
000073307ffdb40d  vmovaps [rsp+0x90], xmm9
000073307ffdb416  vmovaps [rsp+0xA0], xmm10
000073307ffdb41f  vmovaps [rsp+0xB0], xmm11
000073307ffdb428  vmovaps [rsp+0xC0], xmm12
000073307ffdb431  vmovaps [rsp+0xD0], xmm13
000073307ffdb43a  vmovaps [rsp+0xE0], xmm14
000073307ffdb443  sub rsp, 0x30
000073307ffdb447  movaps [rsp], xmm15
000073307ffdb44c  movaps [rsp+0x10], xmm11
000073307ffdb452  movaps [rsp+0x20], xmm12
000073307ffdb458  lea rdi, [rsp]
000073307ffdb45c  mov esi, 0x00
000073307ffdb461  mov rax, 0x600DE0EC8530
000073307ffdb46b  call rax
000073307ffdb46d  movaps xmm15, [rsp]
000073307ffdb472  add rsp, 0x30
000073307ffdb476  vmovaps xmm0, [rsp]
000073307ffdb47b  vmovaps xmm1, [rsp+0x10]
000073307ffdb481  vmovaps xmm2, [rsp+0x20]
000073307ffdb487  vmovaps xmm3, [rsp+0x30]
000073307ffdb48d  vmovaps xmm4, [rsp+0x40]
000073307ffdb493  vmovaps xmm5, [rsp+0x50]
000073307ffdb499  vmovaps xmm6, [rsp+0x60]
000073307ffdb49f  vmovaps xmm7, [rsp+0x70]
000073307ffdb4a5  vmovaps xmm8, [rsp+0x80]
000073307ffdb4ae  vmovaps xmm9, [rsp+0x90]
000073307ffdb4b7  vmovaps xmm10, [rsp+0xA0]
000073307ffdb4c0  vmovaps xmm11, [rsp+0xB0]
000073307ffdb4c9  vmovaps xmm12, [rsp+0xC0]
000073307ffdb4d2  vmovaps xmm13, [rsp+0xD0]
000073307ffdb4db  vmovaps xmm14, [rsp+0xE0]
000073307ffdb4e4  add rsp, 0xF0
000073307ffdb4eb  pop r11
000073307ffdb4ed  pop r10
000073307ffdb4ef  pop r9
000073307ffdb4f1  pop r8
000073307ffdb4f3  pop rsi
000073307ffdb4f4  pop rdi
000073307ffdb4f5  pop rdx
000073307ffdb4f6  pop rcx
000073307ffdb4f7  pop rax
000073307ffdb4f8  add rsp, 0x08
000073307ffdb4fc  jmp 0x000073307FFD664A
000073307ffdb501  sub rsp, 0x08
000073307ffdb505  push rax
000073307ffdb506  push rcx
000073307ffdb507  push rdx
000073307ffdb508  push rdi
000073307ffdb509  push rsi
000073307ffdb50a  push r8
000073307ffdb50c  push r9
000073307ffdb50e  push r10
000073307ffdb510  push r11
000073307ffdb512  sub rsp, 0xF0
000073307ffdb519  vmovaps [rsp], xmm0
000073307ffdb51e  vmovaps [rsp+0x10], xmm1
000073307ffdb524  vmovaps [rsp+0x20], xmm2
000073307ffdb52a  vmovaps [rsp+0x30], xmm3
000073307ffdb530  vmovaps [rsp+0x40], xmm4
000073307ffdb536  vmovaps [rsp+0x50], xmm5
000073307ffdb53c  vmovaps [rsp+0x60], xmm6
000073307ffdb542  vmovaps [rsp+0x70], xmm7
000073307ffdb548  vmovaps [rsp+0x80], xmm8
000073307ffdb551  vmovaps [rsp+0x90], xmm9
000073307ffdb55a  vmovaps [rsp+0xA0], xmm10
000073307ffdb563  vmovaps [rsp+0xB0], xmm11
000073307ffdb56c  vmovaps [rsp+0xC0], xmm12
000073307ffdb575  vmovaps [rsp+0xD0], xmm14
000073307ffdb57e  vmovaps [rsp+0xE0], xmm15
000073307ffdb587  sub rsp, 0x30
000073307ffdb58b  movaps [rsp], xmm13
000073307ffdb590  movaps [rsp+0x10], xmm10
000073307ffdb596  movaps [rsp+0x20], xmm14
000073307ffdb59c  lea rdi, [rsp]
000073307ffdb5a0  mov esi, 0x00
000073307ffdb5a5  mov rax, 0x600DE0EC8530
000073307ffdb5af  call rax
000073307ffdb5b1  movaps xmm13, [rsp]
000073307ffdb5b6  add rsp, 0x30
000073307ffdb5ba  vmovaps xmm0, [rsp]
000073307ffdb5bf  vmovaps xmm1, [rsp+0x10]
000073307ffdb5c5  vmovaps xmm2, [rsp+0x20]
000073307ffdb5cb  vmovaps xmm3, [rsp+0x30]
000073307ffdb5d1  vmovaps xmm4, [rsp+0x40]
000073307ffdb5d7  vmovaps xmm5, [rsp+0x50]
000073307ffdb5dd  vmovaps xmm6, [rsp+0x60]
000073307ffdb5e3  vmovaps xmm7, [rsp+0x70]
000073307ffdb5e9  vmovaps xmm8, [rsp+0x80]
000073307ffdb5f2  vmovaps xmm9, [rsp+0x90]
000073307ffdb5fb  vmovaps xmm10, [rsp+0xA0]
000073307ffdb604  vmovaps xmm11, [rsp+0xB0]
000073307ffdb60d  vmovaps xmm12, [rsp+0xC0]
000073307ffdb616  vmovaps xmm14, [rsp+0xD0]
000073307ffdb61f  vmovaps xmm15, [rsp+0xE0]
000073307ffdb628  add rsp, 0xF0
000073307ffdb62f  pop r11
000073307ffdb631  pop r10
000073307ffdb633  pop r9
000073307ffdb635  pop r8
000073307ffdb637  pop rsi
000073307ffdb638  pop rdi
000073307ffdb639  pop rdx
000073307ffdb63a  pop rcx
000073307ffdb63b  pop rax
000073307ffdb63c  add rsp, 0x08
000073307ffdb640  jmp 0x000073307FFD666D
000073307ffdb645  sub rsp, 0x08
000073307ffdb649  push rax
000073307ffdb64a  push rcx
000073307ffdb64b  push rdx
000073307ffdb64c  push rdi
000073307ffdb64d  push rsi
000073307ffdb64e  push r8
000073307ffdb650  push r9
000073307ffdb652  push r10
000073307ffdb654  push r11
000073307ffdb656  sub rsp, 0xF0
000073307ffdb65d  vmovaps [rsp], xmm0
000073307ffdb662  vmovaps [rsp+0x10], xmm1
000073307ffdb668  vmovaps [rsp+0x20], xmm2
000073307ffdb66e  vmovaps [rsp+0x30], xmm3
000073307ffdb674  vmovaps [rsp+0x40], xmm4
000073307ffdb67a  vmovaps [rsp+0x50], xmm5
000073307ffdb680  vmovaps [rsp+0x60], xmm6
000073307ffdb686  vmovaps [rsp+0x70], xmm7
000073307ffdb68c  vmovaps [rsp+0x80], xmm8
000073307ffdb695  vmovaps [rsp+0x90], xmm9
000073307ffdb69e  vmovaps [rsp+0xA0], xmm10
000073307ffdb6a7  vmovaps [rsp+0xB0], xmm11
000073307ffdb6b0  vmovaps [rsp+0xC0], xmm12
000073307ffdb6b9  vmovaps [rsp+0xD0], xmm13
000073307ffdb6c2  vmovaps [rsp+0xE0], xmm15
000073307ffdb6cb  sub rsp, 0x30
000073307ffdb6cf  movaps [rsp], xmm14
000073307ffdb6d4  movaps [rsp+0x10], xmm1
000073307ffdb6d9  movaps [rsp+0x20], xmm7
000073307ffdb6de  lea rdi, [rsp]
000073307ffdb6e2  mov esi, 0x00
000073307ffdb6e7  mov rax, 0x600DE0EC8530
000073307ffdb6f1  call rax
000073307ffdb6f3  movaps xmm14, [rsp]
000073307ffdb6f8  add rsp, 0x30
000073307ffdb6fc  vmovaps xmm0, [rsp]
000073307ffdb701  vmovaps xmm1, [rsp+0x10]
000073307ffdb707  vmovaps xmm2, [rsp+0x20]
000073307ffdb70d  vmovaps xmm3, [rsp+0x30]
000073307ffdb713  vmovaps xmm4, [rsp+0x40]
000073307ffdb719  vmovaps xmm5, [rsp+0x50]
000073307ffdb71f  vmovaps xmm6, [rsp+0x60]
000073307ffdb725  vmovaps xmm7, [rsp+0x70]
000073307ffdb72b  vmovaps xmm8, [rsp+0x80]
000073307ffdb734  vmovaps xmm9, [rsp+0x90]
000073307ffdb73d  vmovaps xmm10, [rsp+0xA0]
000073307ffdb746  vmovaps xmm11, [rsp+0xB0]
000073307ffdb74f  vmovaps xmm12, [rsp+0xC0]
000073307ffdb758  vmovaps xmm13, [rsp+0xD0]
000073307ffdb761  vmovaps xmm15, [rsp+0xE0]
000073307ffdb76a  add rsp, 0xF0
000073307ffdb771  pop r11
000073307ffdb773  pop r10
000073307ffdb775  pop r9
000073307ffdb777  pop r8
000073307ffdb779  pop rsi
000073307ffdb77a  pop rdi
000073307ffdb77b  pop rdx
000073307ffdb77c  pop rcx
000073307ffdb77d  pop rax
000073307ffdb77e  add rsp, 0x08
000073307ffdb782  jmp 0x000073307FFD6690
000073307ffdb787  sub rsp, 0x08
000073307ffdb78b  push rax
000073307ffdb78c  push rcx
000073307ffdb78d  push rdx
000073307ffdb78e  push rdi
000073307ffdb78f  push rsi
000073307ffdb790  push r8
000073307ffdb792  push r9
000073307ffdb794  push r10
000073307ffdb796  push r11
000073307ffdb798  sub rsp, 0xF0
000073307ffdb79f  vmovaps [rsp], xmm0
000073307ffdb7a4  vmovaps [rsp+0x10], xmm2
000073307ffdb7aa  vmovaps [rsp+0x20], xmm3
000073307ffdb7b0  vmovaps [rsp+0x30], xmm4
000073307ffdb7b6  vmovaps [rsp+0x40], xmm5
000073307ffdb7bc  vmovaps [rsp+0x50], xmm6
000073307ffdb7c2  vmovaps [rsp+0x60], xmm7
000073307ffdb7c8  vmovaps [rsp+0x70], xmm8
000073307ffdb7ce  vmovaps [rsp+0x80], xmm9
000073307ffdb7d7  vmovaps [rsp+0x90], xmm10
000073307ffdb7e0  vmovaps [rsp+0xA0], xmm11
000073307ffdb7e9  vmovaps [rsp+0xB0], xmm12
000073307ffdb7f2  vmovaps [rsp+0xC0], xmm13
000073307ffdb7fb  vmovaps [rsp+0xD0], xmm14
000073307ffdb804  vmovaps [rsp+0xE0], xmm15
000073307ffdb80d  sub rsp, 0x30
000073307ffdb811  movaps [rsp], xmm1
000073307ffdb815  movaps [rsp+0x10], xmm8
000073307ffdb81b  movaps [rsp+0x20], xmm9
000073307ffdb821  lea rdi, [rsp]
000073307ffdb825  mov esi, 0x00
000073307ffdb82a  mov rax, 0x600DE0EC8530
000073307ffdb834  call rax
000073307ffdb836  movaps xmm1, [rsp]
000073307ffdb83a  add rsp, 0x30
000073307ffdb83e  vmovaps xmm0, [rsp]
000073307ffdb843  vmovaps xmm2, [rsp+0x10]
000073307ffdb849  vmovaps xmm3, [rsp+0x20]
000073307ffdb84f  vmovaps xmm4, [rsp+0x30]
000073307ffdb855  vmovaps xmm5, [rsp+0x40]
000073307ffdb85b  vmovaps xmm6, [rsp+0x50]
000073307ffdb861  vmovaps xmm7, [rsp+0x60]
000073307ffdb867  vmovaps xmm8, [rsp+0x70]
000073307ffdb86d  vmovaps xmm9, [rsp+0x80]
000073307ffdb876  vmovaps xmm10, [rsp+0x90]
000073307ffdb87f  vmovaps xmm11, [rsp+0xA0]
000073307ffdb888  vmovaps xmm12, [rsp+0xB0]
000073307ffdb891  vmovaps xmm13, [rsp+0xC0]
000073307ffdb89a  vmovaps xmm14, [rsp+0xD0]
000073307ffdb8a3  vmovaps xmm15, [rsp+0xE0]
000073307ffdb8ac  add rsp, 0xF0
000073307ffdb8b3  pop r11
000073307ffdb8b5  pop r10
000073307ffdb8b7  pop r9
000073307ffdb8b9  pop r8
000073307ffdb8bb  pop rsi
000073307ffdb8bc  pop rdi
000073307ffdb8bd  pop rdx
000073307ffdb8be  pop rcx
000073307ffdb8bf  pop rax
000073307ffdb8c0  add rsp, 0x08
000073307ffdb8c4  jmp 0x000073307FFD66B2
000073307ffdb8c9  call 0x000073307FEB3E40
000073307ffdb8ce  jmp 0x000073307FFD66C0
000073307ffdb8d3  call 0x000073307FE0C380
000073307ffdb8d8  jmp 0x000073307FFD66CA
000073307ffdb8dd  call 0x000073307FE0D600
000073307ffdb8e2  jmp 0x000073307FFD66D4
000073307ffdb8e7  call 0x000073307FDFF540
000073307ffdb8ec  jmp 0x000073307FFD66DE
000073307ffdb8f1  int3
000073307ffdb8f2  nop [rax+rax*1], ax
000073307ffdb8fb  nop [rax+rax*1], eax
000073307ffdb900  mov eax, [r15+0x48]
000073307ffdb904  lea r14d, [eax+0x01]
000073307ffdb909  mov [rsp+0x10], r14d
000073307ffdb90e  mov r14d, r14d
000073307ffdb911  mov [r15+0x48], r14
000073307ffdb915  xor eax, eax
000073307ffdb917  mov r14d, [rsp+0x10]
000073307ffdb91c  cmp r14d, 0x1F4
000073307ffdb923  cmc
000073307ffdb924  lahf
000073307ffdb925  seto al
000073307ffdb928  mov [r15+0x108], eax
000073307ffdb92f  mov eax, [r15+0x108]
000073307ffdb936  sahf
000073307ffdb937  jnz 0x000073307FFDB969
000073307ffdb939  cmp dword ptr [r15+0x318], 0x00
000073307ffdb941  jz 0x000073307FFE1AB0
000073307ffdb947  nop [rax+rax*1], ax
000073307ffdb950  nop [rax+rax*1], eax
000073307ffdb958  mov eax, 0x410450
000073307ffdb95d  mov [r15+0x100], rax
000073307ffdb964  jmp 0x000073307FDFE110
000073307ffdb969  cmp dword ptr [r15+0x318], 0x00
000073307ffdb971  jz 0x000073307FFDB9A0
000073307ffdb977  nop [rax+rax*1], ax
000073307ffdb980  nop [rax+rax*1], eax
000073307ffdb988  mov eax, 0x410274
000073307ffdb98d  mov [r15+0x100], rax
000073307ffdb994  jmp 0x000073307FDFE110
000073307ffdb999  int3
000073307ffdb99a  int3
000073307ffdb99b  nop [rax+rax*1], eax
000073307ffdb9a0  mov rax, [r15+0x40]
000073307ffdb9a4  movaps xmm1, [r15+0x1D0]
000073307ffdb9ac  vmovaps [rsp+0x10], xmm1
000073307ffdb9b2  vmovaps xmm15, [rsp+0x10]
000073307ffdb9b8  por xmm1, xmm15
000073307ffdb9bd  movaps xmm14, [r15+0x1A0]
000073307ffdb9c5  vmovaps [rsp+0x10], xmm14
000073307ffdb9cb  vmovaps xmm13, [rsp+0x10]
000073307ffdb9d1  por xmm14, xmm13
000073307ffdb9d6  lea r14, [rax+0x30]
000073307ffdb9da  mov r12, [r13+r14*1]
000073307ffdb9df  lea r14, [rax+0x38]
000073307ffdb9e3  mov r11, [r13+r14*1]
000073307ffdb9e8  movq xmm13, r12
000073307ffdb9ed  movq xmm12, r11
000073307ffdb9f2  movq xmm13, xmm13
000073307ffdb9f7  vmovaps [rsp+0x10], xmm13
000073307ffdb9fd  movq xmm13, xmm13
000073307ffdba02  movaps [r15+0x130], xmm13
000073307ffdba0a  movq xmm12, xmm12
000073307ffdba0f  vmovaps [rsp+0x20], xmm12
000073307ffdba15  movq xmm12, xmm12
000073307ffdba1a  movaps [r15+0x280], xmm12
000073307ffdba22  movaps xmm13, [r15+0x270]
000073307ffdba2a  vmovaps [rsp+0x30], xmm13
000073307ffdba30  vmovaps xmm12, [rsp+0x30]
000073307ffdba36  por xmm13, xmm12
000073307ffdba3b  lea r14, [rax+0x20]
000073307ffdba3f  mov r12, [r13+r14*1]
000073307ffdba44  lea r14, [rax+0x28]
000073307ffdba48  mov r11, [r13+r14*1]
000073307ffdba4d  movq xmm12, r12
000073307ffdba52  movq xmm11, r11
000073307ffdba57  movq xmm12, xmm12
000073307ffdba5c  vmovaps [rsp+0x30], xmm12
000073307ffdba62  movq xmm12, xmm12
000073307ffdba67  movaps [r15+0x150], xmm12
000073307ffdba6f  movq xmm11, xmm11
000073307ffdba74  vmovaps [rsp+0x40], xmm11
000073307ffdba7a  movq xmm11, xmm11
000073307ffdba7f  movaps [r15+0x140], xmm11
000073307ffdba87  lea r14, [rax+0x10]
000073307ffdba8b  mov r12, [r13+r14*1]
000073307ffdba90  lea r14, [rax+0x18]
000073307ffdba94  mov r11, [r13+r14*1]
000073307ffdba99  movq xmm12, r12
000073307ffdba9e  movq xmm11, r11
000073307ffdbaa3  movq xmm12, xmm12
000073307ffdbaa8  vmovaps [rsp+0x50], xmm12
000073307ffdbaae  movq xmm12, xmm12
000073307ffdbab3  movaps [r15+0x170], xmm12
000073307ffdbabb  movq xmm11, xmm11
000073307ffdbac0  vmovaps [rsp+0x60], xmm11
000073307ffdbac6  movq xmm11, xmm11
000073307ffdbacb  movaps [r15+0x160], xmm11
000073307ffdbad3  mov r14, [r13+rax*1]
000073307ffdbad8  vmovq xmm12, r14
000073307ffdbadd  vpbroadcastq xmm12, xmm12
000073307ffdbae2  lea r14, [rax+0x08]
000073307ffdbae6  mov rax, [r13+r14*1]
000073307ffdbaeb  movq xmm11, rax
000073307ffdbaf0  movaps [r15+0x230], xmm11
000073307ffdbaf8  mov rax, [r15+0xF8]
000073307ffdbaff  lea r14, [rax+0x50]
000073307ffdbb03  movups xmm11, [r13+r14*1]
000073307ffdbb09  lea r14, [rax+0x60]
000073307ffdbb0d  movups xmm10, [r13+r14*1]
000073307ffdbb13  lea r14, [rax+0x30]
000073307ffdbb17  movups xmm9, [r13+r14*1]
000073307ffdbb1d  mov r14, [r15+0x50]
000073307ffdbb21  mov [r15+0x60], r14
000073307ffdbb25  mov qword ptr [r15+0x58], 0x40
000073307ffdbb2d  movaps xmm8, xmm12
000073307ffdbb31  mulpd xmm8, xmm15
000073307ffdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
000073307ffdbb3c  ptest xmm7, xmm7
000073307ffdbb41  jnz 0x000073307FFDC96A
000073307ffdbb47  movq xmm15, qword ptr [r15+0x230]
000073307ffdbb50  vmovaps [rsp+0x70], xmm15
000073307ffdbb56  vpermilpd xmm15, xmm15, 0x00
000073307ffdbb5c  movaps xmm7, xmm9
000073307ffdbb60  mulpd xmm7, xmm15
000073307ffdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
000073307ffdbb6a  ptest xmm6, xmm6
000073307ffdbb6f  jnz 0x000073307FFDCAAE
000073307ffdbb75  vxorps xmm15, xmm15, xmm15
000073307ffdbb7a  vpbroadcastq xmm15, xmm15
000073307ffdbb7f  movaps xmm9, xmm12
000073307ffdbb83  mulpd xmm9, xmm10
000073307ffdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
000073307ffdbb8e  ptest xmm6, xmm6
000073307ffdbb93  jnz 0x000073307FFDCBF0
000073307ffdbb99  movaps xmm10, xmm12
000073307ffdbb9d  mulpd xmm10, xmm11
000073307ffdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
000073307ffdbba8  ptest xmm6, xmm6
000073307ffdbbad  jnz 0x000073307FFDCD34
000073307ffdbbb3  movaps xmm11, [r15+0x1F0]
000073307ffdbbbb  movaps xmm6, xmm12
000073307ffdbbbf  mulpd xmm6, xmm11
000073307ffdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
000073307ffdbbc9  ptest xmm5, xmm5
000073307ffdbbce  jnz 0x000073307FFDCE78
000073307ffdbbd4  movaps xmm12, [r15+0x2A0]
000073307ffdbbdc  vmovaps [rsp+0x80], xmm12
000073307ffdbbe5  vmovaps xmm11, [rsp+0x80]
000073307ffdbbee  por xmm12, xmm11
000073307ffdbbf3  movaps xmm11, [r15+0x250]
000073307ffdbbfb  vmovaps [rsp+0x80], xmm11
000073307ffdbc04  vmovaps xmm5, [rsp+0x80]
000073307ffdbc0d  por xmm11, xmm5
000073307ffdbc12  vmovaps xmm4, [rsp+0x70]
000073307ffdbc18  vpermilpd xmm4, xmm4, 0x00
000073307ffdbc1e  movaps xmm3, xmm5
000073307ffdbc21  mulpd xmm3, xmm4
000073307ffdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
000073307ffdbc2a  ptest xmm2, xmm2
000073307ffdbc2f  jnz 0x000073307FFDCFBA
000073307ffdbc35  mov [rsp+0x80], rax
000073307ffdbc3d  xor eax, eax
000073307ffdbc3f  mov r12d, 0x40
000073307ffdbc45  mov r11d, 0x200
000073307ffdbc4b  cmp r12, r11
000073307ffdbc4e  cmc
000073307ffdbc4f  lahf
000073307ffdbc50  seto al
000073307ffdbc53  mov [r15+0x108], eax
000073307ffdbc5a  movaps xmm5, xmm8
000073307ffdbc5e  addpd xmm5, xmm15
000073307ffdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
000073307ffdbc68  ptest xmm4, xmm4
000073307ffdbc6d  jnz 0x000073307FFDD0FA
000073307ffdbc73  movaps xmm8, [r15+0x1B0]
000073307ffdbc7b  movaps xmm4, xmm9
000073307ffdbc7f  addpd xmm4, xmm8
000073307ffdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
000073307ffdbc89  ptest xmm2, xmm2
000073307ffdbc8e  jnz 0x000073307FFDD23C
000073307ffdbc94  movaps xmm9, xmm10
000073307ffdbc98  addpd xmm9, xmm8
000073307ffdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
000073307ffdbca3  ptest xmm2, xmm2
000073307ffdbca8  jnz 0x000073307FFDD37E
000073307ffdbcae  movaps xmm10, [r15+0x2F0]
000073307ffdbcb6  vmovaps [rsp+0x90], xmm10
000073307ffdbcbf  vmovaps xmm8, [rsp+0x90]
000073307ffdbcc8  por xmm10, xmm8
000073307ffdbccd  movaps xmm8, [r15+0x2E0]
000073307ffdbcd5  vmovaps [rsp+0x90], xmm8
000073307ffdbcde  vmovaps xmm2, [rsp+0x90]
000073307ffdbce7  por xmm8, xmm2
000073307ffdbcec  movaps xmm2, [r15+0x2D0]
000073307ffdbcf4  vmovaps [rsp+0x90], xmm2
000073307ffdbcfd  vmovaps [rsp+0xA0], xmm1
000073307ffdbd06  vmovaps xmm1, [rsp+0x90]
000073307ffdbd0f  por xmm2, xmm1
000073307ffdbd13  movaps xmm1, [r15+0x200]
000073307ffdbd1b  vmovaps [rsp+0x90], xmm1
000073307ffdbd24  vmovaps [rsp+0xB0], xmm15
000073307ffdbd2d  vmovaps xmm15, [rsp+0x90]
000073307ffdbd36  por xmm1, xmm15
000073307ffdbd3b  movaps xmm15, [r15+0x1C0]
000073307ffdbd43  vmovaps [rsp+0x90], xmm15
000073307ffdbd4c  vmovaps [rsp+0xC0], xmm1
000073307ffdbd55  vmovaps xmm1, [rsp+0x90]
000073307ffdbd5e  por xmm15, xmm1
000073307ffdbd63  movaps xmm1, [r15+0x190]
000073307ffdbd6b  vmovaps [rsp+0x90], xmm1
000073307ffdbd74  vmovaps [rsp+0xD0], xmm15
000073307ffdbd7d  vmovaps xmm15, [rsp+0x90]
000073307ffdbd86  por xmm1, xmm15
000073307ffdbd8b  movaps xmm15, [r15+0x300]
000073307ffdbd93  vmovaps [rsp+0x90], xmm15
000073307ffdbd9c  vmovaps [rsp+0xE0], xmm1
000073307ffdbda5  vmovaps xmm1, [rsp+0x90]
000073307ffdbdae  por xmm15, xmm1
000073307ffdbdb3  mov rax, [rsp+0x80]
000073307ffdbdbb  lea r12, [rax+0xA0]
000073307ffdbdc2  movups xmm1, [r13+r12*1]
000073307ffdbdc8  lea r12, [rax+0xB0]
000073307ffdbdcf  vmovaps [rsp+0x80], xmm1
000073307ffdbdd8  movups xmm1, [r13+r12*1]
000073307ffdbdde  vmovaps [rsp+0x90], xmm1
000073307ffdbde7  vmovaps [rsp+0xF0], xmm15
000073307ffdbdf0  vmovaps xmm15, [rsp+0xB0]
000073307ffdbdf9  vmovaps [rsp+0xB0], xmm14
000073307ffdbe02  movaps xmm1, xmm6
000073307ffdbe05  addpd xmm1, xmm15
000073307ffdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
000073307ffdbe0f  ptest xmm14, xmm14
000073307ffdbe15  jnz 0x000073307FFDD4D6
000073307ffdbe1b  lea r12, [rax+0xF0]
000073307ffdbe22  movups xmm15, [r13+r12*1]
000073307ffdbe28  movaps xmm14, xmm4
000073307ffdbe2c  addpd xmm14, xmm3
000073307ffdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
000073307ffdbe37  ptest xmm6, xmm6
000073307ffdbe3c  jnz 0x000073307FFDD621
000073307ffdbe42  movaps xmm6, xmm9
000073307ffdbe46  addpd xmm6, xmm7
000073307ffdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
000073307ffdbe4f  ptest xmm4, xmm4
000073307ffdbe54  jnz 0x000073307FFDD763
000073307ffdbe5a  vmovaps xmm9, [rsp+0x70]
000073307ffdbe60  vpermilpd xmm9, xmm9, 0x00
000073307ffdbe66  vmovaps xmm4, [rsp+0x90]
000073307ffdbe6f  movaps xmm7, xmm4
000073307ffdbe72  mulpd xmm7, xmm9
000073307ffdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
000073307ffdbe7c  ptest xmm3, xmm3
000073307ffdbe81  jnz 0x000073307FFDD8A4
000073307ffdbe87  vmovaps xmm9, [rsp+0x50]
000073307ffdbe8d  vpermilpd xmm9, xmm9, 0x00
000073307ffdbe93  movaps xmm4, xmm15
000073307ffdbe97  mulpd xmm4, xmm9
000073307ffdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
000073307ffdbea1  ptest xmm3, xmm3
000073307ffdbea6  jnz 0x000073307FFDD9E5
000073307ffdbeac  lea r12, [rax+0xE0]
000073307ffdbeb3  movups xmm15, [r13+r12*1]
000073307ffdbeb9  vmovaps xmm9, [rsp+0x70]
000073307ffdbebf  vpermilpd xmm9, xmm9, 0x00
000073307ffdbec5  vmovaps [rsp+0x70], xmm1
000073307ffdbecb  vmovaps xmm1, [rsp+0x80]
000073307ffdbed4  vmovaps [rsp+0x80], xmm15
000073307ffdbedd  movaps xmm3, xmm1
000073307ffdbee0  mulpd xmm3, xmm9
000073307ffdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
000073307ffdbeea  ptest xmm15, xmm15
000073307ffdbef0  jnz 0x000073307FFDDB31
000073307ffdbef6  vmovaps xmm1, [rsp+0xF0]
000073307ffdbeff  vmovaps xmm15, [rsp+0xF0]
000073307ffdbf08  por xmm1, xmm15
000073307ffdbf0d  movaps [r15+0x300], xmm1
000073307ffdbf15  vmovaps xmm15, [rsp+0xE0]
000073307ffdbf1e  vmovaps xmm9, [rsp+0xE0]
000073307ffdbf27  por xmm15, xmm9
000073307ffdbf2c  movaps [r15+0x190], xmm15
000073307ffdbf34  vmovaps xmm9, [rsp+0x50]
000073307ffdbf3a  vpermilpd xmm9, xmm9, 0x00
000073307ffdbf40  vmovaps [rsp+0x90], xmm1
000073307ffdbf49  vmovaps [rsp+0xE0], xmm15
000073307ffdbf52  vmovaps xmm15, [rsp+0x80]
000073307ffdbf5b  vmovaps [rsp+0x80], xmm14
000073307ffdbf64  movaps xmm1, xmm15
000073307ffdbf68  mulpd xmm1, xmm9
000073307ffdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
000073307ffdbf72  ptest xmm14, xmm14
000073307ffdbf78  jnz 0x000073307FFDDC72
000073307ffdbf7e  lea r12, [rax+0x90]
000073307ffdbf85  movups xmm15, [r13+r12*1]
000073307ffdbf8b  vmovaps xmm14, [rsp+0xD0]
000073307ffdbf94  vmovaps xmm9, [rsp+0xD0]
000073307ffdbf9d  por xmm14, xmm9
000073307ffdbfa2  movaps [r15+0x1C0], xmm14
000073307ffdbfaa  vmovaps xmm9, [rsp+0xC0]
000073307ffdbfb3  vmovaps [rsp+0xD0], xmm1
000073307ffdbfbc  vmovaps xmm1, [rsp+0xC0]
000073307ffdbfc5  por xmm9, xmm1
000073307ffdbfca  movaps [r15+0x200], xmm9
000073307ffdbfd2  vmovaps [rsp+0xC0], xmm2
000073307ffdbfdb  vmovaps xmm1, [rsp+0xC0]
000073307ffdbfe4  por xmm2, xmm1
000073307ffdbfe8  movaps [r15+0x2D0], xmm2
000073307ffdbff0  vmovaps [rsp+0xC0], xmm8
000073307ffdbff9  vmovaps xmm1, [rsp+0xC0]
000073307ffdc002  por xmm8, xmm1
000073307ffdc007  movaps [r15+0x2E0], xmm8
000073307ffdc00f  vmovaps [rsp+0xC0], xmm15
000073307ffdc018  movaps xmm1, xmm5
000073307ffdc01b  addpd xmm1, xmm7
000073307ffdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
000073307ffdc024  ptest xmm15, xmm15
000073307ffdc02a  jnz 0x000073307FFDDDBE
000073307ffdc030  vmovaps xmm15, [rsp+0x50]
000073307ffdc036  vpermilpd xmm15, xmm15, 0x00
000073307ffdc03c  vmovaps xmm5, [rsp+0xC0]
000073307ffdc045  vmovaps [rsp+0xC0], xmm1
000073307ffdc04e  movaps xmm7, xmm5
000073307ffdc051  mulpd xmm7, xmm15
000073307ffdc056  vcmppd xmm1, xmm7, xmm7, 0x03
000073307ffdc05b  ptest xmm1, xmm1
000073307ffdc060  jnz 0x000073307FFDDEFE
000073307ffdc066  lea r12, [rax+0x80]
000073307ffdc06d  movups xmm1, [r13+r12*1]
000073307ffdc073  vmovaps xmm5, [rsp+0x70]
000073307ffdc079  vmovaps [rsp+0x70], xmm1
000073307ffdc07f  movaps xmm15, xmm5
000073307ffdc083  addpd xmm15, xmm3
000073307ffdc088  vcmppd xmm1, xmm15, xmm15, 0x03
000073307ffdc08e  ptest xmm1, xmm1
000073307ffdc093  jnz 0x000073307FFDE049
000073307ffdc099  vmovaps xmm5, [rsp+0x80]
000073307ffdc0a2  movaps xmm1, xmm5
000073307ffdc0a5  addpd xmm1, xmm4
000073307ffdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
000073307ffdc0ae  ptest xmm3, xmm3
000073307ffdc0b3  jnz 0x000073307FFDE18B
000073307ffdc0b9  vmovaps [rsp+0x80], xmm10
000073307ffdc0c2  vmovaps xmm5, [rsp+0x80]
000073307ffdc0cb  por xmm10, xmm5
000073307ffdc0d0  movaps [r15+0x2F0], xmm10
000073307ffdc0d8  vmovaps xmm5, [rsp+0x50]
000073307ffdc0de  vpermilpd xmm5, xmm5, 0x00
000073307ffdc0e4  vmovaps xmm3, [rsp+0x70]
000073307ffdc0ea  vmovaps [rsp+0x50], xmm1
000073307ffdc0f0  movaps xmm4, xmm3
000073307ffdc0f3  mulpd xmm4, xmm5
000073307ffdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
000073307ffdc0fc  ptest xmm1, xmm1
000073307ffdc101  jnz 0x000073307FFDE2CB
000073307ffdc107  lea r12, [rax+0xD0]
000073307ffdc10e  movups xmm1, [r13+r12*1]
000073307ffdc114  vmovaps xmm3, [rsp+0xD0]
000073307ffdc11d  vmovaps [rsp+0x70], xmm1
000073307ffdc123  movaps xmm5, xmm6
000073307ffdc126  addpd xmm5, xmm3
000073307ffdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
000073307ffdc12f  ptest xmm1, xmm1
000073307ffdc134  jnz 0x000073307FFDE415
000073307ffdc13a  vmovaps xmm1, [rsp+0x60]
000073307ffdc140  vpermilpd xmm1, xmm1, 0x00
000073307ffdc146  movaps xmm6, xmm9
000073307ffdc14a  mulpd xmm6, xmm1
000073307ffdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
000073307ffdc153  ptest xmm3, xmm3
000073307ffdc158  jnz 0x000073307FFDE555
000073307ffdc15e  movaps [r15+0x260], xmm6
000073307ffdc166  vxorps xmm1, xmm1, xmm1
000073307ffdc16a  vpbroadcastq xmm1, xmm1
000073307ffdc16f  movaps [r15+0x1B0], xmm1
000073307ffdc177  vmovaps xmm1, [rsp+0x60]
000073307ffdc17d  vpermilpd xmm1, xmm1, 0x00
000073307ffdc183  vmovaps xmm3, [rsp+0x70]
000073307ffdc189  vmovaps [rsp+0x70], xmm15
000073307ffdc18f  movaps xmm9, xmm3
000073307ffdc193  mulpd xmm9, xmm1
000073307ffdc198  vcmppd xmm15, xmm9, xmm9, 0x03
000073307ffdc19e  ptest xmm15, xmm15
000073307ffdc1a4  jnz 0x000073307FFDE696
000073307ffdc1aa  lea r12, [rax+0xC0]
000073307ffdc1b1  movups xmm1, [r13+r12*1]
000073307ffdc1b7  vmovaps xmm3, [rsp+0xC0]
000073307ffdc1c0  vmovaps [rsp+0x80], xmm1
000073307ffdc1c9  movaps xmm15, xmm3
000073307ffdc1cd  addpd xmm15, xmm7
000073307ffdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
000073307ffdc1d8  ptest xmm1, xmm1
000073307ffdc1dd  jnz 0x000073307FFDE7E2
000073307ffdc1e3  vmovaps [rsp+0xC0], xmm13
000073307ffdc1ec  vmovaps xmm1, [rsp+0xC0]
000073307ffdc1f5  por xmm13, xmm1
000073307ffdc1fa  movaps [r15+0x270], xmm13
000073307ffdc202  vmovaps xmm1, [rsp+0xB0]
000073307ffdc20b  vmovaps xmm7, [rsp+0xB0]
000073307ffdc214  por xmm1, xmm7
000073307ffdc218  movaps [r15+0x1A0], xmm1
000073307ffdc220  vmovaps xmm1, [rsp+0x60]
000073307ffdc226  vpermilpd xmm1, xmm1, 0x00
000073307ffdc22c  vmovaps [rsp+0xB0], xmm1
000073307ffdc235  vmovaps xmm1, [rsp+0x80]
000073307ffdc23e  vmovaps [rsp+0x80], xmm15
000073307ffdc247  vmovaps xmm15, [rsp+0xB0]
000073307ffdc250  vmovaps [rsp+0xB0], xmm14
000073307ffdc259  movaps xmm3, xmm1
000073307ffdc25c  mulpd xmm3, xmm15
000073307ffdc261  vcmppd xmm14, xmm3, xmm3, 0x03
000073307ffdc266  ptest xmm14, xmm14
000073307ffdc26c  jnz 0x000073307FFDE924
000073307ffdc272  lea r12, [rax+0x20]
000073307ffdc276  movups xmm1, [r13+r12*1]
000073307ffdc27c  movaps [r15+0x110], xmm1
000073307ffdc284  vmovaps xmm14, [rsp+0x70]
000073307ffdc28a  vmovaps [rsp+0x70], xmm1
000073307ffdc290  movaps xmm15, xmm14
000073307ffdc294  addpd xmm15, xmm4
000073307ffdc299  vcmppd xmm1, xmm15, xmm15, 0x03
000073307ffdc29f  ptest xmm1, xmm1
000073307ffdc2a4  jnz 0x000073307FFDEA6F
000073307ffdc2aa  vmovaps xmm1, [rsp+0x60]
000073307ffdc2b0  vpermilpd xmm1, xmm1, 0x00
000073307ffdc2b6  movaps xmm14, xmm2
000073307ffdc2ba  mulpd xmm14, xmm1
000073307ffdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
000073307ffdc2c5  ptest xmm4, xmm4
000073307ffdc2ca  jnz 0x000073307FFDEBB2
000073307ffdc2d0  vmovaps xmm4, [rsp+0x50]
000073307ffdc2d6  movaps xmm1, xmm4
000073307ffdc2d9  addpd xmm1, xmm9
000073307ffdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
000073307ffdc2e3  ptest xmm2, xmm2
000073307ffdc2e8  jnz 0x000073307FFDECF4
000073307ffdc2ee  vmovaps xmm9, [rsp+0x30]
000073307ffdc2f4  vpermilpd xmm9, xmm9, 0x00
000073307ffdc2fa  vmovaps xmm2, [rsp+0x70]
000073307ffdc300  vmovaps [rsp+0x50], xmm1
000073307ffdc306  movaps xmm4, xmm2
000073307ffdc309  mulpd xmm4, xmm9
000073307ffdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
000073307ffdc313  ptest xmm1, xmm1
000073307ffdc318  jnz 0x000073307FFDEE35
000073307ffdc31e  vmovaps xmm1, [rsp+0x30]
000073307ffdc324  vpermilpd xmm1, xmm1, 0x00
000073307ffdc32a  vmovaps xmm2, [rsp+0x90]
000073307ffdc333  vmovaps [rsp+0x60], xmm15
000073307ffdc339  movaps xmm9, xmm2
000073307ffdc33d  mulpd xmm9, xmm1
000073307ffdc342  vcmppd xmm15, xmm9, xmm9, 0x03
000073307ffdc348  ptest xmm15, xmm15
000073307ffdc34e  jnz 0x000073307FFDEF76
000073307ffdc354  vmovaps xmm15, [rsp+0x80]
000073307ffdc35d  movaps xmm1, xmm15
000073307ffdc361  addpd xmm1, xmm6
000073307ffdc365  vcmppd xmm2, xmm1, xmm1, 0x03
000073307ffdc36a  ptest xmm2, xmm2
000073307ffdc36f  jnz 0x000073307FFDF0B8
000073307ffdc375  movaps xmm15, xmm5
000073307ffdc379  addpd xmm15, xmm3
000073307ffdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
000073307ffdc384  ptest xmm6, xmm6
000073307ffdc389  jnz 0x000073307FFDF1F9
000073307ffdc38f  vmovaps xmm6, [rsp+0x30]
000073307ffdc395  vpermilpd xmm6, xmm6, 0x00
000073307ffdc39b  movaps xmm5, xmm8
000073307ffdc39f  mulpd xmm5, xmm6
000073307ffdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
000073307ffdc3a8  ptest xmm3, xmm3
000073307ffdc3ad  jnz 0x000073307FFDF33B
000073307ffdc3b3  vmovaps xmm8, [rsp+0x30]
000073307ffdc3b9  vpermilpd xmm8, xmm8, 0x00
000073307ffdc3bf  movaps xmm6, xmm10
000073307ffdc3c3  mulpd xmm6, xmm8
000073307ffdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
000073307ffdc3cd  ptest xmm3, xmm3
000073307ffdc3d2  jnz 0x000073307FFDF47C
000073307ffdc3d8  vmovaps xmm8, [rsp+0x60]
000073307ffdc3de  movaps xmm10, xmm8
000073307ffdc3e2  addpd xmm10, xmm14
000073307ffdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
000073307ffdc3ed  ptest xmm3, xmm3
000073307ffdc3f2  jnz 0x000073307FFDF5BE
000073307ffdc3f8  vmovaps xmm8, [rsp+0x50]
000073307ffdc3fe  movaps xmm14, xmm8
000073307ffdc402  addpd xmm14, xmm4
000073307ffdc407  vcmppd xmm3, xmm14, xmm14, 0x03
000073307ffdc40d  ptest xmm3, xmm3
000073307ffdc412  jnz 0x000073307FFDF702
000073307ffdc418  vmovaps xmm8, [rsp+0x40]
000073307ffdc41e  vpermilpd xmm8, xmm8, 0x00
000073307ffdc424  movaps xmm4, xmm13
000073307ffdc428  mulpd xmm4, xmm8
000073307ffdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
000073307ffdc432  ptest xmm3, xmm3
000073307ffdc437  jnz 0x000073307FFDF845
000073307ffdc43d  movaps xmm13, xmm15
000073307ffdc441  addpd xmm13, xmm9
000073307ffdc446  vcmppd xmm8, xmm13, xmm13, 0x03
000073307ffdc44c  ptest xmm8, xmm8
000073307ffdc452  jnz 0x000073307FFDF987
000073307ffdc458  movaps xmm15, xmm1
000073307ffdc45c  addpd xmm15, xmm5
000073307ffdc461  vcmppd xmm9, xmm15, xmm15, 0x03
000073307ffdc467  ptest xmm9, xmm9
000073307ffdc46d  jnz 0x000073307FFDFACB
000073307ffdc473  vmovaps [rsp+0x30], xmm11
000073307ffdc479  vmovaps xmm1, [rsp+0x30]
000073307ffdc47f  por xmm11, xmm1
000073307ffdc484  movaps [r15+0x250], xmm11
000073307ffdc48c  vmovaps [rsp+0x30], xmm12
000073307ffdc492  vmovaps xmm1, [rsp+0x30]
000073307ffdc498  por xmm12, xmm1
000073307ffdc49d  movaps [r15+0x2A0], xmm12
000073307ffdc4a5  vmovaps xmm1, [rsp+0xA0]
000073307ffdc4ae  vmovaps xmm11, [rsp+0xA0]
000073307ffdc4b7  por xmm1, xmm11
000073307ffdc4bc  movaps [r15+0x1D0], xmm1
000073307ffdc4c4  lea r12, [rax+0x40]
000073307ffdc4c8  movups xmm1, [r13+r12*1]
000073307ffdc4ce  movaps [r15+0x2C0], xmm1
000073307ffdc4d6  vmovaps xmm11, [rsp+0x40]
000073307ffdc4dc  vpermilpd xmm11, xmm11, 0x00
000073307ffdc4e2  vmovaps xmm8, [rsp+0xE0]
000073307ffdc4eb  movaps xmm9, xmm8
000073307ffdc4ef  mulpd xmm9, xmm11
000073307ffdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
000073307ffdc4fa  ptest xmm5, xmm5
000073307ffdc4ff  jnz 0x000073307FFDFC17
000073307ffdc505  movaps xmm11, xmm10
000073307ffdc509  addpd xmm11, xmm6
000073307ffdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
000073307ffdc514  ptest xmm8, xmm8
000073307ffdc51a  jnz 0x000073307FFDFD5B
000073307ffdc520  movaps xmm10, xmm14
000073307ffdc524  addpd xmm10, xmm4
000073307ffdc529  vcmppd xmm8, xmm10, xmm10, 0x03
000073307ffdc52f  ptest xmm8, xmm8
000073307ffdc535  jnz 0x000073307FFDFE9E
000073307ffdc53b  vmovaps xmm14, [rsp+0x40]
000073307ffdc541  vpermilpd xmm14, xmm14, 0x00
000073307ffdc547  movaps xmm8, xmm1
000073307ffdc54b  mulpd xmm8, xmm14
000073307ffdc550  vcmppd xmm6, xmm8, xmm8, 0x03
000073307ffdc556  ptest xmm6, xmm6
000073307ffdc55b  jnz 0x000073307FFDFFE1
000073307ffdc561  movaps xmm1, [r15+0x2B0]
000073307ffdc569  vmovaps xmm14, [rsp+0x40]
000073307ffdc56f  vpermilpd xmm14, xmm14, 0x00
000073307ffdc575  movaps xmm6, xmm1
000073307ffdc578  mulpd xmm6, xmm14
000073307ffdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
000073307ffdc582  ptest xmm5, xmm5
000073307ffdc587  jnz 0x000073307FFE0124
000073307ffdc58d  vmovaps xmm1, [rsp+0x10]
000073307ffdc593  vpermilpd xmm1, xmm1, 0x00
000073307ffdc599  movaps xmm14, xmm12
000073307ffdc59d  mulpd xmm14, xmm1
000073307ffdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
000073307ffdc5a8  ptest xmm5, xmm5
000073307ffdc5ad  jnz 0x000073307FFE0265
000073307ffdc5b3  movaps xmm1, xmm13
000073307ffdc5b7  addpd xmm1, xmm9
000073307ffdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
000073307ffdc5c1  ptest xmm12, xmm12
000073307ffdc5c7  jnz 0x000073307FFE03A8
000073307ffdc5cd  vmovaps xmm13, [rsp+0x10]
000073307ffdc5d3  vpermilpd xmm13, xmm13, 0x00
000073307ffdc5d9  movaps xmm12, xmm7
000073307ffdc5dd  mulpd xmm12, xmm13
000073307ffdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
000073307ffdc5e8  ptest xmm9, xmm9
000073307ffdc5ee  jnz 0x000073307FFE04EA
000073307ffdc5f4  movaps xmm13, xmm15
000073307ffdc5f8  addpd xmm13, xmm8
000073307ffdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
000073307ffdc603  ptest xmm9, xmm9
000073307ffdc609  jnz 0x000073307FFE062D
000073307ffdc60f  movaps xmm15, [r15+0x290]
000073307ffdc617  vmovaps xmm9, [rsp+0x10]
000073307ffdc61d  vpermilpd xmm9, xmm9, 0x00
000073307ffdc623  movaps xmm8, xmm15
000073307ffdc627  mulpd xmm8, xmm9
000073307ffdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
000073307ffdc632  ptest xmm7, xmm7
000073307ffdc637  jnz 0x000073307FFE0771
000073307ffdc63d  movaps xmm15, xmm11
000073307ffdc641  addpd xmm15, xmm6
000073307ffdc646  vcmppd xmm9, xmm15, xmm15, 0x03
000073307ffdc64c  ptest xmm9, xmm9
000073307ffdc652  jnz 0x000073307FFE08B5
000073307ffdc658  movaps xmm11, [r15+0x1E0]
000073307ffdc660  vmovaps xmm9, [rsp+0x10]
000073307ffdc666  vpermilpd xmm9, xmm9, 0x00
000073307ffdc66c  movaps xmm7, xmm11
000073307ffdc670  mulpd xmm7, xmm9
000073307ffdc675  vcmppd xmm6, xmm7, xmm7, 0x03
000073307ffdc67a  ptest xmm6, xmm6
000073307ffdc67f  jnz 0x000073307FFE09F8
000073307ffdc685  movaps xmm11, xmm10
000073307ffdc689  addpd xmm11, xmm14
000073307ffdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
000073307ffdc694  ptest xmm9, xmm9
000073307ffdc69a  jnz 0x000073307FFE0B3A
000073307ffdc6a0  lea r12, [rax+0x70]
000073307ffdc6a4  movups xmm14, [r13+r12*1]
000073307ffdc6aa  movaps [r15+0x240], xmm14
000073307ffdc6b2  movaps xmm10, xmm1
000073307ffdc6b6  addpd xmm10, xmm12
000073307ffdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
000073307ffdc6c1  ptest xmm9, xmm9
000073307ffdc6c7  jnz 0x000073307FFE0C88
000073307ffdc6cd  movaps [r15+0x170], xmm10
000073307ffdc6d5  vmovaps xmm1, [rsp+0x20]
000073307ffdc6db  vpermilpd xmm1, xmm1, 0x00
000073307ffdc6e1  movaps xmm12, xmm14
000073307ffdc6e5  mulpd xmm12, xmm1
000073307ffdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
000073307ffdc6f0  ptest xmm9, xmm9
000073307ffdc6f6  jnz 0x000073307FFE0DCB
000073307ffdc6fc  vmovaps xmm1, [rsp+0x20]
000073307ffdc702  vpermilpd xmm1, xmm1, 0x00
000073307ffdc708  vmovaps xmm9, [rsp+0xB0]
000073307ffdc711  movaps xmm14, xmm9
000073307ffdc715  mulpd xmm14, xmm1
000073307ffdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
000073307ffdc720  ptest xmm6, xmm6
000073307ffdc725  jnz 0x000073307FFE0F0E
000073307ffdc72b  movaps [r15+0x180], xmm14
000073307ffdc733  movaps xmm1, xmm13
000073307ffdc737  addpd xmm1, xmm8
000073307ffdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
000073307ffdc741  ptest xmm9, xmm9
000073307ffdc747  jnz 0x000073307FFE1051
000073307ffdc74d  movaps [r15+0x210], xmm1
000073307ffdc755  movups xmm13, [r13+rax*1]
000073307ffdc75b  lea r12, [rax+0x10]
000073307ffdc75f  movups xmm9, [r13+r12*1]
000073307ffdc765  movaps [r15+0x230], xmm9
000073307ffdc76d  movaps xmm8, xmm15
000073307ffdc771  addpd xmm8, xmm7
000073307ffdc776  vcmppd xmm6, xmm8, xmm8, 0x03
000073307ffdc77c  ptest xmm6, xmm6
000073307ffdc781  jnz 0x000073307FFE11A7
000073307ffdc787  movaps [r15+0x130], xmm8
000073307ffdc78f  vmovaps xmm15, [rsp+0x20]
000073307ffdc795  vpermilpd xmm15, xmm15, 0x00
000073307ffdc79b  movaps xmm7, xmm9
000073307ffdc79f  mulpd xmm7, xmm15
000073307ffdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
000073307ffdc7a9  ptest xmm6, xmm6
000073307ffdc7ae  jnz 0x000073307FFE12EA
000073307ffdc7b4  movaps [r15+0x220], xmm7
000073307ffdc7bc  vmovaps xmm15, [rsp+0x20]
000073307ffdc7c2  vpermilpd xmm15, xmm15, 0x00
000073307ffdc7c8  movaps xmm9, xmm13
000073307ffdc7cc  mulpd xmm9, xmm15
000073307ffdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
000073307ffdc7d7  ptest xmm6, xmm6
000073307ffdc7dc  jnz 0x000073307FFE142C
000073307ffdc7e2  movaps xmm15, xmm11
000073307ffdc7e6  addpd xmm15, xmm12
000073307ffdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
000073307ffdc7f1  ptest xmm13, xmm13
000073307ffdc7f7  jnz 0x000073307FFE1570
000073307ffdc7fd  movaps [r15+0x140], xmm15
000073307ffdc805  movaps xmm13, xmm10
000073307ffdc809  addpd xmm13, xmm14
000073307ffdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
000073307ffdc814  ptest xmm12, xmm12
000073307ffdc81a  jnz 0x000073307FFE16B4
000073307ffdc820  movaps [r15+0x150], xmm13
000073307ffdc828  movaps xmm14, xmm1
000073307ffdc82c  addpd xmm14, xmm7
000073307ffdc831  vcmppd xmm12, xmm14, xmm14, 0x03
000073307ffdc837  ptest xmm12, xmm12
000073307ffdc83d  jnz 0x000073307FFE17F8
000073307ffdc843  movaps [r15+0x160], xmm14
000073307ffdc84b  movaps xmm1, xmm8
000073307ffdc84f  addpd xmm1, xmm9
000073307ffdc854  vcmppd xmm12, xmm1, xmm1, 0x03
000073307ffdc859  ptest xmm12, xmm12
000073307ffdc85f  jnz 0x000073307FFE193A
000073307ffdc865  movaps [r15+0x120], xmm1
000073307ffdc86d  movups [r13+r14*1], xmm15
000073307ffdc873  lea rax, [r14+0x10]
000073307ffdc877  movups [r13+rax*1], xmm13
000073307ffdc87d  lea rax, [r14+0x20]
000073307ffdc881  movups [r13+rax*1], xmm14
000073307ffdc887  lea rax, [r14+0x30]
000073307ffdc88b  movups [r13+rax*1], xmm1
000073307ffdc891  mov eax, [r15+0x108]
000073307ffdc898  sahf
000073307ffdc899  jnz 0x000073307FFDC8CB
000073307ffdc89b  cmp dword ptr [r15+0x318], 0x00
000073307ffdc8a3  jz 0x000073307FFDB900
000073307ffdc8a9  nop [rax+rax*1], ax
000073307ffdc8b2  nop [rax+rax*1], eax
000073307ffdc8ba  mov eax, 0x410444
000073307ffdc8bf  mov [r15+0x100], rax
000073307ffdc8c6  jmp 0x000073307FDFE110
000073307ffdc8cb  cmp dword ptr [r15+0x318], 0x00
000073307ffdc8d3  jz 0x000073307FFD57E0
000073307ffdc8d9  nop [rax+rax*1], ax
000073307ffdc8e2  nop [rax+rax*1], eax
000073307ffdc8ea  mov eax, 0x410278
000073307ffdc8ef  mov [r15+0x100], rax
000073307ffdc8f6  jmp 0x000073307FDFE110
000073307ffdc8fb  int3
000073307ffdc8fc  call 0x000073307FEE27E0
000073307ffdc901  jmp 0x000073307FFDB9DF
000073307ffdc906  call 0x000073307FEE1570
000073307ffdc90b  jmp 0x000073307FFDB9E8
000073307ffdc910  call 0x000073307FEE27E0
000073307ffdc915  jmp 0x000073307FFDBA44
000073307ffdc91a  call 0x000073307FEE1570
000073307ffdc91f  jmp 0x000073307FFDBA4D
000073307ffdc924  call 0x000073307FEE27E0
000073307ffdc929  jmp 0x000073307FFDBA90
000073307ffdc92e  call 0x000073307FEE1570
000073307ffdc933  jmp 0x000073307FFDBA99
000073307ffdc938  call 0x000073307FE0DC20
000073307ffdc93d  jmp 0x000073307FFDBAD8
000073307ffdc942  call 0x000073307FED59C0
000073307ffdc947  jmp 0x000073307FFDBAEB
000073307ffdc94c  call 0x000073307FEE0E30
000073307ffdc951  jmp 0x000073307FFDBB09
000073307ffdc956  call 0x000073307FEDFBC0
000073307ffdc95b  jmp 0x000073307FFDBB13
000073307ffdc960  call 0x000073307FEDE950
000073307ffdc965  jmp 0x000073307FFDBB1D
000073307ffdc96a  sub rsp, 0x08
000073307ffdc96e  push rax
000073307ffdc96f  push rcx
000073307ffdc970  push rdx
000073307ffdc971  push rdi
000073307ffdc972  push rsi
000073307ffdc973  push r8
000073307ffdc975  push r9
000073307ffdc977  push r10
000073307ffdc979  push r11
000073307ffdc97b  sub rsp, 0xF0
000073307ffdc982  vmovaps [rsp], xmm0
000073307ffdc987  vmovaps [rsp+0x10], xmm1
000073307ffdc98d  vmovaps [rsp+0x20], xmm2
000073307ffdc993  vmovaps [rsp+0x30], xmm3
000073307ffdc999  vmovaps [rsp+0x40], xmm4
000073307ffdc99f  vmovaps [rsp+0x50], xmm5
000073307ffdc9a5  vmovaps [rsp+0x60], xmm6
000073307ffdc9ab  vmovaps [rsp+0x70], xmm7
000073307ffdc9b1  vmovaps [rsp+0x80], xmm9
000073307ffdc9ba  vmovaps [rsp+0x90], xmm10
000073307ffdc9c3  vmovaps [rsp+0xA0], xmm11
000073307ffdc9cc  vmovaps [rsp+0xB0], xmm12
000073307ffdc9d5  vmovaps [rsp+0xC0], xmm13
000073307ffdc9de  vmovaps [rsp+0xD0], xmm14
000073307ffdc9e7  vmovaps [rsp+0xE0], xmm15
000073307ffdc9f0  sub rsp, 0x30
000073307ffdc9f4  movaps [rsp], xmm8
000073307ffdc9f9  movaps [rsp+0x10], xmm12
000073307ffdc9ff  movaps [rsp+0x20], xmm15
000073307ffdca05  lea rdi, [rsp]
000073307ffdca09  mov esi, 0x00
000073307ffdca0e  mov rax, 0x600DE0EC8530
000073307ffdca18  call rax
000073307ffdca1a  movaps xmm8, [rsp]
000073307ffdca1f  add rsp, 0x30
000073307ffdca23  vmovaps xmm0, [rsp]
000073307ffdca28  vmovaps xmm1, [rsp+0x10]
000073307ffdca2e  vmovaps xmm2, [rsp+0x20]
000073307ffdca34  vmovaps xmm3, [rsp+0x30]
000073307ffdca3a  vmovaps xmm4, [rsp+0x40]
000073307ffdca40  vmovaps xmm5, [rsp+0x50]
000073307ffdca46  vmovaps xmm6, [rsp+0x60]
000073307ffdca4c  vmovaps xmm7, [rsp+0x70]
000073307ffdca52  vmovaps xmm9, [rsp+0x80]
000073307ffdca5b  vmovaps xmm10, [rsp+0x90]
000073307ffdca64  vmovaps xmm11, [rsp+0xA0]
000073307ffdca6d  vmovaps xmm12, [rsp+0xB0]
000073307ffdca76  vmovaps xmm13, [rsp+0xC0]
000073307ffdca7f  vmovaps xmm14, [rsp+0xD0]
000073307ffdca88  vmovaps xmm15, [rsp+0xE0]
000073307ffdca91  add rsp, 0xF0
000073307ffdca98  pop r11
000073307ffdca9a  pop r10
000073307ffdca9c  pop r9
000073307ffdca9e  pop r8
000073307ffdcaa0  pop rsi
000073307ffdcaa1  pop rdi
000073307ffdcaa2  pop rdx
000073307ffdcaa3  pop rcx
000073307ffdcaa4  pop rax
000073307ffdcaa5  add rsp, 0x08
000073307ffdcaa9  jmp 0x000073307FFDBB47
000073307ffdcaae  sub rsp, 0x08
000073307ffdcab2  push rax
000073307ffdcab3  push rcx
000073307ffdcab4  push rdx
000073307ffdcab5  push rdi
000073307ffdcab6  push rsi
000073307ffdcab7  push r8
000073307ffdcab9  push r9
000073307ffdcabb  push r10
000073307ffdcabd  push r11
000073307ffdcabf  sub rsp, 0xF0
000073307ffdcac6  vmovaps [rsp], xmm0
000073307ffdcacb  vmovaps [rsp+0x10], xmm1
000073307ffdcad1  vmovaps [rsp+0x20], xmm2
000073307ffdcad7  vmovaps [rsp+0x30], xmm3
000073307ffdcadd  vmovaps [rsp+0x40], xmm4
000073307ffdcae3  vmovaps [rsp+0x50], xmm5
000073307ffdcae9  vmovaps [rsp+0x60], xmm6
000073307ffdcaef  vmovaps [rsp+0x70], xmm8
000073307ffdcaf5  vmovaps [rsp+0x80], xmm9
000073307ffdcafe  vmovaps [rsp+0x90], xmm10
000073307ffdcb07  vmovaps [rsp+0xA0], xmm11
000073307ffdcb10  vmovaps [rsp+0xB0], xmm12
000073307ffdcb19  vmovaps [rsp+0xC0], xmm13
000073307ffdcb22  vmovaps [rsp+0xD0], xmm14
000073307ffdcb2b  vmovaps [rsp+0xE0], xmm15
000073307ffdcb34  sub rsp, 0x30
000073307ffdcb38  movaps [rsp], xmm7
000073307ffdcb3c  movaps [rsp+0x10], xmm9
000073307ffdcb42  movaps [rsp+0x20], xmm15
000073307ffdcb48  lea rdi, [rsp]
000073307ffdcb4c  mov esi, 0x00
000073307ffdcb51  mov rax, 0x600DE0EC8530
000073307ffdcb5b  call rax
000073307ffdcb5d  movaps xmm7, [rsp]
000073307ffdcb61  add rsp, 0x30
000073307ffdcb65  vmovaps xmm0, [rsp]
000073307ffdcb6a  vmovaps xmm1, [rsp+0x10]
000073307ffdcb70  vmovaps xmm2, [rsp+0x20]
000073307ffdcb76  vmovaps xmm3, [rsp+0x30]
000073307ffdcb7c  vmovaps xmm4, [rsp+0x40]
000073307ffdcb82  vmovaps xmm5, [rsp+0x50]
000073307ffdcb88  vmovaps xmm6, [rsp+0x60]
000073307ffdcb8e  vmovaps xmm8, [rsp+0x70]
000073307ffdcb94  vmovaps xmm9, [rsp+0x80]
000073307ffdcb9d  vmovaps xmm10, [rsp+0x90]
000073307ffdcba6  vmovaps xmm11, [rsp+0xA0]
000073307ffdcbaf  vmovaps xmm12, [rsp+0xB0]
000073307ffdcbb8  vmovaps xmm13, [rsp+0xC0]
000073307ffdcbc1  vmovaps xmm14, [rsp+0xD0]
000073307ffdcbca  vmovaps xmm15, [rsp+0xE0]
000073307ffdcbd3  add rsp, 0xF0
000073307ffdcbda  pop r11
000073307ffdcbdc  pop r10
000073307ffdcbde  pop r9
000073307ffdcbe0  pop r8
000073307ffdcbe2  pop rsi
000073307ffdcbe3  pop rdi
000073307ffdcbe4  pop rdx
000073307ffdcbe5  pop rcx
000073307ffdcbe6  pop rax
000073307ffdcbe7  add rsp, 0x08
000073307ffdcbeb  jmp 0x000073307FFDBB75
000073307ffdcbf0  sub rsp, 0x08
000073307ffdcbf4  push rax
000073307ffdcbf5  push rcx
000073307ffdcbf6  push rdx
000073307ffdcbf7  push rdi
000073307ffdcbf8  push rsi
000073307ffdcbf9  push r8
000073307ffdcbfb  push r9
000073307ffdcbfd  push r10
000073307ffdcbff  push r11
000073307ffdcc01  sub rsp, 0xF0
000073307ffdcc08  vmovaps [rsp], xmm0
000073307ffdcc0d  vmovaps [rsp+0x10], xmm1
000073307ffdcc13  vmovaps [rsp+0x20], xmm2
000073307ffdcc19  vmovaps [rsp+0x30], xmm3
000073307ffdcc1f  vmovaps [rsp+0x40], xmm4
000073307ffdcc25  vmovaps [rsp+0x50], xmm5
000073307ffdcc2b  vmovaps [rsp+0x60], xmm6
000073307ffdcc31  vmovaps [rsp+0x70], xmm7
000073307ffdcc37  vmovaps [rsp+0x80], xmm8
000073307ffdcc40  vmovaps [rsp+0x90], xmm10
000073307ffdcc49  vmovaps [rsp+0xA0], xmm11
000073307ffdcc52  vmovaps [rsp+0xB0], xmm12
000073307ffdcc5b  vmovaps [rsp+0xC0], xmm13
000073307ffdcc64  vmovaps [rsp+0xD0], xmm14
000073307ffdcc6d  vmovaps [rsp+0xE0], xmm15
000073307ffdcc76  sub rsp, 0x30
000073307ffdcc7a  movaps [rsp], xmm9
000073307ffdcc7f  movaps [rsp+0x10], xmm12
000073307ffdcc85  movaps [rsp+0x20], xmm10
000073307ffdcc8b  lea rdi, [rsp]
000073307ffdcc8f  mov esi, 0x00
000073307ffdcc94  mov rax, 0x600DE0EC8530
000073307ffdcc9e  call rax
000073307ffdcca0  movaps xmm9, [rsp]
000073307ffdcca5  add rsp, 0x30
000073307ffdcca9  vmovaps xmm0, [rsp]
000073307ffdccae  vmovaps xmm1, [rsp+0x10]
000073307ffdccb4  vmovaps xmm2, [rsp+0x20]
000073307ffdccba  vmovaps xmm3, [rsp+0x30]
000073307ffdccc0  vmovaps xmm4, [rsp+0x40]
000073307ffdccc6  vmovaps xmm5, [rsp+0x50]
000073307ffdcccc  vmovaps xmm6, [rsp+0x60]
000073307ffdccd2  vmovaps xmm7, [rsp+0x70]
000073307ffdccd8  vmovaps xmm8, [rsp+0x80]
000073307ffdcce1  vmovaps xmm10, [rsp+0x90]
000073307ffdccea  vmovaps xmm11, [rsp+0xA0]
000073307ffdccf3  vmovaps xmm12, [rsp+0xB0]
000073307ffdccfc  vmovaps xmm13, [rsp+0xC0]
000073307ffdcd05  vmovaps xmm14, [rsp+0xD0]
000073307ffdcd0e  vmovaps xmm15, [rsp+0xE0]
000073307ffdcd17  add rsp, 0xF0
000073307ffdcd1e  pop r11
000073307ffdcd20  pop r10
000073307ffdcd22  pop r9
000073307ffdcd24  pop r8
000073307ffdcd26  pop rsi
000073307ffdcd27  pop rdi
000073307ffdcd28  pop rdx
000073307ffdcd29  pop rcx
000073307ffdcd2a  pop rax
000073307ffdcd2b  add rsp, 0x08
000073307ffdcd2f  jmp 0x000073307FFDBB99
000073307ffdcd34  sub rsp, 0x08
000073307ffdcd38  push rax
000073307ffdcd39  push rcx
000073307ffdcd3a  push rdx
000073307ffdcd3b  push rdi
000073307ffdcd3c  push rsi
000073307ffdcd3d  push r8
000073307ffdcd3f  push r9
000073307ffdcd41  push r10
000073307ffdcd43  push r11
000073307ffdcd45  sub rsp, 0xF0
000073307ffdcd4c  vmovaps [rsp], xmm0
000073307ffdcd51  vmovaps [rsp+0x10], xmm1
000073307ffdcd57  vmovaps [rsp+0x20], xmm2
000073307ffdcd5d  vmovaps [rsp+0x30], xmm3
000073307ffdcd63  vmovaps [rsp+0x40], xmm4
000073307ffdcd69  vmovaps [rsp+0x50], xmm5
000073307ffdcd6f  vmovaps [rsp+0x60], xmm6
000073307ffdcd75  vmovaps [rsp+0x70], xmm7
000073307ffdcd7b  vmovaps [rsp+0x80], xmm8
000073307ffdcd84  vmovaps [rsp+0x90], xmm9
000073307ffdcd8d  vmovaps [rsp+0xA0], xmm11
000073307ffdcd96  vmovaps [rsp+0xB0], xmm12
000073307ffdcd9f  vmovaps [rsp+0xC0], xmm13
000073307ffdcda8  vmovaps [rsp+0xD0], xmm14
000073307ffdcdb1  vmovaps [rsp+0xE0], xmm15
000073307ffdcdba  sub rsp, 0x30
000073307ffdcdbe  movaps [rsp], xmm10
000073307ffdcdc3  movaps [rsp+0x10], xmm12
000073307ffdcdc9  movaps [rsp+0x20], xmm11
000073307ffdcdcf  lea rdi, [rsp]
000073307ffdcdd3  mov esi, 0x00
000073307ffdcdd8  mov rax, 0x600DE0EC8530
000073307ffdcde2  call rax
000073307ffdcde4  movaps xmm10, [rsp]
000073307ffdcde9  add rsp, 0x30
000073307ffdcded  vmovaps xmm0, [rsp]
000073307ffdcdf2  vmovaps xmm1, [rsp+0x10]
000073307ffdcdf8  vmovaps xmm2, [rsp+0x20]
000073307ffdcdfe  vmovaps xmm3, [rsp+0x30]
000073307ffdce04  vmovaps xmm4, [rsp+0x40]
000073307ffdce0a  vmovaps xmm5, [rsp+0x50]
000073307ffdce10  vmovaps xmm6, [rsp+0x60]
000073307ffdce16  vmovaps xmm7, [rsp+0x70]
000073307ffdce1c  vmovaps xmm8, [rsp+0x80]
000073307ffdce25  vmovaps xmm9, [rsp+0x90]
000073307ffdce2e  vmovaps xmm11, [rsp+0xA0]
000073307ffdce37  vmovaps xmm12, [rsp+0xB0]
000073307ffdce40  vmovaps xmm13, [rsp+0xC0]
000073307ffdce49  vmovaps xmm14, [rsp+0xD0]
000073307ffdce52  vmovaps xmm15, [rsp+0xE0]
000073307ffdce5b  add rsp, 0xF0
000073307ffdce62  pop r11
000073307ffdce64  pop r10
000073307ffdce66  pop r9
000073307ffdce68  pop r8
000073307ffdce6a  pop rsi
000073307ffdce6b  pop rdi
000073307ffdce6c  pop rdx
000073307ffdce6d  pop rcx
000073307ffdce6e  pop rax
000073307ffdce6f  add rsp, 0x08
000073307ffdce73  jmp 0x000073307FFDBBB3
000073307ffdce78  sub rsp, 0x08
000073307ffdce7c  push rax
000073307ffdce7d  push rcx
000073307ffdce7e  push rdx
000073307ffdce7f  push rdi
000073307ffdce80  push rsi
000073307ffdce81  push r8
000073307ffdce83  push r9
000073307ffdce85  push r10
000073307ffdce87  push r11
000073307ffdce89  sub rsp, 0xF0
000073307ffdce90  vmovaps [rsp], xmm0
000073307ffdce95  vmovaps [rsp+0x10], xmm1
000073307ffdce9b  vmovaps [rsp+0x20], xmm2
000073307ffdcea1  vmovaps [rsp+0x30], xmm3
000073307ffdcea7  vmovaps [rsp+0x40], xmm4
000073307ffdcead  vmovaps [rsp+0x50], xmm5
000073307ffdceb3  vmovaps [rsp+0x60], xmm7
000073307ffdceb9  vmovaps [rsp+0x70], xmm8
000073307ffdcebf  vmovaps [rsp+0x80], xmm9
000073307ffdcec8  vmovaps [rsp+0x90], xmm10
000073307ffdced1  vmovaps [rsp+0xA0], xmm11
000073307ffdceda  vmovaps [rsp+0xB0], xmm12
000073307ffdcee3  vmovaps [rsp+0xC0], xmm13
000073307ffdceec  vmovaps [rsp+0xD0], xmm14
000073307ffdcef5  vmovaps [rsp+0xE0], xmm15
000073307ffdcefe  sub rsp, 0x30
000073307ffdcf02  movaps [rsp], xmm6
000073307ffdcf06  movaps [rsp+0x10], xmm12
000073307ffdcf0c  movaps [rsp+0x20], xmm11
000073307ffdcf12  lea rdi, [rsp]
000073307ffdcf16  mov esi, 0x00
000073307ffdcf1b  mov rax, 0x600DE0EC8530
000073307ffdcf25  call rax
000073307ffdcf27  movaps xmm6, [rsp]
000073307ffdcf2b  add rsp, 0x30
000073307ffdcf2f  vmovaps xmm0, [rsp]
000073307ffdcf34  vmovaps xmm1, [rsp+0x10]
000073307ffdcf3a  vmovaps xmm2, [rsp+0x20]
000073307ffdcf40  vmovaps xmm3, [rsp+0x30]
000073307ffdcf46  vmovaps xmm4, [rsp+0x40]
000073307ffdcf4c  vmovaps xmm5, [rsp+0x50]
000073307ffdcf52  vmovaps xmm7, [rsp+0x60]
000073307ffdcf58  vmovaps xmm8, [rsp+0x70]
000073307ffdcf5e  vmovaps xmm9, [rsp+0x80]
000073307ffdcf67  vmovaps xmm10, [rsp+0x90]
000073307ffdcf70  vmovaps xmm11, [rsp+0xA0]
000073307ffdcf79  vmovaps xmm12, [rsp+0xB0]
000073307ffdcf82  vmovaps xmm13, [rsp+0xC0]
000073307ffdcf8b  vmovaps xmm14, [rsp+0xD0]
000073307ffdcf94  vmovaps xmm15, [rsp+0xE0]
000073307ffdcf9d  add rsp, 0xF0
000073307ffdcfa4  pop r11
000073307ffdcfa6  pop r10
000073307ffdcfa8  pop r9
000073307ffdcfaa  pop r8
000073307ffdcfac  pop rsi
000073307ffdcfad  pop rdi
000073307ffdcfae  pop rdx
000073307ffdcfaf  pop rcx
000073307ffdcfb0  pop rax
000073307ffdcfb1  add rsp, 0x08
000073307ffdcfb5  jmp 0x000073307FFDBBD4
000073307ffdcfba  sub rsp, 0x08
000073307ffdcfbe  push rax
000073307ffdcfbf  push rcx
000073307ffdcfc0  push rdx
000073307ffdcfc1  push rdi
000073307ffdcfc2  push rsi
000073307ffdcfc3  push r8
000073307ffdcfc5  push r9
000073307ffdcfc7  push r10
000073307ffdcfc9  push r11
000073307ffdcfcb  sub rsp, 0xF0
000073307ffdcfd2  vmovaps [rsp], xmm0
000073307ffdcfd7  vmovaps [rsp+0x10], xmm1
000073307ffdcfdd  vmovaps [rsp+0x20], xmm2
000073307ffdcfe3  vmovaps [rsp+0x30], xmm4
000073307ffdcfe9  vmovaps [rsp+0x40], xmm5
000073307ffdcfef  vmovaps [rsp+0x50], xmm6
000073307ffdcff5  vmovaps [rsp+0x60], xmm7
000073307ffdcffb  vmovaps [rsp+0x70], xmm8
000073307ffdd001  vmovaps [rsp+0x80], xmm9
000073307ffdd00a  vmovaps [rsp+0x90], xmm10
000073307ffdd013  vmovaps [rsp+0xA0], xmm11
000073307ffdd01c  vmovaps [rsp+0xB0], xmm12
000073307ffdd025  vmovaps [rsp+0xC0], xmm13
000073307ffdd02e  vmovaps [rsp+0xD0], xmm14
000073307ffdd037  vmovaps [rsp+0xE0], xmm15
000073307ffdd040  sub rsp, 0x30
000073307ffdd044  movaps [rsp], xmm3
000073307ffdd048  movaps [rsp+0x10], xmm5
000073307ffdd04d  movaps [rsp+0x20], xmm4
000073307ffdd052  lea rdi, [rsp]
000073307ffdd056  mov esi, 0x00
000073307ffdd05b  mov rax, 0x600DE0EC8530
000073307ffdd065  call rax
000073307ffdd067  movaps xmm3, [rsp]
000073307ffdd06b  add rsp, 0x30
000073307ffdd06f  vmovaps xmm0, [rsp]
000073307ffdd074  vmovaps xmm1, [rsp+0x10]
000073307ffdd07a  vmovaps xmm2, [rsp+0x20]
000073307ffdd080  vmovaps xmm4, [rsp+0x30]
000073307ffdd086  vmovaps xmm5, [rsp+0x40]
000073307ffdd08c  vmovaps xmm6, [rsp+0x50]
000073307ffdd092  vmovaps xmm7, [rsp+0x60]
000073307ffdd098  vmovaps xmm8, [rsp+0x70]
000073307ffdd09e  vmovaps xmm9, [rsp+0x80]
000073307ffdd0a7  vmovaps xmm10, [rsp+0x90]
000073307ffdd0b0  vmovaps xmm11, [rsp+0xA0]
000073307ffdd0b9  vmovaps xmm12, [rsp+0xB0]
000073307ffdd0c2  vmovaps xmm13, [rsp+0xC0]
000073307ffdd0cb  vmovaps xmm14, [rsp+0xD0]
000073307ffdd0d4  vmovaps xmm15, [rsp+0xE0]
000073307ffdd0dd  add rsp, 0xF0
000073307ffdd0e4  pop r11
000073307ffdd0e6  pop r10
000073307ffdd0e8  pop r9
000073307ffdd0ea  pop r8
000073307ffdd0ec  pop rsi
000073307ffdd0ed  pop rdi
000073307ffdd0ee  pop rdx
000073307ffdd0ef  pop rcx
000073307ffdd0f0  pop rax
000073307ffdd0f1  add rsp, 0x08
000073307ffdd0f5  jmp 0x000073307FFDBC35
000073307ffdd0fa  sub rsp, 0x08
000073307ffdd0fe  push rax
000073307ffdd0ff  push rcx
000073307ffdd100  push rdx
000073307ffdd101  push rdi
000073307ffdd102  push rsi
000073307ffdd103  push r8
000073307ffdd105  push r9
000073307ffdd107  push r10
000073307ffdd109  push r11
000073307ffdd10b  sub rsp, 0xF0
000073307ffdd112  vmovaps [rsp], xmm0
000073307ffdd117  vmovaps [rsp+0x10], xmm1
000073307ffdd11d  vmovaps [rsp+0x20], xmm2
000073307ffdd123  vmovaps [rsp+0x30], xmm3
000073307ffdd129  vmovaps [rsp+0x40], xmm4
000073307ffdd12f  vmovaps [rsp+0x50], xmm6
000073307ffdd135  vmovaps [rsp+0x60], xmm7
000073307ffdd13b  vmovaps [rsp+0x70], xmm8
000073307ffdd141  vmovaps [rsp+0x80], xmm9
000073307ffdd14a  vmovaps [rsp+0x90], xmm10
000073307ffdd153  vmovaps [rsp+0xA0], xmm11
000073307ffdd15c  vmovaps [rsp+0xB0], xmm12
000073307ffdd165  vmovaps [rsp+0xC0], xmm13
000073307ffdd16e  vmovaps [rsp+0xD0], xmm14
000073307ffdd177  vmovaps [rsp+0xE0], xmm15
000073307ffdd180  sub rsp, 0x30
000073307ffdd184  movaps [rsp], xmm5
000073307ffdd188  movaps [rsp+0x10], xmm8
000073307ffdd18e  movaps [rsp+0x20], xmm15
000073307ffdd194  lea rdi, [rsp]
000073307ffdd198  mov esi, 0x00
000073307ffdd19d  mov rax, 0x600DE0EC8530
000073307ffdd1a7  call rax
000073307ffdd1a9  movaps xmm5, [rsp]
000073307ffdd1ad  add rsp, 0x30
000073307ffdd1b1  vmovaps xmm0, [rsp]
000073307ffdd1b6  vmovaps xmm1, [rsp+0x10]
000073307ffdd1bc  vmovaps xmm2, [rsp+0x20]
000073307ffdd1c2  vmovaps xmm3, [rsp+0x30]
000073307ffdd1c8  vmovaps xmm4, [rsp+0x40]
000073307ffdd1ce  vmovaps xmm6, [rsp+0x50]
000073307ffdd1d4  vmovaps xmm7, [rsp+0x60]
000073307ffdd1da  vmovaps xmm8, [rsp+0x70]
000073307ffdd1e0  vmovaps xmm9, [rsp+0x80]
000073307ffdd1e9  vmovaps xmm10, [rsp+0x90]
000073307ffdd1f2  vmovaps xmm11, [rsp+0xA0]
000073307ffdd1fb  vmovaps xmm12, [rsp+0xB0]
000073307ffdd204  vmovaps xmm13, [rsp+0xC0]
000073307ffdd20d  vmovaps xmm14, [rsp+0xD0]
000073307ffdd216  vmovaps xmm15, [rsp+0xE0]
000073307ffdd21f  add rsp, 0xF0
000073307ffdd226  pop r11
000073307ffdd228  pop r10
000073307ffdd22a  pop r9
000073307ffdd22c  pop r8
000073307ffdd22e  pop rsi
000073307ffdd22f  pop rdi
000073307ffdd230  pop rdx
000073307ffdd231  pop rcx
000073307ffdd232  pop rax
000073307ffdd233  add rsp, 0x08
000073307ffdd237  jmp 0x000073307FFDBC73
000073307ffdd23c  sub rsp, 0x08
000073307ffdd240  push rax
000073307ffdd241  push rcx
000073307ffdd242  push rdx
000073307ffdd243  push rdi
000073307ffdd244  push rsi
000073307ffdd245  push r8
000073307ffdd247  push r9
000073307ffdd249  push r10
000073307ffdd24b  push r11
000073307ffdd24d  sub rsp, 0xF0
000073307ffdd254  vmovaps [rsp], xmm0
000073307ffdd259  vmovaps [rsp+0x10], xmm1
000073307ffdd25f  vmovaps [rsp+0x20], xmm2
000073307ffdd265  vmovaps [rsp+0x30], xmm3
000073307ffdd26b  vmovaps [rsp+0x40], xmm5
000073307ffdd271  vmovaps [rsp+0x50], xmm6
000073307ffdd277  vmovaps [rsp+0x60], xmm7
000073307ffdd27d  vmovaps [rsp+0x70], xmm8
000073307ffdd283  vmovaps [rsp+0x80], xmm9
000073307ffdd28c  vmovaps [rsp+0x90], xmm10
000073307ffdd295  vmovaps [rsp+0xA0], xmm11
000073307ffdd29e  vmovaps [rsp+0xB0], xmm12
000073307ffdd2a7  vmovaps [rsp+0xC0], xmm13
000073307ffdd2b0  vmovaps [rsp+0xD0], xmm14
000073307ffdd2b9  vmovaps [rsp+0xE0], xmm15
000073307ffdd2c2  sub rsp, 0x30
000073307ffdd2c6  movaps [rsp], xmm4
000073307ffdd2ca  movaps [rsp+0x10], xmm9
000073307ffdd2d0  movaps [rsp+0x20], xmm8
000073307ffdd2d6  lea rdi, [rsp]
000073307ffdd2da  mov esi, 0x00
000073307ffdd2df  mov rax, 0x600DE0EC8530
000073307ffdd2e9  call rax
000073307ffdd2eb  movaps xmm4, [rsp]
000073307ffdd2ef  add rsp, 0x30
000073307ffdd2f3  vmovaps xmm0, [rsp]
000073307ffdd2f8  vmovaps xmm1, [rsp+0x10]
000073307ffdd2fe  vmovaps xmm2, [rsp+0x20]
000073307ffdd304  vmovaps xmm3, [rsp+0x30]
000073307ffdd30a  vmovaps xmm5, [rsp+0x40]
000073307ffdd310  vmovaps xmm6, [rsp+0x50]
000073307ffdd316  vmovaps xmm7, [rsp+0x60]
000073307ffdd31c  vmovaps xmm8, [rsp+0x70]
000073307ffdd322  vmovaps xmm9, [rsp+0x80]
000073307ffdd32b  vmovaps xmm10, [rsp+0x90]
000073307ffdd334  vmovaps xmm11, [rsp+0xA0]
000073307ffdd33d  vmovaps xmm12, [rsp+0xB0]
000073307ffdd346  vmovaps xmm13, [rsp+0xC0]
000073307ffdd34f  vmovaps xmm14, [rsp+0xD0]
000073307ffdd358  vmovaps xmm15, [rsp+0xE0]
000073307ffdd361  add rsp, 0xF0
000073307ffdd368  pop r11
000073307ffdd36a  pop r10
000073307ffdd36c  pop r9
000073307ffdd36e  pop r8
000073307ffdd370  pop rsi
000073307ffdd371  pop rdi
000073307ffdd372  pop rdx
000073307ffdd373  pop rcx
000073307ffdd374  pop rax
000073307ffdd375  add rsp, 0x08
000073307ffdd379  jmp 0x000073307FFDBC94
000073307ffdd37e  sub rsp, 0x08
000073307ffdd382  push rax
000073307ffdd383  push rcx
000073307ffdd384  push rdx
000073307ffdd385  push rdi
000073307ffdd386  push rsi
000073307ffdd387  push r8
000073307ffdd389  push r9
000073307ffdd38b  push r10
000073307ffdd38d  push r11
000073307ffdd38f  sub rsp, 0xF0
000073307ffdd396  vmovaps [rsp], xmm0
000073307ffdd39b  vmovaps [rsp+0x10], xmm1
000073307ffdd3a1  vmovaps [rsp+0x20], xmm2
000073307ffdd3a7  vmovaps [rsp+0x30], xmm3
000073307ffdd3ad  vmovaps [rsp+0x40], xmm4
000073307ffdd3b3  vmovaps [rsp+0x50], xmm5
000073307ffdd3b9  vmovaps [rsp+0x60], xmm6
000073307ffdd3bf  vmovaps [rsp+0x70], xmm7
000073307ffdd3c5  vmovaps [rsp+0x80], xmm8
000073307ffdd3ce  vmovaps [rsp+0x90], xmm10
000073307ffdd3d7  vmovaps [rsp+0xA0], xmm11
000073307ffdd3e0  vmovaps [rsp+0xB0], xmm12
000073307ffdd3e9  vmovaps [rsp+0xC0], xmm13
000073307ffdd3f2  vmovaps [rsp+0xD0], xmm14
000073307ffdd3fb  vmovaps [rsp+0xE0], xmm15
000073307ffdd404  sub rsp, 0x30
000073307ffdd408  movaps [rsp], xmm9
000073307ffdd40d  movaps [rsp+0x10], xmm10
000073307ffdd413  movaps [rsp+0x20], xmm8
000073307ffdd419  lea rdi, [rsp]
000073307ffdd41d  mov esi, 0x00
000073307ffdd422  mov rax, 0x600DE0EC8530
000073307ffdd42c  call rax
000073307ffdd42e  movaps xmm9, [rsp]
000073307ffdd433  add rsp, 0x30
000073307ffdd437  vmovaps xmm0, [rsp]
000073307ffdd43c  vmovaps xmm1, [rsp+0x10]
000073307ffdd442  vmovaps xmm2, [rsp+0x20]
000073307ffdd448  vmovaps xmm3, [rsp+0x30]
000073307ffdd44e  vmovaps xmm4, [rsp+0x40]
000073307ffdd454  vmovaps xmm5, [rsp+0x50]
000073307ffdd45a  vmovaps xmm6, [rsp+0x60]
000073307ffdd460  vmovaps xmm7, [rsp+0x70]
000073307ffdd466  vmovaps xmm8, [rsp+0x80]
000073307ffdd46f  vmovaps xmm10, [rsp+0x90]
000073307ffdd478  vmovaps xmm11, [rsp+0xA0]
000073307ffdd481  vmovaps xmm12, [rsp+0xB0]
000073307ffdd48a  vmovaps xmm13, [rsp+0xC0]
000073307ffdd493  vmovaps xmm14, [rsp+0xD0]
000073307ffdd49c  vmovaps xmm15, [rsp+0xE0]
000073307ffdd4a5  add rsp, 0xF0
000073307ffdd4ac  pop r11
000073307ffdd4ae  pop r10
000073307ffdd4b0  pop r9
000073307ffdd4b2  pop r8
000073307ffdd4b4  pop rsi
000073307ffdd4b5  pop rdi
000073307ffdd4b6  pop rdx
000073307ffdd4b7  pop rcx
000073307ffdd4b8  pop rax
000073307ffdd4b9  add rsp, 0x08
000073307ffdd4bd  jmp 0x000073307FFDBCAE
000073307ffdd4c2  call 0x000073307FEB52F0
000073307ffdd4c7  jmp 0x000073307FFDBDC8
000073307ffdd4cc  call 0x000073307FEB52F0
000073307ffdd4d1  jmp 0x000073307FFDBDDE
000073307ffdd4d6  sub rsp, 0x08
000073307ffdd4da  push rax
000073307ffdd4db  push rcx
000073307ffdd4dc  push rdx
000073307ffdd4dd  push rdi
000073307ffdd4de  push rsi
000073307ffdd4df  push r8
000073307ffdd4e1  push r9
000073307ffdd4e3  push r10
000073307ffdd4e5  push r11
000073307ffdd4e7  sub rsp, 0xF0
000073307ffdd4ee  vmovaps [rsp], xmm0
000073307ffdd4f3  vmovaps [rsp+0x10], xmm2
000073307ffdd4f9  vmovaps [rsp+0x20], xmm3
000073307ffdd4ff  vmovaps [rsp+0x30], xmm4
000073307ffdd505  vmovaps [rsp+0x40], xmm5
000073307ffdd50b  vmovaps [rsp+0x50], xmm6
000073307ffdd511  vmovaps [rsp+0x60], xmm7
000073307ffdd517  vmovaps [rsp+0x70], xmm8
000073307ffdd51d  vmovaps [rsp+0x80], xmm9
000073307ffdd526  vmovaps [rsp+0x90], xmm10
000073307ffdd52f  vmovaps [rsp+0xA0], xmm11
000073307ffdd538  vmovaps [rsp+0xB0], xmm12
000073307ffdd541  vmovaps [rsp+0xC0], xmm13
000073307ffdd54a  vmovaps [rsp+0xD0], xmm14
000073307ffdd553  vmovaps [rsp+0xE0], xmm15
000073307ffdd55c  sub rsp, 0x30
000073307ffdd560  movaps [rsp], xmm1
000073307ffdd564  movaps [rsp+0x10], xmm6
000073307ffdd569  movaps [rsp+0x20], xmm15
000073307ffdd56f  lea rdi, [rsp]
000073307ffdd573  mov esi, 0x00
000073307ffdd578  mov rax, 0x600DE0EC8530
000073307ffdd582  call rax
000073307ffdd584  movaps xmm1, [rsp]
000073307ffdd588  add rsp, 0x30
000073307ffdd58c  vmovaps xmm0, [rsp]
000073307ffdd591  vmovaps xmm2, [rsp+0x10]
000073307ffdd597  vmovaps xmm3, [rsp+0x20]
000073307ffdd59d  vmovaps xmm4, [rsp+0x30]
000073307ffdd5a3  vmovaps xmm5, [rsp+0x40]
000073307ffdd5a9  vmovaps xmm6, [rsp+0x50]
000073307ffdd5af  vmovaps xmm7, [rsp+0x60]
000073307ffdd5b5  vmovaps xmm8, [rsp+0x70]
000073307ffdd5bb  vmovaps xmm9, [rsp+0x80]
000073307ffdd5c4  vmovaps xmm10, [rsp+0x90]
000073307ffdd5cd  vmovaps xmm11, [rsp+0xA0]
000073307ffdd5d6  vmovaps xmm12, [rsp+0xB0]
000073307ffdd5df  vmovaps xmm13, [rsp+0xC0]
000073307ffdd5e8  vmovaps xmm14, [rsp+0xD0]
000073307ffdd5f1  vmovaps xmm15, [rsp+0xE0]
000073307ffdd5fa  add rsp, 0xF0
000073307ffdd601  pop r11
000073307ffdd603  pop r10
000073307ffdd605  pop r9
000073307ffdd607  pop r8
000073307ffdd609  pop rsi
000073307ffdd60a  pop rdi
000073307ffdd60b  pop rdx
000073307ffdd60c  pop rcx
000073307ffdd60d  pop rax
000073307ffdd60e  add rsp, 0x08
000073307ffdd612  jmp 0x000073307FFDBE1B
000073307ffdd617  call 0x000073307FEC4620
000073307ffdd61c  jmp 0x000073307FFDBE28
000073307ffdd621  sub rsp, 0x08
000073307ffdd625  push rax
000073307ffdd626  push rcx
000073307ffdd627  push rdx
000073307ffdd628  push rdi
000073307ffdd629  push rsi
000073307ffdd62a  push r8
000073307ffdd62c  push r9
000073307ffdd62e  push r10
000073307ffdd630  push r11
000073307ffdd632  sub rsp, 0xF0
000073307ffdd639  vmovaps [rsp], xmm0
000073307ffdd63e  vmovaps [rsp+0x10], xmm1
000073307ffdd644  vmovaps [rsp+0x20], xmm2
000073307ffdd64a  vmovaps [rsp+0x30], xmm3
000073307ffdd650  vmovaps [rsp+0x40], xmm4
000073307ffdd656  vmovaps [rsp+0x50], xmm5
000073307ffdd65c  vmovaps [rsp+0x60], xmm6
000073307ffdd662  vmovaps [rsp+0x70], xmm7
000073307ffdd668  vmovaps [rsp+0x80], xmm8
000073307ffdd671  vmovaps [rsp+0x90], xmm9
000073307ffdd67a  vmovaps [rsp+0xA0], xmm10
000073307ffdd683  vmovaps [rsp+0xB0], xmm11
000073307ffdd68c  vmovaps [rsp+0xC0], xmm12
000073307ffdd695  vmovaps [rsp+0xD0], xmm13
000073307ffdd69e  vmovaps [rsp+0xE0], xmm15
000073307ffdd6a7  sub rsp, 0x30
000073307ffdd6ab  movaps [rsp], xmm14
000073307ffdd6b0  movaps [rsp+0x10], xmm4
000073307ffdd6b5  movaps [rsp+0x20], xmm3
000073307ffdd6ba  lea rdi, [rsp]
000073307ffdd6be  mov esi, 0x00
000073307ffdd6c3  mov rax, 0x600DE0EC8530
000073307ffdd6cd  call rax
000073307ffdd6cf  movaps xmm14, [rsp]
000073307ffdd6d4  add rsp, 0x30
000073307ffdd6d8  vmovaps xmm0, [rsp]
000073307ffdd6dd  vmovaps xmm1, [rsp+0x10]
000073307ffdd6e3  vmovaps xmm2, [rsp+0x20]
000073307ffdd6e9  vmovaps xmm3, [rsp+0x30]
000073307ffdd6ef  vmovaps xmm4, [rsp+0x40]
000073307ffdd6f5  vmovaps xmm5, [rsp+0x50]
000073307ffdd6fb  vmovaps xmm6, [rsp+0x60]
000073307ffdd701  vmovaps xmm7, [rsp+0x70]
000073307ffdd707  vmovaps xmm8, [rsp+0x80]
000073307ffdd710  vmovaps xmm9, [rsp+0x90]
000073307ffdd719  vmovaps xmm10, [rsp+0xA0]
000073307ffdd722  vmovaps xmm11, [rsp+0xB0]
000073307ffdd72b  vmovaps xmm12, [rsp+0xC0]
000073307ffdd734  vmovaps xmm13, [rsp+0xD0]
000073307ffdd73d  vmovaps xmm15, [rsp+0xE0]
000073307ffdd746  add rsp, 0xF0
000073307ffdd74d  pop r11
000073307ffdd74f  pop r10
000073307ffdd751  pop r9
000073307ffdd753  pop r8
000073307ffdd755  pop rsi
000073307ffdd756  pop rdi
000073307ffdd757  pop rdx
000073307ffdd758  pop rcx
000073307ffdd759  pop rax
000073307ffdd75a  add rsp, 0x08
000073307ffdd75e  jmp 0x000073307FFDBE42
000073307ffdd763  sub rsp, 0x08
000073307ffdd767  push rax
000073307ffdd768  push rcx
000073307ffdd769  push rdx
000073307ffdd76a  push rdi
000073307ffdd76b  push rsi
000073307ffdd76c  push r8
000073307ffdd76e  push r9
000073307ffdd770  push r10
000073307ffdd772  push r11
000073307ffdd774  sub rsp, 0xF0
000073307ffdd77b  vmovaps [rsp], xmm0
000073307ffdd780  vmovaps [rsp+0x10], xmm1
000073307ffdd786  vmovaps [rsp+0x20], xmm2
000073307ffdd78c  vmovaps [rsp+0x30], xmm3
000073307ffdd792  vmovaps [rsp+0x40], xmm4
000073307ffdd798  vmovaps [rsp+0x50], xmm5
000073307ffdd79e  vmovaps [rsp+0x60], xmm7
000073307ffdd7a4  vmovaps [rsp+0x70], xmm8
000073307ffdd7aa  vmovaps [rsp+0x80], xmm9
000073307ffdd7b3  vmovaps [rsp+0x90], xmm10
000073307ffdd7bc  vmovaps [rsp+0xA0], xmm11
000073307ffdd7c5  vmovaps [rsp+0xB0], xmm12
000073307ffdd7ce  vmovaps [rsp+0xC0], xmm13
000073307ffdd7d7  vmovaps [rsp+0xD0], xmm14
000073307ffdd7e0  vmovaps [rsp+0xE0], xmm15
000073307ffdd7e9  sub rsp, 0x30
000073307ffdd7ed  movaps [rsp], xmm6
000073307ffdd7f1  movaps [rsp+0x10], xmm9
000073307ffdd7f7  movaps [rsp+0x20], xmm7
000073307ffdd7fc  lea rdi, [rsp]
000073307ffdd800  mov esi, 0x00
000073307ffdd805  mov rax, 0x600DE0EC8530
000073307ffdd80f  call rax
000073307ffdd811  movaps xmm6, [rsp]
000073307ffdd815  add rsp, 0x30
000073307ffdd819  vmovaps xmm0, [rsp]
000073307ffdd81e  vmovaps xmm1, [rsp+0x10]
000073307ffdd824  vmovaps xmm2, [rsp+0x20]
000073307ffdd82a  vmovaps xmm3, [rsp+0x30]
000073307ffdd830  vmovaps xmm4, [rsp+0x40]
000073307ffdd836  vmovaps xmm5, [rsp+0x50]
000073307ffdd83c  vmovaps xmm7, [rsp+0x60]
000073307ffdd842  vmovaps xmm8, [rsp+0x70]
000073307ffdd848  vmovaps xmm9, [rsp+0x80]
000073307ffdd851  vmovaps xmm10, [rsp+0x90]
000073307ffdd85a  vmovaps xmm11, [rsp+0xA0]
000073307ffdd863  vmovaps xmm12, [rsp+0xB0]
000073307ffdd86c  vmovaps xmm13, [rsp+0xC0]
000073307ffdd875  vmovaps xmm14, [rsp+0xD0]
000073307ffdd87e  vmovaps xmm15, [rsp+0xE0]
000073307ffdd887  add rsp, 0xF0
000073307ffdd88e  pop r11
000073307ffdd890  pop r10
000073307ffdd892  pop r9
000073307ffdd894  pop r8
000073307ffdd896  pop rsi
000073307ffdd897  pop rdi
000073307ffdd898  pop rdx
000073307ffdd899  pop rcx
000073307ffdd89a  pop rax
000073307ffdd89b  add rsp, 0x08
000073307ffdd89f  jmp 0x000073307FFDBE5A
000073307ffdd8a4  sub rsp, 0x08
000073307ffdd8a8  push rax
000073307ffdd8a9  push rcx
000073307ffdd8aa  push rdx
000073307ffdd8ab  push rdi
000073307ffdd8ac  push rsi
000073307ffdd8ad  push r8
000073307ffdd8af  push r9
000073307ffdd8b1  push r10
000073307ffdd8b3  push r11
000073307ffdd8b5  sub rsp, 0xF0
000073307ffdd8bc  vmovaps [rsp], xmm0
000073307ffdd8c1  vmovaps [rsp+0x10], xmm1
000073307ffdd8c7  vmovaps [rsp+0x20], xmm2
000073307ffdd8cd  vmovaps [rsp+0x30], xmm3
000073307ffdd8d3  vmovaps [rsp+0x40], xmm4
000073307ffdd8d9  vmovaps [rsp+0x50], xmm5
000073307ffdd8df  vmovaps [rsp+0x60], xmm6
000073307ffdd8e5  vmovaps [rsp+0x70], xmm8
000073307ffdd8eb  vmovaps [rsp+0x80], xmm9
000073307ffdd8f4  vmovaps [rsp+0x90], xmm10
000073307ffdd8fd  vmovaps [rsp+0xA0], xmm11
000073307ffdd906  vmovaps [rsp+0xB0], xmm12
000073307ffdd90f  vmovaps [rsp+0xC0], xmm13
000073307ffdd918  vmovaps [rsp+0xD0], xmm14
000073307ffdd921  vmovaps [rsp+0xE0], xmm15
000073307ffdd92a  sub rsp, 0x30
000073307ffdd92e  movaps [rsp], xmm7
000073307ffdd932  movaps [rsp+0x10], xmm4
000073307ffdd937  movaps [rsp+0x20], xmm9
000073307ffdd93d  lea rdi, [rsp]
000073307ffdd941  mov esi, 0x00
000073307ffdd946  mov rax, 0x600DE0EC8530
000073307ffdd950  call rax
000073307ffdd952  movaps xmm7, [rsp]
000073307ffdd956  add rsp, 0x30
000073307ffdd95a  vmovaps xmm0, [rsp]
000073307ffdd95f  vmovaps xmm1, [rsp+0x10]
000073307ffdd965  vmovaps xmm2, [rsp+0x20]
000073307ffdd96b  vmovaps xmm3, [rsp+0x30]
000073307ffdd971  vmovaps xmm4, [rsp+0x40]
000073307ffdd977  vmovaps xmm5, [rsp+0x50]
000073307ffdd97d  vmovaps xmm6, [rsp+0x60]
000073307ffdd983  vmovaps xmm8, [rsp+0x70]
000073307ffdd989  vmovaps xmm9, [rsp+0x80]
000073307ffdd992  vmovaps xmm10, [rsp+0x90]
000073307ffdd99b  vmovaps xmm11, [rsp+0xA0]
000073307ffdd9a4  vmovaps xmm12, [rsp+0xB0]
000073307ffdd9ad  vmovaps xmm13, [rsp+0xC0]
000073307ffdd9b6  vmovaps xmm14, [rsp+0xD0]
000073307ffdd9bf  vmovaps xmm15, [rsp+0xE0]
000073307ffdd9c8  add rsp, 0xF0
000073307ffdd9cf  pop r11
000073307ffdd9d1  pop r10
000073307ffdd9d3  pop r9
000073307ffdd9d5  pop r8
000073307ffdd9d7  pop rsi
000073307ffdd9d8  pop rdi
000073307ffdd9d9  pop rdx
000073307ffdd9da  pop rcx
000073307ffdd9db  pop rax
000073307ffdd9dc  add rsp, 0x08
000073307ffdd9e0  jmp 0x000073307FFDBE87
000073307ffdd9e5  sub rsp, 0x08
000073307ffdd9e9  push rax
000073307ffdd9ea  push rcx
000073307ffdd9eb  push rdx
000073307ffdd9ec  push rdi
000073307ffdd9ed  push rsi
000073307ffdd9ee  push r8
000073307ffdd9f0  push r9
000073307ffdd9f2  push r10
000073307ffdd9f4  push r11
000073307ffdd9f6  sub rsp, 0xF0
000073307ffdd9fd  vmovaps [rsp], xmm0
000073307ffdda02  vmovaps [rsp+0x10], xmm1
000073307ffdda08  vmovaps [rsp+0x20], xmm2
000073307ffdda0e  vmovaps [rsp+0x30], xmm3
000073307ffdda14  vmovaps [rsp+0x40], xmm5
000073307ffdda1a  vmovaps [rsp+0x50], xmm6
000073307ffdda20  vmovaps [rsp+0x60], xmm7
000073307ffdda26  vmovaps [rsp+0x70], xmm8
000073307ffdda2c  vmovaps [rsp+0x80], xmm9
000073307ffdda35  vmovaps [rsp+0x90], xmm10
000073307ffdda3e  vmovaps [rsp+0xA0], xmm11
000073307ffdda47  vmovaps [rsp+0xB0], xmm12
000073307ffdda50  vmovaps [rsp+0xC0], xmm13
000073307ffdda59  vmovaps [rsp+0xD0], xmm14
000073307ffdda62  vmovaps [rsp+0xE0], xmm15
000073307ffdda6b  sub rsp, 0x30
000073307ffdda6f  movaps [rsp], xmm4
000073307ffdda73  movaps [rsp+0x10], xmm15
000073307ffdda79  movaps [rsp+0x20], xmm9
000073307ffdda7f  lea rdi, [rsp]
000073307ffdda83  mov esi, 0x00
000073307ffdda88  mov rax, 0x600DE0EC8530
000073307ffdda92  call rax
000073307ffdda94  movaps xmm4, [rsp]
000073307ffdda98  add rsp, 0x30
000073307ffdda9c  vmovaps xmm0, [rsp]
000073307ffddaa1  vmovaps xmm1, [rsp+0x10]
000073307ffddaa7  vmovaps xmm2, [rsp+0x20]
000073307ffddaad  vmovaps xmm3, [rsp+0x30]
000073307ffddab3  vmovaps xmm5, [rsp+0x40]
000073307ffddab9  vmovaps xmm6, [rsp+0x50]
000073307ffddabf  vmovaps xmm7, [rsp+0x60]
000073307ffddac5  vmovaps xmm8, [rsp+0x70]
000073307ffddacb  vmovaps xmm9, [rsp+0x80]
000073307ffddad4  vmovaps xmm10, [rsp+0x90]
000073307ffddadd  vmovaps xmm11, [rsp+0xA0]
000073307ffddae6  vmovaps xmm12, [rsp+0xB0]
000073307ffddaef  vmovaps xmm13, [rsp+0xC0]
000073307ffddaf8  vmovaps xmm14, [rsp+0xD0]
000073307ffddb01  vmovaps xmm15, [rsp+0xE0]
000073307ffddb0a  add rsp, 0xF0
000073307ffddb11  pop r11
000073307ffddb13  pop r10
000073307ffddb15  pop r9
000073307ffddb17  pop r8
000073307ffddb19  pop rsi
000073307ffddb1a  pop rdi
000073307ffddb1b  pop rdx
000073307ffddb1c  pop rcx
000073307ffddb1d  pop rax
000073307ffddb1e  add rsp, 0x08
000073307ffddb22  jmp 0x000073307FFDBEAC
000073307ffddb27  call 0x000073307FEC4620
000073307ffddb2c  jmp 0x000073307FFDBEB9
000073307ffddb31  sub rsp, 0x08
000073307ffddb35  push rax
000073307ffddb36  push rcx
000073307ffddb37  push rdx
000073307ffddb38  push rdi
000073307ffddb39  push rsi
000073307ffddb3a  push r8
000073307ffddb3c  push r9
000073307ffddb3e  push r10
000073307ffddb40  push r11
000073307ffddb42  sub rsp, 0xF0
000073307ffddb49  vmovaps [rsp], xmm0
000073307ffddb4e  vmovaps [rsp+0x10], xmm1
000073307ffddb54  vmovaps [rsp+0x20], xmm2
000073307ffddb5a  vmovaps [rsp+0x30], xmm4
000073307ffddb60  vmovaps [rsp+0x40], xmm5
000073307ffddb66  vmovaps [rsp+0x50], xmm6
000073307ffddb6c  vmovaps [rsp+0x60], xmm7
000073307ffddb72  vmovaps [rsp+0x70], xmm8
000073307ffddb78  vmovaps [rsp+0x80], xmm9
000073307ffddb81  vmovaps [rsp+0x90], xmm10
000073307ffddb8a  vmovaps [rsp+0xA0], xmm11
000073307ffddb93  vmovaps [rsp+0xB0], xmm12
000073307ffddb9c  vmovaps [rsp+0xC0], xmm13
000073307ffddba5  vmovaps [rsp+0xD0], xmm14
000073307ffddbae  vmovaps [rsp+0xE0], xmm15
000073307ffddbb7  sub rsp, 0x30
000073307ffddbbb  movaps [rsp], xmm3
000073307ffddbbf  movaps [rsp+0x10], xmm1
000073307ffddbc4  movaps [rsp+0x20], xmm9
000073307ffddbca  lea rdi, [rsp]
000073307ffddbce  mov esi, 0x00
000073307ffddbd3  mov rax, 0x600DE0EC8530
000073307ffddbdd  call rax
000073307ffddbdf  movaps xmm3, [rsp]
000073307ffddbe3  add rsp, 0x30
000073307ffddbe7  vmovaps xmm0, [rsp]
000073307ffddbec  vmovaps xmm1, [rsp+0x10]
000073307ffddbf2  vmovaps xmm2, [rsp+0x20]
000073307ffddbf8  vmovaps xmm4, [rsp+0x30]
000073307ffddbfe  vmovaps xmm5, [rsp+0x40]
000073307ffddc04  vmovaps xmm6, [rsp+0x50]
000073307ffddc0a  vmovaps xmm7, [rsp+0x60]
000073307ffddc10  vmovaps xmm8, [rsp+0x70]
000073307ffddc16  vmovaps xmm9, [rsp+0x80]
000073307ffddc1f  vmovaps xmm10, [rsp+0x90]
000073307ffddc28  vmovaps xmm11, [rsp+0xA0]
000073307ffddc31  vmovaps xmm12, [rsp+0xB0]
000073307ffddc3a  vmovaps xmm13, [rsp+0xC0]
000073307ffddc43  vmovaps xmm14, [rsp+0xD0]
000073307ffddc4c  vmovaps xmm15, [rsp+0xE0]
000073307ffddc55  add rsp, 0xF0
000073307ffddc5c  pop r11
000073307ffddc5e  pop r10
000073307ffddc60  pop r9
000073307ffddc62  pop r8
000073307ffddc64  pop rsi
000073307ffddc65  pop rdi
000073307ffddc66  pop rdx
000073307ffddc67  pop rcx
000073307ffddc68  pop rax
000073307ffddc69  add rsp, 0x08
000073307ffddc6d  jmp 0x000073307FFDBEF6
000073307ffddc72  sub rsp, 0x08
000073307ffddc76  push rax
000073307ffddc77  push rcx
000073307ffddc78  push rdx
000073307ffddc79  push rdi
000073307ffddc7a  push rsi
000073307ffddc7b  push r8
000073307ffddc7d  push r9
000073307ffddc7f  push r10
000073307ffddc81  push r11
000073307ffddc83  sub rsp, 0xF0
000073307ffddc8a  vmovaps [rsp], xmm0
000073307ffddc8f  vmovaps [rsp+0x10], xmm2
000073307ffddc95  vmovaps [rsp+0x20], xmm3
000073307ffddc9b  vmovaps [rsp+0x30], xmm4
000073307ffddca1  vmovaps [rsp+0x40], xmm5
000073307ffddca7  vmovaps [rsp+0x50], xmm6
000073307ffddcad  vmovaps [rsp+0x60], xmm7
000073307ffddcb3  vmovaps [rsp+0x70], xmm8
000073307ffddcb9  vmovaps [rsp+0x80], xmm9
000073307ffddcc2  vmovaps [rsp+0x90], xmm10
000073307ffddccb  vmovaps [rsp+0xA0], xmm11
000073307ffddcd4  vmovaps [rsp+0xB0], xmm12
000073307ffddcdd  vmovaps [rsp+0xC0], xmm13
000073307ffddce6  vmovaps [rsp+0xD0], xmm14
000073307ffddcef  vmovaps [rsp+0xE0], xmm15
000073307ffddcf8  sub rsp, 0x30
000073307ffddcfc  movaps [rsp], xmm1
000073307ffddd00  movaps [rsp+0x10], xmm15
000073307ffddd06  movaps [rsp+0x20], xmm9
000073307ffddd0c  lea rdi, [rsp]
000073307ffddd10  mov esi, 0x00
000073307ffddd15  mov rax, 0x600DE0EC8530
000073307ffddd1f  call rax
000073307ffddd21  movaps xmm1, [rsp]
000073307ffddd25  add rsp, 0x30
000073307ffddd29  vmovaps xmm0, [rsp]
000073307ffddd2e  vmovaps xmm2, [rsp+0x10]
000073307ffddd34  vmovaps xmm3, [rsp+0x20]
000073307ffddd3a  vmovaps xmm4, [rsp+0x30]
000073307ffddd40  vmovaps xmm5, [rsp+0x40]
000073307ffddd46  vmovaps xmm6, [rsp+0x50]
000073307ffddd4c  vmovaps xmm7, [rsp+0x60]
000073307ffddd52  vmovaps xmm8, [rsp+0x70]
000073307ffddd58  vmovaps xmm9, [rsp+0x80]
000073307ffddd61  vmovaps xmm10, [rsp+0x90]
000073307ffddd6a  vmovaps xmm11, [rsp+0xA0]
000073307ffddd73  vmovaps xmm12, [rsp+0xB0]
000073307ffddd7c  vmovaps xmm13, [rsp+0xC0]
000073307ffddd85  vmovaps xmm14, [rsp+0xD0]
000073307ffddd8e  vmovaps xmm15, [rsp+0xE0]
000073307ffddd97  add rsp, 0xF0
000073307ffddd9e  pop r11
000073307ffddda0  pop r10
000073307ffddda2  pop r9
000073307ffddda4  pop r8
000073307ffddda6  pop rsi
000073307ffddda7  pop rdi
000073307ffddda8  pop rdx
000073307ffddda9  pop rcx
000073307ffdddaa  pop rax
000073307ffdddab  add rsp, 0x08
000073307ffdddaf  jmp 0x000073307FFDBF7E
000073307ffdddb4  call 0x000073307FEC4620
000073307ffdddb9  jmp 0x000073307FFDBF8B
000073307ffdddbe  sub rsp, 0x08
000073307ffdddc2  push rax
000073307ffdddc3  push rcx
000073307ffdddc4  push rdx
000073307ffdddc5  push rdi
000073307ffdddc6  push rsi
000073307ffdddc7  push r8
000073307ffdddc9  push r9
000073307ffdddcb  push r10
000073307ffdddcd  push r11
000073307ffdddcf  sub rsp, 0xF0
000073307ffdddd6  vmovaps [rsp], xmm0
000073307ffddddb  vmovaps [rsp+0x10], xmm2
000073307ffddde1  vmovaps [rsp+0x20], xmm3
000073307ffddde7  vmovaps [rsp+0x30], xmm4
000073307ffddded  vmovaps [rsp+0x40], xmm5
000073307ffdddf3  vmovaps [rsp+0x50], xmm6
000073307ffdddf9  vmovaps [rsp+0x60], xmm7
000073307ffdddff  vmovaps [rsp+0x70], xmm8
000073307ffdde05  vmovaps [rsp+0x80], xmm9
000073307ffdde0e  vmovaps [rsp+0x90], xmm10
000073307ffdde17  vmovaps [rsp+0xA0], xmm11
000073307ffdde20  vmovaps [rsp+0xB0], xmm12
000073307ffdde29  vmovaps [rsp+0xC0], xmm13
000073307ffdde32  vmovaps [rsp+0xD0], xmm14
000073307ffdde3b  vmovaps [rsp+0xE0], xmm15
000073307ffdde44  sub rsp, 0x30
000073307ffdde48  movaps [rsp], xmm1
000073307ffdde4c  movaps [rsp+0x10], xmm5
000073307ffdde51  movaps [rsp+0x20], xmm7
000073307ffdde56  lea rdi, [rsp]
000073307ffdde5a  mov esi, 0x00
000073307ffdde5f  mov rax, 0x600DE0EC8530
000073307ffdde69  call rax
000073307ffdde6b  movaps xmm1, [rsp]
000073307ffdde6f  add rsp, 0x30
000073307ffdde73  vmovaps xmm0, [rsp]
000073307ffdde78  vmovaps xmm2, [rsp+0x10]
000073307ffdde7e  vmovaps xmm3, [rsp+0x20]
000073307ffdde84  vmovaps xmm4, [rsp+0x30]
000073307ffdde8a  vmovaps xmm5, [rsp+0x40]
000073307ffdde90  vmovaps xmm6, [rsp+0x50]
000073307ffdde96  vmovaps xmm7, [rsp+0x60]
000073307ffdde9c  vmovaps xmm8, [rsp+0x70]
000073307ffddea2  vmovaps xmm9, [rsp+0x80]
000073307ffddeab  vmovaps xmm10, [rsp+0x90]
000073307ffddeb4  vmovaps xmm11, [rsp+0xA0]
000073307ffddebd  vmovaps xmm12, [rsp+0xB0]
000073307ffddec6  vmovaps xmm13, [rsp+0xC0]
000073307ffddecf  vmovaps xmm14, [rsp+0xD0]
000073307ffdded8  vmovaps xmm15, [rsp+0xE0]
000073307ffddee1  add rsp, 0xF0
000073307ffddee8  pop r11
000073307ffddeea  pop r10
000073307ffddeec  pop r9
000073307ffddeee  pop r8
000073307ffddef0  pop rsi
000073307ffddef1  pop rdi
000073307ffddef2  pop rdx
000073307ffddef3  pop rcx
000073307ffddef4  pop rax
000073307ffddef5  add rsp, 0x08
000073307ffddef9  jmp 0x000073307FFDC030
000073307ffddefe  sub rsp, 0x08
000073307ffddf02  push rax
000073307ffddf03  push rcx
000073307ffddf04  push rdx
000073307ffddf05  push rdi
000073307ffddf06  push rsi
000073307ffddf07  push r8
000073307ffddf09  push r9
000073307ffddf0b  push r10
000073307ffddf0d  push r11
000073307ffddf0f  sub rsp, 0xF0
000073307ffddf16  vmovaps [rsp], xmm0
000073307ffddf1b  vmovaps [rsp+0x10], xmm1
000073307ffddf21  vmovaps [rsp+0x20], xmm2
000073307ffddf27  vmovaps [rsp+0x30], xmm3
000073307ffddf2d  vmovaps [rsp+0x40], xmm4
000073307ffddf33  vmovaps [rsp+0x50], xmm5
000073307ffddf39  vmovaps [rsp+0x60], xmm6
000073307ffddf3f  vmovaps [rsp+0x70], xmm8
000073307ffddf45  vmovaps [rsp+0x80], xmm9
000073307ffddf4e  vmovaps [rsp+0x90], xmm10
000073307ffddf57  vmovaps [rsp+0xA0], xmm11
000073307ffddf60  vmovaps [rsp+0xB0], xmm12
000073307ffddf69  vmovaps [rsp+0xC0], xmm13
000073307ffddf72  vmovaps [rsp+0xD0], xmm14
000073307ffddf7b  vmovaps [rsp+0xE0], xmm15
000073307ffddf84  sub rsp, 0x30
000073307ffddf88  movaps [rsp], xmm7
000073307ffddf8c  movaps [rsp+0x10], xmm5
000073307ffddf91  movaps [rsp+0x20], xmm15
000073307ffddf97  lea rdi, [rsp]
000073307ffddf9b  mov esi, 0x00
000073307ffddfa0  mov rax, 0x600DE0EC8530
000073307ffddfaa  call rax
000073307ffddfac  movaps xmm7, [rsp]
000073307ffddfb0  add rsp, 0x30
000073307ffddfb4  vmovaps xmm0, [rsp]
000073307ffddfb9  vmovaps xmm1, [rsp+0x10]
000073307ffddfbf  vmovaps xmm2, [rsp+0x20]
000073307ffddfc5  vmovaps xmm3, [rsp+0x30]
000073307ffddfcb  vmovaps xmm4, [rsp+0x40]
000073307ffddfd1  vmovaps xmm5, [rsp+0x50]
000073307ffddfd7  vmovaps xmm6, [rsp+0x60]
000073307ffddfdd  vmovaps xmm8, [rsp+0x70]
000073307ffddfe3  vmovaps xmm9, [rsp+0x80]
000073307ffddfec  vmovaps xmm10, [rsp+0x90]
000073307ffddff5  vmovaps xmm11, [rsp+0xA0]
000073307ffddffe  vmovaps xmm12, [rsp+0xB0]
000073307ffde007  vmovaps xmm13, [rsp+0xC0]
000073307ffde010  vmovaps xmm14, [rsp+0xD0]
000073307ffde019  vmovaps xmm15, [rsp+0xE0]
000073307ffde022  add rsp, 0xF0
000073307ffde029  pop r11
000073307ffde02b  pop r10
000073307ffde02d  pop r9
000073307ffde02f  pop r8
000073307ffde031  pop rsi
000073307ffde032  pop rdi
000073307ffde033  pop rdx
000073307ffde034  pop rcx
000073307ffde035  pop rax
000073307ffde036  add rsp, 0x08
000073307ffde03a  jmp 0x000073307FFDC066
000073307ffde03f  call 0x000073307FEB52F0
000073307ffde044  jmp 0x000073307FFDC073
000073307ffde049  sub rsp, 0x08
000073307ffde04d  push rax
000073307ffde04e  push rcx
000073307ffde04f  push rdx
000073307ffde050  push rdi
000073307ffde051  push rsi
000073307ffde052  push r8
000073307ffde054  push r9
000073307ffde056  push r10
000073307ffde058  push r11
000073307ffde05a  sub rsp, 0xF0
000073307ffde061  vmovaps [rsp], xmm0
000073307ffde066  vmovaps [rsp+0x10], xmm1
000073307ffde06c  vmovaps [rsp+0x20], xmm2
000073307ffde072  vmovaps [rsp+0x30], xmm3
000073307ffde078  vmovaps [rsp+0x40], xmm4
000073307ffde07e  vmovaps [rsp+0x50], xmm5
000073307ffde084  vmovaps [rsp+0x60], xmm6
000073307ffde08a  vmovaps [rsp+0x70], xmm7
000073307ffde090  vmovaps [rsp+0x80], xmm8
000073307ffde099  vmovaps [rsp+0x90], xmm9
000073307ffde0a2  vmovaps [rsp+0xA0], xmm10
000073307ffde0ab  vmovaps [rsp+0xB0], xmm11
000073307ffde0b4  vmovaps [rsp+0xC0], xmm12
000073307ffde0bd  vmovaps [rsp+0xD0], xmm13
000073307ffde0c6  vmovaps [rsp+0xE0], xmm14
000073307ffde0cf  sub rsp, 0x30
000073307ffde0d3  movaps [rsp], xmm15
000073307ffde0d8  movaps [rsp+0x10], xmm5
000073307ffde0dd  movaps [rsp+0x20], xmm3
000073307ffde0e2  lea rdi, [rsp]
000073307ffde0e6  mov esi, 0x00
000073307ffde0eb  mov rax, 0x600DE0EC8530
000073307ffde0f5  call rax
000073307ffde0f7  movaps xmm15, [rsp]
000073307ffde0fc  add rsp, 0x30
000073307ffde100  vmovaps xmm0, [rsp]
000073307ffde105  vmovaps xmm1, [rsp+0x10]
000073307ffde10b  vmovaps xmm2, [rsp+0x20]
000073307ffde111  vmovaps xmm3, [rsp+0x30]
000073307ffde117  vmovaps xmm4, [rsp+0x40]
000073307ffde11d  vmovaps xmm5, [rsp+0x50]
000073307ffde123  vmovaps xmm6, [rsp+0x60]
000073307ffde129  vmovaps xmm7, [rsp+0x70]
000073307ffde12f  vmovaps xmm8, [rsp+0x80]
000073307ffde138  vmovaps xmm9, [rsp+0x90]
000073307ffde141  vmovaps xmm10, [rsp+0xA0]
000073307ffde14a  vmovaps xmm11, [rsp+0xB0]
000073307ffde153  vmovaps xmm12, [rsp+0xC0]
000073307ffde15c  vmovaps xmm13, [rsp+0xD0]
000073307ffde165  vmovaps xmm14, [rsp+0xE0]
000073307ffde16e  add rsp, 0xF0
000073307ffde175  pop r11
000073307ffde177  pop r10
000073307ffde179  pop r9
000073307ffde17b  pop r8
000073307ffde17d  pop rsi
000073307ffde17e  pop rdi
000073307ffde17f  pop rdx
000073307ffde180  pop rcx
000073307ffde181  pop rax
000073307ffde182  add rsp, 0x08
000073307ffde186  jmp 0x000073307FFDC099
000073307ffde18b  sub rsp, 0x08
000073307ffde18f  push rax
000073307ffde190  push rcx
000073307ffde191  push rdx
000073307ffde192  push rdi
000073307ffde193  push rsi
000073307ffde194  push r8
000073307ffde196  push r9
000073307ffde198  push r10
000073307ffde19a  push r11
000073307ffde19c  sub rsp, 0xF0
000073307ffde1a3  vmovaps [rsp], xmm0
000073307ffde1a8  vmovaps [rsp+0x10], xmm2
000073307ffde1ae  vmovaps [rsp+0x20], xmm3
000073307ffde1b4  vmovaps [rsp+0x30], xmm4
000073307ffde1ba  vmovaps [rsp+0x40], xmm5
000073307ffde1c0  vmovaps [rsp+0x50], xmm6
000073307ffde1c6  vmovaps [rsp+0x60], xmm7
000073307ffde1cc  vmovaps [rsp+0x70], xmm8
000073307ffde1d2  vmovaps [rsp+0x80], xmm9
000073307ffde1db  vmovaps [rsp+0x90], xmm10
000073307ffde1e4  vmovaps [rsp+0xA0], xmm11
000073307ffde1ed  vmovaps [rsp+0xB0], xmm12
000073307ffde1f6  vmovaps [rsp+0xC0], xmm13
000073307ffde1ff  vmovaps [rsp+0xD0], xmm14
000073307ffde208  vmovaps [rsp+0xE0], xmm15
000073307ffde211  sub rsp, 0x30
000073307ffde215  movaps [rsp], xmm1
000073307ffde219  movaps [rsp+0x10], xmm5
000073307ffde21e  movaps [rsp+0x20], xmm4
000073307ffde223  lea rdi, [rsp]
000073307ffde227  mov esi, 0x00
000073307ffde22c  mov rax, 0x600DE0EC8530
000073307ffde236  call rax
000073307ffde238  movaps xmm1, [rsp]
000073307ffde23c  add rsp, 0x30
000073307ffde240  vmovaps xmm0, [rsp]
000073307ffde245  vmovaps xmm2, [rsp+0x10]
000073307ffde24b  vmovaps xmm3, [rsp+0x20]
000073307ffde251  vmovaps xmm4, [rsp+0x30]
000073307ffde257  vmovaps xmm5, [rsp+0x40]
000073307ffde25d  vmovaps xmm6, [rsp+0x50]
000073307ffde263  vmovaps xmm7, [rsp+0x60]
000073307ffde269  vmovaps xmm8, [rsp+0x70]
000073307ffde26f  vmovaps xmm9, [rsp+0x80]
000073307ffde278  vmovaps xmm10, [rsp+0x90]
000073307ffde281  vmovaps xmm11, [rsp+0xA0]
000073307ffde28a  vmovaps xmm12, [rsp+0xB0]
000073307ffde293  vmovaps xmm13, [rsp+0xC0]
000073307ffde29c  vmovaps xmm14, [rsp+0xD0]
000073307ffde2a5  vmovaps xmm15, [rsp+0xE0]
000073307ffde2ae  add rsp, 0xF0
000073307ffde2b5  pop r11
000073307ffde2b7  pop r10
000073307ffde2b9  pop r9
000073307ffde2bb  pop r8
000073307ffde2bd  pop rsi
000073307ffde2be  pop rdi
000073307ffde2bf  pop rdx
000073307ffde2c0  pop rcx
000073307ffde2c1  pop rax
000073307ffde2c2  add rsp, 0x08
000073307ffde2c6  jmp 0x000073307FFDC0B9
000073307ffde2cb  sub rsp, 0x08
000073307ffde2cf  push rax
000073307ffde2d0  push rcx
000073307ffde2d1  push rdx
000073307ffde2d2  push rdi
000073307ffde2d3  push rsi
000073307ffde2d4  push r8
000073307ffde2d6  push r9
000073307ffde2d8  push r10
000073307ffde2da  push r11
000073307ffde2dc  sub rsp, 0xF0
000073307ffde2e3  vmovaps [rsp], xmm0
000073307ffde2e8  vmovaps [rsp+0x10], xmm1
000073307ffde2ee  vmovaps [rsp+0x20], xmm2
000073307ffde2f4  vmovaps [rsp+0x30], xmm3
000073307ffde2fa  vmovaps [rsp+0x40], xmm5
000073307ffde300  vmovaps [rsp+0x50], xmm6
000073307ffde306  vmovaps [rsp+0x60], xmm7
000073307ffde30c  vmovaps [rsp+0x70], xmm8
000073307ffde312  vmovaps [rsp+0x80], xmm9
000073307ffde31b  vmovaps [rsp+0x90], xmm10
000073307ffde324  vmovaps [rsp+0xA0], xmm11
000073307ffde32d  vmovaps [rsp+0xB0], xmm12
000073307ffde336  vmovaps [rsp+0xC0], xmm13
000073307ffde33f  vmovaps [rsp+0xD0], xmm14
000073307ffde348  vmovaps [rsp+0xE0], xmm15
000073307ffde351  sub rsp, 0x30
000073307ffde355  movaps [rsp], xmm4
000073307ffde359  movaps [rsp+0x10], xmm3
000073307ffde35e  movaps [rsp+0x20], xmm5
000073307ffde363  lea rdi, [rsp]
000073307ffde367  mov esi, 0x00
000073307ffde36c  mov rax, 0x600DE0EC8530
000073307ffde376  call rax
000073307ffde378  movaps xmm4, [rsp]
000073307ffde37c  add rsp, 0x30
000073307ffde380  vmovaps xmm0, [rsp]
000073307ffde385  vmovaps xmm1, [rsp+0x10]
000073307ffde38b  vmovaps xmm2, [rsp+0x20]
000073307ffde391  vmovaps xmm3, [rsp+0x30]
000073307ffde397  vmovaps xmm5, [rsp+0x40]
000073307ffde39d  vmovaps xmm6, [rsp+0x50]
000073307ffde3a3  vmovaps xmm7, [rsp+0x60]
000073307ffde3a9  vmovaps xmm8, [rsp+0x70]
000073307ffde3af  vmovaps xmm9, [rsp+0x80]
000073307ffde3b8  vmovaps xmm10, [rsp+0x90]
000073307ffde3c1  vmovaps xmm11, [rsp+0xA0]
000073307ffde3ca  vmovaps xmm12, [rsp+0xB0]
000073307ffde3d3  vmovaps xmm13, [rsp+0xC0]
000073307ffde3dc  vmovaps xmm14, [rsp+0xD0]
000073307ffde3e5  vmovaps xmm15, [rsp+0xE0]
000073307ffde3ee  add rsp, 0xF0
000073307ffde3f5  pop r11
000073307ffde3f7  pop r10
000073307ffde3f9  pop r9
000073307ffde3fb  pop r8
000073307ffde3fd  pop rsi
000073307ffde3fe  pop rdi
000073307ffde3ff  pop rdx
000073307ffde400  pop rcx
000073307ffde401  pop rax
000073307ffde402  add rsp, 0x08
000073307ffde406  jmp 0x000073307FFDC107
000073307ffde40b  call 0x000073307FEB52F0
000073307ffde410  jmp 0x000073307FFDC114
000073307ffde415  sub rsp, 0x08
000073307ffde419  push rax
000073307ffde41a  push rcx
000073307ffde41b  push rdx
000073307ffde41c  push rdi
000073307ffde41d  push rsi
000073307ffde41e  push r8
000073307ffde420  push r9
000073307ffde422  push r10
000073307ffde424  push r11
000073307ffde426  sub rsp, 0xF0
000073307ffde42d  vmovaps [rsp], xmm0
000073307ffde432  vmovaps [rsp+0x10], xmm1
000073307ffde438  vmovaps [rsp+0x20], xmm2
000073307ffde43e  vmovaps [rsp+0x30], xmm3
000073307ffde444  vmovaps [rsp+0x40], xmm4
000073307ffde44a  vmovaps [rsp+0x50], xmm6
000073307ffde450  vmovaps [rsp+0x60], xmm7
000073307ffde456  vmovaps [rsp+0x70], xmm8
000073307ffde45c  vmovaps [rsp+0x80], xmm9
000073307ffde465  vmovaps [rsp+0x90], xmm10
000073307ffde46e  vmovaps [rsp+0xA0], xmm11
000073307ffde477  vmovaps [rsp+0xB0], xmm12
000073307ffde480  vmovaps [rsp+0xC0], xmm13
000073307ffde489  vmovaps [rsp+0xD0], xmm14
000073307ffde492  vmovaps [rsp+0xE0], xmm15
000073307ffde49b  sub rsp, 0x30
000073307ffde49f  movaps [rsp], xmm5
000073307ffde4a3  movaps [rsp+0x10], xmm6
000073307ffde4a8  movaps [rsp+0x20], xmm3
000073307ffde4ad  lea rdi, [rsp]
000073307ffde4b1  mov esi, 0x00
000073307ffde4b6  mov rax, 0x600DE0EC8530
000073307ffde4c0  call rax
000073307ffde4c2  movaps xmm5, [rsp]
000073307ffde4c6  add rsp, 0x30
000073307ffde4ca  vmovaps xmm0, [rsp]
000073307ffde4cf  vmovaps xmm1, [rsp+0x10]
000073307ffde4d5  vmovaps xmm2, [rsp+0x20]
000073307ffde4db  vmovaps xmm3, [rsp+0x30]
000073307ffde4e1  vmovaps xmm4, [rsp+0x40]
000073307ffde4e7  vmovaps xmm6, [rsp+0x50]
000073307ffde4ed  vmovaps xmm7, [rsp+0x60]
000073307ffde4f3  vmovaps xmm8, [rsp+0x70]
000073307ffde4f9  vmovaps xmm9, [rsp+0x80]
000073307ffde502  vmovaps xmm10, [rsp+0x90]
000073307ffde50b  vmovaps xmm11, [rsp+0xA0]
000073307ffde514  vmovaps xmm12, [rsp+0xB0]
000073307ffde51d  vmovaps xmm13, [rsp+0xC0]
000073307ffde526  vmovaps xmm14, [rsp+0xD0]
000073307ffde52f  vmovaps xmm15, [rsp+0xE0]
000073307ffde538  add rsp, 0xF0
000073307ffde53f  pop r11
000073307ffde541  pop r10
000073307ffde543  pop r9
000073307ffde545  pop r8
000073307ffde547  pop rsi
000073307ffde548  pop rdi
000073307ffde549  pop rdx
000073307ffde54a  pop rcx
000073307ffde54b  pop rax
000073307ffde54c  add rsp, 0x08
000073307ffde550  jmp 0x000073307FFDC13A
000073307ffde555  sub rsp, 0x08
000073307ffde559  push rax
000073307ffde55a  push rcx
000073307ffde55b  push rdx
000073307ffde55c  push rdi
000073307ffde55d  push rsi
000073307ffde55e  push r8
000073307ffde560  push r9
000073307ffde562  push r10
000073307ffde564  push r11
000073307ffde566  sub rsp, 0xF0
000073307ffde56d  vmovaps [rsp], xmm0
000073307ffde572  vmovaps [rsp+0x10], xmm1
000073307ffde578  vmovaps [rsp+0x20], xmm2
000073307ffde57e  vmovaps [rsp+0x30], xmm3
000073307ffde584  vmovaps [rsp+0x40], xmm4
000073307ffde58a  vmovaps [rsp+0x50], xmm5
000073307ffde590  vmovaps [rsp+0x60], xmm7
000073307ffde596  vmovaps [rsp+0x70], xmm8
000073307ffde59c  vmovaps [rsp+0x80], xmm9
000073307ffde5a5  vmovaps [rsp+0x90], xmm10
000073307ffde5ae  vmovaps [rsp+0xA0], xmm11
000073307ffde5b7  vmovaps [rsp+0xB0], xmm12
000073307ffde5c0  vmovaps [rsp+0xC0], xmm13
000073307ffde5c9  vmovaps [rsp+0xD0], xmm14
000073307ffde5d2  vmovaps [rsp+0xE0], xmm15
000073307ffde5db  sub rsp, 0x30
000073307ffde5df  movaps [rsp], xmm6
000073307ffde5e3  movaps [rsp+0x10], xmm9
000073307ffde5e9  movaps [rsp+0x20], xmm1
000073307ffde5ee  lea rdi, [rsp]
000073307ffde5f2  mov esi, 0x00
000073307ffde5f7  mov rax, 0x600DE0EC8530
000073307ffde601  call rax
000073307ffde603  movaps xmm6, [rsp]
000073307ffde607  add rsp, 0x30
000073307ffde60b  vmovaps xmm0, [rsp]
000073307ffde610  vmovaps xmm1, [rsp+0x10]
000073307ffde616  vmovaps xmm2, [rsp+0x20]
000073307ffde61c  vmovaps xmm3, [rsp+0x30]
000073307ffde622  vmovaps xmm4, [rsp+0x40]
000073307ffde628  vmovaps xmm5, [rsp+0x50]
000073307ffde62e  vmovaps xmm7, [rsp+0x60]
000073307ffde634  vmovaps xmm8, [rsp+0x70]
000073307ffde63a  vmovaps xmm9, [rsp+0x80]
000073307ffde643  vmovaps xmm10, [rsp+0x90]
000073307ffde64c  vmovaps xmm11, [rsp+0xA0]
000073307ffde655  vmovaps xmm12, [rsp+0xB0]
000073307ffde65e  vmovaps xmm13, [rsp+0xC0]
000073307ffde667  vmovaps xmm14, [rsp+0xD0]
000073307ffde670  vmovaps xmm15, [rsp+0xE0]
000073307ffde679  add rsp, 0xF0
000073307ffde680  pop r11
000073307ffde682  pop r10
000073307ffde684  pop r9
000073307ffde686  pop r8
000073307ffde688  pop rsi
000073307ffde689  pop rdi
000073307ffde68a  pop rdx
000073307ffde68b  pop rcx
000073307ffde68c  pop rax
000073307ffde68d  add rsp, 0x08
000073307ffde691  jmp 0x000073307FFDC15E
000073307ffde696  sub rsp, 0x08
000073307ffde69a  push rax
000073307ffde69b  push rcx
000073307ffde69c  push rdx
000073307ffde69d  push rdi
000073307ffde69e  push rsi
000073307ffde69f  push r8
000073307ffde6a1  push r9
000073307ffde6a3  push r10
000073307ffde6a5  push r11
000073307ffde6a7  sub rsp, 0xF0
000073307ffde6ae  vmovaps [rsp], xmm0
000073307ffde6b3  vmovaps [rsp+0x10], xmm1
000073307ffde6b9  vmovaps [rsp+0x20], xmm2
000073307ffde6bf  vmovaps [rsp+0x30], xmm3
000073307ffde6c5  vmovaps [rsp+0x40], xmm4
000073307ffde6cb  vmovaps [rsp+0x50], xmm5
000073307ffde6d1  vmovaps [rsp+0x60], xmm6
000073307ffde6d7  vmovaps [rsp+0x70], xmm7
000073307ffde6dd  vmovaps [rsp+0x80], xmm8
000073307ffde6e6  vmovaps [rsp+0x90], xmm10
000073307ffde6ef  vmovaps [rsp+0xA0], xmm11
000073307ffde6f8  vmovaps [rsp+0xB0], xmm12
000073307ffde701  vmovaps [rsp+0xC0], xmm13
000073307ffde70a  vmovaps [rsp+0xD0], xmm14
000073307ffde713  vmovaps [rsp+0xE0], xmm15
000073307ffde71c  sub rsp, 0x30
000073307ffde720  movaps [rsp], xmm9
000073307ffde725  movaps [rsp+0x10], xmm3
000073307ffde72a  movaps [rsp+0x20], xmm1
000073307ffde72f  lea rdi, [rsp]
000073307ffde733  mov esi, 0x00
000073307ffde738  mov rax, 0x600DE0EC8530
000073307ffde742  call rax
000073307ffde744  movaps xmm9, [rsp]
000073307ffde749  add rsp, 0x30
000073307ffde74d  vmovaps xmm0, [rsp]
000073307ffde752  vmovaps xmm1, [rsp+0x10]
000073307ffde758  vmovaps xmm2, [rsp+0x20]
000073307ffde75e  vmovaps xmm3, [rsp+0x30]
000073307ffde764  vmovaps xmm4, [rsp+0x40]
000073307ffde76a  vmovaps xmm5, [rsp+0x50]
000073307ffde770  vmovaps xmm6, [rsp+0x60]
000073307ffde776  vmovaps xmm7, [rsp+0x70]
000073307ffde77c  vmovaps xmm8, [rsp+0x80]
000073307ffde785  vmovaps xmm10, [rsp+0x90]
000073307ffde78e  vmovaps xmm11, [rsp+0xA0]
000073307ffde797  vmovaps xmm12, [rsp+0xB0]
000073307ffde7a0  vmovaps xmm13, [rsp+0xC0]
000073307ffde7a9  vmovaps xmm14, [rsp+0xD0]
000073307ffde7b2  vmovaps xmm15, [rsp+0xE0]
000073307ffde7bb  add rsp, 0xF0
000073307ffde7c2  pop r11
000073307ffde7c4  pop r10
000073307ffde7c6  pop r9
000073307ffde7c8  pop r8
000073307ffde7ca  pop rsi
000073307ffde7cb  pop rdi
000073307ffde7cc  pop rdx
000073307ffde7cd  pop rcx
000073307ffde7ce  pop rax
000073307ffde7cf  add rsp, 0x08
000073307ffde7d3  jmp 0x000073307FFDC1AA
000073307ffde7d8  call 0x000073307FEB52F0
000073307ffde7dd  jmp 0x000073307FFDC1B7
000073307ffde7e2  sub rsp, 0x08
000073307ffde7e6  push rax
000073307ffde7e7  push rcx
000073307ffde7e8  push rdx
000073307ffde7e9  push rdi
000073307ffde7ea  push rsi
000073307ffde7eb  push r8
000073307ffde7ed  push r9
000073307ffde7ef  push r10
000073307ffde7f1  push r11
000073307ffde7f3  sub rsp, 0xF0
000073307ffde7fa  vmovaps [rsp], xmm0
000073307ffde7ff  vmovaps [rsp+0x10], xmm1
000073307ffde805  vmovaps [rsp+0x20], xmm2
000073307ffde80b  vmovaps [rsp+0x30], xmm3
000073307ffde811  vmovaps [rsp+0x40], xmm4
000073307ffde817  vmovaps [rsp+0x50], xmm5
000073307ffde81d  vmovaps [rsp+0x60], xmm6
000073307ffde823  vmovaps [rsp+0x70], xmm7
000073307ffde829  vmovaps [rsp+0x80], xmm8
000073307ffde832  vmovaps [rsp+0x90], xmm9
000073307ffde83b  vmovaps [rsp+0xA0], xmm10
000073307ffde844  vmovaps [rsp+0xB0], xmm11
000073307ffde84d  vmovaps [rsp+0xC0], xmm12
000073307ffde856  vmovaps [rsp+0xD0], xmm13
000073307ffde85f  vmovaps [rsp+0xE0], xmm14
000073307ffde868  sub rsp, 0x30
000073307ffde86c  movaps [rsp], xmm15
000073307ffde871  movaps [rsp+0x10], xmm3
000073307ffde876  movaps [rsp+0x20], xmm7
000073307ffde87b  lea rdi, [rsp]
000073307ffde87f  mov esi, 0x00
000073307ffde884  mov rax, 0x600DE0EC8530
000073307ffde88e  call rax
000073307ffde890  movaps xmm15, [rsp]
000073307ffde895  add rsp, 0x30
000073307ffde899  vmovaps xmm0, [rsp]
000073307ffde89e  vmovaps xmm1, [rsp+0x10]
000073307ffde8a4  vmovaps xmm2, [rsp+0x20]
000073307ffde8aa  vmovaps xmm3, [rsp+0x30]
000073307ffde8b0  vmovaps xmm4, [rsp+0x40]
000073307ffde8b6  vmovaps xmm5, [rsp+0x50]
000073307ffde8bc  vmovaps xmm6, [rsp+0x60]
000073307ffde8c2  vmovaps xmm7, [rsp+0x70]
000073307ffde8c8  vmovaps xmm8, [rsp+0x80]
000073307ffde8d1  vmovaps xmm9, [rsp+0x90]
000073307ffde8da  vmovaps xmm10, [rsp+0xA0]
000073307ffde8e3  vmovaps xmm11, [rsp+0xB0]
000073307ffde8ec  vmovaps xmm12, [rsp+0xC0]
000073307ffde8f5  vmovaps xmm13, [rsp+0xD0]
000073307ffde8fe  vmovaps xmm14, [rsp+0xE0]
000073307ffde907  add rsp, 0xF0
000073307ffde90e  pop r11
000073307ffde910  pop r10
000073307ffde912  pop r9
000073307ffde914  pop r8
000073307ffde916  pop rsi
000073307ffde917  pop rdi
000073307ffde918  pop rdx
000073307ffde919  pop rcx
000073307ffde91a  pop rax
000073307ffde91b  add rsp, 0x08
000073307ffde91f  jmp 0x000073307FFDC1E3
000073307ffde924  sub rsp, 0x08
000073307ffde928  push rax
000073307ffde929  push rcx
000073307ffde92a  push rdx
000073307ffde92b  push rdi
000073307ffde92c  push rsi
000073307ffde92d  push r8
000073307ffde92f  push r9
000073307ffde931  push r10
000073307ffde933  push r11
000073307ffde935  sub rsp, 0xF0
000073307ffde93c  vmovaps [rsp], xmm0
000073307ffde941  vmovaps [rsp+0x10], xmm1
000073307ffde947  vmovaps [rsp+0x20], xmm2
000073307ffde94d  vmovaps [rsp+0x30], xmm4
000073307ffde953  vmovaps [rsp+0x40], xmm5
000073307ffde959  vmovaps [rsp+0x50], xmm6
000073307ffde95f  vmovaps [rsp+0x60], xmm7
000073307ffde965  vmovaps [rsp+0x70], xmm8
000073307ffde96b  vmovaps [rsp+0x80], xmm9
000073307ffde974  vmovaps [rsp+0x90], xmm10
000073307ffde97d  vmovaps [rsp+0xA0], xmm11
000073307ffde986  vmovaps [rsp+0xB0], xmm12
000073307ffde98f  vmovaps [rsp+0xC0], xmm13
000073307ffde998  vmovaps [rsp+0xD0], xmm14
000073307ffde9a1  vmovaps [rsp+0xE0], xmm15
000073307ffde9aa  sub rsp, 0x30
000073307ffde9ae  movaps [rsp], xmm3
000073307ffde9b2  movaps [rsp+0x10], xmm1
000073307ffde9b7  movaps [rsp+0x20], xmm15
000073307ffde9bd  lea rdi, [rsp]
000073307ffde9c1  mov esi, 0x00
000073307ffde9c6  mov rax, 0x600DE0EC8530
000073307ffde9d0  call rax
000073307ffde9d2  movaps xmm3, [rsp]
000073307ffde9d6  add rsp, 0x30
000073307ffde9da  vmovaps xmm0, [rsp]
000073307ffde9df  vmovaps xmm1, [rsp+0x10]
000073307ffde9e5  vmovaps xmm2, [rsp+0x20]
000073307ffde9eb  vmovaps xmm4, [rsp+0x30]
000073307ffde9f1  vmovaps xmm5, [rsp+0x40]
000073307ffde9f7  vmovaps xmm6, [rsp+0x50]
000073307ffde9fd  vmovaps xmm7, [rsp+0x60]
000073307ffdea03  vmovaps xmm8, [rsp+0x70]
000073307ffdea09  vmovaps xmm9, [rsp+0x80]
000073307ffdea12  vmovaps xmm10, [rsp+0x90]
000073307ffdea1b  vmovaps xmm11, [rsp+0xA0]
000073307ffdea24  vmovaps xmm12, [rsp+0xB0]
000073307ffdea2d  vmovaps xmm13, [rsp+0xC0]
000073307ffdea36  vmovaps xmm14, [rsp+0xD0]
000073307ffdea3f  vmovaps xmm15, [rsp+0xE0]
000073307ffdea48  add rsp, 0xF0
000073307ffdea4f  pop r11
000073307ffdea51  pop r10
000073307ffdea53  pop r9
000073307ffdea55  pop r8
000073307ffdea57  pop rsi
000073307ffdea58  pop rdi
000073307ffdea59  pop rdx
000073307ffdea5a  pop rcx
000073307ffdea5b  pop rax
000073307ffdea5c  add rsp, 0x08
000073307ffdea60  jmp 0x000073307FFDC272
000073307ffdea65  call 0x000073307FEB52F0
000073307ffdea6a  jmp 0x000073307FFDC27C
000073307ffdea6f  sub rsp, 0x08
000073307ffdea73  push rax
000073307ffdea74  push rcx
000073307ffdea75  push rdx
000073307ffdea76  push rdi
000073307ffdea77  push rsi
000073307ffdea78  push r8
000073307ffdea7a  push r9
000073307ffdea7c  push r10
000073307ffdea7e  push r11
000073307ffdea80  sub rsp, 0xF0
000073307ffdea87  vmovaps [rsp], xmm0
000073307ffdea8c  vmovaps [rsp+0x10], xmm1
000073307ffdea92  vmovaps [rsp+0x20], xmm2
000073307ffdea98  vmovaps [rsp+0x30], xmm3
000073307ffdea9e  vmovaps [rsp+0x40], xmm4
000073307ffdeaa4  vmovaps [rsp+0x50], xmm5
000073307ffdeaaa  vmovaps [rsp+0x60], xmm6
000073307ffdeab0  vmovaps [rsp+0x70], xmm7
000073307ffdeab6  vmovaps [rsp+0x80], xmm8
000073307ffdeabf  vmovaps [rsp+0x90], xmm9
000073307ffdeac8  vmovaps [rsp+0xA0], xmm10
000073307ffdead1  vmovaps [rsp+0xB0], xmm11
000073307ffdeada  vmovaps [rsp+0xC0], xmm12
000073307ffdeae3  vmovaps [rsp+0xD0], xmm13
000073307ffdeaec  vmovaps [rsp+0xE0], xmm14
000073307ffdeaf5  sub rsp, 0x30
000073307ffdeaf9  movaps [rsp], xmm15
000073307ffdeafe  movaps [rsp+0x10], xmm14
000073307ffdeb04  movaps [rsp+0x20], xmm4
000073307ffdeb09  lea rdi, [rsp]
000073307ffdeb0d  mov esi, 0x00
000073307ffdeb12  mov rax, 0x600DE0EC8530
000073307ffdeb1c  call rax
000073307ffdeb1e  movaps xmm15, [rsp]
000073307ffdeb23  add rsp, 0x30
000073307ffdeb27  vmovaps xmm0, [rsp]
000073307ffdeb2c  vmovaps xmm1, [rsp+0x10]
000073307ffdeb32  vmovaps xmm2, [rsp+0x20]
000073307ffdeb38  vmovaps xmm3, [rsp+0x30]
000073307ffdeb3e  vmovaps xmm4, [rsp+0x40]
000073307ffdeb44  vmovaps xmm5, [rsp+0x50]
000073307ffdeb4a  vmovaps xmm6, [rsp+0x60]
000073307ffdeb50  vmovaps xmm7, [rsp+0x70]
000073307ffdeb56  vmovaps xmm8, [rsp+0x80]
000073307ffdeb5f  vmovaps xmm9, [rsp+0x90]
000073307ffdeb68  vmovaps xmm10, [rsp+0xA0]
000073307ffdeb71  vmovaps xmm11, [rsp+0xB0]
000073307ffdeb7a  vmovaps xmm12, [rsp+0xC0]
000073307ffdeb83  vmovaps xmm13, [rsp+0xD0]
000073307ffdeb8c  vmovaps xmm14, [rsp+0xE0]
000073307ffdeb95  add rsp, 0xF0
000073307ffdeb9c  pop r11
000073307ffdeb9e  pop r10
000073307ffdeba0  pop r9
000073307ffdeba2  pop r8
000073307ffdeba4  pop rsi
000073307ffdeba5  pop rdi
000073307ffdeba6  pop rdx
000073307ffdeba7  pop rcx
000073307ffdeba8  pop rax
000073307ffdeba9  add rsp, 0x08
000073307ffdebad  jmp 0x000073307FFDC2AA
000073307ffdebb2  sub rsp, 0x08
000073307ffdebb6  push rax
000073307ffdebb7  push rcx
000073307ffdebb8  push rdx
000073307ffdebb9  push rdi
000073307ffdebba  push rsi
000073307ffdebbb  push r8
000073307ffdebbd  push r9
000073307ffdebbf  push r10
000073307ffdebc1  push r11
000073307ffdebc3  sub rsp, 0xF0
000073307ffdebca  vmovaps [rsp], xmm0
000073307ffdebcf  vmovaps [rsp+0x10], xmm1
000073307ffdebd5  vmovaps [rsp+0x20], xmm2
000073307ffdebdb  vmovaps [rsp+0x30], xmm3
000073307ffdebe1  vmovaps [rsp+0x40], xmm4
000073307ffdebe7  vmovaps [rsp+0x50], xmm5
000073307ffdebed  vmovaps [rsp+0x60], xmm6
000073307ffdebf3  vmovaps [rsp+0x70], xmm7
000073307ffdebf9  vmovaps [rsp+0x80], xmm8
000073307ffdec02  vmovaps [rsp+0x90], xmm9
000073307ffdec0b  vmovaps [rsp+0xA0], xmm10
000073307ffdec14  vmovaps [rsp+0xB0], xmm11
000073307ffdec1d  vmovaps [rsp+0xC0], xmm12
000073307ffdec26  vmovaps [rsp+0xD0], xmm13
000073307ffdec2f  vmovaps [rsp+0xE0], xmm15
000073307ffdec38  sub rsp, 0x30
000073307ffdec3c  movaps [rsp], xmm14
000073307ffdec41  movaps [rsp+0x10], xmm2
000073307ffdec46  movaps [rsp+0x20], xmm1
000073307ffdec4b  lea rdi, [rsp]
000073307ffdec4f  mov esi, 0x00
000073307ffdec54  mov rax, 0x600DE0EC8530
000073307ffdec5e  call rax
000073307ffdec60  movaps xmm14, [rsp]
000073307ffdec65  add rsp, 0x30
000073307ffdec69  vmovaps xmm0, [rsp]
000073307ffdec6e  vmovaps xmm1, [rsp+0x10]
000073307ffdec74  vmovaps xmm2, [rsp+0x20]
000073307ffdec7a  vmovaps xmm3, [rsp+0x30]
000073307ffdec80  vmovaps xmm4, [rsp+0x40]
000073307ffdec86  vmovaps xmm5, [rsp+0x50]
000073307ffdec8c  vmovaps xmm6, [rsp+0x60]
000073307ffdec92  vmovaps xmm7, [rsp+0x70]
000073307ffdec98  vmovaps xmm8, [rsp+0x80]
000073307ffdeca1  vmovaps xmm9, [rsp+0x90]
000073307ffdecaa  vmovaps xmm10, [rsp+0xA0]
000073307ffdecb3  vmovaps xmm11, [rsp+0xB0]
000073307ffdecbc  vmovaps xmm12, [rsp+0xC0]
000073307ffdecc5  vmovaps xmm13, [rsp+0xD0]
000073307ffdecce  vmovaps xmm15, [rsp+0xE0]
000073307ffdecd7  add rsp, 0xF0
000073307ffdecde  pop r11
000073307ffdece0  pop r10
000073307ffdece2  pop r9
000073307ffdece4  pop r8
000073307ffdece6  pop rsi
000073307ffdece7  pop rdi
000073307ffdece8  pop rdx
000073307ffdece9  pop rcx
000073307ffdecea  pop rax
000073307ffdeceb  add rsp, 0x08
000073307ffdecef  jmp 0x000073307FFDC2D0
000073307ffdecf4  sub rsp, 0x08
000073307ffdecf8  push rax
000073307ffdecf9  push rcx
000073307ffdecfa  push rdx
000073307ffdecfb  push rdi
000073307ffdecfc  push rsi
000073307ffdecfd  push r8
000073307ffdecff  push r9
000073307ffded01  push r10
000073307ffded03  push r11
000073307ffded05  sub rsp, 0xF0
000073307ffded0c  vmovaps [rsp], xmm0
000073307ffded11  vmovaps [rsp+0x10], xmm2
000073307ffded17  vmovaps [rsp+0x20], xmm3
000073307ffded1d  vmovaps [rsp+0x30], xmm4
000073307ffded23  vmovaps [rsp+0x40], xmm5
000073307ffded29  vmovaps [rsp+0x50], xmm6
000073307ffded2f  vmovaps [rsp+0x60], xmm7
000073307ffded35  vmovaps [rsp+0x70], xmm8
000073307ffded3b  vmovaps [rsp+0x80], xmm9
000073307ffded44  vmovaps [rsp+0x90], xmm10
000073307ffded4d  vmovaps [rsp+0xA0], xmm11
000073307ffded56  vmovaps [rsp+0xB0], xmm12
000073307ffded5f  vmovaps [rsp+0xC0], xmm13
000073307ffded68  vmovaps [rsp+0xD0], xmm14
000073307ffded71  vmovaps [rsp+0xE0], xmm15
000073307ffded7a  sub rsp, 0x30
000073307ffded7e  movaps [rsp], xmm1
000073307ffded82  movaps [rsp+0x10], xmm4
000073307ffded87  movaps [rsp+0x20], xmm9
000073307ffded8d  lea rdi, [rsp]
000073307ffded91  mov esi, 0x00
000073307ffded96  mov rax, 0x600DE0EC8530
000073307ffdeda0  call rax
000073307ffdeda2  movaps xmm1, [rsp]
000073307ffdeda6  add rsp, 0x30
000073307ffdedaa  vmovaps xmm0, [rsp]
000073307ffdedaf  vmovaps xmm2, [rsp+0x10]
000073307ffdedb5  vmovaps xmm3, [rsp+0x20]
000073307ffdedbb  vmovaps xmm4, [rsp+0x30]
000073307ffdedc1  vmovaps xmm5, [rsp+0x40]
000073307ffdedc7  vmovaps xmm6, [rsp+0x50]
000073307ffdedcd  vmovaps xmm7, [rsp+0x60]
000073307ffdedd3  vmovaps xmm8, [rsp+0x70]
000073307ffdedd9  vmovaps xmm9, [rsp+0x80]
000073307ffdede2  vmovaps xmm10, [rsp+0x90]
000073307ffdedeb  vmovaps xmm11, [rsp+0xA0]
000073307ffdedf4  vmovaps xmm12, [rsp+0xB0]
000073307ffdedfd  vmovaps xmm13, [rsp+0xC0]
000073307ffdee06  vmovaps xmm14, [rsp+0xD0]
000073307ffdee0f  vmovaps xmm15, [rsp+0xE0]
000073307ffdee18  add rsp, 0xF0
000073307ffdee1f  pop r11
000073307ffdee21  pop r10
000073307ffdee23  pop r9
000073307ffdee25  pop r8
000073307ffdee27  pop rsi
000073307ffdee28  pop rdi
000073307ffdee29  pop rdx
000073307ffdee2a  pop rcx
000073307ffdee2b  pop rax
000073307ffdee2c  add rsp, 0x08
000073307ffdee30  jmp 0x000073307FFDC2EE
000073307ffdee35  sub rsp, 0x08
000073307ffdee39  push rax
000073307ffdee3a  push rcx
000073307ffdee3b  push rdx
000073307ffdee3c  push rdi
000073307ffdee3d  push rsi
000073307ffdee3e  push r8
000073307ffdee40  push r9
000073307ffdee42  push r10
000073307ffdee44  push r11
000073307ffdee46  sub rsp, 0xF0
000073307ffdee4d  vmovaps [rsp], xmm0
000073307ffdee52  vmovaps [rsp+0x10], xmm1
000073307ffdee58  vmovaps [rsp+0x20], xmm2
000073307ffdee5e  vmovaps [rsp+0x30], xmm3
000073307ffdee64  vmovaps [rsp+0x40], xmm5
000073307ffdee6a  vmovaps [rsp+0x50], xmm6
000073307ffdee70  vmovaps [rsp+0x60], xmm7
000073307ffdee76  vmovaps [rsp+0x70], xmm8
000073307ffdee7c  vmovaps [rsp+0x80], xmm9
000073307ffdee85  vmovaps [rsp+0x90], xmm10
000073307ffdee8e  vmovaps [rsp+0xA0], xmm11
000073307ffdee97  vmovaps [rsp+0xB0], xmm12
000073307ffdeea0  vmovaps [rsp+0xC0], xmm13
000073307ffdeea9  vmovaps [rsp+0xD0], xmm14
000073307ffdeeb2  vmovaps [rsp+0xE0], xmm15
000073307ffdeebb  sub rsp, 0x30
000073307ffdeebf  movaps [rsp], xmm4
000073307ffdeec3  movaps [rsp+0x10], xmm2
000073307ffdeec8  movaps [rsp+0x20], xmm9
000073307ffdeece  lea rdi, [rsp]
000073307ffdeed2  mov esi, 0x00
000073307ffdeed7  mov rax, 0x600DE0EC8530
000073307ffdeee1  call rax
000073307ffdeee3  movaps xmm4, [rsp]
000073307ffdeee7  add rsp, 0x30
000073307ffdeeeb  vmovaps xmm0, [rsp]
000073307ffdeef0  vmovaps xmm1, [rsp+0x10]
000073307ffdeef6  vmovaps xmm2, [rsp+0x20]
000073307ffdeefc  vmovaps xmm3, [rsp+0x30]
000073307ffdef02  vmovaps xmm5, [rsp+0x40]
000073307ffdef08  vmovaps xmm6, [rsp+0x50]
000073307ffdef0e  vmovaps xmm7, [rsp+0x60]
000073307ffdef14  vmovaps xmm8, [rsp+0x70]
000073307ffdef1a  vmovaps xmm9, [rsp+0x80]
000073307ffdef23  vmovaps xmm10, [rsp+0x90]
000073307ffdef2c  vmovaps xmm11, [rsp+0xA0]
000073307ffdef35  vmovaps xmm12, [rsp+0xB0]
000073307ffdef3e  vmovaps xmm13, [rsp+0xC0]
000073307ffdef47  vmovaps xmm14, [rsp+0xD0]
000073307ffdef50  vmovaps xmm15, [rsp+0xE0]
000073307ffdef59  add rsp, 0xF0
000073307ffdef60  pop r11
000073307ffdef62  pop r10
000073307ffdef64  pop r9
000073307ffdef66  pop r8
000073307ffdef68  pop rsi
000073307ffdef69  pop rdi
000073307ffdef6a  pop rdx
000073307ffdef6b  pop rcx
000073307ffdef6c  pop rax
000073307ffdef6d  add rsp, 0x08
000073307ffdef71  jmp 0x000073307FFDC31E
000073307ffdef76  sub rsp, 0x08
000073307ffdef7a  push rax
000073307ffdef7b  push rcx
000073307ffdef7c  push rdx
000073307ffdef7d  push rdi
000073307ffdef7e  push rsi
000073307ffdef7f  push r8
000073307ffdef81  push r9
000073307ffdef83  push r10
000073307ffdef85  push r11
000073307ffdef87  sub rsp, 0xF0
000073307ffdef8e  vmovaps [rsp], xmm0
000073307ffdef93  vmovaps [rsp+0x10], xmm1
000073307ffdef99  vmovaps [rsp+0x20], xmm2
000073307ffdef9f  vmovaps [rsp+0x30], xmm3
000073307ffdefa5  vmovaps [rsp+0x40], xmm4
000073307ffdefab  vmovaps [rsp+0x50], xmm5
000073307ffdefb1  vmovaps [rsp+0x60], xmm6
000073307ffdefb7  vmovaps [rsp+0x70], xmm7
000073307ffdefbd  vmovaps [rsp+0x80], xmm8
000073307ffdefc6  vmovaps [rsp+0x90], xmm10
000073307ffdefcf  vmovaps [rsp+0xA0], xmm11
000073307ffdefd8  vmovaps [rsp+0xB0], xmm12
000073307ffdefe1  vmovaps [rsp+0xC0], xmm13
000073307ffdefea  vmovaps [rsp+0xD0], xmm14
000073307ffdeff3  vmovaps [rsp+0xE0], xmm15
000073307ffdeffc  sub rsp, 0x30
000073307ffdf000  movaps [rsp], xmm9
000073307ffdf005  movaps [rsp+0x10], xmm2
000073307ffdf00a  movaps [rsp+0x20], xmm1
000073307ffdf00f  lea rdi, [rsp]
000073307ffdf013  mov esi, 0x00
000073307ffdf018  mov rax, 0x600DE0EC8530
000073307ffdf022  call rax
000073307ffdf024  movaps xmm9, [rsp]
000073307ffdf029  add rsp, 0x30
000073307ffdf02d  vmovaps xmm0, [rsp]
000073307ffdf032  vmovaps xmm1, [rsp+0x10]
000073307ffdf038  vmovaps xmm2, [rsp+0x20]
000073307ffdf03e  vmovaps xmm3, [rsp+0x30]
000073307ffdf044  vmovaps xmm4, [rsp+0x40]
000073307ffdf04a  vmovaps xmm5, [rsp+0x50]
000073307ffdf050  vmovaps xmm6, [rsp+0x60]
000073307ffdf056  vmovaps xmm7, [rsp+0x70]
000073307ffdf05c  vmovaps xmm8, [rsp+0x80]
000073307ffdf065  vmovaps xmm10, [rsp+0x90]
000073307ffdf06e  vmovaps xmm11, [rsp+0xA0]
000073307ffdf077  vmovaps xmm12, [rsp+0xB0]
000073307ffdf080  vmovaps xmm13, [rsp+0xC0]
000073307ffdf089  vmovaps xmm14, [rsp+0xD0]
000073307ffdf092  vmovaps xmm15, [rsp+0xE0]
000073307ffdf09b  add rsp, 0xF0
000073307ffdf0a2  pop r11
000073307ffdf0a4  pop r10
000073307ffdf0a6  pop r9
000073307ffdf0a8  pop r8
000073307ffdf0aa  pop rsi
000073307ffdf0ab  pop rdi
000073307ffdf0ac  pop rdx
000073307ffdf0ad  pop rcx
000073307ffdf0ae  pop rax
000073307ffdf0af  add rsp, 0x08
000073307ffdf0b3  jmp 0x000073307FFDC354
000073307ffdf0b8  sub rsp, 0x08
000073307ffdf0bc  push rax
000073307ffdf0bd  push rcx
000073307ffdf0be  push rdx
000073307ffdf0bf  push rdi
000073307ffdf0c0  push rsi
000073307ffdf0c1  push r8
000073307ffdf0c3  push r9
000073307ffdf0c5  push r10
000073307ffdf0c7  push r11
000073307ffdf0c9  sub rsp, 0xF0
000073307ffdf0d0  vmovaps [rsp], xmm0
000073307ffdf0d5  vmovaps [rsp+0x10], xmm2
000073307ffdf0db  vmovaps [rsp+0x20], xmm3
000073307ffdf0e1  vmovaps [rsp+0x30], xmm4
000073307ffdf0e7  vmovaps [rsp+0x40], xmm5
000073307ffdf0ed  vmovaps [rsp+0x50], xmm6
000073307ffdf0f3  vmovaps [rsp+0x60], xmm7
000073307ffdf0f9  vmovaps [rsp+0x70], xmm8
000073307ffdf0ff  vmovaps [rsp+0x80], xmm9
000073307ffdf108  vmovaps [rsp+0x90], xmm10
000073307ffdf111  vmovaps [rsp+0xA0], xmm11
000073307ffdf11a  vmovaps [rsp+0xB0], xmm12
000073307ffdf123  vmovaps [rsp+0xC0], xmm13
000073307ffdf12c  vmovaps [rsp+0xD0], xmm14
000073307ffdf135  vmovaps [rsp+0xE0], xmm15
000073307ffdf13e  sub rsp, 0x30
000073307ffdf142  movaps [rsp], xmm1
000073307ffdf146  movaps [rsp+0x10], xmm15
000073307ffdf14c  movaps [rsp+0x20], xmm6
000073307ffdf151  lea rdi, [rsp]
000073307ffdf155  mov esi, 0x00
000073307ffdf15a  mov rax, 0x600DE0EC8530
000073307ffdf164  call rax
000073307ffdf166  movaps xmm1, [rsp]
000073307ffdf16a  add rsp, 0x30
000073307ffdf16e  vmovaps xmm0, [rsp]
000073307ffdf173  vmovaps xmm2, [rsp+0x10]
000073307ffdf179  vmovaps xmm3, [rsp+0x20]
000073307ffdf17f  vmovaps xmm4, [rsp+0x30]
000073307ffdf185  vmovaps xmm5, [rsp+0x40]
000073307ffdf18b  vmovaps xmm6, [rsp+0x50]
000073307ffdf191  vmovaps xmm7, [rsp+0x60]
000073307ffdf197  vmovaps xmm8, [rsp+0x70]
000073307ffdf19d  vmovaps xmm9, [rsp+0x80]
000073307ffdf1a6  vmovaps xmm10, [rsp+0x90]
000073307ffdf1af  vmovaps xmm11, [rsp+0xA0]
000073307ffdf1b8  vmovaps xmm12, [rsp+0xB0]
000073307ffdf1c1  vmovaps xmm13, [rsp+0xC0]
000073307ffdf1ca  vmovaps xmm14, [rsp+0xD0]
000073307ffdf1d3  vmovaps xmm15, [rsp+0xE0]
000073307ffdf1dc  add rsp, 0xF0
000073307ffdf1e3  pop r11
000073307ffdf1e5  pop r10
000073307ffdf1e7  pop r9
000073307ffdf1e9  pop r8
000073307ffdf1eb  pop rsi
000073307ffdf1ec  pop rdi
000073307ffdf1ed  pop rdx
000073307ffdf1ee  pop rcx
000073307ffdf1ef  pop rax
000073307ffdf1f0  add rsp, 0x08
000073307ffdf1f4  jmp 0x000073307FFDC375
000073307ffdf1f9  sub rsp, 0x08
000073307ffdf1fd  push rax
000073307ffdf1fe  push rcx
000073307ffdf1ff  push rdx
000073307ffdf200  push rdi
000073307ffdf201  push rsi
000073307ffdf202  push r8
000073307ffdf204  push r9
000073307ffdf206  push r10
000073307ffdf208  push r11
000073307ffdf20a  sub rsp, 0xF0
000073307ffdf211  vmovaps [rsp], xmm0
000073307ffdf216  vmovaps [rsp+0x10], xmm1
000073307ffdf21c  vmovaps [rsp+0x20], xmm2
000073307ffdf222  vmovaps [rsp+0x30], xmm3
000073307ffdf228  vmovaps [rsp+0x40], xmm4
000073307ffdf22e  vmovaps [rsp+0x50], xmm5
000073307ffdf234  vmovaps [rsp+0x60], xmm6
000073307ffdf23a  vmovaps [rsp+0x70], xmm7
000073307ffdf240  vmovaps [rsp+0x80], xmm8
000073307ffdf249  vmovaps [rsp+0x90], xmm9
000073307ffdf252  vmovaps [rsp+0xA0], xmm10
000073307ffdf25b  vmovaps [rsp+0xB0], xmm11
000073307ffdf264  vmovaps [rsp+0xC0], xmm12
000073307ffdf26d  vmovaps [rsp+0xD0], xmm13
000073307ffdf276  vmovaps [rsp+0xE0], xmm14
000073307ffdf27f  sub rsp, 0x30
000073307ffdf283  movaps [rsp], xmm15
000073307ffdf288  movaps [rsp+0x10], xmm5
000073307ffdf28d  movaps [rsp+0x20], xmm3
000073307ffdf292  lea rdi, [rsp]
000073307ffdf296  mov esi, 0x00
000073307ffdf29b  mov rax, 0x600DE0EC8530
000073307ffdf2a5  call rax
000073307ffdf2a7  movaps xmm15, [rsp]
000073307ffdf2ac  add rsp, 0x30
000073307ffdf2b0  vmovaps xmm0, [rsp]
000073307ffdf2b5  vmovaps xmm1, [rsp+0x10]
000073307ffdf2bb  vmovaps xmm2, [rsp+0x20]
000073307ffdf2c1  vmovaps xmm3, [rsp+0x30]
000073307ffdf2c7  vmovaps xmm4, [rsp+0x40]
000073307ffdf2cd  vmovaps xmm5, [rsp+0x50]
000073307ffdf2d3  vmovaps xmm6, [rsp+0x60]
000073307ffdf2d9  vmovaps xmm7, [rsp+0x70]
000073307ffdf2df  vmovaps xmm8, [rsp+0x80]
000073307ffdf2e8  vmovaps xmm9, [rsp+0x90]
000073307ffdf2f1  vmovaps xmm10, [rsp+0xA0]
000073307ffdf2fa  vmovaps xmm11, [rsp+0xB0]
000073307ffdf303  vmovaps xmm12, [rsp+0xC0]
000073307ffdf30c  vmovaps xmm13, [rsp+0xD0]
000073307ffdf315  vmovaps xmm14, [rsp+0xE0]
000073307ffdf31e  add rsp, 0xF0
000073307ffdf325  pop r11
000073307ffdf327  pop r10
000073307ffdf329  pop r9
000073307ffdf32b  pop r8
000073307ffdf32d  pop rsi
000073307ffdf32e  pop rdi
000073307ffdf32f  pop rdx
000073307ffdf330  pop rcx
000073307ffdf331  pop rax
000073307ffdf332  add rsp, 0x08
000073307ffdf336  jmp 0x000073307FFDC38F
000073307ffdf33b  sub rsp, 0x08
000073307ffdf33f  push rax
000073307ffdf340  push rcx
000073307ffdf341  push rdx
000073307ffdf342  push rdi
000073307ffdf343  push rsi
000073307ffdf344  push r8
000073307ffdf346  push r9
000073307ffdf348  push r10
000073307ffdf34a  push r11
000073307ffdf34c  sub rsp, 0xF0
000073307ffdf353  vmovaps [rsp], xmm0
000073307ffdf358  vmovaps [rsp+0x10], xmm1
000073307ffdf35e  vmovaps [rsp+0x20], xmm2
000073307ffdf364  vmovaps [rsp+0x30], xmm3
000073307ffdf36a  vmovaps [rsp+0x40], xmm4
000073307ffdf370  vmovaps [rsp+0x50], xmm6
000073307ffdf376  vmovaps [rsp+0x60], xmm7
000073307ffdf37c  vmovaps [rsp+0x70], xmm8
000073307ffdf382  vmovaps [rsp+0x80], xmm9
000073307ffdf38b  vmovaps [rsp+0x90], xmm10
000073307ffdf394  vmovaps [rsp+0xA0], xmm11
000073307ffdf39d  vmovaps [rsp+0xB0], xmm12
000073307ffdf3a6  vmovaps [rsp+0xC0], xmm13
000073307ffdf3af  vmovaps [rsp+0xD0], xmm14
000073307ffdf3b8  vmovaps [rsp+0xE0], xmm15
000073307ffdf3c1  sub rsp, 0x30
000073307ffdf3c5  movaps [rsp], xmm5
000073307ffdf3c9  movaps [rsp+0x10], xmm8
000073307ffdf3cf  movaps [rsp+0x20], xmm6
000073307ffdf3d4  lea rdi, [rsp]
000073307ffdf3d8  mov esi, 0x00
000073307ffdf3dd  mov rax, 0x600DE0EC8530
000073307ffdf3e7  call rax
000073307ffdf3e9  movaps xmm5, [rsp]
000073307ffdf3ed  add rsp, 0x30
000073307ffdf3f1  vmovaps xmm0, [rsp]
000073307ffdf3f6  vmovaps xmm1, [rsp+0x10]
000073307ffdf3fc  vmovaps xmm2, [rsp+0x20]
000073307ffdf402  vmovaps xmm3, [rsp+0x30]
000073307ffdf408  vmovaps xmm4, [rsp+0x40]
000073307ffdf40e  vmovaps xmm6, [rsp+0x50]
000073307ffdf414  vmovaps xmm7, [rsp+0x60]
000073307ffdf41a  vmovaps xmm8, [rsp+0x70]
000073307ffdf420  vmovaps xmm9, [rsp+0x80]
000073307ffdf429  vmovaps xmm10, [rsp+0x90]
000073307ffdf432  vmovaps xmm11, [rsp+0xA0]
000073307ffdf43b  vmovaps xmm12, [rsp+0xB0]
000073307ffdf444  vmovaps xmm13, [rsp+0xC0]
000073307ffdf44d  vmovaps xmm14, [rsp+0xD0]
000073307ffdf456  vmovaps xmm15, [rsp+0xE0]
000073307ffdf45f  add rsp, 0xF0
000073307ffdf466  pop r11
000073307ffdf468  pop r10
000073307ffdf46a  pop r9
000073307ffdf46c  pop r8
000073307ffdf46e  pop rsi
000073307ffdf46f  pop rdi
000073307ffdf470  pop rdx
000073307ffdf471  pop rcx
000073307ffdf472  pop rax
000073307ffdf473  add rsp, 0x08
000073307ffdf477  jmp 0x000073307FFDC3B3
000073307ffdf47c  sub rsp, 0x08
000073307ffdf480  push rax
000073307ffdf481  push rcx
000073307ffdf482  push rdx
000073307ffdf483  push rdi
000073307ffdf484  push rsi
000073307ffdf485  push r8
000073307ffdf487  push r9
000073307ffdf489  push r10
000073307ffdf48b  push r11
000073307ffdf48d  sub rsp, 0xF0
000073307ffdf494  vmovaps [rsp], xmm0
000073307ffdf499  vmovaps [rsp+0x10], xmm1
000073307ffdf49f  vmovaps [rsp+0x20], xmm2
000073307ffdf4a5  vmovaps [rsp+0x30], xmm3
000073307ffdf4ab  vmovaps [rsp+0x40], xmm4
000073307ffdf4b1  vmovaps [rsp+0x50], xmm5
000073307ffdf4b7  vmovaps [rsp+0x60], xmm7
000073307ffdf4bd  vmovaps [rsp+0x70], xmm8
000073307ffdf4c3  vmovaps [rsp+0x80], xmm9
000073307ffdf4cc  vmovaps [rsp+0x90], xmm10
000073307ffdf4d5  vmovaps [rsp+0xA0], xmm11
000073307ffdf4de  vmovaps [rsp+0xB0], xmm12
000073307ffdf4e7  vmovaps [rsp+0xC0], xmm13
000073307ffdf4f0  vmovaps [rsp+0xD0], xmm14
000073307ffdf4f9  vmovaps [rsp+0xE0], xmm15
000073307ffdf502  sub rsp, 0x30
000073307ffdf506  movaps [rsp], xmm6
000073307ffdf50a  movaps [rsp+0x10], xmm10
000073307ffdf510  movaps [rsp+0x20], xmm8
000073307ffdf516  lea rdi, [rsp]
000073307ffdf51a  mov esi, 0x00
000073307ffdf51f  mov rax, 0x600DE0EC8530
000073307ffdf529  call rax
000073307ffdf52b  movaps xmm6, [rsp]
000073307ffdf52f  add rsp, 0x30
000073307ffdf533  vmovaps xmm0, [rsp]
000073307ffdf538  vmovaps xmm1, [rsp+0x10]
000073307ffdf53e  vmovaps xmm2, [rsp+0x20]
000073307ffdf544  vmovaps xmm3, [rsp+0x30]
000073307ffdf54a  vmovaps xmm4, [rsp+0x40]
000073307ffdf550  vmovaps xmm5, [rsp+0x50]
000073307ffdf556  vmovaps xmm7, [rsp+0x60]
000073307ffdf55c  vmovaps xmm8, [rsp+0x70]
000073307ffdf562  vmovaps xmm9, [rsp+0x80]
000073307ffdf56b  vmovaps xmm10, [rsp+0x90]
000073307ffdf574  vmovaps xmm11, [rsp+0xA0]
000073307ffdf57d  vmovaps xmm12, [rsp+0xB0]
000073307ffdf586  vmovaps xmm13, [rsp+0xC0]
000073307ffdf58f  vmovaps xmm14, [rsp+0xD0]
000073307ffdf598  vmovaps xmm15, [rsp+0xE0]
000073307ffdf5a1  add rsp, 0xF0
000073307ffdf5a8  pop r11
000073307ffdf5aa  pop r10
000073307ffdf5ac  pop r9
000073307ffdf5ae  pop r8
000073307ffdf5b0  pop rsi
000073307ffdf5b1  pop rdi
000073307ffdf5b2  pop rdx
000073307ffdf5b3  pop rcx
000073307ffdf5b4  pop rax
000073307ffdf5b5  add rsp, 0x08
000073307ffdf5b9  jmp 0x000073307FFDC3D8
000073307ffdf5be  sub rsp, 0x08
000073307ffdf5c2  push rax
000073307ffdf5c3  push rcx
000073307ffdf5c4  push rdx
000073307ffdf5c5  push rdi
000073307ffdf5c6  push rsi
000073307ffdf5c7  push r8
000073307ffdf5c9  push r9
000073307ffdf5cb  push r10
000073307ffdf5cd  push r11
000073307ffdf5cf  sub rsp, 0xF0
000073307ffdf5d6  vmovaps [rsp], xmm0
000073307ffdf5db  vmovaps [rsp+0x10], xmm1
000073307ffdf5e1  vmovaps [rsp+0x20], xmm2
000073307ffdf5e7  vmovaps [rsp+0x30], xmm3
000073307ffdf5ed  vmovaps [rsp+0x40], xmm4
000073307ffdf5f3  vmovaps [rsp+0x50], xmm5
000073307ffdf5f9  vmovaps [rsp+0x60], xmm6
000073307ffdf5ff  vmovaps [rsp+0x70], xmm7
000073307ffdf605  vmovaps [rsp+0x80], xmm8
000073307ffdf60e  vmovaps [rsp+0x90], xmm9
000073307ffdf617  vmovaps [rsp+0xA0], xmm11
000073307ffdf620  vmovaps [rsp+0xB0], xmm12
000073307ffdf629  vmovaps [rsp+0xC0], xmm13
000073307ffdf632  vmovaps [rsp+0xD0], xmm14
000073307ffdf63b  vmovaps [rsp+0xE0], xmm15
000073307ffdf644  sub rsp, 0x30
000073307ffdf648  movaps [rsp], xmm10
000073307ffdf64d  movaps [rsp+0x10], xmm8
000073307ffdf653  movaps [rsp+0x20], xmm14
000073307ffdf659  lea rdi, [rsp]
000073307ffdf65d  mov esi, 0x00
000073307ffdf662  mov rax, 0x600DE0EC8530
000073307ffdf66c  call rax
000073307ffdf66e  movaps xmm10, [rsp]
000073307ffdf673  add rsp, 0x30
000073307ffdf677  vmovaps xmm0, [rsp]
000073307ffdf67c  vmovaps xmm1, [rsp+0x10]
000073307ffdf682  vmovaps xmm2, [rsp+0x20]
000073307ffdf688  vmovaps xmm3, [rsp+0x30]
000073307ffdf68e  vmovaps xmm4, [rsp+0x40]
000073307ffdf694  vmovaps xmm5, [rsp+0x50]
000073307ffdf69a  vmovaps xmm6, [rsp+0x60]
000073307ffdf6a0  vmovaps xmm7, [rsp+0x70]
000073307ffdf6a6  vmovaps xmm8, [rsp+0x80]
000073307ffdf6af  vmovaps xmm9, [rsp+0x90]
000073307ffdf6b8  vmovaps xmm11, [rsp+0xA0]
000073307ffdf6c1  vmovaps xmm12, [rsp+0xB0]
000073307ffdf6ca  vmovaps xmm13, [rsp+0xC0]
000073307ffdf6d3  vmovaps xmm14, [rsp+0xD0]
000073307ffdf6dc  vmovaps xmm15, [rsp+0xE0]
000073307ffdf6e5  add rsp, 0xF0
000073307ffdf6ec  pop r11
000073307ffdf6ee  pop r10
000073307ffdf6f0  pop r9
000073307ffdf6f2  pop r8
000073307ffdf6f4  pop rsi
000073307ffdf6f5  pop rdi
000073307ffdf6f6  pop rdx
000073307ffdf6f7  pop rcx
000073307ffdf6f8  pop rax
000073307ffdf6f9  add rsp, 0x08
000073307ffdf6fd  jmp 0x000073307FFDC3F8
000073307ffdf702  sub rsp, 0x08
000073307ffdf706  push rax
000073307ffdf707  push rcx
000073307ffdf708  push rdx
000073307ffdf709  push rdi
000073307ffdf70a  push rsi
000073307ffdf70b  push r8
000073307ffdf70d  push r9
000073307ffdf70f  push r10
000073307ffdf711  push r11
000073307ffdf713  sub rsp, 0xF0
000073307ffdf71a  vmovaps [rsp], xmm0
000073307ffdf71f  vmovaps [rsp+0x10], xmm1
000073307ffdf725  vmovaps [rsp+0x20], xmm2
000073307ffdf72b  vmovaps [rsp+0x30], xmm3
000073307ffdf731  vmovaps [rsp+0x40], xmm4
000073307ffdf737  vmovaps [rsp+0x50], xmm5
000073307ffdf73d  vmovaps [rsp+0x60], xmm6
000073307ffdf743  vmovaps [rsp+0x70], xmm7
000073307ffdf749  vmovaps [rsp+0x80], xmm8
000073307ffdf752  vmovaps [rsp+0x90], xmm9
000073307ffdf75b  vmovaps [rsp+0xA0], xmm10
000073307ffdf764  vmovaps [rsp+0xB0], xmm11
000073307ffdf76d  vmovaps [rsp+0xC0], xmm12
000073307ffdf776  vmovaps [rsp+0xD0], xmm13
000073307ffdf77f  vmovaps [rsp+0xE0], xmm15
000073307ffdf788  sub rsp, 0x30
000073307ffdf78c  movaps [rsp], xmm14
000073307ffdf791  movaps [rsp+0x10], xmm8
000073307ffdf797  movaps [rsp+0x20], xmm4
000073307ffdf79c  lea rdi, [rsp]
000073307ffdf7a0  mov esi, 0x00
000073307ffdf7a5  mov rax, 0x600DE0EC8530
000073307ffdf7af  call rax
000073307ffdf7b1  movaps xmm14, [rsp]
000073307ffdf7b6  add rsp, 0x30
000073307ffdf7ba  vmovaps xmm0, [rsp]
000073307ffdf7bf  vmovaps xmm1, [rsp+0x10]
000073307ffdf7c5  vmovaps xmm2, [rsp+0x20]
000073307ffdf7cb  vmovaps xmm3, [rsp+0x30]
000073307ffdf7d1  vmovaps xmm4, [rsp+0x40]
000073307ffdf7d7  vmovaps xmm5, [rsp+0x50]
000073307ffdf7dd  vmovaps xmm6, [rsp+0x60]
000073307ffdf7e3  vmovaps xmm7, [rsp+0x70]
000073307ffdf7e9  vmovaps xmm8, [rsp+0x80]
000073307ffdf7f2  vmovaps xmm9, [rsp+0x90]
000073307ffdf7fb  vmovaps xmm10, [rsp+0xA0]
000073307ffdf804  vmovaps xmm11, [rsp+0xB0]
000073307ffdf80d  vmovaps xmm12, [rsp+0xC0]
000073307ffdf816  vmovaps xmm13, [rsp+0xD0]
000073307ffdf81f  vmovaps xmm15, [rsp+0xE0]
000073307ffdf828  add rsp, 0xF0
000073307ffdf82f  pop r11
000073307ffdf831  pop r10
000073307ffdf833  pop r9
000073307ffdf835  pop r8
000073307ffdf837  pop rsi
000073307ffdf838  pop rdi
000073307ffdf839  pop rdx
000073307ffdf83a  pop rcx
000073307ffdf83b  pop rax
000073307ffdf83c  add rsp, 0x08
000073307ffdf840  jmp 0x000073307FFDC418
000073307ffdf845  sub rsp, 0x08
000073307ffdf849  push rax
000073307ffdf84a  push rcx
000073307ffdf84b  push rdx
000073307ffdf84c  push rdi
000073307ffdf84d  push rsi
000073307ffdf84e  push r8
000073307ffdf850  push r9
000073307ffdf852  push r10
000073307ffdf854  push r11
000073307ffdf856  sub rsp, 0xF0
000073307ffdf85d  vmovaps [rsp], xmm0
000073307ffdf862  vmovaps [rsp+0x10], xmm1
000073307ffdf868  vmovaps [rsp+0x20], xmm2
000073307ffdf86e  vmovaps [rsp+0x30], xmm3
000073307ffdf874  vmovaps [rsp+0x40], xmm5
000073307ffdf87a  vmovaps [rsp+0x50], xmm6
000073307ffdf880  vmovaps [rsp+0x60], xmm7
000073307ffdf886  vmovaps [rsp+0x70], xmm8
000073307ffdf88c  vmovaps [rsp+0x80], xmm9
000073307ffdf895  vmovaps [rsp+0x90], xmm10
000073307ffdf89e  vmovaps [rsp+0xA0], xmm11
000073307ffdf8a7  vmovaps [rsp+0xB0], xmm12
000073307ffdf8b0  vmovaps [rsp+0xC0], xmm13
000073307ffdf8b9  vmovaps [rsp+0xD0], xmm14
000073307ffdf8c2  vmovaps [rsp+0xE0], xmm15
000073307ffdf8cb  sub rsp, 0x30
000073307ffdf8cf  movaps [rsp], xmm4
000073307ffdf8d3  movaps [rsp+0x10], xmm13
000073307ffdf8d9  movaps [rsp+0x20], xmm8
000073307ffdf8df  lea rdi, [rsp]
000073307ffdf8e3  mov esi, 0x00
000073307ffdf8e8  mov rax, 0x600DE0EC8530
000073307ffdf8f2  call rax
000073307ffdf8f4  movaps xmm4, [rsp]
000073307ffdf8f8  add rsp, 0x30
000073307ffdf8fc  vmovaps xmm0, [rsp]
000073307ffdf901  vmovaps xmm1, [rsp+0x10]
000073307ffdf907  vmovaps xmm2, [rsp+0x20]
000073307ffdf90d  vmovaps xmm3, [rsp+0x30]
000073307ffdf913  vmovaps xmm5, [rsp+0x40]
000073307ffdf919  vmovaps xmm6, [rsp+0x50]
000073307ffdf91f  vmovaps xmm7, [rsp+0x60]
000073307ffdf925  vmovaps xmm8, [rsp+0x70]
000073307ffdf92b  vmovaps xmm9, [rsp+0x80]
000073307ffdf934  vmovaps xmm10, [rsp+0x90]
000073307ffdf93d  vmovaps xmm11, [rsp+0xA0]
000073307ffdf946  vmovaps xmm12, [rsp+0xB0]
000073307ffdf94f  vmovaps xmm13, [rsp+0xC0]
000073307ffdf958  vmovaps xmm14, [rsp+0xD0]
000073307ffdf961  vmovaps xmm15, [rsp+0xE0]
000073307ffdf96a  add rsp, 0xF0
000073307ffdf971  pop r11
000073307ffdf973  pop r10
000073307ffdf975  pop r9
000073307ffdf977  pop r8
000073307ffdf979  pop rsi
000073307ffdf97a  pop rdi
000073307ffdf97b  pop rdx
000073307ffdf97c  pop rcx
000073307ffdf97d  pop rax
000073307ffdf97e  add rsp, 0x08
000073307ffdf982  jmp 0x000073307FFDC43D
000073307ffdf987  sub rsp, 0x08
000073307ffdf98b  push rax
000073307ffdf98c  push rcx
000073307ffdf98d  push rdx
000073307ffdf98e  push rdi
000073307ffdf98f  push rsi
000073307ffdf990  push r8
000073307ffdf992  push r9
000073307ffdf994  push r10
000073307ffdf996  push r11
000073307ffdf998  sub rsp, 0xF0
000073307ffdf99f  vmovaps [rsp], xmm0
000073307ffdf9a4  vmovaps [rsp+0x10], xmm1
000073307ffdf9aa  vmovaps [rsp+0x20], xmm2
000073307ffdf9b0  vmovaps [rsp+0x30], xmm3
000073307ffdf9b6  vmovaps [rsp+0x40], xmm4
000073307ffdf9bc  vmovaps [rsp+0x50], xmm5
000073307ffdf9c2  vmovaps [rsp+0x60], xmm6
000073307ffdf9c8  vmovaps [rsp+0x70], xmm7
000073307ffdf9ce  vmovaps [rsp+0x80], xmm8
000073307ffdf9d7  vmovaps [rsp+0x90], xmm9
000073307ffdf9e0  vmovaps [rsp+0xA0], xmm10
000073307ffdf9e9  vmovaps [rsp+0xB0], xmm11
000073307ffdf9f2  vmovaps [rsp+0xC0], xmm12
000073307ffdf9fb  vmovaps [rsp+0xD0], xmm14
000073307ffdfa04  vmovaps [rsp+0xE0], xmm15
000073307ffdfa0d  sub rsp, 0x30
000073307ffdfa11  movaps [rsp], xmm13
000073307ffdfa16  movaps [rsp+0x10], xmm15
000073307ffdfa1c  movaps [rsp+0x20], xmm9
000073307ffdfa22  lea rdi, [rsp]
000073307ffdfa26  mov esi, 0x00
000073307ffdfa2b  mov rax, 0x600DE0EC8530
000073307ffdfa35  call rax
000073307ffdfa37  movaps xmm13, [rsp]
000073307ffdfa3c  add rsp, 0x30
000073307ffdfa40  vmovaps xmm0, [rsp]
000073307ffdfa45  vmovaps xmm1, [rsp+0x10]
000073307ffdfa4b  vmovaps xmm2, [rsp+0x20]
000073307ffdfa51  vmovaps xmm3, [rsp+0x30]
000073307ffdfa57  vmovaps xmm4, [rsp+0x40]
000073307ffdfa5d  vmovaps xmm5, [rsp+0x50]
000073307ffdfa63  vmovaps xmm6, [rsp+0x60]
000073307ffdfa69  vmovaps xmm7, [rsp+0x70]
000073307ffdfa6f  vmovaps xmm8, [rsp+0x80]
000073307ffdfa78  vmovaps xmm9, [rsp+0x90]
000073307ffdfa81  vmovaps xmm10, [rsp+0xA0]
000073307ffdfa8a  vmovaps xmm11, [rsp+0xB0]
000073307ffdfa93  vmovaps xmm12, [rsp+0xC0]
000073307ffdfa9c  vmovaps xmm14, [rsp+0xD0]
000073307ffdfaa5  vmovaps xmm15, [rsp+0xE0]
000073307ffdfaae  add rsp, 0xF0
000073307ffdfab5  pop r11
000073307ffdfab7  pop r10
000073307ffdfab9  pop r9
000073307ffdfabb  pop r8
000073307ffdfabd  pop rsi
000073307ffdfabe  pop rdi
000073307ffdfabf  pop rdx
000073307ffdfac0  pop rcx
000073307ffdfac1  pop rax
000073307ffdfac2  add rsp, 0x08
000073307ffdfac6  jmp 0x000073307FFDC458
000073307ffdfacb  sub rsp, 0x08
000073307ffdfacf  push rax
000073307ffdfad0  push rcx
000073307ffdfad1  push rdx
000073307ffdfad2  push rdi
000073307ffdfad3  push rsi
000073307ffdfad4  push r8
000073307ffdfad6  push r9
000073307ffdfad8  push r10
000073307ffdfada  push r11
000073307ffdfadc  sub rsp, 0xF0
000073307ffdfae3  vmovaps [rsp], xmm0
000073307ffdfae8  vmovaps [rsp+0x10], xmm1
000073307ffdfaee  vmovaps [rsp+0x20], xmm2
000073307ffdfaf4  vmovaps [rsp+0x30], xmm3
000073307ffdfafa  vmovaps [rsp+0x40], xmm4
000073307ffdfb00  vmovaps [rsp+0x50], xmm5
000073307ffdfb06  vmovaps [rsp+0x60], xmm6
000073307ffdfb0c  vmovaps [rsp+0x70], xmm7
000073307ffdfb12  vmovaps [rsp+0x80], xmm8
000073307ffdfb1b  vmovaps [rsp+0x90], xmm9
000073307ffdfb24  vmovaps [rsp+0xA0], xmm10
000073307ffdfb2d  vmovaps [rsp+0xB0], xmm11
000073307ffdfb36  vmovaps [rsp+0xC0], xmm12
000073307ffdfb3f  vmovaps [rsp+0xD0], xmm13
000073307ffdfb48  vmovaps [rsp+0xE0], xmm14
000073307ffdfb51  sub rsp, 0x30
000073307ffdfb55  movaps [rsp], xmm15
000073307ffdfb5a  movaps [rsp+0x10], xmm1
000073307ffdfb5f  movaps [rsp+0x20], xmm5
000073307ffdfb64  lea rdi, [rsp]
000073307ffdfb68  mov esi, 0x00
000073307ffdfb6d  mov rax, 0x600DE0EC8530
000073307ffdfb77  call rax
000073307ffdfb79  movaps xmm15, [rsp]
000073307ffdfb7e  add rsp, 0x30
000073307ffdfb82  vmovaps xmm0, [rsp]
000073307ffdfb87  vmovaps xmm1, [rsp+0x10]
000073307ffdfb8d  vmovaps xmm2, [rsp+0x20]
000073307ffdfb93  vmovaps xmm3, [rsp+0x30]
000073307ffdfb99  vmovaps xmm4, [rsp+0x40]
000073307ffdfb9f  vmovaps xmm5, [rsp+0x50]
000073307ffdfba5  vmovaps xmm6, [rsp+0x60]
000073307ffdfbab  vmovaps xmm7, [rsp+0x70]
000073307ffdfbb1  vmovaps xmm8, [rsp+0x80]
000073307ffdfbba  vmovaps xmm9, [rsp+0x90]
000073307ffdfbc3  vmovaps xmm10, [rsp+0xA0]
000073307ffdfbcc  vmovaps xmm11, [rsp+0xB0]
000073307ffdfbd5  vmovaps xmm12, [rsp+0xC0]
000073307ffdfbde  vmovaps xmm13, [rsp+0xD0]
000073307ffdfbe7  vmovaps xmm14, [rsp+0xE0]
000073307ffdfbf0  add rsp, 0xF0
000073307ffdfbf7  pop r11
000073307ffdfbf9  pop r10
000073307ffdfbfb  pop r9
000073307ffdfbfd  pop r8
000073307ffdfbff  pop rsi
000073307ffdfc00  pop rdi
000073307ffdfc01  pop rdx
000073307ffdfc02  pop rcx
000073307ffdfc03  pop rax
000073307ffdfc04  add rsp, 0x08
000073307ffdfc08  jmp 0x000073307FFDC473
000073307ffdfc0d  call 0x000073307FEB52F0
000073307ffdfc12  jmp 0x000073307FFDC4CE
000073307ffdfc17  sub rsp, 0x08
000073307ffdfc1b  push rax
000073307ffdfc1c  push rcx
000073307ffdfc1d  push rdx
000073307ffdfc1e  push rdi
000073307ffdfc1f  push rsi
000073307ffdfc20  push r8
000073307ffdfc22  push r9
000073307ffdfc24  push r10
000073307ffdfc26  push r11
000073307ffdfc28  sub rsp, 0xF0
000073307ffdfc2f  vmovaps [rsp], xmm0
000073307ffdfc34  vmovaps [rsp+0x10], xmm1
000073307ffdfc3a  vmovaps [rsp+0x20], xmm2
000073307ffdfc40  vmovaps [rsp+0x30], xmm3
000073307ffdfc46  vmovaps [rsp+0x40], xmm4
000073307ffdfc4c  vmovaps [rsp+0x50], xmm5
000073307ffdfc52  vmovaps [rsp+0x60], xmm6
000073307ffdfc58  vmovaps [rsp+0x70], xmm7
000073307ffdfc5e  vmovaps [rsp+0x80], xmm8
000073307ffdfc67  vmovaps [rsp+0x90], xmm10
000073307ffdfc70  vmovaps [rsp+0xA0], xmm11
000073307ffdfc79  vmovaps [rsp+0xB0], xmm12
000073307ffdfc82  vmovaps [rsp+0xC0], xmm13
000073307ffdfc8b  vmovaps [rsp+0xD0], xmm14
000073307ffdfc94  vmovaps [rsp+0xE0], xmm15
000073307ffdfc9d  sub rsp, 0x30
000073307ffdfca1  movaps [rsp], xmm9
000073307ffdfca6  movaps [rsp+0x10], xmm8
000073307ffdfcac  movaps [rsp+0x20], xmm11
000073307ffdfcb2  lea rdi, [rsp]
000073307ffdfcb6  mov esi, 0x00
000073307ffdfcbb  mov rax, 0x600DE0EC8530
000073307ffdfcc5  call rax
000073307ffdfcc7  movaps xmm9, [rsp]
000073307ffdfccc  add rsp, 0x30
000073307ffdfcd0  vmovaps xmm0, [rsp]
000073307ffdfcd5  vmovaps xmm1, [rsp+0x10]
000073307ffdfcdb  vmovaps xmm2, [rsp+0x20]
000073307ffdfce1  vmovaps xmm3, [rsp+0x30]
000073307ffdfce7  vmovaps xmm4, [rsp+0x40]
000073307ffdfced  vmovaps xmm5, [rsp+0x50]
000073307ffdfcf3  vmovaps xmm6, [rsp+0x60]
000073307ffdfcf9  vmovaps xmm7, [rsp+0x70]
000073307ffdfcff  vmovaps xmm8, [rsp+0x80]
000073307ffdfd08  vmovaps xmm10, [rsp+0x90]
000073307ffdfd11  vmovaps xmm11, [rsp+0xA0]
000073307ffdfd1a  vmovaps xmm12, [rsp+0xB0]
000073307ffdfd23  vmovaps xmm13, [rsp+0xC0]
000073307ffdfd2c  vmovaps xmm14, [rsp+0xD0]
000073307ffdfd35  vmovaps xmm15, [rsp+0xE0]
000073307ffdfd3e  add rsp, 0xF0
000073307ffdfd45  pop r11
000073307ffdfd47  pop r10
000073307ffdfd49  pop r9
000073307ffdfd4b  pop r8
000073307ffdfd4d  pop rsi
000073307ffdfd4e  pop rdi
000073307ffdfd4f  pop rdx
000073307ffdfd50  pop rcx
000073307ffdfd51  pop rax
000073307ffdfd52  add rsp, 0x08
000073307ffdfd56  jmp 0x000073307FFDC505
000073307ffdfd5b  sub rsp, 0x08
000073307ffdfd5f  push rax
000073307ffdfd60  push rcx
000073307ffdfd61  push rdx
000073307ffdfd62  push rdi
000073307ffdfd63  push rsi
000073307ffdfd64  push r8
000073307ffdfd66  push r9
000073307ffdfd68  push r10
000073307ffdfd6a  push r11
000073307ffdfd6c  sub rsp, 0xF0
000073307ffdfd73  vmovaps [rsp], xmm0
000073307ffdfd78  vmovaps [rsp+0x10], xmm1
000073307ffdfd7e  vmovaps [rsp+0x20], xmm2
000073307ffdfd84  vmovaps [rsp+0x30], xmm3
000073307ffdfd8a  vmovaps [rsp+0x40], xmm4
000073307ffdfd90  vmovaps [rsp+0x50], xmm5
000073307ffdfd96  vmovaps [rsp+0x60], xmm6
000073307ffdfd9c  vmovaps [rsp+0x70], xmm7
000073307ffdfda2  vmovaps [rsp+0x80], xmm8
000073307ffdfdab  vmovaps [rsp+0x90], xmm9
000073307ffdfdb4  vmovaps [rsp+0xA0], xmm10
000073307ffdfdbd  vmovaps [rsp+0xB0], xmm12
000073307ffdfdc6  vmovaps [rsp+0xC0], xmm13
000073307ffdfdcf  vmovaps [rsp+0xD0], xmm14
000073307ffdfdd8  vmovaps [rsp+0xE0], xmm15
000073307ffdfde1  sub rsp, 0x30
000073307ffdfde5  movaps [rsp], xmm11
000073307ffdfdea  movaps [rsp+0x10], xmm10
000073307ffdfdf0  movaps [rsp+0x20], xmm6
000073307ffdfdf5  lea rdi, [rsp]
000073307ffdfdf9  mov esi, 0x00
000073307ffdfdfe  mov rax, 0x600DE0EC8530
000073307ffdfe08  call rax
000073307ffdfe0a  movaps xmm11, [rsp]
000073307ffdfe0f  add rsp, 0x30
000073307ffdfe13  vmovaps xmm0, [rsp]
000073307ffdfe18  vmovaps xmm1, [rsp+0x10]
000073307ffdfe1e  vmovaps xmm2, [rsp+0x20]
000073307ffdfe24  vmovaps xmm3, [rsp+0x30]
000073307ffdfe2a  vmovaps xmm4, [rsp+0x40]
000073307ffdfe30  vmovaps xmm5, [rsp+0x50]
000073307ffdfe36  vmovaps xmm6, [rsp+0x60]
000073307ffdfe3c  vmovaps xmm7, [rsp+0x70]
000073307ffdfe42  vmovaps xmm8, [rsp+0x80]
000073307ffdfe4b  vmovaps xmm9, [rsp+0x90]
000073307ffdfe54  vmovaps xmm10, [rsp+0xA0]
000073307ffdfe5d  vmovaps xmm12, [rsp+0xB0]
000073307ffdfe66  vmovaps xmm13, [rsp+0xC0]
000073307ffdfe6f  vmovaps xmm14, [rsp+0xD0]
000073307ffdfe78  vmovaps xmm15, [rsp+0xE0]
000073307ffdfe81  add rsp, 0xF0
000073307ffdfe88  pop r11
000073307ffdfe8a  pop r10
000073307ffdfe8c  pop r9
000073307ffdfe8e  pop r8
000073307ffdfe90  pop rsi
000073307ffdfe91  pop rdi
000073307ffdfe92  pop rdx
000073307ffdfe93  pop rcx
000073307ffdfe94  pop rax
000073307ffdfe95  add rsp, 0x08
000073307ffdfe99  jmp 0x000073307FFDC520
000073307ffdfe9e  sub rsp, 0x08
000073307ffdfea2  push rax
000073307ffdfea3  push rcx
000073307ffdfea4  push rdx
000073307ffdfea5  push rdi
000073307ffdfea6  push rsi
000073307ffdfea7  push r8
000073307ffdfea9  push r9
000073307ffdfeab  push r10
000073307ffdfead  push r11
000073307ffdfeaf  sub rsp, 0xF0
000073307ffdfeb6  vmovaps [rsp], xmm0
000073307ffdfebb  vmovaps [rsp+0x10], xmm1
000073307ffdfec1  vmovaps [rsp+0x20], xmm2
000073307ffdfec7  vmovaps [rsp+0x30], xmm3
000073307ffdfecd  vmovaps [rsp+0x40], xmm4
000073307ffdfed3  vmovaps [rsp+0x50], xmm5
000073307ffdfed9  vmovaps [rsp+0x60], xmm6
000073307ffdfedf  vmovaps [rsp+0x70], xmm7
000073307ffdfee5  vmovaps [rsp+0x80], xmm8
000073307ffdfeee  vmovaps [rsp+0x90], xmm9
000073307ffdfef7  vmovaps [rsp+0xA0], xmm11
000073307ffdff00  vmovaps [rsp+0xB0], xmm12
000073307ffdff09  vmovaps [rsp+0xC0], xmm13
000073307ffdff12  vmovaps [rsp+0xD0], xmm14
000073307ffdff1b  vmovaps [rsp+0xE0], xmm15
000073307ffdff24  sub rsp, 0x30
000073307ffdff28  movaps [rsp], xmm10
000073307ffdff2d  movaps [rsp+0x10], xmm14
000073307ffdff33  movaps [rsp+0x20], xmm4
000073307ffdff38  lea rdi, [rsp]
000073307ffdff3c  mov esi, 0x00
000073307ffdff41  mov rax, 0x600DE0EC8530
000073307ffdff4b  call rax
000073307ffdff4d  movaps xmm10, [rsp]
000073307ffdff52  add rsp, 0x30
000073307ffdff56  vmovaps xmm0, [rsp]
000073307ffdff5b  vmovaps xmm1, [rsp+0x10]
000073307ffdff61  vmovaps xmm2, [rsp+0x20]
000073307ffdff67  vmovaps xmm3, [rsp+0x30]
000073307ffdff6d  vmovaps xmm4, [rsp+0x40]
000073307ffdff73  vmovaps xmm5, [rsp+0x50]
000073307ffdff79  vmovaps xmm6, [rsp+0x60]
000073307ffdff7f  vmovaps xmm7, [rsp+0x70]
000073307ffdff85  vmovaps xmm8, [rsp+0x80]
000073307ffdff8e  vmovaps xmm9, [rsp+0x90]
000073307ffdff97  vmovaps xmm11, [rsp+0xA0]
000073307ffdffa0  vmovaps xmm12, [rsp+0xB0]
000073307ffdffa9  vmovaps xmm13, [rsp+0xC0]
000073307ffdffb2  vmovaps xmm14, [rsp+0xD0]
000073307ffdffbb  vmovaps xmm15, [rsp+0xE0]
000073307ffdffc4  add rsp, 0xF0
000073307ffdffcb  pop r11
000073307ffdffcd  pop r10
000073307ffdffcf  pop r9
000073307ffdffd1  pop r8
000073307ffdffd3  pop rsi
000073307ffdffd4  pop rdi
000073307ffdffd5  pop rdx
000073307ffdffd6  pop rcx
000073307ffdffd7  pop rax
000073307ffdffd8  add rsp, 0x08
000073307ffdffdc  jmp 0x000073307FFDC53B
000073307ffdffe1  sub rsp, 0x08
000073307ffdffe5  push rax
000073307ffdffe6  push rcx
000073307ffdffe7  push rdx
000073307ffdffe8  push rdi
000073307ffdffe9  push rsi
000073307ffdffea  push r8
000073307ffdffec  push r9
000073307ffdffee  push r10
000073307ffdfff0  push r11
000073307ffdfff2  sub rsp, 0xF0
000073307ffdfff9  vmovaps [rsp], xmm0
000073307ffdfffe  vmovaps [rsp+0x10], xmm1
000073307ffe0004  vmovaps [rsp+0x20], xmm2
000073307ffe000a  vmovaps [rsp+0x30], xmm3
000073307ffe0010  vmovaps [rsp+0x40], xmm4
000073307ffe0016  vmovaps [rsp+0x50], xmm5
000073307ffe001c  vmovaps [rsp+0x60], xmm6
000073307ffe0022  vmovaps [rsp+0x70], xmm7
000073307ffe0028  vmovaps [rsp+0x80], xmm9
000073307ffe0031  vmovaps [rsp+0x90], xmm10
000073307ffe003a  vmovaps [rsp+0xA0], xmm11
000073307ffe0043  vmovaps [rsp+0xB0], xmm12
000073307ffe004c  vmovaps [rsp+0xC0], xmm13
000073307ffe0055  vmovaps [rsp+0xD0], xmm14
000073307ffe005e  vmovaps [rsp+0xE0], xmm15
000073307ffe0067  sub rsp, 0x30
000073307ffe006b  movaps [rsp], xmm8
000073307ffe0070  movaps [rsp+0x10], xmm1
000073307ffe0075  movaps [rsp+0x20], xmm14
000073307ffe007b  lea rdi, [rsp]
000073307ffe007f  mov esi, 0x00
000073307ffe0084  mov rax, 0x600DE0EC8530
000073307ffe008e  call rax
000073307ffe0090  movaps xmm8, [rsp]
000073307ffe0095  add rsp, 0x30
000073307ffe0099  vmovaps xmm0, [rsp]
000073307ffe009e  vmovaps xmm1, [rsp+0x10]
000073307ffe00a4  vmovaps xmm2, [rsp+0x20]
000073307ffe00aa  vmovaps xmm3, [rsp+0x30]
000073307ffe00b0  vmovaps xmm4, [rsp+0x40]
000073307ffe00b6  vmovaps xmm5, [rsp+0x50]
000073307ffe00bc  vmovaps xmm6, [rsp+0x60]
000073307ffe00c2  vmovaps xmm7, [rsp+0x70]
000073307ffe00c8  vmovaps xmm9, [rsp+0x80]
000073307ffe00d1  vmovaps xmm10, [rsp+0x90]
000073307ffe00da  vmovaps xmm11, [rsp+0xA0]
000073307ffe00e3  vmovaps xmm12, [rsp+0xB0]
000073307ffe00ec  vmovaps xmm13, [rsp+0xC0]
000073307ffe00f5  vmovaps xmm14, [rsp+0xD0]
000073307ffe00fe  vmovaps xmm15, [rsp+0xE0]
000073307ffe0107  add rsp, 0xF0
000073307ffe010e  pop r11
000073307ffe0110  pop r10
000073307ffe0112  pop r9
000073307ffe0114  pop r8
000073307ffe0116  pop rsi
000073307ffe0117  pop rdi
000073307ffe0118  pop rdx
000073307ffe0119  pop rcx
000073307ffe011a  pop rax
000073307ffe011b  add rsp, 0x08
000073307ffe011f  jmp 0x000073307FFDC561
000073307ffe0124  sub rsp, 0x08
000073307ffe0128  push rax
000073307ffe0129  push rcx
000073307ffe012a  push rdx
000073307ffe012b  push rdi
000073307ffe012c  push rsi
000073307ffe012d  push r8
000073307ffe012f  push r9
000073307ffe0131  push r10
000073307ffe0133  push r11
000073307ffe0135  sub rsp, 0xF0
000073307ffe013c  vmovaps [rsp], xmm0
000073307ffe0141  vmovaps [rsp+0x10], xmm1
000073307ffe0147  vmovaps [rsp+0x20], xmm2
000073307ffe014d  vmovaps [rsp+0x30], xmm3
000073307ffe0153  vmovaps [rsp+0x40], xmm4
000073307ffe0159  vmovaps [rsp+0x50], xmm5
000073307ffe015f  vmovaps [rsp+0x60], xmm7
000073307ffe0165  vmovaps [rsp+0x70], xmm8
000073307ffe016b  vmovaps [rsp+0x80], xmm9
000073307ffe0174  vmovaps [rsp+0x90], xmm10
000073307ffe017d  vmovaps [rsp+0xA0], xmm11
000073307ffe0186  vmovaps [rsp+0xB0], xmm12
000073307ffe018f  vmovaps [rsp+0xC0], xmm13
000073307ffe0198  vmovaps [rsp+0xD0], xmm14
000073307ffe01a1  vmovaps [rsp+0xE0], xmm15
000073307ffe01aa  sub rsp, 0x30
000073307ffe01ae  movaps [rsp], xmm6
000073307ffe01b2  movaps [rsp+0x10], xmm1
000073307ffe01b7  movaps [rsp+0x20], xmm14
000073307ffe01bd  lea rdi, [rsp]
000073307ffe01c1  mov esi, 0x00
000073307ffe01c6  mov rax, 0x600DE0EC8530
000073307ffe01d0  call rax
000073307ffe01d2  movaps xmm6, [rsp]
000073307ffe01d6  add rsp, 0x30
000073307ffe01da  vmovaps xmm0, [rsp]
000073307ffe01df  vmovaps xmm1, [rsp+0x10]
000073307ffe01e5  vmovaps xmm2, [rsp+0x20]
000073307ffe01eb  vmovaps xmm3, [rsp+0x30]
000073307ffe01f1  vmovaps xmm4, [rsp+0x40]
000073307ffe01f7  vmovaps xmm5, [rsp+0x50]
000073307ffe01fd  vmovaps xmm7, [rsp+0x60]
000073307ffe0203  vmovaps xmm8, [rsp+0x70]
000073307ffe0209  vmovaps xmm9, [rsp+0x80]
000073307ffe0212  vmovaps xmm10, [rsp+0x90]
000073307ffe021b  vmovaps xmm11, [rsp+0xA0]
000073307ffe0224  vmovaps xmm12, [rsp+0xB0]
000073307ffe022d  vmovaps xmm13, [rsp+0xC0]
000073307ffe0236  vmovaps xmm14, [rsp+0xD0]
000073307ffe023f  vmovaps xmm15, [rsp+0xE0]
000073307ffe0248  add rsp, 0xF0
000073307ffe024f  pop r11
000073307ffe0251  pop r10
000073307ffe0253  pop r9
000073307ffe0255  pop r8
000073307ffe0257  pop rsi
000073307ffe0258  pop rdi
000073307ffe0259  pop rdx
000073307ffe025a  pop rcx
000073307ffe025b  pop rax
000073307ffe025c  add rsp, 0x08
000073307ffe0260  jmp 0x000073307FFDC58D
000073307ffe0265  sub rsp, 0x08
000073307ffe0269  push rax
000073307ffe026a  push rcx
000073307ffe026b  push rdx
000073307ffe026c  push rdi
000073307ffe026d  push rsi
000073307ffe026e  push r8
000073307ffe0270  push r9
000073307ffe0272  push r10
000073307ffe0274  push r11
000073307ffe0276  sub rsp, 0xF0
000073307ffe027d  vmovaps [rsp], xmm0
000073307ffe0282  vmovaps [rsp+0x10], xmm1
000073307ffe0288  vmovaps [rsp+0x20], xmm2
000073307ffe028e  vmovaps [rsp+0x30], xmm3
000073307ffe0294  vmovaps [rsp+0x40], xmm4
000073307ffe029a  vmovaps [rsp+0x50], xmm5
000073307ffe02a0  vmovaps [rsp+0x60], xmm6
000073307ffe02a6  vmovaps [rsp+0x70], xmm7
000073307ffe02ac  vmovaps [rsp+0x80], xmm8
000073307ffe02b5  vmovaps [rsp+0x90], xmm9
000073307ffe02be  vmovaps [rsp+0xA0], xmm10
000073307ffe02c7  vmovaps [rsp+0xB0], xmm11
000073307ffe02d0  vmovaps [rsp+0xC0], xmm12
000073307ffe02d9  vmovaps [rsp+0xD0], xmm13
000073307ffe02e2  vmovaps [rsp+0xE0], xmm15
000073307ffe02eb  sub rsp, 0x30
000073307ffe02ef  movaps [rsp], xmm14
000073307ffe02f4  movaps [rsp+0x10], xmm12
000073307ffe02fa  movaps [rsp+0x20], xmm1
000073307ffe02ff  lea rdi, [rsp]
000073307ffe0303  mov esi, 0x00
000073307ffe0308  mov rax, 0x600DE0EC8530
000073307ffe0312  call rax
000073307ffe0314  movaps xmm14, [rsp]
000073307ffe0319  add rsp, 0x30
000073307ffe031d  vmovaps xmm0, [rsp]
000073307ffe0322  vmovaps xmm1, [rsp+0x10]
000073307ffe0328  vmovaps xmm2, [rsp+0x20]
000073307ffe032e  vmovaps xmm3, [rsp+0x30]
000073307ffe0334  vmovaps xmm4, [rsp+0x40]
000073307ffe033a  vmovaps xmm5, [rsp+0x50]
000073307ffe0340  vmovaps xmm6, [rsp+0x60]
000073307ffe0346  vmovaps xmm7, [rsp+0x70]
000073307ffe034c  vmovaps xmm8, [rsp+0x80]
000073307ffe0355  vmovaps xmm9, [rsp+0x90]
000073307ffe035e  vmovaps xmm10, [rsp+0xA0]
000073307ffe0367  vmovaps xmm11, [rsp+0xB0]
000073307ffe0370  vmovaps xmm12, [rsp+0xC0]
000073307ffe0379  vmovaps xmm13, [rsp+0xD0]
000073307ffe0382  vmovaps xmm15, [rsp+0xE0]
000073307ffe038b  add rsp, 0xF0
000073307ffe0392  pop r11
000073307ffe0394  pop r10
000073307ffe0396  pop r9
000073307ffe0398  pop r8
000073307ffe039a  pop rsi
000073307ffe039b  pop rdi
000073307ffe039c  pop rdx
000073307ffe039d  pop rcx
000073307ffe039e  pop rax
000073307ffe039f  add rsp, 0x08
000073307ffe03a3  jmp 0x000073307FFDC5B3
000073307ffe03a8  sub rsp, 0x08
000073307ffe03ac  push rax
000073307ffe03ad  push rcx
000073307ffe03ae  push rdx
000073307ffe03af  push rdi
000073307ffe03b0  push rsi
000073307ffe03b1  push r8
000073307ffe03b3  push r9
000073307ffe03b5  push r10
000073307ffe03b7  push r11
000073307ffe03b9  sub rsp, 0xF0
000073307ffe03c0  vmovaps [rsp], xmm0
000073307ffe03c5  vmovaps [rsp+0x10], xmm2
000073307ffe03cb  vmovaps [rsp+0x20], xmm3
000073307ffe03d1  vmovaps [rsp+0x30], xmm4
000073307ffe03d7  vmovaps [rsp+0x40], xmm5
000073307ffe03dd  vmovaps [rsp+0x50], xmm6
000073307ffe03e3  vmovaps [rsp+0x60], xmm7
000073307ffe03e9  vmovaps [rsp+0x70], xmm8
000073307ffe03ef  vmovaps [rsp+0x80], xmm9
000073307ffe03f8  vmovaps [rsp+0x90], xmm10
000073307ffe0401  vmovaps [rsp+0xA0], xmm11
000073307ffe040a  vmovaps [rsp+0xB0], xmm12
000073307ffe0413  vmovaps [rsp+0xC0], xmm13
000073307ffe041c  vmovaps [rsp+0xD0], xmm14
000073307ffe0425  vmovaps [rsp+0xE0], xmm15
000073307ffe042e  sub rsp, 0x30
000073307ffe0432  movaps [rsp], xmm1
000073307ffe0436  movaps [rsp+0x10], xmm13
000073307ffe043c  movaps [rsp+0x20], xmm9
000073307ffe0442  lea rdi, [rsp]
000073307ffe0446  mov esi, 0x00
000073307ffe044b  mov rax, 0x600DE0EC8530
000073307ffe0455  call rax
000073307ffe0457  movaps xmm1, [rsp]
000073307ffe045b  add rsp, 0x30
000073307ffe045f  vmovaps xmm0, [rsp]
000073307ffe0464  vmovaps xmm2, [rsp+0x10]
000073307ffe046a  vmovaps xmm3, [rsp+0x20]
000073307ffe0470  vmovaps xmm4, [rsp+0x30]
000073307ffe0476  vmovaps xmm5, [rsp+0x40]
000073307ffe047c  vmovaps xmm6, [rsp+0x50]
000073307ffe0482  vmovaps xmm7, [rsp+0x60]
000073307ffe0488  vmovaps xmm8, [rsp+0x70]
000073307ffe048e  vmovaps xmm9, [rsp+0x80]
000073307ffe0497  vmovaps xmm10, [rsp+0x90]
000073307ffe04a0  vmovaps xmm11, [rsp+0xA0]
000073307ffe04a9  vmovaps xmm12, [rsp+0xB0]
000073307ffe04b2  vmovaps xmm13, [rsp+0xC0]
000073307ffe04bb  vmovaps xmm14, [rsp+0xD0]
000073307ffe04c4  vmovaps xmm15, [rsp+0xE0]
000073307ffe04cd  add rsp, 0xF0
000073307ffe04d4  pop r11
000073307ffe04d6  pop r10
000073307ffe04d8  pop r9
000073307ffe04da  pop r8
000073307ffe04dc  pop rsi
000073307ffe04dd  pop rdi
000073307ffe04de  pop rdx
000073307ffe04df  pop rcx
000073307ffe04e0  pop rax
000073307ffe04e1  add rsp, 0x08
000073307ffe04e5  jmp 0x000073307FFDC5CD
000073307ffe04ea  sub rsp, 0x08
000073307ffe04ee  push rax
000073307ffe04ef  push rcx
000073307ffe04f0  push rdx
000073307ffe04f1  push rdi
000073307ffe04f2  push rsi
000073307ffe04f3  push r8
000073307ffe04f5  push r9
000073307ffe04f7  push r10
000073307ffe04f9  push r11
000073307ffe04fb  sub rsp, 0xF0
000073307ffe0502  vmovaps [rsp], xmm0
000073307ffe0507  vmovaps [rsp+0x10], xmm1
000073307ffe050d  vmovaps [rsp+0x20], xmm2
000073307ffe0513  vmovaps [rsp+0x30], xmm3
000073307ffe0519  vmovaps [rsp+0x40], xmm4
000073307ffe051f  vmovaps [rsp+0x50], xmm5
000073307ffe0525  vmovaps [rsp+0x60], xmm6
000073307ffe052b  vmovaps [rsp+0x70], xmm7
000073307ffe0531  vmovaps [rsp+0x80], xmm8
000073307ffe053a  vmovaps [rsp+0x90], xmm9
000073307ffe0543  vmovaps [rsp+0xA0], xmm10
000073307ffe054c  vmovaps [rsp+0xB0], xmm11
000073307ffe0555  vmovaps [rsp+0xC0], xmm13
000073307ffe055e  vmovaps [rsp+0xD0], xmm14
000073307ffe0567  vmovaps [rsp+0xE0], xmm15
000073307ffe0570  sub rsp, 0x30
000073307ffe0574  movaps [rsp], xmm12
000073307ffe0579  movaps [rsp+0x10], xmm7
000073307ffe057e  movaps [rsp+0x20], xmm13
000073307ffe0584  lea rdi, [rsp]
000073307ffe0588  mov esi, 0x00
000073307ffe058d  mov rax, 0x600DE0EC8530
000073307ffe0597  call rax
000073307ffe0599  movaps xmm12, [rsp]
000073307ffe059e  add rsp, 0x30
000073307ffe05a2  vmovaps xmm0, [rsp]
000073307ffe05a7  vmovaps xmm1, [rsp+0x10]
000073307ffe05ad  vmovaps xmm2, [rsp+0x20]
000073307ffe05b3  vmovaps xmm3, [rsp+0x30]
000073307ffe05b9  vmovaps xmm4, [rsp+0x40]
000073307ffe05bf  vmovaps xmm5, [rsp+0x50]
000073307ffe05c5  vmovaps xmm6, [rsp+0x60]
000073307ffe05cb  vmovaps xmm7, [rsp+0x70]
000073307ffe05d1  vmovaps xmm8, [rsp+0x80]
000073307ffe05da  vmovaps xmm9, [rsp+0x90]
000073307ffe05e3  vmovaps xmm10, [rsp+0xA0]
000073307ffe05ec  vmovaps xmm11, [rsp+0xB0]
000073307ffe05f5  vmovaps xmm13, [rsp+0xC0]
000073307ffe05fe  vmovaps xmm14, [rsp+0xD0]
000073307ffe0607  vmovaps xmm15, [rsp+0xE0]
000073307ffe0610  add rsp, 0xF0
000073307ffe0617  pop r11
000073307ffe0619  pop r10
000073307ffe061b  pop r9
000073307ffe061d  pop r8
000073307ffe061f  pop rsi
000073307ffe0620  pop rdi
000073307ffe0621  pop rdx
000073307ffe0622  pop rcx
000073307ffe0623  pop rax
000073307ffe0624  add rsp, 0x08
000073307ffe0628  jmp 0x000073307FFDC5F4
000073307ffe062d  sub rsp, 0x08
000073307ffe0631  push rax
000073307ffe0632  push rcx
000073307ffe0633  push rdx
000073307ffe0634  push rdi
000073307ffe0635  push rsi
000073307ffe0636  push r8
000073307ffe0638  push r9
000073307ffe063a  push r10
000073307ffe063c  push r11
000073307ffe063e  sub rsp, 0xF0
000073307ffe0645  vmovaps [rsp], xmm0
000073307ffe064a  vmovaps [rsp+0x10], xmm1
000073307ffe0650  vmovaps [rsp+0x20], xmm2
000073307ffe0656  vmovaps [rsp+0x30], xmm3
000073307ffe065c  vmovaps [rsp+0x40], xmm4
000073307ffe0662  vmovaps [rsp+0x50], xmm5
000073307ffe0668  vmovaps [rsp+0x60], xmm6
000073307ffe066e  vmovaps [rsp+0x70], xmm7
000073307ffe0674  vmovaps [rsp+0x80], xmm8
000073307ffe067d  vmovaps [rsp+0x90], xmm9
000073307ffe0686  vmovaps [rsp+0xA0], xmm10
000073307ffe068f  vmovaps [rsp+0xB0], xmm11
000073307ffe0698  vmovaps [rsp+0xC0], xmm12
000073307ffe06a1  vmovaps [rsp+0xD0], xmm14
000073307ffe06aa  vmovaps [rsp+0xE0], xmm15
000073307ffe06b3  sub rsp, 0x30
000073307ffe06b7  movaps [rsp], xmm13
000073307ffe06bc  movaps [rsp+0x10], xmm15
000073307ffe06c2  movaps [rsp+0x20], xmm8
000073307ffe06c8  lea rdi, [rsp]
000073307ffe06cc  mov esi, 0x00
000073307ffe06d1  mov rax, 0x600DE0EC8530
000073307ffe06db  call rax
000073307ffe06dd  movaps xmm13, [rsp]
000073307ffe06e2  add rsp, 0x30
000073307ffe06e6  vmovaps xmm0, [rsp]
000073307ffe06eb  vmovaps xmm1, [rsp+0x10]
000073307ffe06f1  vmovaps xmm2, [rsp+0x20]
000073307ffe06f7  vmovaps xmm3, [rsp+0x30]
000073307ffe06fd  vmovaps xmm4, [rsp+0x40]
000073307ffe0703  vmovaps xmm5, [rsp+0x50]
000073307ffe0709  vmovaps xmm6, [rsp+0x60]
000073307ffe070f  vmovaps xmm7, [rsp+0x70]
000073307ffe0715  vmovaps xmm8, [rsp+0x80]
000073307ffe071e  vmovaps xmm9, [rsp+0x90]
000073307ffe0727  vmovaps xmm10, [rsp+0xA0]
000073307ffe0730  vmovaps xmm11, [rsp+0xB0]
000073307ffe0739  vmovaps xmm12, [rsp+0xC0]
000073307ffe0742  vmovaps xmm14, [rsp+0xD0]
000073307ffe074b  vmovaps xmm15, [rsp+0xE0]
000073307ffe0754  add rsp, 0xF0
000073307ffe075b  pop r11
000073307ffe075d  pop r10
000073307ffe075f  pop r9
000073307ffe0761  pop r8
000073307ffe0763  pop rsi
000073307ffe0764  pop rdi
000073307ffe0765  pop rdx
000073307ffe0766  pop rcx
000073307ffe0767  pop rax
000073307ffe0768  add rsp, 0x08
000073307ffe076c  jmp 0x000073307FFDC60F
000073307ffe0771  sub rsp, 0x08
000073307ffe0775  push rax
000073307ffe0776  push rcx
000073307ffe0777  push rdx
000073307ffe0778  push rdi
000073307ffe0779  push rsi
000073307ffe077a  push r8
000073307ffe077c  push r9
000073307ffe077e  push r10
000073307ffe0780  push r11
000073307ffe0782  sub rsp, 0xF0
000073307ffe0789  vmovaps [rsp], xmm0
000073307ffe078e  vmovaps [rsp+0x10], xmm1
000073307ffe0794  vmovaps [rsp+0x20], xmm2
000073307ffe079a  vmovaps [rsp+0x30], xmm3
000073307ffe07a0  vmovaps [rsp+0x40], xmm4
000073307ffe07a6  vmovaps [rsp+0x50], xmm5
000073307ffe07ac  vmovaps [rsp+0x60], xmm6
000073307ffe07b2  vmovaps [rsp+0x70], xmm7
000073307ffe07b8  vmovaps [rsp+0x80], xmm9
000073307ffe07c1  vmovaps [rsp+0x90], xmm10
000073307ffe07ca  vmovaps [rsp+0xA0], xmm11
000073307ffe07d3  vmovaps [rsp+0xB0], xmm12
000073307ffe07dc  vmovaps [rsp+0xC0], xmm13
000073307ffe07e5  vmovaps [rsp+0xD0], xmm14
000073307ffe07ee  vmovaps [rsp+0xE0], xmm15
000073307ffe07f7  sub rsp, 0x30
000073307ffe07fb  movaps [rsp], xmm8
000073307ffe0800  movaps [rsp+0x10], xmm15
000073307ffe0806  movaps [rsp+0x20], xmm9
000073307ffe080c  lea rdi, [rsp]
000073307ffe0810  mov esi, 0x00
000073307ffe0815  mov rax, 0x600DE0EC8530
000073307ffe081f  call rax
000073307ffe0821  movaps xmm8, [rsp]
000073307ffe0826  add rsp, 0x30
000073307ffe082a  vmovaps xmm0, [rsp]
000073307ffe082f  vmovaps xmm1, [rsp+0x10]
000073307ffe0835  vmovaps xmm2, [rsp+0x20]
000073307ffe083b  vmovaps xmm3, [rsp+0x30]
000073307ffe0841  vmovaps xmm4, [rsp+0x40]
000073307ffe0847  vmovaps xmm5, [rsp+0x50]
000073307ffe084d  vmovaps xmm6, [rsp+0x60]
000073307ffe0853  vmovaps xmm7, [rsp+0x70]
000073307ffe0859  vmovaps xmm9, [rsp+0x80]
000073307ffe0862  vmovaps xmm10, [rsp+0x90]
000073307ffe086b  vmovaps xmm11, [rsp+0xA0]
000073307ffe0874  vmovaps xmm12, [rsp+0xB0]
000073307ffe087d  vmovaps xmm13, [rsp+0xC0]
000073307ffe0886  vmovaps xmm14, [rsp+0xD0]
000073307ffe088f  vmovaps xmm15, [rsp+0xE0]
000073307ffe0898  add rsp, 0xF0
000073307ffe089f  pop r11
000073307ffe08a1  pop r10
000073307ffe08a3  pop r9
000073307ffe08a5  pop r8
000073307ffe08a7  pop rsi
000073307ffe08a8  pop rdi
000073307ffe08a9  pop rdx
000073307ffe08aa  pop rcx
000073307ffe08ab  pop rax
000073307ffe08ac  add rsp, 0x08
000073307ffe08b0  jmp 0x000073307FFDC63D
000073307ffe08b5  sub rsp, 0x08
000073307ffe08b9  push rax
000073307ffe08ba  push rcx
000073307ffe08bb  push rdx
000073307ffe08bc  push rdi
000073307ffe08bd  push rsi
000073307ffe08be  push r8
000073307ffe08c0  push r9
000073307ffe08c2  push r10
000073307ffe08c4  push r11
000073307ffe08c6  sub rsp, 0xF0
000073307ffe08cd  vmovaps [rsp], xmm0
000073307ffe08d2  vmovaps [rsp+0x10], xmm1
000073307ffe08d8  vmovaps [rsp+0x20], xmm2
000073307ffe08de  vmovaps [rsp+0x30], xmm3
000073307ffe08e4  vmovaps [rsp+0x40], xmm4
000073307ffe08ea  vmovaps [rsp+0x50], xmm5
000073307ffe08f0  vmovaps [rsp+0x60], xmm6
000073307ffe08f6  vmovaps [rsp+0x70], xmm7
000073307ffe08fc  vmovaps [rsp+0x80], xmm8
000073307ffe0905  vmovaps [rsp+0x90], xmm9
000073307ffe090e  vmovaps [rsp+0xA0], xmm10
000073307ffe0917  vmovaps [rsp+0xB0], xmm11
000073307ffe0920  vmovaps [rsp+0xC0], xmm12
000073307ffe0929  vmovaps [rsp+0xD0], xmm13
000073307ffe0932  vmovaps [rsp+0xE0], xmm14
000073307ffe093b  sub rsp, 0x30
000073307ffe093f  movaps [rsp], xmm15
000073307ffe0944  movaps [rsp+0x10], xmm11
000073307ffe094a  movaps [rsp+0x20], xmm6
000073307ffe094f  lea rdi, [rsp]
000073307ffe0953  mov esi, 0x00
000073307ffe0958  mov rax, 0x600DE0EC8530
000073307ffe0962  call rax
000073307ffe0964  movaps xmm15, [rsp]
000073307ffe0969  add rsp, 0x30
000073307ffe096d  vmovaps xmm0, [rsp]
000073307ffe0972  vmovaps xmm1, [rsp+0x10]
000073307ffe0978  vmovaps xmm2, [rsp+0x20]
000073307ffe097e  vmovaps xmm3, [rsp+0x30]
000073307ffe0984  vmovaps xmm4, [rsp+0x40]
000073307ffe098a  vmovaps xmm5, [rsp+0x50]
000073307ffe0990  vmovaps xmm6, [rsp+0x60]
000073307ffe0996  vmovaps xmm7, [rsp+0x70]
000073307ffe099c  vmovaps xmm8, [rsp+0x80]
000073307ffe09a5  vmovaps xmm9, [rsp+0x90]
000073307ffe09ae  vmovaps xmm10, [rsp+0xA0]
000073307ffe09b7  vmovaps xmm11, [rsp+0xB0]
000073307ffe09c0  vmovaps xmm12, [rsp+0xC0]
000073307ffe09c9  vmovaps xmm13, [rsp+0xD0]
000073307ffe09d2  vmovaps xmm14, [rsp+0xE0]
000073307ffe09db  add rsp, 0xF0
000073307ffe09e2  pop r11
000073307ffe09e4  pop r10
000073307ffe09e6  pop r9
000073307ffe09e8  pop r8
000073307ffe09ea  pop rsi
000073307ffe09eb  pop rdi
000073307ffe09ec  pop rdx
000073307ffe09ed  pop rcx
000073307ffe09ee  pop rax
000073307ffe09ef  add rsp, 0x08
000073307ffe09f3  jmp 0x000073307FFDC658
000073307ffe09f8  sub rsp, 0x08
000073307ffe09fc  push rax
000073307ffe09fd  push rcx
000073307ffe09fe  push rdx
000073307ffe09ff  push rdi
000073307ffe0a00  push rsi
000073307ffe0a01  push r8
000073307ffe0a03  push r9
000073307ffe0a05  push r10
000073307ffe0a07  push r11
000073307ffe0a09  sub rsp, 0xF0
000073307ffe0a10  vmovaps [rsp], xmm0
000073307ffe0a15  vmovaps [rsp+0x10], xmm1
000073307ffe0a1b  vmovaps [rsp+0x20], xmm2
000073307ffe0a21  vmovaps [rsp+0x30], xmm3
000073307ffe0a27  vmovaps [rsp+0x40], xmm4
000073307ffe0a2d  vmovaps [rsp+0x50], xmm5
000073307ffe0a33  vmovaps [rsp+0x60], xmm6
000073307ffe0a39  vmovaps [rsp+0x70], xmm8
000073307ffe0a3f  vmovaps [rsp+0x80], xmm9
000073307ffe0a48  vmovaps [rsp+0x90], xmm10
000073307ffe0a51  vmovaps [rsp+0xA0], xmm11
000073307ffe0a5a  vmovaps [rsp+0xB0], xmm12
000073307ffe0a63  vmovaps [rsp+0xC0], xmm13
000073307ffe0a6c  vmovaps [rsp+0xD0], xmm14
000073307ffe0a75  vmovaps [rsp+0xE0], xmm15
000073307ffe0a7e  sub rsp, 0x30
000073307ffe0a82  movaps [rsp], xmm7
000073307ffe0a86  movaps [rsp+0x10], xmm11
000073307ffe0a8c  movaps [rsp+0x20], xmm9
000073307ffe0a92  lea rdi, [rsp]
000073307ffe0a96  mov esi, 0x00
000073307ffe0a9b  mov rax, 0x600DE0EC8530
000073307ffe0aa5  call rax
000073307ffe0aa7  movaps xmm7, [rsp]
000073307ffe0aab  add rsp, 0x30
000073307ffe0aaf  vmovaps xmm0, [rsp]
000073307ffe0ab4  vmovaps xmm1, [rsp+0x10]
000073307ffe0aba  vmovaps xmm2, [rsp+0x20]
000073307ffe0ac0  vmovaps xmm3, [rsp+0x30]
000073307ffe0ac6  vmovaps xmm4, [rsp+0x40]
000073307ffe0acc  vmovaps xmm5, [rsp+0x50]
000073307ffe0ad2  vmovaps xmm6, [rsp+0x60]
000073307ffe0ad8  vmovaps xmm8, [rsp+0x70]
000073307ffe0ade  vmovaps xmm9, [rsp+0x80]
000073307ffe0ae7  vmovaps xmm10, [rsp+0x90]
000073307ffe0af0  vmovaps xmm11, [rsp+0xA0]
000073307ffe0af9  vmovaps xmm12, [rsp+0xB0]
000073307ffe0b02  vmovaps xmm13, [rsp+0xC0]
000073307ffe0b0b  vmovaps xmm14, [rsp+0xD0]
000073307ffe0b14  vmovaps xmm15, [rsp+0xE0]
000073307ffe0b1d  add rsp, 0xF0
000073307ffe0b24  pop r11
000073307ffe0b26  pop r10
000073307ffe0b28  pop r9
000073307ffe0b2a  pop r8
000073307ffe0b2c  pop rsi
000073307ffe0b2d  pop rdi
000073307ffe0b2e  pop rdx
000073307ffe0b2f  pop rcx
000073307ffe0b30  pop rax
000073307ffe0b31  add rsp, 0x08
000073307ffe0b35  jmp 0x000073307FFDC685
000073307ffe0b3a  sub rsp, 0x08
000073307ffe0b3e  push rax
000073307ffe0b3f  push rcx
000073307ffe0b40  push rdx
000073307ffe0b41  push rdi
000073307ffe0b42  push rsi
000073307ffe0b43  push r8
000073307ffe0b45  push r9
000073307ffe0b47  push r10
000073307ffe0b49  push r11
000073307ffe0b4b  sub rsp, 0xF0
000073307ffe0b52  vmovaps [rsp], xmm0
000073307ffe0b57  vmovaps [rsp+0x10], xmm1
000073307ffe0b5d  vmovaps [rsp+0x20], xmm2
000073307ffe0b63  vmovaps [rsp+0x30], xmm3
000073307ffe0b69  vmovaps [rsp+0x40], xmm4
000073307ffe0b6f  vmovaps [rsp+0x50], xmm5
000073307ffe0b75  vmovaps [rsp+0x60], xmm6
000073307ffe0b7b  vmovaps [rsp+0x70], xmm7
000073307ffe0b81  vmovaps [rsp+0x80], xmm8
000073307ffe0b8a  vmovaps [rsp+0x90], xmm9
000073307ffe0b93  vmovaps [rsp+0xA0], xmm10
000073307ffe0b9c  vmovaps [rsp+0xB0], xmm12
000073307ffe0ba5  vmovaps [rsp+0xC0], xmm13
000073307ffe0bae  vmovaps [rsp+0xD0], xmm14
000073307ffe0bb7  vmovaps [rsp+0xE0], xmm15
000073307ffe0bc0  sub rsp, 0x30
000073307ffe0bc4  movaps [rsp], xmm11
000073307ffe0bc9  movaps [rsp+0x10], xmm10
000073307ffe0bcf  movaps [rsp+0x20], xmm14
000073307ffe0bd5  lea rdi, [rsp]
000073307ffe0bd9  mov esi, 0x00
000073307ffe0bde  mov rax, 0x600DE0EC8530
000073307ffe0be8  call rax
000073307ffe0bea  movaps xmm11, [rsp]
000073307ffe0bef  add rsp, 0x30
000073307ffe0bf3  vmovaps xmm0, [rsp]
000073307ffe0bf8  vmovaps xmm1, [rsp+0x10]
000073307ffe0bfe  vmovaps xmm2, [rsp+0x20]
000073307ffe0c04  vmovaps xmm3, [rsp+0x30]
000073307ffe0c0a  vmovaps xmm4, [rsp+0x40]
000073307ffe0c10  vmovaps xmm5, [rsp+0x50]
000073307ffe0c16  vmovaps xmm6, [rsp+0x60]
000073307ffe0c1c  vmovaps xmm7, [rsp+0x70]
000073307ffe0c22  vmovaps xmm8, [rsp+0x80]
000073307ffe0c2b  vmovaps xmm9, [rsp+0x90]
000073307ffe0c34  vmovaps xmm10, [rsp+0xA0]
000073307ffe0c3d  vmovaps xmm12, [rsp+0xB0]
000073307ffe0c46  vmovaps xmm13, [rsp+0xC0]
000073307ffe0c4f  vmovaps xmm14, [rsp+0xD0]
000073307ffe0c58  vmovaps xmm15, [rsp+0xE0]
000073307ffe0c61  add rsp, 0xF0
000073307ffe0c68  pop r11
000073307ffe0c6a  pop r10
000073307ffe0c6c  pop r9
000073307ffe0c6e  pop r8
000073307ffe0c70  pop rsi
000073307ffe0c71  pop rdi
000073307ffe0c72  pop rdx
000073307ffe0c73  pop rcx
000073307ffe0c74  pop rax
000073307ffe0c75  add rsp, 0x08
000073307ffe0c79  jmp 0x000073307FFDC6A0
000073307ffe0c7e  call 0x000073307FEC33A0
000073307ffe0c83  jmp 0x000073307FFDC6AA
000073307ffe0c88  sub rsp, 0x08
000073307ffe0c8c  push rax
000073307ffe0c8d  push rcx
000073307ffe0c8e  push rdx
000073307ffe0c8f  push rdi
000073307ffe0c90  push rsi
000073307ffe0c91  push r8
000073307ffe0c93  push r9
000073307ffe0c95  push r10
000073307ffe0c97  push r11
000073307ffe0c99  sub rsp, 0xF0
000073307ffe0ca0  vmovaps [rsp], xmm0
000073307ffe0ca5  vmovaps [rsp+0x10], xmm1
000073307ffe0cab  vmovaps [rsp+0x20], xmm2
000073307ffe0cb1  vmovaps [rsp+0x30], xmm3
000073307ffe0cb7  vmovaps [rsp+0x40], xmm4
000073307ffe0cbd  vmovaps [rsp+0x50], xmm5
000073307ffe0cc3  vmovaps [rsp+0x60], xmm6
000073307ffe0cc9  vmovaps [rsp+0x70], xmm7
000073307ffe0ccf  vmovaps [rsp+0x80], xmm8
000073307ffe0cd8  vmovaps [rsp+0x90], xmm9
000073307ffe0ce1  vmovaps [rsp+0xA0], xmm11
000073307ffe0cea  vmovaps [rsp+0xB0], xmm12
000073307ffe0cf3  vmovaps [rsp+0xC0], xmm13
000073307ffe0cfc  vmovaps [rsp+0xD0], xmm14
000073307ffe0d05  vmovaps [rsp+0xE0], xmm15
000073307ffe0d0e  sub rsp, 0x30
000073307ffe0d12  movaps [rsp], xmm10
000073307ffe0d17  movaps [rsp+0x10], xmm1
000073307ffe0d1c  movaps [rsp+0x20], xmm12
000073307ffe0d22  lea rdi, [rsp]
000073307ffe0d26  mov esi, 0x00
000073307ffe0d2b  mov rax, 0x600DE0EC8530
000073307ffe0d35  call rax
000073307ffe0d37  movaps xmm10, [rsp]
000073307ffe0d3c  add rsp, 0x30
000073307ffe0d40  vmovaps xmm0, [rsp]
000073307ffe0d45  vmovaps xmm1, [rsp+0x10]
000073307ffe0d4b  vmovaps xmm2, [rsp+0x20]
000073307ffe0d51  vmovaps xmm3, [rsp+0x30]
000073307ffe0d57  vmovaps xmm4, [rsp+0x40]
000073307ffe0d5d  vmovaps xmm5, [rsp+0x50]
000073307ffe0d63  vmovaps xmm6, [rsp+0x60]
000073307ffe0d69  vmovaps xmm7, [rsp+0x70]
000073307ffe0d6f  vmovaps xmm8, [rsp+0x80]
000073307ffe0d78  vmovaps xmm9, [rsp+0x90]
000073307ffe0d81  vmovaps xmm11, [rsp+0xA0]
000073307ffe0d8a  vmovaps xmm12, [rsp+0xB0]
000073307ffe0d93  vmovaps xmm13, [rsp+0xC0]
000073307ffe0d9c  vmovaps xmm14, [rsp+0xD0]
000073307ffe0da5  vmovaps xmm15, [rsp+0xE0]
000073307ffe0dae  add rsp, 0xF0
000073307ffe0db5  pop r11
000073307ffe0db7  pop r10
000073307ffe0db9  pop r9
000073307ffe0dbb  pop r8
000073307ffe0dbd  pop rsi
000073307ffe0dbe  pop rdi
000073307ffe0dbf  pop rdx
000073307ffe0dc0  pop rcx
000073307ffe0dc1  pop rax
000073307ffe0dc2  add rsp, 0x08
000073307ffe0dc6  jmp 0x000073307FFDC6CD
000073307ffe0dcb  sub rsp, 0x08
000073307ffe0dcf  push rax
000073307ffe0dd0  push rcx
000073307ffe0dd1  push rdx
000073307ffe0dd2  push rdi
000073307ffe0dd3  push rsi
000073307ffe0dd4  push r8
000073307ffe0dd6  push r9
000073307ffe0dd8  push r10
000073307ffe0dda  push r11
000073307ffe0ddc  sub rsp, 0xF0
000073307ffe0de3  vmovaps [rsp], xmm0
000073307ffe0de8  vmovaps [rsp+0x10], xmm1
000073307ffe0dee  vmovaps [rsp+0x20], xmm2
000073307ffe0df4  vmovaps [rsp+0x30], xmm3
000073307ffe0dfa  vmovaps [rsp+0x40], xmm4
000073307ffe0e00  vmovaps [rsp+0x50], xmm5
000073307ffe0e06  vmovaps [rsp+0x60], xmm6
000073307ffe0e0c  vmovaps [rsp+0x70], xmm7
000073307ffe0e12  vmovaps [rsp+0x80], xmm8
000073307ffe0e1b  vmovaps [rsp+0x90], xmm9
000073307ffe0e24  vmovaps [rsp+0xA0], xmm10
000073307ffe0e2d  vmovaps [rsp+0xB0], xmm11
000073307ffe0e36  vmovaps [rsp+0xC0], xmm13
000073307ffe0e3f  vmovaps [rsp+0xD0], xmm14
000073307ffe0e48  vmovaps [rsp+0xE0], xmm15
000073307ffe0e51  sub rsp, 0x30
000073307ffe0e55  movaps [rsp], xmm12
000073307ffe0e5a  movaps [rsp+0x10], xmm14
000073307ffe0e60  movaps [rsp+0x20], xmm1
000073307ffe0e65  lea rdi, [rsp]
000073307ffe0e69  mov esi, 0x00
000073307ffe0e6e  mov rax, 0x600DE0EC8530
000073307ffe0e78  call rax
000073307ffe0e7a  movaps xmm12, [rsp]
000073307ffe0e7f  add rsp, 0x30
000073307ffe0e83  vmovaps xmm0, [rsp]
000073307ffe0e88  vmovaps xmm1, [rsp+0x10]
000073307ffe0e8e  vmovaps xmm2, [rsp+0x20]
000073307ffe0e94  vmovaps xmm3, [rsp+0x30]
000073307ffe0e9a  vmovaps xmm4, [rsp+0x40]
000073307ffe0ea0  vmovaps xmm5, [rsp+0x50]
000073307ffe0ea6  vmovaps xmm6, [rsp+0x60]
000073307ffe0eac  vmovaps xmm7, [rsp+0x70]
000073307ffe0eb2  vmovaps xmm8, [rsp+0x80]
000073307ffe0ebb  vmovaps xmm9, [rsp+0x90]
000073307ffe0ec4  vmovaps xmm10, [rsp+0xA0]
000073307ffe0ecd  vmovaps xmm11, [rsp+0xB0]
000073307ffe0ed6  vmovaps xmm13, [rsp+0xC0]
000073307ffe0edf  vmovaps xmm14, [rsp+0xD0]
000073307ffe0ee8  vmovaps xmm15, [rsp+0xE0]
000073307ffe0ef1  add rsp, 0xF0
000073307ffe0ef8  pop r11
000073307ffe0efa  pop r10
000073307ffe0efc  pop r9
000073307ffe0efe  pop r8
000073307ffe0f00  pop rsi
000073307ffe0f01  pop rdi
000073307ffe0f02  pop rdx
000073307ffe0f03  pop rcx
000073307ffe0f04  pop rax
000073307ffe0f05  add rsp, 0x08
000073307ffe0f09  jmp 0x000073307FFDC6FC
000073307ffe0f0e  sub rsp, 0x08
000073307ffe0f12  push rax
000073307ffe0f13  push rcx
000073307ffe0f14  push rdx
000073307ffe0f15  push rdi
000073307ffe0f16  push rsi
000073307ffe0f17  push r8
000073307ffe0f19  push r9
000073307ffe0f1b  push r10
000073307ffe0f1d  push r11
000073307ffe0f1f  sub rsp, 0xF0
000073307ffe0f26  vmovaps [rsp], xmm0
000073307ffe0f2b  vmovaps [rsp+0x10], xmm1
000073307ffe0f31  vmovaps [rsp+0x20], xmm2
000073307ffe0f37  vmovaps [rsp+0x30], xmm3
000073307ffe0f3d  vmovaps [rsp+0x40], xmm4
000073307ffe0f43  vmovaps [rsp+0x50], xmm5
000073307ffe0f49  vmovaps [rsp+0x60], xmm6
000073307ffe0f4f  vmovaps [rsp+0x70], xmm7
000073307ffe0f55  vmovaps [rsp+0x80], xmm8
000073307ffe0f5e  vmovaps [rsp+0x90], xmm9
000073307ffe0f67  vmovaps [rsp+0xA0], xmm10
000073307ffe0f70  vmovaps [rsp+0xB0], xmm11
000073307ffe0f79  vmovaps [rsp+0xC0], xmm12
000073307ffe0f82  vmovaps [rsp+0xD0], xmm13
000073307ffe0f8b  vmovaps [rsp+0xE0], xmm15
000073307ffe0f94  sub rsp, 0x30
000073307ffe0f98  movaps [rsp], xmm14
000073307ffe0f9d  movaps [rsp+0x10], xmm9
000073307ffe0fa3  movaps [rsp+0x20], xmm1
000073307ffe0fa8  lea rdi, [rsp]
000073307ffe0fac  mov esi, 0x00
000073307ffe0fb1  mov rax, 0x600DE0EC8530
000073307ffe0fbb  call rax
000073307ffe0fbd  movaps xmm14, [rsp]
000073307ffe0fc2  add rsp, 0x30
000073307ffe0fc6  vmovaps xmm0, [rsp]
000073307ffe0fcb  vmovaps xmm1, [rsp+0x10]
000073307ffe0fd1  vmovaps xmm2, [rsp+0x20]
000073307ffe0fd7  vmovaps xmm3, [rsp+0x30]
000073307ffe0fdd  vmovaps xmm4, [rsp+0x40]
000073307ffe0fe3  vmovaps xmm5, [rsp+0x50]
000073307ffe0fe9  vmovaps xmm6, [rsp+0x60]
000073307ffe0fef  vmovaps xmm7, [rsp+0x70]
000073307ffe0ff5  vmovaps xmm8, [rsp+0x80]
000073307ffe0ffe  vmovaps xmm9, [rsp+0x90]
000073307ffe1007  vmovaps xmm10, [rsp+0xA0]
000073307ffe1010  vmovaps xmm11, [rsp+0xB0]
000073307ffe1019  vmovaps xmm12, [rsp+0xC0]
000073307ffe1022  vmovaps xmm13, [rsp+0xD0]
000073307ffe102b  vmovaps xmm15, [rsp+0xE0]
000073307ffe1034  add rsp, 0xF0
000073307ffe103b  pop r11
000073307ffe103d  pop r10
000073307ffe103f  pop r9
000073307ffe1041  pop r8
000073307ffe1043  pop rsi
000073307ffe1044  pop rdi
000073307ffe1045  pop rdx
000073307ffe1046  pop rcx
000073307ffe1047  pop rax
000073307ffe1048  add rsp, 0x08
000073307ffe104c  jmp 0x000073307FFDC72B
000073307ffe1051  sub rsp, 0x08
000073307ffe1055  push rax
000073307ffe1056  push rcx
000073307ffe1057  push rdx
000073307ffe1058  push rdi
000073307ffe1059  push rsi
000073307ffe105a  push r8
000073307ffe105c  push r9
000073307ffe105e  push r10
000073307ffe1060  push r11
000073307ffe1062  sub rsp, 0xF0
000073307ffe1069  vmovaps [rsp], xmm0
000073307ffe106e  vmovaps [rsp+0x10], xmm2
000073307ffe1074  vmovaps [rsp+0x20], xmm3
000073307ffe107a  vmovaps [rsp+0x30], xmm4
000073307ffe1080  vmovaps [rsp+0x40], xmm5
000073307ffe1086  vmovaps [rsp+0x50], xmm6
000073307ffe108c  vmovaps [rsp+0x60], xmm7
000073307ffe1092  vmovaps [rsp+0x70], xmm8
000073307ffe1098  vmovaps [rsp+0x80], xmm9
000073307ffe10a1  vmovaps [rsp+0x90], xmm10
000073307ffe10aa  vmovaps [rsp+0xA0], xmm11
000073307ffe10b3  vmovaps [rsp+0xB0], xmm12
000073307ffe10bc  vmovaps [rsp+0xC0], xmm13
000073307ffe10c5  vmovaps [rsp+0xD0], xmm14
000073307ffe10ce  vmovaps [rsp+0xE0], xmm15
000073307ffe10d7  sub rsp, 0x30
000073307ffe10db  movaps [rsp], xmm1
000073307ffe10df  movaps [rsp+0x10], xmm13
000073307ffe10e5  movaps [rsp+0x20], xmm8
000073307ffe10eb  lea rdi, [rsp]
000073307ffe10ef  mov esi, 0x00
000073307ffe10f4  mov rax, 0x600DE0EC8530
000073307ffe10fe  call rax
000073307ffe1100  movaps xmm1, [rsp]
000073307ffe1104  add rsp, 0x30
000073307ffe1108  vmovaps xmm0, [rsp]
000073307ffe110d  vmovaps xmm2, [rsp+0x10]
000073307ffe1113  vmovaps xmm3, [rsp+0x20]
000073307ffe1119  vmovaps xmm4, [rsp+0x30]
000073307ffe111f  vmovaps xmm5, [rsp+0x40]
000073307ffe1125  vmovaps xmm6, [rsp+0x50]
000073307ffe112b  vmovaps xmm7, [rsp+0x60]
000073307ffe1131  vmovaps xmm8, [rsp+0x70]
000073307ffe1137  vmovaps xmm9, [rsp+0x80]
000073307ffe1140  vmovaps xmm10, [rsp+0x90]
000073307ffe1149  vmovaps xmm11, [rsp+0xA0]
000073307ffe1152  vmovaps xmm12, [rsp+0xB0]
000073307ffe115b  vmovaps xmm13, [rsp+0xC0]
000073307ffe1164  vmovaps xmm14, [rsp+0xD0]
000073307ffe116d  vmovaps xmm15, [rsp+0xE0]
000073307ffe1176  add rsp, 0xF0
000073307ffe117d  pop r11
000073307ffe117f  pop r10
000073307ffe1181  pop r9
000073307ffe1183  pop r8
000073307ffe1185  pop rsi
000073307ffe1186  pop rdi
000073307ffe1187  pop rdx
000073307ffe1188  pop rcx
000073307ffe1189  pop rax
000073307ffe118a  add rsp, 0x08
000073307ffe118e  jmp 0x000073307FFDC74D
000073307ffe1193  call 0x000073307FE0C260
000073307ffe1198  jmp 0x000073307FFDC75B
000073307ffe119d  call 0x000073307FEBD750
000073307ffe11a2  jmp 0x000073307FFDC765
000073307ffe11a7  sub rsp, 0x08
000073307ffe11ab  push rax
000073307ffe11ac  push rcx
000073307ffe11ad  push rdx
000073307ffe11ae  push rdi
000073307ffe11af  push rsi
000073307ffe11b0  push r8
000073307ffe11b2  push r9
000073307ffe11b4  push r10
000073307ffe11b6  push r11
000073307ffe11b8  sub rsp, 0xF0
000073307ffe11bf  vmovaps [rsp], xmm0
000073307ffe11c4  vmovaps [rsp+0x10], xmm1
000073307ffe11ca  vmovaps [rsp+0x20], xmm2
000073307ffe11d0  vmovaps [rsp+0x30], xmm3
000073307ffe11d6  vmovaps [rsp+0x40], xmm4
000073307ffe11dc  vmovaps [rsp+0x50], xmm5
000073307ffe11e2  vmovaps [rsp+0x60], xmm6
000073307ffe11e8  vmovaps [rsp+0x70], xmm7
000073307ffe11ee  vmovaps [rsp+0x80], xmm9
000073307ffe11f7  vmovaps [rsp+0x90], xmm10
000073307ffe1200  vmovaps [rsp+0xA0], xmm11
000073307ffe1209  vmovaps [rsp+0xB0], xmm12
000073307ffe1212  vmovaps [rsp+0xC0], xmm13
000073307ffe121b  vmovaps [rsp+0xD0], xmm14
000073307ffe1224  vmovaps [rsp+0xE0], xmm15
000073307ffe122d  sub rsp, 0x30
000073307ffe1231  movaps [rsp], xmm8
000073307ffe1236  movaps [rsp+0x10], xmm15
000073307ffe123c  movaps [rsp+0x20], xmm7
000073307ffe1241  lea rdi, [rsp]
000073307ffe1245  mov esi, 0x00
000073307ffe124a  mov rax, 0x600DE0EC8530
000073307ffe1254  call rax
000073307ffe1256  movaps xmm8, [rsp]
000073307ffe125b  add rsp, 0x30
000073307ffe125f  vmovaps xmm0, [rsp]
000073307ffe1264  vmovaps xmm1, [rsp+0x10]
000073307ffe126a  vmovaps xmm2, [rsp+0x20]
000073307ffe1270  vmovaps xmm3, [rsp+0x30]
000073307ffe1276  vmovaps xmm4, [rsp+0x40]
000073307ffe127c  vmovaps xmm5, [rsp+0x50]
000073307ffe1282  vmovaps xmm6, [rsp+0x60]
000073307ffe1288  vmovaps xmm7, [rsp+0x70]
000073307ffe128e  vmovaps xmm9, [rsp+0x80]
000073307ffe1297  vmovaps xmm10, [rsp+0x90]
000073307ffe12a0  vmovaps xmm11, [rsp+0xA0]
000073307ffe12a9  vmovaps xmm12, [rsp+0xB0]
000073307ffe12b2  vmovaps xmm13, [rsp+0xC0]
000073307ffe12bb  vmovaps xmm14, [rsp+0xD0]
000073307ffe12c4  vmovaps xmm15, [rsp+0xE0]
000073307ffe12cd  add rsp, 0xF0
000073307ffe12d4  pop r11
000073307ffe12d6  pop r10
000073307ffe12d8  pop r9
000073307ffe12da  pop r8
000073307ffe12dc  pop rsi
000073307ffe12dd  pop rdi
000073307ffe12de  pop rdx
000073307ffe12df  pop rcx
000073307ffe12e0  pop rax
000073307ffe12e1  add rsp, 0x08
000073307ffe12e5  jmp 0x000073307FFDC787
000073307ffe12ea  sub rsp, 0x08
000073307ffe12ee  push rax
000073307ffe12ef  push rcx
000073307ffe12f0  push rdx
000073307ffe12f1  push rdi
000073307ffe12f2  push rsi
000073307ffe12f3  push r8
000073307ffe12f5  push r9
000073307ffe12f7  push r10
000073307ffe12f9  push r11
000073307ffe12fb  sub rsp, 0xF0
000073307ffe1302  vmovaps [rsp], xmm0
000073307ffe1307  vmovaps [rsp+0x10], xmm1
000073307ffe130d  vmovaps [rsp+0x20], xmm2
000073307ffe1313  vmovaps [rsp+0x30], xmm3
000073307ffe1319  vmovaps [rsp+0x40], xmm4
000073307ffe131f  vmovaps [rsp+0x50], xmm5
000073307ffe1325  vmovaps [rsp+0x60], xmm6
000073307ffe132b  vmovaps [rsp+0x70], xmm8
000073307ffe1331  vmovaps [rsp+0x80], xmm9
000073307ffe133a  vmovaps [rsp+0x90], xmm10
000073307ffe1343  vmovaps [rsp+0xA0], xmm11
000073307ffe134c  vmovaps [rsp+0xB0], xmm12
000073307ffe1355  vmovaps [rsp+0xC0], xmm13
000073307ffe135e  vmovaps [rsp+0xD0], xmm14
000073307ffe1367  vmovaps [rsp+0xE0], xmm15
000073307ffe1370  sub rsp, 0x30
000073307ffe1374  movaps [rsp], xmm7
000073307ffe1378  movaps [rsp+0x10], xmm9
000073307ffe137e  movaps [rsp+0x20], xmm15
000073307ffe1384  lea rdi, [rsp]
000073307ffe1388  mov esi, 0x00
000073307ffe138d  mov rax, 0x600DE0EC8530
000073307ffe1397  call rax
000073307ffe1399  movaps xmm7, [rsp]
000073307ffe139d  add rsp, 0x30
000073307ffe13a1  vmovaps xmm0, [rsp]
000073307ffe13a6  vmovaps xmm1, [rsp+0x10]
000073307ffe13ac  vmovaps xmm2, [rsp+0x20]
000073307ffe13b2  vmovaps xmm3, [rsp+0x30]
000073307ffe13b8  vmovaps xmm4, [rsp+0x40]
000073307ffe13be  vmovaps xmm5, [rsp+0x50]
000073307ffe13c4  vmovaps xmm6, [rsp+0x60]
000073307ffe13ca  vmovaps xmm8, [rsp+0x70]
000073307ffe13d0  vmovaps xmm9, [rsp+0x80]
000073307ffe13d9  vmovaps xmm10, [rsp+0x90]
000073307ffe13e2  vmovaps xmm11, [rsp+0xA0]
000073307ffe13eb  vmovaps xmm12, [rsp+0xB0]
000073307ffe13f4  vmovaps xmm13, [rsp+0xC0]
000073307ffe13fd  vmovaps xmm14, [rsp+0xD0]
000073307ffe1406  vmovaps xmm15, [rsp+0xE0]
000073307ffe140f  add rsp, 0xF0
000073307ffe1416  pop r11
000073307ffe1418  pop r10
000073307ffe141a  pop r9
000073307ffe141c  pop r8
000073307ffe141e  pop rsi
000073307ffe141f  pop rdi
000073307ffe1420  pop rdx
000073307ffe1421  pop rcx
000073307ffe1422  pop rax
000073307ffe1423  add rsp, 0x08
000073307ffe1427  jmp 0x000073307FFDC7B4
000073307ffe142c  sub rsp, 0x08
000073307ffe1430  push rax
000073307ffe1431  push rcx
000073307ffe1432  push rdx
000073307ffe1433  push rdi
000073307ffe1434  push rsi
000073307ffe1435  push r8
000073307ffe1437  push r9
000073307ffe1439  push r10
000073307ffe143b  push r11
000073307ffe143d  sub rsp, 0xF0
000073307ffe1444  vmovaps [rsp], xmm0
000073307ffe1449  vmovaps [rsp+0x10], xmm1
000073307ffe144f  vmovaps [rsp+0x20], xmm2
000073307ffe1455  vmovaps [rsp+0x30], xmm3
000073307ffe145b  vmovaps [rsp+0x40], xmm4
000073307ffe1461  vmovaps [rsp+0x50], xmm5
000073307ffe1467  vmovaps [rsp+0x60], xmm6
000073307ffe146d  vmovaps [rsp+0x70], xmm7
000073307ffe1473  vmovaps [rsp+0x80], xmm8
000073307ffe147c  vmovaps [rsp+0x90], xmm10
000073307ffe1485  vmovaps [rsp+0xA0], xmm11
000073307ffe148e  vmovaps [rsp+0xB0], xmm12
000073307ffe1497  vmovaps [rsp+0xC0], xmm13
000073307ffe14a0  vmovaps [rsp+0xD0], xmm14
000073307ffe14a9  vmovaps [rsp+0xE0], xmm15
000073307ffe14b2  sub rsp, 0x30
000073307ffe14b6  movaps [rsp], xmm9
000073307ffe14bb  movaps [rsp+0x10], xmm13
000073307ffe14c1  movaps [rsp+0x20], xmm15
000073307ffe14c7  lea rdi, [rsp]
000073307ffe14cb  mov esi, 0x00
000073307ffe14d0  mov rax, 0x600DE0EC8530
000073307ffe14da  call rax
000073307ffe14dc  movaps xmm9, [rsp]
000073307ffe14e1  add rsp, 0x30
000073307ffe14e5  vmovaps xmm0, [rsp]
000073307ffe14ea  vmovaps xmm1, [rsp+0x10]
000073307ffe14f0  vmovaps xmm2, [rsp+0x20]
000073307ffe14f6  vmovaps xmm3, [rsp+0x30]
000073307ffe14fc  vmovaps xmm4, [rsp+0x40]
000073307ffe1502  vmovaps xmm5, [rsp+0x50]
000073307ffe1508  vmovaps xmm6, [rsp+0x60]
000073307ffe150e  vmovaps xmm7, [rsp+0x70]
000073307ffe1514  vmovaps xmm8, [rsp+0x80]
000073307ffe151d  vmovaps xmm10, [rsp+0x90]
000073307ffe1526  vmovaps xmm11, [rsp+0xA0]
000073307ffe152f  vmovaps xmm12, [rsp+0xB0]
000073307ffe1538  vmovaps xmm13, [rsp+0xC0]
000073307ffe1541  vmovaps xmm14, [rsp+0xD0]
000073307ffe154a  vmovaps xmm15, [rsp+0xE0]
000073307ffe1553  add rsp, 0xF0
000073307ffe155a  pop r11
000073307ffe155c  pop r10
000073307ffe155e  pop r9
000073307ffe1560  pop r8
000073307ffe1562  pop rsi
000073307ffe1563  pop rdi
000073307ffe1564  pop rdx
000073307ffe1565  pop rcx
000073307ffe1566  pop rax
000073307ffe1567  add rsp, 0x08
000073307ffe156b  jmp 0x000073307FFDC7E2
000073307ffe1570  sub rsp, 0x08
000073307ffe1574  push rax
000073307ffe1575  push rcx
000073307ffe1576  push rdx
000073307ffe1577  push rdi
000073307ffe1578  push rsi
000073307ffe1579  push r8
000073307ffe157b  push r9
000073307ffe157d  push r10
000073307ffe157f  push r11
000073307ffe1581  sub rsp, 0xF0
000073307ffe1588  vmovaps [rsp], xmm0
000073307ffe158d  vmovaps [rsp+0x10], xmm1
000073307ffe1593  vmovaps [rsp+0x20], xmm2
000073307ffe1599  vmovaps [rsp+0x30], xmm3
000073307ffe159f  vmovaps [rsp+0x40], xmm4
000073307ffe15a5  vmovaps [rsp+0x50], xmm5
000073307ffe15ab  vmovaps [rsp+0x60], xmm6
000073307ffe15b1  vmovaps [rsp+0x70], xmm7
000073307ffe15b7  vmovaps [rsp+0x80], xmm8
000073307ffe15c0  vmovaps [rsp+0x90], xmm9
000073307ffe15c9  vmovaps [rsp+0xA0], xmm10
000073307ffe15d2  vmovaps [rsp+0xB0], xmm11
000073307ffe15db  vmovaps [rsp+0xC0], xmm12
000073307ffe15e4  vmovaps [rsp+0xD0], xmm13
000073307ffe15ed  vmovaps [rsp+0xE0], xmm14
000073307ffe15f6  sub rsp, 0x30
000073307ffe15fa  movaps [rsp], xmm15
000073307ffe15ff  movaps [rsp+0x10], xmm11
000073307ffe1605  movaps [rsp+0x20], xmm12
000073307ffe160b  lea rdi, [rsp]
000073307ffe160f  mov esi, 0x00
000073307ffe1614  mov rax, 0x600DE0EC8530
000073307ffe161e  call rax
000073307ffe1620  movaps xmm15, [rsp]
000073307ffe1625  add rsp, 0x30
000073307ffe1629  vmovaps xmm0, [rsp]
000073307ffe162e  vmovaps xmm1, [rsp+0x10]
000073307ffe1634  vmovaps xmm2, [rsp+0x20]
000073307ffe163a  vmovaps xmm3, [rsp+0x30]
000073307ffe1640  vmovaps xmm4, [rsp+0x40]
000073307ffe1646  vmovaps xmm5, [rsp+0x50]
000073307ffe164c  vmovaps xmm6, [rsp+0x60]
000073307ffe1652  vmovaps xmm7, [rsp+0x70]
000073307ffe1658  vmovaps xmm8, [rsp+0x80]
000073307ffe1661  vmovaps xmm9, [rsp+0x90]
000073307ffe166a  vmovaps xmm10, [rsp+0xA0]
000073307ffe1673  vmovaps xmm11, [rsp+0xB0]
000073307ffe167c  vmovaps xmm12, [rsp+0xC0]
000073307ffe1685  vmovaps xmm13, [rsp+0xD0]
000073307ffe168e  vmovaps xmm14, [rsp+0xE0]
000073307ffe1697  add rsp, 0xF0
000073307ffe169e  pop r11
000073307ffe16a0  pop r10
000073307ffe16a2  pop r9
000073307ffe16a4  pop r8
000073307ffe16a6  pop rsi
000073307ffe16a7  pop rdi
000073307ffe16a8  pop rdx
000073307ffe16a9  pop rcx
000073307ffe16aa  pop rax
000073307ffe16ab  add rsp, 0x08
000073307ffe16af  jmp 0x000073307FFDC7FD
000073307ffe16b4  sub rsp, 0x08
000073307ffe16b8  push rax
000073307ffe16b9  push rcx
000073307ffe16ba  push rdx
000073307ffe16bb  push rdi
000073307ffe16bc  push rsi
000073307ffe16bd  push r8
000073307ffe16bf  push r9
000073307ffe16c1  push r10
000073307ffe16c3  push r11
000073307ffe16c5  sub rsp, 0xF0
000073307ffe16cc  vmovaps [rsp], xmm0
000073307ffe16d1  vmovaps [rsp+0x10], xmm1
000073307ffe16d7  vmovaps [rsp+0x20], xmm2
000073307ffe16dd  vmovaps [rsp+0x30], xmm3
000073307ffe16e3  vmovaps [rsp+0x40], xmm4
000073307ffe16e9  vmovaps [rsp+0x50], xmm5
000073307ffe16ef  vmovaps [rsp+0x60], xmm6
000073307ffe16f5  vmovaps [rsp+0x70], xmm7
000073307ffe16fb  vmovaps [rsp+0x80], xmm8
000073307ffe1704  vmovaps [rsp+0x90], xmm9
000073307ffe170d  vmovaps [rsp+0xA0], xmm10
000073307ffe1716  vmovaps [rsp+0xB0], xmm11
000073307ffe171f  vmovaps [rsp+0xC0], xmm12
000073307ffe1728  vmovaps [rsp+0xD0], xmm14
000073307ffe1731  vmovaps [rsp+0xE0], xmm15
000073307ffe173a  sub rsp, 0x30
000073307ffe173e  movaps [rsp], xmm13
000073307ffe1743  movaps [rsp+0x10], xmm10
000073307ffe1749  movaps [rsp+0x20], xmm14
000073307ffe174f  lea rdi, [rsp]
000073307ffe1753  mov esi, 0x00
000073307ffe1758  mov rax, 0x600DE0EC8530
000073307ffe1762  call rax
000073307ffe1764  movaps xmm13, [rsp]
000073307ffe1769  add rsp, 0x30
000073307ffe176d  vmovaps xmm0, [rsp]
000073307ffe1772  vmovaps xmm1, [rsp+0x10]
000073307ffe1778  vmovaps xmm2, [rsp+0x20]
000073307ffe177e  vmovaps xmm3, [rsp+0x30]
000073307ffe1784  vmovaps xmm4, [rsp+0x40]
000073307ffe178a  vmovaps xmm5, [rsp+0x50]
000073307ffe1790  vmovaps xmm6, [rsp+0x60]
000073307ffe1796  vmovaps xmm7, [rsp+0x70]
000073307ffe179c  vmovaps xmm8, [rsp+0x80]
000073307ffe17a5  vmovaps xmm9, [rsp+0x90]
000073307ffe17ae  vmovaps xmm10, [rsp+0xA0]
000073307ffe17b7  vmovaps xmm11, [rsp+0xB0]
000073307ffe17c0  vmovaps xmm12, [rsp+0xC0]
000073307ffe17c9  vmovaps xmm14, [rsp+0xD0]
000073307ffe17d2  vmovaps xmm15, [rsp+0xE0]
000073307ffe17db  add rsp, 0xF0
000073307ffe17e2  pop r11
000073307ffe17e4  pop r10
000073307ffe17e6  pop r9
000073307ffe17e8  pop r8
000073307ffe17ea  pop rsi
000073307ffe17eb  pop rdi
000073307ffe17ec  pop rdx
000073307ffe17ed  pop rcx
000073307ffe17ee  pop rax
000073307ffe17ef  add rsp, 0x08
000073307ffe17f3  jmp 0x000073307FFDC820
000073307ffe17f8  sub rsp, 0x08
000073307ffe17fc  push rax
000073307ffe17fd  push rcx
000073307ffe17fe  push rdx
000073307ffe17ff  push rdi
000073307ffe1800  push rsi
000073307ffe1801  push r8
000073307ffe1803  push r9
000073307ffe1805  push r10
000073307ffe1807  push r11
000073307ffe1809  sub rsp, 0xF0
000073307ffe1810  vmovaps [rsp], xmm0
000073307ffe1815  vmovaps [rsp+0x10], xmm1
000073307ffe181b  vmovaps [rsp+0x20], xmm2
000073307ffe1821  vmovaps [rsp+0x30], xmm3
000073307ffe1827  vmovaps [rsp+0x40], xmm4
000073307ffe182d  vmovaps [rsp+0x50], xmm5
000073307ffe1833  vmovaps [rsp+0x60], xmm6
000073307ffe1839  vmovaps [rsp+0x70], xmm7
000073307ffe183f  vmovaps [rsp+0x80], xmm8
000073307ffe1848  vmovaps [rsp+0x90], xmm9
000073307ffe1851  vmovaps [rsp+0xA0], xmm10
000073307ffe185a  vmovaps [rsp+0xB0], xmm11
000073307ffe1863  vmovaps [rsp+0xC0], xmm12
000073307ffe186c  vmovaps [rsp+0xD0], xmm13
000073307ffe1875  vmovaps [rsp+0xE0], xmm15
000073307ffe187e  sub rsp, 0x30
000073307ffe1882  movaps [rsp], xmm14
000073307ffe1887  movaps [rsp+0x10], xmm1
000073307ffe188c  movaps [rsp+0x20], xmm7
000073307ffe1891  lea rdi, [rsp]
000073307ffe1895  mov esi, 0x00
000073307ffe189a  mov rax, 0x600DE0EC8530
000073307ffe18a4  call rax
000073307ffe18a6  movaps xmm14, [rsp]
000073307ffe18ab  add rsp, 0x30
000073307ffe18af  vmovaps xmm0, [rsp]
000073307ffe18b4  vmovaps xmm1, [rsp+0x10]
000073307ffe18ba  vmovaps xmm2, [rsp+0x20]
000073307ffe18c0  vmovaps xmm3, [rsp+0x30]
000073307ffe18c6  vmovaps xmm4, [rsp+0x40]
000073307ffe18cc  vmovaps xmm5, [rsp+0x50]
000073307ffe18d2  vmovaps xmm6, [rsp+0x60]
000073307ffe18d8  vmovaps xmm7, [rsp+0x70]
000073307ffe18de  vmovaps xmm8, [rsp+0x80]
000073307ffe18e7  vmovaps xmm9, [rsp+0x90]
000073307ffe18f0  vmovaps xmm10, [rsp+0xA0]
000073307ffe18f9  vmovaps xmm11, [rsp+0xB0]
000073307ffe1902  vmovaps xmm12, [rsp+0xC0]
000073307ffe190b  vmovaps xmm13, [rsp+0xD0]
000073307ffe1914  vmovaps xmm15, [rsp+0xE0]
000073307ffe191d  add rsp, 0xF0
000073307ffe1924  pop r11
000073307ffe1926  pop r10
000073307ffe1928  pop r9
000073307ffe192a  pop r8
000073307ffe192c  pop rsi
000073307ffe192d  pop rdi
000073307ffe192e  pop rdx
000073307ffe192f  pop rcx
000073307ffe1930  pop rax
000073307ffe1931  add rsp, 0x08
000073307ffe1935  jmp 0x000073307FFDC843
000073307ffe193a  sub rsp, 0x08
000073307ffe193e  push rax
000073307ffe193f  push rcx
000073307ffe1940  push rdx
000073307ffe1941  push rdi
000073307ffe1942  push rsi
000073307ffe1943  push r8
000073307ffe1945  push r9
000073307ffe1947  push r10
000073307ffe1949  push r11
000073307ffe194b  sub rsp, 0xF0
000073307ffe1952  vmovaps [rsp], xmm0
000073307ffe1957  vmovaps [rsp+0x10], xmm2
000073307ffe195d  vmovaps [rsp+0x20], xmm3
000073307ffe1963  vmovaps [rsp+0x30], xmm4
000073307ffe1969  vmovaps [rsp+0x40], xmm5
000073307ffe196f  vmovaps [rsp+0x50], xmm6
000073307ffe1975  vmovaps [rsp+0x60], xmm7
000073307ffe197b  vmovaps [rsp+0x70], xmm8
000073307ffe1981  vmovaps [rsp+0x80], xmm9
000073307ffe198a  vmovaps [rsp+0x90], xmm10
000073307ffe1993  vmovaps [rsp+0xA0], xmm11
000073307ffe199c  vmovaps [rsp+0xB0], xmm12
000073307ffe19a5  vmovaps [rsp+0xC0], xmm13
000073307ffe19ae  vmovaps [rsp+0xD0], xmm14
000073307ffe19b7  vmovaps [rsp+0xE0], xmm15
000073307ffe19c0  sub rsp, 0x30
000073307ffe19c4  movaps [rsp], xmm1
000073307ffe19c8  movaps [rsp+0x10], xmm8
000073307ffe19ce  movaps [rsp+0x20], xmm9
000073307ffe19d4  lea rdi, [rsp]
000073307ffe19d8  mov esi, 0x00
000073307ffe19dd  mov rax, 0x600DE0EC8530
000073307ffe19e7  call rax
000073307ffe19e9  movaps xmm1, [rsp]
000073307ffe19ed  add rsp, 0x30
000073307ffe19f1  vmovaps xmm0, [rsp]
000073307ffe19f6  vmovaps xmm2, [rsp+0x10]
000073307ffe19fc  vmovaps xmm3, [rsp+0x20]
000073307ffe1a02  vmovaps xmm4, [rsp+0x30]
000073307ffe1a08  vmovaps xmm5, [rsp+0x40]
000073307ffe1a0e  vmovaps xmm6, [rsp+0x50]
000073307ffe1a14  vmovaps xmm7, [rsp+0x60]
000073307ffe1a1a  vmovaps xmm8, [rsp+0x70]
000073307ffe1a20  vmovaps xmm9, [rsp+0x80]
000073307ffe1a29  vmovaps xmm10, [rsp+0x90]
000073307ffe1a32  vmovaps xmm11, [rsp+0xA0]
000073307ffe1a3b  vmovaps xmm12, [rsp+0xB0]
000073307ffe1a44  vmovaps xmm13, [rsp+0xC0]
000073307ffe1a4d  vmovaps xmm14, [rsp+0xD0]
000073307ffe1a56  vmovaps xmm15, [rsp+0xE0]
000073307ffe1a5f  add rsp, 0xF0
000073307ffe1a66  pop r11
000073307ffe1a68  pop r10
000073307ffe1a6a  pop r9
000073307ffe1a6c  pop r8
000073307ffe1a6e  pop rsi
000073307ffe1a6f  pop rdi
000073307ffe1a70  pop rdx
000073307ffe1a71  pop rcx
000073307ffe1a72  pop rax
000073307ffe1a73  add rsp, 0x08
000073307ffe1a77  jmp 0x000073307FFDC865
000073307ffe1a7c  call 0x000073307FEE5940
000073307ffe1a81  jmp 0x000073307FFDC873
000073307ffe1a86  call 0x000073307FE0C380
000073307ffe1a8b  jmp 0x000073307FFDC87D
000073307ffe1a90  call 0x000073307FE0D600
000073307ffe1a95  jmp 0x000073307FFDC887
000073307ffe1a9a  call 0x000073307FDFF540
000073307ffe1a9f  jmp 0x000073307FFDC891
000073307ffe1aa4  int3
000073307ffe1aa5  nop [rax+rax*1], ax
000073307ffe1aae  nop
000073307ffe1ab0  mov rax, [r15+0xF8]
000073307ffe1ab7  lea r14, [rax+0x140]
000073307ffe1abe  mov r12, [r13+r14*1]
000073307ffe1ac3  mov [r15+0xE8], r12
000073307ffe1aca  lea r14, [rax+0x130]
000073307ffe1ad1  mov r12, [r13+r14*1]
000073307ffe1ad6  lea r14, [rax+0x138]
000073307ffe1add  mov r11, [r13+r14*1]
000073307ffe1ae2  movq xmm1, r12
000073307ffe1ae7  movq xmm15, r11
000073307ffe1aec  movq xmm1, xmm1
000073307ffe1af0  movq xmm1, xmm1
000073307ffe1af4  movaps [r15+0x1A0], xmm1
000073307ffe1afc  movq xmm15, xmm15
000073307ffe1b01  movq xmm15, xmm15
000073307ffe1b06  movaps [r15+0x190], xmm15
000073307ffe1b0e  lea r14, [rax+0x120]
000073307ffe1b15  mov r12, [r13+r14*1]
000073307ffe1b1a  lea r14, [rax+0x128]
000073307ffe1b21  mov r11, [r13+r14*1]
000073307ffe1b26  movq xmm1, r12
000073307ffe1b2b  movq xmm15, r11
000073307ffe1b30  movq xmm1, xmm1
000073307ffe1b34  movq xmm1, xmm1
000073307ffe1b38  movaps [r15+0x1C0], xmm1
000073307ffe1b40  movq xmm15, xmm15
000073307ffe1b45  movq xmm15, xmm15
000073307ffe1b4a  movaps [r15+0x1B0], xmm15
000073307ffe1b52  lea r14, [rax+0x110]
000073307ffe1b59  mov r12, [r13+r14*1]
000073307ffe1b5e  lea r14, [rax+0x118]
000073307ffe1b65  mov r11, [r13+r14*1]
000073307ffe1b6a  movq xmm1, r12
000073307ffe1b6f  movq xmm15, r11
000073307ffe1b74  movq xmm1, xmm1
000073307ffe1b78  movq xmm1, xmm1
000073307ffe1b7c  movaps [r15+0x1E0], xmm1
000073307ffe1b84  movq xmm15, xmm15
000073307ffe1b89  movq xmm15, xmm15
000073307ffe1b8e  movaps [r15+0x1D0], xmm15
000073307ffe1b96  lea r14, [rax+0x100]
000073307ffe1b9d  mov r12, [r13+r14*1]
000073307ffe1ba2  lea r14, [rax+0x108]
000073307ffe1ba9  mov r11, [r13+r14*1]
000073307ffe1bae  movq xmm1, r12
000073307ffe1bb3  movq xmm15, r11
000073307ffe1bb8  movq xmm1, xmm1
000073307ffe1bbc  movq xmm1, xmm1
000073307ffe1bc0  movaps [r15+0x200], xmm1
000073307ffe1bc8  movq xmm15, xmm15
000073307ffe1bcd  movq xmm15, xmm15
000073307ffe1bd2  movaps [r15+0x1F0], xmm15
000073307ffe1bda  mov qword ptr [r15+0x40], 0x430000
000073307ffe1be2  mov r14d, 0x430510
000073307ffe1be8  mov r12, [r13+r14*1]
000073307ffe1bed  movq xmm1, r12
000073307ffe1bf2  lea r14, [rax+0x150]
000073307ffe1bf9  mov [r15+0xF8], r14
000073307ffe1c00  mov rax, [r15+0x50]
000073307ffe1c04  movups xmm15, [r13+rax*1]
000073307ffe1c0a  movaps [r15+0x120], xmm15
000073307ffe1c12  mov qword ptr [r15+0x48], 0x10
000073307ffe1c1a  xor eax, eax
000073307ffe1c1c  mov r14d, 0x10
000073307ffe1c22  mov r12d, 0x200
000073307ffe1c28  cmp r14, r12
000073307ffe1c2b  cmc
000073307ffe1c2c  lahf
000073307ffe1c2d  seto al
000073307ffe1c30  mov [r15+0x108], eax
000073307ffe1c37  pextrq rax, xmm15, 0x01
000073307ffe1c3e  movq xmm14, rax
000073307ffe1c43  movaps [r15+0x130], xmm14
000073307ffe1c4b  movq rax, xmm1
000073307ffe1c50  movq r14, xmm15
000073307ffe1c55  vmovq xmm1, rax
000073307ffe1c5a  vmovq xmm15, r14
000073307ffe1c5f  movaps xmm13, xmm1
000073307ffe1c63  addsd xmm13, xmm15
000073307ffe1c68  ucomisd xmm13, xmm13
000073307ffe1c6d  jp 0x000073307FFE1D86
000073307ffe1c73  movq xmm13, xmm13
000073307ffe1c78  movq rax, xmm13
000073307ffe1c7d  movq r14, xmm14
000073307ffe1c82  vmovq xmm1, rax
000073307ffe1c87  vmovq xmm15, r14
000073307ffe1c8c  movaps xmm14, xmm1
000073307ffe1c90  addsd xmm14, xmm15
000073307ffe1c95  ucomisd xmm14, xmm14
000073307ffe1c9a  jp 0x000073307FFE1DCE
000073307ffe1ca0  movq xmm14, xmm14
000073307ffe1ca5  movaps [r15+0x110], xmm14
000073307ffe1cad  mov eax, [r15+0x108]
000073307ffe1cb4  sahf
000073307ffe1cb5  jnz 0x000073307FFE1CE7
000073307ffe1cb7  cmp dword ptr [r15+0x318], 0x00
000073307ffe1cbf  jz 0x000073307FFE1FE0
000073307ffe1cc5  nop [rax+rax*1], ax
000073307ffe1cce  nop [rax+rax*1], eax
000073307ffe1cd6  mov eax, 0x410490
000073307ffe1cdb  mov [r15+0x100], rax
000073307ffe1ce2  jmp 0x000073307FDFE110
000073307ffe1ce7  cmp dword ptr [r15+0x318], 0x00
000073307ffe1cef  jz 0x000073307FFE1E20
000073307ffe1cf5  nop [rax+rax*1], ax
000073307ffe1cfe  nop [rax+rax*1], eax
000073307ffe1d06  mov eax, 0x410474
000073307ffe1d0b  mov [r15+0x100], rax
000073307ffe1d12  jmp 0x000073307FDFE110
000073307ffe1d17  int3
000073307ffe1d18  call 0x000073307FEE27E0
000073307ffe1d1d  jmp 0x000073307FFE1AC3
000073307ffe1d22  call 0x000073307FEE27E0
000073307ffe1d27  jmp 0x000073307FFE1AD6
000073307ffe1d2c  call 0x000073307FEE1570
000073307ffe1d31  jmp 0x000073307FFE1AE2
000073307ffe1d36  call 0x000073307FEE27E0
000073307ffe1d3b  jmp 0x000073307FFE1B1A
000073307ffe1d40  call 0x000073307FEE1570
000073307ffe1d45  jmp 0x000073307FFE1B26
000073307ffe1d4a  call 0x000073307FEE27E0
000073307ffe1d4f  jmp 0x000073307FFE1B5E
000073307ffe1d54  call 0x000073307FEE1570
000073307ffe1d59  jmp 0x000073307FFE1B6A
000073307ffe1d5e  call 0x000073307FEE27E0
000073307ffe1d63  jmp 0x000073307FFE1BA2
000073307ffe1d68  call 0x000073307FEE1570
000073307ffe1d6d  jmp 0x000073307FFE1BAE
000073307ffe1d72  call 0x000073307FEE27E0
000073307ffe1d77  jmp 0x000073307FFE1BED
000073307ffe1d7c  call 0x000073307FE0E760
000073307ffe1d81  jmp 0x000073307FFE1C0A
000073307ffe1d86  ucomisd xmm1, xmm15
000073307ffe1d8b  jp 0x000073307FFE1D9A
000073307ffe1d8d  movaps xmm13, [0x000073307FBFE060]
000073307ffe1d95  jmp 0x000073307FFE1C73
000073307ffe1d9a  vxorps xmm0, xmm1, xmm15
000073307ffe1d9f  pextrw eax, xmm0, 0x03
000073307ffe1da4  and eax, 0x7FF8
000073307ffe1da9  cmp eax, 0x08
000073307ffe1dac  jnz 0x000073307FFE1C73
000073307ffe1db2  movq rax, xmm15
000073307ffe1db7  shl rax, 0x0D
000073307ffe1dbb  jbe 0x000073307FFE1C73
000073307ffe1dc1  vorps xmm13, xmm15, [0x000073307FBFE070]
000073307ffe1dc9  jmp 0x000073307FFE1C73
000073307ffe1dce  ucomisd xmm1, xmm15
000073307ffe1dd3  jp 0x000073307FFE1DE2
000073307ffe1dd5  movaps xmm14, [0x000073307FBFE060]
000073307ffe1ddd  jmp 0x000073307FFE1CA0
000073307ffe1de2  vxorps xmm0, xmm1, xmm15
000073307ffe1de7  pextrw eax, xmm0, 0x03
000073307ffe1dec  and eax, 0x7FF8
000073307ffe1df1  cmp eax, 0x08
000073307ffe1df4  jnz 0x000073307FFE1CA0
000073307ffe1dfa  movq rax, xmm15
000073307ffe1dff  shl rax, 0x0D
000073307ffe1e03  jbe 0x000073307FFE1CA0
000073307ffe1e09  vorps xmm14, xmm15, [0x000073307FBFE070]
000073307ffe1e11  jmp 0x000073307FFE1CA0
000073307ffe1e16  int3
000073307ffe1e17  nop [rax+rax*1], ax
000073307ffe1e20  mov rax, [r15+0x48]
000073307ffe1e24  mov r14, [r15+0x50]
000073307ffe1e28  lea r12, [r14+rax*1]
000073307ffe1e2c  movups xmm1, [r13+r12*1]
000073307ffe1e32  movaps [r15+0x120], xmm1
000073307ffe1e3a  lea r14, [rax+0x10]
000073307ffe1e3e  mov [r15+0x48], r14
000073307ffe1e42  xor eax, eax
000073307ffe1e44  mov r12d, 0x200
000073307ffe1e4a  cmp r14, r12
000073307ffe1e4d  cmc
000073307ffe1e4e  lahf
000073307ffe1e4f  seto al
000073307ffe1e52  mov [r15+0x108], eax
000073307ffe1e59  pextrq rax, xmm1, 0x01
000073307ffe1e60  movq xmm15, rax
000073307ffe1e65  movaps [r15+0x130], xmm15
000073307ffe1e6d  movaps xmm14, [r15+0x110]
000073307ffe1e75  movq rax, xmm14
000073307ffe1e7a  movq r14, xmm1
000073307ffe1e7f  vmovq xmm1, rax
000073307ffe1e84  vmovq xmm14, r14
000073307ffe1e89  movaps xmm13, xmm1
000073307ffe1e8d  addsd xmm13, xmm14
000073307ffe1e92  ucomisd xmm13, xmm13
000073307ffe1e97  jp 0x000073307FFE1F4C
000073307ffe1e9d  movq xmm13, xmm13
000073307ffe1ea2  movq rax, xmm13
000073307ffe1ea7  movq r14, xmm15
000073307ffe1eac  vmovq xmm1, rax
000073307ffe1eb1  vmovq xmm15, r14
000073307ffe1eb6  movaps xmm14, xmm1
000073307ffe1eba  addsd xmm14, xmm15
000073307ffe1ebf  ucomisd xmm14, xmm14
000073307ffe1ec4  jp 0x000073307FFE1F94
000073307ffe1eca  movq xmm14, xmm14
000073307ffe1ecf  movaps [r15+0x110], xmm14
000073307ffe1ed7  mov eax, [r15+0x108]
000073307ffe1ede  sahf
000073307ffe1edf  jnz 0x000073307FFE1F11
000073307ffe1ee1  cmp dword ptr [r15+0x318], 0x00
000073307ffe1ee9  jz 0x000073307FFE1FE0
000073307ffe1eef  nop [rax+rax*1], ax
000073307ffe1ef8  nop [rax+rax*1], eax
000073307ffe1f00  mov eax, 0x410490
000073307ffe1f05  mov [r15+0x100], rax
000073307ffe1f0c  jmp 0x000073307FDFE110
000073307ffe1f11  cmp dword ptr [r15+0x318], 0x00
000073307ffe1f19  jz 0x000073307FFE1E20
000073307ffe1f1f  nop [rax+rax*1], ax
000073307ffe1f28  nop [rax+rax*1], eax
000073307ffe1f30  mov eax, 0x410474
000073307ffe1f35  mov [r15+0x100], rax
000073307ffe1f3c  jmp 0x000073307FDFE110
000073307ffe1f41  int3
000073307ffe1f42  call 0x000073307FEB52F0
000073307ffe1f47  jmp 0x000073307FFE1E32
000073307ffe1f4c  ucomisd xmm1, xmm14
000073307ffe1f51  jp 0x000073307FFE1F60
000073307ffe1f53  movaps xmm13, [0x000073307FBFE060]
000073307ffe1f5b  jmp 0x000073307FFE1E9D
000073307ffe1f60  vxorps xmm0, xmm1, xmm14
000073307ffe1f65  pextrw eax, xmm0, 0x03
000073307ffe1f6a  and eax, 0x7FF8
000073307ffe1f6f  cmp eax, 0x08
000073307ffe1f72  jnz 0x000073307FFE1E9D
000073307ffe1f78  movq rax, xmm14
000073307ffe1f7d  shl rax, 0x0D
000073307ffe1f81  jbe 0x000073307FFE1E9D
000073307ffe1f87  vorps xmm13, xmm14, [0x000073307FBFE070]
000073307ffe1f8f  jmp 0x000073307FFE1E9D
000073307ffe1f94  ucomisd xmm1, xmm15
000073307ffe1f99  jp 0x000073307FFE1FA8
000073307ffe1f9b  movaps xmm14, [0x000073307FBFE060]
000073307ffe1fa3  jmp 0x000073307FFE1ECA
000073307ffe1fa8  vxorps xmm0, xmm1, xmm15
000073307ffe1fad  pextrw eax, xmm0, 0x03
000073307ffe1fb2  and eax, 0x7FF8
000073307ffe1fb7  cmp eax, 0x08
000073307ffe1fba  jnz 0x000073307FFE1ECA
000073307ffe1fc0  movq rax, xmm15
000073307ffe1fc5  shl rax, 0x0D
000073307ffe1fc9  jbe 0x000073307FFE1ECA
000073307ffe1fcf  vorps xmm14, xmm15, [0x000073307FBFE070]
000073307ffe1fd7  jmp 0x000073307FFE1ECA
000073307ffe1fdc  int3
000073307ffe1fdd  nop [rax], eax
000073307ffe1fe0  mov rax, [r15+0x40]
000073307ffe1fe4  lea r14, [rax+0x510]
000073307ffe1feb  movaps xmm1, [r15+0x110]
000073307ffe1ff3  movq rax, xmm1
000073307ffe1ff8  mov [r13+r14*1], rax
000073307ffe1ffd  mov rax, [r15+0xF0]
000073307ffe2004  mov [r15+0x100], rax
000073307ffe200b  jmp 0x000073307FFCE5C0
000073307ffe2010  int3
000073307ffe2011  call 0x000073307FED5EB0
000073307ffe2016  jmp 0x000073307FFE1FFD
000073307ffe201b  int3
000073307ffe201c  nop [rax], eax
000073307ffe2020  mov qword ptr [r15+0x100], 0x04
000073307ffe202b  mov esi, 0x00
000073307ffe2030  mov edx, 0x09
000073307ffe2035  mov rdi, 0x7FFCE9C6ECB0
000073307ffe203f  mov rax, 0x600DE0D5B970
000073307ffe2049  call rax
000073307ffe204b  cmp dword ptr [r15+0x318], 0x00
000073307ffe2053  jnz 0x000073307FDFE110
000073307ffe2059  jmp 0x000073307FDFE0A0
000073307ffe205e  int3
000073307ffe205f  int3
