00007f46e3fce69b  nop [rax+rax*1], eax
00007f46e3fce6a0  vmovaps xmm1, [0x00007F46E3BFE010]
00007f46e3fce6a8  movq xmm1, xmm1
00007f46e3fce6ac  movaps [r15+0x110], xmm1
00007f46e3fce6b4  vmovaps xmm1, [0x00007F46E3BFE020]
00007f46e3fce6bc  movq xmm1, xmm1
00007f46e3fce6c0  movaps [r15+0x120], xmm1
00007f46e3fce6c8  mov eax, 0x4204C0
00007f46e3fce6cd  mov r14, [r13+rax*1]
00007f46e3fce6d2  movq xmm1, r14
00007f46e3fce6d7  movaps [r15+0x130], xmm1
00007f46e3fce6df  vmovaps xmm1, [0x00007F46E3BFE030]
00007f46e3fce6e7  vpbroadcastq xmm1, xmm1
00007f46e3fce6ec  movaps [r15+0x140], xmm1
00007f46e3fce6f4  mov qword ptr [r15+0x40], 0x02
00007f46e3fce6fc  vmovaps xmm15, [0x00007F46E3BFE040]
00007f46e3fce704  movq xmm15, xmm15
00007f46e3fce709  movaps [r15+0x150], xmm15
00007f46e3fce711  mov qword ptr [r15+0x58], 0x420000
00007f46e3fce719  vmovaps xmm15, [0x00007F46E3BFE050]
00007f46e3fce721  vpbroadcastq xmm15, xmm15
00007f46e3fce726  movaps [r15+0x160], xmm15
00007f46e3fce72e  mov rax, [r15+0x40]
00007f46e3fce732  vmovq xmm14, rax
00007f46e3fce737  vpbroadcastq xmm14, xmm14
00007f46e3fce73c  movaps [r15+0x170], xmm14
00007f46e3fce744  mov eax, 0x4204D0
00007f46e3fce749  movups xmm13, [r13+rax*1]
00007f46e3fce74f  mov qword ptr [r15+0x40], 0x430518
00007f46e3fce757  mov qword ptr [r15+0x50], 0x430720
00007f46e3fce75f  vpmovqd xmm12, xmm13
00007f46e3fce765  pxor xmm11, xmm11
00007f46e3fce76a  punpcklqdq xmm12, xmm11
00007f46e3fce76f  movaps [r15+0x210], xmm12
00007f46e3fce777  movq xmm12, qword ptr [r15+0x120]
00007f46e3fce780  movq xmm11, qword ptr [r15+0x130]
00007f46e3fce789  psubd xmm12, xmm11
00007f46e3fce78e  movq xmm12, xmm12
00007f46e3fce793  paddq xmm13, xmm14
00007f46e3fce798  movaps [r15+0x180], xmm13
00007f46e3fce7a0  movq xmm14, qword ptr [r15+0x150]
00007f46e3fce7a9  paddd xmm11, xmm14
00007f46e3fce7ae  movq xmm11, xmm11
00007f46e3fce7b3  movq xmm11, xmm11
00007f46e3fce7b8  movaps [r15+0x130], xmm11
00007f46e3fce7c0  pmovzxdq xmm12, xmm12
00007f46e3fce7c6  psllq xmm12, 0x00
00007f46e3fce7cc  movq xmm14, qword ptr [r15+0x210]
00007f46e3fce7d5  movq xmm13, qword ptr [r15+0x110]
00007f46e3fce7de  paddd xmm14, xmm13
00007f46e3fce7e3  movq xmm14, xmm14
00007f46e3fce7e8  vcvtuqq2pd xmm12, xmm12
00007f46e3fce7ee  pmovzxdq xmm14, xmm14
00007f46e3fce7f4  psllq xmm14, 0x00
00007f46e3fce7fa  vcvtuqq2pd xmm14, xmm14
00007f46e3fce800  movaps xmm13, xmm12
00007f46e3fce804  mulpd xmm13, xmm1
00007f46e3fce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007f46e3fce80f  ptest xmm11, xmm11
00007f46e3fce815  jnz 0x00007F46E3FCE8FF
00007f46e3fce81b  movaps [r15+0x220], xmm13
00007f46e3fce823  mov eax, 0x430720
00007f46e3fce828  movups [r13+rax*1], xmm13
00007f46e3fce82e  movaps xmm1, xmm14
00007f46e3fce832  mulpd xmm1, xmm15
00007f46e3fce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007f46e3fce83c  ptest xmm13, xmm13
00007f46e3fce842  jnz 0x00007F46E3FCEA4C
00007f46e3fce848  movaps [r15+0x210], xmm1
00007f46e3fce850  mov eax, 0x430518
00007f46e3fce855  movups [r13+rax*1], xmm1
00007f46e3fce85b  mov qword ptr [r15+0x48], 0x10
00007f46e3fce863  xor eax, eax
00007f46e3fce865  mov r14d, 0x10
00007f46e3fce86b  mov r12d, 0x200
00007f46e3fce871  cmp r14, r12
00007f46e3fce874  cmc
00007f46e3fce875  lahf
00007f46e3fce876  seto al
00007f46e3fce879  mov [r15+0x108], eax
00007f46e3fce880  mov eax, [r15+0x108]
00007f46e3fce887  sahf
00007f46e3fce888  jnz 0x00007F46E3FCE8BA
00007f46e3fce88a  cmp dword ptr [r15+0x318], 0x00
00007f46e3fce892  jz 0x00007F46E3FCEFF0
00007f46e3fce898  nop [rax+rax*1], ax
00007f46e3fce8a1  nop [rax+rax*1], eax
00007f46e3fce8a9  mov eax, 0x4101EC
00007f46e3fce8ae  mov [r15+0x100], rax
00007f46e3fce8b5  jmp 0x00007F46E3DFE110
00007f46e3fce8ba  cmp dword ptr [r15+0x318], 0x00
00007f46e3fce8c2  jz 0x00007F46E3FCEBA0
00007f46e3fce8c8  nop [rax+rax*1], ax
00007f46e3fce8d1  nop [rax+rax*1], eax
00007f46e3fce8d9  mov eax, 0x4101AC
00007f46e3fce8de  mov [r15+0x100], rax
00007f46e3fce8e5  jmp 0x00007F46E3DFE110
00007f46e3fce8ea  int3
00007f46e3fce8eb  call 0x00007F46E3E0DC20
00007f46e3fce8f0  jmp 0x00007F46E3FCE6D2
00007f46e3fce8f5  call 0x00007F46E3E0C260
00007f46e3fce8fa  jmp 0x00007F46E3FCE74F
00007f46e3fce8ff  sub rsp, 0x08
00007f46e3fce903  push rax
00007f46e3fce904  push rcx
00007f46e3fce905  push rdx
00007f46e3fce906  push rdi
00007f46e3fce907  push rsi
00007f46e3fce908  push r8
00007f46e3fce90a  push r9
00007f46e3fce90c  push r10
00007f46e3fce90e  push r11
00007f46e3fce910  sub rsp, 0xF0
00007f46e3fce917  vmovaps [rsp], xmm0
00007f46e3fce91c  vmovaps [rsp+0x10], xmm1
00007f46e3fce922  vmovaps [rsp+0x20], xmm2
00007f46e3fce928  vmovaps [rsp+0x30], xmm3
00007f46e3fce92e  vmovaps [rsp+0x40], xmm4
00007f46e3fce934  vmovaps [rsp+0x50], xmm5
00007f46e3fce93a  vmovaps [rsp+0x60], xmm6
00007f46e3fce940  vmovaps [rsp+0x70], xmm7
00007f46e3fce946  vmovaps [rsp+0x80], xmm8
00007f46e3fce94f  vmovaps [rsp+0x90], xmm9
00007f46e3fce958  vmovaps [rsp+0xA0], xmm10
00007f46e3fce961  vmovaps [rsp+0xB0], xmm11
00007f46e3fce96a  vmovaps [rsp+0xC0], xmm12
00007f46e3fce973  vmovaps [rsp+0xD0], xmm14
00007f46e3fce97c  vmovaps [rsp+0xE0], xmm15
00007f46e3fce985  sub rsp, 0x30
00007f46e3fce989  movaps [rsp], xmm13
00007f46e3fce98e  movaps [rsp+0x10], xmm12
00007f46e3fce994  movaps [rsp+0x20], xmm1
00007f46e3fce999  lea rdi, [rsp]
00007f46e3fce99d  mov esi, 0x00
00007f46e3fce9a2  mov rax, 0x6238B185B530
00007f46e3fce9ac  call rax
00007f46e3fce9ae  movaps xmm13, [rsp]
00007f46e3fce9b3  add rsp, 0x30
00007f46e3fce9b7  vmovaps xmm0, [rsp]
00007f46e3fce9bc  vmovaps xmm1, [rsp+0x10]
00007f46e3fce9c2  vmovaps xmm2, [rsp+0x20]
00007f46e3fce9c8  vmovaps xmm3, [rsp+0x30]
00007f46e3fce9ce  vmovaps xmm4, [rsp+0x40]
00007f46e3fce9d4  vmovaps xmm5, [rsp+0x50]
00007f46e3fce9da  vmovaps xmm6, [rsp+0x60]
00007f46e3fce9e0  vmovaps xmm7, [rsp+0x70]
00007f46e3fce9e6  vmovaps xmm8, [rsp+0x80]
00007f46e3fce9ef  vmovaps xmm9, [rsp+0x90]
00007f46e3fce9f8  vmovaps xmm10, [rsp+0xA0]
00007f46e3fcea01  vmovaps xmm11, [rsp+0xB0]
00007f46e3fcea0a  vmovaps xmm12, [rsp+0xC0]
00007f46e3fcea13  vmovaps xmm14, [rsp+0xD0]
00007f46e3fcea1c  vmovaps xmm15, [rsp+0xE0]
00007f46e3fcea25  add rsp, 0xF0
00007f46e3fcea2c  pop r11
00007f46e3fcea2e  pop r10
00007f46e3fcea30  pop r9
00007f46e3fcea32  pop r8
00007f46e3fcea34  pop rsi
00007f46e3fcea35  pop rdi
00007f46e3fcea36  pop rdx
00007f46e3fcea37  pop rcx
00007f46e3fcea38  pop rax
00007f46e3fcea39  add rsp, 0x08
00007f46e3fcea3d  jmp 0x00007F46E3FCE81B
00007f46e3fcea42  call 0x00007F46E3E0C380
00007f46e3fcea47  jmp 0x00007F46E3FCE82E
00007f46e3fcea4c  sub rsp, 0x08
00007f46e3fcea50  push rax
00007f46e3fcea51  push rcx
00007f46e3fcea52  push rdx
00007f46e3fcea53  push rdi
00007f46e3fcea54  push rsi
00007f46e3fcea55  push r8
00007f46e3fcea57  push r9
00007f46e3fcea59  push r10
00007f46e3fcea5b  push r11
00007f46e3fcea5d  sub rsp, 0xF0
00007f46e3fcea64  vmovaps [rsp], xmm0
00007f46e3fcea69  vmovaps [rsp+0x10], xmm2
00007f46e3fcea6f  vmovaps [rsp+0x20], xmm3
00007f46e3fcea75  vmovaps [rsp+0x30], xmm4
00007f46e3fcea7b  vmovaps [rsp+0x40], xmm5
00007f46e3fcea81  vmovaps [rsp+0x50], xmm6
00007f46e3fcea87  vmovaps [rsp+0x60], xmm7
00007f46e3fcea8d  vmovaps [rsp+0x70], xmm8
00007f46e3fcea93  vmovaps [rsp+0x80], xmm9
00007f46e3fcea9c  vmovaps [rsp+0x90], xmm10
00007f46e3fceaa5  vmovaps [rsp+0xA0], xmm11
00007f46e3fceaae  vmovaps [rsp+0xB0], xmm12
00007f46e3fceab7  vmovaps [rsp+0xC0], xmm13
00007f46e3fceac0  vmovaps [rsp+0xD0], xmm14
00007f46e3fceac9  vmovaps [rsp+0xE0], xmm15
00007f46e3fcead2  sub rsp, 0x30
00007f46e3fcead6  movaps [rsp], xmm1
00007f46e3fceada  movaps [rsp+0x10], xmm14
00007f46e3fceae0  movaps [rsp+0x20], xmm15
00007f46e3fceae6  lea rdi, [rsp]
00007f46e3fceaea  mov esi, 0x00
00007f46e3fceaef  mov rax, 0x6238B185B530
00007f46e3fceaf9  call rax
00007f46e3fceafb  movaps xmm1, [rsp]
00007f46e3fceaff  add rsp, 0x30
00007f46e3fceb03  vmovaps xmm0, [rsp]
00007f46e3fceb08  vmovaps xmm2, [rsp+0x10]
00007f46e3fceb0e  vmovaps xmm3, [rsp+0x20]
00007f46e3fceb14  vmovaps xmm4, [rsp+0x30]
00007f46e3fceb1a  vmovaps xmm5, [rsp+0x40]
00007f46e3fceb20  vmovaps xmm6, [rsp+0x50]
00007f46e3fceb26  vmovaps xmm7, [rsp+0x60]
00007f46e3fceb2c  vmovaps xmm8, [rsp+0x70]
00007f46e3fceb32  vmovaps xmm9, [rsp+0x80]
00007f46e3fceb3b  vmovaps xmm10, [rsp+0x90]
00007f46e3fceb44  vmovaps xmm11, [rsp+0xA0]
00007f46e3fceb4d  vmovaps xmm12, [rsp+0xB0]
00007f46e3fceb56  vmovaps xmm13, [rsp+0xC0]
00007f46e3fceb5f  vmovaps xmm14, [rsp+0xD0]
00007f46e3fceb68  vmovaps xmm15, [rsp+0xE0]
00007f46e3fceb71  add rsp, 0xF0
00007f46e3fceb78  pop r11
00007f46e3fceb7a  pop r10
00007f46e3fceb7c  pop r9
00007f46e3fceb7e  pop r8
00007f46e3fceb80  pop rsi
00007f46e3fceb81  pop rdi
00007f46e3fceb82  pop rdx
00007f46e3fceb83  pop rcx
00007f46e3fceb84  pop rax
00007f46e3fceb85  add rsp, 0x08
00007f46e3fceb89  jmp 0x00007F46E3FCE848
00007f46e3fceb8e  call 0x00007F46E3DFF540
00007f46e3fceb93  jmp 0x00007F46E3FCE85B
00007f46e3fceb98  int3
00007f46e3fceb99  nop [rax], eax
00007f46e3fceba0  movaps xmm1, [r15+0x180]
00007f46e3fceba8  vpmovqd xmm15, xmm1
00007f46e3fcebae  pxor xmm14, xmm14
00007f46e3fcebb3  punpcklqdq xmm15, xmm14
00007f46e3fcebb8  movaps [r15+0x210], xmm15
00007f46e3fcebc0  movq xmm15, qword ptr [r15+0x120]
00007f46e3fcebc9  movq xmm14, qword ptr [r15+0x130]
00007f46e3fcebd2  psubd xmm15, xmm14
00007f46e3fcebd7  movq xmm15, xmm15
00007f46e3fcebdc  movaps xmm13, [r15+0x170]
00007f46e3fcebe4  paddq xmm1, xmm13
00007f46e3fcebe9  movaps [r15+0x180], xmm1
00007f46e3fcebf1  movq xmm1, qword ptr [r15+0x150]
00007f46e3fcebfa  paddd xmm14, xmm1
00007f46e3fcebff  movq xmm14, xmm14
00007f46e3fcec04  movq xmm14, xmm14
00007f46e3fcec09  movaps [r15+0x130], xmm14
00007f46e3fcec11  pmovzxdq xmm15, xmm15
00007f46e3fcec17  psllq xmm15, 0x00
00007f46e3fcec1d  movq xmm1, qword ptr [r15+0x210]
00007f46e3fcec26  movq xmm14, qword ptr [r15+0x110]
00007f46e3fcec2f  paddd xmm1, xmm14
00007f46e3fcec34  movq xmm1, xmm1
00007f46e3fcec38  vcvtuqq2pd xmm15, xmm15
00007f46e3fcec3e  pmovzxdq xmm1, xmm1
00007f46e3fcec43  psllq xmm1, 0x00
00007f46e3fcec48  vcvtuqq2pd xmm1, xmm1
00007f46e3fcec4e  movaps xmm14, [r15+0x140]
00007f46e3fcec56  movaps xmm13, xmm15
00007f46e3fcec5a  mulpd xmm13, xmm14
00007f46e3fcec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007f46e3fcec65  ptest xmm12, xmm12
00007f46e3fcec6b  jnz 0x00007F46E3FCED4E
00007f46e3fcec71  movaps [r15+0x220], xmm13
00007f46e3fcec79  mov rax, [r15+0x48]
00007f46e3fcec7d  mov r14, [r15+0x50]
00007f46e3fcec81  lea r12, [r14+rax*1]
00007f46e3fcec85  movups [r13+r12*1], xmm13
00007f46e3fcec8b  movaps xmm15, [r15+0x160]
00007f46e3fcec93  movaps xmm14, xmm1
00007f46e3fcec97  mulpd xmm14, xmm15
00007f46e3fcec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007f46e3fceca2  ptest xmm13, xmm13
00007f46e3fceca8  jnz 0x00007F46E3FCEE9C
00007f46e3fcecae  movaps [r15+0x210], xmm14
00007f46e3fcecb6  mov r14, [r15+0x40]
00007f46e3fcecba  lea r12, [r14+rax*1]
00007f46e3fcecbe  movups [r13+r12*1], xmm14
00007f46e3fcecc4  lea r14, [rax+0x10]
00007f46e3fcecc8  mov [r15+0x48], r14
00007f46e3fceccc  xor eax, eax
00007f46e3fcecce  mov r12d, 0x200
00007f46e3fcecd4  cmp r14, r12
00007f46e3fcecd7  cmc
00007f46e3fcecd8  lahf
00007f46e3fcecd9  seto al
00007f46e3fcecdc  mov [r15+0x108], eax
00007f46e3fcece3  mov eax, [r15+0x108]
00007f46e3fcecea  sahf
00007f46e3fceceb  jnz 0x00007F46E3FCED1D
00007f46e3fceced  cmp dword ptr [r15+0x318], 0x00
00007f46e3fcecf5  jz 0x00007F46E3FCEFF0
00007f46e3fcecfb  nop [rax+rax*1], ax
00007f46e3fced04  nop [rax+rax*1], eax
00007f46e3fced0c  mov eax, 0x4101EC
00007f46e3fced11  mov [r15+0x100], rax
00007f46e3fced18  jmp 0x00007F46E3DFE110
00007f46e3fced1d  cmp dword ptr [r15+0x318], 0x00
00007f46e3fced25  jz 0x00007F46E3FCEBA0
00007f46e3fced2b  nop [rax+rax*1], ax
00007f46e3fced34  nop [rax+rax*1], eax
00007f46e3fced3c  mov eax, 0x4101AC
00007f46e3fced41  mov [r15+0x100], rax
00007f46e3fced48  jmp 0x00007F46E3DFE110
00007f46e3fced4d  int3
00007f46e3fced4e  sub rsp, 0x08
00007f46e3fced52  push rax
00007f46e3fced53  push rcx
00007f46e3fced54  push rdx
00007f46e3fced55  push rdi
00007f46e3fced56  push rsi
00007f46e3fced57  push r8
00007f46e3fced59  push r9
00007f46e3fced5b  push r10
00007f46e3fced5d  push r11
00007f46e3fced5f  sub rsp, 0xF0
00007f46e3fced66  vmovaps [rsp], xmm0
00007f46e3fced6b  vmovaps [rsp+0x10], xmm1
00007f46e3fced71  vmovaps [rsp+0x20], xmm2
00007f46e3fced77  vmovaps [rsp+0x30], xmm3
00007f46e3fced7d  vmovaps [rsp+0x40], xmm4
00007f46e3fced83  vmovaps [rsp+0x50], xmm5
00007f46e3fced89  vmovaps [rsp+0x60], xmm6
00007f46e3fced8f  vmovaps [rsp+0x70], xmm7
00007f46e3fced95  vmovaps [rsp+0x80], xmm8
00007f46e3fced9e  vmovaps [rsp+0x90], xmm9
00007f46e3fceda7  vmovaps [rsp+0xA0], xmm10
00007f46e3fcedb0  vmovaps [rsp+0xB0], xmm11
00007f46e3fcedb9  vmovaps [rsp+0xC0], xmm12
00007f46e3fcedc2  vmovaps [rsp+0xD0], xmm14
00007f46e3fcedcb  vmovaps [rsp+0xE0], xmm15
00007f46e3fcedd4  sub rsp, 0x30
00007f46e3fcedd8  movaps [rsp], xmm13
00007f46e3fceddd  movaps [rsp+0x10], xmm15
00007f46e3fcede3  movaps [rsp+0x20], xmm14
00007f46e3fcede9  lea rdi, [rsp]
00007f46e3fceded  mov esi, 0x00
00007f46e3fcedf2  mov rax, 0x6238B185B530
00007f46e3fcedfc  call rax
00007f46e3fcedfe  movaps xmm13, [rsp]
00007f46e3fcee03  add rsp, 0x30
00007f46e3fcee07  vmovaps xmm0, [rsp]
00007f46e3fcee0c  vmovaps xmm1, [rsp+0x10]
00007f46e3fcee12  vmovaps xmm2, [rsp+0x20]
00007f46e3fcee18  vmovaps xmm3, [rsp+0x30]
00007f46e3fcee1e  vmovaps xmm4, [rsp+0x40]
00007f46e3fcee24  vmovaps xmm5, [rsp+0x50]
00007f46e3fcee2a  vmovaps xmm6, [rsp+0x60]
00007f46e3fcee30  vmovaps xmm7, [rsp+0x70]
00007f46e3fcee36  vmovaps xmm8, [rsp+0x80]
00007f46e3fcee3f  vmovaps xmm9, [rsp+0x90]
00007f46e3fcee48  vmovaps xmm10, [rsp+0xA0]
00007f46e3fcee51  vmovaps xmm11, [rsp+0xB0]
00007f46e3fcee5a  vmovaps xmm12, [rsp+0xC0]
00007f46e3fcee63  vmovaps xmm14, [rsp+0xD0]
00007f46e3fcee6c  vmovaps xmm15, [rsp+0xE0]
00007f46e3fcee75  add rsp, 0xF0
00007f46e3fcee7c  pop r11
00007f46e3fcee7e  pop r10
00007f46e3fcee80  pop r9
00007f46e3fcee82  pop r8
00007f46e3fcee84  pop rsi
00007f46e3fcee85  pop rdi
00007f46e3fcee86  pop rdx
00007f46e3fcee87  pop rcx
00007f46e3fcee88  pop rax
00007f46e3fcee89  add rsp, 0x08
00007f46e3fcee8d  jmp 0x00007F46E3FCEC71
00007f46e3fcee92  call 0x00007F46E3EC2240
00007f46e3fcee97  jmp 0x00007F46E3FCEC8B
00007f46e3fcee9c  sub rsp, 0x08
00007f46e3fceea0  push rax
00007f46e3fceea1  push rcx
00007f46e3fceea2  push rdx
00007f46e3fceea3  push rdi
00007f46e3fceea4  push rsi
00007f46e3fceea5  push r8
00007f46e3fceea7  push r9
00007f46e3fceea9  push r10
00007f46e3fceeab  push r11
00007f46e3fceead  sub rsp, 0xF0
00007f46e3fceeb4  vmovaps [rsp], xmm0
00007f46e3fceeb9  vmovaps [rsp+0x10], xmm1
00007f46e3fceebf  vmovaps [rsp+0x20], xmm2
00007f46e3fceec5  vmovaps [rsp+0x30], xmm3
00007f46e3fceecb  vmovaps [rsp+0x40], xmm4
00007f46e3fceed1  vmovaps [rsp+0x50], xmm5
00007f46e3fceed7  vmovaps [rsp+0x60], xmm6
00007f46e3fceedd  vmovaps [rsp+0x70], xmm7
00007f46e3fceee3  vmovaps [rsp+0x80], xmm8
00007f46e3fceeec  vmovaps [rsp+0x90], xmm9
00007f46e3fceef5  vmovaps [rsp+0xA0], xmm10
00007f46e3fceefe  vmovaps [rsp+0xB0], xmm11
00007f46e3fcef07  vmovaps [rsp+0xC0], xmm12
00007f46e3fcef10  vmovaps [rsp+0xD0], xmm13
00007f46e3fcef19  vmovaps [rsp+0xE0], xmm15
00007f46e3fcef22  sub rsp, 0x30
00007f46e3fcef26  movaps [rsp], xmm14
00007f46e3fcef2b  movaps [rsp+0x10], xmm1
00007f46e3fcef30  movaps [rsp+0x20], xmm15
00007f46e3fcef36  lea rdi, [rsp]
00007f46e3fcef3a  mov esi, 0x00
00007f46e3fcef3f  mov rax, 0x6238B185B530
00007f46e3fcef49  call rax
00007f46e3fcef4b  movaps xmm14, [rsp]
00007f46e3fcef50  add rsp, 0x30
00007f46e3fcef54  vmovaps xmm0, [rsp]
00007f46e3fcef59  vmovaps xmm1, [rsp+0x10]
00007f46e3fcef5f  vmovaps xmm2, [rsp+0x20]
00007f46e3fcef65  vmovaps xmm3, [rsp+0x30]
00007f46e3fcef6b  vmovaps xmm4, [rsp+0x40]
00007f46e3fcef71  vmovaps xmm5, [rsp+0x50]
00007f46e3fcef77  vmovaps xmm6, [rsp+0x60]
00007f46e3fcef7d  vmovaps xmm7, [rsp+0x70]
00007f46e3fcef83  vmovaps xmm8, [rsp+0x80]
00007f46e3fcef8c  vmovaps xmm9, [rsp+0x90]
00007f46e3fcef95  vmovaps xmm10, [rsp+0xA0]
00007f46e3fcef9e  vmovaps xmm11, [rsp+0xB0]
00007f46e3fcefa7  vmovaps xmm12, [rsp+0xC0]
00007f46e3fcefb0  vmovaps xmm13, [rsp+0xD0]
00007f46e3fcefb9  vmovaps xmm15, [rsp+0xE0]
00007f46e3fcefc2  add rsp, 0xF0
00007f46e3fcefc9  pop r11
00007f46e3fcefcb  pop r10
00007f46e3fcefcd  pop r9
00007f46e3fcefcf  pop r8
00007f46e3fcefd1  pop rsi
00007f46e3fcefd2  pop rdi
00007f46e3fcefd3  pop rdx
00007f46e3fcefd4  pop rcx
00007f46e3fcefd5  pop rax
00007f46e3fcefd6  add rsp, 0x08
00007f46e3fcefda  jmp 0x00007F46E3FCECAE
00007f46e3fcefdf  call 0x00007F46E3EC34C0
00007f46e3fcefe4  jmp 0x00007F46E3FCECC4
00007f46e3fcefe9  int3
00007f46e3fcefea  nop [rax+rax*1], ax
00007f46e3fceff0  mov rax, [r15+0xF8]
00007f46e3fceff7  lea r14, [rax-0x150]
00007f46e3fceffe  mov [r15+0xF8], r14
00007f46e3fcf005  mov rax, [r15+0x50]
00007f46e3fcf009  lea r12, [rax+0x80]
00007f46e3fcf010  movups xmm1, [r13+r12*1]
00007f46e3fcf016  lea r12, [rax+0x90]
00007f46e3fcf01d  movups xmm15, [r13+r12*1]
00007f46e3fcf023  mov qword ptr [r15+0x48], 0x00
00007f46e3fcf02b  lea r12, [rax+0x40]
00007f46e3fcf02f  movups xmm14, [r13+r12*1]
00007f46e3fcf035  lea r12, [rax+0x50]
00007f46e3fcf039  movups xmm13, [r13+r12*1]
00007f46e3fcf03f  lea r12, [r14+0x120]
00007f46e3fcf046  movq xmm12, qword ptr [r15+0x1C0]
00007f46e3fcf04f  movq xmm11, qword ptr [r15+0x1B0]
00007f46e3fcf058  movq r11, xmm12
00007f46e3fcf05d  movq r10, xmm11
00007f46e3fcf062  mov [r13+r12*1], r11
00007f46e3fcf067  lea r12, [r14+0x128]
00007f46e3fcf06e  mov [r13+r12*1], r10
00007f46e3fcf073  vxorps xmm12, xmm12, xmm12
00007f46e3fcf078  vpbroadcastq xmm12, xmm12
00007f46e3fcf07d  lea r12, [r14+0x100]
00007f46e3fcf084  movq xmm11, qword ptr [r15+0x200]
00007f46e3fcf08d  movq xmm10, qword ptr [r15+0x1F0]
00007f46e3fcf096  movq r11, xmm11
00007f46e3fcf09b  movq r10, xmm10
00007f46e3fcf0a0  mov [r13+r12*1], r11
00007f46e3fcf0a5  lea r12, [r14+0x108]
00007f46e3fcf0ac  mov [r13+r12*1], r10
00007f46e3fcf0b1  lea r12, [r14+0xE0]
00007f46e3fcf0b8  movups [r13+r12*1], xmm15
00007f46e3fcf0be  lea r12, [r14+0xF0]
00007f46e3fcf0c5  movups [r13+r12*1], xmm1
00007f46e3fcf0cb  lea r12, [rax+0xC0]
00007f46e3fcf0d2  movups xmm1, [r13+r12*1]
00007f46e3fcf0d8  lea r12, [rax+0xD0]
00007f46e3fcf0df  movups xmm15, [r13+r12*1]
00007f46e3fcf0e5  lea r12, [r14+0x110]
00007f46e3fcf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007f46e3fcf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007f46e3fcf0fe  movq r11, xmm11
00007f46e3fcf103  movq r10, xmm10
00007f46e3fcf108  mov [r13+r12*1], r11
00007f46e3fcf10d  lea r12, [r14+0x118]
00007f46e3fcf114  mov [r13+r12*1], r10
00007f46e3fcf119  movups xmm11, [r13+rax*1]
00007f46e3fcf11f  lea r12, [rax+0x10]
00007f46e3fcf123  movups xmm10, [r13+r12*1]
00007f46e3fcf129  lea r12, [r14+0x130]
00007f46e3fcf130  movq xmm9, qword ptr [r15+0x1A0]
00007f46e3fcf139  movq xmm8, qword ptr [r15+0x190]
00007f46e3fcf142  movq r11, xmm9
00007f46e3fcf147  movq r10, xmm8
00007f46e3fcf14c  mov [r13+r12*1], r11
00007f46e3fcf151  lea r12, [r14+0x138]
00007f46e3fcf158  mov [r13+r12*1], r10
00007f46e3fcf15d  lea r12, [rax+0x140]
00007f46e3fcf164  movups xmm9, [r13+r12*1]
00007f46e3fcf16a  lea r12, [rax+0x150]
00007f46e3fcf171  movups xmm8, [r13+r12*1]
00007f46e3fcf177  lea r12, [r14+0xC0]
00007f46e3fcf17e  movups [r13+r12*1], xmm15
00007f46e3fcf184  lea r12, [r14+0xD0]
00007f46e3fcf18b  movups [r13+r12*1], xmm1
00007f46e3fcf191  lea r12, [rax+0x100]
00007f46e3fcf198  movups xmm1, [r13+r12*1]
00007f46e3fcf19e  lea r12, [rax+0x110]
00007f46e3fcf1a5  movups xmm15, [r13+r12*1]
00007f46e3fcf1ab  lea r12, [r14+0x140]
00007f46e3fcf1b2  mov r11, [r15+0xE8]
00007f46e3fcf1b9  mov [r13+r12*1], r11
00007f46e3fcf1be  lea r12, [rax+0x180]
00007f46e3fcf1c5  movups xmm7, [r13+r12*1]
00007f46e3fcf1cb  lea r12, [rax+0x190]
00007f46e3fcf1d2  movups xmm6, [r13+r12*1]
00007f46e3fcf1d8  lea r12, [rax+0x1C0]
00007f46e3fcf1df  movups xmm5, [r13+r12*1]
00007f46e3fcf1e5  lea r12, [rax+0x1D0]
00007f46e3fcf1ec  movups xmm4, [r13+r12*1]
00007f46e3fcf1f2  lea r12, [r14+0x20]
00007f46e3fcf1f6  movups [r13+r12*1], xmm1
00007f46e3fcf1fc  lea r12, [r14+0x30]
00007f46e3fcf200  movups [r13+r12*1], xmm13
00007f46e3fcf206  lea r12, [rax+0x60]
00007f46e3fcf20a  movups xmm1, [r13+r12*1]
00007f46e3fcf210  lea r12, [rax+0x70]
00007f46e3fcf214  movups xmm13, [r13+r12*1]
00007f46e3fcf21a  lea r12, [rax+0x20]
00007f46e3fcf21e  movups xmm3, [r13+r12*1]
00007f46e3fcf224  lea r12, [rax+0x30]
00007f46e3fcf228  movups xmm2, [r13+r12*1]
00007f46e3fcf22e  movaps [r15+0x1F0], xmm2
00007f46e3fcf236  lea r12, [r14+0x60]
00007f46e3fcf23a  movups [r13+r12*1], xmm11
00007f46e3fcf240  lea r12, [r14+0x70]
00007f46e3fcf244  movups [r13+r12*1], xmm5
00007f46e3fcf24a  lea r12, [rax+0xE0]
00007f46e3fcf251  movups xmm11, [r13+r12*1]
00007f46e3fcf257  lea r12, [rax+0xF0]
00007f46e3fcf25e  movups xmm5, [r13+r12*1]
00007f46e3fcf264  lea r12, [r14+0xA0]
00007f46e3fcf26b  movups [r13+r12*1], xmm13
00007f46e3fcf271  lea r12, [r14+0xB0]
00007f46e3fcf278  movups [r13+r12*1], xmm1
00007f46e3fcf27e  lea r12, [rax+0xA0]
00007f46e3fcf285  movups xmm1, [r13+r12*1]
00007f46e3fcf28b  lea r12, [rax+0xB0]
00007f46e3fcf292  movups xmm13, [r13+r12*1]
00007f46e3fcf298  lea r12, [rax+0x120]
00007f46e3fcf29f  vmovaps [rsp+0x10], xmm1
00007f46e3fcf2a5  movups xmm1, [r13+r12*1]
00007f46e3fcf2ab  lea r12, [rax+0x130]
00007f46e3fcf2b2  vmovaps [rsp+0x20], xmm1
00007f46e3fcf2b8  movups xmm1, [r13+r12*1]
00007f46e3fcf2be  lea r12, [rax+0x160]
00007f46e3fcf2c5  vmovaps [rsp+0x30], xmm1
00007f46e3fcf2cb  movups xmm1, [r13+r12*1]
00007f46e3fcf2d1  lea r12, [rax+0x170]
00007f46e3fcf2d8  vmovaps [rsp+0x40], xmm1
00007f46e3fcf2de  movups xmm1, [r13+r12*1]
00007f46e3fcf2e4  movaps [r15+0x2B0], xmm1
00007f46e3fcf2ec  lea r12, [r14+0x80]
00007f46e3fcf2f3  movups [r13+r12*1], xmm13
00007f46e3fcf2f9  lea r12, [r14+0x90]
00007f46e3fcf300  vmovaps xmm13, [rsp+0x10]
00007f46e3fcf306  movups [r13+r12*1], xmm13
00007f46e3fcf30c  lea r12, [rax+0x1A0]
00007f46e3fcf313  movups xmm13, [r13+r12*1]
00007f46e3fcf319  lea r12, [rax+0x1B0]
00007f46e3fcf320  vmovaps [rsp+0x10], xmm1
00007f46e3fcf326  movups xmm1, [r13+r12*1]
00007f46e3fcf32c  movaps [r15+0x290], xmm13
00007f46e3fcf334  movaps [r15+0x1E0], xmm1
00007f46e3fcf33c  lea r12, [rax+0x1E0]
00007f46e3fcf343  vmovaps [rsp+0x50], xmm1
00007f46e3fcf349  movups xmm1, [r13+r12*1]
00007f46e3fcf34f  lea r12, [rax+0x1F0]
00007f46e3fcf356  vmovaps [rsp+0x60], xmm1
00007f46e3fcf35c  movups xmm1, [r13+r12*1]
00007f46e3fcf362  mov qword ptr [r15+0x50], 0x430920
00007f46e3fcf36a  lea rax, [r14+0x40]
00007f46e3fcf36e  vmovaps [rsp+0x70], xmm1
00007f46e3fcf374  vmovaps xmm1, [rsp+0x40]
00007f46e3fcf37a  movups [r13+rax*1], xmm1
00007f46e3fcf380  lea rax, [r14+0x50]
00007f46e3fcf384  movups [r13+rax*1], xmm10
00007f46e3fcf38a  vmovaps xmm1, [rsp+0x70]
00007f46e3fcf390  movups [r13+r14*1], xmm1
00007f46e3fcf396  lea rax, [r14+0x10]
00007f46e3fcf39a  vmovaps xmm1, [rsp+0x60]
00007f46e3fcf3a0  movups [r13+rax*1], xmm1
00007f46e3fcf3a6  mov rax, [r15+0x40]
00007f46e3fcf3aa  vmovaps [rsp+0x40], xmm3
00007f46e3fcf3b0  vmovaps xmm1, [rsp+0x40]
00007f46e3fcf3b6  por xmm3, xmm1
00007f46e3fcf3ba  vmovaps [rsp+0x40], xmm6
00007f46e3fcf3c0  vmovaps xmm10, [rsp+0x40]
00007f46e3fcf3c6  por xmm6, xmm10
00007f46e3fcf3cb  lea r12, [rax+0x30]
00007f46e3fcf3cf  mov r11, [r13+r12*1]
00007f46e3fcf3d4  lea r12, [rax+0x38]
00007f46e3fcf3d8  mov r10, [r13+r12*1]
00007f46e3fcf3dd  movq xmm10, r11
00007f46e3fcf3e2  vmovaps [rsp+0x40], xmm1
00007f46e3fcf3e8  movq xmm1, r10
00007f46e3fcf3ed  movq xmm10, xmm10
00007f46e3fcf3f2  vmovaps [rsp+0x60], xmm10
00007f46e3fcf3f8  movq xmm10, xmm10
00007f46e3fcf3fd  movaps [r15+0x130], xmm10
00007f46e3fcf405  movq xmm1, xmm1
00007f46e3fcf409  vmovaps [rsp+0x70], xmm1
00007f46e3fcf40f  movq xmm1, xmm1
00007f46e3fcf413  movaps [r15+0x280], xmm1
00007f46e3fcf41b  vmovaps [rsp+0x80], xmm9
00007f46e3fcf424  vmovaps xmm1, [rsp+0x80]
00007f46e3fcf42d  por xmm9, xmm1
00007f46e3fcf432  lea r12, [rax+0x20]
00007f46e3fcf436  mov r11, [r13+r12*1]
00007f46e3fcf43b  lea r12, [rax+0x28]
00007f46e3fcf43f  mov r10, [r13+r12*1]
00007f46e3fcf444  movq xmm1, r11
00007f46e3fcf449  movq xmm10, r10
00007f46e3fcf44e  movq xmm1, xmm1
00007f46e3fcf452  vmovaps [rsp+0x80], xmm1
00007f46e3fcf45b  movq xmm1, xmm1
00007f46e3fcf45f  movaps [r15+0x150], xmm1
00007f46e3fcf467  movq xmm10, xmm10
00007f46e3fcf46c  vmovaps [rsp+0x90], xmm10
00007f46e3fcf475  movq xmm10, xmm10
00007f46e3fcf47a  movaps [r15+0x140], xmm10
00007f46e3fcf482  lea r12, [rax+0x10]
00007f46e3fcf486  mov r11, [r13+r12*1]
00007f46e3fcf48b  lea r12, [rax+0x18]
00007f46e3fcf48f  mov r10, [r13+r12*1]
00007f46e3fcf494  movq xmm1, r11
00007f46e3fcf499  movq xmm10, r10
00007f46e3fcf49e  movq xmm1, xmm1
00007f46e3fcf4a2  vmovaps [rsp+0xA0], xmm1
00007f46e3fcf4ab  movq xmm1, xmm1
00007f46e3fcf4af  movaps [r15+0x170], xmm1
00007f46e3fcf4b7  movq xmm10, xmm10
00007f46e3fcf4bc  vmovaps [rsp+0xB0], xmm10
00007f46e3fcf4c5  movq xmm10, xmm10
00007f46e3fcf4ca  movaps [r15+0x160], xmm10
00007f46e3fcf4d2  mov r12, [r13+rax*1]
00007f46e3fcf4d7  vmovq xmm1, r12
00007f46e3fcf4dc  vpbroadcastq xmm1, xmm1
00007f46e3fcf4e1  lea r12, [rax+0x08]
00007f46e3fcf4e5  mov rax, [r13+r12*1]
00007f46e3fcf4ea  movq xmm10, rax
00007f46e3fcf4ef  movaps [r15+0x230], xmm10
00007f46e3fcf4f7  lea rax, [r14+0x50]
00007f46e3fcf4fb  movups xmm10, [r13+rax*1]
00007f46e3fcf501  lea rax, [r14+0x60]
00007f46e3fcf505  vmovaps [rsp+0xC0], xmm1
00007f46e3fcf50e  movups xmm1, [r13+rax*1]
00007f46e3fcf514  lea rax, [r14+0x30]
00007f46e3fcf518  vmovaps [rsp+0xD0], xmm1
00007f46e3fcf521  movups xmm1, [r13+rax*1]
00007f46e3fcf527  mov qword ptr [r15+0x60], 0x430920
00007f46e3fcf52f  mov qword ptr [r15+0x58], 0x40
00007f46e3fcf537  vmovaps [rsp+0xE0], xmm1
00007f46e3fcf540  vmovaps [rsp+0xF0], xmm15
00007f46e3fcf549  vmovaps xmm15, [rsp+0xC0]
00007f46e3fcf552  vmovaps [rsp+0xC0], xmm14
00007f46e3fcf55b  vmovaps xmm14, [rsp+0x40]
00007f46e3fcf561  vmovaps [rsp+0x40], xmm13
00007f46e3fcf567  movaps xmm1, xmm15
00007f46e3fcf56b  mulpd xmm1, xmm14
00007f46e3fcf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007f46e3fcf575  ptest xmm13, xmm13
00007f46e3fcf57b  jnz 0x00007F46E3FD0682
00007f46e3fcf581  movq xmm14, qword ptr [r15+0x230]
00007f46e3fcf58a  vmovaps [rsp+0x100], xmm14
00007f46e3fcf593  vpermilpd xmm14, xmm14, 0x00
00007f46e3fcf599  vmovaps [rsp+0x110], xmm1
00007f46e3fcf5a2  vmovaps xmm1, [rsp+0xE0]
00007f46e3fcf5ab  vmovaps [rsp+0xE0], xmm15
00007f46e3fcf5b4  movaps xmm13, xmm1
00007f46e3fcf5b8  mulpd xmm13, xmm14
00007f46e3fcf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007f46e3fcf5c3  ptest xmm15, xmm15
00007f46e3fcf5c9  jnz 0x00007F46E3FD07C4
00007f46e3fcf5cf  vxorps xmm1, xmm1, xmm1
00007f46e3fcf5d3  vpbroadcastq xmm1, xmm1
00007f46e3fcf5d8  vmovaps xmm14, [rsp+0xE0]
00007f46e3fcf5e1  vmovaps [rsp+0xE0], xmm1
00007f46e3fcf5ea  vmovaps xmm1, [rsp+0xD0]
00007f46e3fcf5f3  vmovaps [rsp+0xD0], xmm13
00007f46e3fcf5fc  movaps xmm15, xmm14
00007f46e3fcf600  mulpd xmm15, xmm1
00007f46e3fcf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007f46e3fcf60b  ptest xmm13, xmm13
00007f46e3fcf611  jnz 0x00007F46E3FD0907
00007f46e3fcf617  movaps xmm1, xmm14
00007f46e3fcf61b  mulpd xmm1, xmm10
00007f46e3fcf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007f46e3fcf625  ptest xmm13, xmm13
00007f46e3fcf62b  jnz 0x00007F46E3FD0A4A
00007f46e3fcf631  movaps xmm13, xmm14
00007f46e3fcf635  mulpd xmm13, xmm2
00007f46e3fcf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007f46e3fcf640  ptest xmm10, xmm10
00007f46e3fcf646  jnz 0x00007F46E3FD0B8C
00007f46e3fcf64c  vmovaps [rsp+0x120], xmm7
00007f46e3fcf655  vmovaps xmm14, [rsp+0x120]
00007f46e3fcf65e  por xmm7, xmm14
00007f46e3fcf663  vmovaps xmm14, [rsp+0xC0]
00007f46e3fcf66c  vmovaps xmm10, [rsp+0xC0]
00007f46e3fcf675  por xmm14, xmm10
00007f46e3fcf67a  vmovaps xmm2, [rsp+0x100]
00007f46e3fcf683  vpermilpd xmm2, xmm2, 0x00
00007f46e3fcf689  vmovaps [rsp+0xC0], xmm1
00007f46e3fcf692  vmovaps [rsp+0x120], xmm15
00007f46e3fcf69b  movaps xmm1, xmm10
00007f46e3fcf69f  mulpd xmm1, xmm2
00007f46e3fcf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007f46e3fcf6a8  ptest xmm15, xmm15
00007f46e3fcf6ae  jnz 0x00007F46E3FD0CCF
00007f46e3fcf6b4  xor eax, eax
00007f46e3fcf6b6  mov r12d, 0x40
00007f46e3fcf6bc  mov r11d, 0x200
00007f46e3fcf6c2  cmp r12, r11
00007f46e3fcf6c5  cmc
00007f46e3fcf6c6  lahf
00007f46e3fcf6c7  seto al
00007f46e3fcf6ca  mov [r15+0x108], eax
00007f46e3fcf6d1  vmovaps xmm10, [rsp+0x110]
00007f46e3fcf6da  vmovaps xmm2, [rsp+0xE0]
00007f46e3fcf6e3  vmovaps [rsp+0xE0], xmm1
00007f46e3fcf6ec  movaps xmm15, xmm10
00007f46e3fcf6f0  addpd xmm15, xmm2
00007f46e3fcf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007f46e3fcf6fb  ptest xmm1, xmm1
00007f46e3fcf700  jnz 0x00007F46E3FD0E10
00007f46e3fcf706  vmovaps xmm10, [rsp+0x120]
00007f46e3fcf70f  vmovaps [rsp+0x110], xmm15
00007f46e3fcf718  movaps xmm1, xmm10
00007f46e3fcf71c  addpd xmm1, xmm12
00007f46e3fcf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007f46e3fcf726  ptest xmm15, xmm15
00007f46e3fcf72c  jnz 0x00007F46E3FD0F53
00007f46e3fcf732  vmovaps xmm10, [rsp+0xC0]
00007f46e3fcf73b  vmovaps [rsp+0xC0], xmm1
00007f46e3fcf744  movaps xmm15, xmm10
00007f46e3fcf748  addpd xmm15, xmm12
00007f46e3fcf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007f46e3fcf753  ptest xmm1, xmm1
00007f46e3fcf758  jnz 0x00007F46E3FD1095
00007f46e3fcf75e  vmovaps xmm1, [rsp+0x30]
00007f46e3fcf764  vmovaps xmm12, [rsp+0x30]
00007f46e3fcf76a  por xmm1, xmm12
00007f46e3fcf76f  vmovaps xmm12, [rsp+0x20]
00007f46e3fcf775  vmovaps xmm10, [rsp+0x20]
00007f46e3fcf77b  por xmm12, xmm10
00007f46e3fcf780  vmovaps [rsp+0x20], xmm5
00007f46e3fcf786  vmovaps xmm10, [rsp+0x20]
00007f46e3fcf78c  por xmm5, xmm10
00007f46e3fcf791  vmovaps [rsp+0x20], xmm11
00007f46e3fcf797  vmovaps xmm10, [rsp+0x20]
00007f46e3fcf79d  por xmm11, xmm10
00007f46e3fcf7a2  vmovaps [rsp+0x20], xmm4
00007f46e3fcf7a8  vmovaps xmm10, [rsp+0x20]
00007f46e3fcf7ae  por xmm4, xmm10
00007f46e3fcf7b3  vmovaps [rsp+0x20], xmm8
00007f46e3fcf7b9  vmovaps xmm10, [rsp+0x20]
00007f46e3fcf7bf  por xmm8, xmm10
00007f46e3fcf7c4  vmovaps xmm10, [rsp+0xF0]
00007f46e3fcf7cd  vmovaps [rsp+0x20], xmm1
00007f46e3fcf7d3  vmovaps xmm1, [rsp+0xF0]
00007f46e3fcf7dc  por xmm10, xmm1
00007f46e3fcf7e1  lea rax, [r14+0xA0]
00007f46e3fcf7e8  movups xmm1, [r13+rax*1]
00007f46e3fcf7ee  lea rax, [r14+0xB0]
00007f46e3fcf7f5  vmovaps [rsp+0x30], xmm1
00007f46e3fcf7fb  movups xmm1, [r13+rax*1]
00007f46e3fcf801  vmovaps [rsp+0xF0], xmm1
00007f46e3fcf80a  vmovaps [rsp+0x120], xmm15
00007f46e3fcf813  movaps xmm1, xmm13
00007f46e3fcf817  addpd xmm1, xmm2
00007f46e3fcf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007f46e3fcf820  ptest xmm15, xmm15
00007f46e3fcf826  jnz 0x00007F46E3FD11ED
00007f46e3fcf82c  lea rax, [r14+0xF0]
00007f46e3fcf833  movups xmm15, [r13+rax*1]
00007f46e3fcf839  vmovaps xmm2, [rsp+0xC0]
00007f46e3fcf842  vmovaps [rsp+0xC0], xmm1
00007f46e3fcf84b  vmovaps xmm1, [rsp+0xE0]
00007f46e3fcf854  vmovaps [rsp+0xE0], xmm15
00007f46e3fcf85d  movaps xmm13, xmm2
00007f46e3fcf861  addpd xmm13, xmm1
00007f46e3fcf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007f46e3fcf86c  ptest xmm15, xmm15
00007f46e3fcf872  jnz 0x00007F46E3FD1338
00007f46e3fcf878  vmovaps xmm15, [rsp+0x120]
00007f46e3fcf881  vmovaps xmm2, [rsp+0xD0]
00007f46e3fcf88a  vmovaps [rsp+0xD0], xmm14
00007f46e3fcf893  movaps xmm1, xmm15
00007f46e3fcf897  addpd xmm1, xmm2
00007f46e3fcf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007f46e3fcf8a0  ptest xmm14, xmm14
00007f46e3fcf8a6  jnz 0x00007F46E3FD147A
00007f46e3fcf8ac  vmovaps xmm15, [rsp+0x100]
00007f46e3fcf8b5  vpermilpd xmm15, xmm15, 0x00
00007f46e3fcf8bb  vmovaps xmm2, [rsp+0xF0]
00007f46e3fcf8c4  vmovaps [rsp+0xF0], xmm1
00007f46e3fcf8cd  movaps xmm14, xmm2
00007f46e3fcf8d1  mulpd xmm14, xmm15
00007f46e3fcf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007f46e3fcf8dc  ptest xmm1, xmm1
00007f46e3fcf8e1  jnz 0x00007F46E3FD15BB
00007f46e3fcf8e7  vmovaps xmm1, [rsp+0xA0]
00007f46e3fcf8f0  vpermilpd xmm1, xmm1, 0x00
00007f46e3fcf8f6  vmovaps xmm2, [rsp+0xE0]
00007f46e3fcf8ff  vmovaps [rsp+0xE0], xmm14
00007f46e3fcf908  movaps xmm15, xmm2
00007f46e3fcf90c  mulpd xmm15, xmm1
00007f46e3fcf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007f46e3fcf917  ptest xmm14, xmm14
00007f46e3fcf91d  jnz 0x00007F46E3FD16FE
00007f46e3fcf923  lea rax, [r14+0xE0]
00007f46e3fcf92a  movups xmm1, [r13+rax*1]
00007f46e3fcf930  vmovaps xmm14, [rsp+0x100]
00007f46e3fcf939  vpermilpd xmm14, xmm14, 0x00
00007f46e3fcf93f  vmovaps [rsp+0x100], xmm1
00007f46e3fcf948  vmovaps xmm1, [rsp+0x30]
00007f46e3fcf94e  vmovaps [rsp+0x30], xmm15
00007f46e3fcf954  movaps xmm2, xmm1
00007f46e3fcf957  mulpd xmm2, xmm14
00007f46e3fcf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007f46e3fcf961  ptest xmm15, xmm15
00007f46e3fcf967  jnz 0x00007F46E3FD184A
00007f46e3fcf96d  vmovaps [rsp+0x120], xmm10
00007f46e3fcf976  vmovaps xmm1, [rsp+0x120]
00007f46e3fcf97f  por xmm10, xmm1
00007f46e3fcf984  movaps [r15+0x300], xmm10
00007f46e3fcf98c  vmovaps [rsp+0x120], xmm8
00007f46e3fcf995  vmovaps xmm1, [rsp+0x120]
00007f46e3fcf99e  por xmm8, xmm1
00007f46e3fcf9a3  movaps [r15+0x190], xmm8
00007f46e3fcf9ab  vmovaps xmm1, [rsp+0xA0]
00007f46e3fcf9b4  vpermilpd xmm1, xmm1, 0x00
00007f46e3fcf9ba  vmovaps xmm14, [rsp+0x100]
00007f46e3fcf9c3  vmovaps [rsp+0x100], xmm13
00007f46e3fcf9cc  movaps xmm15, xmm14
00007f46e3fcf9d0  mulpd xmm15, xmm1
00007f46e3fcf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007f46e3fcf9db  ptest xmm13, xmm13
00007f46e3fcf9e1  jnz 0x00007F46E3FD198B
00007f46e3fcf9e7  lea rax, [r14+0x90]
00007f46e3fcf9ee  movups xmm1, [r13+rax*1]
00007f46e3fcf9f4  vmovaps [rsp+0x120], xmm4
00007f46e3fcf9fd  vmovaps xmm14, [rsp+0x120]
00007f46e3fcfa06  por xmm4, xmm14
00007f46e3fcfa0b  movaps [r15+0x1C0], xmm4
00007f46e3fcfa13  vmovaps [rsp+0x120], xmm11
00007f46e3fcfa1c  vmovaps xmm14, [rsp+0x120]
00007f46e3fcfa25  por xmm11, xmm14
00007f46e3fcfa2a  movaps [r15+0x200], xmm11
00007f46e3fcfa32  vmovaps [rsp+0x120], xmm5
00007f46e3fcfa3b  vmovaps xmm14, [rsp+0x120]
00007f46e3fcfa44  por xmm5, xmm14
00007f46e3fcfa49  movaps [r15+0x2D0], xmm5
00007f46e3fcfa51  vmovaps [rsp+0x120], xmm12
00007f46e3fcfa5a  vmovaps xmm14, [rsp+0x120]
00007f46e3fcfa63  por xmm12, xmm14
00007f46e3fcfa68  movaps [r15+0x2E0], xmm12
00007f46e3fcfa70  vmovaps xmm13, [rsp+0x110]
00007f46e3fcfa79  vmovaps [rsp+0x110], xmm1
00007f46e3fcfa82  vmovaps xmm1, [rsp+0xE0]
00007f46e3fcfa8b  vmovaps [rsp+0xE0], xmm15
00007f46e3fcfa94  movaps xmm14, xmm13
00007f46e3fcfa98  addpd xmm14, xmm1
00007f46e3fcfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007f46e3fcfaa3  ptest xmm15, xmm15
00007f46e3fcfaa9  jnz 0x00007F46E3FD1AD8
00007f46e3fcfaaf  vmovaps xmm1, [rsp+0xA0]
00007f46e3fcfab8  vpermilpd xmm1, xmm1, 0x00
00007f46e3fcfabe  vmovaps xmm13, [rsp+0x110]
00007f46e3fcfac7  vmovaps [rsp+0x110], xmm14
00007f46e3fcfad0  movaps xmm15, xmm13
00007f46e3fcfad4  mulpd xmm15, xmm1
00007f46e3fcfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007f46e3fcfadf  ptest xmm14, xmm14
00007f46e3fcfae5  jnz 0x00007F46E3FD1C1B
00007f46e3fcfaeb  lea rax, [r14+0x80]
00007f46e3fcfaf2  movups xmm1, [r13+rax*1]
00007f46e3fcfaf8  vmovaps xmm13, [rsp+0xC0]
00007f46e3fcfb01  vmovaps [rsp+0xC0], xmm1
00007f46e3fcfb0a  movaps xmm14, xmm13
00007f46e3fcfb0e  addpd xmm14, xmm2
00007f46e3fcfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007f46e3fcfb19  ptest xmm1, xmm1
00007f46e3fcfb1e  jnz 0x00007F46E3FD1D68
00007f46e3fcfb24  vmovaps xmm13, [rsp+0x100]
00007f46e3fcfb2d  vmovaps xmm2, [rsp+0x30]
00007f46e3fcfb33  vmovaps [rsp+0x30], xmm15
00007f46e3fcfb39  movaps xmm1, xmm13
00007f46e3fcfb3d  addpd xmm1, xmm2
00007f46e3fcfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007f46e3fcfb46  ptest xmm15, xmm15
00007f46e3fcfb4c  jnz 0x00007F46E3FD1EAB
00007f46e3fcfb52  vmovaps xmm15, [rsp+0x20]
00007f46e3fcfb58  vmovaps xmm13, [rsp+0x20]
00007f46e3fcfb5e  por xmm15, xmm13
00007f46e3fcfb63  movaps [r15+0x2F0], xmm15
00007f46e3fcfb6b  vmovaps xmm13, [rsp+0xA0]
00007f46e3fcfb74  vpermilpd xmm13, xmm13, 0x00
00007f46e3fcfb7a  vmovaps [rsp+0x20], xmm1
00007f46e3fcfb80  vmovaps xmm1, [rsp+0xC0]
00007f46e3fcfb89  vmovaps [rsp+0xA0], xmm15
00007f46e3fcfb92  movaps xmm2, xmm1
00007f46e3fcfb95  mulpd xmm2, xmm13
00007f46e3fcfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007f46e3fcfb9f  ptest xmm15, xmm15
00007f46e3fcfba5  jnz 0x00007F46E3FD1FEC
00007f46e3fcfbab  lea rax, [r14+0xD0]
00007f46e3fcfbb2  movups xmm1, [r13+rax*1]
00007f46e3fcfbb8  vmovaps xmm13, [rsp+0xF0]
00007f46e3fcfbc1  vmovaps [rsp+0xC0], xmm1
00007f46e3fcfbca  vmovaps xmm1, [rsp+0xE0]
00007f46e3fcfbd3  vmovaps [rsp+0xE0], xmm14
00007f46e3fcfbdc  movaps xmm15, xmm13
00007f46e3fcfbe0  addpd xmm15, xmm1
00007f46e3fcfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007f46e3fcfbeb  ptest xmm14, xmm14
00007f46e3fcfbf1  jnz 0x00007F46E3FD2137
00007f46e3fcfbf7  vmovaps xmm1, [rsp+0xB0]
00007f46e3fcfc00  vpermilpd xmm1, xmm1, 0x00
00007f46e3fcfc06  movaps xmm14, xmm11
00007f46e3fcfc0a  mulpd xmm14, xmm1
00007f46e3fcfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007f46e3fcfc15  ptest xmm13, xmm13
00007f46e3fcfc1b  jnz 0x00007F46E3FD227A
00007f46e3fcfc21  movaps [r15+0x260], xmm14
00007f46e3fcfc29  vxorps xmm1, xmm1, xmm1
00007f46e3fcfc2d  vpbroadcastq xmm1, xmm1
00007f46e3fcfc32  movaps [r15+0x1B0], xmm1
00007f46e3fcfc3a  vmovaps xmm1, [rsp+0xB0]
00007f46e3fcfc43  vpermilpd xmm1, xmm1, 0x00
00007f46e3fcfc49  vmovaps xmm11, [rsp+0xC0]
00007f46e3fcfc52  vmovaps [rsp+0xC0], xmm15
00007f46e3fcfc5b  movaps xmm13, xmm11
00007f46e3fcfc5f  mulpd xmm13, xmm1
00007f46e3fcfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007f46e3fcfc6a  ptest xmm15, xmm15
00007f46e3fcfc70  jnz 0x00007F46E3FD23BD
00007f46e3fcfc76  lea rax, [r14+0xC0]
00007f46e3fcfc7d  movups xmm1, [r13+rax*1]
00007f46e3fcfc83  vmovaps xmm11, [rsp+0x110]
00007f46e3fcfc8c  vmovaps [rsp+0xF0], xmm1
00007f46e3fcfc95  vmovaps xmm1, [rsp+0x30]
00007f46e3fcfc9b  vmovaps [rsp+0x30], xmm14
00007f46e3fcfca1  movaps xmm15, xmm11
00007f46e3fcfca5  addpd xmm15, xmm1
00007f46e3fcfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007f46e3fcfcb0  ptest xmm14, xmm14
00007f46e3fcfcb6  jnz 0x00007F46E3FD250A
00007f46e3fcfcbc  vmovaps [rsp+0x100], xmm9
00007f46e3fcfcc5  vmovaps xmm1, [rsp+0x100]
00007f46e3fcfcce  por xmm9, xmm1
00007f46e3fcfcd3  movaps [r15+0x270], xmm9
00007f46e3fcfcdb  vmovaps [rsp+0x100], xmm6
00007f46e3fcfce4  vmovaps xmm1, [rsp+0x100]
00007f46e3fcfced  por xmm6, xmm1
00007f46e3fcfcf1  movaps [r15+0x1A0], xmm6
00007f46e3fcfcf9  vmovaps xmm14, [rsp+0xB0]
00007f46e3fcfd02  vpermilpd xmm14, xmm14, 0x00
00007f46e3fcfd08  vmovaps xmm6, [rsp+0xF0]
00007f46e3fcfd11  vmovaps [rsp+0xF0], xmm1
00007f46e3fcfd1a  movaps xmm11, xmm6
00007f46e3fcfd1e  mulpd xmm11, xmm14
00007f46e3fcfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007f46e3fcfd29  ptest xmm1, xmm1
00007f46e3fcfd2e  jnz 0x00007F46E3FD264D
00007f46e3fcfd34  lea rax, [r14+0x20]
00007f46e3fcfd38  movups xmm1, [r13+rax*1]
00007f46e3fcfd3e  movaps [r15+0x110], xmm1
00007f46e3fcfd46  vmovaps xmm6, [rsp+0xE0]
00007f46e3fcfd4f  vmovaps [rsp+0xE0], xmm1
00007f46e3fcfd58  movaps xmm14, xmm6
00007f46e3fcfd5c  addpd xmm14, xmm2
00007f46e3fcfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007f46e3fcfd67  ptest xmm1, xmm1
00007f46e3fcfd6c  jnz 0x00007F46E3FD279A
00007f46e3fcfd72  vmovaps xmm1, [rsp+0xB0]
00007f46e3fcfd7b  vpermilpd xmm1, xmm1, 0x00
00007f46e3fcfd81  movaps xmm6, xmm5
00007f46e3fcfd84  mulpd xmm6, xmm1
00007f46e3fcfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007f46e3fcfd8d  ptest xmm2, xmm2
00007f46e3fcfd92  jnz 0x00007F46E3FD28DC
00007f46e3fcfd98  vmovaps xmm5, [rsp+0x20]
00007f46e3fcfd9e  movaps xmm1, xmm5
00007f46e3fcfda1  addpd xmm1, xmm13
00007f46e3fcfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007f46e3fcfdab  ptest xmm2, xmm2
00007f46e3fcfdb0  jnz 0x00007F46E3FD2A1C
00007f46e3fcfdb6  vmovaps xmm13, [rsp+0x80]
00007f46e3fcfdbf  vpermilpd xmm13, xmm13, 0x00
00007f46e3fcfdc5  vmovaps xmm2, [rsp+0xE0]
00007f46e3fcfdce  vmovaps [rsp+0x20], xmm1
00007f46e3fcfdd4  movaps xmm5, xmm2
00007f46e3fcfdd7  mulpd xmm5, xmm13
00007f46e3fcfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007f46e3fcfde1  ptest xmm1, xmm1
00007f46e3fcfde6  jnz 0x00007F46E3FD2B5D
00007f46e3fcfdec  vmovaps xmm1, [rsp+0x80]
00007f46e3fcfdf5  vpermilpd xmm1, xmm1, 0x00
00007f46e3fcfdfb  movaps xmm13, xmm10
00007f46e3fcfdff  mulpd xmm13, xmm1
00007f46e3fcfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007f46e3fcfe0a  ptest xmm2, xmm2
00007f46e3fcfe0f  jnz 0x00007F46E3FD2C9E
00007f46e3fcfe15  vmovaps xmm10, [rsp+0x30]
00007f46e3fcfe1b  movaps xmm1, xmm15
00007f46e3fcfe1f  addpd xmm1, xmm10
00007f46e3fcfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007f46e3fcfe29  ptest xmm2, xmm2
00007f46e3fcfe2e  jnz 0x00007F46E3FD2DE1
00007f46e3fcfe34  vmovaps xmm10, [rsp+0xC0]
00007f46e3fcfe3d  movaps xmm15, xmm10
00007f46e3fcfe41  addpd xmm15, xmm11
00007f46e3fcfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007f46e3fcfe4c  ptest xmm2, xmm2
00007f46e3fcfe51  jnz 0x00007F46E3FD2F23
00007f46e3fcfe57  vmovaps xmm11, [rsp+0x80]
00007f46e3fcfe60  vpermilpd xmm11, xmm11, 0x00
00007f46e3fcfe66  movaps xmm10, xmm12
00007f46e3fcfe6a  mulpd xmm10, xmm11
00007f46e3fcfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007f46e3fcfe75  ptest xmm2, xmm2
00007f46e3fcfe7a  jnz 0x00007F46E3FD3067
00007f46e3fcfe80  vmovaps xmm12, [rsp+0x80]
00007f46e3fcfe89  vpermilpd xmm12, xmm12, 0x00
00007f46e3fcfe8f  vmovaps xmm2, [rsp+0xA0]
00007f46e3fcfe98  vmovaps [rsp+0x30], xmm1
00007f46e3fcfe9e  movaps xmm11, xmm2
00007f46e3fcfea2  mulpd xmm11, xmm12
00007f46e3fcfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007f46e3fcfead  ptest xmm1, xmm1
00007f46e3fcfeb2  jnz 0x00007F46E3FD31AB
00007f46e3fcfeb8  movaps xmm1, xmm14
00007f46e3fcfebc  addpd xmm1, xmm6
00007f46e3fcfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007f46e3fcfec5  ptest xmm12, xmm12
00007f46e3fcfecb  jnz 0x00007F46E3FD32EE
00007f46e3fcfed1  vmovaps xmm12, [rsp+0x20]
00007f46e3fcfed7  movaps xmm14, xmm12
00007f46e3fcfedb  addpd xmm14, xmm5
00007f46e3fcfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007f46e3fcfee6  ptest xmm6, xmm6
00007f46e3fcfeeb  jnz 0x00007F46E3FD342F
00007f46e3fcfef1  vmovaps xmm12, [rsp+0x90]
00007f46e3fcfefa  vpermilpd xmm12, xmm12, 0x00
00007f46e3fcff00  movaps xmm6, xmm9
00007f46e3fcff04  mulpd xmm6, xmm12
00007f46e3fcff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007f46e3fcff0e  ptest xmm5, xmm5
00007f46e3fcff13  jnz 0x00007F46E3FD3572
00007f46e3fcff19  movaps xmm12, xmm15
00007f46e3fcff1d  addpd xmm12, xmm13
00007f46e3fcff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007f46e3fcff28  ptest xmm9, xmm9
00007f46e3fcff2e  jnz 0x00007F46E3FD36B4
00007f46e3fcff34  vmovaps xmm13, [rsp+0x30]
00007f46e3fcff3a  movaps xmm15, xmm13
00007f46e3fcff3e  addpd xmm15, xmm10
00007f46e3fcff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007f46e3fcff49  ptest xmm9, xmm9
00007f46e3fcff4f  jnz 0x00007F46E3FD37F8
00007f46e3fcff55  vmovaps xmm13, [rsp+0xD0]
00007f46e3fcff5e  vmovaps xmm10, [rsp+0xD0]
00007f46e3fcff67  por xmm13, xmm10
00007f46e3fcff6c  movaps [r15+0x250], xmm13
00007f46e3fcff74  vmovaps [rsp+0x20], xmm7
00007f46e3fcff7a  vmovaps xmm13, [rsp+0x20]
00007f46e3fcff80  por xmm7, xmm13
00007f46e3fcff85  movaps [r15+0x2A0], xmm7
00007f46e3fcff8d  vmovaps [rsp+0x20], xmm3
00007f46e3fcff93  vmovaps xmm13, [rsp+0x20]
00007f46e3fcff99  por xmm3, xmm13
00007f46e3fcff9e  movaps [r15+0x1D0], xmm3
00007f46e3fcffa6  lea rax, [r14+0x40]
00007f46e3fcffaa  movups xmm13, [r13+rax*1]
00007f46e3fcffb0  movaps [r15+0x2C0], xmm13
00007f46e3fcffb8  vmovaps xmm10, [rsp+0x90]
00007f46e3fcffc1  vpermilpd xmm10, xmm10, 0x00
00007f46e3fcffc7  movaps xmm9, xmm8
00007f46e3fcffcb  mulpd xmm9, xmm10
00007f46e3fcffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007f46e3fcffd6  ptest xmm5, xmm5
00007f46e3fcffdb  jnz 0x00007F46E3FD3946
00007f46e3fcffe1  movaps xmm10, xmm1
00007f46e3fcffe5  addpd xmm10, xmm11
00007f46e3fcffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007f46e3fcfff0  ptest xmm8, xmm8
00007f46e3fcfff6  jnz 0x00007F46E3FD3A8A
00007f46e3fcfffc  movaps xmm1, xmm14
00007f46e3fd0000  addpd xmm1, xmm6
00007f46e3fd0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007f46e3fd0009  ptest xmm11, xmm11
00007f46e3fd000f  jnz 0x00007F46E3FD3BCD
00007f46e3fd0015  vmovaps xmm14, [rsp+0x90]
00007f46e3fd001e  vpermilpd xmm14, xmm14, 0x00
00007f46e3fd0024  movaps xmm11, xmm13
00007f46e3fd0028  mulpd xmm11, xmm14
00007f46e3fd002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007f46e3fd0033  ptest xmm8, xmm8
00007f46e3fd0039  jnz 0x00007F46E3FD3D0E
00007f46e3fd003f  vmovaps xmm14, [rsp+0x90]
00007f46e3fd0048  vpermilpd xmm14, xmm14, 0x00
00007f46e3fd004e  vmovaps xmm8, [rsp+0x10]
00007f46e3fd0054  movaps xmm13, xmm8
00007f46e3fd0058  mulpd xmm13, xmm14
00007f46e3fd005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007f46e3fd0063  ptest xmm6, xmm6
00007f46e3fd0068  jnz 0x00007F46E3FD3E52
00007f46e3fd006e  vmovaps xmm14, [rsp+0x60]
00007f46e3fd0074  vpermilpd xmm14, xmm14, 0x00
00007f46e3fd007a  movaps xmm8, xmm7
00007f46e3fd007e  mulpd xmm8, xmm14
00007f46e3fd0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007f46e3fd0089  ptest xmm6, xmm6
00007f46e3fd008e  jnz 0x00007F46E3FD3F96
00007f46e3fd0094  movaps xmm14, xmm12
00007f46e3fd0098  addpd xmm14, xmm9
00007f46e3fd009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007f46e3fd00a3  ptest xmm7, xmm7
00007f46e3fd00a8  jnz 0x00007F46E3FD40D9
00007f46e3fd00ae  vmovaps xmm12, [rsp+0x60]
00007f46e3fd00b4  vpermilpd xmm12, xmm12, 0x00
00007f46e3fd00ba  vmovaps xmm7, [rsp+0xF0]
00007f46e3fd00c3  movaps xmm9, xmm7
00007f46e3fd00c7  mulpd xmm9, xmm12
00007f46e3fd00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007f46e3fd00d2  ptest xmm6, xmm6
00007f46e3fd00d7  jnz 0x00007F46E3FD421D
00007f46e3fd00dd  movaps xmm12, xmm15
00007f46e3fd00e1  addpd xmm12, xmm11
00007f46e3fd00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007f46e3fd00ec  ptest xmm7, xmm7
00007f46e3fd00f1  jnz 0x00007F46E3FD4360
00007f46e3fd00f7  vmovaps xmm15, [rsp+0x60]
00007f46e3fd00fd  vpermilpd xmm15, xmm15, 0x00
00007f46e3fd0103  vmovaps xmm7, [rsp+0x40]
00007f46e3fd0109  movaps xmm11, xmm7
00007f46e3fd010d  mulpd xmm11, xmm15
00007f46e3fd0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007f46e3fd0118  ptest xmm6, xmm6
00007f46e3fd011d  jnz 0x00007F46E3FD44A4
00007f46e3fd0123  movaps xmm15, xmm10
00007f46e3fd0127  addpd xmm15, xmm13
00007f46e3fd012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007f46e3fd0132  ptest xmm7, xmm7
00007f46e3fd0137  jnz 0x00007F46E3FD45E7
00007f46e3fd013d  vmovaps xmm13, [rsp+0x60]
00007f46e3fd0143  vpermilpd xmm13, xmm13, 0x00
00007f46e3fd0149  vmovaps xmm7, [rsp+0x50]
00007f46e3fd014f  movaps xmm10, xmm7
00007f46e3fd0153  mulpd xmm10, xmm13
00007f46e3fd0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007f46e3fd015e  ptest xmm6, xmm6
00007f46e3fd0163  jnz 0x00007F46E3FD472B
00007f46e3fd0169  movaps xmm13, xmm1
00007f46e3fd016d  addpd xmm13, xmm8
00007f46e3fd0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007f46e3fd0178  ptest xmm7, xmm7
00007f46e3fd017d  jnz 0x00007F46E3FD486E
00007f46e3fd0183  lea rax, [r14+0x70]
00007f46e3fd0187  movups xmm1, [r13+rax*1]
00007f46e3fd018d  movaps [r15+0x240], xmm1
00007f46e3fd0195  movaps xmm8, xmm14
00007f46e3fd0199  addpd xmm8, xmm9
00007f46e3fd019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007f46e3fd01a4  ptest xmm7, xmm7
00007f46e3fd01a9  jnz 0x00007F46E3FD49BB
00007f46e3fd01af  movaps [r15+0x170], xmm8
00007f46e3fd01b7  vmovaps xmm14, [rsp+0x70]
00007f46e3fd01bd  vpermilpd xmm14, xmm14, 0x00
00007f46e3fd01c3  movaps xmm9, xmm1
00007f46e3fd01c7  mulpd xmm9, xmm14
00007f46e3fd01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007f46e3fd01d2  ptest xmm7, xmm7
00007f46e3fd01d7  jnz 0x00007F46E3FD4AFF
00007f46e3fd01dd  vmovaps xmm1, [rsp+0x70]
00007f46e3fd01e3  vpermilpd xmm1, xmm1, 0x00
00007f46e3fd01e9  movaps xmm14, xmm4
00007f46e3fd01ed  mulpd xmm14, xmm1
00007f46e3fd01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007f46e3fd01f8  ptest xmm7, xmm7
00007f46e3fd01fd  jnz 0x00007F46E3FD4C42
00007f46e3fd0203  movaps [r15+0x180], xmm14
00007f46e3fd020b  movaps xmm1, xmm12
00007f46e3fd020f  addpd xmm1, xmm11
00007f46e3fd0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007f46e3fd0219  ptest xmm7, xmm7
00007f46e3fd021e  jnz 0x00007F46E3FD4D84
00007f46e3fd0224  movaps [r15+0x210], xmm1
00007f46e3fd022c  movups xmm12, [r13+r14*1]
00007f46e3fd0232  lea rax, [r14+0x10]
00007f46e3fd0236  movups xmm11, [r13+rax*1]
00007f46e3fd023c  movaps [r15+0x230], xmm11
00007f46e3fd0244  movaps xmm7, xmm15
00007f46e3fd0248  addpd xmm7, xmm10
00007f46e3fd024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007f46e3fd0252  ptest xmm6, xmm6
00007f46e3fd0257  jnz 0x00007F46E3FD4EDA
00007f46e3fd025d  movaps [r15+0x130], xmm7
00007f46e3fd0265  vmovaps xmm15, [rsp+0x70]
00007f46e3fd026b  vpermilpd xmm15, xmm15, 0x00
00007f46e3fd0271  movaps xmm10, xmm11
00007f46e3fd0275  mulpd xmm10, xmm15
00007f46e3fd027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007f46e3fd0280  ptest xmm6, xmm6
00007f46e3fd0285  jnz 0x00007F46E3FD501C
00007f46e3fd028b  movaps [r15+0x220], xmm10
00007f46e3fd0293  vmovaps xmm15, [rsp+0x70]
00007f46e3fd0299  vpermilpd xmm15, xmm15, 0x00
00007f46e3fd029f  movaps xmm11, xmm12
00007f46e3fd02a3  mulpd xmm11, xmm15
00007f46e3fd02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007f46e3fd02ae  ptest xmm6, xmm6
00007f46e3fd02b3  jnz 0x00007F46E3FD5160
00007f46e3fd02b9  movaps xmm15, xmm13
00007f46e3fd02bd  addpd xmm15, xmm9
00007f46e3fd02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007f46e3fd02c8  ptest xmm12, xmm12
00007f46e3fd02ce  jnz 0x00007F46E3FD52A4
00007f46e3fd02d4  movaps [r15+0x140], xmm15
00007f46e3fd02dc  movaps xmm13, xmm8
00007f46e3fd02e0  addpd xmm13, xmm14
00007f46e3fd02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007f46e3fd02eb  ptest xmm12, xmm12
00007f46e3fd02f1  jnz 0x00007F46E3FD53E8
00007f46e3fd02f7  movaps [r15+0x150], xmm13
00007f46e3fd02ff  movaps xmm14, xmm1
00007f46e3fd0303  addpd xmm14, xmm10
00007f46e3fd0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007f46e3fd030e  ptest xmm12, xmm12
00007f46e3fd0314  jnz 0x00007F46E3FD552C
00007f46e3fd031a  movaps [r15+0x160], xmm14
00007f46e3fd0322  movaps xmm1, xmm7
00007f46e3fd0325  addpd xmm1, xmm11
00007f46e3fd032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007f46e3fd032f  ptest xmm12, xmm12
00007f46e3fd0335  jnz 0x00007F46E3FD566F
00007f46e3fd033b  movaps [r15+0x120], xmm1
00007f46e3fd0343  mov eax, 0x430920
00007f46e3fd0348  movups [r13+rax*1], xmm15
00007f46e3fd034e  mov eax, 0x430930
00007f46e3fd0353  movups [r13+rax*1], xmm13
00007f46e3fd0359  mov eax, 0x430940
00007f46e3fd035e  movups [r13+rax*1], xmm14
00007f46e3fd0364  mov eax, 0x430950
00007f46e3fd0369  movups [r13+rax*1], xmm1
00007f46e3fd036f  mov eax, [r15+0x108]
00007f46e3fd0376  sahf
00007f46e3fd0377  jnz 0x00007F46E3FD03A9
00007f46e3fd0379  cmp dword ptr [r15+0x318], 0x00
00007f46e3fd0381  jz 0x00007F46E3FDB900
00007f46e3fd0387  nop [rax+rax*1], ax
00007f46e3fd0390  nop [rax+rax*1], eax
00007f46e3fd0398  mov eax, 0x410444
00007f46e3fd039d  mov [r15+0x100], rax
00007f46e3fd03a4  jmp 0x00007F46E3DFE110
00007f46e3fd03a9  cmp dword ptr [r15+0x318], 0x00
00007f46e3fd03b1  jz 0x00007F46E3FD57E0
00007f46e3fd03b7  nop [rax+rax*1], ax
00007f46e3fd03c0  nop [rax+rax*1], eax
00007f46e3fd03c8  mov eax, 0x410278
00007f46e3fd03cd  mov [r15+0x100], rax
00007f46e3fd03d4  jmp 0x00007F46E3DFE110
00007f46e3fd03d9  int3
00007f46e3fd03da  call 0x00007F46E3EB52F0
00007f46e3fd03df  jmp 0x00007F46E3FCF016
00007f46e3fd03e4  call 0x00007F46E3EC4620
00007f46e3fd03e9  jmp 0x00007F46E3FCF023
00007f46e3fd03ee  call 0x00007F46E3EC33A0
00007f46e3fd03f3  jmp 0x00007F46E3FCF035
00007f46e3fd03f8  call 0x00007F46E3EC2120
00007f46e3fd03fd  jmp 0x00007F46E3FCF03F
00007f46e3fd0402  call 0x00007F46E3EC0860
00007f46e3fd0407  jmp 0x00007F46E3FCF067
00007f46e3fd040c  call 0x00007F46E3EBF5F0
00007f46e3fd0411  jmp 0x00007F46E3FCF073
00007f46e3fd0416  call 0x00007F46E3EC0860
00007f46e3fd041b  jmp 0x00007F46E3FCF0A5
00007f46e3fd0420  call 0x00007F46E3EBF5F0
00007f46e3fd0425  jmp 0x00007F46E3FCF0B1
00007f46e3fd042a  call 0x00007F46E3EC4740
00007f46e3fd042f  jmp 0x00007F46E3FCF0BE
00007f46e3fd0434  call 0x00007F46E3EB5400
00007f46e3fd0439  jmp 0x00007F46E3FCF0CB
00007f46e3fd043e  call 0x00007F46E3EB52F0
00007f46e3fd0443  jmp 0x00007F46E3FCF0D8
00007f46e3fd0448  call 0x00007F46E3EC4620
00007f46e3fd044d  jmp 0x00007F46E3FCF0E5
00007f46e3fd0452  call 0x00007F46E3EC0860
00007f46e3fd0457  jmp 0x00007F46E3FCF10D
00007f46e3fd045c  call 0x00007F46E3EBF5F0
00007f46e3fd0461  jmp 0x00007F46E3FCF119
00007f46e3fd0466  call 0x00007F46E3E09D70
00007f46e3fd046b  jmp 0x00007F46E3FCF11F
00007f46e3fd0470  call 0x00007F46E3EBE9C0
00007f46e3fd0475  jmp 0x00007F46E3FCF129
00007f46e3fd047a  call 0x00007F46E3EC0860
00007f46e3fd047f  jmp 0x00007F46E3FCF151
00007f46e3fd0484  call 0x00007F46E3EBF5F0
00007f46e3fd0489  jmp 0x00007F46E3FCF15D
00007f46e3fd048e  call 0x00007F46E3EBD750
00007f46e3fd0493  jmp 0x00007F46E3FCF16A
00007f46e3fd0498  call 0x00007F46E3EBC4E0
00007f46e3fd049d  jmp 0x00007F46E3FCF177
00007f46e3fd04a2  call 0x00007F46E3EC4740
00007f46e3fd04a7  jmp 0x00007F46E3FCF184
00007f46e3fd04ac  call 0x00007F46E3EB5400
00007f46e3fd04b1  jmp 0x00007F46E3FCF191
00007f46e3fd04b6  call 0x00007F46E3EB52F0
00007f46e3fd04bb  jmp 0x00007F46E3FCF19E
00007f46e3fd04c0  call 0x00007F46E3EC4620
00007f46e3fd04c5  jmp 0x00007F46E3FCF1AB
00007f46e3fd04ca  call 0x00007F46E3EC0860
00007f46e3fd04cf  jmp 0x00007F46E3FCF1BE
00007f46e3fd04d4  call 0x00007F46E3EBB270
00007f46e3fd04d9  jmp 0x00007F46E3FCF1CB
00007f46e3fd04de  call 0x00007F46E3EBA000
00007f46e3fd04e3  jmp 0x00007F46E3FCF1D8
00007f46e3fd04e8  call 0x00007F46E3EB8D90
00007f46e3fd04ed  jmp 0x00007F46E3FCF1E5
00007f46e3fd04f2  call 0x00007F46E3EB8A20
00007f46e3fd04f7  jmp 0x00007F46E3FCF1F2
00007f46e3fd04fc  call 0x00007F46E3EB5400
00007f46e3fd0501  jmp 0x00007F46E3FCF1FC
00007f46e3fd0506  call 0x00007F46E3EC2240
00007f46e3fd050b  jmp 0x00007F46E3FCF206
00007f46e3fd0510  call 0x00007F46E3EB52F0
00007f46e3fd0515  jmp 0x00007F46E3FCF210
00007f46e3fd051a  call 0x00007F46E3EC2120
00007f46e3fd051f  jmp 0x00007F46E3FCF21A
00007f46e3fd0524  call 0x00007F46E3EB77B0
00007f46e3fd0529  jmp 0x00007F46E3FCF224
00007f46e3fd052e  call 0x00007F46E3EB6550
00007f46e3fd0533  jmp 0x00007F46E3FCF22E
00007f46e3fd0538  call 0x00007F46E3EBFD50
00007f46e3fd053d  jmp 0x00007F46E3FCF240
00007f46e3fd0542  call 0x00007F46E3EB8EA0
00007f46e3fd0547  jmp 0x00007F46E3FCF24A
00007f46e3fd054c  call 0x00007F46E3EBFC30
00007f46e3fd0551  jmp 0x00007F46E3FCF257
00007f46e3fd0556  call 0x00007F46E3EB8D90
00007f46e3fd055b  jmp 0x00007F46E3FCF264
00007f46e3fd0560  call 0x00007F46E3EC2240
00007f46e3fd0565  jmp 0x00007F46E3FCF271
00007f46e3fd056a  call 0x00007F46E3EB5400
00007f46e3fd056f  jmp 0x00007F46E3FCF27E
00007f46e3fd0574  call 0x00007F46E3EB52F0
00007f46e3fd0579  jmp 0x00007F46E3FCF28B
00007f46e3fd057e  call 0x00007F46E3EC2120
00007f46e3fd0583  jmp 0x00007F46E3FCF298
00007f46e3fd0588  call 0x00007F46E3EB52F0
00007f46e3fd058d  jmp 0x00007F46E3FCF2AB
00007f46e3fd0592  call 0x00007F46E3EB52F0
00007f46e3fd0597  jmp 0x00007F46E3FCF2BE
00007f46e3fd059c  call 0x00007F46E3EB52F0
00007f46e3fd05a1  jmp 0x00007F46E3FCF2D1
00007f46e3fd05a6  call 0x00007F46E3EB52F0
00007f46e3fd05ab  jmp 0x00007F46E3FCF2E4
00007f46e3fd05b0  call 0x00007F46E3EC2240
00007f46e3fd05b5  jmp 0x00007F46E3FCF2F9
00007f46e3fd05ba  call 0x00007F46E3EC2240
00007f46e3fd05bf  jmp 0x00007F46E3FCF30C
00007f46e3fd05c4  call 0x00007F46E3EC2120
00007f46e3fd05c9  jmp 0x00007F46E3FCF319
00007f46e3fd05ce  call 0x00007F46E3EB52F0
00007f46e3fd05d3  jmp 0x00007F46E3FCF32C
00007f46e3fd05d8  call 0x00007F46E3EB52F0
00007f46e3fd05dd  jmp 0x00007F46E3FCF34F
00007f46e3fd05e2  call 0x00007F46E3EB52F0
00007f46e3fd05e7  jmp 0x00007F46E3FCF362
00007f46e3fd05ec  call 0x00007F46E3DFF540
00007f46e3fd05f1  jmp 0x00007F46E3FCF380
00007f46e3fd05f6  call 0x00007F46E3E08C20
00007f46e3fd05fb  jmp 0x00007F46E3FCF38A
00007f46e3fd0600  call 0x00007F46E3ED6600
00007f46e3fd0605  jmp 0x00007F46E3FCF396
00007f46e3fd060a  call 0x00007F46E3DFF540
00007f46e3fd060f  jmp 0x00007F46E3FCF3A6
00007f46e3fd0614  call 0x00007F46E3EC0370
00007f46e3fd0619  jmp 0x00007F46E3FCF3D4
00007f46e3fd061e  call 0x00007F46E3EBF100
00007f46e3fd0623  jmp 0x00007F46E3FCF3DD
00007f46e3fd0628  call 0x00007F46E3EC0370
00007f46e3fd062d  jmp 0x00007F46E3FCF43B
00007f46e3fd0632  call 0x00007F46E3EBF100
00007f46e3fd0637  jmp 0x00007F46E3FCF444
00007f46e3fd063c  call 0x00007F46E3EC0370
00007f46e3fd0641  jmp 0x00007F46E3FCF48B
00007f46e3fd0646  call 0x00007F46E3EBF100
00007f46e3fd064b  jmp 0x00007F46E3FCF494
00007f46e3fd0650  call 0x00007F46E3E0B720
00007f46e3fd0655  jmp 0x00007F46E3FCF4D7
00007f46e3fd065a  call 0x00007F46E3EB47C0
00007f46e3fd065f  jmp 0x00007F46E3FCF4EA
00007f46e3fd0664  call 0x00007F46E3E08B00
00007f46e3fd0669  jmp 0x00007F46E3FCF501
00007f46e3fd066e  call 0x00007F46E3DFF430
00007f46e3fd0673  jmp 0x00007F46E3FCF514
00007f46e3fd0678  call 0x00007F46E3DFF430
00007f46e3fd067d  jmp 0x00007F46E3FCF527
00007f46e3fd0682  sub rsp, 0x08
00007f46e3fd0686  push rax
00007f46e3fd0687  push rcx
00007f46e3fd0688  push rdx
00007f46e3fd0689  push rdi
00007f46e3fd068a  push rsi
00007f46e3fd068b  push r8
00007f46e3fd068d  push r9
00007f46e3fd068f  push r10
00007f46e3fd0691  push r11
00007f46e3fd0693  sub rsp, 0xF0
00007f46e3fd069a  vmovaps [rsp], xmm0
00007f46e3fd069f  vmovaps [rsp+0x10], xmm2
00007f46e3fd06a5  vmovaps [rsp+0x20], xmm3
00007f46e3fd06ab  vmovaps [rsp+0x30], xmm4
00007f46e3fd06b1  vmovaps [rsp+0x40], xmm5
00007f46e3fd06b7  vmovaps [rsp+0x50], xmm6
00007f46e3fd06bd  vmovaps [rsp+0x60], xmm7
00007f46e3fd06c3  vmovaps [rsp+0x70], xmm8
00007f46e3fd06c9  vmovaps [rsp+0x80], xmm9
00007f46e3fd06d2  vmovaps [rsp+0x90], xmm10
00007f46e3fd06db  vmovaps [rsp+0xA0], xmm11
00007f46e3fd06e4  vmovaps [rsp+0xB0], xmm12
00007f46e3fd06ed  vmovaps [rsp+0xC0], xmm13
00007f46e3fd06f6  vmovaps [rsp+0xD0], xmm14
00007f46e3fd06ff  vmovaps [rsp+0xE0], xmm15
00007f46e3fd0708  sub rsp, 0x30
00007f46e3fd070c  movaps [rsp], xmm1
00007f46e3fd0710  movaps [rsp+0x10], xmm15
00007f46e3fd0716  movaps [rsp+0x20], xmm14
00007f46e3fd071c  lea rdi, [rsp]
00007f46e3fd0720  mov esi, 0x00
00007f46e3fd0725  mov rax, 0x6238B185B530
00007f46e3fd072f  call rax
00007f46e3fd0731  movaps xmm1, [rsp]
00007f46e3fd0735  add rsp, 0x30
00007f46e3fd0739  vmovaps xmm0, [rsp]
00007f46e3fd073e  vmovaps xmm2, [rsp+0x10]
00007f46e3fd0744  vmovaps xmm3, [rsp+0x20]
00007f46e3fd074a  vmovaps xmm4, [rsp+0x30]
00007f46e3fd0750  vmovaps xmm5, [rsp+0x40]
00007f46e3fd0756  vmovaps xmm6, [rsp+0x50]
00007f46e3fd075c  vmovaps xmm7, [rsp+0x60]
00007f46e3fd0762  vmovaps xmm8, [rsp+0x70]
00007f46e3fd0768  vmovaps xmm9, [rsp+0x80]
00007f46e3fd0771  vmovaps xmm10, [rsp+0x90]
00007f46e3fd077a  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd0783  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd078c  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd0795  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd079e  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd07a7  add rsp, 0xF0
00007f46e3fd07ae  pop r11
00007f46e3fd07b0  pop r10
00007f46e3fd07b2  pop r9
00007f46e3fd07b4  pop r8
00007f46e3fd07b6  pop rsi
00007f46e3fd07b7  pop rdi
00007f46e3fd07b8  pop rdx
00007f46e3fd07b9  pop rcx
00007f46e3fd07ba  pop rax
00007f46e3fd07bb  add rsp, 0x08
00007f46e3fd07bf  jmp 0x00007F46E3FCF581
00007f46e3fd07c4  sub rsp, 0x08
00007f46e3fd07c8  push rax
00007f46e3fd07c9  push rcx
00007f46e3fd07ca  push rdx
00007f46e3fd07cb  push rdi
00007f46e3fd07cc  push rsi
00007f46e3fd07cd  push r8
00007f46e3fd07cf  push r9
00007f46e3fd07d1  push r10
00007f46e3fd07d3  push r11
00007f46e3fd07d5  sub rsp, 0xF0
00007f46e3fd07dc  vmovaps [rsp], xmm0
00007f46e3fd07e1  vmovaps [rsp+0x10], xmm1
00007f46e3fd07e7  vmovaps [rsp+0x20], xmm2
00007f46e3fd07ed  vmovaps [rsp+0x30], xmm3
00007f46e3fd07f3  vmovaps [rsp+0x40], xmm4
00007f46e3fd07f9  vmovaps [rsp+0x50], xmm5
00007f46e3fd07ff  vmovaps [rsp+0x60], xmm6
00007f46e3fd0805  vmovaps [rsp+0x70], xmm7
00007f46e3fd080b  vmovaps [rsp+0x80], xmm8
00007f46e3fd0814  vmovaps [rsp+0x90], xmm9
00007f46e3fd081d  vmovaps [rsp+0xA0], xmm10
00007f46e3fd0826  vmovaps [rsp+0xB0], xmm11
00007f46e3fd082f  vmovaps [rsp+0xC0], xmm12
00007f46e3fd0838  vmovaps [rsp+0xD0], xmm14
00007f46e3fd0841  vmovaps [rsp+0xE0], xmm15
00007f46e3fd084a  sub rsp, 0x30
00007f46e3fd084e  movaps [rsp], xmm13
00007f46e3fd0853  movaps [rsp+0x10], xmm1
00007f46e3fd0858  movaps [rsp+0x20], xmm14
00007f46e3fd085e  lea rdi, [rsp]
00007f46e3fd0862  mov esi, 0x00
00007f46e3fd0867  mov rax, 0x6238B185B530
00007f46e3fd0871  call rax
00007f46e3fd0873  movaps xmm13, [rsp]
00007f46e3fd0878  add rsp, 0x30
00007f46e3fd087c  vmovaps xmm0, [rsp]
00007f46e3fd0881  vmovaps xmm1, [rsp+0x10]
00007f46e3fd0887  vmovaps xmm2, [rsp+0x20]
00007f46e3fd088d  vmovaps xmm3, [rsp+0x30]
00007f46e3fd0893  vmovaps xmm4, [rsp+0x40]
00007f46e3fd0899  vmovaps xmm5, [rsp+0x50]
00007f46e3fd089f  vmovaps xmm6, [rsp+0x60]
00007f46e3fd08a5  vmovaps xmm7, [rsp+0x70]
00007f46e3fd08ab  vmovaps xmm8, [rsp+0x80]
00007f46e3fd08b4  vmovaps xmm9, [rsp+0x90]
00007f46e3fd08bd  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd08c6  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd08cf  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd08d8  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd08e1  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd08ea  add rsp, 0xF0
00007f46e3fd08f1  pop r11
00007f46e3fd08f3  pop r10
00007f46e3fd08f5  pop r9
00007f46e3fd08f7  pop r8
00007f46e3fd08f9  pop rsi
00007f46e3fd08fa  pop rdi
00007f46e3fd08fb  pop rdx
00007f46e3fd08fc  pop rcx
00007f46e3fd08fd  pop rax
00007f46e3fd08fe  add rsp, 0x08
00007f46e3fd0902  jmp 0x00007F46E3FCF5CF
00007f46e3fd0907  sub rsp, 0x08
00007f46e3fd090b  push rax
00007f46e3fd090c  push rcx
00007f46e3fd090d  push rdx
00007f46e3fd090e  push rdi
00007f46e3fd090f  push rsi
00007f46e3fd0910  push r8
00007f46e3fd0912  push r9
00007f46e3fd0914  push r10
00007f46e3fd0916  push r11
00007f46e3fd0918  sub rsp, 0xF0
00007f46e3fd091f  vmovaps [rsp], xmm0
00007f46e3fd0924  vmovaps [rsp+0x10], xmm1
00007f46e3fd092a  vmovaps [rsp+0x20], xmm2
00007f46e3fd0930  vmovaps [rsp+0x30], xmm3
00007f46e3fd0936  vmovaps [rsp+0x40], xmm4
00007f46e3fd093c  vmovaps [rsp+0x50], xmm5
00007f46e3fd0942  vmovaps [rsp+0x60], xmm6
00007f46e3fd0948  vmovaps [rsp+0x70], xmm7
00007f46e3fd094e  vmovaps [rsp+0x80], xmm8
00007f46e3fd0957  vmovaps [rsp+0x90], xmm9
00007f46e3fd0960  vmovaps [rsp+0xA0], xmm10
00007f46e3fd0969  vmovaps [rsp+0xB0], xmm11
00007f46e3fd0972  vmovaps [rsp+0xC0], xmm12
00007f46e3fd097b  vmovaps [rsp+0xD0], xmm13
00007f46e3fd0984  vmovaps [rsp+0xE0], xmm14
00007f46e3fd098d  sub rsp, 0x30
00007f46e3fd0991  movaps [rsp], xmm15
00007f46e3fd0996  movaps [rsp+0x10], xmm14
00007f46e3fd099c  movaps [rsp+0x20], xmm1
00007f46e3fd09a1  lea rdi, [rsp]
00007f46e3fd09a5  mov esi, 0x00
00007f46e3fd09aa  mov rax, 0x6238B185B530
00007f46e3fd09b4  call rax
00007f46e3fd09b6  movaps xmm15, [rsp]
00007f46e3fd09bb  add rsp, 0x30
00007f46e3fd09bf  vmovaps xmm0, [rsp]
00007f46e3fd09c4  vmovaps xmm1, [rsp+0x10]
00007f46e3fd09ca  vmovaps xmm2, [rsp+0x20]
00007f46e3fd09d0  vmovaps xmm3, [rsp+0x30]
00007f46e3fd09d6  vmovaps xmm4, [rsp+0x40]
00007f46e3fd09dc  vmovaps xmm5, [rsp+0x50]
00007f46e3fd09e2  vmovaps xmm6, [rsp+0x60]
00007f46e3fd09e8  vmovaps xmm7, [rsp+0x70]
00007f46e3fd09ee  vmovaps xmm8, [rsp+0x80]
00007f46e3fd09f7  vmovaps xmm9, [rsp+0x90]
00007f46e3fd0a00  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd0a09  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd0a12  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd0a1b  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd0a24  vmovaps xmm14, [rsp+0xE0]
00007f46e3fd0a2d  add rsp, 0xF0
00007f46e3fd0a34  pop r11
00007f46e3fd0a36  pop r10
00007f46e3fd0a38  pop r9
00007f46e3fd0a3a  pop r8
00007f46e3fd0a3c  pop rsi
00007f46e3fd0a3d  pop rdi
00007f46e3fd0a3e  pop rdx
00007f46e3fd0a3f  pop rcx
00007f46e3fd0a40  pop rax
00007f46e3fd0a41  add rsp, 0x08
00007f46e3fd0a45  jmp 0x00007F46E3FCF617
00007f46e3fd0a4a  sub rsp, 0x08
00007f46e3fd0a4e  push rax
00007f46e3fd0a4f  push rcx
00007f46e3fd0a50  push rdx
00007f46e3fd0a51  push rdi
00007f46e3fd0a52  push rsi
00007f46e3fd0a53  push r8
00007f46e3fd0a55  push r9
00007f46e3fd0a57  push r10
00007f46e3fd0a59  push r11
00007f46e3fd0a5b  sub rsp, 0xF0
00007f46e3fd0a62  vmovaps [rsp], xmm0
00007f46e3fd0a67  vmovaps [rsp+0x10], xmm2
00007f46e3fd0a6d  vmovaps [rsp+0x20], xmm3
00007f46e3fd0a73  vmovaps [rsp+0x30], xmm4
00007f46e3fd0a79  vmovaps [rsp+0x40], xmm5
00007f46e3fd0a7f  vmovaps [rsp+0x50], xmm6
00007f46e3fd0a85  vmovaps [rsp+0x60], xmm7
00007f46e3fd0a8b  vmovaps [rsp+0x70], xmm8
00007f46e3fd0a91  vmovaps [rsp+0x80], xmm9
00007f46e3fd0a9a  vmovaps [rsp+0x90], xmm10
00007f46e3fd0aa3  vmovaps [rsp+0xA0], xmm11
00007f46e3fd0aac  vmovaps [rsp+0xB0], xmm12
00007f46e3fd0ab5  vmovaps [rsp+0xC0], xmm13
00007f46e3fd0abe  vmovaps [rsp+0xD0], xmm14
00007f46e3fd0ac7  vmovaps [rsp+0xE0], xmm15
00007f46e3fd0ad0  sub rsp, 0x30
00007f46e3fd0ad4  movaps [rsp], xmm1
00007f46e3fd0ad8  movaps [rsp+0x10], xmm14
00007f46e3fd0ade  movaps [rsp+0x20], xmm10
00007f46e3fd0ae4  lea rdi, [rsp]
00007f46e3fd0ae8  mov esi, 0x00
00007f46e3fd0aed  mov rax, 0x6238B185B530
00007f46e3fd0af7  call rax
00007f46e3fd0af9  movaps xmm1, [rsp]
00007f46e3fd0afd  add rsp, 0x30
00007f46e3fd0b01  vmovaps xmm0, [rsp]
00007f46e3fd0b06  vmovaps xmm2, [rsp+0x10]
00007f46e3fd0b0c  vmovaps xmm3, [rsp+0x20]
00007f46e3fd0b12  vmovaps xmm4, [rsp+0x30]
00007f46e3fd0b18  vmovaps xmm5, [rsp+0x40]
00007f46e3fd0b1e  vmovaps xmm6, [rsp+0x50]
00007f46e3fd0b24  vmovaps xmm7, [rsp+0x60]
00007f46e3fd0b2a  vmovaps xmm8, [rsp+0x70]
00007f46e3fd0b30  vmovaps xmm9, [rsp+0x80]
00007f46e3fd0b39  vmovaps xmm10, [rsp+0x90]
00007f46e3fd0b42  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd0b4b  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd0b54  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd0b5d  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd0b66  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd0b6f  add rsp, 0xF0
00007f46e3fd0b76  pop r11
00007f46e3fd0b78  pop r10
00007f46e3fd0b7a  pop r9
00007f46e3fd0b7c  pop r8
00007f46e3fd0b7e  pop rsi
00007f46e3fd0b7f  pop rdi
00007f46e3fd0b80  pop rdx
00007f46e3fd0b81  pop rcx
00007f46e3fd0b82  pop rax
00007f46e3fd0b83  add rsp, 0x08
00007f46e3fd0b87  jmp 0x00007F46E3FCF631
00007f46e3fd0b8c  sub rsp, 0x08
00007f46e3fd0b90  push rax
00007f46e3fd0b91  push rcx
00007f46e3fd0b92  push rdx
00007f46e3fd0b93  push rdi
00007f46e3fd0b94  push rsi
00007f46e3fd0b95  push r8
00007f46e3fd0b97  push r9
00007f46e3fd0b99  push r10
00007f46e3fd0b9b  push r11
00007f46e3fd0b9d  sub rsp, 0xF0
00007f46e3fd0ba4  vmovaps [rsp], xmm0
00007f46e3fd0ba9  vmovaps [rsp+0x10], xmm1
00007f46e3fd0baf  vmovaps [rsp+0x20], xmm2
00007f46e3fd0bb5  vmovaps [rsp+0x30], xmm3
00007f46e3fd0bbb  vmovaps [rsp+0x40], xmm4
00007f46e3fd0bc1  vmovaps [rsp+0x50], xmm5
00007f46e3fd0bc7  vmovaps [rsp+0x60], xmm6
00007f46e3fd0bcd  vmovaps [rsp+0x70], xmm7
00007f46e3fd0bd3  vmovaps [rsp+0x80], xmm8
00007f46e3fd0bdc  vmovaps [rsp+0x90], xmm9
00007f46e3fd0be5  vmovaps [rsp+0xA0], xmm10
00007f46e3fd0bee  vmovaps [rsp+0xB0], xmm11
00007f46e3fd0bf7  vmovaps [rsp+0xC0], xmm12
00007f46e3fd0c00  vmovaps [rsp+0xD0], xmm14
00007f46e3fd0c09  vmovaps [rsp+0xE0], xmm15
00007f46e3fd0c12  sub rsp, 0x30
00007f46e3fd0c16  movaps [rsp], xmm13
00007f46e3fd0c1b  movaps [rsp+0x10], xmm14
00007f46e3fd0c21  movaps [rsp+0x20], xmm2
00007f46e3fd0c26  lea rdi, [rsp]
00007f46e3fd0c2a  mov esi, 0x00
00007f46e3fd0c2f  mov rax, 0x6238B185B530
00007f46e3fd0c39  call rax
00007f46e3fd0c3b  movaps xmm13, [rsp]
00007f46e3fd0c40  add rsp, 0x30
00007f46e3fd0c44  vmovaps xmm0, [rsp]
00007f46e3fd0c49  vmovaps xmm1, [rsp+0x10]
00007f46e3fd0c4f  vmovaps xmm2, [rsp+0x20]
00007f46e3fd0c55  vmovaps xmm3, [rsp+0x30]
00007f46e3fd0c5b  vmovaps xmm4, [rsp+0x40]
00007f46e3fd0c61  vmovaps xmm5, [rsp+0x50]
00007f46e3fd0c67  vmovaps xmm6, [rsp+0x60]
00007f46e3fd0c6d  vmovaps xmm7, [rsp+0x70]
00007f46e3fd0c73  vmovaps xmm8, [rsp+0x80]
00007f46e3fd0c7c  vmovaps xmm9, [rsp+0x90]
00007f46e3fd0c85  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd0c8e  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd0c97  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd0ca0  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd0ca9  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd0cb2  add rsp, 0xF0
00007f46e3fd0cb9  pop r11
00007f46e3fd0cbb  pop r10
00007f46e3fd0cbd  pop r9
00007f46e3fd0cbf  pop r8
00007f46e3fd0cc1  pop rsi
00007f46e3fd0cc2  pop rdi
00007f46e3fd0cc3  pop rdx
00007f46e3fd0cc4  pop rcx
00007f46e3fd0cc5  pop rax
00007f46e3fd0cc6  add rsp, 0x08
00007f46e3fd0cca  jmp 0x00007F46E3FCF64C
00007f46e3fd0ccf  sub rsp, 0x08
00007f46e3fd0cd3  push rax
00007f46e3fd0cd4  push rcx
00007f46e3fd0cd5  push rdx
00007f46e3fd0cd6  push rdi
00007f46e3fd0cd7  push rsi
00007f46e3fd0cd8  push r8
00007f46e3fd0cda  push r9
00007f46e3fd0cdc  push r10
00007f46e3fd0cde  push r11
00007f46e3fd0ce0  sub rsp, 0xF0
00007f46e3fd0ce7  vmovaps [rsp], xmm0
00007f46e3fd0cec  vmovaps [rsp+0x10], xmm2
00007f46e3fd0cf2  vmovaps [rsp+0x20], xmm3
00007f46e3fd0cf8  vmovaps [rsp+0x30], xmm4
00007f46e3fd0cfe  vmovaps [rsp+0x40], xmm5
00007f46e3fd0d04  vmovaps [rsp+0x50], xmm6
00007f46e3fd0d0a  vmovaps [rsp+0x60], xmm7
00007f46e3fd0d10  vmovaps [rsp+0x70], xmm8
00007f46e3fd0d16  vmovaps [rsp+0x80], xmm9
00007f46e3fd0d1f  vmovaps [rsp+0x90], xmm10
00007f46e3fd0d28  vmovaps [rsp+0xA0], xmm11
00007f46e3fd0d31  vmovaps [rsp+0xB0], xmm12
00007f46e3fd0d3a  vmovaps [rsp+0xC0], xmm13
00007f46e3fd0d43  vmovaps [rsp+0xD0], xmm14
00007f46e3fd0d4c  vmovaps [rsp+0xE0], xmm15
00007f46e3fd0d55  sub rsp, 0x30
00007f46e3fd0d59  movaps [rsp], xmm1
00007f46e3fd0d5d  movaps [rsp+0x10], xmm10
00007f46e3fd0d63  movaps [rsp+0x20], xmm2
00007f46e3fd0d68  lea rdi, [rsp]
00007f46e3fd0d6c  mov esi, 0x00
00007f46e3fd0d71  mov rax, 0x6238B185B530
00007f46e3fd0d7b  call rax
00007f46e3fd0d7d  movaps xmm1, [rsp]
00007f46e3fd0d81  add rsp, 0x30
00007f46e3fd0d85  vmovaps xmm0, [rsp]
00007f46e3fd0d8a  vmovaps xmm2, [rsp+0x10]
00007f46e3fd0d90  vmovaps xmm3, [rsp+0x20]
00007f46e3fd0d96  vmovaps xmm4, [rsp+0x30]
00007f46e3fd0d9c  vmovaps xmm5, [rsp+0x40]
00007f46e3fd0da2  vmovaps xmm6, [rsp+0x50]
00007f46e3fd0da8  vmovaps xmm7, [rsp+0x60]
00007f46e3fd0dae  vmovaps xmm8, [rsp+0x70]
00007f46e3fd0db4  vmovaps xmm9, [rsp+0x80]
00007f46e3fd0dbd  vmovaps xmm10, [rsp+0x90]
00007f46e3fd0dc6  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd0dcf  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd0dd8  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd0de1  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd0dea  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd0df3  add rsp, 0xF0
00007f46e3fd0dfa  pop r11
00007f46e3fd0dfc  pop r10
00007f46e3fd0dfe  pop r9
00007f46e3fd0e00  pop r8
00007f46e3fd0e02  pop rsi
00007f46e3fd0e03  pop rdi
00007f46e3fd0e04  pop rdx
00007f46e3fd0e05  pop rcx
00007f46e3fd0e06  pop rax
00007f46e3fd0e07  add rsp, 0x08
00007f46e3fd0e0b  jmp 0x00007F46E3FCF6B4
00007f46e3fd0e10  sub rsp, 0x08
00007f46e3fd0e14  push rax
00007f46e3fd0e15  push rcx
00007f46e3fd0e16  push rdx
00007f46e3fd0e17  push rdi
00007f46e3fd0e18  push rsi
00007f46e3fd0e19  push r8
00007f46e3fd0e1b  push r9
00007f46e3fd0e1d  push r10
00007f46e3fd0e1f  push r11
00007f46e3fd0e21  sub rsp, 0xF0
00007f46e3fd0e28  vmovaps [rsp], xmm0
00007f46e3fd0e2d  vmovaps [rsp+0x10], xmm1
00007f46e3fd0e33  vmovaps [rsp+0x20], xmm2
00007f46e3fd0e39  vmovaps [rsp+0x30], xmm3
00007f46e3fd0e3f  vmovaps [rsp+0x40], xmm4
00007f46e3fd0e45  vmovaps [rsp+0x50], xmm5
00007f46e3fd0e4b  vmovaps [rsp+0x60], xmm6
00007f46e3fd0e51  vmovaps [rsp+0x70], xmm7
00007f46e3fd0e57  vmovaps [rsp+0x80], xmm8
00007f46e3fd0e60  vmovaps [rsp+0x90], xmm9
00007f46e3fd0e69  vmovaps [rsp+0xA0], xmm10
00007f46e3fd0e72  vmovaps [rsp+0xB0], xmm11
00007f46e3fd0e7b  vmovaps [rsp+0xC0], xmm12
00007f46e3fd0e84  vmovaps [rsp+0xD0], xmm13
00007f46e3fd0e8d  vmovaps [rsp+0xE0], xmm14
00007f46e3fd0e96  sub rsp, 0x30
00007f46e3fd0e9a  movaps [rsp], xmm15
00007f46e3fd0e9f  movaps [rsp+0x10], xmm10
00007f46e3fd0ea5  movaps [rsp+0x20], xmm2
00007f46e3fd0eaa  lea rdi, [rsp]
00007f46e3fd0eae  mov esi, 0x00
00007f46e3fd0eb3  mov rax, 0x6238B185B530
00007f46e3fd0ebd  call rax
00007f46e3fd0ebf  movaps xmm15, [rsp]
00007f46e3fd0ec4  add rsp, 0x30
00007f46e3fd0ec8  vmovaps xmm0, [rsp]
00007f46e3fd0ecd  vmovaps xmm1, [rsp+0x10]
00007f46e3fd0ed3  vmovaps xmm2, [rsp+0x20]
00007f46e3fd0ed9  vmovaps xmm3, [rsp+0x30]
00007f46e3fd0edf  vmovaps xmm4, [rsp+0x40]
00007f46e3fd0ee5  vmovaps xmm5, [rsp+0x50]
00007f46e3fd0eeb  vmovaps xmm6, [rsp+0x60]
00007f46e3fd0ef1  vmovaps xmm7, [rsp+0x70]
00007f46e3fd0ef7  vmovaps xmm8, [rsp+0x80]
00007f46e3fd0f00  vmovaps xmm9, [rsp+0x90]
00007f46e3fd0f09  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd0f12  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd0f1b  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd0f24  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd0f2d  vmovaps xmm14, [rsp+0xE0]
00007f46e3fd0f36  add rsp, 0xF0
00007f46e3fd0f3d  pop r11
00007f46e3fd0f3f  pop r10
00007f46e3fd0f41  pop r9
00007f46e3fd0f43  pop r8
00007f46e3fd0f45  pop rsi
00007f46e3fd0f46  pop rdi
00007f46e3fd0f47  pop rdx
00007f46e3fd0f48  pop rcx
00007f46e3fd0f49  pop rax
00007f46e3fd0f4a  add rsp, 0x08
00007f46e3fd0f4e  jmp 0x00007F46E3FCF706
00007f46e3fd0f53  sub rsp, 0x08
00007f46e3fd0f57  push rax
00007f46e3fd0f58  push rcx
00007f46e3fd0f59  push rdx
00007f46e3fd0f5a  push rdi
00007f46e3fd0f5b  push rsi
00007f46e3fd0f5c  push r8
00007f46e3fd0f5e  push r9
00007f46e3fd0f60  push r10
00007f46e3fd0f62  push r11
00007f46e3fd0f64  sub rsp, 0xF0
00007f46e3fd0f6b  vmovaps [rsp], xmm0
00007f46e3fd0f70  vmovaps [rsp+0x10], xmm2
00007f46e3fd0f76  vmovaps [rsp+0x20], xmm3
00007f46e3fd0f7c  vmovaps [rsp+0x30], xmm4
00007f46e3fd0f82  vmovaps [rsp+0x40], xmm5
00007f46e3fd0f88  vmovaps [rsp+0x50], xmm6
00007f46e3fd0f8e  vmovaps [rsp+0x60], xmm7
00007f46e3fd0f94  vmovaps [rsp+0x70], xmm8
00007f46e3fd0f9a  vmovaps [rsp+0x80], xmm9
00007f46e3fd0fa3  vmovaps [rsp+0x90], xmm10
00007f46e3fd0fac  vmovaps [rsp+0xA0], xmm11
00007f46e3fd0fb5  vmovaps [rsp+0xB0], xmm12
00007f46e3fd0fbe  vmovaps [rsp+0xC0], xmm13
00007f46e3fd0fc7  vmovaps [rsp+0xD0], xmm14
00007f46e3fd0fd0  vmovaps [rsp+0xE0], xmm15
00007f46e3fd0fd9  sub rsp, 0x30
00007f46e3fd0fdd  movaps [rsp], xmm1
00007f46e3fd0fe1  movaps [rsp+0x10], xmm10
00007f46e3fd0fe7  movaps [rsp+0x20], xmm12
00007f46e3fd0fed  lea rdi, [rsp]
00007f46e3fd0ff1  mov esi, 0x00
00007f46e3fd0ff6  mov rax, 0x6238B185B530
00007f46e3fd1000  call rax
00007f46e3fd1002  movaps xmm1, [rsp]
00007f46e3fd1006  add rsp, 0x30
00007f46e3fd100a  vmovaps xmm0, [rsp]
00007f46e3fd100f  vmovaps xmm2, [rsp+0x10]
00007f46e3fd1015  vmovaps xmm3, [rsp+0x20]
00007f46e3fd101b  vmovaps xmm4, [rsp+0x30]
00007f46e3fd1021  vmovaps xmm5, [rsp+0x40]
00007f46e3fd1027  vmovaps xmm6, [rsp+0x50]
00007f46e3fd102d  vmovaps xmm7, [rsp+0x60]
00007f46e3fd1033  vmovaps xmm8, [rsp+0x70]
00007f46e3fd1039  vmovaps xmm9, [rsp+0x80]
00007f46e3fd1042  vmovaps xmm10, [rsp+0x90]
00007f46e3fd104b  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd1054  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd105d  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd1066  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd106f  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd1078  add rsp, 0xF0
00007f46e3fd107f  pop r11
00007f46e3fd1081  pop r10
00007f46e3fd1083  pop r9
00007f46e3fd1085  pop r8
00007f46e3fd1087  pop rsi
00007f46e3fd1088  pop rdi
00007f46e3fd1089  pop rdx
00007f46e3fd108a  pop rcx
00007f46e3fd108b  pop rax
00007f46e3fd108c  add rsp, 0x08
00007f46e3fd1090  jmp 0x00007F46E3FCF732
00007f46e3fd1095  sub rsp, 0x08
00007f46e3fd1099  push rax
00007f46e3fd109a  push rcx
00007f46e3fd109b  push rdx
00007f46e3fd109c  push rdi
00007f46e3fd109d  push rsi
00007f46e3fd109e  push r8
00007f46e3fd10a0  push r9
00007f46e3fd10a2  push r10
00007f46e3fd10a4  push r11
00007f46e3fd10a6  sub rsp, 0xF0
00007f46e3fd10ad  vmovaps [rsp], xmm0
00007f46e3fd10b2  vmovaps [rsp+0x10], xmm1
00007f46e3fd10b8  vmovaps [rsp+0x20], xmm2
00007f46e3fd10be  vmovaps [rsp+0x30], xmm3
00007f46e3fd10c4  vmovaps [rsp+0x40], xmm4
00007f46e3fd10ca  vmovaps [rsp+0x50], xmm5
00007f46e3fd10d0  vmovaps [rsp+0x60], xmm6
00007f46e3fd10d6  vmovaps [rsp+0x70], xmm7
00007f46e3fd10dc  vmovaps [rsp+0x80], xmm8
00007f46e3fd10e5  vmovaps [rsp+0x90], xmm9
00007f46e3fd10ee  vmovaps [rsp+0xA0], xmm10
00007f46e3fd10f7  vmovaps [rsp+0xB0], xmm11
00007f46e3fd1100  vmovaps [rsp+0xC0], xmm12
00007f46e3fd1109  vmovaps [rsp+0xD0], xmm13
00007f46e3fd1112  vmovaps [rsp+0xE0], xmm14
00007f46e3fd111b  sub rsp, 0x30
00007f46e3fd111f  movaps [rsp], xmm15
00007f46e3fd1124  movaps [rsp+0x10], xmm10
00007f46e3fd112a  movaps [rsp+0x20], xmm12
00007f46e3fd1130  lea rdi, [rsp]
00007f46e3fd1134  mov esi, 0x00
00007f46e3fd1139  mov rax, 0x6238B185B530
00007f46e3fd1143  call rax
00007f46e3fd1145  movaps xmm15, [rsp]
00007f46e3fd114a  add rsp, 0x30
00007f46e3fd114e  vmovaps xmm0, [rsp]
00007f46e3fd1153  vmovaps xmm1, [rsp+0x10]
00007f46e3fd1159  vmovaps xmm2, [rsp+0x20]
00007f46e3fd115f  vmovaps xmm3, [rsp+0x30]
00007f46e3fd1165  vmovaps xmm4, [rsp+0x40]
00007f46e3fd116b  vmovaps xmm5, [rsp+0x50]
00007f46e3fd1171  vmovaps xmm6, [rsp+0x60]
00007f46e3fd1177  vmovaps xmm7, [rsp+0x70]
00007f46e3fd117d  vmovaps xmm8, [rsp+0x80]
00007f46e3fd1186  vmovaps xmm9, [rsp+0x90]
00007f46e3fd118f  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd1198  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd11a1  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd11aa  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd11b3  vmovaps xmm14, [rsp+0xE0]
00007f46e3fd11bc  add rsp, 0xF0
00007f46e3fd11c3  pop r11
00007f46e3fd11c5  pop r10
00007f46e3fd11c7  pop r9
00007f46e3fd11c9  pop r8
00007f46e3fd11cb  pop rsi
00007f46e3fd11cc  pop rdi
00007f46e3fd11cd  pop rdx
00007f46e3fd11ce  pop rcx
00007f46e3fd11cf  pop rax
00007f46e3fd11d0  add rsp, 0x08
00007f46e3fd11d4  jmp 0x00007F46E3FCF75E
00007f46e3fd11d9  call 0x00007F46E3DFF430
00007f46e3fd11de  jmp 0x00007F46E3FCF7EE
00007f46e3fd11e3  call 0x00007F46E3DFF430
00007f46e3fd11e8  jmp 0x00007F46E3FCF801
00007f46e3fd11ed  sub rsp, 0x08
00007f46e3fd11f1  push rax
00007f46e3fd11f2  push rcx
00007f46e3fd11f3  push rdx
00007f46e3fd11f4  push rdi
00007f46e3fd11f5  push rsi
00007f46e3fd11f6  push r8
00007f46e3fd11f8  push r9
00007f46e3fd11fa  push r10
00007f46e3fd11fc  push r11
00007f46e3fd11fe  sub rsp, 0xF0
00007f46e3fd1205  vmovaps [rsp], xmm0
00007f46e3fd120a  vmovaps [rsp+0x10], xmm2
00007f46e3fd1210  vmovaps [rsp+0x20], xmm3
00007f46e3fd1216  vmovaps [rsp+0x30], xmm4
00007f46e3fd121c  vmovaps [rsp+0x40], xmm5
00007f46e3fd1222  vmovaps [rsp+0x50], xmm6
00007f46e3fd1228  vmovaps [rsp+0x60], xmm7
00007f46e3fd122e  vmovaps [rsp+0x70], xmm8
00007f46e3fd1234  vmovaps [rsp+0x80], xmm9
00007f46e3fd123d  vmovaps [rsp+0x90], xmm10
00007f46e3fd1246  vmovaps [rsp+0xA0], xmm11
00007f46e3fd124f  vmovaps [rsp+0xB0], xmm12
00007f46e3fd1258  vmovaps [rsp+0xC0], xmm13
00007f46e3fd1261  vmovaps [rsp+0xD0], xmm14
00007f46e3fd126a  vmovaps [rsp+0xE0], xmm15
00007f46e3fd1273  sub rsp, 0x30
00007f46e3fd1277  movaps [rsp], xmm1
00007f46e3fd127b  movaps [rsp+0x10], xmm13
00007f46e3fd1281  movaps [rsp+0x20], xmm2
00007f46e3fd1286  lea rdi, [rsp]
00007f46e3fd128a  mov esi, 0x00
00007f46e3fd128f  mov rax, 0x6238B185B530
00007f46e3fd1299  call rax
00007f46e3fd129b  movaps xmm1, [rsp]
00007f46e3fd129f  add rsp, 0x30
00007f46e3fd12a3  vmovaps xmm0, [rsp]
00007f46e3fd12a8  vmovaps xmm2, [rsp+0x10]
00007f46e3fd12ae  vmovaps xmm3, [rsp+0x20]
00007f46e3fd12b4  vmovaps xmm4, [rsp+0x30]
00007f46e3fd12ba  vmovaps xmm5, [rsp+0x40]
00007f46e3fd12c0  vmovaps xmm6, [rsp+0x50]
00007f46e3fd12c6  vmovaps xmm7, [rsp+0x60]
00007f46e3fd12cc  vmovaps xmm8, [rsp+0x70]
00007f46e3fd12d2  vmovaps xmm9, [rsp+0x80]
00007f46e3fd12db  vmovaps xmm10, [rsp+0x90]
00007f46e3fd12e4  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd12ed  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd12f6  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd12ff  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd1308  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd1311  add rsp, 0xF0
00007f46e3fd1318  pop r11
00007f46e3fd131a  pop r10
00007f46e3fd131c  pop r9
00007f46e3fd131e  pop r8
00007f46e3fd1320  pop rsi
00007f46e3fd1321  pop rdi
00007f46e3fd1322  pop rdx
00007f46e3fd1323  pop rcx
00007f46e3fd1324  pop rax
00007f46e3fd1325  add rsp, 0x08
00007f46e3fd1329  jmp 0x00007F46E3FCF82C
00007f46e3fd132e  call 0x00007F46E3E0E760
00007f46e3fd1333  jmp 0x00007F46E3FCF839
00007f46e3fd1338  sub rsp, 0x08
00007f46e3fd133c  push rax
00007f46e3fd133d  push rcx
00007f46e3fd133e  push rdx
00007f46e3fd133f  push rdi
00007f46e3fd1340  push rsi
00007f46e3fd1341  push r8
00007f46e3fd1343  push r9
00007f46e3fd1345  push r10
00007f46e3fd1347  push r11
00007f46e3fd1349  sub rsp, 0xF0
00007f46e3fd1350  vmovaps [rsp], xmm0
00007f46e3fd1355  vmovaps [rsp+0x10], xmm1
00007f46e3fd135b  vmovaps [rsp+0x20], xmm2
00007f46e3fd1361  vmovaps [rsp+0x30], xmm3
00007f46e3fd1367  vmovaps [rsp+0x40], xmm4
00007f46e3fd136d  vmovaps [rsp+0x50], xmm5
00007f46e3fd1373  vmovaps [rsp+0x60], xmm6
00007f46e3fd1379  vmovaps [rsp+0x70], xmm7
00007f46e3fd137f  vmovaps [rsp+0x80], xmm8
00007f46e3fd1388  vmovaps [rsp+0x90], xmm9
00007f46e3fd1391  vmovaps [rsp+0xA0], xmm10
00007f46e3fd139a  vmovaps [rsp+0xB0], xmm11
00007f46e3fd13a3  vmovaps [rsp+0xC0], xmm12
00007f46e3fd13ac  vmovaps [rsp+0xD0], xmm14
00007f46e3fd13b5  vmovaps [rsp+0xE0], xmm15
00007f46e3fd13be  sub rsp, 0x30
00007f46e3fd13c2  movaps [rsp], xmm13
00007f46e3fd13c7  movaps [rsp+0x10], xmm2
00007f46e3fd13cc  movaps [rsp+0x20], xmm1
00007f46e3fd13d1  lea rdi, [rsp]
00007f46e3fd13d5  mov esi, 0x00
00007f46e3fd13da  mov rax, 0x6238B185B530
00007f46e3fd13e4  call rax
00007f46e3fd13e6  movaps xmm13, [rsp]
00007f46e3fd13eb  add rsp, 0x30
00007f46e3fd13ef  vmovaps xmm0, [rsp]
00007f46e3fd13f4  vmovaps xmm1, [rsp+0x10]
00007f46e3fd13fa  vmovaps xmm2, [rsp+0x20]
00007f46e3fd1400  vmovaps xmm3, [rsp+0x30]
00007f46e3fd1406  vmovaps xmm4, [rsp+0x40]
00007f46e3fd140c  vmovaps xmm5, [rsp+0x50]
00007f46e3fd1412  vmovaps xmm6, [rsp+0x60]
00007f46e3fd1418  vmovaps xmm7, [rsp+0x70]
00007f46e3fd141e  vmovaps xmm8, [rsp+0x80]
00007f46e3fd1427  vmovaps xmm9, [rsp+0x90]
00007f46e3fd1430  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd1439  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd1442  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd144b  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd1454  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd145d  add rsp, 0xF0
00007f46e3fd1464  pop r11
00007f46e3fd1466  pop r10
00007f46e3fd1468  pop r9
00007f46e3fd146a  pop r8
00007f46e3fd146c  pop rsi
00007f46e3fd146d  pop rdi
00007f46e3fd146e  pop rdx
00007f46e3fd146f  pop rcx
00007f46e3fd1470  pop rax
00007f46e3fd1471  add rsp, 0x08
00007f46e3fd1475  jmp 0x00007F46E3FCF878
00007f46e3fd147a  sub rsp, 0x08
00007f46e3fd147e  push rax
00007f46e3fd147f  push rcx
00007f46e3fd1480  push rdx
00007f46e3fd1481  push rdi
00007f46e3fd1482  push rsi
00007f46e3fd1483  push r8
00007f46e3fd1485  push r9
00007f46e3fd1487  push r10
00007f46e3fd1489  push r11
00007f46e3fd148b  sub rsp, 0xF0
00007f46e3fd1492  vmovaps [rsp], xmm0
00007f46e3fd1497  vmovaps [rsp+0x10], xmm2
00007f46e3fd149d  vmovaps [rsp+0x20], xmm3
00007f46e3fd14a3  vmovaps [rsp+0x30], xmm4
00007f46e3fd14a9  vmovaps [rsp+0x40], xmm5
00007f46e3fd14af  vmovaps [rsp+0x50], xmm6
00007f46e3fd14b5  vmovaps [rsp+0x60], xmm7
00007f46e3fd14bb  vmovaps [rsp+0x70], xmm8
00007f46e3fd14c1  vmovaps [rsp+0x80], xmm9
00007f46e3fd14ca  vmovaps [rsp+0x90], xmm10
00007f46e3fd14d3  vmovaps [rsp+0xA0], xmm11
00007f46e3fd14dc  vmovaps [rsp+0xB0], xmm12
00007f46e3fd14e5  vmovaps [rsp+0xC0], xmm13
00007f46e3fd14ee  vmovaps [rsp+0xD0], xmm14
00007f46e3fd14f7  vmovaps [rsp+0xE0], xmm15
00007f46e3fd1500  sub rsp, 0x30
00007f46e3fd1504  movaps [rsp], xmm1
00007f46e3fd1508  movaps [rsp+0x10], xmm15
00007f46e3fd150e  movaps [rsp+0x20], xmm2
00007f46e3fd1513  lea rdi, [rsp]
00007f46e3fd1517  mov esi, 0x00
00007f46e3fd151c  mov rax, 0x6238B185B530
00007f46e3fd1526  call rax
00007f46e3fd1528  movaps xmm1, [rsp]
00007f46e3fd152c  add rsp, 0x30
00007f46e3fd1530  vmovaps xmm0, [rsp]
00007f46e3fd1535  vmovaps xmm2, [rsp+0x10]
00007f46e3fd153b  vmovaps xmm3, [rsp+0x20]
00007f46e3fd1541  vmovaps xmm4, [rsp+0x30]
00007f46e3fd1547  vmovaps xmm5, [rsp+0x40]
00007f46e3fd154d  vmovaps xmm6, [rsp+0x50]
00007f46e3fd1553  vmovaps xmm7, [rsp+0x60]
00007f46e3fd1559  vmovaps xmm8, [rsp+0x70]
00007f46e3fd155f  vmovaps xmm9, [rsp+0x80]
00007f46e3fd1568  vmovaps xmm10, [rsp+0x90]
00007f46e3fd1571  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd157a  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd1583  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd158c  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd1595  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd159e  add rsp, 0xF0
00007f46e3fd15a5  pop r11
00007f46e3fd15a7  pop r10
00007f46e3fd15a9  pop r9
00007f46e3fd15ab  pop r8
00007f46e3fd15ad  pop rsi
00007f46e3fd15ae  pop rdi
00007f46e3fd15af  pop rdx
00007f46e3fd15b0  pop rcx
00007f46e3fd15b1  pop rax
00007f46e3fd15b2  add rsp, 0x08
00007f46e3fd15b6  jmp 0x00007F46E3FCF8AC
00007f46e3fd15bb  sub rsp, 0x08
00007f46e3fd15bf  push rax
00007f46e3fd15c0  push rcx
00007f46e3fd15c1  push rdx
00007f46e3fd15c2  push rdi
00007f46e3fd15c3  push rsi
00007f46e3fd15c4  push r8
00007f46e3fd15c6  push r9
00007f46e3fd15c8  push r10
00007f46e3fd15ca  push r11
00007f46e3fd15cc  sub rsp, 0xF0
00007f46e3fd15d3  vmovaps [rsp], xmm0
00007f46e3fd15d8  vmovaps [rsp+0x10], xmm1
00007f46e3fd15de  vmovaps [rsp+0x20], xmm2
00007f46e3fd15e4  vmovaps [rsp+0x30], xmm3
00007f46e3fd15ea  vmovaps [rsp+0x40], xmm4
00007f46e3fd15f0  vmovaps [rsp+0x50], xmm5
00007f46e3fd15f6  vmovaps [rsp+0x60], xmm6
00007f46e3fd15fc  vmovaps [rsp+0x70], xmm7
00007f46e3fd1602  vmovaps [rsp+0x80], xmm8
00007f46e3fd160b  vmovaps [rsp+0x90], xmm9
00007f46e3fd1614  vmovaps [rsp+0xA0], xmm10
00007f46e3fd161d  vmovaps [rsp+0xB0], xmm11
00007f46e3fd1626  vmovaps [rsp+0xC0], xmm12
00007f46e3fd162f  vmovaps [rsp+0xD0], xmm13
00007f46e3fd1638  vmovaps [rsp+0xE0], xmm15
00007f46e3fd1641  sub rsp, 0x30
00007f46e3fd1645  movaps [rsp], xmm14
00007f46e3fd164a  movaps [rsp+0x10], xmm2
00007f46e3fd164f  movaps [rsp+0x20], xmm15
00007f46e3fd1655  lea rdi, [rsp]
00007f46e3fd1659  mov esi, 0x00
00007f46e3fd165e  mov rax, 0x6238B185B530
00007f46e3fd1668  call rax
00007f46e3fd166a  movaps xmm14, [rsp]
00007f46e3fd166f  add rsp, 0x30
00007f46e3fd1673  vmovaps xmm0, [rsp]
00007f46e3fd1678  vmovaps xmm1, [rsp+0x10]
00007f46e3fd167e  vmovaps xmm2, [rsp+0x20]
00007f46e3fd1684  vmovaps xmm3, [rsp+0x30]
00007f46e3fd168a  vmovaps xmm4, [rsp+0x40]
00007f46e3fd1690  vmovaps xmm5, [rsp+0x50]
00007f46e3fd1696  vmovaps xmm6, [rsp+0x60]
00007f46e3fd169c  vmovaps xmm7, [rsp+0x70]
00007f46e3fd16a2  vmovaps xmm8, [rsp+0x80]
00007f46e3fd16ab  vmovaps xmm9, [rsp+0x90]
00007f46e3fd16b4  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd16bd  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd16c6  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd16cf  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd16d8  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd16e1  add rsp, 0xF0
00007f46e3fd16e8  pop r11
00007f46e3fd16ea  pop r10
00007f46e3fd16ec  pop r9
00007f46e3fd16ee  pop r8
00007f46e3fd16f0  pop rsi
00007f46e3fd16f1  pop rdi
00007f46e3fd16f2  pop rdx
00007f46e3fd16f3  pop rcx
00007f46e3fd16f4  pop rax
00007f46e3fd16f5  add rsp, 0x08
00007f46e3fd16f9  jmp 0x00007F46E3FCF8E7
00007f46e3fd16fe  sub rsp, 0x08
00007f46e3fd1702  push rax
00007f46e3fd1703  push rcx
00007f46e3fd1704  push rdx
00007f46e3fd1705  push rdi
00007f46e3fd1706  push rsi
00007f46e3fd1707  push r8
00007f46e3fd1709  push r9
00007f46e3fd170b  push r10
00007f46e3fd170d  push r11
00007f46e3fd170f  sub rsp, 0xF0
00007f46e3fd1716  vmovaps [rsp], xmm0
00007f46e3fd171b  vmovaps [rsp+0x10], xmm1
00007f46e3fd1721  vmovaps [rsp+0x20], xmm2
00007f46e3fd1727  vmovaps [rsp+0x30], xmm3
00007f46e3fd172d  vmovaps [rsp+0x40], xmm4
00007f46e3fd1733  vmovaps [rsp+0x50], xmm5
00007f46e3fd1739  vmovaps [rsp+0x60], xmm6
00007f46e3fd173f  vmovaps [rsp+0x70], xmm7
00007f46e3fd1745  vmovaps [rsp+0x80], xmm8
00007f46e3fd174e  vmovaps [rsp+0x90], xmm9
00007f46e3fd1757  vmovaps [rsp+0xA0], xmm10
00007f46e3fd1760  vmovaps [rsp+0xB0], xmm11
00007f46e3fd1769  vmovaps [rsp+0xC0], xmm12
00007f46e3fd1772  vmovaps [rsp+0xD0], xmm13
00007f46e3fd177b  vmovaps [rsp+0xE0], xmm14
00007f46e3fd1784  sub rsp, 0x30
00007f46e3fd1788  movaps [rsp], xmm15
00007f46e3fd178d  movaps [rsp+0x10], xmm2
00007f46e3fd1792  movaps [rsp+0x20], xmm1
00007f46e3fd1797  lea rdi, [rsp]
00007f46e3fd179b  mov esi, 0x00
00007f46e3fd17a0  mov rax, 0x6238B185B530
00007f46e3fd17aa  call rax
00007f46e3fd17ac  movaps xmm15, [rsp]
00007f46e3fd17b1  add rsp, 0x30
00007f46e3fd17b5  vmovaps xmm0, [rsp]
00007f46e3fd17ba  vmovaps xmm1, [rsp+0x10]
00007f46e3fd17c0  vmovaps xmm2, [rsp+0x20]
00007f46e3fd17c6  vmovaps xmm3, [rsp+0x30]
00007f46e3fd17cc  vmovaps xmm4, [rsp+0x40]
00007f46e3fd17d2  vmovaps xmm5, [rsp+0x50]
00007f46e3fd17d8  vmovaps xmm6, [rsp+0x60]
00007f46e3fd17de  vmovaps xmm7, [rsp+0x70]
00007f46e3fd17e4  vmovaps xmm8, [rsp+0x80]
00007f46e3fd17ed  vmovaps xmm9, [rsp+0x90]
00007f46e3fd17f6  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd17ff  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd1808  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd1811  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd181a  vmovaps xmm14, [rsp+0xE0]
00007f46e3fd1823  add rsp, 0xF0
00007f46e3fd182a  pop r11
00007f46e3fd182c  pop r10
00007f46e3fd182e  pop r9
00007f46e3fd1830  pop r8
00007f46e3fd1832  pop rsi
00007f46e3fd1833  pop rdi
00007f46e3fd1834  pop rdx
00007f46e3fd1835  pop rcx
00007f46e3fd1836  pop rax
00007f46e3fd1837  add rsp, 0x08
00007f46e3fd183b  jmp 0x00007F46E3FCF923
00007f46e3fd1840  call 0x00007F46E3DFF430
00007f46e3fd1845  jmp 0x00007F46E3FCF930
00007f46e3fd184a  sub rsp, 0x08
00007f46e3fd184e  push rax
00007f46e3fd184f  push rcx
00007f46e3fd1850  push rdx
00007f46e3fd1851  push rdi
00007f46e3fd1852  push rsi
00007f46e3fd1853  push r8
00007f46e3fd1855  push r9
00007f46e3fd1857  push r10
00007f46e3fd1859  push r11
00007f46e3fd185b  sub rsp, 0xF0
00007f46e3fd1862  vmovaps [rsp], xmm0
00007f46e3fd1867  vmovaps [rsp+0x10], xmm1
00007f46e3fd186d  vmovaps [rsp+0x20], xmm3
00007f46e3fd1873  vmovaps [rsp+0x30], xmm4
00007f46e3fd1879  vmovaps [rsp+0x40], xmm5
00007f46e3fd187f  vmovaps [rsp+0x50], xmm6
00007f46e3fd1885  vmovaps [rsp+0x60], xmm7
00007f46e3fd188b  vmovaps [rsp+0x70], xmm8
00007f46e3fd1891  vmovaps [rsp+0x80], xmm9
00007f46e3fd189a  vmovaps [rsp+0x90], xmm10
00007f46e3fd18a3  vmovaps [rsp+0xA0], xmm11
00007f46e3fd18ac  vmovaps [rsp+0xB0], xmm12
00007f46e3fd18b5  vmovaps [rsp+0xC0], xmm13
00007f46e3fd18be  vmovaps [rsp+0xD0], xmm14
00007f46e3fd18c7  vmovaps [rsp+0xE0], xmm15
00007f46e3fd18d0  sub rsp, 0x30
00007f46e3fd18d4  movaps [rsp], xmm2
00007f46e3fd18d8  movaps [rsp+0x10], xmm1
00007f46e3fd18dd  movaps [rsp+0x20], xmm14
00007f46e3fd18e3  lea rdi, [rsp]
00007f46e3fd18e7  mov esi, 0x00
00007f46e3fd18ec  mov rax, 0x6238B185B530
00007f46e3fd18f6  call rax
00007f46e3fd18f8  movaps xmm2, [rsp]
00007f46e3fd18fc  add rsp, 0x30
00007f46e3fd1900  vmovaps xmm0, [rsp]
00007f46e3fd1905  vmovaps xmm1, [rsp+0x10]
00007f46e3fd190b  vmovaps xmm3, [rsp+0x20]
00007f46e3fd1911  vmovaps xmm4, [rsp+0x30]
00007f46e3fd1917  vmovaps xmm5, [rsp+0x40]
00007f46e3fd191d  vmovaps xmm6, [rsp+0x50]
00007f46e3fd1923  vmovaps xmm7, [rsp+0x60]
00007f46e3fd1929  vmovaps xmm8, [rsp+0x70]
00007f46e3fd192f  vmovaps xmm9, [rsp+0x80]
00007f46e3fd1938  vmovaps xmm10, [rsp+0x90]
00007f46e3fd1941  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd194a  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd1953  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd195c  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd1965  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd196e  add rsp, 0xF0
00007f46e3fd1975  pop r11
00007f46e3fd1977  pop r10
00007f46e3fd1979  pop r9
00007f46e3fd197b  pop r8
00007f46e3fd197d  pop rsi
00007f46e3fd197e  pop rdi
00007f46e3fd197f  pop rdx
00007f46e3fd1980  pop rcx
00007f46e3fd1981  pop rax
00007f46e3fd1982  add rsp, 0x08
00007f46e3fd1986  jmp 0x00007F46E3FCF96D
00007f46e3fd198b  sub rsp, 0x08
00007f46e3fd198f  push rax
00007f46e3fd1990  push rcx
00007f46e3fd1991  push rdx
00007f46e3fd1992  push rdi
00007f46e3fd1993  push rsi
00007f46e3fd1994  push r8
00007f46e3fd1996  push r9
00007f46e3fd1998  push r10
00007f46e3fd199a  push r11
00007f46e3fd199c  sub rsp, 0xF0
00007f46e3fd19a3  vmovaps [rsp], xmm0
00007f46e3fd19a8  vmovaps [rsp+0x10], xmm1
00007f46e3fd19ae  vmovaps [rsp+0x20], xmm2
00007f46e3fd19b4  vmovaps [rsp+0x30], xmm3
00007f46e3fd19ba  vmovaps [rsp+0x40], xmm4
00007f46e3fd19c0  vmovaps [rsp+0x50], xmm5
00007f46e3fd19c6  vmovaps [rsp+0x60], xmm6
00007f46e3fd19cc  vmovaps [rsp+0x70], xmm7
00007f46e3fd19d2  vmovaps [rsp+0x80], xmm8
00007f46e3fd19db  vmovaps [rsp+0x90], xmm9
00007f46e3fd19e4  vmovaps [rsp+0xA0], xmm10
00007f46e3fd19ed  vmovaps [rsp+0xB0], xmm11
00007f46e3fd19f6  vmovaps [rsp+0xC0], xmm12
00007f46e3fd19ff  vmovaps [rsp+0xD0], xmm13
00007f46e3fd1a08  vmovaps [rsp+0xE0], xmm14
00007f46e3fd1a11  sub rsp, 0x30
00007f46e3fd1a15  movaps [rsp], xmm15
00007f46e3fd1a1a  movaps [rsp+0x10], xmm14
00007f46e3fd1a20  movaps [rsp+0x20], xmm1
00007f46e3fd1a25  lea rdi, [rsp]
00007f46e3fd1a29  mov esi, 0x00
00007f46e3fd1a2e  mov rax, 0x6238B185B530
00007f46e3fd1a38  call rax
00007f46e3fd1a3a  movaps xmm15, [rsp]
00007f46e3fd1a3f  add rsp, 0x30
00007f46e3fd1a43  vmovaps xmm0, [rsp]
00007f46e3fd1a48  vmovaps xmm1, [rsp+0x10]
00007f46e3fd1a4e  vmovaps xmm2, [rsp+0x20]
00007f46e3fd1a54  vmovaps xmm3, [rsp+0x30]
00007f46e3fd1a5a  vmovaps xmm4, [rsp+0x40]
00007f46e3fd1a60  vmovaps xmm5, [rsp+0x50]
00007f46e3fd1a66  vmovaps xmm6, [rsp+0x60]
00007f46e3fd1a6c  vmovaps xmm7, [rsp+0x70]
00007f46e3fd1a72  vmovaps xmm8, [rsp+0x80]
00007f46e3fd1a7b  vmovaps xmm9, [rsp+0x90]
00007f46e3fd1a84  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd1a8d  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd1a96  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd1a9f  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd1aa8  vmovaps xmm14, [rsp+0xE0]
00007f46e3fd1ab1  add rsp, 0xF0
00007f46e3fd1ab8  pop r11
00007f46e3fd1aba  pop r10
00007f46e3fd1abc  pop r9
00007f46e3fd1abe  pop r8
00007f46e3fd1ac0  pop rsi
00007f46e3fd1ac1  pop rdi
00007f46e3fd1ac2  pop rdx
00007f46e3fd1ac3  pop rcx
00007f46e3fd1ac4  pop rax
00007f46e3fd1ac5  add rsp, 0x08
00007f46e3fd1ac9  jmp 0x00007F46E3FCF9E7
00007f46e3fd1ace  call 0x00007F46E3DFF430
00007f46e3fd1ad3  jmp 0x00007F46E3FCF9F4
00007f46e3fd1ad8  sub rsp, 0x08
00007f46e3fd1adc  push rax
00007f46e3fd1add  push rcx
00007f46e3fd1ade  push rdx
00007f46e3fd1adf  push rdi
00007f46e3fd1ae0  push rsi
00007f46e3fd1ae1  push r8
00007f46e3fd1ae3  push r9
00007f46e3fd1ae5  push r10
00007f46e3fd1ae7  push r11
00007f46e3fd1ae9  sub rsp, 0xF0
00007f46e3fd1af0  vmovaps [rsp], xmm0
00007f46e3fd1af5  vmovaps [rsp+0x10], xmm1
00007f46e3fd1afb  vmovaps [rsp+0x20], xmm2
00007f46e3fd1b01  vmovaps [rsp+0x30], xmm3
00007f46e3fd1b07  vmovaps [rsp+0x40], xmm4
00007f46e3fd1b0d  vmovaps [rsp+0x50], xmm5
00007f46e3fd1b13  vmovaps [rsp+0x60], xmm6
00007f46e3fd1b19  vmovaps [rsp+0x70], xmm7
00007f46e3fd1b1f  vmovaps [rsp+0x80], xmm8
00007f46e3fd1b28  vmovaps [rsp+0x90], xmm9
00007f46e3fd1b31  vmovaps [rsp+0xA0], xmm10
00007f46e3fd1b3a  vmovaps [rsp+0xB0], xmm11
00007f46e3fd1b43  vmovaps [rsp+0xC0], xmm12
00007f46e3fd1b4c  vmovaps [rsp+0xD0], xmm13
00007f46e3fd1b55  vmovaps [rsp+0xE0], xmm15
00007f46e3fd1b5e  sub rsp, 0x30
00007f46e3fd1b62  movaps [rsp], xmm14
00007f46e3fd1b67  movaps [rsp+0x10], xmm13
00007f46e3fd1b6d  movaps [rsp+0x20], xmm1
00007f46e3fd1b72  lea rdi, [rsp]
00007f46e3fd1b76  mov esi, 0x00
00007f46e3fd1b7b  mov rax, 0x6238B185B530
00007f46e3fd1b85  call rax
00007f46e3fd1b87  movaps xmm14, [rsp]
00007f46e3fd1b8c  add rsp, 0x30
00007f46e3fd1b90  vmovaps xmm0, [rsp]
00007f46e3fd1b95  vmovaps xmm1, [rsp+0x10]
00007f46e3fd1b9b  vmovaps xmm2, [rsp+0x20]
00007f46e3fd1ba1  vmovaps xmm3, [rsp+0x30]
00007f46e3fd1ba7  vmovaps xmm4, [rsp+0x40]
00007f46e3fd1bad  vmovaps xmm5, [rsp+0x50]
00007f46e3fd1bb3  vmovaps xmm6, [rsp+0x60]
00007f46e3fd1bb9  vmovaps xmm7, [rsp+0x70]
00007f46e3fd1bbf  vmovaps xmm8, [rsp+0x80]
00007f46e3fd1bc8  vmovaps xmm9, [rsp+0x90]
00007f46e3fd1bd1  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd1bda  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd1be3  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd1bec  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd1bf5  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd1bfe  add rsp, 0xF0
00007f46e3fd1c05  pop r11
00007f46e3fd1c07  pop r10
00007f46e3fd1c09  pop r9
00007f46e3fd1c0b  pop r8
00007f46e3fd1c0d  pop rsi
00007f46e3fd1c0e  pop rdi
00007f46e3fd1c0f  pop rdx
00007f46e3fd1c10  pop rcx
00007f46e3fd1c11  pop rax
00007f46e3fd1c12  add rsp, 0x08
00007f46e3fd1c16  jmp 0x00007F46E3FCFAAF
00007f46e3fd1c1b  sub rsp, 0x08
00007f46e3fd1c1f  push rax
00007f46e3fd1c20  push rcx
00007f46e3fd1c21  push rdx
00007f46e3fd1c22  push rdi
00007f46e3fd1c23  push rsi
00007f46e3fd1c24  push r8
00007f46e3fd1c26  push r9
00007f46e3fd1c28  push r10
00007f46e3fd1c2a  push r11
00007f46e3fd1c2c  sub rsp, 0xF0
00007f46e3fd1c33  vmovaps [rsp], xmm0
00007f46e3fd1c38  vmovaps [rsp+0x10], xmm1
00007f46e3fd1c3e  vmovaps [rsp+0x20], xmm2
00007f46e3fd1c44  vmovaps [rsp+0x30], xmm3
00007f46e3fd1c4a  vmovaps [rsp+0x40], xmm4
00007f46e3fd1c50  vmovaps [rsp+0x50], xmm5
00007f46e3fd1c56  vmovaps [rsp+0x60], xmm6
00007f46e3fd1c5c  vmovaps [rsp+0x70], xmm7
00007f46e3fd1c62  vmovaps [rsp+0x80], xmm8
00007f46e3fd1c6b  vmovaps [rsp+0x90], xmm9
00007f46e3fd1c74  vmovaps [rsp+0xA0], xmm10
00007f46e3fd1c7d  vmovaps [rsp+0xB0], xmm11
00007f46e3fd1c86  vmovaps [rsp+0xC0], xmm12
00007f46e3fd1c8f  vmovaps [rsp+0xD0], xmm13
00007f46e3fd1c98  vmovaps [rsp+0xE0], xmm14
00007f46e3fd1ca1  sub rsp, 0x30
00007f46e3fd1ca5  movaps [rsp], xmm15
00007f46e3fd1caa  movaps [rsp+0x10], xmm13
00007f46e3fd1cb0  movaps [rsp+0x20], xmm1
00007f46e3fd1cb5  lea rdi, [rsp]
00007f46e3fd1cb9  mov esi, 0x00
00007f46e3fd1cbe  mov rax, 0x6238B185B530
00007f46e3fd1cc8  call rax
00007f46e3fd1cca  movaps xmm15, [rsp]
00007f46e3fd1ccf  add rsp, 0x30
00007f46e3fd1cd3  vmovaps xmm0, [rsp]
00007f46e3fd1cd8  vmovaps xmm1, [rsp+0x10]
00007f46e3fd1cde  vmovaps xmm2, [rsp+0x20]
00007f46e3fd1ce4  vmovaps xmm3, [rsp+0x30]
00007f46e3fd1cea  vmovaps xmm4, [rsp+0x40]
00007f46e3fd1cf0  vmovaps xmm5, [rsp+0x50]
00007f46e3fd1cf6  vmovaps xmm6, [rsp+0x60]
00007f46e3fd1cfc  vmovaps xmm7, [rsp+0x70]
00007f46e3fd1d02  vmovaps xmm8, [rsp+0x80]
00007f46e3fd1d0b  vmovaps xmm9, [rsp+0x90]
00007f46e3fd1d14  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd1d1d  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd1d26  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd1d2f  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd1d38  vmovaps xmm14, [rsp+0xE0]
00007f46e3fd1d41  add rsp, 0xF0
00007f46e3fd1d48  pop r11
00007f46e3fd1d4a  pop r10
00007f46e3fd1d4c  pop r9
00007f46e3fd1d4e  pop r8
00007f46e3fd1d50  pop rsi
00007f46e3fd1d51  pop rdi
00007f46e3fd1d52  pop rdx
00007f46e3fd1d53  pop rcx
00007f46e3fd1d54  pop rax
00007f46e3fd1d55  add rsp, 0x08
00007f46e3fd1d59  jmp 0x00007F46E3FCFAEB
00007f46e3fd1d5e  call 0x00007F46E3DFF430
00007f46e3fd1d63  jmp 0x00007F46E3FCFAF8
00007f46e3fd1d68  sub rsp, 0x08
00007f46e3fd1d6c  push rax
00007f46e3fd1d6d  push rcx
00007f46e3fd1d6e  push rdx
00007f46e3fd1d6f  push rdi
00007f46e3fd1d70  push rsi
00007f46e3fd1d71  push r8
00007f46e3fd1d73  push r9
00007f46e3fd1d75  push r10
00007f46e3fd1d77  push r11
00007f46e3fd1d79  sub rsp, 0xF0
00007f46e3fd1d80  vmovaps [rsp], xmm0
00007f46e3fd1d85  vmovaps [rsp+0x10], xmm1
00007f46e3fd1d8b  vmovaps [rsp+0x20], xmm2
00007f46e3fd1d91  vmovaps [rsp+0x30], xmm3
00007f46e3fd1d97  vmovaps [rsp+0x40], xmm4
00007f46e3fd1d9d  vmovaps [rsp+0x50], xmm5
00007f46e3fd1da3  vmovaps [rsp+0x60], xmm6
00007f46e3fd1da9  vmovaps [rsp+0x70], xmm7
00007f46e3fd1daf  vmovaps [rsp+0x80], xmm8
00007f46e3fd1db8  vmovaps [rsp+0x90], xmm9
00007f46e3fd1dc1  vmovaps [rsp+0xA0], xmm10
00007f46e3fd1dca  vmovaps [rsp+0xB0], xmm11
00007f46e3fd1dd3  vmovaps [rsp+0xC0], xmm12
00007f46e3fd1ddc  vmovaps [rsp+0xD0], xmm13
00007f46e3fd1de5  vmovaps [rsp+0xE0], xmm15
00007f46e3fd1dee  sub rsp, 0x30
00007f46e3fd1df2  movaps [rsp], xmm14
00007f46e3fd1df7  movaps [rsp+0x10], xmm13
00007f46e3fd1dfd  movaps [rsp+0x20], xmm2
00007f46e3fd1e02  lea rdi, [rsp]
00007f46e3fd1e06  mov esi, 0x00
00007f46e3fd1e0b  mov rax, 0x6238B185B530
00007f46e3fd1e15  call rax
00007f46e3fd1e17  movaps xmm14, [rsp]
00007f46e3fd1e1c  add rsp, 0x30
00007f46e3fd1e20  vmovaps xmm0, [rsp]
00007f46e3fd1e25  vmovaps xmm1, [rsp+0x10]
00007f46e3fd1e2b  vmovaps xmm2, [rsp+0x20]
00007f46e3fd1e31  vmovaps xmm3, [rsp+0x30]
00007f46e3fd1e37  vmovaps xmm4, [rsp+0x40]
00007f46e3fd1e3d  vmovaps xmm5, [rsp+0x50]
00007f46e3fd1e43  vmovaps xmm6, [rsp+0x60]
00007f46e3fd1e49  vmovaps xmm7, [rsp+0x70]
00007f46e3fd1e4f  vmovaps xmm8, [rsp+0x80]
00007f46e3fd1e58  vmovaps xmm9, [rsp+0x90]
00007f46e3fd1e61  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd1e6a  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd1e73  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd1e7c  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd1e85  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd1e8e  add rsp, 0xF0
00007f46e3fd1e95  pop r11
00007f46e3fd1e97  pop r10
00007f46e3fd1e99  pop r9
00007f46e3fd1e9b  pop r8
00007f46e3fd1e9d  pop rsi
00007f46e3fd1e9e  pop rdi
00007f46e3fd1e9f  pop rdx
00007f46e3fd1ea0  pop rcx
00007f46e3fd1ea1  pop rax
00007f46e3fd1ea2  add rsp, 0x08
00007f46e3fd1ea6  jmp 0x00007F46E3FCFB24
00007f46e3fd1eab  sub rsp, 0x08
00007f46e3fd1eaf  push rax
00007f46e3fd1eb0  push rcx
00007f46e3fd1eb1  push rdx
00007f46e3fd1eb2  push rdi
00007f46e3fd1eb3  push rsi
00007f46e3fd1eb4  push r8
00007f46e3fd1eb6  push r9
00007f46e3fd1eb8  push r10
00007f46e3fd1eba  push r11
00007f46e3fd1ebc  sub rsp, 0xF0
00007f46e3fd1ec3  vmovaps [rsp], xmm0
00007f46e3fd1ec8  vmovaps [rsp+0x10], xmm2
00007f46e3fd1ece  vmovaps [rsp+0x20], xmm3
00007f46e3fd1ed4  vmovaps [rsp+0x30], xmm4
00007f46e3fd1eda  vmovaps [rsp+0x40], xmm5
00007f46e3fd1ee0  vmovaps [rsp+0x50], xmm6
00007f46e3fd1ee6  vmovaps [rsp+0x60], xmm7
00007f46e3fd1eec  vmovaps [rsp+0x70], xmm8
00007f46e3fd1ef2  vmovaps [rsp+0x80], xmm9
00007f46e3fd1efb  vmovaps [rsp+0x90], xmm10
00007f46e3fd1f04  vmovaps [rsp+0xA0], xmm11
00007f46e3fd1f0d  vmovaps [rsp+0xB0], xmm12
00007f46e3fd1f16  vmovaps [rsp+0xC0], xmm13
00007f46e3fd1f1f  vmovaps [rsp+0xD0], xmm14
00007f46e3fd1f28  vmovaps [rsp+0xE0], xmm15
00007f46e3fd1f31  sub rsp, 0x30
00007f46e3fd1f35  movaps [rsp], xmm1
00007f46e3fd1f39  movaps [rsp+0x10], xmm13
00007f46e3fd1f3f  movaps [rsp+0x20], xmm2
00007f46e3fd1f44  lea rdi, [rsp]
00007f46e3fd1f48  mov esi, 0x00
00007f46e3fd1f4d  mov rax, 0x6238B185B530
00007f46e3fd1f57  call rax
00007f46e3fd1f59  movaps xmm1, [rsp]
00007f46e3fd1f5d  add rsp, 0x30
00007f46e3fd1f61  vmovaps xmm0, [rsp]
00007f46e3fd1f66  vmovaps xmm2, [rsp+0x10]
00007f46e3fd1f6c  vmovaps xmm3, [rsp+0x20]
00007f46e3fd1f72  vmovaps xmm4, [rsp+0x30]
00007f46e3fd1f78  vmovaps xmm5, [rsp+0x40]
00007f46e3fd1f7e  vmovaps xmm6, [rsp+0x50]
00007f46e3fd1f84  vmovaps xmm7, [rsp+0x60]
00007f46e3fd1f8a  vmovaps xmm8, [rsp+0x70]
00007f46e3fd1f90  vmovaps xmm9, [rsp+0x80]
00007f46e3fd1f99  vmovaps xmm10, [rsp+0x90]
00007f46e3fd1fa2  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd1fab  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd1fb4  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd1fbd  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd1fc6  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd1fcf  add rsp, 0xF0
00007f46e3fd1fd6  pop r11
00007f46e3fd1fd8  pop r10
00007f46e3fd1fda  pop r9
00007f46e3fd1fdc  pop r8
00007f46e3fd1fde  pop rsi
00007f46e3fd1fdf  pop rdi
00007f46e3fd1fe0  pop rdx
00007f46e3fd1fe1  pop rcx
00007f46e3fd1fe2  pop rax
00007f46e3fd1fe3  add rsp, 0x08
00007f46e3fd1fe7  jmp 0x00007F46E3FCFB52
00007f46e3fd1fec  sub rsp, 0x08
00007f46e3fd1ff0  push rax
00007f46e3fd1ff1  push rcx
00007f46e3fd1ff2  push rdx
00007f46e3fd1ff3  push rdi
00007f46e3fd1ff4  push rsi
00007f46e3fd1ff5  push r8
00007f46e3fd1ff7  push r9
00007f46e3fd1ff9  push r10
00007f46e3fd1ffb  push r11
00007f46e3fd1ffd  sub rsp, 0xF0
00007f46e3fd2004  vmovaps [rsp], xmm0
00007f46e3fd2009  vmovaps [rsp+0x10], xmm1
00007f46e3fd200f  vmovaps [rsp+0x20], xmm3
00007f46e3fd2015  vmovaps [rsp+0x30], xmm4
00007f46e3fd201b  vmovaps [rsp+0x40], xmm5
00007f46e3fd2021  vmovaps [rsp+0x50], xmm6
00007f46e3fd2027  vmovaps [rsp+0x60], xmm7
00007f46e3fd202d  vmovaps [rsp+0x70], xmm8
00007f46e3fd2033  vmovaps [rsp+0x80], xmm9
00007f46e3fd203c  vmovaps [rsp+0x90], xmm10
00007f46e3fd2045  vmovaps [rsp+0xA0], xmm11
00007f46e3fd204e  vmovaps [rsp+0xB0], xmm12
00007f46e3fd2057  vmovaps [rsp+0xC0], xmm13
00007f46e3fd2060  vmovaps [rsp+0xD0], xmm14
00007f46e3fd2069  vmovaps [rsp+0xE0], xmm15
00007f46e3fd2072  sub rsp, 0x30
00007f46e3fd2076  movaps [rsp], xmm2
00007f46e3fd207a  movaps [rsp+0x10], xmm1
00007f46e3fd207f  movaps [rsp+0x20], xmm13
00007f46e3fd2085  lea rdi, [rsp]
00007f46e3fd2089  mov esi, 0x00
00007f46e3fd208e  mov rax, 0x6238B185B530
00007f46e3fd2098  call rax
00007f46e3fd209a  movaps xmm2, [rsp]
00007f46e3fd209e  add rsp, 0x30
00007f46e3fd20a2  vmovaps xmm0, [rsp]
00007f46e3fd20a7  vmovaps xmm1, [rsp+0x10]
00007f46e3fd20ad  vmovaps xmm3, [rsp+0x20]
00007f46e3fd20b3  vmovaps xmm4, [rsp+0x30]
00007f46e3fd20b9  vmovaps xmm5, [rsp+0x40]
00007f46e3fd20bf  vmovaps xmm6, [rsp+0x50]
00007f46e3fd20c5  vmovaps xmm7, [rsp+0x60]
00007f46e3fd20cb  vmovaps xmm8, [rsp+0x70]
00007f46e3fd20d1  vmovaps xmm9, [rsp+0x80]
00007f46e3fd20da  vmovaps xmm10, [rsp+0x90]
00007f46e3fd20e3  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd20ec  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd20f5  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd20fe  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd2107  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd2110  add rsp, 0xF0
00007f46e3fd2117  pop r11
00007f46e3fd2119  pop r10
00007f46e3fd211b  pop r9
00007f46e3fd211d  pop r8
00007f46e3fd211f  pop rsi
00007f46e3fd2120  pop rdi
00007f46e3fd2121  pop rdx
00007f46e3fd2122  pop rcx
00007f46e3fd2123  pop rax
00007f46e3fd2124  add rsp, 0x08
00007f46e3fd2128  jmp 0x00007F46E3FCFBAB
00007f46e3fd212d  call 0x00007F46E3DFF430
00007f46e3fd2132  jmp 0x00007F46E3FCFBB8
00007f46e3fd2137  sub rsp, 0x08
00007f46e3fd213b  push rax
00007f46e3fd213c  push rcx
00007f46e3fd213d  push rdx
00007f46e3fd213e  push rdi
00007f46e3fd213f  push rsi
00007f46e3fd2140  push r8
00007f46e3fd2142  push r9
00007f46e3fd2144  push r10
00007f46e3fd2146  push r11
00007f46e3fd2148  sub rsp, 0xF0
00007f46e3fd214f  vmovaps [rsp], xmm0
00007f46e3fd2154  vmovaps [rsp+0x10], xmm1
00007f46e3fd215a  vmovaps [rsp+0x20], xmm2
00007f46e3fd2160  vmovaps [rsp+0x30], xmm3
00007f46e3fd2166  vmovaps [rsp+0x40], xmm4
00007f46e3fd216c  vmovaps [rsp+0x50], xmm5
00007f46e3fd2172  vmovaps [rsp+0x60], xmm6
00007f46e3fd2178  vmovaps [rsp+0x70], xmm7
00007f46e3fd217e  vmovaps [rsp+0x80], xmm8
00007f46e3fd2187  vmovaps [rsp+0x90], xmm9
00007f46e3fd2190  vmovaps [rsp+0xA0], xmm10
00007f46e3fd2199  vmovaps [rsp+0xB0], xmm11
00007f46e3fd21a2  vmovaps [rsp+0xC0], xmm12
00007f46e3fd21ab  vmovaps [rsp+0xD0], xmm13
00007f46e3fd21b4  vmovaps [rsp+0xE0], xmm14
00007f46e3fd21bd  sub rsp, 0x30
00007f46e3fd21c1  movaps [rsp], xmm15
00007f46e3fd21c6  movaps [rsp+0x10], xmm13
00007f46e3fd21cc  movaps [rsp+0x20], xmm1
00007f46e3fd21d1  lea rdi, [rsp]
00007f46e3fd21d5  mov esi, 0x00
00007f46e3fd21da  mov rax, 0x6238B185B530
00007f46e3fd21e4  call rax
00007f46e3fd21e6  movaps xmm15, [rsp]
00007f46e3fd21eb  add rsp, 0x30
00007f46e3fd21ef  vmovaps xmm0, [rsp]
00007f46e3fd21f4  vmovaps xmm1, [rsp+0x10]
00007f46e3fd21fa  vmovaps xmm2, [rsp+0x20]
00007f46e3fd2200  vmovaps xmm3, [rsp+0x30]
00007f46e3fd2206  vmovaps xmm4, [rsp+0x40]
00007f46e3fd220c  vmovaps xmm5, [rsp+0x50]
00007f46e3fd2212  vmovaps xmm6, [rsp+0x60]
00007f46e3fd2218  vmovaps xmm7, [rsp+0x70]
00007f46e3fd221e  vmovaps xmm8, [rsp+0x80]
00007f46e3fd2227  vmovaps xmm9, [rsp+0x90]
00007f46e3fd2230  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd2239  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd2242  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd224b  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd2254  vmovaps xmm14, [rsp+0xE0]
00007f46e3fd225d  add rsp, 0xF0
00007f46e3fd2264  pop r11
00007f46e3fd2266  pop r10
00007f46e3fd2268  pop r9
00007f46e3fd226a  pop r8
00007f46e3fd226c  pop rsi
00007f46e3fd226d  pop rdi
00007f46e3fd226e  pop rdx
00007f46e3fd226f  pop rcx
00007f46e3fd2270  pop rax
00007f46e3fd2271  add rsp, 0x08
00007f46e3fd2275  jmp 0x00007F46E3FCFBF7
00007f46e3fd227a  sub rsp, 0x08
00007f46e3fd227e  push rax
00007f46e3fd227f  push rcx
00007f46e3fd2280  push rdx
00007f46e3fd2281  push rdi
00007f46e3fd2282  push rsi
00007f46e3fd2283  push r8
00007f46e3fd2285  push r9
00007f46e3fd2287  push r10
00007f46e3fd2289  push r11
00007f46e3fd228b  sub rsp, 0xF0
00007f46e3fd2292  vmovaps [rsp], xmm0
00007f46e3fd2297  vmovaps [rsp+0x10], xmm1
00007f46e3fd229d  vmovaps [rsp+0x20], xmm2
00007f46e3fd22a3  vmovaps [rsp+0x30], xmm3
00007f46e3fd22a9  vmovaps [rsp+0x40], xmm4
00007f46e3fd22af  vmovaps [rsp+0x50], xmm5
00007f46e3fd22b5  vmovaps [rsp+0x60], xmm6
00007f46e3fd22bb  vmovaps [rsp+0x70], xmm7
00007f46e3fd22c1  vmovaps [rsp+0x80], xmm8
00007f46e3fd22ca  vmovaps [rsp+0x90], xmm9
00007f46e3fd22d3  vmovaps [rsp+0xA0], xmm10
00007f46e3fd22dc  vmovaps [rsp+0xB0], xmm11
00007f46e3fd22e5  vmovaps [rsp+0xC0], xmm12
00007f46e3fd22ee  vmovaps [rsp+0xD0], xmm13
00007f46e3fd22f7  vmovaps [rsp+0xE0], xmm15
00007f46e3fd2300  sub rsp, 0x30
00007f46e3fd2304  movaps [rsp], xmm14
00007f46e3fd2309  movaps [rsp+0x10], xmm11
00007f46e3fd230f  movaps [rsp+0x20], xmm1
00007f46e3fd2314  lea rdi, [rsp]
00007f46e3fd2318  mov esi, 0x00
00007f46e3fd231d  mov rax, 0x6238B185B530
00007f46e3fd2327  call rax
00007f46e3fd2329  movaps xmm14, [rsp]
00007f46e3fd232e  add rsp, 0x30
00007f46e3fd2332  vmovaps xmm0, [rsp]
00007f46e3fd2337  vmovaps xmm1, [rsp+0x10]
00007f46e3fd233d  vmovaps xmm2, [rsp+0x20]
00007f46e3fd2343  vmovaps xmm3, [rsp+0x30]
00007f46e3fd2349  vmovaps xmm4, [rsp+0x40]
00007f46e3fd234f  vmovaps xmm5, [rsp+0x50]
00007f46e3fd2355  vmovaps xmm6, [rsp+0x60]
00007f46e3fd235b  vmovaps xmm7, [rsp+0x70]
00007f46e3fd2361  vmovaps xmm8, [rsp+0x80]
00007f46e3fd236a  vmovaps xmm9, [rsp+0x90]
00007f46e3fd2373  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd237c  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd2385  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd238e  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd2397  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd23a0  add rsp, 0xF0
00007f46e3fd23a7  pop r11
00007f46e3fd23a9  pop r10
00007f46e3fd23ab  pop r9
00007f46e3fd23ad  pop r8
00007f46e3fd23af  pop rsi
00007f46e3fd23b0  pop rdi
00007f46e3fd23b1  pop rdx
00007f46e3fd23b2  pop rcx
00007f46e3fd23b3  pop rax
00007f46e3fd23b4  add rsp, 0x08
00007f46e3fd23b8  jmp 0x00007F46E3FCFC21
00007f46e3fd23bd  sub rsp, 0x08
00007f46e3fd23c1  push rax
00007f46e3fd23c2  push rcx
00007f46e3fd23c3  push rdx
00007f46e3fd23c4  push rdi
00007f46e3fd23c5  push rsi
00007f46e3fd23c6  push r8
00007f46e3fd23c8  push r9
00007f46e3fd23ca  push r10
00007f46e3fd23cc  push r11
00007f46e3fd23ce  sub rsp, 0xF0
00007f46e3fd23d5  vmovaps [rsp], xmm0
00007f46e3fd23da  vmovaps [rsp+0x10], xmm1
00007f46e3fd23e0  vmovaps [rsp+0x20], xmm2
00007f46e3fd23e6  vmovaps [rsp+0x30], xmm3
00007f46e3fd23ec  vmovaps [rsp+0x40], xmm4
00007f46e3fd23f2  vmovaps [rsp+0x50], xmm5
00007f46e3fd23f8  vmovaps [rsp+0x60], xmm6
00007f46e3fd23fe  vmovaps [rsp+0x70], xmm7
00007f46e3fd2404  vmovaps [rsp+0x80], xmm8
00007f46e3fd240d  vmovaps [rsp+0x90], xmm9
00007f46e3fd2416  vmovaps [rsp+0xA0], xmm10
00007f46e3fd241f  vmovaps [rsp+0xB0], xmm11
00007f46e3fd2428  vmovaps [rsp+0xC0], xmm12
00007f46e3fd2431  vmovaps [rsp+0xD0], xmm14
00007f46e3fd243a  vmovaps [rsp+0xE0], xmm15
00007f46e3fd2443  sub rsp, 0x30
00007f46e3fd2447  movaps [rsp], xmm13
00007f46e3fd244c  movaps [rsp+0x10], xmm11
00007f46e3fd2452  movaps [rsp+0x20], xmm1
00007f46e3fd2457  lea rdi, [rsp]
00007f46e3fd245b  mov esi, 0x00
00007f46e3fd2460  mov rax, 0x6238B185B530
00007f46e3fd246a  call rax
00007f46e3fd246c  movaps xmm13, [rsp]
00007f46e3fd2471  add rsp, 0x30
00007f46e3fd2475  vmovaps xmm0, [rsp]
00007f46e3fd247a  vmovaps xmm1, [rsp+0x10]
00007f46e3fd2480  vmovaps xmm2, [rsp+0x20]
00007f46e3fd2486  vmovaps xmm3, [rsp+0x30]
00007f46e3fd248c  vmovaps xmm4, [rsp+0x40]
00007f46e3fd2492  vmovaps xmm5, [rsp+0x50]
00007f46e3fd2498  vmovaps xmm6, [rsp+0x60]
00007f46e3fd249e  vmovaps xmm7, [rsp+0x70]
00007f46e3fd24a4  vmovaps xmm8, [rsp+0x80]
00007f46e3fd24ad  vmovaps xmm9, [rsp+0x90]
00007f46e3fd24b6  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd24bf  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd24c8  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd24d1  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd24da  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd24e3  add rsp, 0xF0
00007f46e3fd24ea  pop r11
00007f46e3fd24ec  pop r10
00007f46e3fd24ee  pop r9
00007f46e3fd24f0  pop r8
00007f46e3fd24f2  pop rsi
00007f46e3fd24f3  pop rdi
00007f46e3fd24f4  pop rdx
00007f46e3fd24f5  pop rcx
00007f46e3fd24f6  pop rax
00007f46e3fd24f7  add rsp, 0x08
00007f46e3fd24fb  jmp 0x00007F46E3FCFC76
00007f46e3fd2500  call 0x00007F46E3DFF430
00007f46e3fd2505  jmp 0x00007F46E3FCFC83
00007f46e3fd250a  sub rsp, 0x08
00007f46e3fd250e  push rax
00007f46e3fd250f  push rcx
00007f46e3fd2510  push rdx
00007f46e3fd2511  push rdi
00007f46e3fd2512  push rsi
00007f46e3fd2513  push r8
00007f46e3fd2515  push r9
00007f46e3fd2517  push r10
00007f46e3fd2519  push r11
00007f46e3fd251b  sub rsp, 0xF0
00007f46e3fd2522  vmovaps [rsp], xmm0
00007f46e3fd2527  vmovaps [rsp+0x10], xmm1
00007f46e3fd252d  vmovaps [rsp+0x20], xmm2
00007f46e3fd2533  vmovaps [rsp+0x30], xmm3
00007f46e3fd2539  vmovaps [rsp+0x40], xmm4
00007f46e3fd253f  vmovaps [rsp+0x50], xmm5
00007f46e3fd2545  vmovaps [rsp+0x60], xmm6
00007f46e3fd254b  vmovaps [rsp+0x70], xmm7
00007f46e3fd2551  vmovaps [rsp+0x80], xmm8
00007f46e3fd255a  vmovaps [rsp+0x90], xmm9
00007f46e3fd2563  vmovaps [rsp+0xA0], xmm10
00007f46e3fd256c  vmovaps [rsp+0xB0], xmm11
00007f46e3fd2575  vmovaps [rsp+0xC0], xmm12
00007f46e3fd257e  vmovaps [rsp+0xD0], xmm13
00007f46e3fd2587  vmovaps [rsp+0xE0], xmm14
00007f46e3fd2590  sub rsp, 0x30
00007f46e3fd2594  movaps [rsp], xmm15
00007f46e3fd2599  movaps [rsp+0x10], xmm11
00007f46e3fd259f  movaps [rsp+0x20], xmm1
00007f46e3fd25a4  lea rdi, [rsp]
00007f46e3fd25a8  mov esi, 0x00
00007f46e3fd25ad  mov rax, 0x6238B185B530
00007f46e3fd25b7  call rax
00007f46e3fd25b9  movaps xmm15, [rsp]
00007f46e3fd25be  add rsp, 0x30
00007f46e3fd25c2  vmovaps xmm0, [rsp]
00007f46e3fd25c7  vmovaps xmm1, [rsp+0x10]
00007f46e3fd25cd  vmovaps xmm2, [rsp+0x20]
00007f46e3fd25d3  vmovaps xmm3, [rsp+0x30]
00007f46e3fd25d9  vmovaps xmm4, [rsp+0x40]
00007f46e3fd25df  vmovaps xmm5, [rsp+0x50]
00007f46e3fd25e5  vmovaps xmm6, [rsp+0x60]
00007f46e3fd25eb  vmovaps xmm7, [rsp+0x70]
00007f46e3fd25f1  vmovaps xmm8, [rsp+0x80]
00007f46e3fd25fa  vmovaps xmm9, [rsp+0x90]
00007f46e3fd2603  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd260c  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd2615  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd261e  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd2627  vmovaps xmm14, [rsp+0xE0]
00007f46e3fd2630  add rsp, 0xF0
00007f46e3fd2637  pop r11
00007f46e3fd2639  pop r10
00007f46e3fd263b  pop r9
00007f46e3fd263d  pop r8
00007f46e3fd263f  pop rsi
00007f46e3fd2640  pop rdi
00007f46e3fd2641  pop rdx
00007f46e3fd2642  pop rcx
00007f46e3fd2643  pop rax
00007f46e3fd2644  add rsp, 0x08
00007f46e3fd2648  jmp 0x00007F46E3FCFCBC
00007f46e3fd264d  sub rsp, 0x08
00007f46e3fd2651  push rax
00007f46e3fd2652  push rcx
00007f46e3fd2653  push rdx
00007f46e3fd2654  push rdi
00007f46e3fd2655  push rsi
00007f46e3fd2656  push r8
00007f46e3fd2658  push r9
00007f46e3fd265a  push r10
00007f46e3fd265c  push r11
00007f46e3fd265e  sub rsp, 0xF0
00007f46e3fd2665  vmovaps [rsp], xmm0
00007f46e3fd266a  vmovaps [rsp+0x10], xmm1
00007f46e3fd2670  vmovaps [rsp+0x20], xmm2
00007f46e3fd2676  vmovaps [rsp+0x30], xmm3
00007f46e3fd267c  vmovaps [rsp+0x40], xmm4
00007f46e3fd2682  vmovaps [rsp+0x50], xmm5
00007f46e3fd2688  vmovaps [rsp+0x60], xmm6
00007f46e3fd268e  vmovaps [rsp+0x70], xmm7
00007f46e3fd2694  vmovaps [rsp+0x80], xmm8
00007f46e3fd269d  vmovaps [rsp+0x90], xmm9
00007f46e3fd26a6  vmovaps [rsp+0xA0], xmm10
00007f46e3fd26af  vmovaps [rsp+0xB0], xmm12
00007f46e3fd26b8  vmovaps [rsp+0xC0], xmm13
00007f46e3fd26c1  vmovaps [rsp+0xD0], xmm14
00007f46e3fd26ca  vmovaps [rsp+0xE0], xmm15
00007f46e3fd26d3  sub rsp, 0x30
00007f46e3fd26d7  movaps [rsp], xmm11
00007f46e3fd26dc  movaps [rsp+0x10], xmm6
00007f46e3fd26e1  movaps [rsp+0x20], xmm14
00007f46e3fd26e7  lea rdi, [rsp]
00007f46e3fd26eb  mov esi, 0x00
00007f46e3fd26f0  mov rax, 0x6238B185B530
00007f46e3fd26fa  call rax
00007f46e3fd26fc  movaps xmm11, [rsp]
00007f46e3fd2701  add rsp, 0x30
00007f46e3fd2705  vmovaps xmm0, [rsp]
00007f46e3fd270a  vmovaps xmm1, [rsp+0x10]
00007f46e3fd2710  vmovaps xmm2, [rsp+0x20]
00007f46e3fd2716  vmovaps xmm3, [rsp+0x30]
00007f46e3fd271c  vmovaps xmm4, [rsp+0x40]
00007f46e3fd2722  vmovaps xmm5, [rsp+0x50]
00007f46e3fd2728  vmovaps xmm6, [rsp+0x60]
00007f46e3fd272e  vmovaps xmm7, [rsp+0x70]
00007f46e3fd2734  vmovaps xmm8, [rsp+0x80]
00007f46e3fd273d  vmovaps xmm9, [rsp+0x90]
00007f46e3fd2746  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd274f  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd2758  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd2761  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd276a  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd2773  add rsp, 0xF0
00007f46e3fd277a  pop r11
00007f46e3fd277c  pop r10
00007f46e3fd277e  pop r9
00007f46e3fd2780  pop r8
00007f46e3fd2782  pop rsi
00007f46e3fd2783  pop rdi
00007f46e3fd2784  pop rdx
00007f46e3fd2785  pop rcx
00007f46e3fd2786  pop rax
00007f46e3fd2787  add rsp, 0x08
00007f46e3fd278b  jmp 0x00007F46E3FCFD34
00007f46e3fd2790  call 0x00007F46E3DFF430
00007f46e3fd2795  jmp 0x00007F46E3FCFD3E
00007f46e3fd279a  sub rsp, 0x08
00007f46e3fd279e  push rax
00007f46e3fd279f  push rcx
00007f46e3fd27a0  push rdx
00007f46e3fd27a1  push rdi
00007f46e3fd27a2  push rsi
00007f46e3fd27a3  push r8
00007f46e3fd27a5  push r9
00007f46e3fd27a7  push r10
00007f46e3fd27a9  push r11
00007f46e3fd27ab  sub rsp, 0xF0
00007f46e3fd27b2  vmovaps [rsp], xmm0
00007f46e3fd27b7  vmovaps [rsp+0x10], xmm1
00007f46e3fd27bd  vmovaps [rsp+0x20], xmm2
00007f46e3fd27c3  vmovaps [rsp+0x30], xmm3
00007f46e3fd27c9  vmovaps [rsp+0x40], xmm4
00007f46e3fd27cf  vmovaps [rsp+0x50], xmm5
00007f46e3fd27d5  vmovaps [rsp+0x60], xmm6
00007f46e3fd27db  vmovaps [rsp+0x70], xmm7
00007f46e3fd27e1  vmovaps [rsp+0x80], xmm8
00007f46e3fd27ea  vmovaps [rsp+0x90], xmm9
00007f46e3fd27f3  vmovaps [rsp+0xA0], xmm10
00007f46e3fd27fc  vmovaps [rsp+0xB0], xmm11
00007f46e3fd2805  vmovaps [rsp+0xC0], xmm12
00007f46e3fd280e  vmovaps [rsp+0xD0], xmm13
00007f46e3fd2817  vmovaps [rsp+0xE0], xmm15
00007f46e3fd2820  sub rsp, 0x30
00007f46e3fd2824  movaps [rsp], xmm14
00007f46e3fd2829  movaps [rsp+0x10], xmm6
00007f46e3fd282e  movaps [rsp+0x20], xmm2
00007f46e3fd2833  lea rdi, [rsp]
00007f46e3fd2837  mov esi, 0x00
00007f46e3fd283c  mov rax, 0x6238B185B530
00007f46e3fd2846  call rax
00007f46e3fd2848  movaps xmm14, [rsp]
00007f46e3fd284d  add rsp, 0x30
00007f46e3fd2851  vmovaps xmm0, [rsp]
00007f46e3fd2856  vmovaps xmm1, [rsp+0x10]
00007f46e3fd285c  vmovaps xmm2, [rsp+0x20]
00007f46e3fd2862  vmovaps xmm3, [rsp+0x30]
00007f46e3fd2868  vmovaps xmm4, [rsp+0x40]
00007f46e3fd286e  vmovaps xmm5, [rsp+0x50]
00007f46e3fd2874  vmovaps xmm6, [rsp+0x60]
00007f46e3fd287a  vmovaps xmm7, [rsp+0x70]
00007f46e3fd2880  vmovaps xmm8, [rsp+0x80]
00007f46e3fd2889  vmovaps xmm9, [rsp+0x90]
00007f46e3fd2892  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd289b  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd28a4  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd28ad  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd28b6  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd28bf  add rsp, 0xF0
00007f46e3fd28c6  pop r11
00007f46e3fd28c8  pop r10
00007f46e3fd28ca  pop r9
00007f46e3fd28cc  pop r8
00007f46e3fd28ce  pop rsi
00007f46e3fd28cf  pop rdi
00007f46e3fd28d0  pop rdx
00007f46e3fd28d1  pop rcx
00007f46e3fd28d2  pop rax
00007f46e3fd28d3  add rsp, 0x08
00007f46e3fd28d7  jmp 0x00007F46E3FCFD72
00007f46e3fd28dc  sub rsp, 0x08
00007f46e3fd28e0  push rax
00007f46e3fd28e1  push rcx
00007f46e3fd28e2  push rdx
00007f46e3fd28e3  push rdi
00007f46e3fd28e4  push rsi
00007f46e3fd28e5  push r8
00007f46e3fd28e7  push r9
00007f46e3fd28e9  push r10
00007f46e3fd28eb  push r11
00007f46e3fd28ed  sub rsp, 0xF0
00007f46e3fd28f4  vmovaps [rsp], xmm0
00007f46e3fd28f9  vmovaps [rsp+0x10], xmm1
00007f46e3fd28ff  vmovaps [rsp+0x20], xmm2
00007f46e3fd2905  vmovaps [rsp+0x30], xmm3
00007f46e3fd290b  vmovaps [rsp+0x40], xmm4
00007f46e3fd2911  vmovaps [rsp+0x50], xmm5
00007f46e3fd2917  vmovaps [rsp+0x60], xmm7
00007f46e3fd291d  vmovaps [rsp+0x70], xmm8
00007f46e3fd2923  vmovaps [rsp+0x80], xmm9
00007f46e3fd292c  vmovaps [rsp+0x90], xmm10
00007f46e3fd2935  vmovaps [rsp+0xA0], xmm11
00007f46e3fd293e  vmovaps [rsp+0xB0], xmm12
00007f46e3fd2947  vmovaps [rsp+0xC0], xmm13
00007f46e3fd2950  vmovaps [rsp+0xD0], xmm14
00007f46e3fd2959  vmovaps [rsp+0xE0], xmm15
00007f46e3fd2962  sub rsp, 0x30
00007f46e3fd2966  movaps [rsp], xmm6
00007f46e3fd296a  movaps [rsp+0x10], xmm5
00007f46e3fd296f  movaps [rsp+0x20], xmm1
00007f46e3fd2974  lea rdi, [rsp]
00007f46e3fd2978  mov esi, 0x00
00007f46e3fd297d  mov rax, 0x6238B185B530
00007f46e3fd2987  call rax
00007f46e3fd2989  movaps xmm6, [rsp]
00007f46e3fd298d  add rsp, 0x30
00007f46e3fd2991  vmovaps xmm0, [rsp]
00007f46e3fd2996  vmovaps xmm1, [rsp+0x10]
00007f46e3fd299c  vmovaps xmm2, [rsp+0x20]
00007f46e3fd29a2  vmovaps xmm3, [rsp+0x30]
00007f46e3fd29a8  vmovaps xmm4, [rsp+0x40]
00007f46e3fd29ae  vmovaps xmm5, [rsp+0x50]
00007f46e3fd29b4  vmovaps xmm7, [rsp+0x60]
00007f46e3fd29ba  vmovaps xmm8, [rsp+0x70]
00007f46e3fd29c0  vmovaps xmm9, [rsp+0x80]
00007f46e3fd29c9  vmovaps xmm10, [rsp+0x90]
00007f46e3fd29d2  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd29db  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd29e4  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd29ed  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd29f6  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd29ff  add rsp, 0xF0
00007f46e3fd2a06  pop r11
00007f46e3fd2a08  pop r10
00007f46e3fd2a0a  pop r9
00007f46e3fd2a0c  pop r8
00007f46e3fd2a0e  pop rsi
00007f46e3fd2a0f  pop rdi
00007f46e3fd2a10  pop rdx
00007f46e3fd2a11  pop rcx
00007f46e3fd2a12  pop rax
00007f46e3fd2a13  add rsp, 0x08
00007f46e3fd2a17  jmp 0x00007F46E3FCFD98
00007f46e3fd2a1c  sub rsp, 0x08
00007f46e3fd2a20  push rax
00007f46e3fd2a21  push rcx
00007f46e3fd2a22  push rdx
00007f46e3fd2a23  push rdi
00007f46e3fd2a24  push rsi
00007f46e3fd2a25  push r8
00007f46e3fd2a27  push r9
00007f46e3fd2a29  push r10
00007f46e3fd2a2b  push r11
00007f46e3fd2a2d  sub rsp, 0xF0
00007f46e3fd2a34  vmovaps [rsp], xmm0
00007f46e3fd2a39  vmovaps [rsp+0x10], xmm2
00007f46e3fd2a3f  vmovaps [rsp+0x20], xmm3
00007f46e3fd2a45  vmovaps [rsp+0x30], xmm4
00007f46e3fd2a4b  vmovaps [rsp+0x40], xmm5
00007f46e3fd2a51  vmovaps [rsp+0x50], xmm6
00007f46e3fd2a57  vmovaps [rsp+0x60], xmm7
00007f46e3fd2a5d  vmovaps [rsp+0x70], xmm8
00007f46e3fd2a63  vmovaps [rsp+0x80], xmm9
00007f46e3fd2a6c  vmovaps [rsp+0x90], xmm10
00007f46e3fd2a75  vmovaps [rsp+0xA0], xmm11
00007f46e3fd2a7e  vmovaps [rsp+0xB0], xmm12
00007f46e3fd2a87  vmovaps [rsp+0xC0], xmm13
00007f46e3fd2a90  vmovaps [rsp+0xD0], xmm14
00007f46e3fd2a99  vmovaps [rsp+0xE0], xmm15
00007f46e3fd2aa2  sub rsp, 0x30
00007f46e3fd2aa6  movaps [rsp], xmm1
00007f46e3fd2aaa  movaps [rsp+0x10], xmm5
00007f46e3fd2aaf  movaps [rsp+0x20], xmm13
00007f46e3fd2ab5  lea rdi, [rsp]
00007f46e3fd2ab9  mov esi, 0x00
00007f46e3fd2abe  mov rax, 0x6238B185B530
00007f46e3fd2ac8  call rax
00007f46e3fd2aca  movaps xmm1, [rsp]
00007f46e3fd2ace  add rsp, 0x30
00007f46e3fd2ad2  vmovaps xmm0, [rsp]
00007f46e3fd2ad7  vmovaps xmm2, [rsp+0x10]
00007f46e3fd2add  vmovaps xmm3, [rsp+0x20]
00007f46e3fd2ae3  vmovaps xmm4, [rsp+0x30]
00007f46e3fd2ae9  vmovaps xmm5, [rsp+0x40]
00007f46e3fd2aef  vmovaps xmm6, [rsp+0x50]
00007f46e3fd2af5  vmovaps xmm7, [rsp+0x60]
00007f46e3fd2afb  vmovaps xmm8, [rsp+0x70]
00007f46e3fd2b01  vmovaps xmm9, [rsp+0x80]
00007f46e3fd2b0a  vmovaps xmm10, [rsp+0x90]
00007f46e3fd2b13  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd2b1c  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd2b25  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd2b2e  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd2b37  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd2b40  add rsp, 0xF0
00007f46e3fd2b47  pop r11
00007f46e3fd2b49  pop r10
00007f46e3fd2b4b  pop r9
00007f46e3fd2b4d  pop r8
00007f46e3fd2b4f  pop rsi
00007f46e3fd2b50  pop rdi
00007f46e3fd2b51  pop rdx
00007f46e3fd2b52  pop rcx
00007f46e3fd2b53  pop rax
00007f46e3fd2b54  add rsp, 0x08
00007f46e3fd2b58  jmp 0x00007F46E3FCFDB6
00007f46e3fd2b5d  sub rsp, 0x08
00007f46e3fd2b61  push rax
00007f46e3fd2b62  push rcx
00007f46e3fd2b63  push rdx
00007f46e3fd2b64  push rdi
00007f46e3fd2b65  push rsi
00007f46e3fd2b66  push r8
00007f46e3fd2b68  push r9
00007f46e3fd2b6a  push r10
00007f46e3fd2b6c  push r11
00007f46e3fd2b6e  sub rsp, 0xF0
00007f46e3fd2b75  vmovaps [rsp], xmm0
00007f46e3fd2b7a  vmovaps [rsp+0x10], xmm1
00007f46e3fd2b80  vmovaps [rsp+0x20], xmm2
00007f46e3fd2b86  vmovaps [rsp+0x30], xmm3
00007f46e3fd2b8c  vmovaps [rsp+0x40], xmm4
00007f46e3fd2b92  vmovaps [rsp+0x50], xmm6
00007f46e3fd2b98  vmovaps [rsp+0x60], xmm7
00007f46e3fd2b9e  vmovaps [rsp+0x70], xmm8
00007f46e3fd2ba4  vmovaps [rsp+0x80], xmm9
00007f46e3fd2bad  vmovaps [rsp+0x90], xmm10
00007f46e3fd2bb6  vmovaps [rsp+0xA0], xmm11
00007f46e3fd2bbf  vmovaps [rsp+0xB0], xmm12
00007f46e3fd2bc8  vmovaps [rsp+0xC0], xmm13
00007f46e3fd2bd1  vmovaps [rsp+0xD0], xmm14
00007f46e3fd2bda  vmovaps [rsp+0xE0], xmm15
00007f46e3fd2be3  sub rsp, 0x30
00007f46e3fd2be7  movaps [rsp], xmm5
00007f46e3fd2beb  movaps [rsp+0x10], xmm2
00007f46e3fd2bf0  movaps [rsp+0x20], xmm13
00007f46e3fd2bf6  lea rdi, [rsp]
00007f46e3fd2bfa  mov esi, 0x00
00007f46e3fd2bff  mov rax, 0x6238B185B530
00007f46e3fd2c09  call rax
00007f46e3fd2c0b  movaps xmm5, [rsp]
00007f46e3fd2c0f  add rsp, 0x30
00007f46e3fd2c13  vmovaps xmm0, [rsp]
00007f46e3fd2c18  vmovaps xmm1, [rsp+0x10]
00007f46e3fd2c1e  vmovaps xmm2, [rsp+0x20]
00007f46e3fd2c24  vmovaps xmm3, [rsp+0x30]
00007f46e3fd2c2a  vmovaps xmm4, [rsp+0x40]
00007f46e3fd2c30  vmovaps xmm6, [rsp+0x50]
00007f46e3fd2c36  vmovaps xmm7, [rsp+0x60]
00007f46e3fd2c3c  vmovaps xmm8, [rsp+0x70]
00007f46e3fd2c42  vmovaps xmm9, [rsp+0x80]
00007f46e3fd2c4b  vmovaps xmm10, [rsp+0x90]
00007f46e3fd2c54  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd2c5d  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd2c66  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd2c6f  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd2c78  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd2c81  add rsp, 0xF0
00007f46e3fd2c88  pop r11
00007f46e3fd2c8a  pop r10
00007f46e3fd2c8c  pop r9
00007f46e3fd2c8e  pop r8
00007f46e3fd2c90  pop rsi
00007f46e3fd2c91  pop rdi
00007f46e3fd2c92  pop rdx
00007f46e3fd2c93  pop rcx
00007f46e3fd2c94  pop rax
00007f46e3fd2c95  add rsp, 0x08
00007f46e3fd2c99  jmp 0x00007F46E3FCFDEC
00007f46e3fd2c9e  sub rsp, 0x08
00007f46e3fd2ca2  push rax
00007f46e3fd2ca3  push rcx
00007f46e3fd2ca4  push rdx
00007f46e3fd2ca5  push rdi
00007f46e3fd2ca6  push rsi
00007f46e3fd2ca7  push r8
00007f46e3fd2ca9  push r9
00007f46e3fd2cab  push r10
00007f46e3fd2cad  push r11
00007f46e3fd2caf  sub rsp, 0xF0
00007f46e3fd2cb6  vmovaps [rsp], xmm0
00007f46e3fd2cbb  vmovaps [rsp+0x10], xmm1
00007f46e3fd2cc1  vmovaps [rsp+0x20], xmm2
00007f46e3fd2cc7  vmovaps [rsp+0x30], xmm3
00007f46e3fd2ccd  vmovaps [rsp+0x40], xmm4
00007f46e3fd2cd3  vmovaps [rsp+0x50], xmm5
00007f46e3fd2cd9  vmovaps [rsp+0x60], xmm6
00007f46e3fd2cdf  vmovaps [rsp+0x70], xmm7
00007f46e3fd2ce5  vmovaps [rsp+0x80], xmm8
00007f46e3fd2cee  vmovaps [rsp+0x90], xmm9
00007f46e3fd2cf7  vmovaps [rsp+0xA0], xmm10
00007f46e3fd2d00  vmovaps [rsp+0xB0], xmm11
00007f46e3fd2d09  vmovaps [rsp+0xC0], xmm12
00007f46e3fd2d12  vmovaps [rsp+0xD0], xmm14
00007f46e3fd2d1b  vmovaps [rsp+0xE0], xmm15
00007f46e3fd2d24  sub rsp, 0x30
00007f46e3fd2d28  movaps [rsp], xmm13
00007f46e3fd2d2d  movaps [rsp+0x10], xmm10
00007f46e3fd2d33  movaps [rsp+0x20], xmm1
00007f46e3fd2d38  lea rdi, [rsp]
00007f46e3fd2d3c  mov esi, 0x00
00007f46e3fd2d41  mov rax, 0x6238B185B530
00007f46e3fd2d4b  call rax
00007f46e3fd2d4d  movaps xmm13, [rsp]
00007f46e3fd2d52  add rsp, 0x30
00007f46e3fd2d56  vmovaps xmm0, [rsp]
00007f46e3fd2d5b  vmovaps xmm1, [rsp+0x10]
00007f46e3fd2d61  vmovaps xmm2, [rsp+0x20]
00007f46e3fd2d67  vmovaps xmm3, [rsp+0x30]
00007f46e3fd2d6d  vmovaps xmm4, [rsp+0x40]
00007f46e3fd2d73  vmovaps xmm5, [rsp+0x50]
00007f46e3fd2d79  vmovaps xmm6, [rsp+0x60]
00007f46e3fd2d7f  vmovaps xmm7, [rsp+0x70]
00007f46e3fd2d85  vmovaps xmm8, [rsp+0x80]
00007f46e3fd2d8e  vmovaps xmm9, [rsp+0x90]
00007f46e3fd2d97  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd2da0  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd2da9  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd2db2  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd2dbb  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd2dc4  add rsp, 0xF0
00007f46e3fd2dcb  pop r11
00007f46e3fd2dcd  pop r10
00007f46e3fd2dcf  pop r9
00007f46e3fd2dd1  pop r8
00007f46e3fd2dd3  pop rsi
00007f46e3fd2dd4  pop rdi
00007f46e3fd2dd5  pop rdx
00007f46e3fd2dd6  pop rcx
00007f46e3fd2dd7  pop rax
00007f46e3fd2dd8  add rsp, 0x08
00007f46e3fd2ddc  jmp 0x00007F46E3FCFE15
00007f46e3fd2de1  sub rsp, 0x08
00007f46e3fd2de5  push rax
00007f46e3fd2de6  push rcx
00007f46e3fd2de7  push rdx
00007f46e3fd2de8  push rdi
00007f46e3fd2de9  push rsi
00007f46e3fd2dea  push r8
00007f46e3fd2dec  push r9
00007f46e3fd2dee  push r10
00007f46e3fd2df0  push r11
00007f46e3fd2df2  sub rsp, 0xF0
00007f46e3fd2df9  vmovaps [rsp], xmm0
00007f46e3fd2dfe  vmovaps [rsp+0x10], xmm2
00007f46e3fd2e04  vmovaps [rsp+0x20], xmm3
00007f46e3fd2e0a  vmovaps [rsp+0x30], xmm4
00007f46e3fd2e10  vmovaps [rsp+0x40], xmm5
00007f46e3fd2e16  vmovaps [rsp+0x50], xmm6
00007f46e3fd2e1c  vmovaps [rsp+0x60], xmm7
00007f46e3fd2e22  vmovaps [rsp+0x70], xmm8
00007f46e3fd2e28  vmovaps [rsp+0x80], xmm9
00007f46e3fd2e31  vmovaps [rsp+0x90], xmm10
00007f46e3fd2e3a  vmovaps [rsp+0xA0], xmm11
00007f46e3fd2e43  vmovaps [rsp+0xB0], xmm12
00007f46e3fd2e4c  vmovaps [rsp+0xC0], xmm13
00007f46e3fd2e55  vmovaps [rsp+0xD0], xmm14
00007f46e3fd2e5e  vmovaps [rsp+0xE0], xmm15
00007f46e3fd2e67  sub rsp, 0x30
00007f46e3fd2e6b  movaps [rsp], xmm1
00007f46e3fd2e6f  movaps [rsp+0x10], xmm15
00007f46e3fd2e75  movaps [rsp+0x20], xmm10
00007f46e3fd2e7b  lea rdi, [rsp]
00007f46e3fd2e7f  mov esi, 0x00
00007f46e3fd2e84  mov rax, 0x6238B185B530
00007f46e3fd2e8e  call rax
00007f46e3fd2e90  movaps xmm1, [rsp]
00007f46e3fd2e94  add rsp, 0x30
00007f46e3fd2e98  vmovaps xmm0, [rsp]
00007f46e3fd2e9d  vmovaps xmm2, [rsp+0x10]
00007f46e3fd2ea3  vmovaps xmm3, [rsp+0x20]
00007f46e3fd2ea9  vmovaps xmm4, [rsp+0x30]
00007f46e3fd2eaf  vmovaps xmm5, [rsp+0x40]
00007f46e3fd2eb5  vmovaps xmm6, [rsp+0x50]
00007f46e3fd2ebb  vmovaps xmm7, [rsp+0x60]
00007f46e3fd2ec1  vmovaps xmm8, [rsp+0x70]
00007f46e3fd2ec7  vmovaps xmm9, [rsp+0x80]
00007f46e3fd2ed0  vmovaps xmm10, [rsp+0x90]
00007f46e3fd2ed9  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd2ee2  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd2eeb  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd2ef4  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd2efd  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd2f06  add rsp, 0xF0
00007f46e3fd2f0d  pop r11
00007f46e3fd2f0f  pop r10
00007f46e3fd2f11  pop r9
00007f46e3fd2f13  pop r8
00007f46e3fd2f15  pop rsi
00007f46e3fd2f16  pop rdi
00007f46e3fd2f17  pop rdx
00007f46e3fd2f18  pop rcx
00007f46e3fd2f19  pop rax
00007f46e3fd2f1a  add rsp, 0x08
00007f46e3fd2f1e  jmp 0x00007F46E3FCFE34
00007f46e3fd2f23  sub rsp, 0x08
00007f46e3fd2f27  push rax
00007f46e3fd2f28  push rcx
00007f46e3fd2f29  push rdx
00007f46e3fd2f2a  push rdi
00007f46e3fd2f2b  push rsi
00007f46e3fd2f2c  push r8
00007f46e3fd2f2e  push r9
00007f46e3fd2f30  push r10
00007f46e3fd2f32  push r11
00007f46e3fd2f34  sub rsp, 0xF0
00007f46e3fd2f3b  vmovaps [rsp], xmm0
00007f46e3fd2f40  vmovaps [rsp+0x10], xmm1
00007f46e3fd2f46  vmovaps [rsp+0x20], xmm2
00007f46e3fd2f4c  vmovaps [rsp+0x30], xmm3
00007f46e3fd2f52  vmovaps [rsp+0x40], xmm4
00007f46e3fd2f58  vmovaps [rsp+0x50], xmm5
00007f46e3fd2f5e  vmovaps [rsp+0x60], xmm6
00007f46e3fd2f64  vmovaps [rsp+0x70], xmm7
00007f46e3fd2f6a  vmovaps [rsp+0x80], xmm8
00007f46e3fd2f73  vmovaps [rsp+0x90], xmm9
00007f46e3fd2f7c  vmovaps [rsp+0xA0], xmm10
00007f46e3fd2f85  vmovaps [rsp+0xB0], xmm11
00007f46e3fd2f8e  vmovaps [rsp+0xC0], xmm12
00007f46e3fd2f97  vmovaps [rsp+0xD0], xmm13
00007f46e3fd2fa0  vmovaps [rsp+0xE0], xmm14
00007f46e3fd2fa9  sub rsp, 0x30
00007f46e3fd2fad  movaps [rsp], xmm15
00007f46e3fd2fb2  movaps [rsp+0x10], xmm10
00007f46e3fd2fb8  movaps [rsp+0x20], xmm11
00007f46e3fd2fbe  lea rdi, [rsp]
00007f46e3fd2fc2  mov esi, 0x00
00007f46e3fd2fc7  mov rax, 0x6238B185B530
00007f46e3fd2fd1  call rax
00007f46e3fd2fd3  movaps xmm15, [rsp]
00007f46e3fd2fd8  add rsp, 0x30
00007f46e3fd2fdc  vmovaps xmm0, [rsp]
00007f46e3fd2fe1  vmovaps xmm1, [rsp+0x10]
00007f46e3fd2fe7  vmovaps xmm2, [rsp+0x20]
00007f46e3fd2fed  vmovaps xmm3, [rsp+0x30]
00007f46e3fd2ff3  vmovaps xmm4, [rsp+0x40]
00007f46e3fd2ff9  vmovaps xmm5, [rsp+0x50]
00007f46e3fd2fff  vmovaps xmm6, [rsp+0x60]
00007f46e3fd3005  vmovaps xmm7, [rsp+0x70]
00007f46e3fd300b  vmovaps xmm8, [rsp+0x80]
00007f46e3fd3014  vmovaps xmm9, [rsp+0x90]
00007f46e3fd301d  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd3026  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd302f  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd3038  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd3041  vmovaps xmm14, [rsp+0xE0]
00007f46e3fd304a  add rsp, 0xF0
00007f46e3fd3051  pop r11
00007f46e3fd3053  pop r10
00007f46e3fd3055  pop r9
00007f46e3fd3057  pop r8
00007f46e3fd3059  pop rsi
00007f46e3fd305a  pop rdi
00007f46e3fd305b  pop rdx
00007f46e3fd305c  pop rcx
00007f46e3fd305d  pop rax
00007f46e3fd305e  add rsp, 0x08
00007f46e3fd3062  jmp 0x00007F46E3FCFE57
00007f46e3fd3067  sub rsp, 0x08
00007f46e3fd306b  push rax
00007f46e3fd306c  push rcx
00007f46e3fd306d  push rdx
00007f46e3fd306e  push rdi
00007f46e3fd306f  push rsi
00007f46e3fd3070  push r8
00007f46e3fd3072  push r9
00007f46e3fd3074  push r10
00007f46e3fd3076  push r11
00007f46e3fd3078  sub rsp, 0xF0
00007f46e3fd307f  vmovaps [rsp], xmm0
00007f46e3fd3084  vmovaps [rsp+0x10], xmm1
00007f46e3fd308a  vmovaps [rsp+0x20], xmm2
00007f46e3fd3090  vmovaps [rsp+0x30], xmm3
00007f46e3fd3096  vmovaps [rsp+0x40], xmm4
00007f46e3fd309c  vmovaps [rsp+0x50], xmm5
00007f46e3fd30a2  vmovaps [rsp+0x60], xmm6
00007f46e3fd30a8  vmovaps [rsp+0x70], xmm7
00007f46e3fd30ae  vmovaps [rsp+0x80], xmm8
00007f46e3fd30b7  vmovaps [rsp+0x90], xmm9
00007f46e3fd30c0  vmovaps [rsp+0xA0], xmm11
00007f46e3fd30c9  vmovaps [rsp+0xB0], xmm12
00007f46e3fd30d2  vmovaps [rsp+0xC0], xmm13
00007f46e3fd30db  vmovaps [rsp+0xD0], xmm14
00007f46e3fd30e4  vmovaps [rsp+0xE0], xmm15
00007f46e3fd30ed  sub rsp, 0x30
00007f46e3fd30f1  movaps [rsp], xmm10
00007f46e3fd30f6  movaps [rsp+0x10], xmm12
00007f46e3fd30fc  movaps [rsp+0x20], xmm11
00007f46e3fd3102  lea rdi, [rsp]
00007f46e3fd3106  mov esi, 0x00
00007f46e3fd310b  mov rax, 0x6238B185B530
00007f46e3fd3115  call rax
00007f46e3fd3117  movaps xmm10, [rsp]
00007f46e3fd311c  add rsp, 0x30
00007f46e3fd3120  vmovaps xmm0, [rsp]
00007f46e3fd3125  vmovaps xmm1, [rsp+0x10]
00007f46e3fd312b  vmovaps xmm2, [rsp+0x20]
00007f46e3fd3131  vmovaps xmm3, [rsp+0x30]
00007f46e3fd3137  vmovaps xmm4, [rsp+0x40]
00007f46e3fd313d  vmovaps xmm5, [rsp+0x50]
00007f46e3fd3143  vmovaps xmm6, [rsp+0x60]
00007f46e3fd3149  vmovaps xmm7, [rsp+0x70]
00007f46e3fd314f  vmovaps xmm8, [rsp+0x80]
00007f46e3fd3158  vmovaps xmm9, [rsp+0x90]
00007f46e3fd3161  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd316a  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd3173  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd317c  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd3185  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd318e  add rsp, 0xF0
00007f46e3fd3195  pop r11
00007f46e3fd3197  pop r10
00007f46e3fd3199  pop r9
00007f46e3fd319b  pop r8
00007f46e3fd319d  pop rsi
00007f46e3fd319e  pop rdi
00007f46e3fd319f  pop rdx
00007f46e3fd31a0  pop rcx
00007f46e3fd31a1  pop rax
00007f46e3fd31a2  add rsp, 0x08
00007f46e3fd31a6  jmp 0x00007F46E3FCFE80
00007f46e3fd31ab  sub rsp, 0x08
00007f46e3fd31af  push rax
00007f46e3fd31b0  push rcx
00007f46e3fd31b1  push rdx
00007f46e3fd31b2  push rdi
00007f46e3fd31b3  push rsi
00007f46e3fd31b4  push r8
00007f46e3fd31b6  push r9
00007f46e3fd31b8  push r10
00007f46e3fd31ba  push r11
00007f46e3fd31bc  sub rsp, 0xF0
00007f46e3fd31c3  vmovaps [rsp], xmm0
00007f46e3fd31c8  vmovaps [rsp+0x10], xmm1
00007f46e3fd31ce  vmovaps [rsp+0x20], xmm2
00007f46e3fd31d4  vmovaps [rsp+0x30], xmm3
00007f46e3fd31da  vmovaps [rsp+0x40], xmm4
00007f46e3fd31e0  vmovaps [rsp+0x50], xmm5
00007f46e3fd31e6  vmovaps [rsp+0x60], xmm6
00007f46e3fd31ec  vmovaps [rsp+0x70], xmm7
00007f46e3fd31f2  vmovaps [rsp+0x80], xmm8
00007f46e3fd31fb  vmovaps [rsp+0x90], xmm9
00007f46e3fd3204  vmovaps [rsp+0xA0], xmm10
00007f46e3fd320d  vmovaps [rsp+0xB0], xmm12
00007f46e3fd3216  vmovaps [rsp+0xC0], xmm13
00007f46e3fd321f  vmovaps [rsp+0xD0], xmm14
00007f46e3fd3228  vmovaps [rsp+0xE0], xmm15
00007f46e3fd3231  sub rsp, 0x30
00007f46e3fd3235  movaps [rsp], xmm11
00007f46e3fd323a  movaps [rsp+0x10], xmm2
00007f46e3fd323f  movaps [rsp+0x20], xmm12
00007f46e3fd3245  lea rdi, [rsp]
00007f46e3fd3249  mov esi, 0x00
00007f46e3fd324e  mov rax, 0x6238B185B530
00007f46e3fd3258  call rax
00007f46e3fd325a  movaps xmm11, [rsp]
00007f46e3fd325f  add rsp, 0x30
00007f46e3fd3263  vmovaps xmm0, [rsp]
00007f46e3fd3268  vmovaps xmm1, [rsp+0x10]
00007f46e3fd326e  vmovaps xmm2, [rsp+0x20]
00007f46e3fd3274  vmovaps xmm3, [rsp+0x30]
00007f46e3fd327a  vmovaps xmm4, [rsp+0x40]
00007f46e3fd3280  vmovaps xmm5, [rsp+0x50]
00007f46e3fd3286  vmovaps xmm6, [rsp+0x60]
00007f46e3fd328c  vmovaps xmm7, [rsp+0x70]
00007f46e3fd3292  vmovaps xmm8, [rsp+0x80]
00007f46e3fd329b  vmovaps xmm9, [rsp+0x90]
00007f46e3fd32a4  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd32ad  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd32b6  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd32bf  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd32c8  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd32d1  add rsp, 0xF0
00007f46e3fd32d8  pop r11
00007f46e3fd32da  pop r10
00007f46e3fd32dc  pop r9
00007f46e3fd32de  pop r8
00007f46e3fd32e0  pop rsi
00007f46e3fd32e1  pop rdi
00007f46e3fd32e2  pop rdx
00007f46e3fd32e3  pop rcx
00007f46e3fd32e4  pop rax
00007f46e3fd32e5  add rsp, 0x08
00007f46e3fd32e9  jmp 0x00007F46E3FCFEB8
00007f46e3fd32ee  sub rsp, 0x08
00007f46e3fd32f2  push rax
00007f46e3fd32f3  push rcx
00007f46e3fd32f4  push rdx
00007f46e3fd32f5  push rdi
00007f46e3fd32f6  push rsi
00007f46e3fd32f7  push r8
00007f46e3fd32f9  push r9
00007f46e3fd32fb  push r10
00007f46e3fd32fd  push r11
00007f46e3fd32ff  sub rsp, 0xF0
00007f46e3fd3306  vmovaps [rsp], xmm0
00007f46e3fd330b  vmovaps [rsp+0x10], xmm2
00007f46e3fd3311  vmovaps [rsp+0x20], xmm3
00007f46e3fd3317  vmovaps [rsp+0x30], xmm4
00007f46e3fd331d  vmovaps [rsp+0x40], xmm5
00007f46e3fd3323  vmovaps [rsp+0x50], xmm6
00007f46e3fd3329  vmovaps [rsp+0x60], xmm7
00007f46e3fd332f  vmovaps [rsp+0x70], xmm8
00007f46e3fd3335  vmovaps [rsp+0x80], xmm9
00007f46e3fd333e  vmovaps [rsp+0x90], xmm10
00007f46e3fd3347  vmovaps [rsp+0xA0], xmm11
00007f46e3fd3350  vmovaps [rsp+0xB0], xmm12
00007f46e3fd3359  vmovaps [rsp+0xC0], xmm13
00007f46e3fd3362  vmovaps [rsp+0xD0], xmm14
00007f46e3fd336b  vmovaps [rsp+0xE0], xmm15
00007f46e3fd3374  sub rsp, 0x30
00007f46e3fd3378  movaps [rsp], xmm1
00007f46e3fd337c  movaps [rsp+0x10], xmm14
00007f46e3fd3382  movaps [rsp+0x20], xmm6
00007f46e3fd3387  lea rdi, [rsp]
00007f46e3fd338b  mov esi, 0x00
00007f46e3fd3390  mov rax, 0x6238B185B530
00007f46e3fd339a  call rax
00007f46e3fd339c  movaps xmm1, [rsp]
00007f46e3fd33a0  add rsp, 0x30
00007f46e3fd33a4  vmovaps xmm0, [rsp]
00007f46e3fd33a9  vmovaps xmm2, [rsp+0x10]
00007f46e3fd33af  vmovaps xmm3, [rsp+0x20]
00007f46e3fd33b5  vmovaps xmm4, [rsp+0x30]
00007f46e3fd33bb  vmovaps xmm5, [rsp+0x40]
00007f46e3fd33c1  vmovaps xmm6, [rsp+0x50]
00007f46e3fd33c7  vmovaps xmm7, [rsp+0x60]
00007f46e3fd33cd  vmovaps xmm8, [rsp+0x70]
00007f46e3fd33d3  vmovaps xmm9, [rsp+0x80]
00007f46e3fd33dc  vmovaps xmm10, [rsp+0x90]
00007f46e3fd33e5  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd33ee  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd33f7  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd3400  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd3409  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd3412  add rsp, 0xF0
00007f46e3fd3419  pop r11
00007f46e3fd341b  pop r10
00007f46e3fd341d  pop r9
00007f46e3fd341f  pop r8
00007f46e3fd3421  pop rsi
00007f46e3fd3422  pop rdi
00007f46e3fd3423  pop rdx
00007f46e3fd3424  pop rcx
00007f46e3fd3425  pop rax
00007f46e3fd3426  add rsp, 0x08
00007f46e3fd342a  jmp 0x00007F46E3FCFED1
00007f46e3fd342f  sub rsp, 0x08
00007f46e3fd3433  push rax
00007f46e3fd3434  push rcx
00007f46e3fd3435  push rdx
00007f46e3fd3436  push rdi
00007f46e3fd3437  push rsi
00007f46e3fd3438  push r8
00007f46e3fd343a  push r9
00007f46e3fd343c  push r10
00007f46e3fd343e  push r11
00007f46e3fd3440  sub rsp, 0xF0
00007f46e3fd3447  vmovaps [rsp], xmm0
00007f46e3fd344c  vmovaps [rsp+0x10], xmm1
00007f46e3fd3452  vmovaps [rsp+0x20], xmm2
00007f46e3fd3458  vmovaps [rsp+0x30], xmm3
00007f46e3fd345e  vmovaps [rsp+0x40], xmm4
00007f46e3fd3464  vmovaps [rsp+0x50], xmm5
00007f46e3fd346a  vmovaps [rsp+0x60], xmm6
00007f46e3fd3470  vmovaps [rsp+0x70], xmm7
00007f46e3fd3476  vmovaps [rsp+0x80], xmm8
00007f46e3fd347f  vmovaps [rsp+0x90], xmm9
00007f46e3fd3488  vmovaps [rsp+0xA0], xmm10
00007f46e3fd3491  vmovaps [rsp+0xB0], xmm11
00007f46e3fd349a  vmovaps [rsp+0xC0], xmm12
00007f46e3fd34a3  vmovaps [rsp+0xD0], xmm13
00007f46e3fd34ac  vmovaps [rsp+0xE0], xmm15
00007f46e3fd34b5  sub rsp, 0x30
00007f46e3fd34b9  movaps [rsp], xmm14
00007f46e3fd34be  movaps [rsp+0x10], xmm12
00007f46e3fd34c4  movaps [rsp+0x20], xmm5
00007f46e3fd34c9  lea rdi, [rsp]
00007f46e3fd34cd  mov esi, 0x00
00007f46e3fd34d2  mov rax, 0x6238B185B530
00007f46e3fd34dc  call rax
00007f46e3fd34de  movaps xmm14, [rsp]
00007f46e3fd34e3  add rsp, 0x30
00007f46e3fd34e7  vmovaps xmm0, [rsp]
00007f46e3fd34ec  vmovaps xmm1, [rsp+0x10]
00007f46e3fd34f2  vmovaps xmm2, [rsp+0x20]
00007f46e3fd34f8  vmovaps xmm3, [rsp+0x30]
00007f46e3fd34fe  vmovaps xmm4, [rsp+0x40]
00007f46e3fd3504  vmovaps xmm5, [rsp+0x50]
00007f46e3fd350a  vmovaps xmm6, [rsp+0x60]
00007f46e3fd3510  vmovaps xmm7, [rsp+0x70]
00007f46e3fd3516  vmovaps xmm8, [rsp+0x80]
00007f46e3fd351f  vmovaps xmm9, [rsp+0x90]
00007f46e3fd3528  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd3531  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd353a  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd3543  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd354c  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd3555  add rsp, 0xF0
00007f46e3fd355c  pop r11
00007f46e3fd355e  pop r10
00007f46e3fd3560  pop r9
00007f46e3fd3562  pop r8
00007f46e3fd3564  pop rsi
00007f46e3fd3565  pop rdi
00007f46e3fd3566  pop rdx
00007f46e3fd3567  pop rcx
00007f46e3fd3568  pop rax
00007f46e3fd3569  add rsp, 0x08
00007f46e3fd356d  jmp 0x00007F46E3FCFEF1
00007f46e3fd3572  sub rsp, 0x08
00007f46e3fd3576  push rax
00007f46e3fd3577  push rcx
00007f46e3fd3578  push rdx
00007f46e3fd3579  push rdi
00007f46e3fd357a  push rsi
00007f46e3fd357b  push r8
00007f46e3fd357d  push r9
00007f46e3fd357f  push r10
00007f46e3fd3581  push r11
00007f46e3fd3583  sub rsp, 0xF0
00007f46e3fd358a  vmovaps [rsp], xmm0
00007f46e3fd358f  vmovaps [rsp+0x10], xmm1
00007f46e3fd3595  vmovaps [rsp+0x20], xmm2
00007f46e3fd359b  vmovaps [rsp+0x30], xmm3
00007f46e3fd35a1  vmovaps [rsp+0x40], xmm4
00007f46e3fd35a7  vmovaps [rsp+0x50], xmm5
00007f46e3fd35ad  vmovaps [rsp+0x60], xmm7
00007f46e3fd35b3  vmovaps [rsp+0x70], xmm8
00007f46e3fd35b9  vmovaps [rsp+0x80], xmm9
00007f46e3fd35c2  vmovaps [rsp+0x90], xmm10
00007f46e3fd35cb  vmovaps [rsp+0xA0], xmm11
00007f46e3fd35d4  vmovaps [rsp+0xB0], xmm12
00007f46e3fd35dd  vmovaps [rsp+0xC0], xmm13
00007f46e3fd35e6  vmovaps [rsp+0xD0], xmm14
00007f46e3fd35ef  vmovaps [rsp+0xE0], xmm15
00007f46e3fd35f8  sub rsp, 0x30
00007f46e3fd35fc  movaps [rsp], xmm6
00007f46e3fd3600  movaps [rsp+0x10], xmm9
00007f46e3fd3606  movaps [rsp+0x20], xmm12
00007f46e3fd360c  lea rdi, [rsp]
00007f46e3fd3610  mov esi, 0x00
00007f46e3fd3615  mov rax, 0x6238B185B530
00007f46e3fd361f  call rax
00007f46e3fd3621  movaps xmm6, [rsp]
00007f46e3fd3625  add rsp, 0x30
00007f46e3fd3629  vmovaps xmm0, [rsp]
00007f46e3fd362e  vmovaps xmm1, [rsp+0x10]
00007f46e3fd3634  vmovaps xmm2, [rsp+0x20]
00007f46e3fd363a  vmovaps xmm3, [rsp+0x30]
00007f46e3fd3640  vmovaps xmm4, [rsp+0x40]
00007f46e3fd3646  vmovaps xmm5, [rsp+0x50]
00007f46e3fd364c  vmovaps xmm7, [rsp+0x60]
00007f46e3fd3652  vmovaps xmm8, [rsp+0x70]
00007f46e3fd3658  vmovaps xmm9, [rsp+0x80]
00007f46e3fd3661  vmovaps xmm10, [rsp+0x90]
00007f46e3fd366a  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd3673  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd367c  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd3685  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd368e  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd3697  add rsp, 0xF0
00007f46e3fd369e  pop r11
00007f46e3fd36a0  pop r10
00007f46e3fd36a2  pop r9
00007f46e3fd36a4  pop r8
00007f46e3fd36a6  pop rsi
00007f46e3fd36a7  pop rdi
00007f46e3fd36a8  pop rdx
00007f46e3fd36a9  pop rcx
00007f46e3fd36aa  pop rax
00007f46e3fd36ab  add rsp, 0x08
00007f46e3fd36af  jmp 0x00007F46E3FCFF19
00007f46e3fd36b4  sub rsp, 0x08
00007f46e3fd36b8  push rax
00007f46e3fd36b9  push rcx
00007f46e3fd36ba  push rdx
00007f46e3fd36bb  push rdi
00007f46e3fd36bc  push rsi
00007f46e3fd36bd  push r8
00007f46e3fd36bf  push r9
00007f46e3fd36c1  push r10
00007f46e3fd36c3  push r11
00007f46e3fd36c5  sub rsp, 0xF0
00007f46e3fd36cc  vmovaps [rsp], xmm0
00007f46e3fd36d1  vmovaps [rsp+0x10], xmm1
00007f46e3fd36d7  vmovaps [rsp+0x20], xmm2
00007f46e3fd36dd  vmovaps [rsp+0x30], xmm3
00007f46e3fd36e3  vmovaps [rsp+0x40], xmm4
00007f46e3fd36e9  vmovaps [rsp+0x50], xmm5
00007f46e3fd36ef  vmovaps [rsp+0x60], xmm6
00007f46e3fd36f5  vmovaps [rsp+0x70], xmm7
00007f46e3fd36fb  vmovaps [rsp+0x80], xmm8
00007f46e3fd3704  vmovaps [rsp+0x90], xmm9
00007f46e3fd370d  vmovaps [rsp+0xA0], xmm10
00007f46e3fd3716  vmovaps [rsp+0xB0], xmm11
00007f46e3fd371f  vmovaps [rsp+0xC0], xmm13
00007f46e3fd3728  vmovaps [rsp+0xD0], xmm14
00007f46e3fd3731  vmovaps [rsp+0xE0], xmm15
00007f46e3fd373a  sub rsp, 0x30
00007f46e3fd373e  movaps [rsp], xmm12
00007f46e3fd3743  movaps [rsp+0x10], xmm15
00007f46e3fd3749  movaps [rsp+0x20], xmm13
00007f46e3fd374f  lea rdi, [rsp]
00007f46e3fd3753  mov esi, 0x00
00007f46e3fd3758  mov rax, 0x6238B185B530
00007f46e3fd3762  call rax
00007f46e3fd3764  movaps xmm12, [rsp]
00007f46e3fd3769  add rsp, 0x30
00007f46e3fd376d  vmovaps xmm0, [rsp]
00007f46e3fd3772  vmovaps xmm1, [rsp+0x10]
00007f46e3fd3778  vmovaps xmm2, [rsp+0x20]
00007f46e3fd377e  vmovaps xmm3, [rsp+0x30]
00007f46e3fd3784  vmovaps xmm4, [rsp+0x40]
00007f46e3fd378a  vmovaps xmm5, [rsp+0x50]
00007f46e3fd3790  vmovaps xmm6, [rsp+0x60]
00007f46e3fd3796  vmovaps xmm7, [rsp+0x70]
00007f46e3fd379c  vmovaps xmm8, [rsp+0x80]
00007f46e3fd37a5  vmovaps xmm9, [rsp+0x90]
00007f46e3fd37ae  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd37b7  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd37c0  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd37c9  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd37d2  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd37db  add rsp, 0xF0
00007f46e3fd37e2  pop r11
00007f46e3fd37e4  pop r10
00007f46e3fd37e6  pop r9
00007f46e3fd37e8  pop r8
00007f46e3fd37ea  pop rsi
00007f46e3fd37eb  pop rdi
00007f46e3fd37ec  pop rdx
00007f46e3fd37ed  pop rcx
00007f46e3fd37ee  pop rax
00007f46e3fd37ef  add rsp, 0x08
00007f46e3fd37f3  jmp 0x00007F46E3FCFF34
00007f46e3fd37f8  sub rsp, 0x08
00007f46e3fd37fc  push rax
00007f46e3fd37fd  push rcx
00007f46e3fd37fe  push rdx
00007f46e3fd37ff  push rdi
00007f46e3fd3800  push rsi
00007f46e3fd3801  push r8
00007f46e3fd3803  push r9
00007f46e3fd3805  push r10
00007f46e3fd3807  push r11
00007f46e3fd3809  sub rsp, 0xF0
00007f46e3fd3810  vmovaps [rsp], xmm0
00007f46e3fd3815  vmovaps [rsp+0x10], xmm1
00007f46e3fd381b  vmovaps [rsp+0x20], xmm2
00007f46e3fd3821  vmovaps [rsp+0x30], xmm3
00007f46e3fd3827  vmovaps [rsp+0x40], xmm4
00007f46e3fd382d  vmovaps [rsp+0x50], xmm5
00007f46e3fd3833  vmovaps [rsp+0x60], xmm6
00007f46e3fd3839  vmovaps [rsp+0x70], xmm7
00007f46e3fd383f  vmovaps [rsp+0x80], xmm8
00007f46e3fd3848  vmovaps [rsp+0x90], xmm9
00007f46e3fd3851  vmovaps [rsp+0xA0], xmm10
00007f46e3fd385a  vmovaps [rsp+0xB0], xmm11
00007f46e3fd3863  vmovaps [rsp+0xC0], xmm12
00007f46e3fd386c  vmovaps [rsp+0xD0], xmm13
00007f46e3fd3875  vmovaps [rsp+0xE0], xmm14
00007f46e3fd387e  sub rsp, 0x30
00007f46e3fd3882  movaps [rsp], xmm15
00007f46e3fd3887  movaps [rsp+0x10], xmm13
00007f46e3fd388d  movaps [rsp+0x20], xmm10
00007f46e3fd3893  lea rdi, [rsp]
00007f46e3fd3897  mov esi, 0x00
00007f46e3fd389c  mov rax, 0x6238B185B530
00007f46e3fd38a6  call rax
00007f46e3fd38a8  movaps xmm15, [rsp]
00007f46e3fd38ad  add rsp, 0x30
00007f46e3fd38b1  vmovaps xmm0, [rsp]
00007f46e3fd38b6  vmovaps xmm1, [rsp+0x10]
00007f46e3fd38bc  vmovaps xmm2, [rsp+0x20]
00007f46e3fd38c2  vmovaps xmm3, [rsp+0x30]
00007f46e3fd38c8  vmovaps xmm4, [rsp+0x40]
00007f46e3fd38ce  vmovaps xmm5, [rsp+0x50]
00007f46e3fd38d4  vmovaps xmm6, [rsp+0x60]
00007f46e3fd38da  vmovaps xmm7, [rsp+0x70]
00007f46e3fd38e0  vmovaps xmm8, [rsp+0x80]
00007f46e3fd38e9  vmovaps xmm9, [rsp+0x90]
00007f46e3fd38f2  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd38fb  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd3904  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd390d  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd3916  vmovaps xmm14, [rsp+0xE0]
00007f46e3fd391f  add rsp, 0xF0
00007f46e3fd3926  pop r11
00007f46e3fd3928  pop r10
00007f46e3fd392a  pop r9
00007f46e3fd392c  pop r8
00007f46e3fd392e  pop rsi
00007f46e3fd392f  pop rdi
00007f46e3fd3930  pop rdx
00007f46e3fd3931  pop rcx
00007f46e3fd3932  pop rax
00007f46e3fd3933  add rsp, 0x08
00007f46e3fd3937  jmp 0x00007F46E3FCFF55
00007f46e3fd393c  call 0x00007F46E3E0C260
00007f46e3fd3941  jmp 0x00007F46E3FCFFB0
00007f46e3fd3946  sub rsp, 0x08
00007f46e3fd394a  push rax
00007f46e3fd394b  push rcx
00007f46e3fd394c  push rdx
00007f46e3fd394d  push rdi
00007f46e3fd394e  push rsi
00007f46e3fd394f  push r8
00007f46e3fd3951  push r9
00007f46e3fd3953  push r10
00007f46e3fd3955  push r11
00007f46e3fd3957  sub rsp, 0xF0
00007f46e3fd395e  vmovaps [rsp], xmm0
00007f46e3fd3963  vmovaps [rsp+0x10], xmm1
00007f46e3fd3969  vmovaps [rsp+0x20], xmm2
00007f46e3fd396f  vmovaps [rsp+0x30], xmm3
00007f46e3fd3975  vmovaps [rsp+0x40], xmm4
00007f46e3fd397b  vmovaps [rsp+0x50], xmm5
00007f46e3fd3981  vmovaps [rsp+0x60], xmm6
00007f46e3fd3987  vmovaps [rsp+0x70], xmm7
00007f46e3fd398d  vmovaps [rsp+0x80], xmm8
00007f46e3fd3996  vmovaps [rsp+0x90], xmm10
00007f46e3fd399f  vmovaps [rsp+0xA0], xmm11
00007f46e3fd39a8  vmovaps [rsp+0xB0], xmm12
00007f46e3fd39b1  vmovaps [rsp+0xC0], xmm13
00007f46e3fd39ba  vmovaps [rsp+0xD0], xmm14
00007f46e3fd39c3  vmovaps [rsp+0xE0], xmm15
00007f46e3fd39cc  sub rsp, 0x30
00007f46e3fd39d0  movaps [rsp], xmm9
00007f46e3fd39d5  movaps [rsp+0x10], xmm8
00007f46e3fd39db  movaps [rsp+0x20], xmm10
00007f46e3fd39e1  lea rdi, [rsp]
00007f46e3fd39e5  mov esi, 0x00
00007f46e3fd39ea  mov rax, 0x6238B185B530
00007f46e3fd39f4  call rax
00007f46e3fd39f6  movaps xmm9, [rsp]
00007f46e3fd39fb  add rsp, 0x30
00007f46e3fd39ff  vmovaps xmm0, [rsp]
00007f46e3fd3a04  vmovaps xmm1, [rsp+0x10]
00007f46e3fd3a0a  vmovaps xmm2, [rsp+0x20]
00007f46e3fd3a10  vmovaps xmm3, [rsp+0x30]
00007f46e3fd3a16  vmovaps xmm4, [rsp+0x40]
00007f46e3fd3a1c  vmovaps xmm5, [rsp+0x50]
00007f46e3fd3a22  vmovaps xmm6, [rsp+0x60]
00007f46e3fd3a28  vmovaps xmm7, [rsp+0x70]
00007f46e3fd3a2e  vmovaps xmm8, [rsp+0x80]
00007f46e3fd3a37  vmovaps xmm10, [rsp+0x90]
00007f46e3fd3a40  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd3a49  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd3a52  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd3a5b  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd3a64  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd3a6d  add rsp, 0xF0
00007f46e3fd3a74  pop r11
00007f46e3fd3a76  pop r10
00007f46e3fd3a78  pop r9
00007f46e3fd3a7a  pop r8
00007f46e3fd3a7c  pop rsi
00007f46e3fd3a7d  pop rdi
00007f46e3fd3a7e  pop rdx
00007f46e3fd3a7f  pop rcx
00007f46e3fd3a80  pop rax
00007f46e3fd3a81  add rsp, 0x08
00007f46e3fd3a85  jmp 0x00007F46E3FCFFE1
00007f46e3fd3a8a  sub rsp, 0x08
00007f46e3fd3a8e  push rax
00007f46e3fd3a8f  push rcx
00007f46e3fd3a90  push rdx
00007f46e3fd3a91  push rdi
00007f46e3fd3a92  push rsi
00007f46e3fd3a93  push r8
00007f46e3fd3a95  push r9
00007f46e3fd3a97  push r10
00007f46e3fd3a99  push r11
00007f46e3fd3a9b  sub rsp, 0xF0
00007f46e3fd3aa2  vmovaps [rsp], xmm0
00007f46e3fd3aa7  vmovaps [rsp+0x10], xmm1
00007f46e3fd3aad  vmovaps [rsp+0x20], xmm2
00007f46e3fd3ab3  vmovaps [rsp+0x30], xmm3
00007f46e3fd3ab9  vmovaps [rsp+0x40], xmm4
00007f46e3fd3abf  vmovaps [rsp+0x50], xmm5
00007f46e3fd3ac5  vmovaps [rsp+0x60], xmm6
00007f46e3fd3acb  vmovaps [rsp+0x70], xmm7
00007f46e3fd3ad1  vmovaps [rsp+0x80], xmm8
00007f46e3fd3ada  vmovaps [rsp+0x90], xmm9
00007f46e3fd3ae3  vmovaps [rsp+0xA0], xmm11
00007f46e3fd3aec  vmovaps [rsp+0xB0], xmm12
00007f46e3fd3af5  vmovaps [rsp+0xC0], xmm13
00007f46e3fd3afe  vmovaps [rsp+0xD0], xmm14
00007f46e3fd3b07  vmovaps [rsp+0xE0], xmm15
00007f46e3fd3b10  sub rsp, 0x30
00007f46e3fd3b14  movaps [rsp], xmm10
00007f46e3fd3b19  movaps [rsp+0x10], xmm1
00007f46e3fd3b1e  movaps [rsp+0x20], xmm11
00007f46e3fd3b24  lea rdi, [rsp]
00007f46e3fd3b28  mov esi, 0x00
00007f46e3fd3b2d  mov rax, 0x6238B185B530
00007f46e3fd3b37  call rax
00007f46e3fd3b39  movaps xmm10, [rsp]
00007f46e3fd3b3e  add rsp, 0x30
00007f46e3fd3b42  vmovaps xmm0, [rsp]
00007f46e3fd3b47  vmovaps xmm1, [rsp+0x10]
00007f46e3fd3b4d  vmovaps xmm2, [rsp+0x20]
00007f46e3fd3b53  vmovaps xmm3, [rsp+0x30]
00007f46e3fd3b59  vmovaps xmm4, [rsp+0x40]
00007f46e3fd3b5f  vmovaps xmm5, [rsp+0x50]
00007f46e3fd3b65  vmovaps xmm6, [rsp+0x60]
00007f46e3fd3b6b  vmovaps xmm7, [rsp+0x70]
00007f46e3fd3b71  vmovaps xmm8, [rsp+0x80]
00007f46e3fd3b7a  vmovaps xmm9, [rsp+0x90]
00007f46e3fd3b83  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd3b8c  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd3b95  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd3b9e  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd3ba7  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd3bb0  add rsp, 0xF0
00007f46e3fd3bb7  pop r11
00007f46e3fd3bb9  pop r10
00007f46e3fd3bbb  pop r9
00007f46e3fd3bbd  pop r8
00007f46e3fd3bbf  pop rsi
00007f46e3fd3bc0  pop rdi
00007f46e3fd3bc1  pop rdx
00007f46e3fd3bc2  pop rcx
00007f46e3fd3bc3  pop rax
00007f46e3fd3bc4  add rsp, 0x08
00007f46e3fd3bc8  jmp 0x00007F46E3FCFFFC
00007f46e3fd3bcd  sub rsp, 0x08
00007f46e3fd3bd1  push rax
00007f46e3fd3bd2  push rcx
00007f46e3fd3bd3  push rdx
00007f46e3fd3bd4  push rdi
00007f46e3fd3bd5  push rsi
00007f46e3fd3bd6  push r8
00007f46e3fd3bd8  push r9
00007f46e3fd3bda  push r10
00007f46e3fd3bdc  push r11
00007f46e3fd3bde  sub rsp, 0xF0
00007f46e3fd3be5  vmovaps [rsp], xmm0
00007f46e3fd3bea  vmovaps [rsp+0x10], xmm2
00007f46e3fd3bf0  vmovaps [rsp+0x20], xmm3
00007f46e3fd3bf6  vmovaps [rsp+0x30], xmm4
00007f46e3fd3bfc  vmovaps [rsp+0x40], xmm5
00007f46e3fd3c02  vmovaps [rsp+0x50], xmm6
00007f46e3fd3c08  vmovaps [rsp+0x60], xmm7
00007f46e3fd3c0e  vmovaps [rsp+0x70], xmm8
00007f46e3fd3c14  vmovaps [rsp+0x80], xmm9
00007f46e3fd3c1d  vmovaps [rsp+0x90], xmm10
00007f46e3fd3c26  vmovaps [rsp+0xA0], xmm11
00007f46e3fd3c2f  vmovaps [rsp+0xB0], xmm12
00007f46e3fd3c38  vmovaps [rsp+0xC0], xmm13
00007f46e3fd3c41  vmovaps [rsp+0xD0], xmm14
00007f46e3fd3c4a  vmovaps [rsp+0xE0], xmm15
00007f46e3fd3c53  sub rsp, 0x30
00007f46e3fd3c57  movaps [rsp], xmm1
00007f46e3fd3c5b  movaps [rsp+0x10], xmm14
00007f46e3fd3c61  movaps [rsp+0x20], xmm6
00007f46e3fd3c66  lea rdi, [rsp]
00007f46e3fd3c6a  mov esi, 0x00
00007f46e3fd3c6f  mov rax, 0x6238B185B530
00007f46e3fd3c79  call rax
00007f46e3fd3c7b  movaps xmm1, [rsp]
00007f46e3fd3c7f  add rsp, 0x30
00007f46e3fd3c83  vmovaps xmm0, [rsp]
00007f46e3fd3c88  vmovaps xmm2, [rsp+0x10]
00007f46e3fd3c8e  vmovaps xmm3, [rsp+0x20]
00007f46e3fd3c94  vmovaps xmm4, [rsp+0x30]
00007f46e3fd3c9a  vmovaps xmm5, [rsp+0x40]
00007f46e3fd3ca0  vmovaps xmm6, [rsp+0x50]
00007f46e3fd3ca6  vmovaps xmm7, [rsp+0x60]
00007f46e3fd3cac  vmovaps xmm8, [rsp+0x70]
00007f46e3fd3cb2  vmovaps xmm9, [rsp+0x80]
00007f46e3fd3cbb  vmovaps xmm10, [rsp+0x90]
00007f46e3fd3cc4  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd3ccd  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd3cd6  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd3cdf  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd3ce8  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd3cf1  add rsp, 0xF0
00007f46e3fd3cf8  pop r11
00007f46e3fd3cfa  pop r10
00007f46e3fd3cfc  pop r9
00007f46e3fd3cfe  pop r8
00007f46e3fd3d00  pop rsi
00007f46e3fd3d01  pop rdi
00007f46e3fd3d02  pop rdx
00007f46e3fd3d03  pop rcx
00007f46e3fd3d04  pop rax
00007f46e3fd3d05  add rsp, 0x08
00007f46e3fd3d09  jmp 0x00007F46E3FD0015
00007f46e3fd3d0e  sub rsp, 0x08
00007f46e3fd3d12  push rax
00007f46e3fd3d13  push rcx
00007f46e3fd3d14  push rdx
00007f46e3fd3d15  push rdi
00007f46e3fd3d16  push rsi
00007f46e3fd3d17  push r8
00007f46e3fd3d19  push r9
00007f46e3fd3d1b  push r10
00007f46e3fd3d1d  push r11
00007f46e3fd3d1f  sub rsp, 0xF0
00007f46e3fd3d26  vmovaps [rsp], xmm0
00007f46e3fd3d2b  vmovaps [rsp+0x10], xmm1
00007f46e3fd3d31  vmovaps [rsp+0x20], xmm2
00007f46e3fd3d37  vmovaps [rsp+0x30], xmm3
00007f46e3fd3d3d  vmovaps [rsp+0x40], xmm4
00007f46e3fd3d43  vmovaps [rsp+0x50], xmm5
00007f46e3fd3d49  vmovaps [rsp+0x60], xmm6
00007f46e3fd3d4f  vmovaps [rsp+0x70], xmm7
00007f46e3fd3d55  vmovaps [rsp+0x80], xmm8
00007f46e3fd3d5e  vmovaps [rsp+0x90], xmm9
00007f46e3fd3d67  vmovaps [rsp+0xA0], xmm10
00007f46e3fd3d70  vmovaps [rsp+0xB0], xmm12
00007f46e3fd3d79  vmovaps [rsp+0xC0], xmm13
00007f46e3fd3d82  vmovaps [rsp+0xD0], xmm14
00007f46e3fd3d8b  vmovaps [rsp+0xE0], xmm15
00007f46e3fd3d94  sub rsp, 0x30
00007f46e3fd3d98  movaps [rsp], xmm11
00007f46e3fd3d9d  movaps [rsp+0x10], xmm13
00007f46e3fd3da3  movaps [rsp+0x20], xmm14
00007f46e3fd3da9  lea rdi, [rsp]
00007f46e3fd3dad  mov esi, 0x00
00007f46e3fd3db2  mov rax, 0x6238B185B530
00007f46e3fd3dbc  call rax
00007f46e3fd3dbe  movaps xmm11, [rsp]
00007f46e3fd3dc3  add rsp, 0x30
00007f46e3fd3dc7  vmovaps xmm0, [rsp]
00007f46e3fd3dcc  vmovaps xmm1, [rsp+0x10]
00007f46e3fd3dd2  vmovaps xmm2, [rsp+0x20]
00007f46e3fd3dd8  vmovaps xmm3, [rsp+0x30]
00007f46e3fd3dde  vmovaps xmm4, [rsp+0x40]
00007f46e3fd3de4  vmovaps xmm5, [rsp+0x50]
00007f46e3fd3dea  vmovaps xmm6, [rsp+0x60]
00007f46e3fd3df0  vmovaps xmm7, [rsp+0x70]
00007f46e3fd3df6  vmovaps xmm8, [rsp+0x80]
00007f46e3fd3dff  vmovaps xmm9, [rsp+0x90]
00007f46e3fd3e08  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd3e11  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd3e1a  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd3e23  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd3e2c  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd3e35  add rsp, 0xF0
00007f46e3fd3e3c  pop r11
00007f46e3fd3e3e  pop r10
00007f46e3fd3e40  pop r9
00007f46e3fd3e42  pop r8
00007f46e3fd3e44  pop rsi
00007f46e3fd3e45  pop rdi
00007f46e3fd3e46  pop rdx
00007f46e3fd3e47  pop rcx
00007f46e3fd3e48  pop rax
00007f46e3fd3e49  add rsp, 0x08
00007f46e3fd3e4d  jmp 0x00007F46E3FD003F
00007f46e3fd3e52  sub rsp, 0x08
00007f46e3fd3e56  push rax
00007f46e3fd3e57  push rcx
00007f46e3fd3e58  push rdx
00007f46e3fd3e59  push rdi
00007f46e3fd3e5a  push rsi
00007f46e3fd3e5b  push r8
00007f46e3fd3e5d  push r9
00007f46e3fd3e5f  push r10
00007f46e3fd3e61  push r11
00007f46e3fd3e63  sub rsp, 0xF0
00007f46e3fd3e6a  vmovaps [rsp], xmm0
00007f46e3fd3e6f  vmovaps [rsp+0x10], xmm1
00007f46e3fd3e75  vmovaps [rsp+0x20], xmm2
00007f46e3fd3e7b  vmovaps [rsp+0x30], xmm3
00007f46e3fd3e81  vmovaps [rsp+0x40], xmm4
00007f46e3fd3e87  vmovaps [rsp+0x50], xmm5
00007f46e3fd3e8d  vmovaps [rsp+0x60], xmm6
00007f46e3fd3e93  vmovaps [rsp+0x70], xmm7
00007f46e3fd3e99  vmovaps [rsp+0x80], xmm8
00007f46e3fd3ea2  vmovaps [rsp+0x90], xmm9
00007f46e3fd3eab  vmovaps [rsp+0xA0], xmm10
00007f46e3fd3eb4  vmovaps [rsp+0xB0], xmm11
00007f46e3fd3ebd  vmovaps [rsp+0xC0], xmm12
00007f46e3fd3ec6  vmovaps [rsp+0xD0], xmm14
00007f46e3fd3ecf  vmovaps [rsp+0xE0], xmm15
00007f46e3fd3ed8  sub rsp, 0x30
00007f46e3fd3edc  movaps [rsp], xmm13
00007f46e3fd3ee1  movaps [rsp+0x10], xmm8
00007f46e3fd3ee7  movaps [rsp+0x20], xmm14
00007f46e3fd3eed  lea rdi, [rsp]
00007f46e3fd3ef1  mov esi, 0x00
00007f46e3fd3ef6  mov rax, 0x6238B185B530
00007f46e3fd3f00  call rax
00007f46e3fd3f02  movaps xmm13, [rsp]
00007f46e3fd3f07  add rsp, 0x30
00007f46e3fd3f0b  vmovaps xmm0, [rsp]
00007f46e3fd3f10  vmovaps xmm1, [rsp+0x10]
00007f46e3fd3f16  vmovaps xmm2, [rsp+0x20]
00007f46e3fd3f1c  vmovaps xmm3, [rsp+0x30]
00007f46e3fd3f22  vmovaps xmm4, [rsp+0x40]
00007f46e3fd3f28  vmovaps xmm5, [rsp+0x50]
00007f46e3fd3f2e  vmovaps xmm6, [rsp+0x60]
00007f46e3fd3f34  vmovaps xmm7, [rsp+0x70]
00007f46e3fd3f3a  vmovaps xmm8, [rsp+0x80]
00007f46e3fd3f43  vmovaps xmm9, [rsp+0x90]
00007f46e3fd3f4c  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd3f55  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd3f5e  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd3f67  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd3f70  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd3f79  add rsp, 0xF0
00007f46e3fd3f80  pop r11
00007f46e3fd3f82  pop r10
00007f46e3fd3f84  pop r9
00007f46e3fd3f86  pop r8
00007f46e3fd3f88  pop rsi
00007f46e3fd3f89  pop rdi
00007f46e3fd3f8a  pop rdx
00007f46e3fd3f8b  pop rcx
00007f46e3fd3f8c  pop rax
00007f46e3fd3f8d  add rsp, 0x08
00007f46e3fd3f91  jmp 0x00007F46E3FD006E
00007f46e3fd3f96  sub rsp, 0x08
00007f46e3fd3f9a  push rax
00007f46e3fd3f9b  push rcx
00007f46e3fd3f9c  push rdx
00007f46e3fd3f9d  push rdi
00007f46e3fd3f9e  push rsi
00007f46e3fd3f9f  push r8
00007f46e3fd3fa1  push r9
00007f46e3fd3fa3  push r10
00007f46e3fd3fa5  push r11
00007f46e3fd3fa7  sub rsp, 0xF0
00007f46e3fd3fae  vmovaps [rsp], xmm0
00007f46e3fd3fb3  vmovaps [rsp+0x10], xmm1
00007f46e3fd3fb9  vmovaps [rsp+0x20], xmm2
00007f46e3fd3fbf  vmovaps [rsp+0x30], xmm3
00007f46e3fd3fc5  vmovaps [rsp+0x40], xmm4
00007f46e3fd3fcb  vmovaps [rsp+0x50], xmm5
00007f46e3fd3fd1  vmovaps [rsp+0x60], xmm6
00007f46e3fd3fd7  vmovaps [rsp+0x70], xmm7
00007f46e3fd3fdd  vmovaps [rsp+0x80], xmm9
00007f46e3fd3fe6  vmovaps [rsp+0x90], xmm10
00007f46e3fd3fef  vmovaps [rsp+0xA0], xmm11
00007f46e3fd3ff8  vmovaps [rsp+0xB0], xmm12
00007f46e3fd4001  vmovaps [rsp+0xC0], xmm13
00007f46e3fd400a  vmovaps [rsp+0xD0], xmm14
00007f46e3fd4013  vmovaps [rsp+0xE0], xmm15
00007f46e3fd401c  sub rsp, 0x30
00007f46e3fd4020  movaps [rsp], xmm8
00007f46e3fd4025  movaps [rsp+0x10], xmm7
00007f46e3fd402a  movaps [rsp+0x20], xmm14
00007f46e3fd4030  lea rdi, [rsp]
00007f46e3fd4034  mov esi, 0x00
00007f46e3fd4039  mov rax, 0x6238B185B530
00007f46e3fd4043  call rax
00007f46e3fd4045  movaps xmm8, [rsp]
00007f46e3fd404a  add rsp, 0x30
00007f46e3fd404e  vmovaps xmm0, [rsp]
00007f46e3fd4053  vmovaps xmm1, [rsp+0x10]
00007f46e3fd4059  vmovaps xmm2, [rsp+0x20]
00007f46e3fd405f  vmovaps xmm3, [rsp+0x30]
00007f46e3fd4065  vmovaps xmm4, [rsp+0x40]
00007f46e3fd406b  vmovaps xmm5, [rsp+0x50]
00007f46e3fd4071  vmovaps xmm6, [rsp+0x60]
00007f46e3fd4077  vmovaps xmm7, [rsp+0x70]
00007f46e3fd407d  vmovaps xmm9, [rsp+0x80]
00007f46e3fd4086  vmovaps xmm10, [rsp+0x90]
00007f46e3fd408f  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd4098  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd40a1  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd40aa  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd40b3  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd40bc  add rsp, 0xF0
00007f46e3fd40c3  pop r11
00007f46e3fd40c5  pop r10
00007f46e3fd40c7  pop r9
00007f46e3fd40c9  pop r8
00007f46e3fd40cb  pop rsi
00007f46e3fd40cc  pop rdi
00007f46e3fd40cd  pop rdx
00007f46e3fd40ce  pop rcx
00007f46e3fd40cf  pop rax
00007f46e3fd40d0  add rsp, 0x08
00007f46e3fd40d4  jmp 0x00007F46E3FD0094
00007f46e3fd40d9  sub rsp, 0x08
00007f46e3fd40dd  push rax
00007f46e3fd40de  push rcx
00007f46e3fd40df  push rdx
00007f46e3fd40e0  push rdi
00007f46e3fd40e1  push rsi
00007f46e3fd40e2  push r8
00007f46e3fd40e4  push r9
00007f46e3fd40e6  push r10
00007f46e3fd40e8  push r11
00007f46e3fd40ea  sub rsp, 0xF0
00007f46e3fd40f1  vmovaps [rsp], xmm0
00007f46e3fd40f6  vmovaps [rsp+0x10], xmm1
00007f46e3fd40fc  vmovaps [rsp+0x20], xmm2
00007f46e3fd4102  vmovaps [rsp+0x30], xmm3
00007f46e3fd4108  vmovaps [rsp+0x40], xmm4
00007f46e3fd410e  vmovaps [rsp+0x50], xmm5
00007f46e3fd4114  vmovaps [rsp+0x60], xmm6
00007f46e3fd411a  vmovaps [rsp+0x70], xmm7
00007f46e3fd4120  vmovaps [rsp+0x80], xmm8
00007f46e3fd4129  vmovaps [rsp+0x90], xmm9
00007f46e3fd4132  vmovaps [rsp+0xA0], xmm10
00007f46e3fd413b  vmovaps [rsp+0xB0], xmm11
00007f46e3fd4144  vmovaps [rsp+0xC0], xmm12
00007f46e3fd414d  vmovaps [rsp+0xD0], xmm13
00007f46e3fd4156  vmovaps [rsp+0xE0], xmm15
00007f46e3fd415f  sub rsp, 0x30
00007f46e3fd4163  movaps [rsp], xmm14
00007f46e3fd4168  movaps [rsp+0x10], xmm12
00007f46e3fd416e  movaps [rsp+0x20], xmm9
00007f46e3fd4174  lea rdi, [rsp]
00007f46e3fd4178  mov esi, 0x00
00007f46e3fd417d  mov rax, 0x6238B185B530
00007f46e3fd4187  call rax
00007f46e3fd4189  movaps xmm14, [rsp]
00007f46e3fd418e  add rsp, 0x30
00007f46e3fd4192  vmovaps xmm0, [rsp]
00007f46e3fd4197  vmovaps xmm1, [rsp+0x10]
00007f46e3fd419d  vmovaps xmm2, [rsp+0x20]
00007f46e3fd41a3  vmovaps xmm3, [rsp+0x30]
00007f46e3fd41a9  vmovaps xmm4, [rsp+0x40]
00007f46e3fd41af  vmovaps xmm5, [rsp+0x50]
00007f46e3fd41b5  vmovaps xmm6, [rsp+0x60]
00007f46e3fd41bb  vmovaps xmm7, [rsp+0x70]
00007f46e3fd41c1  vmovaps xmm8, [rsp+0x80]
00007f46e3fd41ca  vmovaps xmm9, [rsp+0x90]
00007f46e3fd41d3  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd41dc  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd41e5  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd41ee  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd41f7  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd4200  add rsp, 0xF0
00007f46e3fd4207  pop r11
00007f46e3fd4209  pop r10
00007f46e3fd420b  pop r9
00007f46e3fd420d  pop r8
00007f46e3fd420f  pop rsi
00007f46e3fd4210  pop rdi
00007f46e3fd4211  pop rdx
00007f46e3fd4212  pop rcx
00007f46e3fd4213  pop rax
00007f46e3fd4214  add rsp, 0x08
00007f46e3fd4218  jmp 0x00007F46E3FD00AE
00007f46e3fd421d  sub rsp, 0x08
00007f46e3fd4221  push rax
00007f46e3fd4222  push rcx
00007f46e3fd4223  push rdx
00007f46e3fd4224  push rdi
00007f46e3fd4225  push rsi
00007f46e3fd4226  push r8
00007f46e3fd4228  push r9
00007f46e3fd422a  push r10
00007f46e3fd422c  push r11
00007f46e3fd422e  sub rsp, 0xF0
00007f46e3fd4235  vmovaps [rsp], xmm0
00007f46e3fd423a  vmovaps [rsp+0x10], xmm1
00007f46e3fd4240  vmovaps [rsp+0x20], xmm2
00007f46e3fd4246  vmovaps [rsp+0x30], xmm3
00007f46e3fd424c  vmovaps [rsp+0x40], xmm4
00007f46e3fd4252  vmovaps [rsp+0x50], xmm5
00007f46e3fd4258  vmovaps [rsp+0x60], xmm6
00007f46e3fd425e  vmovaps [rsp+0x70], xmm7
00007f46e3fd4264  vmovaps [rsp+0x80], xmm8
00007f46e3fd426d  vmovaps [rsp+0x90], xmm10
00007f46e3fd4276  vmovaps [rsp+0xA0], xmm11
00007f46e3fd427f  vmovaps [rsp+0xB0], xmm12
00007f46e3fd4288  vmovaps [rsp+0xC0], xmm13
00007f46e3fd4291  vmovaps [rsp+0xD0], xmm14
00007f46e3fd429a  vmovaps [rsp+0xE0], xmm15
00007f46e3fd42a3  sub rsp, 0x30
00007f46e3fd42a7  movaps [rsp], xmm9
00007f46e3fd42ac  movaps [rsp+0x10], xmm7
00007f46e3fd42b1  movaps [rsp+0x20], xmm12
00007f46e3fd42b7  lea rdi, [rsp]
00007f46e3fd42bb  mov esi, 0x00
00007f46e3fd42c0  mov rax, 0x6238B185B530
00007f46e3fd42ca  call rax
00007f46e3fd42cc  movaps xmm9, [rsp]
00007f46e3fd42d1  add rsp, 0x30
00007f46e3fd42d5  vmovaps xmm0, [rsp]
00007f46e3fd42da  vmovaps xmm1, [rsp+0x10]
00007f46e3fd42e0  vmovaps xmm2, [rsp+0x20]
00007f46e3fd42e6  vmovaps xmm3, [rsp+0x30]
00007f46e3fd42ec  vmovaps xmm4, [rsp+0x40]
00007f46e3fd42f2  vmovaps xmm5, [rsp+0x50]
00007f46e3fd42f8  vmovaps xmm6, [rsp+0x60]
00007f46e3fd42fe  vmovaps xmm7, [rsp+0x70]
00007f46e3fd4304  vmovaps xmm8, [rsp+0x80]
00007f46e3fd430d  vmovaps xmm10, [rsp+0x90]
00007f46e3fd4316  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd431f  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd4328  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd4331  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd433a  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd4343  add rsp, 0xF0
00007f46e3fd434a  pop r11
00007f46e3fd434c  pop r10
00007f46e3fd434e  pop r9
00007f46e3fd4350  pop r8
00007f46e3fd4352  pop rsi
00007f46e3fd4353  pop rdi
00007f46e3fd4354  pop rdx
00007f46e3fd4355  pop rcx
00007f46e3fd4356  pop rax
00007f46e3fd4357  add rsp, 0x08
00007f46e3fd435b  jmp 0x00007F46E3FD00DD
00007f46e3fd4360  sub rsp, 0x08
00007f46e3fd4364  push rax
00007f46e3fd4365  push rcx
00007f46e3fd4366  push rdx
00007f46e3fd4367  push rdi
00007f46e3fd4368  push rsi
00007f46e3fd4369  push r8
00007f46e3fd436b  push r9
00007f46e3fd436d  push r10
00007f46e3fd436f  push r11
00007f46e3fd4371  sub rsp, 0xF0
00007f46e3fd4378  vmovaps [rsp], xmm0
00007f46e3fd437d  vmovaps [rsp+0x10], xmm1
00007f46e3fd4383  vmovaps [rsp+0x20], xmm2
00007f46e3fd4389  vmovaps [rsp+0x30], xmm3
00007f46e3fd438f  vmovaps [rsp+0x40], xmm4
00007f46e3fd4395  vmovaps [rsp+0x50], xmm5
00007f46e3fd439b  vmovaps [rsp+0x60], xmm6
00007f46e3fd43a1  vmovaps [rsp+0x70], xmm7
00007f46e3fd43a7  vmovaps [rsp+0x80], xmm8
00007f46e3fd43b0  vmovaps [rsp+0x90], xmm9
00007f46e3fd43b9  vmovaps [rsp+0xA0], xmm10
00007f46e3fd43c2  vmovaps [rsp+0xB0], xmm11
00007f46e3fd43cb  vmovaps [rsp+0xC0], xmm13
00007f46e3fd43d4  vmovaps [rsp+0xD0], xmm14
00007f46e3fd43dd  vmovaps [rsp+0xE0], xmm15
00007f46e3fd43e6  sub rsp, 0x30
00007f46e3fd43ea  movaps [rsp], xmm12
00007f46e3fd43ef  movaps [rsp+0x10], xmm15
00007f46e3fd43f5  movaps [rsp+0x20], xmm11
00007f46e3fd43fb  lea rdi, [rsp]
00007f46e3fd43ff  mov esi, 0x00
00007f46e3fd4404  mov rax, 0x6238B185B530
00007f46e3fd440e  call rax
00007f46e3fd4410  movaps xmm12, [rsp]
00007f46e3fd4415  add rsp, 0x30
00007f46e3fd4419  vmovaps xmm0, [rsp]
00007f46e3fd441e  vmovaps xmm1, [rsp+0x10]
00007f46e3fd4424  vmovaps xmm2, [rsp+0x20]
00007f46e3fd442a  vmovaps xmm3, [rsp+0x30]
00007f46e3fd4430  vmovaps xmm4, [rsp+0x40]
00007f46e3fd4436  vmovaps xmm5, [rsp+0x50]
00007f46e3fd443c  vmovaps xmm6, [rsp+0x60]
00007f46e3fd4442  vmovaps xmm7, [rsp+0x70]
00007f46e3fd4448  vmovaps xmm8, [rsp+0x80]
00007f46e3fd4451  vmovaps xmm9, [rsp+0x90]
00007f46e3fd445a  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd4463  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd446c  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd4475  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd447e  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd4487  add rsp, 0xF0
00007f46e3fd448e  pop r11
00007f46e3fd4490  pop r10
00007f46e3fd4492  pop r9
00007f46e3fd4494  pop r8
00007f46e3fd4496  pop rsi
00007f46e3fd4497  pop rdi
00007f46e3fd4498  pop rdx
00007f46e3fd4499  pop rcx
00007f46e3fd449a  pop rax
00007f46e3fd449b  add rsp, 0x08
00007f46e3fd449f  jmp 0x00007F46E3FD00F7
00007f46e3fd44a4  sub rsp, 0x08
00007f46e3fd44a8  push rax
00007f46e3fd44a9  push rcx
00007f46e3fd44aa  push rdx
00007f46e3fd44ab  push rdi
00007f46e3fd44ac  push rsi
00007f46e3fd44ad  push r8
00007f46e3fd44af  push r9
00007f46e3fd44b1  push r10
00007f46e3fd44b3  push r11
00007f46e3fd44b5  sub rsp, 0xF0
00007f46e3fd44bc  vmovaps [rsp], xmm0
00007f46e3fd44c1  vmovaps [rsp+0x10], xmm1
00007f46e3fd44c7  vmovaps [rsp+0x20], xmm2
00007f46e3fd44cd  vmovaps [rsp+0x30], xmm3
00007f46e3fd44d3  vmovaps [rsp+0x40], xmm4
00007f46e3fd44d9  vmovaps [rsp+0x50], xmm5
00007f46e3fd44df  vmovaps [rsp+0x60], xmm6
00007f46e3fd44e5  vmovaps [rsp+0x70], xmm7
00007f46e3fd44eb  vmovaps [rsp+0x80], xmm8
00007f46e3fd44f4  vmovaps [rsp+0x90], xmm9
00007f46e3fd44fd  vmovaps [rsp+0xA0], xmm10
00007f46e3fd4506  vmovaps [rsp+0xB0], xmm12
00007f46e3fd450f  vmovaps [rsp+0xC0], xmm13
00007f46e3fd4518  vmovaps [rsp+0xD0], xmm14
00007f46e3fd4521  vmovaps [rsp+0xE0], xmm15
00007f46e3fd452a  sub rsp, 0x30
00007f46e3fd452e  movaps [rsp], xmm11
00007f46e3fd4533  movaps [rsp+0x10], xmm7
00007f46e3fd4538  movaps [rsp+0x20], xmm15
00007f46e3fd453e  lea rdi, [rsp]
00007f46e3fd4542  mov esi, 0x00
00007f46e3fd4547  mov rax, 0x6238B185B530
00007f46e3fd4551  call rax
00007f46e3fd4553  movaps xmm11, [rsp]
00007f46e3fd4558  add rsp, 0x30
00007f46e3fd455c  vmovaps xmm0, [rsp]
00007f46e3fd4561  vmovaps xmm1, [rsp+0x10]
00007f46e3fd4567  vmovaps xmm2, [rsp+0x20]
00007f46e3fd456d  vmovaps xmm3, [rsp+0x30]
00007f46e3fd4573  vmovaps xmm4, [rsp+0x40]
00007f46e3fd4579  vmovaps xmm5, [rsp+0x50]
00007f46e3fd457f  vmovaps xmm6, [rsp+0x60]
00007f46e3fd4585  vmovaps xmm7, [rsp+0x70]
00007f46e3fd458b  vmovaps xmm8, [rsp+0x80]
00007f46e3fd4594  vmovaps xmm9, [rsp+0x90]
00007f46e3fd459d  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd45a6  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd45af  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd45b8  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd45c1  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd45ca  add rsp, 0xF0
00007f46e3fd45d1  pop r11
00007f46e3fd45d3  pop r10
00007f46e3fd45d5  pop r9
00007f46e3fd45d7  pop r8
00007f46e3fd45d9  pop rsi
00007f46e3fd45da  pop rdi
00007f46e3fd45db  pop rdx
00007f46e3fd45dc  pop rcx
00007f46e3fd45dd  pop rax
00007f46e3fd45de  add rsp, 0x08
00007f46e3fd45e2  jmp 0x00007F46E3FD0123
00007f46e3fd45e7  sub rsp, 0x08
00007f46e3fd45eb  push rax
00007f46e3fd45ec  push rcx
00007f46e3fd45ed  push rdx
00007f46e3fd45ee  push rdi
00007f46e3fd45ef  push rsi
00007f46e3fd45f0  push r8
00007f46e3fd45f2  push r9
00007f46e3fd45f4  push r10
00007f46e3fd45f6  push r11
00007f46e3fd45f8  sub rsp, 0xF0
00007f46e3fd45ff  vmovaps [rsp], xmm0
00007f46e3fd4604  vmovaps [rsp+0x10], xmm1
00007f46e3fd460a  vmovaps [rsp+0x20], xmm2
00007f46e3fd4610  vmovaps [rsp+0x30], xmm3
00007f46e3fd4616  vmovaps [rsp+0x40], xmm4
00007f46e3fd461c  vmovaps [rsp+0x50], xmm5
00007f46e3fd4622  vmovaps [rsp+0x60], xmm6
00007f46e3fd4628  vmovaps [rsp+0x70], xmm7
00007f46e3fd462e  vmovaps [rsp+0x80], xmm8
00007f46e3fd4637  vmovaps [rsp+0x90], xmm9
00007f46e3fd4640  vmovaps [rsp+0xA0], xmm10
00007f46e3fd4649  vmovaps [rsp+0xB0], xmm11
00007f46e3fd4652  vmovaps [rsp+0xC0], xmm12
00007f46e3fd465b  vmovaps [rsp+0xD0], xmm13
00007f46e3fd4664  vmovaps [rsp+0xE0], xmm14
00007f46e3fd466d  sub rsp, 0x30
00007f46e3fd4671  movaps [rsp], xmm15
00007f46e3fd4676  movaps [rsp+0x10], xmm10
00007f46e3fd467c  movaps [rsp+0x20], xmm13
00007f46e3fd4682  lea rdi, [rsp]
00007f46e3fd4686  mov esi, 0x00
00007f46e3fd468b  mov rax, 0x6238B185B530
00007f46e3fd4695  call rax
00007f46e3fd4697  movaps xmm15, [rsp]
00007f46e3fd469c  add rsp, 0x30
00007f46e3fd46a0  vmovaps xmm0, [rsp]
00007f46e3fd46a5  vmovaps xmm1, [rsp+0x10]
00007f46e3fd46ab  vmovaps xmm2, [rsp+0x20]
00007f46e3fd46b1  vmovaps xmm3, [rsp+0x30]
00007f46e3fd46b7  vmovaps xmm4, [rsp+0x40]
00007f46e3fd46bd  vmovaps xmm5, [rsp+0x50]
00007f46e3fd46c3  vmovaps xmm6, [rsp+0x60]
00007f46e3fd46c9  vmovaps xmm7, [rsp+0x70]
00007f46e3fd46cf  vmovaps xmm8, [rsp+0x80]
00007f46e3fd46d8  vmovaps xmm9, [rsp+0x90]
00007f46e3fd46e1  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd46ea  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd46f3  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd46fc  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd4705  vmovaps xmm14, [rsp+0xE0]
00007f46e3fd470e  add rsp, 0xF0
00007f46e3fd4715  pop r11
00007f46e3fd4717  pop r10
00007f46e3fd4719  pop r9
00007f46e3fd471b  pop r8
00007f46e3fd471d  pop rsi
00007f46e3fd471e  pop rdi
00007f46e3fd471f  pop rdx
00007f46e3fd4720  pop rcx
00007f46e3fd4721  pop rax
00007f46e3fd4722  add rsp, 0x08
00007f46e3fd4726  jmp 0x00007F46E3FD013D
00007f46e3fd472b  sub rsp, 0x08
00007f46e3fd472f  push rax
00007f46e3fd4730  push rcx
00007f46e3fd4731  push rdx
00007f46e3fd4732  push rdi
00007f46e3fd4733  push rsi
00007f46e3fd4734  push r8
00007f46e3fd4736  push r9
00007f46e3fd4738  push r10
00007f46e3fd473a  push r11
00007f46e3fd473c  sub rsp, 0xF0
00007f46e3fd4743  vmovaps [rsp], xmm0
00007f46e3fd4748  vmovaps [rsp+0x10], xmm1
00007f46e3fd474e  vmovaps [rsp+0x20], xmm2
00007f46e3fd4754  vmovaps [rsp+0x30], xmm3
00007f46e3fd475a  vmovaps [rsp+0x40], xmm4
00007f46e3fd4760  vmovaps [rsp+0x50], xmm5
00007f46e3fd4766  vmovaps [rsp+0x60], xmm6
00007f46e3fd476c  vmovaps [rsp+0x70], xmm7
00007f46e3fd4772  vmovaps [rsp+0x80], xmm8
00007f46e3fd477b  vmovaps [rsp+0x90], xmm9
00007f46e3fd4784  vmovaps [rsp+0xA0], xmm11
00007f46e3fd478d  vmovaps [rsp+0xB0], xmm12
00007f46e3fd4796  vmovaps [rsp+0xC0], xmm13
00007f46e3fd479f  vmovaps [rsp+0xD0], xmm14
00007f46e3fd47a8  vmovaps [rsp+0xE0], xmm15
00007f46e3fd47b1  sub rsp, 0x30
00007f46e3fd47b5  movaps [rsp], xmm10
00007f46e3fd47ba  movaps [rsp+0x10], xmm7
00007f46e3fd47bf  movaps [rsp+0x20], xmm13
00007f46e3fd47c5  lea rdi, [rsp]
00007f46e3fd47c9  mov esi, 0x00
00007f46e3fd47ce  mov rax, 0x6238B185B530
00007f46e3fd47d8  call rax
00007f46e3fd47da  movaps xmm10, [rsp]
00007f46e3fd47df  add rsp, 0x30
00007f46e3fd47e3  vmovaps xmm0, [rsp]
00007f46e3fd47e8  vmovaps xmm1, [rsp+0x10]
00007f46e3fd47ee  vmovaps xmm2, [rsp+0x20]
00007f46e3fd47f4  vmovaps xmm3, [rsp+0x30]
00007f46e3fd47fa  vmovaps xmm4, [rsp+0x40]
00007f46e3fd4800  vmovaps xmm5, [rsp+0x50]
00007f46e3fd4806  vmovaps xmm6, [rsp+0x60]
00007f46e3fd480c  vmovaps xmm7, [rsp+0x70]
00007f46e3fd4812  vmovaps xmm8, [rsp+0x80]
00007f46e3fd481b  vmovaps xmm9, [rsp+0x90]
00007f46e3fd4824  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd482d  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd4836  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd483f  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd4848  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd4851  add rsp, 0xF0
00007f46e3fd4858  pop r11
00007f46e3fd485a  pop r10
00007f46e3fd485c  pop r9
00007f46e3fd485e  pop r8
00007f46e3fd4860  pop rsi
00007f46e3fd4861  pop rdi
00007f46e3fd4862  pop rdx
00007f46e3fd4863  pop rcx
00007f46e3fd4864  pop rax
00007f46e3fd4865  add rsp, 0x08
00007f46e3fd4869  jmp 0x00007F46E3FD0169
00007f46e3fd486e  sub rsp, 0x08
00007f46e3fd4872  push rax
00007f46e3fd4873  push rcx
00007f46e3fd4874  push rdx
00007f46e3fd4875  push rdi
00007f46e3fd4876  push rsi
00007f46e3fd4877  push r8
00007f46e3fd4879  push r9
00007f46e3fd487b  push r10
00007f46e3fd487d  push r11
00007f46e3fd487f  sub rsp, 0xF0
00007f46e3fd4886  vmovaps [rsp], xmm0
00007f46e3fd488b  vmovaps [rsp+0x10], xmm1
00007f46e3fd4891  vmovaps [rsp+0x20], xmm2
00007f46e3fd4897  vmovaps [rsp+0x30], xmm3
00007f46e3fd489d  vmovaps [rsp+0x40], xmm4
00007f46e3fd48a3  vmovaps [rsp+0x50], xmm5
00007f46e3fd48a9  vmovaps [rsp+0x60], xmm6
00007f46e3fd48af  vmovaps [rsp+0x70], xmm7
00007f46e3fd48b5  vmovaps [rsp+0x80], xmm8
00007f46e3fd48be  vmovaps [rsp+0x90], xmm9
00007f46e3fd48c7  vmovaps [rsp+0xA0], xmm10
00007f46e3fd48d0  vmovaps [rsp+0xB0], xmm11
00007f46e3fd48d9  vmovaps [rsp+0xC0], xmm12
00007f46e3fd48e2  vmovaps [rsp+0xD0], xmm14
00007f46e3fd48eb  vmovaps [rsp+0xE0], xmm15
00007f46e3fd48f4  sub rsp, 0x30
00007f46e3fd48f8  movaps [rsp], xmm13
00007f46e3fd48fd  movaps [rsp+0x10], xmm1
00007f46e3fd4902  movaps [rsp+0x20], xmm8
00007f46e3fd4908  lea rdi, [rsp]
00007f46e3fd490c  mov esi, 0x00
00007f46e3fd4911  mov rax, 0x6238B185B530
00007f46e3fd491b  call rax
00007f46e3fd491d  movaps xmm13, [rsp]
00007f46e3fd4922  add rsp, 0x30
00007f46e3fd4926  vmovaps xmm0, [rsp]
00007f46e3fd492b  vmovaps xmm1, [rsp+0x10]
00007f46e3fd4931  vmovaps xmm2, [rsp+0x20]
00007f46e3fd4937  vmovaps xmm3, [rsp+0x30]
00007f46e3fd493d  vmovaps xmm4, [rsp+0x40]
00007f46e3fd4943  vmovaps xmm5, [rsp+0x50]
00007f46e3fd4949  vmovaps xmm6, [rsp+0x60]
00007f46e3fd494f  vmovaps xmm7, [rsp+0x70]
00007f46e3fd4955  vmovaps xmm8, [rsp+0x80]
00007f46e3fd495e  vmovaps xmm9, [rsp+0x90]
00007f46e3fd4967  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd4970  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd4979  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd4982  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd498b  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd4994  add rsp, 0xF0
00007f46e3fd499b  pop r11
00007f46e3fd499d  pop r10
00007f46e3fd499f  pop r9
00007f46e3fd49a1  pop r8
00007f46e3fd49a3  pop rsi
00007f46e3fd49a4  pop rdi
00007f46e3fd49a5  pop rdx
00007f46e3fd49a6  pop rcx
00007f46e3fd49a7  pop rax
00007f46e3fd49a8  add rsp, 0x08
00007f46e3fd49ac  jmp 0x00007F46E3FD0183
00007f46e3fd49b1  call 0x00007F46E3DFF430
00007f46e3fd49b6  jmp 0x00007F46E3FD018D
00007f46e3fd49bb  sub rsp, 0x08
00007f46e3fd49bf  push rax
00007f46e3fd49c0  push rcx
00007f46e3fd49c1  push rdx
00007f46e3fd49c2  push rdi
00007f46e3fd49c3  push rsi
00007f46e3fd49c4  push r8
00007f46e3fd49c6  push r9
00007f46e3fd49c8  push r10
00007f46e3fd49ca  push r11
00007f46e3fd49cc  sub rsp, 0xF0
00007f46e3fd49d3  vmovaps [rsp], xmm0
00007f46e3fd49d8  vmovaps [rsp+0x10], xmm1
00007f46e3fd49de  vmovaps [rsp+0x20], xmm2
00007f46e3fd49e4  vmovaps [rsp+0x30], xmm3
00007f46e3fd49ea  vmovaps [rsp+0x40], xmm4
00007f46e3fd49f0  vmovaps [rsp+0x50], xmm5
00007f46e3fd49f6  vmovaps [rsp+0x60], xmm6
00007f46e3fd49fc  vmovaps [rsp+0x70], xmm7
00007f46e3fd4a02  vmovaps [rsp+0x80], xmm9
00007f46e3fd4a0b  vmovaps [rsp+0x90], xmm10
00007f46e3fd4a14  vmovaps [rsp+0xA0], xmm11
00007f46e3fd4a1d  vmovaps [rsp+0xB0], xmm12
00007f46e3fd4a26  vmovaps [rsp+0xC0], xmm13
00007f46e3fd4a2f  vmovaps [rsp+0xD0], xmm14
00007f46e3fd4a38  vmovaps [rsp+0xE0], xmm15
00007f46e3fd4a41  sub rsp, 0x30
00007f46e3fd4a45  movaps [rsp], xmm8
00007f46e3fd4a4a  movaps [rsp+0x10], xmm14
00007f46e3fd4a50  movaps [rsp+0x20], xmm9
00007f46e3fd4a56  lea rdi, [rsp]
00007f46e3fd4a5a  mov esi, 0x00
00007f46e3fd4a5f  mov rax, 0x6238B185B530
00007f46e3fd4a69  call rax
00007f46e3fd4a6b  movaps xmm8, [rsp]
00007f46e3fd4a70  add rsp, 0x30
00007f46e3fd4a74  vmovaps xmm0, [rsp]
00007f46e3fd4a79  vmovaps xmm1, [rsp+0x10]
00007f46e3fd4a7f  vmovaps xmm2, [rsp+0x20]
00007f46e3fd4a85  vmovaps xmm3, [rsp+0x30]
00007f46e3fd4a8b  vmovaps xmm4, [rsp+0x40]
00007f46e3fd4a91  vmovaps xmm5, [rsp+0x50]
00007f46e3fd4a97  vmovaps xmm6, [rsp+0x60]
00007f46e3fd4a9d  vmovaps xmm7, [rsp+0x70]
00007f46e3fd4aa3  vmovaps xmm9, [rsp+0x80]
00007f46e3fd4aac  vmovaps xmm10, [rsp+0x90]
00007f46e3fd4ab5  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd4abe  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd4ac7  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd4ad0  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd4ad9  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd4ae2  add rsp, 0xF0
00007f46e3fd4ae9  pop r11
00007f46e3fd4aeb  pop r10
00007f46e3fd4aed  pop r9
00007f46e3fd4aef  pop r8
00007f46e3fd4af1  pop rsi
00007f46e3fd4af2  pop rdi
00007f46e3fd4af3  pop rdx
00007f46e3fd4af4  pop rcx
00007f46e3fd4af5  pop rax
00007f46e3fd4af6  add rsp, 0x08
00007f46e3fd4afa  jmp 0x00007F46E3FD01AF
00007f46e3fd4aff  sub rsp, 0x08
00007f46e3fd4b03  push rax
00007f46e3fd4b04  push rcx
00007f46e3fd4b05  push rdx
00007f46e3fd4b06  push rdi
00007f46e3fd4b07  push rsi
00007f46e3fd4b08  push r8
00007f46e3fd4b0a  push r9
00007f46e3fd4b0c  push r10
00007f46e3fd4b0e  push r11
00007f46e3fd4b10  sub rsp, 0xF0
00007f46e3fd4b17  vmovaps [rsp], xmm0
00007f46e3fd4b1c  vmovaps [rsp+0x10], xmm1
00007f46e3fd4b22  vmovaps [rsp+0x20], xmm2
00007f46e3fd4b28  vmovaps [rsp+0x30], xmm3
00007f46e3fd4b2e  vmovaps [rsp+0x40], xmm4
00007f46e3fd4b34  vmovaps [rsp+0x50], xmm5
00007f46e3fd4b3a  vmovaps [rsp+0x60], xmm6
00007f46e3fd4b40  vmovaps [rsp+0x70], xmm7
00007f46e3fd4b46  vmovaps [rsp+0x80], xmm8
00007f46e3fd4b4f  vmovaps [rsp+0x90], xmm10
00007f46e3fd4b58  vmovaps [rsp+0xA0], xmm11
00007f46e3fd4b61  vmovaps [rsp+0xB0], xmm12
00007f46e3fd4b6a  vmovaps [rsp+0xC0], xmm13
00007f46e3fd4b73  vmovaps [rsp+0xD0], xmm14
00007f46e3fd4b7c  vmovaps [rsp+0xE0], xmm15
00007f46e3fd4b85  sub rsp, 0x30
00007f46e3fd4b89  movaps [rsp], xmm9
00007f46e3fd4b8e  movaps [rsp+0x10], xmm1
00007f46e3fd4b93  movaps [rsp+0x20], xmm14
00007f46e3fd4b99  lea rdi, [rsp]
00007f46e3fd4b9d  mov esi, 0x00
00007f46e3fd4ba2  mov rax, 0x6238B185B530
00007f46e3fd4bac  call rax
00007f46e3fd4bae  movaps xmm9, [rsp]
00007f46e3fd4bb3  add rsp, 0x30
00007f46e3fd4bb7  vmovaps xmm0, [rsp]
00007f46e3fd4bbc  vmovaps xmm1, [rsp+0x10]
00007f46e3fd4bc2  vmovaps xmm2, [rsp+0x20]
00007f46e3fd4bc8  vmovaps xmm3, [rsp+0x30]
00007f46e3fd4bce  vmovaps xmm4, [rsp+0x40]
00007f46e3fd4bd4  vmovaps xmm5, [rsp+0x50]
00007f46e3fd4bda  vmovaps xmm6, [rsp+0x60]
00007f46e3fd4be0  vmovaps xmm7, [rsp+0x70]
00007f46e3fd4be6  vmovaps xmm8, [rsp+0x80]
00007f46e3fd4bef  vmovaps xmm10, [rsp+0x90]
00007f46e3fd4bf8  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd4c01  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd4c0a  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd4c13  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd4c1c  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd4c25  add rsp, 0xF0
00007f46e3fd4c2c  pop r11
00007f46e3fd4c2e  pop r10
00007f46e3fd4c30  pop r9
00007f46e3fd4c32  pop r8
00007f46e3fd4c34  pop rsi
00007f46e3fd4c35  pop rdi
00007f46e3fd4c36  pop rdx
00007f46e3fd4c37  pop rcx
00007f46e3fd4c38  pop rax
00007f46e3fd4c39  add rsp, 0x08
00007f46e3fd4c3d  jmp 0x00007F46E3FD01DD
00007f46e3fd4c42  sub rsp, 0x08
00007f46e3fd4c46  push rax
00007f46e3fd4c47  push rcx
00007f46e3fd4c48  push rdx
00007f46e3fd4c49  push rdi
00007f46e3fd4c4a  push rsi
00007f46e3fd4c4b  push r8
00007f46e3fd4c4d  push r9
00007f46e3fd4c4f  push r10
00007f46e3fd4c51  push r11
00007f46e3fd4c53  sub rsp, 0xF0
00007f46e3fd4c5a  vmovaps [rsp], xmm0
00007f46e3fd4c5f  vmovaps [rsp+0x10], xmm1
00007f46e3fd4c65  vmovaps [rsp+0x20], xmm2
00007f46e3fd4c6b  vmovaps [rsp+0x30], xmm3
00007f46e3fd4c71  vmovaps [rsp+0x40], xmm4
00007f46e3fd4c77  vmovaps [rsp+0x50], xmm5
00007f46e3fd4c7d  vmovaps [rsp+0x60], xmm6
00007f46e3fd4c83  vmovaps [rsp+0x70], xmm7
00007f46e3fd4c89  vmovaps [rsp+0x80], xmm8
00007f46e3fd4c92  vmovaps [rsp+0x90], xmm9
00007f46e3fd4c9b  vmovaps [rsp+0xA0], xmm10
00007f46e3fd4ca4  vmovaps [rsp+0xB0], xmm11
00007f46e3fd4cad  vmovaps [rsp+0xC0], xmm12
00007f46e3fd4cb6  vmovaps [rsp+0xD0], xmm13
00007f46e3fd4cbf  vmovaps [rsp+0xE0], xmm15
00007f46e3fd4cc8  sub rsp, 0x30
00007f46e3fd4ccc  movaps [rsp], xmm14
00007f46e3fd4cd1  movaps [rsp+0x10], xmm4
00007f46e3fd4cd6  movaps [rsp+0x20], xmm1
00007f46e3fd4cdb  lea rdi, [rsp]
00007f46e3fd4cdf  mov esi, 0x00
00007f46e3fd4ce4  mov rax, 0x6238B185B530
00007f46e3fd4cee  call rax
00007f46e3fd4cf0  movaps xmm14, [rsp]
00007f46e3fd4cf5  add rsp, 0x30
00007f46e3fd4cf9  vmovaps xmm0, [rsp]
00007f46e3fd4cfe  vmovaps xmm1, [rsp+0x10]
00007f46e3fd4d04  vmovaps xmm2, [rsp+0x20]
00007f46e3fd4d0a  vmovaps xmm3, [rsp+0x30]
00007f46e3fd4d10  vmovaps xmm4, [rsp+0x40]
00007f46e3fd4d16  vmovaps xmm5, [rsp+0x50]
00007f46e3fd4d1c  vmovaps xmm6, [rsp+0x60]
00007f46e3fd4d22  vmovaps xmm7, [rsp+0x70]
00007f46e3fd4d28  vmovaps xmm8, [rsp+0x80]
00007f46e3fd4d31  vmovaps xmm9, [rsp+0x90]
00007f46e3fd4d3a  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd4d43  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd4d4c  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd4d55  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd4d5e  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd4d67  add rsp, 0xF0
00007f46e3fd4d6e  pop r11
00007f46e3fd4d70  pop r10
00007f46e3fd4d72  pop r9
00007f46e3fd4d74  pop r8
00007f46e3fd4d76  pop rsi
00007f46e3fd4d77  pop rdi
00007f46e3fd4d78  pop rdx
00007f46e3fd4d79  pop rcx
00007f46e3fd4d7a  pop rax
00007f46e3fd4d7b  add rsp, 0x08
00007f46e3fd4d7f  jmp 0x00007F46E3FD0203
00007f46e3fd4d84  sub rsp, 0x08
00007f46e3fd4d88  push rax
00007f46e3fd4d89  push rcx
00007f46e3fd4d8a  push rdx
00007f46e3fd4d8b  push rdi
00007f46e3fd4d8c  push rsi
00007f46e3fd4d8d  push r8
00007f46e3fd4d8f  push r9
00007f46e3fd4d91  push r10
00007f46e3fd4d93  push r11
00007f46e3fd4d95  sub rsp, 0xF0
00007f46e3fd4d9c  vmovaps [rsp], xmm0
00007f46e3fd4da1  vmovaps [rsp+0x10], xmm2
00007f46e3fd4da7  vmovaps [rsp+0x20], xmm3
00007f46e3fd4dad  vmovaps [rsp+0x30], xmm4
00007f46e3fd4db3  vmovaps [rsp+0x40], xmm5
00007f46e3fd4db9  vmovaps [rsp+0x50], xmm6
00007f46e3fd4dbf  vmovaps [rsp+0x60], xmm7
00007f46e3fd4dc5  vmovaps [rsp+0x70], xmm8
00007f46e3fd4dcb  vmovaps [rsp+0x80], xmm9
00007f46e3fd4dd4  vmovaps [rsp+0x90], xmm10
00007f46e3fd4ddd  vmovaps [rsp+0xA0], xmm11
00007f46e3fd4de6  vmovaps [rsp+0xB0], xmm12
00007f46e3fd4def  vmovaps [rsp+0xC0], xmm13
00007f46e3fd4df8  vmovaps [rsp+0xD0], xmm14
00007f46e3fd4e01  vmovaps [rsp+0xE0], xmm15
00007f46e3fd4e0a  sub rsp, 0x30
00007f46e3fd4e0e  movaps [rsp], xmm1
00007f46e3fd4e12  movaps [rsp+0x10], xmm12
00007f46e3fd4e18  movaps [rsp+0x20], xmm11
00007f46e3fd4e1e  lea rdi, [rsp]
00007f46e3fd4e22  mov esi, 0x00
00007f46e3fd4e27  mov rax, 0x6238B185B530
00007f46e3fd4e31  call rax
00007f46e3fd4e33  movaps xmm1, [rsp]
00007f46e3fd4e37  add rsp, 0x30
00007f46e3fd4e3b  vmovaps xmm0, [rsp]
00007f46e3fd4e40  vmovaps xmm2, [rsp+0x10]
00007f46e3fd4e46  vmovaps xmm3, [rsp+0x20]
00007f46e3fd4e4c  vmovaps xmm4, [rsp+0x30]
00007f46e3fd4e52  vmovaps xmm5, [rsp+0x40]
00007f46e3fd4e58  vmovaps xmm6, [rsp+0x50]
00007f46e3fd4e5e  vmovaps xmm7, [rsp+0x60]
00007f46e3fd4e64  vmovaps xmm8, [rsp+0x70]
00007f46e3fd4e6a  vmovaps xmm9, [rsp+0x80]
00007f46e3fd4e73  vmovaps xmm10, [rsp+0x90]
00007f46e3fd4e7c  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd4e85  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd4e8e  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd4e97  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd4ea0  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd4ea9  add rsp, 0xF0
00007f46e3fd4eb0  pop r11
00007f46e3fd4eb2  pop r10
00007f46e3fd4eb4  pop r9
00007f46e3fd4eb6  pop r8
00007f46e3fd4eb8  pop rsi
00007f46e3fd4eb9  pop rdi
00007f46e3fd4eba  pop rdx
00007f46e3fd4ebb  pop rcx
00007f46e3fd4ebc  pop rax
00007f46e3fd4ebd  add rsp, 0x08
00007f46e3fd4ec1  jmp 0x00007F46E3FD0224
00007f46e3fd4ec6  call 0x00007F46E3EE20A0
00007f46e3fd4ecb  jmp 0x00007F46E3FD0232
00007f46e3fd4ed0  call 0x00007F46E3E09D70
00007f46e3fd4ed5  jmp 0x00007F46E3FD023C
00007f46e3fd4eda  sub rsp, 0x08
00007f46e3fd4ede  push rax
00007f46e3fd4edf  push rcx
00007f46e3fd4ee0  push rdx
00007f46e3fd4ee1  push rdi
00007f46e3fd4ee2  push rsi
00007f46e3fd4ee3  push r8
00007f46e3fd4ee5  push r9
00007f46e3fd4ee7  push r10
00007f46e3fd4ee9  push r11
00007f46e3fd4eeb  sub rsp, 0xF0
00007f46e3fd4ef2  vmovaps [rsp], xmm0
00007f46e3fd4ef7  vmovaps [rsp+0x10], xmm1
00007f46e3fd4efd  vmovaps [rsp+0x20], xmm2
00007f46e3fd4f03  vmovaps [rsp+0x30], xmm3
00007f46e3fd4f09  vmovaps [rsp+0x40], xmm4
00007f46e3fd4f0f  vmovaps [rsp+0x50], xmm5
00007f46e3fd4f15  vmovaps [rsp+0x60], xmm6
00007f46e3fd4f1b  vmovaps [rsp+0x70], xmm8
00007f46e3fd4f21  vmovaps [rsp+0x80], xmm9
00007f46e3fd4f2a  vmovaps [rsp+0x90], xmm10
00007f46e3fd4f33  vmovaps [rsp+0xA0], xmm11
00007f46e3fd4f3c  vmovaps [rsp+0xB0], xmm12
00007f46e3fd4f45  vmovaps [rsp+0xC0], xmm13
00007f46e3fd4f4e  vmovaps [rsp+0xD0], xmm14
00007f46e3fd4f57  vmovaps [rsp+0xE0], xmm15
00007f46e3fd4f60  sub rsp, 0x30
00007f46e3fd4f64  movaps [rsp], xmm7
00007f46e3fd4f68  movaps [rsp+0x10], xmm15
00007f46e3fd4f6e  movaps [rsp+0x20], xmm10
00007f46e3fd4f74  lea rdi, [rsp]
00007f46e3fd4f78  mov esi, 0x00
00007f46e3fd4f7d  mov rax, 0x6238B185B530
00007f46e3fd4f87  call rax
00007f46e3fd4f89  movaps xmm7, [rsp]
00007f46e3fd4f8d  add rsp, 0x30
00007f46e3fd4f91  vmovaps xmm0, [rsp]
00007f46e3fd4f96  vmovaps xmm1, [rsp+0x10]
00007f46e3fd4f9c  vmovaps xmm2, [rsp+0x20]
00007f46e3fd4fa2  vmovaps xmm3, [rsp+0x30]
00007f46e3fd4fa8  vmovaps xmm4, [rsp+0x40]
00007f46e3fd4fae  vmovaps xmm5, [rsp+0x50]
00007f46e3fd4fb4  vmovaps xmm6, [rsp+0x60]
00007f46e3fd4fba  vmovaps xmm8, [rsp+0x70]
00007f46e3fd4fc0  vmovaps xmm9, [rsp+0x80]
00007f46e3fd4fc9  vmovaps xmm10, [rsp+0x90]
00007f46e3fd4fd2  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd4fdb  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd4fe4  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd4fed  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd4ff6  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd4fff  add rsp, 0xF0
00007f46e3fd5006  pop r11
00007f46e3fd5008  pop r10
00007f46e3fd500a  pop r9
00007f46e3fd500c  pop r8
00007f46e3fd500e  pop rsi
00007f46e3fd500f  pop rdi
00007f46e3fd5010  pop rdx
00007f46e3fd5011  pop rcx
00007f46e3fd5012  pop rax
00007f46e3fd5013  add rsp, 0x08
00007f46e3fd5017  jmp 0x00007F46E3FD025D
00007f46e3fd501c  sub rsp, 0x08
00007f46e3fd5020  push rax
00007f46e3fd5021  push rcx
00007f46e3fd5022  push rdx
00007f46e3fd5023  push rdi
00007f46e3fd5024  push rsi
00007f46e3fd5025  push r8
00007f46e3fd5027  push r9
00007f46e3fd5029  push r10
00007f46e3fd502b  push r11
00007f46e3fd502d  sub rsp, 0xF0
00007f46e3fd5034  vmovaps [rsp], xmm0
00007f46e3fd5039  vmovaps [rsp+0x10], xmm1
00007f46e3fd503f  vmovaps [rsp+0x20], xmm2
00007f46e3fd5045  vmovaps [rsp+0x30], xmm3
00007f46e3fd504b  vmovaps [rsp+0x40], xmm4
00007f46e3fd5051  vmovaps [rsp+0x50], xmm5
00007f46e3fd5057  vmovaps [rsp+0x60], xmm6
00007f46e3fd505d  vmovaps [rsp+0x70], xmm7
00007f46e3fd5063  vmovaps [rsp+0x80], xmm8
00007f46e3fd506c  vmovaps [rsp+0x90], xmm9
00007f46e3fd5075  vmovaps [rsp+0xA0], xmm11
00007f46e3fd507e  vmovaps [rsp+0xB0], xmm12
00007f46e3fd5087  vmovaps [rsp+0xC0], xmm13
00007f46e3fd5090  vmovaps [rsp+0xD0], xmm14
00007f46e3fd5099  vmovaps [rsp+0xE0], xmm15
00007f46e3fd50a2  sub rsp, 0x30
00007f46e3fd50a6  movaps [rsp], xmm10
00007f46e3fd50ab  movaps [rsp+0x10], xmm11
00007f46e3fd50b1  movaps [rsp+0x20], xmm15
00007f46e3fd50b7  lea rdi, [rsp]
00007f46e3fd50bb  mov esi, 0x00
00007f46e3fd50c0  mov rax, 0x6238B185B530
00007f46e3fd50ca  call rax
00007f46e3fd50cc  movaps xmm10, [rsp]
00007f46e3fd50d1  add rsp, 0x30
00007f46e3fd50d5  vmovaps xmm0, [rsp]
00007f46e3fd50da  vmovaps xmm1, [rsp+0x10]
00007f46e3fd50e0  vmovaps xmm2, [rsp+0x20]
00007f46e3fd50e6  vmovaps xmm3, [rsp+0x30]
00007f46e3fd50ec  vmovaps xmm4, [rsp+0x40]
00007f46e3fd50f2  vmovaps xmm5, [rsp+0x50]
00007f46e3fd50f8  vmovaps xmm6, [rsp+0x60]
00007f46e3fd50fe  vmovaps xmm7, [rsp+0x70]
00007f46e3fd5104  vmovaps xmm8, [rsp+0x80]
00007f46e3fd510d  vmovaps xmm9, [rsp+0x90]
00007f46e3fd5116  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd511f  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd5128  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd5131  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd513a  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd5143  add rsp, 0xF0
00007f46e3fd514a  pop r11
00007f46e3fd514c  pop r10
00007f46e3fd514e  pop r9
00007f46e3fd5150  pop r8
00007f46e3fd5152  pop rsi
00007f46e3fd5153  pop rdi
00007f46e3fd5154  pop rdx
00007f46e3fd5155  pop rcx
00007f46e3fd5156  pop rax
00007f46e3fd5157  add rsp, 0x08
00007f46e3fd515b  jmp 0x00007F46E3FD028B
00007f46e3fd5160  sub rsp, 0x08
00007f46e3fd5164  push rax
00007f46e3fd5165  push rcx
00007f46e3fd5166  push rdx
00007f46e3fd5167  push rdi
00007f46e3fd5168  push rsi
00007f46e3fd5169  push r8
00007f46e3fd516b  push r9
00007f46e3fd516d  push r10
00007f46e3fd516f  push r11
00007f46e3fd5171  sub rsp, 0xF0
00007f46e3fd5178  vmovaps [rsp], xmm0
00007f46e3fd517d  vmovaps [rsp+0x10], xmm1
00007f46e3fd5183  vmovaps [rsp+0x20], xmm2
00007f46e3fd5189  vmovaps [rsp+0x30], xmm3
00007f46e3fd518f  vmovaps [rsp+0x40], xmm4
00007f46e3fd5195  vmovaps [rsp+0x50], xmm5
00007f46e3fd519b  vmovaps [rsp+0x60], xmm6
00007f46e3fd51a1  vmovaps [rsp+0x70], xmm7
00007f46e3fd51a7  vmovaps [rsp+0x80], xmm8
00007f46e3fd51b0  vmovaps [rsp+0x90], xmm9
00007f46e3fd51b9  vmovaps [rsp+0xA0], xmm10
00007f46e3fd51c2  vmovaps [rsp+0xB0], xmm12
00007f46e3fd51cb  vmovaps [rsp+0xC0], xmm13
00007f46e3fd51d4  vmovaps [rsp+0xD0], xmm14
00007f46e3fd51dd  vmovaps [rsp+0xE0], xmm15
00007f46e3fd51e6  sub rsp, 0x30
00007f46e3fd51ea  movaps [rsp], xmm11
00007f46e3fd51ef  movaps [rsp+0x10], xmm12
00007f46e3fd51f5  movaps [rsp+0x20], xmm15
00007f46e3fd51fb  lea rdi, [rsp]
00007f46e3fd51ff  mov esi, 0x00
00007f46e3fd5204  mov rax, 0x6238B185B530
00007f46e3fd520e  call rax
00007f46e3fd5210  movaps xmm11, [rsp]
00007f46e3fd5215  add rsp, 0x30
00007f46e3fd5219  vmovaps xmm0, [rsp]
00007f46e3fd521e  vmovaps xmm1, [rsp+0x10]
00007f46e3fd5224  vmovaps xmm2, [rsp+0x20]
00007f46e3fd522a  vmovaps xmm3, [rsp+0x30]
00007f46e3fd5230  vmovaps xmm4, [rsp+0x40]
00007f46e3fd5236  vmovaps xmm5, [rsp+0x50]
00007f46e3fd523c  vmovaps xmm6, [rsp+0x60]
00007f46e3fd5242  vmovaps xmm7, [rsp+0x70]
00007f46e3fd5248  vmovaps xmm8, [rsp+0x80]
00007f46e3fd5251  vmovaps xmm9, [rsp+0x90]
00007f46e3fd525a  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd5263  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd526c  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd5275  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd527e  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd5287  add rsp, 0xF0
00007f46e3fd528e  pop r11
00007f46e3fd5290  pop r10
00007f46e3fd5292  pop r9
00007f46e3fd5294  pop r8
00007f46e3fd5296  pop rsi
00007f46e3fd5297  pop rdi
00007f46e3fd5298  pop rdx
00007f46e3fd5299  pop rcx
00007f46e3fd529a  pop rax
00007f46e3fd529b  add rsp, 0x08
00007f46e3fd529f  jmp 0x00007F46E3FD02B9
00007f46e3fd52a4  sub rsp, 0x08
00007f46e3fd52a8  push rax
00007f46e3fd52a9  push rcx
00007f46e3fd52aa  push rdx
00007f46e3fd52ab  push rdi
00007f46e3fd52ac  push rsi
00007f46e3fd52ad  push r8
00007f46e3fd52af  push r9
00007f46e3fd52b1  push r10
00007f46e3fd52b3  push r11
00007f46e3fd52b5  sub rsp, 0xF0
00007f46e3fd52bc  vmovaps [rsp], xmm0
00007f46e3fd52c1  vmovaps [rsp+0x10], xmm1
00007f46e3fd52c7  vmovaps [rsp+0x20], xmm2
00007f46e3fd52cd  vmovaps [rsp+0x30], xmm3
00007f46e3fd52d3  vmovaps [rsp+0x40], xmm4
00007f46e3fd52d9  vmovaps [rsp+0x50], xmm5
00007f46e3fd52df  vmovaps [rsp+0x60], xmm6
00007f46e3fd52e5  vmovaps [rsp+0x70], xmm7
00007f46e3fd52eb  vmovaps [rsp+0x80], xmm8
00007f46e3fd52f4  vmovaps [rsp+0x90], xmm9
00007f46e3fd52fd  vmovaps [rsp+0xA0], xmm10
00007f46e3fd5306  vmovaps [rsp+0xB0], xmm11
00007f46e3fd530f  vmovaps [rsp+0xC0], xmm12
00007f46e3fd5318  vmovaps [rsp+0xD0], xmm13
00007f46e3fd5321  vmovaps [rsp+0xE0], xmm14
00007f46e3fd532a  sub rsp, 0x30
00007f46e3fd532e  movaps [rsp], xmm15
00007f46e3fd5333  movaps [rsp+0x10], xmm13
00007f46e3fd5339  movaps [rsp+0x20], xmm9
00007f46e3fd533f  lea rdi, [rsp]
00007f46e3fd5343  mov esi, 0x00
00007f46e3fd5348  mov rax, 0x6238B185B530
00007f46e3fd5352  call rax
00007f46e3fd5354  movaps xmm15, [rsp]
00007f46e3fd5359  add rsp, 0x30
00007f46e3fd535d  vmovaps xmm0, [rsp]
00007f46e3fd5362  vmovaps xmm1, [rsp+0x10]
00007f46e3fd5368  vmovaps xmm2, [rsp+0x20]
00007f46e3fd536e  vmovaps xmm3, [rsp+0x30]
00007f46e3fd5374  vmovaps xmm4, [rsp+0x40]
00007f46e3fd537a  vmovaps xmm5, [rsp+0x50]
00007f46e3fd5380  vmovaps xmm6, [rsp+0x60]
00007f46e3fd5386  vmovaps xmm7, [rsp+0x70]
00007f46e3fd538c  vmovaps xmm8, [rsp+0x80]
00007f46e3fd5395  vmovaps xmm9, [rsp+0x90]
00007f46e3fd539e  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd53a7  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd53b0  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd53b9  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd53c2  vmovaps xmm14, [rsp+0xE0]
00007f46e3fd53cb  add rsp, 0xF0
00007f46e3fd53d2  pop r11
00007f46e3fd53d4  pop r10
00007f46e3fd53d6  pop r9
00007f46e3fd53d8  pop r8
00007f46e3fd53da  pop rsi
00007f46e3fd53db  pop rdi
00007f46e3fd53dc  pop rdx
00007f46e3fd53dd  pop rcx
00007f46e3fd53de  pop rax
00007f46e3fd53df  add rsp, 0x08
00007f46e3fd53e3  jmp 0x00007F46E3FD02D4
00007f46e3fd53e8  sub rsp, 0x08
00007f46e3fd53ec  push rax
00007f46e3fd53ed  push rcx
00007f46e3fd53ee  push rdx
00007f46e3fd53ef  push rdi
00007f46e3fd53f0  push rsi
00007f46e3fd53f1  push r8
00007f46e3fd53f3  push r9
00007f46e3fd53f5  push r10
00007f46e3fd53f7  push r11
00007f46e3fd53f9  sub rsp, 0xF0
00007f46e3fd5400  vmovaps [rsp], xmm0
00007f46e3fd5405  vmovaps [rsp+0x10], xmm1
00007f46e3fd540b  vmovaps [rsp+0x20], xmm2
00007f46e3fd5411  vmovaps [rsp+0x30], xmm3
00007f46e3fd5417  vmovaps [rsp+0x40], xmm4
00007f46e3fd541d  vmovaps [rsp+0x50], xmm5
00007f46e3fd5423  vmovaps [rsp+0x60], xmm6
00007f46e3fd5429  vmovaps [rsp+0x70], xmm7
00007f46e3fd542f  vmovaps [rsp+0x80], xmm8
00007f46e3fd5438  vmovaps [rsp+0x90], xmm9
00007f46e3fd5441  vmovaps [rsp+0xA0], xmm10
00007f46e3fd544a  vmovaps [rsp+0xB0], xmm11
00007f46e3fd5453  vmovaps [rsp+0xC0], xmm12
00007f46e3fd545c  vmovaps [rsp+0xD0], xmm14
00007f46e3fd5465  vmovaps [rsp+0xE0], xmm15
00007f46e3fd546e  sub rsp, 0x30
00007f46e3fd5472  movaps [rsp], xmm13
00007f46e3fd5477  movaps [rsp+0x10], xmm8
00007f46e3fd547d  movaps [rsp+0x20], xmm14
00007f46e3fd5483  lea rdi, [rsp]
00007f46e3fd5487  mov esi, 0x00
00007f46e3fd548c  mov rax, 0x6238B185B530
00007f46e3fd5496  call rax
00007f46e3fd5498  movaps xmm13, [rsp]
00007f46e3fd549d  add rsp, 0x30
00007f46e3fd54a1  vmovaps xmm0, [rsp]
00007f46e3fd54a6  vmovaps xmm1, [rsp+0x10]
00007f46e3fd54ac  vmovaps xmm2, [rsp+0x20]
00007f46e3fd54b2  vmovaps xmm3, [rsp+0x30]
00007f46e3fd54b8  vmovaps xmm4, [rsp+0x40]
00007f46e3fd54be  vmovaps xmm5, [rsp+0x50]
00007f46e3fd54c4  vmovaps xmm6, [rsp+0x60]
00007f46e3fd54ca  vmovaps xmm7, [rsp+0x70]
00007f46e3fd54d0  vmovaps xmm8, [rsp+0x80]
00007f46e3fd54d9  vmovaps xmm9, [rsp+0x90]
00007f46e3fd54e2  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd54eb  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd54f4  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd54fd  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd5506  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd550f  add rsp, 0xF0
00007f46e3fd5516  pop r11
00007f46e3fd5518  pop r10
00007f46e3fd551a  pop r9
00007f46e3fd551c  pop r8
00007f46e3fd551e  pop rsi
00007f46e3fd551f  pop rdi
00007f46e3fd5520  pop rdx
00007f46e3fd5521  pop rcx
00007f46e3fd5522  pop rax
00007f46e3fd5523  add rsp, 0x08
00007f46e3fd5527  jmp 0x00007F46E3FD02F7
00007f46e3fd552c  sub rsp, 0x08
00007f46e3fd5530  push rax
00007f46e3fd5531  push rcx
00007f46e3fd5532  push rdx
00007f46e3fd5533  push rdi
00007f46e3fd5534  push rsi
00007f46e3fd5535  push r8
00007f46e3fd5537  push r9
00007f46e3fd5539  push r10
00007f46e3fd553b  push r11
00007f46e3fd553d  sub rsp, 0xF0
00007f46e3fd5544  vmovaps [rsp], xmm0
00007f46e3fd5549  vmovaps [rsp+0x10], xmm1
00007f46e3fd554f  vmovaps [rsp+0x20], xmm2
00007f46e3fd5555  vmovaps [rsp+0x30], xmm3
00007f46e3fd555b  vmovaps [rsp+0x40], xmm4
00007f46e3fd5561  vmovaps [rsp+0x50], xmm5
00007f46e3fd5567  vmovaps [rsp+0x60], xmm6
00007f46e3fd556d  vmovaps [rsp+0x70], xmm7
00007f46e3fd5573  vmovaps [rsp+0x80], xmm8
00007f46e3fd557c  vmovaps [rsp+0x90], xmm9
00007f46e3fd5585  vmovaps [rsp+0xA0], xmm10
00007f46e3fd558e  vmovaps [rsp+0xB0], xmm11
00007f46e3fd5597  vmovaps [rsp+0xC0], xmm12
00007f46e3fd55a0  vmovaps [rsp+0xD0], xmm13
00007f46e3fd55a9  vmovaps [rsp+0xE0], xmm15
00007f46e3fd55b2  sub rsp, 0x30
00007f46e3fd55b6  movaps [rsp], xmm14
00007f46e3fd55bb  movaps [rsp+0x10], xmm1
00007f46e3fd55c0  movaps [rsp+0x20], xmm10
00007f46e3fd55c6  lea rdi, [rsp]
00007f46e3fd55ca  mov esi, 0x00
00007f46e3fd55cf  mov rax, 0x6238B185B530
00007f46e3fd55d9  call rax
00007f46e3fd55db  movaps xmm14, [rsp]
00007f46e3fd55e0  add rsp, 0x30
00007f46e3fd55e4  vmovaps xmm0, [rsp]
00007f46e3fd55e9  vmovaps xmm1, [rsp+0x10]
00007f46e3fd55ef  vmovaps xmm2, [rsp+0x20]
00007f46e3fd55f5  vmovaps xmm3, [rsp+0x30]
00007f46e3fd55fb  vmovaps xmm4, [rsp+0x40]
00007f46e3fd5601  vmovaps xmm5, [rsp+0x50]
00007f46e3fd5607  vmovaps xmm6, [rsp+0x60]
00007f46e3fd560d  vmovaps xmm7, [rsp+0x70]
00007f46e3fd5613  vmovaps xmm8, [rsp+0x80]
00007f46e3fd561c  vmovaps xmm9, [rsp+0x90]
00007f46e3fd5625  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd562e  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd5637  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd5640  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd5649  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd5652  add rsp, 0xF0
00007f46e3fd5659  pop r11
00007f46e3fd565b  pop r10
00007f46e3fd565d  pop r9
00007f46e3fd565f  pop r8
00007f46e3fd5661  pop rsi
00007f46e3fd5662  pop rdi
00007f46e3fd5663  pop rdx
00007f46e3fd5664  pop rcx
00007f46e3fd5665  pop rax
00007f46e3fd5666  add rsp, 0x08
00007f46e3fd566a  jmp 0x00007F46E3FD031A
00007f46e3fd566f  sub rsp, 0x08
00007f46e3fd5673  push rax
00007f46e3fd5674  push rcx
00007f46e3fd5675  push rdx
00007f46e3fd5676  push rdi
00007f46e3fd5677  push rsi
00007f46e3fd5678  push r8
00007f46e3fd567a  push r9
00007f46e3fd567c  push r10
00007f46e3fd567e  push r11
00007f46e3fd5680  sub rsp, 0xF0
00007f46e3fd5687  vmovaps [rsp], xmm0
00007f46e3fd568c  vmovaps [rsp+0x10], xmm2
00007f46e3fd5692  vmovaps [rsp+0x20], xmm3
00007f46e3fd5698  vmovaps [rsp+0x30], xmm4
00007f46e3fd569e  vmovaps [rsp+0x40], xmm5
00007f46e3fd56a4  vmovaps [rsp+0x50], xmm6
00007f46e3fd56aa  vmovaps [rsp+0x60], xmm7
00007f46e3fd56b0  vmovaps [rsp+0x70], xmm8
00007f46e3fd56b6  vmovaps [rsp+0x80], xmm9
00007f46e3fd56bf  vmovaps [rsp+0x90], xmm10
00007f46e3fd56c8  vmovaps [rsp+0xA0], xmm11
00007f46e3fd56d1  vmovaps [rsp+0xB0], xmm12
00007f46e3fd56da  vmovaps [rsp+0xC0], xmm13
00007f46e3fd56e3  vmovaps [rsp+0xD0], xmm14
00007f46e3fd56ec  vmovaps [rsp+0xE0], xmm15
00007f46e3fd56f5  sub rsp, 0x30
00007f46e3fd56f9  movaps [rsp], xmm1
00007f46e3fd56fd  movaps [rsp+0x10], xmm7
00007f46e3fd5702  movaps [rsp+0x20], xmm11
00007f46e3fd5708  lea rdi, [rsp]
00007f46e3fd570c  mov esi, 0x00
00007f46e3fd5711  mov rax, 0x6238B185B530
00007f46e3fd571b  call rax
00007f46e3fd571d  movaps xmm1, [rsp]
00007f46e3fd5721  add rsp, 0x30
00007f46e3fd5725  vmovaps xmm0, [rsp]
00007f46e3fd572a  vmovaps xmm2, [rsp+0x10]
00007f46e3fd5730  vmovaps xmm3, [rsp+0x20]
00007f46e3fd5736  vmovaps xmm4, [rsp+0x30]
00007f46e3fd573c  vmovaps xmm5, [rsp+0x40]
00007f46e3fd5742  vmovaps xmm6, [rsp+0x50]
00007f46e3fd5748  vmovaps xmm7, [rsp+0x60]
00007f46e3fd574e  vmovaps xmm8, [rsp+0x70]
00007f46e3fd5754  vmovaps xmm9, [rsp+0x80]
00007f46e3fd575d  vmovaps xmm10, [rsp+0x90]
00007f46e3fd5766  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd576f  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd5778  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd5781  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd578a  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd5793  add rsp, 0xF0
00007f46e3fd579a  pop r11
00007f46e3fd579c  pop r10
00007f46e3fd579e  pop r9
00007f46e3fd57a0  pop r8
00007f46e3fd57a2  pop rsi
00007f46e3fd57a3  pop rdi
00007f46e3fd57a4  pop rdx
00007f46e3fd57a5  pop rcx
00007f46e3fd57a6  pop rax
00007f46e3fd57a7  add rsp, 0x08
00007f46e3fd57ab  jmp 0x00007F46E3FD033B
00007f46e3fd57b0  call 0x00007F46E3E0E880
00007f46e3fd57b5  jmp 0x00007F46E3FD034E
00007f46e3fd57ba  call 0x00007F46E3E0C380
00007f46e3fd57bf  jmp 0x00007F46E3FD0359
00007f46e3fd57c4  call 0x00007F46E3E0D600
00007f46e3fd57c9  jmp 0x00007F46E3FD0364
00007f46e3fd57ce  call 0x00007F46E3DFF540
00007f46e3fd57d3  jmp 0x00007F46E3FD036F
00007f46e3fd57d8  int3
00007f46e3fd57d9  nop [rax], eax
00007f46e3fd57e0  mov rax, [r15+0x40]
00007f46e3fd57e4  mov r14, [r15+0x58]
00007f46e3fd57e8  lea r12, [rax+r14*1]
00007f46e3fd57ec  movaps xmm1, [r15+0x1D0]
00007f46e3fd57f4  vmovaps [rsp+0x10], xmm1
00007f46e3fd57fa  vmovaps xmm15, [rsp+0x10]
00007f46e3fd5800  por xmm1, xmm15
00007f46e3fd5805  movaps xmm14, [r15+0x1A0]
00007f46e3fd580d  vmovaps [rsp+0x10], xmm14
00007f46e3fd5813  vmovaps xmm13, [rsp+0x10]
00007f46e3fd5819  por xmm14, xmm13
00007f46e3fd581e  lea rax, [r12+0x30]
00007f46e3fd5823  mov r11, [r13+rax*1]
00007f46e3fd5828  lea rax, [r12+0x38]
00007f46e3fd582d  mov r10, [r13+rax*1]
00007f46e3fd5832  movq xmm13, r11
00007f46e3fd5837  movq xmm12, r10
00007f46e3fd583c  movq xmm13, xmm13
00007f46e3fd5841  vmovaps [rsp+0x10], xmm13
00007f46e3fd5847  movq xmm13, xmm13
00007f46e3fd584c  movaps [r15+0x130], xmm13
00007f46e3fd5854  movq xmm12, xmm12
00007f46e3fd5859  vmovaps [rsp+0x20], xmm12
00007f46e3fd585f  movq xmm12, xmm12
00007f46e3fd5864  movaps [r15+0x280], xmm12
00007f46e3fd586c  movaps xmm13, [r15+0x270]
00007f46e3fd5874  vmovaps [rsp+0x30], xmm13
00007f46e3fd587a  vmovaps xmm12, [rsp+0x30]
00007f46e3fd5880  por xmm13, xmm12
00007f46e3fd5885  lea rax, [r12+0x20]
00007f46e3fd588a  mov r11, [r13+rax*1]
00007f46e3fd588f  lea rax, [r12+0x28]
00007f46e3fd5894  mov r10, [r13+rax*1]
00007f46e3fd5899  movq xmm12, r11
00007f46e3fd589e  movq xmm11, r10
00007f46e3fd58a3  movq xmm12, xmm12
00007f46e3fd58a8  vmovaps [rsp+0x30], xmm12
00007f46e3fd58ae  movq xmm12, xmm12
00007f46e3fd58b3  movaps [r15+0x150], xmm12
00007f46e3fd58bb  movq xmm11, xmm11
00007f46e3fd58c0  vmovaps [rsp+0x40], xmm11
00007f46e3fd58c6  movq xmm11, xmm11
00007f46e3fd58cb  movaps [r15+0x140], xmm11
00007f46e3fd58d3  lea rax, [r12+0x10]
00007f46e3fd58d8  mov r11, [r13+rax*1]
00007f46e3fd58dd  lea rax, [r12+0x18]
00007f46e3fd58e2  mov r10, [r13+rax*1]
00007f46e3fd58e7  movq xmm12, r11
00007f46e3fd58ec  movq xmm11, r10
00007f46e3fd58f1  movq xmm12, xmm12
00007f46e3fd58f6  vmovaps [rsp+0x50], xmm12
00007f46e3fd58fc  movq xmm12, xmm12
00007f46e3fd5901  movaps [r15+0x170], xmm12
00007f46e3fd5909  movq xmm11, xmm11
00007f46e3fd590e  vmovaps [rsp+0x60], xmm11
00007f46e3fd5914  movq xmm11, xmm11
00007f46e3fd5919  movaps [r15+0x160], xmm11
00007f46e3fd5921  mov rax, [r13+r12*1]
00007f46e3fd5926  vmovq xmm12, rax
00007f46e3fd592b  vpbroadcastq xmm12, xmm12
00007f46e3fd5930  lea rax, [r12+0x08]
00007f46e3fd5935  mov r12, [r13+rax*1]
00007f46e3fd593a  movq xmm11, r12
00007f46e3fd593f  movaps [r15+0x230], xmm11
00007f46e3fd5947  mov rax, [r15+0xF8]
00007f46e3fd594e  lea r12, [rax+0x50]
00007f46e3fd5952  movups xmm11, [r13+r12*1]
00007f46e3fd5958  lea r12, [rax+0x60]
00007f46e3fd595c  movups xmm10, [r13+r12*1]
00007f46e3fd5962  lea r12, [rax+0x30]
00007f46e3fd5966  movups xmm9, [r13+r12*1]
00007f46e3fd596c  mov r12, [r15+0x50]
00007f46e3fd5970  lea r11, [r12+r14*1]
00007f46e3fd5974  mov [r15+0x60], r11
00007f46e3fd5978  lea r12, [r14+0x40]
00007f46e3fd597c  mov [r15+0x58], r12
00007f46e3fd5980  movaps xmm8, xmm12
00007f46e3fd5984  mulpd xmm8, xmm15
00007f46e3fd5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007f46e3fd598f  ptest xmm7, xmm7
00007f46e3fd5994  jnz 0x00007F46E3FD67B7
00007f46e3fd599a  movq xmm15, qword ptr [r15+0x230]
00007f46e3fd59a3  vmovaps [rsp+0x70], xmm15
00007f46e3fd59a9  vpermilpd xmm15, xmm15, 0x00
00007f46e3fd59af  movaps xmm7, xmm9
00007f46e3fd59b3  mulpd xmm7, xmm15
00007f46e3fd59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007f46e3fd59bd  ptest xmm6, xmm6
00007f46e3fd59c2  jnz 0x00007F46E3FD68FB
00007f46e3fd59c8  vxorps xmm15, xmm15, xmm15
00007f46e3fd59cd  vpbroadcastq xmm15, xmm15
00007f46e3fd59d2  movaps xmm9, xmm12
00007f46e3fd59d6  mulpd xmm9, xmm10
00007f46e3fd59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007f46e3fd59e1  ptest xmm6, xmm6
00007f46e3fd59e6  jnz 0x00007F46E3FD6A3D
00007f46e3fd59ec  movaps xmm10, xmm12
00007f46e3fd59f0  mulpd xmm10, xmm11
00007f46e3fd59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007f46e3fd59fb  ptest xmm6, xmm6
00007f46e3fd5a00  jnz 0x00007F46E3FD6B81
00007f46e3fd5a06  movaps xmm11, [r15+0x1F0]
00007f46e3fd5a0e  movaps xmm6, xmm12
00007f46e3fd5a12  mulpd xmm6, xmm11
00007f46e3fd5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007f46e3fd5a1c  ptest xmm5, xmm5
00007f46e3fd5a21  jnz 0x00007F46E3FD6CC5
00007f46e3fd5a27  movaps xmm12, [r15+0x2A0]
00007f46e3fd5a2f  vmovaps [rsp+0x80], xmm12
00007f46e3fd5a38  vmovaps xmm11, [rsp+0x80]
00007f46e3fd5a41  por xmm12, xmm11
00007f46e3fd5a46  movaps xmm11, [r15+0x250]
00007f46e3fd5a4e  vmovaps [rsp+0x80], xmm11
00007f46e3fd5a57  vmovaps xmm5, [rsp+0x80]
00007f46e3fd5a60  por xmm11, xmm5
00007f46e3fd5a65  vmovaps xmm4, [rsp+0x70]
00007f46e3fd5a6b  vpermilpd xmm4, xmm4, 0x00
00007f46e3fd5a71  movaps xmm3, xmm5
00007f46e3fd5a74  mulpd xmm3, xmm4
00007f46e3fd5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007f46e3fd5a7d  ptest xmm2, xmm2
00007f46e3fd5a82  jnz 0x00007F46E3FD6E07
00007f46e3fd5a88  mov [rsp+0x80], rax
00007f46e3fd5a90  xor eax, eax
00007f46e3fd5a92  mov r14d, 0x200
00007f46e3fd5a98  cmp r12, r14
00007f46e3fd5a9b  cmc
00007f46e3fd5a9c  lahf
00007f46e3fd5a9d  seto al
00007f46e3fd5aa0  mov [r15+0x108], eax
00007f46e3fd5aa7  movaps xmm5, xmm8
00007f46e3fd5aab  addpd xmm5, xmm15
00007f46e3fd5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007f46e3fd5ab5  ptest xmm4, xmm4
00007f46e3fd5aba  jnz 0x00007F46E3FD6F47
00007f46e3fd5ac0  movaps xmm8, [r15+0x1B0]
00007f46e3fd5ac8  movaps xmm4, xmm9
00007f46e3fd5acc  addpd xmm4, xmm8
00007f46e3fd5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007f46e3fd5ad6  ptest xmm2, xmm2
00007f46e3fd5adb  jnz 0x00007F46E3FD7089
00007f46e3fd5ae1  movaps xmm9, xmm10
00007f46e3fd5ae5  addpd xmm9, xmm8
00007f46e3fd5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007f46e3fd5af0  ptest xmm2, xmm2
00007f46e3fd5af5  jnz 0x00007F46E3FD71CB
00007f46e3fd5afb  movaps xmm10, [r15+0x2F0]
00007f46e3fd5b03  vmovaps [rsp+0x90], xmm10
00007f46e3fd5b0c  vmovaps xmm8, [rsp+0x90]
00007f46e3fd5b15  por xmm10, xmm8
00007f46e3fd5b1a  movaps xmm8, [r15+0x2E0]
00007f46e3fd5b22  vmovaps [rsp+0x90], xmm8
00007f46e3fd5b2b  vmovaps xmm2, [rsp+0x90]
00007f46e3fd5b34  por xmm8, xmm2
00007f46e3fd5b39  movaps xmm2, [r15+0x2D0]
00007f46e3fd5b41  vmovaps [rsp+0x90], xmm2
00007f46e3fd5b4a  vmovaps [rsp+0xA0], xmm1
00007f46e3fd5b53  vmovaps xmm1, [rsp+0x90]
00007f46e3fd5b5c  por xmm2, xmm1
00007f46e3fd5b60  movaps xmm1, [r15+0x200]
00007f46e3fd5b68  vmovaps [rsp+0x90], xmm1
00007f46e3fd5b71  vmovaps [rsp+0xB0], xmm15
00007f46e3fd5b7a  vmovaps xmm15, [rsp+0x90]
00007f46e3fd5b83  por xmm1, xmm15
00007f46e3fd5b88  movaps xmm15, [r15+0x1C0]
00007f46e3fd5b90  vmovaps [rsp+0x90], xmm15
00007f46e3fd5b99  vmovaps [rsp+0xC0], xmm1
00007f46e3fd5ba2  vmovaps xmm1, [rsp+0x90]
00007f46e3fd5bab  por xmm15, xmm1
00007f46e3fd5bb0  movaps xmm1, [r15+0x190]
00007f46e3fd5bb8  vmovaps [rsp+0x90], xmm1
00007f46e3fd5bc1  vmovaps [rsp+0xD0], xmm15
00007f46e3fd5bca  vmovaps xmm15, [rsp+0x90]
00007f46e3fd5bd3  por xmm1, xmm15
00007f46e3fd5bd8  movaps xmm15, [r15+0x300]
00007f46e3fd5be0  vmovaps [rsp+0x90], xmm15
00007f46e3fd5be9  vmovaps [rsp+0xE0], xmm1
00007f46e3fd5bf2  vmovaps xmm1, [rsp+0x90]
00007f46e3fd5bfb  por xmm15, xmm1
00007f46e3fd5c00  mov rax, [rsp+0x80]
00007f46e3fd5c08  lea r14, [rax+0xA0]
00007f46e3fd5c0f  movups xmm1, [r13+r14*1]
00007f46e3fd5c15  lea r14, [rax+0xB0]
00007f46e3fd5c1c  vmovaps [rsp+0x80], xmm1
00007f46e3fd5c25  movups xmm1, [r13+r14*1]
00007f46e3fd5c2b  vmovaps [rsp+0x90], xmm1
00007f46e3fd5c34  vmovaps [rsp+0xF0], xmm15
00007f46e3fd5c3d  vmovaps xmm15, [rsp+0xB0]
00007f46e3fd5c46  vmovaps [rsp+0xB0], xmm14
00007f46e3fd5c4f  movaps xmm1, xmm6
00007f46e3fd5c52  addpd xmm1, xmm15
00007f46e3fd5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007f46e3fd5c5c  ptest xmm14, xmm14
00007f46e3fd5c62  jnz 0x00007F46E3FD7323
00007f46e3fd5c68  lea r14, [rax+0xF0]
00007f46e3fd5c6f  movups xmm15, [r13+r14*1]
00007f46e3fd5c75  movaps xmm14, xmm4
00007f46e3fd5c79  addpd xmm14, xmm3
00007f46e3fd5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007f46e3fd5c84  ptest xmm6, xmm6
00007f46e3fd5c89  jnz 0x00007F46E3FD746E
00007f46e3fd5c8f  movaps xmm6, xmm9
00007f46e3fd5c93  addpd xmm6, xmm7
00007f46e3fd5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007f46e3fd5c9c  ptest xmm4, xmm4
00007f46e3fd5ca1  jnz 0x00007F46E3FD75B0
00007f46e3fd5ca7  vmovaps xmm9, [rsp+0x70]
00007f46e3fd5cad  vpermilpd xmm9, xmm9, 0x00
00007f46e3fd5cb3  vmovaps xmm4, [rsp+0x90]
00007f46e3fd5cbc  movaps xmm7, xmm4
00007f46e3fd5cbf  mulpd xmm7, xmm9
00007f46e3fd5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007f46e3fd5cc9  ptest xmm3, xmm3
00007f46e3fd5cce  jnz 0x00007F46E3FD76F1
00007f46e3fd5cd4  vmovaps xmm9, [rsp+0x50]
00007f46e3fd5cda  vpermilpd xmm9, xmm9, 0x00
00007f46e3fd5ce0  movaps xmm4, xmm15
00007f46e3fd5ce4  mulpd xmm4, xmm9
00007f46e3fd5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007f46e3fd5cee  ptest xmm3, xmm3
00007f46e3fd5cf3  jnz 0x00007F46E3FD7832
00007f46e3fd5cf9  lea r14, [rax+0xE0]
00007f46e3fd5d00  movups xmm15, [r13+r14*1]
00007f46e3fd5d06  vmovaps xmm9, [rsp+0x70]
00007f46e3fd5d0c  vpermilpd xmm9, xmm9, 0x00
00007f46e3fd5d12  vmovaps [rsp+0x70], xmm1
00007f46e3fd5d18  vmovaps xmm1, [rsp+0x80]
00007f46e3fd5d21  vmovaps [rsp+0x80], xmm15
00007f46e3fd5d2a  movaps xmm3, xmm1
00007f46e3fd5d2d  mulpd xmm3, xmm9
00007f46e3fd5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007f46e3fd5d37  ptest xmm15, xmm15
00007f46e3fd5d3d  jnz 0x00007F46E3FD797E
00007f46e3fd5d43  vmovaps xmm1, [rsp+0xF0]
00007f46e3fd5d4c  vmovaps xmm15, [rsp+0xF0]
00007f46e3fd5d55  por xmm1, xmm15
00007f46e3fd5d5a  movaps [r15+0x300], xmm1
00007f46e3fd5d62  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd5d6b  vmovaps xmm9, [rsp+0xE0]
00007f46e3fd5d74  por xmm15, xmm9
00007f46e3fd5d79  movaps [r15+0x190], xmm15
00007f46e3fd5d81  vmovaps xmm9, [rsp+0x50]
00007f46e3fd5d87  vpermilpd xmm9, xmm9, 0x00
00007f46e3fd5d8d  vmovaps [rsp+0x90], xmm1
00007f46e3fd5d96  vmovaps [rsp+0xE0], xmm15
00007f46e3fd5d9f  vmovaps xmm15, [rsp+0x80]
00007f46e3fd5da8  vmovaps [rsp+0x80], xmm14
00007f46e3fd5db1  movaps xmm1, xmm15
00007f46e3fd5db5  mulpd xmm1, xmm9
00007f46e3fd5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007f46e3fd5dbf  ptest xmm14, xmm14
00007f46e3fd5dc5  jnz 0x00007F46E3FD7ABF
00007f46e3fd5dcb  lea r14, [rax+0x90]
00007f46e3fd5dd2  movups xmm15, [r13+r14*1]
00007f46e3fd5dd8  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd5de1  vmovaps xmm9, [rsp+0xD0]
00007f46e3fd5dea  por xmm14, xmm9
00007f46e3fd5def  movaps [r15+0x1C0], xmm14
00007f46e3fd5df7  vmovaps xmm9, [rsp+0xC0]
00007f46e3fd5e00  vmovaps [rsp+0xD0], xmm1
00007f46e3fd5e09  vmovaps xmm1, [rsp+0xC0]
00007f46e3fd5e12  por xmm9, xmm1
00007f46e3fd5e17  movaps [r15+0x200], xmm9
00007f46e3fd5e1f  vmovaps [rsp+0xC0], xmm2
00007f46e3fd5e28  vmovaps xmm1, [rsp+0xC0]
00007f46e3fd5e31  por xmm2, xmm1
00007f46e3fd5e35  movaps [r15+0x2D0], xmm2
00007f46e3fd5e3d  vmovaps [rsp+0xC0], xmm8
00007f46e3fd5e46  vmovaps xmm1, [rsp+0xC0]
00007f46e3fd5e4f  por xmm8, xmm1
00007f46e3fd5e54  movaps [r15+0x2E0], xmm8
00007f46e3fd5e5c  vmovaps [rsp+0xC0], xmm15
00007f46e3fd5e65  movaps xmm1, xmm5
00007f46e3fd5e68  addpd xmm1, xmm7
00007f46e3fd5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007f46e3fd5e71  ptest xmm15, xmm15
00007f46e3fd5e77  jnz 0x00007F46E3FD7C0B
00007f46e3fd5e7d  vmovaps xmm15, [rsp+0x50]
00007f46e3fd5e83  vpermilpd xmm15, xmm15, 0x00
00007f46e3fd5e89  vmovaps xmm5, [rsp+0xC0]
00007f46e3fd5e92  vmovaps [rsp+0xC0], xmm1
00007f46e3fd5e9b  movaps xmm7, xmm5
00007f46e3fd5e9e  mulpd xmm7, xmm15
00007f46e3fd5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007f46e3fd5ea8  ptest xmm1, xmm1
00007f46e3fd5ead  jnz 0x00007F46E3FD7D4B
00007f46e3fd5eb3  lea r14, [rax+0x80]
00007f46e3fd5eba  movups xmm1, [r13+r14*1]
00007f46e3fd5ec0  vmovaps xmm5, [rsp+0x70]
00007f46e3fd5ec6  vmovaps [rsp+0x70], xmm1
00007f46e3fd5ecc  movaps xmm15, xmm5
00007f46e3fd5ed0  addpd xmm15, xmm3
00007f46e3fd5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007f46e3fd5edb  ptest xmm1, xmm1
00007f46e3fd5ee0  jnz 0x00007F46E3FD7E96
00007f46e3fd5ee6  vmovaps xmm5, [rsp+0x80]
00007f46e3fd5eef  movaps xmm1, xmm5
00007f46e3fd5ef2  addpd xmm1, xmm4
00007f46e3fd5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007f46e3fd5efb  ptest xmm3, xmm3
00007f46e3fd5f00  jnz 0x00007F46E3FD7FD8
00007f46e3fd5f06  vmovaps [rsp+0x80], xmm10
00007f46e3fd5f0f  vmovaps xmm5, [rsp+0x80]
00007f46e3fd5f18  por xmm10, xmm5
00007f46e3fd5f1d  movaps [r15+0x2F0], xmm10
00007f46e3fd5f25  vmovaps xmm5, [rsp+0x50]
00007f46e3fd5f2b  vpermilpd xmm5, xmm5, 0x00
00007f46e3fd5f31  vmovaps xmm3, [rsp+0x70]
00007f46e3fd5f37  vmovaps [rsp+0x50], xmm1
00007f46e3fd5f3d  movaps xmm4, xmm3
00007f46e3fd5f40  mulpd xmm4, xmm5
00007f46e3fd5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007f46e3fd5f49  ptest xmm1, xmm1
00007f46e3fd5f4e  jnz 0x00007F46E3FD8118
00007f46e3fd5f54  lea r14, [rax+0xD0]
00007f46e3fd5f5b  movups xmm1, [r13+r14*1]
00007f46e3fd5f61  vmovaps xmm3, [rsp+0xD0]
00007f46e3fd5f6a  vmovaps [rsp+0x70], xmm1
00007f46e3fd5f70  movaps xmm5, xmm6
00007f46e3fd5f73  addpd xmm5, xmm3
00007f46e3fd5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007f46e3fd5f7c  ptest xmm1, xmm1
00007f46e3fd5f81  jnz 0x00007F46E3FD8262
00007f46e3fd5f87  vmovaps xmm1, [rsp+0x60]
00007f46e3fd5f8d  vpermilpd xmm1, xmm1, 0x00
00007f46e3fd5f93  movaps xmm6, xmm9
00007f46e3fd5f97  mulpd xmm6, xmm1
00007f46e3fd5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007f46e3fd5fa0  ptest xmm3, xmm3
00007f46e3fd5fa5  jnz 0x00007F46E3FD83A2
00007f46e3fd5fab  movaps [r15+0x260], xmm6
00007f46e3fd5fb3  vxorps xmm1, xmm1, xmm1
00007f46e3fd5fb7  vpbroadcastq xmm1, xmm1
00007f46e3fd5fbc  movaps [r15+0x1B0], xmm1
00007f46e3fd5fc4  vmovaps xmm1, [rsp+0x60]
00007f46e3fd5fca  vpermilpd xmm1, xmm1, 0x00
00007f46e3fd5fd0  vmovaps xmm3, [rsp+0x70]
00007f46e3fd5fd6  vmovaps [rsp+0x70], xmm15
00007f46e3fd5fdc  movaps xmm9, xmm3
00007f46e3fd5fe0  mulpd xmm9, xmm1
00007f46e3fd5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007f46e3fd5feb  ptest xmm15, xmm15
00007f46e3fd5ff1  jnz 0x00007F46E3FD84E3
00007f46e3fd5ff7  lea r14, [rax+0xC0]
00007f46e3fd5ffe  movups xmm1, [r13+r14*1]
00007f46e3fd6004  vmovaps xmm3, [rsp+0xC0]
00007f46e3fd600d  vmovaps [rsp+0x80], xmm1
00007f46e3fd6016  movaps xmm15, xmm3
00007f46e3fd601a  addpd xmm15, xmm7
00007f46e3fd601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007f46e3fd6025  ptest xmm1, xmm1
00007f46e3fd602a  jnz 0x00007F46E3FD862F
00007f46e3fd6030  vmovaps [rsp+0xC0], xmm13
00007f46e3fd6039  vmovaps xmm1, [rsp+0xC0]
00007f46e3fd6042  por xmm13, xmm1
00007f46e3fd6047  movaps [r15+0x270], xmm13
00007f46e3fd604f  vmovaps xmm1, [rsp+0xB0]
00007f46e3fd6058  vmovaps xmm7, [rsp+0xB0]
00007f46e3fd6061  por xmm1, xmm7
00007f46e3fd6065  movaps [r15+0x1A0], xmm1
00007f46e3fd606d  vmovaps xmm1, [rsp+0x60]
00007f46e3fd6073  vpermilpd xmm1, xmm1, 0x00
00007f46e3fd6079  vmovaps [rsp+0xB0], xmm1
00007f46e3fd6082  vmovaps xmm1, [rsp+0x80]
00007f46e3fd608b  vmovaps [rsp+0x80], xmm15
00007f46e3fd6094  vmovaps xmm15, [rsp+0xB0]
00007f46e3fd609d  vmovaps [rsp+0xB0], xmm14
00007f46e3fd60a6  movaps xmm3, xmm1
00007f46e3fd60a9  mulpd xmm3, xmm15
00007f46e3fd60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007f46e3fd60b3  ptest xmm14, xmm14
00007f46e3fd60b9  jnz 0x00007F46E3FD8771
00007f46e3fd60bf  lea r14, [rax+0x20]
00007f46e3fd60c3  movups xmm1, [r13+r14*1]
00007f46e3fd60c9  movaps [r15+0x110], xmm1
00007f46e3fd60d1  vmovaps xmm14, [rsp+0x70]
00007f46e3fd60d7  vmovaps [rsp+0x70], xmm1
00007f46e3fd60dd  movaps xmm15, xmm14
00007f46e3fd60e1  addpd xmm15, xmm4
00007f46e3fd60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007f46e3fd60ec  ptest xmm1, xmm1
00007f46e3fd60f1  jnz 0x00007F46E3FD88BC
00007f46e3fd60f7  vmovaps xmm1, [rsp+0x60]
00007f46e3fd60fd  vpermilpd xmm1, xmm1, 0x00
00007f46e3fd6103  movaps xmm14, xmm2
00007f46e3fd6107  mulpd xmm14, xmm1
00007f46e3fd610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007f46e3fd6112  ptest xmm4, xmm4
00007f46e3fd6117  jnz 0x00007F46E3FD89FF
00007f46e3fd611d  vmovaps xmm4, [rsp+0x50]
00007f46e3fd6123  movaps xmm1, xmm4
00007f46e3fd6126  addpd xmm1, xmm9
00007f46e3fd612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007f46e3fd6130  ptest xmm2, xmm2
00007f46e3fd6135  jnz 0x00007F46E3FD8B41
00007f46e3fd613b  vmovaps xmm9, [rsp+0x30]
00007f46e3fd6141  vpermilpd xmm9, xmm9, 0x00
00007f46e3fd6147  vmovaps xmm2, [rsp+0x70]
00007f46e3fd614d  vmovaps [rsp+0x50], xmm1
00007f46e3fd6153  movaps xmm4, xmm2
00007f46e3fd6156  mulpd xmm4, xmm9
00007f46e3fd615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007f46e3fd6160  ptest xmm1, xmm1
00007f46e3fd6165  jnz 0x00007F46E3FD8C82
00007f46e3fd616b  vmovaps xmm1, [rsp+0x30]
00007f46e3fd6171  vpermilpd xmm1, xmm1, 0x00
00007f46e3fd6177  vmovaps xmm2, [rsp+0x90]
00007f46e3fd6180  vmovaps [rsp+0x60], xmm15
00007f46e3fd6186  movaps xmm9, xmm2
00007f46e3fd618a  mulpd xmm9, xmm1
00007f46e3fd618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007f46e3fd6195  ptest xmm15, xmm15
00007f46e3fd619b  jnz 0x00007F46E3FD8DC3
00007f46e3fd61a1  vmovaps xmm15, [rsp+0x80]
00007f46e3fd61aa  movaps xmm1, xmm15
00007f46e3fd61ae  addpd xmm1, xmm6
00007f46e3fd61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007f46e3fd61b7  ptest xmm2, xmm2
00007f46e3fd61bc  jnz 0x00007F46E3FD8F05
00007f46e3fd61c2  movaps xmm15, xmm5
00007f46e3fd61c6  addpd xmm15, xmm3
00007f46e3fd61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007f46e3fd61d1  ptest xmm6, xmm6
00007f46e3fd61d6  jnz 0x00007F46E3FD9046
00007f46e3fd61dc  vmovaps xmm6, [rsp+0x30]
00007f46e3fd61e2  vpermilpd xmm6, xmm6, 0x00
00007f46e3fd61e8  movaps xmm5, xmm8
00007f46e3fd61ec  mulpd xmm5, xmm6
00007f46e3fd61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007f46e3fd61f5  ptest xmm3, xmm3
00007f46e3fd61fa  jnz 0x00007F46E3FD9188
00007f46e3fd6200  vmovaps xmm8, [rsp+0x30]
00007f46e3fd6206  vpermilpd xmm8, xmm8, 0x00
00007f46e3fd620c  movaps xmm6, xmm10
00007f46e3fd6210  mulpd xmm6, xmm8
00007f46e3fd6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007f46e3fd621a  ptest xmm3, xmm3
00007f46e3fd621f  jnz 0x00007F46E3FD92C9
00007f46e3fd6225  vmovaps xmm8, [rsp+0x60]
00007f46e3fd622b  movaps xmm10, xmm8
00007f46e3fd622f  addpd xmm10, xmm14
00007f46e3fd6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007f46e3fd623a  ptest xmm3, xmm3
00007f46e3fd623f  jnz 0x00007F46E3FD940B
00007f46e3fd6245  vmovaps xmm8, [rsp+0x50]
00007f46e3fd624b  movaps xmm14, xmm8
00007f46e3fd624f  addpd xmm14, xmm4
00007f46e3fd6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007f46e3fd625a  ptest xmm3, xmm3
00007f46e3fd625f  jnz 0x00007F46E3FD954F
00007f46e3fd6265  vmovaps xmm8, [rsp+0x40]
00007f46e3fd626b  vpermilpd xmm8, xmm8, 0x00
00007f46e3fd6271  movaps xmm4, xmm13
00007f46e3fd6275  mulpd xmm4, xmm8
00007f46e3fd627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007f46e3fd627f  ptest xmm3, xmm3
00007f46e3fd6284  jnz 0x00007F46E3FD9692
00007f46e3fd628a  movaps xmm13, xmm15
00007f46e3fd628e  addpd xmm13, xmm9
00007f46e3fd6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007f46e3fd6299  ptest xmm8, xmm8
00007f46e3fd629f  jnz 0x00007F46E3FD97D4
00007f46e3fd62a5  movaps xmm15, xmm1
00007f46e3fd62a9  addpd xmm15, xmm5
00007f46e3fd62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007f46e3fd62b4  ptest xmm9, xmm9
00007f46e3fd62ba  jnz 0x00007F46E3FD9918
00007f46e3fd62c0  vmovaps [rsp+0x30], xmm11
00007f46e3fd62c6  vmovaps xmm1, [rsp+0x30]
00007f46e3fd62cc  por xmm11, xmm1
00007f46e3fd62d1  movaps [r15+0x250], xmm11
00007f46e3fd62d9  vmovaps [rsp+0x30], xmm12
00007f46e3fd62df  vmovaps xmm1, [rsp+0x30]
00007f46e3fd62e5  por xmm12, xmm1
00007f46e3fd62ea  movaps [r15+0x2A0], xmm12
00007f46e3fd62f2  vmovaps xmm1, [rsp+0xA0]
00007f46e3fd62fb  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd6304  por xmm1, xmm11
00007f46e3fd6309  movaps [r15+0x1D0], xmm1
00007f46e3fd6311  lea r14, [rax+0x40]
00007f46e3fd6315  movups xmm1, [r13+r14*1]
00007f46e3fd631b  movaps [r15+0x2C0], xmm1
00007f46e3fd6323  vmovaps xmm11, [rsp+0x40]
00007f46e3fd6329  vpermilpd xmm11, xmm11, 0x00
00007f46e3fd632f  vmovaps xmm8, [rsp+0xE0]
00007f46e3fd6338  movaps xmm9, xmm8
00007f46e3fd633c  mulpd xmm9, xmm11
00007f46e3fd6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007f46e3fd6347  ptest xmm5, xmm5
00007f46e3fd634c  jnz 0x00007F46E3FD9A64
00007f46e3fd6352  movaps xmm11, xmm10
00007f46e3fd6356  addpd xmm11, xmm6
00007f46e3fd635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007f46e3fd6361  ptest xmm8, xmm8
00007f46e3fd6367  jnz 0x00007F46E3FD9BA8
00007f46e3fd636d  movaps xmm10, xmm14
00007f46e3fd6371  addpd xmm10, xmm4
00007f46e3fd6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007f46e3fd637c  ptest xmm8, xmm8
00007f46e3fd6382  jnz 0x00007F46E3FD9CEB
00007f46e3fd6388  vmovaps xmm14, [rsp+0x40]
00007f46e3fd638e  vpermilpd xmm14, xmm14, 0x00
00007f46e3fd6394  movaps xmm8, xmm1
00007f46e3fd6398  mulpd xmm8, xmm14
00007f46e3fd639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007f46e3fd63a3  ptest xmm6, xmm6
00007f46e3fd63a8  jnz 0x00007F46E3FD9E2E
00007f46e3fd63ae  movaps xmm1, [r15+0x2B0]
00007f46e3fd63b6  vmovaps xmm14, [rsp+0x40]
00007f46e3fd63bc  vpermilpd xmm14, xmm14, 0x00
00007f46e3fd63c2  movaps xmm6, xmm1
00007f46e3fd63c5  mulpd xmm6, xmm14
00007f46e3fd63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007f46e3fd63cf  ptest xmm5, xmm5
00007f46e3fd63d4  jnz 0x00007F46E3FD9F71
00007f46e3fd63da  vmovaps xmm1, [rsp+0x10]
00007f46e3fd63e0  vpermilpd xmm1, xmm1, 0x00
00007f46e3fd63e6  movaps xmm14, xmm12
00007f46e3fd63ea  mulpd xmm14, xmm1
00007f46e3fd63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007f46e3fd63f5  ptest xmm5, xmm5
00007f46e3fd63fa  jnz 0x00007F46E3FDA0B2
00007f46e3fd6400  movaps xmm1, xmm13
00007f46e3fd6404  addpd xmm1, xmm9
00007f46e3fd6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007f46e3fd640e  ptest xmm12, xmm12
00007f46e3fd6414  jnz 0x00007F46E3FDA1F5
00007f46e3fd641a  vmovaps xmm13, [rsp+0x10]
00007f46e3fd6420  vpermilpd xmm13, xmm13, 0x00
00007f46e3fd6426  movaps xmm12, xmm7
00007f46e3fd642a  mulpd xmm12, xmm13
00007f46e3fd642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007f46e3fd6435  ptest xmm9, xmm9
00007f46e3fd643b  jnz 0x00007F46E3FDA337
00007f46e3fd6441  movaps xmm13, xmm15
00007f46e3fd6445  addpd xmm13, xmm8
00007f46e3fd644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007f46e3fd6450  ptest xmm9, xmm9
00007f46e3fd6456  jnz 0x00007F46E3FDA47A
00007f46e3fd645c  movaps xmm15, [r15+0x290]
00007f46e3fd6464  vmovaps xmm9, [rsp+0x10]
00007f46e3fd646a  vpermilpd xmm9, xmm9, 0x00
00007f46e3fd6470  movaps xmm8, xmm15
00007f46e3fd6474  mulpd xmm8, xmm9
00007f46e3fd6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007f46e3fd647f  ptest xmm7, xmm7
00007f46e3fd6484  jnz 0x00007F46E3FDA5BE
00007f46e3fd648a  movaps xmm15, xmm11
00007f46e3fd648e  addpd xmm15, xmm6
00007f46e3fd6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007f46e3fd6499  ptest xmm9, xmm9
00007f46e3fd649f  jnz 0x00007F46E3FDA702
00007f46e3fd64a5  movaps xmm11, [r15+0x1E0]
00007f46e3fd64ad  vmovaps xmm9, [rsp+0x10]
00007f46e3fd64b3  vpermilpd xmm9, xmm9, 0x00
00007f46e3fd64b9  movaps xmm7, xmm11
00007f46e3fd64bd  mulpd xmm7, xmm9
00007f46e3fd64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007f46e3fd64c7  ptest xmm6, xmm6
00007f46e3fd64cc  jnz 0x00007F46E3FDA845
00007f46e3fd64d2  movaps xmm11, xmm10
00007f46e3fd64d6  addpd xmm11, xmm14
00007f46e3fd64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007f46e3fd64e1  ptest xmm9, xmm9
00007f46e3fd64e7  jnz 0x00007F46E3FDA987
00007f46e3fd64ed  lea r14, [rax+0x70]
00007f46e3fd64f1  movups xmm14, [r13+r14*1]
00007f46e3fd64f7  movaps [r15+0x240], xmm14
00007f46e3fd64ff  movaps xmm10, xmm1
00007f46e3fd6503  addpd xmm10, xmm12
00007f46e3fd6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007f46e3fd650e  ptest xmm9, xmm9
00007f46e3fd6514  jnz 0x00007F46E3FDAAD5
00007f46e3fd651a  movaps [r15+0x170], xmm10
00007f46e3fd6522  vmovaps xmm1, [rsp+0x20]
00007f46e3fd6528  vpermilpd xmm1, xmm1, 0x00
00007f46e3fd652e  movaps xmm12, xmm14
00007f46e3fd6532  mulpd xmm12, xmm1
00007f46e3fd6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007f46e3fd653d  ptest xmm9, xmm9
00007f46e3fd6543  jnz 0x00007F46E3FDAC18
00007f46e3fd6549  vmovaps xmm1, [rsp+0x20]
00007f46e3fd654f  vpermilpd xmm1, xmm1, 0x00
00007f46e3fd6555  vmovaps xmm9, [rsp+0xB0]
00007f46e3fd655e  movaps xmm14, xmm9
00007f46e3fd6562  mulpd xmm14, xmm1
00007f46e3fd6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007f46e3fd656d  ptest xmm6, xmm6
00007f46e3fd6572  jnz 0x00007F46E3FDAD5B
00007f46e3fd6578  movaps [r15+0x180], xmm14
00007f46e3fd6580  movaps xmm1, xmm13
00007f46e3fd6584  addpd xmm1, xmm8
00007f46e3fd6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007f46e3fd658e  ptest xmm9, xmm9
00007f46e3fd6594  jnz 0x00007F46E3FDAE9E
00007f46e3fd659a  movaps [r15+0x210], xmm1
00007f46e3fd65a2  movups xmm13, [r13+rax*1]
00007f46e3fd65a8  lea r14, [rax+0x10]
00007f46e3fd65ac  movups xmm9, [r13+r14*1]
00007f46e3fd65b2  movaps [r15+0x230], xmm9
00007f46e3fd65ba  movaps xmm8, xmm15
00007f46e3fd65be  addpd xmm8, xmm7
00007f46e3fd65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007f46e3fd65c9  ptest xmm6, xmm6
00007f46e3fd65ce  jnz 0x00007F46E3FDAFF4
00007f46e3fd65d4  movaps [r15+0x130], xmm8
00007f46e3fd65dc  vmovaps xmm15, [rsp+0x20]
00007f46e3fd65e2  vpermilpd xmm15, xmm15, 0x00
00007f46e3fd65e8  movaps xmm7, xmm9
00007f46e3fd65ec  mulpd xmm7, xmm15
00007f46e3fd65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007f46e3fd65f6  ptest xmm6, xmm6
00007f46e3fd65fb  jnz 0x00007F46E3FDB137
00007f46e3fd6601  movaps [r15+0x220], xmm7
00007f46e3fd6609  vmovaps xmm15, [rsp+0x20]
00007f46e3fd660f  vpermilpd xmm15, xmm15, 0x00
00007f46e3fd6615  movaps xmm9, xmm13
00007f46e3fd6619  mulpd xmm9, xmm15
00007f46e3fd661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007f46e3fd6624  ptest xmm6, xmm6
00007f46e3fd6629  jnz 0x00007F46E3FDB279
00007f46e3fd662f  movaps xmm15, xmm11
00007f46e3fd6633  addpd xmm15, xmm12
00007f46e3fd6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007f46e3fd663e  ptest xmm13, xmm13
00007f46e3fd6644  jnz 0x00007F46E3FDB3BD
00007f46e3fd664a  movaps [r15+0x140], xmm15
00007f46e3fd6652  movaps xmm13, xmm10
00007f46e3fd6656  addpd xmm13, xmm14
00007f46e3fd665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007f46e3fd6661  ptest xmm12, xmm12
00007f46e3fd6667  jnz 0x00007F46E3FDB501
00007f46e3fd666d  movaps [r15+0x150], xmm13
00007f46e3fd6675  movaps xmm14, xmm1
00007f46e3fd6679  addpd xmm14, xmm7
00007f46e3fd667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007f46e3fd6684  ptest xmm12, xmm12
00007f46e3fd668a  jnz 0x00007F46E3FDB645
00007f46e3fd6690  movaps [r15+0x160], xmm14
00007f46e3fd6698  movaps xmm1, xmm8
00007f46e3fd669c  addpd xmm1, xmm9
00007f46e3fd66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007f46e3fd66a6  ptest xmm12, xmm12
00007f46e3fd66ac  jnz 0x00007F46E3FDB787
00007f46e3fd66b2  movaps [r15+0x120], xmm1
00007f46e3fd66ba  movups [r13+r11*1], xmm15
00007f46e3fd66c0  lea rax, [r11+0x10]
00007f46e3fd66c4  movups [r13+rax*1], xmm13
00007f46e3fd66ca  lea rax, [r11+0x20]
00007f46e3fd66ce  movups [r13+rax*1], xmm14
00007f46e3fd66d4  lea rax, [r11+0x30]
00007f46e3fd66d8  movups [r13+rax*1], xmm1
00007f46e3fd66de  mov eax, [r15+0x108]
00007f46e3fd66e5  sahf
00007f46e3fd66e6  jnz 0x00007F46E3FD6718
00007f46e3fd66e8  cmp dword ptr [r15+0x318], 0x00
00007f46e3fd66f0  jz 0x00007F46E3FDB900
00007f46e3fd66f6  nop [rax+rax*1], ax
00007f46e3fd66ff  nop [rax+rax*1], eax
00007f46e3fd6707  mov eax, 0x410444
00007f46e3fd670c  mov [r15+0x100], rax
00007f46e3fd6713  jmp 0x00007F46E3DFE110
00007f46e3fd6718  cmp dword ptr [r15+0x318], 0x00
00007f46e3fd6720  jz 0x00007F46E3FD57E0
00007f46e3fd6726  nop [rax+rax*1], ax
00007f46e3fd672f  nop [rax+rax*1], eax
00007f46e3fd6737  mov eax, 0x410278
00007f46e3fd673c  mov [r15+0x100], rax
00007f46e3fd6743  jmp 0x00007F46E3DFE110
00007f46e3fd6748  int3
00007f46e3fd6749  call 0x00007F46E3E0A4B0
00007f46e3fd674e  jmp 0x00007F46E3FD5828
00007f46e3fd6753  call 0x00007F46E3E09240
00007f46e3fd6758  jmp 0x00007F46E3FD5832
00007f46e3fd675d  call 0x00007F46E3E0A4B0
00007f46e3fd6762  jmp 0x00007F46E3FD588F
00007f46e3fd6767  call 0x00007F46E3E09240
00007f46e3fd676c  jmp 0x00007F46E3FD5899
00007f46e3fd6771  call 0x00007F46E3E0A4B0
00007f46e3fd6776  jmp 0x00007F46E3FD58DD
00007f46e3fd677b  call 0x00007F46E3E09240
00007f46e3fd6780  jmp 0x00007F46E3FD58E7
00007f46e3fd6785  call 0x00007F46E3EB47C0
00007f46e3fd678a  jmp 0x00007F46E3FD5926
00007f46e3fd678f  call 0x00007F46E3E0B720
00007f46e3fd6794  jmp 0x00007F46E3FD593A
00007f46e3fd6799  call 0x00007F46E3EBFC30
00007f46e3fd679e  jmp 0x00007F46E3FD5958
00007f46e3fd67a3  call 0x00007F46E3EBE9C0
00007f46e3fd67a8  jmp 0x00007F46E3FD5962
00007f46e3fd67ad  call 0x00007F46E3EBD750
00007f46e3fd67b2  jmp 0x00007F46E3FD596C
00007f46e3fd67b7  sub rsp, 0x08
00007f46e3fd67bb  push rax
00007f46e3fd67bc  push rcx
00007f46e3fd67bd  push rdx
00007f46e3fd67be  push rdi
00007f46e3fd67bf  push rsi
00007f46e3fd67c0  push r8
00007f46e3fd67c2  push r9
00007f46e3fd67c4  push r10
00007f46e3fd67c6  push r11
00007f46e3fd67c8  sub rsp, 0xF0
00007f46e3fd67cf  vmovaps [rsp], xmm0
00007f46e3fd67d4  vmovaps [rsp+0x10], xmm1
00007f46e3fd67da  vmovaps [rsp+0x20], xmm2
00007f46e3fd67e0  vmovaps [rsp+0x30], xmm3
00007f46e3fd67e6  vmovaps [rsp+0x40], xmm4
00007f46e3fd67ec  vmovaps [rsp+0x50], xmm5
00007f46e3fd67f2  vmovaps [rsp+0x60], xmm6
00007f46e3fd67f8  vmovaps [rsp+0x70], xmm7
00007f46e3fd67fe  vmovaps [rsp+0x80], xmm9
00007f46e3fd6807  vmovaps [rsp+0x90], xmm10
00007f46e3fd6810  vmovaps [rsp+0xA0], xmm11
00007f46e3fd6819  vmovaps [rsp+0xB0], xmm12
00007f46e3fd6822  vmovaps [rsp+0xC0], xmm13
00007f46e3fd682b  vmovaps [rsp+0xD0], xmm14
00007f46e3fd6834  vmovaps [rsp+0xE0], xmm15
00007f46e3fd683d  sub rsp, 0x30
00007f46e3fd6841  movaps [rsp], xmm8
00007f46e3fd6846  movaps [rsp+0x10], xmm12
00007f46e3fd684c  movaps [rsp+0x20], xmm15
00007f46e3fd6852  lea rdi, [rsp]
00007f46e3fd6856  mov esi, 0x00
00007f46e3fd685b  mov rax, 0x6238B185B530
00007f46e3fd6865  call rax
00007f46e3fd6867  movaps xmm8, [rsp]
00007f46e3fd686c  add rsp, 0x30
00007f46e3fd6870  vmovaps xmm0, [rsp]
00007f46e3fd6875  vmovaps xmm1, [rsp+0x10]
00007f46e3fd687b  vmovaps xmm2, [rsp+0x20]
00007f46e3fd6881  vmovaps xmm3, [rsp+0x30]
00007f46e3fd6887  vmovaps xmm4, [rsp+0x40]
00007f46e3fd688d  vmovaps xmm5, [rsp+0x50]
00007f46e3fd6893  vmovaps xmm6, [rsp+0x60]
00007f46e3fd6899  vmovaps xmm7, [rsp+0x70]
00007f46e3fd689f  vmovaps xmm9, [rsp+0x80]
00007f46e3fd68a8  vmovaps xmm10, [rsp+0x90]
00007f46e3fd68b1  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd68ba  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd68c3  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd68cc  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd68d5  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd68de  add rsp, 0xF0
00007f46e3fd68e5  pop r11
00007f46e3fd68e7  pop r10
00007f46e3fd68e9  pop r9
00007f46e3fd68eb  pop r8
00007f46e3fd68ed  pop rsi
00007f46e3fd68ee  pop rdi
00007f46e3fd68ef  pop rdx
00007f46e3fd68f0  pop rcx
00007f46e3fd68f1  pop rax
00007f46e3fd68f2  add rsp, 0x08
00007f46e3fd68f6  jmp 0x00007F46E3FD599A
00007f46e3fd68fb  sub rsp, 0x08
00007f46e3fd68ff  push rax
00007f46e3fd6900  push rcx
00007f46e3fd6901  push rdx
00007f46e3fd6902  push rdi
00007f46e3fd6903  push rsi
00007f46e3fd6904  push r8
00007f46e3fd6906  push r9
00007f46e3fd6908  push r10
00007f46e3fd690a  push r11
00007f46e3fd690c  sub rsp, 0xF0
00007f46e3fd6913  vmovaps [rsp], xmm0
00007f46e3fd6918  vmovaps [rsp+0x10], xmm1
00007f46e3fd691e  vmovaps [rsp+0x20], xmm2
00007f46e3fd6924  vmovaps [rsp+0x30], xmm3
00007f46e3fd692a  vmovaps [rsp+0x40], xmm4
00007f46e3fd6930  vmovaps [rsp+0x50], xmm5
00007f46e3fd6936  vmovaps [rsp+0x60], xmm6
00007f46e3fd693c  vmovaps [rsp+0x70], xmm8
00007f46e3fd6942  vmovaps [rsp+0x80], xmm9
00007f46e3fd694b  vmovaps [rsp+0x90], xmm10
00007f46e3fd6954  vmovaps [rsp+0xA0], xmm11
00007f46e3fd695d  vmovaps [rsp+0xB0], xmm12
00007f46e3fd6966  vmovaps [rsp+0xC0], xmm13
00007f46e3fd696f  vmovaps [rsp+0xD0], xmm14
00007f46e3fd6978  vmovaps [rsp+0xE0], xmm15
00007f46e3fd6981  sub rsp, 0x30
00007f46e3fd6985  movaps [rsp], xmm7
00007f46e3fd6989  movaps [rsp+0x10], xmm9
00007f46e3fd698f  movaps [rsp+0x20], xmm15
00007f46e3fd6995  lea rdi, [rsp]
00007f46e3fd6999  mov esi, 0x00
00007f46e3fd699e  mov rax, 0x6238B185B530
00007f46e3fd69a8  call rax
00007f46e3fd69aa  movaps xmm7, [rsp]
00007f46e3fd69ae  add rsp, 0x30
00007f46e3fd69b2  vmovaps xmm0, [rsp]
00007f46e3fd69b7  vmovaps xmm1, [rsp+0x10]
00007f46e3fd69bd  vmovaps xmm2, [rsp+0x20]
00007f46e3fd69c3  vmovaps xmm3, [rsp+0x30]
00007f46e3fd69c9  vmovaps xmm4, [rsp+0x40]
00007f46e3fd69cf  vmovaps xmm5, [rsp+0x50]
00007f46e3fd69d5  vmovaps xmm6, [rsp+0x60]
00007f46e3fd69db  vmovaps xmm8, [rsp+0x70]
00007f46e3fd69e1  vmovaps xmm9, [rsp+0x80]
00007f46e3fd69ea  vmovaps xmm10, [rsp+0x90]
00007f46e3fd69f3  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd69fc  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd6a05  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd6a0e  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd6a17  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd6a20  add rsp, 0xF0
00007f46e3fd6a27  pop r11
00007f46e3fd6a29  pop r10
00007f46e3fd6a2b  pop r9
00007f46e3fd6a2d  pop r8
00007f46e3fd6a2f  pop rsi
00007f46e3fd6a30  pop rdi
00007f46e3fd6a31  pop rdx
00007f46e3fd6a32  pop rcx
00007f46e3fd6a33  pop rax
00007f46e3fd6a34  add rsp, 0x08
00007f46e3fd6a38  jmp 0x00007F46E3FD59C8
00007f46e3fd6a3d  sub rsp, 0x08
00007f46e3fd6a41  push rax
00007f46e3fd6a42  push rcx
00007f46e3fd6a43  push rdx
00007f46e3fd6a44  push rdi
00007f46e3fd6a45  push rsi
00007f46e3fd6a46  push r8
00007f46e3fd6a48  push r9
00007f46e3fd6a4a  push r10
00007f46e3fd6a4c  push r11
00007f46e3fd6a4e  sub rsp, 0xF0
00007f46e3fd6a55  vmovaps [rsp], xmm0
00007f46e3fd6a5a  vmovaps [rsp+0x10], xmm1
00007f46e3fd6a60  vmovaps [rsp+0x20], xmm2
00007f46e3fd6a66  vmovaps [rsp+0x30], xmm3
00007f46e3fd6a6c  vmovaps [rsp+0x40], xmm4
00007f46e3fd6a72  vmovaps [rsp+0x50], xmm5
00007f46e3fd6a78  vmovaps [rsp+0x60], xmm6
00007f46e3fd6a7e  vmovaps [rsp+0x70], xmm7
00007f46e3fd6a84  vmovaps [rsp+0x80], xmm8
00007f46e3fd6a8d  vmovaps [rsp+0x90], xmm10
00007f46e3fd6a96  vmovaps [rsp+0xA0], xmm11
00007f46e3fd6a9f  vmovaps [rsp+0xB0], xmm12
00007f46e3fd6aa8  vmovaps [rsp+0xC0], xmm13
00007f46e3fd6ab1  vmovaps [rsp+0xD0], xmm14
00007f46e3fd6aba  vmovaps [rsp+0xE0], xmm15
00007f46e3fd6ac3  sub rsp, 0x30
00007f46e3fd6ac7  movaps [rsp], xmm9
00007f46e3fd6acc  movaps [rsp+0x10], xmm12
00007f46e3fd6ad2  movaps [rsp+0x20], xmm10
00007f46e3fd6ad8  lea rdi, [rsp]
00007f46e3fd6adc  mov esi, 0x00
00007f46e3fd6ae1  mov rax, 0x6238B185B530
00007f46e3fd6aeb  call rax
00007f46e3fd6aed  movaps xmm9, [rsp]
00007f46e3fd6af2  add rsp, 0x30
00007f46e3fd6af6  vmovaps xmm0, [rsp]
00007f46e3fd6afb  vmovaps xmm1, [rsp+0x10]
00007f46e3fd6b01  vmovaps xmm2, [rsp+0x20]
00007f46e3fd6b07  vmovaps xmm3, [rsp+0x30]
00007f46e3fd6b0d  vmovaps xmm4, [rsp+0x40]
00007f46e3fd6b13  vmovaps xmm5, [rsp+0x50]
00007f46e3fd6b19  vmovaps xmm6, [rsp+0x60]
00007f46e3fd6b1f  vmovaps xmm7, [rsp+0x70]
00007f46e3fd6b25  vmovaps xmm8, [rsp+0x80]
00007f46e3fd6b2e  vmovaps xmm10, [rsp+0x90]
00007f46e3fd6b37  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd6b40  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd6b49  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd6b52  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd6b5b  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd6b64  add rsp, 0xF0
00007f46e3fd6b6b  pop r11
00007f46e3fd6b6d  pop r10
00007f46e3fd6b6f  pop r9
00007f46e3fd6b71  pop r8
00007f46e3fd6b73  pop rsi
00007f46e3fd6b74  pop rdi
00007f46e3fd6b75  pop rdx
00007f46e3fd6b76  pop rcx
00007f46e3fd6b77  pop rax
00007f46e3fd6b78  add rsp, 0x08
00007f46e3fd6b7c  jmp 0x00007F46E3FD59EC
00007f46e3fd6b81  sub rsp, 0x08
00007f46e3fd6b85  push rax
00007f46e3fd6b86  push rcx
00007f46e3fd6b87  push rdx
00007f46e3fd6b88  push rdi
00007f46e3fd6b89  push rsi
00007f46e3fd6b8a  push r8
00007f46e3fd6b8c  push r9
00007f46e3fd6b8e  push r10
00007f46e3fd6b90  push r11
00007f46e3fd6b92  sub rsp, 0xF0
00007f46e3fd6b99  vmovaps [rsp], xmm0
00007f46e3fd6b9e  vmovaps [rsp+0x10], xmm1
00007f46e3fd6ba4  vmovaps [rsp+0x20], xmm2
00007f46e3fd6baa  vmovaps [rsp+0x30], xmm3
00007f46e3fd6bb0  vmovaps [rsp+0x40], xmm4
00007f46e3fd6bb6  vmovaps [rsp+0x50], xmm5
00007f46e3fd6bbc  vmovaps [rsp+0x60], xmm6
00007f46e3fd6bc2  vmovaps [rsp+0x70], xmm7
00007f46e3fd6bc8  vmovaps [rsp+0x80], xmm8
00007f46e3fd6bd1  vmovaps [rsp+0x90], xmm9
00007f46e3fd6bda  vmovaps [rsp+0xA0], xmm11
00007f46e3fd6be3  vmovaps [rsp+0xB0], xmm12
00007f46e3fd6bec  vmovaps [rsp+0xC0], xmm13
00007f46e3fd6bf5  vmovaps [rsp+0xD0], xmm14
00007f46e3fd6bfe  vmovaps [rsp+0xE0], xmm15
00007f46e3fd6c07  sub rsp, 0x30
00007f46e3fd6c0b  movaps [rsp], xmm10
00007f46e3fd6c10  movaps [rsp+0x10], xmm12
00007f46e3fd6c16  movaps [rsp+0x20], xmm11
00007f46e3fd6c1c  lea rdi, [rsp]
00007f46e3fd6c20  mov esi, 0x00
00007f46e3fd6c25  mov rax, 0x6238B185B530
00007f46e3fd6c2f  call rax
00007f46e3fd6c31  movaps xmm10, [rsp]
00007f46e3fd6c36  add rsp, 0x30
00007f46e3fd6c3a  vmovaps xmm0, [rsp]
00007f46e3fd6c3f  vmovaps xmm1, [rsp+0x10]
00007f46e3fd6c45  vmovaps xmm2, [rsp+0x20]
00007f46e3fd6c4b  vmovaps xmm3, [rsp+0x30]
00007f46e3fd6c51  vmovaps xmm4, [rsp+0x40]
00007f46e3fd6c57  vmovaps xmm5, [rsp+0x50]
00007f46e3fd6c5d  vmovaps xmm6, [rsp+0x60]
00007f46e3fd6c63  vmovaps xmm7, [rsp+0x70]
00007f46e3fd6c69  vmovaps xmm8, [rsp+0x80]
00007f46e3fd6c72  vmovaps xmm9, [rsp+0x90]
00007f46e3fd6c7b  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd6c84  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd6c8d  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd6c96  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd6c9f  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd6ca8  add rsp, 0xF0
00007f46e3fd6caf  pop r11
00007f46e3fd6cb1  pop r10
00007f46e3fd6cb3  pop r9
00007f46e3fd6cb5  pop r8
00007f46e3fd6cb7  pop rsi
00007f46e3fd6cb8  pop rdi
00007f46e3fd6cb9  pop rdx
00007f46e3fd6cba  pop rcx
00007f46e3fd6cbb  pop rax
00007f46e3fd6cbc  add rsp, 0x08
00007f46e3fd6cc0  jmp 0x00007F46E3FD5A06
00007f46e3fd6cc5  sub rsp, 0x08
00007f46e3fd6cc9  push rax
00007f46e3fd6cca  push rcx
00007f46e3fd6ccb  push rdx
00007f46e3fd6ccc  push rdi
00007f46e3fd6ccd  push rsi
00007f46e3fd6cce  push r8
00007f46e3fd6cd0  push r9
00007f46e3fd6cd2  push r10
00007f46e3fd6cd4  push r11
00007f46e3fd6cd6  sub rsp, 0xF0
00007f46e3fd6cdd  vmovaps [rsp], xmm0
00007f46e3fd6ce2  vmovaps [rsp+0x10], xmm1
00007f46e3fd6ce8  vmovaps [rsp+0x20], xmm2
00007f46e3fd6cee  vmovaps [rsp+0x30], xmm3
00007f46e3fd6cf4  vmovaps [rsp+0x40], xmm4
00007f46e3fd6cfa  vmovaps [rsp+0x50], xmm5
00007f46e3fd6d00  vmovaps [rsp+0x60], xmm7
00007f46e3fd6d06  vmovaps [rsp+0x70], xmm8
00007f46e3fd6d0c  vmovaps [rsp+0x80], xmm9
00007f46e3fd6d15  vmovaps [rsp+0x90], xmm10
00007f46e3fd6d1e  vmovaps [rsp+0xA0], xmm11
00007f46e3fd6d27  vmovaps [rsp+0xB0], xmm12
00007f46e3fd6d30  vmovaps [rsp+0xC0], xmm13
00007f46e3fd6d39  vmovaps [rsp+0xD0], xmm14
00007f46e3fd6d42  vmovaps [rsp+0xE0], xmm15
00007f46e3fd6d4b  sub rsp, 0x30
00007f46e3fd6d4f  movaps [rsp], xmm6
00007f46e3fd6d53  movaps [rsp+0x10], xmm12
00007f46e3fd6d59  movaps [rsp+0x20], xmm11
00007f46e3fd6d5f  lea rdi, [rsp]
00007f46e3fd6d63  mov esi, 0x00
00007f46e3fd6d68  mov rax, 0x6238B185B530
00007f46e3fd6d72  call rax
00007f46e3fd6d74  movaps xmm6, [rsp]
00007f46e3fd6d78  add rsp, 0x30
00007f46e3fd6d7c  vmovaps xmm0, [rsp]
00007f46e3fd6d81  vmovaps xmm1, [rsp+0x10]
00007f46e3fd6d87  vmovaps xmm2, [rsp+0x20]
00007f46e3fd6d8d  vmovaps xmm3, [rsp+0x30]
00007f46e3fd6d93  vmovaps xmm4, [rsp+0x40]
00007f46e3fd6d99  vmovaps xmm5, [rsp+0x50]
00007f46e3fd6d9f  vmovaps xmm7, [rsp+0x60]
00007f46e3fd6da5  vmovaps xmm8, [rsp+0x70]
00007f46e3fd6dab  vmovaps xmm9, [rsp+0x80]
00007f46e3fd6db4  vmovaps xmm10, [rsp+0x90]
00007f46e3fd6dbd  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd6dc6  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd6dcf  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd6dd8  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd6de1  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd6dea  add rsp, 0xF0
00007f46e3fd6df1  pop r11
00007f46e3fd6df3  pop r10
00007f46e3fd6df5  pop r9
00007f46e3fd6df7  pop r8
00007f46e3fd6df9  pop rsi
00007f46e3fd6dfa  pop rdi
00007f46e3fd6dfb  pop rdx
00007f46e3fd6dfc  pop rcx
00007f46e3fd6dfd  pop rax
00007f46e3fd6dfe  add rsp, 0x08
00007f46e3fd6e02  jmp 0x00007F46E3FD5A27
00007f46e3fd6e07  sub rsp, 0x08
00007f46e3fd6e0b  push rax
00007f46e3fd6e0c  push rcx
00007f46e3fd6e0d  push rdx
00007f46e3fd6e0e  push rdi
00007f46e3fd6e0f  push rsi
00007f46e3fd6e10  push r8
00007f46e3fd6e12  push r9
00007f46e3fd6e14  push r10
00007f46e3fd6e16  push r11
00007f46e3fd6e18  sub rsp, 0xF0
00007f46e3fd6e1f  vmovaps [rsp], xmm0
00007f46e3fd6e24  vmovaps [rsp+0x10], xmm1
00007f46e3fd6e2a  vmovaps [rsp+0x20], xmm2
00007f46e3fd6e30  vmovaps [rsp+0x30], xmm4
00007f46e3fd6e36  vmovaps [rsp+0x40], xmm5
00007f46e3fd6e3c  vmovaps [rsp+0x50], xmm6
00007f46e3fd6e42  vmovaps [rsp+0x60], xmm7
00007f46e3fd6e48  vmovaps [rsp+0x70], xmm8
00007f46e3fd6e4e  vmovaps [rsp+0x80], xmm9
00007f46e3fd6e57  vmovaps [rsp+0x90], xmm10
00007f46e3fd6e60  vmovaps [rsp+0xA0], xmm11
00007f46e3fd6e69  vmovaps [rsp+0xB0], xmm12
00007f46e3fd6e72  vmovaps [rsp+0xC0], xmm13
00007f46e3fd6e7b  vmovaps [rsp+0xD0], xmm14
00007f46e3fd6e84  vmovaps [rsp+0xE0], xmm15
00007f46e3fd6e8d  sub rsp, 0x30
00007f46e3fd6e91  movaps [rsp], xmm3
00007f46e3fd6e95  movaps [rsp+0x10], xmm5
00007f46e3fd6e9a  movaps [rsp+0x20], xmm4
00007f46e3fd6e9f  lea rdi, [rsp]
00007f46e3fd6ea3  mov esi, 0x00
00007f46e3fd6ea8  mov rax, 0x6238B185B530
00007f46e3fd6eb2  call rax
00007f46e3fd6eb4  movaps xmm3, [rsp]
00007f46e3fd6eb8  add rsp, 0x30
00007f46e3fd6ebc  vmovaps xmm0, [rsp]
00007f46e3fd6ec1  vmovaps xmm1, [rsp+0x10]
00007f46e3fd6ec7  vmovaps xmm2, [rsp+0x20]
00007f46e3fd6ecd  vmovaps xmm4, [rsp+0x30]
00007f46e3fd6ed3  vmovaps xmm5, [rsp+0x40]
00007f46e3fd6ed9  vmovaps xmm6, [rsp+0x50]
00007f46e3fd6edf  vmovaps xmm7, [rsp+0x60]
00007f46e3fd6ee5  vmovaps xmm8, [rsp+0x70]
00007f46e3fd6eeb  vmovaps xmm9, [rsp+0x80]
00007f46e3fd6ef4  vmovaps xmm10, [rsp+0x90]
00007f46e3fd6efd  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd6f06  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd6f0f  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd6f18  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd6f21  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd6f2a  add rsp, 0xF0
00007f46e3fd6f31  pop r11
00007f46e3fd6f33  pop r10
00007f46e3fd6f35  pop r9
00007f46e3fd6f37  pop r8
00007f46e3fd6f39  pop rsi
00007f46e3fd6f3a  pop rdi
00007f46e3fd6f3b  pop rdx
00007f46e3fd6f3c  pop rcx
00007f46e3fd6f3d  pop rax
00007f46e3fd6f3e  add rsp, 0x08
00007f46e3fd6f42  jmp 0x00007F46E3FD5A88
00007f46e3fd6f47  sub rsp, 0x08
00007f46e3fd6f4b  push rax
00007f46e3fd6f4c  push rcx
00007f46e3fd6f4d  push rdx
00007f46e3fd6f4e  push rdi
00007f46e3fd6f4f  push rsi
00007f46e3fd6f50  push r8
00007f46e3fd6f52  push r9
00007f46e3fd6f54  push r10
00007f46e3fd6f56  push r11
00007f46e3fd6f58  sub rsp, 0xF0
00007f46e3fd6f5f  vmovaps [rsp], xmm0
00007f46e3fd6f64  vmovaps [rsp+0x10], xmm1
00007f46e3fd6f6a  vmovaps [rsp+0x20], xmm2
00007f46e3fd6f70  vmovaps [rsp+0x30], xmm3
00007f46e3fd6f76  vmovaps [rsp+0x40], xmm4
00007f46e3fd6f7c  vmovaps [rsp+0x50], xmm6
00007f46e3fd6f82  vmovaps [rsp+0x60], xmm7
00007f46e3fd6f88  vmovaps [rsp+0x70], xmm8
00007f46e3fd6f8e  vmovaps [rsp+0x80], xmm9
00007f46e3fd6f97  vmovaps [rsp+0x90], xmm10
00007f46e3fd6fa0  vmovaps [rsp+0xA0], xmm11
00007f46e3fd6fa9  vmovaps [rsp+0xB0], xmm12
00007f46e3fd6fb2  vmovaps [rsp+0xC0], xmm13
00007f46e3fd6fbb  vmovaps [rsp+0xD0], xmm14
00007f46e3fd6fc4  vmovaps [rsp+0xE0], xmm15
00007f46e3fd6fcd  sub rsp, 0x30
00007f46e3fd6fd1  movaps [rsp], xmm5
00007f46e3fd6fd5  movaps [rsp+0x10], xmm8
00007f46e3fd6fdb  movaps [rsp+0x20], xmm15
00007f46e3fd6fe1  lea rdi, [rsp]
00007f46e3fd6fe5  mov esi, 0x00
00007f46e3fd6fea  mov rax, 0x6238B185B530
00007f46e3fd6ff4  call rax
00007f46e3fd6ff6  movaps xmm5, [rsp]
00007f46e3fd6ffa  add rsp, 0x30
00007f46e3fd6ffe  vmovaps xmm0, [rsp]
00007f46e3fd7003  vmovaps xmm1, [rsp+0x10]
00007f46e3fd7009  vmovaps xmm2, [rsp+0x20]
00007f46e3fd700f  vmovaps xmm3, [rsp+0x30]
00007f46e3fd7015  vmovaps xmm4, [rsp+0x40]
00007f46e3fd701b  vmovaps xmm6, [rsp+0x50]
00007f46e3fd7021  vmovaps xmm7, [rsp+0x60]
00007f46e3fd7027  vmovaps xmm8, [rsp+0x70]
00007f46e3fd702d  vmovaps xmm9, [rsp+0x80]
00007f46e3fd7036  vmovaps xmm10, [rsp+0x90]
00007f46e3fd703f  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd7048  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd7051  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd705a  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd7063  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd706c  add rsp, 0xF0
00007f46e3fd7073  pop r11
00007f46e3fd7075  pop r10
00007f46e3fd7077  pop r9
00007f46e3fd7079  pop r8
00007f46e3fd707b  pop rsi
00007f46e3fd707c  pop rdi
00007f46e3fd707d  pop rdx
00007f46e3fd707e  pop rcx
00007f46e3fd707f  pop rax
00007f46e3fd7080  add rsp, 0x08
00007f46e3fd7084  jmp 0x00007F46E3FD5AC0
00007f46e3fd7089  sub rsp, 0x08
00007f46e3fd708d  push rax
00007f46e3fd708e  push rcx
00007f46e3fd708f  push rdx
00007f46e3fd7090  push rdi
00007f46e3fd7091  push rsi
00007f46e3fd7092  push r8
00007f46e3fd7094  push r9
00007f46e3fd7096  push r10
00007f46e3fd7098  push r11
00007f46e3fd709a  sub rsp, 0xF0
00007f46e3fd70a1  vmovaps [rsp], xmm0
00007f46e3fd70a6  vmovaps [rsp+0x10], xmm1
00007f46e3fd70ac  vmovaps [rsp+0x20], xmm2
00007f46e3fd70b2  vmovaps [rsp+0x30], xmm3
00007f46e3fd70b8  vmovaps [rsp+0x40], xmm5
00007f46e3fd70be  vmovaps [rsp+0x50], xmm6
00007f46e3fd70c4  vmovaps [rsp+0x60], xmm7
00007f46e3fd70ca  vmovaps [rsp+0x70], xmm8
00007f46e3fd70d0  vmovaps [rsp+0x80], xmm9
00007f46e3fd70d9  vmovaps [rsp+0x90], xmm10
00007f46e3fd70e2  vmovaps [rsp+0xA0], xmm11
00007f46e3fd70eb  vmovaps [rsp+0xB0], xmm12
00007f46e3fd70f4  vmovaps [rsp+0xC0], xmm13
00007f46e3fd70fd  vmovaps [rsp+0xD0], xmm14
00007f46e3fd7106  vmovaps [rsp+0xE0], xmm15
00007f46e3fd710f  sub rsp, 0x30
00007f46e3fd7113  movaps [rsp], xmm4
00007f46e3fd7117  movaps [rsp+0x10], xmm9
00007f46e3fd711d  movaps [rsp+0x20], xmm8
00007f46e3fd7123  lea rdi, [rsp]
00007f46e3fd7127  mov esi, 0x00
00007f46e3fd712c  mov rax, 0x6238B185B530
00007f46e3fd7136  call rax
00007f46e3fd7138  movaps xmm4, [rsp]
00007f46e3fd713c  add rsp, 0x30
00007f46e3fd7140  vmovaps xmm0, [rsp]
00007f46e3fd7145  vmovaps xmm1, [rsp+0x10]
00007f46e3fd714b  vmovaps xmm2, [rsp+0x20]
00007f46e3fd7151  vmovaps xmm3, [rsp+0x30]
00007f46e3fd7157  vmovaps xmm5, [rsp+0x40]
00007f46e3fd715d  vmovaps xmm6, [rsp+0x50]
00007f46e3fd7163  vmovaps xmm7, [rsp+0x60]
00007f46e3fd7169  vmovaps xmm8, [rsp+0x70]
00007f46e3fd716f  vmovaps xmm9, [rsp+0x80]
00007f46e3fd7178  vmovaps xmm10, [rsp+0x90]
00007f46e3fd7181  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd718a  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd7193  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd719c  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd71a5  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd71ae  add rsp, 0xF0
00007f46e3fd71b5  pop r11
00007f46e3fd71b7  pop r10
00007f46e3fd71b9  pop r9
00007f46e3fd71bb  pop r8
00007f46e3fd71bd  pop rsi
00007f46e3fd71be  pop rdi
00007f46e3fd71bf  pop rdx
00007f46e3fd71c0  pop rcx
00007f46e3fd71c1  pop rax
00007f46e3fd71c2  add rsp, 0x08
00007f46e3fd71c6  jmp 0x00007F46E3FD5AE1
00007f46e3fd71cb  sub rsp, 0x08
00007f46e3fd71cf  push rax
00007f46e3fd71d0  push rcx
00007f46e3fd71d1  push rdx
00007f46e3fd71d2  push rdi
00007f46e3fd71d3  push rsi
00007f46e3fd71d4  push r8
00007f46e3fd71d6  push r9
00007f46e3fd71d8  push r10
00007f46e3fd71da  push r11
00007f46e3fd71dc  sub rsp, 0xF0
00007f46e3fd71e3  vmovaps [rsp], xmm0
00007f46e3fd71e8  vmovaps [rsp+0x10], xmm1
00007f46e3fd71ee  vmovaps [rsp+0x20], xmm2
00007f46e3fd71f4  vmovaps [rsp+0x30], xmm3
00007f46e3fd71fa  vmovaps [rsp+0x40], xmm4
00007f46e3fd7200  vmovaps [rsp+0x50], xmm5
00007f46e3fd7206  vmovaps [rsp+0x60], xmm6
00007f46e3fd720c  vmovaps [rsp+0x70], xmm7
00007f46e3fd7212  vmovaps [rsp+0x80], xmm8
00007f46e3fd721b  vmovaps [rsp+0x90], xmm10
00007f46e3fd7224  vmovaps [rsp+0xA0], xmm11
00007f46e3fd722d  vmovaps [rsp+0xB0], xmm12
00007f46e3fd7236  vmovaps [rsp+0xC0], xmm13
00007f46e3fd723f  vmovaps [rsp+0xD0], xmm14
00007f46e3fd7248  vmovaps [rsp+0xE0], xmm15
00007f46e3fd7251  sub rsp, 0x30
00007f46e3fd7255  movaps [rsp], xmm9
00007f46e3fd725a  movaps [rsp+0x10], xmm10
00007f46e3fd7260  movaps [rsp+0x20], xmm8
00007f46e3fd7266  lea rdi, [rsp]
00007f46e3fd726a  mov esi, 0x00
00007f46e3fd726f  mov rax, 0x6238B185B530
00007f46e3fd7279  call rax
00007f46e3fd727b  movaps xmm9, [rsp]
00007f46e3fd7280  add rsp, 0x30
00007f46e3fd7284  vmovaps xmm0, [rsp]
00007f46e3fd7289  vmovaps xmm1, [rsp+0x10]
00007f46e3fd728f  vmovaps xmm2, [rsp+0x20]
00007f46e3fd7295  vmovaps xmm3, [rsp+0x30]
00007f46e3fd729b  vmovaps xmm4, [rsp+0x40]
00007f46e3fd72a1  vmovaps xmm5, [rsp+0x50]
00007f46e3fd72a7  vmovaps xmm6, [rsp+0x60]
00007f46e3fd72ad  vmovaps xmm7, [rsp+0x70]
00007f46e3fd72b3  vmovaps xmm8, [rsp+0x80]
00007f46e3fd72bc  vmovaps xmm10, [rsp+0x90]
00007f46e3fd72c5  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd72ce  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd72d7  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd72e0  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd72e9  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd72f2  add rsp, 0xF0
00007f46e3fd72f9  pop r11
00007f46e3fd72fb  pop r10
00007f46e3fd72fd  pop r9
00007f46e3fd72ff  pop r8
00007f46e3fd7301  pop rsi
00007f46e3fd7302  pop rdi
00007f46e3fd7303  pop rdx
00007f46e3fd7304  pop rcx
00007f46e3fd7305  pop rax
00007f46e3fd7306  add rsp, 0x08
00007f46e3fd730a  jmp 0x00007F46E3FD5AFB
00007f46e3fd730f  call 0x00007F46E3ED64F0
00007f46e3fd7314  jmp 0x00007F46E3FD5C15
00007f46e3fd7319  call 0x00007F46E3ED64F0
00007f46e3fd731e  jmp 0x00007F46E3FD5C2B
00007f46e3fd7323  sub rsp, 0x08
00007f46e3fd7327  push rax
00007f46e3fd7328  push rcx
00007f46e3fd7329  push rdx
00007f46e3fd732a  push rdi
00007f46e3fd732b  push rsi
00007f46e3fd732c  push r8
00007f46e3fd732e  push r9
00007f46e3fd7330  push r10
00007f46e3fd7332  push r11
00007f46e3fd7334  sub rsp, 0xF0
00007f46e3fd733b  vmovaps [rsp], xmm0
00007f46e3fd7340  vmovaps [rsp+0x10], xmm2
00007f46e3fd7346  vmovaps [rsp+0x20], xmm3
00007f46e3fd734c  vmovaps [rsp+0x30], xmm4
00007f46e3fd7352  vmovaps [rsp+0x40], xmm5
00007f46e3fd7358  vmovaps [rsp+0x50], xmm6
00007f46e3fd735e  vmovaps [rsp+0x60], xmm7
00007f46e3fd7364  vmovaps [rsp+0x70], xmm8
00007f46e3fd736a  vmovaps [rsp+0x80], xmm9
00007f46e3fd7373  vmovaps [rsp+0x90], xmm10
00007f46e3fd737c  vmovaps [rsp+0xA0], xmm11
00007f46e3fd7385  vmovaps [rsp+0xB0], xmm12
00007f46e3fd738e  vmovaps [rsp+0xC0], xmm13
00007f46e3fd7397  vmovaps [rsp+0xD0], xmm14
00007f46e3fd73a0  vmovaps [rsp+0xE0], xmm15
00007f46e3fd73a9  sub rsp, 0x30
00007f46e3fd73ad  movaps [rsp], xmm1
00007f46e3fd73b1  movaps [rsp+0x10], xmm6
00007f46e3fd73b6  movaps [rsp+0x20], xmm15
00007f46e3fd73bc  lea rdi, [rsp]
00007f46e3fd73c0  mov esi, 0x00
00007f46e3fd73c5  mov rax, 0x6238B185B530
00007f46e3fd73cf  call rax
00007f46e3fd73d1  movaps xmm1, [rsp]
00007f46e3fd73d5  add rsp, 0x30
00007f46e3fd73d9  vmovaps xmm0, [rsp]
00007f46e3fd73de  vmovaps xmm2, [rsp+0x10]
00007f46e3fd73e4  vmovaps xmm3, [rsp+0x20]
00007f46e3fd73ea  vmovaps xmm4, [rsp+0x30]
00007f46e3fd73f0  vmovaps xmm5, [rsp+0x40]
00007f46e3fd73f6  vmovaps xmm6, [rsp+0x50]
00007f46e3fd73fc  vmovaps xmm7, [rsp+0x60]
00007f46e3fd7402  vmovaps xmm8, [rsp+0x70]
00007f46e3fd7408  vmovaps xmm9, [rsp+0x80]
00007f46e3fd7411  vmovaps xmm10, [rsp+0x90]
00007f46e3fd741a  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd7423  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd742c  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd7435  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd743e  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd7447  add rsp, 0xF0
00007f46e3fd744e  pop r11
00007f46e3fd7450  pop r10
00007f46e3fd7452  pop r9
00007f46e3fd7454  pop r8
00007f46e3fd7456  pop rsi
00007f46e3fd7457  pop rdi
00007f46e3fd7458  pop rdx
00007f46e3fd7459  pop rcx
00007f46e3fd745a  pop rax
00007f46e3fd745b  add rsp, 0x08
00007f46e3fd745f  jmp 0x00007F46E3FD5C68
00007f46e3fd7464  call 0x00007F46E3EE5820
00007f46e3fd7469  jmp 0x00007F46E3FD5C75
00007f46e3fd746e  sub rsp, 0x08
00007f46e3fd7472  push rax
00007f46e3fd7473  push rcx
00007f46e3fd7474  push rdx
00007f46e3fd7475  push rdi
00007f46e3fd7476  push rsi
00007f46e3fd7477  push r8
00007f46e3fd7479  push r9
00007f46e3fd747b  push r10
00007f46e3fd747d  push r11
00007f46e3fd747f  sub rsp, 0xF0
00007f46e3fd7486  vmovaps [rsp], xmm0
00007f46e3fd748b  vmovaps [rsp+0x10], xmm1
00007f46e3fd7491  vmovaps [rsp+0x20], xmm2
00007f46e3fd7497  vmovaps [rsp+0x30], xmm3
00007f46e3fd749d  vmovaps [rsp+0x40], xmm4
00007f46e3fd74a3  vmovaps [rsp+0x50], xmm5
00007f46e3fd74a9  vmovaps [rsp+0x60], xmm6
00007f46e3fd74af  vmovaps [rsp+0x70], xmm7
00007f46e3fd74b5  vmovaps [rsp+0x80], xmm8
00007f46e3fd74be  vmovaps [rsp+0x90], xmm9
00007f46e3fd74c7  vmovaps [rsp+0xA0], xmm10
00007f46e3fd74d0  vmovaps [rsp+0xB0], xmm11
00007f46e3fd74d9  vmovaps [rsp+0xC0], xmm12
00007f46e3fd74e2  vmovaps [rsp+0xD0], xmm13
00007f46e3fd74eb  vmovaps [rsp+0xE0], xmm15
00007f46e3fd74f4  sub rsp, 0x30
00007f46e3fd74f8  movaps [rsp], xmm14
00007f46e3fd74fd  movaps [rsp+0x10], xmm4
00007f46e3fd7502  movaps [rsp+0x20], xmm3
00007f46e3fd7507  lea rdi, [rsp]
00007f46e3fd750b  mov esi, 0x00
00007f46e3fd7510  mov rax, 0x6238B185B530
00007f46e3fd751a  call rax
00007f46e3fd751c  movaps xmm14, [rsp]
00007f46e3fd7521  add rsp, 0x30
00007f46e3fd7525  vmovaps xmm0, [rsp]
00007f46e3fd752a  vmovaps xmm1, [rsp+0x10]
00007f46e3fd7530  vmovaps xmm2, [rsp+0x20]
00007f46e3fd7536  vmovaps xmm3, [rsp+0x30]
00007f46e3fd753c  vmovaps xmm4, [rsp+0x40]
00007f46e3fd7542  vmovaps xmm5, [rsp+0x50]
00007f46e3fd7548  vmovaps xmm6, [rsp+0x60]
00007f46e3fd754e  vmovaps xmm7, [rsp+0x70]
00007f46e3fd7554  vmovaps xmm8, [rsp+0x80]
00007f46e3fd755d  vmovaps xmm9, [rsp+0x90]
00007f46e3fd7566  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd756f  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd7578  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd7581  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd758a  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd7593  add rsp, 0xF0
00007f46e3fd759a  pop r11
00007f46e3fd759c  pop r10
00007f46e3fd759e  pop r9
00007f46e3fd75a0  pop r8
00007f46e3fd75a2  pop rsi
00007f46e3fd75a3  pop rdi
00007f46e3fd75a4  pop rdx
00007f46e3fd75a5  pop rcx
00007f46e3fd75a6  pop rax
00007f46e3fd75a7  add rsp, 0x08
00007f46e3fd75ab  jmp 0x00007F46E3FD5C8F
00007f46e3fd75b0  sub rsp, 0x08
00007f46e3fd75b4  push rax
00007f46e3fd75b5  push rcx
00007f46e3fd75b6  push rdx
00007f46e3fd75b7  push rdi
00007f46e3fd75b8  push rsi
00007f46e3fd75b9  push r8
00007f46e3fd75bb  push r9
00007f46e3fd75bd  push r10
00007f46e3fd75bf  push r11
00007f46e3fd75c1  sub rsp, 0xF0
00007f46e3fd75c8  vmovaps [rsp], xmm0
00007f46e3fd75cd  vmovaps [rsp+0x10], xmm1
00007f46e3fd75d3  vmovaps [rsp+0x20], xmm2
00007f46e3fd75d9  vmovaps [rsp+0x30], xmm3
00007f46e3fd75df  vmovaps [rsp+0x40], xmm4
00007f46e3fd75e5  vmovaps [rsp+0x50], xmm5
00007f46e3fd75eb  vmovaps [rsp+0x60], xmm7
00007f46e3fd75f1  vmovaps [rsp+0x70], xmm8
00007f46e3fd75f7  vmovaps [rsp+0x80], xmm9
00007f46e3fd7600  vmovaps [rsp+0x90], xmm10
00007f46e3fd7609  vmovaps [rsp+0xA0], xmm11
00007f46e3fd7612  vmovaps [rsp+0xB0], xmm12
00007f46e3fd761b  vmovaps [rsp+0xC0], xmm13
00007f46e3fd7624  vmovaps [rsp+0xD0], xmm14
00007f46e3fd762d  vmovaps [rsp+0xE0], xmm15
00007f46e3fd7636  sub rsp, 0x30
00007f46e3fd763a  movaps [rsp], xmm6
00007f46e3fd763e  movaps [rsp+0x10], xmm9
00007f46e3fd7644  movaps [rsp+0x20], xmm7
00007f46e3fd7649  lea rdi, [rsp]
00007f46e3fd764d  mov esi, 0x00
00007f46e3fd7652  mov rax, 0x6238B185B530
00007f46e3fd765c  call rax
00007f46e3fd765e  movaps xmm6, [rsp]
00007f46e3fd7662  add rsp, 0x30
00007f46e3fd7666  vmovaps xmm0, [rsp]
00007f46e3fd766b  vmovaps xmm1, [rsp+0x10]
00007f46e3fd7671  vmovaps xmm2, [rsp+0x20]
00007f46e3fd7677  vmovaps xmm3, [rsp+0x30]
00007f46e3fd767d  vmovaps xmm4, [rsp+0x40]
00007f46e3fd7683  vmovaps xmm5, [rsp+0x50]
00007f46e3fd7689  vmovaps xmm7, [rsp+0x60]
00007f46e3fd768f  vmovaps xmm8, [rsp+0x70]
00007f46e3fd7695  vmovaps xmm9, [rsp+0x80]
00007f46e3fd769e  vmovaps xmm10, [rsp+0x90]
00007f46e3fd76a7  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd76b0  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd76b9  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd76c2  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd76cb  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd76d4  add rsp, 0xF0
00007f46e3fd76db  pop r11
00007f46e3fd76dd  pop r10
00007f46e3fd76df  pop r9
00007f46e3fd76e1  pop r8
00007f46e3fd76e3  pop rsi
00007f46e3fd76e4  pop rdi
00007f46e3fd76e5  pop rdx
00007f46e3fd76e6  pop rcx
00007f46e3fd76e7  pop rax
00007f46e3fd76e8  add rsp, 0x08
00007f46e3fd76ec  jmp 0x00007F46E3FD5CA7
00007f46e3fd76f1  sub rsp, 0x08
00007f46e3fd76f5  push rax
00007f46e3fd76f6  push rcx
00007f46e3fd76f7  push rdx
00007f46e3fd76f8  push rdi
00007f46e3fd76f9  push rsi
00007f46e3fd76fa  push r8
00007f46e3fd76fc  push r9
00007f46e3fd76fe  push r10
00007f46e3fd7700  push r11
00007f46e3fd7702  sub rsp, 0xF0
00007f46e3fd7709  vmovaps [rsp], xmm0
00007f46e3fd770e  vmovaps [rsp+0x10], xmm1
00007f46e3fd7714  vmovaps [rsp+0x20], xmm2
00007f46e3fd771a  vmovaps [rsp+0x30], xmm3
00007f46e3fd7720  vmovaps [rsp+0x40], xmm4
00007f46e3fd7726  vmovaps [rsp+0x50], xmm5
00007f46e3fd772c  vmovaps [rsp+0x60], xmm6
00007f46e3fd7732  vmovaps [rsp+0x70], xmm8
00007f46e3fd7738  vmovaps [rsp+0x80], xmm9
00007f46e3fd7741  vmovaps [rsp+0x90], xmm10
00007f46e3fd774a  vmovaps [rsp+0xA0], xmm11
00007f46e3fd7753  vmovaps [rsp+0xB0], xmm12
00007f46e3fd775c  vmovaps [rsp+0xC0], xmm13
00007f46e3fd7765  vmovaps [rsp+0xD0], xmm14
00007f46e3fd776e  vmovaps [rsp+0xE0], xmm15
00007f46e3fd7777  sub rsp, 0x30
00007f46e3fd777b  movaps [rsp], xmm7
00007f46e3fd777f  movaps [rsp+0x10], xmm4
00007f46e3fd7784  movaps [rsp+0x20], xmm9
00007f46e3fd778a  lea rdi, [rsp]
00007f46e3fd778e  mov esi, 0x00
00007f46e3fd7793  mov rax, 0x6238B185B530
00007f46e3fd779d  call rax
00007f46e3fd779f  movaps xmm7, [rsp]
00007f46e3fd77a3  add rsp, 0x30
00007f46e3fd77a7  vmovaps xmm0, [rsp]
00007f46e3fd77ac  vmovaps xmm1, [rsp+0x10]
00007f46e3fd77b2  vmovaps xmm2, [rsp+0x20]
00007f46e3fd77b8  vmovaps xmm3, [rsp+0x30]
00007f46e3fd77be  vmovaps xmm4, [rsp+0x40]
00007f46e3fd77c4  vmovaps xmm5, [rsp+0x50]
00007f46e3fd77ca  vmovaps xmm6, [rsp+0x60]
00007f46e3fd77d0  vmovaps xmm8, [rsp+0x70]
00007f46e3fd77d6  vmovaps xmm9, [rsp+0x80]
00007f46e3fd77df  vmovaps xmm10, [rsp+0x90]
00007f46e3fd77e8  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd77f1  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd77fa  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd7803  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd780c  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd7815  add rsp, 0xF0
00007f46e3fd781c  pop r11
00007f46e3fd781e  pop r10
00007f46e3fd7820  pop r9
00007f46e3fd7822  pop r8
00007f46e3fd7824  pop rsi
00007f46e3fd7825  pop rdi
00007f46e3fd7826  pop rdx
00007f46e3fd7827  pop rcx
00007f46e3fd7828  pop rax
00007f46e3fd7829  add rsp, 0x08
00007f46e3fd782d  jmp 0x00007F46E3FD5CD4
00007f46e3fd7832  sub rsp, 0x08
00007f46e3fd7836  push rax
00007f46e3fd7837  push rcx
00007f46e3fd7838  push rdx
00007f46e3fd7839  push rdi
00007f46e3fd783a  push rsi
00007f46e3fd783b  push r8
00007f46e3fd783d  push r9
00007f46e3fd783f  push r10
00007f46e3fd7841  push r11
00007f46e3fd7843  sub rsp, 0xF0
00007f46e3fd784a  vmovaps [rsp], xmm0
00007f46e3fd784f  vmovaps [rsp+0x10], xmm1
00007f46e3fd7855  vmovaps [rsp+0x20], xmm2
00007f46e3fd785b  vmovaps [rsp+0x30], xmm3
00007f46e3fd7861  vmovaps [rsp+0x40], xmm5
00007f46e3fd7867  vmovaps [rsp+0x50], xmm6
00007f46e3fd786d  vmovaps [rsp+0x60], xmm7
00007f46e3fd7873  vmovaps [rsp+0x70], xmm8
00007f46e3fd7879  vmovaps [rsp+0x80], xmm9
00007f46e3fd7882  vmovaps [rsp+0x90], xmm10
00007f46e3fd788b  vmovaps [rsp+0xA0], xmm11
00007f46e3fd7894  vmovaps [rsp+0xB0], xmm12
00007f46e3fd789d  vmovaps [rsp+0xC0], xmm13
00007f46e3fd78a6  vmovaps [rsp+0xD0], xmm14
00007f46e3fd78af  vmovaps [rsp+0xE0], xmm15
00007f46e3fd78b8  sub rsp, 0x30
00007f46e3fd78bc  movaps [rsp], xmm4
00007f46e3fd78c0  movaps [rsp+0x10], xmm15
00007f46e3fd78c6  movaps [rsp+0x20], xmm9
00007f46e3fd78cc  lea rdi, [rsp]
00007f46e3fd78d0  mov esi, 0x00
00007f46e3fd78d5  mov rax, 0x6238B185B530
00007f46e3fd78df  call rax
00007f46e3fd78e1  movaps xmm4, [rsp]
00007f46e3fd78e5  add rsp, 0x30
00007f46e3fd78e9  vmovaps xmm0, [rsp]
00007f46e3fd78ee  vmovaps xmm1, [rsp+0x10]
00007f46e3fd78f4  vmovaps xmm2, [rsp+0x20]
00007f46e3fd78fa  vmovaps xmm3, [rsp+0x30]
00007f46e3fd7900  vmovaps xmm5, [rsp+0x40]
00007f46e3fd7906  vmovaps xmm6, [rsp+0x50]
00007f46e3fd790c  vmovaps xmm7, [rsp+0x60]
00007f46e3fd7912  vmovaps xmm8, [rsp+0x70]
00007f46e3fd7918  vmovaps xmm9, [rsp+0x80]
00007f46e3fd7921  vmovaps xmm10, [rsp+0x90]
00007f46e3fd792a  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd7933  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd793c  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd7945  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd794e  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd7957  add rsp, 0xF0
00007f46e3fd795e  pop r11
00007f46e3fd7960  pop r10
00007f46e3fd7962  pop r9
00007f46e3fd7964  pop r8
00007f46e3fd7966  pop rsi
00007f46e3fd7967  pop rdi
00007f46e3fd7968  pop rdx
00007f46e3fd7969  pop rcx
00007f46e3fd796a  pop rax
00007f46e3fd796b  add rsp, 0x08
00007f46e3fd796f  jmp 0x00007F46E3FD5CF9
00007f46e3fd7974  call 0x00007F46E3EE5820
00007f46e3fd7979  jmp 0x00007F46E3FD5D06
00007f46e3fd797e  sub rsp, 0x08
00007f46e3fd7982  push rax
00007f46e3fd7983  push rcx
00007f46e3fd7984  push rdx
00007f46e3fd7985  push rdi
00007f46e3fd7986  push rsi
00007f46e3fd7987  push r8
00007f46e3fd7989  push r9
00007f46e3fd798b  push r10
00007f46e3fd798d  push r11
00007f46e3fd798f  sub rsp, 0xF0
00007f46e3fd7996  vmovaps [rsp], xmm0
00007f46e3fd799b  vmovaps [rsp+0x10], xmm1
00007f46e3fd79a1  vmovaps [rsp+0x20], xmm2
00007f46e3fd79a7  vmovaps [rsp+0x30], xmm4
00007f46e3fd79ad  vmovaps [rsp+0x40], xmm5
00007f46e3fd79b3  vmovaps [rsp+0x50], xmm6
00007f46e3fd79b9  vmovaps [rsp+0x60], xmm7
00007f46e3fd79bf  vmovaps [rsp+0x70], xmm8
00007f46e3fd79c5  vmovaps [rsp+0x80], xmm9
00007f46e3fd79ce  vmovaps [rsp+0x90], xmm10
00007f46e3fd79d7  vmovaps [rsp+0xA0], xmm11
00007f46e3fd79e0  vmovaps [rsp+0xB0], xmm12
00007f46e3fd79e9  vmovaps [rsp+0xC0], xmm13
00007f46e3fd79f2  vmovaps [rsp+0xD0], xmm14
00007f46e3fd79fb  vmovaps [rsp+0xE0], xmm15
00007f46e3fd7a04  sub rsp, 0x30
00007f46e3fd7a08  movaps [rsp], xmm3
00007f46e3fd7a0c  movaps [rsp+0x10], xmm1
00007f46e3fd7a11  movaps [rsp+0x20], xmm9
00007f46e3fd7a17  lea rdi, [rsp]
00007f46e3fd7a1b  mov esi, 0x00
00007f46e3fd7a20  mov rax, 0x6238B185B530
00007f46e3fd7a2a  call rax
00007f46e3fd7a2c  movaps xmm3, [rsp]
00007f46e3fd7a30  add rsp, 0x30
00007f46e3fd7a34  vmovaps xmm0, [rsp]
00007f46e3fd7a39  vmovaps xmm1, [rsp+0x10]
00007f46e3fd7a3f  vmovaps xmm2, [rsp+0x20]
00007f46e3fd7a45  vmovaps xmm4, [rsp+0x30]
00007f46e3fd7a4b  vmovaps xmm5, [rsp+0x40]
00007f46e3fd7a51  vmovaps xmm6, [rsp+0x50]
00007f46e3fd7a57  vmovaps xmm7, [rsp+0x60]
00007f46e3fd7a5d  vmovaps xmm8, [rsp+0x70]
00007f46e3fd7a63  vmovaps xmm9, [rsp+0x80]
00007f46e3fd7a6c  vmovaps xmm10, [rsp+0x90]
00007f46e3fd7a75  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd7a7e  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd7a87  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd7a90  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd7a99  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd7aa2  add rsp, 0xF0
00007f46e3fd7aa9  pop r11
00007f46e3fd7aab  pop r10
00007f46e3fd7aad  pop r9
00007f46e3fd7aaf  pop r8
00007f46e3fd7ab1  pop rsi
00007f46e3fd7ab2  pop rdi
00007f46e3fd7ab3  pop rdx
00007f46e3fd7ab4  pop rcx
00007f46e3fd7ab5  pop rax
00007f46e3fd7ab6  add rsp, 0x08
00007f46e3fd7aba  jmp 0x00007F46E3FD5D43
00007f46e3fd7abf  sub rsp, 0x08
00007f46e3fd7ac3  push rax
00007f46e3fd7ac4  push rcx
00007f46e3fd7ac5  push rdx
00007f46e3fd7ac6  push rdi
00007f46e3fd7ac7  push rsi
00007f46e3fd7ac8  push r8
00007f46e3fd7aca  push r9
00007f46e3fd7acc  push r10
00007f46e3fd7ace  push r11
00007f46e3fd7ad0  sub rsp, 0xF0
00007f46e3fd7ad7  vmovaps [rsp], xmm0
00007f46e3fd7adc  vmovaps [rsp+0x10], xmm2
00007f46e3fd7ae2  vmovaps [rsp+0x20], xmm3
00007f46e3fd7ae8  vmovaps [rsp+0x30], xmm4
00007f46e3fd7aee  vmovaps [rsp+0x40], xmm5
00007f46e3fd7af4  vmovaps [rsp+0x50], xmm6
00007f46e3fd7afa  vmovaps [rsp+0x60], xmm7
00007f46e3fd7b00  vmovaps [rsp+0x70], xmm8
00007f46e3fd7b06  vmovaps [rsp+0x80], xmm9
00007f46e3fd7b0f  vmovaps [rsp+0x90], xmm10
00007f46e3fd7b18  vmovaps [rsp+0xA0], xmm11
00007f46e3fd7b21  vmovaps [rsp+0xB0], xmm12
00007f46e3fd7b2a  vmovaps [rsp+0xC0], xmm13
00007f46e3fd7b33  vmovaps [rsp+0xD0], xmm14
00007f46e3fd7b3c  vmovaps [rsp+0xE0], xmm15
00007f46e3fd7b45  sub rsp, 0x30
00007f46e3fd7b49  movaps [rsp], xmm1
00007f46e3fd7b4d  movaps [rsp+0x10], xmm15
00007f46e3fd7b53  movaps [rsp+0x20], xmm9
00007f46e3fd7b59  lea rdi, [rsp]
00007f46e3fd7b5d  mov esi, 0x00
00007f46e3fd7b62  mov rax, 0x6238B185B530
00007f46e3fd7b6c  call rax
00007f46e3fd7b6e  movaps xmm1, [rsp]
00007f46e3fd7b72  add rsp, 0x30
00007f46e3fd7b76  vmovaps xmm0, [rsp]
00007f46e3fd7b7b  vmovaps xmm2, [rsp+0x10]
00007f46e3fd7b81  vmovaps xmm3, [rsp+0x20]
00007f46e3fd7b87  vmovaps xmm4, [rsp+0x30]
00007f46e3fd7b8d  vmovaps xmm5, [rsp+0x40]
00007f46e3fd7b93  vmovaps xmm6, [rsp+0x50]
00007f46e3fd7b99  vmovaps xmm7, [rsp+0x60]
00007f46e3fd7b9f  vmovaps xmm8, [rsp+0x70]
00007f46e3fd7ba5  vmovaps xmm9, [rsp+0x80]
00007f46e3fd7bae  vmovaps xmm10, [rsp+0x90]
00007f46e3fd7bb7  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd7bc0  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd7bc9  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd7bd2  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd7bdb  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd7be4  add rsp, 0xF0
00007f46e3fd7beb  pop r11
00007f46e3fd7bed  pop r10
00007f46e3fd7bef  pop r9
00007f46e3fd7bf1  pop r8
00007f46e3fd7bf3  pop rsi
00007f46e3fd7bf4  pop rdi
00007f46e3fd7bf5  pop rdx
00007f46e3fd7bf6  pop rcx
00007f46e3fd7bf7  pop rax
00007f46e3fd7bf8  add rsp, 0x08
00007f46e3fd7bfc  jmp 0x00007F46E3FD5DCB
00007f46e3fd7c01  call 0x00007F46E3EE5820
00007f46e3fd7c06  jmp 0x00007F46E3FD5DD8
00007f46e3fd7c0b  sub rsp, 0x08
00007f46e3fd7c0f  push rax
00007f46e3fd7c10  push rcx
00007f46e3fd7c11  push rdx
00007f46e3fd7c12  push rdi
00007f46e3fd7c13  push rsi
00007f46e3fd7c14  push r8
00007f46e3fd7c16  push r9
00007f46e3fd7c18  push r10
00007f46e3fd7c1a  push r11
00007f46e3fd7c1c  sub rsp, 0xF0
00007f46e3fd7c23  vmovaps [rsp], xmm0
00007f46e3fd7c28  vmovaps [rsp+0x10], xmm2
00007f46e3fd7c2e  vmovaps [rsp+0x20], xmm3
00007f46e3fd7c34  vmovaps [rsp+0x30], xmm4
00007f46e3fd7c3a  vmovaps [rsp+0x40], xmm5
00007f46e3fd7c40  vmovaps [rsp+0x50], xmm6
00007f46e3fd7c46  vmovaps [rsp+0x60], xmm7
00007f46e3fd7c4c  vmovaps [rsp+0x70], xmm8
00007f46e3fd7c52  vmovaps [rsp+0x80], xmm9
00007f46e3fd7c5b  vmovaps [rsp+0x90], xmm10
00007f46e3fd7c64  vmovaps [rsp+0xA0], xmm11
00007f46e3fd7c6d  vmovaps [rsp+0xB0], xmm12
00007f46e3fd7c76  vmovaps [rsp+0xC0], xmm13
00007f46e3fd7c7f  vmovaps [rsp+0xD0], xmm14
00007f46e3fd7c88  vmovaps [rsp+0xE0], xmm15
00007f46e3fd7c91  sub rsp, 0x30
00007f46e3fd7c95  movaps [rsp], xmm1
00007f46e3fd7c99  movaps [rsp+0x10], xmm5
00007f46e3fd7c9e  movaps [rsp+0x20], xmm7
00007f46e3fd7ca3  lea rdi, [rsp]
00007f46e3fd7ca7  mov esi, 0x00
00007f46e3fd7cac  mov rax, 0x6238B185B530
00007f46e3fd7cb6  call rax
00007f46e3fd7cb8  movaps xmm1, [rsp]
00007f46e3fd7cbc  add rsp, 0x30
00007f46e3fd7cc0  vmovaps xmm0, [rsp]
00007f46e3fd7cc5  vmovaps xmm2, [rsp+0x10]
00007f46e3fd7ccb  vmovaps xmm3, [rsp+0x20]
00007f46e3fd7cd1  vmovaps xmm4, [rsp+0x30]
00007f46e3fd7cd7  vmovaps xmm5, [rsp+0x40]
00007f46e3fd7cdd  vmovaps xmm6, [rsp+0x50]
00007f46e3fd7ce3  vmovaps xmm7, [rsp+0x60]
00007f46e3fd7ce9  vmovaps xmm8, [rsp+0x70]
00007f46e3fd7cef  vmovaps xmm9, [rsp+0x80]
00007f46e3fd7cf8  vmovaps xmm10, [rsp+0x90]
00007f46e3fd7d01  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd7d0a  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd7d13  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd7d1c  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd7d25  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd7d2e  add rsp, 0xF0
00007f46e3fd7d35  pop r11
00007f46e3fd7d37  pop r10
00007f46e3fd7d39  pop r9
00007f46e3fd7d3b  pop r8
00007f46e3fd7d3d  pop rsi
00007f46e3fd7d3e  pop rdi
00007f46e3fd7d3f  pop rdx
00007f46e3fd7d40  pop rcx
00007f46e3fd7d41  pop rax
00007f46e3fd7d42  add rsp, 0x08
00007f46e3fd7d46  jmp 0x00007F46E3FD5E7D
00007f46e3fd7d4b  sub rsp, 0x08
00007f46e3fd7d4f  push rax
00007f46e3fd7d50  push rcx
00007f46e3fd7d51  push rdx
00007f46e3fd7d52  push rdi
00007f46e3fd7d53  push rsi
00007f46e3fd7d54  push r8
00007f46e3fd7d56  push r9
00007f46e3fd7d58  push r10
00007f46e3fd7d5a  push r11
00007f46e3fd7d5c  sub rsp, 0xF0
00007f46e3fd7d63  vmovaps [rsp], xmm0
00007f46e3fd7d68  vmovaps [rsp+0x10], xmm1
00007f46e3fd7d6e  vmovaps [rsp+0x20], xmm2
00007f46e3fd7d74  vmovaps [rsp+0x30], xmm3
00007f46e3fd7d7a  vmovaps [rsp+0x40], xmm4
00007f46e3fd7d80  vmovaps [rsp+0x50], xmm5
00007f46e3fd7d86  vmovaps [rsp+0x60], xmm6
00007f46e3fd7d8c  vmovaps [rsp+0x70], xmm8
00007f46e3fd7d92  vmovaps [rsp+0x80], xmm9
00007f46e3fd7d9b  vmovaps [rsp+0x90], xmm10
00007f46e3fd7da4  vmovaps [rsp+0xA0], xmm11
00007f46e3fd7dad  vmovaps [rsp+0xB0], xmm12
00007f46e3fd7db6  vmovaps [rsp+0xC0], xmm13
00007f46e3fd7dbf  vmovaps [rsp+0xD0], xmm14
00007f46e3fd7dc8  vmovaps [rsp+0xE0], xmm15
00007f46e3fd7dd1  sub rsp, 0x30
00007f46e3fd7dd5  movaps [rsp], xmm7
00007f46e3fd7dd9  movaps [rsp+0x10], xmm5
00007f46e3fd7dde  movaps [rsp+0x20], xmm15
00007f46e3fd7de4  lea rdi, [rsp]
00007f46e3fd7de8  mov esi, 0x00
00007f46e3fd7ded  mov rax, 0x6238B185B530
00007f46e3fd7df7  call rax
00007f46e3fd7df9  movaps xmm7, [rsp]
00007f46e3fd7dfd  add rsp, 0x30
00007f46e3fd7e01  vmovaps xmm0, [rsp]
00007f46e3fd7e06  vmovaps xmm1, [rsp+0x10]
00007f46e3fd7e0c  vmovaps xmm2, [rsp+0x20]
00007f46e3fd7e12  vmovaps xmm3, [rsp+0x30]
00007f46e3fd7e18  vmovaps xmm4, [rsp+0x40]
00007f46e3fd7e1e  vmovaps xmm5, [rsp+0x50]
00007f46e3fd7e24  vmovaps xmm6, [rsp+0x60]
00007f46e3fd7e2a  vmovaps xmm8, [rsp+0x70]
00007f46e3fd7e30  vmovaps xmm9, [rsp+0x80]
00007f46e3fd7e39  vmovaps xmm10, [rsp+0x90]
00007f46e3fd7e42  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd7e4b  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd7e54  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd7e5d  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd7e66  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd7e6f  add rsp, 0xF0
00007f46e3fd7e76  pop r11
00007f46e3fd7e78  pop r10
00007f46e3fd7e7a  pop r9
00007f46e3fd7e7c  pop r8
00007f46e3fd7e7e  pop rsi
00007f46e3fd7e7f  pop rdi
00007f46e3fd7e80  pop rdx
00007f46e3fd7e81  pop rcx
00007f46e3fd7e82  pop rax
00007f46e3fd7e83  add rsp, 0x08
00007f46e3fd7e87  jmp 0x00007F46E3FD5EB3
00007f46e3fd7e8c  call 0x00007F46E3ED64F0
00007f46e3fd7e91  jmp 0x00007F46E3FD5EC0
00007f46e3fd7e96  sub rsp, 0x08
00007f46e3fd7e9a  push rax
00007f46e3fd7e9b  push rcx
00007f46e3fd7e9c  push rdx
00007f46e3fd7e9d  push rdi
00007f46e3fd7e9e  push rsi
00007f46e3fd7e9f  push r8
00007f46e3fd7ea1  push r9
00007f46e3fd7ea3  push r10
00007f46e3fd7ea5  push r11
00007f46e3fd7ea7  sub rsp, 0xF0
00007f46e3fd7eae  vmovaps [rsp], xmm0
00007f46e3fd7eb3  vmovaps [rsp+0x10], xmm1
00007f46e3fd7eb9  vmovaps [rsp+0x20], xmm2
00007f46e3fd7ebf  vmovaps [rsp+0x30], xmm3
00007f46e3fd7ec5  vmovaps [rsp+0x40], xmm4
00007f46e3fd7ecb  vmovaps [rsp+0x50], xmm5
00007f46e3fd7ed1  vmovaps [rsp+0x60], xmm6
00007f46e3fd7ed7  vmovaps [rsp+0x70], xmm7
00007f46e3fd7edd  vmovaps [rsp+0x80], xmm8
00007f46e3fd7ee6  vmovaps [rsp+0x90], xmm9
00007f46e3fd7eef  vmovaps [rsp+0xA0], xmm10
00007f46e3fd7ef8  vmovaps [rsp+0xB0], xmm11
00007f46e3fd7f01  vmovaps [rsp+0xC0], xmm12
00007f46e3fd7f0a  vmovaps [rsp+0xD0], xmm13
00007f46e3fd7f13  vmovaps [rsp+0xE0], xmm14
00007f46e3fd7f1c  sub rsp, 0x30
00007f46e3fd7f20  movaps [rsp], xmm15
00007f46e3fd7f25  movaps [rsp+0x10], xmm5
00007f46e3fd7f2a  movaps [rsp+0x20], xmm3
00007f46e3fd7f2f  lea rdi, [rsp]
00007f46e3fd7f33  mov esi, 0x00
00007f46e3fd7f38  mov rax, 0x6238B185B530
00007f46e3fd7f42  call rax
00007f46e3fd7f44  movaps xmm15, [rsp]
00007f46e3fd7f49  add rsp, 0x30
00007f46e3fd7f4d  vmovaps xmm0, [rsp]
00007f46e3fd7f52  vmovaps xmm1, [rsp+0x10]
00007f46e3fd7f58  vmovaps xmm2, [rsp+0x20]
00007f46e3fd7f5e  vmovaps xmm3, [rsp+0x30]
00007f46e3fd7f64  vmovaps xmm4, [rsp+0x40]
00007f46e3fd7f6a  vmovaps xmm5, [rsp+0x50]
00007f46e3fd7f70  vmovaps xmm6, [rsp+0x60]
00007f46e3fd7f76  vmovaps xmm7, [rsp+0x70]
00007f46e3fd7f7c  vmovaps xmm8, [rsp+0x80]
00007f46e3fd7f85  vmovaps xmm9, [rsp+0x90]
00007f46e3fd7f8e  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd7f97  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd7fa0  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd7fa9  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd7fb2  vmovaps xmm14, [rsp+0xE0]
00007f46e3fd7fbb  add rsp, 0xF0
00007f46e3fd7fc2  pop r11
00007f46e3fd7fc4  pop r10
00007f46e3fd7fc6  pop r9
00007f46e3fd7fc8  pop r8
00007f46e3fd7fca  pop rsi
00007f46e3fd7fcb  pop rdi
00007f46e3fd7fcc  pop rdx
00007f46e3fd7fcd  pop rcx
00007f46e3fd7fce  pop rax
00007f46e3fd7fcf  add rsp, 0x08
00007f46e3fd7fd3  jmp 0x00007F46E3FD5EE6
00007f46e3fd7fd8  sub rsp, 0x08
00007f46e3fd7fdc  push rax
00007f46e3fd7fdd  push rcx
00007f46e3fd7fde  push rdx
00007f46e3fd7fdf  push rdi
00007f46e3fd7fe0  push rsi
00007f46e3fd7fe1  push r8
00007f46e3fd7fe3  push r9
00007f46e3fd7fe5  push r10
00007f46e3fd7fe7  push r11
00007f46e3fd7fe9  sub rsp, 0xF0
00007f46e3fd7ff0  vmovaps [rsp], xmm0
00007f46e3fd7ff5  vmovaps [rsp+0x10], xmm2
00007f46e3fd7ffb  vmovaps [rsp+0x20], xmm3
00007f46e3fd8001  vmovaps [rsp+0x30], xmm4
00007f46e3fd8007  vmovaps [rsp+0x40], xmm5
00007f46e3fd800d  vmovaps [rsp+0x50], xmm6
00007f46e3fd8013  vmovaps [rsp+0x60], xmm7
00007f46e3fd8019  vmovaps [rsp+0x70], xmm8
00007f46e3fd801f  vmovaps [rsp+0x80], xmm9
00007f46e3fd8028  vmovaps [rsp+0x90], xmm10
00007f46e3fd8031  vmovaps [rsp+0xA0], xmm11
00007f46e3fd803a  vmovaps [rsp+0xB0], xmm12
00007f46e3fd8043  vmovaps [rsp+0xC0], xmm13
00007f46e3fd804c  vmovaps [rsp+0xD0], xmm14
00007f46e3fd8055  vmovaps [rsp+0xE0], xmm15
00007f46e3fd805e  sub rsp, 0x30
00007f46e3fd8062  movaps [rsp], xmm1
00007f46e3fd8066  movaps [rsp+0x10], xmm5
00007f46e3fd806b  movaps [rsp+0x20], xmm4
00007f46e3fd8070  lea rdi, [rsp]
00007f46e3fd8074  mov esi, 0x00
00007f46e3fd8079  mov rax, 0x6238B185B530
00007f46e3fd8083  call rax
00007f46e3fd8085  movaps xmm1, [rsp]
00007f46e3fd8089  add rsp, 0x30
00007f46e3fd808d  vmovaps xmm0, [rsp]
00007f46e3fd8092  vmovaps xmm2, [rsp+0x10]
00007f46e3fd8098  vmovaps xmm3, [rsp+0x20]
00007f46e3fd809e  vmovaps xmm4, [rsp+0x30]
00007f46e3fd80a4  vmovaps xmm5, [rsp+0x40]
00007f46e3fd80aa  vmovaps xmm6, [rsp+0x50]
00007f46e3fd80b0  vmovaps xmm7, [rsp+0x60]
00007f46e3fd80b6  vmovaps xmm8, [rsp+0x70]
00007f46e3fd80bc  vmovaps xmm9, [rsp+0x80]
00007f46e3fd80c5  vmovaps xmm10, [rsp+0x90]
00007f46e3fd80ce  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd80d7  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd80e0  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd80e9  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd80f2  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd80fb  add rsp, 0xF0
00007f46e3fd8102  pop r11
00007f46e3fd8104  pop r10
00007f46e3fd8106  pop r9
00007f46e3fd8108  pop r8
00007f46e3fd810a  pop rsi
00007f46e3fd810b  pop rdi
00007f46e3fd810c  pop rdx
00007f46e3fd810d  pop rcx
00007f46e3fd810e  pop rax
00007f46e3fd810f  add rsp, 0x08
00007f46e3fd8113  jmp 0x00007F46E3FD5F06
00007f46e3fd8118  sub rsp, 0x08
00007f46e3fd811c  push rax
00007f46e3fd811d  push rcx
00007f46e3fd811e  push rdx
00007f46e3fd811f  push rdi
00007f46e3fd8120  push rsi
00007f46e3fd8121  push r8
00007f46e3fd8123  push r9
00007f46e3fd8125  push r10
00007f46e3fd8127  push r11
00007f46e3fd8129  sub rsp, 0xF0
00007f46e3fd8130  vmovaps [rsp], xmm0
00007f46e3fd8135  vmovaps [rsp+0x10], xmm1
00007f46e3fd813b  vmovaps [rsp+0x20], xmm2
00007f46e3fd8141  vmovaps [rsp+0x30], xmm3
00007f46e3fd8147  vmovaps [rsp+0x40], xmm5
00007f46e3fd814d  vmovaps [rsp+0x50], xmm6
00007f46e3fd8153  vmovaps [rsp+0x60], xmm7
00007f46e3fd8159  vmovaps [rsp+0x70], xmm8
00007f46e3fd815f  vmovaps [rsp+0x80], xmm9
00007f46e3fd8168  vmovaps [rsp+0x90], xmm10
00007f46e3fd8171  vmovaps [rsp+0xA0], xmm11
00007f46e3fd817a  vmovaps [rsp+0xB0], xmm12
00007f46e3fd8183  vmovaps [rsp+0xC0], xmm13
00007f46e3fd818c  vmovaps [rsp+0xD0], xmm14
00007f46e3fd8195  vmovaps [rsp+0xE0], xmm15
00007f46e3fd819e  sub rsp, 0x30
00007f46e3fd81a2  movaps [rsp], xmm4
00007f46e3fd81a6  movaps [rsp+0x10], xmm3
00007f46e3fd81ab  movaps [rsp+0x20], xmm5
00007f46e3fd81b0  lea rdi, [rsp]
00007f46e3fd81b4  mov esi, 0x00
00007f46e3fd81b9  mov rax, 0x6238B185B530
00007f46e3fd81c3  call rax
00007f46e3fd81c5  movaps xmm4, [rsp]
00007f46e3fd81c9  add rsp, 0x30
00007f46e3fd81cd  vmovaps xmm0, [rsp]
00007f46e3fd81d2  vmovaps xmm1, [rsp+0x10]
00007f46e3fd81d8  vmovaps xmm2, [rsp+0x20]
00007f46e3fd81de  vmovaps xmm3, [rsp+0x30]
00007f46e3fd81e4  vmovaps xmm5, [rsp+0x40]
00007f46e3fd81ea  vmovaps xmm6, [rsp+0x50]
00007f46e3fd81f0  vmovaps xmm7, [rsp+0x60]
00007f46e3fd81f6  vmovaps xmm8, [rsp+0x70]
00007f46e3fd81fc  vmovaps xmm9, [rsp+0x80]
00007f46e3fd8205  vmovaps xmm10, [rsp+0x90]
00007f46e3fd820e  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd8217  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd8220  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd8229  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd8232  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd823b  add rsp, 0xF0
00007f46e3fd8242  pop r11
00007f46e3fd8244  pop r10
00007f46e3fd8246  pop r9
00007f46e3fd8248  pop r8
00007f46e3fd824a  pop rsi
00007f46e3fd824b  pop rdi
00007f46e3fd824c  pop rdx
00007f46e3fd824d  pop rcx
00007f46e3fd824e  pop rax
00007f46e3fd824f  add rsp, 0x08
00007f46e3fd8253  jmp 0x00007F46E3FD5F54
00007f46e3fd8258  call 0x00007F46E3ED64F0
00007f46e3fd825d  jmp 0x00007F46E3FD5F61
00007f46e3fd8262  sub rsp, 0x08
00007f46e3fd8266  push rax
00007f46e3fd8267  push rcx
00007f46e3fd8268  push rdx
00007f46e3fd8269  push rdi
00007f46e3fd826a  push rsi
00007f46e3fd826b  push r8
00007f46e3fd826d  push r9
00007f46e3fd826f  push r10
00007f46e3fd8271  push r11
00007f46e3fd8273  sub rsp, 0xF0
00007f46e3fd827a  vmovaps [rsp], xmm0
00007f46e3fd827f  vmovaps [rsp+0x10], xmm1
00007f46e3fd8285  vmovaps [rsp+0x20], xmm2
00007f46e3fd828b  vmovaps [rsp+0x30], xmm3
00007f46e3fd8291  vmovaps [rsp+0x40], xmm4
00007f46e3fd8297  vmovaps [rsp+0x50], xmm6
00007f46e3fd829d  vmovaps [rsp+0x60], xmm7
00007f46e3fd82a3  vmovaps [rsp+0x70], xmm8
00007f46e3fd82a9  vmovaps [rsp+0x80], xmm9
00007f46e3fd82b2  vmovaps [rsp+0x90], xmm10
00007f46e3fd82bb  vmovaps [rsp+0xA0], xmm11
00007f46e3fd82c4  vmovaps [rsp+0xB0], xmm12
00007f46e3fd82cd  vmovaps [rsp+0xC0], xmm13
00007f46e3fd82d6  vmovaps [rsp+0xD0], xmm14
00007f46e3fd82df  vmovaps [rsp+0xE0], xmm15
00007f46e3fd82e8  sub rsp, 0x30
00007f46e3fd82ec  movaps [rsp], xmm5
00007f46e3fd82f0  movaps [rsp+0x10], xmm6
00007f46e3fd82f5  movaps [rsp+0x20], xmm3
00007f46e3fd82fa  lea rdi, [rsp]
00007f46e3fd82fe  mov esi, 0x00
00007f46e3fd8303  mov rax, 0x6238B185B530
00007f46e3fd830d  call rax
00007f46e3fd830f  movaps xmm5, [rsp]
00007f46e3fd8313  add rsp, 0x30
00007f46e3fd8317  vmovaps xmm0, [rsp]
00007f46e3fd831c  vmovaps xmm1, [rsp+0x10]
00007f46e3fd8322  vmovaps xmm2, [rsp+0x20]
00007f46e3fd8328  vmovaps xmm3, [rsp+0x30]
00007f46e3fd832e  vmovaps xmm4, [rsp+0x40]
00007f46e3fd8334  vmovaps xmm6, [rsp+0x50]
00007f46e3fd833a  vmovaps xmm7, [rsp+0x60]
00007f46e3fd8340  vmovaps xmm8, [rsp+0x70]
00007f46e3fd8346  vmovaps xmm9, [rsp+0x80]
00007f46e3fd834f  vmovaps xmm10, [rsp+0x90]
00007f46e3fd8358  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd8361  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd836a  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd8373  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd837c  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd8385  add rsp, 0xF0
00007f46e3fd838c  pop r11
00007f46e3fd838e  pop r10
00007f46e3fd8390  pop r9
00007f46e3fd8392  pop r8
00007f46e3fd8394  pop rsi
00007f46e3fd8395  pop rdi
00007f46e3fd8396  pop rdx
00007f46e3fd8397  pop rcx
00007f46e3fd8398  pop rax
00007f46e3fd8399  add rsp, 0x08
00007f46e3fd839d  jmp 0x00007F46E3FD5F87
00007f46e3fd83a2  sub rsp, 0x08
00007f46e3fd83a6  push rax
00007f46e3fd83a7  push rcx
00007f46e3fd83a8  push rdx
00007f46e3fd83a9  push rdi
00007f46e3fd83aa  push rsi
00007f46e3fd83ab  push r8
00007f46e3fd83ad  push r9
00007f46e3fd83af  push r10
00007f46e3fd83b1  push r11
00007f46e3fd83b3  sub rsp, 0xF0
00007f46e3fd83ba  vmovaps [rsp], xmm0
00007f46e3fd83bf  vmovaps [rsp+0x10], xmm1
00007f46e3fd83c5  vmovaps [rsp+0x20], xmm2
00007f46e3fd83cb  vmovaps [rsp+0x30], xmm3
00007f46e3fd83d1  vmovaps [rsp+0x40], xmm4
00007f46e3fd83d7  vmovaps [rsp+0x50], xmm5
00007f46e3fd83dd  vmovaps [rsp+0x60], xmm7
00007f46e3fd83e3  vmovaps [rsp+0x70], xmm8
00007f46e3fd83e9  vmovaps [rsp+0x80], xmm9
00007f46e3fd83f2  vmovaps [rsp+0x90], xmm10
00007f46e3fd83fb  vmovaps [rsp+0xA0], xmm11
00007f46e3fd8404  vmovaps [rsp+0xB0], xmm12
00007f46e3fd840d  vmovaps [rsp+0xC0], xmm13
00007f46e3fd8416  vmovaps [rsp+0xD0], xmm14
00007f46e3fd841f  vmovaps [rsp+0xE0], xmm15
00007f46e3fd8428  sub rsp, 0x30
00007f46e3fd842c  movaps [rsp], xmm6
00007f46e3fd8430  movaps [rsp+0x10], xmm9
00007f46e3fd8436  movaps [rsp+0x20], xmm1
00007f46e3fd843b  lea rdi, [rsp]
00007f46e3fd843f  mov esi, 0x00
00007f46e3fd8444  mov rax, 0x6238B185B530
00007f46e3fd844e  call rax
00007f46e3fd8450  movaps xmm6, [rsp]
00007f46e3fd8454  add rsp, 0x30
00007f46e3fd8458  vmovaps xmm0, [rsp]
00007f46e3fd845d  vmovaps xmm1, [rsp+0x10]
00007f46e3fd8463  vmovaps xmm2, [rsp+0x20]
00007f46e3fd8469  vmovaps xmm3, [rsp+0x30]
00007f46e3fd846f  vmovaps xmm4, [rsp+0x40]
00007f46e3fd8475  vmovaps xmm5, [rsp+0x50]
00007f46e3fd847b  vmovaps xmm7, [rsp+0x60]
00007f46e3fd8481  vmovaps xmm8, [rsp+0x70]
00007f46e3fd8487  vmovaps xmm9, [rsp+0x80]
00007f46e3fd8490  vmovaps xmm10, [rsp+0x90]
00007f46e3fd8499  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd84a2  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd84ab  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd84b4  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd84bd  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd84c6  add rsp, 0xF0
00007f46e3fd84cd  pop r11
00007f46e3fd84cf  pop r10
00007f46e3fd84d1  pop r9
00007f46e3fd84d3  pop r8
00007f46e3fd84d5  pop rsi
00007f46e3fd84d6  pop rdi
00007f46e3fd84d7  pop rdx
00007f46e3fd84d8  pop rcx
00007f46e3fd84d9  pop rax
00007f46e3fd84da  add rsp, 0x08
00007f46e3fd84de  jmp 0x00007F46E3FD5FAB
00007f46e3fd84e3  sub rsp, 0x08
00007f46e3fd84e7  push rax
00007f46e3fd84e8  push rcx
00007f46e3fd84e9  push rdx
00007f46e3fd84ea  push rdi
00007f46e3fd84eb  push rsi
00007f46e3fd84ec  push r8
00007f46e3fd84ee  push r9
00007f46e3fd84f0  push r10
00007f46e3fd84f2  push r11
00007f46e3fd84f4  sub rsp, 0xF0
00007f46e3fd84fb  vmovaps [rsp], xmm0
00007f46e3fd8500  vmovaps [rsp+0x10], xmm1
00007f46e3fd8506  vmovaps [rsp+0x20], xmm2
00007f46e3fd850c  vmovaps [rsp+0x30], xmm3
00007f46e3fd8512  vmovaps [rsp+0x40], xmm4
00007f46e3fd8518  vmovaps [rsp+0x50], xmm5
00007f46e3fd851e  vmovaps [rsp+0x60], xmm6
00007f46e3fd8524  vmovaps [rsp+0x70], xmm7
00007f46e3fd852a  vmovaps [rsp+0x80], xmm8
00007f46e3fd8533  vmovaps [rsp+0x90], xmm10
00007f46e3fd853c  vmovaps [rsp+0xA0], xmm11
00007f46e3fd8545  vmovaps [rsp+0xB0], xmm12
00007f46e3fd854e  vmovaps [rsp+0xC0], xmm13
00007f46e3fd8557  vmovaps [rsp+0xD0], xmm14
00007f46e3fd8560  vmovaps [rsp+0xE0], xmm15
00007f46e3fd8569  sub rsp, 0x30
00007f46e3fd856d  movaps [rsp], xmm9
00007f46e3fd8572  movaps [rsp+0x10], xmm3
00007f46e3fd8577  movaps [rsp+0x20], xmm1
00007f46e3fd857c  lea rdi, [rsp]
00007f46e3fd8580  mov esi, 0x00
00007f46e3fd8585  mov rax, 0x6238B185B530
00007f46e3fd858f  call rax
00007f46e3fd8591  movaps xmm9, [rsp]
00007f46e3fd8596  add rsp, 0x30
00007f46e3fd859a  vmovaps xmm0, [rsp]
00007f46e3fd859f  vmovaps xmm1, [rsp+0x10]
00007f46e3fd85a5  vmovaps xmm2, [rsp+0x20]
00007f46e3fd85ab  vmovaps xmm3, [rsp+0x30]
00007f46e3fd85b1  vmovaps xmm4, [rsp+0x40]
00007f46e3fd85b7  vmovaps xmm5, [rsp+0x50]
00007f46e3fd85bd  vmovaps xmm6, [rsp+0x60]
00007f46e3fd85c3  vmovaps xmm7, [rsp+0x70]
00007f46e3fd85c9  vmovaps xmm8, [rsp+0x80]
00007f46e3fd85d2  vmovaps xmm10, [rsp+0x90]
00007f46e3fd85db  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd85e4  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd85ed  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd85f6  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd85ff  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd8608  add rsp, 0xF0
00007f46e3fd860f  pop r11
00007f46e3fd8611  pop r10
00007f46e3fd8613  pop r9
00007f46e3fd8615  pop r8
00007f46e3fd8617  pop rsi
00007f46e3fd8618  pop rdi
00007f46e3fd8619  pop rdx
00007f46e3fd861a  pop rcx
00007f46e3fd861b  pop rax
00007f46e3fd861c  add rsp, 0x08
00007f46e3fd8620  jmp 0x00007F46E3FD5FF7
00007f46e3fd8625  call 0x00007F46E3ED64F0
00007f46e3fd862a  jmp 0x00007F46E3FD6004
00007f46e3fd862f  sub rsp, 0x08
00007f46e3fd8633  push rax
00007f46e3fd8634  push rcx
00007f46e3fd8635  push rdx
00007f46e3fd8636  push rdi
00007f46e3fd8637  push rsi
00007f46e3fd8638  push r8
00007f46e3fd863a  push r9
00007f46e3fd863c  push r10
00007f46e3fd863e  push r11
00007f46e3fd8640  sub rsp, 0xF0
00007f46e3fd8647  vmovaps [rsp], xmm0
00007f46e3fd864c  vmovaps [rsp+0x10], xmm1
00007f46e3fd8652  vmovaps [rsp+0x20], xmm2
00007f46e3fd8658  vmovaps [rsp+0x30], xmm3
00007f46e3fd865e  vmovaps [rsp+0x40], xmm4
00007f46e3fd8664  vmovaps [rsp+0x50], xmm5
00007f46e3fd866a  vmovaps [rsp+0x60], xmm6
00007f46e3fd8670  vmovaps [rsp+0x70], xmm7
00007f46e3fd8676  vmovaps [rsp+0x80], xmm8
00007f46e3fd867f  vmovaps [rsp+0x90], xmm9
00007f46e3fd8688  vmovaps [rsp+0xA0], xmm10
00007f46e3fd8691  vmovaps [rsp+0xB0], xmm11
00007f46e3fd869a  vmovaps [rsp+0xC0], xmm12
00007f46e3fd86a3  vmovaps [rsp+0xD0], xmm13
00007f46e3fd86ac  vmovaps [rsp+0xE0], xmm14
00007f46e3fd86b5  sub rsp, 0x30
00007f46e3fd86b9  movaps [rsp], xmm15
00007f46e3fd86be  movaps [rsp+0x10], xmm3
00007f46e3fd86c3  movaps [rsp+0x20], xmm7
00007f46e3fd86c8  lea rdi, [rsp]
00007f46e3fd86cc  mov esi, 0x00
00007f46e3fd86d1  mov rax, 0x6238B185B530
00007f46e3fd86db  call rax
00007f46e3fd86dd  movaps xmm15, [rsp]
00007f46e3fd86e2  add rsp, 0x30
00007f46e3fd86e6  vmovaps xmm0, [rsp]
00007f46e3fd86eb  vmovaps xmm1, [rsp+0x10]
00007f46e3fd86f1  vmovaps xmm2, [rsp+0x20]
00007f46e3fd86f7  vmovaps xmm3, [rsp+0x30]
00007f46e3fd86fd  vmovaps xmm4, [rsp+0x40]
00007f46e3fd8703  vmovaps xmm5, [rsp+0x50]
00007f46e3fd8709  vmovaps xmm6, [rsp+0x60]
00007f46e3fd870f  vmovaps xmm7, [rsp+0x70]
00007f46e3fd8715  vmovaps xmm8, [rsp+0x80]
00007f46e3fd871e  vmovaps xmm9, [rsp+0x90]
00007f46e3fd8727  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd8730  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd8739  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd8742  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd874b  vmovaps xmm14, [rsp+0xE0]
00007f46e3fd8754  add rsp, 0xF0
00007f46e3fd875b  pop r11
00007f46e3fd875d  pop r10
00007f46e3fd875f  pop r9
00007f46e3fd8761  pop r8
00007f46e3fd8763  pop rsi
00007f46e3fd8764  pop rdi
00007f46e3fd8765  pop rdx
00007f46e3fd8766  pop rcx
00007f46e3fd8767  pop rax
00007f46e3fd8768  add rsp, 0x08
00007f46e3fd876c  jmp 0x00007F46E3FD6030
00007f46e3fd8771  sub rsp, 0x08
00007f46e3fd8775  push rax
00007f46e3fd8776  push rcx
00007f46e3fd8777  push rdx
00007f46e3fd8778  push rdi
00007f46e3fd8779  push rsi
00007f46e3fd877a  push r8
00007f46e3fd877c  push r9
00007f46e3fd877e  push r10
00007f46e3fd8780  push r11
00007f46e3fd8782  sub rsp, 0xF0
00007f46e3fd8789  vmovaps [rsp], xmm0
00007f46e3fd878e  vmovaps [rsp+0x10], xmm1
00007f46e3fd8794  vmovaps [rsp+0x20], xmm2
00007f46e3fd879a  vmovaps [rsp+0x30], xmm4
00007f46e3fd87a0  vmovaps [rsp+0x40], xmm5
00007f46e3fd87a6  vmovaps [rsp+0x50], xmm6
00007f46e3fd87ac  vmovaps [rsp+0x60], xmm7
00007f46e3fd87b2  vmovaps [rsp+0x70], xmm8
00007f46e3fd87b8  vmovaps [rsp+0x80], xmm9
00007f46e3fd87c1  vmovaps [rsp+0x90], xmm10
00007f46e3fd87ca  vmovaps [rsp+0xA0], xmm11
00007f46e3fd87d3  vmovaps [rsp+0xB0], xmm12
00007f46e3fd87dc  vmovaps [rsp+0xC0], xmm13
00007f46e3fd87e5  vmovaps [rsp+0xD0], xmm14
00007f46e3fd87ee  vmovaps [rsp+0xE0], xmm15
00007f46e3fd87f7  sub rsp, 0x30
00007f46e3fd87fb  movaps [rsp], xmm3
00007f46e3fd87ff  movaps [rsp+0x10], xmm1
00007f46e3fd8804  movaps [rsp+0x20], xmm15
00007f46e3fd880a  lea rdi, [rsp]
00007f46e3fd880e  mov esi, 0x00
00007f46e3fd8813  mov rax, 0x6238B185B530
00007f46e3fd881d  call rax
00007f46e3fd881f  movaps xmm3, [rsp]
00007f46e3fd8823  add rsp, 0x30
00007f46e3fd8827  vmovaps xmm0, [rsp]
00007f46e3fd882c  vmovaps xmm1, [rsp+0x10]
00007f46e3fd8832  vmovaps xmm2, [rsp+0x20]
00007f46e3fd8838  vmovaps xmm4, [rsp+0x30]
00007f46e3fd883e  vmovaps xmm5, [rsp+0x40]
00007f46e3fd8844  vmovaps xmm6, [rsp+0x50]
00007f46e3fd884a  vmovaps xmm7, [rsp+0x60]
00007f46e3fd8850  vmovaps xmm8, [rsp+0x70]
00007f46e3fd8856  vmovaps xmm9, [rsp+0x80]
00007f46e3fd885f  vmovaps xmm10, [rsp+0x90]
00007f46e3fd8868  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd8871  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd887a  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd8883  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd888c  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd8895  add rsp, 0xF0
00007f46e3fd889c  pop r11
00007f46e3fd889e  pop r10
00007f46e3fd88a0  pop r9
00007f46e3fd88a2  pop r8
00007f46e3fd88a4  pop rsi
00007f46e3fd88a5  pop rdi
00007f46e3fd88a6  pop rdx
00007f46e3fd88a7  pop rcx
00007f46e3fd88a8  pop rax
00007f46e3fd88a9  add rsp, 0x08
00007f46e3fd88ad  jmp 0x00007F46E3FD60BF
00007f46e3fd88b2  call 0x00007F46E3ED64F0
00007f46e3fd88b7  jmp 0x00007F46E3FD60C9
00007f46e3fd88bc  sub rsp, 0x08
00007f46e3fd88c0  push rax
00007f46e3fd88c1  push rcx
00007f46e3fd88c2  push rdx
00007f46e3fd88c3  push rdi
00007f46e3fd88c4  push rsi
00007f46e3fd88c5  push r8
00007f46e3fd88c7  push r9
00007f46e3fd88c9  push r10
00007f46e3fd88cb  push r11
00007f46e3fd88cd  sub rsp, 0xF0
00007f46e3fd88d4  vmovaps [rsp], xmm0
00007f46e3fd88d9  vmovaps [rsp+0x10], xmm1
00007f46e3fd88df  vmovaps [rsp+0x20], xmm2
00007f46e3fd88e5  vmovaps [rsp+0x30], xmm3
00007f46e3fd88eb  vmovaps [rsp+0x40], xmm4
00007f46e3fd88f1  vmovaps [rsp+0x50], xmm5
00007f46e3fd88f7  vmovaps [rsp+0x60], xmm6
00007f46e3fd88fd  vmovaps [rsp+0x70], xmm7
00007f46e3fd8903  vmovaps [rsp+0x80], xmm8
00007f46e3fd890c  vmovaps [rsp+0x90], xmm9
00007f46e3fd8915  vmovaps [rsp+0xA0], xmm10
00007f46e3fd891e  vmovaps [rsp+0xB0], xmm11
00007f46e3fd8927  vmovaps [rsp+0xC0], xmm12
00007f46e3fd8930  vmovaps [rsp+0xD0], xmm13
00007f46e3fd8939  vmovaps [rsp+0xE0], xmm14
00007f46e3fd8942  sub rsp, 0x30
00007f46e3fd8946  movaps [rsp], xmm15
00007f46e3fd894b  movaps [rsp+0x10], xmm14
00007f46e3fd8951  movaps [rsp+0x20], xmm4
00007f46e3fd8956  lea rdi, [rsp]
00007f46e3fd895a  mov esi, 0x00
00007f46e3fd895f  mov rax, 0x6238B185B530
00007f46e3fd8969  call rax
00007f46e3fd896b  movaps xmm15, [rsp]
00007f46e3fd8970  add rsp, 0x30
00007f46e3fd8974  vmovaps xmm0, [rsp]
00007f46e3fd8979  vmovaps xmm1, [rsp+0x10]
00007f46e3fd897f  vmovaps xmm2, [rsp+0x20]
00007f46e3fd8985  vmovaps xmm3, [rsp+0x30]
00007f46e3fd898b  vmovaps xmm4, [rsp+0x40]
00007f46e3fd8991  vmovaps xmm5, [rsp+0x50]
00007f46e3fd8997  vmovaps xmm6, [rsp+0x60]
00007f46e3fd899d  vmovaps xmm7, [rsp+0x70]
00007f46e3fd89a3  vmovaps xmm8, [rsp+0x80]
00007f46e3fd89ac  vmovaps xmm9, [rsp+0x90]
00007f46e3fd89b5  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd89be  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd89c7  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd89d0  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd89d9  vmovaps xmm14, [rsp+0xE0]
00007f46e3fd89e2  add rsp, 0xF0
00007f46e3fd89e9  pop r11
00007f46e3fd89eb  pop r10
00007f46e3fd89ed  pop r9
00007f46e3fd89ef  pop r8
00007f46e3fd89f1  pop rsi
00007f46e3fd89f2  pop rdi
00007f46e3fd89f3  pop rdx
00007f46e3fd89f4  pop rcx
00007f46e3fd89f5  pop rax
00007f46e3fd89f6  add rsp, 0x08
00007f46e3fd89fa  jmp 0x00007F46E3FD60F7
00007f46e3fd89ff  sub rsp, 0x08
00007f46e3fd8a03  push rax
00007f46e3fd8a04  push rcx
00007f46e3fd8a05  push rdx
00007f46e3fd8a06  push rdi
00007f46e3fd8a07  push rsi
00007f46e3fd8a08  push r8
00007f46e3fd8a0a  push r9
00007f46e3fd8a0c  push r10
00007f46e3fd8a0e  push r11
00007f46e3fd8a10  sub rsp, 0xF0
00007f46e3fd8a17  vmovaps [rsp], xmm0
00007f46e3fd8a1c  vmovaps [rsp+0x10], xmm1
00007f46e3fd8a22  vmovaps [rsp+0x20], xmm2
00007f46e3fd8a28  vmovaps [rsp+0x30], xmm3
00007f46e3fd8a2e  vmovaps [rsp+0x40], xmm4
00007f46e3fd8a34  vmovaps [rsp+0x50], xmm5
00007f46e3fd8a3a  vmovaps [rsp+0x60], xmm6
00007f46e3fd8a40  vmovaps [rsp+0x70], xmm7
00007f46e3fd8a46  vmovaps [rsp+0x80], xmm8
00007f46e3fd8a4f  vmovaps [rsp+0x90], xmm9
00007f46e3fd8a58  vmovaps [rsp+0xA0], xmm10
00007f46e3fd8a61  vmovaps [rsp+0xB0], xmm11
00007f46e3fd8a6a  vmovaps [rsp+0xC0], xmm12
00007f46e3fd8a73  vmovaps [rsp+0xD0], xmm13
00007f46e3fd8a7c  vmovaps [rsp+0xE0], xmm15
00007f46e3fd8a85  sub rsp, 0x30
00007f46e3fd8a89  movaps [rsp], xmm14
00007f46e3fd8a8e  movaps [rsp+0x10], xmm2
00007f46e3fd8a93  movaps [rsp+0x20], xmm1
00007f46e3fd8a98  lea rdi, [rsp]
00007f46e3fd8a9c  mov esi, 0x00
00007f46e3fd8aa1  mov rax, 0x6238B185B530
00007f46e3fd8aab  call rax
00007f46e3fd8aad  movaps xmm14, [rsp]
00007f46e3fd8ab2  add rsp, 0x30
00007f46e3fd8ab6  vmovaps xmm0, [rsp]
00007f46e3fd8abb  vmovaps xmm1, [rsp+0x10]
00007f46e3fd8ac1  vmovaps xmm2, [rsp+0x20]
00007f46e3fd8ac7  vmovaps xmm3, [rsp+0x30]
00007f46e3fd8acd  vmovaps xmm4, [rsp+0x40]
00007f46e3fd8ad3  vmovaps xmm5, [rsp+0x50]
00007f46e3fd8ad9  vmovaps xmm6, [rsp+0x60]
00007f46e3fd8adf  vmovaps xmm7, [rsp+0x70]
00007f46e3fd8ae5  vmovaps xmm8, [rsp+0x80]
00007f46e3fd8aee  vmovaps xmm9, [rsp+0x90]
00007f46e3fd8af7  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd8b00  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd8b09  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd8b12  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd8b1b  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd8b24  add rsp, 0xF0
00007f46e3fd8b2b  pop r11
00007f46e3fd8b2d  pop r10
00007f46e3fd8b2f  pop r9
00007f46e3fd8b31  pop r8
00007f46e3fd8b33  pop rsi
00007f46e3fd8b34  pop rdi
00007f46e3fd8b35  pop rdx
00007f46e3fd8b36  pop rcx
00007f46e3fd8b37  pop rax
00007f46e3fd8b38  add rsp, 0x08
00007f46e3fd8b3c  jmp 0x00007F46E3FD611D
00007f46e3fd8b41  sub rsp, 0x08
00007f46e3fd8b45  push rax
00007f46e3fd8b46  push rcx
00007f46e3fd8b47  push rdx
00007f46e3fd8b48  push rdi
00007f46e3fd8b49  push rsi
00007f46e3fd8b4a  push r8
00007f46e3fd8b4c  push r9
00007f46e3fd8b4e  push r10
00007f46e3fd8b50  push r11
00007f46e3fd8b52  sub rsp, 0xF0
00007f46e3fd8b59  vmovaps [rsp], xmm0
00007f46e3fd8b5e  vmovaps [rsp+0x10], xmm2
00007f46e3fd8b64  vmovaps [rsp+0x20], xmm3
00007f46e3fd8b6a  vmovaps [rsp+0x30], xmm4
00007f46e3fd8b70  vmovaps [rsp+0x40], xmm5
00007f46e3fd8b76  vmovaps [rsp+0x50], xmm6
00007f46e3fd8b7c  vmovaps [rsp+0x60], xmm7
00007f46e3fd8b82  vmovaps [rsp+0x70], xmm8
00007f46e3fd8b88  vmovaps [rsp+0x80], xmm9
00007f46e3fd8b91  vmovaps [rsp+0x90], xmm10
00007f46e3fd8b9a  vmovaps [rsp+0xA0], xmm11
00007f46e3fd8ba3  vmovaps [rsp+0xB0], xmm12
00007f46e3fd8bac  vmovaps [rsp+0xC0], xmm13
00007f46e3fd8bb5  vmovaps [rsp+0xD0], xmm14
00007f46e3fd8bbe  vmovaps [rsp+0xE0], xmm15
00007f46e3fd8bc7  sub rsp, 0x30
00007f46e3fd8bcb  movaps [rsp], xmm1
00007f46e3fd8bcf  movaps [rsp+0x10], xmm4
00007f46e3fd8bd4  movaps [rsp+0x20], xmm9
00007f46e3fd8bda  lea rdi, [rsp]
00007f46e3fd8bde  mov esi, 0x00
00007f46e3fd8be3  mov rax, 0x6238B185B530
00007f46e3fd8bed  call rax
00007f46e3fd8bef  movaps xmm1, [rsp]
00007f46e3fd8bf3  add rsp, 0x30
00007f46e3fd8bf7  vmovaps xmm0, [rsp]
00007f46e3fd8bfc  vmovaps xmm2, [rsp+0x10]
00007f46e3fd8c02  vmovaps xmm3, [rsp+0x20]
00007f46e3fd8c08  vmovaps xmm4, [rsp+0x30]
00007f46e3fd8c0e  vmovaps xmm5, [rsp+0x40]
00007f46e3fd8c14  vmovaps xmm6, [rsp+0x50]
00007f46e3fd8c1a  vmovaps xmm7, [rsp+0x60]
00007f46e3fd8c20  vmovaps xmm8, [rsp+0x70]
00007f46e3fd8c26  vmovaps xmm9, [rsp+0x80]
00007f46e3fd8c2f  vmovaps xmm10, [rsp+0x90]
00007f46e3fd8c38  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd8c41  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd8c4a  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd8c53  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd8c5c  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd8c65  add rsp, 0xF0
00007f46e3fd8c6c  pop r11
00007f46e3fd8c6e  pop r10
00007f46e3fd8c70  pop r9
00007f46e3fd8c72  pop r8
00007f46e3fd8c74  pop rsi
00007f46e3fd8c75  pop rdi
00007f46e3fd8c76  pop rdx
00007f46e3fd8c77  pop rcx
00007f46e3fd8c78  pop rax
00007f46e3fd8c79  add rsp, 0x08
00007f46e3fd8c7d  jmp 0x00007F46E3FD613B
00007f46e3fd8c82  sub rsp, 0x08
00007f46e3fd8c86  push rax
00007f46e3fd8c87  push rcx
00007f46e3fd8c88  push rdx
00007f46e3fd8c89  push rdi
00007f46e3fd8c8a  push rsi
00007f46e3fd8c8b  push r8
00007f46e3fd8c8d  push r9
00007f46e3fd8c8f  push r10
00007f46e3fd8c91  push r11
00007f46e3fd8c93  sub rsp, 0xF0
00007f46e3fd8c9a  vmovaps [rsp], xmm0
00007f46e3fd8c9f  vmovaps [rsp+0x10], xmm1
00007f46e3fd8ca5  vmovaps [rsp+0x20], xmm2
00007f46e3fd8cab  vmovaps [rsp+0x30], xmm3
00007f46e3fd8cb1  vmovaps [rsp+0x40], xmm5
00007f46e3fd8cb7  vmovaps [rsp+0x50], xmm6
00007f46e3fd8cbd  vmovaps [rsp+0x60], xmm7
00007f46e3fd8cc3  vmovaps [rsp+0x70], xmm8
00007f46e3fd8cc9  vmovaps [rsp+0x80], xmm9
00007f46e3fd8cd2  vmovaps [rsp+0x90], xmm10
00007f46e3fd8cdb  vmovaps [rsp+0xA0], xmm11
00007f46e3fd8ce4  vmovaps [rsp+0xB0], xmm12
00007f46e3fd8ced  vmovaps [rsp+0xC0], xmm13
00007f46e3fd8cf6  vmovaps [rsp+0xD0], xmm14
00007f46e3fd8cff  vmovaps [rsp+0xE0], xmm15
00007f46e3fd8d08  sub rsp, 0x30
00007f46e3fd8d0c  movaps [rsp], xmm4
00007f46e3fd8d10  movaps [rsp+0x10], xmm2
00007f46e3fd8d15  movaps [rsp+0x20], xmm9
00007f46e3fd8d1b  lea rdi, [rsp]
00007f46e3fd8d1f  mov esi, 0x00
00007f46e3fd8d24  mov rax, 0x6238B185B530
00007f46e3fd8d2e  call rax
00007f46e3fd8d30  movaps xmm4, [rsp]
00007f46e3fd8d34  add rsp, 0x30
00007f46e3fd8d38  vmovaps xmm0, [rsp]
00007f46e3fd8d3d  vmovaps xmm1, [rsp+0x10]
00007f46e3fd8d43  vmovaps xmm2, [rsp+0x20]
00007f46e3fd8d49  vmovaps xmm3, [rsp+0x30]
00007f46e3fd8d4f  vmovaps xmm5, [rsp+0x40]
00007f46e3fd8d55  vmovaps xmm6, [rsp+0x50]
00007f46e3fd8d5b  vmovaps xmm7, [rsp+0x60]
00007f46e3fd8d61  vmovaps xmm8, [rsp+0x70]
00007f46e3fd8d67  vmovaps xmm9, [rsp+0x80]
00007f46e3fd8d70  vmovaps xmm10, [rsp+0x90]
00007f46e3fd8d79  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd8d82  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd8d8b  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd8d94  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd8d9d  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd8da6  add rsp, 0xF0
00007f46e3fd8dad  pop r11
00007f46e3fd8daf  pop r10
00007f46e3fd8db1  pop r9
00007f46e3fd8db3  pop r8
00007f46e3fd8db5  pop rsi
00007f46e3fd8db6  pop rdi
00007f46e3fd8db7  pop rdx
00007f46e3fd8db8  pop rcx
00007f46e3fd8db9  pop rax
00007f46e3fd8dba  add rsp, 0x08
00007f46e3fd8dbe  jmp 0x00007F46E3FD616B
00007f46e3fd8dc3  sub rsp, 0x08
00007f46e3fd8dc7  push rax
00007f46e3fd8dc8  push rcx
00007f46e3fd8dc9  push rdx
00007f46e3fd8dca  push rdi
00007f46e3fd8dcb  push rsi
00007f46e3fd8dcc  push r8
00007f46e3fd8dce  push r9
00007f46e3fd8dd0  push r10
00007f46e3fd8dd2  push r11
00007f46e3fd8dd4  sub rsp, 0xF0
00007f46e3fd8ddb  vmovaps [rsp], xmm0
00007f46e3fd8de0  vmovaps [rsp+0x10], xmm1
00007f46e3fd8de6  vmovaps [rsp+0x20], xmm2
00007f46e3fd8dec  vmovaps [rsp+0x30], xmm3
00007f46e3fd8df2  vmovaps [rsp+0x40], xmm4
00007f46e3fd8df8  vmovaps [rsp+0x50], xmm5
00007f46e3fd8dfe  vmovaps [rsp+0x60], xmm6
00007f46e3fd8e04  vmovaps [rsp+0x70], xmm7
00007f46e3fd8e0a  vmovaps [rsp+0x80], xmm8
00007f46e3fd8e13  vmovaps [rsp+0x90], xmm10
00007f46e3fd8e1c  vmovaps [rsp+0xA0], xmm11
00007f46e3fd8e25  vmovaps [rsp+0xB0], xmm12
00007f46e3fd8e2e  vmovaps [rsp+0xC0], xmm13
00007f46e3fd8e37  vmovaps [rsp+0xD0], xmm14
00007f46e3fd8e40  vmovaps [rsp+0xE0], xmm15
00007f46e3fd8e49  sub rsp, 0x30
00007f46e3fd8e4d  movaps [rsp], xmm9
00007f46e3fd8e52  movaps [rsp+0x10], xmm2
00007f46e3fd8e57  movaps [rsp+0x20], xmm1
00007f46e3fd8e5c  lea rdi, [rsp]
00007f46e3fd8e60  mov esi, 0x00
00007f46e3fd8e65  mov rax, 0x6238B185B530
00007f46e3fd8e6f  call rax
00007f46e3fd8e71  movaps xmm9, [rsp]
00007f46e3fd8e76  add rsp, 0x30
00007f46e3fd8e7a  vmovaps xmm0, [rsp]
00007f46e3fd8e7f  vmovaps xmm1, [rsp+0x10]
00007f46e3fd8e85  vmovaps xmm2, [rsp+0x20]
00007f46e3fd8e8b  vmovaps xmm3, [rsp+0x30]
00007f46e3fd8e91  vmovaps xmm4, [rsp+0x40]
00007f46e3fd8e97  vmovaps xmm5, [rsp+0x50]
00007f46e3fd8e9d  vmovaps xmm6, [rsp+0x60]
00007f46e3fd8ea3  vmovaps xmm7, [rsp+0x70]
00007f46e3fd8ea9  vmovaps xmm8, [rsp+0x80]
00007f46e3fd8eb2  vmovaps xmm10, [rsp+0x90]
00007f46e3fd8ebb  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd8ec4  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd8ecd  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd8ed6  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd8edf  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd8ee8  add rsp, 0xF0
00007f46e3fd8eef  pop r11
00007f46e3fd8ef1  pop r10
00007f46e3fd8ef3  pop r9
00007f46e3fd8ef5  pop r8
00007f46e3fd8ef7  pop rsi
00007f46e3fd8ef8  pop rdi
00007f46e3fd8ef9  pop rdx
00007f46e3fd8efa  pop rcx
00007f46e3fd8efb  pop rax
00007f46e3fd8efc  add rsp, 0x08
00007f46e3fd8f00  jmp 0x00007F46E3FD61A1
00007f46e3fd8f05  sub rsp, 0x08
00007f46e3fd8f09  push rax
00007f46e3fd8f0a  push rcx
00007f46e3fd8f0b  push rdx
00007f46e3fd8f0c  push rdi
00007f46e3fd8f0d  push rsi
00007f46e3fd8f0e  push r8
00007f46e3fd8f10  push r9
00007f46e3fd8f12  push r10
00007f46e3fd8f14  push r11
00007f46e3fd8f16  sub rsp, 0xF0
00007f46e3fd8f1d  vmovaps [rsp], xmm0
00007f46e3fd8f22  vmovaps [rsp+0x10], xmm2
00007f46e3fd8f28  vmovaps [rsp+0x20], xmm3
00007f46e3fd8f2e  vmovaps [rsp+0x30], xmm4
00007f46e3fd8f34  vmovaps [rsp+0x40], xmm5
00007f46e3fd8f3a  vmovaps [rsp+0x50], xmm6
00007f46e3fd8f40  vmovaps [rsp+0x60], xmm7
00007f46e3fd8f46  vmovaps [rsp+0x70], xmm8
00007f46e3fd8f4c  vmovaps [rsp+0x80], xmm9
00007f46e3fd8f55  vmovaps [rsp+0x90], xmm10
00007f46e3fd8f5e  vmovaps [rsp+0xA0], xmm11
00007f46e3fd8f67  vmovaps [rsp+0xB0], xmm12
00007f46e3fd8f70  vmovaps [rsp+0xC0], xmm13
00007f46e3fd8f79  vmovaps [rsp+0xD0], xmm14
00007f46e3fd8f82  vmovaps [rsp+0xE0], xmm15
00007f46e3fd8f8b  sub rsp, 0x30
00007f46e3fd8f8f  movaps [rsp], xmm1
00007f46e3fd8f93  movaps [rsp+0x10], xmm15
00007f46e3fd8f99  movaps [rsp+0x20], xmm6
00007f46e3fd8f9e  lea rdi, [rsp]
00007f46e3fd8fa2  mov esi, 0x00
00007f46e3fd8fa7  mov rax, 0x6238B185B530
00007f46e3fd8fb1  call rax
00007f46e3fd8fb3  movaps xmm1, [rsp]
00007f46e3fd8fb7  add rsp, 0x30
00007f46e3fd8fbb  vmovaps xmm0, [rsp]
00007f46e3fd8fc0  vmovaps xmm2, [rsp+0x10]
00007f46e3fd8fc6  vmovaps xmm3, [rsp+0x20]
00007f46e3fd8fcc  vmovaps xmm4, [rsp+0x30]
00007f46e3fd8fd2  vmovaps xmm5, [rsp+0x40]
00007f46e3fd8fd8  vmovaps xmm6, [rsp+0x50]
00007f46e3fd8fde  vmovaps xmm7, [rsp+0x60]
00007f46e3fd8fe4  vmovaps xmm8, [rsp+0x70]
00007f46e3fd8fea  vmovaps xmm9, [rsp+0x80]
00007f46e3fd8ff3  vmovaps xmm10, [rsp+0x90]
00007f46e3fd8ffc  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd9005  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd900e  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd9017  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd9020  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd9029  add rsp, 0xF0
00007f46e3fd9030  pop r11
00007f46e3fd9032  pop r10
00007f46e3fd9034  pop r9
00007f46e3fd9036  pop r8
00007f46e3fd9038  pop rsi
00007f46e3fd9039  pop rdi
00007f46e3fd903a  pop rdx
00007f46e3fd903b  pop rcx
00007f46e3fd903c  pop rax
00007f46e3fd903d  add rsp, 0x08
00007f46e3fd9041  jmp 0x00007F46E3FD61C2
00007f46e3fd9046  sub rsp, 0x08
00007f46e3fd904a  push rax
00007f46e3fd904b  push rcx
00007f46e3fd904c  push rdx
00007f46e3fd904d  push rdi
00007f46e3fd904e  push rsi
00007f46e3fd904f  push r8
00007f46e3fd9051  push r9
00007f46e3fd9053  push r10
00007f46e3fd9055  push r11
00007f46e3fd9057  sub rsp, 0xF0
00007f46e3fd905e  vmovaps [rsp], xmm0
00007f46e3fd9063  vmovaps [rsp+0x10], xmm1
00007f46e3fd9069  vmovaps [rsp+0x20], xmm2
00007f46e3fd906f  vmovaps [rsp+0x30], xmm3
00007f46e3fd9075  vmovaps [rsp+0x40], xmm4
00007f46e3fd907b  vmovaps [rsp+0x50], xmm5
00007f46e3fd9081  vmovaps [rsp+0x60], xmm6
00007f46e3fd9087  vmovaps [rsp+0x70], xmm7
00007f46e3fd908d  vmovaps [rsp+0x80], xmm8
00007f46e3fd9096  vmovaps [rsp+0x90], xmm9
00007f46e3fd909f  vmovaps [rsp+0xA0], xmm10
00007f46e3fd90a8  vmovaps [rsp+0xB0], xmm11
00007f46e3fd90b1  vmovaps [rsp+0xC0], xmm12
00007f46e3fd90ba  vmovaps [rsp+0xD0], xmm13
00007f46e3fd90c3  vmovaps [rsp+0xE0], xmm14
00007f46e3fd90cc  sub rsp, 0x30
00007f46e3fd90d0  movaps [rsp], xmm15
00007f46e3fd90d5  movaps [rsp+0x10], xmm5
00007f46e3fd90da  movaps [rsp+0x20], xmm3
00007f46e3fd90df  lea rdi, [rsp]
00007f46e3fd90e3  mov esi, 0x00
00007f46e3fd90e8  mov rax, 0x6238B185B530
00007f46e3fd90f2  call rax
00007f46e3fd90f4  movaps xmm15, [rsp]
00007f46e3fd90f9  add rsp, 0x30
00007f46e3fd90fd  vmovaps xmm0, [rsp]
00007f46e3fd9102  vmovaps xmm1, [rsp+0x10]
00007f46e3fd9108  vmovaps xmm2, [rsp+0x20]
00007f46e3fd910e  vmovaps xmm3, [rsp+0x30]
00007f46e3fd9114  vmovaps xmm4, [rsp+0x40]
00007f46e3fd911a  vmovaps xmm5, [rsp+0x50]
00007f46e3fd9120  vmovaps xmm6, [rsp+0x60]
00007f46e3fd9126  vmovaps xmm7, [rsp+0x70]
00007f46e3fd912c  vmovaps xmm8, [rsp+0x80]
00007f46e3fd9135  vmovaps xmm9, [rsp+0x90]
00007f46e3fd913e  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd9147  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd9150  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd9159  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd9162  vmovaps xmm14, [rsp+0xE0]
00007f46e3fd916b  add rsp, 0xF0
00007f46e3fd9172  pop r11
00007f46e3fd9174  pop r10
00007f46e3fd9176  pop r9
00007f46e3fd9178  pop r8
00007f46e3fd917a  pop rsi
00007f46e3fd917b  pop rdi
00007f46e3fd917c  pop rdx
00007f46e3fd917d  pop rcx
00007f46e3fd917e  pop rax
00007f46e3fd917f  add rsp, 0x08
00007f46e3fd9183  jmp 0x00007F46E3FD61DC
00007f46e3fd9188  sub rsp, 0x08
00007f46e3fd918c  push rax
00007f46e3fd918d  push rcx
00007f46e3fd918e  push rdx
00007f46e3fd918f  push rdi
00007f46e3fd9190  push rsi
00007f46e3fd9191  push r8
00007f46e3fd9193  push r9
00007f46e3fd9195  push r10
00007f46e3fd9197  push r11
00007f46e3fd9199  sub rsp, 0xF0
00007f46e3fd91a0  vmovaps [rsp], xmm0
00007f46e3fd91a5  vmovaps [rsp+0x10], xmm1
00007f46e3fd91ab  vmovaps [rsp+0x20], xmm2
00007f46e3fd91b1  vmovaps [rsp+0x30], xmm3
00007f46e3fd91b7  vmovaps [rsp+0x40], xmm4
00007f46e3fd91bd  vmovaps [rsp+0x50], xmm6
00007f46e3fd91c3  vmovaps [rsp+0x60], xmm7
00007f46e3fd91c9  vmovaps [rsp+0x70], xmm8
00007f46e3fd91cf  vmovaps [rsp+0x80], xmm9
00007f46e3fd91d8  vmovaps [rsp+0x90], xmm10
00007f46e3fd91e1  vmovaps [rsp+0xA0], xmm11
00007f46e3fd91ea  vmovaps [rsp+0xB0], xmm12
00007f46e3fd91f3  vmovaps [rsp+0xC0], xmm13
00007f46e3fd91fc  vmovaps [rsp+0xD0], xmm14
00007f46e3fd9205  vmovaps [rsp+0xE0], xmm15
00007f46e3fd920e  sub rsp, 0x30
00007f46e3fd9212  movaps [rsp], xmm5
00007f46e3fd9216  movaps [rsp+0x10], xmm8
00007f46e3fd921c  movaps [rsp+0x20], xmm6
00007f46e3fd9221  lea rdi, [rsp]
00007f46e3fd9225  mov esi, 0x00
00007f46e3fd922a  mov rax, 0x6238B185B530
00007f46e3fd9234  call rax
00007f46e3fd9236  movaps xmm5, [rsp]
00007f46e3fd923a  add rsp, 0x30
00007f46e3fd923e  vmovaps xmm0, [rsp]
00007f46e3fd9243  vmovaps xmm1, [rsp+0x10]
00007f46e3fd9249  vmovaps xmm2, [rsp+0x20]
00007f46e3fd924f  vmovaps xmm3, [rsp+0x30]
00007f46e3fd9255  vmovaps xmm4, [rsp+0x40]
00007f46e3fd925b  vmovaps xmm6, [rsp+0x50]
00007f46e3fd9261  vmovaps xmm7, [rsp+0x60]
00007f46e3fd9267  vmovaps xmm8, [rsp+0x70]
00007f46e3fd926d  vmovaps xmm9, [rsp+0x80]
00007f46e3fd9276  vmovaps xmm10, [rsp+0x90]
00007f46e3fd927f  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd9288  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd9291  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd929a  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd92a3  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd92ac  add rsp, 0xF0
00007f46e3fd92b3  pop r11
00007f46e3fd92b5  pop r10
00007f46e3fd92b7  pop r9
00007f46e3fd92b9  pop r8
00007f46e3fd92bb  pop rsi
00007f46e3fd92bc  pop rdi
00007f46e3fd92bd  pop rdx
00007f46e3fd92be  pop rcx
00007f46e3fd92bf  pop rax
00007f46e3fd92c0  add rsp, 0x08
00007f46e3fd92c4  jmp 0x00007F46E3FD6200
00007f46e3fd92c9  sub rsp, 0x08
00007f46e3fd92cd  push rax
00007f46e3fd92ce  push rcx
00007f46e3fd92cf  push rdx
00007f46e3fd92d0  push rdi
00007f46e3fd92d1  push rsi
00007f46e3fd92d2  push r8
00007f46e3fd92d4  push r9
00007f46e3fd92d6  push r10
00007f46e3fd92d8  push r11
00007f46e3fd92da  sub rsp, 0xF0
00007f46e3fd92e1  vmovaps [rsp], xmm0
00007f46e3fd92e6  vmovaps [rsp+0x10], xmm1
00007f46e3fd92ec  vmovaps [rsp+0x20], xmm2
00007f46e3fd92f2  vmovaps [rsp+0x30], xmm3
00007f46e3fd92f8  vmovaps [rsp+0x40], xmm4
00007f46e3fd92fe  vmovaps [rsp+0x50], xmm5
00007f46e3fd9304  vmovaps [rsp+0x60], xmm7
00007f46e3fd930a  vmovaps [rsp+0x70], xmm8
00007f46e3fd9310  vmovaps [rsp+0x80], xmm9
00007f46e3fd9319  vmovaps [rsp+0x90], xmm10
00007f46e3fd9322  vmovaps [rsp+0xA0], xmm11
00007f46e3fd932b  vmovaps [rsp+0xB0], xmm12
00007f46e3fd9334  vmovaps [rsp+0xC0], xmm13
00007f46e3fd933d  vmovaps [rsp+0xD0], xmm14
00007f46e3fd9346  vmovaps [rsp+0xE0], xmm15
00007f46e3fd934f  sub rsp, 0x30
00007f46e3fd9353  movaps [rsp], xmm6
00007f46e3fd9357  movaps [rsp+0x10], xmm10
00007f46e3fd935d  movaps [rsp+0x20], xmm8
00007f46e3fd9363  lea rdi, [rsp]
00007f46e3fd9367  mov esi, 0x00
00007f46e3fd936c  mov rax, 0x6238B185B530
00007f46e3fd9376  call rax
00007f46e3fd9378  movaps xmm6, [rsp]
00007f46e3fd937c  add rsp, 0x30
00007f46e3fd9380  vmovaps xmm0, [rsp]
00007f46e3fd9385  vmovaps xmm1, [rsp+0x10]
00007f46e3fd938b  vmovaps xmm2, [rsp+0x20]
00007f46e3fd9391  vmovaps xmm3, [rsp+0x30]
00007f46e3fd9397  vmovaps xmm4, [rsp+0x40]
00007f46e3fd939d  vmovaps xmm5, [rsp+0x50]
00007f46e3fd93a3  vmovaps xmm7, [rsp+0x60]
00007f46e3fd93a9  vmovaps xmm8, [rsp+0x70]
00007f46e3fd93af  vmovaps xmm9, [rsp+0x80]
00007f46e3fd93b8  vmovaps xmm10, [rsp+0x90]
00007f46e3fd93c1  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd93ca  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd93d3  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd93dc  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd93e5  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd93ee  add rsp, 0xF0
00007f46e3fd93f5  pop r11
00007f46e3fd93f7  pop r10
00007f46e3fd93f9  pop r9
00007f46e3fd93fb  pop r8
00007f46e3fd93fd  pop rsi
00007f46e3fd93fe  pop rdi
00007f46e3fd93ff  pop rdx
00007f46e3fd9400  pop rcx
00007f46e3fd9401  pop rax
00007f46e3fd9402  add rsp, 0x08
00007f46e3fd9406  jmp 0x00007F46E3FD6225
00007f46e3fd940b  sub rsp, 0x08
00007f46e3fd940f  push rax
00007f46e3fd9410  push rcx
00007f46e3fd9411  push rdx
00007f46e3fd9412  push rdi
00007f46e3fd9413  push rsi
00007f46e3fd9414  push r8
00007f46e3fd9416  push r9
00007f46e3fd9418  push r10
00007f46e3fd941a  push r11
00007f46e3fd941c  sub rsp, 0xF0
00007f46e3fd9423  vmovaps [rsp], xmm0
00007f46e3fd9428  vmovaps [rsp+0x10], xmm1
00007f46e3fd942e  vmovaps [rsp+0x20], xmm2
00007f46e3fd9434  vmovaps [rsp+0x30], xmm3
00007f46e3fd943a  vmovaps [rsp+0x40], xmm4
00007f46e3fd9440  vmovaps [rsp+0x50], xmm5
00007f46e3fd9446  vmovaps [rsp+0x60], xmm6
00007f46e3fd944c  vmovaps [rsp+0x70], xmm7
00007f46e3fd9452  vmovaps [rsp+0x80], xmm8
00007f46e3fd945b  vmovaps [rsp+0x90], xmm9
00007f46e3fd9464  vmovaps [rsp+0xA0], xmm11
00007f46e3fd946d  vmovaps [rsp+0xB0], xmm12
00007f46e3fd9476  vmovaps [rsp+0xC0], xmm13
00007f46e3fd947f  vmovaps [rsp+0xD0], xmm14
00007f46e3fd9488  vmovaps [rsp+0xE0], xmm15
00007f46e3fd9491  sub rsp, 0x30
00007f46e3fd9495  movaps [rsp], xmm10
00007f46e3fd949a  movaps [rsp+0x10], xmm8
00007f46e3fd94a0  movaps [rsp+0x20], xmm14
00007f46e3fd94a6  lea rdi, [rsp]
00007f46e3fd94aa  mov esi, 0x00
00007f46e3fd94af  mov rax, 0x6238B185B530
00007f46e3fd94b9  call rax
00007f46e3fd94bb  movaps xmm10, [rsp]
00007f46e3fd94c0  add rsp, 0x30
00007f46e3fd94c4  vmovaps xmm0, [rsp]
00007f46e3fd94c9  vmovaps xmm1, [rsp+0x10]
00007f46e3fd94cf  vmovaps xmm2, [rsp+0x20]
00007f46e3fd94d5  vmovaps xmm3, [rsp+0x30]
00007f46e3fd94db  vmovaps xmm4, [rsp+0x40]
00007f46e3fd94e1  vmovaps xmm5, [rsp+0x50]
00007f46e3fd94e7  vmovaps xmm6, [rsp+0x60]
00007f46e3fd94ed  vmovaps xmm7, [rsp+0x70]
00007f46e3fd94f3  vmovaps xmm8, [rsp+0x80]
00007f46e3fd94fc  vmovaps xmm9, [rsp+0x90]
00007f46e3fd9505  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd950e  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd9517  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd9520  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd9529  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd9532  add rsp, 0xF0
00007f46e3fd9539  pop r11
00007f46e3fd953b  pop r10
00007f46e3fd953d  pop r9
00007f46e3fd953f  pop r8
00007f46e3fd9541  pop rsi
00007f46e3fd9542  pop rdi
00007f46e3fd9543  pop rdx
00007f46e3fd9544  pop rcx
00007f46e3fd9545  pop rax
00007f46e3fd9546  add rsp, 0x08
00007f46e3fd954a  jmp 0x00007F46E3FD6245
00007f46e3fd954f  sub rsp, 0x08
00007f46e3fd9553  push rax
00007f46e3fd9554  push rcx
00007f46e3fd9555  push rdx
00007f46e3fd9556  push rdi
00007f46e3fd9557  push rsi
00007f46e3fd9558  push r8
00007f46e3fd955a  push r9
00007f46e3fd955c  push r10
00007f46e3fd955e  push r11
00007f46e3fd9560  sub rsp, 0xF0
00007f46e3fd9567  vmovaps [rsp], xmm0
00007f46e3fd956c  vmovaps [rsp+0x10], xmm1
00007f46e3fd9572  vmovaps [rsp+0x20], xmm2
00007f46e3fd9578  vmovaps [rsp+0x30], xmm3
00007f46e3fd957e  vmovaps [rsp+0x40], xmm4
00007f46e3fd9584  vmovaps [rsp+0x50], xmm5
00007f46e3fd958a  vmovaps [rsp+0x60], xmm6
00007f46e3fd9590  vmovaps [rsp+0x70], xmm7
00007f46e3fd9596  vmovaps [rsp+0x80], xmm8
00007f46e3fd959f  vmovaps [rsp+0x90], xmm9
00007f46e3fd95a8  vmovaps [rsp+0xA0], xmm10
00007f46e3fd95b1  vmovaps [rsp+0xB0], xmm11
00007f46e3fd95ba  vmovaps [rsp+0xC0], xmm12
00007f46e3fd95c3  vmovaps [rsp+0xD0], xmm13
00007f46e3fd95cc  vmovaps [rsp+0xE0], xmm15
00007f46e3fd95d5  sub rsp, 0x30
00007f46e3fd95d9  movaps [rsp], xmm14
00007f46e3fd95de  movaps [rsp+0x10], xmm8
00007f46e3fd95e4  movaps [rsp+0x20], xmm4
00007f46e3fd95e9  lea rdi, [rsp]
00007f46e3fd95ed  mov esi, 0x00
00007f46e3fd95f2  mov rax, 0x6238B185B530
00007f46e3fd95fc  call rax
00007f46e3fd95fe  movaps xmm14, [rsp]
00007f46e3fd9603  add rsp, 0x30
00007f46e3fd9607  vmovaps xmm0, [rsp]
00007f46e3fd960c  vmovaps xmm1, [rsp+0x10]
00007f46e3fd9612  vmovaps xmm2, [rsp+0x20]
00007f46e3fd9618  vmovaps xmm3, [rsp+0x30]
00007f46e3fd961e  vmovaps xmm4, [rsp+0x40]
00007f46e3fd9624  vmovaps xmm5, [rsp+0x50]
00007f46e3fd962a  vmovaps xmm6, [rsp+0x60]
00007f46e3fd9630  vmovaps xmm7, [rsp+0x70]
00007f46e3fd9636  vmovaps xmm8, [rsp+0x80]
00007f46e3fd963f  vmovaps xmm9, [rsp+0x90]
00007f46e3fd9648  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd9651  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd965a  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd9663  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd966c  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd9675  add rsp, 0xF0
00007f46e3fd967c  pop r11
00007f46e3fd967e  pop r10
00007f46e3fd9680  pop r9
00007f46e3fd9682  pop r8
00007f46e3fd9684  pop rsi
00007f46e3fd9685  pop rdi
00007f46e3fd9686  pop rdx
00007f46e3fd9687  pop rcx
00007f46e3fd9688  pop rax
00007f46e3fd9689  add rsp, 0x08
00007f46e3fd968d  jmp 0x00007F46E3FD6265
00007f46e3fd9692  sub rsp, 0x08
00007f46e3fd9696  push rax
00007f46e3fd9697  push rcx
00007f46e3fd9698  push rdx
00007f46e3fd9699  push rdi
00007f46e3fd969a  push rsi
00007f46e3fd969b  push r8
00007f46e3fd969d  push r9
00007f46e3fd969f  push r10
00007f46e3fd96a1  push r11
00007f46e3fd96a3  sub rsp, 0xF0
00007f46e3fd96aa  vmovaps [rsp], xmm0
00007f46e3fd96af  vmovaps [rsp+0x10], xmm1
00007f46e3fd96b5  vmovaps [rsp+0x20], xmm2
00007f46e3fd96bb  vmovaps [rsp+0x30], xmm3
00007f46e3fd96c1  vmovaps [rsp+0x40], xmm5
00007f46e3fd96c7  vmovaps [rsp+0x50], xmm6
00007f46e3fd96cd  vmovaps [rsp+0x60], xmm7
00007f46e3fd96d3  vmovaps [rsp+0x70], xmm8
00007f46e3fd96d9  vmovaps [rsp+0x80], xmm9
00007f46e3fd96e2  vmovaps [rsp+0x90], xmm10
00007f46e3fd96eb  vmovaps [rsp+0xA0], xmm11
00007f46e3fd96f4  vmovaps [rsp+0xB0], xmm12
00007f46e3fd96fd  vmovaps [rsp+0xC0], xmm13
00007f46e3fd9706  vmovaps [rsp+0xD0], xmm14
00007f46e3fd970f  vmovaps [rsp+0xE0], xmm15
00007f46e3fd9718  sub rsp, 0x30
00007f46e3fd971c  movaps [rsp], xmm4
00007f46e3fd9720  movaps [rsp+0x10], xmm13
00007f46e3fd9726  movaps [rsp+0x20], xmm8
00007f46e3fd972c  lea rdi, [rsp]
00007f46e3fd9730  mov esi, 0x00
00007f46e3fd9735  mov rax, 0x6238B185B530
00007f46e3fd973f  call rax
00007f46e3fd9741  movaps xmm4, [rsp]
00007f46e3fd9745  add rsp, 0x30
00007f46e3fd9749  vmovaps xmm0, [rsp]
00007f46e3fd974e  vmovaps xmm1, [rsp+0x10]
00007f46e3fd9754  vmovaps xmm2, [rsp+0x20]
00007f46e3fd975a  vmovaps xmm3, [rsp+0x30]
00007f46e3fd9760  vmovaps xmm5, [rsp+0x40]
00007f46e3fd9766  vmovaps xmm6, [rsp+0x50]
00007f46e3fd976c  vmovaps xmm7, [rsp+0x60]
00007f46e3fd9772  vmovaps xmm8, [rsp+0x70]
00007f46e3fd9778  vmovaps xmm9, [rsp+0x80]
00007f46e3fd9781  vmovaps xmm10, [rsp+0x90]
00007f46e3fd978a  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd9793  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd979c  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd97a5  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd97ae  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd97b7  add rsp, 0xF0
00007f46e3fd97be  pop r11
00007f46e3fd97c0  pop r10
00007f46e3fd97c2  pop r9
00007f46e3fd97c4  pop r8
00007f46e3fd97c6  pop rsi
00007f46e3fd97c7  pop rdi
00007f46e3fd97c8  pop rdx
00007f46e3fd97c9  pop rcx
00007f46e3fd97ca  pop rax
00007f46e3fd97cb  add rsp, 0x08
00007f46e3fd97cf  jmp 0x00007F46E3FD628A
00007f46e3fd97d4  sub rsp, 0x08
00007f46e3fd97d8  push rax
00007f46e3fd97d9  push rcx
00007f46e3fd97da  push rdx
00007f46e3fd97db  push rdi
00007f46e3fd97dc  push rsi
00007f46e3fd97dd  push r8
00007f46e3fd97df  push r9
00007f46e3fd97e1  push r10
00007f46e3fd97e3  push r11
00007f46e3fd97e5  sub rsp, 0xF0
00007f46e3fd97ec  vmovaps [rsp], xmm0
00007f46e3fd97f1  vmovaps [rsp+0x10], xmm1
00007f46e3fd97f7  vmovaps [rsp+0x20], xmm2
00007f46e3fd97fd  vmovaps [rsp+0x30], xmm3
00007f46e3fd9803  vmovaps [rsp+0x40], xmm4
00007f46e3fd9809  vmovaps [rsp+0x50], xmm5
00007f46e3fd980f  vmovaps [rsp+0x60], xmm6
00007f46e3fd9815  vmovaps [rsp+0x70], xmm7
00007f46e3fd981b  vmovaps [rsp+0x80], xmm8
00007f46e3fd9824  vmovaps [rsp+0x90], xmm9
00007f46e3fd982d  vmovaps [rsp+0xA0], xmm10
00007f46e3fd9836  vmovaps [rsp+0xB0], xmm11
00007f46e3fd983f  vmovaps [rsp+0xC0], xmm12
00007f46e3fd9848  vmovaps [rsp+0xD0], xmm14
00007f46e3fd9851  vmovaps [rsp+0xE0], xmm15
00007f46e3fd985a  sub rsp, 0x30
00007f46e3fd985e  movaps [rsp], xmm13
00007f46e3fd9863  movaps [rsp+0x10], xmm15
00007f46e3fd9869  movaps [rsp+0x20], xmm9
00007f46e3fd986f  lea rdi, [rsp]
00007f46e3fd9873  mov esi, 0x00
00007f46e3fd9878  mov rax, 0x6238B185B530
00007f46e3fd9882  call rax
00007f46e3fd9884  movaps xmm13, [rsp]
00007f46e3fd9889  add rsp, 0x30
00007f46e3fd988d  vmovaps xmm0, [rsp]
00007f46e3fd9892  vmovaps xmm1, [rsp+0x10]
00007f46e3fd9898  vmovaps xmm2, [rsp+0x20]
00007f46e3fd989e  vmovaps xmm3, [rsp+0x30]
00007f46e3fd98a4  vmovaps xmm4, [rsp+0x40]
00007f46e3fd98aa  vmovaps xmm5, [rsp+0x50]
00007f46e3fd98b0  vmovaps xmm6, [rsp+0x60]
00007f46e3fd98b6  vmovaps xmm7, [rsp+0x70]
00007f46e3fd98bc  vmovaps xmm8, [rsp+0x80]
00007f46e3fd98c5  vmovaps xmm9, [rsp+0x90]
00007f46e3fd98ce  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd98d7  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd98e0  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd98e9  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd98f2  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd98fb  add rsp, 0xF0
00007f46e3fd9902  pop r11
00007f46e3fd9904  pop r10
00007f46e3fd9906  pop r9
00007f46e3fd9908  pop r8
00007f46e3fd990a  pop rsi
00007f46e3fd990b  pop rdi
00007f46e3fd990c  pop rdx
00007f46e3fd990d  pop rcx
00007f46e3fd990e  pop rax
00007f46e3fd990f  add rsp, 0x08
00007f46e3fd9913  jmp 0x00007F46E3FD62A5
00007f46e3fd9918  sub rsp, 0x08
00007f46e3fd991c  push rax
00007f46e3fd991d  push rcx
00007f46e3fd991e  push rdx
00007f46e3fd991f  push rdi
00007f46e3fd9920  push rsi
00007f46e3fd9921  push r8
00007f46e3fd9923  push r9
00007f46e3fd9925  push r10
00007f46e3fd9927  push r11
00007f46e3fd9929  sub rsp, 0xF0
00007f46e3fd9930  vmovaps [rsp], xmm0
00007f46e3fd9935  vmovaps [rsp+0x10], xmm1
00007f46e3fd993b  vmovaps [rsp+0x20], xmm2
00007f46e3fd9941  vmovaps [rsp+0x30], xmm3
00007f46e3fd9947  vmovaps [rsp+0x40], xmm4
00007f46e3fd994d  vmovaps [rsp+0x50], xmm5
00007f46e3fd9953  vmovaps [rsp+0x60], xmm6
00007f46e3fd9959  vmovaps [rsp+0x70], xmm7
00007f46e3fd995f  vmovaps [rsp+0x80], xmm8
00007f46e3fd9968  vmovaps [rsp+0x90], xmm9
00007f46e3fd9971  vmovaps [rsp+0xA0], xmm10
00007f46e3fd997a  vmovaps [rsp+0xB0], xmm11
00007f46e3fd9983  vmovaps [rsp+0xC0], xmm12
00007f46e3fd998c  vmovaps [rsp+0xD0], xmm13
00007f46e3fd9995  vmovaps [rsp+0xE0], xmm14
00007f46e3fd999e  sub rsp, 0x30
00007f46e3fd99a2  movaps [rsp], xmm15
00007f46e3fd99a7  movaps [rsp+0x10], xmm1
00007f46e3fd99ac  movaps [rsp+0x20], xmm5
00007f46e3fd99b1  lea rdi, [rsp]
00007f46e3fd99b5  mov esi, 0x00
00007f46e3fd99ba  mov rax, 0x6238B185B530
00007f46e3fd99c4  call rax
00007f46e3fd99c6  movaps xmm15, [rsp]
00007f46e3fd99cb  add rsp, 0x30
00007f46e3fd99cf  vmovaps xmm0, [rsp]
00007f46e3fd99d4  vmovaps xmm1, [rsp+0x10]
00007f46e3fd99da  vmovaps xmm2, [rsp+0x20]
00007f46e3fd99e0  vmovaps xmm3, [rsp+0x30]
00007f46e3fd99e6  vmovaps xmm4, [rsp+0x40]
00007f46e3fd99ec  vmovaps xmm5, [rsp+0x50]
00007f46e3fd99f2  vmovaps xmm6, [rsp+0x60]
00007f46e3fd99f8  vmovaps xmm7, [rsp+0x70]
00007f46e3fd99fe  vmovaps xmm8, [rsp+0x80]
00007f46e3fd9a07  vmovaps xmm9, [rsp+0x90]
00007f46e3fd9a10  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd9a19  vmovaps xmm11, [rsp+0xB0]
00007f46e3fd9a22  vmovaps xmm12, [rsp+0xC0]
00007f46e3fd9a2b  vmovaps xmm13, [rsp+0xD0]
00007f46e3fd9a34  vmovaps xmm14, [rsp+0xE0]
00007f46e3fd9a3d  add rsp, 0xF0
00007f46e3fd9a44  pop r11
00007f46e3fd9a46  pop r10
00007f46e3fd9a48  pop r9
00007f46e3fd9a4a  pop r8
00007f46e3fd9a4c  pop rsi
00007f46e3fd9a4d  pop rdi
00007f46e3fd9a4e  pop rdx
00007f46e3fd9a4f  pop rcx
00007f46e3fd9a50  pop rax
00007f46e3fd9a51  add rsp, 0x08
00007f46e3fd9a55  jmp 0x00007F46E3FD62C0
00007f46e3fd9a5a  call 0x00007F46E3ED64F0
00007f46e3fd9a5f  jmp 0x00007F46E3FD631B
00007f46e3fd9a64  sub rsp, 0x08
00007f46e3fd9a68  push rax
00007f46e3fd9a69  push rcx
00007f46e3fd9a6a  push rdx
00007f46e3fd9a6b  push rdi
00007f46e3fd9a6c  push rsi
00007f46e3fd9a6d  push r8
00007f46e3fd9a6f  push r9
00007f46e3fd9a71  push r10
00007f46e3fd9a73  push r11
00007f46e3fd9a75  sub rsp, 0xF0
00007f46e3fd9a7c  vmovaps [rsp], xmm0
00007f46e3fd9a81  vmovaps [rsp+0x10], xmm1
00007f46e3fd9a87  vmovaps [rsp+0x20], xmm2
00007f46e3fd9a8d  vmovaps [rsp+0x30], xmm3
00007f46e3fd9a93  vmovaps [rsp+0x40], xmm4
00007f46e3fd9a99  vmovaps [rsp+0x50], xmm5
00007f46e3fd9a9f  vmovaps [rsp+0x60], xmm6
00007f46e3fd9aa5  vmovaps [rsp+0x70], xmm7
00007f46e3fd9aab  vmovaps [rsp+0x80], xmm8
00007f46e3fd9ab4  vmovaps [rsp+0x90], xmm10
00007f46e3fd9abd  vmovaps [rsp+0xA0], xmm11
00007f46e3fd9ac6  vmovaps [rsp+0xB0], xmm12
00007f46e3fd9acf  vmovaps [rsp+0xC0], xmm13
00007f46e3fd9ad8  vmovaps [rsp+0xD0], xmm14
00007f46e3fd9ae1  vmovaps [rsp+0xE0], xmm15
00007f46e3fd9aea  sub rsp, 0x30
00007f46e3fd9aee  movaps [rsp], xmm9
00007f46e3fd9af3  movaps [rsp+0x10], xmm8
00007f46e3fd9af9  movaps [rsp+0x20], xmm11
00007f46e3fd9aff  lea rdi, [rsp]
00007f46e3fd9b03  mov esi, 0x00
00007f46e3fd9b08  mov rax, 0x6238B185B530
00007f46e3fd9b12  call rax
00007f46e3fd9b14  movaps xmm9, [rsp]
00007f46e3fd9b19  add rsp, 0x30
00007f46e3fd9b1d  vmovaps xmm0, [rsp]
00007f46e3fd9b22  vmovaps xmm1, [rsp+0x10]
00007f46e3fd9b28  vmovaps xmm2, [rsp+0x20]
00007f46e3fd9b2e  vmovaps xmm3, [rsp+0x30]
00007f46e3fd9b34  vmovaps xmm4, [rsp+0x40]
00007f46e3fd9b3a  vmovaps xmm5, [rsp+0x50]
00007f46e3fd9b40  vmovaps xmm6, [rsp+0x60]
00007f46e3fd9b46  vmovaps xmm7, [rsp+0x70]
00007f46e3fd9b4c  vmovaps xmm8, [rsp+0x80]
00007f46e3fd9b55  vmovaps xmm10, [rsp+0x90]
00007f46e3fd9b5e  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd9b67  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd9b70  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd9b79  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd9b82  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd9b8b  add rsp, 0xF0
00007f46e3fd9b92  pop r11
00007f46e3fd9b94  pop r10
00007f46e3fd9b96  pop r9
00007f46e3fd9b98  pop r8
00007f46e3fd9b9a  pop rsi
00007f46e3fd9b9b  pop rdi
00007f46e3fd9b9c  pop rdx
00007f46e3fd9b9d  pop rcx
00007f46e3fd9b9e  pop rax
00007f46e3fd9b9f  add rsp, 0x08
00007f46e3fd9ba3  jmp 0x00007F46E3FD6352
00007f46e3fd9ba8  sub rsp, 0x08
00007f46e3fd9bac  push rax
00007f46e3fd9bad  push rcx
00007f46e3fd9bae  push rdx
00007f46e3fd9baf  push rdi
00007f46e3fd9bb0  push rsi
00007f46e3fd9bb1  push r8
00007f46e3fd9bb3  push r9
00007f46e3fd9bb5  push r10
00007f46e3fd9bb7  push r11
00007f46e3fd9bb9  sub rsp, 0xF0
00007f46e3fd9bc0  vmovaps [rsp], xmm0
00007f46e3fd9bc5  vmovaps [rsp+0x10], xmm1
00007f46e3fd9bcb  vmovaps [rsp+0x20], xmm2
00007f46e3fd9bd1  vmovaps [rsp+0x30], xmm3
00007f46e3fd9bd7  vmovaps [rsp+0x40], xmm4
00007f46e3fd9bdd  vmovaps [rsp+0x50], xmm5
00007f46e3fd9be3  vmovaps [rsp+0x60], xmm6
00007f46e3fd9be9  vmovaps [rsp+0x70], xmm7
00007f46e3fd9bef  vmovaps [rsp+0x80], xmm8
00007f46e3fd9bf8  vmovaps [rsp+0x90], xmm9
00007f46e3fd9c01  vmovaps [rsp+0xA0], xmm10
00007f46e3fd9c0a  vmovaps [rsp+0xB0], xmm12
00007f46e3fd9c13  vmovaps [rsp+0xC0], xmm13
00007f46e3fd9c1c  vmovaps [rsp+0xD0], xmm14
00007f46e3fd9c25  vmovaps [rsp+0xE0], xmm15
00007f46e3fd9c2e  sub rsp, 0x30
00007f46e3fd9c32  movaps [rsp], xmm11
00007f46e3fd9c37  movaps [rsp+0x10], xmm10
00007f46e3fd9c3d  movaps [rsp+0x20], xmm6
00007f46e3fd9c42  lea rdi, [rsp]
00007f46e3fd9c46  mov esi, 0x00
00007f46e3fd9c4b  mov rax, 0x6238B185B530
00007f46e3fd9c55  call rax
00007f46e3fd9c57  movaps xmm11, [rsp]
00007f46e3fd9c5c  add rsp, 0x30
00007f46e3fd9c60  vmovaps xmm0, [rsp]
00007f46e3fd9c65  vmovaps xmm1, [rsp+0x10]
00007f46e3fd9c6b  vmovaps xmm2, [rsp+0x20]
00007f46e3fd9c71  vmovaps xmm3, [rsp+0x30]
00007f46e3fd9c77  vmovaps xmm4, [rsp+0x40]
00007f46e3fd9c7d  vmovaps xmm5, [rsp+0x50]
00007f46e3fd9c83  vmovaps xmm6, [rsp+0x60]
00007f46e3fd9c89  vmovaps xmm7, [rsp+0x70]
00007f46e3fd9c8f  vmovaps xmm8, [rsp+0x80]
00007f46e3fd9c98  vmovaps xmm9, [rsp+0x90]
00007f46e3fd9ca1  vmovaps xmm10, [rsp+0xA0]
00007f46e3fd9caa  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd9cb3  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd9cbc  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd9cc5  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd9cce  add rsp, 0xF0
00007f46e3fd9cd5  pop r11
00007f46e3fd9cd7  pop r10
00007f46e3fd9cd9  pop r9
00007f46e3fd9cdb  pop r8
00007f46e3fd9cdd  pop rsi
00007f46e3fd9cde  pop rdi
00007f46e3fd9cdf  pop rdx
00007f46e3fd9ce0  pop rcx
00007f46e3fd9ce1  pop rax
00007f46e3fd9ce2  add rsp, 0x08
00007f46e3fd9ce6  jmp 0x00007F46E3FD636D
00007f46e3fd9ceb  sub rsp, 0x08
00007f46e3fd9cef  push rax
00007f46e3fd9cf0  push rcx
00007f46e3fd9cf1  push rdx
00007f46e3fd9cf2  push rdi
00007f46e3fd9cf3  push rsi
00007f46e3fd9cf4  push r8
00007f46e3fd9cf6  push r9
00007f46e3fd9cf8  push r10
00007f46e3fd9cfa  push r11
00007f46e3fd9cfc  sub rsp, 0xF0
00007f46e3fd9d03  vmovaps [rsp], xmm0
00007f46e3fd9d08  vmovaps [rsp+0x10], xmm1
00007f46e3fd9d0e  vmovaps [rsp+0x20], xmm2
00007f46e3fd9d14  vmovaps [rsp+0x30], xmm3
00007f46e3fd9d1a  vmovaps [rsp+0x40], xmm4
00007f46e3fd9d20  vmovaps [rsp+0x50], xmm5
00007f46e3fd9d26  vmovaps [rsp+0x60], xmm6
00007f46e3fd9d2c  vmovaps [rsp+0x70], xmm7
00007f46e3fd9d32  vmovaps [rsp+0x80], xmm8
00007f46e3fd9d3b  vmovaps [rsp+0x90], xmm9
00007f46e3fd9d44  vmovaps [rsp+0xA0], xmm11
00007f46e3fd9d4d  vmovaps [rsp+0xB0], xmm12
00007f46e3fd9d56  vmovaps [rsp+0xC0], xmm13
00007f46e3fd9d5f  vmovaps [rsp+0xD0], xmm14
00007f46e3fd9d68  vmovaps [rsp+0xE0], xmm15
00007f46e3fd9d71  sub rsp, 0x30
00007f46e3fd9d75  movaps [rsp], xmm10
00007f46e3fd9d7a  movaps [rsp+0x10], xmm14
00007f46e3fd9d80  movaps [rsp+0x20], xmm4
00007f46e3fd9d85  lea rdi, [rsp]
00007f46e3fd9d89  mov esi, 0x00
00007f46e3fd9d8e  mov rax, 0x6238B185B530
00007f46e3fd9d98  call rax
00007f46e3fd9d9a  movaps xmm10, [rsp]
00007f46e3fd9d9f  add rsp, 0x30
00007f46e3fd9da3  vmovaps xmm0, [rsp]
00007f46e3fd9da8  vmovaps xmm1, [rsp+0x10]
00007f46e3fd9dae  vmovaps xmm2, [rsp+0x20]
00007f46e3fd9db4  vmovaps xmm3, [rsp+0x30]
00007f46e3fd9dba  vmovaps xmm4, [rsp+0x40]
00007f46e3fd9dc0  vmovaps xmm5, [rsp+0x50]
00007f46e3fd9dc6  vmovaps xmm6, [rsp+0x60]
00007f46e3fd9dcc  vmovaps xmm7, [rsp+0x70]
00007f46e3fd9dd2  vmovaps xmm8, [rsp+0x80]
00007f46e3fd9ddb  vmovaps xmm9, [rsp+0x90]
00007f46e3fd9de4  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd9ded  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd9df6  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd9dff  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd9e08  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd9e11  add rsp, 0xF0
00007f46e3fd9e18  pop r11
00007f46e3fd9e1a  pop r10
00007f46e3fd9e1c  pop r9
00007f46e3fd9e1e  pop r8
00007f46e3fd9e20  pop rsi
00007f46e3fd9e21  pop rdi
00007f46e3fd9e22  pop rdx
00007f46e3fd9e23  pop rcx
00007f46e3fd9e24  pop rax
00007f46e3fd9e25  add rsp, 0x08
00007f46e3fd9e29  jmp 0x00007F46E3FD6388
00007f46e3fd9e2e  sub rsp, 0x08
00007f46e3fd9e32  push rax
00007f46e3fd9e33  push rcx
00007f46e3fd9e34  push rdx
00007f46e3fd9e35  push rdi
00007f46e3fd9e36  push rsi
00007f46e3fd9e37  push r8
00007f46e3fd9e39  push r9
00007f46e3fd9e3b  push r10
00007f46e3fd9e3d  push r11
00007f46e3fd9e3f  sub rsp, 0xF0
00007f46e3fd9e46  vmovaps [rsp], xmm0
00007f46e3fd9e4b  vmovaps [rsp+0x10], xmm1
00007f46e3fd9e51  vmovaps [rsp+0x20], xmm2
00007f46e3fd9e57  vmovaps [rsp+0x30], xmm3
00007f46e3fd9e5d  vmovaps [rsp+0x40], xmm4
00007f46e3fd9e63  vmovaps [rsp+0x50], xmm5
00007f46e3fd9e69  vmovaps [rsp+0x60], xmm6
00007f46e3fd9e6f  vmovaps [rsp+0x70], xmm7
00007f46e3fd9e75  vmovaps [rsp+0x80], xmm9
00007f46e3fd9e7e  vmovaps [rsp+0x90], xmm10
00007f46e3fd9e87  vmovaps [rsp+0xA0], xmm11
00007f46e3fd9e90  vmovaps [rsp+0xB0], xmm12
00007f46e3fd9e99  vmovaps [rsp+0xC0], xmm13
00007f46e3fd9ea2  vmovaps [rsp+0xD0], xmm14
00007f46e3fd9eab  vmovaps [rsp+0xE0], xmm15
00007f46e3fd9eb4  sub rsp, 0x30
00007f46e3fd9eb8  movaps [rsp], xmm8
00007f46e3fd9ebd  movaps [rsp+0x10], xmm1
00007f46e3fd9ec2  movaps [rsp+0x20], xmm14
00007f46e3fd9ec8  lea rdi, [rsp]
00007f46e3fd9ecc  mov esi, 0x00
00007f46e3fd9ed1  mov rax, 0x6238B185B530
00007f46e3fd9edb  call rax
00007f46e3fd9edd  movaps xmm8, [rsp]
00007f46e3fd9ee2  add rsp, 0x30
00007f46e3fd9ee6  vmovaps xmm0, [rsp]
00007f46e3fd9eeb  vmovaps xmm1, [rsp+0x10]
00007f46e3fd9ef1  vmovaps xmm2, [rsp+0x20]
00007f46e3fd9ef7  vmovaps xmm3, [rsp+0x30]
00007f46e3fd9efd  vmovaps xmm4, [rsp+0x40]
00007f46e3fd9f03  vmovaps xmm5, [rsp+0x50]
00007f46e3fd9f09  vmovaps xmm6, [rsp+0x60]
00007f46e3fd9f0f  vmovaps xmm7, [rsp+0x70]
00007f46e3fd9f15  vmovaps xmm9, [rsp+0x80]
00007f46e3fd9f1e  vmovaps xmm10, [rsp+0x90]
00007f46e3fd9f27  vmovaps xmm11, [rsp+0xA0]
00007f46e3fd9f30  vmovaps xmm12, [rsp+0xB0]
00007f46e3fd9f39  vmovaps xmm13, [rsp+0xC0]
00007f46e3fd9f42  vmovaps xmm14, [rsp+0xD0]
00007f46e3fd9f4b  vmovaps xmm15, [rsp+0xE0]
00007f46e3fd9f54  add rsp, 0xF0
00007f46e3fd9f5b  pop r11
00007f46e3fd9f5d  pop r10
00007f46e3fd9f5f  pop r9
00007f46e3fd9f61  pop r8
00007f46e3fd9f63  pop rsi
00007f46e3fd9f64  pop rdi
00007f46e3fd9f65  pop rdx
00007f46e3fd9f66  pop rcx
00007f46e3fd9f67  pop rax
00007f46e3fd9f68  add rsp, 0x08
00007f46e3fd9f6c  jmp 0x00007F46E3FD63AE
00007f46e3fd9f71  sub rsp, 0x08
00007f46e3fd9f75  push rax
00007f46e3fd9f76  push rcx
00007f46e3fd9f77  push rdx
00007f46e3fd9f78  push rdi
00007f46e3fd9f79  push rsi
00007f46e3fd9f7a  push r8
00007f46e3fd9f7c  push r9
00007f46e3fd9f7e  push r10
00007f46e3fd9f80  push r11
00007f46e3fd9f82  sub rsp, 0xF0
00007f46e3fd9f89  vmovaps [rsp], xmm0
00007f46e3fd9f8e  vmovaps [rsp+0x10], xmm1
00007f46e3fd9f94  vmovaps [rsp+0x20], xmm2
00007f46e3fd9f9a  vmovaps [rsp+0x30], xmm3
00007f46e3fd9fa0  vmovaps [rsp+0x40], xmm4
00007f46e3fd9fa6  vmovaps [rsp+0x50], xmm5
00007f46e3fd9fac  vmovaps [rsp+0x60], xmm7
00007f46e3fd9fb2  vmovaps [rsp+0x70], xmm8
00007f46e3fd9fb8  vmovaps [rsp+0x80], xmm9
00007f46e3fd9fc1  vmovaps [rsp+0x90], xmm10
00007f46e3fd9fca  vmovaps [rsp+0xA0], xmm11
00007f46e3fd9fd3  vmovaps [rsp+0xB0], xmm12
00007f46e3fd9fdc  vmovaps [rsp+0xC0], xmm13
00007f46e3fd9fe5  vmovaps [rsp+0xD0], xmm14
00007f46e3fd9fee  vmovaps [rsp+0xE0], xmm15
00007f46e3fd9ff7  sub rsp, 0x30
00007f46e3fd9ffb  movaps [rsp], xmm6
00007f46e3fd9fff  movaps [rsp+0x10], xmm1
00007f46e3fda004  movaps [rsp+0x20], xmm14
00007f46e3fda00a  lea rdi, [rsp]
00007f46e3fda00e  mov esi, 0x00
00007f46e3fda013  mov rax, 0x6238B185B530
00007f46e3fda01d  call rax
00007f46e3fda01f  movaps xmm6, [rsp]
00007f46e3fda023  add rsp, 0x30
00007f46e3fda027  vmovaps xmm0, [rsp]
00007f46e3fda02c  vmovaps xmm1, [rsp+0x10]
00007f46e3fda032  vmovaps xmm2, [rsp+0x20]
00007f46e3fda038  vmovaps xmm3, [rsp+0x30]
00007f46e3fda03e  vmovaps xmm4, [rsp+0x40]
00007f46e3fda044  vmovaps xmm5, [rsp+0x50]
00007f46e3fda04a  vmovaps xmm7, [rsp+0x60]
00007f46e3fda050  vmovaps xmm8, [rsp+0x70]
00007f46e3fda056  vmovaps xmm9, [rsp+0x80]
00007f46e3fda05f  vmovaps xmm10, [rsp+0x90]
00007f46e3fda068  vmovaps xmm11, [rsp+0xA0]
00007f46e3fda071  vmovaps xmm12, [rsp+0xB0]
00007f46e3fda07a  vmovaps xmm13, [rsp+0xC0]
00007f46e3fda083  vmovaps xmm14, [rsp+0xD0]
00007f46e3fda08c  vmovaps xmm15, [rsp+0xE0]
00007f46e3fda095  add rsp, 0xF0
00007f46e3fda09c  pop r11
00007f46e3fda09e  pop r10
00007f46e3fda0a0  pop r9
00007f46e3fda0a2  pop r8
00007f46e3fda0a4  pop rsi
00007f46e3fda0a5  pop rdi
00007f46e3fda0a6  pop rdx
00007f46e3fda0a7  pop rcx
00007f46e3fda0a8  pop rax
00007f46e3fda0a9  add rsp, 0x08
00007f46e3fda0ad  jmp 0x00007F46E3FD63DA
00007f46e3fda0b2  sub rsp, 0x08
00007f46e3fda0b6  push rax
00007f46e3fda0b7  push rcx
00007f46e3fda0b8  push rdx
00007f46e3fda0b9  push rdi
00007f46e3fda0ba  push rsi
00007f46e3fda0bb  push r8
00007f46e3fda0bd  push r9
00007f46e3fda0bf  push r10
00007f46e3fda0c1  push r11
00007f46e3fda0c3  sub rsp, 0xF0
00007f46e3fda0ca  vmovaps [rsp], xmm0
00007f46e3fda0cf  vmovaps [rsp+0x10], xmm1
00007f46e3fda0d5  vmovaps [rsp+0x20], xmm2
00007f46e3fda0db  vmovaps [rsp+0x30], xmm3
00007f46e3fda0e1  vmovaps [rsp+0x40], xmm4
00007f46e3fda0e7  vmovaps [rsp+0x50], xmm5
00007f46e3fda0ed  vmovaps [rsp+0x60], xmm6
00007f46e3fda0f3  vmovaps [rsp+0x70], xmm7
00007f46e3fda0f9  vmovaps [rsp+0x80], xmm8
00007f46e3fda102  vmovaps [rsp+0x90], xmm9
00007f46e3fda10b  vmovaps [rsp+0xA0], xmm10
00007f46e3fda114  vmovaps [rsp+0xB0], xmm11
00007f46e3fda11d  vmovaps [rsp+0xC0], xmm12
00007f46e3fda126  vmovaps [rsp+0xD0], xmm13
00007f46e3fda12f  vmovaps [rsp+0xE0], xmm15
00007f46e3fda138  sub rsp, 0x30
00007f46e3fda13c  movaps [rsp], xmm14
00007f46e3fda141  movaps [rsp+0x10], xmm12
00007f46e3fda147  movaps [rsp+0x20], xmm1
00007f46e3fda14c  lea rdi, [rsp]
00007f46e3fda150  mov esi, 0x00
00007f46e3fda155  mov rax, 0x6238B185B530
00007f46e3fda15f  call rax
00007f46e3fda161  movaps xmm14, [rsp]
00007f46e3fda166  add rsp, 0x30
00007f46e3fda16a  vmovaps xmm0, [rsp]
00007f46e3fda16f  vmovaps xmm1, [rsp+0x10]
00007f46e3fda175  vmovaps xmm2, [rsp+0x20]
00007f46e3fda17b  vmovaps xmm3, [rsp+0x30]
00007f46e3fda181  vmovaps xmm4, [rsp+0x40]
00007f46e3fda187  vmovaps xmm5, [rsp+0x50]
00007f46e3fda18d  vmovaps xmm6, [rsp+0x60]
00007f46e3fda193  vmovaps xmm7, [rsp+0x70]
00007f46e3fda199  vmovaps xmm8, [rsp+0x80]
00007f46e3fda1a2  vmovaps xmm9, [rsp+0x90]
00007f46e3fda1ab  vmovaps xmm10, [rsp+0xA0]
00007f46e3fda1b4  vmovaps xmm11, [rsp+0xB0]
00007f46e3fda1bd  vmovaps xmm12, [rsp+0xC0]
00007f46e3fda1c6  vmovaps xmm13, [rsp+0xD0]
00007f46e3fda1cf  vmovaps xmm15, [rsp+0xE0]
00007f46e3fda1d8  add rsp, 0xF0
00007f46e3fda1df  pop r11
00007f46e3fda1e1  pop r10
00007f46e3fda1e3  pop r9
00007f46e3fda1e5  pop r8
00007f46e3fda1e7  pop rsi
00007f46e3fda1e8  pop rdi
00007f46e3fda1e9  pop rdx
00007f46e3fda1ea  pop rcx
00007f46e3fda1eb  pop rax
00007f46e3fda1ec  add rsp, 0x08
00007f46e3fda1f0  jmp 0x00007F46E3FD6400
00007f46e3fda1f5  sub rsp, 0x08
00007f46e3fda1f9  push rax
00007f46e3fda1fa  push rcx
00007f46e3fda1fb  push rdx
00007f46e3fda1fc  push rdi
00007f46e3fda1fd  push rsi
00007f46e3fda1fe  push r8
00007f46e3fda200  push r9
00007f46e3fda202  push r10
00007f46e3fda204  push r11
00007f46e3fda206  sub rsp, 0xF0
00007f46e3fda20d  vmovaps [rsp], xmm0
00007f46e3fda212  vmovaps [rsp+0x10], xmm2
00007f46e3fda218  vmovaps [rsp+0x20], xmm3
00007f46e3fda21e  vmovaps [rsp+0x30], xmm4
00007f46e3fda224  vmovaps [rsp+0x40], xmm5
00007f46e3fda22a  vmovaps [rsp+0x50], xmm6
00007f46e3fda230  vmovaps [rsp+0x60], xmm7
00007f46e3fda236  vmovaps [rsp+0x70], xmm8
00007f46e3fda23c  vmovaps [rsp+0x80], xmm9
00007f46e3fda245  vmovaps [rsp+0x90], xmm10
00007f46e3fda24e  vmovaps [rsp+0xA0], xmm11
00007f46e3fda257  vmovaps [rsp+0xB0], xmm12
00007f46e3fda260  vmovaps [rsp+0xC0], xmm13
00007f46e3fda269  vmovaps [rsp+0xD0], xmm14
00007f46e3fda272  vmovaps [rsp+0xE0], xmm15
00007f46e3fda27b  sub rsp, 0x30
00007f46e3fda27f  movaps [rsp], xmm1
00007f46e3fda283  movaps [rsp+0x10], xmm13
00007f46e3fda289  movaps [rsp+0x20], xmm9
00007f46e3fda28f  lea rdi, [rsp]
00007f46e3fda293  mov esi, 0x00
00007f46e3fda298  mov rax, 0x6238B185B530
00007f46e3fda2a2  call rax
00007f46e3fda2a4  movaps xmm1, [rsp]
00007f46e3fda2a8  add rsp, 0x30
00007f46e3fda2ac  vmovaps xmm0, [rsp]
00007f46e3fda2b1  vmovaps xmm2, [rsp+0x10]
00007f46e3fda2b7  vmovaps xmm3, [rsp+0x20]
00007f46e3fda2bd  vmovaps xmm4, [rsp+0x30]
00007f46e3fda2c3  vmovaps xmm5, [rsp+0x40]
00007f46e3fda2c9  vmovaps xmm6, [rsp+0x50]
00007f46e3fda2cf  vmovaps xmm7, [rsp+0x60]
00007f46e3fda2d5  vmovaps xmm8, [rsp+0x70]
00007f46e3fda2db  vmovaps xmm9, [rsp+0x80]
00007f46e3fda2e4  vmovaps xmm10, [rsp+0x90]
00007f46e3fda2ed  vmovaps xmm11, [rsp+0xA0]
00007f46e3fda2f6  vmovaps xmm12, [rsp+0xB0]
00007f46e3fda2ff  vmovaps xmm13, [rsp+0xC0]
00007f46e3fda308  vmovaps xmm14, [rsp+0xD0]
00007f46e3fda311  vmovaps xmm15, [rsp+0xE0]
00007f46e3fda31a  add rsp, 0xF0
00007f46e3fda321  pop r11
00007f46e3fda323  pop r10
00007f46e3fda325  pop r9
00007f46e3fda327  pop r8
00007f46e3fda329  pop rsi
00007f46e3fda32a  pop rdi
00007f46e3fda32b  pop rdx
00007f46e3fda32c  pop rcx
00007f46e3fda32d  pop rax
00007f46e3fda32e  add rsp, 0x08
00007f46e3fda332  jmp 0x00007F46E3FD641A
00007f46e3fda337  sub rsp, 0x08
00007f46e3fda33b  push rax
00007f46e3fda33c  push rcx
00007f46e3fda33d  push rdx
00007f46e3fda33e  push rdi
00007f46e3fda33f  push rsi
00007f46e3fda340  push r8
00007f46e3fda342  push r9
00007f46e3fda344  push r10
00007f46e3fda346  push r11
00007f46e3fda348  sub rsp, 0xF0
00007f46e3fda34f  vmovaps [rsp], xmm0
00007f46e3fda354  vmovaps [rsp+0x10], xmm1
00007f46e3fda35a  vmovaps [rsp+0x20], xmm2
00007f46e3fda360  vmovaps [rsp+0x30], xmm3
00007f46e3fda366  vmovaps [rsp+0x40], xmm4
00007f46e3fda36c  vmovaps [rsp+0x50], xmm5
00007f46e3fda372  vmovaps [rsp+0x60], xmm6
00007f46e3fda378  vmovaps [rsp+0x70], xmm7
00007f46e3fda37e  vmovaps [rsp+0x80], xmm8
00007f46e3fda387  vmovaps [rsp+0x90], xmm9
00007f46e3fda390  vmovaps [rsp+0xA0], xmm10
00007f46e3fda399  vmovaps [rsp+0xB0], xmm11
00007f46e3fda3a2  vmovaps [rsp+0xC0], xmm13
00007f46e3fda3ab  vmovaps [rsp+0xD0], xmm14
00007f46e3fda3b4  vmovaps [rsp+0xE0], xmm15
00007f46e3fda3bd  sub rsp, 0x30
00007f46e3fda3c1  movaps [rsp], xmm12
00007f46e3fda3c6  movaps [rsp+0x10], xmm7
00007f46e3fda3cb  movaps [rsp+0x20], xmm13
00007f46e3fda3d1  lea rdi, [rsp]
00007f46e3fda3d5  mov esi, 0x00
00007f46e3fda3da  mov rax, 0x6238B185B530
00007f46e3fda3e4  call rax
00007f46e3fda3e6  movaps xmm12, [rsp]
00007f46e3fda3eb  add rsp, 0x30
00007f46e3fda3ef  vmovaps xmm0, [rsp]
00007f46e3fda3f4  vmovaps xmm1, [rsp+0x10]
00007f46e3fda3fa  vmovaps xmm2, [rsp+0x20]
00007f46e3fda400  vmovaps xmm3, [rsp+0x30]
00007f46e3fda406  vmovaps xmm4, [rsp+0x40]
00007f46e3fda40c  vmovaps xmm5, [rsp+0x50]
00007f46e3fda412  vmovaps xmm6, [rsp+0x60]
00007f46e3fda418  vmovaps xmm7, [rsp+0x70]
00007f46e3fda41e  vmovaps xmm8, [rsp+0x80]
00007f46e3fda427  vmovaps xmm9, [rsp+0x90]
00007f46e3fda430  vmovaps xmm10, [rsp+0xA0]
00007f46e3fda439  vmovaps xmm11, [rsp+0xB0]
00007f46e3fda442  vmovaps xmm13, [rsp+0xC0]
00007f46e3fda44b  vmovaps xmm14, [rsp+0xD0]
00007f46e3fda454  vmovaps xmm15, [rsp+0xE0]
00007f46e3fda45d  add rsp, 0xF0
00007f46e3fda464  pop r11
00007f46e3fda466  pop r10
00007f46e3fda468  pop r9
00007f46e3fda46a  pop r8
00007f46e3fda46c  pop rsi
00007f46e3fda46d  pop rdi
00007f46e3fda46e  pop rdx
00007f46e3fda46f  pop rcx
00007f46e3fda470  pop rax
00007f46e3fda471  add rsp, 0x08
00007f46e3fda475  jmp 0x00007F46E3FD6441
00007f46e3fda47a  sub rsp, 0x08
00007f46e3fda47e  push rax
00007f46e3fda47f  push rcx
00007f46e3fda480  push rdx
00007f46e3fda481  push rdi
00007f46e3fda482  push rsi
00007f46e3fda483  push r8
00007f46e3fda485  push r9
00007f46e3fda487  push r10
00007f46e3fda489  push r11
00007f46e3fda48b  sub rsp, 0xF0
00007f46e3fda492  vmovaps [rsp], xmm0
00007f46e3fda497  vmovaps [rsp+0x10], xmm1
00007f46e3fda49d  vmovaps [rsp+0x20], xmm2
00007f46e3fda4a3  vmovaps [rsp+0x30], xmm3
00007f46e3fda4a9  vmovaps [rsp+0x40], xmm4
00007f46e3fda4af  vmovaps [rsp+0x50], xmm5
00007f46e3fda4b5  vmovaps [rsp+0x60], xmm6
00007f46e3fda4bb  vmovaps [rsp+0x70], xmm7
00007f46e3fda4c1  vmovaps [rsp+0x80], xmm8
00007f46e3fda4ca  vmovaps [rsp+0x90], xmm9
00007f46e3fda4d3  vmovaps [rsp+0xA0], xmm10
00007f46e3fda4dc  vmovaps [rsp+0xB0], xmm11
00007f46e3fda4e5  vmovaps [rsp+0xC0], xmm12
00007f46e3fda4ee  vmovaps [rsp+0xD0], xmm14
00007f46e3fda4f7  vmovaps [rsp+0xE0], xmm15
00007f46e3fda500  sub rsp, 0x30
00007f46e3fda504  movaps [rsp], xmm13
00007f46e3fda509  movaps [rsp+0x10], xmm15
00007f46e3fda50f  movaps [rsp+0x20], xmm8
00007f46e3fda515  lea rdi, [rsp]
00007f46e3fda519  mov esi, 0x00
00007f46e3fda51e  mov rax, 0x6238B185B530
00007f46e3fda528  call rax
00007f46e3fda52a  movaps xmm13, [rsp]
00007f46e3fda52f  add rsp, 0x30
00007f46e3fda533  vmovaps xmm0, [rsp]
00007f46e3fda538  vmovaps xmm1, [rsp+0x10]
00007f46e3fda53e  vmovaps xmm2, [rsp+0x20]
00007f46e3fda544  vmovaps xmm3, [rsp+0x30]
00007f46e3fda54a  vmovaps xmm4, [rsp+0x40]
00007f46e3fda550  vmovaps xmm5, [rsp+0x50]
00007f46e3fda556  vmovaps xmm6, [rsp+0x60]
00007f46e3fda55c  vmovaps xmm7, [rsp+0x70]
00007f46e3fda562  vmovaps xmm8, [rsp+0x80]
00007f46e3fda56b  vmovaps xmm9, [rsp+0x90]
00007f46e3fda574  vmovaps xmm10, [rsp+0xA0]
00007f46e3fda57d  vmovaps xmm11, [rsp+0xB0]
00007f46e3fda586  vmovaps xmm12, [rsp+0xC0]
00007f46e3fda58f  vmovaps xmm14, [rsp+0xD0]
00007f46e3fda598  vmovaps xmm15, [rsp+0xE0]
00007f46e3fda5a1  add rsp, 0xF0
00007f46e3fda5a8  pop r11
00007f46e3fda5aa  pop r10
00007f46e3fda5ac  pop r9
00007f46e3fda5ae  pop r8
00007f46e3fda5b0  pop rsi
00007f46e3fda5b1  pop rdi
00007f46e3fda5b2  pop rdx
00007f46e3fda5b3  pop rcx
00007f46e3fda5b4  pop rax
00007f46e3fda5b5  add rsp, 0x08
00007f46e3fda5b9  jmp 0x00007F46E3FD645C
00007f46e3fda5be  sub rsp, 0x08
00007f46e3fda5c2  push rax
00007f46e3fda5c3  push rcx
00007f46e3fda5c4  push rdx
00007f46e3fda5c5  push rdi
00007f46e3fda5c6  push rsi
00007f46e3fda5c7  push r8
00007f46e3fda5c9  push r9
00007f46e3fda5cb  push r10
00007f46e3fda5cd  push r11
00007f46e3fda5cf  sub rsp, 0xF0
00007f46e3fda5d6  vmovaps [rsp], xmm0
00007f46e3fda5db  vmovaps [rsp+0x10], xmm1
00007f46e3fda5e1  vmovaps [rsp+0x20], xmm2
00007f46e3fda5e7  vmovaps [rsp+0x30], xmm3
00007f46e3fda5ed  vmovaps [rsp+0x40], xmm4
00007f46e3fda5f3  vmovaps [rsp+0x50], xmm5
00007f46e3fda5f9  vmovaps [rsp+0x60], xmm6
00007f46e3fda5ff  vmovaps [rsp+0x70], xmm7
00007f46e3fda605  vmovaps [rsp+0x80], xmm9
00007f46e3fda60e  vmovaps [rsp+0x90], xmm10
00007f46e3fda617  vmovaps [rsp+0xA0], xmm11
00007f46e3fda620  vmovaps [rsp+0xB0], xmm12
00007f46e3fda629  vmovaps [rsp+0xC0], xmm13
00007f46e3fda632  vmovaps [rsp+0xD0], xmm14
00007f46e3fda63b  vmovaps [rsp+0xE0], xmm15
00007f46e3fda644  sub rsp, 0x30
00007f46e3fda648  movaps [rsp], xmm8
00007f46e3fda64d  movaps [rsp+0x10], xmm15
00007f46e3fda653  movaps [rsp+0x20], xmm9
00007f46e3fda659  lea rdi, [rsp]
00007f46e3fda65d  mov esi, 0x00
00007f46e3fda662  mov rax, 0x6238B185B530
00007f46e3fda66c  call rax
00007f46e3fda66e  movaps xmm8, [rsp]
00007f46e3fda673  add rsp, 0x30
00007f46e3fda677  vmovaps xmm0, [rsp]
00007f46e3fda67c  vmovaps xmm1, [rsp+0x10]
00007f46e3fda682  vmovaps xmm2, [rsp+0x20]
00007f46e3fda688  vmovaps xmm3, [rsp+0x30]
00007f46e3fda68e  vmovaps xmm4, [rsp+0x40]
00007f46e3fda694  vmovaps xmm5, [rsp+0x50]
00007f46e3fda69a  vmovaps xmm6, [rsp+0x60]
00007f46e3fda6a0  vmovaps xmm7, [rsp+0x70]
00007f46e3fda6a6  vmovaps xmm9, [rsp+0x80]
00007f46e3fda6af  vmovaps xmm10, [rsp+0x90]
00007f46e3fda6b8  vmovaps xmm11, [rsp+0xA0]
00007f46e3fda6c1  vmovaps xmm12, [rsp+0xB0]
00007f46e3fda6ca  vmovaps xmm13, [rsp+0xC0]
00007f46e3fda6d3  vmovaps xmm14, [rsp+0xD0]
00007f46e3fda6dc  vmovaps xmm15, [rsp+0xE0]
00007f46e3fda6e5  add rsp, 0xF0
00007f46e3fda6ec  pop r11
00007f46e3fda6ee  pop r10
00007f46e3fda6f0  pop r9
00007f46e3fda6f2  pop r8
00007f46e3fda6f4  pop rsi
00007f46e3fda6f5  pop rdi
00007f46e3fda6f6  pop rdx
00007f46e3fda6f7  pop rcx
00007f46e3fda6f8  pop rax
00007f46e3fda6f9  add rsp, 0x08
00007f46e3fda6fd  jmp 0x00007F46E3FD648A
00007f46e3fda702  sub rsp, 0x08
00007f46e3fda706  push rax
00007f46e3fda707  push rcx
00007f46e3fda708  push rdx
00007f46e3fda709  push rdi
00007f46e3fda70a  push rsi
00007f46e3fda70b  push r8
00007f46e3fda70d  push r9
00007f46e3fda70f  push r10
00007f46e3fda711  push r11
00007f46e3fda713  sub rsp, 0xF0
00007f46e3fda71a  vmovaps [rsp], xmm0
00007f46e3fda71f  vmovaps [rsp+0x10], xmm1
00007f46e3fda725  vmovaps [rsp+0x20], xmm2
00007f46e3fda72b  vmovaps [rsp+0x30], xmm3
00007f46e3fda731  vmovaps [rsp+0x40], xmm4
00007f46e3fda737  vmovaps [rsp+0x50], xmm5
00007f46e3fda73d  vmovaps [rsp+0x60], xmm6
00007f46e3fda743  vmovaps [rsp+0x70], xmm7
00007f46e3fda749  vmovaps [rsp+0x80], xmm8
00007f46e3fda752  vmovaps [rsp+0x90], xmm9
00007f46e3fda75b  vmovaps [rsp+0xA0], xmm10
00007f46e3fda764  vmovaps [rsp+0xB0], xmm11
00007f46e3fda76d  vmovaps [rsp+0xC0], xmm12
00007f46e3fda776  vmovaps [rsp+0xD0], xmm13
00007f46e3fda77f  vmovaps [rsp+0xE0], xmm14
00007f46e3fda788  sub rsp, 0x30
00007f46e3fda78c  movaps [rsp], xmm15
00007f46e3fda791  movaps [rsp+0x10], xmm11
00007f46e3fda797  movaps [rsp+0x20], xmm6
00007f46e3fda79c  lea rdi, [rsp]
00007f46e3fda7a0  mov esi, 0x00
00007f46e3fda7a5  mov rax, 0x6238B185B530
00007f46e3fda7af  call rax
00007f46e3fda7b1  movaps xmm15, [rsp]
00007f46e3fda7b6  add rsp, 0x30
00007f46e3fda7ba  vmovaps xmm0, [rsp]
00007f46e3fda7bf  vmovaps xmm1, [rsp+0x10]
00007f46e3fda7c5  vmovaps xmm2, [rsp+0x20]
00007f46e3fda7cb  vmovaps xmm3, [rsp+0x30]
00007f46e3fda7d1  vmovaps xmm4, [rsp+0x40]
00007f46e3fda7d7  vmovaps xmm5, [rsp+0x50]
00007f46e3fda7dd  vmovaps xmm6, [rsp+0x60]
00007f46e3fda7e3  vmovaps xmm7, [rsp+0x70]
00007f46e3fda7e9  vmovaps xmm8, [rsp+0x80]
00007f46e3fda7f2  vmovaps xmm9, [rsp+0x90]
00007f46e3fda7fb  vmovaps xmm10, [rsp+0xA0]
00007f46e3fda804  vmovaps xmm11, [rsp+0xB0]
00007f46e3fda80d  vmovaps xmm12, [rsp+0xC0]
00007f46e3fda816  vmovaps xmm13, [rsp+0xD0]
00007f46e3fda81f  vmovaps xmm14, [rsp+0xE0]
00007f46e3fda828  add rsp, 0xF0
00007f46e3fda82f  pop r11
00007f46e3fda831  pop r10
00007f46e3fda833  pop r9
00007f46e3fda835  pop r8
00007f46e3fda837  pop rsi
00007f46e3fda838  pop rdi
00007f46e3fda839  pop rdx
00007f46e3fda83a  pop rcx
00007f46e3fda83b  pop rax
00007f46e3fda83c  add rsp, 0x08
00007f46e3fda840  jmp 0x00007F46E3FD64A5
00007f46e3fda845  sub rsp, 0x08
00007f46e3fda849  push rax
00007f46e3fda84a  push rcx
00007f46e3fda84b  push rdx
00007f46e3fda84c  push rdi
00007f46e3fda84d  push rsi
00007f46e3fda84e  push r8
00007f46e3fda850  push r9
00007f46e3fda852  push r10
00007f46e3fda854  push r11
00007f46e3fda856  sub rsp, 0xF0
00007f46e3fda85d  vmovaps [rsp], xmm0
00007f46e3fda862  vmovaps [rsp+0x10], xmm1
00007f46e3fda868  vmovaps [rsp+0x20], xmm2
00007f46e3fda86e  vmovaps [rsp+0x30], xmm3
00007f46e3fda874  vmovaps [rsp+0x40], xmm4
00007f46e3fda87a  vmovaps [rsp+0x50], xmm5
00007f46e3fda880  vmovaps [rsp+0x60], xmm6
00007f46e3fda886  vmovaps [rsp+0x70], xmm8
00007f46e3fda88c  vmovaps [rsp+0x80], xmm9
00007f46e3fda895  vmovaps [rsp+0x90], xmm10
00007f46e3fda89e  vmovaps [rsp+0xA0], xmm11
00007f46e3fda8a7  vmovaps [rsp+0xB0], xmm12
00007f46e3fda8b0  vmovaps [rsp+0xC0], xmm13
00007f46e3fda8b9  vmovaps [rsp+0xD0], xmm14
00007f46e3fda8c2  vmovaps [rsp+0xE0], xmm15
00007f46e3fda8cb  sub rsp, 0x30
00007f46e3fda8cf  movaps [rsp], xmm7
00007f46e3fda8d3  movaps [rsp+0x10], xmm11
00007f46e3fda8d9  movaps [rsp+0x20], xmm9
00007f46e3fda8df  lea rdi, [rsp]
00007f46e3fda8e3  mov esi, 0x00
00007f46e3fda8e8  mov rax, 0x6238B185B530
00007f46e3fda8f2  call rax
00007f46e3fda8f4  movaps xmm7, [rsp]
00007f46e3fda8f8  add rsp, 0x30
00007f46e3fda8fc  vmovaps xmm0, [rsp]
00007f46e3fda901  vmovaps xmm1, [rsp+0x10]
00007f46e3fda907  vmovaps xmm2, [rsp+0x20]
00007f46e3fda90d  vmovaps xmm3, [rsp+0x30]
00007f46e3fda913  vmovaps xmm4, [rsp+0x40]
00007f46e3fda919  vmovaps xmm5, [rsp+0x50]
00007f46e3fda91f  vmovaps xmm6, [rsp+0x60]
00007f46e3fda925  vmovaps xmm8, [rsp+0x70]
00007f46e3fda92b  vmovaps xmm9, [rsp+0x80]
00007f46e3fda934  vmovaps xmm10, [rsp+0x90]
00007f46e3fda93d  vmovaps xmm11, [rsp+0xA0]
00007f46e3fda946  vmovaps xmm12, [rsp+0xB0]
00007f46e3fda94f  vmovaps xmm13, [rsp+0xC0]
00007f46e3fda958  vmovaps xmm14, [rsp+0xD0]
00007f46e3fda961  vmovaps xmm15, [rsp+0xE0]
00007f46e3fda96a  add rsp, 0xF0
00007f46e3fda971  pop r11
00007f46e3fda973  pop r10
00007f46e3fda975  pop r9
00007f46e3fda977  pop r8
00007f46e3fda979  pop rsi
00007f46e3fda97a  pop rdi
00007f46e3fda97b  pop rdx
00007f46e3fda97c  pop rcx
00007f46e3fda97d  pop rax
00007f46e3fda97e  add rsp, 0x08
00007f46e3fda982  jmp 0x00007F46E3FD64D2
00007f46e3fda987  sub rsp, 0x08
00007f46e3fda98b  push rax
00007f46e3fda98c  push rcx
00007f46e3fda98d  push rdx
00007f46e3fda98e  push rdi
00007f46e3fda98f  push rsi
00007f46e3fda990  push r8
00007f46e3fda992  push r9
00007f46e3fda994  push r10
00007f46e3fda996  push r11
00007f46e3fda998  sub rsp, 0xF0
00007f46e3fda99f  vmovaps [rsp], xmm0
00007f46e3fda9a4  vmovaps [rsp+0x10], xmm1
00007f46e3fda9aa  vmovaps [rsp+0x20], xmm2
00007f46e3fda9b0  vmovaps [rsp+0x30], xmm3
00007f46e3fda9b6  vmovaps [rsp+0x40], xmm4
00007f46e3fda9bc  vmovaps [rsp+0x50], xmm5
00007f46e3fda9c2  vmovaps [rsp+0x60], xmm6
00007f46e3fda9c8  vmovaps [rsp+0x70], xmm7
00007f46e3fda9ce  vmovaps [rsp+0x80], xmm8
00007f46e3fda9d7  vmovaps [rsp+0x90], xmm9
00007f46e3fda9e0  vmovaps [rsp+0xA0], xmm10
00007f46e3fda9e9  vmovaps [rsp+0xB0], xmm12
00007f46e3fda9f2  vmovaps [rsp+0xC0], xmm13
00007f46e3fda9fb  vmovaps [rsp+0xD0], xmm14
00007f46e3fdaa04  vmovaps [rsp+0xE0], xmm15
00007f46e3fdaa0d  sub rsp, 0x30
00007f46e3fdaa11  movaps [rsp], xmm11
00007f46e3fdaa16  movaps [rsp+0x10], xmm10
00007f46e3fdaa1c  movaps [rsp+0x20], xmm14
00007f46e3fdaa22  lea rdi, [rsp]
00007f46e3fdaa26  mov esi, 0x00
00007f46e3fdaa2b  mov rax, 0x6238B185B530
00007f46e3fdaa35  call rax
00007f46e3fdaa37  movaps xmm11, [rsp]
00007f46e3fdaa3c  add rsp, 0x30
00007f46e3fdaa40  vmovaps xmm0, [rsp]
00007f46e3fdaa45  vmovaps xmm1, [rsp+0x10]
00007f46e3fdaa4b  vmovaps xmm2, [rsp+0x20]
00007f46e3fdaa51  vmovaps xmm3, [rsp+0x30]
00007f46e3fdaa57  vmovaps xmm4, [rsp+0x40]
00007f46e3fdaa5d  vmovaps xmm5, [rsp+0x50]
00007f46e3fdaa63  vmovaps xmm6, [rsp+0x60]
00007f46e3fdaa69  vmovaps xmm7, [rsp+0x70]
00007f46e3fdaa6f  vmovaps xmm8, [rsp+0x80]
00007f46e3fdaa78  vmovaps xmm9, [rsp+0x90]
00007f46e3fdaa81  vmovaps xmm10, [rsp+0xA0]
00007f46e3fdaa8a  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdaa93  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdaa9c  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdaaa5  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdaaae  add rsp, 0xF0
00007f46e3fdaab5  pop r11
00007f46e3fdaab7  pop r10
00007f46e3fdaab9  pop r9
00007f46e3fdaabb  pop r8
00007f46e3fdaabd  pop rsi
00007f46e3fdaabe  pop rdi
00007f46e3fdaabf  pop rdx
00007f46e3fdaac0  pop rcx
00007f46e3fdaac1  pop rax
00007f46e3fdaac2  add rsp, 0x08
00007f46e3fdaac6  jmp 0x00007F46E3FD64ED
00007f46e3fdaacb  call 0x00007F46E3EE45A0
00007f46e3fdaad0  jmp 0x00007F46E3FD64F7
00007f46e3fdaad5  sub rsp, 0x08
00007f46e3fdaad9  push rax
00007f46e3fdaada  push rcx
00007f46e3fdaadb  push rdx
00007f46e3fdaadc  push rdi
00007f46e3fdaadd  push rsi
00007f46e3fdaade  push r8
00007f46e3fdaae0  push r9
00007f46e3fdaae2  push r10
00007f46e3fdaae4  push r11
00007f46e3fdaae6  sub rsp, 0xF0
00007f46e3fdaaed  vmovaps [rsp], xmm0
00007f46e3fdaaf2  vmovaps [rsp+0x10], xmm1
00007f46e3fdaaf8  vmovaps [rsp+0x20], xmm2
00007f46e3fdaafe  vmovaps [rsp+0x30], xmm3
00007f46e3fdab04  vmovaps [rsp+0x40], xmm4
00007f46e3fdab0a  vmovaps [rsp+0x50], xmm5
00007f46e3fdab10  vmovaps [rsp+0x60], xmm6
00007f46e3fdab16  vmovaps [rsp+0x70], xmm7
00007f46e3fdab1c  vmovaps [rsp+0x80], xmm8
00007f46e3fdab25  vmovaps [rsp+0x90], xmm9
00007f46e3fdab2e  vmovaps [rsp+0xA0], xmm11
00007f46e3fdab37  vmovaps [rsp+0xB0], xmm12
00007f46e3fdab40  vmovaps [rsp+0xC0], xmm13
00007f46e3fdab49  vmovaps [rsp+0xD0], xmm14
00007f46e3fdab52  vmovaps [rsp+0xE0], xmm15
00007f46e3fdab5b  sub rsp, 0x30
00007f46e3fdab5f  movaps [rsp], xmm10
00007f46e3fdab64  movaps [rsp+0x10], xmm1
00007f46e3fdab69  movaps [rsp+0x20], xmm12
00007f46e3fdab6f  lea rdi, [rsp]
00007f46e3fdab73  mov esi, 0x00
00007f46e3fdab78  mov rax, 0x6238B185B530
00007f46e3fdab82  call rax
00007f46e3fdab84  movaps xmm10, [rsp]
00007f46e3fdab89  add rsp, 0x30
00007f46e3fdab8d  vmovaps xmm0, [rsp]
00007f46e3fdab92  vmovaps xmm1, [rsp+0x10]
00007f46e3fdab98  vmovaps xmm2, [rsp+0x20]
00007f46e3fdab9e  vmovaps xmm3, [rsp+0x30]
00007f46e3fdaba4  vmovaps xmm4, [rsp+0x40]
00007f46e3fdabaa  vmovaps xmm5, [rsp+0x50]
00007f46e3fdabb0  vmovaps xmm6, [rsp+0x60]
00007f46e3fdabb6  vmovaps xmm7, [rsp+0x70]
00007f46e3fdabbc  vmovaps xmm8, [rsp+0x80]
00007f46e3fdabc5  vmovaps xmm9, [rsp+0x90]
00007f46e3fdabce  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdabd7  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdabe0  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdabe9  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdabf2  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdabfb  add rsp, 0xF0
00007f46e3fdac02  pop r11
00007f46e3fdac04  pop r10
00007f46e3fdac06  pop r9
00007f46e3fdac08  pop r8
00007f46e3fdac0a  pop rsi
00007f46e3fdac0b  pop rdi
00007f46e3fdac0c  pop rdx
00007f46e3fdac0d  pop rcx
00007f46e3fdac0e  pop rax
00007f46e3fdac0f  add rsp, 0x08
00007f46e3fdac13  jmp 0x00007F46E3FD651A
00007f46e3fdac18  sub rsp, 0x08
00007f46e3fdac1c  push rax
00007f46e3fdac1d  push rcx
00007f46e3fdac1e  push rdx
00007f46e3fdac1f  push rdi
00007f46e3fdac20  push rsi
00007f46e3fdac21  push r8
00007f46e3fdac23  push r9
00007f46e3fdac25  push r10
00007f46e3fdac27  push r11
00007f46e3fdac29  sub rsp, 0xF0
00007f46e3fdac30  vmovaps [rsp], xmm0
00007f46e3fdac35  vmovaps [rsp+0x10], xmm1
00007f46e3fdac3b  vmovaps [rsp+0x20], xmm2
00007f46e3fdac41  vmovaps [rsp+0x30], xmm3
00007f46e3fdac47  vmovaps [rsp+0x40], xmm4
00007f46e3fdac4d  vmovaps [rsp+0x50], xmm5
00007f46e3fdac53  vmovaps [rsp+0x60], xmm6
00007f46e3fdac59  vmovaps [rsp+0x70], xmm7
00007f46e3fdac5f  vmovaps [rsp+0x80], xmm8
00007f46e3fdac68  vmovaps [rsp+0x90], xmm9
00007f46e3fdac71  vmovaps [rsp+0xA0], xmm10
00007f46e3fdac7a  vmovaps [rsp+0xB0], xmm11
00007f46e3fdac83  vmovaps [rsp+0xC0], xmm13
00007f46e3fdac8c  vmovaps [rsp+0xD0], xmm14
00007f46e3fdac95  vmovaps [rsp+0xE0], xmm15
00007f46e3fdac9e  sub rsp, 0x30
00007f46e3fdaca2  movaps [rsp], xmm12
00007f46e3fdaca7  movaps [rsp+0x10], xmm14
00007f46e3fdacad  movaps [rsp+0x20], xmm1
00007f46e3fdacb2  lea rdi, [rsp]
00007f46e3fdacb6  mov esi, 0x00
00007f46e3fdacbb  mov rax, 0x6238B185B530
00007f46e3fdacc5  call rax
00007f46e3fdacc7  movaps xmm12, [rsp]
00007f46e3fdaccc  add rsp, 0x30
00007f46e3fdacd0  vmovaps xmm0, [rsp]
00007f46e3fdacd5  vmovaps xmm1, [rsp+0x10]
00007f46e3fdacdb  vmovaps xmm2, [rsp+0x20]
00007f46e3fdace1  vmovaps xmm3, [rsp+0x30]
00007f46e3fdace7  vmovaps xmm4, [rsp+0x40]
00007f46e3fdaced  vmovaps xmm5, [rsp+0x50]
00007f46e3fdacf3  vmovaps xmm6, [rsp+0x60]
00007f46e3fdacf9  vmovaps xmm7, [rsp+0x70]
00007f46e3fdacff  vmovaps xmm8, [rsp+0x80]
00007f46e3fdad08  vmovaps xmm9, [rsp+0x90]
00007f46e3fdad11  vmovaps xmm10, [rsp+0xA0]
00007f46e3fdad1a  vmovaps xmm11, [rsp+0xB0]
00007f46e3fdad23  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdad2c  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdad35  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdad3e  add rsp, 0xF0
00007f46e3fdad45  pop r11
00007f46e3fdad47  pop r10
00007f46e3fdad49  pop r9
00007f46e3fdad4b  pop r8
00007f46e3fdad4d  pop rsi
00007f46e3fdad4e  pop rdi
00007f46e3fdad4f  pop rdx
00007f46e3fdad50  pop rcx
00007f46e3fdad51  pop rax
00007f46e3fdad52  add rsp, 0x08
00007f46e3fdad56  jmp 0x00007F46E3FD6549
00007f46e3fdad5b  sub rsp, 0x08
00007f46e3fdad5f  push rax
00007f46e3fdad60  push rcx
00007f46e3fdad61  push rdx
00007f46e3fdad62  push rdi
00007f46e3fdad63  push rsi
00007f46e3fdad64  push r8
00007f46e3fdad66  push r9
00007f46e3fdad68  push r10
00007f46e3fdad6a  push r11
00007f46e3fdad6c  sub rsp, 0xF0
00007f46e3fdad73  vmovaps [rsp], xmm0
00007f46e3fdad78  vmovaps [rsp+0x10], xmm1
00007f46e3fdad7e  vmovaps [rsp+0x20], xmm2
00007f46e3fdad84  vmovaps [rsp+0x30], xmm3
00007f46e3fdad8a  vmovaps [rsp+0x40], xmm4
00007f46e3fdad90  vmovaps [rsp+0x50], xmm5
00007f46e3fdad96  vmovaps [rsp+0x60], xmm6
00007f46e3fdad9c  vmovaps [rsp+0x70], xmm7
00007f46e3fdada2  vmovaps [rsp+0x80], xmm8
00007f46e3fdadab  vmovaps [rsp+0x90], xmm9
00007f46e3fdadb4  vmovaps [rsp+0xA0], xmm10
00007f46e3fdadbd  vmovaps [rsp+0xB0], xmm11
00007f46e3fdadc6  vmovaps [rsp+0xC0], xmm12
00007f46e3fdadcf  vmovaps [rsp+0xD0], xmm13
00007f46e3fdadd8  vmovaps [rsp+0xE0], xmm15
00007f46e3fdade1  sub rsp, 0x30
00007f46e3fdade5  movaps [rsp], xmm14
00007f46e3fdadea  movaps [rsp+0x10], xmm9
00007f46e3fdadf0  movaps [rsp+0x20], xmm1
00007f46e3fdadf5  lea rdi, [rsp]
00007f46e3fdadf9  mov esi, 0x00
00007f46e3fdadfe  mov rax, 0x6238B185B530
00007f46e3fdae08  call rax
00007f46e3fdae0a  movaps xmm14, [rsp]
00007f46e3fdae0f  add rsp, 0x30
00007f46e3fdae13  vmovaps xmm0, [rsp]
00007f46e3fdae18  vmovaps xmm1, [rsp+0x10]
00007f46e3fdae1e  vmovaps xmm2, [rsp+0x20]
00007f46e3fdae24  vmovaps xmm3, [rsp+0x30]
00007f46e3fdae2a  vmovaps xmm4, [rsp+0x40]
00007f46e3fdae30  vmovaps xmm5, [rsp+0x50]
00007f46e3fdae36  vmovaps xmm6, [rsp+0x60]
00007f46e3fdae3c  vmovaps xmm7, [rsp+0x70]
00007f46e3fdae42  vmovaps xmm8, [rsp+0x80]
00007f46e3fdae4b  vmovaps xmm9, [rsp+0x90]
00007f46e3fdae54  vmovaps xmm10, [rsp+0xA0]
00007f46e3fdae5d  vmovaps xmm11, [rsp+0xB0]
00007f46e3fdae66  vmovaps xmm12, [rsp+0xC0]
00007f46e3fdae6f  vmovaps xmm13, [rsp+0xD0]
00007f46e3fdae78  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdae81  add rsp, 0xF0
00007f46e3fdae88  pop r11
00007f46e3fdae8a  pop r10
00007f46e3fdae8c  pop r9
00007f46e3fdae8e  pop r8
00007f46e3fdae90  pop rsi
00007f46e3fdae91  pop rdi
00007f46e3fdae92  pop rdx
00007f46e3fdae93  pop rcx
00007f46e3fdae94  pop rax
00007f46e3fdae95  add rsp, 0x08
00007f46e3fdae99  jmp 0x00007F46E3FD6578
00007f46e3fdae9e  sub rsp, 0x08
00007f46e3fdaea2  push rax
00007f46e3fdaea3  push rcx
00007f46e3fdaea4  push rdx
00007f46e3fdaea5  push rdi
00007f46e3fdaea6  push rsi
00007f46e3fdaea7  push r8
00007f46e3fdaea9  push r9
00007f46e3fdaeab  push r10
00007f46e3fdaead  push r11
00007f46e3fdaeaf  sub rsp, 0xF0
00007f46e3fdaeb6  vmovaps [rsp], xmm0
00007f46e3fdaebb  vmovaps [rsp+0x10], xmm2
00007f46e3fdaec1  vmovaps [rsp+0x20], xmm3
00007f46e3fdaec7  vmovaps [rsp+0x30], xmm4
00007f46e3fdaecd  vmovaps [rsp+0x40], xmm5
00007f46e3fdaed3  vmovaps [rsp+0x50], xmm6
00007f46e3fdaed9  vmovaps [rsp+0x60], xmm7
00007f46e3fdaedf  vmovaps [rsp+0x70], xmm8
00007f46e3fdaee5  vmovaps [rsp+0x80], xmm9
00007f46e3fdaeee  vmovaps [rsp+0x90], xmm10
00007f46e3fdaef7  vmovaps [rsp+0xA0], xmm11
00007f46e3fdaf00  vmovaps [rsp+0xB0], xmm12
00007f46e3fdaf09  vmovaps [rsp+0xC0], xmm13
00007f46e3fdaf12  vmovaps [rsp+0xD0], xmm14
00007f46e3fdaf1b  vmovaps [rsp+0xE0], xmm15
00007f46e3fdaf24  sub rsp, 0x30
00007f46e3fdaf28  movaps [rsp], xmm1
00007f46e3fdaf2c  movaps [rsp+0x10], xmm13
00007f46e3fdaf32  movaps [rsp+0x20], xmm8
00007f46e3fdaf38  lea rdi, [rsp]
00007f46e3fdaf3c  mov esi, 0x00
00007f46e3fdaf41  mov rax, 0x6238B185B530
00007f46e3fdaf4b  call rax
00007f46e3fdaf4d  movaps xmm1, [rsp]
00007f46e3fdaf51  add rsp, 0x30
00007f46e3fdaf55  vmovaps xmm0, [rsp]
00007f46e3fdaf5a  vmovaps xmm2, [rsp+0x10]
00007f46e3fdaf60  vmovaps xmm3, [rsp+0x20]
00007f46e3fdaf66  vmovaps xmm4, [rsp+0x30]
00007f46e3fdaf6c  vmovaps xmm5, [rsp+0x40]
00007f46e3fdaf72  vmovaps xmm6, [rsp+0x50]
00007f46e3fdaf78  vmovaps xmm7, [rsp+0x60]
00007f46e3fdaf7e  vmovaps xmm8, [rsp+0x70]
00007f46e3fdaf84  vmovaps xmm9, [rsp+0x80]
00007f46e3fdaf8d  vmovaps xmm10, [rsp+0x90]
00007f46e3fdaf96  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdaf9f  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdafa8  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdafb1  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdafba  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdafc3  add rsp, 0xF0
00007f46e3fdafca  pop r11
00007f46e3fdafcc  pop r10
00007f46e3fdafce  pop r9
00007f46e3fdafd0  pop r8
00007f46e3fdafd2  pop rsi
00007f46e3fdafd3  pop rdi
00007f46e3fdafd4  pop rdx
00007f46e3fdafd5  pop rcx
00007f46e3fdafd6  pop rax
00007f46e3fdafd7  add rsp, 0x08
00007f46e3fdafdb  jmp 0x00007F46E3FD659A
00007f46e3fdafe0  call 0x00007F46E3E0C260
00007f46e3fdafe5  jmp 0x00007F46E3FD65A8
00007f46e3fdafea  call 0x00007F46E3EDE950
00007f46e3fdafef  jmp 0x00007F46E3FD65B2
00007f46e3fdaff4  sub rsp, 0x08
00007f46e3fdaff8  push rax
00007f46e3fdaff9  push rcx
00007f46e3fdaffa  push rdx
00007f46e3fdaffb  push rdi
00007f46e3fdaffc  push rsi
00007f46e3fdaffd  push r8
00007f46e3fdafff  push r9
00007f46e3fdb001  push r10
00007f46e3fdb003  push r11
00007f46e3fdb005  sub rsp, 0xF0
00007f46e3fdb00c  vmovaps [rsp], xmm0
00007f46e3fdb011  vmovaps [rsp+0x10], xmm1
00007f46e3fdb017  vmovaps [rsp+0x20], xmm2
00007f46e3fdb01d  vmovaps [rsp+0x30], xmm3
00007f46e3fdb023  vmovaps [rsp+0x40], xmm4
00007f46e3fdb029  vmovaps [rsp+0x50], xmm5
00007f46e3fdb02f  vmovaps [rsp+0x60], xmm6
00007f46e3fdb035  vmovaps [rsp+0x70], xmm7
00007f46e3fdb03b  vmovaps [rsp+0x80], xmm9
00007f46e3fdb044  vmovaps [rsp+0x90], xmm10
00007f46e3fdb04d  vmovaps [rsp+0xA0], xmm11
00007f46e3fdb056  vmovaps [rsp+0xB0], xmm12
00007f46e3fdb05f  vmovaps [rsp+0xC0], xmm13
00007f46e3fdb068  vmovaps [rsp+0xD0], xmm14
00007f46e3fdb071  vmovaps [rsp+0xE0], xmm15
00007f46e3fdb07a  sub rsp, 0x30
00007f46e3fdb07e  movaps [rsp], xmm8
00007f46e3fdb083  movaps [rsp+0x10], xmm15
00007f46e3fdb089  movaps [rsp+0x20], xmm7
00007f46e3fdb08e  lea rdi, [rsp]
00007f46e3fdb092  mov esi, 0x00
00007f46e3fdb097  mov rax, 0x6238B185B530
00007f46e3fdb0a1  call rax
00007f46e3fdb0a3  movaps xmm8, [rsp]
00007f46e3fdb0a8  add rsp, 0x30
00007f46e3fdb0ac  vmovaps xmm0, [rsp]
00007f46e3fdb0b1  vmovaps xmm1, [rsp+0x10]
00007f46e3fdb0b7  vmovaps xmm2, [rsp+0x20]
00007f46e3fdb0bd  vmovaps xmm3, [rsp+0x30]
00007f46e3fdb0c3  vmovaps xmm4, [rsp+0x40]
00007f46e3fdb0c9  vmovaps xmm5, [rsp+0x50]
00007f46e3fdb0cf  vmovaps xmm6, [rsp+0x60]
00007f46e3fdb0d5  vmovaps xmm7, [rsp+0x70]
00007f46e3fdb0db  vmovaps xmm9, [rsp+0x80]
00007f46e3fdb0e4  vmovaps xmm10, [rsp+0x90]
00007f46e3fdb0ed  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdb0f6  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdb0ff  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdb108  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdb111  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdb11a  add rsp, 0xF0
00007f46e3fdb121  pop r11
00007f46e3fdb123  pop r10
00007f46e3fdb125  pop r9
00007f46e3fdb127  pop r8
00007f46e3fdb129  pop rsi
00007f46e3fdb12a  pop rdi
00007f46e3fdb12b  pop rdx
00007f46e3fdb12c  pop rcx
00007f46e3fdb12d  pop rax
00007f46e3fdb12e  add rsp, 0x08
00007f46e3fdb132  jmp 0x00007F46E3FD65D4
00007f46e3fdb137  sub rsp, 0x08
00007f46e3fdb13b  push rax
00007f46e3fdb13c  push rcx
00007f46e3fdb13d  push rdx
00007f46e3fdb13e  push rdi
00007f46e3fdb13f  push rsi
00007f46e3fdb140  push r8
00007f46e3fdb142  push r9
00007f46e3fdb144  push r10
00007f46e3fdb146  push r11
00007f46e3fdb148  sub rsp, 0xF0
00007f46e3fdb14f  vmovaps [rsp], xmm0
00007f46e3fdb154  vmovaps [rsp+0x10], xmm1
00007f46e3fdb15a  vmovaps [rsp+0x20], xmm2
00007f46e3fdb160  vmovaps [rsp+0x30], xmm3
00007f46e3fdb166  vmovaps [rsp+0x40], xmm4
00007f46e3fdb16c  vmovaps [rsp+0x50], xmm5
00007f46e3fdb172  vmovaps [rsp+0x60], xmm6
00007f46e3fdb178  vmovaps [rsp+0x70], xmm8
00007f46e3fdb17e  vmovaps [rsp+0x80], xmm9
00007f46e3fdb187  vmovaps [rsp+0x90], xmm10
00007f46e3fdb190  vmovaps [rsp+0xA0], xmm11
00007f46e3fdb199  vmovaps [rsp+0xB0], xmm12
00007f46e3fdb1a2  vmovaps [rsp+0xC0], xmm13
00007f46e3fdb1ab  vmovaps [rsp+0xD0], xmm14
00007f46e3fdb1b4  vmovaps [rsp+0xE0], xmm15
00007f46e3fdb1bd  sub rsp, 0x30
00007f46e3fdb1c1  movaps [rsp], xmm7
00007f46e3fdb1c5  movaps [rsp+0x10], xmm9
00007f46e3fdb1cb  movaps [rsp+0x20], xmm15
00007f46e3fdb1d1  lea rdi, [rsp]
00007f46e3fdb1d5  mov esi, 0x00
00007f46e3fdb1da  mov rax, 0x6238B185B530
00007f46e3fdb1e4  call rax
00007f46e3fdb1e6  movaps xmm7, [rsp]
00007f46e3fdb1ea  add rsp, 0x30
00007f46e3fdb1ee  vmovaps xmm0, [rsp]
00007f46e3fdb1f3  vmovaps xmm1, [rsp+0x10]
00007f46e3fdb1f9  vmovaps xmm2, [rsp+0x20]
00007f46e3fdb1ff  vmovaps xmm3, [rsp+0x30]
00007f46e3fdb205  vmovaps xmm4, [rsp+0x40]
00007f46e3fdb20b  vmovaps xmm5, [rsp+0x50]
00007f46e3fdb211  vmovaps xmm6, [rsp+0x60]
00007f46e3fdb217  vmovaps xmm8, [rsp+0x70]
00007f46e3fdb21d  vmovaps xmm9, [rsp+0x80]
00007f46e3fdb226  vmovaps xmm10, [rsp+0x90]
00007f46e3fdb22f  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdb238  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdb241  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdb24a  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdb253  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdb25c  add rsp, 0xF0
00007f46e3fdb263  pop r11
00007f46e3fdb265  pop r10
00007f46e3fdb267  pop r9
00007f46e3fdb269  pop r8
00007f46e3fdb26b  pop rsi
00007f46e3fdb26c  pop rdi
00007f46e3fdb26d  pop rdx
00007f46e3fdb26e  pop rcx
00007f46e3fdb26f  pop rax
00007f46e3fdb270  add rsp, 0x08
00007f46e3fdb274  jmp 0x00007F46E3FD6601
00007f46e3fdb279  sub rsp, 0x08
00007f46e3fdb27d  push rax
00007f46e3fdb27e  push rcx
00007f46e3fdb27f  push rdx
00007f46e3fdb280  push rdi
00007f46e3fdb281  push rsi
00007f46e3fdb282  push r8
00007f46e3fdb284  push r9
00007f46e3fdb286  push r10
00007f46e3fdb288  push r11
00007f46e3fdb28a  sub rsp, 0xF0
00007f46e3fdb291  vmovaps [rsp], xmm0
00007f46e3fdb296  vmovaps [rsp+0x10], xmm1
00007f46e3fdb29c  vmovaps [rsp+0x20], xmm2
00007f46e3fdb2a2  vmovaps [rsp+0x30], xmm3
00007f46e3fdb2a8  vmovaps [rsp+0x40], xmm4
00007f46e3fdb2ae  vmovaps [rsp+0x50], xmm5
00007f46e3fdb2b4  vmovaps [rsp+0x60], xmm6
00007f46e3fdb2ba  vmovaps [rsp+0x70], xmm7
00007f46e3fdb2c0  vmovaps [rsp+0x80], xmm8
00007f46e3fdb2c9  vmovaps [rsp+0x90], xmm10
00007f46e3fdb2d2  vmovaps [rsp+0xA0], xmm11
00007f46e3fdb2db  vmovaps [rsp+0xB0], xmm12
00007f46e3fdb2e4  vmovaps [rsp+0xC0], xmm13
00007f46e3fdb2ed  vmovaps [rsp+0xD0], xmm14
00007f46e3fdb2f6  vmovaps [rsp+0xE0], xmm15
00007f46e3fdb2ff  sub rsp, 0x30
00007f46e3fdb303  movaps [rsp], xmm9
00007f46e3fdb308  movaps [rsp+0x10], xmm13
00007f46e3fdb30e  movaps [rsp+0x20], xmm15
00007f46e3fdb314  lea rdi, [rsp]
00007f46e3fdb318  mov esi, 0x00
00007f46e3fdb31d  mov rax, 0x6238B185B530
00007f46e3fdb327  call rax
00007f46e3fdb329  movaps xmm9, [rsp]
00007f46e3fdb32e  add rsp, 0x30
00007f46e3fdb332  vmovaps xmm0, [rsp]
00007f46e3fdb337  vmovaps xmm1, [rsp+0x10]
00007f46e3fdb33d  vmovaps xmm2, [rsp+0x20]
00007f46e3fdb343  vmovaps xmm3, [rsp+0x30]
00007f46e3fdb349  vmovaps xmm4, [rsp+0x40]
00007f46e3fdb34f  vmovaps xmm5, [rsp+0x50]
00007f46e3fdb355  vmovaps xmm6, [rsp+0x60]
00007f46e3fdb35b  vmovaps xmm7, [rsp+0x70]
00007f46e3fdb361  vmovaps xmm8, [rsp+0x80]
00007f46e3fdb36a  vmovaps xmm10, [rsp+0x90]
00007f46e3fdb373  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdb37c  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdb385  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdb38e  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdb397  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdb3a0  add rsp, 0xF0
00007f46e3fdb3a7  pop r11
00007f46e3fdb3a9  pop r10
00007f46e3fdb3ab  pop r9
00007f46e3fdb3ad  pop r8
00007f46e3fdb3af  pop rsi
00007f46e3fdb3b0  pop rdi
00007f46e3fdb3b1  pop rdx
00007f46e3fdb3b2  pop rcx
00007f46e3fdb3b3  pop rax
00007f46e3fdb3b4  add rsp, 0x08
00007f46e3fdb3b8  jmp 0x00007F46E3FD662F
00007f46e3fdb3bd  sub rsp, 0x08
00007f46e3fdb3c1  push rax
00007f46e3fdb3c2  push rcx
00007f46e3fdb3c3  push rdx
00007f46e3fdb3c4  push rdi
00007f46e3fdb3c5  push rsi
00007f46e3fdb3c6  push r8
00007f46e3fdb3c8  push r9
00007f46e3fdb3ca  push r10
00007f46e3fdb3cc  push r11
00007f46e3fdb3ce  sub rsp, 0xF0
00007f46e3fdb3d5  vmovaps [rsp], xmm0
00007f46e3fdb3da  vmovaps [rsp+0x10], xmm1
00007f46e3fdb3e0  vmovaps [rsp+0x20], xmm2
00007f46e3fdb3e6  vmovaps [rsp+0x30], xmm3
00007f46e3fdb3ec  vmovaps [rsp+0x40], xmm4
00007f46e3fdb3f2  vmovaps [rsp+0x50], xmm5
00007f46e3fdb3f8  vmovaps [rsp+0x60], xmm6
00007f46e3fdb3fe  vmovaps [rsp+0x70], xmm7
00007f46e3fdb404  vmovaps [rsp+0x80], xmm8
00007f46e3fdb40d  vmovaps [rsp+0x90], xmm9
00007f46e3fdb416  vmovaps [rsp+0xA0], xmm10
00007f46e3fdb41f  vmovaps [rsp+0xB0], xmm11
00007f46e3fdb428  vmovaps [rsp+0xC0], xmm12
00007f46e3fdb431  vmovaps [rsp+0xD0], xmm13
00007f46e3fdb43a  vmovaps [rsp+0xE0], xmm14
00007f46e3fdb443  sub rsp, 0x30
00007f46e3fdb447  movaps [rsp], xmm15
00007f46e3fdb44c  movaps [rsp+0x10], xmm11
00007f46e3fdb452  movaps [rsp+0x20], xmm12
00007f46e3fdb458  lea rdi, [rsp]
00007f46e3fdb45c  mov esi, 0x00
00007f46e3fdb461  mov rax, 0x6238B185B530
00007f46e3fdb46b  call rax
00007f46e3fdb46d  movaps xmm15, [rsp]
00007f46e3fdb472  add rsp, 0x30
00007f46e3fdb476  vmovaps xmm0, [rsp]
00007f46e3fdb47b  vmovaps xmm1, [rsp+0x10]
00007f46e3fdb481  vmovaps xmm2, [rsp+0x20]
00007f46e3fdb487  vmovaps xmm3, [rsp+0x30]
00007f46e3fdb48d  vmovaps xmm4, [rsp+0x40]
00007f46e3fdb493  vmovaps xmm5, [rsp+0x50]
00007f46e3fdb499  vmovaps xmm6, [rsp+0x60]
00007f46e3fdb49f  vmovaps xmm7, [rsp+0x70]
00007f46e3fdb4a5  vmovaps xmm8, [rsp+0x80]
00007f46e3fdb4ae  vmovaps xmm9, [rsp+0x90]
00007f46e3fdb4b7  vmovaps xmm10, [rsp+0xA0]
00007f46e3fdb4c0  vmovaps xmm11, [rsp+0xB0]
00007f46e3fdb4c9  vmovaps xmm12, [rsp+0xC0]
00007f46e3fdb4d2  vmovaps xmm13, [rsp+0xD0]
00007f46e3fdb4db  vmovaps xmm14, [rsp+0xE0]
00007f46e3fdb4e4  add rsp, 0xF0
00007f46e3fdb4eb  pop r11
00007f46e3fdb4ed  pop r10
00007f46e3fdb4ef  pop r9
00007f46e3fdb4f1  pop r8
00007f46e3fdb4f3  pop rsi
00007f46e3fdb4f4  pop rdi
00007f46e3fdb4f5  pop rdx
00007f46e3fdb4f6  pop rcx
00007f46e3fdb4f7  pop rax
00007f46e3fdb4f8  add rsp, 0x08
00007f46e3fdb4fc  jmp 0x00007F46E3FD664A
00007f46e3fdb501  sub rsp, 0x08
00007f46e3fdb505  push rax
00007f46e3fdb506  push rcx
00007f46e3fdb507  push rdx
00007f46e3fdb508  push rdi
00007f46e3fdb509  push rsi
00007f46e3fdb50a  push r8
00007f46e3fdb50c  push r9
00007f46e3fdb50e  push r10
00007f46e3fdb510  push r11
00007f46e3fdb512  sub rsp, 0xF0
00007f46e3fdb519  vmovaps [rsp], xmm0
00007f46e3fdb51e  vmovaps [rsp+0x10], xmm1
00007f46e3fdb524  vmovaps [rsp+0x20], xmm2
00007f46e3fdb52a  vmovaps [rsp+0x30], xmm3
00007f46e3fdb530  vmovaps [rsp+0x40], xmm4
00007f46e3fdb536  vmovaps [rsp+0x50], xmm5
00007f46e3fdb53c  vmovaps [rsp+0x60], xmm6
00007f46e3fdb542  vmovaps [rsp+0x70], xmm7
00007f46e3fdb548  vmovaps [rsp+0x80], xmm8
00007f46e3fdb551  vmovaps [rsp+0x90], xmm9
00007f46e3fdb55a  vmovaps [rsp+0xA0], xmm10
00007f46e3fdb563  vmovaps [rsp+0xB0], xmm11
00007f46e3fdb56c  vmovaps [rsp+0xC0], xmm12
00007f46e3fdb575  vmovaps [rsp+0xD0], xmm14
00007f46e3fdb57e  vmovaps [rsp+0xE0], xmm15
00007f46e3fdb587  sub rsp, 0x30
00007f46e3fdb58b  movaps [rsp], xmm13
00007f46e3fdb590  movaps [rsp+0x10], xmm10
00007f46e3fdb596  movaps [rsp+0x20], xmm14
00007f46e3fdb59c  lea rdi, [rsp]
00007f46e3fdb5a0  mov esi, 0x00
00007f46e3fdb5a5  mov rax, 0x6238B185B530
00007f46e3fdb5af  call rax
00007f46e3fdb5b1  movaps xmm13, [rsp]
00007f46e3fdb5b6  add rsp, 0x30
00007f46e3fdb5ba  vmovaps xmm0, [rsp]
00007f46e3fdb5bf  vmovaps xmm1, [rsp+0x10]
00007f46e3fdb5c5  vmovaps xmm2, [rsp+0x20]
00007f46e3fdb5cb  vmovaps xmm3, [rsp+0x30]
00007f46e3fdb5d1  vmovaps xmm4, [rsp+0x40]
00007f46e3fdb5d7  vmovaps xmm5, [rsp+0x50]
00007f46e3fdb5dd  vmovaps xmm6, [rsp+0x60]
00007f46e3fdb5e3  vmovaps xmm7, [rsp+0x70]
00007f46e3fdb5e9  vmovaps xmm8, [rsp+0x80]
00007f46e3fdb5f2  vmovaps xmm9, [rsp+0x90]
00007f46e3fdb5fb  vmovaps xmm10, [rsp+0xA0]
00007f46e3fdb604  vmovaps xmm11, [rsp+0xB0]
00007f46e3fdb60d  vmovaps xmm12, [rsp+0xC0]
00007f46e3fdb616  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdb61f  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdb628  add rsp, 0xF0
00007f46e3fdb62f  pop r11
00007f46e3fdb631  pop r10
00007f46e3fdb633  pop r9
00007f46e3fdb635  pop r8
00007f46e3fdb637  pop rsi
00007f46e3fdb638  pop rdi
00007f46e3fdb639  pop rdx
00007f46e3fdb63a  pop rcx
00007f46e3fdb63b  pop rax
00007f46e3fdb63c  add rsp, 0x08
00007f46e3fdb640  jmp 0x00007F46E3FD666D
00007f46e3fdb645  sub rsp, 0x08
00007f46e3fdb649  push rax
00007f46e3fdb64a  push rcx
00007f46e3fdb64b  push rdx
00007f46e3fdb64c  push rdi
00007f46e3fdb64d  push rsi
00007f46e3fdb64e  push r8
00007f46e3fdb650  push r9
00007f46e3fdb652  push r10
00007f46e3fdb654  push r11
00007f46e3fdb656  sub rsp, 0xF0
00007f46e3fdb65d  vmovaps [rsp], xmm0
00007f46e3fdb662  vmovaps [rsp+0x10], xmm1
00007f46e3fdb668  vmovaps [rsp+0x20], xmm2
00007f46e3fdb66e  vmovaps [rsp+0x30], xmm3
00007f46e3fdb674  vmovaps [rsp+0x40], xmm4
00007f46e3fdb67a  vmovaps [rsp+0x50], xmm5
00007f46e3fdb680  vmovaps [rsp+0x60], xmm6
00007f46e3fdb686  vmovaps [rsp+0x70], xmm7
00007f46e3fdb68c  vmovaps [rsp+0x80], xmm8
00007f46e3fdb695  vmovaps [rsp+0x90], xmm9
00007f46e3fdb69e  vmovaps [rsp+0xA0], xmm10
00007f46e3fdb6a7  vmovaps [rsp+0xB0], xmm11
00007f46e3fdb6b0  vmovaps [rsp+0xC0], xmm12
00007f46e3fdb6b9  vmovaps [rsp+0xD0], xmm13
00007f46e3fdb6c2  vmovaps [rsp+0xE0], xmm15
00007f46e3fdb6cb  sub rsp, 0x30
00007f46e3fdb6cf  movaps [rsp], xmm14
00007f46e3fdb6d4  movaps [rsp+0x10], xmm1
00007f46e3fdb6d9  movaps [rsp+0x20], xmm7
00007f46e3fdb6de  lea rdi, [rsp]
00007f46e3fdb6e2  mov esi, 0x00
00007f46e3fdb6e7  mov rax, 0x6238B185B530
00007f46e3fdb6f1  call rax
00007f46e3fdb6f3  movaps xmm14, [rsp]
00007f46e3fdb6f8  add rsp, 0x30
00007f46e3fdb6fc  vmovaps xmm0, [rsp]
00007f46e3fdb701  vmovaps xmm1, [rsp+0x10]
00007f46e3fdb707  vmovaps xmm2, [rsp+0x20]
00007f46e3fdb70d  vmovaps xmm3, [rsp+0x30]
00007f46e3fdb713  vmovaps xmm4, [rsp+0x40]
00007f46e3fdb719  vmovaps xmm5, [rsp+0x50]
00007f46e3fdb71f  vmovaps xmm6, [rsp+0x60]
00007f46e3fdb725  vmovaps xmm7, [rsp+0x70]
00007f46e3fdb72b  vmovaps xmm8, [rsp+0x80]
00007f46e3fdb734  vmovaps xmm9, [rsp+0x90]
00007f46e3fdb73d  vmovaps xmm10, [rsp+0xA0]
00007f46e3fdb746  vmovaps xmm11, [rsp+0xB0]
00007f46e3fdb74f  vmovaps xmm12, [rsp+0xC0]
00007f46e3fdb758  vmovaps xmm13, [rsp+0xD0]
00007f46e3fdb761  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdb76a  add rsp, 0xF0
00007f46e3fdb771  pop r11
00007f46e3fdb773  pop r10
00007f46e3fdb775  pop r9
00007f46e3fdb777  pop r8
00007f46e3fdb779  pop rsi
00007f46e3fdb77a  pop rdi
00007f46e3fdb77b  pop rdx
00007f46e3fdb77c  pop rcx
00007f46e3fdb77d  pop rax
00007f46e3fdb77e  add rsp, 0x08
00007f46e3fdb782  jmp 0x00007F46E3FD6690
00007f46e3fdb787  sub rsp, 0x08
00007f46e3fdb78b  push rax
00007f46e3fdb78c  push rcx
00007f46e3fdb78d  push rdx
00007f46e3fdb78e  push rdi
00007f46e3fdb78f  push rsi
00007f46e3fdb790  push r8
00007f46e3fdb792  push r9
00007f46e3fdb794  push r10
00007f46e3fdb796  push r11
00007f46e3fdb798  sub rsp, 0xF0
00007f46e3fdb79f  vmovaps [rsp], xmm0
00007f46e3fdb7a4  vmovaps [rsp+0x10], xmm2
00007f46e3fdb7aa  vmovaps [rsp+0x20], xmm3
00007f46e3fdb7b0  vmovaps [rsp+0x30], xmm4
00007f46e3fdb7b6  vmovaps [rsp+0x40], xmm5
00007f46e3fdb7bc  vmovaps [rsp+0x50], xmm6
00007f46e3fdb7c2  vmovaps [rsp+0x60], xmm7
00007f46e3fdb7c8  vmovaps [rsp+0x70], xmm8
00007f46e3fdb7ce  vmovaps [rsp+0x80], xmm9
00007f46e3fdb7d7  vmovaps [rsp+0x90], xmm10
00007f46e3fdb7e0  vmovaps [rsp+0xA0], xmm11
00007f46e3fdb7e9  vmovaps [rsp+0xB0], xmm12
00007f46e3fdb7f2  vmovaps [rsp+0xC0], xmm13
00007f46e3fdb7fb  vmovaps [rsp+0xD0], xmm14
00007f46e3fdb804  vmovaps [rsp+0xE0], xmm15
00007f46e3fdb80d  sub rsp, 0x30
00007f46e3fdb811  movaps [rsp], xmm1
00007f46e3fdb815  movaps [rsp+0x10], xmm8
00007f46e3fdb81b  movaps [rsp+0x20], xmm9
00007f46e3fdb821  lea rdi, [rsp]
00007f46e3fdb825  mov esi, 0x00
00007f46e3fdb82a  mov rax, 0x6238B185B530
00007f46e3fdb834  call rax
00007f46e3fdb836  movaps xmm1, [rsp]
00007f46e3fdb83a  add rsp, 0x30
00007f46e3fdb83e  vmovaps xmm0, [rsp]
00007f46e3fdb843  vmovaps xmm2, [rsp+0x10]
00007f46e3fdb849  vmovaps xmm3, [rsp+0x20]
00007f46e3fdb84f  vmovaps xmm4, [rsp+0x30]
00007f46e3fdb855  vmovaps xmm5, [rsp+0x40]
00007f46e3fdb85b  vmovaps xmm6, [rsp+0x50]
00007f46e3fdb861  vmovaps xmm7, [rsp+0x60]
00007f46e3fdb867  vmovaps xmm8, [rsp+0x70]
00007f46e3fdb86d  vmovaps xmm9, [rsp+0x80]
00007f46e3fdb876  vmovaps xmm10, [rsp+0x90]
00007f46e3fdb87f  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdb888  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdb891  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdb89a  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdb8a3  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdb8ac  add rsp, 0xF0
00007f46e3fdb8b3  pop r11
00007f46e3fdb8b5  pop r10
00007f46e3fdb8b7  pop r9
00007f46e3fdb8b9  pop r8
00007f46e3fdb8bb  pop rsi
00007f46e3fdb8bc  pop rdi
00007f46e3fdb8bd  pop rdx
00007f46e3fdb8be  pop rcx
00007f46e3fdb8bf  pop rax
00007f46e3fdb8c0  add rsp, 0x08
00007f46e3fdb8c4  jmp 0x00007F46E3FD66B2
00007f46e3fdb8c9  call 0x00007F46E3EB3E40
00007f46e3fdb8ce  jmp 0x00007F46E3FD66C0
00007f46e3fdb8d3  call 0x00007F46E3E0C380
00007f46e3fdb8d8  jmp 0x00007F46E3FD66CA
00007f46e3fdb8dd  call 0x00007F46E3E0D600
00007f46e3fdb8e2  jmp 0x00007F46E3FD66D4
00007f46e3fdb8e7  call 0x00007F46E3DFF540
00007f46e3fdb8ec  jmp 0x00007F46E3FD66DE
00007f46e3fdb8f1  int3
00007f46e3fdb8f2  nop [rax+rax*1], ax
00007f46e3fdb8fb  nop [rax+rax*1], eax
00007f46e3fdb900  mov eax, [r15+0x48]
00007f46e3fdb904  lea r14d, [eax+0x01]
00007f46e3fdb909  mov [rsp+0x10], r14d
00007f46e3fdb90e  mov r14d, r14d
00007f46e3fdb911  mov [r15+0x48], r14
00007f46e3fdb915  xor eax, eax
00007f46e3fdb917  mov r14d, [rsp+0x10]
00007f46e3fdb91c  cmp r14d, 0x1F4
00007f46e3fdb923  cmc
00007f46e3fdb924  lahf
00007f46e3fdb925  seto al
00007f46e3fdb928  mov [r15+0x108], eax
00007f46e3fdb92f  mov eax, [r15+0x108]
00007f46e3fdb936  sahf
00007f46e3fdb937  jnz 0x00007F46E3FDB969
00007f46e3fdb939  cmp dword ptr [r15+0x318], 0x00
00007f46e3fdb941  jz 0x00007F46E3FE1AB0
00007f46e3fdb947  nop [rax+rax*1], ax
00007f46e3fdb950  nop [rax+rax*1], eax
00007f46e3fdb958  mov eax, 0x410450
00007f46e3fdb95d  mov [r15+0x100], rax
00007f46e3fdb964  jmp 0x00007F46E3DFE110
00007f46e3fdb969  cmp dword ptr [r15+0x318], 0x00
00007f46e3fdb971  jz 0x00007F46E3FDB9A0
00007f46e3fdb977  nop [rax+rax*1], ax
00007f46e3fdb980  nop [rax+rax*1], eax
00007f46e3fdb988  mov eax, 0x410274
00007f46e3fdb98d  mov [r15+0x100], rax
00007f46e3fdb994  jmp 0x00007F46E3DFE110
00007f46e3fdb999  int3
00007f46e3fdb99a  int3
00007f46e3fdb99b  nop [rax+rax*1], eax
00007f46e3fdb9a0  mov rax, [r15+0x40]
00007f46e3fdb9a4  movaps xmm1, [r15+0x1D0]
00007f46e3fdb9ac  vmovaps [rsp+0x10], xmm1
00007f46e3fdb9b2  vmovaps xmm15, [rsp+0x10]
00007f46e3fdb9b8  por xmm1, xmm15
00007f46e3fdb9bd  movaps xmm14, [r15+0x1A0]
00007f46e3fdb9c5  vmovaps [rsp+0x10], xmm14
00007f46e3fdb9cb  vmovaps xmm13, [rsp+0x10]
00007f46e3fdb9d1  por xmm14, xmm13
00007f46e3fdb9d6  lea r14, [rax+0x30]
00007f46e3fdb9da  mov r12, [r13+r14*1]
00007f46e3fdb9df  lea r14, [rax+0x38]
00007f46e3fdb9e3  mov r11, [r13+r14*1]
00007f46e3fdb9e8  movq xmm13, r12
00007f46e3fdb9ed  movq xmm12, r11
00007f46e3fdb9f2  movq xmm13, xmm13
00007f46e3fdb9f7  vmovaps [rsp+0x10], xmm13
00007f46e3fdb9fd  movq xmm13, xmm13
00007f46e3fdba02  movaps [r15+0x130], xmm13
00007f46e3fdba0a  movq xmm12, xmm12
00007f46e3fdba0f  vmovaps [rsp+0x20], xmm12
00007f46e3fdba15  movq xmm12, xmm12
00007f46e3fdba1a  movaps [r15+0x280], xmm12
00007f46e3fdba22  movaps xmm13, [r15+0x270]
00007f46e3fdba2a  vmovaps [rsp+0x30], xmm13
00007f46e3fdba30  vmovaps xmm12, [rsp+0x30]
00007f46e3fdba36  por xmm13, xmm12
00007f46e3fdba3b  lea r14, [rax+0x20]
00007f46e3fdba3f  mov r12, [r13+r14*1]
00007f46e3fdba44  lea r14, [rax+0x28]
00007f46e3fdba48  mov r11, [r13+r14*1]
00007f46e3fdba4d  movq xmm12, r12
00007f46e3fdba52  movq xmm11, r11
00007f46e3fdba57  movq xmm12, xmm12
00007f46e3fdba5c  vmovaps [rsp+0x30], xmm12
00007f46e3fdba62  movq xmm12, xmm12
00007f46e3fdba67  movaps [r15+0x150], xmm12
00007f46e3fdba6f  movq xmm11, xmm11
00007f46e3fdba74  vmovaps [rsp+0x40], xmm11
00007f46e3fdba7a  movq xmm11, xmm11
00007f46e3fdba7f  movaps [r15+0x140], xmm11
00007f46e3fdba87  lea r14, [rax+0x10]
00007f46e3fdba8b  mov r12, [r13+r14*1]
00007f46e3fdba90  lea r14, [rax+0x18]
00007f46e3fdba94  mov r11, [r13+r14*1]
00007f46e3fdba99  movq xmm12, r12
00007f46e3fdba9e  movq xmm11, r11
00007f46e3fdbaa3  movq xmm12, xmm12
00007f46e3fdbaa8  vmovaps [rsp+0x50], xmm12
00007f46e3fdbaae  movq xmm12, xmm12
00007f46e3fdbab3  movaps [r15+0x170], xmm12
00007f46e3fdbabb  movq xmm11, xmm11
00007f46e3fdbac0  vmovaps [rsp+0x60], xmm11
00007f46e3fdbac6  movq xmm11, xmm11
00007f46e3fdbacb  movaps [r15+0x160], xmm11
00007f46e3fdbad3  mov r14, [r13+rax*1]
00007f46e3fdbad8  vmovq xmm12, r14
00007f46e3fdbadd  vpbroadcastq xmm12, xmm12
00007f46e3fdbae2  lea r14, [rax+0x08]
00007f46e3fdbae6  mov rax, [r13+r14*1]
00007f46e3fdbaeb  movq xmm11, rax
00007f46e3fdbaf0  movaps [r15+0x230], xmm11
00007f46e3fdbaf8  mov rax, [r15+0xF8]
00007f46e3fdbaff  lea r14, [rax+0x50]
00007f46e3fdbb03  movups xmm11, [r13+r14*1]
00007f46e3fdbb09  lea r14, [rax+0x60]
00007f46e3fdbb0d  movups xmm10, [r13+r14*1]
00007f46e3fdbb13  lea r14, [rax+0x30]
00007f46e3fdbb17  movups xmm9, [r13+r14*1]
00007f46e3fdbb1d  mov r14, [r15+0x50]
00007f46e3fdbb21  mov [r15+0x60], r14
00007f46e3fdbb25  mov qword ptr [r15+0x58], 0x40
00007f46e3fdbb2d  movaps xmm8, xmm12
00007f46e3fdbb31  mulpd xmm8, xmm15
00007f46e3fdbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007f46e3fdbb3c  ptest xmm7, xmm7
00007f46e3fdbb41  jnz 0x00007F46E3FDC96A
00007f46e3fdbb47  movq xmm15, qword ptr [r15+0x230]
00007f46e3fdbb50  vmovaps [rsp+0x70], xmm15
00007f46e3fdbb56  vpermilpd xmm15, xmm15, 0x00
00007f46e3fdbb5c  movaps xmm7, xmm9
00007f46e3fdbb60  mulpd xmm7, xmm15
00007f46e3fdbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007f46e3fdbb6a  ptest xmm6, xmm6
00007f46e3fdbb6f  jnz 0x00007F46E3FDCAAE
00007f46e3fdbb75  vxorps xmm15, xmm15, xmm15
00007f46e3fdbb7a  vpbroadcastq xmm15, xmm15
00007f46e3fdbb7f  movaps xmm9, xmm12
00007f46e3fdbb83  mulpd xmm9, xmm10
00007f46e3fdbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007f46e3fdbb8e  ptest xmm6, xmm6
00007f46e3fdbb93  jnz 0x00007F46E3FDCBF0
00007f46e3fdbb99  movaps xmm10, xmm12
00007f46e3fdbb9d  mulpd xmm10, xmm11
00007f46e3fdbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007f46e3fdbba8  ptest xmm6, xmm6
00007f46e3fdbbad  jnz 0x00007F46E3FDCD34
00007f46e3fdbbb3  movaps xmm11, [r15+0x1F0]
00007f46e3fdbbbb  movaps xmm6, xmm12
00007f46e3fdbbbf  mulpd xmm6, xmm11
00007f46e3fdbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007f46e3fdbbc9  ptest xmm5, xmm5
00007f46e3fdbbce  jnz 0x00007F46E3FDCE78
00007f46e3fdbbd4  movaps xmm12, [r15+0x2A0]
00007f46e3fdbbdc  vmovaps [rsp+0x80], xmm12
00007f46e3fdbbe5  vmovaps xmm11, [rsp+0x80]
00007f46e3fdbbee  por xmm12, xmm11
00007f46e3fdbbf3  movaps xmm11, [r15+0x250]
00007f46e3fdbbfb  vmovaps [rsp+0x80], xmm11
00007f46e3fdbc04  vmovaps xmm5, [rsp+0x80]
00007f46e3fdbc0d  por xmm11, xmm5
00007f46e3fdbc12  vmovaps xmm4, [rsp+0x70]
00007f46e3fdbc18  vpermilpd xmm4, xmm4, 0x00
00007f46e3fdbc1e  movaps xmm3, xmm5
00007f46e3fdbc21  mulpd xmm3, xmm4
00007f46e3fdbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007f46e3fdbc2a  ptest xmm2, xmm2
00007f46e3fdbc2f  jnz 0x00007F46E3FDCFBA
00007f46e3fdbc35  mov [rsp+0x80], rax
00007f46e3fdbc3d  xor eax, eax
00007f46e3fdbc3f  mov r12d, 0x40
00007f46e3fdbc45  mov r11d, 0x200
00007f46e3fdbc4b  cmp r12, r11
00007f46e3fdbc4e  cmc
00007f46e3fdbc4f  lahf
00007f46e3fdbc50  seto al
00007f46e3fdbc53  mov [r15+0x108], eax
00007f46e3fdbc5a  movaps xmm5, xmm8
00007f46e3fdbc5e  addpd xmm5, xmm15
00007f46e3fdbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007f46e3fdbc68  ptest xmm4, xmm4
00007f46e3fdbc6d  jnz 0x00007F46E3FDD0FA
00007f46e3fdbc73  movaps xmm8, [r15+0x1B0]
00007f46e3fdbc7b  movaps xmm4, xmm9
00007f46e3fdbc7f  addpd xmm4, xmm8
00007f46e3fdbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007f46e3fdbc89  ptest xmm2, xmm2
00007f46e3fdbc8e  jnz 0x00007F46E3FDD23C
00007f46e3fdbc94  movaps xmm9, xmm10
00007f46e3fdbc98  addpd xmm9, xmm8
00007f46e3fdbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007f46e3fdbca3  ptest xmm2, xmm2
00007f46e3fdbca8  jnz 0x00007F46E3FDD37E
00007f46e3fdbcae  movaps xmm10, [r15+0x2F0]
00007f46e3fdbcb6  vmovaps [rsp+0x90], xmm10
00007f46e3fdbcbf  vmovaps xmm8, [rsp+0x90]
00007f46e3fdbcc8  por xmm10, xmm8
00007f46e3fdbccd  movaps xmm8, [r15+0x2E0]
00007f46e3fdbcd5  vmovaps [rsp+0x90], xmm8
00007f46e3fdbcde  vmovaps xmm2, [rsp+0x90]
00007f46e3fdbce7  por xmm8, xmm2
00007f46e3fdbcec  movaps xmm2, [r15+0x2D0]
00007f46e3fdbcf4  vmovaps [rsp+0x90], xmm2
00007f46e3fdbcfd  vmovaps [rsp+0xA0], xmm1
00007f46e3fdbd06  vmovaps xmm1, [rsp+0x90]
00007f46e3fdbd0f  por xmm2, xmm1
00007f46e3fdbd13  movaps xmm1, [r15+0x200]
00007f46e3fdbd1b  vmovaps [rsp+0x90], xmm1
00007f46e3fdbd24  vmovaps [rsp+0xB0], xmm15
00007f46e3fdbd2d  vmovaps xmm15, [rsp+0x90]
00007f46e3fdbd36  por xmm1, xmm15
00007f46e3fdbd3b  movaps xmm15, [r15+0x1C0]
00007f46e3fdbd43  vmovaps [rsp+0x90], xmm15
00007f46e3fdbd4c  vmovaps [rsp+0xC0], xmm1
00007f46e3fdbd55  vmovaps xmm1, [rsp+0x90]
00007f46e3fdbd5e  por xmm15, xmm1
00007f46e3fdbd63  movaps xmm1, [r15+0x190]
00007f46e3fdbd6b  vmovaps [rsp+0x90], xmm1
00007f46e3fdbd74  vmovaps [rsp+0xD0], xmm15
00007f46e3fdbd7d  vmovaps xmm15, [rsp+0x90]
00007f46e3fdbd86  por xmm1, xmm15
00007f46e3fdbd8b  movaps xmm15, [r15+0x300]
00007f46e3fdbd93  vmovaps [rsp+0x90], xmm15
00007f46e3fdbd9c  vmovaps [rsp+0xE0], xmm1
00007f46e3fdbda5  vmovaps xmm1, [rsp+0x90]
00007f46e3fdbdae  por xmm15, xmm1
00007f46e3fdbdb3  mov rax, [rsp+0x80]
00007f46e3fdbdbb  lea r12, [rax+0xA0]
00007f46e3fdbdc2  movups xmm1, [r13+r12*1]
00007f46e3fdbdc8  lea r12, [rax+0xB0]
00007f46e3fdbdcf  vmovaps [rsp+0x80], xmm1
00007f46e3fdbdd8  movups xmm1, [r13+r12*1]
00007f46e3fdbdde  vmovaps [rsp+0x90], xmm1
00007f46e3fdbde7  vmovaps [rsp+0xF0], xmm15
00007f46e3fdbdf0  vmovaps xmm15, [rsp+0xB0]
00007f46e3fdbdf9  vmovaps [rsp+0xB0], xmm14
00007f46e3fdbe02  movaps xmm1, xmm6
00007f46e3fdbe05  addpd xmm1, xmm15
00007f46e3fdbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007f46e3fdbe0f  ptest xmm14, xmm14
00007f46e3fdbe15  jnz 0x00007F46E3FDD4D6
00007f46e3fdbe1b  lea r12, [rax+0xF0]
00007f46e3fdbe22  movups xmm15, [r13+r12*1]
00007f46e3fdbe28  movaps xmm14, xmm4
00007f46e3fdbe2c  addpd xmm14, xmm3
00007f46e3fdbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007f46e3fdbe37  ptest xmm6, xmm6
00007f46e3fdbe3c  jnz 0x00007F46E3FDD621
00007f46e3fdbe42  movaps xmm6, xmm9
00007f46e3fdbe46  addpd xmm6, xmm7
00007f46e3fdbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007f46e3fdbe4f  ptest xmm4, xmm4
00007f46e3fdbe54  jnz 0x00007F46E3FDD763
00007f46e3fdbe5a  vmovaps xmm9, [rsp+0x70]
00007f46e3fdbe60  vpermilpd xmm9, xmm9, 0x00
00007f46e3fdbe66  vmovaps xmm4, [rsp+0x90]
00007f46e3fdbe6f  movaps xmm7, xmm4
00007f46e3fdbe72  mulpd xmm7, xmm9
00007f46e3fdbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007f46e3fdbe7c  ptest xmm3, xmm3
00007f46e3fdbe81  jnz 0x00007F46E3FDD8A4
00007f46e3fdbe87  vmovaps xmm9, [rsp+0x50]
00007f46e3fdbe8d  vpermilpd xmm9, xmm9, 0x00
00007f46e3fdbe93  movaps xmm4, xmm15
00007f46e3fdbe97  mulpd xmm4, xmm9
00007f46e3fdbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007f46e3fdbea1  ptest xmm3, xmm3
00007f46e3fdbea6  jnz 0x00007F46E3FDD9E5
00007f46e3fdbeac  lea r12, [rax+0xE0]
00007f46e3fdbeb3  movups xmm15, [r13+r12*1]
00007f46e3fdbeb9  vmovaps xmm9, [rsp+0x70]
00007f46e3fdbebf  vpermilpd xmm9, xmm9, 0x00
00007f46e3fdbec5  vmovaps [rsp+0x70], xmm1
00007f46e3fdbecb  vmovaps xmm1, [rsp+0x80]
00007f46e3fdbed4  vmovaps [rsp+0x80], xmm15
00007f46e3fdbedd  movaps xmm3, xmm1
00007f46e3fdbee0  mulpd xmm3, xmm9
00007f46e3fdbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007f46e3fdbeea  ptest xmm15, xmm15
00007f46e3fdbef0  jnz 0x00007F46E3FDDB31
00007f46e3fdbef6  vmovaps xmm1, [rsp+0xF0]
00007f46e3fdbeff  vmovaps xmm15, [rsp+0xF0]
00007f46e3fdbf08  por xmm1, xmm15
00007f46e3fdbf0d  movaps [r15+0x300], xmm1
00007f46e3fdbf15  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdbf1e  vmovaps xmm9, [rsp+0xE0]
00007f46e3fdbf27  por xmm15, xmm9
00007f46e3fdbf2c  movaps [r15+0x190], xmm15
00007f46e3fdbf34  vmovaps xmm9, [rsp+0x50]
00007f46e3fdbf3a  vpermilpd xmm9, xmm9, 0x00
00007f46e3fdbf40  vmovaps [rsp+0x90], xmm1
00007f46e3fdbf49  vmovaps [rsp+0xE0], xmm15
00007f46e3fdbf52  vmovaps xmm15, [rsp+0x80]
00007f46e3fdbf5b  vmovaps [rsp+0x80], xmm14
00007f46e3fdbf64  movaps xmm1, xmm15
00007f46e3fdbf68  mulpd xmm1, xmm9
00007f46e3fdbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007f46e3fdbf72  ptest xmm14, xmm14
00007f46e3fdbf78  jnz 0x00007F46E3FDDC72
00007f46e3fdbf7e  lea r12, [rax+0x90]
00007f46e3fdbf85  movups xmm15, [r13+r12*1]
00007f46e3fdbf8b  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdbf94  vmovaps xmm9, [rsp+0xD0]
00007f46e3fdbf9d  por xmm14, xmm9
00007f46e3fdbfa2  movaps [r15+0x1C0], xmm14
00007f46e3fdbfaa  vmovaps xmm9, [rsp+0xC0]
00007f46e3fdbfb3  vmovaps [rsp+0xD0], xmm1
00007f46e3fdbfbc  vmovaps xmm1, [rsp+0xC0]
00007f46e3fdbfc5  por xmm9, xmm1
00007f46e3fdbfca  movaps [r15+0x200], xmm9
00007f46e3fdbfd2  vmovaps [rsp+0xC0], xmm2
00007f46e3fdbfdb  vmovaps xmm1, [rsp+0xC0]
00007f46e3fdbfe4  por xmm2, xmm1
00007f46e3fdbfe8  movaps [r15+0x2D0], xmm2
00007f46e3fdbff0  vmovaps [rsp+0xC0], xmm8
00007f46e3fdbff9  vmovaps xmm1, [rsp+0xC0]
00007f46e3fdc002  por xmm8, xmm1
00007f46e3fdc007  movaps [r15+0x2E0], xmm8
00007f46e3fdc00f  vmovaps [rsp+0xC0], xmm15
00007f46e3fdc018  movaps xmm1, xmm5
00007f46e3fdc01b  addpd xmm1, xmm7
00007f46e3fdc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007f46e3fdc024  ptest xmm15, xmm15
00007f46e3fdc02a  jnz 0x00007F46E3FDDDBE
00007f46e3fdc030  vmovaps xmm15, [rsp+0x50]
00007f46e3fdc036  vpermilpd xmm15, xmm15, 0x00
00007f46e3fdc03c  vmovaps xmm5, [rsp+0xC0]
00007f46e3fdc045  vmovaps [rsp+0xC0], xmm1
00007f46e3fdc04e  movaps xmm7, xmm5
00007f46e3fdc051  mulpd xmm7, xmm15
00007f46e3fdc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007f46e3fdc05b  ptest xmm1, xmm1
00007f46e3fdc060  jnz 0x00007F46E3FDDEFE
00007f46e3fdc066  lea r12, [rax+0x80]
00007f46e3fdc06d  movups xmm1, [r13+r12*1]
00007f46e3fdc073  vmovaps xmm5, [rsp+0x70]
00007f46e3fdc079  vmovaps [rsp+0x70], xmm1
00007f46e3fdc07f  movaps xmm15, xmm5
00007f46e3fdc083  addpd xmm15, xmm3
00007f46e3fdc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007f46e3fdc08e  ptest xmm1, xmm1
00007f46e3fdc093  jnz 0x00007F46E3FDE049
00007f46e3fdc099  vmovaps xmm5, [rsp+0x80]
00007f46e3fdc0a2  movaps xmm1, xmm5
00007f46e3fdc0a5  addpd xmm1, xmm4
00007f46e3fdc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007f46e3fdc0ae  ptest xmm3, xmm3
00007f46e3fdc0b3  jnz 0x00007F46E3FDE18B
00007f46e3fdc0b9  vmovaps [rsp+0x80], xmm10
00007f46e3fdc0c2  vmovaps xmm5, [rsp+0x80]
00007f46e3fdc0cb  por xmm10, xmm5
00007f46e3fdc0d0  movaps [r15+0x2F0], xmm10
00007f46e3fdc0d8  vmovaps xmm5, [rsp+0x50]
00007f46e3fdc0de  vpermilpd xmm5, xmm5, 0x00
00007f46e3fdc0e4  vmovaps xmm3, [rsp+0x70]
00007f46e3fdc0ea  vmovaps [rsp+0x50], xmm1
00007f46e3fdc0f0  movaps xmm4, xmm3
00007f46e3fdc0f3  mulpd xmm4, xmm5
00007f46e3fdc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007f46e3fdc0fc  ptest xmm1, xmm1
00007f46e3fdc101  jnz 0x00007F46E3FDE2CB
00007f46e3fdc107  lea r12, [rax+0xD0]
00007f46e3fdc10e  movups xmm1, [r13+r12*1]
00007f46e3fdc114  vmovaps xmm3, [rsp+0xD0]
00007f46e3fdc11d  vmovaps [rsp+0x70], xmm1
00007f46e3fdc123  movaps xmm5, xmm6
00007f46e3fdc126  addpd xmm5, xmm3
00007f46e3fdc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007f46e3fdc12f  ptest xmm1, xmm1
00007f46e3fdc134  jnz 0x00007F46E3FDE415
00007f46e3fdc13a  vmovaps xmm1, [rsp+0x60]
00007f46e3fdc140  vpermilpd xmm1, xmm1, 0x00
00007f46e3fdc146  movaps xmm6, xmm9
00007f46e3fdc14a  mulpd xmm6, xmm1
00007f46e3fdc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007f46e3fdc153  ptest xmm3, xmm3
00007f46e3fdc158  jnz 0x00007F46E3FDE555
00007f46e3fdc15e  movaps [r15+0x260], xmm6
00007f46e3fdc166  vxorps xmm1, xmm1, xmm1
00007f46e3fdc16a  vpbroadcastq xmm1, xmm1
00007f46e3fdc16f  movaps [r15+0x1B0], xmm1
00007f46e3fdc177  vmovaps xmm1, [rsp+0x60]
00007f46e3fdc17d  vpermilpd xmm1, xmm1, 0x00
00007f46e3fdc183  vmovaps xmm3, [rsp+0x70]
00007f46e3fdc189  vmovaps [rsp+0x70], xmm15
00007f46e3fdc18f  movaps xmm9, xmm3
00007f46e3fdc193  mulpd xmm9, xmm1
00007f46e3fdc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007f46e3fdc19e  ptest xmm15, xmm15
00007f46e3fdc1a4  jnz 0x00007F46E3FDE696
00007f46e3fdc1aa  lea r12, [rax+0xC0]
00007f46e3fdc1b1  movups xmm1, [r13+r12*1]
00007f46e3fdc1b7  vmovaps xmm3, [rsp+0xC0]
00007f46e3fdc1c0  vmovaps [rsp+0x80], xmm1
00007f46e3fdc1c9  movaps xmm15, xmm3
00007f46e3fdc1cd  addpd xmm15, xmm7
00007f46e3fdc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007f46e3fdc1d8  ptest xmm1, xmm1
00007f46e3fdc1dd  jnz 0x00007F46E3FDE7E2
00007f46e3fdc1e3  vmovaps [rsp+0xC0], xmm13
00007f46e3fdc1ec  vmovaps xmm1, [rsp+0xC0]
00007f46e3fdc1f5  por xmm13, xmm1
00007f46e3fdc1fa  movaps [r15+0x270], xmm13
00007f46e3fdc202  vmovaps xmm1, [rsp+0xB0]
00007f46e3fdc20b  vmovaps xmm7, [rsp+0xB0]
00007f46e3fdc214  por xmm1, xmm7
00007f46e3fdc218  movaps [r15+0x1A0], xmm1
00007f46e3fdc220  vmovaps xmm1, [rsp+0x60]
00007f46e3fdc226  vpermilpd xmm1, xmm1, 0x00
00007f46e3fdc22c  vmovaps [rsp+0xB0], xmm1
00007f46e3fdc235  vmovaps xmm1, [rsp+0x80]
00007f46e3fdc23e  vmovaps [rsp+0x80], xmm15
00007f46e3fdc247  vmovaps xmm15, [rsp+0xB0]
00007f46e3fdc250  vmovaps [rsp+0xB0], xmm14
00007f46e3fdc259  movaps xmm3, xmm1
00007f46e3fdc25c  mulpd xmm3, xmm15
00007f46e3fdc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007f46e3fdc266  ptest xmm14, xmm14
00007f46e3fdc26c  jnz 0x00007F46E3FDE924
00007f46e3fdc272  lea r12, [rax+0x20]
00007f46e3fdc276  movups xmm1, [r13+r12*1]
00007f46e3fdc27c  movaps [r15+0x110], xmm1
00007f46e3fdc284  vmovaps xmm14, [rsp+0x70]
00007f46e3fdc28a  vmovaps [rsp+0x70], xmm1
00007f46e3fdc290  movaps xmm15, xmm14
00007f46e3fdc294  addpd xmm15, xmm4
00007f46e3fdc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007f46e3fdc29f  ptest xmm1, xmm1
00007f46e3fdc2a4  jnz 0x00007F46E3FDEA6F
00007f46e3fdc2aa  vmovaps xmm1, [rsp+0x60]
00007f46e3fdc2b0  vpermilpd xmm1, xmm1, 0x00
00007f46e3fdc2b6  movaps xmm14, xmm2
00007f46e3fdc2ba  mulpd xmm14, xmm1
00007f46e3fdc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007f46e3fdc2c5  ptest xmm4, xmm4
00007f46e3fdc2ca  jnz 0x00007F46E3FDEBB2
00007f46e3fdc2d0  vmovaps xmm4, [rsp+0x50]
00007f46e3fdc2d6  movaps xmm1, xmm4
00007f46e3fdc2d9  addpd xmm1, xmm9
00007f46e3fdc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007f46e3fdc2e3  ptest xmm2, xmm2
00007f46e3fdc2e8  jnz 0x00007F46E3FDECF4
00007f46e3fdc2ee  vmovaps xmm9, [rsp+0x30]
00007f46e3fdc2f4  vpermilpd xmm9, xmm9, 0x00
00007f46e3fdc2fa  vmovaps xmm2, [rsp+0x70]
00007f46e3fdc300  vmovaps [rsp+0x50], xmm1
00007f46e3fdc306  movaps xmm4, xmm2
00007f46e3fdc309  mulpd xmm4, xmm9
00007f46e3fdc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007f46e3fdc313  ptest xmm1, xmm1
00007f46e3fdc318  jnz 0x00007F46E3FDEE35
00007f46e3fdc31e  vmovaps xmm1, [rsp+0x30]
00007f46e3fdc324  vpermilpd xmm1, xmm1, 0x00
00007f46e3fdc32a  vmovaps xmm2, [rsp+0x90]
00007f46e3fdc333  vmovaps [rsp+0x60], xmm15
00007f46e3fdc339  movaps xmm9, xmm2
00007f46e3fdc33d  mulpd xmm9, xmm1
00007f46e3fdc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007f46e3fdc348  ptest xmm15, xmm15
00007f46e3fdc34e  jnz 0x00007F46E3FDEF76
00007f46e3fdc354  vmovaps xmm15, [rsp+0x80]
00007f46e3fdc35d  movaps xmm1, xmm15
00007f46e3fdc361  addpd xmm1, xmm6
00007f46e3fdc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007f46e3fdc36a  ptest xmm2, xmm2
00007f46e3fdc36f  jnz 0x00007F46E3FDF0B8
00007f46e3fdc375  movaps xmm15, xmm5
00007f46e3fdc379  addpd xmm15, xmm3
00007f46e3fdc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007f46e3fdc384  ptest xmm6, xmm6
00007f46e3fdc389  jnz 0x00007F46E3FDF1F9
00007f46e3fdc38f  vmovaps xmm6, [rsp+0x30]
00007f46e3fdc395  vpermilpd xmm6, xmm6, 0x00
00007f46e3fdc39b  movaps xmm5, xmm8
00007f46e3fdc39f  mulpd xmm5, xmm6
00007f46e3fdc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007f46e3fdc3a8  ptest xmm3, xmm3
00007f46e3fdc3ad  jnz 0x00007F46E3FDF33B
00007f46e3fdc3b3  vmovaps xmm8, [rsp+0x30]
00007f46e3fdc3b9  vpermilpd xmm8, xmm8, 0x00
00007f46e3fdc3bf  movaps xmm6, xmm10
00007f46e3fdc3c3  mulpd xmm6, xmm8
00007f46e3fdc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007f46e3fdc3cd  ptest xmm3, xmm3
00007f46e3fdc3d2  jnz 0x00007F46E3FDF47C
00007f46e3fdc3d8  vmovaps xmm8, [rsp+0x60]
00007f46e3fdc3de  movaps xmm10, xmm8
00007f46e3fdc3e2  addpd xmm10, xmm14
00007f46e3fdc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007f46e3fdc3ed  ptest xmm3, xmm3
00007f46e3fdc3f2  jnz 0x00007F46E3FDF5BE
00007f46e3fdc3f8  vmovaps xmm8, [rsp+0x50]
00007f46e3fdc3fe  movaps xmm14, xmm8
00007f46e3fdc402  addpd xmm14, xmm4
00007f46e3fdc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007f46e3fdc40d  ptest xmm3, xmm3
00007f46e3fdc412  jnz 0x00007F46E3FDF702
00007f46e3fdc418  vmovaps xmm8, [rsp+0x40]
00007f46e3fdc41e  vpermilpd xmm8, xmm8, 0x00
00007f46e3fdc424  movaps xmm4, xmm13
00007f46e3fdc428  mulpd xmm4, xmm8
00007f46e3fdc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007f46e3fdc432  ptest xmm3, xmm3
00007f46e3fdc437  jnz 0x00007F46E3FDF845
00007f46e3fdc43d  movaps xmm13, xmm15
00007f46e3fdc441  addpd xmm13, xmm9
00007f46e3fdc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007f46e3fdc44c  ptest xmm8, xmm8
00007f46e3fdc452  jnz 0x00007F46E3FDF987
00007f46e3fdc458  movaps xmm15, xmm1
00007f46e3fdc45c  addpd xmm15, xmm5
00007f46e3fdc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007f46e3fdc467  ptest xmm9, xmm9
00007f46e3fdc46d  jnz 0x00007F46E3FDFACB
00007f46e3fdc473  vmovaps [rsp+0x30], xmm11
00007f46e3fdc479  vmovaps xmm1, [rsp+0x30]
00007f46e3fdc47f  por xmm11, xmm1
00007f46e3fdc484  movaps [r15+0x250], xmm11
00007f46e3fdc48c  vmovaps [rsp+0x30], xmm12
00007f46e3fdc492  vmovaps xmm1, [rsp+0x30]
00007f46e3fdc498  por xmm12, xmm1
00007f46e3fdc49d  movaps [r15+0x2A0], xmm12
00007f46e3fdc4a5  vmovaps xmm1, [rsp+0xA0]
00007f46e3fdc4ae  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdc4b7  por xmm1, xmm11
00007f46e3fdc4bc  movaps [r15+0x1D0], xmm1
00007f46e3fdc4c4  lea r12, [rax+0x40]
00007f46e3fdc4c8  movups xmm1, [r13+r12*1]
00007f46e3fdc4ce  movaps [r15+0x2C0], xmm1
00007f46e3fdc4d6  vmovaps xmm11, [rsp+0x40]
00007f46e3fdc4dc  vpermilpd xmm11, xmm11, 0x00
00007f46e3fdc4e2  vmovaps xmm8, [rsp+0xE0]
00007f46e3fdc4eb  movaps xmm9, xmm8
00007f46e3fdc4ef  mulpd xmm9, xmm11
00007f46e3fdc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007f46e3fdc4fa  ptest xmm5, xmm5
00007f46e3fdc4ff  jnz 0x00007F46E3FDFC17
00007f46e3fdc505  movaps xmm11, xmm10
00007f46e3fdc509  addpd xmm11, xmm6
00007f46e3fdc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007f46e3fdc514  ptest xmm8, xmm8
00007f46e3fdc51a  jnz 0x00007F46E3FDFD5B
00007f46e3fdc520  movaps xmm10, xmm14
00007f46e3fdc524  addpd xmm10, xmm4
00007f46e3fdc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007f46e3fdc52f  ptest xmm8, xmm8
00007f46e3fdc535  jnz 0x00007F46E3FDFE9E
00007f46e3fdc53b  vmovaps xmm14, [rsp+0x40]
00007f46e3fdc541  vpermilpd xmm14, xmm14, 0x00
00007f46e3fdc547  movaps xmm8, xmm1
00007f46e3fdc54b  mulpd xmm8, xmm14
00007f46e3fdc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007f46e3fdc556  ptest xmm6, xmm6
00007f46e3fdc55b  jnz 0x00007F46E3FDFFE1
00007f46e3fdc561  movaps xmm1, [r15+0x2B0]
00007f46e3fdc569  vmovaps xmm14, [rsp+0x40]
00007f46e3fdc56f  vpermilpd xmm14, xmm14, 0x00
00007f46e3fdc575  movaps xmm6, xmm1
00007f46e3fdc578  mulpd xmm6, xmm14
00007f46e3fdc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007f46e3fdc582  ptest xmm5, xmm5
00007f46e3fdc587  jnz 0x00007F46E3FE0124
00007f46e3fdc58d  vmovaps xmm1, [rsp+0x10]
00007f46e3fdc593  vpermilpd xmm1, xmm1, 0x00
00007f46e3fdc599  movaps xmm14, xmm12
00007f46e3fdc59d  mulpd xmm14, xmm1
00007f46e3fdc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007f46e3fdc5a8  ptest xmm5, xmm5
00007f46e3fdc5ad  jnz 0x00007F46E3FE0265
00007f46e3fdc5b3  movaps xmm1, xmm13
00007f46e3fdc5b7  addpd xmm1, xmm9
00007f46e3fdc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007f46e3fdc5c1  ptest xmm12, xmm12
00007f46e3fdc5c7  jnz 0x00007F46E3FE03A8
00007f46e3fdc5cd  vmovaps xmm13, [rsp+0x10]
00007f46e3fdc5d3  vpermilpd xmm13, xmm13, 0x00
00007f46e3fdc5d9  movaps xmm12, xmm7
00007f46e3fdc5dd  mulpd xmm12, xmm13
00007f46e3fdc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007f46e3fdc5e8  ptest xmm9, xmm9
00007f46e3fdc5ee  jnz 0x00007F46E3FE04EA
00007f46e3fdc5f4  movaps xmm13, xmm15
00007f46e3fdc5f8  addpd xmm13, xmm8
00007f46e3fdc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007f46e3fdc603  ptest xmm9, xmm9
00007f46e3fdc609  jnz 0x00007F46E3FE062D
00007f46e3fdc60f  movaps xmm15, [r15+0x290]
00007f46e3fdc617  vmovaps xmm9, [rsp+0x10]
00007f46e3fdc61d  vpermilpd xmm9, xmm9, 0x00
00007f46e3fdc623  movaps xmm8, xmm15
00007f46e3fdc627  mulpd xmm8, xmm9
00007f46e3fdc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007f46e3fdc632  ptest xmm7, xmm7
00007f46e3fdc637  jnz 0x00007F46E3FE0771
00007f46e3fdc63d  movaps xmm15, xmm11
00007f46e3fdc641  addpd xmm15, xmm6
00007f46e3fdc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007f46e3fdc64c  ptest xmm9, xmm9
00007f46e3fdc652  jnz 0x00007F46E3FE08B5
00007f46e3fdc658  movaps xmm11, [r15+0x1E0]
00007f46e3fdc660  vmovaps xmm9, [rsp+0x10]
00007f46e3fdc666  vpermilpd xmm9, xmm9, 0x00
00007f46e3fdc66c  movaps xmm7, xmm11
00007f46e3fdc670  mulpd xmm7, xmm9
00007f46e3fdc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007f46e3fdc67a  ptest xmm6, xmm6
00007f46e3fdc67f  jnz 0x00007F46E3FE09F8
00007f46e3fdc685  movaps xmm11, xmm10
00007f46e3fdc689  addpd xmm11, xmm14
00007f46e3fdc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007f46e3fdc694  ptest xmm9, xmm9
00007f46e3fdc69a  jnz 0x00007F46E3FE0B3A
00007f46e3fdc6a0  lea r12, [rax+0x70]
00007f46e3fdc6a4  movups xmm14, [r13+r12*1]
00007f46e3fdc6aa  movaps [r15+0x240], xmm14
00007f46e3fdc6b2  movaps xmm10, xmm1
00007f46e3fdc6b6  addpd xmm10, xmm12
00007f46e3fdc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007f46e3fdc6c1  ptest xmm9, xmm9
00007f46e3fdc6c7  jnz 0x00007F46E3FE0C88
00007f46e3fdc6cd  movaps [r15+0x170], xmm10
00007f46e3fdc6d5  vmovaps xmm1, [rsp+0x20]
00007f46e3fdc6db  vpermilpd xmm1, xmm1, 0x00
00007f46e3fdc6e1  movaps xmm12, xmm14
00007f46e3fdc6e5  mulpd xmm12, xmm1
00007f46e3fdc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007f46e3fdc6f0  ptest xmm9, xmm9
00007f46e3fdc6f6  jnz 0x00007F46E3FE0DCB
00007f46e3fdc6fc  vmovaps xmm1, [rsp+0x20]
00007f46e3fdc702  vpermilpd xmm1, xmm1, 0x00
00007f46e3fdc708  vmovaps xmm9, [rsp+0xB0]
00007f46e3fdc711  movaps xmm14, xmm9
00007f46e3fdc715  mulpd xmm14, xmm1
00007f46e3fdc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007f46e3fdc720  ptest xmm6, xmm6
00007f46e3fdc725  jnz 0x00007F46E3FE0F0E
00007f46e3fdc72b  movaps [r15+0x180], xmm14
00007f46e3fdc733  movaps xmm1, xmm13
00007f46e3fdc737  addpd xmm1, xmm8
00007f46e3fdc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007f46e3fdc741  ptest xmm9, xmm9
00007f46e3fdc747  jnz 0x00007F46E3FE1051
00007f46e3fdc74d  movaps [r15+0x210], xmm1
00007f46e3fdc755  movups xmm13, [r13+rax*1]
00007f46e3fdc75b  lea r12, [rax+0x10]
00007f46e3fdc75f  movups xmm9, [r13+r12*1]
00007f46e3fdc765  movaps [r15+0x230], xmm9
00007f46e3fdc76d  movaps xmm8, xmm15
00007f46e3fdc771  addpd xmm8, xmm7
00007f46e3fdc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007f46e3fdc77c  ptest xmm6, xmm6
00007f46e3fdc781  jnz 0x00007F46E3FE11A7
00007f46e3fdc787  movaps [r15+0x130], xmm8
00007f46e3fdc78f  vmovaps xmm15, [rsp+0x20]
00007f46e3fdc795  vpermilpd xmm15, xmm15, 0x00
00007f46e3fdc79b  movaps xmm7, xmm9
00007f46e3fdc79f  mulpd xmm7, xmm15
00007f46e3fdc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007f46e3fdc7a9  ptest xmm6, xmm6
00007f46e3fdc7ae  jnz 0x00007F46E3FE12EA
00007f46e3fdc7b4  movaps [r15+0x220], xmm7
00007f46e3fdc7bc  vmovaps xmm15, [rsp+0x20]
00007f46e3fdc7c2  vpermilpd xmm15, xmm15, 0x00
00007f46e3fdc7c8  movaps xmm9, xmm13
00007f46e3fdc7cc  mulpd xmm9, xmm15
00007f46e3fdc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007f46e3fdc7d7  ptest xmm6, xmm6
00007f46e3fdc7dc  jnz 0x00007F46E3FE142C
00007f46e3fdc7e2  movaps xmm15, xmm11
00007f46e3fdc7e6  addpd xmm15, xmm12
00007f46e3fdc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007f46e3fdc7f1  ptest xmm13, xmm13
00007f46e3fdc7f7  jnz 0x00007F46E3FE1570
00007f46e3fdc7fd  movaps [r15+0x140], xmm15
00007f46e3fdc805  movaps xmm13, xmm10
00007f46e3fdc809  addpd xmm13, xmm14
00007f46e3fdc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007f46e3fdc814  ptest xmm12, xmm12
00007f46e3fdc81a  jnz 0x00007F46E3FE16B4
00007f46e3fdc820  movaps [r15+0x150], xmm13
00007f46e3fdc828  movaps xmm14, xmm1
00007f46e3fdc82c  addpd xmm14, xmm7
00007f46e3fdc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007f46e3fdc837  ptest xmm12, xmm12
00007f46e3fdc83d  jnz 0x00007F46E3FE17F8
00007f46e3fdc843  movaps [r15+0x160], xmm14
00007f46e3fdc84b  movaps xmm1, xmm8
00007f46e3fdc84f  addpd xmm1, xmm9
00007f46e3fdc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007f46e3fdc859  ptest xmm12, xmm12
00007f46e3fdc85f  jnz 0x00007F46E3FE193A
00007f46e3fdc865  movaps [r15+0x120], xmm1
00007f46e3fdc86d  movups [r13+r14*1], xmm15
00007f46e3fdc873  lea rax, [r14+0x10]
00007f46e3fdc877  movups [r13+rax*1], xmm13
00007f46e3fdc87d  lea rax, [r14+0x20]
00007f46e3fdc881  movups [r13+rax*1], xmm14
00007f46e3fdc887  lea rax, [r14+0x30]
00007f46e3fdc88b  movups [r13+rax*1], xmm1
00007f46e3fdc891  mov eax, [r15+0x108]
00007f46e3fdc898  sahf
00007f46e3fdc899  jnz 0x00007F46E3FDC8CB
00007f46e3fdc89b  cmp dword ptr [r15+0x318], 0x00
00007f46e3fdc8a3  jz 0x00007F46E3FDB900
00007f46e3fdc8a9  nop [rax+rax*1], ax
00007f46e3fdc8b2  nop [rax+rax*1], eax
00007f46e3fdc8ba  mov eax, 0x410444
00007f46e3fdc8bf  mov [r15+0x100], rax
00007f46e3fdc8c6  jmp 0x00007F46E3DFE110
00007f46e3fdc8cb  cmp dword ptr [r15+0x318], 0x00
00007f46e3fdc8d3  jz 0x00007F46E3FD57E0
00007f46e3fdc8d9  nop [rax+rax*1], ax
00007f46e3fdc8e2  nop [rax+rax*1], eax
00007f46e3fdc8ea  mov eax, 0x410278
00007f46e3fdc8ef  mov [r15+0x100], rax
00007f46e3fdc8f6  jmp 0x00007F46E3DFE110
00007f46e3fdc8fb  int3
00007f46e3fdc8fc  call 0x00007F46E3EE27E0
00007f46e3fdc901  jmp 0x00007F46E3FDB9DF
00007f46e3fdc906  call 0x00007F46E3EE1570
00007f46e3fdc90b  jmp 0x00007F46E3FDB9E8
00007f46e3fdc910  call 0x00007F46E3EE27E0
00007f46e3fdc915  jmp 0x00007F46E3FDBA44
00007f46e3fdc91a  call 0x00007F46E3EE1570
00007f46e3fdc91f  jmp 0x00007F46E3FDBA4D
00007f46e3fdc924  call 0x00007F46E3EE27E0
00007f46e3fdc929  jmp 0x00007F46E3FDBA90
00007f46e3fdc92e  call 0x00007F46E3EE1570
00007f46e3fdc933  jmp 0x00007F46E3FDBA99
00007f46e3fdc938  call 0x00007F46E3E0DC20
00007f46e3fdc93d  jmp 0x00007F46E3FDBAD8
00007f46e3fdc942  call 0x00007F46E3ED59C0
00007f46e3fdc947  jmp 0x00007F46E3FDBAEB
00007f46e3fdc94c  call 0x00007F46E3EE0E30
00007f46e3fdc951  jmp 0x00007F46E3FDBB09
00007f46e3fdc956  call 0x00007F46E3EDFBC0
00007f46e3fdc95b  jmp 0x00007F46E3FDBB13
00007f46e3fdc960  call 0x00007F46E3EDE950
00007f46e3fdc965  jmp 0x00007F46E3FDBB1D
00007f46e3fdc96a  sub rsp, 0x08
00007f46e3fdc96e  push rax
00007f46e3fdc96f  push rcx
00007f46e3fdc970  push rdx
00007f46e3fdc971  push rdi
00007f46e3fdc972  push rsi
00007f46e3fdc973  push r8
00007f46e3fdc975  push r9
00007f46e3fdc977  push r10
00007f46e3fdc979  push r11
00007f46e3fdc97b  sub rsp, 0xF0
00007f46e3fdc982  vmovaps [rsp], xmm0
00007f46e3fdc987  vmovaps [rsp+0x10], xmm1
00007f46e3fdc98d  vmovaps [rsp+0x20], xmm2
00007f46e3fdc993  vmovaps [rsp+0x30], xmm3
00007f46e3fdc999  vmovaps [rsp+0x40], xmm4
00007f46e3fdc99f  vmovaps [rsp+0x50], xmm5
00007f46e3fdc9a5  vmovaps [rsp+0x60], xmm6
00007f46e3fdc9ab  vmovaps [rsp+0x70], xmm7
00007f46e3fdc9b1  vmovaps [rsp+0x80], xmm9
00007f46e3fdc9ba  vmovaps [rsp+0x90], xmm10
00007f46e3fdc9c3  vmovaps [rsp+0xA0], xmm11
00007f46e3fdc9cc  vmovaps [rsp+0xB0], xmm12
00007f46e3fdc9d5  vmovaps [rsp+0xC0], xmm13
00007f46e3fdc9de  vmovaps [rsp+0xD0], xmm14
00007f46e3fdc9e7  vmovaps [rsp+0xE0], xmm15
00007f46e3fdc9f0  sub rsp, 0x30
00007f46e3fdc9f4  movaps [rsp], xmm8
00007f46e3fdc9f9  movaps [rsp+0x10], xmm12
00007f46e3fdc9ff  movaps [rsp+0x20], xmm15
00007f46e3fdca05  lea rdi, [rsp]
00007f46e3fdca09  mov esi, 0x00
00007f46e3fdca0e  mov rax, 0x6238B185B530
00007f46e3fdca18  call rax
00007f46e3fdca1a  movaps xmm8, [rsp]
00007f46e3fdca1f  add rsp, 0x30
00007f46e3fdca23  vmovaps xmm0, [rsp]
00007f46e3fdca28  vmovaps xmm1, [rsp+0x10]
00007f46e3fdca2e  vmovaps xmm2, [rsp+0x20]
00007f46e3fdca34  vmovaps xmm3, [rsp+0x30]
00007f46e3fdca3a  vmovaps xmm4, [rsp+0x40]
00007f46e3fdca40  vmovaps xmm5, [rsp+0x50]
00007f46e3fdca46  vmovaps xmm6, [rsp+0x60]
00007f46e3fdca4c  vmovaps xmm7, [rsp+0x70]
00007f46e3fdca52  vmovaps xmm9, [rsp+0x80]
00007f46e3fdca5b  vmovaps xmm10, [rsp+0x90]
00007f46e3fdca64  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdca6d  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdca76  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdca7f  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdca88  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdca91  add rsp, 0xF0
00007f46e3fdca98  pop r11
00007f46e3fdca9a  pop r10
00007f46e3fdca9c  pop r9
00007f46e3fdca9e  pop r8
00007f46e3fdcaa0  pop rsi
00007f46e3fdcaa1  pop rdi
00007f46e3fdcaa2  pop rdx
00007f46e3fdcaa3  pop rcx
00007f46e3fdcaa4  pop rax
00007f46e3fdcaa5  add rsp, 0x08
00007f46e3fdcaa9  jmp 0x00007F46E3FDBB47
00007f46e3fdcaae  sub rsp, 0x08
00007f46e3fdcab2  push rax
00007f46e3fdcab3  push rcx
00007f46e3fdcab4  push rdx
00007f46e3fdcab5  push rdi
00007f46e3fdcab6  push rsi
00007f46e3fdcab7  push r8
00007f46e3fdcab9  push r9
00007f46e3fdcabb  push r10
00007f46e3fdcabd  push r11
00007f46e3fdcabf  sub rsp, 0xF0
00007f46e3fdcac6  vmovaps [rsp], xmm0
00007f46e3fdcacb  vmovaps [rsp+0x10], xmm1
00007f46e3fdcad1  vmovaps [rsp+0x20], xmm2
00007f46e3fdcad7  vmovaps [rsp+0x30], xmm3
00007f46e3fdcadd  vmovaps [rsp+0x40], xmm4
00007f46e3fdcae3  vmovaps [rsp+0x50], xmm5
00007f46e3fdcae9  vmovaps [rsp+0x60], xmm6
00007f46e3fdcaef  vmovaps [rsp+0x70], xmm8
00007f46e3fdcaf5  vmovaps [rsp+0x80], xmm9
00007f46e3fdcafe  vmovaps [rsp+0x90], xmm10
00007f46e3fdcb07  vmovaps [rsp+0xA0], xmm11
00007f46e3fdcb10  vmovaps [rsp+0xB0], xmm12
00007f46e3fdcb19  vmovaps [rsp+0xC0], xmm13
00007f46e3fdcb22  vmovaps [rsp+0xD0], xmm14
00007f46e3fdcb2b  vmovaps [rsp+0xE0], xmm15
00007f46e3fdcb34  sub rsp, 0x30
00007f46e3fdcb38  movaps [rsp], xmm7
00007f46e3fdcb3c  movaps [rsp+0x10], xmm9
00007f46e3fdcb42  movaps [rsp+0x20], xmm15
00007f46e3fdcb48  lea rdi, [rsp]
00007f46e3fdcb4c  mov esi, 0x00
00007f46e3fdcb51  mov rax, 0x6238B185B530
00007f46e3fdcb5b  call rax
00007f46e3fdcb5d  movaps xmm7, [rsp]
00007f46e3fdcb61  add rsp, 0x30
00007f46e3fdcb65  vmovaps xmm0, [rsp]
00007f46e3fdcb6a  vmovaps xmm1, [rsp+0x10]
00007f46e3fdcb70  vmovaps xmm2, [rsp+0x20]
00007f46e3fdcb76  vmovaps xmm3, [rsp+0x30]
00007f46e3fdcb7c  vmovaps xmm4, [rsp+0x40]
00007f46e3fdcb82  vmovaps xmm5, [rsp+0x50]
00007f46e3fdcb88  vmovaps xmm6, [rsp+0x60]
00007f46e3fdcb8e  vmovaps xmm8, [rsp+0x70]
00007f46e3fdcb94  vmovaps xmm9, [rsp+0x80]
00007f46e3fdcb9d  vmovaps xmm10, [rsp+0x90]
00007f46e3fdcba6  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdcbaf  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdcbb8  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdcbc1  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdcbca  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdcbd3  add rsp, 0xF0
00007f46e3fdcbda  pop r11
00007f46e3fdcbdc  pop r10
00007f46e3fdcbde  pop r9
00007f46e3fdcbe0  pop r8
00007f46e3fdcbe2  pop rsi
00007f46e3fdcbe3  pop rdi
00007f46e3fdcbe4  pop rdx
00007f46e3fdcbe5  pop rcx
00007f46e3fdcbe6  pop rax
00007f46e3fdcbe7  add rsp, 0x08
00007f46e3fdcbeb  jmp 0x00007F46E3FDBB75
00007f46e3fdcbf0  sub rsp, 0x08
00007f46e3fdcbf4  push rax
00007f46e3fdcbf5  push rcx
00007f46e3fdcbf6  push rdx
00007f46e3fdcbf7  push rdi
00007f46e3fdcbf8  push rsi
00007f46e3fdcbf9  push r8
00007f46e3fdcbfb  push r9
00007f46e3fdcbfd  push r10
00007f46e3fdcbff  push r11
00007f46e3fdcc01  sub rsp, 0xF0
00007f46e3fdcc08  vmovaps [rsp], xmm0
00007f46e3fdcc0d  vmovaps [rsp+0x10], xmm1
00007f46e3fdcc13  vmovaps [rsp+0x20], xmm2
00007f46e3fdcc19  vmovaps [rsp+0x30], xmm3
00007f46e3fdcc1f  vmovaps [rsp+0x40], xmm4
00007f46e3fdcc25  vmovaps [rsp+0x50], xmm5
00007f46e3fdcc2b  vmovaps [rsp+0x60], xmm6
00007f46e3fdcc31  vmovaps [rsp+0x70], xmm7
00007f46e3fdcc37  vmovaps [rsp+0x80], xmm8
00007f46e3fdcc40  vmovaps [rsp+0x90], xmm10
00007f46e3fdcc49  vmovaps [rsp+0xA0], xmm11
00007f46e3fdcc52  vmovaps [rsp+0xB0], xmm12
00007f46e3fdcc5b  vmovaps [rsp+0xC0], xmm13
00007f46e3fdcc64  vmovaps [rsp+0xD0], xmm14
00007f46e3fdcc6d  vmovaps [rsp+0xE0], xmm15
00007f46e3fdcc76  sub rsp, 0x30
00007f46e3fdcc7a  movaps [rsp], xmm9
00007f46e3fdcc7f  movaps [rsp+0x10], xmm12
00007f46e3fdcc85  movaps [rsp+0x20], xmm10
00007f46e3fdcc8b  lea rdi, [rsp]
00007f46e3fdcc8f  mov esi, 0x00
00007f46e3fdcc94  mov rax, 0x6238B185B530
00007f46e3fdcc9e  call rax
00007f46e3fdcca0  movaps xmm9, [rsp]
00007f46e3fdcca5  add rsp, 0x30
00007f46e3fdcca9  vmovaps xmm0, [rsp]
00007f46e3fdccae  vmovaps xmm1, [rsp+0x10]
00007f46e3fdccb4  vmovaps xmm2, [rsp+0x20]
00007f46e3fdccba  vmovaps xmm3, [rsp+0x30]
00007f46e3fdccc0  vmovaps xmm4, [rsp+0x40]
00007f46e3fdccc6  vmovaps xmm5, [rsp+0x50]
00007f46e3fdcccc  vmovaps xmm6, [rsp+0x60]
00007f46e3fdccd2  vmovaps xmm7, [rsp+0x70]
00007f46e3fdccd8  vmovaps xmm8, [rsp+0x80]
00007f46e3fdcce1  vmovaps xmm10, [rsp+0x90]
00007f46e3fdccea  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdccf3  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdccfc  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdcd05  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdcd0e  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdcd17  add rsp, 0xF0
00007f46e3fdcd1e  pop r11
00007f46e3fdcd20  pop r10
00007f46e3fdcd22  pop r9
00007f46e3fdcd24  pop r8
00007f46e3fdcd26  pop rsi
00007f46e3fdcd27  pop rdi
00007f46e3fdcd28  pop rdx
00007f46e3fdcd29  pop rcx
00007f46e3fdcd2a  pop rax
00007f46e3fdcd2b  add rsp, 0x08
00007f46e3fdcd2f  jmp 0x00007F46E3FDBB99
00007f46e3fdcd34  sub rsp, 0x08
00007f46e3fdcd38  push rax
00007f46e3fdcd39  push rcx
00007f46e3fdcd3a  push rdx
00007f46e3fdcd3b  push rdi
00007f46e3fdcd3c  push rsi
00007f46e3fdcd3d  push r8
00007f46e3fdcd3f  push r9
00007f46e3fdcd41  push r10
00007f46e3fdcd43  push r11
00007f46e3fdcd45  sub rsp, 0xF0
00007f46e3fdcd4c  vmovaps [rsp], xmm0
00007f46e3fdcd51  vmovaps [rsp+0x10], xmm1
00007f46e3fdcd57  vmovaps [rsp+0x20], xmm2
00007f46e3fdcd5d  vmovaps [rsp+0x30], xmm3
00007f46e3fdcd63  vmovaps [rsp+0x40], xmm4
00007f46e3fdcd69  vmovaps [rsp+0x50], xmm5
00007f46e3fdcd6f  vmovaps [rsp+0x60], xmm6
00007f46e3fdcd75  vmovaps [rsp+0x70], xmm7
00007f46e3fdcd7b  vmovaps [rsp+0x80], xmm8
00007f46e3fdcd84  vmovaps [rsp+0x90], xmm9
00007f46e3fdcd8d  vmovaps [rsp+0xA0], xmm11
00007f46e3fdcd96  vmovaps [rsp+0xB0], xmm12
00007f46e3fdcd9f  vmovaps [rsp+0xC0], xmm13
00007f46e3fdcda8  vmovaps [rsp+0xD0], xmm14
00007f46e3fdcdb1  vmovaps [rsp+0xE0], xmm15
00007f46e3fdcdba  sub rsp, 0x30
00007f46e3fdcdbe  movaps [rsp], xmm10
00007f46e3fdcdc3  movaps [rsp+0x10], xmm12
00007f46e3fdcdc9  movaps [rsp+0x20], xmm11
00007f46e3fdcdcf  lea rdi, [rsp]
00007f46e3fdcdd3  mov esi, 0x00
00007f46e3fdcdd8  mov rax, 0x6238B185B530
00007f46e3fdcde2  call rax
00007f46e3fdcde4  movaps xmm10, [rsp]
00007f46e3fdcde9  add rsp, 0x30
00007f46e3fdcded  vmovaps xmm0, [rsp]
00007f46e3fdcdf2  vmovaps xmm1, [rsp+0x10]
00007f46e3fdcdf8  vmovaps xmm2, [rsp+0x20]
00007f46e3fdcdfe  vmovaps xmm3, [rsp+0x30]
00007f46e3fdce04  vmovaps xmm4, [rsp+0x40]
00007f46e3fdce0a  vmovaps xmm5, [rsp+0x50]
00007f46e3fdce10  vmovaps xmm6, [rsp+0x60]
00007f46e3fdce16  vmovaps xmm7, [rsp+0x70]
00007f46e3fdce1c  vmovaps xmm8, [rsp+0x80]
00007f46e3fdce25  vmovaps xmm9, [rsp+0x90]
00007f46e3fdce2e  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdce37  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdce40  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdce49  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdce52  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdce5b  add rsp, 0xF0
00007f46e3fdce62  pop r11
00007f46e3fdce64  pop r10
00007f46e3fdce66  pop r9
00007f46e3fdce68  pop r8
00007f46e3fdce6a  pop rsi
00007f46e3fdce6b  pop rdi
00007f46e3fdce6c  pop rdx
00007f46e3fdce6d  pop rcx
00007f46e3fdce6e  pop rax
00007f46e3fdce6f  add rsp, 0x08
00007f46e3fdce73  jmp 0x00007F46E3FDBBB3
00007f46e3fdce78  sub rsp, 0x08
00007f46e3fdce7c  push rax
00007f46e3fdce7d  push rcx
00007f46e3fdce7e  push rdx
00007f46e3fdce7f  push rdi
00007f46e3fdce80  push rsi
00007f46e3fdce81  push r8
00007f46e3fdce83  push r9
00007f46e3fdce85  push r10
00007f46e3fdce87  push r11
00007f46e3fdce89  sub rsp, 0xF0
00007f46e3fdce90  vmovaps [rsp], xmm0
00007f46e3fdce95  vmovaps [rsp+0x10], xmm1
00007f46e3fdce9b  vmovaps [rsp+0x20], xmm2
00007f46e3fdcea1  vmovaps [rsp+0x30], xmm3
00007f46e3fdcea7  vmovaps [rsp+0x40], xmm4
00007f46e3fdcead  vmovaps [rsp+0x50], xmm5
00007f46e3fdceb3  vmovaps [rsp+0x60], xmm7
00007f46e3fdceb9  vmovaps [rsp+0x70], xmm8
00007f46e3fdcebf  vmovaps [rsp+0x80], xmm9
00007f46e3fdcec8  vmovaps [rsp+0x90], xmm10
00007f46e3fdced1  vmovaps [rsp+0xA0], xmm11
00007f46e3fdceda  vmovaps [rsp+0xB0], xmm12
00007f46e3fdcee3  vmovaps [rsp+0xC0], xmm13
00007f46e3fdceec  vmovaps [rsp+0xD0], xmm14
00007f46e3fdcef5  vmovaps [rsp+0xE0], xmm15
00007f46e3fdcefe  sub rsp, 0x30
00007f46e3fdcf02  movaps [rsp], xmm6
00007f46e3fdcf06  movaps [rsp+0x10], xmm12
00007f46e3fdcf0c  movaps [rsp+0x20], xmm11
00007f46e3fdcf12  lea rdi, [rsp]
00007f46e3fdcf16  mov esi, 0x00
00007f46e3fdcf1b  mov rax, 0x6238B185B530
00007f46e3fdcf25  call rax
00007f46e3fdcf27  movaps xmm6, [rsp]
00007f46e3fdcf2b  add rsp, 0x30
00007f46e3fdcf2f  vmovaps xmm0, [rsp]
00007f46e3fdcf34  vmovaps xmm1, [rsp+0x10]
00007f46e3fdcf3a  vmovaps xmm2, [rsp+0x20]
00007f46e3fdcf40  vmovaps xmm3, [rsp+0x30]
00007f46e3fdcf46  vmovaps xmm4, [rsp+0x40]
00007f46e3fdcf4c  vmovaps xmm5, [rsp+0x50]
00007f46e3fdcf52  vmovaps xmm7, [rsp+0x60]
00007f46e3fdcf58  vmovaps xmm8, [rsp+0x70]
00007f46e3fdcf5e  vmovaps xmm9, [rsp+0x80]
00007f46e3fdcf67  vmovaps xmm10, [rsp+0x90]
00007f46e3fdcf70  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdcf79  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdcf82  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdcf8b  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdcf94  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdcf9d  add rsp, 0xF0
00007f46e3fdcfa4  pop r11
00007f46e3fdcfa6  pop r10
00007f46e3fdcfa8  pop r9
00007f46e3fdcfaa  pop r8
00007f46e3fdcfac  pop rsi
00007f46e3fdcfad  pop rdi
00007f46e3fdcfae  pop rdx
00007f46e3fdcfaf  pop rcx
00007f46e3fdcfb0  pop rax
00007f46e3fdcfb1  add rsp, 0x08
00007f46e3fdcfb5  jmp 0x00007F46E3FDBBD4
00007f46e3fdcfba  sub rsp, 0x08
00007f46e3fdcfbe  push rax
00007f46e3fdcfbf  push rcx
00007f46e3fdcfc0  push rdx
00007f46e3fdcfc1  push rdi
00007f46e3fdcfc2  push rsi
00007f46e3fdcfc3  push r8
00007f46e3fdcfc5  push r9
00007f46e3fdcfc7  push r10
00007f46e3fdcfc9  push r11
00007f46e3fdcfcb  sub rsp, 0xF0
00007f46e3fdcfd2  vmovaps [rsp], xmm0
00007f46e3fdcfd7  vmovaps [rsp+0x10], xmm1
00007f46e3fdcfdd  vmovaps [rsp+0x20], xmm2
00007f46e3fdcfe3  vmovaps [rsp+0x30], xmm4
00007f46e3fdcfe9  vmovaps [rsp+0x40], xmm5
00007f46e3fdcfef  vmovaps [rsp+0x50], xmm6
00007f46e3fdcff5  vmovaps [rsp+0x60], xmm7
00007f46e3fdcffb  vmovaps [rsp+0x70], xmm8
00007f46e3fdd001  vmovaps [rsp+0x80], xmm9
00007f46e3fdd00a  vmovaps [rsp+0x90], xmm10
00007f46e3fdd013  vmovaps [rsp+0xA0], xmm11
00007f46e3fdd01c  vmovaps [rsp+0xB0], xmm12
00007f46e3fdd025  vmovaps [rsp+0xC0], xmm13
00007f46e3fdd02e  vmovaps [rsp+0xD0], xmm14
00007f46e3fdd037  vmovaps [rsp+0xE0], xmm15
00007f46e3fdd040  sub rsp, 0x30
00007f46e3fdd044  movaps [rsp], xmm3
00007f46e3fdd048  movaps [rsp+0x10], xmm5
00007f46e3fdd04d  movaps [rsp+0x20], xmm4
00007f46e3fdd052  lea rdi, [rsp]
00007f46e3fdd056  mov esi, 0x00
00007f46e3fdd05b  mov rax, 0x6238B185B530
00007f46e3fdd065  call rax
00007f46e3fdd067  movaps xmm3, [rsp]
00007f46e3fdd06b  add rsp, 0x30
00007f46e3fdd06f  vmovaps xmm0, [rsp]
00007f46e3fdd074  vmovaps xmm1, [rsp+0x10]
00007f46e3fdd07a  vmovaps xmm2, [rsp+0x20]
00007f46e3fdd080  vmovaps xmm4, [rsp+0x30]
00007f46e3fdd086  vmovaps xmm5, [rsp+0x40]
00007f46e3fdd08c  vmovaps xmm6, [rsp+0x50]
00007f46e3fdd092  vmovaps xmm7, [rsp+0x60]
00007f46e3fdd098  vmovaps xmm8, [rsp+0x70]
00007f46e3fdd09e  vmovaps xmm9, [rsp+0x80]
00007f46e3fdd0a7  vmovaps xmm10, [rsp+0x90]
00007f46e3fdd0b0  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdd0b9  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdd0c2  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdd0cb  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdd0d4  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdd0dd  add rsp, 0xF0
00007f46e3fdd0e4  pop r11
00007f46e3fdd0e6  pop r10
00007f46e3fdd0e8  pop r9
00007f46e3fdd0ea  pop r8
00007f46e3fdd0ec  pop rsi
00007f46e3fdd0ed  pop rdi
00007f46e3fdd0ee  pop rdx
00007f46e3fdd0ef  pop rcx
00007f46e3fdd0f0  pop rax
00007f46e3fdd0f1  add rsp, 0x08
00007f46e3fdd0f5  jmp 0x00007F46E3FDBC35
00007f46e3fdd0fa  sub rsp, 0x08
00007f46e3fdd0fe  push rax
00007f46e3fdd0ff  push rcx
00007f46e3fdd100  push rdx
00007f46e3fdd101  push rdi
00007f46e3fdd102  push rsi
00007f46e3fdd103  push r8
00007f46e3fdd105  push r9
00007f46e3fdd107  push r10
00007f46e3fdd109  push r11
00007f46e3fdd10b  sub rsp, 0xF0
00007f46e3fdd112  vmovaps [rsp], xmm0
00007f46e3fdd117  vmovaps [rsp+0x10], xmm1
00007f46e3fdd11d  vmovaps [rsp+0x20], xmm2
00007f46e3fdd123  vmovaps [rsp+0x30], xmm3
00007f46e3fdd129  vmovaps [rsp+0x40], xmm4
00007f46e3fdd12f  vmovaps [rsp+0x50], xmm6
00007f46e3fdd135  vmovaps [rsp+0x60], xmm7
00007f46e3fdd13b  vmovaps [rsp+0x70], xmm8
00007f46e3fdd141  vmovaps [rsp+0x80], xmm9
00007f46e3fdd14a  vmovaps [rsp+0x90], xmm10
00007f46e3fdd153  vmovaps [rsp+0xA0], xmm11
00007f46e3fdd15c  vmovaps [rsp+0xB0], xmm12
00007f46e3fdd165  vmovaps [rsp+0xC0], xmm13
00007f46e3fdd16e  vmovaps [rsp+0xD0], xmm14
00007f46e3fdd177  vmovaps [rsp+0xE0], xmm15
00007f46e3fdd180  sub rsp, 0x30
00007f46e3fdd184  movaps [rsp], xmm5
00007f46e3fdd188  movaps [rsp+0x10], xmm8
00007f46e3fdd18e  movaps [rsp+0x20], xmm15
00007f46e3fdd194  lea rdi, [rsp]
00007f46e3fdd198  mov esi, 0x00
00007f46e3fdd19d  mov rax, 0x6238B185B530
00007f46e3fdd1a7  call rax
00007f46e3fdd1a9  movaps xmm5, [rsp]
00007f46e3fdd1ad  add rsp, 0x30
00007f46e3fdd1b1  vmovaps xmm0, [rsp]
00007f46e3fdd1b6  vmovaps xmm1, [rsp+0x10]
00007f46e3fdd1bc  vmovaps xmm2, [rsp+0x20]
00007f46e3fdd1c2  vmovaps xmm3, [rsp+0x30]
00007f46e3fdd1c8  vmovaps xmm4, [rsp+0x40]
00007f46e3fdd1ce  vmovaps xmm6, [rsp+0x50]
00007f46e3fdd1d4  vmovaps xmm7, [rsp+0x60]
00007f46e3fdd1da  vmovaps xmm8, [rsp+0x70]
00007f46e3fdd1e0  vmovaps xmm9, [rsp+0x80]
00007f46e3fdd1e9  vmovaps xmm10, [rsp+0x90]
00007f46e3fdd1f2  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdd1fb  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdd204  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdd20d  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdd216  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdd21f  add rsp, 0xF0
00007f46e3fdd226  pop r11
00007f46e3fdd228  pop r10
00007f46e3fdd22a  pop r9
00007f46e3fdd22c  pop r8
00007f46e3fdd22e  pop rsi
00007f46e3fdd22f  pop rdi
00007f46e3fdd230  pop rdx
00007f46e3fdd231  pop rcx
00007f46e3fdd232  pop rax
00007f46e3fdd233  add rsp, 0x08
00007f46e3fdd237  jmp 0x00007F46E3FDBC73
00007f46e3fdd23c  sub rsp, 0x08
00007f46e3fdd240  push rax
00007f46e3fdd241  push rcx
00007f46e3fdd242  push rdx
00007f46e3fdd243  push rdi
00007f46e3fdd244  push rsi
00007f46e3fdd245  push r8
00007f46e3fdd247  push r9
00007f46e3fdd249  push r10
00007f46e3fdd24b  push r11
00007f46e3fdd24d  sub rsp, 0xF0
00007f46e3fdd254  vmovaps [rsp], xmm0
00007f46e3fdd259  vmovaps [rsp+0x10], xmm1
00007f46e3fdd25f  vmovaps [rsp+0x20], xmm2
00007f46e3fdd265  vmovaps [rsp+0x30], xmm3
00007f46e3fdd26b  vmovaps [rsp+0x40], xmm5
00007f46e3fdd271  vmovaps [rsp+0x50], xmm6
00007f46e3fdd277  vmovaps [rsp+0x60], xmm7
00007f46e3fdd27d  vmovaps [rsp+0x70], xmm8
00007f46e3fdd283  vmovaps [rsp+0x80], xmm9
00007f46e3fdd28c  vmovaps [rsp+0x90], xmm10
00007f46e3fdd295  vmovaps [rsp+0xA0], xmm11
00007f46e3fdd29e  vmovaps [rsp+0xB0], xmm12
00007f46e3fdd2a7  vmovaps [rsp+0xC0], xmm13
00007f46e3fdd2b0  vmovaps [rsp+0xD0], xmm14
00007f46e3fdd2b9  vmovaps [rsp+0xE0], xmm15
00007f46e3fdd2c2  sub rsp, 0x30
00007f46e3fdd2c6  movaps [rsp], xmm4
00007f46e3fdd2ca  movaps [rsp+0x10], xmm9
00007f46e3fdd2d0  movaps [rsp+0x20], xmm8
00007f46e3fdd2d6  lea rdi, [rsp]
00007f46e3fdd2da  mov esi, 0x00
00007f46e3fdd2df  mov rax, 0x6238B185B530
00007f46e3fdd2e9  call rax
00007f46e3fdd2eb  movaps xmm4, [rsp]
00007f46e3fdd2ef  add rsp, 0x30
00007f46e3fdd2f3  vmovaps xmm0, [rsp]
00007f46e3fdd2f8  vmovaps xmm1, [rsp+0x10]
00007f46e3fdd2fe  vmovaps xmm2, [rsp+0x20]
00007f46e3fdd304  vmovaps xmm3, [rsp+0x30]
00007f46e3fdd30a  vmovaps xmm5, [rsp+0x40]
00007f46e3fdd310  vmovaps xmm6, [rsp+0x50]
00007f46e3fdd316  vmovaps xmm7, [rsp+0x60]
00007f46e3fdd31c  vmovaps xmm8, [rsp+0x70]
00007f46e3fdd322  vmovaps xmm9, [rsp+0x80]
00007f46e3fdd32b  vmovaps xmm10, [rsp+0x90]
00007f46e3fdd334  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdd33d  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdd346  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdd34f  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdd358  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdd361  add rsp, 0xF0
00007f46e3fdd368  pop r11
00007f46e3fdd36a  pop r10
00007f46e3fdd36c  pop r9
00007f46e3fdd36e  pop r8
00007f46e3fdd370  pop rsi
00007f46e3fdd371  pop rdi
00007f46e3fdd372  pop rdx
00007f46e3fdd373  pop rcx
00007f46e3fdd374  pop rax
00007f46e3fdd375  add rsp, 0x08
00007f46e3fdd379  jmp 0x00007F46E3FDBC94
00007f46e3fdd37e  sub rsp, 0x08
00007f46e3fdd382  push rax
00007f46e3fdd383  push rcx
00007f46e3fdd384  push rdx
00007f46e3fdd385  push rdi
00007f46e3fdd386  push rsi
00007f46e3fdd387  push r8
00007f46e3fdd389  push r9
00007f46e3fdd38b  push r10
00007f46e3fdd38d  push r11
00007f46e3fdd38f  sub rsp, 0xF0
00007f46e3fdd396  vmovaps [rsp], xmm0
00007f46e3fdd39b  vmovaps [rsp+0x10], xmm1
00007f46e3fdd3a1  vmovaps [rsp+0x20], xmm2
00007f46e3fdd3a7  vmovaps [rsp+0x30], xmm3
00007f46e3fdd3ad  vmovaps [rsp+0x40], xmm4
00007f46e3fdd3b3  vmovaps [rsp+0x50], xmm5
00007f46e3fdd3b9  vmovaps [rsp+0x60], xmm6
00007f46e3fdd3bf  vmovaps [rsp+0x70], xmm7
00007f46e3fdd3c5  vmovaps [rsp+0x80], xmm8
00007f46e3fdd3ce  vmovaps [rsp+0x90], xmm10
00007f46e3fdd3d7  vmovaps [rsp+0xA0], xmm11
00007f46e3fdd3e0  vmovaps [rsp+0xB0], xmm12
00007f46e3fdd3e9  vmovaps [rsp+0xC0], xmm13
00007f46e3fdd3f2  vmovaps [rsp+0xD0], xmm14
00007f46e3fdd3fb  vmovaps [rsp+0xE0], xmm15
00007f46e3fdd404  sub rsp, 0x30
00007f46e3fdd408  movaps [rsp], xmm9
00007f46e3fdd40d  movaps [rsp+0x10], xmm10
00007f46e3fdd413  movaps [rsp+0x20], xmm8
00007f46e3fdd419  lea rdi, [rsp]
00007f46e3fdd41d  mov esi, 0x00
00007f46e3fdd422  mov rax, 0x6238B185B530
00007f46e3fdd42c  call rax
00007f46e3fdd42e  movaps xmm9, [rsp]
00007f46e3fdd433  add rsp, 0x30
00007f46e3fdd437  vmovaps xmm0, [rsp]
00007f46e3fdd43c  vmovaps xmm1, [rsp+0x10]
00007f46e3fdd442  vmovaps xmm2, [rsp+0x20]
00007f46e3fdd448  vmovaps xmm3, [rsp+0x30]
00007f46e3fdd44e  vmovaps xmm4, [rsp+0x40]
00007f46e3fdd454  vmovaps xmm5, [rsp+0x50]
00007f46e3fdd45a  vmovaps xmm6, [rsp+0x60]
00007f46e3fdd460  vmovaps xmm7, [rsp+0x70]
00007f46e3fdd466  vmovaps xmm8, [rsp+0x80]
00007f46e3fdd46f  vmovaps xmm10, [rsp+0x90]
00007f46e3fdd478  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdd481  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdd48a  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdd493  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdd49c  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdd4a5  add rsp, 0xF0
00007f46e3fdd4ac  pop r11
00007f46e3fdd4ae  pop r10
00007f46e3fdd4b0  pop r9
00007f46e3fdd4b2  pop r8
00007f46e3fdd4b4  pop rsi
00007f46e3fdd4b5  pop rdi
00007f46e3fdd4b6  pop rdx
00007f46e3fdd4b7  pop rcx
00007f46e3fdd4b8  pop rax
00007f46e3fdd4b9  add rsp, 0x08
00007f46e3fdd4bd  jmp 0x00007F46E3FDBCAE
00007f46e3fdd4c2  call 0x00007F46E3EB52F0
00007f46e3fdd4c7  jmp 0x00007F46E3FDBDC8
00007f46e3fdd4cc  call 0x00007F46E3EB52F0
00007f46e3fdd4d1  jmp 0x00007F46E3FDBDDE
00007f46e3fdd4d6  sub rsp, 0x08
00007f46e3fdd4da  push rax
00007f46e3fdd4db  push rcx
00007f46e3fdd4dc  push rdx
00007f46e3fdd4dd  push rdi
00007f46e3fdd4de  push rsi
00007f46e3fdd4df  push r8
00007f46e3fdd4e1  push r9
00007f46e3fdd4e3  push r10
00007f46e3fdd4e5  push r11
00007f46e3fdd4e7  sub rsp, 0xF0
00007f46e3fdd4ee  vmovaps [rsp], xmm0
00007f46e3fdd4f3  vmovaps [rsp+0x10], xmm2
00007f46e3fdd4f9  vmovaps [rsp+0x20], xmm3
00007f46e3fdd4ff  vmovaps [rsp+0x30], xmm4
00007f46e3fdd505  vmovaps [rsp+0x40], xmm5
00007f46e3fdd50b  vmovaps [rsp+0x50], xmm6
00007f46e3fdd511  vmovaps [rsp+0x60], xmm7
00007f46e3fdd517  vmovaps [rsp+0x70], xmm8
00007f46e3fdd51d  vmovaps [rsp+0x80], xmm9
00007f46e3fdd526  vmovaps [rsp+0x90], xmm10
00007f46e3fdd52f  vmovaps [rsp+0xA0], xmm11
00007f46e3fdd538  vmovaps [rsp+0xB0], xmm12
00007f46e3fdd541  vmovaps [rsp+0xC0], xmm13
00007f46e3fdd54a  vmovaps [rsp+0xD0], xmm14
00007f46e3fdd553  vmovaps [rsp+0xE0], xmm15
00007f46e3fdd55c  sub rsp, 0x30
00007f46e3fdd560  movaps [rsp], xmm1
00007f46e3fdd564  movaps [rsp+0x10], xmm6
00007f46e3fdd569  movaps [rsp+0x20], xmm15
00007f46e3fdd56f  lea rdi, [rsp]
00007f46e3fdd573  mov esi, 0x00
00007f46e3fdd578  mov rax, 0x6238B185B530
00007f46e3fdd582  call rax
00007f46e3fdd584  movaps xmm1, [rsp]
00007f46e3fdd588  add rsp, 0x30
00007f46e3fdd58c  vmovaps xmm0, [rsp]
00007f46e3fdd591  vmovaps xmm2, [rsp+0x10]
00007f46e3fdd597  vmovaps xmm3, [rsp+0x20]
00007f46e3fdd59d  vmovaps xmm4, [rsp+0x30]
00007f46e3fdd5a3  vmovaps xmm5, [rsp+0x40]
00007f46e3fdd5a9  vmovaps xmm6, [rsp+0x50]
00007f46e3fdd5af  vmovaps xmm7, [rsp+0x60]
00007f46e3fdd5b5  vmovaps xmm8, [rsp+0x70]
00007f46e3fdd5bb  vmovaps xmm9, [rsp+0x80]
00007f46e3fdd5c4  vmovaps xmm10, [rsp+0x90]
00007f46e3fdd5cd  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdd5d6  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdd5df  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdd5e8  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdd5f1  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdd5fa  add rsp, 0xF0
00007f46e3fdd601  pop r11
00007f46e3fdd603  pop r10
00007f46e3fdd605  pop r9
00007f46e3fdd607  pop r8
00007f46e3fdd609  pop rsi
00007f46e3fdd60a  pop rdi
00007f46e3fdd60b  pop rdx
00007f46e3fdd60c  pop rcx
00007f46e3fdd60d  pop rax
00007f46e3fdd60e  add rsp, 0x08
00007f46e3fdd612  jmp 0x00007F46E3FDBE1B
00007f46e3fdd617  call 0x00007F46E3EC4620
00007f46e3fdd61c  jmp 0x00007F46E3FDBE28
00007f46e3fdd621  sub rsp, 0x08
00007f46e3fdd625  push rax
00007f46e3fdd626  push rcx
00007f46e3fdd627  push rdx
00007f46e3fdd628  push rdi
00007f46e3fdd629  push rsi
00007f46e3fdd62a  push r8
00007f46e3fdd62c  push r9
00007f46e3fdd62e  push r10
00007f46e3fdd630  push r11
00007f46e3fdd632  sub rsp, 0xF0
00007f46e3fdd639  vmovaps [rsp], xmm0
00007f46e3fdd63e  vmovaps [rsp+0x10], xmm1
00007f46e3fdd644  vmovaps [rsp+0x20], xmm2
00007f46e3fdd64a  vmovaps [rsp+0x30], xmm3
00007f46e3fdd650  vmovaps [rsp+0x40], xmm4
00007f46e3fdd656  vmovaps [rsp+0x50], xmm5
00007f46e3fdd65c  vmovaps [rsp+0x60], xmm6
00007f46e3fdd662  vmovaps [rsp+0x70], xmm7
00007f46e3fdd668  vmovaps [rsp+0x80], xmm8
00007f46e3fdd671  vmovaps [rsp+0x90], xmm9
00007f46e3fdd67a  vmovaps [rsp+0xA0], xmm10
00007f46e3fdd683  vmovaps [rsp+0xB0], xmm11
00007f46e3fdd68c  vmovaps [rsp+0xC0], xmm12
00007f46e3fdd695  vmovaps [rsp+0xD0], xmm13
00007f46e3fdd69e  vmovaps [rsp+0xE0], xmm15
00007f46e3fdd6a7  sub rsp, 0x30
00007f46e3fdd6ab  movaps [rsp], xmm14
00007f46e3fdd6b0  movaps [rsp+0x10], xmm4
00007f46e3fdd6b5  movaps [rsp+0x20], xmm3
00007f46e3fdd6ba  lea rdi, [rsp]
00007f46e3fdd6be  mov esi, 0x00
00007f46e3fdd6c3  mov rax, 0x6238B185B530
00007f46e3fdd6cd  call rax
00007f46e3fdd6cf  movaps xmm14, [rsp]
00007f46e3fdd6d4  add rsp, 0x30
00007f46e3fdd6d8  vmovaps xmm0, [rsp]
00007f46e3fdd6dd  vmovaps xmm1, [rsp+0x10]
00007f46e3fdd6e3  vmovaps xmm2, [rsp+0x20]
00007f46e3fdd6e9  vmovaps xmm3, [rsp+0x30]
00007f46e3fdd6ef  vmovaps xmm4, [rsp+0x40]
00007f46e3fdd6f5  vmovaps xmm5, [rsp+0x50]
00007f46e3fdd6fb  vmovaps xmm6, [rsp+0x60]
00007f46e3fdd701  vmovaps xmm7, [rsp+0x70]
00007f46e3fdd707  vmovaps xmm8, [rsp+0x80]
00007f46e3fdd710  vmovaps xmm9, [rsp+0x90]
00007f46e3fdd719  vmovaps xmm10, [rsp+0xA0]
00007f46e3fdd722  vmovaps xmm11, [rsp+0xB0]
00007f46e3fdd72b  vmovaps xmm12, [rsp+0xC0]
00007f46e3fdd734  vmovaps xmm13, [rsp+0xD0]
00007f46e3fdd73d  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdd746  add rsp, 0xF0
00007f46e3fdd74d  pop r11
00007f46e3fdd74f  pop r10
00007f46e3fdd751  pop r9
00007f46e3fdd753  pop r8
00007f46e3fdd755  pop rsi
00007f46e3fdd756  pop rdi
00007f46e3fdd757  pop rdx
00007f46e3fdd758  pop rcx
00007f46e3fdd759  pop rax
00007f46e3fdd75a  add rsp, 0x08
00007f46e3fdd75e  jmp 0x00007F46E3FDBE42
00007f46e3fdd763  sub rsp, 0x08
00007f46e3fdd767  push rax
00007f46e3fdd768  push rcx
00007f46e3fdd769  push rdx
00007f46e3fdd76a  push rdi
00007f46e3fdd76b  push rsi
00007f46e3fdd76c  push r8
00007f46e3fdd76e  push r9
00007f46e3fdd770  push r10
00007f46e3fdd772  push r11
00007f46e3fdd774  sub rsp, 0xF0
00007f46e3fdd77b  vmovaps [rsp], xmm0
00007f46e3fdd780  vmovaps [rsp+0x10], xmm1
00007f46e3fdd786  vmovaps [rsp+0x20], xmm2
00007f46e3fdd78c  vmovaps [rsp+0x30], xmm3
00007f46e3fdd792  vmovaps [rsp+0x40], xmm4
00007f46e3fdd798  vmovaps [rsp+0x50], xmm5
00007f46e3fdd79e  vmovaps [rsp+0x60], xmm7
00007f46e3fdd7a4  vmovaps [rsp+0x70], xmm8
00007f46e3fdd7aa  vmovaps [rsp+0x80], xmm9
00007f46e3fdd7b3  vmovaps [rsp+0x90], xmm10
00007f46e3fdd7bc  vmovaps [rsp+0xA0], xmm11
00007f46e3fdd7c5  vmovaps [rsp+0xB0], xmm12
00007f46e3fdd7ce  vmovaps [rsp+0xC0], xmm13
00007f46e3fdd7d7  vmovaps [rsp+0xD0], xmm14
00007f46e3fdd7e0  vmovaps [rsp+0xE0], xmm15
00007f46e3fdd7e9  sub rsp, 0x30
00007f46e3fdd7ed  movaps [rsp], xmm6
00007f46e3fdd7f1  movaps [rsp+0x10], xmm9
00007f46e3fdd7f7  movaps [rsp+0x20], xmm7
00007f46e3fdd7fc  lea rdi, [rsp]
00007f46e3fdd800  mov esi, 0x00
00007f46e3fdd805  mov rax, 0x6238B185B530
00007f46e3fdd80f  call rax
00007f46e3fdd811  movaps xmm6, [rsp]
00007f46e3fdd815  add rsp, 0x30
00007f46e3fdd819  vmovaps xmm0, [rsp]
00007f46e3fdd81e  vmovaps xmm1, [rsp+0x10]
00007f46e3fdd824  vmovaps xmm2, [rsp+0x20]
00007f46e3fdd82a  vmovaps xmm3, [rsp+0x30]
00007f46e3fdd830  vmovaps xmm4, [rsp+0x40]
00007f46e3fdd836  vmovaps xmm5, [rsp+0x50]
00007f46e3fdd83c  vmovaps xmm7, [rsp+0x60]
00007f46e3fdd842  vmovaps xmm8, [rsp+0x70]
00007f46e3fdd848  vmovaps xmm9, [rsp+0x80]
00007f46e3fdd851  vmovaps xmm10, [rsp+0x90]
00007f46e3fdd85a  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdd863  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdd86c  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdd875  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdd87e  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdd887  add rsp, 0xF0
00007f46e3fdd88e  pop r11
00007f46e3fdd890  pop r10
00007f46e3fdd892  pop r9
00007f46e3fdd894  pop r8
00007f46e3fdd896  pop rsi
00007f46e3fdd897  pop rdi
00007f46e3fdd898  pop rdx
00007f46e3fdd899  pop rcx
00007f46e3fdd89a  pop rax
00007f46e3fdd89b  add rsp, 0x08
00007f46e3fdd89f  jmp 0x00007F46E3FDBE5A
00007f46e3fdd8a4  sub rsp, 0x08
00007f46e3fdd8a8  push rax
00007f46e3fdd8a9  push rcx
00007f46e3fdd8aa  push rdx
00007f46e3fdd8ab  push rdi
00007f46e3fdd8ac  push rsi
00007f46e3fdd8ad  push r8
00007f46e3fdd8af  push r9
00007f46e3fdd8b1  push r10
00007f46e3fdd8b3  push r11
00007f46e3fdd8b5  sub rsp, 0xF0
00007f46e3fdd8bc  vmovaps [rsp], xmm0
00007f46e3fdd8c1  vmovaps [rsp+0x10], xmm1
00007f46e3fdd8c7  vmovaps [rsp+0x20], xmm2
00007f46e3fdd8cd  vmovaps [rsp+0x30], xmm3
00007f46e3fdd8d3  vmovaps [rsp+0x40], xmm4
00007f46e3fdd8d9  vmovaps [rsp+0x50], xmm5
00007f46e3fdd8df  vmovaps [rsp+0x60], xmm6
00007f46e3fdd8e5  vmovaps [rsp+0x70], xmm8
00007f46e3fdd8eb  vmovaps [rsp+0x80], xmm9
00007f46e3fdd8f4  vmovaps [rsp+0x90], xmm10
00007f46e3fdd8fd  vmovaps [rsp+0xA0], xmm11
00007f46e3fdd906  vmovaps [rsp+0xB0], xmm12
00007f46e3fdd90f  vmovaps [rsp+0xC0], xmm13
00007f46e3fdd918  vmovaps [rsp+0xD0], xmm14
00007f46e3fdd921  vmovaps [rsp+0xE0], xmm15
00007f46e3fdd92a  sub rsp, 0x30
00007f46e3fdd92e  movaps [rsp], xmm7
00007f46e3fdd932  movaps [rsp+0x10], xmm4
00007f46e3fdd937  movaps [rsp+0x20], xmm9
00007f46e3fdd93d  lea rdi, [rsp]
00007f46e3fdd941  mov esi, 0x00
00007f46e3fdd946  mov rax, 0x6238B185B530
00007f46e3fdd950  call rax
00007f46e3fdd952  movaps xmm7, [rsp]
00007f46e3fdd956  add rsp, 0x30
00007f46e3fdd95a  vmovaps xmm0, [rsp]
00007f46e3fdd95f  vmovaps xmm1, [rsp+0x10]
00007f46e3fdd965  vmovaps xmm2, [rsp+0x20]
00007f46e3fdd96b  vmovaps xmm3, [rsp+0x30]
00007f46e3fdd971  vmovaps xmm4, [rsp+0x40]
00007f46e3fdd977  vmovaps xmm5, [rsp+0x50]
00007f46e3fdd97d  vmovaps xmm6, [rsp+0x60]
00007f46e3fdd983  vmovaps xmm8, [rsp+0x70]
00007f46e3fdd989  vmovaps xmm9, [rsp+0x80]
00007f46e3fdd992  vmovaps xmm10, [rsp+0x90]
00007f46e3fdd99b  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdd9a4  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdd9ad  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdd9b6  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdd9bf  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdd9c8  add rsp, 0xF0
00007f46e3fdd9cf  pop r11
00007f46e3fdd9d1  pop r10
00007f46e3fdd9d3  pop r9
00007f46e3fdd9d5  pop r8
00007f46e3fdd9d7  pop rsi
00007f46e3fdd9d8  pop rdi
00007f46e3fdd9d9  pop rdx
00007f46e3fdd9da  pop rcx
00007f46e3fdd9db  pop rax
00007f46e3fdd9dc  add rsp, 0x08
00007f46e3fdd9e0  jmp 0x00007F46E3FDBE87
00007f46e3fdd9e5  sub rsp, 0x08
00007f46e3fdd9e9  push rax
00007f46e3fdd9ea  push rcx
00007f46e3fdd9eb  push rdx
00007f46e3fdd9ec  push rdi
00007f46e3fdd9ed  push rsi
00007f46e3fdd9ee  push r8
00007f46e3fdd9f0  push r9
00007f46e3fdd9f2  push r10
00007f46e3fdd9f4  push r11
00007f46e3fdd9f6  sub rsp, 0xF0
00007f46e3fdd9fd  vmovaps [rsp], xmm0
00007f46e3fdda02  vmovaps [rsp+0x10], xmm1
00007f46e3fdda08  vmovaps [rsp+0x20], xmm2
00007f46e3fdda0e  vmovaps [rsp+0x30], xmm3
00007f46e3fdda14  vmovaps [rsp+0x40], xmm5
00007f46e3fdda1a  vmovaps [rsp+0x50], xmm6
00007f46e3fdda20  vmovaps [rsp+0x60], xmm7
00007f46e3fdda26  vmovaps [rsp+0x70], xmm8
00007f46e3fdda2c  vmovaps [rsp+0x80], xmm9
00007f46e3fdda35  vmovaps [rsp+0x90], xmm10
00007f46e3fdda3e  vmovaps [rsp+0xA0], xmm11
00007f46e3fdda47  vmovaps [rsp+0xB0], xmm12
00007f46e3fdda50  vmovaps [rsp+0xC0], xmm13
00007f46e3fdda59  vmovaps [rsp+0xD0], xmm14
00007f46e3fdda62  vmovaps [rsp+0xE0], xmm15
00007f46e3fdda6b  sub rsp, 0x30
00007f46e3fdda6f  movaps [rsp], xmm4
00007f46e3fdda73  movaps [rsp+0x10], xmm15
00007f46e3fdda79  movaps [rsp+0x20], xmm9
00007f46e3fdda7f  lea rdi, [rsp]
00007f46e3fdda83  mov esi, 0x00
00007f46e3fdda88  mov rax, 0x6238B185B530
00007f46e3fdda92  call rax
00007f46e3fdda94  movaps xmm4, [rsp]
00007f46e3fdda98  add rsp, 0x30
00007f46e3fdda9c  vmovaps xmm0, [rsp]
00007f46e3fddaa1  vmovaps xmm1, [rsp+0x10]
00007f46e3fddaa7  vmovaps xmm2, [rsp+0x20]
00007f46e3fddaad  vmovaps xmm3, [rsp+0x30]
00007f46e3fddab3  vmovaps xmm5, [rsp+0x40]
00007f46e3fddab9  vmovaps xmm6, [rsp+0x50]
00007f46e3fddabf  vmovaps xmm7, [rsp+0x60]
00007f46e3fddac5  vmovaps xmm8, [rsp+0x70]
00007f46e3fddacb  vmovaps xmm9, [rsp+0x80]
00007f46e3fddad4  vmovaps xmm10, [rsp+0x90]
00007f46e3fddadd  vmovaps xmm11, [rsp+0xA0]
00007f46e3fddae6  vmovaps xmm12, [rsp+0xB0]
00007f46e3fddaef  vmovaps xmm13, [rsp+0xC0]
00007f46e3fddaf8  vmovaps xmm14, [rsp+0xD0]
00007f46e3fddb01  vmovaps xmm15, [rsp+0xE0]
00007f46e3fddb0a  add rsp, 0xF0
00007f46e3fddb11  pop r11
00007f46e3fddb13  pop r10
00007f46e3fddb15  pop r9
00007f46e3fddb17  pop r8
00007f46e3fddb19  pop rsi
00007f46e3fddb1a  pop rdi
00007f46e3fddb1b  pop rdx
00007f46e3fddb1c  pop rcx
00007f46e3fddb1d  pop rax
00007f46e3fddb1e  add rsp, 0x08
00007f46e3fddb22  jmp 0x00007F46E3FDBEAC
00007f46e3fddb27  call 0x00007F46E3EC4620
00007f46e3fddb2c  jmp 0x00007F46E3FDBEB9
00007f46e3fddb31  sub rsp, 0x08
00007f46e3fddb35  push rax
00007f46e3fddb36  push rcx
00007f46e3fddb37  push rdx
00007f46e3fddb38  push rdi
00007f46e3fddb39  push rsi
00007f46e3fddb3a  push r8
00007f46e3fddb3c  push r9
00007f46e3fddb3e  push r10
00007f46e3fddb40  push r11
00007f46e3fddb42  sub rsp, 0xF0
00007f46e3fddb49  vmovaps [rsp], xmm0
00007f46e3fddb4e  vmovaps [rsp+0x10], xmm1
00007f46e3fddb54  vmovaps [rsp+0x20], xmm2
00007f46e3fddb5a  vmovaps [rsp+0x30], xmm4
00007f46e3fddb60  vmovaps [rsp+0x40], xmm5
00007f46e3fddb66  vmovaps [rsp+0x50], xmm6
00007f46e3fddb6c  vmovaps [rsp+0x60], xmm7
00007f46e3fddb72  vmovaps [rsp+0x70], xmm8
00007f46e3fddb78  vmovaps [rsp+0x80], xmm9
00007f46e3fddb81  vmovaps [rsp+0x90], xmm10
00007f46e3fddb8a  vmovaps [rsp+0xA0], xmm11
00007f46e3fddb93  vmovaps [rsp+0xB0], xmm12
00007f46e3fddb9c  vmovaps [rsp+0xC0], xmm13
00007f46e3fddba5  vmovaps [rsp+0xD0], xmm14
00007f46e3fddbae  vmovaps [rsp+0xE0], xmm15
00007f46e3fddbb7  sub rsp, 0x30
00007f46e3fddbbb  movaps [rsp], xmm3
00007f46e3fddbbf  movaps [rsp+0x10], xmm1
00007f46e3fddbc4  movaps [rsp+0x20], xmm9
00007f46e3fddbca  lea rdi, [rsp]
00007f46e3fddbce  mov esi, 0x00
00007f46e3fddbd3  mov rax, 0x6238B185B530
00007f46e3fddbdd  call rax
00007f46e3fddbdf  movaps xmm3, [rsp]
00007f46e3fddbe3  add rsp, 0x30
00007f46e3fddbe7  vmovaps xmm0, [rsp]
00007f46e3fddbec  vmovaps xmm1, [rsp+0x10]
00007f46e3fddbf2  vmovaps xmm2, [rsp+0x20]
00007f46e3fddbf8  vmovaps xmm4, [rsp+0x30]
00007f46e3fddbfe  vmovaps xmm5, [rsp+0x40]
00007f46e3fddc04  vmovaps xmm6, [rsp+0x50]
00007f46e3fddc0a  vmovaps xmm7, [rsp+0x60]
00007f46e3fddc10  vmovaps xmm8, [rsp+0x70]
00007f46e3fddc16  vmovaps xmm9, [rsp+0x80]
00007f46e3fddc1f  vmovaps xmm10, [rsp+0x90]
00007f46e3fddc28  vmovaps xmm11, [rsp+0xA0]
00007f46e3fddc31  vmovaps xmm12, [rsp+0xB0]
00007f46e3fddc3a  vmovaps xmm13, [rsp+0xC0]
00007f46e3fddc43  vmovaps xmm14, [rsp+0xD0]
00007f46e3fddc4c  vmovaps xmm15, [rsp+0xE0]
00007f46e3fddc55  add rsp, 0xF0
00007f46e3fddc5c  pop r11
00007f46e3fddc5e  pop r10
00007f46e3fddc60  pop r9
00007f46e3fddc62  pop r8
00007f46e3fddc64  pop rsi
00007f46e3fddc65  pop rdi
00007f46e3fddc66  pop rdx
00007f46e3fddc67  pop rcx
00007f46e3fddc68  pop rax
00007f46e3fddc69  add rsp, 0x08
00007f46e3fddc6d  jmp 0x00007F46E3FDBEF6
00007f46e3fddc72  sub rsp, 0x08
00007f46e3fddc76  push rax
00007f46e3fddc77  push rcx
00007f46e3fddc78  push rdx
00007f46e3fddc79  push rdi
00007f46e3fddc7a  push rsi
00007f46e3fddc7b  push r8
00007f46e3fddc7d  push r9
00007f46e3fddc7f  push r10
00007f46e3fddc81  push r11
00007f46e3fddc83  sub rsp, 0xF0
00007f46e3fddc8a  vmovaps [rsp], xmm0
00007f46e3fddc8f  vmovaps [rsp+0x10], xmm2
00007f46e3fddc95  vmovaps [rsp+0x20], xmm3
00007f46e3fddc9b  vmovaps [rsp+0x30], xmm4
00007f46e3fddca1  vmovaps [rsp+0x40], xmm5
00007f46e3fddca7  vmovaps [rsp+0x50], xmm6
00007f46e3fddcad  vmovaps [rsp+0x60], xmm7
00007f46e3fddcb3  vmovaps [rsp+0x70], xmm8
00007f46e3fddcb9  vmovaps [rsp+0x80], xmm9
00007f46e3fddcc2  vmovaps [rsp+0x90], xmm10
00007f46e3fddccb  vmovaps [rsp+0xA0], xmm11
00007f46e3fddcd4  vmovaps [rsp+0xB0], xmm12
00007f46e3fddcdd  vmovaps [rsp+0xC0], xmm13
00007f46e3fddce6  vmovaps [rsp+0xD0], xmm14
00007f46e3fddcef  vmovaps [rsp+0xE0], xmm15
00007f46e3fddcf8  sub rsp, 0x30
00007f46e3fddcfc  movaps [rsp], xmm1
00007f46e3fddd00  movaps [rsp+0x10], xmm15
00007f46e3fddd06  movaps [rsp+0x20], xmm9
00007f46e3fddd0c  lea rdi, [rsp]
00007f46e3fddd10  mov esi, 0x00
00007f46e3fddd15  mov rax, 0x6238B185B530
00007f46e3fddd1f  call rax
00007f46e3fddd21  movaps xmm1, [rsp]
00007f46e3fddd25  add rsp, 0x30
00007f46e3fddd29  vmovaps xmm0, [rsp]
00007f46e3fddd2e  vmovaps xmm2, [rsp+0x10]
00007f46e3fddd34  vmovaps xmm3, [rsp+0x20]
00007f46e3fddd3a  vmovaps xmm4, [rsp+0x30]
00007f46e3fddd40  vmovaps xmm5, [rsp+0x40]
00007f46e3fddd46  vmovaps xmm6, [rsp+0x50]
00007f46e3fddd4c  vmovaps xmm7, [rsp+0x60]
00007f46e3fddd52  vmovaps xmm8, [rsp+0x70]
00007f46e3fddd58  vmovaps xmm9, [rsp+0x80]
00007f46e3fddd61  vmovaps xmm10, [rsp+0x90]
00007f46e3fddd6a  vmovaps xmm11, [rsp+0xA0]
00007f46e3fddd73  vmovaps xmm12, [rsp+0xB0]
00007f46e3fddd7c  vmovaps xmm13, [rsp+0xC0]
00007f46e3fddd85  vmovaps xmm14, [rsp+0xD0]
00007f46e3fddd8e  vmovaps xmm15, [rsp+0xE0]
00007f46e3fddd97  add rsp, 0xF0
00007f46e3fddd9e  pop r11
00007f46e3fddda0  pop r10
00007f46e3fddda2  pop r9
00007f46e3fddda4  pop r8
00007f46e3fddda6  pop rsi
00007f46e3fddda7  pop rdi
00007f46e3fddda8  pop rdx
00007f46e3fddda9  pop rcx
00007f46e3fdddaa  pop rax
00007f46e3fdddab  add rsp, 0x08
00007f46e3fdddaf  jmp 0x00007F46E3FDBF7E
00007f46e3fdddb4  call 0x00007F46E3EC4620
00007f46e3fdddb9  jmp 0x00007F46E3FDBF8B
00007f46e3fdddbe  sub rsp, 0x08
00007f46e3fdddc2  push rax
00007f46e3fdddc3  push rcx
00007f46e3fdddc4  push rdx
00007f46e3fdddc5  push rdi
00007f46e3fdddc6  push rsi
00007f46e3fdddc7  push r8
00007f46e3fdddc9  push r9
00007f46e3fdddcb  push r10
00007f46e3fdddcd  push r11
00007f46e3fdddcf  sub rsp, 0xF0
00007f46e3fdddd6  vmovaps [rsp], xmm0
00007f46e3fddddb  vmovaps [rsp+0x10], xmm2
00007f46e3fddde1  vmovaps [rsp+0x20], xmm3
00007f46e3fddde7  vmovaps [rsp+0x30], xmm4
00007f46e3fddded  vmovaps [rsp+0x40], xmm5
00007f46e3fdddf3  vmovaps [rsp+0x50], xmm6
00007f46e3fdddf9  vmovaps [rsp+0x60], xmm7
00007f46e3fdddff  vmovaps [rsp+0x70], xmm8
00007f46e3fdde05  vmovaps [rsp+0x80], xmm9
00007f46e3fdde0e  vmovaps [rsp+0x90], xmm10
00007f46e3fdde17  vmovaps [rsp+0xA0], xmm11
00007f46e3fdde20  vmovaps [rsp+0xB0], xmm12
00007f46e3fdde29  vmovaps [rsp+0xC0], xmm13
00007f46e3fdde32  vmovaps [rsp+0xD0], xmm14
00007f46e3fdde3b  vmovaps [rsp+0xE0], xmm15
00007f46e3fdde44  sub rsp, 0x30
00007f46e3fdde48  movaps [rsp], xmm1
00007f46e3fdde4c  movaps [rsp+0x10], xmm5
00007f46e3fdde51  movaps [rsp+0x20], xmm7
00007f46e3fdde56  lea rdi, [rsp]
00007f46e3fdde5a  mov esi, 0x00
00007f46e3fdde5f  mov rax, 0x6238B185B530
00007f46e3fdde69  call rax
00007f46e3fdde6b  movaps xmm1, [rsp]
00007f46e3fdde6f  add rsp, 0x30
00007f46e3fdde73  vmovaps xmm0, [rsp]
00007f46e3fdde78  vmovaps xmm2, [rsp+0x10]
00007f46e3fdde7e  vmovaps xmm3, [rsp+0x20]
00007f46e3fdde84  vmovaps xmm4, [rsp+0x30]
00007f46e3fdde8a  vmovaps xmm5, [rsp+0x40]
00007f46e3fdde90  vmovaps xmm6, [rsp+0x50]
00007f46e3fdde96  vmovaps xmm7, [rsp+0x60]
00007f46e3fdde9c  vmovaps xmm8, [rsp+0x70]
00007f46e3fddea2  vmovaps xmm9, [rsp+0x80]
00007f46e3fddeab  vmovaps xmm10, [rsp+0x90]
00007f46e3fddeb4  vmovaps xmm11, [rsp+0xA0]
00007f46e3fddebd  vmovaps xmm12, [rsp+0xB0]
00007f46e3fddec6  vmovaps xmm13, [rsp+0xC0]
00007f46e3fddecf  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdded8  vmovaps xmm15, [rsp+0xE0]
00007f46e3fddee1  add rsp, 0xF0
00007f46e3fddee8  pop r11
00007f46e3fddeea  pop r10
00007f46e3fddeec  pop r9
00007f46e3fddeee  pop r8
00007f46e3fddef0  pop rsi
00007f46e3fddef1  pop rdi
00007f46e3fddef2  pop rdx
00007f46e3fddef3  pop rcx
00007f46e3fddef4  pop rax
00007f46e3fddef5  add rsp, 0x08
00007f46e3fddef9  jmp 0x00007F46E3FDC030
00007f46e3fddefe  sub rsp, 0x08
00007f46e3fddf02  push rax
00007f46e3fddf03  push rcx
00007f46e3fddf04  push rdx
00007f46e3fddf05  push rdi
00007f46e3fddf06  push rsi
00007f46e3fddf07  push r8
00007f46e3fddf09  push r9
00007f46e3fddf0b  push r10
00007f46e3fddf0d  push r11
00007f46e3fddf0f  sub rsp, 0xF0
00007f46e3fddf16  vmovaps [rsp], xmm0
00007f46e3fddf1b  vmovaps [rsp+0x10], xmm1
00007f46e3fddf21  vmovaps [rsp+0x20], xmm2
00007f46e3fddf27  vmovaps [rsp+0x30], xmm3
00007f46e3fddf2d  vmovaps [rsp+0x40], xmm4
00007f46e3fddf33  vmovaps [rsp+0x50], xmm5
00007f46e3fddf39  vmovaps [rsp+0x60], xmm6
00007f46e3fddf3f  vmovaps [rsp+0x70], xmm8
00007f46e3fddf45  vmovaps [rsp+0x80], xmm9
00007f46e3fddf4e  vmovaps [rsp+0x90], xmm10
00007f46e3fddf57  vmovaps [rsp+0xA0], xmm11
00007f46e3fddf60  vmovaps [rsp+0xB0], xmm12
00007f46e3fddf69  vmovaps [rsp+0xC0], xmm13
00007f46e3fddf72  vmovaps [rsp+0xD0], xmm14
00007f46e3fddf7b  vmovaps [rsp+0xE0], xmm15
00007f46e3fddf84  sub rsp, 0x30
00007f46e3fddf88  movaps [rsp], xmm7
00007f46e3fddf8c  movaps [rsp+0x10], xmm5
00007f46e3fddf91  movaps [rsp+0x20], xmm15
00007f46e3fddf97  lea rdi, [rsp]
00007f46e3fddf9b  mov esi, 0x00
00007f46e3fddfa0  mov rax, 0x6238B185B530
00007f46e3fddfaa  call rax
00007f46e3fddfac  movaps xmm7, [rsp]
00007f46e3fddfb0  add rsp, 0x30
00007f46e3fddfb4  vmovaps xmm0, [rsp]
00007f46e3fddfb9  vmovaps xmm1, [rsp+0x10]
00007f46e3fddfbf  vmovaps xmm2, [rsp+0x20]
00007f46e3fddfc5  vmovaps xmm3, [rsp+0x30]
00007f46e3fddfcb  vmovaps xmm4, [rsp+0x40]
00007f46e3fddfd1  vmovaps xmm5, [rsp+0x50]
00007f46e3fddfd7  vmovaps xmm6, [rsp+0x60]
00007f46e3fddfdd  vmovaps xmm8, [rsp+0x70]
00007f46e3fddfe3  vmovaps xmm9, [rsp+0x80]
00007f46e3fddfec  vmovaps xmm10, [rsp+0x90]
00007f46e3fddff5  vmovaps xmm11, [rsp+0xA0]
00007f46e3fddffe  vmovaps xmm12, [rsp+0xB0]
00007f46e3fde007  vmovaps xmm13, [rsp+0xC0]
00007f46e3fde010  vmovaps xmm14, [rsp+0xD0]
00007f46e3fde019  vmovaps xmm15, [rsp+0xE0]
00007f46e3fde022  add rsp, 0xF0
00007f46e3fde029  pop r11
00007f46e3fde02b  pop r10
00007f46e3fde02d  pop r9
00007f46e3fde02f  pop r8
00007f46e3fde031  pop rsi
00007f46e3fde032  pop rdi
00007f46e3fde033  pop rdx
00007f46e3fde034  pop rcx
00007f46e3fde035  pop rax
00007f46e3fde036  add rsp, 0x08
00007f46e3fde03a  jmp 0x00007F46E3FDC066
00007f46e3fde03f  call 0x00007F46E3EB52F0
00007f46e3fde044  jmp 0x00007F46E3FDC073
00007f46e3fde049  sub rsp, 0x08
00007f46e3fde04d  push rax
00007f46e3fde04e  push rcx
00007f46e3fde04f  push rdx
00007f46e3fde050  push rdi
00007f46e3fde051  push rsi
00007f46e3fde052  push r8
00007f46e3fde054  push r9
00007f46e3fde056  push r10
00007f46e3fde058  push r11
00007f46e3fde05a  sub rsp, 0xF0
00007f46e3fde061  vmovaps [rsp], xmm0
00007f46e3fde066  vmovaps [rsp+0x10], xmm1
00007f46e3fde06c  vmovaps [rsp+0x20], xmm2
00007f46e3fde072  vmovaps [rsp+0x30], xmm3
00007f46e3fde078  vmovaps [rsp+0x40], xmm4
00007f46e3fde07e  vmovaps [rsp+0x50], xmm5
00007f46e3fde084  vmovaps [rsp+0x60], xmm6
00007f46e3fde08a  vmovaps [rsp+0x70], xmm7
00007f46e3fde090  vmovaps [rsp+0x80], xmm8
00007f46e3fde099  vmovaps [rsp+0x90], xmm9
00007f46e3fde0a2  vmovaps [rsp+0xA0], xmm10
00007f46e3fde0ab  vmovaps [rsp+0xB0], xmm11
00007f46e3fde0b4  vmovaps [rsp+0xC0], xmm12
00007f46e3fde0bd  vmovaps [rsp+0xD0], xmm13
00007f46e3fde0c6  vmovaps [rsp+0xE0], xmm14
00007f46e3fde0cf  sub rsp, 0x30
00007f46e3fde0d3  movaps [rsp], xmm15
00007f46e3fde0d8  movaps [rsp+0x10], xmm5
00007f46e3fde0dd  movaps [rsp+0x20], xmm3
00007f46e3fde0e2  lea rdi, [rsp]
00007f46e3fde0e6  mov esi, 0x00
00007f46e3fde0eb  mov rax, 0x6238B185B530
00007f46e3fde0f5  call rax
00007f46e3fde0f7  movaps xmm15, [rsp]
00007f46e3fde0fc  add rsp, 0x30
00007f46e3fde100  vmovaps xmm0, [rsp]
00007f46e3fde105  vmovaps xmm1, [rsp+0x10]
00007f46e3fde10b  vmovaps xmm2, [rsp+0x20]
00007f46e3fde111  vmovaps xmm3, [rsp+0x30]
00007f46e3fde117  vmovaps xmm4, [rsp+0x40]
00007f46e3fde11d  vmovaps xmm5, [rsp+0x50]
00007f46e3fde123  vmovaps xmm6, [rsp+0x60]
00007f46e3fde129  vmovaps xmm7, [rsp+0x70]
00007f46e3fde12f  vmovaps xmm8, [rsp+0x80]
00007f46e3fde138  vmovaps xmm9, [rsp+0x90]
00007f46e3fde141  vmovaps xmm10, [rsp+0xA0]
00007f46e3fde14a  vmovaps xmm11, [rsp+0xB0]
00007f46e3fde153  vmovaps xmm12, [rsp+0xC0]
00007f46e3fde15c  vmovaps xmm13, [rsp+0xD0]
00007f46e3fde165  vmovaps xmm14, [rsp+0xE0]
00007f46e3fde16e  add rsp, 0xF0
00007f46e3fde175  pop r11
00007f46e3fde177  pop r10
00007f46e3fde179  pop r9
00007f46e3fde17b  pop r8
00007f46e3fde17d  pop rsi
00007f46e3fde17e  pop rdi
00007f46e3fde17f  pop rdx
00007f46e3fde180  pop rcx
00007f46e3fde181  pop rax
00007f46e3fde182  add rsp, 0x08
00007f46e3fde186  jmp 0x00007F46E3FDC099
00007f46e3fde18b  sub rsp, 0x08
00007f46e3fde18f  push rax
00007f46e3fde190  push rcx
00007f46e3fde191  push rdx
00007f46e3fde192  push rdi
00007f46e3fde193  push rsi
00007f46e3fde194  push r8
00007f46e3fde196  push r9
00007f46e3fde198  push r10
00007f46e3fde19a  push r11
00007f46e3fde19c  sub rsp, 0xF0
00007f46e3fde1a3  vmovaps [rsp], xmm0
00007f46e3fde1a8  vmovaps [rsp+0x10], xmm2
00007f46e3fde1ae  vmovaps [rsp+0x20], xmm3
00007f46e3fde1b4  vmovaps [rsp+0x30], xmm4
00007f46e3fde1ba  vmovaps [rsp+0x40], xmm5
00007f46e3fde1c0  vmovaps [rsp+0x50], xmm6
00007f46e3fde1c6  vmovaps [rsp+0x60], xmm7
00007f46e3fde1cc  vmovaps [rsp+0x70], xmm8
00007f46e3fde1d2  vmovaps [rsp+0x80], xmm9
00007f46e3fde1db  vmovaps [rsp+0x90], xmm10
00007f46e3fde1e4  vmovaps [rsp+0xA0], xmm11
00007f46e3fde1ed  vmovaps [rsp+0xB0], xmm12
00007f46e3fde1f6  vmovaps [rsp+0xC0], xmm13
00007f46e3fde1ff  vmovaps [rsp+0xD0], xmm14
00007f46e3fde208  vmovaps [rsp+0xE0], xmm15
00007f46e3fde211  sub rsp, 0x30
00007f46e3fde215  movaps [rsp], xmm1
00007f46e3fde219  movaps [rsp+0x10], xmm5
00007f46e3fde21e  movaps [rsp+0x20], xmm4
00007f46e3fde223  lea rdi, [rsp]
00007f46e3fde227  mov esi, 0x00
00007f46e3fde22c  mov rax, 0x6238B185B530
00007f46e3fde236  call rax
00007f46e3fde238  movaps xmm1, [rsp]
00007f46e3fde23c  add rsp, 0x30
00007f46e3fde240  vmovaps xmm0, [rsp]
00007f46e3fde245  vmovaps xmm2, [rsp+0x10]
00007f46e3fde24b  vmovaps xmm3, [rsp+0x20]
00007f46e3fde251  vmovaps xmm4, [rsp+0x30]
00007f46e3fde257  vmovaps xmm5, [rsp+0x40]
00007f46e3fde25d  vmovaps xmm6, [rsp+0x50]
00007f46e3fde263  vmovaps xmm7, [rsp+0x60]
00007f46e3fde269  vmovaps xmm8, [rsp+0x70]
00007f46e3fde26f  vmovaps xmm9, [rsp+0x80]
00007f46e3fde278  vmovaps xmm10, [rsp+0x90]
00007f46e3fde281  vmovaps xmm11, [rsp+0xA0]
00007f46e3fde28a  vmovaps xmm12, [rsp+0xB0]
00007f46e3fde293  vmovaps xmm13, [rsp+0xC0]
00007f46e3fde29c  vmovaps xmm14, [rsp+0xD0]
00007f46e3fde2a5  vmovaps xmm15, [rsp+0xE0]
00007f46e3fde2ae  add rsp, 0xF0
00007f46e3fde2b5  pop r11
00007f46e3fde2b7  pop r10
00007f46e3fde2b9  pop r9
00007f46e3fde2bb  pop r8
00007f46e3fde2bd  pop rsi
00007f46e3fde2be  pop rdi
00007f46e3fde2bf  pop rdx
00007f46e3fde2c0  pop rcx
00007f46e3fde2c1  pop rax
00007f46e3fde2c2  add rsp, 0x08
00007f46e3fde2c6  jmp 0x00007F46E3FDC0B9
00007f46e3fde2cb  sub rsp, 0x08
00007f46e3fde2cf  push rax
00007f46e3fde2d0  push rcx
00007f46e3fde2d1  push rdx
00007f46e3fde2d2  push rdi
00007f46e3fde2d3  push rsi
00007f46e3fde2d4  push r8
00007f46e3fde2d6  push r9
00007f46e3fde2d8  push r10
00007f46e3fde2da  push r11
00007f46e3fde2dc  sub rsp, 0xF0
00007f46e3fde2e3  vmovaps [rsp], xmm0
00007f46e3fde2e8  vmovaps [rsp+0x10], xmm1
00007f46e3fde2ee  vmovaps [rsp+0x20], xmm2
00007f46e3fde2f4  vmovaps [rsp+0x30], xmm3
00007f46e3fde2fa  vmovaps [rsp+0x40], xmm5
00007f46e3fde300  vmovaps [rsp+0x50], xmm6
00007f46e3fde306  vmovaps [rsp+0x60], xmm7
00007f46e3fde30c  vmovaps [rsp+0x70], xmm8
00007f46e3fde312  vmovaps [rsp+0x80], xmm9
00007f46e3fde31b  vmovaps [rsp+0x90], xmm10
00007f46e3fde324  vmovaps [rsp+0xA0], xmm11
00007f46e3fde32d  vmovaps [rsp+0xB0], xmm12
00007f46e3fde336  vmovaps [rsp+0xC0], xmm13
00007f46e3fde33f  vmovaps [rsp+0xD0], xmm14
00007f46e3fde348  vmovaps [rsp+0xE0], xmm15
00007f46e3fde351  sub rsp, 0x30
00007f46e3fde355  movaps [rsp], xmm4
00007f46e3fde359  movaps [rsp+0x10], xmm3
00007f46e3fde35e  movaps [rsp+0x20], xmm5
00007f46e3fde363  lea rdi, [rsp]
00007f46e3fde367  mov esi, 0x00
00007f46e3fde36c  mov rax, 0x6238B185B530
00007f46e3fde376  call rax
00007f46e3fde378  movaps xmm4, [rsp]
00007f46e3fde37c  add rsp, 0x30
00007f46e3fde380  vmovaps xmm0, [rsp]
00007f46e3fde385  vmovaps xmm1, [rsp+0x10]
00007f46e3fde38b  vmovaps xmm2, [rsp+0x20]
00007f46e3fde391  vmovaps xmm3, [rsp+0x30]
00007f46e3fde397  vmovaps xmm5, [rsp+0x40]
00007f46e3fde39d  vmovaps xmm6, [rsp+0x50]
00007f46e3fde3a3  vmovaps xmm7, [rsp+0x60]
00007f46e3fde3a9  vmovaps xmm8, [rsp+0x70]
00007f46e3fde3af  vmovaps xmm9, [rsp+0x80]
00007f46e3fde3b8  vmovaps xmm10, [rsp+0x90]
00007f46e3fde3c1  vmovaps xmm11, [rsp+0xA0]
00007f46e3fde3ca  vmovaps xmm12, [rsp+0xB0]
00007f46e3fde3d3  vmovaps xmm13, [rsp+0xC0]
00007f46e3fde3dc  vmovaps xmm14, [rsp+0xD0]
00007f46e3fde3e5  vmovaps xmm15, [rsp+0xE0]
00007f46e3fde3ee  add rsp, 0xF0
00007f46e3fde3f5  pop r11
00007f46e3fde3f7  pop r10
00007f46e3fde3f9  pop r9
00007f46e3fde3fb  pop r8
00007f46e3fde3fd  pop rsi
00007f46e3fde3fe  pop rdi
00007f46e3fde3ff  pop rdx
00007f46e3fde400  pop rcx
00007f46e3fde401  pop rax
00007f46e3fde402  add rsp, 0x08
00007f46e3fde406  jmp 0x00007F46E3FDC107
00007f46e3fde40b  call 0x00007F46E3EB52F0
00007f46e3fde410  jmp 0x00007F46E3FDC114
00007f46e3fde415  sub rsp, 0x08
00007f46e3fde419  push rax
00007f46e3fde41a  push rcx
00007f46e3fde41b  push rdx
00007f46e3fde41c  push rdi
00007f46e3fde41d  push rsi
00007f46e3fde41e  push r8
00007f46e3fde420  push r9
00007f46e3fde422  push r10
00007f46e3fde424  push r11
00007f46e3fde426  sub rsp, 0xF0
00007f46e3fde42d  vmovaps [rsp], xmm0
00007f46e3fde432  vmovaps [rsp+0x10], xmm1
00007f46e3fde438  vmovaps [rsp+0x20], xmm2
00007f46e3fde43e  vmovaps [rsp+0x30], xmm3
00007f46e3fde444  vmovaps [rsp+0x40], xmm4
00007f46e3fde44a  vmovaps [rsp+0x50], xmm6
00007f46e3fde450  vmovaps [rsp+0x60], xmm7
00007f46e3fde456  vmovaps [rsp+0x70], xmm8
00007f46e3fde45c  vmovaps [rsp+0x80], xmm9
00007f46e3fde465  vmovaps [rsp+0x90], xmm10
00007f46e3fde46e  vmovaps [rsp+0xA0], xmm11
00007f46e3fde477  vmovaps [rsp+0xB0], xmm12
00007f46e3fde480  vmovaps [rsp+0xC0], xmm13
00007f46e3fde489  vmovaps [rsp+0xD0], xmm14
00007f46e3fde492  vmovaps [rsp+0xE0], xmm15
00007f46e3fde49b  sub rsp, 0x30
00007f46e3fde49f  movaps [rsp], xmm5
00007f46e3fde4a3  movaps [rsp+0x10], xmm6
00007f46e3fde4a8  movaps [rsp+0x20], xmm3
00007f46e3fde4ad  lea rdi, [rsp]
00007f46e3fde4b1  mov esi, 0x00
00007f46e3fde4b6  mov rax, 0x6238B185B530
00007f46e3fde4c0  call rax
00007f46e3fde4c2  movaps xmm5, [rsp]
00007f46e3fde4c6  add rsp, 0x30
00007f46e3fde4ca  vmovaps xmm0, [rsp]
00007f46e3fde4cf  vmovaps xmm1, [rsp+0x10]
00007f46e3fde4d5  vmovaps xmm2, [rsp+0x20]
00007f46e3fde4db  vmovaps xmm3, [rsp+0x30]
00007f46e3fde4e1  vmovaps xmm4, [rsp+0x40]
00007f46e3fde4e7  vmovaps xmm6, [rsp+0x50]
00007f46e3fde4ed  vmovaps xmm7, [rsp+0x60]
00007f46e3fde4f3  vmovaps xmm8, [rsp+0x70]
00007f46e3fde4f9  vmovaps xmm9, [rsp+0x80]
00007f46e3fde502  vmovaps xmm10, [rsp+0x90]
00007f46e3fde50b  vmovaps xmm11, [rsp+0xA0]
00007f46e3fde514  vmovaps xmm12, [rsp+0xB0]
00007f46e3fde51d  vmovaps xmm13, [rsp+0xC0]
00007f46e3fde526  vmovaps xmm14, [rsp+0xD0]
00007f46e3fde52f  vmovaps xmm15, [rsp+0xE0]
00007f46e3fde538  add rsp, 0xF0
00007f46e3fde53f  pop r11
00007f46e3fde541  pop r10
00007f46e3fde543  pop r9
00007f46e3fde545  pop r8
00007f46e3fde547  pop rsi
00007f46e3fde548  pop rdi
00007f46e3fde549  pop rdx
00007f46e3fde54a  pop rcx
00007f46e3fde54b  pop rax
00007f46e3fde54c  add rsp, 0x08
00007f46e3fde550  jmp 0x00007F46E3FDC13A
00007f46e3fde555  sub rsp, 0x08
00007f46e3fde559  push rax
00007f46e3fde55a  push rcx
00007f46e3fde55b  push rdx
00007f46e3fde55c  push rdi
00007f46e3fde55d  push rsi
00007f46e3fde55e  push r8
00007f46e3fde560  push r9
00007f46e3fde562  push r10
00007f46e3fde564  push r11
00007f46e3fde566  sub rsp, 0xF0
00007f46e3fde56d  vmovaps [rsp], xmm0
00007f46e3fde572  vmovaps [rsp+0x10], xmm1
00007f46e3fde578  vmovaps [rsp+0x20], xmm2
00007f46e3fde57e  vmovaps [rsp+0x30], xmm3
00007f46e3fde584  vmovaps [rsp+0x40], xmm4
00007f46e3fde58a  vmovaps [rsp+0x50], xmm5
00007f46e3fde590  vmovaps [rsp+0x60], xmm7
00007f46e3fde596  vmovaps [rsp+0x70], xmm8
00007f46e3fde59c  vmovaps [rsp+0x80], xmm9
00007f46e3fde5a5  vmovaps [rsp+0x90], xmm10
00007f46e3fde5ae  vmovaps [rsp+0xA0], xmm11
00007f46e3fde5b7  vmovaps [rsp+0xB0], xmm12
00007f46e3fde5c0  vmovaps [rsp+0xC0], xmm13
00007f46e3fde5c9  vmovaps [rsp+0xD0], xmm14
00007f46e3fde5d2  vmovaps [rsp+0xE0], xmm15
00007f46e3fde5db  sub rsp, 0x30
00007f46e3fde5df  movaps [rsp], xmm6
00007f46e3fde5e3  movaps [rsp+0x10], xmm9
00007f46e3fde5e9  movaps [rsp+0x20], xmm1
00007f46e3fde5ee  lea rdi, [rsp]
00007f46e3fde5f2  mov esi, 0x00
00007f46e3fde5f7  mov rax, 0x6238B185B530
00007f46e3fde601  call rax
00007f46e3fde603  movaps xmm6, [rsp]
00007f46e3fde607  add rsp, 0x30
00007f46e3fde60b  vmovaps xmm0, [rsp]
00007f46e3fde610  vmovaps xmm1, [rsp+0x10]
00007f46e3fde616  vmovaps xmm2, [rsp+0x20]
00007f46e3fde61c  vmovaps xmm3, [rsp+0x30]
00007f46e3fde622  vmovaps xmm4, [rsp+0x40]
00007f46e3fde628  vmovaps xmm5, [rsp+0x50]
00007f46e3fde62e  vmovaps xmm7, [rsp+0x60]
00007f46e3fde634  vmovaps xmm8, [rsp+0x70]
00007f46e3fde63a  vmovaps xmm9, [rsp+0x80]
00007f46e3fde643  vmovaps xmm10, [rsp+0x90]
00007f46e3fde64c  vmovaps xmm11, [rsp+0xA0]
00007f46e3fde655  vmovaps xmm12, [rsp+0xB0]
00007f46e3fde65e  vmovaps xmm13, [rsp+0xC0]
00007f46e3fde667  vmovaps xmm14, [rsp+0xD0]
00007f46e3fde670  vmovaps xmm15, [rsp+0xE0]
00007f46e3fde679  add rsp, 0xF0
00007f46e3fde680  pop r11
00007f46e3fde682  pop r10
00007f46e3fde684  pop r9
00007f46e3fde686  pop r8
00007f46e3fde688  pop rsi
00007f46e3fde689  pop rdi
00007f46e3fde68a  pop rdx
00007f46e3fde68b  pop rcx
00007f46e3fde68c  pop rax
00007f46e3fde68d  add rsp, 0x08
00007f46e3fde691  jmp 0x00007F46E3FDC15E
00007f46e3fde696  sub rsp, 0x08
00007f46e3fde69a  push rax
00007f46e3fde69b  push rcx
00007f46e3fde69c  push rdx
00007f46e3fde69d  push rdi
00007f46e3fde69e  push rsi
00007f46e3fde69f  push r8
00007f46e3fde6a1  push r9
00007f46e3fde6a3  push r10
00007f46e3fde6a5  push r11
00007f46e3fde6a7  sub rsp, 0xF0
00007f46e3fde6ae  vmovaps [rsp], xmm0
00007f46e3fde6b3  vmovaps [rsp+0x10], xmm1
00007f46e3fde6b9  vmovaps [rsp+0x20], xmm2
00007f46e3fde6bf  vmovaps [rsp+0x30], xmm3
00007f46e3fde6c5  vmovaps [rsp+0x40], xmm4
00007f46e3fde6cb  vmovaps [rsp+0x50], xmm5
00007f46e3fde6d1  vmovaps [rsp+0x60], xmm6
00007f46e3fde6d7  vmovaps [rsp+0x70], xmm7
00007f46e3fde6dd  vmovaps [rsp+0x80], xmm8
00007f46e3fde6e6  vmovaps [rsp+0x90], xmm10
00007f46e3fde6ef  vmovaps [rsp+0xA0], xmm11
00007f46e3fde6f8  vmovaps [rsp+0xB0], xmm12
00007f46e3fde701  vmovaps [rsp+0xC0], xmm13
00007f46e3fde70a  vmovaps [rsp+0xD0], xmm14
00007f46e3fde713  vmovaps [rsp+0xE0], xmm15
00007f46e3fde71c  sub rsp, 0x30
00007f46e3fde720  movaps [rsp], xmm9
00007f46e3fde725  movaps [rsp+0x10], xmm3
00007f46e3fde72a  movaps [rsp+0x20], xmm1
00007f46e3fde72f  lea rdi, [rsp]
00007f46e3fde733  mov esi, 0x00
00007f46e3fde738  mov rax, 0x6238B185B530
00007f46e3fde742  call rax
00007f46e3fde744  movaps xmm9, [rsp]
00007f46e3fde749  add rsp, 0x30
00007f46e3fde74d  vmovaps xmm0, [rsp]
00007f46e3fde752  vmovaps xmm1, [rsp+0x10]
00007f46e3fde758  vmovaps xmm2, [rsp+0x20]
00007f46e3fde75e  vmovaps xmm3, [rsp+0x30]
00007f46e3fde764  vmovaps xmm4, [rsp+0x40]
00007f46e3fde76a  vmovaps xmm5, [rsp+0x50]
00007f46e3fde770  vmovaps xmm6, [rsp+0x60]
00007f46e3fde776  vmovaps xmm7, [rsp+0x70]
00007f46e3fde77c  vmovaps xmm8, [rsp+0x80]
00007f46e3fde785  vmovaps xmm10, [rsp+0x90]
00007f46e3fde78e  vmovaps xmm11, [rsp+0xA0]
00007f46e3fde797  vmovaps xmm12, [rsp+0xB0]
00007f46e3fde7a0  vmovaps xmm13, [rsp+0xC0]
00007f46e3fde7a9  vmovaps xmm14, [rsp+0xD0]
00007f46e3fde7b2  vmovaps xmm15, [rsp+0xE0]
00007f46e3fde7bb  add rsp, 0xF0
00007f46e3fde7c2  pop r11
00007f46e3fde7c4  pop r10
00007f46e3fde7c6  pop r9
00007f46e3fde7c8  pop r8
00007f46e3fde7ca  pop rsi
00007f46e3fde7cb  pop rdi
00007f46e3fde7cc  pop rdx
00007f46e3fde7cd  pop rcx
00007f46e3fde7ce  pop rax
00007f46e3fde7cf  add rsp, 0x08
00007f46e3fde7d3  jmp 0x00007F46E3FDC1AA
00007f46e3fde7d8  call 0x00007F46E3EB52F0
00007f46e3fde7dd  jmp 0x00007F46E3FDC1B7
00007f46e3fde7e2  sub rsp, 0x08
00007f46e3fde7e6  push rax
00007f46e3fde7e7  push rcx
00007f46e3fde7e8  push rdx
00007f46e3fde7e9  push rdi
00007f46e3fde7ea  push rsi
00007f46e3fde7eb  push r8
00007f46e3fde7ed  push r9
00007f46e3fde7ef  push r10
00007f46e3fde7f1  push r11
00007f46e3fde7f3  sub rsp, 0xF0
00007f46e3fde7fa  vmovaps [rsp], xmm0
00007f46e3fde7ff  vmovaps [rsp+0x10], xmm1
00007f46e3fde805  vmovaps [rsp+0x20], xmm2
00007f46e3fde80b  vmovaps [rsp+0x30], xmm3
00007f46e3fde811  vmovaps [rsp+0x40], xmm4
00007f46e3fde817  vmovaps [rsp+0x50], xmm5
00007f46e3fde81d  vmovaps [rsp+0x60], xmm6
00007f46e3fde823  vmovaps [rsp+0x70], xmm7
00007f46e3fde829  vmovaps [rsp+0x80], xmm8
00007f46e3fde832  vmovaps [rsp+0x90], xmm9
00007f46e3fde83b  vmovaps [rsp+0xA0], xmm10
00007f46e3fde844  vmovaps [rsp+0xB0], xmm11
00007f46e3fde84d  vmovaps [rsp+0xC0], xmm12
00007f46e3fde856  vmovaps [rsp+0xD0], xmm13
00007f46e3fde85f  vmovaps [rsp+0xE0], xmm14
00007f46e3fde868  sub rsp, 0x30
00007f46e3fde86c  movaps [rsp], xmm15
00007f46e3fde871  movaps [rsp+0x10], xmm3
00007f46e3fde876  movaps [rsp+0x20], xmm7
00007f46e3fde87b  lea rdi, [rsp]
00007f46e3fde87f  mov esi, 0x00
00007f46e3fde884  mov rax, 0x6238B185B530
00007f46e3fde88e  call rax
00007f46e3fde890  movaps xmm15, [rsp]
00007f46e3fde895  add rsp, 0x30
00007f46e3fde899  vmovaps xmm0, [rsp]
00007f46e3fde89e  vmovaps xmm1, [rsp+0x10]
00007f46e3fde8a4  vmovaps xmm2, [rsp+0x20]
00007f46e3fde8aa  vmovaps xmm3, [rsp+0x30]
00007f46e3fde8b0  vmovaps xmm4, [rsp+0x40]
00007f46e3fde8b6  vmovaps xmm5, [rsp+0x50]
00007f46e3fde8bc  vmovaps xmm6, [rsp+0x60]
00007f46e3fde8c2  vmovaps xmm7, [rsp+0x70]
00007f46e3fde8c8  vmovaps xmm8, [rsp+0x80]
00007f46e3fde8d1  vmovaps xmm9, [rsp+0x90]
00007f46e3fde8da  vmovaps xmm10, [rsp+0xA0]
00007f46e3fde8e3  vmovaps xmm11, [rsp+0xB0]
00007f46e3fde8ec  vmovaps xmm12, [rsp+0xC0]
00007f46e3fde8f5  vmovaps xmm13, [rsp+0xD0]
00007f46e3fde8fe  vmovaps xmm14, [rsp+0xE0]
00007f46e3fde907  add rsp, 0xF0
00007f46e3fde90e  pop r11
00007f46e3fde910  pop r10
00007f46e3fde912  pop r9
00007f46e3fde914  pop r8
00007f46e3fde916  pop rsi
00007f46e3fde917  pop rdi
00007f46e3fde918  pop rdx
00007f46e3fde919  pop rcx
00007f46e3fde91a  pop rax
00007f46e3fde91b  add rsp, 0x08
00007f46e3fde91f  jmp 0x00007F46E3FDC1E3
00007f46e3fde924  sub rsp, 0x08
00007f46e3fde928  push rax
00007f46e3fde929  push rcx
00007f46e3fde92a  push rdx
00007f46e3fde92b  push rdi
00007f46e3fde92c  push rsi
00007f46e3fde92d  push r8
00007f46e3fde92f  push r9
00007f46e3fde931  push r10
00007f46e3fde933  push r11
00007f46e3fde935  sub rsp, 0xF0
00007f46e3fde93c  vmovaps [rsp], xmm0
00007f46e3fde941  vmovaps [rsp+0x10], xmm1
00007f46e3fde947  vmovaps [rsp+0x20], xmm2
00007f46e3fde94d  vmovaps [rsp+0x30], xmm4
00007f46e3fde953  vmovaps [rsp+0x40], xmm5
00007f46e3fde959  vmovaps [rsp+0x50], xmm6
00007f46e3fde95f  vmovaps [rsp+0x60], xmm7
00007f46e3fde965  vmovaps [rsp+0x70], xmm8
00007f46e3fde96b  vmovaps [rsp+0x80], xmm9
00007f46e3fde974  vmovaps [rsp+0x90], xmm10
00007f46e3fde97d  vmovaps [rsp+0xA0], xmm11
00007f46e3fde986  vmovaps [rsp+0xB0], xmm12
00007f46e3fde98f  vmovaps [rsp+0xC0], xmm13
00007f46e3fde998  vmovaps [rsp+0xD0], xmm14
00007f46e3fde9a1  vmovaps [rsp+0xE0], xmm15
00007f46e3fde9aa  sub rsp, 0x30
00007f46e3fde9ae  movaps [rsp], xmm3
00007f46e3fde9b2  movaps [rsp+0x10], xmm1
00007f46e3fde9b7  movaps [rsp+0x20], xmm15
00007f46e3fde9bd  lea rdi, [rsp]
00007f46e3fde9c1  mov esi, 0x00
00007f46e3fde9c6  mov rax, 0x6238B185B530
00007f46e3fde9d0  call rax
00007f46e3fde9d2  movaps xmm3, [rsp]
00007f46e3fde9d6  add rsp, 0x30
00007f46e3fde9da  vmovaps xmm0, [rsp]
00007f46e3fde9df  vmovaps xmm1, [rsp+0x10]
00007f46e3fde9e5  vmovaps xmm2, [rsp+0x20]
00007f46e3fde9eb  vmovaps xmm4, [rsp+0x30]
00007f46e3fde9f1  vmovaps xmm5, [rsp+0x40]
00007f46e3fde9f7  vmovaps xmm6, [rsp+0x50]
00007f46e3fde9fd  vmovaps xmm7, [rsp+0x60]
00007f46e3fdea03  vmovaps xmm8, [rsp+0x70]
00007f46e3fdea09  vmovaps xmm9, [rsp+0x80]
00007f46e3fdea12  vmovaps xmm10, [rsp+0x90]
00007f46e3fdea1b  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdea24  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdea2d  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdea36  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdea3f  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdea48  add rsp, 0xF0
00007f46e3fdea4f  pop r11
00007f46e3fdea51  pop r10
00007f46e3fdea53  pop r9
00007f46e3fdea55  pop r8
00007f46e3fdea57  pop rsi
00007f46e3fdea58  pop rdi
00007f46e3fdea59  pop rdx
00007f46e3fdea5a  pop rcx
00007f46e3fdea5b  pop rax
00007f46e3fdea5c  add rsp, 0x08
00007f46e3fdea60  jmp 0x00007F46E3FDC272
00007f46e3fdea65  call 0x00007F46E3EB52F0
00007f46e3fdea6a  jmp 0x00007F46E3FDC27C
00007f46e3fdea6f  sub rsp, 0x08
00007f46e3fdea73  push rax
00007f46e3fdea74  push rcx
00007f46e3fdea75  push rdx
00007f46e3fdea76  push rdi
00007f46e3fdea77  push rsi
00007f46e3fdea78  push r8
00007f46e3fdea7a  push r9
00007f46e3fdea7c  push r10
00007f46e3fdea7e  push r11
00007f46e3fdea80  sub rsp, 0xF0
00007f46e3fdea87  vmovaps [rsp], xmm0
00007f46e3fdea8c  vmovaps [rsp+0x10], xmm1
00007f46e3fdea92  vmovaps [rsp+0x20], xmm2
00007f46e3fdea98  vmovaps [rsp+0x30], xmm3
00007f46e3fdea9e  vmovaps [rsp+0x40], xmm4
00007f46e3fdeaa4  vmovaps [rsp+0x50], xmm5
00007f46e3fdeaaa  vmovaps [rsp+0x60], xmm6
00007f46e3fdeab0  vmovaps [rsp+0x70], xmm7
00007f46e3fdeab6  vmovaps [rsp+0x80], xmm8
00007f46e3fdeabf  vmovaps [rsp+0x90], xmm9
00007f46e3fdeac8  vmovaps [rsp+0xA0], xmm10
00007f46e3fdead1  vmovaps [rsp+0xB0], xmm11
00007f46e3fdeada  vmovaps [rsp+0xC0], xmm12
00007f46e3fdeae3  vmovaps [rsp+0xD0], xmm13
00007f46e3fdeaec  vmovaps [rsp+0xE0], xmm14
00007f46e3fdeaf5  sub rsp, 0x30
00007f46e3fdeaf9  movaps [rsp], xmm15
00007f46e3fdeafe  movaps [rsp+0x10], xmm14
00007f46e3fdeb04  movaps [rsp+0x20], xmm4
00007f46e3fdeb09  lea rdi, [rsp]
00007f46e3fdeb0d  mov esi, 0x00
00007f46e3fdeb12  mov rax, 0x6238B185B530
00007f46e3fdeb1c  call rax
00007f46e3fdeb1e  movaps xmm15, [rsp]
00007f46e3fdeb23  add rsp, 0x30
00007f46e3fdeb27  vmovaps xmm0, [rsp]
00007f46e3fdeb2c  vmovaps xmm1, [rsp+0x10]
00007f46e3fdeb32  vmovaps xmm2, [rsp+0x20]
00007f46e3fdeb38  vmovaps xmm3, [rsp+0x30]
00007f46e3fdeb3e  vmovaps xmm4, [rsp+0x40]
00007f46e3fdeb44  vmovaps xmm5, [rsp+0x50]
00007f46e3fdeb4a  vmovaps xmm6, [rsp+0x60]
00007f46e3fdeb50  vmovaps xmm7, [rsp+0x70]
00007f46e3fdeb56  vmovaps xmm8, [rsp+0x80]
00007f46e3fdeb5f  vmovaps xmm9, [rsp+0x90]
00007f46e3fdeb68  vmovaps xmm10, [rsp+0xA0]
00007f46e3fdeb71  vmovaps xmm11, [rsp+0xB0]
00007f46e3fdeb7a  vmovaps xmm12, [rsp+0xC0]
00007f46e3fdeb83  vmovaps xmm13, [rsp+0xD0]
00007f46e3fdeb8c  vmovaps xmm14, [rsp+0xE0]
00007f46e3fdeb95  add rsp, 0xF0
00007f46e3fdeb9c  pop r11
00007f46e3fdeb9e  pop r10
00007f46e3fdeba0  pop r9
00007f46e3fdeba2  pop r8
00007f46e3fdeba4  pop rsi
00007f46e3fdeba5  pop rdi
00007f46e3fdeba6  pop rdx
00007f46e3fdeba7  pop rcx
00007f46e3fdeba8  pop rax
00007f46e3fdeba9  add rsp, 0x08
00007f46e3fdebad  jmp 0x00007F46E3FDC2AA
00007f46e3fdebb2  sub rsp, 0x08
00007f46e3fdebb6  push rax
00007f46e3fdebb7  push rcx
00007f46e3fdebb8  push rdx
00007f46e3fdebb9  push rdi
00007f46e3fdebba  push rsi
00007f46e3fdebbb  push r8
00007f46e3fdebbd  push r9
00007f46e3fdebbf  push r10
00007f46e3fdebc1  push r11
00007f46e3fdebc3  sub rsp, 0xF0
00007f46e3fdebca  vmovaps [rsp], xmm0
00007f46e3fdebcf  vmovaps [rsp+0x10], xmm1
00007f46e3fdebd5  vmovaps [rsp+0x20], xmm2
00007f46e3fdebdb  vmovaps [rsp+0x30], xmm3
00007f46e3fdebe1  vmovaps [rsp+0x40], xmm4
00007f46e3fdebe7  vmovaps [rsp+0x50], xmm5
00007f46e3fdebed  vmovaps [rsp+0x60], xmm6
00007f46e3fdebf3  vmovaps [rsp+0x70], xmm7
00007f46e3fdebf9  vmovaps [rsp+0x80], xmm8
00007f46e3fdec02  vmovaps [rsp+0x90], xmm9
00007f46e3fdec0b  vmovaps [rsp+0xA0], xmm10
00007f46e3fdec14  vmovaps [rsp+0xB0], xmm11
00007f46e3fdec1d  vmovaps [rsp+0xC0], xmm12
00007f46e3fdec26  vmovaps [rsp+0xD0], xmm13
00007f46e3fdec2f  vmovaps [rsp+0xE0], xmm15
00007f46e3fdec38  sub rsp, 0x30
00007f46e3fdec3c  movaps [rsp], xmm14
00007f46e3fdec41  movaps [rsp+0x10], xmm2
00007f46e3fdec46  movaps [rsp+0x20], xmm1
00007f46e3fdec4b  lea rdi, [rsp]
00007f46e3fdec4f  mov esi, 0x00
00007f46e3fdec54  mov rax, 0x6238B185B530
00007f46e3fdec5e  call rax
00007f46e3fdec60  movaps xmm14, [rsp]
00007f46e3fdec65  add rsp, 0x30
00007f46e3fdec69  vmovaps xmm0, [rsp]
00007f46e3fdec6e  vmovaps xmm1, [rsp+0x10]
00007f46e3fdec74  vmovaps xmm2, [rsp+0x20]
00007f46e3fdec7a  vmovaps xmm3, [rsp+0x30]
00007f46e3fdec80  vmovaps xmm4, [rsp+0x40]
00007f46e3fdec86  vmovaps xmm5, [rsp+0x50]
00007f46e3fdec8c  vmovaps xmm6, [rsp+0x60]
00007f46e3fdec92  vmovaps xmm7, [rsp+0x70]
00007f46e3fdec98  vmovaps xmm8, [rsp+0x80]
00007f46e3fdeca1  vmovaps xmm9, [rsp+0x90]
00007f46e3fdecaa  vmovaps xmm10, [rsp+0xA0]
00007f46e3fdecb3  vmovaps xmm11, [rsp+0xB0]
00007f46e3fdecbc  vmovaps xmm12, [rsp+0xC0]
00007f46e3fdecc5  vmovaps xmm13, [rsp+0xD0]
00007f46e3fdecce  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdecd7  add rsp, 0xF0
00007f46e3fdecde  pop r11
00007f46e3fdece0  pop r10
00007f46e3fdece2  pop r9
00007f46e3fdece4  pop r8
00007f46e3fdece6  pop rsi
00007f46e3fdece7  pop rdi
00007f46e3fdece8  pop rdx
00007f46e3fdece9  pop rcx
00007f46e3fdecea  pop rax
00007f46e3fdeceb  add rsp, 0x08
00007f46e3fdecef  jmp 0x00007F46E3FDC2D0
00007f46e3fdecf4  sub rsp, 0x08
00007f46e3fdecf8  push rax
00007f46e3fdecf9  push rcx
00007f46e3fdecfa  push rdx
00007f46e3fdecfb  push rdi
00007f46e3fdecfc  push rsi
00007f46e3fdecfd  push r8
00007f46e3fdecff  push r9
00007f46e3fded01  push r10
00007f46e3fded03  push r11
00007f46e3fded05  sub rsp, 0xF0
00007f46e3fded0c  vmovaps [rsp], xmm0
00007f46e3fded11  vmovaps [rsp+0x10], xmm2
00007f46e3fded17  vmovaps [rsp+0x20], xmm3
00007f46e3fded1d  vmovaps [rsp+0x30], xmm4
00007f46e3fded23  vmovaps [rsp+0x40], xmm5
00007f46e3fded29  vmovaps [rsp+0x50], xmm6
00007f46e3fded2f  vmovaps [rsp+0x60], xmm7
00007f46e3fded35  vmovaps [rsp+0x70], xmm8
00007f46e3fded3b  vmovaps [rsp+0x80], xmm9
00007f46e3fded44  vmovaps [rsp+0x90], xmm10
00007f46e3fded4d  vmovaps [rsp+0xA0], xmm11
00007f46e3fded56  vmovaps [rsp+0xB0], xmm12
00007f46e3fded5f  vmovaps [rsp+0xC0], xmm13
00007f46e3fded68  vmovaps [rsp+0xD0], xmm14
00007f46e3fded71  vmovaps [rsp+0xE0], xmm15
00007f46e3fded7a  sub rsp, 0x30
00007f46e3fded7e  movaps [rsp], xmm1
00007f46e3fded82  movaps [rsp+0x10], xmm4
00007f46e3fded87  movaps [rsp+0x20], xmm9
00007f46e3fded8d  lea rdi, [rsp]
00007f46e3fded91  mov esi, 0x00
00007f46e3fded96  mov rax, 0x6238B185B530
00007f46e3fdeda0  call rax
00007f46e3fdeda2  movaps xmm1, [rsp]
00007f46e3fdeda6  add rsp, 0x30
00007f46e3fdedaa  vmovaps xmm0, [rsp]
00007f46e3fdedaf  vmovaps xmm2, [rsp+0x10]
00007f46e3fdedb5  vmovaps xmm3, [rsp+0x20]
00007f46e3fdedbb  vmovaps xmm4, [rsp+0x30]
00007f46e3fdedc1  vmovaps xmm5, [rsp+0x40]
00007f46e3fdedc7  vmovaps xmm6, [rsp+0x50]
00007f46e3fdedcd  vmovaps xmm7, [rsp+0x60]
00007f46e3fdedd3  vmovaps xmm8, [rsp+0x70]
00007f46e3fdedd9  vmovaps xmm9, [rsp+0x80]
00007f46e3fdede2  vmovaps xmm10, [rsp+0x90]
00007f46e3fdedeb  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdedf4  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdedfd  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdee06  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdee0f  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdee18  add rsp, 0xF0
00007f46e3fdee1f  pop r11
00007f46e3fdee21  pop r10
00007f46e3fdee23  pop r9
00007f46e3fdee25  pop r8
00007f46e3fdee27  pop rsi
00007f46e3fdee28  pop rdi
00007f46e3fdee29  pop rdx
00007f46e3fdee2a  pop rcx
00007f46e3fdee2b  pop rax
00007f46e3fdee2c  add rsp, 0x08
00007f46e3fdee30  jmp 0x00007F46E3FDC2EE
00007f46e3fdee35  sub rsp, 0x08
00007f46e3fdee39  push rax
00007f46e3fdee3a  push rcx
00007f46e3fdee3b  push rdx
00007f46e3fdee3c  push rdi
00007f46e3fdee3d  push rsi
00007f46e3fdee3e  push r8
00007f46e3fdee40  push r9
00007f46e3fdee42  push r10
00007f46e3fdee44  push r11
00007f46e3fdee46  sub rsp, 0xF0
00007f46e3fdee4d  vmovaps [rsp], xmm0
00007f46e3fdee52  vmovaps [rsp+0x10], xmm1
00007f46e3fdee58  vmovaps [rsp+0x20], xmm2
00007f46e3fdee5e  vmovaps [rsp+0x30], xmm3
00007f46e3fdee64  vmovaps [rsp+0x40], xmm5
00007f46e3fdee6a  vmovaps [rsp+0x50], xmm6
00007f46e3fdee70  vmovaps [rsp+0x60], xmm7
00007f46e3fdee76  vmovaps [rsp+0x70], xmm8
00007f46e3fdee7c  vmovaps [rsp+0x80], xmm9
00007f46e3fdee85  vmovaps [rsp+0x90], xmm10
00007f46e3fdee8e  vmovaps [rsp+0xA0], xmm11
00007f46e3fdee97  vmovaps [rsp+0xB0], xmm12
00007f46e3fdeea0  vmovaps [rsp+0xC0], xmm13
00007f46e3fdeea9  vmovaps [rsp+0xD0], xmm14
00007f46e3fdeeb2  vmovaps [rsp+0xE0], xmm15
00007f46e3fdeebb  sub rsp, 0x30
00007f46e3fdeebf  movaps [rsp], xmm4
00007f46e3fdeec3  movaps [rsp+0x10], xmm2
00007f46e3fdeec8  movaps [rsp+0x20], xmm9
00007f46e3fdeece  lea rdi, [rsp]
00007f46e3fdeed2  mov esi, 0x00
00007f46e3fdeed7  mov rax, 0x6238B185B530
00007f46e3fdeee1  call rax
00007f46e3fdeee3  movaps xmm4, [rsp]
00007f46e3fdeee7  add rsp, 0x30
00007f46e3fdeeeb  vmovaps xmm0, [rsp]
00007f46e3fdeef0  vmovaps xmm1, [rsp+0x10]
00007f46e3fdeef6  vmovaps xmm2, [rsp+0x20]
00007f46e3fdeefc  vmovaps xmm3, [rsp+0x30]
00007f46e3fdef02  vmovaps xmm5, [rsp+0x40]
00007f46e3fdef08  vmovaps xmm6, [rsp+0x50]
00007f46e3fdef0e  vmovaps xmm7, [rsp+0x60]
00007f46e3fdef14  vmovaps xmm8, [rsp+0x70]
00007f46e3fdef1a  vmovaps xmm9, [rsp+0x80]
00007f46e3fdef23  vmovaps xmm10, [rsp+0x90]
00007f46e3fdef2c  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdef35  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdef3e  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdef47  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdef50  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdef59  add rsp, 0xF0
00007f46e3fdef60  pop r11
00007f46e3fdef62  pop r10
00007f46e3fdef64  pop r9
00007f46e3fdef66  pop r8
00007f46e3fdef68  pop rsi
00007f46e3fdef69  pop rdi
00007f46e3fdef6a  pop rdx
00007f46e3fdef6b  pop rcx
00007f46e3fdef6c  pop rax
00007f46e3fdef6d  add rsp, 0x08
00007f46e3fdef71  jmp 0x00007F46E3FDC31E
00007f46e3fdef76  sub rsp, 0x08
00007f46e3fdef7a  push rax
00007f46e3fdef7b  push rcx
00007f46e3fdef7c  push rdx
00007f46e3fdef7d  push rdi
00007f46e3fdef7e  push rsi
00007f46e3fdef7f  push r8
00007f46e3fdef81  push r9
00007f46e3fdef83  push r10
00007f46e3fdef85  push r11
00007f46e3fdef87  sub rsp, 0xF0
00007f46e3fdef8e  vmovaps [rsp], xmm0
00007f46e3fdef93  vmovaps [rsp+0x10], xmm1
00007f46e3fdef99  vmovaps [rsp+0x20], xmm2
00007f46e3fdef9f  vmovaps [rsp+0x30], xmm3
00007f46e3fdefa5  vmovaps [rsp+0x40], xmm4
00007f46e3fdefab  vmovaps [rsp+0x50], xmm5
00007f46e3fdefb1  vmovaps [rsp+0x60], xmm6
00007f46e3fdefb7  vmovaps [rsp+0x70], xmm7
00007f46e3fdefbd  vmovaps [rsp+0x80], xmm8
00007f46e3fdefc6  vmovaps [rsp+0x90], xmm10
00007f46e3fdefcf  vmovaps [rsp+0xA0], xmm11
00007f46e3fdefd8  vmovaps [rsp+0xB0], xmm12
00007f46e3fdefe1  vmovaps [rsp+0xC0], xmm13
00007f46e3fdefea  vmovaps [rsp+0xD0], xmm14
00007f46e3fdeff3  vmovaps [rsp+0xE0], xmm15
00007f46e3fdeffc  sub rsp, 0x30
00007f46e3fdf000  movaps [rsp], xmm9
00007f46e3fdf005  movaps [rsp+0x10], xmm2
00007f46e3fdf00a  movaps [rsp+0x20], xmm1
00007f46e3fdf00f  lea rdi, [rsp]
00007f46e3fdf013  mov esi, 0x00
00007f46e3fdf018  mov rax, 0x6238B185B530
00007f46e3fdf022  call rax
00007f46e3fdf024  movaps xmm9, [rsp]
00007f46e3fdf029  add rsp, 0x30
00007f46e3fdf02d  vmovaps xmm0, [rsp]
00007f46e3fdf032  vmovaps xmm1, [rsp+0x10]
00007f46e3fdf038  vmovaps xmm2, [rsp+0x20]
00007f46e3fdf03e  vmovaps xmm3, [rsp+0x30]
00007f46e3fdf044  vmovaps xmm4, [rsp+0x40]
00007f46e3fdf04a  vmovaps xmm5, [rsp+0x50]
00007f46e3fdf050  vmovaps xmm6, [rsp+0x60]
00007f46e3fdf056  vmovaps xmm7, [rsp+0x70]
00007f46e3fdf05c  vmovaps xmm8, [rsp+0x80]
00007f46e3fdf065  vmovaps xmm10, [rsp+0x90]
00007f46e3fdf06e  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdf077  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdf080  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdf089  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdf092  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdf09b  add rsp, 0xF0
00007f46e3fdf0a2  pop r11
00007f46e3fdf0a4  pop r10
00007f46e3fdf0a6  pop r9
00007f46e3fdf0a8  pop r8
00007f46e3fdf0aa  pop rsi
00007f46e3fdf0ab  pop rdi
00007f46e3fdf0ac  pop rdx
00007f46e3fdf0ad  pop rcx
00007f46e3fdf0ae  pop rax
00007f46e3fdf0af  add rsp, 0x08
00007f46e3fdf0b3  jmp 0x00007F46E3FDC354
00007f46e3fdf0b8  sub rsp, 0x08
00007f46e3fdf0bc  push rax
00007f46e3fdf0bd  push rcx
00007f46e3fdf0be  push rdx
00007f46e3fdf0bf  push rdi
00007f46e3fdf0c0  push rsi
00007f46e3fdf0c1  push r8
00007f46e3fdf0c3  push r9
00007f46e3fdf0c5  push r10
00007f46e3fdf0c7  push r11
00007f46e3fdf0c9  sub rsp, 0xF0
00007f46e3fdf0d0  vmovaps [rsp], xmm0
00007f46e3fdf0d5  vmovaps [rsp+0x10], xmm2
00007f46e3fdf0db  vmovaps [rsp+0x20], xmm3
00007f46e3fdf0e1  vmovaps [rsp+0x30], xmm4
00007f46e3fdf0e7  vmovaps [rsp+0x40], xmm5
00007f46e3fdf0ed  vmovaps [rsp+0x50], xmm6
00007f46e3fdf0f3  vmovaps [rsp+0x60], xmm7
00007f46e3fdf0f9  vmovaps [rsp+0x70], xmm8
00007f46e3fdf0ff  vmovaps [rsp+0x80], xmm9
00007f46e3fdf108  vmovaps [rsp+0x90], xmm10
00007f46e3fdf111  vmovaps [rsp+0xA0], xmm11
00007f46e3fdf11a  vmovaps [rsp+0xB0], xmm12
00007f46e3fdf123  vmovaps [rsp+0xC0], xmm13
00007f46e3fdf12c  vmovaps [rsp+0xD0], xmm14
00007f46e3fdf135  vmovaps [rsp+0xE0], xmm15
00007f46e3fdf13e  sub rsp, 0x30
00007f46e3fdf142  movaps [rsp], xmm1
00007f46e3fdf146  movaps [rsp+0x10], xmm15
00007f46e3fdf14c  movaps [rsp+0x20], xmm6
00007f46e3fdf151  lea rdi, [rsp]
00007f46e3fdf155  mov esi, 0x00
00007f46e3fdf15a  mov rax, 0x6238B185B530
00007f46e3fdf164  call rax
00007f46e3fdf166  movaps xmm1, [rsp]
00007f46e3fdf16a  add rsp, 0x30
00007f46e3fdf16e  vmovaps xmm0, [rsp]
00007f46e3fdf173  vmovaps xmm2, [rsp+0x10]
00007f46e3fdf179  vmovaps xmm3, [rsp+0x20]
00007f46e3fdf17f  vmovaps xmm4, [rsp+0x30]
00007f46e3fdf185  vmovaps xmm5, [rsp+0x40]
00007f46e3fdf18b  vmovaps xmm6, [rsp+0x50]
00007f46e3fdf191  vmovaps xmm7, [rsp+0x60]
00007f46e3fdf197  vmovaps xmm8, [rsp+0x70]
00007f46e3fdf19d  vmovaps xmm9, [rsp+0x80]
00007f46e3fdf1a6  vmovaps xmm10, [rsp+0x90]
00007f46e3fdf1af  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdf1b8  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdf1c1  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdf1ca  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdf1d3  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdf1dc  add rsp, 0xF0
00007f46e3fdf1e3  pop r11
00007f46e3fdf1e5  pop r10
00007f46e3fdf1e7  pop r9
00007f46e3fdf1e9  pop r8
00007f46e3fdf1eb  pop rsi
00007f46e3fdf1ec  pop rdi
00007f46e3fdf1ed  pop rdx
00007f46e3fdf1ee  pop rcx
00007f46e3fdf1ef  pop rax
00007f46e3fdf1f0  add rsp, 0x08
00007f46e3fdf1f4  jmp 0x00007F46E3FDC375
00007f46e3fdf1f9  sub rsp, 0x08
00007f46e3fdf1fd  push rax
00007f46e3fdf1fe  push rcx
00007f46e3fdf1ff  push rdx
00007f46e3fdf200  push rdi
00007f46e3fdf201  push rsi
00007f46e3fdf202  push r8
00007f46e3fdf204  push r9
00007f46e3fdf206  push r10
00007f46e3fdf208  push r11
00007f46e3fdf20a  sub rsp, 0xF0
00007f46e3fdf211  vmovaps [rsp], xmm0
00007f46e3fdf216  vmovaps [rsp+0x10], xmm1
00007f46e3fdf21c  vmovaps [rsp+0x20], xmm2
00007f46e3fdf222  vmovaps [rsp+0x30], xmm3
00007f46e3fdf228  vmovaps [rsp+0x40], xmm4
00007f46e3fdf22e  vmovaps [rsp+0x50], xmm5
00007f46e3fdf234  vmovaps [rsp+0x60], xmm6
00007f46e3fdf23a  vmovaps [rsp+0x70], xmm7
00007f46e3fdf240  vmovaps [rsp+0x80], xmm8
00007f46e3fdf249  vmovaps [rsp+0x90], xmm9
00007f46e3fdf252  vmovaps [rsp+0xA0], xmm10
00007f46e3fdf25b  vmovaps [rsp+0xB0], xmm11
00007f46e3fdf264  vmovaps [rsp+0xC0], xmm12
00007f46e3fdf26d  vmovaps [rsp+0xD0], xmm13
00007f46e3fdf276  vmovaps [rsp+0xE0], xmm14
00007f46e3fdf27f  sub rsp, 0x30
00007f46e3fdf283  movaps [rsp], xmm15
00007f46e3fdf288  movaps [rsp+0x10], xmm5
00007f46e3fdf28d  movaps [rsp+0x20], xmm3
00007f46e3fdf292  lea rdi, [rsp]
00007f46e3fdf296  mov esi, 0x00
00007f46e3fdf29b  mov rax, 0x6238B185B530
00007f46e3fdf2a5  call rax
00007f46e3fdf2a7  movaps xmm15, [rsp]
00007f46e3fdf2ac  add rsp, 0x30
00007f46e3fdf2b0  vmovaps xmm0, [rsp]
00007f46e3fdf2b5  vmovaps xmm1, [rsp+0x10]
00007f46e3fdf2bb  vmovaps xmm2, [rsp+0x20]
00007f46e3fdf2c1  vmovaps xmm3, [rsp+0x30]
00007f46e3fdf2c7  vmovaps xmm4, [rsp+0x40]
00007f46e3fdf2cd  vmovaps xmm5, [rsp+0x50]
00007f46e3fdf2d3  vmovaps xmm6, [rsp+0x60]
00007f46e3fdf2d9  vmovaps xmm7, [rsp+0x70]
00007f46e3fdf2df  vmovaps xmm8, [rsp+0x80]
00007f46e3fdf2e8  vmovaps xmm9, [rsp+0x90]
00007f46e3fdf2f1  vmovaps xmm10, [rsp+0xA0]
00007f46e3fdf2fa  vmovaps xmm11, [rsp+0xB0]
00007f46e3fdf303  vmovaps xmm12, [rsp+0xC0]
00007f46e3fdf30c  vmovaps xmm13, [rsp+0xD0]
00007f46e3fdf315  vmovaps xmm14, [rsp+0xE0]
00007f46e3fdf31e  add rsp, 0xF0
00007f46e3fdf325  pop r11
00007f46e3fdf327  pop r10
00007f46e3fdf329  pop r9
00007f46e3fdf32b  pop r8
00007f46e3fdf32d  pop rsi
00007f46e3fdf32e  pop rdi
00007f46e3fdf32f  pop rdx
00007f46e3fdf330  pop rcx
00007f46e3fdf331  pop rax
00007f46e3fdf332  add rsp, 0x08
00007f46e3fdf336  jmp 0x00007F46E3FDC38F
00007f46e3fdf33b  sub rsp, 0x08
00007f46e3fdf33f  push rax
00007f46e3fdf340  push rcx
00007f46e3fdf341  push rdx
00007f46e3fdf342  push rdi
00007f46e3fdf343  push rsi
00007f46e3fdf344  push r8
00007f46e3fdf346  push r9
00007f46e3fdf348  push r10
00007f46e3fdf34a  push r11
00007f46e3fdf34c  sub rsp, 0xF0
00007f46e3fdf353  vmovaps [rsp], xmm0
00007f46e3fdf358  vmovaps [rsp+0x10], xmm1
00007f46e3fdf35e  vmovaps [rsp+0x20], xmm2
00007f46e3fdf364  vmovaps [rsp+0x30], xmm3
00007f46e3fdf36a  vmovaps [rsp+0x40], xmm4
00007f46e3fdf370  vmovaps [rsp+0x50], xmm6
00007f46e3fdf376  vmovaps [rsp+0x60], xmm7
00007f46e3fdf37c  vmovaps [rsp+0x70], xmm8
00007f46e3fdf382  vmovaps [rsp+0x80], xmm9
00007f46e3fdf38b  vmovaps [rsp+0x90], xmm10
00007f46e3fdf394  vmovaps [rsp+0xA0], xmm11
00007f46e3fdf39d  vmovaps [rsp+0xB0], xmm12
00007f46e3fdf3a6  vmovaps [rsp+0xC0], xmm13
00007f46e3fdf3af  vmovaps [rsp+0xD0], xmm14
00007f46e3fdf3b8  vmovaps [rsp+0xE0], xmm15
00007f46e3fdf3c1  sub rsp, 0x30
00007f46e3fdf3c5  movaps [rsp], xmm5
00007f46e3fdf3c9  movaps [rsp+0x10], xmm8
00007f46e3fdf3cf  movaps [rsp+0x20], xmm6
00007f46e3fdf3d4  lea rdi, [rsp]
00007f46e3fdf3d8  mov esi, 0x00
00007f46e3fdf3dd  mov rax, 0x6238B185B530
00007f46e3fdf3e7  call rax
00007f46e3fdf3e9  movaps xmm5, [rsp]
00007f46e3fdf3ed  add rsp, 0x30
00007f46e3fdf3f1  vmovaps xmm0, [rsp]
00007f46e3fdf3f6  vmovaps xmm1, [rsp+0x10]
00007f46e3fdf3fc  vmovaps xmm2, [rsp+0x20]
00007f46e3fdf402  vmovaps xmm3, [rsp+0x30]
00007f46e3fdf408  vmovaps xmm4, [rsp+0x40]
00007f46e3fdf40e  vmovaps xmm6, [rsp+0x50]
00007f46e3fdf414  vmovaps xmm7, [rsp+0x60]
00007f46e3fdf41a  vmovaps xmm8, [rsp+0x70]
00007f46e3fdf420  vmovaps xmm9, [rsp+0x80]
00007f46e3fdf429  vmovaps xmm10, [rsp+0x90]
00007f46e3fdf432  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdf43b  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdf444  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdf44d  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdf456  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdf45f  add rsp, 0xF0
00007f46e3fdf466  pop r11
00007f46e3fdf468  pop r10
00007f46e3fdf46a  pop r9
00007f46e3fdf46c  pop r8
00007f46e3fdf46e  pop rsi
00007f46e3fdf46f  pop rdi
00007f46e3fdf470  pop rdx
00007f46e3fdf471  pop rcx
00007f46e3fdf472  pop rax
00007f46e3fdf473  add rsp, 0x08
00007f46e3fdf477  jmp 0x00007F46E3FDC3B3
00007f46e3fdf47c  sub rsp, 0x08
00007f46e3fdf480  push rax
00007f46e3fdf481  push rcx
00007f46e3fdf482  push rdx
00007f46e3fdf483  push rdi
00007f46e3fdf484  push rsi
00007f46e3fdf485  push r8
00007f46e3fdf487  push r9
00007f46e3fdf489  push r10
00007f46e3fdf48b  push r11
00007f46e3fdf48d  sub rsp, 0xF0
00007f46e3fdf494  vmovaps [rsp], xmm0
00007f46e3fdf499  vmovaps [rsp+0x10], xmm1
00007f46e3fdf49f  vmovaps [rsp+0x20], xmm2
00007f46e3fdf4a5  vmovaps [rsp+0x30], xmm3
00007f46e3fdf4ab  vmovaps [rsp+0x40], xmm4
00007f46e3fdf4b1  vmovaps [rsp+0x50], xmm5
00007f46e3fdf4b7  vmovaps [rsp+0x60], xmm7
00007f46e3fdf4bd  vmovaps [rsp+0x70], xmm8
00007f46e3fdf4c3  vmovaps [rsp+0x80], xmm9
00007f46e3fdf4cc  vmovaps [rsp+0x90], xmm10
00007f46e3fdf4d5  vmovaps [rsp+0xA0], xmm11
00007f46e3fdf4de  vmovaps [rsp+0xB0], xmm12
00007f46e3fdf4e7  vmovaps [rsp+0xC0], xmm13
00007f46e3fdf4f0  vmovaps [rsp+0xD0], xmm14
00007f46e3fdf4f9  vmovaps [rsp+0xE0], xmm15
00007f46e3fdf502  sub rsp, 0x30
00007f46e3fdf506  movaps [rsp], xmm6
00007f46e3fdf50a  movaps [rsp+0x10], xmm10
00007f46e3fdf510  movaps [rsp+0x20], xmm8
00007f46e3fdf516  lea rdi, [rsp]
00007f46e3fdf51a  mov esi, 0x00
00007f46e3fdf51f  mov rax, 0x6238B185B530
00007f46e3fdf529  call rax
00007f46e3fdf52b  movaps xmm6, [rsp]
00007f46e3fdf52f  add rsp, 0x30
00007f46e3fdf533  vmovaps xmm0, [rsp]
00007f46e3fdf538  vmovaps xmm1, [rsp+0x10]
00007f46e3fdf53e  vmovaps xmm2, [rsp+0x20]
00007f46e3fdf544  vmovaps xmm3, [rsp+0x30]
00007f46e3fdf54a  vmovaps xmm4, [rsp+0x40]
00007f46e3fdf550  vmovaps xmm5, [rsp+0x50]
00007f46e3fdf556  vmovaps xmm7, [rsp+0x60]
00007f46e3fdf55c  vmovaps xmm8, [rsp+0x70]
00007f46e3fdf562  vmovaps xmm9, [rsp+0x80]
00007f46e3fdf56b  vmovaps xmm10, [rsp+0x90]
00007f46e3fdf574  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdf57d  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdf586  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdf58f  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdf598  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdf5a1  add rsp, 0xF0
00007f46e3fdf5a8  pop r11
00007f46e3fdf5aa  pop r10
00007f46e3fdf5ac  pop r9
00007f46e3fdf5ae  pop r8
00007f46e3fdf5b0  pop rsi
00007f46e3fdf5b1  pop rdi
00007f46e3fdf5b2  pop rdx
00007f46e3fdf5b3  pop rcx
00007f46e3fdf5b4  pop rax
00007f46e3fdf5b5  add rsp, 0x08
00007f46e3fdf5b9  jmp 0x00007F46E3FDC3D8
00007f46e3fdf5be  sub rsp, 0x08
00007f46e3fdf5c2  push rax
00007f46e3fdf5c3  push rcx
00007f46e3fdf5c4  push rdx
00007f46e3fdf5c5  push rdi
00007f46e3fdf5c6  push rsi
00007f46e3fdf5c7  push r8
00007f46e3fdf5c9  push r9
00007f46e3fdf5cb  push r10
00007f46e3fdf5cd  push r11
00007f46e3fdf5cf  sub rsp, 0xF0
00007f46e3fdf5d6  vmovaps [rsp], xmm0
00007f46e3fdf5db  vmovaps [rsp+0x10], xmm1
00007f46e3fdf5e1  vmovaps [rsp+0x20], xmm2
00007f46e3fdf5e7  vmovaps [rsp+0x30], xmm3
00007f46e3fdf5ed  vmovaps [rsp+0x40], xmm4
00007f46e3fdf5f3  vmovaps [rsp+0x50], xmm5
00007f46e3fdf5f9  vmovaps [rsp+0x60], xmm6
00007f46e3fdf5ff  vmovaps [rsp+0x70], xmm7
00007f46e3fdf605  vmovaps [rsp+0x80], xmm8
00007f46e3fdf60e  vmovaps [rsp+0x90], xmm9
00007f46e3fdf617  vmovaps [rsp+0xA0], xmm11
00007f46e3fdf620  vmovaps [rsp+0xB0], xmm12
00007f46e3fdf629  vmovaps [rsp+0xC0], xmm13
00007f46e3fdf632  vmovaps [rsp+0xD0], xmm14
00007f46e3fdf63b  vmovaps [rsp+0xE0], xmm15
00007f46e3fdf644  sub rsp, 0x30
00007f46e3fdf648  movaps [rsp], xmm10
00007f46e3fdf64d  movaps [rsp+0x10], xmm8
00007f46e3fdf653  movaps [rsp+0x20], xmm14
00007f46e3fdf659  lea rdi, [rsp]
00007f46e3fdf65d  mov esi, 0x00
00007f46e3fdf662  mov rax, 0x6238B185B530
00007f46e3fdf66c  call rax
00007f46e3fdf66e  movaps xmm10, [rsp]
00007f46e3fdf673  add rsp, 0x30
00007f46e3fdf677  vmovaps xmm0, [rsp]
00007f46e3fdf67c  vmovaps xmm1, [rsp+0x10]
00007f46e3fdf682  vmovaps xmm2, [rsp+0x20]
00007f46e3fdf688  vmovaps xmm3, [rsp+0x30]
00007f46e3fdf68e  vmovaps xmm4, [rsp+0x40]
00007f46e3fdf694  vmovaps xmm5, [rsp+0x50]
00007f46e3fdf69a  vmovaps xmm6, [rsp+0x60]
00007f46e3fdf6a0  vmovaps xmm7, [rsp+0x70]
00007f46e3fdf6a6  vmovaps xmm8, [rsp+0x80]
00007f46e3fdf6af  vmovaps xmm9, [rsp+0x90]
00007f46e3fdf6b8  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdf6c1  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdf6ca  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdf6d3  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdf6dc  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdf6e5  add rsp, 0xF0
00007f46e3fdf6ec  pop r11
00007f46e3fdf6ee  pop r10
00007f46e3fdf6f0  pop r9
00007f46e3fdf6f2  pop r8
00007f46e3fdf6f4  pop rsi
00007f46e3fdf6f5  pop rdi
00007f46e3fdf6f6  pop rdx
00007f46e3fdf6f7  pop rcx
00007f46e3fdf6f8  pop rax
00007f46e3fdf6f9  add rsp, 0x08
00007f46e3fdf6fd  jmp 0x00007F46E3FDC3F8
00007f46e3fdf702  sub rsp, 0x08
00007f46e3fdf706  push rax
00007f46e3fdf707  push rcx
00007f46e3fdf708  push rdx
00007f46e3fdf709  push rdi
00007f46e3fdf70a  push rsi
00007f46e3fdf70b  push r8
00007f46e3fdf70d  push r9
00007f46e3fdf70f  push r10
00007f46e3fdf711  push r11
00007f46e3fdf713  sub rsp, 0xF0
00007f46e3fdf71a  vmovaps [rsp], xmm0
00007f46e3fdf71f  vmovaps [rsp+0x10], xmm1
00007f46e3fdf725  vmovaps [rsp+0x20], xmm2
00007f46e3fdf72b  vmovaps [rsp+0x30], xmm3
00007f46e3fdf731  vmovaps [rsp+0x40], xmm4
00007f46e3fdf737  vmovaps [rsp+0x50], xmm5
00007f46e3fdf73d  vmovaps [rsp+0x60], xmm6
00007f46e3fdf743  vmovaps [rsp+0x70], xmm7
00007f46e3fdf749  vmovaps [rsp+0x80], xmm8
00007f46e3fdf752  vmovaps [rsp+0x90], xmm9
00007f46e3fdf75b  vmovaps [rsp+0xA0], xmm10
00007f46e3fdf764  vmovaps [rsp+0xB0], xmm11
00007f46e3fdf76d  vmovaps [rsp+0xC0], xmm12
00007f46e3fdf776  vmovaps [rsp+0xD0], xmm13
00007f46e3fdf77f  vmovaps [rsp+0xE0], xmm15
00007f46e3fdf788  sub rsp, 0x30
00007f46e3fdf78c  movaps [rsp], xmm14
00007f46e3fdf791  movaps [rsp+0x10], xmm8
00007f46e3fdf797  movaps [rsp+0x20], xmm4
00007f46e3fdf79c  lea rdi, [rsp]
00007f46e3fdf7a0  mov esi, 0x00
00007f46e3fdf7a5  mov rax, 0x6238B185B530
00007f46e3fdf7af  call rax
00007f46e3fdf7b1  movaps xmm14, [rsp]
00007f46e3fdf7b6  add rsp, 0x30
00007f46e3fdf7ba  vmovaps xmm0, [rsp]
00007f46e3fdf7bf  vmovaps xmm1, [rsp+0x10]
00007f46e3fdf7c5  vmovaps xmm2, [rsp+0x20]
00007f46e3fdf7cb  vmovaps xmm3, [rsp+0x30]
00007f46e3fdf7d1  vmovaps xmm4, [rsp+0x40]
00007f46e3fdf7d7  vmovaps xmm5, [rsp+0x50]
00007f46e3fdf7dd  vmovaps xmm6, [rsp+0x60]
00007f46e3fdf7e3  vmovaps xmm7, [rsp+0x70]
00007f46e3fdf7e9  vmovaps xmm8, [rsp+0x80]
00007f46e3fdf7f2  vmovaps xmm9, [rsp+0x90]
00007f46e3fdf7fb  vmovaps xmm10, [rsp+0xA0]
00007f46e3fdf804  vmovaps xmm11, [rsp+0xB0]
00007f46e3fdf80d  vmovaps xmm12, [rsp+0xC0]
00007f46e3fdf816  vmovaps xmm13, [rsp+0xD0]
00007f46e3fdf81f  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdf828  add rsp, 0xF0
00007f46e3fdf82f  pop r11
00007f46e3fdf831  pop r10
00007f46e3fdf833  pop r9
00007f46e3fdf835  pop r8
00007f46e3fdf837  pop rsi
00007f46e3fdf838  pop rdi
00007f46e3fdf839  pop rdx
00007f46e3fdf83a  pop rcx
00007f46e3fdf83b  pop rax
00007f46e3fdf83c  add rsp, 0x08
00007f46e3fdf840  jmp 0x00007F46E3FDC418
00007f46e3fdf845  sub rsp, 0x08
00007f46e3fdf849  push rax
00007f46e3fdf84a  push rcx
00007f46e3fdf84b  push rdx
00007f46e3fdf84c  push rdi
00007f46e3fdf84d  push rsi
00007f46e3fdf84e  push r8
00007f46e3fdf850  push r9
00007f46e3fdf852  push r10
00007f46e3fdf854  push r11
00007f46e3fdf856  sub rsp, 0xF0
00007f46e3fdf85d  vmovaps [rsp], xmm0
00007f46e3fdf862  vmovaps [rsp+0x10], xmm1
00007f46e3fdf868  vmovaps [rsp+0x20], xmm2
00007f46e3fdf86e  vmovaps [rsp+0x30], xmm3
00007f46e3fdf874  vmovaps [rsp+0x40], xmm5
00007f46e3fdf87a  vmovaps [rsp+0x50], xmm6
00007f46e3fdf880  vmovaps [rsp+0x60], xmm7
00007f46e3fdf886  vmovaps [rsp+0x70], xmm8
00007f46e3fdf88c  vmovaps [rsp+0x80], xmm9
00007f46e3fdf895  vmovaps [rsp+0x90], xmm10
00007f46e3fdf89e  vmovaps [rsp+0xA0], xmm11
00007f46e3fdf8a7  vmovaps [rsp+0xB0], xmm12
00007f46e3fdf8b0  vmovaps [rsp+0xC0], xmm13
00007f46e3fdf8b9  vmovaps [rsp+0xD0], xmm14
00007f46e3fdf8c2  vmovaps [rsp+0xE0], xmm15
00007f46e3fdf8cb  sub rsp, 0x30
00007f46e3fdf8cf  movaps [rsp], xmm4
00007f46e3fdf8d3  movaps [rsp+0x10], xmm13
00007f46e3fdf8d9  movaps [rsp+0x20], xmm8
00007f46e3fdf8df  lea rdi, [rsp]
00007f46e3fdf8e3  mov esi, 0x00
00007f46e3fdf8e8  mov rax, 0x6238B185B530
00007f46e3fdf8f2  call rax
00007f46e3fdf8f4  movaps xmm4, [rsp]
00007f46e3fdf8f8  add rsp, 0x30
00007f46e3fdf8fc  vmovaps xmm0, [rsp]
00007f46e3fdf901  vmovaps xmm1, [rsp+0x10]
00007f46e3fdf907  vmovaps xmm2, [rsp+0x20]
00007f46e3fdf90d  vmovaps xmm3, [rsp+0x30]
00007f46e3fdf913  vmovaps xmm5, [rsp+0x40]
00007f46e3fdf919  vmovaps xmm6, [rsp+0x50]
00007f46e3fdf91f  vmovaps xmm7, [rsp+0x60]
00007f46e3fdf925  vmovaps xmm8, [rsp+0x70]
00007f46e3fdf92b  vmovaps xmm9, [rsp+0x80]
00007f46e3fdf934  vmovaps xmm10, [rsp+0x90]
00007f46e3fdf93d  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdf946  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdf94f  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdf958  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdf961  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdf96a  add rsp, 0xF0
00007f46e3fdf971  pop r11
00007f46e3fdf973  pop r10
00007f46e3fdf975  pop r9
00007f46e3fdf977  pop r8
00007f46e3fdf979  pop rsi
00007f46e3fdf97a  pop rdi
00007f46e3fdf97b  pop rdx
00007f46e3fdf97c  pop rcx
00007f46e3fdf97d  pop rax
00007f46e3fdf97e  add rsp, 0x08
00007f46e3fdf982  jmp 0x00007F46E3FDC43D
00007f46e3fdf987  sub rsp, 0x08
00007f46e3fdf98b  push rax
00007f46e3fdf98c  push rcx
00007f46e3fdf98d  push rdx
00007f46e3fdf98e  push rdi
00007f46e3fdf98f  push rsi
00007f46e3fdf990  push r8
00007f46e3fdf992  push r9
00007f46e3fdf994  push r10
00007f46e3fdf996  push r11
00007f46e3fdf998  sub rsp, 0xF0
00007f46e3fdf99f  vmovaps [rsp], xmm0
00007f46e3fdf9a4  vmovaps [rsp+0x10], xmm1
00007f46e3fdf9aa  vmovaps [rsp+0x20], xmm2
00007f46e3fdf9b0  vmovaps [rsp+0x30], xmm3
00007f46e3fdf9b6  vmovaps [rsp+0x40], xmm4
00007f46e3fdf9bc  vmovaps [rsp+0x50], xmm5
00007f46e3fdf9c2  vmovaps [rsp+0x60], xmm6
00007f46e3fdf9c8  vmovaps [rsp+0x70], xmm7
00007f46e3fdf9ce  vmovaps [rsp+0x80], xmm8
00007f46e3fdf9d7  vmovaps [rsp+0x90], xmm9
00007f46e3fdf9e0  vmovaps [rsp+0xA0], xmm10
00007f46e3fdf9e9  vmovaps [rsp+0xB0], xmm11
00007f46e3fdf9f2  vmovaps [rsp+0xC0], xmm12
00007f46e3fdf9fb  vmovaps [rsp+0xD0], xmm14
00007f46e3fdfa04  vmovaps [rsp+0xE0], xmm15
00007f46e3fdfa0d  sub rsp, 0x30
00007f46e3fdfa11  movaps [rsp], xmm13
00007f46e3fdfa16  movaps [rsp+0x10], xmm15
00007f46e3fdfa1c  movaps [rsp+0x20], xmm9
00007f46e3fdfa22  lea rdi, [rsp]
00007f46e3fdfa26  mov esi, 0x00
00007f46e3fdfa2b  mov rax, 0x6238B185B530
00007f46e3fdfa35  call rax
00007f46e3fdfa37  movaps xmm13, [rsp]
00007f46e3fdfa3c  add rsp, 0x30
00007f46e3fdfa40  vmovaps xmm0, [rsp]
00007f46e3fdfa45  vmovaps xmm1, [rsp+0x10]
00007f46e3fdfa4b  vmovaps xmm2, [rsp+0x20]
00007f46e3fdfa51  vmovaps xmm3, [rsp+0x30]
00007f46e3fdfa57  vmovaps xmm4, [rsp+0x40]
00007f46e3fdfa5d  vmovaps xmm5, [rsp+0x50]
00007f46e3fdfa63  vmovaps xmm6, [rsp+0x60]
00007f46e3fdfa69  vmovaps xmm7, [rsp+0x70]
00007f46e3fdfa6f  vmovaps xmm8, [rsp+0x80]
00007f46e3fdfa78  vmovaps xmm9, [rsp+0x90]
00007f46e3fdfa81  vmovaps xmm10, [rsp+0xA0]
00007f46e3fdfa8a  vmovaps xmm11, [rsp+0xB0]
00007f46e3fdfa93  vmovaps xmm12, [rsp+0xC0]
00007f46e3fdfa9c  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdfaa5  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdfaae  add rsp, 0xF0
00007f46e3fdfab5  pop r11
00007f46e3fdfab7  pop r10
00007f46e3fdfab9  pop r9
00007f46e3fdfabb  pop r8
00007f46e3fdfabd  pop rsi
00007f46e3fdfabe  pop rdi
00007f46e3fdfabf  pop rdx
00007f46e3fdfac0  pop rcx
00007f46e3fdfac1  pop rax
00007f46e3fdfac2  add rsp, 0x08
00007f46e3fdfac6  jmp 0x00007F46E3FDC458
00007f46e3fdfacb  sub rsp, 0x08
00007f46e3fdfacf  push rax
00007f46e3fdfad0  push rcx
00007f46e3fdfad1  push rdx
00007f46e3fdfad2  push rdi
00007f46e3fdfad3  push rsi
00007f46e3fdfad4  push r8
00007f46e3fdfad6  push r9
00007f46e3fdfad8  push r10
00007f46e3fdfada  push r11
00007f46e3fdfadc  sub rsp, 0xF0
00007f46e3fdfae3  vmovaps [rsp], xmm0
00007f46e3fdfae8  vmovaps [rsp+0x10], xmm1
00007f46e3fdfaee  vmovaps [rsp+0x20], xmm2
00007f46e3fdfaf4  vmovaps [rsp+0x30], xmm3
00007f46e3fdfafa  vmovaps [rsp+0x40], xmm4
00007f46e3fdfb00  vmovaps [rsp+0x50], xmm5
00007f46e3fdfb06  vmovaps [rsp+0x60], xmm6
00007f46e3fdfb0c  vmovaps [rsp+0x70], xmm7
00007f46e3fdfb12  vmovaps [rsp+0x80], xmm8
00007f46e3fdfb1b  vmovaps [rsp+0x90], xmm9
00007f46e3fdfb24  vmovaps [rsp+0xA0], xmm10
00007f46e3fdfb2d  vmovaps [rsp+0xB0], xmm11
00007f46e3fdfb36  vmovaps [rsp+0xC0], xmm12
00007f46e3fdfb3f  vmovaps [rsp+0xD0], xmm13
00007f46e3fdfb48  vmovaps [rsp+0xE0], xmm14
00007f46e3fdfb51  sub rsp, 0x30
00007f46e3fdfb55  movaps [rsp], xmm15
00007f46e3fdfb5a  movaps [rsp+0x10], xmm1
00007f46e3fdfb5f  movaps [rsp+0x20], xmm5
00007f46e3fdfb64  lea rdi, [rsp]
00007f46e3fdfb68  mov esi, 0x00
00007f46e3fdfb6d  mov rax, 0x6238B185B530
00007f46e3fdfb77  call rax
00007f46e3fdfb79  movaps xmm15, [rsp]
00007f46e3fdfb7e  add rsp, 0x30
00007f46e3fdfb82  vmovaps xmm0, [rsp]
00007f46e3fdfb87  vmovaps xmm1, [rsp+0x10]
00007f46e3fdfb8d  vmovaps xmm2, [rsp+0x20]
00007f46e3fdfb93  vmovaps xmm3, [rsp+0x30]
00007f46e3fdfb99  vmovaps xmm4, [rsp+0x40]
00007f46e3fdfb9f  vmovaps xmm5, [rsp+0x50]
00007f46e3fdfba5  vmovaps xmm6, [rsp+0x60]
00007f46e3fdfbab  vmovaps xmm7, [rsp+0x70]
00007f46e3fdfbb1  vmovaps xmm8, [rsp+0x80]
00007f46e3fdfbba  vmovaps xmm9, [rsp+0x90]
00007f46e3fdfbc3  vmovaps xmm10, [rsp+0xA0]
00007f46e3fdfbcc  vmovaps xmm11, [rsp+0xB0]
00007f46e3fdfbd5  vmovaps xmm12, [rsp+0xC0]
00007f46e3fdfbde  vmovaps xmm13, [rsp+0xD0]
00007f46e3fdfbe7  vmovaps xmm14, [rsp+0xE0]
00007f46e3fdfbf0  add rsp, 0xF0
00007f46e3fdfbf7  pop r11
00007f46e3fdfbf9  pop r10
00007f46e3fdfbfb  pop r9
00007f46e3fdfbfd  pop r8
00007f46e3fdfbff  pop rsi
00007f46e3fdfc00  pop rdi
00007f46e3fdfc01  pop rdx
00007f46e3fdfc02  pop rcx
00007f46e3fdfc03  pop rax
00007f46e3fdfc04  add rsp, 0x08
00007f46e3fdfc08  jmp 0x00007F46E3FDC473
00007f46e3fdfc0d  call 0x00007F46E3EB52F0
00007f46e3fdfc12  jmp 0x00007F46E3FDC4CE
00007f46e3fdfc17  sub rsp, 0x08
00007f46e3fdfc1b  push rax
00007f46e3fdfc1c  push rcx
00007f46e3fdfc1d  push rdx
00007f46e3fdfc1e  push rdi
00007f46e3fdfc1f  push rsi
00007f46e3fdfc20  push r8
00007f46e3fdfc22  push r9
00007f46e3fdfc24  push r10
00007f46e3fdfc26  push r11
00007f46e3fdfc28  sub rsp, 0xF0
00007f46e3fdfc2f  vmovaps [rsp], xmm0
00007f46e3fdfc34  vmovaps [rsp+0x10], xmm1
00007f46e3fdfc3a  vmovaps [rsp+0x20], xmm2
00007f46e3fdfc40  vmovaps [rsp+0x30], xmm3
00007f46e3fdfc46  vmovaps [rsp+0x40], xmm4
00007f46e3fdfc4c  vmovaps [rsp+0x50], xmm5
00007f46e3fdfc52  vmovaps [rsp+0x60], xmm6
00007f46e3fdfc58  vmovaps [rsp+0x70], xmm7
00007f46e3fdfc5e  vmovaps [rsp+0x80], xmm8
00007f46e3fdfc67  vmovaps [rsp+0x90], xmm10
00007f46e3fdfc70  vmovaps [rsp+0xA0], xmm11
00007f46e3fdfc79  vmovaps [rsp+0xB0], xmm12
00007f46e3fdfc82  vmovaps [rsp+0xC0], xmm13
00007f46e3fdfc8b  vmovaps [rsp+0xD0], xmm14
00007f46e3fdfc94  vmovaps [rsp+0xE0], xmm15
00007f46e3fdfc9d  sub rsp, 0x30
00007f46e3fdfca1  movaps [rsp], xmm9
00007f46e3fdfca6  movaps [rsp+0x10], xmm8
00007f46e3fdfcac  movaps [rsp+0x20], xmm11
00007f46e3fdfcb2  lea rdi, [rsp]
00007f46e3fdfcb6  mov esi, 0x00
00007f46e3fdfcbb  mov rax, 0x6238B185B530
00007f46e3fdfcc5  call rax
00007f46e3fdfcc7  movaps xmm9, [rsp]
00007f46e3fdfccc  add rsp, 0x30
00007f46e3fdfcd0  vmovaps xmm0, [rsp]
00007f46e3fdfcd5  vmovaps xmm1, [rsp+0x10]
00007f46e3fdfcdb  vmovaps xmm2, [rsp+0x20]
00007f46e3fdfce1  vmovaps xmm3, [rsp+0x30]
00007f46e3fdfce7  vmovaps xmm4, [rsp+0x40]
00007f46e3fdfced  vmovaps xmm5, [rsp+0x50]
00007f46e3fdfcf3  vmovaps xmm6, [rsp+0x60]
00007f46e3fdfcf9  vmovaps xmm7, [rsp+0x70]
00007f46e3fdfcff  vmovaps xmm8, [rsp+0x80]
00007f46e3fdfd08  vmovaps xmm10, [rsp+0x90]
00007f46e3fdfd11  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdfd1a  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdfd23  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdfd2c  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdfd35  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdfd3e  add rsp, 0xF0
00007f46e3fdfd45  pop r11
00007f46e3fdfd47  pop r10
00007f46e3fdfd49  pop r9
00007f46e3fdfd4b  pop r8
00007f46e3fdfd4d  pop rsi
00007f46e3fdfd4e  pop rdi
00007f46e3fdfd4f  pop rdx
00007f46e3fdfd50  pop rcx
00007f46e3fdfd51  pop rax
00007f46e3fdfd52  add rsp, 0x08
00007f46e3fdfd56  jmp 0x00007F46E3FDC505
00007f46e3fdfd5b  sub rsp, 0x08
00007f46e3fdfd5f  push rax
00007f46e3fdfd60  push rcx
00007f46e3fdfd61  push rdx
00007f46e3fdfd62  push rdi
00007f46e3fdfd63  push rsi
00007f46e3fdfd64  push r8
00007f46e3fdfd66  push r9
00007f46e3fdfd68  push r10
00007f46e3fdfd6a  push r11
00007f46e3fdfd6c  sub rsp, 0xF0
00007f46e3fdfd73  vmovaps [rsp], xmm0
00007f46e3fdfd78  vmovaps [rsp+0x10], xmm1
00007f46e3fdfd7e  vmovaps [rsp+0x20], xmm2
00007f46e3fdfd84  vmovaps [rsp+0x30], xmm3
00007f46e3fdfd8a  vmovaps [rsp+0x40], xmm4
00007f46e3fdfd90  vmovaps [rsp+0x50], xmm5
00007f46e3fdfd96  vmovaps [rsp+0x60], xmm6
00007f46e3fdfd9c  vmovaps [rsp+0x70], xmm7
00007f46e3fdfda2  vmovaps [rsp+0x80], xmm8
00007f46e3fdfdab  vmovaps [rsp+0x90], xmm9
00007f46e3fdfdb4  vmovaps [rsp+0xA0], xmm10
00007f46e3fdfdbd  vmovaps [rsp+0xB0], xmm12
00007f46e3fdfdc6  vmovaps [rsp+0xC0], xmm13
00007f46e3fdfdcf  vmovaps [rsp+0xD0], xmm14
00007f46e3fdfdd8  vmovaps [rsp+0xE0], xmm15
00007f46e3fdfde1  sub rsp, 0x30
00007f46e3fdfde5  movaps [rsp], xmm11
00007f46e3fdfdea  movaps [rsp+0x10], xmm10
00007f46e3fdfdf0  movaps [rsp+0x20], xmm6
00007f46e3fdfdf5  lea rdi, [rsp]
00007f46e3fdfdf9  mov esi, 0x00
00007f46e3fdfdfe  mov rax, 0x6238B185B530
00007f46e3fdfe08  call rax
00007f46e3fdfe0a  movaps xmm11, [rsp]
00007f46e3fdfe0f  add rsp, 0x30
00007f46e3fdfe13  vmovaps xmm0, [rsp]
00007f46e3fdfe18  vmovaps xmm1, [rsp+0x10]
00007f46e3fdfe1e  vmovaps xmm2, [rsp+0x20]
00007f46e3fdfe24  vmovaps xmm3, [rsp+0x30]
00007f46e3fdfe2a  vmovaps xmm4, [rsp+0x40]
00007f46e3fdfe30  vmovaps xmm5, [rsp+0x50]
00007f46e3fdfe36  vmovaps xmm6, [rsp+0x60]
00007f46e3fdfe3c  vmovaps xmm7, [rsp+0x70]
00007f46e3fdfe42  vmovaps xmm8, [rsp+0x80]
00007f46e3fdfe4b  vmovaps xmm9, [rsp+0x90]
00007f46e3fdfe54  vmovaps xmm10, [rsp+0xA0]
00007f46e3fdfe5d  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdfe66  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdfe6f  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdfe78  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdfe81  add rsp, 0xF0
00007f46e3fdfe88  pop r11
00007f46e3fdfe8a  pop r10
00007f46e3fdfe8c  pop r9
00007f46e3fdfe8e  pop r8
00007f46e3fdfe90  pop rsi
00007f46e3fdfe91  pop rdi
00007f46e3fdfe92  pop rdx
00007f46e3fdfe93  pop rcx
00007f46e3fdfe94  pop rax
00007f46e3fdfe95  add rsp, 0x08
00007f46e3fdfe99  jmp 0x00007F46E3FDC520
00007f46e3fdfe9e  sub rsp, 0x08
00007f46e3fdfea2  push rax
00007f46e3fdfea3  push rcx
00007f46e3fdfea4  push rdx
00007f46e3fdfea5  push rdi
00007f46e3fdfea6  push rsi
00007f46e3fdfea7  push r8
00007f46e3fdfea9  push r9
00007f46e3fdfeab  push r10
00007f46e3fdfead  push r11
00007f46e3fdfeaf  sub rsp, 0xF0
00007f46e3fdfeb6  vmovaps [rsp], xmm0
00007f46e3fdfebb  vmovaps [rsp+0x10], xmm1
00007f46e3fdfec1  vmovaps [rsp+0x20], xmm2
00007f46e3fdfec7  vmovaps [rsp+0x30], xmm3
00007f46e3fdfecd  vmovaps [rsp+0x40], xmm4
00007f46e3fdfed3  vmovaps [rsp+0x50], xmm5
00007f46e3fdfed9  vmovaps [rsp+0x60], xmm6
00007f46e3fdfedf  vmovaps [rsp+0x70], xmm7
00007f46e3fdfee5  vmovaps [rsp+0x80], xmm8
00007f46e3fdfeee  vmovaps [rsp+0x90], xmm9
00007f46e3fdfef7  vmovaps [rsp+0xA0], xmm11
00007f46e3fdff00  vmovaps [rsp+0xB0], xmm12
00007f46e3fdff09  vmovaps [rsp+0xC0], xmm13
00007f46e3fdff12  vmovaps [rsp+0xD0], xmm14
00007f46e3fdff1b  vmovaps [rsp+0xE0], xmm15
00007f46e3fdff24  sub rsp, 0x30
00007f46e3fdff28  movaps [rsp], xmm10
00007f46e3fdff2d  movaps [rsp+0x10], xmm14
00007f46e3fdff33  movaps [rsp+0x20], xmm4
00007f46e3fdff38  lea rdi, [rsp]
00007f46e3fdff3c  mov esi, 0x00
00007f46e3fdff41  mov rax, 0x6238B185B530
00007f46e3fdff4b  call rax
00007f46e3fdff4d  movaps xmm10, [rsp]
00007f46e3fdff52  add rsp, 0x30
00007f46e3fdff56  vmovaps xmm0, [rsp]
00007f46e3fdff5b  vmovaps xmm1, [rsp+0x10]
00007f46e3fdff61  vmovaps xmm2, [rsp+0x20]
00007f46e3fdff67  vmovaps xmm3, [rsp+0x30]
00007f46e3fdff6d  vmovaps xmm4, [rsp+0x40]
00007f46e3fdff73  vmovaps xmm5, [rsp+0x50]
00007f46e3fdff79  vmovaps xmm6, [rsp+0x60]
00007f46e3fdff7f  vmovaps xmm7, [rsp+0x70]
00007f46e3fdff85  vmovaps xmm8, [rsp+0x80]
00007f46e3fdff8e  vmovaps xmm9, [rsp+0x90]
00007f46e3fdff97  vmovaps xmm11, [rsp+0xA0]
00007f46e3fdffa0  vmovaps xmm12, [rsp+0xB0]
00007f46e3fdffa9  vmovaps xmm13, [rsp+0xC0]
00007f46e3fdffb2  vmovaps xmm14, [rsp+0xD0]
00007f46e3fdffbb  vmovaps xmm15, [rsp+0xE0]
00007f46e3fdffc4  add rsp, 0xF0
00007f46e3fdffcb  pop r11
00007f46e3fdffcd  pop r10
00007f46e3fdffcf  pop r9
00007f46e3fdffd1  pop r8
00007f46e3fdffd3  pop rsi
00007f46e3fdffd4  pop rdi
00007f46e3fdffd5  pop rdx
00007f46e3fdffd6  pop rcx
00007f46e3fdffd7  pop rax
00007f46e3fdffd8  add rsp, 0x08
00007f46e3fdffdc  jmp 0x00007F46E3FDC53B
00007f46e3fdffe1  sub rsp, 0x08
00007f46e3fdffe5  push rax
00007f46e3fdffe6  push rcx
00007f46e3fdffe7  push rdx
00007f46e3fdffe8  push rdi
00007f46e3fdffe9  push rsi
00007f46e3fdffea  push r8
00007f46e3fdffec  push r9
00007f46e3fdffee  push r10
00007f46e3fdfff0  push r11
00007f46e3fdfff2  sub rsp, 0xF0
00007f46e3fdfff9  vmovaps [rsp], xmm0
00007f46e3fdfffe  vmovaps [rsp+0x10], xmm1
00007f46e3fe0004  vmovaps [rsp+0x20], xmm2
00007f46e3fe000a  vmovaps [rsp+0x30], xmm3
00007f46e3fe0010  vmovaps [rsp+0x40], xmm4
00007f46e3fe0016  vmovaps [rsp+0x50], xmm5
00007f46e3fe001c  vmovaps [rsp+0x60], xmm6
00007f46e3fe0022  vmovaps [rsp+0x70], xmm7
00007f46e3fe0028  vmovaps [rsp+0x80], xmm9
00007f46e3fe0031  vmovaps [rsp+0x90], xmm10
00007f46e3fe003a  vmovaps [rsp+0xA0], xmm11
00007f46e3fe0043  vmovaps [rsp+0xB0], xmm12
00007f46e3fe004c  vmovaps [rsp+0xC0], xmm13
00007f46e3fe0055  vmovaps [rsp+0xD0], xmm14
00007f46e3fe005e  vmovaps [rsp+0xE0], xmm15
00007f46e3fe0067  sub rsp, 0x30
00007f46e3fe006b  movaps [rsp], xmm8
00007f46e3fe0070  movaps [rsp+0x10], xmm1
00007f46e3fe0075  movaps [rsp+0x20], xmm14
00007f46e3fe007b  lea rdi, [rsp]
00007f46e3fe007f  mov esi, 0x00
00007f46e3fe0084  mov rax, 0x6238B185B530
00007f46e3fe008e  call rax
00007f46e3fe0090  movaps xmm8, [rsp]
00007f46e3fe0095  add rsp, 0x30
00007f46e3fe0099  vmovaps xmm0, [rsp]
00007f46e3fe009e  vmovaps xmm1, [rsp+0x10]
00007f46e3fe00a4  vmovaps xmm2, [rsp+0x20]
00007f46e3fe00aa  vmovaps xmm3, [rsp+0x30]
00007f46e3fe00b0  vmovaps xmm4, [rsp+0x40]
00007f46e3fe00b6  vmovaps xmm5, [rsp+0x50]
00007f46e3fe00bc  vmovaps xmm6, [rsp+0x60]
00007f46e3fe00c2  vmovaps xmm7, [rsp+0x70]
00007f46e3fe00c8  vmovaps xmm9, [rsp+0x80]
00007f46e3fe00d1  vmovaps xmm10, [rsp+0x90]
00007f46e3fe00da  vmovaps xmm11, [rsp+0xA0]
00007f46e3fe00e3  vmovaps xmm12, [rsp+0xB0]
00007f46e3fe00ec  vmovaps xmm13, [rsp+0xC0]
00007f46e3fe00f5  vmovaps xmm14, [rsp+0xD0]
00007f46e3fe00fe  vmovaps xmm15, [rsp+0xE0]
00007f46e3fe0107  add rsp, 0xF0
00007f46e3fe010e  pop r11
00007f46e3fe0110  pop r10
00007f46e3fe0112  pop r9
00007f46e3fe0114  pop r8
00007f46e3fe0116  pop rsi
00007f46e3fe0117  pop rdi
00007f46e3fe0118  pop rdx
00007f46e3fe0119  pop rcx
00007f46e3fe011a  pop rax
00007f46e3fe011b  add rsp, 0x08
00007f46e3fe011f  jmp 0x00007F46E3FDC561
00007f46e3fe0124  sub rsp, 0x08
00007f46e3fe0128  push rax
00007f46e3fe0129  push rcx
00007f46e3fe012a  push rdx
00007f46e3fe012b  push rdi
00007f46e3fe012c  push rsi
00007f46e3fe012d  push r8
00007f46e3fe012f  push r9
00007f46e3fe0131  push r10
00007f46e3fe0133  push r11
00007f46e3fe0135  sub rsp, 0xF0
00007f46e3fe013c  vmovaps [rsp], xmm0
00007f46e3fe0141  vmovaps [rsp+0x10], xmm1
00007f46e3fe0147  vmovaps [rsp+0x20], xmm2
00007f46e3fe014d  vmovaps [rsp+0x30], xmm3
00007f46e3fe0153  vmovaps [rsp+0x40], xmm4
00007f46e3fe0159  vmovaps [rsp+0x50], xmm5
00007f46e3fe015f  vmovaps [rsp+0x60], xmm7
00007f46e3fe0165  vmovaps [rsp+0x70], xmm8
00007f46e3fe016b  vmovaps [rsp+0x80], xmm9
00007f46e3fe0174  vmovaps [rsp+0x90], xmm10
00007f46e3fe017d  vmovaps [rsp+0xA0], xmm11
00007f46e3fe0186  vmovaps [rsp+0xB0], xmm12
00007f46e3fe018f  vmovaps [rsp+0xC0], xmm13
00007f46e3fe0198  vmovaps [rsp+0xD0], xmm14
00007f46e3fe01a1  vmovaps [rsp+0xE0], xmm15
00007f46e3fe01aa  sub rsp, 0x30
00007f46e3fe01ae  movaps [rsp], xmm6
00007f46e3fe01b2  movaps [rsp+0x10], xmm1
00007f46e3fe01b7  movaps [rsp+0x20], xmm14
00007f46e3fe01bd  lea rdi, [rsp]
00007f46e3fe01c1  mov esi, 0x00
00007f46e3fe01c6  mov rax, 0x6238B185B530
00007f46e3fe01d0  call rax
00007f46e3fe01d2  movaps xmm6, [rsp]
00007f46e3fe01d6  add rsp, 0x30
00007f46e3fe01da  vmovaps xmm0, [rsp]
00007f46e3fe01df  vmovaps xmm1, [rsp+0x10]
00007f46e3fe01e5  vmovaps xmm2, [rsp+0x20]
00007f46e3fe01eb  vmovaps xmm3, [rsp+0x30]
00007f46e3fe01f1  vmovaps xmm4, [rsp+0x40]
00007f46e3fe01f7  vmovaps xmm5, [rsp+0x50]
00007f46e3fe01fd  vmovaps xmm7, [rsp+0x60]
00007f46e3fe0203  vmovaps xmm8, [rsp+0x70]
00007f46e3fe0209  vmovaps xmm9, [rsp+0x80]
00007f46e3fe0212  vmovaps xmm10, [rsp+0x90]
00007f46e3fe021b  vmovaps xmm11, [rsp+0xA0]
00007f46e3fe0224  vmovaps xmm12, [rsp+0xB0]
00007f46e3fe022d  vmovaps xmm13, [rsp+0xC0]
00007f46e3fe0236  vmovaps xmm14, [rsp+0xD0]
00007f46e3fe023f  vmovaps xmm15, [rsp+0xE0]
00007f46e3fe0248  add rsp, 0xF0
00007f46e3fe024f  pop r11
00007f46e3fe0251  pop r10
00007f46e3fe0253  pop r9
00007f46e3fe0255  pop r8
00007f46e3fe0257  pop rsi
00007f46e3fe0258  pop rdi
00007f46e3fe0259  pop rdx
00007f46e3fe025a  pop rcx
00007f46e3fe025b  pop rax
00007f46e3fe025c  add rsp, 0x08
00007f46e3fe0260  jmp 0x00007F46E3FDC58D
00007f46e3fe0265  sub rsp, 0x08
00007f46e3fe0269  push rax
00007f46e3fe026a  push rcx
00007f46e3fe026b  push rdx
00007f46e3fe026c  push rdi
00007f46e3fe026d  push rsi
00007f46e3fe026e  push r8
00007f46e3fe0270  push r9
00007f46e3fe0272  push r10
00007f46e3fe0274  push r11
00007f46e3fe0276  sub rsp, 0xF0
00007f46e3fe027d  vmovaps [rsp], xmm0
00007f46e3fe0282  vmovaps [rsp+0x10], xmm1
00007f46e3fe0288  vmovaps [rsp+0x20], xmm2
00007f46e3fe028e  vmovaps [rsp+0x30], xmm3
00007f46e3fe0294  vmovaps [rsp+0x40], xmm4
00007f46e3fe029a  vmovaps [rsp+0x50], xmm5
00007f46e3fe02a0  vmovaps [rsp+0x60], xmm6
00007f46e3fe02a6  vmovaps [rsp+0x70], xmm7
00007f46e3fe02ac  vmovaps [rsp+0x80], xmm8
00007f46e3fe02b5  vmovaps [rsp+0x90], xmm9
00007f46e3fe02be  vmovaps [rsp+0xA0], xmm10
00007f46e3fe02c7  vmovaps [rsp+0xB0], xmm11
00007f46e3fe02d0  vmovaps [rsp+0xC0], xmm12
00007f46e3fe02d9  vmovaps [rsp+0xD0], xmm13
00007f46e3fe02e2  vmovaps [rsp+0xE0], xmm15
00007f46e3fe02eb  sub rsp, 0x30
00007f46e3fe02ef  movaps [rsp], xmm14
00007f46e3fe02f4  movaps [rsp+0x10], xmm12
00007f46e3fe02fa  movaps [rsp+0x20], xmm1
00007f46e3fe02ff  lea rdi, [rsp]
00007f46e3fe0303  mov esi, 0x00
00007f46e3fe0308  mov rax, 0x6238B185B530
00007f46e3fe0312  call rax
00007f46e3fe0314  movaps xmm14, [rsp]
00007f46e3fe0319  add rsp, 0x30
00007f46e3fe031d  vmovaps xmm0, [rsp]
00007f46e3fe0322  vmovaps xmm1, [rsp+0x10]
00007f46e3fe0328  vmovaps xmm2, [rsp+0x20]
00007f46e3fe032e  vmovaps xmm3, [rsp+0x30]
00007f46e3fe0334  vmovaps xmm4, [rsp+0x40]
00007f46e3fe033a  vmovaps xmm5, [rsp+0x50]
00007f46e3fe0340  vmovaps xmm6, [rsp+0x60]
00007f46e3fe0346  vmovaps xmm7, [rsp+0x70]
00007f46e3fe034c  vmovaps xmm8, [rsp+0x80]
00007f46e3fe0355  vmovaps xmm9, [rsp+0x90]
00007f46e3fe035e  vmovaps xmm10, [rsp+0xA0]
00007f46e3fe0367  vmovaps xmm11, [rsp+0xB0]
00007f46e3fe0370  vmovaps xmm12, [rsp+0xC0]
00007f46e3fe0379  vmovaps xmm13, [rsp+0xD0]
00007f46e3fe0382  vmovaps xmm15, [rsp+0xE0]
00007f46e3fe038b  add rsp, 0xF0
00007f46e3fe0392  pop r11
00007f46e3fe0394  pop r10
00007f46e3fe0396  pop r9
00007f46e3fe0398  pop r8
00007f46e3fe039a  pop rsi
00007f46e3fe039b  pop rdi
00007f46e3fe039c  pop rdx
00007f46e3fe039d  pop rcx
00007f46e3fe039e  pop rax
00007f46e3fe039f  add rsp, 0x08
00007f46e3fe03a3  jmp 0x00007F46E3FDC5B3
00007f46e3fe03a8  sub rsp, 0x08
00007f46e3fe03ac  push rax
00007f46e3fe03ad  push rcx
00007f46e3fe03ae  push rdx
00007f46e3fe03af  push rdi
00007f46e3fe03b0  push rsi
00007f46e3fe03b1  push r8
00007f46e3fe03b3  push r9
00007f46e3fe03b5  push r10
00007f46e3fe03b7  push r11
00007f46e3fe03b9  sub rsp, 0xF0
00007f46e3fe03c0  vmovaps [rsp], xmm0
00007f46e3fe03c5  vmovaps [rsp+0x10], xmm2
00007f46e3fe03cb  vmovaps [rsp+0x20], xmm3
00007f46e3fe03d1  vmovaps [rsp+0x30], xmm4
00007f46e3fe03d7  vmovaps [rsp+0x40], xmm5
00007f46e3fe03dd  vmovaps [rsp+0x50], xmm6
00007f46e3fe03e3  vmovaps [rsp+0x60], xmm7
00007f46e3fe03e9  vmovaps [rsp+0x70], xmm8
00007f46e3fe03ef  vmovaps [rsp+0x80], xmm9
00007f46e3fe03f8  vmovaps [rsp+0x90], xmm10
00007f46e3fe0401  vmovaps [rsp+0xA0], xmm11
00007f46e3fe040a  vmovaps [rsp+0xB0], xmm12
00007f46e3fe0413  vmovaps [rsp+0xC0], xmm13
00007f46e3fe041c  vmovaps [rsp+0xD0], xmm14
00007f46e3fe0425  vmovaps [rsp+0xE0], xmm15
00007f46e3fe042e  sub rsp, 0x30
00007f46e3fe0432  movaps [rsp], xmm1
00007f46e3fe0436  movaps [rsp+0x10], xmm13
00007f46e3fe043c  movaps [rsp+0x20], xmm9
00007f46e3fe0442  lea rdi, [rsp]
00007f46e3fe0446  mov esi, 0x00
00007f46e3fe044b  mov rax, 0x6238B185B530
00007f46e3fe0455  call rax
00007f46e3fe0457  movaps xmm1, [rsp]
00007f46e3fe045b  add rsp, 0x30
00007f46e3fe045f  vmovaps xmm0, [rsp]
00007f46e3fe0464  vmovaps xmm2, [rsp+0x10]
00007f46e3fe046a  vmovaps xmm3, [rsp+0x20]
00007f46e3fe0470  vmovaps xmm4, [rsp+0x30]
00007f46e3fe0476  vmovaps xmm5, [rsp+0x40]
00007f46e3fe047c  vmovaps xmm6, [rsp+0x50]
00007f46e3fe0482  vmovaps xmm7, [rsp+0x60]
00007f46e3fe0488  vmovaps xmm8, [rsp+0x70]
00007f46e3fe048e  vmovaps xmm9, [rsp+0x80]
00007f46e3fe0497  vmovaps xmm10, [rsp+0x90]
00007f46e3fe04a0  vmovaps xmm11, [rsp+0xA0]
00007f46e3fe04a9  vmovaps xmm12, [rsp+0xB0]
00007f46e3fe04b2  vmovaps xmm13, [rsp+0xC0]
00007f46e3fe04bb  vmovaps xmm14, [rsp+0xD0]
00007f46e3fe04c4  vmovaps xmm15, [rsp+0xE0]
00007f46e3fe04cd  add rsp, 0xF0
00007f46e3fe04d4  pop r11
00007f46e3fe04d6  pop r10
00007f46e3fe04d8  pop r9
00007f46e3fe04da  pop r8
00007f46e3fe04dc  pop rsi
00007f46e3fe04dd  pop rdi
00007f46e3fe04de  pop rdx
00007f46e3fe04df  pop rcx
00007f46e3fe04e0  pop rax
00007f46e3fe04e1  add rsp, 0x08
00007f46e3fe04e5  jmp 0x00007F46E3FDC5CD
00007f46e3fe04ea  sub rsp, 0x08
00007f46e3fe04ee  push rax
00007f46e3fe04ef  push rcx
00007f46e3fe04f0  push rdx
00007f46e3fe04f1  push rdi
00007f46e3fe04f2  push rsi
00007f46e3fe04f3  push r8
00007f46e3fe04f5  push r9
00007f46e3fe04f7  push r10
00007f46e3fe04f9  push r11
00007f46e3fe04fb  sub rsp, 0xF0
00007f46e3fe0502  vmovaps [rsp], xmm0
00007f46e3fe0507  vmovaps [rsp+0x10], xmm1
00007f46e3fe050d  vmovaps [rsp+0x20], xmm2
00007f46e3fe0513  vmovaps [rsp+0x30], xmm3
00007f46e3fe0519  vmovaps [rsp+0x40], xmm4
00007f46e3fe051f  vmovaps [rsp+0x50], xmm5
00007f46e3fe0525  vmovaps [rsp+0x60], xmm6
00007f46e3fe052b  vmovaps [rsp+0x70], xmm7
00007f46e3fe0531  vmovaps [rsp+0x80], xmm8
00007f46e3fe053a  vmovaps [rsp+0x90], xmm9
00007f46e3fe0543  vmovaps [rsp+0xA0], xmm10
00007f46e3fe054c  vmovaps [rsp+0xB0], xmm11
00007f46e3fe0555  vmovaps [rsp+0xC0], xmm13
00007f46e3fe055e  vmovaps [rsp+0xD0], xmm14
00007f46e3fe0567  vmovaps [rsp+0xE0], xmm15
00007f46e3fe0570  sub rsp, 0x30
00007f46e3fe0574  movaps [rsp], xmm12
00007f46e3fe0579  movaps [rsp+0x10], xmm7
00007f46e3fe057e  movaps [rsp+0x20], xmm13
00007f46e3fe0584  lea rdi, [rsp]
00007f46e3fe0588  mov esi, 0x00
00007f46e3fe058d  mov rax, 0x6238B185B530
00007f46e3fe0597  call rax
00007f46e3fe0599  movaps xmm12, [rsp]
00007f46e3fe059e  add rsp, 0x30
00007f46e3fe05a2  vmovaps xmm0, [rsp]
00007f46e3fe05a7  vmovaps xmm1, [rsp+0x10]
00007f46e3fe05ad  vmovaps xmm2, [rsp+0x20]
00007f46e3fe05b3  vmovaps xmm3, [rsp+0x30]
00007f46e3fe05b9  vmovaps xmm4, [rsp+0x40]
00007f46e3fe05bf  vmovaps xmm5, [rsp+0x50]
00007f46e3fe05c5  vmovaps xmm6, [rsp+0x60]
00007f46e3fe05cb  vmovaps xmm7, [rsp+0x70]
00007f46e3fe05d1  vmovaps xmm8, [rsp+0x80]
00007f46e3fe05da  vmovaps xmm9, [rsp+0x90]
00007f46e3fe05e3  vmovaps xmm10, [rsp+0xA0]
00007f46e3fe05ec  vmovaps xmm11, [rsp+0xB0]
00007f46e3fe05f5  vmovaps xmm13, [rsp+0xC0]
00007f46e3fe05fe  vmovaps xmm14, [rsp+0xD0]
00007f46e3fe0607  vmovaps xmm15, [rsp+0xE0]
00007f46e3fe0610  add rsp, 0xF0
00007f46e3fe0617  pop r11
00007f46e3fe0619  pop r10
00007f46e3fe061b  pop r9
00007f46e3fe061d  pop r8
00007f46e3fe061f  pop rsi
00007f46e3fe0620  pop rdi
00007f46e3fe0621  pop rdx
00007f46e3fe0622  pop rcx
00007f46e3fe0623  pop rax
00007f46e3fe0624  add rsp, 0x08
00007f46e3fe0628  jmp 0x00007F46E3FDC5F4
00007f46e3fe062d  sub rsp, 0x08
00007f46e3fe0631  push rax
00007f46e3fe0632  push rcx
00007f46e3fe0633  push rdx
00007f46e3fe0634  push rdi
00007f46e3fe0635  push rsi
00007f46e3fe0636  push r8
00007f46e3fe0638  push r9
00007f46e3fe063a  push r10
00007f46e3fe063c  push r11
00007f46e3fe063e  sub rsp, 0xF0
00007f46e3fe0645  vmovaps [rsp], xmm0
00007f46e3fe064a  vmovaps [rsp+0x10], xmm1
00007f46e3fe0650  vmovaps [rsp+0x20], xmm2
00007f46e3fe0656  vmovaps [rsp+0x30], xmm3
00007f46e3fe065c  vmovaps [rsp+0x40], xmm4
00007f46e3fe0662  vmovaps [rsp+0x50], xmm5
00007f46e3fe0668  vmovaps [rsp+0x60], xmm6
00007f46e3fe066e  vmovaps [rsp+0x70], xmm7
00007f46e3fe0674  vmovaps [rsp+0x80], xmm8
00007f46e3fe067d  vmovaps [rsp+0x90], xmm9
00007f46e3fe0686  vmovaps [rsp+0xA0], xmm10
00007f46e3fe068f  vmovaps [rsp+0xB0], xmm11
00007f46e3fe0698  vmovaps [rsp+0xC0], xmm12
00007f46e3fe06a1  vmovaps [rsp+0xD0], xmm14
00007f46e3fe06aa  vmovaps [rsp+0xE0], xmm15
00007f46e3fe06b3  sub rsp, 0x30
00007f46e3fe06b7  movaps [rsp], xmm13
00007f46e3fe06bc  movaps [rsp+0x10], xmm15
00007f46e3fe06c2  movaps [rsp+0x20], xmm8
00007f46e3fe06c8  lea rdi, [rsp]
00007f46e3fe06cc  mov esi, 0x00
00007f46e3fe06d1  mov rax, 0x6238B185B530
00007f46e3fe06db  call rax
00007f46e3fe06dd  movaps xmm13, [rsp]
00007f46e3fe06e2  add rsp, 0x30
00007f46e3fe06e6  vmovaps xmm0, [rsp]
00007f46e3fe06eb  vmovaps xmm1, [rsp+0x10]
00007f46e3fe06f1  vmovaps xmm2, [rsp+0x20]
00007f46e3fe06f7  vmovaps xmm3, [rsp+0x30]
00007f46e3fe06fd  vmovaps xmm4, [rsp+0x40]
00007f46e3fe0703  vmovaps xmm5, [rsp+0x50]
00007f46e3fe0709  vmovaps xmm6, [rsp+0x60]
00007f46e3fe070f  vmovaps xmm7, [rsp+0x70]
00007f46e3fe0715  vmovaps xmm8, [rsp+0x80]
00007f46e3fe071e  vmovaps xmm9, [rsp+0x90]
00007f46e3fe0727  vmovaps xmm10, [rsp+0xA0]
00007f46e3fe0730  vmovaps xmm11, [rsp+0xB0]
00007f46e3fe0739  vmovaps xmm12, [rsp+0xC0]
00007f46e3fe0742  vmovaps xmm14, [rsp+0xD0]
00007f46e3fe074b  vmovaps xmm15, [rsp+0xE0]
00007f46e3fe0754  add rsp, 0xF0
00007f46e3fe075b  pop r11
00007f46e3fe075d  pop r10
00007f46e3fe075f  pop r9
00007f46e3fe0761  pop r8
00007f46e3fe0763  pop rsi
00007f46e3fe0764  pop rdi
00007f46e3fe0765  pop rdx
00007f46e3fe0766  pop rcx
00007f46e3fe0767  pop rax
00007f46e3fe0768  add rsp, 0x08
00007f46e3fe076c  jmp 0x00007F46E3FDC60F
00007f46e3fe0771  sub rsp, 0x08
00007f46e3fe0775  push rax
00007f46e3fe0776  push rcx
00007f46e3fe0777  push rdx
00007f46e3fe0778  push rdi
00007f46e3fe0779  push rsi
00007f46e3fe077a  push r8
00007f46e3fe077c  push r9
00007f46e3fe077e  push r10
00007f46e3fe0780  push r11
00007f46e3fe0782  sub rsp, 0xF0
00007f46e3fe0789  vmovaps [rsp], xmm0
00007f46e3fe078e  vmovaps [rsp+0x10], xmm1
00007f46e3fe0794  vmovaps [rsp+0x20], xmm2
00007f46e3fe079a  vmovaps [rsp+0x30], xmm3
00007f46e3fe07a0  vmovaps [rsp+0x40], xmm4
00007f46e3fe07a6  vmovaps [rsp+0x50], xmm5
00007f46e3fe07ac  vmovaps [rsp+0x60], xmm6
00007f46e3fe07b2  vmovaps [rsp+0x70], xmm7
00007f46e3fe07b8  vmovaps [rsp+0x80], xmm9
00007f46e3fe07c1  vmovaps [rsp+0x90], xmm10
00007f46e3fe07ca  vmovaps [rsp+0xA0], xmm11
00007f46e3fe07d3  vmovaps [rsp+0xB0], xmm12
00007f46e3fe07dc  vmovaps [rsp+0xC0], xmm13
00007f46e3fe07e5  vmovaps [rsp+0xD0], xmm14
00007f46e3fe07ee  vmovaps [rsp+0xE0], xmm15
00007f46e3fe07f7  sub rsp, 0x30
00007f46e3fe07fb  movaps [rsp], xmm8
00007f46e3fe0800  movaps [rsp+0x10], xmm15
00007f46e3fe0806  movaps [rsp+0x20], xmm9
00007f46e3fe080c  lea rdi, [rsp]
00007f46e3fe0810  mov esi, 0x00
00007f46e3fe0815  mov rax, 0x6238B185B530
00007f46e3fe081f  call rax
00007f46e3fe0821  movaps xmm8, [rsp]
00007f46e3fe0826  add rsp, 0x30
00007f46e3fe082a  vmovaps xmm0, [rsp]
00007f46e3fe082f  vmovaps xmm1, [rsp+0x10]
00007f46e3fe0835  vmovaps xmm2, [rsp+0x20]
00007f46e3fe083b  vmovaps xmm3, [rsp+0x30]
00007f46e3fe0841  vmovaps xmm4, [rsp+0x40]
00007f46e3fe0847  vmovaps xmm5, [rsp+0x50]
00007f46e3fe084d  vmovaps xmm6, [rsp+0x60]
00007f46e3fe0853  vmovaps xmm7, [rsp+0x70]
00007f46e3fe0859  vmovaps xmm9, [rsp+0x80]
00007f46e3fe0862  vmovaps xmm10, [rsp+0x90]
00007f46e3fe086b  vmovaps xmm11, [rsp+0xA0]
00007f46e3fe0874  vmovaps xmm12, [rsp+0xB0]
00007f46e3fe087d  vmovaps xmm13, [rsp+0xC0]
00007f46e3fe0886  vmovaps xmm14, [rsp+0xD0]
00007f46e3fe088f  vmovaps xmm15, [rsp+0xE0]
00007f46e3fe0898  add rsp, 0xF0
00007f46e3fe089f  pop r11
00007f46e3fe08a1  pop r10
00007f46e3fe08a3  pop r9
00007f46e3fe08a5  pop r8
00007f46e3fe08a7  pop rsi
00007f46e3fe08a8  pop rdi
00007f46e3fe08a9  pop rdx
00007f46e3fe08aa  pop rcx
00007f46e3fe08ab  pop rax
00007f46e3fe08ac  add rsp, 0x08
00007f46e3fe08b0  jmp 0x00007F46E3FDC63D
00007f46e3fe08b5  sub rsp, 0x08
00007f46e3fe08b9  push rax
00007f46e3fe08ba  push rcx
00007f46e3fe08bb  push rdx
00007f46e3fe08bc  push rdi
00007f46e3fe08bd  push rsi
00007f46e3fe08be  push r8
00007f46e3fe08c0  push r9
00007f46e3fe08c2  push r10
00007f46e3fe08c4  push r11
00007f46e3fe08c6  sub rsp, 0xF0
00007f46e3fe08cd  vmovaps [rsp], xmm0
00007f46e3fe08d2  vmovaps [rsp+0x10], xmm1
00007f46e3fe08d8  vmovaps [rsp+0x20], xmm2
00007f46e3fe08de  vmovaps [rsp+0x30], xmm3
00007f46e3fe08e4  vmovaps [rsp+0x40], xmm4
00007f46e3fe08ea  vmovaps [rsp+0x50], xmm5
00007f46e3fe08f0  vmovaps [rsp+0x60], xmm6
00007f46e3fe08f6  vmovaps [rsp+0x70], xmm7
00007f46e3fe08fc  vmovaps [rsp+0x80], xmm8
00007f46e3fe0905  vmovaps [rsp+0x90], xmm9
00007f46e3fe090e  vmovaps [rsp+0xA0], xmm10
00007f46e3fe0917  vmovaps [rsp+0xB0], xmm11
00007f46e3fe0920  vmovaps [rsp+0xC0], xmm12
00007f46e3fe0929  vmovaps [rsp+0xD0], xmm13
00007f46e3fe0932  vmovaps [rsp+0xE0], xmm14
00007f46e3fe093b  sub rsp, 0x30
00007f46e3fe093f  movaps [rsp], xmm15
00007f46e3fe0944  movaps [rsp+0x10], xmm11
00007f46e3fe094a  movaps [rsp+0x20], xmm6
00007f46e3fe094f  lea rdi, [rsp]
00007f46e3fe0953  mov esi, 0x00
00007f46e3fe0958  mov rax, 0x6238B185B530
00007f46e3fe0962  call rax
00007f46e3fe0964  movaps xmm15, [rsp]
00007f46e3fe0969  add rsp, 0x30
00007f46e3fe096d  vmovaps xmm0, [rsp]
00007f46e3fe0972  vmovaps xmm1, [rsp+0x10]
00007f46e3fe0978  vmovaps xmm2, [rsp+0x20]
00007f46e3fe097e  vmovaps xmm3, [rsp+0x30]
00007f46e3fe0984  vmovaps xmm4, [rsp+0x40]
00007f46e3fe098a  vmovaps xmm5, [rsp+0x50]
00007f46e3fe0990  vmovaps xmm6, [rsp+0x60]
00007f46e3fe0996  vmovaps xmm7, [rsp+0x70]
00007f46e3fe099c  vmovaps xmm8, [rsp+0x80]
00007f46e3fe09a5  vmovaps xmm9, [rsp+0x90]
00007f46e3fe09ae  vmovaps xmm10, [rsp+0xA0]
00007f46e3fe09b7  vmovaps xmm11, [rsp+0xB0]
00007f46e3fe09c0  vmovaps xmm12, [rsp+0xC0]
00007f46e3fe09c9  vmovaps xmm13, [rsp+0xD0]
00007f46e3fe09d2  vmovaps xmm14, [rsp+0xE0]
00007f46e3fe09db  add rsp, 0xF0
00007f46e3fe09e2  pop r11
00007f46e3fe09e4  pop r10
00007f46e3fe09e6  pop r9
00007f46e3fe09e8  pop r8
00007f46e3fe09ea  pop rsi
00007f46e3fe09eb  pop rdi
00007f46e3fe09ec  pop rdx
00007f46e3fe09ed  pop rcx
00007f46e3fe09ee  pop rax
00007f46e3fe09ef  add rsp, 0x08
00007f46e3fe09f3  jmp 0x00007F46E3FDC658
00007f46e3fe09f8  sub rsp, 0x08
00007f46e3fe09fc  push rax
00007f46e3fe09fd  push rcx
00007f46e3fe09fe  push rdx
00007f46e3fe09ff  push rdi
00007f46e3fe0a00  push rsi
00007f46e3fe0a01  push r8
00007f46e3fe0a03  push r9
00007f46e3fe0a05  push r10
00007f46e3fe0a07  push r11
00007f46e3fe0a09  sub rsp, 0xF0
00007f46e3fe0a10  vmovaps [rsp], xmm0
00007f46e3fe0a15  vmovaps [rsp+0x10], xmm1
00007f46e3fe0a1b  vmovaps [rsp+0x20], xmm2
00007f46e3fe0a21  vmovaps [rsp+0x30], xmm3
00007f46e3fe0a27  vmovaps [rsp+0x40], xmm4
00007f46e3fe0a2d  vmovaps [rsp+0x50], xmm5
00007f46e3fe0a33  vmovaps [rsp+0x60], xmm6
00007f46e3fe0a39  vmovaps [rsp+0x70], xmm8
00007f46e3fe0a3f  vmovaps [rsp+0x80], xmm9
00007f46e3fe0a48  vmovaps [rsp+0x90], xmm10
00007f46e3fe0a51  vmovaps [rsp+0xA0], xmm11
00007f46e3fe0a5a  vmovaps [rsp+0xB0], xmm12
00007f46e3fe0a63  vmovaps [rsp+0xC0], xmm13
00007f46e3fe0a6c  vmovaps [rsp+0xD0], xmm14
00007f46e3fe0a75  vmovaps [rsp+0xE0], xmm15
00007f46e3fe0a7e  sub rsp, 0x30
00007f46e3fe0a82  movaps [rsp], xmm7
00007f46e3fe0a86  movaps [rsp+0x10], xmm11
00007f46e3fe0a8c  movaps [rsp+0x20], xmm9
00007f46e3fe0a92  lea rdi, [rsp]
00007f46e3fe0a96  mov esi, 0x00
00007f46e3fe0a9b  mov rax, 0x6238B185B530
00007f46e3fe0aa5  call rax
00007f46e3fe0aa7  movaps xmm7, [rsp]
00007f46e3fe0aab  add rsp, 0x30
00007f46e3fe0aaf  vmovaps xmm0, [rsp]
00007f46e3fe0ab4  vmovaps xmm1, [rsp+0x10]
00007f46e3fe0aba  vmovaps xmm2, [rsp+0x20]
00007f46e3fe0ac0  vmovaps xmm3, [rsp+0x30]
00007f46e3fe0ac6  vmovaps xmm4, [rsp+0x40]
00007f46e3fe0acc  vmovaps xmm5, [rsp+0x50]
00007f46e3fe0ad2  vmovaps xmm6, [rsp+0x60]
00007f46e3fe0ad8  vmovaps xmm8, [rsp+0x70]
00007f46e3fe0ade  vmovaps xmm9, [rsp+0x80]
00007f46e3fe0ae7  vmovaps xmm10, [rsp+0x90]
00007f46e3fe0af0  vmovaps xmm11, [rsp+0xA0]
00007f46e3fe0af9  vmovaps xmm12, [rsp+0xB0]
00007f46e3fe0b02  vmovaps xmm13, [rsp+0xC0]
00007f46e3fe0b0b  vmovaps xmm14, [rsp+0xD0]
00007f46e3fe0b14  vmovaps xmm15, [rsp+0xE0]
00007f46e3fe0b1d  add rsp, 0xF0
00007f46e3fe0b24  pop r11
00007f46e3fe0b26  pop r10
00007f46e3fe0b28  pop r9
00007f46e3fe0b2a  pop r8
00007f46e3fe0b2c  pop rsi
00007f46e3fe0b2d  pop rdi
00007f46e3fe0b2e  pop rdx
00007f46e3fe0b2f  pop rcx
00007f46e3fe0b30  pop rax
00007f46e3fe0b31  add rsp, 0x08
00007f46e3fe0b35  jmp 0x00007F46E3FDC685
00007f46e3fe0b3a  sub rsp, 0x08
00007f46e3fe0b3e  push rax
00007f46e3fe0b3f  push rcx
00007f46e3fe0b40  push rdx
00007f46e3fe0b41  push rdi
00007f46e3fe0b42  push rsi
00007f46e3fe0b43  push r8
00007f46e3fe0b45  push r9
00007f46e3fe0b47  push r10
00007f46e3fe0b49  push r11
00007f46e3fe0b4b  sub rsp, 0xF0
00007f46e3fe0b52  vmovaps [rsp], xmm0
00007f46e3fe0b57  vmovaps [rsp+0x10], xmm1
00007f46e3fe0b5d  vmovaps [rsp+0x20], xmm2
00007f46e3fe0b63  vmovaps [rsp+0x30], xmm3
00007f46e3fe0b69  vmovaps [rsp+0x40], xmm4
00007f46e3fe0b6f  vmovaps [rsp+0x50], xmm5
00007f46e3fe0b75  vmovaps [rsp+0x60], xmm6
00007f46e3fe0b7b  vmovaps [rsp+0x70], xmm7
00007f46e3fe0b81  vmovaps [rsp+0x80], xmm8
00007f46e3fe0b8a  vmovaps [rsp+0x90], xmm9
00007f46e3fe0b93  vmovaps [rsp+0xA0], xmm10
00007f46e3fe0b9c  vmovaps [rsp+0xB0], xmm12
00007f46e3fe0ba5  vmovaps [rsp+0xC0], xmm13
00007f46e3fe0bae  vmovaps [rsp+0xD0], xmm14
00007f46e3fe0bb7  vmovaps [rsp+0xE0], xmm15
00007f46e3fe0bc0  sub rsp, 0x30
00007f46e3fe0bc4  movaps [rsp], xmm11
00007f46e3fe0bc9  movaps [rsp+0x10], xmm10
00007f46e3fe0bcf  movaps [rsp+0x20], xmm14
00007f46e3fe0bd5  lea rdi, [rsp]
00007f46e3fe0bd9  mov esi, 0x00
00007f46e3fe0bde  mov rax, 0x6238B185B530
00007f46e3fe0be8  call rax
00007f46e3fe0bea  movaps xmm11, [rsp]
00007f46e3fe0bef  add rsp, 0x30
00007f46e3fe0bf3  vmovaps xmm0, [rsp]
00007f46e3fe0bf8  vmovaps xmm1, [rsp+0x10]
00007f46e3fe0bfe  vmovaps xmm2, [rsp+0x20]
00007f46e3fe0c04  vmovaps xmm3, [rsp+0x30]
00007f46e3fe0c0a  vmovaps xmm4, [rsp+0x40]
00007f46e3fe0c10  vmovaps xmm5, [rsp+0x50]
00007f46e3fe0c16  vmovaps xmm6, [rsp+0x60]
00007f46e3fe0c1c  vmovaps xmm7, [rsp+0x70]
00007f46e3fe0c22  vmovaps xmm8, [rsp+0x80]
00007f46e3fe0c2b  vmovaps xmm9, [rsp+0x90]
00007f46e3fe0c34  vmovaps xmm10, [rsp+0xA0]
00007f46e3fe0c3d  vmovaps xmm12, [rsp+0xB0]
00007f46e3fe0c46  vmovaps xmm13, [rsp+0xC0]
00007f46e3fe0c4f  vmovaps xmm14, [rsp+0xD0]
00007f46e3fe0c58  vmovaps xmm15, [rsp+0xE0]
00007f46e3fe0c61  add rsp, 0xF0
00007f46e3fe0c68  pop r11
00007f46e3fe0c6a  pop r10
00007f46e3fe0c6c  pop r9
00007f46e3fe0c6e  pop r8
00007f46e3fe0c70  pop rsi
00007f46e3fe0c71  pop rdi
00007f46e3fe0c72  pop rdx
00007f46e3fe0c73  pop rcx
00007f46e3fe0c74  pop rax
00007f46e3fe0c75  add rsp, 0x08
00007f46e3fe0c79  jmp 0x00007F46E3FDC6A0
00007f46e3fe0c7e  call 0x00007F46E3EC33A0
00007f46e3fe0c83  jmp 0x00007F46E3FDC6AA
00007f46e3fe0c88  sub rsp, 0x08
00007f46e3fe0c8c  push rax
00007f46e3fe0c8d  push rcx
00007f46e3fe0c8e  push rdx
00007f46e3fe0c8f  push rdi
00007f46e3fe0c90  push rsi
00007f46e3fe0c91  push r8
00007f46e3fe0c93  push r9
00007f46e3fe0c95  push r10
00007f46e3fe0c97  push r11
00007f46e3fe0c99  sub rsp, 0xF0
00007f46e3fe0ca0  vmovaps [rsp], xmm0
00007f46e3fe0ca5  vmovaps [rsp+0x10], xmm1
00007f46e3fe0cab  vmovaps [rsp+0x20], xmm2
00007f46e3fe0cb1  vmovaps [rsp+0x30], xmm3
00007f46e3fe0cb7  vmovaps [rsp+0x40], xmm4
00007f46e3fe0cbd  vmovaps [rsp+0x50], xmm5
00007f46e3fe0cc3  vmovaps [rsp+0x60], xmm6
00007f46e3fe0cc9  vmovaps [rsp+0x70], xmm7
00007f46e3fe0ccf  vmovaps [rsp+0x80], xmm8
00007f46e3fe0cd8  vmovaps [rsp+0x90], xmm9
00007f46e3fe0ce1  vmovaps [rsp+0xA0], xmm11
00007f46e3fe0cea  vmovaps [rsp+0xB0], xmm12
00007f46e3fe0cf3  vmovaps [rsp+0xC0], xmm13
00007f46e3fe0cfc  vmovaps [rsp+0xD0], xmm14
00007f46e3fe0d05  vmovaps [rsp+0xE0], xmm15
00007f46e3fe0d0e  sub rsp, 0x30
00007f46e3fe0d12  movaps [rsp], xmm10
00007f46e3fe0d17  movaps [rsp+0x10], xmm1
00007f46e3fe0d1c  movaps [rsp+0x20], xmm12
00007f46e3fe0d22  lea rdi, [rsp]
00007f46e3fe0d26  mov esi, 0x00
00007f46e3fe0d2b  mov rax, 0x6238B185B530
00007f46e3fe0d35  call rax
00007f46e3fe0d37  movaps xmm10, [rsp]
00007f46e3fe0d3c  add rsp, 0x30
00007f46e3fe0d40  vmovaps xmm0, [rsp]
00007f46e3fe0d45  vmovaps xmm1, [rsp+0x10]
00007f46e3fe0d4b  vmovaps xmm2, [rsp+0x20]
00007f46e3fe0d51  vmovaps xmm3, [rsp+0x30]
00007f46e3fe0d57  vmovaps xmm4, [rsp+0x40]
00007f46e3fe0d5d  vmovaps xmm5, [rsp+0x50]
00007f46e3fe0d63  vmovaps xmm6, [rsp+0x60]
00007f46e3fe0d69  vmovaps xmm7, [rsp+0x70]
00007f46e3fe0d6f  vmovaps xmm8, [rsp+0x80]
00007f46e3fe0d78  vmovaps xmm9, [rsp+0x90]
00007f46e3fe0d81  vmovaps xmm11, [rsp+0xA0]
00007f46e3fe0d8a  vmovaps xmm12, [rsp+0xB0]
00007f46e3fe0d93  vmovaps xmm13, [rsp+0xC0]
00007f46e3fe0d9c  vmovaps xmm14, [rsp+0xD0]
00007f46e3fe0da5  vmovaps xmm15, [rsp+0xE0]
00007f46e3fe0dae  add rsp, 0xF0
00007f46e3fe0db5  pop r11
00007f46e3fe0db7  pop r10
00007f46e3fe0db9  pop r9
00007f46e3fe0dbb  pop r8
00007f46e3fe0dbd  pop rsi
00007f46e3fe0dbe  pop rdi
00007f46e3fe0dbf  pop rdx
00007f46e3fe0dc0  pop rcx
00007f46e3fe0dc1  pop rax
00007f46e3fe0dc2  add rsp, 0x08
00007f46e3fe0dc6  jmp 0x00007F46E3FDC6CD
00007f46e3fe0dcb  sub rsp, 0x08
00007f46e3fe0dcf  push rax
00007f46e3fe0dd0  push rcx
00007f46e3fe0dd1  push rdx
00007f46e3fe0dd2  push rdi
00007f46e3fe0dd3  push rsi
00007f46e3fe0dd4  push r8
00007f46e3fe0dd6  push r9
00007f46e3fe0dd8  push r10
00007f46e3fe0dda  push r11
00007f46e3fe0ddc  sub rsp, 0xF0
00007f46e3fe0de3  vmovaps [rsp], xmm0
00007f46e3fe0de8  vmovaps [rsp+0x10], xmm1
00007f46e3fe0dee  vmovaps [rsp+0x20], xmm2
00007f46e3fe0df4  vmovaps [rsp+0x30], xmm3
00007f46e3fe0dfa  vmovaps [rsp+0x40], xmm4
00007f46e3fe0e00  vmovaps [rsp+0x50], xmm5
00007f46e3fe0e06  vmovaps [rsp+0x60], xmm6
00007f46e3fe0e0c  vmovaps [rsp+0x70], xmm7
00007f46e3fe0e12  vmovaps [rsp+0x80], xmm8
00007f46e3fe0e1b  vmovaps [rsp+0x90], xmm9
00007f46e3fe0e24  vmovaps [rsp+0xA0], xmm10
00007f46e3fe0e2d  vmovaps [rsp+0xB0], xmm11
00007f46e3fe0e36  vmovaps [rsp+0xC0], xmm13
00007f46e3fe0e3f  vmovaps [rsp+0xD0], xmm14
00007f46e3fe0e48  vmovaps [rsp+0xE0], xmm15
00007f46e3fe0e51  sub rsp, 0x30
00007f46e3fe0e55  movaps [rsp], xmm12
00007f46e3fe0e5a  movaps [rsp+0x10], xmm14
00007f46e3fe0e60  movaps [rsp+0x20], xmm1
00007f46e3fe0e65  lea rdi, [rsp]
00007f46e3fe0e69  mov esi, 0x00
00007f46e3fe0e6e  mov rax, 0x6238B185B530
00007f46e3fe0e78  call rax
00007f46e3fe0e7a  movaps xmm12, [rsp]
00007f46e3fe0e7f  add rsp, 0x30
00007f46e3fe0e83  vmovaps xmm0, [rsp]
00007f46e3fe0e88  vmovaps xmm1, [rsp+0x10]
00007f46e3fe0e8e  vmovaps xmm2, [rsp+0x20]
00007f46e3fe0e94  vmovaps xmm3, [rsp+0x30]
00007f46e3fe0e9a  vmovaps xmm4, [rsp+0x40]
00007f46e3fe0ea0  vmovaps xmm5, [rsp+0x50]
00007f46e3fe0ea6  vmovaps xmm6, [rsp+0x60]
00007f46e3fe0eac  vmovaps xmm7, [rsp+0x70]
00007f46e3fe0eb2  vmovaps xmm8, [rsp+0x80]
00007f46e3fe0ebb  vmovaps xmm9, [rsp+0x90]
00007f46e3fe0ec4  vmovaps xmm10, [rsp+0xA0]
00007f46e3fe0ecd  vmovaps xmm11, [rsp+0xB0]
00007f46e3fe0ed6  vmovaps xmm13, [rsp+0xC0]
00007f46e3fe0edf  vmovaps xmm14, [rsp+0xD0]
00007f46e3fe0ee8  vmovaps xmm15, [rsp+0xE0]
00007f46e3fe0ef1  add rsp, 0xF0
00007f46e3fe0ef8  pop r11
00007f46e3fe0efa  pop r10
00007f46e3fe0efc  pop r9
00007f46e3fe0efe  pop r8
00007f46e3fe0f00  pop rsi
00007f46e3fe0f01  pop rdi
00007f46e3fe0f02  pop rdx
00007f46e3fe0f03  pop rcx
00007f46e3fe0f04  pop rax
00007f46e3fe0f05  add rsp, 0x08
00007f46e3fe0f09  jmp 0x00007F46E3FDC6FC
00007f46e3fe0f0e  sub rsp, 0x08
00007f46e3fe0f12  push rax
00007f46e3fe0f13  push rcx
00007f46e3fe0f14  push rdx
00007f46e3fe0f15  push rdi
00007f46e3fe0f16  push rsi
00007f46e3fe0f17  push r8
00007f46e3fe0f19  push r9
00007f46e3fe0f1b  push r10
00007f46e3fe0f1d  push r11
00007f46e3fe0f1f  sub rsp, 0xF0
00007f46e3fe0f26  vmovaps [rsp], xmm0
00007f46e3fe0f2b  vmovaps [rsp+0x10], xmm1
00007f46e3fe0f31  vmovaps [rsp+0x20], xmm2
00007f46e3fe0f37  vmovaps [rsp+0x30], xmm3
00007f46e3fe0f3d  vmovaps [rsp+0x40], xmm4
00007f46e3fe0f43  vmovaps [rsp+0x50], xmm5
00007f46e3fe0f49  vmovaps [rsp+0x60], xmm6
00007f46e3fe0f4f  vmovaps [rsp+0x70], xmm7
00007f46e3fe0f55  vmovaps [rsp+0x80], xmm8
00007f46e3fe0f5e  vmovaps [rsp+0x90], xmm9
00007f46e3fe0f67  vmovaps [rsp+0xA0], xmm10
00007f46e3fe0f70  vmovaps [rsp+0xB0], xmm11
00007f46e3fe0f79  vmovaps [rsp+0xC0], xmm12
00007f46e3fe0f82  vmovaps [rsp+0xD0], xmm13
00007f46e3fe0f8b  vmovaps [rsp+0xE0], xmm15
00007f46e3fe0f94  sub rsp, 0x30
00007f46e3fe0f98  movaps [rsp], xmm14
00007f46e3fe0f9d  movaps [rsp+0x10], xmm9
00007f46e3fe0fa3  movaps [rsp+0x20], xmm1
00007f46e3fe0fa8  lea rdi, [rsp]
00007f46e3fe0fac  mov esi, 0x00
00007f46e3fe0fb1  mov rax, 0x6238B185B530
00007f46e3fe0fbb  call rax
00007f46e3fe0fbd  movaps xmm14, [rsp]
00007f46e3fe0fc2  add rsp, 0x30
00007f46e3fe0fc6  vmovaps xmm0, [rsp]
00007f46e3fe0fcb  vmovaps xmm1, [rsp+0x10]
00007f46e3fe0fd1  vmovaps xmm2, [rsp+0x20]
00007f46e3fe0fd7  vmovaps xmm3, [rsp+0x30]
00007f46e3fe0fdd  vmovaps xmm4, [rsp+0x40]
00007f46e3fe0fe3  vmovaps xmm5, [rsp+0x50]
00007f46e3fe0fe9  vmovaps xmm6, [rsp+0x60]
00007f46e3fe0fef  vmovaps xmm7, [rsp+0x70]
00007f46e3fe0ff5  vmovaps xmm8, [rsp+0x80]
00007f46e3fe0ffe  vmovaps xmm9, [rsp+0x90]
00007f46e3fe1007  vmovaps xmm10, [rsp+0xA0]
00007f46e3fe1010  vmovaps xmm11, [rsp+0xB0]
00007f46e3fe1019  vmovaps xmm12, [rsp+0xC0]
00007f46e3fe1022  vmovaps xmm13, [rsp+0xD0]
00007f46e3fe102b  vmovaps xmm15, [rsp+0xE0]
00007f46e3fe1034  add rsp, 0xF0
00007f46e3fe103b  pop r11
00007f46e3fe103d  pop r10
00007f46e3fe103f  pop r9
00007f46e3fe1041  pop r8
00007f46e3fe1043  pop rsi
00007f46e3fe1044  pop rdi
00007f46e3fe1045  pop rdx
00007f46e3fe1046  pop rcx
00007f46e3fe1047  pop rax
00007f46e3fe1048  add rsp, 0x08
00007f46e3fe104c  jmp 0x00007F46E3FDC72B
00007f46e3fe1051  sub rsp, 0x08
00007f46e3fe1055  push rax
00007f46e3fe1056  push rcx
00007f46e3fe1057  push rdx
00007f46e3fe1058  push rdi
00007f46e3fe1059  push rsi
00007f46e3fe105a  push r8
00007f46e3fe105c  push r9
00007f46e3fe105e  push r10
00007f46e3fe1060  push r11
00007f46e3fe1062  sub rsp, 0xF0
00007f46e3fe1069  vmovaps [rsp], xmm0
00007f46e3fe106e  vmovaps [rsp+0x10], xmm2
00007f46e3fe1074  vmovaps [rsp+0x20], xmm3
00007f46e3fe107a  vmovaps [rsp+0x30], xmm4
00007f46e3fe1080  vmovaps [rsp+0x40], xmm5
00007f46e3fe1086  vmovaps [rsp+0x50], xmm6
00007f46e3fe108c  vmovaps [rsp+0x60], xmm7
00007f46e3fe1092  vmovaps [rsp+0x70], xmm8
00007f46e3fe1098  vmovaps [rsp+0x80], xmm9
00007f46e3fe10a1  vmovaps [rsp+0x90], xmm10
00007f46e3fe10aa  vmovaps [rsp+0xA0], xmm11
00007f46e3fe10b3  vmovaps [rsp+0xB0], xmm12
00007f46e3fe10bc  vmovaps [rsp+0xC0], xmm13
00007f46e3fe10c5  vmovaps [rsp+0xD0], xmm14
00007f46e3fe10ce  vmovaps [rsp+0xE0], xmm15
00007f46e3fe10d7  sub rsp, 0x30
00007f46e3fe10db  movaps [rsp], xmm1
00007f46e3fe10df  movaps [rsp+0x10], xmm13
00007f46e3fe10e5  movaps [rsp+0x20], xmm8
00007f46e3fe10eb  lea rdi, [rsp]
00007f46e3fe10ef  mov esi, 0x00
00007f46e3fe10f4  mov rax, 0x6238B185B530
00007f46e3fe10fe  call rax
00007f46e3fe1100  movaps xmm1, [rsp]
00007f46e3fe1104  add rsp, 0x30
00007f46e3fe1108  vmovaps xmm0, [rsp]
00007f46e3fe110d  vmovaps xmm2, [rsp+0x10]
00007f46e3fe1113  vmovaps xmm3, [rsp+0x20]
00007f46e3fe1119  vmovaps xmm4, [rsp+0x30]
00007f46e3fe111f  vmovaps xmm5, [rsp+0x40]
00007f46e3fe1125  vmovaps xmm6, [rsp+0x50]
00007f46e3fe112b  vmovaps xmm7, [rsp+0x60]
00007f46e3fe1131  vmovaps xmm8, [rsp+0x70]
00007f46e3fe1137  vmovaps xmm9, [rsp+0x80]
00007f46e3fe1140  vmovaps xmm10, [rsp+0x90]
00007f46e3fe1149  vmovaps xmm11, [rsp+0xA0]
00007f46e3fe1152  vmovaps xmm12, [rsp+0xB0]
00007f46e3fe115b  vmovaps xmm13, [rsp+0xC0]
00007f46e3fe1164  vmovaps xmm14, [rsp+0xD0]
00007f46e3fe116d  vmovaps xmm15, [rsp+0xE0]
00007f46e3fe1176  add rsp, 0xF0
00007f46e3fe117d  pop r11
00007f46e3fe117f  pop r10
00007f46e3fe1181  pop r9
00007f46e3fe1183  pop r8
00007f46e3fe1185  pop rsi
00007f46e3fe1186  pop rdi
00007f46e3fe1187  pop rdx
00007f46e3fe1188  pop rcx
00007f46e3fe1189  pop rax
00007f46e3fe118a  add rsp, 0x08
00007f46e3fe118e  jmp 0x00007F46E3FDC74D
00007f46e3fe1193  call 0x00007F46E3E0C260
00007f46e3fe1198  jmp 0x00007F46E3FDC75B
00007f46e3fe119d  call 0x00007F46E3EBD750
00007f46e3fe11a2  jmp 0x00007F46E3FDC765
00007f46e3fe11a7  sub rsp, 0x08
00007f46e3fe11ab  push rax
00007f46e3fe11ac  push rcx
00007f46e3fe11ad  push rdx
00007f46e3fe11ae  push rdi
00007f46e3fe11af  push rsi
00007f46e3fe11b0  push r8
00007f46e3fe11b2  push r9
00007f46e3fe11b4  push r10
00007f46e3fe11b6  push r11
00007f46e3fe11b8  sub rsp, 0xF0
00007f46e3fe11bf  vmovaps [rsp], xmm0
00007f46e3fe11c4  vmovaps [rsp+0x10], xmm1
00007f46e3fe11ca  vmovaps [rsp+0x20], xmm2
00007f46e3fe11d0  vmovaps [rsp+0x30], xmm3
00007f46e3fe11d6  vmovaps [rsp+0x40], xmm4
00007f46e3fe11dc  vmovaps [rsp+0x50], xmm5
00007f46e3fe11e2  vmovaps [rsp+0x60], xmm6
00007f46e3fe11e8  vmovaps [rsp+0x70], xmm7
00007f46e3fe11ee  vmovaps [rsp+0x80], xmm9
00007f46e3fe11f7  vmovaps [rsp+0x90], xmm10
00007f46e3fe1200  vmovaps [rsp+0xA0], xmm11
00007f46e3fe1209  vmovaps [rsp+0xB0], xmm12
00007f46e3fe1212  vmovaps [rsp+0xC0], xmm13
00007f46e3fe121b  vmovaps [rsp+0xD0], xmm14
00007f46e3fe1224  vmovaps [rsp+0xE0], xmm15
00007f46e3fe122d  sub rsp, 0x30
00007f46e3fe1231  movaps [rsp], xmm8
00007f46e3fe1236  movaps [rsp+0x10], xmm15
00007f46e3fe123c  movaps [rsp+0x20], xmm7
00007f46e3fe1241  lea rdi, [rsp]
00007f46e3fe1245  mov esi, 0x00
00007f46e3fe124a  mov rax, 0x6238B185B530
00007f46e3fe1254  call rax
00007f46e3fe1256  movaps xmm8, [rsp]
00007f46e3fe125b  add rsp, 0x30
00007f46e3fe125f  vmovaps xmm0, [rsp]
00007f46e3fe1264  vmovaps xmm1, [rsp+0x10]
00007f46e3fe126a  vmovaps xmm2, [rsp+0x20]
00007f46e3fe1270  vmovaps xmm3, [rsp+0x30]
00007f46e3fe1276  vmovaps xmm4, [rsp+0x40]
00007f46e3fe127c  vmovaps xmm5, [rsp+0x50]
00007f46e3fe1282  vmovaps xmm6, [rsp+0x60]
00007f46e3fe1288  vmovaps xmm7, [rsp+0x70]
00007f46e3fe128e  vmovaps xmm9, [rsp+0x80]
00007f46e3fe1297  vmovaps xmm10, [rsp+0x90]
00007f46e3fe12a0  vmovaps xmm11, [rsp+0xA0]
00007f46e3fe12a9  vmovaps xmm12, [rsp+0xB0]
00007f46e3fe12b2  vmovaps xmm13, [rsp+0xC0]
00007f46e3fe12bb  vmovaps xmm14, [rsp+0xD0]
00007f46e3fe12c4  vmovaps xmm15, [rsp+0xE0]
00007f46e3fe12cd  add rsp, 0xF0
00007f46e3fe12d4  pop r11
00007f46e3fe12d6  pop r10
00007f46e3fe12d8  pop r9
00007f46e3fe12da  pop r8
00007f46e3fe12dc  pop rsi
00007f46e3fe12dd  pop rdi
00007f46e3fe12de  pop rdx
00007f46e3fe12df  pop rcx
00007f46e3fe12e0  pop rax
00007f46e3fe12e1  add rsp, 0x08
00007f46e3fe12e5  jmp 0x00007F46E3FDC787
00007f46e3fe12ea  sub rsp, 0x08
00007f46e3fe12ee  push rax
00007f46e3fe12ef  push rcx
00007f46e3fe12f0  push rdx
00007f46e3fe12f1  push rdi
00007f46e3fe12f2  push rsi
00007f46e3fe12f3  push r8
00007f46e3fe12f5  push r9
00007f46e3fe12f7  push r10
00007f46e3fe12f9  push r11
00007f46e3fe12fb  sub rsp, 0xF0
00007f46e3fe1302  vmovaps [rsp], xmm0
00007f46e3fe1307  vmovaps [rsp+0x10], xmm1
00007f46e3fe130d  vmovaps [rsp+0x20], xmm2
00007f46e3fe1313  vmovaps [rsp+0x30], xmm3
00007f46e3fe1319  vmovaps [rsp+0x40], xmm4
00007f46e3fe131f  vmovaps [rsp+0x50], xmm5
00007f46e3fe1325  vmovaps [rsp+0x60], xmm6
00007f46e3fe132b  vmovaps [rsp+0x70], xmm8
00007f46e3fe1331  vmovaps [rsp+0x80], xmm9
00007f46e3fe133a  vmovaps [rsp+0x90], xmm10
00007f46e3fe1343  vmovaps [rsp+0xA0], xmm11
00007f46e3fe134c  vmovaps [rsp+0xB0], xmm12
00007f46e3fe1355  vmovaps [rsp+0xC0], xmm13
00007f46e3fe135e  vmovaps [rsp+0xD0], xmm14
00007f46e3fe1367  vmovaps [rsp+0xE0], xmm15
00007f46e3fe1370  sub rsp, 0x30
00007f46e3fe1374  movaps [rsp], xmm7
00007f46e3fe1378  movaps [rsp+0x10], xmm9
00007f46e3fe137e  movaps [rsp+0x20], xmm15
00007f46e3fe1384  lea rdi, [rsp]
00007f46e3fe1388  mov esi, 0x00
00007f46e3fe138d  mov rax, 0x6238B185B530
00007f46e3fe1397  call rax
00007f46e3fe1399  movaps xmm7, [rsp]
00007f46e3fe139d  add rsp, 0x30
00007f46e3fe13a1  vmovaps xmm0, [rsp]
00007f46e3fe13a6  vmovaps xmm1, [rsp+0x10]
00007f46e3fe13ac  vmovaps xmm2, [rsp+0x20]
00007f46e3fe13b2  vmovaps xmm3, [rsp+0x30]
00007f46e3fe13b8  vmovaps xmm4, [rsp+0x40]
00007f46e3fe13be  vmovaps xmm5, [rsp+0x50]
00007f46e3fe13c4  vmovaps xmm6, [rsp+0x60]
00007f46e3fe13ca  vmovaps xmm8, [rsp+0x70]
00007f46e3fe13d0  vmovaps xmm9, [rsp+0x80]
00007f46e3fe13d9  vmovaps xmm10, [rsp+0x90]
00007f46e3fe13e2  vmovaps xmm11, [rsp+0xA0]
00007f46e3fe13eb  vmovaps xmm12, [rsp+0xB0]
00007f46e3fe13f4  vmovaps xmm13, [rsp+0xC0]
00007f46e3fe13fd  vmovaps xmm14, [rsp+0xD0]
00007f46e3fe1406  vmovaps xmm15, [rsp+0xE0]
00007f46e3fe140f  add rsp, 0xF0
00007f46e3fe1416  pop r11
00007f46e3fe1418  pop r10
00007f46e3fe141a  pop r9
00007f46e3fe141c  pop r8
00007f46e3fe141e  pop rsi
00007f46e3fe141f  pop rdi
00007f46e3fe1420  pop rdx
00007f46e3fe1421  pop rcx
00007f46e3fe1422  pop rax
00007f46e3fe1423  add rsp, 0x08
00007f46e3fe1427  jmp 0x00007F46E3FDC7B4
00007f46e3fe142c  sub rsp, 0x08
00007f46e3fe1430  push rax
00007f46e3fe1431  push rcx
00007f46e3fe1432  push rdx
00007f46e3fe1433  push rdi
00007f46e3fe1434  push rsi
00007f46e3fe1435  push r8
00007f46e3fe1437  push r9
00007f46e3fe1439  push r10
00007f46e3fe143b  push r11
00007f46e3fe143d  sub rsp, 0xF0
00007f46e3fe1444  vmovaps [rsp], xmm0
00007f46e3fe1449  vmovaps [rsp+0x10], xmm1
00007f46e3fe144f  vmovaps [rsp+0x20], xmm2
00007f46e3fe1455  vmovaps [rsp+0x30], xmm3
00007f46e3fe145b  vmovaps [rsp+0x40], xmm4
00007f46e3fe1461  vmovaps [rsp+0x50], xmm5
00007f46e3fe1467  vmovaps [rsp+0x60], xmm6
00007f46e3fe146d  vmovaps [rsp+0x70], xmm7
00007f46e3fe1473  vmovaps [rsp+0x80], xmm8
00007f46e3fe147c  vmovaps [rsp+0x90], xmm10
00007f46e3fe1485  vmovaps [rsp+0xA0], xmm11
00007f46e3fe148e  vmovaps [rsp+0xB0], xmm12
00007f46e3fe1497  vmovaps [rsp+0xC0], xmm13
00007f46e3fe14a0  vmovaps [rsp+0xD0], xmm14
00007f46e3fe14a9  vmovaps [rsp+0xE0], xmm15
00007f46e3fe14b2  sub rsp, 0x30
00007f46e3fe14b6  movaps [rsp], xmm9
00007f46e3fe14bb  movaps [rsp+0x10], xmm13
00007f46e3fe14c1  movaps [rsp+0x20], xmm15
00007f46e3fe14c7  lea rdi, [rsp]
00007f46e3fe14cb  mov esi, 0x00
00007f46e3fe14d0  mov rax, 0x6238B185B530
00007f46e3fe14da  call rax
00007f46e3fe14dc  movaps xmm9, [rsp]
00007f46e3fe14e1  add rsp, 0x30
00007f46e3fe14e5  vmovaps xmm0, [rsp]
00007f46e3fe14ea  vmovaps xmm1, [rsp+0x10]
00007f46e3fe14f0  vmovaps xmm2, [rsp+0x20]
00007f46e3fe14f6  vmovaps xmm3, [rsp+0x30]
00007f46e3fe14fc  vmovaps xmm4, [rsp+0x40]
00007f46e3fe1502  vmovaps xmm5, [rsp+0x50]
00007f46e3fe1508  vmovaps xmm6, [rsp+0x60]
00007f46e3fe150e  vmovaps xmm7, [rsp+0x70]
00007f46e3fe1514  vmovaps xmm8, [rsp+0x80]
00007f46e3fe151d  vmovaps xmm10, [rsp+0x90]
00007f46e3fe1526  vmovaps xmm11, [rsp+0xA0]
00007f46e3fe152f  vmovaps xmm12, [rsp+0xB0]
00007f46e3fe1538  vmovaps xmm13, [rsp+0xC0]
00007f46e3fe1541  vmovaps xmm14, [rsp+0xD0]
00007f46e3fe154a  vmovaps xmm15, [rsp+0xE0]
00007f46e3fe1553  add rsp, 0xF0
00007f46e3fe155a  pop r11
00007f46e3fe155c  pop r10
00007f46e3fe155e  pop r9
00007f46e3fe1560  pop r8
00007f46e3fe1562  pop rsi
00007f46e3fe1563  pop rdi
00007f46e3fe1564  pop rdx
00007f46e3fe1565  pop rcx
00007f46e3fe1566  pop rax
00007f46e3fe1567  add rsp, 0x08
00007f46e3fe156b  jmp 0x00007F46E3FDC7E2
00007f46e3fe1570  sub rsp, 0x08
00007f46e3fe1574  push rax
00007f46e3fe1575  push rcx
00007f46e3fe1576  push rdx
00007f46e3fe1577  push rdi
00007f46e3fe1578  push rsi
00007f46e3fe1579  push r8
00007f46e3fe157b  push r9
00007f46e3fe157d  push r10
00007f46e3fe157f  push r11
00007f46e3fe1581  sub rsp, 0xF0
00007f46e3fe1588  vmovaps [rsp], xmm0
00007f46e3fe158d  vmovaps [rsp+0x10], xmm1
00007f46e3fe1593  vmovaps [rsp+0x20], xmm2
00007f46e3fe1599  vmovaps [rsp+0x30], xmm3
00007f46e3fe159f  vmovaps [rsp+0x40], xmm4
00007f46e3fe15a5  vmovaps [rsp+0x50], xmm5
00007f46e3fe15ab  vmovaps [rsp+0x60], xmm6
00007f46e3fe15b1  vmovaps [rsp+0x70], xmm7
00007f46e3fe15b7  vmovaps [rsp+0x80], xmm8
00007f46e3fe15c0  vmovaps [rsp+0x90], xmm9
00007f46e3fe15c9  vmovaps [rsp+0xA0], xmm10
00007f46e3fe15d2  vmovaps [rsp+0xB0], xmm11
00007f46e3fe15db  vmovaps [rsp+0xC0], xmm12
00007f46e3fe15e4  vmovaps [rsp+0xD0], xmm13
00007f46e3fe15ed  vmovaps [rsp+0xE0], xmm14
00007f46e3fe15f6  sub rsp, 0x30
00007f46e3fe15fa  movaps [rsp], xmm15
00007f46e3fe15ff  movaps [rsp+0x10], xmm11
00007f46e3fe1605  movaps [rsp+0x20], xmm12
00007f46e3fe160b  lea rdi, [rsp]
00007f46e3fe160f  mov esi, 0x00
00007f46e3fe1614  mov rax, 0x6238B185B530
00007f46e3fe161e  call rax
00007f46e3fe1620  movaps xmm15, [rsp]
00007f46e3fe1625  add rsp, 0x30
00007f46e3fe1629  vmovaps xmm0, [rsp]
00007f46e3fe162e  vmovaps xmm1, [rsp+0x10]
00007f46e3fe1634  vmovaps xmm2, [rsp+0x20]
00007f46e3fe163a  vmovaps xmm3, [rsp+0x30]
00007f46e3fe1640  vmovaps xmm4, [rsp+0x40]
00007f46e3fe1646  vmovaps xmm5, [rsp+0x50]
00007f46e3fe164c  vmovaps xmm6, [rsp+0x60]
00007f46e3fe1652  vmovaps xmm7, [rsp+0x70]
00007f46e3fe1658  vmovaps xmm8, [rsp+0x80]
00007f46e3fe1661  vmovaps xmm9, [rsp+0x90]
00007f46e3fe166a  vmovaps xmm10, [rsp+0xA0]
00007f46e3fe1673  vmovaps xmm11, [rsp+0xB0]
00007f46e3fe167c  vmovaps xmm12, [rsp+0xC0]
00007f46e3fe1685  vmovaps xmm13, [rsp+0xD0]
00007f46e3fe168e  vmovaps xmm14, [rsp+0xE0]
00007f46e3fe1697  add rsp, 0xF0
00007f46e3fe169e  pop r11
00007f46e3fe16a0  pop r10
00007f46e3fe16a2  pop r9
00007f46e3fe16a4  pop r8
00007f46e3fe16a6  pop rsi
00007f46e3fe16a7  pop rdi
00007f46e3fe16a8  pop rdx
00007f46e3fe16a9  pop rcx
00007f46e3fe16aa  pop rax
00007f46e3fe16ab  add rsp, 0x08
00007f46e3fe16af  jmp 0x00007F46E3FDC7FD
00007f46e3fe16b4  sub rsp, 0x08
00007f46e3fe16b8  push rax
00007f46e3fe16b9  push rcx
00007f46e3fe16ba  push rdx
00007f46e3fe16bb  push rdi
00007f46e3fe16bc  push rsi
00007f46e3fe16bd  push r8
00007f46e3fe16bf  push r9
00007f46e3fe16c1  push r10
00007f46e3fe16c3  push r11
00007f46e3fe16c5  sub rsp, 0xF0
00007f46e3fe16cc  vmovaps [rsp], xmm0
00007f46e3fe16d1  vmovaps [rsp+0x10], xmm1
00007f46e3fe16d7  vmovaps [rsp+0x20], xmm2
00007f46e3fe16dd  vmovaps [rsp+0x30], xmm3
00007f46e3fe16e3  vmovaps [rsp+0x40], xmm4
00007f46e3fe16e9  vmovaps [rsp+0x50], xmm5
00007f46e3fe16ef  vmovaps [rsp+0x60], xmm6
00007f46e3fe16f5  vmovaps [rsp+0x70], xmm7
00007f46e3fe16fb  vmovaps [rsp+0x80], xmm8
00007f46e3fe1704  vmovaps [rsp+0x90], xmm9
00007f46e3fe170d  vmovaps [rsp+0xA0], xmm10
00007f46e3fe1716  vmovaps [rsp+0xB0], xmm11
00007f46e3fe171f  vmovaps [rsp+0xC0], xmm12
00007f46e3fe1728  vmovaps [rsp+0xD0], xmm14
00007f46e3fe1731  vmovaps [rsp+0xE0], xmm15
00007f46e3fe173a  sub rsp, 0x30
00007f46e3fe173e  movaps [rsp], xmm13
00007f46e3fe1743  movaps [rsp+0x10], xmm10
00007f46e3fe1749  movaps [rsp+0x20], xmm14
00007f46e3fe174f  lea rdi, [rsp]
00007f46e3fe1753  mov esi, 0x00
00007f46e3fe1758  mov rax, 0x6238B185B530
00007f46e3fe1762  call rax
00007f46e3fe1764  movaps xmm13, [rsp]
00007f46e3fe1769  add rsp, 0x30
00007f46e3fe176d  vmovaps xmm0, [rsp]
00007f46e3fe1772  vmovaps xmm1, [rsp+0x10]
00007f46e3fe1778  vmovaps xmm2, [rsp+0x20]
00007f46e3fe177e  vmovaps xmm3, [rsp+0x30]
00007f46e3fe1784  vmovaps xmm4, [rsp+0x40]
00007f46e3fe178a  vmovaps xmm5, [rsp+0x50]
00007f46e3fe1790  vmovaps xmm6, [rsp+0x60]
00007f46e3fe1796  vmovaps xmm7, [rsp+0x70]
00007f46e3fe179c  vmovaps xmm8, [rsp+0x80]
00007f46e3fe17a5  vmovaps xmm9, [rsp+0x90]
00007f46e3fe17ae  vmovaps xmm10, [rsp+0xA0]
00007f46e3fe17b7  vmovaps xmm11, [rsp+0xB0]
00007f46e3fe17c0  vmovaps xmm12, [rsp+0xC0]
00007f46e3fe17c9  vmovaps xmm14, [rsp+0xD0]
00007f46e3fe17d2  vmovaps xmm15, [rsp+0xE0]
00007f46e3fe17db  add rsp, 0xF0
00007f46e3fe17e2  pop r11
00007f46e3fe17e4  pop r10
00007f46e3fe17e6  pop r9
00007f46e3fe17e8  pop r8
00007f46e3fe17ea  pop rsi
00007f46e3fe17eb  pop rdi
00007f46e3fe17ec  pop rdx
00007f46e3fe17ed  pop rcx
00007f46e3fe17ee  pop rax
00007f46e3fe17ef  add rsp, 0x08
00007f46e3fe17f3  jmp 0x00007F46E3FDC820
00007f46e3fe17f8  sub rsp, 0x08
00007f46e3fe17fc  push rax
00007f46e3fe17fd  push rcx
00007f46e3fe17fe  push rdx
00007f46e3fe17ff  push rdi
00007f46e3fe1800  push rsi
00007f46e3fe1801  push r8
00007f46e3fe1803  push r9
00007f46e3fe1805  push r10
00007f46e3fe1807  push r11
00007f46e3fe1809  sub rsp, 0xF0
00007f46e3fe1810  vmovaps [rsp], xmm0
00007f46e3fe1815  vmovaps [rsp+0x10], xmm1
00007f46e3fe181b  vmovaps [rsp+0x20], xmm2
00007f46e3fe1821  vmovaps [rsp+0x30], xmm3
00007f46e3fe1827  vmovaps [rsp+0x40], xmm4
00007f46e3fe182d  vmovaps [rsp+0x50], xmm5
00007f46e3fe1833  vmovaps [rsp+0x60], xmm6
00007f46e3fe1839  vmovaps [rsp+0x70], xmm7
00007f46e3fe183f  vmovaps [rsp+0x80], xmm8
00007f46e3fe1848  vmovaps [rsp+0x90], xmm9
00007f46e3fe1851  vmovaps [rsp+0xA0], xmm10
00007f46e3fe185a  vmovaps [rsp+0xB0], xmm11
00007f46e3fe1863  vmovaps [rsp+0xC0], xmm12
00007f46e3fe186c  vmovaps [rsp+0xD0], xmm13
00007f46e3fe1875  vmovaps [rsp+0xE0], xmm15
00007f46e3fe187e  sub rsp, 0x30
00007f46e3fe1882  movaps [rsp], xmm14
00007f46e3fe1887  movaps [rsp+0x10], xmm1
00007f46e3fe188c  movaps [rsp+0x20], xmm7
00007f46e3fe1891  lea rdi, [rsp]
00007f46e3fe1895  mov esi, 0x00
00007f46e3fe189a  mov rax, 0x6238B185B530
00007f46e3fe18a4  call rax
00007f46e3fe18a6  movaps xmm14, [rsp]
00007f46e3fe18ab  add rsp, 0x30
00007f46e3fe18af  vmovaps xmm0, [rsp]
00007f46e3fe18b4  vmovaps xmm1, [rsp+0x10]
00007f46e3fe18ba  vmovaps xmm2, [rsp+0x20]
00007f46e3fe18c0  vmovaps xmm3, [rsp+0x30]
00007f46e3fe18c6  vmovaps xmm4, [rsp+0x40]
00007f46e3fe18cc  vmovaps xmm5, [rsp+0x50]
00007f46e3fe18d2  vmovaps xmm6, [rsp+0x60]
00007f46e3fe18d8  vmovaps xmm7, [rsp+0x70]
00007f46e3fe18de  vmovaps xmm8, [rsp+0x80]
00007f46e3fe18e7  vmovaps xmm9, [rsp+0x90]
00007f46e3fe18f0  vmovaps xmm10, [rsp+0xA0]
00007f46e3fe18f9  vmovaps xmm11, [rsp+0xB0]
00007f46e3fe1902  vmovaps xmm12, [rsp+0xC0]
00007f46e3fe190b  vmovaps xmm13, [rsp+0xD0]
00007f46e3fe1914  vmovaps xmm15, [rsp+0xE0]
00007f46e3fe191d  add rsp, 0xF0
00007f46e3fe1924  pop r11
00007f46e3fe1926  pop r10
00007f46e3fe1928  pop r9
00007f46e3fe192a  pop r8
00007f46e3fe192c  pop rsi
00007f46e3fe192d  pop rdi
00007f46e3fe192e  pop rdx
00007f46e3fe192f  pop rcx
00007f46e3fe1930  pop rax
00007f46e3fe1931  add rsp, 0x08
00007f46e3fe1935  jmp 0x00007F46E3FDC843
00007f46e3fe193a  sub rsp, 0x08
00007f46e3fe193e  push rax
00007f46e3fe193f  push rcx
00007f46e3fe1940  push rdx
00007f46e3fe1941  push rdi
00007f46e3fe1942  push rsi
00007f46e3fe1943  push r8
00007f46e3fe1945  push r9
00007f46e3fe1947  push r10
00007f46e3fe1949  push r11
00007f46e3fe194b  sub rsp, 0xF0
00007f46e3fe1952  vmovaps [rsp], xmm0
00007f46e3fe1957  vmovaps [rsp+0x10], xmm2
00007f46e3fe195d  vmovaps [rsp+0x20], xmm3
00007f46e3fe1963  vmovaps [rsp+0x30], xmm4
00007f46e3fe1969  vmovaps [rsp+0x40], xmm5
00007f46e3fe196f  vmovaps [rsp+0x50], xmm6
00007f46e3fe1975  vmovaps [rsp+0x60], xmm7
00007f46e3fe197b  vmovaps [rsp+0x70], xmm8
00007f46e3fe1981  vmovaps [rsp+0x80], xmm9
00007f46e3fe198a  vmovaps [rsp+0x90], xmm10
00007f46e3fe1993  vmovaps [rsp+0xA0], xmm11
00007f46e3fe199c  vmovaps [rsp+0xB0], xmm12
00007f46e3fe19a5  vmovaps [rsp+0xC0], xmm13
00007f46e3fe19ae  vmovaps [rsp+0xD0], xmm14
00007f46e3fe19b7  vmovaps [rsp+0xE0], xmm15
00007f46e3fe19c0  sub rsp, 0x30
00007f46e3fe19c4  movaps [rsp], xmm1
00007f46e3fe19c8  movaps [rsp+0x10], xmm8
00007f46e3fe19ce  movaps [rsp+0x20], xmm9
00007f46e3fe19d4  lea rdi, [rsp]
00007f46e3fe19d8  mov esi, 0x00
00007f46e3fe19dd  mov rax, 0x6238B185B530
00007f46e3fe19e7  call rax
00007f46e3fe19e9  movaps xmm1, [rsp]
00007f46e3fe19ed  add rsp, 0x30
00007f46e3fe19f1  vmovaps xmm0, [rsp]
00007f46e3fe19f6  vmovaps xmm2, [rsp+0x10]
00007f46e3fe19fc  vmovaps xmm3, [rsp+0x20]
00007f46e3fe1a02  vmovaps xmm4, [rsp+0x30]
00007f46e3fe1a08  vmovaps xmm5, [rsp+0x40]
00007f46e3fe1a0e  vmovaps xmm6, [rsp+0x50]
00007f46e3fe1a14  vmovaps xmm7, [rsp+0x60]
00007f46e3fe1a1a  vmovaps xmm8, [rsp+0x70]
00007f46e3fe1a20  vmovaps xmm9, [rsp+0x80]
00007f46e3fe1a29  vmovaps xmm10, [rsp+0x90]
00007f46e3fe1a32  vmovaps xmm11, [rsp+0xA0]
00007f46e3fe1a3b  vmovaps xmm12, [rsp+0xB0]
00007f46e3fe1a44  vmovaps xmm13, [rsp+0xC0]
00007f46e3fe1a4d  vmovaps xmm14, [rsp+0xD0]
00007f46e3fe1a56  vmovaps xmm15, [rsp+0xE0]
00007f46e3fe1a5f  add rsp, 0xF0
00007f46e3fe1a66  pop r11
00007f46e3fe1a68  pop r10
00007f46e3fe1a6a  pop r9
00007f46e3fe1a6c  pop r8
00007f46e3fe1a6e  pop rsi
00007f46e3fe1a6f  pop rdi
00007f46e3fe1a70  pop rdx
00007f46e3fe1a71  pop rcx
00007f46e3fe1a72  pop rax
00007f46e3fe1a73  add rsp, 0x08
00007f46e3fe1a77  jmp 0x00007F46E3FDC865
00007f46e3fe1a7c  call 0x00007F46E3EE5940
00007f46e3fe1a81  jmp 0x00007F46E3FDC873
00007f46e3fe1a86  call 0x00007F46E3E0C380
00007f46e3fe1a8b  jmp 0x00007F46E3FDC87D
00007f46e3fe1a90  call 0x00007F46E3E0D600
00007f46e3fe1a95  jmp 0x00007F46E3FDC887
00007f46e3fe1a9a  call 0x00007F46E3DFF540
00007f46e3fe1a9f  jmp 0x00007F46E3FDC891
00007f46e3fe1aa4  int3
00007f46e3fe1aa5  nop [rax+rax*1], ax
00007f46e3fe1aae  nop
00007f46e3fe1ab0  mov rax, [r15+0xF8]
00007f46e3fe1ab7  lea r14, [rax+0x140]
00007f46e3fe1abe  mov r12, [r13+r14*1]
00007f46e3fe1ac3  mov [r15+0xE8], r12
00007f46e3fe1aca  lea r14, [rax+0x130]
00007f46e3fe1ad1  mov r12, [r13+r14*1]
00007f46e3fe1ad6  lea r14, [rax+0x138]
00007f46e3fe1add  mov r11, [r13+r14*1]
00007f46e3fe1ae2  movq xmm1, r12
00007f46e3fe1ae7  movq xmm15, r11
00007f46e3fe1aec  movq xmm1, xmm1
00007f46e3fe1af0  movq xmm1, xmm1
00007f46e3fe1af4  movaps [r15+0x1A0], xmm1
00007f46e3fe1afc  movq xmm15, xmm15
00007f46e3fe1b01  movq xmm15, xmm15
00007f46e3fe1b06  movaps [r15+0x190], xmm15
00007f46e3fe1b0e  lea r14, [rax+0x120]
00007f46e3fe1b15  mov r12, [r13+r14*1]
00007f46e3fe1b1a  lea r14, [rax+0x128]
00007f46e3fe1b21  mov r11, [r13+r14*1]
00007f46e3fe1b26  movq xmm1, r12
00007f46e3fe1b2b  movq xmm15, r11
00007f46e3fe1b30  movq xmm1, xmm1
00007f46e3fe1b34  movq xmm1, xmm1
00007f46e3fe1b38  movaps [r15+0x1C0], xmm1
00007f46e3fe1b40  movq xmm15, xmm15
00007f46e3fe1b45  movq xmm15, xmm15
00007f46e3fe1b4a  movaps [r15+0x1B0], xmm15
00007f46e3fe1b52  lea r14, [rax+0x110]
00007f46e3fe1b59  mov r12, [r13+r14*1]
00007f46e3fe1b5e  lea r14, [rax+0x118]
00007f46e3fe1b65  mov r11, [r13+r14*1]
00007f46e3fe1b6a  movq xmm1, r12
00007f46e3fe1b6f  movq xmm15, r11
00007f46e3fe1b74  movq xmm1, xmm1
00007f46e3fe1b78  movq xmm1, xmm1
00007f46e3fe1b7c  movaps [r15+0x1E0], xmm1
00007f46e3fe1b84  movq xmm15, xmm15
00007f46e3fe1b89  movq xmm15, xmm15
00007f46e3fe1b8e  movaps [r15+0x1D0], xmm15
00007f46e3fe1b96  lea r14, [rax+0x100]
00007f46e3fe1b9d  mov r12, [r13+r14*1]
00007f46e3fe1ba2  lea r14, [rax+0x108]
00007f46e3fe1ba9  mov r11, [r13+r14*1]
00007f46e3fe1bae  movq xmm1, r12
00007f46e3fe1bb3  movq xmm15, r11
00007f46e3fe1bb8  movq xmm1, xmm1
00007f46e3fe1bbc  movq xmm1, xmm1
00007f46e3fe1bc0  movaps [r15+0x200], xmm1
00007f46e3fe1bc8  movq xmm15, xmm15
00007f46e3fe1bcd  movq xmm15, xmm15
00007f46e3fe1bd2  movaps [r15+0x1F0], xmm15
00007f46e3fe1bda  mov qword ptr [r15+0x40], 0x430000
00007f46e3fe1be2  mov r14d, 0x430510
00007f46e3fe1be8  mov r12, [r13+r14*1]
00007f46e3fe1bed  movq xmm1, r12
00007f46e3fe1bf2  lea r14, [rax+0x150]
00007f46e3fe1bf9  mov [r15+0xF8], r14
00007f46e3fe1c00  mov rax, [r15+0x50]
00007f46e3fe1c04  movups xmm15, [r13+rax*1]
00007f46e3fe1c0a  movaps [r15+0x120], xmm15
00007f46e3fe1c12  mov qword ptr [r15+0x48], 0x10
00007f46e3fe1c1a  xor eax, eax
00007f46e3fe1c1c  mov r14d, 0x10
00007f46e3fe1c22  mov r12d, 0x200
00007f46e3fe1c28  cmp r14, r12
00007f46e3fe1c2b  cmc
00007f46e3fe1c2c  lahf
00007f46e3fe1c2d  seto al
00007f46e3fe1c30  mov [r15+0x108], eax
00007f46e3fe1c37  pextrq rax, xmm15, 0x01
00007f46e3fe1c3e  movq xmm14, rax
00007f46e3fe1c43  movaps [r15+0x130], xmm14
00007f46e3fe1c4b  movq rax, xmm1
00007f46e3fe1c50  movq r14, xmm15
00007f46e3fe1c55  vmovq xmm1, rax
00007f46e3fe1c5a  vmovq xmm15, r14
00007f46e3fe1c5f  movaps xmm13, xmm1
00007f46e3fe1c63  addsd xmm13, xmm15
00007f46e3fe1c68  ucomisd xmm13, xmm13
00007f46e3fe1c6d  jp 0x00007F46E3FE1D86
00007f46e3fe1c73  movq xmm13, xmm13
00007f46e3fe1c78  movq rax, xmm13
00007f46e3fe1c7d  movq r14, xmm14
00007f46e3fe1c82  vmovq xmm1, rax
00007f46e3fe1c87  vmovq xmm15, r14
00007f46e3fe1c8c  movaps xmm14, xmm1
00007f46e3fe1c90  addsd xmm14, xmm15
00007f46e3fe1c95  ucomisd xmm14, xmm14
00007f46e3fe1c9a  jp 0x00007F46E3FE1DCE
00007f46e3fe1ca0  movq xmm14, xmm14
00007f46e3fe1ca5  movaps [r15+0x110], xmm14
00007f46e3fe1cad  mov eax, [r15+0x108]
00007f46e3fe1cb4  sahf
00007f46e3fe1cb5  jnz 0x00007F46E3FE1CE7
00007f46e3fe1cb7  cmp dword ptr [r15+0x318], 0x00
00007f46e3fe1cbf  jz 0x00007F46E3FE1FE0
00007f46e3fe1cc5  nop [rax+rax*1], ax
00007f46e3fe1cce  nop [rax+rax*1], eax
00007f46e3fe1cd6  mov eax, 0x410490
00007f46e3fe1cdb  mov [r15+0x100], rax
00007f46e3fe1ce2  jmp 0x00007F46E3DFE110
00007f46e3fe1ce7  cmp dword ptr [r15+0x318], 0x00
00007f46e3fe1cef  jz 0x00007F46E3FE1E20
00007f46e3fe1cf5  nop [rax+rax*1], ax
00007f46e3fe1cfe  nop [rax+rax*1], eax
00007f46e3fe1d06  mov eax, 0x410474
00007f46e3fe1d0b  mov [r15+0x100], rax
00007f46e3fe1d12  jmp 0x00007F46E3DFE110
00007f46e3fe1d17  int3
00007f46e3fe1d18  call 0x00007F46E3EE27E0
00007f46e3fe1d1d  jmp 0x00007F46E3FE1AC3
00007f46e3fe1d22  call 0x00007F46E3EE27E0
00007f46e3fe1d27  jmp 0x00007F46E3FE1AD6
00007f46e3fe1d2c  call 0x00007F46E3EE1570
00007f46e3fe1d31  jmp 0x00007F46E3FE1AE2
00007f46e3fe1d36  call 0x00007F46E3EE27E0
00007f46e3fe1d3b  jmp 0x00007F46E3FE1B1A
00007f46e3fe1d40  call 0x00007F46E3EE1570
00007f46e3fe1d45  jmp 0x00007F46E3FE1B26
00007f46e3fe1d4a  call 0x00007F46E3EE27E0
00007f46e3fe1d4f  jmp 0x00007F46E3FE1B5E
00007f46e3fe1d54  call 0x00007F46E3EE1570
00007f46e3fe1d59  jmp 0x00007F46E3FE1B6A
00007f46e3fe1d5e  call 0x00007F46E3EE27E0
00007f46e3fe1d63  jmp 0x00007F46E3FE1BA2
00007f46e3fe1d68  call 0x00007F46E3EE1570
00007f46e3fe1d6d  jmp 0x00007F46E3FE1BAE
00007f46e3fe1d72  call 0x00007F46E3EE27E0
00007f46e3fe1d77  jmp 0x00007F46E3FE1BED
00007f46e3fe1d7c  call 0x00007F46E3E0E760
00007f46e3fe1d81  jmp 0x00007F46E3FE1C0A
00007f46e3fe1d86  ucomisd xmm1, xmm15
00007f46e3fe1d8b  jp 0x00007F46E3FE1D9A
00007f46e3fe1d8d  movaps xmm13, [0x00007F46E3BFE060]
00007f46e3fe1d95  jmp 0x00007F46E3FE1C73
00007f46e3fe1d9a  vxorps xmm0, xmm1, xmm15
00007f46e3fe1d9f  pextrw eax, xmm0, 0x03
00007f46e3fe1da4  and eax, 0x7FF8
00007f46e3fe1da9  cmp eax, 0x08
00007f46e3fe1dac  jnz 0x00007F46E3FE1C73
00007f46e3fe1db2  movq rax, xmm15
00007f46e3fe1db7  shl rax, 0x0D
00007f46e3fe1dbb  jbe 0x00007F46E3FE1C73
00007f46e3fe1dc1  vorps xmm13, xmm15, [0x00007F46E3BFE070]
00007f46e3fe1dc9  jmp 0x00007F46E3FE1C73
00007f46e3fe1dce  ucomisd xmm1, xmm15
00007f46e3fe1dd3  jp 0x00007F46E3FE1DE2
00007f46e3fe1dd5  movaps xmm14, [0x00007F46E3BFE060]
00007f46e3fe1ddd  jmp 0x00007F46E3FE1CA0
00007f46e3fe1de2  vxorps xmm0, xmm1, xmm15
00007f46e3fe1de7  pextrw eax, xmm0, 0x03
00007f46e3fe1dec  and eax, 0x7FF8
00007f46e3fe1df1  cmp eax, 0x08
00007f46e3fe1df4  jnz 0x00007F46E3FE1CA0
00007f46e3fe1dfa  movq rax, xmm15
00007f46e3fe1dff  shl rax, 0x0D
00007f46e3fe1e03  jbe 0x00007F46E3FE1CA0
00007f46e3fe1e09  vorps xmm14, xmm15, [0x00007F46E3BFE070]
00007f46e3fe1e11  jmp 0x00007F46E3FE1CA0
00007f46e3fe1e16  int3
00007f46e3fe1e17  nop [rax+rax*1], ax
00007f46e3fe1e20  mov rax, [r15+0x48]
00007f46e3fe1e24  mov r14, [r15+0x50]
00007f46e3fe1e28  lea r12, [r14+rax*1]
00007f46e3fe1e2c  movups xmm1, [r13+r12*1]
00007f46e3fe1e32  movaps [r15+0x120], xmm1
00007f46e3fe1e3a  lea r14, [rax+0x10]
00007f46e3fe1e3e  mov [r15+0x48], r14
00007f46e3fe1e42  xor eax, eax
00007f46e3fe1e44  mov r12d, 0x200
00007f46e3fe1e4a  cmp r14, r12
00007f46e3fe1e4d  cmc
00007f46e3fe1e4e  lahf
00007f46e3fe1e4f  seto al
00007f46e3fe1e52  mov [r15+0x108], eax
00007f46e3fe1e59  pextrq rax, xmm1, 0x01
00007f46e3fe1e60  movq xmm15, rax
00007f46e3fe1e65  movaps [r15+0x130], xmm15
00007f46e3fe1e6d  movaps xmm14, [r15+0x110]
00007f46e3fe1e75  movq rax, xmm14
00007f46e3fe1e7a  movq r14, xmm1
00007f46e3fe1e7f  vmovq xmm1, rax
00007f46e3fe1e84  vmovq xmm14, r14
00007f46e3fe1e89  movaps xmm13, xmm1
00007f46e3fe1e8d  addsd xmm13, xmm14
00007f46e3fe1e92  ucomisd xmm13, xmm13
00007f46e3fe1e97  jp 0x00007F46E3FE1F4C
00007f46e3fe1e9d  movq xmm13, xmm13
00007f46e3fe1ea2  movq rax, xmm13
00007f46e3fe1ea7  movq r14, xmm15
00007f46e3fe1eac  vmovq xmm1, rax
00007f46e3fe1eb1  vmovq xmm15, r14
00007f46e3fe1eb6  movaps xmm14, xmm1
00007f46e3fe1eba  addsd xmm14, xmm15
00007f46e3fe1ebf  ucomisd xmm14, xmm14
00007f46e3fe1ec4  jp 0x00007F46E3FE1F94
00007f46e3fe1eca  movq xmm14, xmm14
00007f46e3fe1ecf  movaps [r15+0x110], xmm14
00007f46e3fe1ed7  mov eax, [r15+0x108]
00007f46e3fe1ede  sahf
00007f46e3fe1edf  jnz 0x00007F46E3FE1F11
00007f46e3fe1ee1  cmp dword ptr [r15+0x318], 0x00
00007f46e3fe1ee9  jz 0x00007F46E3FE1FE0
00007f46e3fe1eef  nop [rax+rax*1], ax
00007f46e3fe1ef8  nop [rax+rax*1], eax
00007f46e3fe1f00  mov eax, 0x410490
00007f46e3fe1f05  mov [r15+0x100], rax
00007f46e3fe1f0c  jmp 0x00007F46E3DFE110
00007f46e3fe1f11  cmp dword ptr [r15+0x318], 0x00
00007f46e3fe1f19  jz 0x00007F46E3FE1E20
00007f46e3fe1f1f  nop [rax+rax*1], ax
00007f46e3fe1f28  nop [rax+rax*1], eax
00007f46e3fe1f30  mov eax, 0x410474
00007f46e3fe1f35  mov [r15+0x100], rax
00007f46e3fe1f3c  jmp 0x00007F46E3DFE110
00007f46e3fe1f41  int3
00007f46e3fe1f42  call 0x00007F46E3EB52F0
00007f46e3fe1f47  jmp 0x00007F46E3FE1E32
00007f46e3fe1f4c  ucomisd xmm1, xmm14
00007f46e3fe1f51  jp 0x00007F46E3FE1F60
00007f46e3fe1f53  movaps xmm13, [0x00007F46E3BFE060]
00007f46e3fe1f5b  jmp 0x00007F46E3FE1E9D
00007f46e3fe1f60  vxorps xmm0, xmm1, xmm14
00007f46e3fe1f65  pextrw eax, xmm0, 0x03
00007f46e3fe1f6a  and eax, 0x7FF8
00007f46e3fe1f6f  cmp eax, 0x08
00007f46e3fe1f72  jnz 0x00007F46E3FE1E9D
00007f46e3fe1f78  movq rax, xmm14
00007f46e3fe1f7d  shl rax, 0x0D
00007f46e3fe1f81  jbe 0x00007F46E3FE1E9D
00007f46e3fe1f87  vorps xmm13, xmm14, [0x00007F46E3BFE070]
00007f46e3fe1f8f  jmp 0x00007F46E3FE1E9D
00007f46e3fe1f94  ucomisd xmm1, xmm15
00007f46e3fe1f99  jp 0x00007F46E3FE1FA8
00007f46e3fe1f9b  movaps xmm14, [0x00007F46E3BFE060]
00007f46e3fe1fa3  jmp 0x00007F46E3FE1ECA
00007f46e3fe1fa8  vxorps xmm0, xmm1, xmm15
00007f46e3fe1fad  pextrw eax, xmm0, 0x03
00007f46e3fe1fb2  and eax, 0x7FF8
00007f46e3fe1fb7  cmp eax, 0x08
00007f46e3fe1fba  jnz 0x00007F46E3FE1ECA
00007f46e3fe1fc0  movq rax, xmm15
00007f46e3fe1fc5  shl rax, 0x0D
00007f46e3fe1fc9  jbe 0x00007F46E3FE1ECA
00007f46e3fe1fcf  vorps xmm14, xmm15, [0x00007F46E3BFE070]
00007f46e3fe1fd7  jmp 0x00007F46E3FE1ECA
00007f46e3fe1fdc  int3
00007f46e3fe1fdd  nop [rax], eax
00007f46e3fe1fe0  mov rax, [r15+0x40]
00007f46e3fe1fe4  lea r14, [rax+0x510]
00007f46e3fe1feb  movaps xmm1, [r15+0x110]
00007f46e3fe1ff3  movq rax, xmm1
00007f46e3fe1ff8  mov [r13+r14*1], rax
00007f46e3fe1ffd  mov rax, [r15+0xF0]
00007f46e3fe2004  mov [r15+0x100], rax
00007f46e3fe200b  jmp 0x00007F46E3FCE5C0
00007f46e3fe2010  int3
00007f46e3fe2011  call 0x00007F46E3ED5EB0
00007f46e3fe2016  jmp 0x00007F46E3FE1FFD
00007f46e3fe201b  int3
00007f46e3fe201c  nop [rax], eax
00007f46e3fe2020  mov qword ptr [r15+0x100], 0x04
00007f46e3fe202b  mov esi, 0x00
00007f46e3fe2030  mov edx, 0x09
00007f46e3fe2035  mov rdi, 0x7FFD0EF649A0
00007f46e3fe203f  mov rax, 0x6238B16EE970
00007f46e3fe2049  call rax
00007f46e3fe204b  cmp dword ptr [r15+0x318], 0x00
00007f46e3fe2053  jnz 0x00007F46E3DFE110
00007f46e3fe2059  jmp 0x00007F46E3DFE0A0
00007f46e3fe205e  int3
00007f46e3fe205f  int3
