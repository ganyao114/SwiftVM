00007d0bb21ce69b  nop [rax+rax*1], eax
00007d0bb21ce6a0  mov rax, [r15+0xF8]
00007d0bb21ce6a7  lea r14, [rax-0x1E0]
00007d0bb21ce6ae  mov [r15+0xF8], r14
00007d0bb21ce6b5  lea rax, [r14+0x1D0]
00007d0bb21ce6bc  mov r12, [r15+0xA0]
00007d0bb21ce6c3  mov r11, [r15+0x98]
00007d0bb21ce6ca  mov [r13+rax*1], r12
00007d0bb21ce6cf  lea rax, [r14+0x1D8]
00007d0bb21ce6d6  mov [r13+rax*1], r11
00007d0bb21ce6db  mov eax, 0x420AA0
00007d0bb21ce6e0  movups xmm1, [r13+rax*1]
00007d0bb21ce6e6  mov eax, 0x420A30
00007d0bb21ce6eb  movups xmm15, [r13+rax*1]
00007d0bb21ce6f1  mov eax, 0x420AC0
00007d0bb21ce6f6  movups xmm14, [r13+rax*1]
00007d0bb21ce6fc  mov eax, 0x420A60
00007d0bb21ce701  movups xmm13, [r13+rax*1]
00007d0bb21ce707  mov qword ptr [r15+0x98], 0x430CD0
00007d0bb21ce712  mov eax, 0x420AD0
00007d0bb21ce717  movups xmm12, [r13+rax*1]
00007d0bb21ce71d  mov eax, 0x430CD0
00007d0bb21ce722  movups [r13+rax*1], xmm1
00007d0bb21ce728  mov eax, 0x430CE0
00007d0bb21ce72d  movups [r13+rax*1], xmm15
00007d0bb21ce733  mov eax, 0x430CF0
00007d0bb21ce738  movups [r13+rax*1], xmm14
00007d0bb21ce73e  mov eax, 0x430D00
00007d0bb21ce743  movups [r13+rax*1], xmm13
00007d0bb21ce749  mov eax, 0x420A20
00007d0bb21ce74e  movups xmm14, [r13+rax*1]
00007d0bb21ce754  mov eax, 0x420A10
00007d0bb21ce759  movups xmm13, [r13+rax*1]
00007d0bb21ce75f  mov eax, 0x430DD0
00007d0bb21ce764  movups [r13+rax*1], xmm1
00007d0bb21ce76a  mov eax, 0x430DE0
00007d0bb21ce76f  movups [r13+rax*1], xmm15
00007d0bb21ce775  mov eax, 0x430D10
00007d0bb21ce77a  movups [r13+rax*1], xmm12
00007d0bb21ce780  mov eax, 0x430D20
00007d0bb21ce785  movups [r13+rax*1], xmm14
00007d0bb21ce78b  mov eax, 0x420A00
00007d0bb21ce790  movups xmm1, [r13+rax*1]
00007d0bb21ce796  mov eax, 0x420A70
00007d0bb21ce79b  movups xmm15, [r13+rax*1]
00007d0bb21ce7a1  mov eax, 0x430D30
00007d0bb21ce7a6  movups [r13+rax*1], xmm13
00007d0bb21ce7ac  mov eax, 0x430D40
00007d0bb21ce7b1  movups [r13+rax*1], xmm1
00007d0bb21ce7b7  mov eax, 0x420A80
00007d0bb21ce7bc  movups xmm1, [r13+rax*1]
00007d0bb21ce7c2  mov eax, 0x420A50
00007d0bb21ce7c7  movups xmm14, [r13+rax*1]
00007d0bb21ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007d0bb21ce7d5  mov eax, 0x430D50
00007d0bb21ce7da  movups [r13+rax*1], xmm15
00007d0bb21ce7e0  mov eax, 0x430D60
00007d0bb21ce7e5  movups [r13+rax*1], xmm1
00007d0bb21ce7eb  mov eax, 0x420AF0
00007d0bb21ce7f0  movups xmm1, [r13+rax*1]
00007d0bb21ce7f6  mov eax, 0x420B00
00007d0bb21ce7fb  movups xmm15, [r13+rax*1]
00007d0bb21ce801  movaps [r15+0x150], xmm15
00007d0bb21ce809  mov qword ptr [r15+0xA0], 0x3E8
00007d0bb21ce814  mov eax, 0x430D70
00007d0bb21ce819  movups [r13+rax*1], xmm14
00007d0bb21ce81f  mov eax, 0x430D80
00007d0bb21ce824  movups [r13+rax*1], xmm1
00007d0bb21ce82a  mov eax, 0x420AE0
00007d0bb21ce82f  movups xmm1, [r13+rax*1]
00007d0bb21ce835  mov eax, 0x420A90
00007d0bb21ce83a  movups xmm14, [r13+rax*1]
00007d0bb21ce840  movaps [r15+0x140], xmm14
00007d0bb21ce848  lea rax, [r14+0x180]
00007d0bb21ce84f  movq xmm13, qword ptr [r15+0x200]
00007d0bb21ce858  movq xmm12, qword ptr [r15+0x1F0]
00007d0bb21ce861  movq r12, xmm13
00007d0bb21ce866  movq r11, xmm12
00007d0bb21ce86b  mov [r13+rax*1], r12
00007d0bb21ce870  lea rax, [r14+0x188]
00007d0bb21ce877  mov [r13+rax*1], r11
00007d0bb21ce87c  mov eax, 0x430D90
00007d0bb21ce881  movups [r13+rax*1], xmm15
00007d0bb21ce887  mov eax, 0x430DA0
00007d0bb21ce88c  movups [r13+rax*1], xmm1
00007d0bb21ce892  mov eax, 0x420AB0
00007d0bb21ce897  movups xmm1, [r13+rax*1]
00007d0bb21ce89d  mov eax, 0x420B18
00007d0bb21ce8a2  mov r12, [r13+rax*1]
00007d0bb21ce8a7  movq xmm15, r12
00007d0bb21ce8ac  mov qword ptr [r15+0x40], 0x420B20
00007d0bb21ce8b4  mov eax, 0x430DB0
00007d0bb21ce8b9  movups [r13+rax*1], xmm14
00007d0bb21ce8bf  mov eax, 0x430DC0
00007d0bb21ce8c4  movups [r13+rax*1], xmm1
00007d0bb21ce8ca  mov eax, 0x420B80
00007d0bb21ce8cf  movups xmm1, [r13+rax*1]
00007d0bb21ce8d5  movq rax, xmm15
00007d0bb21ce8da  mov r12d, 0x430DF0
00007d0bb21ce8e0  mov [r13+r12*1], rax
00007d0bb21ce8e5  mov eax, 0x420B60
00007d0bb21ce8ea  movups xmm15, [r13+rax*1]
00007d0bb21ce8f0  mov eax, 0x420B70
00007d0bb21ce8f5  movups xmm14, [r13+rax*1]
00007d0bb21ce8fb  lea rax, [r14+0x160]
00007d0bb21ce902  movups [r13+rax*1], xmm1
00007d0bb21ce908  lea rax, [r14+0x190]
00007d0bb21ce90f  movq xmm1, qword ptr [r15+0x1E0]
00007d0bb21ce918  movq xmm13, qword ptr [r15+0x1D0]
00007d0bb21ce921  movq r12, xmm1
00007d0bb21ce926  movq r11, xmm13
00007d0bb21ce92b  mov [r13+rax*1], r12
00007d0bb21ce930  lea rax, [r14+0x198]
00007d0bb21ce937  mov [r13+rax*1], r11
00007d0bb21ce93c  lea rax, [r14+0x140]
00007d0bb21ce943  movups [r13+rax*1], xmm15
00007d0bb21ce949  lea rax, [r14+0x150]
00007d0bb21ce950  movups [r13+rax*1], xmm14
00007d0bb21ce956  mov eax, 0x420B20
00007d0bb21ce95b  movups xmm1, [r13+rax*1]
00007d0bb21ce961  mov eax, 0x420B30
00007d0bb21ce966  movups xmm15, [r13+rax*1]
00007d0bb21ce96c  movaps [r15+0x120], xmm15
00007d0bb21ce974  lea rax, [r14+0x1A0]
00007d0bb21ce97b  movq xmm14, qword ptr [r15+0x1C0]
00007d0bb21ce984  movq xmm13, qword ptr [r15+0x1B0]
00007d0bb21ce98d  movq r12, xmm14
00007d0bb21ce992  movq r11, xmm13
00007d0bb21ce997  mov [r13+rax*1], r12
00007d0bb21ce99c  lea rax, [r14+0x1A8]
00007d0bb21ce9a3  mov [r13+rax*1], r11
00007d0bb21ce9a8  lea rax, [r14+0x1B0]
00007d0bb21ce9af  movq xmm14, qword ptr [r15+0x1A0]
00007d0bb21ce9b8  movq xmm13, qword ptr [r15+0x190]
00007d0bb21ce9c1  movq r12, xmm14
00007d0bb21ce9c6  movq r11, xmm13
00007d0bb21ce9cb  mov [r13+rax*1], r12
00007d0bb21ce9d0  lea rax, [r14+0x1B8]
00007d0bb21ce9d7  mov [r13+rax*1], r11
00007d0bb21ce9dc  lea rax, [r14+0x100]
00007d0bb21ce9e3  movups [r13+rax*1], xmm1
00007d0bb21ce9e9  lea rax, [r14+0x110]
00007d0bb21ce9f0  movups [r13+rax*1], xmm15
00007d0bb21ce9f6  mov eax, 0x420B40
00007d0bb21ce9fb  movups xmm1, [r13+rax*1]
00007d0bb21cea01  mov eax, 0x420B50
00007d0bb21cea06  movups xmm15, [r13+rax*1]
00007d0bb21cea0c  movaps [r15+0x110], xmm1
00007d0bb21cea14  movaps [r15+0x130], xmm15
00007d0bb21cea1c  lea rax, [r14+0x1C0]
00007d0bb21cea23  mov r12, [r15+0xE8]
00007d0bb21cea2a  mov r11, [r15+0xF0]
00007d0bb21cea31  mov [r13+rax*1], r12
00007d0bb21cea36  lea rax, [r14+0x1C8]
00007d0bb21cea3d  mov [r13+rax*1], r11
00007d0bb21cea42  mov eax, 0x430DF8
00007d0bb21cea47  mov r12d, 0x421DF8D3
00007d0bb21cea4d  mov [r13+rax*1], r12d
00007d0bb21cea52  lea rax, [r14+0x120]
00007d0bb21cea59  movups [r13+rax*1], xmm1
00007d0bb21cea5f  lea rax, [r14+0x130]
00007d0bb21cea66  movups [r13+rax*1], xmm15
00007d0bb21cea6c  lea rax, [r14+0x100]
00007d0bb21cea73  mov [r15], rax
00007d0bb21cea76  mov qword ptr [r15+0x08], 0x430CD0
00007d0bb21cea7e  mov qword ptr [r15+0x10], 0x12C
00007d0bb21cea86  mov qword ptr [r15+0xF0], 0x410284
00007d0bb21cea91  mov r14d, [r15+0x320]
00007d0bb21cea98  mov eax, 0x410284
00007d0bb21cea9d  mov rcx, 0x7D0BB21D07C0
00007d0bb21ceaa7  mov [r15+r14*8+0x328], rax
00007d0bb21ceaaf  mov [r15+r14*8+0x368], rcx
00007d0bb21ceab7  add r14d, 0x01
00007d0bb21ceabb  and r14d, 0x07
00007d0bb21ceabf  mov [r15+0x320], r14d
00007d0bb21ceac6  cmp dword ptr [r15+0x318], 0x00
00007d0bb21ceace  jz 0x00007D0BB21CED70
00007d0bb21cead4  nop [rax+rax*1], ax
00007d0bb21ceadd  nop [rax+rax*1], eax
00007d0bb21ceae5  mov eax, 0x410728
00007d0bb21ceaea  mov [r15+0x100], rax
00007d0bb21ceaf1  jmp 0x00007D0BB1FFE110
00007d0bb21ceaf6  int3
00007d0bb21ceaf7  call 0x00007D0BB200BC20
00007d0bb21ceafc  jmp 0x00007D0BB21CE6CF
00007d0bb21ceb01  call 0x00007D0BB200A9A0
00007d0bb21ceb06  jmp 0x00007D0BB21CE6DB
00007d0bb21ceb0b  call 0x00007D0BB1FFF430
00007d0bb21ceb10  jmp 0x00007D0BB21CE6E6
00007d0bb21ceb15  call 0x00007D0BB200E760
00007d0bb21ceb1a  jmp 0x00007D0BB21CE6F1
00007d0bb21ceb1f  call 0x00007D0BB200D4E0
00007d0bb21ceb24  jmp 0x00007D0BB21CE6FC
00007d0bb21ceb29  call 0x00007D0BB200C260
00007d0bb21ceb2e  jmp 0x00007D0BB21CE707
00007d0bb21ceb33  call 0x00007D0BB200AFE0
00007d0bb21ceb38  jmp 0x00007D0BB21CE71D
00007d0bb21ceb3d  call 0x00007D0BB1FFF540
00007d0bb21ceb42  jmp 0x00007D0BB21CE728
00007d0bb21ceb47  call 0x00007D0BB200E880
00007d0bb21ceb4c  jmp 0x00007D0BB21CE733
00007d0bb21ceb51  call 0x00007D0BB200D600
00007d0bb21ceb56  jmp 0x00007D0BB21CE73E
00007d0bb21ceb5b  call 0x00007D0BB200C380
00007d0bb21ceb60  jmp 0x00007D0BB21CE749
00007d0bb21ceb65  call 0x00007D0BB200D4E0
00007d0bb21ceb6a  jmp 0x00007D0BB21CE754
00007d0bb21ceb6f  call 0x00007D0BB200C260
00007d0bb21ceb74  jmp 0x00007D0BB21CE75F
00007d0bb21ceb79  call 0x00007D0BB1FFF540
00007d0bb21ceb7e  jmp 0x00007D0BB21CE76A
00007d0bb21ceb83  call 0x00007D0BB200E880
00007d0bb21ceb88  jmp 0x00007D0BB21CE775
00007d0bb21ceb8d  call 0x00007D0BB200B100
00007d0bb21ceb92  jmp 0x00007D0BB21CE780
00007d0bb21ceb97  call 0x00007D0BB200D600
00007d0bb21ceb9c  jmp 0x00007D0BB21CE78B
00007d0bb21ceba1  call 0x00007D0BB1FFF430
00007d0bb21ceba6  jmp 0x00007D0BB21CE796
00007d0bb21cebab  call 0x00007D0BB200E760
00007d0bb21cebb0  jmp 0x00007D0BB21CE7A1
00007d0bb21cebb5  call 0x00007D0BB200C380
00007d0bb21cebba  jmp 0x00007D0BB21CE7AC
00007d0bb21cebbf  call 0x00007D0BB1FFF540
00007d0bb21cebc4  jmp 0x00007D0BB21CE7B7
00007d0bb21cebc9  call 0x00007D0BB1FFF430
00007d0bb21cebce  jmp 0x00007D0BB21CE7C2
00007d0bb21cebd3  call 0x00007D0BB200D4E0
00007d0bb21cebd8  jmp 0x00007D0BB21CE7CD
00007d0bb21cebdd  call 0x00007D0BB200E880
00007d0bb21cebe2  jmp 0x00007D0BB21CE7E0
00007d0bb21cebe7  call 0x00007D0BB1FFF540
00007d0bb21cebec  jmp 0x00007D0BB21CE7EB
00007d0bb21cebf1  call 0x00007D0BB1FFF430
00007d0bb21cebf6  jmp 0x00007D0BB21CE7F6
00007d0bb21cebfb  call 0x00007D0BB200E760
00007d0bb21cec00  jmp 0x00007D0BB21CE801
00007d0bb21cec05  call 0x00007D0BB200D600
00007d0bb21cec0a  jmp 0x00007D0BB21CE81F
00007d0bb21cec0f  call 0x00007D0BB1FFF540
00007d0bb21cec14  jmp 0x00007D0BB21CE82A
00007d0bb21cec19  call 0x00007D0BB1FFF430
00007d0bb21cec1e  jmp 0x00007D0BB21CE835
00007d0bb21cec23  call 0x00007D0BB200D4E0
00007d0bb21cec28  jmp 0x00007D0BB21CE840
00007d0bb21cec2d  call 0x00007D0BB200BC20
00007d0bb21cec32  jmp 0x00007D0BB21CE870
00007d0bb21cec37  call 0x00007D0BB200A9A0
00007d0bb21cec3c  jmp 0x00007D0BB21CE87C
00007d0bb21cec41  call 0x00007D0BB200E880
00007d0bb21cec46  jmp 0x00007D0BB21CE887
00007d0bb21cec4b  call 0x00007D0BB1FFF540
00007d0bb21cec50  jmp 0x00007D0BB21CE892
00007d0bb21cec55  call 0x00007D0BB1FFF430
00007d0bb21cec5a  jmp 0x00007D0BB21CE89D
00007d0bb21cec5f  call 0x00007D0BB200B720
00007d0bb21cec64  jmp 0x00007D0BB21CE8A7
00007d0bb21cec69  call 0x00007D0BB200D600
00007d0bb21cec6e  jmp 0x00007D0BB21CE8BF
00007d0bb21cec73  call 0x00007D0BB1FFF540
00007d0bb21cec78  jmp 0x00007D0BB21CE8CA
00007d0bb21cec7d  call 0x00007D0BB1FFF430
00007d0bb21cec82  jmp 0x00007D0BB21CE8D5
00007d0bb21cec87  call 0x00007D0BB20B4CB0
00007d0bb21cec8c  jmp 0x00007D0BB21CE8E5
00007d0bb21cec91  call 0x00007D0BB200E760
00007d0bb21cec96  jmp 0x00007D0BB21CE8F0
00007d0bb21cec9b  call 0x00007D0BB200D4E0
00007d0bb21ceca0  jmp 0x00007D0BB21CE8FB
00007d0bb21ceca5  call 0x00007D0BB1FFF540
00007d0bb21cecaa  jmp 0x00007D0BB21CE908
00007d0bb21cecaf  call 0x00007D0BB200BC20
00007d0bb21cecb4  jmp 0x00007D0BB21CE930
00007d0bb21cecb9  call 0x00007D0BB200A9A0
00007d0bb21cecbe  jmp 0x00007D0BB21CE93C
00007d0bb21cecc3  call 0x00007D0BB200E880
00007d0bb21cecc8  jmp 0x00007D0BB21CE949
00007d0bb21ceccd  call 0x00007D0BB200D600
00007d0bb21cecd2  jmp 0x00007D0BB21CE956
00007d0bb21cecd7  call 0x00007D0BB1FFF430
00007d0bb21cecdc  jmp 0x00007D0BB21CE961
00007d0bb21cece1  call 0x00007D0BB200E760
00007d0bb21cece6  jmp 0x00007D0BB21CE96C
00007d0bb21ceceb  call 0x00007D0BB200BC20
00007d0bb21cecf0  jmp 0x00007D0BB21CE99C
00007d0bb21cecf5  call 0x00007D0BB200A9A0
00007d0bb21cecfa  jmp 0x00007D0BB21CE9A8
00007d0bb21cecff  call 0x00007D0BB200BC20
00007d0bb21ced04  jmp 0x00007D0BB21CE9D0
00007d0bb21ced09  call 0x00007D0BB200A9A0
00007d0bb21ced0e  jmp 0x00007D0BB21CE9DC
00007d0bb21ced13  call 0x00007D0BB1FFF540
00007d0bb21ced18  jmp 0x00007D0BB21CE9E9
00007d0bb21ced1d  call 0x00007D0BB200E880
00007d0bb21ced22  jmp 0x00007D0BB21CE9F6
00007d0bb21ced27  call 0x00007D0BB1FFF430
00007d0bb21ced2c  jmp 0x00007D0BB21CEA01
00007d0bb21ced31  call 0x00007D0BB200E760
00007d0bb21ced36  jmp 0x00007D0BB21CEA0C
00007d0bb21ced3b  call 0x00007D0BB200BC20
00007d0bb21ced40  jmp 0x00007D0BB21CEA36
00007d0bb21ced45  call 0x00007D0BB200A9A0
00007d0bb21ced4a  jmp 0x00007D0BB21CEA42
00007d0bb21ced4f  call 0x00007D0BB200BAE0
00007d0bb21ced54  jmp 0x00007D0BB21CEA52
00007d0bb21ced59  call 0x00007D0BB1FFF540
00007d0bb21ced5e  jmp 0x00007D0BB21CEA5F
00007d0bb21ced63  call 0x00007D0BB200E880
00007d0bb21ced68  jmp 0x00007D0BB21CEA6C
00007d0bb21ced6d  int3
00007d0bb21ced6e  nop
00007d0bb21ced70  mov rax, [r15]
00007d0bb21ced73  lea r14, [rax+0x20]
00007d0bb21ced77  mov r12, [r13+r14*1]
00007d0bb21ced7c  mov r14, [r15+0x10]
00007d0bb21ced80  lea r11, [r12+r14*1]
00007d0bb21ced84  mov [r15+0x40], r11
00007d0bb21ced88  lea r12, [rax+0x20]
00007d0bb21ced8c  mov [r13+r12*1], r11
00007d0bb21ced91  test r14, r14
00007d0bb21ced94  setz r14b
00007d0bb21ced98  movzx r14, r14b
00007d0bb21ced9c  mov [rsp+0x414], r14b
00007d0bb21ceda4  cmp byte ptr [rsp+0x414], 0x00
00007d0bb21cedac  jz 0x00007D0BB21CEDDE
00007d0bb21cedae  cmp dword ptr [r15+0x318], 0x00
00007d0bb21cedb6  mov eax, 0x4109A0
00007d0bb21cedbb  mov [r15+0x100], rax
00007d0bb21cedc2  jz 0x00007D0BB1FFE0A0
00007d0bb21cedc8  nop [rax+rax*1], eax
00007d0bb21cedcd  mov eax, 0x4109A0
00007d0bb21cedd2  mov [r15+0x100], rax
00007d0bb21cedd9  jmp 0x00007D0BB1FFE110
00007d0bb21cedde  cmp dword ptr [r15+0x318], 0x00
00007d0bb21cede6  jz 0x00007D0BB21CEE30
00007d0bb21cedec  nop [rax+rax*1], ax
00007d0bb21cedf5  nop [rax+rax*1], eax
00007d0bb21cedfd  mov eax, 0x410738
00007d0bb21cee02  mov [r15+0x100], rax
00007d0bb21cee09  jmp 0x00007D0BB1FFE110
00007d0bb21cee0e  int3
00007d0bb21cee0f  call 0x00007D0BB20E27E0
00007d0bb21cee14  jmp 0x00007D0BB21CED7C
00007d0bb21cee19  call 0x00007D0BB20C0860
00007d0bb21cee1e  jmp 0x00007D0BB21CED91
00007d0bb21cee23  int3
00007d0bb21cee24  nop [rax+rax*1], ax
00007d0bb21cee2d  nop [rax], eax
00007d0bb21cee30  mov rax, [r15+0xF8]
00007d0bb21cee37  lea r14, [rax-0x150]
00007d0bb21cee3e  mov [r15+0xF8], r14
00007d0bb21cee45  mov rax, [r15]
00007d0bb21cee48  lea r12, [rax+0x68]
00007d0bb21cee4c  mov r11, [r13+r12*1]
00007d0bb21cee51  mov [r15+0x88], r11
00007d0bb21cee58  lea r12, [rax+0x28]
00007d0bb21cee5c  mov [r15+0x40], r12
00007d0bb21cee60  mov [r15+0x48], r14
00007d0bb21cee64  mov qword ptr [r15+0x50], 0x420B90
00007d0bb21cee6c  lea rax, [r14+0x100]
00007d0bb21cee73  mov r12, [r15+0xE8]
00007d0bb21cee7a  mov r11, [r15+0xD8]
00007d0bb21cee81  mov [r13+rax*1], r12
00007d0bb21cee86  lea rax, [r14+0x108]
00007d0bb21cee8d  mov [r13+rax*1], r11
00007d0bb21cee92  lea rax, [r14+0x110]
00007d0bb21cee99  mov r12, [r15+0xD0]
00007d0bb21ceea0  mov r11, [r15+0xC8]
00007d0bb21ceea7  mov [r13+rax*1], r12
00007d0bb21ceeac  lea rax, [r14+0x118]
00007d0bb21ceeb3  mov [r13+rax*1], r11
00007d0bb21ceeb8  lea rax, [r14+0x120]
00007d0bb21ceebf  mov r12, [r15+0xC0]
00007d0bb21ceec6  mov r11, [r15+0xB8]
00007d0bb21ceecd  mov [r13+rax*1], r12
00007d0bb21ceed2  lea rax, [r14+0x128]
00007d0bb21ceed9  mov [r13+rax*1], r11
00007d0bb21ceede  lea rax, [r14+0x130]
00007d0bb21ceee5  mov r12, [r15+0xB0]
00007d0bb21ceeec  mov r11, [r15+0xA8]
00007d0bb21ceef3  mov [r13+rax*1], r12
00007d0bb21ceef8  lea rax, [r14+0x138]
00007d0bb21ceeff  mov [r13+rax*1], r11
00007d0bb21cef04  lea rax, [r14+0x140]
00007d0bb21cef0b  mov r12, [r15+0xA0]
00007d0bb21cef12  mov r11, [r15+0x98]
00007d0bb21cef19  mov [r13+rax*1], r12
00007d0bb21cef1e  lea rax, [r14+0x148]
00007d0bb21cef25  mov [r13+rax*1], r11
00007d0bb21cef2a  cmp dword ptr [r15+0x318], 0x00
00007d0bb21cef32  jz 0x00007D0BB21CEFD0
00007d0bb21cef38  nop [rax+rax*1], ax
00007d0bb21cef41  nop [rax+rax*1], eax
00007d0bb21cef49  mov eax, 0x410770
00007d0bb21cef4e  mov [r15+0x100], rax
00007d0bb21cef55  jmp 0x00007D0BB1FFE110
00007d0bb21cef5a  int3
00007d0bb21cef5b  call 0x00007D0BB20C0370
00007d0bb21cef60  jmp 0x00007D0BB21CEE51
00007d0bb21cef65  call 0x00007D0BB200BC20
00007d0bb21cef6a  jmp 0x00007D0BB21CEE86
00007d0bb21cef6f  call 0x00007D0BB200A9A0
00007d0bb21cef74  jmp 0x00007D0BB21CEE92
00007d0bb21cef79  call 0x00007D0BB200BC20
00007d0bb21cef7e  jmp 0x00007D0BB21CEEAC
00007d0bb21cef83  call 0x00007D0BB200A9A0
00007d0bb21cef88  jmp 0x00007D0BB21CEEB8
00007d0bb21cef8d  call 0x00007D0BB200BC20
00007d0bb21cef92  jmp 0x00007D0BB21CEED2
00007d0bb21cef97  call 0x00007D0BB200A9A0
00007d0bb21cef9c  jmp 0x00007D0BB21CEEDE
00007d0bb21cefa1  call 0x00007D0BB200BC20
00007d0bb21cefa6  jmp 0x00007D0BB21CEEF8
00007d0bb21cefab  call 0x00007D0BB200A9A0
00007d0bb21cefb0  jmp 0x00007D0BB21CEF04
00007d0bb21cefb5  call 0x00007D0BB200BC20
00007d0bb21cefba  jmp 0x00007D0BB21CEF1E
00007d0bb21cefbf  call 0x00007D0BB200A9A0
00007d0bb21cefc4  jmp 0x00007D0BB21CEF2A
00007d0bb21cefc9  int3
00007d0bb21cefca  nop [rax+rax*1], ax
00007d0bb21cefd0  mov rax, [r15+0x08]
00007d0bb21cefd4  movzx r14d, byte ptr [r13+rax*1]
00007d0bb21cefda  movzx r14d, r14b
00007d0bb21cefde  mov [rsp+0x10], r14d
00007d0bb21cefe3  mov r14d, r14d
00007d0bb21cefe6  mov [r15+0x58], r14
00007d0bb21cefea  lea r14, [rax+0x01]
00007d0bb21cefee  mov [r15+0x08], r14
00007d0bb21ceff2  mov rax, [r15+0x88]
00007d0bb21ceff9  lea r14, [rax+0x01]
00007d0bb21ceffd  mov r12, [r15]
00007d0bb21cf000  lea r11, [r12+0x68]
00007d0bb21cf005  mov [r13+r11*1], r14
00007d0bb21cf00a  lea r14, [r12+rax*1]
00007d0bb21cf00e  mov [r15+0x60], r14
00007d0bb21cf012  lea rax, [r14+0x28]
00007d0bb21cf016  mov r11d, [rsp+0x10]
00007d0bb21cf01b  movzx r14d, r11b
00007d0bb21cf01f  mov [r13+rax*1], r14b
00007d0bb21cf024  lea rax, [r12+0x68]
00007d0bb21cf029  mov r14, [r13+rax*1]
00007d0bb21cf02e  mov [r15+0x88], r14
00007d0bb21cf035  xor eax, eax
00007d0bb21cf037  mov r12d, 0x40
00007d0bb21cf03d  cmp r14, r12
00007d0bb21cf040  cmc
00007d0bb21cf041  lahf
00007d0bb21cf042  seto al
00007d0bb21cf045  mov [r15+0x108], eax
00007d0bb21cf04c  mov eax, [r15+0x108]
00007d0bb21cf053  sahf
00007d0bb21cf054  jnz 0x00007D0BB21CF086
00007d0bb21cf056  cmp dword ptr [r15+0x318], 0x00
00007d0bb21cf05e  jz 0x00007D0BB21CF170
00007d0bb21cf064  nop [rax+rax*1], ax
00007d0bb21cf06d  nop [rax+rax*1], eax
00007d0bb21cf075  mov eax, 0x410790
00007d0bb21cf07a  mov [r15+0x100], rax
00007d0bb21cf081  jmp 0x00007D0BB1FFE110
00007d0bb21cf086  cmp dword ptr [r15+0x318], 0x00
00007d0bb21cf08e  jz 0x00007D0BB21CF0E0
00007d0bb21cf094  nop [rax+rax*1], ax
00007d0bb21cf09d  nop [rax+rax*1], eax
00007d0bb21cf0a5  mov eax, 0x410768
00007d0bb21cf0aa  mov [r15+0x100], rax
00007d0bb21cf0b1  jmp 0x00007D0BB1FFE110
00007d0bb21cf0b6  int3
00007d0bb21cf0b7  call 0x00007D0BB200D860
00007d0bb21cf0bc  jmp 0x00007D0BB21CEFDA
00007d0bb21cf0c1  call 0x00007D0BB20B36E0
00007d0bb21cf0c6  jmp 0x00007D0BB21CF00A
00007d0bb21cf0cb  call 0x00007D0BB200DD60
00007d0bb21cf0d0  jmp 0x00007D0BB21CF024
00007d0bb21cf0d5  call 0x00007D0BB200DC20
00007d0bb21cf0da  jmp 0x00007D0BB21CF02E
00007d0bb21cf0df  int3
00007d0bb21cf0e0  mov rax, [r15+0x10]
00007d0bb21cf0e4  lea r14, [rax-0x01]
00007d0bb21cf0e8  mov [r15+0x10], r14
00007d0bb21cf0ec  test r14, r14
00007d0bb21cf0ef  setz r14b
00007d0bb21cf0f3  movzx r14, r14b
00007d0bb21cf0f7  mov [rsp+0x414], r14b
00007d0bb21cf0ff  cmp byte ptr [rsp+0x414], 0x00
00007d0bb21cf107  jz 0x00007D0BB21CF139
00007d0bb21cf109  cmp dword ptr [r15+0x318], 0x00
00007d0bb21cf111  jz 0x00007D0BB21D0670
00007d0bb21cf117  nop [rax+rax*1], ax
00007d0bb21cf120  nop [rax+rax*1], eax
00007d0bb21cf128  mov eax, 0x410988
00007d0bb21cf12d  mov [r15+0x100], rax
00007d0bb21cf134  jmp 0x00007D0BB1FFE110
00007d0bb21cf139  cmp dword ptr [r15+0x318], 0x00
00007d0bb21cf141  jz 0x00007D0BB21CEFD0
00007d0bb21cf147  nop [rax+rax*1], ax
00007d0bb21cf150  nop [rax+rax*1], eax
00007d0bb21cf158  mov eax, 0x410770
00007d0bb21cf15d  mov [r15+0x100], rax
00007d0bb21cf164  jmp 0x00007D0BB1FFE110
00007d0bb21cf169  int3
00007d0bb21cf16a  int3
00007d0bb21cf16b  nop [rax+rax*1], eax
00007d0bb21cf170  mov rax, [r15+0x40]
00007d0bb21cf174  movzx r14d, byte ptr [r13+rax*1]
00007d0bb21cf17a  movaps xmm1, [r15+0x110]
00007d0bb21cf182  pinsrb xmm1, r14d, 0x00
00007d0bb21cf189  lea r14, [rax+0x01]
00007d0bb21cf18d  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf193  movaps xmm15, [r15+0x120]
00007d0bb21cf19b  pinsrb xmm15, r12d, 0x00
00007d0bb21cf1a2  lea r14, [rax+0x02]
00007d0bb21cf1a6  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf1ac  movaps xmm14, [r15+0x130]
00007d0bb21cf1b4  pinsrb xmm14, r12d, 0x00
00007d0bb21cf1bb  lea r14, [rax+0x03]
00007d0bb21cf1bf  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf1c5  movaps xmm13, [r15+0x140]
00007d0bb21cf1cd  pinsrb xmm13, r12d, 0x00
00007d0bb21cf1d4  lea r14, [rax+0x04]
00007d0bb21cf1d8  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf1de  pinsrb xmm1, r12d, 0x01
00007d0bb21cf1e5  lea r14, [rax+0x05]
00007d0bb21cf1e9  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf1ef  pinsrb xmm15, r12d, 0x01
00007d0bb21cf1f6  lea r14, [rax+0x06]
00007d0bb21cf1fa  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf200  pinsrb xmm14, r12d, 0x01
00007d0bb21cf207  lea r14, [rax+0x07]
00007d0bb21cf20b  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf211  pinsrb xmm13, r12d, 0x01
00007d0bb21cf218  lea r14, [rax+0x08]
00007d0bb21cf21c  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf222  pinsrb xmm1, r12d, 0x02
00007d0bb21cf229  lea r14, [rax+0x09]
00007d0bb21cf22d  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf233  pinsrb xmm15, r12d, 0x02
00007d0bb21cf23a  lea r14, [rax+0x0A]
00007d0bb21cf23e  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf244  pinsrb xmm14, r12d, 0x02
00007d0bb21cf24b  lea r14, [rax+0x0B]
00007d0bb21cf24f  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf255  pinsrb xmm13, r12d, 0x02
00007d0bb21cf25c  lea r14, [rax+0x0C]
00007d0bb21cf260  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf266  pinsrb xmm1, r12d, 0x03
00007d0bb21cf26d  lea r14, [rax+0x0D]
00007d0bb21cf271  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf277  pinsrb xmm15, r12d, 0x03
00007d0bb21cf27e  lea r14, [rax+0x0E]
00007d0bb21cf282  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf288  pinsrb xmm14, r12d, 0x03
00007d0bb21cf28f  lea r14, [rax+0x0F]
00007d0bb21cf293  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf299  pinsrb xmm13, r12d, 0x03
00007d0bb21cf2a0  lea r14, [rax+0x10]
00007d0bb21cf2a4  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf2aa  pinsrb xmm1, r12d, 0x04
00007d0bb21cf2b1  lea r14, [rax+0x11]
00007d0bb21cf2b5  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf2bb  pinsrb xmm15, r12d, 0x04
00007d0bb21cf2c2  lea r14, [rax+0x12]
00007d0bb21cf2c6  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf2cc  pinsrb xmm14, r12d, 0x04
00007d0bb21cf2d3  lea r14, [rax+0x13]
00007d0bb21cf2d7  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf2dd  pinsrb xmm13, r12d, 0x04
00007d0bb21cf2e4  lea r14, [rax+0x14]
00007d0bb21cf2e8  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf2ee  pinsrb xmm1, r12d, 0x05
00007d0bb21cf2f5  lea r14, [rax+0x15]
00007d0bb21cf2f9  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf2ff  pinsrb xmm15, r12d, 0x05
00007d0bb21cf306  lea r14, [rax+0x16]
00007d0bb21cf30a  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf310  pinsrb xmm14, r12d, 0x05
00007d0bb21cf317  lea r14, [rax+0x17]
00007d0bb21cf31b  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf321  pinsrb xmm13, r12d, 0x05
00007d0bb21cf328  lea r14, [rax+0x18]
00007d0bb21cf32c  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf332  pinsrb xmm1, r12d, 0x06
00007d0bb21cf339  lea r14, [rax+0x19]
00007d0bb21cf33d  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf343  pinsrb xmm15, r12d, 0x06
00007d0bb21cf34a  lea r14, [rax+0x1A]
00007d0bb21cf34e  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf354  pinsrb xmm14, r12d, 0x06
00007d0bb21cf35b  lea r14, [rax+0x1B]
00007d0bb21cf35f  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf365  pinsrb xmm13, r12d, 0x06
00007d0bb21cf36c  lea r14, [rax+0x1C]
00007d0bb21cf370  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf376  pinsrb xmm1, r12d, 0x07
00007d0bb21cf37d  lea r14, [rax+0x1D]
00007d0bb21cf381  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf387  pinsrb xmm15, r12d, 0x07
00007d0bb21cf38e  lea r14, [rax+0x1E]
00007d0bb21cf392  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf398  pinsrb xmm14, r12d, 0x07
00007d0bb21cf39f  lea r14, [rax+0x1F]
00007d0bb21cf3a3  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf3a9  pinsrb xmm13, r12d, 0x07
00007d0bb21cf3b0  lea r14, [rax+0x20]
00007d0bb21cf3b4  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf3ba  pinsrb xmm1, r12d, 0x08
00007d0bb21cf3c1  lea r14, [rax+0x21]
00007d0bb21cf3c5  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf3cb  pinsrb xmm15, r12d, 0x08
00007d0bb21cf3d2  lea r14, [rax+0x22]
00007d0bb21cf3d6  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf3dc  pinsrb xmm14, r12d, 0x08
00007d0bb21cf3e3  lea r14, [rax+0x23]
00007d0bb21cf3e7  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf3ed  pinsrb xmm13, r12d, 0x08
00007d0bb21cf3f4  lea r14, [rax+0x24]
00007d0bb21cf3f8  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf3fe  pinsrb xmm1, r12d, 0x09
00007d0bb21cf405  lea r14, [rax+0x25]
00007d0bb21cf409  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf40f  pinsrb xmm15, r12d, 0x09
00007d0bb21cf416  lea r14, [rax+0x26]
00007d0bb21cf41a  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf420  pinsrb xmm14, r12d, 0x09
00007d0bb21cf427  lea r14, [rax+0x27]
00007d0bb21cf42b  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf431  pinsrb xmm13, r12d, 0x09
00007d0bb21cf438  lea r14, [rax+0x28]
00007d0bb21cf43c  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf442  pinsrb xmm1, r12d, 0x0A
00007d0bb21cf449  lea r14, [rax+0x29]
00007d0bb21cf44d  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf453  pinsrb xmm15, r12d, 0x0A
00007d0bb21cf45a  lea r14, [rax+0x2A]
00007d0bb21cf45e  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf464  pinsrb xmm14, r12d, 0x0A
00007d0bb21cf46b  lea r14, [rax+0x2B]
00007d0bb21cf46f  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf475  pinsrb xmm13, r12d, 0x0A
00007d0bb21cf47c  lea r14, [rax+0x2C]
00007d0bb21cf480  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf486  pinsrb xmm1, r12d, 0x0B
00007d0bb21cf48d  lea r14, [rax+0x2D]
00007d0bb21cf491  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf497  pinsrb xmm15, r12d, 0x0B
00007d0bb21cf49e  lea r14, [rax+0x2E]
00007d0bb21cf4a2  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf4a8  pinsrb xmm14, r12d, 0x0B
00007d0bb21cf4af  lea r14, [rax+0x2F]
00007d0bb21cf4b3  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf4b9  pinsrb xmm13, r12d, 0x0B
00007d0bb21cf4c0  lea r14, [rax+0x30]
00007d0bb21cf4c4  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf4ca  pinsrb xmm1, r12d, 0x0C
00007d0bb21cf4d1  lea r14, [rax+0x31]
00007d0bb21cf4d5  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf4db  pinsrb xmm15, r12d, 0x0C
00007d0bb21cf4e2  lea r14, [rax+0x32]
00007d0bb21cf4e6  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf4ec  pinsrb xmm14, r12d, 0x0C
00007d0bb21cf4f3  lea r14, [rax+0x33]
00007d0bb21cf4f7  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf4fd  pinsrb xmm13, r12d, 0x0C
00007d0bb21cf504  lea r14, [rax+0x34]
00007d0bb21cf508  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf50e  pinsrb xmm1, r12d, 0x0D
00007d0bb21cf515  lea r14, [rax+0x35]
00007d0bb21cf519  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf51f  pinsrb xmm15, r12d, 0x0D
00007d0bb21cf526  lea r14, [rax+0x36]
00007d0bb21cf52a  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf530  pinsrb xmm14, r12d, 0x0D
00007d0bb21cf537  lea r14, [rax+0x37]
00007d0bb21cf53b  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf541  pinsrb xmm13, r12d, 0x0D
00007d0bb21cf548  lea r14, [rax+0x38]
00007d0bb21cf54c  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf552  pinsrb xmm1, r12d, 0x0E
00007d0bb21cf559  lea r14, [rax+0x39]
00007d0bb21cf55d  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf563  pinsrb xmm15, r12d, 0x0E
00007d0bb21cf56a  lea r14, [rax+0x3A]
00007d0bb21cf56e  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf574  pinsrb xmm14, r12d, 0x0E
00007d0bb21cf57b  lea r14, [rax+0x3B]
00007d0bb21cf57f  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf585  pinsrb xmm13, r12d, 0x0E
00007d0bb21cf58c  lea r14, [rax+0x3C]
00007d0bb21cf590  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf596  pinsrb xmm1, r12d, 0x0F
00007d0bb21cf59d  movaps [r15+0x110], xmm1
00007d0bb21cf5a5  lea r14, [rax+0x3D]
00007d0bb21cf5a9  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf5af  pinsrb xmm15, r12d, 0x0F
00007d0bb21cf5b6  movaps [r15+0x120], xmm15
00007d0bb21cf5be  lea r14, [rax+0x3E]
00007d0bb21cf5c2  movzx r12d, byte ptr [r13+r14*1]
00007d0bb21cf5c8  pinsrb xmm14, r12d, 0x0F
00007d0bb21cf5cf  movaps [r15+0x130], xmm14
00007d0bb21cf5d7  lea r14, [rax+0x3F]
00007d0bb21cf5db  movzx eax, byte ptr [r13+r14*1]
00007d0bb21cf5e1  pinsrb xmm13, eax, 0x0F
00007d0bb21cf5e8  movaps [r15+0x140], xmm13
00007d0bb21cf5f0  movq xmm1, qword ptr [r15+0x120]
00007d0bb21cf5f9  pmovzxbw xmm1, xmm1
00007d0bb21cf5fe  psllw xmm1, 0x00
00007d0bb21cf603  movaps [r15+0x150], xmm1
00007d0bb21cf60b  movq xmm1, qword ptr [r15+0x130]
00007d0bb21cf614  pmovzxbw xmm1, xmm1
00007d0bb21cf619  psllw xmm1, 0x00
00007d0bb21cf61e  movaps [r15+0x160], xmm1
00007d0bb21cf626  movq xmm1, qword ptr [r15+0x110]
00007d0bb21cf62f  pmovzxbw xmm1, xmm1
00007d0bb21cf634  psllw xmm1, 0x00
00007d0bb21cf639  movaps [r15+0x170], xmm1
00007d0bb21cf641  movaps xmm15, [r15+0x110]
00007d0bb21cf649  pextrq rax, xmm15, 0x01
00007d0bb21cf650  movq xmm15, rax
00007d0bb21cf655  pmovzxbw xmm15, xmm15
00007d0bb21cf65b  psllw xmm15, 0x00
00007d0bb21cf661  movaps [r15+0x180], xmm15
00007d0bb21cf669  movaps xmm14, [r15+0x120]
00007d0bb21cf671  pextrq rax, xmm14, 0x01
00007d0bb21cf678  movq xmm14, rax
00007d0bb21cf67d  pmovzxbw xmm14, xmm14
00007d0bb21cf683  psllw xmm14, 0x00
00007d0bb21cf689  movaps [r15+0x210], xmm14
00007d0bb21cf691  movaps xmm13, [r15+0x130]
00007d0bb21cf699  pextrq rax, xmm13, 0x01
00007d0bb21cf6a0  movq xmm13, rax
00007d0bb21cf6a5  pmovzxbw xmm13, xmm13
00007d0bb21cf6ab  psllw xmm13, 0x00
00007d0bb21cf6b1  movaps [r15+0x220], xmm13
00007d0bb21cf6b9  movq xmm12, qword ptr [r15+0x140]
00007d0bb21cf6c2  pmovzxbw xmm12, xmm12
00007d0bb21cf6c8  psllw xmm12, 0x00
00007d0bb21cf6ce  movaps [r15+0x250], xmm12
00007d0bb21cf6d6  movaps xmm12, [r15+0x140]
00007d0bb21cf6de  pextrq rax, xmm12, 0x01
00007d0bb21cf6e5  movq xmm12, rax
00007d0bb21cf6ea  pmovzxbw xmm12, xmm12
00007d0bb21cf6f0  psllw xmm12, 0x00
00007d0bb21cf6f6  movaps [r15+0x110], xmm12
00007d0bb21cf6fe  movq xmm11, qword ptr [r15+0x150]
00007d0bb21cf707  pmovzxwd xmm11, xmm11
00007d0bb21cf70d  pslld xmm11, 0x10
00007d0bb21cf713  movq xmm10, qword ptr [r15+0x160]
00007d0bb21cf71c  pmovzxwd xmm10, xmm10
00007d0bb21cf722  pslld xmm10, 0x08
00007d0bb21cf728  pextrq rax, xmm1, 0x01
00007d0bb21cf72f  movq xmm1, rax
00007d0bb21cf734  pmovzxwd xmm1, xmm1
00007d0bb21cf739  pslld xmm1, 0x00
00007d0bb21cf73e  movaps [r15+0x260], xmm1
00007d0bb21cf746  pextrq rax, xmm15, 0x01
00007d0bb21cf74d  movq xmm15, rax
00007d0bb21cf752  pmovzxwd xmm15, xmm15
00007d0bb21cf758  pslld xmm15, 0x00
00007d0bb21cf75e  movaps [r15+0x270], xmm15
00007d0bb21cf766  movq xmm9, qword ptr [r15+0x170]
00007d0bb21cf76f  pmovzxwd xmm9, xmm9
00007d0bb21cf775  pslld xmm9, 0x00
00007d0bb21cf77b  pextrq rax, xmm14, 0x01
00007d0bb21cf782  movq xmm14, rax
00007d0bb21cf787  pmovzxwd xmm14, xmm14
00007d0bb21cf78d  pslld xmm14, 0x10
00007d0bb21cf793  movaps [r15+0x280], xmm14
00007d0bb21cf79b  movq xmm8, qword ptr [r15+0x180]
00007d0bb21cf7a4  pmovzxwd xmm8, xmm8
00007d0bb21cf7aa  pslld xmm8, 0x00
00007d0bb21cf7b0  movq xmm7, qword ptr [r15+0x210]
00007d0bb21cf7b9  pmovzxwd xmm7, xmm7
00007d0bb21cf7be  pslld xmm7, 0x10
00007d0bb21cf7c3  movaps xmm6, [r15+0x150]
00007d0bb21cf7cb  pextrq rax, xmm6, 0x01
00007d0bb21cf7d2  movq xmm6, rax
00007d0bb21cf7d7  pmovzxwd xmm6, xmm6
00007d0bb21cf7dc  pslld xmm6, 0x10
00007d0bb21cf7e1  por xmm11, xmm10
00007d0bb21cf7e6  movaps [r15+0x230], xmm11
00007d0bb21cf7ee  pextrq rax, xmm13, 0x01
00007d0bb21cf7f5  movq xmm13, rax
00007d0bb21cf7fa  pmovzxwd xmm13, xmm13
00007d0bb21cf800  pslld xmm13, 0x08
00007d0bb21cf806  movaps [r15+0x240], xmm13
00007d0bb21cf80e  movq xmm10, qword ptr [r15+0x220]
00007d0bb21cf817  pmovzxwd xmm10, xmm10
00007d0bb21cf81d  pslld xmm10, 0x08
00007d0bb21cf823  movaps xmm5, [r15+0x160]
00007d0bb21cf82b  pextrq rax, xmm5, 0x01
00007d0bb21cf832  movq xmm5, rax
00007d0bb21cf837  pmovzxwd xmm5, xmm5
00007d0bb21cf83c  pslld xmm5, 0x08
00007d0bb21cf841  pslld xmm9, 0x18
00007d0bb21cf847  pslld xmm15, 0x18
00007d0bb21cf84d  pslld xmm8, 0x18
00007d0bb21cf853  movq xmm4, qword ptr [r15+0x250]
00007d0bb21cf85c  pmovzxwd xmm4, xmm4
00007d0bb21cf861  pslld xmm4, 0x00
00007d0bb21cf866  por xmm14, xmm13
00007d0bb21cf86b  por xmm7, xmm10
00007d0bb21cf870  movaps [r15+0x210], xmm7
00007d0bb21cf878  pslld xmm1, 0x18
00007d0bb21cf87d  movaps [r15+0x220], xmm1
00007d0bb21cf885  por xmm6, xmm5
00007d0bb21cf889  por xmm11, xmm9
00007d0bb21cf88e  movaps [r15+0x160], xmm11
00007d0bb21cf896  pextrq rax, xmm12, 0x01
00007d0bb21cf89d  movq xmm13, rax
00007d0bb21cf8a2  pmovzxwd xmm13, xmm13
00007d0bb21cf8a8  pslld xmm13, 0x00
00007d0bb21cf8ae  movaps [r15+0x170], xmm13
00007d0bb21cf8b6  movq xmm12, qword ptr [r15+0x110]
00007d0bb21cf8bf  pmovzxwd xmm12, xmm12
00007d0bb21cf8c5  pslld xmm12, 0x00
00007d0bb21cf8cb  por xmm14, xmm15
00007d0bb21cf8d0  por xmm7, xmm8
00007d0bb21cf8d5  movaps xmm15, [r15+0x250]
00007d0bb21cf8dd  pextrq rax, xmm15, 0x01
00007d0bb21cf8e4  movq xmm15, rax
00007d0bb21cf8e9  pmovzxwd xmm15, xmm15
00007d0bb21cf8ef  pslld xmm15, 0x00
00007d0bb21cf8f5  movaps [r15+0x180], xmm15
00007d0bb21cf8fd  por xmm6, xmm1
00007d0bb21cf901  movaps [r15+0x150], xmm6
00007d0bb21cf909  por xmm11, xmm4
00007d0bb21cf90e  movaps [r15+0x140], xmm11
00007d0bb21cf916  por xmm7, xmm12
00007d0bb21cf91b  movaps [r15+0x110], xmm7
00007d0bb21cf923  por xmm14, xmm13
00007d0bb21cf928  movaps [r15+0x120], xmm14
00007d0bb21cf930  por xmm6, xmm15
00007d0bb21cf935  movaps [r15+0x130], xmm6
00007d0bb21cf93d  mov rax, [r15+0xF8]
00007d0bb21cf944  lea r14, [rax+0x20]
00007d0bb21cf948  movups [r13+r14*1], xmm7
00007d0bb21cf94e  lea r14, [rax+0x30]
00007d0bb21cf952  movups [r13+r14*1], xmm14
00007d0bb21cf958  movups [r13+rax*1], xmm11
00007d0bb21cf95e  lea r14, [rax+0x10]
00007d0bb21cf962  movups [r13+r14*1], xmm6
00007d0bb21cf968  mov r14d, [r13+rax*1]
00007d0bb21cf96d  mov rax, [r15+0x48]
00007d0bb21cf971  mov [r15+0x68], rax
00007d0bb21cf975  mov qword ptr [r15+0x58], 0x04
00007d0bb21cf97d  lea r12, [rax+0x04]
00007d0bb21cf981  mov r11d, [r13+r12*1]
00007d0bb21cf986  mov [rsp+0x10], r11d
00007d0bb21cf98b  mov r11d, r11d
00007d0bb21cf98e  mov [r15+0x70], r11
00007d0bb21cf992  lea r12, [rax+0x38]
00007d0bb21cf996  mov r11d, [r13+r12*1]
00007d0bb21cf99b  lea r12, [rax+0x24]
00007d0bb21cf99f  mov r10d, [r13+r12*1]
00007d0bb21cf9a4  mov [rsp+0x20], r10d
00007d0bb21cf9a9  mov r10d, r10d
00007d0bb21cf9ac  mov [r15+0x90], r10
00007d0bb21cf9b3  mov [rsp+0x30], rax
00007d0bb21cf9b8  xor eax, eax
00007d0bb21cf9ba  mov r12d, 0x04
00007d0bb21cf9c0  mov r10d, 0xC0
00007d0bb21cf9c6  cmp r12, r10
00007d0bb21cf9c9  cmc
00007d0bb21cf9ca  lahf
00007d0bb21cf9cb  seto al
00007d0bb21cf9ce  mov [r15+0x108], eax
00007d0bb21cf9d5  mov eax, [rsp+0x10]
00007d0bb21cf9d9  mov r12d, [rsp+0x10]
00007d0bb21cf9de  shrd eax, r12d, 0x07
00007d0bb21cf9e3  mov [rsp+0x10], r11d
00007d0bb21cf9e8  mov r10d, [rsp+0x10]
00007d0bb21cf9ed  shrd r11d, r10d, 0x11
00007d0bb21cf9f2  mov r9d, [rsp+0x20]
00007d0bb21cf9f7  lea r8d, [r9d+r14d*1]
00007d0bb21cf9fc  rorx r14d, r12d, 0x12
00007d0bb21cfa02  xor eax, r14d
00007d0bb21cfa05  rorx r14d, r10d, 0x13
00007d0bb21cfa0b  xor r11d, r14d
00007d0bb21cfa0e  mov [rsp+0x10], r11d
00007d0bb21cfa13  mov r11d, r11d
00007d0bb21cfa16  mov [r15+0x88], r11
00007d0bb21cfa1d  mov [rsp+0x20], r12d
00007d0bb21cfa22  shr r12d, 0x03
00007d0bb21cfa26  xor eax, r12d
00007d0bb21cfa29  mov [rsp+0x40], eax
00007d0bb21cfa2d  mov eax, eax
00007d0bb21cfa2f  mov [r15+0x80], rax
00007d0bb21cfa36  shr r10d, 0x0A
00007d0bb21cfa3a  mov eax, [rsp+0x10]
00007d0bb21cfa3e  xor eax, r10d
00007d0bb21cfa41  mov [rsp+0x10], eax
00007d0bb21cfa45  mov eax, eax
00007d0bb21cfa47  mov [r15+0x78], rax
00007d0bb21cfa4b  mov eax, [rsp+0x40]
00007d0bb21cfa4f  lea r14d, [r8d+eax*1]
00007d0bb21cfa54  mov eax, [rsp+0x10]
00007d0bb21cfa58  lea r12d, [r14d+eax*1]
00007d0bb21cfa5d  mov rax, [rsp+0x30]
00007d0bb21cfa62  lea r14, [rax+0x40]
00007d0bb21cfa66  mov [r13+r14*1], r12d
00007d0bb21cfa6b  mov eax, [rsp+0x20]
00007d0bb21cfa6f  mov eax, eax
00007d0bb21cfa71  mov [r15+0x60], rax
00007d0bb21cfa75  mov eax, [r15+0x108]
00007d0bb21cfa7c  sahf
00007d0bb21cfa7d  jnz 0x00007D0BB21CFAAF
00007d0bb21cfa7f  cmp dword ptr [r15+0x318], 0x00
00007d0bb21cfa87  jz 0x00007D0BB21CFF70
00007d0bb21cfa8d  nop [rax+rax*1], ax
00007d0bb21cfa96  nop [rax+rax*1], eax
00007d0bb21cfa9e  mov eax, 0x41088C
00007d0bb21cfaa3  mov [r15+0x100], rax
00007d0bb21cfaaa  jmp 0x00007D0BB1FFE110
00007d0bb21cfaaf  cmp dword ptr [r15+0x318], 0x00
00007d0bb21cfab7  jz 0x00007D0BB21CFDC0
00007d0bb21cfabd  nop [rax+rax*1], ax
00007d0bb21cfac6  nop [rax+rax*1], eax
00007d0bb21cface  mov eax, 0x410844
00007d0bb21cfad3  mov [r15+0x100], rax
00007d0bb21cfada  jmp 0x00007D0BB1FFE110
00007d0bb21cfadf  int3
00007d0bb21cfae0  call 0x00007D0BB200D860
00007d0bb21cfae5  jmp 0x00007D0BB21CF17A
00007d0bb21cfaea  call 0x00007D0BB20E2420
00007d0bb21cfaef  jmp 0x00007D0BB21CF193
00007d0bb21cfaf4  call 0x00007D0BB20E2420
00007d0bb21cfaf9  jmp 0x00007D0BB21CF1AC
00007d0bb21cfafe  call 0x00007D0BB20E2420
00007d0bb21cfb03  jmp 0x00007D0BB21CF1C5
00007d0bb21cfb08  call 0x00007D0BB20E2420
00007d0bb21cfb0d  jmp 0x00007D0BB21CF1DE
00007d0bb21cfb12  call 0x00007D0BB20E2420
00007d0bb21cfb17  jmp 0x00007D0BB21CF1EF
00007d0bb21cfb1c  call 0x00007D0BB20E2420
00007d0bb21cfb21  jmp 0x00007D0BB21CF200
00007d0bb21cfb26  call 0x00007D0BB20E2420
00007d0bb21cfb2b  jmp 0x00007D0BB21CF211
00007d0bb21cfb30  call 0x00007D0BB20E2420
00007d0bb21cfb35  jmp 0x00007D0BB21CF222
00007d0bb21cfb3a  call 0x00007D0BB20E2420
00007d0bb21cfb3f  jmp 0x00007D0BB21CF233
00007d0bb21cfb44  call 0x00007D0BB20E2420
00007d0bb21cfb49  jmp 0x00007D0BB21CF244
00007d0bb21cfb4e  call 0x00007D0BB20E2420
00007d0bb21cfb53  jmp 0x00007D0BB21CF255
00007d0bb21cfb58  call 0x00007D0BB20E2420
00007d0bb21cfb5d  jmp 0x00007D0BB21CF266
00007d0bb21cfb62  call 0x00007D0BB20E2420
00007d0bb21cfb67  jmp 0x00007D0BB21CF277
00007d0bb21cfb6c  call 0x00007D0BB20E2420
00007d0bb21cfb71  jmp 0x00007D0BB21CF288
00007d0bb21cfb76  call 0x00007D0BB20E2420
00007d0bb21cfb7b  jmp 0x00007D0BB21CF299
00007d0bb21cfb80  call 0x00007D0BB20E2420
00007d0bb21cfb85  jmp 0x00007D0BB21CF2AA
00007d0bb21cfb8a  call 0x00007D0BB20E2420
00007d0bb21cfb8f  jmp 0x00007D0BB21CF2BB
00007d0bb21cfb94  call 0x00007D0BB20E2420
00007d0bb21cfb99  jmp 0x00007D0BB21CF2CC
00007d0bb21cfb9e  call 0x00007D0BB20E2420
00007d0bb21cfba3  jmp 0x00007D0BB21CF2DD
00007d0bb21cfba8  call 0x00007D0BB20E2420
00007d0bb21cfbad  jmp 0x00007D0BB21CF2EE
00007d0bb21cfbb2  call 0x00007D0BB20E2420
00007d0bb21cfbb7  jmp 0x00007D0BB21CF2FF
00007d0bb21cfbbc  call 0x00007D0BB20E2420
00007d0bb21cfbc1  jmp 0x00007D0BB21CF310
00007d0bb21cfbc6  call 0x00007D0BB20E2420
00007d0bb21cfbcb  jmp 0x00007D0BB21CF321
00007d0bb21cfbd0  call 0x00007D0BB20E2420
00007d0bb21cfbd5  jmp 0x00007D0BB21CF332
00007d0bb21cfbda  call 0x00007D0BB20E2420
00007d0bb21cfbdf  jmp 0x00007D0BB21CF343
00007d0bb21cfbe4  call 0x00007D0BB20E2420
00007d0bb21cfbe9  jmp 0x00007D0BB21CF354
00007d0bb21cfbee  call 0x00007D0BB20E2420
00007d0bb21cfbf3  jmp 0x00007D0BB21CF365
00007d0bb21cfbf8  call 0x00007D0BB20E2420
00007d0bb21cfbfd  jmp 0x00007D0BB21CF376
00007d0bb21cfc02  call 0x00007D0BB20E2420
00007d0bb21cfc07  jmp 0x00007D0BB21CF387
00007d0bb21cfc0c  call 0x00007D0BB20E2420
00007d0bb21cfc11  jmp 0x00007D0BB21CF398
00007d0bb21cfc16  call 0x00007D0BB20E2420
00007d0bb21cfc1b  jmp 0x00007D0BB21CF3A9
00007d0bb21cfc20  call 0x00007D0BB20E2420
00007d0bb21cfc25  jmp 0x00007D0BB21CF3BA
00007d0bb21cfc2a  call 0x00007D0BB20E2420
00007d0bb21cfc2f  jmp 0x00007D0BB21CF3CB
00007d0bb21cfc34  call 0x00007D0BB20E2420
00007d0bb21cfc39  jmp 0x00007D0BB21CF3DC
00007d0bb21cfc3e  call 0x00007D0BB20E2420
00007d0bb21cfc43  jmp 0x00007D0BB21CF3ED
00007d0bb21cfc48  call 0x00007D0BB20E2420
00007d0bb21cfc4d  jmp 0x00007D0BB21CF3FE
00007d0bb21cfc52  call 0x00007D0BB20E2420
00007d0bb21cfc57  jmp 0x00007D0BB21CF40F
00007d0bb21cfc5c  call 0x00007D0BB20E2420
00007d0bb21cfc61  jmp 0x00007D0BB21CF420
00007d0bb21cfc66  call 0x00007D0BB20E2420
00007d0bb21cfc6b  jmp 0x00007D0BB21CF431
00007d0bb21cfc70  call 0x00007D0BB20E2420
00007d0bb21cfc75  jmp 0x00007D0BB21CF442
00007d0bb21cfc7a  call 0x00007D0BB20E2420
00007d0bb21cfc7f  jmp 0x00007D0BB21CF453
00007d0bb21cfc84  call 0x00007D0BB20E2420
00007d0bb21cfc89  jmp 0x00007D0BB21CF464
00007d0bb21cfc8e  call 0x00007D0BB20E2420
00007d0bb21cfc93  jmp 0x00007D0BB21CF475
00007d0bb21cfc98  call 0x00007D0BB20E2420
00007d0bb21cfc9d  jmp 0x00007D0BB21CF486
00007d0bb21cfca2  call 0x00007D0BB20E2420
00007d0bb21cfca7  jmp 0x00007D0BB21CF497
00007d0bb21cfcac  call 0x00007D0BB20E2420
00007d0bb21cfcb1  jmp 0x00007D0BB21CF4A8
00007d0bb21cfcb6  call 0x00007D0BB20E2420
00007d0bb21cfcbb  jmp 0x00007D0BB21CF4B9
00007d0bb21cfcc0  call 0x00007D0BB20E2420
00007d0bb21cfcc5  jmp 0x00007D0BB21CF4CA
00007d0bb21cfcca  call 0x00007D0BB20E2420
00007d0bb21cfccf  jmp 0x00007D0BB21CF4DB
00007d0bb21cfcd4  call 0x00007D0BB20E2420
00007d0bb21cfcd9  jmp 0x00007D0BB21CF4EC
00007d0bb21cfcde  call 0x00007D0BB20E2420
00007d0bb21cfce3  jmp 0x00007D0BB21CF4FD
00007d0bb21cfce8  call 0x00007D0BB20E2420
00007d0bb21cfced  jmp 0x00007D0BB21CF50E
00007d0bb21cfcf2  call 0x00007D0BB20E2420
00007d0bb21cfcf7  jmp 0x00007D0BB21CF51F
00007d0bb21cfcfc  call 0x00007D0BB20E2420
00007d0bb21cfd01  jmp 0x00007D0BB21CF530
00007d0bb21cfd06  call 0x00007D0BB20E2420
00007d0bb21cfd0b  jmp 0x00007D0BB21CF541
00007d0bb21cfd10  call 0x00007D0BB20E2420
00007d0bb21cfd15  jmp 0x00007D0BB21CF552
00007d0bb21cfd1a  call 0x00007D0BB20E2420
00007d0bb21cfd1f  jmp 0x00007D0BB21CF563
00007d0bb21cfd24  call 0x00007D0BB20E2420
00007d0bb21cfd29  jmp 0x00007D0BB21CF574
00007d0bb21cfd2e  call 0x00007D0BB20E2420
00007d0bb21cfd33  jmp 0x00007D0BB21CF585
00007d0bb21cfd38  call 0x00007D0BB20E2420
00007d0bb21cfd3d  jmp 0x00007D0BB21CF596
00007d0bb21cfd42  call 0x00007D0BB20E2420
00007d0bb21cfd47  jmp 0x00007D0BB21CF5AF
00007d0bb21cfd4c  call 0x00007D0BB20E2420
00007d0bb21cfd51  jmp 0x00007D0BB21CF5C8
00007d0bb21cfd56  call 0x00007D0BB20D5610
00007d0bb21cfd5b  jmp 0x00007D0BB21CF5E1
00007d0bb21cfd60  call 0x00007D0BB20DC580
00007d0bb21cfd65  jmp 0x00007D0BB21CF94E
00007d0bb21cfd6a  call 0x00007D0BB20E46C0
00007d0bb21cfd6f  jmp 0x00007D0BB21CF958
00007d0bb21cfd74  call 0x00007D0BB2009E90
00007d0bb21cfd79  jmp 0x00007D0BB21CF95E
00007d0bb21cfd7e  call 0x00007D0BB20DB310
00007d0bb21cfd83  jmp 0x00007D0BB21CF968
00007d0bb21cfd88  call 0x00007D0BB200DAE0
00007d0bb21cfd8d  jmp 0x00007D0BB21CF96D
00007d0bb21cfd92  call 0x00007D0BB20C0230
00007d0bb21cfd97  jmp 0x00007D0BB21CF986
00007d0bb21cfd9c  call 0x00007D0BB20C0230
00007d0bb21cfda1  jmp 0x00007D0BB21CF99B
00007d0bb21cfda6  call 0x00007D0BB20BEFC0
00007d0bb21cfdab  jmp 0x00007D0BB21CF9A4
00007d0bb21cfdb0  call 0x00007D0BB20E2BA0
00007d0bb21cfdb5  jmp 0x00007D0BB21CFA6B
00007d0bb21cfdba  int3
00007d0bb21cfdbb  nop [rax+rax*1], eax
00007d0bb21cfdc0  mov rax, [r15+0x48]
00007d0bb21cfdc4  mov r14, [r15+0x58]
00007d0bb21cfdc8  lea r12, [rax+r14*1]
00007d0bb21cfdcc  mov [r15+0x68], r12
00007d0bb21cfdd0  lea rax, [r14+0x04]
00007d0bb21cfdd4  mov [r15+0x58], rax
00007d0bb21cfdd8  lea r14, [r12+0x04]
00007d0bb21cfddd  mov r11d, [r13+r14*1]
00007d0bb21cfde2  mov [rsp+0x10], r11d
00007d0bb21cfde7  mov r11d, r11d
00007d0bb21cfdea  mov [r15+0x70], r11
00007d0bb21cfdee  lea r14, [r12+0x38]
00007d0bb21cfdf3  mov r11d, [r13+r14*1]
00007d0bb21cfdf8  lea r14, [r12+0x24]
00007d0bb21cfdfd  mov r10d, [r13+r14*1]
00007d0bb21cfe02  mov [rsp+0x20], r10d
00007d0bb21cfe07  mov r10d, r10d
00007d0bb21cfe0a  mov [r15+0x90], r10
00007d0bb21cfe11  mov [rsp+0x30], rax
00007d0bb21cfe16  xor eax, eax
00007d0bb21cfe18  mov r14, [rsp+0x30]
00007d0bb21cfe1d  mov r10d, 0xC0
00007d0bb21cfe23  cmp r14, r10
00007d0bb21cfe26  cmc
00007d0bb21cfe27  lahf
00007d0bb21cfe28  seto al
00007d0bb21cfe2b  mov [r15+0x108], eax
00007d0bb21cfe32  mov eax, [rsp+0x10]
00007d0bb21cfe36  mov r14d, [rsp+0x10]
00007d0bb21cfe3b  shrd eax, r14d, 0x07
00007d0bb21cfe40  mov [rsp+0x10], r11d
00007d0bb21cfe45  mov r10d, [rsp+0x10]
00007d0bb21cfe4a  shrd r11d, r10d, 0x11
00007d0bb21cfe4f  mov r9d, [r15+0x60]
00007d0bb21cfe53  mov r8d, [rsp+0x20]
00007d0bb21cfe58  lea ebp, [r8d+r9d*1]
00007d0bb21cfe5d  rorx r9d, r14d, 0x12
00007d0bb21cfe63  xor eax, r9d
00007d0bb21cfe66  rorx r9d, r10d, 0x13
00007d0bb21cfe6c  xor r11d, r9d
00007d0bb21cfe6f  mov [rsp+0x10], r11d
00007d0bb21cfe74  mov r11d, r11d
00007d0bb21cfe77  mov [r15+0x88], r11
00007d0bb21cfe7e  mov [rsp+0x20], r14d
00007d0bb21cfe83  shr r14d, 0x03
00007d0bb21cfe87  xor eax, r14d
00007d0bb21cfe8a  mov [rsp+0x30], eax
00007d0bb21cfe8e  mov eax, eax
00007d0bb21cfe90  mov [r15+0x80], rax
00007d0bb21cfe97  shr r10d, 0x0A
00007d0bb21cfe9b  mov eax, [rsp+0x10]
00007d0bb21cfe9f  xor eax, r10d
00007d0bb21cfea2  mov [rsp+0x10], eax
00007d0bb21cfea6  mov eax, eax
00007d0bb21cfea8  mov [r15+0x78], rax
00007d0bb21cfeac  mov eax, [rsp+0x30]
00007d0bb21cfeb0  lea r14d, [ebp+eax*1]
00007d0bb21cfeb6  mov eax, [rsp+0x10]
00007d0bb21cfeba  lea r11d, [r14d+eax*1]
00007d0bb21cfebf  lea rax, [r12+0x40]
00007d0bb21cfec4  mov [r13+rax*1], r11d
00007d0bb21cfec9  mov eax, [rsp+0x20]
00007d0bb21cfecd  mov eax, eax
00007d0bb21cfecf  mov [r15+0x60], rax
00007d0bb21cfed3  mov eax, [r15+0x108]
00007d0bb21cfeda  sahf
00007d0bb21cfedb  jnz 0x00007D0BB21CFF0D
00007d0bb21cfedd  cmp dword ptr [r15+0x318], 0x00
00007d0bb21cfee5  jz 0x00007D0BB21CFF70
00007d0bb21cfeeb  nop [rax+rax*1], ax
00007d0bb21cfef4  nop [rax+rax*1], eax
00007d0bb21cfefc  mov eax, 0x41088C
00007d0bb21cff01  mov [r15+0x100], rax
00007d0bb21cff08  jmp 0x00007D0BB1FFE110
00007d0bb21cff0d  cmp dword ptr [r15+0x318], 0x00
00007d0bb21cff15  jz 0x00007D0BB21CFDC0
00007d0bb21cff1b  nop [rax+rax*1], ax
00007d0bb21cff24  nop [rax+rax*1], eax
00007d0bb21cff2c  mov eax, 0x410844
00007d0bb21cff31  mov [r15+0x100], rax
00007d0bb21cff38  jmp 0x00007D0BB1FFE110
00007d0bb21cff3d  int3
00007d0bb21cff3e  call 0x00007D0BB20E1430
00007d0bb21cff43  jmp 0x00007D0BB21CFDE2
00007d0bb21cff48  call 0x00007D0BB20E1430
00007d0bb21cff4d  jmp 0x00007D0BB21CFDF8
00007d0bb21cff52  call 0x00007D0BB20E01C0
00007d0bb21cff57  jmp 0x00007D0BB21CFE02
00007d0bb21cff5c  call 0x00007D0BB200A860
00007d0bb21cff61  jmp 0x00007D0BB21CFEC9
00007d0bb21cff66  int3
00007d0bb21cff67  nop [rax+rax*1], ax
00007d0bb21cff70  mov rax, [r15]
00007d0bb21cff73  mov r14d, [r13+rax*1]
00007d0bb21cff78  lea r12, [rax+0x04]
00007d0bb21cff7c  mov r11d, [r13+r12*1]
00007d0bb21cff81  mov [rsp+0x10], r14d
00007d0bb21cff86  mov r14d, r14d
00007d0bb21cff89  mov [r15+0x78], r14
00007d0bb21cff8d  mov [rsp+0x20], r11d
00007d0bb21cff92  mov r11d, r11d
00007d0bb21cff95  mov [r15+0x80], r11
00007d0bb21cff9c  lea r14, [rax+0x08]
00007d0bb21cffa0  mov r12d, [r13+r14*1]
00007d0bb21cffa5  lea r14, [rax+0x0C]
00007d0bb21cffa9  mov r11d, [r13+r14*1]
00007d0bb21cffae  mov [rsp+0x30], r12d
00007d0bb21cffb3  mov r12d, r12d
00007d0bb21cffb6  mov [r15+0x70], r12
00007d0bb21cffba  mov [rsp+0x40], r11d
00007d0bb21cffbf  mov r11d, r11d
00007d0bb21cffc2  mov [r15+0x68], r11
00007d0bb21cffc6  lea r14, [rax+0x18]
00007d0bb21cffca  mov r12d, [r13+r14*1]
00007d0bb21cffcf  lea r14, [rax+0x1C]
00007d0bb21cffd3  mov r11d, [r13+r14*1]
00007d0bb21cffd8  mov [rsp+0x50], r12d
00007d0bb21cffdd  mov r12d, r12d
00007d0bb21cffe0  mov [r15+0x58], r12
00007d0bb21cffe4  mov [rsp+0x60], r11d
00007d0bb21cffe9  mov r11d, r11d
00007d0bb21cffec  mov [r15+0x60], r11
00007d0bb21cfff0  lea r14, [rax+0x10]
00007d0bb21cfff4  mov r12d, [r13+r14*1]
00007d0bb21cfff9  lea r14, [rax+0x14]
00007d0bb21cfffd  mov eax, [r13+r14*1]
00007d0bb21d0002  mov [rsp+0x70], r12d
00007d0bb21d0007  mov r12d, r12d
00007d0bb21d000a  mov [r15+0x18], r12
00007d0bb21d000e  mov [rsp+0x80], eax
00007d0bb21d0015  mov eax, eax
00007d0bb21d0017  mov [r15+0x90], rax
00007d0bb21d001e  mov eax, [rsp+0x70]
00007d0bb21d0022  mov eax, eax
00007d0bb21d0024  mov [r15+0x30], rax
00007d0bb21d0028  mov eax, [rsp+0x50]
00007d0bb21d002c  mov eax, eax
00007d0bb21d002e  mov [r15+0xA0], rax
00007d0bb21d0035  mov eax, [rsp+0x30]
00007d0bb21d0039  mov eax, eax
00007d0bb21d003b  mov [r15+0x28], rax
00007d0bb21d003f  mov eax, [rsp+0x20]
00007d0bb21d0043  mov eax, eax
00007d0bb21d0045  mov [r15+0x98], rax
00007d0bb21d004c  mov eax, [rsp+0x10]
00007d0bb21d0050  mov eax, eax
00007d0bb21d0052  mov [r15+0x38], rax
00007d0bb21d0056  mov eax, [rsp+0x70]
00007d0bb21d005a  mov r14d, [rsp+0x70]
00007d0bb21d005f  shrd eax, r14d, 0x06
00007d0bb21d0064  mov [rsp+0x70], r14d
00007d0bb21d0069  mov r12d, [rsp+0x80]
00007d0bb21d0071  and r14d, r12d
00007d0bb21d0074  mov r11d, [rsp+0x10]
00007d0bb21d0079  mov r10d, [rsp+0x10]
00007d0bb21d007e  shrd r11d, r10d, 0x02
00007d0bb21d0083  mov [rsp+0x10], r12d
00007d0bb21d0088  mov r12d, r12d
00007d0bb21d008b  mov [r15+0x20], r12
00007d0bb21d008f  mov r12, [r15+0x50]
00007d0bb21d0093  mov r9d, [r13+r12*1]
00007d0bb21d0098  mov r12d, [rsp+0x50]
00007d0bb21d009d  mov r8d, [rsp+0x70]
00007d0bb21d00a2  andn ebp, r8d, r12d
00007d0bb21d00a7  mov edi, [rsp+0x60]
00007d0bb21d00ab  lea esi, [r14d+edi*1]
00007d0bb21d00b0  rorx r14d, r8d, 0x0B
00007d0bb21d00b6  xor eax, r14d
00007d0bb21d00b9  rorx r14d, r10d, 0x0D
00007d0bb21d00bf  xor r11d, r14d
00007d0bb21d00c2  lea edi, [esi+ebp*1]
00007d0bb21d00c6  mov r14, [r15+0x48]
00007d0bb21d00ca  mov ebp, [r13+r14*1]
00007d0bb21d00cf  mov r14d, [rsp+0x30]
00007d0bb21d00d4  mov esi, [rsp+0x20]
00007d0bb21d00d8  and r14d, esi
00007d0bb21d00db  mov [rsp+0x20], r14d
00007d0bb21d00e0  mov r14d, r14d
00007d0bb21d00e3  mov [r15+0xD8], r14
00007d0bb21d00ea  lea r14d, [edi+r9d*1]
00007d0bb21d00ef  mov r9d, [rsp+0x30]
00007d0bb21d00f4  xor r9d, esi
00007d0bb21d00f7  rorx edi, r8d, 0x19
00007d0bb21d00fd  xor eax, edi
00007d0bb21d00ff  and r9d, r10d
00007d0bb21d0102  rorx edi, r10d, 0x16
00007d0bb21d0108  xor r11d, edi
00007d0bb21d010b  mov [rsp+0x30], r11d
00007d0bb21d0110  mov r11d, r11d
00007d0bb21d0113  mov [r15+0xD0], r11
00007d0bb21d011a  lea r11d, [r14d+ebp*1]
00007d0bb21d011f  mov r10d, [rsp+0x20]
00007d0bb21d0124  xor r9d, r10d
00007d0bb21d0127  lea r14d, [r11d+eax*1]
00007d0bb21d012c  mov qword ptr [r15+0x88], 0x04
00007d0bb21d0137  mov eax, [rsp+0x30]
00007d0bb21d013b  lea r11d, [r9d+eax*1]
00007d0bb21d0140  mov eax, [rsp+0x40]
00007d0bb21d0144  lea r10d, [r14d+eax*1]
00007d0bb21d0149  mov r10d, r10d
00007d0bb21d014c  mov [r15+0xB8], r10
00007d0bb21d0153  xor eax, eax
00007d0bb21d0155  mov r10d, 0x04
00007d0bb21d015b  mov r9d, 0x100
00007d0bb21d0161  cmp r10, r9
00007d0bb21d0164  cmc
00007d0bb21d0165  lahf
00007d0bb21d0166  seto al
00007d0bb21d0169  mov [r15+0x108], eax
00007d0bb21d0170  lea eax, [r11d+r14d*1]
00007d0bb21d0175  mov eax, eax
00007d0bb21d0177  mov [r15+0xA8], rax
00007d0bb21d017e  mov r12d, r12d
00007d0bb21d0181  mov [r15+0xB0], r12
00007d0bb21d0188  mov eax, [rsp+0x10]
00007d0bb21d018c  mov eax, eax
00007d0bb21d018e  mov [r15+0xC0], rax
00007d0bb21d0195  mov r8d, r8d
00007d0bb21d0198  mov [r15+0xC8], r8
00007d0bb21d019f  mov eax, [r15+0x108]
00007d0bb21d01a6  sahf
00007d0bb21d01a7  jnz 0x00007D0BB21D01D9
00007d0bb21d01a9  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d01b1  jz 0x00007D0BB21D04A0
00007d0bb21d01b7  nop [rax+rax*1], ax
00007d0bb21d01c0  nop [rax+rax*1], eax
00007d0bb21d01c8  mov eax, 0x41094C
00007d0bb21d01cd  mov [r15+0x100], rax
00007d0bb21d01d4  jmp 0x00007D0BB1FFE110
00007d0bb21d01d9  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d01e1  jz 0x00007D0BB21D0270
00007d0bb21d01e7  nop [rax+rax*1], ax
00007d0bb21d01f0  nop [rax+rax*1], eax
00007d0bb21d01f8  mov eax, 0x4108C0
00007d0bb21d01fd  mov [r15+0x100], rax
00007d0bb21d0204  jmp 0x00007D0BB1FFE110
00007d0bb21d0209  int3
00007d0bb21d020a  call 0x00007D0BB200DAE0
00007d0bb21d020f  jmp 0x00007D0BB21CFF78
00007d0bb21d0214  call 0x00007D0BB20C0230
00007d0bb21d0219  jmp 0x00007D0BB21CFF81
00007d0bb21d021e  call 0x00007D0BB20E26A0
00007d0bb21d0223  jmp 0x00007D0BB21CFFA5
00007d0bb21d0228  call 0x00007D0BB20E1430
00007d0bb21d022d  jmp 0x00007D0BB21CFFAE
00007d0bb21d0232  call 0x00007D0BB20E26A0
00007d0bb21d0237  jmp 0x00007D0BB21CFFCF
00007d0bb21d023c  call 0x00007D0BB20E1430
00007d0bb21d0241  jmp 0x00007D0BB21CFFD8
00007d0bb21d0246  call 0x00007D0BB20E26A0
00007d0bb21d024b  jmp 0x00007D0BB21CFFF9
00007d0bb21d0250  call 0x00007D0BB20D5890
00007d0bb21d0255  jmp 0x00007D0BB21D0002
00007d0bb21d025a  call 0x00007D0BB20BDD50
00007d0bb21d025f  jmp 0x00007D0BB21D0098
00007d0bb21d0264  call 0x00007D0BB20DA580
00007d0bb21d0269  jmp 0x00007D0BB21D00CF
00007d0bb21d026e  int3
00007d0bb21d026f  nop
00007d0bb21d0270  mov eax, [r15+0xB8]
00007d0bb21d0277  mov [rsp+0x10], eax
00007d0bb21d027b  mov eax, eax
00007d0bb21d027d  mov [r15+0x30], rax
00007d0bb21d0281  mov eax, [r15+0xC0]
00007d0bb21d0288  mov [rsp+0x20], eax
00007d0bb21d028c  mov eax, eax
00007d0bb21d028e  mov [r15+0xA0], rax
00007d0bb21d0295  mov eax, [r15+0x28]
00007d0bb21d0299  mov r14d, [r15+0x98]
00007d0bb21d02a0  mov [rsp+0x30], r14d
00007d0bb21d02a5  mov r14d, r14d
00007d0bb21d02a8  mov [r15+0x28], r14
00007d0bb21d02ac  mov r14d, [r15+0x38]
00007d0bb21d02b0  mov [rsp+0x40], r14d
00007d0bb21d02b5  mov r14d, r14d
00007d0bb21d02b8  mov [r15+0x98], r14
00007d0bb21d02bf  mov r14d, [r15+0xA8]
00007d0bb21d02c6  mov [rsp+0x50], r14d
00007d0bb21d02cb  mov r14d, r14d
00007d0bb21d02ce  mov [r15+0x38], r14
00007d0bb21d02d2  mov r14d, [rsp+0x10]
00007d0bb21d02d7  mov r12d, [rsp+0x10]
00007d0bb21d02dc  shrd r14d, r12d, 0x06
00007d0bb21d02e1  mov r11d, [r15+0xC8]
00007d0bb21d02e8  mov [rsp+0x10], r12d
00007d0bb21d02ed  and r12d, r11d
00007d0bb21d02f0  mov r10d, [rsp+0x50]
00007d0bb21d02f5  mov r9d, [rsp+0x50]
00007d0bb21d02fa  shrd r10d, r9d, 0x02
00007d0bb21d02ff  mov [rsp+0x50], r11d
00007d0bb21d0304  mov r11d, r11d
00007d0bb21d0307  mov [r15+0x20], r11
00007d0bb21d030b  mov r11, [r15+0x88]
00007d0bb21d0312  mov r8, [r15+0x50]
00007d0bb21d0316  lea rbp, [r8+r11*1]
00007d0bb21d031a  mov r8d, [r13+rbp*1]
00007d0bb21d031f  mov ebp, [rsp+0x20]
00007d0bb21d0323  mov edi, [rsp+0x10]
00007d0bb21d0327  andn esi, edi, ebp
00007d0bb21d032c  mov edx, [r15+0xB0]
00007d0bb21d0333  lea ecx, [r12d+edx*1]
00007d0bb21d0338  rorx r12d, edi, 0x0B
00007d0bb21d033e  xor r14d, r12d
00007d0bb21d0341  rorx r12d, r9d, 0x0D
00007d0bb21d0347  xor r10d, r12d
00007d0bb21d034a  lea r12d, [ecx+esi*1]
00007d0bb21d034f  mov rsi, [r15+0x48]
00007d0bb21d0353  lea rdx, [rsi+r11*1]
00007d0bb21d0357  mov esi, [r13+rdx*1]
00007d0bb21d035c  mov edx, [rsp+0x30]
00007d0bb21d0360  mov ecx, [rsp+0x40]
00007d0bb21d0364  and edx, ecx
00007d0bb21d0366  mov [rsp+0x10], edx
00007d0bb21d036a  mov edx, edx
00007d0bb21d036c  mov [r15+0xD8], rdx
00007d0bb21d0373  lea edx, [r12d+r8d*1]
00007d0bb21d0378  mov r12d, [rsp+0x30]
00007d0bb21d037d  xor r12d, ecx
00007d0bb21d0380  rorx r8d, edi, 0x19
00007d0bb21d0386  xor r14d, r8d
00007d0bb21d0389  and r12d, r9d
00007d0bb21d038c  rorx r8d, r9d, 0x16
00007d0bb21d0392  xor r10d, r8d
00007d0bb21d0395  mov [rsp+0x20], r10d
00007d0bb21d039a  mov r10d, r10d
00007d0bb21d039d  mov [r15+0xD0], r10
00007d0bb21d03a4  lea r10d, [edx+esi*1]
00007d0bb21d03a9  mov r9d, [rsp+0x10]
00007d0bb21d03ae  xor r12d, r9d
00007d0bb21d03b1  lea r9d, [r10d+r14d*1]
00007d0bb21d03b6  lea r14, [r11+0x04]
00007d0bb21d03ba  mov [r15+0x88], r14
00007d0bb21d03c1  mov r11d, [rsp+0x20]
00007d0bb21d03c6  lea r10d, [r12d+r11d*1]
00007d0bb21d03cb  lea r11d, [r9d+eax*1]
00007d0bb21d03d0  mov r11d, r11d
00007d0bb21d03d3  mov [r15+0xB8], r11
00007d0bb21d03da  xor eax, eax
00007d0bb21d03dc  mov r12d, 0x100
00007d0bb21d03e2  cmp r14, r12
00007d0bb21d03e5  cmc
00007d0bb21d03e6  lahf
00007d0bb21d03e7  seto al
00007d0bb21d03ea  mov [r15+0x108], eax
00007d0bb21d03f1  lea eax, [r10d+r9d*1]
00007d0bb21d03f6  mov eax, eax
00007d0bb21d03f8  mov [r15+0xA8], rax
00007d0bb21d03ff  mov ebp, ebp
00007d0bb21d0401  mov [r15+0xB0], rbp
00007d0bb21d0408  mov eax, [rsp+0x50]
00007d0bb21d040c  mov eax, eax
00007d0bb21d040e  mov [r15+0xC0], rax
00007d0bb21d0415  mov edi, edi
00007d0bb21d0417  mov [r15+0xC8], rdi
00007d0bb21d041e  mov eax, [r15+0x108]
00007d0bb21d0425  sahf
00007d0bb21d0426  jnz 0x00007D0BB21D0458
00007d0bb21d0428  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d0430  jz 0x00007D0BB21D04A0
00007d0bb21d0436  nop [rax+rax*1], ax
00007d0bb21d043f  nop [rax+rax*1], eax
00007d0bb21d0447  mov eax, 0x41094C
00007d0bb21d044c  mov [r15+0x100], rax
00007d0bb21d0453  jmp 0x00007D0BB1FFE110
00007d0bb21d0458  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d0460  jz 0x00007D0BB21D0270
00007d0bb21d0466  nop [rax+rax*1], ax
00007d0bb21d046f  nop [rax+rax*1], eax
00007d0bb21d0477  mov eax, 0x4108C0
00007d0bb21d047c  mov [r15+0x100], rax
00007d0bb21d0483  jmp 0x00007D0BB1FFE110
00007d0bb21d0488  int3
00007d0bb21d0489  call 0x00007D0BB2049010
00007d0bb21d048e  jmp 0x00007D0BB21D031F
00007d0bb21d0493  call 0x00007D0BB2025930
00007d0bb21d0498  jmp 0x00007D0BB21D035C
00007d0bb21d049d  int3
00007d0bb21d049e  nop
00007d0bb21d04a0  mov eax, [r15+0x98]
00007d0bb21d04a7  mov r14d, [r15+0x70]
00007d0bb21d04ab  lea r12d, [eax+r14d*1]
00007d0bb21d04b0  mov eax, [r15+0x28]
00007d0bb21d04b4  mov r14d, [r15+0x68]
00007d0bb21d04b8  lea r11d, [eax+r14d*1]
00007d0bb21d04bd  mov qword ptr [r15+0x88], 0x00
00007d0bb21d04c8  mov eax, [r15+0xA8]
00007d0bb21d04cf  mov r14d, [r15+0x78]
00007d0bb21d04d3  lea r10d, [eax+r14d*1]
00007d0bb21d04d8  mov [rsp+0x10], r10d
00007d0bb21d04dd  mov r10d, r10d
00007d0bb21d04e0  mov [r15+0x78], r10
00007d0bb21d04e4  mov eax, [r15+0x38]
00007d0bb21d04e8  mov r14d, [r15+0x80]
00007d0bb21d04ef  lea r10d, [eax+r14d*1]
00007d0bb21d04f4  mov [rsp+0x20], r10d
00007d0bb21d04f9  mov r10d, r10d
00007d0bb21d04fc  mov [r15+0x80], r10
00007d0bb21d0503  mov rax, [r15]
00007d0bb21d0506  lea r14, [rax+0x08]
00007d0bb21d050a  mov [r13+r14*1], r12d
00007d0bb21d050f  lea r14, [rax+0x0C]
00007d0bb21d0513  mov [r13+r14*1], r11d
00007d0bb21d0518  mov r14d, [r15+0xB8]
00007d0bb21d051f  mov r12d, [r15+0x18]
00007d0bb21d0523  lea r11d, [r14d+r12d*1]
00007d0bb21d0528  mov [rsp+0x30], r11d
00007d0bb21d052d  mov r11d, r11d
00007d0bb21d0530  mov [r15+0x68], r11
00007d0bb21d0534  mov r14d, [r15+0x30]
00007d0bb21d0538  mov r12d, [r15+0x90]
00007d0bb21d053f  lea r11d, [r14d+r12d*1]
00007d0bb21d0544  mov [rsp+0x40], r11d
00007d0bb21d0549  mov r11d, r11d
00007d0bb21d054c  mov [r15+0x70], r11
00007d0bb21d0550  mov r14d, [r15+0x20]
00007d0bb21d0554  mov r12d, [r15+0x58]
00007d0bb21d0558  lea r11d, [r14d+r12d*1]
00007d0bb21d055d  mov [rsp+0x50], r11d
00007d0bb21d0562  mov r11d, r11d
00007d0bb21d0565  mov [r15+0x58], r11
00007d0bb21d0569  mov r14d, [r15+0xA0]
00007d0bb21d0570  mov r12d, [r15+0x60]
00007d0bb21d0574  lea r11d, [r14d+r12d*1]
00007d0bb21d0579  mov [rsp+0x60], r11d
00007d0bb21d057e  mov r11d, r11d
00007d0bb21d0581  mov [r15+0x60], r11
00007d0bb21d0585  mov r14d, [rsp+0x10]
00007d0bb21d058a  mov [r13+rax*1], r14d
00007d0bb21d058f  lea r14, [rax+0x04]
00007d0bb21d0593  mov r12d, [rsp+0x20]
00007d0bb21d0598  mov [r13+r14*1], r12d
00007d0bb21d059d  lea r14, [rax+0x10]
00007d0bb21d05a1  mov r12d, [rsp+0x30]
00007d0bb21d05a6  mov [r13+r14*1], r12d
00007d0bb21d05ab  lea r14, [rax+0x14]
00007d0bb21d05af  mov r12d, [rsp+0x40]
00007d0bb21d05b4  mov [r13+r14*1], r12d
00007d0bb21d05b9  lea r14, [rax+0x18]
00007d0bb21d05bd  mov r12d, [rsp+0x50]
00007d0bb21d05c2  mov [r13+r14*1], r12d
00007d0bb21d05c7  lea r14, [rax+0x1C]
00007d0bb21d05cb  mov r12d, [rsp+0x60]
00007d0bb21d05d0  mov [r13+r14*1], r12d
00007d0bb21d05d5  lea r14, [rax+0x68]
00007d0bb21d05d9  xor eax, eax
00007d0bb21d05db  mov [r13+r14*1], rax
00007d0bb21d05e0  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d05e8  jz 0x00007D0BB21CF0E0
00007d0bb21d05ee  nop [rax+rax*1], ax
00007d0bb21d05f7  nop [rax+rax*1], eax
00007d0bb21d05ff  mov eax, 0x410768
00007d0bb21d0604  mov [r15+0x100], rax
00007d0bb21d060b  jmp 0x00007D0BB1FFE110
00007d0bb21d0610  int3
00007d0bb21d0611  call 0x00007D0BB20E2BA0
00007d0bb21d0616  jmp 0x00007D0BB21D050F
00007d0bb21d061b  call 0x00007D0BB20E1920
00007d0bb21d0620  jmp 0x00007D0BB21D0518
00007d0bb21d0625  call 0x00007D0BB200DFE0
00007d0bb21d062a  jmp 0x00007D0BB21D058F
00007d0bb21d062f  call 0x00007D0BB20E2BA0
00007d0bb21d0634  jmp 0x00007D0BB21D059D
00007d0bb21d0639  call 0x00007D0BB20E2BA0
00007d0bb21d063e  jmp 0x00007D0BB21D05AB
00007d0bb21d0643  call 0x00007D0BB20E2BA0
00007d0bb21d0648  jmp 0x00007D0BB21D05B9
00007d0bb21d064d  call 0x00007D0BB20E2BA0
00007d0bb21d0652  jmp 0x00007D0BB21D05C7
00007d0bb21d0657  call 0x00007D0BB20E2BA0
00007d0bb21d065c  jmp 0x00007D0BB21D05D5
00007d0bb21d0661  call 0x00007D0BB20D5EB0
00007d0bb21d0666  jmp 0x00007D0BB21D05E0
00007d0bb21d066b  int3
00007d0bb21d066c  nop [rax], eax
00007d0bb21d0670  mov rax, [r15+0xF8]
00007d0bb21d0677  lea r14, [rax+0x140]
00007d0bb21d067e  mov r12, [r13+r14*1]
00007d0bb21d0683  lea r14, [rax+0x148]
00007d0bb21d068a  mov r11, [r13+r14*1]
00007d0bb21d068f  mov [r15+0xA0], r12
00007d0bb21d0696  mov [r15+0x98], r11
00007d0bb21d069d  lea r14, [rax+0x130]
00007d0bb21d06a4  mov r12, [r13+r14*1]
00007d0bb21d06a9  lea r14, [rax+0x138]
00007d0bb21d06b0  mov r11, [r13+r14*1]
00007d0bb21d06b5  mov [r15+0xB0], r12
00007d0bb21d06bc  mov [r15+0xA8], r11
00007d0bb21d06c3  lea r14, [rax+0x120]
00007d0bb21d06ca  mov r12, [r13+r14*1]
00007d0bb21d06cf  lea r14, [rax+0x128]
00007d0bb21d06d6  mov r11, [r13+r14*1]
00007d0bb21d06db  mov [r15+0xC0], r12
00007d0bb21d06e2  mov [r15+0xB8], r11
00007d0bb21d06e9  lea r14, [rax+0x110]
00007d0bb21d06f0  mov r12, [r13+r14*1]
00007d0bb21d06f5  lea r14, [rax+0x118]
00007d0bb21d06fc  mov r11, [r13+r14*1]
00007d0bb21d0701  mov [r15+0xD0], r12
00007d0bb21d0708  mov [r15+0xC8], r11
00007d0bb21d070f  lea r14, [rax+0x100]
00007d0bb21d0716  mov r12, [r13+r14*1]
00007d0bb21d071b  lea r14, [rax+0x108]
00007d0bb21d0722  mov r11, [r13+r14*1]
00007d0bb21d0727  mov [r15+0xE8], r12
00007d0bb21d072e  mov [r15+0xD8], r11
00007d0bb21d0735  lea r14, [rax+0x150]
00007d0bb21d073c  mov [r15+0xF8], r14
00007d0bb21d0743  mov rax, [r15+0xF0]
00007d0bb21d074a  mov [r15+0x100], rax
00007d0bb21d0751  jmp 0x00007D0BB21CE5C0
00007d0bb21d0756  int3
00007d0bb21d0757  call 0x00007D0BB20E27E0
00007d0bb21d075c  jmp 0x00007D0BB21D0683
00007d0bb21d0761  call 0x00007D0BB20E1570
00007d0bb21d0766  jmp 0x00007D0BB21D068F
00007d0bb21d076b  call 0x00007D0BB20E27E0
00007d0bb21d0770  jmp 0x00007D0BB21D06A9
00007d0bb21d0775  call 0x00007D0BB20E1570
00007d0bb21d077a  jmp 0x00007D0BB21D06B5
00007d0bb21d077f  call 0x00007D0BB20E27E0
00007d0bb21d0784  jmp 0x00007D0BB21D06CF
00007d0bb21d0789  call 0x00007D0BB20E1570
00007d0bb21d078e  jmp 0x00007D0BB21D06DB
00007d0bb21d0793  call 0x00007D0BB20E27E0
00007d0bb21d0798  jmp 0x00007D0BB21D06F5
00007d0bb21d079d  call 0x00007D0BB20E1570
00007d0bb21d07a2  jmp 0x00007D0BB21D0701
00007d0bb21d07a7  call 0x00007D0BB20E27E0
00007d0bb21d07ac  jmp 0x00007D0BB21D071B
00007d0bb21d07b1  call 0x00007D0BB20E1570
00007d0bb21d07b6  jmp 0x00007D0BB21D0727
00007d0bb21d07bb  int3
00007d0bb21d07bc  nop [rax], eax
00007d0bb21d07c0  mov eax, [r15+0xA0]
00007d0bb21d07c7  mov [rsp+0x10], eax
00007d0bb21d07cb  xor eax, eax
00007d0bb21d07cd  mov r14d, [rsp+0x10]
00007d0bb21d07d2  sub r14d, 0x01
00007d0bb21d07d6  cmc
00007d0bb21d07d7  lahf
00007d0bb21d07d8  seto al
00007d0bb21d07db  mov [r15+0x108], eax
00007d0bb21d07e2  mov r14d, r14d
00007d0bb21d07e5  mov [r15+0xA0], r14
00007d0bb21d07ec  mov eax, [r15+0x108]
00007d0bb21d07f3  sahf
00007d0bb21d07f4  jnz 0x00007D0BB21D0826
00007d0bb21d07f6  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d07fe  jz 0x00007D0BB21D0900
00007d0bb21d0804  nop [rax+rax*1], ax
00007d0bb21d080d  nop [rax+rax*1], eax
00007d0bb21d0815  mov eax, 0x41028C
00007d0bb21d081a  mov [r15+0x100], rax
00007d0bb21d0821  jmp 0x00007D0BB1FFE110
00007d0bb21d0826  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d082e  jz 0x00007D0BB21D0860
00007d0bb21d0834  nop [rax+rax*1], ax
00007d0bb21d083d  nop [rax+rax*1], eax
00007d0bb21d0845  mov eax, 0x410274
00007d0bb21d084a  mov [r15+0x100], rax
00007d0bb21d0851  jmp 0x00007D0BB1FFE110
00007d0bb21d0856  int3
00007d0bb21d0857  int3
00007d0bb21d0858  nop [rax+rax*1], eax
00007d0bb21d0860  mov rax, [r15+0xF8]
00007d0bb21d0867  lea r14, [rax+0x100]
00007d0bb21d086e  mov [r15], r14
00007d0bb21d0871  mov rax, [r15+0x98]
00007d0bb21d0878  mov [r15+0x08], rax
00007d0bb21d087c  mov qword ptr [r15+0x10], 0x12C
00007d0bb21d0884  mov qword ptr [r15+0xF0], 0x410284
00007d0bb21d088f  mov r14d, [r15+0x320]
00007d0bb21d0896  mov eax, 0x410284
00007d0bb21d089b  mov rcx, 0x7D0BB21D07C0
00007d0bb21d08a5  mov [r15+r14*8+0x328], rax
00007d0bb21d08ad  mov [r15+r14*8+0x368], rcx
00007d0bb21d08b5  add r14d, 0x01
00007d0bb21d08b9  and r14d, 0x07
00007d0bb21d08bd  mov [r15+0x320], r14d
00007d0bb21d08c4  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d08cc  jz 0x00007D0BB21CED70
00007d0bb21d08d2  nop [rax+rax*1], ax
00007d0bb21d08db  nop [rax+rax*1], eax
00007d0bb21d08e3  mov eax, 0x410728
00007d0bb21d08e8  mov [r15+0x100], rax
00007d0bb21d08ef  jmp 0x00007D0BB1FFE110
00007d0bb21d08f4  int3
00007d0bb21d08f5  int3
00007d0bb21d08f6  nop [rax+rax*1], ax
00007d0bb21d08ff  nop
00007d0bb21d0900  mov rax, [r15+0xF8]
00007d0bb21d0907  lea r14, [rax+0x120]
00007d0bb21d090e  mov r12, [r13+r14*1]
00007d0bb21d0913  mov [r15+0x98], r12
00007d0bb21d091a  mov qword ptr [r15+0x40], 0x80
00007d0bb21d0922  lea r14, [rax+0x100]
00007d0bb21d0929  mov [r15], r14
00007d0bb21d092c  lea r14, [rax+0x17C]
00007d0bb21d0933  mov [r15+0x08], r14
00007d0bb21d0937  mov qword ptr [r15+0x10], 0x01
00007d0bb21d093f  lea r14, [rax+0x17C]
00007d0bb21d0946  mov eax, 0x80
00007d0bb21d094b  mov [r13+r14*1], al
00007d0bb21d0950  mov qword ptr [r15+0xF0], 0x4102A8
00007d0bb21d095b  mov r14d, [r15+0x320]
00007d0bb21d0962  mov eax, 0x4102A8
00007d0bb21d0967  mov rcx, 0x7D0BB21D09E0
00007d0bb21d0971  mov [r15+r14*8+0x328], rax
00007d0bb21d0979  mov [r15+r14*8+0x368], rcx
00007d0bb21d0981  add r14d, 0x01
00007d0bb21d0985  and r14d, 0x07
00007d0bb21d0989  mov [r15+0x320], r14d
00007d0bb21d0990  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d0998  jz 0x00007D0BB21CED70
00007d0bb21d099e  nop [rax+rax*1], ax
00007d0bb21d09a7  nop [rax+rax*1], eax
00007d0bb21d09af  mov eax, 0x410728
00007d0bb21d09b4  mov [r15+0x100], rax
00007d0bb21d09bb  jmp 0x00007D0BB1FFE110
00007d0bb21d09c0  int3
00007d0bb21d09c1  call 0x00007D0BB20E27E0
00007d0bb21d09c6  jmp 0x00007D0BB21D0913
00007d0bb21d09cb  call 0x00007D0BB20D5AF0
00007d0bb21d09d0  jmp 0x00007D0BB21D0950
00007d0bb21d09d5  int3
00007d0bb21d09d6  nop [rax+rax*1], ax
00007d0bb21d09df  nop
00007d0bb21d09e0  mov rax, [r15+0xF8]
00007d0bb21d09e7  lea r14, [rax+0x168]
00007d0bb21d09ee  mov r12, [r13+r14*1]
00007d0bb21d09f3  mov [r15+0x40], r12
00007d0bb21d09f7  lea r14, [rax+0x178]
00007d0bb21d09fe  xor eax, eax
00007d0bb21d0a00  mov [r13+r14*1], al
00007d0bb21d0a05  xor eax, eax
00007d0bb21d0a07  mov r14d, 0x38
00007d0bb21d0a0d  cmp r12, r14
00007d0bb21d0a10  cmc
00007d0bb21d0a11  lahf
00007d0bb21d0a12  seto al
00007d0bb21d0a15  mov [r15+0x108], eax
00007d0bb21d0a1c  mov eax, [r15+0x108]
00007d0bb21d0a23  sahf
00007d0bb21d0a24  jz 0x00007D0BB21D0A56
00007d0bb21d0a26  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d0a2e  jz 0x00007D0BB21D0AA0
00007d0bb21d0a34  nop [rax+rax*1], ax
00007d0bb21d0a3d  nop [rax+rax*1], eax
00007d0bb21d0a45  mov eax, 0x4102B8
00007d0bb21d0a4a  mov [r15+0x100], rax
00007d0bb21d0a51  jmp 0x00007D0BB1FFE110
00007d0bb21d0a56  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d0a5e  jz 0x00007D0BB21D0BF0
00007d0bb21d0a64  nop [rax+rax*1], ax
00007d0bb21d0a6d  nop [rax+rax*1], eax
00007d0bb21d0a75  mov eax, 0x4102D4
00007d0bb21d0a7a  mov [r15+0x100], rax
00007d0bb21d0a81  jmp 0x00007D0BB1FFE110
00007d0bb21d0a86  int3
00007d0bb21d0a87  call 0x00007D0BB20E27E0
00007d0bb21d0a8c  jmp 0x00007D0BB21D09F3
00007d0bb21d0a91  call 0x00007D0BB20D5AF0
00007d0bb21d0a96  jmp 0x00007D0BB21D0A05
00007d0bb21d0a9b  int3
00007d0bb21d0a9c  nop [rax], eax
00007d0bb21d0aa0  mov rax, [r15+0xF8]
00007d0bb21d0aa7  lea r14, [rax+0x100]
00007d0bb21d0aae  mov [r15], r14
00007d0bb21d0ab1  lea r14, [rax+0x178]
00007d0bb21d0ab8  mov [r15+0x08], r14
00007d0bb21d0abc  mov qword ptr [r15+0x10], 0x01
00007d0bb21d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007d0bb21d0acf  mov r14d, [r15+0x320]
00007d0bb21d0ad6  mov eax, 0x4102C8
00007d0bb21d0adb  mov rcx, 0x7D0BB21D0B40
00007d0bb21d0ae5  mov [r15+r14*8+0x328], rax
00007d0bb21d0aed  mov [r15+r14*8+0x368], rcx
00007d0bb21d0af5  add r14d, 0x01
00007d0bb21d0af9  and r14d, 0x07
00007d0bb21d0afd  mov [r15+0x320], r14d
00007d0bb21d0b04  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d0b0c  jz 0x00007D0BB21CED70
00007d0bb21d0b12  nop [rax+rax*1], ax
00007d0bb21d0b1b  nop [rax+rax*1], eax
00007d0bb21d0b23  mov eax, 0x410728
00007d0bb21d0b28  mov [r15+0x100], rax
00007d0bb21d0b2f  jmp 0x00007D0BB1FFE110
00007d0bb21d0b34  int3
00007d0bb21d0b35  int3
00007d0bb21d0b36  nop [rax+rax*1], ax
00007d0bb21d0b3f  nop
00007d0bb21d0b40  mov rax, [r15+0xF8]
00007d0bb21d0b47  lea r14, [rax+0x168]
00007d0bb21d0b4e  mov rax, [r13+r14*1]
00007d0bb21d0b53  mov [r15+0x40], rax
00007d0bb21d0b57  mov [rsp+0x10], rax
00007d0bb21d0b5c  xor eax, eax
00007d0bb21d0b5e  mov r14, [rsp+0x10]
00007d0bb21d0b63  mov r12d, 0x38
00007d0bb21d0b69  cmp r14, r12
00007d0bb21d0b6c  cmc
00007d0bb21d0b6d  lahf
00007d0bb21d0b6e  seto al
00007d0bb21d0b71  mov [r15+0x108], eax
00007d0bb21d0b78  mov eax, [r15+0x108]
00007d0bb21d0b7f  sahf
00007d0bb21d0b80  jnz 0x00007D0BB21D0BB2
00007d0bb21d0b82  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d0b8a  jz 0x00007D0BB21D0BF0
00007d0bb21d0b90  nop [rax+rax*1], ax
00007d0bb21d0b99  nop [rax+rax*1], eax
00007d0bb21d0ba1  mov eax, 0x4102D4
00007d0bb21d0ba6  mov [r15+0x100], rax
00007d0bb21d0bad  jmp 0x00007D0BB1FFE110
00007d0bb21d0bb2  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d0bba  jz 0x00007D0BB21D0AA0
00007d0bb21d0bc0  nop [rax+rax*1], ax
00007d0bb21d0bc9  nop [rax+rax*1], eax
00007d0bb21d0bd1  mov eax, 0x4102B8
00007d0bb21d0bd6  mov [r15+0x100], rax
00007d0bb21d0bdd  jmp 0x00007D0BB1FFE110
00007d0bb21d0be2  int3
00007d0bb21d0be3  call 0x00007D0BB20D59C0
00007d0bb21d0be8  jmp 0x00007D0BB21D0B53
00007d0bb21d0bed  int3
00007d0bb21d0bee  nop
00007d0bb21d0bf0  mov rax, [r15+0x98]
00007d0bb21d0bf7  rorx r14, rax, 0x3D
00007d0bb21d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007d0bb21d0c01  mov rax, [r15+0xF8]
00007d0bb21d0c08  lea r12, [rax+0x100]
00007d0bb21d0c0f  mov [r15], r12
00007d0bb21d0c12  lea r12, [rax+0x170]
00007d0bb21d0c19  mov [r15+0x08], r12
00007d0bb21d0c1d  mov qword ptr [r15+0x10], 0x08
00007d0bb21d0c25  bswap r14
00007d0bb21d0c28  mov [r15+0x40], r14
00007d0bb21d0c2c  lea r12, [rax+0x170]
00007d0bb21d0c33  mov [r13+r12*1], r14
00007d0bb21d0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007d0bb21d0c43  mov r14d, [r15+0x320]
00007d0bb21d0c4a  mov eax, 0x4102F0
00007d0bb21d0c4f  mov rcx, 0x7D0BB21D0CC0
00007d0bb21d0c59  mov [r15+r14*8+0x328], rax
00007d0bb21d0c61  mov [r15+r14*8+0x368], rcx
00007d0bb21d0c69  add r14d, 0x01
00007d0bb21d0c6d  and r14d, 0x07
00007d0bb21d0c71  mov [r15+0x320], r14d
00007d0bb21d0c78  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d0c80  jz 0x00007D0BB21CED70
00007d0bb21d0c86  nop [rax+rax*1], ax
00007d0bb21d0c8f  nop [rax+rax*1], eax
00007d0bb21d0c97  mov eax, 0x410728
00007d0bb21d0c9c  mov [r15+0x100], rax
00007d0bb21d0ca3  jmp 0x00007D0BB1FFE110
00007d0bb21d0ca8  int3
00007d0bb21d0ca9  call 0x00007D0BB20C3FE0
00007d0bb21d0cae  jmp 0x00007D0BB21D0C38
00007d0bb21d0cb3  int3
00007d0bb21d0cb4  nop [rax+rax*1], ax
00007d0bb21d0cbd  nop [rax], eax
00007d0bb21d0cc0  mov rax, [r15+0xF8]
00007d0bb21d0cc7  lea r14, [rax+0x100]
00007d0bb21d0cce  mov r12d, [r13+r14*1]
00007d0bb21d0cd3  lea r14, [rax+0x104]
00007d0bb21d0cda  mov r11d, [r13+r14*1]
00007d0bb21d0cdf  mov qword ptr [r15+0x48], 0x430C90
00007d0bb21d0ce7  lea r14, [rax+0x108]
00007d0bb21d0cee  mov r10d, [r13+r14*1]
00007d0bb21d0cf3  lea r14, [rax+0x10C]
00007d0bb21d0cfa  mov r9d, [r13+r14*1]
00007d0bb21d0cff  bswap r12d
00007d0bb21d0d02  bswap r11d
00007d0bb21d0d05  mov qword ptr [r15+0xA0], 0x00
00007d0bb21d0d10  mov r14d, 0x430C90
00007d0bb21d0d16  mov [r13+r14*1], r12d
00007d0bb21d0d1b  mov r14d, 0x430C94
00007d0bb21d0d21  mov [r13+r14*1], r11d
00007d0bb21d0d26  bswap r10d
00007d0bb21d0d29  lea r14, [rax+0x110]
00007d0bb21d0d30  mov r12d, [r13+r14*1]
00007d0bb21d0d35  bswap r9d
00007d0bb21d0d38  lea r14, [rax+0x114]
00007d0bb21d0d3f  mov r11d, [r13+r14*1]
00007d0bb21d0d44  mov qword ptr [r15+0x98], 0x430DFC
00007d0bb21d0d4f  mov r14d, 0x430C98
00007d0bb21d0d55  mov [r13+r14*1], r10d
00007d0bb21d0d5a  mov r14d, 0x430C9C
00007d0bb21d0d60  mov [r13+r14*1], r9d
00007d0bb21d0d65  bswap r12d
00007d0bb21d0d68  lea r14, [rax+0x118]
00007d0bb21d0d6f  mov r10d, [r13+r14*1]
00007d0bb21d0d74  bswap r11d
00007d0bb21d0d77  mov [rsp+0x10], r11d
00007d0bb21d0d7c  mov r11d, r11d
00007d0bb21d0d7f  mov [r15+0x58], r11
00007d0bb21d0d83  lea r14, [rax+0x11C]
00007d0bb21d0d8a  mov eax, [r13+r14*1]
00007d0bb21d0d8f  mov [rsp+0x20], eax
00007d0bb21d0d93  mov eax, eax
00007d0bb21d0d95  mov [r15+0x60], rax
00007d0bb21d0d99  mov eax, 0x430CA0
00007d0bb21d0d9e  mov [r13+rax*1], r12d
00007d0bb21d0da3  mov eax, 0x430CA4
00007d0bb21d0da8  mov r14d, [rsp+0x10]
00007d0bb21d0dad  mov [r13+rax*1], r14d
00007d0bb21d0db2  bswap r10d
00007d0bb21d0db5  mov [rsp+0x10], r10d
00007d0bb21d0dba  mov r10d, r10d
00007d0bb21d0dbd  mov [r15+0x40], r10
00007d0bb21d0dc1  mov eax, [rsp+0x20]
00007d0bb21d0dc5  bswap eax
00007d0bb21d0dc7  mov [rsp+0x20], eax
00007d0bb21d0dcb  mov eax, eax
00007d0bb21d0dcd  mov [r15+0x50], rax
00007d0bb21d0dd1  mov eax, 0x430CA8
00007d0bb21d0dd6  mov r14d, [rsp+0x10]
00007d0bb21d0ddb  mov [r13+rax*1], r14d
00007d0bb21d0de0  mov eax, 0x430CAC
00007d0bb21d0de5  mov r14d, [rsp+0x20]
00007d0bb21d0dea  mov [r13+rax*1], r14d
00007d0bb21d0def  mov eax, [r15+0xA0]
00007d0bb21d0df6  lea r14d, [eax+0x11]
00007d0bb21d0dfb  mov r14d, r14d
00007d0bb21d0dfe  mov [r15], r14
00007d0bb21d0e01  mov qword ptr [r15+0xF0], 0x41035C
00007d0bb21d0e0c  mov r14d, [r15+0x320]
00007d0bb21d0e13  mov eax, 0x41035C
00007d0bb21d0e18  mov rcx, 0x7D0BB21D0F90
00007d0bb21d0e22  mov [r15+r14*8+0x328], rax
00007d0bb21d0e2a  mov [r15+r14*8+0x368], rcx
00007d0bb21d0e32  add r14d, 0x01
00007d0bb21d0e36  and r14d, 0x07
00007d0bb21d0e3a  mov [r15+0x320], r14d
00007d0bb21d0e41  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d0e49  jz 0x00007D0BB21D0F20
00007d0bb21d0e4f  nop [rax+rax*1], ax
00007d0bb21d0e58  nop [rax+rax*1], eax
00007d0bb21d0e60  mov eax, 0x4109A4
00007d0bb21d0e65  mov [r15+0x100], rax
00007d0bb21d0e6c  jmp 0x00007D0BB1FFE110
00007d0bb21d0e71  int3
00007d0bb21d0e72  call 0x00007D0BB20E26A0
00007d0bb21d0e77  jmp 0x00007D0BB21D0CD3
00007d0bb21d0e7c  call 0x00007D0BB20E1430
00007d0bb21d0e81  jmp 0x00007D0BB21D0CDF
00007d0bb21d0e86  call 0x00007D0BB20E01C0
00007d0bb21d0e8b  jmp 0x00007D0BB21D0CF3
00007d0bb21d0e90  call 0x00007D0BB20DEF50
00007d0bb21d0e95  jmp 0x00007D0BB21D0CFF
00007d0bb21d0e9a  call 0x00007D0BB20E2BA0
00007d0bb21d0e9f  jmp 0x00007D0BB21D0D1B
00007d0bb21d0ea4  call 0x00007D0BB20E1920
00007d0bb21d0ea9  jmp 0x00007D0BB21D0D26
00007d0bb21d0eae  call 0x00007D0BB20E26A0
00007d0bb21d0eb3  jmp 0x00007D0BB21D0D35
00007d0bb21d0eb8  call 0x00007D0BB20E1430
00007d0bb21d0ebd  jmp 0x00007D0BB21D0D44
00007d0bb21d0ec2  call 0x00007D0BB20E06B0
00007d0bb21d0ec7  jmp 0x00007D0BB21D0D5A
00007d0bb21d0ecc  call 0x00007D0BB20DF440
00007d0bb21d0ed1  jmp 0x00007D0BB21D0D65
00007d0bb21d0ed6  call 0x00007D0BB20E01C0
00007d0bb21d0edb  jmp 0x00007D0BB21D0D74
00007d0bb21d0ee0  call 0x00007D0BB20D5890
00007d0bb21d0ee5  jmp 0x00007D0BB21D0D8F
00007d0bb21d0eea  call 0x00007D0BB200BAE0
00007d0bb21d0eef  jmp 0x00007D0BB21D0DA3
00007d0bb21d0ef4  call 0x00007D0BB200DFE0
00007d0bb21d0ef9  jmp 0x00007D0BB21D0DB2
00007d0bb21d0efe  call 0x00007D0BB200DFE0
00007d0bb21d0f03  jmp 0x00007D0BB21D0DE0
00007d0bb21d0f08  call 0x00007D0BB200DFE0
00007d0bb21d0f0d  jmp 0x00007D0BB21D0DEF
00007d0bb21d0f12  int3
00007d0bb21d0f13  nop [rax+rax*1], ax
00007d0bb21d0f1c  nop [rax], eax
00007d0bb21d0f20  mov eax, [r15]
00007d0bb21d0f23  mov [rsp+0x10], eax
00007d0bb21d0f27  shr eax, 0x10
00007d0bb21d0f2a  mov r14d, [rsp+0x10]
00007d0bb21d0f2f  xor r14d, eax
00007d0bb21d0f32  imul r14d, r14d, 0x7FEB352D
00007d0bb21d0f39  mov eax, 0x846CA68B
00007d0bb21d0f3e  mov eax, eax
00007d0bb21d0f40  mov [r15+0x48], rax
00007d0bb21d0f44  mov [rsp+0x10], r14d
00007d0bb21d0f49  shr r14d, 0x0F
00007d0bb21d0f4d  mov eax, [rsp+0x10]
00007d0bb21d0f51  xor eax, r14d
00007d0bb21d0f54  imul eax, eax, 0x846CA68B
00007d0bb21d0f5a  mov [rsp+0x10], eax
00007d0bb21d0f5e  mov eax, eax
00007d0bb21d0f60  mov [r15+0x40], rax
00007d0bb21d0f64  mov eax, [rsp+0x10]
00007d0bb21d0f68  shr eax, 0x10
00007d0bb21d0f6b  mov r14d, [rsp+0x10]
00007d0bb21d0f70  xor r14d, eax
00007d0bb21d0f73  mov r14d, r14d
00007d0bb21d0f76  mov [r15], r14
00007d0bb21d0f79  mov rax, [r15+0xF0]
00007d0bb21d0f80  mov [r15+0x100], rax
00007d0bb21d0f87  jmp 0x00007D0BB21CE5C0
00007d0bb21d0f8c  int3
00007d0bb21d0f8d  int3
00007d0bb21d0f8e  nop
00007d0bb21d0f90  mov rax, [r15+0xA0]
00007d0bb21d0f97  mov [rsp+0x10], rax
00007d0bb21d0f9c  shl rax, 0x02
00007d0bb21d0fa0  mov r14, [r15+0x98]
00007d0bb21d0fa7  lea r12, [r14+rax*1]
00007d0bb21d0fab  mov eax, [r15]
00007d0bb21d0fae  mov [r13+r12*1], eax
00007d0bb21d0fb3  mov rax, [rsp+0x10]
00007d0bb21d0fb8  lea r14, [rax+0x01]
00007d0bb21d0fbc  mov [r15+0xA0], r14
00007d0bb21d0fc3  xor eax, eax
00007d0bb21d0fc5  mov r12d, 0x400
00007d0bb21d0fcb  cmp r14, r12
00007d0bb21d0fce  cmc
00007d0bb21d0fcf  lahf
00007d0bb21d0fd0  seto al
00007d0bb21d0fd3  mov [r15+0x108], eax
00007d0bb21d0fda  mov eax, [r15+0x108]
00007d0bb21d0fe1  sahf
00007d0bb21d0fe2  jnz 0x00007D0BB21D1014
00007d0bb21d0fe4  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d0fec  jz 0x00007D0BB21D10E0
00007d0bb21d0ff2  nop [rax+rax*1], ax
00007d0bb21d0ffb  nop [rax+rax*1], eax
00007d0bb21d1003  mov eax, 0x41036C
00007d0bb21d1008  mov [r15+0x100], rax
00007d0bb21d100f  jmp 0x00007D0BB1FFE110
00007d0bb21d1014  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d101c  jz 0x00007D0BB21D1050
00007d0bb21d1022  nop [rax+rax*1], ax
00007d0bb21d102b  nop [rax+rax*1], eax
00007d0bb21d1033  mov eax, 0x410354
00007d0bb21d1038  mov [r15+0x100], rax
00007d0bb21d103f  jmp 0x00007D0BB1FFE110
00007d0bb21d1044  int3
00007d0bb21d1045  call 0x00007D0BB20B4B70
00007d0bb21d104a  jmp 0x00007D0BB21D0FB3
00007d0bb21d104f  int3
00007d0bb21d1050  mov eax, [r15+0xA0]
00007d0bb21d1057  lea r14d, [eax+0x11]
00007d0bb21d105c  mov r14d, r14d
00007d0bb21d105f  mov [r15], r14
00007d0bb21d1062  mov qword ptr [r15+0xF0], 0x41035C
00007d0bb21d106d  mov r14d, [r15+0x320]
00007d0bb21d1074  mov eax, 0x41035C
00007d0bb21d1079  mov rcx, 0x7D0BB21D0F90
00007d0bb21d1083  mov [r15+r14*8+0x328], rax
00007d0bb21d108b  mov [r15+r14*8+0x368], rcx
00007d0bb21d1093  add r14d, 0x01
00007d0bb21d1097  and r14d, 0x07
00007d0bb21d109b  mov [r15+0x320], r14d
00007d0bb21d10a2  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d10aa  jz 0x00007D0BB21D0F20
00007d0bb21d10b0  nop [rax+rax*1], ax
00007d0bb21d10b9  nop [rax+rax*1], eax
00007d0bb21d10c1  mov eax, 0x4109A4
00007d0bb21d10c6  mov [r15+0x100], rax
00007d0bb21d10cd  jmp 0x00007D0BB1FFE110
00007d0bb21d10d2  int3
00007d0bb21d10d3  int3
00007d0bb21d10d4  nop [rax+rax*1], ax
00007d0bb21d10dd  nop [rax], eax
00007d0bb21d10e0  mov qword ptr [r15+0x40], 0x01
00007d0bb21d10e8  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d10f0  jz 0x00007D0BB21D1120
00007d0bb21d10f6  nop [rax+rax*1], ax
00007d0bb21d10ff  nop [rax+rax*1], eax
00007d0bb21d1107  mov eax, 0x410388
00007d0bb21d110c  mov [r15+0x100], rax
00007d0bb21d1113  jmp 0x00007D0BB1FFE110
00007d0bb21d1118  int3
00007d0bb21d1119  int3
00007d0bb21d111a  nop [rax+rax*1], ax
00007d0bb21d1120  mov rax, [r15+0x40]
00007d0bb21d1124  mov [rsp+0x10], rax
00007d0bb21d1129  shl rax, 0x02
00007d0bb21d112d  mov r14, [r15+0x98]
00007d0bb21d1134  lea r12, [r14+rax*1]
00007d0bb21d1138  mov eax, [r13+r12*1]
00007d0bb21d113d  mov [rsp+0x20], eax
00007d0bb21d1141  mov eax, eax
00007d0bb21d1143  mov [r15+0x48], rax
00007d0bb21d1147  mov rax, [rsp+0x10]
00007d0bb21d114c  mov [r15+0x50], rax
00007d0bb21d1150  mov eax, [r15+0x50]
00007d0bb21d1154  lea r12d, [eax-0x01]
00007d0bb21d1159  mov r12d, r12d
00007d0bb21d115c  mov [r15+0x58], r12
00007d0bb21d1160  mov rax, [r15+0x58]
00007d0bb21d1164  mov r12d, eax
00007d0bb21d1167  mov r12d, r12d
00007d0bb21d116a  shl r12, 0x02
00007d0bb21d116e  lea rax, [r14+r12*1]
00007d0bb21d1172  mov r14d, [r13+rax*1]
00007d0bb21d1177  mov [rsp+0x10], r14d
00007d0bb21d117c  mov r14d, r14d
00007d0bb21d117f  mov [r15+0x60], r14
00007d0bb21d1183  xor eax, eax
00007d0bb21d1185  mov r14d, [rsp+0x10]
00007d0bb21d118a  mov r12d, [rsp+0x20]
00007d0bb21d118f  cmp r14d, r12d
00007d0bb21d1192  cmc
00007d0bb21d1193  lahf
00007d0bb21d1194  seto al
00007d0bb21d1197  mov [r15+0x108], eax
00007d0bb21d119e  mov eax, [r15+0x108]
00007d0bb21d11a5  sahf
00007d0bb21d11a6  cmc
00007d0bb21d11a7  jbe 0x00007D0BB21D11D9
00007d0bb21d11a9  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d11b1  jz 0x00007D0BB21D1220
00007d0bb21d11b7  nop [rax+rax*1], ax
00007d0bb21d11c0  nop [rax+rax*1], eax
00007d0bb21d11c8  mov eax, 0x4103A0
00007d0bb21d11cd  mov [r15+0x100], rax
00007d0bb21d11d4  jmp 0x00007D0BB1FFE110
00007d0bb21d11d9  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d11e1  jz 0x00007D0BB21D14C0
00007d0bb21d11e7  nop [rax+rax*1], ax
00007d0bb21d11f0  nop [rax+rax*1], eax
00007d0bb21d11f8  mov eax, 0x410378
00007d0bb21d11fd  mov [r15+0x100], rax
00007d0bb21d1204  jmp 0x00007D0BB1FFE110
00007d0bb21d1209  int3
00007d0bb21d120a  call 0x00007D0BB20B4690
00007d0bb21d120f  jmp 0x00007D0BB21D113D
00007d0bb21d1214  call 0x00007D0BB200DAE0
00007d0bb21d1219  jmp 0x00007D0BB21D1177
00007d0bb21d121e  int3
00007d0bb21d121f  nop
00007d0bb21d1220  mov rax, [r15+0x50]
00007d0bb21d1224  mov [rsp+0x10], rax
00007d0bb21d1229  shl rax, 0x02
00007d0bb21d122d  mov r14, [r15+0x98]
00007d0bb21d1234  lea r12, [r14+rax*1]
00007d0bb21d1238  mov eax, [r15+0x60]
00007d0bb21d123c  mov [r13+r12*1], eax
00007d0bb21d1241  mov rax, [rsp+0x10]
00007d0bb21d1246  lea r14, [rax-0x01]
00007d0bb21d124a  mov [r15+0x50], r14
00007d0bb21d124e  mov rax, [r15+0x58]
00007d0bb21d1252  test rax, rax
00007d0bb21d1255  setz al
00007d0bb21d1258  movzx rax, al
00007d0bb21d125c  mov [rsp+0x414], al
00007d0bb21d1263  cmp byte ptr [rsp+0x414], 0x00
00007d0bb21d126b  jz 0x00007D0BB21D129D
00007d0bb21d126d  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d1275  jz 0x00007D0BB21D12E0
00007d0bb21d127b  nop [rax+rax*1], ax
00007d0bb21d1284  nop [rax+rax*1], eax
00007d0bb21d128c  mov eax, 0x4103AC
00007d0bb21d1291  mov [r15+0x100], rax
00007d0bb21d1298  jmp 0x00007D0BB1FFE110
00007d0bb21d129d  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d12a5  jz 0x00007D0BB21D13E0
00007d0bb21d12ab  nop [rax+rax*1], ax
00007d0bb21d12b4  nop [rax+rax*1], eax
00007d0bb21d12bc  mov eax, 0x410390
00007d0bb21d12c1  mov [r15+0x100], rax
00007d0bb21d12c8  jmp 0x00007D0BB1FFE110
00007d0bb21d12cd  int3
00007d0bb21d12ce  call 0x00007D0BB20B4B70
00007d0bb21d12d3  jmp 0x00007D0BB21D1241
00007d0bb21d12d8  int3
00007d0bb21d12d9  nop [rax], eax
00007d0bb21d12e0  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d12e8  jz 0x00007D0BB21D1320
00007d0bb21d12ee  nop [rax+rax*1], ax
00007d0bb21d12f7  nop [rax+rax*1], eax
00007d0bb21d12ff  mov eax, 0x410374
00007d0bb21d1304  mov [r15+0x100], rax
00007d0bb21d130b  jmp 0x00007D0BB1FFE110
00007d0bb21d1310  int3
00007d0bb21d1311  int3
00007d0bb21d1312  nop [rax+rax*1], ax
00007d0bb21d131b  nop [rax+rax*1], eax
00007d0bb21d1320  mov qword ptr [r15+0x50], 0x00
00007d0bb21d1328  mov rax, [r15+0x40]
00007d0bb21d132c  lea r14, [rax+0x01]
00007d0bb21d1330  mov [r15+0x40], r14
00007d0bb21d1334  mov rax, [r15+0x98]
00007d0bb21d133b  mov r12d, [r15+0x48]
00007d0bb21d133f  mov [r13+rax*1], r12d
00007d0bb21d1344  xor eax, eax
00007d0bb21d1346  mov r12d, 0x400
00007d0bb21d134c  cmp r14, r12
00007d0bb21d134f  cmc
00007d0bb21d1350  lahf
00007d0bb21d1351  seto al
00007d0bb21d1354  mov [r15+0x108], eax
00007d0bb21d135b  mov eax, [r15+0x108]
00007d0bb21d1362  sahf
00007d0bb21d1363  jz 0x00007D0BB21D1395
00007d0bb21d1365  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d136d  jz 0x00007D0BB21D1120
00007d0bb21d1373  nop [rax+rax*1], ax
00007d0bb21d137c  nop [rax+rax*1], eax
00007d0bb21d1384  mov eax, 0x410388
00007d0bb21d1389  mov [r15+0x100], rax
00007d0bb21d1390  jmp 0x00007D0BB1FFE110
00007d0bb21d1395  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d139d  jz 0x00007D0BB21D1580
00007d0bb21d13a3  nop [rax+rax*1], ax
00007d0bb21d13ac  nop [rax+rax*1], eax
00007d0bb21d13b4  mov eax, 0x4103B0
00007d0bb21d13b9  mov [r15+0x100], rax
00007d0bb21d13c0  jmp 0x00007D0BB1FFE110
00007d0bb21d13c5  int3
00007d0bb21d13c6  call 0x00007D0BB200BAE0
00007d0bb21d13cb  jmp 0x00007D0BB21D1344
00007d0bb21d13d0  int3
00007d0bb21d13d1  nop [rax+rax*1], ax
00007d0bb21d13da  nop [rax+rax*1], ax
00007d0bb21d13e0  mov eax, [r15+0x50]
00007d0bb21d13e4  lea r14d, [eax-0x01]
00007d0bb21d13e9  mov r14d, r14d
00007d0bb21d13ec  mov [r15+0x58], r14
00007d0bb21d13f0  mov rax, [r15+0x58]
00007d0bb21d13f4  mov r14d, eax
00007d0bb21d13f7  mov r14d, r14d
00007d0bb21d13fa  shl r14, 0x02
00007d0bb21d13fe  mov rax, [r15+0x98]
00007d0bb21d1405  lea r12, [rax+r14*1]
00007d0bb21d1409  mov eax, [r13+r12*1]
00007d0bb21d140e  mov [rsp+0x10], eax
00007d0bb21d1412  mov eax, eax
00007d0bb21d1414  mov [r15+0x60], rax
00007d0bb21d1418  mov eax, [r15+0x48]
00007d0bb21d141c  mov [rsp+0x20], eax
00007d0bb21d1420  xor eax, eax
00007d0bb21d1422  mov r14d, [rsp+0x10]
00007d0bb21d1427  mov r12d, [rsp+0x20]
00007d0bb21d142c  cmp r14d, r12d
00007d0bb21d142f  cmc
00007d0bb21d1430  lahf
00007d0bb21d1431  seto al
00007d0bb21d1434  mov [r15+0x108], eax
00007d0bb21d143b  mov eax, [r15+0x108]
00007d0bb21d1442  sahf
00007d0bb21d1443  cmc
00007d0bb21d1444  jbe 0x00007D0BB21D1476
00007d0bb21d1446  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d144e  jz 0x00007D0BB21D1220
00007d0bb21d1454  nop [rax+rax*1], ax
00007d0bb21d145d  nop [rax+rax*1], eax
00007d0bb21d1465  mov eax, 0x4103A0
00007d0bb21d146a  mov [r15+0x100], rax
00007d0bb21d1471  jmp 0x00007D0BB1FFE110
00007d0bb21d1476  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d147e  jz 0x00007D0BB21D14C0
00007d0bb21d1484  nop [rax+rax*1], ax
00007d0bb21d148d  nop [rax+rax*1], eax
00007d0bb21d1495  mov eax, 0x410378
00007d0bb21d149a  mov [r15+0x100], rax
00007d0bb21d14a1  jmp 0x00007D0BB1FFE110
00007d0bb21d14a6  int3
00007d0bb21d14a7  call 0x00007D0BB20B4690
00007d0bb21d14ac  jmp 0x00007D0BB21D140E
00007d0bb21d14b1  int3
00007d0bb21d14b2  nop [rax+rax*1], ax
00007d0bb21d14bb  nop [rax+rax*1], eax
00007d0bb21d14c0  mov rax, [r15+0x40]
00007d0bb21d14c4  lea r14, [rax+0x01]
00007d0bb21d14c8  mov [r15+0x40], r14
00007d0bb21d14cc  mov rax, [r15+0x50]
00007d0bb21d14d0  mov r12d, eax
00007d0bb21d14d3  mov r12d, r12d
00007d0bb21d14d6  shl r12, 0x02
00007d0bb21d14da  mov rax, [r15+0x98]
00007d0bb21d14e1  lea r11, [rax+r12*1]
00007d0bb21d14e5  mov eax, [r15+0x48]
00007d0bb21d14e9  mov [r13+r11*1], eax
00007d0bb21d14ee  xor eax, eax
00007d0bb21d14f0  mov r12d, 0x400
00007d0bb21d14f6  cmp r14, r12
00007d0bb21d14f9  cmc
00007d0bb21d14fa  lahf
00007d0bb21d14fb  seto al
00007d0bb21d14fe  mov [r15+0x108], eax
00007d0bb21d1505  mov eax, [r15+0x108]
00007d0bb21d150c  sahf
00007d0bb21d150d  jz 0x00007D0BB21D153F
00007d0bb21d150f  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d1517  jz 0x00007D0BB21D1120
00007d0bb21d151d  nop [rax+rax*1], ax
00007d0bb21d1526  nop [rax+rax*1], eax
00007d0bb21d152e  mov eax, 0x410388
00007d0bb21d1533  mov [r15+0x100], rax
00007d0bb21d153a  jmp 0x00007D0BB1FFE110
00007d0bb21d153f  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d1547  jz 0x00007D0BB21D1580
00007d0bb21d154d  nop [rax+rax*1], ax
00007d0bb21d1556  nop [rax+rax*1], eax
00007d0bb21d155e  mov eax, 0x4103B0
00007d0bb21d1563  mov [r15+0x100], rax
00007d0bb21d156a  jmp 0x00007D0BB1FFE110
00007d0bb21d156f  int3
00007d0bb21d1570  call 0x00007D0BB20A4270
00007d0bb21d1575  jmp 0x00007D0BB21D14EE
00007d0bb21d157a  int3
00007d0bb21d157b  nop [rax+rax*1], eax
00007d0bb21d1580  mov qword ptr [r15+0x40], 0x430000
00007d0bb21d1588  mov eax, 0x430CB0
00007d0bb21d158d  mov r14, [r13+rax*1]
00007d0bb21d1592  mov rax, [r15+0x98]
00007d0bb21d1599  mov r12d, [r13+rax*1]
00007d0bb21d159e  lea r11, [rax+0x04]
00007d0bb21d15a2  mov eax, [r13+r11*1]
00007d0bb21d15a7  mov r12d, r12d
00007d0bb21d15aa  mov [r15+0x68], r12
00007d0bb21d15ae  mov eax, eax
00007d0bb21d15b0  mov [r15+0x60], rax
00007d0bb21d15b4  mov rax, [r15+0x68]
00007d0bb21d15b8  mov [r15+0x68], rax
00007d0bb21d15bc  mov qword ptr [r15+0x58], 0x02
00007d0bb21d15c4  mov [rsp+0x10], rax
00007d0bb21d15c9  xor eax, eax
00007d0bb21d15cb  mov r12d, 0x02
00007d0bb21d15d1  mov r11d, 0x400
00007d0bb21d15d7  cmp r12, r11
00007d0bb21d15da  cmc
00007d0bb21d15db  lahf
00007d0bb21d15dc  seto al
00007d0bb21d15df  mov [r15+0x108], eax
00007d0bb21d15e6  mov rax, [r15+0x60]
00007d0bb21d15ea  mov r12d, 0x02
00007d0bb21d15f0  imul rax, r12
00007d0bb21d15f4  mov [r15+0x50], rax
00007d0bb21d15f8  mov rax, [rsp+0x10]
00007d0bb21d15fd  lea r12, [rax+r14*1]
00007d0bb21d1601  mov [r15+0x48], r12
00007d0bb21d1605  mov eax, [r15+0x108]
00007d0bb21d160c  sahf
00007d0bb21d160d  jnz 0x00007D0BB21D163F
00007d0bb21d160f  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d1617  jz 0x00007D0BB21D17B0
00007d0bb21d161d  nop [rax+rax*1], ax
00007d0bb21d1626  nop [rax+rax*1], eax
00007d0bb21d162e  mov eax, 0x4103E0
00007d0bb21d1633  mov [r15+0x100], rax
00007d0bb21d163a  jmp 0x00007D0BB1FFE110
00007d0bb21d163f  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d1647  jz 0x00007D0BB21D1690
00007d0bb21d164d  nop [rax+rax*1], ax
00007d0bb21d1656  nop [rax+rax*1], eax
00007d0bb21d165e  mov eax, 0x4103C0
00007d0bb21d1663  mov [r15+0x100], rax
00007d0bb21d166a  jmp 0x00007D0BB1FFE110
00007d0bb21d166f  int3
00007d0bb21d1670  call 0x00007D0BB200DC20
00007d0bb21d1675  jmp 0x00007D0BB21D1592
00007d0bb21d167a  call 0x00007D0BB200B5E0
00007d0bb21d167f  jmp 0x00007D0BB21D159E
00007d0bb21d1684  call 0x00007D0BB20A3D90
00007d0bb21d1689  jmp 0x00007D0BB21D15A7
00007d0bb21d168e  int3
00007d0bb21d168f  nop
00007d0bb21d1690  mov rax, [r15+0x98]
00007d0bb21d1697  mov r14, [r15+0x58]
00007d0bb21d169b  mov [rsp+0x10], r14
00007d0bb21d16a0  shl r14, 0x02
00007d0bb21d16a4  lea r12, [rax+r14*1]
00007d0bb21d16a8  mov eax, [r13+r12*1]
00007d0bb21d16ad  lea r14, [r12+0x04]
00007d0bb21d16b2  mov r12d, [r13+r14*1]
00007d0bb21d16b7  mov eax, eax
00007d0bb21d16b9  mov [r15+0x68], rax
00007d0bb21d16bd  mov r12d, r12d
00007d0bb21d16c0  mov [r15+0x60], r12
00007d0bb21d16c4  mov rax, [r15+0x68]
00007d0bb21d16c8  mov [rsp+0x20], rax
00007d0bb21d16cd  mov r14, [rsp+0x10]
00007d0bb21d16d2  imul rax, r14
00007d0bb21d16d6  mov r12, [rsp+0x20]
00007d0bb21d16db  lea r11, [r12+rax*1]
00007d0bb21d16df  mov [r15+0x68], r11
00007d0bb21d16e3  lea rax, [r14+0x02]
00007d0bb21d16e7  mov [r15+0x58], rax
00007d0bb21d16eb  mov [rsp+0x10], rax
00007d0bb21d16f0  xor eax, eax
00007d0bb21d16f2  mov r14, [rsp+0x10]
00007d0bb21d16f7  mov r12d, 0x400
00007d0bb21d16fd  cmp r14, r12
00007d0bb21d1700  cmc
00007d0bb21d1701  lahf
00007d0bb21d1702  seto al
00007d0bb21d1705  mov [r15+0x108], eax
00007d0bb21d170c  mov rax, [r15+0x50]
00007d0bb21d1710  mov r12, [r15+0x60]
00007d0bb21d1714  imul r14, r12
00007d0bb21d1718  lea r12, [rax+r14*1]
00007d0bb21d171c  mov [r15+0x50], r12
00007d0bb21d1720  mov rax, [r15+0x48]
00007d0bb21d1724  lea r14, [r11+rax*1]
00007d0bb21d1728  mov [r15+0x48], r14
00007d0bb21d172c  mov eax, [r15+0x108]
00007d0bb21d1733  sahf
00007d0bb21d1734  jnz 0x00007D0BB21D1766
00007d0bb21d1736  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d173e  jz 0x00007D0BB21D17B0
00007d0bb21d1744  nop [rax+rax*1], ax
00007d0bb21d174d  nop [rax+rax*1], eax
00007d0bb21d1755  mov eax, 0x4103E0
00007d0bb21d175a  mov [r15+0x100], rax
00007d0bb21d1761  jmp 0x00007D0BB1FFE110
00007d0bb21d1766  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d176e  jz 0x00007D0BB21D1690
00007d0bb21d1774  nop [rax+rax*1], ax
00007d0bb21d177d  nop [rax+rax*1], eax
00007d0bb21d1785  mov eax, 0x4103C0
00007d0bb21d178a  mov [r15+0x100], rax
00007d0bb21d1791  jmp 0x00007D0BB1FFE110
00007d0bb21d1796  int3
00007d0bb21d1797  call 0x00007D0BB20B4690
00007d0bb21d179c  jmp 0x00007D0BB21D16AD
00007d0bb21d17a1  call 0x00007D0BB20E26A0
00007d0bb21d17a6  jmp 0x00007D0BB21D16B7
00007d0bb21d17ab  int3
00007d0bb21d17ac  nop [rax], eax
00007d0bb21d17b0  mov qword ptr [r15+0x98], 0x00
00007d0bb21d17bb  mov rax, [r15+0x50]
00007d0bb21d17bf  mov r14, [r15+0x48]
00007d0bb21d17c3  lea r12, [rax+r14*1]
00007d0bb21d17c7  mov [r15+0x48], r12
00007d0bb21d17cb  mov rax, [r15+0x40]
00007d0bb21d17cf  lea r14, [rax+0xCB0]
00007d0bb21d17d6  mov [r13+r14*1], r12
00007d0bb21d17db  mov qword ptr [r15], 0x01
00007d0bb21d17e2  mov qword ptr [r15+0xF0], 0x4103F8
00007d0bb21d17ed  mov r14d, [r15+0x320]
00007d0bb21d17f4  mov eax, 0x4103F8
00007d0bb21d17f9  mov rcx, 0x7D0BB21D1860
00007d0bb21d1803  mov [r15+r14*8+0x328], rax
00007d0bb21d180b  mov [r15+r14*8+0x368], rcx
00007d0bb21d1813  add r14d, 0x01
00007d0bb21d1817  and r14d, 0x07
00007d0bb21d181b  mov [r15+0x320], r14d
00007d0bb21d1822  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d182a  jz 0x00007D0BB21D0F20
00007d0bb21d1830  nop [rax+rax*1], ax
00007d0bb21d1839  nop [rax+rax*1], eax
00007d0bb21d1841  mov eax, 0x4109A4
00007d0bb21d1846  mov [r15+0x100], rax
00007d0bb21d184d  jmp 0x00007D0BB1FFE110
00007d0bb21d1852  int3
00007d0bb21d1853  call 0x00007D0BB20E2CE0
00007d0bb21d1858  jmp 0x00007D0BB21D17DB
00007d0bb21d185d  int3
00007d0bb21d185e  nop
00007d0bb21d1860  mov eax, [r15+0x98]
00007d0bb21d1867  lea r14d, [eax+0x01]
00007d0bb21d186c  mov [rsp+0x10], r14d
00007d0bb21d1871  mov r14d, r14d
00007d0bb21d1874  mov [r15+0x98], r14
00007d0bb21d187b  xor eax, eax
00007d0bb21d187d  mov r14d, [rsp+0x10]
00007d0bb21d1882  cmp r14d, 0x10000
00007d0bb21d1889  cmc
00007d0bb21d188a  lahf
00007d0bb21d188b  seto al
00007d0bb21d188e  mov [r15+0x108], eax
00007d0bb21d1895  mov eax, [r15+0x108]
00007d0bb21d189c  sahf
00007d0bb21d189d  jnz 0x00007D0BB21D18CF
00007d0bb21d189f  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d18a7  jz 0x00007D0BB21D19A0
00007d0bb21d18ad  nop [rax+rax*1], ax
00007d0bb21d18b6  nop [rax+rax*1], eax
00007d0bb21d18be  mov eax, 0x410404
00007d0bb21d18c3  mov [r15+0x100], rax
00007d0bb21d18ca  jmp 0x00007D0BB1FFE110
00007d0bb21d18cf  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d18d7  jz 0x00007D0BB21D1910
00007d0bb21d18dd  nop [rax+rax*1], ax
00007d0bb21d18e6  nop [rax+rax*1], eax
00007d0bb21d18ee  mov eax, 0x4103F0
00007d0bb21d18f3  mov [r15+0x100], rax
00007d0bb21d18fa  jmp 0x00007D0BB1FFE110
00007d0bb21d18ff  int3
00007d0bb21d1900  int3
00007d0bb21d1901  nop [rax+rax*1], ax
00007d0bb21d190a  nop [rax+rax*1], ax
00007d0bb21d1910  mov eax, [r15]
00007d0bb21d1913  mov r14d, [r15+0x98]
00007d0bb21d191a  lea r12d, [eax+r14d*1]
00007d0bb21d191f  mov r12d, r12d
00007d0bb21d1922  mov [r15], r12
00007d0bb21d1925  mov qword ptr [r15+0xF0], 0x4103F8
00007d0bb21d1930  mov r14d, [r15+0x320]
00007d0bb21d1937  mov eax, 0x4103F8
00007d0bb21d193c  mov rcx, 0x7D0BB21D1860
00007d0bb21d1946  mov [r15+r14*8+0x328], rax
00007d0bb21d194e  mov [r15+r14*8+0x368], rcx
00007d0bb21d1956  add r14d, 0x01
00007d0bb21d195a  and r14d, 0x07
00007d0bb21d195e  mov [r15+0x320], r14d
00007d0bb21d1965  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d196d  jz 0x00007D0BB21D0F20
00007d0bb21d1973  nop [rax+rax*1], ax
00007d0bb21d197c  nop [rax+rax*1], eax
00007d0bb21d1984  mov eax, 0x4109A4
00007d0bb21d1989  mov [r15+0x100], rax
00007d0bb21d1990  jmp 0x00007D0BB1FFE110
00007d0bb21d1995  int3
00007d0bb21d1996  int3
00007d0bb21d1997  nop [rax+rax*1], ax
00007d0bb21d19a0  vmovaps xmm1, [0x00007D0BB1DFE010]
00007d0bb21d19a8  movq xmm1, xmm1
00007d0bb21d19ac  movaps [r15+0x110], xmm1
00007d0bb21d19b4  mov eax, 0x420B10
00007d0bb21d19b9  mov r14, [r13+rax*1]
00007d0bb21d19be  movq xmm1, r14
00007d0bb21d19c3  movaps [r15+0x120], xmm1
00007d0bb21d19cb  vmovaps xmm1, [0x00007D0BB1DFE020]
00007d0bb21d19d3  movq xmm1, xmm1
00007d0bb21d19d7  movaps [r15+0x140], xmm1
00007d0bb21d19df  vmovaps xmm1, [0x00007D0BB1DFE030]
00007d0bb21d19e7  vpbroadcastq xmm1, xmm1
00007d0bb21d19ec  movaps [r15+0x150], xmm1
00007d0bb21d19f4  mov qword ptr [r15+0x40], 0x02
00007d0bb21d19fc  vmovaps xmm15, [0x00007D0BB1DFE040]
00007d0bb21d1a04  movq xmm15, xmm15
00007d0bb21d1a09  movaps [r15+0x160], xmm15
00007d0bb21d1a11  vmovaps xmm15, [0x00007D0BB1DFE050]
00007d0bb21d1a19  vpbroadcastq xmm15, xmm15
00007d0bb21d1a1e  movaps [r15+0x130], xmm15
00007d0bb21d1a26  mov rax, [r15+0x40]
00007d0bb21d1a2a  vmovq xmm14, rax
00007d0bb21d1a2f  vpbroadcastq xmm14, xmm14
00007d0bb21d1a34  movaps [r15+0x170], xmm14
00007d0bb21d1a3c  mov eax, 0x420A40
00007d0bb21d1a41  movups xmm13, [r13+rax*1]
00007d0bb21d1a47  mov qword ptr [r15+0x40], 0x431E00
00007d0bb21d1a4f  mov eax, [r15]
00007d0bb21d1a52  mov r14d, 0x430CB8
00007d0bb21d1a58  mov [r13+r14*1], eax
00007d0bb21d1a5d  mov qword ptr [r15+0x50], 0x432000
00007d0bb21d1a65  vpmovqd xmm12, xmm13
00007d0bb21d1a6b  pxor xmm11, xmm11
00007d0bb21d1a70  punpcklqdq xmm12, xmm11
00007d0bb21d1a75  movaps [r15+0x210], xmm12
00007d0bb21d1a7d  movq xmm12, qword ptr [r15+0x140]
00007d0bb21d1a86  movq xmm11, qword ptr [r15+0x120]
00007d0bb21d1a8f  psubd xmm12, xmm11
00007d0bb21d1a94  movq xmm12, xmm12
00007d0bb21d1a99  paddq xmm13, xmm14
00007d0bb21d1a9e  movaps [r15+0x180], xmm13
00007d0bb21d1aa6  movq xmm14, qword ptr [r15+0x160]
00007d0bb21d1aaf  paddd xmm11, xmm14
00007d0bb21d1ab4  movq xmm11, xmm11
00007d0bb21d1ab9  movq xmm11, xmm11
00007d0bb21d1abe  movaps [r15+0x120], xmm11
00007d0bb21d1ac6  pmovzxdq xmm12, xmm12
00007d0bb21d1acc  psllq xmm12, 0x00
00007d0bb21d1ad2  movq xmm14, qword ptr [r15+0x210]
00007d0bb21d1adb  movq xmm13, qword ptr [r15+0x110]
00007d0bb21d1ae4  paddd xmm14, xmm13
00007d0bb21d1ae9  movq xmm14, xmm14
00007d0bb21d1aee  vcvtuqq2pd xmm12, xmm12
00007d0bb21d1af4  pmovzxdq xmm14, xmm14
00007d0bb21d1afa  psllq xmm14, 0x00
00007d0bb21d1b00  vcvtuqq2pd xmm14, xmm14
00007d0bb21d1b06  movaps xmm13, xmm12
00007d0bb21d1b0a  mulpd xmm13, xmm1
00007d0bb21d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007d0bb21d1b15  ptest xmm11, xmm11
00007d0bb21d1b1b  jnz 0x00007D0BB21D1C0F
00007d0bb21d1b21  movaps [r15+0x220], xmm13
00007d0bb21d1b29  mov eax, 0x432000
00007d0bb21d1b2e  movups [r13+rax*1], xmm13
00007d0bb21d1b34  movaps xmm1, xmm14
00007d0bb21d1b38  mulpd xmm1, xmm15
00007d0bb21d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007d0bb21d1b42  ptest xmm13, xmm13
00007d0bb21d1b48  jnz 0x00007D0BB21D1D5C
00007d0bb21d1b4e  movaps [r15+0x210], xmm1
00007d0bb21d1b56  mov eax, 0x431E00
00007d0bb21d1b5b  movups [r13+rax*1], xmm1
00007d0bb21d1b61  mov qword ptr [r15+0x48], 0x10
00007d0bb21d1b69  xor eax, eax
00007d0bb21d1b6b  mov r14d, 0x10
00007d0bb21d1b71  mov r12d, 0x200
00007d0bb21d1b77  cmp r14, r12
00007d0bb21d1b7a  cmc
00007d0bb21d1b7b  lahf
00007d0bb21d1b7c  seto al
00007d0bb21d1b7f  mov [r15+0x108], eax
00007d0bb21d1b86  mov eax, [r15+0x108]
00007d0bb21d1b8d  sahf
00007d0bb21d1b8e  jnz 0x00007D0BB21D1BC0
00007d0bb21d1b90  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d1b98  jz 0x00007D0BB21D2300
00007d0bb21d1b9e  nop [rax+rax*1], ax
00007d0bb21d1ba7  nop [rax+rax*1], eax
00007d0bb21d1baf  mov eax, 0x410490
00007d0bb21d1bb4  mov [r15+0x100], rax
00007d0bb21d1bbb  jmp 0x00007D0BB1FFE110
00007d0bb21d1bc0  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d1bc8  jz 0x00007D0BB21D1EB0
00007d0bb21d1bce  nop [rax+rax*1], ax
00007d0bb21d1bd7  nop [rax+rax*1], eax
00007d0bb21d1bdf  mov eax, 0x410450
00007d0bb21d1be4  mov [r15+0x100], rax
00007d0bb21d1beb  jmp 0x00007D0BB1FFE110
00007d0bb21d1bf0  int3
00007d0bb21d1bf1  call 0x00007D0BB200DC20
00007d0bb21d1bf6  jmp 0x00007D0BB21D19BE
00007d0bb21d1bfb  call 0x00007D0BB200C260
00007d0bb21d1c00  jmp 0x00007D0BB21D1A47
00007d0bb21d1c05  call 0x00007D0BB20D5D70
00007d0bb21d1c0a  jmp 0x00007D0BB21D1A5D
00007d0bb21d1c0f  sub rsp, 0x08
00007d0bb21d1c13  push rax
00007d0bb21d1c14  push rcx
00007d0bb21d1c15  push rdx
00007d0bb21d1c16  push rdi
00007d0bb21d1c17  push rsi
00007d0bb21d1c18  push r8
00007d0bb21d1c1a  push r9
00007d0bb21d1c1c  push r10
00007d0bb21d1c1e  push r11
00007d0bb21d1c20  sub rsp, 0xF0
00007d0bb21d1c27  vmovaps [rsp], xmm0
00007d0bb21d1c2c  vmovaps [rsp+0x10], xmm1
00007d0bb21d1c32  vmovaps [rsp+0x20], xmm2
00007d0bb21d1c38  vmovaps [rsp+0x30], xmm3
00007d0bb21d1c3e  vmovaps [rsp+0x40], xmm4
00007d0bb21d1c44  vmovaps [rsp+0x50], xmm5
00007d0bb21d1c4a  vmovaps [rsp+0x60], xmm6
00007d0bb21d1c50  vmovaps [rsp+0x70], xmm7
00007d0bb21d1c56  vmovaps [rsp+0x80], xmm8
00007d0bb21d1c5f  vmovaps [rsp+0x90], xmm9
00007d0bb21d1c68  vmovaps [rsp+0xA0], xmm10
00007d0bb21d1c71  vmovaps [rsp+0xB0], xmm11
00007d0bb21d1c7a  vmovaps [rsp+0xC0], xmm12
00007d0bb21d1c83  vmovaps [rsp+0xD0], xmm14
00007d0bb21d1c8c  vmovaps [rsp+0xE0], xmm15
00007d0bb21d1c95  sub rsp, 0x30
00007d0bb21d1c99  movaps [rsp], xmm13
00007d0bb21d1c9e  movaps [rsp+0x10], xmm12
00007d0bb21d1ca4  movaps [rsp+0x20], xmm1
00007d0bb21d1ca9  lea rdi, [rsp]
00007d0bb21d1cad  mov esi, 0x00
00007d0bb21d1cb2  mov rax, 0x6392BBE7F530
00007d0bb21d1cbc  call rax
00007d0bb21d1cbe  movaps xmm13, [rsp]
00007d0bb21d1cc3  add rsp, 0x30
00007d0bb21d1cc7  vmovaps xmm0, [rsp]
00007d0bb21d1ccc  vmovaps xmm1, [rsp+0x10]
00007d0bb21d1cd2  vmovaps xmm2, [rsp+0x20]
00007d0bb21d1cd8  vmovaps xmm3, [rsp+0x30]
00007d0bb21d1cde  vmovaps xmm4, [rsp+0x40]
00007d0bb21d1ce4  vmovaps xmm5, [rsp+0x50]
00007d0bb21d1cea  vmovaps xmm6, [rsp+0x60]
00007d0bb21d1cf0  vmovaps xmm7, [rsp+0x70]
00007d0bb21d1cf6  vmovaps xmm8, [rsp+0x80]
00007d0bb21d1cff  vmovaps xmm9, [rsp+0x90]
00007d0bb21d1d08  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d1d11  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d1d1a  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d1d23  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d1d2c  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d1d35  add rsp, 0xF0
00007d0bb21d1d3c  pop r11
00007d0bb21d1d3e  pop r10
00007d0bb21d1d40  pop r9
00007d0bb21d1d42  pop r8
00007d0bb21d1d44  pop rsi
00007d0bb21d1d45  pop rdi
00007d0bb21d1d46  pop rdx
00007d0bb21d1d47  pop rcx
00007d0bb21d1d48  pop rax
00007d0bb21d1d49  add rsp, 0x08
00007d0bb21d1d4d  jmp 0x00007D0BB21D1B21
00007d0bb21d1d52  call 0x00007D0BB200C380
00007d0bb21d1d57  jmp 0x00007D0BB21D1B34
00007d0bb21d1d5c  sub rsp, 0x08
00007d0bb21d1d60  push rax
00007d0bb21d1d61  push rcx
00007d0bb21d1d62  push rdx
00007d0bb21d1d63  push rdi
00007d0bb21d1d64  push rsi
00007d0bb21d1d65  push r8
00007d0bb21d1d67  push r9
00007d0bb21d1d69  push r10
00007d0bb21d1d6b  push r11
00007d0bb21d1d6d  sub rsp, 0xF0
00007d0bb21d1d74  vmovaps [rsp], xmm0
00007d0bb21d1d79  vmovaps [rsp+0x10], xmm2
00007d0bb21d1d7f  vmovaps [rsp+0x20], xmm3
00007d0bb21d1d85  vmovaps [rsp+0x30], xmm4
00007d0bb21d1d8b  vmovaps [rsp+0x40], xmm5
00007d0bb21d1d91  vmovaps [rsp+0x50], xmm6
00007d0bb21d1d97  vmovaps [rsp+0x60], xmm7
00007d0bb21d1d9d  vmovaps [rsp+0x70], xmm8
00007d0bb21d1da3  vmovaps [rsp+0x80], xmm9
00007d0bb21d1dac  vmovaps [rsp+0x90], xmm10
00007d0bb21d1db5  vmovaps [rsp+0xA0], xmm11
00007d0bb21d1dbe  vmovaps [rsp+0xB0], xmm12
00007d0bb21d1dc7  vmovaps [rsp+0xC0], xmm13
00007d0bb21d1dd0  vmovaps [rsp+0xD0], xmm14
00007d0bb21d1dd9  vmovaps [rsp+0xE0], xmm15
00007d0bb21d1de2  sub rsp, 0x30
00007d0bb21d1de6  movaps [rsp], xmm1
00007d0bb21d1dea  movaps [rsp+0x10], xmm14
00007d0bb21d1df0  movaps [rsp+0x20], xmm15
00007d0bb21d1df6  lea rdi, [rsp]
00007d0bb21d1dfa  mov esi, 0x00
00007d0bb21d1dff  mov rax, 0x6392BBE7F530
00007d0bb21d1e09  call rax
00007d0bb21d1e0b  movaps xmm1, [rsp]
00007d0bb21d1e0f  add rsp, 0x30
00007d0bb21d1e13  vmovaps xmm0, [rsp]
00007d0bb21d1e18  vmovaps xmm2, [rsp+0x10]
00007d0bb21d1e1e  vmovaps xmm3, [rsp+0x20]
00007d0bb21d1e24  vmovaps xmm4, [rsp+0x30]
00007d0bb21d1e2a  vmovaps xmm5, [rsp+0x40]
00007d0bb21d1e30  vmovaps xmm6, [rsp+0x50]
00007d0bb21d1e36  vmovaps xmm7, [rsp+0x60]
00007d0bb21d1e3c  vmovaps xmm8, [rsp+0x70]
00007d0bb21d1e42  vmovaps xmm9, [rsp+0x80]
00007d0bb21d1e4b  vmovaps xmm10, [rsp+0x90]
00007d0bb21d1e54  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d1e5d  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d1e66  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d1e6f  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d1e78  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d1e81  add rsp, 0xF0
00007d0bb21d1e88  pop r11
00007d0bb21d1e8a  pop r10
00007d0bb21d1e8c  pop r9
00007d0bb21d1e8e  pop r8
00007d0bb21d1e90  pop rsi
00007d0bb21d1e91  pop rdi
00007d0bb21d1e92  pop rdx
00007d0bb21d1e93  pop rcx
00007d0bb21d1e94  pop rax
00007d0bb21d1e95  add rsp, 0x08
00007d0bb21d1e99  jmp 0x00007D0BB21D1B4E
00007d0bb21d1e9e  call 0x00007D0BB1FFF540
00007d0bb21d1ea3  jmp 0x00007D0BB21D1B61
00007d0bb21d1ea8  int3
00007d0bb21d1ea9  nop [rax], eax
00007d0bb21d1eb0  movaps xmm1, [r15+0x180]
00007d0bb21d1eb8  vpmovqd xmm15, xmm1
00007d0bb21d1ebe  pxor xmm14, xmm14
00007d0bb21d1ec3  punpcklqdq xmm15, xmm14
00007d0bb21d1ec8  movaps [r15+0x210], xmm15
00007d0bb21d1ed0  movq xmm15, qword ptr [r15+0x140]
00007d0bb21d1ed9  movq xmm14, qword ptr [r15+0x120]
00007d0bb21d1ee2  psubd xmm15, xmm14
00007d0bb21d1ee7  movq xmm15, xmm15
00007d0bb21d1eec  movaps xmm13, [r15+0x170]
00007d0bb21d1ef4  paddq xmm1, xmm13
00007d0bb21d1ef9  movaps [r15+0x180], xmm1
00007d0bb21d1f01  movq xmm1, qword ptr [r15+0x160]
00007d0bb21d1f0a  paddd xmm14, xmm1
00007d0bb21d1f0f  movq xmm14, xmm14
00007d0bb21d1f14  movq xmm14, xmm14
00007d0bb21d1f19  movaps [r15+0x120], xmm14
00007d0bb21d1f21  pmovzxdq xmm15, xmm15
00007d0bb21d1f27  psllq xmm15, 0x00
00007d0bb21d1f2d  movq xmm1, qword ptr [r15+0x210]
00007d0bb21d1f36  movq xmm14, qword ptr [r15+0x110]
00007d0bb21d1f3f  paddd xmm1, xmm14
00007d0bb21d1f44  movq xmm1, xmm1
00007d0bb21d1f48  vcvtuqq2pd xmm15, xmm15
00007d0bb21d1f4e  pmovzxdq xmm1, xmm1
00007d0bb21d1f53  psllq xmm1, 0x00
00007d0bb21d1f58  vcvtuqq2pd xmm1, xmm1
00007d0bb21d1f5e  movaps xmm14, [r15+0x150]
00007d0bb21d1f66  movaps xmm13, xmm15
00007d0bb21d1f6a  mulpd xmm13, xmm14
00007d0bb21d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007d0bb21d1f75  ptest xmm12, xmm12
00007d0bb21d1f7b  jnz 0x00007D0BB21D205E
00007d0bb21d1f81  movaps [r15+0x220], xmm13
00007d0bb21d1f89  mov rax, [r15+0x48]
00007d0bb21d1f8d  mov r14, [r15+0x50]
00007d0bb21d1f91  lea r12, [r14+rax*1]
00007d0bb21d1f95  movups [r13+r12*1], xmm13
00007d0bb21d1f9b  movaps xmm15, [r15+0x130]
00007d0bb21d1fa3  movaps xmm14, xmm1
00007d0bb21d1fa7  mulpd xmm14, xmm15
00007d0bb21d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007d0bb21d1fb2  ptest xmm13, xmm13
00007d0bb21d1fb8  jnz 0x00007D0BB21D21AC
00007d0bb21d1fbe  movaps [r15+0x210], xmm14
00007d0bb21d1fc6  mov r14, [r15+0x40]
00007d0bb21d1fca  lea r12, [r14+rax*1]
00007d0bb21d1fce  movups [r13+r12*1], xmm14
00007d0bb21d1fd4  lea r14, [rax+0x10]
00007d0bb21d1fd8  mov [r15+0x48], r14
00007d0bb21d1fdc  xor eax, eax
00007d0bb21d1fde  mov r12d, 0x200
00007d0bb21d1fe4  cmp r14, r12
00007d0bb21d1fe7  cmc
00007d0bb21d1fe8  lahf
00007d0bb21d1fe9  seto al
00007d0bb21d1fec  mov [r15+0x108], eax
00007d0bb21d1ff3  mov eax, [r15+0x108]
00007d0bb21d1ffa  sahf
00007d0bb21d1ffb  jnz 0x00007D0BB21D202D
00007d0bb21d1ffd  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d2005  jz 0x00007D0BB21D2300
00007d0bb21d200b  nop [rax+rax*1], ax
00007d0bb21d2014  nop [rax+rax*1], eax
00007d0bb21d201c  mov eax, 0x410490
00007d0bb21d2021  mov [r15+0x100], rax
00007d0bb21d2028  jmp 0x00007D0BB1FFE110
00007d0bb21d202d  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d2035  jz 0x00007D0BB21D1EB0
00007d0bb21d203b  nop [rax+rax*1], ax
00007d0bb21d2044  nop [rax+rax*1], eax
00007d0bb21d204c  mov eax, 0x410450
00007d0bb21d2051  mov [r15+0x100], rax
00007d0bb21d2058  jmp 0x00007D0BB1FFE110
00007d0bb21d205d  int3
00007d0bb21d205e  sub rsp, 0x08
00007d0bb21d2062  push rax
00007d0bb21d2063  push rcx
00007d0bb21d2064  push rdx
00007d0bb21d2065  push rdi
00007d0bb21d2066  push rsi
00007d0bb21d2067  push r8
00007d0bb21d2069  push r9
00007d0bb21d206b  push r10
00007d0bb21d206d  push r11
00007d0bb21d206f  sub rsp, 0xF0
00007d0bb21d2076  vmovaps [rsp], xmm0
00007d0bb21d207b  vmovaps [rsp+0x10], xmm1
00007d0bb21d2081  vmovaps [rsp+0x20], xmm2
00007d0bb21d2087  vmovaps [rsp+0x30], xmm3
00007d0bb21d208d  vmovaps [rsp+0x40], xmm4
00007d0bb21d2093  vmovaps [rsp+0x50], xmm5
00007d0bb21d2099  vmovaps [rsp+0x60], xmm6
00007d0bb21d209f  vmovaps [rsp+0x70], xmm7
00007d0bb21d20a5  vmovaps [rsp+0x80], xmm8
00007d0bb21d20ae  vmovaps [rsp+0x90], xmm9
00007d0bb21d20b7  vmovaps [rsp+0xA0], xmm10
00007d0bb21d20c0  vmovaps [rsp+0xB0], xmm11
00007d0bb21d20c9  vmovaps [rsp+0xC0], xmm12
00007d0bb21d20d2  vmovaps [rsp+0xD0], xmm14
00007d0bb21d20db  vmovaps [rsp+0xE0], xmm15
00007d0bb21d20e4  sub rsp, 0x30
00007d0bb21d20e8  movaps [rsp], xmm13
00007d0bb21d20ed  movaps [rsp+0x10], xmm15
00007d0bb21d20f3  movaps [rsp+0x20], xmm14
00007d0bb21d20f9  lea rdi, [rsp]
00007d0bb21d20fd  mov esi, 0x00
00007d0bb21d2102  mov rax, 0x6392BBE7F530
00007d0bb21d210c  call rax
00007d0bb21d210e  movaps xmm13, [rsp]
00007d0bb21d2113  add rsp, 0x30
00007d0bb21d2117  vmovaps xmm0, [rsp]
00007d0bb21d211c  vmovaps xmm1, [rsp+0x10]
00007d0bb21d2122  vmovaps xmm2, [rsp+0x20]
00007d0bb21d2128  vmovaps xmm3, [rsp+0x30]
00007d0bb21d212e  vmovaps xmm4, [rsp+0x40]
00007d0bb21d2134  vmovaps xmm5, [rsp+0x50]
00007d0bb21d213a  vmovaps xmm6, [rsp+0x60]
00007d0bb21d2140  vmovaps xmm7, [rsp+0x70]
00007d0bb21d2146  vmovaps xmm8, [rsp+0x80]
00007d0bb21d214f  vmovaps xmm9, [rsp+0x90]
00007d0bb21d2158  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d2161  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d216a  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d2173  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d217c  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d2185  add rsp, 0xF0
00007d0bb21d218c  pop r11
00007d0bb21d218e  pop r10
00007d0bb21d2190  pop r9
00007d0bb21d2192  pop r8
00007d0bb21d2194  pop rsi
00007d0bb21d2195  pop rdi
00007d0bb21d2196  pop rdx
00007d0bb21d2197  pop rcx
00007d0bb21d2198  pop rax
00007d0bb21d2199  add rsp, 0x08
00007d0bb21d219d  jmp 0x00007D0BB21D1F81
00007d0bb21d21a2  call 0x00007D0BB20C2240
00007d0bb21d21a7  jmp 0x00007D0BB21D1F9B
00007d0bb21d21ac  sub rsp, 0x08
00007d0bb21d21b0  push rax
00007d0bb21d21b1  push rcx
00007d0bb21d21b2  push rdx
00007d0bb21d21b3  push rdi
00007d0bb21d21b4  push rsi
00007d0bb21d21b5  push r8
00007d0bb21d21b7  push r9
00007d0bb21d21b9  push r10
00007d0bb21d21bb  push r11
00007d0bb21d21bd  sub rsp, 0xF0
00007d0bb21d21c4  vmovaps [rsp], xmm0
00007d0bb21d21c9  vmovaps [rsp+0x10], xmm1
00007d0bb21d21cf  vmovaps [rsp+0x20], xmm2
00007d0bb21d21d5  vmovaps [rsp+0x30], xmm3
00007d0bb21d21db  vmovaps [rsp+0x40], xmm4
00007d0bb21d21e1  vmovaps [rsp+0x50], xmm5
00007d0bb21d21e7  vmovaps [rsp+0x60], xmm6
00007d0bb21d21ed  vmovaps [rsp+0x70], xmm7
00007d0bb21d21f3  vmovaps [rsp+0x80], xmm8
00007d0bb21d21fc  vmovaps [rsp+0x90], xmm9
00007d0bb21d2205  vmovaps [rsp+0xA0], xmm10
00007d0bb21d220e  vmovaps [rsp+0xB0], xmm11
00007d0bb21d2217  vmovaps [rsp+0xC0], xmm12
00007d0bb21d2220  vmovaps [rsp+0xD0], xmm13
00007d0bb21d2229  vmovaps [rsp+0xE0], xmm15
00007d0bb21d2232  sub rsp, 0x30
00007d0bb21d2236  movaps [rsp], xmm14
00007d0bb21d223b  movaps [rsp+0x10], xmm1
00007d0bb21d2240  movaps [rsp+0x20], xmm15
00007d0bb21d2246  lea rdi, [rsp]
00007d0bb21d224a  mov esi, 0x00
00007d0bb21d224f  mov rax, 0x6392BBE7F530
00007d0bb21d2259  call rax
00007d0bb21d225b  movaps xmm14, [rsp]
00007d0bb21d2260  add rsp, 0x30
00007d0bb21d2264  vmovaps xmm0, [rsp]
00007d0bb21d2269  vmovaps xmm1, [rsp+0x10]
00007d0bb21d226f  vmovaps xmm2, [rsp+0x20]
00007d0bb21d2275  vmovaps xmm3, [rsp+0x30]
00007d0bb21d227b  vmovaps xmm4, [rsp+0x40]
00007d0bb21d2281  vmovaps xmm5, [rsp+0x50]
00007d0bb21d2287  vmovaps xmm6, [rsp+0x60]
00007d0bb21d228d  vmovaps xmm7, [rsp+0x70]
00007d0bb21d2293  vmovaps xmm8, [rsp+0x80]
00007d0bb21d229c  vmovaps xmm9, [rsp+0x90]
00007d0bb21d22a5  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d22ae  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d22b7  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d22c0  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d22c9  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d22d2  add rsp, 0xF0
00007d0bb21d22d9  pop r11
00007d0bb21d22db  pop r10
00007d0bb21d22dd  pop r9
00007d0bb21d22df  pop r8
00007d0bb21d22e1  pop rsi
00007d0bb21d22e2  pop rdi
00007d0bb21d22e3  pop rdx
00007d0bb21d22e4  pop rcx
00007d0bb21d22e5  pop rax
00007d0bb21d22e6  add rsp, 0x08
00007d0bb21d22ea  jmp 0x00007D0BB21D1FBE
00007d0bb21d22ef  call 0x00007D0BB20C34C0
00007d0bb21d22f4  jmp 0x00007D0BB21D1FD4
00007d0bb21d22f9  int3
00007d0bb21d22fa  nop [rax+rax*1], ax
00007d0bb21d2300  mov rax, [r15+0x50]
00007d0bb21d2304  lea r14, [rax+0x80]
00007d0bb21d230b  movups xmm1, [r13+r14*1]
00007d0bb21d2311  lea r14, [rax+0x90]
00007d0bb21d2318  movups xmm15, [r13+r14*1]
00007d0bb21d231e  vxorps xmm14, xmm14, xmm14
00007d0bb21d2323  vpbroadcastq xmm14, xmm14
00007d0bb21d2328  lea r14, [rax+0x40]
00007d0bb21d232c  movups xmm13, [r13+r14*1]
00007d0bb21d2332  lea r14, [rax+0x50]
00007d0bb21d2336  movups xmm12, [r13+r14*1]
00007d0bb21d233c  mov qword ptr [r15+0x48], 0x00
00007d0bb21d2344  movups xmm11, [r13+rax*1]
00007d0bb21d234a  lea r14, [rax+0x10]
00007d0bb21d234e  movups xmm10, [r13+r14*1]
00007d0bb21d2354  mov r14, [r15+0xF8]
00007d0bb21d235b  lea r12, [r14+0xE0]
00007d0bb21d2362  movups [r13+r12*1], xmm15
00007d0bb21d2368  lea r12, [r14+0xF0]
00007d0bb21d236f  movups [r13+r12*1], xmm1
00007d0bb21d2375  lea r12, [rax+0xC0]
00007d0bb21d237c  movups xmm1, [r13+r12*1]
00007d0bb21d2382  lea r12, [rax+0xD0]
00007d0bb21d2389  movups xmm15, [r13+r12*1]
00007d0bb21d238f  lea r12, [rax+0x140]
00007d0bb21d2396  movups xmm9, [r13+r12*1]
00007d0bb21d239c  lea r12, [rax+0x150]
00007d0bb21d23a3  movups xmm8, [r13+r12*1]
00007d0bb21d23a9  lea r12, [rax+0x180]
00007d0bb21d23b0  movups xmm7, [r13+r12*1]
00007d0bb21d23b6  lea r12, [rax+0x190]
00007d0bb21d23bd  movups xmm6, [r13+r12*1]
00007d0bb21d23c3  lea r12, [r14+0xC0]
00007d0bb21d23ca  movups [r13+r12*1], xmm15
00007d0bb21d23d0  lea r12, [r14+0xD0]
00007d0bb21d23d7  movups [r13+r12*1], xmm1
00007d0bb21d23dd  lea r12, [rax+0x100]
00007d0bb21d23e4  movups xmm1, [r13+r12*1]
00007d0bb21d23ea  lea r12, [rax+0x110]
00007d0bb21d23f1  movups xmm15, [r13+r12*1]
00007d0bb21d23f7  lea r12, [rax+0x1C0]
00007d0bb21d23fe  movups xmm5, [r13+r12*1]
00007d0bb21d2404  lea r12, [rax+0x1D0]
00007d0bb21d240b  movups xmm4, [r13+r12*1]
00007d0bb21d2411  lea r12, [rax+0x20]
00007d0bb21d2415  movups xmm3, [r13+r12*1]
00007d0bb21d241b  lea r12, [rax+0x30]
00007d0bb21d241f  movups xmm2, [r13+r12*1]
00007d0bb21d2425  movaps [r15+0x1F0], xmm2
00007d0bb21d242d  lea r12, [r14+0x20]
00007d0bb21d2431  movups [r13+r12*1], xmm1
00007d0bb21d2437  lea r12, [r14+0x30]
00007d0bb21d243b  movups [r13+r12*1], xmm12
00007d0bb21d2441  lea r12, [rax+0x60]
00007d0bb21d2445  movups xmm1, [r13+r12*1]
00007d0bb21d244b  lea r12, [rax+0x70]
00007d0bb21d244f  movups xmm12, [r13+r12*1]
00007d0bb21d2455  lea r12, [r14+0x60]
00007d0bb21d2459  movups [r13+r12*1], xmm11
00007d0bb21d245f  lea r12, [r14+0x70]
00007d0bb21d2463  movups [r13+r12*1], xmm5
00007d0bb21d2469  lea r12, [rax+0xE0]
00007d0bb21d2470  movups xmm11, [r13+r12*1]
00007d0bb21d2476  lea r12, [rax+0xF0]
00007d0bb21d247d  movups xmm5, [r13+r12*1]
00007d0bb21d2483  lea r12, [rax+0x120]
00007d0bb21d248a  vmovaps [rsp+0x10], xmm1
00007d0bb21d2490  movups xmm1, [r13+r12*1]
00007d0bb21d2496  lea r12, [rax+0x130]
00007d0bb21d249d  vmovaps [rsp+0x20], xmm1
00007d0bb21d24a3  movups xmm1, [r13+r12*1]
00007d0bb21d24a9  lea r12, [r14+0xA0]
00007d0bb21d24b0  movups [r13+r12*1], xmm12
00007d0bb21d24b6  lea r12, [r14+0xB0]
00007d0bb21d24bd  vmovaps xmm12, [rsp+0x10]
00007d0bb21d24c3  movups [r13+r12*1], xmm12
00007d0bb21d24c9  lea r12, [rax+0xA0]
00007d0bb21d24d0  movups xmm12, [r13+r12*1]
00007d0bb21d24d6  lea r12, [rax+0xB0]
00007d0bb21d24dd  vmovaps [rsp+0x10], xmm1
00007d0bb21d24e3  movups xmm1, [r13+r12*1]
00007d0bb21d24e9  lea r12, [rax+0x160]
00007d0bb21d24f0  vmovaps [rsp+0x30], xmm1
00007d0bb21d24f6  movups xmm1, [r13+r12*1]
00007d0bb21d24fc  lea r12, [rax+0x170]
00007d0bb21d2503  vmovaps [rsp+0x40], xmm1
00007d0bb21d2509  movups xmm1, [r13+r12*1]
00007d0bb21d250f  movaps [r15+0x2B0], xmm1
00007d0bb21d2517  lea r12, [rax+0x1A0]
00007d0bb21d251e  vmovaps [rsp+0x50], xmm1
00007d0bb21d2524  movups xmm1, [r13+r12*1]
00007d0bb21d252a  lea r12, [rax+0x1B0]
00007d0bb21d2531  vmovaps [rsp+0x60], xmm1
00007d0bb21d2537  movups xmm1, [r13+r12*1]
00007d0bb21d253d  vmovaps [rsp+0x70], xmm1
00007d0bb21d2543  vmovaps xmm1, [rsp+0x60]
00007d0bb21d2549  movaps [r15+0x290], xmm1
00007d0bb21d2551  vmovaps [rsp+0x60], xmm1
00007d0bb21d2557  vmovaps xmm1, [rsp+0x70]
00007d0bb21d255d  movaps [r15+0x1E0], xmm1
00007d0bb21d2565  lea r12, [r14+0x80]
00007d0bb21d256c  vmovaps [rsp+0x70], xmm1
00007d0bb21d2572  vmovaps xmm1, [rsp+0x30]
00007d0bb21d2578  movups [r13+r12*1], xmm1
00007d0bb21d257e  lea r12, [r14+0x90]
00007d0bb21d2585  movups [r13+r12*1], xmm12
00007d0bb21d258b  lea r12, [rax+0x1E0]
00007d0bb21d2592  movups xmm1, [r13+r12*1]
00007d0bb21d2598  lea r12, [rax+0x1F0]
00007d0bb21d259f  movups xmm12, [r13+r12*1]
00007d0bb21d25a5  mov qword ptr [r15+0x50], 0x432200
00007d0bb21d25ad  lea rax, [r14+0x40]
00007d0bb21d25b1  vmovaps [rsp+0x30], xmm1
00007d0bb21d25b7  vmovaps xmm1, [rsp+0x40]
00007d0bb21d25bd  movups [r13+rax*1], xmm1
00007d0bb21d25c3  lea rax, [r14+0x50]
00007d0bb21d25c7  movups [r13+rax*1], xmm10
00007d0bb21d25cd  movups [r13+r14*1], xmm12
00007d0bb21d25d3  lea rax, [r14+0x10]
00007d0bb21d25d7  vmovaps xmm1, [rsp+0x30]
00007d0bb21d25dd  movups [r13+rax*1], xmm1
00007d0bb21d25e3  mov rax, [r15+0x40]
00007d0bb21d25e7  vmovaps [rsp+0x30], xmm3
00007d0bb21d25ed  vmovaps xmm1, [rsp+0x30]
00007d0bb21d25f3  por xmm3, xmm1
00007d0bb21d25f7  vmovaps [rsp+0x30], xmm6
00007d0bb21d25fd  vmovaps xmm12, [rsp+0x30]
00007d0bb21d2603  por xmm6, xmm12
00007d0bb21d2608  lea r12, [rax+0x30]
00007d0bb21d260c  mov r11, [r13+r12*1]
00007d0bb21d2611  lea r12, [rax+0x38]
00007d0bb21d2615  mov r10, [r13+r12*1]
00007d0bb21d261a  movq xmm12, r11
00007d0bb21d261f  movq xmm10, r10
00007d0bb21d2624  movq xmm12, xmm12
00007d0bb21d2629  vmovaps [rsp+0x30], xmm12
00007d0bb21d262f  movq xmm12, xmm12
00007d0bb21d2634  movaps [r15+0x130], xmm12
00007d0bb21d263c  movq xmm10, xmm10
00007d0bb21d2641  vmovaps [rsp+0x40], xmm10
00007d0bb21d2647  movq xmm10, xmm10
00007d0bb21d264c  movaps [r15+0x280], xmm10
00007d0bb21d2654  vmovaps [rsp+0x80], xmm9
00007d0bb21d265d  vmovaps xmm12, [rsp+0x80]
00007d0bb21d2666  por xmm9, xmm12
00007d0bb21d266b  lea r12, [rax+0x20]
00007d0bb21d266f  mov r11, [r13+r12*1]
00007d0bb21d2674  lea r12, [rax+0x28]
00007d0bb21d2678  mov r10, [r13+r12*1]
00007d0bb21d267d  movq xmm12, r11
00007d0bb21d2682  movq xmm10, r10
00007d0bb21d2687  movq xmm12, xmm12
00007d0bb21d268c  vmovaps [rsp+0x80], xmm12
00007d0bb21d2695  movq xmm12, xmm12
00007d0bb21d269a  movaps [r15+0x150], xmm12
00007d0bb21d26a2  movq xmm10, xmm10
00007d0bb21d26a7  vmovaps [rsp+0x90], xmm10
00007d0bb21d26b0  movq xmm10, xmm10
00007d0bb21d26b5  movaps [r15+0x140], xmm10
00007d0bb21d26bd  lea r12, [rax+0x10]
00007d0bb21d26c1  mov r11, [r13+r12*1]
00007d0bb21d26c6  lea r12, [rax+0x18]
00007d0bb21d26ca  mov r10, [r13+r12*1]
00007d0bb21d26cf  movq xmm12, r11
00007d0bb21d26d4  movq xmm10, r10
00007d0bb21d26d9  movq xmm12, xmm12
00007d0bb21d26de  vmovaps [rsp+0xA0], xmm12
00007d0bb21d26e7  movq xmm12, xmm12
00007d0bb21d26ec  movaps [r15+0x170], xmm12
00007d0bb21d26f4  movq xmm10, xmm10
00007d0bb21d26f9  vmovaps [rsp+0xB0], xmm10
00007d0bb21d2702  movq xmm10, xmm10
00007d0bb21d2707  movaps [r15+0x160], xmm10
00007d0bb21d270f  mov r12, [r13+rax*1]
00007d0bb21d2714  vmovq xmm12, r12
00007d0bb21d2719  vpbroadcastq xmm12, xmm12
00007d0bb21d271e  lea r12, [rax+0x08]
00007d0bb21d2722  mov rax, [r13+r12*1]
00007d0bb21d2727  movq xmm10, rax
00007d0bb21d272c  movaps [r15+0x230], xmm10
00007d0bb21d2734  lea rax, [r14+0x50]
00007d0bb21d2738  movups xmm10, [r13+rax*1]
00007d0bb21d273e  lea rax, [r14+0x60]
00007d0bb21d2742  vmovaps [rsp+0xC0], xmm1
00007d0bb21d274b  movups xmm1, [r13+rax*1]
00007d0bb21d2751  lea rax, [r14+0x30]
00007d0bb21d2755  vmovaps [rsp+0xD0], xmm1
00007d0bb21d275e  movups xmm1, [r13+rax*1]
00007d0bb21d2764  mov qword ptr [r15+0x60], 0x432200
00007d0bb21d276c  mov qword ptr [r15+0x58], 0x40
00007d0bb21d2774  vmovaps [rsp+0xE0], xmm1
00007d0bb21d277d  vmovaps [rsp+0xF0], xmm15
00007d0bb21d2786  vmovaps xmm15, [rsp+0xC0]
00007d0bb21d278f  vmovaps [rsp+0xC0], xmm14
00007d0bb21d2798  movaps xmm1, xmm12
00007d0bb21d279c  mulpd xmm1, xmm15
00007d0bb21d27a1  vcmppd xmm14, xmm1, xmm1, 0x03
00007d0bb21d27a6  ptest xmm14, xmm14
00007d0bb21d27ac  jnz 0x00007D0BB21D3863
00007d0bb21d27b2  movq xmm15, qword ptr [r15+0x230]
00007d0bb21d27bb  vmovaps [rsp+0x100], xmm15
00007d0bb21d27c4  vpermilpd xmm15, xmm15, 0x00
00007d0bb21d27ca  vmovaps [rsp+0x110], xmm1
00007d0bb21d27d3  vmovaps xmm1, [rsp+0xE0]
00007d0bb21d27dc  vmovaps [rsp+0xE0], xmm13
00007d0bb21d27e5  movaps xmm14, xmm1
00007d0bb21d27e9  mulpd xmm14, xmm15
00007d0bb21d27ee  vcmppd xmm13, xmm14, xmm14, 0x03
00007d0bb21d27f4  ptest xmm13, xmm13
00007d0bb21d27fa  jnz 0x00007D0BB21D39A5
00007d0bb21d2800  vxorps xmm1, xmm1, xmm1
00007d0bb21d2804  vpbroadcastq xmm1, xmm1
00007d0bb21d2809  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d2812  vmovaps [rsp+0xD0], xmm1
00007d0bb21d281b  movaps xmm15, xmm12
00007d0bb21d281f  mulpd xmm15, xmm13
00007d0bb21d2824  vcmppd xmm1, xmm15, xmm15, 0x03
00007d0bb21d282a  ptest xmm1, xmm1
00007d0bb21d282f  jnz 0x00007D0BB21D3AE8
00007d0bb21d2835  movaps xmm1, xmm12
00007d0bb21d2839  mulpd xmm1, xmm10
00007d0bb21d283e  vcmppd xmm13, xmm1, xmm1, 0x03
00007d0bb21d2843  ptest xmm13, xmm13
00007d0bb21d2849  jnz 0x00007D0BB21D3C2C
00007d0bb21d284f  movaps xmm13, xmm12
00007d0bb21d2853  mulpd xmm13, xmm2
00007d0bb21d2858  vcmppd xmm10, xmm13, xmm13, 0x03
00007d0bb21d285e  ptest xmm10, xmm10
00007d0bb21d2864  jnz 0x00007D0BB21D3D6E
00007d0bb21d286a  vmovaps [rsp+0x120], xmm7
00007d0bb21d2873  vmovaps xmm12, [rsp+0x120]
00007d0bb21d287c  por xmm7, xmm12
00007d0bb21d2881  vmovaps xmm12, [rsp+0xE0]
00007d0bb21d288a  vmovaps xmm10, [rsp+0xE0]
00007d0bb21d2893  por xmm12, xmm10
00007d0bb21d2898  vmovaps xmm2, [rsp+0x100]
00007d0bb21d28a1  vpermilpd xmm2, xmm2, 0x00
00007d0bb21d28a7  vmovaps [rsp+0xE0], xmm1
00007d0bb21d28b0  vmovaps [rsp+0x120], xmm15
00007d0bb21d28b9  movaps xmm1, xmm10
00007d0bb21d28bd  mulpd xmm1, xmm2
00007d0bb21d28c1  vcmppd xmm15, xmm1, xmm1, 0x03
00007d0bb21d28c6  ptest xmm15, xmm15
00007d0bb21d28cc  jnz 0x00007D0BB21D3EB1
00007d0bb21d28d2  xor eax, eax
00007d0bb21d28d4  mov r12d, 0x40
00007d0bb21d28da  mov r11d, 0x200
00007d0bb21d28e0  cmp r12, r11
00007d0bb21d28e3  cmc
00007d0bb21d28e4  lahf
00007d0bb21d28e5  seto al
00007d0bb21d28e8  mov [r15+0x108], eax
00007d0bb21d28ef  vmovaps xmm10, [rsp+0x110]
00007d0bb21d28f8  vmovaps xmm2, [rsp+0xD0]
00007d0bb21d2901  vmovaps [rsp+0xD0], xmm1
00007d0bb21d290a  movaps xmm15, xmm10
00007d0bb21d290e  addpd xmm15, xmm2
00007d0bb21d2913  vcmppd xmm1, xmm15, xmm15, 0x03
00007d0bb21d2919  ptest xmm1, xmm1
00007d0bb21d291e  jnz 0x00007D0BB21D3FF2
00007d0bb21d2924  vmovaps xmm10, [rsp+0x120]
00007d0bb21d292d  vmovaps [rsp+0x110], xmm15
00007d0bb21d2936  vmovaps xmm15, [rsp+0xC0]
00007d0bb21d293f  vmovaps [rsp+0xC0], xmm14
00007d0bb21d2948  movaps xmm1, xmm10
00007d0bb21d294c  addpd xmm1, xmm15
00007d0bb21d2951  vcmppd xmm14, xmm1, xmm1, 0x03
00007d0bb21d2956  ptest xmm14, xmm14
00007d0bb21d295c  jnz 0x00007D0BB21D4135
00007d0bb21d2962  vmovaps xmm10, [rsp+0xE0]
00007d0bb21d296b  vmovaps [rsp+0xE0], xmm1
00007d0bb21d2974  movaps xmm14, xmm10
00007d0bb21d2978  addpd xmm14, xmm15
00007d0bb21d297d  vcmppd xmm1, xmm14, xmm14, 0x03
00007d0bb21d2983  ptest xmm1, xmm1
00007d0bb21d2988  jnz 0x00007D0BB21D4277
00007d0bb21d298e  vmovaps xmm1, [rsp+0x10]
00007d0bb21d2994  vmovaps xmm15, [rsp+0x10]
00007d0bb21d299a  por xmm1, xmm15
00007d0bb21d299f  vmovaps xmm15, [rsp+0x20]
00007d0bb21d29a5  vmovaps xmm10, [rsp+0x20]
00007d0bb21d29ab  por xmm15, xmm10
00007d0bb21d29b0  vmovaps [rsp+0x10], xmm5
00007d0bb21d29b6  vmovaps xmm10, [rsp+0x10]
00007d0bb21d29bc  por xmm5, xmm10
00007d0bb21d29c1  vmovaps [rsp+0x10], xmm11
00007d0bb21d29c7  vmovaps xmm10, [rsp+0x10]
00007d0bb21d29cd  por xmm11, xmm10
00007d0bb21d29d2  vmovaps [rsp+0x10], xmm4
00007d0bb21d29d8  vmovaps xmm10, [rsp+0x10]
00007d0bb21d29de  por xmm4, xmm10
00007d0bb21d29e3  vmovaps [rsp+0x10], xmm8
00007d0bb21d29e9  vmovaps xmm10, [rsp+0x10]
00007d0bb21d29ef  por xmm8, xmm10
00007d0bb21d29f4  vmovaps xmm10, [rsp+0xF0]
00007d0bb21d29fd  vmovaps [rsp+0x10], xmm1
00007d0bb21d2a03  vmovaps xmm1, [rsp+0xF0]
00007d0bb21d2a0c  por xmm10, xmm1
00007d0bb21d2a11  lea rax, [r14+0xA0]
00007d0bb21d2a18  movups xmm1, [r13+rax*1]
00007d0bb21d2a1e  lea rax, [r14+0xB0]
00007d0bb21d2a25  vmovaps [rsp+0x20], xmm1
00007d0bb21d2a2b  movups xmm1, [r13+rax*1]
00007d0bb21d2a31  vmovaps [rsp+0xF0], xmm1
00007d0bb21d2a3a  vmovaps [rsp+0x120], xmm15
00007d0bb21d2a43  movaps xmm1, xmm13
00007d0bb21d2a47  addpd xmm1, xmm2
00007d0bb21d2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
00007d0bb21d2a50  ptest xmm15, xmm15
00007d0bb21d2a56  jnz 0x00007D0BB21D43CF
00007d0bb21d2a5c  lea rax, [r14+0xF0]
00007d0bb21d2a63  movups xmm15, [r13+rax*1]
00007d0bb21d2a69  vmovaps xmm2, [rsp+0xE0]
00007d0bb21d2a72  vmovaps [rsp+0xE0], xmm1
00007d0bb21d2a7b  vmovaps xmm1, [rsp+0xD0]
00007d0bb21d2a84  vmovaps [rsp+0xD0], xmm15
00007d0bb21d2a8d  movaps xmm13, xmm2
00007d0bb21d2a91  addpd xmm13, xmm1
00007d0bb21d2a96  vcmppd xmm15, xmm13, xmm13, 0x03
00007d0bb21d2a9c  ptest xmm15, xmm15
00007d0bb21d2aa2  jnz 0x00007D0BB21D451A
00007d0bb21d2aa8  vmovaps xmm15, [rsp+0xC0]
00007d0bb21d2ab1  movaps xmm1, xmm14
00007d0bb21d2ab5  addpd xmm1, xmm15
00007d0bb21d2aba  vcmppd xmm2, xmm1, xmm1, 0x03
00007d0bb21d2abf  ptest xmm2, xmm2
00007d0bb21d2ac4  jnz 0x00007D0BB21D465C
00007d0bb21d2aca  vmovaps xmm15, [rsp+0x100]
00007d0bb21d2ad3  vpermilpd xmm15, xmm15, 0x00
00007d0bb21d2ad9  vmovaps xmm2, [rsp+0xF0]
00007d0bb21d2ae2  vmovaps [rsp+0xC0], xmm1
00007d0bb21d2aeb  movaps xmm14, xmm2
00007d0bb21d2aef  mulpd xmm14, xmm15
00007d0bb21d2af4  vcmppd xmm1, xmm14, xmm14, 0x03
00007d0bb21d2afa  ptest xmm1, xmm1
00007d0bb21d2aff  jnz 0x00007D0BB21D479E
00007d0bb21d2b05  vmovaps xmm1, [rsp+0xA0]
00007d0bb21d2b0e  vpermilpd xmm1, xmm1, 0x00
00007d0bb21d2b14  vmovaps xmm2, [rsp+0xD0]
00007d0bb21d2b1d  vmovaps [rsp+0xD0], xmm14
00007d0bb21d2b26  movaps xmm15, xmm2
00007d0bb21d2b2a  mulpd xmm15, xmm1
00007d0bb21d2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
00007d0bb21d2b35  ptest xmm14, xmm14
00007d0bb21d2b3b  jnz 0x00007D0BB21D48E1
00007d0bb21d2b41  lea rax, [r14+0xE0]
00007d0bb21d2b48  movups xmm1, [r13+rax*1]
00007d0bb21d2b4e  vmovaps xmm14, [rsp+0x100]
00007d0bb21d2b57  vpermilpd xmm14, xmm14, 0x00
00007d0bb21d2b5d  vmovaps [rsp+0xF0], xmm1
00007d0bb21d2b66  vmovaps xmm1, [rsp+0x20]
00007d0bb21d2b6c  vmovaps [rsp+0x20], xmm15
00007d0bb21d2b72  movaps xmm2, xmm1
00007d0bb21d2b75  mulpd xmm2, xmm14
00007d0bb21d2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
00007d0bb21d2b7f  ptest xmm15, xmm15
00007d0bb21d2b85  jnz 0x00007D0BB21D4A2D
00007d0bb21d2b8b  vmovaps [rsp+0x100], xmm10
00007d0bb21d2b94  vmovaps xmm1, [rsp+0x100]
00007d0bb21d2b9d  por xmm10, xmm1
00007d0bb21d2ba2  movaps [r15+0x300], xmm10
00007d0bb21d2baa  vmovaps [rsp+0x100], xmm8
00007d0bb21d2bb3  vmovaps xmm1, [rsp+0x100]
00007d0bb21d2bbc  por xmm8, xmm1
00007d0bb21d2bc1  movaps [r15+0x190], xmm8
00007d0bb21d2bc9  vmovaps xmm1, [rsp+0xA0]
00007d0bb21d2bd2  vpermilpd xmm1, xmm1, 0x00
00007d0bb21d2bd8  vmovaps xmm14, [rsp+0xF0]
00007d0bb21d2be1  vmovaps [rsp+0xF0], xmm13
00007d0bb21d2bea  movaps xmm15, xmm14
00007d0bb21d2bee  mulpd xmm15, xmm1
00007d0bb21d2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
00007d0bb21d2bf9  ptest xmm13, xmm13
00007d0bb21d2bff  jnz 0x00007D0BB21D4B6E
00007d0bb21d2c05  lea rax, [r14+0x90]
00007d0bb21d2c0c  movups xmm1, [r13+rax*1]
00007d0bb21d2c12  vmovaps [rsp+0x100], xmm4
00007d0bb21d2c1b  vmovaps xmm14, [rsp+0x100]
00007d0bb21d2c24  por xmm4, xmm14
00007d0bb21d2c29  movaps [r15+0x1C0], xmm4
00007d0bb21d2c31  vmovaps [rsp+0x100], xmm11
00007d0bb21d2c3a  vmovaps xmm14, [rsp+0x100]
00007d0bb21d2c43  por xmm11, xmm14
00007d0bb21d2c48  movaps [r15+0x200], xmm11
00007d0bb21d2c50  vmovaps [rsp+0x100], xmm5
00007d0bb21d2c59  vmovaps xmm14, [rsp+0x100]
00007d0bb21d2c62  por xmm5, xmm14
00007d0bb21d2c67  movaps [r15+0x2D0], xmm5
00007d0bb21d2c6f  vmovaps xmm14, [rsp+0x120]
00007d0bb21d2c78  vmovaps xmm13, [rsp+0x120]
00007d0bb21d2c81  por xmm14, xmm13
00007d0bb21d2c86  movaps [r15+0x2E0], xmm14
00007d0bb21d2c8e  vmovaps [rsp+0x100], xmm1
00007d0bb21d2c97  vmovaps xmm1, [rsp+0x110]
00007d0bb21d2ca0  vmovaps [rsp+0x110], xmm15
00007d0bb21d2ca9  vmovaps xmm15, [rsp+0xD0]
00007d0bb21d2cb2  vmovaps [rsp+0xD0], xmm14
00007d0bb21d2cbb  movaps xmm13, xmm1
00007d0bb21d2cbf  addpd xmm13, xmm15
00007d0bb21d2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
00007d0bb21d2cca  ptest xmm14, xmm14
00007d0bb21d2cd0  jnz 0x00007D0BB21D4CBB
00007d0bb21d2cd6  vmovaps xmm1, [rsp+0xA0]
00007d0bb21d2cdf  vpermilpd xmm1, xmm1, 0x00
00007d0bb21d2ce5  vmovaps xmm14, [rsp+0x100]
00007d0bb21d2cee  vmovaps [rsp+0x100], xmm13
00007d0bb21d2cf7  movaps xmm15, xmm14
00007d0bb21d2cfb  mulpd xmm15, xmm1
00007d0bb21d2d00  vcmppd xmm13, xmm15, xmm15, 0x03
00007d0bb21d2d06  ptest xmm13, xmm13
00007d0bb21d2d0c  jnz 0x00007D0BB21D4DFE
00007d0bb21d2d12  lea rax, [r14+0x80]
00007d0bb21d2d19  movups xmm1, [r13+rax*1]
00007d0bb21d2d1f  vmovaps xmm13, [rsp+0xE0]
00007d0bb21d2d28  vmovaps [rsp+0xE0], xmm1
00007d0bb21d2d31  movaps xmm14, xmm13
00007d0bb21d2d35  addpd xmm14, xmm2
00007d0bb21d2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
00007d0bb21d2d40  ptest xmm1, xmm1
00007d0bb21d2d45  jnz 0x00007D0BB21D4F4B
00007d0bb21d2d4b  vmovaps xmm13, [rsp+0xF0]
00007d0bb21d2d54  vmovaps xmm2, [rsp+0x20]
00007d0bb21d2d5a  vmovaps [rsp+0x20], xmm15
00007d0bb21d2d60  movaps xmm1, xmm13
00007d0bb21d2d64  addpd xmm1, xmm2
00007d0bb21d2d68  vcmppd xmm15, xmm1, xmm1, 0x03
00007d0bb21d2d6d  ptest xmm15, xmm15
00007d0bb21d2d73  jnz 0x00007D0BB21D508E
00007d0bb21d2d79  vmovaps xmm15, [rsp+0x10]
00007d0bb21d2d7f  vmovaps xmm13, [rsp+0x10]
00007d0bb21d2d85  por xmm15, xmm13
00007d0bb21d2d8a  movaps [r15+0x2F0], xmm15
00007d0bb21d2d92  vmovaps xmm13, [rsp+0xA0]
00007d0bb21d2d9b  vpermilpd xmm13, xmm13, 0x00
00007d0bb21d2da1  vmovaps [rsp+0x10], xmm1
00007d0bb21d2da7  vmovaps xmm1, [rsp+0xE0]
00007d0bb21d2db0  vmovaps [rsp+0xA0], xmm15
00007d0bb21d2db9  movaps xmm2, xmm1
00007d0bb21d2dbc  mulpd xmm2, xmm13
00007d0bb21d2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
00007d0bb21d2dc6  ptest xmm15, xmm15
00007d0bb21d2dcc  jnz 0x00007D0BB21D51CF
00007d0bb21d2dd2  lea rax, [r14+0xD0]
00007d0bb21d2dd9  movups xmm1, [r13+rax*1]
00007d0bb21d2ddf  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d2de8  vmovaps [rsp+0xC0], xmm1
00007d0bb21d2df1  vmovaps xmm1, [rsp+0x110]
00007d0bb21d2dfa  vmovaps [rsp+0xE0], xmm14
00007d0bb21d2e03  movaps xmm15, xmm13
00007d0bb21d2e07  addpd xmm15, xmm1
00007d0bb21d2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
00007d0bb21d2e12  ptest xmm14, xmm14
00007d0bb21d2e18  jnz 0x00007D0BB21D531A
00007d0bb21d2e1e  vmovaps xmm1, [rsp+0xB0]
00007d0bb21d2e27  vpermilpd xmm1, xmm1, 0x00
00007d0bb21d2e2d  movaps xmm14, xmm11
00007d0bb21d2e31  mulpd xmm14, xmm1
00007d0bb21d2e36  vcmppd xmm13, xmm14, xmm14, 0x03
00007d0bb21d2e3c  ptest xmm13, xmm13
00007d0bb21d2e42  jnz 0x00007D0BB21D545D
00007d0bb21d2e48  movaps [r15+0x260], xmm14
00007d0bb21d2e50  vxorps xmm1, xmm1, xmm1
00007d0bb21d2e54  vpbroadcastq xmm1, xmm1
00007d0bb21d2e59  movaps [r15+0x1B0], xmm1
00007d0bb21d2e61  vmovaps xmm1, [rsp+0xB0]
00007d0bb21d2e6a  vpermilpd xmm1, xmm1, 0x00
00007d0bb21d2e70  vmovaps xmm11, [rsp+0xC0]
00007d0bb21d2e79  vmovaps [rsp+0xC0], xmm15
00007d0bb21d2e82  movaps xmm13, xmm11
00007d0bb21d2e86  mulpd xmm13, xmm1
00007d0bb21d2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
00007d0bb21d2e91  ptest xmm15, xmm15
00007d0bb21d2e97  jnz 0x00007D0BB21D55A0
00007d0bb21d2e9d  lea rax, [r14+0xC0]
00007d0bb21d2ea4  movups xmm1, [r13+rax*1]
00007d0bb21d2eaa  vmovaps xmm11, [rsp+0x100]
00007d0bb21d2eb3  vmovaps [rsp+0xF0], xmm1
00007d0bb21d2ebc  vmovaps xmm1, [rsp+0x20]
00007d0bb21d2ec2  vmovaps [rsp+0x20], xmm14
00007d0bb21d2ec8  movaps xmm15, xmm11
00007d0bb21d2ecc  addpd xmm15, xmm1
00007d0bb21d2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
00007d0bb21d2ed7  ptest xmm14, xmm14
00007d0bb21d2edd  jnz 0x00007D0BB21D56ED
00007d0bb21d2ee3  vmovaps [rsp+0x100], xmm9
00007d0bb21d2eec  vmovaps xmm1, [rsp+0x100]
00007d0bb21d2ef5  por xmm9, xmm1
00007d0bb21d2efa  movaps [r15+0x270], xmm9
00007d0bb21d2f02  vmovaps [rsp+0x100], xmm6
00007d0bb21d2f0b  vmovaps xmm1, [rsp+0x100]
00007d0bb21d2f14  por xmm6, xmm1
00007d0bb21d2f18  movaps [r15+0x1A0], xmm6
00007d0bb21d2f20  vmovaps xmm14, [rsp+0xB0]
00007d0bb21d2f29  vpermilpd xmm14, xmm14, 0x00
00007d0bb21d2f2f  vmovaps xmm6, [rsp+0xF0]
00007d0bb21d2f38  vmovaps [rsp+0xF0], xmm1
00007d0bb21d2f41  movaps xmm11, xmm6
00007d0bb21d2f45  mulpd xmm11, xmm14
00007d0bb21d2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
00007d0bb21d2f50  ptest xmm1, xmm1
00007d0bb21d2f55  jnz 0x00007D0BB21D5830
00007d0bb21d2f5b  lea rax, [r14+0x20]
00007d0bb21d2f5f  movups xmm1, [r13+rax*1]
00007d0bb21d2f65  movaps [r15+0x110], xmm1
00007d0bb21d2f6d  vmovaps xmm6, [rsp+0xE0]
00007d0bb21d2f76  vmovaps [rsp+0xE0], xmm1
00007d0bb21d2f7f  movaps xmm14, xmm6
00007d0bb21d2f83  addpd xmm14, xmm2
00007d0bb21d2f88  vcmppd xmm1, xmm14, xmm14, 0x03
00007d0bb21d2f8e  ptest xmm1, xmm1
00007d0bb21d2f93  jnz 0x00007D0BB21D597D
00007d0bb21d2f99  vmovaps xmm1, [rsp+0xB0]
00007d0bb21d2fa2  vpermilpd xmm1, xmm1, 0x00
00007d0bb21d2fa8  movaps xmm6, xmm5
00007d0bb21d2fab  mulpd xmm6, xmm1
00007d0bb21d2faf  vcmppd xmm2, xmm6, xmm6, 0x03
00007d0bb21d2fb4  ptest xmm2, xmm2
00007d0bb21d2fb9  jnz 0x00007D0BB21D5ABF
00007d0bb21d2fbf  vmovaps xmm5, [rsp+0x10]
00007d0bb21d2fc5  movaps xmm1, xmm5
00007d0bb21d2fc8  addpd xmm1, xmm13
00007d0bb21d2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
00007d0bb21d2fd2  ptest xmm2, xmm2
00007d0bb21d2fd7  jnz 0x00007D0BB21D5BFF
00007d0bb21d2fdd  vmovaps xmm13, [rsp+0x80]
00007d0bb21d2fe6  vpermilpd xmm13, xmm13, 0x00
00007d0bb21d2fec  vmovaps xmm2, [rsp+0xE0]
00007d0bb21d2ff5  vmovaps [rsp+0x10], xmm1
00007d0bb21d2ffb  movaps xmm5, xmm2
00007d0bb21d2ffe  mulpd xmm5, xmm13
00007d0bb21d3003  vcmppd xmm1, xmm5, xmm5, 0x03
00007d0bb21d3008  ptest xmm1, xmm1
00007d0bb21d300d  jnz 0x00007D0BB21D5D40
00007d0bb21d3013  vmovaps xmm1, [rsp+0x80]
00007d0bb21d301c  vpermilpd xmm1, xmm1, 0x00
00007d0bb21d3022  movaps xmm13, xmm10
00007d0bb21d3026  mulpd xmm13, xmm1
00007d0bb21d302b  vcmppd xmm2, xmm13, xmm13, 0x03
00007d0bb21d3031  ptest xmm2, xmm2
00007d0bb21d3036  jnz 0x00007D0BB21D5E81
00007d0bb21d303c  vmovaps xmm10, [rsp+0x20]
00007d0bb21d3042  movaps xmm1, xmm15
00007d0bb21d3046  addpd xmm1, xmm10
00007d0bb21d304b  vcmppd xmm2, xmm1, xmm1, 0x03
00007d0bb21d3050  ptest xmm2, xmm2
00007d0bb21d3055  jnz 0x00007D0BB21D5FC4
00007d0bb21d305b  vmovaps xmm10, [rsp+0xC0]
00007d0bb21d3064  movaps xmm15, xmm10
00007d0bb21d3068  addpd xmm15, xmm11
00007d0bb21d306d  vcmppd xmm2, xmm15, xmm15, 0x03
00007d0bb21d3073  ptest xmm2, xmm2
00007d0bb21d3078  jnz 0x00007D0BB21D6106
00007d0bb21d307e  vmovaps xmm11, [rsp+0x80]
00007d0bb21d3087  vpermilpd xmm11, xmm11, 0x00
00007d0bb21d308d  vmovaps xmm2, [rsp+0xD0]
00007d0bb21d3096  vmovaps [rsp+0x20], xmm1
00007d0bb21d309c  movaps xmm10, xmm2
00007d0bb21d30a0  mulpd xmm10, xmm11
00007d0bb21d30a5  vcmppd xmm1, xmm10, xmm10, 0x03
00007d0bb21d30ab  ptest xmm1, xmm1
00007d0bb21d30b0  jnz 0x00007D0BB21D624A
00007d0bb21d30b6  vmovaps xmm1, [rsp+0x80]
00007d0bb21d30bf  vpermilpd xmm1, xmm1, 0x00
00007d0bb21d30c5  vmovaps xmm2, [rsp+0xA0]
00007d0bb21d30ce  vmovaps [rsp+0x80], xmm15
00007d0bb21d30d7  movaps xmm11, xmm2
00007d0bb21d30db  mulpd xmm11, xmm1
00007d0bb21d30e0  vcmppd xmm15, xmm11, xmm11, 0x03
00007d0bb21d30e6  ptest xmm15, xmm15
00007d0bb21d30ec  jnz 0x00007D0BB21D638D
00007d0bb21d30f2  movaps xmm1, xmm14
00007d0bb21d30f6  addpd xmm1, xmm6
00007d0bb21d30fa  vcmppd xmm15, xmm1, xmm1, 0x03
00007d0bb21d30ff  ptest xmm15, xmm15
00007d0bb21d3105  jnz 0x00007D0BB21D64CF
00007d0bb21d310b  vmovaps xmm14, [rsp+0x10]
00007d0bb21d3111  movaps xmm15, xmm14
00007d0bb21d3115  addpd xmm15, xmm5
00007d0bb21d311a  vcmppd xmm6, xmm15, xmm15, 0x03
00007d0bb21d3120  ptest xmm6, xmm6
00007d0bb21d3125  jnz 0x00007D0BB21D6610
00007d0bb21d312b  vmovaps xmm14, [rsp+0x90]
00007d0bb21d3134  vpermilpd xmm14, xmm14, 0x00
00007d0bb21d313a  movaps xmm6, xmm9
00007d0bb21d313e  mulpd xmm6, xmm14
00007d0bb21d3143  vcmppd xmm5, xmm6, xmm6, 0x03
00007d0bb21d3148  ptest xmm5, xmm5
00007d0bb21d314d  jnz 0x00007D0BB21D6753
00007d0bb21d3153  vmovaps xmm9, [rsp+0x80]
00007d0bb21d315c  movaps xmm14, xmm9
00007d0bb21d3160  addpd xmm14, xmm13
00007d0bb21d3165  vcmppd xmm5, xmm14, xmm14, 0x03
00007d0bb21d316b  ptest xmm5, xmm5
00007d0bb21d3170  jnz 0x00007D0BB21D6895
00007d0bb21d3176  vmovaps xmm9, [rsp+0x20]
00007d0bb21d317c  movaps xmm13, xmm9
00007d0bb21d3180  addpd xmm13, xmm10
00007d0bb21d3185  vcmppd xmm5, xmm13, xmm13, 0x03
00007d0bb21d318b  ptest xmm5, xmm5
00007d0bb21d3190  jnz 0x00007D0BB21D69D9
00007d0bb21d3196  vmovaps [rsp+0x10], xmm12
00007d0bb21d319c  vmovaps xmm10, [rsp+0x10]
00007d0bb21d31a2  por xmm12, xmm10
00007d0bb21d31a7  movaps [r15+0x250], xmm12
00007d0bb21d31af  vmovaps [rsp+0x10], xmm7
00007d0bb21d31b5  vmovaps xmm12, [rsp+0x10]
00007d0bb21d31bb  por xmm7, xmm12
00007d0bb21d31c0  movaps [r15+0x2A0], xmm7
00007d0bb21d31c8  vmovaps [rsp+0x10], xmm3
00007d0bb21d31ce  vmovaps xmm12, [rsp+0x10]
00007d0bb21d31d4  por xmm3, xmm12
00007d0bb21d31d9  movaps [r15+0x1D0], xmm3
00007d0bb21d31e1  lea rax, [r14+0x40]
00007d0bb21d31e5  movups xmm12, [r13+rax*1]
00007d0bb21d31eb  movaps [r15+0x2C0], xmm12
00007d0bb21d31f3  vmovaps xmm10, [rsp+0x90]
00007d0bb21d31fc  vpermilpd xmm10, xmm10, 0x00
00007d0bb21d3202  movaps xmm9, xmm8
00007d0bb21d3206  mulpd xmm9, xmm10
00007d0bb21d320b  vcmppd xmm5, xmm9, xmm9, 0x03
00007d0bb21d3211  ptest xmm5, xmm5
00007d0bb21d3216  jnz 0x00007D0BB21D6B27
00007d0bb21d321c  movaps xmm10, xmm1
00007d0bb21d3220  addpd xmm10, xmm11
00007d0bb21d3225  vcmppd xmm8, xmm10, xmm10, 0x03
00007d0bb21d322b  ptest xmm8, xmm8
00007d0bb21d3231  jnz 0x00007D0BB21D6C6B
00007d0bb21d3237  movaps xmm1, xmm15
00007d0bb21d323b  addpd xmm1, xmm6
00007d0bb21d323f  vcmppd xmm11, xmm1, xmm1, 0x03
00007d0bb21d3244  ptest xmm11, xmm11
00007d0bb21d324a  jnz 0x00007D0BB21D6DAE
00007d0bb21d3250  vmovaps xmm15, [rsp+0x90]
00007d0bb21d3259  vpermilpd xmm15, xmm15, 0x00
00007d0bb21d325f  movaps xmm11, xmm12
00007d0bb21d3263  mulpd xmm11, xmm15
00007d0bb21d3268  vcmppd xmm8, xmm11, xmm11, 0x03
00007d0bb21d326e  ptest xmm8, xmm8
00007d0bb21d3274  jnz 0x00007D0BB21D6EEF
00007d0bb21d327a  vmovaps xmm15, [rsp+0x90]
00007d0bb21d3283  vpermilpd xmm15, xmm15, 0x00
00007d0bb21d3289  vmovaps xmm8, [rsp+0x50]
00007d0bb21d328f  movaps xmm12, xmm8
00007d0bb21d3293  mulpd xmm12, xmm15
00007d0bb21d3298  vcmppd xmm6, xmm12, xmm12, 0x03
00007d0bb21d329e  ptest xmm6, xmm6
00007d0bb21d32a3  jnz 0x00007D0BB21D7033
00007d0bb21d32a9  vmovaps xmm15, [rsp+0x30]
00007d0bb21d32af  vpermilpd xmm15, xmm15, 0x00
00007d0bb21d32b5  movaps xmm8, xmm7
00007d0bb21d32b9  mulpd xmm8, xmm15
00007d0bb21d32be  vcmppd xmm6, xmm8, xmm8, 0x03
00007d0bb21d32c4  ptest xmm6, xmm6
00007d0bb21d32c9  jnz 0x00007D0BB21D7177
00007d0bb21d32cf  movaps xmm15, xmm14
00007d0bb21d32d3  addpd xmm15, xmm9
00007d0bb21d32d8  vcmppd xmm7, xmm15, xmm15, 0x03
00007d0bb21d32de  ptest xmm7, xmm7
00007d0bb21d32e3  jnz 0x00007D0BB21D72BA
00007d0bb21d32e9  vmovaps xmm14, [rsp+0x30]
00007d0bb21d32ef  vpermilpd xmm14, xmm14, 0x00
00007d0bb21d32f5  vmovaps xmm7, [rsp+0xF0]
00007d0bb21d32fe  movaps xmm9, xmm7
00007d0bb21d3302  mulpd xmm9, xmm14
00007d0bb21d3307  vcmppd xmm6, xmm9, xmm9, 0x03
00007d0bb21d330d  ptest xmm6, xmm6
00007d0bb21d3312  jnz 0x00007D0BB21D73FE
00007d0bb21d3318  movaps xmm14, xmm13
00007d0bb21d331c  addpd xmm14, xmm11
00007d0bb21d3321  vcmppd xmm7, xmm14, xmm14, 0x03
00007d0bb21d3327  ptest xmm7, xmm7
00007d0bb21d332c  jnz 0x00007D0BB21D7541
00007d0bb21d3332  vmovaps xmm13, [rsp+0x30]
00007d0bb21d3338  vpermilpd xmm13, xmm13, 0x00
00007d0bb21d333e  vmovaps xmm7, [rsp+0x60]
00007d0bb21d3344  movaps xmm11, xmm7
00007d0bb21d3348  mulpd xmm11, xmm13
00007d0bb21d334d  vcmppd xmm6, xmm11, xmm11, 0x03
00007d0bb21d3353  ptest xmm6, xmm6
00007d0bb21d3358  jnz 0x00007D0BB21D7685
00007d0bb21d335e  movaps xmm13, xmm10
00007d0bb21d3362  addpd xmm13, xmm12
00007d0bb21d3367  vcmppd xmm7, xmm13, xmm13, 0x03
00007d0bb21d336d  ptest xmm7, xmm7
00007d0bb21d3372  jnz 0x00007D0BB21D77C8
00007d0bb21d3378  vmovaps xmm12, [rsp+0x30]
00007d0bb21d337e  vpermilpd xmm12, xmm12, 0x00
00007d0bb21d3384  vmovaps xmm7, [rsp+0x70]
00007d0bb21d338a  movaps xmm10, xmm7
00007d0bb21d338e  mulpd xmm10, xmm12
00007d0bb21d3393  vcmppd xmm6, xmm10, xmm10, 0x03
00007d0bb21d3399  ptest xmm6, xmm6
00007d0bb21d339e  jnz 0x00007D0BB21D790C
00007d0bb21d33a4  movaps xmm12, xmm1
00007d0bb21d33a8  addpd xmm12, xmm8
00007d0bb21d33ad  vcmppd xmm7, xmm12, xmm12, 0x03
00007d0bb21d33b3  ptest xmm7, xmm7
00007d0bb21d33b8  jnz 0x00007D0BB21D7A4F
00007d0bb21d33be  lea rax, [r14+0x70]
00007d0bb21d33c2  movups xmm1, [r13+rax*1]
00007d0bb21d33c8  movaps [r15+0x240], xmm1
00007d0bb21d33d0  movaps xmm8, xmm15
00007d0bb21d33d4  addpd xmm8, xmm9
00007d0bb21d33d9  vcmppd xmm7, xmm8, xmm8, 0x03
00007d0bb21d33df  ptest xmm7, xmm7
00007d0bb21d33e4  jnz 0x00007D0BB21D7B9C
00007d0bb21d33ea  movaps [r15+0x170], xmm8
00007d0bb21d33f2  vmovaps xmm15, [rsp+0x40]
00007d0bb21d33f8  vpermilpd xmm15, xmm15, 0x00
00007d0bb21d33fe  movaps xmm9, xmm1
00007d0bb21d3402  mulpd xmm9, xmm15
00007d0bb21d3407  vcmppd xmm7, xmm9, xmm9, 0x03
00007d0bb21d340d  ptest xmm7, xmm7
00007d0bb21d3412  jnz 0x00007D0BB21D7CE0
00007d0bb21d3418  vmovaps xmm1, [rsp+0x40]
00007d0bb21d341e  vpermilpd xmm1, xmm1, 0x00
00007d0bb21d3424  movaps xmm15, xmm4
00007d0bb21d3428  mulpd xmm15, xmm1
00007d0bb21d342d  vcmppd xmm7, xmm15, xmm15, 0x03
00007d0bb21d3433  ptest xmm7, xmm7
00007d0bb21d3438  jnz 0x00007D0BB21D7E23
00007d0bb21d343e  movaps [r15+0x180], xmm15
00007d0bb21d3446  movaps xmm1, xmm14
00007d0bb21d344a  addpd xmm1, xmm11
00007d0bb21d344f  vcmppd xmm7, xmm1, xmm1, 0x03
00007d0bb21d3454  ptest xmm7, xmm7
00007d0bb21d3459  jnz 0x00007D0BB21D7F65
00007d0bb21d345f  movaps [r15+0x210], xmm1
00007d0bb21d3467  movups xmm14, [r13+r14*1]
00007d0bb21d346d  lea rax, [r14+0x10]
00007d0bb21d3471  movups xmm11, [r13+rax*1]
00007d0bb21d3477  movaps [r15+0x230], xmm11
00007d0bb21d347f  movaps xmm7, xmm13
00007d0bb21d3483  addpd xmm7, xmm10
00007d0bb21d3488  vcmppd xmm6, xmm7, xmm7, 0x03
00007d0bb21d348d  ptest xmm6, xmm6
00007d0bb21d3492  jnz 0x00007D0BB21D80BB
00007d0bb21d3498  movaps [r15+0x130], xmm7
00007d0bb21d34a0  vmovaps xmm13, [rsp+0x40]
00007d0bb21d34a6  vpermilpd xmm13, xmm13, 0x00
00007d0bb21d34ac  movaps xmm10, xmm11
00007d0bb21d34b0  mulpd xmm10, xmm13
00007d0bb21d34b5  vcmppd xmm6, xmm10, xmm10, 0x03
00007d0bb21d34bb  ptest xmm6, xmm6
00007d0bb21d34c0  jnz 0x00007D0BB21D81FD
00007d0bb21d34c6  movaps [r15+0x220], xmm10
00007d0bb21d34ce  vmovaps xmm13, [rsp+0x40]
00007d0bb21d34d4  vpermilpd xmm13, xmm13, 0x00
00007d0bb21d34da  movaps xmm11, xmm14
00007d0bb21d34de  mulpd xmm11, xmm13
00007d0bb21d34e3  vcmppd xmm6, xmm11, xmm11, 0x03
00007d0bb21d34e9  ptest xmm6, xmm6
00007d0bb21d34ee  jnz 0x00007D0BB21D8341
00007d0bb21d34f4  movaps xmm14, xmm12
00007d0bb21d34f8  addpd xmm14, xmm9
00007d0bb21d34fd  vcmppd xmm13, xmm14, xmm14, 0x03
00007d0bb21d3503  ptest xmm13, xmm13
00007d0bb21d3509  jnz 0x00007D0BB21D8485
00007d0bb21d350f  movaps [r15+0x140], xmm14
00007d0bb21d3517  movaps xmm13, xmm8
00007d0bb21d351b  addpd xmm13, xmm15
00007d0bb21d3520  vcmppd xmm12, xmm13, xmm13, 0x03
00007d0bb21d3526  ptest xmm12, xmm12
00007d0bb21d352c  jnz 0x00007D0BB21D85C9
00007d0bb21d3532  movaps [r15+0x150], xmm13
00007d0bb21d353a  movaps xmm15, xmm1
00007d0bb21d353e  addpd xmm15, xmm10
00007d0bb21d3543  vcmppd xmm12, xmm15, xmm15, 0x03
00007d0bb21d3549  ptest xmm12, xmm12
00007d0bb21d354f  jnz 0x00007D0BB21D870D
00007d0bb21d3555  movaps [r15+0x160], xmm15
00007d0bb21d355d  movaps xmm1, xmm7
00007d0bb21d3560  addpd xmm1, xmm11
00007d0bb21d3565  vcmppd xmm12, xmm1, xmm1, 0x03
00007d0bb21d356a  ptest xmm12, xmm12
00007d0bb21d3570  jnz 0x00007D0BB21D8850
00007d0bb21d3576  movaps [r15+0x120], xmm1
00007d0bb21d357e  mov eax, 0x432200
00007d0bb21d3583  movups [r13+rax*1], xmm14
00007d0bb21d3589  mov eax, 0x432210
00007d0bb21d358e  movups [r13+rax*1], xmm13
00007d0bb21d3594  mov eax, 0x432220
00007d0bb21d3599  movups [r13+rax*1], xmm15
00007d0bb21d359f  mov eax, 0x432230
00007d0bb21d35a4  movups [r13+rax*1], xmm1
00007d0bb21d35aa  mov eax, [r15+0x108]
00007d0bb21d35b1  sahf
00007d0bb21d35b2  jnz 0x00007D0BB21D35E4
00007d0bb21d35b4  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d35bc  jz 0x00007D0BB21DEAE0
00007d0bb21d35c2  nop [rax+rax*1], ax
00007d0bb21d35cb  nop [rax+rax*1], eax
00007d0bb21d35d3  mov eax, 0x4106D0
00007d0bb21d35d8  mov [r15+0x100], rax
00007d0bb21d35df  jmp 0x00007D0BB1FFE110
00007d0bb21d35e4  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d35ec  jz 0x00007D0BB21D89C0
00007d0bb21d35f2  nop [rax+rax*1], ax
00007d0bb21d35fb  nop [rax+rax*1], eax
00007d0bb21d3603  mov eax, 0x410504
00007d0bb21d3608  mov [r15+0x100], rax
00007d0bb21d360f  jmp 0x00007D0BB1FFE110
00007d0bb21d3614  int3
00007d0bb21d3615  call 0x00007D0BB20D64F0
00007d0bb21d361a  jmp 0x00007D0BB21D2311
00007d0bb21d361f  call 0x00007D0BB20E5820
00007d0bb21d3624  jmp 0x00007D0BB21D231E
00007d0bb21d3629  call 0x00007D0BB20E3320
00007d0bb21d362e  jmp 0x00007D0BB21D2332
00007d0bb21d3633  call 0x00007D0BB20E20A0
00007d0bb21d3638  jmp 0x00007D0BB21D233C
00007d0bb21d363d  call 0x00007D0BB2009D70
00007d0bb21d3642  jmp 0x00007D0BB21D234A
00007d0bb21d3647  call 0x00007D0BB20DFBC0
00007d0bb21d364c  jmp 0x00007D0BB21D2354
00007d0bb21d3651  call 0x00007D0BB20C4740
00007d0bb21d3656  jmp 0x00007D0BB21D2368
00007d0bb21d365b  call 0x00007D0BB20B5400
00007d0bb21d3660  jmp 0x00007D0BB21D2375
00007d0bb21d3665  call 0x00007D0BB20B52F0
00007d0bb21d366a  jmp 0x00007D0BB21D2382
00007d0bb21d366f  call 0x00007D0BB20C4620
00007d0bb21d3674  jmp 0x00007D0BB21D238F
00007d0bb21d3679  call 0x00007D0BB20BD750
00007d0bb21d367e  jmp 0x00007D0BB21D239C
00007d0bb21d3683  call 0x00007D0BB20BC4E0
00007d0bb21d3688  jmp 0x00007D0BB21D23A9
00007d0bb21d368d  call 0x00007D0BB20BB270
00007d0bb21d3692  jmp 0x00007D0BB21D23B6
00007d0bb21d3697  call 0x00007D0BB20BA000
00007d0bb21d369c  jmp 0x00007D0BB21D23C3
00007d0bb21d36a1  call 0x00007D0BB20C4740
00007d0bb21d36a6  jmp 0x00007D0BB21D23D0
00007d0bb21d36ab  call 0x00007D0BB20B5400
00007d0bb21d36b0  jmp 0x00007D0BB21D23DD
00007d0bb21d36b5  call 0x00007D0BB20B52F0
00007d0bb21d36ba  jmp 0x00007D0BB21D23EA
00007d0bb21d36bf  call 0x00007D0BB20C4620
00007d0bb21d36c4  jmp 0x00007D0BB21D23F7
00007d0bb21d36c9  call 0x00007D0BB20B8D90
00007d0bb21d36ce  jmp 0x00007D0BB21D2404
00007d0bb21d36d3  call 0x00007D0BB20B8A20
00007d0bb21d36d8  jmp 0x00007D0BB21D2411
00007d0bb21d36dd  call 0x00007D0BB20B77B0
00007d0bb21d36e2  jmp 0x00007D0BB21D241B
00007d0bb21d36e7  call 0x00007D0BB20B6550
00007d0bb21d36ec  jmp 0x00007D0BB21D2425
00007d0bb21d36f1  call 0x00007D0BB20B5400
00007d0bb21d36f6  jmp 0x00007D0BB21D2437
00007d0bb21d36fb  call 0x00007D0BB20C0FC0
00007d0bb21d3700  jmp 0x00007D0BB21D2441
00007d0bb21d3705  call 0x00007D0BB20B52F0
00007d0bb21d370a  jmp 0x00007D0BB21D244B
00007d0bb21d370f  call 0x00007D0BB20C0EA0
00007d0bb21d3714  jmp 0x00007D0BB21D2455
00007d0bb21d3719  call 0x00007D0BB20BFD50
00007d0bb21d371e  jmp 0x00007D0BB21D245F
00007d0bb21d3723  call 0x00007D0BB20B8EA0
00007d0bb21d3728  jmp 0x00007D0BB21D2469
00007d0bb21d372d  call 0x00007D0BB20BFC30
00007d0bb21d3732  jmp 0x00007D0BB21D2476
00007d0bb21d3737  call 0x00007D0BB20B8D90
00007d0bb21d373c  jmp 0x00007D0BB21D2483
00007d0bb21d3741  call 0x00007D0BB20B52F0
00007d0bb21d3746  jmp 0x00007D0BB21D2496
00007d0bb21d374b  call 0x00007D0BB20B52F0
00007d0bb21d3750  jmp 0x00007D0BB21D24A9
00007d0bb21d3755  call 0x00007D0BB20C0FC0
00007d0bb21d375a  jmp 0x00007D0BB21D24B6
00007d0bb21d375f  call 0x00007D0BB20C0FC0
00007d0bb21d3764  jmp 0x00007D0BB21D24C9
00007d0bb21d3769  call 0x00007D0BB20C0EA0
00007d0bb21d376e  jmp 0x00007D0BB21D24D6
00007d0bb21d3773  call 0x00007D0BB20B52F0
00007d0bb21d3778  jmp 0x00007D0BB21D24E9
00007d0bb21d377d  call 0x00007D0BB20B52F0
00007d0bb21d3782  jmp 0x00007D0BB21D24FC
00007d0bb21d3787  call 0x00007D0BB20B52F0
00007d0bb21d378c  jmp 0x00007D0BB21D250F
00007d0bb21d3791  call 0x00007D0BB20B52F0
00007d0bb21d3796  jmp 0x00007D0BB21D252A
00007d0bb21d379b  call 0x00007D0BB20B52F0
00007d0bb21d37a0  jmp 0x00007D0BB21D253D
00007d0bb21d37a5  call 0x00007D0BB20B5400
00007d0bb21d37aa  jmp 0x00007D0BB21D257E
00007d0bb21d37af  call 0x00007D0BB20C0FC0
00007d0bb21d37b4  jmp 0x00007D0BB21D258B
00007d0bb21d37b9  call 0x00007D0BB20B52F0
00007d0bb21d37be  jmp 0x00007D0BB21D2598
00007d0bb21d37c3  call 0x00007D0BB20C0EA0
00007d0bb21d37c8  jmp 0x00007D0BB21D25A5
00007d0bb21d37cd  call 0x00007D0BB1FFF540
00007d0bb21d37d2  jmp 0x00007D0BB21D25C3
00007d0bb21d37d7  call 0x00007D0BB2008C20
00007d0bb21d37dc  jmp 0x00007D0BB21D25CD
00007d0bb21d37e1  call 0x00007D0BB20E21C0
00007d0bb21d37e6  jmp 0x00007D0BB21D25D3
00007d0bb21d37eb  call 0x00007D0BB1FFF540
00007d0bb21d37f0  jmp 0x00007D0BB21D25E3
00007d0bb21d37f5  call 0x00007D0BB20C0370
00007d0bb21d37fa  jmp 0x00007D0BB21D2611
00007d0bb21d37ff  call 0x00007D0BB20BF100
00007d0bb21d3804  jmp 0x00007D0BB21D261A
00007d0bb21d3809  call 0x00007D0BB20C0370
00007d0bb21d380e  jmp 0x00007D0BB21D2674
00007d0bb21d3813  call 0x00007D0BB20BF100
00007d0bb21d3818  jmp 0x00007D0BB21D267D
00007d0bb21d381d  call 0x00007D0BB20C0370
00007d0bb21d3822  jmp 0x00007D0BB21D26C6
00007d0bb21d3827  call 0x00007D0BB20BF100
00007d0bb21d382c  jmp 0x00007D0BB21D26CF
00007d0bb21d3831  call 0x00007D0BB200B720
00007d0bb21d3836  jmp 0x00007D0BB21D2714
00007d0bb21d383b  call 0x00007D0BB20B47C0
00007d0bb21d3840  jmp 0x00007D0BB21D2727
00007d0bb21d3845  call 0x00007D0BB2008B00
00007d0bb21d384a  jmp 0x00007D0BB21D273E
00007d0bb21d384f  call 0x00007D0BB1FFF430
00007d0bb21d3854  jmp 0x00007D0BB21D2751
00007d0bb21d3859  call 0x00007D0BB1FFF430
00007d0bb21d385e  jmp 0x00007D0BB21D2764
00007d0bb21d3863  sub rsp, 0x08
00007d0bb21d3867  push rax
00007d0bb21d3868  push rcx
00007d0bb21d3869  push rdx
00007d0bb21d386a  push rdi
00007d0bb21d386b  push rsi
00007d0bb21d386c  push r8
00007d0bb21d386e  push r9
00007d0bb21d3870  push r10
00007d0bb21d3872  push r11
00007d0bb21d3874  sub rsp, 0xF0
00007d0bb21d387b  vmovaps [rsp], xmm0
00007d0bb21d3880  vmovaps [rsp+0x10], xmm2
00007d0bb21d3886  vmovaps [rsp+0x20], xmm3
00007d0bb21d388c  vmovaps [rsp+0x30], xmm4
00007d0bb21d3892  vmovaps [rsp+0x40], xmm5
00007d0bb21d3898  vmovaps [rsp+0x50], xmm6
00007d0bb21d389e  vmovaps [rsp+0x60], xmm7
00007d0bb21d38a4  vmovaps [rsp+0x70], xmm8
00007d0bb21d38aa  vmovaps [rsp+0x80], xmm9
00007d0bb21d38b3  vmovaps [rsp+0x90], xmm10
00007d0bb21d38bc  vmovaps [rsp+0xA0], xmm11
00007d0bb21d38c5  vmovaps [rsp+0xB0], xmm12
00007d0bb21d38ce  vmovaps [rsp+0xC0], xmm13
00007d0bb21d38d7  vmovaps [rsp+0xD0], xmm14
00007d0bb21d38e0  vmovaps [rsp+0xE0], xmm15
00007d0bb21d38e9  sub rsp, 0x30
00007d0bb21d38ed  movaps [rsp], xmm1
00007d0bb21d38f1  movaps [rsp+0x10], xmm12
00007d0bb21d38f7  movaps [rsp+0x20], xmm15
00007d0bb21d38fd  lea rdi, [rsp]
00007d0bb21d3901  mov esi, 0x00
00007d0bb21d3906  mov rax, 0x6392BBE7F530
00007d0bb21d3910  call rax
00007d0bb21d3912  movaps xmm1, [rsp]
00007d0bb21d3916  add rsp, 0x30
00007d0bb21d391a  vmovaps xmm0, [rsp]
00007d0bb21d391f  vmovaps xmm2, [rsp+0x10]
00007d0bb21d3925  vmovaps xmm3, [rsp+0x20]
00007d0bb21d392b  vmovaps xmm4, [rsp+0x30]
00007d0bb21d3931  vmovaps xmm5, [rsp+0x40]
00007d0bb21d3937  vmovaps xmm6, [rsp+0x50]
00007d0bb21d393d  vmovaps xmm7, [rsp+0x60]
00007d0bb21d3943  vmovaps xmm8, [rsp+0x70]
00007d0bb21d3949  vmovaps xmm9, [rsp+0x80]
00007d0bb21d3952  vmovaps xmm10, [rsp+0x90]
00007d0bb21d395b  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d3964  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d396d  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d3976  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d397f  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d3988  add rsp, 0xF0
00007d0bb21d398f  pop r11
00007d0bb21d3991  pop r10
00007d0bb21d3993  pop r9
00007d0bb21d3995  pop r8
00007d0bb21d3997  pop rsi
00007d0bb21d3998  pop rdi
00007d0bb21d3999  pop rdx
00007d0bb21d399a  pop rcx
00007d0bb21d399b  pop rax
00007d0bb21d399c  add rsp, 0x08
00007d0bb21d39a0  jmp 0x00007D0BB21D27B2
00007d0bb21d39a5  sub rsp, 0x08
00007d0bb21d39a9  push rax
00007d0bb21d39aa  push rcx
00007d0bb21d39ab  push rdx
00007d0bb21d39ac  push rdi
00007d0bb21d39ad  push rsi
00007d0bb21d39ae  push r8
00007d0bb21d39b0  push r9
00007d0bb21d39b2  push r10
00007d0bb21d39b4  push r11
00007d0bb21d39b6  sub rsp, 0xF0
00007d0bb21d39bd  vmovaps [rsp], xmm0
00007d0bb21d39c2  vmovaps [rsp+0x10], xmm1
00007d0bb21d39c8  vmovaps [rsp+0x20], xmm2
00007d0bb21d39ce  vmovaps [rsp+0x30], xmm3
00007d0bb21d39d4  vmovaps [rsp+0x40], xmm4
00007d0bb21d39da  vmovaps [rsp+0x50], xmm5
00007d0bb21d39e0  vmovaps [rsp+0x60], xmm6
00007d0bb21d39e6  vmovaps [rsp+0x70], xmm7
00007d0bb21d39ec  vmovaps [rsp+0x80], xmm8
00007d0bb21d39f5  vmovaps [rsp+0x90], xmm9
00007d0bb21d39fe  vmovaps [rsp+0xA0], xmm10
00007d0bb21d3a07  vmovaps [rsp+0xB0], xmm11
00007d0bb21d3a10  vmovaps [rsp+0xC0], xmm12
00007d0bb21d3a19  vmovaps [rsp+0xD0], xmm13
00007d0bb21d3a22  vmovaps [rsp+0xE0], xmm15
00007d0bb21d3a2b  sub rsp, 0x30
00007d0bb21d3a2f  movaps [rsp], xmm14
00007d0bb21d3a34  movaps [rsp+0x10], xmm1
00007d0bb21d3a39  movaps [rsp+0x20], xmm15
00007d0bb21d3a3f  lea rdi, [rsp]
00007d0bb21d3a43  mov esi, 0x00
00007d0bb21d3a48  mov rax, 0x6392BBE7F530
00007d0bb21d3a52  call rax
00007d0bb21d3a54  movaps xmm14, [rsp]
00007d0bb21d3a59  add rsp, 0x30
00007d0bb21d3a5d  vmovaps xmm0, [rsp]
00007d0bb21d3a62  vmovaps xmm1, [rsp+0x10]
00007d0bb21d3a68  vmovaps xmm2, [rsp+0x20]
00007d0bb21d3a6e  vmovaps xmm3, [rsp+0x30]
00007d0bb21d3a74  vmovaps xmm4, [rsp+0x40]
00007d0bb21d3a7a  vmovaps xmm5, [rsp+0x50]
00007d0bb21d3a80  vmovaps xmm6, [rsp+0x60]
00007d0bb21d3a86  vmovaps xmm7, [rsp+0x70]
00007d0bb21d3a8c  vmovaps xmm8, [rsp+0x80]
00007d0bb21d3a95  vmovaps xmm9, [rsp+0x90]
00007d0bb21d3a9e  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d3aa7  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d3ab0  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d3ab9  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d3ac2  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d3acb  add rsp, 0xF0
00007d0bb21d3ad2  pop r11
00007d0bb21d3ad4  pop r10
00007d0bb21d3ad6  pop r9
00007d0bb21d3ad8  pop r8
00007d0bb21d3ada  pop rsi
00007d0bb21d3adb  pop rdi
00007d0bb21d3adc  pop rdx
00007d0bb21d3add  pop rcx
00007d0bb21d3ade  pop rax
00007d0bb21d3adf  add rsp, 0x08
00007d0bb21d3ae3  jmp 0x00007D0BB21D2800
00007d0bb21d3ae8  sub rsp, 0x08
00007d0bb21d3aec  push rax
00007d0bb21d3aed  push rcx
00007d0bb21d3aee  push rdx
00007d0bb21d3aef  push rdi
00007d0bb21d3af0  push rsi
00007d0bb21d3af1  push r8
00007d0bb21d3af3  push r9
00007d0bb21d3af5  push r10
00007d0bb21d3af7  push r11
00007d0bb21d3af9  sub rsp, 0xF0
00007d0bb21d3b00  vmovaps [rsp], xmm0
00007d0bb21d3b05  vmovaps [rsp+0x10], xmm1
00007d0bb21d3b0b  vmovaps [rsp+0x20], xmm2
00007d0bb21d3b11  vmovaps [rsp+0x30], xmm3
00007d0bb21d3b17  vmovaps [rsp+0x40], xmm4
00007d0bb21d3b1d  vmovaps [rsp+0x50], xmm5
00007d0bb21d3b23  vmovaps [rsp+0x60], xmm6
00007d0bb21d3b29  vmovaps [rsp+0x70], xmm7
00007d0bb21d3b2f  vmovaps [rsp+0x80], xmm8
00007d0bb21d3b38  vmovaps [rsp+0x90], xmm9
00007d0bb21d3b41  vmovaps [rsp+0xA0], xmm10
00007d0bb21d3b4a  vmovaps [rsp+0xB0], xmm11
00007d0bb21d3b53  vmovaps [rsp+0xC0], xmm12
00007d0bb21d3b5c  vmovaps [rsp+0xD0], xmm13
00007d0bb21d3b65  vmovaps [rsp+0xE0], xmm14
00007d0bb21d3b6e  sub rsp, 0x30
00007d0bb21d3b72  movaps [rsp], xmm15
00007d0bb21d3b77  movaps [rsp+0x10], xmm12
00007d0bb21d3b7d  movaps [rsp+0x20], xmm13
00007d0bb21d3b83  lea rdi, [rsp]
00007d0bb21d3b87  mov esi, 0x00
00007d0bb21d3b8c  mov rax, 0x6392BBE7F530
00007d0bb21d3b96  call rax
00007d0bb21d3b98  movaps xmm15, [rsp]
00007d0bb21d3b9d  add rsp, 0x30
00007d0bb21d3ba1  vmovaps xmm0, [rsp]
00007d0bb21d3ba6  vmovaps xmm1, [rsp+0x10]
00007d0bb21d3bac  vmovaps xmm2, [rsp+0x20]
00007d0bb21d3bb2  vmovaps xmm3, [rsp+0x30]
00007d0bb21d3bb8  vmovaps xmm4, [rsp+0x40]
00007d0bb21d3bbe  vmovaps xmm5, [rsp+0x50]
00007d0bb21d3bc4  vmovaps xmm6, [rsp+0x60]
00007d0bb21d3bca  vmovaps xmm7, [rsp+0x70]
00007d0bb21d3bd0  vmovaps xmm8, [rsp+0x80]
00007d0bb21d3bd9  vmovaps xmm9, [rsp+0x90]
00007d0bb21d3be2  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d3beb  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d3bf4  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d3bfd  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d3c06  vmovaps xmm14, [rsp+0xE0]
00007d0bb21d3c0f  add rsp, 0xF0
00007d0bb21d3c16  pop r11
00007d0bb21d3c18  pop r10
00007d0bb21d3c1a  pop r9
00007d0bb21d3c1c  pop r8
00007d0bb21d3c1e  pop rsi
00007d0bb21d3c1f  pop rdi
00007d0bb21d3c20  pop rdx
00007d0bb21d3c21  pop rcx
00007d0bb21d3c22  pop rax
00007d0bb21d3c23  add rsp, 0x08
00007d0bb21d3c27  jmp 0x00007D0BB21D2835
00007d0bb21d3c2c  sub rsp, 0x08
00007d0bb21d3c30  push rax
00007d0bb21d3c31  push rcx
00007d0bb21d3c32  push rdx
00007d0bb21d3c33  push rdi
00007d0bb21d3c34  push rsi
00007d0bb21d3c35  push r8
00007d0bb21d3c37  push r9
00007d0bb21d3c39  push r10
00007d0bb21d3c3b  push r11
00007d0bb21d3c3d  sub rsp, 0xF0
00007d0bb21d3c44  vmovaps [rsp], xmm0
00007d0bb21d3c49  vmovaps [rsp+0x10], xmm2
00007d0bb21d3c4f  vmovaps [rsp+0x20], xmm3
00007d0bb21d3c55  vmovaps [rsp+0x30], xmm4
00007d0bb21d3c5b  vmovaps [rsp+0x40], xmm5
00007d0bb21d3c61  vmovaps [rsp+0x50], xmm6
00007d0bb21d3c67  vmovaps [rsp+0x60], xmm7
00007d0bb21d3c6d  vmovaps [rsp+0x70], xmm8
00007d0bb21d3c73  vmovaps [rsp+0x80], xmm9
00007d0bb21d3c7c  vmovaps [rsp+0x90], xmm10
00007d0bb21d3c85  vmovaps [rsp+0xA0], xmm11
00007d0bb21d3c8e  vmovaps [rsp+0xB0], xmm12
00007d0bb21d3c97  vmovaps [rsp+0xC0], xmm13
00007d0bb21d3ca0  vmovaps [rsp+0xD0], xmm14
00007d0bb21d3ca9  vmovaps [rsp+0xE0], xmm15
00007d0bb21d3cb2  sub rsp, 0x30
00007d0bb21d3cb6  movaps [rsp], xmm1
00007d0bb21d3cba  movaps [rsp+0x10], xmm12
00007d0bb21d3cc0  movaps [rsp+0x20], xmm10
00007d0bb21d3cc6  lea rdi, [rsp]
00007d0bb21d3cca  mov esi, 0x00
00007d0bb21d3ccf  mov rax, 0x6392BBE7F530
00007d0bb21d3cd9  call rax
00007d0bb21d3cdb  movaps xmm1, [rsp]
00007d0bb21d3cdf  add rsp, 0x30
00007d0bb21d3ce3  vmovaps xmm0, [rsp]
00007d0bb21d3ce8  vmovaps xmm2, [rsp+0x10]
00007d0bb21d3cee  vmovaps xmm3, [rsp+0x20]
00007d0bb21d3cf4  vmovaps xmm4, [rsp+0x30]
00007d0bb21d3cfa  vmovaps xmm5, [rsp+0x40]
00007d0bb21d3d00  vmovaps xmm6, [rsp+0x50]
00007d0bb21d3d06  vmovaps xmm7, [rsp+0x60]
00007d0bb21d3d0c  vmovaps xmm8, [rsp+0x70]
00007d0bb21d3d12  vmovaps xmm9, [rsp+0x80]
00007d0bb21d3d1b  vmovaps xmm10, [rsp+0x90]
00007d0bb21d3d24  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d3d2d  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d3d36  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d3d3f  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d3d48  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d3d51  add rsp, 0xF0
00007d0bb21d3d58  pop r11
00007d0bb21d3d5a  pop r10
00007d0bb21d3d5c  pop r9
00007d0bb21d3d5e  pop r8
00007d0bb21d3d60  pop rsi
00007d0bb21d3d61  pop rdi
00007d0bb21d3d62  pop rdx
00007d0bb21d3d63  pop rcx
00007d0bb21d3d64  pop rax
00007d0bb21d3d65  add rsp, 0x08
00007d0bb21d3d69  jmp 0x00007D0BB21D284F
00007d0bb21d3d6e  sub rsp, 0x08
00007d0bb21d3d72  push rax
00007d0bb21d3d73  push rcx
00007d0bb21d3d74  push rdx
00007d0bb21d3d75  push rdi
00007d0bb21d3d76  push rsi
00007d0bb21d3d77  push r8
00007d0bb21d3d79  push r9
00007d0bb21d3d7b  push r10
00007d0bb21d3d7d  push r11
00007d0bb21d3d7f  sub rsp, 0xF0
00007d0bb21d3d86  vmovaps [rsp], xmm0
00007d0bb21d3d8b  vmovaps [rsp+0x10], xmm1
00007d0bb21d3d91  vmovaps [rsp+0x20], xmm2
00007d0bb21d3d97  vmovaps [rsp+0x30], xmm3
00007d0bb21d3d9d  vmovaps [rsp+0x40], xmm4
00007d0bb21d3da3  vmovaps [rsp+0x50], xmm5
00007d0bb21d3da9  vmovaps [rsp+0x60], xmm6
00007d0bb21d3daf  vmovaps [rsp+0x70], xmm7
00007d0bb21d3db5  vmovaps [rsp+0x80], xmm8
00007d0bb21d3dbe  vmovaps [rsp+0x90], xmm9
00007d0bb21d3dc7  vmovaps [rsp+0xA0], xmm10
00007d0bb21d3dd0  vmovaps [rsp+0xB0], xmm11
00007d0bb21d3dd9  vmovaps [rsp+0xC0], xmm12
00007d0bb21d3de2  vmovaps [rsp+0xD0], xmm14
00007d0bb21d3deb  vmovaps [rsp+0xE0], xmm15
00007d0bb21d3df4  sub rsp, 0x30
00007d0bb21d3df8  movaps [rsp], xmm13
00007d0bb21d3dfd  movaps [rsp+0x10], xmm12
00007d0bb21d3e03  movaps [rsp+0x20], xmm2
00007d0bb21d3e08  lea rdi, [rsp]
00007d0bb21d3e0c  mov esi, 0x00
00007d0bb21d3e11  mov rax, 0x6392BBE7F530
00007d0bb21d3e1b  call rax
00007d0bb21d3e1d  movaps xmm13, [rsp]
00007d0bb21d3e22  add rsp, 0x30
00007d0bb21d3e26  vmovaps xmm0, [rsp]
00007d0bb21d3e2b  vmovaps xmm1, [rsp+0x10]
00007d0bb21d3e31  vmovaps xmm2, [rsp+0x20]
00007d0bb21d3e37  vmovaps xmm3, [rsp+0x30]
00007d0bb21d3e3d  vmovaps xmm4, [rsp+0x40]
00007d0bb21d3e43  vmovaps xmm5, [rsp+0x50]
00007d0bb21d3e49  vmovaps xmm6, [rsp+0x60]
00007d0bb21d3e4f  vmovaps xmm7, [rsp+0x70]
00007d0bb21d3e55  vmovaps xmm8, [rsp+0x80]
00007d0bb21d3e5e  vmovaps xmm9, [rsp+0x90]
00007d0bb21d3e67  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d3e70  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d3e79  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d3e82  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d3e8b  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d3e94  add rsp, 0xF0
00007d0bb21d3e9b  pop r11
00007d0bb21d3e9d  pop r10
00007d0bb21d3e9f  pop r9
00007d0bb21d3ea1  pop r8
00007d0bb21d3ea3  pop rsi
00007d0bb21d3ea4  pop rdi
00007d0bb21d3ea5  pop rdx
00007d0bb21d3ea6  pop rcx
00007d0bb21d3ea7  pop rax
00007d0bb21d3ea8  add rsp, 0x08
00007d0bb21d3eac  jmp 0x00007D0BB21D286A
00007d0bb21d3eb1  sub rsp, 0x08
00007d0bb21d3eb5  push rax
00007d0bb21d3eb6  push rcx
00007d0bb21d3eb7  push rdx
00007d0bb21d3eb8  push rdi
00007d0bb21d3eb9  push rsi
00007d0bb21d3eba  push r8
00007d0bb21d3ebc  push r9
00007d0bb21d3ebe  push r10
00007d0bb21d3ec0  push r11
00007d0bb21d3ec2  sub rsp, 0xF0
00007d0bb21d3ec9  vmovaps [rsp], xmm0
00007d0bb21d3ece  vmovaps [rsp+0x10], xmm2
00007d0bb21d3ed4  vmovaps [rsp+0x20], xmm3
00007d0bb21d3eda  vmovaps [rsp+0x30], xmm4
00007d0bb21d3ee0  vmovaps [rsp+0x40], xmm5
00007d0bb21d3ee6  vmovaps [rsp+0x50], xmm6
00007d0bb21d3eec  vmovaps [rsp+0x60], xmm7
00007d0bb21d3ef2  vmovaps [rsp+0x70], xmm8
00007d0bb21d3ef8  vmovaps [rsp+0x80], xmm9
00007d0bb21d3f01  vmovaps [rsp+0x90], xmm10
00007d0bb21d3f0a  vmovaps [rsp+0xA0], xmm11
00007d0bb21d3f13  vmovaps [rsp+0xB0], xmm12
00007d0bb21d3f1c  vmovaps [rsp+0xC0], xmm13
00007d0bb21d3f25  vmovaps [rsp+0xD0], xmm14
00007d0bb21d3f2e  vmovaps [rsp+0xE0], xmm15
00007d0bb21d3f37  sub rsp, 0x30
00007d0bb21d3f3b  movaps [rsp], xmm1
00007d0bb21d3f3f  movaps [rsp+0x10], xmm10
00007d0bb21d3f45  movaps [rsp+0x20], xmm2
00007d0bb21d3f4a  lea rdi, [rsp]
00007d0bb21d3f4e  mov esi, 0x00
00007d0bb21d3f53  mov rax, 0x6392BBE7F530
00007d0bb21d3f5d  call rax
00007d0bb21d3f5f  movaps xmm1, [rsp]
00007d0bb21d3f63  add rsp, 0x30
00007d0bb21d3f67  vmovaps xmm0, [rsp]
00007d0bb21d3f6c  vmovaps xmm2, [rsp+0x10]
00007d0bb21d3f72  vmovaps xmm3, [rsp+0x20]
00007d0bb21d3f78  vmovaps xmm4, [rsp+0x30]
00007d0bb21d3f7e  vmovaps xmm5, [rsp+0x40]
00007d0bb21d3f84  vmovaps xmm6, [rsp+0x50]
00007d0bb21d3f8a  vmovaps xmm7, [rsp+0x60]
00007d0bb21d3f90  vmovaps xmm8, [rsp+0x70]
00007d0bb21d3f96  vmovaps xmm9, [rsp+0x80]
00007d0bb21d3f9f  vmovaps xmm10, [rsp+0x90]
00007d0bb21d3fa8  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d3fb1  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d3fba  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d3fc3  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d3fcc  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d3fd5  add rsp, 0xF0
00007d0bb21d3fdc  pop r11
00007d0bb21d3fde  pop r10
00007d0bb21d3fe0  pop r9
00007d0bb21d3fe2  pop r8
00007d0bb21d3fe4  pop rsi
00007d0bb21d3fe5  pop rdi
00007d0bb21d3fe6  pop rdx
00007d0bb21d3fe7  pop rcx
00007d0bb21d3fe8  pop rax
00007d0bb21d3fe9  add rsp, 0x08
00007d0bb21d3fed  jmp 0x00007D0BB21D28D2
00007d0bb21d3ff2  sub rsp, 0x08
00007d0bb21d3ff6  push rax
00007d0bb21d3ff7  push rcx
00007d0bb21d3ff8  push rdx
00007d0bb21d3ff9  push rdi
00007d0bb21d3ffa  push rsi
00007d0bb21d3ffb  push r8
00007d0bb21d3ffd  push r9
00007d0bb21d3fff  push r10
00007d0bb21d4001  push r11
00007d0bb21d4003  sub rsp, 0xF0
00007d0bb21d400a  vmovaps [rsp], xmm0
00007d0bb21d400f  vmovaps [rsp+0x10], xmm1
00007d0bb21d4015  vmovaps [rsp+0x20], xmm2
00007d0bb21d401b  vmovaps [rsp+0x30], xmm3
00007d0bb21d4021  vmovaps [rsp+0x40], xmm4
00007d0bb21d4027  vmovaps [rsp+0x50], xmm5
00007d0bb21d402d  vmovaps [rsp+0x60], xmm6
00007d0bb21d4033  vmovaps [rsp+0x70], xmm7
00007d0bb21d4039  vmovaps [rsp+0x80], xmm8
00007d0bb21d4042  vmovaps [rsp+0x90], xmm9
00007d0bb21d404b  vmovaps [rsp+0xA0], xmm10
00007d0bb21d4054  vmovaps [rsp+0xB0], xmm11
00007d0bb21d405d  vmovaps [rsp+0xC0], xmm12
00007d0bb21d4066  vmovaps [rsp+0xD0], xmm13
00007d0bb21d406f  vmovaps [rsp+0xE0], xmm14
00007d0bb21d4078  sub rsp, 0x30
00007d0bb21d407c  movaps [rsp], xmm15
00007d0bb21d4081  movaps [rsp+0x10], xmm10
00007d0bb21d4087  movaps [rsp+0x20], xmm2
00007d0bb21d408c  lea rdi, [rsp]
00007d0bb21d4090  mov esi, 0x00
00007d0bb21d4095  mov rax, 0x6392BBE7F530
00007d0bb21d409f  call rax
00007d0bb21d40a1  movaps xmm15, [rsp]
00007d0bb21d40a6  add rsp, 0x30
00007d0bb21d40aa  vmovaps xmm0, [rsp]
00007d0bb21d40af  vmovaps xmm1, [rsp+0x10]
00007d0bb21d40b5  vmovaps xmm2, [rsp+0x20]
00007d0bb21d40bb  vmovaps xmm3, [rsp+0x30]
00007d0bb21d40c1  vmovaps xmm4, [rsp+0x40]
00007d0bb21d40c7  vmovaps xmm5, [rsp+0x50]
00007d0bb21d40cd  vmovaps xmm6, [rsp+0x60]
00007d0bb21d40d3  vmovaps xmm7, [rsp+0x70]
00007d0bb21d40d9  vmovaps xmm8, [rsp+0x80]
00007d0bb21d40e2  vmovaps xmm9, [rsp+0x90]
00007d0bb21d40eb  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d40f4  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d40fd  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d4106  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d410f  vmovaps xmm14, [rsp+0xE0]
00007d0bb21d4118  add rsp, 0xF0
00007d0bb21d411f  pop r11
00007d0bb21d4121  pop r10
00007d0bb21d4123  pop r9
00007d0bb21d4125  pop r8
00007d0bb21d4127  pop rsi
00007d0bb21d4128  pop rdi
00007d0bb21d4129  pop rdx
00007d0bb21d412a  pop rcx
00007d0bb21d412b  pop rax
00007d0bb21d412c  add rsp, 0x08
00007d0bb21d4130  jmp 0x00007D0BB21D2924
00007d0bb21d4135  sub rsp, 0x08
00007d0bb21d4139  push rax
00007d0bb21d413a  push rcx
00007d0bb21d413b  push rdx
00007d0bb21d413c  push rdi
00007d0bb21d413d  push rsi
00007d0bb21d413e  push r8
00007d0bb21d4140  push r9
00007d0bb21d4142  push r10
00007d0bb21d4144  push r11
00007d0bb21d4146  sub rsp, 0xF0
00007d0bb21d414d  vmovaps [rsp], xmm0
00007d0bb21d4152  vmovaps [rsp+0x10], xmm2
00007d0bb21d4158  vmovaps [rsp+0x20], xmm3
00007d0bb21d415e  vmovaps [rsp+0x30], xmm4
00007d0bb21d4164  vmovaps [rsp+0x40], xmm5
00007d0bb21d416a  vmovaps [rsp+0x50], xmm6
00007d0bb21d4170  vmovaps [rsp+0x60], xmm7
00007d0bb21d4176  vmovaps [rsp+0x70], xmm8
00007d0bb21d417c  vmovaps [rsp+0x80], xmm9
00007d0bb21d4185  vmovaps [rsp+0x90], xmm10
00007d0bb21d418e  vmovaps [rsp+0xA0], xmm11
00007d0bb21d4197  vmovaps [rsp+0xB0], xmm12
00007d0bb21d41a0  vmovaps [rsp+0xC0], xmm13
00007d0bb21d41a9  vmovaps [rsp+0xD0], xmm14
00007d0bb21d41b2  vmovaps [rsp+0xE0], xmm15
00007d0bb21d41bb  sub rsp, 0x30
00007d0bb21d41bf  movaps [rsp], xmm1
00007d0bb21d41c3  movaps [rsp+0x10], xmm10
00007d0bb21d41c9  movaps [rsp+0x20], xmm15
00007d0bb21d41cf  lea rdi, [rsp]
00007d0bb21d41d3  mov esi, 0x00
00007d0bb21d41d8  mov rax, 0x6392BBE7F530
00007d0bb21d41e2  call rax
00007d0bb21d41e4  movaps xmm1, [rsp]
00007d0bb21d41e8  add rsp, 0x30
00007d0bb21d41ec  vmovaps xmm0, [rsp]
00007d0bb21d41f1  vmovaps xmm2, [rsp+0x10]
00007d0bb21d41f7  vmovaps xmm3, [rsp+0x20]
00007d0bb21d41fd  vmovaps xmm4, [rsp+0x30]
00007d0bb21d4203  vmovaps xmm5, [rsp+0x40]
00007d0bb21d4209  vmovaps xmm6, [rsp+0x50]
00007d0bb21d420f  vmovaps xmm7, [rsp+0x60]
00007d0bb21d4215  vmovaps xmm8, [rsp+0x70]
00007d0bb21d421b  vmovaps xmm9, [rsp+0x80]
00007d0bb21d4224  vmovaps xmm10, [rsp+0x90]
00007d0bb21d422d  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d4236  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d423f  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d4248  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d4251  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d425a  add rsp, 0xF0
00007d0bb21d4261  pop r11
00007d0bb21d4263  pop r10
00007d0bb21d4265  pop r9
00007d0bb21d4267  pop r8
00007d0bb21d4269  pop rsi
00007d0bb21d426a  pop rdi
00007d0bb21d426b  pop rdx
00007d0bb21d426c  pop rcx
00007d0bb21d426d  pop rax
00007d0bb21d426e  add rsp, 0x08
00007d0bb21d4272  jmp 0x00007D0BB21D2962
00007d0bb21d4277  sub rsp, 0x08
00007d0bb21d427b  push rax
00007d0bb21d427c  push rcx
00007d0bb21d427d  push rdx
00007d0bb21d427e  push rdi
00007d0bb21d427f  push rsi
00007d0bb21d4280  push r8
00007d0bb21d4282  push r9
00007d0bb21d4284  push r10
00007d0bb21d4286  push r11
00007d0bb21d4288  sub rsp, 0xF0
00007d0bb21d428f  vmovaps [rsp], xmm0
00007d0bb21d4294  vmovaps [rsp+0x10], xmm1
00007d0bb21d429a  vmovaps [rsp+0x20], xmm2
00007d0bb21d42a0  vmovaps [rsp+0x30], xmm3
00007d0bb21d42a6  vmovaps [rsp+0x40], xmm4
00007d0bb21d42ac  vmovaps [rsp+0x50], xmm5
00007d0bb21d42b2  vmovaps [rsp+0x60], xmm6
00007d0bb21d42b8  vmovaps [rsp+0x70], xmm7
00007d0bb21d42be  vmovaps [rsp+0x80], xmm8
00007d0bb21d42c7  vmovaps [rsp+0x90], xmm9
00007d0bb21d42d0  vmovaps [rsp+0xA0], xmm10
00007d0bb21d42d9  vmovaps [rsp+0xB0], xmm11
00007d0bb21d42e2  vmovaps [rsp+0xC0], xmm12
00007d0bb21d42eb  vmovaps [rsp+0xD0], xmm13
00007d0bb21d42f4  vmovaps [rsp+0xE0], xmm15
00007d0bb21d42fd  sub rsp, 0x30
00007d0bb21d4301  movaps [rsp], xmm14
00007d0bb21d4306  movaps [rsp+0x10], xmm10
00007d0bb21d430c  movaps [rsp+0x20], xmm15
00007d0bb21d4312  lea rdi, [rsp]
00007d0bb21d4316  mov esi, 0x00
00007d0bb21d431b  mov rax, 0x6392BBE7F530
00007d0bb21d4325  call rax
00007d0bb21d4327  movaps xmm14, [rsp]
00007d0bb21d432c  add rsp, 0x30
00007d0bb21d4330  vmovaps xmm0, [rsp]
00007d0bb21d4335  vmovaps xmm1, [rsp+0x10]
00007d0bb21d433b  vmovaps xmm2, [rsp+0x20]
00007d0bb21d4341  vmovaps xmm3, [rsp+0x30]
00007d0bb21d4347  vmovaps xmm4, [rsp+0x40]
00007d0bb21d434d  vmovaps xmm5, [rsp+0x50]
00007d0bb21d4353  vmovaps xmm6, [rsp+0x60]
00007d0bb21d4359  vmovaps xmm7, [rsp+0x70]
00007d0bb21d435f  vmovaps xmm8, [rsp+0x80]
00007d0bb21d4368  vmovaps xmm9, [rsp+0x90]
00007d0bb21d4371  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d437a  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d4383  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d438c  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d4395  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d439e  add rsp, 0xF0
00007d0bb21d43a5  pop r11
00007d0bb21d43a7  pop r10
00007d0bb21d43a9  pop r9
00007d0bb21d43ab  pop r8
00007d0bb21d43ad  pop rsi
00007d0bb21d43ae  pop rdi
00007d0bb21d43af  pop rdx
00007d0bb21d43b0  pop rcx
00007d0bb21d43b1  pop rax
00007d0bb21d43b2  add rsp, 0x08
00007d0bb21d43b6  jmp 0x00007D0BB21D298E
00007d0bb21d43bb  call 0x00007D0BB1FFF430
00007d0bb21d43c0  jmp 0x00007D0BB21D2A1E
00007d0bb21d43c5  call 0x00007D0BB1FFF430
00007d0bb21d43ca  jmp 0x00007D0BB21D2A31
00007d0bb21d43cf  sub rsp, 0x08
00007d0bb21d43d3  push rax
00007d0bb21d43d4  push rcx
00007d0bb21d43d5  push rdx
00007d0bb21d43d6  push rdi
00007d0bb21d43d7  push rsi
00007d0bb21d43d8  push r8
00007d0bb21d43da  push r9
00007d0bb21d43dc  push r10
00007d0bb21d43de  push r11
00007d0bb21d43e0  sub rsp, 0xF0
00007d0bb21d43e7  vmovaps [rsp], xmm0
00007d0bb21d43ec  vmovaps [rsp+0x10], xmm2
00007d0bb21d43f2  vmovaps [rsp+0x20], xmm3
00007d0bb21d43f8  vmovaps [rsp+0x30], xmm4
00007d0bb21d43fe  vmovaps [rsp+0x40], xmm5
00007d0bb21d4404  vmovaps [rsp+0x50], xmm6
00007d0bb21d440a  vmovaps [rsp+0x60], xmm7
00007d0bb21d4410  vmovaps [rsp+0x70], xmm8
00007d0bb21d4416  vmovaps [rsp+0x80], xmm9
00007d0bb21d441f  vmovaps [rsp+0x90], xmm10
00007d0bb21d4428  vmovaps [rsp+0xA0], xmm11
00007d0bb21d4431  vmovaps [rsp+0xB0], xmm12
00007d0bb21d443a  vmovaps [rsp+0xC0], xmm13
00007d0bb21d4443  vmovaps [rsp+0xD0], xmm14
00007d0bb21d444c  vmovaps [rsp+0xE0], xmm15
00007d0bb21d4455  sub rsp, 0x30
00007d0bb21d4459  movaps [rsp], xmm1
00007d0bb21d445d  movaps [rsp+0x10], xmm13
00007d0bb21d4463  movaps [rsp+0x20], xmm2
00007d0bb21d4468  lea rdi, [rsp]
00007d0bb21d446c  mov esi, 0x00
00007d0bb21d4471  mov rax, 0x6392BBE7F530
00007d0bb21d447b  call rax
00007d0bb21d447d  movaps xmm1, [rsp]
00007d0bb21d4481  add rsp, 0x30
00007d0bb21d4485  vmovaps xmm0, [rsp]
00007d0bb21d448a  vmovaps xmm2, [rsp+0x10]
00007d0bb21d4490  vmovaps xmm3, [rsp+0x20]
00007d0bb21d4496  vmovaps xmm4, [rsp+0x30]
00007d0bb21d449c  vmovaps xmm5, [rsp+0x40]
00007d0bb21d44a2  vmovaps xmm6, [rsp+0x50]
00007d0bb21d44a8  vmovaps xmm7, [rsp+0x60]
00007d0bb21d44ae  vmovaps xmm8, [rsp+0x70]
00007d0bb21d44b4  vmovaps xmm9, [rsp+0x80]
00007d0bb21d44bd  vmovaps xmm10, [rsp+0x90]
00007d0bb21d44c6  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d44cf  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d44d8  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d44e1  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d44ea  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d44f3  add rsp, 0xF0
00007d0bb21d44fa  pop r11
00007d0bb21d44fc  pop r10
00007d0bb21d44fe  pop r9
00007d0bb21d4500  pop r8
00007d0bb21d4502  pop rsi
00007d0bb21d4503  pop rdi
00007d0bb21d4504  pop rdx
00007d0bb21d4505  pop rcx
00007d0bb21d4506  pop rax
00007d0bb21d4507  add rsp, 0x08
00007d0bb21d450b  jmp 0x00007D0BB21D2A5C
00007d0bb21d4510  call 0x00007D0BB200E760
00007d0bb21d4515  jmp 0x00007D0BB21D2A69
00007d0bb21d451a  sub rsp, 0x08
00007d0bb21d451e  push rax
00007d0bb21d451f  push rcx
00007d0bb21d4520  push rdx
00007d0bb21d4521  push rdi
00007d0bb21d4522  push rsi
00007d0bb21d4523  push r8
00007d0bb21d4525  push r9
00007d0bb21d4527  push r10
00007d0bb21d4529  push r11
00007d0bb21d452b  sub rsp, 0xF0
00007d0bb21d4532  vmovaps [rsp], xmm0
00007d0bb21d4537  vmovaps [rsp+0x10], xmm1
00007d0bb21d453d  vmovaps [rsp+0x20], xmm2
00007d0bb21d4543  vmovaps [rsp+0x30], xmm3
00007d0bb21d4549  vmovaps [rsp+0x40], xmm4
00007d0bb21d454f  vmovaps [rsp+0x50], xmm5
00007d0bb21d4555  vmovaps [rsp+0x60], xmm6
00007d0bb21d455b  vmovaps [rsp+0x70], xmm7
00007d0bb21d4561  vmovaps [rsp+0x80], xmm8
00007d0bb21d456a  vmovaps [rsp+0x90], xmm9
00007d0bb21d4573  vmovaps [rsp+0xA0], xmm10
00007d0bb21d457c  vmovaps [rsp+0xB0], xmm11
00007d0bb21d4585  vmovaps [rsp+0xC0], xmm12
00007d0bb21d458e  vmovaps [rsp+0xD0], xmm14
00007d0bb21d4597  vmovaps [rsp+0xE0], xmm15
00007d0bb21d45a0  sub rsp, 0x30
00007d0bb21d45a4  movaps [rsp], xmm13
00007d0bb21d45a9  movaps [rsp+0x10], xmm2
00007d0bb21d45ae  movaps [rsp+0x20], xmm1
00007d0bb21d45b3  lea rdi, [rsp]
00007d0bb21d45b7  mov esi, 0x00
00007d0bb21d45bc  mov rax, 0x6392BBE7F530
00007d0bb21d45c6  call rax
00007d0bb21d45c8  movaps xmm13, [rsp]
00007d0bb21d45cd  add rsp, 0x30
00007d0bb21d45d1  vmovaps xmm0, [rsp]
00007d0bb21d45d6  vmovaps xmm1, [rsp+0x10]
00007d0bb21d45dc  vmovaps xmm2, [rsp+0x20]
00007d0bb21d45e2  vmovaps xmm3, [rsp+0x30]
00007d0bb21d45e8  vmovaps xmm4, [rsp+0x40]
00007d0bb21d45ee  vmovaps xmm5, [rsp+0x50]
00007d0bb21d45f4  vmovaps xmm6, [rsp+0x60]
00007d0bb21d45fa  vmovaps xmm7, [rsp+0x70]
00007d0bb21d4600  vmovaps xmm8, [rsp+0x80]
00007d0bb21d4609  vmovaps xmm9, [rsp+0x90]
00007d0bb21d4612  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d461b  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d4624  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d462d  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d4636  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d463f  add rsp, 0xF0
00007d0bb21d4646  pop r11
00007d0bb21d4648  pop r10
00007d0bb21d464a  pop r9
00007d0bb21d464c  pop r8
00007d0bb21d464e  pop rsi
00007d0bb21d464f  pop rdi
00007d0bb21d4650  pop rdx
00007d0bb21d4651  pop rcx
00007d0bb21d4652  pop rax
00007d0bb21d4653  add rsp, 0x08
00007d0bb21d4657  jmp 0x00007D0BB21D2AA8
00007d0bb21d465c  sub rsp, 0x08
00007d0bb21d4660  push rax
00007d0bb21d4661  push rcx
00007d0bb21d4662  push rdx
00007d0bb21d4663  push rdi
00007d0bb21d4664  push rsi
00007d0bb21d4665  push r8
00007d0bb21d4667  push r9
00007d0bb21d4669  push r10
00007d0bb21d466b  push r11
00007d0bb21d466d  sub rsp, 0xF0
00007d0bb21d4674  vmovaps [rsp], xmm0
00007d0bb21d4679  vmovaps [rsp+0x10], xmm2
00007d0bb21d467f  vmovaps [rsp+0x20], xmm3
00007d0bb21d4685  vmovaps [rsp+0x30], xmm4
00007d0bb21d468b  vmovaps [rsp+0x40], xmm5
00007d0bb21d4691  vmovaps [rsp+0x50], xmm6
00007d0bb21d4697  vmovaps [rsp+0x60], xmm7
00007d0bb21d469d  vmovaps [rsp+0x70], xmm8
00007d0bb21d46a3  vmovaps [rsp+0x80], xmm9
00007d0bb21d46ac  vmovaps [rsp+0x90], xmm10
00007d0bb21d46b5  vmovaps [rsp+0xA0], xmm11
00007d0bb21d46be  vmovaps [rsp+0xB0], xmm12
00007d0bb21d46c7  vmovaps [rsp+0xC0], xmm13
00007d0bb21d46d0  vmovaps [rsp+0xD0], xmm14
00007d0bb21d46d9  vmovaps [rsp+0xE0], xmm15
00007d0bb21d46e2  sub rsp, 0x30
00007d0bb21d46e6  movaps [rsp], xmm1
00007d0bb21d46ea  movaps [rsp+0x10], xmm14
00007d0bb21d46f0  movaps [rsp+0x20], xmm15
00007d0bb21d46f6  lea rdi, [rsp]
00007d0bb21d46fa  mov esi, 0x00
00007d0bb21d46ff  mov rax, 0x6392BBE7F530
00007d0bb21d4709  call rax
00007d0bb21d470b  movaps xmm1, [rsp]
00007d0bb21d470f  add rsp, 0x30
00007d0bb21d4713  vmovaps xmm0, [rsp]
00007d0bb21d4718  vmovaps xmm2, [rsp+0x10]
00007d0bb21d471e  vmovaps xmm3, [rsp+0x20]
00007d0bb21d4724  vmovaps xmm4, [rsp+0x30]
00007d0bb21d472a  vmovaps xmm5, [rsp+0x40]
00007d0bb21d4730  vmovaps xmm6, [rsp+0x50]
00007d0bb21d4736  vmovaps xmm7, [rsp+0x60]
00007d0bb21d473c  vmovaps xmm8, [rsp+0x70]
00007d0bb21d4742  vmovaps xmm9, [rsp+0x80]
00007d0bb21d474b  vmovaps xmm10, [rsp+0x90]
00007d0bb21d4754  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d475d  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d4766  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d476f  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d4778  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d4781  add rsp, 0xF0
00007d0bb21d4788  pop r11
00007d0bb21d478a  pop r10
00007d0bb21d478c  pop r9
00007d0bb21d478e  pop r8
00007d0bb21d4790  pop rsi
00007d0bb21d4791  pop rdi
00007d0bb21d4792  pop rdx
00007d0bb21d4793  pop rcx
00007d0bb21d4794  pop rax
00007d0bb21d4795  add rsp, 0x08
00007d0bb21d4799  jmp 0x00007D0BB21D2ACA
00007d0bb21d479e  sub rsp, 0x08
00007d0bb21d47a2  push rax
00007d0bb21d47a3  push rcx
00007d0bb21d47a4  push rdx
00007d0bb21d47a5  push rdi
00007d0bb21d47a6  push rsi
00007d0bb21d47a7  push r8
00007d0bb21d47a9  push r9
00007d0bb21d47ab  push r10
00007d0bb21d47ad  push r11
00007d0bb21d47af  sub rsp, 0xF0
00007d0bb21d47b6  vmovaps [rsp], xmm0
00007d0bb21d47bb  vmovaps [rsp+0x10], xmm1
00007d0bb21d47c1  vmovaps [rsp+0x20], xmm2
00007d0bb21d47c7  vmovaps [rsp+0x30], xmm3
00007d0bb21d47cd  vmovaps [rsp+0x40], xmm4
00007d0bb21d47d3  vmovaps [rsp+0x50], xmm5
00007d0bb21d47d9  vmovaps [rsp+0x60], xmm6
00007d0bb21d47df  vmovaps [rsp+0x70], xmm7
00007d0bb21d47e5  vmovaps [rsp+0x80], xmm8
00007d0bb21d47ee  vmovaps [rsp+0x90], xmm9
00007d0bb21d47f7  vmovaps [rsp+0xA0], xmm10
00007d0bb21d4800  vmovaps [rsp+0xB0], xmm11
00007d0bb21d4809  vmovaps [rsp+0xC0], xmm12
00007d0bb21d4812  vmovaps [rsp+0xD0], xmm13
00007d0bb21d481b  vmovaps [rsp+0xE0], xmm15
00007d0bb21d4824  sub rsp, 0x30
00007d0bb21d4828  movaps [rsp], xmm14
00007d0bb21d482d  movaps [rsp+0x10], xmm2
00007d0bb21d4832  movaps [rsp+0x20], xmm15
00007d0bb21d4838  lea rdi, [rsp]
00007d0bb21d483c  mov esi, 0x00
00007d0bb21d4841  mov rax, 0x6392BBE7F530
00007d0bb21d484b  call rax
00007d0bb21d484d  movaps xmm14, [rsp]
00007d0bb21d4852  add rsp, 0x30
00007d0bb21d4856  vmovaps xmm0, [rsp]
00007d0bb21d485b  vmovaps xmm1, [rsp+0x10]
00007d0bb21d4861  vmovaps xmm2, [rsp+0x20]
00007d0bb21d4867  vmovaps xmm3, [rsp+0x30]
00007d0bb21d486d  vmovaps xmm4, [rsp+0x40]
00007d0bb21d4873  vmovaps xmm5, [rsp+0x50]
00007d0bb21d4879  vmovaps xmm6, [rsp+0x60]
00007d0bb21d487f  vmovaps xmm7, [rsp+0x70]
00007d0bb21d4885  vmovaps xmm8, [rsp+0x80]
00007d0bb21d488e  vmovaps xmm9, [rsp+0x90]
00007d0bb21d4897  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d48a0  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d48a9  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d48b2  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d48bb  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d48c4  add rsp, 0xF0
00007d0bb21d48cb  pop r11
00007d0bb21d48cd  pop r10
00007d0bb21d48cf  pop r9
00007d0bb21d48d1  pop r8
00007d0bb21d48d3  pop rsi
00007d0bb21d48d4  pop rdi
00007d0bb21d48d5  pop rdx
00007d0bb21d48d6  pop rcx
00007d0bb21d48d7  pop rax
00007d0bb21d48d8  add rsp, 0x08
00007d0bb21d48dc  jmp 0x00007D0BB21D2B05
00007d0bb21d48e1  sub rsp, 0x08
00007d0bb21d48e5  push rax
00007d0bb21d48e6  push rcx
00007d0bb21d48e7  push rdx
00007d0bb21d48e8  push rdi
00007d0bb21d48e9  push rsi
00007d0bb21d48ea  push r8
00007d0bb21d48ec  push r9
00007d0bb21d48ee  push r10
00007d0bb21d48f0  push r11
00007d0bb21d48f2  sub rsp, 0xF0
00007d0bb21d48f9  vmovaps [rsp], xmm0
00007d0bb21d48fe  vmovaps [rsp+0x10], xmm1
00007d0bb21d4904  vmovaps [rsp+0x20], xmm2
00007d0bb21d490a  vmovaps [rsp+0x30], xmm3
00007d0bb21d4910  vmovaps [rsp+0x40], xmm4
00007d0bb21d4916  vmovaps [rsp+0x50], xmm5
00007d0bb21d491c  vmovaps [rsp+0x60], xmm6
00007d0bb21d4922  vmovaps [rsp+0x70], xmm7
00007d0bb21d4928  vmovaps [rsp+0x80], xmm8
00007d0bb21d4931  vmovaps [rsp+0x90], xmm9
00007d0bb21d493a  vmovaps [rsp+0xA0], xmm10
00007d0bb21d4943  vmovaps [rsp+0xB0], xmm11
00007d0bb21d494c  vmovaps [rsp+0xC0], xmm12
00007d0bb21d4955  vmovaps [rsp+0xD0], xmm13
00007d0bb21d495e  vmovaps [rsp+0xE0], xmm14
00007d0bb21d4967  sub rsp, 0x30
00007d0bb21d496b  movaps [rsp], xmm15
00007d0bb21d4970  movaps [rsp+0x10], xmm2
00007d0bb21d4975  movaps [rsp+0x20], xmm1
00007d0bb21d497a  lea rdi, [rsp]
00007d0bb21d497e  mov esi, 0x00
00007d0bb21d4983  mov rax, 0x6392BBE7F530
00007d0bb21d498d  call rax
00007d0bb21d498f  movaps xmm15, [rsp]
00007d0bb21d4994  add rsp, 0x30
00007d0bb21d4998  vmovaps xmm0, [rsp]
00007d0bb21d499d  vmovaps xmm1, [rsp+0x10]
00007d0bb21d49a3  vmovaps xmm2, [rsp+0x20]
00007d0bb21d49a9  vmovaps xmm3, [rsp+0x30]
00007d0bb21d49af  vmovaps xmm4, [rsp+0x40]
00007d0bb21d49b5  vmovaps xmm5, [rsp+0x50]
00007d0bb21d49bb  vmovaps xmm6, [rsp+0x60]
00007d0bb21d49c1  vmovaps xmm7, [rsp+0x70]
00007d0bb21d49c7  vmovaps xmm8, [rsp+0x80]
00007d0bb21d49d0  vmovaps xmm9, [rsp+0x90]
00007d0bb21d49d9  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d49e2  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d49eb  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d49f4  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d49fd  vmovaps xmm14, [rsp+0xE0]
00007d0bb21d4a06  add rsp, 0xF0
00007d0bb21d4a0d  pop r11
00007d0bb21d4a0f  pop r10
00007d0bb21d4a11  pop r9
00007d0bb21d4a13  pop r8
00007d0bb21d4a15  pop rsi
00007d0bb21d4a16  pop rdi
00007d0bb21d4a17  pop rdx
00007d0bb21d4a18  pop rcx
00007d0bb21d4a19  pop rax
00007d0bb21d4a1a  add rsp, 0x08
00007d0bb21d4a1e  jmp 0x00007D0BB21D2B41
00007d0bb21d4a23  call 0x00007D0BB1FFF430
00007d0bb21d4a28  jmp 0x00007D0BB21D2B4E
00007d0bb21d4a2d  sub rsp, 0x08
00007d0bb21d4a31  push rax
00007d0bb21d4a32  push rcx
00007d0bb21d4a33  push rdx
00007d0bb21d4a34  push rdi
00007d0bb21d4a35  push rsi
00007d0bb21d4a36  push r8
00007d0bb21d4a38  push r9
00007d0bb21d4a3a  push r10
00007d0bb21d4a3c  push r11
00007d0bb21d4a3e  sub rsp, 0xF0
00007d0bb21d4a45  vmovaps [rsp], xmm0
00007d0bb21d4a4a  vmovaps [rsp+0x10], xmm1
00007d0bb21d4a50  vmovaps [rsp+0x20], xmm3
00007d0bb21d4a56  vmovaps [rsp+0x30], xmm4
00007d0bb21d4a5c  vmovaps [rsp+0x40], xmm5
00007d0bb21d4a62  vmovaps [rsp+0x50], xmm6
00007d0bb21d4a68  vmovaps [rsp+0x60], xmm7
00007d0bb21d4a6e  vmovaps [rsp+0x70], xmm8
00007d0bb21d4a74  vmovaps [rsp+0x80], xmm9
00007d0bb21d4a7d  vmovaps [rsp+0x90], xmm10
00007d0bb21d4a86  vmovaps [rsp+0xA0], xmm11
00007d0bb21d4a8f  vmovaps [rsp+0xB0], xmm12
00007d0bb21d4a98  vmovaps [rsp+0xC0], xmm13
00007d0bb21d4aa1  vmovaps [rsp+0xD0], xmm14
00007d0bb21d4aaa  vmovaps [rsp+0xE0], xmm15
00007d0bb21d4ab3  sub rsp, 0x30
00007d0bb21d4ab7  movaps [rsp], xmm2
00007d0bb21d4abb  movaps [rsp+0x10], xmm1
00007d0bb21d4ac0  movaps [rsp+0x20], xmm14
00007d0bb21d4ac6  lea rdi, [rsp]
00007d0bb21d4aca  mov esi, 0x00
00007d0bb21d4acf  mov rax, 0x6392BBE7F530
00007d0bb21d4ad9  call rax
00007d0bb21d4adb  movaps xmm2, [rsp]
00007d0bb21d4adf  add rsp, 0x30
00007d0bb21d4ae3  vmovaps xmm0, [rsp]
00007d0bb21d4ae8  vmovaps xmm1, [rsp+0x10]
00007d0bb21d4aee  vmovaps xmm3, [rsp+0x20]
00007d0bb21d4af4  vmovaps xmm4, [rsp+0x30]
00007d0bb21d4afa  vmovaps xmm5, [rsp+0x40]
00007d0bb21d4b00  vmovaps xmm6, [rsp+0x50]
00007d0bb21d4b06  vmovaps xmm7, [rsp+0x60]
00007d0bb21d4b0c  vmovaps xmm8, [rsp+0x70]
00007d0bb21d4b12  vmovaps xmm9, [rsp+0x80]
00007d0bb21d4b1b  vmovaps xmm10, [rsp+0x90]
00007d0bb21d4b24  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d4b2d  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d4b36  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d4b3f  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d4b48  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d4b51  add rsp, 0xF0
00007d0bb21d4b58  pop r11
00007d0bb21d4b5a  pop r10
00007d0bb21d4b5c  pop r9
00007d0bb21d4b5e  pop r8
00007d0bb21d4b60  pop rsi
00007d0bb21d4b61  pop rdi
00007d0bb21d4b62  pop rdx
00007d0bb21d4b63  pop rcx
00007d0bb21d4b64  pop rax
00007d0bb21d4b65  add rsp, 0x08
00007d0bb21d4b69  jmp 0x00007D0BB21D2B8B
00007d0bb21d4b6e  sub rsp, 0x08
00007d0bb21d4b72  push rax
00007d0bb21d4b73  push rcx
00007d0bb21d4b74  push rdx
00007d0bb21d4b75  push rdi
00007d0bb21d4b76  push rsi
00007d0bb21d4b77  push r8
00007d0bb21d4b79  push r9
00007d0bb21d4b7b  push r10
00007d0bb21d4b7d  push r11
00007d0bb21d4b7f  sub rsp, 0xF0
00007d0bb21d4b86  vmovaps [rsp], xmm0
00007d0bb21d4b8b  vmovaps [rsp+0x10], xmm1
00007d0bb21d4b91  vmovaps [rsp+0x20], xmm2
00007d0bb21d4b97  vmovaps [rsp+0x30], xmm3
00007d0bb21d4b9d  vmovaps [rsp+0x40], xmm4
00007d0bb21d4ba3  vmovaps [rsp+0x50], xmm5
00007d0bb21d4ba9  vmovaps [rsp+0x60], xmm6
00007d0bb21d4baf  vmovaps [rsp+0x70], xmm7
00007d0bb21d4bb5  vmovaps [rsp+0x80], xmm8
00007d0bb21d4bbe  vmovaps [rsp+0x90], xmm9
00007d0bb21d4bc7  vmovaps [rsp+0xA0], xmm10
00007d0bb21d4bd0  vmovaps [rsp+0xB0], xmm11
00007d0bb21d4bd9  vmovaps [rsp+0xC0], xmm12
00007d0bb21d4be2  vmovaps [rsp+0xD0], xmm13
00007d0bb21d4beb  vmovaps [rsp+0xE0], xmm14
00007d0bb21d4bf4  sub rsp, 0x30
00007d0bb21d4bf8  movaps [rsp], xmm15
00007d0bb21d4bfd  movaps [rsp+0x10], xmm14
00007d0bb21d4c03  movaps [rsp+0x20], xmm1
00007d0bb21d4c08  lea rdi, [rsp]
00007d0bb21d4c0c  mov esi, 0x00
00007d0bb21d4c11  mov rax, 0x6392BBE7F530
00007d0bb21d4c1b  call rax
00007d0bb21d4c1d  movaps xmm15, [rsp]
00007d0bb21d4c22  add rsp, 0x30
00007d0bb21d4c26  vmovaps xmm0, [rsp]
00007d0bb21d4c2b  vmovaps xmm1, [rsp+0x10]
00007d0bb21d4c31  vmovaps xmm2, [rsp+0x20]
00007d0bb21d4c37  vmovaps xmm3, [rsp+0x30]
00007d0bb21d4c3d  vmovaps xmm4, [rsp+0x40]
00007d0bb21d4c43  vmovaps xmm5, [rsp+0x50]
00007d0bb21d4c49  vmovaps xmm6, [rsp+0x60]
00007d0bb21d4c4f  vmovaps xmm7, [rsp+0x70]
00007d0bb21d4c55  vmovaps xmm8, [rsp+0x80]
00007d0bb21d4c5e  vmovaps xmm9, [rsp+0x90]
00007d0bb21d4c67  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d4c70  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d4c79  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d4c82  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d4c8b  vmovaps xmm14, [rsp+0xE0]
00007d0bb21d4c94  add rsp, 0xF0
00007d0bb21d4c9b  pop r11
00007d0bb21d4c9d  pop r10
00007d0bb21d4c9f  pop r9
00007d0bb21d4ca1  pop r8
00007d0bb21d4ca3  pop rsi
00007d0bb21d4ca4  pop rdi
00007d0bb21d4ca5  pop rdx
00007d0bb21d4ca6  pop rcx
00007d0bb21d4ca7  pop rax
00007d0bb21d4ca8  add rsp, 0x08
00007d0bb21d4cac  jmp 0x00007D0BB21D2C05
00007d0bb21d4cb1  call 0x00007D0BB1FFF430
00007d0bb21d4cb6  jmp 0x00007D0BB21D2C12
00007d0bb21d4cbb  sub rsp, 0x08
00007d0bb21d4cbf  push rax
00007d0bb21d4cc0  push rcx
00007d0bb21d4cc1  push rdx
00007d0bb21d4cc2  push rdi
00007d0bb21d4cc3  push rsi
00007d0bb21d4cc4  push r8
00007d0bb21d4cc6  push r9
00007d0bb21d4cc8  push r10
00007d0bb21d4cca  push r11
00007d0bb21d4ccc  sub rsp, 0xF0
00007d0bb21d4cd3  vmovaps [rsp], xmm0
00007d0bb21d4cd8  vmovaps [rsp+0x10], xmm1
00007d0bb21d4cde  vmovaps [rsp+0x20], xmm2
00007d0bb21d4ce4  vmovaps [rsp+0x30], xmm3
00007d0bb21d4cea  vmovaps [rsp+0x40], xmm4
00007d0bb21d4cf0  vmovaps [rsp+0x50], xmm5
00007d0bb21d4cf6  vmovaps [rsp+0x60], xmm6
00007d0bb21d4cfc  vmovaps [rsp+0x70], xmm7
00007d0bb21d4d02  vmovaps [rsp+0x80], xmm8
00007d0bb21d4d0b  vmovaps [rsp+0x90], xmm9
00007d0bb21d4d14  vmovaps [rsp+0xA0], xmm10
00007d0bb21d4d1d  vmovaps [rsp+0xB0], xmm11
00007d0bb21d4d26  vmovaps [rsp+0xC0], xmm12
00007d0bb21d4d2f  vmovaps [rsp+0xD0], xmm14
00007d0bb21d4d38  vmovaps [rsp+0xE0], xmm15
00007d0bb21d4d41  sub rsp, 0x30
00007d0bb21d4d45  movaps [rsp], xmm13
00007d0bb21d4d4a  movaps [rsp+0x10], xmm1
00007d0bb21d4d4f  movaps [rsp+0x20], xmm15
00007d0bb21d4d55  lea rdi, [rsp]
00007d0bb21d4d59  mov esi, 0x00
00007d0bb21d4d5e  mov rax, 0x6392BBE7F530
00007d0bb21d4d68  call rax
00007d0bb21d4d6a  movaps xmm13, [rsp]
00007d0bb21d4d6f  add rsp, 0x30
00007d0bb21d4d73  vmovaps xmm0, [rsp]
00007d0bb21d4d78  vmovaps xmm1, [rsp+0x10]
00007d0bb21d4d7e  vmovaps xmm2, [rsp+0x20]
00007d0bb21d4d84  vmovaps xmm3, [rsp+0x30]
00007d0bb21d4d8a  vmovaps xmm4, [rsp+0x40]
00007d0bb21d4d90  vmovaps xmm5, [rsp+0x50]
00007d0bb21d4d96  vmovaps xmm6, [rsp+0x60]
00007d0bb21d4d9c  vmovaps xmm7, [rsp+0x70]
00007d0bb21d4da2  vmovaps xmm8, [rsp+0x80]
00007d0bb21d4dab  vmovaps xmm9, [rsp+0x90]
00007d0bb21d4db4  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d4dbd  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d4dc6  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d4dcf  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d4dd8  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d4de1  add rsp, 0xF0
00007d0bb21d4de8  pop r11
00007d0bb21d4dea  pop r10
00007d0bb21d4dec  pop r9
00007d0bb21d4dee  pop r8
00007d0bb21d4df0  pop rsi
00007d0bb21d4df1  pop rdi
00007d0bb21d4df2  pop rdx
00007d0bb21d4df3  pop rcx
00007d0bb21d4df4  pop rax
00007d0bb21d4df5  add rsp, 0x08
00007d0bb21d4df9  jmp 0x00007D0BB21D2CD6
00007d0bb21d4dfe  sub rsp, 0x08
00007d0bb21d4e02  push rax
00007d0bb21d4e03  push rcx
00007d0bb21d4e04  push rdx
00007d0bb21d4e05  push rdi
00007d0bb21d4e06  push rsi
00007d0bb21d4e07  push r8
00007d0bb21d4e09  push r9
00007d0bb21d4e0b  push r10
00007d0bb21d4e0d  push r11
00007d0bb21d4e0f  sub rsp, 0xF0
00007d0bb21d4e16  vmovaps [rsp], xmm0
00007d0bb21d4e1b  vmovaps [rsp+0x10], xmm1
00007d0bb21d4e21  vmovaps [rsp+0x20], xmm2
00007d0bb21d4e27  vmovaps [rsp+0x30], xmm3
00007d0bb21d4e2d  vmovaps [rsp+0x40], xmm4
00007d0bb21d4e33  vmovaps [rsp+0x50], xmm5
00007d0bb21d4e39  vmovaps [rsp+0x60], xmm6
00007d0bb21d4e3f  vmovaps [rsp+0x70], xmm7
00007d0bb21d4e45  vmovaps [rsp+0x80], xmm8
00007d0bb21d4e4e  vmovaps [rsp+0x90], xmm9
00007d0bb21d4e57  vmovaps [rsp+0xA0], xmm10
00007d0bb21d4e60  vmovaps [rsp+0xB0], xmm11
00007d0bb21d4e69  vmovaps [rsp+0xC0], xmm12
00007d0bb21d4e72  vmovaps [rsp+0xD0], xmm13
00007d0bb21d4e7b  vmovaps [rsp+0xE0], xmm14
00007d0bb21d4e84  sub rsp, 0x30
00007d0bb21d4e88  movaps [rsp], xmm15
00007d0bb21d4e8d  movaps [rsp+0x10], xmm14
00007d0bb21d4e93  movaps [rsp+0x20], xmm1
00007d0bb21d4e98  lea rdi, [rsp]
00007d0bb21d4e9c  mov esi, 0x00
00007d0bb21d4ea1  mov rax, 0x6392BBE7F530
00007d0bb21d4eab  call rax
00007d0bb21d4ead  movaps xmm15, [rsp]
00007d0bb21d4eb2  add rsp, 0x30
00007d0bb21d4eb6  vmovaps xmm0, [rsp]
00007d0bb21d4ebb  vmovaps xmm1, [rsp+0x10]
00007d0bb21d4ec1  vmovaps xmm2, [rsp+0x20]
00007d0bb21d4ec7  vmovaps xmm3, [rsp+0x30]
00007d0bb21d4ecd  vmovaps xmm4, [rsp+0x40]
00007d0bb21d4ed3  vmovaps xmm5, [rsp+0x50]
00007d0bb21d4ed9  vmovaps xmm6, [rsp+0x60]
00007d0bb21d4edf  vmovaps xmm7, [rsp+0x70]
00007d0bb21d4ee5  vmovaps xmm8, [rsp+0x80]
00007d0bb21d4eee  vmovaps xmm9, [rsp+0x90]
00007d0bb21d4ef7  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d4f00  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d4f09  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d4f12  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d4f1b  vmovaps xmm14, [rsp+0xE0]
00007d0bb21d4f24  add rsp, 0xF0
00007d0bb21d4f2b  pop r11
00007d0bb21d4f2d  pop r10
00007d0bb21d4f2f  pop r9
00007d0bb21d4f31  pop r8
00007d0bb21d4f33  pop rsi
00007d0bb21d4f34  pop rdi
00007d0bb21d4f35  pop rdx
00007d0bb21d4f36  pop rcx
00007d0bb21d4f37  pop rax
00007d0bb21d4f38  add rsp, 0x08
00007d0bb21d4f3c  jmp 0x00007D0BB21D2D12
00007d0bb21d4f41  call 0x00007D0BB1FFF430
00007d0bb21d4f46  jmp 0x00007D0BB21D2D1F
00007d0bb21d4f4b  sub rsp, 0x08
00007d0bb21d4f4f  push rax
00007d0bb21d4f50  push rcx
00007d0bb21d4f51  push rdx
00007d0bb21d4f52  push rdi
00007d0bb21d4f53  push rsi
00007d0bb21d4f54  push r8
00007d0bb21d4f56  push r9
00007d0bb21d4f58  push r10
00007d0bb21d4f5a  push r11
00007d0bb21d4f5c  sub rsp, 0xF0
00007d0bb21d4f63  vmovaps [rsp], xmm0
00007d0bb21d4f68  vmovaps [rsp+0x10], xmm1
00007d0bb21d4f6e  vmovaps [rsp+0x20], xmm2
00007d0bb21d4f74  vmovaps [rsp+0x30], xmm3
00007d0bb21d4f7a  vmovaps [rsp+0x40], xmm4
00007d0bb21d4f80  vmovaps [rsp+0x50], xmm5
00007d0bb21d4f86  vmovaps [rsp+0x60], xmm6
00007d0bb21d4f8c  vmovaps [rsp+0x70], xmm7
00007d0bb21d4f92  vmovaps [rsp+0x80], xmm8
00007d0bb21d4f9b  vmovaps [rsp+0x90], xmm9
00007d0bb21d4fa4  vmovaps [rsp+0xA0], xmm10
00007d0bb21d4fad  vmovaps [rsp+0xB0], xmm11
00007d0bb21d4fb6  vmovaps [rsp+0xC0], xmm12
00007d0bb21d4fbf  vmovaps [rsp+0xD0], xmm13
00007d0bb21d4fc8  vmovaps [rsp+0xE0], xmm15
00007d0bb21d4fd1  sub rsp, 0x30
00007d0bb21d4fd5  movaps [rsp], xmm14
00007d0bb21d4fda  movaps [rsp+0x10], xmm13
00007d0bb21d4fe0  movaps [rsp+0x20], xmm2
00007d0bb21d4fe5  lea rdi, [rsp]
00007d0bb21d4fe9  mov esi, 0x00
00007d0bb21d4fee  mov rax, 0x6392BBE7F530
00007d0bb21d4ff8  call rax
00007d0bb21d4ffa  movaps xmm14, [rsp]
00007d0bb21d4fff  add rsp, 0x30
00007d0bb21d5003  vmovaps xmm0, [rsp]
00007d0bb21d5008  vmovaps xmm1, [rsp+0x10]
00007d0bb21d500e  vmovaps xmm2, [rsp+0x20]
00007d0bb21d5014  vmovaps xmm3, [rsp+0x30]
00007d0bb21d501a  vmovaps xmm4, [rsp+0x40]
00007d0bb21d5020  vmovaps xmm5, [rsp+0x50]
00007d0bb21d5026  vmovaps xmm6, [rsp+0x60]
00007d0bb21d502c  vmovaps xmm7, [rsp+0x70]
00007d0bb21d5032  vmovaps xmm8, [rsp+0x80]
00007d0bb21d503b  vmovaps xmm9, [rsp+0x90]
00007d0bb21d5044  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d504d  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d5056  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d505f  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d5068  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d5071  add rsp, 0xF0
00007d0bb21d5078  pop r11
00007d0bb21d507a  pop r10
00007d0bb21d507c  pop r9
00007d0bb21d507e  pop r8
00007d0bb21d5080  pop rsi
00007d0bb21d5081  pop rdi
00007d0bb21d5082  pop rdx
00007d0bb21d5083  pop rcx
00007d0bb21d5084  pop rax
00007d0bb21d5085  add rsp, 0x08
00007d0bb21d5089  jmp 0x00007D0BB21D2D4B
00007d0bb21d508e  sub rsp, 0x08
00007d0bb21d5092  push rax
00007d0bb21d5093  push rcx
00007d0bb21d5094  push rdx
00007d0bb21d5095  push rdi
00007d0bb21d5096  push rsi
00007d0bb21d5097  push r8
00007d0bb21d5099  push r9
00007d0bb21d509b  push r10
00007d0bb21d509d  push r11
00007d0bb21d509f  sub rsp, 0xF0
00007d0bb21d50a6  vmovaps [rsp], xmm0
00007d0bb21d50ab  vmovaps [rsp+0x10], xmm2
00007d0bb21d50b1  vmovaps [rsp+0x20], xmm3
00007d0bb21d50b7  vmovaps [rsp+0x30], xmm4
00007d0bb21d50bd  vmovaps [rsp+0x40], xmm5
00007d0bb21d50c3  vmovaps [rsp+0x50], xmm6
00007d0bb21d50c9  vmovaps [rsp+0x60], xmm7
00007d0bb21d50cf  vmovaps [rsp+0x70], xmm8
00007d0bb21d50d5  vmovaps [rsp+0x80], xmm9
00007d0bb21d50de  vmovaps [rsp+0x90], xmm10
00007d0bb21d50e7  vmovaps [rsp+0xA0], xmm11
00007d0bb21d50f0  vmovaps [rsp+0xB0], xmm12
00007d0bb21d50f9  vmovaps [rsp+0xC0], xmm13
00007d0bb21d5102  vmovaps [rsp+0xD0], xmm14
00007d0bb21d510b  vmovaps [rsp+0xE0], xmm15
00007d0bb21d5114  sub rsp, 0x30
00007d0bb21d5118  movaps [rsp], xmm1
00007d0bb21d511c  movaps [rsp+0x10], xmm13
00007d0bb21d5122  movaps [rsp+0x20], xmm2
00007d0bb21d5127  lea rdi, [rsp]
00007d0bb21d512b  mov esi, 0x00
00007d0bb21d5130  mov rax, 0x6392BBE7F530
00007d0bb21d513a  call rax
00007d0bb21d513c  movaps xmm1, [rsp]
00007d0bb21d5140  add rsp, 0x30
00007d0bb21d5144  vmovaps xmm0, [rsp]
00007d0bb21d5149  vmovaps xmm2, [rsp+0x10]
00007d0bb21d514f  vmovaps xmm3, [rsp+0x20]
00007d0bb21d5155  vmovaps xmm4, [rsp+0x30]
00007d0bb21d515b  vmovaps xmm5, [rsp+0x40]
00007d0bb21d5161  vmovaps xmm6, [rsp+0x50]
00007d0bb21d5167  vmovaps xmm7, [rsp+0x60]
00007d0bb21d516d  vmovaps xmm8, [rsp+0x70]
00007d0bb21d5173  vmovaps xmm9, [rsp+0x80]
00007d0bb21d517c  vmovaps xmm10, [rsp+0x90]
00007d0bb21d5185  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d518e  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d5197  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d51a0  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d51a9  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d51b2  add rsp, 0xF0
00007d0bb21d51b9  pop r11
00007d0bb21d51bb  pop r10
00007d0bb21d51bd  pop r9
00007d0bb21d51bf  pop r8
00007d0bb21d51c1  pop rsi
00007d0bb21d51c2  pop rdi
00007d0bb21d51c3  pop rdx
00007d0bb21d51c4  pop rcx
00007d0bb21d51c5  pop rax
00007d0bb21d51c6  add rsp, 0x08
00007d0bb21d51ca  jmp 0x00007D0BB21D2D79
00007d0bb21d51cf  sub rsp, 0x08
00007d0bb21d51d3  push rax
00007d0bb21d51d4  push rcx
00007d0bb21d51d5  push rdx
00007d0bb21d51d6  push rdi
00007d0bb21d51d7  push rsi
00007d0bb21d51d8  push r8
00007d0bb21d51da  push r9
00007d0bb21d51dc  push r10
00007d0bb21d51de  push r11
00007d0bb21d51e0  sub rsp, 0xF0
00007d0bb21d51e7  vmovaps [rsp], xmm0
00007d0bb21d51ec  vmovaps [rsp+0x10], xmm1
00007d0bb21d51f2  vmovaps [rsp+0x20], xmm3
00007d0bb21d51f8  vmovaps [rsp+0x30], xmm4
00007d0bb21d51fe  vmovaps [rsp+0x40], xmm5
00007d0bb21d5204  vmovaps [rsp+0x50], xmm6
00007d0bb21d520a  vmovaps [rsp+0x60], xmm7
00007d0bb21d5210  vmovaps [rsp+0x70], xmm8
00007d0bb21d5216  vmovaps [rsp+0x80], xmm9
00007d0bb21d521f  vmovaps [rsp+0x90], xmm10
00007d0bb21d5228  vmovaps [rsp+0xA0], xmm11
00007d0bb21d5231  vmovaps [rsp+0xB0], xmm12
00007d0bb21d523a  vmovaps [rsp+0xC0], xmm13
00007d0bb21d5243  vmovaps [rsp+0xD0], xmm14
00007d0bb21d524c  vmovaps [rsp+0xE0], xmm15
00007d0bb21d5255  sub rsp, 0x30
00007d0bb21d5259  movaps [rsp], xmm2
00007d0bb21d525d  movaps [rsp+0x10], xmm1
00007d0bb21d5262  movaps [rsp+0x20], xmm13
00007d0bb21d5268  lea rdi, [rsp]
00007d0bb21d526c  mov esi, 0x00
00007d0bb21d5271  mov rax, 0x6392BBE7F530
00007d0bb21d527b  call rax
00007d0bb21d527d  movaps xmm2, [rsp]
00007d0bb21d5281  add rsp, 0x30
00007d0bb21d5285  vmovaps xmm0, [rsp]
00007d0bb21d528a  vmovaps xmm1, [rsp+0x10]
00007d0bb21d5290  vmovaps xmm3, [rsp+0x20]
00007d0bb21d5296  vmovaps xmm4, [rsp+0x30]
00007d0bb21d529c  vmovaps xmm5, [rsp+0x40]
00007d0bb21d52a2  vmovaps xmm6, [rsp+0x50]
00007d0bb21d52a8  vmovaps xmm7, [rsp+0x60]
00007d0bb21d52ae  vmovaps xmm8, [rsp+0x70]
00007d0bb21d52b4  vmovaps xmm9, [rsp+0x80]
00007d0bb21d52bd  vmovaps xmm10, [rsp+0x90]
00007d0bb21d52c6  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d52cf  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d52d8  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d52e1  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d52ea  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d52f3  add rsp, 0xF0
00007d0bb21d52fa  pop r11
00007d0bb21d52fc  pop r10
00007d0bb21d52fe  pop r9
00007d0bb21d5300  pop r8
00007d0bb21d5302  pop rsi
00007d0bb21d5303  pop rdi
00007d0bb21d5304  pop rdx
00007d0bb21d5305  pop rcx
00007d0bb21d5306  pop rax
00007d0bb21d5307  add rsp, 0x08
00007d0bb21d530b  jmp 0x00007D0BB21D2DD2
00007d0bb21d5310  call 0x00007D0BB1FFF430
00007d0bb21d5315  jmp 0x00007D0BB21D2DDF
00007d0bb21d531a  sub rsp, 0x08
00007d0bb21d531e  push rax
00007d0bb21d531f  push rcx
00007d0bb21d5320  push rdx
00007d0bb21d5321  push rdi
00007d0bb21d5322  push rsi
00007d0bb21d5323  push r8
00007d0bb21d5325  push r9
00007d0bb21d5327  push r10
00007d0bb21d5329  push r11
00007d0bb21d532b  sub rsp, 0xF0
00007d0bb21d5332  vmovaps [rsp], xmm0
00007d0bb21d5337  vmovaps [rsp+0x10], xmm1
00007d0bb21d533d  vmovaps [rsp+0x20], xmm2
00007d0bb21d5343  vmovaps [rsp+0x30], xmm3
00007d0bb21d5349  vmovaps [rsp+0x40], xmm4
00007d0bb21d534f  vmovaps [rsp+0x50], xmm5
00007d0bb21d5355  vmovaps [rsp+0x60], xmm6
00007d0bb21d535b  vmovaps [rsp+0x70], xmm7
00007d0bb21d5361  vmovaps [rsp+0x80], xmm8
00007d0bb21d536a  vmovaps [rsp+0x90], xmm9
00007d0bb21d5373  vmovaps [rsp+0xA0], xmm10
00007d0bb21d537c  vmovaps [rsp+0xB0], xmm11
00007d0bb21d5385  vmovaps [rsp+0xC0], xmm12
00007d0bb21d538e  vmovaps [rsp+0xD0], xmm13
00007d0bb21d5397  vmovaps [rsp+0xE0], xmm14
00007d0bb21d53a0  sub rsp, 0x30
00007d0bb21d53a4  movaps [rsp], xmm15
00007d0bb21d53a9  movaps [rsp+0x10], xmm13
00007d0bb21d53af  movaps [rsp+0x20], xmm1
00007d0bb21d53b4  lea rdi, [rsp]
00007d0bb21d53b8  mov esi, 0x00
00007d0bb21d53bd  mov rax, 0x6392BBE7F530
00007d0bb21d53c7  call rax
00007d0bb21d53c9  movaps xmm15, [rsp]
00007d0bb21d53ce  add rsp, 0x30
00007d0bb21d53d2  vmovaps xmm0, [rsp]
00007d0bb21d53d7  vmovaps xmm1, [rsp+0x10]
00007d0bb21d53dd  vmovaps xmm2, [rsp+0x20]
00007d0bb21d53e3  vmovaps xmm3, [rsp+0x30]
00007d0bb21d53e9  vmovaps xmm4, [rsp+0x40]
00007d0bb21d53ef  vmovaps xmm5, [rsp+0x50]
00007d0bb21d53f5  vmovaps xmm6, [rsp+0x60]
00007d0bb21d53fb  vmovaps xmm7, [rsp+0x70]
00007d0bb21d5401  vmovaps xmm8, [rsp+0x80]
00007d0bb21d540a  vmovaps xmm9, [rsp+0x90]
00007d0bb21d5413  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d541c  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d5425  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d542e  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d5437  vmovaps xmm14, [rsp+0xE0]
00007d0bb21d5440  add rsp, 0xF0
00007d0bb21d5447  pop r11
00007d0bb21d5449  pop r10
00007d0bb21d544b  pop r9
00007d0bb21d544d  pop r8
00007d0bb21d544f  pop rsi
00007d0bb21d5450  pop rdi
00007d0bb21d5451  pop rdx
00007d0bb21d5452  pop rcx
00007d0bb21d5453  pop rax
00007d0bb21d5454  add rsp, 0x08
00007d0bb21d5458  jmp 0x00007D0BB21D2E1E
00007d0bb21d545d  sub rsp, 0x08
00007d0bb21d5461  push rax
00007d0bb21d5462  push rcx
00007d0bb21d5463  push rdx
00007d0bb21d5464  push rdi
00007d0bb21d5465  push rsi
00007d0bb21d5466  push r8
00007d0bb21d5468  push r9
00007d0bb21d546a  push r10
00007d0bb21d546c  push r11
00007d0bb21d546e  sub rsp, 0xF0
00007d0bb21d5475  vmovaps [rsp], xmm0
00007d0bb21d547a  vmovaps [rsp+0x10], xmm1
00007d0bb21d5480  vmovaps [rsp+0x20], xmm2
00007d0bb21d5486  vmovaps [rsp+0x30], xmm3
00007d0bb21d548c  vmovaps [rsp+0x40], xmm4
00007d0bb21d5492  vmovaps [rsp+0x50], xmm5
00007d0bb21d5498  vmovaps [rsp+0x60], xmm6
00007d0bb21d549e  vmovaps [rsp+0x70], xmm7
00007d0bb21d54a4  vmovaps [rsp+0x80], xmm8
00007d0bb21d54ad  vmovaps [rsp+0x90], xmm9
00007d0bb21d54b6  vmovaps [rsp+0xA0], xmm10
00007d0bb21d54bf  vmovaps [rsp+0xB0], xmm11
00007d0bb21d54c8  vmovaps [rsp+0xC0], xmm12
00007d0bb21d54d1  vmovaps [rsp+0xD0], xmm13
00007d0bb21d54da  vmovaps [rsp+0xE0], xmm15
00007d0bb21d54e3  sub rsp, 0x30
00007d0bb21d54e7  movaps [rsp], xmm14
00007d0bb21d54ec  movaps [rsp+0x10], xmm11
00007d0bb21d54f2  movaps [rsp+0x20], xmm1
00007d0bb21d54f7  lea rdi, [rsp]
00007d0bb21d54fb  mov esi, 0x00
00007d0bb21d5500  mov rax, 0x6392BBE7F530
00007d0bb21d550a  call rax
00007d0bb21d550c  movaps xmm14, [rsp]
00007d0bb21d5511  add rsp, 0x30
00007d0bb21d5515  vmovaps xmm0, [rsp]
00007d0bb21d551a  vmovaps xmm1, [rsp+0x10]
00007d0bb21d5520  vmovaps xmm2, [rsp+0x20]
00007d0bb21d5526  vmovaps xmm3, [rsp+0x30]
00007d0bb21d552c  vmovaps xmm4, [rsp+0x40]
00007d0bb21d5532  vmovaps xmm5, [rsp+0x50]
00007d0bb21d5538  vmovaps xmm6, [rsp+0x60]
00007d0bb21d553e  vmovaps xmm7, [rsp+0x70]
00007d0bb21d5544  vmovaps xmm8, [rsp+0x80]
00007d0bb21d554d  vmovaps xmm9, [rsp+0x90]
00007d0bb21d5556  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d555f  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d5568  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d5571  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d557a  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d5583  add rsp, 0xF0
00007d0bb21d558a  pop r11
00007d0bb21d558c  pop r10
00007d0bb21d558e  pop r9
00007d0bb21d5590  pop r8
00007d0bb21d5592  pop rsi
00007d0bb21d5593  pop rdi
00007d0bb21d5594  pop rdx
00007d0bb21d5595  pop rcx
00007d0bb21d5596  pop rax
00007d0bb21d5597  add rsp, 0x08
00007d0bb21d559b  jmp 0x00007D0BB21D2E48
00007d0bb21d55a0  sub rsp, 0x08
00007d0bb21d55a4  push rax
00007d0bb21d55a5  push rcx
00007d0bb21d55a6  push rdx
00007d0bb21d55a7  push rdi
00007d0bb21d55a8  push rsi
00007d0bb21d55a9  push r8
00007d0bb21d55ab  push r9
00007d0bb21d55ad  push r10
00007d0bb21d55af  push r11
00007d0bb21d55b1  sub rsp, 0xF0
00007d0bb21d55b8  vmovaps [rsp], xmm0
00007d0bb21d55bd  vmovaps [rsp+0x10], xmm1
00007d0bb21d55c3  vmovaps [rsp+0x20], xmm2
00007d0bb21d55c9  vmovaps [rsp+0x30], xmm3
00007d0bb21d55cf  vmovaps [rsp+0x40], xmm4
00007d0bb21d55d5  vmovaps [rsp+0x50], xmm5
00007d0bb21d55db  vmovaps [rsp+0x60], xmm6
00007d0bb21d55e1  vmovaps [rsp+0x70], xmm7
00007d0bb21d55e7  vmovaps [rsp+0x80], xmm8
00007d0bb21d55f0  vmovaps [rsp+0x90], xmm9
00007d0bb21d55f9  vmovaps [rsp+0xA0], xmm10
00007d0bb21d5602  vmovaps [rsp+0xB0], xmm11
00007d0bb21d560b  vmovaps [rsp+0xC0], xmm12
00007d0bb21d5614  vmovaps [rsp+0xD0], xmm14
00007d0bb21d561d  vmovaps [rsp+0xE0], xmm15
00007d0bb21d5626  sub rsp, 0x30
00007d0bb21d562a  movaps [rsp], xmm13
00007d0bb21d562f  movaps [rsp+0x10], xmm11
00007d0bb21d5635  movaps [rsp+0x20], xmm1
00007d0bb21d563a  lea rdi, [rsp]
00007d0bb21d563e  mov esi, 0x00
00007d0bb21d5643  mov rax, 0x6392BBE7F530
00007d0bb21d564d  call rax
00007d0bb21d564f  movaps xmm13, [rsp]
00007d0bb21d5654  add rsp, 0x30
00007d0bb21d5658  vmovaps xmm0, [rsp]
00007d0bb21d565d  vmovaps xmm1, [rsp+0x10]
00007d0bb21d5663  vmovaps xmm2, [rsp+0x20]
00007d0bb21d5669  vmovaps xmm3, [rsp+0x30]
00007d0bb21d566f  vmovaps xmm4, [rsp+0x40]
00007d0bb21d5675  vmovaps xmm5, [rsp+0x50]
00007d0bb21d567b  vmovaps xmm6, [rsp+0x60]
00007d0bb21d5681  vmovaps xmm7, [rsp+0x70]
00007d0bb21d5687  vmovaps xmm8, [rsp+0x80]
00007d0bb21d5690  vmovaps xmm9, [rsp+0x90]
00007d0bb21d5699  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d56a2  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d56ab  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d56b4  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d56bd  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d56c6  add rsp, 0xF0
00007d0bb21d56cd  pop r11
00007d0bb21d56cf  pop r10
00007d0bb21d56d1  pop r9
00007d0bb21d56d3  pop r8
00007d0bb21d56d5  pop rsi
00007d0bb21d56d6  pop rdi
00007d0bb21d56d7  pop rdx
00007d0bb21d56d8  pop rcx
00007d0bb21d56d9  pop rax
00007d0bb21d56da  add rsp, 0x08
00007d0bb21d56de  jmp 0x00007D0BB21D2E9D
00007d0bb21d56e3  call 0x00007D0BB1FFF430
00007d0bb21d56e8  jmp 0x00007D0BB21D2EAA
00007d0bb21d56ed  sub rsp, 0x08
00007d0bb21d56f1  push rax
00007d0bb21d56f2  push rcx
00007d0bb21d56f3  push rdx
00007d0bb21d56f4  push rdi
00007d0bb21d56f5  push rsi
00007d0bb21d56f6  push r8
00007d0bb21d56f8  push r9
00007d0bb21d56fa  push r10
00007d0bb21d56fc  push r11
00007d0bb21d56fe  sub rsp, 0xF0
00007d0bb21d5705  vmovaps [rsp], xmm0
00007d0bb21d570a  vmovaps [rsp+0x10], xmm1
00007d0bb21d5710  vmovaps [rsp+0x20], xmm2
00007d0bb21d5716  vmovaps [rsp+0x30], xmm3
00007d0bb21d571c  vmovaps [rsp+0x40], xmm4
00007d0bb21d5722  vmovaps [rsp+0x50], xmm5
00007d0bb21d5728  vmovaps [rsp+0x60], xmm6
00007d0bb21d572e  vmovaps [rsp+0x70], xmm7
00007d0bb21d5734  vmovaps [rsp+0x80], xmm8
00007d0bb21d573d  vmovaps [rsp+0x90], xmm9
00007d0bb21d5746  vmovaps [rsp+0xA0], xmm10
00007d0bb21d574f  vmovaps [rsp+0xB0], xmm11
00007d0bb21d5758  vmovaps [rsp+0xC0], xmm12
00007d0bb21d5761  vmovaps [rsp+0xD0], xmm13
00007d0bb21d576a  vmovaps [rsp+0xE0], xmm14
00007d0bb21d5773  sub rsp, 0x30
00007d0bb21d5777  movaps [rsp], xmm15
00007d0bb21d577c  movaps [rsp+0x10], xmm11
00007d0bb21d5782  movaps [rsp+0x20], xmm1
00007d0bb21d5787  lea rdi, [rsp]
00007d0bb21d578b  mov esi, 0x00
00007d0bb21d5790  mov rax, 0x6392BBE7F530
00007d0bb21d579a  call rax
00007d0bb21d579c  movaps xmm15, [rsp]
00007d0bb21d57a1  add rsp, 0x30
00007d0bb21d57a5  vmovaps xmm0, [rsp]
00007d0bb21d57aa  vmovaps xmm1, [rsp+0x10]
00007d0bb21d57b0  vmovaps xmm2, [rsp+0x20]
00007d0bb21d57b6  vmovaps xmm3, [rsp+0x30]
00007d0bb21d57bc  vmovaps xmm4, [rsp+0x40]
00007d0bb21d57c2  vmovaps xmm5, [rsp+0x50]
00007d0bb21d57c8  vmovaps xmm6, [rsp+0x60]
00007d0bb21d57ce  vmovaps xmm7, [rsp+0x70]
00007d0bb21d57d4  vmovaps xmm8, [rsp+0x80]
00007d0bb21d57dd  vmovaps xmm9, [rsp+0x90]
00007d0bb21d57e6  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d57ef  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d57f8  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d5801  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d580a  vmovaps xmm14, [rsp+0xE0]
00007d0bb21d5813  add rsp, 0xF0
00007d0bb21d581a  pop r11
00007d0bb21d581c  pop r10
00007d0bb21d581e  pop r9
00007d0bb21d5820  pop r8
00007d0bb21d5822  pop rsi
00007d0bb21d5823  pop rdi
00007d0bb21d5824  pop rdx
00007d0bb21d5825  pop rcx
00007d0bb21d5826  pop rax
00007d0bb21d5827  add rsp, 0x08
00007d0bb21d582b  jmp 0x00007D0BB21D2EE3
00007d0bb21d5830  sub rsp, 0x08
00007d0bb21d5834  push rax
00007d0bb21d5835  push rcx
00007d0bb21d5836  push rdx
00007d0bb21d5837  push rdi
00007d0bb21d5838  push rsi
00007d0bb21d5839  push r8
00007d0bb21d583b  push r9
00007d0bb21d583d  push r10
00007d0bb21d583f  push r11
00007d0bb21d5841  sub rsp, 0xF0
00007d0bb21d5848  vmovaps [rsp], xmm0
00007d0bb21d584d  vmovaps [rsp+0x10], xmm1
00007d0bb21d5853  vmovaps [rsp+0x20], xmm2
00007d0bb21d5859  vmovaps [rsp+0x30], xmm3
00007d0bb21d585f  vmovaps [rsp+0x40], xmm4
00007d0bb21d5865  vmovaps [rsp+0x50], xmm5
00007d0bb21d586b  vmovaps [rsp+0x60], xmm6
00007d0bb21d5871  vmovaps [rsp+0x70], xmm7
00007d0bb21d5877  vmovaps [rsp+0x80], xmm8
00007d0bb21d5880  vmovaps [rsp+0x90], xmm9
00007d0bb21d5889  vmovaps [rsp+0xA0], xmm10
00007d0bb21d5892  vmovaps [rsp+0xB0], xmm12
00007d0bb21d589b  vmovaps [rsp+0xC0], xmm13
00007d0bb21d58a4  vmovaps [rsp+0xD0], xmm14
00007d0bb21d58ad  vmovaps [rsp+0xE0], xmm15
00007d0bb21d58b6  sub rsp, 0x30
00007d0bb21d58ba  movaps [rsp], xmm11
00007d0bb21d58bf  movaps [rsp+0x10], xmm6
00007d0bb21d58c4  movaps [rsp+0x20], xmm14
00007d0bb21d58ca  lea rdi, [rsp]
00007d0bb21d58ce  mov esi, 0x00
00007d0bb21d58d3  mov rax, 0x6392BBE7F530
00007d0bb21d58dd  call rax
00007d0bb21d58df  movaps xmm11, [rsp]
00007d0bb21d58e4  add rsp, 0x30
00007d0bb21d58e8  vmovaps xmm0, [rsp]
00007d0bb21d58ed  vmovaps xmm1, [rsp+0x10]
00007d0bb21d58f3  vmovaps xmm2, [rsp+0x20]
00007d0bb21d58f9  vmovaps xmm3, [rsp+0x30]
00007d0bb21d58ff  vmovaps xmm4, [rsp+0x40]
00007d0bb21d5905  vmovaps xmm5, [rsp+0x50]
00007d0bb21d590b  vmovaps xmm6, [rsp+0x60]
00007d0bb21d5911  vmovaps xmm7, [rsp+0x70]
00007d0bb21d5917  vmovaps xmm8, [rsp+0x80]
00007d0bb21d5920  vmovaps xmm9, [rsp+0x90]
00007d0bb21d5929  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d5932  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d593b  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d5944  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d594d  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d5956  add rsp, 0xF0
00007d0bb21d595d  pop r11
00007d0bb21d595f  pop r10
00007d0bb21d5961  pop r9
00007d0bb21d5963  pop r8
00007d0bb21d5965  pop rsi
00007d0bb21d5966  pop rdi
00007d0bb21d5967  pop rdx
00007d0bb21d5968  pop rcx
00007d0bb21d5969  pop rax
00007d0bb21d596a  add rsp, 0x08
00007d0bb21d596e  jmp 0x00007D0BB21D2F5B
00007d0bb21d5973  call 0x00007D0BB1FFF430
00007d0bb21d5978  jmp 0x00007D0BB21D2F65
00007d0bb21d597d  sub rsp, 0x08
00007d0bb21d5981  push rax
00007d0bb21d5982  push rcx
00007d0bb21d5983  push rdx
00007d0bb21d5984  push rdi
00007d0bb21d5985  push rsi
00007d0bb21d5986  push r8
00007d0bb21d5988  push r9
00007d0bb21d598a  push r10
00007d0bb21d598c  push r11
00007d0bb21d598e  sub rsp, 0xF0
00007d0bb21d5995  vmovaps [rsp], xmm0
00007d0bb21d599a  vmovaps [rsp+0x10], xmm1
00007d0bb21d59a0  vmovaps [rsp+0x20], xmm2
00007d0bb21d59a6  vmovaps [rsp+0x30], xmm3
00007d0bb21d59ac  vmovaps [rsp+0x40], xmm4
00007d0bb21d59b2  vmovaps [rsp+0x50], xmm5
00007d0bb21d59b8  vmovaps [rsp+0x60], xmm6
00007d0bb21d59be  vmovaps [rsp+0x70], xmm7
00007d0bb21d59c4  vmovaps [rsp+0x80], xmm8
00007d0bb21d59cd  vmovaps [rsp+0x90], xmm9
00007d0bb21d59d6  vmovaps [rsp+0xA0], xmm10
00007d0bb21d59df  vmovaps [rsp+0xB0], xmm11
00007d0bb21d59e8  vmovaps [rsp+0xC0], xmm12
00007d0bb21d59f1  vmovaps [rsp+0xD0], xmm13
00007d0bb21d59fa  vmovaps [rsp+0xE0], xmm15
00007d0bb21d5a03  sub rsp, 0x30
00007d0bb21d5a07  movaps [rsp], xmm14
00007d0bb21d5a0c  movaps [rsp+0x10], xmm6
00007d0bb21d5a11  movaps [rsp+0x20], xmm2
00007d0bb21d5a16  lea rdi, [rsp]
00007d0bb21d5a1a  mov esi, 0x00
00007d0bb21d5a1f  mov rax, 0x6392BBE7F530
00007d0bb21d5a29  call rax
00007d0bb21d5a2b  movaps xmm14, [rsp]
00007d0bb21d5a30  add rsp, 0x30
00007d0bb21d5a34  vmovaps xmm0, [rsp]
00007d0bb21d5a39  vmovaps xmm1, [rsp+0x10]
00007d0bb21d5a3f  vmovaps xmm2, [rsp+0x20]
00007d0bb21d5a45  vmovaps xmm3, [rsp+0x30]
00007d0bb21d5a4b  vmovaps xmm4, [rsp+0x40]
00007d0bb21d5a51  vmovaps xmm5, [rsp+0x50]
00007d0bb21d5a57  vmovaps xmm6, [rsp+0x60]
00007d0bb21d5a5d  vmovaps xmm7, [rsp+0x70]
00007d0bb21d5a63  vmovaps xmm8, [rsp+0x80]
00007d0bb21d5a6c  vmovaps xmm9, [rsp+0x90]
00007d0bb21d5a75  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d5a7e  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d5a87  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d5a90  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d5a99  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d5aa2  add rsp, 0xF0
00007d0bb21d5aa9  pop r11
00007d0bb21d5aab  pop r10
00007d0bb21d5aad  pop r9
00007d0bb21d5aaf  pop r8
00007d0bb21d5ab1  pop rsi
00007d0bb21d5ab2  pop rdi
00007d0bb21d5ab3  pop rdx
00007d0bb21d5ab4  pop rcx
00007d0bb21d5ab5  pop rax
00007d0bb21d5ab6  add rsp, 0x08
00007d0bb21d5aba  jmp 0x00007D0BB21D2F99
00007d0bb21d5abf  sub rsp, 0x08
00007d0bb21d5ac3  push rax
00007d0bb21d5ac4  push rcx
00007d0bb21d5ac5  push rdx
00007d0bb21d5ac6  push rdi
00007d0bb21d5ac7  push rsi
00007d0bb21d5ac8  push r8
00007d0bb21d5aca  push r9
00007d0bb21d5acc  push r10
00007d0bb21d5ace  push r11
00007d0bb21d5ad0  sub rsp, 0xF0
00007d0bb21d5ad7  vmovaps [rsp], xmm0
00007d0bb21d5adc  vmovaps [rsp+0x10], xmm1
00007d0bb21d5ae2  vmovaps [rsp+0x20], xmm2
00007d0bb21d5ae8  vmovaps [rsp+0x30], xmm3
00007d0bb21d5aee  vmovaps [rsp+0x40], xmm4
00007d0bb21d5af4  vmovaps [rsp+0x50], xmm5
00007d0bb21d5afa  vmovaps [rsp+0x60], xmm7
00007d0bb21d5b00  vmovaps [rsp+0x70], xmm8
00007d0bb21d5b06  vmovaps [rsp+0x80], xmm9
00007d0bb21d5b0f  vmovaps [rsp+0x90], xmm10
00007d0bb21d5b18  vmovaps [rsp+0xA0], xmm11
00007d0bb21d5b21  vmovaps [rsp+0xB0], xmm12
00007d0bb21d5b2a  vmovaps [rsp+0xC0], xmm13
00007d0bb21d5b33  vmovaps [rsp+0xD0], xmm14
00007d0bb21d5b3c  vmovaps [rsp+0xE0], xmm15
00007d0bb21d5b45  sub rsp, 0x30
00007d0bb21d5b49  movaps [rsp], xmm6
00007d0bb21d5b4d  movaps [rsp+0x10], xmm5
00007d0bb21d5b52  movaps [rsp+0x20], xmm1
00007d0bb21d5b57  lea rdi, [rsp]
00007d0bb21d5b5b  mov esi, 0x00
00007d0bb21d5b60  mov rax, 0x6392BBE7F530
00007d0bb21d5b6a  call rax
00007d0bb21d5b6c  movaps xmm6, [rsp]
00007d0bb21d5b70  add rsp, 0x30
00007d0bb21d5b74  vmovaps xmm0, [rsp]
00007d0bb21d5b79  vmovaps xmm1, [rsp+0x10]
00007d0bb21d5b7f  vmovaps xmm2, [rsp+0x20]
00007d0bb21d5b85  vmovaps xmm3, [rsp+0x30]
00007d0bb21d5b8b  vmovaps xmm4, [rsp+0x40]
00007d0bb21d5b91  vmovaps xmm5, [rsp+0x50]
00007d0bb21d5b97  vmovaps xmm7, [rsp+0x60]
00007d0bb21d5b9d  vmovaps xmm8, [rsp+0x70]
00007d0bb21d5ba3  vmovaps xmm9, [rsp+0x80]
00007d0bb21d5bac  vmovaps xmm10, [rsp+0x90]
00007d0bb21d5bb5  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d5bbe  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d5bc7  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d5bd0  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d5bd9  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d5be2  add rsp, 0xF0
00007d0bb21d5be9  pop r11
00007d0bb21d5beb  pop r10
00007d0bb21d5bed  pop r9
00007d0bb21d5bef  pop r8
00007d0bb21d5bf1  pop rsi
00007d0bb21d5bf2  pop rdi
00007d0bb21d5bf3  pop rdx
00007d0bb21d5bf4  pop rcx
00007d0bb21d5bf5  pop rax
00007d0bb21d5bf6  add rsp, 0x08
00007d0bb21d5bfa  jmp 0x00007D0BB21D2FBF
00007d0bb21d5bff  sub rsp, 0x08
00007d0bb21d5c03  push rax
00007d0bb21d5c04  push rcx
00007d0bb21d5c05  push rdx
00007d0bb21d5c06  push rdi
00007d0bb21d5c07  push rsi
00007d0bb21d5c08  push r8
00007d0bb21d5c0a  push r9
00007d0bb21d5c0c  push r10
00007d0bb21d5c0e  push r11
00007d0bb21d5c10  sub rsp, 0xF0
00007d0bb21d5c17  vmovaps [rsp], xmm0
00007d0bb21d5c1c  vmovaps [rsp+0x10], xmm2
00007d0bb21d5c22  vmovaps [rsp+0x20], xmm3
00007d0bb21d5c28  vmovaps [rsp+0x30], xmm4
00007d0bb21d5c2e  vmovaps [rsp+0x40], xmm5
00007d0bb21d5c34  vmovaps [rsp+0x50], xmm6
00007d0bb21d5c3a  vmovaps [rsp+0x60], xmm7
00007d0bb21d5c40  vmovaps [rsp+0x70], xmm8
00007d0bb21d5c46  vmovaps [rsp+0x80], xmm9
00007d0bb21d5c4f  vmovaps [rsp+0x90], xmm10
00007d0bb21d5c58  vmovaps [rsp+0xA0], xmm11
00007d0bb21d5c61  vmovaps [rsp+0xB0], xmm12
00007d0bb21d5c6a  vmovaps [rsp+0xC0], xmm13
00007d0bb21d5c73  vmovaps [rsp+0xD0], xmm14
00007d0bb21d5c7c  vmovaps [rsp+0xE0], xmm15
00007d0bb21d5c85  sub rsp, 0x30
00007d0bb21d5c89  movaps [rsp], xmm1
00007d0bb21d5c8d  movaps [rsp+0x10], xmm5
00007d0bb21d5c92  movaps [rsp+0x20], xmm13
00007d0bb21d5c98  lea rdi, [rsp]
00007d0bb21d5c9c  mov esi, 0x00
00007d0bb21d5ca1  mov rax, 0x6392BBE7F530
00007d0bb21d5cab  call rax
00007d0bb21d5cad  movaps xmm1, [rsp]
00007d0bb21d5cb1  add rsp, 0x30
00007d0bb21d5cb5  vmovaps xmm0, [rsp]
00007d0bb21d5cba  vmovaps xmm2, [rsp+0x10]
00007d0bb21d5cc0  vmovaps xmm3, [rsp+0x20]
00007d0bb21d5cc6  vmovaps xmm4, [rsp+0x30]
00007d0bb21d5ccc  vmovaps xmm5, [rsp+0x40]
00007d0bb21d5cd2  vmovaps xmm6, [rsp+0x50]
00007d0bb21d5cd8  vmovaps xmm7, [rsp+0x60]
00007d0bb21d5cde  vmovaps xmm8, [rsp+0x70]
00007d0bb21d5ce4  vmovaps xmm9, [rsp+0x80]
00007d0bb21d5ced  vmovaps xmm10, [rsp+0x90]
00007d0bb21d5cf6  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d5cff  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d5d08  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d5d11  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d5d1a  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d5d23  add rsp, 0xF0
00007d0bb21d5d2a  pop r11
00007d0bb21d5d2c  pop r10
00007d0bb21d5d2e  pop r9
00007d0bb21d5d30  pop r8
00007d0bb21d5d32  pop rsi
00007d0bb21d5d33  pop rdi
00007d0bb21d5d34  pop rdx
00007d0bb21d5d35  pop rcx
00007d0bb21d5d36  pop rax
00007d0bb21d5d37  add rsp, 0x08
00007d0bb21d5d3b  jmp 0x00007D0BB21D2FDD
00007d0bb21d5d40  sub rsp, 0x08
00007d0bb21d5d44  push rax
00007d0bb21d5d45  push rcx
00007d0bb21d5d46  push rdx
00007d0bb21d5d47  push rdi
00007d0bb21d5d48  push rsi
00007d0bb21d5d49  push r8
00007d0bb21d5d4b  push r9
00007d0bb21d5d4d  push r10
00007d0bb21d5d4f  push r11
00007d0bb21d5d51  sub rsp, 0xF0
00007d0bb21d5d58  vmovaps [rsp], xmm0
00007d0bb21d5d5d  vmovaps [rsp+0x10], xmm1
00007d0bb21d5d63  vmovaps [rsp+0x20], xmm2
00007d0bb21d5d69  vmovaps [rsp+0x30], xmm3
00007d0bb21d5d6f  vmovaps [rsp+0x40], xmm4
00007d0bb21d5d75  vmovaps [rsp+0x50], xmm6
00007d0bb21d5d7b  vmovaps [rsp+0x60], xmm7
00007d0bb21d5d81  vmovaps [rsp+0x70], xmm8
00007d0bb21d5d87  vmovaps [rsp+0x80], xmm9
00007d0bb21d5d90  vmovaps [rsp+0x90], xmm10
00007d0bb21d5d99  vmovaps [rsp+0xA0], xmm11
00007d0bb21d5da2  vmovaps [rsp+0xB0], xmm12
00007d0bb21d5dab  vmovaps [rsp+0xC0], xmm13
00007d0bb21d5db4  vmovaps [rsp+0xD0], xmm14
00007d0bb21d5dbd  vmovaps [rsp+0xE0], xmm15
00007d0bb21d5dc6  sub rsp, 0x30
00007d0bb21d5dca  movaps [rsp], xmm5
00007d0bb21d5dce  movaps [rsp+0x10], xmm2
00007d0bb21d5dd3  movaps [rsp+0x20], xmm13
00007d0bb21d5dd9  lea rdi, [rsp]
00007d0bb21d5ddd  mov esi, 0x00
00007d0bb21d5de2  mov rax, 0x6392BBE7F530
00007d0bb21d5dec  call rax
00007d0bb21d5dee  movaps xmm5, [rsp]
00007d0bb21d5df2  add rsp, 0x30
00007d0bb21d5df6  vmovaps xmm0, [rsp]
00007d0bb21d5dfb  vmovaps xmm1, [rsp+0x10]
00007d0bb21d5e01  vmovaps xmm2, [rsp+0x20]
00007d0bb21d5e07  vmovaps xmm3, [rsp+0x30]
00007d0bb21d5e0d  vmovaps xmm4, [rsp+0x40]
00007d0bb21d5e13  vmovaps xmm6, [rsp+0x50]
00007d0bb21d5e19  vmovaps xmm7, [rsp+0x60]
00007d0bb21d5e1f  vmovaps xmm8, [rsp+0x70]
00007d0bb21d5e25  vmovaps xmm9, [rsp+0x80]
00007d0bb21d5e2e  vmovaps xmm10, [rsp+0x90]
00007d0bb21d5e37  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d5e40  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d5e49  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d5e52  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d5e5b  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d5e64  add rsp, 0xF0
00007d0bb21d5e6b  pop r11
00007d0bb21d5e6d  pop r10
00007d0bb21d5e6f  pop r9
00007d0bb21d5e71  pop r8
00007d0bb21d5e73  pop rsi
00007d0bb21d5e74  pop rdi
00007d0bb21d5e75  pop rdx
00007d0bb21d5e76  pop rcx
00007d0bb21d5e77  pop rax
00007d0bb21d5e78  add rsp, 0x08
00007d0bb21d5e7c  jmp 0x00007D0BB21D3013
00007d0bb21d5e81  sub rsp, 0x08
00007d0bb21d5e85  push rax
00007d0bb21d5e86  push rcx
00007d0bb21d5e87  push rdx
00007d0bb21d5e88  push rdi
00007d0bb21d5e89  push rsi
00007d0bb21d5e8a  push r8
00007d0bb21d5e8c  push r9
00007d0bb21d5e8e  push r10
00007d0bb21d5e90  push r11
00007d0bb21d5e92  sub rsp, 0xF0
00007d0bb21d5e99  vmovaps [rsp], xmm0
00007d0bb21d5e9e  vmovaps [rsp+0x10], xmm1
00007d0bb21d5ea4  vmovaps [rsp+0x20], xmm2
00007d0bb21d5eaa  vmovaps [rsp+0x30], xmm3
00007d0bb21d5eb0  vmovaps [rsp+0x40], xmm4
00007d0bb21d5eb6  vmovaps [rsp+0x50], xmm5
00007d0bb21d5ebc  vmovaps [rsp+0x60], xmm6
00007d0bb21d5ec2  vmovaps [rsp+0x70], xmm7
00007d0bb21d5ec8  vmovaps [rsp+0x80], xmm8
00007d0bb21d5ed1  vmovaps [rsp+0x90], xmm9
00007d0bb21d5eda  vmovaps [rsp+0xA0], xmm10
00007d0bb21d5ee3  vmovaps [rsp+0xB0], xmm11
00007d0bb21d5eec  vmovaps [rsp+0xC0], xmm12
00007d0bb21d5ef5  vmovaps [rsp+0xD0], xmm14
00007d0bb21d5efe  vmovaps [rsp+0xE0], xmm15
00007d0bb21d5f07  sub rsp, 0x30
00007d0bb21d5f0b  movaps [rsp], xmm13
00007d0bb21d5f10  movaps [rsp+0x10], xmm10
00007d0bb21d5f16  movaps [rsp+0x20], xmm1
00007d0bb21d5f1b  lea rdi, [rsp]
00007d0bb21d5f1f  mov esi, 0x00
00007d0bb21d5f24  mov rax, 0x6392BBE7F530
00007d0bb21d5f2e  call rax
00007d0bb21d5f30  movaps xmm13, [rsp]
00007d0bb21d5f35  add rsp, 0x30
00007d0bb21d5f39  vmovaps xmm0, [rsp]
00007d0bb21d5f3e  vmovaps xmm1, [rsp+0x10]
00007d0bb21d5f44  vmovaps xmm2, [rsp+0x20]
00007d0bb21d5f4a  vmovaps xmm3, [rsp+0x30]
00007d0bb21d5f50  vmovaps xmm4, [rsp+0x40]
00007d0bb21d5f56  vmovaps xmm5, [rsp+0x50]
00007d0bb21d5f5c  vmovaps xmm6, [rsp+0x60]
00007d0bb21d5f62  vmovaps xmm7, [rsp+0x70]
00007d0bb21d5f68  vmovaps xmm8, [rsp+0x80]
00007d0bb21d5f71  vmovaps xmm9, [rsp+0x90]
00007d0bb21d5f7a  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d5f83  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d5f8c  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d5f95  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d5f9e  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d5fa7  add rsp, 0xF0
00007d0bb21d5fae  pop r11
00007d0bb21d5fb0  pop r10
00007d0bb21d5fb2  pop r9
00007d0bb21d5fb4  pop r8
00007d0bb21d5fb6  pop rsi
00007d0bb21d5fb7  pop rdi
00007d0bb21d5fb8  pop rdx
00007d0bb21d5fb9  pop rcx
00007d0bb21d5fba  pop rax
00007d0bb21d5fbb  add rsp, 0x08
00007d0bb21d5fbf  jmp 0x00007D0BB21D303C
00007d0bb21d5fc4  sub rsp, 0x08
00007d0bb21d5fc8  push rax
00007d0bb21d5fc9  push rcx
00007d0bb21d5fca  push rdx
00007d0bb21d5fcb  push rdi
00007d0bb21d5fcc  push rsi
00007d0bb21d5fcd  push r8
00007d0bb21d5fcf  push r9
00007d0bb21d5fd1  push r10
00007d0bb21d5fd3  push r11
00007d0bb21d5fd5  sub rsp, 0xF0
00007d0bb21d5fdc  vmovaps [rsp], xmm0
00007d0bb21d5fe1  vmovaps [rsp+0x10], xmm2
00007d0bb21d5fe7  vmovaps [rsp+0x20], xmm3
00007d0bb21d5fed  vmovaps [rsp+0x30], xmm4
00007d0bb21d5ff3  vmovaps [rsp+0x40], xmm5
00007d0bb21d5ff9  vmovaps [rsp+0x50], xmm6
00007d0bb21d5fff  vmovaps [rsp+0x60], xmm7
00007d0bb21d6005  vmovaps [rsp+0x70], xmm8
00007d0bb21d600b  vmovaps [rsp+0x80], xmm9
00007d0bb21d6014  vmovaps [rsp+0x90], xmm10
00007d0bb21d601d  vmovaps [rsp+0xA0], xmm11
00007d0bb21d6026  vmovaps [rsp+0xB0], xmm12
00007d0bb21d602f  vmovaps [rsp+0xC0], xmm13
00007d0bb21d6038  vmovaps [rsp+0xD0], xmm14
00007d0bb21d6041  vmovaps [rsp+0xE0], xmm15
00007d0bb21d604a  sub rsp, 0x30
00007d0bb21d604e  movaps [rsp], xmm1
00007d0bb21d6052  movaps [rsp+0x10], xmm15
00007d0bb21d6058  movaps [rsp+0x20], xmm10
00007d0bb21d605e  lea rdi, [rsp]
00007d0bb21d6062  mov esi, 0x00
00007d0bb21d6067  mov rax, 0x6392BBE7F530
00007d0bb21d6071  call rax
00007d0bb21d6073  movaps xmm1, [rsp]
00007d0bb21d6077  add rsp, 0x30
00007d0bb21d607b  vmovaps xmm0, [rsp]
00007d0bb21d6080  vmovaps xmm2, [rsp+0x10]
00007d0bb21d6086  vmovaps xmm3, [rsp+0x20]
00007d0bb21d608c  vmovaps xmm4, [rsp+0x30]
00007d0bb21d6092  vmovaps xmm5, [rsp+0x40]
00007d0bb21d6098  vmovaps xmm6, [rsp+0x50]
00007d0bb21d609e  vmovaps xmm7, [rsp+0x60]
00007d0bb21d60a4  vmovaps xmm8, [rsp+0x70]
00007d0bb21d60aa  vmovaps xmm9, [rsp+0x80]
00007d0bb21d60b3  vmovaps xmm10, [rsp+0x90]
00007d0bb21d60bc  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d60c5  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d60ce  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d60d7  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d60e0  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d60e9  add rsp, 0xF0
00007d0bb21d60f0  pop r11
00007d0bb21d60f2  pop r10
00007d0bb21d60f4  pop r9
00007d0bb21d60f6  pop r8
00007d0bb21d60f8  pop rsi
00007d0bb21d60f9  pop rdi
00007d0bb21d60fa  pop rdx
00007d0bb21d60fb  pop rcx
00007d0bb21d60fc  pop rax
00007d0bb21d60fd  add rsp, 0x08
00007d0bb21d6101  jmp 0x00007D0BB21D305B
00007d0bb21d6106  sub rsp, 0x08
00007d0bb21d610a  push rax
00007d0bb21d610b  push rcx
00007d0bb21d610c  push rdx
00007d0bb21d610d  push rdi
00007d0bb21d610e  push rsi
00007d0bb21d610f  push r8
00007d0bb21d6111  push r9
00007d0bb21d6113  push r10
00007d0bb21d6115  push r11
00007d0bb21d6117  sub rsp, 0xF0
00007d0bb21d611e  vmovaps [rsp], xmm0
00007d0bb21d6123  vmovaps [rsp+0x10], xmm1
00007d0bb21d6129  vmovaps [rsp+0x20], xmm2
00007d0bb21d612f  vmovaps [rsp+0x30], xmm3
00007d0bb21d6135  vmovaps [rsp+0x40], xmm4
00007d0bb21d613b  vmovaps [rsp+0x50], xmm5
00007d0bb21d6141  vmovaps [rsp+0x60], xmm6
00007d0bb21d6147  vmovaps [rsp+0x70], xmm7
00007d0bb21d614d  vmovaps [rsp+0x80], xmm8
00007d0bb21d6156  vmovaps [rsp+0x90], xmm9
00007d0bb21d615f  vmovaps [rsp+0xA0], xmm10
00007d0bb21d6168  vmovaps [rsp+0xB0], xmm11
00007d0bb21d6171  vmovaps [rsp+0xC0], xmm12
00007d0bb21d617a  vmovaps [rsp+0xD0], xmm13
00007d0bb21d6183  vmovaps [rsp+0xE0], xmm14
00007d0bb21d618c  sub rsp, 0x30
00007d0bb21d6190  movaps [rsp], xmm15
00007d0bb21d6195  movaps [rsp+0x10], xmm10
00007d0bb21d619b  movaps [rsp+0x20], xmm11
00007d0bb21d61a1  lea rdi, [rsp]
00007d0bb21d61a5  mov esi, 0x00
00007d0bb21d61aa  mov rax, 0x6392BBE7F530
00007d0bb21d61b4  call rax
00007d0bb21d61b6  movaps xmm15, [rsp]
00007d0bb21d61bb  add rsp, 0x30
00007d0bb21d61bf  vmovaps xmm0, [rsp]
00007d0bb21d61c4  vmovaps xmm1, [rsp+0x10]
00007d0bb21d61ca  vmovaps xmm2, [rsp+0x20]
00007d0bb21d61d0  vmovaps xmm3, [rsp+0x30]
00007d0bb21d61d6  vmovaps xmm4, [rsp+0x40]
00007d0bb21d61dc  vmovaps xmm5, [rsp+0x50]
00007d0bb21d61e2  vmovaps xmm6, [rsp+0x60]
00007d0bb21d61e8  vmovaps xmm7, [rsp+0x70]
00007d0bb21d61ee  vmovaps xmm8, [rsp+0x80]
00007d0bb21d61f7  vmovaps xmm9, [rsp+0x90]
00007d0bb21d6200  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d6209  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d6212  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d621b  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d6224  vmovaps xmm14, [rsp+0xE0]
00007d0bb21d622d  add rsp, 0xF0
00007d0bb21d6234  pop r11
00007d0bb21d6236  pop r10
00007d0bb21d6238  pop r9
00007d0bb21d623a  pop r8
00007d0bb21d623c  pop rsi
00007d0bb21d623d  pop rdi
00007d0bb21d623e  pop rdx
00007d0bb21d623f  pop rcx
00007d0bb21d6240  pop rax
00007d0bb21d6241  add rsp, 0x08
00007d0bb21d6245  jmp 0x00007D0BB21D307E
00007d0bb21d624a  sub rsp, 0x08
00007d0bb21d624e  push rax
00007d0bb21d624f  push rcx
00007d0bb21d6250  push rdx
00007d0bb21d6251  push rdi
00007d0bb21d6252  push rsi
00007d0bb21d6253  push r8
00007d0bb21d6255  push r9
00007d0bb21d6257  push r10
00007d0bb21d6259  push r11
00007d0bb21d625b  sub rsp, 0xF0
00007d0bb21d6262  vmovaps [rsp], xmm0
00007d0bb21d6267  vmovaps [rsp+0x10], xmm1
00007d0bb21d626d  vmovaps [rsp+0x20], xmm2
00007d0bb21d6273  vmovaps [rsp+0x30], xmm3
00007d0bb21d6279  vmovaps [rsp+0x40], xmm4
00007d0bb21d627f  vmovaps [rsp+0x50], xmm5
00007d0bb21d6285  vmovaps [rsp+0x60], xmm6
00007d0bb21d628b  vmovaps [rsp+0x70], xmm7
00007d0bb21d6291  vmovaps [rsp+0x80], xmm8
00007d0bb21d629a  vmovaps [rsp+0x90], xmm9
00007d0bb21d62a3  vmovaps [rsp+0xA0], xmm11
00007d0bb21d62ac  vmovaps [rsp+0xB0], xmm12
00007d0bb21d62b5  vmovaps [rsp+0xC0], xmm13
00007d0bb21d62be  vmovaps [rsp+0xD0], xmm14
00007d0bb21d62c7  vmovaps [rsp+0xE0], xmm15
00007d0bb21d62d0  sub rsp, 0x30
00007d0bb21d62d4  movaps [rsp], xmm10
00007d0bb21d62d9  movaps [rsp+0x10], xmm2
00007d0bb21d62de  movaps [rsp+0x20], xmm11
00007d0bb21d62e4  lea rdi, [rsp]
00007d0bb21d62e8  mov esi, 0x00
00007d0bb21d62ed  mov rax, 0x6392BBE7F530
00007d0bb21d62f7  call rax
00007d0bb21d62f9  movaps xmm10, [rsp]
00007d0bb21d62fe  add rsp, 0x30
00007d0bb21d6302  vmovaps xmm0, [rsp]
00007d0bb21d6307  vmovaps xmm1, [rsp+0x10]
00007d0bb21d630d  vmovaps xmm2, [rsp+0x20]
00007d0bb21d6313  vmovaps xmm3, [rsp+0x30]
00007d0bb21d6319  vmovaps xmm4, [rsp+0x40]
00007d0bb21d631f  vmovaps xmm5, [rsp+0x50]
00007d0bb21d6325  vmovaps xmm6, [rsp+0x60]
00007d0bb21d632b  vmovaps xmm7, [rsp+0x70]
00007d0bb21d6331  vmovaps xmm8, [rsp+0x80]
00007d0bb21d633a  vmovaps xmm9, [rsp+0x90]
00007d0bb21d6343  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d634c  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d6355  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d635e  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d6367  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d6370  add rsp, 0xF0
00007d0bb21d6377  pop r11
00007d0bb21d6379  pop r10
00007d0bb21d637b  pop r9
00007d0bb21d637d  pop r8
00007d0bb21d637f  pop rsi
00007d0bb21d6380  pop rdi
00007d0bb21d6381  pop rdx
00007d0bb21d6382  pop rcx
00007d0bb21d6383  pop rax
00007d0bb21d6384  add rsp, 0x08
00007d0bb21d6388  jmp 0x00007D0BB21D30B6
00007d0bb21d638d  sub rsp, 0x08
00007d0bb21d6391  push rax
00007d0bb21d6392  push rcx
00007d0bb21d6393  push rdx
00007d0bb21d6394  push rdi
00007d0bb21d6395  push rsi
00007d0bb21d6396  push r8
00007d0bb21d6398  push r9
00007d0bb21d639a  push r10
00007d0bb21d639c  push r11
00007d0bb21d639e  sub rsp, 0xF0
00007d0bb21d63a5  vmovaps [rsp], xmm0
00007d0bb21d63aa  vmovaps [rsp+0x10], xmm1
00007d0bb21d63b0  vmovaps [rsp+0x20], xmm2
00007d0bb21d63b6  vmovaps [rsp+0x30], xmm3
00007d0bb21d63bc  vmovaps [rsp+0x40], xmm4
00007d0bb21d63c2  vmovaps [rsp+0x50], xmm5
00007d0bb21d63c8  vmovaps [rsp+0x60], xmm6
00007d0bb21d63ce  vmovaps [rsp+0x70], xmm7
00007d0bb21d63d4  vmovaps [rsp+0x80], xmm8
00007d0bb21d63dd  vmovaps [rsp+0x90], xmm9
00007d0bb21d63e6  vmovaps [rsp+0xA0], xmm10
00007d0bb21d63ef  vmovaps [rsp+0xB0], xmm12
00007d0bb21d63f8  vmovaps [rsp+0xC0], xmm13
00007d0bb21d6401  vmovaps [rsp+0xD0], xmm14
00007d0bb21d640a  vmovaps [rsp+0xE0], xmm15
00007d0bb21d6413  sub rsp, 0x30
00007d0bb21d6417  movaps [rsp], xmm11
00007d0bb21d641c  movaps [rsp+0x10], xmm2
00007d0bb21d6421  movaps [rsp+0x20], xmm1
00007d0bb21d6426  lea rdi, [rsp]
00007d0bb21d642a  mov esi, 0x00
00007d0bb21d642f  mov rax, 0x6392BBE7F530
00007d0bb21d6439  call rax
00007d0bb21d643b  movaps xmm11, [rsp]
00007d0bb21d6440  add rsp, 0x30
00007d0bb21d6444  vmovaps xmm0, [rsp]
00007d0bb21d6449  vmovaps xmm1, [rsp+0x10]
00007d0bb21d644f  vmovaps xmm2, [rsp+0x20]
00007d0bb21d6455  vmovaps xmm3, [rsp+0x30]
00007d0bb21d645b  vmovaps xmm4, [rsp+0x40]
00007d0bb21d6461  vmovaps xmm5, [rsp+0x50]
00007d0bb21d6467  vmovaps xmm6, [rsp+0x60]
00007d0bb21d646d  vmovaps xmm7, [rsp+0x70]
00007d0bb21d6473  vmovaps xmm8, [rsp+0x80]
00007d0bb21d647c  vmovaps xmm9, [rsp+0x90]
00007d0bb21d6485  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d648e  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d6497  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d64a0  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d64a9  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d64b2  add rsp, 0xF0
00007d0bb21d64b9  pop r11
00007d0bb21d64bb  pop r10
00007d0bb21d64bd  pop r9
00007d0bb21d64bf  pop r8
00007d0bb21d64c1  pop rsi
00007d0bb21d64c2  pop rdi
00007d0bb21d64c3  pop rdx
00007d0bb21d64c4  pop rcx
00007d0bb21d64c5  pop rax
00007d0bb21d64c6  add rsp, 0x08
00007d0bb21d64ca  jmp 0x00007D0BB21D30F2
00007d0bb21d64cf  sub rsp, 0x08
00007d0bb21d64d3  push rax
00007d0bb21d64d4  push rcx
00007d0bb21d64d5  push rdx
00007d0bb21d64d6  push rdi
00007d0bb21d64d7  push rsi
00007d0bb21d64d8  push r8
00007d0bb21d64da  push r9
00007d0bb21d64dc  push r10
00007d0bb21d64de  push r11
00007d0bb21d64e0  sub rsp, 0xF0
00007d0bb21d64e7  vmovaps [rsp], xmm0
00007d0bb21d64ec  vmovaps [rsp+0x10], xmm2
00007d0bb21d64f2  vmovaps [rsp+0x20], xmm3
00007d0bb21d64f8  vmovaps [rsp+0x30], xmm4
00007d0bb21d64fe  vmovaps [rsp+0x40], xmm5
00007d0bb21d6504  vmovaps [rsp+0x50], xmm6
00007d0bb21d650a  vmovaps [rsp+0x60], xmm7
00007d0bb21d6510  vmovaps [rsp+0x70], xmm8
00007d0bb21d6516  vmovaps [rsp+0x80], xmm9
00007d0bb21d651f  vmovaps [rsp+0x90], xmm10
00007d0bb21d6528  vmovaps [rsp+0xA0], xmm11
00007d0bb21d6531  vmovaps [rsp+0xB0], xmm12
00007d0bb21d653a  vmovaps [rsp+0xC0], xmm13
00007d0bb21d6543  vmovaps [rsp+0xD0], xmm14
00007d0bb21d654c  vmovaps [rsp+0xE0], xmm15
00007d0bb21d6555  sub rsp, 0x30
00007d0bb21d6559  movaps [rsp], xmm1
00007d0bb21d655d  movaps [rsp+0x10], xmm14
00007d0bb21d6563  movaps [rsp+0x20], xmm6
00007d0bb21d6568  lea rdi, [rsp]
00007d0bb21d656c  mov esi, 0x00
00007d0bb21d6571  mov rax, 0x6392BBE7F530
00007d0bb21d657b  call rax
00007d0bb21d657d  movaps xmm1, [rsp]
00007d0bb21d6581  add rsp, 0x30
00007d0bb21d6585  vmovaps xmm0, [rsp]
00007d0bb21d658a  vmovaps xmm2, [rsp+0x10]
00007d0bb21d6590  vmovaps xmm3, [rsp+0x20]
00007d0bb21d6596  vmovaps xmm4, [rsp+0x30]
00007d0bb21d659c  vmovaps xmm5, [rsp+0x40]
00007d0bb21d65a2  vmovaps xmm6, [rsp+0x50]
00007d0bb21d65a8  vmovaps xmm7, [rsp+0x60]
00007d0bb21d65ae  vmovaps xmm8, [rsp+0x70]
00007d0bb21d65b4  vmovaps xmm9, [rsp+0x80]
00007d0bb21d65bd  vmovaps xmm10, [rsp+0x90]
00007d0bb21d65c6  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d65cf  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d65d8  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d65e1  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d65ea  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d65f3  add rsp, 0xF0
00007d0bb21d65fa  pop r11
00007d0bb21d65fc  pop r10
00007d0bb21d65fe  pop r9
00007d0bb21d6600  pop r8
00007d0bb21d6602  pop rsi
00007d0bb21d6603  pop rdi
00007d0bb21d6604  pop rdx
00007d0bb21d6605  pop rcx
00007d0bb21d6606  pop rax
00007d0bb21d6607  add rsp, 0x08
00007d0bb21d660b  jmp 0x00007D0BB21D310B
00007d0bb21d6610  sub rsp, 0x08
00007d0bb21d6614  push rax
00007d0bb21d6615  push rcx
00007d0bb21d6616  push rdx
00007d0bb21d6617  push rdi
00007d0bb21d6618  push rsi
00007d0bb21d6619  push r8
00007d0bb21d661b  push r9
00007d0bb21d661d  push r10
00007d0bb21d661f  push r11
00007d0bb21d6621  sub rsp, 0xF0
00007d0bb21d6628  vmovaps [rsp], xmm0
00007d0bb21d662d  vmovaps [rsp+0x10], xmm1
00007d0bb21d6633  vmovaps [rsp+0x20], xmm2
00007d0bb21d6639  vmovaps [rsp+0x30], xmm3
00007d0bb21d663f  vmovaps [rsp+0x40], xmm4
00007d0bb21d6645  vmovaps [rsp+0x50], xmm5
00007d0bb21d664b  vmovaps [rsp+0x60], xmm6
00007d0bb21d6651  vmovaps [rsp+0x70], xmm7
00007d0bb21d6657  vmovaps [rsp+0x80], xmm8
00007d0bb21d6660  vmovaps [rsp+0x90], xmm9
00007d0bb21d6669  vmovaps [rsp+0xA0], xmm10
00007d0bb21d6672  vmovaps [rsp+0xB0], xmm11
00007d0bb21d667b  vmovaps [rsp+0xC0], xmm12
00007d0bb21d6684  vmovaps [rsp+0xD0], xmm13
00007d0bb21d668d  vmovaps [rsp+0xE0], xmm14
00007d0bb21d6696  sub rsp, 0x30
00007d0bb21d669a  movaps [rsp], xmm15
00007d0bb21d669f  movaps [rsp+0x10], xmm14
00007d0bb21d66a5  movaps [rsp+0x20], xmm5
00007d0bb21d66aa  lea rdi, [rsp]
00007d0bb21d66ae  mov esi, 0x00
00007d0bb21d66b3  mov rax, 0x6392BBE7F530
00007d0bb21d66bd  call rax
00007d0bb21d66bf  movaps xmm15, [rsp]
00007d0bb21d66c4  add rsp, 0x30
00007d0bb21d66c8  vmovaps xmm0, [rsp]
00007d0bb21d66cd  vmovaps xmm1, [rsp+0x10]
00007d0bb21d66d3  vmovaps xmm2, [rsp+0x20]
00007d0bb21d66d9  vmovaps xmm3, [rsp+0x30]
00007d0bb21d66df  vmovaps xmm4, [rsp+0x40]
00007d0bb21d66e5  vmovaps xmm5, [rsp+0x50]
00007d0bb21d66eb  vmovaps xmm6, [rsp+0x60]
00007d0bb21d66f1  vmovaps xmm7, [rsp+0x70]
00007d0bb21d66f7  vmovaps xmm8, [rsp+0x80]
00007d0bb21d6700  vmovaps xmm9, [rsp+0x90]
00007d0bb21d6709  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d6712  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d671b  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d6724  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d672d  vmovaps xmm14, [rsp+0xE0]
00007d0bb21d6736  add rsp, 0xF0
00007d0bb21d673d  pop r11
00007d0bb21d673f  pop r10
00007d0bb21d6741  pop r9
00007d0bb21d6743  pop r8
00007d0bb21d6745  pop rsi
00007d0bb21d6746  pop rdi
00007d0bb21d6747  pop rdx
00007d0bb21d6748  pop rcx
00007d0bb21d6749  pop rax
00007d0bb21d674a  add rsp, 0x08
00007d0bb21d674e  jmp 0x00007D0BB21D312B
00007d0bb21d6753  sub rsp, 0x08
00007d0bb21d6757  push rax
00007d0bb21d6758  push rcx
00007d0bb21d6759  push rdx
00007d0bb21d675a  push rdi
00007d0bb21d675b  push rsi
00007d0bb21d675c  push r8
00007d0bb21d675e  push r9
00007d0bb21d6760  push r10
00007d0bb21d6762  push r11
00007d0bb21d6764  sub rsp, 0xF0
00007d0bb21d676b  vmovaps [rsp], xmm0
00007d0bb21d6770  vmovaps [rsp+0x10], xmm1
00007d0bb21d6776  vmovaps [rsp+0x20], xmm2
00007d0bb21d677c  vmovaps [rsp+0x30], xmm3
00007d0bb21d6782  vmovaps [rsp+0x40], xmm4
00007d0bb21d6788  vmovaps [rsp+0x50], xmm5
00007d0bb21d678e  vmovaps [rsp+0x60], xmm7
00007d0bb21d6794  vmovaps [rsp+0x70], xmm8
00007d0bb21d679a  vmovaps [rsp+0x80], xmm9
00007d0bb21d67a3  vmovaps [rsp+0x90], xmm10
00007d0bb21d67ac  vmovaps [rsp+0xA0], xmm11
00007d0bb21d67b5  vmovaps [rsp+0xB0], xmm12
00007d0bb21d67be  vmovaps [rsp+0xC0], xmm13
00007d0bb21d67c7  vmovaps [rsp+0xD0], xmm14
00007d0bb21d67d0  vmovaps [rsp+0xE0], xmm15
00007d0bb21d67d9  sub rsp, 0x30
00007d0bb21d67dd  movaps [rsp], xmm6
00007d0bb21d67e1  movaps [rsp+0x10], xmm9
00007d0bb21d67e7  movaps [rsp+0x20], xmm14
00007d0bb21d67ed  lea rdi, [rsp]
00007d0bb21d67f1  mov esi, 0x00
00007d0bb21d67f6  mov rax, 0x6392BBE7F530
00007d0bb21d6800  call rax
00007d0bb21d6802  movaps xmm6, [rsp]
00007d0bb21d6806  add rsp, 0x30
00007d0bb21d680a  vmovaps xmm0, [rsp]
00007d0bb21d680f  vmovaps xmm1, [rsp+0x10]
00007d0bb21d6815  vmovaps xmm2, [rsp+0x20]
00007d0bb21d681b  vmovaps xmm3, [rsp+0x30]
00007d0bb21d6821  vmovaps xmm4, [rsp+0x40]
00007d0bb21d6827  vmovaps xmm5, [rsp+0x50]
00007d0bb21d682d  vmovaps xmm7, [rsp+0x60]
00007d0bb21d6833  vmovaps xmm8, [rsp+0x70]
00007d0bb21d6839  vmovaps xmm9, [rsp+0x80]
00007d0bb21d6842  vmovaps xmm10, [rsp+0x90]
00007d0bb21d684b  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d6854  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d685d  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d6866  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d686f  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d6878  add rsp, 0xF0
00007d0bb21d687f  pop r11
00007d0bb21d6881  pop r10
00007d0bb21d6883  pop r9
00007d0bb21d6885  pop r8
00007d0bb21d6887  pop rsi
00007d0bb21d6888  pop rdi
00007d0bb21d6889  pop rdx
00007d0bb21d688a  pop rcx
00007d0bb21d688b  pop rax
00007d0bb21d688c  add rsp, 0x08
00007d0bb21d6890  jmp 0x00007D0BB21D3153
00007d0bb21d6895  sub rsp, 0x08
00007d0bb21d6899  push rax
00007d0bb21d689a  push rcx
00007d0bb21d689b  push rdx
00007d0bb21d689c  push rdi
00007d0bb21d689d  push rsi
00007d0bb21d689e  push r8
00007d0bb21d68a0  push r9
00007d0bb21d68a2  push r10
00007d0bb21d68a4  push r11
00007d0bb21d68a6  sub rsp, 0xF0
00007d0bb21d68ad  vmovaps [rsp], xmm0
00007d0bb21d68b2  vmovaps [rsp+0x10], xmm1
00007d0bb21d68b8  vmovaps [rsp+0x20], xmm2
00007d0bb21d68be  vmovaps [rsp+0x30], xmm3
00007d0bb21d68c4  vmovaps [rsp+0x40], xmm4
00007d0bb21d68ca  vmovaps [rsp+0x50], xmm5
00007d0bb21d68d0  vmovaps [rsp+0x60], xmm6
00007d0bb21d68d6  vmovaps [rsp+0x70], xmm7
00007d0bb21d68dc  vmovaps [rsp+0x80], xmm8
00007d0bb21d68e5  vmovaps [rsp+0x90], xmm9
00007d0bb21d68ee  vmovaps [rsp+0xA0], xmm10
00007d0bb21d68f7  vmovaps [rsp+0xB0], xmm11
00007d0bb21d6900  vmovaps [rsp+0xC0], xmm12
00007d0bb21d6909  vmovaps [rsp+0xD0], xmm13
00007d0bb21d6912  vmovaps [rsp+0xE0], xmm15
00007d0bb21d691b  sub rsp, 0x30
00007d0bb21d691f  movaps [rsp], xmm14
00007d0bb21d6924  movaps [rsp+0x10], xmm9
00007d0bb21d692a  movaps [rsp+0x20], xmm13
00007d0bb21d6930  lea rdi, [rsp]
00007d0bb21d6934  mov esi, 0x00
00007d0bb21d6939  mov rax, 0x6392BBE7F530
00007d0bb21d6943  call rax
00007d0bb21d6945  movaps xmm14, [rsp]
00007d0bb21d694a  add rsp, 0x30
00007d0bb21d694e  vmovaps xmm0, [rsp]
00007d0bb21d6953  vmovaps xmm1, [rsp+0x10]
00007d0bb21d6959  vmovaps xmm2, [rsp+0x20]
00007d0bb21d695f  vmovaps xmm3, [rsp+0x30]
00007d0bb21d6965  vmovaps xmm4, [rsp+0x40]
00007d0bb21d696b  vmovaps xmm5, [rsp+0x50]
00007d0bb21d6971  vmovaps xmm6, [rsp+0x60]
00007d0bb21d6977  vmovaps xmm7, [rsp+0x70]
00007d0bb21d697d  vmovaps xmm8, [rsp+0x80]
00007d0bb21d6986  vmovaps xmm9, [rsp+0x90]
00007d0bb21d698f  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d6998  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d69a1  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d69aa  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d69b3  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d69bc  add rsp, 0xF0
00007d0bb21d69c3  pop r11
00007d0bb21d69c5  pop r10
00007d0bb21d69c7  pop r9
00007d0bb21d69c9  pop r8
00007d0bb21d69cb  pop rsi
00007d0bb21d69cc  pop rdi
00007d0bb21d69cd  pop rdx
00007d0bb21d69ce  pop rcx
00007d0bb21d69cf  pop rax
00007d0bb21d69d0  add rsp, 0x08
00007d0bb21d69d4  jmp 0x00007D0BB21D3176
00007d0bb21d69d9  sub rsp, 0x08
00007d0bb21d69dd  push rax
00007d0bb21d69de  push rcx
00007d0bb21d69df  push rdx
00007d0bb21d69e0  push rdi
00007d0bb21d69e1  push rsi
00007d0bb21d69e2  push r8
00007d0bb21d69e4  push r9
00007d0bb21d69e6  push r10
00007d0bb21d69e8  push r11
00007d0bb21d69ea  sub rsp, 0xF0
00007d0bb21d69f1  vmovaps [rsp], xmm0
00007d0bb21d69f6  vmovaps [rsp+0x10], xmm1
00007d0bb21d69fc  vmovaps [rsp+0x20], xmm2
00007d0bb21d6a02  vmovaps [rsp+0x30], xmm3
00007d0bb21d6a08  vmovaps [rsp+0x40], xmm4
00007d0bb21d6a0e  vmovaps [rsp+0x50], xmm5
00007d0bb21d6a14  vmovaps [rsp+0x60], xmm6
00007d0bb21d6a1a  vmovaps [rsp+0x70], xmm7
00007d0bb21d6a20  vmovaps [rsp+0x80], xmm8
00007d0bb21d6a29  vmovaps [rsp+0x90], xmm9
00007d0bb21d6a32  vmovaps [rsp+0xA0], xmm10
00007d0bb21d6a3b  vmovaps [rsp+0xB0], xmm11
00007d0bb21d6a44  vmovaps [rsp+0xC0], xmm12
00007d0bb21d6a4d  vmovaps [rsp+0xD0], xmm14
00007d0bb21d6a56  vmovaps [rsp+0xE0], xmm15
00007d0bb21d6a5f  sub rsp, 0x30
00007d0bb21d6a63  movaps [rsp], xmm13
00007d0bb21d6a68  movaps [rsp+0x10], xmm9
00007d0bb21d6a6e  movaps [rsp+0x20], xmm10
00007d0bb21d6a74  lea rdi, [rsp]
00007d0bb21d6a78  mov esi, 0x00
00007d0bb21d6a7d  mov rax, 0x6392BBE7F530
00007d0bb21d6a87  call rax
00007d0bb21d6a89  movaps xmm13, [rsp]
00007d0bb21d6a8e  add rsp, 0x30
00007d0bb21d6a92  vmovaps xmm0, [rsp]
00007d0bb21d6a97  vmovaps xmm1, [rsp+0x10]
00007d0bb21d6a9d  vmovaps xmm2, [rsp+0x20]
00007d0bb21d6aa3  vmovaps xmm3, [rsp+0x30]
00007d0bb21d6aa9  vmovaps xmm4, [rsp+0x40]
00007d0bb21d6aaf  vmovaps xmm5, [rsp+0x50]
00007d0bb21d6ab5  vmovaps xmm6, [rsp+0x60]
00007d0bb21d6abb  vmovaps xmm7, [rsp+0x70]
00007d0bb21d6ac1  vmovaps xmm8, [rsp+0x80]
00007d0bb21d6aca  vmovaps xmm9, [rsp+0x90]
00007d0bb21d6ad3  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d6adc  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d6ae5  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d6aee  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d6af7  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d6b00  add rsp, 0xF0
00007d0bb21d6b07  pop r11
00007d0bb21d6b09  pop r10
00007d0bb21d6b0b  pop r9
00007d0bb21d6b0d  pop r8
00007d0bb21d6b0f  pop rsi
00007d0bb21d6b10  pop rdi
00007d0bb21d6b11  pop rdx
00007d0bb21d6b12  pop rcx
00007d0bb21d6b13  pop rax
00007d0bb21d6b14  add rsp, 0x08
00007d0bb21d6b18  jmp 0x00007D0BB21D3196
00007d0bb21d6b1d  call 0x00007D0BB200AFE0
00007d0bb21d6b22  jmp 0x00007D0BB21D31EB
00007d0bb21d6b27  sub rsp, 0x08
00007d0bb21d6b2b  push rax
00007d0bb21d6b2c  push rcx
00007d0bb21d6b2d  push rdx
00007d0bb21d6b2e  push rdi
00007d0bb21d6b2f  push rsi
00007d0bb21d6b30  push r8
00007d0bb21d6b32  push r9
00007d0bb21d6b34  push r10
00007d0bb21d6b36  push r11
00007d0bb21d6b38  sub rsp, 0xF0
00007d0bb21d6b3f  vmovaps [rsp], xmm0
00007d0bb21d6b44  vmovaps [rsp+0x10], xmm1
00007d0bb21d6b4a  vmovaps [rsp+0x20], xmm2
00007d0bb21d6b50  vmovaps [rsp+0x30], xmm3
00007d0bb21d6b56  vmovaps [rsp+0x40], xmm4
00007d0bb21d6b5c  vmovaps [rsp+0x50], xmm5
00007d0bb21d6b62  vmovaps [rsp+0x60], xmm6
00007d0bb21d6b68  vmovaps [rsp+0x70], xmm7
00007d0bb21d6b6e  vmovaps [rsp+0x80], xmm8
00007d0bb21d6b77  vmovaps [rsp+0x90], xmm10
00007d0bb21d6b80  vmovaps [rsp+0xA0], xmm11
00007d0bb21d6b89  vmovaps [rsp+0xB0], xmm12
00007d0bb21d6b92  vmovaps [rsp+0xC0], xmm13
00007d0bb21d6b9b  vmovaps [rsp+0xD0], xmm14
00007d0bb21d6ba4  vmovaps [rsp+0xE0], xmm15
00007d0bb21d6bad  sub rsp, 0x30
00007d0bb21d6bb1  movaps [rsp], xmm9
00007d0bb21d6bb6  movaps [rsp+0x10], xmm8
00007d0bb21d6bbc  movaps [rsp+0x20], xmm10
00007d0bb21d6bc2  lea rdi, [rsp]
00007d0bb21d6bc6  mov esi, 0x00
00007d0bb21d6bcb  mov rax, 0x6392BBE7F530
00007d0bb21d6bd5  call rax
00007d0bb21d6bd7  movaps xmm9, [rsp]
00007d0bb21d6bdc  add rsp, 0x30
00007d0bb21d6be0  vmovaps xmm0, [rsp]
00007d0bb21d6be5  vmovaps xmm1, [rsp+0x10]
00007d0bb21d6beb  vmovaps xmm2, [rsp+0x20]
00007d0bb21d6bf1  vmovaps xmm3, [rsp+0x30]
00007d0bb21d6bf7  vmovaps xmm4, [rsp+0x40]
00007d0bb21d6bfd  vmovaps xmm5, [rsp+0x50]
00007d0bb21d6c03  vmovaps xmm6, [rsp+0x60]
00007d0bb21d6c09  vmovaps xmm7, [rsp+0x70]
00007d0bb21d6c0f  vmovaps xmm8, [rsp+0x80]
00007d0bb21d6c18  vmovaps xmm10, [rsp+0x90]
00007d0bb21d6c21  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d6c2a  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d6c33  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d6c3c  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d6c45  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d6c4e  add rsp, 0xF0
00007d0bb21d6c55  pop r11
00007d0bb21d6c57  pop r10
00007d0bb21d6c59  pop r9
00007d0bb21d6c5b  pop r8
00007d0bb21d6c5d  pop rsi
00007d0bb21d6c5e  pop rdi
00007d0bb21d6c5f  pop rdx
00007d0bb21d6c60  pop rcx
00007d0bb21d6c61  pop rax
00007d0bb21d6c62  add rsp, 0x08
00007d0bb21d6c66  jmp 0x00007D0BB21D321C
00007d0bb21d6c6b  sub rsp, 0x08
00007d0bb21d6c6f  push rax
00007d0bb21d6c70  push rcx
00007d0bb21d6c71  push rdx
00007d0bb21d6c72  push rdi
00007d0bb21d6c73  push rsi
00007d0bb21d6c74  push r8
00007d0bb21d6c76  push r9
00007d0bb21d6c78  push r10
00007d0bb21d6c7a  push r11
00007d0bb21d6c7c  sub rsp, 0xF0
00007d0bb21d6c83  vmovaps [rsp], xmm0
00007d0bb21d6c88  vmovaps [rsp+0x10], xmm1
00007d0bb21d6c8e  vmovaps [rsp+0x20], xmm2
00007d0bb21d6c94  vmovaps [rsp+0x30], xmm3
00007d0bb21d6c9a  vmovaps [rsp+0x40], xmm4
00007d0bb21d6ca0  vmovaps [rsp+0x50], xmm5
00007d0bb21d6ca6  vmovaps [rsp+0x60], xmm6
00007d0bb21d6cac  vmovaps [rsp+0x70], xmm7
00007d0bb21d6cb2  vmovaps [rsp+0x80], xmm8
00007d0bb21d6cbb  vmovaps [rsp+0x90], xmm9
00007d0bb21d6cc4  vmovaps [rsp+0xA0], xmm11
00007d0bb21d6ccd  vmovaps [rsp+0xB0], xmm12
00007d0bb21d6cd6  vmovaps [rsp+0xC0], xmm13
00007d0bb21d6cdf  vmovaps [rsp+0xD0], xmm14
00007d0bb21d6ce8  vmovaps [rsp+0xE0], xmm15
00007d0bb21d6cf1  sub rsp, 0x30
00007d0bb21d6cf5  movaps [rsp], xmm10
00007d0bb21d6cfa  movaps [rsp+0x10], xmm1
00007d0bb21d6cff  movaps [rsp+0x20], xmm11
00007d0bb21d6d05  lea rdi, [rsp]
00007d0bb21d6d09  mov esi, 0x00
00007d0bb21d6d0e  mov rax, 0x6392BBE7F530
00007d0bb21d6d18  call rax
00007d0bb21d6d1a  movaps xmm10, [rsp]
00007d0bb21d6d1f  add rsp, 0x30
00007d0bb21d6d23  vmovaps xmm0, [rsp]
00007d0bb21d6d28  vmovaps xmm1, [rsp+0x10]
00007d0bb21d6d2e  vmovaps xmm2, [rsp+0x20]
00007d0bb21d6d34  vmovaps xmm3, [rsp+0x30]
00007d0bb21d6d3a  vmovaps xmm4, [rsp+0x40]
00007d0bb21d6d40  vmovaps xmm5, [rsp+0x50]
00007d0bb21d6d46  vmovaps xmm6, [rsp+0x60]
00007d0bb21d6d4c  vmovaps xmm7, [rsp+0x70]
00007d0bb21d6d52  vmovaps xmm8, [rsp+0x80]
00007d0bb21d6d5b  vmovaps xmm9, [rsp+0x90]
00007d0bb21d6d64  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d6d6d  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d6d76  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d6d7f  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d6d88  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d6d91  add rsp, 0xF0
00007d0bb21d6d98  pop r11
00007d0bb21d6d9a  pop r10
00007d0bb21d6d9c  pop r9
00007d0bb21d6d9e  pop r8
00007d0bb21d6da0  pop rsi
00007d0bb21d6da1  pop rdi
00007d0bb21d6da2  pop rdx
00007d0bb21d6da3  pop rcx
00007d0bb21d6da4  pop rax
00007d0bb21d6da5  add rsp, 0x08
00007d0bb21d6da9  jmp 0x00007D0BB21D3237
00007d0bb21d6dae  sub rsp, 0x08
00007d0bb21d6db2  push rax
00007d0bb21d6db3  push rcx
00007d0bb21d6db4  push rdx
00007d0bb21d6db5  push rdi
00007d0bb21d6db6  push rsi
00007d0bb21d6db7  push r8
00007d0bb21d6db9  push r9
00007d0bb21d6dbb  push r10
00007d0bb21d6dbd  push r11
00007d0bb21d6dbf  sub rsp, 0xF0
00007d0bb21d6dc6  vmovaps [rsp], xmm0
00007d0bb21d6dcb  vmovaps [rsp+0x10], xmm2
00007d0bb21d6dd1  vmovaps [rsp+0x20], xmm3
00007d0bb21d6dd7  vmovaps [rsp+0x30], xmm4
00007d0bb21d6ddd  vmovaps [rsp+0x40], xmm5
00007d0bb21d6de3  vmovaps [rsp+0x50], xmm6
00007d0bb21d6de9  vmovaps [rsp+0x60], xmm7
00007d0bb21d6def  vmovaps [rsp+0x70], xmm8
00007d0bb21d6df5  vmovaps [rsp+0x80], xmm9
00007d0bb21d6dfe  vmovaps [rsp+0x90], xmm10
00007d0bb21d6e07  vmovaps [rsp+0xA0], xmm11
00007d0bb21d6e10  vmovaps [rsp+0xB0], xmm12
00007d0bb21d6e19  vmovaps [rsp+0xC0], xmm13
00007d0bb21d6e22  vmovaps [rsp+0xD0], xmm14
00007d0bb21d6e2b  vmovaps [rsp+0xE0], xmm15
00007d0bb21d6e34  sub rsp, 0x30
00007d0bb21d6e38  movaps [rsp], xmm1
00007d0bb21d6e3c  movaps [rsp+0x10], xmm15
00007d0bb21d6e42  movaps [rsp+0x20], xmm6
00007d0bb21d6e47  lea rdi, [rsp]
00007d0bb21d6e4b  mov esi, 0x00
00007d0bb21d6e50  mov rax, 0x6392BBE7F530
00007d0bb21d6e5a  call rax
00007d0bb21d6e5c  movaps xmm1, [rsp]
00007d0bb21d6e60  add rsp, 0x30
00007d0bb21d6e64  vmovaps xmm0, [rsp]
00007d0bb21d6e69  vmovaps xmm2, [rsp+0x10]
00007d0bb21d6e6f  vmovaps xmm3, [rsp+0x20]
00007d0bb21d6e75  vmovaps xmm4, [rsp+0x30]
00007d0bb21d6e7b  vmovaps xmm5, [rsp+0x40]
00007d0bb21d6e81  vmovaps xmm6, [rsp+0x50]
00007d0bb21d6e87  vmovaps xmm7, [rsp+0x60]
00007d0bb21d6e8d  vmovaps xmm8, [rsp+0x70]
00007d0bb21d6e93  vmovaps xmm9, [rsp+0x80]
00007d0bb21d6e9c  vmovaps xmm10, [rsp+0x90]
00007d0bb21d6ea5  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d6eae  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d6eb7  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d6ec0  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d6ec9  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d6ed2  add rsp, 0xF0
00007d0bb21d6ed9  pop r11
00007d0bb21d6edb  pop r10
00007d0bb21d6edd  pop r9
00007d0bb21d6edf  pop r8
00007d0bb21d6ee1  pop rsi
00007d0bb21d6ee2  pop rdi
00007d0bb21d6ee3  pop rdx
00007d0bb21d6ee4  pop rcx
00007d0bb21d6ee5  pop rax
00007d0bb21d6ee6  add rsp, 0x08
00007d0bb21d6eea  jmp 0x00007D0BB21D3250
00007d0bb21d6eef  sub rsp, 0x08
00007d0bb21d6ef3  push rax
00007d0bb21d6ef4  push rcx
00007d0bb21d6ef5  push rdx
00007d0bb21d6ef6  push rdi
00007d0bb21d6ef7  push rsi
00007d0bb21d6ef8  push r8
00007d0bb21d6efa  push r9
00007d0bb21d6efc  push r10
00007d0bb21d6efe  push r11
00007d0bb21d6f00  sub rsp, 0xF0
00007d0bb21d6f07  vmovaps [rsp], xmm0
00007d0bb21d6f0c  vmovaps [rsp+0x10], xmm1
00007d0bb21d6f12  vmovaps [rsp+0x20], xmm2
00007d0bb21d6f18  vmovaps [rsp+0x30], xmm3
00007d0bb21d6f1e  vmovaps [rsp+0x40], xmm4
00007d0bb21d6f24  vmovaps [rsp+0x50], xmm5
00007d0bb21d6f2a  vmovaps [rsp+0x60], xmm6
00007d0bb21d6f30  vmovaps [rsp+0x70], xmm7
00007d0bb21d6f36  vmovaps [rsp+0x80], xmm8
00007d0bb21d6f3f  vmovaps [rsp+0x90], xmm9
00007d0bb21d6f48  vmovaps [rsp+0xA0], xmm10
00007d0bb21d6f51  vmovaps [rsp+0xB0], xmm12
00007d0bb21d6f5a  vmovaps [rsp+0xC0], xmm13
00007d0bb21d6f63  vmovaps [rsp+0xD0], xmm14
00007d0bb21d6f6c  vmovaps [rsp+0xE0], xmm15
00007d0bb21d6f75  sub rsp, 0x30
00007d0bb21d6f79  movaps [rsp], xmm11
00007d0bb21d6f7e  movaps [rsp+0x10], xmm12
00007d0bb21d6f84  movaps [rsp+0x20], xmm15
00007d0bb21d6f8a  lea rdi, [rsp]
00007d0bb21d6f8e  mov esi, 0x00
00007d0bb21d6f93  mov rax, 0x6392BBE7F530
00007d0bb21d6f9d  call rax
00007d0bb21d6f9f  movaps xmm11, [rsp]
00007d0bb21d6fa4  add rsp, 0x30
00007d0bb21d6fa8  vmovaps xmm0, [rsp]
00007d0bb21d6fad  vmovaps xmm1, [rsp+0x10]
00007d0bb21d6fb3  vmovaps xmm2, [rsp+0x20]
00007d0bb21d6fb9  vmovaps xmm3, [rsp+0x30]
00007d0bb21d6fbf  vmovaps xmm4, [rsp+0x40]
00007d0bb21d6fc5  vmovaps xmm5, [rsp+0x50]
00007d0bb21d6fcb  vmovaps xmm6, [rsp+0x60]
00007d0bb21d6fd1  vmovaps xmm7, [rsp+0x70]
00007d0bb21d6fd7  vmovaps xmm8, [rsp+0x80]
00007d0bb21d6fe0  vmovaps xmm9, [rsp+0x90]
00007d0bb21d6fe9  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d6ff2  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d6ffb  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d7004  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d700d  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d7016  add rsp, 0xF0
00007d0bb21d701d  pop r11
00007d0bb21d701f  pop r10
00007d0bb21d7021  pop r9
00007d0bb21d7023  pop r8
00007d0bb21d7025  pop rsi
00007d0bb21d7026  pop rdi
00007d0bb21d7027  pop rdx
00007d0bb21d7028  pop rcx
00007d0bb21d7029  pop rax
00007d0bb21d702a  add rsp, 0x08
00007d0bb21d702e  jmp 0x00007D0BB21D327A
00007d0bb21d7033  sub rsp, 0x08
00007d0bb21d7037  push rax
00007d0bb21d7038  push rcx
00007d0bb21d7039  push rdx
00007d0bb21d703a  push rdi
00007d0bb21d703b  push rsi
00007d0bb21d703c  push r8
00007d0bb21d703e  push r9
00007d0bb21d7040  push r10
00007d0bb21d7042  push r11
00007d0bb21d7044  sub rsp, 0xF0
00007d0bb21d704b  vmovaps [rsp], xmm0
00007d0bb21d7050  vmovaps [rsp+0x10], xmm1
00007d0bb21d7056  vmovaps [rsp+0x20], xmm2
00007d0bb21d705c  vmovaps [rsp+0x30], xmm3
00007d0bb21d7062  vmovaps [rsp+0x40], xmm4
00007d0bb21d7068  vmovaps [rsp+0x50], xmm5
00007d0bb21d706e  vmovaps [rsp+0x60], xmm6
00007d0bb21d7074  vmovaps [rsp+0x70], xmm7
00007d0bb21d707a  vmovaps [rsp+0x80], xmm8
00007d0bb21d7083  vmovaps [rsp+0x90], xmm9
00007d0bb21d708c  vmovaps [rsp+0xA0], xmm10
00007d0bb21d7095  vmovaps [rsp+0xB0], xmm11
00007d0bb21d709e  vmovaps [rsp+0xC0], xmm13
00007d0bb21d70a7  vmovaps [rsp+0xD0], xmm14
00007d0bb21d70b0  vmovaps [rsp+0xE0], xmm15
00007d0bb21d70b9  sub rsp, 0x30
00007d0bb21d70bd  movaps [rsp], xmm12
00007d0bb21d70c2  movaps [rsp+0x10], xmm8
00007d0bb21d70c8  movaps [rsp+0x20], xmm15
00007d0bb21d70ce  lea rdi, [rsp]
00007d0bb21d70d2  mov esi, 0x00
00007d0bb21d70d7  mov rax, 0x6392BBE7F530
00007d0bb21d70e1  call rax
00007d0bb21d70e3  movaps xmm12, [rsp]
00007d0bb21d70e8  add rsp, 0x30
00007d0bb21d70ec  vmovaps xmm0, [rsp]
00007d0bb21d70f1  vmovaps xmm1, [rsp+0x10]
00007d0bb21d70f7  vmovaps xmm2, [rsp+0x20]
00007d0bb21d70fd  vmovaps xmm3, [rsp+0x30]
00007d0bb21d7103  vmovaps xmm4, [rsp+0x40]
00007d0bb21d7109  vmovaps xmm5, [rsp+0x50]
00007d0bb21d710f  vmovaps xmm6, [rsp+0x60]
00007d0bb21d7115  vmovaps xmm7, [rsp+0x70]
00007d0bb21d711b  vmovaps xmm8, [rsp+0x80]
00007d0bb21d7124  vmovaps xmm9, [rsp+0x90]
00007d0bb21d712d  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d7136  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d713f  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d7148  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d7151  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d715a  add rsp, 0xF0
00007d0bb21d7161  pop r11
00007d0bb21d7163  pop r10
00007d0bb21d7165  pop r9
00007d0bb21d7167  pop r8
00007d0bb21d7169  pop rsi
00007d0bb21d716a  pop rdi
00007d0bb21d716b  pop rdx
00007d0bb21d716c  pop rcx
00007d0bb21d716d  pop rax
00007d0bb21d716e  add rsp, 0x08
00007d0bb21d7172  jmp 0x00007D0BB21D32A9
00007d0bb21d7177  sub rsp, 0x08
00007d0bb21d717b  push rax
00007d0bb21d717c  push rcx
00007d0bb21d717d  push rdx
00007d0bb21d717e  push rdi
00007d0bb21d717f  push rsi
00007d0bb21d7180  push r8
00007d0bb21d7182  push r9
00007d0bb21d7184  push r10
00007d0bb21d7186  push r11
00007d0bb21d7188  sub rsp, 0xF0
00007d0bb21d718f  vmovaps [rsp], xmm0
00007d0bb21d7194  vmovaps [rsp+0x10], xmm1
00007d0bb21d719a  vmovaps [rsp+0x20], xmm2
00007d0bb21d71a0  vmovaps [rsp+0x30], xmm3
00007d0bb21d71a6  vmovaps [rsp+0x40], xmm4
00007d0bb21d71ac  vmovaps [rsp+0x50], xmm5
00007d0bb21d71b2  vmovaps [rsp+0x60], xmm6
00007d0bb21d71b8  vmovaps [rsp+0x70], xmm7
00007d0bb21d71be  vmovaps [rsp+0x80], xmm9
00007d0bb21d71c7  vmovaps [rsp+0x90], xmm10
00007d0bb21d71d0  vmovaps [rsp+0xA0], xmm11
00007d0bb21d71d9  vmovaps [rsp+0xB0], xmm12
00007d0bb21d71e2  vmovaps [rsp+0xC0], xmm13
00007d0bb21d71eb  vmovaps [rsp+0xD0], xmm14
00007d0bb21d71f4  vmovaps [rsp+0xE0], xmm15
00007d0bb21d71fd  sub rsp, 0x30
00007d0bb21d7201  movaps [rsp], xmm8
00007d0bb21d7206  movaps [rsp+0x10], xmm7
00007d0bb21d720b  movaps [rsp+0x20], xmm15
00007d0bb21d7211  lea rdi, [rsp]
00007d0bb21d7215  mov esi, 0x00
00007d0bb21d721a  mov rax, 0x6392BBE7F530
00007d0bb21d7224  call rax
00007d0bb21d7226  movaps xmm8, [rsp]
00007d0bb21d722b  add rsp, 0x30
00007d0bb21d722f  vmovaps xmm0, [rsp]
00007d0bb21d7234  vmovaps xmm1, [rsp+0x10]
00007d0bb21d723a  vmovaps xmm2, [rsp+0x20]
00007d0bb21d7240  vmovaps xmm3, [rsp+0x30]
00007d0bb21d7246  vmovaps xmm4, [rsp+0x40]
00007d0bb21d724c  vmovaps xmm5, [rsp+0x50]
00007d0bb21d7252  vmovaps xmm6, [rsp+0x60]
00007d0bb21d7258  vmovaps xmm7, [rsp+0x70]
00007d0bb21d725e  vmovaps xmm9, [rsp+0x80]
00007d0bb21d7267  vmovaps xmm10, [rsp+0x90]
00007d0bb21d7270  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d7279  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d7282  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d728b  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d7294  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d729d  add rsp, 0xF0
00007d0bb21d72a4  pop r11
00007d0bb21d72a6  pop r10
00007d0bb21d72a8  pop r9
00007d0bb21d72aa  pop r8
00007d0bb21d72ac  pop rsi
00007d0bb21d72ad  pop rdi
00007d0bb21d72ae  pop rdx
00007d0bb21d72af  pop rcx
00007d0bb21d72b0  pop rax
00007d0bb21d72b1  add rsp, 0x08
00007d0bb21d72b5  jmp 0x00007D0BB21D32CF
00007d0bb21d72ba  sub rsp, 0x08
00007d0bb21d72be  push rax
00007d0bb21d72bf  push rcx
00007d0bb21d72c0  push rdx
00007d0bb21d72c1  push rdi
00007d0bb21d72c2  push rsi
00007d0bb21d72c3  push r8
00007d0bb21d72c5  push r9
00007d0bb21d72c7  push r10
00007d0bb21d72c9  push r11
00007d0bb21d72cb  sub rsp, 0xF0
00007d0bb21d72d2  vmovaps [rsp], xmm0
00007d0bb21d72d7  vmovaps [rsp+0x10], xmm1
00007d0bb21d72dd  vmovaps [rsp+0x20], xmm2
00007d0bb21d72e3  vmovaps [rsp+0x30], xmm3
00007d0bb21d72e9  vmovaps [rsp+0x40], xmm4
00007d0bb21d72ef  vmovaps [rsp+0x50], xmm5
00007d0bb21d72f5  vmovaps [rsp+0x60], xmm6
00007d0bb21d72fb  vmovaps [rsp+0x70], xmm7
00007d0bb21d7301  vmovaps [rsp+0x80], xmm8
00007d0bb21d730a  vmovaps [rsp+0x90], xmm9
00007d0bb21d7313  vmovaps [rsp+0xA0], xmm10
00007d0bb21d731c  vmovaps [rsp+0xB0], xmm11
00007d0bb21d7325  vmovaps [rsp+0xC0], xmm12
00007d0bb21d732e  vmovaps [rsp+0xD0], xmm13
00007d0bb21d7337  vmovaps [rsp+0xE0], xmm14
00007d0bb21d7340  sub rsp, 0x30
00007d0bb21d7344  movaps [rsp], xmm15
00007d0bb21d7349  movaps [rsp+0x10], xmm14
00007d0bb21d734f  movaps [rsp+0x20], xmm9
00007d0bb21d7355  lea rdi, [rsp]
00007d0bb21d7359  mov esi, 0x00
00007d0bb21d735e  mov rax, 0x6392BBE7F530
00007d0bb21d7368  call rax
00007d0bb21d736a  movaps xmm15, [rsp]
00007d0bb21d736f  add rsp, 0x30
00007d0bb21d7373  vmovaps xmm0, [rsp]
00007d0bb21d7378  vmovaps xmm1, [rsp+0x10]
00007d0bb21d737e  vmovaps xmm2, [rsp+0x20]
00007d0bb21d7384  vmovaps xmm3, [rsp+0x30]
00007d0bb21d738a  vmovaps xmm4, [rsp+0x40]
00007d0bb21d7390  vmovaps xmm5, [rsp+0x50]
00007d0bb21d7396  vmovaps xmm6, [rsp+0x60]
00007d0bb21d739c  vmovaps xmm7, [rsp+0x70]
00007d0bb21d73a2  vmovaps xmm8, [rsp+0x80]
00007d0bb21d73ab  vmovaps xmm9, [rsp+0x90]
00007d0bb21d73b4  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d73bd  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d73c6  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d73cf  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d73d8  vmovaps xmm14, [rsp+0xE0]
00007d0bb21d73e1  add rsp, 0xF0
00007d0bb21d73e8  pop r11
00007d0bb21d73ea  pop r10
00007d0bb21d73ec  pop r9
00007d0bb21d73ee  pop r8
00007d0bb21d73f0  pop rsi
00007d0bb21d73f1  pop rdi
00007d0bb21d73f2  pop rdx
00007d0bb21d73f3  pop rcx
00007d0bb21d73f4  pop rax
00007d0bb21d73f5  add rsp, 0x08
00007d0bb21d73f9  jmp 0x00007D0BB21D32E9
00007d0bb21d73fe  sub rsp, 0x08
00007d0bb21d7402  push rax
00007d0bb21d7403  push rcx
00007d0bb21d7404  push rdx
00007d0bb21d7405  push rdi
00007d0bb21d7406  push rsi
00007d0bb21d7407  push r8
00007d0bb21d7409  push r9
00007d0bb21d740b  push r10
00007d0bb21d740d  push r11
00007d0bb21d740f  sub rsp, 0xF0
00007d0bb21d7416  vmovaps [rsp], xmm0
00007d0bb21d741b  vmovaps [rsp+0x10], xmm1
00007d0bb21d7421  vmovaps [rsp+0x20], xmm2
00007d0bb21d7427  vmovaps [rsp+0x30], xmm3
00007d0bb21d742d  vmovaps [rsp+0x40], xmm4
00007d0bb21d7433  vmovaps [rsp+0x50], xmm5
00007d0bb21d7439  vmovaps [rsp+0x60], xmm6
00007d0bb21d743f  vmovaps [rsp+0x70], xmm7
00007d0bb21d7445  vmovaps [rsp+0x80], xmm8
00007d0bb21d744e  vmovaps [rsp+0x90], xmm10
00007d0bb21d7457  vmovaps [rsp+0xA0], xmm11
00007d0bb21d7460  vmovaps [rsp+0xB0], xmm12
00007d0bb21d7469  vmovaps [rsp+0xC0], xmm13
00007d0bb21d7472  vmovaps [rsp+0xD0], xmm14
00007d0bb21d747b  vmovaps [rsp+0xE0], xmm15
00007d0bb21d7484  sub rsp, 0x30
00007d0bb21d7488  movaps [rsp], xmm9
00007d0bb21d748d  movaps [rsp+0x10], xmm7
00007d0bb21d7492  movaps [rsp+0x20], xmm14
00007d0bb21d7498  lea rdi, [rsp]
00007d0bb21d749c  mov esi, 0x00
00007d0bb21d74a1  mov rax, 0x6392BBE7F530
00007d0bb21d74ab  call rax
00007d0bb21d74ad  movaps xmm9, [rsp]
00007d0bb21d74b2  add rsp, 0x30
00007d0bb21d74b6  vmovaps xmm0, [rsp]
00007d0bb21d74bb  vmovaps xmm1, [rsp+0x10]
00007d0bb21d74c1  vmovaps xmm2, [rsp+0x20]
00007d0bb21d74c7  vmovaps xmm3, [rsp+0x30]
00007d0bb21d74cd  vmovaps xmm4, [rsp+0x40]
00007d0bb21d74d3  vmovaps xmm5, [rsp+0x50]
00007d0bb21d74d9  vmovaps xmm6, [rsp+0x60]
00007d0bb21d74df  vmovaps xmm7, [rsp+0x70]
00007d0bb21d74e5  vmovaps xmm8, [rsp+0x80]
00007d0bb21d74ee  vmovaps xmm10, [rsp+0x90]
00007d0bb21d74f7  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d7500  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d7509  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d7512  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d751b  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d7524  add rsp, 0xF0
00007d0bb21d752b  pop r11
00007d0bb21d752d  pop r10
00007d0bb21d752f  pop r9
00007d0bb21d7531  pop r8
00007d0bb21d7533  pop rsi
00007d0bb21d7534  pop rdi
00007d0bb21d7535  pop rdx
00007d0bb21d7536  pop rcx
00007d0bb21d7537  pop rax
00007d0bb21d7538  add rsp, 0x08
00007d0bb21d753c  jmp 0x00007D0BB21D3318
00007d0bb21d7541  sub rsp, 0x08
00007d0bb21d7545  push rax
00007d0bb21d7546  push rcx
00007d0bb21d7547  push rdx
00007d0bb21d7548  push rdi
00007d0bb21d7549  push rsi
00007d0bb21d754a  push r8
00007d0bb21d754c  push r9
00007d0bb21d754e  push r10
00007d0bb21d7550  push r11
00007d0bb21d7552  sub rsp, 0xF0
00007d0bb21d7559  vmovaps [rsp], xmm0
00007d0bb21d755e  vmovaps [rsp+0x10], xmm1
00007d0bb21d7564  vmovaps [rsp+0x20], xmm2
00007d0bb21d756a  vmovaps [rsp+0x30], xmm3
00007d0bb21d7570  vmovaps [rsp+0x40], xmm4
00007d0bb21d7576  vmovaps [rsp+0x50], xmm5
00007d0bb21d757c  vmovaps [rsp+0x60], xmm6
00007d0bb21d7582  vmovaps [rsp+0x70], xmm7
00007d0bb21d7588  vmovaps [rsp+0x80], xmm8
00007d0bb21d7591  vmovaps [rsp+0x90], xmm9
00007d0bb21d759a  vmovaps [rsp+0xA0], xmm10
00007d0bb21d75a3  vmovaps [rsp+0xB0], xmm11
00007d0bb21d75ac  vmovaps [rsp+0xC0], xmm12
00007d0bb21d75b5  vmovaps [rsp+0xD0], xmm13
00007d0bb21d75be  vmovaps [rsp+0xE0], xmm15
00007d0bb21d75c7  sub rsp, 0x30
00007d0bb21d75cb  movaps [rsp], xmm14
00007d0bb21d75d0  movaps [rsp+0x10], xmm13
00007d0bb21d75d6  movaps [rsp+0x20], xmm11
00007d0bb21d75dc  lea rdi, [rsp]
00007d0bb21d75e0  mov esi, 0x00
00007d0bb21d75e5  mov rax, 0x6392BBE7F530
00007d0bb21d75ef  call rax
00007d0bb21d75f1  movaps xmm14, [rsp]
00007d0bb21d75f6  add rsp, 0x30
00007d0bb21d75fa  vmovaps xmm0, [rsp]
00007d0bb21d75ff  vmovaps xmm1, [rsp+0x10]
00007d0bb21d7605  vmovaps xmm2, [rsp+0x20]
00007d0bb21d760b  vmovaps xmm3, [rsp+0x30]
00007d0bb21d7611  vmovaps xmm4, [rsp+0x40]
00007d0bb21d7617  vmovaps xmm5, [rsp+0x50]
00007d0bb21d761d  vmovaps xmm6, [rsp+0x60]
00007d0bb21d7623  vmovaps xmm7, [rsp+0x70]
00007d0bb21d7629  vmovaps xmm8, [rsp+0x80]
00007d0bb21d7632  vmovaps xmm9, [rsp+0x90]
00007d0bb21d763b  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d7644  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d764d  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d7656  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d765f  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d7668  add rsp, 0xF0
00007d0bb21d766f  pop r11
00007d0bb21d7671  pop r10
00007d0bb21d7673  pop r9
00007d0bb21d7675  pop r8
00007d0bb21d7677  pop rsi
00007d0bb21d7678  pop rdi
00007d0bb21d7679  pop rdx
00007d0bb21d767a  pop rcx
00007d0bb21d767b  pop rax
00007d0bb21d767c  add rsp, 0x08
00007d0bb21d7680  jmp 0x00007D0BB21D3332
00007d0bb21d7685  sub rsp, 0x08
00007d0bb21d7689  push rax
00007d0bb21d768a  push rcx
00007d0bb21d768b  push rdx
00007d0bb21d768c  push rdi
00007d0bb21d768d  push rsi
00007d0bb21d768e  push r8
00007d0bb21d7690  push r9
00007d0bb21d7692  push r10
00007d0bb21d7694  push r11
00007d0bb21d7696  sub rsp, 0xF0
00007d0bb21d769d  vmovaps [rsp], xmm0
00007d0bb21d76a2  vmovaps [rsp+0x10], xmm1
00007d0bb21d76a8  vmovaps [rsp+0x20], xmm2
00007d0bb21d76ae  vmovaps [rsp+0x30], xmm3
00007d0bb21d76b4  vmovaps [rsp+0x40], xmm4
00007d0bb21d76ba  vmovaps [rsp+0x50], xmm5
00007d0bb21d76c0  vmovaps [rsp+0x60], xmm6
00007d0bb21d76c6  vmovaps [rsp+0x70], xmm7
00007d0bb21d76cc  vmovaps [rsp+0x80], xmm8
00007d0bb21d76d5  vmovaps [rsp+0x90], xmm9
00007d0bb21d76de  vmovaps [rsp+0xA0], xmm10
00007d0bb21d76e7  vmovaps [rsp+0xB0], xmm12
00007d0bb21d76f0  vmovaps [rsp+0xC0], xmm13
00007d0bb21d76f9  vmovaps [rsp+0xD0], xmm14
00007d0bb21d7702  vmovaps [rsp+0xE0], xmm15
00007d0bb21d770b  sub rsp, 0x30
00007d0bb21d770f  movaps [rsp], xmm11
00007d0bb21d7714  movaps [rsp+0x10], xmm7
00007d0bb21d7719  movaps [rsp+0x20], xmm13
00007d0bb21d771f  lea rdi, [rsp]
00007d0bb21d7723  mov esi, 0x00
00007d0bb21d7728  mov rax, 0x6392BBE7F530
00007d0bb21d7732  call rax
00007d0bb21d7734  movaps xmm11, [rsp]
00007d0bb21d7739  add rsp, 0x30
00007d0bb21d773d  vmovaps xmm0, [rsp]
00007d0bb21d7742  vmovaps xmm1, [rsp+0x10]
00007d0bb21d7748  vmovaps xmm2, [rsp+0x20]
00007d0bb21d774e  vmovaps xmm3, [rsp+0x30]
00007d0bb21d7754  vmovaps xmm4, [rsp+0x40]
00007d0bb21d775a  vmovaps xmm5, [rsp+0x50]
00007d0bb21d7760  vmovaps xmm6, [rsp+0x60]
00007d0bb21d7766  vmovaps xmm7, [rsp+0x70]
00007d0bb21d776c  vmovaps xmm8, [rsp+0x80]
00007d0bb21d7775  vmovaps xmm9, [rsp+0x90]
00007d0bb21d777e  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d7787  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d7790  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d7799  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d77a2  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d77ab  add rsp, 0xF0
00007d0bb21d77b2  pop r11
00007d0bb21d77b4  pop r10
00007d0bb21d77b6  pop r9
00007d0bb21d77b8  pop r8
00007d0bb21d77ba  pop rsi
00007d0bb21d77bb  pop rdi
00007d0bb21d77bc  pop rdx
00007d0bb21d77bd  pop rcx
00007d0bb21d77be  pop rax
00007d0bb21d77bf  add rsp, 0x08
00007d0bb21d77c3  jmp 0x00007D0BB21D335E
00007d0bb21d77c8  sub rsp, 0x08
00007d0bb21d77cc  push rax
00007d0bb21d77cd  push rcx
00007d0bb21d77ce  push rdx
00007d0bb21d77cf  push rdi
00007d0bb21d77d0  push rsi
00007d0bb21d77d1  push r8
00007d0bb21d77d3  push r9
00007d0bb21d77d5  push r10
00007d0bb21d77d7  push r11
00007d0bb21d77d9  sub rsp, 0xF0
00007d0bb21d77e0  vmovaps [rsp], xmm0
00007d0bb21d77e5  vmovaps [rsp+0x10], xmm1
00007d0bb21d77eb  vmovaps [rsp+0x20], xmm2
00007d0bb21d77f1  vmovaps [rsp+0x30], xmm3
00007d0bb21d77f7  vmovaps [rsp+0x40], xmm4
00007d0bb21d77fd  vmovaps [rsp+0x50], xmm5
00007d0bb21d7803  vmovaps [rsp+0x60], xmm6
00007d0bb21d7809  vmovaps [rsp+0x70], xmm7
00007d0bb21d780f  vmovaps [rsp+0x80], xmm8
00007d0bb21d7818  vmovaps [rsp+0x90], xmm9
00007d0bb21d7821  vmovaps [rsp+0xA0], xmm10
00007d0bb21d782a  vmovaps [rsp+0xB0], xmm11
00007d0bb21d7833  vmovaps [rsp+0xC0], xmm12
00007d0bb21d783c  vmovaps [rsp+0xD0], xmm14
00007d0bb21d7845  vmovaps [rsp+0xE0], xmm15
00007d0bb21d784e  sub rsp, 0x30
00007d0bb21d7852  movaps [rsp], xmm13
00007d0bb21d7857  movaps [rsp+0x10], xmm10
00007d0bb21d785d  movaps [rsp+0x20], xmm12
00007d0bb21d7863  lea rdi, [rsp]
00007d0bb21d7867  mov esi, 0x00
00007d0bb21d786c  mov rax, 0x6392BBE7F530
00007d0bb21d7876  call rax
00007d0bb21d7878  movaps xmm13, [rsp]
00007d0bb21d787d  add rsp, 0x30
00007d0bb21d7881  vmovaps xmm0, [rsp]
00007d0bb21d7886  vmovaps xmm1, [rsp+0x10]
00007d0bb21d788c  vmovaps xmm2, [rsp+0x20]
00007d0bb21d7892  vmovaps xmm3, [rsp+0x30]
00007d0bb21d7898  vmovaps xmm4, [rsp+0x40]
00007d0bb21d789e  vmovaps xmm5, [rsp+0x50]
00007d0bb21d78a4  vmovaps xmm6, [rsp+0x60]
00007d0bb21d78aa  vmovaps xmm7, [rsp+0x70]
00007d0bb21d78b0  vmovaps xmm8, [rsp+0x80]
00007d0bb21d78b9  vmovaps xmm9, [rsp+0x90]
00007d0bb21d78c2  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d78cb  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d78d4  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d78dd  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d78e6  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d78ef  add rsp, 0xF0
00007d0bb21d78f6  pop r11
00007d0bb21d78f8  pop r10
00007d0bb21d78fa  pop r9
00007d0bb21d78fc  pop r8
00007d0bb21d78fe  pop rsi
00007d0bb21d78ff  pop rdi
00007d0bb21d7900  pop rdx
00007d0bb21d7901  pop rcx
00007d0bb21d7902  pop rax
00007d0bb21d7903  add rsp, 0x08
00007d0bb21d7907  jmp 0x00007D0BB21D3378
00007d0bb21d790c  sub rsp, 0x08
00007d0bb21d7910  push rax
00007d0bb21d7911  push rcx
00007d0bb21d7912  push rdx
00007d0bb21d7913  push rdi
00007d0bb21d7914  push rsi
00007d0bb21d7915  push r8
00007d0bb21d7917  push r9
00007d0bb21d7919  push r10
00007d0bb21d791b  push r11
00007d0bb21d791d  sub rsp, 0xF0
00007d0bb21d7924  vmovaps [rsp], xmm0
00007d0bb21d7929  vmovaps [rsp+0x10], xmm1
00007d0bb21d792f  vmovaps [rsp+0x20], xmm2
00007d0bb21d7935  vmovaps [rsp+0x30], xmm3
00007d0bb21d793b  vmovaps [rsp+0x40], xmm4
00007d0bb21d7941  vmovaps [rsp+0x50], xmm5
00007d0bb21d7947  vmovaps [rsp+0x60], xmm6
00007d0bb21d794d  vmovaps [rsp+0x70], xmm7
00007d0bb21d7953  vmovaps [rsp+0x80], xmm8
00007d0bb21d795c  vmovaps [rsp+0x90], xmm9
00007d0bb21d7965  vmovaps [rsp+0xA0], xmm11
00007d0bb21d796e  vmovaps [rsp+0xB0], xmm12
00007d0bb21d7977  vmovaps [rsp+0xC0], xmm13
00007d0bb21d7980  vmovaps [rsp+0xD0], xmm14
00007d0bb21d7989  vmovaps [rsp+0xE0], xmm15
00007d0bb21d7992  sub rsp, 0x30
00007d0bb21d7996  movaps [rsp], xmm10
00007d0bb21d799b  movaps [rsp+0x10], xmm7
00007d0bb21d79a0  movaps [rsp+0x20], xmm12
00007d0bb21d79a6  lea rdi, [rsp]
00007d0bb21d79aa  mov esi, 0x00
00007d0bb21d79af  mov rax, 0x6392BBE7F530
00007d0bb21d79b9  call rax
00007d0bb21d79bb  movaps xmm10, [rsp]
00007d0bb21d79c0  add rsp, 0x30
00007d0bb21d79c4  vmovaps xmm0, [rsp]
00007d0bb21d79c9  vmovaps xmm1, [rsp+0x10]
00007d0bb21d79cf  vmovaps xmm2, [rsp+0x20]
00007d0bb21d79d5  vmovaps xmm3, [rsp+0x30]
00007d0bb21d79db  vmovaps xmm4, [rsp+0x40]
00007d0bb21d79e1  vmovaps xmm5, [rsp+0x50]
00007d0bb21d79e7  vmovaps xmm6, [rsp+0x60]
00007d0bb21d79ed  vmovaps xmm7, [rsp+0x70]
00007d0bb21d79f3  vmovaps xmm8, [rsp+0x80]
00007d0bb21d79fc  vmovaps xmm9, [rsp+0x90]
00007d0bb21d7a05  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d7a0e  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d7a17  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d7a20  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d7a29  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d7a32  add rsp, 0xF0
00007d0bb21d7a39  pop r11
00007d0bb21d7a3b  pop r10
00007d0bb21d7a3d  pop r9
00007d0bb21d7a3f  pop r8
00007d0bb21d7a41  pop rsi
00007d0bb21d7a42  pop rdi
00007d0bb21d7a43  pop rdx
00007d0bb21d7a44  pop rcx
00007d0bb21d7a45  pop rax
00007d0bb21d7a46  add rsp, 0x08
00007d0bb21d7a4a  jmp 0x00007D0BB21D33A4
00007d0bb21d7a4f  sub rsp, 0x08
00007d0bb21d7a53  push rax
00007d0bb21d7a54  push rcx
00007d0bb21d7a55  push rdx
00007d0bb21d7a56  push rdi
00007d0bb21d7a57  push rsi
00007d0bb21d7a58  push r8
00007d0bb21d7a5a  push r9
00007d0bb21d7a5c  push r10
00007d0bb21d7a5e  push r11
00007d0bb21d7a60  sub rsp, 0xF0
00007d0bb21d7a67  vmovaps [rsp], xmm0
00007d0bb21d7a6c  vmovaps [rsp+0x10], xmm1
00007d0bb21d7a72  vmovaps [rsp+0x20], xmm2
00007d0bb21d7a78  vmovaps [rsp+0x30], xmm3
00007d0bb21d7a7e  vmovaps [rsp+0x40], xmm4
00007d0bb21d7a84  vmovaps [rsp+0x50], xmm5
00007d0bb21d7a8a  vmovaps [rsp+0x60], xmm6
00007d0bb21d7a90  vmovaps [rsp+0x70], xmm7
00007d0bb21d7a96  vmovaps [rsp+0x80], xmm8
00007d0bb21d7a9f  vmovaps [rsp+0x90], xmm9
00007d0bb21d7aa8  vmovaps [rsp+0xA0], xmm10
00007d0bb21d7ab1  vmovaps [rsp+0xB0], xmm11
00007d0bb21d7aba  vmovaps [rsp+0xC0], xmm13
00007d0bb21d7ac3  vmovaps [rsp+0xD0], xmm14
00007d0bb21d7acc  vmovaps [rsp+0xE0], xmm15
00007d0bb21d7ad5  sub rsp, 0x30
00007d0bb21d7ad9  movaps [rsp], xmm12
00007d0bb21d7ade  movaps [rsp+0x10], xmm1
00007d0bb21d7ae3  movaps [rsp+0x20], xmm8
00007d0bb21d7ae9  lea rdi, [rsp]
00007d0bb21d7aed  mov esi, 0x00
00007d0bb21d7af2  mov rax, 0x6392BBE7F530
00007d0bb21d7afc  call rax
00007d0bb21d7afe  movaps xmm12, [rsp]
00007d0bb21d7b03  add rsp, 0x30
00007d0bb21d7b07  vmovaps xmm0, [rsp]
00007d0bb21d7b0c  vmovaps xmm1, [rsp+0x10]
00007d0bb21d7b12  vmovaps xmm2, [rsp+0x20]
00007d0bb21d7b18  vmovaps xmm3, [rsp+0x30]
00007d0bb21d7b1e  vmovaps xmm4, [rsp+0x40]
00007d0bb21d7b24  vmovaps xmm5, [rsp+0x50]
00007d0bb21d7b2a  vmovaps xmm6, [rsp+0x60]
00007d0bb21d7b30  vmovaps xmm7, [rsp+0x70]
00007d0bb21d7b36  vmovaps xmm8, [rsp+0x80]
00007d0bb21d7b3f  vmovaps xmm9, [rsp+0x90]
00007d0bb21d7b48  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d7b51  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d7b5a  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d7b63  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d7b6c  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d7b75  add rsp, 0xF0
00007d0bb21d7b7c  pop r11
00007d0bb21d7b7e  pop r10
00007d0bb21d7b80  pop r9
00007d0bb21d7b82  pop r8
00007d0bb21d7b84  pop rsi
00007d0bb21d7b85  pop rdi
00007d0bb21d7b86  pop rdx
00007d0bb21d7b87  pop rcx
00007d0bb21d7b88  pop rax
00007d0bb21d7b89  add rsp, 0x08
00007d0bb21d7b8d  jmp 0x00007D0BB21D33BE
00007d0bb21d7b92  call 0x00007D0BB1FFF430
00007d0bb21d7b97  jmp 0x00007D0BB21D33C8
00007d0bb21d7b9c  sub rsp, 0x08
00007d0bb21d7ba0  push rax
00007d0bb21d7ba1  push rcx
00007d0bb21d7ba2  push rdx
00007d0bb21d7ba3  push rdi
00007d0bb21d7ba4  push rsi
00007d0bb21d7ba5  push r8
00007d0bb21d7ba7  push r9
00007d0bb21d7ba9  push r10
00007d0bb21d7bab  push r11
00007d0bb21d7bad  sub rsp, 0xF0
00007d0bb21d7bb4  vmovaps [rsp], xmm0
00007d0bb21d7bb9  vmovaps [rsp+0x10], xmm1
00007d0bb21d7bbf  vmovaps [rsp+0x20], xmm2
00007d0bb21d7bc5  vmovaps [rsp+0x30], xmm3
00007d0bb21d7bcb  vmovaps [rsp+0x40], xmm4
00007d0bb21d7bd1  vmovaps [rsp+0x50], xmm5
00007d0bb21d7bd7  vmovaps [rsp+0x60], xmm6
00007d0bb21d7bdd  vmovaps [rsp+0x70], xmm7
00007d0bb21d7be3  vmovaps [rsp+0x80], xmm9
00007d0bb21d7bec  vmovaps [rsp+0x90], xmm10
00007d0bb21d7bf5  vmovaps [rsp+0xA0], xmm11
00007d0bb21d7bfe  vmovaps [rsp+0xB0], xmm12
00007d0bb21d7c07  vmovaps [rsp+0xC0], xmm13
00007d0bb21d7c10  vmovaps [rsp+0xD0], xmm14
00007d0bb21d7c19  vmovaps [rsp+0xE0], xmm15
00007d0bb21d7c22  sub rsp, 0x30
00007d0bb21d7c26  movaps [rsp], xmm8
00007d0bb21d7c2b  movaps [rsp+0x10], xmm15
00007d0bb21d7c31  movaps [rsp+0x20], xmm9
00007d0bb21d7c37  lea rdi, [rsp]
00007d0bb21d7c3b  mov esi, 0x00
00007d0bb21d7c40  mov rax, 0x6392BBE7F530
00007d0bb21d7c4a  call rax
00007d0bb21d7c4c  movaps xmm8, [rsp]
00007d0bb21d7c51  add rsp, 0x30
00007d0bb21d7c55  vmovaps xmm0, [rsp]
00007d0bb21d7c5a  vmovaps xmm1, [rsp+0x10]
00007d0bb21d7c60  vmovaps xmm2, [rsp+0x20]
00007d0bb21d7c66  vmovaps xmm3, [rsp+0x30]
00007d0bb21d7c6c  vmovaps xmm4, [rsp+0x40]
00007d0bb21d7c72  vmovaps xmm5, [rsp+0x50]
00007d0bb21d7c78  vmovaps xmm6, [rsp+0x60]
00007d0bb21d7c7e  vmovaps xmm7, [rsp+0x70]
00007d0bb21d7c84  vmovaps xmm9, [rsp+0x80]
00007d0bb21d7c8d  vmovaps xmm10, [rsp+0x90]
00007d0bb21d7c96  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d7c9f  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d7ca8  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d7cb1  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d7cba  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d7cc3  add rsp, 0xF0
00007d0bb21d7cca  pop r11
00007d0bb21d7ccc  pop r10
00007d0bb21d7cce  pop r9
00007d0bb21d7cd0  pop r8
00007d0bb21d7cd2  pop rsi
00007d0bb21d7cd3  pop rdi
00007d0bb21d7cd4  pop rdx
00007d0bb21d7cd5  pop rcx
00007d0bb21d7cd6  pop rax
00007d0bb21d7cd7  add rsp, 0x08
00007d0bb21d7cdb  jmp 0x00007D0BB21D33EA
00007d0bb21d7ce0  sub rsp, 0x08
00007d0bb21d7ce4  push rax
00007d0bb21d7ce5  push rcx
00007d0bb21d7ce6  push rdx
00007d0bb21d7ce7  push rdi
00007d0bb21d7ce8  push rsi
00007d0bb21d7ce9  push r8
00007d0bb21d7ceb  push r9
00007d0bb21d7ced  push r10
00007d0bb21d7cef  push r11
00007d0bb21d7cf1  sub rsp, 0xF0
00007d0bb21d7cf8  vmovaps [rsp], xmm0
00007d0bb21d7cfd  vmovaps [rsp+0x10], xmm1
00007d0bb21d7d03  vmovaps [rsp+0x20], xmm2
00007d0bb21d7d09  vmovaps [rsp+0x30], xmm3
00007d0bb21d7d0f  vmovaps [rsp+0x40], xmm4
00007d0bb21d7d15  vmovaps [rsp+0x50], xmm5
00007d0bb21d7d1b  vmovaps [rsp+0x60], xmm6
00007d0bb21d7d21  vmovaps [rsp+0x70], xmm7
00007d0bb21d7d27  vmovaps [rsp+0x80], xmm8
00007d0bb21d7d30  vmovaps [rsp+0x90], xmm10
00007d0bb21d7d39  vmovaps [rsp+0xA0], xmm11
00007d0bb21d7d42  vmovaps [rsp+0xB0], xmm12
00007d0bb21d7d4b  vmovaps [rsp+0xC0], xmm13
00007d0bb21d7d54  vmovaps [rsp+0xD0], xmm14
00007d0bb21d7d5d  vmovaps [rsp+0xE0], xmm15
00007d0bb21d7d66  sub rsp, 0x30
00007d0bb21d7d6a  movaps [rsp], xmm9
00007d0bb21d7d6f  movaps [rsp+0x10], xmm1
00007d0bb21d7d74  movaps [rsp+0x20], xmm15
00007d0bb21d7d7a  lea rdi, [rsp]
00007d0bb21d7d7e  mov esi, 0x00
00007d0bb21d7d83  mov rax, 0x6392BBE7F530
00007d0bb21d7d8d  call rax
00007d0bb21d7d8f  movaps xmm9, [rsp]
00007d0bb21d7d94  add rsp, 0x30
00007d0bb21d7d98  vmovaps xmm0, [rsp]
00007d0bb21d7d9d  vmovaps xmm1, [rsp+0x10]
00007d0bb21d7da3  vmovaps xmm2, [rsp+0x20]
00007d0bb21d7da9  vmovaps xmm3, [rsp+0x30]
00007d0bb21d7daf  vmovaps xmm4, [rsp+0x40]
00007d0bb21d7db5  vmovaps xmm5, [rsp+0x50]
00007d0bb21d7dbb  vmovaps xmm6, [rsp+0x60]
00007d0bb21d7dc1  vmovaps xmm7, [rsp+0x70]
00007d0bb21d7dc7  vmovaps xmm8, [rsp+0x80]
00007d0bb21d7dd0  vmovaps xmm10, [rsp+0x90]
00007d0bb21d7dd9  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d7de2  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d7deb  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d7df4  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d7dfd  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d7e06  add rsp, 0xF0
00007d0bb21d7e0d  pop r11
00007d0bb21d7e0f  pop r10
00007d0bb21d7e11  pop r9
00007d0bb21d7e13  pop r8
00007d0bb21d7e15  pop rsi
00007d0bb21d7e16  pop rdi
00007d0bb21d7e17  pop rdx
00007d0bb21d7e18  pop rcx
00007d0bb21d7e19  pop rax
00007d0bb21d7e1a  add rsp, 0x08
00007d0bb21d7e1e  jmp 0x00007D0BB21D3418
00007d0bb21d7e23  sub rsp, 0x08
00007d0bb21d7e27  push rax
00007d0bb21d7e28  push rcx
00007d0bb21d7e29  push rdx
00007d0bb21d7e2a  push rdi
00007d0bb21d7e2b  push rsi
00007d0bb21d7e2c  push r8
00007d0bb21d7e2e  push r9
00007d0bb21d7e30  push r10
00007d0bb21d7e32  push r11
00007d0bb21d7e34  sub rsp, 0xF0
00007d0bb21d7e3b  vmovaps [rsp], xmm0
00007d0bb21d7e40  vmovaps [rsp+0x10], xmm1
00007d0bb21d7e46  vmovaps [rsp+0x20], xmm2
00007d0bb21d7e4c  vmovaps [rsp+0x30], xmm3
00007d0bb21d7e52  vmovaps [rsp+0x40], xmm4
00007d0bb21d7e58  vmovaps [rsp+0x50], xmm5
00007d0bb21d7e5e  vmovaps [rsp+0x60], xmm6
00007d0bb21d7e64  vmovaps [rsp+0x70], xmm7
00007d0bb21d7e6a  vmovaps [rsp+0x80], xmm8
00007d0bb21d7e73  vmovaps [rsp+0x90], xmm9
00007d0bb21d7e7c  vmovaps [rsp+0xA0], xmm10
00007d0bb21d7e85  vmovaps [rsp+0xB0], xmm11
00007d0bb21d7e8e  vmovaps [rsp+0xC0], xmm12
00007d0bb21d7e97  vmovaps [rsp+0xD0], xmm13
00007d0bb21d7ea0  vmovaps [rsp+0xE0], xmm14
00007d0bb21d7ea9  sub rsp, 0x30
00007d0bb21d7ead  movaps [rsp], xmm15
00007d0bb21d7eb2  movaps [rsp+0x10], xmm4
00007d0bb21d7eb7  movaps [rsp+0x20], xmm1
00007d0bb21d7ebc  lea rdi, [rsp]
00007d0bb21d7ec0  mov esi, 0x00
00007d0bb21d7ec5  mov rax, 0x6392BBE7F530
00007d0bb21d7ecf  call rax
00007d0bb21d7ed1  movaps xmm15, [rsp]
00007d0bb21d7ed6  add rsp, 0x30
00007d0bb21d7eda  vmovaps xmm0, [rsp]
00007d0bb21d7edf  vmovaps xmm1, [rsp+0x10]
00007d0bb21d7ee5  vmovaps xmm2, [rsp+0x20]
00007d0bb21d7eeb  vmovaps xmm3, [rsp+0x30]
00007d0bb21d7ef1  vmovaps xmm4, [rsp+0x40]
00007d0bb21d7ef7  vmovaps xmm5, [rsp+0x50]
00007d0bb21d7efd  vmovaps xmm6, [rsp+0x60]
00007d0bb21d7f03  vmovaps xmm7, [rsp+0x70]
00007d0bb21d7f09  vmovaps xmm8, [rsp+0x80]
00007d0bb21d7f12  vmovaps xmm9, [rsp+0x90]
00007d0bb21d7f1b  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d7f24  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d7f2d  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d7f36  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d7f3f  vmovaps xmm14, [rsp+0xE0]
00007d0bb21d7f48  add rsp, 0xF0
00007d0bb21d7f4f  pop r11
00007d0bb21d7f51  pop r10
00007d0bb21d7f53  pop r9
00007d0bb21d7f55  pop r8
00007d0bb21d7f57  pop rsi
00007d0bb21d7f58  pop rdi
00007d0bb21d7f59  pop rdx
00007d0bb21d7f5a  pop rcx
00007d0bb21d7f5b  pop rax
00007d0bb21d7f5c  add rsp, 0x08
00007d0bb21d7f60  jmp 0x00007D0BB21D343E
00007d0bb21d7f65  sub rsp, 0x08
00007d0bb21d7f69  push rax
00007d0bb21d7f6a  push rcx
00007d0bb21d7f6b  push rdx
00007d0bb21d7f6c  push rdi
00007d0bb21d7f6d  push rsi
00007d0bb21d7f6e  push r8
00007d0bb21d7f70  push r9
00007d0bb21d7f72  push r10
00007d0bb21d7f74  push r11
00007d0bb21d7f76  sub rsp, 0xF0
00007d0bb21d7f7d  vmovaps [rsp], xmm0
00007d0bb21d7f82  vmovaps [rsp+0x10], xmm2
00007d0bb21d7f88  vmovaps [rsp+0x20], xmm3
00007d0bb21d7f8e  vmovaps [rsp+0x30], xmm4
00007d0bb21d7f94  vmovaps [rsp+0x40], xmm5
00007d0bb21d7f9a  vmovaps [rsp+0x50], xmm6
00007d0bb21d7fa0  vmovaps [rsp+0x60], xmm7
00007d0bb21d7fa6  vmovaps [rsp+0x70], xmm8
00007d0bb21d7fac  vmovaps [rsp+0x80], xmm9
00007d0bb21d7fb5  vmovaps [rsp+0x90], xmm10
00007d0bb21d7fbe  vmovaps [rsp+0xA0], xmm11
00007d0bb21d7fc7  vmovaps [rsp+0xB0], xmm12
00007d0bb21d7fd0  vmovaps [rsp+0xC0], xmm13
00007d0bb21d7fd9  vmovaps [rsp+0xD0], xmm14
00007d0bb21d7fe2  vmovaps [rsp+0xE0], xmm15
00007d0bb21d7feb  sub rsp, 0x30
00007d0bb21d7fef  movaps [rsp], xmm1
00007d0bb21d7ff3  movaps [rsp+0x10], xmm14
00007d0bb21d7ff9  movaps [rsp+0x20], xmm11
00007d0bb21d7fff  lea rdi, [rsp]
00007d0bb21d8003  mov esi, 0x00
00007d0bb21d8008  mov rax, 0x6392BBE7F530
00007d0bb21d8012  call rax
00007d0bb21d8014  movaps xmm1, [rsp]
00007d0bb21d8018  add rsp, 0x30
00007d0bb21d801c  vmovaps xmm0, [rsp]
00007d0bb21d8021  vmovaps xmm2, [rsp+0x10]
00007d0bb21d8027  vmovaps xmm3, [rsp+0x20]
00007d0bb21d802d  vmovaps xmm4, [rsp+0x30]
00007d0bb21d8033  vmovaps xmm5, [rsp+0x40]
00007d0bb21d8039  vmovaps xmm6, [rsp+0x50]
00007d0bb21d803f  vmovaps xmm7, [rsp+0x60]
00007d0bb21d8045  vmovaps xmm8, [rsp+0x70]
00007d0bb21d804b  vmovaps xmm9, [rsp+0x80]
00007d0bb21d8054  vmovaps xmm10, [rsp+0x90]
00007d0bb21d805d  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d8066  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d806f  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d8078  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d8081  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d808a  add rsp, 0xF0
00007d0bb21d8091  pop r11
00007d0bb21d8093  pop r10
00007d0bb21d8095  pop r9
00007d0bb21d8097  pop r8
00007d0bb21d8099  pop rsi
00007d0bb21d809a  pop rdi
00007d0bb21d809b  pop rdx
00007d0bb21d809c  pop rcx
00007d0bb21d809d  pop rax
00007d0bb21d809e  add rsp, 0x08
00007d0bb21d80a2  jmp 0x00007D0BB21D345F
00007d0bb21d80a7  call 0x00007D0BB20E45A0
00007d0bb21d80ac  jmp 0x00007D0BB21D346D
00007d0bb21d80b1  call 0x00007D0BB2009D70
00007d0bb21d80b6  jmp 0x00007D0BB21D3477
00007d0bb21d80bb  sub rsp, 0x08
00007d0bb21d80bf  push rax
00007d0bb21d80c0  push rcx
00007d0bb21d80c1  push rdx
00007d0bb21d80c2  push rdi
00007d0bb21d80c3  push rsi
00007d0bb21d80c4  push r8
00007d0bb21d80c6  push r9
00007d0bb21d80c8  push r10
00007d0bb21d80ca  push r11
00007d0bb21d80cc  sub rsp, 0xF0
00007d0bb21d80d3  vmovaps [rsp], xmm0
00007d0bb21d80d8  vmovaps [rsp+0x10], xmm1
00007d0bb21d80de  vmovaps [rsp+0x20], xmm2
00007d0bb21d80e4  vmovaps [rsp+0x30], xmm3
00007d0bb21d80ea  vmovaps [rsp+0x40], xmm4
00007d0bb21d80f0  vmovaps [rsp+0x50], xmm5
00007d0bb21d80f6  vmovaps [rsp+0x60], xmm6
00007d0bb21d80fc  vmovaps [rsp+0x70], xmm8
00007d0bb21d8102  vmovaps [rsp+0x80], xmm9
00007d0bb21d810b  vmovaps [rsp+0x90], xmm10
00007d0bb21d8114  vmovaps [rsp+0xA0], xmm11
00007d0bb21d811d  vmovaps [rsp+0xB0], xmm12
00007d0bb21d8126  vmovaps [rsp+0xC0], xmm13
00007d0bb21d812f  vmovaps [rsp+0xD0], xmm14
00007d0bb21d8138  vmovaps [rsp+0xE0], xmm15
00007d0bb21d8141  sub rsp, 0x30
00007d0bb21d8145  movaps [rsp], xmm7
00007d0bb21d8149  movaps [rsp+0x10], xmm13
00007d0bb21d814f  movaps [rsp+0x20], xmm10
00007d0bb21d8155  lea rdi, [rsp]
00007d0bb21d8159  mov esi, 0x00
00007d0bb21d815e  mov rax, 0x6392BBE7F530
00007d0bb21d8168  call rax
00007d0bb21d816a  movaps xmm7, [rsp]
00007d0bb21d816e  add rsp, 0x30
00007d0bb21d8172  vmovaps xmm0, [rsp]
00007d0bb21d8177  vmovaps xmm1, [rsp+0x10]
00007d0bb21d817d  vmovaps xmm2, [rsp+0x20]
00007d0bb21d8183  vmovaps xmm3, [rsp+0x30]
00007d0bb21d8189  vmovaps xmm4, [rsp+0x40]
00007d0bb21d818f  vmovaps xmm5, [rsp+0x50]
00007d0bb21d8195  vmovaps xmm6, [rsp+0x60]
00007d0bb21d819b  vmovaps xmm8, [rsp+0x70]
00007d0bb21d81a1  vmovaps xmm9, [rsp+0x80]
00007d0bb21d81aa  vmovaps xmm10, [rsp+0x90]
00007d0bb21d81b3  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d81bc  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d81c5  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d81ce  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d81d7  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d81e0  add rsp, 0xF0
00007d0bb21d81e7  pop r11
00007d0bb21d81e9  pop r10
00007d0bb21d81eb  pop r9
00007d0bb21d81ed  pop r8
00007d0bb21d81ef  pop rsi
00007d0bb21d81f0  pop rdi
00007d0bb21d81f1  pop rdx
00007d0bb21d81f2  pop rcx
00007d0bb21d81f3  pop rax
00007d0bb21d81f4  add rsp, 0x08
00007d0bb21d81f8  jmp 0x00007D0BB21D3498
00007d0bb21d81fd  sub rsp, 0x08
00007d0bb21d8201  push rax
00007d0bb21d8202  push rcx
00007d0bb21d8203  push rdx
00007d0bb21d8204  push rdi
00007d0bb21d8205  push rsi
00007d0bb21d8206  push r8
00007d0bb21d8208  push r9
00007d0bb21d820a  push r10
00007d0bb21d820c  push r11
00007d0bb21d820e  sub rsp, 0xF0
00007d0bb21d8215  vmovaps [rsp], xmm0
00007d0bb21d821a  vmovaps [rsp+0x10], xmm1
00007d0bb21d8220  vmovaps [rsp+0x20], xmm2
00007d0bb21d8226  vmovaps [rsp+0x30], xmm3
00007d0bb21d822c  vmovaps [rsp+0x40], xmm4
00007d0bb21d8232  vmovaps [rsp+0x50], xmm5
00007d0bb21d8238  vmovaps [rsp+0x60], xmm6
00007d0bb21d823e  vmovaps [rsp+0x70], xmm7
00007d0bb21d8244  vmovaps [rsp+0x80], xmm8
00007d0bb21d824d  vmovaps [rsp+0x90], xmm9
00007d0bb21d8256  vmovaps [rsp+0xA0], xmm11
00007d0bb21d825f  vmovaps [rsp+0xB0], xmm12
00007d0bb21d8268  vmovaps [rsp+0xC0], xmm13
00007d0bb21d8271  vmovaps [rsp+0xD0], xmm14
00007d0bb21d827a  vmovaps [rsp+0xE0], xmm15
00007d0bb21d8283  sub rsp, 0x30
00007d0bb21d8287  movaps [rsp], xmm10
00007d0bb21d828c  movaps [rsp+0x10], xmm11
00007d0bb21d8292  movaps [rsp+0x20], xmm13
00007d0bb21d8298  lea rdi, [rsp]
00007d0bb21d829c  mov esi, 0x00
00007d0bb21d82a1  mov rax, 0x6392BBE7F530
00007d0bb21d82ab  call rax
00007d0bb21d82ad  movaps xmm10, [rsp]
00007d0bb21d82b2  add rsp, 0x30
00007d0bb21d82b6  vmovaps xmm0, [rsp]
00007d0bb21d82bb  vmovaps xmm1, [rsp+0x10]
00007d0bb21d82c1  vmovaps xmm2, [rsp+0x20]
00007d0bb21d82c7  vmovaps xmm3, [rsp+0x30]
00007d0bb21d82cd  vmovaps xmm4, [rsp+0x40]
00007d0bb21d82d3  vmovaps xmm5, [rsp+0x50]
00007d0bb21d82d9  vmovaps xmm6, [rsp+0x60]
00007d0bb21d82df  vmovaps xmm7, [rsp+0x70]
00007d0bb21d82e5  vmovaps xmm8, [rsp+0x80]
00007d0bb21d82ee  vmovaps xmm9, [rsp+0x90]
00007d0bb21d82f7  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d8300  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d8309  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d8312  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d831b  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d8324  add rsp, 0xF0
00007d0bb21d832b  pop r11
00007d0bb21d832d  pop r10
00007d0bb21d832f  pop r9
00007d0bb21d8331  pop r8
00007d0bb21d8333  pop rsi
00007d0bb21d8334  pop rdi
00007d0bb21d8335  pop rdx
00007d0bb21d8336  pop rcx
00007d0bb21d8337  pop rax
00007d0bb21d8338  add rsp, 0x08
00007d0bb21d833c  jmp 0x00007D0BB21D34C6
00007d0bb21d8341  sub rsp, 0x08
00007d0bb21d8345  push rax
00007d0bb21d8346  push rcx
00007d0bb21d8347  push rdx
00007d0bb21d8348  push rdi
00007d0bb21d8349  push rsi
00007d0bb21d834a  push r8
00007d0bb21d834c  push r9
00007d0bb21d834e  push r10
00007d0bb21d8350  push r11
00007d0bb21d8352  sub rsp, 0xF0
00007d0bb21d8359  vmovaps [rsp], xmm0
00007d0bb21d835e  vmovaps [rsp+0x10], xmm1
00007d0bb21d8364  vmovaps [rsp+0x20], xmm2
00007d0bb21d836a  vmovaps [rsp+0x30], xmm3
00007d0bb21d8370  vmovaps [rsp+0x40], xmm4
00007d0bb21d8376  vmovaps [rsp+0x50], xmm5
00007d0bb21d837c  vmovaps [rsp+0x60], xmm6
00007d0bb21d8382  vmovaps [rsp+0x70], xmm7
00007d0bb21d8388  vmovaps [rsp+0x80], xmm8
00007d0bb21d8391  vmovaps [rsp+0x90], xmm9
00007d0bb21d839a  vmovaps [rsp+0xA0], xmm10
00007d0bb21d83a3  vmovaps [rsp+0xB0], xmm12
00007d0bb21d83ac  vmovaps [rsp+0xC0], xmm13
00007d0bb21d83b5  vmovaps [rsp+0xD0], xmm14
00007d0bb21d83be  vmovaps [rsp+0xE0], xmm15
00007d0bb21d83c7  sub rsp, 0x30
00007d0bb21d83cb  movaps [rsp], xmm11
00007d0bb21d83d0  movaps [rsp+0x10], xmm14
00007d0bb21d83d6  movaps [rsp+0x20], xmm13
00007d0bb21d83dc  lea rdi, [rsp]
00007d0bb21d83e0  mov esi, 0x00
00007d0bb21d83e5  mov rax, 0x6392BBE7F530
00007d0bb21d83ef  call rax
00007d0bb21d83f1  movaps xmm11, [rsp]
00007d0bb21d83f6  add rsp, 0x30
00007d0bb21d83fa  vmovaps xmm0, [rsp]
00007d0bb21d83ff  vmovaps xmm1, [rsp+0x10]
00007d0bb21d8405  vmovaps xmm2, [rsp+0x20]
00007d0bb21d840b  vmovaps xmm3, [rsp+0x30]
00007d0bb21d8411  vmovaps xmm4, [rsp+0x40]
00007d0bb21d8417  vmovaps xmm5, [rsp+0x50]
00007d0bb21d841d  vmovaps xmm6, [rsp+0x60]
00007d0bb21d8423  vmovaps xmm7, [rsp+0x70]
00007d0bb21d8429  vmovaps xmm8, [rsp+0x80]
00007d0bb21d8432  vmovaps xmm9, [rsp+0x90]
00007d0bb21d843b  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d8444  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d844d  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d8456  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d845f  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d8468  add rsp, 0xF0
00007d0bb21d846f  pop r11
00007d0bb21d8471  pop r10
00007d0bb21d8473  pop r9
00007d0bb21d8475  pop r8
00007d0bb21d8477  pop rsi
00007d0bb21d8478  pop rdi
00007d0bb21d8479  pop rdx
00007d0bb21d847a  pop rcx
00007d0bb21d847b  pop rax
00007d0bb21d847c  add rsp, 0x08
00007d0bb21d8480  jmp 0x00007D0BB21D34F4
00007d0bb21d8485  sub rsp, 0x08
00007d0bb21d8489  push rax
00007d0bb21d848a  push rcx
00007d0bb21d848b  push rdx
00007d0bb21d848c  push rdi
00007d0bb21d848d  push rsi
00007d0bb21d848e  push r8
00007d0bb21d8490  push r9
00007d0bb21d8492  push r10
00007d0bb21d8494  push r11
00007d0bb21d8496  sub rsp, 0xF0
00007d0bb21d849d  vmovaps [rsp], xmm0
00007d0bb21d84a2  vmovaps [rsp+0x10], xmm1
00007d0bb21d84a8  vmovaps [rsp+0x20], xmm2
00007d0bb21d84ae  vmovaps [rsp+0x30], xmm3
00007d0bb21d84b4  vmovaps [rsp+0x40], xmm4
00007d0bb21d84ba  vmovaps [rsp+0x50], xmm5
00007d0bb21d84c0  vmovaps [rsp+0x60], xmm6
00007d0bb21d84c6  vmovaps [rsp+0x70], xmm7
00007d0bb21d84cc  vmovaps [rsp+0x80], xmm8
00007d0bb21d84d5  vmovaps [rsp+0x90], xmm9
00007d0bb21d84de  vmovaps [rsp+0xA0], xmm10
00007d0bb21d84e7  vmovaps [rsp+0xB0], xmm11
00007d0bb21d84f0  vmovaps [rsp+0xC0], xmm12
00007d0bb21d84f9  vmovaps [rsp+0xD0], xmm13
00007d0bb21d8502  vmovaps [rsp+0xE0], xmm15
00007d0bb21d850b  sub rsp, 0x30
00007d0bb21d850f  movaps [rsp], xmm14
00007d0bb21d8514  movaps [rsp+0x10], xmm12
00007d0bb21d851a  movaps [rsp+0x20], xmm9
00007d0bb21d8520  lea rdi, [rsp]
00007d0bb21d8524  mov esi, 0x00
00007d0bb21d8529  mov rax, 0x6392BBE7F530
00007d0bb21d8533  call rax
00007d0bb21d8535  movaps xmm14, [rsp]
00007d0bb21d853a  add rsp, 0x30
00007d0bb21d853e  vmovaps xmm0, [rsp]
00007d0bb21d8543  vmovaps xmm1, [rsp+0x10]
00007d0bb21d8549  vmovaps xmm2, [rsp+0x20]
00007d0bb21d854f  vmovaps xmm3, [rsp+0x30]
00007d0bb21d8555  vmovaps xmm4, [rsp+0x40]
00007d0bb21d855b  vmovaps xmm5, [rsp+0x50]
00007d0bb21d8561  vmovaps xmm6, [rsp+0x60]
00007d0bb21d8567  vmovaps xmm7, [rsp+0x70]
00007d0bb21d856d  vmovaps xmm8, [rsp+0x80]
00007d0bb21d8576  vmovaps xmm9, [rsp+0x90]
00007d0bb21d857f  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d8588  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d8591  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d859a  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d85a3  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d85ac  add rsp, 0xF0
00007d0bb21d85b3  pop r11
00007d0bb21d85b5  pop r10
00007d0bb21d85b7  pop r9
00007d0bb21d85b9  pop r8
00007d0bb21d85bb  pop rsi
00007d0bb21d85bc  pop rdi
00007d0bb21d85bd  pop rdx
00007d0bb21d85be  pop rcx
00007d0bb21d85bf  pop rax
00007d0bb21d85c0  add rsp, 0x08
00007d0bb21d85c4  jmp 0x00007D0BB21D350F
00007d0bb21d85c9  sub rsp, 0x08
00007d0bb21d85cd  push rax
00007d0bb21d85ce  push rcx
00007d0bb21d85cf  push rdx
00007d0bb21d85d0  push rdi
00007d0bb21d85d1  push rsi
00007d0bb21d85d2  push r8
00007d0bb21d85d4  push r9
00007d0bb21d85d6  push r10
00007d0bb21d85d8  push r11
00007d0bb21d85da  sub rsp, 0xF0
00007d0bb21d85e1  vmovaps [rsp], xmm0
00007d0bb21d85e6  vmovaps [rsp+0x10], xmm1
00007d0bb21d85ec  vmovaps [rsp+0x20], xmm2
00007d0bb21d85f2  vmovaps [rsp+0x30], xmm3
00007d0bb21d85f8  vmovaps [rsp+0x40], xmm4
00007d0bb21d85fe  vmovaps [rsp+0x50], xmm5
00007d0bb21d8604  vmovaps [rsp+0x60], xmm6
00007d0bb21d860a  vmovaps [rsp+0x70], xmm7
00007d0bb21d8610  vmovaps [rsp+0x80], xmm8
00007d0bb21d8619  vmovaps [rsp+0x90], xmm9
00007d0bb21d8622  vmovaps [rsp+0xA0], xmm10
00007d0bb21d862b  vmovaps [rsp+0xB0], xmm11
00007d0bb21d8634  vmovaps [rsp+0xC0], xmm12
00007d0bb21d863d  vmovaps [rsp+0xD0], xmm14
00007d0bb21d8646  vmovaps [rsp+0xE0], xmm15
00007d0bb21d864f  sub rsp, 0x30
00007d0bb21d8653  movaps [rsp], xmm13
00007d0bb21d8658  movaps [rsp+0x10], xmm8
00007d0bb21d865e  movaps [rsp+0x20], xmm15
00007d0bb21d8664  lea rdi, [rsp]
00007d0bb21d8668  mov esi, 0x00
00007d0bb21d866d  mov rax, 0x6392BBE7F530
00007d0bb21d8677  call rax
00007d0bb21d8679  movaps xmm13, [rsp]
00007d0bb21d867e  add rsp, 0x30
00007d0bb21d8682  vmovaps xmm0, [rsp]
00007d0bb21d8687  vmovaps xmm1, [rsp+0x10]
00007d0bb21d868d  vmovaps xmm2, [rsp+0x20]
00007d0bb21d8693  vmovaps xmm3, [rsp+0x30]
00007d0bb21d8699  vmovaps xmm4, [rsp+0x40]
00007d0bb21d869f  vmovaps xmm5, [rsp+0x50]
00007d0bb21d86a5  vmovaps xmm6, [rsp+0x60]
00007d0bb21d86ab  vmovaps xmm7, [rsp+0x70]
00007d0bb21d86b1  vmovaps xmm8, [rsp+0x80]
00007d0bb21d86ba  vmovaps xmm9, [rsp+0x90]
00007d0bb21d86c3  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d86cc  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d86d5  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d86de  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d86e7  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d86f0  add rsp, 0xF0
00007d0bb21d86f7  pop r11
00007d0bb21d86f9  pop r10
00007d0bb21d86fb  pop r9
00007d0bb21d86fd  pop r8
00007d0bb21d86ff  pop rsi
00007d0bb21d8700  pop rdi
00007d0bb21d8701  pop rdx
00007d0bb21d8702  pop rcx
00007d0bb21d8703  pop rax
00007d0bb21d8704  add rsp, 0x08
00007d0bb21d8708  jmp 0x00007D0BB21D3532
00007d0bb21d870d  sub rsp, 0x08
00007d0bb21d8711  push rax
00007d0bb21d8712  push rcx
00007d0bb21d8713  push rdx
00007d0bb21d8714  push rdi
00007d0bb21d8715  push rsi
00007d0bb21d8716  push r8
00007d0bb21d8718  push r9
00007d0bb21d871a  push r10
00007d0bb21d871c  push r11
00007d0bb21d871e  sub rsp, 0xF0
00007d0bb21d8725  vmovaps [rsp], xmm0
00007d0bb21d872a  vmovaps [rsp+0x10], xmm1
00007d0bb21d8730  vmovaps [rsp+0x20], xmm2
00007d0bb21d8736  vmovaps [rsp+0x30], xmm3
00007d0bb21d873c  vmovaps [rsp+0x40], xmm4
00007d0bb21d8742  vmovaps [rsp+0x50], xmm5
00007d0bb21d8748  vmovaps [rsp+0x60], xmm6
00007d0bb21d874e  vmovaps [rsp+0x70], xmm7
00007d0bb21d8754  vmovaps [rsp+0x80], xmm8
00007d0bb21d875d  vmovaps [rsp+0x90], xmm9
00007d0bb21d8766  vmovaps [rsp+0xA0], xmm10
00007d0bb21d876f  vmovaps [rsp+0xB0], xmm11
00007d0bb21d8778  vmovaps [rsp+0xC0], xmm12
00007d0bb21d8781  vmovaps [rsp+0xD0], xmm13
00007d0bb21d878a  vmovaps [rsp+0xE0], xmm14
00007d0bb21d8793  sub rsp, 0x30
00007d0bb21d8797  movaps [rsp], xmm15
00007d0bb21d879c  movaps [rsp+0x10], xmm1
00007d0bb21d87a1  movaps [rsp+0x20], xmm10
00007d0bb21d87a7  lea rdi, [rsp]
00007d0bb21d87ab  mov esi, 0x00
00007d0bb21d87b0  mov rax, 0x6392BBE7F530
00007d0bb21d87ba  call rax
00007d0bb21d87bc  movaps xmm15, [rsp]
00007d0bb21d87c1  add rsp, 0x30
00007d0bb21d87c5  vmovaps xmm0, [rsp]
00007d0bb21d87ca  vmovaps xmm1, [rsp+0x10]
00007d0bb21d87d0  vmovaps xmm2, [rsp+0x20]
00007d0bb21d87d6  vmovaps xmm3, [rsp+0x30]
00007d0bb21d87dc  vmovaps xmm4, [rsp+0x40]
00007d0bb21d87e2  vmovaps xmm5, [rsp+0x50]
00007d0bb21d87e8  vmovaps xmm6, [rsp+0x60]
00007d0bb21d87ee  vmovaps xmm7, [rsp+0x70]
00007d0bb21d87f4  vmovaps xmm8, [rsp+0x80]
00007d0bb21d87fd  vmovaps xmm9, [rsp+0x90]
00007d0bb21d8806  vmovaps xmm10, [rsp+0xA0]
00007d0bb21d880f  vmovaps xmm11, [rsp+0xB0]
00007d0bb21d8818  vmovaps xmm12, [rsp+0xC0]
00007d0bb21d8821  vmovaps xmm13, [rsp+0xD0]
00007d0bb21d882a  vmovaps xmm14, [rsp+0xE0]
00007d0bb21d8833  add rsp, 0xF0
00007d0bb21d883a  pop r11
00007d0bb21d883c  pop r10
00007d0bb21d883e  pop r9
00007d0bb21d8840  pop r8
00007d0bb21d8842  pop rsi
00007d0bb21d8843  pop rdi
00007d0bb21d8844  pop rdx
00007d0bb21d8845  pop rcx
00007d0bb21d8846  pop rax
00007d0bb21d8847  add rsp, 0x08
00007d0bb21d884b  jmp 0x00007D0BB21D3555
00007d0bb21d8850  sub rsp, 0x08
00007d0bb21d8854  push rax
00007d0bb21d8855  push rcx
00007d0bb21d8856  push rdx
00007d0bb21d8857  push rdi
00007d0bb21d8858  push rsi
00007d0bb21d8859  push r8
00007d0bb21d885b  push r9
00007d0bb21d885d  push r10
00007d0bb21d885f  push r11
00007d0bb21d8861  sub rsp, 0xF0
00007d0bb21d8868  vmovaps [rsp], xmm0
00007d0bb21d886d  vmovaps [rsp+0x10], xmm2
00007d0bb21d8873  vmovaps [rsp+0x20], xmm3
00007d0bb21d8879  vmovaps [rsp+0x30], xmm4
00007d0bb21d887f  vmovaps [rsp+0x40], xmm5
00007d0bb21d8885  vmovaps [rsp+0x50], xmm6
00007d0bb21d888b  vmovaps [rsp+0x60], xmm7
00007d0bb21d8891  vmovaps [rsp+0x70], xmm8
00007d0bb21d8897  vmovaps [rsp+0x80], xmm9
00007d0bb21d88a0  vmovaps [rsp+0x90], xmm10
00007d0bb21d88a9  vmovaps [rsp+0xA0], xmm11
00007d0bb21d88b2  vmovaps [rsp+0xB0], xmm12
00007d0bb21d88bb  vmovaps [rsp+0xC0], xmm13
00007d0bb21d88c4  vmovaps [rsp+0xD0], xmm14
00007d0bb21d88cd  vmovaps [rsp+0xE0], xmm15
00007d0bb21d88d6  sub rsp, 0x30
00007d0bb21d88da  movaps [rsp], xmm1
00007d0bb21d88de  movaps [rsp+0x10], xmm7
00007d0bb21d88e3  movaps [rsp+0x20], xmm11
00007d0bb21d88e9  lea rdi, [rsp]
00007d0bb21d88ed  mov esi, 0x00
00007d0bb21d88f2  mov rax, 0x6392BBE7F530
00007d0bb21d88fc  call rax
00007d0bb21d88fe  movaps xmm1, [rsp]
00007d0bb21d8902  add rsp, 0x30
00007d0bb21d8906  vmovaps xmm0, [rsp]
00007d0bb21d890b  vmovaps xmm2, [rsp+0x10]
00007d0bb21d8911  vmovaps xmm3, [rsp+0x20]
00007d0bb21d8917  vmovaps xmm4, [rsp+0x30]
00007d0bb21d891d  vmovaps xmm5, [rsp+0x40]
00007d0bb21d8923  vmovaps xmm6, [rsp+0x50]
00007d0bb21d8929  vmovaps xmm7, [rsp+0x60]
00007d0bb21d892f  vmovaps xmm8, [rsp+0x70]
00007d0bb21d8935  vmovaps xmm9, [rsp+0x80]
00007d0bb21d893e  vmovaps xmm10, [rsp+0x90]
00007d0bb21d8947  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d8950  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d8959  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d8962  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d896b  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d8974  add rsp, 0xF0
00007d0bb21d897b  pop r11
00007d0bb21d897d  pop r10
00007d0bb21d897f  pop r9
00007d0bb21d8981  pop r8
00007d0bb21d8983  pop rsi
00007d0bb21d8984  pop rdi
00007d0bb21d8985  pop rdx
00007d0bb21d8986  pop rcx
00007d0bb21d8987  pop rax
00007d0bb21d8988  add rsp, 0x08
00007d0bb21d898c  jmp 0x00007D0BB21D3576
00007d0bb21d8991  call 0x00007D0BB200D600
00007d0bb21d8996  jmp 0x00007D0BB21D3589
00007d0bb21d899b  call 0x00007D0BB200C380
00007d0bb21d89a0  jmp 0x00007D0BB21D3594
00007d0bb21d89a5  call 0x00007D0BB200E880
00007d0bb21d89aa  jmp 0x00007D0BB21D359F
00007d0bb21d89af  call 0x00007D0BB1FFF540
00007d0bb21d89b4  jmp 0x00007D0BB21D35AA
00007d0bb21d89b9  int3
00007d0bb21d89ba  nop [rax+rax*1], ax
00007d0bb21d89c0  mov rax, [r15+0x40]
00007d0bb21d89c4  mov r14, [r15+0x58]
00007d0bb21d89c8  lea r12, [rax+r14*1]
00007d0bb21d89cc  movaps xmm1, [r15+0x1D0]
00007d0bb21d89d4  vmovaps [rsp+0x10], xmm1
00007d0bb21d89da  vmovaps xmm15, [rsp+0x10]
00007d0bb21d89e0  por xmm1, xmm15
00007d0bb21d89e5  movaps xmm14, [r15+0x1A0]
00007d0bb21d89ed  vmovaps [rsp+0x10], xmm14
00007d0bb21d89f3  vmovaps xmm13, [rsp+0x10]
00007d0bb21d89f9  por xmm14, xmm13
00007d0bb21d89fe  lea rax, [r12+0x30]
00007d0bb21d8a03  mov r11, [r13+rax*1]
00007d0bb21d8a08  lea rax, [r12+0x38]
00007d0bb21d8a0d  mov r10, [r13+rax*1]
00007d0bb21d8a12  movq xmm13, r11
00007d0bb21d8a17  movq xmm12, r10
00007d0bb21d8a1c  movq xmm13, xmm13
00007d0bb21d8a21  vmovaps [rsp+0x10], xmm13
00007d0bb21d8a27  movq xmm13, xmm13
00007d0bb21d8a2c  movaps [r15+0x130], xmm13
00007d0bb21d8a34  movq xmm12, xmm12
00007d0bb21d8a39  vmovaps [rsp+0x20], xmm12
00007d0bb21d8a3f  movq xmm12, xmm12
00007d0bb21d8a44  movaps [r15+0x280], xmm12
00007d0bb21d8a4c  movaps xmm13, [r15+0x270]
00007d0bb21d8a54  vmovaps [rsp+0x30], xmm13
00007d0bb21d8a5a  vmovaps xmm12, [rsp+0x30]
00007d0bb21d8a60  por xmm13, xmm12
00007d0bb21d8a65  lea rax, [r12+0x20]
00007d0bb21d8a6a  mov r11, [r13+rax*1]
00007d0bb21d8a6f  lea rax, [r12+0x28]
00007d0bb21d8a74  mov r10, [r13+rax*1]
00007d0bb21d8a79  movq xmm12, r11
00007d0bb21d8a7e  movq xmm11, r10
00007d0bb21d8a83  movq xmm12, xmm12
00007d0bb21d8a88  vmovaps [rsp+0x30], xmm12
00007d0bb21d8a8e  movq xmm12, xmm12
00007d0bb21d8a93  movaps [r15+0x150], xmm12
00007d0bb21d8a9b  movq xmm11, xmm11
00007d0bb21d8aa0  vmovaps [rsp+0x40], xmm11
00007d0bb21d8aa6  movq xmm11, xmm11
00007d0bb21d8aab  movaps [r15+0x140], xmm11
00007d0bb21d8ab3  lea rax, [r12+0x10]
00007d0bb21d8ab8  mov r11, [r13+rax*1]
00007d0bb21d8abd  lea rax, [r12+0x18]
00007d0bb21d8ac2  mov r10, [r13+rax*1]
00007d0bb21d8ac7  movq xmm12, r11
00007d0bb21d8acc  movq xmm11, r10
00007d0bb21d8ad1  movq xmm12, xmm12
00007d0bb21d8ad6  vmovaps [rsp+0x50], xmm12
00007d0bb21d8adc  movq xmm12, xmm12
00007d0bb21d8ae1  movaps [r15+0x170], xmm12
00007d0bb21d8ae9  movq xmm11, xmm11
00007d0bb21d8aee  vmovaps [rsp+0x60], xmm11
00007d0bb21d8af4  movq xmm11, xmm11
00007d0bb21d8af9  movaps [r15+0x160], xmm11
00007d0bb21d8b01  mov rax, [r13+r12*1]
00007d0bb21d8b06  vmovq xmm12, rax
00007d0bb21d8b0b  vpbroadcastq xmm12, xmm12
00007d0bb21d8b10  lea rax, [r12+0x08]
00007d0bb21d8b15  mov r12, [r13+rax*1]
00007d0bb21d8b1a  movq xmm11, r12
00007d0bb21d8b1f  movaps [r15+0x230], xmm11
00007d0bb21d8b27  mov rax, [r15+0xF8]
00007d0bb21d8b2e  lea r12, [rax+0x50]
00007d0bb21d8b32  movups xmm11, [r13+r12*1]
00007d0bb21d8b38  lea r12, [rax+0x60]
00007d0bb21d8b3c  movups xmm10, [r13+r12*1]
00007d0bb21d8b42  lea r12, [rax+0x30]
00007d0bb21d8b46  movups xmm9, [r13+r12*1]
00007d0bb21d8b4c  mov r12, [r15+0x50]
00007d0bb21d8b50  lea r11, [r12+r14*1]
00007d0bb21d8b54  mov [r15+0x60], r11
00007d0bb21d8b58  lea r12, [r14+0x40]
00007d0bb21d8b5c  mov [r15+0x58], r12
00007d0bb21d8b60  movaps xmm8, xmm12
00007d0bb21d8b64  mulpd xmm8, xmm15
00007d0bb21d8b69  vcmppd xmm7, xmm8, xmm8, 0x03
00007d0bb21d8b6f  ptest xmm7, xmm7
00007d0bb21d8b74  jnz 0x00007D0BB21D9997
00007d0bb21d8b7a  movq xmm15, qword ptr [r15+0x230]
00007d0bb21d8b83  vmovaps [rsp+0x70], xmm15
00007d0bb21d8b89  vpermilpd xmm15, xmm15, 0x00
00007d0bb21d8b8f  movaps xmm7, xmm9
00007d0bb21d8b93  mulpd xmm7, xmm15
00007d0bb21d8b98  vcmppd xmm6, xmm7, xmm7, 0x03
00007d0bb21d8b9d  ptest xmm6, xmm6
00007d0bb21d8ba2  jnz 0x00007D0BB21D9ADB
00007d0bb21d8ba8  vxorps xmm15, xmm15, xmm15
00007d0bb21d8bad  vpbroadcastq xmm15, xmm15
00007d0bb21d8bb2  movaps xmm9, xmm12
00007d0bb21d8bb6  mulpd xmm9, xmm10
00007d0bb21d8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
00007d0bb21d8bc1  ptest xmm6, xmm6
00007d0bb21d8bc6  jnz 0x00007D0BB21D9C1D
00007d0bb21d8bcc  movaps xmm10, xmm12
00007d0bb21d8bd0  mulpd xmm10, xmm11
00007d0bb21d8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
00007d0bb21d8bdb  ptest xmm6, xmm6
00007d0bb21d8be0  jnz 0x00007D0BB21D9D61
00007d0bb21d8be6  movaps xmm11, [r15+0x1F0]
00007d0bb21d8bee  movaps xmm6, xmm12
00007d0bb21d8bf2  mulpd xmm6, xmm11
00007d0bb21d8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
00007d0bb21d8bfc  ptest xmm5, xmm5
00007d0bb21d8c01  jnz 0x00007D0BB21D9EA5
00007d0bb21d8c07  movaps xmm12, [r15+0x2A0]
00007d0bb21d8c0f  vmovaps [rsp+0x80], xmm12
00007d0bb21d8c18  vmovaps xmm11, [rsp+0x80]
00007d0bb21d8c21  por xmm12, xmm11
00007d0bb21d8c26  movaps xmm11, [r15+0x250]
00007d0bb21d8c2e  vmovaps [rsp+0x80], xmm11
00007d0bb21d8c37  vmovaps xmm5, [rsp+0x80]
00007d0bb21d8c40  por xmm11, xmm5
00007d0bb21d8c45  vmovaps xmm4, [rsp+0x70]
00007d0bb21d8c4b  vpermilpd xmm4, xmm4, 0x00
00007d0bb21d8c51  movaps xmm3, xmm5
00007d0bb21d8c54  mulpd xmm3, xmm4
00007d0bb21d8c58  vcmppd xmm2, xmm3, xmm3, 0x03
00007d0bb21d8c5d  ptest xmm2, xmm2
00007d0bb21d8c62  jnz 0x00007D0BB21D9FE7
00007d0bb21d8c68  mov [rsp+0x80], rax
00007d0bb21d8c70  xor eax, eax
00007d0bb21d8c72  mov r14d, 0x200
00007d0bb21d8c78  cmp r12, r14
00007d0bb21d8c7b  cmc
00007d0bb21d8c7c  lahf
00007d0bb21d8c7d  seto al
00007d0bb21d8c80  mov [r15+0x108], eax
00007d0bb21d8c87  movaps xmm5, xmm8
00007d0bb21d8c8b  addpd xmm5, xmm15
00007d0bb21d8c90  vcmppd xmm4, xmm5, xmm5, 0x03
00007d0bb21d8c95  ptest xmm4, xmm4
00007d0bb21d8c9a  jnz 0x00007D0BB21DA127
00007d0bb21d8ca0  movaps xmm8, [r15+0x1B0]
00007d0bb21d8ca8  movaps xmm4, xmm9
00007d0bb21d8cac  addpd xmm4, xmm8
00007d0bb21d8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
00007d0bb21d8cb6  ptest xmm2, xmm2
00007d0bb21d8cbb  jnz 0x00007D0BB21DA269
00007d0bb21d8cc1  movaps xmm9, xmm10
00007d0bb21d8cc5  addpd xmm9, xmm8
00007d0bb21d8cca  vcmppd xmm2, xmm9, xmm9, 0x03
00007d0bb21d8cd0  ptest xmm2, xmm2
00007d0bb21d8cd5  jnz 0x00007D0BB21DA3AB
00007d0bb21d8cdb  movaps xmm10, [r15+0x2F0]
00007d0bb21d8ce3  vmovaps [rsp+0x90], xmm10
00007d0bb21d8cec  vmovaps xmm8, [rsp+0x90]
00007d0bb21d8cf5  por xmm10, xmm8
00007d0bb21d8cfa  movaps xmm8, [r15+0x2E0]
00007d0bb21d8d02  vmovaps [rsp+0x90], xmm8
00007d0bb21d8d0b  vmovaps xmm2, [rsp+0x90]
00007d0bb21d8d14  por xmm8, xmm2
00007d0bb21d8d19  movaps xmm2, [r15+0x2D0]
00007d0bb21d8d21  vmovaps [rsp+0x90], xmm2
00007d0bb21d8d2a  vmovaps [rsp+0xA0], xmm1
00007d0bb21d8d33  vmovaps xmm1, [rsp+0x90]
00007d0bb21d8d3c  por xmm2, xmm1
00007d0bb21d8d40  movaps xmm1, [r15+0x200]
00007d0bb21d8d48  vmovaps [rsp+0x90], xmm1
00007d0bb21d8d51  vmovaps [rsp+0xB0], xmm15
00007d0bb21d8d5a  vmovaps xmm15, [rsp+0x90]
00007d0bb21d8d63  por xmm1, xmm15
00007d0bb21d8d68  movaps xmm15, [r15+0x1C0]
00007d0bb21d8d70  vmovaps [rsp+0x90], xmm15
00007d0bb21d8d79  vmovaps [rsp+0xC0], xmm1
00007d0bb21d8d82  vmovaps xmm1, [rsp+0x90]
00007d0bb21d8d8b  por xmm15, xmm1
00007d0bb21d8d90  movaps xmm1, [r15+0x190]
00007d0bb21d8d98  vmovaps [rsp+0x90], xmm1
00007d0bb21d8da1  vmovaps [rsp+0xD0], xmm15
00007d0bb21d8daa  vmovaps xmm15, [rsp+0x90]
00007d0bb21d8db3  por xmm1, xmm15
00007d0bb21d8db8  movaps xmm15, [r15+0x300]
00007d0bb21d8dc0  vmovaps [rsp+0x90], xmm15
00007d0bb21d8dc9  vmovaps [rsp+0xE0], xmm1
00007d0bb21d8dd2  vmovaps xmm1, [rsp+0x90]
00007d0bb21d8ddb  por xmm15, xmm1
00007d0bb21d8de0  mov rax, [rsp+0x80]
00007d0bb21d8de8  lea r14, [rax+0xA0]
00007d0bb21d8def  movups xmm1, [r13+r14*1]
00007d0bb21d8df5  lea r14, [rax+0xB0]
00007d0bb21d8dfc  vmovaps [rsp+0x80], xmm1
00007d0bb21d8e05  movups xmm1, [r13+r14*1]
00007d0bb21d8e0b  vmovaps [rsp+0x90], xmm1
00007d0bb21d8e14  vmovaps [rsp+0xF0], xmm15
00007d0bb21d8e1d  vmovaps xmm15, [rsp+0xB0]
00007d0bb21d8e26  vmovaps [rsp+0xB0], xmm14
00007d0bb21d8e2f  movaps xmm1, xmm6
00007d0bb21d8e32  addpd xmm1, xmm15
00007d0bb21d8e37  vcmppd xmm14, xmm1, xmm1, 0x03
00007d0bb21d8e3c  ptest xmm14, xmm14
00007d0bb21d8e42  jnz 0x00007D0BB21DA503
00007d0bb21d8e48  lea r14, [rax+0xF0]
00007d0bb21d8e4f  movups xmm15, [r13+r14*1]
00007d0bb21d8e55  movaps xmm14, xmm4
00007d0bb21d8e59  addpd xmm14, xmm3
00007d0bb21d8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
00007d0bb21d8e64  ptest xmm6, xmm6
00007d0bb21d8e69  jnz 0x00007D0BB21DA64E
00007d0bb21d8e6f  movaps xmm6, xmm9
00007d0bb21d8e73  addpd xmm6, xmm7
00007d0bb21d8e77  vcmppd xmm4, xmm6, xmm6, 0x03
00007d0bb21d8e7c  ptest xmm4, xmm4
00007d0bb21d8e81  jnz 0x00007D0BB21DA790
00007d0bb21d8e87  vmovaps xmm9, [rsp+0x70]
00007d0bb21d8e8d  vpermilpd xmm9, xmm9, 0x00
00007d0bb21d8e93  vmovaps xmm4, [rsp+0x90]
00007d0bb21d8e9c  movaps xmm7, xmm4
00007d0bb21d8e9f  mulpd xmm7, xmm9
00007d0bb21d8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
00007d0bb21d8ea9  ptest xmm3, xmm3
00007d0bb21d8eae  jnz 0x00007D0BB21DA8D1
00007d0bb21d8eb4  vmovaps xmm9, [rsp+0x50]
00007d0bb21d8eba  vpermilpd xmm9, xmm9, 0x00
00007d0bb21d8ec0  movaps xmm4, xmm15
00007d0bb21d8ec4  mulpd xmm4, xmm9
00007d0bb21d8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
00007d0bb21d8ece  ptest xmm3, xmm3
00007d0bb21d8ed3  jnz 0x00007D0BB21DAA12
00007d0bb21d8ed9  lea r14, [rax+0xE0]
00007d0bb21d8ee0  movups xmm15, [r13+r14*1]
00007d0bb21d8ee6  vmovaps xmm9, [rsp+0x70]
00007d0bb21d8eec  vpermilpd xmm9, xmm9, 0x00
00007d0bb21d8ef2  vmovaps [rsp+0x70], xmm1
00007d0bb21d8ef8  vmovaps xmm1, [rsp+0x80]
00007d0bb21d8f01  vmovaps [rsp+0x80], xmm15
00007d0bb21d8f0a  movaps xmm3, xmm1
00007d0bb21d8f0d  mulpd xmm3, xmm9
00007d0bb21d8f12  vcmppd xmm15, xmm3, xmm3, 0x03
00007d0bb21d8f17  ptest xmm15, xmm15
00007d0bb21d8f1d  jnz 0x00007D0BB21DAB5E
00007d0bb21d8f23  vmovaps xmm1, [rsp+0xF0]
00007d0bb21d8f2c  vmovaps xmm15, [rsp+0xF0]
00007d0bb21d8f35  por xmm1, xmm15
00007d0bb21d8f3a  movaps [r15+0x300], xmm1
00007d0bb21d8f42  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d8f4b  vmovaps xmm9, [rsp+0xE0]
00007d0bb21d8f54  por xmm15, xmm9
00007d0bb21d8f59  movaps [r15+0x190], xmm15
00007d0bb21d8f61  vmovaps xmm9, [rsp+0x50]
00007d0bb21d8f67  vpermilpd xmm9, xmm9, 0x00
00007d0bb21d8f6d  vmovaps [rsp+0x90], xmm1
00007d0bb21d8f76  vmovaps [rsp+0xE0], xmm15
00007d0bb21d8f7f  vmovaps xmm15, [rsp+0x80]
00007d0bb21d8f88  vmovaps [rsp+0x80], xmm14
00007d0bb21d8f91  movaps xmm1, xmm15
00007d0bb21d8f95  mulpd xmm1, xmm9
00007d0bb21d8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
00007d0bb21d8f9f  ptest xmm14, xmm14
00007d0bb21d8fa5  jnz 0x00007D0BB21DAC9F
00007d0bb21d8fab  lea r14, [rax+0x90]
00007d0bb21d8fb2  movups xmm15, [r13+r14*1]
00007d0bb21d8fb8  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d8fc1  vmovaps xmm9, [rsp+0xD0]
00007d0bb21d8fca  por xmm14, xmm9
00007d0bb21d8fcf  movaps [r15+0x1C0], xmm14
00007d0bb21d8fd7  vmovaps xmm9, [rsp+0xC0]
00007d0bb21d8fe0  vmovaps [rsp+0xD0], xmm1
00007d0bb21d8fe9  vmovaps xmm1, [rsp+0xC0]
00007d0bb21d8ff2  por xmm9, xmm1
00007d0bb21d8ff7  movaps [r15+0x200], xmm9
00007d0bb21d8fff  vmovaps [rsp+0xC0], xmm2
00007d0bb21d9008  vmovaps xmm1, [rsp+0xC0]
00007d0bb21d9011  por xmm2, xmm1
00007d0bb21d9015  movaps [r15+0x2D0], xmm2
00007d0bb21d901d  vmovaps [rsp+0xC0], xmm8
00007d0bb21d9026  vmovaps xmm1, [rsp+0xC0]
00007d0bb21d902f  por xmm8, xmm1
00007d0bb21d9034  movaps [r15+0x2E0], xmm8
00007d0bb21d903c  vmovaps [rsp+0xC0], xmm15
00007d0bb21d9045  movaps xmm1, xmm5
00007d0bb21d9048  addpd xmm1, xmm7
00007d0bb21d904c  vcmppd xmm15, xmm1, xmm1, 0x03
00007d0bb21d9051  ptest xmm15, xmm15
00007d0bb21d9057  jnz 0x00007D0BB21DADEB
00007d0bb21d905d  vmovaps xmm15, [rsp+0x50]
00007d0bb21d9063  vpermilpd xmm15, xmm15, 0x00
00007d0bb21d9069  vmovaps xmm5, [rsp+0xC0]
00007d0bb21d9072  vmovaps [rsp+0xC0], xmm1
00007d0bb21d907b  movaps xmm7, xmm5
00007d0bb21d907e  mulpd xmm7, xmm15
00007d0bb21d9083  vcmppd xmm1, xmm7, xmm7, 0x03
00007d0bb21d9088  ptest xmm1, xmm1
00007d0bb21d908d  jnz 0x00007D0BB21DAF2B
00007d0bb21d9093  lea r14, [rax+0x80]
00007d0bb21d909a  movups xmm1, [r13+r14*1]
00007d0bb21d90a0  vmovaps xmm5, [rsp+0x70]
00007d0bb21d90a6  vmovaps [rsp+0x70], xmm1
00007d0bb21d90ac  movaps xmm15, xmm5
00007d0bb21d90b0  addpd xmm15, xmm3
00007d0bb21d90b5  vcmppd xmm1, xmm15, xmm15, 0x03
00007d0bb21d90bb  ptest xmm1, xmm1
00007d0bb21d90c0  jnz 0x00007D0BB21DB076
00007d0bb21d90c6  vmovaps xmm5, [rsp+0x80]
00007d0bb21d90cf  movaps xmm1, xmm5
00007d0bb21d90d2  addpd xmm1, xmm4
00007d0bb21d90d6  vcmppd xmm3, xmm1, xmm1, 0x03
00007d0bb21d90db  ptest xmm3, xmm3
00007d0bb21d90e0  jnz 0x00007D0BB21DB1B8
00007d0bb21d90e6  vmovaps [rsp+0x80], xmm10
00007d0bb21d90ef  vmovaps xmm5, [rsp+0x80]
00007d0bb21d90f8  por xmm10, xmm5
00007d0bb21d90fd  movaps [r15+0x2F0], xmm10
00007d0bb21d9105  vmovaps xmm5, [rsp+0x50]
00007d0bb21d910b  vpermilpd xmm5, xmm5, 0x00
00007d0bb21d9111  vmovaps xmm3, [rsp+0x70]
00007d0bb21d9117  vmovaps [rsp+0x50], xmm1
00007d0bb21d911d  movaps xmm4, xmm3
00007d0bb21d9120  mulpd xmm4, xmm5
00007d0bb21d9124  vcmppd xmm1, xmm4, xmm4, 0x03
00007d0bb21d9129  ptest xmm1, xmm1
00007d0bb21d912e  jnz 0x00007D0BB21DB2F8
00007d0bb21d9134  lea r14, [rax+0xD0]
00007d0bb21d913b  movups xmm1, [r13+r14*1]
00007d0bb21d9141  vmovaps xmm3, [rsp+0xD0]
00007d0bb21d914a  vmovaps [rsp+0x70], xmm1
00007d0bb21d9150  movaps xmm5, xmm6
00007d0bb21d9153  addpd xmm5, xmm3
00007d0bb21d9157  vcmppd xmm1, xmm5, xmm5, 0x03
00007d0bb21d915c  ptest xmm1, xmm1
00007d0bb21d9161  jnz 0x00007D0BB21DB442
00007d0bb21d9167  vmovaps xmm1, [rsp+0x60]
00007d0bb21d916d  vpermilpd xmm1, xmm1, 0x00
00007d0bb21d9173  movaps xmm6, xmm9
00007d0bb21d9177  mulpd xmm6, xmm1
00007d0bb21d917b  vcmppd xmm3, xmm6, xmm6, 0x03
00007d0bb21d9180  ptest xmm3, xmm3
00007d0bb21d9185  jnz 0x00007D0BB21DB582
00007d0bb21d918b  movaps [r15+0x260], xmm6
00007d0bb21d9193  vxorps xmm1, xmm1, xmm1
00007d0bb21d9197  vpbroadcastq xmm1, xmm1
00007d0bb21d919c  movaps [r15+0x1B0], xmm1
00007d0bb21d91a4  vmovaps xmm1, [rsp+0x60]
00007d0bb21d91aa  vpermilpd xmm1, xmm1, 0x00
00007d0bb21d91b0  vmovaps xmm3, [rsp+0x70]
00007d0bb21d91b6  vmovaps [rsp+0x70], xmm15
00007d0bb21d91bc  movaps xmm9, xmm3
00007d0bb21d91c0  mulpd xmm9, xmm1
00007d0bb21d91c5  vcmppd xmm15, xmm9, xmm9, 0x03
00007d0bb21d91cb  ptest xmm15, xmm15
00007d0bb21d91d1  jnz 0x00007D0BB21DB6C3
00007d0bb21d91d7  lea r14, [rax+0xC0]
00007d0bb21d91de  movups xmm1, [r13+r14*1]
00007d0bb21d91e4  vmovaps xmm3, [rsp+0xC0]
00007d0bb21d91ed  vmovaps [rsp+0x80], xmm1
00007d0bb21d91f6  movaps xmm15, xmm3
00007d0bb21d91fa  addpd xmm15, xmm7
00007d0bb21d91ff  vcmppd xmm1, xmm15, xmm15, 0x03
00007d0bb21d9205  ptest xmm1, xmm1
00007d0bb21d920a  jnz 0x00007D0BB21DB80F
00007d0bb21d9210  vmovaps [rsp+0xC0], xmm13
00007d0bb21d9219  vmovaps xmm1, [rsp+0xC0]
00007d0bb21d9222  por xmm13, xmm1
00007d0bb21d9227  movaps [r15+0x270], xmm13
00007d0bb21d922f  vmovaps xmm1, [rsp+0xB0]
00007d0bb21d9238  vmovaps xmm7, [rsp+0xB0]
00007d0bb21d9241  por xmm1, xmm7
00007d0bb21d9245  movaps [r15+0x1A0], xmm1
00007d0bb21d924d  vmovaps xmm1, [rsp+0x60]
00007d0bb21d9253  vpermilpd xmm1, xmm1, 0x00
00007d0bb21d9259  vmovaps [rsp+0xB0], xmm1
00007d0bb21d9262  vmovaps xmm1, [rsp+0x80]
00007d0bb21d926b  vmovaps [rsp+0x80], xmm15
00007d0bb21d9274  vmovaps xmm15, [rsp+0xB0]
00007d0bb21d927d  vmovaps [rsp+0xB0], xmm14
00007d0bb21d9286  movaps xmm3, xmm1
00007d0bb21d9289  mulpd xmm3, xmm15
00007d0bb21d928e  vcmppd xmm14, xmm3, xmm3, 0x03
00007d0bb21d9293  ptest xmm14, xmm14
00007d0bb21d9299  jnz 0x00007D0BB21DB951
00007d0bb21d929f  lea r14, [rax+0x20]
00007d0bb21d92a3  movups xmm1, [r13+r14*1]
00007d0bb21d92a9  movaps [r15+0x110], xmm1
00007d0bb21d92b1  vmovaps xmm14, [rsp+0x70]
00007d0bb21d92b7  vmovaps [rsp+0x70], xmm1
00007d0bb21d92bd  movaps xmm15, xmm14
00007d0bb21d92c1  addpd xmm15, xmm4
00007d0bb21d92c6  vcmppd xmm1, xmm15, xmm15, 0x03
00007d0bb21d92cc  ptest xmm1, xmm1
00007d0bb21d92d1  jnz 0x00007D0BB21DBA9C
00007d0bb21d92d7  vmovaps xmm1, [rsp+0x60]
00007d0bb21d92dd  vpermilpd xmm1, xmm1, 0x00
00007d0bb21d92e3  movaps xmm14, xmm2
00007d0bb21d92e7  mulpd xmm14, xmm1
00007d0bb21d92ec  vcmppd xmm4, xmm14, xmm14, 0x03
00007d0bb21d92f2  ptest xmm4, xmm4
00007d0bb21d92f7  jnz 0x00007D0BB21DBBDF
00007d0bb21d92fd  vmovaps xmm4, [rsp+0x50]
00007d0bb21d9303  movaps xmm1, xmm4
00007d0bb21d9306  addpd xmm1, xmm9
00007d0bb21d930b  vcmppd xmm2, xmm1, xmm1, 0x03
00007d0bb21d9310  ptest xmm2, xmm2
00007d0bb21d9315  jnz 0x00007D0BB21DBD21
00007d0bb21d931b  vmovaps xmm9, [rsp+0x30]
00007d0bb21d9321  vpermilpd xmm9, xmm9, 0x00
00007d0bb21d9327  vmovaps xmm2, [rsp+0x70]
00007d0bb21d932d  vmovaps [rsp+0x50], xmm1
00007d0bb21d9333  movaps xmm4, xmm2
00007d0bb21d9336  mulpd xmm4, xmm9
00007d0bb21d933b  vcmppd xmm1, xmm4, xmm4, 0x03
00007d0bb21d9340  ptest xmm1, xmm1
00007d0bb21d9345  jnz 0x00007D0BB21DBE62
00007d0bb21d934b  vmovaps xmm1, [rsp+0x30]
00007d0bb21d9351  vpermilpd xmm1, xmm1, 0x00
00007d0bb21d9357  vmovaps xmm2, [rsp+0x90]
00007d0bb21d9360  vmovaps [rsp+0x60], xmm15
00007d0bb21d9366  movaps xmm9, xmm2
00007d0bb21d936a  mulpd xmm9, xmm1
00007d0bb21d936f  vcmppd xmm15, xmm9, xmm9, 0x03
00007d0bb21d9375  ptest xmm15, xmm15
00007d0bb21d937b  jnz 0x00007D0BB21DBFA3
00007d0bb21d9381  vmovaps xmm15, [rsp+0x80]
00007d0bb21d938a  movaps xmm1, xmm15
00007d0bb21d938e  addpd xmm1, xmm6
00007d0bb21d9392  vcmppd xmm2, xmm1, xmm1, 0x03
00007d0bb21d9397  ptest xmm2, xmm2
00007d0bb21d939c  jnz 0x00007D0BB21DC0E5
00007d0bb21d93a2  movaps xmm15, xmm5
00007d0bb21d93a6  addpd xmm15, xmm3
00007d0bb21d93ab  vcmppd xmm6, xmm15, xmm15, 0x03
00007d0bb21d93b1  ptest xmm6, xmm6
00007d0bb21d93b6  jnz 0x00007D0BB21DC226
00007d0bb21d93bc  vmovaps xmm6, [rsp+0x30]
00007d0bb21d93c2  vpermilpd xmm6, xmm6, 0x00
00007d0bb21d93c8  movaps xmm5, xmm8
00007d0bb21d93cc  mulpd xmm5, xmm6
00007d0bb21d93d0  vcmppd xmm3, xmm5, xmm5, 0x03
00007d0bb21d93d5  ptest xmm3, xmm3
00007d0bb21d93da  jnz 0x00007D0BB21DC368
00007d0bb21d93e0  vmovaps xmm8, [rsp+0x30]
00007d0bb21d93e6  vpermilpd xmm8, xmm8, 0x00
00007d0bb21d93ec  movaps xmm6, xmm10
00007d0bb21d93f0  mulpd xmm6, xmm8
00007d0bb21d93f5  vcmppd xmm3, xmm6, xmm6, 0x03
00007d0bb21d93fa  ptest xmm3, xmm3
00007d0bb21d93ff  jnz 0x00007D0BB21DC4A9
00007d0bb21d9405  vmovaps xmm8, [rsp+0x60]
00007d0bb21d940b  movaps xmm10, xmm8
00007d0bb21d940f  addpd xmm10, xmm14
00007d0bb21d9414  vcmppd xmm3, xmm10, xmm10, 0x03
00007d0bb21d941a  ptest xmm3, xmm3
00007d0bb21d941f  jnz 0x00007D0BB21DC5EB
00007d0bb21d9425  vmovaps xmm8, [rsp+0x50]
00007d0bb21d942b  movaps xmm14, xmm8
00007d0bb21d942f  addpd xmm14, xmm4
00007d0bb21d9434  vcmppd xmm3, xmm14, xmm14, 0x03
00007d0bb21d943a  ptest xmm3, xmm3
00007d0bb21d943f  jnz 0x00007D0BB21DC72F
00007d0bb21d9445  vmovaps xmm8, [rsp+0x40]
00007d0bb21d944b  vpermilpd xmm8, xmm8, 0x00
00007d0bb21d9451  movaps xmm4, xmm13
00007d0bb21d9455  mulpd xmm4, xmm8
00007d0bb21d945a  vcmppd xmm3, xmm4, xmm4, 0x03
00007d0bb21d945f  ptest xmm3, xmm3
00007d0bb21d9464  jnz 0x00007D0BB21DC872
00007d0bb21d946a  movaps xmm13, xmm15
00007d0bb21d946e  addpd xmm13, xmm9
00007d0bb21d9473  vcmppd xmm8, xmm13, xmm13, 0x03
00007d0bb21d9479  ptest xmm8, xmm8
00007d0bb21d947f  jnz 0x00007D0BB21DC9B4
00007d0bb21d9485  movaps xmm15, xmm1
00007d0bb21d9489  addpd xmm15, xmm5
00007d0bb21d948e  vcmppd xmm9, xmm15, xmm15, 0x03
00007d0bb21d9494  ptest xmm9, xmm9
00007d0bb21d949a  jnz 0x00007D0BB21DCAF8
00007d0bb21d94a0  vmovaps [rsp+0x30], xmm11
00007d0bb21d94a6  vmovaps xmm1, [rsp+0x30]
00007d0bb21d94ac  por xmm11, xmm1
00007d0bb21d94b1  movaps [r15+0x250], xmm11
00007d0bb21d94b9  vmovaps [rsp+0x30], xmm12
00007d0bb21d94bf  vmovaps xmm1, [rsp+0x30]
00007d0bb21d94c5  por xmm12, xmm1
00007d0bb21d94ca  movaps [r15+0x2A0], xmm12
00007d0bb21d94d2  vmovaps xmm1, [rsp+0xA0]
00007d0bb21d94db  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d94e4  por xmm1, xmm11
00007d0bb21d94e9  movaps [r15+0x1D0], xmm1
00007d0bb21d94f1  lea r14, [rax+0x40]
00007d0bb21d94f5  movups xmm1, [r13+r14*1]
00007d0bb21d94fb  movaps [r15+0x2C0], xmm1
00007d0bb21d9503  vmovaps xmm11, [rsp+0x40]
00007d0bb21d9509  vpermilpd xmm11, xmm11, 0x00
00007d0bb21d950f  vmovaps xmm8, [rsp+0xE0]
00007d0bb21d9518  movaps xmm9, xmm8
00007d0bb21d951c  mulpd xmm9, xmm11
00007d0bb21d9521  vcmppd xmm5, xmm9, xmm9, 0x03
00007d0bb21d9527  ptest xmm5, xmm5
00007d0bb21d952c  jnz 0x00007D0BB21DCC44
00007d0bb21d9532  movaps xmm11, xmm10
00007d0bb21d9536  addpd xmm11, xmm6
00007d0bb21d953b  vcmppd xmm8, xmm11, xmm11, 0x03
00007d0bb21d9541  ptest xmm8, xmm8
00007d0bb21d9547  jnz 0x00007D0BB21DCD88
00007d0bb21d954d  movaps xmm10, xmm14
00007d0bb21d9551  addpd xmm10, xmm4
00007d0bb21d9556  vcmppd xmm8, xmm10, xmm10, 0x03
00007d0bb21d955c  ptest xmm8, xmm8
00007d0bb21d9562  jnz 0x00007D0BB21DCECB
00007d0bb21d9568  vmovaps xmm14, [rsp+0x40]
00007d0bb21d956e  vpermilpd xmm14, xmm14, 0x00
00007d0bb21d9574  movaps xmm8, xmm1
00007d0bb21d9578  mulpd xmm8, xmm14
00007d0bb21d957d  vcmppd xmm6, xmm8, xmm8, 0x03
00007d0bb21d9583  ptest xmm6, xmm6
00007d0bb21d9588  jnz 0x00007D0BB21DD00E
00007d0bb21d958e  movaps xmm1, [r15+0x2B0]
00007d0bb21d9596  vmovaps xmm14, [rsp+0x40]
00007d0bb21d959c  vpermilpd xmm14, xmm14, 0x00
00007d0bb21d95a2  movaps xmm6, xmm1
00007d0bb21d95a5  mulpd xmm6, xmm14
00007d0bb21d95aa  vcmppd xmm5, xmm6, xmm6, 0x03
00007d0bb21d95af  ptest xmm5, xmm5
00007d0bb21d95b4  jnz 0x00007D0BB21DD151
00007d0bb21d95ba  vmovaps xmm1, [rsp+0x10]
00007d0bb21d95c0  vpermilpd xmm1, xmm1, 0x00
00007d0bb21d95c6  movaps xmm14, xmm12
00007d0bb21d95ca  mulpd xmm14, xmm1
00007d0bb21d95cf  vcmppd xmm5, xmm14, xmm14, 0x03
00007d0bb21d95d5  ptest xmm5, xmm5
00007d0bb21d95da  jnz 0x00007D0BB21DD292
00007d0bb21d95e0  movaps xmm1, xmm13
00007d0bb21d95e4  addpd xmm1, xmm9
00007d0bb21d95e9  vcmppd xmm12, xmm1, xmm1, 0x03
00007d0bb21d95ee  ptest xmm12, xmm12
00007d0bb21d95f4  jnz 0x00007D0BB21DD3D5
00007d0bb21d95fa  vmovaps xmm13, [rsp+0x10]
00007d0bb21d9600  vpermilpd xmm13, xmm13, 0x00
00007d0bb21d9606  movaps xmm12, xmm7
00007d0bb21d960a  mulpd xmm12, xmm13
00007d0bb21d960f  vcmppd xmm9, xmm12, xmm12, 0x03
00007d0bb21d9615  ptest xmm9, xmm9
00007d0bb21d961b  jnz 0x00007D0BB21DD517
00007d0bb21d9621  movaps xmm13, xmm15
00007d0bb21d9625  addpd xmm13, xmm8
00007d0bb21d962a  vcmppd xmm9, xmm13, xmm13, 0x03
00007d0bb21d9630  ptest xmm9, xmm9
00007d0bb21d9636  jnz 0x00007D0BB21DD65A
00007d0bb21d963c  movaps xmm15, [r15+0x290]
00007d0bb21d9644  vmovaps xmm9, [rsp+0x10]
00007d0bb21d964a  vpermilpd xmm9, xmm9, 0x00
00007d0bb21d9650  movaps xmm8, xmm15
00007d0bb21d9654  mulpd xmm8, xmm9
00007d0bb21d9659  vcmppd xmm7, xmm8, xmm8, 0x03
00007d0bb21d965f  ptest xmm7, xmm7
00007d0bb21d9664  jnz 0x00007D0BB21DD79E
00007d0bb21d966a  movaps xmm15, xmm11
00007d0bb21d966e  addpd xmm15, xmm6
00007d0bb21d9673  vcmppd xmm9, xmm15, xmm15, 0x03
00007d0bb21d9679  ptest xmm9, xmm9
00007d0bb21d967f  jnz 0x00007D0BB21DD8E2
00007d0bb21d9685  movaps xmm11, [r15+0x1E0]
00007d0bb21d968d  vmovaps xmm9, [rsp+0x10]
00007d0bb21d9693  vpermilpd xmm9, xmm9, 0x00
00007d0bb21d9699  movaps xmm7, xmm11
00007d0bb21d969d  mulpd xmm7, xmm9
00007d0bb21d96a2  vcmppd xmm6, xmm7, xmm7, 0x03
00007d0bb21d96a7  ptest xmm6, xmm6
00007d0bb21d96ac  jnz 0x00007D0BB21DDA25
00007d0bb21d96b2  movaps xmm11, xmm10
00007d0bb21d96b6  addpd xmm11, xmm14
00007d0bb21d96bb  vcmppd xmm9, xmm11, xmm11, 0x03
00007d0bb21d96c1  ptest xmm9, xmm9
00007d0bb21d96c7  jnz 0x00007D0BB21DDB67
00007d0bb21d96cd  lea r14, [rax+0x70]
00007d0bb21d96d1  movups xmm14, [r13+r14*1]
00007d0bb21d96d7  movaps [r15+0x240], xmm14
00007d0bb21d96df  movaps xmm10, xmm1
00007d0bb21d96e3  addpd xmm10, xmm12
00007d0bb21d96e8  vcmppd xmm9, xmm10, xmm10, 0x03
00007d0bb21d96ee  ptest xmm9, xmm9
00007d0bb21d96f4  jnz 0x00007D0BB21DDCB5
00007d0bb21d96fa  movaps [r15+0x170], xmm10
00007d0bb21d9702  vmovaps xmm1, [rsp+0x20]
00007d0bb21d9708  vpermilpd xmm1, xmm1, 0x00
00007d0bb21d970e  movaps xmm12, xmm14
00007d0bb21d9712  mulpd xmm12, xmm1
00007d0bb21d9717  vcmppd xmm9, xmm12, xmm12, 0x03
00007d0bb21d971d  ptest xmm9, xmm9
00007d0bb21d9723  jnz 0x00007D0BB21DDDF8
00007d0bb21d9729  vmovaps xmm1, [rsp+0x20]
00007d0bb21d972f  vpermilpd xmm1, xmm1, 0x00
00007d0bb21d9735  vmovaps xmm9, [rsp+0xB0]
00007d0bb21d973e  movaps xmm14, xmm9
00007d0bb21d9742  mulpd xmm14, xmm1
00007d0bb21d9747  vcmppd xmm6, xmm14, xmm14, 0x03
00007d0bb21d974d  ptest xmm6, xmm6
00007d0bb21d9752  jnz 0x00007D0BB21DDF3B
00007d0bb21d9758  movaps [r15+0x180], xmm14
00007d0bb21d9760  movaps xmm1, xmm13
00007d0bb21d9764  addpd xmm1, xmm8
00007d0bb21d9769  vcmppd xmm9, xmm1, xmm1, 0x03
00007d0bb21d976e  ptest xmm9, xmm9
00007d0bb21d9774  jnz 0x00007D0BB21DE07E
00007d0bb21d977a  movaps [r15+0x210], xmm1
00007d0bb21d9782  movups xmm13, [r13+rax*1]
00007d0bb21d9788  lea r14, [rax+0x10]
00007d0bb21d978c  movups xmm9, [r13+r14*1]
00007d0bb21d9792  movaps [r15+0x230], xmm9
00007d0bb21d979a  movaps xmm8, xmm15
00007d0bb21d979e  addpd xmm8, xmm7
00007d0bb21d97a3  vcmppd xmm6, xmm8, xmm8, 0x03
00007d0bb21d97a9  ptest xmm6, xmm6
00007d0bb21d97ae  jnz 0x00007D0BB21DE1D4
00007d0bb21d97b4  movaps [r15+0x130], xmm8
00007d0bb21d97bc  vmovaps xmm15, [rsp+0x20]
00007d0bb21d97c2  vpermilpd xmm15, xmm15, 0x00
00007d0bb21d97c8  movaps xmm7, xmm9
00007d0bb21d97cc  mulpd xmm7, xmm15
00007d0bb21d97d1  vcmppd xmm6, xmm7, xmm7, 0x03
00007d0bb21d97d6  ptest xmm6, xmm6
00007d0bb21d97db  jnz 0x00007D0BB21DE317
00007d0bb21d97e1  movaps [r15+0x220], xmm7
00007d0bb21d97e9  vmovaps xmm15, [rsp+0x20]
00007d0bb21d97ef  vpermilpd xmm15, xmm15, 0x00
00007d0bb21d97f5  movaps xmm9, xmm13
00007d0bb21d97f9  mulpd xmm9, xmm15
00007d0bb21d97fe  vcmppd xmm6, xmm9, xmm9, 0x03
00007d0bb21d9804  ptest xmm6, xmm6
00007d0bb21d9809  jnz 0x00007D0BB21DE459
00007d0bb21d980f  movaps xmm15, xmm11
00007d0bb21d9813  addpd xmm15, xmm12
00007d0bb21d9818  vcmppd xmm13, xmm15, xmm15, 0x03
00007d0bb21d981e  ptest xmm13, xmm13
00007d0bb21d9824  jnz 0x00007D0BB21DE59D
00007d0bb21d982a  movaps [r15+0x140], xmm15
00007d0bb21d9832  movaps xmm13, xmm10
00007d0bb21d9836  addpd xmm13, xmm14
00007d0bb21d983b  vcmppd xmm12, xmm13, xmm13, 0x03
00007d0bb21d9841  ptest xmm12, xmm12
00007d0bb21d9847  jnz 0x00007D0BB21DE6E1
00007d0bb21d984d  movaps [r15+0x150], xmm13
00007d0bb21d9855  movaps xmm14, xmm1
00007d0bb21d9859  addpd xmm14, xmm7
00007d0bb21d985e  vcmppd xmm12, xmm14, xmm14, 0x03
00007d0bb21d9864  ptest xmm12, xmm12
00007d0bb21d986a  jnz 0x00007D0BB21DE825
00007d0bb21d9870  movaps [r15+0x160], xmm14
00007d0bb21d9878  movaps xmm1, xmm8
00007d0bb21d987c  addpd xmm1, xmm9
00007d0bb21d9881  vcmppd xmm12, xmm1, xmm1, 0x03
00007d0bb21d9886  ptest xmm12, xmm12
00007d0bb21d988c  jnz 0x00007D0BB21DE967
00007d0bb21d9892  movaps [r15+0x120], xmm1
00007d0bb21d989a  movups [r13+r11*1], xmm15
00007d0bb21d98a0  lea rax, [r11+0x10]
00007d0bb21d98a4  movups [r13+rax*1], xmm13
00007d0bb21d98aa  lea rax, [r11+0x20]
00007d0bb21d98ae  movups [r13+rax*1], xmm14
00007d0bb21d98b4  lea rax, [r11+0x30]
00007d0bb21d98b8  movups [r13+rax*1], xmm1
00007d0bb21d98be  mov eax, [r15+0x108]
00007d0bb21d98c5  sahf
00007d0bb21d98c6  jnz 0x00007D0BB21D98F8
00007d0bb21d98c8  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d98d0  jz 0x00007D0BB21DEAE0
00007d0bb21d98d6  nop [rax+rax*1], ax
00007d0bb21d98df  nop [rax+rax*1], eax
00007d0bb21d98e7  mov eax, 0x4106D0
00007d0bb21d98ec  mov [r15+0x100], rax
00007d0bb21d98f3  jmp 0x00007D0BB1FFE110
00007d0bb21d98f8  cmp dword ptr [r15+0x318], 0x00
00007d0bb21d9900  jz 0x00007D0BB21D89C0
00007d0bb21d9906  nop [rax+rax*1], ax
00007d0bb21d990f  nop [rax+rax*1], eax
00007d0bb21d9917  mov eax, 0x410504
00007d0bb21d991c  mov [r15+0x100], rax
00007d0bb21d9923  jmp 0x00007D0BB1FFE110
00007d0bb21d9928  int3
00007d0bb21d9929  call 0x00007D0BB200A4B0
00007d0bb21d992e  jmp 0x00007D0BB21D8A08
00007d0bb21d9933  call 0x00007D0BB2009240
00007d0bb21d9938  jmp 0x00007D0BB21D8A12
00007d0bb21d993d  call 0x00007D0BB200A4B0
00007d0bb21d9942  jmp 0x00007D0BB21D8A6F
00007d0bb21d9947  call 0x00007D0BB2009240
00007d0bb21d994c  jmp 0x00007D0BB21D8A79
00007d0bb21d9951  call 0x00007D0BB200A4B0
00007d0bb21d9956  jmp 0x00007D0BB21D8ABD
00007d0bb21d995b  call 0x00007D0BB2009240
00007d0bb21d9960  jmp 0x00007D0BB21D8AC7
00007d0bb21d9965  call 0x00007D0BB20B47C0
00007d0bb21d996a  jmp 0x00007D0BB21D8B06
00007d0bb21d996f  call 0x00007D0BB200B720
00007d0bb21d9974  jmp 0x00007D0BB21D8B1A
00007d0bb21d9979  call 0x00007D0BB20BFC30
00007d0bb21d997e  jmp 0x00007D0BB21D8B38
00007d0bb21d9983  call 0x00007D0BB20BE9C0
00007d0bb21d9988  jmp 0x00007D0BB21D8B42
00007d0bb21d998d  call 0x00007D0BB20BD750
00007d0bb21d9992  jmp 0x00007D0BB21D8B4C
00007d0bb21d9997  sub rsp, 0x08
00007d0bb21d999b  push rax
00007d0bb21d999c  push rcx
00007d0bb21d999d  push rdx
00007d0bb21d999e  push rdi
00007d0bb21d999f  push rsi
00007d0bb21d99a0  push r8
00007d0bb21d99a2  push r9
00007d0bb21d99a4  push r10
00007d0bb21d99a6  push r11
00007d0bb21d99a8  sub rsp, 0xF0
00007d0bb21d99af  vmovaps [rsp], xmm0
00007d0bb21d99b4  vmovaps [rsp+0x10], xmm1
00007d0bb21d99ba  vmovaps [rsp+0x20], xmm2
00007d0bb21d99c0  vmovaps [rsp+0x30], xmm3
00007d0bb21d99c6  vmovaps [rsp+0x40], xmm4
00007d0bb21d99cc  vmovaps [rsp+0x50], xmm5
00007d0bb21d99d2  vmovaps [rsp+0x60], xmm6
00007d0bb21d99d8  vmovaps [rsp+0x70], xmm7
00007d0bb21d99de  vmovaps [rsp+0x80], xmm9
00007d0bb21d99e7  vmovaps [rsp+0x90], xmm10
00007d0bb21d99f0  vmovaps [rsp+0xA0], xmm11
00007d0bb21d99f9  vmovaps [rsp+0xB0], xmm12
00007d0bb21d9a02  vmovaps [rsp+0xC0], xmm13
00007d0bb21d9a0b  vmovaps [rsp+0xD0], xmm14
00007d0bb21d9a14  vmovaps [rsp+0xE0], xmm15
00007d0bb21d9a1d  sub rsp, 0x30
00007d0bb21d9a21  movaps [rsp], xmm8
00007d0bb21d9a26  movaps [rsp+0x10], xmm12
00007d0bb21d9a2c  movaps [rsp+0x20], xmm15
00007d0bb21d9a32  lea rdi, [rsp]
00007d0bb21d9a36  mov esi, 0x00
00007d0bb21d9a3b  mov rax, 0x6392BBE7F530
00007d0bb21d9a45  call rax
00007d0bb21d9a47  movaps xmm8, [rsp]
00007d0bb21d9a4c  add rsp, 0x30
00007d0bb21d9a50  vmovaps xmm0, [rsp]
00007d0bb21d9a55  vmovaps xmm1, [rsp+0x10]
00007d0bb21d9a5b  vmovaps xmm2, [rsp+0x20]
00007d0bb21d9a61  vmovaps xmm3, [rsp+0x30]
00007d0bb21d9a67  vmovaps xmm4, [rsp+0x40]
00007d0bb21d9a6d  vmovaps xmm5, [rsp+0x50]
00007d0bb21d9a73  vmovaps xmm6, [rsp+0x60]
00007d0bb21d9a79  vmovaps xmm7, [rsp+0x70]
00007d0bb21d9a7f  vmovaps xmm9, [rsp+0x80]
00007d0bb21d9a88  vmovaps xmm10, [rsp+0x90]
00007d0bb21d9a91  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d9a9a  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d9aa3  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d9aac  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d9ab5  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d9abe  add rsp, 0xF0
00007d0bb21d9ac5  pop r11
00007d0bb21d9ac7  pop r10
00007d0bb21d9ac9  pop r9
00007d0bb21d9acb  pop r8
00007d0bb21d9acd  pop rsi
00007d0bb21d9ace  pop rdi
00007d0bb21d9acf  pop rdx
00007d0bb21d9ad0  pop rcx
00007d0bb21d9ad1  pop rax
00007d0bb21d9ad2  add rsp, 0x08
00007d0bb21d9ad6  jmp 0x00007D0BB21D8B7A
00007d0bb21d9adb  sub rsp, 0x08
00007d0bb21d9adf  push rax
00007d0bb21d9ae0  push rcx
00007d0bb21d9ae1  push rdx
00007d0bb21d9ae2  push rdi
00007d0bb21d9ae3  push rsi
00007d0bb21d9ae4  push r8
00007d0bb21d9ae6  push r9
00007d0bb21d9ae8  push r10
00007d0bb21d9aea  push r11
00007d0bb21d9aec  sub rsp, 0xF0
00007d0bb21d9af3  vmovaps [rsp], xmm0
00007d0bb21d9af8  vmovaps [rsp+0x10], xmm1
00007d0bb21d9afe  vmovaps [rsp+0x20], xmm2
00007d0bb21d9b04  vmovaps [rsp+0x30], xmm3
00007d0bb21d9b0a  vmovaps [rsp+0x40], xmm4
00007d0bb21d9b10  vmovaps [rsp+0x50], xmm5
00007d0bb21d9b16  vmovaps [rsp+0x60], xmm6
00007d0bb21d9b1c  vmovaps [rsp+0x70], xmm8
00007d0bb21d9b22  vmovaps [rsp+0x80], xmm9
00007d0bb21d9b2b  vmovaps [rsp+0x90], xmm10
00007d0bb21d9b34  vmovaps [rsp+0xA0], xmm11
00007d0bb21d9b3d  vmovaps [rsp+0xB0], xmm12
00007d0bb21d9b46  vmovaps [rsp+0xC0], xmm13
00007d0bb21d9b4f  vmovaps [rsp+0xD0], xmm14
00007d0bb21d9b58  vmovaps [rsp+0xE0], xmm15
00007d0bb21d9b61  sub rsp, 0x30
00007d0bb21d9b65  movaps [rsp], xmm7
00007d0bb21d9b69  movaps [rsp+0x10], xmm9
00007d0bb21d9b6f  movaps [rsp+0x20], xmm15
00007d0bb21d9b75  lea rdi, [rsp]
00007d0bb21d9b79  mov esi, 0x00
00007d0bb21d9b7e  mov rax, 0x6392BBE7F530
00007d0bb21d9b88  call rax
00007d0bb21d9b8a  movaps xmm7, [rsp]
00007d0bb21d9b8e  add rsp, 0x30
00007d0bb21d9b92  vmovaps xmm0, [rsp]
00007d0bb21d9b97  vmovaps xmm1, [rsp+0x10]
00007d0bb21d9b9d  vmovaps xmm2, [rsp+0x20]
00007d0bb21d9ba3  vmovaps xmm3, [rsp+0x30]
00007d0bb21d9ba9  vmovaps xmm4, [rsp+0x40]
00007d0bb21d9baf  vmovaps xmm5, [rsp+0x50]
00007d0bb21d9bb5  vmovaps xmm6, [rsp+0x60]
00007d0bb21d9bbb  vmovaps xmm8, [rsp+0x70]
00007d0bb21d9bc1  vmovaps xmm9, [rsp+0x80]
00007d0bb21d9bca  vmovaps xmm10, [rsp+0x90]
00007d0bb21d9bd3  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d9bdc  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d9be5  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d9bee  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d9bf7  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d9c00  add rsp, 0xF0
00007d0bb21d9c07  pop r11
00007d0bb21d9c09  pop r10
00007d0bb21d9c0b  pop r9
00007d0bb21d9c0d  pop r8
00007d0bb21d9c0f  pop rsi
00007d0bb21d9c10  pop rdi
00007d0bb21d9c11  pop rdx
00007d0bb21d9c12  pop rcx
00007d0bb21d9c13  pop rax
00007d0bb21d9c14  add rsp, 0x08
00007d0bb21d9c18  jmp 0x00007D0BB21D8BA8
00007d0bb21d9c1d  sub rsp, 0x08
00007d0bb21d9c21  push rax
00007d0bb21d9c22  push rcx
00007d0bb21d9c23  push rdx
00007d0bb21d9c24  push rdi
00007d0bb21d9c25  push rsi
00007d0bb21d9c26  push r8
00007d0bb21d9c28  push r9
00007d0bb21d9c2a  push r10
00007d0bb21d9c2c  push r11
00007d0bb21d9c2e  sub rsp, 0xF0
00007d0bb21d9c35  vmovaps [rsp], xmm0
00007d0bb21d9c3a  vmovaps [rsp+0x10], xmm1
00007d0bb21d9c40  vmovaps [rsp+0x20], xmm2
00007d0bb21d9c46  vmovaps [rsp+0x30], xmm3
00007d0bb21d9c4c  vmovaps [rsp+0x40], xmm4
00007d0bb21d9c52  vmovaps [rsp+0x50], xmm5
00007d0bb21d9c58  vmovaps [rsp+0x60], xmm6
00007d0bb21d9c5e  vmovaps [rsp+0x70], xmm7
00007d0bb21d9c64  vmovaps [rsp+0x80], xmm8
00007d0bb21d9c6d  vmovaps [rsp+0x90], xmm10
00007d0bb21d9c76  vmovaps [rsp+0xA0], xmm11
00007d0bb21d9c7f  vmovaps [rsp+0xB0], xmm12
00007d0bb21d9c88  vmovaps [rsp+0xC0], xmm13
00007d0bb21d9c91  vmovaps [rsp+0xD0], xmm14
00007d0bb21d9c9a  vmovaps [rsp+0xE0], xmm15
00007d0bb21d9ca3  sub rsp, 0x30
00007d0bb21d9ca7  movaps [rsp], xmm9
00007d0bb21d9cac  movaps [rsp+0x10], xmm12
00007d0bb21d9cb2  movaps [rsp+0x20], xmm10
00007d0bb21d9cb8  lea rdi, [rsp]
00007d0bb21d9cbc  mov esi, 0x00
00007d0bb21d9cc1  mov rax, 0x6392BBE7F530
00007d0bb21d9ccb  call rax
00007d0bb21d9ccd  movaps xmm9, [rsp]
00007d0bb21d9cd2  add rsp, 0x30
00007d0bb21d9cd6  vmovaps xmm0, [rsp]
00007d0bb21d9cdb  vmovaps xmm1, [rsp+0x10]
00007d0bb21d9ce1  vmovaps xmm2, [rsp+0x20]
00007d0bb21d9ce7  vmovaps xmm3, [rsp+0x30]
00007d0bb21d9ced  vmovaps xmm4, [rsp+0x40]
00007d0bb21d9cf3  vmovaps xmm5, [rsp+0x50]
00007d0bb21d9cf9  vmovaps xmm6, [rsp+0x60]
00007d0bb21d9cff  vmovaps xmm7, [rsp+0x70]
00007d0bb21d9d05  vmovaps xmm8, [rsp+0x80]
00007d0bb21d9d0e  vmovaps xmm10, [rsp+0x90]
00007d0bb21d9d17  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d9d20  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d9d29  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d9d32  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d9d3b  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d9d44  add rsp, 0xF0
00007d0bb21d9d4b  pop r11
00007d0bb21d9d4d  pop r10
00007d0bb21d9d4f  pop r9
00007d0bb21d9d51  pop r8
00007d0bb21d9d53  pop rsi
00007d0bb21d9d54  pop rdi
00007d0bb21d9d55  pop rdx
00007d0bb21d9d56  pop rcx
00007d0bb21d9d57  pop rax
00007d0bb21d9d58  add rsp, 0x08
00007d0bb21d9d5c  jmp 0x00007D0BB21D8BCC
00007d0bb21d9d61  sub rsp, 0x08
00007d0bb21d9d65  push rax
00007d0bb21d9d66  push rcx
00007d0bb21d9d67  push rdx
00007d0bb21d9d68  push rdi
00007d0bb21d9d69  push rsi
00007d0bb21d9d6a  push r8
00007d0bb21d9d6c  push r9
00007d0bb21d9d6e  push r10
00007d0bb21d9d70  push r11
00007d0bb21d9d72  sub rsp, 0xF0
00007d0bb21d9d79  vmovaps [rsp], xmm0
00007d0bb21d9d7e  vmovaps [rsp+0x10], xmm1
00007d0bb21d9d84  vmovaps [rsp+0x20], xmm2
00007d0bb21d9d8a  vmovaps [rsp+0x30], xmm3
00007d0bb21d9d90  vmovaps [rsp+0x40], xmm4
00007d0bb21d9d96  vmovaps [rsp+0x50], xmm5
00007d0bb21d9d9c  vmovaps [rsp+0x60], xmm6
00007d0bb21d9da2  vmovaps [rsp+0x70], xmm7
00007d0bb21d9da8  vmovaps [rsp+0x80], xmm8
00007d0bb21d9db1  vmovaps [rsp+0x90], xmm9
00007d0bb21d9dba  vmovaps [rsp+0xA0], xmm11
00007d0bb21d9dc3  vmovaps [rsp+0xB0], xmm12
00007d0bb21d9dcc  vmovaps [rsp+0xC0], xmm13
00007d0bb21d9dd5  vmovaps [rsp+0xD0], xmm14
00007d0bb21d9dde  vmovaps [rsp+0xE0], xmm15
00007d0bb21d9de7  sub rsp, 0x30
00007d0bb21d9deb  movaps [rsp], xmm10
00007d0bb21d9df0  movaps [rsp+0x10], xmm12
00007d0bb21d9df6  movaps [rsp+0x20], xmm11
00007d0bb21d9dfc  lea rdi, [rsp]
00007d0bb21d9e00  mov esi, 0x00
00007d0bb21d9e05  mov rax, 0x6392BBE7F530
00007d0bb21d9e0f  call rax
00007d0bb21d9e11  movaps xmm10, [rsp]
00007d0bb21d9e16  add rsp, 0x30
00007d0bb21d9e1a  vmovaps xmm0, [rsp]
00007d0bb21d9e1f  vmovaps xmm1, [rsp+0x10]
00007d0bb21d9e25  vmovaps xmm2, [rsp+0x20]
00007d0bb21d9e2b  vmovaps xmm3, [rsp+0x30]
00007d0bb21d9e31  vmovaps xmm4, [rsp+0x40]
00007d0bb21d9e37  vmovaps xmm5, [rsp+0x50]
00007d0bb21d9e3d  vmovaps xmm6, [rsp+0x60]
00007d0bb21d9e43  vmovaps xmm7, [rsp+0x70]
00007d0bb21d9e49  vmovaps xmm8, [rsp+0x80]
00007d0bb21d9e52  vmovaps xmm9, [rsp+0x90]
00007d0bb21d9e5b  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d9e64  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d9e6d  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d9e76  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d9e7f  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d9e88  add rsp, 0xF0
00007d0bb21d9e8f  pop r11
00007d0bb21d9e91  pop r10
00007d0bb21d9e93  pop r9
00007d0bb21d9e95  pop r8
00007d0bb21d9e97  pop rsi
00007d0bb21d9e98  pop rdi
00007d0bb21d9e99  pop rdx
00007d0bb21d9e9a  pop rcx
00007d0bb21d9e9b  pop rax
00007d0bb21d9e9c  add rsp, 0x08
00007d0bb21d9ea0  jmp 0x00007D0BB21D8BE6
00007d0bb21d9ea5  sub rsp, 0x08
00007d0bb21d9ea9  push rax
00007d0bb21d9eaa  push rcx
00007d0bb21d9eab  push rdx
00007d0bb21d9eac  push rdi
00007d0bb21d9ead  push rsi
00007d0bb21d9eae  push r8
00007d0bb21d9eb0  push r9
00007d0bb21d9eb2  push r10
00007d0bb21d9eb4  push r11
00007d0bb21d9eb6  sub rsp, 0xF0
00007d0bb21d9ebd  vmovaps [rsp], xmm0
00007d0bb21d9ec2  vmovaps [rsp+0x10], xmm1
00007d0bb21d9ec8  vmovaps [rsp+0x20], xmm2
00007d0bb21d9ece  vmovaps [rsp+0x30], xmm3
00007d0bb21d9ed4  vmovaps [rsp+0x40], xmm4
00007d0bb21d9eda  vmovaps [rsp+0x50], xmm5
00007d0bb21d9ee0  vmovaps [rsp+0x60], xmm7
00007d0bb21d9ee6  vmovaps [rsp+0x70], xmm8
00007d0bb21d9eec  vmovaps [rsp+0x80], xmm9
00007d0bb21d9ef5  vmovaps [rsp+0x90], xmm10
00007d0bb21d9efe  vmovaps [rsp+0xA0], xmm11
00007d0bb21d9f07  vmovaps [rsp+0xB0], xmm12
00007d0bb21d9f10  vmovaps [rsp+0xC0], xmm13
00007d0bb21d9f19  vmovaps [rsp+0xD0], xmm14
00007d0bb21d9f22  vmovaps [rsp+0xE0], xmm15
00007d0bb21d9f2b  sub rsp, 0x30
00007d0bb21d9f2f  movaps [rsp], xmm6
00007d0bb21d9f33  movaps [rsp+0x10], xmm12
00007d0bb21d9f39  movaps [rsp+0x20], xmm11
00007d0bb21d9f3f  lea rdi, [rsp]
00007d0bb21d9f43  mov esi, 0x00
00007d0bb21d9f48  mov rax, 0x6392BBE7F530
00007d0bb21d9f52  call rax
00007d0bb21d9f54  movaps xmm6, [rsp]
00007d0bb21d9f58  add rsp, 0x30
00007d0bb21d9f5c  vmovaps xmm0, [rsp]
00007d0bb21d9f61  vmovaps xmm1, [rsp+0x10]
00007d0bb21d9f67  vmovaps xmm2, [rsp+0x20]
00007d0bb21d9f6d  vmovaps xmm3, [rsp+0x30]
00007d0bb21d9f73  vmovaps xmm4, [rsp+0x40]
00007d0bb21d9f79  vmovaps xmm5, [rsp+0x50]
00007d0bb21d9f7f  vmovaps xmm7, [rsp+0x60]
00007d0bb21d9f85  vmovaps xmm8, [rsp+0x70]
00007d0bb21d9f8b  vmovaps xmm9, [rsp+0x80]
00007d0bb21d9f94  vmovaps xmm10, [rsp+0x90]
00007d0bb21d9f9d  vmovaps xmm11, [rsp+0xA0]
00007d0bb21d9fa6  vmovaps xmm12, [rsp+0xB0]
00007d0bb21d9faf  vmovaps xmm13, [rsp+0xC0]
00007d0bb21d9fb8  vmovaps xmm14, [rsp+0xD0]
00007d0bb21d9fc1  vmovaps xmm15, [rsp+0xE0]
00007d0bb21d9fca  add rsp, 0xF0
00007d0bb21d9fd1  pop r11
00007d0bb21d9fd3  pop r10
00007d0bb21d9fd5  pop r9
00007d0bb21d9fd7  pop r8
00007d0bb21d9fd9  pop rsi
00007d0bb21d9fda  pop rdi
00007d0bb21d9fdb  pop rdx
00007d0bb21d9fdc  pop rcx
00007d0bb21d9fdd  pop rax
00007d0bb21d9fde  add rsp, 0x08
00007d0bb21d9fe2  jmp 0x00007D0BB21D8C07
00007d0bb21d9fe7  sub rsp, 0x08
00007d0bb21d9feb  push rax
00007d0bb21d9fec  push rcx
00007d0bb21d9fed  push rdx
00007d0bb21d9fee  push rdi
00007d0bb21d9fef  push rsi
00007d0bb21d9ff0  push r8
00007d0bb21d9ff2  push r9
00007d0bb21d9ff4  push r10
00007d0bb21d9ff6  push r11
00007d0bb21d9ff8  sub rsp, 0xF0
00007d0bb21d9fff  vmovaps [rsp], xmm0
00007d0bb21da004  vmovaps [rsp+0x10], xmm1
00007d0bb21da00a  vmovaps [rsp+0x20], xmm2
00007d0bb21da010  vmovaps [rsp+0x30], xmm4
00007d0bb21da016  vmovaps [rsp+0x40], xmm5
00007d0bb21da01c  vmovaps [rsp+0x50], xmm6
00007d0bb21da022  vmovaps [rsp+0x60], xmm7
00007d0bb21da028  vmovaps [rsp+0x70], xmm8
00007d0bb21da02e  vmovaps [rsp+0x80], xmm9
00007d0bb21da037  vmovaps [rsp+0x90], xmm10
00007d0bb21da040  vmovaps [rsp+0xA0], xmm11
00007d0bb21da049  vmovaps [rsp+0xB0], xmm12
00007d0bb21da052  vmovaps [rsp+0xC0], xmm13
00007d0bb21da05b  vmovaps [rsp+0xD0], xmm14
00007d0bb21da064  vmovaps [rsp+0xE0], xmm15
00007d0bb21da06d  sub rsp, 0x30
00007d0bb21da071  movaps [rsp], xmm3
00007d0bb21da075  movaps [rsp+0x10], xmm5
00007d0bb21da07a  movaps [rsp+0x20], xmm4
00007d0bb21da07f  lea rdi, [rsp]
00007d0bb21da083  mov esi, 0x00
00007d0bb21da088  mov rax, 0x6392BBE7F530
00007d0bb21da092  call rax
00007d0bb21da094  movaps xmm3, [rsp]
00007d0bb21da098  add rsp, 0x30
00007d0bb21da09c  vmovaps xmm0, [rsp]
00007d0bb21da0a1  vmovaps xmm1, [rsp+0x10]
00007d0bb21da0a7  vmovaps xmm2, [rsp+0x20]
00007d0bb21da0ad  vmovaps xmm4, [rsp+0x30]
00007d0bb21da0b3  vmovaps xmm5, [rsp+0x40]
00007d0bb21da0b9  vmovaps xmm6, [rsp+0x50]
00007d0bb21da0bf  vmovaps xmm7, [rsp+0x60]
00007d0bb21da0c5  vmovaps xmm8, [rsp+0x70]
00007d0bb21da0cb  vmovaps xmm9, [rsp+0x80]
00007d0bb21da0d4  vmovaps xmm10, [rsp+0x90]
00007d0bb21da0dd  vmovaps xmm11, [rsp+0xA0]
00007d0bb21da0e6  vmovaps xmm12, [rsp+0xB0]
00007d0bb21da0ef  vmovaps xmm13, [rsp+0xC0]
00007d0bb21da0f8  vmovaps xmm14, [rsp+0xD0]
00007d0bb21da101  vmovaps xmm15, [rsp+0xE0]
00007d0bb21da10a  add rsp, 0xF0
00007d0bb21da111  pop r11
00007d0bb21da113  pop r10
00007d0bb21da115  pop r9
00007d0bb21da117  pop r8
00007d0bb21da119  pop rsi
00007d0bb21da11a  pop rdi
00007d0bb21da11b  pop rdx
00007d0bb21da11c  pop rcx
00007d0bb21da11d  pop rax
00007d0bb21da11e  add rsp, 0x08
00007d0bb21da122  jmp 0x00007D0BB21D8C68
00007d0bb21da127  sub rsp, 0x08
00007d0bb21da12b  push rax
00007d0bb21da12c  push rcx
00007d0bb21da12d  push rdx
00007d0bb21da12e  push rdi
00007d0bb21da12f  push rsi
00007d0bb21da130  push r8
00007d0bb21da132  push r9
00007d0bb21da134  push r10
00007d0bb21da136  push r11
00007d0bb21da138  sub rsp, 0xF0
00007d0bb21da13f  vmovaps [rsp], xmm0
00007d0bb21da144  vmovaps [rsp+0x10], xmm1
00007d0bb21da14a  vmovaps [rsp+0x20], xmm2
00007d0bb21da150  vmovaps [rsp+0x30], xmm3
00007d0bb21da156  vmovaps [rsp+0x40], xmm4
00007d0bb21da15c  vmovaps [rsp+0x50], xmm6
00007d0bb21da162  vmovaps [rsp+0x60], xmm7
00007d0bb21da168  vmovaps [rsp+0x70], xmm8
00007d0bb21da16e  vmovaps [rsp+0x80], xmm9
00007d0bb21da177  vmovaps [rsp+0x90], xmm10
00007d0bb21da180  vmovaps [rsp+0xA0], xmm11
00007d0bb21da189  vmovaps [rsp+0xB0], xmm12
00007d0bb21da192  vmovaps [rsp+0xC0], xmm13
00007d0bb21da19b  vmovaps [rsp+0xD0], xmm14
00007d0bb21da1a4  vmovaps [rsp+0xE0], xmm15
00007d0bb21da1ad  sub rsp, 0x30
00007d0bb21da1b1  movaps [rsp], xmm5
00007d0bb21da1b5  movaps [rsp+0x10], xmm8
00007d0bb21da1bb  movaps [rsp+0x20], xmm15
00007d0bb21da1c1  lea rdi, [rsp]
00007d0bb21da1c5  mov esi, 0x00
00007d0bb21da1ca  mov rax, 0x6392BBE7F530
00007d0bb21da1d4  call rax
00007d0bb21da1d6  movaps xmm5, [rsp]
00007d0bb21da1da  add rsp, 0x30
00007d0bb21da1de  vmovaps xmm0, [rsp]
00007d0bb21da1e3  vmovaps xmm1, [rsp+0x10]
00007d0bb21da1e9  vmovaps xmm2, [rsp+0x20]
00007d0bb21da1ef  vmovaps xmm3, [rsp+0x30]
00007d0bb21da1f5  vmovaps xmm4, [rsp+0x40]
00007d0bb21da1fb  vmovaps xmm6, [rsp+0x50]
00007d0bb21da201  vmovaps xmm7, [rsp+0x60]
00007d0bb21da207  vmovaps xmm8, [rsp+0x70]
00007d0bb21da20d  vmovaps xmm9, [rsp+0x80]
00007d0bb21da216  vmovaps xmm10, [rsp+0x90]
00007d0bb21da21f  vmovaps xmm11, [rsp+0xA0]
00007d0bb21da228  vmovaps xmm12, [rsp+0xB0]
00007d0bb21da231  vmovaps xmm13, [rsp+0xC0]
00007d0bb21da23a  vmovaps xmm14, [rsp+0xD0]
00007d0bb21da243  vmovaps xmm15, [rsp+0xE0]
00007d0bb21da24c  add rsp, 0xF0
00007d0bb21da253  pop r11
00007d0bb21da255  pop r10
00007d0bb21da257  pop r9
00007d0bb21da259  pop r8
00007d0bb21da25b  pop rsi
00007d0bb21da25c  pop rdi
00007d0bb21da25d  pop rdx
00007d0bb21da25e  pop rcx
00007d0bb21da25f  pop rax
00007d0bb21da260  add rsp, 0x08
00007d0bb21da264  jmp 0x00007D0BB21D8CA0
00007d0bb21da269  sub rsp, 0x08
00007d0bb21da26d  push rax
00007d0bb21da26e  push rcx
00007d0bb21da26f  push rdx
00007d0bb21da270  push rdi
00007d0bb21da271  push rsi
00007d0bb21da272  push r8
00007d0bb21da274  push r9
00007d0bb21da276  push r10
00007d0bb21da278  push r11
00007d0bb21da27a  sub rsp, 0xF0
00007d0bb21da281  vmovaps [rsp], xmm0
00007d0bb21da286  vmovaps [rsp+0x10], xmm1
00007d0bb21da28c  vmovaps [rsp+0x20], xmm2
00007d0bb21da292  vmovaps [rsp+0x30], xmm3
00007d0bb21da298  vmovaps [rsp+0x40], xmm5
00007d0bb21da29e  vmovaps [rsp+0x50], xmm6
00007d0bb21da2a4  vmovaps [rsp+0x60], xmm7
00007d0bb21da2aa  vmovaps [rsp+0x70], xmm8
00007d0bb21da2b0  vmovaps [rsp+0x80], xmm9
00007d0bb21da2b9  vmovaps [rsp+0x90], xmm10
00007d0bb21da2c2  vmovaps [rsp+0xA0], xmm11
00007d0bb21da2cb  vmovaps [rsp+0xB0], xmm12
00007d0bb21da2d4  vmovaps [rsp+0xC0], xmm13
00007d0bb21da2dd  vmovaps [rsp+0xD0], xmm14
00007d0bb21da2e6  vmovaps [rsp+0xE0], xmm15
00007d0bb21da2ef  sub rsp, 0x30
00007d0bb21da2f3  movaps [rsp], xmm4
00007d0bb21da2f7  movaps [rsp+0x10], xmm9
00007d0bb21da2fd  movaps [rsp+0x20], xmm8
00007d0bb21da303  lea rdi, [rsp]
00007d0bb21da307  mov esi, 0x00
00007d0bb21da30c  mov rax, 0x6392BBE7F530
00007d0bb21da316  call rax
00007d0bb21da318  movaps xmm4, [rsp]
00007d0bb21da31c  add rsp, 0x30
00007d0bb21da320  vmovaps xmm0, [rsp]
00007d0bb21da325  vmovaps xmm1, [rsp+0x10]
00007d0bb21da32b  vmovaps xmm2, [rsp+0x20]
00007d0bb21da331  vmovaps xmm3, [rsp+0x30]
00007d0bb21da337  vmovaps xmm5, [rsp+0x40]
00007d0bb21da33d  vmovaps xmm6, [rsp+0x50]
00007d0bb21da343  vmovaps xmm7, [rsp+0x60]
00007d0bb21da349  vmovaps xmm8, [rsp+0x70]
00007d0bb21da34f  vmovaps xmm9, [rsp+0x80]
00007d0bb21da358  vmovaps xmm10, [rsp+0x90]
00007d0bb21da361  vmovaps xmm11, [rsp+0xA0]
00007d0bb21da36a  vmovaps xmm12, [rsp+0xB0]
00007d0bb21da373  vmovaps xmm13, [rsp+0xC0]
00007d0bb21da37c  vmovaps xmm14, [rsp+0xD0]
00007d0bb21da385  vmovaps xmm15, [rsp+0xE0]
00007d0bb21da38e  add rsp, 0xF0
00007d0bb21da395  pop r11
00007d0bb21da397  pop r10
00007d0bb21da399  pop r9
00007d0bb21da39b  pop r8
00007d0bb21da39d  pop rsi
00007d0bb21da39e  pop rdi
00007d0bb21da39f  pop rdx
00007d0bb21da3a0  pop rcx
00007d0bb21da3a1  pop rax
00007d0bb21da3a2  add rsp, 0x08
00007d0bb21da3a6  jmp 0x00007D0BB21D8CC1
00007d0bb21da3ab  sub rsp, 0x08
00007d0bb21da3af  push rax
00007d0bb21da3b0  push rcx
00007d0bb21da3b1  push rdx
00007d0bb21da3b2  push rdi
00007d0bb21da3b3  push rsi
00007d0bb21da3b4  push r8
00007d0bb21da3b6  push r9
00007d0bb21da3b8  push r10
00007d0bb21da3ba  push r11
00007d0bb21da3bc  sub rsp, 0xF0
00007d0bb21da3c3  vmovaps [rsp], xmm0
00007d0bb21da3c8  vmovaps [rsp+0x10], xmm1
00007d0bb21da3ce  vmovaps [rsp+0x20], xmm2
00007d0bb21da3d4  vmovaps [rsp+0x30], xmm3
00007d0bb21da3da  vmovaps [rsp+0x40], xmm4
00007d0bb21da3e0  vmovaps [rsp+0x50], xmm5
00007d0bb21da3e6  vmovaps [rsp+0x60], xmm6
00007d0bb21da3ec  vmovaps [rsp+0x70], xmm7
00007d0bb21da3f2  vmovaps [rsp+0x80], xmm8
00007d0bb21da3fb  vmovaps [rsp+0x90], xmm10
00007d0bb21da404  vmovaps [rsp+0xA0], xmm11
00007d0bb21da40d  vmovaps [rsp+0xB0], xmm12
00007d0bb21da416  vmovaps [rsp+0xC0], xmm13
00007d0bb21da41f  vmovaps [rsp+0xD0], xmm14
00007d0bb21da428  vmovaps [rsp+0xE0], xmm15
00007d0bb21da431  sub rsp, 0x30
00007d0bb21da435  movaps [rsp], xmm9
00007d0bb21da43a  movaps [rsp+0x10], xmm10
00007d0bb21da440  movaps [rsp+0x20], xmm8
00007d0bb21da446  lea rdi, [rsp]
00007d0bb21da44a  mov esi, 0x00
00007d0bb21da44f  mov rax, 0x6392BBE7F530
00007d0bb21da459  call rax
00007d0bb21da45b  movaps xmm9, [rsp]
00007d0bb21da460  add rsp, 0x30
00007d0bb21da464  vmovaps xmm0, [rsp]
00007d0bb21da469  vmovaps xmm1, [rsp+0x10]
00007d0bb21da46f  vmovaps xmm2, [rsp+0x20]
00007d0bb21da475  vmovaps xmm3, [rsp+0x30]
00007d0bb21da47b  vmovaps xmm4, [rsp+0x40]
00007d0bb21da481  vmovaps xmm5, [rsp+0x50]
00007d0bb21da487  vmovaps xmm6, [rsp+0x60]
00007d0bb21da48d  vmovaps xmm7, [rsp+0x70]
00007d0bb21da493  vmovaps xmm8, [rsp+0x80]
00007d0bb21da49c  vmovaps xmm10, [rsp+0x90]
00007d0bb21da4a5  vmovaps xmm11, [rsp+0xA0]
00007d0bb21da4ae  vmovaps xmm12, [rsp+0xB0]
00007d0bb21da4b7  vmovaps xmm13, [rsp+0xC0]
00007d0bb21da4c0  vmovaps xmm14, [rsp+0xD0]
00007d0bb21da4c9  vmovaps xmm15, [rsp+0xE0]
00007d0bb21da4d2  add rsp, 0xF0
00007d0bb21da4d9  pop r11
00007d0bb21da4db  pop r10
00007d0bb21da4dd  pop r9
00007d0bb21da4df  pop r8
00007d0bb21da4e1  pop rsi
00007d0bb21da4e2  pop rdi
00007d0bb21da4e3  pop rdx
00007d0bb21da4e4  pop rcx
00007d0bb21da4e5  pop rax
00007d0bb21da4e6  add rsp, 0x08
00007d0bb21da4ea  jmp 0x00007D0BB21D8CDB
00007d0bb21da4ef  call 0x00007D0BB20D64F0
00007d0bb21da4f4  jmp 0x00007D0BB21D8DF5
00007d0bb21da4f9  call 0x00007D0BB20D64F0
00007d0bb21da4fe  jmp 0x00007D0BB21D8E0B
00007d0bb21da503  sub rsp, 0x08
00007d0bb21da507  push rax
00007d0bb21da508  push rcx
00007d0bb21da509  push rdx
00007d0bb21da50a  push rdi
00007d0bb21da50b  push rsi
00007d0bb21da50c  push r8
00007d0bb21da50e  push r9
00007d0bb21da510  push r10
00007d0bb21da512  push r11
00007d0bb21da514  sub rsp, 0xF0
00007d0bb21da51b  vmovaps [rsp], xmm0
00007d0bb21da520  vmovaps [rsp+0x10], xmm2
00007d0bb21da526  vmovaps [rsp+0x20], xmm3
00007d0bb21da52c  vmovaps [rsp+0x30], xmm4
00007d0bb21da532  vmovaps [rsp+0x40], xmm5
00007d0bb21da538  vmovaps [rsp+0x50], xmm6
00007d0bb21da53e  vmovaps [rsp+0x60], xmm7
00007d0bb21da544  vmovaps [rsp+0x70], xmm8
00007d0bb21da54a  vmovaps [rsp+0x80], xmm9
00007d0bb21da553  vmovaps [rsp+0x90], xmm10
00007d0bb21da55c  vmovaps [rsp+0xA0], xmm11
00007d0bb21da565  vmovaps [rsp+0xB0], xmm12
00007d0bb21da56e  vmovaps [rsp+0xC0], xmm13
00007d0bb21da577  vmovaps [rsp+0xD0], xmm14
00007d0bb21da580  vmovaps [rsp+0xE0], xmm15
00007d0bb21da589  sub rsp, 0x30
00007d0bb21da58d  movaps [rsp], xmm1
00007d0bb21da591  movaps [rsp+0x10], xmm6
00007d0bb21da596  movaps [rsp+0x20], xmm15
00007d0bb21da59c  lea rdi, [rsp]
00007d0bb21da5a0  mov esi, 0x00
00007d0bb21da5a5  mov rax, 0x6392BBE7F530
00007d0bb21da5af  call rax
00007d0bb21da5b1  movaps xmm1, [rsp]
00007d0bb21da5b5  add rsp, 0x30
00007d0bb21da5b9  vmovaps xmm0, [rsp]
00007d0bb21da5be  vmovaps xmm2, [rsp+0x10]
00007d0bb21da5c4  vmovaps xmm3, [rsp+0x20]
00007d0bb21da5ca  vmovaps xmm4, [rsp+0x30]
00007d0bb21da5d0  vmovaps xmm5, [rsp+0x40]
00007d0bb21da5d6  vmovaps xmm6, [rsp+0x50]
00007d0bb21da5dc  vmovaps xmm7, [rsp+0x60]
00007d0bb21da5e2  vmovaps xmm8, [rsp+0x70]
00007d0bb21da5e8  vmovaps xmm9, [rsp+0x80]
00007d0bb21da5f1  vmovaps xmm10, [rsp+0x90]
00007d0bb21da5fa  vmovaps xmm11, [rsp+0xA0]
00007d0bb21da603  vmovaps xmm12, [rsp+0xB0]
00007d0bb21da60c  vmovaps xmm13, [rsp+0xC0]
00007d0bb21da615  vmovaps xmm14, [rsp+0xD0]
00007d0bb21da61e  vmovaps xmm15, [rsp+0xE0]
00007d0bb21da627  add rsp, 0xF0
00007d0bb21da62e  pop r11
00007d0bb21da630  pop r10
00007d0bb21da632  pop r9
00007d0bb21da634  pop r8
00007d0bb21da636  pop rsi
00007d0bb21da637  pop rdi
00007d0bb21da638  pop rdx
00007d0bb21da639  pop rcx
00007d0bb21da63a  pop rax
00007d0bb21da63b  add rsp, 0x08
00007d0bb21da63f  jmp 0x00007D0BB21D8E48
00007d0bb21da644  call 0x00007D0BB20E5820
00007d0bb21da649  jmp 0x00007D0BB21D8E55
00007d0bb21da64e  sub rsp, 0x08
00007d0bb21da652  push rax
00007d0bb21da653  push rcx
00007d0bb21da654  push rdx
00007d0bb21da655  push rdi
00007d0bb21da656  push rsi
00007d0bb21da657  push r8
00007d0bb21da659  push r9
00007d0bb21da65b  push r10
00007d0bb21da65d  push r11
00007d0bb21da65f  sub rsp, 0xF0
00007d0bb21da666  vmovaps [rsp], xmm0
00007d0bb21da66b  vmovaps [rsp+0x10], xmm1
00007d0bb21da671  vmovaps [rsp+0x20], xmm2
00007d0bb21da677  vmovaps [rsp+0x30], xmm3
00007d0bb21da67d  vmovaps [rsp+0x40], xmm4
00007d0bb21da683  vmovaps [rsp+0x50], xmm5
00007d0bb21da689  vmovaps [rsp+0x60], xmm6
00007d0bb21da68f  vmovaps [rsp+0x70], xmm7
00007d0bb21da695  vmovaps [rsp+0x80], xmm8
00007d0bb21da69e  vmovaps [rsp+0x90], xmm9
00007d0bb21da6a7  vmovaps [rsp+0xA0], xmm10
00007d0bb21da6b0  vmovaps [rsp+0xB0], xmm11
00007d0bb21da6b9  vmovaps [rsp+0xC0], xmm12
00007d0bb21da6c2  vmovaps [rsp+0xD0], xmm13
00007d0bb21da6cb  vmovaps [rsp+0xE0], xmm15
00007d0bb21da6d4  sub rsp, 0x30
00007d0bb21da6d8  movaps [rsp], xmm14
00007d0bb21da6dd  movaps [rsp+0x10], xmm4
00007d0bb21da6e2  movaps [rsp+0x20], xmm3
00007d0bb21da6e7  lea rdi, [rsp]
00007d0bb21da6eb  mov esi, 0x00
00007d0bb21da6f0  mov rax, 0x6392BBE7F530
00007d0bb21da6fa  call rax
00007d0bb21da6fc  movaps xmm14, [rsp]
00007d0bb21da701  add rsp, 0x30
00007d0bb21da705  vmovaps xmm0, [rsp]
00007d0bb21da70a  vmovaps xmm1, [rsp+0x10]
00007d0bb21da710  vmovaps xmm2, [rsp+0x20]
00007d0bb21da716  vmovaps xmm3, [rsp+0x30]
00007d0bb21da71c  vmovaps xmm4, [rsp+0x40]
00007d0bb21da722  vmovaps xmm5, [rsp+0x50]
00007d0bb21da728  vmovaps xmm6, [rsp+0x60]
00007d0bb21da72e  vmovaps xmm7, [rsp+0x70]
00007d0bb21da734  vmovaps xmm8, [rsp+0x80]
00007d0bb21da73d  vmovaps xmm9, [rsp+0x90]
00007d0bb21da746  vmovaps xmm10, [rsp+0xA0]
00007d0bb21da74f  vmovaps xmm11, [rsp+0xB0]
00007d0bb21da758  vmovaps xmm12, [rsp+0xC0]
00007d0bb21da761  vmovaps xmm13, [rsp+0xD0]
00007d0bb21da76a  vmovaps xmm15, [rsp+0xE0]
00007d0bb21da773  add rsp, 0xF0
00007d0bb21da77a  pop r11
00007d0bb21da77c  pop r10
00007d0bb21da77e  pop r9
00007d0bb21da780  pop r8
00007d0bb21da782  pop rsi
00007d0bb21da783  pop rdi
00007d0bb21da784  pop rdx
00007d0bb21da785  pop rcx
00007d0bb21da786  pop rax
00007d0bb21da787  add rsp, 0x08
00007d0bb21da78b  jmp 0x00007D0BB21D8E6F
00007d0bb21da790  sub rsp, 0x08
00007d0bb21da794  push rax
00007d0bb21da795  push rcx
00007d0bb21da796  push rdx
00007d0bb21da797  push rdi
00007d0bb21da798  push rsi
00007d0bb21da799  push r8
00007d0bb21da79b  push r9
00007d0bb21da79d  push r10
00007d0bb21da79f  push r11
00007d0bb21da7a1  sub rsp, 0xF0
00007d0bb21da7a8  vmovaps [rsp], xmm0
00007d0bb21da7ad  vmovaps [rsp+0x10], xmm1
00007d0bb21da7b3  vmovaps [rsp+0x20], xmm2
00007d0bb21da7b9  vmovaps [rsp+0x30], xmm3
00007d0bb21da7bf  vmovaps [rsp+0x40], xmm4
00007d0bb21da7c5  vmovaps [rsp+0x50], xmm5
00007d0bb21da7cb  vmovaps [rsp+0x60], xmm7
00007d0bb21da7d1  vmovaps [rsp+0x70], xmm8
00007d0bb21da7d7  vmovaps [rsp+0x80], xmm9
00007d0bb21da7e0  vmovaps [rsp+0x90], xmm10
00007d0bb21da7e9  vmovaps [rsp+0xA0], xmm11
00007d0bb21da7f2  vmovaps [rsp+0xB0], xmm12
00007d0bb21da7fb  vmovaps [rsp+0xC0], xmm13
00007d0bb21da804  vmovaps [rsp+0xD0], xmm14
00007d0bb21da80d  vmovaps [rsp+0xE0], xmm15
00007d0bb21da816  sub rsp, 0x30
00007d0bb21da81a  movaps [rsp], xmm6
00007d0bb21da81e  movaps [rsp+0x10], xmm9
00007d0bb21da824  movaps [rsp+0x20], xmm7
00007d0bb21da829  lea rdi, [rsp]
00007d0bb21da82d  mov esi, 0x00
00007d0bb21da832  mov rax, 0x6392BBE7F530
00007d0bb21da83c  call rax
00007d0bb21da83e  movaps xmm6, [rsp]
00007d0bb21da842  add rsp, 0x30
00007d0bb21da846  vmovaps xmm0, [rsp]
00007d0bb21da84b  vmovaps xmm1, [rsp+0x10]
00007d0bb21da851  vmovaps xmm2, [rsp+0x20]
00007d0bb21da857  vmovaps xmm3, [rsp+0x30]
00007d0bb21da85d  vmovaps xmm4, [rsp+0x40]
00007d0bb21da863  vmovaps xmm5, [rsp+0x50]
00007d0bb21da869  vmovaps xmm7, [rsp+0x60]
00007d0bb21da86f  vmovaps xmm8, [rsp+0x70]
00007d0bb21da875  vmovaps xmm9, [rsp+0x80]
00007d0bb21da87e  vmovaps xmm10, [rsp+0x90]
00007d0bb21da887  vmovaps xmm11, [rsp+0xA0]
00007d0bb21da890  vmovaps xmm12, [rsp+0xB0]
00007d0bb21da899  vmovaps xmm13, [rsp+0xC0]
00007d0bb21da8a2  vmovaps xmm14, [rsp+0xD0]
00007d0bb21da8ab  vmovaps xmm15, [rsp+0xE0]
00007d0bb21da8b4  add rsp, 0xF0
00007d0bb21da8bb  pop r11
00007d0bb21da8bd  pop r10
00007d0bb21da8bf  pop r9
00007d0bb21da8c1  pop r8
00007d0bb21da8c3  pop rsi
00007d0bb21da8c4  pop rdi
00007d0bb21da8c5  pop rdx
00007d0bb21da8c6  pop rcx
00007d0bb21da8c7  pop rax
00007d0bb21da8c8  add rsp, 0x08
00007d0bb21da8cc  jmp 0x00007D0BB21D8E87
00007d0bb21da8d1  sub rsp, 0x08
00007d0bb21da8d5  push rax
00007d0bb21da8d6  push rcx
00007d0bb21da8d7  push rdx
00007d0bb21da8d8  push rdi
00007d0bb21da8d9  push rsi
00007d0bb21da8da  push r8
00007d0bb21da8dc  push r9
00007d0bb21da8de  push r10
00007d0bb21da8e0  push r11
00007d0bb21da8e2  sub rsp, 0xF0
00007d0bb21da8e9  vmovaps [rsp], xmm0
00007d0bb21da8ee  vmovaps [rsp+0x10], xmm1
00007d0bb21da8f4  vmovaps [rsp+0x20], xmm2
00007d0bb21da8fa  vmovaps [rsp+0x30], xmm3
00007d0bb21da900  vmovaps [rsp+0x40], xmm4
00007d0bb21da906  vmovaps [rsp+0x50], xmm5
00007d0bb21da90c  vmovaps [rsp+0x60], xmm6
00007d0bb21da912  vmovaps [rsp+0x70], xmm8
00007d0bb21da918  vmovaps [rsp+0x80], xmm9
00007d0bb21da921  vmovaps [rsp+0x90], xmm10
00007d0bb21da92a  vmovaps [rsp+0xA0], xmm11
00007d0bb21da933  vmovaps [rsp+0xB0], xmm12
00007d0bb21da93c  vmovaps [rsp+0xC0], xmm13
00007d0bb21da945  vmovaps [rsp+0xD0], xmm14
00007d0bb21da94e  vmovaps [rsp+0xE0], xmm15
00007d0bb21da957  sub rsp, 0x30
00007d0bb21da95b  movaps [rsp], xmm7
00007d0bb21da95f  movaps [rsp+0x10], xmm4
00007d0bb21da964  movaps [rsp+0x20], xmm9
00007d0bb21da96a  lea rdi, [rsp]
00007d0bb21da96e  mov esi, 0x00
00007d0bb21da973  mov rax, 0x6392BBE7F530
00007d0bb21da97d  call rax
00007d0bb21da97f  movaps xmm7, [rsp]
00007d0bb21da983  add rsp, 0x30
00007d0bb21da987  vmovaps xmm0, [rsp]
00007d0bb21da98c  vmovaps xmm1, [rsp+0x10]
00007d0bb21da992  vmovaps xmm2, [rsp+0x20]
00007d0bb21da998  vmovaps xmm3, [rsp+0x30]
00007d0bb21da99e  vmovaps xmm4, [rsp+0x40]
00007d0bb21da9a4  vmovaps xmm5, [rsp+0x50]
00007d0bb21da9aa  vmovaps xmm6, [rsp+0x60]
00007d0bb21da9b0  vmovaps xmm8, [rsp+0x70]
00007d0bb21da9b6  vmovaps xmm9, [rsp+0x80]
00007d0bb21da9bf  vmovaps xmm10, [rsp+0x90]
00007d0bb21da9c8  vmovaps xmm11, [rsp+0xA0]
00007d0bb21da9d1  vmovaps xmm12, [rsp+0xB0]
00007d0bb21da9da  vmovaps xmm13, [rsp+0xC0]
00007d0bb21da9e3  vmovaps xmm14, [rsp+0xD0]
00007d0bb21da9ec  vmovaps xmm15, [rsp+0xE0]
00007d0bb21da9f5  add rsp, 0xF0
00007d0bb21da9fc  pop r11
00007d0bb21da9fe  pop r10
00007d0bb21daa00  pop r9
00007d0bb21daa02  pop r8
00007d0bb21daa04  pop rsi
00007d0bb21daa05  pop rdi
00007d0bb21daa06  pop rdx
00007d0bb21daa07  pop rcx
00007d0bb21daa08  pop rax
00007d0bb21daa09  add rsp, 0x08
00007d0bb21daa0d  jmp 0x00007D0BB21D8EB4
00007d0bb21daa12  sub rsp, 0x08
00007d0bb21daa16  push rax
00007d0bb21daa17  push rcx
00007d0bb21daa18  push rdx
00007d0bb21daa19  push rdi
00007d0bb21daa1a  push rsi
00007d0bb21daa1b  push r8
00007d0bb21daa1d  push r9
00007d0bb21daa1f  push r10
00007d0bb21daa21  push r11
00007d0bb21daa23  sub rsp, 0xF0
00007d0bb21daa2a  vmovaps [rsp], xmm0
00007d0bb21daa2f  vmovaps [rsp+0x10], xmm1
00007d0bb21daa35  vmovaps [rsp+0x20], xmm2
00007d0bb21daa3b  vmovaps [rsp+0x30], xmm3
00007d0bb21daa41  vmovaps [rsp+0x40], xmm5
00007d0bb21daa47  vmovaps [rsp+0x50], xmm6
00007d0bb21daa4d  vmovaps [rsp+0x60], xmm7
00007d0bb21daa53  vmovaps [rsp+0x70], xmm8
00007d0bb21daa59  vmovaps [rsp+0x80], xmm9
00007d0bb21daa62  vmovaps [rsp+0x90], xmm10
00007d0bb21daa6b  vmovaps [rsp+0xA0], xmm11
00007d0bb21daa74  vmovaps [rsp+0xB0], xmm12
00007d0bb21daa7d  vmovaps [rsp+0xC0], xmm13
00007d0bb21daa86  vmovaps [rsp+0xD0], xmm14
00007d0bb21daa8f  vmovaps [rsp+0xE0], xmm15
00007d0bb21daa98  sub rsp, 0x30
00007d0bb21daa9c  movaps [rsp], xmm4
00007d0bb21daaa0  movaps [rsp+0x10], xmm15
00007d0bb21daaa6  movaps [rsp+0x20], xmm9
00007d0bb21daaac  lea rdi, [rsp]
00007d0bb21daab0  mov esi, 0x00
00007d0bb21daab5  mov rax, 0x6392BBE7F530
00007d0bb21daabf  call rax
00007d0bb21daac1  movaps xmm4, [rsp]
00007d0bb21daac5  add rsp, 0x30
00007d0bb21daac9  vmovaps xmm0, [rsp]
00007d0bb21daace  vmovaps xmm1, [rsp+0x10]
00007d0bb21daad4  vmovaps xmm2, [rsp+0x20]
00007d0bb21daada  vmovaps xmm3, [rsp+0x30]
00007d0bb21daae0  vmovaps xmm5, [rsp+0x40]
00007d0bb21daae6  vmovaps xmm6, [rsp+0x50]
00007d0bb21daaec  vmovaps xmm7, [rsp+0x60]
00007d0bb21daaf2  vmovaps xmm8, [rsp+0x70]
00007d0bb21daaf8  vmovaps xmm9, [rsp+0x80]
00007d0bb21dab01  vmovaps xmm10, [rsp+0x90]
00007d0bb21dab0a  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dab13  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dab1c  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dab25  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dab2e  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dab37  add rsp, 0xF0
00007d0bb21dab3e  pop r11
00007d0bb21dab40  pop r10
00007d0bb21dab42  pop r9
00007d0bb21dab44  pop r8
00007d0bb21dab46  pop rsi
00007d0bb21dab47  pop rdi
00007d0bb21dab48  pop rdx
00007d0bb21dab49  pop rcx
00007d0bb21dab4a  pop rax
00007d0bb21dab4b  add rsp, 0x08
00007d0bb21dab4f  jmp 0x00007D0BB21D8ED9
00007d0bb21dab54  call 0x00007D0BB20E5820
00007d0bb21dab59  jmp 0x00007D0BB21D8EE6
00007d0bb21dab5e  sub rsp, 0x08
00007d0bb21dab62  push rax
00007d0bb21dab63  push rcx
00007d0bb21dab64  push rdx
00007d0bb21dab65  push rdi
00007d0bb21dab66  push rsi
00007d0bb21dab67  push r8
00007d0bb21dab69  push r9
00007d0bb21dab6b  push r10
00007d0bb21dab6d  push r11
00007d0bb21dab6f  sub rsp, 0xF0
00007d0bb21dab76  vmovaps [rsp], xmm0
00007d0bb21dab7b  vmovaps [rsp+0x10], xmm1
00007d0bb21dab81  vmovaps [rsp+0x20], xmm2
00007d0bb21dab87  vmovaps [rsp+0x30], xmm4
00007d0bb21dab8d  vmovaps [rsp+0x40], xmm5
00007d0bb21dab93  vmovaps [rsp+0x50], xmm6
00007d0bb21dab99  vmovaps [rsp+0x60], xmm7
00007d0bb21dab9f  vmovaps [rsp+0x70], xmm8
00007d0bb21daba5  vmovaps [rsp+0x80], xmm9
00007d0bb21dabae  vmovaps [rsp+0x90], xmm10
00007d0bb21dabb7  vmovaps [rsp+0xA0], xmm11
00007d0bb21dabc0  vmovaps [rsp+0xB0], xmm12
00007d0bb21dabc9  vmovaps [rsp+0xC0], xmm13
00007d0bb21dabd2  vmovaps [rsp+0xD0], xmm14
00007d0bb21dabdb  vmovaps [rsp+0xE0], xmm15
00007d0bb21dabe4  sub rsp, 0x30
00007d0bb21dabe8  movaps [rsp], xmm3
00007d0bb21dabec  movaps [rsp+0x10], xmm1
00007d0bb21dabf1  movaps [rsp+0x20], xmm9
00007d0bb21dabf7  lea rdi, [rsp]
00007d0bb21dabfb  mov esi, 0x00
00007d0bb21dac00  mov rax, 0x6392BBE7F530
00007d0bb21dac0a  call rax
00007d0bb21dac0c  movaps xmm3, [rsp]
00007d0bb21dac10  add rsp, 0x30
00007d0bb21dac14  vmovaps xmm0, [rsp]
00007d0bb21dac19  vmovaps xmm1, [rsp+0x10]
00007d0bb21dac1f  vmovaps xmm2, [rsp+0x20]
00007d0bb21dac25  vmovaps xmm4, [rsp+0x30]
00007d0bb21dac2b  vmovaps xmm5, [rsp+0x40]
00007d0bb21dac31  vmovaps xmm6, [rsp+0x50]
00007d0bb21dac37  vmovaps xmm7, [rsp+0x60]
00007d0bb21dac3d  vmovaps xmm8, [rsp+0x70]
00007d0bb21dac43  vmovaps xmm9, [rsp+0x80]
00007d0bb21dac4c  vmovaps xmm10, [rsp+0x90]
00007d0bb21dac55  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dac5e  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dac67  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dac70  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dac79  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dac82  add rsp, 0xF0
00007d0bb21dac89  pop r11
00007d0bb21dac8b  pop r10
00007d0bb21dac8d  pop r9
00007d0bb21dac8f  pop r8
00007d0bb21dac91  pop rsi
00007d0bb21dac92  pop rdi
00007d0bb21dac93  pop rdx
00007d0bb21dac94  pop rcx
00007d0bb21dac95  pop rax
00007d0bb21dac96  add rsp, 0x08
00007d0bb21dac9a  jmp 0x00007D0BB21D8F23
00007d0bb21dac9f  sub rsp, 0x08
00007d0bb21daca3  push rax
00007d0bb21daca4  push rcx
00007d0bb21daca5  push rdx
00007d0bb21daca6  push rdi
00007d0bb21daca7  push rsi
00007d0bb21daca8  push r8
00007d0bb21dacaa  push r9
00007d0bb21dacac  push r10
00007d0bb21dacae  push r11
00007d0bb21dacb0  sub rsp, 0xF0
00007d0bb21dacb7  vmovaps [rsp], xmm0
00007d0bb21dacbc  vmovaps [rsp+0x10], xmm2
00007d0bb21dacc2  vmovaps [rsp+0x20], xmm3
00007d0bb21dacc8  vmovaps [rsp+0x30], xmm4
00007d0bb21dacce  vmovaps [rsp+0x40], xmm5
00007d0bb21dacd4  vmovaps [rsp+0x50], xmm6
00007d0bb21dacda  vmovaps [rsp+0x60], xmm7
00007d0bb21dace0  vmovaps [rsp+0x70], xmm8
00007d0bb21dace6  vmovaps [rsp+0x80], xmm9
00007d0bb21dacef  vmovaps [rsp+0x90], xmm10
00007d0bb21dacf8  vmovaps [rsp+0xA0], xmm11
00007d0bb21dad01  vmovaps [rsp+0xB0], xmm12
00007d0bb21dad0a  vmovaps [rsp+0xC0], xmm13
00007d0bb21dad13  vmovaps [rsp+0xD0], xmm14
00007d0bb21dad1c  vmovaps [rsp+0xE0], xmm15
00007d0bb21dad25  sub rsp, 0x30
00007d0bb21dad29  movaps [rsp], xmm1
00007d0bb21dad2d  movaps [rsp+0x10], xmm15
00007d0bb21dad33  movaps [rsp+0x20], xmm9
00007d0bb21dad39  lea rdi, [rsp]
00007d0bb21dad3d  mov esi, 0x00
00007d0bb21dad42  mov rax, 0x6392BBE7F530
00007d0bb21dad4c  call rax
00007d0bb21dad4e  movaps xmm1, [rsp]
00007d0bb21dad52  add rsp, 0x30
00007d0bb21dad56  vmovaps xmm0, [rsp]
00007d0bb21dad5b  vmovaps xmm2, [rsp+0x10]
00007d0bb21dad61  vmovaps xmm3, [rsp+0x20]
00007d0bb21dad67  vmovaps xmm4, [rsp+0x30]
00007d0bb21dad6d  vmovaps xmm5, [rsp+0x40]
00007d0bb21dad73  vmovaps xmm6, [rsp+0x50]
00007d0bb21dad79  vmovaps xmm7, [rsp+0x60]
00007d0bb21dad7f  vmovaps xmm8, [rsp+0x70]
00007d0bb21dad85  vmovaps xmm9, [rsp+0x80]
00007d0bb21dad8e  vmovaps xmm10, [rsp+0x90]
00007d0bb21dad97  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dada0  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dada9  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dadb2  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dadbb  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dadc4  add rsp, 0xF0
00007d0bb21dadcb  pop r11
00007d0bb21dadcd  pop r10
00007d0bb21dadcf  pop r9
00007d0bb21dadd1  pop r8
00007d0bb21dadd3  pop rsi
00007d0bb21dadd4  pop rdi
00007d0bb21dadd5  pop rdx
00007d0bb21dadd6  pop rcx
00007d0bb21dadd7  pop rax
00007d0bb21dadd8  add rsp, 0x08
00007d0bb21daddc  jmp 0x00007D0BB21D8FAB
00007d0bb21dade1  call 0x00007D0BB20E5820
00007d0bb21dade6  jmp 0x00007D0BB21D8FB8
00007d0bb21dadeb  sub rsp, 0x08
00007d0bb21dadef  push rax
00007d0bb21dadf0  push rcx
00007d0bb21dadf1  push rdx
00007d0bb21dadf2  push rdi
00007d0bb21dadf3  push rsi
00007d0bb21dadf4  push r8
00007d0bb21dadf6  push r9
00007d0bb21dadf8  push r10
00007d0bb21dadfa  push r11
00007d0bb21dadfc  sub rsp, 0xF0
00007d0bb21dae03  vmovaps [rsp], xmm0
00007d0bb21dae08  vmovaps [rsp+0x10], xmm2
00007d0bb21dae0e  vmovaps [rsp+0x20], xmm3
00007d0bb21dae14  vmovaps [rsp+0x30], xmm4
00007d0bb21dae1a  vmovaps [rsp+0x40], xmm5
00007d0bb21dae20  vmovaps [rsp+0x50], xmm6
00007d0bb21dae26  vmovaps [rsp+0x60], xmm7
00007d0bb21dae2c  vmovaps [rsp+0x70], xmm8
00007d0bb21dae32  vmovaps [rsp+0x80], xmm9
00007d0bb21dae3b  vmovaps [rsp+0x90], xmm10
00007d0bb21dae44  vmovaps [rsp+0xA0], xmm11
00007d0bb21dae4d  vmovaps [rsp+0xB0], xmm12
00007d0bb21dae56  vmovaps [rsp+0xC0], xmm13
00007d0bb21dae5f  vmovaps [rsp+0xD0], xmm14
00007d0bb21dae68  vmovaps [rsp+0xE0], xmm15
00007d0bb21dae71  sub rsp, 0x30
00007d0bb21dae75  movaps [rsp], xmm1
00007d0bb21dae79  movaps [rsp+0x10], xmm5
00007d0bb21dae7e  movaps [rsp+0x20], xmm7
00007d0bb21dae83  lea rdi, [rsp]
00007d0bb21dae87  mov esi, 0x00
00007d0bb21dae8c  mov rax, 0x6392BBE7F530
00007d0bb21dae96  call rax
00007d0bb21dae98  movaps xmm1, [rsp]
00007d0bb21dae9c  add rsp, 0x30
00007d0bb21daea0  vmovaps xmm0, [rsp]
00007d0bb21daea5  vmovaps xmm2, [rsp+0x10]
00007d0bb21daeab  vmovaps xmm3, [rsp+0x20]
00007d0bb21daeb1  vmovaps xmm4, [rsp+0x30]
00007d0bb21daeb7  vmovaps xmm5, [rsp+0x40]
00007d0bb21daebd  vmovaps xmm6, [rsp+0x50]
00007d0bb21daec3  vmovaps xmm7, [rsp+0x60]
00007d0bb21daec9  vmovaps xmm8, [rsp+0x70]
00007d0bb21daecf  vmovaps xmm9, [rsp+0x80]
00007d0bb21daed8  vmovaps xmm10, [rsp+0x90]
00007d0bb21daee1  vmovaps xmm11, [rsp+0xA0]
00007d0bb21daeea  vmovaps xmm12, [rsp+0xB0]
00007d0bb21daef3  vmovaps xmm13, [rsp+0xC0]
00007d0bb21daefc  vmovaps xmm14, [rsp+0xD0]
00007d0bb21daf05  vmovaps xmm15, [rsp+0xE0]
00007d0bb21daf0e  add rsp, 0xF0
00007d0bb21daf15  pop r11
00007d0bb21daf17  pop r10
00007d0bb21daf19  pop r9
00007d0bb21daf1b  pop r8
00007d0bb21daf1d  pop rsi
00007d0bb21daf1e  pop rdi
00007d0bb21daf1f  pop rdx
00007d0bb21daf20  pop rcx
00007d0bb21daf21  pop rax
00007d0bb21daf22  add rsp, 0x08
00007d0bb21daf26  jmp 0x00007D0BB21D905D
00007d0bb21daf2b  sub rsp, 0x08
00007d0bb21daf2f  push rax
00007d0bb21daf30  push rcx
00007d0bb21daf31  push rdx
00007d0bb21daf32  push rdi
00007d0bb21daf33  push rsi
00007d0bb21daf34  push r8
00007d0bb21daf36  push r9
00007d0bb21daf38  push r10
00007d0bb21daf3a  push r11
00007d0bb21daf3c  sub rsp, 0xF0
00007d0bb21daf43  vmovaps [rsp], xmm0
00007d0bb21daf48  vmovaps [rsp+0x10], xmm1
00007d0bb21daf4e  vmovaps [rsp+0x20], xmm2
00007d0bb21daf54  vmovaps [rsp+0x30], xmm3
00007d0bb21daf5a  vmovaps [rsp+0x40], xmm4
00007d0bb21daf60  vmovaps [rsp+0x50], xmm5
00007d0bb21daf66  vmovaps [rsp+0x60], xmm6
00007d0bb21daf6c  vmovaps [rsp+0x70], xmm8
00007d0bb21daf72  vmovaps [rsp+0x80], xmm9
00007d0bb21daf7b  vmovaps [rsp+0x90], xmm10
00007d0bb21daf84  vmovaps [rsp+0xA0], xmm11
00007d0bb21daf8d  vmovaps [rsp+0xB0], xmm12
00007d0bb21daf96  vmovaps [rsp+0xC0], xmm13
00007d0bb21daf9f  vmovaps [rsp+0xD0], xmm14
00007d0bb21dafa8  vmovaps [rsp+0xE0], xmm15
00007d0bb21dafb1  sub rsp, 0x30
00007d0bb21dafb5  movaps [rsp], xmm7
00007d0bb21dafb9  movaps [rsp+0x10], xmm5
00007d0bb21dafbe  movaps [rsp+0x20], xmm15
00007d0bb21dafc4  lea rdi, [rsp]
00007d0bb21dafc8  mov esi, 0x00
00007d0bb21dafcd  mov rax, 0x6392BBE7F530
00007d0bb21dafd7  call rax
00007d0bb21dafd9  movaps xmm7, [rsp]
00007d0bb21dafdd  add rsp, 0x30
00007d0bb21dafe1  vmovaps xmm0, [rsp]
00007d0bb21dafe6  vmovaps xmm1, [rsp+0x10]
00007d0bb21dafec  vmovaps xmm2, [rsp+0x20]
00007d0bb21daff2  vmovaps xmm3, [rsp+0x30]
00007d0bb21daff8  vmovaps xmm4, [rsp+0x40]
00007d0bb21daffe  vmovaps xmm5, [rsp+0x50]
00007d0bb21db004  vmovaps xmm6, [rsp+0x60]
00007d0bb21db00a  vmovaps xmm8, [rsp+0x70]
00007d0bb21db010  vmovaps xmm9, [rsp+0x80]
00007d0bb21db019  vmovaps xmm10, [rsp+0x90]
00007d0bb21db022  vmovaps xmm11, [rsp+0xA0]
00007d0bb21db02b  vmovaps xmm12, [rsp+0xB0]
00007d0bb21db034  vmovaps xmm13, [rsp+0xC0]
00007d0bb21db03d  vmovaps xmm14, [rsp+0xD0]
00007d0bb21db046  vmovaps xmm15, [rsp+0xE0]
00007d0bb21db04f  add rsp, 0xF0
00007d0bb21db056  pop r11
00007d0bb21db058  pop r10
00007d0bb21db05a  pop r9
00007d0bb21db05c  pop r8
00007d0bb21db05e  pop rsi
00007d0bb21db05f  pop rdi
00007d0bb21db060  pop rdx
00007d0bb21db061  pop rcx
00007d0bb21db062  pop rax
00007d0bb21db063  add rsp, 0x08
00007d0bb21db067  jmp 0x00007D0BB21D9093
00007d0bb21db06c  call 0x00007D0BB20D64F0
00007d0bb21db071  jmp 0x00007D0BB21D90A0
00007d0bb21db076  sub rsp, 0x08
00007d0bb21db07a  push rax
00007d0bb21db07b  push rcx
00007d0bb21db07c  push rdx
00007d0bb21db07d  push rdi
00007d0bb21db07e  push rsi
00007d0bb21db07f  push r8
00007d0bb21db081  push r9
00007d0bb21db083  push r10
00007d0bb21db085  push r11
00007d0bb21db087  sub rsp, 0xF0
00007d0bb21db08e  vmovaps [rsp], xmm0
00007d0bb21db093  vmovaps [rsp+0x10], xmm1
00007d0bb21db099  vmovaps [rsp+0x20], xmm2
00007d0bb21db09f  vmovaps [rsp+0x30], xmm3
00007d0bb21db0a5  vmovaps [rsp+0x40], xmm4
00007d0bb21db0ab  vmovaps [rsp+0x50], xmm5
00007d0bb21db0b1  vmovaps [rsp+0x60], xmm6
00007d0bb21db0b7  vmovaps [rsp+0x70], xmm7
00007d0bb21db0bd  vmovaps [rsp+0x80], xmm8
00007d0bb21db0c6  vmovaps [rsp+0x90], xmm9
00007d0bb21db0cf  vmovaps [rsp+0xA0], xmm10
00007d0bb21db0d8  vmovaps [rsp+0xB0], xmm11
00007d0bb21db0e1  vmovaps [rsp+0xC0], xmm12
00007d0bb21db0ea  vmovaps [rsp+0xD0], xmm13
00007d0bb21db0f3  vmovaps [rsp+0xE0], xmm14
00007d0bb21db0fc  sub rsp, 0x30
00007d0bb21db100  movaps [rsp], xmm15
00007d0bb21db105  movaps [rsp+0x10], xmm5
00007d0bb21db10a  movaps [rsp+0x20], xmm3
00007d0bb21db10f  lea rdi, [rsp]
00007d0bb21db113  mov esi, 0x00
00007d0bb21db118  mov rax, 0x6392BBE7F530
00007d0bb21db122  call rax
00007d0bb21db124  movaps xmm15, [rsp]
00007d0bb21db129  add rsp, 0x30
00007d0bb21db12d  vmovaps xmm0, [rsp]
00007d0bb21db132  vmovaps xmm1, [rsp+0x10]
00007d0bb21db138  vmovaps xmm2, [rsp+0x20]
00007d0bb21db13e  vmovaps xmm3, [rsp+0x30]
00007d0bb21db144  vmovaps xmm4, [rsp+0x40]
00007d0bb21db14a  vmovaps xmm5, [rsp+0x50]
00007d0bb21db150  vmovaps xmm6, [rsp+0x60]
00007d0bb21db156  vmovaps xmm7, [rsp+0x70]
00007d0bb21db15c  vmovaps xmm8, [rsp+0x80]
00007d0bb21db165  vmovaps xmm9, [rsp+0x90]
00007d0bb21db16e  vmovaps xmm10, [rsp+0xA0]
00007d0bb21db177  vmovaps xmm11, [rsp+0xB0]
00007d0bb21db180  vmovaps xmm12, [rsp+0xC0]
00007d0bb21db189  vmovaps xmm13, [rsp+0xD0]
00007d0bb21db192  vmovaps xmm14, [rsp+0xE0]
00007d0bb21db19b  add rsp, 0xF0
00007d0bb21db1a2  pop r11
00007d0bb21db1a4  pop r10
00007d0bb21db1a6  pop r9
00007d0bb21db1a8  pop r8
00007d0bb21db1aa  pop rsi
00007d0bb21db1ab  pop rdi
00007d0bb21db1ac  pop rdx
00007d0bb21db1ad  pop rcx
00007d0bb21db1ae  pop rax
00007d0bb21db1af  add rsp, 0x08
00007d0bb21db1b3  jmp 0x00007D0BB21D90C6
00007d0bb21db1b8  sub rsp, 0x08
00007d0bb21db1bc  push rax
00007d0bb21db1bd  push rcx
00007d0bb21db1be  push rdx
00007d0bb21db1bf  push rdi
00007d0bb21db1c0  push rsi
00007d0bb21db1c1  push r8
00007d0bb21db1c3  push r9
00007d0bb21db1c5  push r10
00007d0bb21db1c7  push r11
00007d0bb21db1c9  sub rsp, 0xF0
00007d0bb21db1d0  vmovaps [rsp], xmm0
00007d0bb21db1d5  vmovaps [rsp+0x10], xmm2
00007d0bb21db1db  vmovaps [rsp+0x20], xmm3
00007d0bb21db1e1  vmovaps [rsp+0x30], xmm4
00007d0bb21db1e7  vmovaps [rsp+0x40], xmm5
00007d0bb21db1ed  vmovaps [rsp+0x50], xmm6
00007d0bb21db1f3  vmovaps [rsp+0x60], xmm7
00007d0bb21db1f9  vmovaps [rsp+0x70], xmm8
00007d0bb21db1ff  vmovaps [rsp+0x80], xmm9
00007d0bb21db208  vmovaps [rsp+0x90], xmm10
00007d0bb21db211  vmovaps [rsp+0xA0], xmm11
00007d0bb21db21a  vmovaps [rsp+0xB0], xmm12
00007d0bb21db223  vmovaps [rsp+0xC0], xmm13
00007d0bb21db22c  vmovaps [rsp+0xD0], xmm14
00007d0bb21db235  vmovaps [rsp+0xE0], xmm15
00007d0bb21db23e  sub rsp, 0x30
00007d0bb21db242  movaps [rsp], xmm1
00007d0bb21db246  movaps [rsp+0x10], xmm5
00007d0bb21db24b  movaps [rsp+0x20], xmm4
00007d0bb21db250  lea rdi, [rsp]
00007d0bb21db254  mov esi, 0x00
00007d0bb21db259  mov rax, 0x6392BBE7F530
00007d0bb21db263  call rax
00007d0bb21db265  movaps xmm1, [rsp]
00007d0bb21db269  add rsp, 0x30
00007d0bb21db26d  vmovaps xmm0, [rsp]
00007d0bb21db272  vmovaps xmm2, [rsp+0x10]
00007d0bb21db278  vmovaps xmm3, [rsp+0x20]
00007d0bb21db27e  vmovaps xmm4, [rsp+0x30]
00007d0bb21db284  vmovaps xmm5, [rsp+0x40]
00007d0bb21db28a  vmovaps xmm6, [rsp+0x50]
00007d0bb21db290  vmovaps xmm7, [rsp+0x60]
00007d0bb21db296  vmovaps xmm8, [rsp+0x70]
00007d0bb21db29c  vmovaps xmm9, [rsp+0x80]
00007d0bb21db2a5  vmovaps xmm10, [rsp+0x90]
00007d0bb21db2ae  vmovaps xmm11, [rsp+0xA0]
00007d0bb21db2b7  vmovaps xmm12, [rsp+0xB0]
00007d0bb21db2c0  vmovaps xmm13, [rsp+0xC0]
00007d0bb21db2c9  vmovaps xmm14, [rsp+0xD0]
00007d0bb21db2d2  vmovaps xmm15, [rsp+0xE0]
00007d0bb21db2db  add rsp, 0xF0
00007d0bb21db2e2  pop r11
00007d0bb21db2e4  pop r10
00007d0bb21db2e6  pop r9
00007d0bb21db2e8  pop r8
00007d0bb21db2ea  pop rsi
00007d0bb21db2eb  pop rdi
00007d0bb21db2ec  pop rdx
00007d0bb21db2ed  pop rcx
00007d0bb21db2ee  pop rax
00007d0bb21db2ef  add rsp, 0x08
00007d0bb21db2f3  jmp 0x00007D0BB21D90E6
00007d0bb21db2f8  sub rsp, 0x08
00007d0bb21db2fc  push rax
00007d0bb21db2fd  push rcx
00007d0bb21db2fe  push rdx
00007d0bb21db2ff  push rdi
00007d0bb21db300  push rsi
00007d0bb21db301  push r8
00007d0bb21db303  push r9
00007d0bb21db305  push r10
00007d0bb21db307  push r11
00007d0bb21db309  sub rsp, 0xF0
00007d0bb21db310  vmovaps [rsp], xmm0
00007d0bb21db315  vmovaps [rsp+0x10], xmm1
00007d0bb21db31b  vmovaps [rsp+0x20], xmm2
00007d0bb21db321  vmovaps [rsp+0x30], xmm3
00007d0bb21db327  vmovaps [rsp+0x40], xmm5
00007d0bb21db32d  vmovaps [rsp+0x50], xmm6
00007d0bb21db333  vmovaps [rsp+0x60], xmm7
00007d0bb21db339  vmovaps [rsp+0x70], xmm8
00007d0bb21db33f  vmovaps [rsp+0x80], xmm9
00007d0bb21db348  vmovaps [rsp+0x90], xmm10
00007d0bb21db351  vmovaps [rsp+0xA0], xmm11
00007d0bb21db35a  vmovaps [rsp+0xB0], xmm12
00007d0bb21db363  vmovaps [rsp+0xC0], xmm13
00007d0bb21db36c  vmovaps [rsp+0xD0], xmm14
00007d0bb21db375  vmovaps [rsp+0xE0], xmm15
00007d0bb21db37e  sub rsp, 0x30
00007d0bb21db382  movaps [rsp], xmm4
00007d0bb21db386  movaps [rsp+0x10], xmm3
00007d0bb21db38b  movaps [rsp+0x20], xmm5
00007d0bb21db390  lea rdi, [rsp]
00007d0bb21db394  mov esi, 0x00
00007d0bb21db399  mov rax, 0x6392BBE7F530
00007d0bb21db3a3  call rax
00007d0bb21db3a5  movaps xmm4, [rsp]
00007d0bb21db3a9  add rsp, 0x30
00007d0bb21db3ad  vmovaps xmm0, [rsp]
00007d0bb21db3b2  vmovaps xmm1, [rsp+0x10]
00007d0bb21db3b8  vmovaps xmm2, [rsp+0x20]
00007d0bb21db3be  vmovaps xmm3, [rsp+0x30]
00007d0bb21db3c4  vmovaps xmm5, [rsp+0x40]
00007d0bb21db3ca  vmovaps xmm6, [rsp+0x50]
00007d0bb21db3d0  vmovaps xmm7, [rsp+0x60]
00007d0bb21db3d6  vmovaps xmm8, [rsp+0x70]
00007d0bb21db3dc  vmovaps xmm9, [rsp+0x80]
00007d0bb21db3e5  vmovaps xmm10, [rsp+0x90]
00007d0bb21db3ee  vmovaps xmm11, [rsp+0xA0]
00007d0bb21db3f7  vmovaps xmm12, [rsp+0xB0]
00007d0bb21db400  vmovaps xmm13, [rsp+0xC0]
00007d0bb21db409  vmovaps xmm14, [rsp+0xD0]
00007d0bb21db412  vmovaps xmm15, [rsp+0xE0]
00007d0bb21db41b  add rsp, 0xF0
00007d0bb21db422  pop r11
00007d0bb21db424  pop r10
00007d0bb21db426  pop r9
00007d0bb21db428  pop r8
00007d0bb21db42a  pop rsi
00007d0bb21db42b  pop rdi
00007d0bb21db42c  pop rdx
00007d0bb21db42d  pop rcx
00007d0bb21db42e  pop rax
00007d0bb21db42f  add rsp, 0x08
00007d0bb21db433  jmp 0x00007D0BB21D9134
00007d0bb21db438  call 0x00007D0BB20D64F0
00007d0bb21db43d  jmp 0x00007D0BB21D9141
00007d0bb21db442  sub rsp, 0x08
00007d0bb21db446  push rax
00007d0bb21db447  push rcx
00007d0bb21db448  push rdx
00007d0bb21db449  push rdi
00007d0bb21db44a  push rsi
00007d0bb21db44b  push r8
00007d0bb21db44d  push r9
00007d0bb21db44f  push r10
00007d0bb21db451  push r11
00007d0bb21db453  sub rsp, 0xF0
00007d0bb21db45a  vmovaps [rsp], xmm0
00007d0bb21db45f  vmovaps [rsp+0x10], xmm1
00007d0bb21db465  vmovaps [rsp+0x20], xmm2
00007d0bb21db46b  vmovaps [rsp+0x30], xmm3
00007d0bb21db471  vmovaps [rsp+0x40], xmm4
00007d0bb21db477  vmovaps [rsp+0x50], xmm6
00007d0bb21db47d  vmovaps [rsp+0x60], xmm7
00007d0bb21db483  vmovaps [rsp+0x70], xmm8
00007d0bb21db489  vmovaps [rsp+0x80], xmm9
00007d0bb21db492  vmovaps [rsp+0x90], xmm10
00007d0bb21db49b  vmovaps [rsp+0xA0], xmm11
00007d0bb21db4a4  vmovaps [rsp+0xB0], xmm12
00007d0bb21db4ad  vmovaps [rsp+0xC0], xmm13
00007d0bb21db4b6  vmovaps [rsp+0xD0], xmm14
00007d0bb21db4bf  vmovaps [rsp+0xE0], xmm15
00007d0bb21db4c8  sub rsp, 0x30
00007d0bb21db4cc  movaps [rsp], xmm5
00007d0bb21db4d0  movaps [rsp+0x10], xmm6
00007d0bb21db4d5  movaps [rsp+0x20], xmm3
00007d0bb21db4da  lea rdi, [rsp]
00007d0bb21db4de  mov esi, 0x00
00007d0bb21db4e3  mov rax, 0x6392BBE7F530
00007d0bb21db4ed  call rax
00007d0bb21db4ef  movaps xmm5, [rsp]
00007d0bb21db4f3  add rsp, 0x30
00007d0bb21db4f7  vmovaps xmm0, [rsp]
00007d0bb21db4fc  vmovaps xmm1, [rsp+0x10]
00007d0bb21db502  vmovaps xmm2, [rsp+0x20]
00007d0bb21db508  vmovaps xmm3, [rsp+0x30]
00007d0bb21db50e  vmovaps xmm4, [rsp+0x40]
00007d0bb21db514  vmovaps xmm6, [rsp+0x50]
00007d0bb21db51a  vmovaps xmm7, [rsp+0x60]
00007d0bb21db520  vmovaps xmm8, [rsp+0x70]
00007d0bb21db526  vmovaps xmm9, [rsp+0x80]
00007d0bb21db52f  vmovaps xmm10, [rsp+0x90]
00007d0bb21db538  vmovaps xmm11, [rsp+0xA0]
00007d0bb21db541  vmovaps xmm12, [rsp+0xB0]
00007d0bb21db54a  vmovaps xmm13, [rsp+0xC0]
00007d0bb21db553  vmovaps xmm14, [rsp+0xD0]
00007d0bb21db55c  vmovaps xmm15, [rsp+0xE0]
00007d0bb21db565  add rsp, 0xF0
00007d0bb21db56c  pop r11
00007d0bb21db56e  pop r10
00007d0bb21db570  pop r9
00007d0bb21db572  pop r8
00007d0bb21db574  pop rsi
00007d0bb21db575  pop rdi
00007d0bb21db576  pop rdx
00007d0bb21db577  pop rcx
00007d0bb21db578  pop rax
00007d0bb21db579  add rsp, 0x08
00007d0bb21db57d  jmp 0x00007D0BB21D9167
00007d0bb21db582  sub rsp, 0x08
00007d0bb21db586  push rax
00007d0bb21db587  push rcx
00007d0bb21db588  push rdx
00007d0bb21db589  push rdi
00007d0bb21db58a  push rsi
00007d0bb21db58b  push r8
00007d0bb21db58d  push r9
00007d0bb21db58f  push r10
00007d0bb21db591  push r11
00007d0bb21db593  sub rsp, 0xF0
00007d0bb21db59a  vmovaps [rsp], xmm0
00007d0bb21db59f  vmovaps [rsp+0x10], xmm1
00007d0bb21db5a5  vmovaps [rsp+0x20], xmm2
00007d0bb21db5ab  vmovaps [rsp+0x30], xmm3
00007d0bb21db5b1  vmovaps [rsp+0x40], xmm4
00007d0bb21db5b7  vmovaps [rsp+0x50], xmm5
00007d0bb21db5bd  vmovaps [rsp+0x60], xmm7
00007d0bb21db5c3  vmovaps [rsp+0x70], xmm8
00007d0bb21db5c9  vmovaps [rsp+0x80], xmm9
00007d0bb21db5d2  vmovaps [rsp+0x90], xmm10
00007d0bb21db5db  vmovaps [rsp+0xA0], xmm11
00007d0bb21db5e4  vmovaps [rsp+0xB0], xmm12
00007d0bb21db5ed  vmovaps [rsp+0xC0], xmm13
00007d0bb21db5f6  vmovaps [rsp+0xD0], xmm14
00007d0bb21db5ff  vmovaps [rsp+0xE0], xmm15
00007d0bb21db608  sub rsp, 0x30
00007d0bb21db60c  movaps [rsp], xmm6
00007d0bb21db610  movaps [rsp+0x10], xmm9
00007d0bb21db616  movaps [rsp+0x20], xmm1
00007d0bb21db61b  lea rdi, [rsp]
00007d0bb21db61f  mov esi, 0x00
00007d0bb21db624  mov rax, 0x6392BBE7F530
00007d0bb21db62e  call rax
00007d0bb21db630  movaps xmm6, [rsp]
00007d0bb21db634  add rsp, 0x30
00007d0bb21db638  vmovaps xmm0, [rsp]
00007d0bb21db63d  vmovaps xmm1, [rsp+0x10]
00007d0bb21db643  vmovaps xmm2, [rsp+0x20]
00007d0bb21db649  vmovaps xmm3, [rsp+0x30]
00007d0bb21db64f  vmovaps xmm4, [rsp+0x40]
00007d0bb21db655  vmovaps xmm5, [rsp+0x50]
00007d0bb21db65b  vmovaps xmm7, [rsp+0x60]
00007d0bb21db661  vmovaps xmm8, [rsp+0x70]
00007d0bb21db667  vmovaps xmm9, [rsp+0x80]
00007d0bb21db670  vmovaps xmm10, [rsp+0x90]
00007d0bb21db679  vmovaps xmm11, [rsp+0xA0]
00007d0bb21db682  vmovaps xmm12, [rsp+0xB0]
00007d0bb21db68b  vmovaps xmm13, [rsp+0xC0]
00007d0bb21db694  vmovaps xmm14, [rsp+0xD0]
00007d0bb21db69d  vmovaps xmm15, [rsp+0xE0]
00007d0bb21db6a6  add rsp, 0xF0
00007d0bb21db6ad  pop r11
00007d0bb21db6af  pop r10
00007d0bb21db6b1  pop r9
00007d0bb21db6b3  pop r8
00007d0bb21db6b5  pop rsi
00007d0bb21db6b6  pop rdi
00007d0bb21db6b7  pop rdx
00007d0bb21db6b8  pop rcx
00007d0bb21db6b9  pop rax
00007d0bb21db6ba  add rsp, 0x08
00007d0bb21db6be  jmp 0x00007D0BB21D918B
00007d0bb21db6c3  sub rsp, 0x08
00007d0bb21db6c7  push rax
00007d0bb21db6c8  push rcx
00007d0bb21db6c9  push rdx
00007d0bb21db6ca  push rdi
00007d0bb21db6cb  push rsi
00007d0bb21db6cc  push r8
00007d0bb21db6ce  push r9
00007d0bb21db6d0  push r10
00007d0bb21db6d2  push r11
00007d0bb21db6d4  sub rsp, 0xF0
00007d0bb21db6db  vmovaps [rsp], xmm0
00007d0bb21db6e0  vmovaps [rsp+0x10], xmm1
00007d0bb21db6e6  vmovaps [rsp+0x20], xmm2
00007d0bb21db6ec  vmovaps [rsp+0x30], xmm3
00007d0bb21db6f2  vmovaps [rsp+0x40], xmm4
00007d0bb21db6f8  vmovaps [rsp+0x50], xmm5
00007d0bb21db6fe  vmovaps [rsp+0x60], xmm6
00007d0bb21db704  vmovaps [rsp+0x70], xmm7
00007d0bb21db70a  vmovaps [rsp+0x80], xmm8
00007d0bb21db713  vmovaps [rsp+0x90], xmm10
00007d0bb21db71c  vmovaps [rsp+0xA0], xmm11
00007d0bb21db725  vmovaps [rsp+0xB0], xmm12
00007d0bb21db72e  vmovaps [rsp+0xC0], xmm13
00007d0bb21db737  vmovaps [rsp+0xD0], xmm14
00007d0bb21db740  vmovaps [rsp+0xE0], xmm15
00007d0bb21db749  sub rsp, 0x30
00007d0bb21db74d  movaps [rsp], xmm9
00007d0bb21db752  movaps [rsp+0x10], xmm3
00007d0bb21db757  movaps [rsp+0x20], xmm1
00007d0bb21db75c  lea rdi, [rsp]
00007d0bb21db760  mov esi, 0x00
00007d0bb21db765  mov rax, 0x6392BBE7F530
00007d0bb21db76f  call rax
00007d0bb21db771  movaps xmm9, [rsp]
00007d0bb21db776  add rsp, 0x30
00007d0bb21db77a  vmovaps xmm0, [rsp]
00007d0bb21db77f  vmovaps xmm1, [rsp+0x10]
00007d0bb21db785  vmovaps xmm2, [rsp+0x20]
00007d0bb21db78b  vmovaps xmm3, [rsp+0x30]
00007d0bb21db791  vmovaps xmm4, [rsp+0x40]
00007d0bb21db797  vmovaps xmm5, [rsp+0x50]
00007d0bb21db79d  vmovaps xmm6, [rsp+0x60]
00007d0bb21db7a3  vmovaps xmm7, [rsp+0x70]
00007d0bb21db7a9  vmovaps xmm8, [rsp+0x80]
00007d0bb21db7b2  vmovaps xmm10, [rsp+0x90]
00007d0bb21db7bb  vmovaps xmm11, [rsp+0xA0]
00007d0bb21db7c4  vmovaps xmm12, [rsp+0xB0]
00007d0bb21db7cd  vmovaps xmm13, [rsp+0xC0]
00007d0bb21db7d6  vmovaps xmm14, [rsp+0xD0]
00007d0bb21db7df  vmovaps xmm15, [rsp+0xE0]
00007d0bb21db7e8  add rsp, 0xF0
00007d0bb21db7ef  pop r11
00007d0bb21db7f1  pop r10
00007d0bb21db7f3  pop r9
00007d0bb21db7f5  pop r8
00007d0bb21db7f7  pop rsi
00007d0bb21db7f8  pop rdi
00007d0bb21db7f9  pop rdx
00007d0bb21db7fa  pop rcx
00007d0bb21db7fb  pop rax
00007d0bb21db7fc  add rsp, 0x08
00007d0bb21db800  jmp 0x00007D0BB21D91D7
00007d0bb21db805  call 0x00007D0BB20D64F0
00007d0bb21db80a  jmp 0x00007D0BB21D91E4
00007d0bb21db80f  sub rsp, 0x08
00007d0bb21db813  push rax
00007d0bb21db814  push rcx
00007d0bb21db815  push rdx
00007d0bb21db816  push rdi
00007d0bb21db817  push rsi
00007d0bb21db818  push r8
00007d0bb21db81a  push r9
00007d0bb21db81c  push r10
00007d0bb21db81e  push r11
00007d0bb21db820  sub rsp, 0xF0
00007d0bb21db827  vmovaps [rsp], xmm0
00007d0bb21db82c  vmovaps [rsp+0x10], xmm1
00007d0bb21db832  vmovaps [rsp+0x20], xmm2
00007d0bb21db838  vmovaps [rsp+0x30], xmm3
00007d0bb21db83e  vmovaps [rsp+0x40], xmm4
00007d0bb21db844  vmovaps [rsp+0x50], xmm5
00007d0bb21db84a  vmovaps [rsp+0x60], xmm6
00007d0bb21db850  vmovaps [rsp+0x70], xmm7
00007d0bb21db856  vmovaps [rsp+0x80], xmm8
00007d0bb21db85f  vmovaps [rsp+0x90], xmm9
00007d0bb21db868  vmovaps [rsp+0xA0], xmm10
00007d0bb21db871  vmovaps [rsp+0xB0], xmm11
00007d0bb21db87a  vmovaps [rsp+0xC0], xmm12
00007d0bb21db883  vmovaps [rsp+0xD0], xmm13
00007d0bb21db88c  vmovaps [rsp+0xE0], xmm14
00007d0bb21db895  sub rsp, 0x30
00007d0bb21db899  movaps [rsp], xmm15
00007d0bb21db89e  movaps [rsp+0x10], xmm3
00007d0bb21db8a3  movaps [rsp+0x20], xmm7
00007d0bb21db8a8  lea rdi, [rsp]
00007d0bb21db8ac  mov esi, 0x00
00007d0bb21db8b1  mov rax, 0x6392BBE7F530
00007d0bb21db8bb  call rax
00007d0bb21db8bd  movaps xmm15, [rsp]
00007d0bb21db8c2  add rsp, 0x30
00007d0bb21db8c6  vmovaps xmm0, [rsp]
00007d0bb21db8cb  vmovaps xmm1, [rsp+0x10]
00007d0bb21db8d1  vmovaps xmm2, [rsp+0x20]
00007d0bb21db8d7  vmovaps xmm3, [rsp+0x30]
00007d0bb21db8dd  vmovaps xmm4, [rsp+0x40]
00007d0bb21db8e3  vmovaps xmm5, [rsp+0x50]
00007d0bb21db8e9  vmovaps xmm6, [rsp+0x60]
00007d0bb21db8ef  vmovaps xmm7, [rsp+0x70]
00007d0bb21db8f5  vmovaps xmm8, [rsp+0x80]
00007d0bb21db8fe  vmovaps xmm9, [rsp+0x90]
00007d0bb21db907  vmovaps xmm10, [rsp+0xA0]
00007d0bb21db910  vmovaps xmm11, [rsp+0xB0]
00007d0bb21db919  vmovaps xmm12, [rsp+0xC0]
00007d0bb21db922  vmovaps xmm13, [rsp+0xD0]
00007d0bb21db92b  vmovaps xmm14, [rsp+0xE0]
00007d0bb21db934  add rsp, 0xF0
00007d0bb21db93b  pop r11
00007d0bb21db93d  pop r10
00007d0bb21db93f  pop r9
00007d0bb21db941  pop r8
00007d0bb21db943  pop rsi
00007d0bb21db944  pop rdi
00007d0bb21db945  pop rdx
00007d0bb21db946  pop rcx
00007d0bb21db947  pop rax
00007d0bb21db948  add rsp, 0x08
00007d0bb21db94c  jmp 0x00007D0BB21D9210
00007d0bb21db951  sub rsp, 0x08
00007d0bb21db955  push rax
00007d0bb21db956  push rcx
00007d0bb21db957  push rdx
00007d0bb21db958  push rdi
00007d0bb21db959  push rsi
00007d0bb21db95a  push r8
00007d0bb21db95c  push r9
00007d0bb21db95e  push r10
00007d0bb21db960  push r11
00007d0bb21db962  sub rsp, 0xF0
00007d0bb21db969  vmovaps [rsp], xmm0
00007d0bb21db96e  vmovaps [rsp+0x10], xmm1
00007d0bb21db974  vmovaps [rsp+0x20], xmm2
00007d0bb21db97a  vmovaps [rsp+0x30], xmm4
00007d0bb21db980  vmovaps [rsp+0x40], xmm5
00007d0bb21db986  vmovaps [rsp+0x50], xmm6
00007d0bb21db98c  vmovaps [rsp+0x60], xmm7
00007d0bb21db992  vmovaps [rsp+0x70], xmm8
00007d0bb21db998  vmovaps [rsp+0x80], xmm9
00007d0bb21db9a1  vmovaps [rsp+0x90], xmm10
00007d0bb21db9aa  vmovaps [rsp+0xA0], xmm11
00007d0bb21db9b3  vmovaps [rsp+0xB0], xmm12
00007d0bb21db9bc  vmovaps [rsp+0xC0], xmm13
00007d0bb21db9c5  vmovaps [rsp+0xD0], xmm14
00007d0bb21db9ce  vmovaps [rsp+0xE0], xmm15
00007d0bb21db9d7  sub rsp, 0x30
00007d0bb21db9db  movaps [rsp], xmm3
00007d0bb21db9df  movaps [rsp+0x10], xmm1
00007d0bb21db9e4  movaps [rsp+0x20], xmm15
00007d0bb21db9ea  lea rdi, [rsp]
00007d0bb21db9ee  mov esi, 0x00
00007d0bb21db9f3  mov rax, 0x6392BBE7F530
00007d0bb21db9fd  call rax
00007d0bb21db9ff  movaps xmm3, [rsp]
00007d0bb21dba03  add rsp, 0x30
00007d0bb21dba07  vmovaps xmm0, [rsp]
00007d0bb21dba0c  vmovaps xmm1, [rsp+0x10]
00007d0bb21dba12  vmovaps xmm2, [rsp+0x20]
00007d0bb21dba18  vmovaps xmm4, [rsp+0x30]
00007d0bb21dba1e  vmovaps xmm5, [rsp+0x40]
00007d0bb21dba24  vmovaps xmm6, [rsp+0x50]
00007d0bb21dba2a  vmovaps xmm7, [rsp+0x60]
00007d0bb21dba30  vmovaps xmm8, [rsp+0x70]
00007d0bb21dba36  vmovaps xmm9, [rsp+0x80]
00007d0bb21dba3f  vmovaps xmm10, [rsp+0x90]
00007d0bb21dba48  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dba51  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dba5a  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dba63  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dba6c  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dba75  add rsp, 0xF0
00007d0bb21dba7c  pop r11
00007d0bb21dba7e  pop r10
00007d0bb21dba80  pop r9
00007d0bb21dba82  pop r8
00007d0bb21dba84  pop rsi
00007d0bb21dba85  pop rdi
00007d0bb21dba86  pop rdx
00007d0bb21dba87  pop rcx
00007d0bb21dba88  pop rax
00007d0bb21dba89  add rsp, 0x08
00007d0bb21dba8d  jmp 0x00007D0BB21D929F
00007d0bb21dba92  call 0x00007D0BB20D64F0
00007d0bb21dba97  jmp 0x00007D0BB21D92A9
00007d0bb21dba9c  sub rsp, 0x08
00007d0bb21dbaa0  push rax
00007d0bb21dbaa1  push rcx
00007d0bb21dbaa2  push rdx
00007d0bb21dbaa3  push rdi
00007d0bb21dbaa4  push rsi
00007d0bb21dbaa5  push r8
00007d0bb21dbaa7  push r9
00007d0bb21dbaa9  push r10
00007d0bb21dbaab  push r11
00007d0bb21dbaad  sub rsp, 0xF0
00007d0bb21dbab4  vmovaps [rsp], xmm0
00007d0bb21dbab9  vmovaps [rsp+0x10], xmm1
00007d0bb21dbabf  vmovaps [rsp+0x20], xmm2
00007d0bb21dbac5  vmovaps [rsp+0x30], xmm3
00007d0bb21dbacb  vmovaps [rsp+0x40], xmm4
00007d0bb21dbad1  vmovaps [rsp+0x50], xmm5
00007d0bb21dbad7  vmovaps [rsp+0x60], xmm6
00007d0bb21dbadd  vmovaps [rsp+0x70], xmm7
00007d0bb21dbae3  vmovaps [rsp+0x80], xmm8
00007d0bb21dbaec  vmovaps [rsp+0x90], xmm9
00007d0bb21dbaf5  vmovaps [rsp+0xA0], xmm10
00007d0bb21dbafe  vmovaps [rsp+0xB0], xmm11
00007d0bb21dbb07  vmovaps [rsp+0xC0], xmm12
00007d0bb21dbb10  vmovaps [rsp+0xD0], xmm13
00007d0bb21dbb19  vmovaps [rsp+0xE0], xmm14
00007d0bb21dbb22  sub rsp, 0x30
00007d0bb21dbb26  movaps [rsp], xmm15
00007d0bb21dbb2b  movaps [rsp+0x10], xmm14
00007d0bb21dbb31  movaps [rsp+0x20], xmm4
00007d0bb21dbb36  lea rdi, [rsp]
00007d0bb21dbb3a  mov esi, 0x00
00007d0bb21dbb3f  mov rax, 0x6392BBE7F530
00007d0bb21dbb49  call rax
00007d0bb21dbb4b  movaps xmm15, [rsp]
00007d0bb21dbb50  add rsp, 0x30
00007d0bb21dbb54  vmovaps xmm0, [rsp]
00007d0bb21dbb59  vmovaps xmm1, [rsp+0x10]
00007d0bb21dbb5f  vmovaps xmm2, [rsp+0x20]
00007d0bb21dbb65  vmovaps xmm3, [rsp+0x30]
00007d0bb21dbb6b  vmovaps xmm4, [rsp+0x40]
00007d0bb21dbb71  vmovaps xmm5, [rsp+0x50]
00007d0bb21dbb77  vmovaps xmm6, [rsp+0x60]
00007d0bb21dbb7d  vmovaps xmm7, [rsp+0x70]
00007d0bb21dbb83  vmovaps xmm8, [rsp+0x80]
00007d0bb21dbb8c  vmovaps xmm9, [rsp+0x90]
00007d0bb21dbb95  vmovaps xmm10, [rsp+0xA0]
00007d0bb21dbb9e  vmovaps xmm11, [rsp+0xB0]
00007d0bb21dbba7  vmovaps xmm12, [rsp+0xC0]
00007d0bb21dbbb0  vmovaps xmm13, [rsp+0xD0]
00007d0bb21dbbb9  vmovaps xmm14, [rsp+0xE0]
00007d0bb21dbbc2  add rsp, 0xF0
00007d0bb21dbbc9  pop r11
00007d0bb21dbbcb  pop r10
00007d0bb21dbbcd  pop r9
00007d0bb21dbbcf  pop r8
00007d0bb21dbbd1  pop rsi
00007d0bb21dbbd2  pop rdi
00007d0bb21dbbd3  pop rdx
00007d0bb21dbbd4  pop rcx
00007d0bb21dbbd5  pop rax
00007d0bb21dbbd6  add rsp, 0x08
00007d0bb21dbbda  jmp 0x00007D0BB21D92D7
00007d0bb21dbbdf  sub rsp, 0x08
00007d0bb21dbbe3  push rax
00007d0bb21dbbe4  push rcx
00007d0bb21dbbe5  push rdx
00007d0bb21dbbe6  push rdi
00007d0bb21dbbe7  push rsi
00007d0bb21dbbe8  push r8
00007d0bb21dbbea  push r9
00007d0bb21dbbec  push r10
00007d0bb21dbbee  push r11
00007d0bb21dbbf0  sub rsp, 0xF0
00007d0bb21dbbf7  vmovaps [rsp], xmm0
00007d0bb21dbbfc  vmovaps [rsp+0x10], xmm1
00007d0bb21dbc02  vmovaps [rsp+0x20], xmm2
00007d0bb21dbc08  vmovaps [rsp+0x30], xmm3
00007d0bb21dbc0e  vmovaps [rsp+0x40], xmm4
00007d0bb21dbc14  vmovaps [rsp+0x50], xmm5
00007d0bb21dbc1a  vmovaps [rsp+0x60], xmm6
00007d0bb21dbc20  vmovaps [rsp+0x70], xmm7
00007d0bb21dbc26  vmovaps [rsp+0x80], xmm8
00007d0bb21dbc2f  vmovaps [rsp+0x90], xmm9
00007d0bb21dbc38  vmovaps [rsp+0xA0], xmm10
00007d0bb21dbc41  vmovaps [rsp+0xB0], xmm11
00007d0bb21dbc4a  vmovaps [rsp+0xC0], xmm12
00007d0bb21dbc53  vmovaps [rsp+0xD0], xmm13
00007d0bb21dbc5c  vmovaps [rsp+0xE0], xmm15
00007d0bb21dbc65  sub rsp, 0x30
00007d0bb21dbc69  movaps [rsp], xmm14
00007d0bb21dbc6e  movaps [rsp+0x10], xmm2
00007d0bb21dbc73  movaps [rsp+0x20], xmm1
00007d0bb21dbc78  lea rdi, [rsp]
00007d0bb21dbc7c  mov esi, 0x00
00007d0bb21dbc81  mov rax, 0x6392BBE7F530
00007d0bb21dbc8b  call rax
00007d0bb21dbc8d  movaps xmm14, [rsp]
00007d0bb21dbc92  add rsp, 0x30
00007d0bb21dbc96  vmovaps xmm0, [rsp]
00007d0bb21dbc9b  vmovaps xmm1, [rsp+0x10]
00007d0bb21dbca1  vmovaps xmm2, [rsp+0x20]
00007d0bb21dbca7  vmovaps xmm3, [rsp+0x30]
00007d0bb21dbcad  vmovaps xmm4, [rsp+0x40]
00007d0bb21dbcb3  vmovaps xmm5, [rsp+0x50]
00007d0bb21dbcb9  vmovaps xmm6, [rsp+0x60]
00007d0bb21dbcbf  vmovaps xmm7, [rsp+0x70]
00007d0bb21dbcc5  vmovaps xmm8, [rsp+0x80]
00007d0bb21dbcce  vmovaps xmm9, [rsp+0x90]
00007d0bb21dbcd7  vmovaps xmm10, [rsp+0xA0]
00007d0bb21dbce0  vmovaps xmm11, [rsp+0xB0]
00007d0bb21dbce9  vmovaps xmm12, [rsp+0xC0]
00007d0bb21dbcf2  vmovaps xmm13, [rsp+0xD0]
00007d0bb21dbcfb  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dbd04  add rsp, 0xF0
00007d0bb21dbd0b  pop r11
00007d0bb21dbd0d  pop r10
00007d0bb21dbd0f  pop r9
00007d0bb21dbd11  pop r8
00007d0bb21dbd13  pop rsi
00007d0bb21dbd14  pop rdi
00007d0bb21dbd15  pop rdx
00007d0bb21dbd16  pop rcx
00007d0bb21dbd17  pop rax
00007d0bb21dbd18  add rsp, 0x08
00007d0bb21dbd1c  jmp 0x00007D0BB21D92FD
00007d0bb21dbd21  sub rsp, 0x08
00007d0bb21dbd25  push rax
00007d0bb21dbd26  push rcx
00007d0bb21dbd27  push rdx
00007d0bb21dbd28  push rdi
00007d0bb21dbd29  push rsi
00007d0bb21dbd2a  push r8
00007d0bb21dbd2c  push r9
00007d0bb21dbd2e  push r10
00007d0bb21dbd30  push r11
00007d0bb21dbd32  sub rsp, 0xF0
00007d0bb21dbd39  vmovaps [rsp], xmm0
00007d0bb21dbd3e  vmovaps [rsp+0x10], xmm2
00007d0bb21dbd44  vmovaps [rsp+0x20], xmm3
00007d0bb21dbd4a  vmovaps [rsp+0x30], xmm4
00007d0bb21dbd50  vmovaps [rsp+0x40], xmm5
00007d0bb21dbd56  vmovaps [rsp+0x50], xmm6
00007d0bb21dbd5c  vmovaps [rsp+0x60], xmm7
00007d0bb21dbd62  vmovaps [rsp+0x70], xmm8
00007d0bb21dbd68  vmovaps [rsp+0x80], xmm9
00007d0bb21dbd71  vmovaps [rsp+0x90], xmm10
00007d0bb21dbd7a  vmovaps [rsp+0xA0], xmm11
00007d0bb21dbd83  vmovaps [rsp+0xB0], xmm12
00007d0bb21dbd8c  vmovaps [rsp+0xC0], xmm13
00007d0bb21dbd95  vmovaps [rsp+0xD0], xmm14
00007d0bb21dbd9e  vmovaps [rsp+0xE0], xmm15
00007d0bb21dbda7  sub rsp, 0x30
00007d0bb21dbdab  movaps [rsp], xmm1
00007d0bb21dbdaf  movaps [rsp+0x10], xmm4
00007d0bb21dbdb4  movaps [rsp+0x20], xmm9
00007d0bb21dbdba  lea rdi, [rsp]
00007d0bb21dbdbe  mov esi, 0x00
00007d0bb21dbdc3  mov rax, 0x6392BBE7F530
00007d0bb21dbdcd  call rax
00007d0bb21dbdcf  movaps xmm1, [rsp]
00007d0bb21dbdd3  add rsp, 0x30
00007d0bb21dbdd7  vmovaps xmm0, [rsp]
00007d0bb21dbddc  vmovaps xmm2, [rsp+0x10]
00007d0bb21dbde2  vmovaps xmm3, [rsp+0x20]
00007d0bb21dbde8  vmovaps xmm4, [rsp+0x30]
00007d0bb21dbdee  vmovaps xmm5, [rsp+0x40]
00007d0bb21dbdf4  vmovaps xmm6, [rsp+0x50]
00007d0bb21dbdfa  vmovaps xmm7, [rsp+0x60]
00007d0bb21dbe00  vmovaps xmm8, [rsp+0x70]
00007d0bb21dbe06  vmovaps xmm9, [rsp+0x80]
00007d0bb21dbe0f  vmovaps xmm10, [rsp+0x90]
00007d0bb21dbe18  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dbe21  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dbe2a  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dbe33  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dbe3c  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dbe45  add rsp, 0xF0
00007d0bb21dbe4c  pop r11
00007d0bb21dbe4e  pop r10
00007d0bb21dbe50  pop r9
00007d0bb21dbe52  pop r8
00007d0bb21dbe54  pop rsi
00007d0bb21dbe55  pop rdi
00007d0bb21dbe56  pop rdx
00007d0bb21dbe57  pop rcx
00007d0bb21dbe58  pop rax
00007d0bb21dbe59  add rsp, 0x08
00007d0bb21dbe5d  jmp 0x00007D0BB21D931B
00007d0bb21dbe62  sub rsp, 0x08
00007d0bb21dbe66  push rax
00007d0bb21dbe67  push rcx
00007d0bb21dbe68  push rdx
00007d0bb21dbe69  push rdi
00007d0bb21dbe6a  push rsi
00007d0bb21dbe6b  push r8
00007d0bb21dbe6d  push r9
00007d0bb21dbe6f  push r10
00007d0bb21dbe71  push r11
00007d0bb21dbe73  sub rsp, 0xF0
00007d0bb21dbe7a  vmovaps [rsp], xmm0
00007d0bb21dbe7f  vmovaps [rsp+0x10], xmm1
00007d0bb21dbe85  vmovaps [rsp+0x20], xmm2
00007d0bb21dbe8b  vmovaps [rsp+0x30], xmm3
00007d0bb21dbe91  vmovaps [rsp+0x40], xmm5
00007d0bb21dbe97  vmovaps [rsp+0x50], xmm6
00007d0bb21dbe9d  vmovaps [rsp+0x60], xmm7
00007d0bb21dbea3  vmovaps [rsp+0x70], xmm8
00007d0bb21dbea9  vmovaps [rsp+0x80], xmm9
00007d0bb21dbeb2  vmovaps [rsp+0x90], xmm10
00007d0bb21dbebb  vmovaps [rsp+0xA0], xmm11
00007d0bb21dbec4  vmovaps [rsp+0xB0], xmm12
00007d0bb21dbecd  vmovaps [rsp+0xC0], xmm13
00007d0bb21dbed6  vmovaps [rsp+0xD0], xmm14
00007d0bb21dbedf  vmovaps [rsp+0xE0], xmm15
00007d0bb21dbee8  sub rsp, 0x30
00007d0bb21dbeec  movaps [rsp], xmm4
00007d0bb21dbef0  movaps [rsp+0x10], xmm2
00007d0bb21dbef5  movaps [rsp+0x20], xmm9
00007d0bb21dbefb  lea rdi, [rsp]
00007d0bb21dbeff  mov esi, 0x00
00007d0bb21dbf04  mov rax, 0x6392BBE7F530
00007d0bb21dbf0e  call rax
00007d0bb21dbf10  movaps xmm4, [rsp]
00007d0bb21dbf14  add rsp, 0x30
00007d0bb21dbf18  vmovaps xmm0, [rsp]
00007d0bb21dbf1d  vmovaps xmm1, [rsp+0x10]
00007d0bb21dbf23  vmovaps xmm2, [rsp+0x20]
00007d0bb21dbf29  vmovaps xmm3, [rsp+0x30]
00007d0bb21dbf2f  vmovaps xmm5, [rsp+0x40]
00007d0bb21dbf35  vmovaps xmm6, [rsp+0x50]
00007d0bb21dbf3b  vmovaps xmm7, [rsp+0x60]
00007d0bb21dbf41  vmovaps xmm8, [rsp+0x70]
00007d0bb21dbf47  vmovaps xmm9, [rsp+0x80]
00007d0bb21dbf50  vmovaps xmm10, [rsp+0x90]
00007d0bb21dbf59  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dbf62  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dbf6b  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dbf74  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dbf7d  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dbf86  add rsp, 0xF0
00007d0bb21dbf8d  pop r11
00007d0bb21dbf8f  pop r10
00007d0bb21dbf91  pop r9
00007d0bb21dbf93  pop r8
00007d0bb21dbf95  pop rsi
00007d0bb21dbf96  pop rdi
00007d0bb21dbf97  pop rdx
00007d0bb21dbf98  pop rcx
00007d0bb21dbf99  pop rax
00007d0bb21dbf9a  add rsp, 0x08
00007d0bb21dbf9e  jmp 0x00007D0BB21D934B
00007d0bb21dbfa3  sub rsp, 0x08
00007d0bb21dbfa7  push rax
00007d0bb21dbfa8  push rcx
00007d0bb21dbfa9  push rdx
00007d0bb21dbfaa  push rdi
00007d0bb21dbfab  push rsi
00007d0bb21dbfac  push r8
00007d0bb21dbfae  push r9
00007d0bb21dbfb0  push r10
00007d0bb21dbfb2  push r11
00007d0bb21dbfb4  sub rsp, 0xF0
00007d0bb21dbfbb  vmovaps [rsp], xmm0
00007d0bb21dbfc0  vmovaps [rsp+0x10], xmm1
00007d0bb21dbfc6  vmovaps [rsp+0x20], xmm2
00007d0bb21dbfcc  vmovaps [rsp+0x30], xmm3
00007d0bb21dbfd2  vmovaps [rsp+0x40], xmm4
00007d0bb21dbfd8  vmovaps [rsp+0x50], xmm5
00007d0bb21dbfde  vmovaps [rsp+0x60], xmm6
00007d0bb21dbfe4  vmovaps [rsp+0x70], xmm7
00007d0bb21dbfea  vmovaps [rsp+0x80], xmm8
00007d0bb21dbff3  vmovaps [rsp+0x90], xmm10
00007d0bb21dbffc  vmovaps [rsp+0xA0], xmm11
00007d0bb21dc005  vmovaps [rsp+0xB0], xmm12
00007d0bb21dc00e  vmovaps [rsp+0xC0], xmm13
00007d0bb21dc017  vmovaps [rsp+0xD0], xmm14
00007d0bb21dc020  vmovaps [rsp+0xE0], xmm15
00007d0bb21dc029  sub rsp, 0x30
00007d0bb21dc02d  movaps [rsp], xmm9
00007d0bb21dc032  movaps [rsp+0x10], xmm2
00007d0bb21dc037  movaps [rsp+0x20], xmm1
00007d0bb21dc03c  lea rdi, [rsp]
00007d0bb21dc040  mov esi, 0x00
00007d0bb21dc045  mov rax, 0x6392BBE7F530
00007d0bb21dc04f  call rax
00007d0bb21dc051  movaps xmm9, [rsp]
00007d0bb21dc056  add rsp, 0x30
00007d0bb21dc05a  vmovaps xmm0, [rsp]
00007d0bb21dc05f  vmovaps xmm1, [rsp+0x10]
00007d0bb21dc065  vmovaps xmm2, [rsp+0x20]
00007d0bb21dc06b  vmovaps xmm3, [rsp+0x30]
00007d0bb21dc071  vmovaps xmm4, [rsp+0x40]
00007d0bb21dc077  vmovaps xmm5, [rsp+0x50]
00007d0bb21dc07d  vmovaps xmm6, [rsp+0x60]
00007d0bb21dc083  vmovaps xmm7, [rsp+0x70]
00007d0bb21dc089  vmovaps xmm8, [rsp+0x80]
00007d0bb21dc092  vmovaps xmm10, [rsp+0x90]
00007d0bb21dc09b  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dc0a4  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dc0ad  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dc0b6  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dc0bf  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dc0c8  add rsp, 0xF0
00007d0bb21dc0cf  pop r11
00007d0bb21dc0d1  pop r10
00007d0bb21dc0d3  pop r9
00007d0bb21dc0d5  pop r8
00007d0bb21dc0d7  pop rsi
00007d0bb21dc0d8  pop rdi
00007d0bb21dc0d9  pop rdx
00007d0bb21dc0da  pop rcx
00007d0bb21dc0db  pop rax
00007d0bb21dc0dc  add rsp, 0x08
00007d0bb21dc0e0  jmp 0x00007D0BB21D9381
00007d0bb21dc0e5  sub rsp, 0x08
00007d0bb21dc0e9  push rax
00007d0bb21dc0ea  push rcx
00007d0bb21dc0eb  push rdx
00007d0bb21dc0ec  push rdi
00007d0bb21dc0ed  push rsi
00007d0bb21dc0ee  push r8
00007d0bb21dc0f0  push r9
00007d0bb21dc0f2  push r10
00007d0bb21dc0f4  push r11
00007d0bb21dc0f6  sub rsp, 0xF0
00007d0bb21dc0fd  vmovaps [rsp], xmm0
00007d0bb21dc102  vmovaps [rsp+0x10], xmm2
00007d0bb21dc108  vmovaps [rsp+0x20], xmm3
00007d0bb21dc10e  vmovaps [rsp+0x30], xmm4
00007d0bb21dc114  vmovaps [rsp+0x40], xmm5
00007d0bb21dc11a  vmovaps [rsp+0x50], xmm6
00007d0bb21dc120  vmovaps [rsp+0x60], xmm7
00007d0bb21dc126  vmovaps [rsp+0x70], xmm8
00007d0bb21dc12c  vmovaps [rsp+0x80], xmm9
00007d0bb21dc135  vmovaps [rsp+0x90], xmm10
00007d0bb21dc13e  vmovaps [rsp+0xA0], xmm11
00007d0bb21dc147  vmovaps [rsp+0xB0], xmm12
00007d0bb21dc150  vmovaps [rsp+0xC0], xmm13
00007d0bb21dc159  vmovaps [rsp+0xD0], xmm14
00007d0bb21dc162  vmovaps [rsp+0xE0], xmm15
00007d0bb21dc16b  sub rsp, 0x30
00007d0bb21dc16f  movaps [rsp], xmm1
00007d0bb21dc173  movaps [rsp+0x10], xmm15
00007d0bb21dc179  movaps [rsp+0x20], xmm6
00007d0bb21dc17e  lea rdi, [rsp]
00007d0bb21dc182  mov esi, 0x00
00007d0bb21dc187  mov rax, 0x6392BBE7F530
00007d0bb21dc191  call rax
00007d0bb21dc193  movaps xmm1, [rsp]
00007d0bb21dc197  add rsp, 0x30
00007d0bb21dc19b  vmovaps xmm0, [rsp]
00007d0bb21dc1a0  vmovaps xmm2, [rsp+0x10]
00007d0bb21dc1a6  vmovaps xmm3, [rsp+0x20]
00007d0bb21dc1ac  vmovaps xmm4, [rsp+0x30]
00007d0bb21dc1b2  vmovaps xmm5, [rsp+0x40]
00007d0bb21dc1b8  vmovaps xmm6, [rsp+0x50]
00007d0bb21dc1be  vmovaps xmm7, [rsp+0x60]
00007d0bb21dc1c4  vmovaps xmm8, [rsp+0x70]
00007d0bb21dc1ca  vmovaps xmm9, [rsp+0x80]
00007d0bb21dc1d3  vmovaps xmm10, [rsp+0x90]
00007d0bb21dc1dc  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dc1e5  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dc1ee  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dc1f7  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dc200  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dc209  add rsp, 0xF0
00007d0bb21dc210  pop r11
00007d0bb21dc212  pop r10
00007d0bb21dc214  pop r9
00007d0bb21dc216  pop r8
00007d0bb21dc218  pop rsi
00007d0bb21dc219  pop rdi
00007d0bb21dc21a  pop rdx
00007d0bb21dc21b  pop rcx
00007d0bb21dc21c  pop rax
00007d0bb21dc21d  add rsp, 0x08
00007d0bb21dc221  jmp 0x00007D0BB21D93A2
00007d0bb21dc226  sub rsp, 0x08
00007d0bb21dc22a  push rax
00007d0bb21dc22b  push rcx
00007d0bb21dc22c  push rdx
00007d0bb21dc22d  push rdi
00007d0bb21dc22e  push rsi
00007d0bb21dc22f  push r8
00007d0bb21dc231  push r9
00007d0bb21dc233  push r10
00007d0bb21dc235  push r11
00007d0bb21dc237  sub rsp, 0xF0
00007d0bb21dc23e  vmovaps [rsp], xmm0
00007d0bb21dc243  vmovaps [rsp+0x10], xmm1
00007d0bb21dc249  vmovaps [rsp+0x20], xmm2
00007d0bb21dc24f  vmovaps [rsp+0x30], xmm3
00007d0bb21dc255  vmovaps [rsp+0x40], xmm4
00007d0bb21dc25b  vmovaps [rsp+0x50], xmm5
00007d0bb21dc261  vmovaps [rsp+0x60], xmm6
00007d0bb21dc267  vmovaps [rsp+0x70], xmm7
00007d0bb21dc26d  vmovaps [rsp+0x80], xmm8
00007d0bb21dc276  vmovaps [rsp+0x90], xmm9
00007d0bb21dc27f  vmovaps [rsp+0xA0], xmm10
00007d0bb21dc288  vmovaps [rsp+0xB0], xmm11
00007d0bb21dc291  vmovaps [rsp+0xC0], xmm12
00007d0bb21dc29a  vmovaps [rsp+0xD0], xmm13
00007d0bb21dc2a3  vmovaps [rsp+0xE0], xmm14
00007d0bb21dc2ac  sub rsp, 0x30
00007d0bb21dc2b0  movaps [rsp], xmm15
00007d0bb21dc2b5  movaps [rsp+0x10], xmm5
00007d0bb21dc2ba  movaps [rsp+0x20], xmm3
00007d0bb21dc2bf  lea rdi, [rsp]
00007d0bb21dc2c3  mov esi, 0x00
00007d0bb21dc2c8  mov rax, 0x6392BBE7F530
00007d0bb21dc2d2  call rax
00007d0bb21dc2d4  movaps xmm15, [rsp]
00007d0bb21dc2d9  add rsp, 0x30
00007d0bb21dc2dd  vmovaps xmm0, [rsp]
00007d0bb21dc2e2  vmovaps xmm1, [rsp+0x10]
00007d0bb21dc2e8  vmovaps xmm2, [rsp+0x20]
00007d0bb21dc2ee  vmovaps xmm3, [rsp+0x30]
00007d0bb21dc2f4  vmovaps xmm4, [rsp+0x40]
00007d0bb21dc2fa  vmovaps xmm5, [rsp+0x50]
00007d0bb21dc300  vmovaps xmm6, [rsp+0x60]
00007d0bb21dc306  vmovaps xmm7, [rsp+0x70]
00007d0bb21dc30c  vmovaps xmm8, [rsp+0x80]
00007d0bb21dc315  vmovaps xmm9, [rsp+0x90]
00007d0bb21dc31e  vmovaps xmm10, [rsp+0xA0]
00007d0bb21dc327  vmovaps xmm11, [rsp+0xB0]
00007d0bb21dc330  vmovaps xmm12, [rsp+0xC0]
00007d0bb21dc339  vmovaps xmm13, [rsp+0xD0]
00007d0bb21dc342  vmovaps xmm14, [rsp+0xE0]
00007d0bb21dc34b  add rsp, 0xF0
00007d0bb21dc352  pop r11
00007d0bb21dc354  pop r10
00007d0bb21dc356  pop r9
00007d0bb21dc358  pop r8
00007d0bb21dc35a  pop rsi
00007d0bb21dc35b  pop rdi
00007d0bb21dc35c  pop rdx
00007d0bb21dc35d  pop rcx
00007d0bb21dc35e  pop rax
00007d0bb21dc35f  add rsp, 0x08
00007d0bb21dc363  jmp 0x00007D0BB21D93BC
00007d0bb21dc368  sub rsp, 0x08
00007d0bb21dc36c  push rax
00007d0bb21dc36d  push rcx
00007d0bb21dc36e  push rdx
00007d0bb21dc36f  push rdi
00007d0bb21dc370  push rsi
00007d0bb21dc371  push r8
00007d0bb21dc373  push r9
00007d0bb21dc375  push r10
00007d0bb21dc377  push r11
00007d0bb21dc379  sub rsp, 0xF0
00007d0bb21dc380  vmovaps [rsp], xmm0
00007d0bb21dc385  vmovaps [rsp+0x10], xmm1
00007d0bb21dc38b  vmovaps [rsp+0x20], xmm2
00007d0bb21dc391  vmovaps [rsp+0x30], xmm3
00007d0bb21dc397  vmovaps [rsp+0x40], xmm4
00007d0bb21dc39d  vmovaps [rsp+0x50], xmm6
00007d0bb21dc3a3  vmovaps [rsp+0x60], xmm7
00007d0bb21dc3a9  vmovaps [rsp+0x70], xmm8
00007d0bb21dc3af  vmovaps [rsp+0x80], xmm9
00007d0bb21dc3b8  vmovaps [rsp+0x90], xmm10
00007d0bb21dc3c1  vmovaps [rsp+0xA0], xmm11
00007d0bb21dc3ca  vmovaps [rsp+0xB0], xmm12
00007d0bb21dc3d3  vmovaps [rsp+0xC0], xmm13
00007d0bb21dc3dc  vmovaps [rsp+0xD0], xmm14
00007d0bb21dc3e5  vmovaps [rsp+0xE0], xmm15
00007d0bb21dc3ee  sub rsp, 0x30
00007d0bb21dc3f2  movaps [rsp], xmm5
00007d0bb21dc3f6  movaps [rsp+0x10], xmm8
00007d0bb21dc3fc  movaps [rsp+0x20], xmm6
00007d0bb21dc401  lea rdi, [rsp]
00007d0bb21dc405  mov esi, 0x00
00007d0bb21dc40a  mov rax, 0x6392BBE7F530
00007d0bb21dc414  call rax
00007d0bb21dc416  movaps xmm5, [rsp]
00007d0bb21dc41a  add rsp, 0x30
00007d0bb21dc41e  vmovaps xmm0, [rsp]
00007d0bb21dc423  vmovaps xmm1, [rsp+0x10]
00007d0bb21dc429  vmovaps xmm2, [rsp+0x20]
00007d0bb21dc42f  vmovaps xmm3, [rsp+0x30]
00007d0bb21dc435  vmovaps xmm4, [rsp+0x40]
00007d0bb21dc43b  vmovaps xmm6, [rsp+0x50]
00007d0bb21dc441  vmovaps xmm7, [rsp+0x60]
00007d0bb21dc447  vmovaps xmm8, [rsp+0x70]
00007d0bb21dc44d  vmovaps xmm9, [rsp+0x80]
00007d0bb21dc456  vmovaps xmm10, [rsp+0x90]
00007d0bb21dc45f  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dc468  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dc471  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dc47a  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dc483  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dc48c  add rsp, 0xF0
00007d0bb21dc493  pop r11
00007d0bb21dc495  pop r10
00007d0bb21dc497  pop r9
00007d0bb21dc499  pop r8
00007d0bb21dc49b  pop rsi
00007d0bb21dc49c  pop rdi
00007d0bb21dc49d  pop rdx
00007d0bb21dc49e  pop rcx
00007d0bb21dc49f  pop rax
00007d0bb21dc4a0  add rsp, 0x08
00007d0bb21dc4a4  jmp 0x00007D0BB21D93E0
00007d0bb21dc4a9  sub rsp, 0x08
00007d0bb21dc4ad  push rax
00007d0bb21dc4ae  push rcx
00007d0bb21dc4af  push rdx
00007d0bb21dc4b0  push rdi
00007d0bb21dc4b1  push rsi
00007d0bb21dc4b2  push r8
00007d0bb21dc4b4  push r9
00007d0bb21dc4b6  push r10
00007d0bb21dc4b8  push r11
00007d0bb21dc4ba  sub rsp, 0xF0
00007d0bb21dc4c1  vmovaps [rsp], xmm0
00007d0bb21dc4c6  vmovaps [rsp+0x10], xmm1
00007d0bb21dc4cc  vmovaps [rsp+0x20], xmm2
00007d0bb21dc4d2  vmovaps [rsp+0x30], xmm3
00007d0bb21dc4d8  vmovaps [rsp+0x40], xmm4
00007d0bb21dc4de  vmovaps [rsp+0x50], xmm5
00007d0bb21dc4e4  vmovaps [rsp+0x60], xmm7
00007d0bb21dc4ea  vmovaps [rsp+0x70], xmm8
00007d0bb21dc4f0  vmovaps [rsp+0x80], xmm9
00007d0bb21dc4f9  vmovaps [rsp+0x90], xmm10
00007d0bb21dc502  vmovaps [rsp+0xA0], xmm11
00007d0bb21dc50b  vmovaps [rsp+0xB0], xmm12
00007d0bb21dc514  vmovaps [rsp+0xC0], xmm13
00007d0bb21dc51d  vmovaps [rsp+0xD0], xmm14
00007d0bb21dc526  vmovaps [rsp+0xE0], xmm15
00007d0bb21dc52f  sub rsp, 0x30
00007d0bb21dc533  movaps [rsp], xmm6
00007d0bb21dc537  movaps [rsp+0x10], xmm10
00007d0bb21dc53d  movaps [rsp+0x20], xmm8
00007d0bb21dc543  lea rdi, [rsp]
00007d0bb21dc547  mov esi, 0x00
00007d0bb21dc54c  mov rax, 0x6392BBE7F530
00007d0bb21dc556  call rax
00007d0bb21dc558  movaps xmm6, [rsp]
00007d0bb21dc55c  add rsp, 0x30
00007d0bb21dc560  vmovaps xmm0, [rsp]
00007d0bb21dc565  vmovaps xmm1, [rsp+0x10]
00007d0bb21dc56b  vmovaps xmm2, [rsp+0x20]
00007d0bb21dc571  vmovaps xmm3, [rsp+0x30]
00007d0bb21dc577  vmovaps xmm4, [rsp+0x40]
00007d0bb21dc57d  vmovaps xmm5, [rsp+0x50]
00007d0bb21dc583  vmovaps xmm7, [rsp+0x60]
00007d0bb21dc589  vmovaps xmm8, [rsp+0x70]
00007d0bb21dc58f  vmovaps xmm9, [rsp+0x80]
00007d0bb21dc598  vmovaps xmm10, [rsp+0x90]
00007d0bb21dc5a1  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dc5aa  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dc5b3  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dc5bc  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dc5c5  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dc5ce  add rsp, 0xF0
00007d0bb21dc5d5  pop r11
00007d0bb21dc5d7  pop r10
00007d0bb21dc5d9  pop r9
00007d0bb21dc5db  pop r8
00007d0bb21dc5dd  pop rsi
00007d0bb21dc5de  pop rdi
00007d0bb21dc5df  pop rdx
00007d0bb21dc5e0  pop rcx
00007d0bb21dc5e1  pop rax
00007d0bb21dc5e2  add rsp, 0x08
00007d0bb21dc5e6  jmp 0x00007D0BB21D9405
00007d0bb21dc5eb  sub rsp, 0x08
00007d0bb21dc5ef  push rax
00007d0bb21dc5f0  push rcx
00007d0bb21dc5f1  push rdx
00007d0bb21dc5f2  push rdi
00007d0bb21dc5f3  push rsi
00007d0bb21dc5f4  push r8
00007d0bb21dc5f6  push r9
00007d0bb21dc5f8  push r10
00007d0bb21dc5fa  push r11
00007d0bb21dc5fc  sub rsp, 0xF0
00007d0bb21dc603  vmovaps [rsp], xmm0
00007d0bb21dc608  vmovaps [rsp+0x10], xmm1
00007d0bb21dc60e  vmovaps [rsp+0x20], xmm2
00007d0bb21dc614  vmovaps [rsp+0x30], xmm3
00007d0bb21dc61a  vmovaps [rsp+0x40], xmm4
00007d0bb21dc620  vmovaps [rsp+0x50], xmm5
00007d0bb21dc626  vmovaps [rsp+0x60], xmm6
00007d0bb21dc62c  vmovaps [rsp+0x70], xmm7
00007d0bb21dc632  vmovaps [rsp+0x80], xmm8
00007d0bb21dc63b  vmovaps [rsp+0x90], xmm9
00007d0bb21dc644  vmovaps [rsp+0xA0], xmm11
00007d0bb21dc64d  vmovaps [rsp+0xB0], xmm12
00007d0bb21dc656  vmovaps [rsp+0xC0], xmm13
00007d0bb21dc65f  vmovaps [rsp+0xD0], xmm14
00007d0bb21dc668  vmovaps [rsp+0xE0], xmm15
00007d0bb21dc671  sub rsp, 0x30
00007d0bb21dc675  movaps [rsp], xmm10
00007d0bb21dc67a  movaps [rsp+0x10], xmm8
00007d0bb21dc680  movaps [rsp+0x20], xmm14
00007d0bb21dc686  lea rdi, [rsp]
00007d0bb21dc68a  mov esi, 0x00
00007d0bb21dc68f  mov rax, 0x6392BBE7F530
00007d0bb21dc699  call rax
00007d0bb21dc69b  movaps xmm10, [rsp]
00007d0bb21dc6a0  add rsp, 0x30
00007d0bb21dc6a4  vmovaps xmm0, [rsp]
00007d0bb21dc6a9  vmovaps xmm1, [rsp+0x10]
00007d0bb21dc6af  vmovaps xmm2, [rsp+0x20]
00007d0bb21dc6b5  vmovaps xmm3, [rsp+0x30]
00007d0bb21dc6bb  vmovaps xmm4, [rsp+0x40]
00007d0bb21dc6c1  vmovaps xmm5, [rsp+0x50]
00007d0bb21dc6c7  vmovaps xmm6, [rsp+0x60]
00007d0bb21dc6cd  vmovaps xmm7, [rsp+0x70]
00007d0bb21dc6d3  vmovaps xmm8, [rsp+0x80]
00007d0bb21dc6dc  vmovaps xmm9, [rsp+0x90]
00007d0bb21dc6e5  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dc6ee  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dc6f7  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dc700  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dc709  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dc712  add rsp, 0xF0
00007d0bb21dc719  pop r11
00007d0bb21dc71b  pop r10
00007d0bb21dc71d  pop r9
00007d0bb21dc71f  pop r8
00007d0bb21dc721  pop rsi
00007d0bb21dc722  pop rdi
00007d0bb21dc723  pop rdx
00007d0bb21dc724  pop rcx
00007d0bb21dc725  pop rax
00007d0bb21dc726  add rsp, 0x08
00007d0bb21dc72a  jmp 0x00007D0BB21D9425
00007d0bb21dc72f  sub rsp, 0x08
00007d0bb21dc733  push rax
00007d0bb21dc734  push rcx
00007d0bb21dc735  push rdx
00007d0bb21dc736  push rdi
00007d0bb21dc737  push rsi
00007d0bb21dc738  push r8
00007d0bb21dc73a  push r9
00007d0bb21dc73c  push r10
00007d0bb21dc73e  push r11
00007d0bb21dc740  sub rsp, 0xF0
00007d0bb21dc747  vmovaps [rsp], xmm0
00007d0bb21dc74c  vmovaps [rsp+0x10], xmm1
00007d0bb21dc752  vmovaps [rsp+0x20], xmm2
00007d0bb21dc758  vmovaps [rsp+0x30], xmm3
00007d0bb21dc75e  vmovaps [rsp+0x40], xmm4
00007d0bb21dc764  vmovaps [rsp+0x50], xmm5
00007d0bb21dc76a  vmovaps [rsp+0x60], xmm6
00007d0bb21dc770  vmovaps [rsp+0x70], xmm7
00007d0bb21dc776  vmovaps [rsp+0x80], xmm8
00007d0bb21dc77f  vmovaps [rsp+0x90], xmm9
00007d0bb21dc788  vmovaps [rsp+0xA0], xmm10
00007d0bb21dc791  vmovaps [rsp+0xB0], xmm11
00007d0bb21dc79a  vmovaps [rsp+0xC0], xmm12
00007d0bb21dc7a3  vmovaps [rsp+0xD0], xmm13
00007d0bb21dc7ac  vmovaps [rsp+0xE0], xmm15
00007d0bb21dc7b5  sub rsp, 0x30
00007d0bb21dc7b9  movaps [rsp], xmm14
00007d0bb21dc7be  movaps [rsp+0x10], xmm8
00007d0bb21dc7c4  movaps [rsp+0x20], xmm4
00007d0bb21dc7c9  lea rdi, [rsp]
00007d0bb21dc7cd  mov esi, 0x00
00007d0bb21dc7d2  mov rax, 0x6392BBE7F530
00007d0bb21dc7dc  call rax
00007d0bb21dc7de  movaps xmm14, [rsp]
00007d0bb21dc7e3  add rsp, 0x30
00007d0bb21dc7e7  vmovaps xmm0, [rsp]
00007d0bb21dc7ec  vmovaps xmm1, [rsp+0x10]
00007d0bb21dc7f2  vmovaps xmm2, [rsp+0x20]
00007d0bb21dc7f8  vmovaps xmm3, [rsp+0x30]
00007d0bb21dc7fe  vmovaps xmm4, [rsp+0x40]
00007d0bb21dc804  vmovaps xmm5, [rsp+0x50]
00007d0bb21dc80a  vmovaps xmm6, [rsp+0x60]
00007d0bb21dc810  vmovaps xmm7, [rsp+0x70]
00007d0bb21dc816  vmovaps xmm8, [rsp+0x80]
00007d0bb21dc81f  vmovaps xmm9, [rsp+0x90]
00007d0bb21dc828  vmovaps xmm10, [rsp+0xA0]
00007d0bb21dc831  vmovaps xmm11, [rsp+0xB0]
00007d0bb21dc83a  vmovaps xmm12, [rsp+0xC0]
00007d0bb21dc843  vmovaps xmm13, [rsp+0xD0]
00007d0bb21dc84c  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dc855  add rsp, 0xF0
00007d0bb21dc85c  pop r11
00007d0bb21dc85e  pop r10
00007d0bb21dc860  pop r9
00007d0bb21dc862  pop r8
00007d0bb21dc864  pop rsi
00007d0bb21dc865  pop rdi
00007d0bb21dc866  pop rdx
00007d0bb21dc867  pop rcx
00007d0bb21dc868  pop rax
00007d0bb21dc869  add rsp, 0x08
00007d0bb21dc86d  jmp 0x00007D0BB21D9445
00007d0bb21dc872  sub rsp, 0x08
00007d0bb21dc876  push rax
00007d0bb21dc877  push rcx
00007d0bb21dc878  push rdx
00007d0bb21dc879  push rdi
00007d0bb21dc87a  push rsi
00007d0bb21dc87b  push r8
00007d0bb21dc87d  push r9
00007d0bb21dc87f  push r10
00007d0bb21dc881  push r11
00007d0bb21dc883  sub rsp, 0xF0
00007d0bb21dc88a  vmovaps [rsp], xmm0
00007d0bb21dc88f  vmovaps [rsp+0x10], xmm1
00007d0bb21dc895  vmovaps [rsp+0x20], xmm2
00007d0bb21dc89b  vmovaps [rsp+0x30], xmm3
00007d0bb21dc8a1  vmovaps [rsp+0x40], xmm5
00007d0bb21dc8a7  vmovaps [rsp+0x50], xmm6
00007d0bb21dc8ad  vmovaps [rsp+0x60], xmm7
00007d0bb21dc8b3  vmovaps [rsp+0x70], xmm8
00007d0bb21dc8b9  vmovaps [rsp+0x80], xmm9
00007d0bb21dc8c2  vmovaps [rsp+0x90], xmm10
00007d0bb21dc8cb  vmovaps [rsp+0xA0], xmm11
00007d0bb21dc8d4  vmovaps [rsp+0xB0], xmm12
00007d0bb21dc8dd  vmovaps [rsp+0xC0], xmm13
00007d0bb21dc8e6  vmovaps [rsp+0xD0], xmm14
00007d0bb21dc8ef  vmovaps [rsp+0xE0], xmm15
00007d0bb21dc8f8  sub rsp, 0x30
00007d0bb21dc8fc  movaps [rsp], xmm4
00007d0bb21dc900  movaps [rsp+0x10], xmm13
00007d0bb21dc906  movaps [rsp+0x20], xmm8
00007d0bb21dc90c  lea rdi, [rsp]
00007d0bb21dc910  mov esi, 0x00
00007d0bb21dc915  mov rax, 0x6392BBE7F530
00007d0bb21dc91f  call rax
00007d0bb21dc921  movaps xmm4, [rsp]
00007d0bb21dc925  add rsp, 0x30
00007d0bb21dc929  vmovaps xmm0, [rsp]
00007d0bb21dc92e  vmovaps xmm1, [rsp+0x10]
00007d0bb21dc934  vmovaps xmm2, [rsp+0x20]
00007d0bb21dc93a  vmovaps xmm3, [rsp+0x30]
00007d0bb21dc940  vmovaps xmm5, [rsp+0x40]
00007d0bb21dc946  vmovaps xmm6, [rsp+0x50]
00007d0bb21dc94c  vmovaps xmm7, [rsp+0x60]
00007d0bb21dc952  vmovaps xmm8, [rsp+0x70]
00007d0bb21dc958  vmovaps xmm9, [rsp+0x80]
00007d0bb21dc961  vmovaps xmm10, [rsp+0x90]
00007d0bb21dc96a  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dc973  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dc97c  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dc985  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dc98e  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dc997  add rsp, 0xF0
00007d0bb21dc99e  pop r11
00007d0bb21dc9a0  pop r10
00007d0bb21dc9a2  pop r9
00007d0bb21dc9a4  pop r8
00007d0bb21dc9a6  pop rsi
00007d0bb21dc9a7  pop rdi
00007d0bb21dc9a8  pop rdx
00007d0bb21dc9a9  pop rcx
00007d0bb21dc9aa  pop rax
00007d0bb21dc9ab  add rsp, 0x08
00007d0bb21dc9af  jmp 0x00007D0BB21D946A
00007d0bb21dc9b4  sub rsp, 0x08
00007d0bb21dc9b8  push rax
00007d0bb21dc9b9  push rcx
00007d0bb21dc9ba  push rdx
00007d0bb21dc9bb  push rdi
00007d0bb21dc9bc  push rsi
00007d0bb21dc9bd  push r8
00007d0bb21dc9bf  push r9
00007d0bb21dc9c1  push r10
00007d0bb21dc9c3  push r11
00007d0bb21dc9c5  sub rsp, 0xF0
00007d0bb21dc9cc  vmovaps [rsp], xmm0
00007d0bb21dc9d1  vmovaps [rsp+0x10], xmm1
00007d0bb21dc9d7  vmovaps [rsp+0x20], xmm2
00007d0bb21dc9dd  vmovaps [rsp+0x30], xmm3
00007d0bb21dc9e3  vmovaps [rsp+0x40], xmm4
00007d0bb21dc9e9  vmovaps [rsp+0x50], xmm5
00007d0bb21dc9ef  vmovaps [rsp+0x60], xmm6
00007d0bb21dc9f5  vmovaps [rsp+0x70], xmm7
00007d0bb21dc9fb  vmovaps [rsp+0x80], xmm8
00007d0bb21dca04  vmovaps [rsp+0x90], xmm9
00007d0bb21dca0d  vmovaps [rsp+0xA0], xmm10
00007d0bb21dca16  vmovaps [rsp+0xB0], xmm11
00007d0bb21dca1f  vmovaps [rsp+0xC0], xmm12
00007d0bb21dca28  vmovaps [rsp+0xD0], xmm14
00007d0bb21dca31  vmovaps [rsp+0xE0], xmm15
00007d0bb21dca3a  sub rsp, 0x30
00007d0bb21dca3e  movaps [rsp], xmm13
00007d0bb21dca43  movaps [rsp+0x10], xmm15
00007d0bb21dca49  movaps [rsp+0x20], xmm9
00007d0bb21dca4f  lea rdi, [rsp]
00007d0bb21dca53  mov esi, 0x00
00007d0bb21dca58  mov rax, 0x6392BBE7F530
00007d0bb21dca62  call rax
00007d0bb21dca64  movaps xmm13, [rsp]
00007d0bb21dca69  add rsp, 0x30
00007d0bb21dca6d  vmovaps xmm0, [rsp]
00007d0bb21dca72  vmovaps xmm1, [rsp+0x10]
00007d0bb21dca78  vmovaps xmm2, [rsp+0x20]
00007d0bb21dca7e  vmovaps xmm3, [rsp+0x30]
00007d0bb21dca84  vmovaps xmm4, [rsp+0x40]
00007d0bb21dca8a  vmovaps xmm5, [rsp+0x50]
00007d0bb21dca90  vmovaps xmm6, [rsp+0x60]
00007d0bb21dca96  vmovaps xmm7, [rsp+0x70]
00007d0bb21dca9c  vmovaps xmm8, [rsp+0x80]
00007d0bb21dcaa5  vmovaps xmm9, [rsp+0x90]
00007d0bb21dcaae  vmovaps xmm10, [rsp+0xA0]
00007d0bb21dcab7  vmovaps xmm11, [rsp+0xB0]
00007d0bb21dcac0  vmovaps xmm12, [rsp+0xC0]
00007d0bb21dcac9  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dcad2  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dcadb  add rsp, 0xF0
00007d0bb21dcae2  pop r11
00007d0bb21dcae4  pop r10
00007d0bb21dcae6  pop r9
00007d0bb21dcae8  pop r8
00007d0bb21dcaea  pop rsi
00007d0bb21dcaeb  pop rdi
00007d0bb21dcaec  pop rdx
00007d0bb21dcaed  pop rcx
00007d0bb21dcaee  pop rax
00007d0bb21dcaef  add rsp, 0x08
00007d0bb21dcaf3  jmp 0x00007D0BB21D9485
00007d0bb21dcaf8  sub rsp, 0x08
00007d0bb21dcafc  push rax
00007d0bb21dcafd  push rcx
00007d0bb21dcafe  push rdx
00007d0bb21dcaff  push rdi
00007d0bb21dcb00  push rsi
00007d0bb21dcb01  push r8
00007d0bb21dcb03  push r9
00007d0bb21dcb05  push r10
00007d0bb21dcb07  push r11
00007d0bb21dcb09  sub rsp, 0xF0
00007d0bb21dcb10  vmovaps [rsp], xmm0
00007d0bb21dcb15  vmovaps [rsp+0x10], xmm1
00007d0bb21dcb1b  vmovaps [rsp+0x20], xmm2
00007d0bb21dcb21  vmovaps [rsp+0x30], xmm3
00007d0bb21dcb27  vmovaps [rsp+0x40], xmm4
00007d0bb21dcb2d  vmovaps [rsp+0x50], xmm5
00007d0bb21dcb33  vmovaps [rsp+0x60], xmm6
00007d0bb21dcb39  vmovaps [rsp+0x70], xmm7
00007d0bb21dcb3f  vmovaps [rsp+0x80], xmm8
00007d0bb21dcb48  vmovaps [rsp+0x90], xmm9
00007d0bb21dcb51  vmovaps [rsp+0xA0], xmm10
00007d0bb21dcb5a  vmovaps [rsp+0xB0], xmm11
00007d0bb21dcb63  vmovaps [rsp+0xC0], xmm12
00007d0bb21dcb6c  vmovaps [rsp+0xD0], xmm13
00007d0bb21dcb75  vmovaps [rsp+0xE0], xmm14
00007d0bb21dcb7e  sub rsp, 0x30
00007d0bb21dcb82  movaps [rsp], xmm15
00007d0bb21dcb87  movaps [rsp+0x10], xmm1
00007d0bb21dcb8c  movaps [rsp+0x20], xmm5
00007d0bb21dcb91  lea rdi, [rsp]
00007d0bb21dcb95  mov esi, 0x00
00007d0bb21dcb9a  mov rax, 0x6392BBE7F530
00007d0bb21dcba4  call rax
00007d0bb21dcba6  movaps xmm15, [rsp]
00007d0bb21dcbab  add rsp, 0x30
00007d0bb21dcbaf  vmovaps xmm0, [rsp]
00007d0bb21dcbb4  vmovaps xmm1, [rsp+0x10]
00007d0bb21dcbba  vmovaps xmm2, [rsp+0x20]
00007d0bb21dcbc0  vmovaps xmm3, [rsp+0x30]
00007d0bb21dcbc6  vmovaps xmm4, [rsp+0x40]
00007d0bb21dcbcc  vmovaps xmm5, [rsp+0x50]
00007d0bb21dcbd2  vmovaps xmm6, [rsp+0x60]
00007d0bb21dcbd8  vmovaps xmm7, [rsp+0x70]
00007d0bb21dcbde  vmovaps xmm8, [rsp+0x80]
00007d0bb21dcbe7  vmovaps xmm9, [rsp+0x90]
00007d0bb21dcbf0  vmovaps xmm10, [rsp+0xA0]
00007d0bb21dcbf9  vmovaps xmm11, [rsp+0xB0]
00007d0bb21dcc02  vmovaps xmm12, [rsp+0xC0]
00007d0bb21dcc0b  vmovaps xmm13, [rsp+0xD0]
00007d0bb21dcc14  vmovaps xmm14, [rsp+0xE0]
00007d0bb21dcc1d  add rsp, 0xF0
00007d0bb21dcc24  pop r11
00007d0bb21dcc26  pop r10
00007d0bb21dcc28  pop r9
00007d0bb21dcc2a  pop r8
00007d0bb21dcc2c  pop rsi
00007d0bb21dcc2d  pop rdi
00007d0bb21dcc2e  pop rdx
00007d0bb21dcc2f  pop rcx
00007d0bb21dcc30  pop rax
00007d0bb21dcc31  add rsp, 0x08
00007d0bb21dcc35  jmp 0x00007D0BB21D94A0
00007d0bb21dcc3a  call 0x00007D0BB20D64F0
00007d0bb21dcc3f  jmp 0x00007D0BB21D94FB
00007d0bb21dcc44  sub rsp, 0x08
00007d0bb21dcc48  push rax
00007d0bb21dcc49  push rcx
00007d0bb21dcc4a  push rdx
00007d0bb21dcc4b  push rdi
00007d0bb21dcc4c  push rsi
00007d0bb21dcc4d  push r8
00007d0bb21dcc4f  push r9
00007d0bb21dcc51  push r10
00007d0bb21dcc53  push r11
00007d0bb21dcc55  sub rsp, 0xF0
00007d0bb21dcc5c  vmovaps [rsp], xmm0
00007d0bb21dcc61  vmovaps [rsp+0x10], xmm1
00007d0bb21dcc67  vmovaps [rsp+0x20], xmm2
00007d0bb21dcc6d  vmovaps [rsp+0x30], xmm3
00007d0bb21dcc73  vmovaps [rsp+0x40], xmm4
00007d0bb21dcc79  vmovaps [rsp+0x50], xmm5
00007d0bb21dcc7f  vmovaps [rsp+0x60], xmm6
00007d0bb21dcc85  vmovaps [rsp+0x70], xmm7
00007d0bb21dcc8b  vmovaps [rsp+0x80], xmm8
00007d0bb21dcc94  vmovaps [rsp+0x90], xmm10
00007d0bb21dcc9d  vmovaps [rsp+0xA0], xmm11
00007d0bb21dcca6  vmovaps [rsp+0xB0], xmm12
00007d0bb21dccaf  vmovaps [rsp+0xC0], xmm13
00007d0bb21dccb8  vmovaps [rsp+0xD0], xmm14
00007d0bb21dccc1  vmovaps [rsp+0xE0], xmm15
00007d0bb21dccca  sub rsp, 0x30
00007d0bb21dccce  movaps [rsp], xmm9
00007d0bb21dccd3  movaps [rsp+0x10], xmm8
00007d0bb21dccd9  movaps [rsp+0x20], xmm11
00007d0bb21dccdf  lea rdi, [rsp]
00007d0bb21dcce3  mov esi, 0x00
00007d0bb21dcce8  mov rax, 0x6392BBE7F530
00007d0bb21dccf2  call rax
00007d0bb21dccf4  movaps xmm9, [rsp]
00007d0bb21dccf9  add rsp, 0x30
00007d0bb21dccfd  vmovaps xmm0, [rsp]
00007d0bb21dcd02  vmovaps xmm1, [rsp+0x10]
00007d0bb21dcd08  vmovaps xmm2, [rsp+0x20]
00007d0bb21dcd0e  vmovaps xmm3, [rsp+0x30]
00007d0bb21dcd14  vmovaps xmm4, [rsp+0x40]
00007d0bb21dcd1a  vmovaps xmm5, [rsp+0x50]
00007d0bb21dcd20  vmovaps xmm6, [rsp+0x60]
00007d0bb21dcd26  vmovaps xmm7, [rsp+0x70]
00007d0bb21dcd2c  vmovaps xmm8, [rsp+0x80]
00007d0bb21dcd35  vmovaps xmm10, [rsp+0x90]
00007d0bb21dcd3e  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dcd47  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dcd50  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dcd59  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dcd62  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dcd6b  add rsp, 0xF0
00007d0bb21dcd72  pop r11
00007d0bb21dcd74  pop r10
00007d0bb21dcd76  pop r9
00007d0bb21dcd78  pop r8
00007d0bb21dcd7a  pop rsi
00007d0bb21dcd7b  pop rdi
00007d0bb21dcd7c  pop rdx
00007d0bb21dcd7d  pop rcx
00007d0bb21dcd7e  pop rax
00007d0bb21dcd7f  add rsp, 0x08
00007d0bb21dcd83  jmp 0x00007D0BB21D9532
00007d0bb21dcd88  sub rsp, 0x08
00007d0bb21dcd8c  push rax
00007d0bb21dcd8d  push rcx
00007d0bb21dcd8e  push rdx
00007d0bb21dcd8f  push rdi
00007d0bb21dcd90  push rsi
00007d0bb21dcd91  push r8
00007d0bb21dcd93  push r9
00007d0bb21dcd95  push r10
00007d0bb21dcd97  push r11
00007d0bb21dcd99  sub rsp, 0xF0
00007d0bb21dcda0  vmovaps [rsp], xmm0
00007d0bb21dcda5  vmovaps [rsp+0x10], xmm1
00007d0bb21dcdab  vmovaps [rsp+0x20], xmm2
00007d0bb21dcdb1  vmovaps [rsp+0x30], xmm3
00007d0bb21dcdb7  vmovaps [rsp+0x40], xmm4
00007d0bb21dcdbd  vmovaps [rsp+0x50], xmm5
00007d0bb21dcdc3  vmovaps [rsp+0x60], xmm6
00007d0bb21dcdc9  vmovaps [rsp+0x70], xmm7
00007d0bb21dcdcf  vmovaps [rsp+0x80], xmm8
00007d0bb21dcdd8  vmovaps [rsp+0x90], xmm9
00007d0bb21dcde1  vmovaps [rsp+0xA0], xmm10
00007d0bb21dcdea  vmovaps [rsp+0xB0], xmm12
00007d0bb21dcdf3  vmovaps [rsp+0xC0], xmm13
00007d0bb21dcdfc  vmovaps [rsp+0xD0], xmm14
00007d0bb21dce05  vmovaps [rsp+0xE0], xmm15
00007d0bb21dce0e  sub rsp, 0x30
00007d0bb21dce12  movaps [rsp], xmm11
00007d0bb21dce17  movaps [rsp+0x10], xmm10
00007d0bb21dce1d  movaps [rsp+0x20], xmm6
00007d0bb21dce22  lea rdi, [rsp]
00007d0bb21dce26  mov esi, 0x00
00007d0bb21dce2b  mov rax, 0x6392BBE7F530
00007d0bb21dce35  call rax
00007d0bb21dce37  movaps xmm11, [rsp]
00007d0bb21dce3c  add rsp, 0x30
00007d0bb21dce40  vmovaps xmm0, [rsp]
00007d0bb21dce45  vmovaps xmm1, [rsp+0x10]
00007d0bb21dce4b  vmovaps xmm2, [rsp+0x20]
00007d0bb21dce51  vmovaps xmm3, [rsp+0x30]
00007d0bb21dce57  vmovaps xmm4, [rsp+0x40]
00007d0bb21dce5d  vmovaps xmm5, [rsp+0x50]
00007d0bb21dce63  vmovaps xmm6, [rsp+0x60]
00007d0bb21dce69  vmovaps xmm7, [rsp+0x70]
00007d0bb21dce6f  vmovaps xmm8, [rsp+0x80]
00007d0bb21dce78  vmovaps xmm9, [rsp+0x90]
00007d0bb21dce81  vmovaps xmm10, [rsp+0xA0]
00007d0bb21dce8a  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dce93  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dce9c  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dcea5  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dceae  add rsp, 0xF0
00007d0bb21dceb5  pop r11
00007d0bb21dceb7  pop r10
00007d0bb21dceb9  pop r9
00007d0bb21dcebb  pop r8
00007d0bb21dcebd  pop rsi
00007d0bb21dcebe  pop rdi
00007d0bb21dcebf  pop rdx
00007d0bb21dcec0  pop rcx
00007d0bb21dcec1  pop rax
00007d0bb21dcec2  add rsp, 0x08
00007d0bb21dcec6  jmp 0x00007D0BB21D954D
00007d0bb21dcecb  sub rsp, 0x08
00007d0bb21dcecf  push rax
00007d0bb21dced0  push rcx
00007d0bb21dced1  push rdx
00007d0bb21dced2  push rdi
00007d0bb21dced3  push rsi
00007d0bb21dced4  push r8
00007d0bb21dced6  push r9
00007d0bb21dced8  push r10
00007d0bb21dceda  push r11
00007d0bb21dcedc  sub rsp, 0xF0
00007d0bb21dcee3  vmovaps [rsp], xmm0
00007d0bb21dcee8  vmovaps [rsp+0x10], xmm1
00007d0bb21dceee  vmovaps [rsp+0x20], xmm2
00007d0bb21dcef4  vmovaps [rsp+0x30], xmm3
00007d0bb21dcefa  vmovaps [rsp+0x40], xmm4
00007d0bb21dcf00  vmovaps [rsp+0x50], xmm5
00007d0bb21dcf06  vmovaps [rsp+0x60], xmm6
00007d0bb21dcf0c  vmovaps [rsp+0x70], xmm7
00007d0bb21dcf12  vmovaps [rsp+0x80], xmm8
00007d0bb21dcf1b  vmovaps [rsp+0x90], xmm9
00007d0bb21dcf24  vmovaps [rsp+0xA0], xmm11
00007d0bb21dcf2d  vmovaps [rsp+0xB0], xmm12
00007d0bb21dcf36  vmovaps [rsp+0xC0], xmm13
00007d0bb21dcf3f  vmovaps [rsp+0xD0], xmm14
00007d0bb21dcf48  vmovaps [rsp+0xE0], xmm15
00007d0bb21dcf51  sub rsp, 0x30
00007d0bb21dcf55  movaps [rsp], xmm10
00007d0bb21dcf5a  movaps [rsp+0x10], xmm14
00007d0bb21dcf60  movaps [rsp+0x20], xmm4
00007d0bb21dcf65  lea rdi, [rsp]
00007d0bb21dcf69  mov esi, 0x00
00007d0bb21dcf6e  mov rax, 0x6392BBE7F530
00007d0bb21dcf78  call rax
00007d0bb21dcf7a  movaps xmm10, [rsp]
00007d0bb21dcf7f  add rsp, 0x30
00007d0bb21dcf83  vmovaps xmm0, [rsp]
00007d0bb21dcf88  vmovaps xmm1, [rsp+0x10]
00007d0bb21dcf8e  vmovaps xmm2, [rsp+0x20]
00007d0bb21dcf94  vmovaps xmm3, [rsp+0x30]
00007d0bb21dcf9a  vmovaps xmm4, [rsp+0x40]
00007d0bb21dcfa0  vmovaps xmm5, [rsp+0x50]
00007d0bb21dcfa6  vmovaps xmm6, [rsp+0x60]
00007d0bb21dcfac  vmovaps xmm7, [rsp+0x70]
00007d0bb21dcfb2  vmovaps xmm8, [rsp+0x80]
00007d0bb21dcfbb  vmovaps xmm9, [rsp+0x90]
00007d0bb21dcfc4  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dcfcd  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dcfd6  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dcfdf  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dcfe8  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dcff1  add rsp, 0xF0
00007d0bb21dcff8  pop r11
00007d0bb21dcffa  pop r10
00007d0bb21dcffc  pop r9
00007d0bb21dcffe  pop r8
00007d0bb21dd000  pop rsi
00007d0bb21dd001  pop rdi
00007d0bb21dd002  pop rdx
00007d0bb21dd003  pop rcx
00007d0bb21dd004  pop rax
00007d0bb21dd005  add rsp, 0x08
00007d0bb21dd009  jmp 0x00007D0BB21D9568
00007d0bb21dd00e  sub rsp, 0x08
00007d0bb21dd012  push rax
00007d0bb21dd013  push rcx
00007d0bb21dd014  push rdx
00007d0bb21dd015  push rdi
00007d0bb21dd016  push rsi
00007d0bb21dd017  push r8
00007d0bb21dd019  push r9
00007d0bb21dd01b  push r10
00007d0bb21dd01d  push r11
00007d0bb21dd01f  sub rsp, 0xF0
00007d0bb21dd026  vmovaps [rsp], xmm0
00007d0bb21dd02b  vmovaps [rsp+0x10], xmm1
00007d0bb21dd031  vmovaps [rsp+0x20], xmm2
00007d0bb21dd037  vmovaps [rsp+0x30], xmm3
00007d0bb21dd03d  vmovaps [rsp+0x40], xmm4
00007d0bb21dd043  vmovaps [rsp+0x50], xmm5
00007d0bb21dd049  vmovaps [rsp+0x60], xmm6
00007d0bb21dd04f  vmovaps [rsp+0x70], xmm7
00007d0bb21dd055  vmovaps [rsp+0x80], xmm9
00007d0bb21dd05e  vmovaps [rsp+0x90], xmm10
00007d0bb21dd067  vmovaps [rsp+0xA0], xmm11
00007d0bb21dd070  vmovaps [rsp+0xB0], xmm12
00007d0bb21dd079  vmovaps [rsp+0xC0], xmm13
00007d0bb21dd082  vmovaps [rsp+0xD0], xmm14
00007d0bb21dd08b  vmovaps [rsp+0xE0], xmm15
00007d0bb21dd094  sub rsp, 0x30
00007d0bb21dd098  movaps [rsp], xmm8
00007d0bb21dd09d  movaps [rsp+0x10], xmm1
00007d0bb21dd0a2  movaps [rsp+0x20], xmm14
00007d0bb21dd0a8  lea rdi, [rsp]
00007d0bb21dd0ac  mov esi, 0x00
00007d0bb21dd0b1  mov rax, 0x6392BBE7F530
00007d0bb21dd0bb  call rax
00007d0bb21dd0bd  movaps xmm8, [rsp]
00007d0bb21dd0c2  add rsp, 0x30
00007d0bb21dd0c6  vmovaps xmm0, [rsp]
00007d0bb21dd0cb  vmovaps xmm1, [rsp+0x10]
00007d0bb21dd0d1  vmovaps xmm2, [rsp+0x20]
00007d0bb21dd0d7  vmovaps xmm3, [rsp+0x30]
00007d0bb21dd0dd  vmovaps xmm4, [rsp+0x40]
00007d0bb21dd0e3  vmovaps xmm5, [rsp+0x50]
00007d0bb21dd0e9  vmovaps xmm6, [rsp+0x60]
00007d0bb21dd0ef  vmovaps xmm7, [rsp+0x70]
00007d0bb21dd0f5  vmovaps xmm9, [rsp+0x80]
00007d0bb21dd0fe  vmovaps xmm10, [rsp+0x90]
00007d0bb21dd107  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dd110  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dd119  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dd122  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dd12b  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dd134  add rsp, 0xF0
00007d0bb21dd13b  pop r11
00007d0bb21dd13d  pop r10
00007d0bb21dd13f  pop r9
00007d0bb21dd141  pop r8
00007d0bb21dd143  pop rsi
00007d0bb21dd144  pop rdi
00007d0bb21dd145  pop rdx
00007d0bb21dd146  pop rcx
00007d0bb21dd147  pop rax
00007d0bb21dd148  add rsp, 0x08
00007d0bb21dd14c  jmp 0x00007D0BB21D958E
00007d0bb21dd151  sub rsp, 0x08
00007d0bb21dd155  push rax
00007d0bb21dd156  push rcx
00007d0bb21dd157  push rdx
00007d0bb21dd158  push rdi
00007d0bb21dd159  push rsi
00007d0bb21dd15a  push r8
00007d0bb21dd15c  push r9
00007d0bb21dd15e  push r10
00007d0bb21dd160  push r11
00007d0bb21dd162  sub rsp, 0xF0
00007d0bb21dd169  vmovaps [rsp], xmm0
00007d0bb21dd16e  vmovaps [rsp+0x10], xmm1
00007d0bb21dd174  vmovaps [rsp+0x20], xmm2
00007d0bb21dd17a  vmovaps [rsp+0x30], xmm3
00007d0bb21dd180  vmovaps [rsp+0x40], xmm4
00007d0bb21dd186  vmovaps [rsp+0x50], xmm5
00007d0bb21dd18c  vmovaps [rsp+0x60], xmm7
00007d0bb21dd192  vmovaps [rsp+0x70], xmm8
00007d0bb21dd198  vmovaps [rsp+0x80], xmm9
00007d0bb21dd1a1  vmovaps [rsp+0x90], xmm10
00007d0bb21dd1aa  vmovaps [rsp+0xA0], xmm11
00007d0bb21dd1b3  vmovaps [rsp+0xB0], xmm12
00007d0bb21dd1bc  vmovaps [rsp+0xC0], xmm13
00007d0bb21dd1c5  vmovaps [rsp+0xD0], xmm14
00007d0bb21dd1ce  vmovaps [rsp+0xE0], xmm15
00007d0bb21dd1d7  sub rsp, 0x30
00007d0bb21dd1db  movaps [rsp], xmm6
00007d0bb21dd1df  movaps [rsp+0x10], xmm1
00007d0bb21dd1e4  movaps [rsp+0x20], xmm14
00007d0bb21dd1ea  lea rdi, [rsp]
00007d0bb21dd1ee  mov esi, 0x00
00007d0bb21dd1f3  mov rax, 0x6392BBE7F530
00007d0bb21dd1fd  call rax
00007d0bb21dd1ff  movaps xmm6, [rsp]
00007d0bb21dd203  add rsp, 0x30
00007d0bb21dd207  vmovaps xmm0, [rsp]
00007d0bb21dd20c  vmovaps xmm1, [rsp+0x10]
00007d0bb21dd212  vmovaps xmm2, [rsp+0x20]
00007d0bb21dd218  vmovaps xmm3, [rsp+0x30]
00007d0bb21dd21e  vmovaps xmm4, [rsp+0x40]
00007d0bb21dd224  vmovaps xmm5, [rsp+0x50]
00007d0bb21dd22a  vmovaps xmm7, [rsp+0x60]
00007d0bb21dd230  vmovaps xmm8, [rsp+0x70]
00007d0bb21dd236  vmovaps xmm9, [rsp+0x80]
00007d0bb21dd23f  vmovaps xmm10, [rsp+0x90]
00007d0bb21dd248  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dd251  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dd25a  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dd263  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dd26c  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dd275  add rsp, 0xF0
00007d0bb21dd27c  pop r11
00007d0bb21dd27e  pop r10
00007d0bb21dd280  pop r9
00007d0bb21dd282  pop r8
00007d0bb21dd284  pop rsi
00007d0bb21dd285  pop rdi
00007d0bb21dd286  pop rdx
00007d0bb21dd287  pop rcx
00007d0bb21dd288  pop rax
00007d0bb21dd289  add rsp, 0x08
00007d0bb21dd28d  jmp 0x00007D0BB21D95BA
00007d0bb21dd292  sub rsp, 0x08
00007d0bb21dd296  push rax
00007d0bb21dd297  push rcx
00007d0bb21dd298  push rdx
00007d0bb21dd299  push rdi
00007d0bb21dd29a  push rsi
00007d0bb21dd29b  push r8
00007d0bb21dd29d  push r9
00007d0bb21dd29f  push r10
00007d0bb21dd2a1  push r11
00007d0bb21dd2a3  sub rsp, 0xF0
00007d0bb21dd2aa  vmovaps [rsp], xmm0
00007d0bb21dd2af  vmovaps [rsp+0x10], xmm1
00007d0bb21dd2b5  vmovaps [rsp+0x20], xmm2
00007d0bb21dd2bb  vmovaps [rsp+0x30], xmm3
00007d0bb21dd2c1  vmovaps [rsp+0x40], xmm4
00007d0bb21dd2c7  vmovaps [rsp+0x50], xmm5
00007d0bb21dd2cd  vmovaps [rsp+0x60], xmm6
00007d0bb21dd2d3  vmovaps [rsp+0x70], xmm7
00007d0bb21dd2d9  vmovaps [rsp+0x80], xmm8
00007d0bb21dd2e2  vmovaps [rsp+0x90], xmm9
00007d0bb21dd2eb  vmovaps [rsp+0xA0], xmm10
00007d0bb21dd2f4  vmovaps [rsp+0xB0], xmm11
00007d0bb21dd2fd  vmovaps [rsp+0xC0], xmm12
00007d0bb21dd306  vmovaps [rsp+0xD0], xmm13
00007d0bb21dd30f  vmovaps [rsp+0xE0], xmm15
00007d0bb21dd318  sub rsp, 0x30
00007d0bb21dd31c  movaps [rsp], xmm14
00007d0bb21dd321  movaps [rsp+0x10], xmm12
00007d0bb21dd327  movaps [rsp+0x20], xmm1
00007d0bb21dd32c  lea rdi, [rsp]
00007d0bb21dd330  mov esi, 0x00
00007d0bb21dd335  mov rax, 0x6392BBE7F530
00007d0bb21dd33f  call rax
00007d0bb21dd341  movaps xmm14, [rsp]
00007d0bb21dd346  add rsp, 0x30
00007d0bb21dd34a  vmovaps xmm0, [rsp]
00007d0bb21dd34f  vmovaps xmm1, [rsp+0x10]
00007d0bb21dd355  vmovaps xmm2, [rsp+0x20]
00007d0bb21dd35b  vmovaps xmm3, [rsp+0x30]
00007d0bb21dd361  vmovaps xmm4, [rsp+0x40]
00007d0bb21dd367  vmovaps xmm5, [rsp+0x50]
00007d0bb21dd36d  vmovaps xmm6, [rsp+0x60]
00007d0bb21dd373  vmovaps xmm7, [rsp+0x70]
00007d0bb21dd379  vmovaps xmm8, [rsp+0x80]
00007d0bb21dd382  vmovaps xmm9, [rsp+0x90]
00007d0bb21dd38b  vmovaps xmm10, [rsp+0xA0]
00007d0bb21dd394  vmovaps xmm11, [rsp+0xB0]
00007d0bb21dd39d  vmovaps xmm12, [rsp+0xC0]
00007d0bb21dd3a6  vmovaps xmm13, [rsp+0xD0]
00007d0bb21dd3af  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dd3b8  add rsp, 0xF0
00007d0bb21dd3bf  pop r11
00007d0bb21dd3c1  pop r10
00007d0bb21dd3c3  pop r9
00007d0bb21dd3c5  pop r8
00007d0bb21dd3c7  pop rsi
00007d0bb21dd3c8  pop rdi
00007d0bb21dd3c9  pop rdx
00007d0bb21dd3ca  pop rcx
00007d0bb21dd3cb  pop rax
00007d0bb21dd3cc  add rsp, 0x08
00007d0bb21dd3d0  jmp 0x00007D0BB21D95E0
00007d0bb21dd3d5  sub rsp, 0x08
00007d0bb21dd3d9  push rax
00007d0bb21dd3da  push rcx
00007d0bb21dd3db  push rdx
00007d0bb21dd3dc  push rdi
00007d0bb21dd3dd  push rsi
00007d0bb21dd3de  push r8
00007d0bb21dd3e0  push r9
00007d0bb21dd3e2  push r10
00007d0bb21dd3e4  push r11
00007d0bb21dd3e6  sub rsp, 0xF0
00007d0bb21dd3ed  vmovaps [rsp], xmm0
00007d0bb21dd3f2  vmovaps [rsp+0x10], xmm2
00007d0bb21dd3f8  vmovaps [rsp+0x20], xmm3
00007d0bb21dd3fe  vmovaps [rsp+0x30], xmm4
00007d0bb21dd404  vmovaps [rsp+0x40], xmm5
00007d0bb21dd40a  vmovaps [rsp+0x50], xmm6
00007d0bb21dd410  vmovaps [rsp+0x60], xmm7
00007d0bb21dd416  vmovaps [rsp+0x70], xmm8
00007d0bb21dd41c  vmovaps [rsp+0x80], xmm9
00007d0bb21dd425  vmovaps [rsp+0x90], xmm10
00007d0bb21dd42e  vmovaps [rsp+0xA0], xmm11
00007d0bb21dd437  vmovaps [rsp+0xB0], xmm12
00007d0bb21dd440  vmovaps [rsp+0xC0], xmm13
00007d0bb21dd449  vmovaps [rsp+0xD0], xmm14
00007d0bb21dd452  vmovaps [rsp+0xE0], xmm15
00007d0bb21dd45b  sub rsp, 0x30
00007d0bb21dd45f  movaps [rsp], xmm1
00007d0bb21dd463  movaps [rsp+0x10], xmm13
00007d0bb21dd469  movaps [rsp+0x20], xmm9
00007d0bb21dd46f  lea rdi, [rsp]
00007d0bb21dd473  mov esi, 0x00
00007d0bb21dd478  mov rax, 0x6392BBE7F530
00007d0bb21dd482  call rax
00007d0bb21dd484  movaps xmm1, [rsp]
00007d0bb21dd488  add rsp, 0x30
00007d0bb21dd48c  vmovaps xmm0, [rsp]
00007d0bb21dd491  vmovaps xmm2, [rsp+0x10]
00007d0bb21dd497  vmovaps xmm3, [rsp+0x20]
00007d0bb21dd49d  vmovaps xmm4, [rsp+0x30]
00007d0bb21dd4a3  vmovaps xmm5, [rsp+0x40]
00007d0bb21dd4a9  vmovaps xmm6, [rsp+0x50]
00007d0bb21dd4af  vmovaps xmm7, [rsp+0x60]
00007d0bb21dd4b5  vmovaps xmm8, [rsp+0x70]
00007d0bb21dd4bb  vmovaps xmm9, [rsp+0x80]
00007d0bb21dd4c4  vmovaps xmm10, [rsp+0x90]
00007d0bb21dd4cd  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dd4d6  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dd4df  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dd4e8  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dd4f1  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dd4fa  add rsp, 0xF0
00007d0bb21dd501  pop r11
00007d0bb21dd503  pop r10
00007d0bb21dd505  pop r9
00007d0bb21dd507  pop r8
00007d0bb21dd509  pop rsi
00007d0bb21dd50a  pop rdi
00007d0bb21dd50b  pop rdx
00007d0bb21dd50c  pop rcx
00007d0bb21dd50d  pop rax
00007d0bb21dd50e  add rsp, 0x08
00007d0bb21dd512  jmp 0x00007D0BB21D95FA
00007d0bb21dd517  sub rsp, 0x08
00007d0bb21dd51b  push rax
00007d0bb21dd51c  push rcx
00007d0bb21dd51d  push rdx
00007d0bb21dd51e  push rdi
00007d0bb21dd51f  push rsi
00007d0bb21dd520  push r8
00007d0bb21dd522  push r9
00007d0bb21dd524  push r10
00007d0bb21dd526  push r11
00007d0bb21dd528  sub rsp, 0xF0
00007d0bb21dd52f  vmovaps [rsp], xmm0
00007d0bb21dd534  vmovaps [rsp+0x10], xmm1
00007d0bb21dd53a  vmovaps [rsp+0x20], xmm2
00007d0bb21dd540  vmovaps [rsp+0x30], xmm3
00007d0bb21dd546  vmovaps [rsp+0x40], xmm4
00007d0bb21dd54c  vmovaps [rsp+0x50], xmm5
00007d0bb21dd552  vmovaps [rsp+0x60], xmm6
00007d0bb21dd558  vmovaps [rsp+0x70], xmm7
00007d0bb21dd55e  vmovaps [rsp+0x80], xmm8
00007d0bb21dd567  vmovaps [rsp+0x90], xmm9
00007d0bb21dd570  vmovaps [rsp+0xA0], xmm10
00007d0bb21dd579  vmovaps [rsp+0xB0], xmm11
00007d0bb21dd582  vmovaps [rsp+0xC0], xmm13
00007d0bb21dd58b  vmovaps [rsp+0xD0], xmm14
00007d0bb21dd594  vmovaps [rsp+0xE0], xmm15
00007d0bb21dd59d  sub rsp, 0x30
00007d0bb21dd5a1  movaps [rsp], xmm12
00007d0bb21dd5a6  movaps [rsp+0x10], xmm7
00007d0bb21dd5ab  movaps [rsp+0x20], xmm13
00007d0bb21dd5b1  lea rdi, [rsp]
00007d0bb21dd5b5  mov esi, 0x00
00007d0bb21dd5ba  mov rax, 0x6392BBE7F530
00007d0bb21dd5c4  call rax
00007d0bb21dd5c6  movaps xmm12, [rsp]
00007d0bb21dd5cb  add rsp, 0x30
00007d0bb21dd5cf  vmovaps xmm0, [rsp]
00007d0bb21dd5d4  vmovaps xmm1, [rsp+0x10]
00007d0bb21dd5da  vmovaps xmm2, [rsp+0x20]
00007d0bb21dd5e0  vmovaps xmm3, [rsp+0x30]
00007d0bb21dd5e6  vmovaps xmm4, [rsp+0x40]
00007d0bb21dd5ec  vmovaps xmm5, [rsp+0x50]
00007d0bb21dd5f2  vmovaps xmm6, [rsp+0x60]
00007d0bb21dd5f8  vmovaps xmm7, [rsp+0x70]
00007d0bb21dd5fe  vmovaps xmm8, [rsp+0x80]
00007d0bb21dd607  vmovaps xmm9, [rsp+0x90]
00007d0bb21dd610  vmovaps xmm10, [rsp+0xA0]
00007d0bb21dd619  vmovaps xmm11, [rsp+0xB0]
00007d0bb21dd622  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dd62b  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dd634  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dd63d  add rsp, 0xF0
00007d0bb21dd644  pop r11
00007d0bb21dd646  pop r10
00007d0bb21dd648  pop r9
00007d0bb21dd64a  pop r8
00007d0bb21dd64c  pop rsi
00007d0bb21dd64d  pop rdi
00007d0bb21dd64e  pop rdx
00007d0bb21dd64f  pop rcx
00007d0bb21dd650  pop rax
00007d0bb21dd651  add rsp, 0x08
00007d0bb21dd655  jmp 0x00007D0BB21D9621
00007d0bb21dd65a  sub rsp, 0x08
00007d0bb21dd65e  push rax
00007d0bb21dd65f  push rcx
00007d0bb21dd660  push rdx
00007d0bb21dd661  push rdi
00007d0bb21dd662  push rsi
00007d0bb21dd663  push r8
00007d0bb21dd665  push r9
00007d0bb21dd667  push r10
00007d0bb21dd669  push r11
00007d0bb21dd66b  sub rsp, 0xF0
00007d0bb21dd672  vmovaps [rsp], xmm0
00007d0bb21dd677  vmovaps [rsp+0x10], xmm1
00007d0bb21dd67d  vmovaps [rsp+0x20], xmm2
00007d0bb21dd683  vmovaps [rsp+0x30], xmm3
00007d0bb21dd689  vmovaps [rsp+0x40], xmm4
00007d0bb21dd68f  vmovaps [rsp+0x50], xmm5
00007d0bb21dd695  vmovaps [rsp+0x60], xmm6
00007d0bb21dd69b  vmovaps [rsp+0x70], xmm7
00007d0bb21dd6a1  vmovaps [rsp+0x80], xmm8
00007d0bb21dd6aa  vmovaps [rsp+0x90], xmm9
00007d0bb21dd6b3  vmovaps [rsp+0xA0], xmm10
00007d0bb21dd6bc  vmovaps [rsp+0xB0], xmm11
00007d0bb21dd6c5  vmovaps [rsp+0xC0], xmm12
00007d0bb21dd6ce  vmovaps [rsp+0xD0], xmm14
00007d0bb21dd6d7  vmovaps [rsp+0xE0], xmm15
00007d0bb21dd6e0  sub rsp, 0x30
00007d0bb21dd6e4  movaps [rsp], xmm13
00007d0bb21dd6e9  movaps [rsp+0x10], xmm15
00007d0bb21dd6ef  movaps [rsp+0x20], xmm8
00007d0bb21dd6f5  lea rdi, [rsp]
00007d0bb21dd6f9  mov esi, 0x00
00007d0bb21dd6fe  mov rax, 0x6392BBE7F530
00007d0bb21dd708  call rax
00007d0bb21dd70a  movaps xmm13, [rsp]
00007d0bb21dd70f  add rsp, 0x30
00007d0bb21dd713  vmovaps xmm0, [rsp]
00007d0bb21dd718  vmovaps xmm1, [rsp+0x10]
00007d0bb21dd71e  vmovaps xmm2, [rsp+0x20]
00007d0bb21dd724  vmovaps xmm3, [rsp+0x30]
00007d0bb21dd72a  vmovaps xmm4, [rsp+0x40]
00007d0bb21dd730  vmovaps xmm5, [rsp+0x50]
00007d0bb21dd736  vmovaps xmm6, [rsp+0x60]
00007d0bb21dd73c  vmovaps xmm7, [rsp+0x70]
00007d0bb21dd742  vmovaps xmm8, [rsp+0x80]
00007d0bb21dd74b  vmovaps xmm9, [rsp+0x90]
00007d0bb21dd754  vmovaps xmm10, [rsp+0xA0]
00007d0bb21dd75d  vmovaps xmm11, [rsp+0xB0]
00007d0bb21dd766  vmovaps xmm12, [rsp+0xC0]
00007d0bb21dd76f  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dd778  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dd781  add rsp, 0xF0
00007d0bb21dd788  pop r11
00007d0bb21dd78a  pop r10
00007d0bb21dd78c  pop r9
00007d0bb21dd78e  pop r8
00007d0bb21dd790  pop rsi
00007d0bb21dd791  pop rdi
00007d0bb21dd792  pop rdx
00007d0bb21dd793  pop rcx
00007d0bb21dd794  pop rax
00007d0bb21dd795  add rsp, 0x08
00007d0bb21dd799  jmp 0x00007D0BB21D963C
00007d0bb21dd79e  sub rsp, 0x08
00007d0bb21dd7a2  push rax
00007d0bb21dd7a3  push rcx
00007d0bb21dd7a4  push rdx
00007d0bb21dd7a5  push rdi
00007d0bb21dd7a6  push rsi
00007d0bb21dd7a7  push r8
00007d0bb21dd7a9  push r9
00007d0bb21dd7ab  push r10
00007d0bb21dd7ad  push r11
00007d0bb21dd7af  sub rsp, 0xF0
00007d0bb21dd7b6  vmovaps [rsp], xmm0
00007d0bb21dd7bb  vmovaps [rsp+0x10], xmm1
00007d0bb21dd7c1  vmovaps [rsp+0x20], xmm2
00007d0bb21dd7c7  vmovaps [rsp+0x30], xmm3
00007d0bb21dd7cd  vmovaps [rsp+0x40], xmm4
00007d0bb21dd7d3  vmovaps [rsp+0x50], xmm5
00007d0bb21dd7d9  vmovaps [rsp+0x60], xmm6
00007d0bb21dd7df  vmovaps [rsp+0x70], xmm7
00007d0bb21dd7e5  vmovaps [rsp+0x80], xmm9
00007d0bb21dd7ee  vmovaps [rsp+0x90], xmm10
00007d0bb21dd7f7  vmovaps [rsp+0xA0], xmm11
00007d0bb21dd800  vmovaps [rsp+0xB0], xmm12
00007d0bb21dd809  vmovaps [rsp+0xC0], xmm13
00007d0bb21dd812  vmovaps [rsp+0xD0], xmm14
00007d0bb21dd81b  vmovaps [rsp+0xE0], xmm15
00007d0bb21dd824  sub rsp, 0x30
00007d0bb21dd828  movaps [rsp], xmm8
00007d0bb21dd82d  movaps [rsp+0x10], xmm15
00007d0bb21dd833  movaps [rsp+0x20], xmm9
00007d0bb21dd839  lea rdi, [rsp]
00007d0bb21dd83d  mov esi, 0x00
00007d0bb21dd842  mov rax, 0x6392BBE7F530
00007d0bb21dd84c  call rax
00007d0bb21dd84e  movaps xmm8, [rsp]
00007d0bb21dd853  add rsp, 0x30
00007d0bb21dd857  vmovaps xmm0, [rsp]
00007d0bb21dd85c  vmovaps xmm1, [rsp+0x10]
00007d0bb21dd862  vmovaps xmm2, [rsp+0x20]
00007d0bb21dd868  vmovaps xmm3, [rsp+0x30]
00007d0bb21dd86e  vmovaps xmm4, [rsp+0x40]
00007d0bb21dd874  vmovaps xmm5, [rsp+0x50]
00007d0bb21dd87a  vmovaps xmm6, [rsp+0x60]
00007d0bb21dd880  vmovaps xmm7, [rsp+0x70]
00007d0bb21dd886  vmovaps xmm9, [rsp+0x80]
00007d0bb21dd88f  vmovaps xmm10, [rsp+0x90]
00007d0bb21dd898  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dd8a1  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dd8aa  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dd8b3  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dd8bc  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dd8c5  add rsp, 0xF0
00007d0bb21dd8cc  pop r11
00007d0bb21dd8ce  pop r10
00007d0bb21dd8d0  pop r9
00007d0bb21dd8d2  pop r8
00007d0bb21dd8d4  pop rsi
00007d0bb21dd8d5  pop rdi
00007d0bb21dd8d6  pop rdx
00007d0bb21dd8d7  pop rcx
00007d0bb21dd8d8  pop rax
00007d0bb21dd8d9  add rsp, 0x08
00007d0bb21dd8dd  jmp 0x00007D0BB21D966A
00007d0bb21dd8e2  sub rsp, 0x08
00007d0bb21dd8e6  push rax
00007d0bb21dd8e7  push rcx
00007d0bb21dd8e8  push rdx
00007d0bb21dd8e9  push rdi
00007d0bb21dd8ea  push rsi
00007d0bb21dd8eb  push r8
00007d0bb21dd8ed  push r9
00007d0bb21dd8ef  push r10
00007d0bb21dd8f1  push r11
00007d0bb21dd8f3  sub rsp, 0xF0
00007d0bb21dd8fa  vmovaps [rsp], xmm0
00007d0bb21dd8ff  vmovaps [rsp+0x10], xmm1
00007d0bb21dd905  vmovaps [rsp+0x20], xmm2
00007d0bb21dd90b  vmovaps [rsp+0x30], xmm3
00007d0bb21dd911  vmovaps [rsp+0x40], xmm4
00007d0bb21dd917  vmovaps [rsp+0x50], xmm5
00007d0bb21dd91d  vmovaps [rsp+0x60], xmm6
00007d0bb21dd923  vmovaps [rsp+0x70], xmm7
00007d0bb21dd929  vmovaps [rsp+0x80], xmm8
00007d0bb21dd932  vmovaps [rsp+0x90], xmm9
00007d0bb21dd93b  vmovaps [rsp+0xA0], xmm10
00007d0bb21dd944  vmovaps [rsp+0xB0], xmm11
00007d0bb21dd94d  vmovaps [rsp+0xC0], xmm12
00007d0bb21dd956  vmovaps [rsp+0xD0], xmm13
00007d0bb21dd95f  vmovaps [rsp+0xE0], xmm14
00007d0bb21dd968  sub rsp, 0x30
00007d0bb21dd96c  movaps [rsp], xmm15
00007d0bb21dd971  movaps [rsp+0x10], xmm11
00007d0bb21dd977  movaps [rsp+0x20], xmm6
00007d0bb21dd97c  lea rdi, [rsp]
00007d0bb21dd980  mov esi, 0x00
00007d0bb21dd985  mov rax, 0x6392BBE7F530
00007d0bb21dd98f  call rax
00007d0bb21dd991  movaps xmm15, [rsp]
00007d0bb21dd996  add rsp, 0x30
00007d0bb21dd99a  vmovaps xmm0, [rsp]
00007d0bb21dd99f  vmovaps xmm1, [rsp+0x10]
00007d0bb21dd9a5  vmovaps xmm2, [rsp+0x20]
00007d0bb21dd9ab  vmovaps xmm3, [rsp+0x30]
00007d0bb21dd9b1  vmovaps xmm4, [rsp+0x40]
00007d0bb21dd9b7  vmovaps xmm5, [rsp+0x50]
00007d0bb21dd9bd  vmovaps xmm6, [rsp+0x60]
00007d0bb21dd9c3  vmovaps xmm7, [rsp+0x70]
00007d0bb21dd9c9  vmovaps xmm8, [rsp+0x80]
00007d0bb21dd9d2  vmovaps xmm9, [rsp+0x90]
00007d0bb21dd9db  vmovaps xmm10, [rsp+0xA0]
00007d0bb21dd9e4  vmovaps xmm11, [rsp+0xB0]
00007d0bb21dd9ed  vmovaps xmm12, [rsp+0xC0]
00007d0bb21dd9f6  vmovaps xmm13, [rsp+0xD0]
00007d0bb21dd9ff  vmovaps xmm14, [rsp+0xE0]
00007d0bb21dda08  add rsp, 0xF0
00007d0bb21dda0f  pop r11
00007d0bb21dda11  pop r10
00007d0bb21dda13  pop r9
00007d0bb21dda15  pop r8
00007d0bb21dda17  pop rsi
00007d0bb21dda18  pop rdi
00007d0bb21dda19  pop rdx
00007d0bb21dda1a  pop rcx
00007d0bb21dda1b  pop rax
00007d0bb21dda1c  add rsp, 0x08
00007d0bb21dda20  jmp 0x00007D0BB21D9685
00007d0bb21dda25  sub rsp, 0x08
00007d0bb21dda29  push rax
00007d0bb21dda2a  push rcx
00007d0bb21dda2b  push rdx
00007d0bb21dda2c  push rdi
00007d0bb21dda2d  push rsi
00007d0bb21dda2e  push r8
00007d0bb21dda30  push r9
00007d0bb21dda32  push r10
00007d0bb21dda34  push r11
00007d0bb21dda36  sub rsp, 0xF0
00007d0bb21dda3d  vmovaps [rsp], xmm0
00007d0bb21dda42  vmovaps [rsp+0x10], xmm1
00007d0bb21dda48  vmovaps [rsp+0x20], xmm2
00007d0bb21dda4e  vmovaps [rsp+0x30], xmm3
00007d0bb21dda54  vmovaps [rsp+0x40], xmm4
00007d0bb21dda5a  vmovaps [rsp+0x50], xmm5
00007d0bb21dda60  vmovaps [rsp+0x60], xmm6
00007d0bb21dda66  vmovaps [rsp+0x70], xmm8
00007d0bb21dda6c  vmovaps [rsp+0x80], xmm9
00007d0bb21dda75  vmovaps [rsp+0x90], xmm10
00007d0bb21dda7e  vmovaps [rsp+0xA0], xmm11
00007d0bb21dda87  vmovaps [rsp+0xB0], xmm12
00007d0bb21dda90  vmovaps [rsp+0xC0], xmm13
00007d0bb21dda99  vmovaps [rsp+0xD0], xmm14
00007d0bb21ddaa2  vmovaps [rsp+0xE0], xmm15
00007d0bb21ddaab  sub rsp, 0x30
00007d0bb21ddaaf  movaps [rsp], xmm7
00007d0bb21ddab3  movaps [rsp+0x10], xmm11
00007d0bb21ddab9  movaps [rsp+0x20], xmm9
00007d0bb21ddabf  lea rdi, [rsp]
00007d0bb21ddac3  mov esi, 0x00
00007d0bb21ddac8  mov rax, 0x6392BBE7F530
00007d0bb21ddad2  call rax
00007d0bb21ddad4  movaps xmm7, [rsp]
00007d0bb21ddad8  add rsp, 0x30
00007d0bb21ddadc  vmovaps xmm0, [rsp]
00007d0bb21ddae1  vmovaps xmm1, [rsp+0x10]
00007d0bb21ddae7  vmovaps xmm2, [rsp+0x20]
00007d0bb21ddaed  vmovaps xmm3, [rsp+0x30]
00007d0bb21ddaf3  vmovaps xmm4, [rsp+0x40]
00007d0bb21ddaf9  vmovaps xmm5, [rsp+0x50]
00007d0bb21ddaff  vmovaps xmm6, [rsp+0x60]
00007d0bb21ddb05  vmovaps xmm8, [rsp+0x70]
00007d0bb21ddb0b  vmovaps xmm9, [rsp+0x80]
00007d0bb21ddb14  vmovaps xmm10, [rsp+0x90]
00007d0bb21ddb1d  vmovaps xmm11, [rsp+0xA0]
00007d0bb21ddb26  vmovaps xmm12, [rsp+0xB0]
00007d0bb21ddb2f  vmovaps xmm13, [rsp+0xC0]
00007d0bb21ddb38  vmovaps xmm14, [rsp+0xD0]
00007d0bb21ddb41  vmovaps xmm15, [rsp+0xE0]
00007d0bb21ddb4a  add rsp, 0xF0
00007d0bb21ddb51  pop r11
00007d0bb21ddb53  pop r10
00007d0bb21ddb55  pop r9
00007d0bb21ddb57  pop r8
00007d0bb21ddb59  pop rsi
00007d0bb21ddb5a  pop rdi
00007d0bb21ddb5b  pop rdx
00007d0bb21ddb5c  pop rcx
00007d0bb21ddb5d  pop rax
00007d0bb21ddb5e  add rsp, 0x08
00007d0bb21ddb62  jmp 0x00007D0BB21D96B2
00007d0bb21ddb67  sub rsp, 0x08
00007d0bb21ddb6b  push rax
00007d0bb21ddb6c  push rcx
00007d0bb21ddb6d  push rdx
00007d0bb21ddb6e  push rdi
00007d0bb21ddb6f  push rsi
00007d0bb21ddb70  push r8
00007d0bb21ddb72  push r9
00007d0bb21ddb74  push r10
00007d0bb21ddb76  push r11
00007d0bb21ddb78  sub rsp, 0xF0
00007d0bb21ddb7f  vmovaps [rsp], xmm0
00007d0bb21ddb84  vmovaps [rsp+0x10], xmm1
00007d0bb21ddb8a  vmovaps [rsp+0x20], xmm2
00007d0bb21ddb90  vmovaps [rsp+0x30], xmm3
00007d0bb21ddb96  vmovaps [rsp+0x40], xmm4
00007d0bb21ddb9c  vmovaps [rsp+0x50], xmm5
00007d0bb21ddba2  vmovaps [rsp+0x60], xmm6
00007d0bb21ddba8  vmovaps [rsp+0x70], xmm7
00007d0bb21ddbae  vmovaps [rsp+0x80], xmm8
00007d0bb21ddbb7  vmovaps [rsp+0x90], xmm9
00007d0bb21ddbc0  vmovaps [rsp+0xA0], xmm10
00007d0bb21ddbc9  vmovaps [rsp+0xB0], xmm12
00007d0bb21ddbd2  vmovaps [rsp+0xC0], xmm13
00007d0bb21ddbdb  vmovaps [rsp+0xD0], xmm14
00007d0bb21ddbe4  vmovaps [rsp+0xE0], xmm15
00007d0bb21ddbed  sub rsp, 0x30
00007d0bb21ddbf1  movaps [rsp], xmm11
00007d0bb21ddbf6  movaps [rsp+0x10], xmm10
00007d0bb21ddbfc  movaps [rsp+0x20], xmm14
00007d0bb21ddc02  lea rdi, [rsp]
00007d0bb21ddc06  mov esi, 0x00
00007d0bb21ddc0b  mov rax, 0x6392BBE7F530
00007d0bb21ddc15  call rax
00007d0bb21ddc17  movaps xmm11, [rsp]
00007d0bb21ddc1c  add rsp, 0x30
00007d0bb21ddc20  vmovaps xmm0, [rsp]
00007d0bb21ddc25  vmovaps xmm1, [rsp+0x10]
00007d0bb21ddc2b  vmovaps xmm2, [rsp+0x20]
00007d0bb21ddc31  vmovaps xmm3, [rsp+0x30]
00007d0bb21ddc37  vmovaps xmm4, [rsp+0x40]
00007d0bb21ddc3d  vmovaps xmm5, [rsp+0x50]
00007d0bb21ddc43  vmovaps xmm6, [rsp+0x60]
00007d0bb21ddc49  vmovaps xmm7, [rsp+0x70]
00007d0bb21ddc4f  vmovaps xmm8, [rsp+0x80]
00007d0bb21ddc58  vmovaps xmm9, [rsp+0x90]
00007d0bb21ddc61  vmovaps xmm10, [rsp+0xA0]
00007d0bb21ddc6a  vmovaps xmm12, [rsp+0xB0]
00007d0bb21ddc73  vmovaps xmm13, [rsp+0xC0]
00007d0bb21ddc7c  vmovaps xmm14, [rsp+0xD0]
00007d0bb21ddc85  vmovaps xmm15, [rsp+0xE0]
00007d0bb21ddc8e  add rsp, 0xF0
00007d0bb21ddc95  pop r11
00007d0bb21ddc97  pop r10
00007d0bb21ddc99  pop r9
00007d0bb21ddc9b  pop r8
00007d0bb21ddc9d  pop rsi
00007d0bb21ddc9e  pop rdi
00007d0bb21ddc9f  pop rdx
00007d0bb21ddca0  pop rcx
00007d0bb21ddca1  pop rax
00007d0bb21ddca2  add rsp, 0x08
00007d0bb21ddca6  jmp 0x00007D0BB21D96CD
00007d0bb21ddcab  call 0x00007D0BB20E45A0
00007d0bb21ddcb0  jmp 0x00007D0BB21D96D7
00007d0bb21ddcb5  sub rsp, 0x08
00007d0bb21ddcb9  push rax
00007d0bb21ddcba  push rcx
00007d0bb21ddcbb  push rdx
00007d0bb21ddcbc  push rdi
00007d0bb21ddcbd  push rsi
00007d0bb21ddcbe  push r8
00007d0bb21ddcc0  push r9
00007d0bb21ddcc2  push r10
00007d0bb21ddcc4  push r11
00007d0bb21ddcc6  sub rsp, 0xF0
00007d0bb21ddccd  vmovaps [rsp], xmm0
00007d0bb21ddcd2  vmovaps [rsp+0x10], xmm1
00007d0bb21ddcd8  vmovaps [rsp+0x20], xmm2
00007d0bb21ddcde  vmovaps [rsp+0x30], xmm3
00007d0bb21ddce4  vmovaps [rsp+0x40], xmm4
00007d0bb21ddcea  vmovaps [rsp+0x50], xmm5
00007d0bb21ddcf0  vmovaps [rsp+0x60], xmm6
00007d0bb21ddcf6  vmovaps [rsp+0x70], xmm7
00007d0bb21ddcfc  vmovaps [rsp+0x80], xmm8
00007d0bb21ddd05  vmovaps [rsp+0x90], xmm9
00007d0bb21ddd0e  vmovaps [rsp+0xA0], xmm11
00007d0bb21ddd17  vmovaps [rsp+0xB0], xmm12
00007d0bb21ddd20  vmovaps [rsp+0xC0], xmm13
00007d0bb21ddd29  vmovaps [rsp+0xD0], xmm14
00007d0bb21ddd32  vmovaps [rsp+0xE0], xmm15
00007d0bb21ddd3b  sub rsp, 0x30
00007d0bb21ddd3f  movaps [rsp], xmm10
00007d0bb21ddd44  movaps [rsp+0x10], xmm1
00007d0bb21ddd49  movaps [rsp+0x20], xmm12
00007d0bb21ddd4f  lea rdi, [rsp]
00007d0bb21ddd53  mov esi, 0x00
00007d0bb21ddd58  mov rax, 0x6392BBE7F530
00007d0bb21ddd62  call rax
00007d0bb21ddd64  movaps xmm10, [rsp]
00007d0bb21ddd69  add rsp, 0x30
00007d0bb21ddd6d  vmovaps xmm0, [rsp]
00007d0bb21ddd72  vmovaps xmm1, [rsp+0x10]
00007d0bb21ddd78  vmovaps xmm2, [rsp+0x20]
00007d0bb21ddd7e  vmovaps xmm3, [rsp+0x30]
00007d0bb21ddd84  vmovaps xmm4, [rsp+0x40]
00007d0bb21ddd8a  vmovaps xmm5, [rsp+0x50]
00007d0bb21ddd90  vmovaps xmm6, [rsp+0x60]
00007d0bb21ddd96  vmovaps xmm7, [rsp+0x70]
00007d0bb21ddd9c  vmovaps xmm8, [rsp+0x80]
00007d0bb21ddda5  vmovaps xmm9, [rsp+0x90]
00007d0bb21dddae  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dddb7  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dddc0  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dddc9  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dddd2  vmovaps xmm15, [rsp+0xE0]
00007d0bb21ddddb  add rsp, 0xF0
00007d0bb21ddde2  pop r11
00007d0bb21ddde4  pop r10
00007d0bb21ddde6  pop r9
00007d0bb21ddde8  pop r8
00007d0bb21dddea  pop rsi
00007d0bb21dddeb  pop rdi
00007d0bb21dddec  pop rdx
00007d0bb21ddded  pop rcx
00007d0bb21dddee  pop rax
00007d0bb21dddef  add rsp, 0x08
00007d0bb21dddf3  jmp 0x00007D0BB21D96FA
00007d0bb21dddf8  sub rsp, 0x08
00007d0bb21dddfc  push rax
00007d0bb21dddfd  push rcx
00007d0bb21dddfe  push rdx
00007d0bb21dddff  push rdi
00007d0bb21dde00  push rsi
00007d0bb21dde01  push r8
00007d0bb21dde03  push r9
00007d0bb21dde05  push r10
00007d0bb21dde07  push r11
00007d0bb21dde09  sub rsp, 0xF0
00007d0bb21dde10  vmovaps [rsp], xmm0
00007d0bb21dde15  vmovaps [rsp+0x10], xmm1
00007d0bb21dde1b  vmovaps [rsp+0x20], xmm2
00007d0bb21dde21  vmovaps [rsp+0x30], xmm3
00007d0bb21dde27  vmovaps [rsp+0x40], xmm4
00007d0bb21dde2d  vmovaps [rsp+0x50], xmm5
00007d0bb21dde33  vmovaps [rsp+0x60], xmm6
00007d0bb21dde39  vmovaps [rsp+0x70], xmm7
00007d0bb21dde3f  vmovaps [rsp+0x80], xmm8
00007d0bb21dde48  vmovaps [rsp+0x90], xmm9
00007d0bb21dde51  vmovaps [rsp+0xA0], xmm10
00007d0bb21dde5a  vmovaps [rsp+0xB0], xmm11
00007d0bb21dde63  vmovaps [rsp+0xC0], xmm13
00007d0bb21dde6c  vmovaps [rsp+0xD0], xmm14
00007d0bb21dde75  vmovaps [rsp+0xE0], xmm15
00007d0bb21dde7e  sub rsp, 0x30
00007d0bb21dde82  movaps [rsp], xmm12
00007d0bb21dde87  movaps [rsp+0x10], xmm14
00007d0bb21dde8d  movaps [rsp+0x20], xmm1
00007d0bb21dde92  lea rdi, [rsp]
00007d0bb21dde96  mov esi, 0x00
00007d0bb21dde9b  mov rax, 0x6392BBE7F530
00007d0bb21ddea5  call rax
00007d0bb21ddea7  movaps xmm12, [rsp]
00007d0bb21ddeac  add rsp, 0x30
00007d0bb21ddeb0  vmovaps xmm0, [rsp]
00007d0bb21ddeb5  vmovaps xmm1, [rsp+0x10]
00007d0bb21ddebb  vmovaps xmm2, [rsp+0x20]
00007d0bb21ddec1  vmovaps xmm3, [rsp+0x30]
00007d0bb21ddec7  vmovaps xmm4, [rsp+0x40]
00007d0bb21ddecd  vmovaps xmm5, [rsp+0x50]
00007d0bb21dded3  vmovaps xmm6, [rsp+0x60]
00007d0bb21dded9  vmovaps xmm7, [rsp+0x70]
00007d0bb21ddedf  vmovaps xmm8, [rsp+0x80]
00007d0bb21ddee8  vmovaps xmm9, [rsp+0x90]
00007d0bb21ddef1  vmovaps xmm10, [rsp+0xA0]
00007d0bb21ddefa  vmovaps xmm11, [rsp+0xB0]
00007d0bb21ddf03  vmovaps xmm13, [rsp+0xC0]
00007d0bb21ddf0c  vmovaps xmm14, [rsp+0xD0]
00007d0bb21ddf15  vmovaps xmm15, [rsp+0xE0]
00007d0bb21ddf1e  add rsp, 0xF0
00007d0bb21ddf25  pop r11
00007d0bb21ddf27  pop r10
00007d0bb21ddf29  pop r9
00007d0bb21ddf2b  pop r8
00007d0bb21ddf2d  pop rsi
00007d0bb21ddf2e  pop rdi
00007d0bb21ddf2f  pop rdx
00007d0bb21ddf30  pop rcx
00007d0bb21ddf31  pop rax
00007d0bb21ddf32  add rsp, 0x08
00007d0bb21ddf36  jmp 0x00007D0BB21D9729
00007d0bb21ddf3b  sub rsp, 0x08
00007d0bb21ddf3f  push rax
00007d0bb21ddf40  push rcx
00007d0bb21ddf41  push rdx
00007d0bb21ddf42  push rdi
00007d0bb21ddf43  push rsi
00007d0bb21ddf44  push r8
00007d0bb21ddf46  push r9
00007d0bb21ddf48  push r10
00007d0bb21ddf4a  push r11
00007d0bb21ddf4c  sub rsp, 0xF0
00007d0bb21ddf53  vmovaps [rsp], xmm0
00007d0bb21ddf58  vmovaps [rsp+0x10], xmm1
00007d0bb21ddf5e  vmovaps [rsp+0x20], xmm2
00007d0bb21ddf64  vmovaps [rsp+0x30], xmm3
00007d0bb21ddf6a  vmovaps [rsp+0x40], xmm4
00007d0bb21ddf70  vmovaps [rsp+0x50], xmm5
00007d0bb21ddf76  vmovaps [rsp+0x60], xmm6
00007d0bb21ddf7c  vmovaps [rsp+0x70], xmm7
00007d0bb21ddf82  vmovaps [rsp+0x80], xmm8
00007d0bb21ddf8b  vmovaps [rsp+0x90], xmm9
00007d0bb21ddf94  vmovaps [rsp+0xA0], xmm10
00007d0bb21ddf9d  vmovaps [rsp+0xB0], xmm11
00007d0bb21ddfa6  vmovaps [rsp+0xC0], xmm12
00007d0bb21ddfaf  vmovaps [rsp+0xD0], xmm13
00007d0bb21ddfb8  vmovaps [rsp+0xE0], xmm15
00007d0bb21ddfc1  sub rsp, 0x30
00007d0bb21ddfc5  movaps [rsp], xmm14
00007d0bb21ddfca  movaps [rsp+0x10], xmm9
00007d0bb21ddfd0  movaps [rsp+0x20], xmm1
00007d0bb21ddfd5  lea rdi, [rsp]
00007d0bb21ddfd9  mov esi, 0x00
00007d0bb21ddfde  mov rax, 0x6392BBE7F530
00007d0bb21ddfe8  call rax
00007d0bb21ddfea  movaps xmm14, [rsp]
00007d0bb21ddfef  add rsp, 0x30
00007d0bb21ddff3  vmovaps xmm0, [rsp]
00007d0bb21ddff8  vmovaps xmm1, [rsp+0x10]
00007d0bb21ddffe  vmovaps xmm2, [rsp+0x20]
00007d0bb21de004  vmovaps xmm3, [rsp+0x30]
00007d0bb21de00a  vmovaps xmm4, [rsp+0x40]
00007d0bb21de010  vmovaps xmm5, [rsp+0x50]
00007d0bb21de016  vmovaps xmm6, [rsp+0x60]
00007d0bb21de01c  vmovaps xmm7, [rsp+0x70]
00007d0bb21de022  vmovaps xmm8, [rsp+0x80]
00007d0bb21de02b  vmovaps xmm9, [rsp+0x90]
00007d0bb21de034  vmovaps xmm10, [rsp+0xA0]
00007d0bb21de03d  vmovaps xmm11, [rsp+0xB0]
00007d0bb21de046  vmovaps xmm12, [rsp+0xC0]
00007d0bb21de04f  vmovaps xmm13, [rsp+0xD0]
00007d0bb21de058  vmovaps xmm15, [rsp+0xE0]
00007d0bb21de061  add rsp, 0xF0
00007d0bb21de068  pop r11
00007d0bb21de06a  pop r10
00007d0bb21de06c  pop r9
00007d0bb21de06e  pop r8
00007d0bb21de070  pop rsi
00007d0bb21de071  pop rdi
00007d0bb21de072  pop rdx
00007d0bb21de073  pop rcx
00007d0bb21de074  pop rax
00007d0bb21de075  add rsp, 0x08
00007d0bb21de079  jmp 0x00007D0BB21D9758
00007d0bb21de07e  sub rsp, 0x08
00007d0bb21de082  push rax
00007d0bb21de083  push rcx
00007d0bb21de084  push rdx
00007d0bb21de085  push rdi
00007d0bb21de086  push rsi
00007d0bb21de087  push r8
00007d0bb21de089  push r9
00007d0bb21de08b  push r10
00007d0bb21de08d  push r11
00007d0bb21de08f  sub rsp, 0xF0
00007d0bb21de096  vmovaps [rsp], xmm0
00007d0bb21de09b  vmovaps [rsp+0x10], xmm2
00007d0bb21de0a1  vmovaps [rsp+0x20], xmm3
00007d0bb21de0a7  vmovaps [rsp+0x30], xmm4
00007d0bb21de0ad  vmovaps [rsp+0x40], xmm5
00007d0bb21de0b3  vmovaps [rsp+0x50], xmm6
00007d0bb21de0b9  vmovaps [rsp+0x60], xmm7
00007d0bb21de0bf  vmovaps [rsp+0x70], xmm8
00007d0bb21de0c5  vmovaps [rsp+0x80], xmm9
00007d0bb21de0ce  vmovaps [rsp+0x90], xmm10
00007d0bb21de0d7  vmovaps [rsp+0xA0], xmm11
00007d0bb21de0e0  vmovaps [rsp+0xB0], xmm12
00007d0bb21de0e9  vmovaps [rsp+0xC0], xmm13
00007d0bb21de0f2  vmovaps [rsp+0xD0], xmm14
00007d0bb21de0fb  vmovaps [rsp+0xE0], xmm15
00007d0bb21de104  sub rsp, 0x30
00007d0bb21de108  movaps [rsp], xmm1
00007d0bb21de10c  movaps [rsp+0x10], xmm13
00007d0bb21de112  movaps [rsp+0x20], xmm8
00007d0bb21de118  lea rdi, [rsp]
00007d0bb21de11c  mov esi, 0x00
00007d0bb21de121  mov rax, 0x6392BBE7F530
00007d0bb21de12b  call rax
00007d0bb21de12d  movaps xmm1, [rsp]
00007d0bb21de131  add rsp, 0x30
00007d0bb21de135  vmovaps xmm0, [rsp]
00007d0bb21de13a  vmovaps xmm2, [rsp+0x10]
00007d0bb21de140  vmovaps xmm3, [rsp+0x20]
00007d0bb21de146  vmovaps xmm4, [rsp+0x30]
00007d0bb21de14c  vmovaps xmm5, [rsp+0x40]
00007d0bb21de152  vmovaps xmm6, [rsp+0x50]
00007d0bb21de158  vmovaps xmm7, [rsp+0x60]
00007d0bb21de15e  vmovaps xmm8, [rsp+0x70]
00007d0bb21de164  vmovaps xmm9, [rsp+0x80]
00007d0bb21de16d  vmovaps xmm10, [rsp+0x90]
00007d0bb21de176  vmovaps xmm11, [rsp+0xA0]
00007d0bb21de17f  vmovaps xmm12, [rsp+0xB0]
00007d0bb21de188  vmovaps xmm13, [rsp+0xC0]
00007d0bb21de191  vmovaps xmm14, [rsp+0xD0]
00007d0bb21de19a  vmovaps xmm15, [rsp+0xE0]
00007d0bb21de1a3  add rsp, 0xF0
00007d0bb21de1aa  pop r11
00007d0bb21de1ac  pop r10
00007d0bb21de1ae  pop r9
00007d0bb21de1b0  pop r8
00007d0bb21de1b2  pop rsi
00007d0bb21de1b3  pop rdi
00007d0bb21de1b4  pop rdx
00007d0bb21de1b5  pop rcx
00007d0bb21de1b6  pop rax
00007d0bb21de1b7  add rsp, 0x08
00007d0bb21de1bb  jmp 0x00007D0BB21D977A
00007d0bb21de1c0  call 0x00007D0BB200C260
00007d0bb21de1c5  jmp 0x00007D0BB21D9788
00007d0bb21de1ca  call 0x00007D0BB20DE950
00007d0bb21de1cf  jmp 0x00007D0BB21D9792
00007d0bb21de1d4  sub rsp, 0x08
00007d0bb21de1d8  push rax
00007d0bb21de1d9  push rcx
00007d0bb21de1da  push rdx
00007d0bb21de1db  push rdi
00007d0bb21de1dc  push rsi
00007d0bb21de1dd  push r8
00007d0bb21de1df  push r9
00007d0bb21de1e1  push r10
00007d0bb21de1e3  push r11
00007d0bb21de1e5  sub rsp, 0xF0
00007d0bb21de1ec  vmovaps [rsp], xmm0
00007d0bb21de1f1  vmovaps [rsp+0x10], xmm1
00007d0bb21de1f7  vmovaps [rsp+0x20], xmm2
00007d0bb21de1fd  vmovaps [rsp+0x30], xmm3
00007d0bb21de203  vmovaps [rsp+0x40], xmm4
00007d0bb21de209  vmovaps [rsp+0x50], xmm5
00007d0bb21de20f  vmovaps [rsp+0x60], xmm6
00007d0bb21de215  vmovaps [rsp+0x70], xmm7
00007d0bb21de21b  vmovaps [rsp+0x80], xmm9
00007d0bb21de224  vmovaps [rsp+0x90], xmm10
00007d0bb21de22d  vmovaps [rsp+0xA0], xmm11
00007d0bb21de236  vmovaps [rsp+0xB0], xmm12
00007d0bb21de23f  vmovaps [rsp+0xC0], xmm13
00007d0bb21de248  vmovaps [rsp+0xD0], xmm14
00007d0bb21de251  vmovaps [rsp+0xE0], xmm15
00007d0bb21de25a  sub rsp, 0x30
00007d0bb21de25e  movaps [rsp], xmm8
00007d0bb21de263  movaps [rsp+0x10], xmm15
00007d0bb21de269  movaps [rsp+0x20], xmm7
00007d0bb21de26e  lea rdi, [rsp]
00007d0bb21de272  mov esi, 0x00
00007d0bb21de277  mov rax, 0x6392BBE7F530
00007d0bb21de281  call rax
00007d0bb21de283  movaps xmm8, [rsp]
00007d0bb21de288  add rsp, 0x30
00007d0bb21de28c  vmovaps xmm0, [rsp]
00007d0bb21de291  vmovaps xmm1, [rsp+0x10]
00007d0bb21de297  vmovaps xmm2, [rsp+0x20]
00007d0bb21de29d  vmovaps xmm3, [rsp+0x30]
00007d0bb21de2a3  vmovaps xmm4, [rsp+0x40]
00007d0bb21de2a9  vmovaps xmm5, [rsp+0x50]
00007d0bb21de2af  vmovaps xmm6, [rsp+0x60]
00007d0bb21de2b5  vmovaps xmm7, [rsp+0x70]
00007d0bb21de2bb  vmovaps xmm9, [rsp+0x80]
00007d0bb21de2c4  vmovaps xmm10, [rsp+0x90]
00007d0bb21de2cd  vmovaps xmm11, [rsp+0xA0]
00007d0bb21de2d6  vmovaps xmm12, [rsp+0xB0]
00007d0bb21de2df  vmovaps xmm13, [rsp+0xC0]
00007d0bb21de2e8  vmovaps xmm14, [rsp+0xD0]
00007d0bb21de2f1  vmovaps xmm15, [rsp+0xE0]
00007d0bb21de2fa  add rsp, 0xF0
00007d0bb21de301  pop r11
00007d0bb21de303  pop r10
00007d0bb21de305  pop r9
00007d0bb21de307  pop r8
00007d0bb21de309  pop rsi
00007d0bb21de30a  pop rdi
00007d0bb21de30b  pop rdx
00007d0bb21de30c  pop rcx
00007d0bb21de30d  pop rax
00007d0bb21de30e  add rsp, 0x08
00007d0bb21de312  jmp 0x00007D0BB21D97B4
00007d0bb21de317  sub rsp, 0x08
00007d0bb21de31b  push rax
00007d0bb21de31c  push rcx
00007d0bb21de31d  push rdx
00007d0bb21de31e  push rdi
00007d0bb21de31f  push rsi
00007d0bb21de320  push r8
00007d0bb21de322  push r9
00007d0bb21de324  push r10
00007d0bb21de326  push r11
00007d0bb21de328  sub rsp, 0xF0
00007d0bb21de32f  vmovaps [rsp], xmm0
00007d0bb21de334  vmovaps [rsp+0x10], xmm1
00007d0bb21de33a  vmovaps [rsp+0x20], xmm2
00007d0bb21de340  vmovaps [rsp+0x30], xmm3
00007d0bb21de346  vmovaps [rsp+0x40], xmm4
00007d0bb21de34c  vmovaps [rsp+0x50], xmm5
00007d0bb21de352  vmovaps [rsp+0x60], xmm6
00007d0bb21de358  vmovaps [rsp+0x70], xmm8
00007d0bb21de35e  vmovaps [rsp+0x80], xmm9
00007d0bb21de367  vmovaps [rsp+0x90], xmm10
00007d0bb21de370  vmovaps [rsp+0xA0], xmm11
00007d0bb21de379  vmovaps [rsp+0xB0], xmm12
00007d0bb21de382  vmovaps [rsp+0xC0], xmm13
00007d0bb21de38b  vmovaps [rsp+0xD0], xmm14
00007d0bb21de394  vmovaps [rsp+0xE0], xmm15
00007d0bb21de39d  sub rsp, 0x30
00007d0bb21de3a1  movaps [rsp], xmm7
00007d0bb21de3a5  movaps [rsp+0x10], xmm9
00007d0bb21de3ab  movaps [rsp+0x20], xmm15
00007d0bb21de3b1  lea rdi, [rsp]
00007d0bb21de3b5  mov esi, 0x00
00007d0bb21de3ba  mov rax, 0x6392BBE7F530
00007d0bb21de3c4  call rax
00007d0bb21de3c6  movaps xmm7, [rsp]
00007d0bb21de3ca  add rsp, 0x30
00007d0bb21de3ce  vmovaps xmm0, [rsp]
00007d0bb21de3d3  vmovaps xmm1, [rsp+0x10]
00007d0bb21de3d9  vmovaps xmm2, [rsp+0x20]
00007d0bb21de3df  vmovaps xmm3, [rsp+0x30]
00007d0bb21de3e5  vmovaps xmm4, [rsp+0x40]
00007d0bb21de3eb  vmovaps xmm5, [rsp+0x50]
00007d0bb21de3f1  vmovaps xmm6, [rsp+0x60]
00007d0bb21de3f7  vmovaps xmm8, [rsp+0x70]
00007d0bb21de3fd  vmovaps xmm9, [rsp+0x80]
00007d0bb21de406  vmovaps xmm10, [rsp+0x90]
00007d0bb21de40f  vmovaps xmm11, [rsp+0xA0]
00007d0bb21de418  vmovaps xmm12, [rsp+0xB0]
00007d0bb21de421  vmovaps xmm13, [rsp+0xC0]
00007d0bb21de42a  vmovaps xmm14, [rsp+0xD0]
00007d0bb21de433  vmovaps xmm15, [rsp+0xE0]
00007d0bb21de43c  add rsp, 0xF0
00007d0bb21de443  pop r11
00007d0bb21de445  pop r10
00007d0bb21de447  pop r9
00007d0bb21de449  pop r8
00007d0bb21de44b  pop rsi
00007d0bb21de44c  pop rdi
00007d0bb21de44d  pop rdx
00007d0bb21de44e  pop rcx
00007d0bb21de44f  pop rax
00007d0bb21de450  add rsp, 0x08
00007d0bb21de454  jmp 0x00007D0BB21D97E1
00007d0bb21de459  sub rsp, 0x08
00007d0bb21de45d  push rax
00007d0bb21de45e  push rcx
00007d0bb21de45f  push rdx
00007d0bb21de460  push rdi
00007d0bb21de461  push rsi
00007d0bb21de462  push r8
00007d0bb21de464  push r9
00007d0bb21de466  push r10
00007d0bb21de468  push r11
00007d0bb21de46a  sub rsp, 0xF0
00007d0bb21de471  vmovaps [rsp], xmm0
00007d0bb21de476  vmovaps [rsp+0x10], xmm1
00007d0bb21de47c  vmovaps [rsp+0x20], xmm2
00007d0bb21de482  vmovaps [rsp+0x30], xmm3
00007d0bb21de488  vmovaps [rsp+0x40], xmm4
00007d0bb21de48e  vmovaps [rsp+0x50], xmm5
00007d0bb21de494  vmovaps [rsp+0x60], xmm6
00007d0bb21de49a  vmovaps [rsp+0x70], xmm7
00007d0bb21de4a0  vmovaps [rsp+0x80], xmm8
00007d0bb21de4a9  vmovaps [rsp+0x90], xmm10
00007d0bb21de4b2  vmovaps [rsp+0xA0], xmm11
00007d0bb21de4bb  vmovaps [rsp+0xB0], xmm12
00007d0bb21de4c4  vmovaps [rsp+0xC0], xmm13
00007d0bb21de4cd  vmovaps [rsp+0xD0], xmm14
00007d0bb21de4d6  vmovaps [rsp+0xE0], xmm15
00007d0bb21de4df  sub rsp, 0x30
00007d0bb21de4e3  movaps [rsp], xmm9
00007d0bb21de4e8  movaps [rsp+0x10], xmm13
00007d0bb21de4ee  movaps [rsp+0x20], xmm15
00007d0bb21de4f4  lea rdi, [rsp]
00007d0bb21de4f8  mov esi, 0x00
00007d0bb21de4fd  mov rax, 0x6392BBE7F530
00007d0bb21de507  call rax
00007d0bb21de509  movaps xmm9, [rsp]
00007d0bb21de50e  add rsp, 0x30
00007d0bb21de512  vmovaps xmm0, [rsp]
00007d0bb21de517  vmovaps xmm1, [rsp+0x10]
00007d0bb21de51d  vmovaps xmm2, [rsp+0x20]
00007d0bb21de523  vmovaps xmm3, [rsp+0x30]
00007d0bb21de529  vmovaps xmm4, [rsp+0x40]
00007d0bb21de52f  vmovaps xmm5, [rsp+0x50]
00007d0bb21de535  vmovaps xmm6, [rsp+0x60]
00007d0bb21de53b  vmovaps xmm7, [rsp+0x70]
00007d0bb21de541  vmovaps xmm8, [rsp+0x80]
00007d0bb21de54a  vmovaps xmm10, [rsp+0x90]
00007d0bb21de553  vmovaps xmm11, [rsp+0xA0]
00007d0bb21de55c  vmovaps xmm12, [rsp+0xB0]
00007d0bb21de565  vmovaps xmm13, [rsp+0xC0]
00007d0bb21de56e  vmovaps xmm14, [rsp+0xD0]
00007d0bb21de577  vmovaps xmm15, [rsp+0xE0]
00007d0bb21de580  add rsp, 0xF0
00007d0bb21de587  pop r11
00007d0bb21de589  pop r10
00007d0bb21de58b  pop r9
00007d0bb21de58d  pop r8
00007d0bb21de58f  pop rsi
00007d0bb21de590  pop rdi
00007d0bb21de591  pop rdx
00007d0bb21de592  pop rcx
00007d0bb21de593  pop rax
00007d0bb21de594  add rsp, 0x08
00007d0bb21de598  jmp 0x00007D0BB21D980F
00007d0bb21de59d  sub rsp, 0x08
00007d0bb21de5a1  push rax
00007d0bb21de5a2  push rcx
00007d0bb21de5a3  push rdx
00007d0bb21de5a4  push rdi
00007d0bb21de5a5  push rsi
00007d0bb21de5a6  push r8
00007d0bb21de5a8  push r9
00007d0bb21de5aa  push r10
00007d0bb21de5ac  push r11
00007d0bb21de5ae  sub rsp, 0xF0
00007d0bb21de5b5  vmovaps [rsp], xmm0
00007d0bb21de5ba  vmovaps [rsp+0x10], xmm1
00007d0bb21de5c0  vmovaps [rsp+0x20], xmm2
00007d0bb21de5c6  vmovaps [rsp+0x30], xmm3
00007d0bb21de5cc  vmovaps [rsp+0x40], xmm4
00007d0bb21de5d2  vmovaps [rsp+0x50], xmm5
00007d0bb21de5d8  vmovaps [rsp+0x60], xmm6
00007d0bb21de5de  vmovaps [rsp+0x70], xmm7
00007d0bb21de5e4  vmovaps [rsp+0x80], xmm8
00007d0bb21de5ed  vmovaps [rsp+0x90], xmm9
00007d0bb21de5f6  vmovaps [rsp+0xA0], xmm10
00007d0bb21de5ff  vmovaps [rsp+0xB0], xmm11
00007d0bb21de608  vmovaps [rsp+0xC0], xmm12
00007d0bb21de611  vmovaps [rsp+0xD0], xmm13
00007d0bb21de61a  vmovaps [rsp+0xE0], xmm14
00007d0bb21de623  sub rsp, 0x30
00007d0bb21de627  movaps [rsp], xmm15
00007d0bb21de62c  movaps [rsp+0x10], xmm11
00007d0bb21de632  movaps [rsp+0x20], xmm12
00007d0bb21de638  lea rdi, [rsp]
00007d0bb21de63c  mov esi, 0x00
00007d0bb21de641  mov rax, 0x6392BBE7F530
00007d0bb21de64b  call rax
00007d0bb21de64d  movaps xmm15, [rsp]
00007d0bb21de652  add rsp, 0x30
00007d0bb21de656  vmovaps xmm0, [rsp]
00007d0bb21de65b  vmovaps xmm1, [rsp+0x10]
00007d0bb21de661  vmovaps xmm2, [rsp+0x20]
00007d0bb21de667  vmovaps xmm3, [rsp+0x30]
00007d0bb21de66d  vmovaps xmm4, [rsp+0x40]
00007d0bb21de673  vmovaps xmm5, [rsp+0x50]
00007d0bb21de679  vmovaps xmm6, [rsp+0x60]
00007d0bb21de67f  vmovaps xmm7, [rsp+0x70]
00007d0bb21de685  vmovaps xmm8, [rsp+0x80]
00007d0bb21de68e  vmovaps xmm9, [rsp+0x90]
00007d0bb21de697  vmovaps xmm10, [rsp+0xA0]
00007d0bb21de6a0  vmovaps xmm11, [rsp+0xB0]
00007d0bb21de6a9  vmovaps xmm12, [rsp+0xC0]
00007d0bb21de6b2  vmovaps xmm13, [rsp+0xD0]
00007d0bb21de6bb  vmovaps xmm14, [rsp+0xE0]
00007d0bb21de6c4  add rsp, 0xF0
00007d0bb21de6cb  pop r11
00007d0bb21de6cd  pop r10
00007d0bb21de6cf  pop r9
00007d0bb21de6d1  pop r8
00007d0bb21de6d3  pop rsi
00007d0bb21de6d4  pop rdi
00007d0bb21de6d5  pop rdx
00007d0bb21de6d6  pop rcx
00007d0bb21de6d7  pop rax
00007d0bb21de6d8  add rsp, 0x08
00007d0bb21de6dc  jmp 0x00007D0BB21D982A
00007d0bb21de6e1  sub rsp, 0x08
00007d0bb21de6e5  push rax
00007d0bb21de6e6  push rcx
00007d0bb21de6e7  push rdx
00007d0bb21de6e8  push rdi
00007d0bb21de6e9  push rsi
00007d0bb21de6ea  push r8
00007d0bb21de6ec  push r9
00007d0bb21de6ee  push r10
00007d0bb21de6f0  push r11
00007d0bb21de6f2  sub rsp, 0xF0
00007d0bb21de6f9  vmovaps [rsp], xmm0
00007d0bb21de6fe  vmovaps [rsp+0x10], xmm1
00007d0bb21de704  vmovaps [rsp+0x20], xmm2
00007d0bb21de70a  vmovaps [rsp+0x30], xmm3
00007d0bb21de710  vmovaps [rsp+0x40], xmm4
00007d0bb21de716  vmovaps [rsp+0x50], xmm5
00007d0bb21de71c  vmovaps [rsp+0x60], xmm6
00007d0bb21de722  vmovaps [rsp+0x70], xmm7
00007d0bb21de728  vmovaps [rsp+0x80], xmm8
00007d0bb21de731  vmovaps [rsp+0x90], xmm9
00007d0bb21de73a  vmovaps [rsp+0xA0], xmm10
00007d0bb21de743  vmovaps [rsp+0xB0], xmm11
00007d0bb21de74c  vmovaps [rsp+0xC0], xmm12
00007d0bb21de755  vmovaps [rsp+0xD0], xmm14
00007d0bb21de75e  vmovaps [rsp+0xE0], xmm15
00007d0bb21de767  sub rsp, 0x30
00007d0bb21de76b  movaps [rsp], xmm13
00007d0bb21de770  movaps [rsp+0x10], xmm10
00007d0bb21de776  movaps [rsp+0x20], xmm14
00007d0bb21de77c  lea rdi, [rsp]
00007d0bb21de780  mov esi, 0x00
00007d0bb21de785  mov rax, 0x6392BBE7F530
00007d0bb21de78f  call rax
00007d0bb21de791  movaps xmm13, [rsp]
00007d0bb21de796  add rsp, 0x30
00007d0bb21de79a  vmovaps xmm0, [rsp]
00007d0bb21de79f  vmovaps xmm1, [rsp+0x10]
00007d0bb21de7a5  vmovaps xmm2, [rsp+0x20]
00007d0bb21de7ab  vmovaps xmm3, [rsp+0x30]
00007d0bb21de7b1  vmovaps xmm4, [rsp+0x40]
00007d0bb21de7b7  vmovaps xmm5, [rsp+0x50]
00007d0bb21de7bd  vmovaps xmm6, [rsp+0x60]
00007d0bb21de7c3  vmovaps xmm7, [rsp+0x70]
00007d0bb21de7c9  vmovaps xmm8, [rsp+0x80]
00007d0bb21de7d2  vmovaps xmm9, [rsp+0x90]
00007d0bb21de7db  vmovaps xmm10, [rsp+0xA0]
00007d0bb21de7e4  vmovaps xmm11, [rsp+0xB0]
00007d0bb21de7ed  vmovaps xmm12, [rsp+0xC0]
00007d0bb21de7f6  vmovaps xmm14, [rsp+0xD0]
00007d0bb21de7ff  vmovaps xmm15, [rsp+0xE0]
00007d0bb21de808  add rsp, 0xF0
00007d0bb21de80f  pop r11
00007d0bb21de811  pop r10
00007d0bb21de813  pop r9
00007d0bb21de815  pop r8
00007d0bb21de817  pop rsi
00007d0bb21de818  pop rdi
00007d0bb21de819  pop rdx
00007d0bb21de81a  pop rcx
00007d0bb21de81b  pop rax
00007d0bb21de81c  add rsp, 0x08
00007d0bb21de820  jmp 0x00007D0BB21D984D
00007d0bb21de825  sub rsp, 0x08
00007d0bb21de829  push rax
00007d0bb21de82a  push rcx
00007d0bb21de82b  push rdx
00007d0bb21de82c  push rdi
00007d0bb21de82d  push rsi
00007d0bb21de82e  push r8
00007d0bb21de830  push r9
00007d0bb21de832  push r10
00007d0bb21de834  push r11
00007d0bb21de836  sub rsp, 0xF0
00007d0bb21de83d  vmovaps [rsp], xmm0
00007d0bb21de842  vmovaps [rsp+0x10], xmm1
00007d0bb21de848  vmovaps [rsp+0x20], xmm2
00007d0bb21de84e  vmovaps [rsp+0x30], xmm3
00007d0bb21de854  vmovaps [rsp+0x40], xmm4
00007d0bb21de85a  vmovaps [rsp+0x50], xmm5
00007d0bb21de860  vmovaps [rsp+0x60], xmm6
00007d0bb21de866  vmovaps [rsp+0x70], xmm7
00007d0bb21de86c  vmovaps [rsp+0x80], xmm8
00007d0bb21de875  vmovaps [rsp+0x90], xmm9
00007d0bb21de87e  vmovaps [rsp+0xA0], xmm10
00007d0bb21de887  vmovaps [rsp+0xB0], xmm11
00007d0bb21de890  vmovaps [rsp+0xC0], xmm12
00007d0bb21de899  vmovaps [rsp+0xD0], xmm13
00007d0bb21de8a2  vmovaps [rsp+0xE0], xmm15
00007d0bb21de8ab  sub rsp, 0x30
00007d0bb21de8af  movaps [rsp], xmm14
00007d0bb21de8b4  movaps [rsp+0x10], xmm1
00007d0bb21de8b9  movaps [rsp+0x20], xmm7
00007d0bb21de8be  lea rdi, [rsp]
00007d0bb21de8c2  mov esi, 0x00
00007d0bb21de8c7  mov rax, 0x6392BBE7F530
00007d0bb21de8d1  call rax
00007d0bb21de8d3  movaps xmm14, [rsp]
00007d0bb21de8d8  add rsp, 0x30
00007d0bb21de8dc  vmovaps xmm0, [rsp]
00007d0bb21de8e1  vmovaps xmm1, [rsp+0x10]
00007d0bb21de8e7  vmovaps xmm2, [rsp+0x20]
00007d0bb21de8ed  vmovaps xmm3, [rsp+0x30]
00007d0bb21de8f3  vmovaps xmm4, [rsp+0x40]
00007d0bb21de8f9  vmovaps xmm5, [rsp+0x50]
00007d0bb21de8ff  vmovaps xmm6, [rsp+0x60]
00007d0bb21de905  vmovaps xmm7, [rsp+0x70]
00007d0bb21de90b  vmovaps xmm8, [rsp+0x80]
00007d0bb21de914  vmovaps xmm9, [rsp+0x90]
00007d0bb21de91d  vmovaps xmm10, [rsp+0xA0]
00007d0bb21de926  vmovaps xmm11, [rsp+0xB0]
00007d0bb21de92f  vmovaps xmm12, [rsp+0xC0]
00007d0bb21de938  vmovaps xmm13, [rsp+0xD0]
00007d0bb21de941  vmovaps xmm15, [rsp+0xE0]
00007d0bb21de94a  add rsp, 0xF0
00007d0bb21de951  pop r11
00007d0bb21de953  pop r10
00007d0bb21de955  pop r9
00007d0bb21de957  pop r8
00007d0bb21de959  pop rsi
00007d0bb21de95a  pop rdi
00007d0bb21de95b  pop rdx
00007d0bb21de95c  pop rcx
00007d0bb21de95d  pop rax
00007d0bb21de95e  add rsp, 0x08
00007d0bb21de962  jmp 0x00007D0BB21D9870
00007d0bb21de967  sub rsp, 0x08
00007d0bb21de96b  push rax
00007d0bb21de96c  push rcx
00007d0bb21de96d  push rdx
00007d0bb21de96e  push rdi
00007d0bb21de96f  push rsi
00007d0bb21de970  push r8
00007d0bb21de972  push r9
00007d0bb21de974  push r10
00007d0bb21de976  push r11
00007d0bb21de978  sub rsp, 0xF0
00007d0bb21de97f  vmovaps [rsp], xmm0
00007d0bb21de984  vmovaps [rsp+0x10], xmm2
00007d0bb21de98a  vmovaps [rsp+0x20], xmm3
00007d0bb21de990  vmovaps [rsp+0x30], xmm4
00007d0bb21de996  vmovaps [rsp+0x40], xmm5
00007d0bb21de99c  vmovaps [rsp+0x50], xmm6
00007d0bb21de9a2  vmovaps [rsp+0x60], xmm7
00007d0bb21de9a8  vmovaps [rsp+0x70], xmm8
00007d0bb21de9ae  vmovaps [rsp+0x80], xmm9
00007d0bb21de9b7  vmovaps [rsp+0x90], xmm10
00007d0bb21de9c0  vmovaps [rsp+0xA0], xmm11
00007d0bb21de9c9  vmovaps [rsp+0xB0], xmm12
00007d0bb21de9d2  vmovaps [rsp+0xC0], xmm13
00007d0bb21de9db  vmovaps [rsp+0xD0], xmm14
00007d0bb21de9e4  vmovaps [rsp+0xE0], xmm15
00007d0bb21de9ed  sub rsp, 0x30
00007d0bb21de9f1  movaps [rsp], xmm1
00007d0bb21de9f5  movaps [rsp+0x10], xmm8
00007d0bb21de9fb  movaps [rsp+0x20], xmm9
00007d0bb21dea01  lea rdi, [rsp]
00007d0bb21dea05  mov esi, 0x00
00007d0bb21dea0a  mov rax, 0x6392BBE7F530
00007d0bb21dea14  call rax
00007d0bb21dea16  movaps xmm1, [rsp]
00007d0bb21dea1a  add rsp, 0x30
00007d0bb21dea1e  vmovaps xmm0, [rsp]
00007d0bb21dea23  vmovaps xmm2, [rsp+0x10]
00007d0bb21dea29  vmovaps xmm3, [rsp+0x20]
00007d0bb21dea2f  vmovaps xmm4, [rsp+0x30]
00007d0bb21dea35  vmovaps xmm5, [rsp+0x40]
00007d0bb21dea3b  vmovaps xmm6, [rsp+0x50]
00007d0bb21dea41  vmovaps xmm7, [rsp+0x60]
00007d0bb21dea47  vmovaps xmm8, [rsp+0x70]
00007d0bb21dea4d  vmovaps xmm9, [rsp+0x80]
00007d0bb21dea56  vmovaps xmm10, [rsp+0x90]
00007d0bb21dea5f  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dea68  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dea71  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dea7a  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dea83  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dea8c  add rsp, 0xF0
00007d0bb21dea93  pop r11
00007d0bb21dea95  pop r10
00007d0bb21dea97  pop r9
00007d0bb21dea99  pop r8
00007d0bb21dea9b  pop rsi
00007d0bb21dea9c  pop rdi
00007d0bb21dea9d  pop rdx
00007d0bb21dea9e  pop rcx
00007d0bb21dea9f  pop rax
00007d0bb21deaa0  add rsp, 0x08
00007d0bb21deaa4  jmp 0x00007D0BB21D9892
00007d0bb21deaa9  call 0x00007D0BB20B3E40
00007d0bb21deaae  jmp 0x00007D0BB21D98A0
00007d0bb21deab3  call 0x00007D0BB200C380
00007d0bb21deab8  jmp 0x00007D0BB21D98AA
00007d0bb21deabd  call 0x00007D0BB200D600
00007d0bb21deac2  jmp 0x00007D0BB21D98B4
00007d0bb21deac7  call 0x00007D0BB1FFF540
00007d0bb21deacc  jmp 0x00007D0BB21D98BE
00007d0bb21dead1  int3
00007d0bb21dead2  nop [rax+rax*1], ax
00007d0bb21deadb  nop [rax+rax*1], eax
00007d0bb21deae0  mov eax, [r15+0x48]
00007d0bb21deae4  lea r14d, [eax+0x01]
00007d0bb21deae9  mov [rsp+0x10], r14d
00007d0bb21deaee  mov r14d, r14d
00007d0bb21deaf1  mov [r15+0x48], r14
00007d0bb21deaf5  xor eax, eax
00007d0bb21deaf7  mov r14d, [rsp+0x10]
00007d0bb21deafc  cmp r14d, 0x1F4
00007d0bb21deb03  cmc
00007d0bb21deb04  lahf
00007d0bb21deb05  seto al
00007d0bb21deb08  mov [r15+0x108], eax
00007d0bb21deb0f  mov eax, [r15+0x108]
00007d0bb21deb16  sahf
00007d0bb21deb17  jnz 0x00007D0BB21DEB49
00007d0bb21deb19  cmp dword ptr [r15+0x318], 0x00
00007d0bb21deb21  jz 0x00007D0BB21E4C90
00007d0bb21deb27  nop [rax+rax*1], ax
00007d0bb21deb30  nop [rax+rax*1], eax
00007d0bb21deb38  mov eax, 0x4106DC
00007d0bb21deb3d  mov [r15+0x100], rax
00007d0bb21deb44  jmp 0x00007D0BB1FFE110
00007d0bb21deb49  cmp dword ptr [r15+0x318], 0x00
00007d0bb21deb51  jz 0x00007D0BB21DEB80
00007d0bb21deb57  nop [rax+rax*1], ax
00007d0bb21deb60  nop [rax+rax*1], eax
00007d0bb21deb68  mov eax, 0x410500
00007d0bb21deb6d  mov [r15+0x100], rax
00007d0bb21deb74  jmp 0x00007D0BB1FFE110
00007d0bb21deb79  int3
00007d0bb21deb7a  int3
00007d0bb21deb7b  nop [rax+rax*1], eax
00007d0bb21deb80  mov rax, [r15+0x40]
00007d0bb21deb84  movaps xmm1, [r15+0x1D0]
00007d0bb21deb8c  vmovaps [rsp+0x10], xmm1
00007d0bb21deb92  vmovaps xmm15, [rsp+0x10]
00007d0bb21deb98  por xmm1, xmm15
00007d0bb21deb9d  movaps xmm14, [r15+0x1A0]
00007d0bb21deba5  vmovaps [rsp+0x10], xmm14
00007d0bb21debab  vmovaps xmm13, [rsp+0x10]
00007d0bb21debb1  por xmm14, xmm13
00007d0bb21debb6  lea r14, [rax+0x30]
00007d0bb21debba  mov r12, [r13+r14*1]
00007d0bb21debbf  lea r14, [rax+0x38]
00007d0bb21debc3  mov r11, [r13+r14*1]
00007d0bb21debc8  movq xmm13, r12
00007d0bb21debcd  movq xmm12, r11
00007d0bb21debd2  movq xmm13, xmm13
00007d0bb21debd7  vmovaps [rsp+0x10], xmm13
00007d0bb21debdd  movq xmm13, xmm13
00007d0bb21debe2  movaps [r15+0x130], xmm13
00007d0bb21debea  movq xmm12, xmm12
00007d0bb21debef  vmovaps [rsp+0x20], xmm12
00007d0bb21debf5  movq xmm12, xmm12
00007d0bb21debfa  movaps [r15+0x280], xmm12
00007d0bb21dec02  movaps xmm13, [r15+0x270]
00007d0bb21dec0a  vmovaps [rsp+0x30], xmm13
00007d0bb21dec10  vmovaps xmm12, [rsp+0x30]
00007d0bb21dec16  por xmm13, xmm12
00007d0bb21dec1b  lea r14, [rax+0x20]
00007d0bb21dec1f  mov r12, [r13+r14*1]
00007d0bb21dec24  lea r14, [rax+0x28]
00007d0bb21dec28  mov r11, [r13+r14*1]
00007d0bb21dec2d  movq xmm12, r12
00007d0bb21dec32  movq xmm11, r11
00007d0bb21dec37  movq xmm12, xmm12
00007d0bb21dec3c  vmovaps [rsp+0x30], xmm12
00007d0bb21dec42  movq xmm12, xmm12
00007d0bb21dec47  movaps [r15+0x150], xmm12
00007d0bb21dec4f  movq xmm11, xmm11
00007d0bb21dec54  vmovaps [rsp+0x40], xmm11
00007d0bb21dec5a  movq xmm11, xmm11
00007d0bb21dec5f  movaps [r15+0x140], xmm11
00007d0bb21dec67  lea r14, [rax+0x10]
00007d0bb21dec6b  mov r12, [r13+r14*1]
00007d0bb21dec70  lea r14, [rax+0x18]
00007d0bb21dec74  mov r11, [r13+r14*1]
00007d0bb21dec79  movq xmm12, r12
00007d0bb21dec7e  movq xmm11, r11
00007d0bb21dec83  movq xmm12, xmm12
00007d0bb21dec88  vmovaps [rsp+0x50], xmm12
00007d0bb21dec8e  movq xmm12, xmm12
00007d0bb21dec93  movaps [r15+0x170], xmm12
00007d0bb21dec9b  movq xmm11, xmm11
00007d0bb21deca0  vmovaps [rsp+0x60], xmm11
00007d0bb21deca6  movq xmm11, xmm11
00007d0bb21decab  movaps [r15+0x160], xmm11
00007d0bb21decb3  mov r14, [r13+rax*1]
00007d0bb21decb8  vmovq xmm12, r14
00007d0bb21decbd  vpbroadcastq xmm12, xmm12
00007d0bb21decc2  lea r14, [rax+0x08]
00007d0bb21decc6  mov rax, [r13+r14*1]
00007d0bb21deccb  movq xmm11, rax
00007d0bb21decd0  movaps [r15+0x230], xmm11
00007d0bb21decd8  mov rax, [r15+0xF8]
00007d0bb21decdf  lea r14, [rax+0x50]
00007d0bb21dece3  movups xmm11, [r13+r14*1]
00007d0bb21dece9  lea r14, [rax+0x60]
00007d0bb21deced  movups xmm10, [r13+r14*1]
00007d0bb21decf3  lea r14, [rax+0x30]
00007d0bb21decf7  movups xmm9, [r13+r14*1]
00007d0bb21decfd  mov r14, [r15+0x50]
00007d0bb21ded01  mov [r15+0x60], r14
00007d0bb21ded05  mov qword ptr [r15+0x58], 0x40
00007d0bb21ded0d  movaps xmm8, xmm12
00007d0bb21ded11  mulpd xmm8, xmm15
00007d0bb21ded16  vcmppd xmm7, xmm8, xmm8, 0x03
00007d0bb21ded1c  ptest xmm7, xmm7
00007d0bb21ded21  jnz 0x00007D0BB21DFB4A
00007d0bb21ded27  movq xmm15, qword ptr [r15+0x230]
00007d0bb21ded30  vmovaps [rsp+0x70], xmm15
00007d0bb21ded36  vpermilpd xmm15, xmm15, 0x00
00007d0bb21ded3c  movaps xmm7, xmm9
00007d0bb21ded40  mulpd xmm7, xmm15
00007d0bb21ded45  vcmppd xmm6, xmm7, xmm7, 0x03
00007d0bb21ded4a  ptest xmm6, xmm6
00007d0bb21ded4f  jnz 0x00007D0BB21DFC8E
00007d0bb21ded55  vxorps xmm15, xmm15, xmm15
00007d0bb21ded5a  vpbroadcastq xmm15, xmm15
00007d0bb21ded5f  movaps xmm9, xmm12
00007d0bb21ded63  mulpd xmm9, xmm10
00007d0bb21ded68  vcmppd xmm6, xmm9, xmm9, 0x03
00007d0bb21ded6e  ptest xmm6, xmm6
00007d0bb21ded73  jnz 0x00007D0BB21DFDD0
00007d0bb21ded79  movaps xmm10, xmm12
00007d0bb21ded7d  mulpd xmm10, xmm11
00007d0bb21ded82  vcmppd xmm6, xmm10, xmm10, 0x03
00007d0bb21ded88  ptest xmm6, xmm6
00007d0bb21ded8d  jnz 0x00007D0BB21DFF14
00007d0bb21ded93  movaps xmm11, [r15+0x1F0]
00007d0bb21ded9b  movaps xmm6, xmm12
00007d0bb21ded9f  mulpd xmm6, xmm11
00007d0bb21deda4  vcmppd xmm5, xmm6, xmm6, 0x03
00007d0bb21deda9  ptest xmm5, xmm5
00007d0bb21dedae  jnz 0x00007D0BB21E0058
00007d0bb21dedb4  movaps xmm12, [r15+0x2A0]
00007d0bb21dedbc  vmovaps [rsp+0x80], xmm12
00007d0bb21dedc5  vmovaps xmm11, [rsp+0x80]
00007d0bb21dedce  por xmm12, xmm11
00007d0bb21dedd3  movaps xmm11, [r15+0x250]
00007d0bb21deddb  vmovaps [rsp+0x80], xmm11
00007d0bb21dede4  vmovaps xmm5, [rsp+0x80]
00007d0bb21deded  por xmm11, xmm5
00007d0bb21dedf2  vmovaps xmm4, [rsp+0x70]
00007d0bb21dedf8  vpermilpd xmm4, xmm4, 0x00
00007d0bb21dedfe  movaps xmm3, xmm5
00007d0bb21dee01  mulpd xmm3, xmm4
00007d0bb21dee05  vcmppd xmm2, xmm3, xmm3, 0x03
00007d0bb21dee0a  ptest xmm2, xmm2
00007d0bb21dee0f  jnz 0x00007D0BB21E019A
00007d0bb21dee15  mov [rsp+0x80], rax
00007d0bb21dee1d  xor eax, eax
00007d0bb21dee1f  mov r12d, 0x40
00007d0bb21dee25  mov r11d, 0x200
00007d0bb21dee2b  cmp r12, r11
00007d0bb21dee2e  cmc
00007d0bb21dee2f  lahf
00007d0bb21dee30  seto al
00007d0bb21dee33  mov [r15+0x108], eax
00007d0bb21dee3a  movaps xmm5, xmm8
00007d0bb21dee3e  addpd xmm5, xmm15
00007d0bb21dee43  vcmppd xmm4, xmm5, xmm5, 0x03
00007d0bb21dee48  ptest xmm4, xmm4
00007d0bb21dee4d  jnz 0x00007D0BB21E02DA
00007d0bb21dee53  movaps xmm8, [r15+0x1B0]
00007d0bb21dee5b  movaps xmm4, xmm9
00007d0bb21dee5f  addpd xmm4, xmm8
00007d0bb21dee64  vcmppd xmm2, xmm4, xmm4, 0x03
00007d0bb21dee69  ptest xmm2, xmm2
00007d0bb21dee6e  jnz 0x00007D0BB21E041C
00007d0bb21dee74  movaps xmm9, xmm10
00007d0bb21dee78  addpd xmm9, xmm8
00007d0bb21dee7d  vcmppd xmm2, xmm9, xmm9, 0x03
00007d0bb21dee83  ptest xmm2, xmm2
00007d0bb21dee88  jnz 0x00007D0BB21E055E
00007d0bb21dee8e  movaps xmm10, [r15+0x2F0]
00007d0bb21dee96  vmovaps [rsp+0x90], xmm10
00007d0bb21dee9f  vmovaps xmm8, [rsp+0x90]
00007d0bb21deea8  por xmm10, xmm8
00007d0bb21deead  movaps xmm8, [r15+0x2E0]
00007d0bb21deeb5  vmovaps [rsp+0x90], xmm8
00007d0bb21deebe  vmovaps xmm2, [rsp+0x90]
00007d0bb21deec7  por xmm8, xmm2
00007d0bb21deecc  movaps xmm2, [r15+0x2D0]
00007d0bb21deed4  vmovaps [rsp+0x90], xmm2
00007d0bb21deedd  vmovaps [rsp+0xA0], xmm1
00007d0bb21deee6  vmovaps xmm1, [rsp+0x90]
00007d0bb21deeef  por xmm2, xmm1
00007d0bb21deef3  movaps xmm1, [r15+0x200]
00007d0bb21deefb  vmovaps [rsp+0x90], xmm1
00007d0bb21def04  vmovaps [rsp+0xB0], xmm15
00007d0bb21def0d  vmovaps xmm15, [rsp+0x90]
00007d0bb21def16  por xmm1, xmm15
00007d0bb21def1b  movaps xmm15, [r15+0x1C0]
00007d0bb21def23  vmovaps [rsp+0x90], xmm15
00007d0bb21def2c  vmovaps [rsp+0xC0], xmm1
00007d0bb21def35  vmovaps xmm1, [rsp+0x90]
00007d0bb21def3e  por xmm15, xmm1
00007d0bb21def43  movaps xmm1, [r15+0x190]
00007d0bb21def4b  vmovaps [rsp+0x90], xmm1
00007d0bb21def54  vmovaps [rsp+0xD0], xmm15
00007d0bb21def5d  vmovaps xmm15, [rsp+0x90]
00007d0bb21def66  por xmm1, xmm15
00007d0bb21def6b  movaps xmm15, [r15+0x300]
00007d0bb21def73  vmovaps [rsp+0x90], xmm15
00007d0bb21def7c  vmovaps [rsp+0xE0], xmm1
00007d0bb21def85  vmovaps xmm1, [rsp+0x90]
00007d0bb21def8e  por xmm15, xmm1
00007d0bb21def93  mov rax, [rsp+0x80]
00007d0bb21def9b  lea r12, [rax+0xA0]
00007d0bb21defa2  movups xmm1, [r13+r12*1]
00007d0bb21defa8  lea r12, [rax+0xB0]
00007d0bb21defaf  vmovaps [rsp+0x80], xmm1
00007d0bb21defb8  movups xmm1, [r13+r12*1]
00007d0bb21defbe  vmovaps [rsp+0x90], xmm1
00007d0bb21defc7  vmovaps [rsp+0xF0], xmm15
00007d0bb21defd0  vmovaps xmm15, [rsp+0xB0]
00007d0bb21defd9  vmovaps [rsp+0xB0], xmm14
00007d0bb21defe2  movaps xmm1, xmm6
00007d0bb21defe5  addpd xmm1, xmm15
00007d0bb21defea  vcmppd xmm14, xmm1, xmm1, 0x03
00007d0bb21defef  ptest xmm14, xmm14
00007d0bb21deff5  jnz 0x00007D0BB21E06B6
00007d0bb21deffb  lea r12, [rax+0xF0]
00007d0bb21df002  movups xmm15, [r13+r12*1]
00007d0bb21df008  movaps xmm14, xmm4
00007d0bb21df00c  addpd xmm14, xmm3
00007d0bb21df011  vcmppd xmm6, xmm14, xmm14, 0x03
00007d0bb21df017  ptest xmm6, xmm6
00007d0bb21df01c  jnz 0x00007D0BB21E0801
00007d0bb21df022  movaps xmm6, xmm9
00007d0bb21df026  addpd xmm6, xmm7
00007d0bb21df02a  vcmppd xmm4, xmm6, xmm6, 0x03
00007d0bb21df02f  ptest xmm4, xmm4
00007d0bb21df034  jnz 0x00007D0BB21E0943
00007d0bb21df03a  vmovaps xmm9, [rsp+0x70]
00007d0bb21df040  vpermilpd xmm9, xmm9, 0x00
00007d0bb21df046  vmovaps xmm4, [rsp+0x90]
00007d0bb21df04f  movaps xmm7, xmm4
00007d0bb21df052  mulpd xmm7, xmm9
00007d0bb21df057  vcmppd xmm3, xmm7, xmm7, 0x03
00007d0bb21df05c  ptest xmm3, xmm3
00007d0bb21df061  jnz 0x00007D0BB21E0A84
00007d0bb21df067  vmovaps xmm9, [rsp+0x50]
00007d0bb21df06d  vpermilpd xmm9, xmm9, 0x00
00007d0bb21df073  movaps xmm4, xmm15
00007d0bb21df077  mulpd xmm4, xmm9
00007d0bb21df07c  vcmppd xmm3, xmm4, xmm4, 0x03
00007d0bb21df081  ptest xmm3, xmm3
00007d0bb21df086  jnz 0x00007D0BB21E0BC5
00007d0bb21df08c  lea r12, [rax+0xE0]
00007d0bb21df093  movups xmm15, [r13+r12*1]
00007d0bb21df099  vmovaps xmm9, [rsp+0x70]
00007d0bb21df09f  vpermilpd xmm9, xmm9, 0x00
00007d0bb21df0a5  vmovaps [rsp+0x70], xmm1
00007d0bb21df0ab  vmovaps xmm1, [rsp+0x80]
00007d0bb21df0b4  vmovaps [rsp+0x80], xmm15
00007d0bb21df0bd  movaps xmm3, xmm1
00007d0bb21df0c0  mulpd xmm3, xmm9
00007d0bb21df0c5  vcmppd xmm15, xmm3, xmm3, 0x03
00007d0bb21df0ca  ptest xmm15, xmm15
00007d0bb21df0d0  jnz 0x00007D0BB21E0D11
00007d0bb21df0d6  vmovaps xmm1, [rsp+0xF0]
00007d0bb21df0df  vmovaps xmm15, [rsp+0xF0]
00007d0bb21df0e8  por xmm1, xmm15
00007d0bb21df0ed  movaps [r15+0x300], xmm1
00007d0bb21df0f5  vmovaps xmm15, [rsp+0xE0]
00007d0bb21df0fe  vmovaps xmm9, [rsp+0xE0]
00007d0bb21df107  por xmm15, xmm9
00007d0bb21df10c  movaps [r15+0x190], xmm15
00007d0bb21df114  vmovaps xmm9, [rsp+0x50]
00007d0bb21df11a  vpermilpd xmm9, xmm9, 0x00
00007d0bb21df120  vmovaps [rsp+0x90], xmm1
00007d0bb21df129  vmovaps [rsp+0xE0], xmm15
00007d0bb21df132  vmovaps xmm15, [rsp+0x80]
00007d0bb21df13b  vmovaps [rsp+0x80], xmm14
00007d0bb21df144  movaps xmm1, xmm15
00007d0bb21df148  mulpd xmm1, xmm9
00007d0bb21df14d  vcmppd xmm14, xmm1, xmm1, 0x03
00007d0bb21df152  ptest xmm14, xmm14
00007d0bb21df158  jnz 0x00007D0BB21E0E52
00007d0bb21df15e  lea r12, [rax+0x90]
00007d0bb21df165  movups xmm15, [r13+r12*1]
00007d0bb21df16b  vmovaps xmm14, [rsp+0xD0]
00007d0bb21df174  vmovaps xmm9, [rsp+0xD0]
00007d0bb21df17d  por xmm14, xmm9
00007d0bb21df182  movaps [r15+0x1C0], xmm14
00007d0bb21df18a  vmovaps xmm9, [rsp+0xC0]
00007d0bb21df193  vmovaps [rsp+0xD0], xmm1
00007d0bb21df19c  vmovaps xmm1, [rsp+0xC0]
00007d0bb21df1a5  por xmm9, xmm1
00007d0bb21df1aa  movaps [r15+0x200], xmm9
00007d0bb21df1b2  vmovaps [rsp+0xC0], xmm2
00007d0bb21df1bb  vmovaps xmm1, [rsp+0xC0]
00007d0bb21df1c4  por xmm2, xmm1
00007d0bb21df1c8  movaps [r15+0x2D0], xmm2
00007d0bb21df1d0  vmovaps [rsp+0xC0], xmm8
00007d0bb21df1d9  vmovaps xmm1, [rsp+0xC0]
00007d0bb21df1e2  por xmm8, xmm1
00007d0bb21df1e7  movaps [r15+0x2E0], xmm8
00007d0bb21df1ef  vmovaps [rsp+0xC0], xmm15
00007d0bb21df1f8  movaps xmm1, xmm5
00007d0bb21df1fb  addpd xmm1, xmm7
00007d0bb21df1ff  vcmppd xmm15, xmm1, xmm1, 0x03
00007d0bb21df204  ptest xmm15, xmm15
00007d0bb21df20a  jnz 0x00007D0BB21E0F9E
00007d0bb21df210  vmovaps xmm15, [rsp+0x50]
00007d0bb21df216  vpermilpd xmm15, xmm15, 0x00
00007d0bb21df21c  vmovaps xmm5, [rsp+0xC0]
00007d0bb21df225  vmovaps [rsp+0xC0], xmm1
00007d0bb21df22e  movaps xmm7, xmm5
00007d0bb21df231  mulpd xmm7, xmm15
00007d0bb21df236  vcmppd xmm1, xmm7, xmm7, 0x03
00007d0bb21df23b  ptest xmm1, xmm1
00007d0bb21df240  jnz 0x00007D0BB21E10DE
00007d0bb21df246  lea r12, [rax+0x80]
00007d0bb21df24d  movups xmm1, [r13+r12*1]
00007d0bb21df253  vmovaps xmm5, [rsp+0x70]
00007d0bb21df259  vmovaps [rsp+0x70], xmm1
00007d0bb21df25f  movaps xmm15, xmm5
00007d0bb21df263  addpd xmm15, xmm3
00007d0bb21df268  vcmppd xmm1, xmm15, xmm15, 0x03
00007d0bb21df26e  ptest xmm1, xmm1
00007d0bb21df273  jnz 0x00007D0BB21E1229
00007d0bb21df279  vmovaps xmm5, [rsp+0x80]
00007d0bb21df282  movaps xmm1, xmm5
00007d0bb21df285  addpd xmm1, xmm4
00007d0bb21df289  vcmppd xmm3, xmm1, xmm1, 0x03
00007d0bb21df28e  ptest xmm3, xmm3
00007d0bb21df293  jnz 0x00007D0BB21E136B
00007d0bb21df299  vmovaps [rsp+0x80], xmm10
00007d0bb21df2a2  vmovaps xmm5, [rsp+0x80]
00007d0bb21df2ab  por xmm10, xmm5
00007d0bb21df2b0  movaps [r15+0x2F0], xmm10
00007d0bb21df2b8  vmovaps xmm5, [rsp+0x50]
00007d0bb21df2be  vpermilpd xmm5, xmm5, 0x00
00007d0bb21df2c4  vmovaps xmm3, [rsp+0x70]
00007d0bb21df2ca  vmovaps [rsp+0x50], xmm1
00007d0bb21df2d0  movaps xmm4, xmm3
00007d0bb21df2d3  mulpd xmm4, xmm5
00007d0bb21df2d7  vcmppd xmm1, xmm4, xmm4, 0x03
00007d0bb21df2dc  ptest xmm1, xmm1
00007d0bb21df2e1  jnz 0x00007D0BB21E14AB
00007d0bb21df2e7  lea r12, [rax+0xD0]
00007d0bb21df2ee  movups xmm1, [r13+r12*1]
00007d0bb21df2f4  vmovaps xmm3, [rsp+0xD0]
00007d0bb21df2fd  vmovaps [rsp+0x70], xmm1
00007d0bb21df303  movaps xmm5, xmm6
00007d0bb21df306  addpd xmm5, xmm3
00007d0bb21df30a  vcmppd xmm1, xmm5, xmm5, 0x03
00007d0bb21df30f  ptest xmm1, xmm1
00007d0bb21df314  jnz 0x00007D0BB21E15F5
00007d0bb21df31a  vmovaps xmm1, [rsp+0x60]
00007d0bb21df320  vpermilpd xmm1, xmm1, 0x00
00007d0bb21df326  movaps xmm6, xmm9
00007d0bb21df32a  mulpd xmm6, xmm1
00007d0bb21df32e  vcmppd xmm3, xmm6, xmm6, 0x03
00007d0bb21df333  ptest xmm3, xmm3
00007d0bb21df338  jnz 0x00007D0BB21E1735
00007d0bb21df33e  movaps [r15+0x260], xmm6
00007d0bb21df346  vxorps xmm1, xmm1, xmm1
00007d0bb21df34a  vpbroadcastq xmm1, xmm1
00007d0bb21df34f  movaps [r15+0x1B0], xmm1
00007d0bb21df357  vmovaps xmm1, [rsp+0x60]
00007d0bb21df35d  vpermilpd xmm1, xmm1, 0x00
00007d0bb21df363  vmovaps xmm3, [rsp+0x70]
00007d0bb21df369  vmovaps [rsp+0x70], xmm15
00007d0bb21df36f  movaps xmm9, xmm3
00007d0bb21df373  mulpd xmm9, xmm1
00007d0bb21df378  vcmppd xmm15, xmm9, xmm9, 0x03
00007d0bb21df37e  ptest xmm15, xmm15
00007d0bb21df384  jnz 0x00007D0BB21E1876
00007d0bb21df38a  lea r12, [rax+0xC0]
00007d0bb21df391  movups xmm1, [r13+r12*1]
00007d0bb21df397  vmovaps xmm3, [rsp+0xC0]
00007d0bb21df3a0  vmovaps [rsp+0x80], xmm1
00007d0bb21df3a9  movaps xmm15, xmm3
00007d0bb21df3ad  addpd xmm15, xmm7
00007d0bb21df3b2  vcmppd xmm1, xmm15, xmm15, 0x03
00007d0bb21df3b8  ptest xmm1, xmm1
00007d0bb21df3bd  jnz 0x00007D0BB21E19C2
00007d0bb21df3c3  vmovaps [rsp+0xC0], xmm13
00007d0bb21df3cc  vmovaps xmm1, [rsp+0xC0]
00007d0bb21df3d5  por xmm13, xmm1
00007d0bb21df3da  movaps [r15+0x270], xmm13
00007d0bb21df3e2  vmovaps xmm1, [rsp+0xB0]
00007d0bb21df3eb  vmovaps xmm7, [rsp+0xB0]
00007d0bb21df3f4  por xmm1, xmm7
00007d0bb21df3f8  movaps [r15+0x1A0], xmm1
00007d0bb21df400  vmovaps xmm1, [rsp+0x60]
00007d0bb21df406  vpermilpd xmm1, xmm1, 0x00
00007d0bb21df40c  vmovaps [rsp+0xB0], xmm1
00007d0bb21df415  vmovaps xmm1, [rsp+0x80]
00007d0bb21df41e  vmovaps [rsp+0x80], xmm15
00007d0bb21df427  vmovaps xmm15, [rsp+0xB0]
00007d0bb21df430  vmovaps [rsp+0xB0], xmm14
00007d0bb21df439  movaps xmm3, xmm1
00007d0bb21df43c  mulpd xmm3, xmm15
00007d0bb21df441  vcmppd xmm14, xmm3, xmm3, 0x03
00007d0bb21df446  ptest xmm14, xmm14
00007d0bb21df44c  jnz 0x00007D0BB21E1B04
00007d0bb21df452  lea r12, [rax+0x20]
00007d0bb21df456  movups xmm1, [r13+r12*1]
00007d0bb21df45c  movaps [r15+0x110], xmm1
00007d0bb21df464  vmovaps xmm14, [rsp+0x70]
00007d0bb21df46a  vmovaps [rsp+0x70], xmm1
00007d0bb21df470  movaps xmm15, xmm14
00007d0bb21df474  addpd xmm15, xmm4
00007d0bb21df479  vcmppd xmm1, xmm15, xmm15, 0x03
00007d0bb21df47f  ptest xmm1, xmm1
00007d0bb21df484  jnz 0x00007D0BB21E1C4F
00007d0bb21df48a  vmovaps xmm1, [rsp+0x60]
00007d0bb21df490  vpermilpd xmm1, xmm1, 0x00
00007d0bb21df496  movaps xmm14, xmm2
00007d0bb21df49a  mulpd xmm14, xmm1
00007d0bb21df49f  vcmppd xmm4, xmm14, xmm14, 0x03
00007d0bb21df4a5  ptest xmm4, xmm4
00007d0bb21df4aa  jnz 0x00007D0BB21E1D92
00007d0bb21df4b0  vmovaps xmm4, [rsp+0x50]
00007d0bb21df4b6  movaps xmm1, xmm4
00007d0bb21df4b9  addpd xmm1, xmm9
00007d0bb21df4be  vcmppd xmm2, xmm1, xmm1, 0x03
00007d0bb21df4c3  ptest xmm2, xmm2
00007d0bb21df4c8  jnz 0x00007D0BB21E1ED4
00007d0bb21df4ce  vmovaps xmm9, [rsp+0x30]
00007d0bb21df4d4  vpermilpd xmm9, xmm9, 0x00
00007d0bb21df4da  vmovaps xmm2, [rsp+0x70]
00007d0bb21df4e0  vmovaps [rsp+0x50], xmm1
00007d0bb21df4e6  movaps xmm4, xmm2
00007d0bb21df4e9  mulpd xmm4, xmm9
00007d0bb21df4ee  vcmppd xmm1, xmm4, xmm4, 0x03
00007d0bb21df4f3  ptest xmm1, xmm1
00007d0bb21df4f8  jnz 0x00007D0BB21E2015
00007d0bb21df4fe  vmovaps xmm1, [rsp+0x30]
00007d0bb21df504  vpermilpd xmm1, xmm1, 0x00
00007d0bb21df50a  vmovaps xmm2, [rsp+0x90]
00007d0bb21df513  vmovaps [rsp+0x60], xmm15
00007d0bb21df519  movaps xmm9, xmm2
00007d0bb21df51d  mulpd xmm9, xmm1
00007d0bb21df522  vcmppd xmm15, xmm9, xmm9, 0x03
00007d0bb21df528  ptest xmm15, xmm15
00007d0bb21df52e  jnz 0x00007D0BB21E2156
00007d0bb21df534  vmovaps xmm15, [rsp+0x80]
00007d0bb21df53d  movaps xmm1, xmm15
00007d0bb21df541  addpd xmm1, xmm6
00007d0bb21df545  vcmppd xmm2, xmm1, xmm1, 0x03
00007d0bb21df54a  ptest xmm2, xmm2
00007d0bb21df54f  jnz 0x00007D0BB21E2298
00007d0bb21df555  movaps xmm15, xmm5
00007d0bb21df559  addpd xmm15, xmm3
00007d0bb21df55e  vcmppd xmm6, xmm15, xmm15, 0x03
00007d0bb21df564  ptest xmm6, xmm6
00007d0bb21df569  jnz 0x00007D0BB21E23D9
00007d0bb21df56f  vmovaps xmm6, [rsp+0x30]
00007d0bb21df575  vpermilpd xmm6, xmm6, 0x00
00007d0bb21df57b  movaps xmm5, xmm8
00007d0bb21df57f  mulpd xmm5, xmm6
00007d0bb21df583  vcmppd xmm3, xmm5, xmm5, 0x03
00007d0bb21df588  ptest xmm3, xmm3
00007d0bb21df58d  jnz 0x00007D0BB21E251B
00007d0bb21df593  vmovaps xmm8, [rsp+0x30]
00007d0bb21df599  vpermilpd xmm8, xmm8, 0x00
00007d0bb21df59f  movaps xmm6, xmm10
00007d0bb21df5a3  mulpd xmm6, xmm8
00007d0bb21df5a8  vcmppd xmm3, xmm6, xmm6, 0x03
00007d0bb21df5ad  ptest xmm3, xmm3
00007d0bb21df5b2  jnz 0x00007D0BB21E265C
00007d0bb21df5b8  vmovaps xmm8, [rsp+0x60]
00007d0bb21df5be  movaps xmm10, xmm8
00007d0bb21df5c2  addpd xmm10, xmm14
00007d0bb21df5c7  vcmppd xmm3, xmm10, xmm10, 0x03
00007d0bb21df5cd  ptest xmm3, xmm3
00007d0bb21df5d2  jnz 0x00007D0BB21E279E
00007d0bb21df5d8  vmovaps xmm8, [rsp+0x50]
00007d0bb21df5de  movaps xmm14, xmm8
00007d0bb21df5e2  addpd xmm14, xmm4
00007d0bb21df5e7  vcmppd xmm3, xmm14, xmm14, 0x03
00007d0bb21df5ed  ptest xmm3, xmm3
00007d0bb21df5f2  jnz 0x00007D0BB21E28E2
00007d0bb21df5f8  vmovaps xmm8, [rsp+0x40]
00007d0bb21df5fe  vpermilpd xmm8, xmm8, 0x00
00007d0bb21df604  movaps xmm4, xmm13
00007d0bb21df608  mulpd xmm4, xmm8
00007d0bb21df60d  vcmppd xmm3, xmm4, xmm4, 0x03
00007d0bb21df612  ptest xmm3, xmm3
00007d0bb21df617  jnz 0x00007D0BB21E2A25
00007d0bb21df61d  movaps xmm13, xmm15
00007d0bb21df621  addpd xmm13, xmm9
00007d0bb21df626  vcmppd xmm8, xmm13, xmm13, 0x03
00007d0bb21df62c  ptest xmm8, xmm8
00007d0bb21df632  jnz 0x00007D0BB21E2B67
00007d0bb21df638  movaps xmm15, xmm1
00007d0bb21df63c  addpd xmm15, xmm5
00007d0bb21df641  vcmppd xmm9, xmm15, xmm15, 0x03
00007d0bb21df647  ptest xmm9, xmm9
00007d0bb21df64d  jnz 0x00007D0BB21E2CAB
00007d0bb21df653  vmovaps [rsp+0x30], xmm11
00007d0bb21df659  vmovaps xmm1, [rsp+0x30]
00007d0bb21df65f  por xmm11, xmm1
00007d0bb21df664  movaps [r15+0x250], xmm11
00007d0bb21df66c  vmovaps [rsp+0x30], xmm12
00007d0bb21df672  vmovaps xmm1, [rsp+0x30]
00007d0bb21df678  por xmm12, xmm1
00007d0bb21df67d  movaps [r15+0x2A0], xmm12
00007d0bb21df685  vmovaps xmm1, [rsp+0xA0]
00007d0bb21df68e  vmovaps xmm11, [rsp+0xA0]
00007d0bb21df697  por xmm1, xmm11
00007d0bb21df69c  movaps [r15+0x1D0], xmm1
00007d0bb21df6a4  lea r12, [rax+0x40]
00007d0bb21df6a8  movups xmm1, [r13+r12*1]
00007d0bb21df6ae  movaps [r15+0x2C0], xmm1
00007d0bb21df6b6  vmovaps xmm11, [rsp+0x40]
00007d0bb21df6bc  vpermilpd xmm11, xmm11, 0x00
00007d0bb21df6c2  vmovaps xmm8, [rsp+0xE0]
00007d0bb21df6cb  movaps xmm9, xmm8
00007d0bb21df6cf  mulpd xmm9, xmm11
00007d0bb21df6d4  vcmppd xmm5, xmm9, xmm9, 0x03
00007d0bb21df6da  ptest xmm5, xmm5
00007d0bb21df6df  jnz 0x00007D0BB21E2DF7
00007d0bb21df6e5  movaps xmm11, xmm10
00007d0bb21df6e9  addpd xmm11, xmm6
00007d0bb21df6ee  vcmppd xmm8, xmm11, xmm11, 0x03
00007d0bb21df6f4  ptest xmm8, xmm8
00007d0bb21df6fa  jnz 0x00007D0BB21E2F3B
00007d0bb21df700  movaps xmm10, xmm14
00007d0bb21df704  addpd xmm10, xmm4
00007d0bb21df709  vcmppd xmm8, xmm10, xmm10, 0x03
00007d0bb21df70f  ptest xmm8, xmm8
00007d0bb21df715  jnz 0x00007D0BB21E307E
00007d0bb21df71b  vmovaps xmm14, [rsp+0x40]
00007d0bb21df721  vpermilpd xmm14, xmm14, 0x00
00007d0bb21df727  movaps xmm8, xmm1
00007d0bb21df72b  mulpd xmm8, xmm14
00007d0bb21df730  vcmppd xmm6, xmm8, xmm8, 0x03
00007d0bb21df736  ptest xmm6, xmm6
00007d0bb21df73b  jnz 0x00007D0BB21E31C1
00007d0bb21df741  movaps xmm1, [r15+0x2B0]
00007d0bb21df749  vmovaps xmm14, [rsp+0x40]
00007d0bb21df74f  vpermilpd xmm14, xmm14, 0x00
00007d0bb21df755  movaps xmm6, xmm1
00007d0bb21df758  mulpd xmm6, xmm14
00007d0bb21df75d  vcmppd xmm5, xmm6, xmm6, 0x03
00007d0bb21df762  ptest xmm5, xmm5
00007d0bb21df767  jnz 0x00007D0BB21E3304
00007d0bb21df76d  vmovaps xmm1, [rsp+0x10]
00007d0bb21df773  vpermilpd xmm1, xmm1, 0x00
00007d0bb21df779  movaps xmm14, xmm12
00007d0bb21df77d  mulpd xmm14, xmm1
00007d0bb21df782  vcmppd xmm5, xmm14, xmm14, 0x03
00007d0bb21df788  ptest xmm5, xmm5
00007d0bb21df78d  jnz 0x00007D0BB21E3445
00007d0bb21df793  movaps xmm1, xmm13
00007d0bb21df797  addpd xmm1, xmm9
00007d0bb21df79c  vcmppd xmm12, xmm1, xmm1, 0x03
00007d0bb21df7a1  ptest xmm12, xmm12
00007d0bb21df7a7  jnz 0x00007D0BB21E3588
00007d0bb21df7ad  vmovaps xmm13, [rsp+0x10]
00007d0bb21df7b3  vpermilpd xmm13, xmm13, 0x00
00007d0bb21df7b9  movaps xmm12, xmm7
00007d0bb21df7bd  mulpd xmm12, xmm13
00007d0bb21df7c2  vcmppd xmm9, xmm12, xmm12, 0x03
00007d0bb21df7c8  ptest xmm9, xmm9
00007d0bb21df7ce  jnz 0x00007D0BB21E36CA
00007d0bb21df7d4  movaps xmm13, xmm15
00007d0bb21df7d8  addpd xmm13, xmm8
00007d0bb21df7dd  vcmppd xmm9, xmm13, xmm13, 0x03
00007d0bb21df7e3  ptest xmm9, xmm9
00007d0bb21df7e9  jnz 0x00007D0BB21E380D
00007d0bb21df7ef  movaps xmm15, [r15+0x290]
00007d0bb21df7f7  vmovaps xmm9, [rsp+0x10]
00007d0bb21df7fd  vpermilpd xmm9, xmm9, 0x00
00007d0bb21df803  movaps xmm8, xmm15
00007d0bb21df807  mulpd xmm8, xmm9
00007d0bb21df80c  vcmppd xmm7, xmm8, xmm8, 0x03
00007d0bb21df812  ptest xmm7, xmm7
00007d0bb21df817  jnz 0x00007D0BB21E3951
00007d0bb21df81d  movaps xmm15, xmm11
00007d0bb21df821  addpd xmm15, xmm6
00007d0bb21df826  vcmppd xmm9, xmm15, xmm15, 0x03
00007d0bb21df82c  ptest xmm9, xmm9
00007d0bb21df832  jnz 0x00007D0BB21E3A95
00007d0bb21df838  movaps xmm11, [r15+0x1E0]
00007d0bb21df840  vmovaps xmm9, [rsp+0x10]
00007d0bb21df846  vpermilpd xmm9, xmm9, 0x00
00007d0bb21df84c  movaps xmm7, xmm11
00007d0bb21df850  mulpd xmm7, xmm9
00007d0bb21df855  vcmppd xmm6, xmm7, xmm7, 0x03
00007d0bb21df85a  ptest xmm6, xmm6
00007d0bb21df85f  jnz 0x00007D0BB21E3BD8
00007d0bb21df865  movaps xmm11, xmm10
00007d0bb21df869  addpd xmm11, xmm14
00007d0bb21df86e  vcmppd xmm9, xmm11, xmm11, 0x03
00007d0bb21df874  ptest xmm9, xmm9
00007d0bb21df87a  jnz 0x00007D0BB21E3D1A
00007d0bb21df880  lea r12, [rax+0x70]
00007d0bb21df884  movups xmm14, [r13+r12*1]
00007d0bb21df88a  movaps [r15+0x240], xmm14
00007d0bb21df892  movaps xmm10, xmm1
00007d0bb21df896  addpd xmm10, xmm12
00007d0bb21df89b  vcmppd xmm9, xmm10, xmm10, 0x03
00007d0bb21df8a1  ptest xmm9, xmm9
00007d0bb21df8a7  jnz 0x00007D0BB21E3E68
00007d0bb21df8ad  movaps [r15+0x170], xmm10
00007d0bb21df8b5  vmovaps xmm1, [rsp+0x20]
00007d0bb21df8bb  vpermilpd xmm1, xmm1, 0x00
00007d0bb21df8c1  movaps xmm12, xmm14
00007d0bb21df8c5  mulpd xmm12, xmm1
00007d0bb21df8ca  vcmppd xmm9, xmm12, xmm12, 0x03
00007d0bb21df8d0  ptest xmm9, xmm9
00007d0bb21df8d6  jnz 0x00007D0BB21E3FAB
00007d0bb21df8dc  vmovaps xmm1, [rsp+0x20]
00007d0bb21df8e2  vpermilpd xmm1, xmm1, 0x00
00007d0bb21df8e8  vmovaps xmm9, [rsp+0xB0]
00007d0bb21df8f1  movaps xmm14, xmm9
00007d0bb21df8f5  mulpd xmm14, xmm1
00007d0bb21df8fa  vcmppd xmm6, xmm14, xmm14, 0x03
00007d0bb21df900  ptest xmm6, xmm6
00007d0bb21df905  jnz 0x00007D0BB21E40EE
00007d0bb21df90b  movaps [r15+0x180], xmm14
00007d0bb21df913  movaps xmm1, xmm13
00007d0bb21df917  addpd xmm1, xmm8
00007d0bb21df91c  vcmppd xmm9, xmm1, xmm1, 0x03
00007d0bb21df921  ptest xmm9, xmm9
00007d0bb21df927  jnz 0x00007D0BB21E4231
00007d0bb21df92d  movaps [r15+0x210], xmm1
00007d0bb21df935  movups xmm13, [r13+rax*1]
00007d0bb21df93b  lea r12, [rax+0x10]
00007d0bb21df93f  movups xmm9, [r13+r12*1]
00007d0bb21df945  movaps [r15+0x230], xmm9
00007d0bb21df94d  movaps xmm8, xmm15
00007d0bb21df951  addpd xmm8, xmm7
00007d0bb21df956  vcmppd xmm6, xmm8, xmm8, 0x03
00007d0bb21df95c  ptest xmm6, xmm6
00007d0bb21df961  jnz 0x00007D0BB21E4387
00007d0bb21df967  movaps [r15+0x130], xmm8
00007d0bb21df96f  vmovaps xmm15, [rsp+0x20]
00007d0bb21df975  vpermilpd xmm15, xmm15, 0x00
00007d0bb21df97b  movaps xmm7, xmm9
00007d0bb21df97f  mulpd xmm7, xmm15
00007d0bb21df984  vcmppd xmm6, xmm7, xmm7, 0x03
00007d0bb21df989  ptest xmm6, xmm6
00007d0bb21df98e  jnz 0x00007D0BB21E44CA
00007d0bb21df994  movaps [r15+0x220], xmm7
00007d0bb21df99c  vmovaps xmm15, [rsp+0x20]
00007d0bb21df9a2  vpermilpd xmm15, xmm15, 0x00
00007d0bb21df9a8  movaps xmm9, xmm13
00007d0bb21df9ac  mulpd xmm9, xmm15
00007d0bb21df9b1  vcmppd xmm6, xmm9, xmm9, 0x03
00007d0bb21df9b7  ptest xmm6, xmm6
00007d0bb21df9bc  jnz 0x00007D0BB21E460C
00007d0bb21df9c2  movaps xmm15, xmm11
00007d0bb21df9c6  addpd xmm15, xmm12
00007d0bb21df9cb  vcmppd xmm13, xmm15, xmm15, 0x03
00007d0bb21df9d1  ptest xmm13, xmm13
00007d0bb21df9d7  jnz 0x00007D0BB21E4750
00007d0bb21df9dd  movaps [r15+0x140], xmm15
00007d0bb21df9e5  movaps xmm13, xmm10
00007d0bb21df9e9  addpd xmm13, xmm14
00007d0bb21df9ee  vcmppd xmm12, xmm13, xmm13, 0x03
00007d0bb21df9f4  ptest xmm12, xmm12
00007d0bb21df9fa  jnz 0x00007D0BB21E4894
00007d0bb21dfa00  movaps [r15+0x150], xmm13
00007d0bb21dfa08  movaps xmm14, xmm1
00007d0bb21dfa0c  addpd xmm14, xmm7
00007d0bb21dfa11  vcmppd xmm12, xmm14, xmm14, 0x03
00007d0bb21dfa17  ptest xmm12, xmm12
00007d0bb21dfa1d  jnz 0x00007D0BB21E49D8
00007d0bb21dfa23  movaps [r15+0x160], xmm14
00007d0bb21dfa2b  movaps xmm1, xmm8
00007d0bb21dfa2f  addpd xmm1, xmm9
00007d0bb21dfa34  vcmppd xmm12, xmm1, xmm1, 0x03
00007d0bb21dfa39  ptest xmm12, xmm12
00007d0bb21dfa3f  jnz 0x00007D0BB21E4B1A
00007d0bb21dfa45  movaps [r15+0x120], xmm1
00007d0bb21dfa4d  movups [r13+r14*1], xmm15
00007d0bb21dfa53  lea rax, [r14+0x10]
00007d0bb21dfa57  movups [r13+rax*1], xmm13
00007d0bb21dfa5d  lea rax, [r14+0x20]
00007d0bb21dfa61  movups [r13+rax*1], xmm14
00007d0bb21dfa67  lea rax, [r14+0x30]
00007d0bb21dfa6b  movups [r13+rax*1], xmm1
00007d0bb21dfa71  mov eax, [r15+0x108]
00007d0bb21dfa78  sahf
00007d0bb21dfa79  jnz 0x00007D0BB21DFAAB
00007d0bb21dfa7b  cmp dword ptr [r15+0x318], 0x00
00007d0bb21dfa83  jz 0x00007D0BB21DEAE0
00007d0bb21dfa89  nop [rax+rax*1], ax
00007d0bb21dfa92  nop [rax+rax*1], eax
00007d0bb21dfa9a  mov eax, 0x4106D0
00007d0bb21dfa9f  mov [r15+0x100], rax
00007d0bb21dfaa6  jmp 0x00007D0BB1FFE110
00007d0bb21dfaab  cmp dword ptr [r15+0x318], 0x00
00007d0bb21dfab3  jz 0x00007D0BB21D89C0
00007d0bb21dfab9  nop [rax+rax*1], ax
00007d0bb21dfac2  nop [rax+rax*1], eax
00007d0bb21dfaca  mov eax, 0x410504
00007d0bb21dfacf  mov [r15+0x100], rax
00007d0bb21dfad6  jmp 0x00007D0BB1FFE110
00007d0bb21dfadb  int3
00007d0bb21dfadc  call 0x00007D0BB20E27E0
00007d0bb21dfae1  jmp 0x00007D0BB21DEBBF
00007d0bb21dfae6  call 0x00007D0BB20E1570
00007d0bb21dfaeb  jmp 0x00007D0BB21DEBC8
00007d0bb21dfaf0  call 0x00007D0BB20E27E0
00007d0bb21dfaf5  jmp 0x00007D0BB21DEC24
00007d0bb21dfafa  call 0x00007D0BB20E1570
00007d0bb21dfaff  jmp 0x00007D0BB21DEC2D
00007d0bb21dfb04  call 0x00007D0BB20E27E0
00007d0bb21dfb09  jmp 0x00007D0BB21DEC70
00007d0bb21dfb0e  call 0x00007D0BB20E1570
00007d0bb21dfb13  jmp 0x00007D0BB21DEC79
00007d0bb21dfb18  call 0x00007D0BB200DC20
00007d0bb21dfb1d  jmp 0x00007D0BB21DECB8
00007d0bb21dfb22  call 0x00007D0BB20D59C0
00007d0bb21dfb27  jmp 0x00007D0BB21DECCB
00007d0bb21dfb2c  call 0x00007D0BB20E0E30
00007d0bb21dfb31  jmp 0x00007D0BB21DECE9
00007d0bb21dfb36  call 0x00007D0BB20DFBC0
00007d0bb21dfb3b  jmp 0x00007D0BB21DECF3
00007d0bb21dfb40  call 0x00007D0BB20DE950
00007d0bb21dfb45  jmp 0x00007D0BB21DECFD
00007d0bb21dfb4a  sub rsp, 0x08
00007d0bb21dfb4e  push rax
00007d0bb21dfb4f  push rcx
00007d0bb21dfb50  push rdx
00007d0bb21dfb51  push rdi
00007d0bb21dfb52  push rsi
00007d0bb21dfb53  push r8
00007d0bb21dfb55  push r9
00007d0bb21dfb57  push r10
00007d0bb21dfb59  push r11
00007d0bb21dfb5b  sub rsp, 0xF0
00007d0bb21dfb62  vmovaps [rsp], xmm0
00007d0bb21dfb67  vmovaps [rsp+0x10], xmm1
00007d0bb21dfb6d  vmovaps [rsp+0x20], xmm2
00007d0bb21dfb73  vmovaps [rsp+0x30], xmm3
00007d0bb21dfb79  vmovaps [rsp+0x40], xmm4
00007d0bb21dfb7f  vmovaps [rsp+0x50], xmm5
00007d0bb21dfb85  vmovaps [rsp+0x60], xmm6
00007d0bb21dfb8b  vmovaps [rsp+0x70], xmm7
00007d0bb21dfb91  vmovaps [rsp+0x80], xmm9
00007d0bb21dfb9a  vmovaps [rsp+0x90], xmm10
00007d0bb21dfba3  vmovaps [rsp+0xA0], xmm11
00007d0bb21dfbac  vmovaps [rsp+0xB0], xmm12
00007d0bb21dfbb5  vmovaps [rsp+0xC0], xmm13
00007d0bb21dfbbe  vmovaps [rsp+0xD0], xmm14
00007d0bb21dfbc7  vmovaps [rsp+0xE0], xmm15
00007d0bb21dfbd0  sub rsp, 0x30
00007d0bb21dfbd4  movaps [rsp], xmm8
00007d0bb21dfbd9  movaps [rsp+0x10], xmm12
00007d0bb21dfbdf  movaps [rsp+0x20], xmm15
00007d0bb21dfbe5  lea rdi, [rsp]
00007d0bb21dfbe9  mov esi, 0x00
00007d0bb21dfbee  mov rax, 0x6392BBE7F530
00007d0bb21dfbf8  call rax
00007d0bb21dfbfa  movaps xmm8, [rsp]
00007d0bb21dfbff  add rsp, 0x30
00007d0bb21dfc03  vmovaps xmm0, [rsp]
00007d0bb21dfc08  vmovaps xmm1, [rsp+0x10]
00007d0bb21dfc0e  vmovaps xmm2, [rsp+0x20]
00007d0bb21dfc14  vmovaps xmm3, [rsp+0x30]
00007d0bb21dfc1a  vmovaps xmm4, [rsp+0x40]
00007d0bb21dfc20  vmovaps xmm5, [rsp+0x50]
00007d0bb21dfc26  vmovaps xmm6, [rsp+0x60]
00007d0bb21dfc2c  vmovaps xmm7, [rsp+0x70]
00007d0bb21dfc32  vmovaps xmm9, [rsp+0x80]
00007d0bb21dfc3b  vmovaps xmm10, [rsp+0x90]
00007d0bb21dfc44  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dfc4d  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dfc56  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dfc5f  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dfc68  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dfc71  add rsp, 0xF0
00007d0bb21dfc78  pop r11
00007d0bb21dfc7a  pop r10
00007d0bb21dfc7c  pop r9
00007d0bb21dfc7e  pop r8
00007d0bb21dfc80  pop rsi
00007d0bb21dfc81  pop rdi
00007d0bb21dfc82  pop rdx
00007d0bb21dfc83  pop rcx
00007d0bb21dfc84  pop rax
00007d0bb21dfc85  add rsp, 0x08
00007d0bb21dfc89  jmp 0x00007D0BB21DED27
00007d0bb21dfc8e  sub rsp, 0x08
00007d0bb21dfc92  push rax
00007d0bb21dfc93  push rcx
00007d0bb21dfc94  push rdx
00007d0bb21dfc95  push rdi
00007d0bb21dfc96  push rsi
00007d0bb21dfc97  push r8
00007d0bb21dfc99  push r9
00007d0bb21dfc9b  push r10
00007d0bb21dfc9d  push r11
00007d0bb21dfc9f  sub rsp, 0xF0
00007d0bb21dfca6  vmovaps [rsp], xmm0
00007d0bb21dfcab  vmovaps [rsp+0x10], xmm1
00007d0bb21dfcb1  vmovaps [rsp+0x20], xmm2
00007d0bb21dfcb7  vmovaps [rsp+0x30], xmm3
00007d0bb21dfcbd  vmovaps [rsp+0x40], xmm4
00007d0bb21dfcc3  vmovaps [rsp+0x50], xmm5
00007d0bb21dfcc9  vmovaps [rsp+0x60], xmm6
00007d0bb21dfccf  vmovaps [rsp+0x70], xmm8
00007d0bb21dfcd5  vmovaps [rsp+0x80], xmm9
00007d0bb21dfcde  vmovaps [rsp+0x90], xmm10
00007d0bb21dfce7  vmovaps [rsp+0xA0], xmm11
00007d0bb21dfcf0  vmovaps [rsp+0xB0], xmm12
00007d0bb21dfcf9  vmovaps [rsp+0xC0], xmm13
00007d0bb21dfd02  vmovaps [rsp+0xD0], xmm14
00007d0bb21dfd0b  vmovaps [rsp+0xE0], xmm15
00007d0bb21dfd14  sub rsp, 0x30
00007d0bb21dfd18  movaps [rsp], xmm7
00007d0bb21dfd1c  movaps [rsp+0x10], xmm9
00007d0bb21dfd22  movaps [rsp+0x20], xmm15
00007d0bb21dfd28  lea rdi, [rsp]
00007d0bb21dfd2c  mov esi, 0x00
00007d0bb21dfd31  mov rax, 0x6392BBE7F530
00007d0bb21dfd3b  call rax
00007d0bb21dfd3d  movaps xmm7, [rsp]
00007d0bb21dfd41  add rsp, 0x30
00007d0bb21dfd45  vmovaps xmm0, [rsp]
00007d0bb21dfd4a  vmovaps xmm1, [rsp+0x10]
00007d0bb21dfd50  vmovaps xmm2, [rsp+0x20]
00007d0bb21dfd56  vmovaps xmm3, [rsp+0x30]
00007d0bb21dfd5c  vmovaps xmm4, [rsp+0x40]
00007d0bb21dfd62  vmovaps xmm5, [rsp+0x50]
00007d0bb21dfd68  vmovaps xmm6, [rsp+0x60]
00007d0bb21dfd6e  vmovaps xmm8, [rsp+0x70]
00007d0bb21dfd74  vmovaps xmm9, [rsp+0x80]
00007d0bb21dfd7d  vmovaps xmm10, [rsp+0x90]
00007d0bb21dfd86  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dfd8f  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dfd98  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dfda1  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dfdaa  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dfdb3  add rsp, 0xF0
00007d0bb21dfdba  pop r11
00007d0bb21dfdbc  pop r10
00007d0bb21dfdbe  pop r9
00007d0bb21dfdc0  pop r8
00007d0bb21dfdc2  pop rsi
00007d0bb21dfdc3  pop rdi
00007d0bb21dfdc4  pop rdx
00007d0bb21dfdc5  pop rcx
00007d0bb21dfdc6  pop rax
00007d0bb21dfdc7  add rsp, 0x08
00007d0bb21dfdcb  jmp 0x00007D0BB21DED55
00007d0bb21dfdd0  sub rsp, 0x08
00007d0bb21dfdd4  push rax
00007d0bb21dfdd5  push rcx
00007d0bb21dfdd6  push rdx
00007d0bb21dfdd7  push rdi
00007d0bb21dfdd8  push rsi
00007d0bb21dfdd9  push r8
00007d0bb21dfddb  push r9
00007d0bb21dfddd  push r10
00007d0bb21dfddf  push r11
00007d0bb21dfde1  sub rsp, 0xF0
00007d0bb21dfde8  vmovaps [rsp], xmm0
00007d0bb21dfded  vmovaps [rsp+0x10], xmm1
00007d0bb21dfdf3  vmovaps [rsp+0x20], xmm2
00007d0bb21dfdf9  vmovaps [rsp+0x30], xmm3
00007d0bb21dfdff  vmovaps [rsp+0x40], xmm4
00007d0bb21dfe05  vmovaps [rsp+0x50], xmm5
00007d0bb21dfe0b  vmovaps [rsp+0x60], xmm6
00007d0bb21dfe11  vmovaps [rsp+0x70], xmm7
00007d0bb21dfe17  vmovaps [rsp+0x80], xmm8
00007d0bb21dfe20  vmovaps [rsp+0x90], xmm10
00007d0bb21dfe29  vmovaps [rsp+0xA0], xmm11
00007d0bb21dfe32  vmovaps [rsp+0xB0], xmm12
00007d0bb21dfe3b  vmovaps [rsp+0xC0], xmm13
00007d0bb21dfe44  vmovaps [rsp+0xD0], xmm14
00007d0bb21dfe4d  vmovaps [rsp+0xE0], xmm15
00007d0bb21dfe56  sub rsp, 0x30
00007d0bb21dfe5a  movaps [rsp], xmm9
00007d0bb21dfe5f  movaps [rsp+0x10], xmm12
00007d0bb21dfe65  movaps [rsp+0x20], xmm10
00007d0bb21dfe6b  lea rdi, [rsp]
00007d0bb21dfe6f  mov esi, 0x00
00007d0bb21dfe74  mov rax, 0x6392BBE7F530
00007d0bb21dfe7e  call rax
00007d0bb21dfe80  movaps xmm9, [rsp]
00007d0bb21dfe85  add rsp, 0x30
00007d0bb21dfe89  vmovaps xmm0, [rsp]
00007d0bb21dfe8e  vmovaps xmm1, [rsp+0x10]
00007d0bb21dfe94  vmovaps xmm2, [rsp+0x20]
00007d0bb21dfe9a  vmovaps xmm3, [rsp+0x30]
00007d0bb21dfea0  vmovaps xmm4, [rsp+0x40]
00007d0bb21dfea6  vmovaps xmm5, [rsp+0x50]
00007d0bb21dfeac  vmovaps xmm6, [rsp+0x60]
00007d0bb21dfeb2  vmovaps xmm7, [rsp+0x70]
00007d0bb21dfeb8  vmovaps xmm8, [rsp+0x80]
00007d0bb21dfec1  vmovaps xmm10, [rsp+0x90]
00007d0bb21dfeca  vmovaps xmm11, [rsp+0xA0]
00007d0bb21dfed3  vmovaps xmm12, [rsp+0xB0]
00007d0bb21dfedc  vmovaps xmm13, [rsp+0xC0]
00007d0bb21dfee5  vmovaps xmm14, [rsp+0xD0]
00007d0bb21dfeee  vmovaps xmm15, [rsp+0xE0]
00007d0bb21dfef7  add rsp, 0xF0
00007d0bb21dfefe  pop r11
00007d0bb21dff00  pop r10
00007d0bb21dff02  pop r9
00007d0bb21dff04  pop r8
00007d0bb21dff06  pop rsi
00007d0bb21dff07  pop rdi
00007d0bb21dff08  pop rdx
00007d0bb21dff09  pop rcx
00007d0bb21dff0a  pop rax
00007d0bb21dff0b  add rsp, 0x08
00007d0bb21dff0f  jmp 0x00007D0BB21DED79
00007d0bb21dff14  sub rsp, 0x08
00007d0bb21dff18  push rax
00007d0bb21dff19  push rcx
00007d0bb21dff1a  push rdx
00007d0bb21dff1b  push rdi
00007d0bb21dff1c  push rsi
00007d0bb21dff1d  push r8
00007d0bb21dff1f  push r9
00007d0bb21dff21  push r10
00007d0bb21dff23  push r11
00007d0bb21dff25  sub rsp, 0xF0
00007d0bb21dff2c  vmovaps [rsp], xmm0
00007d0bb21dff31  vmovaps [rsp+0x10], xmm1
00007d0bb21dff37  vmovaps [rsp+0x20], xmm2
00007d0bb21dff3d  vmovaps [rsp+0x30], xmm3
00007d0bb21dff43  vmovaps [rsp+0x40], xmm4
00007d0bb21dff49  vmovaps [rsp+0x50], xmm5
00007d0bb21dff4f  vmovaps [rsp+0x60], xmm6
00007d0bb21dff55  vmovaps [rsp+0x70], xmm7
00007d0bb21dff5b  vmovaps [rsp+0x80], xmm8
00007d0bb21dff64  vmovaps [rsp+0x90], xmm9
00007d0bb21dff6d  vmovaps [rsp+0xA0], xmm11
00007d0bb21dff76  vmovaps [rsp+0xB0], xmm12
00007d0bb21dff7f  vmovaps [rsp+0xC0], xmm13
00007d0bb21dff88  vmovaps [rsp+0xD0], xmm14
00007d0bb21dff91  vmovaps [rsp+0xE0], xmm15
00007d0bb21dff9a  sub rsp, 0x30
00007d0bb21dff9e  movaps [rsp], xmm10
00007d0bb21dffa3  movaps [rsp+0x10], xmm12
00007d0bb21dffa9  movaps [rsp+0x20], xmm11
00007d0bb21dffaf  lea rdi, [rsp]
00007d0bb21dffb3  mov esi, 0x00
00007d0bb21dffb8  mov rax, 0x6392BBE7F530
00007d0bb21dffc2  call rax
00007d0bb21dffc4  movaps xmm10, [rsp]
00007d0bb21dffc9  add rsp, 0x30
00007d0bb21dffcd  vmovaps xmm0, [rsp]
00007d0bb21dffd2  vmovaps xmm1, [rsp+0x10]
00007d0bb21dffd8  vmovaps xmm2, [rsp+0x20]
00007d0bb21dffde  vmovaps xmm3, [rsp+0x30]
00007d0bb21dffe4  vmovaps xmm4, [rsp+0x40]
00007d0bb21dffea  vmovaps xmm5, [rsp+0x50]
00007d0bb21dfff0  vmovaps xmm6, [rsp+0x60]
00007d0bb21dfff6  vmovaps xmm7, [rsp+0x70]
00007d0bb21dfffc  vmovaps xmm8, [rsp+0x80]
00007d0bb21e0005  vmovaps xmm9, [rsp+0x90]
00007d0bb21e000e  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e0017  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e0020  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e0029  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e0032  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e003b  add rsp, 0xF0
00007d0bb21e0042  pop r11
00007d0bb21e0044  pop r10
00007d0bb21e0046  pop r9
00007d0bb21e0048  pop r8
00007d0bb21e004a  pop rsi
00007d0bb21e004b  pop rdi
00007d0bb21e004c  pop rdx
00007d0bb21e004d  pop rcx
00007d0bb21e004e  pop rax
00007d0bb21e004f  add rsp, 0x08
00007d0bb21e0053  jmp 0x00007D0BB21DED93
00007d0bb21e0058  sub rsp, 0x08
00007d0bb21e005c  push rax
00007d0bb21e005d  push rcx
00007d0bb21e005e  push rdx
00007d0bb21e005f  push rdi
00007d0bb21e0060  push rsi
00007d0bb21e0061  push r8
00007d0bb21e0063  push r9
00007d0bb21e0065  push r10
00007d0bb21e0067  push r11
00007d0bb21e0069  sub rsp, 0xF0
00007d0bb21e0070  vmovaps [rsp], xmm0
00007d0bb21e0075  vmovaps [rsp+0x10], xmm1
00007d0bb21e007b  vmovaps [rsp+0x20], xmm2
00007d0bb21e0081  vmovaps [rsp+0x30], xmm3
00007d0bb21e0087  vmovaps [rsp+0x40], xmm4
00007d0bb21e008d  vmovaps [rsp+0x50], xmm5
00007d0bb21e0093  vmovaps [rsp+0x60], xmm7
00007d0bb21e0099  vmovaps [rsp+0x70], xmm8
00007d0bb21e009f  vmovaps [rsp+0x80], xmm9
00007d0bb21e00a8  vmovaps [rsp+0x90], xmm10
00007d0bb21e00b1  vmovaps [rsp+0xA0], xmm11
00007d0bb21e00ba  vmovaps [rsp+0xB0], xmm12
00007d0bb21e00c3  vmovaps [rsp+0xC0], xmm13
00007d0bb21e00cc  vmovaps [rsp+0xD0], xmm14
00007d0bb21e00d5  vmovaps [rsp+0xE0], xmm15
00007d0bb21e00de  sub rsp, 0x30
00007d0bb21e00e2  movaps [rsp], xmm6
00007d0bb21e00e6  movaps [rsp+0x10], xmm12
00007d0bb21e00ec  movaps [rsp+0x20], xmm11
00007d0bb21e00f2  lea rdi, [rsp]
00007d0bb21e00f6  mov esi, 0x00
00007d0bb21e00fb  mov rax, 0x6392BBE7F530
00007d0bb21e0105  call rax
00007d0bb21e0107  movaps xmm6, [rsp]
00007d0bb21e010b  add rsp, 0x30
00007d0bb21e010f  vmovaps xmm0, [rsp]
00007d0bb21e0114  vmovaps xmm1, [rsp+0x10]
00007d0bb21e011a  vmovaps xmm2, [rsp+0x20]
00007d0bb21e0120  vmovaps xmm3, [rsp+0x30]
00007d0bb21e0126  vmovaps xmm4, [rsp+0x40]
00007d0bb21e012c  vmovaps xmm5, [rsp+0x50]
00007d0bb21e0132  vmovaps xmm7, [rsp+0x60]
00007d0bb21e0138  vmovaps xmm8, [rsp+0x70]
00007d0bb21e013e  vmovaps xmm9, [rsp+0x80]
00007d0bb21e0147  vmovaps xmm10, [rsp+0x90]
00007d0bb21e0150  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e0159  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e0162  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e016b  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e0174  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e017d  add rsp, 0xF0
00007d0bb21e0184  pop r11
00007d0bb21e0186  pop r10
00007d0bb21e0188  pop r9
00007d0bb21e018a  pop r8
00007d0bb21e018c  pop rsi
00007d0bb21e018d  pop rdi
00007d0bb21e018e  pop rdx
00007d0bb21e018f  pop rcx
00007d0bb21e0190  pop rax
00007d0bb21e0191  add rsp, 0x08
00007d0bb21e0195  jmp 0x00007D0BB21DEDB4
00007d0bb21e019a  sub rsp, 0x08
00007d0bb21e019e  push rax
00007d0bb21e019f  push rcx
00007d0bb21e01a0  push rdx
00007d0bb21e01a1  push rdi
00007d0bb21e01a2  push rsi
00007d0bb21e01a3  push r8
00007d0bb21e01a5  push r9
00007d0bb21e01a7  push r10
00007d0bb21e01a9  push r11
00007d0bb21e01ab  sub rsp, 0xF0
00007d0bb21e01b2  vmovaps [rsp], xmm0
00007d0bb21e01b7  vmovaps [rsp+0x10], xmm1
00007d0bb21e01bd  vmovaps [rsp+0x20], xmm2
00007d0bb21e01c3  vmovaps [rsp+0x30], xmm4
00007d0bb21e01c9  vmovaps [rsp+0x40], xmm5
00007d0bb21e01cf  vmovaps [rsp+0x50], xmm6
00007d0bb21e01d5  vmovaps [rsp+0x60], xmm7
00007d0bb21e01db  vmovaps [rsp+0x70], xmm8
00007d0bb21e01e1  vmovaps [rsp+0x80], xmm9
00007d0bb21e01ea  vmovaps [rsp+0x90], xmm10
00007d0bb21e01f3  vmovaps [rsp+0xA0], xmm11
00007d0bb21e01fc  vmovaps [rsp+0xB0], xmm12
00007d0bb21e0205  vmovaps [rsp+0xC0], xmm13
00007d0bb21e020e  vmovaps [rsp+0xD0], xmm14
00007d0bb21e0217  vmovaps [rsp+0xE0], xmm15
00007d0bb21e0220  sub rsp, 0x30
00007d0bb21e0224  movaps [rsp], xmm3
00007d0bb21e0228  movaps [rsp+0x10], xmm5
00007d0bb21e022d  movaps [rsp+0x20], xmm4
00007d0bb21e0232  lea rdi, [rsp]
00007d0bb21e0236  mov esi, 0x00
00007d0bb21e023b  mov rax, 0x6392BBE7F530
00007d0bb21e0245  call rax
00007d0bb21e0247  movaps xmm3, [rsp]
00007d0bb21e024b  add rsp, 0x30
00007d0bb21e024f  vmovaps xmm0, [rsp]
00007d0bb21e0254  vmovaps xmm1, [rsp+0x10]
00007d0bb21e025a  vmovaps xmm2, [rsp+0x20]
00007d0bb21e0260  vmovaps xmm4, [rsp+0x30]
00007d0bb21e0266  vmovaps xmm5, [rsp+0x40]
00007d0bb21e026c  vmovaps xmm6, [rsp+0x50]
00007d0bb21e0272  vmovaps xmm7, [rsp+0x60]
00007d0bb21e0278  vmovaps xmm8, [rsp+0x70]
00007d0bb21e027e  vmovaps xmm9, [rsp+0x80]
00007d0bb21e0287  vmovaps xmm10, [rsp+0x90]
00007d0bb21e0290  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e0299  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e02a2  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e02ab  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e02b4  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e02bd  add rsp, 0xF0
00007d0bb21e02c4  pop r11
00007d0bb21e02c6  pop r10
00007d0bb21e02c8  pop r9
00007d0bb21e02ca  pop r8
00007d0bb21e02cc  pop rsi
00007d0bb21e02cd  pop rdi
00007d0bb21e02ce  pop rdx
00007d0bb21e02cf  pop rcx
00007d0bb21e02d0  pop rax
00007d0bb21e02d1  add rsp, 0x08
00007d0bb21e02d5  jmp 0x00007D0BB21DEE15
00007d0bb21e02da  sub rsp, 0x08
00007d0bb21e02de  push rax
00007d0bb21e02df  push rcx
00007d0bb21e02e0  push rdx
00007d0bb21e02e1  push rdi
00007d0bb21e02e2  push rsi
00007d0bb21e02e3  push r8
00007d0bb21e02e5  push r9
00007d0bb21e02e7  push r10
00007d0bb21e02e9  push r11
00007d0bb21e02eb  sub rsp, 0xF0
00007d0bb21e02f2  vmovaps [rsp], xmm0
00007d0bb21e02f7  vmovaps [rsp+0x10], xmm1
00007d0bb21e02fd  vmovaps [rsp+0x20], xmm2
00007d0bb21e0303  vmovaps [rsp+0x30], xmm3
00007d0bb21e0309  vmovaps [rsp+0x40], xmm4
00007d0bb21e030f  vmovaps [rsp+0x50], xmm6
00007d0bb21e0315  vmovaps [rsp+0x60], xmm7
00007d0bb21e031b  vmovaps [rsp+0x70], xmm8
00007d0bb21e0321  vmovaps [rsp+0x80], xmm9
00007d0bb21e032a  vmovaps [rsp+0x90], xmm10
00007d0bb21e0333  vmovaps [rsp+0xA0], xmm11
00007d0bb21e033c  vmovaps [rsp+0xB0], xmm12
00007d0bb21e0345  vmovaps [rsp+0xC0], xmm13
00007d0bb21e034e  vmovaps [rsp+0xD0], xmm14
00007d0bb21e0357  vmovaps [rsp+0xE0], xmm15
00007d0bb21e0360  sub rsp, 0x30
00007d0bb21e0364  movaps [rsp], xmm5
00007d0bb21e0368  movaps [rsp+0x10], xmm8
00007d0bb21e036e  movaps [rsp+0x20], xmm15
00007d0bb21e0374  lea rdi, [rsp]
00007d0bb21e0378  mov esi, 0x00
00007d0bb21e037d  mov rax, 0x6392BBE7F530
00007d0bb21e0387  call rax
00007d0bb21e0389  movaps xmm5, [rsp]
00007d0bb21e038d  add rsp, 0x30
00007d0bb21e0391  vmovaps xmm0, [rsp]
00007d0bb21e0396  vmovaps xmm1, [rsp+0x10]
00007d0bb21e039c  vmovaps xmm2, [rsp+0x20]
00007d0bb21e03a2  vmovaps xmm3, [rsp+0x30]
00007d0bb21e03a8  vmovaps xmm4, [rsp+0x40]
00007d0bb21e03ae  vmovaps xmm6, [rsp+0x50]
00007d0bb21e03b4  vmovaps xmm7, [rsp+0x60]
00007d0bb21e03ba  vmovaps xmm8, [rsp+0x70]
00007d0bb21e03c0  vmovaps xmm9, [rsp+0x80]
00007d0bb21e03c9  vmovaps xmm10, [rsp+0x90]
00007d0bb21e03d2  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e03db  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e03e4  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e03ed  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e03f6  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e03ff  add rsp, 0xF0
00007d0bb21e0406  pop r11
00007d0bb21e0408  pop r10
00007d0bb21e040a  pop r9
00007d0bb21e040c  pop r8
00007d0bb21e040e  pop rsi
00007d0bb21e040f  pop rdi
00007d0bb21e0410  pop rdx
00007d0bb21e0411  pop rcx
00007d0bb21e0412  pop rax
00007d0bb21e0413  add rsp, 0x08
00007d0bb21e0417  jmp 0x00007D0BB21DEE53
00007d0bb21e041c  sub rsp, 0x08
00007d0bb21e0420  push rax
00007d0bb21e0421  push rcx
00007d0bb21e0422  push rdx
00007d0bb21e0423  push rdi
00007d0bb21e0424  push rsi
00007d0bb21e0425  push r8
00007d0bb21e0427  push r9
00007d0bb21e0429  push r10
00007d0bb21e042b  push r11
00007d0bb21e042d  sub rsp, 0xF0
00007d0bb21e0434  vmovaps [rsp], xmm0
00007d0bb21e0439  vmovaps [rsp+0x10], xmm1
00007d0bb21e043f  vmovaps [rsp+0x20], xmm2
00007d0bb21e0445  vmovaps [rsp+0x30], xmm3
00007d0bb21e044b  vmovaps [rsp+0x40], xmm5
00007d0bb21e0451  vmovaps [rsp+0x50], xmm6
00007d0bb21e0457  vmovaps [rsp+0x60], xmm7
00007d0bb21e045d  vmovaps [rsp+0x70], xmm8
00007d0bb21e0463  vmovaps [rsp+0x80], xmm9
00007d0bb21e046c  vmovaps [rsp+0x90], xmm10
00007d0bb21e0475  vmovaps [rsp+0xA0], xmm11
00007d0bb21e047e  vmovaps [rsp+0xB0], xmm12
00007d0bb21e0487  vmovaps [rsp+0xC0], xmm13
00007d0bb21e0490  vmovaps [rsp+0xD0], xmm14
00007d0bb21e0499  vmovaps [rsp+0xE0], xmm15
00007d0bb21e04a2  sub rsp, 0x30
00007d0bb21e04a6  movaps [rsp], xmm4
00007d0bb21e04aa  movaps [rsp+0x10], xmm9
00007d0bb21e04b0  movaps [rsp+0x20], xmm8
00007d0bb21e04b6  lea rdi, [rsp]
00007d0bb21e04ba  mov esi, 0x00
00007d0bb21e04bf  mov rax, 0x6392BBE7F530
00007d0bb21e04c9  call rax
00007d0bb21e04cb  movaps xmm4, [rsp]
00007d0bb21e04cf  add rsp, 0x30
00007d0bb21e04d3  vmovaps xmm0, [rsp]
00007d0bb21e04d8  vmovaps xmm1, [rsp+0x10]
00007d0bb21e04de  vmovaps xmm2, [rsp+0x20]
00007d0bb21e04e4  vmovaps xmm3, [rsp+0x30]
00007d0bb21e04ea  vmovaps xmm5, [rsp+0x40]
00007d0bb21e04f0  vmovaps xmm6, [rsp+0x50]
00007d0bb21e04f6  vmovaps xmm7, [rsp+0x60]
00007d0bb21e04fc  vmovaps xmm8, [rsp+0x70]
00007d0bb21e0502  vmovaps xmm9, [rsp+0x80]
00007d0bb21e050b  vmovaps xmm10, [rsp+0x90]
00007d0bb21e0514  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e051d  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e0526  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e052f  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e0538  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e0541  add rsp, 0xF0
00007d0bb21e0548  pop r11
00007d0bb21e054a  pop r10
00007d0bb21e054c  pop r9
00007d0bb21e054e  pop r8
00007d0bb21e0550  pop rsi
00007d0bb21e0551  pop rdi
00007d0bb21e0552  pop rdx
00007d0bb21e0553  pop rcx
00007d0bb21e0554  pop rax
00007d0bb21e0555  add rsp, 0x08
00007d0bb21e0559  jmp 0x00007D0BB21DEE74
00007d0bb21e055e  sub rsp, 0x08
00007d0bb21e0562  push rax
00007d0bb21e0563  push rcx
00007d0bb21e0564  push rdx
00007d0bb21e0565  push rdi
00007d0bb21e0566  push rsi
00007d0bb21e0567  push r8
00007d0bb21e0569  push r9
00007d0bb21e056b  push r10
00007d0bb21e056d  push r11
00007d0bb21e056f  sub rsp, 0xF0
00007d0bb21e0576  vmovaps [rsp], xmm0
00007d0bb21e057b  vmovaps [rsp+0x10], xmm1
00007d0bb21e0581  vmovaps [rsp+0x20], xmm2
00007d0bb21e0587  vmovaps [rsp+0x30], xmm3
00007d0bb21e058d  vmovaps [rsp+0x40], xmm4
00007d0bb21e0593  vmovaps [rsp+0x50], xmm5
00007d0bb21e0599  vmovaps [rsp+0x60], xmm6
00007d0bb21e059f  vmovaps [rsp+0x70], xmm7
00007d0bb21e05a5  vmovaps [rsp+0x80], xmm8
00007d0bb21e05ae  vmovaps [rsp+0x90], xmm10
00007d0bb21e05b7  vmovaps [rsp+0xA0], xmm11
00007d0bb21e05c0  vmovaps [rsp+0xB0], xmm12
00007d0bb21e05c9  vmovaps [rsp+0xC0], xmm13
00007d0bb21e05d2  vmovaps [rsp+0xD0], xmm14
00007d0bb21e05db  vmovaps [rsp+0xE0], xmm15
00007d0bb21e05e4  sub rsp, 0x30
00007d0bb21e05e8  movaps [rsp], xmm9
00007d0bb21e05ed  movaps [rsp+0x10], xmm10
00007d0bb21e05f3  movaps [rsp+0x20], xmm8
00007d0bb21e05f9  lea rdi, [rsp]
00007d0bb21e05fd  mov esi, 0x00
00007d0bb21e0602  mov rax, 0x6392BBE7F530
00007d0bb21e060c  call rax
00007d0bb21e060e  movaps xmm9, [rsp]
00007d0bb21e0613  add rsp, 0x30
00007d0bb21e0617  vmovaps xmm0, [rsp]
00007d0bb21e061c  vmovaps xmm1, [rsp+0x10]
00007d0bb21e0622  vmovaps xmm2, [rsp+0x20]
00007d0bb21e0628  vmovaps xmm3, [rsp+0x30]
00007d0bb21e062e  vmovaps xmm4, [rsp+0x40]
00007d0bb21e0634  vmovaps xmm5, [rsp+0x50]
00007d0bb21e063a  vmovaps xmm6, [rsp+0x60]
00007d0bb21e0640  vmovaps xmm7, [rsp+0x70]
00007d0bb21e0646  vmovaps xmm8, [rsp+0x80]
00007d0bb21e064f  vmovaps xmm10, [rsp+0x90]
00007d0bb21e0658  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e0661  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e066a  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e0673  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e067c  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e0685  add rsp, 0xF0
00007d0bb21e068c  pop r11
00007d0bb21e068e  pop r10
00007d0bb21e0690  pop r9
00007d0bb21e0692  pop r8
00007d0bb21e0694  pop rsi
00007d0bb21e0695  pop rdi
00007d0bb21e0696  pop rdx
00007d0bb21e0697  pop rcx
00007d0bb21e0698  pop rax
00007d0bb21e0699  add rsp, 0x08
00007d0bb21e069d  jmp 0x00007D0BB21DEE8E
00007d0bb21e06a2  call 0x00007D0BB20B52F0
00007d0bb21e06a7  jmp 0x00007D0BB21DEFA8
00007d0bb21e06ac  call 0x00007D0BB20B52F0
00007d0bb21e06b1  jmp 0x00007D0BB21DEFBE
00007d0bb21e06b6  sub rsp, 0x08
00007d0bb21e06ba  push rax
00007d0bb21e06bb  push rcx
00007d0bb21e06bc  push rdx
00007d0bb21e06bd  push rdi
00007d0bb21e06be  push rsi
00007d0bb21e06bf  push r8
00007d0bb21e06c1  push r9
00007d0bb21e06c3  push r10
00007d0bb21e06c5  push r11
00007d0bb21e06c7  sub rsp, 0xF0
00007d0bb21e06ce  vmovaps [rsp], xmm0
00007d0bb21e06d3  vmovaps [rsp+0x10], xmm2
00007d0bb21e06d9  vmovaps [rsp+0x20], xmm3
00007d0bb21e06df  vmovaps [rsp+0x30], xmm4
00007d0bb21e06e5  vmovaps [rsp+0x40], xmm5
00007d0bb21e06eb  vmovaps [rsp+0x50], xmm6
00007d0bb21e06f1  vmovaps [rsp+0x60], xmm7
00007d0bb21e06f7  vmovaps [rsp+0x70], xmm8
00007d0bb21e06fd  vmovaps [rsp+0x80], xmm9
00007d0bb21e0706  vmovaps [rsp+0x90], xmm10
00007d0bb21e070f  vmovaps [rsp+0xA0], xmm11
00007d0bb21e0718  vmovaps [rsp+0xB0], xmm12
00007d0bb21e0721  vmovaps [rsp+0xC0], xmm13
00007d0bb21e072a  vmovaps [rsp+0xD0], xmm14
00007d0bb21e0733  vmovaps [rsp+0xE0], xmm15
00007d0bb21e073c  sub rsp, 0x30
00007d0bb21e0740  movaps [rsp], xmm1
00007d0bb21e0744  movaps [rsp+0x10], xmm6
00007d0bb21e0749  movaps [rsp+0x20], xmm15
00007d0bb21e074f  lea rdi, [rsp]
00007d0bb21e0753  mov esi, 0x00
00007d0bb21e0758  mov rax, 0x6392BBE7F530
00007d0bb21e0762  call rax
00007d0bb21e0764  movaps xmm1, [rsp]
00007d0bb21e0768  add rsp, 0x30
00007d0bb21e076c  vmovaps xmm0, [rsp]
00007d0bb21e0771  vmovaps xmm2, [rsp+0x10]
00007d0bb21e0777  vmovaps xmm3, [rsp+0x20]
00007d0bb21e077d  vmovaps xmm4, [rsp+0x30]
00007d0bb21e0783  vmovaps xmm5, [rsp+0x40]
00007d0bb21e0789  vmovaps xmm6, [rsp+0x50]
00007d0bb21e078f  vmovaps xmm7, [rsp+0x60]
00007d0bb21e0795  vmovaps xmm8, [rsp+0x70]
00007d0bb21e079b  vmovaps xmm9, [rsp+0x80]
00007d0bb21e07a4  vmovaps xmm10, [rsp+0x90]
00007d0bb21e07ad  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e07b6  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e07bf  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e07c8  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e07d1  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e07da  add rsp, 0xF0
00007d0bb21e07e1  pop r11
00007d0bb21e07e3  pop r10
00007d0bb21e07e5  pop r9
00007d0bb21e07e7  pop r8
00007d0bb21e07e9  pop rsi
00007d0bb21e07ea  pop rdi
00007d0bb21e07eb  pop rdx
00007d0bb21e07ec  pop rcx
00007d0bb21e07ed  pop rax
00007d0bb21e07ee  add rsp, 0x08
00007d0bb21e07f2  jmp 0x00007D0BB21DEFFB
00007d0bb21e07f7  call 0x00007D0BB20C4620
00007d0bb21e07fc  jmp 0x00007D0BB21DF008
00007d0bb21e0801  sub rsp, 0x08
00007d0bb21e0805  push rax
00007d0bb21e0806  push rcx
00007d0bb21e0807  push rdx
00007d0bb21e0808  push rdi
00007d0bb21e0809  push rsi
00007d0bb21e080a  push r8
00007d0bb21e080c  push r9
00007d0bb21e080e  push r10
00007d0bb21e0810  push r11
00007d0bb21e0812  sub rsp, 0xF0
00007d0bb21e0819  vmovaps [rsp], xmm0
00007d0bb21e081e  vmovaps [rsp+0x10], xmm1
00007d0bb21e0824  vmovaps [rsp+0x20], xmm2
00007d0bb21e082a  vmovaps [rsp+0x30], xmm3
00007d0bb21e0830  vmovaps [rsp+0x40], xmm4
00007d0bb21e0836  vmovaps [rsp+0x50], xmm5
00007d0bb21e083c  vmovaps [rsp+0x60], xmm6
00007d0bb21e0842  vmovaps [rsp+0x70], xmm7
00007d0bb21e0848  vmovaps [rsp+0x80], xmm8
00007d0bb21e0851  vmovaps [rsp+0x90], xmm9
00007d0bb21e085a  vmovaps [rsp+0xA0], xmm10
00007d0bb21e0863  vmovaps [rsp+0xB0], xmm11
00007d0bb21e086c  vmovaps [rsp+0xC0], xmm12
00007d0bb21e0875  vmovaps [rsp+0xD0], xmm13
00007d0bb21e087e  vmovaps [rsp+0xE0], xmm15
00007d0bb21e0887  sub rsp, 0x30
00007d0bb21e088b  movaps [rsp], xmm14
00007d0bb21e0890  movaps [rsp+0x10], xmm4
00007d0bb21e0895  movaps [rsp+0x20], xmm3
00007d0bb21e089a  lea rdi, [rsp]
00007d0bb21e089e  mov esi, 0x00
00007d0bb21e08a3  mov rax, 0x6392BBE7F530
00007d0bb21e08ad  call rax
00007d0bb21e08af  movaps xmm14, [rsp]
00007d0bb21e08b4  add rsp, 0x30
00007d0bb21e08b8  vmovaps xmm0, [rsp]
00007d0bb21e08bd  vmovaps xmm1, [rsp+0x10]
00007d0bb21e08c3  vmovaps xmm2, [rsp+0x20]
00007d0bb21e08c9  vmovaps xmm3, [rsp+0x30]
00007d0bb21e08cf  vmovaps xmm4, [rsp+0x40]
00007d0bb21e08d5  vmovaps xmm5, [rsp+0x50]
00007d0bb21e08db  vmovaps xmm6, [rsp+0x60]
00007d0bb21e08e1  vmovaps xmm7, [rsp+0x70]
00007d0bb21e08e7  vmovaps xmm8, [rsp+0x80]
00007d0bb21e08f0  vmovaps xmm9, [rsp+0x90]
00007d0bb21e08f9  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e0902  vmovaps xmm11, [rsp+0xB0]
00007d0bb21e090b  vmovaps xmm12, [rsp+0xC0]
00007d0bb21e0914  vmovaps xmm13, [rsp+0xD0]
00007d0bb21e091d  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e0926  add rsp, 0xF0
00007d0bb21e092d  pop r11
00007d0bb21e092f  pop r10
00007d0bb21e0931  pop r9
00007d0bb21e0933  pop r8
00007d0bb21e0935  pop rsi
00007d0bb21e0936  pop rdi
00007d0bb21e0937  pop rdx
00007d0bb21e0938  pop rcx
00007d0bb21e0939  pop rax
00007d0bb21e093a  add rsp, 0x08
00007d0bb21e093e  jmp 0x00007D0BB21DF022
00007d0bb21e0943  sub rsp, 0x08
00007d0bb21e0947  push rax
00007d0bb21e0948  push rcx
00007d0bb21e0949  push rdx
00007d0bb21e094a  push rdi
00007d0bb21e094b  push rsi
00007d0bb21e094c  push r8
00007d0bb21e094e  push r9
00007d0bb21e0950  push r10
00007d0bb21e0952  push r11
00007d0bb21e0954  sub rsp, 0xF0
00007d0bb21e095b  vmovaps [rsp], xmm0
00007d0bb21e0960  vmovaps [rsp+0x10], xmm1
00007d0bb21e0966  vmovaps [rsp+0x20], xmm2
00007d0bb21e096c  vmovaps [rsp+0x30], xmm3
00007d0bb21e0972  vmovaps [rsp+0x40], xmm4
00007d0bb21e0978  vmovaps [rsp+0x50], xmm5
00007d0bb21e097e  vmovaps [rsp+0x60], xmm7
00007d0bb21e0984  vmovaps [rsp+0x70], xmm8
00007d0bb21e098a  vmovaps [rsp+0x80], xmm9
00007d0bb21e0993  vmovaps [rsp+0x90], xmm10
00007d0bb21e099c  vmovaps [rsp+0xA0], xmm11
00007d0bb21e09a5  vmovaps [rsp+0xB0], xmm12
00007d0bb21e09ae  vmovaps [rsp+0xC0], xmm13
00007d0bb21e09b7  vmovaps [rsp+0xD0], xmm14
00007d0bb21e09c0  vmovaps [rsp+0xE0], xmm15
00007d0bb21e09c9  sub rsp, 0x30
00007d0bb21e09cd  movaps [rsp], xmm6
00007d0bb21e09d1  movaps [rsp+0x10], xmm9
00007d0bb21e09d7  movaps [rsp+0x20], xmm7
00007d0bb21e09dc  lea rdi, [rsp]
00007d0bb21e09e0  mov esi, 0x00
00007d0bb21e09e5  mov rax, 0x6392BBE7F530
00007d0bb21e09ef  call rax
00007d0bb21e09f1  movaps xmm6, [rsp]
00007d0bb21e09f5  add rsp, 0x30
00007d0bb21e09f9  vmovaps xmm0, [rsp]
00007d0bb21e09fe  vmovaps xmm1, [rsp+0x10]
00007d0bb21e0a04  vmovaps xmm2, [rsp+0x20]
00007d0bb21e0a0a  vmovaps xmm3, [rsp+0x30]
00007d0bb21e0a10  vmovaps xmm4, [rsp+0x40]
00007d0bb21e0a16  vmovaps xmm5, [rsp+0x50]
00007d0bb21e0a1c  vmovaps xmm7, [rsp+0x60]
00007d0bb21e0a22  vmovaps xmm8, [rsp+0x70]
00007d0bb21e0a28  vmovaps xmm9, [rsp+0x80]
00007d0bb21e0a31  vmovaps xmm10, [rsp+0x90]
00007d0bb21e0a3a  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e0a43  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e0a4c  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e0a55  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e0a5e  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e0a67  add rsp, 0xF0
00007d0bb21e0a6e  pop r11
00007d0bb21e0a70  pop r10
00007d0bb21e0a72  pop r9
00007d0bb21e0a74  pop r8
00007d0bb21e0a76  pop rsi
00007d0bb21e0a77  pop rdi
00007d0bb21e0a78  pop rdx
00007d0bb21e0a79  pop rcx
00007d0bb21e0a7a  pop rax
00007d0bb21e0a7b  add rsp, 0x08
00007d0bb21e0a7f  jmp 0x00007D0BB21DF03A
00007d0bb21e0a84  sub rsp, 0x08
00007d0bb21e0a88  push rax
00007d0bb21e0a89  push rcx
00007d0bb21e0a8a  push rdx
00007d0bb21e0a8b  push rdi
00007d0bb21e0a8c  push rsi
00007d0bb21e0a8d  push r8
00007d0bb21e0a8f  push r9
00007d0bb21e0a91  push r10
00007d0bb21e0a93  push r11
00007d0bb21e0a95  sub rsp, 0xF0
00007d0bb21e0a9c  vmovaps [rsp], xmm0
00007d0bb21e0aa1  vmovaps [rsp+0x10], xmm1
00007d0bb21e0aa7  vmovaps [rsp+0x20], xmm2
00007d0bb21e0aad  vmovaps [rsp+0x30], xmm3
00007d0bb21e0ab3  vmovaps [rsp+0x40], xmm4
00007d0bb21e0ab9  vmovaps [rsp+0x50], xmm5
00007d0bb21e0abf  vmovaps [rsp+0x60], xmm6
00007d0bb21e0ac5  vmovaps [rsp+0x70], xmm8
00007d0bb21e0acb  vmovaps [rsp+0x80], xmm9
00007d0bb21e0ad4  vmovaps [rsp+0x90], xmm10
00007d0bb21e0add  vmovaps [rsp+0xA0], xmm11
00007d0bb21e0ae6  vmovaps [rsp+0xB0], xmm12
00007d0bb21e0aef  vmovaps [rsp+0xC0], xmm13
00007d0bb21e0af8  vmovaps [rsp+0xD0], xmm14
00007d0bb21e0b01  vmovaps [rsp+0xE0], xmm15
00007d0bb21e0b0a  sub rsp, 0x30
00007d0bb21e0b0e  movaps [rsp], xmm7
00007d0bb21e0b12  movaps [rsp+0x10], xmm4
00007d0bb21e0b17  movaps [rsp+0x20], xmm9
00007d0bb21e0b1d  lea rdi, [rsp]
00007d0bb21e0b21  mov esi, 0x00
00007d0bb21e0b26  mov rax, 0x6392BBE7F530
00007d0bb21e0b30  call rax
00007d0bb21e0b32  movaps xmm7, [rsp]
00007d0bb21e0b36  add rsp, 0x30
00007d0bb21e0b3a  vmovaps xmm0, [rsp]
00007d0bb21e0b3f  vmovaps xmm1, [rsp+0x10]
00007d0bb21e0b45  vmovaps xmm2, [rsp+0x20]
00007d0bb21e0b4b  vmovaps xmm3, [rsp+0x30]
00007d0bb21e0b51  vmovaps xmm4, [rsp+0x40]
00007d0bb21e0b57  vmovaps xmm5, [rsp+0x50]
00007d0bb21e0b5d  vmovaps xmm6, [rsp+0x60]
00007d0bb21e0b63  vmovaps xmm8, [rsp+0x70]
00007d0bb21e0b69  vmovaps xmm9, [rsp+0x80]
00007d0bb21e0b72  vmovaps xmm10, [rsp+0x90]
00007d0bb21e0b7b  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e0b84  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e0b8d  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e0b96  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e0b9f  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e0ba8  add rsp, 0xF0
00007d0bb21e0baf  pop r11
00007d0bb21e0bb1  pop r10
00007d0bb21e0bb3  pop r9
00007d0bb21e0bb5  pop r8
00007d0bb21e0bb7  pop rsi
00007d0bb21e0bb8  pop rdi
00007d0bb21e0bb9  pop rdx
00007d0bb21e0bba  pop rcx
00007d0bb21e0bbb  pop rax
00007d0bb21e0bbc  add rsp, 0x08
00007d0bb21e0bc0  jmp 0x00007D0BB21DF067
00007d0bb21e0bc5  sub rsp, 0x08
00007d0bb21e0bc9  push rax
00007d0bb21e0bca  push rcx
00007d0bb21e0bcb  push rdx
00007d0bb21e0bcc  push rdi
00007d0bb21e0bcd  push rsi
00007d0bb21e0bce  push r8
00007d0bb21e0bd0  push r9
00007d0bb21e0bd2  push r10
00007d0bb21e0bd4  push r11
00007d0bb21e0bd6  sub rsp, 0xF0
00007d0bb21e0bdd  vmovaps [rsp], xmm0
00007d0bb21e0be2  vmovaps [rsp+0x10], xmm1
00007d0bb21e0be8  vmovaps [rsp+0x20], xmm2
00007d0bb21e0bee  vmovaps [rsp+0x30], xmm3
00007d0bb21e0bf4  vmovaps [rsp+0x40], xmm5
00007d0bb21e0bfa  vmovaps [rsp+0x50], xmm6
00007d0bb21e0c00  vmovaps [rsp+0x60], xmm7
00007d0bb21e0c06  vmovaps [rsp+0x70], xmm8
00007d0bb21e0c0c  vmovaps [rsp+0x80], xmm9
00007d0bb21e0c15  vmovaps [rsp+0x90], xmm10
00007d0bb21e0c1e  vmovaps [rsp+0xA0], xmm11
00007d0bb21e0c27  vmovaps [rsp+0xB0], xmm12
00007d0bb21e0c30  vmovaps [rsp+0xC0], xmm13
00007d0bb21e0c39  vmovaps [rsp+0xD0], xmm14
00007d0bb21e0c42  vmovaps [rsp+0xE0], xmm15
00007d0bb21e0c4b  sub rsp, 0x30
00007d0bb21e0c4f  movaps [rsp], xmm4
00007d0bb21e0c53  movaps [rsp+0x10], xmm15
00007d0bb21e0c59  movaps [rsp+0x20], xmm9
00007d0bb21e0c5f  lea rdi, [rsp]
00007d0bb21e0c63  mov esi, 0x00
00007d0bb21e0c68  mov rax, 0x6392BBE7F530
00007d0bb21e0c72  call rax
00007d0bb21e0c74  movaps xmm4, [rsp]
00007d0bb21e0c78  add rsp, 0x30
00007d0bb21e0c7c  vmovaps xmm0, [rsp]
00007d0bb21e0c81  vmovaps xmm1, [rsp+0x10]
00007d0bb21e0c87  vmovaps xmm2, [rsp+0x20]
00007d0bb21e0c8d  vmovaps xmm3, [rsp+0x30]
00007d0bb21e0c93  vmovaps xmm5, [rsp+0x40]
00007d0bb21e0c99  vmovaps xmm6, [rsp+0x50]
00007d0bb21e0c9f  vmovaps xmm7, [rsp+0x60]
00007d0bb21e0ca5  vmovaps xmm8, [rsp+0x70]
00007d0bb21e0cab  vmovaps xmm9, [rsp+0x80]
00007d0bb21e0cb4  vmovaps xmm10, [rsp+0x90]
00007d0bb21e0cbd  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e0cc6  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e0ccf  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e0cd8  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e0ce1  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e0cea  add rsp, 0xF0
00007d0bb21e0cf1  pop r11
00007d0bb21e0cf3  pop r10
00007d0bb21e0cf5  pop r9
00007d0bb21e0cf7  pop r8
00007d0bb21e0cf9  pop rsi
00007d0bb21e0cfa  pop rdi
00007d0bb21e0cfb  pop rdx
00007d0bb21e0cfc  pop rcx
00007d0bb21e0cfd  pop rax
00007d0bb21e0cfe  add rsp, 0x08
00007d0bb21e0d02  jmp 0x00007D0BB21DF08C
00007d0bb21e0d07  call 0x00007D0BB20C4620
00007d0bb21e0d0c  jmp 0x00007D0BB21DF099
00007d0bb21e0d11  sub rsp, 0x08
00007d0bb21e0d15  push rax
00007d0bb21e0d16  push rcx
00007d0bb21e0d17  push rdx
00007d0bb21e0d18  push rdi
00007d0bb21e0d19  push rsi
00007d0bb21e0d1a  push r8
00007d0bb21e0d1c  push r9
00007d0bb21e0d1e  push r10
00007d0bb21e0d20  push r11
00007d0bb21e0d22  sub rsp, 0xF0
00007d0bb21e0d29  vmovaps [rsp], xmm0
00007d0bb21e0d2e  vmovaps [rsp+0x10], xmm1
00007d0bb21e0d34  vmovaps [rsp+0x20], xmm2
00007d0bb21e0d3a  vmovaps [rsp+0x30], xmm4
00007d0bb21e0d40  vmovaps [rsp+0x40], xmm5
00007d0bb21e0d46  vmovaps [rsp+0x50], xmm6
00007d0bb21e0d4c  vmovaps [rsp+0x60], xmm7
00007d0bb21e0d52  vmovaps [rsp+0x70], xmm8
00007d0bb21e0d58  vmovaps [rsp+0x80], xmm9
00007d0bb21e0d61  vmovaps [rsp+0x90], xmm10
00007d0bb21e0d6a  vmovaps [rsp+0xA0], xmm11
00007d0bb21e0d73  vmovaps [rsp+0xB0], xmm12
00007d0bb21e0d7c  vmovaps [rsp+0xC0], xmm13
00007d0bb21e0d85  vmovaps [rsp+0xD0], xmm14
00007d0bb21e0d8e  vmovaps [rsp+0xE0], xmm15
00007d0bb21e0d97  sub rsp, 0x30
00007d0bb21e0d9b  movaps [rsp], xmm3
00007d0bb21e0d9f  movaps [rsp+0x10], xmm1
00007d0bb21e0da4  movaps [rsp+0x20], xmm9
00007d0bb21e0daa  lea rdi, [rsp]
00007d0bb21e0dae  mov esi, 0x00
00007d0bb21e0db3  mov rax, 0x6392BBE7F530
00007d0bb21e0dbd  call rax
00007d0bb21e0dbf  movaps xmm3, [rsp]
00007d0bb21e0dc3  add rsp, 0x30
00007d0bb21e0dc7  vmovaps xmm0, [rsp]
00007d0bb21e0dcc  vmovaps xmm1, [rsp+0x10]
00007d0bb21e0dd2  vmovaps xmm2, [rsp+0x20]
00007d0bb21e0dd8  vmovaps xmm4, [rsp+0x30]
00007d0bb21e0dde  vmovaps xmm5, [rsp+0x40]
00007d0bb21e0de4  vmovaps xmm6, [rsp+0x50]
00007d0bb21e0dea  vmovaps xmm7, [rsp+0x60]
00007d0bb21e0df0  vmovaps xmm8, [rsp+0x70]
00007d0bb21e0df6  vmovaps xmm9, [rsp+0x80]
00007d0bb21e0dff  vmovaps xmm10, [rsp+0x90]
00007d0bb21e0e08  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e0e11  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e0e1a  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e0e23  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e0e2c  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e0e35  add rsp, 0xF0
00007d0bb21e0e3c  pop r11
00007d0bb21e0e3e  pop r10
00007d0bb21e0e40  pop r9
00007d0bb21e0e42  pop r8
00007d0bb21e0e44  pop rsi
00007d0bb21e0e45  pop rdi
00007d0bb21e0e46  pop rdx
00007d0bb21e0e47  pop rcx
00007d0bb21e0e48  pop rax
00007d0bb21e0e49  add rsp, 0x08
00007d0bb21e0e4d  jmp 0x00007D0BB21DF0D6
00007d0bb21e0e52  sub rsp, 0x08
00007d0bb21e0e56  push rax
00007d0bb21e0e57  push rcx
00007d0bb21e0e58  push rdx
00007d0bb21e0e59  push rdi
00007d0bb21e0e5a  push rsi
00007d0bb21e0e5b  push r8
00007d0bb21e0e5d  push r9
00007d0bb21e0e5f  push r10
00007d0bb21e0e61  push r11
00007d0bb21e0e63  sub rsp, 0xF0
00007d0bb21e0e6a  vmovaps [rsp], xmm0
00007d0bb21e0e6f  vmovaps [rsp+0x10], xmm2
00007d0bb21e0e75  vmovaps [rsp+0x20], xmm3
00007d0bb21e0e7b  vmovaps [rsp+0x30], xmm4
00007d0bb21e0e81  vmovaps [rsp+0x40], xmm5
00007d0bb21e0e87  vmovaps [rsp+0x50], xmm6
00007d0bb21e0e8d  vmovaps [rsp+0x60], xmm7
00007d0bb21e0e93  vmovaps [rsp+0x70], xmm8
00007d0bb21e0e99  vmovaps [rsp+0x80], xmm9
00007d0bb21e0ea2  vmovaps [rsp+0x90], xmm10
00007d0bb21e0eab  vmovaps [rsp+0xA0], xmm11
00007d0bb21e0eb4  vmovaps [rsp+0xB0], xmm12
00007d0bb21e0ebd  vmovaps [rsp+0xC0], xmm13
00007d0bb21e0ec6  vmovaps [rsp+0xD0], xmm14
00007d0bb21e0ecf  vmovaps [rsp+0xE0], xmm15
00007d0bb21e0ed8  sub rsp, 0x30
00007d0bb21e0edc  movaps [rsp], xmm1
00007d0bb21e0ee0  movaps [rsp+0x10], xmm15
00007d0bb21e0ee6  movaps [rsp+0x20], xmm9
00007d0bb21e0eec  lea rdi, [rsp]
00007d0bb21e0ef0  mov esi, 0x00
00007d0bb21e0ef5  mov rax, 0x6392BBE7F530
00007d0bb21e0eff  call rax
00007d0bb21e0f01  movaps xmm1, [rsp]
00007d0bb21e0f05  add rsp, 0x30
00007d0bb21e0f09  vmovaps xmm0, [rsp]
00007d0bb21e0f0e  vmovaps xmm2, [rsp+0x10]
00007d0bb21e0f14  vmovaps xmm3, [rsp+0x20]
00007d0bb21e0f1a  vmovaps xmm4, [rsp+0x30]
00007d0bb21e0f20  vmovaps xmm5, [rsp+0x40]
00007d0bb21e0f26  vmovaps xmm6, [rsp+0x50]
00007d0bb21e0f2c  vmovaps xmm7, [rsp+0x60]
00007d0bb21e0f32  vmovaps xmm8, [rsp+0x70]
00007d0bb21e0f38  vmovaps xmm9, [rsp+0x80]
00007d0bb21e0f41  vmovaps xmm10, [rsp+0x90]
00007d0bb21e0f4a  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e0f53  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e0f5c  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e0f65  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e0f6e  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e0f77  add rsp, 0xF0
00007d0bb21e0f7e  pop r11
00007d0bb21e0f80  pop r10
00007d0bb21e0f82  pop r9
00007d0bb21e0f84  pop r8
00007d0bb21e0f86  pop rsi
00007d0bb21e0f87  pop rdi
00007d0bb21e0f88  pop rdx
00007d0bb21e0f89  pop rcx
00007d0bb21e0f8a  pop rax
00007d0bb21e0f8b  add rsp, 0x08
00007d0bb21e0f8f  jmp 0x00007D0BB21DF15E
00007d0bb21e0f94  call 0x00007D0BB20C4620
00007d0bb21e0f99  jmp 0x00007D0BB21DF16B
00007d0bb21e0f9e  sub rsp, 0x08
00007d0bb21e0fa2  push rax
00007d0bb21e0fa3  push rcx
00007d0bb21e0fa4  push rdx
00007d0bb21e0fa5  push rdi
00007d0bb21e0fa6  push rsi
00007d0bb21e0fa7  push r8
00007d0bb21e0fa9  push r9
00007d0bb21e0fab  push r10
00007d0bb21e0fad  push r11
00007d0bb21e0faf  sub rsp, 0xF0
00007d0bb21e0fb6  vmovaps [rsp], xmm0
00007d0bb21e0fbb  vmovaps [rsp+0x10], xmm2
00007d0bb21e0fc1  vmovaps [rsp+0x20], xmm3
00007d0bb21e0fc7  vmovaps [rsp+0x30], xmm4
00007d0bb21e0fcd  vmovaps [rsp+0x40], xmm5
00007d0bb21e0fd3  vmovaps [rsp+0x50], xmm6
00007d0bb21e0fd9  vmovaps [rsp+0x60], xmm7
00007d0bb21e0fdf  vmovaps [rsp+0x70], xmm8
00007d0bb21e0fe5  vmovaps [rsp+0x80], xmm9
00007d0bb21e0fee  vmovaps [rsp+0x90], xmm10
00007d0bb21e0ff7  vmovaps [rsp+0xA0], xmm11
00007d0bb21e1000  vmovaps [rsp+0xB0], xmm12
00007d0bb21e1009  vmovaps [rsp+0xC0], xmm13
00007d0bb21e1012  vmovaps [rsp+0xD0], xmm14
00007d0bb21e101b  vmovaps [rsp+0xE0], xmm15
00007d0bb21e1024  sub rsp, 0x30
00007d0bb21e1028  movaps [rsp], xmm1
00007d0bb21e102c  movaps [rsp+0x10], xmm5
00007d0bb21e1031  movaps [rsp+0x20], xmm7
00007d0bb21e1036  lea rdi, [rsp]
00007d0bb21e103a  mov esi, 0x00
00007d0bb21e103f  mov rax, 0x6392BBE7F530
00007d0bb21e1049  call rax
00007d0bb21e104b  movaps xmm1, [rsp]
00007d0bb21e104f  add rsp, 0x30
00007d0bb21e1053  vmovaps xmm0, [rsp]
00007d0bb21e1058  vmovaps xmm2, [rsp+0x10]
00007d0bb21e105e  vmovaps xmm3, [rsp+0x20]
00007d0bb21e1064  vmovaps xmm4, [rsp+0x30]
00007d0bb21e106a  vmovaps xmm5, [rsp+0x40]
00007d0bb21e1070  vmovaps xmm6, [rsp+0x50]
00007d0bb21e1076  vmovaps xmm7, [rsp+0x60]
00007d0bb21e107c  vmovaps xmm8, [rsp+0x70]
00007d0bb21e1082  vmovaps xmm9, [rsp+0x80]
00007d0bb21e108b  vmovaps xmm10, [rsp+0x90]
00007d0bb21e1094  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e109d  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e10a6  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e10af  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e10b8  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e10c1  add rsp, 0xF0
00007d0bb21e10c8  pop r11
00007d0bb21e10ca  pop r10
00007d0bb21e10cc  pop r9
00007d0bb21e10ce  pop r8
00007d0bb21e10d0  pop rsi
00007d0bb21e10d1  pop rdi
00007d0bb21e10d2  pop rdx
00007d0bb21e10d3  pop rcx
00007d0bb21e10d4  pop rax
00007d0bb21e10d5  add rsp, 0x08
00007d0bb21e10d9  jmp 0x00007D0BB21DF210
00007d0bb21e10de  sub rsp, 0x08
00007d0bb21e10e2  push rax
00007d0bb21e10e3  push rcx
00007d0bb21e10e4  push rdx
00007d0bb21e10e5  push rdi
00007d0bb21e10e6  push rsi
00007d0bb21e10e7  push r8
00007d0bb21e10e9  push r9
00007d0bb21e10eb  push r10
00007d0bb21e10ed  push r11
00007d0bb21e10ef  sub rsp, 0xF0
00007d0bb21e10f6  vmovaps [rsp], xmm0
00007d0bb21e10fb  vmovaps [rsp+0x10], xmm1
00007d0bb21e1101  vmovaps [rsp+0x20], xmm2
00007d0bb21e1107  vmovaps [rsp+0x30], xmm3
00007d0bb21e110d  vmovaps [rsp+0x40], xmm4
00007d0bb21e1113  vmovaps [rsp+0x50], xmm5
00007d0bb21e1119  vmovaps [rsp+0x60], xmm6
00007d0bb21e111f  vmovaps [rsp+0x70], xmm8
00007d0bb21e1125  vmovaps [rsp+0x80], xmm9
00007d0bb21e112e  vmovaps [rsp+0x90], xmm10
00007d0bb21e1137  vmovaps [rsp+0xA0], xmm11
00007d0bb21e1140  vmovaps [rsp+0xB0], xmm12
00007d0bb21e1149  vmovaps [rsp+0xC0], xmm13
00007d0bb21e1152  vmovaps [rsp+0xD0], xmm14
00007d0bb21e115b  vmovaps [rsp+0xE0], xmm15
00007d0bb21e1164  sub rsp, 0x30
00007d0bb21e1168  movaps [rsp], xmm7
00007d0bb21e116c  movaps [rsp+0x10], xmm5
00007d0bb21e1171  movaps [rsp+0x20], xmm15
00007d0bb21e1177  lea rdi, [rsp]
00007d0bb21e117b  mov esi, 0x00
00007d0bb21e1180  mov rax, 0x6392BBE7F530
00007d0bb21e118a  call rax
00007d0bb21e118c  movaps xmm7, [rsp]
00007d0bb21e1190  add rsp, 0x30
00007d0bb21e1194  vmovaps xmm0, [rsp]
00007d0bb21e1199  vmovaps xmm1, [rsp+0x10]
00007d0bb21e119f  vmovaps xmm2, [rsp+0x20]
00007d0bb21e11a5  vmovaps xmm3, [rsp+0x30]
00007d0bb21e11ab  vmovaps xmm4, [rsp+0x40]
00007d0bb21e11b1  vmovaps xmm5, [rsp+0x50]
00007d0bb21e11b7  vmovaps xmm6, [rsp+0x60]
00007d0bb21e11bd  vmovaps xmm8, [rsp+0x70]
00007d0bb21e11c3  vmovaps xmm9, [rsp+0x80]
00007d0bb21e11cc  vmovaps xmm10, [rsp+0x90]
00007d0bb21e11d5  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e11de  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e11e7  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e11f0  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e11f9  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e1202  add rsp, 0xF0
00007d0bb21e1209  pop r11
00007d0bb21e120b  pop r10
00007d0bb21e120d  pop r9
00007d0bb21e120f  pop r8
00007d0bb21e1211  pop rsi
00007d0bb21e1212  pop rdi
00007d0bb21e1213  pop rdx
00007d0bb21e1214  pop rcx
00007d0bb21e1215  pop rax
00007d0bb21e1216  add rsp, 0x08
00007d0bb21e121a  jmp 0x00007D0BB21DF246
00007d0bb21e121f  call 0x00007D0BB20B52F0
00007d0bb21e1224  jmp 0x00007D0BB21DF253
00007d0bb21e1229  sub rsp, 0x08
00007d0bb21e122d  push rax
00007d0bb21e122e  push rcx
00007d0bb21e122f  push rdx
00007d0bb21e1230  push rdi
00007d0bb21e1231  push rsi
00007d0bb21e1232  push r8
00007d0bb21e1234  push r9
00007d0bb21e1236  push r10
00007d0bb21e1238  push r11
00007d0bb21e123a  sub rsp, 0xF0
00007d0bb21e1241  vmovaps [rsp], xmm0
00007d0bb21e1246  vmovaps [rsp+0x10], xmm1
00007d0bb21e124c  vmovaps [rsp+0x20], xmm2
00007d0bb21e1252  vmovaps [rsp+0x30], xmm3
00007d0bb21e1258  vmovaps [rsp+0x40], xmm4
00007d0bb21e125e  vmovaps [rsp+0x50], xmm5
00007d0bb21e1264  vmovaps [rsp+0x60], xmm6
00007d0bb21e126a  vmovaps [rsp+0x70], xmm7
00007d0bb21e1270  vmovaps [rsp+0x80], xmm8
00007d0bb21e1279  vmovaps [rsp+0x90], xmm9
00007d0bb21e1282  vmovaps [rsp+0xA0], xmm10
00007d0bb21e128b  vmovaps [rsp+0xB0], xmm11
00007d0bb21e1294  vmovaps [rsp+0xC0], xmm12
00007d0bb21e129d  vmovaps [rsp+0xD0], xmm13
00007d0bb21e12a6  vmovaps [rsp+0xE0], xmm14
00007d0bb21e12af  sub rsp, 0x30
00007d0bb21e12b3  movaps [rsp], xmm15
00007d0bb21e12b8  movaps [rsp+0x10], xmm5
00007d0bb21e12bd  movaps [rsp+0x20], xmm3
00007d0bb21e12c2  lea rdi, [rsp]
00007d0bb21e12c6  mov esi, 0x00
00007d0bb21e12cb  mov rax, 0x6392BBE7F530
00007d0bb21e12d5  call rax
00007d0bb21e12d7  movaps xmm15, [rsp]
00007d0bb21e12dc  add rsp, 0x30
00007d0bb21e12e0  vmovaps xmm0, [rsp]
00007d0bb21e12e5  vmovaps xmm1, [rsp+0x10]
00007d0bb21e12eb  vmovaps xmm2, [rsp+0x20]
00007d0bb21e12f1  vmovaps xmm3, [rsp+0x30]
00007d0bb21e12f7  vmovaps xmm4, [rsp+0x40]
00007d0bb21e12fd  vmovaps xmm5, [rsp+0x50]
00007d0bb21e1303  vmovaps xmm6, [rsp+0x60]
00007d0bb21e1309  vmovaps xmm7, [rsp+0x70]
00007d0bb21e130f  vmovaps xmm8, [rsp+0x80]
00007d0bb21e1318  vmovaps xmm9, [rsp+0x90]
00007d0bb21e1321  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e132a  vmovaps xmm11, [rsp+0xB0]
00007d0bb21e1333  vmovaps xmm12, [rsp+0xC0]
00007d0bb21e133c  vmovaps xmm13, [rsp+0xD0]
00007d0bb21e1345  vmovaps xmm14, [rsp+0xE0]
00007d0bb21e134e  add rsp, 0xF0
00007d0bb21e1355  pop r11
00007d0bb21e1357  pop r10
00007d0bb21e1359  pop r9
00007d0bb21e135b  pop r8
00007d0bb21e135d  pop rsi
00007d0bb21e135e  pop rdi
00007d0bb21e135f  pop rdx
00007d0bb21e1360  pop rcx
00007d0bb21e1361  pop rax
00007d0bb21e1362  add rsp, 0x08
00007d0bb21e1366  jmp 0x00007D0BB21DF279
00007d0bb21e136b  sub rsp, 0x08
00007d0bb21e136f  push rax
00007d0bb21e1370  push rcx
00007d0bb21e1371  push rdx
00007d0bb21e1372  push rdi
00007d0bb21e1373  push rsi
00007d0bb21e1374  push r8
00007d0bb21e1376  push r9
00007d0bb21e1378  push r10
00007d0bb21e137a  push r11
00007d0bb21e137c  sub rsp, 0xF0
00007d0bb21e1383  vmovaps [rsp], xmm0
00007d0bb21e1388  vmovaps [rsp+0x10], xmm2
00007d0bb21e138e  vmovaps [rsp+0x20], xmm3
00007d0bb21e1394  vmovaps [rsp+0x30], xmm4
00007d0bb21e139a  vmovaps [rsp+0x40], xmm5
00007d0bb21e13a0  vmovaps [rsp+0x50], xmm6
00007d0bb21e13a6  vmovaps [rsp+0x60], xmm7
00007d0bb21e13ac  vmovaps [rsp+0x70], xmm8
00007d0bb21e13b2  vmovaps [rsp+0x80], xmm9
00007d0bb21e13bb  vmovaps [rsp+0x90], xmm10
00007d0bb21e13c4  vmovaps [rsp+0xA0], xmm11
00007d0bb21e13cd  vmovaps [rsp+0xB0], xmm12
00007d0bb21e13d6  vmovaps [rsp+0xC0], xmm13
00007d0bb21e13df  vmovaps [rsp+0xD0], xmm14
00007d0bb21e13e8  vmovaps [rsp+0xE0], xmm15
00007d0bb21e13f1  sub rsp, 0x30
00007d0bb21e13f5  movaps [rsp], xmm1
00007d0bb21e13f9  movaps [rsp+0x10], xmm5
00007d0bb21e13fe  movaps [rsp+0x20], xmm4
00007d0bb21e1403  lea rdi, [rsp]
00007d0bb21e1407  mov esi, 0x00
00007d0bb21e140c  mov rax, 0x6392BBE7F530
00007d0bb21e1416  call rax
00007d0bb21e1418  movaps xmm1, [rsp]
00007d0bb21e141c  add rsp, 0x30
00007d0bb21e1420  vmovaps xmm0, [rsp]
00007d0bb21e1425  vmovaps xmm2, [rsp+0x10]
00007d0bb21e142b  vmovaps xmm3, [rsp+0x20]
00007d0bb21e1431  vmovaps xmm4, [rsp+0x30]
00007d0bb21e1437  vmovaps xmm5, [rsp+0x40]
00007d0bb21e143d  vmovaps xmm6, [rsp+0x50]
00007d0bb21e1443  vmovaps xmm7, [rsp+0x60]
00007d0bb21e1449  vmovaps xmm8, [rsp+0x70]
00007d0bb21e144f  vmovaps xmm9, [rsp+0x80]
00007d0bb21e1458  vmovaps xmm10, [rsp+0x90]
00007d0bb21e1461  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e146a  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e1473  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e147c  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e1485  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e148e  add rsp, 0xF0
00007d0bb21e1495  pop r11
00007d0bb21e1497  pop r10
00007d0bb21e1499  pop r9
00007d0bb21e149b  pop r8
00007d0bb21e149d  pop rsi
00007d0bb21e149e  pop rdi
00007d0bb21e149f  pop rdx
00007d0bb21e14a0  pop rcx
00007d0bb21e14a1  pop rax
00007d0bb21e14a2  add rsp, 0x08
00007d0bb21e14a6  jmp 0x00007D0BB21DF299
00007d0bb21e14ab  sub rsp, 0x08
00007d0bb21e14af  push rax
00007d0bb21e14b0  push rcx
00007d0bb21e14b1  push rdx
00007d0bb21e14b2  push rdi
00007d0bb21e14b3  push rsi
00007d0bb21e14b4  push r8
00007d0bb21e14b6  push r9
00007d0bb21e14b8  push r10
00007d0bb21e14ba  push r11
00007d0bb21e14bc  sub rsp, 0xF0
00007d0bb21e14c3  vmovaps [rsp], xmm0
00007d0bb21e14c8  vmovaps [rsp+0x10], xmm1
00007d0bb21e14ce  vmovaps [rsp+0x20], xmm2
00007d0bb21e14d4  vmovaps [rsp+0x30], xmm3
00007d0bb21e14da  vmovaps [rsp+0x40], xmm5
00007d0bb21e14e0  vmovaps [rsp+0x50], xmm6
00007d0bb21e14e6  vmovaps [rsp+0x60], xmm7
00007d0bb21e14ec  vmovaps [rsp+0x70], xmm8
00007d0bb21e14f2  vmovaps [rsp+0x80], xmm9
00007d0bb21e14fb  vmovaps [rsp+0x90], xmm10
00007d0bb21e1504  vmovaps [rsp+0xA0], xmm11
00007d0bb21e150d  vmovaps [rsp+0xB0], xmm12
00007d0bb21e1516  vmovaps [rsp+0xC0], xmm13
00007d0bb21e151f  vmovaps [rsp+0xD0], xmm14
00007d0bb21e1528  vmovaps [rsp+0xE0], xmm15
00007d0bb21e1531  sub rsp, 0x30
00007d0bb21e1535  movaps [rsp], xmm4
00007d0bb21e1539  movaps [rsp+0x10], xmm3
00007d0bb21e153e  movaps [rsp+0x20], xmm5
00007d0bb21e1543  lea rdi, [rsp]
00007d0bb21e1547  mov esi, 0x00
00007d0bb21e154c  mov rax, 0x6392BBE7F530
00007d0bb21e1556  call rax
00007d0bb21e1558  movaps xmm4, [rsp]
00007d0bb21e155c  add rsp, 0x30
00007d0bb21e1560  vmovaps xmm0, [rsp]
00007d0bb21e1565  vmovaps xmm1, [rsp+0x10]
00007d0bb21e156b  vmovaps xmm2, [rsp+0x20]
00007d0bb21e1571  vmovaps xmm3, [rsp+0x30]
00007d0bb21e1577  vmovaps xmm5, [rsp+0x40]
00007d0bb21e157d  vmovaps xmm6, [rsp+0x50]
00007d0bb21e1583  vmovaps xmm7, [rsp+0x60]
00007d0bb21e1589  vmovaps xmm8, [rsp+0x70]
00007d0bb21e158f  vmovaps xmm9, [rsp+0x80]
00007d0bb21e1598  vmovaps xmm10, [rsp+0x90]
00007d0bb21e15a1  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e15aa  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e15b3  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e15bc  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e15c5  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e15ce  add rsp, 0xF0
00007d0bb21e15d5  pop r11
00007d0bb21e15d7  pop r10
00007d0bb21e15d9  pop r9
00007d0bb21e15db  pop r8
00007d0bb21e15dd  pop rsi
00007d0bb21e15de  pop rdi
00007d0bb21e15df  pop rdx
00007d0bb21e15e0  pop rcx
00007d0bb21e15e1  pop rax
00007d0bb21e15e2  add rsp, 0x08
00007d0bb21e15e6  jmp 0x00007D0BB21DF2E7
00007d0bb21e15eb  call 0x00007D0BB20B52F0
00007d0bb21e15f0  jmp 0x00007D0BB21DF2F4
00007d0bb21e15f5  sub rsp, 0x08
00007d0bb21e15f9  push rax
00007d0bb21e15fa  push rcx
00007d0bb21e15fb  push rdx
00007d0bb21e15fc  push rdi
00007d0bb21e15fd  push rsi
00007d0bb21e15fe  push r8
00007d0bb21e1600  push r9
00007d0bb21e1602  push r10
00007d0bb21e1604  push r11
00007d0bb21e1606  sub rsp, 0xF0
00007d0bb21e160d  vmovaps [rsp], xmm0
00007d0bb21e1612  vmovaps [rsp+0x10], xmm1
00007d0bb21e1618  vmovaps [rsp+0x20], xmm2
00007d0bb21e161e  vmovaps [rsp+0x30], xmm3
00007d0bb21e1624  vmovaps [rsp+0x40], xmm4
00007d0bb21e162a  vmovaps [rsp+0x50], xmm6
00007d0bb21e1630  vmovaps [rsp+0x60], xmm7
00007d0bb21e1636  vmovaps [rsp+0x70], xmm8
00007d0bb21e163c  vmovaps [rsp+0x80], xmm9
00007d0bb21e1645  vmovaps [rsp+0x90], xmm10
00007d0bb21e164e  vmovaps [rsp+0xA0], xmm11
00007d0bb21e1657  vmovaps [rsp+0xB0], xmm12
00007d0bb21e1660  vmovaps [rsp+0xC0], xmm13
00007d0bb21e1669  vmovaps [rsp+0xD0], xmm14
00007d0bb21e1672  vmovaps [rsp+0xE0], xmm15
00007d0bb21e167b  sub rsp, 0x30
00007d0bb21e167f  movaps [rsp], xmm5
00007d0bb21e1683  movaps [rsp+0x10], xmm6
00007d0bb21e1688  movaps [rsp+0x20], xmm3
00007d0bb21e168d  lea rdi, [rsp]
00007d0bb21e1691  mov esi, 0x00
00007d0bb21e1696  mov rax, 0x6392BBE7F530
00007d0bb21e16a0  call rax
00007d0bb21e16a2  movaps xmm5, [rsp]
00007d0bb21e16a6  add rsp, 0x30
00007d0bb21e16aa  vmovaps xmm0, [rsp]
00007d0bb21e16af  vmovaps xmm1, [rsp+0x10]
00007d0bb21e16b5  vmovaps xmm2, [rsp+0x20]
00007d0bb21e16bb  vmovaps xmm3, [rsp+0x30]
00007d0bb21e16c1  vmovaps xmm4, [rsp+0x40]
00007d0bb21e16c7  vmovaps xmm6, [rsp+0x50]
00007d0bb21e16cd  vmovaps xmm7, [rsp+0x60]
00007d0bb21e16d3  vmovaps xmm8, [rsp+0x70]
00007d0bb21e16d9  vmovaps xmm9, [rsp+0x80]
00007d0bb21e16e2  vmovaps xmm10, [rsp+0x90]
00007d0bb21e16eb  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e16f4  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e16fd  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e1706  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e170f  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e1718  add rsp, 0xF0
00007d0bb21e171f  pop r11
00007d0bb21e1721  pop r10
00007d0bb21e1723  pop r9
00007d0bb21e1725  pop r8
00007d0bb21e1727  pop rsi
00007d0bb21e1728  pop rdi
00007d0bb21e1729  pop rdx
00007d0bb21e172a  pop rcx
00007d0bb21e172b  pop rax
00007d0bb21e172c  add rsp, 0x08
00007d0bb21e1730  jmp 0x00007D0BB21DF31A
00007d0bb21e1735  sub rsp, 0x08
00007d0bb21e1739  push rax
00007d0bb21e173a  push rcx
00007d0bb21e173b  push rdx
00007d0bb21e173c  push rdi
00007d0bb21e173d  push rsi
00007d0bb21e173e  push r8
00007d0bb21e1740  push r9
00007d0bb21e1742  push r10
00007d0bb21e1744  push r11
00007d0bb21e1746  sub rsp, 0xF0
00007d0bb21e174d  vmovaps [rsp], xmm0
00007d0bb21e1752  vmovaps [rsp+0x10], xmm1
00007d0bb21e1758  vmovaps [rsp+0x20], xmm2
00007d0bb21e175e  vmovaps [rsp+0x30], xmm3
00007d0bb21e1764  vmovaps [rsp+0x40], xmm4
00007d0bb21e176a  vmovaps [rsp+0x50], xmm5
00007d0bb21e1770  vmovaps [rsp+0x60], xmm7
00007d0bb21e1776  vmovaps [rsp+0x70], xmm8
00007d0bb21e177c  vmovaps [rsp+0x80], xmm9
00007d0bb21e1785  vmovaps [rsp+0x90], xmm10
00007d0bb21e178e  vmovaps [rsp+0xA0], xmm11
00007d0bb21e1797  vmovaps [rsp+0xB0], xmm12
00007d0bb21e17a0  vmovaps [rsp+0xC0], xmm13
00007d0bb21e17a9  vmovaps [rsp+0xD0], xmm14
00007d0bb21e17b2  vmovaps [rsp+0xE0], xmm15
00007d0bb21e17bb  sub rsp, 0x30
00007d0bb21e17bf  movaps [rsp], xmm6
00007d0bb21e17c3  movaps [rsp+0x10], xmm9
00007d0bb21e17c9  movaps [rsp+0x20], xmm1
00007d0bb21e17ce  lea rdi, [rsp]
00007d0bb21e17d2  mov esi, 0x00
00007d0bb21e17d7  mov rax, 0x6392BBE7F530
00007d0bb21e17e1  call rax
00007d0bb21e17e3  movaps xmm6, [rsp]
00007d0bb21e17e7  add rsp, 0x30
00007d0bb21e17eb  vmovaps xmm0, [rsp]
00007d0bb21e17f0  vmovaps xmm1, [rsp+0x10]
00007d0bb21e17f6  vmovaps xmm2, [rsp+0x20]
00007d0bb21e17fc  vmovaps xmm3, [rsp+0x30]
00007d0bb21e1802  vmovaps xmm4, [rsp+0x40]
00007d0bb21e1808  vmovaps xmm5, [rsp+0x50]
00007d0bb21e180e  vmovaps xmm7, [rsp+0x60]
00007d0bb21e1814  vmovaps xmm8, [rsp+0x70]
00007d0bb21e181a  vmovaps xmm9, [rsp+0x80]
00007d0bb21e1823  vmovaps xmm10, [rsp+0x90]
00007d0bb21e182c  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e1835  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e183e  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e1847  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e1850  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e1859  add rsp, 0xF0
00007d0bb21e1860  pop r11
00007d0bb21e1862  pop r10
00007d0bb21e1864  pop r9
00007d0bb21e1866  pop r8
00007d0bb21e1868  pop rsi
00007d0bb21e1869  pop rdi
00007d0bb21e186a  pop rdx
00007d0bb21e186b  pop rcx
00007d0bb21e186c  pop rax
00007d0bb21e186d  add rsp, 0x08
00007d0bb21e1871  jmp 0x00007D0BB21DF33E
00007d0bb21e1876  sub rsp, 0x08
00007d0bb21e187a  push rax
00007d0bb21e187b  push rcx
00007d0bb21e187c  push rdx
00007d0bb21e187d  push rdi
00007d0bb21e187e  push rsi
00007d0bb21e187f  push r8
00007d0bb21e1881  push r9
00007d0bb21e1883  push r10
00007d0bb21e1885  push r11
00007d0bb21e1887  sub rsp, 0xF0
00007d0bb21e188e  vmovaps [rsp], xmm0
00007d0bb21e1893  vmovaps [rsp+0x10], xmm1
00007d0bb21e1899  vmovaps [rsp+0x20], xmm2
00007d0bb21e189f  vmovaps [rsp+0x30], xmm3
00007d0bb21e18a5  vmovaps [rsp+0x40], xmm4
00007d0bb21e18ab  vmovaps [rsp+0x50], xmm5
00007d0bb21e18b1  vmovaps [rsp+0x60], xmm6
00007d0bb21e18b7  vmovaps [rsp+0x70], xmm7
00007d0bb21e18bd  vmovaps [rsp+0x80], xmm8
00007d0bb21e18c6  vmovaps [rsp+0x90], xmm10
00007d0bb21e18cf  vmovaps [rsp+0xA0], xmm11
00007d0bb21e18d8  vmovaps [rsp+0xB0], xmm12
00007d0bb21e18e1  vmovaps [rsp+0xC0], xmm13
00007d0bb21e18ea  vmovaps [rsp+0xD0], xmm14
00007d0bb21e18f3  vmovaps [rsp+0xE0], xmm15
00007d0bb21e18fc  sub rsp, 0x30
00007d0bb21e1900  movaps [rsp], xmm9
00007d0bb21e1905  movaps [rsp+0x10], xmm3
00007d0bb21e190a  movaps [rsp+0x20], xmm1
00007d0bb21e190f  lea rdi, [rsp]
00007d0bb21e1913  mov esi, 0x00
00007d0bb21e1918  mov rax, 0x6392BBE7F530
00007d0bb21e1922  call rax
00007d0bb21e1924  movaps xmm9, [rsp]
00007d0bb21e1929  add rsp, 0x30
00007d0bb21e192d  vmovaps xmm0, [rsp]
00007d0bb21e1932  vmovaps xmm1, [rsp+0x10]
00007d0bb21e1938  vmovaps xmm2, [rsp+0x20]
00007d0bb21e193e  vmovaps xmm3, [rsp+0x30]
00007d0bb21e1944  vmovaps xmm4, [rsp+0x40]
00007d0bb21e194a  vmovaps xmm5, [rsp+0x50]
00007d0bb21e1950  vmovaps xmm6, [rsp+0x60]
00007d0bb21e1956  vmovaps xmm7, [rsp+0x70]
00007d0bb21e195c  vmovaps xmm8, [rsp+0x80]
00007d0bb21e1965  vmovaps xmm10, [rsp+0x90]
00007d0bb21e196e  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e1977  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e1980  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e1989  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e1992  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e199b  add rsp, 0xF0
00007d0bb21e19a2  pop r11
00007d0bb21e19a4  pop r10
00007d0bb21e19a6  pop r9
00007d0bb21e19a8  pop r8
00007d0bb21e19aa  pop rsi
00007d0bb21e19ab  pop rdi
00007d0bb21e19ac  pop rdx
00007d0bb21e19ad  pop rcx
00007d0bb21e19ae  pop rax
00007d0bb21e19af  add rsp, 0x08
00007d0bb21e19b3  jmp 0x00007D0BB21DF38A
00007d0bb21e19b8  call 0x00007D0BB20B52F0
00007d0bb21e19bd  jmp 0x00007D0BB21DF397
00007d0bb21e19c2  sub rsp, 0x08
00007d0bb21e19c6  push rax
00007d0bb21e19c7  push rcx
00007d0bb21e19c8  push rdx
00007d0bb21e19c9  push rdi
00007d0bb21e19ca  push rsi
00007d0bb21e19cb  push r8
00007d0bb21e19cd  push r9
00007d0bb21e19cf  push r10
00007d0bb21e19d1  push r11
00007d0bb21e19d3  sub rsp, 0xF0
00007d0bb21e19da  vmovaps [rsp], xmm0
00007d0bb21e19df  vmovaps [rsp+0x10], xmm1
00007d0bb21e19e5  vmovaps [rsp+0x20], xmm2
00007d0bb21e19eb  vmovaps [rsp+0x30], xmm3
00007d0bb21e19f1  vmovaps [rsp+0x40], xmm4
00007d0bb21e19f7  vmovaps [rsp+0x50], xmm5
00007d0bb21e19fd  vmovaps [rsp+0x60], xmm6
00007d0bb21e1a03  vmovaps [rsp+0x70], xmm7
00007d0bb21e1a09  vmovaps [rsp+0x80], xmm8
00007d0bb21e1a12  vmovaps [rsp+0x90], xmm9
00007d0bb21e1a1b  vmovaps [rsp+0xA0], xmm10
00007d0bb21e1a24  vmovaps [rsp+0xB0], xmm11
00007d0bb21e1a2d  vmovaps [rsp+0xC0], xmm12
00007d0bb21e1a36  vmovaps [rsp+0xD0], xmm13
00007d0bb21e1a3f  vmovaps [rsp+0xE0], xmm14
00007d0bb21e1a48  sub rsp, 0x30
00007d0bb21e1a4c  movaps [rsp], xmm15
00007d0bb21e1a51  movaps [rsp+0x10], xmm3
00007d0bb21e1a56  movaps [rsp+0x20], xmm7
00007d0bb21e1a5b  lea rdi, [rsp]
00007d0bb21e1a5f  mov esi, 0x00
00007d0bb21e1a64  mov rax, 0x6392BBE7F530
00007d0bb21e1a6e  call rax
00007d0bb21e1a70  movaps xmm15, [rsp]
00007d0bb21e1a75  add rsp, 0x30
00007d0bb21e1a79  vmovaps xmm0, [rsp]
00007d0bb21e1a7e  vmovaps xmm1, [rsp+0x10]
00007d0bb21e1a84  vmovaps xmm2, [rsp+0x20]
00007d0bb21e1a8a  vmovaps xmm3, [rsp+0x30]
00007d0bb21e1a90  vmovaps xmm4, [rsp+0x40]
00007d0bb21e1a96  vmovaps xmm5, [rsp+0x50]
00007d0bb21e1a9c  vmovaps xmm6, [rsp+0x60]
00007d0bb21e1aa2  vmovaps xmm7, [rsp+0x70]
00007d0bb21e1aa8  vmovaps xmm8, [rsp+0x80]
00007d0bb21e1ab1  vmovaps xmm9, [rsp+0x90]
00007d0bb21e1aba  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e1ac3  vmovaps xmm11, [rsp+0xB0]
00007d0bb21e1acc  vmovaps xmm12, [rsp+0xC0]
00007d0bb21e1ad5  vmovaps xmm13, [rsp+0xD0]
00007d0bb21e1ade  vmovaps xmm14, [rsp+0xE0]
00007d0bb21e1ae7  add rsp, 0xF0
00007d0bb21e1aee  pop r11
00007d0bb21e1af0  pop r10
00007d0bb21e1af2  pop r9
00007d0bb21e1af4  pop r8
00007d0bb21e1af6  pop rsi
00007d0bb21e1af7  pop rdi
00007d0bb21e1af8  pop rdx
00007d0bb21e1af9  pop rcx
00007d0bb21e1afa  pop rax
00007d0bb21e1afb  add rsp, 0x08
00007d0bb21e1aff  jmp 0x00007D0BB21DF3C3
00007d0bb21e1b04  sub rsp, 0x08
00007d0bb21e1b08  push rax
00007d0bb21e1b09  push rcx
00007d0bb21e1b0a  push rdx
00007d0bb21e1b0b  push rdi
00007d0bb21e1b0c  push rsi
00007d0bb21e1b0d  push r8
00007d0bb21e1b0f  push r9
00007d0bb21e1b11  push r10
00007d0bb21e1b13  push r11
00007d0bb21e1b15  sub rsp, 0xF0
00007d0bb21e1b1c  vmovaps [rsp], xmm0
00007d0bb21e1b21  vmovaps [rsp+0x10], xmm1
00007d0bb21e1b27  vmovaps [rsp+0x20], xmm2
00007d0bb21e1b2d  vmovaps [rsp+0x30], xmm4
00007d0bb21e1b33  vmovaps [rsp+0x40], xmm5
00007d0bb21e1b39  vmovaps [rsp+0x50], xmm6
00007d0bb21e1b3f  vmovaps [rsp+0x60], xmm7
00007d0bb21e1b45  vmovaps [rsp+0x70], xmm8
00007d0bb21e1b4b  vmovaps [rsp+0x80], xmm9
00007d0bb21e1b54  vmovaps [rsp+0x90], xmm10
00007d0bb21e1b5d  vmovaps [rsp+0xA0], xmm11
00007d0bb21e1b66  vmovaps [rsp+0xB0], xmm12
00007d0bb21e1b6f  vmovaps [rsp+0xC0], xmm13
00007d0bb21e1b78  vmovaps [rsp+0xD0], xmm14
00007d0bb21e1b81  vmovaps [rsp+0xE0], xmm15
00007d0bb21e1b8a  sub rsp, 0x30
00007d0bb21e1b8e  movaps [rsp], xmm3
00007d0bb21e1b92  movaps [rsp+0x10], xmm1
00007d0bb21e1b97  movaps [rsp+0x20], xmm15
00007d0bb21e1b9d  lea rdi, [rsp]
00007d0bb21e1ba1  mov esi, 0x00
00007d0bb21e1ba6  mov rax, 0x6392BBE7F530
00007d0bb21e1bb0  call rax
00007d0bb21e1bb2  movaps xmm3, [rsp]
00007d0bb21e1bb6  add rsp, 0x30
00007d0bb21e1bba  vmovaps xmm0, [rsp]
00007d0bb21e1bbf  vmovaps xmm1, [rsp+0x10]
00007d0bb21e1bc5  vmovaps xmm2, [rsp+0x20]
00007d0bb21e1bcb  vmovaps xmm4, [rsp+0x30]
00007d0bb21e1bd1  vmovaps xmm5, [rsp+0x40]
00007d0bb21e1bd7  vmovaps xmm6, [rsp+0x50]
00007d0bb21e1bdd  vmovaps xmm7, [rsp+0x60]
00007d0bb21e1be3  vmovaps xmm8, [rsp+0x70]
00007d0bb21e1be9  vmovaps xmm9, [rsp+0x80]
00007d0bb21e1bf2  vmovaps xmm10, [rsp+0x90]
00007d0bb21e1bfb  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e1c04  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e1c0d  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e1c16  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e1c1f  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e1c28  add rsp, 0xF0
00007d0bb21e1c2f  pop r11
00007d0bb21e1c31  pop r10
00007d0bb21e1c33  pop r9
00007d0bb21e1c35  pop r8
00007d0bb21e1c37  pop rsi
00007d0bb21e1c38  pop rdi
00007d0bb21e1c39  pop rdx
00007d0bb21e1c3a  pop rcx
00007d0bb21e1c3b  pop rax
00007d0bb21e1c3c  add rsp, 0x08
00007d0bb21e1c40  jmp 0x00007D0BB21DF452
00007d0bb21e1c45  call 0x00007D0BB20B52F0
00007d0bb21e1c4a  jmp 0x00007D0BB21DF45C
00007d0bb21e1c4f  sub rsp, 0x08
00007d0bb21e1c53  push rax
00007d0bb21e1c54  push rcx
00007d0bb21e1c55  push rdx
00007d0bb21e1c56  push rdi
00007d0bb21e1c57  push rsi
00007d0bb21e1c58  push r8
00007d0bb21e1c5a  push r9
00007d0bb21e1c5c  push r10
00007d0bb21e1c5e  push r11
00007d0bb21e1c60  sub rsp, 0xF0
00007d0bb21e1c67  vmovaps [rsp], xmm0
00007d0bb21e1c6c  vmovaps [rsp+0x10], xmm1
00007d0bb21e1c72  vmovaps [rsp+0x20], xmm2
00007d0bb21e1c78  vmovaps [rsp+0x30], xmm3
00007d0bb21e1c7e  vmovaps [rsp+0x40], xmm4
00007d0bb21e1c84  vmovaps [rsp+0x50], xmm5
00007d0bb21e1c8a  vmovaps [rsp+0x60], xmm6
00007d0bb21e1c90  vmovaps [rsp+0x70], xmm7
00007d0bb21e1c96  vmovaps [rsp+0x80], xmm8
00007d0bb21e1c9f  vmovaps [rsp+0x90], xmm9
00007d0bb21e1ca8  vmovaps [rsp+0xA0], xmm10
00007d0bb21e1cb1  vmovaps [rsp+0xB0], xmm11
00007d0bb21e1cba  vmovaps [rsp+0xC0], xmm12
00007d0bb21e1cc3  vmovaps [rsp+0xD0], xmm13
00007d0bb21e1ccc  vmovaps [rsp+0xE0], xmm14
00007d0bb21e1cd5  sub rsp, 0x30
00007d0bb21e1cd9  movaps [rsp], xmm15
00007d0bb21e1cde  movaps [rsp+0x10], xmm14
00007d0bb21e1ce4  movaps [rsp+0x20], xmm4
00007d0bb21e1ce9  lea rdi, [rsp]
00007d0bb21e1ced  mov esi, 0x00
00007d0bb21e1cf2  mov rax, 0x6392BBE7F530
00007d0bb21e1cfc  call rax
00007d0bb21e1cfe  movaps xmm15, [rsp]
00007d0bb21e1d03  add rsp, 0x30
00007d0bb21e1d07  vmovaps xmm0, [rsp]
00007d0bb21e1d0c  vmovaps xmm1, [rsp+0x10]
00007d0bb21e1d12  vmovaps xmm2, [rsp+0x20]
00007d0bb21e1d18  vmovaps xmm3, [rsp+0x30]
00007d0bb21e1d1e  vmovaps xmm4, [rsp+0x40]
00007d0bb21e1d24  vmovaps xmm5, [rsp+0x50]
00007d0bb21e1d2a  vmovaps xmm6, [rsp+0x60]
00007d0bb21e1d30  vmovaps xmm7, [rsp+0x70]
00007d0bb21e1d36  vmovaps xmm8, [rsp+0x80]
00007d0bb21e1d3f  vmovaps xmm9, [rsp+0x90]
00007d0bb21e1d48  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e1d51  vmovaps xmm11, [rsp+0xB0]
00007d0bb21e1d5a  vmovaps xmm12, [rsp+0xC0]
00007d0bb21e1d63  vmovaps xmm13, [rsp+0xD0]
00007d0bb21e1d6c  vmovaps xmm14, [rsp+0xE0]
00007d0bb21e1d75  add rsp, 0xF0
00007d0bb21e1d7c  pop r11
00007d0bb21e1d7e  pop r10
00007d0bb21e1d80  pop r9
00007d0bb21e1d82  pop r8
00007d0bb21e1d84  pop rsi
00007d0bb21e1d85  pop rdi
00007d0bb21e1d86  pop rdx
00007d0bb21e1d87  pop rcx
00007d0bb21e1d88  pop rax
00007d0bb21e1d89  add rsp, 0x08
00007d0bb21e1d8d  jmp 0x00007D0BB21DF48A
00007d0bb21e1d92  sub rsp, 0x08
00007d0bb21e1d96  push rax
00007d0bb21e1d97  push rcx
00007d0bb21e1d98  push rdx
00007d0bb21e1d99  push rdi
00007d0bb21e1d9a  push rsi
00007d0bb21e1d9b  push r8
00007d0bb21e1d9d  push r9
00007d0bb21e1d9f  push r10
00007d0bb21e1da1  push r11
00007d0bb21e1da3  sub rsp, 0xF0
00007d0bb21e1daa  vmovaps [rsp], xmm0
00007d0bb21e1daf  vmovaps [rsp+0x10], xmm1
00007d0bb21e1db5  vmovaps [rsp+0x20], xmm2
00007d0bb21e1dbb  vmovaps [rsp+0x30], xmm3
00007d0bb21e1dc1  vmovaps [rsp+0x40], xmm4
00007d0bb21e1dc7  vmovaps [rsp+0x50], xmm5
00007d0bb21e1dcd  vmovaps [rsp+0x60], xmm6
00007d0bb21e1dd3  vmovaps [rsp+0x70], xmm7
00007d0bb21e1dd9  vmovaps [rsp+0x80], xmm8
00007d0bb21e1de2  vmovaps [rsp+0x90], xmm9
00007d0bb21e1deb  vmovaps [rsp+0xA0], xmm10
00007d0bb21e1df4  vmovaps [rsp+0xB0], xmm11
00007d0bb21e1dfd  vmovaps [rsp+0xC0], xmm12
00007d0bb21e1e06  vmovaps [rsp+0xD0], xmm13
00007d0bb21e1e0f  vmovaps [rsp+0xE0], xmm15
00007d0bb21e1e18  sub rsp, 0x30
00007d0bb21e1e1c  movaps [rsp], xmm14
00007d0bb21e1e21  movaps [rsp+0x10], xmm2
00007d0bb21e1e26  movaps [rsp+0x20], xmm1
00007d0bb21e1e2b  lea rdi, [rsp]
00007d0bb21e1e2f  mov esi, 0x00
00007d0bb21e1e34  mov rax, 0x6392BBE7F530
00007d0bb21e1e3e  call rax
00007d0bb21e1e40  movaps xmm14, [rsp]
00007d0bb21e1e45  add rsp, 0x30
00007d0bb21e1e49  vmovaps xmm0, [rsp]
00007d0bb21e1e4e  vmovaps xmm1, [rsp+0x10]
00007d0bb21e1e54  vmovaps xmm2, [rsp+0x20]
00007d0bb21e1e5a  vmovaps xmm3, [rsp+0x30]
00007d0bb21e1e60  vmovaps xmm4, [rsp+0x40]
00007d0bb21e1e66  vmovaps xmm5, [rsp+0x50]
00007d0bb21e1e6c  vmovaps xmm6, [rsp+0x60]
00007d0bb21e1e72  vmovaps xmm7, [rsp+0x70]
00007d0bb21e1e78  vmovaps xmm8, [rsp+0x80]
00007d0bb21e1e81  vmovaps xmm9, [rsp+0x90]
00007d0bb21e1e8a  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e1e93  vmovaps xmm11, [rsp+0xB0]
00007d0bb21e1e9c  vmovaps xmm12, [rsp+0xC0]
00007d0bb21e1ea5  vmovaps xmm13, [rsp+0xD0]
00007d0bb21e1eae  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e1eb7  add rsp, 0xF0
00007d0bb21e1ebe  pop r11
00007d0bb21e1ec0  pop r10
00007d0bb21e1ec2  pop r9
00007d0bb21e1ec4  pop r8
00007d0bb21e1ec6  pop rsi
00007d0bb21e1ec7  pop rdi
00007d0bb21e1ec8  pop rdx
00007d0bb21e1ec9  pop rcx
00007d0bb21e1eca  pop rax
00007d0bb21e1ecb  add rsp, 0x08
00007d0bb21e1ecf  jmp 0x00007D0BB21DF4B0
00007d0bb21e1ed4  sub rsp, 0x08
00007d0bb21e1ed8  push rax
00007d0bb21e1ed9  push rcx
00007d0bb21e1eda  push rdx
00007d0bb21e1edb  push rdi
00007d0bb21e1edc  push rsi
00007d0bb21e1edd  push r8
00007d0bb21e1edf  push r9
00007d0bb21e1ee1  push r10
00007d0bb21e1ee3  push r11
00007d0bb21e1ee5  sub rsp, 0xF0
00007d0bb21e1eec  vmovaps [rsp], xmm0
00007d0bb21e1ef1  vmovaps [rsp+0x10], xmm2
00007d0bb21e1ef7  vmovaps [rsp+0x20], xmm3
00007d0bb21e1efd  vmovaps [rsp+0x30], xmm4
00007d0bb21e1f03  vmovaps [rsp+0x40], xmm5
00007d0bb21e1f09  vmovaps [rsp+0x50], xmm6
00007d0bb21e1f0f  vmovaps [rsp+0x60], xmm7
00007d0bb21e1f15  vmovaps [rsp+0x70], xmm8
00007d0bb21e1f1b  vmovaps [rsp+0x80], xmm9
00007d0bb21e1f24  vmovaps [rsp+0x90], xmm10
00007d0bb21e1f2d  vmovaps [rsp+0xA0], xmm11
00007d0bb21e1f36  vmovaps [rsp+0xB0], xmm12
00007d0bb21e1f3f  vmovaps [rsp+0xC0], xmm13
00007d0bb21e1f48  vmovaps [rsp+0xD0], xmm14
00007d0bb21e1f51  vmovaps [rsp+0xE0], xmm15
00007d0bb21e1f5a  sub rsp, 0x30
00007d0bb21e1f5e  movaps [rsp], xmm1
00007d0bb21e1f62  movaps [rsp+0x10], xmm4
00007d0bb21e1f67  movaps [rsp+0x20], xmm9
00007d0bb21e1f6d  lea rdi, [rsp]
00007d0bb21e1f71  mov esi, 0x00
00007d0bb21e1f76  mov rax, 0x6392BBE7F530
00007d0bb21e1f80  call rax
00007d0bb21e1f82  movaps xmm1, [rsp]
00007d0bb21e1f86  add rsp, 0x30
00007d0bb21e1f8a  vmovaps xmm0, [rsp]
00007d0bb21e1f8f  vmovaps xmm2, [rsp+0x10]
00007d0bb21e1f95  vmovaps xmm3, [rsp+0x20]
00007d0bb21e1f9b  vmovaps xmm4, [rsp+0x30]
00007d0bb21e1fa1  vmovaps xmm5, [rsp+0x40]
00007d0bb21e1fa7  vmovaps xmm6, [rsp+0x50]
00007d0bb21e1fad  vmovaps xmm7, [rsp+0x60]
00007d0bb21e1fb3  vmovaps xmm8, [rsp+0x70]
00007d0bb21e1fb9  vmovaps xmm9, [rsp+0x80]
00007d0bb21e1fc2  vmovaps xmm10, [rsp+0x90]
00007d0bb21e1fcb  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e1fd4  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e1fdd  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e1fe6  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e1fef  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e1ff8  add rsp, 0xF0
00007d0bb21e1fff  pop r11
00007d0bb21e2001  pop r10
00007d0bb21e2003  pop r9
00007d0bb21e2005  pop r8
00007d0bb21e2007  pop rsi
00007d0bb21e2008  pop rdi
00007d0bb21e2009  pop rdx
00007d0bb21e200a  pop rcx
00007d0bb21e200b  pop rax
00007d0bb21e200c  add rsp, 0x08
00007d0bb21e2010  jmp 0x00007D0BB21DF4CE
00007d0bb21e2015  sub rsp, 0x08
00007d0bb21e2019  push rax
00007d0bb21e201a  push rcx
00007d0bb21e201b  push rdx
00007d0bb21e201c  push rdi
00007d0bb21e201d  push rsi
00007d0bb21e201e  push r8
00007d0bb21e2020  push r9
00007d0bb21e2022  push r10
00007d0bb21e2024  push r11
00007d0bb21e2026  sub rsp, 0xF0
00007d0bb21e202d  vmovaps [rsp], xmm0
00007d0bb21e2032  vmovaps [rsp+0x10], xmm1
00007d0bb21e2038  vmovaps [rsp+0x20], xmm2
00007d0bb21e203e  vmovaps [rsp+0x30], xmm3
00007d0bb21e2044  vmovaps [rsp+0x40], xmm5
00007d0bb21e204a  vmovaps [rsp+0x50], xmm6
00007d0bb21e2050  vmovaps [rsp+0x60], xmm7
00007d0bb21e2056  vmovaps [rsp+0x70], xmm8
00007d0bb21e205c  vmovaps [rsp+0x80], xmm9
00007d0bb21e2065  vmovaps [rsp+0x90], xmm10
00007d0bb21e206e  vmovaps [rsp+0xA0], xmm11
00007d0bb21e2077  vmovaps [rsp+0xB0], xmm12
00007d0bb21e2080  vmovaps [rsp+0xC0], xmm13
00007d0bb21e2089  vmovaps [rsp+0xD0], xmm14
00007d0bb21e2092  vmovaps [rsp+0xE0], xmm15
00007d0bb21e209b  sub rsp, 0x30
00007d0bb21e209f  movaps [rsp], xmm4
00007d0bb21e20a3  movaps [rsp+0x10], xmm2
00007d0bb21e20a8  movaps [rsp+0x20], xmm9
00007d0bb21e20ae  lea rdi, [rsp]
00007d0bb21e20b2  mov esi, 0x00
00007d0bb21e20b7  mov rax, 0x6392BBE7F530
00007d0bb21e20c1  call rax
00007d0bb21e20c3  movaps xmm4, [rsp]
00007d0bb21e20c7  add rsp, 0x30
00007d0bb21e20cb  vmovaps xmm0, [rsp]
00007d0bb21e20d0  vmovaps xmm1, [rsp+0x10]
00007d0bb21e20d6  vmovaps xmm2, [rsp+0x20]
00007d0bb21e20dc  vmovaps xmm3, [rsp+0x30]
00007d0bb21e20e2  vmovaps xmm5, [rsp+0x40]
00007d0bb21e20e8  vmovaps xmm6, [rsp+0x50]
00007d0bb21e20ee  vmovaps xmm7, [rsp+0x60]
00007d0bb21e20f4  vmovaps xmm8, [rsp+0x70]
00007d0bb21e20fa  vmovaps xmm9, [rsp+0x80]
00007d0bb21e2103  vmovaps xmm10, [rsp+0x90]
00007d0bb21e210c  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e2115  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e211e  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e2127  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e2130  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e2139  add rsp, 0xF0
00007d0bb21e2140  pop r11
00007d0bb21e2142  pop r10
00007d0bb21e2144  pop r9
00007d0bb21e2146  pop r8
00007d0bb21e2148  pop rsi
00007d0bb21e2149  pop rdi
00007d0bb21e214a  pop rdx
00007d0bb21e214b  pop rcx
00007d0bb21e214c  pop rax
00007d0bb21e214d  add rsp, 0x08
00007d0bb21e2151  jmp 0x00007D0BB21DF4FE
00007d0bb21e2156  sub rsp, 0x08
00007d0bb21e215a  push rax
00007d0bb21e215b  push rcx
00007d0bb21e215c  push rdx
00007d0bb21e215d  push rdi
00007d0bb21e215e  push rsi
00007d0bb21e215f  push r8
00007d0bb21e2161  push r9
00007d0bb21e2163  push r10
00007d0bb21e2165  push r11
00007d0bb21e2167  sub rsp, 0xF0
00007d0bb21e216e  vmovaps [rsp], xmm0
00007d0bb21e2173  vmovaps [rsp+0x10], xmm1
00007d0bb21e2179  vmovaps [rsp+0x20], xmm2
00007d0bb21e217f  vmovaps [rsp+0x30], xmm3
00007d0bb21e2185  vmovaps [rsp+0x40], xmm4
00007d0bb21e218b  vmovaps [rsp+0x50], xmm5
00007d0bb21e2191  vmovaps [rsp+0x60], xmm6
00007d0bb21e2197  vmovaps [rsp+0x70], xmm7
00007d0bb21e219d  vmovaps [rsp+0x80], xmm8
00007d0bb21e21a6  vmovaps [rsp+0x90], xmm10
00007d0bb21e21af  vmovaps [rsp+0xA0], xmm11
00007d0bb21e21b8  vmovaps [rsp+0xB0], xmm12
00007d0bb21e21c1  vmovaps [rsp+0xC0], xmm13
00007d0bb21e21ca  vmovaps [rsp+0xD0], xmm14
00007d0bb21e21d3  vmovaps [rsp+0xE0], xmm15
00007d0bb21e21dc  sub rsp, 0x30
00007d0bb21e21e0  movaps [rsp], xmm9
00007d0bb21e21e5  movaps [rsp+0x10], xmm2
00007d0bb21e21ea  movaps [rsp+0x20], xmm1
00007d0bb21e21ef  lea rdi, [rsp]
00007d0bb21e21f3  mov esi, 0x00
00007d0bb21e21f8  mov rax, 0x6392BBE7F530
00007d0bb21e2202  call rax
00007d0bb21e2204  movaps xmm9, [rsp]
00007d0bb21e2209  add rsp, 0x30
00007d0bb21e220d  vmovaps xmm0, [rsp]
00007d0bb21e2212  vmovaps xmm1, [rsp+0x10]
00007d0bb21e2218  vmovaps xmm2, [rsp+0x20]
00007d0bb21e221e  vmovaps xmm3, [rsp+0x30]
00007d0bb21e2224  vmovaps xmm4, [rsp+0x40]
00007d0bb21e222a  vmovaps xmm5, [rsp+0x50]
00007d0bb21e2230  vmovaps xmm6, [rsp+0x60]
00007d0bb21e2236  vmovaps xmm7, [rsp+0x70]
00007d0bb21e223c  vmovaps xmm8, [rsp+0x80]
00007d0bb21e2245  vmovaps xmm10, [rsp+0x90]
00007d0bb21e224e  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e2257  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e2260  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e2269  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e2272  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e227b  add rsp, 0xF0
00007d0bb21e2282  pop r11
00007d0bb21e2284  pop r10
00007d0bb21e2286  pop r9
00007d0bb21e2288  pop r8
00007d0bb21e228a  pop rsi
00007d0bb21e228b  pop rdi
00007d0bb21e228c  pop rdx
00007d0bb21e228d  pop rcx
00007d0bb21e228e  pop rax
00007d0bb21e228f  add rsp, 0x08
00007d0bb21e2293  jmp 0x00007D0BB21DF534
00007d0bb21e2298  sub rsp, 0x08
00007d0bb21e229c  push rax
00007d0bb21e229d  push rcx
00007d0bb21e229e  push rdx
00007d0bb21e229f  push rdi
00007d0bb21e22a0  push rsi
00007d0bb21e22a1  push r8
00007d0bb21e22a3  push r9
00007d0bb21e22a5  push r10
00007d0bb21e22a7  push r11
00007d0bb21e22a9  sub rsp, 0xF0
00007d0bb21e22b0  vmovaps [rsp], xmm0
00007d0bb21e22b5  vmovaps [rsp+0x10], xmm2
00007d0bb21e22bb  vmovaps [rsp+0x20], xmm3
00007d0bb21e22c1  vmovaps [rsp+0x30], xmm4
00007d0bb21e22c7  vmovaps [rsp+0x40], xmm5
00007d0bb21e22cd  vmovaps [rsp+0x50], xmm6
00007d0bb21e22d3  vmovaps [rsp+0x60], xmm7
00007d0bb21e22d9  vmovaps [rsp+0x70], xmm8
00007d0bb21e22df  vmovaps [rsp+0x80], xmm9
00007d0bb21e22e8  vmovaps [rsp+0x90], xmm10
00007d0bb21e22f1  vmovaps [rsp+0xA0], xmm11
00007d0bb21e22fa  vmovaps [rsp+0xB0], xmm12
00007d0bb21e2303  vmovaps [rsp+0xC0], xmm13
00007d0bb21e230c  vmovaps [rsp+0xD0], xmm14
00007d0bb21e2315  vmovaps [rsp+0xE0], xmm15
00007d0bb21e231e  sub rsp, 0x30
00007d0bb21e2322  movaps [rsp], xmm1
00007d0bb21e2326  movaps [rsp+0x10], xmm15
00007d0bb21e232c  movaps [rsp+0x20], xmm6
00007d0bb21e2331  lea rdi, [rsp]
00007d0bb21e2335  mov esi, 0x00
00007d0bb21e233a  mov rax, 0x6392BBE7F530
00007d0bb21e2344  call rax
00007d0bb21e2346  movaps xmm1, [rsp]
00007d0bb21e234a  add rsp, 0x30
00007d0bb21e234e  vmovaps xmm0, [rsp]
00007d0bb21e2353  vmovaps xmm2, [rsp+0x10]
00007d0bb21e2359  vmovaps xmm3, [rsp+0x20]
00007d0bb21e235f  vmovaps xmm4, [rsp+0x30]
00007d0bb21e2365  vmovaps xmm5, [rsp+0x40]
00007d0bb21e236b  vmovaps xmm6, [rsp+0x50]
00007d0bb21e2371  vmovaps xmm7, [rsp+0x60]
00007d0bb21e2377  vmovaps xmm8, [rsp+0x70]
00007d0bb21e237d  vmovaps xmm9, [rsp+0x80]
00007d0bb21e2386  vmovaps xmm10, [rsp+0x90]
00007d0bb21e238f  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e2398  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e23a1  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e23aa  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e23b3  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e23bc  add rsp, 0xF0
00007d0bb21e23c3  pop r11
00007d0bb21e23c5  pop r10
00007d0bb21e23c7  pop r9
00007d0bb21e23c9  pop r8
00007d0bb21e23cb  pop rsi
00007d0bb21e23cc  pop rdi
00007d0bb21e23cd  pop rdx
00007d0bb21e23ce  pop rcx
00007d0bb21e23cf  pop rax
00007d0bb21e23d0  add rsp, 0x08
00007d0bb21e23d4  jmp 0x00007D0BB21DF555
00007d0bb21e23d9  sub rsp, 0x08
00007d0bb21e23dd  push rax
00007d0bb21e23de  push rcx
00007d0bb21e23df  push rdx
00007d0bb21e23e0  push rdi
00007d0bb21e23e1  push rsi
00007d0bb21e23e2  push r8
00007d0bb21e23e4  push r9
00007d0bb21e23e6  push r10
00007d0bb21e23e8  push r11
00007d0bb21e23ea  sub rsp, 0xF0
00007d0bb21e23f1  vmovaps [rsp], xmm0
00007d0bb21e23f6  vmovaps [rsp+0x10], xmm1
00007d0bb21e23fc  vmovaps [rsp+0x20], xmm2
00007d0bb21e2402  vmovaps [rsp+0x30], xmm3
00007d0bb21e2408  vmovaps [rsp+0x40], xmm4
00007d0bb21e240e  vmovaps [rsp+0x50], xmm5
00007d0bb21e2414  vmovaps [rsp+0x60], xmm6
00007d0bb21e241a  vmovaps [rsp+0x70], xmm7
00007d0bb21e2420  vmovaps [rsp+0x80], xmm8
00007d0bb21e2429  vmovaps [rsp+0x90], xmm9
00007d0bb21e2432  vmovaps [rsp+0xA0], xmm10
00007d0bb21e243b  vmovaps [rsp+0xB0], xmm11
00007d0bb21e2444  vmovaps [rsp+0xC0], xmm12
00007d0bb21e244d  vmovaps [rsp+0xD0], xmm13
00007d0bb21e2456  vmovaps [rsp+0xE0], xmm14
00007d0bb21e245f  sub rsp, 0x30
00007d0bb21e2463  movaps [rsp], xmm15
00007d0bb21e2468  movaps [rsp+0x10], xmm5
00007d0bb21e246d  movaps [rsp+0x20], xmm3
00007d0bb21e2472  lea rdi, [rsp]
00007d0bb21e2476  mov esi, 0x00
00007d0bb21e247b  mov rax, 0x6392BBE7F530
00007d0bb21e2485  call rax
00007d0bb21e2487  movaps xmm15, [rsp]
00007d0bb21e248c  add rsp, 0x30
00007d0bb21e2490  vmovaps xmm0, [rsp]
00007d0bb21e2495  vmovaps xmm1, [rsp+0x10]
00007d0bb21e249b  vmovaps xmm2, [rsp+0x20]
00007d0bb21e24a1  vmovaps xmm3, [rsp+0x30]
00007d0bb21e24a7  vmovaps xmm4, [rsp+0x40]
00007d0bb21e24ad  vmovaps xmm5, [rsp+0x50]
00007d0bb21e24b3  vmovaps xmm6, [rsp+0x60]
00007d0bb21e24b9  vmovaps xmm7, [rsp+0x70]
00007d0bb21e24bf  vmovaps xmm8, [rsp+0x80]
00007d0bb21e24c8  vmovaps xmm9, [rsp+0x90]
00007d0bb21e24d1  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e24da  vmovaps xmm11, [rsp+0xB0]
00007d0bb21e24e3  vmovaps xmm12, [rsp+0xC0]
00007d0bb21e24ec  vmovaps xmm13, [rsp+0xD0]
00007d0bb21e24f5  vmovaps xmm14, [rsp+0xE0]
00007d0bb21e24fe  add rsp, 0xF0
00007d0bb21e2505  pop r11
00007d0bb21e2507  pop r10
00007d0bb21e2509  pop r9
00007d0bb21e250b  pop r8
00007d0bb21e250d  pop rsi
00007d0bb21e250e  pop rdi
00007d0bb21e250f  pop rdx
00007d0bb21e2510  pop rcx
00007d0bb21e2511  pop rax
00007d0bb21e2512  add rsp, 0x08
00007d0bb21e2516  jmp 0x00007D0BB21DF56F
00007d0bb21e251b  sub rsp, 0x08
00007d0bb21e251f  push rax
00007d0bb21e2520  push rcx
00007d0bb21e2521  push rdx
00007d0bb21e2522  push rdi
00007d0bb21e2523  push rsi
00007d0bb21e2524  push r8
00007d0bb21e2526  push r9
00007d0bb21e2528  push r10
00007d0bb21e252a  push r11
00007d0bb21e252c  sub rsp, 0xF0
00007d0bb21e2533  vmovaps [rsp], xmm0
00007d0bb21e2538  vmovaps [rsp+0x10], xmm1
00007d0bb21e253e  vmovaps [rsp+0x20], xmm2
00007d0bb21e2544  vmovaps [rsp+0x30], xmm3
00007d0bb21e254a  vmovaps [rsp+0x40], xmm4
00007d0bb21e2550  vmovaps [rsp+0x50], xmm6
00007d0bb21e2556  vmovaps [rsp+0x60], xmm7
00007d0bb21e255c  vmovaps [rsp+0x70], xmm8
00007d0bb21e2562  vmovaps [rsp+0x80], xmm9
00007d0bb21e256b  vmovaps [rsp+0x90], xmm10
00007d0bb21e2574  vmovaps [rsp+0xA0], xmm11
00007d0bb21e257d  vmovaps [rsp+0xB0], xmm12
00007d0bb21e2586  vmovaps [rsp+0xC0], xmm13
00007d0bb21e258f  vmovaps [rsp+0xD0], xmm14
00007d0bb21e2598  vmovaps [rsp+0xE0], xmm15
00007d0bb21e25a1  sub rsp, 0x30
00007d0bb21e25a5  movaps [rsp], xmm5
00007d0bb21e25a9  movaps [rsp+0x10], xmm8
00007d0bb21e25af  movaps [rsp+0x20], xmm6
00007d0bb21e25b4  lea rdi, [rsp]
00007d0bb21e25b8  mov esi, 0x00
00007d0bb21e25bd  mov rax, 0x6392BBE7F530
00007d0bb21e25c7  call rax
00007d0bb21e25c9  movaps xmm5, [rsp]
00007d0bb21e25cd  add rsp, 0x30
00007d0bb21e25d1  vmovaps xmm0, [rsp]
00007d0bb21e25d6  vmovaps xmm1, [rsp+0x10]
00007d0bb21e25dc  vmovaps xmm2, [rsp+0x20]
00007d0bb21e25e2  vmovaps xmm3, [rsp+0x30]
00007d0bb21e25e8  vmovaps xmm4, [rsp+0x40]
00007d0bb21e25ee  vmovaps xmm6, [rsp+0x50]
00007d0bb21e25f4  vmovaps xmm7, [rsp+0x60]
00007d0bb21e25fa  vmovaps xmm8, [rsp+0x70]
00007d0bb21e2600  vmovaps xmm9, [rsp+0x80]
00007d0bb21e2609  vmovaps xmm10, [rsp+0x90]
00007d0bb21e2612  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e261b  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e2624  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e262d  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e2636  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e263f  add rsp, 0xF0
00007d0bb21e2646  pop r11
00007d0bb21e2648  pop r10
00007d0bb21e264a  pop r9
00007d0bb21e264c  pop r8
00007d0bb21e264e  pop rsi
00007d0bb21e264f  pop rdi
00007d0bb21e2650  pop rdx
00007d0bb21e2651  pop rcx
00007d0bb21e2652  pop rax
00007d0bb21e2653  add rsp, 0x08
00007d0bb21e2657  jmp 0x00007D0BB21DF593
00007d0bb21e265c  sub rsp, 0x08
00007d0bb21e2660  push rax
00007d0bb21e2661  push rcx
00007d0bb21e2662  push rdx
00007d0bb21e2663  push rdi
00007d0bb21e2664  push rsi
00007d0bb21e2665  push r8
00007d0bb21e2667  push r9
00007d0bb21e2669  push r10
00007d0bb21e266b  push r11
00007d0bb21e266d  sub rsp, 0xF0
00007d0bb21e2674  vmovaps [rsp], xmm0
00007d0bb21e2679  vmovaps [rsp+0x10], xmm1
00007d0bb21e267f  vmovaps [rsp+0x20], xmm2
00007d0bb21e2685  vmovaps [rsp+0x30], xmm3
00007d0bb21e268b  vmovaps [rsp+0x40], xmm4
00007d0bb21e2691  vmovaps [rsp+0x50], xmm5
00007d0bb21e2697  vmovaps [rsp+0x60], xmm7
00007d0bb21e269d  vmovaps [rsp+0x70], xmm8
00007d0bb21e26a3  vmovaps [rsp+0x80], xmm9
00007d0bb21e26ac  vmovaps [rsp+0x90], xmm10
00007d0bb21e26b5  vmovaps [rsp+0xA0], xmm11
00007d0bb21e26be  vmovaps [rsp+0xB0], xmm12
00007d0bb21e26c7  vmovaps [rsp+0xC0], xmm13
00007d0bb21e26d0  vmovaps [rsp+0xD0], xmm14
00007d0bb21e26d9  vmovaps [rsp+0xE0], xmm15
00007d0bb21e26e2  sub rsp, 0x30
00007d0bb21e26e6  movaps [rsp], xmm6
00007d0bb21e26ea  movaps [rsp+0x10], xmm10
00007d0bb21e26f0  movaps [rsp+0x20], xmm8
00007d0bb21e26f6  lea rdi, [rsp]
00007d0bb21e26fa  mov esi, 0x00
00007d0bb21e26ff  mov rax, 0x6392BBE7F530
00007d0bb21e2709  call rax
00007d0bb21e270b  movaps xmm6, [rsp]
00007d0bb21e270f  add rsp, 0x30
00007d0bb21e2713  vmovaps xmm0, [rsp]
00007d0bb21e2718  vmovaps xmm1, [rsp+0x10]
00007d0bb21e271e  vmovaps xmm2, [rsp+0x20]
00007d0bb21e2724  vmovaps xmm3, [rsp+0x30]
00007d0bb21e272a  vmovaps xmm4, [rsp+0x40]
00007d0bb21e2730  vmovaps xmm5, [rsp+0x50]
00007d0bb21e2736  vmovaps xmm7, [rsp+0x60]
00007d0bb21e273c  vmovaps xmm8, [rsp+0x70]
00007d0bb21e2742  vmovaps xmm9, [rsp+0x80]
00007d0bb21e274b  vmovaps xmm10, [rsp+0x90]
00007d0bb21e2754  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e275d  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e2766  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e276f  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e2778  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e2781  add rsp, 0xF0
00007d0bb21e2788  pop r11
00007d0bb21e278a  pop r10
00007d0bb21e278c  pop r9
00007d0bb21e278e  pop r8
00007d0bb21e2790  pop rsi
00007d0bb21e2791  pop rdi
00007d0bb21e2792  pop rdx
00007d0bb21e2793  pop rcx
00007d0bb21e2794  pop rax
00007d0bb21e2795  add rsp, 0x08
00007d0bb21e2799  jmp 0x00007D0BB21DF5B8
00007d0bb21e279e  sub rsp, 0x08
00007d0bb21e27a2  push rax
00007d0bb21e27a3  push rcx
00007d0bb21e27a4  push rdx
00007d0bb21e27a5  push rdi
00007d0bb21e27a6  push rsi
00007d0bb21e27a7  push r8
00007d0bb21e27a9  push r9
00007d0bb21e27ab  push r10
00007d0bb21e27ad  push r11
00007d0bb21e27af  sub rsp, 0xF0
00007d0bb21e27b6  vmovaps [rsp], xmm0
00007d0bb21e27bb  vmovaps [rsp+0x10], xmm1
00007d0bb21e27c1  vmovaps [rsp+0x20], xmm2
00007d0bb21e27c7  vmovaps [rsp+0x30], xmm3
00007d0bb21e27cd  vmovaps [rsp+0x40], xmm4
00007d0bb21e27d3  vmovaps [rsp+0x50], xmm5
00007d0bb21e27d9  vmovaps [rsp+0x60], xmm6
00007d0bb21e27df  vmovaps [rsp+0x70], xmm7
00007d0bb21e27e5  vmovaps [rsp+0x80], xmm8
00007d0bb21e27ee  vmovaps [rsp+0x90], xmm9
00007d0bb21e27f7  vmovaps [rsp+0xA0], xmm11
00007d0bb21e2800  vmovaps [rsp+0xB0], xmm12
00007d0bb21e2809  vmovaps [rsp+0xC0], xmm13
00007d0bb21e2812  vmovaps [rsp+0xD0], xmm14
00007d0bb21e281b  vmovaps [rsp+0xE0], xmm15
00007d0bb21e2824  sub rsp, 0x30
00007d0bb21e2828  movaps [rsp], xmm10
00007d0bb21e282d  movaps [rsp+0x10], xmm8
00007d0bb21e2833  movaps [rsp+0x20], xmm14
00007d0bb21e2839  lea rdi, [rsp]
00007d0bb21e283d  mov esi, 0x00
00007d0bb21e2842  mov rax, 0x6392BBE7F530
00007d0bb21e284c  call rax
00007d0bb21e284e  movaps xmm10, [rsp]
00007d0bb21e2853  add rsp, 0x30
00007d0bb21e2857  vmovaps xmm0, [rsp]
00007d0bb21e285c  vmovaps xmm1, [rsp+0x10]
00007d0bb21e2862  vmovaps xmm2, [rsp+0x20]
00007d0bb21e2868  vmovaps xmm3, [rsp+0x30]
00007d0bb21e286e  vmovaps xmm4, [rsp+0x40]
00007d0bb21e2874  vmovaps xmm5, [rsp+0x50]
00007d0bb21e287a  vmovaps xmm6, [rsp+0x60]
00007d0bb21e2880  vmovaps xmm7, [rsp+0x70]
00007d0bb21e2886  vmovaps xmm8, [rsp+0x80]
00007d0bb21e288f  vmovaps xmm9, [rsp+0x90]
00007d0bb21e2898  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e28a1  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e28aa  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e28b3  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e28bc  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e28c5  add rsp, 0xF0
00007d0bb21e28cc  pop r11
00007d0bb21e28ce  pop r10
00007d0bb21e28d0  pop r9
00007d0bb21e28d2  pop r8
00007d0bb21e28d4  pop rsi
00007d0bb21e28d5  pop rdi
00007d0bb21e28d6  pop rdx
00007d0bb21e28d7  pop rcx
00007d0bb21e28d8  pop rax
00007d0bb21e28d9  add rsp, 0x08
00007d0bb21e28dd  jmp 0x00007D0BB21DF5D8
00007d0bb21e28e2  sub rsp, 0x08
00007d0bb21e28e6  push rax
00007d0bb21e28e7  push rcx
00007d0bb21e28e8  push rdx
00007d0bb21e28e9  push rdi
00007d0bb21e28ea  push rsi
00007d0bb21e28eb  push r8
00007d0bb21e28ed  push r9
00007d0bb21e28ef  push r10
00007d0bb21e28f1  push r11
00007d0bb21e28f3  sub rsp, 0xF0
00007d0bb21e28fa  vmovaps [rsp], xmm0
00007d0bb21e28ff  vmovaps [rsp+0x10], xmm1
00007d0bb21e2905  vmovaps [rsp+0x20], xmm2
00007d0bb21e290b  vmovaps [rsp+0x30], xmm3
00007d0bb21e2911  vmovaps [rsp+0x40], xmm4
00007d0bb21e2917  vmovaps [rsp+0x50], xmm5
00007d0bb21e291d  vmovaps [rsp+0x60], xmm6
00007d0bb21e2923  vmovaps [rsp+0x70], xmm7
00007d0bb21e2929  vmovaps [rsp+0x80], xmm8
00007d0bb21e2932  vmovaps [rsp+0x90], xmm9
00007d0bb21e293b  vmovaps [rsp+0xA0], xmm10
00007d0bb21e2944  vmovaps [rsp+0xB0], xmm11
00007d0bb21e294d  vmovaps [rsp+0xC0], xmm12
00007d0bb21e2956  vmovaps [rsp+0xD0], xmm13
00007d0bb21e295f  vmovaps [rsp+0xE0], xmm15
00007d0bb21e2968  sub rsp, 0x30
00007d0bb21e296c  movaps [rsp], xmm14
00007d0bb21e2971  movaps [rsp+0x10], xmm8
00007d0bb21e2977  movaps [rsp+0x20], xmm4
00007d0bb21e297c  lea rdi, [rsp]
00007d0bb21e2980  mov esi, 0x00
00007d0bb21e2985  mov rax, 0x6392BBE7F530
00007d0bb21e298f  call rax
00007d0bb21e2991  movaps xmm14, [rsp]
00007d0bb21e2996  add rsp, 0x30
00007d0bb21e299a  vmovaps xmm0, [rsp]
00007d0bb21e299f  vmovaps xmm1, [rsp+0x10]
00007d0bb21e29a5  vmovaps xmm2, [rsp+0x20]
00007d0bb21e29ab  vmovaps xmm3, [rsp+0x30]
00007d0bb21e29b1  vmovaps xmm4, [rsp+0x40]
00007d0bb21e29b7  vmovaps xmm5, [rsp+0x50]
00007d0bb21e29bd  vmovaps xmm6, [rsp+0x60]
00007d0bb21e29c3  vmovaps xmm7, [rsp+0x70]
00007d0bb21e29c9  vmovaps xmm8, [rsp+0x80]
00007d0bb21e29d2  vmovaps xmm9, [rsp+0x90]
00007d0bb21e29db  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e29e4  vmovaps xmm11, [rsp+0xB0]
00007d0bb21e29ed  vmovaps xmm12, [rsp+0xC0]
00007d0bb21e29f6  vmovaps xmm13, [rsp+0xD0]
00007d0bb21e29ff  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e2a08  add rsp, 0xF0
00007d0bb21e2a0f  pop r11
00007d0bb21e2a11  pop r10
00007d0bb21e2a13  pop r9
00007d0bb21e2a15  pop r8
00007d0bb21e2a17  pop rsi
00007d0bb21e2a18  pop rdi
00007d0bb21e2a19  pop rdx
00007d0bb21e2a1a  pop rcx
00007d0bb21e2a1b  pop rax
00007d0bb21e2a1c  add rsp, 0x08
00007d0bb21e2a20  jmp 0x00007D0BB21DF5F8
00007d0bb21e2a25  sub rsp, 0x08
00007d0bb21e2a29  push rax
00007d0bb21e2a2a  push rcx
00007d0bb21e2a2b  push rdx
00007d0bb21e2a2c  push rdi
00007d0bb21e2a2d  push rsi
00007d0bb21e2a2e  push r8
00007d0bb21e2a30  push r9
00007d0bb21e2a32  push r10
00007d0bb21e2a34  push r11
00007d0bb21e2a36  sub rsp, 0xF0
00007d0bb21e2a3d  vmovaps [rsp], xmm0
00007d0bb21e2a42  vmovaps [rsp+0x10], xmm1
00007d0bb21e2a48  vmovaps [rsp+0x20], xmm2
00007d0bb21e2a4e  vmovaps [rsp+0x30], xmm3
00007d0bb21e2a54  vmovaps [rsp+0x40], xmm5
00007d0bb21e2a5a  vmovaps [rsp+0x50], xmm6
00007d0bb21e2a60  vmovaps [rsp+0x60], xmm7
00007d0bb21e2a66  vmovaps [rsp+0x70], xmm8
00007d0bb21e2a6c  vmovaps [rsp+0x80], xmm9
00007d0bb21e2a75  vmovaps [rsp+0x90], xmm10
00007d0bb21e2a7e  vmovaps [rsp+0xA0], xmm11
00007d0bb21e2a87  vmovaps [rsp+0xB0], xmm12
00007d0bb21e2a90  vmovaps [rsp+0xC0], xmm13
00007d0bb21e2a99  vmovaps [rsp+0xD0], xmm14
00007d0bb21e2aa2  vmovaps [rsp+0xE0], xmm15
00007d0bb21e2aab  sub rsp, 0x30
00007d0bb21e2aaf  movaps [rsp], xmm4
00007d0bb21e2ab3  movaps [rsp+0x10], xmm13
00007d0bb21e2ab9  movaps [rsp+0x20], xmm8
00007d0bb21e2abf  lea rdi, [rsp]
00007d0bb21e2ac3  mov esi, 0x00
00007d0bb21e2ac8  mov rax, 0x6392BBE7F530
00007d0bb21e2ad2  call rax
00007d0bb21e2ad4  movaps xmm4, [rsp]
00007d0bb21e2ad8  add rsp, 0x30
00007d0bb21e2adc  vmovaps xmm0, [rsp]
00007d0bb21e2ae1  vmovaps xmm1, [rsp+0x10]
00007d0bb21e2ae7  vmovaps xmm2, [rsp+0x20]
00007d0bb21e2aed  vmovaps xmm3, [rsp+0x30]
00007d0bb21e2af3  vmovaps xmm5, [rsp+0x40]
00007d0bb21e2af9  vmovaps xmm6, [rsp+0x50]
00007d0bb21e2aff  vmovaps xmm7, [rsp+0x60]
00007d0bb21e2b05  vmovaps xmm8, [rsp+0x70]
00007d0bb21e2b0b  vmovaps xmm9, [rsp+0x80]
00007d0bb21e2b14  vmovaps xmm10, [rsp+0x90]
00007d0bb21e2b1d  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e2b26  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e2b2f  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e2b38  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e2b41  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e2b4a  add rsp, 0xF0
00007d0bb21e2b51  pop r11
00007d0bb21e2b53  pop r10
00007d0bb21e2b55  pop r9
00007d0bb21e2b57  pop r8
00007d0bb21e2b59  pop rsi
00007d0bb21e2b5a  pop rdi
00007d0bb21e2b5b  pop rdx
00007d0bb21e2b5c  pop rcx
00007d0bb21e2b5d  pop rax
00007d0bb21e2b5e  add rsp, 0x08
00007d0bb21e2b62  jmp 0x00007D0BB21DF61D
00007d0bb21e2b67  sub rsp, 0x08
00007d0bb21e2b6b  push rax
00007d0bb21e2b6c  push rcx
00007d0bb21e2b6d  push rdx
00007d0bb21e2b6e  push rdi
00007d0bb21e2b6f  push rsi
00007d0bb21e2b70  push r8
00007d0bb21e2b72  push r9
00007d0bb21e2b74  push r10
00007d0bb21e2b76  push r11
00007d0bb21e2b78  sub rsp, 0xF0
00007d0bb21e2b7f  vmovaps [rsp], xmm0
00007d0bb21e2b84  vmovaps [rsp+0x10], xmm1
00007d0bb21e2b8a  vmovaps [rsp+0x20], xmm2
00007d0bb21e2b90  vmovaps [rsp+0x30], xmm3
00007d0bb21e2b96  vmovaps [rsp+0x40], xmm4
00007d0bb21e2b9c  vmovaps [rsp+0x50], xmm5
00007d0bb21e2ba2  vmovaps [rsp+0x60], xmm6
00007d0bb21e2ba8  vmovaps [rsp+0x70], xmm7
00007d0bb21e2bae  vmovaps [rsp+0x80], xmm8
00007d0bb21e2bb7  vmovaps [rsp+0x90], xmm9
00007d0bb21e2bc0  vmovaps [rsp+0xA0], xmm10
00007d0bb21e2bc9  vmovaps [rsp+0xB0], xmm11
00007d0bb21e2bd2  vmovaps [rsp+0xC0], xmm12
00007d0bb21e2bdb  vmovaps [rsp+0xD0], xmm14
00007d0bb21e2be4  vmovaps [rsp+0xE0], xmm15
00007d0bb21e2bed  sub rsp, 0x30
00007d0bb21e2bf1  movaps [rsp], xmm13
00007d0bb21e2bf6  movaps [rsp+0x10], xmm15
00007d0bb21e2bfc  movaps [rsp+0x20], xmm9
00007d0bb21e2c02  lea rdi, [rsp]
00007d0bb21e2c06  mov esi, 0x00
00007d0bb21e2c0b  mov rax, 0x6392BBE7F530
00007d0bb21e2c15  call rax
00007d0bb21e2c17  movaps xmm13, [rsp]
00007d0bb21e2c1c  add rsp, 0x30
00007d0bb21e2c20  vmovaps xmm0, [rsp]
00007d0bb21e2c25  vmovaps xmm1, [rsp+0x10]
00007d0bb21e2c2b  vmovaps xmm2, [rsp+0x20]
00007d0bb21e2c31  vmovaps xmm3, [rsp+0x30]
00007d0bb21e2c37  vmovaps xmm4, [rsp+0x40]
00007d0bb21e2c3d  vmovaps xmm5, [rsp+0x50]
00007d0bb21e2c43  vmovaps xmm6, [rsp+0x60]
00007d0bb21e2c49  vmovaps xmm7, [rsp+0x70]
00007d0bb21e2c4f  vmovaps xmm8, [rsp+0x80]
00007d0bb21e2c58  vmovaps xmm9, [rsp+0x90]
00007d0bb21e2c61  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e2c6a  vmovaps xmm11, [rsp+0xB0]
00007d0bb21e2c73  vmovaps xmm12, [rsp+0xC0]
00007d0bb21e2c7c  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e2c85  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e2c8e  add rsp, 0xF0
00007d0bb21e2c95  pop r11
00007d0bb21e2c97  pop r10
00007d0bb21e2c99  pop r9
00007d0bb21e2c9b  pop r8
00007d0bb21e2c9d  pop rsi
00007d0bb21e2c9e  pop rdi
00007d0bb21e2c9f  pop rdx
00007d0bb21e2ca0  pop rcx
00007d0bb21e2ca1  pop rax
00007d0bb21e2ca2  add rsp, 0x08
00007d0bb21e2ca6  jmp 0x00007D0BB21DF638
00007d0bb21e2cab  sub rsp, 0x08
00007d0bb21e2caf  push rax
00007d0bb21e2cb0  push rcx
00007d0bb21e2cb1  push rdx
00007d0bb21e2cb2  push rdi
00007d0bb21e2cb3  push rsi
00007d0bb21e2cb4  push r8
00007d0bb21e2cb6  push r9
00007d0bb21e2cb8  push r10
00007d0bb21e2cba  push r11
00007d0bb21e2cbc  sub rsp, 0xF0
00007d0bb21e2cc3  vmovaps [rsp], xmm0
00007d0bb21e2cc8  vmovaps [rsp+0x10], xmm1
00007d0bb21e2cce  vmovaps [rsp+0x20], xmm2
00007d0bb21e2cd4  vmovaps [rsp+0x30], xmm3
00007d0bb21e2cda  vmovaps [rsp+0x40], xmm4
00007d0bb21e2ce0  vmovaps [rsp+0x50], xmm5
00007d0bb21e2ce6  vmovaps [rsp+0x60], xmm6
00007d0bb21e2cec  vmovaps [rsp+0x70], xmm7
00007d0bb21e2cf2  vmovaps [rsp+0x80], xmm8
00007d0bb21e2cfb  vmovaps [rsp+0x90], xmm9
00007d0bb21e2d04  vmovaps [rsp+0xA0], xmm10
00007d0bb21e2d0d  vmovaps [rsp+0xB0], xmm11
00007d0bb21e2d16  vmovaps [rsp+0xC0], xmm12
00007d0bb21e2d1f  vmovaps [rsp+0xD0], xmm13
00007d0bb21e2d28  vmovaps [rsp+0xE0], xmm14
00007d0bb21e2d31  sub rsp, 0x30
00007d0bb21e2d35  movaps [rsp], xmm15
00007d0bb21e2d3a  movaps [rsp+0x10], xmm1
00007d0bb21e2d3f  movaps [rsp+0x20], xmm5
00007d0bb21e2d44  lea rdi, [rsp]
00007d0bb21e2d48  mov esi, 0x00
00007d0bb21e2d4d  mov rax, 0x6392BBE7F530
00007d0bb21e2d57  call rax
00007d0bb21e2d59  movaps xmm15, [rsp]
00007d0bb21e2d5e  add rsp, 0x30
00007d0bb21e2d62  vmovaps xmm0, [rsp]
00007d0bb21e2d67  vmovaps xmm1, [rsp+0x10]
00007d0bb21e2d6d  vmovaps xmm2, [rsp+0x20]
00007d0bb21e2d73  vmovaps xmm3, [rsp+0x30]
00007d0bb21e2d79  vmovaps xmm4, [rsp+0x40]
00007d0bb21e2d7f  vmovaps xmm5, [rsp+0x50]
00007d0bb21e2d85  vmovaps xmm6, [rsp+0x60]
00007d0bb21e2d8b  vmovaps xmm7, [rsp+0x70]
00007d0bb21e2d91  vmovaps xmm8, [rsp+0x80]
00007d0bb21e2d9a  vmovaps xmm9, [rsp+0x90]
00007d0bb21e2da3  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e2dac  vmovaps xmm11, [rsp+0xB0]
00007d0bb21e2db5  vmovaps xmm12, [rsp+0xC0]
00007d0bb21e2dbe  vmovaps xmm13, [rsp+0xD0]
00007d0bb21e2dc7  vmovaps xmm14, [rsp+0xE0]
00007d0bb21e2dd0  add rsp, 0xF0
00007d0bb21e2dd7  pop r11
00007d0bb21e2dd9  pop r10
00007d0bb21e2ddb  pop r9
00007d0bb21e2ddd  pop r8
00007d0bb21e2ddf  pop rsi
00007d0bb21e2de0  pop rdi
00007d0bb21e2de1  pop rdx
00007d0bb21e2de2  pop rcx
00007d0bb21e2de3  pop rax
00007d0bb21e2de4  add rsp, 0x08
00007d0bb21e2de8  jmp 0x00007D0BB21DF653
00007d0bb21e2ded  call 0x00007D0BB20B52F0
00007d0bb21e2df2  jmp 0x00007D0BB21DF6AE
00007d0bb21e2df7  sub rsp, 0x08
00007d0bb21e2dfb  push rax
00007d0bb21e2dfc  push rcx
00007d0bb21e2dfd  push rdx
00007d0bb21e2dfe  push rdi
00007d0bb21e2dff  push rsi
00007d0bb21e2e00  push r8
00007d0bb21e2e02  push r9
00007d0bb21e2e04  push r10
00007d0bb21e2e06  push r11
00007d0bb21e2e08  sub rsp, 0xF0
00007d0bb21e2e0f  vmovaps [rsp], xmm0
00007d0bb21e2e14  vmovaps [rsp+0x10], xmm1
00007d0bb21e2e1a  vmovaps [rsp+0x20], xmm2
00007d0bb21e2e20  vmovaps [rsp+0x30], xmm3
00007d0bb21e2e26  vmovaps [rsp+0x40], xmm4
00007d0bb21e2e2c  vmovaps [rsp+0x50], xmm5
00007d0bb21e2e32  vmovaps [rsp+0x60], xmm6
00007d0bb21e2e38  vmovaps [rsp+0x70], xmm7
00007d0bb21e2e3e  vmovaps [rsp+0x80], xmm8
00007d0bb21e2e47  vmovaps [rsp+0x90], xmm10
00007d0bb21e2e50  vmovaps [rsp+0xA0], xmm11
00007d0bb21e2e59  vmovaps [rsp+0xB0], xmm12
00007d0bb21e2e62  vmovaps [rsp+0xC0], xmm13
00007d0bb21e2e6b  vmovaps [rsp+0xD0], xmm14
00007d0bb21e2e74  vmovaps [rsp+0xE0], xmm15
00007d0bb21e2e7d  sub rsp, 0x30
00007d0bb21e2e81  movaps [rsp], xmm9
00007d0bb21e2e86  movaps [rsp+0x10], xmm8
00007d0bb21e2e8c  movaps [rsp+0x20], xmm11
00007d0bb21e2e92  lea rdi, [rsp]
00007d0bb21e2e96  mov esi, 0x00
00007d0bb21e2e9b  mov rax, 0x6392BBE7F530
00007d0bb21e2ea5  call rax
00007d0bb21e2ea7  movaps xmm9, [rsp]
00007d0bb21e2eac  add rsp, 0x30
00007d0bb21e2eb0  vmovaps xmm0, [rsp]
00007d0bb21e2eb5  vmovaps xmm1, [rsp+0x10]
00007d0bb21e2ebb  vmovaps xmm2, [rsp+0x20]
00007d0bb21e2ec1  vmovaps xmm3, [rsp+0x30]
00007d0bb21e2ec7  vmovaps xmm4, [rsp+0x40]
00007d0bb21e2ecd  vmovaps xmm5, [rsp+0x50]
00007d0bb21e2ed3  vmovaps xmm6, [rsp+0x60]
00007d0bb21e2ed9  vmovaps xmm7, [rsp+0x70]
00007d0bb21e2edf  vmovaps xmm8, [rsp+0x80]
00007d0bb21e2ee8  vmovaps xmm10, [rsp+0x90]
00007d0bb21e2ef1  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e2efa  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e2f03  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e2f0c  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e2f15  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e2f1e  add rsp, 0xF0
00007d0bb21e2f25  pop r11
00007d0bb21e2f27  pop r10
00007d0bb21e2f29  pop r9
00007d0bb21e2f2b  pop r8
00007d0bb21e2f2d  pop rsi
00007d0bb21e2f2e  pop rdi
00007d0bb21e2f2f  pop rdx
00007d0bb21e2f30  pop rcx
00007d0bb21e2f31  pop rax
00007d0bb21e2f32  add rsp, 0x08
00007d0bb21e2f36  jmp 0x00007D0BB21DF6E5
00007d0bb21e2f3b  sub rsp, 0x08
00007d0bb21e2f3f  push rax
00007d0bb21e2f40  push rcx
00007d0bb21e2f41  push rdx
00007d0bb21e2f42  push rdi
00007d0bb21e2f43  push rsi
00007d0bb21e2f44  push r8
00007d0bb21e2f46  push r9
00007d0bb21e2f48  push r10
00007d0bb21e2f4a  push r11
00007d0bb21e2f4c  sub rsp, 0xF0
00007d0bb21e2f53  vmovaps [rsp], xmm0
00007d0bb21e2f58  vmovaps [rsp+0x10], xmm1
00007d0bb21e2f5e  vmovaps [rsp+0x20], xmm2
00007d0bb21e2f64  vmovaps [rsp+0x30], xmm3
00007d0bb21e2f6a  vmovaps [rsp+0x40], xmm4
00007d0bb21e2f70  vmovaps [rsp+0x50], xmm5
00007d0bb21e2f76  vmovaps [rsp+0x60], xmm6
00007d0bb21e2f7c  vmovaps [rsp+0x70], xmm7
00007d0bb21e2f82  vmovaps [rsp+0x80], xmm8
00007d0bb21e2f8b  vmovaps [rsp+0x90], xmm9
00007d0bb21e2f94  vmovaps [rsp+0xA0], xmm10
00007d0bb21e2f9d  vmovaps [rsp+0xB0], xmm12
00007d0bb21e2fa6  vmovaps [rsp+0xC0], xmm13
00007d0bb21e2faf  vmovaps [rsp+0xD0], xmm14
00007d0bb21e2fb8  vmovaps [rsp+0xE0], xmm15
00007d0bb21e2fc1  sub rsp, 0x30
00007d0bb21e2fc5  movaps [rsp], xmm11
00007d0bb21e2fca  movaps [rsp+0x10], xmm10
00007d0bb21e2fd0  movaps [rsp+0x20], xmm6
00007d0bb21e2fd5  lea rdi, [rsp]
00007d0bb21e2fd9  mov esi, 0x00
00007d0bb21e2fde  mov rax, 0x6392BBE7F530
00007d0bb21e2fe8  call rax
00007d0bb21e2fea  movaps xmm11, [rsp]
00007d0bb21e2fef  add rsp, 0x30
00007d0bb21e2ff3  vmovaps xmm0, [rsp]
00007d0bb21e2ff8  vmovaps xmm1, [rsp+0x10]
00007d0bb21e2ffe  vmovaps xmm2, [rsp+0x20]
00007d0bb21e3004  vmovaps xmm3, [rsp+0x30]
00007d0bb21e300a  vmovaps xmm4, [rsp+0x40]
00007d0bb21e3010  vmovaps xmm5, [rsp+0x50]
00007d0bb21e3016  vmovaps xmm6, [rsp+0x60]
00007d0bb21e301c  vmovaps xmm7, [rsp+0x70]
00007d0bb21e3022  vmovaps xmm8, [rsp+0x80]
00007d0bb21e302b  vmovaps xmm9, [rsp+0x90]
00007d0bb21e3034  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e303d  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e3046  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e304f  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e3058  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e3061  add rsp, 0xF0
00007d0bb21e3068  pop r11
00007d0bb21e306a  pop r10
00007d0bb21e306c  pop r9
00007d0bb21e306e  pop r8
00007d0bb21e3070  pop rsi
00007d0bb21e3071  pop rdi
00007d0bb21e3072  pop rdx
00007d0bb21e3073  pop rcx
00007d0bb21e3074  pop rax
00007d0bb21e3075  add rsp, 0x08
00007d0bb21e3079  jmp 0x00007D0BB21DF700
00007d0bb21e307e  sub rsp, 0x08
00007d0bb21e3082  push rax
00007d0bb21e3083  push rcx
00007d0bb21e3084  push rdx
00007d0bb21e3085  push rdi
00007d0bb21e3086  push rsi
00007d0bb21e3087  push r8
00007d0bb21e3089  push r9
00007d0bb21e308b  push r10
00007d0bb21e308d  push r11
00007d0bb21e308f  sub rsp, 0xF0
00007d0bb21e3096  vmovaps [rsp], xmm0
00007d0bb21e309b  vmovaps [rsp+0x10], xmm1
00007d0bb21e30a1  vmovaps [rsp+0x20], xmm2
00007d0bb21e30a7  vmovaps [rsp+0x30], xmm3
00007d0bb21e30ad  vmovaps [rsp+0x40], xmm4
00007d0bb21e30b3  vmovaps [rsp+0x50], xmm5
00007d0bb21e30b9  vmovaps [rsp+0x60], xmm6
00007d0bb21e30bf  vmovaps [rsp+0x70], xmm7
00007d0bb21e30c5  vmovaps [rsp+0x80], xmm8
00007d0bb21e30ce  vmovaps [rsp+0x90], xmm9
00007d0bb21e30d7  vmovaps [rsp+0xA0], xmm11
00007d0bb21e30e0  vmovaps [rsp+0xB0], xmm12
00007d0bb21e30e9  vmovaps [rsp+0xC0], xmm13
00007d0bb21e30f2  vmovaps [rsp+0xD0], xmm14
00007d0bb21e30fb  vmovaps [rsp+0xE0], xmm15
00007d0bb21e3104  sub rsp, 0x30
00007d0bb21e3108  movaps [rsp], xmm10
00007d0bb21e310d  movaps [rsp+0x10], xmm14
00007d0bb21e3113  movaps [rsp+0x20], xmm4
00007d0bb21e3118  lea rdi, [rsp]
00007d0bb21e311c  mov esi, 0x00
00007d0bb21e3121  mov rax, 0x6392BBE7F530
00007d0bb21e312b  call rax
00007d0bb21e312d  movaps xmm10, [rsp]
00007d0bb21e3132  add rsp, 0x30
00007d0bb21e3136  vmovaps xmm0, [rsp]
00007d0bb21e313b  vmovaps xmm1, [rsp+0x10]
00007d0bb21e3141  vmovaps xmm2, [rsp+0x20]
00007d0bb21e3147  vmovaps xmm3, [rsp+0x30]
00007d0bb21e314d  vmovaps xmm4, [rsp+0x40]
00007d0bb21e3153  vmovaps xmm5, [rsp+0x50]
00007d0bb21e3159  vmovaps xmm6, [rsp+0x60]
00007d0bb21e315f  vmovaps xmm7, [rsp+0x70]
00007d0bb21e3165  vmovaps xmm8, [rsp+0x80]
00007d0bb21e316e  vmovaps xmm9, [rsp+0x90]
00007d0bb21e3177  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e3180  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e3189  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e3192  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e319b  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e31a4  add rsp, 0xF0
00007d0bb21e31ab  pop r11
00007d0bb21e31ad  pop r10
00007d0bb21e31af  pop r9
00007d0bb21e31b1  pop r8
00007d0bb21e31b3  pop rsi
00007d0bb21e31b4  pop rdi
00007d0bb21e31b5  pop rdx
00007d0bb21e31b6  pop rcx
00007d0bb21e31b7  pop rax
00007d0bb21e31b8  add rsp, 0x08
00007d0bb21e31bc  jmp 0x00007D0BB21DF71B
00007d0bb21e31c1  sub rsp, 0x08
00007d0bb21e31c5  push rax
00007d0bb21e31c6  push rcx
00007d0bb21e31c7  push rdx
00007d0bb21e31c8  push rdi
00007d0bb21e31c9  push rsi
00007d0bb21e31ca  push r8
00007d0bb21e31cc  push r9
00007d0bb21e31ce  push r10
00007d0bb21e31d0  push r11
00007d0bb21e31d2  sub rsp, 0xF0
00007d0bb21e31d9  vmovaps [rsp], xmm0
00007d0bb21e31de  vmovaps [rsp+0x10], xmm1
00007d0bb21e31e4  vmovaps [rsp+0x20], xmm2
00007d0bb21e31ea  vmovaps [rsp+0x30], xmm3
00007d0bb21e31f0  vmovaps [rsp+0x40], xmm4
00007d0bb21e31f6  vmovaps [rsp+0x50], xmm5
00007d0bb21e31fc  vmovaps [rsp+0x60], xmm6
00007d0bb21e3202  vmovaps [rsp+0x70], xmm7
00007d0bb21e3208  vmovaps [rsp+0x80], xmm9
00007d0bb21e3211  vmovaps [rsp+0x90], xmm10
00007d0bb21e321a  vmovaps [rsp+0xA0], xmm11
00007d0bb21e3223  vmovaps [rsp+0xB0], xmm12
00007d0bb21e322c  vmovaps [rsp+0xC0], xmm13
00007d0bb21e3235  vmovaps [rsp+0xD0], xmm14
00007d0bb21e323e  vmovaps [rsp+0xE0], xmm15
00007d0bb21e3247  sub rsp, 0x30
00007d0bb21e324b  movaps [rsp], xmm8
00007d0bb21e3250  movaps [rsp+0x10], xmm1
00007d0bb21e3255  movaps [rsp+0x20], xmm14
00007d0bb21e325b  lea rdi, [rsp]
00007d0bb21e325f  mov esi, 0x00
00007d0bb21e3264  mov rax, 0x6392BBE7F530
00007d0bb21e326e  call rax
00007d0bb21e3270  movaps xmm8, [rsp]
00007d0bb21e3275  add rsp, 0x30
00007d0bb21e3279  vmovaps xmm0, [rsp]
00007d0bb21e327e  vmovaps xmm1, [rsp+0x10]
00007d0bb21e3284  vmovaps xmm2, [rsp+0x20]
00007d0bb21e328a  vmovaps xmm3, [rsp+0x30]
00007d0bb21e3290  vmovaps xmm4, [rsp+0x40]
00007d0bb21e3296  vmovaps xmm5, [rsp+0x50]
00007d0bb21e329c  vmovaps xmm6, [rsp+0x60]
00007d0bb21e32a2  vmovaps xmm7, [rsp+0x70]
00007d0bb21e32a8  vmovaps xmm9, [rsp+0x80]
00007d0bb21e32b1  vmovaps xmm10, [rsp+0x90]
00007d0bb21e32ba  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e32c3  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e32cc  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e32d5  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e32de  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e32e7  add rsp, 0xF0
00007d0bb21e32ee  pop r11
00007d0bb21e32f0  pop r10
00007d0bb21e32f2  pop r9
00007d0bb21e32f4  pop r8
00007d0bb21e32f6  pop rsi
00007d0bb21e32f7  pop rdi
00007d0bb21e32f8  pop rdx
00007d0bb21e32f9  pop rcx
00007d0bb21e32fa  pop rax
00007d0bb21e32fb  add rsp, 0x08
00007d0bb21e32ff  jmp 0x00007D0BB21DF741
00007d0bb21e3304  sub rsp, 0x08
00007d0bb21e3308  push rax
00007d0bb21e3309  push rcx
00007d0bb21e330a  push rdx
00007d0bb21e330b  push rdi
00007d0bb21e330c  push rsi
00007d0bb21e330d  push r8
00007d0bb21e330f  push r9
00007d0bb21e3311  push r10
00007d0bb21e3313  push r11
00007d0bb21e3315  sub rsp, 0xF0
00007d0bb21e331c  vmovaps [rsp], xmm0
00007d0bb21e3321  vmovaps [rsp+0x10], xmm1
00007d0bb21e3327  vmovaps [rsp+0x20], xmm2
00007d0bb21e332d  vmovaps [rsp+0x30], xmm3
00007d0bb21e3333  vmovaps [rsp+0x40], xmm4
00007d0bb21e3339  vmovaps [rsp+0x50], xmm5
00007d0bb21e333f  vmovaps [rsp+0x60], xmm7
00007d0bb21e3345  vmovaps [rsp+0x70], xmm8
00007d0bb21e334b  vmovaps [rsp+0x80], xmm9
00007d0bb21e3354  vmovaps [rsp+0x90], xmm10
00007d0bb21e335d  vmovaps [rsp+0xA0], xmm11
00007d0bb21e3366  vmovaps [rsp+0xB0], xmm12
00007d0bb21e336f  vmovaps [rsp+0xC0], xmm13
00007d0bb21e3378  vmovaps [rsp+0xD0], xmm14
00007d0bb21e3381  vmovaps [rsp+0xE0], xmm15
00007d0bb21e338a  sub rsp, 0x30
00007d0bb21e338e  movaps [rsp], xmm6
00007d0bb21e3392  movaps [rsp+0x10], xmm1
00007d0bb21e3397  movaps [rsp+0x20], xmm14
00007d0bb21e339d  lea rdi, [rsp]
00007d0bb21e33a1  mov esi, 0x00
00007d0bb21e33a6  mov rax, 0x6392BBE7F530
00007d0bb21e33b0  call rax
00007d0bb21e33b2  movaps xmm6, [rsp]
00007d0bb21e33b6  add rsp, 0x30
00007d0bb21e33ba  vmovaps xmm0, [rsp]
00007d0bb21e33bf  vmovaps xmm1, [rsp+0x10]
00007d0bb21e33c5  vmovaps xmm2, [rsp+0x20]
00007d0bb21e33cb  vmovaps xmm3, [rsp+0x30]
00007d0bb21e33d1  vmovaps xmm4, [rsp+0x40]
00007d0bb21e33d7  vmovaps xmm5, [rsp+0x50]
00007d0bb21e33dd  vmovaps xmm7, [rsp+0x60]
00007d0bb21e33e3  vmovaps xmm8, [rsp+0x70]
00007d0bb21e33e9  vmovaps xmm9, [rsp+0x80]
00007d0bb21e33f2  vmovaps xmm10, [rsp+0x90]
00007d0bb21e33fb  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e3404  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e340d  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e3416  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e341f  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e3428  add rsp, 0xF0
00007d0bb21e342f  pop r11
00007d0bb21e3431  pop r10
00007d0bb21e3433  pop r9
00007d0bb21e3435  pop r8
00007d0bb21e3437  pop rsi
00007d0bb21e3438  pop rdi
00007d0bb21e3439  pop rdx
00007d0bb21e343a  pop rcx
00007d0bb21e343b  pop rax
00007d0bb21e343c  add rsp, 0x08
00007d0bb21e3440  jmp 0x00007D0BB21DF76D
00007d0bb21e3445  sub rsp, 0x08
00007d0bb21e3449  push rax
00007d0bb21e344a  push rcx
00007d0bb21e344b  push rdx
00007d0bb21e344c  push rdi
00007d0bb21e344d  push rsi
00007d0bb21e344e  push r8
00007d0bb21e3450  push r9
00007d0bb21e3452  push r10
00007d0bb21e3454  push r11
00007d0bb21e3456  sub rsp, 0xF0
00007d0bb21e345d  vmovaps [rsp], xmm0
00007d0bb21e3462  vmovaps [rsp+0x10], xmm1
00007d0bb21e3468  vmovaps [rsp+0x20], xmm2
00007d0bb21e346e  vmovaps [rsp+0x30], xmm3
00007d0bb21e3474  vmovaps [rsp+0x40], xmm4
00007d0bb21e347a  vmovaps [rsp+0x50], xmm5
00007d0bb21e3480  vmovaps [rsp+0x60], xmm6
00007d0bb21e3486  vmovaps [rsp+0x70], xmm7
00007d0bb21e348c  vmovaps [rsp+0x80], xmm8
00007d0bb21e3495  vmovaps [rsp+0x90], xmm9
00007d0bb21e349e  vmovaps [rsp+0xA0], xmm10
00007d0bb21e34a7  vmovaps [rsp+0xB0], xmm11
00007d0bb21e34b0  vmovaps [rsp+0xC0], xmm12
00007d0bb21e34b9  vmovaps [rsp+0xD0], xmm13
00007d0bb21e34c2  vmovaps [rsp+0xE0], xmm15
00007d0bb21e34cb  sub rsp, 0x30
00007d0bb21e34cf  movaps [rsp], xmm14
00007d0bb21e34d4  movaps [rsp+0x10], xmm12
00007d0bb21e34da  movaps [rsp+0x20], xmm1
00007d0bb21e34df  lea rdi, [rsp]
00007d0bb21e34e3  mov esi, 0x00
00007d0bb21e34e8  mov rax, 0x6392BBE7F530
00007d0bb21e34f2  call rax
00007d0bb21e34f4  movaps xmm14, [rsp]
00007d0bb21e34f9  add rsp, 0x30
00007d0bb21e34fd  vmovaps xmm0, [rsp]
00007d0bb21e3502  vmovaps xmm1, [rsp+0x10]
00007d0bb21e3508  vmovaps xmm2, [rsp+0x20]
00007d0bb21e350e  vmovaps xmm3, [rsp+0x30]
00007d0bb21e3514  vmovaps xmm4, [rsp+0x40]
00007d0bb21e351a  vmovaps xmm5, [rsp+0x50]
00007d0bb21e3520  vmovaps xmm6, [rsp+0x60]
00007d0bb21e3526  vmovaps xmm7, [rsp+0x70]
00007d0bb21e352c  vmovaps xmm8, [rsp+0x80]
00007d0bb21e3535  vmovaps xmm9, [rsp+0x90]
00007d0bb21e353e  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e3547  vmovaps xmm11, [rsp+0xB0]
00007d0bb21e3550  vmovaps xmm12, [rsp+0xC0]
00007d0bb21e3559  vmovaps xmm13, [rsp+0xD0]
00007d0bb21e3562  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e356b  add rsp, 0xF0
00007d0bb21e3572  pop r11
00007d0bb21e3574  pop r10
00007d0bb21e3576  pop r9
00007d0bb21e3578  pop r8
00007d0bb21e357a  pop rsi
00007d0bb21e357b  pop rdi
00007d0bb21e357c  pop rdx
00007d0bb21e357d  pop rcx
00007d0bb21e357e  pop rax
00007d0bb21e357f  add rsp, 0x08
00007d0bb21e3583  jmp 0x00007D0BB21DF793
00007d0bb21e3588  sub rsp, 0x08
00007d0bb21e358c  push rax
00007d0bb21e358d  push rcx
00007d0bb21e358e  push rdx
00007d0bb21e358f  push rdi
00007d0bb21e3590  push rsi
00007d0bb21e3591  push r8
00007d0bb21e3593  push r9
00007d0bb21e3595  push r10
00007d0bb21e3597  push r11
00007d0bb21e3599  sub rsp, 0xF0
00007d0bb21e35a0  vmovaps [rsp], xmm0
00007d0bb21e35a5  vmovaps [rsp+0x10], xmm2
00007d0bb21e35ab  vmovaps [rsp+0x20], xmm3
00007d0bb21e35b1  vmovaps [rsp+0x30], xmm4
00007d0bb21e35b7  vmovaps [rsp+0x40], xmm5
00007d0bb21e35bd  vmovaps [rsp+0x50], xmm6
00007d0bb21e35c3  vmovaps [rsp+0x60], xmm7
00007d0bb21e35c9  vmovaps [rsp+0x70], xmm8
00007d0bb21e35cf  vmovaps [rsp+0x80], xmm9
00007d0bb21e35d8  vmovaps [rsp+0x90], xmm10
00007d0bb21e35e1  vmovaps [rsp+0xA0], xmm11
00007d0bb21e35ea  vmovaps [rsp+0xB0], xmm12
00007d0bb21e35f3  vmovaps [rsp+0xC0], xmm13
00007d0bb21e35fc  vmovaps [rsp+0xD0], xmm14
00007d0bb21e3605  vmovaps [rsp+0xE0], xmm15
00007d0bb21e360e  sub rsp, 0x30
00007d0bb21e3612  movaps [rsp], xmm1
00007d0bb21e3616  movaps [rsp+0x10], xmm13
00007d0bb21e361c  movaps [rsp+0x20], xmm9
00007d0bb21e3622  lea rdi, [rsp]
00007d0bb21e3626  mov esi, 0x00
00007d0bb21e362b  mov rax, 0x6392BBE7F530
00007d0bb21e3635  call rax
00007d0bb21e3637  movaps xmm1, [rsp]
00007d0bb21e363b  add rsp, 0x30
00007d0bb21e363f  vmovaps xmm0, [rsp]
00007d0bb21e3644  vmovaps xmm2, [rsp+0x10]
00007d0bb21e364a  vmovaps xmm3, [rsp+0x20]
00007d0bb21e3650  vmovaps xmm4, [rsp+0x30]
00007d0bb21e3656  vmovaps xmm5, [rsp+0x40]
00007d0bb21e365c  vmovaps xmm6, [rsp+0x50]
00007d0bb21e3662  vmovaps xmm7, [rsp+0x60]
00007d0bb21e3668  vmovaps xmm8, [rsp+0x70]
00007d0bb21e366e  vmovaps xmm9, [rsp+0x80]
00007d0bb21e3677  vmovaps xmm10, [rsp+0x90]
00007d0bb21e3680  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e3689  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e3692  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e369b  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e36a4  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e36ad  add rsp, 0xF0
00007d0bb21e36b4  pop r11
00007d0bb21e36b6  pop r10
00007d0bb21e36b8  pop r9
00007d0bb21e36ba  pop r8
00007d0bb21e36bc  pop rsi
00007d0bb21e36bd  pop rdi
00007d0bb21e36be  pop rdx
00007d0bb21e36bf  pop rcx
00007d0bb21e36c0  pop rax
00007d0bb21e36c1  add rsp, 0x08
00007d0bb21e36c5  jmp 0x00007D0BB21DF7AD
00007d0bb21e36ca  sub rsp, 0x08
00007d0bb21e36ce  push rax
00007d0bb21e36cf  push rcx
00007d0bb21e36d0  push rdx
00007d0bb21e36d1  push rdi
00007d0bb21e36d2  push rsi
00007d0bb21e36d3  push r8
00007d0bb21e36d5  push r9
00007d0bb21e36d7  push r10
00007d0bb21e36d9  push r11
00007d0bb21e36db  sub rsp, 0xF0
00007d0bb21e36e2  vmovaps [rsp], xmm0
00007d0bb21e36e7  vmovaps [rsp+0x10], xmm1
00007d0bb21e36ed  vmovaps [rsp+0x20], xmm2
00007d0bb21e36f3  vmovaps [rsp+0x30], xmm3
00007d0bb21e36f9  vmovaps [rsp+0x40], xmm4
00007d0bb21e36ff  vmovaps [rsp+0x50], xmm5
00007d0bb21e3705  vmovaps [rsp+0x60], xmm6
00007d0bb21e370b  vmovaps [rsp+0x70], xmm7
00007d0bb21e3711  vmovaps [rsp+0x80], xmm8
00007d0bb21e371a  vmovaps [rsp+0x90], xmm9
00007d0bb21e3723  vmovaps [rsp+0xA0], xmm10
00007d0bb21e372c  vmovaps [rsp+0xB0], xmm11
00007d0bb21e3735  vmovaps [rsp+0xC0], xmm13
00007d0bb21e373e  vmovaps [rsp+0xD0], xmm14
00007d0bb21e3747  vmovaps [rsp+0xE0], xmm15
00007d0bb21e3750  sub rsp, 0x30
00007d0bb21e3754  movaps [rsp], xmm12
00007d0bb21e3759  movaps [rsp+0x10], xmm7
00007d0bb21e375e  movaps [rsp+0x20], xmm13
00007d0bb21e3764  lea rdi, [rsp]
00007d0bb21e3768  mov esi, 0x00
00007d0bb21e376d  mov rax, 0x6392BBE7F530
00007d0bb21e3777  call rax
00007d0bb21e3779  movaps xmm12, [rsp]
00007d0bb21e377e  add rsp, 0x30
00007d0bb21e3782  vmovaps xmm0, [rsp]
00007d0bb21e3787  vmovaps xmm1, [rsp+0x10]
00007d0bb21e378d  vmovaps xmm2, [rsp+0x20]
00007d0bb21e3793  vmovaps xmm3, [rsp+0x30]
00007d0bb21e3799  vmovaps xmm4, [rsp+0x40]
00007d0bb21e379f  vmovaps xmm5, [rsp+0x50]
00007d0bb21e37a5  vmovaps xmm6, [rsp+0x60]
00007d0bb21e37ab  vmovaps xmm7, [rsp+0x70]
00007d0bb21e37b1  vmovaps xmm8, [rsp+0x80]
00007d0bb21e37ba  vmovaps xmm9, [rsp+0x90]
00007d0bb21e37c3  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e37cc  vmovaps xmm11, [rsp+0xB0]
00007d0bb21e37d5  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e37de  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e37e7  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e37f0  add rsp, 0xF0
00007d0bb21e37f7  pop r11
00007d0bb21e37f9  pop r10
00007d0bb21e37fb  pop r9
00007d0bb21e37fd  pop r8
00007d0bb21e37ff  pop rsi
00007d0bb21e3800  pop rdi
00007d0bb21e3801  pop rdx
00007d0bb21e3802  pop rcx
00007d0bb21e3803  pop rax
00007d0bb21e3804  add rsp, 0x08
00007d0bb21e3808  jmp 0x00007D0BB21DF7D4
00007d0bb21e380d  sub rsp, 0x08
00007d0bb21e3811  push rax
00007d0bb21e3812  push rcx
00007d0bb21e3813  push rdx
00007d0bb21e3814  push rdi
00007d0bb21e3815  push rsi
00007d0bb21e3816  push r8
00007d0bb21e3818  push r9
00007d0bb21e381a  push r10
00007d0bb21e381c  push r11
00007d0bb21e381e  sub rsp, 0xF0
00007d0bb21e3825  vmovaps [rsp], xmm0
00007d0bb21e382a  vmovaps [rsp+0x10], xmm1
00007d0bb21e3830  vmovaps [rsp+0x20], xmm2
00007d0bb21e3836  vmovaps [rsp+0x30], xmm3
00007d0bb21e383c  vmovaps [rsp+0x40], xmm4
00007d0bb21e3842  vmovaps [rsp+0x50], xmm5
00007d0bb21e3848  vmovaps [rsp+0x60], xmm6
00007d0bb21e384e  vmovaps [rsp+0x70], xmm7
00007d0bb21e3854  vmovaps [rsp+0x80], xmm8
00007d0bb21e385d  vmovaps [rsp+0x90], xmm9
00007d0bb21e3866  vmovaps [rsp+0xA0], xmm10
00007d0bb21e386f  vmovaps [rsp+0xB0], xmm11
00007d0bb21e3878  vmovaps [rsp+0xC0], xmm12
00007d0bb21e3881  vmovaps [rsp+0xD0], xmm14
00007d0bb21e388a  vmovaps [rsp+0xE0], xmm15
00007d0bb21e3893  sub rsp, 0x30
00007d0bb21e3897  movaps [rsp], xmm13
00007d0bb21e389c  movaps [rsp+0x10], xmm15
00007d0bb21e38a2  movaps [rsp+0x20], xmm8
00007d0bb21e38a8  lea rdi, [rsp]
00007d0bb21e38ac  mov esi, 0x00
00007d0bb21e38b1  mov rax, 0x6392BBE7F530
00007d0bb21e38bb  call rax
00007d0bb21e38bd  movaps xmm13, [rsp]
00007d0bb21e38c2  add rsp, 0x30
00007d0bb21e38c6  vmovaps xmm0, [rsp]
00007d0bb21e38cb  vmovaps xmm1, [rsp+0x10]
00007d0bb21e38d1  vmovaps xmm2, [rsp+0x20]
00007d0bb21e38d7  vmovaps xmm3, [rsp+0x30]
00007d0bb21e38dd  vmovaps xmm4, [rsp+0x40]
00007d0bb21e38e3  vmovaps xmm5, [rsp+0x50]
00007d0bb21e38e9  vmovaps xmm6, [rsp+0x60]
00007d0bb21e38ef  vmovaps xmm7, [rsp+0x70]
00007d0bb21e38f5  vmovaps xmm8, [rsp+0x80]
00007d0bb21e38fe  vmovaps xmm9, [rsp+0x90]
00007d0bb21e3907  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e3910  vmovaps xmm11, [rsp+0xB0]
00007d0bb21e3919  vmovaps xmm12, [rsp+0xC0]
00007d0bb21e3922  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e392b  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e3934  add rsp, 0xF0
00007d0bb21e393b  pop r11
00007d0bb21e393d  pop r10
00007d0bb21e393f  pop r9
00007d0bb21e3941  pop r8
00007d0bb21e3943  pop rsi
00007d0bb21e3944  pop rdi
00007d0bb21e3945  pop rdx
00007d0bb21e3946  pop rcx
00007d0bb21e3947  pop rax
00007d0bb21e3948  add rsp, 0x08
00007d0bb21e394c  jmp 0x00007D0BB21DF7EF
00007d0bb21e3951  sub rsp, 0x08
00007d0bb21e3955  push rax
00007d0bb21e3956  push rcx
00007d0bb21e3957  push rdx
00007d0bb21e3958  push rdi
00007d0bb21e3959  push rsi
00007d0bb21e395a  push r8
00007d0bb21e395c  push r9
00007d0bb21e395e  push r10
00007d0bb21e3960  push r11
00007d0bb21e3962  sub rsp, 0xF0
00007d0bb21e3969  vmovaps [rsp], xmm0
00007d0bb21e396e  vmovaps [rsp+0x10], xmm1
00007d0bb21e3974  vmovaps [rsp+0x20], xmm2
00007d0bb21e397a  vmovaps [rsp+0x30], xmm3
00007d0bb21e3980  vmovaps [rsp+0x40], xmm4
00007d0bb21e3986  vmovaps [rsp+0x50], xmm5
00007d0bb21e398c  vmovaps [rsp+0x60], xmm6
00007d0bb21e3992  vmovaps [rsp+0x70], xmm7
00007d0bb21e3998  vmovaps [rsp+0x80], xmm9
00007d0bb21e39a1  vmovaps [rsp+0x90], xmm10
00007d0bb21e39aa  vmovaps [rsp+0xA0], xmm11
00007d0bb21e39b3  vmovaps [rsp+0xB0], xmm12
00007d0bb21e39bc  vmovaps [rsp+0xC0], xmm13
00007d0bb21e39c5  vmovaps [rsp+0xD0], xmm14
00007d0bb21e39ce  vmovaps [rsp+0xE0], xmm15
00007d0bb21e39d7  sub rsp, 0x30
00007d0bb21e39db  movaps [rsp], xmm8
00007d0bb21e39e0  movaps [rsp+0x10], xmm15
00007d0bb21e39e6  movaps [rsp+0x20], xmm9
00007d0bb21e39ec  lea rdi, [rsp]
00007d0bb21e39f0  mov esi, 0x00
00007d0bb21e39f5  mov rax, 0x6392BBE7F530
00007d0bb21e39ff  call rax
00007d0bb21e3a01  movaps xmm8, [rsp]
00007d0bb21e3a06  add rsp, 0x30
00007d0bb21e3a0a  vmovaps xmm0, [rsp]
00007d0bb21e3a0f  vmovaps xmm1, [rsp+0x10]
00007d0bb21e3a15  vmovaps xmm2, [rsp+0x20]
00007d0bb21e3a1b  vmovaps xmm3, [rsp+0x30]
00007d0bb21e3a21  vmovaps xmm4, [rsp+0x40]
00007d0bb21e3a27  vmovaps xmm5, [rsp+0x50]
00007d0bb21e3a2d  vmovaps xmm6, [rsp+0x60]
00007d0bb21e3a33  vmovaps xmm7, [rsp+0x70]
00007d0bb21e3a39  vmovaps xmm9, [rsp+0x80]
00007d0bb21e3a42  vmovaps xmm10, [rsp+0x90]
00007d0bb21e3a4b  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e3a54  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e3a5d  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e3a66  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e3a6f  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e3a78  add rsp, 0xF0
00007d0bb21e3a7f  pop r11
00007d0bb21e3a81  pop r10
00007d0bb21e3a83  pop r9
00007d0bb21e3a85  pop r8
00007d0bb21e3a87  pop rsi
00007d0bb21e3a88  pop rdi
00007d0bb21e3a89  pop rdx
00007d0bb21e3a8a  pop rcx
00007d0bb21e3a8b  pop rax
00007d0bb21e3a8c  add rsp, 0x08
00007d0bb21e3a90  jmp 0x00007D0BB21DF81D
00007d0bb21e3a95  sub rsp, 0x08
00007d0bb21e3a99  push rax
00007d0bb21e3a9a  push rcx
00007d0bb21e3a9b  push rdx
00007d0bb21e3a9c  push rdi
00007d0bb21e3a9d  push rsi
00007d0bb21e3a9e  push r8
00007d0bb21e3aa0  push r9
00007d0bb21e3aa2  push r10
00007d0bb21e3aa4  push r11
00007d0bb21e3aa6  sub rsp, 0xF0
00007d0bb21e3aad  vmovaps [rsp], xmm0
00007d0bb21e3ab2  vmovaps [rsp+0x10], xmm1
00007d0bb21e3ab8  vmovaps [rsp+0x20], xmm2
00007d0bb21e3abe  vmovaps [rsp+0x30], xmm3
00007d0bb21e3ac4  vmovaps [rsp+0x40], xmm4
00007d0bb21e3aca  vmovaps [rsp+0x50], xmm5
00007d0bb21e3ad0  vmovaps [rsp+0x60], xmm6
00007d0bb21e3ad6  vmovaps [rsp+0x70], xmm7
00007d0bb21e3adc  vmovaps [rsp+0x80], xmm8
00007d0bb21e3ae5  vmovaps [rsp+0x90], xmm9
00007d0bb21e3aee  vmovaps [rsp+0xA0], xmm10
00007d0bb21e3af7  vmovaps [rsp+0xB0], xmm11
00007d0bb21e3b00  vmovaps [rsp+0xC0], xmm12
00007d0bb21e3b09  vmovaps [rsp+0xD0], xmm13
00007d0bb21e3b12  vmovaps [rsp+0xE0], xmm14
00007d0bb21e3b1b  sub rsp, 0x30
00007d0bb21e3b1f  movaps [rsp], xmm15
00007d0bb21e3b24  movaps [rsp+0x10], xmm11
00007d0bb21e3b2a  movaps [rsp+0x20], xmm6
00007d0bb21e3b2f  lea rdi, [rsp]
00007d0bb21e3b33  mov esi, 0x00
00007d0bb21e3b38  mov rax, 0x6392BBE7F530
00007d0bb21e3b42  call rax
00007d0bb21e3b44  movaps xmm15, [rsp]
00007d0bb21e3b49  add rsp, 0x30
00007d0bb21e3b4d  vmovaps xmm0, [rsp]
00007d0bb21e3b52  vmovaps xmm1, [rsp+0x10]
00007d0bb21e3b58  vmovaps xmm2, [rsp+0x20]
00007d0bb21e3b5e  vmovaps xmm3, [rsp+0x30]
00007d0bb21e3b64  vmovaps xmm4, [rsp+0x40]
00007d0bb21e3b6a  vmovaps xmm5, [rsp+0x50]
00007d0bb21e3b70  vmovaps xmm6, [rsp+0x60]
00007d0bb21e3b76  vmovaps xmm7, [rsp+0x70]
00007d0bb21e3b7c  vmovaps xmm8, [rsp+0x80]
00007d0bb21e3b85  vmovaps xmm9, [rsp+0x90]
00007d0bb21e3b8e  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e3b97  vmovaps xmm11, [rsp+0xB0]
00007d0bb21e3ba0  vmovaps xmm12, [rsp+0xC0]
00007d0bb21e3ba9  vmovaps xmm13, [rsp+0xD0]
00007d0bb21e3bb2  vmovaps xmm14, [rsp+0xE0]
00007d0bb21e3bbb  add rsp, 0xF0
00007d0bb21e3bc2  pop r11
00007d0bb21e3bc4  pop r10
00007d0bb21e3bc6  pop r9
00007d0bb21e3bc8  pop r8
00007d0bb21e3bca  pop rsi
00007d0bb21e3bcb  pop rdi
00007d0bb21e3bcc  pop rdx
00007d0bb21e3bcd  pop rcx
00007d0bb21e3bce  pop rax
00007d0bb21e3bcf  add rsp, 0x08
00007d0bb21e3bd3  jmp 0x00007D0BB21DF838
00007d0bb21e3bd8  sub rsp, 0x08
00007d0bb21e3bdc  push rax
00007d0bb21e3bdd  push rcx
00007d0bb21e3bde  push rdx
00007d0bb21e3bdf  push rdi
00007d0bb21e3be0  push rsi
00007d0bb21e3be1  push r8
00007d0bb21e3be3  push r9
00007d0bb21e3be5  push r10
00007d0bb21e3be7  push r11
00007d0bb21e3be9  sub rsp, 0xF0
00007d0bb21e3bf0  vmovaps [rsp], xmm0
00007d0bb21e3bf5  vmovaps [rsp+0x10], xmm1
00007d0bb21e3bfb  vmovaps [rsp+0x20], xmm2
00007d0bb21e3c01  vmovaps [rsp+0x30], xmm3
00007d0bb21e3c07  vmovaps [rsp+0x40], xmm4
00007d0bb21e3c0d  vmovaps [rsp+0x50], xmm5
00007d0bb21e3c13  vmovaps [rsp+0x60], xmm6
00007d0bb21e3c19  vmovaps [rsp+0x70], xmm8
00007d0bb21e3c1f  vmovaps [rsp+0x80], xmm9
00007d0bb21e3c28  vmovaps [rsp+0x90], xmm10
00007d0bb21e3c31  vmovaps [rsp+0xA0], xmm11
00007d0bb21e3c3a  vmovaps [rsp+0xB0], xmm12
00007d0bb21e3c43  vmovaps [rsp+0xC0], xmm13
00007d0bb21e3c4c  vmovaps [rsp+0xD0], xmm14
00007d0bb21e3c55  vmovaps [rsp+0xE0], xmm15
00007d0bb21e3c5e  sub rsp, 0x30
00007d0bb21e3c62  movaps [rsp], xmm7
00007d0bb21e3c66  movaps [rsp+0x10], xmm11
00007d0bb21e3c6c  movaps [rsp+0x20], xmm9
00007d0bb21e3c72  lea rdi, [rsp]
00007d0bb21e3c76  mov esi, 0x00
00007d0bb21e3c7b  mov rax, 0x6392BBE7F530
00007d0bb21e3c85  call rax
00007d0bb21e3c87  movaps xmm7, [rsp]
00007d0bb21e3c8b  add rsp, 0x30
00007d0bb21e3c8f  vmovaps xmm0, [rsp]
00007d0bb21e3c94  vmovaps xmm1, [rsp+0x10]
00007d0bb21e3c9a  vmovaps xmm2, [rsp+0x20]
00007d0bb21e3ca0  vmovaps xmm3, [rsp+0x30]
00007d0bb21e3ca6  vmovaps xmm4, [rsp+0x40]
00007d0bb21e3cac  vmovaps xmm5, [rsp+0x50]
00007d0bb21e3cb2  vmovaps xmm6, [rsp+0x60]
00007d0bb21e3cb8  vmovaps xmm8, [rsp+0x70]
00007d0bb21e3cbe  vmovaps xmm9, [rsp+0x80]
00007d0bb21e3cc7  vmovaps xmm10, [rsp+0x90]
00007d0bb21e3cd0  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e3cd9  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e3ce2  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e3ceb  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e3cf4  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e3cfd  add rsp, 0xF0
00007d0bb21e3d04  pop r11
00007d0bb21e3d06  pop r10
00007d0bb21e3d08  pop r9
00007d0bb21e3d0a  pop r8
00007d0bb21e3d0c  pop rsi
00007d0bb21e3d0d  pop rdi
00007d0bb21e3d0e  pop rdx
00007d0bb21e3d0f  pop rcx
00007d0bb21e3d10  pop rax
00007d0bb21e3d11  add rsp, 0x08
00007d0bb21e3d15  jmp 0x00007D0BB21DF865
00007d0bb21e3d1a  sub rsp, 0x08
00007d0bb21e3d1e  push rax
00007d0bb21e3d1f  push rcx
00007d0bb21e3d20  push rdx
00007d0bb21e3d21  push rdi
00007d0bb21e3d22  push rsi
00007d0bb21e3d23  push r8
00007d0bb21e3d25  push r9
00007d0bb21e3d27  push r10
00007d0bb21e3d29  push r11
00007d0bb21e3d2b  sub rsp, 0xF0
00007d0bb21e3d32  vmovaps [rsp], xmm0
00007d0bb21e3d37  vmovaps [rsp+0x10], xmm1
00007d0bb21e3d3d  vmovaps [rsp+0x20], xmm2
00007d0bb21e3d43  vmovaps [rsp+0x30], xmm3
00007d0bb21e3d49  vmovaps [rsp+0x40], xmm4
00007d0bb21e3d4f  vmovaps [rsp+0x50], xmm5
00007d0bb21e3d55  vmovaps [rsp+0x60], xmm6
00007d0bb21e3d5b  vmovaps [rsp+0x70], xmm7
00007d0bb21e3d61  vmovaps [rsp+0x80], xmm8
00007d0bb21e3d6a  vmovaps [rsp+0x90], xmm9
00007d0bb21e3d73  vmovaps [rsp+0xA0], xmm10
00007d0bb21e3d7c  vmovaps [rsp+0xB0], xmm12
00007d0bb21e3d85  vmovaps [rsp+0xC0], xmm13
00007d0bb21e3d8e  vmovaps [rsp+0xD0], xmm14
00007d0bb21e3d97  vmovaps [rsp+0xE0], xmm15
00007d0bb21e3da0  sub rsp, 0x30
00007d0bb21e3da4  movaps [rsp], xmm11
00007d0bb21e3da9  movaps [rsp+0x10], xmm10
00007d0bb21e3daf  movaps [rsp+0x20], xmm14
00007d0bb21e3db5  lea rdi, [rsp]
00007d0bb21e3db9  mov esi, 0x00
00007d0bb21e3dbe  mov rax, 0x6392BBE7F530
00007d0bb21e3dc8  call rax
00007d0bb21e3dca  movaps xmm11, [rsp]
00007d0bb21e3dcf  add rsp, 0x30
00007d0bb21e3dd3  vmovaps xmm0, [rsp]
00007d0bb21e3dd8  vmovaps xmm1, [rsp+0x10]
00007d0bb21e3dde  vmovaps xmm2, [rsp+0x20]
00007d0bb21e3de4  vmovaps xmm3, [rsp+0x30]
00007d0bb21e3dea  vmovaps xmm4, [rsp+0x40]
00007d0bb21e3df0  vmovaps xmm5, [rsp+0x50]
00007d0bb21e3df6  vmovaps xmm6, [rsp+0x60]
00007d0bb21e3dfc  vmovaps xmm7, [rsp+0x70]
00007d0bb21e3e02  vmovaps xmm8, [rsp+0x80]
00007d0bb21e3e0b  vmovaps xmm9, [rsp+0x90]
00007d0bb21e3e14  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e3e1d  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e3e26  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e3e2f  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e3e38  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e3e41  add rsp, 0xF0
00007d0bb21e3e48  pop r11
00007d0bb21e3e4a  pop r10
00007d0bb21e3e4c  pop r9
00007d0bb21e3e4e  pop r8
00007d0bb21e3e50  pop rsi
00007d0bb21e3e51  pop rdi
00007d0bb21e3e52  pop rdx
00007d0bb21e3e53  pop rcx
00007d0bb21e3e54  pop rax
00007d0bb21e3e55  add rsp, 0x08
00007d0bb21e3e59  jmp 0x00007D0BB21DF880
00007d0bb21e3e5e  call 0x00007D0BB20C33A0
00007d0bb21e3e63  jmp 0x00007D0BB21DF88A
00007d0bb21e3e68  sub rsp, 0x08
00007d0bb21e3e6c  push rax
00007d0bb21e3e6d  push rcx
00007d0bb21e3e6e  push rdx
00007d0bb21e3e6f  push rdi
00007d0bb21e3e70  push rsi
00007d0bb21e3e71  push r8
00007d0bb21e3e73  push r9
00007d0bb21e3e75  push r10
00007d0bb21e3e77  push r11
00007d0bb21e3e79  sub rsp, 0xF0
00007d0bb21e3e80  vmovaps [rsp], xmm0
00007d0bb21e3e85  vmovaps [rsp+0x10], xmm1
00007d0bb21e3e8b  vmovaps [rsp+0x20], xmm2
00007d0bb21e3e91  vmovaps [rsp+0x30], xmm3
00007d0bb21e3e97  vmovaps [rsp+0x40], xmm4
00007d0bb21e3e9d  vmovaps [rsp+0x50], xmm5
00007d0bb21e3ea3  vmovaps [rsp+0x60], xmm6
00007d0bb21e3ea9  vmovaps [rsp+0x70], xmm7
00007d0bb21e3eaf  vmovaps [rsp+0x80], xmm8
00007d0bb21e3eb8  vmovaps [rsp+0x90], xmm9
00007d0bb21e3ec1  vmovaps [rsp+0xA0], xmm11
00007d0bb21e3eca  vmovaps [rsp+0xB0], xmm12
00007d0bb21e3ed3  vmovaps [rsp+0xC0], xmm13
00007d0bb21e3edc  vmovaps [rsp+0xD0], xmm14
00007d0bb21e3ee5  vmovaps [rsp+0xE0], xmm15
00007d0bb21e3eee  sub rsp, 0x30
00007d0bb21e3ef2  movaps [rsp], xmm10
00007d0bb21e3ef7  movaps [rsp+0x10], xmm1
00007d0bb21e3efc  movaps [rsp+0x20], xmm12
00007d0bb21e3f02  lea rdi, [rsp]
00007d0bb21e3f06  mov esi, 0x00
00007d0bb21e3f0b  mov rax, 0x6392BBE7F530
00007d0bb21e3f15  call rax
00007d0bb21e3f17  movaps xmm10, [rsp]
00007d0bb21e3f1c  add rsp, 0x30
00007d0bb21e3f20  vmovaps xmm0, [rsp]
00007d0bb21e3f25  vmovaps xmm1, [rsp+0x10]
00007d0bb21e3f2b  vmovaps xmm2, [rsp+0x20]
00007d0bb21e3f31  vmovaps xmm3, [rsp+0x30]
00007d0bb21e3f37  vmovaps xmm4, [rsp+0x40]
00007d0bb21e3f3d  vmovaps xmm5, [rsp+0x50]
00007d0bb21e3f43  vmovaps xmm6, [rsp+0x60]
00007d0bb21e3f49  vmovaps xmm7, [rsp+0x70]
00007d0bb21e3f4f  vmovaps xmm8, [rsp+0x80]
00007d0bb21e3f58  vmovaps xmm9, [rsp+0x90]
00007d0bb21e3f61  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e3f6a  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e3f73  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e3f7c  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e3f85  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e3f8e  add rsp, 0xF0
00007d0bb21e3f95  pop r11
00007d0bb21e3f97  pop r10
00007d0bb21e3f99  pop r9
00007d0bb21e3f9b  pop r8
00007d0bb21e3f9d  pop rsi
00007d0bb21e3f9e  pop rdi
00007d0bb21e3f9f  pop rdx
00007d0bb21e3fa0  pop rcx
00007d0bb21e3fa1  pop rax
00007d0bb21e3fa2  add rsp, 0x08
00007d0bb21e3fa6  jmp 0x00007D0BB21DF8AD
00007d0bb21e3fab  sub rsp, 0x08
00007d0bb21e3faf  push rax
00007d0bb21e3fb0  push rcx
00007d0bb21e3fb1  push rdx
00007d0bb21e3fb2  push rdi
00007d0bb21e3fb3  push rsi
00007d0bb21e3fb4  push r8
00007d0bb21e3fb6  push r9
00007d0bb21e3fb8  push r10
00007d0bb21e3fba  push r11
00007d0bb21e3fbc  sub rsp, 0xF0
00007d0bb21e3fc3  vmovaps [rsp], xmm0
00007d0bb21e3fc8  vmovaps [rsp+0x10], xmm1
00007d0bb21e3fce  vmovaps [rsp+0x20], xmm2
00007d0bb21e3fd4  vmovaps [rsp+0x30], xmm3
00007d0bb21e3fda  vmovaps [rsp+0x40], xmm4
00007d0bb21e3fe0  vmovaps [rsp+0x50], xmm5
00007d0bb21e3fe6  vmovaps [rsp+0x60], xmm6
00007d0bb21e3fec  vmovaps [rsp+0x70], xmm7
00007d0bb21e3ff2  vmovaps [rsp+0x80], xmm8
00007d0bb21e3ffb  vmovaps [rsp+0x90], xmm9
00007d0bb21e4004  vmovaps [rsp+0xA0], xmm10
00007d0bb21e400d  vmovaps [rsp+0xB0], xmm11
00007d0bb21e4016  vmovaps [rsp+0xC0], xmm13
00007d0bb21e401f  vmovaps [rsp+0xD0], xmm14
00007d0bb21e4028  vmovaps [rsp+0xE0], xmm15
00007d0bb21e4031  sub rsp, 0x30
00007d0bb21e4035  movaps [rsp], xmm12
00007d0bb21e403a  movaps [rsp+0x10], xmm14
00007d0bb21e4040  movaps [rsp+0x20], xmm1
00007d0bb21e4045  lea rdi, [rsp]
00007d0bb21e4049  mov esi, 0x00
00007d0bb21e404e  mov rax, 0x6392BBE7F530
00007d0bb21e4058  call rax
00007d0bb21e405a  movaps xmm12, [rsp]
00007d0bb21e405f  add rsp, 0x30
00007d0bb21e4063  vmovaps xmm0, [rsp]
00007d0bb21e4068  vmovaps xmm1, [rsp+0x10]
00007d0bb21e406e  vmovaps xmm2, [rsp+0x20]
00007d0bb21e4074  vmovaps xmm3, [rsp+0x30]
00007d0bb21e407a  vmovaps xmm4, [rsp+0x40]
00007d0bb21e4080  vmovaps xmm5, [rsp+0x50]
00007d0bb21e4086  vmovaps xmm6, [rsp+0x60]
00007d0bb21e408c  vmovaps xmm7, [rsp+0x70]
00007d0bb21e4092  vmovaps xmm8, [rsp+0x80]
00007d0bb21e409b  vmovaps xmm9, [rsp+0x90]
00007d0bb21e40a4  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e40ad  vmovaps xmm11, [rsp+0xB0]
00007d0bb21e40b6  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e40bf  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e40c8  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e40d1  add rsp, 0xF0
00007d0bb21e40d8  pop r11
00007d0bb21e40da  pop r10
00007d0bb21e40dc  pop r9
00007d0bb21e40de  pop r8
00007d0bb21e40e0  pop rsi
00007d0bb21e40e1  pop rdi
00007d0bb21e40e2  pop rdx
00007d0bb21e40e3  pop rcx
00007d0bb21e40e4  pop rax
00007d0bb21e40e5  add rsp, 0x08
00007d0bb21e40e9  jmp 0x00007D0BB21DF8DC
00007d0bb21e40ee  sub rsp, 0x08
00007d0bb21e40f2  push rax
00007d0bb21e40f3  push rcx
00007d0bb21e40f4  push rdx
00007d0bb21e40f5  push rdi
00007d0bb21e40f6  push rsi
00007d0bb21e40f7  push r8
00007d0bb21e40f9  push r9
00007d0bb21e40fb  push r10
00007d0bb21e40fd  push r11
00007d0bb21e40ff  sub rsp, 0xF0
00007d0bb21e4106  vmovaps [rsp], xmm0
00007d0bb21e410b  vmovaps [rsp+0x10], xmm1
00007d0bb21e4111  vmovaps [rsp+0x20], xmm2
00007d0bb21e4117  vmovaps [rsp+0x30], xmm3
00007d0bb21e411d  vmovaps [rsp+0x40], xmm4
00007d0bb21e4123  vmovaps [rsp+0x50], xmm5
00007d0bb21e4129  vmovaps [rsp+0x60], xmm6
00007d0bb21e412f  vmovaps [rsp+0x70], xmm7
00007d0bb21e4135  vmovaps [rsp+0x80], xmm8
00007d0bb21e413e  vmovaps [rsp+0x90], xmm9
00007d0bb21e4147  vmovaps [rsp+0xA0], xmm10
00007d0bb21e4150  vmovaps [rsp+0xB0], xmm11
00007d0bb21e4159  vmovaps [rsp+0xC0], xmm12
00007d0bb21e4162  vmovaps [rsp+0xD0], xmm13
00007d0bb21e416b  vmovaps [rsp+0xE0], xmm15
00007d0bb21e4174  sub rsp, 0x30
00007d0bb21e4178  movaps [rsp], xmm14
00007d0bb21e417d  movaps [rsp+0x10], xmm9
00007d0bb21e4183  movaps [rsp+0x20], xmm1
00007d0bb21e4188  lea rdi, [rsp]
00007d0bb21e418c  mov esi, 0x00
00007d0bb21e4191  mov rax, 0x6392BBE7F530
00007d0bb21e419b  call rax
00007d0bb21e419d  movaps xmm14, [rsp]
00007d0bb21e41a2  add rsp, 0x30
00007d0bb21e41a6  vmovaps xmm0, [rsp]
00007d0bb21e41ab  vmovaps xmm1, [rsp+0x10]
00007d0bb21e41b1  vmovaps xmm2, [rsp+0x20]
00007d0bb21e41b7  vmovaps xmm3, [rsp+0x30]
00007d0bb21e41bd  vmovaps xmm4, [rsp+0x40]
00007d0bb21e41c3  vmovaps xmm5, [rsp+0x50]
00007d0bb21e41c9  vmovaps xmm6, [rsp+0x60]
00007d0bb21e41cf  vmovaps xmm7, [rsp+0x70]
00007d0bb21e41d5  vmovaps xmm8, [rsp+0x80]
00007d0bb21e41de  vmovaps xmm9, [rsp+0x90]
00007d0bb21e41e7  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e41f0  vmovaps xmm11, [rsp+0xB0]
00007d0bb21e41f9  vmovaps xmm12, [rsp+0xC0]
00007d0bb21e4202  vmovaps xmm13, [rsp+0xD0]
00007d0bb21e420b  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e4214  add rsp, 0xF0
00007d0bb21e421b  pop r11
00007d0bb21e421d  pop r10
00007d0bb21e421f  pop r9
00007d0bb21e4221  pop r8
00007d0bb21e4223  pop rsi
00007d0bb21e4224  pop rdi
00007d0bb21e4225  pop rdx
00007d0bb21e4226  pop rcx
00007d0bb21e4227  pop rax
00007d0bb21e4228  add rsp, 0x08
00007d0bb21e422c  jmp 0x00007D0BB21DF90B
00007d0bb21e4231  sub rsp, 0x08
00007d0bb21e4235  push rax
00007d0bb21e4236  push rcx
00007d0bb21e4237  push rdx
00007d0bb21e4238  push rdi
00007d0bb21e4239  push rsi
00007d0bb21e423a  push r8
00007d0bb21e423c  push r9
00007d0bb21e423e  push r10
00007d0bb21e4240  push r11
00007d0bb21e4242  sub rsp, 0xF0
00007d0bb21e4249  vmovaps [rsp], xmm0
00007d0bb21e424e  vmovaps [rsp+0x10], xmm2
00007d0bb21e4254  vmovaps [rsp+0x20], xmm3
00007d0bb21e425a  vmovaps [rsp+0x30], xmm4
00007d0bb21e4260  vmovaps [rsp+0x40], xmm5
00007d0bb21e4266  vmovaps [rsp+0x50], xmm6
00007d0bb21e426c  vmovaps [rsp+0x60], xmm7
00007d0bb21e4272  vmovaps [rsp+0x70], xmm8
00007d0bb21e4278  vmovaps [rsp+0x80], xmm9
00007d0bb21e4281  vmovaps [rsp+0x90], xmm10
00007d0bb21e428a  vmovaps [rsp+0xA0], xmm11
00007d0bb21e4293  vmovaps [rsp+0xB0], xmm12
00007d0bb21e429c  vmovaps [rsp+0xC0], xmm13
00007d0bb21e42a5  vmovaps [rsp+0xD0], xmm14
00007d0bb21e42ae  vmovaps [rsp+0xE0], xmm15
00007d0bb21e42b7  sub rsp, 0x30
00007d0bb21e42bb  movaps [rsp], xmm1
00007d0bb21e42bf  movaps [rsp+0x10], xmm13
00007d0bb21e42c5  movaps [rsp+0x20], xmm8
00007d0bb21e42cb  lea rdi, [rsp]
00007d0bb21e42cf  mov esi, 0x00
00007d0bb21e42d4  mov rax, 0x6392BBE7F530
00007d0bb21e42de  call rax
00007d0bb21e42e0  movaps xmm1, [rsp]
00007d0bb21e42e4  add rsp, 0x30
00007d0bb21e42e8  vmovaps xmm0, [rsp]
00007d0bb21e42ed  vmovaps xmm2, [rsp+0x10]
00007d0bb21e42f3  vmovaps xmm3, [rsp+0x20]
00007d0bb21e42f9  vmovaps xmm4, [rsp+0x30]
00007d0bb21e42ff  vmovaps xmm5, [rsp+0x40]
00007d0bb21e4305  vmovaps xmm6, [rsp+0x50]
00007d0bb21e430b  vmovaps xmm7, [rsp+0x60]
00007d0bb21e4311  vmovaps xmm8, [rsp+0x70]
00007d0bb21e4317  vmovaps xmm9, [rsp+0x80]
00007d0bb21e4320  vmovaps xmm10, [rsp+0x90]
00007d0bb21e4329  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e4332  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e433b  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e4344  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e434d  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e4356  add rsp, 0xF0
00007d0bb21e435d  pop r11
00007d0bb21e435f  pop r10
00007d0bb21e4361  pop r9
00007d0bb21e4363  pop r8
00007d0bb21e4365  pop rsi
00007d0bb21e4366  pop rdi
00007d0bb21e4367  pop rdx
00007d0bb21e4368  pop rcx
00007d0bb21e4369  pop rax
00007d0bb21e436a  add rsp, 0x08
00007d0bb21e436e  jmp 0x00007D0BB21DF92D
00007d0bb21e4373  call 0x00007D0BB200C260
00007d0bb21e4378  jmp 0x00007D0BB21DF93B
00007d0bb21e437d  call 0x00007D0BB20BD750
00007d0bb21e4382  jmp 0x00007D0BB21DF945
00007d0bb21e4387  sub rsp, 0x08
00007d0bb21e438b  push rax
00007d0bb21e438c  push rcx
00007d0bb21e438d  push rdx
00007d0bb21e438e  push rdi
00007d0bb21e438f  push rsi
00007d0bb21e4390  push r8
00007d0bb21e4392  push r9
00007d0bb21e4394  push r10
00007d0bb21e4396  push r11
00007d0bb21e4398  sub rsp, 0xF0
00007d0bb21e439f  vmovaps [rsp], xmm0
00007d0bb21e43a4  vmovaps [rsp+0x10], xmm1
00007d0bb21e43aa  vmovaps [rsp+0x20], xmm2
00007d0bb21e43b0  vmovaps [rsp+0x30], xmm3
00007d0bb21e43b6  vmovaps [rsp+0x40], xmm4
00007d0bb21e43bc  vmovaps [rsp+0x50], xmm5
00007d0bb21e43c2  vmovaps [rsp+0x60], xmm6
00007d0bb21e43c8  vmovaps [rsp+0x70], xmm7
00007d0bb21e43ce  vmovaps [rsp+0x80], xmm9
00007d0bb21e43d7  vmovaps [rsp+0x90], xmm10
00007d0bb21e43e0  vmovaps [rsp+0xA0], xmm11
00007d0bb21e43e9  vmovaps [rsp+0xB0], xmm12
00007d0bb21e43f2  vmovaps [rsp+0xC0], xmm13
00007d0bb21e43fb  vmovaps [rsp+0xD0], xmm14
00007d0bb21e4404  vmovaps [rsp+0xE0], xmm15
00007d0bb21e440d  sub rsp, 0x30
00007d0bb21e4411  movaps [rsp], xmm8
00007d0bb21e4416  movaps [rsp+0x10], xmm15
00007d0bb21e441c  movaps [rsp+0x20], xmm7
00007d0bb21e4421  lea rdi, [rsp]
00007d0bb21e4425  mov esi, 0x00
00007d0bb21e442a  mov rax, 0x6392BBE7F530
00007d0bb21e4434  call rax
00007d0bb21e4436  movaps xmm8, [rsp]
00007d0bb21e443b  add rsp, 0x30
00007d0bb21e443f  vmovaps xmm0, [rsp]
00007d0bb21e4444  vmovaps xmm1, [rsp+0x10]
00007d0bb21e444a  vmovaps xmm2, [rsp+0x20]
00007d0bb21e4450  vmovaps xmm3, [rsp+0x30]
00007d0bb21e4456  vmovaps xmm4, [rsp+0x40]
00007d0bb21e445c  vmovaps xmm5, [rsp+0x50]
00007d0bb21e4462  vmovaps xmm6, [rsp+0x60]
00007d0bb21e4468  vmovaps xmm7, [rsp+0x70]
00007d0bb21e446e  vmovaps xmm9, [rsp+0x80]
00007d0bb21e4477  vmovaps xmm10, [rsp+0x90]
00007d0bb21e4480  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e4489  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e4492  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e449b  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e44a4  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e44ad  add rsp, 0xF0
00007d0bb21e44b4  pop r11
00007d0bb21e44b6  pop r10
00007d0bb21e44b8  pop r9
00007d0bb21e44ba  pop r8
00007d0bb21e44bc  pop rsi
00007d0bb21e44bd  pop rdi
00007d0bb21e44be  pop rdx
00007d0bb21e44bf  pop rcx
00007d0bb21e44c0  pop rax
00007d0bb21e44c1  add rsp, 0x08
00007d0bb21e44c5  jmp 0x00007D0BB21DF967
00007d0bb21e44ca  sub rsp, 0x08
00007d0bb21e44ce  push rax
00007d0bb21e44cf  push rcx
00007d0bb21e44d0  push rdx
00007d0bb21e44d1  push rdi
00007d0bb21e44d2  push rsi
00007d0bb21e44d3  push r8
00007d0bb21e44d5  push r9
00007d0bb21e44d7  push r10
00007d0bb21e44d9  push r11
00007d0bb21e44db  sub rsp, 0xF0
00007d0bb21e44e2  vmovaps [rsp], xmm0
00007d0bb21e44e7  vmovaps [rsp+0x10], xmm1
00007d0bb21e44ed  vmovaps [rsp+0x20], xmm2
00007d0bb21e44f3  vmovaps [rsp+0x30], xmm3
00007d0bb21e44f9  vmovaps [rsp+0x40], xmm4
00007d0bb21e44ff  vmovaps [rsp+0x50], xmm5
00007d0bb21e4505  vmovaps [rsp+0x60], xmm6
00007d0bb21e450b  vmovaps [rsp+0x70], xmm8
00007d0bb21e4511  vmovaps [rsp+0x80], xmm9
00007d0bb21e451a  vmovaps [rsp+0x90], xmm10
00007d0bb21e4523  vmovaps [rsp+0xA0], xmm11
00007d0bb21e452c  vmovaps [rsp+0xB0], xmm12
00007d0bb21e4535  vmovaps [rsp+0xC0], xmm13
00007d0bb21e453e  vmovaps [rsp+0xD0], xmm14
00007d0bb21e4547  vmovaps [rsp+0xE0], xmm15
00007d0bb21e4550  sub rsp, 0x30
00007d0bb21e4554  movaps [rsp], xmm7
00007d0bb21e4558  movaps [rsp+0x10], xmm9
00007d0bb21e455e  movaps [rsp+0x20], xmm15
00007d0bb21e4564  lea rdi, [rsp]
00007d0bb21e4568  mov esi, 0x00
00007d0bb21e456d  mov rax, 0x6392BBE7F530
00007d0bb21e4577  call rax
00007d0bb21e4579  movaps xmm7, [rsp]
00007d0bb21e457d  add rsp, 0x30
00007d0bb21e4581  vmovaps xmm0, [rsp]
00007d0bb21e4586  vmovaps xmm1, [rsp+0x10]
00007d0bb21e458c  vmovaps xmm2, [rsp+0x20]
00007d0bb21e4592  vmovaps xmm3, [rsp+0x30]
00007d0bb21e4598  vmovaps xmm4, [rsp+0x40]
00007d0bb21e459e  vmovaps xmm5, [rsp+0x50]
00007d0bb21e45a4  vmovaps xmm6, [rsp+0x60]
00007d0bb21e45aa  vmovaps xmm8, [rsp+0x70]
00007d0bb21e45b0  vmovaps xmm9, [rsp+0x80]
00007d0bb21e45b9  vmovaps xmm10, [rsp+0x90]
00007d0bb21e45c2  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e45cb  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e45d4  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e45dd  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e45e6  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e45ef  add rsp, 0xF0
00007d0bb21e45f6  pop r11
00007d0bb21e45f8  pop r10
00007d0bb21e45fa  pop r9
00007d0bb21e45fc  pop r8
00007d0bb21e45fe  pop rsi
00007d0bb21e45ff  pop rdi
00007d0bb21e4600  pop rdx
00007d0bb21e4601  pop rcx
00007d0bb21e4602  pop rax
00007d0bb21e4603  add rsp, 0x08
00007d0bb21e4607  jmp 0x00007D0BB21DF994
00007d0bb21e460c  sub rsp, 0x08
00007d0bb21e4610  push rax
00007d0bb21e4611  push rcx
00007d0bb21e4612  push rdx
00007d0bb21e4613  push rdi
00007d0bb21e4614  push rsi
00007d0bb21e4615  push r8
00007d0bb21e4617  push r9
00007d0bb21e4619  push r10
00007d0bb21e461b  push r11
00007d0bb21e461d  sub rsp, 0xF0
00007d0bb21e4624  vmovaps [rsp], xmm0
00007d0bb21e4629  vmovaps [rsp+0x10], xmm1
00007d0bb21e462f  vmovaps [rsp+0x20], xmm2
00007d0bb21e4635  vmovaps [rsp+0x30], xmm3
00007d0bb21e463b  vmovaps [rsp+0x40], xmm4
00007d0bb21e4641  vmovaps [rsp+0x50], xmm5
00007d0bb21e4647  vmovaps [rsp+0x60], xmm6
00007d0bb21e464d  vmovaps [rsp+0x70], xmm7
00007d0bb21e4653  vmovaps [rsp+0x80], xmm8
00007d0bb21e465c  vmovaps [rsp+0x90], xmm10
00007d0bb21e4665  vmovaps [rsp+0xA0], xmm11
00007d0bb21e466e  vmovaps [rsp+0xB0], xmm12
00007d0bb21e4677  vmovaps [rsp+0xC0], xmm13
00007d0bb21e4680  vmovaps [rsp+0xD0], xmm14
00007d0bb21e4689  vmovaps [rsp+0xE0], xmm15
00007d0bb21e4692  sub rsp, 0x30
00007d0bb21e4696  movaps [rsp], xmm9
00007d0bb21e469b  movaps [rsp+0x10], xmm13
00007d0bb21e46a1  movaps [rsp+0x20], xmm15
00007d0bb21e46a7  lea rdi, [rsp]
00007d0bb21e46ab  mov esi, 0x00
00007d0bb21e46b0  mov rax, 0x6392BBE7F530
00007d0bb21e46ba  call rax
00007d0bb21e46bc  movaps xmm9, [rsp]
00007d0bb21e46c1  add rsp, 0x30
00007d0bb21e46c5  vmovaps xmm0, [rsp]
00007d0bb21e46ca  vmovaps xmm1, [rsp+0x10]
00007d0bb21e46d0  vmovaps xmm2, [rsp+0x20]
00007d0bb21e46d6  vmovaps xmm3, [rsp+0x30]
00007d0bb21e46dc  vmovaps xmm4, [rsp+0x40]
00007d0bb21e46e2  vmovaps xmm5, [rsp+0x50]
00007d0bb21e46e8  vmovaps xmm6, [rsp+0x60]
00007d0bb21e46ee  vmovaps xmm7, [rsp+0x70]
00007d0bb21e46f4  vmovaps xmm8, [rsp+0x80]
00007d0bb21e46fd  vmovaps xmm10, [rsp+0x90]
00007d0bb21e4706  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e470f  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e4718  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e4721  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e472a  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e4733  add rsp, 0xF0
00007d0bb21e473a  pop r11
00007d0bb21e473c  pop r10
00007d0bb21e473e  pop r9
00007d0bb21e4740  pop r8
00007d0bb21e4742  pop rsi
00007d0bb21e4743  pop rdi
00007d0bb21e4744  pop rdx
00007d0bb21e4745  pop rcx
00007d0bb21e4746  pop rax
00007d0bb21e4747  add rsp, 0x08
00007d0bb21e474b  jmp 0x00007D0BB21DF9C2
00007d0bb21e4750  sub rsp, 0x08
00007d0bb21e4754  push rax
00007d0bb21e4755  push rcx
00007d0bb21e4756  push rdx
00007d0bb21e4757  push rdi
00007d0bb21e4758  push rsi
00007d0bb21e4759  push r8
00007d0bb21e475b  push r9
00007d0bb21e475d  push r10
00007d0bb21e475f  push r11
00007d0bb21e4761  sub rsp, 0xF0
00007d0bb21e4768  vmovaps [rsp], xmm0
00007d0bb21e476d  vmovaps [rsp+0x10], xmm1
00007d0bb21e4773  vmovaps [rsp+0x20], xmm2
00007d0bb21e4779  vmovaps [rsp+0x30], xmm3
00007d0bb21e477f  vmovaps [rsp+0x40], xmm4
00007d0bb21e4785  vmovaps [rsp+0x50], xmm5
00007d0bb21e478b  vmovaps [rsp+0x60], xmm6
00007d0bb21e4791  vmovaps [rsp+0x70], xmm7
00007d0bb21e4797  vmovaps [rsp+0x80], xmm8
00007d0bb21e47a0  vmovaps [rsp+0x90], xmm9
00007d0bb21e47a9  vmovaps [rsp+0xA0], xmm10
00007d0bb21e47b2  vmovaps [rsp+0xB0], xmm11
00007d0bb21e47bb  vmovaps [rsp+0xC0], xmm12
00007d0bb21e47c4  vmovaps [rsp+0xD0], xmm13
00007d0bb21e47cd  vmovaps [rsp+0xE0], xmm14
00007d0bb21e47d6  sub rsp, 0x30
00007d0bb21e47da  movaps [rsp], xmm15
00007d0bb21e47df  movaps [rsp+0x10], xmm11
00007d0bb21e47e5  movaps [rsp+0x20], xmm12
00007d0bb21e47eb  lea rdi, [rsp]
00007d0bb21e47ef  mov esi, 0x00
00007d0bb21e47f4  mov rax, 0x6392BBE7F530
00007d0bb21e47fe  call rax
00007d0bb21e4800  movaps xmm15, [rsp]
00007d0bb21e4805  add rsp, 0x30
00007d0bb21e4809  vmovaps xmm0, [rsp]
00007d0bb21e480e  vmovaps xmm1, [rsp+0x10]
00007d0bb21e4814  vmovaps xmm2, [rsp+0x20]
00007d0bb21e481a  vmovaps xmm3, [rsp+0x30]
00007d0bb21e4820  vmovaps xmm4, [rsp+0x40]
00007d0bb21e4826  vmovaps xmm5, [rsp+0x50]
00007d0bb21e482c  vmovaps xmm6, [rsp+0x60]
00007d0bb21e4832  vmovaps xmm7, [rsp+0x70]
00007d0bb21e4838  vmovaps xmm8, [rsp+0x80]
00007d0bb21e4841  vmovaps xmm9, [rsp+0x90]
00007d0bb21e484a  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e4853  vmovaps xmm11, [rsp+0xB0]
00007d0bb21e485c  vmovaps xmm12, [rsp+0xC0]
00007d0bb21e4865  vmovaps xmm13, [rsp+0xD0]
00007d0bb21e486e  vmovaps xmm14, [rsp+0xE0]
00007d0bb21e4877  add rsp, 0xF0
00007d0bb21e487e  pop r11
00007d0bb21e4880  pop r10
00007d0bb21e4882  pop r9
00007d0bb21e4884  pop r8
00007d0bb21e4886  pop rsi
00007d0bb21e4887  pop rdi
00007d0bb21e4888  pop rdx
00007d0bb21e4889  pop rcx
00007d0bb21e488a  pop rax
00007d0bb21e488b  add rsp, 0x08
00007d0bb21e488f  jmp 0x00007D0BB21DF9DD
00007d0bb21e4894  sub rsp, 0x08
00007d0bb21e4898  push rax
00007d0bb21e4899  push rcx
00007d0bb21e489a  push rdx
00007d0bb21e489b  push rdi
00007d0bb21e489c  push rsi
00007d0bb21e489d  push r8
00007d0bb21e489f  push r9
00007d0bb21e48a1  push r10
00007d0bb21e48a3  push r11
00007d0bb21e48a5  sub rsp, 0xF0
00007d0bb21e48ac  vmovaps [rsp], xmm0
00007d0bb21e48b1  vmovaps [rsp+0x10], xmm1
00007d0bb21e48b7  vmovaps [rsp+0x20], xmm2
00007d0bb21e48bd  vmovaps [rsp+0x30], xmm3
00007d0bb21e48c3  vmovaps [rsp+0x40], xmm4
00007d0bb21e48c9  vmovaps [rsp+0x50], xmm5
00007d0bb21e48cf  vmovaps [rsp+0x60], xmm6
00007d0bb21e48d5  vmovaps [rsp+0x70], xmm7
00007d0bb21e48db  vmovaps [rsp+0x80], xmm8
00007d0bb21e48e4  vmovaps [rsp+0x90], xmm9
00007d0bb21e48ed  vmovaps [rsp+0xA0], xmm10
00007d0bb21e48f6  vmovaps [rsp+0xB0], xmm11
00007d0bb21e48ff  vmovaps [rsp+0xC0], xmm12
00007d0bb21e4908  vmovaps [rsp+0xD0], xmm14
00007d0bb21e4911  vmovaps [rsp+0xE0], xmm15
00007d0bb21e491a  sub rsp, 0x30
00007d0bb21e491e  movaps [rsp], xmm13
00007d0bb21e4923  movaps [rsp+0x10], xmm10
00007d0bb21e4929  movaps [rsp+0x20], xmm14
00007d0bb21e492f  lea rdi, [rsp]
00007d0bb21e4933  mov esi, 0x00
00007d0bb21e4938  mov rax, 0x6392BBE7F530
00007d0bb21e4942  call rax
00007d0bb21e4944  movaps xmm13, [rsp]
00007d0bb21e4949  add rsp, 0x30
00007d0bb21e494d  vmovaps xmm0, [rsp]
00007d0bb21e4952  vmovaps xmm1, [rsp+0x10]
00007d0bb21e4958  vmovaps xmm2, [rsp+0x20]
00007d0bb21e495e  vmovaps xmm3, [rsp+0x30]
00007d0bb21e4964  vmovaps xmm4, [rsp+0x40]
00007d0bb21e496a  vmovaps xmm5, [rsp+0x50]
00007d0bb21e4970  vmovaps xmm6, [rsp+0x60]
00007d0bb21e4976  vmovaps xmm7, [rsp+0x70]
00007d0bb21e497c  vmovaps xmm8, [rsp+0x80]
00007d0bb21e4985  vmovaps xmm9, [rsp+0x90]
00007d0bb21e498e  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e4997  vmovaps xmm11, [rsp+0xB0]
00007d0bb21e49a0  vmovaps xmm12, [rsp+0xC0]
00007d0bb21e49a9  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e49b2  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e49bb  add rsp, 0xF0
00007d0bb21e49c2  pop r11
00007d0bb21e49c4  pop r10
00007d0bb21e49c6  pop r9
00007d0bb21e49c8  pop r8
00007d0bb21e49ca  pop rsi
00007d0bb21e49cb  pop rdi
00007d0bb21e49cc  pop rdx
00007d0bb21e49cd  pop rcx
00007d0bb21e49ce  pop rax
00007d0bb21e49cf  add rsp, 0x08
00007d0bb21e49d3  jmp 0x00007D0BB21DFA00
00007d0bb21e49d8  sub rsp, 0x08
00007d0bb21e49dc  push rax
00007d0bb21e49dd  push rcx
00007d0bb21e49de  push rdx
00007d0bb21e49df  push rdi
00007d0bb21e49e0  push rsi
00007d0bb21e49e1  push r8
00007d0bb21e49e3  push r9
00007d0bb21e49e5  push r10
00007d0bb21e49e7  push r11
00007d0bb21e49e9  sub rsp, 0xF0
00007d0bb21e49f0  vmovaps [rsp], xmm0
00007d0bb21e49f5  vmovaps [rsp+0x10], xmm1
00007d0bb21e49fb  vmovaps [rsp+0x20], xmm2
00007d0bb21e4a01  vmovaps [rsp+0x30], xmm3
00007d0bb21e4a07  vmovaps [rsp+0x40], xmm4
00007d0bb21e4a0d  vmovaps [rsp+0x50], xmm5
00007d0bb21e4a13  vmovaps [rsp+0x60], xmm6
00007d0bb21e4a19  vmovaps [rsp+0x70], xmm7
00007d0bb21e4a1f  vmovaps [rsp+0x80], xmm8
00007d0bb21e4a28  vmovaps [rsp+0x90], xmm9
00007d0bb21e4a31  vmovaps [rsp+0xA0], xmm10
00007d0bb21e4a3a  vmovaps [rsp+0xB0], xmm11
00007d0bb21e4a43  vmovaps [rsp+0xC0], xmm12
00007d0bb21e4a4c  vmovaps [rsp+0xD0], xmm13
00007d0bb21e4a55  vmovaps [rsp+0xE0], xmm15
00007d0bb21e4a5e  sub rsp, 0x30
00007d0bb21e4a62  movaps [rsp], xmm14
00007d0bb21e4a67  movaps [rsp+0x10], xmm1
00007d0bb21e4a6c  movaps [rsp+0x20], xmm7
00007d0bb21e4a71  lea rdi, [rsp]
00007d0bb21e4a75  mov esi, 0x00
00007d0bb21e4a7a  mov rax, 0x6392BBE7F530
00007d0bb21e4a84  call rax
00007d0bb21e4a86  movaps xmm14, [rsp]
00007d0bb21e4a8b  add rsp, 0x30
00007d0bb21e4a8f  vmovaps xmm0, [rsp]
00007d0bb21e4a94  vmovaps xmm1, [rsp+0x10]
00007d0bb21e4a9a  vmovaps xmm2, [rsp+0x20]
00007d0bb21e4aa0  vmovaps xmm3, [rsp+0x30]
00007d0bb21e4aa6  vmovaps xmm4, [rsp+0x40]
00007d0bb21e4aac  vmovaps xmm5, [rsp+0x50]
00007d0bb21e4ab2  vmovaps xmm6, [rsp+0x60]
00007d0bb21e4ab8  vmovaps xmm7, [rsp+0x70]
00007d0bb21e4abe  vmovaps xmm8, [rsp+0x80]
00007d0bb21e4ac7  vmovaps xmm9, [rsp+0x90]
00007d0bb21e4ad0  vmovaps xmm10, [rsp+0xA0]
00007d0bb21e4ad9  vmovaps xmm11, [rsp+0xB0]
00007d0bb21e4ae2  vmovaps xmm12, [rsp+0xC0]
00007d0bb21e4aeb  vmovaps xmm13, [rsp+0xD0]
00007d0bb21e4af4  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e4afd  add rsp, 0xF0
00007d0bb21e4b04  pop r11
00007d0bb21e4b06  pop r10
00007d0bb21e4b08  pop r9
00007d0bb21e4b0a  pop r8
00007d0bb21e4b0c  pop rsi
00007d0bb21e4b0d  pop rdi
00007d0bb21e4b0e  pop rdx
00007d0bb21e4b0f  pop rcx
00007d0bb21e4b10  pop rax
00007d0bb21e4b11  add rsp, 0x08
00007d0bb21e4b15  jmp 0x00007D0BB21DFA23
00007d0bb21e4b1a  sub rsp, 0x08
00007d0bb21e4b1e  push rax
00007d0bb21e4b1f  push rcx
00007d0bb21e4b20  push rdx
00007d0bb21e4b21  push rdi
00007d0bb21e4b22  push rsi
00007d0bb21e4b23  push r8
00007d0bb21e4b25  push r9
00007d0bb21e4b27  push r10
00007d0bb21e4b29  push r11
00007d0bb21e4b2b  sub rsp, 0xF0
00007d0bb21e4b32  vmovaps [rsp], xmm0
00007d0bb21e4b37  vmovaps [rsp+0x10], xmm2
00007d0bb21e4b3d  vmovaps [rsp+0x20], xmm3
00007d0bb21e4b43  vmovaps [rsp+0x30], xmm4
00007d0bb21e4b49  vmovaps [rsp+0x40], xmm5
00007d0bb21e4b4f  vmovaps [rsp+0x50], xmm6
00007d0bb21e4b55  vmovaps [rsp+0x60], xmm7
00007d0bb21e4b5b  vmovaps [rsp+0x70], xmm8
00007d0bb21e4b61  vmovaps [rsp+0x80], xmm9
00007d0bb21e4b6a  vmovaps [rsp+0x90], xmm10
00007d0bb21e4b73  vmovaps [rsp+0xA0], xmm11
00007d0bb21e4b7c  vmovaps [rsp+0xB0], xmm12
00007d0bb21e4b85  vmovaps [rsp+0xC0], xmm13
00007d0bb21e4b8e  vmovaps [rsp+0xD0], xmm14
00007d0bb21e4b97  vmovaps [rsp+0xE0], xmm15
00007d0bb21e4ba0  sub rsp, 0x30
00007d0bb21e4ba4  movaps [rsp], xmm1
00007d0bb21e4ba8  movaps [rsp+0x10], xmm8
00007d0bb21e4bae  movaps [rsp+0x20], xmm9
00007d0bb21e4bb4  lea rdi, [rsp]
00007d0bb21e4bb8  mov esi, 0x00
00007d0bb21e4bbd  mov rax, 0x6392BBE7F530
00007d0bb21e4bc7  call rax
00007d0bb21e4bc9  movaps xmm1, [rsp]
00007d0bb21e4bcd  add rsp, 0x30
00007d0bb21e4bd1  vmovaps xmm0, [rsp]
00007d0bb21e4bd6  vmovaps xmm2, [rsp+0x10]
00007d0bb21e4bdc  vmovaps xmm3, [rsp+0x20]
00007d0bb21e4be2  vmovaps xmm4, [rsp+0x30]
00007d0bb21e4be8  vmovaps xmm5, [rsp+0x40]
00007d0bb21e4bee  vmovaps xmm6, [rsp+0x50]
00007d0bb21e4bf4  vmovaps xmm7, [rsp+0x60]
00007d0bb21e4bfa  vmovaps xmm8, [rsp+0x70]
00007d0bb21e4c00  vmovaps xmm9, [rsp+0x80]
00007d0bb21e4c09  vmovaps xmm10, [rsp+0x90]
00007d0bb21e4c12  vmovaps xmm11, [rsp+0xA0]
00007d0bb21e4c1b  vmovaps xmm12, [rsp+0xB0]
00007d0bb21e4c24  vmovaps xmm13, [rsp+0xC0]
00007d0bb21e4c2d  vmovaps xmm14, [rsp+0xD0]
00007d0bb21e4c36  vmovaps xmm15, [rsp+0xE0]
00007d0bb21e4c3f  add rsp, 0xF0
00007d0bb21e4c46  pop r11
00007d0bb21e4c48  pop r10
00007d0bb21e4c4a  pop r9
00007d0bb21e4c4c  pop r8
00007d0bb21e4c4e  pop rsi
00007d0bb21e4c4f  pop rdi
00007d0bb21e4c50  pop rdx
00007d0bb21e4c51  pop rcx
00007d0bb21e4c52  pop rax
00007d0bb21e4c53  add rsp, 0x08
00007d0bb21e4c57  jmp 0x00007D0BB21DFA45
00007d0bb21e4c5c  call 0x00007D0BB20E5940
00007d0bb21e4c61  jmp 0x00007D0BB21DFA53
00007d0bb21e4c66  call 0x00007D0BB200C380
00007d0bb21e4c6b  jmp 0x00007D0BB21DFA5D
00007d0bb21e4c70  call 0x00007D0BB200D600
00007d0bb21e4c75  jmp 0x00007D0BB21DFA67
00007d0bb21e4c7a  call 0x00007D0BB1FFF540
00007d0bb21e4c7f  jmp 0x00007D0BB21DFA71
00007d0bb21e4c84  int3
00007d0bb21e4c85  nop [rax+rax*1], ax
00007d0bb21e4c8e  nop
00007d0bb21e4c90  mov qword ptr [r15+0x40], 0x430000
00007d0bb21e4c98  mov eax, 0x430CC0
00007d0bb21e4c9d  mov r14, [r13+rax*1]
00007d0bb21e4ca2  movq xmm1, r14
00007d0bb21e4ca7  mov rax, [r15+0x50]
00007d0bb21e4cab  movups xmm15, [r13+rax*1]
00007d0bb21e4cb1  movaps [r15+0x120], xmm15
00007d0bb21e4cb9  mov qword ptr [r15+0x48], 0x10
00007d0bb21e4cc1  xor eax, eax
00007d0bb21e4cc3  mov r14d, 0x10
00007d0bb21e4cc9  mov r12d, 0x200
00007d0bb21e4ccf  cmp r14, r12
00007d0bb21e4cd2  cmc
00007d0bb21e4cd3  lahf
00007d0bb21e4cd4  seto al
00007d0bb21e4cd7  mov [r15+0x108], eax
00007d0bb21e4cde  pextrq rax, xmm15, 0x01
00007d0bb21e4ce5  movq xmm14, rax
00007d0bb21e4cea  movaps [r15+0x130], xmm14
00007d0bb21e4cf2  movq rax, xmm1
00007d0bb21e4cf7  movq r14, xmm15
00007d0bb21e4cfc  vmovq xmm1, rax
00007d0bb21e4d01  vmovq xmm15, r14
00007d0bb21e4d06  movaps xmm13, xmm1
00007d0bb21e4d0a  addsd xmm13, xmm15
00007d0bb21e4d0f  ucomisd xmm13, xmm13
00007d0bb21e4d14  jp 0x00007D0BB21E4DD3
00007d0bb21e4d1a  movq xmm13, xmm13
00007d0bb21e4d1f  movq rax, xmm13
00007d0bb21e4d24  movq r14, xmm14
00007d0bb21e4d29  vmovq xmm1, rax
00007d0bb21e4d2e  vmovq xmm15, r14
00007d0bb21e4d33  movaps xmm14, xmm1
00007d0bb21e4d37  addsd xmm14, xmm15
00007d0bb21e4d3c  ucomisd xmm14, xmm14
00007d0bb21e4d41  jp 0x00007D0BB21E4E1B
00007d0bb21e4d47  movq xmm14, xmm14
00007d0bb21e4d4c  movaps [r15+0x110], xmm14
00007d0bb21e4d54  mov eax, [r15+0x108]
00007d0bb21e4d5b  sahf
00007d0bb21e4d5c  jnz 0x00007D0BB21E4D8E
00007d0bb21e4d5e  cmp dword ptr [r15+0x318], 0x00
00007d0bb21e4d66  jz 0x00007D0BB21E5030
00007d0bb21e4d6c  nop [rax+rax*1], ax
00007d0bb21e4d75  nop [rax+rax*1], eax
00007d0bb21e4d7d  mov eax, 0x410704
00007d0bb21e4d82  mov [r15+0x100], rax
00007d0bb21e4d89  jmp 0x00007D0BB1FFE110
00007d0bb21e4d8e  cmp dword ptr [r15+0x318], 0x00
00007d0bb21e4d96  jz 0x00007D0BB21E4E70
00007d0bb21e4d9c  nop [rax+rax*1], ax
00007d0bb21e4da5  nop [rax+rax*1], eax
00007d0bb21e4dad  mov eax, 0x4106E8
00007d0bb21e4db2  mov [r15+0x100], rax
00007d0bb21e4db9  jmp 0x00007D0BB1FFE110
00007d0bb21e4dbe  int3
00007d0bb21e4dbf  call 0x00007D0BB200DC20
00007d0bb21e4dc4  jmp 0x00007D0BB21E4CA2
00007d0bb21e4dc9  call 0x00007D0BB200E760
00007d0bb21e4dce  jmp 0x00007D0BB21E4CB1
00007d0bb21e4dd3  ucomisd xmm1, xmm15
00007d0bb21e4dd8  jp 0x00007D0BB21E4DE7
00007d0bb21e4dda  movaps xmm13, [0x00007D0BB1DFE060]
00007d0bb21e4de2  jmp 0x00007D0BB21E4D1A
00007d0bb21e4de7  vxorps xmm0, xmm1, xmm15
00007d0bb21e4dec  pextrw eax, xmm0, 0x03
00007d0bb21e4df1  and eax, 0x7FF8
00007d0bb21e4df6  cmp eax, 0x08
00007d0bb21e4df9  jnz 0x00007D0BB21E4D1A
00007d0bb21e4dff  movq rax, xmm15
00007d0bb21e4e04  shl rax, 0x0D
00007d0bb21e4e08  jbe 0x00007D0BB21E4D1A
00007d0bb21e4e0e  vorps xmm13, xmm15, [0x00007D0BB1DFE070]
00007d0bb21e4e16  jmp 0x00007D0BB21E4D1A
00007d0bb21e4e1b  ucomisd xmm1, xmm15
00007d0bb21e4e20  jp 0x00007D0BB21E4E2F
00007d0bb21e4e22  movaps xmm14, [0x00007D0BB1DFE060]
00007d0bb21e4e2a  jmp 0x00007D0BB21E4D47
00007d0bb21e4e2f  vxorps xmm0, xmm1, xmm15
00007d0bb21e4e34  pextrw eax, xmm0, 0x03
00007d0bb21e4e39  and eax, 0x7FF8
00007d0bb21e4e3e  cmp eax, 0x08
00007d0bb21e4e41  jnz 0x00007D0BB21E4D47
00007d0bb21e4e47  movq rax, xmm15
00007d0bb21e4e4c  shl rax, 0x0D
00007d0bb21e4e50  jbe 0x00007D0BB21E4D47
00007d0bb21e4e56  vorps xmm14, xmm15, [0x00007D0BB1DFE070]
00007d0bb21e4e5e  jmp 0x00007D0BB21E4D47
00007d0bb21e4e63  int3
00007d0bb21e4e64  nop [rax+rax*1], ax
00007d0bb21e4e6d  nop [rax], eax
00007d0bb21e4e70  mov rax, [r15+0x48]
00007d0bb21e4e74  mov r14, [r15+0x50]
00007d0bb21e4e78  lea r12, [r14+rax*1]
00007d0bb21e4e7c  movups xmm1, [r13+r12*1]
00007d0bb21e4e82  movaps [r15+0x120], xmm1
00007d0bb21e4e8a  lea r14, [rax+0x10]
00007d0bb21e4e8e  mov [r15+0x48], r14
00007d0bb21e4e92  xor eax, eax
00007d0bb21e4e94  mov r12d, 0x200
00007d0bb21e4e9a  cmp r14, r12
00007d0bb21e4e9d  cmc
00007d0bb21e4e9e  lahf
00007d0bb21e4e9f  seto al
00007d0bb21e4ea2  mov [r15+0x108], eax
00007d0bb21e4ea9  pextrq rax, xmm1, 0x01
00007d0bb21e4eb0  movq xmm15, rax
00007d0bb21e4eb5  movaps [r15+0x130], xmm15
00007d0bb21e4ebd  movaps xmm14, [r15+0x110]
00007d0bb21e4ec5  movq rax, xmm14
00007d0bb21e4eca  movq r14, xmm1
00007d0bb21e4ecf  vmovq xmm1, rax
00007d0bb21e4ed4  vmovq xmm14, r14
00007d0bb21e4ed9  movaps xmm13, xmm1
00007d0bb21e4edd  addsd xmm13, xmm14
00007d0bb21e4ee2  ucomisd xmm13, xmm13
00007d0bb21e4ee7  jp 0x00007D0BB21E4F9C
00007d0bb21e4eed  movq xmm13, xmm13
00007d0bb21e4ef2  movq rax, xmm13
00007d0bb21e4ef7  movq r14, xmm15
00007d0bb21e4efc  vmovq xmm1, rax
00007d0bb21e4f01  vmovq xmm15, r14
00007d0bb21e4f06  movaps xmm14, xmm1
00007d0bb21e4f0a  addsd xmm14, xmm15
00007d0bb21e4f0f  ucomisd xmm14, xmm14
00007d0bb21e4f14  jp 0x00007D0BB21E4FE4
00007d0bb21e4f1a  movq xmm14, xmm14
00007d0bb21e4f1f  movaps [r15+0x110], xmm14
00007d0bb21e4f27  mov eax, [r15+0x108]
00007d0bb21e4f2e  sahf
00007d0bb21e4f2f  jnz 0x00007D0BB21E4F61
00007d0bb21e4f31  cmp dword ptr [r15+0x318], 0x00
00007d0bb21e4f39  jz 0x00007D0BB21E5030
00007d0bb21e4f3f  nop [rax+rax*1], ax
00007d0bb21e4f48  nop [rax+rax*1], eax
00007d0bb21e4f50  mov eax, 0x410704
00007d0bb21e4f55  mov [r15+0x100], rax
00007d0bb21e4f5c  jmp 0x00007D0BB1FFE110
00007d0bb21e4f61  cmp dword ptr [r15+0x318], 0x00
00007d0bb21e4f69  jz 0x00007D0BB21E4E70
00007d0bb21e4f6f  nop [rax+rax*1], ax
00007d0bb21e4f78  nop [rax+rax*1], eax
00007d0bb21e4f80  mov eax, 0x4106E8
00007d0bb21e4f85  mov [r15+0x100], rax
00007d0bb21e4f8c  jmp 0x00007D0BB1FFE110
00007d0bb21e4f91  int3
00007d0bb21e4f92  call 0x00007D0BB20B52F0
00007d0bb21e4f97  jmp 0x00007D0BB21E4E82
00007d0bb21e4f9c  ucomisd xmm1, xmm14
00007d0bb21e4fa1  jp 0x00007D0BB21E4FB0
00007d0bb21e4fa3  movaps xmm13, [0x00007D0BB1DFE060]
00007d0bb21e4fab  jmp 0x00007D0BB21E4EED
00007d0bb21e4fb0  vxorps xmm0, xmm1, xmm14
00007d0bb21e4fb5  pextrw eax, xmm0, 0x03
00007d0bb21e4fba  and eax, 0x7FF8
00007d0bb21e4fbf  cmp eax, 0x08
00007d0bb21e4fc2  jnz 0x00007D0BB21E4EED
00007d0bb21e4fc8  movq rax, xmm14
00007d0bb21e4fcd  shl rax, 0x0D
00007d0bb21e4fd1  jbe 0x00007D0BB21E4EED
00007d0bb21e4fd7  vorps xmm13, xmm14, [0x00007D0BB1DFE070]
00007d0bb21e4fdf  jmp 0x00007D0BB21E4EED
00007d0bb21e4fe4  ucomisd xmm1, xmm15
00007d0bb21e4fe9  jp 0x00007D0BB21E4FF8
00007d0bb21e4feb  movaps xmm14, [0x00007D0BB1DFE060]
00007d0bb21e4ff3  jmp 0x00007D0BB21E4F1A
00007d0bb21e4ff8  vxorps xmm0, xmm1, xmm15
00007d0bb21e4ffd  pextrw eax, xmm0, 0x03
00007d0bb21e5002  and eax, 0x7FF8
00007d0bb21e5007  cmp eax, 0x08
00007d0bb21e500a  jnz 0x00007D0BB21E4F1A
00007d0bb21e5010  movq rax, xmm15
00007d0bb21e5015  shl rax, 0x0D
00007d0bb21e5019  jbe 0x00007D0BB21E4F1A
00007d0bb21e501f  vorps xmm14, xmm15, [0x00007D0BB1DFE070]
00007d0bb21e5027  jmp 0x00007D0BB21E4F1A
00007d0bb21e502c  int3
00007d0bb21e502d  nop [rax], eax
00007d0bb21e5030  mov rax, [r15+0xF8]
00007d0bb21e5037  lea r14, [rax+0x1D0]
00007d0bb21e503e  mov r12, [r13+r14*1]
00007d0bb21e5043  lea r14, [rax+0x1D8]
00007d0bb21e504a  mov r11, [r13+r14*1]
00007d0bb21e504f  mov [r15+0xA0], r12
00007d0bb21e5056  mov [r15+0x98], r11
00007d0bb21e505d  mov r14, [r15+0x40]
00007d0bb21e5061  lea r12, [r14+0xCC0]
00007d0bb21e5068  movaps xmm1, [r15+0x110]
00007d0bb21e5070  movq r14, xmm1
00007d0bb21e5075  mov [r13+r12*1], r14
00007d0bb21e507a  lea r14, [rax+0x1C0]
00007d0bb21e5081  mov r12, [r13+r14*1]
00007d0bb21e5086  lea r14, [rax+0x1C8]
00007d0bb21e508d  mov r11, [r13+r14*1]
00007d0bb21e5092  mov [r15+0xE8], r12
00007d0bb21e5099  mov [r15+0xF0], r11
00007d0bb21e50a0  lea r14, [rax+0x1B0]
00007d0bb21e50a7  mov r12, [r13+r14*1]
00007d0bb21e50ac  lea r14, [rax+0x1B8]
00007d0bb21e50b3  mov r10, [r13+r14*1]
00007d0bb21e50b8  movq xmm1, r12
00007d0bb21e50bd  movq xmm15, r10
00007d0bb21e50c2  movq xmm1, xmm1
00007d0bb21e50c6  movq xmm1, xmm1
00007d0bb21e50ca  movaps [r15+0x1A0], xmm1
00007d0bb21e50d2  movq xmm15, xmm15
00007d0bb21e50d7  movq xmm15, xmm15
00007d0bb21e50dc  movaps [r15+0x190], xmm15
00007d0bb21e50e4  lea r14, [rax+0x1A0]
00007d0bb21e50eb  mov r12, [r13+r14*1]
00007d0bb21e50f0  lea r14, [rax+0x1A8]
00007d0bb21e50f7  mov r10, [r13+r14*1]
00007d0bb21e50fc  movq xmm1, r12
00007d0bb21e5101  movq xmm15, r10
00007d0bb21e5106  movq xmm1, xmm1
00007d0bb21e510a  movq xmm1, xmm1
00007d0bb21e510e  movaps [r15+0x1C0], xmm1
00007d0bb21e5116  movq xmm15, xmm15
00007d0bb21e511b  movq xmm15, xmm15
00007d0bb21e5120  movaps [r15+0x1B0], xmm15
00007d0bb21e5128  lea r14, [rax+0x190]
00007d0bb21e512f  mov r12, [r13+r14*1]
00007d0bb21e5134  lea r14, [rax+0x198]
00007d0bb21e513b  mov r10, [r13+r14*1]
00007d0bb21e5140  movq xmm1, r12
00007d0bb21e5145  movq xmm15, r10
00007d0bb21e514a  movq xmm1, xmm1
00007d0bb21e514e  movq xmm1, xmm1
00007d0bb21e5152  movaps [r15+0x1E0], xmm1
00007d0bb21e515a  movq xmm15, xmm15
00007d0bb21e515f  movq xmm15, xmm15
00007d0bb21e5164  movaps [r15+0x1D0], xmm15
00007d0bb21e516c  lea r14, [rax+0x180]
00007d0bb21e5173  mov r12, [r13+r14*1]
00007d0bb21e5178  lea r14, [rax+0x188]
00007d0bb21e517f  mov r10, [r13+r14*1]
00007d0bb21e5184  movq xmm1, r12
00007d0bb21e5189  movq xmm15, r10
00007d0bb21e518e  movq xmm1, xmm1
00007d0bb21e5192  movq xmm1, xmm1
00007d0bb21e5196  movaps [r15+0x200], xmm1
00007d0bb21e519e  movq xmm15, xmm15
00007d0bb21e51a3  movq xmm15, xmm15
00007d0bb21e51a8  movaps [r15+0x1F0], xmm15
00007d0bb21e51b0  lea r14, [rax+0x1E0]
00007d0bb21e51b7  mov [r15+0xF8], r14
00007d0bb21e51be  mov [r15+0x100], r11
00007d0bb21e51c5  jmp 0x00007D0BB21CE5C0
00007d0bb21e51ca  int3
00007d0bb21e51cb  call 0x00007D0BB20E27E0
00007d0bb21e51d0  jmp 0x00007D0BB21E5043
00007d0bb21e51d5  call 0x00007D0BB20E1570
00007d0bb21e51da  jmp 0x00007D0BB21E504F
00007d0bb21e51df  call 0x00007D0BB20C3FE0
00007d0bb21e51e4  jmp 0x00007D0BB21E507A
00007d0bb21e51e9  call 0x00007D0BB20E27E0
00007d0bb21e51ee  jmp 0x00007D0BB21E5086
00007d0bb21e51f3  call 0x00007D0BB20E1570
00007d0bb21e51f8  jmp 0x00007D0BB21E5092
00007d0bb21e51fd  call 0x00007D0BB20E27E0
00007d0bb21e5202  jmp 0x00007D0BB21E50AC
00007d0bb21e5207  call 0x00007D0BB20E0300
00007d0bb21e520c  jmp 0x00007D0BB21E50B8
00007d0bb21e5211  call 0x00007D0BB20E27E0
00007d0bb21e5216  jmp 0x00007D0BB21E50F0
00007d0bb21e521b  call 0x00007D0BB20E0300
00007d0bb21e5220  jmp 0x00007D0BB21E50FC
00007d0bb21e5225  call 0x00007D0BB20E27E0
00007d0bb21e522a  jmp 0x00007D0BB21E5134
00007d0bb21e522f  call 0x00007D0BB20E0300
00007d0bb21e5234  jmp 0x00007D0BB21E5140
00007d0bb21e5239  call 0x00007D0BB20E27E0
00007d0bb21e523e  jmp 0x00007D0BB21E5178
00007d0bb21e5243  call 0x00007D0BB20E0300
00007d0bb21e5248  jmp 0x00007D0BB21E5184
00007d0bb21e524d  int3
00007d0bb21e524e  nop
00007d0bb21e5250  mov qword ptr [r15+0x100], 0x04
00007d0bb21e525b  mov esi, 0x00
00007d0bb21e5260  mov edx, 0x09
00007d0bb21e5265  mov rdi, 0x7FFD3B9BD0E0
00007d0bb21e526f  mov rax, 0x6392BBD12970
00007d0bb21e5279  call rax
00007d0bb21e527b  cmp dword ptr [r15+0x318], 0x00
00007d0bb21e5283  jnz 0x00007D0BB1FFE110
00007d0bb21e5289  jmp 0x00007D0BB1FFE0A0
00007d0bb21e528e  int3
00007d0bb21e528f  int3
