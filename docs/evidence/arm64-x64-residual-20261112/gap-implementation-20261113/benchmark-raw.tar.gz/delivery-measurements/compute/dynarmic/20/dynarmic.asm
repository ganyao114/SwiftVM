000078d2e7dce69b  nop [rax+rax*1], eax
000078d2e7dce6a0  mov rax, [r15+0xF8]
000078d2e7dce6a7  lea r14, [rax-0x1E0]
000078d2e7dce6ae  mov [r15+0xF8], r14
000078d2e7dce6b5  lea rax, [r14+0x1D0]
000078d2e7dce6bc  mov r12, [r15+0xA0]
000078d2e7dce6c3  mov r11, [r15+0x98]
000078d2e7dce6ca  mov [r13+rax*1], r12
000078d2e7dce6cf  lea rax, [r14+0x1D8]
000078d2e7dce6d6  mov [r13+rax*1], r11
000078d2e7dce6db  mov eax, 0x420AA0
000078d2e7dce6e0  movups xmm1, [r13+rax*1]
000078d2e7dce6e6  mov eax, 0x420A30
000078d2e7dce6eb  movups xmm15, [r13+rax*1]
000078d2e7dce6f1  mov eax, 0x420AC0
000078d2e7dce6f6  movups xmm14, [r13+rax*1]
000078d2e7dce6fc  mov eax, 0x420A60
000078d2e7dce701  movups xmm13, [r13+rax*1]
000078d2e7dce707  mov qword ptr [r15+0x98], 0x430CD0
000078d2e7dce712  mov eax, 0x420AD0
000078d2e7dce717  movups xmm12, [r13+rax*1]
000078d2e7dce71d  mov eax, 0x430CD0
000078d2e7dce722  movups [r13+rax*1], xmm1
000078d2e7dce728  mov eax, 0x430CE0
000078d2e7dce72d  movups [r13+rax*1], xmm15
000078d2e7dce733  mov eax, 0x430CF0
000078d2e7dce738  movups [r13+rax*1], xmm14
000078d2e7dce73e  mov eax, 0x430D00
000078d2e7dce743  movups [r13+rax*1], xmm13
000078d2e7dce749  mov eax, 0x420A20
000078d2e7dce74e  movups xmm14, [r13+rax*1]
000078d2e7dce754  mov eax, 0x420A10
000078d2e7dce759  movups xmm13, [r13+rax*1]
000078d2e7dce75f  mov eax, 0x430DD0
000078d2e7dce764  movups [r13+rax*1], xmm1
000078d2e7dce76a  mov eax, 0x430DE0
000078d2e7dce76f  movups [r13+rax*1], xmm15
000078d2e7dce775  mov eax, 0x430D10
000078d2e7dce77a  movups [r13+rax*1], xmm12
000078d2e7dce780  mov eax, 0x430D20
000078d2e7dce785  movups [r13+rax*1], xmm14
000078d2e7dce78b  mov eax, 0x420A00
000078d2e7dce790  movups xmm1, [r13+rax*1]
000078d2e7dce796  mov eax, 0x420A70
000078d2e7dce79b  movups xmm15, [r13+rax*1]
000078d2e7dce7a1  mov eax, 0x430D30
000078d2e7dce7a6  movups [r13+rax*1], xmm13
000078d2e7dce7ac  mov eax, 0x430D40
000078d2e7dce7b1  movups [r13+rax*1], xmm1
000078d2e7dce7b7  mov eax, 0x420A80
000078d2e7dce7bc  movups xmm1, [r13+rax*1]
000078d2e7dce7c2  mov eax, 0x420A50
000078d2e7dce7c7  movups xmm14, [r13+rax*1]
000078d2e7dce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000078d2e7dce7d5  mov eax, 0x430D50
000078d2e7dce7da  movups [r13+rax*1], xmm15
000078d2e7dce7e0  mov eax, 0x430D60
000078d2e7dce7e5  movups [r13+rax*1], xmm1
000078d2e7dce7eb  mov eax, 0x420AF0
000078d2e7dce7f0  movups xmm1, [r13+rax*1]
000078d2e7dce7f6  mov eax, 0x420B00
000078d2e7dce7fb  movups xmm15, [r13+rax*1]
000078d2e7dce801  movaps [r15+0x150], xmm15
000078d2e7dce809  mov qword ptr [r15+0xA0], 0x3E8
000078d2e7dce814  mov eax, 0x430D70
000078d2e7dce819  movups [r13+rax*1], xmm14
000078d2e7dce81f  mov eax, 0x430D80
000078d2e7dce824  movups [r13+rax*1], xmm1
000078d2e7dce82a  mov eax, 0x420AE0
000078d2e7dce82f  movups xmm1, [r13+rax*1]
000078d2e7dce835  mov eax, 0x420A90
000078d2e7dce83a  movups xmm14, [r13+rax*1]
000078d2e7dce840  movaps [r15+0x140], xmm14
000078d2e7dce848  lea rax, [r14+0x180]
000078d2e7dce84f  movq xmm13, qword ptr [r15+0x200]
000078d2e7dce858  movq xmm12, qword ptr [r15+0x1F0]
000078d2e7dce861  movq r12, xmm13
000078d2e7dce866  movq r11, xmm12
000078d2e7dce86b  mov [r13+rax*1], r12
000078d2e7dce870  lea rax, [r14+0x188]
000078d2e7dce877  mov [r13+rax*1], r11
000078d2e7dce87c  mov eax, 0x430D90
000078d2e7dce881  movups [r13+rax*1], xmm15
000078d2e7dce887  mov eax, 0x430DA0
000078d2e7dce88c  movups [r13+rax*1], xmm1
000078d2e7dce892  mov eax, 0x420AB0
000078d2e7dce897  movups xmm1, [r13+rax*1]
000078d2e7dce89d  mov eax, 0x420B18
000078d2e7dce8a2  mov r12, [r13+rax*1]
000078d2e7dce8a7  movq xmm15, r12
000078d2e7dce8ac  mov qword ptr [r15+0x40], 0x420B20
000078d2e7dce8b4  mov eax, 0x430DB0
000078d2e7dce8b9  movups [r13+rax*1], xmm14
000078d2e7dce8bf  mov eax, 0x430DC0
000078d2e7dce8c4  movups [r13+rax*1], xmm1
000078d2e7dce8ca  mov eax, 0x420B80
000078d2e7dce8cf  movups xmm1, [r13+rax*1]
000078d2e7dce8d5  movq rax, xmm15
000078d2e7dce8da  mov r12d, 0x430DF0
000078d2e7dce8e0  mov [r13+r12*1], rax
000078d2e7dce8e5  mov eax, 0x420B60
000078d2e7dce8ea  movups xmm15, [r13+rax*1]
000078d2e7dce8f0  mov eax, 0x420B70
000078d2e7dce8f5  movups xmm14, [r13+rax*1]
000078d2e7dce8fb  lea rax, [r14+0x160]
000078d2e7dce902  movups [r13+rax*1], xmm1
000078d2e7dce908  lea rax, [r14+0x190]
000078d2e7dce90f  movq xmm1, qword ptr [r15+0x1E0]
000078d2e7dce918  movq xmm13, qword ptr [r15+0x1D0]
000078d2e7dce921  movq r12, xmm1
000078d2e7dce926  movq r11, xmm13
000078d2e7dce92b  mov [r13+rax*1], r12
000078d2e7dce930  lea rax, [r14+0x198]
000078d2e7dce937  mov [r13+rax*1], r11
000078d2e7dce93c  lea rax, [r14+0x140]
000078d2e7dce943  movups [r13+rax*1], xmm15
000078d2e7dce949  lea rax, [r14+0x150]
000078d2e7dce950  movups [r13+rax*1], xmm14
000078d2e7dce956  mov eax, 0x420B20
000078d2e7dce95b  movups xmm1, [r13+rax*1]
000078d2e7dce961  mov eax, 0x420B30
000078d2e7dce966  movups xmm15, [r13+rax*1]
000078d2e7dce96c  movaps [r15+0x120], xmm15
000078d2e7dce974  lea rax, [r14+0x1A0]
000078d2e7dce97b  movq xmm14, qword ptr [r15+0x1C0]
000078d2e7dce984  movq xmm13, qword ptr [r15+0x1B0]
000078d2e7dce98d  movq r12, xmm14
000078d2e7dce992  movq r11, xmm13
000078d2e7dce997  mov [r13+rax*1], r12
000078d2e7dce99c  lea rax, [r14+0x1A8]
000078d2e7dce9a3  mov [r13+rax*1], r11
000078d2e7dce9a8  lea rax, [r14+0x1B0]
000078d2e7dce9af  movq xmm14, qword ptr [r15+0x1A0]
000078d2e7dce9b8  movq xmm13, qword ptr [r15+0x190]
000078d2e7dce9c1  movq r12, xmm14
000078d2e7dce9c6  movq r11, xmm13
000078d2e7dce9cb  mov [r13+rax*1], r12
000078d2e7dce9d0  lea rax, [r14+0x1B8]
000078d2e7dce9d7  mov [r13+rax*1], r11
000078d2e7dce9dc  lea rax, [r14+0x100]
000078d2e7dce9e3  movups [r13+rax*1], xmm1
000078d2e7dce9e9  lea rax, [r14+0x110]
000078d2e7dce9f0  movups [r13+rax*1], xmm15
000078d2e7dce9f6  mov eax, 0x420B40
000078d2e7dce9fb  movups xmm1, [r13+rax*1]
000078d2e7dcea01  mov eax, 0x420B50
000078d2e7dcea06  movups xmm15, [r13+rax*1]
000078d2e7dcea0c  movaps [r15+0x110], xmm1
000078d2e7dcea14  movaps [r15+0x130], xmm15
000078d2e7dcea1c  lea rax, [r14+0x1C0]
000078d2e7dcea23  mov r12, [r15+0xE8]
000078d2e7dcea2a  mov r11, [r15+0xF0]
000078d2e7dcea31  mov [r13+rax*1], r12
000078d2e7dcea36  lea rax, [r14+0x1C8]
000078d2e7dcea3d  mov [r13+rax*1], r11
000078d2e7dcea42  mov eax, 0x430DF8
000078d2e7dcea47  mov r12d, 0x421DF8D3
000078d2e7dcea4d  mov [r13+rax*1], r12d
000078d2e7dcea52  lea rax, [r14+0x120]
000078d2e7dcea59  movups [r13+rax*1], xmm1
000078d2e7dcea5f  lea rax, [r14+0x130]
000078d2e7dcea66  movups [r13+rax*1], xmm15
000078d2e7dcea6c  lea rax, [r14+0x100]
000078d2e7dcea73  mov [r15], rax
000078d2e7dcea76  mov qword ptr [r15+0x08], 0x430CD0
000078d2e7dcea7e  mov qword ptr [r15+0x10], 0x12C
000078d2e7dcea86  mov qword ptr [r15+0xF0], 0x410284
000078d2e7dcea91  mov r14d, [r15+0x320]
000078d2e7dcea98  mov eax, 0x410284
000078d2e7dcea9d  mov rcx, 0x78D2E7DD07C0
000078d2e7dceaa7  mov [r15+r14*8+0x328], rax
000078d2e7dceaaf  mov [r15+r14*8+0x368], rcx
000078d2e7dceab7  add r14d, 0x01
000078d2e7dceabb  and r14d, 0x07
000078d2e7dceabf  mov [r15+0x320], r14d
000078d2e7dceac6  cmp dword ptr [r15+0x318], 0x00
000078d2e7dceace  jz 0x000078D2E7DCED70
000078d2e7dcead4  nop [rax+rax*1], ax
000078d2e7dceadd  nop [rax+rax*1], eax
000078d2e7dceae5  mov eax, 0x410728
000078d2e7dceaea  mov [r15+0x100], rax
000078d2e7dceaf1  jmp 0x000078D2E7BFE110
000078d2e7dceaf6  int3
000078d2e7dceaf7  call 0x000078D2E7C0BC20
000078d2e7dceafc  jmp 0x000078D2E7DCE6CF
000078d2e7dceb01  call 0x000078D2E7C0A9A0
000078d2e7dceb06  jmp 0x000078D2E7DCE6DB
000078d2e7dceb0b  call 0x000078D2E7BFF430
000078d2e7dceb10  jmp 0x000078D2E7DCE6E6
000078d2e7dceb15  call 0x000078D2E7C0E760
000078d2e7dceb1a  jmp 0x000078D2E7DCE6F1
000078d2e7dceb1f  call 0x000078D2E7C0D4E0
000078d2e7dceb24  jmp 0x000078D2E7DCE6FC
000078d2e7dceb29  call 0x000078D2E7C0C260
000078d2e7dceb2e  jmp 0x000078D2E7DCE707
000078d2e7dceb33  call 0x000078D2E7C0AFE0
000078d2e7dceb38  jmp 0x000078D2E7DCE71D
000078d2e7dceb3d  call 0x000078D2E7BFF540
000078d2e7dceb42  jmp 0x000078D2E7DCE728
000078d2e7dceb47  call 0x000078D2E7C0E880
000078d2e7dceb4c  jmp 0x000078D2E7DCE733
000078d2e7dceb51  call 0x000078D2E7C0D600
000078d2e7dceb56  jmp 0x000078D2E7DCE73E
000078d2e7dceb5b  call 0x000078D2E7C0C380
000078d2e7dceb60  jmp 0x000078D2E7DCE749
000078d2e7dceb65  call 0x000078D2E7C0D4E0
000078d2e7dceb6a  jmp 0x000078D2E7DCE754
000078d2e7dceb6f  call 0x000078D2E7C0C260
000078d2e7dceb74  jmp 0x000078D2E7DCE75F
000078d2e7dceb79  call 0x000078D2E7BFF540
000078d2e7dceb7e  jmp 0x000078D2E7DCE76A
000078d2e7dceb83  call 0x000078D2E7C0E880
000078d2e7dceb88  jmp 0x000078D2E7DCE775
000078d2e7dceb8d  call 0x000078D2E7C0B100
000078d2e7dceb92  jmp 0x000078D2E7DCE780
000078d2e7dceb97  call 0x000078D2E7C0D600
000078d2e7dceb9c  jmp 0x000078D2E7DCE78B
000078d2e7dceba1  call 0x000078D2E7BFF430
000078d2e7dceba6  jmp 0x000078D2E7DCE796
000078d2e7dcebab  call 0x000078D2E7C0E760
000078d2e7dcebb0  jmp 0x000078D2E7DCE7A1
000078d2e7dcebb5  call 0x000078D2E7C0C380
000078d2e7dcebba  jmp 0x000078D2E7DCE7AC
000078d2e7dcebbf  call 0x000078D2E7BFF540
000078d2e7dcebc4  jmp 0x000078D2E7DCE7B7
000078d2e7dcebc9  call 0x000078D2E7BFF430
000078d2e7dcebce  jmp 0x000078D2E7DCE7C2
000078d2e7dcebd3  call 0x000078D2E7C0D4E0
000078d2e7dcebd8  jmp 0x000078D2E7DCE7CD
000078d2e7dcebdd  call 0x000078D2E7C0E880
000078d2e7dcebe2  jmp 0x000078D2E7DCE7E0
000078d2e7dcebe7  call 0x000078D2E7BFF540
000078d2e7dcebec  jmp 0x000078D2E7DCE7EB
000078d2e7dcebf1  call 0x000078D2E7BFF430
000078d2e7dcebf6  jmp 0x000078D2E7DCE7F6
000078d2e7dcebfb  call 0x000078D2E7C0E760
000078d2e7dcec00  jmp 0x000078D2E7DCE801
000078d2e7dcec05  call 0x000078D2E7C0D600
000078d2e7dcec0a  jmp 0x000078D2E7DCE81F
000078d2e7dcec0f  call 0x000078D2E7BFF540
000078d2e7dcec14  jmp 0x000078D2E7DCE82A
000078d2e7dcec19  call 0x000078D2E7BFF430
000078d2e7dcec1e  jmp 0x000078D2E7DCE835
000078d2e7dcec23  call 0x000078D2E7C0D4E0
000078d2e7dcec28  jmp 0x000078D2E7DCE840
000078d2e7dcec2d  call 0x000078D2E7C0BC20
000078d2e7dcec32  jmp 0x000078D2E7DCE870
000078d2e7dcec37  call 0x000078D2E7C0A9A0
000078d2e7dcec3c  jmp 0x000078D2E7DCE87C
000078d2e7dcec41  call 0x000078D2E7C0E880
000078d2e7dcec46  jmp 0x000078D2E7DCE887
000078d2e7dcec4b  call 0x000078D2E7BFF540
000078d2e7dcec50  jmp 0x000078D2E7DCE892
000078d2e7dcec55  call 0x000078D2E7BFF430
000078d2e7dcec5a  jmp 0x000078D2E7DCE89D
000078d2e7dcec5f  call 0x000078D2E7C0B720
000078d2e7dcec64  jmp 0x000078D2E7DCE8A7
000078d2e7dcec69  call 0x000078D2E7C0D600
000078d2e7dcec6e  jmp 0x000078D2E7DCE8BF
000078d2e7dcec73  call 0x000078D2E7BFF540
000078d2e7dcec78  jmp 0x000078D2E7DCE8CA
000078d2e7dcec7d  call 0x000078D2E7BFF430
000078d2e7dcec82  jmp 0x000078D2E7DCE8D5
000078d2e7dcec87  call 0x000078D2E7CB4CB0
000078d2e7dcec8c  jmp 0x000078D2E7DCE8E5
000078d2e7dcec91  call 0x000078D2E7C0E760
000078d2e7dcec96  jmp 0x000078D2E7DCE8F0
000078d2e7dcec9b  call 0x000078D2E7C0D4E0
000078d2e7dceca0  jmp 0x000078D2E7DCE8FB
000078d2e7dceca5  call 0x000078D2E7BFF540
000078d2e7dcecaa  jmp 0x000078D2E7DCE908
000078d2e7dcecaf  call 0x000078D2E7C0BC20
000078d2e7dcecb4  jmp 0x000078D2E7DCE930
000078d2e7dcecb9  call 0x000078D2E7C0A9A0
000078d2e7dcecbe  jmp 0x000078D2E7DCE93C
000078d2e7dcecc3  call 0x000078D2E7C0E880
000078d2e7dcecc8  jmp 0x000078D2E7DCE949
000078d2e7dceccd  call 0x000078D2E7C0D600
000078d2e7dcecd2  jmp 0x000078D2E7DCE956
000078d2e7dcecd7  call 0x000078D2E7BFF430
000078d2e7dcecdc  jmp 0x000078D2E7DCE961
000078d2e7dcece1  call 0x000078D2E7C0E760
000078d2e7dcece6  jmp 0x000078D2E7DCE96C
000078d2e7dceceb  call 0x000078D2E7C0BC20
000078d2e7dcecf0  jmp 0x000078D2E7DCE99C
000078d2e7dcecf5  call 0x000078D2E7C0A9A0
000078d2e7dcecfa  jmp 0x000078D2E7DCE9A8
000078d2e7dcecff  call 0x000078D2E7C0BC20
000078d2e7dced04  jmp 0x000078D2E7DCE9D0
000078d2e7dced09  call 0x000078D2E7C0A9A0
000078d2e7dced0e  jmp 0x000078D2E7DCE9DC
000078d2e7dced13  call 0x000078D2E7BFF540
000078d2e7dced18  jmp 0x000078D2E7DCE9E9
000078d2e7dced1d  call 0x000078D2E7C0E880
000078d2e7dced22  jmp 0x000078D2E7DCE9F6
000078d2e7dced27  call 0x000078D2E7BFF430
000078d2e7dced2c  jmp 0x000078D2E7DCEA01
000078d2e7dced31  call 0x000078D2E7C0E760
000078d2e7dced36  jmp 0x000078D2E7DCEA0C
000078d2e7dced3b  call 0x000078D2E7C0BC20
000078d2e7dced40  jmp 0x000078D2E7DCEA36
000078d2e7dced45  call 0x000078D2E7C0A9A0
000078d2e7dced4a  jmp 0x000078D2E7DCEA42
000078d2e7dced4f  call 0x000078D2E7C0BAE0
000078d2e7dced54  jmp 0x000078D2E7DCEA52
000078d2e7dced59  call 0x000078D2E7BFF540
000078d2e7dced5e  jmp 0x000078D2E7DCEA5F
000078d2e7dced63  call 0x000078D2E7C0E880
000078d2e7dced68  jmp 0x000078D2E7DCEA6C
000078d2e7dced6d  int3
000078d2e7dced6e  nop
000078d2e7dced70  mov rax, [r15]
000078d2e7dced73  lea r14, [rax+0x20]
000078d2e7dced77  mov r12, [r13+r14*1]
000078d2e7dced7c  mov r14, [r15+0x10]
000078d2e7dced80  lea r11, [r12+r14*1]
000078d2e7dced84  mov [r15+0x40], r11
000078d2e7dced88  lea r12, [rax+0x20]
000078d2e7dced8c  mov [r13+r12*1], r11
000078d2e7dced91  test r14, r14
000078d2e7dced94  setz r14b
000078d2e7dced98  movzx r14, r14b
000078d2e7dced9c  mov [rsp+0x414], r14b
000078d2e7dceda4  cmp byte ptr [rsp+0x414], 0x00
000078d2e7dcedac  jz 0x000078D2E7DCEDDE
000078d2e7dcedae  cmp dword ptr [r15+0x318], 0x00
000078d2e7dcedb6  mov eax, 0x4109A0
000078d2e7dcedbb  mov [r15+0x100], rax
000078d2e7dcedc2  jz 0x000078D2E7BFE0A0
000078d2e7dcedc8  nop [rax+rax*1], eax
000078d2e7dcedcd  mov eax, 0x4109A0
000078d2e7dcedd2  mov [r15+0x100], rax
000078d2e7dcedd9  jmp 0x000078D2E7BFE110
000078d2e7dcedde  cmp dword ptr [r15+0x318], 0x00
000078d2e7dcede6  jz 0x000078D2E7DCEE30
000078d2e7dcedec  nop [rax+rax*1], ax
000078d2e7dcedf5  nop [rax+rax*1], eax
000078d2e7dcedfd  mov eax, 0x410738
000078d2e7dcee02  mov [r15+0x100], rax
000078d2e7dcee09  jmp 0x000078D2E7BFE110
000078d2e7dcee0e  int3
000078d2e7dcee0f  call 0x000078D2E7CE27E0
000078d2e7dcee14  jmp 0x000078D2E7DCED7C
000078d2e7dcee19  call 0x000078D2E7CC0860
000078d2e7dcee1e  jmp 0x000078D2E7DCED91
000078d2e7dcee23  int3
000078d2e7dcee24  nop [rax+rax*1], ax
000078d2e7dcee2d  nop [rax], eax
000078d2e7dcee30  mov rax, [r15+0xF8]
000078d2e7dcee37  lea r14, [rax-0x150]
000078d2e7dcee3e  mov [r15+0xF8], r14
000078d2e7dcee45  mov rax, [r15]
000078d2e7dcee48  lea r12, [rax+0x68]
000078d2e7dcee4c  mov r11, [r13+r12*1]
000078d2e7dcee51  mov [r15+0x88], r11
000078d2e7dcee58  lea r12, [rax+0x28]
000078d2e7dcee5c  mov [r15+0x40], r12
000078d2e7dcee60  mov [r15+0x48], r14
000078d2e7dcee64  mov qword ptr [r15+0x50], 0x420B90
000078d2e7dcee6c  lea rax, [r14+0x100]
000078d2e7dcee73  mov r12, [r15+0xE8]
000078d2e7dcee7a  mov r11, [r15+0xD8]
000078d2e7dcee81  mov [r13+rax*1], r12
000078d2e7dcee86  lea rax, [r14+0x108]
000078d2e7dcee8d  mov [r13+rax*1], r11
000078d2e7dcee92  lea rax, [r14+0x110]
000078d2e7dcee99  mov r12, [r15+0xD0]
000078d2e7dceea0  mov r11, [r15+0xC8]
000078d2e7dceea7  mov [r13+rax*1], r12
000078d2e7dceeac  lea rax, [r14+0x118]
000078d2e7dceeb3  mov [r13+rax*1], r11
000078d2e7dceeb8  lea rax, [r14+0x120]
000078d2e7dceebf  mov r12, [r15+0xC0]
000078d2e7dceec6  mov r11, [r15+0xB8]
000078d2e7dceecd  mov [r13+rax*1], r12
000078d2e7dceed2  lea rax, [r14+0x128]
000078d2e7dceed9  mov [r13+rax*1], r11
000078d2e7dceede  lea rax, [r14+0x130]
000078d2e7dceee5  mov r12, [r15+0xB0]
000078d2e7dceeec  mov r11, [r15+0xA8]
000078d2e7dceef3  mov [r13+rax*1], r12
000078d2e7dceef8  lea rax, [r14+0x138]
000078d2e7dceeff  mov [r13+rax*1], r11
000078d2e7dcef04  lea rax, [r14+0x140]
000078d2e7dcef0b  mov r12, [r15+0xA0]
000078d2e7dcef12  mov r11, [r15+0x98]
000078d2e7dcef19  mov [r13+rax*1], r12
000078d2e7dcef1e  lea rax, [r14+0x148]
000078d2e7dcef25  mov [r13+rax*1], r11
000078d2e7dcef2a  cmp dword ptr [r15+0x318], 0x00
000078d2e7dcef32  jz 0x000078D2E7DCEFD0
000078d2e7dcef38  nop [rax+rax*1], ax
000078d2e7dcef41  nop [rax+rax*1], eax
000078d2e7dcef49  mov eax, 0x410770
000078d2e7dcef4e  mov [r15+0x100], rax
000078d2e7dcef55  jmp 0x000078D2E7BFE110
000078d2e7dcef5a  int3
000078d2e7dcef5b  call 0x000078D2E7CC0370
000078d2e7dcef60  jmp 0x000078D2E7DCEE51
000078d2e7dcef65  call 0x000078D2E7C0BC20
000078d2e7dcef6a  jmp 0x000078D2E7DCEE86
000078d2e7dcef6f  call 0x000078D2E7C0A9A0
000078d2e7dcef74  jmp 0x000078D2E7DCEE92
000078d2e7dcef79  call 0x000078D2E7C0BC20
000078d2e7dcef7e  jmp 0x000078D2E7DCEEAC
000078d2e7dcef83  call 0x000078D2E7C0A9A0
000078d2e7dcef88  jmp 0x000078D2E7DCEEB8
000078d2e7dcef8d  call 0x000078D2E7C0BC20
000078d2e7dcef92  jmp 0x000078D2E7DCEED2
000078d2e7dcef97  call 0x000078D2E7C0A9A0
000078d2e7dcef9c  jmp 0x000078D2E7DCEEDE
000078d2e7dcefa1  call 0x000078D2E7C0BC20
000078d2e7dcefa6  jmp 0x000078D2E7DCEEF8
000078d2e7dcefab  call 0x000078D2E7C0A9A0
000078d2e7dcefb0  jmp 0x000078D2E7DCEF04
000078d2e7dcefb5  call 0x000078D2E7C0BC20
000078d2e7dcefba  jmp 0x000078D2E7DCEF1E
000078d2e7dcefbf  call 0x000078D2E7C0A9A0
000078d2e7dcefc4  jmp 0x000078D2E7DCEF2A
000078d2e7dcefc9  int3
000078d2e7dcefca  nop [rax+rax*1], ax
000078d2e7dcefd0  mov rax, [r15+0x08]
000078d2e7dcefd4  movzx r14d, byte ptr [r13+rax*1]
000078d2e7dcefda  movzx r14d, r14b
000078d2e7dcefde  mov [rsp+0x10], r14d
000078d2e7dcefe3  mov r14d, r14d
000078d2e7dcefe6  mov [r15+0x58], r14
000078d2e7dcefea  lea r14, [rax+0x01]
000078d2e7dcefee  mov [r15+0x08], r14
000078d2e7dceff2  mov rax, [r15+0x88]
000078d2e7dceff9  lea r14, [rax+0x01]
000078d2e7dceffd  mov r12, [r15]
000078d2e7dcf000  lea r11, [r12+0x68]
000078d2e7dcf005  mov [r13+r11*1], r14
000078d2e7dcf00a  lea r14, [r12+rax*1]
000078d2e7dcf00e  mov [r15+0x60], r14
000078d2e7dcf012  lea rax, [r14+0x28]
000078d2e7dcf016  mov r11d, [rsp+0x10]
000078d2e7dcf01b  movzx r14d, r11b
000078d2e7dcf01f  mov [r13+rax*1], r14b
000078d2e7dcf024  lea rax, [r12+0x68]
000078d2e7dcf029  mov r14, [r13+rax*1]
000078d2e7dcf02e  mov [r15+0x88], r14
000078d2e7dcf035  xor eax, eax
000078d2e7dcf037  mov r12d, 0x40
000078d2e7dcf03d  cmp r14, r12
000078d2e7dcf040  cmc
000078d2e7dcf041  lahf
000078d2e7dcf042  seto al
000078d2e7dcf045  mov [r15+0x108], eax
000078d2e7dcf04c  mov eax, [r15+0x108]
000078d2e7dcf053  sahf
000078d2e7dcf054  jnz 0x000078D2E7DCF086
000078d2e7dcf056  cmp dword ptr [r15+0x318], 0x00
000078d2e7dcf05e  jz 0x000078D2E7DCF170
000078d2e7dcf064  nop [rax+rax*1], ax
000078d2e7dcf06d  nop [rax+rax*1], eax
000078d2e7dcf075  mov eax, 0x410790
000078d2e7dcf07a  mov [r15+0x100], rax
000078d2e7dcf081  jmp 0x000078D2E7BFE110
000078d2e7dcf086  cmp dword ptr [r15+0x318], 0x00
000078d2e7dcf08e  jz 0x000078D2E7DCF0E0
000078d2e7dcf094  nop [rax+rax*1], ax
000078d2e7dcf09d  nop [rax+rax*1], eax
000078d2e7dcf0a5  mov eax, 0x410768
000078d2e7dcf0aa  mov [r15+0x100], rax
000078d2e7dcf0b1  jmp 0x000078D2E7BFE110
000078d2e7dcf0b6  int3
000078d2e7dcf0b7  call 0x000078D2E7C0D860
000078d2e7dcf0bc  jmp 0x000078D2E7DCEFDA
000078d2e7dcf0c1  call 0x000078D2E7CB36E0
000078d2e7dcf0c6  jmp 0x000078D2E7DCF00A
000078d2e7dcf0cb  call 0x000078D2E7C0DD60
000078d2e7dcf0d0  jmp 0x000078D2E7DCF024
000078d2e7dcf0d5  call 0x000078D2E7C0DC20
000078d2e7dcf0da  jmp 0x000078D2E7DCF02E
000078d2e7dcf0df  int3
000078d2e7dcf0e0  mov rax, [r15+0x10]
000078d2e7dcf0e4  lea r14, [rax-0x01]
000078d2e7dcf0e8  mov [r15+0x10], r14
000078d2e7dcf0ec  test r14, r14
000078d2e7dcf0ef  setz r14b
000078d2e7dcf0f3  movzx r14, r14b
000078d2e7dcf0f7  mov [rsp+0x414], r14b
000078d2e7dcf0ff  cmp byte ptr [rsp+0x414], 0x00
000078d2e7dcf107  jz 0x000078D2E7DCF139
000078d2e7dcf109  cmp dword ptr [r15+0x318], 0x00
000078d2e7dcf111  jz 0x000078D2E7DD0670
000078d2e7dcf117  nop [rax+rax*1], ax
000078d2e7dcf120  nop [rax+rax*1], eax
000078d2e7dcf128  mov eax, 0x410988
000078d2e7dcf12d  mov [r15+0x100], rax
000078d2e7dcf134  jmp 0x000078D2E7BFE110
000078d2e7dcf139  cmp dword ptr [r15+0x318], 0x00
000078d2e7dcf141  jz 0x000078D2E7DCEFD0
000078d2e7dcf147  nop [rax+rax*1], ax
000078d2e7dcf150  nop [rax+rax*1], eax
000078d2e7dcf158  mov eax, 0x410770
000078d2e7dcf15d  mov [r15+0x100], rax
000078d2e7dcf164  jmp 0x000078D2E7BFE110
000078d2e7dcf169  int3
000078d2e7dcf16a  int3
000078d2e7dcf16b  nop [rax+rax*1], eax
000078d2e7dcf170  mov rax, [r15+0x40]
000078d2e7dcf174  movzx r14d, byte ptr [r13+rax*1]
000078d2e7dcf17a  movaps xmm1, [r15+0x110]
000078d2e7dcf182  pinsrb xmm1, r14d, 0x00
000078d2e7dcf189  lea r14, [rax+0x01]
000078d2e7dcf18d  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf193  movaps xmm15, [r15+0x120]
000078d2e7dcf19b  pinsrb xmm15, r12d, 0x00
000078d2e7dcf1a2  lea r14, [rax+0x02]
000078d2e7dcf1a6  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf1ac  movaps xmm14, [r15+0x130]
000078d2e7dcf1b4  pinsrb xmm14, r12d, 0x00
000078d2e7dcf1bb  lea r14, [rax+0x03]
000078d2e7dcf1bf  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf1c5  movaps xmm13, [r15+0x140]
000078d2e7dcf1cd  pinsrb xmm13, r12d, 0x00
000078d2e7dcf1d4  lea r14, [rax+0x04]
000078d2e7dcf1d8  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf1de  pinsrb xmm1, r12d, 0x01
000078d2e7dcf1e5  lea r14, [rax+0x05]
000078d2e7dcf1e9  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf1ef  pinsrb xmm15, r12d, 0x01
000078d2e7dcf1f6  lea r14, [rax+0x06]
000078d2e7dcf1fa  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf200  pinsrb xmm14, r12d, 0x01
000078d2e7dcf207  lea r14, [rax+0x07]
000078d2e7dcf20b  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf211  pinsrb xmm13, r12d, 0x01
000078d2e7dcf218  lea r14, [rax+0x08]
000078d2e7dcf21c  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf222  pinsrb xmm1, r12d, 0x02
000078d2e7dcf229  lea r14, [rax+0x09]
000078d2e7dcf22d  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf233  pinsrb xmm15, r12d, 0x02
000078d2e7dcf23a  lea r14, [rax+0x0A]
000078d2e7dcf23e  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf244  pinsrb xmm14, r12d, 0x02
000078d2e7dcf24b  lea r14, [rax+0x0B]
000078d2e7dcf24f  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf255  pinsrb xmm13, r12d, 0x02
000078d2e7dcf25c  lea r14, [rax+0x0C]
000078d2e7dcf260  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf266  pinsrb xmm1, r12d, 0x03
000078d2e7dcf26d  lea r14, [rax+0x0D]
000078d2e7dcf271  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf277  pinsrb xmm15, r12d, 0x03
000078d2e7dcf27e  lea r14, [rax+0x0E]
000078d2e7dcf282  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf288  pinsrb xmm14, r12d, 0x03
000078d2e7dcf28f  lea r14, [rax+0x0F]
000078d2e7dcf293  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf299  pinsrb xmm13, r12d, 0x03
000078d2e7dcf2a0  lea r14, [rax+0x10]
000078d2e7dcf2a4  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf2aa  pinsrb xmm1, r12d, 0x04
000078d2e7dcf2b1  lea r14, [rax+0x11]
000078d2e7dcf2b5  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf2bb  pinsrb xmm15, r12d, 0x04
000078d2e7dcf2c2  lea r14, [rax+0x12]
000078d2e7dcf2c6  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf2cc  pinsrb xmm14, r12d, 0x04
000078d2e7dcf2d3  lea r14, [rax+0x13]
000078d2e7dcf2d7  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf2dd  pinsrb xmm13, r12d, 0x04
000078d2e7dcf2e4  lea r14, [rax+0x14]
000078d2e7dcf2e8  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf2ee  pinsrb xmm1, r12d, 0x05
000078d2e7dcf2f5  lea r14, [rax+0x15]
000078d2e7dcf2f9  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf2ff  pinsrb xmm15, r12d, 0x05
000078d2e7dcf306  lea r14, [rax+0x16]
000078d2e7dcf30a  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf310  pinsrb xmm14, r12d, 0x05
000078d2e7dcf317  lea r14, [rax+0x17]
000078d2e7dcf31b  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf321  pinsrb xmm13, r12d, 0x05
000078d2e7dcf328  lea r14, [rax+0x18]
000078d2e7dcf32c  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf332  pinsrb xmm1, r12d, 0x06
000078d2e7dcf339  lea r14, [rax+0x19]
000078d2e7dcf33d  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf343  pinsrb xmm15, r12d, 0x06
000078d2e7dcf34a  lea r14, [rax+0x1A]
000078d2e7dcf34e  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf354  pinsrb xmm14, r12d, 0x06
000078d2e7dcf35b  lea r14, [rax+0x1B]
000078d2e7dcf35f  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf365  pinsrb xmm13, r12d, 0x06
000078d2e7dcf36c  lea r14, [rax+0x1C]
000078d2e7dcf370  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf376  pinsrb xmm1, r12d, 0x07
000078d2e7dcf37d  lea r14, [rax+0x1D]
000078d2e7dcf381  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf387  pinsrb xmm15, r12d, 0x07
000078d2e7dcf38e  lea r14, [rax+0x1E]
000078d2e7dcf392  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf398  pinsrb xmm14, r12d, 0x07
000078d2e7dcf39f  lea r14, [rax+0x1F]
000078d2e7dcf3a3  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf3a9  pinsrb xmm13, r12d, 0x07
000078d2e7dcf3b0  lea r14, [rax+0x20]
000078d2e7dcf3b4  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf3ba  pinsrb xmm1, r12d, 0x08
000078d2e7dcf3c1  lea r14, [rax+0x21]
000078d2e7dcf3c5  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf3cb  pinsrb xmm15, r12d, 0x08
000078d2e7dcf3d2  lea r14, [rax+0x22]
000078d2e7dcf3d6  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf3dc  pinsrb xmm14, r12d, 0x08
000078d2e7dcf3e3  lea r14, [rax+0x23]
000078d2e7dcf3e7  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf3ed  pinsrb xmm13, r12d, 0x08
000078d2e7dcf3f4  lea r14, [rax+0x24]
000078d2e7dcf3f8  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf3fe  pinsrb xmm1, r12d, 0x09
000078d2e7dcf405  lea r14, [rax+0x25]
000078d2e7dcf409  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf40f  pinsrb xmm15, r12d, 0x09
000078d2e7dcf416  lea r14, [rax+0x26]
000078d2e7dcf41a  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf420  pinsrb xmm14, r12d, 0x09
000078d2e7dcf427  lea r14, [rax+0x27]
000078d2e7dcf42b  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf431  pinsrb xmm13, r12d, 0x09
000078d2e7dcf438  lea r14, [rax+0x28]
000078d2e7dcf43c  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf442  pinsrb xmm1, r12d, 0x0A
000078d2e7dcf449  lea r14, [rax+0x29]
000078d2e7dcf44d  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf453  pinsrb xmm15, r12d, 0x0A
000078d2e7dcf45a  lea r14, [rax+0x2A]
000078d2e7dcf45e  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf464  pinsrb xmm14, r12d, 0x0A
000078d2e7dcf46b  lea r14, [rax+0x2B]
000078d2e7dcf46f  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf475  pinsrb xmm13, r12d, 0x0A
000078d2e7dcf47c  lea r14, [rax+0x2C]
000078d2e7dcf480  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf486  pinsrb xmm1, r12d, 0x0B
000078d2e7dcf48d  lea r14, [rax+0x2D]
000078d2e7dcf491  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf497  pinsrb xmm15, r12d, 0x0B
000078d2e7dcf49e  lea r14, [rax+0x2E]
000078d2e7dcf4a2  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf4a8  pinsrb xmm14, r12d, 0x0B
000078d2e7dcf4af  lea r14, [rax+0x2F]
000078d2e7dcf4b3  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf4b9  pinsrb xmm13, r12d, 0x0B
000078d2e7dcf4c0  lea r14, [rax+0x30]
000078d2e7dcf4c4  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf4ca  pinsrb xmm1, r12d, 0x0C
000078d2e7dcf4d1  lea r14, [rax+0x31]
000078d2e7dcf4d5  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf4db  pinsrb xmm15, r12d, 0x0C
000078d2e7dcf4e2  lea r14, [rax+0x32]
000078d2e7dcf4e6  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf4ec  pinsrb xmm14, r12d, 0x0C
000078d2e7dcf4f3  lea r14, [rax+0x33]
000078d2e7dcf4f7  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf4fd  pinsrb xmm13, r12d, 0x0C
000078d2e7dcf504  lea r14, [rax+0x34]
000078d2e7dcf508  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf50e  pinsrb xmm1, r12d, 0x0D
000078d2e7dcf515  lea r14, [rax+0x35]
000078d2e7dcf519  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf51f  pinsrb xmm15, r12d, 0x0D
000078d2e7dcf526  lea r14, [rax+0x36]
000078d2e7dcf52a  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf530  pinsrb xmm14, r12d, 0x0D
000078d2e7dcf537  lea r14, [rax+0x37]
000078d2e7dcf53b  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf541  pinsrb xmm13, r12d, 0x0D
000078d2e7dcf548  lea r14, [rax+0x38]
000078d2e7dcf54c  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf552  pinsrb xmm1, r12d, 0x0E
000078d2e7dcf559  lea r14, [rax+0x39]
000078d2e7dcf55d  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf563  pinsrb xmm15, r12d, 0x0E
000078d2e7dcf56a  lea r14, [rax+0x3A]
000078d2e7dcf56e  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf574  pinsrb xmm14, r12d, 0x0E
000078d2e7dcf57b  lea r14, [rax+0x3B]
000078d2e7dcf57f  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf585  pinsrb xmm13, r12d, 0x0E
000078d2e7dcf58c  lea r14, [rax+0x3C]
000078d2e7dcf590  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf596  pinsrb xmm1, r12d, 0x0F
000078d2e7dcf59d  movaps [r15+0x110], xmm1
000078d2e7dcf5a5  lea r14, [rax+0x3D]
000078d2e7dcf5a9  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf5af  pinsrb xmm15, r12d, 0x0F
000078d2e7dcf5b6  movaps [r15+0x120], xmm15
000078d2e7dcf5be  lea r14, [rax+0x3E]
000078d2e7dcf5c2  movzx r12d, byte ptr [r13+r14*1]
000078d2e7dcf5c8  pinsrb xmm14, r12d, 0x0F
000078d2e7dcf5cf  movaps [r15+0x130], xmm14
000078d2e7dcf5d7  lea r14, [rax+0x3F]
000078d2e7dcf5db  movzx eax, byte ptr [r13+r14*1]
000078d2e7dcf5e1  pinsrb xmm13, eax, 0x0F
000078d2e7dcf5e8  movaps [r15+0x140], xmm13
000078d2e7dcf5f0  movq xmm1, qword ptr [r15+0x120]
000078d2e7dcf5f9  pmovzxbw xmm1, xmm1
000078d2e7dcf5fe  psllw xmm1, 0x00
000078d2e7dcf603  movaps [r15+0x150], xmm1
000078d2e7dcf60b  movq xmm1, qword ptr [r15+0x130]
000078d2e7dcf614  pmovzxbw xmm1, xmm1
000078d2e7dcf619  psllw xmm1, 0x00
000078d2e7dcf61e  movaps [r15+0x160], xmm1
000078d2e7dcf626  movq xmm1, qword ptr [r15+0x110]
000078d2e7dcf62f  pmovzxbw xmm1, xmm1
000078d2e7dcf634  psllw xmm1, 0x00
000078d2e7dcf639  movaps [r15+0x170], xmm1
000078d2e7dcf641  movaps xmm15, [r15+0x110]
000078d2e7dcf649  pextrq rax, xmm15, 0x01
000078d2e7dcf650  movq xmm15, rax
000078d2e7dcf655  pmovzxbw xmm15, xmm15
000078d2e7dcf65b  psllw xmm15, 0x00
000078d2e7dcf661  movaps [r15+0x180], xmm15
000078d2e7dcf669  movaps xmm14, [r15+0x120]
000078d2e7dcf671  pextrq rax, xmm14, 0x01
000078d2e7dcf678  movq xmm14, rax
000078d2e7dcf67d  pmovzxbw xmm14, xmm14
000078d2e7dcf683  psllw xmm14, 0x00
000078d2e7dcf689  movaps [r15+0x210], xmm14
000078d2e7dcf691  movaps xmm13, [r15+0x130]
000078d2e7dcf699  pextrq rax, xmm13, 0x01
000078d2e7dcf6a0  movq xmm13, rax
000078d2e7dcf6a5  pmovzxbw xmm13, xmm13
000078d2e7dcf6ab  psllw xmm13, 0x00
000078d2e7dcf6b1  movaps [r15+0x220], xmm13
000078d2e7dcf6b9  movq xmm12, qword ptr [r15+0x140]
000078d2e7dcf6c2  pmovzxbw xmm12, xmm12
000078d2e7dcf6c8  psllw xmm12, 0x00
000078d2e7dcf6ce  movaps [r15+0x250], xmm12
000078d2e7dcf6d6  movaps xmm12, [r15+0x140]
000078d2e7dcf6de  pextrq rax, xmm12, 0x01
000078d2e7dcf6e5  movq xmm12, rax
000078d2e7dcf6ea  pmovzxbw xmm12, xmm12
000078d2e7dcf6f0  psllw xmm12, 0x00
000078d2e7dcf6f6  movaps [r15+0x110], xmm12
000078d2e7dcf6fe  movq xmm11, qword ptr [r15+0x150]
000078d2e7dcf707  pmovzxwd xmm11, xmm11
000078d2e7dcf70d  pslld xmm11, 0x10
000078d2e7dcf713  movq xmm10, qword ptr [r15+0x160]
000078d2e7dcf71c  pmovzxwd xmm10, xmm10
000078d2e7dcf722  pslld xmm10, 0x08
000078d2e7dcf728  pextrq rax, xmm1, 0x01
000078d2e7dcf72f  movq xmm1, rax
000078d2e7dcf734  pmovzxwd xmm1, xmm1
000078d2e7dcf739  pslld xmm1, 0x00
000078d2e7dcf73e  movaps [r15+0x260], xmm1
000078d2e7dcf746  pextrq rax, xmm15, 0x01
000078d2e7dcf74d  movq xmm15, rax
000078d2e7dcf752  pmovzxwd xmm15, xmm15
000078d2e7dcf758  pslld xmm15, 0x00
000078d2e7dcf75e  movaps [r15+0x270], xmm15
000078d2e7dcf766  movq xmm9, qword ptr [r15+0x170]
000078d2e7dcf76f  pmovzxwd xmm9, xmm9
000078d2e7dcf775  pslld xmm9, 0x00
000078d2e7dcf77b  pextrq rax, xmm14, 0x01
000078d2e7dcf782  movq xmm14, rax
000078d2e7dcf787  pmovzxwd xmm14, xmm14
000078d2e7dcf78d  pslld xmm14, 0x10
000078d2e7dcf793  movaps [r15+0x280], xmm14
000078d2e7dcf79b  movq xmm8, qword ptr [r15+0x180]
000078d2e7dcf7a4  pmovzxwd xmm8, xmm8
000078d2e7dcf7aa  pslld xmm8, 0x00
000078d2e7dcf7b0  movq xmm7, qword ptr [r15+0x210]
000078d2e7dcf7b9  pmovzxwd xmm7, xmm7
000078d2e7dcf7be  pslld xmm7, 0x10
000078d2e7dcf7c3  movaps xmm6, [r15+0x150]
000078d2e7dcf7cb  pextrq rax, xmm6, 0x01
000078d2e7dcf7d2  movq xmm6, rax
000078d2e7dcf7d7  pmovzxwd xmm6, xmm6
000078d2e7dcf7dc  pslld xmm6, 0x10
000078d2e7dcf7e1  por xmm11, xmm10
000078d2e7dcf7e6  movaps [r15+0x230], xmm11
000078d2e7dcf7ee  pextrq rax, xmm13, 0x01
000078d2e7dcf7f5  movq xmm13, rax
000078d2e7dcf7fa  pmovzxwd xmm13, xmm13
000078d2e7dcf800  pslld xmm13, 0x08
000078d2e7dcf806  movaps [r15+0x240], xmm13
000078d2e7dcf80e  movq xmm10, qword ptr [r15+0x220]
000078d2e7dcf817  pmovzxwd xmm10, xmm10
000078d2e7dcf81d  pslld xmm10, 0x08
000078d2e7dcf823  movaps xmm5, [r15+0x160]
000078d2e7dcf82b  pextrq rax, xmm5, 0x01
000078d2e7dcf832  movq xmm5, rax
000078d2e7dcf837  pmovzxwd xmm5, xmm5
000078d2e7dcf83c  pslld xmm5, 0x08
000078d2e7dcf841  pslld xmm9, 0x18
000078d2e7dcf847  pslld xmm15, 0x18
000078d2e7dcf84d  pslld xmm8, 0x18
000078d2e7dcf853  movq xmm4, qword ptr [r15+0x250]
000078d2e7dcf85c  pmovzxwd xmm4, xmm4
000078d2e7dcf861  pslld xmm4, 0x00
000078d2e7dcf866  por xmm14, xmm13
000078d2e7dcf86b  por xmm7, xmm10
000078d2e7dcf870  movaps [r15+0x210], xmm7
000078d2e7dcf878  pslld xmm1, 0x18
000078d2e7dcf87d  movaps [r15+0x220], xmm1
000078d2e7dcf885  por xmm6, xmm5
000078d2e7dcf889  por xmm11, xmm9
000078d2e7dcf88e  movaps [r15+0x160], xmm11
000078d2e7dcf896  pextrq rax, xmm12, 0x01
000078d2e7dcf89d  movq xmm13, rax
000078d2e7dcf8a2  pmovzxwd xmm13, xmm13
000078d2e7dcf8a8  pslld xmm13, 0x00
000078d2e7dcf8ae  movaps [r15+0x170], xmm13
000078d2e7dcf8b6  movq xmm12, qword ptr [r15+0x110]
000078d2e7dcf8bf  pmovzxwd xmm12, xmm12
000078d2e7dcf8c5  pslld xmm12, 0x00
000078d2e7dcf8cb  por xmm14, xmm15
000078d2e7dcf8d0  por xmm7, xmm8
000078d2e7dcf8d5  movaps xmm15, [r15+0x250]
000078d2e7dcf8dd  pextrq rax, xmm15, 0x01
000078d2e7dcf8e4  movq xmm15, rax
000078d2e7dcf8e9  pmovzxwd xmm15, xmm15
000078d2e7dcf8ef  pslld xmm15, 0x00
000078d2e7dcf8f5  movaps [r15+0x180], xmm15
000078d2e7dcf8fd  por xmm6, xmm1
000078d2e7dcf901  movaps [r15+0x150], xmm6
000078d2e7dcf909  por xmm11, xmm4
000078d2e7dcf90e  movaps [r15+0x140], xmm11
000078d2e7dcf916  por xmm7, xmm12
000078d2e7dcf91b  movaps [r15+0x110], xmm7
000078d2e7dcf923  por xmm14, xmm13
000078d2e7dcf928  movaps [r15+0x120], xmm14
000078d2e7dcf930  por xmm6, xmm15
000078d2e7dcf935  movaps [r15+0x130], xmm6
000078d2e7dcf93d  mov rax, [r15+0xF8]
000078d2e7dcf944  lea r14, [rax+0x20]
000078d2e7dcf948  movups [r13+r14*1], xmm7
000078d2e7dcf94e  lea r14, [rax+0x30]
000078d2e7dcf952  movups [r13+r14*1], xmm14
000078d2e7dcf958  movups [r13+rax*1], xmm11
000078d2e7dcf95e  lea r14, [rax+0x10]
000078d2e7dcf962  movups [r13+r14*1], xmm6
000078d2e7dcf968  mov r14d, [r13+rax*1]
000078d2e7dcf96d  mov rax, [r15+0x48]
000078d2e7dcf971  mov [r15+0x68], rax
000078d2e7dcf975  mov qword ptr [r15+0x58], 0x04
000078d2e7dcf97d  lea r12, [rax+0x04]
000078d2e7dcf981  mov r11d, [r13+r12*1]
000078d2e7dcf986  mov [rsp+0x10], r11d
000078d2e7dcf98b  mov r11d, r11d
000078d2e7dcf98e  mov [r15+0x70], r11
000078d2e7dcf992  lea r12, [rax+0x38]
000078d2e7dcf996  mov r11d, [r13+r12*1]
000078d2e7dcf99b  lea r12, [rax+0x24]
000078d2e7dcf99f  mov r10d, [r13+r12*1]
000078d2e7dcf9a4  mov [rsp+0x20], r10d
000078d2e7dcf9a9  mov r10d, r10d
000078d2e7dcf9ac  mov [r15+0x90], r10
000078d2e7dcf9b3  mov [rsp+0x30], rax
000078d2e7dcf9b8  xor eax, eax
000078d2e7dcf9ba  mov r12d, 0x04
000078d2e7dcf9c0  mov r10d, 0xC0
000078d2e7dcf9c6  cmp r12, r10
000078d2e7dcf9c9  cmc
000078d2e7dcf9ca  lahf
000078d2e7dcf9cb  seto al
000078d2e7dcf9ce  mov [r15+0x108], eax
000078d2e7dcf9d5  mov eax, [rsp+0x10]
000078d2e7dcf9d9  mov r12d, [rsp+0x10]
000078d2e7dcf9de  shrd eax, r12d, 0x07
000078d2e7dcf9e3  mov [rsp+0x10], r11d
000078d2e7dcf9e8  mov r10d, [rsp+0x10]
000078d2e7dcf9ed  shrd r11d, r10d, 0x11
000078d2e7dcf9f2  mov r9d, [rsp+0x20]
000078d2e7dcf9f7  lea r8d, [r9d+r14d*1]
000078d2e7dcf9fc  rorx r14d, r12d, 0x12
000078d2e7dcfa02  xor eax, r14d
000078d2e7dcfa05  rorx r14d, r10d, 0x13
000078d2e7dcfa0b  xor r11d, r14d
000078d2e7dcfa0e  mov [rsp+0x10], r11d
000078d2e7dcfa13  mov r11d, r11d
000078d2e7dcfa16  mov [r15+0x88], r11
000078d2e7dcfa1d  mov [rsp+0x20], r12d
000078d2e7dcfa22  shr r12d, 0x03
000078d2e7dcfa26  xor eax, r12d
000078d2e7dcfa29  mov [rsp+0x40], eax
000078d2e7dcfa2d  mov eax, eax
000078d2e7dcfa2f  mov [r15+0x80], rax
000078d2e7dcfa36  shr r10d, 0x0A
000078d2e7dcfa3a  mov eax, [rsp+0x10]
000078d2e7dcfa3e  xor eax, r10d
000078d2e7dcfa41  mov [rsp+0x10], eax
000078d2e7dcfa45  mov eax, eax
000078d2e7dcfa47  mov [r15+0x78], rax
000078d2e7dcfa4b  mov eax, [rsp+0x40]
000078d2e7dcfa4f  lea r14d, [r8d+eax*1]
000078d2e7dcfa54  mov eax, [rsp+0x10]
000078d2e7dcfa58  lea r12d, [r14d+eax*1]
000078d2e7dcfa5d  mov rax, [rsp+0x30]
000078d2e7dcfa62  lea r14, [rax+0x40]
000078d2e7dcfa66  mov [r13+r14*1], r12d
000078d2e7dcfa6b  mov eax, [rsp+0x20]
000078d2e7dcfa6f  mov eax, eax
000078d2e7dcfa71  mov [r15+0x60], rax
000078d2e7dcfa75  mov eax, [r15+0x108]
000078d2e7dcfa7c  sahf
000078d2e7dcfa7d  jnz 0x000078D2E7DCFAAF
000078d2e7dcfa7f  cmp dword ptr [r15+0x318], 0x00
000078d2e7dcfa87  jz 0x000078D2E7DCFF70
000078d2e7dcfa8d  nop [rax+rax*1], ax
000078d2e7dcfa96  nop [rax+rax*1], eax
000078d2e7dcfa9e  mov eax, 0x41088C
000078d2e7dcfaa3  mov [r15+0x100], rax
000078d2e7dcfaaa  jmp 0x000078D2E7BFE110
000078d2e7dcfaaf  cmp dword ptr [r15+0x318], 0x00
000078d2e7dcfab7  jz 0x000078D2E7DCFDC0
000078d2e7dcfabd  nop [rax+rax*1], ax
000078d2e7dcfac6  nop [rax+rax*1], eax
000078d2e7dcface  mov eax, 0x410844
000078d2e7dcfad3  mov [r15+0x100], rax
000078d2e7dcfada  jmp 0x000078D2E7BFE110
000078d2e7dcfadf  int3
000078d2e7dcfae0  call 0x000078D2E7C0D860
000078d2e7dcfae5  jmp 0x000078D2E7DCF17A
000078d2e7dcfaea  call 0x000078D2E7CE2420
000078d2e7dcfaef  jmp 0x000078D2E7DCF193
000078d2e7dcfaf4  call 0x000078D2E7CE2420
000078d2e7dcfaf9  jmp 0x000078D2E7DCF1AC
000078d2e7dcfafe  call 0x000078D2E7CE2420
000078d2e7dcfb03  jmp 0x000078D2E7DCF1C5
000078d2e7dcfb08  call 0x000078D2E7CE2420
000078d2e7dcfb0d  jmp 0x000078D2E7DCF1DE
000078d2e7dcfb12  call 0x000078D2E7CE2420
000078d2e7dcfb17  jmp 0x000078D2E7DCF1EF
000078d2e7dcfb1c  call 0x000078D2E7CE2420
000078d2e7dcfb21  jmp 0x000078D2E7DCF200
000078d2e7dcfb26  call 0x000078D2E7CE2420
000078d2e7dcfb2b  jmp 0x000078D2E7DCF211
000078d2e7dcfb30  call 0x000078D2E7CE2420
000078d2e7dcfb35  jmp 0x000078D2E7DCF222
000078d2e7dcfb3a  call 0x000078D2E7CE2420
000078d2e7dcfb3f  jmp 0x000078D2E7DCF233
000078d2e7dcfb44  call 0x000078D2E7CE2420
000078d2e7dcfb49  jmp 0x000078D2E7DCF244
000078d2e7dcfb4e  call 0x000078D2E7CE2420
000078d2e7dcfb53  jmp 0x000078D2E7DCF255
000078d2e7dcfb58  call 0x000078D2E7CE2420
000078d2e7dcfb5d  jmp 0x000078D2E7DCF266
000078d2e7dcfb62  call 0x000078D2E7CE2420
000078d2e7dcfb67  jmp 0x000078D2E7DCF277
000078d2e7dcfb6c  call 0x000078D2E7CE2420
000078d2e7dcfb71  jmp 0x000078D2E7DCF288
000078d2e7dcfb76  call 0x000078D2E7CE2420
000078d2e7dcfb7b  jmp 0x000078D2E7DCF299
000078d2e7dcfb80  call 0x000078D2E7CE2420
000078d2e7dcfb85  jmp 0x000078D2E7DCF2AA
000078d2e7dcfb8a  call 0x000078D2E7CE2420
000078d2e7dcfb8f  jmp 0x000078D2E7DCF2BB
000078d2e7dcfb94  call 0x000078D2E7CE2420
000078d2e7dcfb99  jmp 0x000078D2E7DCF2CC
000078d2e7dcfb9e  call 0x000078D2E7CE2420
000078d2e7dcfba3  jmp 0x000078D2E7DCF2DD
000078d2e7dcfba8  call 0x000078D2E7CE2420
000078d2e7dcfbad  jmp 0x000078D2E7DCF2EE
000078d2e7dcfbb2  call 0x000078D2E7CE2420
000078d2e7dcfbb7  jmp 0x000078D2E7DCF2FF
000078d2e7dcfbbc  call 0x000078D2E7CE2420
000078d2e7dcfbc1  jmp 0x000078D2E7DCF310
000078d2e7dcfbc6  call 0x000078D2E7CE2420
000078d2e7dcfbcb  jmp 0x000078D2E7DCF321
000078d2e7dcfbd0  call 0x000078D2E7CE2420
000078d2e7dcfbd5  jmp 0x000078D2E7DCF332
000078d2e7dcfbda  call 0x000078D2E7CE2420
000078d2e7dcfbdf  jmp 0x000078D2E7DCF343
000078d2e7dcfbe4  call 0x000078D2E7CE2420
000078d2e7dcfbe9  jmp 0x000078D2E7DCF354
000078d2e7dcfbee  call 0x000078D2E7CE2420
000078d2e7dcfbf3  jmp 0x000078D2E7DCF365
000078d2e7dcfbf8  call 0x000078D2E7CE2420
000078d2e7dcfbfd  jmp 0x000078D2E7DCF376
000078d2e7dcfc02  call 0x000078D2E7CE2420
000078d2e7dcfc07  jmp 0x000078D2E7DCF387
000078d2e7dcfc0c  call 0x000078D2E7CE2420
000078d2e7dcfc11  jmp 0x000078D2E7DCF398
000078d2e7dcfc16  call 0x000078D2E7CE2420
000078d2e7dcfc1b  jmp 0x000078D2E7DCF3A9
000078d2e7dcfc20  call 0x000078D2E7CE2420
000078d2e7dcfc25  jmp 0x000078D2E7DCF3BA
000078d2e7dcfc2a  call 0x000078D2E7CE2420
000078d2e7dcfc2f  jmp 0x000078D2E7DCF3CB
000078d2e7dcfc34  call 0x000078D2E7CE2420
000078d2e7dcfc39  jmp 0x000078D2E7DCF3DC
000078d2e7dcfc3e  call 0x000078D2E7CE2420
000078d2e7dcfc43  jmp 0x000078D2E7DCF3ED
000078d2e7dcfc48  call 0x000078D2E7CE2420
000078d2e7dcfc4d  jmp 0x000078D2E7DCF3FE
000078d2e7dcfc52  call 0x000078D2E7CE2420
000078d2e7dcfc57  jmp 0x000078D2E7DCF40F
000078d2e7dcfc5c  call 0x000078D2E7CE2420
000078d2e7dcfc61  jmp 0x000078D2E7DCF420
000078d2e7dcfc66  call 0x000078D2E7CE2420
000078d2e7dcfc6b  jmp 0x000078D2E7DCF431
000078d2e7dcfc70  call 0x000078D2E7CE2420
000078d2e7dcfc75  jmp 0x000078D2E7DCF442
000078d2e7dcfc7a  call 0x000078D2E7CE2420
000078d2e7dcfc7f  jmp 0x000078D2E7DCF453
000078d2e7dcfc84  call 0x000078D2E7CE2420
000078d2e7dcfc89  jmp 0x000078D2E7DCF464
000078d2e7dcfc8e  call 0x000078D2E7CE2420
000078d2e7dcfc93  jmp 0x000078D2E7DCF475
000078d2e7dcfc98  call 0x000078D2E7CE2420
000078d2e7dcfc9d  jmp 0x000078D2E7DCF486
000078d2e7dcfca2  call 0x000078D2E7CE2420
000078d2e7dcfca7  jmp 0x000078D2E7DCF497
000078d2e7dcfcac  call 0x000078D2E7CE2420
000078d2e7dcfcb1  jmp 0x000078D2E7DCF4A8
000078d2e7dcfcb6  call 0x000078D2E7CE2420
000078d2e7dcfcbb  jmp 0x000078D2E7DCF4B9
000078d2e7dcfcc0  call 0x000078D2E7CE2420
000078d2e7dcfcc5  jmp 0x000078D2E7DCF4CA
000078d2e7dcfcca  call 0x000078D2E7CE2420
000078d2e7dcfccf  jmp 0x000078D2E7DCF4DB
000078d2e7dcfcd4  call 0x000078D2E7CE2420
000078d2e7dcfcd9  jmp 0x000078D2E7DCF4EC
000078d2e7dcfcde  call 0x000078D2E7CE2420
000078d2e7dcfce3  jmp 0x000078D2E7DCF4FD
000078d2e7dcfce8  call 0x000078D2E7CE2420
000078d2e7dcfced  jmp 0x000078D2E7DCF50E
000078d2e7dcfcf2  call 0x000078D2E7CE2420
000078d2e7dcfcf7  jmp 0x000078D2E7DCF51F
000078d2e7dcfcfc  call 0x000078D2E7CE2420
000078d2e7dcfd01  jmp 0x000078D2E7DCF530
000078d2e7dcfd06  call 0x000078D2E7CE2420
000078d2e7dcfd0b  jmp 0x000078D2E7DCF541
000078d2e7dcfd10  call 0x000078D2E7CE2420
000078d2e7dcfd15  jmp 0x000078D2E7DCF552
000078d2e7dcfd1a  call 0x000078D2E7CE2420
000078d2e7dcfd1f  jmp 0x000078D2E7DCF563
000078d2e7dcfd24  call 0x000078D2E7CE2420
000078d2e7dcfd29  jmp 0x000078D2E7DCF574
000078d2e7dcfd2e  call 0x000078D2E7CE2420
000078d2e7dcfd33  jmp 0x000078D2E7DCF585
000078d2e7dcfd38  call 0x000078D2E7CE2420
000078d2e7dcfd3d  jmp 0x000078D2E7DCF596
000078d2e7dcfd42  call 0x000078D2E7CE2420
000078d2e7dcfd47  jmp 0x000078D2E7DCF5AF
000078d2e7dcfd4c  call 0x000078D2E7CE2420
000078d2e7dcfd51  jmp 0x000078D2E7DCF5C8
000078d2e7dcfd56  call 0x000078D2E7CD5610
000078d2e7dcfd5b  jmp 0x000078D2E7DCF5E1
000078d2e7dcfd60  call 0x000078D2E7CDC580
000078d2e7dcfd65  jmp 0x000078D2E7DCF94E
000078d2e7dcfd6a  call 0x000078D2E7CE46C0
000078d2e7dcfd6f  jmp 0x000078D2E7DCF958
000078d2e7dcfd74  call 0x000078D2E7C09E90
000078d2e7dcfd79  jmp 0x000078D2E7DCF95E
000078d2e7dcfd7e  call 0x000078D2E7CDB310
000078d2e7dcfd83  jmp 0x000078D2E7DCF968
000078d2e7dcfd88  call 0x000078D2E7C0DAE0
000078d2e7dcfd8d  jmp 0x000078D2E7DCF96D
000078d2e7dcfd92  call 0x000078D2E7CC0230
000078d2e7dcfd97  jmp 0x000078D2E7DCF986
000078d2e7dcfd9c  call 0x000078D2E7CC0230
000078d2e7dcfda1  jmp 0x000078D2E7DCF99B
000078d2e7dcfda6  call 0x000078D2E7CBEFC0
000078d2e7dcfdab  jmp 0x000078D2E7DCF9A4
000078d2e7dcfdb0  call 0x000078D2E7CE2BA0
000078d2e7dcfdb5  jmp 0x000078D2E7DCFA6B
000078d2e7dcfdba  int3
000078d2e7dcfdbb  nop [rax+rax*1], eax
000078d2e7dcfdc0  mov rax, [r15+0x48]
000078d2e7dcfdc4  mov r14, [r15+0x58]
000078d2e7dcfdc8  lea r12, [rax+r14*1]
000078d2e7dcfdcc  mov [r15+0x68], r12
000078d2e7dcfdd0  lea rax, [r14+0x04]
000078d2e7dcfdd4  mov [r15+0x58], rax
000078d2e7dcfdd8  lea r14, [r12+0x04]
000078d2e7dcfddd  mov r11d, [r13+r14*1]
000078d2e7dcfde2  mov [rsp+0x10], r11d
000078d2e7dcfde7  mov r11d, r11d
000078d2e7dcfdea  mov [r15+0x70], r11
000078d2e7dcfdee  lea r14, [r12+0x38]
000078d2e7dcfdf3  mov r11d, [r13+r14*1]
000078d2e7dcfdf8  lea r14, [r12+0x24]
000078d2e7dcfdfd  mov r10d, [r13+r14*1]
000078d2e7dcfe02  mov [rsp+0x20], r10d
000078d2e7dcfe07  mov r10d, r10d
000078d2e7dcfe0a  mov [r15+0x90], r10
000078d2e7dcfe11  mov [rsp+0x30], rax
000078d2e7dcfe16  xor eax, eax
000078d2e7dcfe18  mov r14, [rsp+0x30]
000078d2e7dcfe1d  mov r10d, 0xC0
000078d2e7dcfe23  cmp r14, r10
000078d2e7dcfe26  cmc
000078d2e7dcfe27  lahf
000078d2e7dcfe28  seto al
000078d2e7dcfe2b  mov [r15+0x108], eax
000078d2e7dcfe32  mov eax, [rsp+0x10]
000078d2e7dcfe36  mov r14d, [rsp+0x10]
000078d2e7dcfe3b  shrd eax, r14d, 0x07
000078d2e7dcfe40  mov [rsp+0x10], r11d
000078d2e7dcfe45  mov r10d, [rsp+0x10]
000078d2e7dcfe4a  shrd r11d, r10d, 0x11
000078d2e7dcfe4f  mov r9d, [r15+0x60]
000078d2e7dcfe53  mov r8d, [rsp+0x20]
000078d2e7dcfe58  lea ebp, [r8d+r9d*1]
000078d2e7dcfe5d  rorx r9d, r14d, 0x12
000078d2e7dcfe63  xor eax, r9d
000078d2e7dcfe66  rorx r9d, r10d, 0x13
000078d2e7dcfe6c  xor r11d, r9d
000078d2e7dcfe6f  mov [rsp+0x10], r11d
000078d2e7dcfe74  mov r11d, r11d
000078d2e7dcfe77  mov [r15+0x88], r11
000078d2e7dcfe7e  mov [rsp+0x20], r14d
000078d2e7dcfe83  shr r14d, 0x03
000078d2e7dcfe87  xor eax, r14d
000078d2e7dcfe8a  mov [rsp+0x30], eax
000078d2e7dcfe8e  mov eax, eax
000078d2e7dcfe90  mov [r15+0x80], rax
000078d2e7dcfe97  shr r10d, 0x0A
000078d2e7dcfe9b  mov eax, [rsp+0x10]
000078d2e7dcfe9f  xor eax, r10d
000078d2e7dcfea2  mov [rsp+0x10], eax
000078d2e7dcfea6  mov eax, eax
000078d2e7dcfea8  mov [r15+0x78], rax
000078d2e7dcfeac  mov eax, [rsp+0x30]
000078d2e7dcfeb0  lea r14d, [ebp+eax*1]
000078d2e7dcfeb6  mov eax, [rsp+0x10]
000078d2e7dcfeba  lea r11d, [r14d+eax*1]
000078d2e7dcfebf  lea rax, [r12+0x40]
000078d2e7dcfec4  mov [r13+rax*1], r11d
000078d2e7dcfec9  mov eax, [rsp+0x20]
000078d2e7dcfecd  mov eax, eax
000078d2e7dcfecf  mov [r15+0x60], rax
000078d2e7dcfed3  mov eax, [r15+0x108]
000078d2e7dcfeda  sahf
000078d2e7dcfedb  jnz 0x000078D2E7DCFF0D
000078d2e7dcfedd  cmp dword ptr [r15+0x318], 0x00
000078d2e7dcfee5  jz 0x000078D2E7DCFF70
000078d2e7dcfeeb  nop [rax+rax*1], ax
000078d2e7dcfef4  nop [rax+rax*1], eax
000078d2e7dcfefc  mov eax, 0x41088C
000078d2e7dcff01  mov [r15+0x100], rax
000078d2e7dcff08  jmp 0x000078D2E7BFE110
000078d2e7dcff0d  cmp dword ptr [r15+0x318], 0x00
000078d2e7dcff15  jz 0x000078D2E7DCFDC0
000078d2e7dcff1b  nop [rax+rax*1], ax
000078d2e7dcff24  nop [rax+rax*1], eax
000078d2e7dcff2c  mov eax, 0x410844
000078d2e7dcff31  mov [r15+0x100], rax
000078d2e7dcff38  jmp 0x000078D2E7BFE110
000078d2e7dcff3d  int3
000078d2e7dcff3e  call 0x000078D2E7CE1430
000078d2e7dcff43  jmp 0x000078D2E7DCFDE2
000078d2e7dcff48  call 0x000078D2E7CE1430
000078d2e7dcff4d  jmp 0x000078D2E7DCFDF8
000078d2e7dcff52  call 0x000078D2E7CE01C0
000078d2e7dcff57  jmp 0x000078D2E7DCFE02
000078d2e7dcff5c  call 0x000078D2E7C0A860
000078d2e7dcff61  jmp 0x000078D2E7DCFEC9
000078d2e7dcff66  int3
000078d2e7dcff67  nop [rax+rax*1], ax
000078d2e7dcff70  mov rax, [r15]
000078d2e7dcff73  mov r14d, [r13+rax*1]
000078d2e7dcff78  lea r12, [rax+0x04]
000078d2e7dcff7c  mov r11d, [r13+r12*1]
000078d2e7dcff81  mov [rsp+0x10], r14d
000078d2e7dcff86  mov r14d, r14d
000078d2e7dcff89  mov [r15+0x78], r14
000078d2e7dcff8d  mov [rsp+0x20], r11d
000078d2e7dcff92  mov r11d, r11d
000078d2e7dcff95  mov [r15+0x80], r11
000078d2e7dcff9c  lea r14, [rax+0x08]
000078d2e7dcffa0  mov r12d, [r13+r14*1]
000078d2e7dcffa5  lea r14, [rax+0x0C]
000078d2e7dcffa9  mov r11d, [r13+r14*1]
000078d2e7dcffae  mov [rsp+0x30], r12d
000078d2e7dcffb3  mov r12d, r12d
000078d2e7dcffb6  mov [r15+0x70], r12
000078d2e7dcffba  mov [rsp+0x40], r11d
000078d2e7dcffbf  mov r11d, r11d
000078d2e7dcffc2  mov [r15+0x68], r11
000078d2e7dcffc6  lea r14, [rax+0x18]
000078d2e7dcffca  mov r12d, [r13+r14*1]
000078d2e7dcffcf  lea r14, [rax+0x1C]
000078d2e7dcffd3  mov r11d, [r13+r14*1]
000078d2e7dcffd8  mov [rsp+0x50], r12d
000078d2e7dcffdd  mov r12d, r12d
000078d2e7dcffe0  mov [r15+0x58], r12
000078d2e7dcffe4  mov [rsp+0x60], r11d
000078d2e7dcffe9  mov r11d, r11d
000078d2e7dcffec  mov [r15+0x60], r11
000078d2e7dcfff0  lea r14, [rax+0x10]
000078d2e7dcfff4  mov r12d, [r13+r14*1]
000078d2e7dcfff9  lea r14, [rax+0x14]
000078d2e7dcfffd  mov eax, [r13+r14*1]
000078d2e7dd0002  mov [rsp+0x70], r12d
000078d2e7dd0007  mov r12d, r12d
000078d2e7dd000a  mov [r15+0x18], r12
000078d2e7dd000e  mov [rsp+0x80], eax
000078d2e7dd0015  mov eax, eax
000078d2e7dd0017  mov [r15+0x90], rax
000078d2e7dd001e  mov eax, [rsp+0x70]
000078d2e7dd0022  mov eax, eax
000078d2e7dd0024  mov [r15+0x30], rax
000078d2e7dd0028  mov eax, [rsp+0x50]
000078d2e7dd002c  mov eax, eax
000078d2e7dd002e  mov [r15+0xA0], rax
000078d2e7dd0035  mov eax, [rsp+0x30]
000078d2e7dd0039  mov eax, eax
000078d2e7dd003b  mov [r15+0x28], rax
000078d2e7dd003f  mov eax, [rsp+0x20]
000078d2e7dd0043  mov eax, eax
000078d2e7dd0045  mov [r15+0x98], rax
000078d2e7dd004c  mov eax, [rsp+0x10]
000078d2e7dd0050  mov eax, eax
000078d2e7dd0052  mov [r15+0x38], rax
000078d2e7dd0056  mov eax, [rsp+0x70]
000078d2e7dd005a  mov r14d, [rsp+0x70]
000078d2e7dd005f  shrd eax, r14d, 0x06
000078d2e7dd0064  mov [rsp+0x70], r14d
000078d2e7dd0069  mov r12d, [rsp+0x80]
000078d2e7dd0071  and r14d, r12d
000078d2e7dd0074  mov r11d, [rsp+0x10]
000078d2e7dd0079  mov r10d, [rsp+0x10]
000078d2e7dd007e  shrd r11d, r10d, 0x02
000078d2e7dd0083  mov [rsp+0x10], r12d
000078d2e7dd0088  mov r12d, r12d
000078d2e7dd008b  mov [r15+0x20], r12
000078d2e7dd008f  mov r12, [r15+0x50]
000078d2e7dd0093  mov r9d, [r13+r12*1]
000078d2e7dd0098  mov r12d, [rsp+0x50]
000078d2e7dd009d  mov r8d, [rsp+0x70]
000078d2e7dd00a2  andn ebp, r8d, r12d
000078d2e7dd00a7  mov edi, [rsp+0x60]
000078d2e7dd00ab  lea esi, [r14d+edi*1]
000078d2e7dd00b0  rorx r14d, r8d, 0x0B
000078d2e7dd00b6  xor eax, r14d
000078d2e7dd00b9  rorx r14d, r10d, 0x0D
000078d2e7dd00bf  xor r11d, r14d
000078d2e7dd00c2  lea edi, [esi+ebp*1]
000078d2e7dd00c6  mov r14, [r15+0x48]
000078d2e7dd00ca  mov ebp, [r13+r14*1]
000078d2e7dd00cf  mov r14d, [rsp+0x30]
000078d2e7dd00d4  mov esi, [rsp+0x20]
000078d2e7dd00d8  and r14d, esi
000078d2e7dd00db  mov [rsp+0x20], r14d
000078d2e7dd00e0  mov r14d, r14d
000078d2e7dd00e3  mov [r15+0xD8], r14
000078d2e7dd00ea  lea r14d, [edi+r9d*1]
000078d2e7dd00ef  mov r9d, [rsp+0x30]
000078d2e7dd00f4  xor r9d, esi
000078d2e7dd00f7  rorx edi, r8d, 0x19
000078d2e7dd00fd  xor eax, edi
000078d2e7dd00ff  and r9d, r10d
000078d2e7dd0102  rorx edi, r10d, 0x16
000078d2e7dd0108  xor r11d, edi
000078d2e7dd010b  mov [rsp+0x30], r11d
000078d2e7dd0110  mov r11d, r11d
000078d2e7dd0113  mov [r15+0xD0], r11
000078d2e7dd011a  lea r11d, [r14d+ebp*1]
000078d2e7dd011f  mov r10d, [rsp+0x20]
000078d2e7dd0124  xor r9d, r10d
000078d2e7dd0127  lea r14d, [r11d+eax*1]
000078d2e7dd012c  mov qword ptr [r15+0x88], 0x04
000078d2e7dd0137  mov eax, [rsp+0x30]
000078d2e7dd013b  lea r11d, [r9d+eax*1]
000078d2e7dd0140  mov eax, [rsp+0x40]
000078d2e7dd0144  lea r10d, [r14d+eax*1]
000078d2e7dd0149  mov r10d, r10d
000078d2e7dd014c  mov [r15+0xB8], r10
000078d2e7dd0153  xor eax, eax
000078d2e7dd0155  mov r10d, 0x04
000078d2e7dd015b  mov r9d, 0x100
000078d2e7dd0161  cmp r10, r9
000078d2e7dd0164  cmc
000078d2e7dd0165  lahf
000078d2e7dd0166  seto al
000078d2e7dd0169  mov [r15+0x108], eax
000078d2e7dd0170  lea eax, [r11d+r14d*1]
000078d2e7dd0175  mov eax, eax
000078d2e7dd0177  mov [r15+0xA8], rax
000078d2e7dd017e  mov r12d, r12d
000078d2e7dd0181  mov [r15+0xB0], r12
000078d2e7dd0188  mov eax, [rsp+0x10]
000078d2e7dd018c  mov eax, eax
000078d2e7dd018e  mov [r15+0xC0], rax
000078d2e7dd0195  mov r8d, r8d
000078d2e7dd0198  mov [r15+0xC8], r8
000078d2e7dd019f  mov eax, [r15+0x108]
000078d2e7dd01a6  sahf
000078d2e7dd01a7  jnz 0x000078D2E7DD01D9
000078d2e7dd01a9  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd01b1  jz 0x000078D2E7DD04A0
000078d2e7dd01b7  nop [rax+rax*1], ax
000078d2e7dd01c0  nop [rax+rax*1], eax
000078d2e7dd01c8  mov eax, 0x41094C
000078d2e7dd01cd  mov [r15+0x100], rax
000078d2e7dd01d4  jmp 0x000078D2E7BFE110
000078d2e7dd01d9  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd01e1  jz 0x000078D2E7DD0270
000078d2e7dd01e7  nop [rax+rax*1], ax
000078d2e7dd01f0  nop [rax+rax*1], eax
000078d2e7dd01f8  mov eax, 0x4108C0
000078d2e7dd01fd  mov [r15+0x100], rax
000078d2e7dd0204  jmp 0x000078D2E7BFE110
000078d2e7dd0209  int3
000078d2e7dd020a  call 0x000078D2E7C0DAE0
000078d2e7dd020f  jmp 0x000078D2E7DCFF78
000078d2e7dd0214  call 0x000078D2E7CC0230
000078d2e7dd0219  jmp 0x000078D2E7DCFF81
000078d2e7dd021e  call 0x000078D2E7CE26A0
000078d2e7dd0223  jmp 0x000078D2E7DCFFA5
000078d2e7dd0228  call 0x000078D2E7CE1430
000078d2e7dd022d  jmp 0x000078D2E7DCFFAE
000078d2e7dd0232  call 0x000078D2E7CE26A0
000078d2e7dd0237  jmp 0x000078D2E7DCFFCF
000078d2e7dd023c  call 0x000078D2E7CE1430
000078d2e7dd0241  jmp 0x000078D2E7DCFFD8
000078d2e7dd0246  call 0x000078D2E7CE26A0
000078d2e7dd024b  jmp 0x000078D2E7DCFFF9
000078d2e7dd0250  call 0x000078D2E7CD5890
000078d2e7dd0255  jmp 0x000078D2E7DD0002
000078d2e7dd025a  call 0x000078D2E7CBDD50
000078d2e7dd025f  jmp 0x000078D2E7DD0098
000078d2e7dd0264  call 0x000078D2E7CDA580
000078d2e7dd0269  jmp 0x000078D2E7DD00CF
000078d2e7dd026e  int3
000078d2e7dd026f  nop
000078d2e7dd0270  mov eax, [r15+0xB8]
000078d2e7dd0277  mov [rsp+0x10], eax
000078d2e7dd027b  mov eax, eax
000078d2e7dd027d  mov [r15+0x30], rax
000078d2e7dd0281  mov eax, [r15+0xC0]
000078d2e7dd0288  mov [rsp+0x20], eax
000078d2e7dd028c  mov eax, eax
000078d2e7dd028e  mov [r15+0xA0], rax
000078d2e7dd0295  mov eax, [r15+0x28]
000078d2e7dd0299  mov r14d, [r15+0x98]
000078d2e7dd02a0  mov [rsp+0x30], r14d
000078d2e7dd02a5  mov r14d, r14d
000078d2e7dd02a8  mov [r15+0x28], r14
000078d2e7dd02ac  mov r14d, [r15+0x38]
000078d2e7dd02b0  mov [rsp+0x40], r14d
000078d2e7dd02b5  mov r14d, r14d
000078d2e7dd02b8  mov [r15+0x98], r14
000078d2e7dd02bf  mov r14d, [r15+0xA8]
000078d2e7dd02c6  mov [rsp+0x50], r14d
000078d2e7dd02cb  mov r14d, r14d
000078d2e7dd02ce  mov [r15+0x38], r14
000078d2e7dd02d2  mov r14d, [rsp+0x10]
000078d2e7dd02d7  mov r12d, [rsp+0x10]
000078d2e7dd02dc  shrd r14d, r12d, 0x06
000078d2e7dd02e1  mov r11d, [r15+0xC8]
000078d2e7dd02e8  mov [rsp+0x10], r12d
000078d2e7dd02ed  and r12d, r11d
000078d2e7dd02f0  mov r10d, [rsp+0x50]
000078d2e7dd02f5  mov r9d, [rsp+0x50]
000078d2e7dd02fa  shrd r10d, r9d, 0x02
000078d2e7dd02ff  mov [rsp+0x50], r11d
000078d2e7dd0304  mov r11d, r11d
000078d2e7dd0307  mov [r15+0x20], r11
000078d2e7dd030b  mov r11, [r15+0x88]
000078d2e7dd0312  mov r8, [r15+0x50]
000078d2e7dd0316  lea rbp, [r8+r11*1]
000078d2e7dd031a  mov r8d, [r13+rbp*1]
000078d2e7dd031f  mov ebp, [rsp+0x20]
000078d2e7dd0323  mov edi, [rsp+0x10]
000078d2e7dd0327  andn esi, edi, ebp
000078d2e7dd032c  mov edx, [r15+0xB0]
000078d2e7dd0333  lea ecx, [r12d+edx*1]
000078d2e7dd0338  rorx r12d, edi, 0x0B
000078d2e7dd033e  xor r14d, r12d
000078d2e7dd0341  rorx r12d, r9d, 0x0D
000078d2e7dd0347  xor r10d, r12d
000078d2e7dd034a  lea r12d, [ecx+esi*1]
000078d2e7dd034f  mov rsi, [r15+0x48]
000078d2e7dd0353  lea rdx, [rsi+r11*1]
000078d2e7dd0357  mov esi, [r13+rdx*1]
000078d2e7dd035c  mov edx, [rsp+0x30]
000078d2e7dd0360  mov ecx, [rsp+0x40]
000078d2e7dd0364  and edx, ecx
000078d2e7dd0366  mov [rsp+0x10], edx
000078d2e7dd036a  mov edx, edx
000078d2e7dd036c  mov [r15+0xD8], rdx
000078d2e7dd0373  lea edx, [r12d+r8d*1]
000078d2e7dd0378  mov r12d, [rsp+0x30]
000078d2e7dd037d  xor r12d, ecx
000078d2e7dd0380  rorx r8d, edi, 0x19
000078d2e7dd0386  xor r14d, r8d
000078d2e7dd0389  and r12d, r9d
000078d2e7dd038c  rorx r8d, r9d, 0x16
000078d2e7dd0392  xor r10d, r8d
000078d2e7dd0395  mov [rsp+0x20], r10d
000078d2e7dd039a  mov r10d, r10d
000078d2e7dd039d  mov [r15+0xD0], r10
000078d2e7dd03a4  lea r10d, [edx+esi*1]
000078d2e7dd03a9  mov r9d, [rsp+0x10]
000078d2e7dd03ae  xor r12d, r9d
000078d2e7dd03b1  lea r9d, [r10d+r14d*1]
000078d2e7dd03b6  lea r14, [r11+0x04]
000078d2e7dd03ba  mov [r15+0x88], r14
000078d2e7dd03c1  mov r11d, [rsp+0x20]
000078d2e7dd03c6  lea r10d, [r12d+r11d*1]
000078d2e7dd03cb  lea r11d, [r9d+eax*1]
000078d2e7dd03d0  mov r11d, r11d
000078d2e7dd03d3  mov [r15+0xB8], r11
000078d2e7dd03da  xor eax, eax
000078d2e7dd03dc  mov r12d, 0x100
000078d2e7dd03e2  cmp r14, r12
000078d2e7dd03e5  cmc
000078d2e7dd03e6  lahf
000078d2e7dd03e7  seto al
000078d2e7dd03ea  mov [r15+0x108], eax
000078d2e7dd03f1  lea eax, [r10d+r9d*1]
000078d2e7dd03f6  mov eax, eax
000078d2e7dd03f8  mov [r15+0xA8], rax
000078d2e7dd03ff  mov ebp, ebp
000078d2e7dd0401  mov [r15+0xB0], rbp
000078d2e7dd0408  mov eax, [rsp+0x50]
000078d2e7dd040c  mov eax, eax
000078d2e7dd040e  mov [r15+0xC0], rax
000078d2e7dd0415  mov edi, edi
000078d2e7dd0417  mov [r15+0xC8], rdi
000078d2e7dd041e  mov eax, [r15+0x108]
000078d2e7dd0425  sahf
000078d2e7dd0426  jnz 0x000078D2E7DD0458
000078d2e7dd0428  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd0430  jz 0x000078D2E7DD04A0
000078d2e7dd0436  nop [rax+rax*1], ax
000078d2e7dd043f  nop [rax+rax*1], eax
000078d2e7dd0447  mov eax, 0x41094C
000078d2e7dd044c  mov [r15+0x100], rax
000078d2e7dd0453  jmp 0x000078D2E7BFE110
000078d2e7dd0458  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd0460  jz 0x000078D2E7DD0270
000078d2e7dd0466  nop [rax+rax*1], ax
000078d2e7dd046f  nop [rax+rax*1], eax
000078d2e7dd0477  mov eax, 0x4108C0
000078d2e7dd047c  mov [r15+0x100], rax
000078d2e7dd0483  jmp 0x000078D2E7BFE110
000078d2e7dd0488  int3
000078d2e7dd0489  call 0x000078D2E7C49010
000078d2e7dd048e  jmp 0x000078D2E7DD031F
000078d2e7dd0493  call 0x000078D2E7C25930
000078d2e7dd0498  jmp 0x000078D2E7DD035C
000078d2e7dd049d  int3
000078d2e7dd049e  nop
000078d2e7dd04a0  mov eax, [r15+0x98]
000078d2e7dd04a7  mov r14d, [r15+0x70]
000078d2e7dd04ab  lea r12d, [eax+r14d*1]
000078d2e7dd04b0  mov eax, [r15+0x28]
000078d2e7dd04b4  mov r14d, [r15+0x68]
000078d2e7dd04b8  lea r11d, [eax+r14d*1]
000078d2e7dd04bd  mov qword ptr [r15+0x88], 0x00
000078d2e7dd04c8  mov eax, [r15+0xA8]
000078d2e7dd04cf  mov r14d, [r15+0x78]
000078d2e7dd04d3  lea r10d, [eax+r14d*1]
000078d2e7dd04d8  mov [rsp+0x10], r10d
000078d2e7dd04dd  mov r10d, r10d
000078d2e7dd04e0  mov [r15+0x78], r10
000078d2e7dd04e4  mov eax, [r15+0x38]
000078d2e7dd04e8  mov r14d, [r15+0x80]
000078d2e7dd04ef  lea r10d, [eax+r14d*1]
000078d2e7dd04f4  mov [rsp+0x20], r10d
000078d2e7dd04f9  mov r10d, r10d
000078d2e7dd04fc  mov [r15+0x80], r10
000078d2e7dd0503  mov rax, [r15]
000078d2e7dd0506  lea r14, [rax+0x08]
000078d2e7dd050a  mov [r13+r14*1], r12d
000078d2e7dd050f  lea r14, [rax+0x0C]
000078d2e7dd0513  mov [r13+r14*1], r11d
000078d2e7dd0518  mov r14d, [r15+0xB8]
000078d2e7dd051f  mov r12d, [r15+0x18]
000078d2e7dd0523  lea r11d, [r14d+r12d*1]
000078d2e7dd0528  mov [rsp+0x30], r11d
000078d2e7dd052d  mov r11d, r11d
000078d2e7dd0530  mov [r15+0x68], r11
000078d2e7dd0534  mov r14d, [r15+0x30]
000078d2e7dd0538  mov r12d, [r15+0x90]
000078d2e7dd053f  lea r11d, [r14d+r12d*1]
000078d2e7dd0544  mov [rsp+0x40], r11d
000078d2e7dd0549  mov r11d, r11d
000078d2e7dd054c  mov [r15+0x70], r11
000078d2e7dd0550  mov r14d, [r15+0x20]
000078d2e7dd0554  mov r12d, [r15+0x58]
000078d2e7dd0558  lea r11d, [r14d+r12d*1]
000078d2e7dd055d  mov [rsp+0x50], r11d
000078d2e7dd0562  mov r11d, r11d
000078d2e7dd0565  mov [r15+0x58], r11
000078d2e7dd0569  mov r14d, [r15+0xA0]
000078d2e7dd0570  mov r12d, [r15+0x60]
000078d2e7dd0574  lea r11d, [r14d+r12d*1]
000078d2e7dd0579  mov [rsp+0x60], r11d
000078d2e7dd057e  mov r11d, r11d
000078d2e7dd0581  mov [r15+0x60], r11
000078d2e7dd0585  mov r14d, [rsp+0x10]
000078d2e7dd058a  mov [r13+rax*1], r14d
000078d2e7dd058f  lea r14, [rax+0x04]
000078d2e7dd0593  mov r12d, [rsp+0x20]
000078d2e7dd0598  mov [r13+r14*1], r12d
000078d2e7dd059d  lea r14, [rax+0x10]
000078d2e7dd05a1  mov r12d, [rsp+0x30]
000078d2e7dd05a6  mov [r13+r14*1], r12d
000078d2e7dd05ab  lea r14, [rax+0x14]
000078d2e7dd05af  mov r12d, [rsp+0x40]
000078d2e7dd05b4  mov [r13+r14*1], r12d
000078d2e7dd05b9  lea r14, [rax+0x18]
000078d2e7dd05bd  mov r12d, [rsp+0x50]
000078d2e7dd05c2  mov [r13+r14*1], r12d
000078d2e7dd05c7  lea r14, [rax+0x1C]
000078d2e7dd05cb  mov r12d, [rsp+0x60]
000078d2e7dd05d0  mov [r13+r14*1], r12d
000078d2e7dd05d5  lea r14, [rax+0x68]
000078d2e7dd05d9  xor eax, eax
000078d2e7dd05db  mov [r13+r14*1], rax
000078d2e7dd05e0  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd05e8  jz 0x000078D2E7DCF0E0
000078d2e7dd05ee  nop [rax+rax*1], ax
000078d2e7dd05f7  nop [rax+rax*1], eax
000078d2e7dd05ff  mov eax, 0x410768
000078d2e7dd0604  mov [r15+0x100], rax
000078d2e7dd060b  jmp 0x000078D2E7BFE110
000078d2e7dd0610  int3
000078d2e7dd0611  call 0x000078D2E7CE2BA0
000078d2e7dd0616  jmp 0x000078D2E7DD050F
000078d2e7dd061b  call 0x000078D2E7CE1920
000078d2e7dd0620  jmp 0x000078D2E7DD0518
000078d2e7dd0625  call 0x000078D2E7C0DFE0
000078d2e7dd062a  jmp 0x000078D2E7DD058F
000078d2e7dd062f  call 0x000078D2E7CE2BA0
000078d2e7dd0634  jmp 0x000078D2E7DD059D
000078d2e7dd0639  call 0x000078D2E7CE2BA0
000078d2e7dd063e  jmp 0x000078D2E7DD05AB
000078d2e7dd0643  call 0x000078D2E7CE2BA0
000078d2e7dd0648  jmp 0x000078D2E7DD05B9
000078d2e7dd064d  call 0x000078D2E7CE2BA0
000078d2e7dd0652  jmp 0x000078D2E7DD05C7
000078d2e7dd0657  call 0x000078D2E7CE2BA0
000078d2e7dd065c  jmp 0x000078D2E7DD05D5
000078d2e7dd0661  call 0x000078D2E7CD5EB0
000078d2e7dd0666  jmp 0x000078D2E7DD05E0
000078d2e7dd066b  int3
000078d2e7dd066c  nop [rax], eax
000078d2e7dd0670  mov rax, [r15+0xF8]
000078d2e7dd0677  lea r14, [rax+0x140]
000078d2e7dd067e  mov r12, [r13+r14*1]
000078d2e7dd0683  lea r14, [rax+0x148]
000078d2e7dd068a  mov r11, [r13+r14*1]
000078d2e7dd068f  mov [r15+0xA0], r12
000078d2e7dd0696  mov [r15+0x98], r11
000078d2e7dd069d  lea r14, [rax+0x130]
000078d2e7dd06a4  mov r12, [r13+r14*1]
000078d2e7dd06a9  lea r14, [rax+0x138]
000078d2e7dd06b0  mov r11, [r13+r14*1]
000078d2e7dd06b5  mov [r15+0xB0], r12
000078d2e7dd06bc  mov [r15+0xA8], r11
000078d2e7dd06c3  lea r14, [rax+0x120]
000078d2e7dd06ca  mov r12, [r13+r14*1]
000078d2e7dd06cf  lea r14, [rax+0x128]
000078d2e7dd06d6  mov r11, [r13+r14*1]
000078d2e7dd06db  mov [r15+0xC0], r12
000078d2e7dd06e2  mov [r15+0xB8], r11
000078d2e7dd06e9  lea r14, [rax+0x110]
000078d2e7dd06f0  mov r12, [r13+r14*1]
000078d2e7dd06f5  lea r14, [rax+0x118]
000078d2e7dd06fc  mov r11, [r13+r14*1]
000078d2e7dd0701  mov [r15+0xD0], r12
000078d2e7dd0708  mov [r15+0xC8], r11
000078d2e7dd070f  lea r14, [rax+0x100]
000078d2e7dd0716  mov r12, [r13+r14*1]
000078d2e7dd071b  lea r14, [rax+0x108]
000078d2e7dd0722  mov r11, [r13+r14*1]
000078d2e7dd0727  mov [r15+0xE8], r12
000078d2e7dd072e  mov [r15+0xD8], r11
000078d2e7dd0735  lea r14, [rax+0x150]
000078d2e7dd073c  mov [r15+0xF8], r14
000078d2e7dd0743  mov rax, [r15+0xF0]
000078d2e7dd074a  mov [r15+0x100], rax
000078d2e7dd0751  jmp 0x000078D2E7DCE5C0
000078d2e7dd0756  int3
000078d2e7dd0757  call 0x000078D2E7CE27E0
000078d2e7dd075c  jmp 0x000078D2E7DD0683
000078d2e7dd0761  call 0x000078D2E7CE1570
000078d2e7dd0766  jmp 0x000078D2E7DD068F
000078d2e7dd076b  call 0x000078D2E7CE27E0
000078d2e7dd0770  jmp 0x000078D2E7DD06A9
000078d2e7dd0775  call 0x000078D2E7CE1570
000078d2e7dd077a  jmp 0x000078D2E7DD06B5
000078d2e7dd077f  call 0x000078D2E7CE27E0
000078d2e7dd0784  jmp 0x000078D2E7DD06CF
000078d2e7dd0789  call 0x000078D2E7CE1570
000078d2e7dd078e  jmp 0x000078D2E7DD06DB
000078d2e7dd0793  call 0x000078D2E7CE27E0
000078d2e7dd0798  jmp 0x000078D2E7DD06F5
000078d2e7dd079d  call 0x000078D2E7CE1570
000078d2e7dd07a2  jmp 0x000078D2E7DD0701
000078d2e7dd07a7  call 0x000078D2E7CE27E0
000078d2e7dd07ac  jmp 0x000078D2E7DD071B
000078d2e7dd07b1  call 0x000078D2E7CE1570
000078d2e7dd07b6  jmp 0x000078D2E7DD0727
000078d2e7dd07bb  int3
000078d2e7dd07bc  nop [rax], eax
000078d2e7dd07c0  mov eax, [r15+0xA0]
000078d2e7dd07c7  mov [rsp+0x10], eax
000078d2e7dd07cb  xor eax, eax
000078d2e7dd07cd  mov r14d, [rsp+0x10]
000078d2e7dd07d2  sub r14d, 0x01
000078d2e7dd07d6  cmc
000078d2e7dd07d7  lahf
000078d2e7dd07d8  seto al
000078d2e7dd07db  mov [r15+0x108], eax
000078d2e7dd07e2  mov r14d, r14d
000078d2e7dd07e5  mov [r15+0xA0], r14
000078d2e7dd07ec  mov eax, [r15+0x108]
000078d2e7dd07f3  sahf
000078d2e7dd07f4  jnz 0x000078D2E7DD0826
000078d2e7dd07f6  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd07fe  jz 0x000078D2E7DD0900
000078d2e7dd0804  nop [rax+rax*1], ax
000078d2e7dd080d  nop [rax+rax*1], eax
000078d2e7dd0815  mov eax, 0x41028C
000078d2e7dd081a  mov [r15+0x100], rax
000078d2e7dd0821  jmp 0x000078D2E7BFE110
000078d2e7dd0826  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd082e  jz 0x000078D2E7DD0860
000078d2e7dd0834  nop [rax+rax*1], ax
000078d2e7dd083d  nop [rax+rax*1], eax
000078d2e7dd0845  mov eax, 0x410274
000078d2e7dd084a  mov [r15+0x100], rax
000078d2e7dd0851  jmp 0x000078D2E7BFE110
000078d2e7dd0856  int3
000078d2e7dd0857  int3
000078d2e7dd0858  nop [rax+rax*1], eax
000078d2e7dd0860  mov rax, [r15+0xF8]
000078d2e7dd0867  lea r14, [rax+0x100]
000078d2e7dd086e  mov [r15], r14
000078d2e7dd0871  mov rax, [r15+0x98]
000078d2e7dd0878  mov [r15+0x08], rax
000078d2e7dd087c  mov qword ptr [r15+0x10], 0x12C
000078d2e7dd0884  mov qword ptr [r15+0xF0], 0x410284
000078d2e7dd088f  mov r14d, [r15+0x320]
000078d2e7dd0896  mov eax, 0x410284
000078d2e7dd089b  mov rcx, 0x78D2E7DD07C0
000078d2e7dd08a5  mov [r15+r14*8+0x328], rax
000078d2e7dd08ad  mov [r15+r14*8+0x368], rcx
000078d2e7dd08b5  add r14d, 0x01
000078d2e7dd08b9  and r14d, 0x07
000078d2e7dd08bd  mov [r15+0x320], r14d
000078d2e7dd08c4  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd08cc  jz 0x000078D2E7DCED70
000078d2e7dd08d2  nop [rax+rax*1], ax
000078d2e7dd08db  nop [rax+rax*1], eax
000078d2e7dd08e3  mov eax, 0x410728
000078d2e7dd08e8  mov [r15+0x100], rax
000078d2e7dd08ef  jmp 0x000078D2E7BFE110
000078d2e7dd08f4  int3
000078d2e7dd08f5  int3
000078d2e7dd08f6  nop [rax+rax*1], ax
000078d2e7dd08ff  nop
000078d2e7dd0900  mov rax, [r15+0xF8]
000078d2e7dd0907  lea r14, [rax+0x120]
000078d2e7dd090e  mov r12, [r13+r14*1]
000078d2e7dd0913  mov [r15+0x98], r12
000078d2e7dd091a  mov qword ptr [r15+0x40], 0x80
000078d2e7dd0922  lea r14, [rax+0x100]
000078d2e7dd0929  mov [r15], r14
000078d2e7dd092c  lea r14, [rax+0x17C]
000078d2e7dd0933  mov [r15+0x08], r14
000078d2e7dd0937  mov qword ptr [r15+0x10], 0x01
000078d2e7dd093f  lea r14, [rax+0x17C]
000078d2e7dd0946  mov eax, 0x80
000078d2e7dd094b  mov [r13+r14*1], al
000078d2e7dd0950  mov qword ptr [r15+0xF0], 0x4102A8
000078d2e7dd095b  mov r14d, [r15+0x320]
000078d2e7dd0962  mov eax, 0x4102A8
000078d2e7dd0967  mov rcx, 0x78D2E7DD09E0
000078d2e7dd0971  mov [r15+r14*8+0x328], rax
000078d2e7dd0979  mov [r15+r14*8+0x368], rcx
000078d2e7dd0981  add r14d, 0x01
000078d2e7dd0985  and r14d, 0x07
000078d2e7dd0989  mov [r15+0x320], r14d
000078d2e7dd0990  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd0998  jz 0x000078D2E7DCED70
000078d2e7dd099e  nop [rax+rax*1], ax
000078d2e7dd09a7  nop [rax+rax*1], eax
000078d2e7dd09af  mov eax, 0x410728
000078d2e7dd09b4  mov [r15+0x100], rax
000078d2e7dd09bb  jmp 0x000078D2E7BFE110
000078d2e7dd09c0  int3
000078d2e7dd09c1  call 0x000078D2E7CE27E0
000078d2e7dd09c6  jmp 0x000078D2E7DD0913
000078d2e7dd09cb  call 0x000078D2E7CD5AF0
000078d2e7dd09d0  jmp 0x000078D2E7DD0950
000078d2e7dd09d5  int3
000078d2e7dd09d6  nop [rax+rax*1], ax
000078d2e7dd09df  nop
000078d2e7dd09e0  mov rax, [r15+0xF8]
000078d2e7dd09e7  lea r14, [rax+0x168]
000078d2e7dd09ee  mov r12, [r13+r14*1]
000078d2e7dd09f3  mov [r15+0x40], r12
000078d2e7dd09f7  lea r14, [rax+0x178]
000078d2e7dd09fe  xor eax, eax
000078d2e7dd0a00  mov [r13+r14*1], al
000078d2e7dd0a05  xor eax, eax
000078d2e7dd0a07  mov r14d, 0x38
000078d2e7dd0a0d  cmp r12, r14
000078d2e7dd0a10  cmc
000078d2e7dd0a11  lahf
000078d2e7dd0a12  seto al
000078d2e7dd0a15  mov [r15+0x108], eax
000078d2e7dd0a1c  mov eax, [r15+0x108]
000078d2e7dd0a23  sahf
000078d2e7dd0a24  jz 0x000078D2E7DD0A56
000078d2e7dd0a26  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd0a2e  jz 0x000078D2E7DD0AA0
000078d2e7dd0a34  nop [rax+rax*1], ax
000078d2e7dd0a3d  nop [rax+rax*1], eax
000078d2e7dd0a45  mov eax, 0x4102B8
000078d2e7dd0a4a  mov [r15+0x100], rax
000078d2e7dd0a51  jmp 0x000078D2E7BFE110
000078d2e7dd0a56  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd0a5e  jz 0x000078D2E7DD0BF0
000078d2e7dd0a64  nop [rax+rax*1], ax
000078d2e7dd0a6d  nop [rax+rax*1], eax
000078d2e7dd0a75  mov eax, 0x4102D4
000078d2e7dd0a7a  mov [r15+0x100], rax
000078d2e7dd0a81  jmp 0x000078D2E7BFE110
000078d2e7dd0a86  int3
000078d2e7dd0a87  call 0x000078D2E7CE27E0
000078d2e7dd0a8c  jmp 0x000078D2E7DD09F3
000078d2e7dd0a91  call 0x000078D2E7CD5AF0
000078d2e7dd0a96  jmp 0x000078D2E7DD0A05
000078d2e7dd0a9b  int3
000078d2e7dd0a9c  nop [rax], eax
000078d2e7dd0aa0  mov rax, [r15+0xF8]
000078d2e7dd0aa7  lea r14, [rax+0x100]
000078d2e7dd0aae  mov [r15], r14
000078d2e7dd0ab1  lea r14, [rax+0x178]
000078d2e7dd0ab8  mov [r15+0x08], r14
000078d2e7dd0abc  mov qword ptr [r15+0x10], 0x01
000078d2e7dd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
000078d2e7dd0acf  mov r14d, [r15+0x320]
000078d2e7dd0ad6  mov eax, 0x4102C8
000078d2e7dd0adb  mov rcx, 0x78D2E7DD0B40
000078d2e7dd0ae5  mov [r15+r14*8+0x328], rax
000078d2e7dd0aed  mov [r15+r14*8+0x368], rcx
000078d2e7dd0af5  add r14d, 0x01
000078d2e7dd0af9  and r14d, 0x07
000078d2e7dd0afd  mov [r15+0x320], r14d
000078d2e7dd0b04  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd0b0c  jz 0x000078D2E7DCED70
000078d2e7dd0b12  nop [rax+rax*1], ax
000078d2e7dd0b1b  nop [rax+rax*1], eax
000078d2e7dd0b23  mov eax, 0x410728
000078d2e7dd0b28  mov [r15+0x100], rax
000078d2e7dd0b2f  jmp 0x000078D2E7BFE110
000078d2e7dd0b34  int3
000078d2e7dd0b35  int3
000078d2e7dd0b36  nop [rax+rax*1], ax
000078d2e7dd0b3f  nop
000078d2e7dd0b40  mov rax, [r15+0xF8]
000078d2e7dd0b47  lea r14, [rax+0x168]
000078d2e7dd0b4e  mov rax, [r13+r14*1]
000078d2e7dd0b53  mov [r15+0x40], rax
000078d2e7dd0b57  mov [rsp+0x10], rax
000078d2e7dd0b5c  xor eax, eax
000078d2e7dd0b5e  mov r14, [rsp+0x10]
000078d2e7dd0b63  mov r12d, 0x38
000078d2e7dd0b69  cmp r14, r12
000078d2e7dd0b6c  cmc
000078d2e7dd0b6d  lahf
000078d2e7dd0b6e  seto al
000078d2e7dd0b71  mov [r15+0x108], eax
000078d2e7dd0b78  mov eax, [r15+0x108]
000078d2e7dd0b7f  sahf
000078d2e7dd0b80  jnz 0x000078D2E7DD0BB2
000078d2e7dd0b82  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd0b8a  jz 0x000078D2E7DD0BF0
000078d2e7dd0b90  nop [rax+rax*1], ax
000078d2e7dd0b99  nop [rax+rax*1], eax
000078d2e7dd0ba1  mov eax, 0x4102D4
000078d2e7dd0ba6  mov [r15+0x100], rax
000078d2e7dd0bad  jmp 0x000078D2E7BFE110
000078d2e7dd0bb2  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd0bba  jz 0x000078D2E7DD0AA0
000078d2e7dd0bc0  nop [rax+rax*1], ax
000078d2e7dd0bc9  nop [rax+rax*1], eax
000078d2e7dd0bd1  mov eax, 0x4102B8
000078d2e7dd0bd6  mov [r15+0x100], rax
000078d2e7dd0bdd  jmp 0x000078D2E7BFE110
000078d2e7dd0be2  int3
000078d2e7dd0be3  call 0x000078D2E7CD59C0
000078d2e7dd0be8  jmp 0x000078D2E7DD0B53
000078d2e7dd0bed  int3
000078d2e7dd0bee  nop
000078d2e7dd0bf0  mov rax, [r15+0x98]
000078d2e7dd0bf7  rorx r14, rax, 0x3D
000078d2e7dd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
000078d2e7dd0c01  mov rax, [r15+0xF8]
000078d2e7dd0c08  lea r12, [rax+0x100]
000078d2e7dd0c0f  mov [r15], r12
000078d2e7dd0c12  lea r12, [rax+0x170]
000078d2e7dd0c19  mov [r15+0x08], r12
000078d2e7dd0c1d  mov qword ptr [r15+0x10], 0x08
000078d2e7dd0c25  bswap r14
000078d2e7dd0c28  mov [r15+0x40], r14
000078d2e7dd0c2c  lea r12, [rax+0x170]
000078d2e7dd0c33  mov [r13+r12*1], r14
000078d2e7dd0c38  mov qword ptr [r15+0xF0], 0x4102F0
000078d2e7dd0c43  mov r14d, [r15+0x320]
000078d2e7dd0c4a  mov eax, 0x4102F0
000078d2e7dd0c4f  mov rcx, 0x78D2E7DD0CC0
000078d2e7dd0c59  mov [r15+r14*8+0x328], rax
000078d2e7dd0c61  mov [r15+r14*8+0x368], rcx
000078d2e7dd0c69  add r14d, 0x01
000078d2e7dd0c6d  and r14d, 0x07
000078d2e7dd0c71  mov [r15+0x320], r14d
000078d2e7dd0c78  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd0c80  jz 0x000078D2E7DCED70
000078d2e7dd0c86  nop [rax+rax*1], ax
000078d2e7dd0c8f  nop [rax+rax*1], eax
000078d2e7dd0c97  mov eax, 0x410728
000078d2e7dd0c9c  mov [r15+0x100], rax
000078d2e7dd0ca3  jmp 0x000078D2E7BFE110
000078d2e7dd0ca8  int3
000078d2e7dd0ca9  call 0x000078D2E7CC3FE0
000078d2e7dd0cae  jmp 0x000078D2E7DD0C38
000078d2e7dd0cb3  int3
000078d2e7dd0cb4  nop [rax+rax*1], ax
000078d2e7dd0cbd  nop [rax], eax
000078d2e7dd0cc0  mov rax, [r15+0xF8]
000078d2e7dd0cc7  lea r14, [rax+0x100]
000078d2e7dd0cce  mov r12d, [r13+r14*1]
000078d2e7dd0cd3  lea r14, [rax+0x104]
000078d2e7dd0cda  mov r11d, [r13+r14*1]
000078d2e7dd0cdf  mov qword ptr [r15+0x48], 0x430C90
000078d2e7dd0ce7  lea r14, [rax+0x108]
000078d2e7dd0cee  mov r10d, [r13+r14*1]
000078d2e7dd0cf3  lea r14, [rax+0x10C]
000078d2e7dd0cfa  mov r9d, [r13+r14*1]
000078d2e7dd0cff  bswap r12d
000078d2e7dd0d02  bswap r11d
000078d2e7dd0d05  mov qword ptr [r15+0xA0], 0x00
000078d2e7dd0d10  mov r14d, 0x430C90
000078d2e7dd0d16  mov [r13+r14*1], r12d
000078d2e7dd0d1b  mov r14d, 0x430C94
000078d2e7dd0d21  mov [r13+r14*1], r11d
000078d2e7dd0d26  bswap r10d
000078d2e7dd0d29  lea r14, [rax+0x110]
000078d2e7dd0d30  mov r12d, [r13+r14*1]
000078d2e7dd0d35  bswap r9d
000078d2e7dd0d38  lea r14, [rax+0x114]
000078d2e7dd0d3f  mov r11d, [r13+r14*1]
000078d2e7dd0d44  mov qword ptr [r15+0x98], 0x430DFC
000078d2e7dd0d4f  mov r14d, 0x430C98
000078d2e7dd0d55  mov [r13+r14*1], r10d
000078d2e7dd0d5a  mov r14d, 0x430C9C
000078d2e7dd0d60  mov [r13+r14*1], r9d
000078d2e7dd0d65  bswap r12d
000078d2e7dd0d68  lea r14, [rax+0x118]
000078d2e7dd0d6f  mov r10d, [r13+r14*1]
000078d2e7dd0d74  bswap r11d
000078d2e7dd0d77  mov [rsp+0x10], r11d
000078d2e7dd0d7c  mov r11d, r11d
000078d2e7dd0d7f  mov [r15+0x58], r11
000078d2e7dd0d83  lea r14, [rax+0x11C]
000078d2e7dd0d8a  mov eax, [r13+r14*1]
000078d2e7dd0d8f  mov [rsp+0x20], eax
000078d2e7dd0d93  mov eax, eax
000078d2e7dd0d95  mov [r15+0x60], rax
000078d2e7dd0d99  mov eax, 0x430CA0
000078d2e7dd0d9e  mov [r13+rax*1], r12d
000078d2e7dd0da3  mov eax, 0x430CA4
000078d2e7dd0da8  mov r14d, [rsp+0x10]
000078d2e7dd0dad  mov [r13+rax*1], r14d
000078d2e7dd0db2  bswap r10d
000078d2e7dd0db5  mov [rsp+0x10], r10d
000078d2e7dd0dba  mov r10d, r10d
000078d2e7dd0dbd  mov [r15+0x40], r10
000078d2e7dd0dc1  mov eax, [rsp+0x20]
000078d2e7dd0dc5  bswap eax
000078d2e7dd0dc7  mov [rsp+0x20], eax
000078d2e7dd0dcb  mov eax, eax
000078d2e7dd0dcd  mov [r15+0x50], rax
000078d2e7dd0dd1  mov eax, 0x430CA8
000078d2e7dd0dd6  mov r14d, [rsp+0x10]
000078d2e7dd0ddb  mov [r13+rax*1], r14d
000078d2e7dd0de0  mov eax, 0x430CAC
000078d2e7dd0de5  mov r14d, [rsp+0x20]
000078d2e7dd0dea  mov [r13+rax*1], r14d
000078d2e7dd0def  mov eax, [r15+0xA0]
000078d2e7dd0df6  lea r14d, [eax+0x11]
000078d2e7dd0dfb  mov r14d, r14d
000078d2e7dd0dfe  mov [r15], r14
000078d2e7dd0e01  mov qword ptr [r15+0xF0], 0x41035C
000078d2e7dd0e0c  mov r14d, [r15+0x320]
000078d2e7dd0e13  mov eax, 0x41035C
000078d2e7dd0e18  mov rcx, 0x78D2E7DD0F90
000078d2e7dd0e22  mov [r15+r14*8+0x328], rax
000078d2e7dd0e2a  mov [r15+r14*8+0x368], rcx
000078d2e7dd0e32  add r14d, 0x01
000078d2e7dd0e36  and r14d, 0x07
000078d2e7dd0e3a  mov [r15+0x320], r14d
000078d2e7dd0e41  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd0e49  jz 0x000078D2E7DD0F20
000078d2e7dd0e4f  nop [rax+rax*1], ax
000078d2e7dd0e58  nop [rax+rax*1], eax
000078d2e7dd0e60  mov eax, 0x4109A4
000078d2e7dd0e65  mov [r15+0x100], rax
000078d2e7dd0e6c  jmp 0x000078D2E7BFE110
000078d2e7dd0e71  int3
000078d2e7dd0e72  call 0x000078D2E7CE26A0
000078d2e7dd0e77  jmp 0x000078D2E7DD0CD3
000078d2e7dd0e7c  call 0x000078D2E7CE1430
000078d2e7dd0e81  jmp 0x000078D2E7DD0CDF
000078d2e7dd0e86  call 0x000078D2E7CE01C0
000078d2e7dd0e8b  jmp 0x000078D2E7DD0CF3
000078d2e7dd0e90  call 0x000078D2E7CDEF50
000078d2e7dd0e95  jmp 0x000078D2E7DD0CFF
000078d2e7dd0e9a  call 0x000078D2E7CE2BA0
000078d2e7dd0e9f  jmp 0x000078D2E7DD0D1B
000078d2e7dd0ea4  call 0x000078D2E7CE1920
000078d2e7dd0ea9  jmp 0x000078D2E7DD0D26
000078d2e7dd0eae  call 0x000078D2E7CE26A0
000078d2e7dd0eb3  jmp 0x000078D2E7DD0D35
000078d2e7dd0eb8  call 0x000078D2E7CE1430
000078d2e7dd0ebd  jmp 0x000078D2E7DD0D44
000078d2e7dd0ec2  call 0x000078D2E7CE06B0
000078d2e7dd0ec7  jmp 0x000078D2E7DD0D5A
000078d2e7dd0ecc  call 0x000078D2E7CDF440
000078d2e7dd0ed1  jmp 0x000078D2E7DD0D65
000078d2e7dd0ed6  call 0x000078D2E7CE01C0
000078d2e7dd0edb  jmp 0x000078D2E7DD0D74
000078d2e7dd0ee0  call 0x000078D2E7CD5890
000078d2e7dd0ee5  jmp 0x000078D2E7DD0D8F
000078d2e7dd0eea  call 0x000078D2E7C0BAE0
000078d2e7dd0eef  jmp 0x000078D2E7DD0DA3
000078d2e7dd0ef4  call 0x000078D2E7C0DFE0
000078d2e7dd0ef9  jmp 0x000078D2E7DD0DB2
000078d2e7dd0efe  call 0x000078D2E7C0DFE0
000078d2e7dd0f03  jmp 0x000078D2E7DD0DE0
000078d2e7dd0f08  call 0x000078D2E7C0DFE0
000078d2e7dd0f0d  jmp 0x000078D2E7DD0DEF
000078d2e7dd0f12  int3
000078d2e7dd0f13  nop [rax+rax*1], ax
000078d2e7dd0f1c  nop [rax], eax
000078d2e7dd0f20  mov eax, [r15]
000078d2e7dd0f23  mov [rsp+0x10], eax
000078d2e7dd0f27  shr eax, 0x10
000078d2e7dd0f2a  mov r14d, [rsp+0x10]
000078d2e7dd0f2f  xor r14d, eax
000078d2e7dd0f32  imul r14d, r14d, 0x7FEB352D
000078d2e7dd0f39  mov eax, 0x846CA68B
000078d2e7dd0f3e  mov eax, eax
000078d2e7dd0f40  mov [r15+0x48], rax
000078d2e7dd0f44  mov [rsp+0x10], r14d
000078d2e7dd0f49  shr r14d, 0x0F
000078d2e7dd0f4d  mov eax, [rsp+0x10]
000078d2e7dd0f51  xor eax, r14d
000078d2e7dd0f54  imul eax, eax, 0x846CA68B
000078d2e7dd0f5a  mov [rsp+0x10], eax
000078d2e7dd0f5e  mov eax, eax
000078d2e7dd0f60  mov [r15+0x40], rax
000078d2e7dd0f64  mov eax, [rsp+0x10]
000078d2e7dd0f68  shr eax, 0x10
000078d2e7dd0f6b  mov r14d, [rsp+0x10]
000078d2e7dd0f70  xor r14d, eax
000078d2e7dd0f73  mov r14d, r14d
000078d2e7dd0f76  mov [r15], r14
000078d2e7dd0f79  mov rax, [r15+0xF0]
000078d2e7dd0f80  mov [r15+0x100], rax
000078d2e7dd0f87  jmp 0x000078D2E7DCE5C0
000078d2e7dd0f8c  int3
000078d2e7dd0f8d  int3
000078d2e7dd0f8e  nop
000078d2e7dd0f90  mov rax, [r15+0xA0]
000078d2e7dd0f97  mov [rsp+0x10], rax
000078d2e7dd0f9c  shl rax, 0x02
000078d2e7dd0fa0  mov r14, [r15+0x98]
000078d2e7dd0fa7  lea r12, [r14+rax*1]
000078d2e7dd0fab  mov eax, [r15]
000078d2e7dd0fae  mov [r13+r12*1], eax
000078d2e7dd0fb3  mov rax, [rsp+0x10]
000078d2e7dd0fb8  lea r14, [rax+0x01]
000078d2e7dd0fbc  mov [r15+0xA0], r14
000078d2e7dd0fc3  xor eax, eax
000078d2e7dd0fc5  mov r12d, 0x400
000078d2e7dd0fcb  cmp r14, r12
000078d2e7dd0fce  cmc
000078d2e7dd0fcf  lahf
000078d2e7dd0fd0  seto al
000078d2e7dd0fd3  mov [r15+0x108], eax
000078d2e7dd0fda  mov eax, [r15+0x108]
000078d2e7dd0fe1  sahf
000078d2e7dd0fe2  jnz 0x000078D2E7DD1014
000078d2e7dd0fe4  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd0fec  jz 0x000078D2E7DD10E0
000078d2e7dd0ff2  nop [rax+rax*1], ax
000078d2e7dd0ffb  nop [rax+rax*1], eax
000078d2e7dd1003  mov eax, 0x41036C
000078d2e7dd1008  mov [r15+0x100], rax
000078d2e7dd100f  jmp 0x000078D2E7BFE110
000078d2e7dd1014  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd101c  jz 0x000078D2E7DD1050
000078d2e7dd1022  nop [rax+rax*1], ax
000078d2e7dd102b  nop [rax+rax*1], eax
000078d2e7dd1033  mov eax, 0x410354
000078d2e7dd1038  mov [r15+0x100], rax
000078d2e7dd103f  jmp 0x000078D2E7BFE110
000078d2e7dd1044  int3
000078d2e7dd1045  call 0x000078D2E7CB4B70
000078d2e7dd104a  jmp 0x000078D2E7DD0FB3
000078d2e7dd104f  int3
000078d2e7dd1050  mov eax, [r15+0xA0]
000078d2e7dd1057  lea r14d, [eax+0x11]
000078d2e7dd105c  mov r14d, r14d
000078d2e7dd105f  mov [r15], r14
000078d2e7dd1062  mov qword ptr [r15+0xF0], 0x41035C
000078d2e7dd106d  mov r14d, [r15+0x320]
000078d2e7dd1074  mov eax, 0x41035C
000078d2e7dd1079  mov rcx, 0x78D2E7DD0F90
000078d2e7dd1083  mov [r15+r14*8+0x328], rax
000078d2e7dd108b  mov [r15+r14*8+0x368], rcx
000078d2e7dd1093  add r14d, 0x01
000078d2e7dd1097  and r14d, 0x07
000078d2e7dd109b  mov [r15+0x320], r14d
000078d2e7dd10a2  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd10aa  jz 0x000078D2E7DD0F20
000078d2e7dd10b0  nop [rax+rax*1], ax
000078d2e7dd10b9  nop [rax+rax*1], eax
000078d2e7dd10c1  mov eax, 0x4109A4
000078d2e7dd10c6  mov [r15+0x100], rax
000078d2e7dd10cd  jmp 0x000078D2E7BFE110
000078d2e7dd10d2  int3
000078d2e7dd10d3  int3
000078d2e7dd10d4  nop [rax+rax*1], ax
000078d2e7dd10dd  nop [rax], eax
000078d2e7dd10e0  mov qword ptr [r15+0x40], 0x01
000078d2e7dd10e8  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd10f0  jz 0x000078D2E7DD1120
000078d2e7dd10f6  nop [rax+rax*1], ax
000078d2e7dd10ff  nop [rax+rax*1], eax
000078d2e7dd1107  mov eax, 0x410388
000078d2e7dd110c  mov [r15+0x100], rax
000078d2e7dd1113  jmp 0x000078D2E7BFE110
000078d2e7dd1118  int3
000078d2e7dd1119  int3
000078d2e7dd111a  nop [rax+rax*1], ax
000078d2e7dd1120  mov rax, [r15+0x40]
000078d2e7dd1124  mov [rsp+0x10], rax
000078d2e7dd1129  shl rax, 0x02
000078d2e7dd112d  mov r14, [r15+0x98]
000078d2e7dd1134  lea r12, [r14+rax*1]
000078d2e7dd1138  mov eax, [r13+r12*1]
000078d2e7dd113d  mov [rsp+0x20], eax
000078d2e7dd1141  mov eax, eax
000078d2e7dd1143  mov [r15+0x48], rax
000078d2e7dd1147  mov rax, [rsp+0x10]
000078d2e7dd114c  mov [r15+0x50], rax
000078d2e7dd1150  mov eax, [r15+0x50]
000078d2e7dd1154  lea r12d, [eax-0x01]
000078d2e7dd1159  mov r12d, r12d
000078d2e7dd115c  mov [r15+0x58], r12
000078d2e7dd1160  mov rax, [r15+0x58]
000078d2e7dd1164  mov r12d, eax
000078d2e7dd1167  mov r12d, r12d
000078d2e7dd116a  shl r12, 0x02
000078d2e7dd116e  lea rax, [r14+r12*1]
000078d2e7dd1172  mov r14d, [r13+rax*1]
000078d2e7dd1177  mov [rsp+0x10], r14d
000078d2e7dd117c  mov r14d, r14d
000078d2e7dd117f  mov [r15+0x60], r14
000078d2e7dd1183  xor eax, eax
000078d2e7dd1185  mov r14d, [rsp+0x10]
000078d2e7dd118a  mov r12d, [rsp+0x20]
000078d2e7dd118f  cmp r14d, r12d
000078d2e7dd1192  cmc
000078d2e7dd1193  lahf
000078d2e7dd1194  seto al
000078d2e7dd1197  mov [r15+0x108], eax
000078d2e7dd119e  mov eax, [r15+0x108]
000078d2e7dd11a5  sahf
000078d2e7dd11a6  cmc
000078d2e7dd11a7  jbe 0x000078D2E7DD11D9
000078d2e7dd11a9  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd11b1  jz 0x000078D2E7DD1220
000078d2e7dd11b7  nop [rax+rax*1], ax
000078d2e7dd11c0  nop [rax+rax*1], eax
000078d2e7dd11c8  mov eax, 0x4103A0
000078d2e7dd11cd  mov [r15+0x100], rax
000078d2e7dd11d4  jmp 0x000078D2E7BFE110
000078d2e7dd11d9  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd11e1  jz 0x000078D2E7DD14C0
000078d2e7dd11e7  nop [rax+rax*1], ax
000078d2e7dd11f0  nop [rax+rax*1], eax
000078d2e7dd11f8  mov eax, 0x410378
000078d2e7dd11fd  mov [r15+0x100], rax
000078d2e7dd1204  jmp 0x000078D2E7BFE110
000078d2e7dd1209  int3
000078d2e7dd120a  call 0x000078D2E7CB4690
000078d2e7dd120f  jmp 0x000078D2E7DD113D
000078d2e7dd1214  call 0x000078D2E7C0DAE0
000078d2e7dd1219  jmp 0x000078D2E7DD1177
000078d2e7dd121e  int3
000078d2e7dd121f  nop
000078d2e7dd1220  mov rax, [r15+0x50]
000078d2e7dd1224  mov [rsp+0x10], rax
000078d2e7dd1229  shl rax, 0x02
000078d2e7dd122d  mov r14, [r15+0x98]
000078d2e7dd1234  lea r12, [r14+rax*1]
000078d2e7dd1238  mov eax, [r15+0x60]
000078d2e7dd123c  mov [r13+r12*1], eax
000078d2e7dd1241  mov rax, [rsp+0x10]
000078d2e7dd1246  lea r14, [rax-0x01]
000078d2e7dd124a  mov [r15+0x50], r14
000078d2e7dd124e  mov rax, [r15+0x58]
000078d2e7dd1252  test rax, rax
000078d2e7dd1255  setz al
000078d2e7dd1258  movzx rax, al
000078d2e7dd125c  mov [rsp+0x414], al
000078d2e7dd1263  cmp byte ptr [rsp+0x414], 0x00
000078d2e7dd126b  jz 0x000078D2E7DD129D
000078d2e7dd126d  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd1275  jz 0x000078D2E7DD12E0
000078d2e7dd127b  nop [rax+rax*1], ax
000078d2e7dd1284  nop [rax+rax*1], eax
000078d2e7dd128c  mov eax, 0x4103AC
000078d2e7dd1291  mov [r15+0x100], rax
000078d2e7dd1298  jmp 0x000078D2E7BFE110
000078d2e7dd129d  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd12a5  jz 0x000078D2E7DD13E0
000078d2e7dd12ab  nop [rax+rax*1], ax
000078d2e7dd12b4  nop [rax+rax*1], eax
000078d2e7dd12bc  mov eax, 0x410390
000078d2e7dd12c1  mov [r15+0x100], rax
000078d2e7dd12c8  jmp 0x000078D2E7BFE110
000078d2e7dd12cd  int3
000078d2e7dd12ce  call 0x000078D2E7CB4B70
000078d2e7dd12d3  jmp 0x000078D2E7DD1241
000078d2e7dd12d8  int3
000078d2e7dd12d9  nop [rax], eax
000078d2e7dd12e0  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd12e8  jz 0x000078D2E7DD1320
000078d2e7dd12ee  nop [rax+rax*1], ax
000078d2e7dd12f7  nop [rax+rax*1], eax
000078d2e7dd12ff  mov eax, 0x410374
000078d2e7dd1304  mov [r15+0x100], rax
000078d2e7dd130b  jmp 0x000078D2E7BFE110
000078d2e7dd1310  int3
000078d2e7dd1311  int3
000078d2e7dd1312  nop [rax+rax*1], ax
000078d2e7dd131b  nop [rax+rax*1], eax
000078d2e7dd1320  mov qword ptr [r15+0x50], 0x00
000078d2e7dd1328  mov rax, [r15+0x40]
000078d2e7dd132c  lea r14, [rax+0x01]
000078d2e7dd1330  mov [r15+0x40], r14
000078d2e7dd1334  mov rax, [r15+0x98]
000078d2e7dd133b  mov r12d, [r15+0x48]
000078d2e7dd133f  mov [r13+rax*1], r12d
000078d2e7dd1344  xor eax, eax
000078d2e7dd1346  mov r12d, 0x400
000078d2e7dd134c  cmp r14, r12
000078d2e7dd134f  cmc
000078d2e7dd1350  lahf
000078d2e7dd1351  seto al
000078d2e7dd1354  mov [r15+0x108], eax
000078d2e7dd135b  mov eax, [r15+0x108]
000078d2e7dd1362  sahf
000078d2e7dd1363  jz 0x000078D2E7DD1395
000078d2e7dd1365  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd136d  jz 0x000078D2E7DD1120
000078d2e7dd1373  nop [rax+rax*1], ax
000078d2e7dd137c  nop [rax+rax*1], eax
000078d2e7dd1384  mov eax, 0x410388
000078d2e7dd1389  mov [r15+0x100], rax
000078d2e7dd1390  jmp 0x000078D2E7BFE110
000078d2e7dd1395  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd139d  jz 0x000078D2E7DD1580
000078d2e7dd13a3  nop [rax+rax*1], ax
000078d2e7dd13ac  nop [rax+rax*1], eax
000078d2e7dd13b4  mov eax, 0x4103B0
000078d2e7dd13b9  mov [r15+0x100], rax
000078d2e7dd13c0  jmp 0x000078D2E7BFE110
000078d2e7dd13c5  int3
000078d2e7dd13c6  call 0x000078D2E7C0BAE0
000078d2e7dd13cb  jmp 0x000078D2E7DD1344
000078d2e7dd13d0  int3
000078d2e7dd13d1  nop [rax+rax*1], ax
000078d2e7dd13da  nop [rax+rax*1], ax
000078d2e7dd13e0  mov eax, [r15+0x50]
000078d2e7dd13e4  lea r14d, [eax-0x01]
000078d2e7dd13e9  mov r14d, r14d
000078d2e7dd13ec  mov [r15+0x58], r14
000078d2e7dd13f0  mov rax, [r15+0x58]
000078d2e7dd13f4  mov r14d, eax
000078d2e7dd13f7  mov r14d, r14d
000078d2e7dd13fa  shl r14, 0x02
000078d2e7dd13fe  mov rax, [r15+0x98]
000078d2e7dd1405  lea r12, [rax+r14*1]
000078d2e7dd1409  mov eax, [r13+r12*1]
000078d2e7dd140e  mov [rsp+0x10], eax
000078d2e7dd1412  mov eax, eax
000078d2e7dd1414  mov [r15+0x60], rax
000078d2e7dd1418  mov eax, [r15+0x48]
000078d2e7dd141c  mov [rsp+0x20], eax
000078d2e7dd1420  xor eax, eax
000078d2e7dd1422  mov r14d, [rsp+0x10]
000078d2e7dd1427  mov r12d, [rsp+0x20]
000078d2e7dd142c  cmp r14d, r12d
000078d2e7dd142f  cmc
000078d2e7dd1430  lahf
000078d2e7dd1431  seto al
000078d2e7dd1434  mov [r15+0x108], eax
000078d2e7dd143b  mov eax, [r15+0x108]
000078d2e7dd1442  sahf
000078d2e7dd1443  cmc
000078d2e7dd1444  jbe 0x000078D2E7DD1476
000078d2e7dd1446  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd144e  jz 0x000078D2E7DD1220
000078d2e7dd1454  nop [rax+rax*1], ax
000078d2e7dd145d  nop [rax+rax*1], eax
000078d2e7dd1465  mov eax, 0x4103A0
000078d2e7dd146a  mov [r15+0x100], rax
000078d2e7dd1471  jmp 0x000078D2E7BFE110
000078d2e7dd1476  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd147e  jz 0x000078D2E7DD14C0
000078d2e7dd1484  nop [rax+rax*1], ax
000078d2e7dd148d  nop [rax+rax*1], eax
000078d2e7dd1495  mov eax, 0x410378
000078d2e7dd149a  mov [r15+0x100], rax
000078d2e7dd14a1  jmp 0x000078D2E7BFE110
000078d2e7dd14a6  int3
000078d2e7dd14a7  call 0x000078D2E7CB4690
000078d2e7dd14ac  jmp 0x000078D2E7DD140E
000078d2e7dd14b1  int3
000078d2e7dd14b2  nop [rax+rax*1], ax
000078d2e7dd14bb  nop [rax+rax*1], eax
000078d2e7dd14c0  mov rax, [r15+0x40]
000078d2e7dd14c4  lea r14, [rax+0x01]
000078d2e7dd14c8  mov [r15+0x40], r14
000078d2e7dd14cc  mov rax, [r15+0x50]
000078d2e7dd14d0  mov r12d, eax
000078d2e7dd14d3  mov r12d, r12d
000078d2e7dd14d6  shl r12, 0x02
000078d2e7dd14da  mov rax, [r15+0x98]
000078d2e7dd14e1  lea r11, [rax+r12*1]
000078d2e7dd14e5  mov eax, [r15+0x48]
000078d2e7dd14e9  mov [r13+r11*1], eax
000078d2e7dd14ee  xor eax, eax
000078d2e7dd14f0  mov r12d, 0x400
000078d2e7dd14f6  cmp r14, r12
000078d2e7dd14f9  cmc
000078d2e7dd14fa  lahf
000078d2e7dd14fb  seto al
000078d2e7dd14fe  mov [r15+0x108], eax
000078d2e7dd1505  mov eax, [r15+0x108]
000078d2e7dd150c  sahf
000078d2e7dd150d  jz 0x000078D2E7DD153F
000078d2e7dd150f  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd1517  jz 0x000078D2E7DD1120
000078d2e7dd151d  nop [rax+rax*1], ax
000078d2e7dd1526  nop [rax+rax*1], eax
000078d2e7dd152e  mov eax, 0x410388
000078d2e7dd1533  mov [r15+0x100], rax
000078d2e7dd153a  jmp 0x000078D2E7BFE110
000078d2e7dd153f  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd1547  jz 0x000078D2E7DD1580
000078d2e7dd154d  nop [rax+rax*1], ax
000078d2e7dd1556  nop [rax+rax*1], eax
000078d2e7dd155e  mov eax, 0x4103B0
000078d2e7dd1563  mov [r15+0x100], rax
000078d2e7dd156a  jmp 0x000078D2E7BFE110
000078d2e7dd156f  int3
000078d2e7dd1570  call 0x000078D2E7CA4270
000078d2e7dd1575  jmp 0x000078D2E7DD14EE
000078d2e7dd157a  int3
000078d2e7dd157b  nop [rax+rax*1], eax
000078d2e7dd1580  mov qword ptr [r15+0x40], 0x430000
000078d2e7dd1588  mov eax, 0x430CB0
000078d2e7dd158d  mov r14, [r13+rax*1]
000078d2e7dd1592  mov rax, [r15+0x98]
000078d2e7dd1599  mov r12d, [r13+rax*1]
000078d2e7dd159e  lea r11, [rax+0x04]
000078d2e7dd15a2  mov eax, [r13+r11*1]
000078d2e7dd15a7  mov r12d, r12d
000078d2e7dd15aa  mov [r15+0x68], r12
000078d2e7dd15ae  mov eax, eax
000078d2e7dd15b0  mov [r15+0x60], rax
000078d2e7dd15b4  mov rax, [r15+0x68]
000078d2e7dd15b8  mov [r15+0x68], rax
000078d2e7dd15bc  mov qword ptr [r15+0x58], 0x02
000078d2e7dd15c4  mov [rsp+0x10], rax
000078d2e7dd15c9  xor eax, eax
000078d2e7dd15cb  mov r12d, 0x02
000078d2e7dd15d1  mov r11d, 0x400
000078d2e7dd15d7  cmp r12, r11
000078d2e7dd15da  cmc
000078d2e7dd15db  lahf
000078d2e7dd15dc  seto al
000078d2e7dd15df  mov [r15+0x108], eax
000078d2e7dd15e6  mov rax, [r15+0x60]
000078d2e7dd15ea  mov r12d, 0x02
000078d2e7dd15f0  imul rax, r12
000078d2e7dd15f4  mov [r15+0x50], rax
000078d2e7dd15f8  mov rax, [rsp+0x10]
000078d2e7dd15fd  lea r12, [rax+r14*1]
000078d2e7dd1601  mov [r15+0x48], r12
000078d2e7dd1605  mov eax, [r15+0x108]
000078d2e7dd160c  sahf
000078d2e7dd160d  jnz 0x000078D2E7DD163F
000078d2e7dd160f  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd1617  jz 0x000078D2E7DD17B0
000078d2e7dd161d  nop [rax+rax*1], ax
000078d2e7dd1626  nop [rax+rax*1], eax
000078d2e7dd162e  mov eax, 0x4103E0
000078d2e7dd1633  mov [r15+0x100], rax
000078d2e7dd163a  jmp 0x000078D2E7BFE110
000078d2e7dd163f  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd1647  jz 0x000078D2E7DD1690
000078d2e7dd164d  nop [rax+rax*1], ax
000078d2e7dd1656  nop [rax+rax*1], eax
000078d2e7dd165e  mov eax, 0x4103C0
000078d2e7dd1663  mov [r15+0x100], rax
000078d2e7dd166a  jmp 0x000078D2E7BFE110
000078d2e7dd166f  int3
000078d2e7dd1670  call 0x000078D2E7C0DC20
000078d2e7dd1675  jmp 0x000078D2E7DD1592
000078d2e7dd167a  call 0x000078D2E7C0B5E0
000078d2e7dd167f  jmp 0x000078D2E7DD159E
000078d2e7dd1684  call 0x000078D2E7CA3D90
000078d2e7dd1689  jmp 0x000078D2E7DD15A7
000078d2e7dd168e  int3
000078d2e7dd168f  nop
000078d2e7dd1690  mov rax, [r15+0x98]
000078d2e7dd1697  mov r14, [r15+0x58]
000078d2e7dd169b  mov [rsp+0x10], r14
000078d2e7dd16a0  shl r14, 0x02
000078d2e7dd16a4  lea r12, [rax+r14*1]
000078d2e7dd16a8  mov eax, [r13+r12*1]
000078d2e7dd16ad  lea r14, [r12+0x04]
000078d2e7dd16b2  mov r12d, [r13+r14*1]
000078d2e7dd16b7  mov eax, eax
000078d2e7dd16b9  mov [r15+0x68], rax
000078d2e7dd16bd  mov r12d, r12d
000078d2e7dd16c0  mov [r15+0x60], r12
000078d2e7dd16c4  mov rax, [r15+0x68]
000078d2e7dd16c8  mov [rsp+0x20], rax
000078d2e7dd16cd  mov r14, [rsp+0x10]
000078d2e7dd16d2  imul rax, r14
000078d2e7dd16d6  mov r12, [rsp+0x20]
000078d2e7dd16db  lea r11, [r12+rax*1]
000078d2e7dd16df  mov [r15+0x68], r11
000078d2e7dd16e3  lea rax, [r14+0x02]
000078d2e7dd16e7  mov [r15+0x58], rax
000078d2e7dd16eb  mov [rsp+0x10], rax
000078d2e7dd16f0  xor eax, eax
000078d2e7dd16f2  mov r14, [rsp+0x10]
000078d2e7dd16f7  mov r12d, 0x400
000078d2e7dd16fd  cmp r14, r12
000078d2e7dd1700  cmc
000078d2e7dd1701  lahf
000078d2e7dd1702  seto al
000078d2e7dd1705  mov [r15+0x108], eax
000078d2e7dd170c  mov rax, [r15+0x50]
000078d2e7dd1710  mov r12, [r15+0x60]
000078d2e7dd1714  imul r14, r12
000078d2e7dd1718  lea r12, [rax+r14*1]
000078d2e7dd171c  mov [r15+0x50], r12
000078d2e7dd1720  mov rax, [r15+0x48]
000078d2e7dd1724  lea r14, [r11+rax*1]
000078d2e7dd1728  mov [r15+0x48], r14
000078d2e7dd172c  mov eax, [r15+0x108]
000078d2e7dd1733  sahf
000078d2e7dd1734  jnz 0x000078D2E7DD1766
000078d2e7dd1736  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd173e  jz 0x000078D2E7DD17B0
000078d2e7dd1744  nop [rax+rax*1], ax
000078d2e7dd174d  nop [rax+rax*1], eax
000078d2e7dd1755  mov eax, 0x4103E0
000078d2e7dd175a  mov [r15+0x100], rax
000078d2e7dd1761  jmp 0x000078D2E7BFE110
000078d2e7dd1766  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd176e  jz 0x000078D2E7DD1690
000078d2e7dd1774  nop [rax+rax*1], ax
000078d2e7dd177d  nop [rax+rax*1], eax
000078d2e7dd1785  mov eax, 0x4103C0
000078d2e7dd178a  mov [r15+0x100], rax
000078d2e7dd1791  jmp 0x000078D2E7BFE110
000078d2e7dd1796  int3
000078d2e7dd1797  call 0x000078D2E7CB4690
000078d2e7dd179c  jmp 0x000078D2E7DD16AD
000078d2e7dd17a1  call 0x000078D2E7CE26A0
000078d2e7dd17a6  jmp 0x000078D2E7DD16B7
000078d2e7dd17ab  int3
000078d2e7dd17ac  nop [rax], eax
000078d2e7dd17b0  mov qword ptr [r15+0x98], 0x00
000078d2e7dd17bb  mov rax, [r15+0x50]
000078d2e7dd17bf  mov r14, [r15+0x48]
000078d2e7dd17c3  lea r12, [rax+r14*1]
000078d2e7dd17c7  mov [r15+0x48], r12
000078d2e7dd17cb  mov rax, [r15+0x40]
000078d2e7dd17cf  lea r14, [rax+0xCB0]
000078d2e7dd17d6  mov [r13+r14*1], r12
000078d2e7dd17db  mov qword ptr [r15], 0x01
000078d2e7dd17e2  mov qword ptr [r15+0xF0], 0x4103F8
000078d2e7dd17ed  mov r14d, [r15+0x320]
000078d2e7dd17f4  mov eax, 0x4103F8
000078d2e7dd17f9  mov rcx, 0x78D2E7DD1860
000078d2e7dd1803  mov [r15+r14*8+0x328], rax
000078d2e7dd180b  mov [r15+r14*8+0x368], rcx
000078d2e7dd1813  add r14d, 0x01
000078d2e7dd1817  and r14d, 0x07
000078d2e7dd181b  mov [r15+0x320], r14d
000078d2e7dd1822  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd182a  jz 0x000078D2E7DD0F20
000078d2e7dd1830  nop [rax+rax*1], ax
000078d2e7dd1839  nop [rax+rax*1], eax
000078d2e7dd1841  mov eax, 0x4109A4
000078d2e7dd1846  mov [r15+0x100], rax
000078d2e7dd184d  jmp 0x000078D2E7BFE110
000078d2e7dd1852  int3
000078d2e7dd1853  call 0x000078D2E7CE2CE0
000078d2e7dd1858  jmp 0x000078D2E7DD17DB
000078d2e7dd185d  int3
000078d2e7dd185e  nop
000078d2e7dd1860  mov eax, [r15+0x98]
000078d2e7dd1867  lea r14d, [eax+0x01]
000078d2e7dd186c  mov [rsp+0x10], r14d
000078d2e7dd1871  mov r14d, r14d
000078d2e7dd1874  mov [r15+0x98], r14
000078d2e7dd187b  xor eax, eax
000078d2e7dd187d  mov r14d, [rsp+0x10]
000078d2e7dd1882  cmp r14d, 0x10000
000078d2e7dd1889  cmc
000078d2e7dd188a  lahf
000078d2e7dd188b  seto al
000078d2e7dd188e  mov [r15+0x108], eax
000078d2e7dd1895  mov eax, [r15+0x108]
000078d2e7dd189c  sahf
000078d2e7dd189d  jnz 0x000078D2E7DD18CF
000078d2e7dd189f  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd18a7  jz 0x000078D2E7DD19A0
000078d2e7dd18ad  nop [rax+rax*1], ax
000078d2e7dd18b6  nop [rax+rax*1], eax
000078d2e7dd18be  mov eax, 0x410404
000078d2e7dd18c3  mov [r15+0x100], rax
000078d2e7dd18ca  jmp 0x000078D2E7BFE110
000078d2e7dd18cf  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd18d7  jz 0x000078D2E7DD1910
000078d2e7dd18dd  nop [rax+rax*1], ax
000078d2e7dd18e6  nop [rax+rax*1], eax
000078d2e7dd18ee  mov eax, 0x4103F0
000078d2e7dd18f3  mov [r15+0x100], rax
000078d2e7dd18fa  jmp 0x000078D2E7BFE110
000078d2e7dd18ff  int3
000078d2e7dd1900  int3
000078d2e7dd1901  nop [rax+rax*1], ax
000078d2e7dd190a  nop [rax+rax*1], ax
000078d2e7dd1910  mov eax, [r15]
000078d2e7dd1913  mov r14d, [r15+0x98]
000078d2e7dd191a  lea r12d, [eax+r14d*1]
000078d2e7dd191f  mov r12d, r12d
000078d2e7dd1922  mov [r15], r12
000078d2e7dd1925  mov qword ptr [r15+0xF0], 0x4103F8
000078d2e7dd1930  mov r14d, [r15+0x320]
000078d2e7dd1937  mov eax, 0x4103F8
000078d2e7dd193c  mov rcx, 0x78D2E7DD1860
000078d2e7dd1946  mov [r15+r14*8+0x328], rax
000078d2e7dd194e  mov [r15+r14*8+0x368], rcx
000078d2e7dd1956  add r14d, 0x01
000078d2e7dd195a  and r14d, 0x07
000078d2e7dd195e  mov [r15+0x320], r14d
000078d2e7dd1965  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd196d  jz 0x000078D2E7DD0F20
000078d2e7dd1973  nop [rax+rax*1], ax
000078d2e7dd197c  nop [rax+rax*1], eax
000078d2e7dd1984  mov eax, 0x4109A4
000078d2e7dd1989  mov [r15+0x100], rax
000078d2e7dd1990  jmp 0x000078D2E7BFE110
000078d2e7dd1995  int3
000078d2e7dd1996  int3
000078d2e7dd1997  nop [rax+rax*1], ax
000078d2e7dd19a0  vmovaps xmm1, [0x000078D2E79FE010]
000078d2e7dd19a8  movq xmm1, xmm1
000078d2e7dd19ac  movaps [r15+0x110], xmm1
000078d2e7dd19b4  mov eax, 0x420B10
000078d2e7dd19b9  mov r14, [r13+rax*1]
000078d2e7dd19be  movq xmm1, r14
000078d2e7dd19c3  movaps [r15+0x120], xmm1
000078d2e7dd19cb  vmovaps xmm1, [0x000078D2E79FE020]
000078d2e7dd19d3  movq xmm1, xmm1
000078d2e7dd19d7  movaps [r15+0x140], xmm1
000078d2e7dd19df  vmovaps xmm1, [0x000078D2E79FE030]
000078d2e7dd19e7  vpbroadcastq xmm1, xmm1
000078d2e7dd19ec  movaps [r15+0x150], xmm1
000078d2e7dd19f4  mov qword ptr [r15+0x40], 0x02
000078d2e7dd19fc  vmovaps xmm15, [0x000078D2E79FE040]
000078d2e7dd1a04  movq xmm15, xmm15
000078d2e7dd1a09  movaps [r15+0x160], xmm15
000078d2e7dd1a11  vmovaps xmm15, [0x000078D2E79FE050]
000078d2e7dd1a19  vpbroadcastq xmm15, xmm15
000078d2e7dd1a1e  movaps [r15+0x130], xmm15
000078d2e7dd1a26  mov rax, [r15+0x40]
000078d2e7dd1a2a  vmovq xmm14, rax
000078d2e7dd1a2f  vpbroadcastq xmm14, xmm14
000078d2e7dd1a34  movaps [r15+0x170], xmm14
000078d2e7dd1a3c  mov eax, 0x420A40
000078d2e7dd1a41  movups xmm13, [r13+rax*1]
000078d2e7dd1a47  mov qword ptr [r15+0x40], 0x431E00
000078d2e7dd1a4f  mov eax, [r15]
000078d2e7dd1a52  mov r14d, 0x430CB8
000078d2e7dd1a58  mov [r13+r14*1], eax
000078d2e7dd1a5d  mov qword ptr [r15+0x50], 0x432000
000078d2e7dd1a65  vpmovqd xmm12, xmm13
000078d2e7dd1a6b  pxor xmm11, xmm11
000078d2e7dd1a70  punpcklqdq xmm12, xmm11
000078d2e7dd1a75  movaps [r15+0x210], xmm12
000078d2e7dd1a7d  movq xmm12, qword ptr [r15+0x140]
000078d2e7dd1a86  movq xmm11, qword ptr [r15+0x120]
000078d2e7dd1a8f  psubd xmm12, xmm11
000078d2e7dd1a94  movq xmm12, xmm12
000078d2e7dd1a99  paddq xmm13, xmm14
000078d2e7dd1a9e  movaps [r15+0x180], xmm13
000078d2e7dd1aa6  movq xmm14, qword ptr [r15+0x160]
000078d2e7dd1aaf  paddd xmm11, xmm14
000078d2e7dd1ab4  movq xmm11, xmm11
000078d2e7dd1ab9  movq xmm11, xmm11
000078d2e7dd1abe  movaps [r15+0x120], xmm11
000078d2e7dd1ac6  pmovzxdq xmm12, xmm12
000078d2e7dd1acc  psllq xmm12, 0x00
000078d2e7dd1ad2  movq xmm14, qword ptr [r15+0x210]
000078d2e7dd1adb  movq xmm13, qword ptr [r15+0x110]
000078d2e7dd1ae4  paddd xmm14, xmm13
000078d2e7dd1ae9  movq xmm14, xmm14
000078d2e7dd1aee  vcvtuqq2pd xmm12, xmm12
000078d2e7dd1af4  pmovzxdq xmm14, xmm14
000078d2e7dd1afa  psllq xmm14, 0x00
000078d2e7dd1b00  vcvtuqq2pd xmm14, xmm14
000078d2e7dd1b06  movaps xmm13, xmm12
000078d2e7dd1b0a  mulpd xmm13, xmm1
000078d2e7dd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
000078d2e7dd1b15  ptest xmm11, xmm11
000078d2e7dd1b1b  jnz 0x000078D2E7DD1C0F
000078d2e7dd1b21  movaps [r15+0x220], xmm13
000078d2e7dd1b29  mov eax, 0x432000
000078d2e7dd1b2e  movups [r13+rax*1], xmm13
000078d2e7dd1b34  movaps xmm1, xmm14
000078d2e7dd1b38  mulpd xmm1, xmm15
000078d2e7dd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
000078d2e7dd1b42  ptest xmm13, xmm13
000078d2e7dd1b48  jnz 0x000078D2E7DD1D5C
000078d2e7dd1b4e  movaps [r15+0x210], xmm1
000078d2e7dd1b56  mov eax, 0x431E00
000078d2e7dd1b5b  movups [r13+rax*1], xmm1
000078d2e7dd1b61  mov qword ptr [r15+0x48], 0x10
000078d2e7dd1b69  xor eax, eax
000078d2e7dd1b6b  mov r14d, 0x10
000078d2e7dd1b71  mov r12d, 0x200
000078d2e7dd1b77  cmp r14, r12
000078d2e7dd1b7a  cmc
000078d2e7dd1b7b  lahf
000078d2e7dd1b7c  seto al
000078d2e7dd1b7f  mov [r15+0x108], eax
000078d2e7dd1b86  mov eax, [r15+0x108]
000078d2e7dd1b8d  sahf
000078d2e7dd1b8e  jnz 0x000078D2E7DD1BC0
000078d2e7dd1b90  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd1b98  jz 0x000078D2E7DD2300
000078d2e7dd1b9e  nop [rax+rax*1], ax
000078d2e7dd1ba7  nop [rax+rax*1], eax
000078d2e7dd1baf  mov eax, 0x410490
000078d2e7dd1bb4  mov [r15+0x100], rax
000078d2e7dd1bbb  jmp 0x000078D2E7BFE110
000078d2e7dd1bc0  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd1bc8  jz 0x000078D2E7DD1EB0
000078d2e7dd1bce  nop [rax+rax*1], ax
000078d2e7dd1bd7  nop [rax+rax*1], eax
000078d2e7dd1bdf  mov eax, 0x410450
000078d2e7dd1be4  mov [r15+0x100], rax
000078d2e7dd1beb  jmp 0x000078D2E7BFE110
000078d2e7dd1bf0  int3
000078d2e7dd1bf1  call 0x000078D2E7C0DC20
000078d2e7dd1bf6  jmp 0x000078D2E7DD19BE
000078d2e7dd1bfb  call 0x000078D2E7C0C260
000078d2e7dd1c00  jmp 0x000078D2E7DD1A47
000078d2e7dd1c05  call 0x000078D2E7CD5D70
000078d2e7dd1c0a  jmp 0x000078D2E7DD1A5D
000078d2e7dd1c0f  sub rsp, 0x08
000078d2e7dd1c13  push rax
000078d2e7dd1c14  push rcx
000078d2e7dd1c15  push rdx
000078d2e7dd1c16  push rdi
000078d2e7dd1c17  push rsi
000078d2e7dd1c18  push r8
000078d2e7dd1c1a  push r9
000078d2e7dd1c1c  push r10
000078d2e7dd1c1e  push r11
000078d2e7dd1c20  sub rsp, 0xF0
000078d2e7dd1c27  vmovaps [rsp], xmm0
000078d2e7dd1c2c  vmovaps [rsp+0x10], xmm1
000078d2e7dd1c32  vmovaps [rsp+0x20], xmm2
000078d2e7dd1c38  vmovaps [rsp+0x30], xmm3
000078d2e7dd1c3e  vmovaps [rsp+0x40], xmm4
000078d2e7dd1c44  vmovaps [rsp+0x50], xmm5
000078d2e7dd1c4a  vmovaps [rsp+0x60], xmm6
000078d2e7dd1c50  vmovaps [rsp+0x70], xmm7
000078d2e7dd1c56  vmovaps [rsp+0x80], xmm8
000078d2e7dd1c5f  vmovaps [rsp+0x90], xmm9
000078d2e7dd1c68  vmovaps [rsp+0xA0], xmm10
000078d2e7dd1c71  vmovaps [rsp+0xB0], xmm11
000078d2e7dd1c7a  vmovaps [rsp+0xC0], xmm12
000078d2e7dd1c83  vmovaps [rsp+0xD0], xmm14
000078d2e7dd1c8c  vmovaps [rsp+0xE0], xmm15
000078d2e7dd1c95  sub rsp, 0x30
000078d2e7dd1c99  movaps [rsp], xmm13
000078d2e7dd1c9e  movaps [rsp+0x10], xmm12
000078d2e7dd1ca4  movaps [rsp+0x20], xmm1
000078d2e7dd1ca9  lea rdi, [rsp]
000078d2e7dd1cad  mov esi, 0x00
000078d2e7dd1cb2  mov rax, 0x5997D2DB1530
000078d2e7dd1cbc  call rax
000078d2e7dd1cbe  movaps xmm13, [rsp]
000078d2e7dd1cc3  add rsp, 0x30
000078d2e7dd1cc7  vmovaps xmm0, [rsp]
000078d2e7dd1ccc  vmovaps xmm1, [rsp+0x10]
000078d2e7dd1cd2  vmovaps xmm2, [rsp+0x20]
000078d2e7dd1cd8  vmovaps xmm3, [rsp+0x30]
000078d2e7dd1cde  vmovaps xmm4, [rsp+0x40]
000078d2e7dd1ce4  vmovaps xmm5, [rsp+0x50]
000078d2e7dd1cea  vmovaps xmm6, [rsp+0x60]
000078d2e7dd1cf0  vmovaps xmm7, [rsp+0x70]
000078d2e7dd1cf6  vmovaps xmm8, [rsp+0x80]
000078d2e7dd1cff  vmovaps xmm9, [rsp+0x90]
000078d2e7dd1d08  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd1d11  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd1d1a  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd1d23  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd1d2c  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd1d35  add rsp, 0xF0
000078d2e7dd1d3c  pop r11
000078d2e7dd1d3e  pop r10
000078d2e7dd1d40  pop r9
000078d2e7dd1d42  pop r8
000078d2e7dd1d44  pop rsi
000078d2e7dd1d45  pop rdi
000078d2e7dd1d46  pop rdx
000078d2e7dd1d47  pop rcx
000078d2e7dd1d48  pop rax
000078d2e7dd1d49  add rsp, 0x08
000078d2e7dd1d4d  jmp 0x000078D2E7DD1B21
000078d2e7dd1d52  call 0x000078D2E7C0C380
000078d2e7dd1d57  jmp 0x000078D2E7DD1B34
000078d2e7dd1d5c  sub rsp, 0x08
000078d2e7dd1d60  push rax
000078d2e7dd1d61  push rcx
000078d2e7dd1d62  push rdx
000078d2e7dd1d63  push rdi
000078d2e7dd1d64  push rsi
000078d2e7dd1d65  push r8
000078d2e7dd1d67  push r9
000078d2e7dd1d69  push r10
000078d2e7dd1d6b  push r11
000078d2e7dd1d6d  sub rsp, 0xF0
000078d2e7dd1d74  vmovaps [rsp], xmm0
000078d2e7dd1d79  vmovaps [rsp+0x10], xmm2
000078d2e7dd1d7f  vmovaps [rsp+0x20], xmm3
000078d2e7dd1d85  vmovaps [rsp+0x30], xmm4
000078d2e7dd1d8b  vmovaps [rsp+0x40], xmm5
000078d2e7dd1d91  vmovaps [rsp+0x50], xmm6
000078d2e7dd1d97  vmovaps [rsp+0x60], xmm7
000078d2e7dd1d9d  vmovaps [rsp+0x70], xmm8
000078d2e7dd1da3  vmovaps [rsp+0x80], xmm9
000078d2e7dd1dac  vmovaps [rsp+0x90], xmm10
000078d2e7dd1db5  vmovaps [rsp+0xA0], xmm11
000078d2e7dd1dbe  vmovaps [rsp+0xB0], xmm12
000078d2e7dd1dc7  vmovaps [rsp+0xC0], xmm13
000078d2e7dd1dd0  vmovaps [rsp+0xD0], xmm14
000078d2e7dd1dd9  vmovaps [rsp+0xE0], xmm15
000078d2e7dd1de2  sub rsp, 0x30
000078d2e7dd1de6  movaps [rsp], xmm1
000078d2e7dd1dea  movaps [rsp+0x10], xmm14
000078d2e7dd1df0  movaps [rsp+0x20], xmm15
000078d2e7dd1df6  lea rdi, [rsp]
000078d2e7dd1dfa  mov esi, 0x00
000078d2e7dd1dff  mov rax, 0x5997D2DB1530
000078d2e7dd1e09  call rax
000078d2e7dd1e0b  movaps xmm1, [rsp]
000078d2e7dd1e0f  add rsp, 0x30
000078d2e7dd1e13  vmovaps xmm0, [rsp]
000078d2e7dd1e18  vmovaps xmm2, [rsp+0x10]
000078d2e7dd1e1e  vmovaps xmm3, [rsp+0x20]
000078d2e7dd1e24  vmovaps xmm4, [rsp+0x30]
000078d2e7dd1e2a  vmovaps xmm5, [rsp+0x40]
000078d2e7dd1e30  vmovaps xmm6, [rsp+0x50]
000078d2e7dd1e36  vmovaps xmm7, [rsp+0x60]
000078d2e7dd1e3c  vmovaps xmm8, [rsp+0x70]
000078d2e7dd1e42  vmovaps xmm9, [rsp+0x80]
000078d2e7dd1e4b  vmovaps xmm10, [rsp+0x90]
000078d2e7dd1e54  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd1e5d  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd1e66  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd1e6f  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd1e78  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd1e81  add rsp, 0xF0
000078d2e7dd1e88  pop r11
000078d2e7dd1e8a  pop r10
000078d2e7dd1e8c  pop r9
000078d2e7dd1e8e  pop r8
000078d2e7dd1e90  pop rsi
000078d2e7dd1e91  pop rdi
000078d2e7dd1e92  pop rdx
000078d2e7dd1e93  pop rcx
000078d2e7dd1e94  pop rax
000078d2e7dd1e95  add rsp, 0x08
000078d2e7dd1e99  jmp 0x000078D2E7DD1B4E
000078d2e7dd1e9e  call 0x000078D2E7BFF540
000078d2e7dd1ea3  jmp 0x000078D2E7DD1B61
000078d2e7dd1ea8  int3
000078d2e7dd1ea9  nop [rax], eax
000078d2e7dd1eb0  movaps xmm1, [r15+0x180]
000078d2e7dd1eb8  vpmovqd xmm15, xmm1
000078d2e7dd1ebe  pxor xmm14, xmm14
000078d2e7dd1ec3  punpcklqdq xmm15, xmm14
000078d2e7dd1ec8  movaps [r15+0x210], xmm15
000078d2e7dd1ed0  movq xmm15, qword ptr [r15+0x140]
000078d2e7dd1ed9  movq xmm14, qword ptr [r15+0x120]
000078d2e7dd1ee2  psubd xmm15, xmm14
000078d2e7dd1ee7  movq xmm15, xmm15
000078d2e7dd1eec  movaps xmm13, [r15+0x170]
000078d2e7dd1ef4  paddq xmm1, xmm13
000078d2e7dd1ef9  movaps [r15+0x180], xmm1
000078d2e7dd1f01  movq xmm1, qword ptr [r15+0x160]
000078d2e7dd1f0a  paddd xmm14, xmm1
000078d2e7dd1f0f  movq xmm14, xmm14
000078d2e7dd1f14  movq xmm14, xmm14
000078d2e7dd1f19  movaps [r15+0x120], xmm14
000078d2e7dd1f21  pmovzxdq xmm15, xmm15
000078d2e7dd1f27  psllq xmm15, 0x00
000078d2e7dd1f2d  movq xmm1, qword ptr [r15+0x210]
000078d2e7dd1f36  movq xmm14, qword ptr [r15+0x110]
000078d2e7dd1f3f  paddd xmm1, xmm14
000078d2e7dd1f44  movq xmm1, xmm1
000078d2e7dd1f48  vcvtuqq2pd xmm15, xmm15
000078d2e7dd1f4e  pmovzxdq xmm1, xmm1
000078d2e7dd1f53  psllq xmm1, 0x00
000078d2e7dd1f58  vcvtuqq2pd xmm1, xmm1
000078d2e7dd1f5e  movaps xmm14, [r15+0x150]
000078d2e7dd1f66  movaps xmm13, xmm15
000078d2e7dd1f6a  mulpd xmm13, xmm14
000078d2e7dd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
000078d2e7dd1f75  ptest xmm12, xmm12
000078d2e7dd1f7b  jnz 0x000078D2E7DD205E
000078d2e7dd1f81  movaps [r15+0x220], xmm13
000078d2e7dd1f89  mov rax, [r15+0x48]
000078d2e7dd1f8d  mov r14, [r15+0x50]
000078d2e7dd1f91  lea r12, [r14+rax*1]
000078d2e7dd1f95  movups [r13+r12*1], xmm13
000078d2e7dd1f9b  movaps xmm15, [r15+0x130]
000078d2e7dd1fa3  movaps xmm14, xmm1
000078d2e7dd1fa7  mulpd xmm14, xmm15
000078d2e7dd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
000078d2e7dd1fb2  ptest xmm13, xmm13
000078d2e7dd1fb8  jnz 0x000078D2E7DD21AC
000078d2e7dd1fbe  movaps [r15+0x210], xmm14
000078d2e7dd1fc6  mov r14, [r15+0x40]
000078d2e7dd1fca  lea r12, [r14+rax*1]
000078d2e7dd1fce  movups [r13+r12*1], xmm14
000078d2e7dd1fd4  lea r14, [rax+0x10]
000078d2e7dd1fd8  mov [r15+0x48], r14
000078d2e7dd1fdc  xor eax, eax
000078d2e7dd1fde  mov r12d, 0x200
000078d2e7dd1fe4  cmp r14, r12
000078d2e7dd1fe7  cmc
000078d2e7dd1fe8  lahf
000078d2e7dd1fe9  seto al
000078d2e7dd1fec  mov [r15+0x108], eax
000078d2e7dd1ff3  mov eax, [r15+0x108]
000078d2e7dd1ffa  sahf
000078d2e7dd1ffb  jnz 0x000078D2E7DD202D
000078d2e7dd1ffd  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd2005  jz 0x000078D2E7DD2300
000078d2e7dd200b  nop [rax+rax*1], ax
000078d2e7dd2014  nop [rax+rax*1], eax
000078d2e7dd201c  mov eax, 0x410490
000078d2e7dd2021  mov [r15+0x100], rax
000078d2e7dd2028  jmp 0x000078D2E7BFE110
000078d2e7dd202d  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd2035  jz 0x000078D2E7DD1EB0
000078d2e7dd203b  nop [rax+rax*1], ax
000078d2e7dd2044  nop [rax+rax*1], eax
000078d2e7dd204c  mov eax, 0x410450
000078d2e7dd2051  mov [r15+0x100], rax
000078d2e7dd2058  jmp 0x000078D2E7BFE110
000078d2e7dd205d  int3
000078d2e7dd205e  sub rsp, 0x08
000078d2e7dd2062  push rax
000078d2e7dd2063  push rcx
000078d2e7dd2064  push rdx
000078d2e7dd2065  push rdi
000078d2e7dd2066  push rsi
000078d2e7dd2067  push r8
000078d2e7dd2069  push r9
000078d2e7dd206b  push r10
000078d2e7dd206d  push r11
000078d2e7dd206f  sub rsp, 0xF0
000078d2e7dd2076  vmovaps [rsp], xmm0
000078d2e7dd207b  vmovaps [rsp+0x10], xmm1
000078d2e7dd2081  vmovaps [rsp+0x20], xmm2
000078d2e7dd2087  vmovaps [rsp+0x30], xmm3
000078d2e7dd208d  vmovaps [rsp+0x40], xmm4
000078d2e7dd2093  vmovaps [rsp+0x50], xmm5
000078d2e7dd2099  vmovaps [rsp+0x60], xmm6
000078d2e7dd209f  vmovaps [rsp+0x70], xmm7
000078d2e7dd20a5  vmovaps [rsp+0x80], xmm8
000078d2e7dd20ae  vmovaps [rsp+0x90], xmm9
000078d2e7dd20b7  vmovaps [rsp+0xA0], xmm10
000078d2e7dd20c0  vmovaps [rsp+0xB0], xmm11
000078d2e7dd20c9  vmovaps [rsp+0xC0], xmm12
000078d2e7dd20d2  vmovaps [rsp+0xD0], xmm14
000078d2e7dd20db  vmovaps [rsp+0xE0], xmm15
000078d2e7dd20e4  sub rsp, 0x30
000078d2e7dd20e8  movaps [rsp], xmm13
000078d2e7dd20ed  movaps [rsp+0x10], xmm15
000078d2e7dd20f3  movaps [rsp+0x20], xmm14
000078d2e7dd20f9  lea rdi, [rsp]
000078d2e7dd20fd  mov esi, 0x00
000078d2e7dd2102  mov rax, 0x5997D2DB1530
000078d2e7dd210c  call rax
000078d2e7dd210e  movaps xmm13, [rsp]
000078d2e7dd2113  add rsp, 0x30
000078d2e7dd2117  vmovaps xmm0, [rsp]
000078d2e7dd211c  vmovaps xmm1, [rsp+0x10]
000078d2e7dd2122  vmovaps xmm2, [rsp+0x20]
000078d2e7dd2128  vmovaps xmm3, [rsp+0x30]
000078d2e7dd212e  vmovaps xmm4, [rsp+0x40]
000078d2e7dd2134  vmovaps xmm5, [rsp+0x50]
000078d2e7dd213a  vmovaps xmm6, [rsp+0x60]
000078d2e7dd2140  vmovaps xmm7, [rsp+0x70]
000078d2e7dd2146  vmovaps xmm8, [rsp+0x80]
000078d2e7dd214f  vmovaps xmm9, [rsp+0x90]
000078d2e7dd2158  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd2161  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd216a  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd2173  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd217c  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd2185  add rsp, 0xF0
000078d2e7dd218c  pop r11
000078d2e7dd218e  pop r10
000078d2e7dd2190  pop r9
000078d2e7dd2192  pop r8
000078d2e7dd2194  pop rsi
000078d2e7dd2195  pop rdi
000078d2e7dd2196  pop rdx
000078d2e7dd2197  pop rcx
000078d2e7dd2198  pop rax
000078d2e7dd2199  add rsp, 0x08
000078d2e7dd219d  jmp 0x000078D2E7DD1F81
000078d2e7dd21a2  call 0x000078D2E7CC2240
000078d2e7dd21a7  jmp 0x000078D2E7DD1F9B
000078d2e7dd21ac  sub rsp, 0x08
000078d2e7dd21b0  push rax
000078d2e7dd21b1  push rcx
000078d2e7dd21b2  push rdx
000078d2e7dd21b3  push rdi
000078d2e7dd21b4  push rsi
000078d2e7dd21b5  push r8
000078d2e7dd21b7  push r9
000078d2e7dd21b9  push r10
000078d2e7dd21bb  push r11
000078d2e7dd21bd  sub rsp, 0xF0
000078d2e7dd21c4  vmovaps [rsp], xmm0
000078d2e7dd21c9  vmovaps [rsp+0x10], xmm1
000078d2e7dd21cf  vmovaps [rsp+0x20], xmm2
000078d2e7dd21d5  vmovaps [rsp+0x30], xmm3
000078d2e7dd21db  vmovaps [rsp+0x40], xmm4
000078d2e7dd21e1  vmovaps [rsp+0x50], xmm5
000078d2e7dd21e7  vmovaps [rsp+0x60], xmm6
000078d2e7dd21ed  vmovaps [rsp+0x70], xmm7
000078d2e7dd21f3  vmovaps [rsp+0x80], xmm8
000078d2e7dd21fc  vmovaps [rsp+0x90], xmm9
000078d2e7dd2205  vmovaps [rsp+0xA0], xmm10
000078d2e7dd220e  vmovaps [rsp+0xB0], xmm11
000078d2e7dd2217  vmovaps [rsp+0xC0], xmm12
000078d2e7dd2220  vmovaps [rsp+0xD0], xmm13
000078d2e7dd2229  vmovaps [rsp+0xE0], xmm15
000078d2e7dd2232  sub rsp, 0x30
000078d2e7dd2236  movaps [rsp], xmm14
000078d2e7dd223b  movaps [rsp+0x10], xmm1
000078d2e7dd2240  movaps [rsp+0x20], xmm15
000078d2e7dd2246  lea rdi, [rsp]
000078d2e7dd224a  mov esi, 0x00
000078d2e7dd224f  mov rax, 0x5997D2DB1530
000078d2e7dd2259  call rax
000078d2e7dd225b  movaps xmm14, [rsp]
000078d2e7dd2260  add rsp, 0x30
000078d2e7dd2264  vmovaps xmm0, [rsp]
000078d2e7dd2269  vmovaps xmm1, [rsp+0x10]
000078d2e7dd226f  vmovaps xmm2, [rsp+0x20]
000078d2e7dd2275  vmovaps xmm3, [rsp+0x30]
000078d2e7dd227b  vmovaps xmm4, [rsp+0x40]
000078d2e7dd2281  vmovaps xmm5, [rsp+0x50]
000078d2e7dd2287  vmovaps xmm6, [rsp+0x60]
000078d2e7dd228d  vmovaps xmm7, [rsp+0x70]
000078d2e7dd2293  vmovaps xmm8, [rsp+0x80]
000078d2e7dd229c  vmovaps xmm9, [rsp+0x90]
000078d2e7dd22a5  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd22ae  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd22b7  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd22c0  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd22c9  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd22d2  add rsp, 0xF0
000078d2e7dd22d9  pop r11
000078d2e7dd22db  pop r10
000078d2e7dd22dd  pop r9
000078d2e7dd22df  pop r8
000078d2e7dd22e1  pop rsi
000078d2e7dd22e2  pop rdi
000078d2e7dd22e3  pop rdx
000078d2e7dd22e4  pop rcx
000078d2e7dd22e5  pop rax
000078d2e7dd22e6  add rsp, 0x08
000078d2e7dd22ea  jmp 0x000078D2E7DD1FBE
000078d2e7dd22ef  call 0x000078D2E7CC34C0
000078d2e7dd22f4  jmp 0x000078D2E7DD1FD4
000078d2e7dd22f9  int3
000078d2e7dd22fa  nop [rax+rax*1], ax
000078d2e7dd2300  mov rax, [r15+0x50]
000078d2e7dd2304  lea r14, [rax+0x80]
000078d2e7dd230b  movups xmm1, [r13+r14*1]
000078d2e7dd2311  lea r14, [rax+0x90]
000078d2e7dd2318  movups xmm15, [r13+r14*1]
000078d2e7dd231e  vxorps xmm14, xmm14, xmm14
000078d2e7dd2323  vpbroadcastq xmm14, xmm14
000078d2e7dd2328  lea r14, [rax+0x40]
000078d2e7dd232c  movups xmm13, [r13+r14*1]
000078d2e7dd2332  lea r14, [rax+0x50]
000078d2e7dd2336  movups xmm12, [r13+r14*1]
000078d2e7dd233c  mov qword ptr [r15+0x48], 0x00
000078d2e7dd2344  movups xmm11, [r13+rax*1]
000078d2e7dd234a  lea r14, [rax+0x10]
000078d2e7dd234e  movups xmm10, [r13+r14*1]
000078d2e7dd2354  mov r14, [r15+0xF8]
000078d2e7dd235b  lea r12, [r14+0xE0]
000078d2e7dd2362  movups [r13+r12*1], xmm15
000078d2e7dd2368  lea r12, [r14+0xF0]
000078d2e7dd236f  movups [r13+r12*1], xmm1
000078d2e7dd2375  lea r12, [rax+0xC0]
000078d2e7dd237c  movups xmm1, [r13+r12*1]
000078d2e7dd2382  lea r12, [rax+0xD0]
000078d2e7dd2389  movups xmm15, [r13+r12*1]
000078d2e7dd238f  lea r12, [rax+0x140]
000078d2e7dd2396  movups xmm9, [r13+r12*1]
000078d2e7dd239c  lea r12, [rax+0x150]
000078d2e7dd23a3  movups xmm8, [r13+r12*1]
000078d2e7dd23a9  lea r12, [rax+0x180]
000078d2e7dd23b0  movups xmm7, [r13+r12*1]
000078d2e7dd23b6  lea r12, [rax+0x190]
000078d2e7dd23bd  movups xmm6, [r13+r12*1]
000078d2e7dd23c3  lea r12, [r14+0xC0]
000078d2e7dd23ca  movups [r13+r12*1], xmm15
000078d2e7dd23d0  lea r12, [r14+0xD0]
000078d2e7dd23d7  movups [r13+r12*1], xmm1
000078d2e7dd23dd  lea r12, [rax+0x100]
000078d2e7dd23e4  movups xmm1, [r13+r12*1]
000078d2e7dd23ea  lea r12, [rax+0x110]
000078d2e7dd23f1  movups xmm15, [r13+r12*1]
000078d2e7dd23f7  lea r12, [rax+0x1C0]
000078d2e7dd23fe  movups xmm5, [r13+r12*1]
000078d2e7dd2404  lea r12, [rax+0x1D0]
000078d2e7dd240b  movups xmm4, [r13+r12*1]
000078d2e7dd2411  lea r12, [rax+0x20]
000078d2e7dd2415  movups xmm3, [r13+r12*1]
000078d2e7dd241b  lea r12, [rax+0x30]
000078d2e7dd241f  movups xmm2, [r13+r12*1]
000078d2e7dd2425  movaps [r15+0x1F0], xmm2
000078d2e7dd242d  lea r12, [r14+0x20]
000078d2e7dd2431  movups [r13+r12*1], xmm1
000078d2e7dd2437  lea r12, [r14+0x30]
000078d2e7dd243b  movups [r13+r12*1], xmm12
000078d2e7dd2441  lea r12, [rax+0x60]
000078d2e7dd2445  movups xmm1, [r13+r12*1]
000078d2e7dd244b  lea r12, [rax+0x70]
000078d2e7dd244f  movups xmm12, [r13+r12*1]
000078d2e7dd2455  lea r12, [r14+0x60]
000078d2e7dd2459  movups [r13+r12*1], xmm11
000078d2e7dd245f  lea r12, [r14+0x70]
000078d2e7dd2463  movups [r13+r12*1], xmm5
000078d2e7dd2469  lea r12, [rax+0xE0]
000078d2e7dd2470  movups xmm11, [r13+r12*1]
000078d2e7dd2476  lea r12, [rax+0xF0]
000078d2e7dd247d  movups xmm5, [r13+r12*1]
000078d2e7dd2483  lea r12, [rax+0x120]
000078d2e7dd248a  vmovaps [rsp+0x10], xmm1
000078d2e7dd2490  movups xmm1, [r13+r12*1]
000078d2e7dd2496  lea r12, [rax+0x130]
000078d2e7dd249d  vmovaps [rsp+0x20], xmm1
000078d2e7dd24a3  movups xmm1, [r13+r12*1]
000078d2e7dd24a9  lea r12, [r14+0xA0]
000078d2e7dd24b0  movups [r13+r12*1], xmm12
000078d2e7dd24b6  lea r12, [r14+0xB0]
000078d2e7dd24bd  vmovaps xmm12, [rsp+0x10]
000078d2e7dd24c3  movups [r13+r12*1], xmm12
000078d2e7dd24c9  lea r12, [rax+0xA0]
000078d2e7dd24d0  movups xmm12, [r13+r12*1]
000078d2e7dd24d6  lea r12, [rax+0xB0]
000078d2e7dd24dd  vmovaps [rsp+0x10], xmm1
000078d2e7dd24e3  movups xmm1, [r13+r12*1]
000078d2e7dd24e9  lea r12, [rax+0x160]
000078d2e7dd24f0  vmovaps [rsp+0x30], xmm1
000078d2e7dd24f6  movups xmm1, [r13+r12*1]
000078d2e7dd24fc  lea r12, [rax+0x170]
000078d2e7dd2503  vmovaps [rsp+0x40], xmm1
000078d2e7dd2509  movups xmm1, [r13+r12*1]
000078d2e7dd250f  movaps [r15+0x2B0], xmm1
000078d2e7dd2517  lea r12, [rax+0x1A0]
000078d2e7dd251e  vmovaps [rsp+0x50], xmm1
000078d2e7dd2524  movups xmm1, [r13+r12*1]
000078d2e7dd252a  lea r12, [rax+0x1B0]
000078d2e7dd2531  vmovaps [rsp+0x60], xmm1
000078d2e7dd2537  movups xmm1, [r13+r12*1]
000078d2e7dd253d  vmovaps [rsp+0x70], xmm1
000078d2e7dd2543  vmovaps xmm1, [rsp+0x60]
000078d2e7dd2549  movaps [r15+0x290], xmm1
000078d2e7dd2551  vmovaps [rsp+0x60], xmm1
000078d2e7dd2557  vmovaps xmm1, [rsp+0x70]
000078d2e7dd255d  movaps [r15+0x1E0], xmm1
000078d2e7dd2565  lea r12, [r14+0x80]
000078d2e7dd256c  vmovaps [rsp+0x70], xmm1
000078d2e7dd2572  vmovaps xmm1, [rsp+0x30]
000078d2e7dd2578  movups [r13+r12*1], xmm1
000078d2e7dd257e  lea r12, [r14+0x90]
000078d2e7dd2585  movups [r13+r12*1], xmm12
000078d2e7dd258b  lea r12, [rax+0x1E0]
000078d2e7dd2592  movups xmm1, [r13+r12*1]
000078d2e7dd2598  lea r12, [rax+0x1F0]
000078d2e7dd259f  movups xmm12, [r13+r12*1]
000078d2e7dd25a5  mov qword ptr [r15+0x50], 0x432200
000078d2e7dd25ad  lea rax, [r14+0x40]
000078d2e7dd25b1  vmovaps [rsp+0x30], xmm1
000078d2e7dd25b7  vmovaps xmm1, [rsp+0x40]
000078d2e7dd25bd  movups [r13+rax*1], xmm1
000078d2e7dd25c3  lea rax, [r14+0x50]
000078d2e7dd25c7  movups [r13+rax*1], xmm10
000078d2e7dd25cd  movups [r13+r14*1], xmm12
000078d2e7dd25d3  lea rax, [r14+0x10]
000078d2e7dd25d7  vmovaps xmm1, [rsp+0x30]
000078d2e7dd25dd  movups [r13+rax*1], xmm1
000078d2e7dd25e3  mov rax, [r15+0x40]
000078d2e7dd25e7  vmovaps [rsp+0x30], xmm3
000078d2e7dd25ed  vmovaps xmm1, [rsp+0x30]
000078d2e7dd25f3  por xmm3, xmm1
000078d2e7dd25f7  vmovaps [rsp+0x30], xmm6
000078d2e7dd25fd  vmovaps xmm12, [rsp+0x30]
000078d2e7dd2603  por xmm6, xmm12
000078d2e7dd2608  lea r12, [rax+0x30]
000078d2e7dd260c  mov r11, [r13+r12*1]
000078d2e7dd2611  lea r12, [rax+0x38]
000078d2e7dd2615  mov r10, [r13+r12*1]
000078d2e7dd261a  movq xmm12, r11
000078d2e7dd261f  movq xmm10, r10
000078d2e7dd2624  movq xmm12, xmm12
000078d2e7dd2629  vmovaps [rsp+0x30], xmm12
000078d2e7dd262f  movq xmm12, xmm12
000078d2e7dd2634  movaps [r15+0x130], xmm12
000078d2e7dd263c  movq xmm10, xmm10
000078d2e7dd2641  vmovaps [rsp+0x40], xmm10
000078d2e7dd2647  movq xmm10, xmm10
000078d2e7dd264c  movaps [r15+0x280], xmm10
000078d2e7dd2654  vmovaps [rsp+0x80], xmm9
000078d2e7dd265d  vmovaps xmm12, [rsp+0x80]
000078d2e7dd2666  por xmm9, xmm12
000078d2e7dd266b  lea r12, [rax+0x20]
000078d2e7dd266f  mov r11, [r13+r12*1]
000078d2e7dd2674  lea r12, [rax+0x28]
000078d2e7dd2678  mov r10, [r13+r12*1]
000078d2e7dd267d  movq xmm12, r11
000078d2e7dd2682  movq xmm10, r10
000078d2e7dd2687  movq xmm12, xmm12
000078d2e7dd268c  vmovaps [rsp+0x80], xmm12
000078d2e7dd2695  movq xmm12, xmm12
000078d2e7dd269a  movaps [r15+0x150], xmm12
000078d2e7dd26a2  movq xmm10, xmm10
000078d2e7dd26a7  vmovaps [rsp+0x90], xmm10
000078d2e7dd26b0  movq xmm10, xmm10
000078d2e7dd26b5  movaps [r15+0x140], xmm10
000078d2e7dd26bd  lea r12, [rax+0x10]
000078d2e7dd26c1  mov r11, [r13+r12*1]
000078d2e7dd26c6  lea r12, [rax+0x18]
000078d2e7dd26ca  mov r10, [r13+r12*1]
000078d2e7dd26cf  movq xmm12, r11
000078d2e7dd26d4  movq xmm10, r10
000078d2e7dd26d9  movq xmm12, xmm12
000078d2e7dd26de  vmovaps [rsp+0xA0], xmm12
000078d2e7dd26e7  movq xmm12, xmm12
000078d2e7dd26ec  movaps [r15+0x170], xmm12
000078d2e7dd26f4  movq xmm10, xmm10
000078d2e7dd26f9  vmovaps [rsp+0xB0], xmm10
000078d2e7dd2702  movq xmm10, xmm10
000078d2e7dd2707  movaps [r15+0x160], xmm10
000078d2e7dd270f  mov r12, [r13+rax*1]
000078d2e7dd2714  vmovq xmm12, r12
000078d2e7dd2719  vpbroadcastq xmm12, xmm12
000078d2e7dd271e  lea r12, [rax+0x08]
000078d2e7dd2722  mov rax, [r13+r12*1]
000078d2e7dd2727  movq xmm10, rax
000078d2e7dd272c  movaps [r15+0x230], xmm10
000078d2e7dd2734  lea rax, [r14+0x50]
000078d2e7dd2738  movups xmm10, [r13+rax*1]
000078d2e7dd273e  lea rax, [r14+0x60]
000078d2e7dd2742  vmovaps [rsp+0xC0], xmm1
000078d2e7dd274b  movups xmm1, [r13+rax*1]
000078d2e7dd2751  lea rax, [r14+0x30]
000078d2e7dd2755  vmovaps [rsp+0xD0], xmm1
000078d2e7dd275e  movups xmm1, [r13+rax*1]
000078d2e7dd2764  mov qword ptr [r15+0x60], 0x432200
000078d2e7dd276c  mov qword ptr [r15+0x58], 0x40
000078d2e7dd2774  vmovaps [rsp+0xE0], xmm1
000078d2e7dd277d  vmovaps [rsp+0xF0], xmm15
000078d2e7dd2786  vmovaps xmm15, [rsp+0xC0]
000078d2e7dd278f  vmovaps [rsp+0xC0], xmm14
000078d2e7dd2798  movaps xmm1, xmm12
000078d2e7dd279c  mulpd xmm1, xmm15
000078d2e7dd27a1  vcmppd xmm14, xmm1, xmm1, 0x03
000078d2e7dd27a6  ptest xmm14, xmm14
000078d2e7dd27ac  jnz 0x000078D2E7DD3863
000078d2e7dd27b2  movq xmm15, qword ptr [r15+0x230]
000078d2e7dd27bb  vmovaps [rsp+0x100], xmm15
000078d2e7dd27c4  vpermilpd xmm15, xmm15, 0x00
000078d2e7dd27ca  vmovaps [rsp+0x110], xmm1
000078d2e7dd27d3  vmovaps xmm1, [rsp+0xE0]
000078d2e7dd27dc  vmovaps [rsp+0xE0], xmm13
000078d2e7dd27e5  movaps xmm14, xmm1
000078d2e7dd27e9  mulpd xmm14, xmm15
000078d2e7dd27ee  vcmppd xmm13, xmm14, xmm14, 0x03
000078d2e7dd27f4  ptest xmm13, xmm13
000078d2e7dd27fa  jnz 0x000078D2E7DD39A5
000078d2e7dd2800  vxorps xmm1, xmm1, xmm1
000078d2e7dd2804  vpbroadcastq xmm1, xmm1
000078d2e7dd2809  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd2812  vmovaps [rsp+0xD0], xmm1
000078d2e7dd281b  movaps xmm15, xmm12
000078d2e7dd281f  mulpd xmm15, xmm13
000078d2e7dd2824  vcmppd xmm1, xmm15, xmm15, 0x03
000078d2e7dd282a  ptest xmm1, xmm1
000078d2e7dd282f  jnz 0x000078D2E7DD3AE8
000078d2e7dd2835  movaps xmm1, xmm12
000078d2e7dd2839  mulpd xmm1, xmm10
000078d2e7dd283e  vcmppd xmm13, xmm1, xmm1, 0x03
000078d2e7dd2843  ptest xmm13, xmm13
000078d2e7dd2849  jnz 0x000078D2E7DD3C2C
000078d2e7dd284f  movaps xmm13, xmm12
000078d2e7dd2853  mulpd xmm13, xmm2
000078d2e7dd2858  vcmppd xmm10, xmm13, xmm13, 0x03
000078d2e7dd285e  ptest xmm10, xmm10
000078d2e7dd2864  jnz 0x000078D2E7DD3D6E
000078d2e7dd286a  vmovaps [rsp+0x120], xmm7
000078d2e7dd2873  vmovaps xmm12, [rsp+0x120]
000078d2e7dd287c  por xmm7, xmm12
000078d2e7dd2881  vmovaps xmm12, [rsp+0xE0]
000078d2e7dd288a  vmovaps xmm10, [rsp+0xE0]
000078d2e7dd2893  por xmm12, xmm10
000078d2e7dd2898  vmovaps xmm2, [rsp+0x100]
000078d2e7dd28a1  vpermilpd xmm2, xmm2, 0x00
000078d2e7dd28a7  vmovaps [rsp+0xE0], xmm1
000078d2e7dd28b0  vmovaps [rsp+0x120], xmm15
000078d2e7dd28b9  movaps xmm1, xmm10
000078d2e7dd28bd  mulpd xmm1, xmm2
000078d2e7dd28c1  vcmppd xmm15, xmm1, xmm1, 0x03
000078d2e7dd28c6  ptest xmm15, xmm15
000078d2e7dd28cc  jnz 0x000078D2E7DD3EB1
000078d2e7dd28d2  xor eax, eax
000078d2e7dd28d4  mov r12d, 0x40
000078d2e7dd28da  mov r11d, 0x200
000078d2e7dd28e0  cmp r12, r11
000078d2e7dd28e3  cmc
000078d2e7dd28e4  lahf
000078d2e7dd28e5  seto al
000078d2e7dd28e8  mov [r15+0x108], eax
000078d2e7dd28ef  vmovaps xmm10, [rsp+0x110]
000078d2e7dd28f8  vmovaps xmm2, [rsp+0xD0]
000078d2e7dd2901  vmovaps [rsp+0xD0], xmm1
000078d2e7dd290a  movaps xmm15, xmm10
000078d2e7dd290e  addpd xmm15, xmm2
000078d2e7dd2913  vcmppd xmm1, xmm15, xmm15, 0x03
000078d2e7dd2919  ptest xmm1, xmm1
000078d2e7dd291e  jnz 0x000078D2E7DD3FF2
000078d2e7dd2924  vmovaps xmm10, [rsp+0x120]
000078d2e7dd292d  vmovaps [rsp+0x110], xmm15
000078d2e7dd2936  vmovaps xmm15, [rsp+0xC0]
000078d2e7dd293f  vmovaps [rsp+0xC0], xmm14
000078d2e7dd2948  movaps xmm1, xmm10
000078d2e7dd294c  addpd xmm1, xmm15
000078d2e7dd2951  vcmppd xmm14, xmm1, xmm1, 0x03
000078d2e7dd2956  ptest xmm14, xmm14
000078d2e7dd295c  jnz 0x000078D2E7DD4135
000078d2e7dd2962  vmovaps xmm10, [rsp+0xE0]
000078d2e7dd296b  vmovaps [rsp+0xE0], xmm1
000078d2e7dd2974  movaps xmm14, xmm10
000078d2e7dd2978  addpd xmm14, xmm15
000078d2e7dd297d  vcmppd xmm1, xmm14, xmm14, 0x03
000078d2e7dd2983  ptest xmm1, xmm1
000078d2e7dd2988  jnz 0x000078D2E7DD4277
000078d2e7dd298e  vmovaps xmm1, [rsp+0x10]
000078d2e7dd2994  vmovaps xmm15, [rsp+0x10]
000078d2e7dd299a  por xmm1, xmm15
000078d2e7dd299f  vmovaps xmm15, [rsp+0x20]
000078d2e7dd29a5  vmovaps xmm10, [rsp+0x20]
000078d2e7dd29ab  por xmm15, xmm10
000078d2e7dd29b0  vmovaps [rsp+0x10], xmm5
000078d2e7dd29b6  vmovaps xmm10, [rsp+0x10]
000078d2e7dd29bc  por xmm5, xmm10
000078d2e7dd29c1  vmovaps [rsp+0x10], xmm11
000078d2e7dd29c7  vmovaps xmm10, [rsp+0x10]
000078d2e7dd29cd  por xmm11, xmm10
000078d2e7dd29d2  vmovaps [rsp+0x10], xmm4
000078d2e7dd29d8  vmovaps xmm10, [rsp+0x10]
000078d2e7dd29de  por xmm4, xmm10
000078d2e7dd29e3  vmovaps [rsp+0x10], xmm8
000078d2e7dd29e9  vmovaps xmm10, [rsp+0x10]
000078d2e7dd29ef  por xmm8, xmm10
000078d2e7dd29f4  vmovaps xmm10, [rsp+0xF0]
000078d2e7dd29fd  vmovaps [rsp+0x10], xmm1
000078d2e7dd2a03  vmovaps xmm1, [rsp+0xF0]
000078d2e7dd2a0c  por xmm10, xmm1
000078d2e7dd2a11  lea rax, [r14+0xA0]
000078d2e7dd2a18  movups xmm1, [r13+rax*1]
000078d2e7dd2a1e  lea rax, [r14+0xB0]
000078d2e7dd2a25  vmovaps [rsp+0x20], xmm1
000078d2e7dd2a2b  movups xmm1, [r13+rax*1]
000078d2e7dd2a31  vmovaps [rsp+0xF0], xmm1
000078d2e7dd2a3a  vmovaps [rsp+0x120], xmm15
000078d2e7dd2a43  movaps xmm1, xmm13
000078d2e7dd2a47  addpd xmm1, xmm2
000078d2e7dd2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
000078d2e7dd2a50  ptest xmm15, xmm15
000078d2e7dd2a56  jnz 0x000078D2E7DD43CF
000078d2e7dd2a5c  lea rax, [r14+0xF0]
000078d2e7dd2a63  movups xmm15, [r13+rax*1]
000078d2e7dd2a69  vmovaps xmm2, [rsp+0xE0]
000078d2e7dd2a72  vmovaps [rsp+0xE0], xmm1
000078d2e7dd2a7b  vmovaps xmm1, [rsp+0xD0]
000078d2e7dd2a84  vmovaps [rsp+0xD0], xmm15
000078d2e7dd2a8d  movaps xmm13, xmm2
000078d2e7dd2a91  addpd xmm13, xmm1
000078d2e7dd2a96  vcmppd xmm15, xmm13, xmm13, 0x03
000078d2e7dd2a9c  ptest xmm15, xmm15
000078d2e7dd2aa2  jnz 0x000078D2E7DD451A
000078d2e7dd2aa8  vmovaps xmm15, [rsp+0xC0]
000078d2e7dd2ab1  movaps xmm1, xmm14
000078d2e7dd2ab5  addpd xmm1, xmm15
000078d2e7dd2aba  vcmppd xmm2, xmm1, xmm1, 0x03
000078d2e7dd2abf  ptest xmm2, xmm2
000078d2e7dd2ac4  jnz 0x000078D2E7DD465C
000078d2e7dd2aca  vmovaps xmm15, [rsp+0x100]
000078d2e7dd2ad3  vpermilpd xmm15, xmm15, 0x00
000078d2e7dd2ad9  vmovaps xmm2, [rsp+0xF0]
000078d2e7dd2ae2  vmovaps [rsp+0xC0], xmm1
000078d2e7dd2aeb  movaps xmm14, xmm2
000078d2e7dd2aef  mulpd xmm14, xmm15
000078d2e7dd2af4  vcmppd xmm1, xmm14, xmm14, 0x03
000078d2e7dd2afa  ptest xmm1, xmm1
000078d2e7dd2aff  jnz 0x000078D2E7DD479E
000078d2e7dd2b05  vmovaps xmm1, [rsp+0xA0]
000078d2e7dd2b0e  vpermilpd xmm1, xmm1, 0x00
000078d2e7dd2b14  vmovaps xmm2, [rsp+0xD0]
000078d2e7dd2b1d  vmovaps [rsp+0xD0], xmm14
000078d2e7dd2b26  movaps xmm15, xmm2
000078d2e7dd2b2a  mulpd xmm15, xmm1
000078d2e7dd2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
000078d2e7dd2b35  ptest xmm14, xmm14
000078d2e7dd2b3b  jnz 0x000078D2E7DD48E1
000078d2e7dd2b41  lea rax, [r14+0xE0]
000078d2e7dd2b48  movups xmm1, [r13+rax*1]
000078d2e7dd2b4e  vmovaps xmm14, [rsp+0x100]
000078d2e7dd2b57  vpermilpd xmm14, xmm14, 0x00
000078d2e7dd2b5d  vmovaps [rsp+0xF0], xmm1
000078d2e7dd2b66  vmovaps xmm1, [rsp+0x20]
000078d2e7dd2b6c  vmovaps [rsp+0x20], xmm15
000078d2e7dd2b72  movaps xmm2, xmm1
000078d2e7dd2b75  mulpd xmm2, xmm14
000078d2e7dd2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
000078d2e7dd2b7f  ptest xmm15, xmm15
000078d2e7dd2b85  jnz 0x000078D2E7DD4A2D
000078d2e7dd2b8b  vmovaps [rsp+0x100], xmm10
000078d2e7dd2b94  vmovaps xmm1, [rsp+0x100]
000078d2e7dd2b9d  por xmm10, xmm1
000078d2e7dd2ba2  movaps [r15+0x300], xmm10
000078d2e7dd2baa  vmovaps [rsp+0x100], xmm8
000078d2e7dd2bb3  vmovaps xmm1, [rsp+0x100]
000078d2e7dd2bbc  por xmm8, xmm1
000078d2e7dd2bc1  movaps [r15+0x190], xmm8
000078d2e7dd2bc9  vmovaps xmm1, [rsp+0xA0]
000078d2e7dd2bd2  vpermilpd xmm1, xmm1, 0x00
000078d2e7dd2bd8  vmovaps xmm14, [rsp+0xF0]
000078d2e7dd2be1  vmovaps [rsp+0xF0], xmm13
000078d2e7dd2bea  movaps xmm15, xmm14
000078d2e7dd2bee  mulpd xmm15, xmm1
000078d2e7dd2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
000078d2e7dd2bf9  ptest xmm13, xmm13
000078d2e7dd2bff  jnz 0x000078D2E7DD4B6E
000078d2e7dd2c05  lea rax, [r14+0x90]
000078d2e7dd2c0c  movups xmm1, [r13+rax*1]
000078d2e7dd2c12  vmovaps [rsp+0x100], xmm4
000078d2e7dd2c1b  vmovaps xmm14, [rsp+0x100]
000078d2e7dd2c24  por xmm4, xmm14
000078d2e7dd2c29  movaps [r15+0x1C0], xmm4
000078d2e7dd2c31  vmovaps [rsp+0x100], xmm11
000078d2e7dd2c3a  vmovaps xmm14, [rsp+0x100]
000078d2e7dd2c43  por xmm11, xmm14
000078d2e7dd2c48  movaps [r15+0x200], xmm11
000078d2e7dd2c50  vmovaps [rsp+0x100], xmm5
000078d2e7dd2c59  vmovaps xmm14, [rsp+0x100]
000078d2e7dd2c62  por xmm5, xmm14
000078d2e7dd2c67  movaps [r15+0x2D0], xmm5
000078d2e7dd2c6f  vmovaps xmm14, [rsp+0x120]
000078d2e7dd2c78  vmovaps xmm13, [rsp+0x120]
000078d2e7dd2c81  por xmm14, xmm13
000078d2e7dd2c86  movaps [r15+0x2E0], xmm14
000078d2e7dd2c8e  vmovaps [rsp+0x100], xmm1
000078d2e7dd2c97  vmovaps xmm1, [rsp+0x110]
000078d2e7dd2ca0  vmovaps [rsp+0x110], xmm15
000078d2e7dd2ca9  vmovaps xmm15, [rsp+0xD0]
000078d2e7dd2cb2  vmovaps [rsp+0xD0], xmm14
000078d2e7dd2cbb  movaps xmm13, xmm1
000078d2e7dd2cbf  addpd xmm13, xmm15
000078d2e7dd2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
000078d2e7dd2cca  ptest xmm14, xmm14
000078d2e7dd2cd0  jnz 0x000078D2E7DD4CBB
000078d2e7dd2cd6  vmovaps xmm1, [rsp+0xA0]
000078d2e7dd2cdf  vpermilpd xmm1, xmm1, 0x00
000078d2e7dd2ce5  vmovaps xmm14, [rsp+0x100]
000078d2e7dd2cee  vmovaps [rsp+0x100], xmm13
000078d2e7dd2cf7  movaps xmm15, xmm14
000078d2e7dd2cfb  mulpd xmm15, xmm1
000078d2e7dd2d00  vcmppd xmm13, xmm15, xmm15, 0x03
000078d2e7dd2d06  ptest xmm13, xmm13
000078d2e7dd2d0c  jnz 0x000078D2E7DD4DFE
000078d2e7dd2d12  lea rax, [r14+0x80]
000078d2e7dd2d19  movups xmm1, [r13+rax*1]
000078d2e7dd2d1f  vmovaps xmm13, [rsp+0xE0]
000078d2e7dd2d28  vmovaps [rsp+0xE0], xmm1
000078d2e7dd2d31  movaps xmm14, xmm13
000078d2e7dd2d35  addpd xmm14, xmm2
000078d2e7dd2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
000078d2e7dd2d40  ptest xmm1, xmm1
000078d2e7dd2d45  jnz 0x000078D2E7DD4F4B
000078d2e7dd2d4b  vmovaps xmm13, [rsp+0xF0]
000078d2e7dd2d54  vmovaps xmm2, [rsp+0x20]
000078d2e7dd2d5a  vmovaps [rsp+0x20], xmm15
000078d2e7dd2d60  movaps xmm1, xmm13
000078d2e7dd2d64  addpd xmm1, xmm2
000078d2e7dd2d68  vcmppd xmm15, xmm1, xmm1, 0x03
000078d2e7dd2d6d  ptest xmm15, xmm15
000078d2e7dd2d73  jnz 0x000078D2E7DD508E
000078d2e7dd2d79  vmovaps xmm15, [rsp+0x10]
000078d2e7dd2d7f  vmovaps xmm13, [rsp+0x10]
000078d2e7dd2d85  por xmm15, xmm13
000078d2e7dd2d8a  movaps [r15+0x2F0], xmm15
000078d2e7dd2d92  vmovaps xmm13, [rsp+0xA0]
000078d2e7dd2d9b  vpermilpd xmm13, xmm13, 0x00
000078d2e7dd2da1  vmovaps [rsp+0x10], xmm1
000078d2e7dd2da7  vmovaps xmm1, [rsp+0xE0]
000078d2e7dd2db0  vmovaps [rsp+0xA0], xmm15
000078d2e7dd2db9  movaps xmm2, xmm1
000078d2e7dd2dbc  mulpd xmm2, xmm13
000078d2e7dd2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
000078d2e7dd2dc6  ptest xmm15, xmm15
000078d2e7dd2dcc  jnz 0x000078D2E7DD51CF
000078d2e7dd2dd2  lea rax, [r14+0xD0]
000078d2e7dd2dd9  movups xmm1, [r13+rax*1]
000078d2e7dd2ddf  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd2de8  vmovaps [rsp+0xC0], xmm1
000078d2e7dd2df1  vmovaps xmm1, [rsp+0x110]
000078d2e7dd2dfa  vmovaps [rsp+0xE0], xmm14
000078d2e7dd2e03  movaps xmm15, xmm13
000078d2e7dd2e07  addpd xmm15, xmm1
000078d2e7dd2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
000078d2e7dd2e12  ptest xmm14, xmm14
000078d2e7dd2e18  jnz 0x000078D2E7DD531A
000078d2e7dd2e1e  vmovaps xmm1, [rsp+0xB0]
000078d2e7dd2e27  vpermilpd xmm1, xmm1, 0x00
000078d2e7dd2e2d  movaps xmm14, xmm11
000078d2e7dd2e31  mulpd xmm14, xmm1
000078d2e7dd2e36  vcmppd xmm13, xmm14, xmm14, 0x03
000078d2e7dd2e3c  ptest xmm13, xmm13
000078d2e7dd2e42  jnz 0x000078D2E7DD545D
000078d2e7dd2e48  movaps [r15+0x260], xmm14
000078d2e7dd2e50  vxorps xmm1, xmm1, xmm1
000078d2e7dd2e54  vpbroadcastq xmm1, xmm1
000078d2e7dd2e59  movaps [r15+0x1B0], xmm1
000078d2e7dd2e61  vmovaps xmm1, [rsp+0xB0]
000078d2e7dd2e6a  vpermilpd xmm1, xmm1, 0x00
000078d2e7dd2e70  vmovaps xmm11, [rsp+0xC0]
000078d2e7dd2e79  vmovaps [rsp+0xC0], xmm15
000078d2e7dd2e82  movaps xmm13, xmm11
000078d2e7dd2e86  mulpd xmm13, xmm1
000078d2e7dd2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
000078d2e7dd2e91  ptest xmm15, xmm15
000078d2e7dd2e97  jnz 0x000078D2E7DD55A0
000078d2e7dd2e9d  lea rax, [r14+0xC0]
000078d2e7dd2ea4  movups xmm1, [r13+rax*1]
000078d2e7dd2eaa  vmovaps xmm11, [rsp+0x100]
000078d2e7dd2eb3  vmovaps [rsp+0xF0], xmm1
000078d2e7dd2ebc  vmovaps xmm1, [rsp+0x20]
000078d2e7dd2ec2  vmovaps [rsp+0x20], xmm14
000078d2e7dd2ec8  movaps xmm15, xmm11
000078d2e7dd2ecc  addpd xmm15, xmm1
000078d2e7dd2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
000078d2e7dd2ed7  ptest xmm14, xmm14
000078d2e7dd2edd  jnz 0x000078D2E7DD56ED
000078d2e7dd2ee3  vmovaps [rsp+0x100], xmm9
000078d2e7dd2eec  vmovaps xmm1, [rsp+0x100]
000078d2e7dd2ef5  por xmm9, xmm1
000078d2e7dd2efa  movaps [r15+0x270], xmm9
000078d2e7dd2f02  vmovaps [rsp+0x100], xmm6
000078d2e7dd2f0b  vmovaps xmm1, [rsp+0x100]
000078d2e7dd2f14  por xmm6, xmm1
000078d2e7dd2f18  movaps [r15+0x1A0], xmm6
000078d2e7dd2f20  vmovaps xmm14, [rsp+0xB0]
000078d2e7dd2f29  vpermilpd xmm14, xmm14, 0x00
000078d2e7dd2f2f  vmovaps xmm6, [rsp+0xF0]
000078d2e7dd2f38  vmovaps [rsp+0xF0], xmm1
000078d2e7dd2f41  movaps xmm11, xmm6
000078d2e7dd2f45  mulpd xmm11, xmm14
000078d2e7dd2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
000078d2e7dd2f50  ptest xmm1, xmm1
000078d2e7dd2f55  jnz 0x000078D2E7DD5830
000078d2e7dd2f5b  lea rax, [r14+0x20]
000078d2e7dd2f5f  movups xmm1, [r13+rax*1]
000078d2e7dd2f65  movaps [r15+0x110], xmm1
000078d2e7dd2f6d  vmovaps xmm6, [rsp+0xE0]
000078d2e7dd2f76  vmovaps [rsp+0xE0], xmm1
000078d2e7dd2f7f  movaps xmm14, xmm6
000078d2e7dd2f83  addpd xmm14, xmm2
000078d2e7dd2f88  vcmppd xmm1, xmm14, xmm14, 0x03
000078d2e7dd2f8e  ptest xmm1, xmm1
000078d2e7dd2f93  jnz 0x000078D2E7DD597D
000078d2e7dd2f99  vmovaps xmm1, [rsp+0xB0]
000078d2e7dd2fa2  vpermilpd xmm1, xmm1, 0x00
000078d2e7dd2fa8  movaps xmm6, xmm5
000078d2e7dd2fab  mulpd xmm6, xmm1
000078d2e7dd2faf  vcmppd xmm2, xmm6, xmm6, 0x03
000078d2e7dd2fb4  ptest xmm2, xmm2
000078d2e7dd2fb9  jnz 0x000078D2E7DD5ABF
000078d2e7dd2fbf  vmovaps xmm5, [rsp+0x10]
000078d2e7dd2fc5  movaps xmm1, xmm5
000078d2e7dd2fc8  addpd xmm1, xmm13
000078d2e7dd2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
000078d2e7dd2fd2  ptest xmm2, xmm2
000078d2e7dd2fd7  jnz 0x000078D2E7DD5BFF
000078d2e7dd2fdd  vmovaps xmm13, [rsp+0x80]
000078d2e7dd2fe6  vpermilpd xmm13, xmm13, 0x00
000078d2e7dd2fec  vmovaps xmm2, [rsp+0xE0]
000078d2e7dd2ff5  vmovaps [rsp+0x10], xmm1
000078d2e7dd2ffb  movaps xmm5, xmm2
000078d2e7dd2ffe  mulpd xmm5, xmm13
000078d2e7dd3003  vcmppd xmm1, xmm5, xmm5, 0x03
000078d2e7dd3008  ptest xmm1, xmm1
000078d2e7dd300d  jnz 0x000078D2E7DD5D40
000078d2e7dd3013  vmovaps xmm1, [rsp+0x80]
000078d2e7dd301c  vpermilpd xmm1, xmm1, 0x00
000078d2e7dd3022  movaps xmm13, xmm10
000078d2e7dd3026  mulpd xmm13, xmm1
000078d2e7dd302b  vcmppd xmm2, xmm13, xmm13, 0x03
000078d2e7dd3031  ptest xmm2, xmm2
000078d2e7dd3036  jnz 0x000078D2E7DD5E81
000078d2e7dd303c  vmovaps xmm10, [rsp+0x20]
000078d2e7dd3042  movaps xmm1, xmm15
000078d2e7dd3046  addpd xmm1, xmm10
000078d2e7dd304b  vcmppd xmm2, xmm1, xmm1, 0x03
000078d2e7dd3050  ptest xmm2, xmm2
000078d2e7dd3055  jnz 0x000078D2E7DD5FC4
000078d2e7dd305b  vmovaps xmm10, [rsp+0xC0]
000078d2e7dd3064  movaps xmm15, xmm10
000078d2e7dd3068  addpd xmm15, xmm11
000078d2e7dd306d  vcmppd xmm2, xmm15, xmm15, 0x03
000078d2e7dd3073  ptest xmm2, xmm2
000078d2e7dd3078  jnz 0x000078D2E7DD6106
000078d2e7dd307e  vmovaps xmm11, [rsp+0x80]
000078d2e7dd3087  vpermilpd xmm11, xmm11, 0x00
000078d2e7dd308d  vmovaps xmm2, [rsp+0xD0]
000078d2e7dd3096  vmovaps [rsp+0x20], xmm1
000078d2e7dd309c  movaps xmm10, xmm2
000078d2e7dd30a0  mulpd xmm10, xmm11
000078d2e7dd30a5  vcmppd xmm1, xmm10, xmm10, 0x03
000078d2e7dd30ab  ptest xmm1, xmm1
000078d2e7dd30b0  jnz 0x000078D2E7DD624A
000078d2e7dd30b6  vmovaps xmm1, [rsp+0x80]
000078d2e7dd30bf  vpermilpd xmm1, xmm1, 0x00
000078d2e7dd30c5  vmovaps xmm2, [rsp+0xA0]
000078d2e7dd30ce  vmovaps [rsp+0x80], xmm15
000078d2e7dd30d7  movaps xmm11, xmm2
000078d2e7dd30db  mulpd xmm11, xmm1
000078d2e7dd30e0  vcmppd xmm15, xmm11, xmm11, 0x03
000078d2e7dd30e6  ptest xmm15, xmm15
000078d2e7dd30ec  jnz 0x000078D2E7DD638D
000078d2e7dd30f2  movaps xmm1, xmm14
000078d2e7dd30f6  addpd xmm1, xmm6
000078d2e7dd30fa  vcmppd xmm15, xmm1, xmm1, 0x03
000078d2e7dd30ff  ptest xmm15, xmm15
000078d2e7dd3105  jnz 0x000078D2E7DD64CF
000078d2e7dd310b  vmovaps xmm14, [rsp+0x10]
000078d2e7dd3111  movaps xmm15, xmm14
000078d2e7dd3115  addpd xmm15, xmm5
000078d2e7dd311a  vcmppd xmm6, xmm15, xmm15, 0x03
000078d2e7dd3120  ptest xmm6, xmm6
000078d2e7dd3125  jnz 0x000078D2E7DD6610
000078d2e7dd312b  vmovaps xmm14, [rsp+0x90]
000078d2e7dd3134  vpermilpd xmm14, xmm14, 0x00
000078d2e7dd313a  movaps xmm6, xmm9
000078d2e7dd313e  mulpd xmm6, xmm14
000078d2e7dd3143  vcmppd xmm5, xmm6, xmm6, 0x03
000078d2e7dd3148  ptest xmm5, xmm5
000078d2e7dd314d  jnz 0x000078D2E7DD6753
000078d2e7dd3153  vmovaps xmm9, [rsp+0x80]
000078d2e7dd315c  movaps xmm14, xmm9
000078d2e7dd3160  addpd xmm14, xmm13
000078d2e7dd3165  vcmppd xmm5, xmm14, xmm14, 0x03
000078d2e7dd316b  ptest xmm5, xmm5
000078d2e7dd3170  jnz 0x000078D2E7DD6895
000078d2e7dd3176  vmovaps xmm9, [rsp+0x20]
000078d2e7dd317c  movaps xmm13, xmm9
000078d2e7dd3180  addpd xmm13, xmm10
000078d2e7dd3185  vcmppd xmm5, xmm13, xmm13, 0x03
000078d2e7dd318b  ptest xmm5, xmm5
000078d2e7dd3190  jnz 0x000078D2E7DD69D9
000078d2e7dd3196  vmovaps [rsp+0x10], xmm12
000078d2e7dd319c  vmovaps xmm10, [rsp+0x10]
000078d2e7dd31a2  por xmm12, xmm10
000078d2e7dd31a7  movaps [r15+0x250], xmm12
000078d2e7dd31af  vmovaps [rsp+0x10], xmm7
000078d2e7dd31b5  vmovaps xmm12, [rsp+0x10]
000078d2e7dd31bb  por xmm7, xmm12
000078d2e7dd31c0  movaps [r15+0x2A0], xmm7
000078d2e7dd31c8  vmovaps [rsp+0x10], xmm3
000078d2e7dd31ce  vmovaps xmm12, [rsp+0x10]
000078d2e7dd31d4  por xmm3, xmm12
000078d2e7dd31d9  movaps [r15+0x1D0], xmm3
000078d2e7dd31e1  lea rax, [r14+0x40]
000078d2e7dd31e5  movups xmm12, [r13+rax*1]
000078d2e7dd31eb  movaps [r15+0x2C0], xmm12
000078d2e7dd31f3  vmovaps xmm10, [rsp+0x90]
000078d2e7dd31fc  vpermilpd xmm10, xmm10, 0x00
000078d2e7dd3202  movaps xmm9, xmm8
000078d2e7dd3206  mulpd xmm9, xmm10
000078d2e7dd320b  vcmppd xmm5, xmm9, xmm9, 0x03
000078d2e7dd3211  ptest xmm5, xmm5
000078d2e7dd3216  jnz 0x000078D2E7DD6B27
000078d2e7dd321c  movaps xmm10, xmm1
000078d2e7dd3220  addpd xmm10, xmm11
000078d2e7dd3225  vcmppd xmm8, xmm10, xmm10, 0x03
000078d2e7dd322b  ptest xmm8, xmm8
000078d2e7dd3231  jnz 0x000078D2E7DD6C6B
000078d2e7dd3237  movaps xmm1, xmm15
000078d2e7dd323b  addpd xmm1, xmm6
000078d2e7dd323f  vcmppd xmm11, xmm1, xmm1, 0x03
000078d2e7dd3244  ptest xmm11, xmm11
000078d2e7dd324a  jnz 0x000078D2E7DD6DAE
000078d2e7dd3250  vmovaps xmm15, [rsp+0x90]
000078d2e7dd3259  vpermilpd xmm15, xmm15, 0x00
000078d2e7dd325f  movaps xmm11, xmm12
000078d2e7dd3263  mulpd xmm11, xmm15
000078d2e7dd3268  vcmppd xmm8, xmm11, xmm11, 0x03
000078d2e7dd326e  ptest xmm8, xmm8
000078d2e7dd3274  jnz 0x000078D2E7DD6EEF
000078d2e7dd327a  vmovaps xmm15, [rsp+0x90]
000078d2e7dd3283  vpermilpd xmm15, xmm15, 0x00
000078d2e7dd3289  vmovaps xmm8, [rsp+0x50]
000078d2e7dd328f  movaps xmm12, xmm8
000078d2e7dd3293  mulpd xmm12, xmm15
000078d2e7dd3298  vcmppd xmm6, xmm12, xmm12, 0x03
000078d2e7dd329e  ptest xmm6, xmm6
000078d2e7dd32a3  jnz 0x000078D2E7DD7033
000078d2e7dd32a9  vmovaps xmm15, [rsp+0x30]
000078d2e7dd32af  vpermilpd xmm15, xmm15, 0x00
000078d2e7dd32b5  movaps xmm8, xmm7
000078d2e7dd32b9  mulpd xmm8, xmm15
000078d2e7dd32be  vcmppd xmm6, xmm8, xmm8, 0x03
000078d2e7dd32c4  ptest xmm6, xmm6
000078d2e7dd32c9  jnz 0x000078D2E7DD7177
000078d2e7dd32cf  movaps xmm15, xmm14
000078d2e7dd32d3  addpd xmm15, xmm9
000078d2e7dd32d8  vcmppd xmm7, xmm15, xmm15, 0x03
000078d2e7dd32de  ptest xmm7, xmm7
000078d2e7dd32e3  jnz 0x000078D2E7DD72BA
000078d2e7dd32e9  vmovaps xmm14, [rsp+0x30]
000078d2e7dd32ef  vpermilpd xmm14, xmm14, 0x00
000078d2e7dd32f5  vmovaps xmm7, [rsp+0xF0]
000078d2e7dd32fe  movaps xmm9, xmm7
000078d2e7dd3302  mulpd xmm9, xmm14
000078d2e7dd3307  vcmppd xmm6, xmm9, xmm9, 0x03
000078d2e7dd330d  ptest xmm6, xmm6
000078d2e7dd3312  jnz 0x000078D2E7DD73FE
000078d2e7dd3318  movaps xmm14, xmm13
000078d2e7dd331c  addpd xmm14, xmm11
000078d2e7dd3321  vcmppd xmm7, xmm14, xmm14, 0x03
000078d2e7dd3327  ptest xmm7, xmm7
000078d2e7dd332c  jnz 0x000078D2E7DD7541
000078d2e7dd3332  vmovaps xmm13, [rsp+0x30]
000078d2e7dd3338  vpermilpd xmm13, xmm13, 0x00
000078d2e7dd333e  vmovaps xmm7, [rsp+0x60]
000078d2e7dd3344  movaps xmm11, xmm7
000078d2e7dd3348  mulpd xmm11, xmm13
000078d2e7dd334d  vcmppd xmm6, xmm11, xmm11, 0x03
000078d2e7dd3353  ptest xmm6, xmm6
000078d2e7dd3358  jnz 0x000078D2E7DD7685
000078d2e7dd335e  movaps xmm13, xmm10
000078d2e7dd3362  addpd xmm13, xmm12
000078d2e7dd3367  vcmppd xmm7, xmm13, xmm13, 0x03
000078d2e7dd336d  ptest xmm7, xmm7
000078d2e7dd3372  jnz 0x000078D2E7DD77C8
000078d2e7dd3378  vmovaps xmm12, [rsp+0x30]
000078d2e7dd337e  vpermilpd xmm12, xmm12, 0x00
000078d2e7dd3384  vmovaps xmm7, [rsp+0x70]
000078d2e7dd338a  movaps xmm10, xmm7
000078d2e7dd338e  mulpd xmm10, xmm12
000078d2e7dd3393  vcmppd xmm6, xmm10, xmm10, 0x03
000078d2e7dd3399  ptest xmm6, xmm6
000078d2e7dd339e  jnz 0x000078D2E7DD790C
000078d2e7dd33a4  movaps xmm12, xmm1
000078d2e7dd33a8  addpd xmm12, xmm8
000078d2e7dd33ad  vcmppd xmm7, xmm12, xmm12, 0x03
000078d2e7dd33b3  ptest xmm7, xmm7
000078d2e7dd33b8  jnz 0x000078D2E7DD7A4F
000078d2e7dd33be  lea rax, [r14+0x70]
000078d2e7dd33c2  movups xmm1, [r13+rax*1]
000078d2e7dd33c8  movaps [r15+0x240], xmm1
000078d2e7dd33d0  movaps xmm8, xmm15
000078d2e7dd33d4  addpd xmm8, xmm9
000078d2e7dd33d9  vcmppd xmm7, xmm8, xmm8, 0x03
000078d2e7dd33df  ptest xmm7, xmm7
000078d2e7dd33e4  jnz 0x000078D2E7DD7B9C
000078d2e7dd33ea  movaps [r15+0x170], xmm8
000078d2e7dd33f2  vmovaps xmm15, [rsp+0x40]
000078d2e7dd33f8  vpermilpd xmm15, xmm15, 0x00
000078d2e7dd33fe  movaps xmm9, xmm1
000078d2e7dd3402  mulpd xmm9, xmm15
000078d2e7dd3407  vcmppd xmm7, xmm9, xmm9, 0x03
000078d2e7dd340d  ptest xmm7, xmm7
000078d2e7dd3412  jnz 0x000078D2E7DD7CE0
000078d2e7dd3418  vmovaps xmm1, [rsp+0x40]
000078d2e7dd341e  vpermilpd xmm1, xmm1, 0x00
000078d2e7dd3424  movaps xmm15, xmm4
000078d2e7dd3428  mulpd xmm15, xmm1
000078d2e7dd342d  vcmppd xmm7, xmm15, xmm15, 0x03
000078d2e7dd3433  ptest xmm7, xmm7
000078d2e7dd3438  jnz 0x000078D2E7DD7E23
000078d2e7dd343e  movaps [r15+0x180], xmm15
000078d2e7dd3446  movaps xmm1, xmm14
000078d2e7dd344a  addpd xmm1, xmm11
000078d2e7dd344f  vcmppd xmm7, xmm1, xmm1, 0x03
000078d2e7dd3454  ptest xmm7, xmm7
000078d2e7dd3459  jnz 0x000078D2E7DD7F65
000078d2e7dd345f  movaps [r15+0x210], xmm1
000078d2e7dd3467  movups xmm14, [r13+r14*1]
000078d2e7dd346d  lea rax, [r14+0x10]
000078d2e7dd3471  movups xmm11, [r13+rax*1]
000078d2e7dd3477  movaps [r15+0x230], xmm11
000078d2e7dd347f  movaps xmm7, xmm13
000078d2e7dd3483  addpd xmm7, xmm10
000078d2e7dd3488  vcmppd xmm6, xmm7, xmm7, 0x03
000078d2e7dd348d  ptest xmm6, xmm6
000078d2e7dd3492  jnz 0x000078D2E7DD80BB
000078d2e7dd3498  movaps [r15+0x130], xmm7
000078d2e7dd34a0  vmovaps xmm13, [rsp+0x40]
000078d2e7dd34a6  vpermilpd xmm13, xmm13, 0x00
000078d2e7dd34ac  movaps xmm10, xmm11
000078d2e7dd34b0  mulpd xmm10, xmm13
000078d2e7dd34b5  vcmppd xmm6, xmm10, xmm10, 0x03
000078d2e7dd34bb  ptest xmm6, xmm6
000078d2e7dd34c0  jnz 0x000078D2E7DD81FD
000078d2e7dd34c6  movaps [r15+0x220], xmm10
000078d2e7dd34ce  vmovaps xmm13, [rsp+0x40]
000078d2e7dd34d4  vpermilpd xmm13, xmm13, 0x00
000078d2e7dd34da  movaps xmm11, xmm14
000078d2e7dd34de  mulpd xmm11, xmm13
000078d2e7dd34e3  vcmppd xmm6, xmm11, xmm11, 0x03
000078d2e7dd34e9  ptest xmm6, xmm6
000078d2e7dd34ee  jnz 0x000078D2E7DD8341
000078d2e7dd34f4  movaps xmm14, xmm12
000078d2e7dd34f8  addpd xmm14, xmm9
000078d2e7dd34fd  vcmppd xmm13, xmm14, xmm14, 0x03
000078d2e7dd3503  ptest xmm13, xmm13
000078d2e7dd3509  jnz 0x000078D2E7DD8485
000078d2e7dd350f  movaps [r15+0x140], xmm14
000078d2e7dd3517  movaps xmm13, xmm8
000078d2e7dd351b  addpd xmm13, xmm15
000078d2e7dd3520  vcmppd xmm12, xmm13, xmm13, 0x03
000078d2e7dd3526  ptest xmm12, xmm12
000078d2e7dd352c  jnz 0x000078D2E7DD85C9
000078d2e7dd3532  movaps [r15+0x150], xmm13
000078d2e7dd353a  movaps xmm15, xmm1
000078d2e7dd353e  addpd xmm15, xmm10
000078d2e7dd3543  vcmppd xmm12, xmm15, xmm15, 0x03
000078d2e7dd3549  ptest xmm12, xmm12
000078d2e7dd354f  jnz 0x000078D2E7DD870D
000078d2e7dd3555  movaps [r15+0x160], xmm15
000078d2e7dd355d  movaps xmm1, xmm7
000078d2e7dd3560  addpd xmm1, xmm11
000078d2e7dd3565  vcmppd xmm12, xmm1, xmm1, 0x03
000078d2e7dd356a  ptest xmm12, xmm12
000078d2e7dd3570  jnz 0x000078D2E7DD8850
000078d2e7dd3576  movaps [r15+0x120], xmm1
000078d2e7dd357e  mov eax, 0x432200
000078d2e7dd3583  movups [r13+rax*1], xmm14
000078d2e7dd3589  mov eax, 0x432210
000078d2e7dd358e  movups [r13+rax*1], xmm13
000078d2e7dd3594  mov eax, 0x432220
000078d2e7dd3599  movups [r13+rax*1], xmm15
000078d2e7dd359f  mov eax, 0x432230
000078d2e7dd35a4  movups [r13+rax*1], xmm1
000078d2e7dd35aa  mov eax, [r15+0x108]
000078d2e7dd35b1  sahf
000078d2e7dd35b2  jnz 0x000078D2E7DD35E4
000078d2e7dd35b4  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd35bc  jz 0x000078D2E7DDEAE0
000078d2e7dd35c2  nop [rax+rax*1], ax
000078d2e7dd35cb  nop [rax+rax*1], eax
000078d2e7dd35d3  mov eax, 0x4106D0
000078d2e7dd35d8  mov [r15+0x100], rax
000078d2e7dd35df  jmp 0x000078D2E7BFE110
000078d2e7dd35e4  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd35ec  jz 0x000078D2E7DD89C0
000078d2e7dd35f2  nop [rax+rax*1], ax
000078d2e7dd35fb  nop [rax+rax*1], eax
000078d2e7dd3603  mov eax, 0x410504
000078d2e7dd3608  mov [r15+0x100], rax
000078d2e7dd360f  jmp 0x000078D2E7BFE110
000078d2e7dd3614  int3
000078d2e7dd3615  call 0x000078D2E7CD64F0
000078d2e7dd361a  jmp 0x000078D2E7DD2311
000078d2e7dd361f  call 0x000078D2E7CE5820
000078d2e7dd3624  jmp 0x000078D2E7DD231E
000078d2e7dd3629  call 0x000078D2E7CE3320
000078d2e7dd362e  jmp 0x000078D2E7DD2332
000078d2e7dd3633  call 0x000078D2E7CE20A0
000078d2e7dd3638  jmp 0x000078D2E7DD233C
000078d2e7dd363d  call 0x000078D2E7C09D70
000078d2e7dd3642  jmp 0x000078D2E7DD234A
000078d2e7dd3647  call 0x000078D2E7CDFBC0
000078d2e7dd364c  jmp 0x000078D2E7DD2354
000078d2e7dd3651  call 0x000078D2E7CC4740
000078d2e7dd3656  jmp 0x000078D2E7DD2368
000078d2e7dd365b  call 0x000078D2E7CB5400
000078d2e7dd3660  jmp 0x000078D2E7DD2375
000078d2e7dd3665  call 0x000078D2E7CB52F0
000078d2e7dd366a  jmp 0x000078D2E7DD2382
000078d2e7dd366f  call 0x000078D2E7CC4620
000078d2e7dd3674  jmp 0x000078D2E7DD238F
000078d2e7dd3679  call 0x000078D2E7CBD750
000078d2e7dd367e  jmp 0x000078D2E7DD239C
000078d2e7dd3683  call 0x000078D2E7CBC4E0
000078d2e7dd3688  jmp 0x000078D2E7DD23A9
000078d2e7dd368d  call 0x000078D2E7CBB270
000078d2e7dd3692  jmp 0x000078D2E7DD23B6
000078d2e7dd3697  call 0x000078D2E7CBA000
000078d2e7dd369c  jmp 0x000078D2E7DD23C3
000078d2e7dd36a1  call 0x000078D2E7CC4740
000078d2e7dd36a6  jmp 0x000078D2E7DD23D0
000078d2e7dd36ab  call 0x000078D2E7CB5400
000078d2e7dd36b0  jmp 0x000078D2E7DD23DD
000078d2e7dd36b5  call 0x000078D2E7CB52F0
000078d2e7dd36ba  jmp 0x000078D2E7DD23EA
000078d2e7dd36bf  call 0x000078D2E7CC4620
000078d2e7dd36c4  jmp 0x000078D2E7DD23F7
000078d2e7dd36c9  call 0x000078D2E7CB8D90
000078d2e7dd36ce  jmp 0x000078D2E7DD2404
000078d2e7dd36d3  call 0x000078D2E7CB8A20
000078d2e7dd36d8  jmp 0x000078D2E7DD2411
000078d2e7dd36dd  call 0x000078D2E7CB77B0
000078d2e7dd36e2  jmp 0x000078D2E7DD241B
000078d2e7dd36e7  call 0x000078D2E7CB6550
000078d2e7dd36ec  jmp 0x000078D2E7DD2425
000078d2e7dd36f1  call 0x000078D2E7CB5400
000078d2e7dd36f6  jmp 0x000078D2E7DD2437
000078d2e7dd36fb  call 0x000078D2E7CC0FC0
000078d2e7dd3700  jmp 0x000078D2E7DD2441
000078d2e7dd3705  call 0x000078D2E7CB52F0
000078d2e7dd370a  jmp 0x000078D2E7DD244B
000078d2e7dd370f  call 0x000078D2E7CC0EA0
000078d2e7dd3714  jmp 0x000078D2E7DD2455
000078d2e7dd3719  call 0x000078D2E7CBFD50
000078d2e7dd371e  jmp 0x000078D2E7DD245F
000078d2e7dd3723  call 0x000078D2E7CB8EA0
000078d2e7dd3728  jmp 0x000078D2E7DD2469
000078d2e7dd372d  call 0x000078D2E7CBFC30
000078d2e7dd3732  jmp 0x000078D2E7DD2476
000078d2e7dd3737  call 0x000078D2E7CB8D90
000078d2e7dd373c  jmp 0x000078D2E7DD2483
000078d2e7dd3741  call 0x000078D2E7CB52F0
000078d2e7dd3746  jmp 0x000078D2E7DD2496
000078d2e7dd374b  call 0x000078D2E7CB52F0
000078d2e7dd3750  jmp 0x000078D2E7DD24A9
000078d2e7dd3755  call 0x000078D2E7CC0FC0
000078d2e7dd375a  jmp 0x000078D2E7DD24B6
000078d2e7dd375f  call 0x000078D2E7CC0FC0
000078d2e7dd3764  jmp 0x000078D2E7DD24C9
000078d2e7dd3769  call 0x000078D2E7CC0EA0
000078d2e7dd376e  jmp 0x000078D2E7DD24D6
000078d2e7dd3773  call 0x000078D2E7CB52F0
000078d2e7dd3778  jmp 0x000078D2E7DD24E9
000078d2e7dd377d  call 0x000078D2E7CB52F0
000078d2e7dd3782  jmp 0x000078D2E7DD24FC
000078d2e7dd3787  call 0x000078D2E7CB52F0
000078d2e7dd378c  jmp 0x000078D2E7DD250F
000078d2e7dd3791  call 0x000078D2E7CB52F0
000078d2e7dd3796  jmp 0x000078D2E7DD252A
000078d2e7dd379b  call 0x000078D2E7CB52F0
000078d2e7dd37a0  jmp 0x000078D2E7DD253D
000078d2e7dd37a5  call 0x000078D2E7CB5400
000078d2e7dd37aa  jmp 0x000078D2E7DD257E
000078d2e7dd37af  call 0x000078D2E7CC0FC0
000078d2e7dd37b4  jmp 0x000078D2E7DD258B
000078d2e7dd37b9  call 0x000078D2E7CB52F0
000078d2e7dd37be  jmp 0x000078D2E7DD2598
000078d2e7dd37c3  call 0x000078D2E7CC0EA0
000078d2e7dd37c8  jmp 0x000078D2E7DD25A5
000078d2e7dd37cd  call 0x000078D2E7BFF540
000078d2e7dd37d2  jmp 0x000078D2E7DD25C3
000078d2e7dd37d7  call 0x000078D2E7C08C20
000078d2e7dd37dc  jmp 0x000078D2E7DD25CD
000078d2e7dd37e1  call 0x000078D2E7CE21C0
000078d2e7dd37e6  jmp 0x000078D2E7DD25D3
000078d2e7dd37eb  call 0x000078D2E7BFF540
000078d2e7dd37f0  jmp 0x000078D2E7DD25E3
000078d2e7dd37f5  call 0x000078D2E7CC0370
000078d2e7dd37fa  jmp 0x000078D2E7DD2611
000078d2e7dd37ff  call 0x000078D2E7CBF100
000078d2e7dd3804  jmp 0x000078D2E7DD261A
000078d2e7dd3809  call 0x000078D2E7CC0370
000078d2e7dd380e  jmp 0x000078D2E7DD2674
000078d2e7dd3813  call 0x000078D2E7CBF100
000078d2e7dd3818  jmp 0x000078D2E7DD267D
000078d2e7dd381d  call 0x000078D2E7CC0370
000078d2e7dd3822  jmp 0x000078D2E7DD26C6
000078d2e7dd3827  call 0x000078D2E7CBF100
000078d2e7dd382c  jmp 0x000078D2E7DD26CF
000078d2e7dd3831  call 0x000078D2E7C0B720
000078d2e7dd3836  jmp 0x000078D2E7DD2714
000078d2e7dd383b  call 0x000078D2E7CB47C0
000078d2e7dd3840  jmp 0x000078D2E7DD2727
000078d2e7dd3845  call 0x000078D2E7C08B00
000078d2e7dd384a  jmp 0x000078D2E7DD273E
000078d2e7dd384f  call 0x000078D2E7BFF430
000078d2e7dd3854  jmp 0x000078D2E7DD2751
000078d2e7dd3859  call 0x000078D2E7BFF430
000078d2e7dd385e  jmp 0x000078D2E7DD2764
000078d2e7dd3863  sub rsp, 0x08
000078d2e7dd3867  push rax
000078d2e7dd3868  push rcx
000078d2e7dd3869  push rdx
000078d2e7dd386a  push rdi
000078d2e7dd386b  push rsi
000078d2e7dd386c  push r8
000078d2e7dd386e  push r9
000078d2e7dd3870  push r10
000078d2e7dd3872  push r11
000078d2e7dd3874  sub rsp, 0xF0
000078d2e7dd387b  vmovaps [rsp], xmm0
000078d2e7dd3880  vmovaps [rsp+0x10], xmm2
000078d2e7dd3886  vmovaps [rsp+0x20], xmm3
000078d2e7dd388c  vmovaps [rsp+0x30], xmm4
000078d2e7dd3892  vmovaps [rsp+0x40], xmm5
000078d2e7dd3898  vmovaps [rsp+0x50], xmm6
000078d2e7dd389e  vmovaps [rsp+0x60], xmm7
000078d2e7dd38a4  vmovaps [rsp+0x70], xmm8
000078d2e7dd38aa  vmovaps [rsp+0x80], xmm9
000078d2e7dd38b3  vmovaps [rsp+0x90], xmm10
000078d2e7dd38bc  vmovaps [rsp+0xA0], xmm11
000078d2e7dd38c5  vmovaps [rsp+0xB0], xmm12
000078d2e7dd38ce  vmovaps [rsp+0xC0], xmm13
000078d2e7dd38d7  vmovaps [rsp+0xD0], xmm14
000078d2e7dd38e0  vmovaps [rsp+0xE0], xmm15
000078d2e7dd38e9  sub rsp, 0x30
000078d2e7dd38ed  movaps [rsp], xmm1
000078d2e7dd38f1  movaps [rsp+0x10], xmm12
000078d2e7dd38f7  movaps [rsp+0x20], xmm15
000078d2e7dd38fd  lea rdi, [rsp]
000078d2e7dd3901  mov esi, 0x00
000078d2e7dd3906  mov rax, 0x5997D2DB1530
000078d2e7dd3910  call rax
000078d2e7dd3912  movaps xmm1, [rsp]
000078d2e7dd3916  add rsp, 0x30
000078d2e7dd391a  vmovaps xmm0, [rsp]
000078d2e7dd391f  vmovaps xmm2, [rsp+0x10]
000078d2e7dd3925  vmovaps xmm3, [rsp+0x20]
000078d2e7dd392b  vmovaps xmm4, [rsp+0x30]
000078d2e7dd3931  vmovaps xmm5, [rsp+0x40]
000078d2e7dd3937  vmovaps xmm6, [rsp+0x50]
000078d2e7dd393d  vmovaps xmm7, [rsp+0x60]
000078d2e7dd3943  vmovaps xmm8, [rsp+0x70]
000078d2e7dd3949  vmovaps xmm9, [rsp+0x80]
000078d2e7dd3952  vmovaps xmm10, [rsp+0x90]
000078d2e7dd395b  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd3964  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd396d  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd3976  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd397f  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd3988  add rsp, 0xF0
000078d2e7dd398f  pop r11
000078d2e7dd3991  pop r10
000078d2e7dd3993  pop r9
000078d2e7dd3995  pop r8
000078d2e7dd3997  pop rsi
000078d2e7dd3998  pop rdi
000078d2e7dd3999  pop rdx
000078d2e7dd399a  pop rcx
000078d2e7dd399b  pop rax
000078d2e7dd399c  add rsp, 0x08
000078d2e7dd39a0  jmp 0x000078D2E7DD27B2
000078d2e7dd39a5  sub rsp, 0x08
000078d2e7dd39a9  push rax
000078d2e7dd39aa  push rcx
000078d2e7dd39ab  push rdx
000078d2e7dd39ac  push rdi
000078d2e7dd39ad  push rsi
000078d2e7dd39ae  push r8
000078d2e7dd39b0  push r9
000078d2e7dd39b2  push r10
000078d2e7dd39b4  push r11
000078d2e7dd39b6  sub rsp, 0xF0
000078d2e7dd39bd  vmovaps [rsp], xmm0
000078d2e7dd39c2  vmovaps [rsp+0x10], xmm1
000078d2e7dd39c8  vmovaps [rsp+0x20], xmm2
000078d2e7dd39ce  vmovaps [rsp+0x30], xmm3
000078d2e7dd39d4  vmovaps [rsp+0x40], xmm4
000078d2e7dd39da  vmovaps [rsp+0x50], xmm5
000078d2e7dd39e0  vmovaps [rsp+0x60], xmm6
000078d2e7dd39e6  vmovaps [rsp+0x70], xmm7
000078d2e7dd39ec  vmovaps [rsp+0x80], xmm8
000078d2e7dd39f5  vmovaps [rsp+0x90], xmm9
000078d2e7dd39fe  vmovaps [rsp+0xA0], xmm10
000078d2e7dd3a07  vmovaps [rsp+0xB0], xmm11
000078d2e7dd3a10  vmovaps [rsp+0xC0], xmm12
000078d2e7dd3a19  vmovaps [rsp+0xD0], xmm13
000078d2e7dd3a22  vmovaps [rsp+0xE0], xmm15
000078d2e7dd3a2b  sub rsp, 0x30
000078d2e7dd3a2f  movaps [rsp], xmm14
000078d2e7dd3a34  movaps [rsp+0x10], xmm1
000078d2e7dd3a39  movaps [rsp+0x20], xmm15
000078d2e7dd3a3f  lea rdi, [rsp]
000078d2e7dd3a43  mov esi, 0x00
000078d2e7dd3a48  mov rax, 0x5997D2DB1530
000078d2e7dd3a52  call rax
000078d2e7dd3a54  movaps xmm14, [rsp]
000078d2e7dd3a59  add rsp, 0x30
000078d2e7dd3a5d  vmovaps xmm0, [rsp]
000078d2e7dd3a62  vmovaps xmm1, [rsp+0x10]
000078d2e7dd3a68  vmovaps xmm2, [rsp+0x20]
000078d2e7dd3a6e  vmovaps xmm3, [rsp+0x30]
000078d2e7dd3a74  vmovaps xmm4, [rsp+0x40]
000078d2e7dd3a7a  vmovaps xmm5, [rsp+0x50]
000078d2e7dd3a80  vmovaps xmm6, [rsp+0x60]
000078d2e7dd3a86  vmovaps xmm7, [rsp+0x70]
000078d2e7dd3a8c  vmovaps xmm8, [rsp+0x80]
000078d2e7dd3a95  vmovaps xmm9, [rsp+0x90]
000078d2e7dd3a9e  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd3aa7  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd3ab0  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd3ab9  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd3ac2  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd3acb  add rsp, 0xF0
000078d2e7dd3ad2  pop r11
000078d2e7dd3ad4  pop r10
000078d2e7dd3ad6  pop r9
000078d2e7dd3ad8  pop r8
000078d2e7dd3ada  pop rsi
000078d2e7dd3adb  pop rdi
000078d2e7dd3adc  pop rdx
000078d2e7dd3add  pop rcx
000078d2e7dd3ade  pop rax
000078d2e7dd3adf  add rsp, 0x08
000078d2e7dd3ae3  jmp 0x000078D2E7DD2800
000078d2e7dd3ae8  sub rsp, 0x08
000078d2e7dd3aec  push rax
000078d2e7dd3aed  push rcx
000078d2e7dd3aee  push rdx
000078d2e7dd3aef  push rdi
000078d2e7dd3af0  push rsi
000078d2e7dd3af1  push r8
000078d2e7dd3af3  push r9
000078d2e7dd3af5  push r10
000078d2e7dd3af7  push r11
000078d2e7dd3af9  sub rsp, 0xF0
000078d2e7dd3b00  vmovaps [rsp], xmm0
000078d2e7dd3b05  vmovaps [rsp+0x10], xmm1
000078d2e7dd3b0b  vmovaps [rsp+0x20], xmm2
000078d2e7dd3b11  vmovaps [rsp+0x30], xmm3
000078d2e7dd3b17  vmovaps [rsp+0x40], xmm4
000078d2e7dd3b1d  vmovaps [rsp+0x50], xmm5
000078d2e7dd3b23  vmovaps [rsp+0x60], xmm6
000078d2e7dd3b29  vmovaps [rsp+0x70], xmm7
000078d2e7dd3b2f  vmovaps [rsp+0x80], xmm8
000078d2e7dd3b38  vmovaps [rsp+0x90], xmm9
000078d2e7dd3b41  vmovaps [rsp+0xA0], xmm10
000078d2e7dd3b4a  vmovaps [rsp+0xB0], xmm11
000078d2e7dd3b53  vmovaps [rsp+0xC0], xmm12
000078d2e7dd3b5c  vmovaps [rsp+0xD0], xmm13
000078d2e7dd3b65  vmovaps [rsp+0xE0], xmm14
000078d2e7dd3b6e  sub rsp, 0x30
000078d2e7dd3b72  movaps [rsp], xmm15
000078d2e7dd3b77  movaps [rsp+0x10], xmm12
000078d2e7dd3b7d  movaps [rsp+0x20], xmm13
000078d2e7dd3b83  lea rdi, [rsp]
000078d2e7dd3b87  mov esi, 0x00
000078d2e7dd3b8c  mov rax, 0x5997D2DB1530
000078d2e7dd3b96  call rax
000078d2e7dd3b98  movaps xmm15, [rsp]
000078d2e7dd3b9d  add rsp, 0x30
000078d2e7dd3ba1  vmovaps xmm0, [rsp]
000078d2e7dd3ba6  vmovaps xmm1, [rsp+0x10]
000078d2e7dd3bac  vmovaps xmm2, [rsp+0x20]
000078d2e7dd3bb2  vmovaps xmm3, [rsp+0x30]
000078d2e7dd3bb8  vmovaps xmm4, [rsp+0x40]
000078d2e7dd3bbe  vmovaps xmm5, [rsp+0x50]
000078d2e7dd3bc4  vmovaps xmm6, [rsp+0x60]
000078d2e7dd3bca  vmovaps xmm7, [rsp+0x70]
000078d2e7dd3bd0  vmovaps xmm8, [rsp+0x80]
000078d2e7dd3bd9  vmovaps xmm9, [rsp+0x90]
000078d2e7dd3be2  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd3beb  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd3bf4  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd3bfd  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd3c06  vmovaps xmm14, [rsp+0xE0]
000078d2e7dd3c0f  add rsp, 0xF0
000078d2e7dd3c16  pop r11
000078d2e7dd3c18  pop r10
000078d2e7dd3c1a  pop r9
000078d2e7dd3c1c  pop r8
000078d2e7dd3c1e  pop rsi
000078d2e7dd3c1f  pop rdi
000078d2e7dd3c20  pop rdx
000078d2e7dd3c21  pop rcx
000078d2e7dd3c22  pop rax
000078d2e7dd3c23  add rsp, 0x08
000078d2e7dd3c27  jmp 0x000078D2E7DD2835
000078d2e7dd3c2c  sub rsp, 0x08
000078d2e7dd3c30  push rax
000078d2e7dd3c31  push rcx
000078d2e7dd3c32  push rdx
000078d2e7dd3c33  push rdi
000078d2e7dd3c34  push rsi
000078d2e7dd3c35  push r8
000078d2e7dd3c37  push r9
000078d2e7dd3c39  push r10
000078d2e7dd3c3b  push r11
000078d2e7dd3c3d  sub rsp, 0xF0
000078d2e7dd3c44  vmovaps [rsp], xmm0
000078d2e7dd3c49  vmovaps [rsp+0x10], xmm2
000078d2e7dd3c4f  vmovaps [rsp+0x20], xmm3
000078d2e7dd3c55  vmovaps [rsp+0x30], xmm4
000078d2e7dd3c5b  vmovaps [rsp+0x40], xmm5
000078d2e7dd3c61  vmovaps [rsp+0x50], xmm6
000078d2e7dd3c67  vmovaps [rsp+0x60], xmm7
000078d2e7dd3c6d  vmovaps [rsp+0x70], xmm8
000078d2e7dd3c73  vmovaps [rsp+0x80], xmm9
000078d2e7dd3c7c  vmovaps [rsp+0x90], xmm10
000078d2e7dd3c85  vmovaps [rsp+0xA0], xmm11
000078d2e7dd3c8e  vmovaps [rsp+0xB0], xmm12
000078d2e7dd3c97  vmovaps [rsp+0xC0], xmm13
000078d2e7dd3ca0  vmovaps [rsp+0xD0], xmm14
000078d2e7dd3ca9  vmovaps [rsp+0xE0], xmm15
000078d2e7dd3cb2  sub rsp, 0x30
000078d2e7dd3cb6  movaps [rsp], xmm1
000078d2e7dd3cba  movaps [rsp+0x10], xmm12
000078d2e7dd3cc0  movaps [rsp+0x20], xmm10
000078d2e7dd3cc6  lea rdi, [rsp]
000078d2e7dd3cca  mov esi, 0x00
000078d2e7dd3ccf  mov rax, 0x5997D2DB1530
000078d2e7dd3cd9  call rax
000078d2e7dd3cdb  movaps xmm1, [rsp]
000078d2e7dd3cdf  add rsp, 0x30
000078d2e7dd3ce3  vmovaps xmm0, [rsp]
000078d2e7dd3ce8  vmovaps xmm2, [rsp+0x10]
000078d2e7dd3cee  vmovaps xmm3, [rsp+0x20]
000078d2e7dd3cf4  vmovaps xmm4, [rsp+0x30]
000078d2e7dd3cfa  vmovaps xmm5, [rsp+0x40]
000078d2e7dd3d00  vmovaps xmm6, [rsp+0x50]
000078d2e7dd3d06  vmovaps xmm7, [rsp+0x60]
000078d2e7dd3d0c  vmovaps xmm8, [rsp+0x70]
000078d2e7dd3d12  vmovaps xmm9, [rsp+0x80]
000078d2e7dd3d1b  vmovaps xmm10, [rsp+0x90]
000078d2e7dd3d24  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd3d2d  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd3d36  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd3d3f  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd3d48  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd3d51  add rsp, 0xF0
000078d2e7dd3d58  pop r11
000078d2e7dd3d5a  pop r10
000078d2e7dd3d5c  pop r9
000078d2e7dd3d5e  pop r8
000078d2e7dd3d60  pop rsi
000078d2e7dd3d61  pop rdi
000078d2e7dd3d62  pop rdx
000078d2e7dd3d63  pop rcx
000078d2e7dd3d64  pop rax
000078d2e7dd3d65  add rsp, 0x08
000078d2e7dd3d69  jmp 0x000078D2E7DD284F
000078d2e7dd3d6e  sub rsp, 0x08
000078d2e7dd3d72  push rax
000078d2e7dd3d73  push rcx
000078d2e7dd3d74  push rdx
000078d2e7dd3d75  push rdi
000078d2e7dd3d76  push rsi
000078d2e7dd3d77  push r8
000078d2e7dd3d79  push r9
000078d2e7dd3d7b  push r10
000078d2e7dd3d7d  push r11
000078d2e7dd3d7f  sub rsp, 0xF0
000078d2e7dd3d86  vmovaps [rsp], xmm0
000078d2e7dd3d8b  vmovaps [rsp+0x10], xmm1
000078d2e7dd3d91  vmovaps [rsp+0x20], xmm2
000078d2e7dd3d97  vmovaps [rsp+0x30], xmm3
000078d2e7dd3d9d  vmovaps [rsp+0x40], xmm4
000078d2e7dd3da3  vmovaps [rsp+0x50], xmm5
000078d2e7dd3da9  vmovaps [rsp+0x60], xmm6
000078d2e7dd3daf  vmovaps [rsp+0x70], xmm7
000078d2e7dd3db5  vmovaps [rsp+0x80], xmm8
000078d2e7dd3dbe  vmovaps [rsp+0x90], xmm9
000078d2e7dd3dc7  vmovaps [rsp+0xA0], xmm10
000078d2e7dd3dd0  vmovaps [rsp+0xB0], xmm11
000078d2e7dd3dd9  vmovaps [rsp+0xC0], xmm12
000078d2e7dd3de2  vmovaps [rsp+0xD0], xmm14
000078d2e7dd3deb  vmovaps [rsp+0xE0], xmm15
000078d2e7dd3df4  sub rsp, 0x30
000078d2e7dd3df8  movaps [rsp], xmm13
000078d2e7dd3dfd  movaps [rsp+0x10], xmm12
000078d2e7dd3e03  movaps [rsp+0x20], xmm2
000078d2e7dd3e08  lea rdi, [rsp]
000078d2e7dd3e0c  mov esi, 0x00
000078d2e7dd3e11  mov rax, 0x5997D2DB1530
000078d2e7dd3e1b  call rax
000078d2e7dd3e1d  movaps xmm13, [rsp]
000078d2e7dd3e22  add rsp, 0x30
000078d2e7dd3e26  vmovaps xmm0, [rsp]
000078d2e7dd3e2b  vmovaps xmm1, [rsp+0x10]
000078d2e7dd3e31  vmovaps xmm2, [rsp+0x20]
000078d2e7dd3e37  vmovaps xmm3, [rsp+0x30]
000078d2e7dd3e3d  vmovaps xmm4, [rsp+0x40]
000078d2e7dd3e43  vmovaps xmm5, [rsp+0x50]
000078d2e7dd3e49  vmovaps xmm6, [rsp+0x60]
000078d2e7dd3e4f  vmovaps xmm7, [rsp+0x70]
000078d2e7dd3e55  vmovaps xmm8, [rsp+0x80]
000078d2e7dd3e5e  vmovaps xmm9, [rsp+0x90]
000078d2e7dd3e67  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd3e70  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd3e79  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd3e82  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd3e8b  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd3e94  add rsp, 0xF0
000078d2e7dd3e9b  pop r11
000078d2e7dd3e9d  pop r10
000078d2e7dd3e9f  pop r9
000078d2e7dd3ea1  pop r8
000078d2e7dd3ea3  pop rsi
000078d2e7dd3ea4  pop rdi
000078d2e7dd3ea5  pop rdx
000078d2e7dd3ea6  pop rcx
000078d2e7dd3ea7  pop rax
000078d2e7dd3ea8  add rsp, 0x08
000078d2e7dd3eac  jmp 0x000078D2E7DD286A
000078d2e7dd3eb1  sub rsp, 0x08
000078d2e7dd3eb5  push rax
000078d2e7dd3eb6  push rcx
000078d2e7dd3eb7  push rdx
000078d2e7dd3eb8  push rdi
000078d2e7dd3eb9  push rsi
000078d2e7dd3eba  push r8
000078d2e7dd3ebc  push r9
000078d2e7dd3ebe  push r10
000078d2e7dd3ec0  push r11
000078d2e7dd3ec2  sub rsp, 0xF0
000078d2e7dd3ec9  vmovaps [rsp], xmm0
000078d2e7dd3ece  vmovaps [rsp+0x10], xmm2
000078d2e7dd3ed4  vmovaps [rsp+0x20], xmm3
000078d2e7dd3eda  vmovaps [rsp+0x30], xmm4
000078d2e7dd3ee0  vmovaps [rsp+0x40], xmm5
000078d2e7dd3ee6  vmovaps [rsp+0x50], xmm6
000078d2e7dd3eec  vmovaps [rsp+0x60], xmm7
000078d2e7dd3ef2  vmovaps [rsp+0x70], xmm8
000078d2e7dd3ef8  vmovaps [rsp+0x80], xmm9
000078d2e7dd3f01  vmovaps [rsp+0x90], xmm10
000078d2e7dd3f0a  vmovaps [rsp+0xA0], xmm11
000078d2e7dd3f13  vmovaps [rsp+0xB0], xmm12
000078d2e7dd3f1c  vmovaps [rsp+0xC0], xmm13
000078d2e7dd3f25  vmovaps [rsp+0xD0], xmm14
000078d2e7dd3f2e  vmovaps [rsp+0xE0], xmm15
000078d2e7dd3f37  sub rsp, 0x30
000078d2e7dd3f3b  movaps [rsp], xmm1
000078d2e7dd3f3f  movaps [rsp+0x10], xmm10
000078d2e7dd3f45  movaps [rsp+0x20], xmm2
000078d2e7dd3f4a  lea rdi, [rsp]
000078d2e7dd3f4e  mov esi, 0x00
000078d2e7dd3f53  mov rax, 0x5997D2DB1530
000078d2e7dd3f5d  call rax
000078d2e7dd3f5f  movaps xmm1, [rsp]
000078d2e7dd3f63  add rsp, 0x30
000078d2e7dd3f67  vmovaps xmm0, [rsp]
000078d2e7dd3f6c  vmovaps xmm2, [rsp+0x10]
000078d2e7dd3f72  vmovaps xmm3, [rsp+0x20]
000078d2e7dd3f78  vmovaps xmm4, [rsp+0x30]
000078d2e7dd3f7e  vmovaps xmm5, [rsp+0x40]
000078d2e7dd3f84  vmovaps xmm6, [rsp+0x50]
000078d2e7dd3f8a  vmovaps xmm7, [rsp+0x60]
000078d2e7dd3f90  vmovaps xmm8, [rsp+0x70]
000078d2e7dd3f96  vmovaps xmm9, [rsp+0x80]
000078d2e7dd3f9f  vmovaps xmm10, [rsp+0x90]
000078d2e7dd3fa8  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd3fb1  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd3fba  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd3fc3  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd3fcc  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd3fd5  add rsp, 0xF0
000078d2e7dd3fdc  pop r11
000078d2e7dd3fde  pop r10
000078d2e7dd3fe0  pop r9
000078d2e7dd3fe2  pop r8
000078d2e7dd3fe4  pop rsi
000078d2e7dd3fe5  pop rdi
000078d2e7dd3fe6  pop rdx
000078d2e7dd3fe7  pop rcx
000078d2e7dd3fe8  pop rax
000078d2e7dd3fe9  add rsp, 0x08
000078d2e7dd3fed  jmp 0x000078D2E7DD28D2
000078d2e7dd3ff2  sub rsp, 0x08
000078d2e7dd3ff6  push rax
000078d2e7dd3ff7  push rcx
000078d2e7dd3ff8  push rdx
000078d2e7dd3ff9  push rdi
000078d2e7dd3ffa  push rsi
000078d2e7dd3ffb  push r8
000078d2e7dd3ffd  push r9
000078d2e7dd3fff  push r10
000078d2e7dd4001  push r11
000078d2e7dd4003  sub rsp, 0xF0
000078d2e7dd400a  vmovaps [rsp], xmm0
000078d2e7dd400f  vmovaps [rsp+0x10], xmm1
000078d2e7dd4015  vmovaps [rsp+0x20], xmm2
000078d2e7dd401b  vmovaps [rsp+0x30], xmm3
000078d2e7dd4021  vmovaps [rsp+0x40], xmm4
000078d2e7dd4027  vmovaps [rsp+0x50], xmm5
000078d2e7dd402d  vmovaps [rsp+0x60], xmm6
000078d2e7dd4033  vmovaps [rsp+0x70], xmm7
000078d2e7dd4039  vmovaps [rsp+0x80], xmm8
000078d2e7dd4042  vmovaps [rsp+0x90], xmm9
000078d2e7dd404b  vmovaps [rsp+0xA0], xmm10
000078d2e7dd4054  vmovaps [rsp+0xB0], xmm11
000078d2e7dd405d  vmovaps [rsp+0xC0], xmm12
000078d2e7dd4066  vmovaps [rsp+0xD0], xmm13
000078d2e7dd406f  vmovaps [rsp+0xE0], xmm14
000078d2e7dd4078  sub rsp, 0x30
000078d2e7dd407c  movaps [rsp], xmm15
000078d2e7dd4081  movaps [rsp+0x10], xmm10
000078d2e7dd4087  movaps [rsp+0x20], xmm2
000078d2e7dd408c  lea rdi, [rsp]
000078d2e7dd4090  mov esi, 0x00
000078d2e7dd4095  mov rax, 0x5997D2DB1530
000078d2e7dd409f  call rax
000078d2e7dd40a1  movaps xmm15, [rsp]
000078d2e7dd40a6  add rsp, 0x30
000078d2e7dd40aa  vmovaps xmm0, [rsp]
000078d2e7dd40af  vmovaps xmm1, [rsp+0x10]
000078d2e7dd40b5  vmovaps xmm2, [rsp+0x20]
000078d2e7dd40bb  vmovaps xmm3, [rsp+0x30]
000078d2e7dd40c1  vmovaps xmm4, [rsp+0x40]
000078d2e7dd40c7  vmovaps xmm5, [rsp+0x50]
000078d2e7dd40cd  vmovaps xmm6, [rsp+0x60]
000078d2e7dd40d3  vmovaps xmm7, [rsp+0x70]
000078d2e7dd40d9  vmovaps xmm8, [rsp+0x80]
000078d2e7dd40e2  vmovaps xmm9, [rsp+0x90]
000078d2e7dd40eb  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd40f4  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd40fd  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd4106  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd410f  vmovaps xmm14, [rsp+0xE0]
000078d2e7dd4118  add rsp, 0xF0
000078d2e7dd411f  pop r11
000078d2e7dd4121  pop r10
000078d2e7dd4123  pop r9
000078d2e7dd4125  pop r8
000078d2e7dd4127  pop rsi
000078d2e7dd4128  pop rdi
000078d2e7dd4129  pop rdx
000078d2e7dd412a  pop rcx
000078d2e7dd412b  pop rax
000078d2e7dd412c  add rsp, 0x08
000078d2e7dd4130  jmp 0x000078D2E7DD2924
000078d2e7dd4135  sub rsp, 0x08
000078d2e7dd4139  push rax
000078d2e7dd413a  push rcx
000078d2e7dd413b  push rdx
000078d2e7dd413c  push rdi
000078d2e7dd413d  push rsi
000078d2e7dd413e  push r8
000078d2e7dd4140  push r9
000078d2e7dd4142  push r10
000078d2e7dd4144  push r11
000078d2e7dd4146  sub rsp, 0xF0
000078d2e7dd414d  vmovaps [rsp], xmm0
000078d2e7dd4152  vmovaps [rsp+0x10], xmm2
000078d2e7dd4158  vmovaps [rsp+0x20], xmm3
000078d2e7dd415e  vmovaps [rsp+0x30], xmm4
000078d2e7dd4164  vmovaps [rsp+0x40], xmm5
000078d2e7dd416a  vmovaps [rsp+0x50], xmm6
000078d2e7dd4170  vmovaps [rsp+0x60], xmm7
000078d2e7dd4176  vmovaps [rsp+0x70], xmm8
000078d2e7dd417c  vmovaps [rsp+0x80], xmm9
000078d2e7dd4185  vmovaps [rsp+0x90], xmm10
000078d2e7dd418e  vmovaps [rsp+0xA0], xmm11
000078d2e7dd4197  vmovaps [rsp+0xB0], xmm12
000078d2e7dd41a0  vmovaps [rsp+0xC0], xmm13
000078d2e7dd41a9  vmovaps [rsp+0xD0], xmm14
000078d2e7dd41b2  vmovaps [rsp+0xE0], xmm15
000078d2e7dd41bb  sub rsp, 0x30
000078d2e7dd41bf  movaps [rsp], xmm1
000078d2e7dd41c3  movaps [rsp+0x10], xmm10
000078d2e7dd41c9  movaps [rsp+0x20], xmm15
000078d2e7dd41cf  lea rdi, [rsp]
000078d2e7dd41d3  mov esi, 0x00
000078d2e7dd41d8  mov rax, 0x5997D2DB1530
000078d2e7dd41e2  call rax
000078d2e7dd41e4  movaps xmm1, [rsp]
000078d2e7dd41e8  add rsp, 0x30
000078d2e7dd41ec  vmovaps xmm0, [rsp]
000078d2e7dd41f1  vmovaps xmm2, [rsp+0x10]
000078d2e7dd41f7  vmovaps xmm3, [rsp+0x20]
000078d2e7dd41fd  vmovaps xmm4, [rsp+0x30]
000078d2e7dd4203  vmovaps xmm5, [rsp+0x40]
000078d2e7dd4209  vmovaps xmm6, [rsp+0x50]
000078d2e7dd420f  vmovaps xmm7, [rsp+0x60]
000078d2e7dd4215  vmovaps xmm8, [rsp+0x70]
000078d2e7dd421b  vmovaps xmm9, [rsp+0x80]
000078d2e7dd4224  vmovaps xmm10, [rsp+0x90]
000078d2e7dd422d  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd4236  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd423f  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd4248  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd4251  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd425a  add rsp, 0xF0
000078d2e7dd4261  pop r11
000078d2e7dd4263  pop r10
000078d2e7dd4265  pop r9
000078d2e7dd4267  pop r8
000078d2e7dd4269  pop rsi
000078d2e7dd426a  pop rdi
000078d2e7dd426b  pop rdx
000078d2e7dd426c  pop rcx
000078d2e7dd426d  pop rax
000078d2e7dd426e  add rsp, 0x08
000078d2e7dd4272  jmp 0x000078D2E7DD2962
000078d2e7dd4277  sub rsp, 0x08
000078d2e7dd427b  push rax
000078d2e7dd427c  push rcx
000078d2e7dd427d  push rdx
000078d2e7dd427e  push rdi
000078d2e7dd427f  push rsi
000078d2e7dd4280  push r8
000078d2e7dd4282  push r9
000078d2e7dd4284  push r10
000078d2e7dd4286  push r11
000078d2e7dd4288  sub rsp, 0xF0
000078d2e7dd428f  vmovaps [rsp], xmm0
000078d2e7dd4294  vmovaps [rsp+0x10], xmm1
000078d2e7dd429a  vmovaps [rsp+0x20], xmm2
000078d2e7dd42a0  vmovaps [rsp+0x30], xmm3
000078d2e7dd42a6  vmovaps [rsp+0x40], xmm4
000078d2e7dd42ac  vmovaps [rsp+0x50], xmm5
000078d2e7dd42b2  vmovaps [rsp+0x60], xmm6
000078d2e7dd42b8  vmovaps [rsp+0x70], xmm7
000078d2e7dd42be  vmovaps [rsp+0x80], xmm8
000078d2e7dd42c7  vmovaps [rsp+0x90], xmm9
000078d2e7dd42d0  vmovaps [rsp+0xA0], xmm10
000078d2e7dd42d9  vmovaps [rsp+0xB0], xmm11
000078d2e7dd42e2  vmovaps [rsp+0xC0], xmm12
000078d2e7dd42eb  vmovaps [rsp+0xD0], xmm13
000078d2e7dd42f4  vmovaps [rsp+0xE0], xmm15
000078d2e7dd42fd  sub rsp, 0x30
000078d2e7dd4301  movaps [rsp], xmm14
000078d2e7dd4306  movaps [rsp+0x10], xmm10
000078d2e7dd430c  movaps [rsp+0x20], xmm15
000078d2e7dd4312  lea rdi, [rsp]
000078d2e7dd4316  mov esi, 0x00
000078d2e7dd431b  mov rax, 0x5997D2DB1530
000078d2e7dd4325  call rax
000078d2e7dd4327  movaps xmm14, [rsp]
000078d2e7dd432c  add rsp, 0x30
000078d2e7dd4330  vmovaps xmm0, [rsp]
000078d2e7dd4335  vmovaps xmm1, [rsp+0x10]
000078d2e7dd433b  vmovaps xmm2, [rsp+0x20]
000078d2e7dd4341  vmovaps xmm3, [rsp+0x30]
000078d2e7dd4347  vmovaps xmm4, [rsp+0x40]
000078d2e7dd434d  vmovaps xmm5, [rsp+0x50]
000078d2e7dd4353  vmovaps xmm6, [rsp+0x60]
000078d2e7dd4359  vmovaps xmm7, [rsp+0x70]
000078d2e7dd435f  vmovaps xmm8, [rsp+0x80]
000078d2e7dd4368  vmovaps xmm9, [rsp+0x90]
000078d2e7dd4371  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd437a  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd4383  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd438c  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd4395  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd439e  add rsp, 0xF0
000078d2e7dd43a5  pop r11
000078d2e7dd43a7  pop r10
000078d2e7dd43a9  pop r9
000078d2e7dd43ab  pop r8
000078d2e7dd43ad  pop rsi
000078d2e7dd43ae  pop rdi
000078d2e7dd43af  pop rdx
000078d2e7dd43b0  pop rcx
000078d2e7dd43b1  pop rax
000078d2e7dd43b2  add rsp, 0x08
000078d2e7dd43b6  jmp 0x000078D2E7DD298E
000078d2e7dd43bb  call 0x000078D2E7BFF430
000078d2e7dd43c0  jmp 0x000078D2E7DD2A1E
000078d2e7dd43c5  call 0x000078D2E7BFF430
000078d2e7dd43ca  jmp 0x000078D2E7DD2A31
000078d2e7dd43cf  sub rsp, 0x08
000078d2e7dd43d3  push rax
000078d2e7dd43d4  push rcx
000078d2e7dd43d5  push rdx
000078d2e7dd43d6  push rdi
000078d2e7dd43d7  push rsi
000078d2e7dd43d8  push r8
000078d2e7dd43da  push r9
000078d2e7dd43dc  push r10
000078d2e7dd43de  push r11
000078d2e7dd43e0  sub rsp, 0xF0
000078d2e7dd43e7  vmovaps [rsp], xmm0
000078d2e7dd43ec  vmovaps [rsp+0x10], xmm2
000078d2e7dd43f2  vmovaps [rsp+0x20], xmm3
000078d2e7dd43f8  vmovaps [rsp+0x30], xmm4
000078d2e7dd43fe  vmovaps [rsp+0x40], xmm5
000078d2e7dd4404  vmovaps [rsp+0x50], xmm6
000078d2e7dd440a  vmovaps [rsp+0x60], xmm7
000078d2e7dd4410  vmovaps [rsp+0x70], xmm8
000078d2e7dd4416  vmovaps [rsp+0x80], xmm9
000078d2e7dd441f  vmovaps [rsp+0x90], xmm10
000078d2e7dd4428  vmovaps [rsp+0xA0], xmm11
000078d2e7dd4431  vmovaps [rsp+0xB0], xmm12
000078d2e7dd443a  vmovaps [rsp+0xC0], xmm13
000078d2e7dd4443  vmovaps [rsp+0xD0], xmm14
000078d2e7dd444c  vmovaps [rsp+0xE0], xmm15
000078d2e7dd4455  sub rsp, 0x30
000078d2e7dd4459  movaps [rsp], xmm1
000078d2e7dd445d  movaps [rsp+0x10], xmm13
000078d2e7dd4463  movaps [rsp+0x20], xmm2
000078d2e7dd4468  lea rdi, [rsp]
000078d2e7dd446c  mov esi, 0x00
000078d2e7dd4471  mov rax, 0x5997D2DB1530
000078d2e7dd447b  call rax
000078d2e7dd447d  movaps xmm1, [rsp]
000078d2e7dd4481  add rsp, 0x30
000078d2e7dd4485  vmovaps xmm0, [rsp]
000078d2e7dd448a  vmovaps xmm2, [rsp+0x10]
000078d2e7dd4490  vmovaps xmm3, [rsp+0x20]
000078d2e7dd4496  vmovaps xmm4, [rsp+0x30]
000078d2e7dd449c  vmovaps xmm5, [rsp+0x40]
000078d2e7dd44a2  vmovaps xmm6, [rsp+0x50]
000078d2e7dd44a8  vmovaps xmm7, [rsp+0x60]
000078d2e7dd44ae  vmovaps xmm8, [rsp+0x70]
000078d2e7dd44b4  vmovaps xmm9, [rsp+0x80]
000078d2e7dd44bd  vmovaps xmm10, [rsp+0x90]
000078d2e7dd44c6  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd44cf  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd44d8  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd44e1  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd44ea  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd44f3  add rsp, 0xF0
000078d2e7dd44fa  pop r11
000078d2e7dd44fc  pop r10
000078d2e7dd44fe  pop r9
000078d2e7dd4500  pop r8
000078d2e7dd4502  pop rsi
000078d2e7dd4503  pop rdi
000078d2e7dd4504  pop rdx
000078d2e7dd4505  pop rcx
000078d2e7dd4506  pop rax
000078d2e7dd4507  add rsp, 0x08
000078d2e7dd450b  jmp 0x000078D2E7DD2A5C
000078d2e7dd4510  call 0x000078D2E7C0E760
000078d2e7dd4515  jmp 0x000078D2E7DD2A69
000078d2e7dd451a  sub rsp, 0x08
000078d2e7dd451e  push rax
000078d2e7dd451f  push rcx
000078d2e7dd4520  push rdx
000078d2e7dd4521  push rdi
000078d2e7dd4522  push rsi
000078d2e7dd4523  push r8
000078d2e7dd4525  push r9
000078d2e7dd4527  push r10
000078d2e7dd4529  push r11
000078d2e7dd452b  sub rsp, 0xF0
000078d2e7dd4532  vmovaps [rsp], xmm0
000078d2e7dd4537  vmovaps [rsp+0x10], xmm1
000078d2e7dd453d  vmovaps [rsp+0x20], xmm2
000078d2e7dd4543  vmovaps [rsp+0x30], xmm3
000078d2e7dd4549  vmovaps [rsp+0x40], xmm4
000078d2e7dd454f  vmovaps [rsp+0x50], xmm5
000078d2e7dd4555  vmovaps [rsp+0x60], xmm6
000078d2e7dd455b  vmovaps [rsp+0x70], xmm7
000078d2e7dd4561  vmovaps [rsp+0x80], xmm8
000078d2e7dd456a  vmovaps [rsp+0x90], xmm9
000078d2e7dd4573  vmovaps [rsp+0xA0], xmm10
000078d2e7dd457c  vmovaps [rsp+0xB0], xmm11
000078d2e7dd4585  vmovaps [rsp+0xC0], xmm12
000078d2e7dd458e  vmovaps [rsp+0xD0], xmm14
000078d2e7dd4597  vmovaps [rsp+0xE0], xmm15
000078d2e7dd45a0  sub rsp, 0x30
000078d2e7dd45a4  movaps [rsp], xmm13
000078d2e7dd45a9  movaps [rsp+0x10], xmm2
000078d2e7dd45ae  movaps [rsp+0x20], xmm1
000078d2e7dd45b3  lea rdi, [rsp]
000078d2e7dd45b7  mov esi, 0x00
000078d2e7dd45bc  mov rax, 0x5997D2DB1530
000078d2e7dd45c6  call rax
000078d2e7dd45c8  movaps xmm13, [rsp]
000078d2e7dd45cd  add rsp, 0x30
000078d2e7dd45d1  vmovaps xmm0, [rsp]
000078d2e7dd45d6  vmovaps xmm1, [rsp+0x10]
000078d2e7dd45dc  vmovaps xmm2, [rsp+0x20]
000078d2e7dd45e2  vmovaps xmm3, [rsp+0x30]
000078d2e7dd45e8  vmovaps xmm4, [rsp+0x40]
000078d2e7dd45ee  vmovaps xmm5, [rsp+0x50]
000078d2e7dd45f4  vmovaps xmm6, [rsp+0x60]
000078d2e7dd45fa  vmovaps xmm7, [rsp+0x70]
000078d2e7dd4600  vmovaps xmm8, [rsp+0x80]
000078d2e7dd4609  vmovaps xmm9, [rsp+0x90]
000078d2e7dd4612  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd461b  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd4624  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd462d  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd4636  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd463f  add rsp, 0xF0
000078d2e7dd4646  pop r11
000078d2e7dd4648  pop r10
000078d2e7dd464a  pop r9
000078d2e7dd464c  pop r8
000078d2e7dd464e  pop rsi
000078d2e7dd464f  pop rdi
000078d2e7dd4650  pop rdx
000078d2e7dd4651  pop rcx
000078d2e7dd4652  pop rax
000078d2e7dd4653  add rsp, 0x08
000078d2e7dd4657  jmp 0x000078D2E7DD2AA8
000078d2e7dd465c  sub rsp, 0x08
000078d2e7dd4660  push rax
000078d2e7dd4661  push rcx
000078d2e7dd4662  push rdx
000078d2e7dd4663  push rdi
000078d2e7dd4664  push rsi
000078d2e7dd4665  push r8
000078d2e7dd4667  push r9
000078d2e7dd4669  push r10
000078d2e7dd466b  push r11
000078d2e7dd466d  sub rsp, 0xF0
000078d2e7dd4674  vmovaps [rsp], xmm0
000078d2e7dd4679  vmovaps [rsp+0x10], xmm2
000078d2e7dd467f  vmovaps [rsp+0x20], xmm3
000078d2e7dd4685  vmovaps [rsp+0x30], xmm4
000078d2e7dd468b  vmovaps [rsp+0x40], xmm5
000078d2e7dd4691  vmovaps [rsp+0x50], xmm6
000078d2e7dd4697  vmovaps [rsp+0x60], xmm7
000078d2e7dd469d  vmovaps [rsp+0x70], xmm8
000078d2e7dd46a3  vmovaps [rsp+0x80], xmm9
000078d2e7dd46ac  vmovaps [rsp+0x90], xmm10
000078d2e7dd46b5  vmovaps [rsp+0xA0], xmm11
000078d2e7dd46be  vmovaps [rsp+0xB0], xmm12
000078d2e7dd46c7  vmovaps [rsp+0xC0], xmm13
000078d2e7dd46d0  vmovaps [rsp+0xD0], xmm14
000078d2e7dd46d9  vmovaps [rsp+0xE0], xmm15
000078d2e7dd46e2  sub rsp, 0x30
000078d2e7dd46e6  movaps [rsp], xmm1
000078d2e7dd46ea  movaps [rsp+0x10], xmm14
000078d2e7dd46f0  movaps [rsp+0x20], xmm15
000078d2e7dd46f6  lea rdi, [rsp]
000078d2e7dd46fa  mov esi, 0x00
000078d2e7dd46ff  mov rax, 0x5997D2DB1530
000078d2e7dd4709  call rax
000078d2e7dd470b  movaps xmm1, [rsp]
000078d2e7dd470f  add rsp, 0x30
000078d2e7dd4713  vmovaps xmm0, [rsp]
000078d2e7dd4718  vmovaps xmm2, [rsp+0x10]
000078d2e7dd471e  vmovaps xmm3, [rsp+0x20]
000078d2e7dd4724  vmovaps xmm4, [rsp+0x30]
000078d2e7dd472a  vmovaps xmm5, [rsp+0x40]
000078d2e7dd4730  vmovaps xmm6, [rsp+0x50]
000078d2e7dd4736  vmovaps xmm7, [rsp+0x60]
000078d2e7dd473c  vmovaps xmm8, [rsp+0x70]
000078d2e7dd4742  vmovaps xmm9, [rsp+0x80]
000078d2e7dd474b  vmovaps xmm10, [rsp+0x90]
000078d2e7dd4754  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd475d  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd4766  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd476f  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd4778  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd4781  add rsp, 0xF0
000078d2e7dd4788  pop r11
000078d2e7dd478a  pop r10
000078d2e7dd478c  pop r9
000078d2e7dd478e  pop r8
000078d2e7dd4790  pop rsi
000078d2e7dd4791  pop rdi
000078d2e7dd4792  pop rdx
000078d2e7dd4793  pop rcx
000078d2e7dd4794  pop rax
000078d2e7dd4795  add rsp, 0x08
000078d2e7dd4799  jmp 0x000078D2E7DD2ACA
000078d2e7dd479e  sub rsp, 0x08
000078d2e7dd47a2  push rax
000078d2e7dd47a3  push rcx
000078d2e7dd47a4  push rdx
000078d2e7dd47a5  push rdi
000078d2e7dd47a6  push rsi
000078d2e7dd47a7  push r8
000078d2e7dd47a9  push r9
000078d2e7dd47ab  push r10
000078d2e7dd47ad  push r11
000078d2e7dd47af  sub rsp, 0xF0
000078d2e7dd47b6  vmovaps [rsp], xmm0
000078d2e7dd47bb  vmovaps [rsp+0x10], xmm1
000078d2e7dd47c1  vmovaps [rsp+0x20], xmm2
000078d2e7dd47c7  vmovaps [rsp+0x30], xmm3
000078d2e7dd47cd  vmovaps [rsp+0x40], xmm4
000078d2e7dd47d3  vmovaps [rsp+0x50], xmm5
000078d2e7dd47d9  vmovaps [rsp+0x60], xmm6
000078d2e7dd47df  vmovaps [rsp+0x70], xmm7
000078d2e7dd47e5  vmovaps [rsp+0x80], xmm8
000078d2e7dd47ee  vmovaps [rsp+0x90], xmm9
000078d2e7dd47f7  vmovaps [rsp+0xA0], xmm10
000078d2e7dd4800  vmovaps [rsp+0xB0], xmm11
000078d2e7dd4809  vmovaps [rsp+0xC0], xmm12
000078d2e7dd4812  vmovaps [rsp+0xD0], xmm13
000078d2e7dd481b  vmovaps [rsp+0xE0], xmm15
000078d2e7dd4824  sub rsp, 0x30
000078d2e7dd4828  movaps [rsp], xmm14
000078d2e7dd482d  movaps [rsp+0x10], xmm2
000078d2e7dd4832  movaps [rsp+0x20], xmm15
000078d2e7dd4838  lea rdi, [rsp]
000078d2e7dd483c  mov esi, 0x00
000078d2e7dd4841  mov rax, 0x5997D2DB1530
000078d2e7dd484b  call rax
000078d2e7dd484d  movaps xmm14, [rsp]
000078d2e7dd4852  add rsp, 0x30
000078d2e7dd4856  vmovaps xmm0, [rsp]
000078d2e7dd485b  vmovaps xmm1, [rsp+0x10]
000078d2e7dd4861  vmovaps xmm2, [rsp+0x20]
000078d2e7dd4867  vmovaps xmm3, [rsp+0x30]
000078d2e7dd486d  vmovaps xmm4, [rsp+0x40]
000078d2e7dd4873  vmovaps xmm5, [rsp+0x50]
000078d2e7dd4879  vmovaps xmm6, [rsp+0x60]
000078d2e7dd487f  vmovaps xmm7, [rsp+0x70]
000078d2e7dd4885  vmovaps xmm8, [rsp+0x80]
000078d2e7dd488e  vmovaps xmm9, [rsp+0x90]
000078d2e7dd4897  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd48a0  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd48a9  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd48b2  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd48bb  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd48c4  add rsp, 0xF0
000078d2e7dd48cb  pop r11
000078d2e7dd48cd  pop r10
000078d2e7dd48cf  pop r9
000078d2e7dd48d1  pop r8
000078d2e7dd48d3  pop rsi
000078d2e7dd48d4  pop rdi
000078d2e7dd48d5  pop rdx
000078d2e7dd48d6  pop rcx
000078d2e7dd48d7  pop rax
000078d2e7dd48d8  add rsp, 0x08
000078d2e7dd48dc  jmp 0x000078D2E7DD2B05
000078d2e7dd48e1  sub rsp, 0x08
000078d2e7dd48e5  push rax
000078d2e7dd48e6  push rcx
000078d2e7dd48e7  push rdx
000078d2e7dd48e8  push rdi
000078d2e7dd48e9  push rsi
000078d2e7dd48ea  push r8
000078d2e7dd48ec  push r9
000078d2e7dd48ee  push r10
000078d2e7dd48f0  push r11
000078d2e7dd48f2  sub rsp, 0xF0
000078d2e7dd48f9  vmovaps [rsp], xmm0
000078d2e7dd48fe  vmovaps [rsp+0x10], xmm1
000078d2e7dd4904  vmovaps [rsp+0x20], xmm2
000078d2e7dd490a  vmovaps [rsp+0x30], xmm3
000078d2e7dd4910  vmovaps [rsp+0x40], xmm4
000078d2e7dd4916  vmovaps [rsp+0x50], xmm5
000078d2e7dd491c  vmovaps [rsp+0x60], xmm6
000078d2e7dd4922  vmovaps [rsp+0x70], xmm7
000078d2e7dd4928  vmovaps [rsp+0x80], xmm8
000078d2e7dd4931  vmovaps [rsp+0x90], xmm9
000078d2e7dd493a  vmovaps [rsp+0xA0], xmm10
000078d2e7dd4943  vmovaps [rsp+0xB0], xmm11
000078d2e7dd494c  vmovaps [rsp+0xC0], xmm12
000078d2e7dd4955  vmovaps [rsp+0xD0], xmm13
000078d2e7dd495e  vmovaps [rsp+0xE0], xmm14
000078d2e7dd4967  sub rsp, 0x30
000078d2e7dd496b  movaps [rsp], xmm15
000078d2e7dd4970  movaps [rsp+0x10], xmm2
000078d2e7dd4975  movaps [rsp+0x20], xmm1
000078d2e7dd497a  lea rdi, [rsp]
000078d2e7dd497e  mov esi, 0x00
000078d2e7dd4983  mov rax, 0x5997D2DB1530
000078d2e7dd498d  call rax
000078d2e7dd498f  movaps xmm15, [rsp]
000078d2e7dd4994  add rsp, 0x30
000078d2e7dd4998  vmovaps xmm0, [rsp]
000078d2e7dd499d  vmovaps xmm1, [rsp+0x10]
000078d2e7dd49a3  vmovaps xmm2, [rsp+0x20]
000078d2e7dd49a9  vmovaps xmm3, [rsp+0x30]
000078d2e7dd49af  vmovaps xmm4, [rsp+0x40]
000078d2e7dd49b5  vmovaps xmm5, [rsp+0x50]
000078d2e7dd49bb  vmovaps xmm6, [rsp+0x60]
000078d2e7dd49c1  vmovaps xmm7, [rsp+0x70]
000078d2e7dd49c7  vmovaps xmm8, [rsp+0x80]
000078d2e7dd49d0  vmovaps xmm9, [rsp+0x90]
000078d2e7dd49d9  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd49e2  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd49eb  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd49f4  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd49fd  vmovaps xmm14, [rsp+0xE0]
000078d2e7dd4a06  add rsp, 0xF0
000078d2e7dd4a0d  pop r11
000078d2e7dd4a0f  pop r10
000078d2e7dd4a11  pop r9
000078d2e7dd4a13  pop r8
000078d2e7dd4a15  pop rsi
000078d2e7dd4a16  pop rdi
000078d2e7dd4a17  pop rdx
000078d2e7dd4a18  pop rcx
000078d2e7dd4a19  pop rax
000078d2e7dd4a1a  add rsp, 0x08
000078d2e7dd4a1e  jmp 0x000078D2E7DD2B41
000078d2e7dd4a23  call 0x000078D2E7BFF430
000078d2e7dd4a28  jmp 0x000078D2E7DD2B4E
000078d2e7dd4a2d  sub rsp, 0x08
000078d2e7dd4a31  push rax
000078d2e7dd4a32  push rcx
000078d2e7dd4a33  push rdx
000078d2e7dd4a34  push rdi
000078d2e7dd4a35  push rsi
000078d2e7dd4a36  push r8
000078d2e7dd4a38  push r9
000078d2e7dd4a3a  push r10
000078d2e7dd4a3c  push r11
000078d2e7dd4a3e  sub rsp, 0xF0
000078d2e7dd4a45  vmovaps [rsp], xmm0
000078d2e7dd4a4a  vmovaps [rsp+0x10], xmm1
000078d2e7dd4a50  vmovaps [rsp+0x20], xmm3
000078d2e7dd4a56  vmovaps [rsp+0x30], xmm4
000078d2e7dd4a5c  vmovaps [rsp+0x40], xmm5
000078d2e7dd4a62  vmovaps [rsp+0x50], xmm6
000078d2e7dd4a68  vmovaps [rsp+0x60], xmm7
000078d2e7dd4a6e  vmovaps [rsp+0x70], xmm8
000078d2e7dd4a74  vmovaps [rsp+0x80], xmm9
000078d2e7dd4a7d  vmovaps [rsp+0x90], xmm10
000078d2e7dd4a86  vmovaps [rsp+0xA0], xmm11
000078d2e7dd4a8f  vmovaps [rsp+0xB0], xmm12
000078d2e7dd4a98  vmovaps [rsp+0xC0], xmm13
000078d2e7dd4aa1  vmovaps [rsp+0xD0], xmm14
000078d2e7dd4aaa  vmovaps [rsp+0xE0], xmm15
000078d2e7dd4ab3  sub rsp, 0x30
000078d2e7dd4ab7  movaps [rsp], xmm2
000078d2e7dd4abb  movaps [rsp+0x10], xmm1
000078d2e7dd4ac0  movaps [rsp+0x20], xmm14
000078d2e7dd4ac6  lea rdi, [rsp]
000078d2e7dd4aca  mov esi, 0x00
000078d2e7dd4acf  mov rax, 0x5997D2DB1530
000078d2e7dd4ad9  call rax
000078d2e7dd4adb  movaps xmm2, [rsp]
000078d2e7dd4adf  add rsp, 0x30
000078d2e7dd4ae3  vmovaps xmm0, [rsp]
000078d2e7dd4ae8  vmovaps xmm1, [rsp+0x10]
000078d2e7dd4aee  vmovaps xmm3, [rsp+0x20]
000078d2e7dd4af4  vmovaps xmm4, [rsp+0x30]
000078d2e7dd4afa  vmovaps xmm5, [rsp+0x40]
000078d2e7dd4b00  vmovaps xmm6, [rsp+0x50]
000078d2e7dd4b06  vmovaps xmm7, [rsp+0x60]
000078d2e7dd4b0c  vmovaps xmm8, [rsp+0x70]
000078d2e7dd4b12  vmovaps xmm9, [rsp+0x80]
000078d2e7dd4b1b  vmovaps xmm10, [rsp+0x90]
000078d2e7dd4b24  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd4b2d  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd4b36  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd4b3f  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd4b48  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd4b51  add rsp, 0xF0
000078d2e7dd4b58  pop r11
000078d2e7dd4b5a  pop r10
000078d2e7dd4b5c  pop r9
000078d2e7dd4b5e  pop r8
000078d2e7dd4b60  pop rsi
000078d2e7dd4b61  pop rdi
000078d2e7dd4b62  pop rdx
000078d2e7dd4b63  pop rcx
000078d2e7dd4b64  pop rax
000078d2e7dd4b65  add rsp, 0x08
000078d2e7dd4b69  jmp 0x000078D2E7DD2B8B
000078d2e7dd4b6e  sub rsp, 0x08
000078d2e7dd4b72  push rax
000078d2e7dd4b73  push rcx
000078d2e7dd4b74  push rdx
000078d2e7dd4b75  push rdi
000078d2e7dd4b76  push rsi
000078d2e7dd4b77  push r8
000078d2e7dd4b79  push r9
000078d2e7dd4b7b  push r10
000078d2e7dd4b7d  push r11
000078d2e7dd4b7f  sub rsp, 0xF0
000078d2e7dd4b86  vmovaps [rsp], xmm0
000078d2e7dd4b8b  vmovaps [rsp+0x10], xmm1
000078d2e7dd4b91  vmovaps [rsp+0x20], xmm2
000078d2e7dd4b97  vmovaps [rsp+0x30], xmm3
000078d2e7dd4b9d  vmovaps [rsp+0x40], xmm4
000078d2e7dd4ba3  vmovaps [rsp+0x50], xmm5
000078d2e7dd4ba9  vmovaps [rsp+0x60], xmm6
000078d2e7dd4baf  vmovaps [rsp+0x70], xmm7
000078d2e7dd4bb5  vmovaps [rsp+0x80], xmm8
000078d2e7dd4bbe  vmovaps [rsp+0x90], xmm9
000078d2e7dd4bc7  vmovaps [rsp+0xA0], xmm10
000078d2e7dd4bd0  vmovaps [rsp+0xB0], xmm11
000078d2e7dd4bd9  vmovaps [rsp+0xC0], xmm12
000078d2e7dd4be2  vmovaps [rsp+0xD0], xmm13
000078d2e7dd4beb  vmovaps [rsp+0xE0], xmm14
000078d2e7dd4bf4  sub rsp, 0x30
000078d2e7dd4bf8  movaps [rsp], xmm15
000078d2e7dd4bfd  movaps [rsp+0x10], xmm14
000078d2e7dd4c03  movaps [rsp+0x20], xmm1
000078d2e7dd4c08  lea rdi, [rsp]
000078d2e7dd4c0c  mov esi, 0x00
000078d2e7dd4c11  mov rax, 0x5997D2DB1530
000078d2e7dd4c1b  call rax
000078d2e7dd4c1d  movaps xmm15, [rsp]
000078d2e7dd4c22  add rsp, 0x30
000078d2e7dd4c26  vmovaps xmm0, [rsp]
000078d2e7dd4c2b  vmovaps xmm1, [rsp+0x10]
000078d2e7dd4c31  vmovaps xmm2, [rsp+0x20]
000078d2e7dd4c37  vmovaps xmm3, [rsp+0x30]
000078d2e7dd4c3d  vmovaps xmm4, [rsp+0x40]
000078d2e7dd4c43  vmovaps xmm5, [rsp+0x50]
000078d2e7dd4c49  vmovaps xmm6, [rsp+0x60]
000078d2e7dd4c4f  vmovaps xmm7, [rsp+0x70]
000078d2e7dd4c55  vmovaps xmm8, [rsp+0x80]
000078d2e7dd4c5e  vmovaps xmm9, [rsp+0x90]
000078d2e7dd4c67  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd4c70  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd4c79  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd4c82  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd4c8b  vmovaps xmm14, [rsp+0xE0]
000078d2e7dd4c94  add rsp, 0xF0
000078d2e7dd4c9b  pop r11
000078d2e7dd4c9d  pop r10
000078d2e7dd4c9f  pop r9
000078d2e7dd4ca1  pop r8
000078d2e7dd4ca3  pop rsi
000078d2e7dd4ca4  pop rdi
000078d2e7dd4ca5  pop rdx
000078d2e7dd4ca6  pop rcx
000078d2e7dd4ca7  pop rax
000078d2e7dd4ca8  add rsp, 0x08
000078d2e7dd4cac  jmp 0x000078D2E7DD2C05
000078d2e7dd4cb1  call 0x000078D2E7BFF430
000078d2e7dd4cb6  jmp 0x000078D2E7DD2C12
000078d2e7dd4cbb  sub rsp, 0x08
000078d2e7dd4cbf  push rax
000078d2e7dd4cc0  push rcx
000078d2e7dd4cc1  push rdx
000078d2e7dd4cc2  push rdi
000078d2e7dd4cc3  push rsi
000078d2e7dd4cc4  push r8
000078d2e7dd4cc6  push r9
000078d2e7dd4cc8  push r10
000078d2e7dd4cca  push r11
000078d2e7dd4ccc  sub rsp, 0xF0
000078d2e7dd4cd3  vmovaps [rsp], xmm0
000078d2e7dd4cd8  vmovaps [rsp+0x10], xmm1
000078d2e7dd4cde  vmovaps [rsp+0x20], xmm2
000078d2e7dd4ce4  vmovaps [rsp+0x30], xmm3
000078d2e7dd4cea  vmovaps [rsp+0x40], xmm4
000078d2e7dd4cf0  vmovaps [rsp+0x50], xmm5
000078d2e7dd4cf6  vmovaps [rsp+0x60], xmm6
000078d2e7dd4cfc  vmovaps [rsp+0x70], xmm7
000078d2e7dd4d02  vmovaps [rsp+0x80], xmm8
000078d2e7dd4d0b  vmovaps [rsp+0x90], xmm9
000078d2e7dd4d14  vmovaps [rsp+0xA0], xmm10
000078d2e7dd4d1d  vmovaps [rsp+0xB0], xmm11
000078d2e7dd4d26  vmovaps [rsp+0xC0], xmm12
000078d2e7dd4d2f  vmovaps [rsp+0xD0], xmm14
000078d2e7dd4d38  vmovaps [rsp+0xE0], xmm15
000078d2e7dd4d41  sub rsp, 0x30
000078d2e7dd4d45  movaps [rsp], xmm13
000078d2e7dd4d4a  movaps [rsp+0x10], xmm1
000078d2e7dd4d4f  movaps [rsp+0x20], xmm15
000078d2e7dd4d55  lea rdi, [rsp]
000078d2e7dd4d59  mov esi, 0x00
000078d2e7dd4d5e  mov rax, 0x5997D2DB1530
000078d2e7dd4d68  call rax
000078d2e7dd4d6a  movaps xmm13, [rsp]
000078d2e7dd4d6f  add rsp, 0x30
000078d2e7dd4d73  vmovaps xmm0, [rsp]
000078d2e7dd4d78  vmovaps xmm1, [rsp+0x10]
000078d2e7dd4d7e  vmovaps xmm2, [rsp+0x20]
000078d2e7dd4d84  vmovaps xmm3, [rsp+0x30]
000078d2e7dd4d8a  vmovaps xmm4, [rsp+0x40]
000078d2e7dd4d90  vmovaps xmm5, [rsp+0x50]
000078d2e7dd4d96  vmovaps xmm6, [rsp+0x60]
000078d2e7dd4d9c  vmovaps xmm7, [rsp+0x70]
000078d2e7dd4da2  vmovaps xmm8, [rsp+0x80]
000078d2e7dd4dab  vmovaps xmm9, [rsp+0x90]
000078d2e7dd4db4  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd4dbd  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd4dc6  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd4dcf  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd4dd8  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd4de1  add rsp, 0xF0
000078d2e7dd4de8  pop r11
000078d2e7dd4dea  pop r10
000078d2e7dd4dec  pop r9
000078d2e7dd4dee  pop r8
000078d2e7dd4df0  pop rsi
000078d2e7dd4df1  pop rdi
000078d2e7dd4df2  pop rdx
000078d2e7dd4df3  pop rcx
000078d2e7dd4df4  pop rax
000078d2e7dd4df5  add rsp, 0x08
000078d2e7dd4df9  jmp 0x000078D2E7DD2CD6
000078d2e7dd4dfe  sub rsp, 0x08
000078d2e7dd4e02  push rax
000078d2e7dd4e03  push rcx
000078d2e7dd4e04  push rdx
000078d2e7dd4e05  push rdi
000078d2e7dd4e06  push rsi
000078d2e7dd4e07  push r8
000078d2e7dd4e09  push r9
000078d2e7dd4e0b  push r10
000078d2e7dd4e0d  push r11
000078d2e7dd4e0f  sub rsp, 0xF0
000078d2e7dd4e16  vmovaps [rsp], xmm0
000078d2e7dd4e1b  vmovaps [rsp+0x10], xmm1
000078d2e7dd4e21  vmovaps [rsp+0x20], xmm2
000078d2e7dd4e27  vmovaps [rsp+0x30], xmm3
000078d2e7dd4e2d  vmovaps [rsp+0x40], xmm4
000078d2e7dd4e33  vmovaps [rsp+0x50], xmm5
000078d2e7dd4e39  vmovaps [rsp+0x60], xmm6
000078d2e7dd4e3f  vmovaps [rsp+0x70], xmm7
000078d2e7dd4e45  vmovaps [rsp+0x80], xmm8
000078d2e7dd4e4e  vmovaps [rsp+0x90], xmm9
000078d2e7dd4e57  vmovaps [rsp+0xA0], xmm10
000078d2e7dd4e60  vmovaps [rsp+0xB0], xmm11
000078d2e7dd4e69  vmovaps [rsp+0xC0], xmm12
000078d2e7dd4e72  vmovaps [rsp+0xD0], xmm13
000078d2e7dd4e7b  vmovaps [rsp+0xE0], xmm14
000078d2e7dd4e84  sub rsp, 0x30
000078d2e7dd4e88  movaps [rsp], xmm15
000078d2e7dd4e8d  movaps [rsp+0x10], xmm14
000078d2e7dd4e93  movaps [rsp+0x20], xmm1
000078d2e7dd4e98  lea rdi, [rsp]
000078d2e7dd4e9c  mov esi, 0x00
000078d2e7dd4ea1  mov rax, 0x5997D2DB1530
000078d2e7dd4eab  call rax
000078d2e7dd4ead  movaps xmm15, [rsp]
000078d2e7dd4eb2  add rsp, 0x30
000078d2e7dd4eb6  vmovaps xmm0, [rsp]
000078d2e7dd4ebb  vmovaps xmm1, [rsp+0x10]
000078d2e7dd4ec1  vmovaps xmm2, [rsp+0x20]
000078d2e7dd4ec7  vmovaps xmm3, [rsp+0x30]
000078d2e7dd4ecd  vmovaps xmm4, [rsp+0x40]
000078d2e7dd4ed3  vmovaps xmm5, [rsp+0x50]
000078d2e7dd4ed9  vmovaps xmm6, [rsp+0x60]
000078d2e7dd4edf  vmovaps xmm7, [rsp+0x70]
000078d2e7dd4ee5  vmovaps xmm8, [rsp+0x80]
000078d2e7dd4eee  vmovaps xmm9, [rsp+0x90]
000078d2e7dd4ef7  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd4f00  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd4f09  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd4f12  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd4f1b  vmovaps xmm14, [rsp+0xE0]
000078d2e7dd4f24  add rsp, 0xF0
000078d2e7dd4f2b  pop r11
000078d2e7dd4f2d  pop r10
000078d2e7dd4f2f  pop r9
000078d2e7dd4f31  pop r8
000078d2e7dd4f33  pop rsi
000078d2e7dd4f34  pop rdi
000078d2e7dd4f35  pop rdx
000078d2e7dd4f36  pop rcx
000078d2e7dd4f37  pop rax
000078d2e7dd4f38  add rsp, 0x08
000078d2e7dd4f3c  jmp 0x000078D2E7DD2D12
000078d2e7dd4f41  call 0x000078D2E7BFF430
000078d2e7dd4f46  jmp 0x000078D2E7DD2D1F
000078d2e7dd4f4b  sub rsp, 0x08
000078d2e7dd4f4f  push rax
000078d2e7dd4f50  push rcx
000078d2e7dd4f51  push rdx
000078d2e7dd4f52  push rdi
000078d2e7dd4f53  push rsi
000078d2e7dd4f54  push r8
000078d2e7dd4f56  push r9
000078d2e7dd4f58  push r10
000078d2e7dd4f5a  push r11
000078d2e7dd4f5c  sub rsp, 0xF0
000078d2e7dd4f63  vmovaps [rsp], xmm0
000078d2e7dd4f68  vmovaps [rsp+0x10], xmm1
000078d2e7dd4f6e  vmovaps [rsp+0x20], xmm2
000078d2e7dd4f74  vmovaps [rsp+0x30], xmm3
000078d2e7dd4f7a  vmovaps [rsp+0x40], xmm4
000078d2e7dd4f80  vmovaps [rsp+0x50], xmm5
000078d2e7dd4f86  vmovaps [rsp+0x60], xmm6
000078d2e7dd4f8c  vmovaps [rsp+0x70], xmm7
000078d2e7dd4f92  vmovaps [rsp+0x80], xmm8
000078d2e7dd4f9b  vmovaps [rsp+0x90], xmm9
000078d2e7dd4fa4  vmovaps [rsp+0xA0], xmm10
000078d2e7dd4fad  vmovaps [rsp+0xB0], xmm11
000078d2e7dd4fb6  vmovaps [rsp+0xC0], xmm12
000078d2e7dd4fbf  vmovaps [rsp+0xD0], xmm13
000078d2e7dd4fc8  vmovaps [rsp+0xE0], xmm15
000078d2e7dd4fd1  sub rsp, 0x30
000078d2e7dd4fd5  movaps [rsp], xmm14
000078d2e7dd4fda  movaps [rsp+0x10], xmm13
000078d2e7dd4fe0  movaps [rsp+0x20], xmm2
000078d2e7dd4fe5  lea rdi, [rsp]
000078d2e7dd4fe9  mov esi, 0x00
000078d2e7dd4fee  mov rax, 0x5997D2DB1530
000078d2e7dd4ff8  call rax
000078d2e7dd4ffa  movaps xmm14, [rsp]
000078d2e7dd4fff  add rsp, 0x30
000078d2e7dd5003  vmovaps xmm0, [rsp]
000078d2e7dd5008  vmovaps xmm1, [rsp+0x10]
000078d2e7dd500e  vmovaps xmm2, [rsp+0x20]
000078d2e7dd5014  vmovaps xmm3, [rsp+0x30]
000078d2e7dd501a  vmovaps xmm4, [rsp+0x40]
000078d2e7dd5020  vmovaps xmm5, [rsp+0x50]
000078d2e7dd5026  vmovaps xmm6, [rsp+0x60]
000078d2e7dd502c  vmovaps xmm7, [rsp+0x70]
000078d2e7dd5032  vmovaps xmm8, [rsp+0x80]
000078d2e7dd503b  vmovaps xmm9, [rsp+0x90]
000078d2e7dd5044  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd504d  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd5056  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd505f  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd5068  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd5071  add rsp, 0xF0
000078d2e7dd5078  pop r11
000078d2e7dd507a  pop r10
000078d2e7dd507c  pop r9
000078d2e7dd507e  pop r8
000078d2e7dd5080  pop rsi
000078d2e7dd5081  pop rdi
000078d2e7dd5082  pop rdx
000078d2e7dd5083  pop rcx
000078d2e7dd5084  pop rax
000078d2e7dd5085  add rsp, 0x08
000078d2e7dd5089  jmp 0x000078D2E7DD2D4B
000078d2e7dd508e  sub rsp, 0x08
000078d2e7dd5092  push rax
000078d2e7dd5093  push rcx
000078d2e7dd5094  push rdx
000078d2e7dd5095  push rdi
000078d2e7dd5096  push rsi
000078d2e7dd5097  push r8
000078d2e7dd5099  push r9
000078d2e7dd509b  push r10
000078d2e7dd509d  push r11
000078d2e7dd509f  sub rsp, 0xF0
000078d2e7dd50a6  vmovaps [rsp], xmm0
000078d2e7dd50ab  vmovaps [rsp+0x10], xmm2
000078d2e7dd50b1  vmovaps [rsp+0x20], xmm3
000078d2e7dd50b7  vmovaps [rsp+0x30], xmm4
000078d2e7dd50bd  vmovaps [rsp+0x40], xmm5
000078d2e7dd50c3  vmovaps [rsp+0x50], xmm6
000078d2e7dd50c9  vmovaps [rsp+0x60], xmm7
000078d2e7dd50cf  vmovaps [rsp+0x70], xmm8
000078d2e7dd50d5  vmovaps [rsp+0x80], xmm9
000078d2e7dd50de  vmovaps [rsp+0x90], xmm10
000078d2e7dd50e7  vmovaps [rsp+0xA0], xmm11
000078d2e7dd50f0  vmovaps [rsp+0xB0], xmm12
000078d2e7dd50f9  vmovaps [rsp+0xC0], xmm13
000078d2e7dd5102  vmovaps [rsp+0xD0], xmm14
000078d2e7dd510b  vmovaps [rsp+0xE0], xmm15
000078d2e7dd5114  sub rsp, 0x30
000078d2e7dd5118  movaps [rsp], xmm1
000078d2e7dd511c  movaps [rsp+0x10], xmm13
000078d2e7dd5122  movaps [rsp+0x20], xmm2
000078d2e7dd5127  lea rdi, [rsp]
000078d2e7dd512b  mov esi, 0x00
000078d2e7dd5130  mov rax, 0x5997D2DB1530
000078d2e7dd513a  call rax
000078d2e7dd513c  movaps xmm1, [rsp]
000078d2e7dd5140  add rsp, 0x30
000078d2e7dd5144  vmovaps xmm0, [rsp]
000078d2e7dd5149  vmovaps xmm2, [rsp+0x10]
000078d2e7dd514f  vmovaps xmm3, [rsp+0x20]
000078d2e7dd5155  vmovaps xmm4, [rsp+0x30]
000078d2e7dd515b  vmovaps xmm5, [rsp+0x40]
000078d2e7dd5161  vmovaps xmm6, [rsp+0x50]
000078d2e7dd5167  vmovaps xmm7, [rsp+0x60]
000078d2e7dd516d  vmovaps xmm8, [rsp+0x70]
000078d2e7dd5173  vmovaps xmm9, [rsp+0x80]
000078d2e7dd517c  vmovaps xmm10, [rsp+0x90]
000078d2e7dd5185  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd518e  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd5197  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd51a0  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd51a9  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd51b2  add rsp, 0xF0
000078d2e7dd51b9  pop r11
000078d2e7dd51bb  pop r10
000078d2e7dd51bd  pop r9
000078d2e7dd51bf  pop r8
000078d2e7dd51c1  pop rsi
000078d2e7dd51c2  pop rdi
000078d2e7dd51c3  pop rdx
000078d2e7dd51c4  pop rcx
000078d2e7dd51c5  pop rax
000078d2e7dd51c6  add rsp, 0x08
000078d2e7dd51ca  jmp 0x000078D2E7DD2D79
000078d2e7dd51cf  sub rsp, 0x08
000078d2e7dd51d3  push rax
000078d2e7dd51d4  push rcx
000078d2e7dd51d5  push rdx
000078d2e7dd51d6  push rdi
000078d2e7dd51d7  push rsi
000078d2e7dd51d8  push r8
000078d2e7dd51da  push r9
000078d2e7dd51dc  push r10
000078d2e7dd51de  push r11
000078d2e7dd51e0  sub rsp, 0xF0
000078d2e7dd51e7  vmovaps [rsp], xmm0
000078d2e7dd51ec  vmovaps [rsp+0x10], xmm1
000078d2e7dd51f2  vmovaps [rsp+0x20], xmm3
000078d2e7dd51f8  vmovaps [rsp+0x30], xmm4
000078d2e7dd51fe  vmovaps [rsp+0x40], xmm5
000078d2e7dd5204  vmovaps [rsp+0x50], xmm6
000078d2e7dd520a  vmovaps [rsp+0x60], xmm7
000078d2e7dd5210  vmovaps [rsp+0x70], xmm8
000078d2e7dd5216  vmovaps [rsp+0x80], xmm9
000078d2e7dd521f  vmovaps [rsp+0x90], xmm10
000078d2e7dd5228  vmovaps [rsp+0xA0], xmm11
000078d2e7dd5231  vmovaps [rsp+0xB0], xmm12
000078d2e7dd523a  vmovaps [rsp+0xC0], xmm13
000078d2e7dd5243  vmovaps [rsp+0xD0], xmm14
000078d2e7dd524c  vmovaps [rsp+0xE0], xmm15
000078d2e7dd5255  sub rsp, 0x30
000078d2e7dd5259  movaps [rsp], xmm2
000078d2e7dd525d  movaps [rsp+0x10], xmm1
000078d2e7dd5262  movaps [rsp+0x20], xmm13
000078d2e7dd5268  lea rdi, [rsp]
000078d2e7dd526c  mov esi, 0x00
000078d2e7dd5271  mov rax, 0x5997D2DB1530
000078d2e7dd527b  call rax
000078d2e7dd527d  movaps xmm2, [rsp]
000078d2e7dd5281  add rsp, 0x30
000078d2e7dd5285  vmovaps xmm0, [rsp]
000078d2e7dd528a  vmovaps xmm1, [rsp+0x10]
000078d2e7dd5290  vmovaps xmm3, [rsp+0x20]
000078d2e7dd5296  vmovaps xmm4, [rsp+0x30]
000078d2e7dd529c  vmovaps xmm5, [rsp+0x40]
000078d2e7dd52a2  vmovaps xmm6, [rsp+0x50]
000078d2e7dd52a8  vmovaps xmm7, [rsp+0x60]
000078d2e7dd52ae  vmovaps xmm8, [rsp+0x70]
000078d2e7dd52b4  vmovaps xmm9, [rsp+0x80]
000078d2e7dd52bd  vmovaps xmm10, [rsp+0x90]
000078d2e7dd52c6  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd52cf  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd52d8  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd52e1  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd52ea  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd52f3  add rsp, 0xF0
000078d2e7dd52fa  pop r11
000078d2e7dd52fc  pop r10
000078d2e7dd52fe  pop r9
000078d2e7dd5300  pop r8
000078d2e7dd5302  pop rsi
000078d2e7dd5303  pop rdi
000078d2e7dd5304  pop rdx
000078d2e7dd5305  pop rcx
000078d2e7dd5306  pop rax
000078d2e7dd5307  add rsp, 0x08
000078d2e7dd530b  jmp 0x000078D2E7DD2DD2
000078d2e7dd5310  call 0x000078D2E7BFF430
000078d2e7dd5315  jmp 0x000078D2E7DD2DDF
000078d2e7dd531a  sub rsp, 0x08
000078d2e7dd531e  push rax
000078d2e7dd531f  push rcx
000078d2e7dd5320  push rdx
000078d2e7dd5321  push rdi
000078d2e7dd5322  push rsi
000078d2e7dd5323  push r8
000078d2e7dd5325  push r9
000078d2e7dd5327  push r10
000078d2e7dd5329  push r11
000078d2e7dd532b  sub rsp, 0xF0
000078d2e7dd5332  vmovaps [rsp], xmm0
000078d2e7dd5337  vmovaps [rsp+0x10], xmm1
000078d2e7dd533d  vmovaps [rsp+0x20], xmm2
000078d2e7dd5343  vmovaps [rsp+0x30], xmm3
000078d2e7dd5349  vmovaps [rsp+0x40], xmm4
000078d2e7dd534f  vmovaps [rsp+0x50], xmm5
000078d2e7dd5355  vmovaps [rsp+0x60], xmm6
000078d2e7dd535b  vmovaps [rsp+0x70], xmm7
000078d2e7dd5361  vmovaps [rsp+0x80], xmm8
000078d2e7dd536a  vmovaps [rsp+0x90], xmm9
000078d2e7dd5373  vmovaps [rsp+0xA0], xmm10
000078d2e7dd537c  vmovaps [rsp+0xB0], xmm11
000078d2e7dd5385  vmovaps [rsp+0xC0], xmm12
000078d2e7dd538e  vmovaps [rsp+0xD0], xmm13
000078d2e7dd5397  vmovaps [rsp+0xE0], xmm14
000078d2e7dd53a0  sub rsp, 0x30
000078d2e7dd53a4  movaps [rsp], xmm15
000078d2e7dd53a9  movaps [rsp+0x10], xmm13
000078d2e7dd53af  movaps [rsp+0x20], xmm1
000078d2e7dd53b4  lea rdi, [rsp]
000078d2e7dd53b8  mov esi, 0x00
000078d2e7dd53bd  mov rax, 0x5997D2DB1530
000078d2e7dd53c7  call rax
000078d2e7dd53c9  movaps xmm15, [rsp]
000078d2e7dd53ce  add rsp, 0x30
000078d2e7dd53d2  vmovaps xmm0, [rsp]
000078d2e7dd53d7  vmovaps xmm1, [rsp+0x10]
000078d2e7dd53dd  vmovaps xmm2, [rsp+0x20]
000078d2e7dd53e3  vmovaps xmm3, [rsp+0x30]
000078d2e7dd53e9  vmovaps xmm4, [rsp+0x40]
000078d2e7dd53ef  vmovaps xmm5, [rsp+0x50]
000078d2e7dd53f5  vmovaps xmm6, [rsp+0x60]
000078d2e7dd53fb  vmovaps xmm7, [rsp+0x70]
000078d2e7dd5401  vmovaps xmm8, [rsp+0x80]
000078d2e7dd540a  vmovaps xmm9, [rsp+0x90]
000078d2e7dd5413  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd541c  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd5425  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd542e  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd5437  vmovaps xmm14, [rsp+0xE0]
000078d2e7dd5440  add rsp, 0xF0
000078d2e7dd5447  pop r11
000078d2e7dd5449  pop r10
000078d2e7dd544b  pop r9
000078d2e7dd544d  pop r8
000078d2e7dd544f  pop rsi
000078d2e7dd5450  pop rdi
000078d2e7dd5451  pop rdx
000078d2e7dd5452  pop rcx
000078d2e7dd5453  pop rax
000078d2e7dd5454  add rsp, 0x08
000078d2e7dd5458  jmp 0x000078D2E7DD2E1E
000078d2e7dd545d  sub rsp, 0x08
000078d2e7dd5461  push rax
000078d2e7dd5462  push rcx
000078d2e7dd5463  push rdx
000078d2e7dd5464  push rdi
000078d2e7dd5465  push rsi
000078d2e7dd5466  push r8
000078d2e7dd5468  push r9
000078d2e7dd546a  push r10
000078d2e7dd546c  push r11
000078d2e7dd546e  sub rsp, 0xF0
000078d2e7dd5475  vmovaps [rsp], xmm0
000078d2e7dd547a  vmovaps [rsp+0x10], xmm1
000078d2e7dd5480  vmovaps [rsp+0x20], xmm2
000078d2e7dd5486  vmovaps [rsp+0x30], xmm3
000078d2e7dd548c  vmovaps [rsp+0x40], xmm4
000078d2e7dd5492  vmovaps [rsp+0x50], xmm5
000078d2e7dd5498  vmovaps [rsp+0x60], xmm6
000078d2e7dd549e  vmovaps [rsp+0x70], xmm7
000078d2e7dd54a4  vmovaps [rsp+0x80], xmm8
000078d2e7dd54ad  vmovaps [rsp+0x90], xmm9
000078d2e7dd54b6  vmovaps [rsp+0xA0], xmm10
000078d2e7dd54bf  vmovaps [rsp+0xB0], xmm11
000078d2e7dd54c8  vmovaps [rsp+0xC0], xmm12
000078d2e7dd54d1  vmovaps [rsp+0xD0], xmm13
000078d2e7dd54da  vmovaps [rsp+0xE0], xmm15
000078d2e7dd54e3  sub rsp, 0x30
000078d2e7dd54e7  movaps [rsp], xmm14
000078d2e7dd54ec  movaps [rsp+0x10], xmm11
000078d2e7dd54f2  movaps [rsp+0x20], xmm1
000078d2e7dd54f7  lea rdi, [rsp]
000078d2e7dd54fb  mov esi, 0x00
000078d2e7dd5500  mov rax, 0x5997D2DB1530
000078d2e7dd550a  call rax
000078d2e7dd550c  movaps xmm14, [rsp]
000078d2e7dd5511  add rsp, 0x30
000078d2e7dd5515  vmovaps xmm0, [rsp]
000078d2e7dd551a  vmovaps xmm1, [rsp+0x10]
000078d2e7dd5520  vmovaps xmm2, [rsp+0x20]
000078d2e7dd5526  vmovaps xmm3, [rsp+0x30]
000078d2e7dd552c  vmovaps xmm4, [rsp+0x40]
000078d2e7dd5532  vmovaps xmm5, [rsp+0x50]
000078d2e7dd5538  vmovaps xmm6, [rsp+0x60]
000078d2e7dd553e  vmovaps xmm7, [rsp+0x70]
000078d2e7dd5544  vmovaps xmm8, [rsp+0x80]
000078d2e7dd554d  vmovaps xmm9, [rsp+0x90]
000078d2e7dd5556  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd555f  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd5568  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd5571  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd557a  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd5583  add rsp, 0xF0
000078d2e7dd558a  pop r11
000078d2e7dd558c  pop r10
000078d2e7dd558e  pop r9
000078d2e7dd5590  pop r8
000078d2e7dd5592  pop rsi
000078d2e7dd5593  pop rdi
000078d2e7dd5594  pop rdx
000078d2e7dd5595  pop rcx
000078d2e7dd5596  pop rax
000078d2e7dd5597  add rsp, 0x08
000078d2e7dd559b  jmp 0x000078D2E7DD2E48
000078d2e7dd55a0  sub rsp, 0x08
000078d2e7dd55a4  push rax
000078d2e7dd55a5  push rcx
000078d2e7dd55a6  push rdx
000078d2e7dd55a7  push rdi
000078d2e7dd55a8  push rsi
000078d2e7dd55a9  push r8
000078d2e7dd55ab  push r9
000078d2e7dd55ad  push r10
000078d2e7dd55af  push r11
000078d2e7dd55b1  sub rsp, 0xF0
000078d2e7dd55b8  vmovaps [rsp], xmm0
000078d2e7dd55bd  vmovaps [rsp+0x10], xmm1
000078d2e7dd55c3  vmovaps [rsp+0x20], xmm2
000078d2e7dd55c9  vmovaps [rsp+0x30], xmm3
000078d2e7dd55cf  vmovaps [rsp+0x40], xmm4
000078d2e7dd55d5  vmovaps [rsp+0x50], xmm5
000078d2e7dd55db  vmovaps [rsp+0x60], xmm6
000078d2e7dd55e1  vmovaps [rsp+0x70], xmm7
000078d2e7dd55e7  vmovaps [rsp+0x80], xmm8
000078d2e7dd55f0  vmovaps [rsp+0x90], xmm9
000078d2e7dd55f9  vmovaps [rsp+0xA0], xmm10
000078d2e7dd5602  vmovaps [rsp+0xB0], xmm11
000078d2e7dd560b  vmovaps [rsp+0xC0], xmm12
000078d2e7dd5614  vmovaps [rsp+0xD0], xmm14
000078d2e7dd561d  vmovaps [rsp+0xE0], xmm15
000078d2e7dd5626  sub rsp, 0x30
000078d2e7dd562a  movaps [rsp], xmm13
000078d2e7dd562f  movaps [rsp+0x10], xmm11
000078d2e7dd5635  movaps [rsp+0x20], xmm1
000078d2e7dd563a  lea rdi, [rsp]
000078d2e7dd563e  mov esi, 0x00
000078d2e7dd5643  mov rax, 0x5997D2DB1530
000078d2e7dd564d  call rax
000078d2e7dd564f  movaps xmm13, [rsp]
000078d2e7dd5654  add rsp, 0x30
000078d2e7dd5658  vmovaps xmm0, [rsp]
000078d2e7dd565d  vmovaps xmm1, [rsp+0x10]
000078d2e7dd5663  vmovaps xmm2, [rsp+0x20]
000078d2e7dd5669  vmovaps xmm3, [rsp+0x30]
000078d2e7dd566f  vmovaps xmm4, [rsp+0x40]
000078d2e7dd5675  vmovaps xmm5, [rsp+0x50]
000078d2e7dd567b  vmovaps xmm6, [rsp+0x60]
000078d2e7dd5681  vmovaps xmm7, [rsp+0x70]
000078d2e7dd5687  vmovaps xmm8, [rsp+0x80]
000078d2e7dd5690  vmovaps xmm9, [rsp+0x90]
000078d2e7dd5699  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd56a2  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd56ab  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd56b4  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd56bd  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd56c6  add rsp, 0xF0
000078d2e7dd56cd  pop r11
000078d2e7dd56cf  pop r10
000078d2e7dd56d1  pop r9
000078d2e7dd56d3  pop r8
000078d2e7dd56d5  pop rsi
000078d2e7dd56d6  pop rdi
000078d2e7dd56d7  pop rdx
000078d2e7dd56d8  pop rcx
000078d2e7dd56d9  pop rax
000078d2e7dd56da  add rsp, 0x08
000078d2e7dd56de  jmp 0x000078D2E7DD2E9D
000078d2e7dd56e3  call 0x000078D2E7BFF430
000078d2e7dd56e8  jmp 0x000078D2E7DD2EAA
000078d2e7dd56ed  sub rsp, 0x08
000078d2e7dd56f1  push rax
000078d2e7dd56f2  push rcx
000078d2e7dd56f3  push rdx
000078d2e7dd56f4  push rdi
000078d2e7dd56f5  push rsi
000078d2e7dd56f6  push r8
000078d2e7dd56f8  push r9
000078d2e7dd56fa  push r10
000078d2e7dd56fc  push r11
000078d2e7dd56fe  sub rsp, 0xF0
000078d2e7dd5705  vmovaps [rsp], xmm0
000078d2e7dd570a  vmovaps [rsp+0x10], xmm1
000078d2e7dd5710  vmovaps [rsp+0x20], xmm2
000078d2e7dd5716  vmovaps [rsp+0x30], xmm3
000078d2e7dd571c  vmovaps [rsp+0x40], xmm4
000078d2e7dd5722  vmovaps [rsp+0x50], xmm5
000078d2e7dd5728  vmovaps [rsp+0x60], xmm6
000078d2e7dd572e  vmovaps [rsp+0x70], xmm7
000078d2e7dd5734  vmovaps [rsp+0x80], xmm8
000078d2e7dd573d  vmovaps [rsp+0x90], xmm9
000078d2e7dd5746  vmovaps [rsp+0xA0], xmm10
000078d2e7dd574f  vmovaps [rsp+0xB0], xmm11
000078d2e7dd5758  vmovaps [rsp+0xC0], xmm12
000078d2e7dd5761  vmovaps [rsp+0xD0], xmm13
000078d2e7dd576a  vmovaps [rsp+0xE0], xmm14
000078d2e7dd5773  sub rsp, 0x30
000078d2e7dd5777  movaps [rsp], xmm15
000078d2e7dd577c  movaps [rsp+0x10], xmm11
000078d2e7dd5782  movaps [rsp+0x20], xmm1
000078d2e7dd5787  lea rdi, [rsp]
000078d2e7dd578b  mov esi, 0x00
000078d2e7dd5790  mov rax, 0x5997D2DB1530
000078d2e7dd579a  call rax
000078d2e7dd579c  movaps xmm15, [rsp]
000078d2e7dd57a1  add rsp, 0x30
000078d2e7dd57a5  vmovaps xmm0, [rsp]
000078d2e7dd57aa  vmovaps xmm1, [rsp+0x10]
000078d2e7dd57b0  vmovaps xmm2, [rsp+0x20]
000078d2e7dd57b6  vmovaps xmm3, [rsp+0x30]
000078d2e7dd57bc  vmovaps xmm4, [rsp+0x40]
000078d2e7dd57c2  vmovaps xmm5, [rsp+0x50]
000078d2e7dd57c8  vmovaps xmm6, [rsp+0x60]
000078d2e7dd57ce  vmovaps xmm7, [rsp+0x70]
000078d2e7dd57d4  vmovaps xmm8, [rsp+0x80]
000078d2e7dd57dd  vmovaps xmm9, [rsp+0x90]
000078d2e7dd57e6  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd57ef  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd57f8  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd5801  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd580a  vmovaps xmm14, [rsp+0xE0]
000078d2e7dd5813  add rsp, 0xF0
000078d2e7dd581a  pop r11
000078d2e7dd581c  pop r10
000078d2e7dd581e  pop r9
000078d2e7dd5820  pop r8
000078d2e7dd5822  pop rsi
000078d2e7dd5823  pop rdi
000078d2e7dd5824  pop rdx
000078d2e7dd5825  pop rcx
000078d2e7dd5826  pop rax
000078d2e7dd5827  add rsp, 0x08
000078d2e7dd582b  jmp 0x000078D2E7DD2EE3
000078d2e7dd5830  sub rsp, 0x08
000078d2e7dd5834  push rax
000078d2e7dd5835  push rcx
000078d2e7dd5836  push rdx
000078d2e7dd5837  push rdi
000078d2e7dd5838  push rsi
000078d2e7dd5839  push r8
000078d2e7dd583b  push r9
000078d2e7dd583d  push r10
000078d2e7dd583f  push r11
000078d2e7dd5841  sub rsp, 0xF0
000078d2e7dd5848  vmovaps [rsp], xmm0
000078d2e7dd584d  vmovaps [rsp+0x10], xmm1
000078d2e7dd5853  vmovaps [rsp+0x20], xmm2
000078d2e7dd5859  vmovaps [rsp+0x30], xmm3
000078d2e7dd585f  vmovaps [rsp+0x40], xmm4
000078d2e7dd5865  vmovaps [rsp+0x50], xmm5
000078d2e7dd586b  vmovaps [rsp+0x60], xmm6
000078d2e7dd5871  vmovaps [rsp+0x70], xmm7
000078d2e7dd5877  vmovaps [rsp+0x80], xmm8
000078d2e7dd5880  vmovaps [rsp+0x90], xmm9
000078d2e7dd5889  vmovaps [rsp+0xA0], xmm10
000078d2e7dd5892  vmovaps [rsp+0xB0], xmm12
000078d2e7dd589b  vmovaps [rsp+0xC0], xmm13
000078d2e7dd58a4  vmovaps [rsp+0xD0], xmm14
000078d2e7dd58ad  vmovaps [rsp+0xE0], xmm15
000078d2e7dd58b6  sub rsp, 0x30
000078d2e7dd58ba  movaps [rsp], xmm11
000078d2e7dd58bf  movaps [rsp+0x10], xmm6
000078d2e7dd58c4  movaps [rsp+0x20], xmm14
000078d2e7dd58ca  lea rdi, [rsp]
000078d2e7dd58ce  mov esi, 0x00
000078d2e7dd58d3  mov rax, 0x5997D2DB1530
000078d2e7dd58dd  call rax
000078d2e7dd58df  movaps xmm11, [rsp]
000078d2e7dd58e4  add rsp, 0x30
000078d2e7dd58e8  vmovaps xmm0, [rsp]
000078d2e7dd58ed  vmovaps xmm1, [rsp+0x10]
000078d2e7dd58f3  vmovaps xmm2, [rsp+0x20]
000078d2e7dd58f9  vmovaps xmm3, [rsp+0x30]
000078d2e7dd58ff  vmovaps xmm4, [rsp+0x40]
000078d2e7dd5905  vmovaps xmm5, [rsp+0x50]
000078d2e7dd590b  vmovaps xmm6, [rsp+0x60]
000078d2e7dd5911  vmovaps xmm7, [rsp+0x70]
000078d2e7dd5917  vmovaps xmm8, [rsp+0x80]
000078d2e7dd5920  vmovaps xmm9, [rsp+0x90]
000078d2e7dd5929  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd5932  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd593b  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd5944  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd594d  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd5956  add rsp, 0xF0
000078d2e7dd595d  pop r11
000078d2e7dd595f  pop r10
000078d2e7dd5961  pop r9
000078d2e7dd5963  pop r8
000078d2e7dd5965  pop rsi
000078d2e7dd5966  pop rdi
000078d2e7dd5967  pop rdx
000078d2e7dd5968  pop rcx
000078d2e7dd5969  pop rax
000078d2e7dd596a  add rsp, 0x08
000078d2e7dd596e  jmp 0x000078D2E7DD2F5B
000078d2e7dd5973  call 0x000078D2E7BFF430
000078d2e7dd5978  jmp 0x000078D2E7DD2F65
000078d2e7dd597d  sub rsp, 0x08
000078d2e7dd5981  push rax
000078d2e7dd5982  push rcx
000078d2e7dd5983  push rdx
000078d2e7dd5984  push rdi
000078d2e7dd5985  push rsi
000078d2e7dd5986  push r8
000078d2e7dd5988  push r9
000078d2e7dd598a  push r10
000078d2e7dd598c  push r11
000078d2e7dd598e  sub rsp, 0xF0
000078d2e7dd5995  vmovaps [rsp], xmm0
000078d2e7dd599a  vmovaps [rsp+0x10], xmm1
000078d2e7dd59a0  vmovaps [rsp+0x20], xmm2
000078d2e7dd59a6  vmovaps [rsp+0x30], xmm3
000078d2e7dd59ac  vmovaps [rsp+0x40], xmm4
000078d2e7dd59b2  vmovaps [rsp+0x50], xmm5
000078d2e7dd59b8  vmovaps [rsp+0x60], xmm6
000078d2e7dd59be  vmovaps [rsp+0x70], xmm7
000078d2e7dd59c4  vmovaps [rsp+0x80], xmm8
000078d2e7dd59cd  vmovaps [rsp+0x90], xmm9
000078d2e7dd59d6  vmovaps [rsp+0xA0], xmm10
000078d2e7dd59df  vmovaps [rsp+0xB0], xmm11
000078d2e7dd59e8  vmovaps [rsp+0xC0], xmm12
000078d2e7dd59f1  vmovaps [rsp+0xD0], xmm13
000078d2e7dd59fa  vmovaps [rsp+0xE0], xmm15
000078d2e7dd5a03  sub rsp, 0x30
000078d2e7dd5a07  movaps [rsp], xmm14
000078d2e7dd5a0c  movaps [rsp+0x10], xmm6
000078d2e7dd5a11  movaps [rsp+0x20], xmm2
000078d2e7dd5a16  lea rdi, [rsp]
000078d2e7dd5a1a  mov esi, 0x00
000078d2e7dd5a1f  mov rax, 0x5997D2DB1530
000078d2e7dd5a29  call rax
000078d2e7dd5a2b  movaps xmm14, [rsp]
000078d2e7dd5a30  add rsp, 0x30
000078d2e7dd5a34  vmovaps xmm0, [rsp]
000078d2e7dd5a39  vmovaps xmm1, [rsp+0x10]
000078d2e7dd5a3f  vmovaps xmm2, [rsp+0x20]
000078d2e7dd5a45  vmovaps xmm3, [rsp+0x30]
000078d2e7dd5a4b  vmovaps xmm4, [rsp+0x40]
000078d2e7dd5a51  vmovaps xmm5, [rsp+0x50]
000078d2e7dd5a57  vmovaps xmm6, [rsp+0x60]
000078d2e7dd5a5d  vmovaps xmm7, [rsp+0x70]
000078d2e7dd5a63  vmovaps xmm8, [rsp+0x80]
000078d2e7dd5a6c  vmovaps xmm9, [rsp+0x90]
000078d2e7dd5a75  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd5a7e  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd5a87  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd5a90  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd5a99  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd5aa2  add rsp, 0xF0
000078d2e7dd5aa9  pop r11
000078d2e7dd5aab  pop r10
000078d2e7dd5aad  pop r9
000078d2e7dd5aaf  pop r8
000078d2e7dd5ab1  pop rsi
000078d2e7dd5ab2  pop rdi
000078d2e7dd5ab3  pop rdx
000078d2e7dd5ab4  pop rcx
000078d2e7dd5ab5  pop rax
000078d2e7dd5ab6  add rsp, 0x08
000078d2e7dd5aba  jmp 0x000078D2E7DD2F99
000078d2e7dd5abf  sub rsp, 0x08
000078d2e7dd5ac3  push rax
000078d2e7dd5ac4  push rcx
000078d2e7dd5ac5  push rdx
000078d2e7dd5ac6  push rdi
000078d2e7dd5ac7  push rsi
000078d2e7dd5ac8  push r8
000078d2e7dd5aca  push r9
000078d2e7dd5acc  push r10
000078d2e7dd5ace  push r11
000078d2e7dd5ad0  sub rsp, 0xF0
000078d2e7dd5ad7  vmovaps [rsp], xmm0
000078d2e7dd5adc  vmovaps [rsp+0x10], xmm1
000078d2e7dd5ae2  vmovaps [rsp+0x20], xmm2
000078d2e7dd5ae8  vmovaps [rsp+0x30], xmm3
000078d2e7dd5aee  vmovaps [rsp+0x40], xmm4
000078d2e7dd5af4  vmovaps [rsp+0x50], xmm5
000078d2e7dd5afa  vmovaps [rsp+0x60], xmm7
000078d2e7dd5b00  vmovaps [rsp+0x70], xmm8
000078d2e7dd5b06  vmovaps [rsp+0x80], xmm9
000078d2e7dd5b0f  vmovaps [rsp+0x90], xmm10
000078d2e7dd5b18  vmovaps [rsp+0xA0], xmm11
000078d2e7dd5b21  vmovaps [rsp+0xB0], xmm12
000078d2e7dd5b2a  vmovaps [rsp+0xC0], xmm13
000078d2e7dd5b33  vmovaps [rsp+0xD0], xmm14
000078d2e7dd5b3c  vmovaps [rsp+0xE0], xmm15
000078d2e7dd5b45  sub rsp, 0x30
000078d2e7dd5b49  movaps [rsp], xmm6
000078d2e7dd5b4d  movaps [rsp+0x10], xmm5
000078d2e7dd5b52  movaps [rsp+0x20], xmm1
000078d2e7dd5b57  lea rdi, [rsp]
000078d2e7dd5b5b  mov esi, 0x00
000078d2e7dd5b60  mov rax, 0x5997D2DB1530
000078d2e7dd5b6a  call rax
000078d2e7dd5b6c  movaps xmm6, [rsp]
000078d2e7dd5b70  add rsp, 0x30
000078d2e7dd5b74  vmovaps xmm0, [rsp]
000078d2e7dd5b79  vmovaps xmm1, [rsp+0x10]
000078d2e7dd5b7f  vmovaps xmm2, [rsp+0x20]
000078d2e7dd5b85  vmovaps xmm3, [rsp+0x30]
000078d2e7dd5b8b  vmovaps xmm4, [rsp+0x40]
000078d2e7dd5b91  vmovaps xmm5, [rsp+0x50]
000078d2e7dd5b97  vmovaps xmm7, [rsp+0x60]
000078d2e7dd5b9d  vmovaps xmm8, [rsp+0x70]
000078d2e7dd5ba3  vmovaps xmm9, [rsp+0x80]
000078d2e7dd5bac  vmovaps xmm10, [rsp+0x90]
000078d2e7dd5bb5  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd5bbe  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd5bc7  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd5bd0  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd5bd9  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd5be2  add rsp, 0xF0
000078d2e7dd5be9  pop r11
000078d2e7dd5beb  pop r10
000078d2e7dd5bed  pop r9
000078d2e7dd5bef  pop r8
000078d2e7dd5bf1  pop rsi
000078d2e7dd5bf2  pop rdi
000078d2e7dd5bf3  pop rdx
000078d2e7dd5bf4  pop rcx
000078d2e7dd5bf5  pop rax
000078d2e7dd5bf6  add rsp, 0x08
000078d2e7dd5bfa  jmp 0x000078D2E7DD2FBF
000078d2e7dd5bff  sub rsp, 0x08
000078d2e7dd5c03  push rax
000078d2e7dd5c04  push rcx
000078d2e7dd5c05  push rdx
000078d2e7dd5c06  push rdi
000078d2e7dd5c07  push rsi
000078d2e7dd5c08  push r8
000078d2e7dd5c0a  push r9
000078d2e7dd5c0c  push r10
000078d2e7dd5c0e  push r11
000078d2e7dd5c10  sub rsp, 0xF0
000078d2e7dd5c17  vmovaps [rsp], xmm0
000078d2e7dd5c1c  vmovaps [rsp+0x10], xmm2
000078d2e7dd5c22  vmovaps [rsp+0x20], xmm3
000078d2e7dd5c28  vmovaps [rsp+0x30], xmm4
000078d2e7dd5c2e  vmovaps [rsp+0x40], xmm5
000078d2e7dd5c34  vmovaps [rsp+0x50], xmm6
000078d2e7dd5c3a  vmovaps [rsp+0x60], xmm7
000078d2e7dd5c40  vmovaps [rsp+0x70], xmm8
000078d2e7dd5c46  vmovaps [rsp+0x80], xmm9
000078d2e7dd5c4f  vmovaps [rsp+0x90], xmm10
000078d2e7dd5c58  vmovaps [rsp+0xA0], xmm11
000078d2e7dd5c61  vmovaps [rsp+0xB0], xmm12
000078d2e7dd5c6a  vmovaps [rsp+0xC0], xmm13
000078d2e7dd5c73  vmovaps [rsp+0xD0], xmm14
000078d2e7dd5c7c  vmovaps [rsp+0xE0], xmm15
000078d2e7dd5c85  sub rsp, 0x30
000078d2e7dd5c89  movaps [rsp], xmm1
000078d2e7dd5c8d  movaps [rsp+0x10], xmm5
000078d2e7dd5c92  movaps [rsp+0x20], xmm13
000078d2e7dd5c98  lea rdi, [rsp]
000078d2e7dd5c9c  mov esi, 0x00
000078d2e7dd5ca1  mov rax, 0x5997D2DB1530
000078d2e7dd5cab  call rax
000078d2e7dd5cad  movaps xmm1, [rsp]
000078d2e7dd5cb1  add rsp, 0x30
000078d2e7dd5cb5  vmovaps xmm0, [rsp]
000078d2e7dd5cba  vmovaps xmm2, [rsp+0x10]
000078d2e7dd5cc0  vmovaps xmm3, [rsp+0x20]
000078d2e7dd5cc6  vmovaps xmm4, [rsp+0x30]
000078d2e7dd5ccc  vmovaps xmm5, [rsp+0x40]
000078d2e7dd5cd2  vmovaps xmm6, [rsp+0x50]
000078d2e7dd5cd8  vmovaps xmm7, [rsp+0x60]
000078d2e7dd5cde  vmovaps xmm8, [rsp+0x70]
000078d2e7dd5ce4  vmovaps xmm9, [rsp+0x80]
000078d2e7dd5ced  vmovaps xmm10, [rsp+0x90]
000078d2e7dd5cf6  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd5cff  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd5d08  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd5d11  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd5d1a  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd5d23  add rsp, 0xF0
000078d2e7dd5d2a  pop r11
000078d2e7dd5d2c  pop r10
000078d2e7dd5d2e  pop r9
000078d2e7dd5d30  pop r8
000078d2e7dd5d32  pop rsi
000078d2e7dd5d33  pop rdi
000078d2e7dd5d34  pop rdx
000078d2e7dd5d35  pop rcx
000078d2e7dd5d36  pop rax
000078d2e7dd5d37  add rsp, 0x08
000078d2e7dd5d3b  jmp 0x000078D2E7DD2FDD
000078d2e7dd5d40  sub rsp, 0x08
000078d2e7dd5d44  push rax
000078d2e7dd5d45  push rcx
000078d2e7dd5d46  push rdx
000078d2e7dd5d47  push rdi
000078d2e7dd5d48  push rsi
000078d2e7dd5d49  push r8
000078d2e7dd5d4b  push r9
000078d2e7dd5d4d  push r10
000078d2e7dd5d4f  push r11
000078d2e7dd5d51  sub rsp, 0xF0
000078d2e7dd5d58  vmovaps [rsp], xmm0
000078d2e7dd5d5d  vmovaps [rsp+0x10], xmm1
000078d2e7dd5d63  vmovaps [rsp+0x20], xmm2
000078d2e7dd5d69  vmovaps [rsp+0x30], xmm3
000078d2e7dd5d6f  vmovaps [rsp+0x40], xmm4
000078d2e7dd5d75  vmovaps [rsp+0x50], xmm6
000078d2e7dd5d7b  vmovaps [rsp+0x60], xmm7
000078d2e7dd5d81  vmovaps [rsp+0x70], xmm8
000078d2e7dd5d87  vmovaps [rsp+0x80], xmm9
000078d2e7dd5d90  vmovaps [rsp+0x90], xmm10
000078d2e7dd5d99  vmovaps [rsp+0xA0], xmm11
000078d2e7dd5da2  vmovaps [rsp+0xB0], xmm12
000078d2e7dd5dab  vmovaps [rsp+0xC0], xmm13
000078d2e7dd5db4  vmovaps [rsp+0xD0], xmm14
000078d2e7dd5dbd  vmovaps [rsp+0xE0], xmm15
000078d2e7dd5dc6  sub rsp, 0x30
000078d2e7dd5dca  movaps [rsp], xmm5
000078d2e7dd5dce  movaps [rsp+0x10], xmm2
000078d2e7dd5dd3  movaps [rsp+0x20], xmm13
000078d2e7dd5dd9  lea rdi, [rsp]
000078d2e7dd5ddd  mov esi, 0x00
000078d2e7dd5de2  mov rax, 0x5997D2DB1530
000078d2e7dd5dec  call rax
000078d2e7dd5dee  movaps xmm5, [rsp]
000078d2e7dd5df2  add rsp, 0x30
000078d2e7dd5df6  vmovaps xmm0, [rsp]
000078d2e7dd5dfb  vmovaps xmm1, [rsp+0x10]
000078d2e7dd5e01  vmovaps xmm2, [rsp+0x20]
000078d2e7dd5e07  vmovaps xmm3, [rsp+0x30]
000078d2e7dd5e0d  vmovaps xmm4, [rsp+0x40]
000078d2e7dd5e13  vmovaps xmm6, [rsp+0x50]
000078d2e7dd5e19  vmovaps xmm7, [rsp+0x60]
000078d2e7dd5e1f  vmovaps xmm8, [rsp+0x70]
000078d2e7dd5e25  vmovaps xmm9, [rsp+0x80]
000078d2e7dd5e2e  vmovaps xmm10, [rsp+0x90]
000078d2e7dd5e37  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd5e40  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd5e49  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd5e52  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd5e5b  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd5e64  add rsp, 0xF0
000078d2e7dd5e6b  pop r11
000078d2e7dd5e6d  pop r10
000078d2e7dd5e6f  pop r9
000078d2e7dd5e71  pop r8
000078d2e7dd5e73  pop rsi
000078d2e7dd5e74  pop rdi
000078d2e7dd5e75  pop rdx
000078d2e7dd5e76  pop rcx
000078d2e7dd5e77  pop rax
000078d2e7dd5e78  add rsp, 0x08
000078d2e7dd5e7c  jmp 0x000078D2E7DD3013
000078d2e7dd5e81  sub rsp, 0x08
000078d2e7dd5e85  push rax
000078d2e7dd5e86  push rcx
000078d2e7dd5e87  push rdx
000078d2e7dd5e88  push rdi
000078d2e7dd5e89  push rsi
000078d2e7dd5e8a  push r8
000078d2e7dd5e8c  push r9
000078d2e7dd5e8e  push r10
000078d2e7dd5e90  push r11
000078d2e7dd5e92  sub rsp, 0xF0
000078d2e7dd5e99  vmovaps [rsp], xmm0
000078d2e7dd5e9e  vmovaps [rsp+0x10], xmm1
000078d2e7dd5ea4  vmovaps [rsp+0x20], xmm2
000078d2e7dd5eaa  vmovaps [rsp+0x30], xmm3
000078d2e7dd5eb0  vmovaps [rsp+0x40], xmm4
000078d2e7dd5eb6  vmovaps [rsp+0x50], xmm5
000078d2e7dd5ebc  vmovaps [rsp+0x60], xmm6
000078d2e7dd5ec2  vmovaps [rsp+0x70], xmm7
000078d2e7dd5ec8  vmovaps [rsp+0x80], xmm8
000078d2e7dd5ed1  vmovaps [rsp+0x90], xmm9
000078d2e7dd5eda  vmovaps [rsp+0xA0], xmm10
000078d2e7dd5ee3  vmovaps [rsp+0xB0], xmm11
000078d2e7dd5eec  vmovaps [rsp+0xC0], xmm12
000078d2e7dd5ef5  vmovaps [rsp+0xD0], xmm14
000078d2e7dd5efe  vmovaps [rsp+0xE0], xmm15
000078d2e7dd5f07  sub rsp, 0x30
000078d2e7dd5f0b  movaps [rsp], xmm13
000078d2e7dd5f10  movaps [rsp+0x10], xmm10
000078d2e7dd5f16  movaps [rsp+0x20], xmm1
000078d2e7dd5f1b  lea rdi, [rsp]
000078d2e7dd5f1f  mov esi, 0x00
000078d2e7dd5f24  mov rax, 0x5997D2DB1530
000078d2e7dd5f2e  call rax
000078d2e7dd5f30  movaps xmm13, [rsp]
000078d2e7dd5f35  add rsp, 0x30
000078d2e7dd5f39  vmovaps xmm0, [rsp]
000078d2e7dd5f3e  vmovaps xmm1, [rsp+0x10]
000078d2e7dd5f44  vmovaps xmm2, [rsp+0x20]
000078d2e7dd5f4a  vmovaps xmm3, [rsp+0x30]
000078d2e7dd5f50  vmovaps xmm4, [rsp+0x40]
000078d2e7dd5f56  vmovaps xmm5, [rsp+0x50]
000078d2e7dd5f5c  vmovaps xmm6, [rsp+0x60]
000078d2e7dd5f62  vmovaps xmm7, [rsp+0x70]
000078d2e7dd5f68  vmovaps xmm8, [rsp+0x80]
000078d2e7dd5f71  vmovaps xmm9, [rsp+0x90]
000078d2e7dd5f7a  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd5f83  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd5f8c  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd5f95  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd5f9e  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd5fa7  add rsp, 0xF0
000078d2e7dd5fae  pop r11
000078d2e7dd5fb0  pop r10
000078d2e7dd5fb2  pop r9
000078d2e7dd5fb4  pop r8
000078d2e7dd5fb6  pop rsi
000078d2e7dd5fb7  pop rdi
000078d2e7dd5fb8  pop rdx
000078d2e7dd5fb9  pop rcx
000078d2e7dd5fba  pop rax
000078d2e7dd5fbb  add rsp, 0x08
000078d2e7dd5fbf  jmp 0x000078D2E7DD303C
000078d2e7dd5fc4  sub rsp, 0x08
000078d2e7dd5fc8  push rax
000078d2e7dd5fc9  push rcx
000078d2e7dd5fca  push rdx
000078d2e7dd5fcb  push rdi
000078d2e7dd5fcc  push rsi
000078d2e7dd5fcd  push r8
000078d2e7dd5fcf  push r9
000078d2e7dd5fd1  push r10
000078d2e7dd5fd3  push r11
000078d2e7dd5fd5  sub rsp, 0xF0
000078d2e7dd5fdc  vmovaps [rsp], xmm0
000078d2e7dd5fe1  vmovaps [rsp+0x10], xmm2
000078d2e7dd5fe7  vmovaps [rsp+0x20], xmm3
000078d2e7dd5fed  vmovaps [rsp+0x30], xmm4
000078d2e7dd5ff3  vmovaps [rsp+0x40], xmm5
000078d2e7dd5ff9  vmovaps [rsp+0x50], xmm6
000078d2e7dd5fff  vmovaps [rsp+0x60], xmm7
000078d2e7dd6005  vmovaps [rsp+0x70], xmm8
000078d2e7dd600b  vmovaps [rsp+0x80], xmm9
000078d2e7dd6014  vmovaps [rsp+0x90], xmm10
000078d2e7dd601d  vmovaps [rsp+0xA0], xmm11
000078d2e7dd6026  vmovaps [rsp+0xB0], xmm12
000078d2e7dd602f  vmovaps [rsp+0xC0], xmm13
000078d2e7dd6038  vmovaps [rsp+0xD0], xmm14
000078d2e7dd6041  vmovaps [rsp+0xE0], xmm15
000078d2e7dd604a  sub rsp, 0x30
000078d2e7dd604e  movaps [rsp], xmm1
000078d2e7dd6052  movaps [rsp+0x10], xmm15
000078d2e7dd6058  movaps [rsp+0x20], xmm10
000078d2e7dd605e  lea rdi, [rsp]
000078d2e7dd6062  mov esi, 0x00
000078d2e7dd6067  mov rax, 0x5997D2DB1530
000078d2e7dd6071  call rax
000078d2e7dd6073  movaps xmm1, [rsp]
000078d2e7dd6077  add rsp, 0x30
000078d2e7dd607b  vmovaps xmm0, [rsp]
000078d2e7dd6080  vmovaps xmm2, [rsp+0x10]
000078d2e7dd6086  vmovaps xmm3, [rsp+0x20]
000078d2e7dd608c  vmovaps xmm4, [rsp+0x30]
000078d2e7dd6092  vmovaps xmm5, [rsp+0x40]
000078d2e7dd6098  vmovaps xmm6, [rsp+0x50]
000078d2e7dd609e  vmovaps xmm7, [rsp+0x60]
000078d2e7dd60a4  vmovaps xmm8, [rsp+0x70]
000078d2e7dd60aa  vmovaps xmm9, [rsp+0x80]
000078d2e7dd60b3  vmovaps xmm10, [rsp+0x90]
000078d2e7dd60bc  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd60c5  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd60ce  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd60d7  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd60e0  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd60e9  add rsp, 0xF0
000078d2e7dd60f0  pop r11
000078d2e7dd60f2  pop r10
000078d2e7dd60f4  pop r9
000078d2e7dd60f6  pop r8
000078d2e7dd60f8  pop rsi
000078d2e7dd60f9  pop rdi
000078d2e7dd60fa  pop rdx
000078d2e7dd60fb  pop rcx
000078d2e7dd60fc  pop rax
000078d2e7dd60fd  add rsp, 0x08
000078d2e7dd6101  jmp 0x000078D2E7DD305B
000078d2e7dd6106  sub rsp, 0x08
000078d2e7dd610a  push rax
000078d2e7dd610b  push rcx
000078d2e7dd610c  push rdx
000078d2e7dd610d  push rdi
000078d2e7dd610e  push rsi
000078d2e7dd610f  push r8
000078d2e7dd6111  push r9
000078d2e7dd6113  push r10
000078d2e7dd6115  push r11
000078d2e7dd6117  sub rsp, 0xF0
000078d2e7dd611e  vmovaps [rsp], xmm0
000078d2e7dd6123  vmovaps [rsp+0x10], xmm1
000078d2e7dd6129  vmovaps [rsp+0x20], xmm2
000078d2e7dd612f  vmovaps [rsp+0x30], xmm3
000078d2e7dd6135  vmovaps [rsp+0x40], xmm4
000078d2e7dd613b  vmovaps [rsp+0x50], xmm5
000078d2e7dd6141  vmovaps [rsp+0x60], xmm6
000078d2e7dd6147  vmovaps [rsp+0x70], xmm7
000078d2e7dd614d  vmovaps [rsp+0x80], xmm8
000078d2e7dd6156  vmovaps [rsp+0x90], xmm9
000078d2e7dd615f  vmovaps [rsp+0xA0], xmm10
000078d2e7dd6168  vmovaps [rsp+0xB0], xmm11
000078d2e7dd6171  vmovaps [rsp+0xC0], xmm12
000078d2e7dd617a  vmovaps [rsp+0xD0], xmm13
000078d2e7dd6183  vmovaps [rsp+0xE0], xmm14
000078d2e7dd618c  sub rsp, 0x30
000078d2e7dd6190  movaps [rsp], xmm15
000078d2e7dd6195  movaps [rsp+0x10], xmm10
000078d2e7dd619b  movaps [rsp+0x20], xmm11
000078d2e7dd61a1  lea rdi, [rsp]
000078d2e7dd61a5  mov esi, 0x00
000078d2e7dd61aa  mov rax, 0x5997D2DB1530
000078d2e7dd61b4  call rax
000078d2e7dd61b6  movaps xmm15, [rsp]
000078d2e7dd61bb  add rsp, 0x30
000078d2e7dd61bf  vmovaps xmm0, [rsp]
000078d2e7dd61c4  vmovaps xmm1, [rsp+0x10]
000078d2e7dd61ca  vmovaps xmm2, [rsp+0x20]
000078d2e7dd61d0  vmovaps xmm3, [rsp+0x30]
000078d2e7dd61d6  vmovaps xmm4, [rsp+0x40]
000078d2e7dd61dc  vmovaps xmm5, [rsp+0x50]
000078d2e7dd61e2  vmovaps xmm6, [rsp+0x60]
000078d2e7dd61e8  vmovaps xmm7, [rsp+0x70]
000078d2e7dd61ee  vmovaps xmm8, [rsp+0x80]
000078d2e7dd61f7  vmovaps xmm9, [rsp+0x90]
000078d2e7dd6200  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd6209  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd6212  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd621b  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd6224  vmovaps xmm14, [rsp+0xE0]
000078d2e7dd622d  add rsp, 0xF0
000078d2e7dd6234  pop r11
000078d2e7dd6236  pop r10
000078d2e7dd6238  pop r9
000078d2e7dd623a  pop r8
000078d2e7dd623c  pop rsi
000078d2e7dd623d  pop rdi
000078d2e7dd623e  pop rdx
000078d2e7dd623f  pop rcx
000078d2e7dd6240  pop rax
000078d2e7dd6241  add rsp, 0x08
000078d2e7dd6245  jmp 0x000078D2E7DD307E
000078d2e7dd624a  sub rsp, 0x08
000078d2e7dd624e  push rax
000078d2e7dd624f  push rcx
000078d2e7dd6250  push rdx
000078d2e7dd6251  push rdi
000078d2e7dd6252  push rsi
000078d2e7dd6253  push r8
000078d2e7dd6255  push r9
000078d2e7dd6257  push r10
000078d2e7dd6259  push r11
000078d2e7dd625b  sub rsp, 0xF0
000078d2e7dd6262  vmovaps [rsp], xmm0
000078d2e7dd6267  vmovaps [rsp+0x10], xmm1
000078d2e7dd626d  vmovaps [rsp+0x20], xmm2
000078d2e7dd6273  vmovaps [rsp+0x30], xmm3
000078d2e7dd6279  vmovaps [rsp+0x40], xmm4
000078d2e7dd627f  vmovaps [rsp+0x50], xmm5
000078d2e7dd6285  vmovaps [rsp+0x60], xmm6
000078d2e7dd628b  vmovaps [rsp+0x70], xmm7
000078d2e7dd6291  vmovaps [rsp+0x80], xmm8
000078d2e7dd629a  vmovaps [rsp+0x90], xmm9
000078d2e7dd62a3  vmovaps [rsp+0xA0], xmm11
000078d2e7dd62ac  vmovaps [rsp+0xB0], xmm12
000078d2e7dd62b5  vmovaps [rsp+0xC0], xmm13
000078d2e7dd62be  vmovaps [rsp+0xD0], xmm14
000078d2e7dd62c7  vmovaps [rsp+0xE0], xmm15
000078d2e7dd62d0  sub rsp, 0x30
000078d2e7dd62d4  movaps [rsp], xmm10
000078d2e7dd62d9  movaps [rsp+0x10], xmm2
000078d2e7dd62de  movaps [rsp+0x20], xmm11
000078d2e7dd62e4  lea rdi, [rsp]
000078d2e7dd62e8  mov esi, 0x00
000078d2e7dd62ed  mov rax, 0x5997D2DB1530
000078d2e7dd62f7  call rax
000078d2e7dd62f9  movaps xmm10, [rsp]
000078d2e7dd62fe  add rsp, 0x30
000078d2e7dd6302  vmovaps xmm0, [rsp]
000078d2e7dd6307  vmovaps xmm1, [rsp+0x10]
000078d2e7dd630d  vmovaps xmm2, [rsp+0x20]
000078d2e7dd6313  vmovaps xmm3, [rsp+0x30]
000078d2e7dd6319  vmovaps xmm4, [rsp+0x40]
000078d2e7dd631f  vmovaps xmm5, [rsp+0x50]
000078d2e7dd6325  vmovaps xmm6, [rsp+0x60]
000078d2e7dd632b  vmovaps xmm7, [rsp+0x70]
000078d2e7dd6331  vmovaps xmm8, [rsp+0x80]
000078d2e7dd633a  vmovaps xmm9, [rsp+0x90]
000078d2e7dd6343  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd634c  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd6355  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd635e  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd6367  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd6370  add rsp, 0xF0
000078d2e7dd6377  pop r11
000078d2e7dd6379  pop r10
000078d2e7dd637b  pop r9
000078d2e7dd637d  pop r8
000078d2e7dd637f  pop rsi
000078d2e7dd6380  pop rdi
000078d2e7dd6381  pop rdx
000078d2e7dd6382  pop rcx
000078d2e7dd6383  pop rax
000078d2e7dd6384  add rsp, 0x08
000078d2e7dd6388  jmp 0x000078D2E7DD30B6
000078d2e7dd638d  sub rsp, 0x08
000078d2e7dd6391  push rax
000078d2e7dd6392  push rcx
000078d2e7dd6393  push rdx
000078d2e7dd6394  push rdi
000078d2e7dd6395  push rsi
000078d2e7dd6396  push r8
000078d2e7dd6398  push r9
000078d2e7dd639a  push r10
000078d2e7dd639c  push r11
000078d2e7dd639e  sub rsp, 0xF0
000078d2e7dd63a5  vmovaps [rsp], xmm0
000078d2e7dd63aa  vmovaps [rsp+0x10], xmm1
000078d2e7dd63b0  vmovaps [rsp+0x20], xmm2
000078d2e7dd63b6  vmovaps [rsp+0x30], xmm3
000078d2e7dd63bc  vmovaps [rsp+0x40], xmm4
000078d2e7dd63c2  vmovaps [rsp+0x50], xmm5
000078d2e7dd63c8  vmovaps [rsp+0x60], xmm6
000078d2e7dd63ce  vmovaps [rsp+0x70], xmm7
000078d2e7dd63d4  vmovaps [rsp+0x80], xmm8
000078d2e7dd63dd  vmovaps [rsp+0x90], xmm9
000078d2e7dd63e6  vmovaps [rsp+0xA0], xmm10
000078d2e7dd63ef  vmovaps [rsp+0xB0], xmm12
000078d2e7dd63f8  vmovaps [rsp+0xC0], xmm13
000078d2e7dd6401  vmovaps [rsp+0xD0], xmm14
000078d2e7dd640a  vmovaps [rsp+0xE0], xmm15
000078d2e7dd6413  sub rsp, 0x30
000078d2e7dd6417  movaps [rsp], xmm11
000078d2e7dd641c  movaps [rsp+0x10], xmm2
000078d2e7dd6421  movaps [rsp+0x20], xmm1
000078d2e7dd6426  lea rdi, [rsp]
000078d2e7dd642a  mov esi, 0x00
000078d2e7dd642f  mov rax, 0x5997D2DB1530
000078d2e7dd6439  call rax
000078d2e7dd643b  movaps xmm11, [rsp]
000078d2e7dd6440  add rsp, 0x30
000078d2e7dd6444  vmovaps xmm0, [rsp]
000078d2e7dd6449  vmovaps xmm1, [rsp+0x10]
000078d2e7dd644f  vmovaps xmm2, [rsp+0x20]
000078d2e7dd6455  vmovaps xmm3, [rsp+0x30]
000078d2e7dd645b  vmovaps xmm4, [rsp+0x40]
000078d2e7dd6461  vmovaps xmm5, [rsp+0x50]
000078d2e7dd6467  vmovaps xmm6, [rsp+0x60]
000078d2e7dd646d  vmovaps xmm7, [rsp+0x70]
000078d2e7dd6473  vmovaps xmm8, [rsp+0x80]
000078d2e7dd647c  vmovaps xmm9, [rsp+0x90]
000078d2e7dd6485  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd648e  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd6497  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd64a0  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd64a9  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd64b2  add rsp, 0xF0
000078d2e7dd64b9  pop r11
000078d2e7dd64bb  pop r10
000078d2e7dd64bd  pop r9
000078d2e7dd64bf  pop r8
000078d2e7dd64c1  pop rsi
000078d2e7dd64c2  pop rdi
000078d2e7dd64c3  pop rdx
000078d2e7dd64c4  pop rcx
000078d2e7dd64c5  pop rax
000078d2e7dd64c6  add rsp, 0x08
000078d2e7dd64ca  jmp 0x000078D2E7DD30F2
000078d2e7dd64cf  sub rsp, 0x08
000078d2e7dd64d3  push rax
000078d2e7dd64d4  push rcx
000078d2e7dd64d5  push rdx
000078d2e7dd64d6  push rdi
000078d2e7dd64d7  push rsi
000078d2e7dd64d8  push r8
000078d2e7dd64da  push r9
000078d2e7dd64dc  push r10
000078d2e7dd64de  push r11
000078d2e7dd64e0  sub rsp, 0xF0
000078d2e7dd64e7  vmovaps [rsp], xmm0
000078d2e7dd64ec  vmovaps [rsp+0x10], xmm2
000078d2e7dd64f2  vmovaps [rsp+0x20], xmm3
000078d2e7dd64f8  vmovaps [rsp+0x30], xmm4
000078d2e7dd64fe  vmovaps [rsp+0x40], xmm5
000078d2e7dd6504  vmovaps [rsp+0x50], xmm6
000078d2e7dd650a  vmovaps [rsp+0x60], xmm7
000078d2e7dd6510  vmovaps [rsp+0x70], xmm8
000078d2e7dd6516  vmovaps [rsp+0x80], xmm9
000078d2e7dd651f  vmovaps [rsp+0x90], xmm10
000078d2e7dd6528  vmovaps [rsp+0xA0], xmm11
000078d2e7dd6531  vmovaps [rsp+0xB0], xmm12
000078d2e7dd653a  vmovaps [rsp+0xC0], xmm13
000078d2e7dd6543  vmovaps [rsp+0xD0], xmm14
000078d2e7dd654c  vmovaps [rsp+0xE0], xmm15
000078d2e7dd6555  sub rsp, 0x30
000078d2e7dd6559  movaps [rsp], xmm1
000078d2e7dd655d  movaps [rsp+0x10], xmm14
000078d2e7dd6563  movaps [rsp+0x20], xmm6
000078d2e7dd6568  lea rdi, [rsp]
000078d2e7dd656c  mov esi, 0x00
000078d2e7dd6571  mov rax, 0x5997D2DB1530
000078d2e7dd657b  call rax
000078d2e7dd657d  movaps xmm1, [rsp]
000078d2e7dd6581  add rsp, 0x30
000078d2e7dd6585  vmovaps xmm0, [rsp]
000078d2e7dd658a  vmovaps xmm2, [rsp+0x10]
000078d2e7dd6590  vmovaps xmm3, [rsp+0x20]
000078d2e7dd6596  vmovaps xmm4, [rsp+0x30]
000078d2e7dd659c  vmovaps xmm5, [rsp+0x40]
000078d2e7dd65a2  vmovaps xmm6, [rsp+0x50]
000078d2e7dd65a8  vmovaps xmm7, [rsp+0x60]
000078d2e7dd65ae  vmovaps xmm8, [rsp+0x70]
000078d2e7dd65b4  vmovaps xmm9, [rsp+0x80]
000078d2e7dd65bd  vmovaps xmm10, [rsp+0x90]
000078d2e7dd65c6  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd65cf  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd65d8  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd65e1  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd65ea  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd65f3  add rsp, 0xF0
000078d2e7dd65fa  pop r11
000078d2e7dd65fc  pop r10
000078d2e7dd65fe  pop r9
000078d2e7dd6600  pop r8
000078d2e7dd6602  pop rsi
000078d2e7dd6603  pop rdi
000078d2e7dd6604  pop rdx
000078d2e7dd6605  pop rcx
000078d2e7dd6606  pop rax
000078d2e7dd6607  add rsp, 0x08
000078d2e7dd660b  jmp 0x000078D2E7DD310B
000078d2e7dd6610  sub rsp, 0x08
000078d2e7dd6614  push rax
000078d2e7dd6615  push rcx
000078d2e7dd6616  push rdx
000078d2e7dd6617  push rdi
000078d2e7dd6618  push rsi
000078d2e7dd6619  push r8
000078d2e7dd661b  push r9
000078d2e7dd661d  push r10
000078d2e7dd661f  push r11
000078d2e7dd6621  sub rsp, 0xF0
000078d2e7dd6628  vmovaps [rsp], xmm0
000078d2e7dd662d  vmovaps [rsp+0x10], xmm1
000078d2e7dd6633  vmovaps [rsp+0x20], xmm2
000078d2e7dd6639  vmovaps [rsp+0x30], xmm3
000078d2e7dd663f  vmovaps [rsp+0x40], xmm4
000078d2e7dd6645  vmovaps [rsp+0x50], xmm5
000078d2e7dd664b  vmovaps [rsp+0x60], xmm6
000078d2e7dd6651  vmovaps [rsp+0x70], xmm7
000078d2e7dd6657  vmovaps [rsp+0x80], xmm8
000078d2e7dd6660  vmovaps [rsp+0x90], xmm9
000078d2e7dd6669  vmovaps [rsp+0xA0], xmm10
000078d2e7dd6672  vmovaps [rsp+0xB0], xmm11
000078d2e7dd667b  vmovaps [rsp+0xC0], xmm12
000078d2e7dd6684  vmovaps [rsp+0xD0], xmm13
000078d2e7dd668d  vmovaps [rsp+0xE0], xmm14
000078d2e7dd6696  sub rsp, 0x30
000078d2e7dd669a  movaps [rsp], xmm15
000078d2e7dd669f  movaps [rsp+0x10], xmm14
000078d2e7dd66a5  movaps [rsp+0x20], xmm5
000078d2e7dd66aa  lea rdi, [rsp]
000078d2e7dd66ae  mov esi, 0x00
000078d2e7dd66b3  mov rax, 0x5997D2DB1530
000078d2e7dd66bd  call rax
000078d2e7dd66bf  movaps xmm15, [rsp]
000078d2e7dd66c4  add rsp, 0x30
000078d2e7dd66c8  vmovaps xmm0, [rsp]
000078d2e7dd66cd  vmovaps xmm1, [rsp+0x10]
000078d2e7dd66d3  vmovaps xmm2, [rsp+0x20]
000078d2e7dd66d9  vmovaps xmm3, [rsp+0x30]
000078d2e7dd66df  vmovaps xmm4, [rsp+0x40]
000078d2e7dd66e5  vmovaps xmm5, [rsp+0x50]
000078d2e7dd66eb  vmovaps xmm6, [rsp+0x60]
000078d2e7dd66f1  vmovaps xmm7, [rsp+0x70]
000078d2e7dd66f7  vmovaps xmm8, [rsp+0x80]
000078d2e7dd6700  vmovaps xmm9, [rsp+0x90]
000078d2e7dd6709  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd6712  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd671b  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd6724  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd672d  vmovaps xmm14, [rsp+0xE0]
000078d2e7dd6736  add rsp, 0xF0
000078d2e7dd673d  pop r11
000078d2e7dd673f  pop r10
000078d2e7dd6741  pop r9
000078d2e7dd6743  pop r8
000078d2e7dd6745  pop rsi
000078d2e7dd6746  pop rdi
000078d2e7dd6747  pop rdx
000078d2e7dd6748  pop rcx
000078d2e7dd6749  pop rax
000078d2e7dd674a  add rsp, 0x08
000078d2e7dd674e  jmp 0x000078D2E7DD312B
000078d2e7dd6753  sub rsp, 0x08
000078d2e7dd6757  push rax
000078d2e7dd6758  push rcx
000078d2e7dd6759  push rdx
000078d2e7dd675a  push rdi
000078d2e7dd675b  push rsi
000078d2e7dd675c  push r8
000078d2e7dd675e  push r9
000078d2e7dd6760  push r10
000078d2e7dd6762  push r11
000078d2e7dd6764  sub rsp, 0xF0
000078d2e7dd676b  vmovaps [rsp], xmm0
000078d2e7dd6770  vmovaps [rsp+0x10], xmm1
000078d2e7dd6776  vmovaps [rsp+0x20], xmm2
000078d2e7dd677c  vmovaps [rsp+0x30], xmm3
000078d2e7dd6782  vmovaps [rsp+0x40], xmm4
000078d2e7dd6788  vmovaps [rsp+0x50], xmm5
000078d2e7dd678e  vmovaps [rsp+0x60], xmm7
000078d2e7dd6794  vmovaps [rsp+0x70], xmm8
000078d2e7dd679a  vmovaps [rsp+0x80], xmm9
000078d2e7dd67a3  vmovaps [rsp+0x90], xmm10
000078d2e7dd67ac  vmovaps [rsp+0xA0], xmm11
000078d2e7dd67b5  vmovaps [rsp+0xB0], xmm12
000078d2e7dd67be  vmovaps [rsp+0xC0], xmm13
000078d2e7dd67c7  vmovaps [rsp+0xD0], xmm14
000078d2e7dd67d0  vmovaps [rsp+0xE0], xmm15
000078d2e7dd67d9  sub rsp, 0x30
000078d2e7dd67dd  movaps [rsp], xmm6
000078d2e7dd67e1  movaps [rsp+0x10], xmm9
000078d2e7dd67e7  movaps [rsp+0x20], xmm14
000078d2e7dd67ed  lea rdi, [rsp]
000078d2e7dd67f1  mov esi, 0x00
000078d2e7dd67f6  mov rax, 0x5997D2DB1530
000078d2e7dd6800  call rax
000078d2e7dd6802  movaps xmm6, [rsp]
000078d2e7dd6806  add rsp, 0x30
000078d2e7dd680a  vmovaps xmm0, [rsp]
000078d2e7dd680f  vmovaps xmm1, [rsp+0x10]
000078d2e7dd6815  vmovaps xmm2, [rsp+0x20]
000078d2e7dd681b  vmovaps xmm3, [rsp+0x30]
000078d2e7dd6821  vmovaps xmm4, [rsp+0x40]
000078d2e7dd6827  vmovaps xmm5, [rsp+0x50]
000078d2e7dd682d  vmovaps xmm7, [rsp+0x60]
000078d2e7dd6833  vmovaps xmm8, [rsp+0x70]
000078d2e7dd6839  vmovaps xmm9, [rsp+0x80]
000078d2e7dd6842  vmovaps xmm10, [rsp+0x90]
000078d2e7dd684b  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd6854  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd685d  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd6866  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd686f  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd6878  add rsp, 0xF0
000078d2e7dd687f  pop r11
000078d2e7dd6881  pop r10
000078d2e7dd6883  pop r9
000078d2e7dd6885  pop r8
000078d2e7dd6887  pop rsi
000078d2e7dd6888  pop rdi
000078d2e7dd6889  pop rdx
000078d2e7dd688a  pop rcx
000078d2e7dd688b  pop rax
000078d2e7dd688c  add rsp, 0x08
000078d2e7dd6890  jmp 0x000078D2E7DD3153
000078d2e7dd6895  sub rsp, 0x08
000078d2e7dd6899  push rax
000078d2e7dd689a  push rcx
000078d2e7dd689b  push rdx
000078d2e7dd689c  push rdi
000078d2e7dd689d  push rsi
000078d2e7dd689e  push r8
000078d2e7dd68a0  push r9
000078d2e7dd68a2  push r10
000078d2e7dd68a4  push r11
000078d2e7dd68a6  sub rsp, 0xF0
000078d2e7dd68ad  vmovaps [rsp], xmm0
000078d2e7dd68b2  vmovaps [rsp+0x10], xmm1
000078d2e7dd68b8  vmovaps [rsp+0x20], xmm2
000078d2e7dd68be  vmovaps [rsp+0x30], xmm3
000078d2e7dd68c4  vmovaps [rsp+0x40], xmm4
000078d2e7dd68ca  vmovaps [rsp+0x50], xmm5
000078d2e7dd68d0  vmovaps [rsp+0x60], xmm6
000078d2e7dd68d6  vmovaps [rsp+0x70], xmm7
000078d2e7dd68dc  vmovaps [rsp+0x80], xmm8
000078d2e7dd68e5  vmovaps [rsp+0x90], xmm9
000078d2e7dd68ee  vmovaps [rsp+0xA0], xmm10
000078d2e7dd68f7  vmovaps [rsp+0xB0], xmm11
000078d2e7dd6900  vmovaps [rsp+0xC0], xmm12
000078d2e7dd6909  vmovaps [rsp+0xD0], xmm13
000078d2e7dd6912  vmovaps [rsp+0xE0], xmm15
000078d2e7dd691b  sub rsp, 0x30
000078d2e7dd691f  movaps [rsp], xmm14
000078d2e7dd6924  movaps [rsp+0x10], xmm9
000078d2e7dd692a  movaps [rsp+0x20], xmm13
000078d2e7dd6930  lea rdi, [rsp]
000078d2e7dd6934  mov esi, 0x00
000078d2e7dd6939  mov rax, 0x5997D2DB1530
000078d2e7dd6943  call rax
000078d2e7dd6945  movaps xmm14, [rsp]
000078d2e7dd694a  add rsp, 0x30
000078d2e7dd694e  vmovaps xmm0, [rsp]
000078d2e7dd6953  vmovaps xmm1, [rsp+0x10]
000078d2e7dd6959  vmovaps xmm2, [rsp+0x20]
000078d2e7dd695f  vmovaps xmm3, [rsp+0x30]
000078d2e7dd6965  vmovaps xmm4, [rsp+0x40]
000078d2e7dd696b  vmovaps xmm5, [rsp+0x50]
000078d2e7dd6971  vmovaps xmm6, [rsp+0x60]
000078d2e7dd6977  vmovaps xmm7, [rsp+0x70]
000078d2e7dd697d  vmovaps xmm8, [rsp+0x80]
000078d2e7dd6986  vmovaps xmm9, [rsp+0x90]
000078d2e7dd698f  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd6998  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd69a1  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd69aa  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd69b3  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd69bc  add rsp, 0xF0
000078d2e7dd69c3  pop r11
000078d2e7dd69c5  pop r10
000078d2e7dd69c7  pop r9
000078d2e7dd69c9  pop r8
000078d2e7dd69cb  pop rsi
000078d2e7dd69cc  pop rdi
000078d2e7dd69cd  pop rdx
000078d2e7dd69ce  pop rcx
000078d2e7dd69cf  pop rax
000078d2e7dd69d0  add rsp, 0x08
000078d2e7dd69d4  jmp 0x000078D2E7DD3176
000078d2e7dd69d9  sub rsp, 0x08
000078d2e7dd69dd  push rax
000078d2e7dd69de  push rcx
000078d2e7dd69df  push rdx
000078d2e7dd69e0  push rdi
000078d2e7dd69e1  push rsi
000078d2e7dd69e2  push r8
000078d2e7dd69e4  push r9
000078d2e7dd69e6  push r10
000078d2e7dd69e8  push r11
000078d2e7dd69ea  sub rsp, 0xF0
000078d2e7dd69f1  vmovaps [rsp], xmm0
000078d2e7dd69f6  vmovaps [rsp+0x10], xmm1
000078d2e7dd69fc  vmovaps [rsp+0x20], xmm2
000078d2e7dd6a02  vmovaps [rsp+0x30], xmm3
000078d2e7dd6a08  vmovaps [rsp+0x40], xmm4
000078d2e7dd6a0e  vmovaps [rsp+0x50], xmm5
000078d2e7dd6a14  vmovaps [rsp+0x60], xmm6
000078d2e7dd6a1a  vmovaps [rsp+0x70], xmm7
000078d2e7dd6a20  vmovaps [rsp+0x80], xmm8
000078d2e7dd6a29  vmovaps [rsp+0x90], xmm9
000078d2e7dd6a32  vmovaps [rsp+0xA0], xmm10
000078d2e7dd6a3b  vmovaps [rsp+0xB0], xmm11
000078d2e7dd6a44  vmovaps [rsp+0xC0], xmm12
000078d2e7dd6a4d  vmovaps [rsp+0xD0], xmm14
000078d2e7dd6a56  vmovaps [rsp+0xE0], xmm15
000078d2e7dd6a5f  sub rsp, 0x30
000078d2e7dd6a63  movaps [rsp], xmm13
000078d2e7dd6a68  movaps [rsp+0x10], xmm9
000078d2e7dd6a6e  movaps [rsp+0x20], xmm10
000078d2e7dd6a74  lea rdi, [rsp]
000078d2e7dd6a78  mov esi, 0x00
000078d2e7dd6a7d  mov rax, 0x5997D2DB1530
000078d2e7dd6a87  call rax
000078d2e7dd6a89  movaps xmm13, [rsp]
000078d2e7dd6a8e  add rsp, 0x30
000078d2e7dd6a92  vmovaps xmm0, [rsp]
000078d2e7dd6a97  vmovaps xmm1, [rsp+0x10]
000078d2e7dd6a9d  vmovaps xmm2, [rsp+0x20]
000078d2e7dd6aa3  vmovaps xmm3, [rsp+0x30]
000078d2e7dd6aa9  vmovaps xmm4, [rsp+0x40]
000078d2e7dd6aaf  vmovaps xmm5, [rsp+0x50]
000078d2e7dd6ab5  vmovaps xmm6, [rsp+0x60]
000078d2e7dd6abb  vmovaps xmm7, [rsp+0x70]
000078d2e7dd6ac1  vmovaps xmm8, [rsp+0x80]
000078d2e7dd6aca  vmovaps xmm9, [rsp+0x90]
000078d2e7dd6ad3  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd6adc  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd6ae5  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd6aee  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd6af7  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd6b00  add rsp, 0xF0
000078d2e7dd6b07  pop r11
000078d2e7dd6b09  pop r10
000078d2e7dd6b0b  pop r9
000078d2e7dd6b0d  pop r8
000078d2e7dd6b0f  pop rsi
000078d2e7dd6b10  pop rdi
000078d2e7dd6b11  pop rdx
000078d2e7dd6b12  pop rcx
000078d2e7dd6b13  pop rax
000078d2e7dd6b14  add rsp, 0x08
000078d2e7dd6b18  jmp 0x000078D2E7DD3196
000078d2e7dd6b1d  call 0x000078D2E7C0AFE0
000078d2e7dd6b22  jmp 0x000078D2E7DD31EB
000078d2e7dd6b27  sub rsp, 0x08
000078d2e7dd6b2b  push rax
000078d2e7dd6b2c  push rcx
000078d2e7dd6b2d  push rdx
000078d2e7dd6b2e  push rdi
000078d2e7dd6b2f  push rsi
000078d2e7dd6b30  push r8
000078d2e7dd6b32  push r9
000078d2e7dd6b34  push r10
000078d2e7dd6b36  push r11
000078d2e7dd6b38  sub rsp, 0xF0
000078d2e7dd6b3f  vmovaps [rsp], xmm0
000078d2e7dd6b44  vmovaps [rsp+0x10], xmm1
000078d2e7dd6b4a  vmovaps [rsp+0x20], xmm2
000078d2e7dd6b50  vmovaps [rsp+0x30], xmm3
000078d2e7dd6b56  vmovaps [rsp+0x40], xmm4
000078d2e7dd6b5c  vmovaps [rsp+0x50], xmm5
000078d2e7dd6b62  vmovaps [rsp+0x60], xmm6
000078d2e7dd6b68  vmovaps [rsp+0x70], xmm7
000078d2e7dd6b6e  vmovaps [rsp+0x80], xmm8
000078d2e7dd6b77  vmovaps [rsp+0x90], xmm10
000078d2e7dd6b80  vmovaps [rsp+0xA0], xmm11
000078d2e7dd6b89  vmovaps [rsp+0xB0], xmm12
000078d2e7dd6b92  vmovaps [rsp+0xC0], xmm13
000078d2e7dd6b9b  vmovaps [rsp+0xD0], xmm14
000078d2e7dd6ba4  vmovaps [rsp+0xE0], xmm15
000078d2e7dd6bad  sub rsp, 0x30
000078d2e7dd6bb1  movaps [rsp], xmm9
000078d2e7dd6bb6  movaps [rsp+0x10], xmm8
000078d2e7dd6bbc  movaps [rsp+0x20], xmm10
000078d2e7dd6bc2  lea rdi, [rsp]
000078d2e7dd6bc6  mov esi, 0x00
000078d2e7dd6bcb  mov rax, 0x5997D2DB1530
000078d2e7dd6bd5  call rax
000078d2e7dd6bd7  movaps xmm9, [rsp]
000078d2e7dd6bdc  add rsp, 0x30
000078d2e7dd6be0  vmovaps xmm0, [rsp]
000078d2e7dd6be5  vmovaps xmm1, [rsp+0x10]
000078d2e7dd6beb  vmovaps xmm2, [rsp+0x20]
000078d2e7dd6bf1  vmovaps xmm3, [rsp+0x30]
000078d2e7dd6bf7  vmovaps xmm4, [rsp+0x40]
000078d2e7dd6bfd  vmovaps xmm5, [rsp+0x50]
000078d2e7dd6c03  vmovaps xmm6, [rsp+0x60]
000078d2e7dd6c09  vmovaps xmm7, [rsp+0x70]
000078d2e7dd6c0f  vmovaps xmm8, [rsp+0x80]
000078d2e7dd6c18  vmovaps xmm10, [rsp+0x90]
000078d2e7dd6c21  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd6c2a  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd6c33  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd6c3c  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd6c45  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd6c4e  add rsp, 0xF0
000078d2e7dd6c55  pop r11
000078d2e7dd6c57  pop r10
000078d2e7dd6c59  pop r9
000078d2e7dd6c5b  pop r8
000078d2e7dd6c5d  pop rsi
000078d2e7dd6c5e  pop rdi
000078d2e7dd6c5f  pop rdx
000078d2e7dd6c60  pop rcx
000078d2e7dd6c61  pop rax
000078d2e7dd6c62  add rsp, 0x08
000078d2e7dd6c66  jmp 0x000078D2E7DD321C
000078d2e7dd6c6b  sub rsp, 0x08
000078d2e7dd6c6f  push rax
000078d2e7dd6c70  push rcx
000078d2e7dd6c71  push rdx
000078d2e7dd6c72  push rdi
000078d2e7dd6c73  push rsi
000078d2e7dd6c74  push r8
000078d2e7dd6c76  push r9
000078d2e7dd6c78  push r10
000078d2e7dd6c7a  push r11
000078d2e7dd6c7c  sub rsp, 0xF0
000078d2e7dd6c83  vmovaps [rsp], xmm0
000078d2e7dd6c88  vmovaps [rsp+0x10], xmm1
000078d2e7dd6c8e  vmovaps [rsp+0x20], xmm2
000078d2e7dd6c94  vmovaps [rsp+0x30], xmm3
000078d2e7dd6c9a  vmovaps [rsp+0x40], xmm4
000078d2e7dd6ca0  vmovaps [rsp+0x50], xmm5
000078d2e7dd6ca6  vmovaps [rsp+0x60], xmm6
000078d2e7dd6cac  vmovaps [rsp+0x70], xmm7
000078d2e7dd6cb2  vmovaps [rsp+0x80], xmm8
000078d2e7dd6cbb  vmovaps [rsp+0x90], xmm9
000078d2e7dd6cc4  vmovaps [rsp+0xA0], xmm11
000078d2e7dd6ccd  vmovaps [rsp+0xB0], xmm12
000078d2e7dd6cd6  vmovaps [rsp+0xC0], xmm13
000078d2e7dd6cdf  vmovaps [rsp+0xD0], xmm14
000078d2e7dd6ce8  vmovaps [rsp+0xE0], xmm15
000078d2e7dd6cf1  sub rsp, 0x30
000078d2e7dd6cf5  movaps [rsp], xmm10
000078d2e7dd6cfa  movaps [rsp+0x10], xmm1
000078d2e7dd6cff  movaps [rsp+0x20], xmm11
000078d2e7dd6d05  lea rdi, [rsp]
000078d2e7dd6d09  mov esi, 0x00
000078d2e7dd6d0e  mov rax, 0x5997D2DB1530
000078d2e7dd6d18  call rax
000078d2e7dd6d1a  movaps xmm10, [rsp]
000078d2e7dd6d1f  add rsp, 0x30
000078d2e7dd6d23  vmovaps xmm0, [rsp]
000078d2e7dd6d28  vmovaps xmm1, [rsp+0x10]
000078d2e7dd6d2e  vmovaps xmm2, [rsp+0x20]
000078d2e7dd6d34  vmovaps xmm3, [rsp+0x30]
000078d2e7dd6d3a  vmovaps xmm4, [rsp+0x40]
000078d2e7dd6d40  vmovaps xmm5, [rsp+0x50]
000078d2e7dd6d46  vmovaps xmm6, [rsp+0x60]
000078d2e7dd6d4c  vmovaps xmm7, [rsp+0x70]
000078d2e7dd6d52  vmovaps xmm8, [rsp+0x80]
000078d2e7dd6d5b  vmovaps xmm9, [rsp+0x90]
000078d2e7dd6d64  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd6d6d  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd6d76  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd6d7f  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd6d88  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd6d91  add rsp, 0xF0
000078d2e7dd6d98  pop r11
000078d2e7dd6d9a  pop r10
000078d2e7dd6d9c  pop r9
000078d2e7dd6d9e  pop r8
000078d2e7dd6da0  pop rsi
000078d2e7dd6da1  pop rdi
000078d2e7dd6da2  pop rdx
000078d2e7dd6da3  pop rcx
000078d2e7dd6da4  pop rax
000078d2e7dd6da5  add rsp, 0x08
000078d2e7dd6da9  jmp 0x000078D2E7DD3237
000078d2e7dd6dae  sub rsp, 0x08
000078d2e7dd6db2  push rax
000078d2e7dd6db3  push rcx
000078d2e7dd6db4  push rdx
000078d2e7dd6db5  push rdi
000078d2e7dd6db6  push rsi
000078d2e7dd6db7  push r8
000078d2e7dd6db9  push r9
000078d2e7dd6dbb  push r10
000078d2e7dd6dbd  push r11
000078d2e7dd6dbf  sub rsp, 0xF0
000078d2e7dd6dc6  vmovaps [rsp], xmm0
000078d2e7dd6dcb  vmovaps [rsp+0x10], xmm2
000078d2e7dd6dd1  vmovaps [rsp+0x20], xmm3
000078d2e7dd6dd7  vmovaps [rsp+0x30], xmm4
000078d2e7dd6ddd  vmovaps [rsp+0x40], xmm5
000078d2e7dd6de3  vmovaps [rsp+0x50], xmm6
000078d2e7dd6de9  vmovaps [rsp+0x60], xmm7
000078d2e7dd6def  vmovaps [rsp+0x70], xmm8
000078d2e7dd6df5  vmovaps [rsp+0x80], xmm9
000078d2e7dd6dfe  vmovaps [rsp+0x90], xmm10
000078d2e7dd6e07  vmovaps [rsp+0xA0], xmm11
000078d2e7dd6e10  vmovaps [rsp+0xB0], xmm12
000078d2e7dd6e19  vmovaps [rsp+0xC0], xmm13
000078d2e7dd6e22  vmovaps [rsp+0xD0], xmm14
000078d2e7dd6e2b  vmovaps [rsp+0xE0], xmm15
000078d2e7dd6e34  sub rsp, 0x30
000078d2e7dd6e38  movaps [rsp], xmm1
000078d2e7dd6e3c  movaps [rsp+0x10], xmm15
000078d2e7dd6e42  movaps [rsp+0x20], xmm6
000078d2e7dd6e47  lea rdi, [rsp]
000078d2e7dd6e4b  mov esi, 0x00
000078d2e7dd6e50  mov rax, 0x5997D2DB1530
000078d2e7dd6e5a  call rax
000078d2e7dd6e5c  movaps xmm1, [rsp]
000078d2e7dd6e60  add rsp, 0x30
000078d2e7dd6e64  vmovaps xmm0, [rsp]
000078d2e7dd6e69  vmovaps xmm2, [rsp+0x10]
000078d2e7dd6e6f  vmovaps xmm3, [rsp+0x20]
000078d2e7dd6e75  vmovaps xmm4, [rsp+0x30]
000078d2e7dd6e7b  vmovaps xmm5, [rsp+0x40]
000078d2e7dd6e81  vmovaps xmm6, [rsp+0x50]
000078d2e7dd6e87  vmovaps xmm7, [rsp+0x60]
000078d2e7dd6e8d  vmovaps xmm8, [rsp+0x70]
000078d2e7dd6e93  vmovaps xmm9, [rsp+0x80]
000078d2e7dd6e9c  vmovaps xmm10, [rsp+0x90]
000078d2e7dd6ea5  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd6eae  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd6eb7  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd6ec0  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd6ec9  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd6ed2  add rsp, 0xF0
000078d2e7dd6ed9  pop r11
000078d2e7dd6edb  pop r10
000078d2e7dd6edd  pop r9
000078d2e7dd6edf  pop r8
000078d2e7dd6ee1  pop rsi
000078d2e7dd6ee2  pop rdi
000078d2e7dd6ee3  pop rdx
000078d2e7dd6ee4  pop rcx
000078d2e7dd6ee5  pop rax
000078d2e7dd6ee6  add rsp, 0x08
000078d2e7dd6eea  jmp 0x000078D2E7DD3250
000078d2e7dd6eef  sub rsp, 0x08
000078d2e7dd6ef3  push rax
000078d2e7dd6ef4  push rcx
000078d2e7dd6ef5  push rdx
000078d2e7dd6ef6  push rdi
000078d2e7dd6ef7  push rsi
000078d2e7dd6ef8  push r8
000078d2e7dd6efa  push r9
000078d2e7dd6efc  push r10
000078d2e7dd6efe  push r11
000078d2e7dd6f00  sub rsp, 0xF0
000078d2e7dd6f07  vmovaps [rsp], xmm0
000078d2e7dd6f0c  vmovaps [rsp+0x10], xmm1
000078d2e7dd6f12  vmovaps [rsp+0x20], xmm2
000078d2e7dd6f18  vmovaps [rsp+0x30], xmm3
000078d2e7dd6f1e  vmovaps [rsp+0x40], xmm4
000078d2e7dd6f24  vmovaps [rsp+0x50], xmm5
000078d2e7dd6f2a  vmovaps [rsp+0x60], xmm6
000078d2e7dd6f30  vmovaps [rsp+0x70], xmm7
000078d2e7dd6f36  vmovaps [rsp+0x80], xmm8
000078d2e7dd6f3f  vmovaps [rsp+0x90], xmm9
000078d2e7dd6f48  vmovaps [rsp+0xA0], xmm10
000078d2e7dd6f51  vmovaps [rsp+0xB0], xmm12
000078d2e7dd6f5a  vmovaps [rsp+0xC0], xmm13
000078d2e7dd6f63  vmovaps [rsp+0xD0], xmm14
000078d2e7dd6f6c  vmovaps [rsp+0xE0], xmm15
000078d2e7dd6f75  sub rsp, 0x30
000078d2e7dd6f79  movaps [rsp], xmm11
000078d2e7dd6f7e  movaps [rsp+0x10], xmm12
000078d2e7dd6f84  movaps [rsp+0x20], xmm15
000078d2e7dd6f8a  lea rdi, [rsp]
000078d2e7dd6f8e  mov esi, 0x00
000078d2e7dd6f93  mov rax, 0x5997D2DB1530
000078d2e7dd6f9d  call rax
000078d2e7dd6f9f  movaps xmm11, [rsp]
000078d2e7dd6fa4  add rsp, 0x30
000078d2e7dd6fa8  vmovaps xmm0, [rsp]
000078d2e7dd6fad  vmovaps xmm1, [rsp+0x10]
000078d2e7dd6fb3  vmovaps xmm2, [rsp+0x20]
000078d2e7dd6fb9  vmovaps xmm3, [rsp+0x30]
000078d2e7dd6fbf  vmovaps xmm4, [rsp+0x40]
000078d2e7dd6fc5  vmovaps xmm5, [rsp+0x50]
000078d2e7dd6fcb  vmovaps xmm6, [rsp+0x60]
000078d2e7dd6fd1  vmovaps xmm7, [rsp+0x70]
000078d2e7dd6fd7  vmovaps xmm8, [rsp+0x80]
000078d2e7dd6fe0  vmovaps xmm9, [rsp+0x90]
000078d2e7dd6fe9  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd6ff2  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd6ffb  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd7004  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd700d  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd7016  add rsp, 0xF0
000078d2e7dd701d  pop r11
000078d2e7dd701f  pop r10
000078d2e7dd7021  pop r9
000078d2e7dd7023  pop r8
000078d2e7dd7025  pop rsi
000078d2e7dd7026  pop rdi
000078d2e7dd7027  pop rdx
000078d2e7dd7028  pop rcx
000078d2e7dd7029  pop rax
000078d2e7dd702a  add rsp, 0x08
000078d2e7dd702e  jmp 0x000078D2E7DD327A
000078d2e7dd7033  sub rsp, 0x08
000078d2e7dd7037  push rax
000078d2e7dd7038  push rcx
000078d2e7dd7039  push rdx
000078d2e7dd703a  push rdi
000078d2e7dd703b  push rsi
000078d2e7dd703c  push r8
000078d2e7dd703e  push r9
000078d2e7dd7040  push r10
000078d2e7dd7042  push r11
000078d2e7dd7044  sub rsp, 0xF0
000078d2e7dd704b  vmovaps [rsp], xmm0
000078d2e7dd7050  vmovaps [rsp+0x10], xmm1
000078d2e7dd7056  vmovaps [rsp+0x20], xmm2
000078d2e7dd705c  vmovaps [rsp+0x30], xmm3
000078d2e7dd7062  vmovaps [rsp+0x40], xmm4
000078d2e7dd7068  vmovaps [rsp+0x50], xmm5
000078d2e7dd706e  vmovaps [rsp+0x60], xmm6
000078d2e7dd7074  vmovaps [rsp+0x70], xmm7
000078d2e7dd707a  vmovaps [rsp+0x80], xmm8
000078d2e7dd7083  vmovaps [rsp+0x90], xmm9
000078d2e7dd708c  vmovaps [rsp+0xA0], xmm10
000078d2e7dd7095  vmovaps [rsp+0xB0], xmm11
000078d2e7dd709e  vmovaps [rsp+0xC0], xmm13
000078d2e7dd70a7  vmovaps [rsp+0xD0], xmm14
000078d2e7dd70b0  vmovaps [rsp+0xE0], xmm15
000078d2e7dd70b9  sub rsp, 0x30
000078d2e7dd70bd  movaps [rsp], xmm12
000078d2e7dd70c2  movaps [rsp+0x10], xmm8
000078d2e7dd70c8  movaps [rsp+0x20], xmm15
000078d2e7dd70ce  lea rdi, [rsp]
000078d2e7dd70d2  mov esi, 0x00
000078d2e7dd70d7  mov rax, 0x5997D2DB1530
000078d2e7dd70e1  call rax
000078d2e7dd70e3  movaps xmm12, [rsp]
000078d2e7dd70e8  add rsp, 0x30
000078d2e7dd70ec  vmovaps xmm0, [rsp]
000078d2e7dd70f1  vmovaps xmm1, [rsp+0x10]
000078d2e7dd70f7  vmovaps xmm2, [rsp+0x20]
000078d2e7dd70fd  vmovaps xmm3, [rsp+0x30]
000078d2e7dd7103  vmovaps xmm4, [rsp+0x40]
000078d2e7dd7109  vmovaps xmm5, [rsp+0x50]
000078d2e7dd710f  vmovaps xmm6, [rsp+0x60]
000078d2e7dd7115  vmovaps xmm7, [rsp+0x70]
000078d2e7dd711b  vmovaps xmm8, [rsp+0x80]
000078d2e7dd7124  vmovaps xmm9, [rsp+0x90]
000078d2e7dd712d  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd7136  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd713f  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd7148  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd7151  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd715a  add rsp, 0xF0
000078d2e7dd7161  pop r11
000078d2e7dd7163  pop r10
000078d2e7dd7165  pop r9
000078d2e7dd7167  pop r8
000078d2e7dd7169  pop rsi
000078d2e7dd716a  pop rdi
000078d2e7dd716b  pop rdx
000078d2e7dd716c  pop rcx
000078d2e7dd716d  pop rax
000078d2e7dd716e  add rsp, 0x08
000078d2e7dd7172  jmp 0x000078D2E7DD32A9
000078d2e7dd7177  sub rsp, 0x08
000078d2e7dd717b  push rax
000078d2e7dd717c  push rcx
000078d2e7dd717d  push rdx
000078d2e7dd717e  push rdi
000078d2e7dd717f  push rsi
000078d2e7dd7180  push r8
000078d2e7dd7182  push r9
000078d2e7dd7184  push r10
000078d2e7dd7186  push r11
000078d2e7dd7188  sub rsp, 0xF0
000078d2e7dd718f  vmovaps [rsp], xmm0
000078d2e7dd7194  vmovaps [rsp+0x10], xmm1
000078d2e7dd719a  vmovaps [rsp+0x20], xmm2
000078d2e7dd71a0  vmovaps [rsp+0x30], xmm3
000078d2e7dd71a6  vmovaps [rsp+0x40], xmm4
000078d2e7dd71ac  vmovaps [rsp+0x50], xmm5
000078d2e7dd71b2  vmovaps [rsp+0x60], xmm6
000078d2e7dd71b8  vmovaps [rsp+0x70], xmm7
000078d2e7dd71be  vmovaps [rsp+0x80], xmm9
000078d2e7dd71c7  vmovaps [rsp+0x90], xmm10
000078d2e7dd71d0  vmovaps [rsp+0xA0], xmm11
000078d2e7dd71d9  vmovaps [rsp+0xB0], xmm12
000078d2e7dd71e2  vmovaps [rsp+0xC0], xmm13
000078d2e7dd71eb  vmovaps [rsp+0xD0], xmm14
000078d2e7dd71f4  vmovaps [rsp+0xE0], xmm15
000078d2e7dd71fd  sub rsp, 0x30
000078d2e7dd7201  movaps [rsp], xmm8
000078d2e7dd7206  movaps [rsp+0x10], xmm7
000078d2e7dd720b  movaps [rsp+0x20], xmm15
000078d2e7dd7211  lea rdi, [rsp]
000078d2e7dd7215  mov esi, 0x00
000078d2e7dd721a  mov rax, 0x5997D2DB1530
000078d2e7dd7224  call rax
000078d2e7dd7226  movaps xmm8, [rsp]
000078d2e7dd722b  add rsp, 0x30
000078d2e7dd722f  vmovaps xmm0, [rsp]
000078d2e7dd7234  vmovaps xmm1, [rsp+0x10]
000078d2e7dd723a  vmovaps xmm2, [rsp+0x20]
000078d2e7dd7240  vmovaps xmm3, [rsp+0x30]
000078d2e7dd7246  vmovaps xmm4, [rsp+0x40]
000078d2e7dd724c  vmovaps xmm5, [rsp+0x50]
000078d2e7dd7252  vmovaps xmm6, [rsp+0x60]
000078d2e7dd7258  vmovaps xmm7, [rsp+0x70]
000078d2e7dd725e  vmovaps xmm9, [rsp+0x80]
000078d2e7dd7267  vmovaps xmm10, [rsp+0x90]
000078d2e7dd7270  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd7279  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd7282  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd728b  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd7294  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd729d  add rsp, 0xF0
000078d2e7dd72a4  pop r11
000078d2e7dd72a6  pop r10
000078d2e7dd72a8  pop r9
000078d2e7dd72aa  pop r8
000078d2e7dd72ac  pop rsi
000078d2e7dd72ad  pop rdi
000078d2e7dd72ae  pop rdx
000078d2e7dd72af  pop rcx
000078d2e7dd72b0  pop rax
000078d2e7dd72b1  add rsp, 0x08
000078d2e7dd72b5  jmp 0x000078D2E7DD32CF
000078d2e7dd72ba  sub rsp, 0x08
000078d2e7dd72be  push rax
000078d2e7dd72bf  push rcx
000078d2e7dd72c0  push rdx
000078d2e7dd72c1  push rdi
000078d2e7dd72c2  push rsi
000078d2e7dd72c3  push r8
000078d2e7dd72c5  push r9
000078d2e7dd72c7  push r10
000078d2e7dd72c9  push r11
000078d2e7dd72cb  sub rsp, 0xF0
000078d2e7dd72d2  vmovaps [rsp], xmm0
000078d2e7dd72d7  vmovaps [rsp+0x10], xmm1
000078d2e7dd72dd  vmovaps [rsp+0x20], xmm2
000078d2e7dd72e3  vmovaps [rsp+0x30], xmm3
000078d2e7dd72e9  vmovaps [rsp+0x40], xmm4
000078d2e7dd72ef  vmovaps [rsp+0x50], xmm5
000078d2e7dd72f5  vmovaps [rsp+0x60], xmm6
000078d2e7dd72fb  vmovaps [rsp+0x70], xmm7
000078d2e7dd7301  vmovaps [rsp+0x80], xmm8
000078d2e7dd730a  vmovaps [rsp+0x90], xmm9
000078d2e7dd7313  vmovaps [rsp+0xA0], xmm10
000078d2e7dd731c  vmovaps [rsp+0xB0], xmm11
000078d2e7dd7325  vmovaps [rsp+0xC0], xmm12
000078d2e7dd732e  vmovaps [rsp+0xD0], xmm13
000078d2e7dd7337  vmovaps [rsp+0xE0], xmm14
000078d2e7dd7340  sub rsp, 0x30
000078d2e7dd7344  movaps [rsp], xmm15
000078d2e7dd7349  movaps [rsp+0x10], xmm14
000078d2e7dd734f  movaps [rsp+0x20], xmm9
000078d2e7dd7355  lea rdi, [rsp]
000078d2e7dd7359  mov esi, 0x00
000078d2e7dd735e  mov rax, 0x5997D2DB1530
000078d2e7dd7368  call rax
000078d2e7dd736a  movaps xmm15, [rsp]
000078d2e7dd736f  add rsp, 0x30
000078d2e7dd7373  vmovaps xmm0, [rsp]
000078d2e7dd7378  vmovaps xmm1, [rsp+0x10]
000078d2e7dd737e  vmovaps xmm2, [rsp+0x20]
000078d2e7dd7384  vmovaps xmm3, [rsp+0x30]
000078d2e7dd738a  vmovaps xmm4, [rsp+0x40]
000078d2e7dd7390  vmovaps xmm5, [rsp+0x50]
000078d2e7dd7396  vmovaps xmm6, [rsp+0x60]
000078d2e7dd739c  vmovaps xmm7, [rsp+0x70]
000078d2e7dd73a2  vmovaps xmm8, [rsp+0x80]
000078d2e7dd73ab  vmovaps xmm9, [rsp+0x90]
000078d2e7dd73b4  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd73bd  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd73c6  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd73cf  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd73d8  vmovaps xmm14, [rsp+0xE0]
000078d2e7dd73e1  add rsp, 0xF0
000078d2e7dd73e8  pop r11
000078d2e7dd73ea  pop r10
000078d2e7dd73ec  pop r9
000078d2e7dd73ee  pop r8
000078d2e7dd73f0  pop rsi
000078d2e7dd73f1  pop rdi
000078d2e7dd73f2  pop rdx
000078d2e7dd73f3  pop rcx
000078d2e7dd73f4  pop rax
000078d2e7dd73f5  add rsp, 0x08
000078d2e7dd73f9  jmp 0x000078D2E7DD32E9
000078d2e7dd73fe  sub rsp, 0x08
000078d2e7dd7402  push rax
000078d2e7dd7403  push rcx
000078d2e7dd7404  push rdx
000078d2e7dd7405  push rdi
000078d2e7dd7406  push rsi
000078d2e7dd7407  push r8
000078d2e7dd7409  push r9
000078d2e7dd740b  push r10
000078d2e7dd740d  push r11
000078d2e7dd740f  sub rsp, 0xF0
000078d2e7dd7416  vmovaps [rsp], xmm0
000078d2e7dd741b  vmovaps [rsp+0x10], xmm1
000078d2e7dd7421  vmovaps [rsp+0x20], xmm2
000078d2e7dd7427  vmovaps [rsp+0x30], xmm3
000078d2e7dd742d  vmovaps [rsp+0x40], xmm4
000078d2e7dd7433  vmovaps [rsp+0x50], xmm5
000078d2e7dd7439  vmovaps [rsp+0x60], xmm6
000078d2e7dd743f  vmovaps [rsp+0x70], xmm7
000078d2e7dd7445  vmovaps [rsp+0x80], xmm8
000078d2e7dd744e  vmovaps [rsp+0x90], xmm10
000078d2e7dd7457  vmovaps [rsp+0xA0], xmm11
000078d2e7dd7460  vmovaps [rsp+0xB0], xmm12
000078d2e7dd7469  vmovaps [rsp+0xC0], xmm13
000078d2e7dd7472  vmovaps [rsp+0xD0], xmm14
000078d2e7dd747b  vmovaps [rsp+0xE0], xmm15
000078d2e7dd7484  sub rsp, 0x30
000078d2e7dd7488  movaps [rsp], xmm9
000078d2e7dd748d  movaps [rsp+0x10], xmm7
000078d2e7dd7492  movaps [rsp+0x20], xmm14
000078d2e7dd7498  lea rdi, [rsp]
000078d2e7dd749c  mov esi, 0x00
000078d2e7dd74a1  mov rax, 0x5997D2DB1530
000078d2e7dd74ab  call rax
000078d2e7dd74ad  movaps xmm9, [rsp]
000078d2e7dd74b2  add rsp, 0x30
000078d2e7dd74b6  vmovaps xmm0, [rsp]
000078d2e7dd74bb  vmovaps xmm1, [rsp+0x10]
000078d2e7dd74c1  vmovaps xmm2, [rsp+0x20]
000078d2e7dd74c7  vmovaps xmm3, [rsp+0x30]
000078d2e7dd74cd  vmovaps xmm4, [rsp+0x40]
000078d2e7dd74d3  vmovaps xmm5, [rsp+0x50]
000078d2e7dd74d9  vmovaps xmm6, [rsp+0x60]
000078d2e7dd74df  vmovaps xmm7, [rsp+0x70]
000078d2e7dd74e5  vmovaps xmm8, [rsp+0x80]
000078d2e7dd74ee  vmovaps xmm10, [rsp+0x90]
000078d2e7dd74f7  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd7500  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd7509  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd7512  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd751b  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd7524  add rsp, 0xF0
000078d2e7dd752b  pop r11
000078d2e7dd752d  pop r10
000078d2e7dd752f  pop r9
000078d2e7dd7531  pop r8
000078d2e7dd7533  pop rsi
000078d2e7dd7534  pop rdi
000078d2e7dd7535  pop rdx
000078d2e7dd7536  pop rcx
000078d2e7dd7537  pop rax
000078d2e7dd7538  add rsp, 0x08
000078d2e7dd753c  jmp 0x000078D2E7DD3318
000078d2e7dd7541  sub rsp, 0x08
000078d2e7dd7545  push rax
000078d2e7dd7546  push rcx
000078d2e7dd7547  push rdx
000078d2e7dd7548  push rdi
000078d2e7dd7549  push rsi
000078d2e7dd754a  push r8
000078d2e7dd754c  push r9
000078d2e7dd754e  push r10
000078d2e7dd7550  push r11
000078d2e7dd7552  sub rsp, 0xF0
000078d2e7dd7559  vmovaps [rsp], xmm0
000078d2e7dd755e  vmovaps [rsp+0x10], xmm1
000078d2e7dd7564  vmovaps [rsp+0x20], xmm2
000078d2e7dd756a  vmovaps [rsp+0x30], xmm3
000078d2e7dd7570  vmovaps [rsp+0x40], xmm4
000078d2e7dd7576  vmovaps [rsp+0x50], xmm5
000078d2e7dd757c  vmovaps [rsp+0x60], xmm6
000078d2e7dd7582  vmovaps [rsp+0x70], xmm7
000078d2e7dd7588  vmovaps [rsp+0x80], xmm8
000078d2e7dd7591  vmovaps [rsp+0x90], xmm9
000078d2e7dd759a  vmovaps [rsp+0xA0], xmm10
000078d2e7dd75a3  vmovaps [rsp+0xB0], xmm11
000078d2e7dd75ac  vmovaps [rsp+0xC0], xmm12
000078d2e7dd75b5  vmovaps [rsp+0xD0], xmm13
000078d2e7dd75be  vmovaps [rsp+0xE0], xmm15
000078d2e7dd75c7  sub rsp, 0x30
000078d2e7dd75cb  movaps [rsp], xmm14
000078d2e7dd75d0  movaps [rsp+0x10], xmm13
000078d2e7dd75d6  movaps [rsp+0x20], xmm11
000078d2e7dd75dc  lea rdi, [rsp]
000078d2e7dd75e0  mov esi, 0x00
000078d2e7dd75e5  mov rax, 0x5997D2DB1530
000078d2e7dd75ef  call rax
000078d2e7dd75f1  movaps xmm14, [rsp]
000078d2e7dd75f6  add rsp, 0x30
000078d2e7dd75fa  vmovaps xmm0, [rsp]
000078d2e7dd75ff  vmovaps xmm1, [rsp+0x10]
000078d2e7dd7605  vmovaps xmm2, [rsp+0x20]
000078d2e7dd760b  vmovaps xmm3, [rsp+0x30]
000078d2e7dd7611  vmovaps xmm4, [rsp+0x40]
000078d2e7dd7617  vmovaps xmm5, [rsp+0x50]
000078d2e7dd761d  vmovaps xmm6, [rsp+0x60]
000078d2e7dd7623  vmovaps xmm7, [rsp+0x70]
000078d2e7dd7629  vmovaps xmm8, [rsp+0x80]
000078d2e7dd7632  vmovaps xmm9, [rsp+0x90]
000078d2e7dd763b  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd7644  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd764d  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd7656  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd765f  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd7668  add rsp, 0xF0
000078d2e7dd766f  pop r11
000078d2e7dd7671  pop r10
000078d2e7dd7673  pop r9
000078d2e7dd7675  pop r8
000078d2e7dd7677  pop rsi
000078d2e7dd7678  pop rdi
000078d2e7dd7679  pop rdx
000078d2e7dd767a  pop rcx
000078d2e7dd767b  pop rax
000078d2e7dd767c  add rsp, 0x08
000078d2e7dd7680  jmp 0x000078D2E7DD3332
000078d2e7dd7685  sub rsp, 0x08
000078d2e7dd7689  push rax
000078d2e7dd768a  push rcx
000078d2e7dd768b  push rdx
000078d2e7dd768c  push rdi
000078d2e7dd768d  push rsi
000078d2e7dd768e  push r8
000078d2e7dd7690  push r9
000078d2e7dd7692  push r10
000078d2e7dd7694  push r11
000078d2e7dd7696  sub rsp, 0xF0
000078d2e7dd769d  vmovaps [rsp], xmm0
000078d2e7dd76a2  vmovaps [rsp+0x10], xmm1
000078d2e7dd76a8  vmovaps [rsp+0x20], xmm2
000078d2e7dd76ae  vmovaps [rsp+0x30], xmm3
000078d2e7dd76b4  vmovaps [rsp+0x40], xmm4
000078d2e7dd76ba  vmovaps [rsp+0x50], xmm5
000078d2e7dd76c0  vmovaps [rsp+0x60], xmm6
000078d2e7dd76c6  vmovaps [rsp+0x70], xmm7
000078d2e7dd76cc  vmovaps [rsp+0x80], xmm8
000078d2e7dd76d5  vmovaps [rsp+0x90], xmm9
000078d2e7dd76de  vmovaps [rsp+0xA0], xmm10
000078d2e7dd76e7  vmovaps [rsp+0xB0], xmm12
000078d2e7dd76f0  vmovaps [rsp+0xC0], xmm13
000078d2e7dd76f9  vmovaps [rsp+0xD0], xmm14
000078d2e7dd7702  vmovaps [rsp+0xE0], xmm15
000078d2e7dd770b  sub rsp, 0x30
000078d2e7dd770f  movaps [rsp], xmm11
000078d2e7dd7714  movaps [rsp+0x10], xmm7
000078d2e7dd7719  movaps [rsp+0x20], xmm13
000078d2e7dd771f  lea rdi, [rsp]
000078d2e7dd7723  mov esi, 0x00
000078d2e7dd7728  mov rax, 0x5997D2DB1530
000078d2e7dd7732  call rax
000078d2e7dd7734  movaps xmm11, [rsp]
000078d2e7dd7739  add rsp, 0x30
000078d2e7dd773d  vmovaps xmm0, [rsp]
000078d2e7dd7742  vmovaps xmm1, [rsp+0x10]
000078d2e7dd7748  vmovaps xmm2, [rsp+0x20]
000078d2e7dd774e  vmovaps xmm3, [rsp+0x30]
000078d2e7dd7754  vmovaps xmm4, [rsp+0x40]
000078d2e7dd775a  vmovaps xmm5, [rsp+0x50]
000078d2e7dd7760  vmovaps xmm6, [rsp+0x60]
000078d2e7dd7766  vmovaps xmm7, [rsp+0x70]
000078d2e7dd776c  vmovaps xmm8, [rsp+0x80]
000078d2e7dd7775  vmovaps xmm9, [rsp+0x90]
000078d2e7dd777e  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd7787  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd7790  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd7799  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd77a2  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd77ab  add rsp, 0xF0
000078d2e7dd77b2  pop r11
000078d2e7dd77b4  pop r10
000078d2e7dd77b6  pop r9
000078d2e7dd77b8  pop r8
000078d2e7dd77ba  pop rsi
000078d2e7dd77bb  pop rdi
000078d2e7dd77bc  pop rdx
000078d2e7dd77bd  pop rcx
000078d2e7dd77be  pop rax
000078d2e7dd77bf  add rsp, 0x08
000078d2e7dd77c3  jmp 0x000078D2E7DD335E
000078d2e7dd77c8  sub rsp, 0x08
000078d2e7dd77cc  push rax
000078d2e7dd77cd  push rcx
000078d2e7dd77ce  push rdx
000078d2e7dd77cf  push rdi
000078d2e7dd77d0  push rsi
000078d2e7dd77d1  push r8
000078d2e7dd77d3  push r9
000078d2e7dd77d5  push r10
000078d2e7dd77d7  push r11
000078d2e7dd77d9  sub rsp, 0xF0
000078d2e7dd77e0  vmovaps [rsp], xmm0
000078d2e7dd77e5  vmovaps [rsp+0x10], xmm1
000078d2e7dd77eb  vmovaps [rsp+0x20], xmm2
000078d2e7dd77f1  vmovaps [rsp+0x30], xmm3
000078d2e7dd77f7  vmovaps [rsp+0x40], xmm4
000078d2e7dd77fd  vmovaps [rsp+0x50], xmm5
000078d2e7dd7803  vmovaps [rsp+0x60], xmm6
000078d2e7dd7809  vmovaps [rsp+0x70], xmm7
000078d2e7dd780f  vmovaps [rsp+0x80], xmm8
000078d2e7dd7818  vmovaps [rsp+0x90], xmm9
000078d2e7dd7821  vmovaps [rsp+0xA0], xmm10
000078d2e7dd782a  vmovaps [rsp+0xB0], xmm11
000078d2e7dd7833  vmovaps [rsp+0xC0], xmm12
000078d2e7dd783c  vmovaps [rsp+0xD0], xmm14
000078d2e7dd7845  vmovaps [rsp+0xE0], xmm15
000078d2e7dd784e  sub rsp, 0x30
000078d2e7dd7852  movaps [rsp], xmm13
000078d2e7dd7857  movaps [rsp+0x10], xmm10
000078d2e7dd785d  movaps [rsp+0x20], xmm12
000078d2e7dd7863  lea rdi, [rsp]
000078d2e7dd7867  mov esi, 0x00
000078d2e7dd786c  mov rax, 0x5997D2DB1530
000078d2e7dd7876  call rax
000078d2e7dd7878  movaps xmm13, [rsp]
000078d2e7dd787d  add rsp, 0x30
000078d2e7dd7881  vmovaps xmm0, [rsp]
000078d2e7dd7886  vmovaps xmm1, [rsp+0x10]
000078d2e7dd788c  vmovaps xmm2, [rsp+0x20]
000078d2e7dd7892  vmovaps xmm3, [rsp+0x30]
000078d2e7dd7898  vmovaps xmm4, [rsp+0x40]
000078d2e7dd789e  vmovaps xmm5, [rsp+0x50]
000078d2e7dd78a4  vmovaps xmm6, [rsp+0x60]
000078d2e7dd78aa  vmovaps xmm7, [rsp+0x70]
000078d2e7dd78b0  vmovaps xmm8, [rsp+0x80]
000078d2e7dd78b9  vmovaps xmm9, [rsp+0x90]
000078d2e7dd78c2  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd78cb  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd78d4  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd78dd  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd78e6  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd78ef  add rsp, 0xF0
000078d2e7dd78f6  pop r11
000078d2e7dd78f8  pop r10
000078d2e7dd78fa  pop r9
000078d2e7dd78fc  pop r8
000078d2e7dd78fe  pop rsi
000078d2e7dd78ff  pop rdi
000078d2e7dd7900  pop rdx
000078d2e7dd7901  pop rcx
000078d2e7dd7902  pop rax
000078d2e7dd7903  add rsp, 0x08
000078d2e7dd7907  jmp 0x000078D2E7DD3378
000078d2e7dd790c  sub rsp, 0x08
000078d2e7dd7910  push rax
000078d2e7dd7911  push rcx
000078d2e7dd7912  push rdx
000078d2e7dd7913  push rdi
000078d2e7dd7914  push rsi
000078d2e7dd7915  push r8
000078d2e7dd7917  push r9
000078d2e7dd7919  push r10
000078d2e7dd791b  push r11
000078d2e7dd791d  sub rsp, 0xF0
000078d2e7dd7924  vmovaps [rsp], xmm0
000078d2e7dd7929  vmovaps [rsp+0x10], xmm1
000078d2e7dd792f  vmovaps [rsp+0x20], xmm2
000078d2e7dd7935  vmovaps [rsp+0x30], xmm3
000078d2e7dd793b  vmovaps [rsp+0x40], xmm4
000078d2e7dd7941  vmovaps [rsp+0x50], xmm5
000078d2e7dd7947  vmovaps [rsp+0x60], xmm6
000078d2e7dd794d  vmovaps [rsp+0x70], xmm7
000078d2e7dd7953  vmovaps [rsp+0x80], xmm8
000078d2e7dd795c  vmovaps [rsp+0x90], xmm9
000078d2e7dd7965  vmovaps [rsp+0xA0], xmm11
000078d2e7dd796e  vmovaps [rsp+0xB0], xmm12
000078d2e7dd7977  vmovaps [rsp+0xC0], xmm13
000078d2e7dd7980  vmovaps [rsp+0xD0], xmm14
000078d2e7dd7989  vmovaps [rsp+0xE0], xmm15
000078d2e7dd7992  sub rsp, 0x30
000078d2e7dd7996  movaps [rsp], xmm10
000078d2e7dd799b  movaps [rsp+0x10], xmm7
000078d2e7dd79a0  movaps [rsp+0x20], xmm12
000078d2e7dd79a6  lea rdi, [rsp]
000078d2e7dd79aa  mov esi, 0x00
000078d2e7dd79af  mov rax, 0x5997D2DB1530
000078d2e7dd79b9  call rax
000078d2e7dd79bb  movaps xmm10, [rsp]
000078d2e7dd79c0  add rsp, 0x30
000078d2e7dd79c4  vmovaps xmm0, [rsp]
000078d2e7dd79c9  vmovaps xmm1, [rsp+0x10]
000078d2e7dd79cf  vmovaps xmm2, [rsp+0x20]
000078d2e7dd79d5  vmovaps xmm3, [rsp+0x30]
000078d2e7dd79db  vmovaps xmm4, [rsp+0x40]
000078d2e7dd79e1  vmovaps xmm5, [rsp+0x50]
000078d2e7dd79e7  vmovaps xmm6, [rsp+0x60]
000078d2e7dd79ed  vmovaps xmm7, [rsp+0x70]
000078d2e7dd79f3  vmovaps xmm8, [rsp+0x80]
000078d2e7dd79fc  vmovaps xmm9, [rsp+0x90]
000078d2e7dd7a05  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd7a0e  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd7a17  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd7a20  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd7a29  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd7a32  add rsp, 0xF0
000078d2e7dd7a39  pop r11
000078d2e7dd7a3b  pop r10
000078d2e7dd7a3d  pop r9
000078d2e7dd7a3f  pop r8
000078d2e7dd7a41  pop rsi
000078d2e7dd7a42  pop rdi
000078d2e7dd7a43  pop rdx
000078d2e7dd7a44  pop rcx
000078d2e7dd7a45  pop rax
000078d2e7dd7a46  add rsp, 0x08
000078d2e7dd7a4a  jmp 0x000078D2E7DD33A4
000078d2e7dd7a4f  sub rsp, 0x08
000078d2e7dd7a53  push rax
000078d2e7dd7a54  push rcx
000078d2e7dd7a55  push rdx
000078d2e7dd7a56  push rdi
000078d2e7dd7a57  push rsi
000078d2e7dd7a58  push r8
000078d2e7dd7a5a  push r9
000078d2e7dd7a5c  push r10
000078d2e7dd7a5e  push r11
000078d2e7dd7a60  sub rsp, 0xF0
000078d2e7dd7a67  vmovaps [rsp], xmm0
000078d2e7dd7a6c  vmovaps [rsp+0x10], xmm1
000078d2e7dd7a72  vmovaps [rsp+0x20], xmm2
000078d2e7dd7a78  vmovaps [rsp+0x30], xmm3
000078d2e7dd7a7e  vmovaps [rsp+0x40], xmm4
000078d2e7dd7a84  vmovaps [rsp+0x50], xmm5
000078d2e7dd7a8a  vmovaps [rsp+0x60], xmm6
000078d2e7dd7a90  vmovaps [rsp+0x70], xmm7
000078d2e7dd7a96  vmovaps [rsp+0x80], xmm8
000078d2e7dd7a9f  vmovaps [rsp+0x90], xmm9
000078d2e7dd7aa8  vmovaps [rsp+0xA0], xmm10
000078d2e7dd7ab1  vmovaps [rsp+0xB0], xmm11
000078d2e7dd7aba  vmovaps [rsp+0xC0], xmm13
000078d2e7dd7ac3  vmovaps [rsp+0xD0], xmm14
000078d2e7dd7acc  vmovaps [rsp+0xE0], xmm15
000078d2e7dd7ad5  sub rsp, 0x30
000078d2e7dd7ad9  movaps [rsp], xmm12
000078d2e7dd7ade  movaps [rsp+0x10], xmm1
000078d2e7dd7ae3  movaps [rsp+0x20], xmm8
000078d2e7dd7ae9  lea rdi, [rsp]
000078d2e7dd7aed  mov esi, 0x00
000078d2e7dd7af2  mov rax, 0x5997D2DB1530
000078d2e7dd7afc  call rax
000078d2e7dd7afe  movaps xmm12, [rsp]
000078d2e7dd7b03  add rsp, 0x30
000078d2e7dd7b07  vmovaps xmm0, [rsp]
000078d2e7dd7b0c  vmovaps xmm1, [rsp+0x10]
000078d2e7dd7b12  vmovaps xmm2, [rsp+0x20]
000078d2e7dd7b18  vmovaps xmm3, [rsp+0x30]
000078d2e7dd7b1e  vmovaps xmm4, [rsp+0x40]
000078d2e7dd7b24  vmovaps xmm5, [rsp+0x50]
000078d2e7dd7b2a  vmovaps xmm6, [rsp+0x60]
000078d2e7dd7b30  vmovaps xmm7, [rsp+0x70]
000078d2e7dd7b36  vmovaps xmm8, [rsp+0x80]
000078d2e7dd7b3f  vmovaps xmm9, [rsp+0x90]
000078d2e7dd7b48  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd7b51  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd7b5a  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd7b63  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd7b6c  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd7b75  add rsp, 0xF0
000078d2e7dd7b7c  pop r11
000078d2e7dd7b7e  pop r10
000078d2e7dd7b80  pop r9
000078d2e7dd7b82  pop r8
000078d2e7dd7b84  pop rsi
000078d2e7dd7b85  pop rdi
000078d2e7dd7b86  pop rdx
000078d2e7dd7b87  pop rcx
000078d2e7dd7b88  pop rax
000078d2e7dd7b89  add rsp, 0x08
000078d2e7dd7b8d  jmp 0x000078D2E7DD33BE
000078d2e7dd7b92  call 0x000078D2E7BFF430
000078d2e7dd7b97  jmp 0x000078D2E7DD33C8
000078d2e7dd7b9c  sub rsp, 0x08
000078d2e7dd7ba0  push rax
000078d2e7dd7ba1  push rcx
000078d2e7dd7ba2  push rdx
000078d2e7dd7ba3  push rdi
000078d2e7dd7ba4  push rsi
000078d2e7dd7ba5  push r8
000078d2e7dd7ba7  push r9
000078d2e7dd7ba9  push r10
000078d2e7dd7bab  push r11
000078d2e7dd7bad  sub rsp, 0xF0
000078d2e7dd7bb4  vmovaps [rsp], xmm0
000078d2e7dd7bb9  vmovaps [rsp+0x10], xmm1
000078d2e7dd7bbf  vmovaps [rsp+0x20], xmm2
000078d2e7dd7bc5  vmovaps [rsp+0x30], xmm3
000078d2e7dd7bcb  vmovaps [rsp+0x40], xmm4
000078d2e7dd7bd1  vmovaps [rsp+0x50], xmm5
000078d2e7dd7bd7  vmovaps [rsp+0x60], xmm6
000078d2e7dd7bdd  vmovaps [rsp+0x70], xmm7
000078d2e7dd7be3  vmovaps [rsp+0x80], xmm9
000078d2e7dd7bec  vmovaps [rsp+0x90], xmm10
000078d2e7dd7bf5  vmovaps [rsp+0xA0], xmm11
000078d2e7dd7bfe  vmovaps [rsp+0xB0], xmm12
000078d2e7dd7c07  vmovaps [rsp+0xC0], xmm13
000078d2e7dd7c10  vmovaps [rsp+0xD0], xmm14
000078d2e7dd7c19  vmovaps [rsp+0xE0], xmm15
000078d2e7dd7c22  sub rsp, 0x30
000078d2e7dd7c26  movaps [rsp], xmm8
000078d2e7dd7c2b  movaps [rsp+0x10], xmm15
000078d2e7dd7c31  movaps [rsp+0x20], xmm9
000078d2e7dd7c37  lea rdi, [rsp]
000078d2e7dd7c3b  mov esi, 0x00
000078d2e7dd7c40  mov rax, 0x5997D2DB1530
000078d2e7dd7c4a  call rax
000078d2e7dd7c4c  movaps xmm8, [rsp]
000078d2e7dd7c51  add rsp, 0x30
000078d2e7dd7c55  vmovaps xmm0, [rsp]
000078d2e7dd7c5a  vmovaps xmm1, [rsp+0x10]
000078d2e7dd7c60  vmovaps xmm2, [rsp+0x20]
000078d2e7dd7c66  vmovaps xmm3, [rsp+0x30]
000078d2e7dd7c6c  vmovaps xmm4, [rsp+0x40]
000078d2e7dd7c72  vmovaps xmm5, [rsp+0x50]
000078d2e7dd7c78  vmovaps xmm6, [rsp+0x60]
000078d2e7dd7c7e  vmovaps xmm7, [rsp+0x70]
000078d2e7dd7c84  vmovaps xmm9, [rsp+0x80]
000078d2e7dd7c8d  vmovaps xmm10, [rsp+0x90]
000078d2e7dd7c96  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd7c9f  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd7ca8  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd7cb1  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd7cba  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd7cc3  add rsp, 0xF0
000078d2e7dd7cca  pop r11
000078d2e7dd7ccc  pop r10
000078d2e7dd7cce  pop r9
000078d2e7dd7cd0  pop r8
000078d2e7dd7cd2  pop rsi
000078d2e7dd7cd3  pop rdi
000078d2e7dd7cd4  pop rdx
000078d2e7dd7cd5  pop rcx
000078d2e7dd7cd6  pop rax
000078d2e7dd7cd7  add rsp, 0x08
000078d2e7dd7cdb  jmp 0x000078D2E7DD33EA
000078d2e7dd7ce0  sub rsp, 0x08
000078d2e7dd7ce4  push rax
000078d2e7dd7ce5  push rcx
000078d2e7dd7ce6  push rdx
000078d2e7dd7ce7  push rdi
000078d2e7dd7ce8  push rsi
000078d2e7dd7ce9  push r8
000078d2e7dd7ceb  push r9
000078d2e7dd7ced  push r10
000078d2e7dd7cef  push r11
000078d2e7dd7cf1  sub rsp, 0xF0
000078d2e7dd7cf8  vmovaps [rsp], xmm0
000078d2e7dd7cfd  vmovaps [rsp+0x10], xmm1
000078d2e7dd7d03  vmovaps [rsp+0x20], xmm2
000078d2e7dd7d09  vmovaps [rsp+0x30], xmm3
000078d2e7dd7d0f  vmovaps [rsp+0x40], xmm4
000078d2e7dd7d15  vmovaps [rsp+0x50], xmm5
000078d2e7dd7d1b  vmovaps [rsp+0x60], xmm6
000078d2e7dd7d21  vmovaps [rsp+0x70], xmm7
000078d2e7dd7d27  vmovaps [rsp+0x80], xmm8
000078d2e7dd7d30  vmovaps [rsp+0x90], xmm10
000078d2e7dd7d39  vmovaps [rsp+0xA0], xmm11
000078d2e7dd7d42  vmovaps [rsp+0xB0], xmm12
000078d2e7dd7d4b  vmovaps [rsp+0xC0], xmm13
000078d2e7dd7d54  vmovaps [rsp+0xD0], xmm14
000078d2e7dd7d5d  vmovaps [rsp+0xE0], xmm15
000078d2e7dd7d66  sub rsp, 0x30
000078d2e7dd7d6a  movaps [rsp], xmm9
000078d2e7dd7d6f  movaps [rsp+0x10], xmm1
000078d2e7dd7d74  movaps [rsp+0x20], xmm15
000078d2e7dd7d7a  lea rdi, [rsp]
000078d2e7dd7d7e  mov esi, 0x00
000078d2e7dd7d83  mov rax, 0x5997D2DB1530
000078d2e7dd7d8d  call rax
000078d2e7dd7d8f  movaps xmm9, [rsp]
000078d2e7dd7d94  add rsp, 0x30
000078d2e7dd7d98  vmovaps xmm0, [rsp]
000078d2e7dd7d9d  vmovaps xmm1, [rsp+0x10]
000078d2e7dd7da3  vmovaps xmm2, [rsp+0x20]
000078d2e7dd7da9  vmovaps xmm3, [rsp+0x30]
000078d2e7dd7daf  vmovaps xmm4, [rsp+0x40]
000078d2e7dd7db5  vmovaps xmm5, [rsp+0x50]
000078d2e7dd7dbb  vmovaps xmm6, [rsp+0x60]
000078d2e7dd7dc1  vmovaps xmm7, [rsp+0x70]
000078d2e7dd7dc7  vmovaps xmm8, [rsp+0x80]
000078d2e7dd7dd0  vmovaps xmm10, [rsp+0x90]
000078d2e7dd7dd9  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd7de2  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd7deb  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd7df4  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd7dfd  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd7e06  add rsp, 0xF0
000078d2e7dd7e0d  pop r11
000078d2e7dd7e0f  pop r10
000078d2e7dd7e11  pop r9
000078d2e7dd7e13  pop r8
000078d2e7dd7e15  pop rsi
000078d2e7dd7e16  pop rdi
000078d2e7dd7e17  pop rdx
000078d2e7dd7e18  pop rcx
000078d2e7dd7e19  pop rax
000078d2e7dd7e1a  add rsp, 0x08
000078d2e7dd7e1e  jmp 0x000078D2E7DD3418
000078d2e7dd7e23  sub rsp, 0x08
000078d2e7dd7e27  push rax
000078d2e7dd7e28  push rcx
000078d2e7dd7e29  push rdx
000078d2e7dd7e2a  push rdi
000078d2e7dd7e2b  push rsi
000078d2e7dd7e2c  push r8
000078d2e7dd7e2e  push r9
000078d2e7dd7e30  push r10
000078d2e7dd7e32  push r11
000078d2e7dd7e34  sub rsp, 0xF0
000078d2e7dd7e3b  vmovaps [rsp], xmm0
000078d2e7dd7e40  vmovaps [rsp+0x10], xmm1
000078d2e7dd7e46  vmovaps [rsp+0x20], xmm2
000078d2e7dd7e4c  vmovaps [rsp+0x30], xmm3
000078d2e7dd7e52  vmovaps [rsp+0x40], xmm4
000078d2e7dd7e58  vmovaps [rsp+0x50], xmm5
000078d2e7dd7e5e  vmovaps [rsp+0x60], xmm6
000078d2e7dd7e64  vmovaps [rsp+0x70], xmm7
000078d2e7dd7e6a  vmovaps [rsp+0x80], xmm8
000078d2e7dd7e73  vmovaps [rsp+0x90], xmm9
000078d2e7dd7e7c  vmovaps [rsp+0xA0], xmm10
000078d2e7dd7e85  vmovaps [rsp+0xB0], xmm11
000078d2e7dd7e8e  vmovaps [rsp+0xC0], xmm12
000078d2e7dd7e97  vmovaps [rsp+0xD0], xmm13
000078d2e7dd7ea0  vmovaps [rsp+0xE0], xmm14
000078d2e7dd7ea9  sub rsp, 0x30
000078d2e7dd7ead  movaps [rsp], xmm15
000078d2e7dd7eb2  movaps [rsp+0x10], xmm4
000078d2e7dd7eb7  movaps [rsp+0x20], xmm1
000078d2e7dd7ebc  lea rdi, [rsp]
000078d2e7dd7ec0  mov esi, 0x00
000078d2e7dd7ec5  mov rax, 0x5997D2DB1530
000078d2e7dd7ecf  call rax
000078d2e7dd7ed1  movaps xmm15, [rsp]
000078d2e7dd7ed6  add rsp, 0x30
000078d2e7dd7eda  vmovaps xmm0, [rsp]
000078d2e7dd7edf  vmovaps xmm1, [rsp+0x10]
000078d2e7dd7ee5  vmovaps xmm2, [rsp+0x20]
000078d2e7dd7eeb  vmovaps xmm3, [rsp+0x30]
000078d2e7dd7ef1  vmovaps xmm4, [rsp+0x40]
000078d2e7dd7ef7  vmovaps xmm5, [rsp+0x50]
000078d2e7dd7efd  vmovaps xmm6, [rsp+0x60]
000078d2e7dd7f03  vmovaps xmm7, [rsp+0x70]
000078d2e7dd7f09  vmovaps xmm8, [rsp+0x80]
000078d2e7dd7f12  vmovaps xmm9, [rsp+0x90]
000078d2e7dd7f1b  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd7f24  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd7f2d  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd7f36  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd7f3f  vmovaps xmm14, [rsp+0xE0]
000078d2e7dd7f48  add rsp, 0xF0
000078d2e7dd7f4f  pop r11
000078d2e7dd7f51  pop r10
000078d2e7dd7f53  pop r9
000078d2e7dd7f55  pop r8
000078d2e7dd7f57  pop rsi
000078d2e7dd7f58  pop rdi
000078d2e7dd7f59  pop rdx
000078d2e7dd7f5a  pop rcx
000078d2e7dd7f5b  pop rax
000078d2e7dd7f5c  add rsp, 0x08
000078d2e7dd7f60  jmp 0x000078D2E7DD343E
000078d2e7dd7f65  sub rsp, 0x08
000078d2e7dd7f69  push rax
000078d2e7dd7f6a  push rcx
000078d2e7dd7f6b  push rdx
000078d2e7dd7f6c  push rdi
000078d2e7dd7f6d  push rsi
000078d2e7dd7f6e  push r8
000078d2e7dd7f70  push r9
000078d2e7dd7f72  push r10
000078d2e7dd7f74  push r11
000078d2e7dd7f76  sub rsp, 0xF0
000078d2e7dd7f7d  vmovaps [rsp], xmm0
000078d2e7dd7f82  vmovaps [rsp+0x10], xmm2
000078d2e7dd7f88  vmovaps [rsp+0x20], xmm3
000078d2e7dd7f8e  vmovaps [rsp+0x30], xmm4
000078d2e7dd7f94  vmovaps [rsp+0x40], xmm5
000078d2e7dd7f9a  vmovaps [rsp+0x50], xmm6
000078d2e7dd7fa0  vmovaps [rsp+0x60], xmm7
000078d2e7dd7fa6  vmovaps [rsp+0x70], xmm8
000078d2e7dd7fac  vmovaps [rsp+0x80], xmm9
000078d2e7dd7fb5  vmovaps [rsp+0x90], xmm10
000078d2e7dd7fbe  vmovaps [rsp+0xA0], xmm11
000078d2e7dd7fc7  vmovaps [rsp+0xB0], xmm12
000078d2e7dd7fd0  vmovaps [rsp+0xC0], xmm13
000078d2e7dd7fd9  vmovaps [rsp+0xD0], xmm14
000078d2e7dd7fe2  vmovaps [rsp+0xE0], xmm15
000078d2e7dd7feb  sub rsp, 0x30
000078d2e7dd7fef  movaps [rsp], xmm1
000078d2e7dd7ff3  movaps [rsp+0x10], xmm14
000078d2e7dd7ff9  movaps [rsp+0x20], xmm11
000078d2e7dd7fff  lea rdi, [rsp]
000078d2e7dd8003  mov esi, 0x00
000078d2e7dd8008  mov rax, 0x5997D2DB1530
000078d2e7dd8012  call rax
000078d2e7dd8014  movaps xmm1, [rsp]
000078d2e7dd8018  add rsp, 0x30
000078d2e7dd801c  vmovaps xmm0, [rsp]
000078d2e7dd8021  vmovaps xmm2, [rsp+0x10]
000078d2e7dd8027  vmovaps xmm3, [rsp+0x20]
000078d2e7dd802d  vmovaps xmm4, [rsp+0x30]
000078d2e7dd8033  vmovaps xmm5, [rsp+0x40]
000078d2e7dd8039  vmovaps xmm6, [rsp+0x50]
000078d2e7dd803f  vmovaps xmm7, [rsp+0x60]
000078d2e7dd8045  vmovaps xmm8, [rsp+0x70]
000078d2e7dd804b  vmovaps xmm9, [rsp+0x80]
000078d2e7dd8054  vmovaps xmm10, [rsp+0x90]
000078d2e7dd805d  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd8066  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd806f  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd8078  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd8081  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd808a  add rsp, 0xF0
000078d2e7dd8091  pop r11
000078d2e7dd8093  pop r10
000078d2e7dd8095  pop r9
000078d2e7dd8097  pop r8
000078d2e7dd8099  pop rsi
000078d2e7dd809a  pop rdi
000078d2e7dd809b  pop rdx
000078d2e7dd809c  pop rcx
000078d2e7dd809d  pop rax
000078d2e7dd809e  add rsp, 0x08
000078d2e7dd80a2  jmp 0x000078D2E7DD345F
000078d2e7dd80a7  call 0x000078D2E7CE45A0
000078d2e7dd80ac  jmp 0x000078D2E7DD346D
000078d2e7dd80b1  call 0x000078D2E7C09D70
000078d2e7dd80b6  jmp 0x000078D2E7DD3477
000078d2e7dd80bb  sub rsp, 0x08
000078d2e7dd80bf  push rax
000078d2e7dd80c0  push rcx
000078d2e7dd80c1  push rdx
000078d2e7dd80c2  push rdi
000078d2e7dd80c3  push rsi
000078d2e7dd80c4  push r8
000078d2e7dd80c6  push r9
000078d2e7dd80c8  push r10
000078d2e7dd80ca  push r11
000078d2e7dd80cc  sub rsp, 0xF0
000078d2e7dd80d3  vmovaps [rsp], xmm0
000078d2e7dd80d8  vmovaps [rsp+0x10], xmm1
000078d2e7dd80de  vmovaps [rsp+0x20], xmm2
000078d2e7dd80e4  vmovaps [rsp+0x30], xmm3
000078d2e7dd80ea  vmovaps [rsp+0x40], xmm4
000078d2e7dd80f0  vmovaps [rsp+0x50], xmm5
000078d2e7dd80f6  vmovaps [rsp+0x60], xmm6
000078d2e7dd80fc  vmovaps [rsp+0x70], xmm8
000078d2e7dd8102  vmovaps [rsp+0x80], xmm9
000078d2e7dd810b  vmovaps [rsp+0x90], xmm10
000078d2e7dd8114  vmovaps [rsp+0xA0], xmm11
000078d2e7dd811d  vmovaps [rsp+0xB0], xmm12
000078d2e7dd8126  vmovaps [rsp+0xC0], xmm13
000078d2e7dd812f  vmovaps [rsp+0xD0], xmm14
000078d2e7dd8138  vmovaps [rsp+0xE0], xmm15
000078d2e7dd8141  sub rsp, 0x30
000078d2e7dd8145  movaps [rsp], xmm7
000078d2e7dd8149  movaps [rsp+0x10], xmm13
000078d2e7dd814f  movaps [rsp+0x20], xmm10
000078d2e7dd8155  lea rdi, [rsp]
000078d2e7dd8159  mov esi, 0x00
000078d2e7dd815e  mov rax, 0x5997D2DB1530
000078d2e7dd8168  call rax
000078d2e7dd816a  movaps xmm7, [rsp]
000078d2e7dd816e  add rsp, 0x30
000078d2e7dd8172  vmovaps xmm0, [rsp]
000078d2e7dd8177  vmovaps xmm1, [rsp+0x10]
000078d2e7dd817d  vmovaps xmm2, [rsp+0x20]
000078d2e7dd8183  vmovaps xmm3, [rsp+0x30]
000078d2e7dd8189  vmovaps xmm4, [rsp+0x40]
000078d2e7dd818f  vmovaps xmm5, [rsp+0x50]
000078d2e7dd8195  vmovaps xmm6, [rsp+0x60]
000078d2e7dd819b  vmovaps xmm8, [rsp+0x70]
000078d2e7dd81a1  vmovaps xmm9, [rsp+0x80]
000078d2e7dd81aa  vmovaps xmm10, [rsp+0x90]
000078d2e7dd81b3  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd81bc  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd81c5  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd81ce  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd81d7  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd81e0  add rsp, 0xF0
000078d2e7dd81e7  pop r11
000078d2e7dd81e9  pop r10
000078d2e7dd81eb  pop r9
000078d2e7dd81ed  pop r8
000078d2e7dd81ef  pop rsi
000078d2e7dd81f0  pop rdi
000078d2e7dd81f1  pop rdx
000078d2e7dd81f2  pop rcx
000078d2e7dd81f3  pop rax
000078d2e7dd81f4  add rsp, 0x08
000078d2e7dd81f8  jmp 0x000078D2E7DD3498
000078d2e7dd81fd  sub rsp, 0x08
000078d2e7dd8201  push rax
000078d2e7dd8202  push rcx
000078d2e7dd8203  push rdx
000078d2e7dd8204  push rdi
000078d2e7dd8205  push rsi
000078d2e7dd8206  push r8
000078d2e7dd8208  push r9
000078d2e7dd820a  push r10
000078d2e7dd820c  push r11
000078d2e7dd820e  sub rsp, 0xF0
000078d2e7dd8215  vmovaps [rsp], xmm0
000078d2e7dd821a  vmovaps [rsp+0x10], xmm1
000078d2e7dd8220  vmovaps [rsp+0x20], xmm2
000078d2e7dd8226  vmovaps [rsp+0x30], xmm3
000078d2e7dd822c  vmovaps [rsp+0x40], xmm4
000078d2e7dd8232  vmovaps [rsp+0x50], xmm5
000078d2e7dd8238  vmovaps [rsp+0x60], xmm6
000078d2e7dd823e  vmovaps [rsp+0x70], xmm7
000078d2e7dd8244  vmovaps [rsp+0x80], xmm8
000078d2e7dd824d  vmovaps [rsp+0x90], xmm9
000078d2e7dd8256  vmovaps [rsp+0xA0], xmm11
000078d2e7dd825f  vmovaps [rsp+0xB0], xmm12
000078d2e7dd8268  vmovaps [rsp+0xC0], xmm13
000078d2e7dd8271  vmovaps [rsp+0xD0], xmm14
000078d2e7dd827a  vmovaps [rsp+0xE0], xmm15
000078d2e7dd8283  sub rsp, 0x30
000078d2e7dd8287  movaps [rsp], xmm10
000078d2e7dd828c  movaps [rsp+0x10], xmm11
000078d2e7dd8292  movaps [rsp+0x20], xmm13
000078d2e7dd8298  lea rdi, [rsp]
000078d2e7dd829c  mov esi, 0x00
000078d2e7dd82a1  mov rax, 0x5997D2DB1530
000078d2e7dd82ab  call rax
000078d2e7dd82ad  movaps xmm10, [rsp]
000078d2e7dd82b2  add rsp, 0x30
000078d2e7dd82b6  vmovaps xmm0, [rsp]
000078d2e7dd82bb  vmovaps xmm1, [rsp+0x10]
000078d2e7dd82c1  vmovaps xmm2, [rsp+0x20]
000078d2e7dd82c7  vmovaps xmm3, [rsp+0x30]
000078d2e7dd82cd  vmovaps xmm4, [rsp+0x40]
000078d2e7dd82d3  vmovaps xmm5, [rsp+0x50]
000078d2e7dd82d9  vmovaps xmm6, [rsp+0x60]
000078d2e7dd82df  vmovaps xmm7, [rsp+0x70]
000078d2e7dd82e5  vmovaps xmm8, [rsp+0x80]
000078d2e7dd82ee  vmovaps xmm9, [rsp+0x90]
000078d2e7dd82f7  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd8300  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd8309  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd8312  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd831b  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd8324  add rsp, 0xF0
000078d2e7dd832b  pop r11
000078d2e7dd832d  pop r10
000078d2e7dd832f  pop r9
000078d2e7dd8331  pop r8
000078d2e7dd8333  pop rsi
000078d2e7dd8334  pop rdi
000078d2e7dd8335  pop rdx
000078d2e7dd8336  pop rcx
000078d2e7dd8337  pop rax
000078d2e7dd8338  add rsp, 0x08
000078d2e7dd833c  jmp 0x000078D2E7DD34C6
000078d2e7dd8341  sub rsp, 0x08
000078d2e7dd8345  push rax
000078d2e7dd8346  push rcx
000078d2e7dd8347  push rdx
000078d2e7dd8348  push rdi
000078d2e7dd8349  push rsi
000078d2e7dd834a  push r8
000078d2e7dd834c  push r9
000078d2e7dd834e  push r10
000078d2e7dd8350  push r11
000078d2e7dd8352  sub rsp, 0xF0
000078d2e7dd8359  vmovaps [rsp], xmm0
000078d2e7dd835e  vmovaps [rsp+0x10], xmm1
000078d2e7dd8364  vmovaps [rsp+0x20], xmm2
000078d2e7dd836a  vmovaps [rsp+0x30], xmm3
000078d2e7dd8370  vmovaps [rsp+0x40], xmm4
000078d2e7dd8376  vmovaps [rsp+0x50], xmm5
000078d2e7dd837c  vmovaps [rsp+0x60], xmm6
000078d2e7dd8382  vmovaps [rsp+0x70], xmm7
000078d2e7dd8388  vmovaps [rsp+0x80], xmm8
000078d2e7dd8391  vmovaps [rsp+0x90], xmm9
000078d2e7dd839a  vmovaps [rsp+0xA0], xmm10
000078d2e7dd83a3  vmovaps [rsp+0xB0], xmm12
000078d2e7dd83ac  vmovaps [rsp+0xC0], xmm13
000078d2e7dd83b5  vmovaps [rsp+0xD0], xmm14
000078d2e7dd83be  vmovaps [rsp+0xE0], xmm15
000078d2e7dd83c7  sub rsp, 0x30
000078d2e7dd83cb  movaps [rsp], xmm11
000078d2e7dd83d0  movaps [rsp+0x10], xmm14
000078d2e7dd83d6  movaps [rsp+0x20], xmm13
000078d2e7dd83dc  lea rdi, [rsp]
000078d2e7dd83e0  mov esi, 0x00
000078d2e7dd83e5  mov rax, 0x5997D2DB1530
000078d2e7dd83ef  call rax
000078d2e7dd83f1  movaps xmm11, [rsp]
000078d2e7dd83f6  add rsp, 0x30
000078d2e7dd83fa  vmovaps xmm0, [rsp]
000078d2e7dd83ff  vmovaps xmm1, [rsp+0x10]
000078d2e7dd8405  vmovaps xmm2, [rsp+0x20]
000078d2e7dd840b  vmovaps xmm3, [rsp+0x30]
000078d2e7dd8411  vmovaps xmm4, [rsp+0x40]
000078d2e7dd8417  vmovaps xmm5, [rsp+0x50]
000078d2e7dd841d  vmovaps xmm6, [rsp+0x60]
000078d2e7dd8423  vmovaps xmm7, [rsp+0x70]
000078d2e7dd8429  vmovaps xmm8, [rsp+0x80]
000078d2e7dd8432  vmovaps xmm9, [rsp+0x90]
000078d2e7dd843b  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd8444  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd844d  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd8456  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd845f  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd8468  add rsp, 0xF0
000078d2e7dd846f  pop r11
000078d2e7dd8471  pop r10
000078d2e7dd8473  pop r9
000078d2e7dd8475  pop r8
000078d2e7dd8477  pop rsi
000078d2e7dd8478  pop rdi
000078d2e7dd8479  pop rdx
000078d2e7dd847a  pop rcx
000078d2e7dd847b  pop rax
000078d2e7dd847c  add rsp, 0x08
000078d2e7dd8480  jmp 0x000078D2E7DD34F4
000078d2e7dd8485  sub rsp, 0x08
000078d2e7dd8489  push rax
000078d2e7dd848a  push rcx
000078d2e7dd848b  push rdx
000078d2e7dd848c  push rdi
000078d2e7dd848d  push rsi
000078d2e7dd848e  push r8
000078d2e7dd8490  push r9
000078d2e7dd8492  push r10
000078d2e7dd8494  push r11
000078d2e7dd8496  sub rsp, 0xF0
000078d2e7dd849d  vmovaps [rsp], xmm0
000078d2e7dd84a2  vmovaps [rsp+0x10], xmm1
000078d2e7dd84a8  vmovaps [rsp+0x20], xmm2
000078d2e7dd84ae  vmovaps [rsp+0x30], xmm3
000078d2e7dd84b4  vmovaps [rsp+0x40], xmm4
000078d2e7dd84ba  vmovaps [rsp+0x50], xmm5
000078d2e7dd84c0  vmovaps [rsp+0x60], xmm6
000078d2e7dd84c6  vmovaps [rsp+0x70], xmm7
000078d2e7dd84cc  vmovaps [rsp+0x80], xmm8
000078d2e7dd84d5  vmovaps [rsp+0x90], xmm9
000078d2e7dd84de  vmovaps [rsp+0xA0], xmm10
000078d2e7dd84e7  vmovaps [rsp+0xB0], xmm11
000078d2e7dd84f0  vmovaps [rsp+0xC0], xmm12
000078d2e7dd84f9  vmovaps [rsp+0xD0], xmm13
000078d2e7dd8502  vmovaps [rsp+0xE0], xmm15
000078d2e7dd850b  sub rsp, 0x30
000078d2e7dd850f  movaps [rsp], xmm14
000078d2e7dd8514  movaps [rsp+0x10], xmm12
000078d2e7dd851a  movaps [rsp+0x20], xmm9
000078d2e7dd8520  lea rdi, [rsp]
000078d2e7dd8524  mov esi, 0x00
000078d2e7dd8529  mov rax, 0x5997D2DB1530
000078d2e7dd8533  call rax
000078d2e7dd8535  movaps xmm14, [rsp]
000078d2e7dd853a  add rsp, 0x30
000078d2e7dd853e  vmovaps xmm0, [rsp]
000078d2e7dd8543  vmovaps xmm1, [rsp+0x10]
000078d2e7dd8549  vmovaps xmm2, [rsp+0x20]
000078d2e7dd854f  vmovaps xmm3, [rsp+0x30]
000078d2e7dd8555  vmovaps xmm4, [rsp+0x40]
000078d2e7dd855b  vmovaps xmm5, [rsp+0x50]
000078d2e7dd8561  vmovaps xmm6, [rsp+0x60]
000078d2e7dd8567  vmovaps xmm7, [rsp+0x70]
000078d2e7dd856d  vmovaps xmm8, [rsp+0x80]
000078d2e7dd8576  vmovaps xmm9, [rsp+0x90]
000078d2e7dd857f  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd8588  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd8591  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd859a  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd85a3  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd85ac  add rsp, 0xF0
000078d2e7dd85b3  pop r11
000078d2e7dd85b5  pop r10
000078d2e7dd85b7  pop r9
000078d2e7dd85b9  pop r8
000078d2e7dd85bb  pop rsi
000078d2e7dd85bc  pop rdi
000078d2e7dd85bd  pop rdx
000078d2e7dd85be  pop rcx
000078d2e7dd85bf  pop rax
000078d2e7dd85c0  add rsp, 0x08
000078d2e7dd85c4  jmp 0x000078D2E7DD350F
000078d2e7dd85c9  sub rsp, 0x08
000078d2e7dd85cd  push rax
000078d2e7dd85ce  push rcx
000078d2e7dd85cf  push rdx
000078d2e7dd85d0  push rdi
000078d2e7dd85d1  push rsi
000078d2e7dd85d2  push r8
000078d2e7dd85d4  push r9
000078d2e7dd85d6  push r10
000078d2e7dd85d8  push r11
000078d2e7dd85da  sub rsp, 0xF0
000078d2e7dd85e1  vmovaps [rsp], xmm0
000078d2e7dd85e6  vmovaps [rsp+0x10], xmm1
000078d2e7dd85ec  vmovaps [rsp+0x20], xmm2
000078d2e7dd85f2  vmovaps [rsp+0x30], xmm3
000078d2e7dd85f8  vmovaps [rsp+0x40], xmm4
000078d2e7dd85fe  vmovaps [rsp+0x50], xmm5
000078d2e7dd8604  vmovaps [rsp+0x60], xmm6
000078d2e7dd860a  vmovaps [rsp+0x70], xmm7
000078d2e7dd8610  vmovaps [rsp+0x80], xmm8
000078d2e7dd8619  vmovaps [rsp+0x90], xmm9
000078d2e7dd8622  vmovaps [rsp+0xA0], xmm10
000078d2e7dd862b  vmovaps [rsp+0xB0], xmm11
000078d2e7dd8634  vmovaps [rsp+0xC0], xmm12
000078d2e7dd863d  vmovaps [rsp+0xD0], xmm14
000078d2e7dd8646  vmovaps [rsp+0xE0], xmm15
000078d2e7dd864f  sub rsp, 0x30
000078d2e7dd8653  movaps [rsp], xmm13
000078d2e7dd8658  movaps [rsp+0x10], xmm8
000078d2e7dd865e  movaps [rsp+0x20], xmm15
000078d2e7dd8664  lea rdi, [rsp]
000078d2e7dd8668  mov esi, 0x00
000078d2e7dd866d  mov rax, 0x5997D2DB1530
000078d2e7dd8677  call rax
000078d2e7dd8679  movaps xmm13, [rsp]
000078d2e7dd867e  add rsp, 0x30
000078d2e7dd8682  vmovaps xmm0, [rsp]
000078d2e7dd8687  vmovaps xmm1, [rsp+0x10]
000078d2e7dd868d  vmovaps xmm2, [rsp+0x20]
000078d2e7dd8693  vmovaps xmm3, [rsp+0x30]
000078d2e7dd8699  vmovaps xmm4, [rsp+0x40]
000078d2e7dd869f  vmovaps xmm5, [rsp+0x50]
000078d2e7dd86a5  vmovaps xmm6, [rsp+0x60]
000078d2e7dd86ab  vmovaps xmm7, [rsp+0x70]
000078d2e7dd86b1  vmovaps xmm8, [rsp+0x80]
000078d2e7dd86ba  vmovaps xmm9, [rsp+0x90]
000078d2e7dd86c3  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd86cc  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd86d5  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd86de  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd86e7  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd86f0  add rsp, 0xF0
000078d2e7dd86f7  pop r11
000078d2e7dd86f9  pop r10
000078d2e7dd86fb  pop r9
000078d2e7dd86fd  pop r8
000078d2e7dd86ff  pop rsi
000078d2e7dd8700  pop rdi
000078d2e7dd8701  pop rdx
000078d2e7dd8702  pop rcx
000078d2e7dd8703  pop rax
000078d2e7dd8704  add rsp, 0x08
000078d2e7dd8708  jmp 0x000078D2E7DD3532
000078d2e7dd870d  sub rsp, 0x08
000078d2e7dd8711  push rax
000078d2e7dd8712  push rcx
000078d2e7dd8713  push rdx
000078d2e7dd8714  push rdi
000078d2e7dd8715  push rsi
000078d2e7dd8716  push r8
000078d2e7dd8718  push r9
000078d2e7dd871a  push r10
000078d2e7dd871c  push r11
000078d2e7dd871e  sub rsp, 0xF0
000078d2e7dd8725  vmovaps [rsp], xmm0
000078d2e7dd872a  vmovaps [rsp+0x10], xmm1
000078d2e7dd8730  vmovaps [rsp+0x20], xmm2
000078d2e7dd8736  vmovaps [rsp+0x30], xmm3
000078d2e7dd873c  vmovaps [rsp+0x40], xmm4
000078d2e7dd8742  vmovaps [rsp+0x50], xmm5
000078d2e7dd8748  vmovaps [rsp+0x60], xmm6
000078d2e7dd874e  vmovaps [rsp+0x70], xmm7
000078d2e7dd8754  vmovaps [rsp+0x80], xmm8
000078d2e7dd875d  vmovaps [rsp+0x90], xmm9
000078d2e7dd8766  vmovaps [rsp+0xA0], xmm10
000078d2e7dd876f  vmovaps [rsp+0xB0], xmm11
000078d2e7dd8778  vmovaps [rsp+0xC0], xmm12
000078d2e7dd8781  vmovaps [rsp+0xD0], xmm13
000078d2e7dd878a  vmovaps [rsp+0xE0], xmm14
000078d2e7dd8793  sub rsp, 0x30
000078d2e7dd8797  movaps [rsp], xmm15
000078d2e7dd879c  movaps [rsp+0x10], xmm1
000078d2e7dd87a1  movaps [rsp+0x20], xmm10
000078d2e7dd87a7  lea rdi, [rsp]
000078d2e7dd87ab  mov esi, 0x00
000078d2e7dd87b0  mov rax, 0x5997D2DB1530
000078d2e7dd87ba  call rax
000078d2e7dd87bc  movaps xmm15, [rsp]
000078d2e7dd87c1  add rsp, 0x30
000078d2e7dd87c5  vmovaps xmm0, [rsp]
000078d2e7dd87ca  vmovaps xmm1, [rsp+0x10]
000078d2e7dd87d0  vmovaps xmm2, [rsp+0x20]
000078d2e7dd87d6  vmovaps xmm3, [rsp+0x30]
000078d2e7dd87dc  vmovaps xmm4, [rsp+0x40]
000078d2e7dd87e2  vmovaps xmm5, [rsp+0x50]
000078d2e7dd87e8  vmovaps xmm6, [rsp+0x60]
000078d2e7dd87ee  vmovaps xmm7, [rsp+0x70]
000078d2e7dd87f4  vmovaps xmm8, [rsp+0x80]
000078d2e7dd87fd  vmovaps xmm9, [rsp+0x90]
000078d2e7dd8806  vmovaps xmm10, [rsp+0xA0]
000078d2e7dd880f  vmovaps xmm11, [rsp+0xB0]
000078d2e7dd8818  vmovaps xmm12, [rsp+0xC0]
000078d2e7dd8821  vmovaps xmm13, [rsp+0xD0]
000078d2e7dd882a  vmovaps xmm14, [rsp+0xE0]
000078d2e7dd8833  add rsp, 0xF0
000078d2e7dd883a  pop r11
000078d2e7dd883c  pop r10
000078d2e7dd883e  pop r9
000078d2e7dd8840  pop r8
000078d2e7dd8842  pop rsi
000078d2e7dd8843  pop rdi
000078d2e7dd8844  pop rdx
000078d2e7dd8845  pop rcx
000078d2e7dd8846  pop rax
000078d2e7dd8847  add rsp, 0x08
000078d2e7dd884b  jmp 0x000078D2E7DD3555
000078d2e7dd8850  sub rsp, 0x08
000078d2e7dd8854  push rax
000078d2e7dd8855  push rcx
000078d2e7dd8856  push rdx
000078d2e7dd8857  push rdi
000078d2e7dd8858  push rsi
000078d2e7dd8859  push r8
000078d2e7dd885b  push r9
000078d2e7dd885d  push r10
000078d2e7dd885f  push r11
000078d2e7dd8861  sub rsp, 0xF0
000078d2e7dd8868  vmovaps [rsp], xmm0
000078d2e7dd886d  vmovaps [rsp+0x10], xmm2
000078d2e7dd8873  vmovaps [rsp+0x20], xmm3
000078d2e7dd8879  vmovaps [rsp+0x30], xmm4
000078d2e7dd887f  vmovaps [rsp+0x40], xmm5
000078d2e7dd8885  vmovaps [rsp+0x50], xmm6
000078d2e7dd888b  vmovaps [rsp+0x60], xmm7
000078d2e7dd8891  vmovaps [rsp+0x70], xmm8
000078d2e7dd8897  vmovaps [rsp+0x80], xmm9
000078d2e7dd88a0  vmovaps [rsp+0x90], xmm10
000078d2e7dd88a9  vmovaps [rsp+0xA0], xmm11
000078d2e7dd88b2  vmovaps [rsp+0xB0], xmm12
000078d2e7dd88bb  vmovaps [rsp+0xC0], xmm13
000078d2e7dd88c4  vmovaps [rsp+0xD0], xmm14
000078d2e7dd88cd  vmovaps [rsp+0xE0], xmm15
000078d2e7dd88d6  sub rsp, 0x30
000078d2e7dd88da  movaps [rsp], xmm1
000078d2e7dd88de  movaps [rsp+0x10], xmm7
000078d2e7dd88e3  movaps [rsp+0x20], xmm11
000078d2e7dd88e9  lea rdi, [rsp]
000078d2e7dd88ed  mov esi, 0x00
000078d2e7dd88f2  mov rax, 0x5997D2DB1530
000078d2e7dd88fc  call rax
000078d2e7dd88fe  movaps xmm1, [rsp]
000078d2e7dd8902  add rsp, 0x30
000078d2e7dd8906  vmovaps xmm0, [rsp]
000078d2e7dd890b  vmovaps xmm2, [rsp+0x10]
000078d2e7dd8911  vmovaps xmm3, [rsp+0x20]
000078d2e7dd8917  vmovaps xmm4, [rsp+0x30]
000078d2e7dd891d  vmovaps xmm5, [rsp+0x40]
000078d2e7dd8923  vmovaps xmm6, [rsp+0x50]
000078d2e7dd8929  vmovaps xmm7, [rsp+0x60]
000078d2e7dd892f  vmovaps xmm8, [rsp+0x70]
000078d2e7dd8935  vmovaps xmm9, [rsp+0x80]
000078d2e7dd893e  vmovaps xmm10, [rsp+0x90]
000078d2e7dd8947  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd8950  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd8959  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd8962  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd896b  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd8974  add rsp, 0xF0
000078d2e7dd897b  pop r11
000078d2e7dd897d  pop r10
000078d2e7dd897f  pop r9
000078d2e7dd8981  pop r8
000078d2e7dd8983  pop rsi
000078d2e7dd8984  pop rdi
000078d2e7dd8985  pop rdx
000078d2e7dd8986  pop rcx
000078d2e7dd8987  pop rax
000078d2e7dd8988  add rsp, 0x08
000078d2e7dd898c  jmp 0x000078D2E7DD3576
000078d2e7dd8991  call 0x000078D2E7C0D600
000078d2e7dd8996  jmp 0x000078D2E7DD3589
000078d2e7dd899b  call 0x000078D2E7C0C380
000078d2e7dd89a0  jmp 0x000078D2E7DD3594
000078d2e7dd89a5  call 0x000078D2E7C0E880
000078d2e7dd89aa  jmp 0x000078D2E7DD359F
000078d2e7dd89af  call 0x000078D2E7BFF540
000078d2e7dd89b4  jmp 0x000078D2E7DD35AA
000078d2e7dd89b9  int3
000078d2e7dd89ba  nop [rax+rax*1], ax
000078d2e7dd89c0  mov rax, [r15+0x40]
000078d2e7dd89c4  mov r14, [r15+0x58]
000078d2e7dd89c8  lea r12, [rax+r14*1]
000078d2e7dd89cc  movaps xmm1, [r15+0x1D0]
000078d2e7dd89d4  vmovaps [rsp+0x10], xmm1
000078d2e7dd89da  vmovaps xmm15, [rsp+0x10]
000078d2e7dd89e0  por xmm1, xmm15
000078d2e7dd89e5  movaps xmm14, [r15+0x1A0]
000078d2e7dd89ed  vmovaps [rsp+0x10], xmm14
000078d2e7dd89f3  vmovaps xmm13, [rsp+0x10]
000078d2e7dd89f9  por xmm14, xmm13
000078d2e7dd89fe  lea rax, [r12+0x30]
000078d2e7dd8a03  mov r11, [r13+rax*1]
000078d2e7dd8a08  lea rax, [r12+0x38]
000078d2e7dd8a0d  mov r10, [r13+rax*1]
000078d2e7dd8a12  movq xmm13, r11
000078d2e7dd8a17  movq xmm12, r10
000078d2e7dd8a1c  movq xmm13, xmm13
000078d2e7dd8a21  vmovaps [rsp+0x10], xmm13
000078d2e7dd8a27  movq xmm13, xmm13
000078d2e7dd8a2c  movaps [r15+0x130], xmm13
000078d2e7dd8a34  movq xmm12, xmm12
000078d2e7dd8a39  vmovaps [rsp+0x20], xmm12
000078d2e7dd8a3f  movq xmm12, xmm12
000078d2e7dd8a44  movaps [r15+0x280], xmm12
000078d2e7dd8a4c  movaps xmm13, [r15+0x270]
000078d2e7dd8a54  vmovaps [rsp+0x30], xmm13
000078d2e7dd8a5a  vmovaps xmm12, [rsp+0x30]
000078d2e7dd8a60  por xmm13, xmm12
000078d2e7dd8a65  lea rax, [r12+0x20]
000078d2e7dd8a6a  mov r11, [r13+rax*1]
000078d2e7dd8a6f  lea rax, [r12+0x28]
000078d2e7dd8a74  mov r10, [r13+rax*1]
000078d2e7dd8a79  movq xmm12, r11
000078d2e7dd8a7e  movq xmm11, r10
000078d2e7dd8a83  movq xmm12, xmm12
000078d2e7dd8a88  vmovaps [rsp+0x30], xmm12
000078d2e7dd8a8e  movq xmm12, xmm12
000078d2e7dd8a93  movaps [r15+0x150], xmm12
000078d2e7dd8a9b  movq xmm11, xmm11
000078d2e7dd8aa0  vmovaps [rsp+0x40], xmm11
000078d2e7dd8aa6  movq xmm11, xmm11
000078d2e7dd8aab  movaps [r15+0x140], xmm11
000078d2e7dd8ab3  lea rax, [r12+0x10]
000078d2e7dd8ab8  mov r11, [r13+rax*1]
000078d2e7dd8abd  lea rax, [r12+0x18]
000078d2e7dd8ac2  mov r10, [r13+rax*1]
000078d2e7dd8ac7  movq xmm12, r11
000078d2e7dd8acc  movq xmm11, r10
000078d2e7dd8ad1  movq xmm12, xmm12
000078d2e7dd8ad6  vmovaps [rsp+0x50], xmm12
000078d2e7dd8adc  movq xmm12, xmm12
000078d2e7dd8ae1  movaps [r15+0x170], xmm12
000078d2e7dd8ae9  movq xmm11, xmm11
000078d2e7dd8aee  vmovaps [rsp+0x60], xmm11
000078d2e7dd8af4  movq xmm11, xmm11
000078d2e7dd8af9  movaps [r15+0x160], xmm11
000078d2e7dd8b01  mov rax, [r13+r12*1]
000078d2e7dd8b06  vmovq xmm12, rax
000078d2e7dd8b0b  vpbroadcastq xmm12, xmm12
000078d2e7dd8b10  lea rax, [r12+0x08]
000078d2e7dd8b15  mov r12, [r13+rax*1]
000078d2e7dd8b1a  movq xmm11, r12
000078d2e7dd8b1f  movaps [r15+0x230], xmm11
000078d2e7dd8b27  mov rax, [r15+0xF8]
000078d2e7dd8b2e  lea r12, [rax+0x50]
000078d2e7dd8b32  movups xmm11, [r13+r12*1]
000078d2e7dd8b38  lea r12, [rax+0x60]
000078d2e7dd8b3c  movups xmm10, [r13+r12*1]
000078d2e7dd8b42  lea r12, [rax+0x30]
000078d2e7dd8b46  movups xmm9, [r13+r12*1]
000078d2e7dd8b4c  mov r12, [r15+0x50]
000078d2e7dd8b50  lea r11, [r12+r14*1]
000078d2e7dd8b54  mov [r15+0x60], r11
000078d2e7dd8b58  lea r12, [r14+0x40]
000078d2e7dd8b5c  mov [r15+0x58], r12
000078d2e7dd8b60  movaps xmm8, xmm12
000078d2e7dd8b64  mulpd xmm8, xmm15
000078d2e7dd8b69  vcmppd xmm7, xmm8, xmm8, 0x03
000078d2e7dd8b6f  ptest xmm7, xmm7
000078d2e7dd8b74  jnz 0x000078D2E7DD9997
000078d2e7dd8b7a  movq xmm15, qword ptr [r15+0x230]
000078d2e7dd8b83  vmovaps [rsp+0x70], xmm15
000078d2e7dd8b89  vpermilpd xmm15, xmm15, 0x00
000078d2e7dd8b8f  movaps xmm7, xmm9
000078d2e7dd8b93  mulpd xmm7, xmm15
000078d2e7dd8b98  vcmppd xmm6, xmm7, xmm7, 0x03
000078d2e7dd8b9d  ptest xmm6, xmm6
000078d2e7dd8ba2  jnz 0x000078D2E7DD9ADB
000078d2e7dd8ba8  vxorps xmm15, xmm15, xmm15
000078d2e7dd8bad  vpbroadcastq xmm15, xmm15
000078d2e7dd8bb2  movaps xmm9, xmm12
000078d2e7dd8bb6  mulpd xmm9, xmm10
000078d2e7dd8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
000078d2e7dd8bc1  ptest xmm6, xmm6
000078d2e7dd8bc6  jnz 0x000078D2E7DD9C1D
000078d2e7dd8bcc  movaps xmm10, xmm12
000078d2e7dd8bd0  mulpd xmm10, xmm11
000078d2e7dd8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
000078d2e7dd8bdb  ptest xmm6, xmm6
000078d2e7dd8be0  jnz 0x000078D2E7DD9D61
000078d2e7dd8be6  movaps xmm11, [r15+0x1F0]
000078d2e7dd8bee  movaps xmm6, xmm12
000078d2e7dd8bf2  mulpd xmm6, xmm11
000078d2e7dd8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
000078d2e7dd8bfc  ptest xmm5, xmm5
000078d2e7dd8c01  jnz 0x000078D2E7DD9EA5
000078d2e7dd8c07  movaps xmm12, [r15+0x2A0]
000078d2e7dd8c0f  vmovaps [rsp+0x80], xmm12
000078d2e7dd8c18  vmovaps xmm11, [rsp+0x80]
000078d2e7dd8c21  por xmm12, xmm11
000078d2e7dd8c26  movaps xmm11, [r15+0x250]
000078d2e7dd8c2e  vmovaps [rsp+0x80], xmm11
000078d2e7dd8c37  vmovaps xmm5, [rsp+0x80]
000078d2e7dd8c40  por xmm11, xmm5
000078d2e7dd8c45  vmovaps xmm4, [rsp+0x70]
000078d2e7dd8c4b  vpermilpd xmm4, xmm4, 0x00
000078d2e7dd8c51  movaps xmm3, xmm5
000078d2e7dd8c54  mulpd xmm3, xmm4
000078d2e7dd8c58  vcmppd xmm2, xmm3, xmm3, 0x03
000078d2e7dd8c5d  ptest xmm2, xmm2
000078d2e7dd8c62  jnz 0x000078D2E7DD9FE7
000078d2e7dd8c68  mov [rsp+0x80], rax
000078d2e7dd8c70  xor eax, eax
000078d2e7dd8c72  mov r14d, 0x200
000078d2e7dd8c78  cmp r12, r14
000078d2e7dd8c7b  cmc
000078d2e7dd8c7c  lahf
000078d2e7dd8c7d  seto al
000078d2e7dd8c80  mov [r15+0x108], eax
000078d2e7dd8c87  movaps xmm5, xmm8
000078d2e7dd8c8b  addpd xmm5, xmm15
000078d2e7dd8c90  vcmppd xmm4, xmm5, xmm5, 0x03
000078d2e7dd8c95  ptest xmm4, xmm4
000078d2e7dd8c9a  jnz 0x000078D2E7DDA127
000078d2e7dd8ca0  movaps xmm8, [r15+0x1B0]
000078d2e7dd8ca8  movaps xmm4, xmm9
000078d2e7dd8cac  addpd xmm4, xmm8
000078d2e7dd8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
000078d2e7dd8cb6  ptest xmm2, xmm2
000078d2e7dd8cbb  jnz 0x000078D2E7DDA269
000078d2e7dd8cc1  movaps xmm9, xmm10
000078d2e7dd8cc5  addpd xmm9, xmm8
000078d2e7dd8cca  vcmppd xmm2, xmm9, xmm9, 0x03
000078d2e7dd8cd0  ptest xmm2, xmm2
000078d2e7dd8cd5  jnz 0x000078D2E7DDA3AB
000078d2e7dd8cdb  movaps xmm10, [r15+0x2F0]
000078d2e7dd8ce3  vmovaps [rsp+0x90], xmm10
000078d2e7dd8cec  vmovaps xmm8, [rsp+0x90]
000078d2e7dd8cf5  por xmm10, xmm8
000078d2e7dd8cfa  movaps xmm8, [r15+0x2E0]
000078d2e7dd8d02  vmovaps [rsp+0x90], xmm8
000078d2e7dd8d0b  vmovaps xmm2, [rsp+0x90]
000078d2e7dd8d14  por xmm8, xmm2
000078d2e7dd8d19  movaps xmm2, [r15+0x2D0]
000078d2e7dd8d21  vmovaps [rsp+0x90], xmm2
000078d2e7dd8d2a  vmovaps [rsp+0xA0], xmm1
000078d2e7dd8d33  vmovaps xmm1, [rsp+0x90]
000078d2e7dd8d3c  por xmm2, xmm1
000078d2e7dd8d40  movaps xmm1, [r15+0x200]
000078d2e7dd8d48  vmovaps [rsp+0x90], xmm1
000078d2e7dd8d51  vmovaps [rsp+0xB0], xmm15
000078d2e7dd8d5a  vmovaps xmm15, [rsp+0x90]
000078d2e7dd8d63  por xmm1, xmm15
000078d2e7dd8d68  movaps xmm15, [r15+0x1C0]
000078d2e7dd8d70  vmovaps [rsp+0x90], xmm15
000078d2e7dd8d79  vmovaps [rsp+0xC0], xmm1
000078d2e7dd8d82  vmovaps xmm1, [rsp+0x90]
000078d2e7dd8d8b  por xmm15, xmm1
000078d2e7dd8d90  movaps xmm1, [r15+0x190]
000078d2e7dd8d98  vmovaps [rsp+0x90], xmm1
000078d2e7dd8da1  vmovaps [rsp+0xD0], xmm15
000078d2e7dd8daa  vmovaps xmm15, [rsp+0x90]
000078d2e7dd8db3  por xmm1, xmm15
000078d2e7dd8db8  movaps xmm15, [r15+0x300]
000078d2e7dd8dc0  vmovaps [rsp+0x90], xmm15
000078d2e7dd8dc9  vmovaps [rsp+0xE0], xmm1
000078d2e7dd8dd2  vmovaps xmm1, [rsp+0x90]
000078d2e7dd8ddb  por xmm15, xmm1
000078d2e7dd8de0  mov rax, [rsp+0x80]
000078d2e7dd8de8  lea r14, [rax+0xA0]
000078d2e7dd8def  movups xmm1, [r13+r14*1]
000078d2e7dd8df5  lea r14, [rax+0xB0]
000078d2e7dd8dfc  vmovaps [rsp+0x80], xmm1
000078d2e7dd8e05  movups xmm1, [r13+r14*1]
000078d2e7dd8e0b  vmovaps [rsp+0x90], xmm1
000078d2e7dd8e14  vmovaps [rsp+0xF0], xmm15
000078d2e7dd8e1d  vmovaps xmm15, [rsp+0xB0]
000078d2e7dd8e26  vmovaps [rsp+0xB0], xmm14
000078d2e7dd8e2f  movaps xmm1, xmm6
000078d2e7dd8e32  addpd xmm1, xmm15
000078d2e7dd8e37  vcmppd xmm14, xmm1, xmm1, 0x03
000078d2e7dd8e3c  ptest xmm14, xmm14
000078d2e7dd8e42  jnz 0x000078D2E7DDA503
000078d2e7dd8e48  lea r14, [rax+0xF0]
000078d2e7dd8e4f  movups xmm15, [r13+r14*1]
000078d2e7dd8e55  movaps xmm14, xmm4
000078d2e7dd8e59  addpd xmm14, xmm3
000078d2e7dd8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
000078d2e7dd8e64  ptest xmm6, xmm6
000078d2e7dd8e69  jnz 0x000078D2E7DDA64E
000078d2e7dd8e6f  movaps xmm6, xmm9
000078d2e7dd8e73  addpd xmm6, xmm7
000078d2e7dd8e77  vcmppd xmm4, xmm6, xmm6, 0x03
000078d2e7dd8e7c  ptest xmm4, xmm4
000078d2e7dd8e81  jnz 0x000078D2E7DDA790
000078d2e7dd8e87  vmovaps xmm9, [rsp+0x70]
000078d2e7dd8e8d  vpermilpd xmm9, xmm9, 0x00
000078d2e7dd8e93  vmovaps xmm4, [rsp+0x90]
000078d2e7dd8e9c  movaps xmm7, xmm4
000078d2e7dd8e9f  mulpd xmm7, xmm9
000078d2e7dd8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
000078d2e7dd8ea9  ptest xmm3, xmm3
000078d2e7dd8eae  jnz 0x000078D2E7DDA8D1
000078d2e7dd8eb4  vmovaps xmm9, [rsp+0x50]
000078d2e7dd8eba  vpermilpd xmm9, xmm9, 0x00
000078d2e7dd8ec0  movaps xmm4, xmm15
000078d2e7dd8ec4  mulpd xmm4, xmm9
000078d2e7dd8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
000078d2e7dd8ece  ptest xmm3, xmm3
000078d2e7dd8ed3  jnz 0x000078D2E7DDAA12
000078d2e7dd8ed9  lea r14, [rax+0xE0]
000078d2e7dd8ee0  movups xmm15, [r13+r14*1]
000078d2e7dd8ee6  vmovaps xmm9, [rsp+0x70]
000078d2e7dd8eec  vpermilpd xmm9, xmm9, 0x00
000078d2e7dd8ef2  vmovaps [rsp+0x70], xmm1
000078d2e7dd8ef8  vmovaps xmm1, [rsp+0x80]
000078d2e7dd8f01  vmovaps [rsp+0x80], xmm15
000078d2e7dd8f0a  movaps xmm3, xmm1
000078d2e7dd8f0d  mulpd xmm3, xmm9
000078d2e7dd8f12  vcmppd xmm15, xmm3, xmm3, 0x03
000078d2e7dd8f17  ptest xmm15, xmm15
000078d2e7dd8f1d  jnz 0x000078D2E7DDAB5E
000078d2e7dd8f23  vmovaps xmm1, [rsp+0xF0]
000078d2e7dd8f2c  vmovaps xmm15, [rsp+0xF0]
000078d2e7dd8f35  por xmm1, xmm15
000078d2e7dd8f3a  movaps [r15+0x300], xmm1
000078d2e7dd8f42  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd8f4b  vmovaps xmm9, [rsp+0xE0]
000078d2e7dd8f54  por xmm15, xmm9
000078d2e7dd8f59  movaps [r15+0x190], xmm15
000078d2e7dd8f61  vmovaps xmm9, [rsp+0x50]
000078d2e7dd8f67  vpermilpd xmm9, xmm9, 0x00
000078d2e7dd8f6d  vmovaps [rsp+0x90], xmm1
000078d2e7dd8f76  vmovaps [rsp+0xE0], xmm15
000078d2e7dd8f7f  vmovaps xmm15, [rsp+0x80]
000078d2e7dd8f88  vmovaps [rsp+0x80], xmm14
000078d2e7dd8f91  movaps xmm1, xmm15
000078d2e7dd8f95  mulpd xmm1, xmm9
000078d2e7dd8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
000078d2e7dd8f9f  ptest xmm14, xmm14
000078d2e7dd8fa5  jnz 0x000078D2E7DDAC9F
000078d2e7dd8fab  lea r14, [rax+0x90]
000078d2e7dd8fb2  movups xmm15, [r13+r14*1]
000078d2e7dd8fb8  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd8fc1  vmovaps xmm9, [rsp+0xD0]
000078d2e7dd8fca  por xmm14, xmm9
000078d2e7dd8fcf  movaps [r15+0x1C0], xmm14
000078d2e7dd8fd7  vmovaps xmm9, [rsp+0xC0]
000078d2e7dd8fe0  vmovaps [rsp+0xD0], xmm1
000078d2e7dd8fe9  vmovaps xmm1, [rsp+0xC0]
000078d2e7dd8ff2  por xmm9, xmm1
000078d2e7dd8ff7  movaps [r15+0x200], xmm9
000078d2e7dd8fff  vmovaps [rsp+0xC0], xmm2
000078d2e7dd9008  vmovaps xmm1, [rsp+0xC0]
000078d2e7dd9011  por xmm2, xmm1
000078d2e7dd9015  movaps [r15+0x2D0], xmm2
000078d2e7dd901d  vmovaps [rsp+0xC0], xmm8
000078d2e7dd9026  vmovaps xmm1, [rsp+0xC0]
000078d2e7dd902f  por xmm8, xmm1
000078d2e7dd9034  movaps [r15+0x2E0], xmm8
000078d2e7dd903c  vmovaps [rsp+0xC0], xmm15
000078d2e7dd9045  movaps xmm1, xmm5
000078d2e7dd9048  addpd xmm1, xmm7
000078d2e7dd904c  vcmppd xmm15, xmm1, xmm1, 0x03
000078d2e7dd9051  ptest xmm15, xmm15
000078d2e7dd9057  jnz 0x000078D2E7DDADEB
000078d2e7dd905d  vmovaps xmm15, [rsp+0x50]
000078d2e7dd9063  vpermilpd xmm15, xmm15, 0x00
000078d2e7dd9069  vmovaps xmm5, [rsp+0xC0]
000078d2e7dd9072  vmovaps [rsp+0xC0], xmm1
000078d2e7dd907b  movaps xmm7, xmm5
000078d2e7dd907e  mulpd xmm7, xmm15
000078d2e7dd9083  vcmppd xmm1, xmm7, xmm7, 0x03
000078d2e7dd9088  ptest xmm1, xmm1
000078d2e7dd908d  jnz 0x000078D2E7DDAF2B
000078d2e7dd9093  lea r14, [rax+0x80]
000078d2e7dd909a  movups xmm1, [r13+r14*1]
000078d2e7dd90a0  vmovaps xmm5, [rsp+0x70]
000078d2e7dd90a6  vmovaps [rsp+0x70], xmm1
000078d2e7dd90ac  movaps xmm15, xmm5
000078d2e7dd90b0  addpd xmm15, xmm3
000078d2e7dd90b5  vcmppd xmm1, xmm15, xmm15, 0x03
000078d2e7dd90bb  ptest xmm1, xmm1
000078d2e7dd90c0  jnz 0x000078D2E7DDB076
000078d2e7dd90c6  vmovaps xmm5, [rsp+0x80]
000078d2e7dd90cf  movaps xmm1, xmm5
000078d2e7dd90d2  addpd xmm1, xmm4
000078d2e7dd90d6  vcmppd xmm3, xmm1, xmm1, 0x03
000078d2e7dd90db  ptest xmm3, xmm3
000078d2e7dd90e0  jnz 0x000078D2E7DDB1B8
000078d2e7dd90e6  vmovaps [rsp+0x80], xmm10
000078d2e7dd90ef  vmovaps xmm5, [rsp+0x80]
000078d2e7dd90f8  por xmm10, xmm5
000078d2e7dd90fd  movaps [r15+0x2F0], xmm10
000078d2e7dd9105  vmovaps xmm5, [rsp+0x50]
000078d2e7dd910b  vpermilpd xmm5, xmm5, 0x00
000078d2e7dd9111  vmovaps xmm3, [rsp+0x70]
000078d2e7dd9117  vmovaps [rsp+0x50], xmm1
000078d2e7dd911d  movaps xmm4, xmm3
000078d2e7dd9120  mulpd xmm4, xmm5
000078d2e7dd9124  vcmppd xmm1, xmm4, xmm4, 0x03
000078d2e7dd9129  ptest xmm1, xmm1
000078d2e7dd912e  jnz 0x000078D2E7DDB2F8
000078d2e7dd9134  lea r14, [rax+0xD0]
000078d2e7dd913b  movups xmm1, [r13+r14*1]
000078d2e7dd9141  vmovaps xmm3, [rsp+0xD0]
000078d2e7dd914a  vmovaps [rsp+0x70], xmm1
000078d2e7dd9150  movaps xmm5, xmm6
000078d2e7dd9153  addpd xmm5, xmm3
000078d2e7dd9157  vcmppd xmm1, xmm5, xmm5, 0x03
000078d2e7dd915c  ptest xmm1, xmm1
000078d2e7dd9161  jnz 0x000078D2E7DDB442
000078d2e7dd9167  vmovaps xmm1, [rsp+0x60]
000078d2e7dd916d  vpermilpd xmm1, xmm1, 0x00
000078d2e7dd9173  movaps xmm6, xmm9
000078d2e7dd9177  mulpd xmm6, xmm1
000078d2e7dd917b  vcmppd xmm3, xmm6, xmm6, 0x03
000078d2e7dd9180  ptest xmm3, xmm3
000078d2e7dd9185  jnz 0x000078D2E7DDB582
000078d2e7dd918b  movaps [r15+0x260], xmm6
000078d2e7dd9193  vxorps xmm1, xmm1, xmm1
000078d2e7dd9197  vpbroadcastq xmm1, xmm1
000078d2e7dd919c  movaps [r15+0x1B0], xmm1
000078d2e7dd91a4  vmovaps xmm1, [rsp+0x60]
000078d2e7dd91aa  vpermilpd xmm1, xmm1, 0x00
000078d2e7dd91b0  vmovaps xmm3, [rsp+0x70]
000078d2e7dd91b6  vmovaps [rsp+0x70], xmm15
000078d2e7dd91bc  movaps xmm9, xmm3
000078d2e7dd91c0  mulpd xmm9, xmm1
000078d2e7dd91c5  vcmppd xmm15, xmm9, xmm9, 0x03
000078d2e7dd91cb  ptest xmm15, xmm15
000078d2e7dd91d1  jnz 0x000078D2E7DDB6C3
000078d2e7dd91d7  lea r14, [rax+0xC0]
000078d2e7dd91de  movups xmm1, [r13+r14*1]
000078d2e7dd91e4  vmovaps xmm3, [rsp+0xC0]
000078d2e7dd91ed  vmovaps [rsp+0x80], xmm1
000078d2e7dd91f6  movaps xmm15, xmm3
000078d2e7dd91fa  addpd xmm15, xmm7
000078d2e7dd91ff  vcmppd xmm1, xmm15, xmm15, 0x03
000078d2e7dd9205  ptest xmm1, xmm1
000078d2e7dd920a  jnz 0x000078D2E7DDB80F
000078d2e7dd9210  vmovaps [rsp+0xC0], xmm13
000078d2e7dd9219  vmovaps xmm1, [rsp+0xC0]
000078d2e7dd9222  por xmm13, xmm1
000078d2e7dd9227  movaps [r15+0x270], xmm13
000078d2e7dd922f  vmovaps xmm1, [rsp+0xB0]
000078d2e7dd9238  vmovaps xmm7, [rsp+0xB0]
000078d2e7dd9241  por xmm1, xmm7
000078d2e7dd9245  movaps [r15+0x1A0], xmm1
000078d2e7dd924d  vmovaps xmm1, [rsp+0x60]
000078d2e7dd9253  vpermilpd xmm1, xmm1, 0x00
000078d2e7dd9259  vmovaps [rsp+0xB0], xmm1
000078d2e7dd9262  vmovaps xmm1, [rsp+0x80]
000078d2e7dd926b  vmovaps [rsp+0x80], xmm15
000078d2e7dd9274  vmovaps xmm15, [rsp+0xB0]
000078d2e7dd927d  vmovaps [rsp+0xB0], xmm14
000078d2e7dd9286  movaps xmm3, xmm1
000078d2e7dd9289  mulpd xmm3, xmm15
000078d2e7dd928e  vcmppd xmm14, xmm3, xmm3, 0x03
000078d2e7dd9293  ptest xmm14, xmm14
000078d2e7dd9299  jnz 0x000078D2E7DDB951
000078d2e7dd929f  lea r14, [rax+0x20]
000078d2e7dd92a3  movups xmm1, [r13+r14*1]
000078d2e7dd92a9  movaps [r15+0x110], xmm1
000078d2e7dd92b1  vmovaps xmm14, [rsp+0x70]
000078d2e7dd92b7  vmovaps [rsp+0x70], xmm1
000078d2e7dd92bd  movaps xmm15, xmm14
000078d2e7dd92c1  addpd xmm15, xmm4
000078d2e7dd92c6  vcmppd xmm1, xmm15, xmm15, 0x03
000078d2e7dd92cc  ptest xmm1, xmm1
000078d2e7dd92d1  jnz 0x000078D2E7DDBA9C
000078d2e7dd92d7  vmovaps xmm1, [rsp+0x60]
000078d2e7dd92dd  vpermilpd xmm1, xmm1, 0x00
000078d2e7dd92e3  movaps xmm14, xmm2
000078d2e7dd92e7  mulpd xmm14, xmm1
000078d2e7dd92ec  vcmppd xmm4, xmm14, xmm14, 0x03
000078d2e7dd92f2  ptest xmm4, xmm4
000078d2e7dd92f7  jnz 0x000078D2E7DDBBDF
000078d2e7dd92fd  vmovaps xmm4, [rsp+0x50]
000078d2e7dd9303  movaps xmm1, xmm4
000078d2e7dd9306  addpd xmm1, xmm9
000078d2e7dd930b  vcmppd xmm2, xmm1, xmm1, 0x03
000078d2e7dd9310  ptest xmm2, xmm2
000078d2e7dd9315  jnz 0x000078D2E7DDBD21
000078d2e7dd931b  vmovaps xmm9, [rsp+0x30]
000078d2e7dd9321  vpermilpd xmm9, xmm9, 0x00
000078d2e7dd9327  vmovaps xmm2, [rsp+0x70]
000078d2e7dd932d  vmovaps [rsp+0x50], xmm1
000078d2e7dd9333  movaps xmm4, xmm2
000078d2e7dd9336  mulpd xmm4, xmm9
000078d2e7dd933b  vcmppd xmm1, xmm4, xmm4, 0x03
000078d2e7dd9340  ptest xmm1, xmm1
000078d2e7dd9345  jnz 0x000078D2E7DDBE62
000078d2e7dd934b  vmovaps xmm1, [rsp+0x30]
000078d2e7dd9351  vpermilpd xmm1, xmm1, 0x00
000078d2e7dd9357  vmovaps xmm2, [rsp+0x90]
000078d2e7dd9360  vmovaps [rsp+0x60], xmm15
000078d2e7dd9366  movaps xmm9, xmm2
000078d2e7dd936a  mulpd xmm9, xmm1
000078d2e7dd936f  vcmppd xmm15, xmm9, xmm9, 0x03
000078d2e7dd9375  ptest xmm15, xmm15
000078d2e7dd937b  jnz 0x000078D2E7DDBFA3
000078d2e7dd9381  vmovaps xmm15, [rsp+0x80]
000078d2e7dd938a  movaps xmm1, xmm15
000078d2e7dd938e  addpd xmm1, xmm6
000078d2e7dd9392  vcmppd xmm2, xmm1, xmm1, 0x03
000078d2e7dd9397  ptest xmm2, xmm2
000078d2e7dd939c  jnz 0x000078D2E7DDC0E5
000078d2e7dd93a2  movaps xmm15, xmm5
000078d2e7dd93a6  addpd xmm15, xmm3
000078d2e7dd93ab  vcmppd xmm6, xmm15, xmm15, 0x03
000078d2e7dd93b1  ptest xmm6, xmm6
000078d2e7dd93b6  jnz 0x000078D2E7DDC226
000078d2e7dd93bc  vmovaps xmm6, [rsp+0x30]
000078d2e7dd93c2  vpermilpd xmm6, xmm6, 0x00
000078d2e7dd93c8  movaps xmm5, xmm8
000078d2e7dd93cc  mulpd xmm5, xmm6
000078d2e7dd93d0  vcmppd xmm3, xmm5, xmm5, 0x03
000078d2e7dd93d5  ptest xmm3, xmm3
000078d2e7dd93da  jnz 0x000078D2E7DDC368
000078d2e7dd93e0  vmovaps xmm8, [rsp+0x30]
000078d2e7dd93e6  vpermilpd xmm8, xmm8, 0x00
000078d2e7dd93ec  movaps xmm6, xmm10
000078d2e7dd93f0  mulpd xmm6, xmm8
000078d2e7dd93f5  vcmppd xmm3, xmm6, xmm6, 0x03
000078d2e7dd93fa  ptest xmm3, xmm3
000078d2e7dd93ff  jnz 0x000078D2E7DDC4A9
000078d2e7dd9405  vmovaps xmm8, [rsp+0x60]
000078d2e7dd940b  movaps xmm10, xmm8
000078d2e7dd940f  addpd xmm10, xmm14
000078d2e7dd9414  vcmppd xmm3, xmm10, xmm10, 0x03
000078d2e7dd941a  ptest xmm3, xmm3
000078d2e7dd941f  jnz 0x000078D2E7DDC5EB
000078d2e7dd9425  vmovaps xmm8, [rsp+0x50]
000078d2e7dd942b  movaps xmm14, xmm8
000078d2e7dd942f  addpd xmm14, xmm4
000078d2e7dd9434  vcmppd xmm3, xmm14, xmm14, 0x03
000078d2e7dd943a  ptest xmm3, xmm3
000078d2e7dd943f  jnz 0x000078D2E7DDC72F
000078d2e7dd9445  vmovaps xmm8, [rsp+0x40]
000078d2e7dd944b  vpermilpd xmm8, xmm8, 0x00
000078d2e7dd9451  movaps xmm4, xmm13
000078d2e7dd9455  mulpd xmm4, xmm8
000078d2e7dd945a  vcmppd xmm3, xmm4, xmm4, 0x03
000078d2e7dd945f  ptest xmm3, xmm3
000078d2e7dd9464  jnz 0x000078D2E7DDC872
000078d2e7dd946a  movaps xmm13, xmm15
000078d2e7dd946e  addpd xmm13, xmm9
000078d2e7dd9473  vcmppd xmm8, xmm13, xmm13, 0x03
000078d2e7dd9479  ptest xmm8, xmm8
000078d2e7dd947f  jnz 0x000078D2E7DDC9B4
000078d2e7dd9485  movaps xmm15, xmm1
000078d2e7dd9489  addpd xmm15, xmm5
000078d2e7dd948e  vcmppd xmm9, xmm15, xmm15, 0x03
000078d2e7dd9494  ptest xmm9, xmm9
000078d2e7dd949a  jnz 0x000078D2E7DDCAF8
000078d2e7dd94a0  vmovaps [rsp+0x30], xmm11
000078d2e7dd94a6  vmovaps xmm1, [rsp+0x30]
000078d2e7dd94ac  por xmm11, xmm1
000078d2e7dd94b1  movaps [r15+0x250], xmm11
000078d2e7dd94b9  vmovaps [rsp+0x30], xmm12
000078d2e7dd94bf  vmovaps xmm1, [rsp+0x30]
000078d2e7dd94c5  por xmm12, xmm1
000078d2e7dd94ca  movaps [r15+0x2A0], xmm12
000078d2e7dd94d2  vmovaps xmm1, [rsp+0xA0]
000078d2e7dd94db  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd94e4  por xmm1, xmm11
000078d2e7dd94e9  movaps [r15+0x1D0], xmm1
000078d2e7dd94f1  lea r14, [rax+0x40]
000078d2e7dd94f5  movups xmm1, [r13+r14*1]
000078d2e7dd94fb  movaps [r15+0x2C0], xmm1
000078d2e7dd9503  vmovaps xmm11, [rsp+0x40]
000078d2e7dd9509  vpermilpd xmm11, xmm11, 0x00
000078d2e7dd950f  vmovaps xmm8, [rsp+0xE0]
000078d2e7dd9518  movaps xmm9, xmm8
000078d2e7dd951c  mulpd xmm9, xmm11
000078d2e7dd9521  vcmppd xmm5, xmm9, xmm9, 0x03
000078d2e7dd9527  ptest xmm5, xmm5
000078d2e7dd952c  jnz 0x000078D2E7DDCC44
000078d2e7dd9532  movaps xmm11, xmm10
000078d2e7dd9536  addpd xmm11, xmm6
000078d2e7dd953b  vcmppd xmm8, xmm11, xmm11, 0x03
000078d2e7dd9541  ptest xmm8, xmm8
000078d2e7dd9547  jnz 0x000078D2E7DDCD88
000078d2e7dd954d  movaps xmm10, xmm14
000078d2e7dd9551  addpd xmm10, xmm4
000078d2e7dd9556  vcmppd xmm8, xmm10, xmm10, 0x03
000078d2e7dd955c  ptest xmm8, xmm8
000078d2e7dd9562  jnz 0x000078D2E7DDCECB
000078d2e7dd9568  vmovaps xmm14, [rsp+0x40]
000078d2e7dd956e  vpermilpd xmm14, xmm14, 0x00
000078d2e7dd9574  movaps xmm8, xmm1
000078d2e7dd9578  mulpd xmm8, xmm14
000078d2e7dd957d  vcmppd xmm6, xmm8, xmm8, 0x03
000078d2e7dd9583  ptest xmm6, xmm6
000078d2e7dd9588  jnz 0x000078D2E7DDD00E
000078d2e7dd958e  movaps xmm1, [r15+0x2B0]
000078d2e7dd9596  vmovaps xmm14, [rsp+0x40]
000078d2e7dd959c  vpermilpd xmm14, xmm14, 0x00
000078d2e7dd95a2  movaps xmm6, xmm1
000078d2e7dd95a5  mulpd xmm6, xmm14
000078d2e7dd95aa  vcmppd xmm5, xmm6, xmm6, 0x03
000078d2e7dd95af  ptest xmm5, xmm5
000078d2e7dd95b4  jnz 0x000078D2E7DDD151
000078d2e7dd95ba  vmovaps xmm1, [rsp+0x10]
000078d2e7dd95c0  vpermilpd xmm1, xmm1, 0x00
000078d2e7dd95c6  movaps xmm14, xmm12
000078d2e7dd95ca  mulpd xmm14, xmm1
000078d2e7dd95cf  vcmppd xmm5, xmm14, xmm14, 0x03
000078d2e7dd95d5  ptest xmm5, xmm5
000078d2e7dd95da  jnz 0x000078D2E7DDD292
000078d2e7dd95e0  movaps xmm1, xmm13
000078d2e7dd95e4  addpd xmm1, xmm9
000078d2e7dd95e9  vcmppd xmm12, xmm1, xmm1, 0x03
000078d2e7dd95ee  ptest xmm12, xmm12
000078d2e7dd95f4  jnz 0x000078D2E7DDD3D5
000078d2e7dd95fa  vmovaps xmm13, [rsp+0x10]
000078d2e7dd9600  vpermilpd xmm13, xmm13, 0x00
000078d2e7dd9606  movaps xmm12, xmm7
000078d2e7dd960a  mulpd xmm12, xmm13
000078d2e7dd960f  vcmppd xmm9, xmm12, xmm12, 0x03
000078d2e7dd9615  ptest xmm9, xmm9
000078d2e7dd961b  jnz 0x000078D2E7DDD517
000078d2e7dd9621  movaps xmm13, xmm15
000078d2e7dd9625  addpd xmm13, xmm8
000078d2e7dd962a  vcmppd xmm9, xmm13, xmm13, 0x03
000078d2e7dd9630  ptest xmm9, xmm9
000078d2e7dd9636  jnz 0x000078D2E7DDD65A
000078d2e7dd963c  movaps xmm15, [r15+0x290]
000078d2e7dd9644  vmovaps xmm9, [rsp+0x10]
000078d2e7dd964a  vpermilpd xmm9, xmm9, 0x00
000078d2e7dd9650  movaps xmm8, xmm15
000078d2e7dd9654  mulpd xmm8, xmm9
000078d2e7dd9659  vcmppd xmm7, xmm8, xmm8, 0x03
000078d2e7dd965f  ptest xmm7, xmm7
000078d2e7dd9664  jnz 0x000078D2E7DDD79E
000078d2e7dd966a  movaps xmm15, xmm11
000078d2e7dd966e  addpd xmm15, xmm6
000078d2e7dd9673  vcmppd xmm9, xmm15, xmm15, 0x03
000078d2e7dd9679  ptest xmm9, xmm9
000078d2e7dd967f  jnz 0x000078D2E7DDD8E2
000078d2e7dd9685  movaps xmm11, [r15+0x1E0]
000078d2e7dd968d  vmovaps xmm9, [rsp+0x10]
000078d2e7dd9693  vpermilpd xmm9, xmm9, 0x00
000078d2e7dd9699  movaps xmm7, xmm11
000078d2e7dd969d  mulpd xmm7, xmm9
000078d2e7dd96a2  vcmppd xmm6, xmm7, xmm7, 0x03
000078d2e7dd96a7  ptest xmm6, xmm6
000078d2e7dd96ac  jnz 0x000078D2E7DDDA25
000078d2e7dd96b2  movaps xmm11, xmm10
000078d2e7dd96b6  addpd xmm11, xmm14
000078d2e7dd96bb  vcmppd xmm9, xmm11, xmm11, 0x03
000078d2e7dd96c1  ptest xmm9, xmm9
000078d2e7dd96c7  jnz 0x000078D2E7DDDB67
000078d2e7dd96cd  lea r14, [rax+0x70]
000078d2e7dd96d1  movups xmm14, [r13+r14*1]
000078d2e7dd96d7  movaps [r15+0x240], xmm14
000078d2e7dd96df  movaps xmm10, xmm1
000078d2e7dd96e3  addpd xmm10, xmm12
000078d2e7dd96e8  vcmppd xmm9, xmm10, xmm10, 0x03
000078d2e7dd96ee  ptest xmm9, xmm9
000078d2e7dd96f4  jnz 0x000078D2E7DDDCB5
000078d2e7dd96fa  movaps [r15+0x170], xmm10
000078d2e7dd9702  vmovaps xmm1, [rsp+0x20]
000078d2e7dd9708  vpermilpd xmm1, xmm1, 0x00
000078d2e7dd970e  movaps xmm12, xmm14
000078d2e7dd9712  mulpd xmm12, xmm1
000078d2e7dd9717  vcmppd xmm9, xmm12, xmm12, 0x03
000078d2e7dd971d  ptest xmm9, xmm9
000078d2e7dd9723  jnz 0x000078D2E7DDDDF8
000078d2e7dd9729  vmovaps xmm1, [rsp+0x20]
000078d2e7dd972f  vpermilpd xmm1, xmm1, 0x00
000078d2e7dd9735  vmovaps xmm9, [rsp+0xB0]
000078d2e7dd973e  movaps xmm14, xmm9
000078d2e7dd9742  mulpd xmm14, xmm1
000078d2e7dd9747  vcmppd xmm6, xmm14, xmm14, 0x03
000078d2e7dd974d  ptest xmm6, xmm6
000078d2e7dd9752  jnz 0x000078D2E7DDDF3B
000078d2e7dd9758  movaps [r15+0x180], xmm14
000078d2e7dd9760  movaps xmm1, xmm13
000078d2e7dd9764  addpd xmm1, xmm8
000078d2e7dd9769  vcmppd xmm9, xmm1, xmm1, 0x03
000078d2e7dd976e  ptest xmm9, xmm9
000078d2e7dd9774  jnz 0x000078D2E7DDE07E
000078d2e7dd977a  movaps [r15+0x210], xmm1
000078d2e7dd9782  movups xmm13, [r13+rax*1]
000078d2e7dd9788  lea r14, [rax+0x10]
000078d2e7dd978c  movups xmm9, [r13+r14*1]
000078d2e7dd9792  movaps [r15+0x230], xmm9
000078d2e7dd979a  movaps xmm8, xmm15
000078d2e7dd979e  addpd xmm8, xmm7
000078d2e7dd97a3  vcmppd xmm6, xmm8, xmm8, 0x03
000078d2e7dd97a9  ptest xmm6, xmm6
000078d2e7dd97ae  jnz 0x000078D2E7DDE1D4
000078d2e7dd97b4  movaps [r15+0x130], xmm8
000078d2e7dd97bc  vmovaps xmm15, [rsp+0x20]
000078d2e7dd97c2  vpermilpd xmm15, xmm15, 0x00
000078d2e7dd97c8  movaps xmm7, xmm9
000078d2e7dd97cc  mulpd xmm7, xmm15
000078d2e7dd97d1  vcmppd xmm6, xmm7, xmm7, 0x03
000078d2e7dd97d6  ptest xmm6, xmm6
000078d2e7dd97db  jnz 0x000078D2E7DDE317
000078d2e7dd97e1  movaps [r15+0x220], xmm7
000078d2e7dd97e9  vmovaps xmm15, [rsp+0x20]
000078d2e7dd97ef  vpermilpd xmm15, xmm15, 0x00
000078d2e7dd97f5  movaps xmm9, xmm13
000078d2e7dd97f9  mulpd xmm9, xmm15
000078d2e7dd97fe  vcmppd xmm6, xmm9, xmm9, 0x03
000078d2e7dd9804  ptest xmm6, xmm6
000078d2e7dd9809  jnz 0x000078D2E7DDE459
000078d2e7dd980f  movaps xmm15, xmm11
000078d2e7dd9813  addpd xmm15, xmm12
000078d2e7dd9818  vcmppd xmm13, xmm15, xmm15, 0x03
000078d2e7dd981e  ptest xmm13, xmm13
000078d2e7dd9824  jnz 0x000078D2E7DDE59D
000078d2e7dd982a  movaps [r15+0x140], xmm15
000078d2e7dd9832  movaps xmm13, xmm10
000078d2e7dd9836  addpd xmm13, xmm14
000078d2e7dd983b  vcmppd xmm12, xmm13, xmm13, 0x03
000078d2e7dd9841  ptest xmm12, xmm12
000078d2e7dd9847  jnz 0x000078D2E7DDE6E1
000078d2e7dd984d  movaps [r15+0x150], xmm13
000078d2e7dd9855  movaps xmm14, xmm1
000078d2e7dd9859  addpd xmm14, xmm7
000078d2e7dd985e  vcmppd xmm12, xmm14, xmm14, 0x03
000078d2e7dd9864  ptest xmm12, xmm12
000078d2e7dd986a  jnz 0x000078D2E7DDE825
000078d2e7dd9870  movaps [r15+0x160], xmm14
000078d2e7dd9878  movaps xmm1, xmm8
000078d2e7dd987c  addpd xmm1, xmm9
000078d2e7dd9881  vcmppd xmm12, xmm1, xmm1, 0x03
000078d2e7dd9886  ptest xmm12, xmm12
000078d2e7dd988c  jnz 0x000078D2E7DDE967
000078d2e7dd9892  movaps [r15+0x120], xmm1
000078d2e7dd989a  movups [r13+r11*1], xmm15
000078d2e7dd98a0  lea rax, [r11+0x10]
000078d2e7dd98a4  movups [r13+rax*1], xmm13
000078d2e7dd98aa  lea rax, [r11+0x20]
000078d2e7dd98ae  movups [r13+rax*1], xmm14
000078d2e7dd98b4  lea rax, [r11+0x30]
000078d2e7dd98b8  movups [r13+rax*1], xmm1
000078d2e7dd98be  mov eax, [r15+0x108]
000078d2e7dd98c5  sahf
000078d2e7dd98c6  jnz 0x000078D2E7DD98F8
000078d2e7dd98c8  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd98d0  jz 0x000078D2E7DDEAE0
000078d2e7dd98d6  nop [rax+rax*1], ax
000078d2e7dd98df  nop [rax+rax*1], eax
000078d2e7dd98e7  mov eax, 0x4106D0
000078d2e7dd98ec  mov [r15+0x100], rax
000078d2e7dd98f3  jmp 0x000078D2E7BFE110
000078d2e7dd98f8  cmp dword ptr [r15+0x318], 0x00
000078d2e7dd9900  jz 0x000078D2E7DD89C0
000078d2e7dd9906  nop [rax+rax*1], ax
000078d2e7dd990f  nop [rax+rax*1], eax
000078d2e7dd9917  mov eax, 0x410504
000078d2e7dd991c  mov [r15+0x100], rax
000078d2e7dd9923  jmp 0x000078D2E7BFE110
000078d2e7dd9928  int3
000078d2e7dd9929  call 0x000078D2E7C0A4B0
000078d2e7dd992e  jmp 0x000078D2E7DD8A08
000078d2e7dd9933  call 0x000078D2E7C09240
000078d2e7dd9938  jmp 0x000078D2E7DD8A12
000078d2e7dd993d  call 0x000078D2E7C0A4B0
000078d2e7dd9942  jmp 0x000078D2E7DD8A6F
000078d2e7dd9947  call 0x000078D2E7C09240
000078d2e7dd994c  jmp 0x000078D2E7DD8A79
000078d2e7dd9951  call 0x000078D2E7C0A4B0
000078d2e7dd9956  jmp 0x000078D2E7DD8ABD
000078d2e7dd995b  call 0x000078D2E7C09240
000078d2e7dd9960  jmp 0x000078D2E7DD8AC7
000078d2e7dd9965  call 0x000078D2E7CB47C0
000078d2e7dd996a  jmp 0x000078D2E7DD8B06
000078d2e7dd996f  call 0x000078D2E7C0B720
000078d2e7dd9974  jmp 0x000078D2E7DD8B1A
000078d2e7dd9979  call 0x000078D2E7CBFC30
000078d2e7dd997e  jmp 0x000078D2E7DD8B38
000078d2e7dd9983  call 0x000078D2E7CBE9C0
000078d2e7dd9988  jmp 0x000078D2E7DD8B42
000078d2e7dd998d  call 0x000078D2E7CBD750
000078d2e7dd9992  jmp 0x000078D2E7DD8B4C
000078d2e7dd9997  sub rsp, 0x08
000078d2e7dd999b  push rax
000078d2e7dd999c  push rcx
000078d2e7dd999d  push rdx
000078d2e7dd999e  push rdi
000078d2e7dd999f  push rsi
000078d2e7dd99a0  push r8
000078d2e7dd99a2  push r9
000078d2e7dd99a4  push r10
000078d2e7dd99a6  push r11
000078d2e7dd99a8  sub rsp, 0xF0
000078d2e7dd99af  vmovaps [rsp], xmm0
000078d2e7dd99b4  vmovaps [rsp+0x10], xmm1
000078d2e7dd99ba  vmovaps [rsp+0x20], xmm2
000078d2e7dd99c0  vmovaps [rsp+0x30], xmm3
000078d2e7dd99c6  vmovaps [rsp+0x40], xmm4
000078d2e7dd99cc  vmovaps [rsp+0x50], xmm5
000078d2e7dd99d2  vmovaps [rsp+0x60], xmm6
000078d2e7dd99d8  vmovaps [rsp+0x70], xmm7
000078d2e7dd99de  vmovaps [rsp+0x80], xmm9
000078d2e7dd99e7  vmovaps [rsp+0x90], xmm10
000078d2e7dd99f0  vmovaps [rsp+0xA0], xmm11
000078d2e7dd99f9  vmovaps [rsp+0xB0], xmm12
000078d2e7dd9a02  vmovaps [rsp+0xC0], xmm13
000078d2e7dd9a0b  vmovaps [rsp+0xD0], xmm14
000078d2e7dd9a14  vmovaps [rsp+0xE0], xmm15
000078d2e7dd9a1d  sub rsp, 0x30
000078d2e7dd9a21  movaps [rsp], xmm8
000078d2e7dd9a26  movaps [rsp+0x10], xmm12
000078d2e7dd9a2c  movaps [rsp+0x20], xmm15
000078d2e7dd9a32  lea rdi, [rsp]
000078d2e7dd9a36  mov esi, 0x00
000078d2e7dd9a3b  mov rax, 0x5997D2DB1530
000078d2e7dd9a45  call rax
000078d2e7dd9a47  movaps xmm8, [rsp]
000078d2e7dd9a4c  add rsp, 0x30
000078d2e7dd9a50  vmovaps xmm0, [rsp]
000078d2e7dd9a55  vmovaps xmm1, [rsp+0x10]
000078d2e7dd9a5b  vmovaps xmm2, [rsp+0x20]
000078d2e7dd9a61  vmovaps xmm3, [rsp+0x30]
000078d2e7dd9a67  vmovaps xmm4, [rsp+0x40]
000078d2e7dd9a6d  vmovaps xmm5, [rsp+0x50]
000078d2e7dd9a73  vmovaps xmm6, [rsp+0x60]
000078d2e7dd9a79  vmovaps xmm7, [rsp+0x70]
000078d2e7dd9a7f  vmovaps xmm9, [rsp+0x80]
000078d2e7dd9a88  vmovaps xmm10, [rsp+0x90]
000078d2e7dd9a91  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd9a9a  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd9aa3  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd9aac  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd9ab5  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd9abe  add rsp, 0xF0
000078d2e7dd9ac5  pop r11
000078d2e7dd9ac7  pop r10
000078d2e7dd9ac9  pop r9
000078d2e7dd9acb  pop r8
000078d2e7dd9acd  pop rsi
000078d2e7dd9ace  pop rdi
000078d2e7dd9acf  pop rdx
000078d2e7dd9ad0  pop rcx
000078d2e7dd9ad1  pop rax
000078d2e7dd9ad2  add rsp, 0x08
000078d2e7dd9ad6  jmp 0x000078D2E7DD8B7A
000078d2e7dd9adb  sub rsp, 0x08
000078d2e7dd9adf  push rax
000078d2e7dd9ae0  push rcx
000078d2e7dd9ae1  push rdx
000078d2e7dd9ae2  push rdi
000078d2e7dd9ae3  push rsi
000078d2e7dd9ae4  push r8
000078d2e7dd9ae6  push r9
000078d2e7dd9ae8  push r10
000078d2e7dd9aea  push r11
000078d2e7dd9aec  sub rsp, 0xF0
000078d2e7dd9af3  vmovaps [rsp], xmm0
000078d2e7dd9af8  vmovaps [rsp+0x10], xmm1
000078d2e7dd9afe  vmovaps [rsp+0x20], xmm2
000078d2e7dd9b04  vmovaps [rsp+0x30], xmm3
000078d2e7dd9b0a  vmovaps [rsp+0x40], xmm4
000078d2e7dd9b10  vmovaps [rsp+0x50], xmm5
000078d2e7dd9b16  vmovaps [rsp+0x60], xmm6
000078d2e7dd9b1c  vmovaps [rsp+0x70], xmm8
000078d2e7dd9b22  vmovaps [rsp+0x80], xmm9
000078d2e7dd9b2b  vmovaps [rsp+0x90], xmm10
000078d2e7dd9b34  vmovaps [rsp+0xA0], xmm11
000078d2e7dd9b3d  vmovaps [rsp+0xB0], xmm12
000078d2e7dd9b46  vmovaps [rsp+0xC0], xmm13
000078d2e7dd9b4f  vmovaps [rsp+0xD0], xmm14
000078d2e7dd9b58  vmovaps [rsp+0xE0], xmm15
000078d2e7dd9b61  sub rsp, 0x30
000078d2e7dd9b65  movaps [rsp], xmm7
000078d2e7dd9b69  movaps [rsp+0x10], xmm9
000078d2e7dd9b6f  movaps [rsp+0x20], xmm15
000078d2e7dd9b75  lea rdi, [rsp]
000078d2e7dd9b79  mov esi, 0x00
000078d2e7dd9b7e  mov rax, 0x5997D2DB1530
000078d2e7dd9b88  call rax
000078d2e7dd9b8a  movaps xmm7, [rsp]
000078d2e7dd9b8e  add rsp, 0x30
000078d2e7dd9b92  vmovaps xmm0, [rsp]
000078d2e7dd9b97  vmovaps xmm1, [rsp+0x10]
000078d2e7dd9b9d  vmovaps xmm2, [rsp+0x20]
000078d2e7dd9ba3  vmovaps xmm3, [rsp+0x30]
000078d2e7dd9ba9  vmovaps xmm4, [rsp+0x40]
000078d2e7dd9baf  vmovaps xmm5, [rsp+0x50]
000078d2e7dd9bb5  vmovaps xmm6, [rsp+0x60]
000078d2e7dd9bbb  vmovaps xmm8, [rsp+0x70]
000078d2e7dd9bc1  vmovaps xmm9, [rsp+0x80]
000078d2e7dd9bca  vmovaps xmm10, [rsp+0x90]
000078d2e7dd9bd3  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd9bdc  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd9be5  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd9bee  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd9bf7  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd9c00  add rsp, 0xF0
000078d2e7dd9c07  pop r11
000078d2e7dd9c09  pop r10
000078d2e7dd9c0b  pop r9
000078d2e7dd9c0d  pop r8
000078d2e7dd9c0f  pop rsi
000078d2e7dd9c10  pop rdi
000078d2e7dd9c11  pop rdx
000078d2e7dd9c12  pop rcx
000078d2e7dd9c13  pop rax
000078d2e7dd9c14  add rsp, 0x08
000078d2e7dd9c18  jmp 0x000078D2E7DD8BA8
000078d2e7dd9c1d  sub rsp, 0x08
000078d2e7dd9c21  push rax
000078d2e7dd9c22  push rcx
000078d2e7dd9c23  push rdx
000078d2e7dd9c24  push rdi
000078d2e7dd9c25  push rsi
000078d2e7dd9c26  push r8
000078d2e7dd9c28  push r9
000078d2e7dd9c2a  push r10
000078d2e7dd9c2c  push r11
000078d2e7dd9c2e  sub rsp, 0xF0
000078d2e7dd9c35  vmovaps [rsp], xmm0
000078d2e7dd9c3a  vmovaps [rsp+0x10], xmm1
000078d2e7dd9c40  vmovaps [rsp+0x20], xmm2
000078d2e7dd9c46  vmovaps [rsp+0x30], xmm3
000078d2e7dd9c4c  vmovaps [rsp+0x40], xmm4
000078d2e7dd9c52  vmovaps [rsp+0x50], xmm5
000078d2e7dd9c58  vmovaps [rsp+0x60], xmm6
000078d2e7dd9c5e  vmovaps [rsp+0x70], xmm7
000078d2e7dd9c64  vmovaps [rsp+0x80], xmm8
000078d2e7dd9c6d  vmovaps [rsp+0x90], xmm10
000078d2e7dd9c76  vmovaps [rsp+0xA0], xmm11
000078d2e7dd9c7f  vmovaps [rsp+0xB0], xmm12
000078d2e7dd9c88  vmovaps [rsp+0xC0], xmm13
000078d2e7dd9c91  vmovaps [rsp+0xD0], xmm14
000078d2e7dd9c9a  vmovaps [rsp+0xE0], xmm15
000078d2e7dd9ca3  sub rsp, 0x30
000078d2e7dd9ca7  movaps [rsp], xmm9
000078d2e7dd9cac  movaps [rsp+0x10], xmm12
000078d2e7dd9cb2  movaps [rsp+0x20], xmm10
000078d2e7dd9cb8  lea rdi, [rsp]
000078d2e7dd9cbc  mov esi, 0x00
000078d2e7dd9cc1  mov rax, 0x5997D2DB1530
000078d2e7dd9ccb  call rax
000078d2e7dd9ccd  movaps xmm9, [rsp]
000078d2e7dd9cd2  add rsp, 0x30
000078d2e7dd9cd6  vmovaps xmm0, [rsp]
000078d2e7dd9cdb  vmovaps xmm1, [rsp+0x10]
000078d2e7dd9ce1  vmovaps xmm2, [rsp+0x20]
000078d2e7dd9ce7  vmovaps xmm3, [rsp+0x30]
000078d2e7dd9ced  vmovaps xmm4, [rsp+0x40]
000078d2e7dd9cf3  vmovaps xmm5, [rsp+0x50]
000078d2e7dd9cf9  vmovaps xmm6, [rsp+0x60]
000078d2e7dd9cff  vmovaps xmm7, [rsp+0x70]
000078d2e7dd9d05  vmovaps xmm8, [rsp+0x80]
000078d2e7dd9d0e  vmovaps xmm10, [rsp+0x90]
000078d2e7dd9d17  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd9d20  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd9d29  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd9d32  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd9d3b  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd9d44  add rsp, 0xF0
000078d2e7dd9d4b  pop r11
000078d2e7dd9d4d  pop r10
000078d2e7dd9d4f  pop r9
000078d2e7dd9d51  pop r8
000078d2e7dd9d53  pop rsi
000078d2e7dd9d54  pop rdi
000078d2e7dd9d55  pop rdx
000078d2e7dd9d56  pop rcx
000078d2e7dd9d57  pop rax
000078d2e7dd9d58  add rsp, 0x08
000078d2e7dd9d5c  jmp 0x000078D2E7DD8BCC
000078d2e7dd9d61  sub rsp, 0x08
000078d2e7dd9d65  push rax
000078d2e7dd9d66  push rcx
000078d2e7dd9d67  push rdx
000078d2e7dd9d68  push rdi
000078d2e7dd9d69  push rsi
000078d2e7dd9d6a  push r8
000078d2e7dd9d6c  push r9
000078d2e7dd9d6e  push r10
000078d2e7dd9d70  push r11
000078d2e7dd9d72  sub rsp, 0xF0
000078d2e7dd9d79  vmovaps [rsp], xmm0
000078d2e7dd9d7e  vmovaps [rsp+0x10], xmm1
000078d2e7dd9d84  vmovaps [rsp+0x20], xmm2
000078d2e7dd9d8a  vmovaps [rsp+0x30], xmm3
000078d2e7dd9d90  vmovaps [rsp+0x40], xmm4
000078d2e7dd9d96  vmovaps [rsp+0x50], xmm5
000078d2e7dd9d9c  vmovaps [rsp+0x60], xmm6
000078d2e7dd9da2  vmovaps [rsp+0x70], xmm7
000078d2e7dd9da8  vmovaps [rsp+0x80], xmm8
000078d2e7dd9db1  vmovaps [rsp+0x90], xmm9
000078d2e7dd9dba  vmovaps [rsp+0xA0], xmm11
000078d2e7dd9dc3  vmovaps [rsp+0xB0], xmm12
000078d2e7dd9dcc  vmovaps [rsp+0xC0], xmm13
000078d2e7dd9dd5  vmovaps [rsp+0xD0], xmm14
000078d2e7dd9dde  vmovaps [rsp+0xE0], xmm15
000078d2e7dd9de7  sub rsp, 0x30
000078d2e7dd9deb  movaps [rsp], xmm10
000078d2e7dd9df0  movaps [rsp+0x10], xmm12
000078d2e7dd9df6  movaps [rsp+0x20], xmm11
000078d2e7dd9dfc  lea rdi, [rsp]
000078d2e7dd9e00  mov esi, 0x00
000078d2e7dd9e05  mov rax, 0x5997D2DB1530
000078d2e7dd9e0f  call rax
000078d2e7dd9e11  movaps xmm10, [rsp]
000078d2e7dd9e16  add rsp, 0x30
000078d2e7dd9e1a  vmovaps xmm0, [rsp]
000078d2e7dd9e1f  vmovaps xmm1, [rsp+0x10]
000078d2e7dd9e25  vmovaps xmm2, [rsp+0x20]
000078d2e7dd9e2b  vmovaps xmm3, [rsp+0x30]
000078d2e7dd9e31  vmovaps xmm4, [rsp+0x40]
000078d2e7dd9e37  vmovaps xmm5, [rsp+0x50]
000078d2e7dd9e3d  vmovaps xmm6, [rsp+0x60]
000078d2e7dd9e43  vmovaps xmm7, [rsp+0x70]
000078d2e7dd9e49  vmovaps xmm8, [rsp+0x80]
000078d2e7dd9e52  vmovaps xmm9, [rsp+0x90]
000078d2e7dd9e5b  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd9e64  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd9e6d  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd9e76  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd9e7f  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd9e88  add rsp, 0xF0
000078d2e7dd9e8f  pop r11
000078d2e7dd9e91  pop r10
000078d2e7dd9e93  pop r9
000078d2e7dd9e95  pop r8
000078d2e7dd9e97  pop rsi
000078d2e7dd9e98  pop rdi
000078d2e7dd9e99  pop rdx
000078d2e7dd9e9a  pop rcx
000078d2e7dd9e9b  pop rax
000078d2e7dd9e9c  add rsp, 0x08
000078d2e7dd9ea0  jmp 0x000078D2E7DD8BE6
000078d2e7dd9ea5  sub rsp, 0x08
000078d2e7dd9ea9  push rax
000078d2e7dd9eaa  push rcx
000078d2e7dd9eab  push rdx
000078d2e7dd9eac  push rdi
000078d2e7dd9ead  push rsi
000078d2e7dd9eae  push r8
000078d2e7dd9eb0  push r9
000078d2e7dd9eb2  push r10
000078d2e7dd9eb4  push r11
000078d2e7dd9eb6  sub rsp, 0xF0
000078d2e7dd9ebd  vmovaps [rsp], xmm0
000078d2e7dd9ec2  vmovaps [rsp+0x10], xmm1
000078d2e7dd9ec8  vmovaps [rsp+0x20], xmm2
000078d2e7dd9ece  vmovaps [rsp+0x30], xmm3
000078d2e7dd9ed4  vmovaps [rsp+0x40], xmm4
000078d2e7dd9eda  vmovaps [rsp+0x50], xmm5
000078d2e7dd9ee0  vmovaps [rsp+0x60], xmm7
000078d2e7dd9ee6  vmovaps [rsp+0x70], xmm8
000078d2e7dd9eec  vmovaps [rsp+0x80], xmm9
000078d2e7dd9ef5  vmovaps [rsp+0x90], xmm10
000078d2e7dd9efe  vmovaps [rsp+0xA0], xmm11
000078d2e7dd9f07  vmovaps [rsp+0xB0], xmm12
000078d2e7dd9f10  vmovaps [rsp+0xC0], xmm13
000078d2e7dd9f19  vmovaps [rsp+0xD0], xmm14
000078d2e7dd9f22  vmovaps [rsp+0xE0], xmm15
000078d2e7dd9f2b  sub rsp, 0x30
000078d2e7dd9f2f  movaps [rsp], xmm6
000078d2e7dd9f33  movaps [rsp+0x10], xmm12
000078d2e7dd9f39  movaps [rsp+0x20], xmm11
000078d2e7dd9f3f  lea rdi, [rsp]
000078d2e7dd9f43  mov esi, 0x00
000078d2e7dd9f48  mov rax, 0x5997D2DB1530
000078d2e7dd9f52  call rax
000078d2e7dd9f54  movaps xmm6, [rsp]
000078d2e7dd9f58  add rsp, 0x30
000078d2e7dd9f5c  vmovaps xmm0, [rsp]
000078d2e7dd9f61  vmovaps xmm1, [rsp+0x10]
000078d2e7dd9f67  vmovaps xmm2, [rsp+0x20]
000078d2e7dd9f6d  vmovaps xmm3, [rsp+0x30]
000078d2e7dd9f73  vmovaps xmm4, [rsp+0x40]
000078d2e7dd9f79  vmovaps xmm5, [rsp+0x50]
000078d2e7dd9f7f  vmovaps xmm7, [rsp+0x60]
000078d2e7dd9f85  vmovaps xmm8, [rsp+0x70]
000078d2e7dd9f8b  vmovaps xmm9, [rsp+0x80]
000078d2e7dd9f94  vmovaps xmm10, [rsp+0x90]
000078d2e7dd9f9d  vmovaps xmm11, [rsp+0xA0]
000078d2e7dd9fa6  vmovaps xmm12, [rsp+0xB0]
000078d2e7dd9faf  vmovaps xmm13, [rsp+0xC0]
000078d2e7dd9fb8  vmovaps xmm14, [rsp+0xD0]
000078d2e7dd9fc1  vmovaps xmm15, [rsp+0xE0]
000078d2e7dd9fca  add rsp, 0xF0
000078d2e7dd9fd1  pop r11
000078d2e7dd9fd3  pop r10
000078d2e7dd9fd5  pop r9
000078d2e7dd9fd7  pop r8
000078d2e7dd9fd9  pop rsi
000078d2e7dd9fda  pop rdi
000078d2e7dd9fdb  pop rdx
000078d2e7dd9fdc  pop rcx
000078d2e7dd9fdd  pop rax
000078d2e7dd9fde  add rsp, 0x08
000078d2e7dd9fe2  jmp 0x000078D2E7DD8C07
000078d2e7dd9fe7  sub rsp, 0x08
000078d2e7dd9feb  push rax
000078d2e7dd9fec  push rcx
000078d2e7dd9fed  push rdx
000078d2e7dd9fee  push rdi
000078d2e7dd9fef  push rsi
000078d2e7dd9ff0  push r8
000078d2e7dd9ff2  push r9
000078d2e7dd9ff4  push r10
000078d2e7dd9ff6  push r11
000078d2e7dd9ff8  sub rsp, 0xF0
000078d2e7dd9fff  vmovaps [rsp], xmm0
000078d2e7dda004  vmovaps [rsp+0x10], xmm1
000078d2e7dda00a  vmovaps [rsp+0x20], xmm2
000078d2e7dda010  vmovaps [rsp+0x30], xmm4
000078d2e7dda016  vmovaps [rsp+0x40], xmm5
000078d2e7dda01c  vmovaps [rsp+0x50], xmm6
000078d2e7dda022  vmovaps [rsp+0x60], xmm7
000078d2e7dda028  vmovaps [rsp+0x70], xmm8
000078d2e7dda02e  vmovaps [rsp+0x80], xmm9
000078d2e7dda037  vmovaps [rsp+0x90], xmm10
000078d2e7dda040  vmovaps [rsp+0xA0], xmm11
000078d2e7dda049  vmovaps [rsp+0xB0], xmm12
000078d2e7dda052  vmovaps [rsp+0xC0], xmm13
000078d2e7dda05b  vmovaps [rsp+0xD0], xmm14
000078d2e7dda064  vmovaps [rsp+0xE0], xmm15
000078d2e7dda06d  sub rsp, 0x30
000078d2e7dda071  movaps [rsp], xmm3
000078d2e7dda075  movaps [rsp+0x10], xmm5
000078d2e7dda07a  movaps [rsp+0x20], xmm4
000078d2e7dda07f  lea rdi, [rsp]
000078d2e7dda083  mov esi, 0x00
000078d2e7dda088  mov rax, 0x5997D2DB1530
000078d2e7dda092  call rax
000078d2e7dda094  movaps xmm3, [rsp]
000078d2e7dda098  add rsp, 0x30
000078d2e7dda09c  vmovaps xmm0, [rsp]
000078d2e7dda0a1  vmovaps xmm1, [rsp+0x10]
000078d2e7dda0a7  vmovaps xmm2, [rsp+0x20]
000078d2e7dda0ad  vmovaps xmm4, [rsp+0x30]
000078d2e7dda0b3  vmovaps xmm5, [rsp+0x40]
000078d2e7dda0b9  vmovaps xmm6, [rsp+0x50]
000078d2e7dda0bf  vmovaps xmm7, [rsp+0x60]
000078d2e7dda0c5  vmovaps xmm8, [rsp+0x70]
000078d2e7dda0cb  vmovaps xmm9, [rsp+0x80]
000078d2e7dda0d4  vmovaps xmm10, [rsp+0x90]
000078d2e7dda0dd  vmovaps xmm11, [rsp+0xA0]
000078d2e7dda0e6  vmovaps xmm12, [rsp+0xB0]
000078d2e7dda0ef  vmovaps xmm13, [rsp+0xC0]
000078d2e7dda0f8  vmovaps xmm14, [rsp+0xD0]
000078d2e7dda101  vmovaps xmm15, [rsp+0xE0]
000078d2e7dda10a  add rsp, 0xF0
000078d2e7dda111  pop r11
000078d2e7dda113  pop r10
000078d2e7dda115  pop r9
000078d2e7dda117  pop r8
000078d2e7dda119  pop rsi
000078d2e7dda11a  pop rdi
000078d2e7dda11b  pop rdx
000078d2e7dda11c  pop rcx
000078d2e7dda11d  pop rax
000078d2e7dda11e  add rsp, 0x08
000078d2e7dda122  jmp 0x000078D2E7DD8C68
000078d2e7dda127  sub rsp, 0x08
000078d2e7dda12b  push rax
000078d2e7dda12c  push rcx
000078d2e7dda12d  push rdx
000078d2e7dda12e  push rdi
000078d2e7dda12f  push rsi
000078d2e7dda130  push r8
000078d2e7dda132  push r9
000078d2e7dda134  push r10
000078d2e7dda136  push r11
000078d2e7dda138  sub rsp, 0xF0
000078d2e7dda13f  vmovaps [rsp], xmm0
000078d2e7dda144  vmovaps [rsp+0x10], xmm1
000078d2e7dda14a  vmovaps [rsp+0x20], xmm2
000078d2e7dda150  vmovaps [rsp+0x30], xmm3
000078d2e7dda156  vmovaps [rsp+0x40], xmm4
000078d2e7dda15c  vmovaps [rsp+0x50], xmm6
000078d2e7dda162  vmovaps [rsp+0x60], xmm7
000078d2e7dda168  vmovaps [rsp+0x70], xmm8
000078d2e7dda16e  vmovaps [rsp+0x80], xmm9
000078d2e7dda177  vmovaps [rsp+0x90], xmm10
000078d2e7dda180  vmovaps [rsp+0xA0], xmm11
000078d2e7dda189  vmovaps [rsp+0xB0], xmm12
000078d2e7dda192  vmovaps [rsp+0xC0], xmm13
000078d2e7dda19b  vmovaps [rsp+0xD0], xmm14
000078d2e7dda1a4  vmovaps [rsp+0xE0], xmm15
000078d2e7dda1ad  sub rsp, 0x30
000078d2e7dda1b1  movaps [rsp], xmm5
000078d2e7dda1b5  movaps [rsp+0x10], xmm8
000078d2e7dda1bb  movaps [rsp+0x20], xmm15
000078d2e7dda1c1  lea rdi, [rsp]
000078d2e7dda1c5  mov esi, 0x00
000078d2e7dda1ca  mov rax, 0x5997D2DB1530
000078d2e7dda1d4  call rax
000078d2e7dda1d6  movaps xmm5, [rsp]
000078d2e7dda1da  add rsp, 0x30
000078d2e7dda1de  vmovaps xmm0, [rsp]
000078d2e7dda1e3  vmovaps xmm1, [rsp+0x10]
000078d2e7dda1e9  vmovaps xmm2, [rsp+0x20]
000078d2e7dda1ef  vmovaps xmm3, [rsp+0x30]
000078d2e7dda1f5  vmovaps xmm4, [rsp+0x40]
000078d2e7dda1fb  vmovaps xmm6, [rsp+0x50]
000078d2e7dda201  vmovaps xmm7, [rsp+0x60]
000078d2e7dda207  vmovaps xmm8, [rsp+0x70]
000078d2e7dda20d  vmovaps xmm9, [rsp+0x80]
000078d2e7dda216  vmovaps xmm10, [rsp+0x90]
000078d2e7dda21f  vmovaps xmm11, [rsp+0xA0]
000078d2e7dda228  vmovaps xmm12, [rsp+0xB0]
000078d2e7dda231  vmovaps xmm13, [rsp+0xC0]
000078d2e7dda23a  vmovaps xmm14, [rsp+0xD0]
000078d2e7dda243  vmovaps xmm15, [rsp+0xE0]
000078d2e7dda24c  add rsp, 0xF0
000078d2e7dda253  pop r11
000078d2e7dda255  pop r10
000078d2e7dda257  pop r9
000078d2e7dda259  pop r8
000078d2e7dda25b  pop rsi
000078d2e7dda25c  pop rdi
000078d2e7dda25d  pop rdx
000078d2e7dda25e  pop rcx
000078d2e7dda25f  pop rax
000078d2e7dda260  add rsp, 0x08
000078d2e7dda264  jmp 0x000078D2E7DD8CA0
000078d2e7dda269  sub rsp, 0x08
000078d2e7dda26d  push rax
000078d2e7dda26e  push rcx
000078d2e7dda26f  push rdx
000078d2e7dda270  push rdi
000078d2e7dda271  push rsi
000078d2e7dda272  push r8
000078d2e7dda274  push r9
000078d2e7dda276  push r10
000078d2e7dda278  push r11
000078d2e7dda27a  sub rsp, 0xF0
000078d2e7dda281  vmovaps [rsp], xmm0
000078d2e7dda286  vmovaps [rsp+0x10], xmm1
000078d2e7dda28c  vmovaps [rsp+0x20], xmm2
000078d2e7dda292  vmovaps [rsp+0x30], xmm3
000078d2e7dda298  vmovaps [rsp+0x40], xmm5
000078d2e7dda29e  vmovaps [rsp+0x50], xmm6
000078d2e7dda2a4  vmovaps [rsp+0x60], xmm7
000078d2e7dda2aa  vmovaps [rsp+0x70], xmm8
000078d2e7dda2b0  vmovaps [rsp+0x80], xmm9
000078d2e7dda2b9  vmovaps [rsp+0x90], xmm10
000078d2e7dda2c2  vmovaps [rsp+0xA0], xmm11
000078d2e7dda2cb  vmovaps [rsp+0xB0], xmm12
000078d2e7dda2d4  vmovaps [rsp+0xC0], xmm13
000078d2e7dda2dd  vmovaps [rsp+0xD0], xmm14
000078d2e7dda2e6  vmovaps [rsp+0xE0], xmm15
000078d2e7dda2ef  sub rsp, 0x30
000078d2e7dda2f3  movaps [rsp], xmm4
000078d2e7dda2f7  movaps [rsp+0x10], xmm9
000078d2e7dda2fd  movaps [rsp+0x20], xmm8
000078d2e7dda303  lea rdi, [rsp]
000078d2e7dda307  mov esi, 0x00
000078d2e7dda30c  mov rax, 0x5997D2DB1530
000078d2e7dda316  call rax
000078d2e7dda318  movaps xmm4, [rsp]
000078d2e7dda31c  add rsp, 0x30
000078d2e7dda320  vmovaps xmm0, [rsp]
000078d2e7dda325  vmovaps xmm1, [rsp+0x10]
000078d2e7dda32b  vmovaps xmm2, [rsp+0x20]
000078d2e7dda331  vmovaps xmm3, [rsp+0x30]
000078d2e7dda337  vmovaps xmm5, [rsp+0x40]
000078d2e7dda33d  vmovaps xmm6, [rsp+0x50]
000078d2e7dda343  vmovaps xmm7, [rsp+0x60]
000078d2e7dda349  vmovaps xmm8, [rsp+0x70]
000078d2e7dda34f  vmovaps xmm9, [rsp+0x80]
000078d2e7dda358  vmovaps xmm10, [rsp+0x90]
000078d2e7dda361  vmovaps xmm11, [rsp+0xA0]
000078d2e7dda36a  vmovaps xmm12, [rsp+0xB0]
000078d2e7dda373  vmovaps xmm13, [rsp+0xC0]
000078d2e7dda37c  vmovaps xmm14, [rsp+0xD0]
000078d2e7dda385  vmovaps xmm15, [rsp+0xE0]
000078d2e7dda38e  add rsp, 0xF0
000078d2e7dda395  pop r11
000078d2e7dda397  pop r10
000078d2e7dda399  pop r9
000078d2e7dda39b  pop r8
000078d2e7dda39d  pop rsi
000078d2e7dda39e  pop rdi
000078d2e7dda39f  pop rdx
000078d2e7dda3a0  pop rcx
000078d2e7dda3a1  pop rax
000078d2e7dda3a2  add rsp, 0x08
000078d2e7dda3a6  jmp 0x000078D2E7DD8CC1
000078d2e7dda3ab  sub rsp, 0x08
000078d2e7dda3af  push rax
000078d2e7dda3b0  push rcx
000078d2e7dda3b1  push rdx
000078d2e7dda3b2  push rdi
000078d2e7dda3b3  push rsi
000078d2e7dda3b4  push r8
000078d2e7dda3b6  push r9
000078d2e7dda3b8  push r10
000078d2e7dda3ba  push r11
000078d2e7dda3bc  sub rsp, 0xF0
000078d2e7dda3c3  vmovaps [rsp], xmm0
000078d2e7dda3c8  vmovaps [rsp+0x10], xmm1
000078d2e7dda3ce  vmovaps [rsp+0x20], xmm2
000078d2e7dda3d4  vmovaps [rsp+0x30], xmm3
000078d2e7dda3da  vmovaps [rsp+0x40], xmm4
000078d2e7dda3e0  vmovaps [rsp+0x50], xmm5
000078d2e7dda3e6  vmovaps [rsp+0x60], xmm6
000078d2e7dda3ec  vmovaps [rsp+0x70], xmm7
000078d2e7dda3f2  vmovaps [rsp+0x80], xmm8
000078d2e7dda3fb  vmovaps [rsp+0x90], xmm10
000078d2e7dda404  vmovaps [rsp+0xA0], xmm11
000078d2e7dda40d  vmovaps [rsp+0xB0], xmm12
000078d2e7dda416  vmovaps [rsp+0xC0], xmm13
000078d2e7dda41f  vmovaps [rsp+0xD0], xmm14
000078d2e7dda428  vmovaps [rsp+0xE0], xmm15
000078d2e7dda431  sub rsp, 0x30
000078d2e7dda435  movaps [rsp], xmm9
000078d2e7dda43a  movaps [rsp+0x10], xmm10
000078d2e7dda440  movaps [rsp+0x20], xmm8
000078d2e7dda446  lea rdi, [rsp]
000078d2e7dda44a  mov esi, 0x00
000078d2e7dda44f  mov rax, 0x5997D2DB1530
000078d2e7dda459  call rax
000078d2e7dda45b  movaps xmm9, [rsp]
000078d2e7dda460  add rsp, 0x30
000078d2e7dda464  vmovaps xmm0, [rsp]
000078d2e7dda469  vmovaps xmm1, [rsp+0x10]
000078d2e7dda46f  vmovaps xmm2, [rsp+0x20]
000078d2e7dda475  vmovaps xmm3, [rsp+0x30]
000078d2e7dda47b  vmovaps xmm4, [rsp+0x40]
000078d2e7dda481  vmovaps xmm5, [rsp+0x50]
000078d2e7dda487  vmovaps xmm6, [rsp+0x60]
000078d2e7dda48d  vmovaps xmm7, [rsp+0x70]
000078d2e7dda493  vmovaps xmm8, [rsp+0x80]
000078d2e7dda49c  vmovaps xmm10, [rsp+0x90]
000078d2e7dda4a5  vmovaps xmm11, [rsp+0xA0]
000078d2e7dda4ae  vmovaps xmm12, [rsp+0xB0]
000078d2e7dda4b7  vmovaps xmm13, [rsp+0xC0]
000078d2e7dda4c0  vmovaps xmm14, [rsp+0xD0]
000078d2e7dda4c9  vmovaps xmm15, [rsp+0xE0]
000078d2e7dda4d2  add rsp, 0xF0
000078d2e7dda4d9  pop r11
000078d2e7dda4db  pop r10
000078d2e7dda4dd  pop r9
000078d2e7dda4df  pop r8
000078d2e7dda4e1  pop rsi
000078d2e7dda4e2  pop rdi
000078d2e7dda4e3  pop rdx
000078d2e7dda4e4  pop rcx
000078d2e7dda4e5  pop rax
000078d2e7dda4e6  add rsp, 0x08
000078d2e7dda4ea  jmp 0x000078D2E7DD8CDB
000078d2e7dda4ef  call 0x000078D2E7CD64F0
000078d2e7dda4f4  jmp 0x000078D2E7DD8DF5
000078d2e7dda4f9  call 0x000078D2E7CD64F0
000078d2e7dda4fe  jmp 0x000078D2E7DD8E0B
000078d2e7dda503  sub rsp, 0x08
000078d2e7dda507  push rax
000078d2e7dda508  push rcx
000078d2e7dda509  push rdx
000078d2e7dda50a  push rdi
000078d2e7dda50b  push rsi
000078d2e7dda50c  push r8
000078d2e7dda50e  push r9
000078d2e7dda510  push r10
000078d2e7dda512  push r11
000078d2e7dda514  sub rsp, 0xF0
000078d2e7dda51b  vmovaps [rsp], xmm0
000078d2e7dda520  vmovaps [rsp+0x10], xmm2
000078d2e7dda526  vmovaps [rsp+0x20], xmm3
000078d2e7dda52c  vmovaps [rsp+0x30], xmm4
000078d2e7dda532  vmovaps [rsp+0x40], xmm5
000078d2e7dda538  vmovaps [rsp+0x50], xmm6
000078d2e7dda53e  vmovaps [rsp+0x60], xmm7
000078d2e7dda544  vmovaps [rsp+0x70], xmm8
000078d2e7dda54a  vmovaps [rsp+0x80], xmm9
000078d2e7dda553  vmovaps [rsp+0x90], xmm10
000078d2e7dda55c  vmovaps [rsp+0xA0], xmm11
000078d2e7dda565  vmovaps [rsp+0xB0], xmm12
000078d2e7dda56e  vmovaps [rsp+0xC0], xmm13
000078d2e7dda577  vmovaps [rsp+0xD0], xmm14
000078d2e7dda580  vmovaps [rsp+0xE0], xmm15
000078d2e7dda589  sub rsp, 0x30
000078d2e7dda58d  movaps [rsp], xmm1
000078d2e7dda591  movaps [rsp+0x10], xmm6
000078d2e7dda596  movaps [rsp+0x20], xmm15
000078d2e7dda59c  lea rdi, [rsp]
000078d2e7dda5a0  mov esi, 0x00
000078d2e7dda5a5  mov rax, 0x5997D2DB1530
000078d2e7dda5af  call rax
000078d2e7dda5b1  movaps xmm1, [rsp]
000078d2e7dda5b5  add rsp, 0x30
000078d2e7dda5b9  vmovaps xmm0, [rsp]
000078d2e7dda5be  vmovaps xmm2, [rsp+0x10]
000078d2e7dda5c4  vmovaps xmm3, [rsp+0x20]
000078d2e7dda5ca  vmovaps xmm4, [rsp+0x30]
000078d2e7dda5d0  vmovaps xmm5, [rsp+0x40]
000078d2e7dda5d6  vmovaps xmm6, [rsp+0x50]
000078d2e7dda5dc  vmovaps xmm7, [rsp+0x60]
000078d2e7dda5e2  vmovaps xmm8, [rsp+0x70]
000078d2e7dda5e8  vmovaps xmm9, [rsp+0x80]
000078d2e7dda5f1  vmovaps xmm10, [rsp+0x90]
000078d2e7dda5fa  vmovaps xmm11, [rsp+0xA0]
000078d2e7dda603  vmovaps xmm12, [rsp+0xB0]
000078d2e7dda60c  vmovaps xmm13, [rsp+0xC0]
000078d2e7dda615  vmovaps xmm14, [rsp+0xD0]
000078d2e7dda61e  vmovaps xmm15, [rsp+0xE0]
000078d2e7dda627  add rsp, 0xF0
000078d2e7dda62e  pop r11
000078d2e7dda630  pop r10
000078d2e7dda632  pop r9
000078d2e7dda634  pop r8
000078d2e7dda636  pop rsi
000078d2e7dda637  pop rdi
000078d2e7dda638  pop rdx
000078d2e7dda639  pop rcx
000078d2e7dda63a  pop rax
000078d2e7dda63b  add rsp, 0x08
000078d2e7dda63f  jmp 0x000078D2E7DD8E48
000078d2e7dda644  call 0x000078D2E7CE5820
000078d2e7dda649  jmp 0x000078D2E7DD8E55
000078d2e7dda64e  sub rsp, 0x08
000078d2e7dda652  push rax
000078d2e7dda653  push rcx
000078d2e7dda654  push rdx
000078d2e7dda655  push rdi
000078d2e7dda656  push rsi
000078d2e7dda657  push r8
000078d2e7dda659  push r9
000078d2e7dda65b  push r10
000078d2e7dda65d  push r11
000078d2e7dda65f  sub rsp, 0xF0
000078d2e7dda666  vmovaps [rsp], xmm0
000078d2e7dda66b  vmovaps [rsp+0x10], xmm1
000078d2e7dda671  vmovaps [rsp+0x20], xmm2
000078d2e7dda677  vmovaps [rsp+0x30], xmm3
000078d2e7dda67d  vmovaps [rsp+0x40], xmm4
000078d2e7dda683  vmovaps [rsp+0x50], xmm5
000078d2e7dda689  vmovaps [rsp+0x60], xmm6
000078d2e7dda68f  vmovaps [rsp+0x70], xmm7
000078d2e7dda695  vmovaps [rsp+0x80], xmm8
000078d2e7dda69e  vmovaps [rsp+0x90], xmm9
000078d2e7dda6a7  vmovaps [rsp+0xA0], xmm10
000078d2e7dda6b0  vmovaps [rsp+0xB0], xmm11
000078d2e7dda6b9  vmovaps [rsp+0xC0], xmm12
000078d2e7dda6c2  vmovaps [rsp+0xD0], xmm13
000078d2e7dda6cb  vmovaps [rsp+0xE0], xmm15
000078d2e7dda6d4  sub rsp, 0x30
000078d2e7dda6d8  movaps [rsp], xmm14
000078d2e7dda6dd  movaps [rsp+0x10], xmm4
000078d2e7dda6e2  movaps [rsp+0x20], xmm3
000078d2e7dda6e7  lea rdi, [rsp]
000078d2e7dda6eb  mov esi, 0x00
000078d2e7dda6f0  mov rax, 0x5997D2DB1530
000078d2e7dda6fa  call rax
000078d2e7dda6fc  movaps xmm14, [rsp]
000078d2e7dda701  add rsp, 0x30
000078d2e7dda705  vmovaps xmm0, [rsp]
000078d2e7dda70a  vmovaps xmm1, [rsp+0x10]
000078d2e7dda710  vmovaps xmm2, [rsp+0x20]
000078d2e7dda716  vmovaps xmm3, [rsp+0x30]
000078d2e7dda71c  vmovaps xmm4, [rsp+0x40]
000078d2e7dda722  vmovaps xmm5, [rsp+0x50]
000078d2e7dda728  vmovaps xmm6, [rsp+0x60]
000078d2e7dda72e  vmovaps xmm7, [rsp+0x70]
000078d2e7dda734  vmovaps xmm8, [rsp+0x80]
000078d2e7dda73d  vmovaps xmm9, [rsp+0x90]
000078d2e7dda746  vmovaps xmm10, [rsp+0xA0]
000078d2e7dda74f  vmovaps xmm11, [rsp+0xB0]
000078d2e7dda758  vmovaps xmm12, [rsp+0xC0]
000078d2e7dda761  vmovaps xmm13, [rsp+0xD0]
000078d2e7dda76a  vmovaps xmm15, [rsp+0xE0]
000078d2e7dda773  add rsp, 0xF0
000078d2e7dda77a  pop r11
000078d2e7dda77c  pop r10
000078d2e7dda77e  pop r9
000078d2e7dda780  pop r8
000078d2e7dda782  pop rsi
000078d2e7dda783  pop rdi
000078d2e7dda784  pop rdx
000078d2e7dda785  pop rcx
000078d2e7dda786  pop rax
000078d2e7dda787  add rsp, 0x08
000078d2e7dda78b  jmp 0x000078D2E7DD8E6F
000078d2e7dda790  sub rsp, 0x08
000078d2e7dda794  push rax
000078d2e7dda795  push rcx
000078d2e7dda796  push rdx
000078d2e7dda797  push rdi
000078d2e7dda798  push rsi
000078d2e7dda799  push r8
000078d2e7dda79b  push r9
000078d2e7dda79d  push r10
000078d2e7dda79f  push r11
000078d2e7dda7a1  sub rsp, 0xF0
000078d2e7dda7a8  vmovaps [rsp], xmm0
000078d2e7dda7ad  vmovaps [rsp+0x10], xmm1
000078d2e7dda7b3  vmovaps [rsp+0x20], xmm2
000078d2e7dda7b9  vmovaps [rsp+0x30], xmm3
000078d2e7dda7bf  vmovaps [rsp+0x40], xmm4
000078d2e7dda7c5  vmovaps [rsp+0x50], xmm5
000078d2e7dda7cb  vmovaps [rsp+0x60], xmm7
000078d2e7dda7d1  vmovaps [rsp+0x70], xmm8
000078d2e7dda7d7  vmovaps [rsp+0x80], xmm9
000078d2e7dda7e0  vmovaps [rsp+0x90], xmm10
000078d2e7dda7e9  vmovaps [rsp+0xA0], xmm11
000078d2e7dda7f2  vmovaps [rsp+0xB0], xmm12
000078d2e7dda7fb  vmovaps [rsp+0xC0], xmm13
000078d2e7dda804  vmovaps [rsp+0xD0], xmm14
000078d2e7dda80d  vmovaps [rsp+0xE0], xmm15
000078d2e7dda816  sub rsp, 0x30
000078d2e7dda81a  movaps [rsp], xmm6
000078d2e7dda81e  movaps [rsp+0x10], xmm9
000078d2e7dda824  movaps [rsp+0x20], xmm7
000078d2e7dda829  lea rdi, [rsp]
000078d2e7dda82d  mov esi, 0x00
000078d2e7dda832  mov rax, 0x5997D2DB1530
000078d2e7dda83c  call rax
000078d2e7dda83e  movaps xmm6, [rsp]
000078d2e7dda842  add rsp, 0x30
000078d2e7dda846  vmovaps xmm0, [rsp]
000078d2e7dda84b  vmovaps xmm1, [rsp+0x10]
000078d2e7dda851  vmovaps xmm2, [rsp+0x20]
000078d2e7dda857  vmovaps xmm3, [rsp+0x30]
000078d2e7dda85d  vmovaps xmm4, [rsp+0x40]
000078d2e7dda863  vmovaps xmm5, [rsp+0x50]
000078d2e7dda869  vmovaps xmm7, [rsp+0x60]
000078d2e7dda86f  vmovaps xmm8, [rsp+0x70]
000078d2e7dda875  vmovaps xmm9, [rsp+0x80]
000078d2e7dda87e  vmovaps xmm10, [rsp+0x90]
000078d2e7dda887  vmovaps xmm11, [rsp+0xA0]
000078d2e7dda890  vmovaps xmm12, [rsp+0xB0]
000078d2e7dda899  vmovaps xmm13, [rsp+0xC0]
000078d2e7dda8a2  vmovaps xmm14, [rsp+0xD0]
000078d2e7dda8ab  vmovaps xmm15, [rsp+0xE0]
000078d2e7dda8b4  add rsp, 0xF0
000078d2e7dda8bb  pop r11
000078d2e7dda8bd  pop r10
000078d2e7dda8bf  pop r9
000078d2e7dda8c1  pop r8
000078d2e7dda8c3  pop rsi
000078d2e7dda8c4  pop rdi
000078d2e7dda8c5  pop rdx
000078d2e7dda8c6  pop rcx
000078d2e7dda8c7  pop rax
000078d2e7dda8c8  add rsp, 0x08
000078d2e7dda8cc  jmp 0x000078D2E7DD8E87
000078d2e7dda8d1  sub rsp, 0x08
000078d2e7dda8d5  push rax
000078d2e7dda8d6  push rcx
000078d2e7dda8d7  push rdx
000078d2e7dda8d8  push rdi
000078d2e7dda8d9  push rsi
000078d2e7dda8da  push r8
000078d2e7dda8dc  push r9
000078d2e7dda8de  push r10
000078d2e7dda8e0  push r11
000078d2e7dda8e2  sub rsp, 0xF0
000078d2e7dda8e9  vmovaps [rsp], xmm0
000078d2e7dda8ee  vmovaps [rsp+0x10], xmm1
000078d2e7dda8f4  vmovaps [rsp+0x20], xmm2
000078d2e7dda8fa  vmovaps [rsp+0x30], xmm3
000078d2e7dda900  vmovaps [rsp+0x40], xmm4
000078d2e7dda906  vmovaps [rsp+0x50], xmm5
000078d2e7dda90c  vmovaps [rsp+0x60], xmm6
000078d2e7dda912  vmovaps [rsp+0x70], xmm8
000078d2e7dda918  vmovaps [rsp+0x80], xmm9
000078d2e7dda921  vmovaps [rsp+0x90], xmm10
000078d2e7dda92a  vmovaps [rsp+0xA0], xmm11
000078d2e7dda933  vmovaps [rsp+0xB0], xmm12
000078d2e7dda93c  vmovaps [rsp+0xC0], xmm13
000078d2e7dda945  vmovaps [rsp+0xD0], xmm14
000078d2e7dda94e  vmovaps [rsp+0xE0], xmm15
000078d2e7dda957  sub rsp, 0x30
000078d2e7dda95b  movaps [rsp], xmm7
000078d2e7dda95f  movaps [rsp+0x10], xmm4
000078d2e7dda964  movaps [rsp+0x20], xmm9
000078d2e7dda96a  lea rdi, [rsp]
000078d2e7dda96e  mov esi, 0x00
000078d2e7dda973  mov rax, 0x5997D2DB1530
000078d2e7dda97d  call rax
000078d2e7dda97f  movaps xmm7, [rsp]
000078d2e7dda983  add rsp, 0x30
000078d2e7dda987  vmovaps xmm0, [rsp]
000078d2e7dda98c  vmovaps xmm1, [rsp+0x10]
000078d2e7dda992  vmovaps xmm2, [rsp+0x20]
000078d2e7dda998  vmovaps xmm3, [rsp+0x30]
000078d2e7dda99e  vmovaps xmm4, [rsp+0x40]
000078d2e7dda9a4  vmovaps xmm5, [rsp+0x50]
000078d2e7dda9aa  vmovaps xmm6, [rsp+0x60]
000078d2e7dda9b0  vmovaps xmm8, [rsp+0x70]
000078d2e7dda9b6  vmovaps xmm9, [rsp+0x80]
000078d2e7dda9bf  vmovaps xmm10, [rsp+0x90]
000078d2e7dda9c8  vmovaps xmm11, [rsp+0xA0]
000078d2e7dda9d1  vmovaps xmm12, [rsp+0xB0]
000078d2e7dda9da  vmovaps xmm13, [rsp+0xC0]
000078d2e7dda9e3  vmovaps xmm14, [rsp+0xD0]
000078d2e7dda9ec  vmovaps xmm15, [rsp+0xE0]
000078d2e7dda9f5  add rsp, 0xF0
000078d2e7dda9fc  pop r11
000078d2e7dda9fe  pop r10
000078d2e7ddaa00  pop r9
000078d2e7ddaa02  pop r8
000078d2e7ddaa04  pop rsi
000078d2e7ddaa05  pop rdi
000078d2e7ddaa06  pop rdx
000078d2e7ddaa07  pop rcx
000078d2e7ddaa08  pop rax
000078d2e7ddaa09  add rsp, 0x08
000078d2e7ddaa0d  jmp 0x000078D2E7DD8EB4
000078d2e7ddaa12  sub rsp, 0x08
000078d2e7ddaa16  push rax
000078d2e7ddaa17  push rcx
000078d2e7ddaa18  push rdx
000078d2e7ddaa19  push rdi
000078d2e7ddaa1a  push rsi
000078d2e7ddaa1b  push r8
000078d2e7ddaa1d  push r9
000078d2e7ddaa1f  push r10
000078d2e7ddaa21  push r11
000078d2e7ddaa23  sub rsp, 0xF0
000078d2e7ddaa2a  vmovaps [rsp], xmm0
000078d2e7ddaa2f  vmovaps [rsp+0x10], xmm1
000078d2e7ddaa35  vmovaps [rsp+0x20], xmm2
000078d2e7ddaa3b  vmovaps [rsp+0x30], xmm3
000078d2e7ddaa41  vmovaps [rsp+0x40], xmm5
000078d2e7ddaa47  vmovaps [rsp+0x50], xmm6
000078d2e7ddaa4d  vmovaps [rsp+0x60], xmm7
000078d2e7ddaa53  vmovaps [rsp+0x70], xmm8
000078d2e7ddaa59  vmovaps [rsp+0x80], xmm9
000078d2e7ddaa62  vmovaps [rsp+0x90], xmm10
000078d2e7ddaa6b  vmovaps [rsp+0xA0], xmm11
000078d2e7ddaa74  vmovaps [rsp+0xB0], xmm12
000078d2e7ddaa7d  vmovaps [rsp+0xC0], xmm13
000078d2e7ddaa86  vmovaps [rsp+0xD0], xmm14
000078d2e7ddaa8f  vmovaps [rsp+0xE0], xmm15
000078d2e7ddaa98  sub rsp, 0x30
000078d2e7ddaa9c  movaps [rsp], xmm4
000078d2e7ddaaa0  movaps [rsp+0x10], xmm15
000078d2e7ddaaa6  movaps [rsp+0x20], xmm9
000078d2e7ddaaac  lea rdi, [rsp]
000078d2e7ddaab0  mov esi, 0x00
000078d2e7ddaab5  mov rax, 0x5997D2DB1530
000078d2e7ddaabf  call rax
000078d2e7ddaac1  movaps xmm4, [rsp]
000078d2e7ddaac5  add rsp, 0x30
000078d2e7ddaac9  vmovaps xmm0, [rsp]
000078d2e7ddaace  vmovaps xmm1, [rsp+0x10]
000078d2e7ddaad4  vmovaps xmm2, [rsp+0x20]
000078d2e7ddaada  vmovaps xmm3, [rsp+0x30]
000078d2e7ddaae0  vmovaps xmm5, [rsp+0x40]
000078d2e7ddaae6  vmovaps xmm6, [rsp+0x50]
000078d2e7ddaaec  vmovaps xmm7, [rsp+0x60]
000078d2e7ddaaf2  vmovaps xmm8, [rsp+0x70]
000078d2e7ddaaf8  vmovaps xmm9, [rsp+0x80]
000078d2e7ddab01  vmovaps xmm10, [rsp+0x90]
000078d2e7ddab0a  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddab13  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddab1c  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddab25  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddab2e  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddab37  add rsp, 0xF0
000078d2e7ddab3e  pop r11
000078d2e7ddab40  pop r10
000078d2e7ddab42  pop r9
000078d2e7ddab44  pop r8
000078d2e7ddab46  pop rsi
000078d2e7ddab47  pop rdi
000078d2e7ddab48  pop rdx
000078d2e7ddab49  pop rcx
000078d2e7ddab4a  pop rax
000078d2e7ddab4b  add rsp, 0x08
000078d2e7ddab4f  jmp 0x000078D2E7DD8ED9
000078d2e7ddab54  call 0x000078D2E7CE5820
000078d2e7ddab59  jmp 0x000078D2E7DD8EE6
000078d2e7ddab5e  sub rsp, 0x08
000078d2e7ddab62  push rax
000078d2e7ddab63  push rcx
000078d2e7ddab64  push rdx
000078d2e7ddab65  push rdi
000078d2e7ddab66  push rsi
000078d2e7ddab67  push r8
000078d2e7ddab69  push r9
000078d2e7ddab6b  push r10
000078d2e7ddab6d  push r11
000078d2e7ddab6f  sub rsp, 0xF0
000078d2e7ddab76  vmovaps [rsp], xmm0
000078d2e7ddab7b  vmovaps [rsp+0x10], xmm1
000078d2e7ddab81  vmovaps [rsp+0x20], xmm2
000078d2e7ddab87  vmovaps [rsp+0x30], xmm4
000078d2e7ddab8d  vmovaps [rsp+0x40], xmm5
000078d2e7ddab93  vmovaps [rsp+0x50], xmm6
000078d2e7ddab99  vmovaps [rsp+0x60], xmm7
000078d2e7ddab9f  vmovaps [rsp+0x70], xmm8
000078d2e7ddaba5  vmovaps [rsp+0x80], xmm9
000078d2e7ddabae  vmovaps [rsp+0x90], xmm10
000078d2e7ddabb7  vmovaps [rsp+0xA0], xmm11
000078d2e7ddabc0  vmovaps [rsp+0xB0], xmm12
000078d2e7ddabc9  vmovaps [rsp+0xC0], xmm13
000078d2e7ddabd2  vmovaps [rsp+0xD0], xmm14
000078d2e7ddabdb  vmovaps [rsp+0xE0], xmm15
000078d2e7ddabe4  sub rsp, 0x30
000078d2e7ddabe8  movaps [rsp], xmm3
000078d2e7ddabec  movaps [rsp+0x10], xmm1
000078d2e7ddabf1  movaps [rsp+0x20], xmm9
000078d2e7ddabf7  lea rdi, [rsp]
000078d2e7ddabfb  mov esi, 0x00
000078d2e7ddac00  mov rax, 0x5997D2DB1530
000078d2e7ddac0a  call rax
000078d2e7ddac0c  movaps xmm3, [rsp]
000078d2e7ddac10  add rsp, 0x30
000078d2e7ddac14  vmovaps xmm0, [rsp]
000078d2e7ddac19  vmovaps xmm1, [rsp+0x10]
000078d2e7ddac1f  vmovaps xmm2, [rsp+0x20]
000078d2e7ddac25  vmovaps xmm4, [rsp+0x30]
000078d2e7ddac2b  vmovaps xmm5, [rsp+0x40]
000078d2e7ddac31  vmovaps xmm6, [rsp+0x50]
000078d2e7ddac37  vmovaps xmm7, [rsp+0x60]
000078d2e7ddac3d  vmovaps xmm8, [rsp+0x70]
000078d2e7ddac43  vmovaps xmm9, [rsp+0x80]
000078d2e7ddac4c  vmovaps xmm10, [rsp+0x90]
000078d2e7ddac55  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddac5e  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddac67  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddac70  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddac79  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddac82  add rsp, 0xF0
000078d2e7ddac89  pop r11
000078d2e7ddac8b  pop r10
000078d2e7ddac8d  pop r9
000078d2e7ddac8f  pop r8
000078d2e7ddac91  pop rsi
000078d2e7ddac92  pop rdi
000078d2e7ddac93  pop rdx
000078d2e7ddac94  pop rcx
000078d2e7ddac95  pop rax
000078d2e7ddac96  add rsp, 0x08
000078d2e7ddac9a  jmp 0x000078D2E7DD8F23
000078d2e7ddac9f  sub rsp, 0x08
000078d2e7ddaca3  push rax
000078d2e7ddaca4  push rcx
000078d2e7ddaca5  push rdx
000078d2e7ddaca6  push rdi
000078d2e7ddaca7  push rsi
000078d2e7ddaca8  push r8
000078d2e7ddacaa  push r9
000078d2e7ddacac  push r10
000078d2e7ddacae  push r11
000078d2e7ddacb0  sub rsp, 0xF0
000078d2e7ddacb7  vmovaps [rsp], xmm0
000078d2e7ddacbc  vmovaps [rsp+0x10], xmm2
000078d2e7ddacc2  vmovaps [rsp+0x20], xmm3
000078d2e7ddacc8  vmovaps [rsp+0x30], xmm4
000078d2e7ddacce  vmovaps [rsp+0x40], xmm5
000078d2e7ddacd4  vmovaps [rsp+0x50], xmm6
000078d2e7ddacda  vmovaps [rsp+0x60], xmm7
000078d2e7ddace0  vmovaps [rsp+0x70], xmm8
000078d2e7ddace6  vmovaps [rsp+0x80], xmm9
000078d2e7ddacef  vmovaps [rsp+0x90], xmm10
000078d2e7ddacf8  vmovaps [rsp+0xA0], xmm11
000078d2e7ddad01  vmovaps [rsp+0xB0], xmm12
000078d2e7ddad0a  vmovaps [rsp+0xC0], xmm13
000078d2e7ddad13  vmovaps [rsp+0xD0], xmm14
000078d2e7ddad1c  vmovaps [rsp+0xE0], xmm15
000078d2e7ddad25  sub rsp, 0x30
000078d2e7ddad29  movaps [rsp], xmm1
000078d2e7ddad2d  movaps [rsp+0x10], xmm15
000078d2e7ddad33  movaps [rsp+0x20], xmm9
000078d2e7ddad39  lea rdi, [rsp]
000078d2e7ddad3d  mov esi, 0x00
000078d2e7ddad42  mov rax, 0x5997D2DB1530
000078d2e7ddad4c  call rax
000078d2e7ddad4e  movaps xmm1, [rsp]
000078d2e7ddad52  add rsp, 0x30
000078d2e7ddad56  vmovaps xmm0, [rsp]
000078d2e7ddad5b  vmovaps xmm2, [rsp+0x10]
000078d2e7ddad61  vmovaps xmm3, [rsp+0x20]
000078d2e7ddad67  vmovaps xmm4, [rsp+0x30]
000078d2e7ddad6d  vmovaps xmm5, [rsp+0x40]
000078d2e7ddad73  vmovaps xmm6, [rsp+0x50]
000078d2e7ddad79  vmovaps xmm7, [rsp+0x60]
000078d2e7ddad7f  vmovaps xmm8, [rsp+0x70]
000078d2e7ddad85  vmovaps xmm9, [rsp+0x80]
000078d2e7ddad8e  vmovaps xmm10, [rsp+0x90]
000078d2e7ddad97  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddada0  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddada9  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddadb2  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddadbb  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddadc4  add rsp, 0xF0
000078d2e7ddadcb  pop r11
000078d2e7ddadcd  pop r10
000078d2e7ddadcf  pop r9
000078d2e7ddadd1  pop r8
000078d2e7ddadd3  pop rsi
000078d2e7ddadd4  pop rdi
000078d2e7ddadd5  pop rdx
000078d2e7ddadd6  pop rcx
000078d2e7ddadd7  pop rax
000078d2e7ddadd8  add rsp, 0x08
000078d2e7ddaddc  jmp 0x000078D2E7DD8FAB
000078d2e7ddade1  call 0x000078D2E7CE5820
000078d2e7ddade6  jmp 0x000078D2E7DD8FB8
000078d2e7ddadeb  sub rsp, 0x08
000078d2e7ddadef  push rax
000078d2e7ddadf0  push rcx
000078d2e7ddadf1  push rdx
000078d2e7ddadf2  push rdi
000078d2e7ddadf3  push rsi
000078d2e7ddadf4  push r8
000078d2e7ddadf6  push r9
000078d2e7ddadf8  push r10
000078d2e7ddadfa  push r11
000078d2e7ddadfc  sub rsp, 0xF0
000078d2e7ddae03  vmovaps [rsp], xmm0
000078d2e7ddae08  vmovaps [rsp+0x10], xmm2
000078d2e7ddae0e  vmovaps [rsp+0x20], xmm3
000078d2e7ddae14  vmovaps [rsp+0x30], xmm4
000078d2e7ddae1a  vmovaps [rsp+0x40], xmm5
000078d2e7ddae20  vmovaps [rsp+0x50], xmm6
000078d2e7ddae26  vmovaps [rsp+0x60], xmm7
000078d2e7ddae2c  vmovaps [rsp+0x70], xmm8
000078d2e7ddae32  vmovaps [rsp+0x80], xmm9
000078d2e7ddae3b  vmovaps [rsp+0x90], xmm10
000078d2e7ddae44  vmovaps [rsp+0xA0], xmm11
000078d2e7ddae4d  vmovaps [rsp+0xB0], xmm12
000078d2e7ddae56  vmovaps [rsp+0xC0], xmm13
000078d2e7ddae5f  vmovaps [rsp+0xD0], xmm14
000078d2e7ddae68  vmovaps [rsp+0xE0], xmm15
000078d2e7ddae71  sub rsp, 0x30
000078d2e7ddae75  movaps [rsp], xmm1
000078d2e7ddae79  movaps [rsp+0x10], xmm5
000078d2e7ddae7e  movaps [rsp+0x20], xmm7
000078d2e7ddae83  lea rdi, [rsp]
000078d2e7ddae87  mov esi, 0x00
000078d2e7ddae8c  mov rax, 0x5997D2DB1530
000078d2e7ddae96  call rax
000078d2e7ddae98  movaps xmm1, [rsp]
000078d2e7ddae9c  add rsp, 0x30
000078d2e7ddaea0  vmovaps xmm0, [rsp]
000078d2e7ddaea5  vmovaps xmm2, [rsp+0x10]
000078d2e7ddaeab  vmovaps xmm3, [rsp+0x20]
000078d2e7ddaeb1  vmovaps xmm4, [rsp+0x30]
000078d2e7ddaeb7  vmovaps xmm5, [rsp+0x40]
000078d2e7ddaebd  vmovaps xmm6, [rsp+0x50]
000078d2e7ddaec3  vmovaps xmm7, [rsp+0x60]
000078d2e7ddaec9  vmovaps xmm8, [rsp+0x70]
000078d2e7ddaecf  vmovaps xmm9, [rsp+0x80]
000078d2e7ddaed8  vmovaps xmm10, [rsp+0x90]
000078d2e7ddaee1  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddaeea  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddaef3  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddaefc  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddaf05  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddaf0e  add rsp, 0xF0
000078d2e7ddaf15  pop r11
000078d2e7ddaf17  pop r10
000078d2e7ddaf19  pop r9
000078d2e7ddaf1b  pop r8
000078d2e7ddaf1d  pop rsi
000078d2e7ddaf1e  pop rdi
000078d2e7ddaf1f  pop rdx
000078d2e7ddaf20  pop rcx
000078d2e7ddaf21  pop rax
000078d2e7ddaf22  add rsp, 0x08
000078d2e7ddaf26  jmp 0x000078D2E7DD905D
000078d2e7ddaf2b  sub rsp, 0x08
000078d2e7ddaf2f  push rax
000078d2e7ddaf30  push rcx
000078d2e7ddaf31  push rdx
000078d2e7ddaf32  push rdi
000078d2e7ddaf33  push rsi
000078d2e7ddaf34  push r8
000078d2e7ddaf36  push r9
000078d2e7ddaf38  push r10
000078d2e7ddaf3a  push r11
000078d2e7ddaf3c  sub rsp, 0xF0
000078d2e7ddaf43  vmovaps [rsp], xmm0
000078d2e7ddaf48  vmovaps [rsp+0x10], xmm1
000078d2e7ddaf4e  vmovaps [rsp+0x20], xmm2
000078d2e7ddaf54  vmovaps [rsp+0x30], xmm3
000078d2e7ddaf5a  vmovaps [rsp+0x40], xmm4
000078d2e7ddaf60  vmovaps [rsp+0x50], xmm5
000078d2e7ddaf66  vmovaps [rsp+0x60], xmm6
000078d2e7ddaf6c  vmovaps [rsp+0x70], xmm8
000078d2e7ddaf72  vmovaps [rsp+0x80], xmm9
000078d2e7ddaf7b  vmovaps [rsp+0x90], xmm10
000078d2e7ddaf84  vmovaps [rsp+0xA0], xmm11
000078d2e7ddaf8d  vmovaps [rsp+0xB0], xmm12
000078d2e7ddaf96  vmovaps [rsp+0xC0], xmm13
000078d2e7ddaf9f  vmovaps [rsp+0xD0], xmm14
000078d2e7ddafa8  vmovaps [rsp+0xE0], xmm15
000078d2e7ddafb1  sub rsp, 0x30
000078d2e7ddafb5  movaps [rsp], xmm7
000078d2e7ddafb9  movaps [rsp+0x10], xmm5
000078d2e7ddafbe  movaps [rsp+0x20], xmm15
000078d2e7ddafc4  lea rdi, [rsp]
000078d2e7ddafc8  mov esi, 0x00
000078d2e7ddafcd  mov rax, 0x5997D2DB1530
000078d2e7ddafd7  call rax
000078d2e7ddafd9  movaps xmm7, [rsp]
000078d2e7ddafdd  add rsp, 0x30
000078d2e7ddafe1  vmovaps xmm0, [rsp]
000078d2e7ddafe6  vmovaps xmm1, [rsp+0x10]
000078d2e7ddafec  vmovaps xmm2, [rsp+0x20]
000078d2e7ddaff2  vmovaps xmm3, [rsp+0x30]
000078d2e7ddaff8  vmovaps xmm4, [rsp+0x40]
000078d2e7ddaffe  vmovaps xmm5, [rsp+0x50]
000078d2e7ddb004  vmovaps xmm6, [rsp+0x60]
000078d2e7ddb00a  vmovaps xmm8, [rsp+0x70]
000078d2e7ddb010  vmovaps xmm9, [rsp+0x80]
000078d2e7ddb019  vmovaps xmm10, [rsp+0x90]
000078d2e7ddb022  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddb02b  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddb034  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddb03d  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddb046  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddb04f  add rsp, 0xF0
000078d2e7ddb056  pop r11
000078d2e7ddb058  pop r10
000078d2e7ddb05a  pop r9
000078d2e7ddb05c  pop r8
000078d2e7ddb05e  pop rsi
000078d2e7ddb05f  pop rdi
000078d2e7ddb060  pop rdx
000078d2e7ddb061  pop rcx
000078d2e7ddb062  pop rax
000078d2e7ddb063  add rsp, 0x08
000078d2e7ddb067  jmp 0x000078D2E7DD9093
000078d2e7ddb06c  call 0x000078D2E7CD64F0
000078d2e7ddb071  jmp 0x000078D2E7DD90A0
000078d2e7ddb076  sub rsp, 0x08
000078d2e7ddb07a  push rax
000078d2e7ddb07b  push rcx
000078d2e7ddb07c  push rdx
000078d2e7ddb07d  push rdi
000078d2e7ddb07e  push rsi
000078d2e7ddb07f  push r8
000078d2e7ddb081  push r9
000078d2e7ddb083  push r10
000078d2e7ddb085  push r11
000078d2e7ddb087  sub rsp, 0xF0
000078d2e7ddb08e  vmovaps [rsp], xmm0
000078d2e7ddb093  vmovaps [rsp+0x10], xmm1
000078d2e7ddb099  vmovaps [rsp+0x20], xmm2
000078d2e7ddb09f  vmovaps [rsp+0x30], xmm3
000078d2e7ddb0a5  vmovaps [rsp+0x40], xmm4
000078d2e7ddb0ab  vmovaps [rsp+0x50], xmm5
000078d2e7ddb0b1  vmovaps [rsp+0x60], xmm6
000078d2e7ddb0b7  vmovaps [rsp+0x70], xmm7
000078d2e7ddb0bd  vmovaps [rsp+0x80], xmm8
000078d2e7ddb0c6  vmovaps [rsp+0x90], xmm9
000078d2e7ddb0cf  vmovaps [rsp+0xA0], xmm10
000078d2e7ddb0d8  vmovaps [rsp+0xB0], xmm11
000078d2e7ddb0e1  vmovaps [rsp+0xC0], xmm12
000078d2e7ddb0ea  vmovaps [rsp+0xD0], xmm13
000078d2e7ddb0f3  vmovaps [rsp+0xE0], xmm14
000078d2e7ddb0fc  sub rsp, 0x30
000078d2e7ddb100  movaps [rsp], xmm15
000078d2e7ddb105  movaps [rsp+0x10], xmm5
000078d2e7ddb10a  movaps [rsp+0x20], xmm3
000078d2e7ddb10f  lea rdi, [rsp]
000078d2e7ddb113  mov esi, 0x00
000078d2e7ddb118  mov rax, 0x5997D2DB1530
000078d2e7ddb122  call rax
000078d2e7ddb124  movaps xmm15, [rsp]
000078d2e7ddb129  add rsp, 0x30
000078d2e7ddb12d  vmovaps xmm0, [rsp]
000078d2e7ddb132  vmovaps xmm1, [rsp+0x10]
000078d2e7ddb138  vmovaps xmm2, [rsp+0x20]
000078d2e7ddb13e  vmovaps xmm3, [rsp+0x30]
000078d2e7ddb144  vmovaps xmm4, [rsp+0x40]
000078d2e7ddb14a  vmovaps xmm5, [rsp+0x50]
000078d2e7ddb150  vmovaps xmm6, [rsp+0x60]
000078d2e7ddb156  vmovaps xmm7, [rsp+0x70]
000078d2e7ddb15c  vmovaps xmm8, [rsp+0x80]
000078d2e7ddb165  vmovaps xmm9, [rsp+0x90]
000078d2e7ddb16e  vmovaps xmm10, [rsp+0xA0]
000078d2e7ddb177  vmovaps xmm11, [rsp+0xB0]
000078d2e7ddb180  vmovaps xmm12, [rsp+0xC0]
000078d2e7ddb189  vmovaps xmm13, [rsp+0xD0]
000078d2e7ddb192  vmovaps xmm14, [rsp+0xE0]
000078d2e7ddb19b  add rsp, 0xF0
000078d2e7ddb1a2  pop r11
000078d2e7ddb1a4  pop r10
000078d2e7ddb1a6  pop r9
000078d2e7ddb1a8  pop r8
000078d2e7ddb1aa  pop rsi
000078d2e7ddb1ab  pop rdi
000078d2e7ddb1ac  pop rdx
000078d2e7ddb1ad  pop rcx
000078d2e7ddb1ae  pop rax
000078d2e7ddb1af  add rsp, 0x08
000078d2e7ddb1b3  jmp 0x000078D2E7DD90C6
000078d2e7ddb1b8  sub rsp, 0x08
000078d2e7ddb1bc  push rax
000078d2e7ddb1bd  push rcx
000078d2e7ddb1be  push rdx
000078d2e7ddb1bf  push rdi
000078d2e7ddb1c0  push rsi
000078d2e7ddb1c1  push r8
000078d2e7ddb1c3  push r9
000078d2e7ddb1c5  push r10
000078d2e7ddb1c7  push r11
000078d2e7ddb1c9  sub rsp, 0xF0
000078d2e7ddb1d0  vmovaps [rsp], xmm0
000078d2e7ddb1d5  vmovaps [rsp+0x10], xmm2
000078d2e7ddb1db  vmovaps [rsp+0x20], xmm3
000078d2e7ddb1e1  vmovaps [rsp+0x30], xmm4
000078d2e7ddb1e7  vmovaps [rsp+0x40], xmm5
000078d2e7ddb1ed  vmovaps [rsp+0x50], xmm6
000078d2e7ddb1f3  vmovaps [rsp+0x60], xmm7
000078d2e7ddb1f9  vmovaps [rsp+0x70], xmm8
000078d2e7ddb1ff  vmovaps [rsp+0x80], xmm9
000078d2e7ddb208  vmovaps [rsp+0x90], xmm10
000078d2e7ddb211  vmovaps [rsp+0xA0], xmm11
000078d2e7ddb21a  vmovaps [rsp+0xB0], xmm12
000078d2e7ddb223  vmovaps [rsp+0xC0], xmm13
000078d2e7ddb22c  vmovaps [rsp+0xD0], xmm14
000078d2e7ddb235  vmovaps [rsp+0xE0], xmm15
000078d2e7ddb23e  sub rsp, 0x30
000078d2e7ddb242  movaps [rsp], xmm1
000078d2e7ddb246  movaps [rsp+0x10], xmm5
000078d2e7ddb24b  movaps [rsp+0x20], xmm4
000078d2e7ddb250  lea rdi, [rsp]
000078d2e7ddb254  mov esi, 0x00
000078d2e7ddb259  mov rax, 0x5997D2DB1530
000078d2e7ddb263  call rax
000078d2e7ddb265  movaps xmm1, [rsp]
000078d2e7ddb269  add rsp, 0x30
000078d2e7ddb26d  vmovaps xmm0, [rsp]
000078d2e7ddb272  vmovaps xmm2, [rsp+0x10]
000078d2e7ddb278  vmovaps xmm3, [rsp+0x20]
000078d2e7ddb27e  vmovaps xmm4, [rsp+0x30]
000078d2e7ddb284  vmovaps xmm5, [rsp+0x40]
000078d2e7ddb28a  vmovaps xmm6, [rsp+0x50]
000078d2e7ddb290  vmovaps xmm7, [rsp+0x60]
000078d2e7ddb296  vmovaps xmm8, [rsp+0x70]
000078d2e7ddb29c  vmovaps xmm9, [rsp+0x80]
000078d2e7ddb2a5  vmovaps xmm10, [rsp+0x90]
000078d2e7ddb2ae  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddb2b7  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddb2c0  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddb2c9  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddb2d2  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddb2db  add rsp, 0xF0
000078d2e7ddb2e2  pop r11
000078d2e7ddb2e4  pop r10
000078d2e7ddb2e6  pop r9
000078d2e7ddb2e8  pop r8
000078d2e7ddb2ea  pop rsi
000078d2e7ddb2eb  pop rdi
000078d2e7ddb2ec  pop rdx
000078d2e7ddb2ed  pop rcx
000078d2e7ddb2ee  pop rax
000078d2e7ddb2ef  add rsp, 0x08
000078d2e7ddb2f3  jmp 0x000078D2E7DD90E6
000078d2e7ddb2f8  sub rsp, 0x08
000078d2e7ddb2fc  push rax
000078d2e7ddb2fd  push rcx
000078d2e7ddb2fe  push rdx
000078d2e7ddb2ff  push rdi
000078d2e7ddb300  push rsi
000078d2e7ddb301  push r8
000078d2e7ddb303  push r9
000078d2e7ddb305  push r10
000078d2e7ddb307  push r11
000078d2e7ddb309  sub rsp, 0xF0
000078d2e7ddb310  vmovaps [rsp], xmm0
000078d2e7ddb315  vmovaps [rsp+0x10], xmm1
000078d2e7ddb31b  vmovaps [rsp+0x20], xmm2
000078d2e7ddb321  vmovaps [rsp+0x30], xmm3
000078d2e7ddb327  vmovaps [rsp+0x40], xmm5
000078d2e7ddb32d  vmovaps [rsp+0x50], xmm6
000078d2e7ddb333  vmovaps [rsp+0x60], xmm7
000078d2e7ddb339  vmovaps [rsp+0x70], xmm8
000078d2e7ddb33f  vmovaps [rsp+0x80], xmm9
000078d2e7ddb348  vmovaps [rsp+0x90], xmm10
000078d2e7ddb351  vmovaps [rsp+0xA0], xmm11
000078d2e7ddb35a  vmovaps [rsp+0xB0], xmm12
000078d2e7ddb363  vmovaps [rsp+0xC0], xmm13
000078d2e7ddb36c  vmovaps [rsp+0xD0], xmm14
000078d2e7ddb375  vmovaps [rsp+0xE0], xmm15
000078d2e7ddb37e  sub rsp, 0x30
000078d2e7ddb382  movaps [rsp], xmm4
000078d2e7ddb386  movaps [rsp+0x10], xmm3
000078d2e7ddb38b  movaps [rsp+0x20], xmm5
000078d2e7ddb390  lea rdi, [rsp]
000078d2e7ddb394  mov esi, 0x00
000078d2e7ddb399  mov rax, 0x5997D2DB1530
000078d2e7ddb3a3  call rax
000078d2e7ddb3a5  movaps xmm4, [rsp]
000078d2e7ddb3a9  add rsp, 0x30
000078d2e7ddb3ad  vmovaps xmm0, [rsp]
000078d2e7ddb3b2  vmovaps xmm1, [rsp+0x10]
000078d2e7ddb3b8  vmovaps xmm2, [rsp+0x20]
000078d2e7ddb3be  vmovaps xmm3, [rsp+0x30]
000078d2e7ddb3c4  vmovaps xmm5, [rsp+0x40]
000078d2e7ddb3ca  vmovaps xmm6, [rsp+0x50]
000078d2e7ddb3d0  vmovaps xmm7, [rsp+0x60]
000078d2e7ddb3d6  vmovaps xmm8, [rsp+0x70]
000078d2e7ddb3dc  vmovaps xmm9, [rsp+0x80]
000078d2e7ddb3e5  vmovaps xmm10, [rsp+0x90]
000078d2e7ddb3ee  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddb3f7  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddb400  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddb409  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddb412  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddb41b  add rsp, 0xF0
000078d2e7ddb422  pop r11
000078d2e7ddb424  pop r10
000078d2e7ddb426  pop r9
000078d2e7ddb428  pop r8
000078d2e7ddb42a  pop rsi
000078d2e7ddb42b  pop rdi
000078d2e7ddb42c  pop rdx
000078d2e7ddb42d  pop rcx
000078d2e7ddb42e  pop rax
000078d2e7ddb42f  add rsp, 0x08
000078d2e7ddb433  jmp 0x000078D2E7DD9134
000078d2e7ddb438  call 0x000078D2E7CD64F0
000078d2e7ddb43d  jmp 0x000078D2E7DD9141
000078d2e7ddb442  sub rsp, 0x08
000078d2e7ddb446  push rax
000078d2e7ddb447  push rcx
000078d2e7ddb448  push rdx
000078d2e7ddb449  push rdi
000078d2e7ddb44a  push rsi
000078d2e7ddb44b  push r8
000078d2e7ddb44d  push r9
000078d2e7ddb44f  push r10
000078d2e7ddb451  push r11
000078d2e7ddb453  sub rsp, 0xF0
000078d2e7ddb45a  vmovaps [rsp], xmm0
000078d2e7ddb45f  vmovaps [rsp+0x10], xmm1
000078d2e7ddb465  vmovaps [rsp+0x20], xmm2
000078d2e7ddb46b  vmovaps [rsp+0x30], xmm3
000078d2e7ddb471  vmovaps [rsp+0x40], xmm4
000078d2e7ddb477  vmovaps [rsp+0x50], xmm6
000078d2e7ddb47d  vmovaps [rsp+0x60], xmm7
000078d2e7ddb483  vmovaps [rsp+0x70], xmm8
000078d2e7ddb489  vmovaps [rsp+0x80], xmm9
000078d2e7ddb492  vmovaps [rsp+0x90], xmm10
000078d2e7ddb49b  vmovaps [rsp+0xA0], xmm11
000078d2e7ddb4a4  vmovaps [rsp+0xB0], xmm12
000078d2e7ddb4ad  vmovaps [rsp+0xC0], xmm13
000078d2e7ddb4b6  vmovaps [rsp+0xD0], xmm14
000078d2e7ddb4bf  vmovaps [rsp+0xE0], xmm15
000078d2e7ddb4c8  sub rsp, 0x30
000078d2e7ddb4cc  movaps [rsp], xmm5
000078d2e7ddb4d0  movaps [rsp+0x10], xmm6
000078d2e7ddb4d5  movaps [rsp+0x20], xmm3
000078d2e7ddb4da  lea rdi, [rsp]
000078d2e7ddb4de  mov esi, 0x00
000078d2e7ddb4e3  mov rax, 0x5997D2DB1530
000078d2e7ddb4ed  call rax
000078d2e7ddb4ef  movaps xmm5, [rsp]
000078d2e7ddb4f3  add rsp, 0x30
000078d2e7ddb4f7  vmovaps xmm0, [rsp]
000078d2e7ddb4fc  vmovaps xmm1, [rsp+0x10]
000078d2e7ddb502  vmovaps xmm2, [rsp+0x20]
000078d2e7ddb508  vmovaps xmm3, [rsp+0x30]
000078d2e7ddb50e  vmovaps xmm4, [rsp+0x40]
000078d2e7ddb514  vmovaps xmm6, [rsp+0x50]
000078d2e7ddb51a  vmovaps xmm7, [rsp+0x60]
000078d2e7ddb520  vmovaps xmm8, [rsp+0x70]
000078d2e7ddb526  vmovaps xmm9, [rsp+0x80]
000078d2e7ddb52f  vmovaps xmm10, [rsp+0x90]
000078d2e7ddb538  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddb541  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddb54a  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddb553  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddb55c  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddb565  add rsp, 0xF0
000078d2e7ddb56c  pop r11
000078d2e7ddb56e  pop r10
000078d2e7ddb570  pop r9
000078d2e7ddb572  pop r8
000078d2e7ddb574  pop rsi
000078d2e7ddb575  pop rdi
000078d2e7ddb576  pop rdx
000078d2e7ddb577  pop rcx
000078d2e7ddb578  pop rax
000078d2e7ddb579  add rsp, 0x08
000078d2e7ddb57d  jmp 0x000078D2E7DD9167
000078d2e7ddb582  sub rsp, 0x08
000078d2e7ddb586  push rax
000078d2e7ddb587  push rcx
000078d2e7ddb588  push rdx
000078d2e7ddb589  push rdi
000078d2e7ddb58a  push rsi
000078d2e7ddb58b  push r8
000078d2e7ddb58d  push r9
000078d2e7ddb58f  push r10
000078d2e7ddb591  push r11
000078d2e7ddb593  sub rsp, 0xF0
000078d2e7ddb59a  vmovaps [rsp], xmm0
000078d2e7ddb59f  vmovaps [rsp+0x10], xmm1
000078d2e7ddb5a5  vmovaps [rsp+0x20], xmm2
000078d2e7ddb5ab  vmovaps [rsp+0x30], xmm3
000078d2e7ddb5b1  vmovaps [rsp+0x40], xmm4
000078d2e7ddb5b7  vmovaps [rsp+0x50], xmm5
000078d2e7ddb5bd  vmovaps [rsp+0x60], xmm7
000078d2e7ddb5c3  vmovaps [rsp+0x70], xmm8
000078d2e7ddb5c9  vmovaps [rsp+0x80], xmm9
000078d2e7ddb5d2  vmovaps [rsp+0x90], xmm10
000078d2e7ddb5db  vmovaps [rsp+0xA0], xmm11
000078d2e7ddb5e4  vmovaps [rsp+0xB0], xmm12
000078d2e7ddb5ed  vmovaps [rsp+0xC0], xmm13
000078d2e7ddb5f6  vmovaps [rsp+0xD0], xmm14
000078d2e7ddb5ff  vmovaps [rsp+0xE0], xmm15
000078d2e7ddb608  sub rsp, 0x30
000078d2e7ddb60c  movaps [rsp], xmm6
000078d2e7ddb610  movaps [rsp+0x10], xmm9
000078d2e7ddb616  movaps [rsp+0x20], xmm1
000078d2e7ddb61b  lea rdi, [rsp]
000078d2e7ddb61f  mov esi, 0x00
000078d2e7ddb624  mov rax, 0x5997D2DB1530
000078d2e7ddb62e  call rax
000078d2e7ddb630  movaps xmm6, [rsp]
000078d2e7ddb634  add rsp, 0x30
000078d2e7ddb638  vmovaps xmm0, [rsp]
000078d2e7ddb63d  vmovaps xmm1, [rsp+0x10]
000078d2e7ddb643  vmovaps xmm2, [rsp+0x20]
000078d2e7ddb649  vmovaps xmm3, [rsp+0x30]
000078d2e7ddb64f  vmovaps xmm4, [rsp+0x40]
000078d2e7ddb655  vmovaps xmm5, [rsp+0x50]
000078d2e7ddb65b  vmovaps xmm7, [rsp+0x60]
000078d2e7ddb661  vmovaps xmm8, [rsp+0x70]
000078d2e7ddb667  vmovaps xmm9, [rsp+0x80]
000078d2e7ddb670  vmovaps xmm10, [rsp+0x90]
000078d2e7ddb679  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddb682  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddb68b  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddb694  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddb69d  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddb6a6  add rsp, 0xF0
000078d2e7ddb6ad  pop r11
000078d2e7ddb6af  pop r10
000078d2e7ddb6b1  pop r9
000078d2e7ddb6b3  pop r8
000078d2e7ddb6b5  pop rsi
000078d2e7ddb6b6  pop rdi
000078d2e7ddb6b7  pop rdx
000078d2e7ddb6b8  pop rcx
000078d2e7ddb6b9  pop rax
000078d2e7ddb6ba  add rsp, 0x08
000078d2e7ddb6be  jmp 0x000078D2E7DD918B
000078d2e7ddb6c3  sub rsp, 0x08
000078d2e7ddb6c7  push rax
000078d2e7ddb6c8  push rcx
000078d2e7ddb6c9  push rdx
000078d2e7ddb6ca  push rdi
000078d2e7ddb6cb  push rsi
000078d2e7ddb6cc  push r8
000078d2e7ddb6ce  push r9
000078d2e7ddb6d0  push r10
000078d2e7ddb6d2  push r11
000078d2e7ddb6d4  sub rsp, 0xF0
000078d2e7ddb6db  vmovaps [rsp], xmm0
000078d2e7ddb6e0  vmovaps [rsp+0x10], xmm1
000078d2e7ddb6e6  vmovaps [rsp+0x20], xmm2
000078d2e7ddb6ec  vmovaps [rsp+0x30], xmm3
000078d2e7ddb6f2  vmovaps [rsp+0x40], xmm4
000078d2e7ddb6f8  vmovaps [rsp+0x50], xmm5
000078d2e7ddb6fe  vmovaps [rsp+0x60], xmm6
000078d2e7ddb704  vmovaps [rsp+0x70], xmm7
000078d2e7ddb70a  vmovaps [rsp+0x80], xmm8
000078d2e7ddb713  vmovaps [rsp+0x90], xmm10
000078d2e7ddb71c  vmovaps [rsp+0xA0], xmm11
000078d2e7ddb725  vmovaps [rsp+0xB0], xmm12
000078d2e7ddb72e  vmovaps [rsp+0xC0], xmm13
000078d2e7ddb737  vmovaps [rsp+0xD0], xmm14
000078d2e7ddb740  vmovaps [rsp+0xE0], xmm15
000078d2e7ddb749  sub rsp, 0x30
000078d2e7ddb74d  movaps [rsp], xmm9
000078d2e7ddb752  movaps [rsp+0x10], xmm3
000078d2e7ddb757  movaps [rsp+0x20], xmm1
000078d2e7ddb75c  lea rdi, [rsp]
000078d2e7ddb760  mov esi, 0x00
000078d2e7ddb765  mov rax, 0x5997D2DB1530
000078d2e7ddb76f  call rax
000078d2e7ddb771  movaps xmm9, [rsp]
000078d2e7ddb776  add rsp, 0x30
000078d2e7ddb77a  vmovaps xmm0, [rsp]
000078d2e7ddb77f  vmovaps xmm1, [rsp+0x10]
000078d2e7ddb785  vmovaps xmm2, [rsp+0x20]
000078d2e7ddb78b  vmovaps xmm3, [rsp+0x30]
000078d2e7ddb791  vmovaps xmm4, [rsp+0x40]
000078d2e7ddb797  vmovaps xmm5, [rsp+0x50]
000078d2e7ddb79d  vmovaps xmm6, [rsp+0x60]
000078d2e7ddb7a3  vmovaps xmm7, [rsp+0x70]
000078d2e7ddb7a9  vmovaps xmm8, [rsp+0x80]
000078d2e7ddb7b2  vmovaps xmm10, [rsp+0x90]
000078d2e7ddb7bb  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddb7c4  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddb7cd  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddb7d6  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddb7df  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddb7e8  add rsp, 0xF0
000078d2e7ddb7ef  pop r11
000078d2e7ddb7f1  pop r10
000078d2e7ddb7f3  pop r9
000078d2e7ddb7f5  pop r8
000078d2e7ddb7f7  pop rsi
000078d2e7ddb7f8  pop rdi
000078d2e7ddb7f9  pop rdx
000078d2e7ddb7fa  pop rcx
000078d2e7ddb7fb  pop rax
000078d2e7ddb7fc  add rsp, 0x08
000078d2e7ddb800  jmp 0x000078D2E7DD91D7
000078d2e7ddb805  call 0x000078D2E7CD64F0
000078d2e7ddb80a  jmp 0x000078D2E7DD91E4
000078d2e7ddb80f  sub rsp, 0x08
000078d2e7ddb813  push rax
000078d2e7ddb814  push rcx
000078d2e7ddb815  push rdx
000078d2e7ddb816  push rdi
000078d2e7ddb817  push rsi
000078d2e7ddb818  push r8
000078d2e7ddb81a  push r9
000078d2e7ddb81c  push r10
000078d2e7ddb81e  push r11
000078d2e7ddb820  sub rsp, 0xF0
000078d2e7ddb827  vmovaps [rsp], xmm0
000078d2e7ddb82c  vmovaps [rsp+0x10], xmm1
000078d2e7ddb832  vmovaps [rsp+0x20], xmm2
000078d2e7ddb838  vmovaps [rsp+0x30], xmm3
000078d2e7ddb83e  vmovaps [rsp+0x40], xmm4
000078d2e7ddb844  vmovaps [rsp+0x50], xmm5
000078d2e7ddb84a  vmovaps [rsp+0x60], xmm6
000078d2e7ddb850  vmovaps [rsp+0x70], xmm7
000078d2e7ddb856  vmovaps [rsp+0x80], xmm8
000078d2e7ddb85f  vmovaps [rsp+0x90], xmm9
000078d2e7ddb868  vmovaps [rsp+0xA0], xmm10
000078d2e7ddb871  vmovaps [rsp+0xB0], xmm11
000078d2e7ddb87a  vmovaps [rsp+0xC0], xmm12
000078d2e7ddb883  vmovaps [rsp+0xD0], xmm13
000078d2e7ddb88c  vmovaps [rsp+0xE0], xmm14
000078d2e7ddb895  sub rsp, 0x30
000078d2e7ddb899  movaps [rsp], xmm15
000078d2e7ddb89e  movaps [rsp+0x10], xmm3
000078d2e7ddb8a3  movaps [rsp+0x20], xmm7
000078d2e7ddb8a8  lea rdi, [rsp]
000078d2e7ddb8ac  mov esi, 0x00
000078d2e7ddb8b1  mov rax, 0x5997D2DB1530
000078d2e7ddb8bb  call rax
000078d2e7ddb8bd  movaps xmm15, [rsp]
000078d2e7ddb8c2  add rsp, 0x30
000078d2e7ddb8c6  vmovaps xmm0, [rsp]
000078d2e7ddb8cb  vmovaps xmm1, [rsp+0x10]
000078d2e7ddb8d1  vmovaps xmm2, [rsp+0x20]
000078d2e7ddb8d7  vmovaps xmm3, [rsp+0x30]
000078d2e7ddb8dd  vmovaps xmm4, [rsp+0x40]
000078d2e7ddb8e3  vmovaps xmm5, [rsp+0x50]
000078d2e7ddb8e9  vmovaps xmm6, [rsp+0x60]
000078d2e7ddb8ef  vmovaps xmm7, [rsp+0x70]
000078d2e7ddb8f5  vmovaps xmm8, [rsp+0x80]
000078d2e7ddb8fe  vmovaps xmm9, [rsp+0x90]
000078d2e7ddb907  vmovaps xmm10, [rsp+0xA0]
000078d2e7ddb910  vmovaps xmm11, [rsp+0xB0]
000078d2e7ddb919  vmovaps xmm12, [rsp+0xC0]
000078d2e7ddb922  vmovaps xmm13, [rsp+0xD0]
000078d2e7ddb92b  vmovaps xmm14, [rsp+0xE0]
000078d2e7ddb934  add rsp, 0xF0
000078d2e7ddb93b  pop r11
000078d2e7ddb93d  pop r10
000078d2e7ddb93f  pop r9
000078d2e7ddb941  pop r8
000078d2e7ddb943  pop rsi
000078d2e7ddb944  pop rdi
000078d2e7ddb945  pop rdx
000078d2e7ddb946  pop rcx
000078d2e7ddb947  pop rax
000078d2e7ddb948  add rsp, 0x08
000078d2e7ddb94c  jmp 0x000078D2E7DD9210
000078d2e7ddb951  sub rsp, 0x08
000078d2e7ddb955  push rax
000078d2e7ddb956  push rcx
000078d2e7ddb957  push rdx
000078d2e7ddb958  push rdi
000078d2e7ddb959  push rsi
000078d2e7ddb95a  push r8
000078d2e7ddb95c  push r9
000078d2e7ddb95e  push r10
000078d2e7ddb960  push r11
000078d2e7ddb962  sub rsp, 0xF0
000078d2e7ddb969  vmovaps [rsp], xmm0
000078d2e7ddb96e  vmovaps [rsp+0x10], xmm1
000078d2e7ddb974  vmovaps [rsp+0x20], xmm2
000078d2e7ddb97a  vmovaps [rsp+0x30], xmm4
000078d2e7ddb980  vmovaps [rsp+0x40], xmm5
000078d2e7ddb986  vmovaps [rsp+0x50], xmm6
000078d2e7ddb98c  vmovaps [rsp+0x60], xmm7
000078d2e7ddb992  vmovaps [rsp+0x70], xmm8
000078d2e7ddb998  vmovaps [rsp+0x80], xmm9
000078d2e7ddb9a1  vmovaps [rsp+0x90], xmm10
000078d2e7ddb9aa  vmovaps [rsp+0xA0], xmm11
000078d2e7ddb9b3  vmovaps [rsp+0xB0], xmm12
000078d2e7ddb9bc  vmovaps [rsp+0xC0], xmm13
000078d2e7ddb9c5  vmovaps [rsp+0xD0], xmm14
000078d2e7ddb9ce  vmovaps [rsp+0xE0], xmm15
000078d2e7ddb9d7  sub rsp, 0x30
000078d2e7ddb9db  movaps [rsp], xmm3
000078d2e7ddb9df  movaps [rsp+0x10], xmm1
000078d2e7ddb9e4  movaps [rsp+0x20], xmm15
000078d2e7ddb9ea  lea rdi, [rsp]
000078d2e7ddb9ee  mov esi, 0x00
000078d2e7ddb9f3  mov rax, 0x5997D2DB1530
000078d2e7ddb9fd  call rax
000078d2e7ddb9ff  movaps xmm3, [rsp]
000078d2e7ddba03  add rsp, 0x30
000078d2e7ddba07  vmovaps xmm0, [rsp]
000078d2e7ddba0c  vmovaps xmm1, [rsp+0x10]
000078d2e7ddba12  vmovaps xmm2, [rsp+0x20]
000078d2e7ddba18  vmovaps xmm4, [rsp+0x30]
000078d2e7ddba1e  vmovaps xmm5, [rsp+0x40]
000078d2e7ddba24  vmovaps xmm6, [rsp+0x50]
000078d2e7ddba2a  vmovaps xmm7, [rsp+0x60]
000078d2e7ddba30  vmovaps xmm8, [rsp+0x70]
000078d2e7ddba36  vmovaps xmm9, [rsp+0x80]
000078d2e7ddba3f  vmovaps xmm10, [rsp+0x90]
000078d2e7ddba48  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddba51  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddba5a  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddba63  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddba6c  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddba75  add rsp, 0xF0
000078d2e7ddba7c  pop r11
000078d2e7ddba7e  pop r10
000078d2e7ddba80  pop r9
000078d2e7ddba82  pop r8
000078d2e7ddba84  pop rsi
000078d2e7ddba85  pop rdi
000078d2e7ddba86  pop rdx
000078d2e7ddba87  pop rcx
000078d2e7ddba88  pop rax
000078d2e7ddba89  add rsp, 0x08
000078d2e7ddba8d  jmp 0x000078D2E7DD929F
000078d2e7ddba92  call 0x000078D2E7CD64F0
000078d2e7ddba97  jmp 0x000078D2E7DD92A9
000078d2e7ddba9c  sub rsp, 0x08
000078d2e7ddbaa0  push rax
000078d2e7ddbaa1  push rcx
000078d2e7ddbaa2  push rdx
000078d2e7ddbaa3  push rdi
000078d2e7ddbaa4  push rsi
000078d2e7ddbaa5  push r8
000078d2e7ddbaa7  push r9
000078d2e7ddbaa9  push r10
000078d2e7ddbaab  push r11
000078d2e7ddbaad  sub rsp, 0xF0
000078d2e7ddbab4  vmovaps [rsp], xmm0
000078d2e7ddbab9  vmovaps [rsp+0x10], xmm1
000078d2e7ddbabf  vmovaps [rsp+0x20], xmm2
000078d2e7ddbac5  vmovaps [rsp+0x30], xmm3
000078d2e7ddbacb  vmovaps [rsp+0x40], xmm4
000078d2e7ddbad1  vmovaps [rsp+0x50], xmm5
000078d2e7ddbad7  vmovaps [rsp+0x60], xmm6
000078d2e7ddbadd  vmovaps [rsp+0x70], xmm7
000078d2e7ddbae3  vmovaps [rsp+0x80], xmm8
000078d2e7ddbaec  vmovaps [rsp+0x90], xmm9
000078d2e7ddbaf5  vmovaps [rsp+0xA0], xmm10
000078d2e7ddbafe  vmovaps [rsp+0xB0], xmm11
000078d2e7ddbb07  vmovaps [rsp+0xC0], xmm12
000078d2e7ddbb10  vmovaps [rsp+0xD0], xmm13
000078d2e7ddbb19  vmovaps [rsp+0xE0], xmm14
000078d2e7ddbb22  sub rsp, 0x30
000078d2e7ddbb26  movaps [rsp], xmm15
000078d2e7ddbb2b  movaps [rsp+0x10], xmm14
000078d2e7ddbb31  movaps [rsp+0x20], xmm4
000078d2e7ddbb36  lea rdi, [rsp]
000078d2e7ddbb3a  mov esi, 0x00
000078d2e7ddbb3f  mov rax, 0x5997D2DB1530
000078d2e7ddbb49  call rax
000078d2e7ddbb4b  movaps xmm15, [rsp]
000078d2e7ddbb50  add rsp, 0x30
000078d2e7ddbb54  vmovaps xmm0, [rsp]
000078d2e7ddbb59  vmovaps xmm1, [rsp+0x10]
000078d2e7ddbb5f  vmovaps xmm2, [rsp+0x20]
000078d2e7ddbb65  vmovaps xmm3, [rsp+0x30]
000078d2e7ddbb6b  vmovaps xmm4, [rsp+0x40]
000078d2e7ddbb71  vmovaps xmm5, [rsp+0x50]
000078d2e7ddbb77  vmovaps xmm6, [rsp+0x60]
000078d2e7ddbb7d  vmovaps xmm7, [rsp+0x70]
000078d2e7ddbb83  vmovaps xmm8, [rsp+0x80]
000078d2e7ddbb8c  vmovaps xmm9, [rsp+0x90]
000078d2e7ddbb95  vmovaps xmm10, [rsp+0xA0]
000078d2e7ddbb9e  vmovaps xmm11, [rsp+0xB0]
000078d2e7ddbba7  vmovaps xmm12, [rsp+0xC0]
000078d2e7ddbbb0  vmovaps xmm13, [rsp+0xD0]
000078d2e7ddbbb9  vmovaps xmm14, [rsp+0xE0]
000078d2e7ddbbc2  add rsp, 0xF0
000078d2e7ddbbc9  pop r11
000078d2e7ddbbcb  pop r10
000078d2e7ddbbcd  pop r9
000078d2e7ddbbcf  pop r8
000078d2e7ddbbd1  pop rsi
000078d2e7ddbbd2  pop rdi
000078d2e7ddbbd3  pop rdx
000078d2e7ddbbd4  pop rcx
000078d2e7ddbbd5  pop rax
000078d2e7ddbbd6  add rsp, 0x08
000078d2e7ddbbda  jmp 0x000078D2E7DD92D7
000078d2e7ddbbdf  sub rsp, 0x08
000078d2e7ddbbe3  push rax
000078d2e7ddbbe4  push rcx
000078d2e7ddbbe5  push rdx
000078d2e7ddbbe6  push rdi
000078d2e7ddbbe7  push rsi
000078d2e7ddbbe8  push r8
000078d2e7ddbbea  push r9
000078d2e7ddbbec  push r10
000078d2e7ddbbee  push r11
000078d2e7ddbbf0  sub rsp, 0xF0
000078d2e7ddbbf7  vmovaps [rsp], xmm0
000078d2e7ddbbfc  vmovaps [rsp+0x10], xmm1
000078d2e7ddbc02  vmovaps [rsp+0x20], xmm2
000078d2e7ddbc08  vmovaps [rsp+0x30], xmm3
000078d2e7ddbc0e  vmovaps [rsp+0x40], xmm4
000078d2e7ddbc14  vmovaps [rsp+0x50], xmm5
000078d2e7ddbc1a  vmovaps [rsp+0x60], xmm6
000078d2e7ddbc20  vmovaps [rsp+0x70], xmm7
000078d2e7ddbc26  vmovaps [rsp+0x80], xmm8
000078d2e7ddbc2f  vmovaps [rsp+0x90], xmm9
000078d2e7ddbc38  vmovaps [rsp+0xA0], xmm10
000078d2e7ddbc41  vmovaps [rsp+0xB0], xmm11
000078d2e7ddbc4a  vmovaps [rsp+0xC0], xmm12
000078d2e7ddbc53  vmovaps [rsp+0xD0], xmm13
000078d2e7ddbc5c  vmovaps [rsp+0xE0], xmm15
000078d2e7ddbc65  sub rsp, 0x30
000078d2e7ddbc69  movaps [rsp], xmm14
000078d2e7ddbc6e  movaps [rsp+0x10], xmm2
000078d2e7ddbc73  movaps [rsp+0x20], xmm1
000078d2e7ddbc78  lea rdi, [rsp]
000078d2e7ddbc7c  mov esi, 0x00
000078d2e7ddbc81  mov rax, 0x5997D2DB1530
000078d2e7ddbc8b  call rax
000078d2e7ddbc8d  movaps xmm14, [rsp]
000078d2e7ddbc92  add rsp, 0x30
000078d2e7ddbc96  vmovaps xmm0, [rsp]
000078d2e7ddbc9b  vmovaps xmm1, [rsp+0x10]
000078d2e7ddbca1  vmovaps xmm2, [rsp+0x20]
000078d2e7ddbca7  vmovaps xmm3, [rsp+0x30]
000078d2e7ddbcad  vmovaps xmm4, [rsp+0x40]
000078d2e7ddbcb3  vmovaps xmm5, [rsp+0x50]
000078d2e7ddbcb9  vmovaps xmm6, [rsp+0x60]
000078d2e7ddbcbf  vmovaps xmm7, [rsp+0x70]
000078d2e7ddbcc5  vmovaps xmm8, [rsp+0x80]
000078d2e7ddbcce  vmovaps xmm9, [rsp+0x90]
000078d2e7ddbcd7  vmovaps xmm10, [rsp+0xA0]
000078d2e7ddbce0  vmovaps xmm11, [rsp+0xB0]
000078d2e7ddbce9  vmovaps xmm12, [rsp+0xC0]
000078d2e7ddbcf2  vmovaps xmm13, [rsp+0xD0]
000078d2e7ddbcfb  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddbd04  add rsp, 0xF0
000078d2e7ddbd0b  pop r11
000078d2e7ddbd0d  pop r10
000078d2e7ddbd0f  pop r9
000078d2e7ddbd11  pop r8
000078d2e7ddbd13  pop rsi
000078d2e7ddbd14  pop rdi
000078d2e7ddbd15  pop rdx
000078d2e7ddbd16  pop rcx
000078d2e7ddbd17  pop rax
000078d2e7ddbd18  add rsp, 0x08
000078d2e7ddbd1c  jmp 0x000078D2E7DD92FD
000078d2e7ddbd21  sub rsp, 0x08
000078d2e7ddbd25  push rax
000078d2e7ddbd26  push rcx
000078d2e7ddbd27  push rdx
000078d2e7ddbd28  push rdi
000078d2e7ddbd29  push rsi
000078d2e7ddbd2a  push r8
000078d2e7ddbd2c  push r9
000078d2e7ddbd2e  push r10
000078d2e7ddbd30  push r11
000078d2e7ddbd32  sub rsp, 0xF0
000078d2e7ddbd39  vmovaps [rsp], xmm0
000078d2e7ddbd3e  vmovaps [rsp+0x10], xmm2
000078d2e7ddbd44  vmovaps [rsp+0x20], xmm3
000078d2e7ddbd4a  vmovaps [rsp+0x30], xmm4
000078d2e7ddbd50  vmovaps [rsp+0x40], xmm5
000078d2e7ddbd56  vmovaps [rsp+0x50], xmm6
000078d2e7ddbd5c  vmovaps [rsp+0x60], xmm7
000078d2e7ddbd62  vmovaps [rsp+0x70], xmm8
000078d2e7ddbd68  vmovaps [rsp+0x80], xmm9
000078d2e7ddbd71  vmovaps [rsp+0x90], xmm10
000078d2e7ddbd7a  vmovaps [rsp+0xA0], xmm11
000078d2e7ddbd83  vmovaps [rsp+0xB0], xmm12
000078d2e7ddbd8c  vmovaps [rsp+0xC0], xmm13
000078d2e7ddbd95  vmovaps [rsp+0xD0], xmm14
000078d2e7ddbd9e  vmovaps [rsp+0xE0], xmm15
000078d2e7ddbda7  sub rsp, 0x30
000078d2e7ddbdab  movaps [rsp], xmm1
000078d2e7ddbdaf  movaps [rsp+0x10], xmm4
000078d2e7ddbdb4  movaps [rsp+0x20], xmm9
000078d2e7ddbdba  lea rdi, [rsp]
000078d2e7ddbdbe  mov esi, 0x00
000078d2e7ddbdc3  mov rax, 0x5997D2DB1530
000078d2e7ddbdcd  call rax
000078d2e7ddbdcf  movaps xmm1, [rsp]
000078d2e7ddbdd3  add rsp, 0x30
000078d2e7ddbdd7  vmovaps xmm0, [rsp]
000078d2e7ddbddc  vmovaps xmm2, [rsp+0x10]
000078d2e7ddbde2  vmovaps xmm3, [rsp+0x20]
000078d2e7ddbde8  vmovaps xmm4, [rsp+0x30]
000078d2e7ddbdee  vmovaps xmm5, [rsp+0x40]
000078d2e7ddbdf4  vmovaps xmm6, [rsp+0x50]
000078d2e7ddbdfa  vmovaps xmm7, [rsp+0x60]
000078d2e7ddbe00  vmovaps xmm8, [rsp+0x70]
000078d2e7ddbe06  vmovaps xmm9, [rsp+0x80]
000078d2e7ddbe0f  vmovaps xmm10, [rsp+0x90]
000078d2e7ddbe18  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddbe21  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddbe2a  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddbe33  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddbe3c  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddbe45  add rsp, 0xF0
000078d2e7ddbe4c  pop r11
000078d2e7ddbe4e  pop r10
000078d2e7ddbe50  pop r9
000078d2e7ddbe52  pop r8
000078d2e7ddbe54  pop rsi
000078d2e7ddbe55  pop rdi
000078d2e7ddbe56  pop rdx
000078d2e7ddbe57  pop rcx
000078d2e7ddbe58  pop rax
000078d2e7ddbe59  add rsp, 0x08
000078d2e7ddbe5d  jmp 0x000078D2E7DD931B
000078d2e7ddbe62  sub rsp, 0x08
000078d2e7ddbe66  push rax
000078d2e7ddbe67  push rcx
000078d2e7ddbe68  push rdx
000078d2e7ddbe69  push rdi
000078d2e7ddbe6a  push rsi
000078d2e7ddbe6b  push r8
000078d2e7ddbe6d  push r9
000078d2e7ddbe6f  push r10
000078d2e7ddbe71  push r11
000078d2e7ddbe73  sub rsp, 0xF0
000078d2e7ddbe7a  vmovaps [rsp], xmm0
000078d2e7ddbe7f  vmovaps [rsp+0x10], xmm1
000078d2e7ddbe85  vmovaps [rsp+0x20], xmm2
000078d2e7ddbe8b  vmovaps [rsp+0x30], xmm3
000078d2e7ddbe91  vmovaps [rsp+0x40], xmm5
000078d2e7ddbe97  vmovaps [rsp+0x50], xmm6
000078d2e7ddbe9d  vmovaps [rsp+0x60], xmm7
000078d2e7ddbea3  vmovaps [rsp+0x70], xmm8
000078d2e7ddbea9  vmovaps [rsp+0x80], xmm9
000078d2e7ddbeb2  vmovaps [rsp+0x90], xmm10
000078d2e7ddbebb  vmovaps [rsp+0xA0], xmm11
000078d2e7ddbec4  vmovaps [rsp+0xB0], xmm12
000078d2e7ddbecd  vmovaps [rsp+0xC0], xmm13
000078d2e7ddbed6  vmovaps [rsp+0xD0], xmm14
000078d2e7ddbedf  vmovaps [rsp+0xE0], xmm15
000078d2e7ddbee8  sub rsp, 0x30
000078d2e7ddbeec  movaps [rsp], xmm4
000078d2e7ddbef0  movaps [rsp+0x10], xmm2
000078d2e7ddbef5  movaps [rsp+0x20], xmm9
000078d2e7ddbefb  lea rdi, [rsp]
000078d2e7ddbeff  mov esi, 0x00
000078d2e7ddbf04  mov rax, 0x5997D2DB1530
000078d2e7ddbf0e  call rax
000078d2e7ddbf10  movaps xmm4, [rsp]
000078d2e7ddbf14  add rsp, 0x30
000078d2e7ddbf18  vmovaps xmm0, [rsp]
000078d2e7ddbf1d  vmovaps xmm1, [rsp+0x10]
000078d2e7ddbf23  vmovaps xmm2, [rsp+0x20]
000078d2e7ddbf29  vmovaps xmm3, [rsp+0x30]
000078d2e7ddbf2f  vmovaps xmm5, [rsp+0x40]
000078d2e7ddbf35  vmovaps xmm6, [rsp+0x50]
000078d2e7ddbf3b  vmovaps xmm7, [rsp+0x60]
000078d2e7ddbf41  vmovaps xmm8, [rsp+0x70]
000078d2e7ddbf47  vmovaps xmm9, [rsp+0x80]
000078d2e7ddbf50  vmovaps xmm10, [rsp+0x90]
000078d2e7ddbf59  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddbf62  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddbf6b  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddbf74  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddbf7d  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddbf86  add rsp, 0xF0
000078d2e7ddbf8d  pop r11
000078d2e7ddbf8f  pop r10
000078d2e7ddbf91  pop r9
000078d2e7ddbf93  pop r8
000078d2e7ddbf95  pop rsi
000078d2e7ddbf96  pop rdi
000078d2e7ddbf97  pop rdx
000078d2e7ddbf98  pop rcx
000078d2e7ddbf99  pop rax
000078d2e7ddbf9a  add rsp, 0x08
000078d2e7ddbf9e  jmp 0x000078D2E7DD934B
000078d2e7ddbfa3  sub rsp, 0x08
000078d2e7ddbfa7  push rax
000078d2e7ddbfa8  push rcx
000078d2e7ddbfa9  push rdx
000078d2e7ddbfaa  push rdi
000078d2e7ddbfab  push rsi
000078d2e7ddbfac  push r8
000078d2e7ddbfae  push r9
000078d2e7ddbfb0  push r10
000078d2e7ddbfb2  push r11
000078d2e7ddbfb4  sub rsp, 0xF0
000078d2e7ddbfbb  vmovaps [rsp], xmm0
000078d2e7ddbfc0  vmovaps [rsp+0x10], xmm1
000078d2e7ddbfc6  vmovaps [rsp+0x20], xmm2
000078d2e7ddbfcc  vmovaps [rsp+0x30], xmm3
000078d2e7ddbfd2  vmovaps [rsp+0x40], xmm4
000078d2e7ddbfd8  vmovaps [rsp+0x50], xmm5
000078d2e7ddbfde  vmovaps [rsp+0x60], xmm6
000078d2e7ddbfe4  vmovaps [rsp+0x70], xmm7
000078d2e7ddbfea  vmovaps [rsp+0x80], xmm8
000078d2e7ddbff3  vmovaps [rsp+0x90], xmm10
000078d2e7ddbffc  vmovaps [rsp+0xA0], xmm11
000078d2e7ddc005  vmovaps [rsp+0xB0], xmm12
000078d2e7ddc00e  vmovaps [rsp+0xC0], xmm13
000078d2e7ddc017  vmovaps [rsp+0xD0], xmm14
000078d2e7ddc020  vmovaps [rsp+0xE0], xmm15
000078d2e7ddc029  sub rsp, 0x30
000078d2e7ddc02d  movaps [rsp], xmm9
000078d2e7ddc032  movaps [rsp+0x10], xmm2
000078d2e7ddc037  movaps [rsp+0x20], xmm1
000078d2e7ddc03c  lea rdi, [rsp]
000078d2e7ddc040  mov esi, 0x00
000078d2e7ddc045  mov rax, 0x5997D2DB1530
000078d2e7ddc04f  call rax
000078d2e7ddc051  movaps xmm9, [rsp]
000078d2e7ddc056  add rsp, 0x30
000078d2e7ddc05a  vmovaps xmm0, [rsp]
000078d2e7ddc05f  vmovaps xmm1, [rsp+0x10]
000078d2e7ddc065  vmovaps xmm2, [rsp+0x20]
000078d2e7ddc06b  vmovaps xmm3, [rsp+0x30]
000078d2e7ddc071  vmovaps xmm4, [rsp+0x40]
000078d2e7ddc077  vmovaps xmm5, [rsp+0x50]
000078d2e7ddc07d  vmovaps xmm6, [rsp+0x60]
000078d2e7ddc083  vmovaps xmm7, [rsp+0x70]
000078d2e7ddc089  vmovaps xmm8, [rsp+0x80]
000078d2e7ddc092  vmovaps xmm10, [rsp+0x90]
000078d2e7ddc09b  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddc0a4  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddc0ad  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddc0b6  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddc0bf  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddc0c8  add rsp, 0xF0
000078d2e7ddc0cf  pop r11
000078d2e7ddc0d1  pop r10
000078d2e7ddc0d3  pop r9
000078d2e7ddc0d5  pop r8
000078d2e7ddc0d7  pop rsi
000078d2e7ddc0d8  pop rdi
000078d2e7ddc0d9  pop rdx
000078d2e7ddc0da  pop rcx
000078d2e7ddc0db  pop rax
000078d2e7ddc0dc  add rsp, 0x08
000078d2e7ddc0e0  jmp 0x000078D2E7DD9381
000078d2e7ddc0e5  sub rsp, 0x08
000078d2e7ddc0e9  push rax
000078d2e7ddc0ea  push rcx
000078d2e7ddc0eb  push rdx
000078d2e7ddc0ec  push rdi
000078d2e7ddc0ed  push rsi
000078d2e7ddc0ee  push r8
000078d2e7ddc0f0  push r9
000078d2e7ddc0f2  push r10
000078d2e7ddc0f4  push r11
000078d2e7ddc0f6  sub rsp, 0xF0
000078d2e7ddc0fd  vmovaps [rsp], xmm0
000078d2e7ddc102  vmovaps [rsp+0x10], xmm2
000078d2e7ddc108  vmovaps [rsp+0x20], xmm3
000078d2e7ddc10e  vmovaps [rsp+0x30], xmm4
000078d2e7ddc114  vmovaps [rsp+0x40], xmm5
000078d2e7ddc11a  vmovaps [rsp+0x50], xmm6
000078d2e7ddc120  vmovaps [rsp+0x60], xmm7
000078d2e7ddc126  vmovaps [rsp+0x70], xmm8
000078d2e7ddc12c  vmovaps [rsp+0x80], xmm9
000078d2e7ddc135  vmovaps [rsp+0x90], xmm10
000078d2e7ddc13e  vmovaps [rsp+0xA0], xmm11
000078d2e7ddc147  vmovaps [rsp+0xB0], xmm12
000078d2e7ddc150  vmovaps [rsp+0xC0], xmm13
000078d2e7ddc159  vmovaps [rsp+0xD0], xmm14
000078d2e7ddc162  vmovaps [rsp+0xE0], xmm15
000078d2e7ddc16b  sub rsp, 0x30
000078d2e7ddc16f  movaps [rsp], xmm1
000078d2e7ddc173  movaps [rsp+0x10], xmm15
000078d2e7ddc179  movaps [rsp+0x20], xmm6
000078d2e7ddc17e  lea rdi, [rsp]
000078d2e7ddc182  mov esi, 0x00
000078d2e7ddc187  mov rax, 0x5997D2DB1530
000078d2e7ddc191  call rax
000078d2e7ddc193  movaps xmm1, [rsp]
000078d2e7ddc197  add rsp, 0x30
000078d2e7ddc19b  vmovaps xmm0, [rsp]
000078d2e7ddc1a0  vmovaps xmm2, [rsp+0x10]
000078d2e7ddc1a6  vmovaps xmm3, [rsp+0x20]
000078d2e7ddc1ac  vmovaps xmm4, [rsp+0x30]
000078d2e7ddc1b2  vmovaps xmm5, [rsp+0x40]
000078d2e7ddc1b8  vmovaps xmm6, [rsp+0x50]
000078d2e7ddc1be  vmovaps xmm7, [rsp+0x60]
000078d2e7ddc1c4  vmovaps xmm8, [rsp+0x70]
000078d2e7ddc1ca  vmovaps xmm9, [rsp+0x80]
000078d2e7ddc1d3  vmovaps xmm10, [rsp+0x90]
000078d2e7ddc1dc  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddc1e5  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddc1ee  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddc1f7  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddc200  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddc209  add rsp, 0xF0
000078d2e7ddc210  pop r11
000078d2e7ddc212  pop r10
000078d2e7ddc214  pop r9
000078d2e7ddc216  pop r8
000078d2e7ddc218  pop rsi
000078d2e7ddc219  pop rdi
000078d2e7ddc21a  pop rdx
000078d2e7ddc21b  pop rcx
000078d2e7ddc21c  pop rax
000078d2e7ddc21d  add rsp, 0x08
000078d2e7ddc221  jmp 0x000078D2E7DD93A2
000078d2e7ddc226  sub rsp, 0x08
000078d2e7ddc22a  push rax
000078d2e7ddc22b  push rcx
000078d2e7ddc22c  push rdx
000078d2e7ddc22d  push rdi
000078d2e7ddc22e  push rsi
000078d2e7ddc22f  push r8
000078d2e7ddc231  push r9
000078d2e7ddc233  push r10
000078d2e7ddc235  push r11
000078d2e7ddc237  sub rsp, 0xF0
000078d2e7ddc23e  vmovaps [rsp], xmm0
000078d2e7ddc243  vmovaps [rsp+0x10], xmm1
000078d2e7ddc249  vmovaps [rsp+0x20], xmm2
000078d2e7ddc24f  vmovaps [rsp+0x30], xmm3
000078d2e7ddc255  vmovaps [rsp+0x40], xmm4
000078d2e7ddc25b  vmovaps [rsp+0x50], xmm5
000078d2e7ddc261  vmovaps [rsp+0x60], xmm6
000078d2e7ddc267  vmovaps [rsp+0x70], xmm7
000078d2e7ddc26d  vmovaps [rsp+0x80], xmm8
000078d2e7ddc276  vmovaps [rsp+0x90], xmm9
000078d2e7ddc27f  vmovaps [rsp+0xA0], xmm10
000078d2e7ddc288  vmovaps [rsp+0xB0], xmm11
000078d2e7ddc291  vmovaps [rsp+0xC0], xmm12
000078d2e7ddc29a  vmovaps [rsp+0xD0], xmm13
000078d2e7ddc2a3  vmovaps [rsp+0xE0], xmm14
000078d2e7ddc2ac  sub rsp, 0x30
000078d2e7ddc2b0  movaps [rsp], xmm15
000078d2e7ddc2b5  movaps [rsp+0x10], xmm5
000078d2e7ddc2ba  movaps [rsp+0x20], xmm3
000078d2e7ddc2bf  lea rdi, [rsp]
000078d2e7ddc2c3  mov esi, 0x00
000078d2e7ddc2c8  mov rax, 0x5997D2DB1530
000078d2e7ddc2d2  call rax
000078d2e7ddc2d4  movaps xmm15, [rsp]
000078d2e7ddc2d9  add rsp, 0x30
000078d2e7ddc2dd  vmovaps xmm0, [rsp]
000078d2e7ddc2e2  vmovaps xmm1, [rsp+0x10]
000078d2e7ddc2e8  vmovaps xmm2, [rsp+0x20]
000078d2e7ddc2ee  vmovaps xmm3, [rsp+0x30]
000078d2e7ddc2f4  vmovaps xmm4, [rsp+0x40]
000078d2e7ddc2fa  vmovaps xmm5, [rsp+0x50]
000078d2e7ddc300  vmovaps xmm6, [rsp+0x60]
000078d2e7ddc306  vmovaps xmm7, [rsp+0x70]
000078d2e7ddc30c  vmovaps xmm8, [rsp+0x80]
000078d2e7ddc315  vmovaps xmm9, [rsp+0x90]
000078d2e7ddc31e  vmovaps xmm10, [rsp+0xA0]
000078d2e7ddc327  vmovaps xmm11, [rsp+0xB0]
000078d2e7ddc330  vmovaps xmm12, [rsp+0xC0]
000078d2e7ddc339  vmovaps xmm13, [rsp+0xD0]
000078d2e7ddc342  vmovaps xmm14, [rsp+0xE0]
000078d2e7ddc34b  add rsp, 0xF0
000078d2e7ddc352  pop r11
000078d2e7ddc354  pop r10
000078d2e7ddc356  pop r9
000078d2e7ddc358  pop r8
000078d2e7ddc35a  pop rsi
000078d2e7ddc35b  pop rdi
000078d2e7ddc35c  pop rdx
000078d2e7ddc35d  pop rcx
000078d2e7ddc35e  pop rax
000078d2e7ddc35f  add rsp, 0x08
000078d2e7ddc363  jmp 0x000078D2E7DD93BC
000078d2e7ddc368  sub rsp, 0x08
000078d2e7ddc36c  push rax
000078d2e7ddc36d  push rcx
000078d2e7ddc36e  push rdx
000078d2e7ddc36f  push rdi
000078d2e7ddc370  push rsi
000078d2e7ddc371  push r8
000078d2e7ddc373  push r9
000078d2e7ddc375  push r10
000078d2e7ddc377  push r11
000078d2e7ddc379  sub rsp, 0xF0
000078d2e7ddc380  vmovaps [rsp], xmm0
000078d2e7ddc385  vmovaps [rsp+0x10], xmm1
000078d2e7ddc38b  vmovaps [rsp+0x20], xmm2
000078d2e7ddc391  vmovaps [rsp+0x30], xmm3
000078d2e7ddc397  vmovaps [rsp+0x40], xmm4
000078d2e7ddc39d  vmovaps [rsp+0x50], xmm6
000078d2e7ddc3a3  vmovaps [rsp+0x60], xmm7
000078d2e7ddc3a9  vmovaps [rsp+0x70], xmm8
000078d2e7ddc3af  vmovaps [rsp+0x80], xmm9
000078d2e7ddc3b8  vmovaps [rsp+0x90], xmm10
000078d2e7ddc3c1  vmovaps [rsp+0xA0], xmm11
000078d2e7ddc3ca  vmovaps [rsp+0xB0], xmm12
000078d2e7ddc3d3  vmovaps [rsp+0xC0], xmm13
000078d2e7ddc3dc  vmovaps [rsp+0xD0], xmm14
000078d2e7ddc3e5  vmovaps [rsp+0xE0], xmm15
000078d2e7ddc3ee  sub rsp, 0x30
000078d2e7ddc3f2  movaps [rsp], xmm5
000078d2e7ddc3f6  movaps [rsp+0x10], xmm8
000078d2e7ddc3fc  movaps [rsp+0x20], xmm6
000078d2e7ddc401  lea rdi, [rsp]
000078d2e7ddc405  mov esi, 0x00
000078d2e7ddc40a  mov rax, 0x5997D2DB1530
000078d2e7ddc414  call rax
000078d2e7ddc416  movaps xmm5, [rsp]
000078d2e7ddc41a  add rsp, 0x30
000078d2e7ddc41e  vmovaps xmm0, [rsp]
000078d2e7ddc423  vmovaps xmm1, [rsp+0x10]
000078d2e7ddc429  vmovaps xmm2, [rsp+0x20]
000078d2e7ddc42f  vmovaps xmm3, [rsp+0x30]
000078d2e7ddc435  vmovaps xmm4, [rsp+0x40]
000078d2e7ddc43b  vmovaps xmm6, [rsp+0x50]
000078d2e7ddc441  vmovaps xmm7, [rsp+0x60]
000078d2e7ddc447  vmovaps xmm8, [rsp+0x70]
000078d2e7ddc44d  vmovaps xmm9, [rsp+0x80]
000078d2e7ddc456  vmovaps xmm10, [rsp+0x90]
000078d2e7ddc45f  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddc468  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddc471  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddc47a  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddc483  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddc48c  add rsp, 0xF0
000078d2e7ddc493  pop r11
000078d2e7ddc495  pop r10
000078d2e7ddc497  pop r9
000078d2e7ddc499  pop r8
000078d2e7ddc49b  pop rsi
000078d2e7ddc49c  pop rdi
000078d2e7ddc49d  pop rdx
000078d2e7ddc49e  pop rcx
000078d2e7ddc49f  pop rax
000078d2e7ddc4a0  add rsp, 0x08
000078d2e7ddc4a4  jmp 0x000078D2E7DD93E0
000078d2e7ddc4a9  sub rsp, 0x08
000078d2e7ddc4ad  push rax
000078d2e7ddc4ae  push rcx
000078d2e7ddc4af  push rdx
000078d2e7ddc4b0  push rdi
000078d2e7ddc4b1  push rsi
000078d2e7ddc4b2  push r8
000078d2e7ddc4b4  push r9
000078d2e7ddc4b6  push r10
000078d2e7ddc4b8  push r11
000078d2e7ddc4ba  sub rsp, 0xF0
000078d2e7ddc4c1  vmovaps [rsp], xmm0
000078d2e7ddc4c6  vmovaps [rsp+0x10], xmm1
000078d2e7ddc4cc  vmovaps [rsp+0x20], xmm2
000078d2e7ddc4d2  vmovaps [rsp+0x30], xmm3
000078d2e7ddc4d8  vmovaps [rsp+0x40], xmm4
000078d2e7ddc4de  vmovaps [rsp+0x50], xmm5
000078d2e7ddc4e4  vmovaps [rsp+0x60], xmm7
000078d2e7ddc4ea  vmovaps [rsp+0x70], xmm8
000078d2e7ddc4f0  vmovaps [rsp+0x80], xmm9
000078d2e7ddc4f9  vmovaps [rsp+0x90], xmm10
000078d2e7ddc502  vmovaps [rsp+0xA0], xmm11
000078d2e7ddc50b  vmovaps [rsp+0xB0], xmm12
000078d2e7ddc514  vmovaps [rsp+0xC0], xmm13
000078d2e7ddc51d  vmovaps [rsp+0xD0], xmm14
000078d2e7ddc526  vmovaps [rsp+0xE0], xmm15
000078d2e7ddc52f  sub rsp, 0x30
000078d2e7ddc533  movaps [rsp], xmm6
000078d2e7ddc537  movaps [rsp+0x10], xmm10
000078d2e7ddc53d  movaps [rsp+0x20], xmm8
000078d2e7ddc543  lea rdi, [rsp]
000078d2e7ddc547  mov esi, 0x00
000078d2e7ddc54c  mov rax, 0x5997D2DB1530
000078d2e7ddc556  call rax
000078d2e7ddc558  movaps xmm6, [rsp]
000078d2e7ddc55c  add rsp, 0x30
000078d2e7ddc560  vmovaps xmm0, [rsp]
000078d2e7ddc565  vmovaps xmm1, [rsp+0x10]
000078d2e7ddc56b  vmovaps xmm2, [rsp+0x20]
000078d2e7ddc571  vmovaps xmm3, [rsp+0x30]
000078d2e7ddc577  vmovaps xmm4, [rsp+0x40]
000078d2e7ddc57d  vmovaps xmm5, [rsp+0x50]
000078d2e7ddc583  vmovaps xmm7, [rsp+0x60]
000078d2e7ddc589  vmovaps xmm8, [rsp+0x70]
000078d2e7ddc58f  vmovaps xmm9, [rsp+0x80]
000078d2e7ddc598  vmovaps xmm10, [rsp+0x90]
000078d2e7ddc5a1  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddc5aa  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddc5b3  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddc5bc  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddc5c5  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddc5ce  add rsp, 0xF0
000078d2e7ddc5d5  pop r11
000078d2e7ddc5d7  pop r10
000078d2e7ddc5d9  pop r9
000078d2e7ddc5db  pop r8
000078d2e7ddc5dd  pop rsi
000078d2e7ddc5de  pop rdi
000078d2e7ddc5df  pop rdx
000078d2e7ddc5e0  pop rcx
000078d2e7ddc5e1  pop rax
000078d2e7ddc5e2  add rsp, 0x08
000078d2e7ddc5e6  jmp 0x000078D2E7DD9405
000078d2e7ddc5eb  sub rsp, 0x08
000078d2e7ddc5ef  push rax
000078d2e7ddc5f0  push rcx
000078d2e7ddc5f1  push rdx
000078d2e7ddc5f2  push rdi
000078d2e7ddc5f3  push rsi
000078d2e7ddc5f4  push r8
000078d2e7ddc5f6  push r9
000078d2e7ddc5f8  push r10
000078d2e7ddc5fa  push r11
000078d2e7ddc5fc  sub rsp, 0xF0
000078d2e7ddc603  vmovaps [rsp], xmm0
000078d2e7ddc608  vmovaps [rsp+0x10], xmm1
000078d2e7ddc60e  vmovaps [rsp+0x20], xmm2
000078d2e7ddc614  vmovaps [rsp+0x30], xmm3
000078d2e7ddc61a  vmovaps [rsp+0x40], xmm4
000078d2e7ddc620  vmovaps [rsp+0x50], xmm5
000078d2e7ddc626  vmovaps [rsp+0x60], xmm6
000078d2e7ddc62c  vmovaps [rsp+0x70], xmm7
000078d2e7ddc632  vmovaps [rsp+0x80], xmm8
000078d2e7ddc63b  vmovaps [rsp+0x90], xmm9
000078d2e7ddc644  vmovaps [rsp+0xA0], xmm11
000078d2e7ddc64d  vmovaps [rsp+0xB0], xmm12
000078d2e7ddc656  vmovaps [rsp+0xC0], xmm13
000078d2e7ddc65f  vmovaps [rsp+0xD0], xmm14
000078d2e7ddc668  vmovaps [rsp+0xE0], xmm15
000078d2e7ddc671  sub rsp, 0x30
000078d2e7ddc675  movaps [rsp], xmm10
000078d2e7ddc67a  movaps [rsp+0x10], xmm8
000078d2e7ddc680  movaps [rsp+0x20], xmm14
000078d2e7ddc686  lea rdi, [rsp]
000078d2e7ddc68a  mov esi, 0x00
000078d2e7ddc68f  mov rax, 0x5997D2DB1530
000078d2e7ddc699  call rax
000078d2e7ddc69b  movaps xmm10, [rsp]
000078d2e7ddc6a0  add rsp, 0x30
000078d2e7ddc6a4  vmovaps xmm0, [rsp]
000078d2e7ddc6a9  vmovaps xmm1, [rsp+0x10]
000078d2e7ddc6af  vmovaps xmm2, [rsp+0x20]
000078d2e7ddc6b5  vmovaps xmm3, [rsp+0x30]
000078d2e7ddc6bb  vmovaps xmm4, [rsp+0x40]
000078d2e7ddc6c1  vmovaps xmm5, [rsp+0x50]
000078d2e7ddc6c7  vmovaps xmm6, [rsp+0x60]
000078d2e7ddc6cd  vmovaps xmm7, [rsp+0x70]
000078d2e7ddc6d3  vmovaps xmm8, [rsp+0x80]
000078d2e7ddc6dc  vmovaps xmm9, [rsp+0x90]
000078d2e7ddc6e5  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddc6ee  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddc6f7  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddc700  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddc709  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddc712  add rsp, 0xF0
000078d2e7ddc719  pop r11
000078d2e7ddc71b  pop r10
000078d2e7ddc71d  pop r9
000078d2e7ddc71f  pop r8
000078d2e7ddc721  pop rsi
000078d2e7ddc722  pop rdi
000078d2e7ddc723  pop rdx
000078d2e7ddc724  pop rcx
000078d2e7ddc725  pop rax
000078d2e7ddc726  add rsp, 0x08
000078d2e7ddc72a  jmp 0x000078D2E7DD9425
000078d2e7ddc72f  sub rsp, 0x08
000078d2e7ddc733  push rax
000078d2e7ddc734  push rcx
000078d2e7ddc735  push rdx
000078d2e7ddc736  push rdi
000078d2e7ddc737  push rsi
000078d2e7ddc738  push r8
000078d2e7ddc73a  push r9
000078d2e7ddc73c  push r10
000078d2e7ddc73e  push r11
000078d2e7ddc740  sub rsp, 0xF0
000078d2e7ddc747  vmovaps [rsp], xmm0
000078d2e7ddc74c  vmovaps [rsp+0x10], xmm1
000078d2e7ddc752  vmovaps [rsp+0x20], xmm2
000078d2e7ddc758  vmovaps [rsp+0x30], xmm3
000078d2e7ddc75e  vmovaps [rsp+0x40], xmm4
000078d2e7ddc764  vmovaps [rsp+0x50], xmm5
000078d2e7ddc76a  vmovaps [rsp+0x60], xmm6
000078d2e7ddc770  vmovaps [rsp+0x70], xmm7
000078d2e7ddc776  vmovaps [rsp+0x80], xmm8
000078d2e7ddc77f  vmovaps [rsp+0x90], xmm9
000078d2e7ddc788  vmovaps [rsp+0xA0], xmm10
000078d2e7ddc791  vmovaps [rsp+0xB0], xmm11
000078d2e7ddc79a  vmovaps [rsp+0xC0], xmm12
000078d2e7ddc7a3  vmovaps [rsp+0xD0], xmm13
000078d2e7ddc7ac  vmovaps [rsp+0xE0], xmm15
000078d2e7ddc7b5  sub rsp, 0x30
000078d2e7ddc7b9  movaps [rsp], xmm14
000078d2e7ddc7be  movaps [rsp+0x10], xmm8
000078d2e7ddc7c4  movaps [rsp+0x20], xmm4
000078d2e7ddc7c9  lea rdi, [rsp]
000078d2e7ddc7cd  mov esi, 0x00
000078d2e7ddc7d2  mov rax, 0x5997D2DB1530
000078d2e7ddc7dc  call rax
000078d2e7ddc7de  movaps xmm14, [rsp]
000078d2e7ddc7e3  add rsp, 0x30
000078d2e7ddc7e7  vmovaps xmm0, [rsp]
000078d2e7ddc7ec  vmovaps xmm1, [rsp+0x10]
000078d2e7ddc7f2  vmovaps xmm2, [rsp+0x20]
000078d2e7ddc7f8  vmovaps xmm3, [rsp+0x30]
000078d2e7ddc7fe  vmovaps xmm4, [rsp+0x40]
000078d2e7ddc804  vmovaps xmm5, [rsp+0x50]
000078d2e7ddc80a  vmovaps xmm6, [rsp+0x60]
000078d2e7ddc810  vmovaps xmm7, [rsp+0x70]
000078d2e7ddc816  vmovaps xmm8, [rsp+0x80]
000078d2e7ddc81f  vmovaps xmm9, [rsp+0x90]
000078d2e7ddc828  vmovaps xmm10, [rsp+0xA0]
000078d2e7ddc831  vmovaps xmm11, [rsp+0xB0]
000078d2e7ddc83a  vmovaps xmm12, [rsp+0xC0]
000078d2e7ddc843  vmovaps xmm13, [rsp+0xD0]
000078d2e7ddc84c  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddc855  add rsp, 0xF0
000078d2e7ddc85c  pop r11
000078d2e7ddc85e  pop r10
000078d2e7ddc860  pop r9
000078d2e7ddc862  pop r8
000078d2e7ddc864  pop rsi
000078d2e7ddc865  pop rdi
000078d2e7ddc866  pop rdx
000078d2e7ddc867  pop rcx
000078d2e7ddc868  pop rax
000078d2e7ddc869  add rsp, 0x08
000078d2e7ddc86d  jmp 0x000078D2E7DD9445
000078d2e7ddc872  sub rsp, 0x08
000078d2e7ddc876  push rax
000078d2e7ddc877  push rcx
000078d2e7ddc878  push rdx
000078d2e7ddc879  push rdi
000078d2e7ddc87a  push rsi
000078d2e7ddc87b  push r8
000078d2e7ddc87d  push r9
000078d2e7ddc87f  push r10
000078d2e7ddc881  push r11
000078d2e7ddc883  sub rsp, 0xF0
000078d2e7ddc88a  vmovaps [rsp], xmm0
000078d2e7ddc88f  vmovaps [rsp+0x10], xmm1
000078d2e7ddc895  vmovaps [rsp+0x20], xmm2
000078d2e7ddc89b  vmovaps [rsp+0x30], xmm3
000078d2e7ddc8a1  vmovaps [rsp+0x40], xmm5
000078d2e7ddc8a7  vmovaps [rsp+0x50], xmm6
000078d2e7ddc8ad  vmovaps [rsp+0x60], xmm7
000078d2e7ddc8b3  vmovaps [rsp+0x70], xmm8
000078d2e7ddc8b9  vmovaps [rsp+0x80], xmm9
000078d2e7ddc8c2  vmovaps [rsp+0x90], xmm10
000078d2e7ddc8cb  vmovaps [rsp+0xA0], xmm11
000078d2e7ddc8d4  vmovaps [rsp+0xB0], xmm12
000078d2e7ddc8dd  vmovaps [rsp+0xC0], xmm13
000078d2e7ddc8e6  vmovaps [rsp+0xD0], xmm14
000078d2e7ddc8ef  vmovaps [rsp+0xE0], xmm15
000078d2e7ddc8f8  sub rsp, 0x30
000078d2e7ddc8fc  movaps [rsp], xmm4
000078d2e7ddc900  movaps [rsp+0x10], xmm13
000078d2e7ddc906  movaps [rsp+0x20], xmm8
000078d2e7ddc90c  lea rdi, [rsp]
000078d2e7ddc910  mov esi, 0x00
000078d2e7ddc915  mov rax, 0x5997D2DB1530
000078d2e7ddc91f  call rax
000078d2e7ddc921  movaps xmm4, [rsp]
000078d2e7ddc925  add rsp, 0x30
000078d2e7ddc929  vmovaps xmm0, [rsp]
000078d2e7ddc92e  vmovaps xmm1, [rsp+0x10]
000078d2e7ddc934  vmovaps xmm2, [rsp+0x20]
000078d2e7ddc93a  vmovaps xmm3, [rsp+0x30]
000078d2e7ddc940  vmovaps xmm5, [rsp+0x40]
000078d2e7ddc946  vmovaps xmm6, [rsp+0x50]
000078d2e7ddc94c  vmovaps xmm7, [rsp+0x60]
000078d2e7ddc952  vmovaps xmm8, [rsp+0x70]
000078d2e7ddc958  vmovaps xmm9, [rsp+0x80]
000078d2e7ddc961  vmovaps xmm10, [rsp+0x90]
000078d2e7ddc96a  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddc973  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddc97c  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddc985  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddc98e  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddc997  add rsp, 0xF0
000078d2e7ddc99e  pop r11
000078d2e7ddc9a0  pop r10
000078d2e7ddc9a2  pop r9
000078d2e7ddc9a4  pop r8
000078d2e7ddc9a6  pop rsi
000078d2e7ddc9a7  pop rdi
000078d2e7ddc9a8  pop rdx
000078d2e7ddc9a9  pop rcx
000078d2e7ddc9aa  pop rax
000078d2e7ddc9ab  add rsp, 0x08
000078d2e7ddc9af  jmp 0x000078D2E7DD946A
000078d2e7ddc9b4  sub rsp, 0x08
000078d2e7ddc9b8  push rax
000078d2e7ddc9b9  push rcx
000078d2e7ddc9ba  push rdx
000078d2e7ddc9bb  push rdi
000078d2e7ddc9bc  push rsi
000078d2e7ddc9bd  push r8
000078d2e7ddc9bf  push r9
000078d2e7ddc9c1  push r10
000078d2e7ddc9c3  push r11
000078d2e7ddc9c5  sub rsp, 0xF0
000078d2e7ddc9cc  vmovaps [rsp], xmm0
000078d2e7ddc9d1  vmovaps [rsp+0x10], xmm1
000078d2e7ddc9d7  vmovaps [rsp+0x20], xmm2
000078d2e7ddc9dd  vmovaps [rsp+0x30], xmm3
000078d2e7ddc9e3  vmovaps [rsp+0x40], xmm4
000078d2e7ddc9e9  vmovaps [rsp+0x50], xmm5
000078d2e7ddc9ef  vmovaps [rsp+0x60], xmm6
000078d2e7ddc9f5  vmovaps [rsp+0x70], xmm7
000078d2e7ddc9fb  vmovaps [rsp+0x80], xmm8
000078d2e7ddca04  vmovaps [rsp+0x90], xmm9
000078d2e7ddca0d  vmovaps [rsp+0xA0], xmm10
000078d2e7ddca16  vmovaps [rsp+0xB0], xmm11
000078d2e7ddca1f  vmovaps [rsp+0xC0], xmm12
000078d2e7ddca28  vmovaps [rsp+0xD0], xmm14
000078d2e7ddca31  vmovaps [rsp+0xE0], xmm15
000078d2e7ddca3a  sub rsp, 0x30
000078d2e7ddca3e  movaps [rsp], xmm13
000078d2e7ddca43  movaps [rsp+0x10], xmm15
000078d2e7ddca49  movaps [rsp+0x20], xmm9
000078d2e7ddca4f  lea rdi, [rsp]
000078d2e7ddca53  mov esi, 0x00
000078d2e7ddca58  mov rax, 0x5997D2DB1530
000078d2e7ddca62  call rax
000078d2e7ddca64  movaps xmm13, [rsp]
000078d2e7ddca69  add rsp, 0x30
000078d2e7ddca6d  vmovaps xmm0, [rsp]
000078d2e7ddca72  vmovaps xmm1, [rsp+0x10]
000078d2e7ddca78  vmovaps xmm2, [rsp+0x20]
000078d2e7ddca7e  vmovaps xmm3, [rsp+0x30]
000078d2e7ddca84  vmovaps xmm4, [rsp+0x40]
000078d2e7ddca8a  vmovaps xmm5, [rsp+0x50]
000078d2e7ddca90  vmovaps xmm6, [rsp+0x60]
000078d2e7ddca96  vmovaps xmm7, [rsp+0x70]
000078d2e7ddca9c  vmovaps xmm8, [rsp+0x80]
000078d2e7ddcaa5  vmovaps xmm9, [rsp+0x90]
000078d2e7ddcaae  vmovaps xmm10, [rsp+0xA0]
000078d2e7ddcab7  vmovaps xmm11, [rsp+0xB0]
000078d2e7ddcac0  vmovaps xmm12, [rsp+0xC0]
000078d2e7ddcac9  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddcad2  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddcadb  add rsp, 0xF0
000078d2e7ddcae2  pop r11
000078d2e7ddcae4  pop r10
000078d2e7ddcae6  pop r9
000078d2e7ddcae8  pop r8
000078d2e7ddcaea  pop rsi
000078d2e7ddcaeb  pop rdi
000078d2e7ddcaec  pop rdx
000078d2e7ddcaed  pop rcx
000078d2e7ddcaee  pop rax
000078d2e7ddcaef  add rsp, 0x08
000078d2e7ddcaf3  jmp 0x000078D2E7DD9485
000078d2e7ddcaf8  sub rsp, 0x08
000078d2e7ddcafc  push rax
000078d2e7ddcafd  push rcx
000078d2e7ddcafe  push rdx
000078d2e7ddcaff  push rdi
000078d2e7ddcb00  push rsi
000078d2e7ddcb01  push r8
000078d2e7ddcb03  push r9
000078d2e7ddcb05  push r10
000078d2e7ddcb07  push r11
000078d2e7ddcb09  sub rsp, 0xF0
000078d2e7ddcb10  vmovaps [rsp], xmm0
000078d2e7ddcb15  vmovaps [rsp+0x10], xmm1
000078d2e7ddcb1b  vmovaps [rsp+0x20], xmm2
000078d2e7ddcb21  vmovaps [rsp+0x30], xmm3
000078d2e7ddcb27  vmovaps [rsp+0x40], xmm4
000078d2e7ddcb2d  vmovaps [rsp+0x50], xmm5
000078d2e7ddcb33  vmovaps [rsp+0x60], xmm6
000078d2e7ddcb39  vmovaps [rsp+0x70], xmm7
000078d2e7ddcb3f  vmovaps [rsp+0x80], xmm8
000078d2e7ddcb48  vmovaps [rsp+0x90], xmm9
000078d2e7ddcb51  vmovaps [rsp+0xA0], xmm10
000078d2e7ddcb5a  vmovaps [rsp+0xB0], xmm11
000078d2e7ddcb63  vmovaps [rsp+0xC0], xmm12
000078d2e7ddcb6c  vmovaps [rsp+0xD0], xmm13
000078d2e7ddcb75  vmovaps [rsp+0xE0], xmm14
000078d2e7ddcb7e  sub rsp, 0x30
000078d2e7ddcb82  movaps [rsp], xmm15
000078d2e7ddcb87  movaps [rsp+0x10], xmm1
000078d2e7ddcb8c  movaps [rsp+0x20], xmm5
000078d2e7ddcb91  lea rdi, [rsp]
000078d2e7ddcb95  mov esi, 0x00
000078d2e7ddcb9a  mov rax, 0x5997D2DB1530
000078d2e7ddcba4  call rax
000078d2e7ddcba6  movaps xmm15, [rsp]
000078d2e7ddcbab  add rsp, 0x30
000078d2e7ddcbaf  vmovaps xmm0, [rsp]
000078d2e7ddcbb4  vmovaps xmm1, [rsp+0x10]
000078d2e7ddcbba  vmovaps xmm2, [rsp+0x20]
000078d2e7ddcbc0  vmovaps xmm3, [rsp+0x30]
000078d2e7ddcbc6  vmovaps xmm4, [rsp+0x40]
000078d2e7ddcbcc  vmovaps xmm5, [rsp+0x50]
000078d2e7ddcbd2  vmovaps xmm6, [rsp+0x60]
000078d2e7ddcbd8  vmovaps xmm7, [rsp+0x70]
000078d2e7ddcbde  vmovaps xmm8, [rsp+0x80]
000078d2e7ddcbe7  vmovaps xmm9, [rsp+0x90]
000078d2e7ddcbf0  vmovaps xmm10, [rsp+0xA0]
000078d2e7ddcbf9  vmovaps xmm11, [rsp+0xB0]
000078d2e7ddcc02  vmovaps xmm12, [rsp+0xC0]
000078d2e7ddcc0b  vmovaps xmm13, [rsp+0xD0]
000078d2e7ddcc14  vmovaps xmm14, [rsp+0xE0]
000078d2e7ddcc1d  add rsp, 0xF0
000078d2e7ddcc24  pop r11
000078d2e7ddcc26  pop r10
000078d2e7ddcc28  pop r9
000078d2e7ddcc2a  pop r8
000078d2e7ddcc2c  pop rsi
000078d2e7ddcc2d  pop rdi
000078d2e7ddcc2e  pop rdx
000078d2e7ddcc2f  pop rcx
000078d2e7ddcc30  pop rax
000078d2e7ddcc31  add rsp, 0x08
000078d2e7ddcc35  jmp 0x000078D2E7DD94A0
000078d2e7ddcc3a  call 0x000078D2E7CD64F0
000078d2e7ddcc3f  jmp 0x000078D2E7DD94FB
000078d2e7ddcc44  sub rsp, 0x08
000078d2e7ddcc48  push rax
000078d2e7ddcc49  push rcx
000078d2e7ddcc4a  push rdx
000078d2e7ddcc4b  push rdi
000078d2e7ddcc4c  push rsi
000078d2e7ddcc4d  push r8
000078d2e7ddcc4f  push r9
000078d2e7ddcc51  push r10
000078d2e7ddcc53  push r11
000078d2e7ddcc55  sub rsp, 0xF0
000078d2e7ddcc5c  vmovaps [rsp], xmm0
000078d2e7ddcc61  vmovaps [rsp+0x10], xmm1
000078d2e7ddcc67  vmovaps [rsp+0x20], xmm2
000078d2e7ddcc6d  vmovaps [rsp+0x30], xmm3
000078d2e7ddcc73  vmovaps [rsp+0x40], xmm4
000078d2e7ddcc79  vmovaps [rsp+0x50], xmm5
000078d2e7ddcc7f  vmovaps [rsp+0x60], xmm6
000078d2e7ddcc85  vmovaps [rsp+0x70], xmm7
000078d2e7ddcc8b  vmovaps [rsp+0x80], xmm8
000078d2e7ddcc94  vmovaps [rsp+0x90], xmm10
000078d2e7ddcc9d  vmovaps [rsp+0xA0], xmm11
000078d2e7ddcca6  vmovaps [rsp+0xB0], xmm12
000078d2e7ddccaf  vmovaps [rsp+0xC0], xmm13
000078d2e7ddccb8  vmovaps [rsp+0xD0], xmm14
000078d2e7ddccc1  vmovaps [rsp+0xE0], xmm15
000078d2e7ddccca  sub rsp, 0x30
000078d2e7ddccce  movaps [rsp], xmm9
000078d2e7ddccd3  movaps [rsp+0x10], xmm8
000078d2e7ddccd9  movaps [rsp+0x20], xmm11
000078d2e7ddccdf  lea rdi, [rsp]
000078d2e7ddcce3  mov esi, 0x00
000078d2e7ddcce8  mov rax, 0x5997D2DB1530
000078d2e7ddccf2  call rax
000078d2e7ddccf4  movaps xmm9, [rsp]
000078d2e7ddccf9  add rsp, 0x30
000078d2e7ddccfd  vmovaps xmm0, [rsp]
000078d2e7ddcd02  vmovaps xmm1, [rsp+0x10]
000078d2e7ddcd08  vmovaps xmm2, [rsp+0x20]
000078d2e7ddcd0e  vmovaps xmm3, [rsp+0x30]
000078d2e7ddcd14  vmovaps xmm4, [rsp+0x40]
000078d2e7ddcd1a  vmovaps xmm5, [rsp+0x50]
000078d2e7ddcd20  vmovaps xmm6, [rsp+0x60]
000078d2e7ddcd26  vmovaps xmm7, [rsp+0x70]
000078d2e7ddcd2c  vmovaps xmm8, [rsp+0x80]
000078d2e7ddcd35  vmovaps xmm10, [rsp+0x90]
000078d2e7ddcd3e  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddcd47  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddcd50  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddcd59  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddcd62  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddcd6b  add rsp, 0xF0
000078d2e7ddcd72  pop r11
000078d2e7ddcd74  pop r10
000078d2e7ddcd76  pop r9
000078d2e7ddcd78  pop r8
000078d2e7ddcd7a  pop rsi
000078d2e7ddcd7b  pop rdi
000078d2e7ddcd7c  pop rdx
000078d2e7ddcd7d  pop rcx
000078d2e7ddcd7e  pop rax
000078d2e7ddcd7f  add rsp, 0x08
000078d2e7ddcd83  jmp 0x000078D2E7DD9532
000078d2e7ddcd88  sub rsp, 0x08
000078d2e7ddcd8c  push rax
000078d2e7ddcd8d  push rcx
000078d2e7ddcd8e  push rdx
000078d2e7ddcd8f  push rdi
000078d2e7ddcd90  push rsi
000078d2e7ddcd91  push r8
000078d2e7ddcd93  push r9
000078d2e7ddcd95  push r10
000078d2e7ddcd97  push r11
000078d2e7ddcd99  sub rsp, 0xF0
000078d2e7ddcda0  vmovaps [rsp], xmm0
000078d2e7ddcda5  vmovaps [rsp+0x10], xmm1
000078d2e7ddcdab  vmovaps [rsp+0x20], xmm2
000078d2e7ddcdb1  vmovaps [rsp+0x30], xmm3
000078d2e7ddcdb7  vmovaps [rsp+0x40], xmm4
000078d2e7ddcdbd  vmovaps [rsp+0x50], xmm5
000078d2e7ddcdc3  vmovaps [rsp+0x60], xmm6
000078d2e7ddcdc9  vmovaps [rsp+0x70], xmm7
000078d2e7ddcdcf  vmovaps [rsp+0x80], xmm8
000078d2e7ddcdd8  vmovaps [rsp+0x90], xmm9
000078d2e7ddcde1  vmovaps [rsp+0xA0], xmm10
000078d2e7ddcdea  vmovaps [rsp+0xB0], xmm12
000078d2e7ddcdf3  vmovaps [rsp+0xC0], xmm13
000078d2e7ddcdfc  vmovaps [rsp+0xD0], xmm14
000078d2e7ddce05  vmovaps [rsp+0xE0], xmm15
000078d2e7ddce0e  sub rsp, 0x30
000078d2e7ddce12  movaps [rsp], xmm11
000078d2e7ddce17  movaps [rsp+0x10], xmm10
000078d2e7ddce1d  movaps [rsp+0x20], xmm6
000078d2e7ddce22  lea rdi, [rsp]
000078d2e7ddce26  mov esi, 0x00
000078d2e7ddce2b  mov rax, 0x5997D2DB1530
000078d2e7ddce35  call rax
000078d2e7ddce37  movaps xmm11, [rsp]
000078d2e7ddce3c  add rsp, 0x30
000078d2e7ddce40  vmovaps xmm0, [rsp]
000078d2e7ddce45  vmovaps xmm1, [rsp+0x10]
000078d2e7ddce4b  vmovaps xmm2, [rsp+0x20]
000078d2e7ddce51  vmovaps xmm3, [rsp+0x30]
000078d2e7ddce57  vmovaps xmm4, [rsp+0x40]
000078d2e7ddce5d  vmovaps xmm5, [rsp+0x50]
000078d2e7ddce63  vmovaps xmm6, [rsp+0x60]
000078d2e7ddce69  vmovaps xmm7, [rsp+0x70]
000078d2e7ddce6f  vmovaps xmm8, [rsp+0x80]
000078d2e7ddce78  vmovaps xmm9, [rsp+0x90]
000078d2e7ddce81  vmovaps xmm10, [rsp+0xA0]
000078d2e7ddce8a  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddce93  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddce9c  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddcea5  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddceae  add rsp, 0xF0
000078d2e7ddceb5  pop r11
000078d2e7ddceb7  pop r10
000078d2e7ddceb9  pop r9
000078d2e7ddcebb  pop r8
000078d2e7ddcebd  pop rsi
000078d2e7ddcebe  pop rdi
000078d2e7ddcebf  pop rdx
000078d2e7ddcec0  pop rcx
000078d2e7ddcec1  pop rax
000078d2e7ddcec2  add rsp, 0x08
000078d2e7ddcec6  jmp 0x000078D2E7DD954D
000078d2e7ddcecb  sub rsp, 0x08
000078d2e7ddcecf  push rax
000078d2e7ddced0  push rcx
000078d2e7ddced1  push rdx
000078d2e7ddced2  push rdi
000078d2e7ddced3  push rsi
000078d2e7ddced4  push r8
000078d2e7ddced6  push r9
000078d2e7ddced8  push r10
000078d2e7ddceda  push r11
000078d2e7ddcedc  sub rsp, 0xF0
000078d2e7ddcee3  vmovaps [rsp], xmm0
000078d2e7ddcee8  vmovaps [rsp+0x10], xmm1
000078d2e7ddceee  vmovaps [rsp+0x20], xmm2
000078d2e7ddcef4  vmovaps [rsp+0x30], xmm3
000078d2e7ddcefa  vmovaps [rsp+0x40], xmm4
000078d2e7ddcf00  vmovaps [rsp+0x50], xmm5
000078d2e7ddcf06  vmovaps [rsp+0x60], xmm6
000078d2e7ddcf0c  vmovaps [rsp+0x70], xmm7
000078d2e7ddcf12  vmovaps [rsp+0x80], xmm8
000078d2e7ddcf1b  vmovaps [rsp+0x90], xmm9
000078d2e7ddcf24  vmovaps [rsp+0xA0], xmm11
000078d2e7ddcf2d  vmovaps [rsp+0xB0], xmm12
000078d2e7ddcf36  vmovaps [rsp+0xC0], xmm13
000078d2e7ddcf3f  vmovaps [rsp+0xD0], xmm14
000078d2e7ddcf48  vmovaps [rsp+0xE0], xmm15
000078d2e7ddcf51  sub rsp, 0x30
000078d2e7ddcf55  movaps [rsp], xmm10
000078d2e7ddcf5a  movaps [rsp+0x10], xmm14
000078d2e7ddcf60  movaps [rsp+0x20], xmm4
000078d2e7ddcf65  lea rdi, [rsp]
000078d2e7ddcf69  mov esi, 0x00
000078d2e7ddcf6e  mov rax, 0x5997D2DB1530
000078d2e7ddcf78  call rax
000078d2e7ddcf7a  movaps xmm10, [rsp]
000078d2e7ddcf7f  add rsp, 0x30
000078d2e7ddcf83  vmovaps xmm0, [rsp]
000078d2e7ddcf88  vmovaps xmm1, [rsp+0x10]
000078d2e7ddcf8e  vmovaps xmm2, [rsp+0x20]
000078d2e7ddcf94  vmovaps xmm3, [rsp+0x30]
000078d2e7ddcf9a  vmovaps xmm4, [rsp+0x40]
000078d2e7ddcfa0  vmovaps xmm5, [rsp+0x50]
000078d2e7ddcfa6  vmovaps xmm6, [rsp+0x60]
000078d2e7ddcfac  vmovaps xmm7, [rsp+0x70]
000078d2e7ddcfb2  vmovaps xmm8, [rsp+0x80]
000078d2e7ddcfbb  vmovaps xmm9, [rsp+0x90]
000078d2e7ddcfc4  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddcfcd  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddcfd6  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddcfdf  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddcfe8  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddcff1  add rsp, 0xF0
000078d2e7ddcff8  pop r11
000078d2e7ddcffa  pop r10
000078d2e7ddcffc  pop r9
000078d2e7ddcffe  pop r8
000078d2e7ddd000  pop rsi
000078d2e7ddd001  pop rdi
000078d2e7ddd002  pop rdx
000078d2e7ddd003  pop rcx
000078d2e7ddd004  pop rax
000078d2e7ddd005  add rsp, 0x08
000078d2e7ddd009  jmp 0x000078D2E7DD9568
000078d2e7ddd00e  sub rsp, 0x08
000078d2e7ddd012  push rax
000078d2e7ddd013  push rcx
000078d2e7ddd014  push rdx
000078d2e7ddd015  push rdi
000078d2e7ddd016  push rsi
000078d2e7ddd017  push r8
000078d2e7ddd019  push r9
000078d2e7ddd01b  push r10
000078d2e7ddd01d  push r11
000078d2e7ddd01f  sub rsp, 0xF0
000078d2e7ddd026  vmovaps [rsp], xmm0
000078d2e7ddd02b  vmovaps [rsp+0x10], xmm1
000078d2e7ddd031  vmovaps [rsp+0x20], xmm2
000078d2e7ddd037  vmovaps [rsp+0x30], xmm3
000078d2e7ddd03d  vmovaps [rsp+0x40], xmm4
000078d2e7ddd043  vmovaps [rsp+0x50], xmm5
000078d2e7ddd049  vmovaps [rsp+0x60], xmm6
000078d2e7ddd04f  vmovaps [rsp+0x70], xmm7
000078d2e7ddd055  vmovaps [rsp+0x80], xmm9
000078d2e7ddd05e  vmovaps [rsp+0x90], xmm10
000078d2e7ddd067  vmovaps [rsp+0xA0], xmm11
000078d2e7ddd070  vmovaps [rsp+0xB0], xmm12
000078d2e7ddd079  vmovaps [rsp+0xC0], xmm13
000078d2e7ddd082  vmovaps [rsp+0xD0], xmm14
000078d2e7ddd08b  vmovaps [rsp+0xE0], xmm15
000078d2e7ddd094  sub rsp, 0x30
000078d2e7ddd098  movaps [rsp], xmm8
000078d2e7ddd09d  movaps [rsp+0x10], xmm1
000078d2e7ddd0a2  movaps [rsp+0x20], xmm14
000078d2e7ddd0a8  lea rdi, [rsp]
000078d2e7ddd0ac  mov esi, 0x00
000078d2e7ddd0b1  mov rax, 0x5997D2DB1530
000078d2e7ddd0bb  call rax
000078d2e7ddd0bd  movaps xmm8, [rsp]
000078d2e7ddd0c2  add rsp, 0x30
000078d2e7ddd0c6  vmovaps xmm0, [rsp]
000078d2e7ddd0cb  vmovaps xmm1, [rsp+0x10]
000078d2e7ddd0d1  vmovaps xmm2, [rsp+0x20]
000078d2e7ddd0d7  vmovaps xmm3, [rsp+0x30]
000078d2e7ddd0dd  vmovaps xmm4, [rsp+0x40]
000078d2e7ddd0e3  vmovaps xmm5, [rsp+0x50]
000078d2e7ddd0e9  vmovaps xmm6, [rsp+0x60]
000078d2e7ddd0ef  vmovaps xmm7, [rsp+0x70]
000078d2e7ddd0f5  vmovaps xmm9, [rsp+0x80]
000078d2e7ddd0fe  vmovaps xmm10, [rsp+0x90]
000078d2e7ddd107  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddd110  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddd119  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddd122  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddd12b  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddd134  add rsp, 0xF0
000078d2e7ddd13b  pop r11
000078d2e7ddd13d  pop r10
000078d2e7ddd13f  pop r9
000078d2e7ddd141  pop r8
000078d2e7ddd143  pop rsi
000078d2e7ddd144  pop rdi
000078d2e7ddd145  pop rdx
000078d2e7ddd146  pop rcx
000078d2e7ddd147  pop rax
000078d2e7ddd148  add rsp, 0x08
000078d2e7ddd14c  jmp 0x000078D2E7DD958E
000078d2e7ddd151  sub rsp, 0x08
000078d2e7ddd155  push rax
000078d2e7ddd156  push rcx
000078d2e7ddd157  push rdx
000078d2e7ddd158  push rdi
000078d2e7ddd159  push rsi
000078d2e7ddd15a  push r8
000078d2e7ddd15c  push r9
000078d2e7ddd15e  push r10
000078d2e7ddd160  push r11
000078d2e7ddd162  sub rsp, 0xF0
000078d2e7ddd169  vmovaps [rsp], xmm0
000078d2e7ddd16e  vmovaps [rsp+0x10], xmm1
000078d2e7ddd174  vmovaps [rsp+0x20], xmm2
000078d2e7ddd17a  vmovaps [rsp+0x30], xmm3
000078d2e7ddd180  vmovaps [rsp+0x40], xmm4
000078d2e7ddd186  vmovaps [rsp+0x50], xmm5
000078d2e7ddd18c  vmovaps [rsp+0x60], xmm7
000078d2e7ddd192  vmovaps [rsp+0x70], xmm8
000078d2e7ddd198  vmovaps [rsp+0x80], xmm9
000078d2e7ddd1a1  vmovaps [rsp+0x90], xmm10
000078d2e7ddd1aa  vmovaps [rsp+0xA0], xmm11
000078d2e7ddd1b3  vmovaps [rsp+0xB0], xmm12
000078d2e7ddd1bc  vmovaps [rsp+0xC0], xmm13
000078d2e7ddd1c5  vmovaps [rsp+0xD0], xmm14
000078d2e7ddd1ce  vmovaps [rsp+0xE0], xmm15
000078d2e7ddd1d7  sub rsp, 0x30
000078d2e7ddd1db  movaps [rsp], xmm6
000078d2e7ddd1df  movaps [rsp+0x10], xmm1
000078d2e7ddd1e4  movaps [rsp+0x20], xmm14
000078d2e7ddd1ea  lea rdi, [rsp]
000078d2e7ddd1ee  mov esi, 0x00
000078d2e7ddd1f3  mov rax, 0x5997D2DB1530
000078d2e7ddd1fd  call rax
000078d2e7ddd1ff  movaps xmm6, [rsp]
000078d2e7ddd203  add rsp, 0x30
000078d2e7ddd207  vmovaps xmm0, [rsp]
000078d2e7ddd20c  vmovaps xmm1, [rsp+0x10]
000078d2e7ddd212  vmovaps xmm2, [rsp+0x20]
000078d2e7ddd218  vmovaps xmm3, [rsp+0x30]
000078d2e7ddd21e  vmovaps xmm4, [rsp+0x40]
000078d2e7ddd224  vmovaps xmm5, [rsp+0x50]
000078d2e7ddd22a  vmovaps xmm7, [rsp+0x60]
000078d2e7ddd230  vmovaps xmm8, [rsp+0x70]
000078d2e7ddd236  vmovaps xmm9, [rsp+0x80]
000078d2e7ddd23f  vmovaps xmm10, [rsp+0x90]
000078d2e7ddd248  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddd251  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddd25a  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddd263  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddd26c  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddd275  add rsp, 0xF0
000078d2e7ddd27c  pop r11
000078d2e7ddd27e  pop r10
000078d2e7ddd280  pop r9
000078d2e7ddd282  pop r8
000078d2e7ddd284  pop rsi
000078d2e7ddd285  pop rdi
000078d2e7ddd286  pop rdx
000078d2e7ddd287  pop rcx
000078d2e7ddd288  pop rax
000078d2e7ddd289  add rsp, 0x08
000078d2e7ddd28d  jmp 0x000078D2E7DD95BA
000078d2e7ddd292  sub rsp, 0x08
000078d2e7ddd296  push rax
000078d2e7ddd297  push rcx
000078d2e7ddd298  push rdx
000078d2e7ddd299  push rdi
000078d2e7ddd29a  push rsi
000078d2e7ddd29b  push r8
000078d2e7ddd29d  push r9
000078d2e7ddd29f  push r10
000078d2e7ddd2a1  push r11
000078d2e7ddd2a3  sub rsp, 0xF0
000078d2e7ddd2aa  vmovaps [rsp], xmm0
000078d2e7ddd2af  vmovaps [rsp+0x10], xmm1
000078d2e7ddd2b5  vmovaps [rsp+0x20], xmm2
000078d2e7ddd2bb  vmovaps [rsp+0x30], xmm3
000078d2e7ddd2c1  vmovaps [rsp+0x40], xmm4
000078d2e7ddd2c7  vmovaps [rsp+0x50], xmm5
000078d2e7ddd2cd  vmovaps [rsp+0x60], xmm6
000078d2e7ddd2d3  vmovaps [rsp+0x70], xmm7
000078d2e7ddd2d9  vmovaps [rsp+0x80], xmm8
000078d2e7ddd2e2  vmovaps [rsp+0x90], xmm9
000078d2e7ddd2eb  vmovaps [rsp+0xA0], xmm10
000078d2e7ddd2f4  vmovaps [rsp+0xB0], xmm11
000078d2e7ddd2fd  vmovaps [rsp+0xC0], xmm12
000078d2e7ddd306  vmovaps [rsp+0xD0], xmm13
000078d2e7ddd30f  vmovaps [rsp+0xE0], xmm15
000078d2e7ddd318  sub rsp, 0x30
000078d2e7ddd31c  movaps [rsp], xmm14
000078d2e7ddd321  movaps [rsp+0x10], xmm12
000078d2e7ddd327  movaps [rsp+0x20], xmm1
000078d2e7ddd32c  lea rdi, [rsp]
000078d2e7ddd330  mov esi, 0x00
000078d2e7ddd335  mov rax, 0x5997D2DB1530
000078d2e7ddd33f  call rax
000078d2e7ddd341  movaps xmm14, [rsp]
000078d2e7ddd346  add rsp, 0x30
000078d2e7ddd34a  vmovaps xmm0, [rsp]
000078d2e7ddd34f  vmovaps xmm1, [rsp+0x10]
000078d2e7ddd355  vmovaps xmm2, [rsp+0x20]
000078d2e7ddd35b  vmovaps xmm3, [rsp+0x30]
000078d2e7ddd361  vmovaps xmm4, [rsp+0x40]
000078d2e7ddd367  vmovaps xmm5, [rsp+0x50]
000078d2e7ddd36d  vmovaps xmm6, [rsp+0x60]
000078d2e7ddd373  vmovaps xmm7, [rsp+0x70]
000078d2e7ddd379  vmovaps xmm8, [rsp+0x80]
000078d2e7ddd382  vmovaps xmm9, [rsp+0x90]
000078d2e7ddd38b  vmovaps xmm10, [rsp+0xA0]
000078d2e7ddd394  vmovaps xmm11, [rsp+0xB0]
000078d2e7ddd39d  vmovaps xmm12, [rsp+0xC0]
000078d2e7ddd3a6  vmovaps xmm13, [rsp+0xD0]
000078d2e7ddd3af  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddd3b8  add rsp, 0xF0
000078d2e7ddd3bf  pop r11
000078d2e7ddd3c1  pop r10
000078d2e7ddd3c3  pop r9
000078d2e7ddd3c5  pop r8
000078d2e7ddd3c7  pop rsi
000078d2e7ddd3c8  pop rdi
000078d2e7ddd3c9  pop rdx
000078d2e7ddd3ca  pop rcx
000078d2e7ddd3cb  pop rax
000078d2e7ddd3cc  add rsp, 0x08
000078d2e7ddd3d0  jmp 0x000078D2E7DD95E0
000078d2e7ddd3d5  sub rsp, 0x08
000078d2e7ddd3d9  push rax
000078d2e7ddd3da  push rcx
000078d2e7ddd3db  push rdx
000078d2e7ddd3dc  push rdi
000078d2e7ddd3dd  push rsi
000078d2e7ddd3de  push r8
000078d2e7ddd3e0  push r9
000078d2e7ddd3e2  push r10
000078d2e7ddd3e4  push r11
000078d2e7ddd3e6  sub rsp, 0xF0
000078d2e7ddd3ed  vmovaps [rsp], xmm0
000078d2e7ddd3f2  vmovaps [rsp+0x10], xmm2
000078d2e7ddd3f8  vmovaps [rsp+0x20], xmm3
000078d2e7ddd3fe  vmovaps [rsp+0x30], xmm4
000078d2e7ddd404  vmovaps [rsp+0x40], xmm5
000078d2e7ddd40a  vmovaps [rsp+0x50], xmm6
000078d2e7ddd410  vmovaps [rsp+0x60], xmm7
000078d2e7ddd416  vmovaps [rsp+0x70], xmm8
000078d2e7ddd41c  vmovaps [rsp+0x80], xmm9
000078d2e7ddd425  vmovaps [rsp+0x90], xmm10
000078d2e7ddd42e  vmovaps [rsp+0xA0], xmm11
000078d2e7ddd437  vmovaps [rsp+0xB0], xmm12
000078d2e7ddd440  vmovaps [rsp+0xC0], xmm13
000078d2e7ddd449  vmovaps [rsp+0xD0], xmm14
000078d2e7ddd452  vmovaps [rsp+0xE0], xmm15
000078d2e7ddd45b  sub rsp, 0x30
000078d2e7ddd45f  movaps [rsp], xmm1
000078d2e7ddd463  movaps [rsp+0x10], xmm13
000078d2e7ddd469  movaps [rsp+0x20], xmm9
000078d2e7ddd46f  lea rdi, [rsp]
000078d2e7ddd473  mov esi, 0x00
000078d2e7ddd478  mov rax, 0x5997D2DB1530
000078d2e7ddd482  call rax
000078d2e7ddd484  movaps xmm1, [rsp]
000078d2e7ddd488  add rsp, 0x30
000078d2e7ddd48c  vmovaps xmm0, [rsp]
000078d2e7ddd491  vmovaps xmm2, [rsp+0x10]
000078d2e7ddd497  vmovaps xmm3, [rsp+0x20]
000078d2e7ddd49d  vmovaps xmm4, [rsp+0x30]
000078d2e7ddd4a3  vmovaps xmm5, [rsp+0x40]
000078d2e7ddd4a9  vmovaps xmm6, [rsp+0x50]
000078d2e7ddd4af  vmovaps xmm7, [rsp+0x60]
000078d2e7ddd4b5  vmovaps xmm8, [rsp+0x70]
000078d2e7ddd4bb  vmovaps xmm9, [rsp+0x80]
000078d2e7ddd4c4  vmovaps xmm10, [rsp+0x90]
000078d2e7ddd4cd  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddd4d6  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddd4df  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddd4e8  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddd4f1  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddd4fa  add rsp, 0xF0
000078d2e7ddd501  pop r11
000078d2e7ddd503  pop r10
000078d2e7ddd505  pop r9
000078d2e7ddd507  pop r8
000078d2e7ddd509  pop rsi
000078d2e7ddd50a  pop rdi
000078d2e7ddd50b  pop rdx
000078d2e7ddd50c  pop rcx
000078d2e7ddd50d  pop rax
000078d2e7ddd50e  add rsp, 0x08
000078d2e7ddd512  jmp 0x000078D2E7DD95FA
000078d2e7ddd517  sub rsp, 0x08
000078d2e7ddd51b  push rax
000078d2e7ddd51c  push rcx
000078d2e7ddd51d  push rdx
000078d2e7ddd51e  push rdi
000078d2e7ddd51f  push rsi
000078d2e7ddd520  push r8
000078d2e7ddd522  push r9
000078d2e7ddd524  push r10
000078d2e7ddd526  push r11
000078d2e7ddd528  sub rsp, 0xF0
000078d2e7ddd52f  vmovaps [rsp], xmm0
000078d2e7ddd534  vmovaps [rsp+0x10], xmm1
000078d2e7ddd53a  vmovaps [rsp+0x20], xmm2
000078d2e7ddd540  vmovaps [rsp+0x30], xmm3
000078d2e7ddd546  vmovaps [rsp+0x40], xmm4
000078d2e7ddd54c  vmovaps [rsp+0x50], xmm5
000078d2e7ddd552  vmovaps [rsp+0x60], xmm6
000078d2e7ddd558  vmovaps [rsp+0x70], xmm7
000078d2e7ddd55e  vmovaps [rsp+0x80], xmm8
000078d2e7ddd567  vmovaps [rsp+0x90], xmm9
000078d2e7ddd570  vmovaps [rsp+0xA0], xmm10
000078d2e7ddd579  vmovaps [rsp+0xB0], xmm11
000078d2e7ddd582  vmovaps [rsp+0xC0], xmm13
000078d2e7ddd58b  vmovaps [rsp+0xD0], xmm14
000078d2e7ddd594  vmovaps [rsp+0xE0], xmm15
000078d2e7ddd59d  sub rsp, 0x30
000078d2e7ddd5a1  movaps [rsp], xmm12
000078d2e7ddd5a6  movaps [rsp+0x10], xmm7
000078d2e7ddd5ab  movaps [rsp+0x20], xmm13
000078d2e7ddd5b1  lea rdi, [rsp]
000078d2e7ddd5b5  mov esi, 0x00
000078d2e7ddd5ba  mov rax, 0x5997D2DB1530
000078d2e7ddd5c4  call rax
000078d2e7ddd5c6  movaps xmm12, [rsp]
000078d2e7ddd5cb  add rsp, 0x30
000078d2e7ddd5cf  vmovaps xmm0, [rsp]
000078d2e7ddd5d4  vmovaps xmm1, [rsp+0x10]
000078d2e7ddd5da  vmovaps xmm2, [rsp+0x20]
000078d2e7ddd5e0  vmovaps xmm3, [rsp+0x30]
000078d2e7ddd5e6  vmovaps xmm4, [rsp+0x40]
000078d2e7ddd5ec  vmovaps xmm5, [rsp+0x50]
000078d2e7ddd5f2  vmovaps xmm6, [rsp+0x60]
000078d2e7ddd5f8  vmovaps xmm7, [rsp+0x70]
000078d2e7ddd5fe  vmovaps xmm8, [rsp+0x80]
000078d2e7ddd607  vmovaps xmm9, [rsp+0x90]
000078d2e7ddd610  vmovaps xmm10, [rsp+0xA0]
000078d2e7ddd619  vmovaps xmm11, [rsp+0xB0]
000078d2e7ddd622  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddd62b  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddd634  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddd63d  add rsp, 0xF0
000078d2e7ddd644  pop r11
000078d2e7ddd646  pop r10
000078d2e7ddd648  pop r9
000078d2e7ddd64a  pop r8
000078d2e7ddd64c  pop rsi
000078d2e7ddd64d  pop rdi
000078d2e7ddd64e  pop rdx
000078d2e7ddd64f  pop rcx
000078d2e7ddd650  pop rax
000078d2e7ddd651  add rsp, 0x08
000078d2e7ddd655  jmp 0x000078D2E7DD9621
000078d2e7ddd65a  sub rsp, 0x08
000078d2e7ddd65e  push rax
000078d2e7ddd65f  push rcx
000078d2e7ddd660  push rdx
000078d2e7ddd661  push rdi
000078d2e7ddd662  push rsi
000078d2e7ddd663  push r8
000078d2e7ddd665  push r9
000078d2e7ddd667  push r10
000078d2e7ddd669  push r11
000078d2e7ddd66b  sub rsp, 0xF0
000078d2e7ddd672  vmovaps [rsp], xmm0
000078d2e7ddd677  vmovaps [rsp+0x10], xmm1
000078d2e7ddd67d  vmovaps [rsp+0x20], xmm2
000078d2e7ddd683  vmovaps [rsp+0x30], xmm3
000078d2e7ddd689  vmovaps [rsp+0x40], xmm4
000078d2e7ddd68f  vmovaps [rsp+0x50], xmm5
000078d2e7ddd695  vmovaps [rsp+0x60], xmm6
000078d2e7ddd69b  vmovaps [rsp+0x70], xmm7
000078d2e7ddd6a1  vmovaps [rsp+0x80], xmm8
000078d2e7ddd6aa  vmovaps [rsp+0x90], xmm9
000078d2e7ddd6b3  vmovaps [rsp+0xA0], xmm10
000078d2e7ddd6bc  vmovaps [rsp+0xB0], xmm11
000078d2e7ddd6c5  vmovaps [rsp+0xC0], xmm12
000078d2e7ddd6ce  vmovaps [rsp+0xD0], xmm14
000078d2e7ddd6d7  vmovaps [rsp+0xE0], xmm15
000078d2e7ddd6e0  sub rsp, 0x30
000078d2e7ddd6e4  movaps [rsp], xmm13
000078d2e7ddd6e9  movaps [rsp+0x10], xmm15
000078d2e7ddd6ef  movaps [rsp+0x20], xmm8
000078d2e7ddd6f5  lea rdi, [rsp]
000078d2e7ddd6f9  mov esi, 0x00
000078d2e7ddd6fe  mov rax, 0x5997D2DB1530
000078d2e7ddd708  call rax
000078d2e7ddd70a  movaps xmm13, [rsp]
000078d2e7ddd70f  add rsp, 0x30
000078d2e7ddd713  vmovaps xmm0, [rsp]
000078d2e7ddd718  vmovaps xmm1, [rsp+0x10]
000078d2e7ddd71e  vmovaps xmm2, [rsp+0x20]
000078d2e7ddd724  vmovaps xmm3, [rsp+0x30]
000078d2e7ddd72a  vmovaps xmm4, [rsp+0x40]
000078d2e7ddd730  vmovaps xmm5, [rsp+0x50]
000078d2e7ddd736  vmovaps xmm6, [rsp+0x60]
000078d2e7ddd73c  vmovaps xmm7, [rsp+0x70]
000078d2e7ddd742  vmovaps xmm8, [rsp+0x80]
000078d2e7ddd74b  vmovaps xmm9, [rsp+0x90]
000078d2e7ddd754  vmovaps xmm10, [rsp+0xA0]
000078d2e7ddd75d  vmovaps xmm11, [rsp+0xB0]
000078d2e7ddd766  vmovaps xmm12, [rsp+0xC0]
000078d2e7ddd76f  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddd778  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddd781  add rsp, 0xF0
000078d2e7ddd788  pop r11
000078d2e7ddd78a  pop r10
000078d2e7ddd78c  pop r9
000078d2e7ddd78e  pop r8
000078d2e7ddd790  pop rsi
000078d2e7ddd791  pop rdi
000078d2e7ddd792  pop rdx
000078d2e7ddd793  pop rcx
000078d2e7ddd794  pop rax
000078d2e7ddd795  add rsp, 0x08
000078d2e7ddd799  jmp 0x000078D2E7DD963C
000078d2e7ddd79e  sub rsp, 0x08
000078d2e7ddd7a2  push rax
000078d2e7ddd7a3  push rcx
000078d2e7ddd7a4  push rdx
000078d2e7ddd7a5  push rdi
000078d2e7ddd7a6  push rsi
000078d2e7ddd7a7  push r8
000078d2e7ddd7a9  push r9
000078d2e7ddd7ab  push r10
000078d2e7ddd7ad  push r11
000078d2e7ddd7af  sub rsp, 0xF0
000078d2e7ddd7b6  vmovaps [rsp], xmm0
000078d2e7ddd7bb  vmovaps [rsp+0x10], xmm1
000078d2e7ddd7c1  vmovaps [rsp+0x20], xmm2
000078d2e7ddd7c7  vmovaps [rsp+0x30], xmm3
000078d2e7ddd7cd  vmovaps [rsp+0x40], xmm4
000078d2e7ddd7d3  vmovaps [rsp+0x50], xmm5
000078d2e7ddd7d9  vmovaps [rsp+0x60], xmm6
000078d2e7ddd7df  vmovaps [rsp+0x70], xmm7
000078d2e7ddd7e5  vmovaps [rsp+0x80], xmm9
000078d2e7ddd7ee  vmovaps [rsp+0x90], xmm10
000078d2e7ddd7f7  vmovaps [rsp+0xA0], xmm11
000078d2e7ddd800  vmovaps [rsp+0xB0], xmm12
000078d2e7ddd809  vmovaps [rsp+0xC0], xmm13
000078d2e7ddd812  vmovaps [rsp+0xD0], xmm14
000078d2e7ddd81b  vmovaps [rsp+0xE0], xmm15
000078d2e7ddd824  sub rsp, 0x30
000078d2e7ddd828  movaps [rsp], xmm8
000078d2e7ddd82d  movaps [rsp+0x10], xmm15
000078d2e7ddd833  movaps [rsp+0x20], xmm9
000078d2e7ddd839  lea rdi, [rsp]
000078d2e7ddd83d  mov esi, 0x00
000078d2e7ddd842  mov rax, 0x5997D2DB1530
000078d2e7ddd84c  call rax
000078d2e7ddd84e  movaps xmm8, [rsp]
000078d2e7ddd853  add rsp, 0x30
000078d2e7ddd857  vmovaps xmm0, [rsp]
000078d2e7ddd85c  vmovaps xmm1, [rsp+0x10]
000078d2e7ddd862  vmovaps xmm2, [rsp+0x20]
000078d2e7ddd868  vmovaps xmm3, [rsp+0x30]
000078d2e7ddd86e  vmovaps xmm4, [rsp+0x40]
000078d2e7ddd874  vmovaps xmm5, [rsp+0x50]
000078d2e7ddd87a  vmovaps xmm6, [rsp+0x60]
000078d2e7ddd880  vmovaps xmm7, [rsp+0x70]
000078d2e7ddd886  vmovaps xmm9, [rsp+0x80]
000078d2e7ddd88f  vmovaps xmm10, [rsp+0x90]
000078d2e7ddd898  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddd8a1  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddd8aa  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddd8b3  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddd8bc  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddd8c5  add rsp, 0xF0
000078d2e7ddd8cc  pop r11
000078d2e7ddd8ce  pop r10
000078d2e7ddd8d0  pop r9
000078d2e7ddd8d2  pop r8
000078d2e7ddd8d4  pop rsi
000078d2e7ddd8d5  pop rdi
000078d2e7ddd8d6  pop rdx
000078d2e7ddd8d7  pop rcx
000078d2e7ddd8d8  pop rax
000078d2e7ddd8d9  add rsp, 0x08
000078d2e7ddd8dd  jmp 0x000078D2E7DD966A
000078d2e7ddd8e2  sub rsp, 0x08
000078d2e7ddd8e6  push rax
000078d2e7ddd8e7  push rcx
000078d2e7ddd8e8  push rdx
000078d2e7ddd8e9  push rdi
000078d2e7ddd8ea  push rsi
000078d2e7ddd8eb  push r8
000078d2e7ddd8ed  push r9
000078d2e7ddd8ef  push r10
000078d2e7ddd8f1  push r11
000078d2e7ddd8f3  sub rsp, 0xF0
000078d2e7ddd8fa  vmovaps [rsp], xmm0
000078d2e7ddd8ff  vmovaps [rsp+0x10], xmm1
000078d2e7ddd905  vmovaps [rsp+0x20], xmm2
000078d2e7ddd90b  vmovaps [rsp+0x30], xmm3
000078d2e7ddd911  vmovaps [rsp+0x40], xmm4
000078d2e7ddd917  vmovaps [rsp+0x50], xmm5
000078d2e7ddd91d  vmovaps [rsp+0x60], xmm6
000078d2e7ddd923  vmovaps [rsp+0x70], xmm7
000078d2e7ddd929  vmovaps [rsp+0x80], xmm8
000078d2e7ddd932  vmovaps [rsp+0x90], xmm9
000078d2e7ddd93b  vmovaps [rsp+0xA0], xmm10
000078d2e7ddd944  vmovaps [rsp+0xB0], xmm11
000078d2e7ddd94d  vmovaps [rsp+0xC0], xmm12
000078d2e7ddd956  vmovaps [rsp+0xD0], xmm13
000078d2e7ddd95f  vmovaps [rsp+0xE0], xmm14
000078d2e7ddd968  sub rsp, 0x30
000078d2e7ddd96c  movaps [rsp], xmm15
000078d2e7ddd971  movaps [rsp+0x10], xmm11
000078d2e7ddd977  movaps [rsp+0x20], xmm6
000078d2e7ddd97c  lea rdi, [rsp]
000078d2e7ddd980  mov esi, 0x00
000078d2e7ddd985  mov rax, 0x5997D2DB1530
000078d2e7ddd98f  call rax
000078d2e7ddd991  movaps xmm15, [rsp]
000078d2e7ddd996  add rsp, 0x30
000078d2e7ddd99a  vmovaps xmm0, [rsp]
000078d2e7ddd99f  vmovaps xmm1, [rsp+0x10]
000078d2e7ddd9a5  vmovaps xmm2, [rsp+0x20]
000078d2e7ddd9ab  vmovaps xmm3, [rsp+0x30]
000078d2e7ddd9b1  vmovaps xmm4, [rsp+0x40]
000078d2e7ddd9b7  vmovaps xmm5, [rsp+0x50]
000078d2e7ddd9bd  vmovaps xmm6, [rsp+0x60]
000078d2e7ddd9c3  vmovaps xmm7, [rsp+0x70]
000078d2e7ddd9c9  vmovaps xmm8, [rsp+0x80]
000078d2e7ddd9d2  vmovaps xmm9, [rsp+0x90]
000078d2e7ddd9db  vmovaps xmm10, [rsp+0xA0]
000078d2e7ddd9e4  vmovaps xmm11, [rsp+0xB0]
000078d2e7ddd9ed  vmovaps xmm12, [rsp+0xC0]
000078d2e7ddd9f6  vmovaps xmm13, [rsp+0xD0]
000078d2e7ddd9ff  vmovaps xmm14, [rsp+0xE0]
000078d2e7ddda08  add rsp, 0xF0
000078d2e7ddda0f  pop r11
000078d2e7ddda11  pop r10
000078d2e7ddda13  pop r9
000078d2e7ddda15  pop r8
000078d2e7ddda17  pop rsi
000078d2e7ddda18  pop rdi
000078d2e7ddda19  pop rdx
000078d2e7ddda1a  pop rcx
000078d2e7ddda1b  pop rax
000078d2e7ddda1c  add rsp, 0x08
000078d2e7ddda20  jmp 0x000078D2E7DD9685
000078d2e7ddda25  sub rsp, 0x08
000078d2e7ddda29  push rax
000078d2e7ddda2a  push rcx
000078d2e7ddda2b  push rdx
000078d2e7ddda2c  push rdi
000078d2e7ddda2d  push rsi
000078d2e7ddda2e  push r8
000078d2e7ddda30  push r9
000078d2e7ddda32  push r10
000078d2e7ddda34  push r11
000078d2e7ddda36  sub rsp, 0xF0
000078d2e7ddda3d  vmovaps [rsp], xmm0
000078d2e7ddda42  vmovaps [rsp+0x10], xmm1
000078d2e7ddda48  vmovaps [rsp+0x20], xmm2
000078d2e7ddda4e  vmovaps [rsp+0x30], xmm3
000078d2e7ddda54  vmovaps [rsp+0x40], xmm4
000078d2e7ddda5a  vmovaps [rsp+0x50], xmm5
000078d2e7ddda60  vmovaps [rsp+0x60], xmm6
000078d2e7ddda66  vmovaps [rsp+0x70], xmm8
000078d2e7ddda6c  vmovaps [rsp+0x80], xmm9
000078d2e7ddda75  vmovaps [rsp+0x90], xmm10
000078d2e7ddda7e  vmovaps [rsp+0xA0], xmm11
000078d2e7ddda87  vmovaps [rsp+0xB0], xmm12
000078d2e7ddda90  vmovaps [rsp+0xC0], xmm13
000078d2e7ddda99  vmovaps [rsp+0xD0], xmm14
000078d2e7dddaa2  vmovaps [rsp+0xE0], xmm15
000078d2e7dddaab  sub rsp, 0x30
000078d2e7dddaaf  movaps [rsp], xmm7
000078d2e7dddab3  movaps [rsp+0x10], xmm11
000078d2e7dddab9  movaps [rsp+0x20], xmm9
000078d2e7dddabf  lea rdi, [rsp]
000078d2e7dddac3  mov esi, 0x00
000078d2e7dddac8  mov rax, 0x5997D2DB1530
000078d2e7dddad2  call rax
000078d2e7dddad4  movaps xmm7, [rsp]
000078d2e7dddad8  add rsp, 0x30
000078d2e7dddadc  vmovaps xmm0, [rsp]
000078d2e7dddae1  vmovaps xmm1, [rsp+0x10]
000078d2e7dddae7  vmovaps xmm2, [rsp+0x20]
000078d2e7dddaed  vmovaps xmm3, [rsp+0x30]
000078d2e7dddaf3  vmovaps xmm4, [rsp+0x40]
000078d2e7dddaf9  vmovaps xmm5, [rsp+0x50]
000078d2e7dddaff  vmovaps xmm6, [rsp+0x60]
000078d2e7dddb05  vmovaps xmm8, [rsp+0x70]
000078d2e7dddb0b  vmovaps xmm9, [rsp+0x80]
000078d2e7dddb14  vmovaps xmm10, [rsp+0x90]
000078d2e7dddb1d  vmovaps xmm11, [rsp+0xA0]
000078d2e7dddb26  vmovaps xmm12, [rsp+0xB0]
000078d2e7dddb2f  vmovaps xmm13, [rsp+0xC0]
000078d2e7dddb38  vmovaps xmm14, [rsp+0xD0]
000078d2e7dddb41  vmovaps xmm15, [rsp+0xE0]
000078d2e7dddb4a  add rsp, 0xF0
000078d2e7dddb51  pop r11
000078d2e7dddb53  pop r10
000078d2e7dddb55  pop r9
000078d2e7dddb57  pop r8
000078d2e7dddb59  pop rsi
000078d2e7dddb5a  pop rdi
000078d2e7dddb5b  pop rdx
000078d2e7dddb5c  pop rcx
000078d2e7dddb5d  pop rax
000078d2e7dddb5e  add rsp, 0x08
000078d2e7dddb62  jmp 0x000078D2E7DD96B2
000078d2e7dddb67  sub rsp, 0x08
000078d2e7dddb6b  push rax
000078d2e7dddb6c  push rcx
000078d2e7dddb6d  push rdx
000078d2e7dddb6e  push rdi
000078d2e7dddb6f  push rsi
000078d2e7dddb70  push r8
000078d2e7dddb72  push r9
000078d2e7dddb74  push r10
000078d2e7dddb76  push r11
000078d2e7dddb78  sub rsp, 0xF0
000078d2e7dddb7f  vmovaps [rsp], xmm0
000078d2e7dddb84  vmovaps [rsp+0x10], xmm1
000078d2e7dddb8a  vmovaps [rsp+0x20], xmm2
000078d2e7dddb90  vmovaps [rsp+0x30], xmm3
000078d2e7dddb96  vmovaps [rsp+0x40], xmm4
000078d2e7dddb9c  vmovaps [rsp+0x50], xmm5
000078d2e7dddba2  vmovaps [rsp+0x60], xmm6
000078d2e7dddba8  vmovaps [rsp+0x70], xmm7
000078d2e7dddbae  vmovaps [rsp+0x80], xmm8
000078d2e7dddbb7  vmovaps [rsp+0x90], xmm9
000078d2e7dddbc0  vmovaps [rsp+0xA0], xmm10
000078d2e7dddbc9  vmovaps [rsp+0xB0], xmm12
000078d2e7dddbd2  vmovaps [rsp+0xC0], xmm13
000078d2e7dddbdb  vmovaps [rsp+0xD0], xmm14
000078d2e7dddbe4  vmovaps [rsp+0xE0], xmm15
000078d2e7dddbed  sub rsp, 0x30
000078d2e7dddbf1  movaps [rsp], xmm11
000078d2e7dddbf6  movaps [rsp+0x10], xmm10
000078d2e7dddbfc  movaps [rsp+0x20], xmm14
000078d2e7dddc02  lea rdi, [rsp]
000078d2e7dddc06  mov esi, 0x00
000078d2e7dddc0b  mov rax, 0x5997D2DB1530
000078d2e7dddc15  call rax
000078d2e7dddc17  movaps xmm11, [rsp]
000078d2e7dddc1c  add rsp, 0x30
000078d2e7dddc20  vmovaps xmm0, [rsp]
000078d2e7dddc25  vmovaps xmm1, [rsp+0x10]
000078d2e7dddc2b  vmovaps xmm2, [rsp+0x20]
000078d2e7dddc31  vmovaps xmm3, [rsp+0x30]
000078d2e7dddc37  vmovaps xmm4, [rsp+0x40]
000078d2e7dddc3d  vmovaps xmm5, [rsp+0x50]
000078d2e7dddc43  vmovaps xmm6, [rsp+0x60]
000078d2e7dddc49  vmovaps xmm7, [rsp+0x70]
000078d2e7dddc4f  vmovaps xmm8, [rsp+0x80]
000078d2e7dddc58  vmovaps xmm9, [rsp+0x90]
000078d2e7dddc61  vmovaps xmm10, [rsp+0xA0]
000078d2e7dddc6a  vmovaps xmm12, [rsp+0xB0]
000078d2e7dddc73  vmovaps xmm13, [rsp+0xC0]
000078d2e7dddc7c  vmovaps xmm14, [rsp+0xD0]
000078d2e7dddc85  vmovaps xmm15, [rsp+0xE0]
000078d2e7dddc8e  add rsp, 0xF0
000078d2e7dddc95  pop r11
000078d2e7dddc97  pop r10
000078d2e7dddc99  pop r9
000078d2e7dddc9b  pop r8
000078d2e7dddc9d  pop rsi
000078d2e7dddc9e  pop rdi
000078d2e7dddc9f  pop rdx
000078d2e7dddca0  pop rcx
000078d2e7dddca1  pop rax
000078d2e7dddca2  add rsp, 0x08
000078d2e7dddca6  jmp 0x000078D2E7DD96CD
000078d2e7dddcab  call 0x000078D2E7CE45A0
000078d2e7dddcb0  jmp 0x000078D2E7DD96D7
000078d2e7dddcb5  sub rsp, 0x08
000078d2e7dddcb9  push rax
000078d2e7dddcba  push rcx
000078d2e7dddcbb  push rdx
000078d2e7dddcbc  push rdi
000078d2e7dddcbd  push rsi
000078d2e7dddcbe  push r8
000078d2e7dddcc0  push r9
000078d2e7dddcc2  push r10
000078d2e7dddcc4  push r11
000078d2e7dddcc6  sub rsp, 0xF0
000078d2e7dddccd  vmovaps [rsp], xmm0
000078d2e7dddcd2  vmovaps [rsp+0x10], xmm1
000078d2e7dddcd8  vmovaps [rsp+0x20], xmm2
000078d2e7dddcde  vmovaps [rsp+0x30], xmm3
000078d2e7dddce4  vmovaps [rsp+0x40], xmm4
000078d2e7dddcea  vmovaps [rsp+0x50], xmm5
000078d2e7dddcf0  vmovaps [rsp+0x60], xmm6
000078d2e7dddcf6  vmovaps [rsp+0x70], xmm7
000078d2e7dddcfc  vmovaps [rsp+0x80], xmm8
000078d2e7dddd05  vmovaps [rsp+0x90], xmm9
000078d2e7dddd0e  vmovaps [rsp+0xA0], xmm11
000078d2e7dddd17  vmovaps [rsp+0xB0], xmm12
000078d2e7dddd20  vmovaps [rsp+0xC0], xmm13
000078d2e7dddd29  vmovaps [rsp+0xD0], xmm14
000078d2e7dddd32  vmovaps [rsp+0xE0], xmm15
000078d2e7dddd3b  sub rsp, 0x30
000078d2e7dddd3f  movaps [rsp], xmm10
000078d2e7dddd44  movaps [rsp+0x10], xmm1
000078d2e7dddd49  movaps [rsp+0x20], xmm12
000078d2e7dddd4f  lea rdi, [rsp]
000078d2e7dddd53  mov esi, 0x00
000078d2e7dddd58  mov rax, 0x5997D2DB1530
000078d2e7dddd62  call rax
000078d2e7dddd64  movaps xmm10, [rsp]
000078d2e7dddd69  add rsp, 0x30
000078d2e7dddd6d  vmovaps xmm0, [rsp]
000078d2e7dddd72  vmovaps xmm1, [rsp+0x10]
000078d2e7dddd78  vmovaps xmm2, [rsp+0x20]
000078d2e7dddd7e  vmovaps xmm3, [rsp+0x30]
000078d2e7dddd84  vmovaps xmm4, [rsp+0x40]
000078d2e7dddd8a  vmovaps xmm5, [rsp+0x50]
000078d2e7dddd90  vmovaps xmm6, [rsp+0x60]
000078d2e7dddd96  vmovaps xmm7, [rsp+0x70]
000078d2e7dddd9c  vmovaps xmm8, [rsp+0x80]
000078d2e7dddda5  vmovaps xmm9, [rsp+0x90]
000078d2e7ddddae  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddddb7  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddddc0  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddddc9  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddddd2  vmovaps xmm15, [rsp+0xE0]
000078d2e7dddddb  add rsp, 0xF0
000078d2e7dddde2  pop r11
000078d2e7dddde4  pop r10
000078d2e7dddde6  pop r9
000078d2e7dddde8  pop r8
000078d2e7ddddea  pop rsi
000078d2e7ddddeb  pop rdi
000078d2e7ddddec  pop rdx
000078d2e7dddded  pop rcx
000078d2e7ddddee  pop rax
000078d2e7ddddef  add rsp, 0x08
000078d2e7ddddf3  jmp 0x000078D2E7DD96FA
000078d2e7ddddf8  sub rsp, 0x08
000078d2e7ddddfc  push rax
000078d2e7ddddfd  push rcx
000078d2e7ddddfe  push rdx
000078d2e7ddddff  push rdi
000078d2e7ddde00  push rsi
000078d2e7ddde01  push r8
000078d2e7ddde03  push r9
000078d2e7ddde05  push r10
000078d2e7ddde07  push r11
000078d2e7ddde09  sub rsp, 0xF0
000078d2e7ddde10  vmovaps [rsp], xmm0
000078d2e7ddde15  vmovaps [rsp+0x10], xmm1
000078d2e7ddde1b  vmovaps [rsp+0x20], xmm2
000078d2e7ddde21  vmovaps [rsp+0x30], xmm3
000078d2e7ddde27  vmovaps [rsp+0x40], xmm4
000078d2e7ddde2d  vmovaps [rsp+0x50], xmm5
000078d2e7ddde33  vmovaps [rsp+0x60], xmm6
000078d2e7ddde39  vmovaps [rsp+0x70], xmm7
000078d2e7ddde3f  vmovaps [rsp+0x80], xmm8
000078d2e7ddde48  vmovaps [rsp+0x90], xmm9
000078d2e7ddde51  vmovaps [rsp+0xA0], xmm10
000078d2e7ddde5a  vmovaps [rsp+0xB0], xmm11
000078d2e7ddde63  vmovaps [rsp+0xC0], xmm13
000078d2e7ddde6c  vmovaps [rsp+0xD0], xmm14
000078d2e7ddde75  vmovaps [rsp+0xE0], xmm15
000078d2e7ddde7e  sub rsp, 0x30
000078d2e7ddde82  movaps [rsp], xmm12
000078d2e7ddde87  movaps [rsp+0x10], xmm14
000078d2e7ddde8d  movaps [rsp+0x20], xmm1
000078d2e7ddde92  lea rdi, [rsp]
000078d2e7ddde96  mov esi, 0x00
000078d2e7ddde9b  mov rax, 0x5997D2DB1530
000078d2e7dddea5  call rax
000078d2e7dddea7  movaps xmm12, [rsp]
000078d2e7dddeac  add rsp, 0x30
000078d2e7dddeb0  vmovaps xmm0, [rsp]
000078d2e7dddeb5  vmovaps xmm1, [rsp+0x10]
000078d2e7dddebb  vmovaps xmm2, [rsp+0x20]
000078d2e7dddec1  vmovaps xmm3, [rsp+0x30]
000078d2e7dddec7  vmovaps xmm4, [rsp+0x40]
000078d2e7dddecd  vmovaps xmm5, [rsp+0x50]
000078d2e7ddded3  vmovaps xmm6, [rsp+0x60]
000078d2e7ddded9  vmovaps xmm7, [rsp+0x70]
000078d2e7dddedf  vmovaps xmm8, [rsp+0x80]
000078d2e7dddee8  vmovaps xmm9, [rsp+0x90]
000078d2e7dddef1  vmovaps xmm10, [rsp+0xA0]
000078d2e7dddefa  vmovaps xmm11, [rsp+0xB0]
000078d2e7dddf03  vmovaps xmm13, [rsp+0xC0]
000078d2e7dddf0c  vmovaps xmm14, [rsp+0xD0]
000078d2e7dddf15  vmovaps xmm15, [rsp+0xE0]
000078d2e7dddf1e  add rsp, 0xF0
000078d2e7dddf25  pop r11
000078d2e7dddf27  pop r10
000078d2e7dddf29  pop r9
000078d2e7dddf2b  pop r8
000078d2e7dddf2d  pop rsi
000078d2e7dddf2e  pop rdi
000078d2e7dddf2f  pop rdx
000078d2e7dddf30  pop rcx
000078d2e7dddf31  pop rax
000078d2e7dddf32  add rsp, 0x08
000078d2e7dddf36  jmp 0x000078D2E7DD9729
000078d2e7dddf3b  sub rsp, 0x08
000078d2e7dddf3f  push rax
000078d2e7dddf40  push rcx
000078d2e7dddf41  push rdx
000078d2e7dddf42  push rdi
000078d2e7dddf43  push rsi
000078d2e7dddf44  push r8
000078d2e7dddf46  push r9
000078d2e7dddf48  push r10
000078d2e7dddf4a  push r11
000078d2e7dddf4c  sub rsp, 0xF0
000078d2e7dddf53  vmovaps [rsp], xmm0
000078d2e7dddf58  vmovaps [rsp+0x10], xmm1
000078d2e7dddf5e  vmovaps [rsp+0x20], xmm2
000078d2e7dddf64  vmovaps [rsp+0x30], xmm3
000078d2e7dddf6a  vmovaps [rsp+0x40], xmm4
000078d2e7dddf70  vmovaps [rsp+0x50], xmm5
000078d2e7dddf76  vmovaps [rsp+0x60], xmm6
000078d2e7dddf7c  vmovaps [rsp+0x70], xmm7
000078d2e7dddf82  vmovaps [rsp+0x80], xmm8
000078d2e7dddf8b  vmovaps [rsp+0x90], xmm9
000078d2e7dddf94  vmovaps [rsp+0xA0], xmm10
000078d2e7dddf9d  vmovaps [rsp+0xB0], xmm11
000078d2e7dddfa6  vmovaps [rsp+0xC0], xmm12
000078d2e7dddfaf  vmovaps [rsp+0xD0], xmm13
000078d2e7dddfb8  vmovaps [rsp+0xE0], xmm15
000078d2e7dddfc1  sub rsp, 0x30
000078d2e7dddfc5  movaps [rsp], xmm14
000078d2e7dddfca  movaps [rsp+0x10], xmm9
000078d2e7dddfd0  movaps [rsp+0x20], xmm1
000078d2e7dddfd5  lea rdi, [rsp]
000078d2e7dddfd9  mov esi, 0x00
000078d2e7dddfde  mov rax, 0x5997D2DB1530
000078d2e7dddfe8  call rax
000078d2e7dddfea  movaps xmm14, [rsp]
000078d2e7dddfef  add rsp, 0x30
000078d2e7dddff3  vmovaps xmm0, [rsp]
000078d2e7dddff8  vmovaps xmm1, [rsp+0x10]
000078d2e7dddffe  vmovaps xmm2, [rsp+0x20]
000078d2e7dde004  vmovaps xmm3, [rsp+0x30]
000078d2e7dde00a  vmovaps xmm4, [rsp+0x40]
000078d2e7dde010  vmovaps xmm5, [rsp+0x50]
000078d2e7dde016  vmovaps xmm6, [rsp+0x60]
000078d2e7dde01c  vmovaps xmm7, [rsp+0x70]
000078d2e7dde022  vmovaps xmm8, [rsp+0x80]
000078d2e7dde02b  vmovaps xmm9, [rsp+0x90]
000078d2e7dde034  vmovaps xmm10, [rsp+0xA0]
000078d2e7dde03d  vmovaps xmm11, [rsp+0xB0]
000078d2e7dde046  vmovaps xmm12, [rsp+0xC0]
000078d2e7dde04f  vmovaps xmm13, [rsp+0xD0]
000078d2e7dde058  vmovaps xmm15, [rsp+0xE0]
000078d2e7dde061  add rsp, 0xF0
000078d2e7dde068  pop r11
000078d2e7dde06a  pop r10
000078d2e7dde06c  pop r9
000078d2e7dde06e  pop r8
000078d2e7dde070  pop rsi
000078d2e7dde071  pop rdi
000078d2e7dde072  pop rdx
000078d2e7dde073  pop rcx
000078d2e7dde074  pop rax
000078d2e7dde075  add rsp, 0x08
000078d2e7dde079  jmp 0x000078D2E7DD9758
000078d2e7dde07e  sub rsp, 0x08
000078d2e7dde082  push rax
000078d2e7dde083  push rcx
000078d2e7dde084  push rdx
000078d2e7dde085  push rdi
000078d2e7dde086  push rsi
000078d2e7dde087  push r8
000078d2e7dde089  push r9
000078d2e7dde08b  push r10
000078d2e7dde08d  push r11
000078d2e7dde08f  sub rsp, 0xF0
000078d2e7dde096  vmovaps [rsp], xmm0
000078d2e7dde09b  vmovaps [rsp+0x10], xmm2
000078d2e7dde0a1  vmovaps [rsp+0x20], xmm3
000078d2e7dde0a7  vmovaps [rsp+0x30], xmm4
000078d2e7dde0ad  vmovaps [rsp+0x40], xmm5
000078d2e7dde0b3  vmovaps [rsp+0x50], xmm6
000078d2e7dde0b9  vmovaps [rsp+0x60], xmm7
000078d2e7dde0bf  vmovaps [rsp+0x70], xmm8
000078d2e7dde0c5  vmovaps [rsp+0x80], xmm9
000078d2e7dde0ce  vmovaps [rsp+0x90], xmm10
000078d2e7dde0d7  vmovaps [rsp+0xA0], xmm11
000078d2e7dde0e0  vmovaps [rsp+0xB0], xmm12
000078d2e7dde0e9  vmovaps [rsp+0xC0], xmm13
000078d2e7dde0f2  vmovaps [rsp+0xD0], xmm14
000078d2e7dde0fb  vmovaps [rsp+0xE0], xmm15
000078d2e7dde104  sub rsp, 0x30
000078d2e7dde108  movaps [rsp], xmm1
000078d2e7dde10c  movaps [rsp+0x10], xmm13
000078d2e7dde112  movaps [rsp+0x20], xmm8
000078d2e7dde118  lea rdi, [rsp]
000078d2e7dde11c  mov esi, 0x00
000078d2e7dde121  mov rax, 0x5997D2DB1530
000078d2e7dde12b  call rax
000078d2e7dde12d  movaps xmm1, [rsp]
000078d2e7dde131  add rsp, 0x30
000078d2e7dde135  vmovaps xmm0, [rsp]
000078d2e7dde13a  vmovaps xmm2, [rsp+0x10]
000078d2e7dde140  vmovaps xmm3, [rsp+0x20]
000078d2e7dde146  vmovaps xmm4, [rsp+0x30]
000078d2e7dde14c  vmovaps xmm5, [rsp+0x40]
000078d2e7dde152  vmovaps xmm6, [rsp+0x50]
000078d2e7dde158  vmovaps xmm7, [rsp+0x60]
000078d2e7dde15e  vmovaps xmm8, [rsp+0x70]
000078d2e7dde164  vmovaps xmm9, [rsp+0x80]
000078d2e7dde16d  vmovaps xmm10, [rsp+0x90]
000078d2e7dde176  vmovaps xmm11, [rsp+0xA0]
000078d2e7dde17f  vmovaps xmm12, [rsp+0xB0]
000078d2e7dde188  vmovaps xmm13, [rsp+0xC0]
000078d2e7dde191  vmovaps xmm14, [rsp+0xD0]
000078d2e7dde19a  vmovaps xmm15, [rsp+0xE0]
000078d2e7dde1a3  add rsp, 0xF0
000078d2e7dde1aa  pop r11
000078d2e7dde1ac  pop r10
000078d2e7dde1ae  pop r9
000078d2e7dde1b0  pop r8
000078d2e7dde1b2  pop rsi
000078d2e7dde1b3  pop rdi
000078d2e7dde1b4  pop rdx
000078d2e7dde1b5  pop rcx
000078d2e7dde1b6  pop rax
000078d2e7dde1b7  add rsp, 0x08
000078d2e7dde1bb  jmp 0x000078D2E7DD977A
000078d2e7dde1c0  call 0x000078D2E7C0C260
000078d2e7dde1c5  jmp 0x000078D2E7DD9788
000078d2e7dde1ca  call 0x000078D2E7CDE950
000078d2e7dde1cf  jmp 0x000078D2E7DD9792
000078d2e7dde1d4  sub rsp, 0x08
000078d2e7dde1d8  push rax
000078d2e7dde1d9  push rcx
000078d2e7dde1da  push rdx
000078d2e7dde1db  push rdi
000078d2e7dde1dc  push rsi
000078d2e7dde1dd  push r8
000078d2e7dde1df  push r9
000078d2e7dde1e1  push r10
000078d2e7dde1e3  push r11
000078d2e7dde1e5  sub rsp, 0xF0
000078d2e7dde1ec  vmovaps [rsp], xmm0
000078d2e7dde1f1  vmovaps [rsp+0x10], xmm1
000078d2e7dde1f7  vmovaps [rsp+0x20], xmm2
000078d2e7dde1fd  vmovaps [rsp+0x30], xmm3
000078d2e7dde203  vmovaps [rsp+0x40], xmm4
000078d2e7dde209  vmovaps [rsp+0x50], xmm5
000078d2e7dde20f  vmovaps [rsp+0x60], xmm6
000078d2e7dde215  vmovaps [rsp+0x70], xmm7
000078d2e7dde21b  vmovaps [rsp+0x80], xmm9
000078d2e7dde224  vmovaps [rsp+0x90], xmm10
000078d2e7dde22d  vmovaps [rsp+0xA0], xmm11
000078d2e7dde236  vmovaps [rsp+0xB0], xmm12
000078d2e7dde23f  vmovaps [rsp+0xC0], xmm13
000078d2e7dde248  vmovaps [rsp+0xD0], xmm14
000078d2e7dde251  vmovaps [rsp+0xE0], xmm15
000078d2e7dde25a  sub rsp, 0x30
000078d2e7dde25e  movaps [rsp], xmm8
000078d2e7dde263  movaps [rsp+0x10], xmm15
000078d2e7dde269  movaps [rsp+0x20], xmm7
000078d2e7dde26e  lea rdi, [rsp]
000078d2e7dde272  mov esi, 0x00
000078d2e7dde277  mov rax, 0x5997D2DB1530
000078d2e7dde281  call rax
000078d2e7dde283  movaps xmm8, [rsp]
000078d2e7dde288  add rsp, 0x30
000078d2e7dde28c  vmovaps xmm0, [rsp]
000078d2e7dde291  vmovaps xmm1, [rsp+0x10]
000078d2e7dde297  vmovaps xmm2, [rsp+0x20]
000078d2e7dde29d  vmovaps xmm3, [rsp+0x30]
000078d2e7dde2a3  vmovaps xmm4, [rsp+0x40]
000078d2e7dde2a9  vmovaps xmm5, [rsp+0x50]
000078d2e7dde2af  vmovaps xmm6, [rsp+0x60]
000078d2e7dde2b5  vmovaps xmm7, [rsp+0x70]
000078d2e7dde2bb  vmovaps xmm9, [rsp+0x80]
000078d2e7dde2c4  vmovaps xmm10, [rsp+0x90]
000078d2e7dde2cd  vmovaps xmm11, [rsp+0xA0]
000078d2e7dde2d6  vmovaps xmm12, [rsp+0xB0]
000078d2e7dde2df  vmovaps xmm13, [rsp+0xC0]
000078d2e7dde2e8  vmovaps xmm14, [rsp+0xD0]
000078d2e7dde2f1  vmovaps xmm15, [rsp+0xE0]
000078d2e7dde2fa  add rsp, 0xF0
000078d2e7dde301  pop r11
000078d2e7dde303  pop r10
000078d2e7dde305  pop r9
000078d2e7dde307  pop r8
000078d2e7dde309  pop rsi
000078d2e7dde30a  pop rdi
000078d2e7dde30b  pop rdx
000078d2e7dde30c  pop rcx
000078d2e7dde30d  pop rax
000078d2e7dde30e  add rsp, 0x08
000078d2e7dde312  jmp 0x000078D2E7DD97B4
000078d2e7dde317  sub rsp, 0x08
000078d2e7dde31b  push rax
000078d2e7dde31c  push rcx
000078d2e7dde31d  push rdx
000078d2e7dde31e  push rdi
000078d2e7dde31f  push rsi
000078d2e7dde320  push r8
000078d2e7dde322  push r9
000078d2e7dde324  push r10
000078d2e7dde326  push r11
000078d2e7dde328  sub rsp, 0xF0
000078d2e7dde32f  vmovaps [rsp], xmm0
000078d2e7dde334  vmovaps [rsp+0x10], xmm1
000078d2e7dde33a  vmovaps [rsp+0x20], xmm2
000078d2e7dde340  vmovaps [rsp+0x30], xmm3
000078d2e7dde346  vmovaps [rsp+0x40], xmm4
000078d2e7dde34c  vmovaps [rsp+0x50], xmm5
000078d2e7dde352  vmovaps [rsp+0x60], xmm6
000078d2e7dde358  vmovaps [rsp+0x70], xmm8
000078d2e7dde35e  vmovaps [rsp+0x80], xmm9
000078d2e7dde367  vmovaps [rsp+0x90], xmm10
000078d2e7dde370  vmovaps [rsp+0xA0], xmm11
000078d2e7dde379  vmovaps [rsp+0xB0], xmm12
000078d2e7dde382  vmovaps [rsp+0xC0], xmm13
000078d2e7dde38b  vmovaps [rsp+0xD0], xmm14
000078d2e7dde394  vmovaps [rsp+0xE0], xmm15
000078d2e7dde39d  sub rsp, 0x30
000078d2e7dde3a1  movaps [rsp], xmm7
000078d2e7dde3a5  movaps [rsp+0x10], xmm9
000078d2e7dde3ab  movaps [rsp+0x20], xmm15
000078d2e7dde3b1  lea rdi, [rsp]
000078d2e7dde3b5  mov esi, 0x00
000078d2e7dde3ba  mov rax, 0x5997D2DB1530
000078d2e7dde3c4  call rax
000078d2e7dde3c6  movaps xmm7, [rsp]
000078d2e7dde3ca  add rsp, 0x30
000078d2e7dde3ce  vmovaps xmm0, [rsp]
000078d2e7dde3d3  vmovaps xmm1, [rsp+0x10]
000078d2e7dde3d9  vmovaps xmm2, [rsp+0x20]
000078d2e7dde3df  vmovaps xmm3, [rsp+0x30]
000078d2e7dde3e5  vmovaps xmm4, [rsp+0x40]
000078d2e7dde3eb  vmovaps xmm5, [rsp+0x50]
000078d2e7dde3f1  vmovaps xmm6, [rsp+0x60]
000078d2e7dde3f7  vmovaps xmm8, [rsp+0x70]
000078d2e7dde3fd  vmovaps xmm9, [rsp+0x80]
000078d2e7dde406  vmovaps xmm10, [rsp+0x90]
000078d2e7dde40f  vmovaps xmm11, [rsp+0xA0]
000078d2e7dde418  vmovaps xmm12, [rsp+0xB0]
000078d2e7dde421  vmovaps xmm13, [rsp+0xC0]
000078d2e7dde42a  vmovaps xmm14, [rsp+0xD0]
000078d2e7dde433  vmovaps xmm15, [rsp+0xE0]
000078d2e7dde43c  add rsp, 0xF0
000078d2e7dde443  pop r11
000078d2e7dde445  pop r10
000078d2e7dde447  pop r9
000078d2e7dde449  pop r8
000078d2e7dde44b  pop rsi
000078d2e7dde44c  pop rdi
000078d2e7dde44d  pop rdx
000078d2e7dde44e  pop rcx
000078d2e7dde44f  pop rax
000078d2e7dde450  add rsp, 0x08
000078d2e7dde454  jmp 0x000078D2E7DD97E1
000078d2e7dde459  sub rsp, 0x08
000078d2e7dde45d  push rax
000078d2e7dde45e  push rcx
000078d2e7dde45f  push rdx
000078d2e7dde460  push rdi
000078d2e7dde461  push rsi
000078d2e7dde462  push r8
000078d2e7dde464  push r9
000078d2e7dde466  push r10
000078d2e7dde468  push r11
000078d2e7dde46a  sub rsp, 0xF0
000078d2e7dde471  vmovaps [rsp], xmm0
000078d2e7dde476  vmovaps [rsp+0x10], xmm1
000078d2e7dde47c  vmovaps [rsp+0x20], xmm2
000078d2e7dde482  vmovaps [rsp+0x30], xmm3
000078d2e7dde488  vmovaps [rsp+0x40], xmm4
000078d2e7dde48e  vmovaps [rsp+0x50], xmm5
000078d2e7dde494  vmovaps [rsp+0x60], xmm6
000078d2e7dde49a  vmovaps [rsp+0x70], xmm7
000078d2e7dde4a0  vmovaps [rsp+0x80], xmm8
000078d2e7dde4a9  vmovaps [rsp+0x90], xmm10
000078d2e7dde4b2  vmovaps [rsp+0xA0], xmm11
000078d2e7dde4bb  vmovaps [rsp+0xB0], xmm12
000078d2e7dde4c4  vmovaps [rsp+0xC0], xmm13
000078d2e7dde4cd  vmovaps [rsp+0xD0], xmm14
000078d2e7dde4d6  vmovaps [rsp+0xE0], xmm15
000078d2e7dde4df  sub rsp, 0x30
000078d2e7dde4e3  movaps [rsp], xmm9
000078d2e7dde4e8  movaps [rsp+0x10], xmm13
000078d2e7dde4ee  movaps [rsp+0x20], xmm15
000078d2e7dde4f4  lea rdi, [rsp]
000078d2e7dde4f8  mov esi, 0x00
000078d2e7dde4fd  mov rax, 0x5997D2DB1530
000078d2e7dde507  call rax
000078d2e7dde509  movaps xmm9, [rsp]
000078d2e7dde50e  add rsp, 0x30
000078d2e7dde512  vmovaps xmm0, [rsp]
000078d2e7dde517  vmovaps xmm1, [rsp+0x10]
000078d2e7dde51d  vmovaps xmm2, [rsp+0x20]
000078d2e7dde523  vmovaps xmm3, [rsp+0x30]
000078d2e7dde529  vmovaps xmm4, [rsp+0x40]
000078d2e7dde52f  vmovaps xmm5, [rsp+0x50]
000078d2e7dde535  vmovaps xmm6, [rsp+0x60]
000078d2e7dde53b  vmovaps xmm7, [rsp+0x70]
000078d2e7dde541  vmovaps xmm8, [rsp+0x80]
000078d2e7dde54a  vmovaps xmm10, [rsp+0x90]
000078d2e7dde553  vmovaps xmm11, [rsp+0xA0]
000078d2e7dde55c  vmovaps xmm12, [rsp+0xB0]
000078d2e7dde565  vmovaps xmm13, [rsp+0xC0]
000078d2e7dde56e  vmovaps xmm14, [rsp+0xD0]
000078d2e7dde577  vmovaps xmm15, [rsp+0xE0]
000078d2e7dde580  add rsp, 0xF0
000078d2e7dde587  pop r11
000078d2e7dde589  pop r10
000078d2e7dde58b  pop r9
000078d2e7dde58d  pop r8
000078d2e7dde58f  pop rsi
000078d2e7dde590  pop rdi
000078d2e7dde591  pop rdx
000078d2e7dde592  pop rcx
000078d2e7dde593  pop rax
000078d2e7dde594  add rsp, 0x08
000078d2e7dde598  jmp 0x000078D2E7DD980F
000078d2e7dde59d  sub rsp, 0x08
000078d2e7dde5a1  push rax
000078d2e7dde5a2  push rcx
000078d2e7dde5a3  push rdx
000078d2e7dde5a4  push rdi
000078d2e7dde5a5  push rsi
000078d2e7dde5a6  push r8
000078d2e7dde5a8  push r9
000078d2e7dde5aa  push r10
000078d2e7dde5ac  push r11
000078d2e7dde5ae  sub rsp, 0xF0
000078d2e7dde5b5  vmovaps [rsp], xmm0
000078d2e7dde5ba  vmovaps [rsp+0x10], xmm1
000078d2e7dde5c0  vmovaps [rsp+0x20], xmm2
000078d2e7dde5c6  vmovaps [rsp+0x30], xmm3
000078d2e7dde5cc  vmovaps [rsp+0x40], xmm4
000078d2e7dde5d2  vmovaps [rsp+0x50], xmm5
000078d2e7dde5d8  vmovaps [rsp+0x60], xmm6
000078d2e7dde5de  vmovaps [rsp+0x70], xmm7
000078d2e7dde5e4  vmovaps [rsp+0x80], xmm8
000078d2e7dde5ed  vmovaps [rsp+0x90], xmm9
000078d2e7dde5f6  vmovaps [rsp+0xA0], xmm10
000078d2e7dde5ff  vmovaps [rsp+0xB0], xmm11
000078d2e7dde608  vmovaps [rsp+0xC0], xmm12
000078d2e7dde611  vmovaps [rsp+0xD0], xmm13
000078d2e7dde61a  vmovaps [rsp+0xE0], xmm14
000078d2e7dde623  sub rsp, 0x30
000078d2e7dde627  movaps [rsp], xmm15
000078d2e7dde62c  movaps [rsp+0x10], xmm11
000078d2e7dde632  movaps [rsp+0x20], xmm12
000078d2e7dde638  lea rdi, [rsp]
000078d2e7dde63c  mov esi, 0x00
000078d2e7dde641  mov rax, 0x5997D2DB1530
000078d2e7dde64b  call rax
000078d2e7dde64d  movaps xmm15, [rsp]
000078d2e7dde652  add rsp, 0x30
000078d2e7dde656  vmovaps xmm0, [rsp]
000078d2e7dde65b  vmovaps xmm1, [rsp+0x10]
000078d2e7dde661  vmovaps xmm2, [rsp+0x20]
000078d2e7dde667  vmovaps xmm3, [rsp+0x30]
000078d2e7dde66d  vmovaps xmm4, [rsp+0x40]
000078d2e7dde673  vmovaps xmm5, [rsp+0x50]
000078d2e7dde679  vmovaps xmm6, [rsp+0x60]
000078d2e7dde67f  vmovaps xmm7, [rsp+0x70]
000078d2e7dde685  vmovaps xmm8, [rsp+0x80]
000078d2e7dde68e  vmovaps xmm9, [rsp+0x90]
000078d2e7dde697  vmovaps xmm10, [rsp+0xA0]
000078d2e7dde6a0  vmovaps xmm11, [rsp+0xB0]
000078d2e7dde6a9  vmovaps xmm12, [rsp+0xC0]
000078d2e7dde6b2  vmovaps xmm13, [rsp+0xD0]
000078d2e7dde6bb  vmovaps xmm14, [rsp+0xE0]
000078d2e7dde6c4  add rsp, 0xF0
000078d2e7dde6cb  pop r11
000078d2e7dde6cd  pop r10
000078d2e7dde6cf  pop r9
000078d2e7dde6d1  pop r8
000078d2e7dde6d3  pop rsi
000078d2e7dde6d4  pop rdi
000078d2e7dde6d5  pop rdx
000078d2e7dde6d6  pop rcx
000078d2e7dde6d7  pop rax
000078d2e7dde6d8  add rsp, 0x08
000078d2e7dde6dc  jmp 0x000078D2E7DD982A
000078d2e7dde6e1  sub rsp, 0x08
000078d2e7dde6e5  push rax
000078d2e7dde6e6  push rcx
000078d2e7dde6e7  push rdx
000078d2e7dde6e8  push rdi
000078d2e7dde6e9  push rsi
000078d2e7dde6ea  push r8
000078d2e7dde6ec  push r9
000078d2e7dde6ee  push r10
000078d2e7dde6f0  push r11
000078d2e7dde6f2  sub rsp, 0xF0
000078d2e7dde6f9  vmovaps [rsp], xmm0
000078d2e7dde6fe  vmovaps [rsp+0x10], xmm1
000078d2e7dde704  vmovaps [rsp+0x20], xmm2
000078d2e7dde70a  vmovaps [rsp+0x30], xmm3
000078d2e7dde710  vmovaps [rsp+0x40], xmm4
000078d2e7dde716  vmovaps [rsp+0x50], xmm5
000078d2e7dde71c  vmovaps [rsp+0x60], xmm6
000078d2e7dde722  vmovaps [rsp+0x70], xmm7
000078d2e7dde728  vmovaps [rsp+0x80], xmm8
000078d2e7dde731  vmovaps [rsp+0x90], xmm9
000078d2e7dde73a  vmovaps [rsp+0xA0], xmm10
000078d2e7dde743  vmovaps [rsp+0xB0], xmm11
000078d2e7dde74c  vmovaps [rsp+0xC0], xmm12
000078d2e7dde755  vmovaps [rsp+0xD0], xmm14
000078d2e7dde75e  vmovaps [rsp+0xE0], xmm15
000078d2e7dde767  sub rsp, 0x30
000078d2e7dde76b  movaps [rsp], xmm13
000078d2e7dde770  movaps [rsp+0x10], xmm10
000078d2e7dde776  movaps [rsp+0x20], xmm14
000078d2e7dde77c  lea rdi, [rsp]
000078d2e7dde780  mov esi, 0x00
000078d2e7dde785  mov rax, 0x5997D2DB1530
000078d2e7dde78f  call rax
000078d2e7dde791  movaps xmm13, [rsp]
000078d2e7dde796  add rsp, 0x30
000078d2e7dde79a  vmovaps xmm0, [rsp]
000078d2e7dde79f  vmovaps xmm1, [rsp+0x10]
000078d2e7dde7a5  vmovaps xmm2, [rsp+0x20]
000078d2e7dde7ab  vmovaps xmm3, [rsp+0x30]
000078d2e7dde7b1  vmovaps xmm4, [rsp+0x40]
000078d2e7dde7b7  vmovaps xmm5, [rsp+0x50]
000078d2e7dde7bd  vmovaps xmm6, [rsp+0x60]
000078d2e7dde7c3  vmovaps xmm7, [rsp+0x70]
000078d2e7dde7c9  vmovaps xmm8, [rsp+0x80]
000078d2e7dde7d2  vmovaps xmm9, [rsp+0x90]
000078d2e7dde7db  vmovaps xmm10, [rsp+0xA0]
000078d2e7dde7e4  vmovaps xmm11, [rsp+0xB0]
000078d2e7dde7ed  vmovaps xmm12, [rsp+0xC0]
000078d2e7dde7f6  vmovaps xmm14, [rsp+0xD0]
000078d2e7dde7ff  vmovaps xmm15, [rsp+0xE0]
000078d2e7dde808  add rsp, 0xF0
000078d2e7dde80f  pop r11
000078d2e7dde811  pop r10
000078d2e7dde813  pop r9
000078d2e7dde815  pop r8
000078d2e7dde817  pop rsi
000078d2e7dde818  pop rdi
000078d2e7dde819  pop rdx
000078d2e7dde81a  pop rcx
000078d2e7dde81b  pop rax
000078d2e7dde81c  add rsp, 0x08
000078d2e7dde820  jmp 0x000078D2E7DD984D
000078d2e7dde825  sub rsp, 0x08
000078d2e7dde829  push rax
000078d2e7dde82a  push rcx
000078d2e7dde82b  push rdx
000078d2e7dde82c  push rdi
000078d2e7dde82d  push rsi
000078d2e7dde82e  push r8
000078d2e7dde830  push r9
000078d2e7dde832  push r10
000078d2e7dde834  push r11
000078d2e7dde836  sub rsp, 0xF0
000078d2e7dde83d  vmovaps [rsp], xmm0
000078d2e7dde842  vmovaps [rsp+0x10], xmm1
000078d2e7dde848  vmovaps [rsp+0x20], xmm2
000078d2e7dde84e  vmovaps [rsp+0x30], xmm3
000078d2e7dde854  vmovaps [rsp+0x40], xmm4
000078d2e7dde85a  vmovaps [rsp+0x50], xmm5
000078d2e7dde860  vmovaps [rsp+0x60], xmm6
000078d2e7dde866  vmovaps [rsp+0x70], xmm7
000078d2e7dde86c  vmovaps [rsp+0x80], xmm8
000078d2e7dde875  vmovaps [rsp+0x90], xmm9
000078d2e7dde87e  vmovaps [rsp+0xA0], xmm10
000078d2e7dde887  vmovaps [rsp+0xB0], xmm11
000078d2e7dde890  vmovaps [rsp+0xC0], xmm12
000078d2e7dde899  vmovaps [rsp+0xD0], xmm13
000078d2e7dde8a2  vmovaps [rsp+0xE0], xmm15
000078d2e7dde8ab  sub rsp, 0x30
000078d2e7dde8af  movaps [rsp], xmm14
000078d2e7dde8b4  movaps [rsp+0x10], xmm1
000078d2e7dde8b9  movaps [rsp+0x20], xmm7
000078d2e7dde8be  lea rdi, [rsp]
000078d2e7dde8c2  mov esi, 0x00
000078d2e7dde8c7  mov rax, 0x5997D2DB1530
000078d2e7dde8d1  call rax
000078d2e7dde8d3  movaps xmm14, [rsp]
000078d2e7dde8d8  add rsp, 0x30
000078d2e7dde8dc  vmovaps xmm0, [rsp]
000078d2e7dde8e1  vmovaps xmm1, [rsp+0x10]
000078d2e7dde8e7  vmovaps xmm2, [rsp+0x20]
000078d2e7dde8ed  vmovaps xmm3, [rsp+0x30]
000078d2e7dde8f3  vmovaps xmm4, [rsp+0x40]
000078d2e7dde8f9  vmovaps xmm5, [rsp+0x50]
000078d2e7dde8ff  vmovaps xmm6, [rsp+0x60]
000078d2e7dde905  vmovaps xmm7, [rsp+0x70]
000078d2e7dde90b  vmovaps xmm8, [rsp+0x80]
000078d2e7dde914  vmovaps xmm9, [rsp+0x90]
000078d2e7dde91d  vmovaps xmm10, [rsp+0xA0]
000078d2e7dde926  vmovaps xmm11, [rsp+0xB0]
000078d2e7dde92f  vmovaps xmm12, [rsp+0xC0]
000078d2e7dde938  vmovaps xmm13, [rsp+0xD0]
000078d2e7dde941  vmovaps xmm15, [rsp+0xE0]
000078d2e7dde94a  add rsp, 0xF0
000078d2e7dde951  pop r11
000078d2e7dde953  pop r10
000078d2e7dde955  pop r9
000078d2e7dde957  pop r8
000078d2e7dde959  pop rsi
000078d2e7dde95a  pop rdi
000078d2e7dde95b  pop rdx
000078d2e7dde95c  pop rcx
000078d2e7dde95d  pop rax
000078d2e7dde95e  add rsp, 0x08
000078d2e7dde962  jmp 0x000078D2E7DD9870
000078d2e7dde967  sub rsp, 0x08
000078d2e7dde96b  push rax
000078d2e7dde96c  push rcx
000078d2e7dde96d  push rdx
000078d2e7dde96e  push rdi
000078d2e7dde96f  push rsi
000078d2e7dde970  push r8
000078d2e7dde972  push r9
000078d2e7dde974  push r10
000078d2e7dde976  push r11
000078d2e7dde978  sub rsp, 0xF0
000078d2e7dde97f  vmovaps [rsp], xmm0
000078d2e7dde984  vmovaps [rsp+0x10], xmm2
000078d2e7dde98a  vmovaps [rsp+0x20], xmm3
000078d2e7dde990  vmovaps [rsp+0x30], xmm4
000078d2e7dde996  vmovaps [rsp+0x40], xmm5
000078d2e7dde99c  vmovaps [rsp+0x50], xmm6
000078d2e7dde9a2  vmovaps [rsp+0x60], xmm7
000078d2e7dde9a8  vmovaps [rsp+0x70], xmm8
000078d2e7dde9ae  vmovaps [rsp+0x80], xmm9
000078d2e7dde9b7  vmovaps [rsp+0x90], xmm10
000078d2e7dde9c0  vmovaps [rsp+0xA0], xmm11
000078d2e7dde9c9  vmovaps [rsp+0xB0], xmm12
000078d2e7dde9d2  vmovaps [rsp+0xC0], xmm13
000078d2e7dde9db  vmovaps [rsp+0xD0], xmm14
000078d2e7dde9e4  vmovaps [rsp+0xE0], xmm15
000078d2e7dde9ed  sub rsp, 0x30
000078d2e7dde9f1  movaps [rsp], xmm1
000078d2e7dde9f5  movaps [rsp+0x10], xmm8
000078d2e7dde9fb  movaps [rsp+0x20], xmm9
000078d2e7ddea01  lea rdi, [rsp]
000078d2e7ddea05  mov esi, 0x00
000078d2e7ddea0a  mov rax, 0x5997D2DB1530
000078d2e7ddea14  call rax
000078d2e7ddea16  movaps xmm1, [rsp]
000078d2e7ddea1a  add rsp, 0x30
000078d2e7ddea1e  vmovaps xmm0, [rsp]
000078d2e7ddea23  vmovaps xmm2, [rsp+0x10]
000078d2e7ddea29  vmovaps xmm3, [rsp+0x20]
000078d2e7ddea2f  vmovaps xmm4, [rsp+0x30]
000078d2e7ddea35  vmovaps xmm5, [rsp+0x40]
000078d2e7ddea3b  vmovaps xmm6, [rsp+0x50]
000078d2e7ddea41  vmovaps xmm7, [rsp+0x60]
000078d2e7ddea47  vmovaps xmm8, [rsp+0x70]
000078d2e7ddea4d  vmovaps xmm9, [rsp+0x80]
000078d2e7ddea56  vmovaps xmm10, [rsp+0x90]
000078d2e7ddea5f  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddea68  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddea71  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddea7a  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddea83  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddea8c  add rsp, 0xF0
000078d2e7ddea93  pop r11
000078d2e7ddea95  pop r10
000078d2e7ddea97  pop r9
000078d2e7ddea99  pop r8
000078d2e7ddea9b  pop rsi
000078d2e7ddea9c  pop rdi
000078d2e7ddea9d  pop rdx
000078d2e7ddea9e  pop rcx
000078d2e7ddea9f  pop rax
000078d2e7ddeaa0  add rsp, 0x08
000078d2e7ddeaa4  jmp 0x000078D2E7DD9892
000078d2e7ddeaa9  call 0x000078D2E7CB3E40
000078d2e7ddeaae  jmp 0x000078D2E7DD98A0
000078d2e7ddeab3  call 0x000078D2E7C0C380
000078d2e7ddeab8  jmp 0x000078D2E7DD98AA
000078d2e7ddeabd  call 0x000078D2E7C0D600
000078d2e7ddeac2  jmp 0x000078D2E7DD98B4
000078d2e7ddeac7  call 0x000078D2E7BFF540
000078d2e7ddeacc  jmp 0x000078D2E7DD98BE
000078d2e7ddead1  int3
000078d2e7ddead2  nop [rax+rax*1], ax
000078d2e7ddeadb  nop [rax+rax*1], eax
000078d2e7ddeae0  mov eax, [r15+0x48]
000078d2e7ddeae4  lea r14d, [eax+0x01]
000078d2e7ddeae9  mov [rsp+0x10], r14d
000078d2e7ddeaee  mov r14d, r14d
000078d2e7ddeaf1  mov [r15+0x48], r14
000078d2e7ddeaf5  xor eax, eax
000078d2e7ddeaf7  mov r14d, [rsp+0x10]
000078d2e7ddeafc  cmp r14d, 0x1F4
000078d2e7ddeb03  cmc
000078d2e7ddeb04  lahf
000078d2e7ddeb05  seto al
000078d2e7ddeb08  mov [r15+0x108], eax
000078d2e7ddeb0f  mov eax, [r15+0x108]
000078d2e7ddeb16  sahf
000078d2e7ddeb17  jnz 0x000078D2E7DDEB49
000078d2e7ddeb19  cmp dword ptr [r15+0x318], 0x00
000078d2e7ddeb21  jz 0x000078D2E7DE4C90
000078d2e7ddeb27  nop [rax+rax*1], ax
000078d2e7ddeb30  nop [rax+rax*1], eax
000078d2e7ddeb38  mov eax, 0x4106DC
000078d2e7ddeb3d  mov [r15+0x100], rax
000078d2e7ddeb44  jmp 0x000078D2E7BFE110
000078d2e7ddeb49  cmp dword ptr [r15+0x318], 0x00
000078d2e7ddeb51  jz 0x000078D2E7DDEB80
000078d2e7ddeb57  nop [rax+rax*1], ax
000078d2e7ddeb60  nop [rax+rax*1], eax
000078d2e7ddeb68  mov eax, 0x410500
000078d2e7ddeb6d  mov [r15+0x100], rax
000078d2e7ddeb74  jmp 0x000078D2E7BFE110
000078d2e7ddeb79  int3
000078d2e7ddeb7a  int3
000078d2e7ddeb7b  nop [rax+rax*1], eax
000078d2e7ddeb80  mov rax, [r15+0x40]
000078d2e7ddeb84  movaps xmm1, [r15+0x1D0]
000078d2e7ddeb8c  vmovaps [rsp+0x10], xmm1
000078d2e7ddeb92  vmovaps xmm15, [rsp+0x10]
000078d2e7ddeb98  por xmm1, xmm15
000078d2e7ddeb9d  movaps xmm14, [r15+0x1A0]
000078d2e7ddeba5  vmovaps [rsp+0x10], xmm14
000078d2e7ddebab  vmovaps xmm13, [rsp+0x10]
000078d2e7ddebb1  por xmm14, xmm13
000078d2e7ddebb6  lea r14, [rax+0x30]
000078d2e7ddebba  mov r12, [r13+r14*1]
000078d2e7ddebbf  lea r14, [rax+0x38]
000078d2e7ddebc3  mov r11, [r13+r14*1]
000078d2e7ddebc8  movq xmm13, r12
000078d2e7ddebcd  movq xmm12, r11
000078d2e7ddebd2  movq xmm13, xmm13
000078d2e7ddebd7  vmovaps [rsp+0x10], xmm13
000078d2e7ddebdd  movq xmm13, xmm13
000078d2e7ddebe2  movaps [r15+0x130], xmm13
000078d2e7ddebea  movq xmm12, xmm12
000078d2e7ddebef  vmovaps [rsp+0x20], xmm12
000078d2e7ddebf5  movq xmm12, xmm12
000078d2e7ddebfa  movaps [r15+0x280], xmm12
000078d2e7ddec02  movaps xmm13, [r15+0x270]
000078d2e7ddec0a  vmovaps [rsp+0x30], xmm13
000078d2e7ddec10  vmovaps xmm12, [rsp+0x30]
000078d2e7ddec16  por xmm13, xmm12
000078d2e7ddec1b  lea r14, [rax+0x20]
000078d2e7ddec1f  mov r12, [r13+r14*1]
000078d2e7ddec24  lea r14, [rax+0x28]
000078d2e7ddec28  mov r11, [r13+r14*1]
000078d2e7ddec2d  movq xmm12, r12
000078d2e7ddec32  movq xmm11, r11
000078d2e7ddec37  movq xmm12, xmm12
000078d2e7ddec3c  vmovaps [rsp+0x30], xmm12
000078d2e7ddec42  movq xmm12, xmm12
000078d2e7ddec47  movaps [r15+0x150], xmm12
000078d2e7ddec4f  movq xmm11, xmm11
000078d2e7ddec54  vmovaps [rsp+0x40], xmm11
000078d2e7ddec5a  movq xmm11, xmm11
000078d2e7ddec5f  movaps [r15+0x140], xmm11
000078d2e7ddec67  lea r14, [rax+0x10]
000078d2e7ddec6b  mov r12, [r13+r14*1]
000078d2e7ddec70  lea r14, [rax+0x18]
000078d2e7ddec74  mov r11, [r13+r14*1]
000078d2e7ddec79  movq xmm12, r12
000078d2e7ddec7e  movq xmm11, r11
000078d2e7ddec83  movq xmm12, xmm12
000078d2e7ddec88  vmovaps [rsp+0x50], xmm12
000078d2e7ddec8e  movq xmm12, xmm12
000078d2e7ddec93  movaps [r15+0x170], xmm12
000078d2e7ddec9b  movq xmm11, xmm11
000078d2e7ddeca0  vmovaps [rsp+0x60], xmm11
000078d2e7ddeca6  movq xmm11, xmm11
000078d2e7ddecab  movaps [r15+0x160], xmm11
000078d2e7ddecb3  mov r14, [r13+rax*1]
000078d2e7ddecb8  vmovq xmm12, r14
000078d2e7ddecbd  vpbroadcastq xmm12, xmm12
000078d2e7ddecc2  lea r14, [rax+0x08]
000078d2e7ddecc6  mov rax, [r13+r14*1]
000078d2e7ddeccb  movq xmm11, rax
000078d2e7ddecd0  movaps [r15+0x230], xmm11
000078d2e7ddecd8  mov rax, [r15+0xF8]
000078d2e7ddecdf  lea r14, [rax+0x50]
000078d2e7ddece3  movups xmm11, [r13+r14*1]
000078d2e7ddece9  lea r14, [rax+0x60]
000078d2e7ddeced  movups xmm10, [r13+r14*1]
000078d2e7ddecf3  lea r14, [rax+0x30]
000078d2e7ddecf7  movups xmm9, [r13+r14*1]
000078d2e7ddecfd  mov r14, [r15+0x50]
000078d2e7dded01  mov [r15+0x60], r14
000078d2e7dded05  mov qword ptr [r15+0x58], 0x40
000078d2e7dded0d  movaps xmm8, xmm12
000078d2e7dded11  mulpd xmm8, xmm15
000078d2e7dded16  vcmppd xmm7, xmm8, xmm8, 0x03
000078d2e7dded1c  ptest xmm7, xmm7
000078d2e7dded21  jnz 0x000078D2E7DDFB4A
000078d2e7dded27  movq xmm15, qword ptr [r15+0x230]
000078d2e7dded30  vmovaps [rsp+0x70], xmm15
000078d2e7dded36  vpermilpd xmm15, xmm15, 0x00
000078d2e7dded3c  movaps xmm7, xmm9
000078d2e7dded40  mulpd xmm7, xmm15
000078d2e7dded45  vcmppd xmm6, xmm7, xmm7, 0x03
000078d2e7dded4a  ptest xmm6, xmm6
000078d2e7dded4f  jnz 0x000078D2E7DDFC8E
000078d2e7dded55  vxorps xmm15, xmm15, xmm15
000078d2e7dded5a  vpbroadcastq xmm15, xmm15
000078d2e7dded5f  movaps xmm9, xmm12
000078d2e7dded63  mulpd xmm9, xmm10
000078d2e7dded68  vcmppd xmm6, xmm9, xmm9, 0x03
000078d2e7dded6e  ptest xmm6, xmm6
000078d2e7dded73  jnz 0x000078D2E7DDFDD0
000078d2e7dded79  movaps xmm10, xmm12
000078d2e7dded7d  mulpd xmm10, xmm11
000078d2e7dded82  vcmppd xmm6, xmm10, xmm10, 0x03
000078d2e7dded88  ptest xmm6, xmm6
000078d2e7dded8d  jnz 0x000078D2E7DDFF14
000078d2e7dded93  movaps xmm11, [r15+0x1F0]
000078d2e7dded9b  movaps xmm6, xmm12
000078d2e7dded9f  mulpd xmm6, xmm11
000078d2e7ddeda4  vcmppd xmm5, xmm6, xmm6, 0x03
000078d2e7ddeda9  ptest xmm5, xmm5
000078d2e7ddedae  jnz 0x000078D2E7DE0058
000078d2e7ddedb4  movaps xmm12, [r15+0x2A0]
000078d2e7ddedbc  vmovaps [rsp+0x80], xmm12
000078d2e7ddedc5  vmovaps xmm11, [rsp+0x80]
000078d2e7ddedce  por xmm12, xmm11
000078d2e7ddedd3  movaps xmm11, [r15+0x250]
000078d2e7ddeddb  vmovaps [rsp+0x80], xmm11
000078d2e7ddede4  vmovaps xmm5, [rsp+0x80]
000078d2e7ddeded  por xmm11, xmm5
000078d2e7ddedf2  vmovaps xmm4, [rsp+0x70]
000078d2e7ddedf8  vpermilpd xmm4, xmm4, 0x00
000078d2e7ddedfe  movaps xmm3, xmm5
000078d2e7ddee01  mulpd xmm3, xmm4
000078d2e7ddee05  vcmppd xmm2, xmm3, xmm3, 0x03
000078d2e7ddee0a  ptest xmm2, xmm2
000078d2e7ddee0f  jnz 0x000078D2E7DE019A
000078d2e7ddee15  mov [rsp+0x80], rax
000078d2e7ddee1d  xor eax, eax
000078d2e7ddee1f  mov r12d, 0x40
000078d2e7ddee25  mov r11d, 0x200
000078d2e7ddee2b  cmp r12, r11
000078d2e7ddee2e  cmc
000078d2e7ddee2f  lahf
000078d2e7ddee30  seto al
000078d2e7ddee33  mov [r15+0x108], eax
000078d2e7ddee3a  movaps xmm5, xmm8
000078d2e7ddee3e  addpd xmm5, xmm15
000078d2e7ddee43  vcmppd xmm4, xmm5, xmm5, 0x03
000078d2e7ddee48  ptest xmm4, xmm4
000078d2e7ddee4d  jnz 0x000078D2E7DE02DA
000078d2e7ddee53  movaps xmm8, [r15+0x1B0]
000078d2e7ddee5b  movaps xmm4, xmm9
000078d2e7ddee5f  addpd xmm4, xmm8
000078d2e7ddee64  vcmppd xmm2, xmm4, xmm4, 0x03
000078d2e7ddee69  ptest xmm2, xmm2
000078d2e7ddee6e  jnz 0x000078D2E7DE041C
000078d2e7ddee74  movaps xmm9, xmm10
000078d2e7ddee78  addpd xmm9, xmm8
000078d2e7ddee7d  vcmppd xmm2, xmm9, xmm9, 0x03
000078d2e7ddee83  ptest xmm2, xmm2
000078d2e7ddee88  jnz 0x000078D2E7DE055E
000078d2e7ddee8e  movaps xmm10, [r15+0x2F0]
000078d2e7ddee96  vmovaps [rsp+0x90], xmm10
000078d2e7ddee9f  vmovaps xmm8, [rsp+0x90]
000078d2e7ddeea8  por xmm10, xmm8
000078d2e7ddeead  movaps xmm8, [r15+0x2E0]
000078d2e7ddeeb5  vmovaps [rsp+0x90], xmm8
000078d2e7ddeebe  vmovaps xmm2, [rsp+0x90]
000078d2e7ddeec7  por xmm8, xmm2
000078d2e7ddeecc  movaps xmm2, [r15+0x2D0]
000078d2e7ddeed4  vmovaps [rsp+0x90], xmm2
000078d2e7ddeedd  vmovaps [rsp+0xA0], xmm1
000078d2e7ddeee6  vmovaps xmm1, [rsp+0x90]
000078d2e7ddeeef  por xmm2, xmm1
000078d2e7ddeef3  movaps xmm1, [r15+0x200]
000078d2e7ddeefb  vmovaps [rsp+0x90], xmm1
000078d2e7ddef04  vmovaps [rsp+0xB0], xmm15
000078d2e7ddef0d  vmovaps xmm15, [rsp+0x90]
000078d2e7ddef16  por xmm1, xmm15
000078d2e7ddef1b  movaps xmm15, [r15+0x1C0]
000078d2e7ddef23  vmovaps [rsp+0x90], xmm15
000078d2e7ddef2c  vmovaps [rsp+0xC0], xmm1
000078d2e7ddef35  vmovaps xmm1, [rsp+0x90]
000078d2e7ddef3e  por xmm15, xmm1
000078d2e7ddef43  movaps xmm1, [r15+0x190]
000078d2e7ddef4b  vmovaps [rsp+0x90], xmm1
000078d2e7ddef54  vmovaps [rsp+0xD0], xmm15
000078d2e7ddef5d  vmovaps xmm15, [rsp+0x90]
000078d2e7ddef66  por xmm1, xmm15
000078d2e7ddef6b  movaps xmm15, [r15+0x300]
000078d2e7ddef73  vmovaps [rsp+0x90], xmm15
000078d2e7ddef7c  vmovaps [rsp+0xE0], xmm1
000078d2e7ddef85  vmovaps xmm1, [rsp+0x90]
000078d2e7ddef8e  por xmm15, xmm1
000078d2e7ddef93  mov rax, [rsp+0x80]
000078d2e7ddef9b  lea r12, [rax+0xA0]
000078d2e7ddefa2  movups xmm1, [r13+r12*1]
000078d2e7ddefa8  lea r12, [rax+0xB0]
000078d2e7ddefaf  vmovaps [rsp+0x80], xmm1
000078d2e7ddefb8  movups xmm1, [r13+r12*1]
000078d2e7ddefbe  vmovaps [rsp+0x90], xmm1
000078d2e7ddefc7  vmovaps [rsp+0xF0], xmm15
000078d2e7ddefd0  vmovaps xmm15, [rsp+0xB0]
000078d2e7ddefd9  vmovaps [rsp+0xB0], xmm14
000078d2e7ddefe2  movaps xmm1, xmm6
000078d2e7ddefe5  addpd xmm1, xmm15
000078d2e7ddefea  vcmppd xmm14, xmm1, xmm1, 0x03
000078d2e7ddefef  ptest xmm14, xmm14
000078d2e7ddeff5  jnz 0x000078D2E7DE06B6
000078d2e7ddeffb  lea r12, [rax+0xF0]
000078d2e7ddf002  movups xmm15, [r13+r12*1]
000078d2e7ddf008  movaps xmm14, xmm4
000078d2e7ddf00c  addpd xmm14, xmm3
000078d2e7ddf011  vcmppd xmm6, xmm14, xmm14, 0x03
000078d2e7ddf017  ptest xmm6, xmm6
000078d2e7ddf01c  jnz 0x000078D2E7DE0801
000078d2e7ddf022  movaps xmm6, xmm9
000078d2e7ddf026  addpd xmm6, xmm7
000078d2e7ddf02a  vcmppd xmm4, xmm6, xmm6, 0x03
000078d2e7ddf02f  ptest xmm4, xmm4
000078d2e7ddf034  jnz 0x000078D2E7DE0943
000078d2e7ddf03a  vmovaps xmm9, [rsp+0x70]
000078d2e7ddf040  vpermilpd xmm9, xmm9, 0x00
000078d2e7ddf046  vmovaps xmm4, [rsp+0x90]
000078d2e7ddf04f  movaps xmm7, xmm4
000078d2e7ddf052  mulpd xmm7, xmm9
000078d2e7ddf057  vcmppd xmm3, xmm7, xmm7, 0x03
000078d2e7ddf05c  ptest xmm3, xmm3
000078d2e7ddf061  jnz 0x000078D2E7DE0A84
000078d2e7ddf067  vmovaps xmm9, [rsp+0x50]
000078d2e7ddf06d  vpermilpd xmm9, xmm9, 0x00
000078d2e7ddf073  movaps xmm4, xmm15
000078d2e7ddf077  mulpd xmm4, xmm9
000078d2e7ddf07c  vcmppd xmm3, xmm4, xmm4, 0x03
000078d2e7ddf081  ptest xmm3, xmm3
000078d2e7ddf086  jnz 0x000078D2E7DE0BC5
000078d2e7ddf08c  lea r12, [rax+0xE0]
000078d2e7ddf093  movups xmm15, [r13+r12*1]
000078d2e7ddf099  vmovaps xmm9, [rsp+0x70]
000078d2e7ddf09f  vpermilpd xmm9, xmm9, 0x00
000078d2e7ddf0a5  vmovaps [rsp+0x70], xmm1
000078d2e7ddf0ab  vmovaps xmm1, [rsp+0x80]
000078d2e7ddf0b4  vmovaps [rsp+0x80], xmm15
000078d2e7ddf0bd  movaps xmm3, xmm1
000078d2e7ddf0c0  mulpd xmm3, xmm9
000078d2e7ddf0c5  vcmppd xmm15, xmm3, xmm3, 0x03
000078d2e7ddf0ca  ptest xmm15, xmm15
000078d2e7ddf0d0  jnz 0x000078D2E7DE0D11
000078d2e7ddf0d6  vmovaps xmm1, [rsp+0xF0]
000078d2e7ddf0df  vmovaps xmm15, [rsp+0xF0]
000078d2e7ddf0e8  por xmm1, xmm15
000078d2e7ddf0ed  movaps [r15+0x300], xmm1
000078d2e7ddf0f5  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddf0fe  vmovaps xmm9, [rsp+0xE0]
000078d2e7ddf107  por xmm15, xmm9
000078d2e7ddf10c  movaps [r15+0x190], xmm15
000078d2e7ddf114  vmovaps xmm9, [rsp+0x50]
000078d2e7ddf11a  vpermilpd xmm9, xmm9, 0x00
000078d2e7ddf120  vmovaps [rsp+0x90], xmm1
000078d2e7ddf129  vmovaps [rsp+0xE0], xmm15
000078d2e7ddf132  vmovaps xmm15, [rsp+0x80]
000078d2e7ddf13b  vmovaps [rsp+0x80], xmm14
000078d2e7ddf144  movaps xmm1, xmm15
000078d2e7ddf148  mulpd xmm1, xmm9
000078d2e7ddf14d  vcmppd xmm14, xmm1, xmm1, 0x03
000078d2e7ddf152  ptest xmm14, xmm14
000078d2e7ddf158  jnz 0x000078D2E7DE0E52
000078d2e7ddf15e  lea r12, [rax+0x90]
000078d2e7ddf165  movups xmm15, [r13+r12*1]
000078d2e7ddf16b  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddf174  vmovaps xmm9, [rsp+0xD0]
000078d2e7ddf17d  por xmm14, xmm9
000078d2e7ddf182  movaps [r15+0x1C0], xmm14
000078d2e7ddf18a  vmovaps xmm9, [rsp+0xC0]
000078d2e7ddf193  vmovaps [rsp+0xD0], xmm1
000078d2e7ddf19c  vmovaps xmm1, [rsp+0xC0]
000078d2e7ddf1a5  por xmm9, xmm1
000078d2e7ddf1aa  movaps [r15+0x200], xmm9
000078d2e7ddf1b2  vmovaps [rsp+0xC0], xmm2
000078d2e7ddf1bb  vmovaps xmm1, [rsp+0xC0]
000078d2e7ddf1c4  por xmm2, xmm1
000078d2e7ddf1c8  movaps [r15+0x2D0], xmm2
000078d2e7ddf1d0  vmovaps [rsp+0xC0], xmm8
000078d2e7ddf1d9  vmovaps xmm1, [rsp+0xC0]
000078d2e7ddf1e2  por xmm8, xmm1
000078d2e7ddf1e7  movaps [r15+0x2E0], xmm8
000078d2e7ddf1ef  vmovaps [rsp+0xC0], xmm15
000078d2e7ddf1f8  movaps xmm1, xmm5
000078d2e7ddf1fb  addpd xmm1, xmm7
000078d2e7ddf1ff  vcmppd xmm15, xmm1, xmm1, 0x03
000078d2e7ddf204  ptest xmm15, xmm15
000078d2e7ddf20a  jnz 0x000078D2E7DE0F9E
000078d2e7ddf210  vmovaps xmm15, [rsp+0x50]
000078d2e7ddf216  vpermilpd xmm15, xmm15, 0x00
000078d2e7ddf21c  vmovaps xmm5, [rsp+0xC0]
000078d2e7ddf225  vmovaps [rsp+0xC0], xmm1
000078d2e7ddf22e  movaps xmm7, xmm5
000078d2e7ddf231  mulpd xmm7, xmm15
000078d2e7ddf236  vcmppd xmm1, xmm7, xmm7, 0x03
000078d2e7ddf23b  ptest xmm1, xmm1
000078d2e7ddf240  jnz 0x000078D2E7DE10DE
000078d2e7ddf246  lea r12, [rax+0x80]
000078d2e7ddf24d  movups xmm1, [r13+r12*1]
000078d2e7ddf253  vmovaps xmm5, [rsp+0x70]
000078d2e7ddf259  vmovaps [rsp+0x70], xmm1
000078d2e7ddf25f  movaps xmm15, xmm5
000078d2e7ddf263  addpd xmm15, xmm3
000078d2e7ddf268  vcmppd xmm1, xmm15, xmm15, 0x03
000078d2e7ddf26e  ptest xmm1, xmm1
000078d2e7ddf273  jnz 0x000078D2E7DE1229
000078d2e7ddf279  vmovaps xmm5, [rsp+0x80]
000078d2e7ddf282  movaps xmm1, xmm5
000078d2e7ddf285  addpd xmm1, xmm4
000078d2e7ddf289  vcmppd xmm3, xmm1, xmm1, 0x03
000078d2e7ddf28e  ptest xmm3, xmm3
000078d2e7ddf293  jnz 0x000078D2E7DE136B
000078d2e7ddf299  vmovaps [rsp+0x80], xmm10
000078d2e7ddf2a2  vmovaps xmm5, [rsp+0x80]
000078d2e7ddf2ab  por xmm10, xmm5
000078d2e7ddf2b0  movaps [r15+0x2F0], xmm10
000078d2e7ddf2b8  vmovaps xmm5, [rsp+0x50]
000078d2e7ddf2be  vpermilpd xmm5, xmm5, 0x00
000078d2e7ddf2c4  vmovaps xmm3, [rsp+0x70]
000078d2e7ddf2ca  vmovaps [rsp+0x50], xmm1
000078d2e7ddf2d0  movaps xmm4, xmm3
000078d2e7ddf2d3  mulpd xmm4, xmm5
000078d2e7ddf2d7  vcmppd xmm1, xmm4, xmm4, 0x03
000078d2e7ddf2dc  ptest xmm1, xmm1
000078d2e7ddf2e1  jnz 0x000078D2E7DE14AB
000078d2e7ddf2e7  lea r12, [rax+0xD0]
000078d2e7ddf2ee  movups xmm1, [r13+r12*1]
000078d2e7ddf2f4  vmovaps xmm3, [rsp+0xD0]
000078d2e7ddf2fd  vmovaps [rsp+0x70], xmm1
000078d2e7ddf303  movaps xmm5, xmm6
000078d2e7ddf306  addpd xmm5, xmm3
000078d2e7ddf30a  vcmppd xmm1, xmm5, xmm5, 0x03
000078d2e7ddf30f  ptest xmm1, xmm1
000078d2e7ddf314  jnz 0x000078D2E7DE15F5
000078d2e7ddf31a  vmovaps xmm1, [rsp+0x60]
000078d2e7ddf320  vpermilpd xmm1, xmm1, 0x00
000078d2e7ddf326  movaps xmm6, xmm9
000078d2e7ddf32a  mulpd xmm6, xmm1
000078d2e7ddf32e  vcmppd xmm3, xmm6, xmm6, 0x03
000078d2e7ddf333  ptest xmm3, xmm3
000078d2e7ddf338  jnz 0x000078D2E7DE1735
000078d2e7ddf33e  movaps [r15+0x260], xmm6
000078d2e7ddf346  vxorps xmm1, xmm1, xmm1
000078d2e7ddf34a  vpbroadcastq xmm1, xmm1
000078d2e7ddf34f  movaps [r15+0x1B0], xmm1
000078d2e7ddf357  vmovaps xmm1, [rsp+0x60]
000078d2e7ddf35d  vpermilpd xmm1, xmm1, 0x00
000078d2e7ddf363  vmovaps xmm3, [rsp+0x70]
000078d2e7ddf369  vmovaps [rsp+0x70], xmm15
000078d2e7ddf36f  movaps xmm9, xmm3
000078d2e7ddf373  mulpd xmm9, xmm1
000078d2e7ddf378  vcmppd xmm15, xmm9, xmm9, 0x03
000078d2e7ddf37e  ptest xmm15, xmm15
000078d2e7ddf384  jnz 0x000078D2E7DE1876
000078d2e7ddf38a  lea r12, [rax+0xC0]
000078d2e7ddf391  movups xmm1, [r13+r12*1]
000078d2e7ddf397  vmovaps xmm3, [rsp+0xC0]
000078d2e7ddf3a0  vmovaps [rsp+0x80], xmm1
000078d2e7ddf3a9  movaps xmm15, xmm3
000078d2e7ddf3ad  addpd xmm15, xmm7
000078d2e7ddf3b2  vcmppd xmm1, xmm15, xmm15, 0x03
000078d2e7ddf3b8  ptest xmm1, xmm1
000078d2e7ddf3bd  jnz 0x000078D2E7DE19C2
000078d2e7ddf3c3  vmovaps [rsp+0xC0], xmm13
000078d2e7ddf3cc  vmovaps xmm1, [rsp+0xC0]
000078d2e7ddf3d5  por xmm13, xmm1
000078d2e7ddf3da  movaps [r15+0x270], xmm13
000078d2e7ddf3e2  vmovaps xmm1, [rsp+0xB0]
000078d2e7ddf3eb  vmovaps xmm7, [rsp+0xB0]
000078d2e7ddf3f4  por xmm1, xmm7
000078d2e7ddf3f8  movaps [r15+0x1A0], xmm1
000078d2e7ddf400  vmovaps xmm1, [rsp+0x60]
000078d2e7ddf406  vpermilpd xmm1, xmm1, 0x00
000078d2e7ddf40c  vmovaps [rsp+0xB0], xmm1
000078d2e7ddf415  vmovaps xmm1, [rsp+0x80]
000078d2e7ddf41e  vmovaps [rsp+0x80], xmm15
000078d2e7ddf427  vmovaps xmm15, [rsp+0xB0]
000078d2e7ddf430  vmovaps [rsp+0xB0], xmm14
000078d2e7ddf439  movaps xmm3, xmm1
000078d2e7ddf43c  mulpd xmm3, xmm15
000078d2e7ddf441  vcmppd xmm14, xmm3, xmm3, 0x03
000078d2e7ddf446  ptest xmm14, xmm14
000078d2e7ddf44c  jnz 0x000078D2E7DE1B04
000078d2e7ddf452  lea r12, [rax+0x20]
000078d2e7ddf456  movups xmm1, [r13+r12*1]
000078d2e7ddf45c  movaps [r15+0x110], xmm1
000078d2e7ddf464  vmovaps xmm14, [rsp+0x70]
000078d2e7ddf46a  vmovaps [rsp+0x70], xmm1
000078d2e7ddf470  movaps xmm15, xmm14
000078d2e7ddf474  addpd xmm15, xmm4
000078d2e7ddf479  vcmppd xmm1, xmm15, xmm15, 0x03
000078d2e7ddf47f  ptest xmm1, xmm1
000078d2e7ddf484  jnz 0x000078D2E7DE1C4F
000078d2e7ddf48a  vmovaps xmm1, [rsp+0x60]
000078d2e7ddf490  vpermilpd xmm1, xmm1, 0x00
000078d2e7ddf496  movaps xmm14, xmm2
000078d2e7ddf49a  mulpd xmm14, xmm1
000078d2e7ddf49f  vcmppd xmm4, xmm14, xmm14, 0x03
000078d2e7ddf4a5  ptest xmm4, xmm4
000078d2e7ddf4aa  jnz 0x000078D2E7DE1D92
000078d2e7ddf4b0  vmovaps xmm4, [rsp+0x50]
000078d2e7ddf4b6  movaps xmm1, xmm4
000078d2e7ddf4b9  addpd xmm1, xmm9
000078d2e7ddf4be  vcmppd xmm2, xmm1, xmm1, 0x03
000078d2e7ddf4c3  ptest xmm2, xmm2
000078d2e7ddf4c8  jnz 0x000078D2E7DE1ED4
000078d2e7ddf4ce  vmovaps xmm9, [rsp+0x30]
000078d2e7ddf4d4  vpermilpd xmm9, xmm9, 0x00
000078d2e7ddf4da  vmovaps xmm2, [rsp+0x70]
000078d2e7ddf4e0  vmovaps [rsp+0x50], xmm1
000078d2e7ddf4e6  movaps xmm4, xmm2
000078d2e7ddf4e9  mulpd xmm4, xmm9
000078d2e7ddf4ee  vcmppd xmm1, xmm4, xmm4, 0x03
000078d2e7ddf4f3  ptest xmm1, xmm1
000078d2e7ddf4f8  jnz 0x000078D2E7DE2015
000078d2e7ddf4fe  vmovaps xmm1, [rsp+0x30]
000078d2e7ddf504  vpermilpd xmm1, xmm1, 0x00
000078d2e7ddf50a  vmovaps xmm2, [rsp+0x90]
000078d2e7ddf513  vmovaps [rsp+0x60], xmm15
000078d2e7ddf519  movaps xmm9, xmm2
000078d2e7ddf51d  mulpd xmm9, xmm1
000078d2e7ddf522  vcmppd xmm15, xmm9, xmm9, 0x03
000078d2e7ddf528  ptest xmm15, xmm15
000078d2e7ddf52e  jnz 0x000078D2E7DE2156
000078d2e7ddf534  vmovaps xmm15, [rsp+0x80]
000078d2e7ddf53d  movaps xmm1, xmm15
000078d2e7ddf541  addpd xmm1, xmm6
000078d2e7ddf545  vcmppd xmm2, xmm1, xmm1, 0x03
000078d2e7ddf54a  ptest xmm2, xmm2
000078d2e7ddf54f  jnz 0x000078D2E7DE2298
000078d2e7ddf555  movaps xmm15, xmm5
000078d2e7ddf559  addpd xmm15, xmm3
000078d2e7ddf55e  vcmppd xmm6, xmm15, xmm15, 0x03
000078d2e7ddf564  ptest xmm6, xmm6
000078d2e7ddf569  jnz 0x000078D2E7DE23D9
000078d2e7ddf56f  vmovaps xmm6, [rsp+0x30]
000078d2e7ddf575  vpermilpd xmm6, xmm6, 0x00
000078d2e7ddf57b  movaps xmm5, xmm8
000078d2e7ddf57f  mulpd xmm5, xmm6
000078d2e7ddf583  vcmppd xmm3, xmm5, xmm5, 0x03
000078d2e7ddf588  ptest xmm3, xmm3
000078d2e7ddf58d  jnz 0x000078D2E7DE251B
000078d2e7ddf593  vmovaps xmm8, [rsp+0x30]
000078d2e7ddf599  vpermilpd xmm8, xmm8, 0x00
000078d2e7ddf59f  movaps xmm6, xmm10
000078d2e7ddf5a3  mulpd xmm6, xmm8
000078d2e7ddf5a8  vcmppd xmm3, xmm6, xmm6, 0x03
000078d2e7ddf5ad  ptest xmm3, xmm3
000078d2e7ddf5b2  jnz 0x000078D2E7DE265C
000078d2e7ddf5b8  vmovaps xmm8, [rsp+0x60]
000078d2e7ddf5be  movaps xmm10, xmm8
000078d2e7ddf5c2  addpd xmm10, xmm14
000078d2e7ddf5c7  vcmppd xmm3, xmm10, xmm10, 0x03
000078d2e7ddf5cd  ptest xmm3, xmm3
000078d2e7ddf5d2  jnz 0x000078D2E7DE279E
000078d2e7ddf5d8  vmovaps xmm8, [rsp+0x50]
000078d2e7ddf5de  movaps xmm14, xmm8
000078d2e7ddf5e2  addpd xmm14, xmm4
000078d2e7ddf5e7  vcmppd xmm3, xmm14, xmm14, 0x03
000078d2e7ddf5ed  ptest xmm3, xmm3
000078d2e7ddf5f2  jnz 0x000078D2E7DE28E2
000078d2e7ddf5f8  vmovaps xmm8, [rsp+0x40]
000078d2e7ddf5fe  vpermilpd xmm8, xmm8, 0x00
000078d2e7ddf604  movaps xmm4, xmm13
000078d2e7ddf608  mulpd xmm4, xmm8
000078d2e7ddf60d  vcmppd xmm3, xmm4, xmm4, 0x03
000078d2e7ddf612  ptest xmm3, xmm3
000078d2e7ddf617  jnz 0x000078D2E7DE2A25
000078d2e7ddf61d  movaps xmm13, xmm15
000078d2e7ddf621  addpd xmm13, xmm9
000078d2e7ddf626  vcmppd xmm8, xmm13, xmm13, 0x03
000078d2e7ddf62c  ptest xmm8, xmm8
000078d2e7ddf632  jnz 0x000078D2E7DE2B67
000078d2e7ddf638  movaps xmm15, xmm1
000078d2e7ddf63c  addpd xmm15, xmm5
000078d2e7ddf641  vcmppd xmm9, xmm15, xmm15, 0x03
000078d2e7ddf647  ptest xmm9, xmm9
000078d2e7ddf64d  jnz 0x000078D2E7DE2CAB
000078d2e7ddf653  vmovaps [rsp+0x30], xmm11
000078d2e7ddf659  vmovaps xmm1, [rsp+0x30]
000078d2e7ddf65f  por xmm11, xmm1
000078d2e7ddf664  movaps [r15+0x250], xmm11
000078d2e7ddf66c  vmovaps [rsp+0x30], xmm12
000078d2e7ddf672  vmovaps xmm1, [rsp+0x30]
000078d2e7ddf678  por xmm12, xmm1
000078d2e7ddf67d  movaps [r15+0x2A0], xmm12
000078d2e7ddf685  vmovaps xmm1, [rsp+0xA0]
000078d2e7ddf68e  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddf697  por xmm1, xmm11
000078d2e7ddf69c  movaps [r15+0x1D0], xmm1
000078d2e7ddf6a4  lea r12, [rax+0x40]
000078d2e7ddf6a8  movups xmm1, [r13+r12*1]
000078d2e7ddf6ae  movaps [r15+0x2C0], xmm1
000078d2e7ddf6b6  vmovaps xmm11, [rsp+0x40]
000078d2e7ddf6bc  vpermilpd xmm11, xmm11, 0x00
000078d2e7ddf6c2  vmovaps xmm8, [rsp+0xE0]
000078d2e7ddf6cb  movaps xmm9, xmm8
000078d2e7ddf6cf  mulpd xmm9, xmm11
000078d2e7ddf6d4  vcmppd xmm5, xmm9, xmm9, 0x03
000078d2e7ddf6da  ptest xmm5, xmm5
000078d2e7ddf6df  jnz 0x000078D2E7DE2DF7
000078d2e7ddf6e5  movaps xmm11, xmm10
000078d2e7ddf6e9  addpd xmm11, xmm6
000078d2e7ddf6ee  vcmppd xmm8, xmm11, xmm11, 0x03
000078d2e7ddf6f4  ptest xmm8, xmm8
000078d2e7ddf6fa  jnz 0x000078D2E7DE2F3B
000078d2e7ddf700  movaps xmm10, xmm14
000078d2e7ddf704  addpd xmm10, xmm4
000078d2e7ddf709  vcmppd xmm8, xmm10, xmm10, 0x03
000078d2e7ddf70f  ptest xmm8, xmm8
000078d2e7ddf715  jnz 0x000078D2E7DE307E
000078d2e7ddf71b  vmovaps xmm14, [rsp+0x40]
000078d2e7ddf721  vpermilpd xmm14, xmm14, 0x00
000078d2e7ddf727  movaps xmm8, xmm1
000078d2e7ddf72b  mulpd xmm8, xmm14
000078d2e7ddf730  vcmppd xmm6, xmm8, xmm8, 0x03
000078d2e7ddf736  ptest xmm6, xmm6
000078d2e7ddf73b  jnz 0x000078D2E7DE31C1
000078d2e7ddf741  movaps xmm1, [r15+0x2B0]
000078d2e7ddf749  vmovaps xmm14, [rsp+0x40]
000078d2e7ddf74f  vpermilpd xmm14, xmm14, 0x00
000078d2e7ddf755  movaps xmm6, xmm1
000078d2e7ddf758  mulpd xmm6, xmm14
000078d2e7ddf75d  vcmppd xmm5, xmm6, xmm6, 0x03
000078d2e7ddf762  ptest xmm5, xmm5
000078d2e7ddf767  jnz 0x000078D2E7DE3304
000078d2e7ddf76d  vmovaps xmm1, [rsp+0x10]
000078d2e7ddf773  vpermilpd xmm1, xmm1, 0x00
000078d2e7ddf779  movaps xmm14, xmm12
000078d2e7ddf77d  mulpd xmm14, xmm1
000078d2e7ddf782  vcmppd xmm5, xmm14, xmm14, 0x03
000078d2e7ddf788  ptest xmm5, xmm5
000078d2e7ddf78d  jnz 0x000078D2E7DE3445
000078d2e7ddf793  movaps xmm1, xmm13
000078d2e7ddf797  addpd xmm1, xmm9
000078d2e7ddf79c  vcmppd xmm12, xmm1, xmm1, 0x03
000078d2e7ddf7a1  ptest xmm12, xmm12
000078d2e7ddf7a7  jnz 0x000078D2E7DE3588
000078d2e7ddf7ad  vmovaps xmm13, [rsp+0x10]
000078d2e7ddf7b3  vpermilpd xmm13, xmm13, 0x00
000078d2e7ddf7b9  movaps xmm12, xmm7
000078d2e7ddf7bd  mulpd xmm12, xmm13
000078d2e7ddf7c2  vcmppd xmm9, xmm12, xmm12, 0x03
000078d2e7ddf7c8  ptest xmm9, xmm9
000078d2e7ddf7ce  jnz 0x000078D2E7DE36CA
000078d2e7ddf7d4  movaps xmm13, xmm15
000078d2e7ddf7d8  addpd xmm13, xmm8
000078d2e7ddf7dd  vcmppd xmm9, xmm13, xmm13, 0x03
000078d2e7ddf7e3  ptest xmm9, xmm9
000078d2e7ddf7e9  jnz 0x000078D2E7DE380D
000078d2e7ddf7ef  movaps xmm15, [r15+0x290]
000078d2e7ddf7f7  vmovaps xmm9, [rsp+0x10]
000078d2e7ddf7fd  vpermilpd xmm9, xmm9, 0x00
000078d2e7ddf803  movaps xmm8, xmm15
000078d2e7ddf807  mulpd xmm8, xmm9
000078d2e7ddf80c  vcmppd xmm7, xmm8, xmm8, 0x03
000078d2e7ddf812  ptest xmm7, xmm7
000078d2e7ddf817  jnz 0x000078D2E7DE3951
000078d2e7ddf81d  movaps xmm15, xmm11
000078d2e7ddf821  addpd xmm15, xmm6
000078d2e7ddf826  vcmppd xmm9, xmm15, xmm15, 0x03
000078d2e7ddf82c  ptest xmm9, xmm9
000078d2e7ddf832  jnz 0x000078D2E7DE3A95
000078d2e7ddf838  movaps xmm11, [r15+0x1E0]
000078d2e7ddf840  vmovaps xmm9, [rsp+0x10]
000078d2e7ddf846  vpermilpd xmm9, xmm9, 0x00
000078d2e7ddf84c  movaps xmm7, xmm11
000078d2e7ddf850  mulpd xmm7, xmm9
000078d2e7ddf855  vcmppd xmm6, xmm7, xmm7, 0x03
000078d2e7ddf85a  ptest xmm6, xmm6
000078d2e7ddf85f  jnz 0x000078D2E7DE3BD8
000078d2e7ddf865  movaps xmm11, xmm10
000078d2e7ddf869  addpd xmm11, xmm14
000078d2e7ddf86e  vcmppd xmm9, xmm11, xmm11, 0x03
000078d2e7ddf874  ptest xmm9, xmm9
000078d2e7ddf87a  jnz 0x000078D2E7DE3D1A
000078d2e7ddf880  lea r12, [rax+0x70]
000078d2e7ddf884  movups xmm14, [r13+r12*1]
000078d2e7ddf88a  movaps [r15+0x240], xmm14
000078d2e7ddf892  movaps xmm10, xmm1
000078d2e7ddf896  addpd xmm10, xmm12
000078d2e7ddf89b  vcmppd xmm9, xmm10, xmm10, 0x03
000078d2e7ddf8a1  ptest xmm9, xmm9
000078d2e7ddf8a7  jnz 0x000078D2E7DE3E68
000078d2e7ddf8ad  movaps [r15+0x170], xmm10
000078d2e7ddf8b5  vmovaps xmm1, [rsp+0x20]
000078d2e7ddf8bb  vpermilpd xmm1, xmm1, 0x00
000078d2e7ddf8c1  movaps xmm12, xmm14
000078d2e7ddf8c5  mulpd xmm12, xmm1
000078d2e7ddf8ca  vcmppd xmm9, xmm12, xmm12, 0x03
000078d2e7ddf8d0  ptest xmm9, xmm9
000078d2e7ddf8d6  jnz 0x000078D2E7DE3FAB
000078d2e7ddf8dc  vmovaps xmm1, [rsp+0x20]
000078d2e7ddf8e2  vpermilpd xmm1, xmm1, 0x00
000078d2e7ddf8e8  vmovaps xmm9, [rsp+0xB0]
000078d2e7ddf8f1  movaps xmm14, xmm9
000078d2e7ddf8f5  mulpd xmm14, xmm1
000078d2e7ddf8fa  vcmppd xmm6, xmm14, xmm14, 0x03
000078d2e7ddf900  ptest xmm6, xmm6
000078d2e7ddf905  jnz 0x000078D2E7DE40EE
000078d2e7ddf90b  movaps [r15+0x180], xmm14
000078d2e7ddf913  movaps xmm1, xmm13
000078d2e7ddf917  addpd xmm1, xmm8
000078d2e7ddf91c  vcmppd xmm9, xmm1, xmm1, 0x03
000078d2e7ddf921  ptest xmm9, xmm9
000078d2e7ddf927  jnz 0x000078D2E7DE4231
000078d2e7ddf92d  movaps [r15+0x210], xmm1
000078d2e7ddf935  movups xmm13, [r13+rax*1]
000078d2e7ddf93b  lea r12, [rax+0x10]
000078d2e7ddf93f  movups xmm9, [r13+r12*1]
000078d2e7ddf945  movaps [r15+0x230], xmm9
000078d2e7ddf94d  movaps xmm8, xmm15
000078d2e7ddf951  addpd xmm8, xmm7
000078d2e7ddf956  vcmppd xmm6, xmm8, xmm8, 0x03
000078d2e7ddf95c  ptest xmm6, xmm6
000078d2e7ddf961  jnz 0x000078D2E7DE4387
000078d2e7ddf967  movaps [r15+0x130], xmm8
000078d2e7ddf96f  vmovaps xmm15, [rsp+0x20]
000078d2e7ddf975  vpermilpd xmm15, xmm15, 0x00
000078d2e7ddf97b  movaps xmm7, xmm9
000078d2e7ddf97f  mulpd xmm7, xmm15
000078d2e7ddf984  vcmppd xmm6, xmm7, xmm7, 0x03
000078d2e7ddf989  ptest xmm6, xmm6
000078d2e7ddf98e  jnz 0x000078D2E7DE44CA
000078d2e7ddf994  movaps [r15+0x220], xmm7
000078d2e7ddf99c  vmovaps xmm15, [rsp+0x20]
000078d2e7ddf9a2  vpermilpd xmm15, xmm15, 0x00
000078d2e7ddf9a8  movaps xmm9, xmm13
000078d2e7ddf9ac  mulpd xmm9, xmm15
000078d2e7ddf9b1  vcmppd xmm6, xmm9, xmm9, 0x03
000078d2e7ddf9b7  ptest xmm6, xmm6
000078d2e7ddf9bc  jnz 0x000078D2E7DE460C
000078d2e7ddf9c2  movaps xmm15, xmm11
000078d2e7ddf9c6  addpd xmm15, xmm12
000078d2e7ddf9cb  vcmppd xmm13, xmm15, xmm15, 0x03
000078d2e7ddf9d1  ptest xmm13, xmm13
000078d2e7ddf9d7  jnz 0x000078D2E7DE4750
000078d2e7ddf9dd  movaps [r15+0x140], xmm15
000078d2e7ddf9e5  movaps xmm13, xmm10
000078d2e7ddf9e9  addpd xmm13, xmm14
000078d2e7ddf9ee  vcmppd xmm12, xmm13, xmm13, 0x03
000078d2e7ddf9f4  ptest xmm12, xmm12
000078d2e7ddf9fa  jnz 0x000078D2E7DE4894
000078d2e7ddfa00  movaps [r15+0x150], xmm13
000078d2e7ddfa08  movaps xmm14, xmm1
000078d2e7ddfa0c  addpd xmm14, xmm7
000078d2e7ddfa11  vcmppd xmm12, xmm14, xmm14, 0x03
000078d2e7ddfa17  ptest xmm12, xmm12
000078d2e7ddfa1d  jnz 0x000078D2E7DE49D8
000078d2e7ddfa23  movaps [r15+0x160], xmm14
000078d2e7ddfa2b  movaps xmm1, xmm8
000078d2e7ddfa2f  addpd xmm1, xmm9
000078d2e7ddfa34  vcmppd xmm12, xmm1, xmm1, 0x03
000078d2e7ddfa39  ptest xmm12, xmm12
000078d2e7ddfa3f  jnz 0x000078D2E7DE4B1A
000078d2e7ddfa45  movaps [r15+0x120], xmm1
000078d2e7ddfa4d  movups [r13+r14*1], xmm15
000078d2e7ddfa53  lea rax, [r14+0x10]
000078d2e7ddfa57  movups [r13+rax*1], xmm13
000078d2e7ddfa5d  lea rax, [r14+0x20]
000078d2e7ddfa61  movups [r13+rax*1], xmm14
000078d2e7ddfa67  lea rax, [r14+0x30]
000078d2e7ddfa6b  movups [r13+rax*1], xmm1
000078d2e7ddfa71  mov eax, [r15+0x108]
000078d2e7ddfa78  sahf
000078d2e7ddfa79  jnz 0x000078D2E7DDFAAB
000078d2e7ddfa7b  cmp dword ptr [r15+0x318], 0x00
000078d2e7ddfa83  jz 0x000078D2E7DDEAE0
000078d2e7ddfa89  nop [rax+rax*1], ax
000078d2e7ddfa92  nop [rax+rax*1], eax
000078d2e7ddfa9a  mov eax, 0x4106D0
000078d2e7ddfa9f  mov [r15+0x100], rax
000078d2e7ddfaa6  jmp 0x000078D2E7BFE110
000078d2e7ddfaab  cmp dword ptr [r15+0x318], 0x00
000078d2e7ddfab3  jz 0x000078D2E7DD89C0
000078d2e7ddfab9  nop [rax+rax*1], ax
000078d2e7ddfac2  nop [rax+rax*1], eax
000078d2e7ddfaca  mov eax, 0x410504
000078d2e7ddfacf  mov [r15+0x100], rax
000078d2e7ddfad6  jmp 0x000078D2E7BFE110
000078d2e7ddfadb  int3
000078d2e7ddfadc  call 0x000078D2E7CE27E0
000078d2e7ddfae1  jmp 0x000078D2E7DDEBBF
000078d2e7ddfae6  call 0x000078D2E7CE1570
000078d2e7ddfaeb  jmp 0x000078D2E7DDEBC8
000078d2e7ddfaf0  call 0x000078D2E7CE27E0
000078d2e7ddfaf5  jmp 0x000078D2E7DDEC24
000078d2e7ddfafa  call 0x000078D2E7CE1570
000078d2e7ddfaff  jmp 0x000078D2E7DDEC2D
000078d2e7ddfb04  call 0x000078D2E7CE27E0
000078d2e7ddfb09  jmp 0x000078D2E7DDEC70
000078d2e7ddfb0e  call 0x000078D2E7CE1570
000078d2e7ddfb13  jmp 0x000078D2E7DDEC79
000078d2e7ddfb18  call 0x000078D2E7C0DC20
000078d2e7ddfb1d  jmp 0x000078D2E7DDECB8
000078d2e7ddfb22  call 0x000078D2E7CD59C0
000078d2e7ddfb27  jmp 0x000078D2E7DDECCB
000078d2e7ddfb2c  call 0x000078D2E7CE0E30
000078d2e7ddfb31  jmp 0x000078D2E7DDECE9
000078d2e7ddfb36  call 0x000078D2E7CDFBC0
000078d2e7ddfb3b  jmp 0x000078D2E7DDECF3
000078d2e7ddfb40  call 0x000078D2E7CDE950
000078d2e7ddfb45  jmp 0x000078D2E7DDECFD
000078d2e7ddfb4a  sub rsp, 0x08
000078d2e7ddfb4e  push rax
000078d2e7ddfb4f  push rcx
000078d2e7ddfb50  push rdx
000078d2e7ddfb51  push rdi
000078d2e7ddfb52  push rsi
000078d2e7ddfb53  push r8
000078d2e7ddfb55  push r9
000078d2e7ddfb57  push r10
000078d2e7ddfb59  push r11
000078d2e7ddfb5b  sub rsp, 0xF0
000078d2e7ddfb62  vmovaps [rsp], xmm0
000078d2e7ddfb67  vmovaps [rsp+0x10], xmm1
000078d2e7ddfb6d  vmovaps [rsp+0x20], xmm2
000078d2e7ddfb73  vmovaps [rsp+0x30], xmm3
000078d2e7ddfb79  vmovaps [rsp+0x40], xmm4
000078d2e7ddfb7f  vmovaps [rsp+0x50], xmm5
000078d2e7ddfb85  vmovaps [rsp+0x60], xmm6
000078d2e7ddfb8b  vmovaps [rsp+0x70], xmm7
000078d2e7ddfb91  vmovaps [rsp+0x80], xmm9
000078d2e7ddfb9a  vmovaps [rsp+0x90], xmm10
000078d2e7ddfba3  vmovaps [rsp+0xA0], xmm11
000078d2e7ddfbac  vmovaps [rsp+0xB0], xmm12
000078d2e7ddfbb5  vmovaps [rsp+0xC0], xmm13
000078d2e7ddfbbe  vmovaps [rsp+0xD0], xmm14
000078d2e7ddfbc7  vmovaps [rsp+0xE0], xmm15
000078d2e7ddfbd0  sub rsp, 0x30
000078d2e7ddfbd4  movaps [rsp], xmm8
000078d2e7ddfbd9  movaps [rsp+0x10], xmm12
000078d2e7ddfbdf  movaps [rsp+0x20], xmm15
000078d2e7ddfbe5  lea rdi, [rsp]
000078d2e7ddfbe9  mov esi, 0x00
000078d2e7ddfbee  mov rax, 0x5997D2DB1530
000078d2e7ddfbf8  call rax
000078d2e7ddfbfa  movaps xmm8, [rsp]
000078d2e7ddfbff  add rsp, 0x30
000078d2e7ddfc03  vmovaps xmm0, [rsp]
000078d2e7ddfc08  vmovaps xmm1, [rsp+0x10]
000078d2e7ddfc0e  vmovaps xmm2, [rsp+0x20]
000078d2e7ddfc14  vmovaps xmm3, [rsp+0x30]
000078d2e7ddfc1a  vmovaps xmm4, [rsp+0x40]
000078d2e7ddfc20  vmovaps xmm5, [rsp+0x50]
000078d2e7ddfc26  vmovaps xmm6, [rsp+0x60]
000078d2e7ddfc2c  vmovaps xmm7, [rsp+0x70]
000078d2e7ddfc32  vmovaps xmm9, [rsp+0x80]
000078d2e7ddfc3b  vmovaps xmm10, [rsp+0x90]
000078d2e7ddfc44  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddfc4d  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddfc56  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddfc5f  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddfc68  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddfc71  add rsp, 0xF0
000078d2e7ddfc78  pop r11
000078d2e7ddfc7a  pop r10
000078d2e7ddfc7c  pop r9
000078d2e7ddfc7e  pop r8
000078d2e7ddfc80  pop rsi
000078d2e7ddfc81  pop rdi
000078d2e7ddfc82  pop rdx
000078d2e7ddfc83  pop rcx
000078d2e7ddfc84  pop rax
000078d2e7ddfc85  add rsp, 0x08
000078d2e7ddfc89  jmp 0x000078D2E7DDED27
000078d2e7ddfc8e  sub rsp, 0x08
000078d2e7ddfc92  push rax
000078d2e7ddfc93  push rcx
000078d2e7ddfc94  push rdx
000078d2e7ddfc95  push rdi
000078d2e7ddfc96  push rsi
000078d2e7ddfc97  push r8
000078d2e7ddfc99  push r9
000078d2e7ddfc9b  push r10
000078d2e7ddfc9d  push r11
000078d2e7ddfc9f  sub rsp, 0xF0
000078d2e7ddfca6  vmovaps [rsp], xmm0
000078d2e7ddfcab  vmovaps [rsp+0x10], xmm1
000078d2e7ddfcb1  vmovaps [rsp+0x20], xmm2
000078d2e7ddfcb7  vmovaps [rsp+0x30], xmm3
000078d2e7ddfcbd  vmovaps [rsp+0x40], xmm4
000078d2e7ddfcc3  vmovaps [rsp+0x50], xmm5
000078d2e7ddfcc9  vmovaps [rsp+0x60], xmm6
000078d2e7ddfccf  vmovaps [rsp+0x70], xmm8
000078d2e7ddfcd5  vmovaps [rsp+0x80], xmm9
000078d2e7ddfcde  vmovaps [rsp+0x90], xmm10
000078d2e7ddfce7  vmovaps [rsp+0xA0], xmm11
000078d2e7ddfcf0  vmovaps [rsp+0xB0], xmm12
000078d2e7ddfcf9  vmovaps [rsp+0xC0], xmm13
000078d2e7ddfd02  vmovaps [rsp+0xD0], xmm14
000078d2e7ddfd0b  vmovaps [rsp+0xE0], xmm15
000078d2e7ddfd14  sub rsp, 0x30
000078d2e7ddfd18  movaps [rsp], xmm7
000078d2e7ddfd1c  movaps [rsp+0x10], xmm9
000078d2e7ddfd22  movaps [rsp+0x20], xmm15
000078d2e7ddfd28  lea rdi, [rsp]
000078d2e7ddfd2c  mov esi, 0x00
000078d2e7ddfd31  mov rax, 0x5997D2DB1530
000078d2e7ddfd3b  call rax
000078d2e7ddfd3d  movaps xmm7, [rsp]
000078d2e7ddfd41  add rsp, 0x30
000078d2e7ddfd45  vmovaps xmm0, [rsp]
000078d2e7ddfd4a  vmovaps xmm1, [rsp+0x10]
000078d2e7ddfd50  vmovaps xmm2, [rsp+0x20]
000078d2e7ddfd56  vmovaps xmm3, [rsp+0x30]
000078d2e7ddfd5c  vmovaps xmm4, [rsp+0x40]
000078d2e7ddfd62  vmovaps xmm5, [rsp+0x50]
000078d2e7ddfd68  vmovaps xmm6, [rsp+0x60]
000078d2e7ddfd6e  vmovaps xmm8, [rsp+0x70]
000078d2e7ddfd74  vmovaps xmm9, [rsp+0x80]
000078d2e7ddfd7d  vmovaps xmm10, [rsp+0x90]
000078d2e7ddfd86  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddfd8f  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddfd98  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddfda1  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddfdaa  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddfdb3  add rsp, 0xF0
000078d2e7ddfdba  pop r11
000078d2e7ddfdbc  pop r10
000078d2e7ddfdbe  pop r9
000078d2e7ddfdc0  pop r8
000078d2e7ddfdc2  pop rsi
000078d2e7ddfdc3  pop rdi
000078d2e7ddfdc4  pop rdx
000078d2e7ddfdc5  pop rcx
000078d2e7ddfdc6  pop rax
000078d2e7ddfdc7  add rsp, 0x08
000078d2e7ddfdcb  jmp 0x000078D2E7DDED55
000078d2e7ddfdd0  sub rsp, 0x08
000078d2e7ddfdd4  push rax
000078d2e7ddfdd5  push rcx
000078d2e7ddfdd6  push rdx
000078d2e7ddfdd7  push rdi
000078d2e7ddfdd8  push rsi
000078d2e7ddfdd9  push r8
000078d2e7ddfddb  push r9
000078d2e7ddfddd  push r10
000078d2e7ddfddf  push r11
000078d2e7ddfde1  sub rsp, 0xF0
000078d2e7ddfde8  vmovaps [rsp], xmm0
000078d2e7ddfded  vmovaps [rsp+0x10], xmm1
000078d2e7ddfdf3  vmovaps [rsp+0x20], xmm2
000078d2e7ddfdf9  vmovaps [rsp+0x30], xmm3
000078d2e7ddfdff  vmovaps [rsp+0x40], xmm4
000078d2e7ddfe05  vmovaps [rsp+0x50], xmm5
000078d2e7ddfe0b  vmovaps [rsp+0x60], xmm6
000078d2e7ddfe11  vmovaps [rsp+0x70], xmm7
000078d2e7ddfe17  vmovaps [rsp+0x80], xmm8
000078d2e7ddfe20  vmovaps [rsp+0x90], xmm10
000078d2e7ddfe29  vmovaps [rsp+0xA0], xmm11
000078d2e7ddfe32  vmovaps [rsp+0xB0], xmm12
000078d2e7ddfe3b  vmovaps [rsp+0xC0], xmm13
000078d2e7ddfe44  vmovaps [rsp+0xD0], xmm14
000078d2e7ddfe4d  vmovaps [rsp+0xE0], xmm15
000078d2e7ddfe56  sub rsp, 0x30
000078d2e7ddfe5a  movaps [rsp], xmm9
000078d2e7ddfe5f  movaps [rsp+0x10], xmm12
000078d2e7ddfe65  movaps [rsp+0x20], xmm10
000078d2e7ddfe6b  lea rdi, [rsp]
000078d2e7ddfe6f  mov esi, 0x00
000078d2e7ddfe74  mov rax, 0x5997D2DB1530
000078d2e7ddfe7e  call rax
000078d2e7ddfe80  movaps xmm9, [rsp]
000078d2e7ddfe85  add rsp, 0x30
000078d2e7ddfe89  vmovaps xmm0, [rsp]
000078d2e7ddfe8e  vmovaps xmm1, [rsp+0x10]
000078d2e7ddfe94  vmovaps xmm2, [rsp+0x20]
000078d2e7ddfe9a  vmovaps xmm3, [rsp+0x30]
000078d2e7ddfea0  vmovaps xmm4, [rsp+0x40]
000078d2e7ddfea6  vmovaps xmm5, [rsp+0x50]
000078d2e7ddfeac  vmovaps xmm6, [rsp+0x60]
000078d2e7ddfeb2  vmovaps xmm7, [rsp+0x70]
000078d2e7ddfeb8  vmovaps xmm8, [rsp+0x80]
000078d2e7ddfec1  vmovaps xmm10, [rsp+0x90]
000078d2e7ddfeca  vmovaps xmm11, [rsp+0xA0]
000078d2e7ddfed3  vmovaps xmm12, [rsp+0xB0]
000078d2e7ddfedc  vmovaps xmm13, [rsp+0xC0]
000078d2e7ddfee5  vmovaps xmm14, [rsp+0xD0]
000078d2e7ddfeee  vmovaps xmm15, [rsp+0xE0]
000078d2e7ddfef7  add rsp, 0xF0
000078d2e7ddfefe  pop r11
000078d2e7ddff00  pop r10
000078d2e7ddff02  pop r9
000078d2e7ddff04  pop r8
000078d2e7ddff06  pop rsi
000078d2e7ddff07  pop rdi
000078d2e7ddff08  pop rdx
000078d2e7ddff09  pop rcx
000078d2e7ddff0a  pop rax
000078d2e7ddff0b  add rsp, 0x08
000078d2e7ddff0f  jmp 0x000078D2E7DDED79
000078d2e7ddff14  sub rsp, 0x08
000078d2e7ddff18  push rax
000078d2e7ddff19  push rcx
000078d2e7ddff1a  push rdx
000078d2e7ddff1b  push rdi
000078d2e7ddff1c  push rsi
000078d2e7ddff1d  push r8
000078d2e7ddff1f  push r9
000078d2e7ddff21  push r10
000078d2e7ddff23  push r11
000078d2e7ddff25  sub rsp, 0xF0
000078d2e7ddff2c  vmovaps [rsp], xmm0
000078d2e7ddff31  vmovaps [rsp+0x10], xmm1
000078d2e7ddff37  vmovaps [rsp+0x20], xmm2
000078d2e7ddff3d  vmovaps [rsp+0x30], xmm3
000078d2e7ddff43  vmovaps [rsp+0x40], xmm4
000078d2e7ddff49  vmovaps [rsp+0x50], xmm5
000078d2e7ddff4f  vmovaps [rsp+0x60], xmm6
000078d2e7ddff55  vmovaps [rsp+0x70], xmm7
000078d2e7ddff5b  vmovaps [rsp+0x80], xmm8
000078d2e7ddff64  vmovaps [rsp+0x90], xmm9
000078d2e7ddff6d  vmovaps [rsp+0xA0], xmm11
000078d2e7ddff76  vmovaps [rsp+0xB0], xmm12
000078d2e7ddff7f  vmovaps [rsp+0xC0], xmm13
000078d2e7ddff88  vmovaps [rsp+0xD0], xmm14
000078d2e7ddff91  vmovaps [rsp+0xE0], xmm15
000078d2e7ddff9a  sub rsp, 0x30
000078d2e7ddff9e  movaps [rsp], xmm10
000078d2e7ddffa3  movaps [rsp+0x10], xmm12
000078d2e7ddffa9  movaps [rsp+0x20], xmm11
000078d2e7ddffaf  lea rdi, [rsp]
000078d2e7ddffb3  mov esi, 0x00
000078d2e7ddffb8  mov rax, 0x5997D2DB1530
000078d2e7ddffc2  call rax
000078d2e7ddffc4  movaps xmm10, [rsp]
000078d2e7ddffc9  add rsp, 0x30
000078d2e7ddffcd  vmovaps xmm0, [rsp]
000078d2e7ddffd2  vmovaps xmm1, [rsp+0x10]
000078d2e7ddffd8  vmovaps xmm2, [rsp+0x20]
000078d2e7ddffde  vmovaps xmm3, [rsp+0x30]
000078d2e7ddffe4  vmovaps xmm4, [rsp+0x40]
000078d2e7ddffea  vmovaps xmm5, [rsp+0x50]
000078d2e7ddfff0  vmovaps xmm6, [rsp+0x60]
000078d2e7ddfff6  vmovaps xmm7, [rsp+0x70]
000078d2e7ddfffc  vmovaps xmm8, [rsp+0x80]
000078d2e7de0005  vmovaps xmm9, [rsp+0x90]
000078d2e7de000e  vmovaps xmm11, [rsp+0xA0]
000078d2e7de0017  vmovaps xmm12, [rsp+0xB0]
000078d2e7de0020  vmovaps xmm13, [rsp+0xC0]
000078d2e7de0029  vmovaps xmm14, [rsp+0xD0]
000078d2e7de0032  vmovaps xmm15, [rsp+0xE0]
000078d2e7de003b  add rsp, 0xF0
000078d2e7de0042  pop r11
000078d2e7de0044  pop r10
000078d2e7de0046  pop r9
000078d2e7de0048  pop r8
000078d2e7de004a  pop rsi
000078d2e7de004b  pop rdi
000078d2e7de004c  pop rdx
000078d2e7de004d  pop rcx
000078d2e7de004e  pop rax
000078d2e7de004f  add rsp, 0x08
000078d2e7de0053  jmp 0x000078D2E7DDED93
000078d2e7de0058  sub rsp, 0x08
000078d2e7de005c  push rax
000078d2e7de005d  push rcx
000078d2e7de005e  push rdx
000078d2e7de005f  push rdi
000078d2e7de0060  push rsi
000078d2e7de0061  push r8
000078d2e7de0063  push r9
000078d2e7de0065  push r10
000078d2e7de0067  push r11
000078d2e7de0069  sub rsp, 0xF0
000078d2e7de0070  vmovaps [rsp], xmm0
000078d2e7de0075  vmovaps [rsp+0x10], xmm1
000078d2e7de007b  vmovaps [rsp+0x20], xmm2
000078d2e7de0081  vmovaps [rsp+0x30], xmm3
000078d2e7de0087  vmovaps [rsp+0x40], xmm4
000078d2e7de008d  vmovaps [rsp+0x50], xmm5
000078d2e7de0093  vmovaps [rsp+0x60], xmm7
000078d2e7de0099  vmovaps [rsp+0x70], xmm8
000078d2e7de009f  vmovaps [rsp+0x80], xmm9
000078d2e7de00a8  vmovaps [rsp+0x90], xmm10
000078d2e7de00b1  vmovaps [rsp+0xA0], xmm11
000078d2e7de00ba  vmovaps [rsp+0xB0], xmm12
000078d2e7de00c3  vmovaps [rsp+0xC0], xmm13
000078d2e7de00cc  vmovaps [rsp+0xD0], xmm14
000078d2e7de00d5  vmovaps [rsp+0xE0], xmm15
000078d2e7de00de  sub rsp, 0x30
000078d2e7de00e2  movaps [rsp], xmm6
000078d2e7de00e6  movaps [rsp+0x10], xmm12
000078d2e7de00ec  movaps [rsp+0x20], xmm11
000078d2e7de00f2  lea rdi, [rsp]
000078d2e7de00f6  mov esi, 0x00
000078d2e7de00fb  mov rax, 0x5997D2DB1530
000078d2e7de0105  call rax
000078d2e7de0107  movaps xmm6, [rsp]
000078d2e7de010b  add rsp, 0x30
000078d2e7de010f  vmovaps xmm0, [rsp]
000078d2e7de0114  vmovaps xmm1, [rsp+0x10]
000078d2e7de011a  vmovaps xmm2, [rsp+0x20]
000078d2e7de0120  vmovaps xmm3, [rsp+0x30]
000078d2e7de0126  vmovaps xmm4, [rsp+0x40]
000078d2e7de012c  vmovaps xmm5, [rsp+0x50]
000078d2e7de0132  vmovaps xmm7, [rsp+0x60]
000078d2e7de0138  vmovaps xmm8, [rsp+0x70]
000078d2e7de013e  vmovaps xmm9, [rsp+0x80]
000078d2e7de0147  vmovaps xmm10, [rsp+0x90]
000078d2e7de0150  vmovaps xmm11, [rsp+0xA0]
000078d2e7de0159  vmovaps xmm12, [rsp+0xB0]
000078d2e7de0162  vmovaps xmm13, [rsp+0xC0]
000078d2e7de016b  vmovaps xmm14, [rsp+0xD0]
000078d2e7de0174  vmovaps xmm15, [rsp+0xE0]
000078d2e7de017d  add rsp, 0xF0
000078d2e7de0184  pop r11
000078d2e7de0186  pop r10
000078d2e7de0188  pop r9
000078d2e7de018a  pop r8
000078d2e7de018c  pop rsi
000078d2e7de018d  pop rdi
000078d2e7de018e  pop rdx
000078d2e7de018f  pop rcx
000078d2e7de0190  pop rax
000078d2e7de0191  add rsp, 0x08
000078d2e7de0195  jmp 0x000078D2E7DDEDB4
000078d2e7de019a  sub rsp, 0x08
000078d2e7de019e  push rax
000078d2e7de019f  push rcx
000078d2e7de01a0  push rdx
000078d2e7de01a1  push rdi
000078d2e7de01a2  push rsi
000078d2e7de01a3  push r8
000078d2e7de01a5  push r9
000078d2e7de01a7  push r10
000078d2e7de01a9  push r11
000078d2e7de01ab  sub rsp, 0xF0
000078d2e7de01b2  vmovaps [rsp], xmm0
000078d2e7de01b7  vmovaps [rsp+0x10], xmm1
000078d2e7de01bd  vmovaps [rsp+0x20], xmm2
000078d2e7de01c3  vmovaps [rsp+0x30], xmm4
000078d2e7de01c9  vmovaps [rsp+0x40], xmm5
000078d2e7de01cf  vmovaps [rsp+0x50], xmm6
000078d2e7de01d5  vmovaps [rsp+0x60], xmm7
000078d2e7de01db  vmovaps [rsp+0x70], xmm8
000078d2e7de01e1  vmovaps [rsp+0x80], xmm9
000078d2e7de01ea  vmovaps [rsp+0x90], xmm10
000078d2e7de01f3  vmovaps [rsp+0xA0], xmm11
000078d2e7de01fc  vmovaps [rsp+0xB0], xmm12
000078d2e7de0205  vmovaps [rsp+0xC0], xmm13
000078d2e7de020e  vmovaps [rsp+0xD0], xmm14
000078d2e7de0217  vmovaps [rsp+0xE0], xmm15
000078d2e7de0220  sub rsp, 0x30
000078d2e7de0224  movaps [rsp], xmm3
000078d2e7de0228  movaps [rsp+0x10], xmm5
000078d2e7de022d  movaps [rsp+0x20], xmm4
000078d2e7de0232  lea rdi, [rsp]
000078d2e7de0236  mov esi, 0x00
000078d2e7de023b  mov rax, 0x5997D2DB1530
000078d2e7de0245  call rax
000078d2e7de0247  movaps xmm3, [rsp]
000078d2e7de024b  add rsp, 0x30
000078d2e7de024f  vmovaps xmm0, [rsp]
000078d2e7de0254  vmovaps xmm1, [rsp+0x10]
000078d2e7de025a  vmovaps xmm2, [rsp+0x20]
000078d2e7de0260  vmovaps xmm4, [rsp+0x30]
000078d2e7de0266  vmovaps xmm5, [rsp+0x40]
000078d2e7de026c  vmovaps xmm6, [rsp+0x50]
000078d2e7de0272  vmovaps xmm7, [rsp+0x60]
000078d2e7de0278  vmovaps xmm8, [rsp+0x70]
000078d2e7de027e  vmovaps xmm9, [rsp+0x80]
000078d2e7de0287  vmovaps xmm10, [rsp+0x90]
000078d2e7de0290  vmovaps xmm11, [rsp+0xA0]
000078d2e7de0299  vmovaps xmm12, [rsp+0xB0]
000078d2e7de02a2  vmovaps xmm13, [rsp+0xC0]
000078d2e7de02ab  vmovaps xmm14, [rsp+0xD0]
000078d2e7de02b4  vmovaps xmm15, [rsp+0xE0]
000078d2e7de02bd  add rsp, 0xF0
000078d2e7de02c4  pop r11
000078d2e7de02c6  pop r10
000078d2e7de02c8  pop r9
000078d2e7de02ca  pop r8
000078d2e7de02cc  pop rsi
000078d2e7de02cd  pop rdi
000078d2e7de02ce  pop rdx
000078d2e7de02cf  pop rcx
000078d2e7de02d0  pop rax
000078d2e7de02d1  add rsp, 0x08
000078d2e7de02d5  jmp 0x000078D2E7DDEE15
000078d2e7de02da  sub rsp, 0x08
000078d2e7de02de  push rax
000078d2e7de02df  push rcx
000078d2e7de02e0  push rdx
000078d2e7de02e1  push rdi
000078d2e7de02e2  push rsi
000078d2e7de02e3  push r8
000078d2e7de02e5  push r9
000078d2e7de02e7  push r10
000078d2e7de02e9  push r11
000078d2e7de02eb  sub rsp, 0xF0
000078d2e7de02f2  vmovaps [rsp], xmm0
000078d2e7de02f7  vmovaps [rsp+0x10], xmm1
000078d2e7de02fd  vmovaps [rsp+0x20], xmm2
000078d2e7de0303  vmovaps [rsp+0x30], xmm3
000078d2e7de0309  vmovaps [rsp+0x40], xmm4
000078d2e7de030f  vmovaps [rsp+0x50], xmm6
000078d2e7de0315  vmovaps [rsp+0x60], xmm7
000078d2e7de031b  vmovaps [rsp+0x70], xmm8
000078d2e7de0321  vmovaps [rsp+0x80], xmm9
000078d2e7de032a  vmovaps [rsp+0x90], xmm10
000078d2e7de0333  vmovaps [rsp+0xA0], xmm11
000078d2e7de033c  vmovaps [rsp+0xB0], xmm12
000078d2e7de0345  vmovaps [rsp+0xC0], xmm13
000078d2e7de034e  vmovaps [rsp+0xD0], xmm14
000078d2e7de0357  vmovaps [rsp+0xE0], xmm15
000078d2e7de0360  sub rsp, 0x30
000078d2e7de0364  movaps [rsp], xmm5
000078d2e7de0368  movaps [rsp+0x10], xmm8
000078d2e7de036e  movaps [rsp+0x20], xmm15
000078d2e7de0374  lea rdi, [rsp]
000078d2e7de0378  mov esi, 0x00
000078d2e7de037d  mov rax, 0x5997D2DB1530
000078d2e7de0387  call rax
000078d2e7de0389  movaps xmm5, [rsp]
000078d2e7de038d  add rsp, 0x30
000078d2e7de0391  vmovaps xmm0, [rsp]
000078d2e7de0396  vmovaps xmm1, [rsp+0x10]
000078d2e7de039c  vmovaps xmm2, [rsp+0x20]
000078d2e7de03a2  vmovaps xmm3, [rsp+0x30]
000078d2e7de03a8  vmovaps xmm4, [rsp+0x40]
000078d2e7de03ae  vmovaps xmm6, [rsp+0x50]
000078d2e7de03b4  vmovaps xmm7, [rsp+0x60]
000078d2e7de03ba  vmovaps xmm8, [rsp+0x70]
000078d2e7de03c0  vmovaps xmm9, [rsp+0x80]
000078d2e7de03c9  vmovaps xmm10, [rsp+0x90]
000078d2e7de03d2  vmovaps xmm11, [rsp+0xA0]
000078d2e7de03db  vmovaps xmm12, [rsp+0xB0]
000078d2e7de03e4  vmovaps xmm13, [rsp+0xC0]
000078d2e7de03ed  vmovaps xmm14, [rsp+0xD0]
000078d2e7de03f6  vmovaps xmm15, [rsp+0xE0]
000078d2e7de03ff  add rsp, 0xF0
000078d2e7de0406  pop r11
000078d2e7de0408  pop r10
000078d2e7de040a  pop r9
000078d2e7de040c  pop r8
000078d2e7de040e  pop rsi
000078d2e7de040f  pop rdi
000078d2e7de0410  pop rdx
000078d2e7de0411  pop rcx
000078d2e7de0412  pop rax
000078d2e7de0413  add rsp, 0x08
000078d2e7de0417  jmp 0x000078D2E7DDEE53
000078d2e7de041c  sub rsp, 0x08
000078d2e7de0420  push rax
000078d2e7de0421  push rcx
000078d2e7de0422  push rdx
000078d2e7de0423  push rdi
000078d2e7de0424  push rsi
000078d2e7de0425  push r8
000078d2e7de0427  push r9
000078d2e7de0429  push r10
000078d2e7de042b  push r11
000078d2e7de042d  sub rsp, 0xF0
000078d2e7de0434  vmovaps [rsp], xmm0
000078d2e7de0439  vmovaps [rsp+0x10], xmm1
000078d2e7de043f  vmovaps [rsp+0x20], xmm2
000078d2e7de0445  vmovaps [rsp+0x30], xmm3
000078d2e7de044b  vmovaps [rsp+0x40], xmm5
000078d2e7de0451  vmovaps [rsp+0x50], xmm6
000078d2e7de0457  vmovaps [rsp+0x60], xmm7
000078d2e7de045d  vmovaps [rsp+0x70], xmm8
000078d2e7de0463  vmovaps [rsp+0x80], xmm9
000078d2e7de046c  vmovaps [rsp+0x90], xmm10
000078d2e7de0475  vmovaps [rsp+0xA0], xmm11
000078d2e7de047e  vmovaps [rsp+0xB0], xmm12
000078d2e7de0487  vmovaps [rsp+0xC0], xmm13
000078d2e7de0490  vmovaps [rsp+0xD0], xmm14
000078d2e7de0499  vmovaps [rsp+0xE0], xmm15
000078d2e7de04a2  sub rsp, 0x30
000078d2e7de04a6  movaps [rsp], xmm4
000078d2e7de04aa  movaps [rsp+0x10], xmm9
000078d2e7de04b0  movaps [rsp+0x20], xmm8
000078d2e7de04b6  lea rdi, [rsp]
000078d2e7de04ba  mov esi, 0x00
000078d2e7de04bf  mov rax, 0x5997D2DB1530
000078d2e7de04c9  call rax
000078d2e7de04cb  movaps xmm4, [rsp]
000078d2e7de04cf  add rsp, 0x30
000078d2e7de04d3  vmovaps xmm0, [rsp]
000078d2e7de04d8  vmovaps xmm1, [rsp+0x10]
000078d2e7de04de  vmovaps xmm2, [rsp+0x20]
000078d2e7de04e4  vmovaps xmm3, [rsp+0x30]
000078d2e7de04ea  vmovaps xmm5, [rsp+0x40]
000078d2e7de04f0  vmovaps xmm6, [rsp+0x50]
000078d2e7de04f6  vmovaps xmm7, [rsp+0x60]
000078d2e7de04fc  vmovaps xmm8, [rsp+0x70]
000078d2e7de0502  vmovaps xmm9, [rsp+0x80]
000078d2e7de050b  vmovaps xmm10, [rsp+0x90]
000078d2e7de0514  vmovaps xmm11, [rsp+0xA0]
000078d2e7de051d  vmovaps xmm12, [rsp+0xB0]
000078d2e7de0526  vmovaps xmm13, [rsp+0xC0]
000078d2e7de052f  vmovaps xmm14, [rsp+0xD0]
000078d2e7de0538  vmovaps xmm15, [rsp+0xE0]
000078d2e7de0541  add rsp, 0xF0
000078d2e7de0548  pop r11
000078d2e7de054a  pop r10
000078d2e7de054c  pop r9
000078d2e7de054e  pop r8
000078d2e7de0550  pop rsi
000078d2e7de0551  pop rdi
000078d2e7de0552  pop rdx
000078d2e7de0553  pop rcx
000078d2e7de0554  pop rax
000078d2e7de0555  add rsp, 0x08
000078d2e7de0559  jmp 0x000078D2E7DDEE74
000078d2e7de055e  sub rsp, 0x08
000078d2e7de0562  push rax
000078d2e7de0563  push rcx
000078d2e7de0564  push rdx
000078d2e7de0565  push rdi
000078d2e7de0566  push rsi
000078d2e7de0567  push r8
000078d2e7de0569  push r9
000078d2e7de056b  push r10
000078d2e7de056d  push r11
000078d2e7de056f  sub rsp, 0xF0
000078d2e7de0576  vmovaps [rsp], xmm0
000078d2e7de057b  vmovaps [rsp+0x10], xmm1
000078d2e7de0581  vmovaps [rsp+0x20], xmm2
000078d2e7de0587  vmovaps [rsp+0x30], xmm3
000078d2e7de058d  vmovaps [rsp+0x40], xmm4
000078d2e7de0593  vmovaps [rsp+0x50], xmm5
000078d2e7de0599  vmovaps [rsp+0x60], xmm6
000078d2e7de059f  vmovaps [rsp+0x70], xmm7
000078d2e7de05a5  vmovaps [rsp+0x80], xmm8
000078d2e7de05ae  vmovaps [rsp+0x90], xmm10
000078d2e7de05b7  vmovaps [rsp+0xA0], xmm11
000078d2e7de05c0  vmovaps [rsp+0xB0], xmm12
000078d2e7de05c9  vmovaps [rsp+0xC0], xmm13
000078d2e7de05d2  vmovaps [rsp+0xD0], xmm14
000078d2e7de05db  vmovaps [rsp+0xE0], xmm15
000078d2e7de05e4  sub rsp, 0x30
000078d2e7de05e8  movaps [rsp], xmm9
000078d2e7de05ed  movaps [rsp+0x10], xmm10
000078d2e7de05f3  movaps [rsp+0x20], xmm8
000078d2e7de05f9  lea rdi, [rsp]
000078d2e7de05fd  mov esi, 0x00
000078d2e7de0602  mov rax, 0x5997D2DB1530
000078d2e7de060c  call rax
000078d2e7de060e  movaps xmm9, [rsp]
000078d2e7de0613  add rsp, 0x30
000078d2e7de0617  vmovaps xmm0, [rsp]
000078d2e7de061c  vmovaps xmm1, [rsp+0x10]
000078d2e7de0622  vmovaps xmm2, [rsp+0x20]
000078d2e7de0628  vmovaps xmm3, [rsp+0x30]
000078d2e7de062e  vmovaps xmm4, [rsp+0x40]
000078d2e7de0634  vmovaps xmm5, [rsp+0x50]
000078d2e7de063a  vmovaps xmm6, [rsp+0x60]
000078d2e7de0640  vmovaps xmm7, [rsp+0x70]
000078d2e7de0646  vmovaps xmm8, [rsp+0x80]
000078d2e7de064f  vmovaps xmm10, [rsp+0x90]
000078d2e7de0658  vmovaps xmm11, [rsp+0xA0]
000078d2e7de0661  vmovaps xmm12, [rsp+0xB0]
000078d2e7de066a  vmovaps xmm13, [rsp+0xC0]
000078d2e7de0673  vmovaps xmm14, [rsp+0xD0]
000078d2e7de067c  vmovaps xmm15, [rsp+0xE0]
000078d2e7de0685  add rsp, 0xF0
000078d2e7de068c  pop r11
000078d2e7de068e  pop r10
000078d2e7de0690  pop r9
000078d2e7de0692  pop r8
000078d2e7de0694  pop rsi
000078d2e7de0695  pop rdi
000078d2e7de0696  pop rdx
000078d2e7de0697  pop rcx
000078d2e7de0698  pop rax
000078d2e7de0699  add rsp, 0x08
000078d2e7de069d  jmp 0x000078D2E7DDEE8E
000078d2e7de06a2  call 0x000078D2E7CB52F0
000078d2e7de06a7  jmp 0x000078D2E7DDEFA8
000078d2e7de06ac  call 0x000078D2E7CB52F0
000078d2e7de06b1  jmp 0x000078D2E7DDEFBE
000078d2e7de06b6  sub rsp, 0x08
000078d2e7de06ba  push rax
000078d2e7de06bb  push rcx
000078d2e7de06bc  push rdx
000078d2e7de06bd  push rdi
000078d2e7de06be  push rsi
000078d2e7de06bf  push r8
000078d2e7de06c1  push r9
000078d2e7de06c3  push r10
000078d2e7de06c5  push r11
000078d2e7de06c7  sub rsp, 0xF0
000078d2e7de06ce  vmovaps [rsp], xmm0
000078d2e7de06d3  vmovaps [rsp+0x10], xmm2
000078d2e7de06d9  vmovaps [rsp+0x20], xmm3
000078d2e7de06df  vmovaps [rsp+0x30], xmm4
000078d2e7de06e5  vmovaps [rsp+0x40], xmm5
000078d2e7de06eb  vmovaps [rsp+0x50], xmm6
000078d2e7de06f1  vmovaps [rsp+0x60], xmm7
000078d2e7de06f7  vmovaps [rsp+0x70], xmm8
000078d2e7de06fd  vmovaps [rsp+0x80], xmm9
000078d2e7de0706  vmovaps [rsp+0x90], xmm10
000078d2e7de070f  vmovaps [rsp+0xA0], xmm11
000078d2e7de0718  vmovaps [rsp+0xB0], xmm12
000078d2e7de0721  vmovaps [rsp+0xC0], xmm13
000078d2e7de072a  vmovaps [rsp+0xD0], xmm14
000078d2e7de0733  vmovaps [rsp+0xE0], xmm15
000078d2e7de073c  sub rsp, 0x30
000078d2e7de0740  movaps [rsp], xmm1
000078d2e7de0744  movaps [rsp+0x10], xmm6
000078d2e7de0749  movaps [rsp+0x20], xmm15
000078d2e7de074f  lea rdi, [rsp]
000078d2e7de0753  mov esi, 0x00
000078d2e7de0758  mov rax, 0x5997D2DB1530
000078d2e7de0762  call rax
000078d2e7de0764  movaps xmm1, [rsp]
000078d2e7de0768  add rsp, 0x30
000078d2e7de076c  vmovaps xmm0, [rsp]
000078d2e7de0771  vmovaps xmm2, [rsp+0x10]
000078d2e7de0777  vmovaps xmm3, [rsp+0x20]
000078d2e7de077d  vmovaps xmm4, [rsp+0x30]
000078d2e7de0783  vmovaps xmm5, [rsp+0x40]
000078d2e7de0789  vmovaps xmm6, [rsp+0x50]
000078d2e7de078f  vmovaps xmm7, [rsp+0x60]
000078d2e7de0795  vmovaps xmm8, [rsp+0x70]
000078d2e7de079b  vmovaps xmm9, [rsp+0x80]
000078d2e7de07a4  vmovaps xmm10, [rsp+0x90]
000078d2e7de07ad  vmovaps xmm11, [rsp+0xA0]
000078d2e7de07b6  vmovaps xmm12, [rsp+0xB0]
000078d2e7de07bf  vmovaps xmm13, [rsp+0xC0]
000078d2e7de07c8  vmovaps xmm14, [rsp+0xD0]
000078d2e7de07d1  vmovaps xmm15, [rsp+0xE0]
000078d2e7de07da  add rsp, 0xF0
000078d2e7de07e1  pop r11
000078d2e7de07e3  pop r10
000078d2e7de07e5  pop r9
000078d2e7de07e7  pop r8
000078d2e7de07e9  pop rsi
000078d2e7de07ea  pop rdi
000078d2e7de07eb  pop rdx
000078d2e7de07ec  pop rcx
000078d2e7de07ed  pop rax
000078d2e7de07ee  add rsp, 0x08
000078d2e7de07f2  jmp 0x000078D2E7DDEFFB
000078d2e7de07f7  call 0x000078D2E7CC4620
000078d2e7de07fc  jmp 0x000078D2E7DDF008
000078d2e7de0801  sub rsp, 0x08
000078d2e7de0805  push rax
000078d2e7de0806  push rcx
000078d2e7de0807  push rdx
000078d2e7de0808  push rdi
000078d2e7de0809  push rsi
000078d2e7de080a  push r8
000078d2e7de080c  push r9
000078d2e7de080e  push r10
000078d2e7de0810  push r11
000078d2e7de0812  sub rsp, 0xF0
000078d2e7de0819  vmovaps [rsp], xmm0
000078d2e7de081e  vmovaps [rsp+0x10], xmm1
000078d2e7de0824  vmovaps [rsp+0x20], xmm2
000078d2e7de082a  vmovaps [rsp+0x30], xmm3
000078d2e7de0830  vmovaps [rsp+0x40], xmm4
000078d2e7de0836  vmovaps [rsp+0x50], xmm5
000078d2e7de083c  vmovaps [rsp+0x60], xmm6
000078d2e7de0842  vmovaps [rsp+0x70], xmm7
000078d2e7de0848  vmovaps [rsp+0x80], xmm8
000078d2e7de0851  vmovaps [rsp+0x90], xmm9
000078d2e7de085a  vmovaps [rsp+0xA0], xmm10
000078d2e7de0863  vmovaps [rsp+0xB0], xmm11
000078d2e7de086c  vmovaps [rsp+0xC0], xmm12
000078d2e7de0875  vmovaps [rsp+0xD0], xmm13
000078d2e7de087e  vmovaps [rsp+0xE0], xmm15
000078d2e7de0887  sub rsp, 0x30
000078d2e7de088b  movaps [rsp], xmm14
000078d2e7de0890  movaps [rsp+0x10], xmm4
000078d2e7de0895  movaps [rsp+0x20], xmm3
000078d2e7de089a  lea rdi, [rsp]
000078d2e7de089e  mov esi, 0x00
000078d2e7de08a3  mov rax, 0x5997D2DB1530
000078d2e7de08ad  call rax
000078d2e7de08af  movaps xmm14, [rsp]
000078d2e7de08b4  add rsp, 0x30
000078d2e7de08b8  vmovaps xmm0, [rsp]
000078d2e7de08bd  vmovaps xmm1, [rsp+0x10]
000078d2e7de08c3  vmovaps xmm2, [rsp+0x20]
000078d2e7de08c9  vmovaps xmm3, [rsp+0x30]
000078d2e7de08cf  vmovaps xmm4, [rsp+0x40]
000078d2e7de08d5  vmovaps xmm5, [rsp+0x50]
000078d2e7de08db  vmovaps xmm6, [rsp+0x60]
000078d2e7de08e1  vmovaps xmm7, [rsp+0x70]
000078d2e7de08e7  vmovaps xmm8, [rsp+0x80]
000078d2e7de08f0  vmovaps xmm9, [rsp+0x90]
000078d2e7de08f9  vmovaps xmm10, [rsp+0xA0]
000078d2e7de0902  vmovaps xmm11, [rsp+0xB0]
000078d2e7de090b  vmovaps xmm12, [rsp+0xC0]
000078d2e7de0914  vmovaps xmm13, [rsp+0xD0]
000078d2e7de091d  vmovaps xmm15, [rsp+0xE0]
000078d2e7de0926  add rsp, 0xF0
000078d2e7de092d  pop r11
000078d2e7de092f  pop r10
000078d2e7de0931  pop r9
000078d2e7de0933  pop r8
000078d2e7de0935  pop rsi
000078d2e7de0936  pop rdi
000078d2e7de0937  pop rdx
000078d2e7de0938  pop rcx
000078d2e7de0939  pop rax
000078d2e7de093a  add rsp, 0x08
000078d2e7de093e  jmp 0x000078D2E7DDF022
000078d2e7de0943  sub rsp, 0x08
000078d2e7de0947  push rax
000078d2e7de0948  push rcx
000078d2e7de0949  push rdx
000078d2e7de094a  push rdi
000078d2e7de094b  push rsi
000078d2e7de094c  push r8
000078d2e7de094e  push r9
000078d2e7de0950  push r10
000078d2e7de0952  push r11
000078d2e7de0954  sub rsp, 0xF0
000078d2e7de095b  vmovaps [rsp], xmm0
000078d2e7de0960  vmovaps [rsp+0x10], xmm1
000078d2e7de0966  vmovaps [rsp+0x20], xmm2
000078d2e7de096c  vmovaps [rsp+0x30], xmm3
000078d2e7de0972  vmovaps [rsp+0x40], xmm4
000078d2e7de0978  vmovaps [rsp+0x50], xmm5
000078d2e7de097e  vmovaps [rsp+0x60], xmm7
000078d2e7de0984  vmovaps [rsp+0x70], xmm8
000078d2e7de098a  vmovaps [rsp+0x80], xmm9
000078d2e7de0993  vmovaps [rsp+0x90], xmm10
000078d2e7de099c  vmovaps [rsp+0xA0], xmm11
000078d2e7de09a5  vmovaps [rsp+0xB0], xmm12
000078d2e7de09ae  vmovaps [rsp+0xC0], xmm13
000078d2e7de09b7  vmovaps [rsp+0xD0], xmm14
000078d2e7de09c0  vmovaps [rsp+0xE0], xmm15
000078d2e7de09c9  sub rsp, 0x30
000078d2e7de09cd  movaps [rsp], xmm6
000078d2e7de09d1  movaps [rsp+0x10], xmm9
000078d2e7de09d7  movaps [rsp+0x20], xmm7
000078d2e7de09dc  lea rdi, [rsp]
000078d2e7de09e0  mov esi, 0x00
000078d2e7de09e5  mov rax, 0x5997D2DB1530
000078d2e7de09ef  call rax
000078d2e7de09f1  movaps xmm6, [rsp]
000078d2e7de09f5  add rsp, 0x30
000078d2e7de09f9  vmovaps xmm0, [rsp]
000078d2e7de09fe  vmovaps xmm1, [rsp+0x10]
000078d2e7de0a04  vmovaps xmm2, [rsp+0x20]
000078d2e7de0a0a  vmovaps xmm3, [rsp+0x30]
000078d2e7de0a10  vmovaps xmm4, [rsp+0x40]
000078d2e7de0a16  vmovaps xmm5, [rsp+0x50]
000078d2e7de0a1c  vmovaps xmm7, [rsp+0x60]
000078d2e7de0a22  vmovaps xmm8, [rsp+0x70]
000078d2e7de0a28  vmovaps xmm9, [rsp+0x80]
000078d2e7de0a31  vmovaps xmm10, [rsp+0x90]
000078d2e7de0a3a  vmovaps xmm11, [rsp+0xA0]
000078d2e7de0a43  vmovaps xmm12, [rsp+0xB0]
000078d2e7de0a4c  vmovaps xmm13, [rsp+0xC0]
000078d2e7de0a55  vmovaps xmm14, [rsp+0xD0]
000078d2e7de0a5e  vmovaps xmm15, [rsp+0xE0]
000078d2e7de0a67  add rsp, 0xF0
000078d2e7de0a6e  pop r11
000078d2e7de0a70  pop r10
000078d2e7de0a72  pop r9
000078d2e7de0a74  pop r8
000078d2e7de0a76  pop rsi
000078d2e7de0a77  pop rdi
000078d2e7de0a78  pop rdx
000078d2e7de0a79  pop rcx
000078d2e7de0a7a  pop rax
000078d2e7de0a7b  add rsp, 0x08
000078d2e7de0a7f  jmp 0x000078D2E7DDF03A
000078d2e7de0a84  sub rsp, 0x08
000078d2e7de0a88  push rax
000078d2e7de0a89  push rcx
000078d2e7de0a8a  push rdx
000078d2e7de0a8b  push rdi
000078d2e7de0a8c  push rsi
000078d2e7de0a8d  push r8
000078d2e7de0a8f  push r9
000078d2e7de0a91  push r10
000078d2e7de0a93  push r11
000078d2e7de0a95  sub rsp, 0xF0
000078d2e7de0a9c  vmovaps [rsp], xmm0
000078d2e7de0aa1  vmovaps [rsp+0x10], xmm1
000078d2e7de0aa7  vmovaps [rsp+0x20], xmm2
000078d2e7de0aad  vmovaps [rsp+0x30], xmm3
000078d2e7de0ab3  vmovaps [rsp+0x40], xmm4
000078d2e7de0ab9  vmovaps [rsp+0x50], xmm5
000078d2e7de0abf  vmovaps [rsp+0x60], xmm6
000078d2e7de0ac5  vmovaps [rsp+0x70], xmm8
000078d2e7de0acb  vmovaps [rsp+0x80], xmm9
000078d2e7de0ad4  vmovaps [rsp+0x90], xmm10
000078d2e7de0add  vmovaps [rsp+0xA0], xmm11
000078d2e7de0ae6  vmovaps [rsp+0xB0], xmm12
000078d2e7de0aef  vmovaps [rsp+0xC0], xmm13
000078d2e7de0af8  vmovaps [rsp+0xD0], xmm14
000078d2e7de0b01  vmovaps [rsp+0xE0], xmm15
000078d2e7de0b0a  sub rsp, 0x30
000078d2e7de0b0e  movaps [rsp], xmm7
000078d2e7de0b12  movaps [rsp+0x10], xmm4
000078d2e7de0b17  movaps [rsp+0x20], xmm9
000078d2e7de0b1d  lea rdi, [rsp]
000078d2e7de0b21  mov esi, 0x00
000078d2e7de0b26  mov rax, 0x5997D2DB1530
000078d2e7de0b30  call rax
000078d2e7de0b32  movaps xmm7, [rsp]
000078d2e7de0b36  add rsp, 0x30
000078d2e7de0b3a  vmovaps xmm0, [rsp]
000078d2e7de0b3f  vmovaps xmm1, [rsp+0x10]
000078d2e7de0b45  vmovaps xmm2, [rsp+0x20]
000078d2e7de0b4b  vmovaps xmm3, [rsp+0x30]
000078d2e7de0b51  vmovaps xmm4, [rsp+0x40]
000078d2e7de0b57  vmovaps xmm5, [rsp+0x50]
000078d2e7de0b5d  vmovaps xmm6, [rsp+0x60]
000078d2e7de0b63  vmovaps xmm8, [rsp+0x70]
000078d2e7de0b69  vmovaps xmm9, [rsp+0x80]
000078d2e7de0b72  vmovaps xmm10, [rsp+0x90]
000078d2e7de0b7b  vmovaps xmm11, [rsp+0xA0]
000078d2e7de0b84  vmovaps xmm12, [rsp+0xB0]
000078d2e7de0b8d  vmovaps xmm13, [rsp+0xC0]
000078d2e7de0b96  vmovaps xmm14, [rsp+0xD0]
000078d2e7de0b9f  vmovaps xmm15, [rsp+0xE0]
000078d2e7de0ba8  add rsp, 0xF0
000078d2e7de0baf  pop r11
000078d2e7de0bb1  pop r10
000078d2e7de0bb3  pop r9
000078d2e7de0bb5  pop r8
000078d2e7de0bb7  pop rsi
000078d2e7de0bb8  pop rdi
000078d2e7de0bb9  pop rdx
000078d2e7de0bba  pop rcx
000078d2e7de0bbb  pop rax
000078d2e7de0bbc  add rsp, 0x08
000078d2e7de0bc0  jmp 0x000078D2E7DDF067
000078d2e7de0bc5  sub rsp, 0x08
000078d2e7de0bc9  push rax
000078d2e7de0bca  push rcx
000078d2e7de0bcb  push rdx
000078d2e7de0bcc  push rdi
000078d2e7de0bcd  push rsi
000078d2e7de0bce  push r8
000078d2e7de0bd0  push r9
000078d2e7de0bd2  push r10
000078d2e7de0bd4  push r11
000078d2e7de0bd6  sub rsp, 0xF0
000078d2e7de0bdd  vmovaps [rsp], xmm0
000078d2e7de0be2  vmovaps [rsp+0x10], xmm1
000078d2e7de0be8  vmovaps [rsp+0x20], xmm2
000078d2e7de0bee  vmovaps [rsp+0x30], xmm3
000078d2e7de0bf4  vmovaps [rsp+0x40], xmm5
000078d2e7de0bfa  vmovaps [rsp+0x50], xmm6
000078d2e7de0c00  vmovaps [rsp+0x60], xmm7
000078d2e7de0c06  vmovaps [rsp+0x70], xmm8
000078d2e7de0c0c  vmovaps [rsp+0x80], xmm9
000078d2e7de0c15  vmovaps [rsp+0x90], xmm10
000078d2e7de0c1e  vmovaps [rsp+0xA0], xmm11
000078d2e7de0c27  vmovaps [rsp+0xB0], xmm12
000078d2e7de0c30  vmovaps [rsp+0xC0], xmm13
000078d2e7de0c39  vmovaps [rsp+0xD0], xmm14
000078d2e7de0c42  vmovaps [rsp+0xE0], xmm15
000078d2e7de0c4b  sub rsp, 0x30
000078d2e7de0c4f  movaps [rsp], xmm4
000078d2e7de0c53  movaps [rsp+0x10], xmm15
000078d2e7de0c59  movaps [rsp+0x20], xmm9
000078d2e7de0c5f  lea rdi, [rsp]
000078d2e7de0c63  mov esi, 0x00
000078d2e7de0c68  mov rax, 0x5997D2DB1530
000078d2e7de0c72  call rax
000078d2e7de0c74  movaps xmm4, [rsp]
000078d2e7de0c78  add rsp, 0x30
000078d2e7de0c7c  vmovaps xmm0, [rsp]
000078d2e7de0c81  vmovaps xmm1, [rsp+0x10]
000078d2e7de0c87  vmovaps xmm2, [rsp+0x20]
000078d2e7de0c8d  vmovaps xmm3, [rsp+0x30]
000078d2e7de0c93  vmovaps xmm5, [rsp+0x40]
000078d2e7de0c99  vmovaps xmm6, [rsp+0x50]
000078d2e7de0c9f  vmovaps xmm7, [rsp+0x60]
000078d2e7de0ca5  vmovaps xmm8, [rsp+0x70]
000078d2e7de0cab  vmovaps xmm9, [rsp+0x80]
000078d2e7de0cb4  vmovaps xmm10, [rsp+0x90]
000078d2e7de0cbd  vmovaps xmm11, [rsp+0xA0]
000078d2e7de0cc6  vmovaps xmm12, [rsp+0xB0]
000078d2e7de0ccf  vmovaps xmm13, [rsp+0xC0]
000078d2e7de0cd8  vmovaps xmm14, [rsp+0xD0]
000078d2e7de0ce1  vmovaps xmm15, [rsp+0xE0]
000078d2e7de0cea  add rsp, 0xF0
000078d2e7de0cf1  pop r11
000078d2e7de0cf3  pop r10
000078d2e7de0cf5  pop r9
000078d2e7de0cf7  pop r8
000078d2e7de0cf9  pop rsi
000078d2e7de0cfa  pop rdi
000078d2e7de0cfb  pop rdx
000078d2e7de0cfc  pop rcx
000078d2e7de0cfd  pop rax
000078d2e7de0cfe  add rsp, 0x08
000078d2e7de0d02  jmp 0x000078D2E7DDF08C
000078d2e7de0d07  call 0x000078D2E7CC4620
000078d2e7de0d0c  jmp 0x000078D2E7DDF099
000078d2e7de0d11  sub rsp, 0x08
000078d2e7de0d15  push rax
000078d2e7de0d16  push rcx
000078d2e7de0d17  push rdx
000078d2e7de0d18  push rdi
000078d2e7de0d19  push rsi
000078d2e7de0d1a  push r8
000078d2e7de0d1c  push r9
000078d2e7de0d1e  push r10
000078d2e7de0d20  push r11
000078d2e7de0d22  sub rsp, 0xF0
000078d2e7de0d29  vmovaps [rsp], xmm0
000078d2e7de0d2e  vmovaps [rsp+0x10], xmm1
000078d2e7de0d34  vmovaps [rsp+0x20], xmm2
000078d2e7de0d3a  vmovaps [rsp+0x30], xmm4
000078d2e7de0d40  vmovaps [rsp+0x40], xmm5
000078d2e7de0d46  vmovaps [rsp+0x50], xmm6
000078d2e7de0d4c  vmovaps [rsp+0x60], xmm7
000078d2e7de0d52  vmovaps [rsp+0x70], xmm8
000078d2e7de0d58  vmovaps [rsp+0x80], xmm9
000078d2e7de0d61  vmovaps [rsp+0x90], xmm10
000078d2e7de0d6a  vmovaps [rsp+0xA0], xmm11
000078d2e7de0d73  vmovaps [rsp+0xB0], xmm12
000078d2e7de0d7c  vmovaps [rsp+0xC0], xmm13
000078d2e7de0d85  vmovaps [rsp+0xD0], xmm14
000078d2e7de0d8e  vmovaps [rsp+0xE0], xmm15
000078d2e7de0d97  sub rsp, 0x30
000078d2e7de0d9b  movaps [rsp], xmm3
000078d2e7de0d9f  movaps [rsp+0x10], xmm1
000078d2e7de0da4  movaps [rsp+0x20], xmm9
000078d2e7de0daa  lea rdi, [rsp]
000078d2e7de0dae  mov esi, 0x00
000078d2e7de0db3  mov rax, 0x5997D2DB1530
000078d2e7de0dbd  call rax
000078d2e7de0dbf  movaps xmm3, [rsp]
000078d2e7de0dc3  add rsp, 0x30
000078d2e7de0dc7  vmovaps xmm0, [rsp]
000078d2e7de0dcc  vmovaps xmm1, [rsp+0x10]
000078d2e7de0dd2  vmovaps xmm2, [rsp+0x20]
000078d2e7de0dd8  vmovaps xmm4, [rsp+0x30]
000078d2e7de0dde  vmovaps xmm5, [rsp+0x40]
000078d2e7de0de4  vmovaps xmm6, [rsp+0x50]
000078d2e7de0dea  vmovaps xmm7, [rsp+0x60]
000078d2e7de0df0  vmovaps xmm8, [rsp+0x70]
000078d2e7de0df6  vmovaps xmm9, [rsp+0x80]
000078d2e7de0dff  vmovaps xmm10, [rsp+0x90]
000078d2e7de0e08  vmovaps xmm11, [rsp+0xA0]
000078d2e7de0e11  vmovaps xmm12, [rsp+0xB0]
000078d2e7de0e1a  vmovaps xmm13, [rsp+0xC0]
000078d2e7de0e23  vmovaps xmm14, [rsp+0xD0]
000078d2e7de0e2c  vmovaps xmm15, [rsp+0xE0]
000078d2e7de0e35  add rsp, 0xF0
000078d2e7de0e3c  pop r11
000078d2e7de0e3e  pop r10
000078d2e7de0e40  pop r9
000078d2e7de0e42  pop r8
000078d2e7de0e44  pop rsi
000078d2e7de0e45  pop rdi
000078d2e7de0e46  pop rdx
000078d2e7de0e47  pop rcx
000078d2e7de0e48  pop rax
000078d2e7de0e49  add rsp, 0x08
000078d2e7de0e4d  jmp 0x000078D2E7DDF0D6
000078d2e7de0e52  sub rsp, 0x08
000078d2e7de0e56  push rax
000078d2e7de0e57  push rcx
000078d2e7de0e58  push rdx
000078d2e7de0e59  push rdi
000078d2e7de0e5a  push rsi
000078d2e7de0e5b  push r8
000078d2e7de0e5d  push r9
000078d2e7de0e5f  push r10
000078d2e7de0e61  push r11
000078d2e7de0e63  sub rsp, 0xF0
000078d2e7de0e6a  vmovaps [rsp], xmm0
000078d2e7de0e6f  vmovaps [rsp+0x10], xmm2
000078d2e7de0e75  vmovaps [rsp+0x20], xmm3
000078d2e7de0e7b  vmovaps [rsp+0x30], xmm4
000078d2e7de0e81  vmovaps [rsp+0x40], xmm5
000078d2e7de0e87  vmovaps [rsp+0x50], xmm6
000078d2e7de0e8d  vmovaps [rsp+0x60], xmm7
000078d2e7de0e93  vmovaps [rsp+0x70], xmm8
000078d2e7de0e99  vmovaps [rsp+0x80], xmm9
000078d2e7de0ea2  vmovaps [rsp+0x90], xmm10
000078d2e7de0eab  vmovaps [rsp+0xA0], xmm11
000078d2e7de0eb4  vmovaps [rsp+0xB0], xmm12
000078d2e7de0ebd  vmovaps [rsp+0xC0], xmm13
000078d2e7de0ec6  vmovaps [rsp+0xD0], xmm14
000078d2e7de0ecf  vmovaps [rsp+0xE0], xmm15
000078d2e7de0ed8  sub rsp, 0x30
000078d2e7de0edc  movaps [rsp], xmm1
000078d2e7de0ee0  movaps [rsp+0x10], xmm15
000078d2e7de0ee6  movaps [rsp+0x20], xmm9
000078d2e7de0eec  lea rdi, [rsp]
000078d2e7de0ef0  mov esi, 0x00
000078d2e7de0ef5  mov rax, 0x5997D2DB1530
000078d2e7de0eff  call rax
000078d2e7de0f01  movaps xmm1, [rsp]
000078d2e7de0f05  add rsp, 0x30
000078d2e7de0f09  vmovaps xmm0, [rsp]
000078d2e7de0f0e  vmovaps xmm2, [rsp+0x10]
000078d2e7de0f14  vmovaps xmm3, [rsp+0x20]
000078d2e7de0f1a  vmovaps xmm4, [rsp+0x30]
000078d2e7de0f20  vmovaps xmm5, [rsp+0x40]
000078d2e7de0f26  vmovaps xmm6, [rsp+0x50]
000078d2e7de0f2c  vmovaps xmm7, [rsp+0x60]
000078d2e7de0f32  vmovaps xmm8, [rsp+0x70]
000078d2e7de0f38  vmovaps xmm9, [rsp+0x80]
000078d2e7de0f41  vmovaps xmm10, [rsp+0x90]
000078d2e7de0f4a  vmovaps xmm11, [rsp+0xA0]
000078d2e7de0f53  vmovaps xmm12, [rsp+0xB0]
000078d2e7de0f5c  vmovaps xmm13, [rsp+0xC0]
000078d2e7de0f65  vmovaps xmm14, [rsp+0xD0]
000078d2e7de0f6e  vmovaps xmm15, [rsp+0xE0]
000078d2e7de0f77  add rsp, 0xF0
000078d2e7de0f7e  pop r11
000078d2e7de0f80  pop r10
000078d2e7de0f82  pop r9
000078d2e7de0f84  pop r8
000078d2e7de0f86  pop rsi
000078d2e7de0f87  pop rdi
000078d2e7de0f88  pop rdx
000078d2e7de0f89  pop rcx
000078d2e7de0f8a  pop rax
000078d2e7de0f8b  add rsp, 0x08
000078d2e7de0f8f  jmp 0x000078D2E7DDF15E
000078d2e7de0f94  call 0x000078D2E7CC4620
000078d2e7de0f99  jmp 0x000078D2E7DDF16B
000078d2e7de0f9e  sub rsp, 0x08
000078d2e7de0fa2  push rax
000078d2e7de0fa3  push rcx
000078d2e7de0fa4  push rdx
000078d2e7de0fa5  push rdi
000078d2e7de0fa6  push rsi
000078d2e7de0fa7  push r8
000078d2e7de0fa9  push r9
000078d2e7de0fab  push r10
000078d2e7de0fad  push r11
000078d2e7de0faf  sub rsp, 0xF0
000078d2e7de0fb6  vmovaps [rsp], xmm0
000078d2e7de0fbb  vmovaps [rsp+0x10], xmm2
000078d2e7de0fc1  vmovaps [rsp+0x20], xmm3
000078d2e7de0fc7  vmovaps [rsp+0x30], xmm4
000078d2e7de0fcd  vmovaps [rsp+0x40], xmm5
000078d2e7de0fd3  vmovaps [rsp+0x50], xmm6
000078d2e7de0fd9  vmovaps [rsp+0x60], xmm7
000078d2e7de0fdf  vmovaps [rsp+0x70], xmm8
000078d2e7de0fe5  vmovaps [rsp+0x80], xmm9
000078d2e7de0fee  vmovaps [rsp+0x90], xmm10
000078d2e7de0ff7  vmovaps [rsp+0xA0], xmm11
000078d2e7de1000  vmovaps [rsp+0xB0], xmm12
000078d2e7de1009  vmovaps [rsp+0xC0], xmm13
000078d2e7de1012  vmovaps [rsp+0xD0], xmm14
000078d2e7de101b  vmovaps [rsp+0xE0], xmm15
000078d2e7de1024  sub rsp, 0x30
000078d2e7de1028  movaps [rsp], xmm1
000078d2e7de102c  movaps [rsp+0x10], xmm5
000078d2e7de1031  movaps [rsp+0x20], xmm7
000078d2e7de1036  lea rdi, [rsp]
000078d2e7de103a  mov esi, 0x00
000078d2e7de103f  mov rax, 0x5997D2DB1530
000078d2e7de1049  call rax
000078d2e7de104b  movaps xmm1, [rsp]
000078d2e7de104f  add rsp, 0x30
000078d2e7de1053  vmovaps xmm0, [rsp]
000078d2e7de1058  vmovaps xmm2, [rsp+0x10]
000078d2e7de105e  vmovaps xmm3, [rsp+0x20]
000078d2e7de1064  vmovaps xmm4, [rsp+0x30]
000078d2e7de106a  vmovaps xmm5, [rsp+0x40]
000078d2e7de1070  vmovaps xmm6, [rsp+0x50]
000078d2e7de1076  vmovaps xmm7, [rsp+0x60]
000078d2e7de107c  vmovaps xmm8, [rsp+0x70]
000078d2e7de1082  vmovaps xmm9, [rsp+0x80]
000078d2e7de108b  vmovaps xmm10, [rsp+0x90]
000078d2e7de1094  vmovaps xmm11, [rsp+0xA0]
000078d2e7de109d  vmovaps xmm12, [rsp+0xB0]
000078d2e7de10a6  vmovaps xmm13, [rsp+0xC0]
000078d2e7de10af  vmovaps xmm14, [rsp+0xD0]
000078d2e7de10b8  vmovaps xmm15, [rsp+0xE0]
000078d2e7de10c1  add rsp, 0xF0
000078d2e7de10c8  pop r11
000078d2e7de10ca  pop r10
000078d2e7de10cc  pop r9
000078d2e7de10ce  pop r8
000078d2e7de10d0  pop rsi
000078d2e7de10d1  pop rdi
000078d2e7de10d2  pop rdx
000078d2e7de10d3  pop rcx
000078d2e7de10d4  pop rax
000078d2e7de10d5  add rsp, 0x08
000078d2e7de10d9  jmp 0x000078D2E7DDF210
000078d2e7de10de  sub rsp, 0x08
000078d2e7de10e2  push rax
000078d2e7de10e3  push rcx
000078d2e7de10e4  push rdx
000078d2e7de10e5  push rdi
000078d2e7de10e6  push rsi
000078d2e7de10e7  push r8
000078d2e7de10e9  push r9
000078d2e7de10eb  push r10
000078d2e7de10ed  push r11
000078d2e7de10ef  sub rsp, 0xF0
000078d2e7de10f6  vmovaps [rsp], xmm0
000078d2e7de10fb  vmovaps [rsp+0x10], xmm1
000078d2e7de1101  vmovaps [rsp+0x20], xmm2
000078d2e7de1107  vmovaps [rsp+0x30], xmm3
000078d2e7de110d  vmovaps [rsp+0x40], xmm4
000078d2e7de1113  vmovaps [rsp+0x50], xmm5
000078d2e7de1119  vmovaps [rsp+0x60], xmm6
000078d2e7de111f  vmovaps [rsp+0x70], xmm8
000078d2e7de1125  vmovaps [rsp+0x80], xmm9
000078d2e7de112e  vmovaps [rsp+0x90], xmm10
000078d2e7de1137  vmovaps [rsp+0xA0], xmm11
000078d2e7de1140  vmovaps [rsp+0xB0], xmm12
000078d2e7de1149  vmovaps [rsp+0xC0], xmm13
000078d2e7de1152  vmovaps [rsp+0xD0], xmm14
000078d2e7de115b  vmovaps [rsp+0xE0], xmm15
000078d2e7de1164  sub rsp, 0x30
000078d2e7de1168  movaps [rsp], xmm7
000078d2e7de116c  movaps [rsp+0x10], xmm5
000078d2e7de1171  movaps [rsp+0x20], xmm15
000078d2e7de1177  lea rdi, [rsp]
000078d2e7de117b  mov esi, 0x00
000078d2e7de1180  mov rax, 0x5997D2DB1530
000078d2e7de118a  call rax
000078d2e7de118c  movaps xmm7, [rsp]
000078d2e7de1190  add rsp, 0x30
000078d2e7de1194  vmovaps xmm0, [rsp]
000078d2e7de1199  vmovaps xmm1, [rsp+0x10]
000078d2e7de119f  vmovaps xmm2, [rsp+0x20]
000078d2e7de11a5  vmovaps xmm3, [rsp+0x30]
000078d2e7de11ab  vmovaps xmm4, [rsp+0x40]
000078d2e7de11b1  vmovaps xmm5, [rsp+0x50]
000078d2e7de11b7  vmovaps xmm6, [rsp+0x60]
000078d2e7de11bd  vmovaps xmm8, [rsp+0x70]
000078d2e7de11c3  vmovaps xmm9, [rsp+0x80]
000078d2e7de11cc  vmovaps xmm10, [rsp+0x90]
000078d2e7de11d5  vmovaps xmm11, [rsp+0xA0]
000078d2e7de11de  vmovaps xmm12, [rsp+0xB0]
000078d2e7de11e7  vmovaps xmm13, [rsp+0xC0]
000078d2e7de11f0  vmovaps xmm14, [rsp+0xD0]
000078d2e7de11f9  vmovaps xmm15, [rsp+0xE0]
000078d2e7de1202  add rsp, 0xF0
000078d2e7de1209  pop r11
000078d2e7de120b  pop r10
000078d2e7de120d  pop r9
000078d2e7de120f  pop r8
000078d2e7de1211  pop rsi
000078d2e7de1212  pop rdi
000078d2e7de1213  pop rdx
000078d2e7de1214  pop rcx
000078d2e7de1215  pop rax
000078d2e7de1216  add rsp, 0x08
000078d2e7de121a  jmp 0x000078D2E7DDF246
000078d2e7de121f  call 0x000078D2E7CB52F0
000078d2e7de1224  jmp 0x000078D2E7DDF253
000078d2e7de1229  sub rsp, 0x08
000078d2e7de122d  push rax
000078d2e7de122e  push rcx
000078d2e7de122f  push rdx
000078d2e7de1230  push rdi
000078d2e7de1231  push rsi
000078d2e7de1232  push r8
000078d2e7de1234  push r9
000078d2e7de1236  push r10
000078d2e7de1238  push r11
000078d2e7de123a  sub rsp, 0xF0
000078d2e7de1241  vmovaps [rsp], xmm0
000078d2e7de1246  vmovaps [rsp+0x10], xmm1
000078d2e7de124c  vmovaps [rsp+0x20], xmm2
000078d2e7de1252  vmovaps [rsp+0x30], xmm3
000078d2e7de1258  vmovaps [rsp+0x40], xmm4
000078d2e7de125e  vmovaps [rsp+0x50], xmm5
000078d2e7de1264  vmovaps [rsp+0x60], xmm6
000078d2e7de126a  vmovaps [rsp+0x70], xmm7
000078d2e7de1270  vmovaps [rsp+0x80], xmm8
000078d2e7de1279  vmovaps [rsp+0x90], xmm9
000078d2e7de1282  vmovaps [rsp+0xA0], xmm10
000078d2e7de128b  vmovaps [rsp+0xB0], xmm11
000078d2e7de1294  vmovaps [rsp+0xC0], xmm12
000078d2e7de129d  vmovaps [rsp+0xD0], xmm13
000078d2e7de12a6  vmovaps [rsp+0xE0], xmm14
000078d2e7de12af  sub rsp, 0x30
000078d2e7de12b3  movaps [rsp], xmm15
000078d2e7de12b8  movaps [rsp+0x10], xmm5
000078d2e7de12bd  movaps [rsp+0x20], xmm3
000078d2e7de12c2  lea rdi, [rsp]
000078d2e7de12c6  mov esi, 0x00
000078d2e7de12cb  mov rax, 0x5997D2DB1530
000078d2e7de12d5  call rax
000078d2e7de12d7  movaps xmm15, [rsp]
000078d2e7de12dc  add rsp, 0x30
000078d2e7de12e0  vmovaps xmm0, [rsp]
000078d2e7de12e5  vmovaps xmm1, [rsp+0x10]
000078d2e7de12eb  vmovaps xmm2, [rsp+0x20]
000078d2e7de12f1  vmovaps xmm3, [rsp+0x30]
000078d2e7de12f7  vmovaps xmm4, [rsp+0x40]
000078d2e7de12fd  vmovaps xmm5, [rsp+0x50]
000078d2e7de1303  vmovaps xmm6, [rsp+0x60]
000078d2e7de1309  vmovaps xmm7, [rsp+0x70]
000078d2e7de130f  vmovaps xmm8, [rsp+0x80]
000078d2e7de1318  vmovaps xmm9, [rsp+0x90]
000078d2e7de1321  vmovaps xmm10, [rsp+0xA0]
000078d2e7de132a  vmovaps xmm11, [rsp+0xB0]
000078d2e7de1333  vmovaps xmm12, [rsp+0xC0]
000078d2e7de133c  vmovaps xmm13, [rsp+0xD0]
000078d2e7de1345  vmovaps xmm14, [rsp+0xE0]
000078d2e7de134e  add rsp, 0xF0
000078d2e7de1355  pop r11
000078d2e7de1357  pop r10
000078d2e7de1359  pop r9
000078d2e7de135b  pop r8
000078d2e7de135d  pop rsi
000078d2e7de135e  pop rdi
000078d2e7de135f  pop rdx
000078d2e7de1360  pop rcx
000078d2e7de1361  pop rax
000078d2e7de1362  add rsp, 0x08
000078d2e7de1366  jmp 0x000078D2E7DDF279
000078d2e7de136b  sub rsp, 0x08
000078d2e7de136f  push rax
000078d2e7de1370  push rcx
000078d2e7de1371  push rdx
000078d2e7de1372  push rdi
000078d2e7de1373  push rsi
000078d2e7de1374  push r8
000078d2e7de1376  push r9
000078d2e7de1378  push r10
000078d2e7de137a  push r11
000078d2e7de137c  sub rsp, 0xF0
000078d2e7de1383  vmovaps [rsp], xmm0
000078d2e7de1388  vmovaps [rsp+0x10], xmm2
000078d2e7de138e  vmovaps [rsp+0x20], xmm3
000078d2e7de1394  vmovaps [rsp+0x30], xmm4
000078d2e7de139a  vmovaps [rsp+0x40], xmm5
000078d2e7de13a0  vmovaps [rsp+0x50], xmm6
000078d2e7de13a6  vmovaps [rsp+0x60], xmm7
000078d2e7de13ac  vmovaps [rsp+0x70], xmm8
000078d2e7de13b2  vmovaps [rsp+0x80], xmm9
000078d2e7de13bb  vmovaps [rsp+0x90], xmm10
000078d2e7de13c4  vmovaps [rsp+0xA0], xmm11
000078d2e7de13cd  vmovaps [rsp+0xB0], xmm12
000078d2e7de13d6  vmovaps [rsp+0xC0], xmm13
000078d2e7de13df  vmovaps [rsp+0xD0], xmm14
000078d2e7de13e8  vmovaps [rsp+0xE0], xmm15
000078d2e7de13f1  sub rsp, 0x30
000078d2e7de13f5  movaps [rsp], xmm1
000078d2e7de13f9  movaps [rsp+0x10], xmm5
000078d2e7de13fe  movaps [rsp+0x20], xmm4
000078d2e7de1403  lea rdi, [rsp]
000078d2e7de1407  mov esi, 0x00
000078d2e7de140c  mov rax, 0x5997D2DB1530
000078d2e7de1416  call rax
000078d2e7de1418  movaps xmm1, [rsp]
000078d2e7de141c  add rsp, 0x30
000078d2e7de1420  vmovaps xmm0, [rsp]
000078d2e7de1425  vmovaps xmm2, [rsp+0x10]
000078d2e7de142b  vmovaps xmm3, [rsp+0x20]
000078d2e7de1431  vmovaps xmm4, [rsp+0x30]
000078d2e7de1437  vmovaps xmm5, [rsp+0x40]
000078d2e7de143d  vmovaps xmm6, [rsp+0x50]
000078d2e7de1443  vmovaps xmm7, [rsp+0x60]
000078d2e7de1449  vmovaps xmm8, [rsp+0x70]
000078d2e7de144f  vmovaps xmm9, [rsp+0x80]
000078d2e7de1458  vmovaps xmm10, [rsp+0x90]
000078d2e7de1461  vmovaps xmm11, [rsp+0xA0]
000078d2e7de146a  vmovaps xmm12, [rsp+0xB0]
000078d2e7de1473  vmovaps xmm13, [rsp+0xC0]
000078d2e7de147c  vmovaps xmm14, [rsp+0xD0]
000078d2e7de1485  vmovaps xmm15, [rsp+0xE0]
000078d2e7de148e  add rsp, 0xF0
000078d2e7de1495  pop r11
000078d2e7de1497  pop r10
000078d2e7de1499  pop r9
000078d2e7de149b  pop r8
000078d2e7de149d  pop rsi
000078d2e7de149e  pop rdi
000078d2e7de149f  pop rdx
000078d2e7de14a0  pop rcx
000078d2e7de14a1  pop rax
000078d2e7de14a2  add rsp, 0x08
000078d2e7de14a6  jmp 0x000078D2E7DDF299
000078d2e7de14ab  sub rsp, 0x08
000078d2e7de14af  push rax
000078d2e7de14b0  push rcx
000078d2e7de14b1  push rdx
000078d2e7de14b2  push rdi
000078d2e7de14b3  push rsi
000078d2e7de14b4  push r8
000078d2e7de14b6  push r9
000078d2e7de14b8  push r10
000078d2e7de14ba  push r11
000078d2e7de14bc  sub rsp, 0xF0
000078d2e7de14c3  vmovaps [rsp], xmm0
000078d2e7de14c8  vmovaps [rsp+0x10], xmm1
000078d2e7de14ce  vmovaps [rsp+0x20], xmm2
000078d2e7de14d4  vmovaps [rsp+0x30], xmm3
000078d2e7de14da  vmovaps [rsp+0x40], xmm5
000078d2e7de14e0  vmovaps [rsp+0x50], xmm6
000078d2e7de14e6  vmovaps [rsp+0x60], xmm7
000078d2e7de14ec  vmovaps [rsp+0x70], xmm8
000078d2e7de14f2  vmovaps [rsp+0x80], xmm9
000078d2e7de14fb  vmovaps [rsp+0x90], xmm10
000078d2e7de1504  vmovaps [rsp+0xA0], xmm11
000078d2e7de150d  vmovaps [rsp+0xB0], xmm12
000078d2e7de1516  vmovaps [rsp+0xC0], xmm13
000078d2e7de151f  vmovaps [rsp+0xD0], xmm14
000078d2e7de1528  vmovaps [rsp+0xE0], xmm15
000078d2e7de1531  sub rsp, 0x30
000078d2e7de1535  movaps [rsp], xmm4
000078d2e7de1539  movaps [rsp+0x10], xmm3
000078d2e7de153e  movaps [rsp+0x20], xmm5
000078d2e7de1543  lea rdi, [rsp]
000078d2e7de1547  mov esi, 0x00
000078d2e7de154c  mov rax, 0x5997D2DB1530
000078d2e7de1556  call rax
000078d2e7de1558  movaps xmm4, [rsp]
000078d2e7de155c  add rsp, 0x30
000078d2e7de1560  vmovaps xmm0, [rsp]
000078d2e7de1565  vmovaps xmm1, [rsp+0x10]
000078d2e7de156b  vmovaps xmm2, [rsp+0x20]
000078d2e7de1571  vmovaps xmm3, [rsp+0x30]
000078d2e7de1577  vmovaps xmm5, [rsp+0x40]
000078d2e7de157d  vmovaps xmm6, [rsp+0x50]
000078d2e7de1583  vmovaps xmm7, [rsp+0x60]
000078d2e7de1589  vmovaps xmm8, [rsp+0x70]
000078d2e7de158f  vmovaps xmm9, [rsp+0x80]
000078d2e7de1598  vmovaps xmm10, [rsp+0x90]
000078d2e7de15a1  vmovaps xmm11, [rsp+0xA0]
000078d2e7de15aa  vmovaps xmm12, [rsp+0xB0]
000078d2e7de15b3  vmovaps xmm13, [rsp+0xC0]
000078d2e7de15bc  vmovaps xmm14, [rsp+0xD0]
000078d2e7de15c5  vmovaps xmm15, [rsp+0xE0]
000078d2e7de15ce  add rsp, 0xF0
000078d2e7de15d5  pop r11
000078d2e7de15d7  pop r10
000078d2e7de15d9  pop r9
000078d2e7de15db  pop r8
000078d2e7de15dd  pop rsi
000078d2e7de15de  pop rdi
000078d2e7de15df  pop rdx
000078d2e7de15e0  pop rcx
000078d2e7de15e1  pop rax
000078d2e7de15e2  add rsp, 0x08
000078d2e7de15e6  jmp 0x000078D2E7DDF2E7
000078d2e7de15eb  call 0x000078D2E7CB52F0
000078d2e7de15f0  jmp 0x000078D2E7DDF2F4
000078d2e7de15f5  sub rsp, 0x08
000078d2e7de15f9  push rax
000078d2e7de15fa  push rcx
000078d2e7de15fb  push rdx
000078d2e7de15fc  push rdi
000078d2e7de15fd  push rsi
000078d2e7de15fe  push r8
000078d2e7de1600  push r9
000078d2e7de1602  push r10
000078d2e7de1604  push r11
000078d2e7de1606  sub rsp, 0xF0
000078d2e7de160d  vmovaps [rsp], xmm0
000078d2e7de1612  vmovaps [rsp+0x10], xmm1
000078d2e7de1618  vmovaps [rsp+0x20], xmm2
000078d2e7de161e  vmovaps [rsp+0x30], xmm3
000078d2e7de1624  vmovaps [rsp+0x40], xmm4
000078d2e7de162a  vmovaps [rsp+0x50], xmm6
000078d2e7de1630  vmovaps [rsp+0x60], xmm7
000078d2e7de1636  vmovaps [rsp+0x70], xmm8
000078d2e7de163c  vmovaps [rsp+0x80], xmm9
000078d2e7de1645  vmovaps [rsp+0x90], xmm10
000078d2e7de164e  vmovaps [rsp+0xA0], xmm11
000078d2e7de1657  vmovaps [rsp+0xB0], xmm12
000078d2e7de1660  vmovaps [rsp+0xC0], xmm13
000078d2e7de1669  vmovaps [rsp+0xD0], xmm14
000078d2e7de1672  vmovaps [rsp+0xE0], xmm15
000078d2e7de167b  sub rsp, 0x30
000078d2e7de167f  movaps [rsp], xmm5
000078d2e7de1683  movaps [rsp+0x10], xmm6
000078d2e7de1688  movaps [rsp+0x20], xmm3
000078d2e7de168d  lea rdi, [rsp]
000078d2e7de1691  mov esi, 0x00
000078d2e7de1696  mov rax, 0x5997D2DB1530
000078d2e7de16a0  call rax
000078d2e7de16a2  movaps xmm5, [rsp]
000078d2e7de16a6  add rsp, 0x30
000078d2e7de16aa  vmovaps xmm0, [rsp]
000078d2e7de16af  vmovaps xmm1, [rsp+0x10]
000078d2e7de16b5  vmovaps xmm2, [rsp+0x20]
000078d2e7de16bb  vmovaps xmm3, [rsp+0x30]
000078d2e7de16c1  vmovaps xmm4, [rsp+0x40]
000078d2e7de16c7  vmovaps xmm6, [rsp+0x50]
000078d2e7de16cd  vmovaps xmm7, [rsp+0x60]
000078d2e7de16d3  vmovaps xmm8, [rsp+0x70]
000078d2e7de16d9  vmovaps xmm9, [rsp+0x80]
000078d2e7de16e2  vmovaps xmm10, [rsp+0x90]
000078d2e7de16eb  vmovaps xmm11, [rsp+0xA0]
000078d2e7de16f4  vmovaps xmm12, [rsp+0xB0]
000078d2e7de16fd  vmovaps xmm13, [rsp+0xC0]
000078d2e7de1706  vmovaps xmm14, [rsp+0xD0]
000078d2e7de170f  vmovaps xmm15, [rsp+0xE0]
000078d2e7de1718  add rsp, 0xF0
000078d2e7de171f  pop r11
000078d2e7de1721  pop r10
000078d2e7de1723  pop r9
000078d2e7de1725  pop r8
000078d2e7de1727  pop rsi
000078d2e7de1728  pop rdi
000078d2e7de1729  pop rdx
000078d2e7de172a  pop rcx
000078d2e7de172b  pop rax
000078d2e7de172c  add rsp, 0x08
000078d2e7de1730  jmp 0x000078D2E7DDF31A
000078d2e7de1735  sub rsp, 0x08
000078d2e7de1739  push rax
000078d2e7de173a  push rcx
000078d2e7de173b  push rdx
000078d2e7de173c  push rdi
000078d2e7de173d  push rsi
000078d2e7de173e  push r8
000078d2e7de1740  push r9
000078d2e7de1742  push r10
000078d2e7de1744  push r11
000078d2e7de1746  sub rsp, 0xF0
000078d2e7de174d  vmovaps [rsp], xmm0
000078d2e7de1752  vmovaps [rsp+0x10], xmm1
000078d2e7de1758  vmovaps [rsp+0x20], xmm2
000078d2e7de175e  vmovaps [rsp+0x30], xmm3
000078d2e7de1764  vmovaps [rsp+0x40], xmm4
000078d2e7de176a  vmovaps [rsp+0x50], xmm5
000078d2e7de1770  vmovaps [rsp+0x60], xmm7
000078d2e7de1776  vmovaps [rsp+0x70], xmm8
000078d2e7de177c  vmovaps [rsp+0x80], xmm9
000078d2e7de1785  vmovaps [rsp+0x90], xmm10
000078d2e7de178e  vmovaps [rsp+0xA0], xmm11
000078d2e7de1797  vmovaps [rsp+0xB0], xmm12
000078d2e7de17a0  vmovaps [rsp+0xC0], xmm13
000078d2e7de17a9  vmovaps [rsp+0xD0], xmm14
000078d2e7de17b2  vmovaps [rsp+0xE0], xmm15
000078d2e7de17bb  sub rsp, 0x30
000078d2e7de17bf  movaps [rsp], xmm6
000078d2e7de17c3  movaps [rsp+0x10], xmm9
000078d2e7de17c9  movaps [rsp+0x20], xmm1
000078d2e7de17ce  lea rdi, [rsp]
000078d2e7de17d2  mov esi, 0x00
000078d2e7de17d7  mov rax, 0x5997D2DB1530
000078d2e7de17e1  call rax
000078d2e7de17e3  movaps xmm6, [rsp]
000078d2e7de17e7  add rsp, 0x30
000078d2e7de17eb  vmovaps xmm0, [rsp]
000078d2e7de17f0  vmovaps xmm1, [rsp+0x10]
000078d2e7de17f6  vmovaps xmm2, [rsp+0x20]
000078d2e7de17fc  vmovaps xmm3, [rsp+0x30]
000078d2e7de1802  vmovaps xmm4, [rsp+0x40]
000078d2e7de1808  vmovaps xmm5, [rsp+0x50]
000078d2e7de180e  vmovaps xmm7, [rsp+0x60]
000078d2e7de1814  vmovaps xmm8, [rsp+0x70]
000078d2e7de181a  vmovaps xmm9, [rsp+0x80]
000078d2e7de1823  vmovaps xmm10, [rsp+0x90]
000078d2e7de182c  vmovaps xmm11, [rsp+0xA0]
000078d2e7de1835  vmovaps xmm12, [rsp+0xB0]
000078d2e7de183e  vmovaps xmm13, [rsp+0xC0]
000078d2e7de1847  vmovaps xmm14, [rsp+0xD0]
000078d2e7de1850  vmovaps xmm15, [rsp+0xE0]
000078d2e7de1859  add rsp, 0xF0
000078d2e7de1860  pop r11
000078d2e7de1862  pop r10
000078d2e7de1864  pop r9
000078d2e7de1866  pop r8
000078d2e7de1868  pop rsi
000078d2e7de1869  pop rdi
000078d2e7de186a  pop rdx
000078d2e7de186b  pop rcx
000078d2e7de186c  pop rax
000078d2e7de186d  add rsp, 0x08
000078d2e7de1871  jmp 0x000078D2E7DDF33E
000078d2e7de1876  sub rsp, 0x08
000078d2e7de187a  push rax
000078d2e7de187b  push rcx
000078d2e7de187c  push rdx
000078d2e7de187d  push rdi
000078d2e7de187e  push rsi
000078d2e7de187f  push r8
000078d2e7de1881  push r9
000078d2e7de1883  push r10
000078d2e7de1885  push r11
000078d2e7de1887  sub rsp, 0xF0
000078d2e7de188e  vmovaps [rsp], xmm0
000078d2e7de1893  vmovaps [rsp+0x10], xmm1
000078d2e7de1899  vmovaps [rsp+0x20], xmm2
000078d2e7de189f  vmovaps [rsp+0x30], xmm3
000078d2e7de18a5  vmovaps [rsp+0x40], xmm4
000078d2e7de18ab  vmovaps [rsp+0x50], xmm5
000078d2e7de18b1  vmovaps [rsp+0x60], xmm6
000078d2e7de18b7  vmovaps [rsp+0x70], xmm7
000078d2e7de18bd  vmovaps [rsp+0x80], xmm8
000078d2e7de18c6  vmovaps [rsp+0x90], xmm10
000078d2e7de18cf  vmovaps [rsp+0xA0], xmm11
000078d2e7de18d8  vmovaps [rsp+0xB0], xmm12
000078d2e7de18e1  vmovaps [rsp+0xC0], xmm13
000078d2e7de18ea  vmovaps [rsp+0xD0], xmm14
000078d2e7de18f3  vmovaps [rsp+0xE0], xmm15
000078d2e7de18fc  sub rsp, 0x30
000078d2e7de1900  movaps [rsp], xmm9
000078d2e7de1905  movaps [rsp+0x10], xmm3
000078d2e7de190a  movaps [rsp+0x20], xmm1
000078d2e7de190f  lea rdi, [rsp]
000078d2e7de1913  mov esi, 0x00
000078d2e7de1918  mov rax, 0x5997D2DB1530
000078d2e7de1922  call rax
000078d2e7de1924  movaps xmm9, [rsp]
000078d2e7de1929  add rsp, 0x30
000078d2e7de192d  vmovaps xmm0, [rsp]
000078d2e7de1932  vmovaps xmm1, [rsp+0x10]
000078d2e7de1938  vmovaps xmm2, [rsp+0x20]
000078d2e7de193e  vmovaps xmm3, [rsp+0x30]
000078d2e7de1944  vmovaps xmm4, [rsp+0x40]
000078d2e7de194a  vmovaps xmm5, [rsp+0x50]
000078d2e7de1950  vmovaps xmm6, [rsp+0x60]
000078d2e7de1956  vmovaps xmm7, [rsp+0x70]
000078d2e7de195c  vmovaps xmm8, [rsp+0x80]
000078d2e7de1965  vmovaps xmm10, [rsp+0x90]
000078d2e7de196e  vmovaps xmm11, [rsp+0xA0]
000078d2e7de1977  vmovaps xmm12, [rsp+0xB0]
000078d2e7de1980  vmovaps xmm13, [rsp+0xC0]
000078d2e7de1989  vmovaps xmm14, [rsp+0xD0]
000078d2e7de1992  vmovaps xmm15, [rsp+0xE0]
000078d2e7de199b  add rsp, 0xF0
000078d2e7de19a2  pop r11
000078d2e7de19a4  pop r10
000078d2e7de19a6  pop r9
000078d2e7de19a8  pop r8
000078d2e7de19aa  pop rsi
000078d2e7de19ab  pop rdi
000078d2e7de19ac  pop rdx
000078d2e7de19ad  pop rcx
000078d2e7de19ae  pop rax
000078d2e7de19af  add rsp, 0x08
000078d2e7de19b3  jmp 0x000078D2E7DDF38A
000078d2e7de19b8  call 0x000078D2E7CB52F0
000078d2e7de19bd  jmp 0x000078D2E7DDF397
000078d2e7de19c2  sub rsp, 0x08
000078d2e7de19c6  push rax
000078d2e7de19c7  push rcx
000078d2e7de19c8  push rdx
000078d2e7de19c9  push rdi
000078d2e7de19ca  push rsi
000078d2e7de19cb  push r8
000078d2e7de19cd  push r9
000078d2e7de19cf  push r10
000078d2e7de19d1  push r11
000078d2e7de19d3  sub rsp, 0xF0
000078d2e7de19da  vmovaps [rsp], xmm0
000078d2e7de19df  vmovaps [rsp+0x10], xmm1
000078d2e7de19e5  vmovaps [rsp+0x20], xmm2
000078d2e7de19eb  vmovaps [rsp+0x30], xmm3
000078d2e7de19f1  vmovaps [rsp+0x40], xmm4
000078d2e7de19f7  vmovaps [rsp+0x50], xmm5
000078d2e7de19fd  vmovaps [rsp+0x60], xmm6
000078d2e7de1a03  vmovaps [rsp+0x70], xmm7
000078d2e7de1a09  vmovaps [rsp+0x80], xmm8
000078d2e7de1a12  vmovaps [rsp+0x90], xmm9
000078d2e7de1a1b  vmovaps [rsp+0xA0], xmm10
000078d2e7de1a24  vmovaps [rsp+0xB0], xmm11
000078d2e7de1a2d  vmovaps [rsp+0xC0], xmm12
000078d2e7de1a36  vmovaps [rsp+0xD0], xmm13
000078d2e7de1a3f  vmovaps [rsp+0xE0], xmm14
000078d2e7de1a48  sub rsp, 0x30
000078d2e7de1a4c  movaps [rsp], xmm15
000078d2e7de1a51  movaps [rsp+0x10], xmm3
000078d2e7de1a56  movaps [rsp+0x20], xmm7
000078d2e7de1a5b  lea rdi, [rsp]
000078d2e7de1a5f  mov esi, 0x00
000078d2e7de1a64  mov rax, 0x5997D2DB1530
000078d2e7de1a6e  call rax
000078d2e7de1a70  movaps xmm15, [rsp]
000078d2e7de1a75  add rsp, 0x30
000078d2e7de1a79  vmovaps xmm0, [rsp]
000078d2e7de1a7e  vmovaps xmm1, [rsp+0x10]
000078d2e7de1a84  vmovaps xmm2, [rsp+0x20]
000078d2e7de1a8a  vmovaps xmm3, [rsp+0x30]
000078d2e7de1a90  vmovaps xmm4, [rsp+0x40]
000078d2e7de1a96  vmovaps xmm5, [rsp+0x50]
000078d2e7de1a9c  vmovaps xmm6, [rsp+0x60]
000078d2e7de1aa2  vmovaps xmm7, [rsp+0x70]
000078d2e7de1aa8  vmovaps xmm8, [rsp+0x80]
000078d2e7de1ab1  vmovaps xmm9, [rsp+0x90]
000078d2e7de1aba  vmovaps xmm10, [rsp+0xA0]
000078d2e7de1ac3  vmovaps xmm11, [rsp+0xB0]
000078d2e7de1acc  vmovaps xmm12, [rsp+0xC0]
000078d2e7de1ad5  vmovaps xmm13, [rsp+0xD0]
000078d2e7de1ade  vmovaps xmm14, [rsp+0xE0]
000078d2e7de1ae7  add rsp, 0xF0
000078d2e7de1aee  pop r11
000078d2e7de1af0  pop r10
000078d2e7de1af2  pop r9
000078d2e7de1af4  pop r8
000078d2e7de1af6  pop rsi
000078d2e7de1af7  pop rdi
000078d2e7de1af8  pop rdx
000078d2e7de1af9  pop rcx
000078d2e7de1afa  pop rax
000078d2e7de1afb  add rsp, 0x08
000078d2e7de1aff  jmp 0x000078D2E7DDF3C3
000078d2e7de1b04  sub rsp, 0x08
000078d2e7de1b08  push rax
000078d2e7de1b09  push rcx
000078d2e7de1b0a  push rdx
000078d2e7de1b0b  push rdi
000078d2e7de1b0c  push rsi
000078d2e7de1b0d  push r8
000078d2e7de1b0f  push r9
000078d2e7de1b11  push r10
000078d2e7de1b13  push r11
000078d2e7de1b15  sub rsp, 0xF0
000078d2e7de1b1c  vmovaps [rsp], xmm0
000078d2e7de1b21  vmovaps [rsp+0x10], xmm1
000078d2e7de1b27  vmovaps [rsp+0x20], xmm2
000078d2e7de1b2d  vmovaps [rsp+0x30], xmm4
000078d2e7de1b33  vmovaps [rsp+0x40], xmm5
000078d2e7de1b39  vmovaps [rsp+0x50], xmm6
000078d2e7de1b3f  vmovaps [rsp+0x60], xmm7
000078d2e7de1b45  vmovaps [rsp+0x70], xmm8
000078d2e7de1b4b  vmovaps [rsp+0x80], xmm9
000078d2e7de1b54  vmovaps [rsp+0x90], xmm10
000078d2e7de1b5d  vmovaps [rsp+0xA0], xmm11
000078d2e7de1b66  vmovaps [rsp+0xB0], xmm12
000078d2e7de1b6f  vmovaps [rsp+0xC0], xmm13
000078d2e7de1b78  vmovaps [rsp+0xD0], xmm14
000078d2e7de1b81  vmovaps [rsp+0xE0], xmm15
000078d2e7de1b8a  sub rsp, 0x30
000078d2e7de1b8e  movaps [rsp], xmm3
000078d2e7de1b92  movaps [rsp+0x10], xmm1
000078d2e7de1b97  movaps [rsp+0x20], xmm15
000078d2e7de1b9d  lea rdi, [rsp]
000078d2e7de1ba1  mov esi, 0x00
000078d2e7de1ba6  mov rax, 0x5997D2DB1530
000078d2e7de1bb0  call rax
000078d2e7de1bb2  movaps xmm3, [rsp]
000078d2e7de1bb6  add rsp, 0x30
000078d2e7de1bba  vmovaps xmm0, [rsp]
000078d2e7de1bbf  vmovaps xmm1, [rsp+0x10]
000078d2e7de1bc5  vmovaps xmm2, [rsp+0x20]
000078d2e7de1bcb  vmovaps xmm4, [rsp+0x30]
000078d2e7de1bd1  vmovaps xmm5, [rsp+0x40]
000078d2e7de1bd7  vmovaps xmm6, [rsp+0x50]
000078d2e7de1bdd  vmovaps xmm7, [rsp+0x60]
000078d2e7de1be3  vmovaps xmm8, [rsp+0x70]
000078d2e7de1be9  vmovaps xmm9, [rsp+0x80]
000078d2e7de1bf2  vmovaps xmm10, [rsp+0x90]
000078d2e7de1bfb  vmovaps xmm11, [rsp+0xA0]
000078d2e7de1c04  vmovaps xmm12, [rsp+0xB0]
000078d2e7de1c0d  vmovaps xmm13, [rsp+0xC0]
000078d2e7de1c16  vmovaps xmm14, [rsp+0xD0]
000078d2e7de1c1f  vmovaps xmm15, [rsp+0xE0]
000078d2e7de1c28  add rsp, 0xF0
000078d2e7de1c2f  pop r11
000078d2e7de1c31  pop r10
000078d2e7de1c33  pop r9
000078d2e7de1c35  pop r8
000078d2e7de1c37  pop rsi
000078d2e7de1c38  pop rdi
000078d2e7de1c39  pop rdx
000078d2e7de1c3a  pop rcx
000078d2e7de1c3b  pop rax
000078d2e7de1c3c  add rsp, 0x08
000078d2e7de1c40  jmp 0x000078D2E7DDF452
000078d2e7de1c45  call 0x000078D2E7CB52F0
000078d2e7de1c4a  jmp 0x000078D2E7DDF45C
000078d2e7de1c4f  sub rsp, 0x08
000078d2e7de1c53  push rax
000078d2e7de1c54  push rcx
000078d2e7de1c55  push rdx
000078d2e7de1c56  push rdi
000078d2e7de1c57  push rsi
000078d2e7de1c58  push r8
000078d2e7de1c5a  push r9
000078d2e7de1c5c  push r10
000078d2e7de1c5e  push r11
000078d2e7de1c60  sub rsp, 0xF0
000078d2e7de1c67  vmovaps [rsp], xmm0
000078d2e7de1c6c  vmovaps [rsp+0x10], xmm1
000078d2e7de1c72  vmovaps [rsp+0x20], xmm2
000078d2e7de1c78  vmovaps [rsp+0x30], xmm3
000078d2e7de1c7e  vmovaps [rsp+0x40], xmm4
000078d2e7de1c84  vmovaps [rsp+0x50], xmm5
000078d2e7de1c8a  vmovaps [rsp+0x60], xmm6
000078d2e7de1c90  vmovaps [rsp+0x70], xmm7
000078d2e7de1c96  vmovaps [rsp+0x80], xmm8
000078d2e7de1c9f  vmovaps [rsp+0x90], xmm9
000078d2e7de1ca8  vmovaps [rsp+0xA0], xmm10
000078d2e7de1cb1  vmovaps [rsp+0xB0], xmm11
000078d2e7de1cba  vmovaps [rsp+0xC0], xmm12
000078d2e7de1cc3  vmovaps [rsp+0xD0], xmm13
000078d2e7de1ccc  vmovaps [rsp+0xE0], xmm14
000078d2e7de1cd5  sub rsp, 0x30
000078d2e7de1cd9  movaps [rsp], xmm15
000078d2e7de1cde  movaps [rsp+0x10], xmm14
000078d2e7de1ce4  movaps [rsp+0x20], xmm4
000078d2e7de1ce9  lea rdi, [rsp]
000078d2e7de1ced  mov esi, 0x00
000078d2e7de1cf2  mov rax, 0x5997D2DB1530
000078d2e7de1cfc  call rax
000078d2e7de1cfe  movaps xmm15, [rsp]
000078d2e7de1d03  add rsp, 0x30
000078d2e7de1d07  vmovaps xmm0, [rsp]
000078d2e7de1d0c  vmovaps xmm1, [rsp+0x10]
000078d2e7de1d12  vmovaps xmm2, [rsp+0x20]
000078d2e7de1d18  vmovaps xmm3, [rsp+0x30]
000078d2e7de1d1e  vmovaps xmm4, [rsp+0x40]
000078d2e7de1d24  vmovaps xmm5, [rsp+0x50]
000078d2e7de1d2a  vmovaps xmm6, [rsp+0x60]
000078d2e7de1d30  vmovaps xmm7, [rsp+0x70]
000078d2e7de1d36  vmovaps xmm8, [rsp+0x80]
000078d2e7de1d3f  vmovaps xmm9, [rsp+0x90]
000078d2e7de1d48  vmovaps xmm10, [rsp+0xA0]
000078d2e7de1d51  vmovaps xmm11, [rsp+0xB0]
000078d2e7de1d5a  vmovaps xmm12, [rsp+0xC0]
000078d2e7de1d63  vmovaps xmm13, [rsp+0xD0]
000078d2e7de1d6c  vmovaps xmm14, [rsp+0xE0]
000078d2e7de1d75  add rsp, 0xF0
000078d2e7de1d7c  pop r11
000078d2e7de1d7e  pop r10
000078d2e7de1d80  pop r9
000078d2e7de1d82  pop r8
000078d2e7de1d84  pop rsi
000078d2e7de1d85  pop rdi
000078d2e7de1d86  pop rdx
000078d2e7de1d87  pop rcx
000078d2e7de1d88  pop rax
000078d2e7de1d89  add rsp, 0x08
000078d2e7de1d8d  jmp 0x000078D2E7DDF48A
000078d2e7de1d92  sub rsp, 0x08
000078d2e7de1d96  push rax
000078d2e7de1d97  push rcx
000078d2e7de1d98  push rdx
000078d2e7de1d99  push rdi
000078d2e7de1d9a  push rsi
000078d2e7de1d9b  push r8
000078d2e7de1d9d  push r9
000078d2e7de1d9f  push r10
000078d2e7de1da1  push r11
000078d2e7de1da3  sub rsp, 0xF0
000078d2e7de1daa  vmovaps [rsp], xmm0
000078d2e7de1daf  vmovaps [rsp+0x10], xmm1
000078d2e7de1db5  vmovaps [rsp+0x20], xmm2
000078d2e7de1dbb  vmovaps [rsp+0x30], xmm3
000078d2e7de1dc1  vmovaps [rsp+0x40], xmm4
000078d2e7de1dc7  vmovaps [rsp+0x50], xmm5
000078d2e7de1dcd  vmovaps [rsp+0x60], xmm6
000078d2e7de1dd3  vmovaps [rsp+0x70], xmm7
000078d2e7de1dd9  vmovaps [rsp+0x80], xmm8
000078d2e7de1de2  vmovaps [rsp+0x90], xmm9
000078d2e7de1deb  vmovaps [rsp+0xA0], xmm10
000078d2e7de1df4  vmovaps [rsp+0xB0], xmm11
000078d2e7de1dfd  vmovaps [rsp+0xC0], xmm12
000078d2e7de1e06  vmovaps [rsp+0xD0], xmm13
000078d2e7de1e0f  vmovaps [rsp+0xE0], xmm15
000078d2e7de1e18  sub rsp, 0x30
000078d2e7de1e1c  movaps [rsp], xmm14
000078d2e7de1e21  movaps [rsp+0x10], xmm2
000078d2e7de1e26  movaps [rsp+0x20], xmm1
000078d2e7de1e2b  lea rdi, [rsp]
000078d2e7de1e2f  mov esi, 0x00
000078d2e7de1e34  mov rax, 0x5997D2DB1530
000078d2e7de1e3e  call rax
000078d2e7de1e40  movaps xmm14, [rsp]
000078d2e7de1e45  add rsp, 0x30
000078d2e7de1e49  vmovaps xmm0, [rsp]
000078d2e7de1e4e  vmovaps xmm1, [rsp+0x10]
000078d2e7de1e54  vmovaps xmm2, [rsp+0x20]
000078d2e7de1e5a  vmovaps xmm3, [rsp+0x30]
000078d2e7de1e60  vmovaps xmm4, [rsp+0x40]
000078d2e7de1e66  vmovaps xmm5, [rsp+0x50]
000078d2e7de1e6c  vmovaps xmm6, [rsp+0x60]
000078d2e7de1e72  vmovaps xmm7, [rsp+0x70]
000078d2e7de1e78  vmovaps xmm8, [rsp+0x80]
000078d2e7de1e81  vmovaps xmm9, [rsp+0x90]
000078d2e7de1e8a  vmovaps xmm10, [rsp+0xA0]
000078d2e7de1e93  vmovaps xmm11, [rsp+0xB0]
000078d2e7de1e9c  vmovaps xmm12, [rsp+0xC0]
000078d2e7de1ea5  vmovaps xmm13, [rsp+0xD0]
000078d2e7de1eae  vmovaps xmm15, [rsp+0xE0]
000078d2e7de1eb7  add rsp, 0xF0
000078d2e7de1ebe  pop r11
000078d2e7de1ec0  pop r10
000078d2e7de1ec2  pop r9
000078d2e7de1ec4  pop r8
000078d2e7de1ec6  pop rsi
000078d2e7de1ec7  pop rdi
000078d2e7de1ec8  pop rdx
000078d2e7de1ec9  pop rcx
000078d2e7de1eca  pop rax
000078d2e7de1ecb  add rsp, 0x08
000078d2e7de1ecf  jmp 0x000078D2E7DDF4B0
000078d2e7de1ed4  sub rsp, 0x08
000078d2e7de1ed8  push rax
000078d2e7de1ed9  push rcx
000078d2e7de1eda  push rdx
000078d2e7de1edb  push rdi
000078d2e7de1edc  push rsi
000078d2e7de1edd  push r8
000078d2e7de1edf  push r9
000078d2e7de1ee1  push r10
000078d2e7de1ee3  push r11
000078d2e7de1ee5  sub rsp, 0xF0
000078d2e7de1eec  vmovaps [rsp], xmm0
000078d2e7de1ef1  vmovaps [rsp+0x10], xmm2
000078d2e7de1ef7  vmovaps [rsp+0x20], xmm3
000078d2e7de1efd  vmovaps [rsp+0x30], xmm4
000078d2e7de1f03  vmovaps [rsp+0x40], xmm5
000078d2e7de1f09  vmovaps [rsp+0x50], xmm6
000078d2e7de1f0f  vmovaps [rsp+0x60], xmm7
000078d2e7de1f15  vmovaps [rsp+0x70], xmm8
000078d2e7de1f1b  vmovaps [rsp+0x80], xmm9
000078d2e7de1f24  vmovaps [rsp+0x90], xmm10
000078d2e7de1f2d  vmovaps [rsp+0xA0], xmm11
000078d2e7de1f36  vmovaps [rsp+0xB0], xmm12
000078d2e7de1f3f  vmovaps [rsp+0xC0], xmm13
000078d2e7de1f48  vmovaps [rsp+0xD0], xmm14
000078d2e7de1f51  vmovaps [rsp+0xE0], xmm15
000078d2e7de1f5a  sub rsp, 0x30
000078d2e7de1f5e  movaps [rsp], xmm1
000078d2e7de1f62  movaps [rsp+0x10], xmm4
000078d2e7de1f67  movaps [rsp+0x20], xmm9
000078d2e7de1f6d  lea rdi, [rsp]
000078d2e7de1f71  mov esi, 0x00
000078d2e7de1f76  mov rax, 0x5997D2DB1530
000078d2e7de1f80  call rax
000078d2e7de1f82  movaps xmm1, [rsp]
000078d2e7de1f86  add rsp, 0x30
000078d2e7de1f8a  vmovaps xmm0, [rsp]
000078d2e7de1f8f  vmovaps xmm2, [rsp+0x10]
000078d2e7de1f95  vmovaps xmm3, [rsp+0x20]
000078d2e7de1f9b  vmovaps xmm4, [rsp+0x30]
000078d2e7de1fa1  vmovaps xmm5, [rsp+0x40]
000078d2e7de1fa7  vmovaps xmm6, [rsp+0x50]
000078d2e7de1fad  vmovaps xmm7, [rsp+0x60]
000078d2e7de1fb3  vmovaps xmm8, [rsp+0x70]
000078d2e7de1fb9  vmovaps xmm9, [rsp+0x80]
000078d2e7de1fc2  vmovaps xmm10, [rsp+0x90]
000078d2e7de1fcb  vmovaps xmm11, [rsp+0xA0]
000078d2e7de1fd4  vmovaps xmm12, [rsp+0xB0]
000078d2e7de1fdd  vmovaps xmm13, [rsp+0xC0]
000078d2e7de1fe6  vmovaps xmm14, [rsp+0xD0]
000078d2e7de1fef  vmovaps xmm15, [rsp+0xE0]
000078d2e7de1ff8  add rsp, 0xF0
000078d2e7de1fff  pop r11
000078d2e7de2001  pop r10
000078d2e7de2003  pop r9
000078d2e7de2005  pop r8
000078d2e7de2007  pop rsi
000078d2e7de2008  pop rdi
000078d2e7de2009  pop rdx
000078d2e7de200a  pop rcx
000078d2e7de200b  pop rax
000078d2e7de200c  add rsp, 0x08
000078d2e7de2010  jmp 0x000078D2E7DDF4CE
000078d2e7de2015  sub rsp, 0x08
000078d2e7de2019  push rax
000078d2e7de201a  push rcx
000078d2e7de201b  push rdx
000078d2e7de201c  push rdi
000078d2e7de201d  push rsi
000078d2e7de201e  push r8
000078d2e7de2020  push r9
000078d2e7de2022  push r10
000078d2e7de2024  push r11
000078d2e7de2026  sub rsp, 0xF0
000078d2e7de202d  vmovaps [rsp], xmm0
000078d2e7de2032  vmovaps [rsp+0x10], xmm1
000078d2e7de2038  vmovaps [rsp+0x20], xmm2
000078d2e7de203e  vmovaps [rsp+0x30], xmm3
000078d2e7de2044  vmovaps [rsp+0x40], xmm5
000078d2e7de204a  vmovaps [rsp+0x50], xmm6
000078d2e7de2050  vmovaps [rsp+0x60], xmm7
000078d2e7de2056  vmovaps [rsp+0x70], xmm8
000078d2e7de205c  vmovaps [rsp+0x80], xmm9
000078d2e7de2065  vmovaps [rsp+0x90], xmm10
000078d2e7de206e  vmovaps [rsp+0xA0], xmm11
000078d2e7de2077  vmovaps [rsp+0xB0], xmm12
000078d2e7de2080  vmovaps [rsp+0xC0], xmm13
000078d2e7de2089  vmovaps [rsp+0xD0], xmm14
000078d2e7de2092  vmovaps [rsp+0xE0], xmm15
000078d2e7de209b  sub rsp, 0x30
000078d2e7de209f  movaps [rsp], xmm4
000078d2e7de20a3  movaps [rsp+0x10], xmm2
000078d2e7de20a8  movaps [rsp+0x20], xmm9
000078d2e7de20ae  lea rdi, [rsp]
000078d2e7de20b2  mov esi, 0x00
000078d2e7de20b7  mov rax, 0x5997D2DB1530
000078d2e7de20c1  call rax
000078d2e7de20c3  movaps xmm4, [rsp]
000078d2e7de20c7  add rsp, 0x30
000078d2e7de20cb  vmovaps xmm0, [rsp]
000078d2e7de20d0  vmovaps xmm1, [rsp+0x10]
000078d2e7de20d6  vmovaps xmm2, [rsp+0x20]
000078d2e7de20dc  vmovaps xmm3, [rsp+0x30]
000078d2e7de20e2  vmovaps xmm5, [rsp+0x40]
000078d2e7de20e8  vmovaps xmm6, [rsp+0x50]
000078d2e7de20ee  vmovaps xmm7, [rsp+0x60]
000078d2e7de20f4  vmovaps xmm8, [rsp+0x70]
000078d2e7de20fa  vmovaps xmm9, [rsp+0x80]
000078d2e7de2103  vmovaps xmm10, [rsp+0x90]
000078d2e7de210c  vmovaps xmm11, [rsp+0xA0]
000078d2e7de2115  vmovaps xmm12, [rsp+0xB0]
000078d2e7de211e  vmovaps xmm13, [rsp+0xC0]
000078d2e7de2127  vmovaps xmm14, [rsp+0xD0]
000078d2e7de2130  vmovaps xmm15, [rsp+0xE0]
000078d2e7de2139  add rsp, 0xF0
000078d2e7de2140  pop r11
000078d2e7de2142  pop r10
000078d2e7de2144  pop r9
000078d2e7de2146  pop r8
000078d2e7de2148  pop rsi
000078d2e7de2149  pop rdi
000078d2e7de214a  pop rdx
000078d2e7de214b  pop rcx
000078d2e7de214c  pop rax
000078d2e7de214d  add rsp, 0x08
000078d2e7de2151  jmp 0x000078D2E7DDF4FE
000078d2e7de2156  sub rsp, 0x08
000078d2e7de215a  push rax
000078d2e7de215b  push rcx
000078d2e7de215c  push rdx
000078d2e7de215d  push rdi
000078d2e7de215e  push rsi
000078d2e7de215f  push r8
000078d2e7de2161  push r9
000078d2e7de2163  push r10
000078d2e7de2165  push r11
000078d2e7de2167  sub rsp, 0xF0
000078d2e7de216e  vmovaps [rsp], xmm0
000078d2e7de2173  vmovaps [rsp+0x10], xmm1
000078d2e7de2179  vmovaps [rsp+0x20], xmm2
000078d2e7de217f  vmovaps [rsp+0x30], xmm3
000078d2e7de2185  vmovaps [rsp+0x40], xmm4
000078d2e7de218b  vmovaps [rsp+0x50], xmm5
000078d2e7de2191  vmovaps [rsp+0x60], xmm6
000078d2e7de2197  vmovaps [rsp+0x70], xmm7
000078d2e7de219d  vmovaps [rsp+0x80], xmm8
000078d2e7de21a6  vmovaps [rsp+0x90], xmm10
000078d2e7de21af  vmovaps [rsp+0xA0], xmm11
000078d2e7de21b8  vmovaps [rsp+0xB0], xmm12
000078d2e7de21c1  vmovaps [rsp+0xC0], xmm13
000078d2e7de21ca  vmovaps [rsp+0xD0], xmm14
000078d2e7de21d3  vmovaps [rsp+0xE0], xmm15
000078d2e7de21dc  sub rsp, 0x30
000078d2e7de21e0  movaps [rsp], xmm9
000078d2e7de21e5  movaps [rsp+0x10], xmm2
000078d2e7de21ea  movaps [rsp+0x20], xmm1
000078d2e7de21ef  lea rdi, [rsp]
000078d2e7de21f3  mov esi, 0x00
000078d2e7de21f8  mov rax, 0x5997D2DB1530
000078d2e7de2202  call rax
000078d2e7de2204  movaps xmm9, [rsp]
000078d2e7de2209  add rsp, 0x30
000078d2e7de220d  vmovaps xmm0, [rsp]
000078d2e7de2212  vmovaps xmm1, [rsp+0x10]
000078d2e7de2218  vmovaps xmm2, [rsp+0x20]
000078d2e7de221e  vmovaps xmm3, [rsp+0x30]
000078d2e7de2224  vmovaps xmm4, [rsp+0x40]
000078d2e7de222a  vmovaps xmm5, [rsp+0x50]
000078d2e7de2230  vmovaps xmm6, [rsp+0x60]
000078d2e7de2236  vmovaps xmm7, [rsp+0x70]
000078d2e7de223c  vmovaps xmm8, [rsp+0x80]
000078d2e7de2245  vmovaps xmm10, [rsp+0x90]
000078d2e7de224e  vmovaps xmm11, [rsp+0xA0]
000078d2e7de2257  vmovaps xmm12, [rsp+0xB0]
000078d2e7de2260  vmovaps xmm13, [rsp+0xC0]
000078d2e7de2269  vmovaps xmm14, [rsp+0xD0]
000078d2e7de2272  vmovaps xmm15, [rsp+0xE0]
000078d2e7de227b  add rsp, 0xF0
000078d2e7de2282  pop r11
000078d2e7de2284  pop r10
000078d2e7de2286  pop r9
000078d2e7de2288  pop r8
000078d2e7de228a  pop rsi
000078d2e7de228b  pop rdi
000078d2e7de228c  pop rdx
000078d2e7de228d  pop rcx
000078d2e7de228e  pop rax
000078d2e7de228f  add rsp, 0x08
000078d2e7de2293  jmp 0x000078D2E7DDF534
000078d2e7de2298  sub rsp, 0x08
000078d2e7de229c  push rax
000078d2e7de229d  push rcx
000078d2e7de229e  push rdx
000078d2e7de229f  push rdi
000078d2e7de22a0  push rsi
000078d2e7de22a1  push r8
000078d2e7de22a3  push r9
000078d2e7de22a5  push r10
000078d2e7de22a7  push r11
000078d2e7de22a9  sub rsp, 0xF0
000078d2e7de22b0  vmovaps [rsp], xmm0
000078d2e7de22b5  vmovaps [rsp+0x10], xmm2
000078d2e7de22bb  vmovaps [rsp+0x20], xmm3
000078d2e7de22c1  vmovaps [rsp+0x30], xmm4
000078d2e7de22c7  vmovaps [rsp+0x40], xmm5
000078d2e7de22cd  vmovaps [rsp+0x50], xmm6
000078d2e7de22d3  vmovaps [rsp+0x60], xmm7
000078d2e7de22d9  vmovaps [rsp+0x70], xmm8
000078d2e7de22df  vmovaps [rsp+0x80], xmm9
000078d2e7de22e8  vmovaps [rsp+0x90], xmm10
000078d2e7de22f1  vmovaps [rsp+0xA0], xmm11
000078d2e7de22fa  vmovaps [rsp+0xB0], xmm12
000078d2e7de2303  vmovaps [rsp+0xC0], xmm13
000078d2e7de230c  vmovaps [rsp+0xD0], xmm14
000078d2e7de2315  vmovaps [rsp+0xE0], xmm15
000078d2e7de231e  sub rsp, 0x30
000078d2e7de2322  movaps [rsp], xmm1
000078d2e7de2326  movaps [rsp+0x10], xmm15
000078d2e7de232c  movaps [rsp+0x20], xmm6
000078d2e7de2331  lea rdi, [rsp]
000078d2e7de2335  mov esi, 0x00
000078d2e7de233a  mov rax, 0x5997D2DB1530
000078d2e7de2344  call rax
000078d2e7de2346  movaps xmm1, [rsp]
000078d2e7de234a  add rsp, 0x30
000078d2e7de234e  vmovaps xmm0, [rsp]
000078d2e7de2353  vmovaps xmm2, [rsp+0x10]
000078d2e7de2359  vmovaps xmm3, [rsp+0x20]
000078d2e7de235f  vmovaps xmm4, [rsp+0x30]
000078d2e7de2365  vmovaps xmm5, [rsp+0x40]
000078d2e7de236b  vmovaps xmm6, [rsp+0x50]
000078d2e7de2371  vmovaps xmm7, [rsp+0x60]
000078d2e7de2377  vmovaps xmm8, [rsp+0x70]
000078d2e7de237d  vmovaps xmm9, [rsp+0x80]
000078d2e7de2386  vmovaps xmm10, [rsp+0x90]
000078d2e7de238f  vmovaps xmm11, [rsp+0xA0]
000078d2e7de2398  vmovaps xmm12, [rsp+0xB0]
000078d2e7de23a1  vmovaps xmm13, [rsp+0xC0]
000078d2e7de23aa  vmovaps xmm14, [rsp+0xD0]
000078d2e7de23b3  vmovaps xmm15, [rsp+0xE0]
000078d2e7de23bc  add rsp, 0xF0
000078d2e7de23c3  pop r11
000078d2e7de23c5  pop r10
000078d2e7de23c7  pop r9
000078d2e7de23c9  pop r8
000078d2e7de23cb  pop rsi
000078d2e7de23cc  pop rdi
000078d2e7de23cd  pop rdx
000078d2e7de23ce  pop rcx
000078d2e7de23cf  pop rax
000078d2e7de23d0  add rsp, 0x08
000078d2e7de23d4  jmp 0x000078D2E7DDF555
000078d2e7de23d9  sub rsp, 0x08
000078d2e7de23dd  push rax
000078d2e7de23de  push rcx
000078d2e7de23df  push rdx
000078d2e7de23e0  push rdi
000078d2e7de23e1  push rsi
000078d2e7de23e2  push r8
000078d2e7de23e4  push r9
000078d2e7de23e6  push r10
000078d2e7de23e8  push r11
000078d2e7de23ea  sub rsp, 0xF0
000078d2e7de23f1  vmovaps [rsp], xmm0
000078d2e7de23f6  vmovaps [rsp+0x10], xmm1
000078d2e7de23fc  vmovaps [rsp+0x20], xmm2
000078d2e7de2402  vmovaps [rsp+0x30], xmm3
000078d2e7de2408  vmovaps [rsp+0x40], xmm4
000078d2e7de240e  vmovaps [rsp+0x50], xmm5
000078d2e7de2414  vmovaps [rsp+0x60], xmm6
000078d2e7de241a  vmovaps [rsp+0x70], xmm7
000078d2e7de2420  vmovaps [rsp+0x80], xmm8
000078d2e7de2429  vmovaps [rsp+0x90], xmm9
000078d2e7de2432  vmovaps [rsp+0xA0], xmm10
000078d2e7de243b  vmovaps [rsp+0xB0], xmm11
000078d2e7de2444  vmovaps [rsp+0xC0], xmm12
000078d2e7de244d  vmovaps [rsp+0xD0], xmm13
000078d2e7de2456  vmovaps [rsp+0xE0], xmm14
000078d2e7de245f  sub rsp, 0x30
000078d2e7de2463  movaps [rsp], xmm15
000078d2e7de2468  movaps [rsp+0x10], xmm5
000078d2e7de246d  movaps [rsp+0x20], xmm3
000078d2e7de2472  lea rdi, [rsp]
000078d2e7de2476  mov esi, 0x00
000078d2e7de247b  mov rax, 0x5997D2DB1530
000078d2e7de2485  call rax
000078d2e7de2487  movaps xmm15, [rsp]
000078d2e7de248c  add rsp, 0x30
000078d2e7de2490  vmovaps xmm0, [rsp]
000078d2e7de2495  vmovaps xmm1, [rsp+0x10]
000078d2e7de249b  vmovaps xmm2, [rsp+0x20]
000078d2e7de24a1  vmovaps xmm3, [rsp+0x30]
000078d2e7de24a7  vmovaps xmm4, [rsp+0x40]
000078d2e7de24ad  vmovaps xmm5, [rsp+0x50]
000078d2e7de24b3  vmovaps xmm6, [rsp+0x60]
000078d2e7de24b9  vmovaps xmm7, [rsp+0x70]
000078d2e7de24bf  vmovaps xmm8, [rsp+0x80]
000078d2e7de24c8  vmovaps xmm9, [rsp+0x90]
000078d2e7de24d1  vmovaps xmm10, [rsp+0xA0]
000078d2e7de24da  vmovaps xmm11, [rsp+0xB0]
000078d2e7de24e3  vmovaps xmm12, [rsp+0xC0]
000078d2e7de24ec  vmovaps xmm13, [rsp+0xD0]
000078d2e7de24f5  vmovaps xmm14, [rsp+0xE0]
000078d2e7de24fe  add rsp, 0xF0
000078d2e7de2505  pop r11
000078d2e7de2507  pop r10
000078d2e7de2509  pop r9
000078d2e7de250b  pop r8
000078d2e7de250d  pop rsi
000078d2e7de250e  pop rdi
000078d2e7de250f  pop rdx
000078d2e7de2510  pop rcx
000078d2e7de2511  pop rax
000078d2e7de2512  add rsp, 0x08
000078d2e7de2516  jmp 0x000078D2E7DDF56F
000078d2e7de251b  sub rsp, 0x08
000078d2e7de251f  push rax
000078d2e7de2520  push rcx
000078d2e7de2521  push rdx
000078d2e7de2522  push rdi
000078d2e7de2523  push rsi
000078d2e7de2524  push r8
000078d2e7de2526  push r9
000078d2e7de2528  push r10
000078d2e7de252a  push r11
000078d2e7de252c  sub rsp, 0xF0
000078d2e7de2533  vmovaps [rsp], xmm0
000078d2e7de2538  vmovaps [rsp+0x10], xmm1
000078d2e7de253e  vmovaps [rsp+0x20], xmm2
000078d2e7de2544  vmovaps [rsp+0x30], xmm3
000078d2e7de254a  vmovaps [rsp+0x40], xmm4
000078d2e7de2550  vmovaps [rsp+0x50], xmm6
000078d2e7de2556  vmovaps [rsp+0x60], xmm7
000078d2e7de255c  vmovaps [rsp+0x70], xmm8
000078d2e7de2562  vmovaps [rsp+0x80], xmm9
000078d2e7de256b  vmovaps [rsp+0x90], xmm10
000078d2e7de2574  vmovaps [rsp+0xA0], xmm11
000078d2e7de257d  vmovaps [rsp+0xB0], xmm12
000078d2e7de2586  vmovaps [rsp+0xC0], xmm13
000078d2e7de258f  vmovaps [rsp+0xD0], xmm14
000078d2e7de2598  vmovaps [rsp+0xE0], xmm15
000078d2e7de25a1  sub rsp, 0x30
000078d2e7de25a5  movaps [rsp], xmm5
000078d2e7de25a9  movaps [rsp+0x10], xmm8
000078d2e7de25af  movaps [rsp+0x20], xmm6
000078d2e7de25b4  lea rdi, [rsp]
000078d2e7de25b8  mov esi, 0x00
000078d2e7de25bd  mov rax, 0x5997D2DB1530
000078d2e7de25c7  call rax
000078d2e7de25c9  movaps xmm5, [rsp]
000078d2e7de25cd  add rsp, 0x30
000078d2e7de25d1  vmovaps xmm0, [rsp]
000078d2e7de25d6  vmovaps xmm1, [rsp+0x10]
000078d2e7de25dc  vmovaps xmm2, [rsp+0x20]
000078d2e7de25e2  vmovaps xmm3, [rsp+0x30]
000078d2e7de25e8  vmovaps xmm4, [rsp+0x40]
000078d2e7de25ee  vmovaps xmm6, [rsp+0x50]
000078d2e7de25f4  vmovaps xmm7, [rsp+0x60]
000078d2e7de25fa  vmovaps xmm8, [rsp+0x70]
000078d2e7de2600  vmovaps xmm9, [rsp+0x80]
000078d2e7de2609  vmovaps xmm10, [rsp+0x90]
000078d2e7de2612  vmovaps xmm11, [rsp+0xA0]
000078d2e7de261b  vmovaps xmm12, [rsp+0xB0]
000078d2e7de2624  vmovaps xmm13, [rsp+0xC0]
000078d2e7de262d  vmovaps xmm14, [rsp+0xD0]
000078d2e7de2636  vmovaps xmm15, [rsp+0xE0]
000078d2e7de263f  add rsp, 0xF0
000078d2e7de2646  pop r11
000078d2e7de2648  pop r10
000078d2e7de264a  pop r9
000078d2e7de264c  pop r8
000078d2e7de264e  pop rsi
000078d2e7de264f  pop rdi
000078d2e7de2650  pop rdx
000078d2e7de2651  pop rcx
000078d2e7de2652  pop rax
000078d2e7de2653  add rsp, 0x08
000078d2e7de2657  jmp 0x000078D2E7DDF593
000078d2e7de265c  sub rsp, 0x08
000078d2e7de2660  push rax
000078d2e7de2661  push rcx
000078d2e7de2662  push rdx
000078d2e7de2663  push rdi
000078d2e7de2664  push rsi
000078d2e7de2665  push r8
000078d2e7de2667  push r9
000078d2e7de2669  push r10
000078d2e7de266b  push r11
000078d2e7de266d  sub rsp, 0xF0
000078d2e7de2674  vmovaps [rsp], xmm0
000078d2e7de2679  vmovaps [rsp+0x10], xmm1
000078d2e7de267f  vmovaps [rsp+0x20], xmm2
000078d2e7de2685  vmovaps [rsp+0x30], xmm3
000078d2e7de268b  vmovaps [rsp+0x40], xmm4
000078d2e7de2691  vmovaps [rsp+0x50], xmm5
000078d2e7de2697  vmovaps [rsp+0x60], xmm7
000078d2e7de269d  vmovaps [rsp+0x70], xmm8
000078d2e7de26a3  vmovaps [rsp+0x80], xmm9
000078d2e7de26ac  vmovaps [rsp+0x90], xmm10
000078d2e7de26b5  vmovaps [rsp+0xA0], xmm11
000078d2e7de26be  vmovaps [rsp+0xB0], xmm12
000078d2e7de26c7  vmovaps [rsp+0xC0], xmm13
000078d2e7de26d0  vmovaps [rsp+0xD0], xmm14
000078d2e7de26d9  vmovaps [rsp+0xE0], xmm15
000078d2e7de26e2  sub rsp, 0x30
000078d2e7de26e6  movaps [rsp], xmm6
000078d2e7de26ea  movaps [rsp+0x10], xmm10
000078d2e7de26f0  movaps [rsp+0x20], xmm8
000078d2e7de26f6  lea rdi, [rsp]
000078d2e7de26fa  mov esi, 0x00
000078d2e7de26ff  mov rax, 0x5997D2DB1530
000078d2e7de2709  call rax
000078d2e7de270b  movaps xmm6, [rsp]
000078d2e7de270f  add rsp, 0x30
000078d2e7de2713  vmovaps xmm0, [rsp]
000078d2e7de2718  vmovaps xmm1, [rsp+0x10]
000078d2e7de271e  vmovaps xmm2, [rsp+0x20]
000078d2e7de2724  vmovaps xmm3, [rsp+0x30]
000078d2e7de272a  vmovaps xmm4, [rsp+0x40]
000078d2e7de2730  vmovaps xmm5, [rsp+0x50]
000078d2e7de2736  vmovaps xmm7, [rsp+0x60]
000078d2e7de273c  vmovaps xmm8, [rsp+0x70]
000078d2e7de2742  vmovaps xmm9, [rsp+0x80]
000078d2e7de274b  vmovaps xmm10, [rsp+0x90]
000078d2e7de2754  vmovaps xmm11, [rsp+0xA0]
000078d2e7de275d  vmovaps xmm12, [rsp+0xB0]
000078d2e7de2766  vmovaps xmm13, [rsp+0xC0]
000078d2e7de276f  vmovaps xmm14, [rsp+0xD0]
000078d2e7de2778  vmovaps xmm15, [rsp+0xE0]
000078d2e7de2781  add rsp, 0xF0
000078d2e7de2788  pop r11
000078d2e7de278a  pop r10
000078d2e7de278c  pop r9
000078d2e7de278e  pop r8
000078d2e7de2790  pop rsi
000078d2e7de2791  pop rdi
000078d2e7de2792  pop rdx
000078d2e7de2793  pop rcx
000078d2e7de2794  pop rax
000078d2e7de2795  add rsp, 0x08
000078d2e7de2799  jmp 0x000078D2E7DDF5B8
000078d2e7de279e  sub rsp, 0x08
000078d2e7de27a2  push rax
000078d2e7de27a3  push rcx
000078d2e7de27a4  push rdx
000078d2e7de27a5  push rdi
000078d2e7de27a6  push rsi
000078d2e7de27a7  push r8
000078d2e7de27a9  push r9
000078d2e7de27ab  push r10
000078d2e7de27ad  push r11
000078d2e7de27af  sub rsp, 0xF0
000078d2e7de27b6  vmovaps [rsp], xmm0
000078d2e7de27bb  vmovaps [rsp+0x10], xmm1
000078d2e7de27c1  vmovaps [rsp+0x20], xmm2
000078d2e7de27c7  vmovaps [rsp+0x30], xmm3
000078d2e7de27cd  vmovaps [rsp+0x40], xmm4
000078d2e7de27d3  vmovaps [rsp+0x50], xmm5
000078d2e7de27d9  vmovaps [rsp+0x60], xmm6
000078d2e7de27df  vmovaps [rsp+0x70], xmm7
000078d2e7de27e5  vmovaps [rsp+0x80], xmm8
000078d2e7de27ee  vmovaps [rsp+0x90], xmm9
000078d2e7de27f7  vmovaps [rsp+0xA0], xmm11
000078d2e7de2800  vmovaps [rsp+0xB0], xmm12
000078d2e7de2809  vmovaps [rsp+0xC0], xmm13
000078d2e7de2812  vmovaps [rsp+0xD0], xmm14
000078d2e7de281b  vmovaps [rsp+0xE0], xmm15
000078d2e7de2824  sub rsp, 0x30
000078d2e7de2828  movaps [rsp], xmm10
000078d2e7de282d  movaps [rsp+0x10], xmm8
000078d2e7de2833  movaps [rsp+0x20], xmm14
000078d2e7de2839  lea rdi, [rsp]
000078d2e7de283d  mov esi, 0x00
000078d2e7de2842  mov rax, 0x5997D2DB1530
000078d2e7de284c  call rax
000078d2e7de284e  movaps xmm10, [rsp]
000078d2e7de2853  add rsp, 0x30
000078d2e7de2857  vmovaps xmm0, [rsp]
000078d2e7de285c  vmovaps xmm1, [rsp+0x10]
000078d2e7de2862  vmovaps xmm2, [rsp+0x20]
000078d2e7de2868  vmovaps xmm3, [rsp+0x30]
000078d2e7de286e  vmovaps xmm4, [rsp+0x40]
000078d2e7de2874  vmovaps xmm5, [rsp+0x50]
000078d2e7de287a  vmovaps xmm6, [rsp+0x60]
000078d2e7de2880  vmovaps xmm7, [rsp+0x70]
000078d2e7de2886  vmovaps xmm8, [rsp+0x80]
000078d2e7de288f  vmovaps xmm9, [rsp+0x90]
000078d2e7de2898  vmovaps xmm11, [rsp+0xA0]
000078d2e7de28a1  vmovaps xmm12, [rsp+0xB0]
000078d2e7de28aa  vmovaps xmm13, [rsp+0xC0]
000078d2e7de28b3  vmovaps xmm14, [rsp+0xD0]
000078d2e7de28bc  vmovaps xmm15, [rsp+0xE0]
000078d2e7de28c5  add rsp, 0xF0
000078d2e7de28cc  pop r11
000078d2e7de28ce  pop r10
000078d2e7de28d0  pop r9
000078d2e7de28d2  pop r8
000078d2e7de28d4  pop rsi
000078d2e7de28d5  pop rdi
000078d2e7de28d6  pop rdx
000078d2e7de28d7  pop rcx
000078d2e7de28d8  pop rax
000078d2e7de28d9  add rsp, 0x08
000078d2e7de28dd  jmp 0x000078D2E7DDF5D8
000078d2e7de28e2  sub rsp, 0x08
000078d2e7de28e6  push rax
000078d2e7de28e7  push rcx
000078d2e7de28e8  push rdx
000078d2e7de28e9  push rdi
000078d2e7de28ea  push rsi
000078d2e7de28eb  push r8
000078d2e7de28ed  push r9
000078d2e7de28ef  push r10
000078d2e7de28f1  push r11
000078d2e7de28f3  sub rsp, 0xF0
000078d2e7de28fa  vmovaps [rsp], xmm0
000078d2e7de28ff  vmovaps [rsp+0x10], xmm1
000078d2e7de2905  vmovaps [rsp+0x20], xmm2
000078d2e7de290b  vmovaps [rsp+0x30], xmm3
000078d2e7de2911  vmovaps [rsp+0x40], xmm4
000078d2e7de2917  vmovaps [rsp+0x50], xmm5
000078d2e7de291d  vmovaps [rsp+0x60], xmm6
000078d2e7de2923  vmovaps [rsp+0x70], xmm7
000078d2e7de2929  vmovaps [rsp+0x80], xmm8
000078d2e7de2932  vmovaps [rsp+0x90], xmm9
000078d2e7de293b  vmovaps [rsp+0xA0], xmm10
000078d2e7de2944  vmovaps [rsp+0xB0], xmm11
000078d2e7de294d  vmovaps [rsp+0xC0], xmm12
000078d2e7de2956  vmovaps [rsp+0xD0], xmm13
000078d2e7de295f  vmovaps [rsp+0xE0], xmm15
000078d2e7de2968  sub rsp, 0x30
000078d2e7de296c  movaps [rsp], xmm14
000078d2e7de2971  movaps [rsp+0x10], xmm8
000078d2e7de2977  movaps [rsp+0x20], xmm4
000078d2e7de297c  lea rdi, [rsp]
000078d2e7de2980  mov esi, 0x00
000078d2e7de2985  mov rax, 0x5997D2DB1530
000078d2e7de298f  call rax
000078d2e7de2991  movaps xmm14, [rsp]
000078d2e7de2996  add rsp, 0x30
000078d2e7de299a  vmovaps xmm0, [rsp]
000078d2e7de299f  vmovaps xmm1, [rsp+0x10]
000078d2e7de29a5  vmovaps xmm2, [rsp+0x20]
000078d2e7de29ab  vmovaps xmm3, [rsp+0x30]
000078d2e7de29b1  vmovaps xmm4, [rsp+0x40]
000078d2e7de29b7  vmovaps xmm5, [rsp+0x50]
000078d2e7de29bd  vmovaps xmm6, [rsp+0x60]
000078d2e7de29c3  vmovaps xmm7, [rsp+0x70]
000078d2e7de29c9  vmovaps xmm8, [rsp+0x80]
000078d2e7de29d2  vmovaps xmm9, [rsp+0x90]
000078d2e7de29db  vmovaps xmm10, [rsp+0xA0]
000078d2e7de29e4  vmovaps xmm11, [rsp+0xB0]
000078d2e7de29ed  vmovaps xmm12, [rsp+0xC0]
000078d2e7de29f6  vmovaps xmm13, [rsp+0xD0]
000078d2e7de29ff  vmovaps xmm15, [rsp+0xE0]
000078d2e7de2a08  add rsp, 0xF0
000078d2e7de2a0f  pop r11
000078d2e7de2a11  pop r10
000078d2e7de2a13  pop r9
000078d2e7de2a15  pop r8
000078d2e7de2a17  pop rsi
000078d2e7de2a18  pop rdi
000078d2e7de2a19  pop rdx
000078d2e7de2a1a  pop rcx
000078d2e7de2a1b  pop rax
000078d2e7de2a1c  add rsp, 0x08
000078d2e7de2a20  jmp 0x000078D2E7DDF5F8
000078d2e7de2a25  sub rsp, 0x08
000078d2e7de2a29  push rax
000078d2e7de2a2a  push rcx
000078d2e7de2a2b  push rdx
000078d2e7de2a2c  push rdi
000078d2e7de2a2d  push rsi
000078d2e7de2a2e  push r8
000078d2e7de2a30  push r9
000078d2e7de2a32  push r10
000078d2e7de2a34  push r11
000078d2e7de2a36  sub rsp, 0xF0
000078d2e7de2a3d  vmovaps [rsp], xmm0
000078d2e7de2a42  vmovaps [rsp+0x10], xmm1
000078d2e7de2a48  vmovaps [rsp+0x20], xmm2
000078d2e7de2a4e  vmovaps [rsp+0x30], xmm3
000078d2e7de2a54  vmovaps [rsp+0x40], xmm5
000078d2e7de2a5a  vmovaps [rsp+0x50], xmm6
000078d2e7de2a60  vmovaps [rsp+0x60], xmm7
000078d2e7de2a66  vmovaps [rsp+0x70], xmm8
000078d2e7de2a6c  vmovaps [rsp+0x80], xmm9
000078d2e7de2a75  vmovaps [rsp+0x90], xmm10
000078d2e7de2a7e  vmovaps [rsp+0xA0], xmm11
000078d2e7de2a87  vmovaps [rsp+0xB0], xmm12
000078d2e7de2a90  vmovaps [rsp+0xC0], xmm13
000078d2e7de2a99  vmovaps [rsp+0xD0], xmm14
000078d2e7de2aa2  vmovaps [rsp+0xE0], xmm15
000078d2e7de2aab  sub rsp, 0x30
000078d2e7de2aaf  movaps [rsp], xmm4
000078d2e7de2ab3  movaps [rsp+0x10], xmm13
000078d2e7de2ab9  movaps [rsp+0x20], xmm8
000078d2e7de2abf  lea rdi, [rsp]
000078d2e7de2ac3  mov esi, 0x00
000078d2e7de2ac8  mov rax, 0x5997D2DB1530
000078d2e7de2ad2  call rax
000078d2e7de2ad4  movaps xmm4, [rsp]
000078d2e7de2ad8  add rsp, 0x30
000078d2e7de2adc  vmovaps xmm0, [rsp]
000078d2e7de2ae1  vmovaps xmm1, [rsp+0x10]
000078d2e7de2ae7  vmovaps xmm2, [rsp+0x20]
000078d2e7de2aed  vmovaps xmm3, [rsp+0x30]
000078d2e7de2af3  vmovaps xmm5, [rsp+0x40]
000078d2e7de2af9  vmovaps xmm6, [rsp+0x50]
000078d2e7de2aff  vmovaps xmm7, [rsp+0x60]
000078d2e7de2b05  vmovaps xmm8, [rsp+0x70]
000078d2e7de2b0b  vmovaps xmm9, [rsp+0x80]
000078d2e7de2b14  vmovaps xmm10, [rsp+0x90]
000078d2e7de2b1d  vmovaps xmm11, [rsp+0xA0]
000078d2e7de2b26  vmovaps xmm12, [rsp+0xB0]
000078d2e7de2b2f  vmovaps xmm13, [rsp+0xC0]
000078d2e7de2b38  vmovaps xmm14, [rsp+0xD0]
000078d2e7de2b41  vmovaps xmm15, [rsp+0xE0]
000078d2e7de2b4a  add rsp, 0xF0
000078d2e7de2b51  pop r11
000078d2e7de2b53  pop r10
000078d2e7de2b55  pop r9
000078d2e7de2b57  pop r8
000078d2e7de2b59  pop rsi
000078d2e7de2b5a  pop rdi
000078d2e7de2b5b  pop rdx
000078d2e7de2b5c  pop rcx
000078d2e7de2b5d  pop rax
000078d2e7de2b5e  add rsp, 0x08
000078d2e7de2b62  jmp 0x000078D2E7DDF61D
000078d2e7de2b67  sub rsp, 0x08
000078d2e7de2b6b  push rax
000078d2e7de2b6c  push rcx
000078d2e7de2b6d  push rdx
000078d2e7de2b6e  push rdi
000078d2e7de2b6f  push rsi
000078d2e7de2b70  push r8
000078d2e7de2b72  push r9
000078d2e7de2b74  push r10
000078d2e7de2b76  push r11
000078d2e7de2b78  sub rsp, 0xF0
000078d2e7de2b7f  vmovaps [rsp], xmm0
000078d2e7de2b84  vmovaps [rsp+0x10], xmm1
000078d2e7de2b8a  vmovaps [rsp+0x20], xmm2
000078d2e7de2b90  vmovaps [rsp+0x30], xmm3
000078d2e7de2b96  vmovaps [rsp+0x40], xmm4
000078d2e7de2b9c  vmovaps [rsp+0x50], xmm5
000078d2e7de2ba2  vmovaps [rsp+0x60], xmm6
000078d2e7de2ba8  vmovaps [rsp+0x70], xmm7
000078d2e7de2bae  vmovaps [rsp+0x80], xmm8
000078d2e7de2bb7  vmovaps [rsp+0x90], xmm9
000078d2e7de2bc0  vmovaps [rsp+0xA0], xmm10
000078d2e7de2bc9  vmovaps [rsp+0xB0], xmm11
000078d2e7de2bd2  vmovaps [rsp+0xC0], xmm12
000078d2e7de2bdb  vmovaps [rsp+0xD0], xmm14
000078d2e7de2be4  vmovaps [rsp+0xE0], xmm15
000078d2e7de2bed  sub rsp, 0x30
000078d2e7de2bf1  movaps [rsp], xmm13
000078d2e7de2bf6  movaps [rsp+0x10], xmm15
000078d2e7de2bfc  movaps [rsp+0x20], xmm9
000078d2e7de2c02  lea rdi, [rsp]
000078d2e7de2c06  mov esi, 0x00
000078d2e7de2c0b  mov rax, 0x5997D2DB1530
000078d2e7de2c15  call rax
000078d2e7de2c17  movaps xmm13, [rsp]
000078d2e7de2c1c  add rsp, 0x30
000078d2e7de2c20  vmovaps xmm0, [rsp]
000078d2e7de2c25  vmovaps xmm1, [rsp+0x10]
000078d2e7de2c2b  vmovaps xmm2, [rsp+0x20]
000078d2e7de2c31  vmovaps xmm3, [rsp+0x30]
000078d2e7de2c37  vmovaps xmm4, [rsp+0x40]
000078d2e7de2c3d  vmovaps xmm5, [rsp+0x50]
000078d2e7de2c43  vmovaps xmm6, [rsp+0x60]
000078d2e7de2c49  vmovaps xmm7, [rsp+0x70]
000078d2e7de2c4f  vmovaps xmm8, [rsp+0x80]
000078d2e7de2c58  vmovaps xmm9, [rsp+0x90]
000078d2e7de2c61  vmovaps xmm10, [rsp+0xA0]
000078d2e7de2c6a  vmovaps xmm11, [rsp+0xB0]
000078d2e7de2c73  vmovaps xmm12, [rsp+0xC0]
000078d2e7de2c7c  vmovaps xmm14, [rsp+0xD0]
000078d2e7de2c85  vmovaps xmm15, [rsp+0xE0]
000078d2e7de2c8e  add rsp, 0xF0
000078d2e7de2c95  pop r11
000078d2e7de2c97  pop r10
000078d2e7de2c99  pop r9
000078d2e7de2c9b  pop r8
000078d2e7de2c9d  pop rsi
000078d2e7de2c9e  pop rdi
000078d2e7de2c9f  pop rdx
000078d2e7de2ca0  pop rcx
000078d2e7de2ca1  pop rax
000078d2e7de2ca2  add rsp, 0x08
000078d2e7de2ca6  jmp 0x000078D2E7DDF638
000078d2e7de2cab  sub rsp, 0x08
000078d2e7de2caf  push rax
000078d2e7de2cb0  push rcx
000078d2e7de2cb1  push rdx
000078d2e7de2cb2  push rdi
000078d2e7de2cb3  push rsi
000078d2e7de2cb4  push r8
000078d2e7de2cb6  push r9
000078d2e7de2cb8  push r10
000078d2e7de2cba  push r11
000078d2e7de2cbc  sub rsp, 0xF0
000078d2e7de2cc3  vmovaps [rsp], xmm0
000078d2e7de2cc8  vmovaps [rsp+0x10], xmm1
000078d2e7de2cce  vmovaps [rsp+0x20], xmm2
000078d2e7de2cd4  vmovaps [rsp+0x30], xmm3
000078d2e7de2cda  vmovaps [rsp+0x40], xmm4
000078d2e7de2ce0  vmovaps [rsp+0x50], xmm5
000078d2e7de2ce6  vmovaps [rsp+0x60], xmm6
000078d2e7de2cec  vmovaps [rsp+0x70], xmm7
000078d2e7de2cf2  vmovaps [rsp+0x80], xmm8
000078d2e7de2cfb  vmovaps [rsp+0x90], xmm9
000078d2e7de2d04  vmovaps [rsp+0xA0], xmm10
000078d2e7de2d0d  vmovaps [rsp+0xB0], xmm11
000078d2e7de2d16  vmovaps [rsp+0xC0], xmm12
000078d2e7de2d1f  vmovaps [rsp+0xD0], xmm13
000078d2e7de2d28  vmovaps [rsp+0xE0], xmm14
000078d2e7de2d31  sub rsp, 0x30
000078d2e7de2d35  movaps [rsp], xmm15
000078d2e7de2d3a  movaps [rsp+0x10], xmm1
000078d2e7de2d3f  movaps [rsp+0x20], xmm5
000078d2e7de2d44  lea rdi, [rsp]
000078d2e7de2d48  mov esi, 0x00
000078d2e7de2d4d  mov rax, 0x5997D2DB1530
000078d2e7de2d57  call rax
000078d2e7de2d59  movaps xmm15, [rsp]
000078d2e7de2d5e  add rsp, 0x30
000078d2e7de2d62  vmovaps xmm0, [rsp]
000078d2e7de2d67  vmovaps xmm1, [rsp+0x10]
000078d2e7de2d6d  vmovaps xmm2, [rsp+0x20]
000078d2e7de2d73  vmovaps xmm3, [rsp+0x30]
000078d2e7de2d79  vmovaps xmm4, [rsp+0x40]
000078d2e7de2d7f  vmovaps xmm5, [rsp+0x50]
000078d2e7de2d85  vmovaps xmm6, [rsp+0x60]
000078d2e7de2d8b  vmovaps xmm7, [rsp+0x70]
000078d2e7de2d91  vmovaps xmm8, [rsp+0x80]
000078d2e7de2d9a  vmovaps xmm9, [rsp+0x90]
000078d2e7de2da3  vmovaps xmm10, [rsp+0xA0]
000078d2e7de2dac  vmovaps xmm11, [rsp+0xB0]
000078d2e7de2db5  vmovaps xmm12, [rsp+0xC0]
000078d2e7de2dbe  vmovaps xmm13, [rsp+0xD0]
000078d2e7de2dc7  vmovaps xmm14, [rsp+0xE0]
000078d2e7de2dd0  add rsp, 0xF0
000078d2e7de2dd7  pop r11
000078d2e7de2dd9  pop r10
000078d2e7de2ddb  pop r9
000078d2e7de2ddd  pop r8
000078d2e7de2ddf  pop rsi
000078d2e7de2de0  pop rdi
000078d2e7de2de1  pop rdx
000078d2e7de2de2  pop rcx
000078d2e7de2de3  pop rax
000078d2e7de2de4  add rsp, 0x08
000078d2e7de2de8  jmp 0x000078D2E7DDF653
000078d2e7de2ded  call 0x000078D2E7CB52F0
000078d2e7de2df2  jmp 0x000078D2E7DDF6AE
000078d2e7de2df7  sub rsp, 0x08
000078d2e7de2dfb  push rax
000078d2e7de2dfc  push rcx
000078d2e7de2dfd  push rdx
000078d2e7de2dfe  push rdi
000078d2e7de2dff  push rsi
000078d2e7de2e00  push r8
000078d2e7de2e02  push r9
000078d2e7de2e04  push r10
000078d2e7de2e06  push r11
000078d2e7de2e08  sub rsp, 0xF0
000078d2e7de2e0f  vmovaps [rsp], xmm0
000078d2e7de2e14  vmovaps [rsp+0x10], xmm1
000078d2e7de2e1a  vmovaps [rsp+0x20], xmm2
000078d2e7de2e20  vmovaps [rsp+0x30], xmm3
000078d2e7de2e26  vmovaps [rsp+0x40], xmm4
000078d2e7de2e2c  vmovaps [rsp+0x50], xmm5
000078d2e7de2e32  vmovaps [rsp+0x60], xmm6
000078d2e7de2e38  vmovaps [rsp+0x70], xmm7
000078d2e7de2e3e  vmovaps [rsp+0x80], xmm8
000078d2e7de2e47  vmovaps [rsp+0x90], xmm10
000078d2e7de2e50  vmovaps [rsp+0xA0], xmm11
000078d2e7de2e59  vmovaps [rsp+0xB0], xmm12
000078d2e7de2e62  vmovaps [rsp+0xC0], xmm13
000078d2e7de2e6b  vmovaps [rsp+0xD0], xmm14
000078d2e7de2e74  vmovaps [rsp+0xE0], xmm15
000078d2e7de2e7d  sub rsp, 0x30
000078d2e7de2e81  movaps [rsp], xmm9
000078d2e7de2e86  movaps [rsp+0x10], xmm8
000078d2e7de2e8c  movaps [rsp+0x20], xmm11
000078d2e7de2e92  lea rdi, [rsp]
000078d2e7de2e96  mov esi, 0x00
000078d2e7de2e9b  mov rax, 0x5997D2DB1530
000078d2e7de2ea5  call rax
000078d2e7de2ea7  movaps xmm9, [rsp]
000078d2e7de2eac  add rsp, 0x30
000078d2e7de2eb0  vmovaps xmm0, [rsp]
000078d2e7de2eb5  vmovaps xmm1, [rsp+0x10]
000078d2e7de2ebb  vmovaps xmm2, [rsp+0x20]
000078d2e7de2ec1  vmovaps xmm3, [rsp+0x30]
000078d2e7de2ec7  vmovaps xmm4, [rsp+0x40]
000078d2e7de2ecd  vmovaps xmm5, [rsp+0x50]
000078d2e7de2ed3  vmovaps xmm6, [rsp+0x60]
000078d2e7de2ed9  vmovaps xmm7, [rsp+0x70]
000078d2e7de2edf  vmovaps xmm8, [rsp+0x80]
000078d2e7de2ee8  vmovaps xmm10, [rsp+0x90]
000078d2e7de2ef1  vmovaps xmm11, [rsp+0xA0]
000078d2e7de2efa  vmovaps xmm12, [rsp+0xB0]
000078d2e7de2f03  vmovaps xmm13, [rsp+0xC0]
000078d2e7de2f0c  vmovaps xmm14, [rsp+0xD0]
000078d2e7de2f15  vmovaps xmm15, [rsp+0xE0]
000078d2e7de2f1e  add rsp, 0xF0
000078d2e7de2f25  pop r11
000078d2e7de2f27  pop r10
000078d2e7de2f29  pop r9
000078d2e7de2f2b  pop r8
000078d2e7de2f2d  pop rsi
000078d2e7de2f2e  pop rdi
000078d2e7de2f2f  pop rdx
000078d2e7de2f30  pop rcx
000078d2e7de2f31  pop rax
000078d2e7de2f32  add rsp, 0x08
000078d2e7de2f36  jmp 0x000078D2E7DDF6E5
000078d2e7de2f3b  sub rsp, 0x08
000078d2e7de2f3f  push rax
000078d2e7de2f40  push rcx
000078d2e7de2f41  push rdx
000078d2e7de2f42  push rdi
000078d2e7de2f43  push rsi
000078d2e7de2f44  push r8
000078d2e7de2f46  push r9
000078d2e7de2f48  push r10
000078d2e7de2f4a  push r11
000078d2e7de2f4c  sub rsp, 0xF0
000078d2e7de2f53  vmovaps [rsp], xmm0
000078d2e7de2f58  vmovaps [rsp+0x10], xmm1
000078d2e7de2f5e  vmovaps [rsp+0x20], xmm2
000078d2e7de2f64  vmovaps [rsp+0x30], xmm3
000078d2e7de2f6a  vmovaps [rsp+0x40], xmm4
000078d2e7de2f70  vmovaps [rsp+0x50], xmm5
000078d2e7de2f76  vmovaps [rsp+0x60], xmm6
000078d2e7de2f7c  vmovaps [rsp+0x70], xmm7
000078d2e7de2f82  vmovaps [rsp+0x80], xmm8
000078d2e7de2f8b  vmovaps [rsp+0x90], xmm9
000078d2e7de2f94  vmovaps [rsp+0xA0], xmm10
000078d2e7de2f9d  vmovaps [rsp+0xB0], xmm12
000078d2e7de2fa6  vmovaps [rsp+0xC0], xmm13
000078d2e7de2faf  vmovaps [rsp+0xD0], xmm14
000078d2e7de2fb8  vmovaps [rsp+0xE0], xmm15
000078d2e7de2fc1  sub rsp, 0x30
000078d2e7de2fc5  movaps [rsp], xmm11
000078d2e7de2fca  movaps [rsp+0x10], xmm10
000078d2e7de2fd0  movaps [rsp+0x20], xmm6
000078d2e7de2fd5  lea rdi, [rsp]
000078d2e7de2fd9  mov esi, 0x00
000078d2e7de2fde  mov rax, 0x5997D2DB1530
000078d2e7de2fe8  call rax
000078d2e7de2fea  movaps xmm11, [rsp]
000078d2e7de2fef  add rsp, 0x30
000078d2e7de2ff3  vmovaps xmm0, [rsp]
000078d2e7de2ff8  vmovaps xmm1, [rsp+0x10]
000078d2e7de2ffe  vmovaps xmm2, [rsp+0x20]
000078d2e7de3004  vmovaps xmm3, [rsp+0x30]
000078d2e7de300a  vmovaps xmm4, [rsp+0x40]
000078d2e7de3010  vmovaps xmm5, [rsp+0x50]
000078d2e7de3016  vmovaps xmm6, [rsp+0x60]
000078d2e7de301c  vmovaps xmm7, [rsp+0x70]
000078d2e7de3022  vmovaps xmm8, [rsp+0x80]
000078d2e7de302b  vmovaps xmm9, [rsp+0x90]
000078d2e7de3034  vmovaps xmm10, [rsp+0xA0]
000078d2e7de303d  vmovaps xmm12, [rsp+0xB0]
000078d2e7de3046  vmovaps xmm13, [rsp+0xC0]
000078d2e7de304f  vmovaps xmm14, [rsp+0xD0]
000078d2e7de3058  vmovaps xmm15, [rsp+0xE0]
000078d2e7de3061  add rsp, 0xF0
000078d2e7de3068  pop r11
000078d2e7de306a  pop r10
000078d2e7de306c  pop r9
000078d2e7de306e  pop r8
000078d2e7de3070  pop rsi
000078d2e7de3071  pop rdi
000078d2e7de3072  pop rdx
000078d2e7de3073  pop rcx
000078d2e7de3074  pop rax
000078d2e7de3075  add rsp, 0x08
000078d2e7de3079  jmp 0x000078D2E7DDF700
000078d2e7de307e  sub rsp, 0x08
000078d2e7de3082  push rax
000078d2e7de3083  push rcx
000078d2e7de3084  push rdx
000078d2e7de3085  push rdi
000078d2e7de3086  push rsi
000078d2e7de3087  push r8
000078d2e7de3089  push r9
000078d2e7de308b  push r10
000078d2e7de308d  push r11
000078d2e7de308f  sub rsp, 0xF0
000078d2e7de3096  vmovaps [rsp], xmm0
000078d2e7de309b  vmovaps [rsp+0x10], xmm1
000078d2e7de30a1  vmovaps [rsp+0x20], xmm2
000078d2e7de30a7  vmovaps [rsp+0x30], xmm3
000078d2e7de30ad  vmovaps [rsp+0x40], xmm4
000078d2e7de30b3  vmovaps [rsp+0x50], xmm5
000078d2e7de30b9  vmovaps [rsp+0x60], xmm6
000078d2e7de30bf  vmovaps [rsp+0x70], xmm7
000078d2e7de30c5  vmovaps [rsp+0x80], xmm8
000078d2e7de30ce  vmovaps [rsp+0x90], xmm9
000078d2e7de30d7  vmovaps [rsp+0xA0], xmm11
000078d2e7de30e0  vmovaps [rsp+0xB0], xmm12
000078d2e7de30e9  vmovaps [rsp+0xC0], xmm13
000078d2e7de30f2  vmovaps [rsp+0xD0], xmm14
000078d2e7de30fb  vmovaps [rsp+0xE0], xmm15
000078d2e7de3104  sub rsp, 0x30
000078d2e7de3108  movaps [rsp], xmm10
000078d2e7de310d  movaps [rsp+0x10], xmm14
000078d2e7de3113  movaps [rsp+0x20], xmm4
000078d2e7de3118  lea rdi, [rsp]
000078d2e7de311c  mov esi, 0x00
000078d2e7de3121  mov rax, 0x5997D2DB1530
000078d2e7de312b  call rax
000078d2e7de312d  movaps xmm10, [rsp]
000078d2e7de3132  add rsp, 0x30
000078d2e7de3136  vmovaps xmm0, [rsp]
000078d2e7de313b  vmovaps xmm1, [rsp+0x10]
000078d2e7de3141  vmovaps xmm2, [rsp+0x20]
000078d2e7de3147  vmovaps xmm3, [rsp+0x30]
000078d2e7de314d  vmovaps xmm4, [rsp+0x40]
000078d2e7de3153  vmovaps xmm5, [rsp+0x50]
000078d2e7de3159  vmovaps xmm6, [rsp+0x60]
000078d2e7de315f  vmovaps xmm7, [rsp+0x70]
000078d2e7de3165  vmovaps xmm8, [rsp+0x80]
000078d2e7de316e  vmovaps xmm9, [rsp+0x90]
000078d2e7de3177  vmovaps xmm11, [rsp+0xA0]
000078d2e7de3180  vmovaps xmm12, [rsp+0xB0]
000078d2e7de3189  vmovaps xmm13, [rsp+0xC0]
000078d2e7de3192  vmovaps xmm14, [rsp+0xD0]
000078d2e7de319b  vmovaps xmm15, [rsp+0xE0]
000078d2e7de31a4  add rsp, 0xF0
000078d2e7de31ab  pop r11
000078d2e7de31ad  pop r10
000078d2e7de31af  pop r9
000078d2e7de31b1  pop r8
000078d2e7de31b3  pop rsi
000078d2e7de31b4  pop rdi
000078d2e7de31b5  pop rdx
000078d2e7de31b6  pop rcx
000078d2e7de31b7  pop rax
000078d2e7de31b8  add rsp, 0x08
000078d2e7de31bc  jmp 0x000078D2E7DDF71B
000078d2e7de31c1  sub rsp, 0x08
000078d2e7de31c5  push rax
000078d2e7de31c6  push rcx
000078d2e7de31c7  push rdx
000078d2e7de31c8  push rdi
000078d2e7de31c9  push rsi
000078d2e7de31ca  push r8
000078d2e7de31cc  push r9
000078d2e7de31ce  push r10
000078d2e7de31d0  push r11
000078d2e7de31d2  sub rsp, 0xF0
000078d2e7de31d9  vmovaps [rsp], xmm0
000078d2e7de31de  vmovaps [rsp+0x10], xmm1
000078d2e7de31e4  vmovaps [rsp+0x20], xmm2
000078d2e7de31ea  vmovaps [rsp+0x30], xmm3
000078d2e7de31f0  vmovaps [rsp+0x40], xmm4
000078d2e7de31f6  vmovaps [rsp+0x50], xmm5
000078d2e7de31fc  vmovaps [rsp+0x60], xmm6
000078d2e7de3202  vmovaps [rsp+0x70], xmm7
000078d2e7de3208  vmovaps [rsp+0x80], xmm9
000078d2e7de3211  vmovaps [rsp+0x90], xmm10
000078d2e7de321a  vmovaps [rsp+0xA0], xmm11
000078d2e7de3223  vmovaps [rsp+0xB0], xmm12
000078d2e7de322c  vmovaps [rsp+0xC0], xmm13
000078d2e7de3235  vmovaps [rsp+0xD0], xmm14
000078d2e7de323e  vmovaps [rsp+0xE0], xmm15
000078d2e7de3247  sub rsp, 0x30
000078d2e7de324b  movaps [rsp], xmm8
000078d2e7de3250  movaps [rsp+0x10], xmm1
000078d2e7de3255  movaps [rsp+0x20], xmm14
000078d2e7de325b  lea rdi, [rsp]
000078d2e7de325f  mov esi, 0x00
000078d2e7de3264  mov rax, 0x5997D2DB1530
000078d2e7de326e  call rax
000078d2e7de3270  movaps xmm8, [rsp]
000078d2e7de3275  add rsp, 0x30
000078d2e7de3279  vmovaps xmm0, [rsp]
000078d2e7de327e  vmovaps xmm1, [rsp+0x10]
000078d2e7de3284  vmovaps xmm2, [rsp+0x20]
000078d2e7de328a  vmovaps xmm3, [rsp+0x30]
000078d2e7de3290  vmovaps xmm4, [rsp+0x40]
000078d2e7de3296  vmovaps xmm5, [rsp+0x50]
000078d2e7de329c  vmovaps xmm6, [rsp+0x60]
000078d2e7de32a2  vmovaps xmm7, [rsp+0x70]
000078d2e7de32a8  vmovaps xmm9, [rsp+0x80]
000078d2e7de32b1  vmovaps xmm10, [rsp+0x90]
000078d2e7de32ba  vmovaps xmm11, [rsp+0xA0]
000078d2e7de32c3  vmovaps xmm12, [rsp+0xB0]
000078d2e7de32cc  vmovaps xmm13, [rsp+0xC0]
000078d2e7de32d5  vmovaps xmm14, [rsp+0xD0]
000078d2e7de32de  vmovaps xmm15, [rsp+0xE0]
000078d2e7de32e7  add rsp, 0xF0
000078d2e7de32ee  pop r11
000078d2e7de32f0  pop r10
000078d2e7de32f2  pop r9
000078d2e7de32f4  pop r8
000078d2e7de32f6  pop rsi
000078d2e7de32f7  pop rdi
000078d2e7de32f8  pop rdx
000078d2e7de32f9  pop rcx
000078d2e7de32fa  pop rax
000078d2e7de32fb  add rsp, 0x08
000078d2e7de32ff  jmp 0x000078D2E7DDF741
000078d2e7de3304  sub rsp, 0x08
000078d2e7de3308  push rax
000078d2e7de3309  push rcx
000078d2e7de330a  push rdx
000078d2e7de330b  push rdi
000078d2e7de330c  push rsi
000078d2e7de330d  push r8
000078d2e7de330f  push r9
000078d2e7de3311  push r10
000078d2e7de3313  push r11
000078d2e7de3315  sub rsp, 0xF0
000078d2e7de331c  vmovaps [rsp], xmm0
000078d2e7de3321  vmovaps [rsp+0x10], xmm1
000078d2e7de3327  vmovaps [rsp+0x20], xmm2
000078d2e7de332d  vmovaps [rsp+0x30], xmm3
000078d2e7de3333  vmovaps [rsp+0x40], xmm4
000078d2e7de3339  vmovaps [rsp+0x50], xmm5
000078d2e7de333f  vmovaps [rsp+0x60], xmm7
000078d2e7de3345  vmovaps [rsp+0x70], xmm8
000078d2e7de334b  vmovaps [rsp+0x80], xmm9
000078d2e7de3354  vmovaps [rsp+0x90], xmm10
000078d2e7de335d  vmovaps [rsp+0xA0], xmm11
000078d2e7de3366  vmovaps [rsp+0xB0], xmm12
000078d2e7de336f  vmovaps [rsp+0xC0], xmm13
000078d2e7de3378  vmovaps [rsp+0xD0], xmm14
000078d2e7de3381  vmovaps [rsp+0xE0], xmm15
000078d2e7de338a  sub rsp, 0x30
000078d2e7de338e  movaps [rsp], xmm6
000078d2e7de3392  movaps [rsp+0x10], xmm1
000078d2e7de3397  movaps [rsp+0x20], xmm14
000078d2e7de339d  lea rdi, [rsp]
000078d2e7de33a1  mov esi, 0x00
000078d2e7de33a6  mov rax, 0x5997D2DB1530
000078d2e7de33b0  call rax
000078d2e7de33b2  movaps xmm6, [rsp]
000078d2e7de33b6  add rsp, 0x30
000078d2e7de33ba  vmovaps xmm0, [rsp]
000078d2e7de33bf  vmovaps xmm1, [rsp+0x10]
000078d2e7de33c5  vmovaps xmm2, [rsp+0x20]
000078d2e7de33cb  vmovaps xmm3, [rsp+0x30]
000078d2e7de33d1  vmovaps xmm4, [rsp+0x40]
000078d2e7de33d7  vmovaps xmm5, [rsp+0x50]
000078d2e7de33dd  vmovaps xmm7, [rsp+0x60]
000078d2e7de33e3  vmovaps xmm8, [rsp+0x70]
000078d2e7de33e9  vmovaps xmm9, [rsp+0x80]
000078d2e7de33f2  vmovaps xmm10, [rsp+0x90]
000078d2e7de33fb  vmovaps xmm11, [rsp+0xA0]
000078d2e7de3404  vmovaps xmm12, [rsp+0xB0]
000078d2e7de340d  vmovaps xmm13, [rsp+0xC0]
000078d2e7de3416  vmovaps xmm14, [rsp+0xD0]
000078d2e7de341f  vmovaps xmm15, [rsp+0xE0]
000078d2e7de3428  add rsp, 0xF0
000078d2e7de342f  pop r11
000078d2e7de3431  pop r10
000078d2e7de3433  pop r9
000078d2e7de3435  pop r8
000078d2e7de3437  pop rsi
000078d2e7de3438  pop rdi
000078d2e7de3439  pop rdx
000078d2e7de343a  pop rcx
000078d2e7de343b  pop rax
000078d2e7de343c  add rsp, 0x08
000078d2e7de3440  jmp 0x000078D2E7DDF76D
000078d2e7de3445  sub rsp, 0x08
000078d2e7de3449  push rax
000078d2e7de344a  push rcx
000078d2e7de344b  push rdx
000078d2e7de344c  push rdi
000078d2e7de344d  push rsi
000078d2e7de344e  push r8
000078d2e7de3450  push r9
000078d2e7de3452  push r10
000078d2e7de3454  push r11
000078d2e7de3456  sub rsp, 0xF0
000078d2e7de345d  vmovaps [rsp], xmm0
000078d2e7de3462  vmovaps [rsp+0x10], xmm1
000078d2e7de3468  vmovaps [rsp+0x20], xmm2
000078d2e7de346e  vmovaps [rsp+0x30], xmm3
000078d2e7de3474  vmovaps [rsp+0x40], xmm4
000078d2e7de347a  vmovaps [rsp+0x50], xmm5
000078d2e7de3480  vmovaps [rsp+0x60], xmm6
000078d2e7de3486  vmovaps [rsp+0x70], xmm7
000078d2e7de348c  vmovaps [rsp+0x80], xmm8
000078d2e7de3495  vmovaps [rsp+0x90], xmm9
000078d2e7de349e  vmovaps [rsp+0xA0], xmm10
000078d2e7de34a7  vmovaps [rsp+0xB0], xmm11
000078d2e7de34b0  vmovaps [rsp+0xC0], xmm12
000078d2e7de34b9  vmovaps [rsp+0xD0], xmm13
000078d2e7de34c2  vmovaps [rsp+0xE0], xmm15
000078d2e7de34cb  sub rsp, 0x30
000078d2e7de34cf  movaps [rsp], xmm14
000078d2e7de34d4  movaps [rsp+0x10], xmm12
000078d2e7de34da  movaps [rsp+0x20], xmm1
000078d2e7de34df  lea rdi, [rsp]
000078d2e7de34e3  mov esi, 0x00
000078d2e7de34e8  mov rax, 0x5997D2DB1530
000078d2e7de34f2  call rax
000078d2e7de34f4  movaps xmm14, [rsp]
000078d2e7de34f9  add rsp, 0x30
000078d2e7de34fd  vmovaps xmm0, [rsp]
000078d2e7de3502  vmovaps xmm1, [rsp+0x10]
000078d2e7de3508  vmovaps xmm2, [rsp+0x20]
000078d2e7de350e  vmovaps xmm3, [rsp+0x30]
000078d2e7de3514  vmovaps xmm4, [rsp+0x40]
000078d2e7de351a  vmovaps xmm5, [rsp+0x50]
000078d2e7de3520  vmovaps xmm6, [rsp+0x60]
000078d2e7de3526  vmovaps xmm7, [rsp+0x70]
000078d2e7de352c  vmovaps xmm8, [rsp+0x80]
000078d2e7de3535  vmovaps xmm9, [rsp+0x90]
000078d2e7de353e  vmovaps xmm10, [rsp+0xA0]
000078d2e7de3547  vmovaps xmm11, [rsp+0xB0]
000078d2e7de3550  vmovaps xmm12, [rsp+0xC0]
000078d2e7de3559  vmovaps xmm13, [rsp+0xD0]
000078d2e7de3562  vmovaps xmm15, [rsp+0xE0]
000078d2e7de356b  add rsp, 0xF0
000078d2e7de3572  pop r11
000078d2e7de3574  pop r10
000078d2e7de3576  pop r9
000078d2e7de3578  pop r8
000078d2e7de357a  pop rsi
000078d2e7de357b  pop rdi
000078d2e7de357c  pop rdx
000078d2e7de357d  pop rcx
000078d2e7de357e  pop rax
000078d2e7de357f  add rsp, 0x08
000078d2e7de3583  jmp 0x000078D2E7DDF793
000078d2e7de3588  sub rsp, 0x08
000078d2e7de358c  push rax
000078d2e7de358d  push rcx
000078d2e7de358e  push rdx
000078d2e7de358f  push rdi
000078d2e7de3590  push rsi
000078d2e7de3591  push r8
000078d2e7de3593  push r9
000078d2e7de3595  push r10
000078d2e7de3597  push r11
000078d2e7de3599  sub rsp, 0xF0
000078d2e7de35a0  vmovaps [rsp], xmm0
000078d2e7de35a5  vmovaps [rsp+0x10], xmm2
000078d2e7de35ab  vmovaps [rsp+0x20], xmm3
000078d2e7de35b1  vmovaps [rsp+0x30], xmm4
000078d2e7de35b7  vmovaps [rsp+0x40], xmm5
000078d2e7de35bd  vmovaps [rsp+0x50], xmm6
000078d2e7de35c3  vmovaps [rsp+0x60], xmm7
000078d2e7de35c9  vmovaps [rsp+0x70], xmm8
000078d2e7de35cf  vmovaps [rsp+0x80], xmm9
000078d2e7de35d8  vmovaps [rsp+0x90], xmm10
000078d2e7de35e1  vmovaps [rsp+0xA0], xmm11
000078d2e7de35ea  vmovaps [rsp+0xB0], xmm12
000078d2e7de35f3  vmovaps [rsp+0xC0], xmm13
000078d2e7de35fc  vmovaps [rsp+0xD0], xmm14
000078d2e7de3605  vmovaps [rsp+0xE0], xmm15
000078d2e7de360e  sub rsp, 0x30
000078d2e7de3612  movaps [rsp], xmm1
000078d2e7de3616  movaps [rsp+0x10], xmm13
000078d2e7de361c  movaps [rsp+0x20], xmm9
000078d2e7de3622  lea rdi, [rsp]
000078d2e7de3626  mov esi, 0x00
000078d2e7de362b  mov rax, 0x5997D2DB1530
000078d2e7de3635  call rax
000078d2e7de3637  movaps xmm1, [rsp]
000078d2e7de363b  add rsp, 0x30
000078d2e7de363f  vmovaps xmm0, [rsp]
000078d2e7de3644  vmovaps xmm2, [rsp+0x10]
000078d2e7de364a  vmovaps xmm3, [rsp+0x20]
000078d2e7de3650  vmovaps xmm4, [rsp+0x30]
000078d2e7de3656  vmovaps xmm5, [rsp+0x40]
000078d2e7de365c  vmovaps xmm6, [rsp+0x50]
000078d2e7de3662  vmovaps xmm7, [rsp+0x60]
000078d2e7de3668  vmovaps xmm8, [rsp+0x70]
000078d2e7de366e  vmovaps xmm9, [rsp+0x80]
000078d2e7de3677  vmovaps xmm10, [rsp+0x90]
000078d2e7de3680  vmovaps xmm11, [rsp+0xA0]
000078d2e7de3689  vmovaps xmm12, [rsp+0xB0]
000078d2e7de3692  vmovaps xmm13, [rsp+0xC0]
000078d2e7de369b  vmovaps xmm14, [rsp+0xD0]
000078d2e7de36a4  vmovaps xmm15, [rsp+0xE0]
000078d2e7de36ad  add rsp, 0xF0
000078d2e7de36b4  pop r11
000078d2e7de36b6  pop r10
000078d2e7de36b8  pop r9
000078d2e7de36ba  pop r8
000078d2e7de36bc  pop rsi
000078d2e7de36bd  pop rdi
000078d2e7de36be  pop rdx
000078d2e7de36bf  pop rcx
000078d2e7de36c0  pop rax
000078d2e7de36c1  add rsp, 0x08
000078d2e7de36c5  jmp 0x000078D2E7DDF7AD
000078d2e7de36ca  sub rsp, 0x08
000078d2e7de36ce  push rax
000078d2e7de36cf  push rcx
000078d2e7de36d0  push rdx
000078d2e7de36d1  push rdi
000078d2e7de36d2  push rsi
000078d2e7de36d3  push r8
000078d2e7de36d5  push r9
000078d2e7de36d7  push r10
000078d2e7de36d9  push r11
000078d2e7de36db  sub rsp, 0xF0
000078d2e7de36e2  vmovaps [rsp], xmm0
000078d2e7de36e7  vmovaps [rsp+0x10], xmm1
000078d2e7de36ed  vmovaps [rsp+0x20], xmm2
000078d2e7de36f3  vmovaps [rsp+0x30], xmm3
000078d2e7de36f9  vmovaps [rsp+0x40], xmm4
000078d2e7de36ff  vmovaps [rsp+0x50], xmm5
000078d2e7de3705  vmovaps [rsp+0x60], xmm6
000078d2e7de370b  vmovaps [rsp+0x70], xmm7
000078d2e7de3711  vmovaps [rsp+0x80], xmm8
000078d2e7de371a  vmovaps [rsp+0x90], xmm9
000078d2e7de3723  vmovaps [rsp+0xA0], xmm10
000078d2e7de372c  vmovaps [rsp+0xB0], xmm11
000078d2e7de3735  vmovaps [rsp+0xC0], xmm13
000078d2e7de373e  vmovaps [rsp+0xD0], xmm14
000078d2e7de3747  vmovaps [rsp+0xE0], xmm15
000078d2e7de3750  sub rsp, 0x30
000078d2e7de3754  movaps [rsp], xmm12
000078d2e7de3759  movaps [rsp+0x10], xmm7
000078d2e7de375e  movaps [rsp+0x20], xmm13
000078d2e7de3764  lea rdi, [rsp]
000078d2e7de3768  mov esi, 0x00
000078d2e7de376d  mov rax, 0x5997D2DB1530
000078d2e7de3777  call rax
000078d2e7de3779  movaps xmm12, [rsp]
000078d2e7de377e  add rsp, 0x30
000078d2e7de3782  vmovaps xmm0, [rsp]
000078d2e7de3787  vmovaps xmm1, [rsp+0x10]
000078d2e7de378d  vmovaps xmm2, [rsp+0x20]
000078d2e7de3793  vmovaps xmm3, [rsp+0x30]
000078d2e7de3799  vmovaps xmm4, [rsp+0x40]
000078d2e7de379f  vmovaps xmm5, [rsp+0x50]
000078d2e7de37a5  vmovaps xmm6, [rsp+0x60]
000078d2e7de37ab  vmovaps xmm7, [rsp+0x70]
000078d2e7de37b1  vmovaps xmm8, [rsp+0x80]
000078d2e7de37ba  vmovaps xmm9, [rsp+0x90]
000078d2e7de37c3  vmovaps xmm10, [rsp+0xA0]
000078d2e7de37cc  vmovaps xmm11, [rsp+0xB0]
000078d2e7de37d5  vmovaps xmm13, [rsp+0xC0]
000078d2e7de37de  vmovaps xmm14, [rsp+0xD0]
000078d2e7de37e7  vmovaps xmm15, [rsp+0xE0]
000078d2e7de37f0  add rsp, 0xF0
000078d2e7de37f7  pop r11
000078d2e7de37f9  pop r10
000078d2e7de37fb  pop r9
000078d2e7de37fd  pop r8
000078d2e7de37ff  pop rsi
000078d2e7de3800  pop rdi
000078d2e7de3801  pop rdx
000078d2e7de3802  pop rcx
000078d2e7de3803  pop rax
000078d2e7de3804  add rsp, 0x08
000078d2e7de3808  jmp 0x000078D2E7DDF7D4
000078d2e7de380d  sub rsp, 0x08
000078d2e7de3811  push rax
000078d2e7de3812  push rcx
000078d2e7de3813  push rdx
000078d2e7de3814  push rdi
000078d2e7de3815  push rsi
000078d2e7de3816  push r8
000078d2e7de3818  push r9
000078d2e7de381a  push r10
000078d2e7de381c  push r11
000078d2e7de381e  sub rsp, 0xF0
000078d2e7de3825  vmovaps [rsp], xmm0
000078d2e7de382a  vmovaps [rsp+0x10], xmm1
000078d2e7de3830  vmovaps [rsp+0x20], xmm2
000078d2e7de3836  vmovaps [rsp+0x30], xmm3
000078d2e7de383c  vmovaps [rsp+0x40], xmm4
000078d2e7de3842  vmovaps [rsp+0x50], xmm5
000078d2e7de3848  vmovaps [rsp+0x60], xmm6
000078d2e7de384e  vmovaps [rsp+0x70], xmm7
000078d2e7de3854  vmovaps [rsp+0x80], xmm8
000078d2e7de385d  vmovaps [rsp+0x90], xmm9
000078d2e7de3866  vmovaps [rsp+0xA0], xmm10
000078d2e7de386f  vmovaps [rsp+0xB0], xmm11
000078d2e7de3878  vmovaps [rsp+0xC0], xmm12
000078d2e7de3881  vmovaps [rsp+0xD0], xmm14
000078d2e7de388a  vmovaps [rsp+0xE0], xmm15
000078d2e7de3893  sub rsp, 0x30
000078d2e7de3897  movaps [rsp], xmm13
000078d2e7de389c  movaps [rsp+0x10], xmm15
000078d2e7de38a2  movaps [rsp+0x20], xmm8
000078d2e7de38a8  lea rdi, [rsp]
000078d2e7de38ac  mov esi, 0x00
000078d2e7de38b1  mov rax, 0x5997D2DB1530
000078d2e7de38bb  call rax
000078d2e7de38bd  movaps xmm13, [rsp]
000078d2e7de38c2  add rsp, 0x30
000078d2e7de38c6  vmovaps xmm0, [rsp]
000078d2e7de38cb  vmovaps xmm1, [rsp+0x10]
000078d2e7de38d1  vmovaps xmm2, [rsp+0x20]
000078d2e7de38d7  vmovaps xmm3, [rsp+0x30]
000078d2e7de38dd  vmovaps xmm4, [rsp+0x40]
000078d2e7de38e3  vmovaps xmm5, [rsp+0x50]
000078d2e7de38e9  vmovaps xmm6, [rsp+0x60]
000078d2e7de38ef  vmovaps xmm7, [rsp+0x70]
000078d2e7de38f5  vmovaps xmm8, [rsp+0x80]
000078d2e7de38fe  vmovaps xmm9, [rsp+0x90]
000078d2e7de3907  vmovaps xmm10, [rsp+0xA0]
000078d2e7de3910  vmovaps xmm11, [rsp+0xB0]
000078d2e7de3919  vmovaps xmm12, [rsp+0xC0]
000078d2e7de3922  vmovaps xmm14, [rsp+0xD0]
000078d2e7de392b  vmovaps xmm15, [rsp+0xE0]
000078d2e7de3934  add rsp, 0xF0
000078d2e7de393b  pop r11
000078d2e7de393d  pop r10
000078d2e7de393f  pop r9
000078d2e7de3941  pop r8
000078d2e7de3943  pop rsi
000078d2e7de3944  pop rdi
000078d2e7de3945  pop rdx
000078d2e7de3946  pop rcx
000078d2e7de3947  pop rax
000078d2e7de3948  add rsp, 0x08
000078d2e7de394c  jmp 0x000078D2E7DDF7EF
000078d2e7de3951  sub rsp, 0x08
000078d2e7de3955  push rax
000078d2e7de3956  push rcx
000078d2e7de3957  push rdx
000078d2e7de3958  push rdi
000078d2e7de3959  push rsi
000078d2e7de395a  push r8
000078d2e7de395c  push r9
000078d2e7de395e  push r10
000078d2e7de3960  push r11
000078d2e7de3962  sub rsp, 0xF0
000078d2e7de3969  vmovaps [rsp], xmm0
000078d2e7de396e  vmovaps [rsp+0x10], xmm1
000078d2e7de3974  vmovaps [rsp+0x20], xmm2
000078d2e7de397a  vmovaps [rsp+0x30], xmm3
000078d2e7de3980  vmovaps [rsp+0x40], xmm4
000078d2e7de3986  vmovaps [rsp+0x50], xmm5
000078d2e7de398c  vmovaps [rsp+0x60], xmm6
000078d2e7de3992  vmovaps [rsp+0x70], xmm7
000078d2e7de3998  vmovaps [rsp+0x80], xmm9
000078d2e7de39a1  vmovaps [rsp+0x90], xmm10
000078d2e7de39aa  vmovaps [rsp+0xA0], xmm11
000078d2e7de39b3  vmovaps [rsp+0xB0], xmm12
000078d2e7de39bc  vmovaps [rsp+0xC0], xmm13
000078d2e7de39c5  vmovaps [rsp+0xD0], xmm14
000078d2e7de39ce  vmovaps [rsp+0xE0], xmm15
000078d2e7de39d7  sub rsp, 0x30
000078d2e7de39db  movaps [rsp], xmm8
000078d2e7de39e0  movaps [rsp+0x10], xmm15
000078d2e7de39e6  movaps [rsp+0x20], xmm9
000078d2e7de39ec  lea rdi, [rsp]
000078d2e7de39f0  mov esi, 0x00
000078d2e7de39f5  mov rax, 0x5997D2DB1530
000078d2e7de39ff  call rax
000078d2e7de3a01  movaps xmm8, [rsp]
000078d2e7de3a06  add rsp, 0x30
000078d2e7de3a0a  vmovaps xmm0, [rsp]
000078d2e7de3a0f  vmovaps xmm1, [rsp+0x10]
000078d2e7de3a15  vmovaps xmm2, [rsp+0x20]
000078d2e7de3a1b  vmovaps xmm3, [rsp+0x30]
000078d2e7de3a21  vmovaps xmm4, [rsp+0x40]
000078d2e7de3a27  vmovaps xmm5, [rsp+0x50]
000078d2e7de3a2d  vmovaps xmm6, [rsp+0x60]
000078d2e7de3a33  vmovaps xmm7, [rsp+0x70]
000078d2e7de3a39  vmovaps xmm9, [rsp+0x80]
000078d2e7de3a42  vmovaps xmm10, [rsp+0x90]
000078d2e7de3a4b  vmovaps xmm11, [rsp+0xA0]
000078d2e7de3a54  vmovaps xmm12, [rsp+0xB0]
000078d2e7de3a5d  vmovaps xmm13, [rsp+0xC0]
000078d2e7de3a66  vmovaps xmm14, [rsp+0xD0]
000078d2e7de3a6f  vmovaps xmm15, [rsp+0xE0]
000078d2e7de3a78  add rsp, 0xF0
000078d2e7de3a7f  pop r11
000078d2e7de3a81  pop r10
000078d2e7de3a83  pop r9
000078d2e7de3a85  pop r8
000078d2e7de3a87  pop rsi
000078d2e7de3a88  pop rdi
000078d2e7de3a89  pop rdx
000078d2e7de3a8a  pop rcx
000078d2e7de3a8b  pop rax
000078d2e7de3a8c  add rsp, 0x08
000078d2e7de3a90  jmp 0x000078D2E7DDF81D
000078d2e7de3a95  sub rsp, 0x08
000078d2e7de3a99  push rax
000078d2e7de3a9a  push rcx
000078d2e7de3a9b  push rdx
000078d2e7de3a9c  push rdi
000078d2e7de3a9d  push rsi
000078d2e7de3a9e  push r8
000078d2e7de3aa0  push r9
000078d2e7de3aa2  push r10
000078d2e7de3aa4  push r11
000078d2e7de3aa6  sub rsp, 0xF0
000078d2e7de3aad  vmovaps [rsp], xmm0
000078d2e7de3ab2  vmovaps [rsp+0x10], xmm1
000078d2e7de3ab8  vmovaps [rsp+0x20], xmm2
000078d2e7de3abe  vmovaps [rsp+0x30], xmm3
000078d2e7de3ac4  vmovaps [rsp+0x40], xmm4
000078d2e7de3aca  vmovaps [rsp+0x50], xmm5
000078d2e7de3ad0  vmovaps [rsp+0x60], xmm6
000078d2e7de3ad6  vmovaps [rsp+0x70], xmm7
000078d2e7de3adc  vmovaps [rsp+0x80], xmm8
000078d2e7de3ae5  vmovaps [rsp+0x90], xmm9
000078d2e7de3aee  vmovaps [rsp+0xA0], xmm10
000078d2e7de3af7  vmovaps [rsp+0xB0], xmm11
000078d2e7de3b00  vmovaps [rsp+0xC0], xmm12
000078d2e7de3b09  vmovaps [rsp+0xD0], xmm13
000078d2e7de3b12  vmovaps [rsp+0xE0], xmm14
000078d2e7de3b1b  sub rsp, 0x30
000078d2e7de3b1f  movaps [rsp], xmm15
000078d2e7de3b24  movaps [rsp+0x10], xmm11
000078d2e7de3b2a  movaps [rsp+0x20], xmm6
000078d2e7de3b2f  lea rdi, [rsp]
000078d2e7de3b33  mov esi, 0x00
000078d2e7de3b38  mov rax, 0x5997D2DB1530
000078d2e7de3b42  call rax
000078d2e7de3b44  movaps xmm15, [rsp]
000078d2e7de3b49  add rsp, 0x30
000078d2e7de3b4d  vmovaps xmm0, [rsp]
000078d2e7de3b52  vmovaps xmm1, [rsp+0x10]
000078d2e7de3b58  vmovaps xmm2, [rsp+0x20]
000078d2e7de3b5e  vmovaps xmm3, [rsp+0x30]
000078d2e7de3b64  vmovaps xmm4, [rsp+0x40]
000078d2e7de3b6a  vmovaps xmm5, [rsp+0x50]
000078d2e7de3b70  vmovaps xmm6, [rsp+0x60]
000078d2e7de3b76  vmovaps xmm7, [rsp+0x70]
000078d2e7de3b7c  vmovaps xmm8, [rsp+0x80]
000078d2e7de3b85  vmovaps xmm9, [rsp+0x90]
000078d2e7de3b8e  vmovaps xmm10, [rsp+0xA0]
000078d2e7de3b97  vmovaps xmm11, [rsp+0xB0]
000078d2e7de3ba0  vmovaps xmm12, [rsp+0xC0]
000078d2e7de3ba9  vmovaps xmm13, [rsp+0xD0]
000078d2e7de3bb2  vmovaps xmm14, [rsp+0xE0]
000078d2e7de3bbb  add rsp, 0xF0
000078d2e7de3bc2  pop r11
000078d2e7de3bc4  pop r10
000078d2e7de3bc6  pop r9
000078d2e7de3bc8  pop r8
000078d2e7de3bca  pop rsi
000078d2e7de3bcb  pop rdi
000078d2e7de3bcc  pop rdx
000078d2e7de3bcd  pop rcx
000078d2e7de3bce  pop rax
000078d2e7de3bcf  add rsp, 0x08
000078d2e7de3bd3  jmp 0x000078D2E7DDF838
000078d2e7de3bd8  sub rsp, 0x08
000078d2e7de3bdc  push rax
000078d2e7de3bdd  push rcx
000078d2e7de3bde  push rdx
000078d2e7de3bdf  push rdi
000078d2e7de3be0  push rsi
000078d2e7de3be1  push r8
000078d2e7de3be3  push r9
000078d2e7de3be5  push r10
000078d2e7de3be7  push r11
000078d2e7de3be9  sub rsp, 0xF0
000078d2e7de3bf0  vmovaps [rsp], xmm0
000078d2e7de3bf5  vmovaps [rsp+0x10], xmm1
000078d2e7de3bfb  vmovaps [rsp+0x20], xmm2
000078d2e7de3c01  vmovaps [rsp+0x30], xmm3
000078d2e7de3c07  vmovaps [rsp+0x40], xmm4
000078d2e7de3c0d  vmovaps [rsp+0x50], xmm5
000078d2e7de3c13  vmovaps [rsp+0x60], xmm6
000078d2e7de3c19  vmovaps [rsp+0x70], xmm8
000078d2e7de3c1f  vmovaps [rsp+0x80], xmm9
000078d2e7de3c28  vmovaps [rsp+0x90], xmm10
000078d2e7de3c31  vmovaps [rsp+0xA0], xmm11
000078d2e7de3c3a  vmovaps [rsp+0xB0], xmm12
000078d2e7de3c43  vmovaps [rsp+0xC0], xmm13
000078d2e7de3c4c  vmovaps [rsp+0xD0], xmm14
000078d2e7de3c55  vmovaps [rsp+0xE0], xmm15
000078d2e7de3c5e  sub rsp, 0x30
000078d2e7de3c62  movaps [rsp], xmm7
000078d2e7de3c66  movaps [rsp+0x10], xmm11
000078d2e7de3c6c  movaps [rsp+0x20], xmm9
000078d2e7de3c72  lea rdi, [rsp]
000078d2e7de3c76  mov esi, 0x00
000078d2e7de3c7b  mov rax, 0x5997D2DB1530
000078d2e7de3c85  call rax
000078d2e7de3c87  movaps xmm7, [rsp]
000078d2e7de3c8b  add rsp, 0x30
000078d2e7de3c8f  vmovaps xmm0, [rsp]
000078d2e7de3c94  vmovaps xmm1, [rsp+0x10]
000078d2e7de3c9a  vmovaps xmm2, [rsp+0x20]
000078d2e7de3ca0  vmovaps xmm3, [rsp+0x30]
000078d2e7de3ca6  vmovaps xmm4, [rsp+0x40]
000078d2e7de3cac  vmovaps xmm5, [rsp+0x50]
000078d2e7de3cb2  vmovaps xmm6, [rsp+0x60]
000078d2e7de3cb8  vmovaps xmm8, [rsp+0x70]
000078d2e7de3cbe  vmovaps xmm9, [rsp+0x80]
000078d2e7de3cc7  vmovaps xmm10, [rsp+0x90]
000078d2e7de3cd0  vmovaps xmm11, [rsp+0xA0]
000078d2e7de3cd9  vmovaps xmm12, [rsp+0xB0]
000078d2e7de3ce2  vmovaps xmm13, [rsp+0xC0]
000078d2e7de3ceb  vmovaps xmm14, [rsp+0xD0]
000078d2e7de3cf4  vmovaps xmm15, [rsp+0xE0]
000078d2e7de3cfd  add rsp, 0xF0
000078d2e7de3d04  pop r11
000078d2e7de3d06  pop r10
000078d2e7de3d08  pop r9
000078d2e7de3d0a  pop r8
000078d2e7de3d0c  pop rsi
000078d2e7de3d0d  pop rdi
000078d2e7de3d0e  pop rdx
000078d2e7de3d0f  pop rcx
000078d2e7de3d10  pop rax
000078d2e7de3d11  add rsp, 0x08
000078d2e7de3d15  jmp 0x000078D2E7DDF865
000078d2e7de3d1a  sub rsp, 0x08
000078d2e7de3d1e  push rax
000078d2e7de3d1f  push rcx
000078d2e7de3d20  push rdx
000078d2e7de3d21  push rdi
000078d2e7de3d22  push rsi
000078d2e7de3d23  push r8
000078d2e7de3d25  push r9
000078d2e7de3d27  push r10
000078d2e7de3d29  push r11
000078d2e7de3d2b  sub rsp, 0xF0
000078d2e7de3d32  vmovaps [rsp], xmm0
000078d2e7de3d37  vmovaps [rsp+0x10], xmm1
000078d2e7de3d3d  vmovaps [rsp+0x20], xmm2
000078d2e7de3d43  vmovaps [rsp+0x30], xmm3
000078d2e7de3d49  vmovaps [rsp+0x40], xmm4
000078d2e7de3d4f  vmovaps [rsp+0x50], xmm5
000078d2e7de3d55  vmovaps [rsp+0x60], xmm6
000078d2e7de3d5b  vmovaps [rsp+0x70], xmm7
000078d2e7de3d61  vmovaps [rsp+0x80], xmm8
000078d2e7de3d6a  vmovaps [rsp+0x90], xmm9
000078d2e7de3d73  vmovaps [rsp+0xA0], xmm10
000078d2e7de3d7c  vmovaps [rsp+0xB0], xmm12
000078d2e7de3d85  vmovaps [rsp+0xC0], xmm13
000078d2e7de3d8e  vmovaps [rsp+0xD0], xmm14
000078d2e7de3d97  vmovaps [rsp+0xE0], xmm15
000078d2e7de3da0  sub rsp, 0x30
000078d2e7de3da4  movaps [rsp], xmm11
000078d2e7de3da9  movaps [rsp+0x10], xmm10
000078d2e7de3daf  movaps [rsp+0x20], xmm14
000078d2e7de3db5  lea rdi, [rsp]
000078d2e7de3db9  mov esi, 0x00
000078d2e7de3dbe  mov rax, 0x5997D2DB1530
000078d2e7de3dc8  call rax
000078d2e7de3dca  movaps xmm11, [rsp]
000078d2e7de3dcf  add rsp, 0x30
000078d2e7de3dd3  vmovaps xmm0, [rsp]
000078d2e7de3dd8  vmovaps xmm1, [rsp+0x10]
000078d2e7de3dde  vmovaps xmm2, [rsp+0x20]
000078d2e7de3de4  vmovaps xmm3, [rsp+0x30]
000078d2e7de3dea  vmovaps xmm4, [rsp+0x40]
000078d2e7de3df0  vmovaps xmm5, [rsp+0x50]
000078d2e7de3df6  vmovaps xmm6, [rsp+0x60]
000078d2e7de3dfc  vmovaps xmm7, [rsp+0x70]
000078d2e7de3e02  vmovaps xmm8, [rsp+0x80]
000078d2e7de3e0b  vmovaps xmm9, [rsp+0x90]
000078d2e7de3e14  vmovaps xmm10, [rsp+0xA0]
000078d2e7de3e1d  vmovaps xmm12, [rsp+0xB0]
000078d2e7de3e26  vmovaps xmm13, [rsp+0xC0]
000078d2e7de3e2f  vmovaps xmm14, [rsp+0xD0]
000078d2e7de3e38  vmovaps xmm15, [rsp+0xE0]
000078d2e7de3e41  add rsp, 0xF0
000078d2e7de3e48  pop r11
000078d2e7de3e4a  pop r10
000078d2e7de3e4c  pop r9
000078d2e7de3e4e  pop r8
000078d2e7de3e50  pop rsi
000078d2e7de3e51  pop rdi
000078d2e7de3e52  pop rdx
000078d2e7de3e53  pop rcx
000078d2e7de3e54  pop rax
000078d2e7de3e55  add rsp, 0x08
000078d2e7de3e59  jmp 0x000078D2E7DDF880
000078d2e7de3e5e  call 0x000078D2E7CC33A0
000078d2e7de3e63  jmp 0x000078D2E7DDF88A
000078d2e7de3e68  sub rsp, 0x08
000078d2e7de3e6c  push rax
000078d2e7de3e6d  push rcx
000078d2e7de3e6e  push rdx
000078d2e7de3e6f  push rdi
000078d2e7de3e70  push rsi
000078d2e7de3e71  push r8
000078d2e7de3e73  push r9
000078d2e7de3e75  push r10
000078d2e7de3e77  push r11
000078d2e7de3e79  sub rsp, 0xF0
000078d2e7de3e80  vmovaps [rsp], xmm0
000078d2e7de3e85  vmovaps [rsp+0x10], xmm1
000078d2e7de3e8b  vmovaps [rsp+0x20], xmm2
000078d2e7de3e91  vmovaps [rsp+0x30], xmm3
000078d2e7de3e97  vmovaps [rsp+0x40], xmm4
000078d2e7de3e9d  vmovaps [rsp+0x50], xmm5
000078d2e7de3ea3  vmovaps [rsp+0x60], xmm6
000078d2e7de3ea9  vmovaps [rsp+0x70], xmm7
000078d2e7de3eaf  vmovaps [rsp+0x80], xmm8
000078d2e7de3eb8  vmovaps [rsp+0x90], xmm9
000078d2e7de3ec1  vmovaps [rsp+0xA0], xmm11
000078d2e7de3eca  vmovaps [rsp+0xB0], xmm12
000078d2e7de3ed3  vmovaps [rsp+0xC0], xmm13
000078d2e7de3edc  vmovaps [rsp+0xD0], xmm14
000078d2e7de3ee5  vmovaps [rsp+0xE0], xmm15
000078d2e7de3eee  sub rsp, 0x30
000078d2e7de3ef2  movaps [rsp], xmm10
000078d2e7de3ef7  movaps [rsp+0x10], xmm1
000078d2e7de3efc  movaps [rsp+0x20], xmm12
000078d2e7de3f02  lea rdi, [rsp]
000078d2e7de3f06  mov esi, 0x00
000078d2e7de3f0b  mov rax, 0x5997D2DB1530
000078d2e7de3f15  call rax
000078d2e7de3f17  movaps xmm10, [rsp]
000078d2e7de3f1c  add rsp, 0x30
000078d2e7de3f20  vmovaps xmm0, [rsp]
000078d2e7de3f25  vmovaps xmm1, [rsp+0x10]
000078d2e7de3f2b  vmovaps xmm2, [rsp+0x20]
000078d2e7de3f31  vmovaps xmm3, [rsp+0x30]
000078d2e7de3f37  vmovaps xmm4, [rsp+0x40]
000078d2e7de3f3d  vmovaps xmm5, [rsp+0x50]
000078d2e7de3f43  vmovaps xmm6, [rsp+0x60]
000078d2e7de3f49  vmovaps xmm7, [rsp+0x70]
000078d2e7de3f4f  vmovaps xmm8, [rsp+0x80]
000078d2e7de3f58  vmovaps xmm9, [rsp+0x90]
000078d2e7de3f61  vmovaps xmm11, [rsp+0xA0]
000078d2e7de3f6a  vmovaps xmm12, [rsp+0xB0]
000078d2e7de3f73  vmovaps xmm13, [rsp+0xC0]
000078d2e7de3f7c  vmovaps xmm14, [rsp+0xD0]
000078d2e7de3f85  vmovaps xmm15, [rsp+0xE0]
000078d2e7de3f8e  add rsp, 0xF0
000078d2e7de3f95  pop r11
000078d2e7de3f97  pop r10
000078d2e7de3f99  pop r9
000078d2e7de3f9b  pop r8
000078d2e7de3f9d  pop rsi
000078d2e7de3f9e  pop rdi
000078d2e7de3f9f  pop rdx
000078d2e7de3fa0  pop rcx
000078d2e7de3fa1  pop rax
000078d2e7de3fa2  add rsp, 0x08
000078d2e7de3fa6  jmp 0x000078D2E7DDF8AD
000078d2e7de3fab  sub rsp, 0x08
000078d2e7de3faf  push rax
000078d2e7de3fb0  push rcx
000078d2e7de3fb1  push rdx
000078d2e7de3fb2  push rdi
000078d2e7de3fb3  push rsi
000078d2e7de3fb4  push r8
000078d2e7de3fb6  push r9
000078d2e7de3fb8  push r10
000078d2e7de3fba  push r11
000078d2e7de3fbc  sub rsp, 0xF0
000078d2e7de3fc3  vmovaps [rsp], xmm0
000078d2e7de3fc8  vmovaps [rsp+0x10], xmm1
000078d2e7de3fce  vmovaps [rsp+0x20], xmm2
000078d2e7de3fd4  vmovaps [rsp+0x30], xmm3
000078d2e7de3fda  vmovaps [rsp+0x40], xmm4
000078d2e7de3fe0  vmovaps [rsp+0x50], xmm5
000078d2e7de3fe6  vmovaps [rsp+0x60], xmm6
000078d2e7de3fec  vmovaps [rsp+0x70], xmm7
000078d2e7de3ff2  vmovaps [rsp+0x80], xmm8
000078d2e7de3ffb  vmovaps [rsp+0x90], xmm9
000078d2e7de4004  vmovaps [rsp+0xA0], xmm10
000078d2e7de400d  vmovaps [rsp+0xB0], xmm11
000078d2e7de4016  vmovaps [rsp+0xC0], xmm13
000078d2e7de401f  vmovaps [rsp+0xD0], xmm14
000078d2e7de4028  vmovaps [rsp+0xE0], xmm15
000078d2e7de4031  sub rsp, 0x30
000078d2e7de4035  movaps [rsp], xmm12
000078d2e7de403a  movaps [rsp+0x10], xmm14
000078d2e7de4040  movaps [rsp+0x20], xmm1
000078d2e7de4045  lea rdi, [rsp]
000078d2e7de4049  mov esi, 0x00
000078d2e7de404e  mov rax, 0x5997D2DB1530
000078d2e7de4058  call rax
000078d2e7de405a  movaps xmm12, [rsp]
000078d2e7de405f  add rsp, 0x30
000078d2e7de4063  vmovaps xmm0, [rsp]
000078d2e7de4068  vmovaps xmm1, [rsp+0x10]
000078d2e7de406e  vmovaps xmm2, [rsp+0x20]
000078d2e7de4074  vmovaps xmm3, [rsp+0x30]
000078d2e7de407a  vmovaps xmm4, [rsp+0x40]
000078d2e7de4080  vmovaps xmm5, [rsp+0x50]
000078d2e7de4086  vmovaps xmm6, [rsp+0x60]
000078d2e7de408c  vmovaps xmm7, [rsp+0x70]
000078d2e7de4092  vmovaps xmm8, [rsp+0x80]
000078d2e7de409b  vmovaps xmm9, [rsp+0x90]
000078d2e7de40a4  vmovaps xmm10, [rsp+0xA0]
000078d2e7de40ad  vmovaps xmm11, [rsp+0xB0]
000078d2e7de40b6  vmovaps xmm13, [rsp+0xC0]
000078d2e7de40bf  vmovaps xmm14, [rsp+0xD0]
000078d2e7de40c8  vmovaps xmm15, [rsp+0xE0]
000078d2e7de40d1  add rsp, 0xF0
000078d2e7de40d8  pop r11
000078d2e7de40da  pop r10
000078d2e7de40dc  pop r9
000078d2e7de40de  pop r8
000078d2e7de40e0  pop rsi
000078d2e7de40e1  pop rdi
000078d2e7de40e2  pop rdx
000078d2e7de40e3  pop rcx
000078d2e7de40e4  pop rax
000078d2e7de40e5  add rsp, 0x08
000078d2e7de40e9  jmp 0x000078D2E7DDF8DC
000078d2e7de40ee  sub rsp, 0x08
000078d2e7de40f2  push rax
000078d2e7de40f3  push rcx
000078d2e7de40f4  push rdx
000078d2e7de40f5  push rdi
000078d2e7de40f6  push rsi
000078d2e7de40f7  push r8
000078d2e7de40f9  push r9
000078d2e7de40fb  push r10
000078d2e7de40fd  push r11
000078d2e7de40ff  sub rsp, 0xF0
000078d2e7de4106  vmovaps [rsp], xmm0
000078d2e7de410b  vmovaps [rsp+0x10], xmm1
000078d2e7de4111  vmovaps [rsp+0x20], xmm2
000078d2e7de4117  vmovaps [rsp+0x30], xmm3
000078d2e7de411d  vmovaps [rsp+0x40], xmm4
000078d2e7de4123  vmovaps [rsp+0x50], xmm5
000078d2e7de4129  vmovaps [rsp+0x60], xmm6
000078d2e7de412f  vmovaps [rsp+0x70], xmm7
000078d2e7de4135  vmovaps [rsp+0x80], xmm8
000078d2e7de413e  vmovaps [rsp+0x90], xmm9
000078d2e7de4147  vmovaps [rsp+0xA0], xmm10
000078d2e7de4150  vmovaps [rsp+0xB0], xmm11
000078d2e7de4159  vmovaps [rsp+0xC0], xmm12
000078d2e7de4162  vmovaps [rsp+0xD0], xmm13
000078d2e7de416b  vmovaps [rsp+0xE0], xmm15
000078d2e7de4174  sub rsp, 0x30
000078d2e7de4178  movaps [rsp], xmm14
000078d2e7de417d  movaps [rsp+0x10], xmm9
000078d2e7de4183  movaps [rsp+0x20], xmm1
000078d2e7de4188  lea rdi, [rsp]
000078d2e7de418c  mov esi, 0x00
000078d2e7de4191  mov rax, 0x5997D2DB1530
000078d2e7de419b  call rax
000078d2e7de419d  movaps xmm14, [rsp]
000078d2e7de41a2  add rsp, 0x30
000078d2e7de41a6  vmovaps xmm0, [rsp]
000078d2e7de41ab  vmovaps xmm1, [rsp+0x10]
000078d2e7de41b1  vmovaps xmm2, [rsp+0x20]
000078d2e7de41b7  vmovaps xmm3, [rsp+0x30]
000078d2e7de41bd  vmovaps xmm4, [rsp+0x40]
000078d2e7de41c3  vmovaps xmm5, [rsp+0x50]
000078d2e7de41c9  vmovaps xmm6, [rsp+0x60]
000078d2e7de41cf  vmovaps xmm7, [rsp+0x70]
000078d2e7de41d5  vmovaps xmm8, [rsp+0x80]
000078d2e7de41de  vmovaps xmm9, [rsp+0x90]
000078d2e7de41e7  vmovaps xmm10, [rsp+0xA0]
000078d2e7de41f0  vmovaps xmm11, [rsp+0xB0]
000078d2e7de41f9  vmovaps xmm12, [rsp+0xC0]
000078d2e7de4202  vmovaps xmm13, [rsp+0xD0]
000078d2e7de420b  vmovaps xmm15, [rsp+0xE0]
000078d2e7de4214  add rsp, 0xF0
000078d2e7de421b  pop r11
000078d2e7de421d  pop r10
000078d2e7de421f  pop r9
000078d2e7de4221  pop r8
000078d2e7de4223  pop rsi
000078d2e7de4224  pop rdi
000078d2e7de4225  pop rdx
000078d2e7de4226  pop rcx
000078d2e7de4227  pop rax
000078d2e7de4228  add rsp, 0x08
000078d2e7de422c  jmp 0x000078D2E7DDF90B
000078d2e7de4231  sub rsp, 0x08
000078d2e7de4235  push rax
000078d2e7de4236  push rcx
000078d2e7de4237  push rdx
000078d2e7de4238  push rdi
000078d2e7de4239  push rsi
000078d2e7de423a  push r8
000078d2e7de423c  push r9
000078d2e7de423e  push r10
000078d2e7de4240  push r11
000078d2e7de4242  sub rsp, 0xF0
000078d2e7de4249  vmovaps [rsp], xmm0
000078d2e7de424e  vmovaps [rsp+0x10], xmm2
000078d2e7de4254  vmovaps [rsp+0x20], xmm3
000078d2e7de425a  vmovaps [rsp+0x30], xmm4
000078d2e7de4260  vmovaps [rsp+0x40], xmm5
000078d2e7de4266  vmovaps [rsp+0x50], xmm6
000078d2e7de426c  vmovaps [rsp+0x60], xmm7
000078d2e7de4272  vmovaps [rsp+0x70], xmm8
000078d2e7de4278  vmovaps [rsp+0x80], xmm9
000078d2e7de4281  vmovaps [rsp+0x90], xmm10
000078d2e7de428a  vmovaps [rsp+0xA0], xmm11
000078d2e7de4293  vmovaps [rsp+0xB0], xmm12
000078d2e7de429c  vmovaps [rsp+0xC0], xmm13
000078d2e7de42a5  vmovaps [rsp+0xD0], xmm14
000078d2e7de42ae  vmovaps [rsp+0xE0], xmm15
000078d2e7de42b7  sub rsp, 0x30
000078d2e7de42bb  movaps [rsp], xmm1
000078d2e7de42bf  movaps [rsp+0x10], xmm13
000078d2e7de42c5  movaps [rsp+0x20], xmm8
000078d2e7de42cb  lea rdi, [rsp]
000078d2e7de42cf  mov esi, 0x00
000078d2e7de42d4  mov rax, 0x5997D2DB1530
000078d2e7de42de  call rax
000078d2e7de42e0  movaps xmm1, [rsp]
000078d2e7de42e4  add rsp, 0x30
000078d2e7de42e8  vmovaps xmm0, [rsp]
000078d2e7de42ed  vmovaps xmm2, [rsp+0x10]
000078d2e7de42f3  vmovaps xmm3, [rsp+0x20]
000078d2e7de42f9  vmovaps xmm4, [rsp+0x30]
000078d2e7de42ff  vmovaps xmm5, [rsp+0x40]
000078d2e7de4305  vmovaps xmm6, [rsp+0x50]
000078d2e7de430b  vmovaps xmm7, [rsp+0x60]
000078d2e7de4311  vmovaps xmm8, [rsp+0x70]
000078d2e7de4317  vmovaps xmm9, [rsp+0x80]
000078d2e7de4320  vmovaps xmm10, [rsp+0x90]
000078d2e7de4329  vmovaps xmm11, [rsp+0xA0]
000078d2e7de4332  vmovaps xmm12, [rsp+0xB0]
000078d2e7de433b  vmovaps xmm13, [rsp+0xC0]
000078d2e7de4344  vmovaps xmm14, [rsp+0xD0]
000078d2e7de434d  vmovaps xmm15, [rsp+0xE0]
000078d2e7de4356  add rsp, 0xF0
000078d2e7de435d  pop r11
000078d2e7de435f  pop r10
000078d2e7de4361  pop r9
000078d2e7de4363  pop r8
000078d2e7de4365  pop rsi
000078d2e7de4366  pop rdi
000078d2e7de4367  pop rdx
000078d2e7de4368  pop rcx
000078d2e7de4369  pop rax
000078d2e7de436a  add rsp, 0x08
000078d2e7de436e  jmp 0x000078D2E7DDF92D
000078d2e7de4373  call 0x000078D2E7C0C260
000078d2e7de4378  jmp 0x000078D2E7DDF93B
000078d2e7de437d  call 0x000078D2E7CBD750
000078d2e7de4382  jmp 0x000078D2E7DDF945
000078d2e7de4387  sub rsp, 0x08
000078d2e7de438b  push rax
000078d2e7de438c  push rcx
000078d2e7de438d  push rdx
000078d2e7de438e  push rdi
000078d2e7de438f  push rsi
000078d2e7de4390  push r8
000078d2e7de4392  push r9
000078d2e7de4394  push r10
000078d2e7de4396  push r11
000078d2e7de4398  sub rsp, 0xF0
000078d2e7de439f  vmovaps [rsp], xmm0
000078d2e7de43a4  vmovaps [rsp+0x10], xmm1
000078d2e7de43aa  vmovaps [rsp+0x20], xmm2
000078d2e7de43b0  vmovaps [rsp+0x30], xmm3
000078d2e7de43b6  vmovaps [rsp+0x40], xmm4
000078d2e7de43bc  vmovaps [rsp+0x50], xmm5
000078d2e7de43c2  vmovaps [rsp+0x60], xmm6
000078d2e7de43c8  vmovaps [rsp+0x70], xmm7
000078d2e7de43ce  vmovaps [rsp+0x80], xmm9
000078d2e7de43d7  vmovaps [rsp+0x90], xmm10
000078d2e7de43e0  vmovaps [rsp+0xA0], xmm11
000078d2e7de43e9  vmovaps [rsp+0xB0], xmm12
000078d2e7de43f2  vmovaps [rsp+0xC0], xmm13
000078d2e7de43fb  vmovaps [rsp+0xD0], xmm14
000078d2e7de4404  vmovaps [rsp+0xE0], xmm15
000078d2e7de440d  sub rsp, 0x30
000078d2e7de4411  movaps [rsp], xmm8
000078d2e7de4416  movaps [rsp+0x10], xmm15
000078d2e7de441c  movaps [rsp+0x20], xmm7
000078d2e7de4421  lea rdi, [rsp]
000078d2e7de4425  mov esi, 0x00
000078d2e7de442a  mov rax, 0x5997D2DB1530
000078d2e7de4434  call rax
000078d2e7de4436  movaps xmm8, [rsp]
000078d2e7de443b  add rsp, 0x30
000078d2e7de443f  vmovaps xmm0, [rsp]
000078d2e7de4444  vmovaps xmm1, [rsp+0x10]
000078d2e7de444a  vmovaps xmm2, [rsp+0x20]
000078d2e7de4450  vmovaps xmm3, [rsp+0x30]
000078d2e7de4456  vmovaps xmm4, [rsp+0x40]
000078d2e7de445c  vmovaps xmm5, [rsp+0x50]
000078d2e7de4462  vmovaps xmm6, [rsp+0x60]
000078d2e7de4468  vmovaps xmm7, [rsp+0x70]
000078d2e7de446e  vmovaps xmm9, [rsp+0x80]
000078d2e7de4477  vmovaps xmm10, [rsp+0x90]
000078d2e7de4480  vmovaps xmm11, [rsp+0xA0]
000078d2e7de4489  vmovaps xmm12, [rsp+0xB0]
000078d2e7de4492  vmovaps xmm13, [rsp+0xC0]
000078d2e7de449b  vmovaps xmm14, [rsp+0xD0]
000078d2e7de44a4  vmovaps xmm15, [rsp+0xE0]
000078d2e7de44ad  add rsp, 0xF0
000078d2e7de44b4  pop r11
000078d2e7de44b6  pop r10
000078d2e7de44b8  pop r9
000078d2e7de44ba  pop r8
000078d2e7de44bc  pop rsi
000078d2e7de44bd  pop rdi
000078d2e7de44be  pop rdx
000078d2e7de44bf  pop rcx
000078d2e7de44c0  pop rax
000078d2e7de44c1  add rsp, 0x08
000078d2e7de44c5  jmp 0x000078D2E7DDF967
000078d2e7de44ca  sub rsp, 0x08
000078d2e7de44ce  push rax
000078d2e7de44cf  push rcx
000078d2e7de44d0  push rdx
000078d2e7de44d1  push rdi
000078d2e7de44d2  push rsi
000078d2e7de44d3  push r8
000078d2e7de44d5  push r9
000078d2e7de44d7  push r10
000078d2e7de44d9  push r11
000078d2e7de44db  sub rsp, 0xF0
000078d2e7de44e2  vmovaps [rsp], xmm0
000078d2e7de44e7  vmovaps [rsp+0x10], xmm1
000078d2e7de44ed  vmovaps [rsp+0x20], xmm2
000078d2e7de44f3  vmovaps [rsp+0x30], xmm3
000078d2e7de44f9  vmovaps [rsp+0x40], xmm4
000078d2e7de44ff  vmovaps [rsp+0x50], xmm5
000078d2e7de4505  vmovaps [rsp+0x60], xmm6
000078d2e7de450b  vmovaps [rsp+0x70], xmm8
000078d2e7de4511  vmovaps [rsp+0x80], xmm9
000078d2e7de451a  vmovaps [rsp+0x90], xmm10
000078d2e7de4523  vmovaps [rsp+0xA0], xmm11
000078d2e7de452c  vmovaps [rsp+0xB0], xmm12
000078d2e7de4535  vmovaps [rsp+0xC0], xmm13
000078d2e7de453e  vmovaps [rsp+0xD0], xmm14
000078d2e7de4547  vmovaps [rsp+0xE0], xmm15
000078d2e7de4550  sub rsp, 0x30
000078d2e7de4554  movaps [rsp], xmm7
000078d2e7de4558  movaps [rsp+0x10], xmm9
000078d2e7de455e  movaps [rsp+0x20], xmm15
000078d2e7de4564  lea rdi, [rsp]
000078d2e7de4568  mov esi, 0x00
000078d2e7de456d  mov rax, 0x5997D2DB1530
000078d2e7de4577  call rax
000078d2e7de4579  movaps xmm7, [rsp]
000078d2e7de457d  add rsp, 0x30
000078d2e7de4581  vmovaps xmm0, [rsp]
000078d2e7de4586  vmovaps xmm1, [rsp+0x10]
000078d2e7de458c  vmovaps xmm2, [rsp+0x20]
000078d2e7de4592  vmovaps xmm3, [rsp+0x30]
000078d2e7de4598  vmovaps xmm4, [rsp+0x40]
000078d2e7de459e  vmovaps xmm5, [rsp+0x50]
000078d2e7de45a4  vmovaps xmm6, [rsp+0x60]
000078d2e7de45aa  vmovaps xmm8, [rsp+0x70]
000078d2e7de45b0  vmovaps xmm9, [rsp+0x80]
000078d2e7de45b9  vmovaps xmm10, [rsp+0x90]
000078d2e7de45c2  vmovaps xmm11, [rsp+0xA0]
000078d2e7de45cb  vmovaps xmm12, [rsp+0xB0]
000078d2e7de45d4  vmovaps xmm13, [rsp+0xC0]
000078d2e7de45dd  vmovaps xmm14, [rsp+0xD0]
000078d2e7de45e6  vmovaps xmm15, [rsp+0xE0]
000078d2e7de45ef  add rsp, 0xF0
000078d2e7de45f6  pop r11
000078d2e7de45f8  pop r10
000078d2e7de45fa  pop r9
000078d2e7de45fc  pop r8
000078d2e7de45fe  pop rsi
000078d2e7de45ff  pop rdi
000078d2e7de4600  pop rdx
000078d2e7de4601  pop rcx
000078d2e7de4602  pop rax
000078d2e7de4603  add rsp, 0x08
000078d2e7de4607  jmp 0x000078D2E7DDF994
000078d2e7de460c  sub rsp, 0x08
000078d2e7de4610  push rax
000078d2e7de4611  push rcx
000078d2e7de4612  push rdx
000078d2e7de4613  push rdi
000078d2e7de4614  push rsi
000078d2e7de4615  push r8
000078d2e7de4617  push r9
000078d2e7de4619  push r10
000078d2e7de461b  push r11
000078d2e7de461d  sub rsp, 0xF0
000078d2e7de4624  vmovaps [rsp], xmm0
000078d2e7de4629  vmovaps [rsp+0x10], xmm1
000078d2e7de462f  vmovaps [rsp+0x20], xmm2
000078d2e7de4635  vmovaps [rsp+0x30], xmm3
000078d2e7de463b  vmovaps [rsp+0x40], xmm4
000078d2e7de4641  vmovaps [rsp+0x50], xmm5
000078d2e7de4647  vmovaps [rsp+0x60], xmm6
000078d2e7de464d  vmovaps [rsp+0x70], xmm7
000078d2e7de4653  vmovaps [rsp+0x80], xmm8
000078d2e7de465c  vmovaps [rsp+0x90], xmm10
000078d2e7de4665  vmovaps [rsp+0xA0], xmm11
000078d2e7de466e  vmovaps [rsp+0xB0], xmm12
000078d2e7de4677  vmovaps [rsp+0xC0], xmm13
000078d2e7de4680  vmovaps [rsp+0xD0], xmm14
000078d2e7de4689  vmovaps [rsp+0xE0], xmm15
000078d2e7de4692  sub rsp, 0x30
000078d2e7de4696  movaps [rsp], xmm9
000078d2e7de469b  movaps [rsp+0x10], xmm13
000078d2e7de46a1  movaps [rsp+0x20], xmm15
000078d2e7de46a7  lea rdi, [rsp]
000078d2e7de46ab  mov esi, 0x00
000078d2e7de46b0  mov rax, 0x5997D2DB1530
000078d2e7de46ba  call rax
000078d2e7de46bc  movaps xmm9, [rsp]
000078d2e7de46c1  add rsp, 0x30
000078d2e7de46c5  vmovaps xmm0, [rsp]
000078d2e7de46ca  vmovaps xmm1, [rsp+0x10]
000078d2e7de46d0  vmovaps xmm2, [rsp+0x20]
000078d2e7de46d6  vmovaps xmm3, [rsp+0x30]
000078d2e7de46dc  vmovaps xmm4, [rsp+0x40]
000078d2e7de46e2  vmovaps xmm5, [rsp+0x50]
000078d2e7de46e8  vmovaps xmm6, [rsp+0x60]
000078d2e7de46ee  vmovaps xmm7, [rsp+0x70]
000078d2e7de46f4  vmovaps xmm8, [rsp+0x80]
000078d2e7de46fd  vmovaps xmm10, [rsp+0x90]
000078d2e7de4706  vmovaps xmm11, [rsp+0xA0]
000078d2e7de470f  vmovaps xmm12, [rsp+0xB0]
000078d2e7de4718  vmovaps xmm13, [rsp+0xC0]
000078d2e7de4721  vmovaps xmm14, [rsp+0xD0]
000078d2e7de472a  vmovaps xmm15, [rsp+0xE0]
000078d2e7de4733  add rsp, 0xF0
000078d2e7de473a  pop r11
000078d2e7de473c  pop r10
000078d2e7de473e  pop r9
000078d2e7de4740  pop r8
000078d2e7de4742  pop rsi
000078d2e7de4743  pop rdi
000078d2e7de4744  pop rdx
000078d2e7de4745  pop rcx
000078d2e7de4746  pop rax
000078d2e7de4747  add rsp, 0x08
000078d2e7de474b  jmp 0x000078D2E7DDF9C2
000078d2e7de4750  sub rsp, 0x08
000078d2e7de4754  push rax
000078d2e7de4755  push rcx
000078d2e7de4756  push rdx
000078d2e7de4757  push rdi
000078d2e7de4758  push rsi
000078d2e7de4759  push r8
000078d2e7de475b  push r9
000078d2e7de475d  push r10
000078d2e7de475f  push r11
000078d2e7de4761  sub rsp, 0xF0
000078d2e7de4768  vmovaps [rsp], xmm0
000078d2e7de476d  vmovaps [rsp+0x10], xmm1
000078d2e7de4773  vmovaps [rsp+0x20], xmm2
000078d2e7de4779  vmovaps [rsp+0x30], xmm3
000078d2e7de477f  vmovaps [rsp+0x40], xmm4
000078d2e7de4785  vmovaps [rsp+0x50], xmm5
000078d2e7de478b  vmovaps [rsp+0x60], xmm6
000078d2e7de4791  vmovaps [rsp+0x70], xmm7
000078d2e7de4797  vmovaps [rsp+0x80], xmm8
000078d2e7de47a0  vmovaps [rsp+0x90], xmm9
000078d2e7de47a9  vmovaps [rsp+0xA0], xmm10
000078d2e7de47b2  vmovaps [rsp+0xB0], xmm11
000078d2e7de47bb  vmovaps [rsp+0xC0], xmm12
000078d2e7de47c4  vmovaps [rsp+0xD0], xmm13
000078d2e7de47cd  vmovaps [rsp+0xE0], xmm14
000078d2e7de47d6  sub rsp, 0x30
000078d2e7de47da  movaps [rsp], xmm15
000078d2e7de47df  movaps [rsp+0x10], xmm11
000078d2e7de47e5  movaps [rsp+0x20], xmm12
000078d2e7de47eb  lea rdi, [rsp]
000078d2e7de47ef  mov esi, 0x00
000078d2e7de47f4  mov rax, 0x5997D2DB1530
000078d2e7de47fe  call rax
000078d2e7de4800  movaps xmm15, [rsp]
000078d2e7de4805  add rsp, 0x30
000078d2e7de4809  vmovaps xmm0, [rsp]
000078d2e7de480e  vmovaps xmm1, [rsp+0x10]
000078d2e7de4814  vmovaps xmm2, [rsp+0x20]
000078d2e7de481a  vmovaps xmm3, [rsp+0x30]
000078d2e7de4820  vmovaps xmm4, [rsp+0x40]
000078d2e7de4826  vmovaps xmm5, [rsp+0x50]
000078d2e7de482c  vmovaps xmm6, [rsp+0x60]
000078d2e7de4832  vmovaps xmm7, [rsp+0x70]
000078d2e7de4838  vmovaps xmm8, [rsp+0x80]
000078d2e7de4841  vmovaps xmm9, [rsp+0x90]
000078d2e7de484a  vmovaps xmm10, [rsp+0xA0]
000078d2e7de4853  vmovaps xmm11, [rsp+0xB0]
000078d2e7de485c  vmovaps xmm12, [rsp+0xC0]
000078d2e7de4865  vmovaps xmm13, [rsp+0xD0]
000078d2e7de486e  vmovaps xmm14, [rsp+0xE0]
000078d2e7de4877  add rsp, 0xF0
000078d2e7de487e  pop r11
000078d2e7de4880  pop r10
000078d2e7de4882  pop r9
000078d2e7de4884  pop r8
000078d2e7de4886  pop rsi
000078d2e7de4887  pop rdi
000078d2e7de4888  pop rdx
000078d2e7de4889  pop rcx
000078d2e7de488a  pop rax
000078d2e7de488b  add rsp, 0x08
000078d2e7de488f  jmp 0x000078D2E7DDF9DD
000078d2e7de4894  sub rsp, 0x08
000078d2e7de4898  push rax
000078d2e7de4899  push rcx
000078d2e7de489a  push rdx
000078d2e7de489b  push rdi
000078d2e7de489c  push rsi
000078d2e7de489d  push r8
000078d2e7de489f  push r9
000078d2e7de48a1  push r10
000078d2e7de48a3  push r11
000078d2e7de48a5  sub rsp, 0xF0
000078d2e7de48ac  vmovaps [rsp], xmm0
000078d2e7de48b1  vmovaps [rsp+0x10], xmm1
000078d2e7de48b7  vmovaps [rsp+0x20], xmm2
000078d2e7de48bd  vmovaps [rsp+0x30], xmm3
000078d2e7de48c3  vmovaps [rsp+0x40], xmm4
000078d2e7de48c9  vmovaps [rsp+0x50], xmm5
000078d2e7de48cf  vmovaps [rsp+0x60], xmm6
000078d2e7de48d5  vmovaps [rsp+0x70], xmm7
000078d2e7de48db  vmovaps [rsp+0x80], xmm8
000078d2e7de48e4  vmovaps [rsp+0x90], xmm9
000078d2e7de48ed  vmovaps [rsp+0xA0], xmm10
000078d2e7de48f6  vmovaps [rsp+0xB0], xmm11
000078d2e7de48ff  vmovaps [rsp+0xC0], xmm12
000078d2e7de4908  vmovaps [rsp+0xD0], xmm14
000078d2e7de4911  vmovaps [rsp+0xE0], xmm15
000078d2e7de491a  sub rsp, 0x30
000078d2e7de491e  movaps [rsp], xmm13
000078d2e7de4923  movaps [rsp+0x10], xmm10
000078d2e7de4929  movaps [rsp+0x20], xmm14
000078d2e7de492f  lea rdi, [rsp]
000078d2e7de4933  mov esi, 0x00
000078d2e7de4938  mov rax, 0x5997D2DB1530
000078d2e7de4942  call rax
000078d2e7de4944  movaps xmm13, [rsp]
000078d2e7de4949  add rsp, 0x30
000078d2e7de494d  vmovaps xmm0, [rsp]
000078d2e7de4952  vmovaps xmm1, [rsp+0x10]
000078d2e7de4958  vmovaps xmm2, [rsp+0x20]
000078d2e7de495e  vmovaps xmm3, [rsp+0x30]
000078d2e7de4964  vmovaps xmm4, [rsp+0x40]
000078d2e7de496a  vmovaps xmm5, [rsp+0x50]
000078d2e7de4970  vmovaps xmm6, [rsp+0x60]
000078d2e7de4976  vmovaps xmm7, [rsp+0x70]
000078d2e7de497c  vmovaps xmm8, [rsp+0x80]
000078d2e7de4985  vmovaps xmm9, [rsp+0x90]
000078d2e7de498e  vmovaps xmm10, [rsp+0xA0]
000078d2e7de4997  vmovaps xmm11, [rsp+0xB0]
000078d2e7de49a0  vmovaps xmm12, [rsp+0xC0]
000078d2e7de49a9  vmovaps xmm14, [rsp+0xD0]
000078d2e7de49b2  vmovaps xmm15, [rsp+0xE0]
000078d2e7de49bb  add rsp, 0xF0
000078d2e7de49c2  pop r11
000078d2e7de49c4  pop r10
000078d2e7de49c6  pop r9
000078d2e7de49c8  pop r8
000078d2e7de49ca  pop rsi
000078d2e7de49cb  pop rdi
000078d2e7de49cc  pop rdx
000078d2e7de49cd  pop rcx
000078d2e7de49ce  pop rax
000078d2e7de49cf  add rsp, 0x08
000078d2e7de49d3  jmp 0x000078D2E7DDFA00
000078d2e7de49d8  sub rsp, 0x08
000078d2e7de49dc  push rax
000078d2e7de49dd  push rcx
000078d2e7de49de  push rdx
000078d2e7de49df  push rdi
000078d2e7de49e0  push rsi
000078d2e7de49e1  push r8
000078d2e7de49e3  push r9
000078d2e7de49e5  push r10
000078d2e7de49e7  push r11
000078d2e7de49e9  sub rsp, 0xF0
000078d2e7de49f0  vmovaps [rsp], xmm0
000078d2e7de49f5  vmovaps [rsp+0x10], xmm1
000078d2e7de49fb  vmovaps [rsp+0x20], xmm2
000078d2e7de4a01  vmovaps [rsp+0x30], xmm3
000078d2e7de4a07  vmovaps [rsp+0x40], xmm4
000078d2e7de4a0d  vmovaps [rsp+0x50], xmm5
000078d2e7de4a13  vmovaps [rsp+0x60], xmm6
000078d2e7de4a19  vmovaps [rsp+0x70], xmm7
000078d2e7de4a1f  vmovaps [rsp+0x80], xmm8
000078d2e7de4a28  vmovaps [rsp+0x90], xmm9
000078d2e7de4a31  vmovaps [rsp+0xA0], xmm10
000078d2e7de4a3a  vmovaps [rsp+0xB0], xmm11
000078d2e7de4a43  vmovaps [rsp+0xC0], xmm12
000078d2e7de4a4c  vmovaps [rsp+0xD0], xmm13
000078d2e7de4a55  vmovaps [rsp+0xE0], xmm15
000078d2e7de4a5e  sub rsp, 0x30
000078d2e7de4a62  movaps [rsp], xmm14
000078d2e7de4a67  movaps [rsp+0x10], xmm1
000078d2e7de4a6c  movaps [rsp+0x20], xmm7
000078d2e7de4a71  lea rdi, [rsp]
000078d2e7de4a75  mov esi, 0x00
000078d2e7de4a7a  mov rax, 0x5997D2DB1530
000078d2e7de4a84  call rax
000078d2e7de4a86  movaps xmm14, [rsp]
000078d2e7de4a8b  add rsp, 0x30
000078d2e7de4a8f  vmovaps xmm0, [rsp]
000078d2e7de4a94  vmovaps xmm1, [rsp+0x10]
000078d2e7de4a9a  vmovaps xmm2, [rsp+0x20]
000078d2e7de4aa0  vmovaps xmm3, [rsp+0x30]
000078d2e7de4aa6  vmovaps xmm4, [rsp+0x40]
000078d2e7de4aac  vmovaps xmm5, [rsp+0x50]
000078d2e7de4ab2  vmovaps xmm6, [rsp+0x60]
000078d2e7de4ab8  vmovaps xmm7, [rsp+0x70]
000078d2e7de4abe  vmovaps xmm8, [rsp+0x80]
000078d2e7de4ac7  vmovaps xmm9, [rsp+0x90]
000078d2e7de4ad0  vmovaps xmm10, [rsp+0xA0]
000078d2e7de4ad9  vmovaps xmm11, [rsp+0xB0]
000078d2e7de4ae2  vmovaps xmm12, [rsp+0xC0]
000078d2e7de4aeb  vmovaps xmm13, [rsp+0xD0]
000078d2e7de4af4  vmovaps xmm15, [rsp+0xE0]
000078d2e7de4afd  add rsp, 0xF0
000078d2e7de4b04  pop r11
000078d2e7de4b06  pop r10
000078d2e7de4b08  pop r9
000078d2e7de4b0a  pop r8
000078d2e7de4b0c  pop rsi
000078d2e7de4b0d  pop rdi
000078d2e7de4b0e  pop rdx
000078d2e7de4b0f  pop rcx
000078d2e7de4b10  pop rax
000078d2e7de4b11  add rsp, 0x08
000078d2e7de4b15  jmp 0x000078D2E7DDFA23
000078d2e7de4b1a  sub rsp, 0x08
000078d2e7de4b1e  push rax
000078d2e7de4b1f  push rcx
000078d2e7de4b20  push rdx
000078d2e7de4b21  push rdi
000078d2e7de4b22  push rsi
000078d2e7de4b23  push r8
000078d2e7de4b25  push r9
000078d2e7de4b27  push r10
000078d2e7de4b29  push r11
000078d2e7de4b2b  sub rsp, 0xF0
000078d2e7de4b32  vmovaps [rsp], xmm0
000078d2e7de4b37  vmovaps [rsp+0x10], xmm2
000078d2e7de4b3d  vmovaps [rsp+0x20], xmm3
000078d2e7de4b43  vmovaps [rsp+0x30], xmm4
000078d2e7de4b49  vmovaps [rsp+0x40], xmm5
000078d2e7de4b4f  vmovaps [rsp+0x50], xmm6
000078d2e7de4b55  vmovaps [rsp+0x60], xmm7
000078d2e7de4b5b  vmovaps [rsp+0x70], xmm8
000078d2e7de4b61  vmovaps [rsp+0x80], xmm9
000078d2e7de4b6a  vmovaps [rsp+0x90], xmm10
000078d2e7de4b73  vmovaps [rsp+0xA0], xmm11
000078d2e7de4b7c  vmovaps [rsp+0xB0], xmm12
000078d2e7de4b85  vmovaps [rsp+0xC0], xmm13
000078d2e7de4b8e  vmovaps [rsp+0xD0], xmm14
000078d2e7de4b97  vmovaps [rsp+0xE0], xmm15
000078d2e7de4ba0  sub rsp, 0x30
000078d2e7de4ba4  movaps [rsp], xmm1
000078d2e7de4ba8  movaps [rsp+0x10], xmm8
000078d2e7de4bae  movaps [rsp+0x20], xmm9
000078d2e7de4bb4  lea rdi, [rsp]
000078d2e7de4bb8  mov esi, 0x00
000078d2e7de4bbd  mov rax, 0x5997D2DB1530
000078d2e7de4bc7  call rax
000078d2e7de4bc9  movaps xmm1, [rsp]
000078d2e7de4bcd  add rsp, 0x30
000078d2e7de4bd1  vmovaps xmm0, [rsp]
000078d2e7de4bd6  vmovaps xmm2, [rsp+0x10]
000078d2e7de4bdc  vmovaps xmm3, [rsp+0x20]
000078d2e7de4be2  vmovaps xmm4, [rsp+0x30]
000078d2e7de4be8  vmovaps xmm5, [rsp+0x40]
000078d2e7de4bee  vmovaps xmm6, [rsp+0x50]
000078d2e7de4bf4  vmovaps xmm7, [rsp+0x60]
000078d2e7de4bfa  vmovaps xmm8, [rsp+0x70]
000078d2e7de4c00  vmovaps xmm9, [rsp+0x80]
000078d2e7de4c09  vmovaps xmm10, [rsp+0x90]
000078d2e7de4c12  vmovaps xmm11, [rsp+0xA0]
000078d2e7de4c1b  vmovaps xmm12, [rsp+0xB0]
000078d2e7de4c24  vmovaps xmm13, [rsp+0xC0]
000078d2e7de4c2d  vmovaps xmm14, [rsp+0xD0]
000078d2e7de4c36  vmovaps xmm15, [rsp+0xE0]
000078d2e7de4c3f  add rsp, 0xF0
000078d2e7de4c46  pop r11
000078d2e7de4c48  pop r10
000078d2e7de4c4a  pop r9
000078d2e7de4c4c  pop r8
000078d2e7de4c4e  pop rsi
000078d2e7de4c4f  pop rdi
000078d2e7de4c50  pop rdx
000078d2e7de4c51  pop rcx
000078d2e7de4c52  pop rax
000078d2e7de4c53  add rsp, 0x08
000078d2e7de4c57  jmp 0x000078D2E7DDFA45
000078d2e7de4c5c  call 0x000078D2E7CE5940
000078d2e7de4c61  jmp 0x000078D2E7DDFA53
000078d2e7de4c66  call 0x000078D2E7C0C380
000078d2e7de4c6b  jmp 0x000078D2E7DDFA5D
000078d2e7de4c70  call 0x000078D2E7C0D600
000078d2e7de4c75  jmp 0x000078D2E7DDFA67
000078d2e7de4c7a  call 0x000078D2E7BFF540
000078d2e7de4c7f  jmp 0x000078D2E7DDFA71
000078d2e7de4c84  int3
000078d2e7de4c85  nop [rax+rax*1], ax
000078d2e7de4c8e  nop
000078d2e7de4c90  mov qword ptr [r15+0x40], 0x430000
000078d2e7de4c98  mov eax, 0x430CC0
000078d2e7de4c9d  mov r14, [r13+rax*1]
000078d2e7de4ca2  movq xmm1, r14
000078d2e7de4ca7  mov rax, [r15+0x50]
000078d2e7de4cab  movups xmm15, [r13+rax*1]
000078d2e7de4cb1  movaps [r15+0x120], xmm15
000078d2e7de4cb9  mov qword ptr [r15+0x48], 0x10
000078d2e7de4cc1  xor eax, eax
000078d2e7de4cc3  mov r14d, 0x10
000078d2e7de4cc9  mov r12d, 0x200
000078d2e7de4ccf  cmp r14, r12
000078d2e7de4cd2  cmc
000078d2e7de4cd3  lahf
000078d2e7de4cd4  seto al
000078d2e7de4cd7  mov [r15+0x108], eax
000078d2e7de4cde  pextrq rax, xmm15, 0x01
000078d2e7de4ce5  movq xmm14, rax
000078d2e7de4cea  movaps [r15+0x130], xmm14
000078d2e7de4cf2  movq rax, xmm1
000078d2e7de4cf7  movq r14, xmm15
000078d2e7de4cfc  vmovq xmm1, rax
000078d2e7de4d01  vmovq xmm15, r14
000078d2e7de4d06  movaps xmm13, xmm1
000078d2e7de4d0a  addsd xmm13, xmm15
000078d2e7de4d0f  ucomisd xmm13, xmm13
000078d2e7de4d14  jp 0x000078D2E7DE4DD3
000078d2e7de4d1a  movq xmm13, xmm13
000078d2e7de4d1f  movq rax, xmm13
000078d2e7de4d24  movq r14, xmm14
000078d2e7de4d29  vmovq xmm1, rax
000078d2e7de4d2e  vmovq xmm15, r14
000078d2e7de4d33  movaps xmm14, xmm1
000078d2e7de4d37  addsd xmm14, xmm15
000078d2e7de4d3c  ucomisd xmm14, xmm14
000078d2e7de4d41  jp 0x000078D2E7DE4E1B
000078d2e7de4d47  movq xmm14, xmm14
000078d2e7de4d4c  movaps [r15+0x110], xmm14
000078d2e7de4d54  mov eax, [r15+0x108]
000078d2e7de4d5b  sahf
000078d2e7de4d5c  jnz 0x000078D2E7DE4D8E
000078d2e7de4d5e  cmp dword ptr [r15+0x318], 0x00
000078d2e7de4d66  jz 0x000078D2E7DE5030
000078d2e7de4d6c  nop [rax+rax*1], ax
000078d2e7de4d75  nop [rax+rax*1], eax
000078d2e7de4d7d  mov eax, 0x410704
000078d2e7de4d82  mov [r15+0x100], rax
000078d2e7de4d89  jmp 0x000078D2E7BFE110
000078d2e7de4d8e  cmp dword ptr [r15+0x318], 0x00
000078d2e7de4d96  jz 0x000078D2E7DE4E70
000078d2e7de4d9c  nop [rax+rax*1], ax
000078d2e7de4da5  nop [rax+rax*1], eax
000078d2e7de4dad  mov eax, 0x4106E8
000078d2e7de4db2  mov [r15+0x100], rax
000078d2e7de4db9  jmp 0x000078D2E7BFE110
000078d2e7de4dbe  int3
000078d2e7de4dbf  call 0x000078D2E7C0DC20
000078d2e7de4dc4  jmp 0x000078D2E7DE4CA2
000078d2e7de4dc9  call 0x000078D2E7C0E760
000078d2e7de4dce  jmp 0x000078D2E7DE4CB1
000078d2e7de4dd3  ucomisd xmm1, xmm15
000078d2e7de4dd8  jp 0x000078D2E7DE4DE7
000078d2e7de4dda  movaps xmm13, [0x000078D2E79FE060]
000078d2e7de4de2  jmp 0x000078D2E7DE4D1A
000078d2e7de4de7  vxorps xmm0, xmm1, xmm15
000078d2e7de4dec  pextrw eax, xmm0, 0x03
000078d2e7de4df1  and eax, 0x7FF8
000078d2e7de4df6  cmp eax, 0x08
000078d2e7de4df9  jnz 0x000078D2E7DE4D1A
000078d2e7de4dff  movq rax, xmm15
000078d2e7de4e04  shl rax, 0x0D
000078d2e7de4e08  jbe 0x000078D2E7DE4D1A
000078d2e7de4e0e  vorps xmm13, xmm15, [0x000078D2E79FE070]
000078d2e7de4e16  jmp 0x000078D2E7DE4D1A
000078d2e7de4e1b  ucomisd xmm1, xmm15
000078d2e7de4e20  jp 0x000078D2E7DE4E2F
000078d2e7de4e22  movaps xmm14, [0x000078D2E79FE060]
000078d2e7de4e2a  jmp 0x000078D2E7DE4D47
000078d2e7de4e2f  vxorps xmm0, xmm1, xmm15
000078d2e7de4e34  pextrw eax, xmm0, 0x03
000078d2e7de4e39  and eax, 0x7FF8
000078d2e7de4e3e  cmp eax, 0x08
000078d2e7de4e41  jnz 0x000078D2E7DE4D47
000078d2e7de4e47  movq rax, xmm15
000078d2e7de4e4c  shl rax, 0x0D
000078d2e7de4e50  jbe 0x000078D2E7DE4D47
000078d2e7de4e56  vorps xmm14, xmm15, [0x000078D2E79FE070]
000078d2e7de4e5e  jmp 0x000078D2E7DE4D47
000078d2e7de4e63  int3
000078d2e7de4e64  nop [rax+rax*1], ax
000078d2e7de4e6d  nop [rax], eax
000078d2e7de4e70  mov rax, [r15+0x48]
000078d2e7de4e74  mov r14, [r15+0x50]
000078d2e7de4e78  lea r12, [r14+rax*1]
000078d2e7de4e7c  movups xmm1, [r13+r12*1]
000078d2e7de4e82  movaps [r15+0x120], xmm1
000078d2e7de4e8a  lea r14, [rax+0x10]
000078d2e7de4e8e  mov [r15+0x48], r14
000078d2e7de4e92  xor eax, eax
000078d2e7de4e94  mov r12d, 0x200
000078d2e7de4e9a  cmp r14, r12
000078d2e7de4e9d  cmc
000078d2e7de4e9e  lahf
000078d2e7de4e9f  seto al
000078d2e7de4ea2  mov [r15+0x108], eax
000078d2e7de4ea9  pextrq rax, xmm1, 0x01
000078d2e7de4eb0  movq xmm15, rax
000078d2e7de4eb5  movaps [r15+0x130], xmm15
000078d2e7de4ebd  movaps xmm14, [r15+0x110]
000078d2e7de4ec5  movq rax, xmm14
000078d2e7de4eca  movq r14, xmm1
000078d2e7de4ecf  vmovq xmm1, rax
000078d2e7de4ed4  vmovq xmm14, r14
000078d2e7de4ed9  movaps xmm13, xmm1
000078d2e7de4edd  addsd xmm13, xmm14
000078d2e7de4ee2  ucomisd xmm13, xmm13
000078d2e7de4ee7  jp 0x000078D2E7DE4F9C
000078d2e7de4eed  movq xmm13, xmm13
000078d2e7de4ef2  movq rax, xmm13
000078d2e7de4ef7  movq r14, xmm15
000078d2e7de4efc  vmovq xmm1, rax
000078d2e7de4f01  vmovq xmm15, r14
000078d2e7de4f06  movaps xmm14, xmm1
000078d2e7de4f0a  addsd xmm14, xmm15
000078d2e7de4f0f  ucomisd xmm14, xmm14
000078d2e7de4f14  jp 0x000078D2E7DE4FE4
000078d2e7de4f1a  movq xmm14, xmm14
000078d2e7de4f1f  movaps [r15+0x110], xmm14
000078d2e7de4f27  mov eax, [r15+0x108]
000078d2e7de4f2e  sahf
000078d2e7de4f2f  jnz 0x000078D2E7DE4F61
000078d2e7de4f31  cmp dword ptr [r15+0x318], 0x00
000078d2e7de4f39  jz 0x000078D2E7DE5030
000078d2e7de4f3f  nop [rax+rax*1], ax
000078d2e7de4f48  nop [rax+rax*1], eax
000078d2e7de4f50  mov eax, 0x410704
000078d2e7de4f55  mov [r15+0x100], rax
000078d2e7de4f5c  jmp 0x000078D2E7BFE110
000078d2e7de4f61  cmp dword ptr [r15+0x318], 0x00
000078d2e7de4f69  jz 0x000078D2E7DE4E70
000078d2e7de4f6f  nop [rax+rax*1], ax
000078d2e7de4f78  nop [rax+rax*1], eax
000078d2e7de4f80  mov eax, 0x4106E8
000078d2e7de4f85  mov [r15+0x100], rax
000078d2e7de4f8c  jmp 0x000078D2E7BFE110
000078d2e7de4f91  int3
000078d2e7de4f92  call 0x000078D2E7CB52F0
000078d2e7de4f97  jmp 0x000078D2E7DE4E82
000078d2e7de4f9c  ucomisd xmm1, xmm14
000078d2e7de4fa1  jp 0x000078D2E7DE4FB0
000078d2e7de4fa3  movaps xmm13, [0x000078D2E79FE060]
000078d2e7de4fab  jmp 0x000078D2E7DE4EED
000078d2e7de4fb0  vxorps xmm0, xmm1, xmm14
000078d2e7de4fb5  pextrw eax, xmm0, 0x03
000078d2e7de4fba  and eax, 0x7FF8
000078d2e7de4fbf  cmp eax, 0x08
000078d2e7de4fc2  jnz 0x000078D2E7DE4EED
000078d2e7de4fc8  movq rax, xmm14
000078d2e7de4fcd  shl rax, 0x0D
000078d2e7de4fd1  jbe 0x000078D2E7DE4EED
000078d2e7de4fd7  vorps xmm13, xmm14, [0x000078D2E79FE070]
000078d2e7de4fdf  jmp 0x000078D2E7DE4EED
000078d2e7de4fe4  ucomisd xmm1, xmm15
000078d2e7de4fe9  jp 0x000078D2E7DE4FF8
000078d2e7de4feb  movaps xmm14, [0x000078D2E79FE060]
000078d2e7de4ff3  jmp 0x000078D2E7DE4F1A
000078d2e7de4ff8  vxorps xmm0, xmm1, xmm15
000078d2e7de4ffd  pextrw eax, xmm0, 0x03
000078d2e7de5002  and eax, 0x7FF8
000078d2e7de5007  cmp eax, 0x08
000078d2e7de500a  jnz 0x000078D2E7DE4F1A
000078d2e7de5010  movq rax, xmm15
000078d2e7de5015  shl rax, 0x0D
000078d2e7de5019  jbe 0x000078D2E7DE4F1A
000078d2e7de501f  vorps xmm14, xmm15, [0x000078D2E79FE070]
000078d2e7de5027  jmp 0x000078D2E7DE4F1A
000078d2e7de502c  int3
000078d2e7de502d  nop [rax], eax
000078d2e7de5030  mov rax, [r15+0xF8]
000078d2e7de5037  lea r14, [rax+0x1D0]
000078d2e7de503e  mov r12, [r13+r14*1]
000078d2e7de5043  lea r14, [rax+0x1D8]
000078d2e7de504a  mov r11, [r13+r14*1]
000078d2e7de504f  mov [r15+0xA0], r12
000078d2e7de5056  mov [r15+0x98], r11
000078d2e7de505d  mov r14, [r15+0x40]
000078d2e7de5061  lea r12, [r14+0xCC0]
000078d2e7de5068  movaps xmm1, [r15+0x110]
000078d2e7de5070  movq r14, xmm1
000078d2e7de5075  mov [r13+r12*1], r14
000078d2e7de507a  lea r14, [rax+0x1C0]
000078d2e7de5081  mov r12, [r13+r14*1]
000078d2e7de5086  lea r14, [rax+0x1C8]
000078d2e7de508d  mov r11, [r13+r14*1]
000078d2e7de5092  mov [r15+0xE8], r12
000078d2e7de5099  mov [r15+0xF0], r11
000078d2e7de50a0  lea r14, [rax+0x1B0]
000078d2e7de50a7  mov r12, [r13+r14*1]
000078d2e7de50ac  lea r14, [rax+0x1B8]
000078d2e7de50b3  mov r10, [r13+r14*1]
000078d2e7de50b8  movq xmm1, r12
000078d2e7de50bd  movq xmm15, r10
000078d2e7de50c2  movq xmm1, xmm1
000078d2e7de50c6  movq xmm1, xmm1
000078d2e7de50ca  movaps [r15+0x1A0], xmm1
000078d2e7de50d2  movq xmm15, xmm15
000078d2e7de50d7  movq xmm15, xmm15
000078d2e7de50dc  movaps [r15+0x190], xmm15
000078d2e7de50e4  lea r14, [rax+0x1A0]
000078d2e7de50eb  mov r12, [r13+r14*1]
000078d2e7de50f0  lea r14, [rax+0x1A8]
000078d2e7de50f7  mov r10, [r13+r14*1]
000078d2e7de50fc  movq xmm1, r12
000078d2e7de5101  movq xmm15, r10
000078d2e7de5106  movq xmm1, xmm1
000078d2e7de510a  movq xmm1, xmm1
000078d2e7de510e  movaps [r15+0x1C0], xmm1
000078d2e7de5116  movq xmm15, xmm15
000078d2e7de511b  movq xmm15, xmm15
000078d2e7de5120  movaps [r15+0x1B0], xmm15
000078d2e7de5128  lea r14, [rax+0x190]
000078d2e7de512f  mov r12, [r13+r14*1]
000078d2e7de5134  lea r14, [rax+0x198]
000078d2e7de513b  mov r10, [r13+r14*1]
000078d2e7de5140  movq xmm1, r12
000078d2e7de5145  movq xmm15, r10
000078d2e7de514a  movq xmm1, xmm1
000078d2e7de514e  movq xmm1, xmm1
000078d2e7de5152  movaps [r15+0x1E0], xmm1
000078d2e7de515a  movq xmm15, xmm15
000078d2e7de515f  movq xmm15, xmm15
000078d2e7de5164  movaps [r15+0x1D0], xmm15
000078d2e7de516c  lea r14, [rax+0x180]
000078d2e7de5173  mov r12, [r13+r14*1]
000078d2e7de5178  lea r14, [rax+0x188]
000078d2e7de517f  mov r10, [r13+r14*1]
000078d2e7de5184  movq xmm1, r12
000078d2e7de5189  movq xmm15, r10
000078d2e7de518e  movq xmm1, xmm1
000078d2e7de5192  movq xmm1, xmm1
000078d2e7de5196  movaps [r15+0x200], xmm1
000078d2e7de519e  movq xmm15, xmm15
000078d2e7de51a3  movq xmm15, xmm15
000078d2e7de51a8  movaps [r15+0x1F0], xmm15
000078d2e7de51b0  lea r14, [rax+0x1E0]
000078d2e7de51b7  mov [r15+0xF8], r14
000078d2e7de51be  mov [r15+0x100], r11
000078d2e7de51c5  jmp 0x000078D2E7DCE5C0
000078d2e7de51ca  int3
000078d2e7de51cb  call 0x000078D2E7CE27E0
000078d2e7de51d0  jmp 0x000078D2E7DE5043
000078d2e7de51d5  call 0x000078D2E7CE1570
000078d2e7de51da  jmp 0x000078D2E7DE504F
000078d2e7de51df  call 0x000078D2E7CC3FE0
000078d2e7de51e4  jmp 0x000078D2E7DE507A
000078d2e7de51e9  call 0x000078D2E7CE27E0
000078d2e7de51ee  jmp 0x000078D2E7DE5086
000078d2e7de51f3  call 0x000078D2E7CE1570
000078d2e7de51f8  jmp 0x000078D2E7DE5092
000078d2e7de51fd  call 0x000078D2E7CE27E0
000078d2e7de5202  jmp 0x000078D2E7DE50AC
000078d2e7de5207  call 0x000078D2E7CE0300
000078d2e7de520c  jmp 0x000078D2E7DE50B8
000078d2e7de5211  call 0x000078D2E7CE27E0
000078d2e7de5216  jmp 0x000078D2E7DE50F0
000078d2e7de521b  call 0x000078D2E7CE0300
000078d2e7de5220  jmp 0x000078D2E7DE50FC
000078d2e7de5225  call 0x000078D2E7CE27E0
000078d2e7de522a  jmp 0x000078D2E7DE5134
000078d2e7de522f  call 0x000078D2E7CE0300
000078d2e7de5234  jmp 0x000078D2E7DE5140
000078d2e7de5239  call 0x000078D2E7CE27E0
000078d2e7de523e  jmp 0x000078D2E7DE5178
000078d2e7de5243  call 0x000078D2E7CE0300
000078d2e7de5248  jmp 0x000078D2E7DE5184
000078d2e7de524d  int3
000078d2e7de524e  nop
000078d2e7de5250  mov qword ptr [r15+0x100], 0x04
000078d2e7de525b  mov esi, 0x00
000078d2e7de5260  mov edx, 0x09
000078d2e7de5265  mov rdi, 0x7FFE75BDEC90
000078d2e7de526f  mov rax, 0x5997D2C44970
000078d2e7de5279  call rax
000078d2e7de527b  cmp dword ptr [r15+0x318], 0x00
000078d2e7de5283  jnz 0x000078D2E7BFE110
000078d2e7de5289  jmp 0x000078D2E7BFE0A0
000078d2e7de528e  int3
000078d2e7de528f  int3
