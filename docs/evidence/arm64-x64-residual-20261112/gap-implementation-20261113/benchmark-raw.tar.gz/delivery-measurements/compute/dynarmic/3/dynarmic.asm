00007a3fbe1ce69b  nop [rax+rax*1], eax
00007a3fbe1ce6a0  mov rax, [r15+0xF8]
00007a3fbe1ce6a7  lea r14, [rax-0x1E0]
00007a3fbe1ce6ae  mov [r15+0xF8], r14
00007a3fbe1ce6b5  lea rax, [r14+0x1D0]
00007a3fbe1ce6bc  mov r12, [r15+0xA0]
00007a3fbe1ce6c3  mov r11, [r15+0x98]
00007a3fbe1ce6ca  mov [r13+rax*1], r12
00007a3fbe1ce6cf  lea rax, [r14+0x1D8]
00007a3fbe1ce6d6  mov [r13+rax*1], r11
00007a3fbe1ce6db  mov eax, 0x420AA0
00007a3fbe1ce6e0  movups xmm1, [r13+rax*1]
00007a3fbe1ce6e6  mov eax, 0x420A30
00007a3fbe1ce6eb  movups xmm15, [r13+rax*1]
00007a3fbe1ce6f1  mov eax, 0x420AC0
00007a3fbe1ce6f6  movups xmm14, [r13+rax*1]
00007a3fbe1ce6fc  mov eax, 0x420A60
00007a3fbe1ce701  movups xmm13, [r13+rax*1]
00007a3fbe1ce707  mov qword ptr [r15+0x98], 0x430CD0
00007a3fbe1ce712  mov eax, 0x420AD0
00007a3fbe1ce717  movups xmm12, [r13+rax*1]
00007a3fbe1ce71d  mov eax, 0x430CD0
00007a3fbe1ce722  movups [r13+rax*1], xmm1
00007a3fbe1ce728  mov eax, 0x430CE0
00007a3fbe1ce72d  movups [r13+rax*1], xmm15
00007a3fbe1ce733  mov eax, 0x430CF0
00007a3fbe1ce738  movups [r13+rax*1], xmm14
00007a3fbe1ce73e  mov eax, 0x430D00
00007a3fbe1ce743  movups [r13+rax*1], xmm13
00007a3fbe1ce749  mov eax, 0x420A20
00007a3fbe1ce74e  movups xmm14, [r13+rax*1]
00007a3fbe1ce754  mov eax, 0x420A10
00007a3fbe1ce759  movups xmm13, [r13+rax*1]
00007a3fbe1ce75f  mov eax, 0x430DD0
00007a3fbe1ce764  movups [r13+rax*1], xmm1
00007a3fbe1ce76a  mov eax, 0x430DE0
00007a3fbe1ce76f  movups [r13+rax*1], xmm15
00007a3fbe1ce775  mov eax, 0x430D10
00007a3fbe1ce77a  movups [r13+rax*1], xmm12
00007a3fbe1ce780  mov eax, 0x430D20
00007a3fbe1ce785  movups [r13+rax*1], xmm14
00007a3fbe1ce78b  mov eax, 0x420A00
00007a3fbe1ce790  movups xmm1, [r13+rax*1]
00007a3fbe1ce796  mov eax, 0x420A70
00007a3fbe1ce79b  movups xmm15, [r13+rax*1]
00007a3fbe1ce7a1  mov eax, 0x430D30
00007a3fbe1ce7a6  movups [r13+rax*1], xmm13
00007a3fbe1ce7ac  mov eax, 0x430D40
00007a3fbe1ce7b1  movups [r13+rax*1], xmm1
00007a3fbe1ce7b7  mov eax, 0x420A80
00007a3fbe1ce7bc  movups xmm1, [r13+rax*1]
00007a3fbe1ce7c2  mov eax, 0x420A50
00007a3fbe1ce7c7  movups xmm14, [r13+rax*1]
00007a3fbe1ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
00007a3fbe1ce7d5  mov eax, 0x430D50
00007a3fbe1ce7da  movups [r13+rax*1], xmm15
00007a3fbe1ce7e0  mov eax, 0x430D60
00007a3fbe1ce7e5  movups [r13+rax*1], xmm1
00007a3fbe1ce7eb  mov eax, 0x420AF0
00007a3fbe1ce7f0  movups xmm1, [r13+rax*1]
00007a3fbe1ce7f6  mov eax, 0x420B00
00007a3fbe1ce7fb  movups xmm15, [r13+rax*1]
00007a3fbe1ce801  movaps [r15+0x150], xmm15
00007a3fbe1ce809  mov qword ptr [r15+0xA0], 0x3E8
00007a3fbe1ce814  mov eax, 0x430D70
00007a3fbe1ce819  movups [r13+rax*1], xmm14
00007a3fbe1ce81f  mov eax, 0x430D80
00007a3fbe1ce824  movups [r13+rax*1], xmm1
00007a3fbe1ce82a  mov eax, 0x420AE0
00007a3fbe1ce82f  movups xmm1, [r13+rax*1]
00007a3fbe1ce835  mov eax, 0x420A90
00007a3fbe1ce83a  movups xmm14, [r13+rax*1]
00007a3fbe1ce840  movaps [r15+0x140], xmm14
00007a3fbe1ce848  lea rax, [r14+0x180]
00007a3fbe1ce84f  movq xmm13, qword ptr [r15+0x200]
00007a3fbe1ce858  movq xmm12, qword ptr [r15+0x1F0]
00007a3fbe1ce861  movq r12, xmm13
00007a3fbe1ce866  movq r11, xmm12
00007a3fbe1ce86b  mov [r13+rax*1], r12
00007a3fbe1ce870  lea rax, [r14+0x188]
00007a3fbe1ce877  mov [r13+rax*1], r11
00007a3fbe1ce87c  mov eax, 0x430D90
00007a3fbe1ce881  movups [r13+rax*1], xmm15
00007a3fbe1ce887  mov eax, 0x430DA0
00007a3fbe1ce88c  movups [r13+rax*1], xmm1
00007a3fbe1ce892  mov eax, 0x420AB0
00007a3fbe1ce897  movups xmm1, [r13+rax*1]
00007a3fbe1ce89d  mov eax, 0x420B18
00007a3fbe1ce8a2  mov r12, [r13+rax*1]
00007a3fbe1ce8a7  movq xmm15, r12
00007a3fbe1ce8ac  mov qword ptr [r15+0x40], 0x420B20
00007a3fbe1ce8b4  mov eax, 0x430DB0
00007a3fbe1ce8b9  movups [r13+rax*1], xmm14
00007a3fbe1ce8bf  mov eax, 0x430DC0
00007a3fbe1ce8c4  movups [r13+rax*1], xmm1
00007a3fbe1ce8ca  mov eax, 0x420B80
00007a3fbe1ce8cf  movups xmm1, [r13+rax*1]
00007a3fbe1ce8d5  movq rax, xmm15
00007a3fbe1ce8da  mov r12d, 0x430DF0
00007a3fbe1ce8e0  mov [r13+r12*1], rax
00007a3fbe1ce8e5  mov eax, 0x420B60
00007a3fbe1ce8ea  movups xmm15, [r13+rax*1]
00007a3fbe1ce8f0  mov eax, 0x420B70
00007a3fbe1ce8f5  movups xmm14, [r13+rax*1]
00007a3fbe1ce8fb  lea rax, [r14+0x160]
00007a3fbe1ce902  movups [r13+rax*1], xmm1
00007a3fbe1ce908  lea rax, [r14+0x190]
00007a3fbe1ce90f  movq xmm1, qword ptr [r15+0x1E0]
00007a3fbe1ce918  movq xmm13, qword ptr [r15+0x1D0]
00007a3fbe1ce921  movq r12, xmm1
00007a3fbe1ce926  movq r11, xmm13
00007a3fbe1ce92b  mov [r13+rax*1], r12
00007a3fbe1ce930  lea rax, [r14+0x198]
00007a3fbe1ce937  mov [r13+rax*1], r11
00007a3fbe1ce93c  lea rax, [r14+0x140]
00007a3fbe1ce943  movups [r13+rax*1], xmm15
00007a3fbe1ce949  lea rax, [r14+0x150]
00007a3fbe1ce950  movups [r13+rax*1], xmm14
00007a3fbe1ce956  mov eax, 0x420B20
00007a3fbe1ce95b  movups xmm1, [r13+rax*1]
00007a3fbe1ce961  mov eax, 0x420B30
00007a3fbe1ce966  movups xmm15, [r13+rax*1]
00007a3fbe1ce96c  movaps [r15+0x120], xmm15
00007a3fbe1ce974  lea rax, [r14+0x1A0]
00007a3fbe1ce97b  movq xmm14, qword ptr [r15+0x1C0]
00007a3fbe1ce984  movq xmm13, qword ptr [r15+0x1B0]
00007a3fbe1ce98d  movq r12, xmm14
00007a3fbe1ce992  movq r11, xmm13
00007a3fbe1ce997  mov [r13+rax*1], r12
00007a3fbe1ce99c  lea rax, [r14+0x1A8]
00007a3fbe1ce9a3  mov [r13+rax*1], r11
00007a3fbe1ce9a8  lea rax, [r14+0x1B0]
00007a3fbe1ce9af  movq xmm14, qword ptr [r15+0x1A0]
00007a3fbe1ce9b8  movq xmm13, qword ptr [r15+0x190]
00007a3fbe1ce9c1  movq r12, xmm14
00007a3fbe1ce9c6  movq r11, xmm13
00007a3fbe1ce9cb  mov [r13+rax*1], r12
00007a3fbe1ce9d0  lea rax, [r14+0x1B8]
00007a3fbe1ce9d7  mov [r13+rax*1], r11
00007a3fbe1ce9dc  lea rax, [r14+0x100]
00007a3fbe1ce9e3  movups [r13+rax*1], xmm1
00007a3fbe1ce9e9  lea rax, [r14+0x110]
00007a3fbe1ce9f0  movups [r13+rax*1], xmm15
00007a3fbe1ce9f6  mov eax, 0x420B40
00007a3fbe1ce9fb  movups xmm1, [r13+rax*1]
00007a3fbe1cea01  mov eax, 0x420B50
00007a3fbe1cea06  movups xmm15, [r13+rax*1]
00007a3fbe1cea0c  movaps [r15+0x110], xmm1
00007a3fbe1cea14  movaps [r15+0x130], xmm15
00007a3fbe1cea1c  lea rax, [r14+0x1C0]
00007a3fbe1cea23  mov r12, [r15+0xE8]
00007a3fbe1cea2a  mov r11, [r15+0xF0]
00007a3fbe1cea31  mov [r13+rax*1], r12
00007a3fbe1cea36  lea rax, [r14+0x1C8]
00007a3fbe1cea3d  mov [r13+rax*1], r11
00007a3fbe1cea42  mov eax, 0x430DF8
00007a3fbe1cea47  mov r12d, 0x421DF8D3
00007a3fbe1cea4d  mov [r13+rax*1], r12d
00007a3fbe1cea52  lea rax, [r14+0x120]
00007a3fbe1cea59  movups [r13+rax*1], xmm1
00007a3fbe1cea5f  lea rax, [r14+0x130]
00007a3fbe1cea66  movups [r13+rax*1], xmm15
00007a3fbe1cea6c  lea rax, [r14+0x100]
00007a3fbe1cea73  mov [r15], rax
00007a3fbe1cea76  mov qword ptr [r15+0x08], 0x430CD0
00007a3fbe1cea7e  mov qword ptr [r15+0x10], 0x12C
00007a3fbe1cea86  mov qword ptr [r15+0xF0], 0x410284
00007a3fbe1cea91  mov r14d, [r15+0x320]
00007a3fbe1cea98  mov eax, 0x410284
00007a3fbe1cea9d  mov rcx, 0x7A3FBE1D07C0
00007a3fbe1ceaa7  mov [r15+r14*8+0x328], rax
00007a3fbe1ceaaf  mov [r15+r14*8+0x368], rcx
00007a3fbe1ceab7  add r14d, 0x01
00007a3fbe1ceabb  and r14d, 0x07
00007a3fbe1ceabf  mov [r15+0x320], r14d
00007a3fbe1ceac6  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1ceace  jz 0x00007A3FBE1CED70
00007a3fbe1cead4  nop [rax+rax*1], ax
00007a3fbe1ceadd  nop [rax+rax*1], eax
00007a3fbe1ceae5  mov eax, 0x410728
00007a3fbe1ceaea  mov [r15+0x100], rax
00007a3fbe1ceaf1  jmp 0x00007A3FBDFFE110
00007a3fbe1ceaf6  int3
00007a3fbe1ceaf7  call 0x00007A3FBE00BC20
00007a3fbe1ceafc  jmp 0x00007A3FBE1CE6CF
00007a3fbe1ceb01  call 0x00007A3FBE00A9A0
00007a3fbe1ceb06  jmp 0x00007A3FBE1CE6DB
00007a3fbe1ceb0b  call 0x00007A3FBDFFF430
00007a3fbe1ceb10  jmp 0x00007A3FBE1CE6E6
00007a3fbe1ceb15  call 0x00007A3FBE00E760
00007a3fbe1ceb1a  jmp 0x00007A3FBE1CE6F1
00007a3fbe1ceb1f  call 0x00007A3FBE00D4E0
00007a3fbe1ceb24  jmp 0x00007A3FBE1CE6FC
00007a3fbe1ceb29  call 0x00007A3FBE00C260
00007a3fbe1ceb2e  jmp 0x00007A3FBE1CE707
00007a3fbe1ceb33  call 0x00007A3FBE00AFE0
00007a3fbe1ceb38  jmp 0x00007A3FBE1CE71D
00007a3fbe1ceb3d  call 0x00007A3FBDFFF540
00007a3fbe1ceb42  jmp 0x00007A3FBE1CE728
00007a3fbe1ceb47  call 0x00007A3FBE00E880
00007a3fbe1ceb4c  jmp 0x00007A3FBE1CE733
00007a3fbe1ceb51  call 0x00007A3FBE00D600
00007a3fbe1ceb56  jmp 0x00007A3FBE1CE73E
00007a3fbe1ceb5b  call 0x00007A3FBE00C380
00007a3fbe1ceb60  jmp 0x00007A3FBE1CE749
00007a3fbe1ceb65  call 0x00007A3FBE00D4E0
00007a3fbe1ceb6a  jmp 0x00007A3FBE1CE754
00007a3fbe1ceb6f  call 0x00007A3FBE00C260
00007a3fbe1ceb74  jmp 0x00007A3FBE1CE75F
00007a3fbe1ceb79  call 0x00007A3FBDFFF540
00007a3fbe1ceb7e  jmp 0x00007A3FBE1CE76A
00007a3fbe1ceb83  call 0x00007A3FBE00E880
00007a3fbe1ceb88  jmp 0x00007A3FBE1CE775
00007a3fbe1ceb8d  call 0x00007A3FBE00B100
00007a3fbe1ceb92  jmp 0x00007A3FBE1CE780
00007a3fbe1ceb97  call 0x00007A3FBE00D600
00007a3fbe1ceb9c  jmp 0x00007A3FBE1CE78B
00007a3fbe1ceba1  call 0x00007A3FBDFFF430
00007a3fbe1ceba6  jmp 0x00007A3FBE1CE796
00007a3fbe1cebab  call 0x00007A3FBE00E760
00007a3fbe1cebb0  jmp 0x00007A3FBE1CE7A1
00007a3fbe1cebb5  call 0x00007A3FBE00C380
00007a3fbe1cebba  jmp 0x00007A3FBE1CE7AC
00007a3fbe1cebbf  call 0x00007A3FBDFFF540
00007a3fbe1cebc4  jmp 0x00007A3FBE1CE7B7
00007a3fbe1cebc9  call 0x00007A3FBDFFF430
00007a3fbe1cebce  jmp 0x00007A3FBE1CE7C2
00007a3fbe1cebd3  call 0x00007A3FBE00D4E0
00007a3fbe1cebd8  jmp 0x00007A3FBE1CE7CD
00007a3fbe1cebdd  call 0x00007A3FBE00E880
00007a3fbe1cebe2  jmp 0x00007A3FBE1CE7E0
00007a3fbe1cebe7  call 0x00007A3FBDFFF540
00007a3fbe1cebec  jmp 0x00007A3FBE1CE7EB
00007a3fbe1cebf1  call 0x00007A3FBDFFF430
00007a3fbe1cebf6  jmp 0x00007A3FBE1CE7F6
00007a3fbe1cebfb  call 0x00007A3FBE00E760
00007a3fbe1cec00  jmp 0x00007A3FBE1CE801
00007a3fbe1cec05  call 0x00007A3FBE00D600
00007a3fbe1cec0a  jmp 0x00007A3FBE1CE81F
00007a3fbe1cec0f  call 0x00007A3FBDFFF540
00007a3fbe1cec14  jmp 0x00007A3FBE1CE82A
00007a3fbe1cec19  call 0x00007A3FBDFFF430
00007a3fbe1cec1e  jmp 0x00007A3FBE1CE835
00007a3fbe1cec23  call 0x00007A3FBE00D4E0
00007a3fbe1cec28  jmp 0x00007A3FBE1CE840
00007a3fbe1cec2d  call 0x00007A3FBE00BC20
00007a3fbe1cec32  jmp 0x00007A3FBE1CE870
00007a3fbe1cec37  call 0x00007A3FBE00A9A0
00007a3fbe1cec3c  jmp 0x00007A3FBE1CE87C
00007a3fbe1cec41  call 0x00007A3FBE00E880
00007a3fbe1cec46  jmp 0x00007A3FBE1CE887
00007a3fbe1cec4b  call 0x00007A3FBDFFF540
00007a3fbe1cec50  jmp 0x00007A3FBE1CE892
00007a3fbe1cec55  call 0x00007A3FBDFFF430
00007a3fbe1cec5a  jmp 0x00007A3FBE1CE89D
00007a3fbe1cec5f  call 0x00007A3FBE00B720
00007a3fbe1cec64  jmp 0x00007A3FBE1CE8A7
00007a3fbe1cec69  call 0x00007A3FBE00D600
00007a3fbe1cec6e  jmp 0x00007A3FBE1CE8BF
00007a3fbe1cec73  call 0x00007A3FBDFFF540
00007a3fbe1cec78  jmp 0x00007A3FBE1CE8CA
00007a3fbe1cec7d  call 0x00007A3FBDFFF430
00007a3fbe1cec82  jmp 0x00007A3FBE1CE8D5
00007a3fbe1cec87  call 0x00007A3FBE0B4CB0
00007a3fbe1cec8c  jmp 0x00007A3FBE1CE8E5
00007a3fbe1cec91  call 0x00007A3FBE00E760
00007a3fbe1cec96  jmp 0x00007A3FBE1CE8F0
00007a3fbe1cec9b  call 0x00007A3FBE00D4E0
00007a3fbe1ceca0  jmp 0x00007A3FBE1CE8FB
00007a3fbe1ceca5  call 0x00007A3FBDFFF540
00007a3fbe1cecaa  jmp 0x00007A3FBE1CE908
00007a3fbe1cecaf  call 0x00007A3FBE00BC20
00007a3fbe1cecb4  jmp 0x00007A3FBE1CE930
00007a3fbe1cecb9  call 0x00007A3FBE00A9A0
00007a3fbe1cecbe  jmp 0x00007A3FBE1CE93C
00007a3fbe1cecc3  call 0x00007A3FBE00E880
00007a3fbe1cecc8  jmp 0x00007A3FBE1CE949
00007a3fbe1ceccd  call 0x00007A3FBE00D600
00007a3fbe1cecd2  jmp 0x00007A3FBE1CE956
00007a3fbe1cecd7  call 0x00007A3FBDFFF430
00007a3fbe1cecdc  jmp 0x00007A3FBE1CE961
00007a3fbe1cece1  call 0x00007A3FBE00E760
00007a3fbe1cece6  jmp 0x00007A3FBE1CE96C
00007a3fbe1ceceb  call 0x00007A3FBE00BC20
00007a3fbe1cecf0  jmp 0x00007A3FBE1CE99C
00007a3fbe1cecf5  call 0x00007A3FBE00A9A0
00007a3fbe1cecfa  jmp 0x00007A3FBE1CE9A8
00007a3fbe1cecff  call 0x00007A3FBE00BC20
00007a3fbe1ced04  jmp 0x00007A3FBE1CE9D0
00007a3fbe1ced09  call 0x00007A3FBE00A9A0
00007a3fbe1ced0e  jmp 0x00007A3FBE1CE9DC
00007a3fbe1ced13  call 0x00007A3FBDFFF540
00007a3fbe1ced18  jmp 0x00007A3FBE1CE9E9
00007a3fbe1ced1d  call 0x00007A3FBE00E880
00007a3fbe1ced22  jmp 0x00007A3FBE1CE9F6
00007a3fbe1ced27  call 0x00007A3FBDFFF430
00007a3fbe1ced2c  jmp 0x00007A3FBE1CEA01
00007a3fbe1ced31  call 0x00007A3FBE00E760
00007a3fbe1ced36  jmp 0x00007A3FBE1CEA0C
00007a3fbe1ced3b  call 0x00007A3FBE00BC20
00007a3fbe1ced40  jmp 0x00007A3FBE1CEA36
00007a3fbe1ced45  call 0x00007A3FBE00A9A0
00007a3fbe1ced4a  jmp 0x00007A3FBE1CEA42
00007a3fbe1ced4f  call 0x00007A3FBE00BAE0
00007a3fbe1ced54  jmp 0x00007A3FBE1CEA52
00007a3fbe1ced59  call 0x00007A3FBDFFF540
00007a3fbe1ced5e  jmp 0x00007A3FBE1CEA5F
00007a3fbe1ced63  call 0x00007A3FBE00E880
00007a3fbe1ced68  jmp 0x00007A3FBE1CEA6C
00007a3fbe1ced6d  int3
00007a3fbe1ced6e  nop
00007a3fbe1ced70  mov rax, [r15]
00007a3fbe1ced73  lea r14, [rax+0x20]
00007a3fbe1ced77  mov r12, [r13+r14*1]
00007a3fbe1ced7c  mov r14, [r15+0x10]
00007a3fbe1ced80  lea r11, [r12+r14*1]
00007a3fbe1ced84  mov [r15+0x40], r11
00007a3fbe1ced88  lea r12, [rax+0x20]
00007a3fbe1ced8c  mov [r13+r12*1], r11
00007a3fbe1ced91  test r14, r14
00007a3fbe1ced94  setz r14b
00007a3fbe1ced98  movzx r14, r14b
00007a3fbe1ced9c  mov [rsp+0x414], r14b
00007a3fbe1ceda4  cmp byte ptr [rsp+0x414], 0x00
00007a3fbe1cedac  jz 0x00007A3FBE1CEDDE
00007a3fbe1cedae  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1cedb6  mov eax, 0x4109A0
00007a3fbe1cedbb  mov [r15+0x100], rax
00007a3fbe1cedc2  jz 0x00007A3FBDFFE0A0
00007a3fbe1cedc8  nop [rax+rax*1], eax
00007a3fbe1cedcd  mov eax, 0x4109A0
00007a3fbe1cedd2  mov [r15+0x100], rax
00007a3fbe1cedd9  jmp 0x00007A3FBDFFE110
00007a3fbe1cedde  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1cede6  jz 0x00007A3FBE1CEE30
00007a3fbe1cedec  nop [rax+rax*1], ax
00007a3fbe1cedf5  nop [rax+rax*1], eax
00007a3fbe1cedfd  mov eax, 0x410738
00007a3fbe1cee02  mov [r15+0x100], rax
00007a3fbe1cee09  jmp 0x00007A3FBDFFE110
00007a3fbe1cee0e  int3
00007a3fbe1cee0f  call 0x00007A3FBE0E27E0
00007a3fbe1cee14  jmp 0x00007A3FBE1CED7C
00007a3fbe1cee19  call 0x00007A3FBE0C0860
00007a3fbe1cee1e  jmp 0x00007A3FBE1CED91
00007a3fbe1cee23  int3
00007a3fbe1cee24  nop [rax+rax*1], ax
00007a3fbe1cee2d  nop [rax], eax
00007a3fbe1cee30  mov rax, [r15+0xF8]
00007a3fbe1cee37  lea r14, [rax-0x150]
00007a3fbe1cee3e  mov [r15+0xF8], r14
00007a3fbe1cee45  mov rax, [r15]
00007a3fbe1cee48  lea r12, [rax+0x68]
00007a3fbe1cee4c  mov r11, [r13+r12*1]
00007a3fbe1cee51  mov [r15+0x88], r11
00007a3fbe1cee58  lea r12, [rax+0x28]
00007a3fbe1cee5c  mov [r15+0x40], r12
00007a3fbe1cee60  mov [r15+0x48], r14
00007a3fbe1cee64  mov qword ptr [r15+0x50], 0x420B90
00007a3fbe1cee6c  lea rax, [r14+0x100]
00007a3fbe1cee73  mov r12, [r15+0xE8]
00007a3fbe1cee7a  mov r11, [r15+0xD8]
00007a3fbe1cee81  mov [r13+rax*1], r12
00007a3fbe1cee86  lea rax, [r14+0x108]
00007a3fbe1cee8d  mov [r13+rax*1], r11
00007a3fbe1cee92  lea rax, [r14+0x110]
00007a3fbe1cee99  mov r12, [r15+0xD0]
00007a3fbe1ceea0  mov r11, [r15+0xC8]
00007a3fbe1ceea7  mov [r13+rax*1], r12
00007a3fbe1ceeac  lea rax, [r14+0x118]
00007a3fbe1ceeb3  mov [r13+rax*1], r11
00007a3fbe1ceeb8  lea rax, [r14+0x120]
00007a3fbe1ceebf  mov r12, [r15+0xC0]
00007a3fbe1ceec6  mov r11, [r15+0xB8]
00007a3fbe1ceecd  mov [r13+rax*1], r12
00007a3fbe1ceed2  lea rax, [r14+0x128]
00007a3fbe1ceed9  mov [r13+rax*1], r11
00007a3fbe1ceede  lea rax, [r14+0x130]
00007a3fbe1ceee5  mov r12, [r15+0xB0]
00007a3fbe1ceeec  mov r11, [r15+0xA8]
00007a3fbe1ceef3  mov [r13+rax*1], r12
00007a3fbe1ceef8  lea rax, [r14+0x138]
00007a3fbe1ceeff  mov [r13+rax*1], r11
00007a3fbe1cef04  lea rax, [r14+0x140]
00007a3fbe1cef0b  mov r12, [r15+0xA0]
00007a3fbe1cef12  mov r11, [r15+0x98]
00007a3fbe1cef19  mov [r13+rax*1], r12
00007a3fbe1cef1e  lea rax, [r14+0x148]
00007a3fbe1cef25  mov [r13+rax*1], r11
00007a3fbe1cef2a  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1cef32  jz 0x00007A3FBE1CEFD0
00007a3fbe1cef38  nop [rax+rax*1], ax
00007a3fbe1cef41  nop [rax+rax*1], eax
00007a3fbe1cef49  mov eax, 0x410770
00007a3fbe1cef4e  mov [r15+0x100], rax
00007a3fbe1cef55  jmp 0x00007A3FBDFFE110
00007a3fbe1cef5a  int3
00007a3fbe1cef5b  call 0x00007A3FBE0C0370
00007a3fbe1cef60  jmp 0x00007A3FBE1CEE51
00007a3fbe1cef65  call 0x00007A3FBE00BC20
00007a3fbe1cef6a  jmp 0x00007A3FBE1CEE86
00007a3fbe1cef6f  call 0x00007A3FBE00A9A0
00007a3fbe1cef74  jmp 0x00007A3FBE1CEE92
00007a3fbe1cef79  call 0x00007A3FBE00BC20
00007a3fbe1cef7e  jmp 0x00007A3FBE1CEEAC
00007a3fbe1cef83  call 0x00007A3FBE00A9A0
00007a3fbe1cef88  jmp 0x00007A3FBE1CEEB8
00007a3fbe1cef8d  call 0x00007A3FBE00BC20
00007a3fbe1cef92  jmp 0x00007A3FBE1CEED2
00007a3fbe1cef97  call 0x00007A3FBE00A9A0
00007a3fbe1cef9c  jmp 0x00007A3FBE1CEEDE
00007a3fbe1cefa1  call 0x00007A3FBE00BC20
00007a3fbe1cefa6  jmp 0x00007A3FBE1CEEF8
00007a3fbe1cefab  call 0x00007A3FBE00A9A0
00007a3fbe1cefb0  jmp 0x00007A3FBE1CEF04
00007a3fbe1cefb5  call 0x00007A3FBE00BC20
00007a3fbe1cefba  jmp 0x00007A3FBE1CEF1E
00007a3fbe1cefbf  call 0x00007A3FBE00A9A0
00007a3fbe1cefc4  jmp 0x00007A3FBE1CEF2A
00007a3fbe1cefc9  int3
00007a3fbe1cefca  nop [rax+rax*1], ax
00007a3fbe1cefd0  mov rax, [r15+0x08]
00007a3fbe1cefd4  movzx r14d, byte ptr [r13+rax*1]
00007a3fbe1cefda  movzx r14d, r14b
00007a3fbe1cefde  mov [rsp+0x10], r14d
00007a3fbe1cefe3  mov r14d, r14d
00007a3fbe1cefe6  mov [r15+0x58], r14
00007a3fbe1cefea  lea r14, [rax+0x01]
00007a3fbe1cefee  mov [r15+0x08], r14
00007a3fbe1ceff2  mov rax, [r15+0x88]
00007a3fbe1ceff9  lea r14, [rax+0x01]
00007a3fbe1ceffd  mov r12, [r15]
00007a3fbe1cf000  lea r11, [r12+0x68]
00007a3fbe1cf005  mov [r13+r11*1], r14
00007a3fbe1cf00a  lea r14, [r12+rax*1]
00007a3fbe1cf00e  mov [r15+0x60], r14
00007a3fbe1cf012  lea rax, [r14+0x28]
00007a3fbe1cf016  mov r11d, [rsp+0x10]
00007a3fbe1cf01b  movzx r14d, r11b
00007a3fbe1cf01f  mov [r13+rax*1], r14b
00007a3fbe1cf024  lea rax, [r12+0x68]
00007a3fbe1cf029  mov r14, [r13+rax*1]
00007a3fbe1cf02e  mov [r15+0x88], r14
00007a3fbe1cf035  xor eax, eax
00007a3fbe1cf037  mov r12d, 0x40
00007a3fbe1cf03d  cmp r14, r12
00007a3fbe1cf040  cmc
00007a3fbe1cf041  lahf
00007a3fbe1cf042  seto al
00007a3fbe1cf045  mov [r15+0x108], eax
00007a3fbe1cf04c  mov eax, [r15+0x108]
00007a3fbe1cf053  sahf
00007a3fbe1cf054  jnz 0x00007A3FBE1CF086
00007a3fbe1cf056  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1cf05e  jz 0x00007A3FBE1CF170
00007a3fbe1cf064  nop [rax+rax*1], ax
00007a3fbe1cf06d  nop [rax+rax*1], eax
00007a3fbe1cf075  mov eax, 0x410790
00007a3fbe1cf07a  mov [r15+0x100], rax
00007a3fbe1cf081  jmp 0x00007A3FBDFFE110
00007a3fbe1cf086  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1cf08e  jz 0x00007A3FBE1CF0E0
00007a3fbe1cf094  nop [rax+rax*1], ax
00007a3fbe1cf09d  nop [rax+rax*1], eax
00007a3fbe1cf0a5  mov eax, 0x410768
00007a3fbe1cf0aa  mov [r15+0x100], rax
00007a3fbe1cf0b1  jmp 0x00007A3FBDFFE110
00007a3fbe1cf0b6  int3
00007a3fbe1cf0b7  call 0x00007A3FBE00D860
00007a3fbe1cf0bc  jmp 0x00007A3FBE1CEFDA
00007a3fbe1cf0c1  call 0x00007A3FBE0B36E0
00007a3fbe1cf0c6  jmp 0x00007A3FBE1CF00A
00007a3fbe1cf0cb  call 0x00007A3FBE00DD60
00007a3fbe1cf0d0  jmp 0x00007A3FBE1CF024
00007a3fbe1cf0d5  call 0x00007A3FBE00DC20
00007a3fbe1cf0da  jmp 0x00007A3FBE1CF02E
00007a3fbe1cf0df  int3
00007a3fbe1cf0e0  mov rax, [r15+0x10]
00007a3fbe1cf0e4  lea r14, [rax-0x01]
00007a3fbe1cf0e8  mov [r15+0x10], r14
00007a3fbe1cf0ec  test r14, r14
00007a3fbe1cf0ef  setz r14b
00007a3fbe1cf0f3  movzx r14, r14b
00007a3fbe1cf0f7  mov [rsp+0x414], r14b
00007a3fbe1cf0ff  cmp byte ptr [rsp+0x414], 0x00
00007a3fbe1cf107  jz 0x00007A3FBE1CF139
00007a3fbe1cf109  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1cf111  jz 0x00007A3FBE1D0670
00007a3fbe1cf117  nop [rax+rax*1], ax
00007a3fbe1cf120  nop [rax+rax*1], eax
00007a3fbe1cf128  mov eax, 0x410988
00007a3fbe1cf12d  mov [r15+0x100], rax
00007a3fbe1cf134  jmp 0x00007A3FBDFFE110
00007a3fbe1cf139  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1cf141  jz 0x00007A3FBE1CEFD0
00007a3fbe1cf147  nop [rax+rax*1], ax
00007a3fbe1cf150  nop [rax+rax*1], eax
00007a3fbe1cf158  mov eax, 0x410770
00007a3fbe1cf15d  mov [r15+0x100], rax
00007a3fbe1cf164  jmp 0x00007A3FBDFFE110
00007a3fbe1cf169  int3
00007a3fbe1cf16a  int3
00007a3fbe1cf16b  nop [rax+rax*1], eax
00007a3fbe1cf170  mov rax, [r15+0x40]
00007a3fbe1cf174  movzx r14d, byte ptr [r13+rax*1]
00007a3fbe1cf17a  movaps xmm1, [r15+0x110]
00007a3fbe1cf182  pinsrb xmm1, r14d, 0x00
00007a3fbe1cf189  lea r14, [rax+0x01]
00007a3fbe1cf18d  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf193  movaps xmm15, [r15+0x120]
00007a3fbe1cf19b  pinsrb xmm15, r12d, 0x00
00007a3fbe1cf1a2  lea r14, [rax+0x02]
00007a3fbe1cf1a6  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf1ac  movaps xmm14, [r15+0x130]
00007a3fbe1cf1b4  pinsrb xmm14, r12d, 0x00
00007a3fbe1cf1bb  lea r14, [rax+0x03]
00007a3fbe1cf1bf  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf1c5  movaps xmm13, [r15+0x140]
00007a3fbe1cf1cd  pinsrb xmm13, r12d, 0x00
00007a3fbe1cf1d4  lea r14, [rax+0x04]
00007a3fbe1cf1d8  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf1de  pinsrb xmm1, r12d, 0x01
00007a3fbe1cf1e5  lea r14, [rax+0x05]
00007a3fbe1cf1e9  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf1ef  pinsrb xmm15, r12d, 0x01
00007a3fbe1cf1f6  lea r14, [rax+0x06]
00007a3fbe1cf1fa  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf200  pinsrb xmm14, r12d, 0x01
00007a3fbe1cf207  lea r14, [rax+0x07]
00007a3fbe1cf20b  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf211  pinsrb xmm13, r12d, 0x01
00007a3fbe1cf218  lea r14, [rax+0x08]
00007a3fbe1cf21c  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf222  pinsrb xmm1, r12d, 0x02
00007a3fbe1cf229  lea r14, [rax+0x09]
00007a3fbe1cf22d  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf233  pinsrb xmm15, r12d, 0x02
00007a3fbe1cf23a  lea r14, [rax+0x0A]
00007a3fbe1cf23e  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf244  pinsrb xmm14, r12d, 0x02
00007a3fbe1cf24b  lea r14, [rax+0x0B]
00007a3fbe1cf24f  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf255  pinsrb xmm13, r12d, 0x02
00007a3fbe1cf25c  lea r14, [rax+0x0C]
00007a3fbe1cf260  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf266  pinsrb xmm1, r12d, 0x03
00007a3fbe1cf26d  lea r14, [rax+0x0D]
00007a3fbe1cf271  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf277  pinsrb xmm15, r12d, 0x03
00007a3fbe1cf27e  lea r14, [rax+0x0E]
00007a3fbe1cf282  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf288  pinsrb xmm14, r12d, 0x03
00007a3fbe1cf28f  lea r14, [rax+0x0F]
00007a3fbe1cf293  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf299  pinsrb xmm13, r12d, 0x03
00007a3fbe1cf2a0  lea r14, [rax+0x10]
00007a3fbe1cf2a4  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf2aa  pinsrb xmm1, r12d, 0x04
00007a3fbe1cf2b1  lea r14, [rax+0x11]
00007a3fbe1cf2b5  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf2bb  pinsrb xmm15, r12d, 0x04
00007a3fbe1cf2c2  lea r14, [rax+0x12]
00007a3fbe1cf2c6  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf2cc  pinsrb xmm14, r12d, 0x04
00007a3fbe1cf2d3  lea r14, [rax+0x13]
00007a3fbe1cf2d7  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf2dd  pinsrb xmm13, r12d, 0x04
00007a3fbe1cf2e4  lea r14, [rax+0x14]
00007a3fbe1cf2e8  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf2ee  pinsrb xmm1, r12d, 0x05
00007a3fbe1cf2f5  lea r14, [rax+0x15]
00007a3fbe1cf2f9  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf2ff  pinsrb xmm15, r12d, 0x05
00007a3fbe1cf306  lea r14, [rax+0x16]
00007a3fbe1cf30a  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf310  pinsrb xmm14, r12d, 0x05
00007a3fbe1cf317  lea r14, [rax+0x17]
00007a3fbe1cf31b  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf321  pinsrb xmm13, r12d, 0x05
00007a3fbe1cf328  lea r14, [rax+0x18]
00007a3fbe1cf32c  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf332  pinsrb xmm1, r12d, 0x06
00007a3fbe1cf339  lea r14, [rax+0x19]
00007a3fbe1cf33d  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf343  pinsrb xmm15, r12d, 0x06
00007a3fbe1cf34a  lea r14, [rax+0x1A]
00007a3fbe1cf34e  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf354  pinsrb xmm14, r12d, 0x06
00007a3fbe1cf35b  lea r14, [rax+0x1B]
00007a3fbe1cf35f  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf365  pinsrb xmm13, r12d, 0x06
00007a3fbe1cf36c  lea r14, [rax+0x1C]
00007a3fbe1cf370  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf376  pinsrb xmm1, r12d, 0x07
00007a3fbe1cf37d  lea r14, [rax+0x1D]
00007a3fbe1cf381  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf387  pinsrb xmm15, r12d, 0x07
00007a3fbe1cf38e  lea r14, [rax+0x1E]
00007a3fbe1cf392  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf398  pinsrb xmm14, r12d, 0x07
00007a3fbe1cf39f  lea r14, [rax+0x1F]
00007a3fbe1cf3a3  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf3a9  pinsrb xmm13, r12d, 0x07
00007a3fbe1cf3b0  lea r14, [rax+0x20]
00007a3fbe1cf3b4  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf3ba  pinsrb xmm1, r12d, 0x08
00007a3fbe1cf3c1  lea r14, [rax+0x21]
00007a3fbe1cf3c5  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf3cb  pinsrb xmm15, r12d, 0x08
00007a3fbe1cf3d2  lea r14, [rax+0x22]
00007a3fbe1cf3d6  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf3dc  pinsrb xmm14, r12d, 0x08
00007a3fbe1cf3e3  lea r14, [rax+0x23]
00007a3fbe1cf3e7  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf3ed  pinsrb xmm13, r12d, 0x08
00007a3fbe1cf3f4  lea r14, [rax+0x24]
00007a3fbe1cf3f8  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf3fe  pinsrb xmm1, r12d, 0x09
00007a3fbe1cf405  lea r14, [rax+0x25]
00007a3fbe1cf409  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf40f  pinsrb xmm15, r12d, 0x09
00007a3fbe1cf416  lea r14, [rax+0x26]
00007a3fbe1cf41a  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf420  pinsrb xmm14, r12d, 0x09
00007a3fbe1cf427  lea r14, [rax+0x27]
00007a3fbe1cf42b  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf431  pinsrb xmm13, r12d, 0x09
00007a3fbe1cf438  lea r14, [rax+0x28]
00007a3fbe1cf43c  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf442  pinsrb xmm1, r12d, 0x0A
00007a3fbe1cf449  lea r14, [rax+0x29]
00007a3fbe1cf44d  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf453  pinsrb xmm15, r12d, 0x0A
00007a3fbe1cf45a  lea r14, [rax+0x2A]
00007a3fbe1cf45e  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf464  pinsrb xmm14, r12d, 0x0A
00007a3fbe1cf46b  lea r14, [rax+0x2B]
00007a3fbe1cf46f  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf475  pinsrb xmm13, r12d, 0x0A
00007a3fbe1cf47c  lea r14, [rax+0x2C]
00007a3fbe1cf480  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf486  pinsrb xmm1, r12d, 0x0B
00007a3fbe1cf48d  lea r14, [rax+0x2D]
00007a3fbe1cf491  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf497  pinsrb xmm15, r12d, 0x0B
00007a3fbe1cf49e  lea r14, [rax+0x2E]
00007a3fbe1cf4a2  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf4a8  pinsrb xmm14, r12d, 0x0B
00007a3fbe1cf4af  lea r14, [rax+0x2F]
00007a3fbe1cf4b3  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf4b9  pinsrb xmm13, r12d, 0x0B
00007a3fbe1cf4c0  lea r14, [rax+0x30]
00007a3fbe1cf4c4  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf4ca  pinsrb xmm1, r12d, 0x0C
00007a3fbe1cf4d1  lea r14, [rax+0x31]
00007a3fbe1cf4d5  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf4db  pinsrb xmm15, r12d, 0x0C
00007a3fbe1cf4e2  lea r14, [rax+0x32]
00007a3fbe1cf4e6  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf4ec  pinsrb xmm14, r12d, 0x0C
00007a3fbe1cf4f3  lea r14, [rax+0x33]
00007a3fbe1cf4f7  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf4fd  pinsrb xmm13, r12d, 0x0C
00007a3fbe1cf504  lea r14, [rax+0x34]
00007a3fbe1cf508  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf50e  pinsrb xmm1, r12d, 0x0D
00007a3fbe1cf515  lea r14, [rax+0x35]
00007a3fbe1cf519  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf51f  pinsrb xmm15, r12d, 0x0D
00007a3fbe1cf526  lea r14, [rax+0x36]
00007a3fbe1cf52a  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf530  pinsrb xmm14, r12d, 0x0D
00007a3fbe1cf537  lea r14, [rax+0x37]
00007a3fbe1cf53b  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf541  pinsrb xmm13, r12d, 0x0D
00007a3fbe1cf548  lea r14, [rax+0x38]
00007a3fbe1cf54c  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf552  pinsrb xmm1, r12d, 0x0E
00007a3fbe1cf559  lea r14, [rax+0x39]
00007a3fbe1cf55d  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf563  pinsrb xmm15, r12d, 0x0E
00007a3fbe1cf56a  lea r14, [rax+0x3A]
00007a3fbe1cf56e  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf574  pinsrb xmm14, r12d, 0x0E
00007a3fbe1cf57b  lea r14, [rax+0x3B]
00007a3fbe1cf57f  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf585  pinsrb xmm13, r12d, 0x0E
00007a3fbe1cf58c  lea r14, [rax+0x3C]
00007a3fbe1cf590  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf596  pinsrb xmm1, r12d, 0x0F
00007a3fbe1cf59d  movaps [r15+0x110], xmm1
00007a3fbe1cf5a5  lea r14, [rax+0x3D]
00007a3fbe1cf5a9  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf5af  pinsrb xmm15, r12d, 0x0F
00007a3fbe1cf5b6  movaps [r15+0x120], xmm15
00007a3fbe1cf5be  lea r14, [rax+0x3E]
00007a3fbe1cf5c2  movzx r12d, byte ptr [r13+r14*1]
00007a3fbe1cf5c8  pinsrb xmm14, r12d, 0x0F
00007a3fbe1cf5cf  movaps [r15+0x130], xmm14
00007a3fbe1cf5d7  lea r14, [rax+0x3F]
00007a3fbe1cf5db  movzx eax, byte ptr [r13+r14*1]
00007a3fbe1cf5e1  pinsrb xmm13, eax, 0x0F
00007a3fbe1cf5e8  movaps [r15+0x140], xmm13
00007a3fbe1cf5f0  movq xmm1, qword ptr [r15+0x120]
00007a3fbe1cf5f9  pmovzxbw xmm1, xmm1
00007a3fbe1cf5fe  psllw xmm1, 0x00
00007a3fbe1cf603  movaps [r15+0x150], xmm1
00007a3fbe1cf60b  movq xmm1, qword ptr [r15+0x130]
00007a3fbe1cf614  pmovzxbw xmm1, xmm1
00007a3fbe1cf619  psllw xmm1, 0x00
00007a3fbe1cf61e  movaps [r15+0x160], xmm1
00007a3fbe1cf626  movq xmm1, qword ptr [r15+0x110]
00007a3fbe1cf62f  pmovzxbw xmm1, xmm1
00007a3fbe1cf634  psllw xmm1, 0x00
00007a3fbe1cf639  movaps [r15+0x170], xmm1
00007a3fbe1cf641  movaps xmm15, [r15+0x110]
00007a3fbe1cf649  pextrq rax, xmm15, 0x01
00007a3fbe1cf650  movq xmm15, rax
00007a3fbe1cf655  pmovzxbw xmm15, xmm15
00007a3fbe1cf65b  psllw xmm15, 0x00
00007a3fbe1cf661  movaps [r15+0x180], xmm15
00007a3fbe1cf669  movaps xmm14, [r15+0x120]
00007a3fbe1cf671  pextrq rax, xmm14, 0x01
00007a3fbe1cf678  movq xmm14, rax
00007a3fbe1cf67d  pmovzxbw xmm14, xmm14
00007a3fbe1cf683  psllw xmm14, 0x00
00007a3fbe1cf689  movaps [r15+0x210], xmm14
00007a3fbe1cf691  movaps xmm13, [r15+0x130]
00007a3fbe1cf699  pextrq rax, xmm13, 0x01
00007a3fbe1cf6a0  movq xmm13, rax
00007a3fbe1cf6a5  pmovzxbw xmm13, xmm13
00007a3fbe1cf6ab  psllw xmm13, 0x00
00007a3fbe1cf6b1  movaps [r15+0x220], xmm13
00007a3fbe1cf6b9  movq xmm12, qword ptr [r15+0x140]
00007a3fbe1cf6c2  pmovzxbw xmm12, xmm12
00007a3fbe1cf6c8  psllw xmm12, 0x00
00007a3fbe1cf6ce  movaps [r15+0x250], xmm12
00007a3fbe1cf6d6  movaps xmm12, [r15+0x140]
00007a3fbe1cf6de  pextrq rax, xmm12, 0x01
00007a3fbe1cf6e5  movq xmm12, rax
00007a3fbe1cf6ea  pmovzxbw xmm12, xmm12
00007a3fbe1cf6f0  psllw xmm12, 0x00
00007a3fbe1cf6f6  movaps [r15+0x110], xmm12
00007a3fbe1cf6fe  movq xmm11, qword ptr [r15+0x150]
00007a3fbe1cf707  pmovzxwd xmm11, xmm11
00007a3fbe1cf70d  pslld xmm11, 0x10
00007a3fbe1cf713  movq xmm10, qword ptr [r15+0x160]
00007a3fbe1cf71c  pmovzxwd xmm10, xmm10
00007a3fbe1cf722  pslld xmm10, 0x08
00007a3fbe1cf728  pextrq rax, xmm1, 0x01
00007a3fbe1cf72f  movq xmm1, rax
00007a3fbe1cf734  pmovzxwd xmm1, xmm1
00007a3fbe1cf739  pslld xmm1, 0x00
00007a3fbe1cf73e  movaps [r15+0x260], xmm1
00007a3fbe1cf746  pextrq rax, xmm15, 0x01
00007a3fbe1cf74d  movq xmm15, rax
00007a3fbe1cf752  pmovzxwd xmm15, xmm15
00007a3fbe1cf758  pslld xmm15, 0x00
00007a3fbe1cf75e  movaps [r15+0x270], xmm15
00007a3fbe1cf766  movq xmm9, qword ptr [r15+0x170]
00007a3fbe1cf76f  pmovzxwd xmm9, xmm9
00007a3fbe1cf775  pslld xmm9, 0x00
00007a3fbe1cf77b  pextrq rax, xmm14, 0x01
00007a3fbe1cf782  movq xmm14, rax
00007a3fbe1cf787  pmovzxwd xmm14, xmm14
00007a3fbe1cf78d  pslld xmm14, 0x10
00007a3fbe1cf793  movaps [r15+0x280], xmm14
00007a3fbe1cf79b  movq xmm8, qword ptr [r15+0x180]
00007a3fbe1cf7a4  pmovzxwd xmm8, xmm8
00007a3fbe1cf7aa  pslld xmm8, 0x00
00007a3fbe1cf7b0  movq xmm7, qword ptr [r15+0x210]
00007a3fbe1cf7b9  pmovzxwd xmm7, xmm7
00007a3fbe1cf7be  pslld xmm7, 0x10
00007a3fbe1cf7c3  movaps xmm6, [r15+0x150]
00007a3fbe1cf7cb  pextrq rax, xmm6, 0x01
00007a3fbe1cf7d2  movq xmm6, rax
00007a3fbe1cf7d7  pmovzxwd xmm6, xmm6
00007a3fbe1cf7dc  pslld xmm6, 0x10
00007a3fbe1cf7e1  por xmm11, xmm10
00007a3fbe1cf7e6  movaps [r15+0x230], xmm11
00007a3fbe1cf7ee  pextrq rax, xmm13, 0x01
00007a3fbe1cf7f5  movq xmm13, rax
00007a3fbe1cf7fa  pmovzxwd xmm13, xmm13
00007a3fbe1cf800  pslld xmm13, 0x08
00007a3fbe1cf806  movaps [r15+0x240], xmm13
00007a3fbe1cf80e  movq xmm10, qword ptr [r15+0x220]
00007a3fbe1cf817  pmovzxwd xmm10, xmm10
00007a3fbe1cf81d  pslld xmm10, 0x08
00007a3fbe1cf823  movaps xmm5, [r15+0x160]
00007a3fbe1cf82b  pextrq rax, xmm5, 0x01
00007a3fbe1cf832  movq xmm5, rax
00007a3fbe1cf837  pmovzxwd xmm5, xmm5
00007a3fbe1cf83c  pslld xmm5, 0x08
00007a3fbe1cf841  pslld xmm9, 0x18
00007a3fbe1cf847  pslld xmm15, 0x18
00007a3fbe1cf84d  pslld xmm8, 0x18
00007a3fbe1cf853  movq xmm4, qword ptr [r15+0x250]
00007a3fbe1cf85c  pmovzxwd xmm4, xmm4
00007a3fbe1cf861  pslld xmm4, 0x00
00007a3fbe1cf866  por xmm14, xmm13
00007a3fbe1cf86b  por xmm7, xmm10
00007a3fbe1cf870  movaps [r15+0x210], xmm7
00007a3fbe1cf878  pslld xmm1, 0x18
00007a3fbe1cf87d  movaps [r15+0x220], xmm1
00007a3fbe1cf885  por xmm6, xmm5
00007a3fbe1cf889  por xmm11, xmm9
00007a3fbe1cf88e  movaps [r15+0x160], xmm11
00007a3fbe1cf896  pextrq rax, xmm12, 0x01
00007a3fbe1cf89d  movq xmm13, rax
00007a3fbe1cf8a2  pmovzxwd xmm13, xmm13
00007a3fbe1cf8a8  pslld xmm13, 0x00
00007a3fbe1cf8ae  movaps [r15+0x170], xmm13
00007a3fbe1cf8b6  movq xmm12, qword ptr [r15+0x110]
00007a3fbe1cf8bf  pmovzxwd xmm12, xmm12
00007a3fbe1cf8c5  pslld xmm12, 0x00
00007a3fbe1cf8cb  por xmm14, xmm15
00007a3fbe1cf8d0  por xmm7, xmm8
00007a3fbe1cf8d5  movaps xmm15, [r15+0x250]
00007a3fbe1cf8dd  pextrq rax, xmm15, 0x01
00007a3fbe1cf8e4  movq xmm15, rax
00007a3fbe1cf8e9  pmovzxwd xmm15, xmm15
00007a3fbe1cf8ef  pslld xmm15, 0x00
00007a3fbe1cf8f5  movaps [r15+0x180], xmm15
00007a3fbe1cf8fd  por xmm6, xmm1
00007a3fbe1cf901  movaps [r15+0x150], xmm6
00007a3fbe1cf909  por xmm11, xmm4
00007a3fbe1cf90e  movaps [r15+0x140], xmm11
00007a3fbe1cf916  por xmm7, xmm12
00007a3fbe1cf91b  movaps [r15+0x110], xmm7
00007a3fbe1cf923  por xmm14, xmm13
00007a3fbe1cf928  movaps [r15+0x120], xmm14
00007a3fbe1cf930  por xmm6, xmm15
00007a3fbe1cf935  movaps [r15+0x130], xmm6
00007a3fbe1cf93d  mov rax, [r15+0xF8]
00007a3fbe1cf944  lea r14, [rax+0x20]
00007a3fbe1cf948  movups [r13+r14*1], xmm7
00007a3fbe1cf94e  lea r14, [rax+0x30]
00007a3fbe1cf952  movups [r13+r14*1], xmm14
00007a3fbe1cf958  movups [r13+rax*1], xmm11
00007a3fbe1cf95e  lea r14, [rax+0x10]
00007a3fbe1cf962  movups [r13+r14*1], xmm6
00007a3fbe1cf968  mov r14d, [r13+rax*1]
00007a3fbe1cf96d  mov rax, [r15+0x48]
00007a3fbe1cf971  mov [r15+0x68], rax
00007a3fbe1cf975  mov qword ptr [r15+0x58], 0x04
00007a3fbe1cf97d  lea r12, [rax+0x04]
00007a3fbe1cf981  mov r11d, [r13+r12*1]
00007a3fbe1cf986  mov [rsp+0x10], r11d
00007a3fbe1cf98b  mov r11d, r11d
00007a3fbe1cf98e  mov [r15+0x70], r11
00007a3fbe1cf992  lea r12, [rax+0x38]
00007a3fbe1cf996  mov r11d, [r13+r12*1]
00007a3fbe1cf99b  lea r12, [rax+0x24]
00007a3fbe1cf99f  mov r10d, [r13+r12*1]
00007a3fbe1cf9a4  mov [rsp+0x20], r10d
00007a3fbe1cf9a9  mov r10d, r10d
00007a3fbe1cf9ac  mov [r15+0x90], r10
00007a3fbe1cf9b3  mov [rsp+0x30], rax
00007a3fbe1cf9b8  xor eax, eax
00007a3fbe1cf9ba  mov r12d, 0x04
00007a3fbe1cf9c0  mov r10d, 0xC0
00007a3fbe1cf9c6  cmp r12, r10
00007a3fbe1cf9c9  cmc
00007a3fbe1cf9ca  lahf
00007a3fbe1cf9cb  seto al
00007a3fbe1cf9ce  mov [r15+0x108], eax
00007a3fbe1cf9d5  mov eax, [rsp+0x10]
00007a3fbe1cf9d9  mov r12d, [rsp+0x10]
00007a3fbe1cf9de  shrd eax, r12d, 0x07
00007a3fbe1cf9e3  mov [rsp+0x10], r11d
00007a3fbe1cf9e8  mov r10d, [rsp+0x10]
00007a3fbe1cf9ed  shrd r11d, r10d, 0x11
00007a3fbe1cf9f2  mov r9d, [rsp+0x20]
00007a3fbe1cf9f7  lea r8d, [r9d+r14d*1]
00007a3fbe1cf9fc  rorx r14d, r12d, 0x12
00007a3fbe1cfa02  xor eax, r14d
00007a3fbe1cfa05  rorx r14d, r10d, 0x13
00007a3fbe1cfa0b  xor r11d, r14d
00007a3fbe1cfa0e  mov [rsp+0x10], r11d
00007a3fbe1cfa13  mov r11d, r11d
00007a3fbe1cfa16  mov [r15+0x88], r11
00007a3fbe1cfa1d  mov [rsp+0x20], r12d
00007a3fbe1cfa22  shr r12d, 0x03
00007a3fbe1cfa26  xor eax, r12d
00007a3fbe1cfa29  mov [rsp+0x40], eax
00007a3fbe1cfa2d  mov eax, eax
00007a3fbe1cfa2f  mov [r15+0x80], rax
00007a3fbe1cfa36  shr r10d, 0x0A
00007a3fbe1cfa3a  mov eax, [rsp+0x10]
00007a3fbe1cfa3e  xor eax, r10d
00007a3fbe1cfa41  mov [rsp+0x10], eax
00007a3fbe1cfa45  mov eax, eax
00007a3fbe1cfa47  mov [r15+0x78], rax
00007a3fbe1cfa4b  mov eax, [rsp+0x40]
00007a3fbe1cfa4f  lea r14d, [r8d+eax*1]
00007a3fbe1cfa54  mov eax, [rsp+0x10]
00007a3fbe1cfa58  lea r12d, [r14d+eax*1]
00007a3fbe1cfa5d  mov rax, [rsp+0x30]
00007a3fbe1cfa62  lea r14, [rax+0x40]
00007a3fbe1cfa66  mov [r13+r14*1], r12d
00007a3fbe1cfa6b  mov eax, [rsp+0x20]
00007a3fbe1cfa6f  mov eax, eax
00007a3fbe1cfa71  mov [r15+0x60], rax
00007a3fbe1cfa75  mov eax, [r15+0x108]
00007a3fbe1cfa7c  sahf
00007a3fbe1cfa7d  jnz 0x00007A3FBE1CFAAF
00007a3fbe1cfa7f  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1cfa87  jz 0x00007A3FBE1CFF70
00007a3fbe1cfa8d  nop [rax+rax*1], ax
00007a3fbe1cfa96  nop [rax+rax*1], eax
00007a3fbe1cfa9e  mov eax, 0x41088C
00007a3fbe1cfaa3  mov [r15+0x100], rax
00007a3fbe1cfaaa  jmp 0x00007A3FBDFFE110
00007a3fbe1cfaaf  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1cfab7  jz 0x00007A3FBE1CFDC0
00007a3fbe1cfabd  nop [rax+rax*1], ax
00007a3fbe1cfac6  nop [rax+rax*1], eax
00007a3fbe1cface  mov eax, 0x410844
00007a3fbe1cfad3  mov [r15+0x100], rax
00007a3fbe1cfada  jmp 0x00007A3FBDFFE110
00007a3fbe1cfadf  int3
00007a3fbe1cfae0  call 0x00007A3FBE00D860
00007a3fbe1cfae5  jmp 0x00007A3FBE1CF17A
00007a3fbe1cfaea  call 0x00007A3FBE0E2420
00007a3fbe1cfaef  jmp 0x00007A3FBE1CF193
00007a3fbe1cfaf4  call 0x00007A3FBE0E2420
00007a3fbe1cfaf9  jmp 0x00007A3FBE1CF1AC
00007a3fbe1cfafe  call 0x00007A3FBE0E2420
00007a3fbe1cfb03  jmp 0x00007A3FBE1CF1C5
00007a3fbe1cfb08  call 0x00007A3FBE0E2420
00007a3fbe1cfb0d  jmp 0x00007A3FBE1CF1DE
00007a3fbe1cfb12  call 0x00007A3FBE0E2420
00007a3fbe1cfb17  jmp 0x00007A3FBE1CF1EF
00007a3fbe1cfb1c  call 0x00007A3FBE0E2420
00007a3fbe1cfb21  jmp 0x00007A3FBE1CF200
00007a3fbe1cfb26  call 0x00007A3FBE0E2420
00007a3fbe1cfb2b  jmp 0x00007A3FBE1CF211
00007a3fbe1cfb30  call 0x00007A3FBE0E2420
00007a3fbe1cfb35  jmp 0x00007A3FBE1CF222
00007a3fbe1cfb3a  call 0x00007A3FBE0E2420
00007a3fbe1cfb3f  jmp 0x00007A3FBE1CF233
00007a3fbe1cfb44  call 0x00007A3FBE0E2420
00007a3fbe1cfb49  jmp 0x00007A3FBE1CF244
00007a3fbe1cfb4e  call 0x00007A3FBE0E2420
00007a3fbe1cfb53  jmp 0x00007A3FBE1CF255
00007a3fbe1cfb58  call 0x00007A3FBE0E2420
00007a3fbe1cfb5d  jmp 0x00007A3FBE1CF266
00007a3fbe1cfb62  call 0x00007A3FBE0E2420
00007a3fbe1cfb67  jmp 0x00007A3FBE1CF277
00007a3fbe1cfb6c  call 0x00007A3FBE0E2420
00007a3fbe1cfb71  jmp 0x00007A3FBE1CF288
00007a3fbe1cfb76  call 0x00007A3FBE0E2420
00007a3fbe1cfb7b  jmp 0x00007A3FBE1CF299
00007a3fbe1cfb80  call 0x00007A3FBE0E2420
00007a3fbe1cfb85  jmp 0x00007A3FBE1CF2AA
00007a3fbe1cfb8a  call 0x00007A3FBE0E2420
00007a3fbe1cfb8f  jmp 0x00007A3FBE1CF2BB
00007a3fbe1cfb94  call 0x00007A3FBE0E2420
00007a3fbe1cfb99  jmp 0x00007A3FBE1CF2CC
00007a3fbe1cfb9e  call 0x00007A3FBE0E2420
00007a3fbe1cfba3  jmp 0x00007A3FBE1CF2DD
00007a3fbe1cfba8  call 0x00007A3FBE0E2420
00007a3fbe1cfbad  jmp 0x00007A3FBE1CF2EE
00007a3fbe1cfbb2  call 0x00007A3FBE0E2420
00007a3fbe1cfbb7  jmp 0x00007A3FBE1CF2FF
00007a3fbe1cfbbc  call 0x00007A3FBE0E2420
00007a3fbe1cfbc1  jmp 0x00007A3FBE1CF310
00007a3fbe1cfbc6  call 0x00007A3FBE0E2420
00007a3fbe1cfbcb  jmp 0x00007A3FBE1CF321
00007a3fbe1cfbd0  call 0x00007A3FBE0E2420
00007a3fbe1cfbd5  jmp 0x00007A3FBE1CF332
00007a3fbe1cfbda  call 0x00007A3FBE0E2420
00007a3fbe1cfbdf  jmp 0x00007A3FBE1CF343
00007a3fbe1cfbe4  call 0x00007A3FBE0E2420
00007a3fbe1cfbe9  jmp 0x00007A3FBE1CF354
00007a3fbe1cfbee  call 0x00007A3FBE0E2420
00007a3fbe1cfbf3  jmp 0x00007A3FBE1CF365
00007a3fbe1cfbf8  call 0x00007A3FBE0E2420
00007a3fbe1cfbfd  jmp 0x00007A3FBE1CF376
00007a3fbe1cfc02  call 0x00007A3FBE0E2420
00007a3fbe1cfc07  jmp 0x00007A3FBE1CF387
00007a3fbe1cfc0c  call 0x00007A3FBE0E2420
00007a3fbe1cfc11  jmp 0x00007A3FBE1CF398
00007a3fbe1cfc16  call 0x00007A3FBE0E2420
00007a3fbe1cfc1b  jmp 0x00007A3FBE1CF3A9
00007a3fbe1cfc20  call 0x00007A3FBE0E2420
00007a3fbe1cfc25  jmp 0x00007A3FBE1CF3BA
00007a3fbe1cfc2a  call 0x00007A3FBE0E2420
00007a3fbe1cfc2f  jmp 0x00007A3FBE1CF3CB
00007a3fbe1cfc34  call 0x00007A3FBE0E2420
00007a3fbe1cfc39  jmp 0x00007A3FBE1CF3DC
00007a3fbe1cfc3e  call 0x00007A3FBE0E2420
00007a3fbe1cfc43  jmp 0x00007A3FBE1CF3ED
00007a3fbe1cfc48  call 0x00007A3FBE0E2420
00007a3fbe1cfc4d  jmp 0x00007A3FBE1CF3FE
00007a3fbe1cfc52  call 0x00007A3FBE0E2420
00007a3fbe1cfc57  jmp 0x00007A3FBE1CF40F
00007a3fbe1cfc5c  call 0x00007A3FBE0E2420
00007a3fbe1cfc61  jmp 0x00007A3FBE1CF420
00007a3fbe1cfc66  call 0x00007A3FBE0E2420
00007a3fbe1cfc6b  jmp 0x00007A3FBE1CF431
00007a3fbe1cfc70  call 0x00007A3FBE0E2420
00007a3fbe1cfc75  jmp 0x00007A3FBE1CF442
00007a3fbe1cfc7a  call 0x00007A3FBE0E2420
00007a3fbe1cfc7f  jmp 0x00007A3FBE1CF453
00007a3fbe1cfc84  call 0x00007A3FBE0E2420
00007a3fbe1cfc89  jmp 0x00007A3FBE1CF464
00007a3fbe1cfc8e  call 0x00007A3FBE0E2420
00007a3fbe1cfc93  jmp 0x00007A3FBE1CF475
00007a3fbe1cfc98  call 0x00007A3FBE0E2420
00007a3fbe1cfc9d  jmp 0x00007A3FBE1CF486
00007a3fbe1cfca2  call 0x00007A3FBE0E2420
00007a3fbe1cfca7  jmp 0x00007A3FBE1CF497
00007a3fbe1cfcac  call 0x00007A3FBE0E2420
00007a3fbe1cfcb1  jmp 0x00007A3FBE1CF4A8
00007a3fbe1cfcb6  call 0x00007A3FBE0E2420
00007a3fbe1cfcbb  jmp 0x00007A3FBE1CF4B9
00007a3fbe1cfcc0  call 0x00007A3FBE0E2420
00007a3fbe1cfcc5  jmp 0x00007A3FBE1CF4CA
00007a3fbe1cfcca  call 0x00007A3FBE0E2420
00007a3fbe1cfccf  jmp 0x00007A3FBE1CF4DB
00007a3fbe1cfcd4  call 0x00007A3FBE0E2420
00007a3fbe1cfcd9  jmp 0x00007A3FBE1CF4EC
00007a3fbe1cfcde  call 0x00007A3FBE0E2420
00007a3fbe1cfce3  jmp 0x00007A3FBE1CF4FD
00007a3fbe1cfce8  call 0x00007A3FBE0E2420
00007a3fbe1cfced  jmp 0x00007A3FBE1CF50E
00007a3fbe1cfcf2  call 0x00007A3FBE0E2420
00007a3fbe1cfcf7  jmp 0x00007A3FBE1CF51F
00007a3fbe1cfcfc  call 0x00007A3FBE0E2420
00007a3fbe1cfd01  jmp 0x00007A3FBE1CF530
00007a3fbe1cfd06  call 0x00007A3FBE0E2420
00007a3fbe1cfd0b  jmp 0x00007A3FBE1CF541
00007a3fbe1cfd10  call 0x00007A3FBE0E2420
00007a3fbe1cfd15  jmp 0x00007A3FBE1CF552
00007a3fbe1cfd1a  call 0x00007A3FBE0E2420
00007a3fbe1cfd1f  jmp 0x00007A3FBE1CF563
00007a3fbe1cfd24  call 0x00007A3FBE0E2420
00007a3fbe1cfd29  jmp 0x00007A3FBE1CF574
00007a3fbe1cfd2e  call 0x00007A3FBE0E2420
00007a3fbe1cfd33  jmp 0x00007A3FBE1CF585
00007a3fbe1cfd38  call 0x00007A3FBE0E2420
00007a3fbe1cfd3d  jmp 0x00007A3FBE1CF596
00007a3fbe1cfd42  call 0x00007A3FBE0E2420
00007a3fbe1cfd47  jmp 0x00007A3FBE1CF5AF
00007a3fbe1cfd4c  call 0x00007A3FBE0E2420
00007a3fbe1cfd51  jmp 0x00007A3FBE1CF5C8
00007a3fbe1cfd56  call 0x00007A3FBE0D5610
00007a3fbe1cfd5b  jmp 0x00007A3FBE1CF5E1
00007a3fbe1cfd60  call 0x00007A3FBE0DC580
00007a3fbe1cfd65  jmp 0x00007A3FBE1CF94E
00007a3fbe1cfd6a  call 0x00007A3FBE0E46C0
00007a3fbe1cfd6f  jmp 0x00007A3FBE1CF958
00007a3fbe1cfd74  call 0x00007A3FBE009E90
00007a3fbe1cfd79  jmp 0x00007A3FBE1CF95E
00007a3fbe1cfd7e  call 0x00007A3FBE0DB310
00007a3fbe1cfd83  jmp 0x00007A3FBE1CF968
00007a3fbe1cfd88  call 0x00007A3FBE00DAE0
00007a3fbe1cfd8d  jmp 0x00007A3FBE1CF96D
00007a3fbe1cfd92  call 0x00007A3FBE0C0230
00007a3fbe1cfd97  jmp 0x00007A3FBE1CF986
00007a3fbe1cfd9c  call 0x00007A3FBE0C0230
00007a3fbe1cfda1  jmp 0x00007A3FBE1CF99B
00007a3fbe1cfda6  call 0x00007A3FBE0BEFC0
00007a3fbe1cfdab  jmp 0x00007A3FBE1CF9A4
00007a3fbe1cfdb0  call 0x00007A3FBE0E2BA0
00007a3fbe1cfdb5  jmp 0x00007A3FBE1CFA6B
00007a3fbe1cfdba  int3
00007a3fbe1cfdbb  nop [rax+rax*1], eax
00007a3fbe1cfdc0  mov rax, [r15+0x48]
00007a3fbe1cfdc4  mov r14, [r15+0x58]
00007a3fbe1cfdc8  lea r12, [rax+r14*1]
00007a3fbe1cfdcc  mov [r15+0x68], r12
00007a3fbe1cfdd0  lea rax, [r14+0x04]
00007a3fbe1cfdd4  mov [r15+0x58], rax
00007a3fbe1cfdd8  lea r14, [r12+0x04]
00007a3fbe1cfddd  mov r11d, [r13+r14*1]
00007a3fbe1cfde2  mov [rsp+0x10], r11d
00007a3fbe1cfde7  mov r11d, r11d
00007a3fbe1cfdea  mov [r15+0x70], r11
00007a3fbe1cfdee  lea r14, [r12+0x38]
00007a3fbe1cfdf3  mov r11d, [r13+r14*1]
00007a3fbe1cfdf8  lea r14, [r12+0x24]
00007a3fbe1cfdfd  mov r10d, [r13+r14*1]
00007a3fbe1cfe02  mov [rsp+0x20], r10d
00007a3fbe1cfe07  mov r10d, r10d
00007a3fbe1cfe0a  mov [r15+0x90], r10
00007a3fbe1cfe11  mov [rsp+0x30], rax
00007a3fbe1cfe16  xor eax, eax
00007a3fbe1cfe18  mov r14, [rsp+0x30]
00007a3fbe1cfe1d  mov r10d, 0xC0
00007a3fbe1cfe23  cmp r14, r10
00007a3fbe1cfe26  cmc
00007a3fbe1cfe27  lahf
00007a3fbe1cfe28  seto al
00007a3fbe1cfe2b  mov [r15+0x108], eax
00007a3fbe1cfe32  mov eax, [rsp+0x10]
00007a3fbe1cfe36  mov r14d, [rsp+0x10]
00007a3fbe1cfe3b  shrd eax, r14d, 0x07
00007a3fbe1cfe40  mov [rsp+0x10], r11d
00007a3fbe1cfe45  mov r10d, [rsp+0x10]
00007a3fbe1cfe4a  shrd r11d, r10d, 0x11
00007a3fbe1cfe4f  mov r9d, [r15+0x60]
00007a3fbe1cfe53  mov r8d, [rsp+0x20]
00007a3fbe1cfe58  lea ebp, [r8d+r9d*1]
00007a3fbe1cfe5d  rorx r9d, r14d, 0x12
00007a3fbe1cfe63  xor eax, r9d
00007a3fbe1cfe66  rorx r9d, r10d, 0x13
00007a3fbe1cfe6c  xor r11d, r9d
00007a3fbe1cfe6f  mov [rsp+0x10], r11d
00007a3fbe1cfe74  mov r11d, r11d
00007a3fbe1cfe77  mov [r15+0x88], r11
00007a3fbe1cfe7e  mov [rsp+0x20], r14d
00007a3fbe1cfe83  shr r14d, 0x03
00007a3fbe1cfe87  xor eax, r14d
00007a3fbe1cfe8a  mov [rsp+0x30], eax
00007a3fbe1cfe8e  mov eax, eax
00007a3fbe1cfe90  mov [r15+0x80], rax
00007a3fbe1cfe97  shr r10d, 0x0A
00007a3fbe1cfe9b  mov eax, [rsp+0x10]
00007a3fbe1cfe9f  xor eax, r10d
00007a3fbe1cfea2  mov [rsp+0x10], eax
00007a3fbe1cfea6  mov eax, eax
00007a3fbe1cfea8  mov [r15+0x78], rax
00007a3fbe1cfeac  mov eax, [rsp+0x30]
00007a3fbe1cfeb0  lea r14d, [ebp+eax*1]
00007a3fbe1cfeb6  mov eax, [rsp+0x10]
00007a3fbe1cfeba  lea r11d, [r14d+eax*1]
00007a3fbe1cfebf  lea rax, [r12+0x40]
00007a3fbe1cfec4  mov [r13+rax*1], r11d
00007a3fbe1cfec9  mov eax, [rsp+0x20]
00007a3fbe1cfecd  mov eax, eax
00007a3fbe1cfecf  mov [r15+0x60], rax
00007a3fbe1cfed3  mov eax, [r15+0x108]
00007a3fbe1cfeda  sahf
00007a3fbe1cfedb  jnz 0x00007A3FBE1CFF0D
00007a3fbe1cfedd  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1cfee5  jz 0x00007A3FBE1CFF70
00007a3fbe1cfeeb  nop [rax+rax*1], ax
00007a3fbe1cfef4  nop [rax+rax*1], eax
00007a3fbe1cfefc  mov eax, 0x41088C
00007a3fbe1cff01  mov [r15+0x100], rax
00007a3fbe1cff08  jmp 0x00007A3FBDFFE110
00007a3fbe1cff0d  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1cff15  jz 0x00007A3FBE1CFDC0
00007a3fbe1cff1b  nop [rax+rax*1], ax
00007a3fbe1cff24  nop [rax+rax*1], eax
00007a3fbe1cff2c  mov eax, 0x410844
00007a3fbe1cff31  mov [r15+0x100], rax
00007a3fbe1cff38  jmp 0x00007A3FBDFFE110
00007a3fbe1cff3d  int3
00007a3fbe1cff3e  call 0x00007A3FBE0E1430
00007a3fbe1cff43  jmp 0x00007A3FBE1CFDE2
00007a3fbe1cff48  call 0x00007A3FBE0E1430
00007a3fbe1cff4d  jmp 0x00007A3FBE1CFDF8
00007a3fbe1cff52  call 0x00007A3FBE0E01C0
00007a3fbe1cff57  jmp 0x00007A3FBE1CFE02
00007a3fbe1cff5c  call 0x00007A3FBE00A860
00007a3fbe1cff61  jmp 0x00007A3FBE1CFEC9
00007a3fbe1cff66  int3
00007a3fbe1cff67  nop [rax+rax*1], ax
00007a3fbe1cff70  mov rax, [r15]
00007a3fbe1cff73  mov r14d, [r13+rax*1]
00007a3fbe1cff78  lea r12, [rax+0x04]
00007a3fbe1cff7c  mov r11d, [r13+r12*1]
00007a3fbe1cff81  mov [rsp+0x10], r14d
00007a3fbe1cff86  mov r14d, r14d
00007a3fbe1cff89  mov [r15+0x78], r14
00007a3fbe1cff8d  mov [rsp+0x20], r11d
00007a3fbe1cff92  mov r11d, r11d
00007a3fbe1cff95  mov [r15+0x80], r11
00007a3fbe1cff9c  lea r14, [rax+0x08]
00007a3fbe1cffa0  mov r12d, [r13+r14*1]
00007a3fbe1cffa5  lea r14, [rax+0x0C]
00007a3fbe1cffa9  mov r11d, [r13+r14*1]
00007a3fbe1cffae  mov [rsp+0x30], r12d
00007a3fbe1cffb3  mov r12d, r12d
00007a3fbe1cffb6  mov [r15+0x70], r12
00007a3fbe1cffba  mov [rsp+0x40], r11d
00007a3fbe1cffbf  mov r11d, r11d
00007a3fbe1cffc2  mov [r15+0x68], r11
00007a3fbe1cffc6  lea r14, [rax+0x18]
00007a3fbe1cffca  mov r12d, [r13+r14*1]
00007a3fbe1cffcf  lea r14, [rax+0x1C]
00007a3fbe1cffd3  mov r11d, [r13+r14*1]
00007a3fbe1cffd8  mov [rsp+0x50], r12d
00007a3fbe1cffdd  mov r12d, r12d
00007a3fbe1cffe0  mov [r15+0x58], r12
00007a3fbe1cffe4  mov [rsp+0x60], r11d
00007a3fbe1cffe9  mov r11d, r11d
00007a3fbe1cffec  mov [r15+0x60], r11
00007a3fbe1cfff0  lea r14, [rax+0x10]
00007a3fbe1cfff4  mov r12d, [r13+r14*1]
00007a3fbe1cfff9  lea r14, [rax+0x14]
00007a3fbe1cfffd  mov eax, [r13+r14*1]
00007a3fbe1d0002  mov [rsp+0x70], r12d
00007a3fbe1d0007  mov r12d, r12d
00007a3fbe1d000a  mov [r15+0x18], r12
00007a3fbe1d000e  mov [rsp+0x80], eax
00007a3fbe1d0015  mov eax, eax
00007a3fbe1d0017  mov [r15+0x90], rax
00007a3fbe1d001e  mov eax, [rsp+0x70]
00007a3fbe1d0022  mov eax, eax
00007a3fbe1d0024  mov [r15+0x30], rax
00007a3fbe1d0028  mov eax, [rsp+0x50]
00007a3fbe1d002c  mov eax, eax
00007a3fbe1d002e  mov [r15+0xA0], rax
00007a3fbe1d0035  mov eax, [rsp+0x30]
00007a3fbe1d0039  mov eax, eax
00007a3fbe1d003b  mov [r15+0x28], rax
00007a3fbe1d003f  mov eax, [rsp+0x20]
00007a3fbe1d0043  mov eax, eax
00007a3fbe1d0045  mov [r15+0x98], rax
00007a3fbe1d004c  mov eax, [rsp+0x10]
00007a3fbe1d0050  mov eax, eax
00007a3fbe1d0052  mov [r15+0x38], rax
00007a3fbe1d0056  mov eax, [rsp+0x70]
00007a3fbe1d005a  mov r14d, [rsp+0x70]
00007a3fbe1d005f  shrd eax, r14d, 0x06
00007a3fbe1d0064  mov [rsp+0x70], r14d
00007a3fbe1d0069  mov r12d, [rsp+0x80]
00007a3fbe1d0071  and r14d, r12d
00007a3fbe1d0074  mov r11d, [rsp+0x10]
00007a3fbe1d0079  mov r10d, [rsp+0x10]
00007a3fbe1d007e  shrd r11d, r10d, 0x02
00007a3fbe1d0083  mov [rsp+0x10], r12d
00007a3fbe1d0088  mov r12d, r12d
00007a3fbe1d008b  mov [r15+0x20], r12
00007a3fbe1d008f  mov r12, [r15+0x50]
00007a3fbe1d0093  mov r9d, [r13+r12*1]
00007a3fbe1d0098  mov r12d, [rsp+0x50]
00007a3fbe1d009d  mov r8d, [rsp+0x70]
00007a3fbe1d00a2  andn ebp, r8d, r12d
00007a3fbe1d00a7  mov edi, [rsp+0x60]
00007a3fbe1d00ab  lea esi, [r14d+edi*1]
00007a3fbe1d00b0  rorx r14d, r8d, 0x0B
00007a3fbe1d00b6  xor eax, r14d
00007a3fbe1d00b9  rorx r14d, r10d, 0x0D
00007a3fbe1d00bf  xor r11d, r14d
00007a3fbe1d00c2  lea edi, [esi+ebp*1]
00007a3fbe1d00c6  mov r14, [r15+0x48]
00007a3fbe1d00ca  mov ebp, [r13+r14*1]
00007a3fbe1d00cf  mov r14d, [rsp+0x30]
00007a3fbe1d00d4  mov esi, [rsp+0x20]
00007a3fbe1d00d8  and r14d, esi
00007a3fbe1d00db  mov [rsp+0x20], r14d
00007a3fbe1d00e0  mov r14d, r14d
00007a3fbe1d00e3  mov [r15+0xD8], r14
00007a3fbe1d00ea  lea r14d, [edi+r9d*1]
00007a3fbe1d00ef  mov r9d, [rsp+0x30]
00007a3fbe1d00f4  xor r9d, esi
00007a3fbe1d00f7  rorx edi, r8d, 0x19
00007a3fbe1d00fd  xor eax, edi
00007a3fbe1d00ff  and r9d, r10d
00007a3fbe1d0102  rorx edi, r10d, 0x16
00007a3fbe1d0108  xor r11d, edi
00007a3fbe1d010b  mov [rsp+0x30], r11d
00007a3fbe1d0110  mov r11d, r11d
00007a3fbe1d0113  mov [r15+0xD0], r11
00007a3fbe1d011a  lea r11d, [r14d+ebp*1]
00007a3fbe1d011f  mov r10d, [rsp+0x20]
00007a3fbe1d0124  xor r9d, r10d
00007a3fbe1d0127  lea r14d, [r11d+eax*1]
00007a3fbe1d012c  mov qword ptr [r15+0x88], 0x04
00007a3fbe1d0137  mov eax, [rsp+0x30]
00007a3fbe1d013b  lea r11d, [r9d+eax*1]
00007a3fbe1d0140  mov eax, [rsp+0x40]
00007a3fbe1d0144  lea r10d, [r14d+eax*1]
00007a3fbe1d0149  mov r10d, r10d
00007a3fbe1d014c  mov [r15+0xB8], r10
00007a3fbe1d0153  xor eax, eax
00007a3fbe1d0155  mov r10d, 0x04
00007a3fbe1d015b  mov r9d, 0x100
00007a3fbe1d0161  cmp r10, r9
00007a3fbe1d0164  cmc
00007a3fbe1d0165  lahf
00007a3fbe1d0166  seto al
00007a3fbe1d0169  mov [r15+0x108], eax
00007a3fbe1d0170  lea eax, [r11d+r14d*1]
00007a3fbe1d0175  mov eax, eax
00007a3fbe1d0177  mov [r15+0xA8], rax
00007a3fbe1d017e  mov r12d, r12d
00007a3fbe1d0181  mov [r15+0xB0], r12
00007a3fbe1d0188  mov eax, [rsp+0x10]
00007a3fbe1d018c  mov eax, eax
00007a3fbe1d018e  mov [r15+0xC0], rax
00007a3fbe1d0195  mov r8d, r8d
00007a3fbe1d0198  mov [r15+0xC8], r8
00007a3fbe1d019f  mov eax, [r15+0x108]
00007a3fbe1d01a6  sahf
00007a3fbe1d01a7  jnz 0x00007A3FBE1D01D9
00007a3fbe1d01a9  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d01b1  jz 0x00007A3FBE1D04A0
00007a3fbe1d01b7  nop [rax+rax*1], ax
00007a3fbe1d01c0  nop [rax+rax*1], eax
00007a3fbe1d01c8  mov eax, 0x41094C
00007a3fbe1d01cd  mov [r15+0x100], rax
00007a3fbe1d01d4  jmp 0x00007A3FBDFFE110
00007a3fbe1d01d9  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d01e1  jz 0x00007A3FBE1D0270
00007a3fbe1d01e7  nop [rax+rax*1], ax
00007a3fbe1d01f0  nop [rax+rax*1], eax
00007a3fbe1d01f8  mov eax, 0x4108C0
00007a3fbe1d01fd  mov [r15+0x100], rax
00007a3fbe1d0204  jmp 0x00007A3FBDFFE110
00007a3fbe1d0209  int3
00007a3fbe1d020a  call 0x00007A3FBE00DAE0
00007a3fbe1d020f  jmp 0x00007A3FBE1CFF78
00007a3fbe1d0214  call 0x00007A3FBE0C0230
00007a3fbe1d0219  jmp 0x00007A3FBE1CFF81
00007a3fbe1d021e  call 0x00007A3FBE0E26A0
00007a3fbe1d0223  jmp 0x00007A3FBE1CFFA5
00007a3fbe1d0228  call 0x00007A3FBE0E1430
00007a3fbe1d022d  jmp 0x00007A3FBE1CFFAE
00007a3fbe1d0232  call 0x00007A3FBE0E26A0
00007a3fbe1d0237  jmp 0x00007A3FBE1CFFCF
00007a3fbe1d023c  call 0x00007A3FBE0E1430
00007a3fbe1d0241  jmp 0x00007A3FBE1CFFD8
00007a3fbe1d0246  call 0x00007A3FBE0E26A0
00007a3fbe1d024b  jmp 0x00007A3FBE1CFFF9
00007a3fbe1d0250  call 0x00007A3FBE0D5890
00007a3fbe1d0255  jmp 0x00007A3FBE1D0002
00007a3fbe1d025a  call 0x00007A3FBE0BDD50
00007a3fbe1d025f  jmp 0x00007A3FBE1D0098
00007a3fbe1d0264  call 0x00007A3FBE0DA580
00007a3fbe1d0269  jmp 0x00007A3FBE1D00CF
00007a3fbe1d026e  int3
00007a3fbe1d026f  nop
00007a3fbe1d0270  mov eax, [r15+0xB8]
00007a3fbe1d0277  mov [rsp+0x10], eax
00007a3fbe1d027b  mov eax, eax
00007a3fbe1d027d  mov [r15+0x30], rax
00007a3fbe1d0281  mov eax, [r15+0xC0]
00007a3fbe1d0288  mov [rsp+0x20], eax
00007a3fbe1d028c  mov eax, eax
00007a3fbe1d028e  mov [r15+0xA0], rax
00007a3fbe1d0295  mov eax, [r15+0x28]
00007a3fbe1d0299  mov r14d, [r15+0x98]
00007a3fbe1d02a0  mov [rsp+0x30], r14d
00007a3fbe1d02a5  mov r14d, r14d
00007a3fbe1d02a8  mov [r15+0x28], r14
00007a3fbe1d02ac  mov r14d, [r15+0x38]
00007a3fbe1d02b0  mov [rsp+0x40], r14d
00007a3fbe1d02b5  mov r14d, r14d
00007a3fbe1d02b8  mov [r15+0x98], r14
00007a3fbe1d02bf  mov r14d, [r15+0xA8]
00007a3fbe1d02c6  mov [rsp+0x50], r14d
00007a3fbe1d02cb  mov r14d, r14d
00007a3fbe1d02ce  mov [r15+0x38], r14
00007a3fbe1d02d2  mov r14d, [rsp+0x10]
00007a3fbe1d02d7  mov r12d, [rsp+0x10]
00007a3fbe1d02dc  shrd r14d, r12d, 0x06
00007a3fbe1d02e1  mov r11d, [r15+0xC8]
00007a3fbe1d02e8  mov [rsp+0x10], r12d
00007a3fbe1d02ed  and r12d, r11d
00007a3fbe1d02f0  mov r10d, [rsp+0x50]
00007a3fbe1d02f5  mov r9d, [rsp+0x50]
00007a3fbe1d02fa  shrd r10d, r9d, 0x02
00007a3fbe1d02ff  mov [rsp+0x50], r11d
00007a3fbe1d0304  mov r11d, r11d
00007a3fbe1d0307  mov [r15+0x20], r11
00007a3fbe1d030b  mov r11, [r15+0x88]
00007a3fbe1d0312  mov r8, [r15+0x50]
00007a3fbe1d0316  lea rbp, [r8+r11*1]
00007a3fbe1d031a  mov r8d, [r13+rbp*1]
00007a3fbe1d031f  mov ebp, [rsp+0x20]
00007a3fbe1d0323  mov edi, [rsp+0x10]
00007a3fbe1d0327  andn esi, edi, ebp
00007a3fbe1d032c  mov edx, [r15+0xB0]
00007a3fbe1d0333  lea ecx, [r12d+edx*1]
00007a3fbe1d0338  rorx r12d, edi, 0x0B
00007a3fbe1d033e  xor r14d, r12d
00007a3fbe1d0341  rorx r12d, r9d, 0x0D
00007a3fbe1d0347  xor r10d, r12d
00007a3fbe1d034a  lea r12d, [ecx+esi*1]
00007a3fbe1d034f  mov rsi, [r15+0x48]
00007a3fbe1d0353  lea rdx, [rsi+r11*1]
00007a3fbe1d0357  mov esi, [r13+rdx*1]
00007a3fbe1d035c  mov edx, [rsp+0x30]
00007a3fbe1d0360  mov ecx, [rsp+0x40]
00007a3fbe1d0364  and edx, ecx
00007a3fbe1d0366  mov [rsp+0x10], edx
00007a3fbe1d036a  mov edx, edx
00007a3fbe1d036c  mov [r15+0xD8], rdx
00007a3fbe1d0373  lea edx, [r12d+r8d*1]
00007a3fbe1d0378  mov r12d, [rsp+0x30]
00007a3fbe1d037d  xor r12d, ecx
00007a3fbe1d0380  rorx r8d, edi, 0x19
00007a3fbe1d0386  xor r14d, r8d
00007a3fbe1d0389  and r12d, r9d
00007a3fbe1d038c  rorx r8d, r9d, 0x16
00007a3fbe1d0392  xor r10d, r8d
00007a3fbe1d0395  mov [rsp+0x20], r10d
00007a3fbe1d039a  mov r10d, r10d
00007a3fbe1d039d  mov [r15+0xD0], r10
00007a3fbe1d03a4  lea r10d, [edx+esi*1]
00007a3fbe1d03a9  mov r9d, [rsp+0x10]
00007a3fbe1d03ae  xor r12d, r9d
00007a3fbe1d03b1  lea r9d, [r10d+r14d*1]
00007a3fbe1d03b6  lea r14, [r11+0x04]
00007a3fbe1d03ba  mov [r15+0x88], r14
00007a3fbe1d03c1  mov r11d, [rsp+0x20]
00007a3fbe1d03c6  lea r10d, [r12d+r11d*1]
00007a3fbe1d03cb  lea r11d, [r9d+eax*1]
00007a3fbe1d03d0  mov r11d, r11d
00007a3fbe1d03d3  mov [r15+0xB8], r11
00007a3fbe1d03da  xor eax, eax
00007a3fbe1d03dc  mov r12d, 0x100
00007a3fbe1d03e2  cmp r14, r12
00007a3fbe1d03e5  cmc
00007a3fbe1d03e6  lahf
00007a3fbe1d03e7  seto al
00007a3fbe1d03ea  mov [r15+0x108], eax
00007a3fbe1d03f1  lea eax, [r10d+r9d*1]
00007a3fbe1d03f6  mov eax, eax
00007a3fbe1d03f8  mov [r15+0xA8], rax
00007a3fbe1d03ff  mov ebp, ebp
00007a3fbe1d0401  mov [r15+0xB0], rbp
00007a3fbe1d0408  mov eax, [rsp+0x50]
00007a3fbe1d040c  mov eax, eax
00007a3fbe1d040e  mov [r15+0xC0], rax
00007a3fbe1d0415  mov edi, edi
00007a3fbe1d0417  mov [r15+0xC8], rdi
00007a3fbe1d041e  mov eax, [r15+0x108]
00007a3fbe1d0425  sahf
00007a3fbe1d0426  jnz 0x00007A3FBE1D0458
00007a3fbe1d0428  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d0430  jz 0x00007A3FBE1D04A0
00007a3fbe1d0436  nop [rax+rax*1], ax
00007a3fbe1d043f  nop [rax+rax*1], eax
00007a3fbe1d0447  mov eax, 0x41094C
00007a3fbe1d044c  mov [r15+0x100], rax
00007a3fbe1d0453  jmp 0x00007A3FBDFFE110
00007a3fbe1d0458  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d0460  jz 0x00007A3FBE1D0270
00007a3fbe1d0466  nop [rax+rax*1], ax
00007a3fbe1d046f  nop [rax+rax*1], eax
00007a3fbe1d0477  mov eax, 0x4108C0
00007a3fbe1d047c  mov [r15+0x100], rax
00007a3fbe1d0483  jmp 0x00007A3FBDFFE110
00007a3fbe1d0488  int3
00007a3fbe1d0489  call 0x00007A3FBE049010
00007a3fbe1d048e  jmp 0x00007A3FBE1D031F
00007a3fbe1d0493  call 0x00007A3FBE025930
00007a3fbe1d0498  jmp 0x00007A3FBE1D035C
00007a3fbe1d049d  int3
00007a3fbe1d049e  nop
00007a3fbe1d04a0  mov eax, [r15+0x98]
00007a3fbe1d04a7  mov r14d, [r15+0x70]
00007a3fbe1d04ab  lea r12d, [eax+r14d*1]
00007a3fbe1d04b0  mov eax, [r15+0x28]
00007a3fbe1d04b4  mov r14d, [r15+0x68]
00007a3fbe1d04b8  lea r11d, [eax+r14d*1]
00007a3fbe1d04bd  mov qword ptr [r15+0x88], 0x00
00007a3fbe1d04c8  mov eax, [r15+0xA8]
00007a3fbe1d04cf  mov r14d, [r15+0x78]
00007a3fbe1d04d3  lea r10d, [eax+r14d*1]
00007a3fbe1d04d8  mov [rsp+0x10], r10d
00007a3fbe1d04dd  mov r10d, r10d
00007a3fbe1d04e0  mov [r15+0x78], r10
00007a3fbe1d04e4  mov eax, [r15+0x38]
00007a3fbe1d04e8  mov r14d, [r15+0x80]
00007a3fbe1d04ef  lea r10d, [eax+r14d*1]
00007a3fbe1d04f4  mov [rsp+0x20], r10d
00007a3fbe1d04f9  mov r10d, r10d
00007a3fbe1d04fc  mov [r15+0x80], r10
00007a3fbe1d0503  mov rax, [r15]
00007a3fbe1d0506  lea r14, [rax+0x08]
00007a3fbe1d050a  mov [r13+r14*1], r12d
00007a3fbe1d050f  lea r14, [rax+0x0C]
00007a3fbe1d0513  mov [r13+r14*1], r11d
00007a3fbe1d0518  mov r14d, [r15+0xB8]
00007a3fbe1d051f  mov r12d, [r15+0x18]
00007a3fbe1d0523  lea r11d, [r14d+r12d*1]
00007a3fbe1d0528  mov [rsp+0x30], r11d
00007a3fbe1d052d  mov r11d, r11d
00007a3fbe1d0530  mov [r15+0x68], r11
00007a3fbe1d0534  mov r14d, [r15+0x30]
00007a3fbe1d0538  mov r12d, [r15+0x90]
00007a3fbe1d053f  lea r11d, [r14d+r12d*1]
00007a3fbe1d0544  mov [rsp+0x40], r11d
00007a3fbe1d0549  mov r11d, r11d
00007a3fbe1d054c  mov [r15+0x70], r11
00007a3fbe1d0550  mov r14d, [r15+0x20]
00007a3fbe1d0554  mov r12d, [r15+0x58]
00007a3fbe1d0558  lea r11d, [r14d+r12d*1]
00007a3fbe1d055d  mov [rsp+0x50], r11d
00007a3fbe1d0562  mov r11d, r11d
00007a3fbe1d0565  mov [r15+0x58], r11
00007a3fbe1d0569  mov r14d, [r15+0xA0]
00007a3fbe1d0570  mov r12d, [r15+0x60]
00007a3fbe1d0574  lea r11d, [r14d+r12d*1]
00007a3fbe1d0579  mov [rsp+0x60], r11d
00007a3fbe1d057e  mov r11d, r11d
00007a3fbe1d0581  mov [r15+0x60], r11
00007a3fbe1d0585  mov r14d, [rsp+0x10]
00007a3fbe1d058a  mov [r13+rax*1], r14d
00007a3fbe1d058f  lea r14, [rax+0x04]
00007a3fbe1d0593  mov r12d, [rsp+0x20]
00007a3fbe1d0598  mov [r13+r14*1], r12d
00007a3fbe1d059d  lea r14, [rax+0x10]
00007a3fbe1d05a1  mov r12d, [rsp+0x30]
00007a3fbe1d05a6  mov [r13+r14*1], r12d
00007a3fbe1d05ab  lea r14, [rax+0x14]
00007a3fbe1d05af  mov r12d, [rsp+0x40]
00007a3fbe1d05b4  mov [r13+r14*1], r12d
00007a3fbe1d05b9  lea r14, [rax+0x18]
00007a3fbe1d05bd  mov r12d, [rsp+0x50]
00007a3fbe1d05c2  mov [r13+r14*1], r12d
00007a3fbe1d05c7  lea r14, [rax+0x1C]
00007a3fbe1d05cb  mov r12d, [rsp+0x60]
00007a3fbe1d05d0  mov [r13+r14*1], r12d
00007a3fbe1d05d5  lea r14, [rax+0x68]
00007a3fbe1d05d9  xor eax, eax
00007a3fbe1d05db  mov [r13+r14*1], rax
00007a3fbe1d05e0  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d05e8  jz 0x00007A3FBE1CF0E0
00007a3fbe1d05ee  nop [rax+rax*1], ax
00007a3fbe1d05f7  nop [rax+rax*1], eax
00007a3fbe1d05ff  mov eax, 0x410768
00007a3fbe1d0604  mov [r15+0x100], rax
00007a3fbe1d060b  jmp 0x00007A3FBDFFE110
00007a3fbe1d0610  int3
00007a3fbe1d0611  call 0x00007A3FBE0E2BA0
00007a3fbe1d0616  jmp 0x00007A3FBE1D050F
00007a3fbe1d061b  call 0x00007A3FBE0E1920
00007a3fbe1d0620  jmp 0x00007A3FBE1D0518
00007a3fbe1d0625  call 0x00007A3FBE00DFE0
00007a3fbe1d062a  jmp 0x00007A3FBE1D058F
00007a3fbe1d062f  call 0x00007A3FBE0E2BA0
00007a3fbe1d0634  jmp 0x00007A3FBE1D059D
00007a3fbe1d0639  call 0x00007A3FBE0E2BA0
00007a3fbe1d063e  jmp 0x00007A3FBE1D05AB
00007a3fbe1d0643  call 0x00007A3FBE0E2BA0
00007a3fbe1d0648  jmp 0x00007A3FBE1D05B9
00007a3fbe1d064d  call 0x00007A3FBE0E2BA0
00007a3fbe1d0652  jmp 0x00007A3FBE1D05C7
00007a3fbe1d0657  call 0x00007A3FBE0E2BA0
00007a3fbe1d065c  jmp 0x00007A3FBE1D05D5
00007a3fbe1d0661  call 0x00007A3FBE0D5EB0
00007a3fbe1d0666  jmp 0x00007A3FBE1D05E0
00007a3fbe1d066b  int3
00007a3fbe1d066c  nop [rax], eax
00007a3fbe1d0670  mov rax, [r15+0xF8]
00007a3fbe1d0677  lea r14, [rax+0x140]
00007a3fbe1d067e  mov r12, [r13+r14*1]
00007a3fbe1d0683  lea r14, [rax+0x148]
00007a3fbe1d068a  mov r11, [r13+r14*1]
00007a3fbe1d068f  mov [r15+0xA0], r12
00007a3fbe1d0696  mov [r15+0x98], r11
00007a3fbe1d069d  lea r14, [rax+0x130]
00007a3fbe1d06a4  mov r12, [r13+r14*1]
00007a3fbe1d06a9  lea r14, [rax+0x138]
00007a3fbe1d06b0  mov r11, [r13+r14*1]
00007a3fbe1d06b5  mov [r15+0xB0], r12
00007a3fbe1d06bc  mov [r15+0xA8], r11
00007a3fbe1d06c3  lea r14, [rax+0x120]
00007a3fbe1d06ca  mov r12, [r13+r14*1]
00007a3fbe1d06cf  lea r14, [rax+0x128]
00007a3fbe1d06d6  mov r11, [r13+r14*1]
00007a3fbe1d06db  mov [r15+0xC0], r12
00007a3fbe1d06e2  mov [r15+0xB8], r11
00007a3fbe1d06e9  lea r14, [rax+0x110]
00007a3fbe1d06f0  mov r12, [r13+r14*1]
00007a3fbe1d06f5  lea r14, [rax+0x118]
00007a3fbe1d06fc  mov r11, [r13+r14*1]
00007a3fbe1d0701  mov [r15+0xD0], r12
00007a3fbe1d0708  mov [r15+0xC8], r11
00007a3fbe1d070f  lea r14, [rax+0x100]
00007a3fbe1d0716  mov r12, [r13+r14*1]
00007a3fbe1d071b  lea r14, [rax+0x108]
00007a3fbe1d0722  mov r11, [r13+r14*1]
00007a3fbe1d0727  mov [r15+0xE8], r12
00007a3fbe1d072e  mov [r15+0xD8], r11
00007a3fbe1d0735  lea r14, [rax+0x150]
00007a3fbe1d073c  mov [r15+0xF8], r14
00007a3fbe1d0743  mov rax, [r15+0xF0]
00007a3fbe1d074a  mov [r15+0x100], rax
00007a3fbe1d0751  jmp 0x00007A3FBE1CE5C0
00007a3fbe1d0756  int3
00007a3fbe1d0757  call 0x00007A3FBE0E27E0
00007a3fbe1d075c  jmp 0x00007A3FBE1D0683
00007a3fbe1d0761  call 0x00007A3FBE0E1570
00007a3fbe1d0766  jmp 0x00007A3FBE1D068F
00007a3fbe1d076b  call 0x00007A3FBE0E27E0
00007a3fbe1d0770  jmp 0x00007A3FBE1D06A9
00007a3fbe1d0775  call 0x00007A3FBE0E1570
00007a3fbe1d077a  jmp 0x00007A3FBE1D06B5
00007a3fbe1d077f  call 0x00007A3FBE0E27E0
00007a3fbe1d0784  jmp 0x00007A3FBE1D06CF
00007a3fbe1d0789  call 0x00007A3FBE0E1570
00007a3fbe1d078e  jmp 0x00007A3FBE1D06DB
00007a3fbe1d0793  call 0x00007A3FBE0E27E0
00007a3fbe1d0798  jmp 0x00007A3FBE1D06F5
00007a3fbe1d079d  call 0x00007A3FBE0E1570
00007a3fbe1d07a2  jmp 0x00007A3FBE1D0701
00007a3fbe1d07a7  call 0x00007A3FBE0E27E0
00007a3fbe1d07ac  jmp 0x00007A3FBE1D071B
00007a3fbe1d07b1  call 0x00007A3FBE0E1570
00007a3fbe1d07b6  jmp 0x00007A3FBE1D0727
00007a3fbe1d07bb  int3
00007a3fbe1d07bc  nop [rax], eax
00007a3fbe1d07c0  mov eax, [r15+0xA0]
00007a3fbe1d07c7  mov [rsp+0x10], eax
00007a3fbe1d07cb  xor eax, eax
00007a3fbe1d07cd  mov r14d, [rsp+0x10]
00007a3fbe1d07d2  sub r14d, 0x01
00007a3fbe1d07d6  cmc
00007a3fbe1d07d7  lahf
00007a3fbe1d07d8  seto al
00007a3fbe1d07db  mov [r15+0x108], eax
00007a3fbe1d07e2  mov r14d, r14d
00007a3fbe1d07e5  mov [r15+0xA0], r14
00007a3fbe1d07ec  mov eax, [r15+0x108]
00007a3fbe1d07f3  sahf
00007a3fbe1d07f4  jnz 0x00007A3FBE1D0826
00007a3fbe1d07f6  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d07fe  jz 0x00007A3FBE1D0900
00007a3fbe1d0804  nop [rax+rax*1], ax
00007a3fbe1d080d  nop [rax+rax*1], eax
00007a3fbe1d0815  mov eax, 0x41028C
00007a3fbe1d081a  mov [r15+0x100], rax
00007a3fbe1d0821  jmp 0x00007A3FBDFFE110
00007a3fbe1d0826  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d082e  jz 0x00007A3FBE1D0860
00007a3fbe1d0834  nop [rax+rax*1], ax
00007a3fbe1d083d  nop [rax+rax*1], eax
00007a3fbe1d0845  mov eax, 0x410274
00007a3fbe1d084a  mov [r15+0x100], rax
00007a3fbe1d0851  jmp 0x00007A3FBDFFE110
00007a3fbe1d0856  int3
00007a3fbe1d0857  int3
00007a3fbe1d0858  nop [rax+rax*1], eax
00007a3fbe1d0860  mov rax, [r15+0xF8]
00007a3fbe1d0867  lea r14, [rax+0x100]
00007a3fbe1d086e  mov [r15], r14
00007a3fbe1d0871  mov rax, [r15+0x98]
00007a3fbe1d0878  mov [r15+0x08], rax
00007a3fbe1d087c  mov qword ptr [r15+0x10], 0x12C
00007a3fbe1d0884  mov qword ptr [r15+0xF0], 0x410284
00007a3fbe1d088f  mov r14d, [r15+0x320]
00007a3fbe1d0896  mov eax, 0x410284
00007a3fbe1d089b  mov rcx, 0x7A3FBE1D07C0
00007a3fbe1d08a5  mov [r15+r14*8+0x328], rax
00007a3fbe1d08ad  mov [r15+r14*8+0x368], rcx
00007a3fbe1d08b5  add r14d, 0x01
00007a3fbe1d08b9  and r14d, 0x07
00007a3fbe1d08bd  mov [r15+0x320], r14d
00007a3fbe1d08c4  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d08cc  jz 0x00007A3FBE1CED70
00007a3fbe1d08d2  nop [rax+rax*1], ax
00007a3fbe1d08db  nop [rax+rax*1], eax
00007a3fbe1d08e3  mov eax, 0x410728
00007a3fbe1d08e8  mov [r15+0x100], rax
00007a3fbe1d08ef  jmp 0x00007A3FBDFFE110
00007a3fbe1d08f4  int3
00007a3fbe1d08f5  int3
00007a3fbe1d08f6  nop [rax+rax*1], ax
00007a3fbe1d08ff  nop
00007a3fbe1d0900  mov rax, [r15+0xF8]
00007a3fbe1d0907  lea r14, [rax+0x120]
00007a3fbe1d090e  mov r12, [r13+r14*1]
00007a3fbe1d0913  mov [r15+0x98], r12
00007a3fbe1d091a  mov qword ptr [r15+0x40], 0x80
00007a3fbe1d0922  lea r14, [rax+0x100]
00007a3fbe1d0929  mov [r15], r14
00007a3fbe1d092c  lea r14, [rax+0x17C]
00007a3fbe1d0933  mov [r15+0x08], r14
00007a3fbe1d0937  mov qword ptr [r15+0x10], 0x01
00007a3fbe1d093f  lea r14, [rax+0x17C]
00007a3fbe1d0946  mov eax, 0x80
00007a3fbe1d094b  mov [r13+r14*1], al
00007a3fbe1d0950  mov qword ptr [r15+0xF0], 0x4102A8
00007a3fbe1d095b  mov r14d, [r15+0x320]
00007a3fbe1d0962  mov eax, 0x4102A8
00007a3fbe1d0967  mov rcx, 0x7A3FBE1D09E0
00007a3fbe1d0971  mov [r15+r14*8+0x328], rax
00007a3fbe1d0979  mov [r15+r14*8+0x368], rcx
00007a3fbe1d0981  add r14d, 0x01
00007a3fbe1d0985  and r14d, 0x07
00007a3fbe1d0989  mov [r15+0x320], r14d
00007a3fbe1d0990  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d0998  jz 0x00007A3FBE1CED70
00007a3fbe1d099e  nop [rax+rax*1], ax
00007a3fbe1d09a7  nop [rax+rax*1], eax
00007a3fbe1d09af  mov eax, 0x410728
00007a3fbe1d09b4  mov [r15+0x100], rax
00007a3fbe1d09bb  jmp 0x00007A3FBDFFE110
00007a3fbe1d09c0  int3
00007a3fbe1d09c1  call 0x00007A3FBE0E27E0
00007a3fbe1d09c6  jmp 0x00007A3FBE1D0913
00007a3fbe1d09cb  call 0x00007A3FBE0D5AF0
00007a3fbe1d09d0  jmp 0x00007A3FBE1D0950
00007a3fbe1d09d5  int3
00007a3fbe1d09d6  nop [rax+rax*1], ax
00007a3fbe1d09df  nop
00007a3fbe1d09e0  mov rax, [r15+0xF8]
00007a3fbe1d09e7  lea r14, [rax+0x168]
00007a3fbe1d09ee  mov r12, [r13+r14*1]
00007a3fbe1d09f3  mov [r15+0x40], r12
00007a3fbe1d09f7  lea r14, [rax+0x178]
00007a3fbe1d09fe  xor eax, eax
00007a3fbe1d0a00  mov [r13+r14*1], al
00007a3fbe1d0a05  xor eax, eax
00007a3fbe1d0a07  mov r14d, 0x38
00007a3fbe1d0a0d  cmp r12, r14
00007a3fbe1d0a10  cmc
00007a3fbe1d0a11  lahf
00007a3fbe1d0a12  seto al
00007a3fbe1d0a15  mov [r15+0x108], eax
00007a3fbe1d0a1c  mov eax, [r15+0x108]
00007a3fbe1d0a23  sahf
00007a3fbe1d0a24  jz 0x00007A3FBE1D0A56
00007a3fbe1d0a26  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d0a2e  jz 0x00007A3FBE1D0AA0
00007a3fbe1d0a34  nop [rax+rax*1], ax
00007a3fbe1d0a3d  nop [rax+rax*1], eax
00007a3fbe1d0a45  mov eax, 0x4102B8
00007a3fbe1d0a4a  mov [r15+0x100], rax
00007a3fbe1d0a51  jmp 0x00007A3FBDFFE110
00007a3fbe1d0a56  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d0a5e  jz 0x00007A3FBE1D0BF0
00007a3fbe1d0a64  nop [rax+rax*1], ax
00007a3fbe1d0a6d  nop [rax+rax*1], eax
00007a3fbe1d0a75  mov eax, 0x4102D4
00007a3fbe1d0a7a  mov [r15+0x100], rax
00007a3fbe1d0a81  jmp 0x00007A3FBDFFE110
00007a3fbe1d0a86  int3
00007a3fbe1d0a87  call 0x00007A3FBE0E27E0
00007a3fbe1d0a8c  jmp 0x00007A3FBE1D09F3
00007a3fbe1d0a91  call 0x00007A3FBE0D5AF0
00007a3fbe1d0a96  jmp 0x00007A3FBE1D0A05
00007a3fbe1d0a9b  int3
00007a3fbe1d0a9c  nop [rax], eax
00007a3fbe1d0aa0  mov rax, [r15+0xF8]
00007a3fbe1d0aa7  lea r14, [rax+0x100]
00007a3fbe1d0aae  mov [r15], r14
00007a3fbe1d0ab1  lea r14, [rax+0x178]
00007a3fbe1d0ab8  mov [r15+0x08], r14
00007a3fbe1d0abc  mov qword ptr [r15+0x10], 0x01
00007a3fbe1d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
00007a3fbe1d0acf  mov r14d, [r15+0x320]
00007a3fbe1d0ad6  mov eax, 0x4102C8
00007a3fbe1d0adb  mov rcx, 0x7A3FBE1D0B40
00007a3fbe1d0ae5  mov [r15+r14*8+0x328], rax
00007a3fbe1d0aed  mov [r15+r14*8+0x368], rcx
00007a3fbe1d0af5  add r14d, 0x01
00007a3fbe1d0af9  and r14d, 0x07
00007a3fbe1d0afd  mov [r15+0x320], r14d
00007a3fbe1d0b04  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d0b0c  jz 0x00007A3FBE1CED70
00007a3fbe1d0b12  nop [rax+rax*1], ax
00007a3fbe1d0b1b  nop [rax+rax*1], eax
00007a3fbe1d0b23  mov eax, 0x410728
00007a3fbe1d0b28  mov [r15+0x100], rax
00007a3fbe1d0b2f  jmp 0x00007A3FBDFFE110
00007a3fbe1d0b34  int3
00007a3fbe1d0b35  int3
00007a3fbe1d0b36  nop [rax+rax*1], ax
00007a3fbe1d0b3f  nop
00007a3fbe1d0b40  mov rax, [r15+0xF8]
00007a3fbe1d0b47  lea r14, [rax+0x168]
00007a3fbe1d0b4e  mov rax, [r13+r14*1]
00007a3fbe1d0b53  mov [r15+0x40], rax
00007a3fbe1d0b57  mov [rsp+0x10], rax
00007a3fbe1d0b5c  xor eax, eax
00007a3fbe1d0b5e  mov r14, [rsp+0x10]
00007a3fbe1d0b63  mov r12d, 0x38
00007a3fbe1d0b69  cmp r14, r12
00007a3fbe1d0b6c  cmc
00007a3fbe1d0b6d  lahf
00007a3fbe1d0b6e  seto al
00007a3fbe1d0b71  mov [r15+0x108], eax
00007a3fbe1d0b78  mov eax, [r15+0x108]
00007a3fbe1d0b7f  sahf
00007a3fbe1d0b80  jnz 0x00007A3FBE1D0BB2
00007a3fbe1d0b82  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d0b8a  jz 0x00007A3FBE1D0BF0
00007a3fbe1d0b90  nop [rax+rax*1], ax
00007a3fbe1d0b99  nop [rax+rax*1], eax
00007a3fbe1d0ba1  mov eax, 0x4102D4
00007a3fbe1d0ba6  mov [r15+0x100], rax
00007a3fbe1d0bad  jmp 0x00007A3FBDFFE110
00007a3fbe1d0bb2  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d0bba  jz 0x00007A3FBE1D0AA0
00007a3fbe1d0bc0  nop [rax+rax*1], ax
00007a3fbe1d0bc9  nop [rax+rax*1], eax
00007a3fbe1d0bd1  mov eax, 0x4102B8
00007a3fbe1d0bd6  mov [r15+0x100], rax
00007a3fbe1d0bdd  jmp 0x00007A3FBDFFE110
00007a3fbe1d0be2  int3
00007a3fbe1d0be3  call 0x00007A3FBE0D59C0
00007a3fbe1d0be8  jmp 0x00007A3FBE1D0B53
00007a3fbe1d0bed  int3
00007a3fbe1d0bee  nop
00007a3fbe1d0bf0  mov rax, [r15+0x98]
00007a3fbe1d0bf7  rorx r14, rax, 0x3D
00007a3fbe1d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
00007a3fbe1d0c01  mov rax, [r15+0xF8]
00007a3fbe1d0c08  lea r12, [rax+0x100]
00007a3fbe1d0c0f  mov [r15], r12
00007a3fbe1d0c12  lea r12, [rax+0x170]
00007a3fbe1d0c19  mov [r15+0x08], r12
00007a3fbe1d0c1d  mov qword ptr [r15+0x10], 0x08
00007a3fbe1d0c25  bswap r14
00007a3fbe1d0c28  mov [r15+0x40], r14
00007a3fbe1d0c2c  lea r12, [rax+0x170]
00007a3fbe1d0c33  mov [r13+r12*1], r14
00007a3fbe1d0c38  mov qword ptr [r15+0xF0], 0x4102F0
00007a3fbe1d0c43  mov r14d, [r15+0x320]
00007a3fbe1d0c4a  mov eax, 0x4102F0
00007a3fbe1d0c4f  mov rcx, 0x7A3FBE1D0CC0
00007a3fbe1d0c59  mov [r15+r14*8+0x328], rax
00007a3fbe1d0c61  mov [r15+r14*8+0x368], rcx
00007a3fbe1d0c69  add r14d, 0x01
00007a3fbe1d0c6d  and r14d, 0x07
00007a3fbe1d0c71  mov [r15+0x320], r14d
00007a3fbe1d0c78  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d0c80  jz 0x00007A3FBE1CED70
00007a3fbe1d0c86  nop [rax+rax*1], ax
00007a3fbe1d0c8f  nop [rax+rax*1], eax
00007a3fbe1d0c97  mov eax, 0x410728
00007a3fbe1d0c9c  mov [r15+0x100], rax
00007a3fbe1d0ca3  jmp 0x00007A3FBDFFE110
00007a3fbe1d0ca8  int3
00007a3fbe1d0ca9  call 0x00007A3FBE0C3FE0
00007a3fbe1d0cae  jmp 0x00007A3FBE1D0C38
00007a3fbe1d0cb3  int3
00007a3fbe1d0cb4  nop [rax+rax*1], ax
00007a3fbe1d0cbd  nop [rax], eax
00007a3fbe1d0cc0  mov rax, [r15+0xF8]
00007a3fbe1d0cc7  lea r14, [rax+0x100]
00007a3fbe1d0cce  mov r12d, [r13+r14*1]
00007a3fbe1d0cd3  lea r14, [rax+0x104]
00007a3fbe1d0cda  mov r11d, [r13+r14*1]
00007a3fbe1d0cdf  mov qword ptr [r15+0x48], 0x430C90
00007a3fbe1d0ce7  lea r14, [rax+0x108]
00007a3fbe1d0cee  mov r10d, [r13+r14*1]
00007a3fbe1d0cf3  lea r14, [rax+0x10C]
00007a3fbe1d0cfa  mov r9d, [r13+r14*1]
00007a3fbe1d0cff  bswap r12d
00007a3fbe1d0d02  bswap r11d
00007a3fbe1d0d05  mov qword ptr [r15+0xA0], 0x00
00007a3fbe1d0d10  mov r14d, 0x430C90
00007a3fbe1d0d16  mov [r13+r14*1], r12d
00007a3fbe1d0d1b  mov r14d, 0x430C94
00007a3fbe1d0d21  mov [r13+r14*1], r11d
00007a3fbe1d0d26  bswap r10d
00007a3fbe1d0d29  lea r14, [rax+0x110]
00007a3fbe1d0d30  mov r12d, [r13+r14*1]
00007a3fbe1d0d35  bswap r9d
00007a3fbe1d0d38  lea r14, [rax+0x114]
00007a3fbe1d0d3f  mov r11d, [r13+r14*1]
00007a3fbe1d0d44  mov qword ptr [r15+0x98], 0x430DFC
00007a3fbe1d0d4f  mov r14d, 0x430C98
00007a3fbe1d0d55  mov [r13+r14*1], r10d
00007a3fbe1d0d5a  mov r14d, 0x430C9C
00007a3fbe1d0d60  mov [r13+r14*1], r9d
00007a3fbe1d0d65  bswap r12d
00007a3fbe1d0d68  lea r14, [rax+0x118]
00007a3fbe1d0d6f  mov r10d, [r13+r14*1]
00007a3fbe1d0d74  bswap r11d
00007a3fbe1d0d77  mov [rsp+0x10], r11d
00007a3fbe1d0d7c  mov r11d, r11d
00007a3fbe1d0d7f  mov [r15+0x58], r11
00007a3fbe1d0d83  lea r14, [rax+0x11C]
00007a3fbe1d0d8a  mov eax, [r13+r14*1]
00007a3fbe1d0d8f  mov [rsp+0x20], eax
00007a3fbe1d0d93  mov eax, eax
00007a3fbe1d0d95  mov [r15+0x60], rax
00007a3fbe1d0d99  mov eax, 0x430CA0
00007a3fbe1d0d9e  mov [r13+rax*1], r12d
00007a3fbe1d0da3  mov eax, 0x430CA4
00007a3fbe1d0da8  mov r14d, [rsp+0x10]
00007a3fbe1d0dad  mov [r13+rax*1], r14d
00007a3fbe1d0db2  bswap r10d
00007a3fbe1d0db5  mov [rsp+0x10], r10d
00007a3fbe1d0dba  mov r10d, r10d
00007a3fbe1d0dbd  mov [r15+0x40], r10
00007a3fbe1d0dc1  mov eax, [rsp+0x20]
00007a3fbe1d0dc5  bswap eax
00007a3fbe1d0dc7  mov [rsp+0x20], eax
00007a3fbe1d0dcb  mov eax, eax
00007a3fbe1d0dcd  mov [r15+0x50], rax
00007a3fbe1d0dd1  mov eax, 0x430CA8
00007a3fbe1d0dd6  mov r14d, [rsp+0x10]
00007a3fbe1d0ddb  mov [r13+rax*1], r14d
00007a3fbe1d0de0  mov eax, 0x430CAC
00007a3fbe1d0de5  mov r14d, [rsp+0x20]
00007a3fbe1d0dea  mov [r13+rax*1], r14d
00007a3fbe1d0def  mov eax, [r15+0xA0]
00007a3fbe1d0df6  lea r14d, [eax+0x11]
00007a3fbe1d0dfb  mov r14d, r14d
00007a3fbe1d0dfe  mov [r15], r14
00007a3fbe1d0e01  mov qword ptr [r15+0xF0], 0x41035C
00007a3fbe1d0e0c  mov r14d, [r15+0x320]
00007a3fbe1d0e13  mov eax, 0x41035C
00007a3fbe1d0e18  mov rcx, 0x7A3FBE1D0F90
00007a3fbe1d0e22  mov [r15+r14*8+0x328], rax
00007a3fbe1d0e2a  mov [r15+r14*8+0x368], rcx
00007a3fbe1d0e32  add r14d, 0x01
00007a3fbe1d0e36  and r14d, 0x07
00007a3fbe1d0e3a  mov [r15+0x320], r14d
00007a3fbe1d0e41  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d0e49  jz 0x00007A3FBE1D0F20
00007a3fbe1d0e4f  nop [rax+rax*1], ax
00007a3fbe1d0e58  nop [rax+rax*1], eax
00007a3fbe1d0e60  mov eax, 0x4109A4
00007a3fbe1d0e65  mov [r15+0x100], rax
00007a3fbe1d0e6c  jmp 0x00007A3FBDFFE110
00007a3fbe1d0e71  int3
00007a3fbe1d0e72  call 0x00007A3FBE0E26A0
00007a3fbe1d0e77  jmp 0x00007A3FBE1D0CD3
00007a3fbe1d0e7c  call 0x00007A3FBE0E1430
00007a3fbe1d0e81  jmp 0x00007A3FBE1D0CDF
00007a3fbe1d0e86  call 0x00007A3FBE0E01C0
00007a3fbe1d0e8b  jmp 0x00007A3FBE1D0CF3
00007a3fbe1d0e90  call 0x00007A3FBE0DEF50
00007a3fbe1d0e95  jmp 0x00007A3FBE1D0CFF
00007a3fbe1d0e9a  call 0x00007A3FBE0E2BA0
00007a3fbe1d0e9f  jmp 0x00007A3FBE1D0D1B
00007a3fbe1d0ea4  call 0x00007A3FBE0E1920
00007a3fbe1d0ea9  jmp 0x00007A3FBE1D0D26
00007a3fbe1d0eae  call 0x00007A3FBE0E26A0
00007a3fbe1d0eb3  jmp 0x00007A3FBE1D0D35
00007a3fbe1d0eb8  call 0x00007A3FBE0E1430
00007a3fbe1d0ebd  jmp 0x00007A3FBE1D0D44
00007a3fbe1d0ec2  call 0x00007A3FBE0E06B0
00007a3fbe1d0ec7  jmp 0x00007A3FBE1D0D5A
00007a3fbe1d0ecc  call 0x00007A3FBE0DF440
00007a3fbe1d0ed1  jmp 0x00007A3FBE1D0D65
00007a3fbe1d0ed6  call 0x00007A3FBE0E01C0
00007a3fbe1d0edb  jmp 0x00007A3FBE1D0D74
00007a3fbe1d0ee0  call 0x00007A3FBE0D5890
00007a3fbe1d0ee5  jmp 0x00007A3FBE1D0D8F
00007a3fbe1d0eea  call 0x00007A3FBE00BAE0
00007a3fbe1d0eef  jmp 0x00007A3FBE1D0DA3
00007a3fbe1d0ef4  call 0x00007A3FBE00DFE0
00007a3fbe1d0ef9  jmp 0x00007A3FBE1D0DB2
00007a3fbe1d0efe  call 0x00007A3FBE00DFE0
00007a3fbe1d0f03  jmp 0x00007A3FBE1D0DE0
00007a3fbe1d0f08  call 0x00007A3FBE00DFE0
00007a3fbe1d0f0d  jmp 0x00007A3FBE1D0DEF
00007a3fbe1d0f12  int3
00007a3fbe1d0f13  nop [rax+rax*1], ax
00007a3fbe1d0f1c  nop [rax], eax
00007a3fbe1d0f20  mov eax, [r15]
00007a3fbe1d0f23  mov [rsp+0x10], eax
00007a3fbe1d0f27  shr eax, 0x10
00007a3fbe1d0f2a  mov r14d, [rsp+0x10]
00007a3fbe1d0f2f  xor r14d, eax
00007a3fbe1d0f32  imul r14d, r14d, 0x7FEB352D
00007a3fbe1d0f39  mov eax, 0x846CA68B
00007a3fbe1d0f3e  mov eax, eax
00007a3fbe1d0f40  mov [r15+0x48], rax
00007a3fbe1d0f44  mov [rsp+0x10], r14d
00007a3fbe1d0f49  shr r14d, 0x0F
00007a3fbe1d0f4d  mov eax, [rsp+0x10]
00007a3fbe1d0f51  xor eax, r14d
00007a3fbe1d0f54  imul eax, eax, 0x846CA68B
00007a3fbe1d0f5a  mov [rsp+0x10], eax
00007a3fbe1d0f5e  mov eax, eax
00007a3fbe1d0f60  mov [r15+0x40], rax
00007a3fbe1d0f64  mov eax, [rsp+0x10]
00007a3fbe1d0f68  shr eax, 0x10
00007a3fbe1d0f6b  mov r14d, [rsp+0x10]
00007a3fbe1d0f70  xor r14d, eax
00007a3fbe1d0f73  mov r14d, r14d
00007a3fbe1d0f76  mov [r15], r14
00007a3fbe1d0f79  mov rax, [r15+0xF0]
00007a3fbe1d0f80  mov [r15+0x100], rax
00007a3fbe1d0f87  jmp 0x00007A3FBE1CE5C0
00007a3fbe1d0f8c  int3
00007a3fbe1d0f8d  int3
00007a3fbe1d0f8e  nop
00007a3fbe1d0f90  mov rax, [r15+0xA0]
00007a3fbe1d0f97  mov [rsp+0x10], rax
00007a3fbe1d0f9c  shl rax, 0x02
00007a3fbe1d0fa0  mov r14, [r15+0x98]
00007a3fbe1d0fa7  lea r12, [r14+rax*1]
00007a3fbe1d0fab  mov eax, [r15]
00007a3fbe1d0fae  mov [r13+r12*1], eax
00007a3fbe1d0fb3  mov rax, [rsp+0x10]
00007a3fbe1d0fb8  lea r14, [rax+0x01]
00007a3fbe1d0fbc  mov [r15+0xA0], r14
00007a3fbe1d0fc3  xor eax, eax
00007a3fbe1d0fc5  mov r12d, 0x400
00007a3fbe1d0fcb  cmp r14, r12
00007a3fbe1d0fce  cmc
00007a3fbe1d0fcf  lahf
00007a3fbe1d0fd0  seto al
00007a3fbe1d0fd3  mov [r15+0x108], eax
00007a3fbe1d0fda  mov eax, [r15+0x108]
00007a3fbe1d0fe1  sahf
00007a3fbe1d0fe2  jnz 0x00007A3FBE1D1014
00007a3fbe1d0fe4  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d0fec  jz 0x00007A3FBE1D10E0
00007a3fbe1d0ff2  nop [rax+rax*1], ax
00007a3fbe1d0ffb  nop [rax+rax*1], eax
00007a3fbe1d1003  mov eax, 0x41036C
00007a3fbe1d1008  mov [r15+0x100], rax
00007a3fbe1d100f  jmp 0x00007A3FBDFFE110
00007a3fbe1d1014  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d101c  jz 0x00007A3FBE1D1050
00007a3fbe1d1022  nop [rax+rax*1], ax
00007a3fbe1d102b  nop [rax+rax*1], eax
00007a3fbe1d1033  mov eax, 0x410354
00007a3fbe1d1038  mov [r15+0x100], rax
00007a3fbe1d103f  jmp 0x00007A3FBDFFE110
00007a3fbe1d1044  int3
00007a3fbe1d1045  call 0x00007A3FBE0B4B70
00007a3fbe1d104a  jmp 0x00007A3FBE1D0FB3
00007a3fbe1d104f  int3
00007a3fbe1d1050  mov eax, [r15+0xA0]
00007a3fbe1d1057  lea r14d, [eax+0x11]
00007a3fbe1d105c  mov r14d, r14d
00007a3fbe1d105f  mov [r15], r14
00007a3fbe1d1062  mov qword ptr [r15+0xF0], 0x41035C
00007a3fbe1d106d  mov r14d, [r15+0x320]
00007a3fbe1d1074  mov eax, 0x41035C
00007a3fbe1d1079  mov rcx, 0x7A3FBE1D0F90
00007a3fbe1d1083  mov [r15+r14*8+0x328], rax
00007a3fbe1d108b  mov [r15+r14*8+0x368], rcx
00007a3fbe1d1093  add r14d, 0x01
00007a3fbe1d1097  and r14d, 0x07
00007a3fbe1d109b  mov [r15+0x320], r14d
00007a3fbe1d10a2  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d10aa  jz 0x00007A3FBE1D0F20
00007a3fbe1d10b0  nop [rax+rax*1], ax
00007a3fbe1d10b9  nop [rax+rax*1], eax
00007a3fbe1d10c1  mov eax, 0x4109A4
00007a3fbe1d10c6  mov [r15+0x100], rax
00007a3fbe1d10cd  jmp 0x00007A3FBDFFE110
00007a3fbe1d10d2  int3
00007a3fbe1d10d3  int3
00007a3fbe1d10d4  nop [rax+rax*1], ax
00007a3fbe1d10dd  nop [rax], eax
00007a3fbe1d10e0  mov qword ptr [r15+0x40], 0x01
00007a3fbe1d10e8  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d10f0  jz 0x00007A3FBE1D1120
00007a3fbe1d10f6  nop [rax+rax*1], ax
00007a3fbe1d10ff  nop [rax+rax*1], eax
00007a3fbe1d1107  mov eax, 0x410388
00007a3fbe1d110c  mov [r15+0x100], rax
00007a3fbe1d1113  jmp 0x00007A3FBDFFE110
00007a3fbe1d1118  int3
00007a3fbe1d1119  int3
00007a3fbe1d111a  nop [rax+rax*1], ax
00007a3fbe1d1120  mov rax, [r15+0x40]
00007a3fbe1d1124  mov [rsp+0x10], rax
00007a3fbe1d1129  shl rax, 0x02
00007a3fbe1d112d  mov r14, [r15+0x98]
00007a3fbe1d1134  lea r12, [r14+rax*1]
00007a3fbe1d1138  mov eax, [r13+r12*1]
00007a3fbe1d113d  mov [rsp+0x20], eax
00007a3fbe1d1141  mov eax, eax
00007a3fbe1d1143  mov [r15+0x48], rax
00007a3fbe1d1147  mov rax, [rsp+0x10]
00007a3fbe1d114c  mov [r15+0x50], rax
00007a3fbe1d1150  mov eax, [r15+0x50]
00007a3fbe1d1154  lea r12d, [eax-0x01]
00007a3fbe1d1159  mov r12d, r12d
00007a3fbe1d115c  mov [r15+0x58], r12
00007a3fbe1d1160  mov rax, [r15+0x58]
00007a3fbe1d1164  mov r12d, eax
00007a3fbe1d1167  mov r12d, r12d
00007a3fbe1d116a  shl r12, 0x02
00007a3fbe1d116e  lea rax, [r14+r12*1]
00007a3fbe1d1172  mov r14d, [r13+rax*1]
00007a3fbe1d1177  mov [rsp+0x10], r14d
00007a3fbe1d117c  mov r14d, r14d
00007a3fbe1d117f  mov [r15+0x60], r14
00007a3fbe1d1183  xor eax, eax
00007a3fbe1d1185  mov r14d, [rsp+0x10]
00007a3fbe1d118a  mov r12d, [rsp+0x20]
00007a3fbe1d118f  cmp r14d, r12d
00007a3fbe1d1192  cmc
00007a3fbe1d1193  lahf
00007a3fbe1d1194  seto al
00007a3fbe1d1197  mov [r15+0x108], eax
00007a3fbe1d119e  mov eax, [r15+0x108]
00007a3fbe1d11a5  sahf
00007a3fbe1d11a6  cmc
00007a3fbe1d11a7  jbe 0x00007A3FBE1D11D9
00007a3fbe1d11a9  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d11b1  jz 0x00007A3FBE1D1220
00007a3fbe1d11b7  nop [rax+rax*1], ax
00007a3fbe1d11c0  nop [rax+rax*1], eax
00007a3fbe1d11c8  mov eax, 0x4103A0
00007a3fbe1d11cd  mov [r15+0x100], rax
00007a3fbe1d11d4  jmp 0x00007A3FBDFFE110
00007a3fbe1d11d9  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d11e1  jz 0x00007A3FBE1D14C0
00007a3fbe1d11e7  nop [rax+rax*1], ax
00007a3fbe1d11f0  nop [rax+rax*1], eax
00007a3fbe1d11f8  mov eax, 0x410378
00007a3fbe1d11fd  mov [r15+0x100], rax
00007a3fbe1d1204  jmp 0x00007A3FBDFFE110
00007a3fbe1d1209  int3
00007a3fbe1d120a  call 0x00007A3FBE0B4690
00007a3fbe1d120f  jmp 0x00007A3FBE1D113D
00007a3fbe1d1214  call 0x00007A3FBE00DAE0
00007a3fbe1d1219  jmp 0x00007A3FBE1D1177
00007a3fbe1d121e  int3
00007a3fbe1d121f  nop
00007a3fbe1d1220  mov rax, [r15+0x50]
00007a3fbe1d1224  mov [rsp+0x10], rax
00007a3fbe1d1229  shl rax, 0x02
00007a3fbe1d122d  mov r14, [r15+0x98]
00007a3fbe1d1234  lea r12, [r14+rax*1]
00007a3fbe1d1238  mov eax, [r15+0x60]
00007a3fbe1d123c  mov [r13+r12*1], eax
00007a3fbe1d1241  mov rax, [rsp+0x10]
00007a3fbe1d1246  lea r14, [rax-0x01]
00007a3fbe1d124a  mov [r15+0x50], r14
00007a3fbe1d124e  mov rax, [r15+0x58]
00007a3fbe1d1252  test rax, rax
00007a3fbe1d1255  setz al
00007a3fbe1d1258  movzx rax, al
00007a3fbe1d125c  mov [rsp+0x414], al
00007a3fbe1d1263  cmp byte ptr [rsp+0x414], 0x00
00007a3fbe1d126b  jz 0x00007A3FBE1D129D
00007a3fbe1d126d  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d1275  jz 0x00007A3FBE1D12E0
00007a3fbe1d127b  nop [rax+rax*1], ax
00007a3fbe1d1284  nop [rax+rax*1], eax
00007a3fbe1d128c  mov eax, 0x4103AC
00007a3fbe1d1291  mov [r15+0x100], rax
00007a3fbe1d1298  jmp 0x00007A3FBDFFE110
00007a3fbe1d129d  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d12a5  jz 0x00007A3FBE1D13E0
00007a3fbe1d12ab  nop [rax+rax*1], ax
00007a3fbe1d12b4  nop [rax+rax*1], eax
00007a3fbe1d12bc  mov eax, 0x410390
00007a3fbe1d12c1  mov [r15+0x100], rax
00007a3fbe1d12c8  jmp 0x00007A3FBDFFE110
00007a3fbe1d12cd  int3
00007a3fbe1d12ce  call 0x00007A3FBE0B4B70
00007a3fbe1d12d3  jmp 0x00007A3FBE1D1241
00007a3fbe1d12d8  int3
00007a3fbe1d12d9  nop [rax], eax
00007a3fbe1d12e0  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d12e8  jz 0x00007A3FBE1D1320
00007a3fbe1d12ee  nop [rax+rax*1], ax
00007a3fbe1d12f7  nop [rax+rax*1], eax
00007a3fbe1d12ff  mov eax, 0x410374
00007a3fbe1d1304  mov [r15+0x100], rax
00007a3fbe1d130b  jmp 0x00007A3FBDFFE110
00007a3fbe1d1310  int3
00007a3fbe1d1311  int3
00007a3fbe1d1312  nop [rax+rax*1], ax
00007a3fbe1d131b  nop [rax+rax*1], eax
00007a3fbe1d1320  mov qword ptr [r15+0x50], 0x00
00007a3fbe1d1328  mov rax, [r15+0x40]
00007a3fbe1d132c  lea r14, [rax+0x01]
00007a3fbe1d1330  mov [r15+0x40], r14
00007a3fbe1d1334  mov rax, [r15+0x98]
00007a3fbe1d133b  mov r12d, [r15+0x48]
00007a3fbe1d133f  mov [r13+rax*1], r12d
00007a3fbe1d1344  xor eax, eax
00007a3fbe1d1346  mov r12d, 0x400
00007a3fbe1d134c  cmp r14, r12
00007a3fbe1d134f  cmc
00007a3fbe1d1350  lahf
00007a3fbe1d1351  seto al
00007a3fbe1d1354  mov [r15+0x108], eax
00007a3fbe1d135b  mov eax, [r15+0x108]
00007a3fbe1d1362  sahf
00007a3fbe1d1363  jz 0x00007A3FBE1D1395
00007a3fbe1d1365  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d136d  jz 0x00007A3FBE1D1120
00007a3fbe1d1373  nop [rax+rax*1], ax
00007a3fbe1d137c  nop [rax+rax*1], eax
00007a3fbe1d1384  mov eax, 0x410388
00007a3fbe1d1389  mov [r15+0x100], rax
00007a3fbe1d1390  jmp 0x00007A3FBDFFE110
00007a3fbe1d1395  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d139d  jz 0x00007A3FBE1D1580
00007a3fbe1d13a3  nop [rax+rax*1], ax
00007a3fbe1d13ac  nop [rax+rax*1], eax
00007a3fbe1d13b4  mov eax, 0x4103B0
00007a3fbe1d13b9  mov [r15+0x100], rax
00007a3fbe1d13c0  jmp 0x00007A3FBDFFE110
00007a3fbe1d13c5  int3
00007a3fbe1d13c6  call 0x00007A3FBE00BAE0
00007a3fbe1d13cb  jmp 0x00007A3FBE1D1344
00007a3fbe1d13d0  int3
00007a3fbe1d13d1  nop [rax+rax*1], ax
00007a3fbe1d13da  nop [rax+rax*1], ax
00007a3fbe1d13e0  mov eax, [r15+0x50]
00007a3fbe1d13e4  lea r14d, [eax-0x01]
00007a3fbe1d13e9  mov r14d, r14d
00007a3fbe1d13ec  mov [r15+0x58], r14
00007a3fbe1d13f0  mov rax, [r15+0x58]
00007a3fbe1d13f4  mov r14d, eax
00007a3fbe1d13f7  mov r14d, r14d
00007a3fbe1d13fa  shl r14, 0x02
00007a3fbe1d13fe  mov rax, [r15+0x98]
00007a3fbe1d1405  lea r12, [rax+r14*1]
00007a3fbe1d1409  mov eax, [r13+r12*1]
00007a3fbe1d140e  mov [rsp+0x10], eax
00007a3fbe1d1412  mov eax, eax
00007a3fbe1d1414  mov [r15+0x60], rax
00007a3fbe1d1418  mov eax, [r15+0x48]
00007a3fbe1d141c  mov [rsp+0x20], eax
00007a3fbe1d1420  xor eax, eax
00007a3fbe1d1422  mov r14d, [rsp+0x10]
00007a3fbe1d1427  mov r12d, [rsp+0x20]
00007a3fbe1d142c  cmp r14d, r12d
00007a3fbe1d142f  cmc
00007a3fbe1d1430  lahf
00007a3fbe1d1431  seto al
00007a3fbe1d1434  mov [r15+0x108], eax
00007a3fbe1d143b  mov eax, [r15+0x108]
00007a3fbe1d1442  sahf
00007a3fbe1d1443  cmc
00007a3fbe1d1444  jbe 0x00007A3FBE1D1476
00007a3fbe1d1446  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d144e  jz 0x00007A3FBE1D1220
00007a3fbe1d1454  nop [rax+rax*1], ax
00007a3fbe1d145d  nop [rax+rax*1], eax
00007a3fbe1d1465  mov eax, 0x4103A0
00007a3fbe1d146a  mov [r15+0x100], rax
00007a3fbe1d1471  jmp 0x00007A3FBDFFE110
00007a3fbe1d1476  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d147e  jz 0x00007A3FBE1D14C0
00007a3fbe1d1484  nop [rax+rax*1], ax
00007a3fbe1d148d  nop [rax+rax*1], eax
00007a3fbe1d1495  mov eax, 0x410378
00007a3fbe1d149a  mov [r15+0x100], rax
00007a3fbe1d14a1  jmp 0x00007A3FBDFFE110
00007a3fbe1d14a6  int3
00007a3fbe1d14a7  call 0x00007A3FBE0B4690
00007a3fbe1d14ac  jmp 0x00007A3FBE1D140E
00007a3fbe1d14b1  int3
00007a3fbe1d14b2  nop [rax+rax*1], ax
00007a3fbe1d14bb  nop [rax+rax*1], eax
00007a3fbe1d14c0  mov rax, [r15+0x40]
00007a3fbe1d14c4  lea r14, [rax+0x01]
00007a3fbe1d14c8  mov [r15+0x40], r14
00007a3fbe1d14cc  mov rax, [r15+0x50]
00007a3fbe1d14d0  mov r12d, eax
00007a3fbe1d14d3  mov r12d, r12d
00007a3fbe1d14d6  shl r12, 0x02
00007a3fbe1d14da  mov rax, [r15+0x98]
00007a3fbe1d14e1  lea r11, [rax+r12*1]
00007a3fbe1d14e5  mov eax, [r15+0x48]
00007a3fbe1d14e9  mov [r13+r11*1], eax
00007a3fbe1d14ee  xor eax, eax
00007a3fbe1d14f0  mov r12d, 0x400
00007a3fbe1d14f6  cmp r14, r12
00007a3fbe1d14f9  cmc
00007a3fbe1d14fa  lahf
00007a3fbe1d14fb  seto al
00007a3fbe1d14fe  mov [r15+0x108], eax
00007a3fbe1d1505  mov eax, [r15+0x108]
00007a3fbe1d150c  sahf
00007a3fbe1d150d  jz 0x00007A3FBE1D153F
00007a3fbe1d150f  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d1517  jz 0x00007A3FBE1D1120
00007a3fbe1d151d  nop [rax+rax*1], ax
00007a3fbe1d1526  nop [rax+rax*1], eax
00007a3fbe1d152e  mov eax, 0x410388
00007a3fbe1d1533  mov [r15+0x100], rax
00007a3fbe1d153a  jmp 0x00007A3FBDFFE110
00007a3fbe1d153f  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d1547  jz 0x00007A3FBE1D1580
00007a3fbe1d154d  nop [rax+rax*1], ax
00007a3fbe1d1556  nop [rax+rax*1], eax
00007a3fbe1d155e  mov eax, 0x4103B0
00007a3fbe1d1563  mov [r15+0x100], rax
00007a3fbe1d156a  jmp 0x00007A3FBDFFE110
00007a3fbe1d156f  int3
00007a3fbe1d1570  call 0x00007A3FBE0A4270
00007a3fbe1d1575  jmp 0x00007A3FBE1D14EE
00007a3fbe1d157a  int3
00007a3fbe1d157b  nop [rax+rax*1], eax
00007a3fbe1d1580  mov qword ptr [r15+0x40], 0x430000
00007a3fbe1d1588  mov eax, 0x430CB0
00007a3fbe1d158d  mov r14, [r13+rax*1]
00007a3fbe1d1592  mov rax, [r15+0x98]
00007a3fbe1d1599  mov r12d, [r13+rax*1]
00007a3fbe1d159e  lea r11, [rax+0x04]
00007a3fbe1d15a2  mov eax, [r13+r11*1]
00007a3fbe1d15a7  mov r12d, r12d
00007a3fbe1d15aa  mov [r15+0x68], r12
00007a3fbe1d15ae  mov eax, eax
00007a3fbe1d15b0  mov [r15+0x60], rax
00007a3fbe1d15b4  mov rax, [r15+0x68]
00007a3fbe1d15b8  mov [r15+0x68], rax
00007a3fbe1d15bc  mov qword ptr [r15+0x58], 0x02
00007a3fbe1d15c4  mov [rsp+0x10], rax
00007a3fbe1d15c9  xor eax, eax
00007a3fbe1d15cb  mov r12d, 0x02
00007a3fbe1d15d1  mov r11d, 0x400
00007a3fbe1d15d7  cmp r12, r11
00007a3fbe1d15da  cmc
00007a3fbe1d15db  lahf
00007a3fbe1d15dc  seto al
00007a3fbe1d15df  mov [r15+0x108], eax
00007a3fbe1d15e6  mov rax, [r15+0x60]
00007a3fbe1d15ea  mov r12d, 0x02
00007a3fbe1d15f0  imul rax, r12
00007a3fbe1d15f4  mov [r15+0x50], rax
00007a3fbe1d15f8  mov rax, [rsp+0x10]
00007a3fbe1d15fd  lea r12, [rax+r14*1]
00007a3fbe1d1601  mov [r15+0x48], r12
00007a3fbe1d1605  mov eax, [r15+0x108]
00007a3fbe1d160c  sahf
00007a3fbe1d160d  jnz 0x00007A3FBE1D163F
00007a3fbe1d160f  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d1617  jz 0x00007A3FBE1D17B0
00007a3fbe1d161d  nop [rax+rax*1], ax
00007a3fbe1d1626  nop [rax+rax*1], eax
00007a3fbe1d162e  mov eax, 0x4103E0
00007a3fbe1d1633  mov [r15+0x100], rax
00007a3fbe1d163a  jmp 0x00007A3FBDFFE110
00007a3fbe1d163f  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d1647  jz 0x00007A3FBE1D1690
00007a3fbe1d164d  nop [rax+rax*1], ax
00007a3fbe1d1656  nop [rax+rax*1], eax
00007a3fbe1d165e  mov eax, 0x4103C0
00007a3fbe1d1663  mov [r15+0x100], rax
00007a3fbe1d166a  jmp 0x00007A3FBDFFE110
00007a3fbe1d166f  int3
00007a3fbe1d1670  call 0x00007A3FBE00DC20
00007a3fbe1d1675  jmp 0x00007A3FBE1D1592
00007a3fbe1d167a  call 0x00007A3FBE00B5E0
00007a3fbe1d167f  jmp 0x00007A3FBE1D159E
00007a3fbe1d1684  call 0x00007A3FBE0A3D90
00007a3fbe1d1689  jmp 0x00007A3FBE1D15A7
00007a3fbe1d168e  int3
00007a3fbe1d168f  nop
00007a3fbe1d1690  mov rax, [r15+0x98]
00007a3fbe1d1697  mov r14, [r15+0x58]
00007a3fbe1d169b  mov [rsp+0x10], r14
00007a3fbe1d16a0  shl r14, 0x02
00007a3fbe1d16a4  lea r12, [rax+r14*1]
00007a3fbe1d16a8  mov eax, [r13+r12*1]
00007a3fbe1d16ad  lea r14, [r12+0x04]
00007a3fbe1d16b2  mov r12d, [r13+r14*1]
00007a3fbe1d16b7  mov eax, eax
00007a3fbe1d16b9  mov [r15+0x68], rax
00007a3fbe1d16bd  mov r12d, r12d
00007a3fbe1d16c0  mov [r15+0x60], r12
00007a3fbe1d16c4  mov rax, [r15+0x68]
00007a3fbe1d16c8  mov [rsp+0x20], rax
00007a3fbe1d16cd  mov r14, [rsp+0x10]
00007a3fbe1d16d2  imul rax, r14
00007a3fbe1d16d6  mov r12, [rsp+0x20]
00007a3fbe1d16db  lea r11, [r12+rax*1]
00007a3fbe1d16df  mov [r15+0x68], r11
00007a3fbe1d16e3  lea rax, [r14+0x02]
00007a3fbe1d16e7  mov [r15+0x58], rax
00007a3fbe1d16eb  mov [rsp+0x10], rax
00007a3fbe1d16f0  xor eax, eax
00007a3fbe1d16f2  mov r14, [rsp+0x10]
00007a3fbe1d16f7  mov r12d, 0x400
00007a3fbe1d16fd  cmp r14, r12
00007a3fbe1d1700  cmc
00007a3fbe1d1701  lahf
00007a3fbe1d1702  seto al
00007a3fbe1d1705  mov [r15+0x108], eax
00007a3fbe1d170c  mov rax, [r15+0x50]
00007a3fbe1d1710  mov r12, [r15+0x60]
00007a3fbe1d1714  imul r14, r12
00007a3fbe1d1718  lea r12, [rax+r14*1]
00007a3fbe1d171c  mov [r15+0x50], r12
00007a3fbe1d1720  mov rax, [r15+0x48]
00007a3fbe1d1724  lea r14, [r11+rax*1]
00007a3fbe1d1728  mov [r15+0x48], r14
00007a3fbe1d172c  mov eax, [r15+0x108]
00007a3fbe1d1733  sahf
00007a3fbe1d1734  jnz 0x00007A3FBE1D1766
00007a3fbe1d1736  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d173e  jz 0x00007A3FBE1D17B0
00007a3fbe1d1744  nop [rax+rax*1], ax
00007a3fbe1d174d  nop [rax+rax*1], eax
00007a3fbe1d1755  mov eax, 0x4103E0
00007a3fbe1d175a  mov [r15+0x100], rax
00007a3fbe1d1761  jmp 0x00007A3FBDFFE110
00007a3fbe1d1766  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d176e  jz 0x00007A3FBE1D1690
00007a3fbe1d1774  nop [rax+rax*1], ax
00007a3fbe1d177d  nop [rax+rax*1], eax
00007a3fbe1d1785  mov eax, 0x4103C0
00007a3fbe1d178a  mov [r15+0x100], rax
00007a3fbe1d1791  jmp 0x00007A3FBDFFE110
00007a3fbe1d1796  int3
00007a3fbe1d1797  call 0x00007A3FBE0B4690
00007a3fbe1d179c  jmp 0x00007A3FBE1D16AD
00007a3fbe1d17a1  call 0x00007A3FBE0E26A0
00007a3fbe1d17a6  jmp 0x00007A3FBE1D16B7
00007a3fbe1d17ab  int3
00007a3fbe1d17ac  nop [rax], eax
00007a3fbe1d17b0  mov qword ptr [r15+0x98], 0x00
00007a3fbe1d17bb  mov rax, [r15+0x50]
00007a3fbe1d17bf  mov r14, [r15+0x48]
00007a3fbe1d17c3  lea r12, [rax+r14*1]
00007a3fbe1d17c7  mov [r15+0x48], r12
00007a3fbe1d17cb  mov rax, [r15+0x40]
00007a3fbe1d17cf  lea r14, [rax+0xCB0]
00007a3fbe1d17d6  mov [r13+r14*1], r12
00007a3fbe1d17db  mov qword ptr [r15], 0x01
00007a3fbe1d17e2  mov qword ptr [r15+0xF0], 0x4103F8
00007a3fbe1d17ed  mov r14d, [r15+0x320]
00007a3fbe1d17f4  mov eax, 0x4103F8
00007a3fbe1d17f9  mov rcx, 0x7A3FBE1D1860
00007a3fbe1d1803  mov [r15+r14*8+0x328], rax
00007a3fbe1d180b  mov [r15+r14*8+0x368], rcx
00007a3fbe1d1813  add r14d, 0x01
00007a3fbe1d1817  and r14d, 0x07
00007a3fbe1d181b  mov [r15+0x320], r14d
00007a3fbe1d1822  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d182a  jz 0x00007A3FBE1D0F20
00007a3fbe1d1830  nop [rax+rax*1], ax
00007a3fbe1d1839  nop [rax+rax*1], eax
00007a3fbe1d1841  mov eax, 0x4109A4
00007a3fbe1d1846  mov [r15+0x100], rax
00007a3fbe1d184d  jmp 0x00007A3FBDFFE110
00007a3fbe1d1852  int3
00007a3fbe1d1853  call 0x00007A3FBE0E2CE0
00007a3fbe1d1858  jmp 0x00007A3FBE1D17DB
00007a3fbe1d185d  int3
00007a3fbe1d185e  nop
00007a3fbe1d1860  mov eax, [r15+0x98]
00007a3fbe1d1867  lea r14d, [eax+0x01]
00007a3fbe1d186c  mov [rsp+0x10], r14d
00007a3fbe1d1871  mov r14d, r14d
00007a3fbe1d1874  mov [r15+0x98], r14
00007a3fbe1d187b  xor eax, eax
00007a3fbe1d187d  mov r14d, [rsp+0x10]
00007a3fbe1d1882  cmp r14d, 0x10000
00007a3fbe1d1889  cmc
00007a3fbe1d188a  lahf
00007a3fbe1d188b  seto al
00007a3fbe1d188e  mov [r15+0x108], eax
00007a3fbe1d1895  mov eax, [r15+0x108]
00007a3fbe1d189c  sahf
00007a3fbe1d189d  jnz 0x00007A3FBE1D18CF
00007a3fbe1d189f  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d18a7  jz 0x00007A3FBE1D19A0
00007a3fbe1d18ad  nop [rax+rax*1], ax
00007a3fbe1d18b6  nop [rax+rax*1], eax
00007a3fbe1d18be  mov eax, 0x410404
00007a3fbe1d18c3  mov [r15+0x100], rax
00007a3fbe1d18ca  jmp 0x00007A3FBDFFE110
00007a3fbe1d18cf  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d18d7  jz 0x00007A3FBE1D1910
00007a3fbe1d18dd  nop [rax+rax*1], ax
00007a3fbe1d18e6  nop [rax+rax*1], eax
00007a3fbe1d18ee  mov eax, 0x4103F0
00007a3fbe1d18f3  mov [r15+0x100], rax
00007a3fbe1d18fa  jmp 0x00007A3FBDFFE110
00007a3fbe1d18ff  int3
00007a3fbe1d1900  int3
00007a3fbe1d1901  nop [rax+rax*1], ax
00007a3fbe1d190a  nop [rax+rax*1], ax
00007a3fbe1d1910  mov eax, [r15]
00007a3fbe1d1913  mov r14d, [r15+0x98]
00007a3fbe1d191a  lea r12d, [eax+r14d*1]
00007a3fbe1d191f  mov r12d, r12d
00007a3fbe1d1922  mov [r15], r12
00007a3fbe1d1925  mov qword ptr [r15+0xF0], 0x4103F8
00007a3fbe1d1930  mov r14d, [r15+0x320]
00007a3fbe1d1937  mov eax, 0x4103F8
00007a3fbe1d193c  mov rcx, 0x7A3FBE1D1860
00007a3fbe1d1946  mov [r15+r14*8+0x328], rax
00007a3fbe1d194e  mov [r15+r14*8+0x368], rcx
00007a3fbe1d1956  add r14d, 0x01
00007a3fbe1d195a  and r14d, 0x07
00007a3fbe1d195e  mov [r15+0x320], r14d
00007a3fbe1d1965  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d196d  jz 0x00007A3FBE1D0F20
00007a3fbe1d1973  nop [rax+rax*1], ax
00007a3fbe1d197c  nop [rax+rax*1], eax
00007a3fbe1d1984  mov eax, 0x4109A4
00007a3fbe1d1989  mov [r15+0x100], rax
00007a3fbe1d1990  jmp 0x00007A3FBDFFE110
00007a3fbe1d1995  int3
00007a3fbe1d1996  int3
00007a3fbe1d1997  nop [rax+rax*1], ax
00007a3fbe1d19a0  vmovaps xmm1, [0x00007A3FBDDFE010]
00007a3fbe1d19a8  movq xmm1, xmm1
00007a3fbe1d19ac  movaps [r15+0x110], xmm1
00007a3fbe1d19b4  mov eax, 0x420B10
00007a3fbe1d19b9  mov r14, [r13+rax*1]
00007a3fbe1d19be  movq xmm1, r14
00007a3fbe1d19c3  movaps [r15+0x120], xmm1
00007a3fbe1d19cb  vmovaps xmm1, [0x00007A3FBDDFE020]
00007a3fbe1d19d3  movq xmm1, xmm1
00007a3fbe1d19d7  movaps [r15+0x140], xmm1
00007a3fbe1d19df  vmovaps xmm1, [0x00007A3FBDDFE030]
00007a3fbe1d19e7  vpbroadcastq xmm1, xmm1
00007a3fbe1d19ec  movaps [r15+0x150], xmm1
00007a3fbe1d19f4  mov qword ptr [r15+0x40], 0x02
00007a3fbe1d19fc  vmovaps xmm15, [0x00007A3FBDDFE040]
00007a3fbe1d1a04  movq xmm15, xmm15
00007a3fbe1d1a09  movaps [r15+0x160], xmm15
00007a3fbe1d1a11  vmovaps xmm15, [0x00007A3FBDDFE050]
00007a3fbe1d1a19  vpbroadcastq xmm15, xmm15
00007a3fbe1d1a1e  movaps [r15+0x130], xmm15
00007a3fbe1d1a26  mov rax, [r15+0x40]
00007a3fbe1d1a2a  vmovq xmm14, rax
00007a3fbe1d1a2f  vpbroadcastq xmm14, xmm14
00007a3fbe1d1a34  movaps [r15+0x170], xmm14
00007a3fbe1d1a3c  mov eax, 0x420A40
00007a3fbe1d1a41  movups xmm13, [r13+rax*1]
00007a3fbe1d1a47  mov qword ptr [r15+0x40], 0x431E00
00007a3fbe1d1a4f  mov eax, [r15]
00007a3fbe1d1a52  mov r14d, 0x430CB8
00007a3fbe1d1a58  mov [r13+r14*1], eax
00007a3fbe1d1a5d  mov qword ptr [r15+0x50], 0x432000
00007a3fbe1d1a65  vpmovqd xmm12, xmm13
00007a3fbe1d1a6b  pxor xmm11, xmm11
00007a3fbe1d1a70  punpcklqdq xmm12, xmm11
00007a3fbe1d1a75  movaps [r15+0x210], xmm12
00007a3fbe1d1a7d  movq xmm12, qword ptr [r15+0x140]
00007a3fbe1d1a86  movq xmm11, qword ptr [r15+0x120]
00007a3fbe1d1a8f  psubd xmm12, xmm11
00007a3fbe1d1a94  movq xmm12, xmm12
00007a3fbe1d1a99  paddq xmm13, xmm14
00007a3fbe1d1a9e  movaps [r15+0x180], xmm13
00007a3fbe1d1aa6  movq xmm14, qword ptr [r15+0x160]
00007a3fbe1d1aaf  paddd xmm11, xmm14
00007a3fbe1d1ab4  movq xmm11, xmm11
00007a3fbe1d1ab9  movq xmm11, xmm11
00007a3fbe1d1abe  movaps [r15+0x120], xmm11
00007a3fbe1d1ac6  pmovzxdq xmm12, xmm12
00007a3fbe1d1acc  psllq xmm12, 0x00
00007a3fbe1d1ad2  movq xmm14, qword ptr [r15+0x210]
00007a3fbe1d1adb  movq xmm13, qword ptr [r15+0x110]
00007a3fbe1d1ae4  paddd xmm14, xmm13
00007a3fbe1d1ae9  movq xmm14, xmm14
00007a3fbe1d1aee  vcvtuqq2pd xmm12, xmm12
00007a3fbe1d1af4  pmovzxdq xmm14, xmm14
00007a3fbe1d1afa  psllq xmm14, 0x00
00007a3fbe1d1b00  vcvtuqq2pd xmm14, xmm14
00007a3fbe1d1b06  movaps xmm13, xmm12
00007a3fbe1d1b0a  mulpd xmm13, xmm1
00007a3fbe1d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
00007a3fbe1d1b15  ptest xmm11, xmm11
00007a3fbe1d1b1b  jnz 0x00007A3FBE1D1C0F
00007a3fbe1d1b21  movaps [r15+0x220], xmm13
00007a3fbe1d1b29  mov eax, 0x432000
00007a3fbe1d1b2e  movups [r13+rax*1], xmm13
00007a3fbe1d1b34  movaps xmm1, xmm14
00007a3fbe1d1b38  mulpd xmm1, xmm15
00007a3fbe1d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
00007a3fbe1d1b42  ptest xmm13, xmm13
00007a3fbe1d1b48  jnz 0x00007A3FBE1D1D5C
00007a3fbe1d1b4e  movaps [r15+0x210], xmm1
00007a3fbe1d1b56  mov eax, 0x431E00
00007a3fbe1d1b5b  movups [r13+rax*1], xmm1
00007a3fbe1d1b61  mov qword ptr [r15+0x48], 0x10
00007a3fbe1d1b69  xor eax, eax
00007a3fbe1d1b6b  mov r14d, 0x10
00007a3fbe1d1b71  mov r12d, 0x200
00007a3fbe1d1b77  cmp r14, r12
00007a3fbe1d1b7a  cmc
00007a3fbe1d1b7b  lahf
00007a3fbe1d1b7c  seto al
00007a3fbe1d1b7f  mov [r15+0x108], eax
00007a3fbe1d1b86  mov eax, [r15+0x108]
00007a3fbe1d1b8d  sahf
00007a3fbe1d1b8e  jnz 0x00007A3FBE1D1BC0
00007a3fbe1d1b90  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d1b98  jz 0x00007A3FBE1D2300
00007a3fbe1d1b9e  nop [rax+rax*1], ax
00007a3fbe1d1ba7  nop [rax+rax*1], eax
00007a3fbe1d1baf  mov eax, 0x410490
00007a3fbe1d1bb4  mov [r15+0x100], rax
00007a3fbe1d1bbb  jmp 0x00007A3FBDFFE110
00007a3fbe1d1bc0  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d1bc8  jz 0x00007A3FBE1D1EB0
00007a3fbe1d1bce  nop [rax+rax*1], ax
00007a3fbe1d1bd7  nop [rax+rax*1], eax
00007a3fbe1d1bdf  mov eax, 0x410450
00007a3fbe1d1be4  mov [r15+0x100], rax
00007a3fbe1d1beb  jmp 0x00007A3FBDFFE110
00007a3fbe1d1bf0  int3
00007a3fbe1d1bf1  call 0x00007A3FBE00DC20
00007a3fbe1d1bf6  jmp 0x00007A3FBE1D19BE
00007a3fbe1d1bfb  call 0x00007A3FBE00C260
00007a3fbe1d1c00  jmp 0x00007A3FBE1D1A47
00007a3fbe1d1c05  call 0x00007A3FBE0D5D70
00007a3fbe1d1c0a  jmp 0x00007A3FBE1D1A5D
00007a3fbe1d1c0f  sub rsp, 0x08
00007a3fbe1d1c13  push rax
00007a3fbe1d1c14  push rcx
00007a3fbe1d1c15  push rdx
00007a3fbe1d1c16  push rdi
00007a3fbe1d1c17  push rsi
00007a3fbe1d1c18  push r8
00007a3fbe1d1c1a  push r9
00007a3fbe1d1c1c  push r10
00007a3fbe1d1c1e  push r11
00007a3fbe1d1c20  sub rsp, 0xF0
00007a3fbe1d1c27  vmovaps [rsp], xmm0
00007a3fbe1d1c2c  vmovaps [rsp+0x10], xmm1
00007a3fbe1d1c32  vmovaps [rsp+0x20], xmm2
00007a3fbe1d1c38  vmovaps [rsp+0x30], xmm3
00007a3fbe1d1c3e  vmovaps [rsp+0x40], xmm4
00007a3fbe1d1c44  vmovaps [rsp+0x50], xmm5
00007a3fbe1d1c4a  vmovaps [rsp+0x60], xmm6
00007a3fbe1d1c50  vmovaps [rsp+0x70], xmm7
00007a3fbe1d1c56  vmovaps [rsp+0x80], xmm8
00007a3fbe1d1c5f  vmovaps [rsp+0x90], xmm9
00007a3fbe1d1c68  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d1c71  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d1c7a  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d1c83  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d1c8c  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d1c95  sub rsp, 0x30
00007a3fbe1d1c99  movaps [rsp], xmm13
00007a3fbe1d1c9e  movaps [rsp+0x10], xmm12
00007a3fbe1d1ca4  movaps [rsp+0x20], xmm1
00007a3fbe1d1ca9  lea rdi, [rsp]
00007a3fbe1d1cad  mov esi, 0x00
00007a3fbe1d1cb2  mov rax, 0x60D1084DB530
00007a3fbe1d1cbc  call rax
00007a3fbe1d1cbe  movaps xmm13, [rsp]
00007a3fbe1d1cc3  add rsp, 0x30
00007a3fbe1d1cc7  vmovaps xmm0, [rsp]
00007a3fbe1d1ccc  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d1cd2  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d1cd8  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d1cde  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d1ce4  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d1cea  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d1cf0  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d1cf6  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d1cff  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d1d08  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d1d11  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d1d1a  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d1d23  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d1d2c  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d1d35  add rsp, 0xF0
00007a3fbe1d1d3c  pop r11
00007a3fbe1d1d3e  pop r10
00007a3fbe1d1d40  pop r9
00007a3fbe1d1d42  pop r8
00007a3fbe1d1d44  pop rsi
00007a3fbe1d1d45  pop rdi
00007a3fbe1d1d46  pop rdx
00007a3fbe1d1d47  pop rcx
00007a3fbe1d1d48  pop rax
00007a3fbe1d1d49  add rsp, 0x08
00007a3fbe1d1d4d  jmp 0x00007A3FBE1D1B21
00007a3fbe1d1d52  call 0x00007A3FBE00C380
00007a3fbe1d1d57  jmp 0x00007A3FBE1D1B34
00007a3fbe1d1d5c  sub rsp, 0x08
00007a3fbe1d1d60  push rax
00007a3fbe1d1d61  push rcx
00007a3fbe1d1d62  push rdx
00007a3fbe1d1d63  push rdi
00007a3fbe1d1d64  push rsi
00007a3fbe1d1d65  push r8
00007a3fbe1d1d67  push r9
00007a3fbe1d1d69  push r10
00007a3fbe1d1d6b  push r11
00007a3fbe1d1d6d  sub rsp, 0xF0
00007a3fbe1d1d74  vmovaps [rsp], xmm0
00007a3fbe1d1d79  vmovaps [rsp+0x10], xmm2
00007a3fbe1d1d7f  vmovaps [rsp+0x20], xmm3
00007a3fbe1d1d85  vmovaps [rsp+0x30], xmm4
00007a3fbe1d1d8b  vmovaps [rsp+0x40], xmm5
00007a3fbe1d1d91  vmovaps [rsp+0x50], xmm6
00007a3fbe1d1d97  vmovaps [rsp+0x60], xmm7
00007a3fbe1d1d9d  vmovaps [rsp+0x70], xmm8
00007a3fbe1d1da3  vmovaps [rsp+0x80], xmm9
00007a3fbe1d1dac  vmovaps [rsp+0x90], xmm10
00007a3fbe1d1db5  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d1dbe  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d1dc7  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d1dd0  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d1dd9  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d1de2  sub rsp, 0x30
00007a3fbe1d1de6  movaps [rsp], xmm1
00007a3fbe1d1dea  movaps [rsp+0x10], xmm14
00007a3fbe1d1df0  movaps [rsp+0x20], xmm15
00007a3fbe1d1df6  lea rdi, [rsp]
00007a3fbe1d1dfa  mov esi, 0x00
00007a3fbe1d1dff  mov rax, 0x60D1084DB530
00007a3fbe1d1e09  call rax
00007a3fbe1d1e0b  movaps xmm1, [rsp]
00007a3fbe1d1e0f  add rsp, 0x30
00007a3fbe1d1e13  vmovaps xmm0, [rsp]
00007a3fbe1d1e18  vmovaps xmm2, [rsp+0x10]
00007a3fbe1d1e1e  vmovaps xmm3, [rsp+0x20]
00007a3fbe1d1e24  vmovaps xmm4, [rsp+0x30]
00007a3fbe1d1e2a  vmovaps xmm5, [rsp+0x40]
00007a3fbe1d1e30  vmovaps xmm6, [rsp+0x50]
00007a3fbe1d1e36  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d1e3c  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d1e42  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d1e4b  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d1e54  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d1e5d  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d1e66  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d1e6f  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d1e78  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d1e81  add rsp, 0xF0
00007a3fbe1d1e88  pop r11
00007a3fbe1d1e8a  pop r10
00007a3fbe1d1e8c  pop r9
00007a3fbe1d1e8e  pop r8
00007a3fbe1d1e90  pop rsi
00007a3fbe1d1e91  pop rdi
00007a3fbe1d1e92  pop rdx
00007a3fbe1d1e93  pop rcx
00007a3fbe1d1e94  pop rax
00007a3fbe1d1e95  add rsp, 0x08
00007a3fbe1d1e99  jmp 0x00007A3FBE1D1B4E
00007a3fbe1d1e9e  call 0x00007A3FBDFFF540
00007a3fbe1d1ea3  jmp 0x00007A3FBE1D1B61
00007a3fbe1d1ea8  int3
00007a3fbe1d1ea9  nop [rax], eax
00007a3fbe1d1eb0  movaps xmm1, [r15+0x180]
00007a3fbe1d1eb8  vpmovqd xmm15, xmm1
00007a3fbe1d1ebe  pxor xmm14, xmm14
00007a3fbe1d1ec3  punpcklqdq xmm15, xmm14
00007a3fbe1d1ec8  movaps [r15+0x210], xmm15
00007a3fbe1d1ed0  movq xmm15, qword ptr [r15+0x140]
00007a3fbe1d1ed9  movq xmm14, qword ptr [r15+0x120]
00007a3fbe1d1ee2  psubd xmm15, xmm14
00007a3fbe1d1ee7  movq xmm15, xmm15
00007a3fbe1d1eec  movaps xmm13, [r15+0x170]
00007a3fbe1d1ef4  paddq xmm1, xmm13
00007a3fbe1d1ef9  movaps [r15+0x180], xmm1
00007a3fbe1d1f01  movq xmm1, qword ptr [r15+0x160]
00007a3fbe1d1f0a  paddd xmm14, xmm1
00007a3fbe1d1f0f  movq xmm14, xmm14
00007a3fbe1d1f14  movq xmm14, xmm14
00007a3fbe1d1f19  movaps [r15+0x120], xmm14
00007a3fbe1d1f21  pmovzxdq xmm15, xmm15
00007a3fbe1d1f27  psllq xmm15, 0x00
00007a3fbe1d1f2d  movq xmm1, qword ptr [r15+0x210]
00007a3fbe1d1f36  movq xmm14, qword ptr [r15+0x110]
00007a3fbe1d1f3f  paddd xmm1, xmm14
00007a3fbe1d1f44  movq xmm1, xmm1
00007a3fbe1d1f48  vcvtuqq2pd xmm15, xmm15
00007a3fbe1d1f4e  pmovzxdq xmm1, xmm1
00007a3fbe1d1f53  psllq xmm1, 0x00
00007a3fbe1d1f58  vcvtuqq2pd xmm1, xmm1
00007a3fbe1d1f5e  movaps xmm14, [r15+0x150]
00007a3fbe1d1f66  movaps xmm13, xmm15
00007a3fbe1d1f6a  mulpd xmm13, xmm14
00007a3fbe1d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
00007a3fbe1d1f75  ptest xmm12, xmm12
00007a3fbe1d1f7b  jnz 0x00007A3FBE1D205E
00007a3fbe1d1f81  movaps [r15+0x220], xmm13
00007a3fbe1d1f89  mov rax, [r15+0x48]
00007a3fbe1d1f8d  mov r14, [r15+0x50]
00007a3fbe1d1f91  lea r12, [r14+rax*1]
00007a3fbe1d1f95  movups [r13+r12*1], xmm13
00007a3fbe1d1f9b  movaps xmm15, [r15+0x130]
00007a3fbe1d1fa3  movaps xmm14, xmm1
00007a3fbe1d1fa7  mulpd xmm14, xmm15
00007a3fbe1d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
00007a3fbe1d1fb2  ptest xmm13, xmm13
00007a3fbe1d1fb8  jnz 0x00007A3FBE1D21AC
00007a3fbe1d1fbe  movaps [r15+0x210], xmm14
00007a3fbe1d1fc6  mov r14, [r15+0x40]
00007a3fbe1d1fca  lea r12, [r14+rax*1]
00007a3fbe1d1fce  movups [r13+r12*1], xmm14
00007a3fbe1d1fd4  lea r14, [rax+0x10]
00007a3fbe1d1fd8  mov [r15+0x48], r14
00007a3fbe1d1fdc  xor eax, eax
00007a3fbe1d1fde  mov r12d, 0x200
00007a3fbe1d1fe4  cmp r14, r12
00007a3fbe1d1fe7  cmc
00007a3fbe1d1fe8  lahf
00007a3fbe1d1fe9  seto al
00007a3fbe1d1fec  mov [r15+0x108], eax
00007a3fbe1d1ff3  mov eax, [r15+0x108]
00007a3fbe1d1ffa  sahf
00007a3fbe1d1ffb  jnz 0x00007A3FBE1D202D
00007a3fbe1d1ffd  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d2005  jz 0x00007A3FBE1D2300
00007a3fbe1d200b  nop [rax+rax*1], ax
00007a3fbe1d2014  nop [rax+rax*1], eax
00007a3fbe1d201c  mov eax, 0x410490
00007a3fbe1d2021  mov [r15+0x100], rax
00007a3fbe1d2028  jmp 0x00007A3FBDFFE110
00007a3fbe1d202d  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d2035  jz 0x00007A3FBE1D1EB0
00007a3fbe1d203b  nop [rax+rax*1], ax
00007a3fbe1d2044  nop [rax+rax*1], eax
00007a3fbe1d204c  mov eax, 0x410450
00007a3fbe1d2051  mov [r15+0x100], rax
00007a3fbe1d2058  jmp 0x00007A3FBDFFE110
00007a3fbe1d205d  int3
00007a3fbe1d205e  sub rsp, 0x08
00007a3fbe1d2062  push rax
00007a3fbe1d2063  push rcx
00007a3fbe1d2064  push rdx
00007a3fbe1d2065  push rdi
00007a3fbe1d2066  push rsi
00007a3fbe1d2067  push r8
00007a3fbe1d2069  push r9
00007a3fbe1d206b  push r10
00007a3fbe1d206d  push r11
00007a3fbe1d206f  sub rsp, 0xF0
00007a3fbe1d2076  vmovaps [rsp], xmm0
00007a3fbe1d207b  vmovaps [rsp+0x10], xmm1
00007a3fbe1d2081  vmovaps [rsp+0x20], xmm2
00007a3fbe1d2087  vmovaps [rsp+0x30], xmm3
00007a3fbe1d208d  vmovaps [rsp+0x40], xmm4
00007a3fbe1d2093  vmovaps [rsp+0x50], xmm5
00007a3fbe1d2099  vmovaps [rsp+0x60], xmm6
00007a3fbe1d209f  vmovaps [rsp+0x70], xmm7
00007a3fbe1d20a5  vmovaps [rsp+0x80], xmm8
00007a3fbe1d20ae  vmovaps [rsp+0x90], xmm9
00007a3fbe1d20b7  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d20c0  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d20c9  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d20d2  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d20db  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d20e4  sub rsp, 0x30
00007a3fbe1d20e8  movaps [rsp], xmm13
00007a3fbe1d20ed  movaps [rsp+0x10], xmm15
00007a3fbe1d20f3  movaps [rsp+0x20], xmm14
00007a3fbe1d20f9  lea rdi, [rsp]
00007a3fbe1d20fd  mov esi, 0x00
00007a3fbe1d2102  mov rax, 0x60D1084DB530
00007a3fbe1d210c  call rax
00007a3fbe1d210e  movaps xmm13, [rsp]
00007a3fbe1d2113  add rsp, 0x30
00007a3fbe1d2117  vmovaps xmm0, [rsp]
00007a3fbe1d211c  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d2122  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d2128  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d212e  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d2134  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d213a  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d2140  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d2146  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d214f  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d2158  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d2161  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d216a  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d2173  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d217c  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d2185  add rsp, 0xF0
00007a3fbe1d218c  pop r11
00007a3fbe1d218e  pop r10
00007a3fbe1d2190  pop r9
00007a3fbe1d2192  pop r8
00007a3fbe1d2194  pop rsi
00007a3fbe1d2195  pop rdi
00007a3fbe1d2196  pop rdx
00007a3fbe1d2197  pop rcx
00007a3fbe1d2198  pop rax
00007a3fbe1d2199  add rsp, 0x08
00007a3fbe1d219d  jmp 0x00007A3FBE1D1F81
00007a3fbe1d21a2  call 0x00007A3FBE0C2240
00007a3fbe1d21a7  jmp 0x00007A3FBE1D1F9B
00007a3fbe1d21ac  sub rsp, 0x08
00007a3fbe1d21b0  push rax
00007a3fbe1d21b1  push rcx
00007a3fbe1d21b2  push rdx
00007a3fbe1d21b3  push rdi
00007a3fbe1d21b4  push rsi
00007a3fbe1d21b5  push r8
00007a3fbe1d21b7  push r9
00007a3fbe1d21b9  push r10
00007a3fbe1d21bb  push r11
00007a3fbe1d21bd  sub rsp, 0xF0
00007a3fbe1d21c4  vmovaps [rsp], xmm0
00007a3fbe1d21c9  vmovaps [rsp+0x10], xmm1
00007a3fbe1d21cf  vmovaps [rsp+0x20], xmm2
00007a3fbe1d21d5  vmovaps [rsp+0x30], xmm3
00007a3fbe1d21db  vmovaps [rsp+0x40], xmm4
00007a3fbe1d21e1  vmovaps [rsp+0x50], xmm5
00007a3fbe1d21e7  vmovaps [rsp+0x60], xmm6
00007a3fbe1d21ed  vmovaps [rsp+0x70], xmm7
00007a3fbe1d21f3  vmovaps [rsp+0x80], xmm8
00007a3fbe1d21fc  vmovaps [rsp+0x90], xmm9
00007a3fbe1d2205  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d220e  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d2217  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d2220  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d2229  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d2232  sub rsp, 0x30
00007a3fbe1d2236  movaps [rsp], xmm14
00007a3fbe1d223b  movaps [rsp+0x10], xmm1
00007a3fbe1d2240  movaps [rsp+0x20], xmm15
00007a3fbe1d2246  lea rdi, [rsp]
00007a3fbe1d224a  mov esi, 0x00
00007a3fbe1d224f  mov rax, 0x60D1084DB530
00007a3fbe1d2259  call rax
00007a3fbe1d225b  movaps xmm14, [rsp]
00007a3fbe1d2260  add rsp, 0x30
00007a3fbe1d2264  vmovaps xmm0, [rsp]
00007a3fbe1d2269  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d226f  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d2275  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d227b  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d2281  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d2287  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d228d  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d2293  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d229c  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d22a5  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d22ae  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d22b7  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d22c0  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d22c9  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d22d2  add rsp, 0xF0
00007a3fbe1d22d9  pop r11
00007a3fbe1d22db  pop r10
00007a3fbe1d22dd  pop r9
00007a3fbe1d22df  pop r8
00007a3fbe1d22e1  pop rsi
00007a3fbe1d22e2  pop rdi
00007a3fbe1d22e3  pop rdx
00007a3fbe1d22e4  pop rcx
00007a3fbe1d22e5  pop rax
00007a3fbe1d22e6  add rsp, 0x08
00007a3fbe1d22ea  jmp 0x00007A3FBE1D1FBE
00007a3fbe1d22ef  call 0x00007A3FBE0C34C0
00007a3fbe1d22f4  jmp 0x00007A3FBE1D1FD4
00007a3fbe1d22f9  int3
00007a3fbe1d22fa  nop [rax+rax*1], ax
00007a3fbe1d2300  mov rax, [r15+0x50]
00007a3fbe1d2304  lea r14, [rax+0x80]
00007a3fbe1d230b  movups xmm1, [r13+r14*1]
00007a3fbe1d2311  lea r14, [rax+0x90]
00007a3fbe1d2318  movups xmm15, [r13+r14*1]
00007a3fbe1d231e  vxorps xmm14, xmm14, xmm14
00007a3fbe1d2323  vpbroadcastq xmm14, xmm14
00007a3fbe1d2328  lea r14, [rax+0x40]
00007a3fbe1d232c  movups xmm13, [r13+r14*1]
00007a3fbe1d2332  lea r14, [rax+0x50]
00007a3fbe1d2336  movups xmm12, [r13+r14*1]
00007a3fbe1d233c  mov qword ptr [r15+0x48], 0x00
00007a3fbe1d2344  movups xmm11, [r13+rax*1]
00007a3fbe1d234a  lea r14, [rax+0x10]
00007a3fbe1d234e  movups xmm10, [r13+r14*1]
00007a3fbe1d2354  mov r14, [r15+0xF8]
00007a3fbe1d235b  lea r12, [r14+0xE0]
00007a3fbe1d2362  movups [r13+r12*1], xmm15
00007a3fbe1d2368  lea r12, [r14+0xF0]
00007a3fbe1d236f  movups [r13+r12*1], xmm1
00007a3fbe1d2375  lea r12, [rax+0xC0]
00007a3fbe1d237c  movups xmm1, [r13+r12*1]
00007a3fbe1d2382  lea r12, [rax+0xD0]
00007a3fbe1d2389  movups xmm15, [r13+r12*1]
00007a3fbe1d238f  lea r12, [rax+0x140]
00007a3fbe1d2396  movups xmm9, [r13+r12*1]
00007a3fbe1d239c  lea r12, [rax+0x150]
00007a3fbe1d23a3  movups xmm8, [r13+r12*1]
00007a3fbe1d23a9  lea r12, [rax+0x180]
00007a3fbe1d23b0  movups xmm7, [r13+r12*1]
00007a3fbe1d23b6  lea r12, [rax+0x190]
00007a3fbe1d23bd  movups xmm6, [r13+r12*1]
00007a3fbe1d23c3  lea r12, [r14+0xC0]
00007a3fbe1d23ca  movups [r13+r12*1], xmm15
00007a3fbe1d23d0  lea r12, [r14+0xD0]
00007a3fbe1d23d7  movups [r13+r12*1], xmm1
00007a3fbe1d23dd  lea r12, [rax+0x100]
00007a3fbe1d23e4  movups xmm1, [r13+r12*1]
00007a3fbe1d23ea  lea r12, [rax+0x110]
00007a3fbe1d23f1  movups xmm15, [r13+r12*1]
00007a3fbe1d23f7  lea r12, [rax+0x1C0]
00007a3fbe1d23fe  movups xmm5, [r13+r12*1]
00007a3fbe1d2404  lea r12, [rax+0x1D0]
00007a3fbe1d240b  movups xmm4, [r13+r12*1]
00007a3fbe1d2411  lea r12, [rax+0x20]
00007a3fbe1d2415  movups xmm3, [r13+r12*1]
00007a3fbe1d241b  lea r12, [rax+0x30]
00007a3fbe1d241f  movups xmm2, [r13+r12*1]
00007a3fbe1d2425  movaps [r15+0x1F0], xmm2
00007a3fbe1d242d  lea r12, [r14+0x20]
00007a3fbe1d2431  movups [r13+r12*1], xmm1
00007a3fbe1d2437  lea r12, [r14+0x30]
00007a3fbe1d243b  movups [r13+r12*1], xmm12
00007a3fbe1d2441  lea r12, [rax+0x60]
00007a3fbe1d2445  movups xmm1, [r13+r12*1]
00007a3fbe1d244b  lea r12, [rax+0x70]
00007a3fbe1d244f  movups xmm12, [r13+r12*1]
00007a3fbe1d2455  lea r12, [r14+0x60]
00007a3fbe1d2459  movups [r13+r12*1], xmm11
00007a3fbe1d245f  lea r12, [r14+0x70]
00007a3fbe1d2463  movups [r13+r12*1], xmm5
00007a3fbe1d2469  lea r12, [rax+0xE0]
00007a3fbe1d2470  movups xmm11, [r13+r12*1]
00007a3fbe1d2476  lea r12, [rax+0xF0]
00007a3fbe1d247d  movups xmm5, [r13+r12*1]
00007a3fbe1d2483  lea r12, [rax+0x120]
00007a3fbe1d248a  vmovaps [rsp+0x10], xmm1
00007a3fbe1d2490  movups xmm1, [r13+r12*1]
00007a3fbe1d2496  lea r12, [rax+0x130]
00007a3fbe1d249d  vmovaps [rsp+0x20], xmm1
00007a3fbe1d24a3  movups xmm1, [r13+r12*1]
00007a3fbe1d24a9  lea r12, [r14+0xA0]
00007a3fbe1d24b0  movups [r13+r12*1], xmm12
00007a3fbe1d24b6  lea r12, [r14+0xB0]
00007a3fbe1d24bd  vmovaps xmm12, [rsp+0x10]
00007a3fbe1d24c3  movups [r13+r12*1], xmm12
00007a3fbe1d24c9  lea r12, [rax+0xA0]
00007a3fbe1d24d0  movups xmm12, [r13+r12*1]
00007a3fbe1d24d6  lea r12, [rax+0xB0]
00007a3fbe1d24dd  vmovaps [rsp+0x10], xmm1
00007a3fbe1d24e3  movups xmm1, [r13+r12*1]
00007a3fbe1d24e9  lea r12, [rax+0x160]
00007a3fbe1d24f0  vmovaps [rsp+0x30], xmm1
00007a3fbe1d24f6  movups xmm1, [r13+r12*1]
00007a3fbe1d24fc  lea r12, [rax+0x170]
00007a3fbe1d2503  vmovaps [rsp+0x40], xmm1
00007a3fbe1d2509  movups xmm1, [r13+r12*1]
00007a3fbe1d250f  movaps [r15+0x2B0], xmm1
00007a3fbe1d2517  lea r12, [rax+0x1A0]
00007a3fbe1d251e  vmovaps [rsp+0x50], xmm1
00007a3fbe1d2524  movups xmm1, [r13+r12*1]
00007a3fbe1d252a  lea r12, [rax+0x1B0]
00007a3fbe1d2531  vmovaps [rsp+0x60], xmm1
00007a3fbe1d2537  movups xmm1, [r13+r12*1]
00007a3fbe1d253d  vmovaps [rsp+0x70], xmm1
00007a3fbe1d2543  vmovaps xmm1, [rsp+0x60]
00007a3fbe1d2549  movaps [r15+0x290], xmm1
00007a3fbe1d2551  vmovaps [rsp+0x60], xmm1
00007a3fbe1d2557  vmovaps xmm1, [rsp+0x70]
00007a3fbe1d255d  movaps [r15+0x1E0], xmm1
00007a3fbe1d2565  lea r12, [r14+0x80]
00007a3fbe1d256c  vmovaps [rsp+0x70], xmm1
00007a3fbe1d2572  vmovaps xmm1, [rsp+0x30]
00007a3fbe1d2578  movups [r13+r12*1], xmm1
00007a3fbe1d257e  lea r12, [r14+0x90]
00007a3fbe1d2585  movups [r13+r12*1], xmm12
00007a3fbe1d258b  lea r12, [rax+0x1E0]
00007a3fbe1d2592  movups xmm1, [r13+r12*1]
00007a3fbe1d2598  lea r12, [rax+0x1F0]
00007a3fbe1d259f  movups xmm12, [r13+r12*1]
00007a3fbe1d25a5  mov qword ptr [r15+0x50], 0x432200
00007a3fbe1d25ad  lea rax, [r14+0x40]
00007a3fbe1d25b1  vmovaps [rsp+0x30], xmm1
00007a3fbe1d25b7  vmovaps xmm1, [rsp+0x40]
00007a3fbe1d25bd  movups [r13+rax*1], xmm1
00007a3fbe1d25c3  lea rax, [r14+0x50]
00007a3fbe1d25c7  movups [r13+rax*1], xmm10
00007a3fbe1d25cd  movups [r13+r14*1], xmm12
00007a3fbe1d25d3  lea rax, [r14+0x10]
00007a3fbe1d25d7  vmovaps xmm1, [rsp+0x30]
00007a3fbe1d25dd  movups [r13+rax*1], xmm1
00007a3fbe1d25e3  mov rax, [r15+0x40]
00007a3fbe1d25e7  vmovaps [rsp+0x30], xmm3
00007a3fbe1d25ed  vmovaps xmm1, [rsp+0x30]
00007a3fbe1d25f3  por xmm3, xmm1
00007a3fbe1d25f7  vmovaps [rsp+0x30], xmm6
00007a3fbe1d25fd  vmovaps xmm12, [rsp+0x30]
00007a3fbe1d2603  por xmm6, xmm12
00007a3fbe1d2608  lea r12, [rax+0x30]
00007a3fbe1d260c  mov r11, [r13+r12*1]
00007a3fbe1d2611  lea r12, [rax+0x38]
00007a3fbe1d2615  mov r10, [r13+r12*1]
00007a3fbe1d261a  movq xmm12, r11
00007a3fbe1d261f  movq xmm10, r10
00007a3fbe1d2624  movq xmm12, xmm12
00007a3fbe1d2629  vmovaps [rsp+0x30], xmm12
00007a3fbe1d262f  movq xmm12, xmm12
00007a3fbe1d2634  movaps [r15+0x130], xmm12
00007a3fbe1d263c  movq xmm10, xmm10
00007a3fbe1d2641  vmovaps [rsp+0x40], xmm10
00007a3fbe1d2647  movq xmm10, xmm10
00007a3fbe1d264c  movaps [r15+0x280], xmm10
00007a3fbe1d2654  vmovaps [rsp+0x80], xmm9
00007a3fbe1d265d  vmovaps xmm12, [rsp+0x80]
00007a3fbe1d2666  por xmm9, xmm12
00007a3fbe1d266b  lea r12, [rax+0x20]
00007a3fbe1d266f  mov r11, [r13+r12*1]
00007a3fbe1d2674  lea r12, [rax+0x28]
00007a3fbe1d2678  mov r10, [r13+r12*1]
00007a3fbe1d267d  movq xmm12, r11
00007a3fbe1d2682  movq xmm10, r10
00007a3fbe1d2687  movq xmm12, xmm12
00007a3fbe1d268c  vmovaps [rsp+0x80], xmm12
00007a3fbe1d2695  movq xmm12, xmm12
00007a3fbe1d269a  movaps [r15+0x150], xmm12
00007a3fbe1d26a2  movq xmm10, xmm10
00007a3fbe1d26a7  vmovaps [rsp+0x90], xmm10
00007a3fbe1d26b0  movq xmm10, xmm10
00007a3fbe1d26b5  movaps [r15+0x140], xmm10
00007a3fbe1d26bd  lea r12, [rax+0x10]
00007a3fbe1d26c1  mov r11, [r13+r12*1]
00007a3fbe1d26c6  lea r12, [rax+0x18]
00007a3fbe1d26ca  mov r10, [r13+r12*1]
00007a3fbe1d26cf  movq xmm12, r11
00007a3fbe1d26d4  movq xmm10, r10
00007a3fbe1d26d9  movq xmm12, xmm12
00007a3fbe1d26de  vmovaps [rsp+0xA0], xmm12
00007a3fbe1d26e7  movq xmm12, xmm12
00007a3fbe1d26ec  movaps [r15+0x170], xmm12
00007a3fbe1d26f4  movq xmm10, xmm10
00007a3fbe1d26f9  vmovaps [rsp+0xB0], xmm10
00007a3fbe1d2702  movq xmm10, xmm10
00007a3fbe1d2707  movaps [r15+0x160], xmm10
00007a3fbe1d270f  mov r12, [r13+rax*1]
00007a3fbe1d2714  vmovq xmm12, r12
00007a3fbe1d2719  vpbroadcastq xmm12, xmm12
00007a3fbe1d271e  lea r12, [rax+0x08]
00007a3fbe1d2722  mov rax, [r13+r12*1]
00007a3fbe1d2727  movq xmm10, rax
00007a3fbe1d272c  movaps [r15+0x230], xmm10
00007a3fbe1d2734  lea rax, [r14+0x50]
00007a3fbe1d2738  movups xmm10, [r13+rax*1]
00007a3fbe1d273e  lea rax, [r14+0x60]
00007a3fbe1d2742  vmovaps [rsp+0xC0], xmm1
00007a3fbe1d274b  movups xmm1, [r13+rax*1]
00007a3fbe1d2751  lea rax, [r14+0x30]
00007a3fbe1d2755  vmovaps [rsp+0xD0], xmm1
00007a3fbe1d275e  movups xmm1, [r13+rax*1]
00007a3fbe1d2764  mov qword ptr [r15+0x60], 0x432200
00007a3fbe1d276c  mov qword ptr [r15+0x58], 0x40
00007a3fbe1d2774  vmovaps [rsp+0xE0], xmm1
00007a3fbe1d277d  vmovaps [rsp+0xF0], xmm15
00007a3fbe1d2786  vmovaps xmm15, [rsp+0xC0]
00007a3fbe1d278f  vmovaps [rsp+0xC0], xmm14
00007a3fbe1d2798  movaps xmm1, xmm12
00007a3fbe1d279c  mulpd xmm1, xmm15
00007a3fbe1d27a1  vcmppd xmm14, xmm1, xmm1, 0x03
00007a3fbe1d27a6  ptest xmm14, xmm14
00007a3fbe1d27ac  jnz 0x00007A3FBE1D3863
00007a3fbe1d27b2  movq xmm15, qword ptr [r15+0x230]
00007a3fbe1d27bb  vmovaps [rsp+0x100], xmm15
00007a3fbe1d27c4  vpermilpd xmm15, xmm15, 0x00
00007a3fbe1d27ca  vmovaps [rsp+0x110], xmm1
00007a3fbe1d27d3  vmovaps xmm1, [rsp+0xE0]
00007a3fbe1d27dc  vmovaps [rsp+0xE0], xmm13
00007a3fbe1d27e5  movaps xmm14, xmm1
00007a3fbe1d27e9  mulpd xmm14, xmm15
00007a3fbe1d27ee  vcmppd xmm13, xmm14, xmm14, 0x03
00007a3fbe1d27f4  ptest xmm13, xmm13
00007a3fbe1d27fa  jnz 0x00007A3FBE1D39A5
00007a3fbe1d2800  vxorps xmm1, xmm1, xmm1
00007a3fbe1d2804  vpbroadcastq xmm1, xmm1
00007a3fbe1d2809  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d2812  vmovaps [rsp+0xD0], xmm1
00007a3fbe1d281b  movaps xmm15, xmm12
00007a3fbe1d281f  mulpd xmm15, xmm13
00007a3fbe1d2824  vcmppd xmm1, xmm15, xmm15, 0x03
00007a3fbe1d282a  ptest xmm1, xmm1
00007a3fbe1d282f  jnz 0x00007A3FBE1D3AE8
00007a3fbe1d2835  movaps xmm1, xmm12
00007a3fbe1d2839  mulpd xmm1, xmm10
00007a3fbe1d283e  vcmppd xmm13, xmm1, xmm1, 0x03
00007a3fbe1d2843  ptest xmm13, xmm13
00007a3fbe1d2849  jnz 0x00007A3FBE1D3C2C
00007a3fbe1d284f  movaps xmm13, xmm12
00007a3fbe1d2853  mulpd xmm13, xmm2
00007a3fbe1d2858  vcmppd xmm10, xmm13, xmm13, 0x03
00007a3fbe1d285e  ptest xmm10, xmm10
00007a3fbe1d2864  jnz 0x00007A3FBE1D3D6E
00007a3fbe1d286a  vmovaps [rsp+0x120], xmm7
00007a3fbe1d2873  vmovaps xmm12, [rsp+0x120]
00007a3fbe1d287c  por xmm7, xmm12
00007a3fbe1d2881  vmovaps xmm12, [rsp+0xE0]
00007a3fbe1d288a  vmovaps xmm10, [rsp+0xE0]
00007a3fbe1d2893  por xmm12, xmm10
00007a3fbe1d2898  vmovaps xmm2, [rsp+0x100]
00007a3fbe1d28a1  vpermilpd xmm2, xmm2, 0x00
00007a3fbe1d28a7  vmovaps [rsp+0xE0], xmm1
00007a3fbe1d28b0  vmovaps [rsp+0x120], xmm15
00007a3fbe1d28b9  movaps xmm1, xmm10
00007a3fbe1d28bd  mulpd xmm1, xmm2
00007a3fbe1d28c1  vcmppd xmm15, xmm1, xmm1, 0x03
00007a3fbe1d28c6  ptest xmm15, xmm15
00007a3fbe1d28cc  jnz 0x00007A3FBE1D3EB1
00007a3fbe1d28d2  xor eax, eax
00007a3fbe1d28d4  mov r12d, 0x40
00007a3fbe1d28da  mov r11d, 0x200
00007a3fbe1d28e0  cmp r12, r11
00007a3fbe1d28e3  cmc
00007a3fbe1d28e4  lahf
00007a3fbe1d28e5  seto al
00007a3fbe1d28e8  mov [r15+0x108], eax
00007a3fbe1d28ef  vmovaps xmm10, [rsp+0x110]
00007a3fbe1d28f8  vmovaps xmm2, [rsp+0xD0]
00007a3fbe1d2901  vmovaps [rsp+0xD0], xmm1
00007a3fbe1d290a  movaps xmm15, xmm10
00007a3fbe1d290e  addpd xmm15, xmm2
00007a3fbe1d2913  vcmppd xmm1, xmm15, xmm15, 0x03
00007a3fbe1d2919  ptest xmm1, xmm1
00007a3fbe1d291e  jnz 0x00007A3FBE1D3FF2
00007a3fbe1d2924  vmovaps xmm10, [rsp+0x120]
00007a3fbe1d292d  vmovaps [rsp+0x110], xmm15
00007a3fbe1d2936  vmovaps xmm15, [rsp+0xC0]
00007a3fbe1d293f  vmovaps [rsp+0xC0], xmm14
00007a3fbe1d2948  movaps xmm1, xmm10
00007a3fbe1d294c  addpd xmm1, xmm15
00007a3fbe1d2951  vcmppd xmm14, xmm1, xmm1, 0x03
00007a3fbe1d2956  ptest xmm14, xmm14
00007a3fbe1d295c  jnz 0x00007A3FBE1D4135
00007a3fbe1d2962  vmovaps xmm10, [rsp+0xE0]
00007a3fbe1d296b  vmovaps [rsp+0xE0], xmm1
00007a3fbe1d2974  movaps xmm14, xmm10
00007a3fbe1d2978  addpd xmm14, xmm15
00007a3fbe1d297d  vcmppd xmm1, xmm14, xmm14, 0x03
00007a3fbe1d2983  ptest xmm1, xmm1
00007a3fbe1d2988  jnz 0x00007A3FBE1D4277
00007a3fbe1d298e  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d2994  vmovaps xmm15, [rsp+0x10]
00007a3fbe1d299a  por xmm1, xmm15
00007a3fbe1d299f  vmovaps xmm15, [rsp+0x20]
00007a3fbe1d29a5  vmovaps xmm10, [rsp+0x20]
00007a3fbe1d29ab  por xmm15, xmm10
00007a3fbe1d29b0  vmovaps [rsp+0x10], xmm5
00007a3fbe1d29b6  vmovaps xmm10, [rsp+0x10]
00007a3fbe1d29bc  por xmm5, xmm10
00007a3fbe1d29c1  vmovaps [rsp+0x10], xmm11
00007a3fbe1d29c7  vmovaps xmm10, [rsp+0x10]
00007a3fbe1d29cd  por xmm11, xmm10
00007a3fbe1d29d2  vmovaps [rsp+0x10], xmm4
00007a3fbe1d29d8  vmovaps xmm10, [rsp+0x10]
00007a3fbe1d29de  por xmm4, xmm10
00007a3fbe1d29e3  vmovaps [rsp+0x10], xmm8
00007a3fbe1d29e9  vmovaps xmm10, [rsp+0x10]
00007a3fbe1d29ef  por xmm8, xmm10
00007a3fbe1d29f4  vmovaps xmm10, [rsp+0xF0]
00007a3fbe1d29fd  vmovaps [rsp+0x10], xmm1
00007a3fbe1d2a03  vmovaps xmm1, [rsp+0xF0]
00007a3fbe1d2a0c  por xmm10, xmm1
00007a3fbe1d2a11  lea rax, [r14+0xA0]
00007a3fbe1d2a18  movups xmm1, [r13+rax*1]
00007a3fbe1d2a1e  lea rax, [r14+0xB0]
00007a3fbe1d2a25  vmovaps [rsp+0x20], xmm1
00007a3fbe1d2a2b  movups xmm1, [r13+rax*1]
00007a3fbe1d2a31  vmovaps [rsp+0xF0], xmm1
00007a3fbe1d2a3a  vmovaps [rsp+0x120], xmm15
00007a3fbe1d2a43  movaps xmm1, xmm13
00007a3fbe1d2a47  addpd xmm1, xmm2
00007a3fbe1d2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
00007a3fbe1d2a50  ptest xmm15, xmm15
00007a3fbe1d2a56  jnz 0x00007A3FBE1D43CF
00007a3fbe1d2a5c  lea rax, [r14+0xF0]
00007a3fbe1d2a63  movups xmm15, [r13+rax*1]
00007a3fbe1d2a69  vmovaps xmm2, [rsp+0xE0]
00007a3fbe1d2a72  vmovaps [rsp+0xE0], xmm1
00007a3fbe1d2a7b  vmovaps xmm1, [rsp+0xD0]
00007a3fbe1d2a84  vmovaps [rsp+0xD0], xmm15
00007a3fbe1d2a8d  movaps xmm13, xmm2
00007a3fbe1d2a91  addpd xmm13, xmm1
00007a3fbe1d2a96  vcmppd xmm15, xmm13, xmm13, 0x03
00007a3fbe1d2a9c  ptest xmm15, xmm15
00007a3fbe1d2aa2  jnz 0x00007A3FBE1D451A
00007a3fbe1d2aa8  vmovaps xmm15, [rsp+0xC0]
00007a3fbe1d2ab1  movaps xmm1, xmm14
00007a3fbe1d2ab5  addpd xmm1, xmm15
00007a3fbe1d2aba  vcmppd xmm2, xmm1, xmm1, 0x03
00007a3fbe1d2abf  ptest xmm2, xmm2
00007a3fbe1d2ac4  jnz 0x00007A3FBE1D465C
00007a3fbe1d2aca  vmovaps xmm15, [rsp+0x100]
00007a3fbe1d2ad3  vpermilpd xmm15, xmm15, 0x00
00007a3fbe1d2ad9  vmovaps xmm2, [rsp+0xF0]
00007a3fbe1d2ae2  vmovaps [rsp+0xC0], xmm1
00007a3fbe1d2aeb  movaps xmm14, xmm2
00007a3fbe1d2aef  mulpd xmm14, xmm15
00007a3fbe1d2af4  vcmppd xmm1, xmm14, xmm14, 0x03
00007a3fbe1d2afa  ptest xmm1, xmm1
00007a3fbe1d2aff  jnz 0x00007A3FBE1D479E
00007a3fbe1d2b05  vmovaps xmm1, [rsp+0xA0]
00007a3fbe1d2b0e  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1d2b14  vmovaps xmm2, [rsp+0xD0]
00007a3fbe1d2b1d  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d2b26  movaps xmm15, xmm2
00007a3fbe1d2b2a  mulpd xmm15, xmm1
00007a3fbe1d2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
00007a3fbe1d2b35  ptest xmm14, xmm14
00007a3fbe1d2b3b  jnz 0x00007A3FBE1D48E1
00007a3fbe1d2b41  lea rax, [r14+0xE0]
00007a3fbe1d2b48  movups xmm1, [r13+rax*1]
00007a3fbe1d2b4e  vmovaps xmm14, [rsp+0x100]
00007a3fbe1d2b57  vpermilpd xmm14, xmm14, 0x00
00007a3fbe1d2b5d  vmovaps [rsp+0xF0], xmm1
00007a3fbe1d2b66  vmovaps xmm1, [rsp+0x20]
00007a3fbe1d2b6c  vmovaps [rsp+0x20], xmm15
00007a3fbe1d2b72  movaps xmm2, xmm1
00007a3fbe1d2b75  mulpd xmm2, xmm14
00007a3fbe1d2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
00007a3fbe1d2b7f  ptest xmm15, xmm15
00007a3fbe1d2b85  jnz 0x00007A3FBE1D4A2D
00007a3fbe1d2b8b  vmovaps [rsp+0x100], xmm10
00007a3fbe1d2b94  vmovaps xmm1, [rsp+0x100]
00007a3fbe1d2b9d  por xmm10, xmm1
00007a3fbe1d2ba2  movaps [r15+0x300], xmm10
00007a3fbe1d2baa  vmovaps [rsp+0x100], xmm8
00007a3fbe1d2bb3  vmovaps xmm1, [rsp+0x100]
00007a3fbe1d2bbc  por xmm8, xmm1
00007a3fbe1d2bc1  movaps [r15+0x190], xmm8
00007a3fbe1d2bc9  vmovaps xmm1, [rsp+0xA0]
00007a3fbe1d2bd2  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1d2bd8  vmovaps xmm14, [rsp+0xF0]
00007a3fbe1d2be1  vmovaps [rsp+0xF0], xmm13
00007a3fbe1d2bea  movaps xmm15, xmm14
00007a3fbe1d2bee  mulpd xmm15, xmm1
00007a3fbe1d2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
00007a3fbe1d2bf9  ptest xmm13, xmm13
00007a3fbe1d2bff  jnz 0x00007A3FBE1D4B6E
00007a3fbe1d2c05  lea rax, [r14+0x90]
00007a3fbe1d2c0c  movups xmm1, [r13+rax*1]
00007a3fbe1d2c12  vmovaps [rsp+0x100], xmm4
00007a3fbe1d2c1b  vmovaps xmm14, [rsp+0x100]
00007a3fbe1d2c24  por xmm4, xmm14
00007a3fbe1d2c29  movaps [r15+0x1C0], xmm4
00007a3fbe1d2c31  vmovaps [rsp+0x100], xmm11
00007a3fbe1d2c3a  vmovaps xmm14, [rsp+0x100]
00007a3fbe1d2c43  por xmm11, xmm14
00007a3fbe1d2c48  movaps [r15+0x200], xmm11
00007a3fbe1d2c50  vmovaps [rsp+0x100], xmm5
00007a3fbe1d2c59  vmovaps xmm14, [rsp+0x100]
00007a3fbe1d2c62  por xmm5, xmm14
00007a3fbe1d2c67  movaps [r15+0x2D0], xmm5
00007a3fbe1d2c6f  vmovaps xmm14, [rsp+0x120]
00007a3fbe1d2c78  vmovaps xmm13, [rsp+0x120]
00007a3fbe1d2c81  por xmm14, xmm13
00007a3fbe1d2c86  movaps [r15+0x2E0], xmm14
00007a3fbe1d2c8e  vmovaps [rsp+0x100], xmm1
00007a3fbe1d2c97  vmovaps xmm1, [rsp+0x110]
00007a3fbe1d2ca0  vmovaps [rsp+0x110], xmm15
00007a3fbe1d2ca9  vmovaps xmm15, [rsp+0xD0]
00007a3fbe1d2cb2  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d2cbb  movaps xmm13, xmm1
00007a3fbe1d2cbf  addpd xmm13, xmm15
00007a3fbe1d2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
00007a3fbe1d2cca  ptest xmm14, xmm14
00007a3fbe1d2cd0  jnz 0x00007A3FBE1D4CBB
00007a3fbe1d2cd6  vmovaps xmm1, [rsp+0xA0]
00007a3fbe1d2cdf  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1d2ce5  vmovaps xmm14, [rsp+0x100]
00007a3fbe1d2cee  vmovaps [rsp+0x100], xmm13
00007a3fbe1d2cf7  movaps xmm15, xmm14
00007a3fbe1d2cfb  mulpd xmm15, xmm1
00007a3fbe1d2d00  vcmppd xmm13, xmm15, xmm15, 0x03
00007a3fbe1d2d06  ptest xmm13, xmm13
00007a3fbe1d2d0c  jnz 0x00007A3FBE1D4DFE
00007a3fbe1d2d12  lea rax, [r14+0x80]
00007a3fbe1d2d19  movups xmm1, [r13+rax*1]
00007a3fbe1d2d1f  vmovaps xmm13, [rsp+0xE0]
00007a3fbe1d2d28  vmovaps [rsp+0xE0], xmm1
00007a3fbe1d2d31  movaps xmm14, xmm13
00007a3fbe1d2d35  addpd xmm14, xmm2
00007a3fbe1d2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
00007a3fbe1d2d40  ptest xmm1, xmm1
00007a3fbe1d2d45  jnz 0x00007A3FBE1D4F4B
00007a3fbe1d2d4b  vmovaps xmm13, [rsp+0xF0]
00007a3fbe1d2d54  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d2d5a  vmovaps [rsp+0x20], xmm15
00007a3fbe1d2d60  movaps xmm1, xmm13
00007a3fbe1d2d64  addpd xmm1, xmm2
00007a3fbe1d2d68  vcmppd xmm15, xmm1, xmm1, 0x03
00007a3fbe1d2d6d  ptest xmm15, xmm15
00007a3fbe1d2d73  jnz 0x00007A3FBE1D508E
00007a3fbe1d2d79  vmovaps xmm15, [rsp+0x10]
00007a3fbe1d2d7f  vmovaps xmm13, [rsp+0x10]
00007a3fbe1d2d85  por xmm15, xmm13
00007a3fbe1d2d8a  movaps [r15+0x2F0], xmm15
00007a3fbe1d2d92  vmovaps xmm13, [rsp+0xA0]
00007a3fbe1d2d9b  vpermilpd xmm13, xmm13, 0x00
00007a3fbe1d2da1  vmovaps [rsp+0x10], xmm1
00007a3fbe1d2da7  vmovaps xmm1, [rsp+0xE0]
00007a3fbe1d2db0  vmovaps [rsp+0xA0], xmm15
00007a3fbe1d2db9  movaps xmm2, xmm1
00007a3fbe1d2dbc  mulpd xmm2, xmm13
00007a3fbe1d2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
00007a3fbe1d2dc6  ptest xmm15, xmm15
00007a3fbe1d2dcc  jnz 0x00007A3FBE1D51CF
00007a3fbe1d2dd2  lea rax, [r14+0xD0]
00007a3fbe1d2dd9  movups xmm1, [r13+rax*1]
00007a3fbe1d2ddf  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d2de8  vmovaps [rsp+0xC0], xmm1
00007a3fbe1d2df1  vmovaps xmm1, [rsp+0x110]
00007a3fbe1d2dfa  vmovaps [rsp+0xE0], xmm14
00007a3fbe1d2e03  movaps xmm15, xmm13
00007a3fbe1d2e07  addpd xmm15, xmm1
00007a3fbe1d2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
00007a3fbe1d2e12  ptest xmm14, xmm14
00007a3fbe1d2e18  jnz 0x00007A3FBE1D531A
00007a3fbe1d2e1e  vmovaps xmm1, [rsp+0xB0]
00007a3fbe1d2e27  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1d2e2d  movaps xmm14, xmm11
00007a3fbe1d2e31  mulpd xmm14, xmm1
00007a3fbe1d2e36  vcmppd xmm13, xmm14, xmm14, 0x03
00007a3fbe1d2e3c  ptest xmm13, xmm13
00007a3fbe1d2e42  jnz 0x00007A3FBE1D545D
00007a3fbe1d2e48  movaps [r15+0x260], xmm14
00007a3fbe1d2e50  vxorps xmm1, xmm1, xmm1
00007a3fbe1d2e54  vpbroadcastq xmm1, xmm1
00007a3fbe1d2e59  movaps [r15+0x1B0], xmm1
00007a3fbe1d2e61  vmovaps xmm1, [rsp+0xB0]
00007a3fbe1d2e6a  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1d2e70  vmovaps xmm11, [rsp+0xC0]
00007a3fbe1d2e79  vmovaps [rsp+0xC0], xmm15
00007a3fbe1d2e82  movaps xmm13, xmm11
00007a3fbe1d2e86  mulpd xmm13, xmm1
00007a3fbe1d2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
00007a3fbe1d2e91  ptest xmm15, xmm15
00007a3fbe1d2e97  jnz 0x00007A3FBE1D55A0
00007a3fbe1d2e9d  lea rax, [r14+0xC0]
00007a3fbe1d2ea4  movups xmm1, [r13+rax*1]
00007a3fbe1d2eaa  vmovaps xmm11, [rsp+0x100]
00007a3fbe1d2eb3  vmovaps [rsp+0xF0], xmm1
00007a3fbe1d2ebc  vmovaps xmm1, [rsp+0x20]
00007a3fbe1d2ec2  vmovaps [rsp+0x20], xmm14
00007a3fbe1d2ec8  movaps xmm15, xmm11
00007a3fbe1d2ecc  addpd xmm15, xmm1
00007a3fbe1d2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
00007a3fbe1d2ed7  ptest xmm14, xmm14
00007a3fbe1d2edd  jnz 0x00007A3FBE1D56ED
00007a3fbe1d2ee3  vmovaps [rsp+0x100], xmm9
00007a3fbe1d2eec  vmovaps xmm1, [rsp+0x100]
00007a3fbe1d2ef5  por xmm9, xmm1
00007a3fbe1d2efa  movaps [r15+0x270], xmm9
00007a3fbe1d2f02  vmovaps [rsp+0x100], xmm6
00007a3fbe1d2f0b  vmovaps xmm1, [rsp+0x100]
00007a3fbe1d2f14  por xmm6, xmm1
00007a3fbe1d2f18  movaps [r15+0x1A0], xmm6
00007a3fbe1d2f20  vmovaps xmm14, [rsp+0xB0]
00007a3fbe1d2f29  vpermilpd xmm14, xmm14, 0x00
00007a3fbe1d2f2f  vmovaps xmm6, [rsp+0xF0]
00007a3fbe1d2f38  vmovaps [rsp+0xF0], xmm1
00007a3fbe1d2f41  movaps xmm11, xmm6
00007a3fbe1d2f45  mulpd xmm11, xmm14
00007a3fbe1d2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
00007a3fbe1d2f50  ptest xmm1, xmm1
00007a3fbe1d2f55  jnz 0x00007A3FBE1D5830
00007a3fbe1d2f5b  lea rax, [r14+0x20]
00007a3fbe1d2f5f  movups xmm1, [r13+rax*1]
00007a3fbe1d2f65  movaps [r15+0x110], xmm1
00007a3fbe1d2f6d  vmovaps xmm6, [rsp+0xE0]
00007a3fbe1d2f76  vmovaps [rsp+0xE0], xmm1
00007a3fbe1d2f7f  movaps xmm14, xmm6
00007a3fbe1d2f83  addpd xmm14, xmm2
00007a3fbe1d2f88  vcmppd xmm1, xmm14, xmm14, 0x03
00007a3fbe1d2f8e  ptest xmm1, xmm1
00007a3fbe1d2f93  jnz 0x00007A3FBE1D597D
00007a3fbe1d2f99  vmovaps xmm1, [rsp+0xB0]
00007a3fbe1d2fa2  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1d2fa8  movaps xmm6, xmm5
00007a3fbe1d2fab  mulpd xmm6, xmm1
00007a3fbe1d2faf  vcmppd xmm2, xmm6, xmm6, 0x03
00007a3fbe1d2fb4  ptest xmm2, xmm2
00007a3fbe1d2fb9  jnz 0x00007A3FBE1D5ABF
00007a3fbe1d2fbf  vmovaps xmm5, [rsp+0x10]
00007a3fbe1d2fc5  movaps xmm1, xmm5
00007a3fbe1d2fc8  addpd xmm1, xmm13
00007a3fbe1d2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
00007a3fbe1d2fd2  ptest xmm2, xmm2
00007a3fbe1d2fd7  jnz 0x00007A3FBE1D5BFF
00007a3fbe1d2fdd  vmovaps xmm13, [rsp+0x80]
00007a3fbe1d2fe6  vpermilpd xmm13, xmm13, 0x00
00007a3fbe1d2fec  vmovaps xmm2, [rsp+0xE0]
00007a3fbe1d2ff5  vmovaps [rsp+0x10], xmm1
00007a3fbe1d2ffb  movaps xmm5, xmm2
00007a3fbe1d2ffe  mulpd xmm5, xmm13
00007a3fbe1d3003  vcmppd xmm1, xmm5, xmm5, 0x03
00007a3fbe1d3008  ptest xmm1, xmm1
00007a3fbe1d300d  jnz 0x00007A3FBE1D5D40
00007a3fbe1d3013  vmovaps xmm1, [rsp+0x80]
00007a3fbe1d301c  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1d3022  movaps xmm13, xmm10
00007a3fbe1d3026  mulpd xmm13, xmm1
00007a3fbe1d302b  vcmppd xmm2, xmm13, xmm13, 0x03
00007a3fbe1d3031  ptest xmm2, xmm2
00007a3fbe1d3036  jnz 0x00007A3FBE1D5E81
00007a3fbe1d303c  vmovaps xmm10, [rsp+0x20]
00007a3fbe1d3042  movaps xmm1, xmm15
00007a3fbe1d3046  addpd xmm1, xmm10
00007a3fbe1d304b  vcmppd xmm2, xmm1, xmm1, 0x03
00007a3fbe1d3050  ptest xmm2, xmm2
00007a3fbe1d3055  jnz 0x00007A3FBE1D5FC4
00007a3fbe1d305b  vmovaps xmm10, [rsp+0xC0]
00007a3fbe1d3064  movaps xmm15, xmm10
00007a3fbe1d3068  addpd xmm15, xmm11
00007a3fbe1d306d  vcmppd xmm2, xmm15, xmm15, 0x03
00007a3fbe1d3073  ptest xmm2, xmm2
00007a3fbe1d3078  jnz 0x00007A3FBE1D6106
00007a3fbe1d307e  vmovaps xmm11, [rsp+0x80]
00007a3fbe1d3087  vpermilpd xmm11, xmm11, 0x00
00007a3fbe1d308d  vmovaps xmm2, [rsp+0xD0]
00007a3fbe1d3096  vmovaps [rsp+0x20], xmm1
00007a3fbe1d309c  movaps xmm10, xmm2
00007a3fbe1d30a0  mulpd xmm10, xmm11
00007a3fbe1d30a5  vcmppd xmm1, xmm10, xmm10, 0x03
00007a3fbe1d30ab  ptest xmm1, xmm1
00007a3fbe1d30b0  jnz 0x00007A3FBE1D624A
00007a3fbe1d30b6  vmovaps xmm1, [rsp+0x80]
00007a3fbe1d30bf  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1d30c5  vmovaps xmm2, [rsp+0xA0]
00007a3fbe1d30ce  vmovaps [rsp+0x80], xmm15
00007a3fbe1d30d7  movaps xmm11, xmm2
00007a3fbe1d30db  mulpd xmm11, xmm1
00007a3fbe1d30e0  vcmppd xmm15, xmm11, xmm11, 0x03
00007a3fbe1d30e6  ptest xmm15, xmm15
00007a3fbe1d30ec  jnz 0x00007A3FBE1D638D
00007a3fbe1d30f2  movaps xmm1, xmm14
00007a3fbe1d30f6  addpd xmm1, xmm6
00007a3fbe1d30fa  vcmppd xmm15, xmm1, xmm1, 0x03
00007a3fbe1d30ff  ptest xmm15, xmm15
00007a3fbe1d3105  jnz 0x00007A3FBE1D64CF
00007a3fbe1d310b  vmovaps xmm14, [rsp+0x10]
00007a3fbe1d3111  movaps xmm15, xmm14
00007a3fbe1d3115  addpd xmm15, xmm5
00007a3fbe1d311a  vcmppd xmm6, xmm15, xmm15, 0x03
00007a3fbe1d3120  ptest xmm6, xmm6
00007a3fbe1d3125  jnz 0x00007A3FBE1D6610
00007a3fbe1d312b  vmovaps xmm14, [rsp+0x90]
00007a3fbe1d3134  vpermilpd xmm14, xmm14, 0x00
00007a3fbe1d313a  movaps xmm6, xmm9
00007a3fbe1d313e  mulpd xmm6, xmm14
00007a3fbe1d3143  vcmppd xmm5, xmm6, xmm6, 0x03
00007a3fbe1d3148  ptest xmm5, xmm5
00007a3fbe1d314d  jnz 0x00007A3FBE1D6753
00007a3fbe1d3153  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d315c  movaps xmm14, xmm9
00007a3fbe1d3160  addpd xmm14, xmm13
00007a3fbe1d3165  vcmppd xmm5, xmm14, xmm14, 0x03
00007a3fbe1d316b  ptest xmm5, xmm5
00007a3fbe1d3170  jnz 0x00007A3FBE1D6895
00007a3fbe1d3176  vmovaps xmm9, [rsp+0x20]
00007a3fbe1d317c  movaps xmm13, xmm9
00007a3fbe1d3180  addpd xmm13, xmm10
00007a3fbe1d3185  vcmppd xmm5, xmm13, xmm13, 0x03
00007a3fbe1d318b  ptest xmm5, xmm5
00007a3fbe1d3190  jnz 0x00007A3FBE1D69D9
00007a3fbe1d3196  vmovaps [rsp+0x10], xmm12
00007a3fbe1d319c  vmovaps xmm10, [rsp+0x10]
00007a3fbe1d31a2  por xmm12, xmm10
00007a3fbe1d31a7  movaps [r15+0x250], xmm12
00007a3fbe1d31af  vmovaps [rsp+0x10], xmm7
00007a3fbe1d31b5  vmovaps xmm12, [rsp+0x10]
00007a3fbe1d31bb  por xmm7, xmm12
00007a3fbe1d31c0  movaps [r15+0x2A0], xmm7
00007a3fbe1d31c8  vmovaps [rsp+0x10], xmm3
00007a3fbe1d31ce  vmovaps xmm12, [rsp+0x10]
00007a3fbe1d31d4  por xmm3, xmm12
00007a3fbe1d31d9  movaps [r15+0x1D0], xmm3
00007a3fbe1d31e1  lea rax, [r14+0x40]
00007a3fbe1d31e5  movups xmm12, [r13+rax*1]
00007a3fbe1d31eb  movaps [r15+0x2C0], xmm12
00007a3fbe1d31f3  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d31fc  vpermilpd xmm10, xmm10, 0x00
00007a3fbe1d3202  movaps xmm9, xmm8
00007a3fbe1d3206  mulpd xmm9, xmm10
00007a3fbe1d320b  vcmppd xmm5, xmm9, xmm9, 0x03
00007a3fbe1d3211  ptest xmm5, xmm5
00007a3fbe1d3216  jnz 0x00007A3FBE1D6B27
00007a3fbe1d321c  movaps xmm10, xmm1
00007a3fbe1d3220  addpd xmm10, xmm11
00007a3fbe1d3225  vcmppd xmm8, xmm10, xmm10, 0x03
00007a3fbe1d322b  ptest xmm8, xmm8
00007a3fbe1d3231  jnz 0x00007A3FBE1D6C6B
00007a3fbe1d3237  movaps xmm1, xmm15
00007a3fbe1d323b  addpd xmm1, xmm6
00007a3fbe1d323f  vcmppd xmm11, xmm1, xmm1, 0x03
00007a3fbe1d3244  ptest xmm11, xmm11
00007a3fbe1d324a  jnz 0x00007A3FBE1D6DAE
00007a3fbe1d3250  vmovaps xmm15, [rsp+0x90]
00007a3fbe1d3259  vpermilpd xmm15, xmm15, 0x00
00007a3fbe1d325f  movaps xmm11, xmm12
00007a3fbe1d3263  mulpd xmm11, xmm15
00007a3fbe1d3268  vcmppd xmm8, xmm11, xmm11, 0x03
00007a3fbe1d326e  ptest xmm8, xmm8
00007a3fbe1d3274  jnz 0x00007A3FBE1D6EEF
00007a3fbe1d327a  vmovaps xmm15, [rsp+0x90]
00007a3fbe1d3283  vpermilpd xmm15, xmm15, 0x00
00007a3fbe1d3289  vmovaps xmm8, [rsp+0x50]
00007a3fbe1d328f  movaps xmm12, xmm8
00007a3fbe1d3293  mulpd xmm12, xmm15
00007a3fbe1d3298  vcmppd xmm6, xmm12, xmm12, 0x03
00007a3fbe1d329e  ptest xmm6, xmm6
00007a3fbe1d32a3  jnz 0x00007A3FBE1D7033
00007a3fbe1d32a9  vmovaps xmm15, [rsp+0x30]
00007a3fbe1d32af  vpermilpd xmm15, xmm15, 0x00
00007a3fbe1d32b5  movaps xmm8, xmm7
00007a3fbe1d32b9  mulpd xmm8, xmm15
00007a3fbe1d32be  vcmppd xmm6, xmm8, xmm8, 0x03
00007a3fbe1d32c4  ptest xmm6, xmm6
00007a3fbe1d32c9  jnz 0x00007A3FBE1D7177
00007a3fbe1d32cf  movaps xmm15, xmm14
00007a3fbe1d32d3  addpd xmm15, xmm9
00007a3fbe1d32d8  vcmppd xmm7, xmm15, xmm15, 0x03
00007a3fbe1d32de  ptest xmm7, xmm7
00007a3fbe1d32e3  jnz 0x00007A3FBE1D72BA
00007a3fbe1d32e9  vmovaps xmm14, [rsp+0x30]
00007a3fbe1d32ef  vpermilpd xmm14, xmm14, 0x00
00007a3fbe1d32f5  vmovaps xmm7, [rsp+0xF0]
00007a3fbe1d32fe  movaps xmm9, xmm7
00007a3fbe1d3302  mulpd xmm9, xmm14
00007a3fbe1d3307  vcmppd xmm6, xmm9, xmm9, 0x03
00007a3fbe1d330d  ptest xmm6, xmm6
00007a3fbe1d3312  jnz 0x00007A3FBE1D73FE
00007a3fbe1d3318  movaps xmm14, xmm13
00007a3fbe1d331c  addpd xmm14, xmm11
00007a3fbe1d3321  vcmppd xmm7, xmm14, xmm14, 0x03
00007a3fbe1d3327  ptest xmm7, xmm7
00007a3fbe1d332c  jnz 0x00007A3FBE1D7541
00007a3fbe1d3332  vmovaps xmm13, [rsp+0x30]
00007a3fbe1d3338  vpermilpd xmm13, xmm13, 0x00
00007a3fbe1d333e  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d3344  movaps xmm11, xmm7
00007a3fbe1d3348  mulpd xmm11, xmm13
00007a3fbe1d334d  vcmppd xmm6, xmm11, xmm11, 0x03
00007a3fbe1d3353  ptest xmm6, xmm6
00007a3fbe1d3358  jnz 0x00007A3FBE1D7685
00007a3fbe1d335e  movaps xmm13, xmm10
00007a3fbe1d3362  addpd xmm13, xmm12
00007a3fbe1d3367  vcmppd xmm7, xmm13, xmm13, 0x03
00007a3fbe1d336d  ptest xmm7, xmm7
00007a3fbe1d3372  jnz 0x00007A3FBE1D77C8
00007a3fbe1d3378  vmovaps xmm12, [rsp+0x30]
00007a3fbe1d337e  vpermilpd xmm12, xmm12, 0x00
00007a3fbe1d3384  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d338a  movaps xmm10, xmm7
00007a3fbe1d338e  mulpd xmm10, xmm12
00007a3fbe1d3393  vcmppd xmm6, xmm10, xmm10, 0x03
00007a3fbe1d3399  ptest xmm6, xmm6
00007a3fbe1d339e  jnz 0x00007A3FBE1D790C
00007a3fbe1d33a4  movaps xmm12, xmm1
00007a3fbe1d33a8  addpd xmm12, xmm8
00007a3fbe1d33ad  vcmppd xmm7, xmm12, xmm12, 0x03
00007a3fbe1d33b3  ptest xmm7, xmm7
00007a3fbe1d33b8  jnz 0x00007A3FBE1D7A4F
00007a3fbe1d33be  lea rax, [r14+0x70]
00007a3fbe1d33c2  movups xmm1, [r13+rax*1]
00007a3fbe1d33c8  movaps [r15+0x240], xmm1
00007a3fbe1d33d0  movaps xmm8, xmm15
00007a3fbe1d33d4  addpd xmm8, xmm9
00007a3fbe1d33d9  vcmppd xmm7, xmm8, xmm8, 0x03
00007a3fbe1d33df  ptest xmm7, xmm7
00007a3fbe1d33e4  jnz 0x00007A3FBE1D7B9C
00007a3fbe1d33ea  movaps [r15+0x170], xmm8
00007a3fbe1d33f2  vmovaps xmm15, [rsp+0x40]
00007a3fbe1d33f8  vpermilpd xmm15, xmm15, 0x00
00007a3fbe1d33fe  movaps xmm9, xmm1
00007a3fbe1d3402  mulpd xmm9, xmm15
00007a3fbe1d3407  vcmppd xmm7, xmm9, xmm9, 0x03
00007a3fbe1d340d  ptest xmm7, xmm7
00007a3fbe1d3412  jnz 0x00007A3FBE1D7CE0
00007a3fbe1d3418  vmovaps xmm1, [rsp+0x40]
00007a3fbe1d341e  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1d3424  movaps xmm15, xmm4
00007a3fbe1d3428  mulpd xmm15, xmm1
00007a3fbe1d342d  vcmppd xmm7, xmm15, xmm15, 0x03
00007a3fbe1d3433  ptest xmm7, xmm7
00007a3fbe1d3438  jnz 0x00007A3FBE1D7E23
00007a3fbe1d343e  movaps [r15+0x180], xmm15
00007a3fbe1d3446  movaps xmm1, xmm14
00007a3fbe1d344a  addpd xmm1, xmm11
00007a3fbe1d344f  vcmppd xmm7, xmm1, xmm1, 0x03
00007a3fbe1d3454  ptest xmm7, xmm7
00007a3fbe1d3459  jnz 0x00007A3FBE1D7F65
00007a3fbe1d345f  movaps [r15+0x210], xmm1
00007a3fbe1d3467  movups xmm14, [r13+r14*1]
00007a3fbe1d346d  lea rax, [r14+0x10]
00007a3fbe1d3471  movups xmm11, [r13+rax*1]
00007a3fbe1d3477  movaps [r15+0x230], xmm11
00007a3fbe1d347f  movaps xmm7, xmm13
00007a3fbe1d3483  addpd xmm7, xmm10
00007a3fbe1d3488  vcmppd xmm6, xmm7, xmm7, 0x03
00007a3fbe1d348d  ptest xmm6, xmm6
00007a3fbe1d3492  jnz 0x00007A3FBE1D80BB
00007a3fbe1d3498  movaps [r15+0x130], xmm7
00007a3fbe1d34a0  vmovaps xmm13, [rsp+0x40]
00007a3fbe1d34a6  vpermilpd xmm13, xmm13, 0x00
00007a3fbe1d34ac  movaps xmm10, xmm11
00007a3fbe1d34b0  mulpd xmm10, xmm13
00007a3fbe1d34b5  vcmppd xmm6, xmm10, xmm10, 0x03
00007a3fbe1d34bb  ptest xmm6, xmm6
00007a3fbe1d34c0  jnz 0x00007A3FBE1D81FD
00007a3fbe1d34c6  movaps [r15+0x220], xmm10
00007a3fbe1d34ce  vmovaps xmm13, [rsp+0x40]
00007a3fbe1d34d4  vpermilpd xmm13, xmm13, 0x00
00007a3fbe1d34da  movaps xmm11, xmm14
00007a3fbe1d34de  mulpd xmm11, xmm13
00007a3fbe1d34e3  vcmppd xmm6, xmm11, xmm11, 0x03
00007a3fbe1d34e9  ptest xmm6, xmm6
00007a3fbe1d34ee  jnz 0x00007A3FBE1D8341
00007a3fbe1d34f4  movaps xmm14, xmm12
00007a3fbe1d34f8  addpd xmm14, xmm9
00007a3fbe1d34fd  vcmppd xmm13, xmm14, xmm14, 0x03
00007a3fbe1d3503  ptest xmm13, xmm13
00007a3fbe1d3509  jnz 0x00007A3FBE1D8485
00007a3fbe1d350f  movaps [r15+0x140], xmm14
00007a3fbe1d3517  movaps xmm13, xmm8
00007a3fbe1d351b  addpd xmm13, xmm15
00007a3fbe1d3520  vcmppd xmm12, xmm13, xmm13, 0x03
00007a3fbe1d3526  ptest xmm12, xmm12
00007a3fbe1d352c  jnz 0x00007A3FBE1D85C9
00007a3fbe1d3532  movaps [r15+0x150], xmm13
00007a3fbe1d353a  movaps xmm15, xmm1
00007a3fbe1d353e  addpd xmm15, xmm10
00007a3fbe1d3543  vcmppd xmm12, xmm15, xmm15, 0x03
00007a3fbe1d3549  ptest xmm12, xmm12
00007a3fbe1d354f  jnz 0x00007A3FBE1D870D
00007a3fbe1d3555  movaps [r15+0x160], xmm15
00007a3fbe1d355d  movaps xmm1, xmm7
00007a3fbe1d3560  addpd xmm1, xmm11
00007a3fbe1d3565  vcmppd xmm12, xmm1, xmm1, 0x03
00007a3fbe1d356a  ptest xmm12, xmm12
00007a3fbe1d3570  jnz 0x00007A3FBE1D8850
00007a3fbe1d3576  movaps [r15+0x120], xmm1
00007a3fbe1d357e  mov eax, 0x432200
00007a3fbe1d3583  movups [r13+rax*1], xmm14
00007a3fbe1d3589  mov eax, 0x432210
00007a3fbe1d358e  movups [r13+rax*1], xmm13
00007a3fbe1d3594  mov eax, 0x432220
00007a3fbe1d3599  movups [r13+rax*1], xmm15
00007a3fbe1d359f  mov eax, 0x432230
00007a3fbe1d35a4  movups [r13+rax*1], xmm1
00007a3fbe1d35aa  mov eax, [r15+0x108]
00007a3fbe1d35b1  sahf
00007a3fbe1d35b2  jnz 0x00007A3FBE1D35E4
00007a3fbe1d35b4  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d35bc  jz 0x00007A3FBE1DEAE0
00007a3fbe1d35c2  nop [rax+rax*1], ax
00007a3fbe1d35cb  nop [rax+rax*1], eax
00007a3fbe1d35d3  mov eax, 0x4106D0
00007a3fbe1d35d8  mov [r15+0x100], rax
00007a3fbe1d35df  jmp 0x00007A3FBDFFE110
00007a3fbe1d35e4  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d35ec  jz 0x00007A3FBE1D89C0
00007a3fbe1d35f2  nop [rax+rax*1], ax
00007a3fbe1d35fb  nop [rax+rax*1], eax
00007a3fbe1d3603  mov eax, 0x410504
00007a3fbe1d3608  mov [r15+0x100], rax
00007a3fbe1d360f  jmp 0x00007A3FBDFFE110
00007a3fbe1d3614  int3
00007a3fbe1d3615  call 0x00007A3FBE0D64F0
00007a3fbe1d361a  jmp 0x00007A3FBE1D2311
00007a3fbe1d361f  call 0x00007A3FBE0E5820
00007a3fbe1d3624  jmp 0x00007A3FBE1D231E
00007a3fbe1d3629  call 0x00007A3FBE0E3320
00007a3fbe1d362e  jmp 0x00007A3FBE1D2332
00007a3fbe1d3633  call 0x00007A3FBE0E20A0
00007a3fbe1d3638  jmp 0x00007A3FBE1D233C
00007a3fbe1d363d  call 0x00007A3FBE009D70
00007a3fbe1d3642  jmp 0x00007A3FBE1D234A
00007a3fbe1d3647  call 0x00007A3FBE0DFBC0
00007a3fbe1d364c  jmp 0x00007A3FBE1D2354
00007a3fbe1d3651  call 0x00007A3FBE0C4740
00007a3fbe1d3656  jmp 0x00007A3FBE1D2368
00007a3fbe1d365b  call 0x00007A3FBE0B5400
00007a3fbe1d3660  jmp 0x00007A3FBE1D2375
00007a3fbe1d3665  call 0x00007A3FBE0B52F0
00007a3fbe1d366a  jmp 0x00007A3FBE1D2382
00007a3fbe1d366f  call 0x00007A3FBE0C4620
00007a3fbe1d3674  jmp 0x00007A3FBE1D238F
00007a3fbe1d3679  call 0x00007A3FBE0BD750
00007a3fbe1d367e  jmp 0x00007A3FBE1D239C
00007a3fbe1d3683  call 0x00007A3FBE0BC4E0
00007a3fbe1d3688  jmp 0x00007A3FBE1D23A9
00007a3fbe1d368d  call 0x00007A3FBE0BB270
00007a3fbe1d3692  jmp 0x00007A3FBE1D23B6
00007a3fbe1d3697  call 0x00007A3FBE0BA000
00007a3fbe1d369c  jmp 0x00007A3FBE1D23C3
00007a3fbe1d36a1  call 0x00007A3FBE0C4740
00007a3fbe1d36a6  jmp 0x00007A3FBE1D23D0
00007a3fbe1d36ab  call 0x00007A3FBE0B5400
00007a3fbe1d36b0  jmp 0x00007A3FBE1D23DD
00007a3fbe1d36b5  call 0x00007A3FBE0B52F0
00007a3fbe1d36ba  jmp 0x00007A3FBE1D23EA
00007a3fbe1d36bf  call 0x00007A3FBE0C4620
00007a3fbe1d36c4  jmp 0x00007A3FBE1D23F7
00007a3fbe1d36c9  call 0x00007A3FBE0B8D90
00007a3fbe1d36ce  jmp 0x00007A3FBE1D2404
00007a3fbe1d36d3  call 0x00007A3FBE0B8A20
00007a3fbe1d36d8  jmp 0x00007A3FBE1D2411
00007a3fbe1d36dd  call 0x00007A3FBE0B77B0
00007a3fbe1d36e2  jmp 0x00007A3FBE1D241B
00007a3fbe1d36e7  call 0x00007A3FBE0B6550
00007a3fbe1d36ec  jmp 0x00007A3FBE1D2425
00007a3fbe1d36f1  call 0x00007A3FBE0B5400
00007a3fbe1d36f6  jmp 0x00007A3FBE1D2437
00007a3fbe1d36fb  call 0x00007A3FBE0C0FC0
00007a3fbe1d3700  jmp 0x00007A3FBE1D2441
00007a3fbe1d3705  call 0x00007A3FBE0B52F0
00007a3fbe1d370a  jmp 0x00007A3FBE1D244B
00007a3fbe1d370f  call 0x00007A3FBE0C0EA0
00007a3fbe1d3714  jmp 0x00007A3FBE1D2455
00007a3fbe1d3719  call 0x00007A3FBE0BFD50
00007a3fbe1d371e  jmp 0x00007A3FBE1D245F
00007a3fbe1d3723  call 0x00007A3FBE0B8EA0
00007a3fbe1d3728  jmp 0x00007A3FBE1D2469
00007a3fbe1d372d  call 0x00007A3FBE0BFC30
00007a3fbe1d3732  jmp 0x00007A3FBE1D2476
00007a3fbe1d3737  call 0x00007A3FBE0B8D90
00007a3fbe1d373c  jmp 0x00007A3FBE1D2483
00007a3fbe1d3741  call 0x00007A3FBE0B52F0
00007a3fbe1d3746  jmp 0x00007A3FBE1D2496
00007a3fbe1d374b  call 0x00007A3FBE0B52F0
00007a3fbe1d3750  jmp 0x00007A3FBE1D24A9
00007a3fbe1d3755  call 0x00007A3FBE0C0FC0
00007a3fbe1d375a  jmp 0x00007A3FBE1D24B6
00007a3fbe1d375f  call 0x00007A3FBE0C0FC0
00007a3fbe1d3764  jmp 0x00007A3FBE1D24C9
00007a3fbe1d3769  call 0x00007A3FBE0C0EA0
00007a3fbe1d376e  jmp 0x00007A3FBE1D24D6
00007a3fbe1d3773  call 0x00007A3FBE0B52F0
00007a3fbe1d3778  jmp 0x00007A3FBE1D24E9
00007a3fbe1d377d  call 0x00007A3FBE0B52F0
00007a3fbe1d3782  jmp 0x00007A3FBE1D24FC
00007a3fbe1d3787  call 0x00007A3FBE0B52F0
00007a3fbe1d378c  jmp 0x00007A3FBE1D250F
00007a3fbe1d3791  call 0x00007A3FBE0B52F0
00007a3fbe1d3796  jmp 0x00007A3FBE1D252A
00007a3fbe1d379b  call 0x00007A3FBE0B52F0
00007a3fbe1d37a0  jmp 0x00007A3FBE1D253D
00007a3fbe1d37a5  call 0x00007A3FBE0B5400
00007a3fbe1d37aa  jmp 0x00007A3FBE1D257E
00007a3fbe1d37af  call 0x00007A3FBE0C0FC0
00007a3fbe1d37b4  jmp 0x00007A3FBE1D258B
00007a3fbe1d37b9  call 0x00007A3FBE0B52F0
00007a3fbe1d37be  jmp 0x00007A3FBE1D2598
00007a3fbe1d37c3  call 0x00007A3FBE0C0EA0
00007a3fbe1d37c8  jmp 0x00007A3FBE1D25A5
00007a3fbe1d37cd  call 0x00007A3FBDFFF540
00007a3fbe1d37d2  jmp 0x00007A3FBE1D25C3
00007a3fbe1d37d7  call 0x00007A3FBE008C20
00007a3fbe1d37dc  jmp 0x00007A3FBE1D25CD
00007a3fbe1d37e1  call 0x00007A3FBE0E21C0
00007a3fbe1d37e6  jmp 0x00007A3FBE1D25D3
00007a3fbe1d37eb  call 0x00007A3FBDFFF540
00007a3fbe1d37f0  jmp 0x00007A3FBE1D25E3
00007a3fbe1d37f5  call 0x00007A3FBE0C0370
00007a3fbe1d37fa  jmp 0x00007A3FBE1D2611
00007a3fbe1d37ff  call 0x00007A3FBE0BF100
00007a3fbe1d3804  jmp 0x00007A3FBE1D261A
00007a3fbe1d3809  call 0x00007A3FBE0C0370
00007a3fbe1d380e  jmp 0x00007A3FBE1D2674
00007a3fbe1d3813  call 0x00007A3FBE0BF100
00007a3fbe1d3818  jmp 0x00007A3FBE1D267D
00007a3fbe1d381d  call 0x00007A3FBE0C0370
00007a3fbe1d3822  jmp 0x00007A3FBE1D26C6
00007a3fbe1d3827  call 0x00007A3FBE0BF100
00007a3fbe1d382c  jmp 0x00007A3FBE1D26CF
00007a3fbe1d3831  call 0x00007A3FBE00B720
00007a3fbe1d3836  jmp 0x00007A3FBE1D2714
00007a3fbe1d383b  call 0x00007A3FBE0B47C0
00007a3fbe1d3840  jmp 0x00007A3FBE1D2727
00007a3fbe1d3845  call 0x00007A3FBE008B00
00007a3fbe1d384a  jmp 0x00007A3FBE1D273E
00007a3fbe1d384f  call 0x00007A3FBDFFF430
00007a3fbe1d3854  jmp 0x00007A3FBE1D2751
00007a3fbe1d3859  call 0x00007A3FBDFFF430
00007a3fbe1d385e  jmp 0x00007A3FBE1D2764
00007a3fbe1d3863  sub rsp, 0x08
00007a3fbe1d3867  push rax
00007a3fbe1d3868  push rcx
00007a3fbe1d3869  push rdx
00007a3fbe1d386a  push rdi
00007a3fbe1d386b  push rsi
00007a3fbe1d386c  push r8
00007a3fbe1d386e  push r9
00007a3fbe1d3870  push r10
00007a3fbe1d3872  push r11
00007a3fbe1d3874  sub rsp, 0xF0
00007a3fbe1d387b  vmovaps [rsp], xmm0
00007a3fbe1d3880  vmovaps [rsp+0x10], xmm2
00007a3fbe1d3886  vmovaps [rsp+0x20], xmm3
00007a3fbe1d388c  vmovaps [rsp+0x30], xmm4
00007a3fbe1d3892  vmovaps [rsp+0x40], xmm5
00007a3fbe1d3898  vmovaps [rsp+0x50], xmm6
00007a3fbe1d389e  vmovaps [rsp+0x60], xmm7
00007a3fbe1d38a4  vmovaps [rsp+0x70], xmm8
00007a3fbe1d38aa  vmovaps [rsp+0x80], xmm9
00007a3fbe1d38b3  vmovaps [rsp+0x90], xmm10
00007a3fbe1d38bc  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d38c5  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d38ce  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d38d7  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d38e0  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d38e9  sub rsp, 0x30
00007a3fbe1d38ed  movaps [rsp], xmm1
00007a3fbe1d38f1  movaps [rsp+0x10], xmm12
00007a3fbe1d38f7  movaps [rsp+0x20], xmm15
00007a3fbe1d38fd  lea rdi, [rsp]
00007a3fbe1d3901  mov esi, 0x00
00007a3fbe1d3906  mov rax, 0x60D1084DB530
00007a3fbe1d3910  call rax
00007a3fbe1d3912  movaps xmm1, [rsp]
00007a3fbe1d3916  add rsp, 0x30
00007a3fbe1d391a  vmovaps xmm0, [rsp]
00007a3fbe1d391f  vmovaps xmm2, [rsp+0x10]
00007a3fbe1d3925  vmovaps xmm3, [rsp+0x20]
00007a3fbe1d392b  vmovaps xmm4, [rsp+0x30]
00007a3fbe1d3931  vmovaps xmm5, [rsp+0x40]
00007a3fbe1d3937  vmovaps xmm6, [rsp+0x50]
00007a3fbe1d393d  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d3943  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d3949  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d3952  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d395b  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d3964  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d396d  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d3976  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d397f  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d3988  add rsp, 0xF0
00007a3fbe1d398f  pop r11
00007a3fbe1d3991  pop r10
00007a3fbe1d3993  pop r9
00007a3fbe1d3995  pop r8
00007a3fbe1d3997  pop rsi
00007a3fbe1d3998  pop rdi
00007a3fbe1d3999  pop rdx
00007a3fbe1d399a  pop rcx
00007a3fbe1d399b  pop rax
00007a3fbe1d399c  add rsp, 0x08
00007a3fbe1d39a0  jmp 0x00007A3FBE1D27B2
00007a3fbe1d39a5  sub rsp, 0x08
00007a3fbe1d39a9  push rax
00007a3fbe1d39aa  push rcx
00007a3fbe1d39ab  push rdx
00007a3fbe1d39ac  push rdi
00007a3fbe1d39ad  push rsi
00007a3fbe1d39ae  push r8
00007a3fbe1d39b0  push r9
00007a3fbe1d39b2  push r10
00007a3fbe1d39b4  push r11
00007a3fbe1d39b6  sub rsp, 0xF0
00007a3fbe1d39bd  vmovaps [rsp], xmm0
00007a3fbe1d39c2  vmovaps [rsp+0x10], xmm1
00007a3fbe1d39c8  vmovaps [rsp+0x20], xmm2
00007a3fbe1d39ce  vmovaps [rsp+0x30], xmm3
00007a3fbe1d39d4  vmovaps [rsp+0x40], xmm4
00007a3fbe1d39da  vmovaps [rsp+0x50], xmm5
00007a3fbe1d39e0  vmovaps [rsp+0x60], xmm6
00007a3fbe1d39e6  vmovaps [rsp+0x70], xmm7
00007a3fbe1d39ec  vmovaps [rsp+0x80], xmm8
00007a3fbe1d39f5  vmovaps [rsp+0x90], xmm9
00007a3fbe1d39fe  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d3a07  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d3a10  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d3a19  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d3a22  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d3a2b  sub rsp, 0x30
00007a3fbe1d3a2f  movaps [rsp], xmm14
00007a3fbe1d3a34  movaps [rsp+0x10], xmm1
00007a3fbe1d3a39  movaps [rsp+0x20], xmm15
00007a3fbe1d3a3f  lea rdi, [rsp]
00007a3fbe1d3a43  mov esi, 0x00
00007a3fbe1d3a48  mov rax, 0x60D1084DB530
00007a3fbe1d3a52  call rax
00007a3fbe1d3a54  movaps xmm14, [rsp]
00007a3fbe1d3a59  add rsp, 0x30
00007a3fbe1d3a5d  vmovaps xmm0, [rsp]
00007a3fbe1d3a62  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d3a68  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d3a6e  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d3a74  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d3a7a  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d3a80  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d3a86  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d3a8c  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d3a95  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d3a9e  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d3aa7  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d3ab0  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d3ab9  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d3ac2  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d3acb  add rsp, 0xF0
00007a3fbe1d3ad2  pop r11
00007a3fbe1d3ad4  pop r10
00007a3fbe1d3ad6  pop r9
00007a3fbe1d3ad8  pop r8
00007a3fbe1d3ada  pop rsi
00007a3fbe1d3adb  pop rdi
00007a3fbe1d3adc  pop rdx
00007a3fbe1d3add  pop rcx
00007a3fbe1d3ade  pop rax
00007a3fbe1d3adf  add rsp, 0x08
00007a3fbe1d3ae3  jmp 0x00007A3FBE1D2800
00007a3fbe1d3ae8  sub rsp, 0x08
00007a3fbe1d3aec  push rax
00007a3fbe1d3aed  push rcx
00007a3fbe1d3aee  push rdx
00007a3fbe1d3aef  push rdi
00007a3fbe1d3af0  push rsi
00007a3fbe1d3af1  push r8
00007a3fbe1d3af3  push r9
00007a3fbe1d3af5  push r10
00007a3fbe1d3af7  push r11
00007a3fbe1d3af9  sub rsp, 0xF0
00007a3fbe1d3b00  vmovaps [rsp], xmm0
00007a3fbe1d3b05  vmovaps [rsp+0x10], xmm1
00007a3fbe1d3b0b  vmovaps [rsp+0x20], xmm2
00007a3fbe1d3b11  vmovaps [rsp+0x30], xmm3
00007a3fbe1d3b17  vmovaps [rsp+0x40], xmm4
00007a3fbe1d3b1d  vmovaps [rsp+0x50], xmm5
00007a3fbe1d3b23  vmovaps [rsp+0x60], xmm6
00007a3fbe1d3b29  vmovaps [rsp+0x70], xmm7
00007a3fbe1d3b2f  vmovaps [rsp+0x80], xmm8
00007a3fbe1d3b38  vmovaps [rsp+0x90], xmm9
00007a3fbe1d3b41  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d3b4a  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d3b53  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d3b5c  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d3b65  vmovaps [rsp+0xE0], xmm14
00007a3fbe1d3b6e  sub rsp, 0x30
00007a3fbe1d3b72  movaps [rsp], xmm15
00007a3fbe1d3b77  movaps [rsp+0x10], xmm12
00007a3fbe1d3b7d  movaps [rsp+0x20], xmm13
00007a3fbe1d3b83  lea rdi, [rsp]
00007a3fbe1d3b87  mov esi, 0x00
00007a3fbe1d3b8c  mov rax, 0x60D1084DB530
00007a3fbe1d3b96  call rax
00007a3fbe1d3b98  movaps xmm15, [rsp]
00007a3fbe1d3b9d  add rsp, 0x30
00007a3fbe1d3ba1  vmovaps xmm0, [rsp]
00007a3fbe1d3ba6  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d3bac  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d3bb2  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d3bb8  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d3bbe  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d3bc4  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d3bca  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d3bd0  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d3bd9  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d3be2  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d3beb  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d3bf4  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d3bfd  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d3c06  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1d3c0f  add rsp, 0xF0
00007a3fbe1d3c16  pop r11
00007a3fbe1d3c18  pop r10
00007a3fbe1d3c1a  pop r9
00007a3fbe1d3c1c  pop r8
00007a3fbe1d3c1e  pop rsi
00007a3fbe1d3c1f  pop rdi
00007a3fbe1d3c20  pop rdx
00007a3fbe1d3c21  pop rcx
00007a3fbe1d3c22  pop rax
00007a3fbe1d3c23  add rsp, 0x08
00007a3fbe1d3c27  jmp 0x00007A3FBE1D2835
00007a3fbe1d3c2c  sub rsp, 0x08
00007a3fbe1d3c30  push rax
00007a3fbe1d3c31  push rcx
00007a3fbe1d3c32  push rdx
00007a3fbe1d3c33  push rdi
00007a3fbe1d3c34  push rsi
00007a3fbe1d3c35  push r8
00007a3fbe1d3c37  push r9
00007a3fbe1d3c39  push r10
00007a3fbe1d3c3b  push r11
00007a3fbe1d3c3d  sub rsp, 0xF0
00007a3fbe1d3c44  vmovaps [rsp], xmm0
00007a3fbe1d3c49  vmovaps [rsp+0x10], xmm2
00007a3fbe1d3c4f  vmovaps [rsp+0x20], xmm3
00007a3fbe1d3c55  vmovaps [rsp+0x30], xmm4
00007a3fbe1d3c5b  vmovaps [rsp+0x40], xmm5
00007a3fbe1d3c61  vmovaps [rsp+0x50], xmm6
00007a3fbe1d3c67  vmovaps [rsp+0x60], xmm7
00007a3fbe1d3c6d  vmovaps [rsp+0x70], xmm8
00007a3fbe1d3c73  vmovaps [rsp+0x80], xmm9
00007a3fbe1d3c7c  vmovaps [rsp+0x90], xmm10
00007a3fbe1d3c85  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d3c8e  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d3c97  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d3ca0  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d3ca9  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d3cb2  sub rsp, 0x30
00007a3fbe1d3cb6  movaps [rsp], xmm1
00007a3fbe1d3cba  movaps [rsp+0x10], xmm12
00007a3fbe1d3cc0  movaps [rsp+0x20], xmm10
00007a3fbe1d3cc6  lea rdi, [rsp]
00007a3fbe1d3cca  mov esi, 0x00
00007a3fbe1d3ccf  mov rax, 0x60D1084DB530
00007a3fbe1d3cd9  call rax
00007a3fbe1d3cdb  movaps xmm1, [rsp]
00007a3fbe1d3cdf  add rsp, 0x30
00007a3fbe1d3ce3  vmovaps xmm0, [rsp]
00007a3fbe1d3ce8  vmovaps xmm2, [rsp+0x10]
00007a3fbe1d3cee  vmovaps xmm3, [rsp+0x20]
00007a3fbe1d3cf4  vmovaps xmm4, [rsp+0x30]
00007a3fbe1d3cfa  vmovaps xmm5, [rsp+0x40]
00007a3fbe1d3d00  vmovaps xmm6, [rsp+0x50]
00007a3fbe1d3d06  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d3d0c  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d3d12  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d3d1b  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d3d24  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d3d2d  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d3d36  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d3d3f  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d3d48  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d3d51  add rsp, 0xF0
00007a3fbe1d3d58  pop r11
00007a3fbe1d3d5a  pop r10
00007a3fbe1d3d5c  pop r9
00007a3fbe1d3d5e  pop r8
00007a3fbe1d3d60  pop rsi
00007a3fbe1d3d61  pop rdi
00007a3fbe1d3d62  pop rdx
00007a3fbe1d3d63  pop rcx
00007a3fbe1d3d64  pop rax
00007a3fbe1d3d65  add rsp, 0x08
00007a3fbe1d3d69  jmp 0x00007A3FBE1D284F
00007a3fbe1d3d6e  sub rsp, 0x08
00007a3fbe1d3d72  push rax
00007a3fbe1d3d73  push rcx
00007a3fbe1d3d74  push rdx
00007a3fbe1d3d75  push rdi
00007a3fbe1d3d76  push rsi
00007a3fbe1d3d77  push r8
00007a3fbe1d3d79  push r9
00007a3fbe1d3d7b  push r10
00007a3fbe1d3d7d  push r11
00007a3fbe1d3d7f  sub rsp, 0xF0
00007a3fbe1d3d86  vmovaps [rsp], xmm0
00007a3fbe1d3d8b  vmovaps [rsp+0x10], xmm1
00007a3fbe1d3d91  vmovaps [rsp+0x20], xmm2
00007a3fbe1d3d97  vmovaps [rsp+0x30], xmm3
00007a3fbe1d3d9d  vmovaps [rsp+0x40], xmm4
00007a3fbe1d3da3  vmovaps [rsp+0x50], xmm5
00007a3fbe1d3da9  vmovaps [rsp+0x60], xmm6
00007a3fbe1d3daf  vmovaps [rsp+0x70], xmm7
00007a3fbe1d3db5  vmovaps [rsp+0x80], xmm8
00007a3fbe1d3dbe  vmovaps [rsp+0x90], xmm9
00007a3fbe1d3dc7  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d3dd0  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d3dd9  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d3de2  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d3deb  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d3df4  sub rsp, 0x30
00007a3fbe1d3df8  movaps [rsp], xmm13
00007a3fbe1d3dfd  movaps [rsp+0x10], xmm12
00007a3fbe1d3e03  movaps [rsp+0x20], xmm2
00007a3fbe1d3e08  lea rdi, [rsp]
00007a3fbe1d3e0c  mov esi, 0x00
00007a3fbe1d3e11  mov rax, 0x60D1084DB530
00007a3fbe1d3e1b  call rax
00007a3fbe1d3e1d  movaps xmm13, [rsp]
00007a3fbe1d3e22  add rsp, 0x30
00007a3fbe1d3e26  vmovaps xmm0, [rsp]
00007a3fbe1d3e2b  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d3e31  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d3e37  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d3e3d  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d3e43  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d3e49  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d3e4f  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d3e55  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d3e5e  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d3e67  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d3e70  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d3e79  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d3e82  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d3e8b  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d3e94  add rsp, 0xF0
00007a3fbe1d3e9b  pop r11
00007a3fbe1d3e9d  pop r10
00007a3fbe1d3e9f  pop r9
00007a3fbe1d3ea1  pop r8
00007a3fbe1d3ea3  pop rsi
00007a3fbe1d3ea4  pop rdi
00007a3fbe1d3ea5  pop rdx
00007a3fbe1d3ea6  pop rcx
00007a3fbe1d3ea7  pop rax
00007a3fbe1d3ea8  add rsp, 0x08
00007a3fbe1d3eac  jmp 0x00007A3FBE1D286A
00007a3fbe1d3eb1  sub rsp, 0x08
00007a3fbe1d3eb5  push rax
00007a3fbe1d3eb6  push rcx
00007a3fbe1d3eb7  push rdx
00007a3fbe1d3eb8  push rdi
00007a3fbe1d3eb9  push rsi
00007a3fbe1d3eba  push r8
00007a3fbe1d3ebc  push r9
00007a3fbe1d3ebe  push r10
00007a3fbe1d3ec0  push r11
00007a3fbe1d3ec2  sub rsp, 0xF0
00007a3fbe1d3ec9  vmovaps [rsp], xmm0
00007a3fbe1d3ece  vmovaps [rsp+0x10], xmm2
00007a3fbe1d3ed4  vmovaps [rsp+0x20], xmm3
00007a3fbe1d3eda  vmovaps [rsp+0x30], xmm4
00007a3fbe1d3ee0  vmovaps [rsp+0x40], xmm5
00007a3fbe1d3ee6  vmovaps [rsp+0x50], xmm6
00007a3fbe1d3eec  vmovaps [rsp+0x60], xmm7
00007a3fbe1d3ef2  vmovaps [rsp+0x70], xmm8
00007a3fbe1d3ef8  vmovaps [rsp+0x80], xmm9
00007a3fbe1d3f01  vmovaps [rsp+0x90], xmm10
00007a3fbe1d3f0a  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d3f13  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d3f1c  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d3f25  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d3f2e  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d3f37  sub rsp, 0x30
00007a3fbe1d3f3b  movaps [rsp], xmm1
00007a3fbe1d3f3f  movaps [rsp+0x10], xmm10
00007a3fbe1d3f45  movaps [rsp+0x20], xmm2
00007a3fbe1d3f4a  lea rdi, [rsp]
00007a3fbe1d3f4e  mov esi, 0x00
00007a3fbe1d3f53  mov rax, 0x60D1084DB530
00007a3fbe1d3f5d  call rax
00007a3fbe1d3f5f  movaps xmm1, [rsp]
00007a3fbe1d3f63  add rsp, 0x30
00007a3fbe1d3f67  vmovaps xmm0, [rsp]
00007a3fbe1d3f6c  vmovaps xmm2, [rsp+0x10]
00007a3fbe1d3f72  vmovaps xmm3, [rsp+0x20]
00007a3fbe1d3f78  vmovaps xmm4, [rsp+0x30]
00007a3fbe1d3f7e  vmovaps xmm5, [rsp+0x40]
00007a3fbe1d3f84  vmovaps xmm6, [rsp+0x50]
00007a3fbe1d3f8a  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d3f90  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d3f96  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d3f9f  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d3fa8  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d3fb1  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d3fba  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d3fc3  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d3fcc  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d3fd5  add rsp, 0xF0
00007a3fbe1d3fdc  pop r11
00007a3fbe1d3fde  pop r10
00007a3fbe1d3fe0  pop r9
00007a3fbe1d3fe2  pop r8
00007a3fbe1d3fe4  pop rsi
00007a3fbe1d3fe5  pop rdi
00007a3fbe1d3fe6  pop rdx
00007a3fbe1d3fe7  pop rcx
00007a3fbe1d3fe8  pop rax
00007a3fbe1d3fe9  add rsp, 0x08
00007a3fbe1d3fed  jmp 0x00007A3FBE1D28D2
00007a3fbe1d3ff2  sub rsp, 0x08
00007a3fbe1d3ff6  push rax
00007a3fbe1d3ff7  push rcx
00007a3fbe1d3ff8  push rdx
00007a3fbe1d3ff9  push rdi
00007a3fbe1d3ffa  push rsi
00007a3fbe1d3ffb  push r8
00007a3fbe1d3ffd  push r9
00007a3fbe1d3fff  push r10
00007a3fbe1d4001  push r11
00007a3fbe1d4003  sub rsp, 0xF0
00007a3fbe1d400a  vmovaps [rsp], xmm0
00007a3fbe1d400f  vmovaps [rsp+0x10], xmm1
00007a3fbe1d4015  vmovaps [rsp+0x20], xmm2
00007a3fbe1d401b  vmovaps [rsp+0x30], xmm3
00007a3fbe1d4021  vmovaps [rsp+0x40], xmm4
00007a3fbe1d4027  vmovaps [rsp+0x50], xmm5
00007a3fbe1d402d  vmovaps [rsp+0x60], xmm6
00007a3fbe1d4033  vmovaps [rsp+0x70], xmm7
00007a3fbe1d4039  vmovaps [rsp+0x80], xmm8
00007a3fbe1d4042  vmovaps [rsp+0x90], xmm9
00007a3fbe1d404b  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d4054  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d405d  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d4066  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d406f  vmovaps [rsp+0xE0], xmm14
00007a3fbe1d4078  sub rsp, 0x30
00007a3fbe1d407c  movaps [rsp], xmm15
00007a3fbe1d4081  movaps [rsp+0x10], xmm10
00007a3fbe1d4087  movaps [rsp+0x20], xmm2
00007a3fbe1d408c  lea rdi, [rsp]
00007a3fbe1d4090  mov esi, 0x00
00007a3fbe1d4095  mov rax, 0x60D1084DB530
00007a3fbe1d409f  call rax
00007a3fbe1d40a1  movaps xmm15, [rsp]
00007a3fbe1d40a6  add rsp, 0x30
00007a3fbe1d40aa  vmovaps xmm0, [rsp]
00007a3fbe1d40af  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d40b5  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d40bb  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d40c1  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d40c7  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d40cd  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d40d3  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d40d9  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d40e2  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d40eb  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d40f4  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d40fd  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d4106  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d410f  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1d4118  add rsp, 0xF0
00007a3fbe1d411f  pop r11
00007a3fbe1d4121  pop r10
00007a3fbe1d4123  pop r9
00007a3fbe1d4125  pop r8
00007a3fbe1d4127  pop rsi
00007a3fbe1d4128  pop rdi
00007a3fbe1d4129  pop rdx
00007a3fbe1d412a  pop rcx
00007a3fbe1d412b  pop rax
00007a3fbe1d412c  add rsp, 0x08
00007a3fbe1d4130  jmp 0x00007A3FBE1D2924
00007a3fbe1d4135  sub rsp, 0x08
00007a3fbe1d4139  push rax
00007a3fbe1d413a  push rcx
00007a3fbe1d413b  push rdx
00007a3fbe1d413c  push rdi
00007a3fbe1d413d  push rsi
00007a3fbe1d413e  push r8
00007a3fbe1d4140  push r9
00007a3fbe1d4142  push r10
00007a3fbe1d4144  push r11
00007a3fbe1d4146  sub rsp, 0xF0
00007a3fbe1d414d  vmovaps [rsp], xmm0
00007a3fbe1d4152  vmovaps [rsp+0x10], xmm2
00007a3fbe1d4158  vmovaps [rsp+0x20], xmm3
00007a3fbe1d415e  vmovaps [rsp+0x30], xmm4
00007a3fbe1d4164  vmovaps [rsp+0x40], xmm5
00007a3fbe1d416a  vmovaps [rsp+0x50], xmm6
00007a3fbe1d4170  vmovaps [rsp+0x60], xmm7
00007a3fbe1d4176  vmovaps [rsp+0x70], xmm8
00007a3fbe1d417c  vmovaps [rsp+0x80], xmm9
00007a3fbe1d4185  vmovaps [rsp+0x90], xmm10
00007a3fbe1d418e  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d4197  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d41a0  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d41a9  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d41b2  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d41bb  sub rsp, 0x30
00007a3fbe1d41bf  movaps [rsp], xmm1
00007a3fbe1d41c3  movaps [rsp+0x10], xmm10
00007a3fbe1d41c9  movaps [rsp+0x20], xmm15
00007a3fbe1d41cf  lea rdi, [rsp]
00007a3fbe1d41d3  mov esi, 0x00
00007a3fbe1d41d8  mov rax, 0x60D1084DB530
00007a3fbe1d41e2  call rax
00007a3fbe1d41e4  movaps xmm1, [rsp]
00007a3fbe1d41e8  add rsp, 0x30
00007a3fbe1d41ec  vmovaps xmm0, [rsp]
00007a3fbe1d41f1  vmovaps xmm2, [rsp+0x10]
00007a3fbe1d41f7  vmovaps xmm3, [rsp+0x20]
00007a3fbe1d41fd  vmovaps xmm4, [rsp+0x30]
00007a3fbe1d4203  vmovaps xmm5, [rsp+0x40]
00007a3fbe1d4209  vmovaps xmm6, [rsp+0x50]
00007a3fbe1d420f  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d4215  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d421b  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d4224  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d422d  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d4236  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d423f  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d4248  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d4251  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d425a  add rsp, 0xF0
00007a3fbe1d4261  pop r11
00007a3fbe1d4263  pop r10
00007a3fbe1d4265  pop r9
00007a3fbe1d4267  pop r8
00007a3fbe1d4269  pop rsi
00007a3fbe1d426a  pop rdi
00007a3fbe1d426b  pop rdx
00007a3fbe1d426c  pop rcx
00007a3fbe1d426d  pop rax
00007a3fbe1d426e  add rsp, 0x08
00007a3fbe1d4272  jmp 0x00007A3FBE1D2962
00007a3fbe1d4277  sub rsp, 0x08
00007a3fbe1d427b  push rax
00007a3fbe1d427c  push rcx
00007a3fbe1d427d  push rdx
00007a3fbe1d427e  push rdi
00007a3fbe1d427f  push rsi
00007a3fbe1d4280  push r8
00007a3fbe1d4282  push r9
00007a3fbe1d4284  push r10
00007a3fbe1d4286  push r11
00007a3fbe1d4288  sub rsp, 0xF0
00007a3fbe1d428f  vmovaps [rsp], xmm0
00007a3fbe1d4294  vmovaps [rsp+0x10], xmm1
00007a3fbe1d429a  vmovaps [rsp+0x20], xmm2
00007a3fbe1d42a0  vmovaps [rsp+0x30], xmm3
00007a3fbe1d42a6  vmovaps [rsp+0x40], xmm4
00007a3fbe1d42ac  vmovaps [rsp+0x50], xmm5
00007a3fbe1d42b2  vmovaps [rsp+0x60], xmm6
00007a3fbe1d42b8  vmovaps [rsp+0x70], xmm7
00007a3fbe1d42be  vmovaps [rsp+0x80], xmm8
00007a3fbe1d42c7  vmovaps [rsp+0x90], xmm9
00007a3fbe1d42d0  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d42d9  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d42e2  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d42eb  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d42f4  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d42fd  sub rsp, 0x30
00007a3fbe1d4301  movaps [rsp], xmm14
00007a3fbe1d4306  movaps [rsp+0x10], xmm10
00007a3fbe1d430c  movaps [rsp+0x20], xmm15
00007a3fbe1d4312  lea rdi, [rsp]
00007a3fbe1d4316  mov esi, 0x00
00007a3fbe1d431b  mov rax, 0x60D1084DB530
00007a3fbe1d4325  call rax
00007a3fbe1d4327  movaps xmm14, [rsp]
00007a3fbe1d432c  add rsp, 0x30
00007a3fbe1d4330  vmovaps xmm0, [rsp]
00007a3fbe1d4335  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d433b  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d4341  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d4347  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d434d  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d4353  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d4359  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d435f  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d4368  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d4371  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d437a  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d4383  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d438c  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d4395  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d439e  add rsp, 0xF0
00007a3fbe1d43a5  pop r11
00007a3fbe1d43a7  pop r10
00007a3fbe1d43a9  pop r9
00007a3fbe1d43ab  pop r8
00007a3fbe1d43ad  pop rsi
00007a3fbe1d43ae  pop rdi
00007a3fbe1d43af  pop rdx
00007a3fbe1d43b0  pop rcx
00007a3fbe1d43b1  pop rax
00007a3fbe1d43b2  add rsp, 0x08
00007a3fbe1d43b6  jmp 0x00007A3FBE1D298E
00007a3fbe1d43bb  call 0x00007A3FBDFFF430
00007a3fbe1d43c0  jmp 0x00007A3FBE1D2A1E
00007a3fbe1d43c5  call 0x00007A3FBDFFF430
00007a3fbe1d43ca  jmp 0x00007A3FBE1D2A31
00007a3fbe1d43cf  sub rsp, 0x08
00007a3fbe1d43d3  push rax
00007a3fbe1d43d4  push rcx
00007a3fbe1d43d5  push rdx
00007a3fbe1d43d6  push rdi
00007a3fbe1d43d7  push rsi
00007a3fbe1d43d8  push r8
00007a3fbe1d43da  push r9
00007a3fbe1d43dc  push r10
00007a3fbe1d43de  push r11
00007a3fbe1d43e0  sub rsp, 0xF0
00007a3fbe1d43e7  vmovaps [rsp], xmm0
00007a3fbe1d43ec  vmovaps [rsp+0x10], xmm2
00007a3fbe1d43f2  vmovaps [rsp+0x20], xmm3
00007a3fbe1d43f8  vmovaps [rsp+0x30], xmm4
00007a3fbe1d43fe  vmovaps [rsp+0x40], xmm5
00007a3fbe1d4404  vmovaps [rsp+0x50], xmm6
00007a3fbe1d440a  vmovaps [rsp+0x60], xmm7
00007a3fbe1d4410  vmovaps [rsp+0x70], xmm8
00007a3fbe1d4416  vmovaps [rsp+0x80], xmm9
00007a3fbe1d441f  vmovaps [rsp+0x90], xmm10
00007a3fbe1d4428  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d4431  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d443a  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d4443  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d444c  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d4455  sub rsp, 0x30
00007a3fbe1d4459  movaps [rsp], xmm1
00007a3fbe1d445d  movaps [rsp+0x10], xmm13
00007a3fbe1d4463  movaps [rsp+0x20], xmm2
00007a3fbe1d4468  lea rdi, [rsp]
00007a3fbe1d446c  mov esi, 0x00
00007a3fbe1d4471  mov rax, 0x60D1084DB530
00007a3fbe1d447b  call rax
00007a3fbe1d447d  movaps xmm1, [rsp]
00007a3fbe1d4481  add rsp, 0x30
00007a3fbe1d4485  vmovaps xmm0, [rsp]
00007a3fbe1d448a  vmovaps xmm2, [rsp+0x10]
00007a3fbe1d4490  vmovaps xmm3, [rsp+0x20]
00007a3fbe1d4496  vmovaps xmm4, [rsp+0x30]
00007a3fbe1d449c  vmovaps xmm5, [rsp+0x40]
00007a3fbe1d44a2  vmovaps xmm6, [rsp+0x50]
00007a3fbe1d44a8  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d44ae  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d44b4  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d44bd  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d44c6  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d44cf  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d44d8  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d44e1  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d44ea  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d44f3  add rsp, 0xF0
00007a3fbe1d44fa  pop r11
00007a3fbe1d44fc  pop r10
00007a3fbe1d44fe  pop r9
00007a3fbe1d4500  pop r8
00007a3fbe1d4502  pop rsi
00007a3fbe1d4503  pop rdi
00007a3fbe1d4504  pop rdx
00007a3fbe1d4505  pop rcx
00007a3fbe1d4506  pop rax
00007a3fbe1d4507  add rsp, 0x08
00007a3fbe1d450b  jmp 0x00007A3FBE1D2A5C
00007a3fbe1d4510  call 0x00007A3FBE00E760
00007a3fbe1d4515  jmp 0x00007A3FBE1D2A69
00007a3fbe1d451a  sub rsp, 0x08
00007a3fbe1d451e  push rax
00007a3fbe1d451f  push rcx
00007a3fbe1d4520  push rdx
00007a3fbe1d4521  push rdi
00007a3fbe1d4522  push rsi
00007a3fbe1d4523  push r8
00007a3fbe1d4525  push r9
00007a3fbe1d4527  push r10
00007a3fbe1d4529  push r11
00007a3fbe1d452b  sub rsp, 0xF0
00007a3fbe1d4532  vmovaps [rsp], xmm0
00007a3fbe1d4537  vmovaps [rsp+0x10], xmm1
00007a3fbe1d453d  vmovaps [rsp+0x20], xmm2
00007a3fbe1d4543  vmovaps [rsp+0x30], xmm3
00007a3fbe1d4549  vmovaps [rsp+0x40], xmm4
00007a3fbe1d454f  vmovaps [rsp+0x50], xmm5
00007a3fbe1d4555  vmovaps [rsp+0x60], xmm6
00007a3fbe1d455b  vmovaps [rsp+0x70], xmm7
00007a3fbe1d4561  vmovaps [rsp+0x80], xmm8
00007a3fbe1d456a  vmovaps [rsp+0x90], xmm9
00007a3fbe1d4573  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d457c  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d4585  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d458e  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d4597  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d45a0  sub rsp, 0x30
00007a3fbe1d45a4  movaps [rsp], xmm13
00007a3fbe1d45a9  movaps [rsp+0x10], xmm2
00007a3fbe1d45ae  movaps [rsp+0x20], xmm1
00007a3fbe1d45b3  lea rdi, [rsp]
00007a3fbe1d45b7  mov esi, 0x00
00007a3fbe1d45bc  mov rax, 0x60D1084DB530
00007a3fbe1d45c6  call rax
00007a3fbe1d45c8  movaps xmm13, [rsp]
00007a3fbe1d45cd  add rsp, 0x30
00007a3fbe1d45d1  vmovaps xmm0, [rsp]
00007a3fbe1d45d6  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d45dc  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d45e2  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d45e8  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d45ee  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d45f4  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d45fa  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d4600  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d4609  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d4612  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d461b  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d4624  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d462d  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d4636  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d463f  add rsp, 0xF0
00007a3fbe1d4646  pop r11
00007a3fbe1d4648  pop r10
00007a3fbe1d464a  pop r9
00007a3fbe1d464c  pop r8
00007a3fbe1d464e  pop rsi
00007a3fbe1d464f  pop rdi
00007a3fbe1d4650  pop rdx
00007a3fbe1d4651  pop rcx
00007a3fbe1d4652  pop rax
00007a3fbe1d4653  add rsp, 0x08
00007a3fbe1d4657  jmp 0x00007A3FBE1D2AA8
00007a3fbe1d465c  sub rsp, 0x08
00007a3fbe1d4660  push rax
00007a3fbe1d4661  push rcx
00007a3fbe1d4662  push rdx
00007a3fbe1d4663  push rdi
00007a3fbe1d4664  push rsi
00007a3fbe1d4665  push r8
00007a3fbe1d4667  push r9
00007a3fbe1d4669  push r10
00007a3fbe1d466b  push r11
00007a3fbe1d466d  sub rsp, 0xF0
00007a3fbe1d4674  vmovaps [rsp], xmm0
00007a3fbe1d4679  vmovaps [rsp+0x10], xmm2
00007a3fbe1d467f  vmovaps [rsp+0x20], xmm3
00007a3fbe1d4685  vmovaps [rsp+0x30], xmm4
00007a3fbe1d468b  vmovaps [rsp+0x40], xmm5
00007a3fbe1d4691  vmovaps [rsp+0x50], xmm6
00007a3fbe1d4697  vmovaps [rsp+0x60], xmm7
00007a3fbe1d469d  vmovaps [rsp+0x70], xmm8
00007a3fbe1d46a3  vmovaps [rsp+0x80], xmm9
00007a3fbe1d46ac  vmovaps [rsp+0x90], xmm10
00007a3fbe1d46b5  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d46be  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d46c7  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d46d0  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d46d9  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d46e2  sub rsp, 0x30
00007a3fbe1d46e6  movaps [rsp], xmm1
00007a3fbe1d46ea  movaps [rsp+0x10], xmm14
00007a3fbe1d46f0  movaps [rsp+0x20], xmm15
00007a3fbe1d46f6  lea rdi, [rsp]
00007a3fbe1d46fa  mov esi, 0x00
00007a3fbe1d46ff  mov rax, 0x60D1084DB530
00007a3fbe1d4709  call rax
00007a3fbe1d470b  movaps xmm1, [rsp]
00007a3fbe1d470f  add rsp, 0x30
00007a3fbe1d4713  vmovaps xmm0, [rsp]
00007a3fbe1d4718  vmovaps xmm2, [rsp+0x10]
00007a3fbe1d471e  vmovaps xmm3, [rsp+0x20]
00007a3fbe1d4724  vmovaps xmm4, [rsp+0x30]
00007a3fbe1d472a  vmovaps xmm5, [rsp+0x40]
00007a3fbe1d4730  vmovaps xmm6, [rsp+0x50]
00007a3fbe1d4736  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d473c  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d4742  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d474b  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d4754  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d475d  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d4766  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d476f  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d4778  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d4781  add rsp, 0xF0
00007a3fbe1d4788  pop r11
00007a3fbe1d478a  pop r10
00007a3fbe1d478c  pop r9
00007a3fbe1d478e  pop r8
00007a3fbe1d4790  pop rsi
00007a3fbe1d4791  pop rdi
00007a3fbe1d4792  pop rdx
00007a3fbe1d4793  pop rcx
00007a3fbe1d4794  pop rax
00007a3fbe1d4795  add rsp, 0x08
00007a3fbe1d4799  jmp 0x00007A3FBE1D2ACA
00007a3fbe1d479e  sub rsp, 0x08
00007a3fbe1d47a2  push rax
00007a3fbe1d47a3  push rcx
00007a3fbe1d47a4  push rdx
00007a3fbe1d47a5  push rdi
00007a3fbe1d47a6  push rsi
00007a3fbe1d47a7  push r8
00007a3fbe1d47a9  push r9
00007a3fbe1d47ab  push r10
00007a3fbe1d47ad  push r11
00007a3fbe1d47af  sub rsp, 0xF0
00007a3fbe1d47b6  vmovaps [rsp], xmm0
00007a3fbe1d47bb  vmovaps [rsp+0x10], xmm1
00007a3fbe1d47c1  vmovaps [rsp+0x20], xmm2
00007a3fbe1d47c7  vmovaps [rsp+0x30], xmm3
00007a3fbe1d47cd  vmovaps [rsp+0x40], xmm4
00007a3fbe1d47d3  vmovaps [rsp+0x50], xmm5
00007a3fbe1d47d9  vmovaps [rsp+0x60], xmm6
00007a3fbe1d47df  vmovaps [rsp+0x70], xmm7
00007a3fbe1d47e5  vmovaps [rsp+0x80], xmm8
00007a3fbe1d47ee  vmovaps [rsp+0x90], xmm9
00007a3fbe1d47f7  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d4800  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d4809  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d4812  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d481b  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d4824  sub rsp, 0x30
00007a3fbe1d4828  movaps [rsp], xmm14
00007a3fbe1d482d  movaps [rsp+0x10], xmm2
00007a3fbe1d4832  movaps [rsp+0x20], xmm15
00007a3fbe1d4838  lea rdi, [rsp]
00007a3fbe1d483c  mov esi, 0x00
00007a3fbe1d4841  mov rax, 0x60D1084DB530
00007a3fbe1d484b  call rax
00007a3fbe1d484d  movaps xmm14, [rsp]
00007a3fbe1d4852  add rsp, 0x30
00007a3fbe1d4856  vmovaps xmm0, [rsp]
00007a3fbe1d485b  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d4861  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d4867  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d486d  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d4873  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d4879  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d487f  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d4885  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d488e  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d4897  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d48a0  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d48a9  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d48b2  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d48bb  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d48c4  add rsp, 0xF0
00007a3fbe1d48cb  pop r11
00007a3fbe1d48cd  pop r10
00007a3fbe1d48cf  pop r9
00007a3fbe1d48d1  pop r8
00007a3fbe1d48d3  pop rsi
00007a3fbe1d48d4  pop rdi
00007a3fbe1d48d5  pop rdx
00007a3fbe1d48d6  pop rcx
00007a3fbe1d48d7  pop rax
00007a3fbe1d48d8  add rsp, 0x08
00007a3fbe1d48dc  jmp 0x00007A3FBE1D2B05
00007a3fbe1d48e1  sub rsp, 0x08
00007a3fbe1d48e5  push rax
00007a3fbe1d48e6  push rcx
00007a3fbe1d48e7  push rdx
00007a3fbe1d48e8  push rdi
00007a3fbe1d48e9  push rsi
00007a3fbe1d48ea  push r8
00007a3fbe1d48ec  push r9
00007a3fbe1d48ee  push r10
00007a3fbe1d48f0  push r11
00007a3fbe1d48f2  sub rsp, 0xF0
00007a3fbe1d48f9  vmovaps [rsp], xmm0
00007a3fbe1d48fe  vmovaps [rsp+0x10], xmm1
00007a3fbe1d4904  vmovaps [rsp+0x20], xmm2
00007a3fbe1d490a  vmovaps [rsp+0x30], xmm3
00007a3fbe1d4910  vmovaps [rsp+0x40], xmm4
00007a3fbe1d4916  vmovaps [rsp+0x50], xmm5
00007a3fbe1d491c  vmovaps [rsp+0x60], xmm6
00007a3fbe1d4922  vmovaps [rsp+0x70], xmm7
00007a3fbe1d4928  vmovaps [rsp+0x80], xmm8
00007a3fbe1d4931  vmovaps [rsp+0x90], xmm9
00007a3fbe1d493a  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d4943  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d494c  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d4955  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d495e  vmovaps [rsp+0xE0], xmm14
00007a3fbe1d4967  sub rsp, 0x30
00007a3fbe1d496b  movaps [rsp], xmm15
00007a3fbe1d4970  movaps [rsp+0x10], xmm2
00007a3fbe1d4975  movaps [rsp+0x20], xmm1
00007a3fbe1d497a  lea rdi, [rsp]
00007a3fbe1d497e  mov esi, 0x00
00007a3fbe1d4983  mov rax, 0x60D1084DB530
00007a3fbe1d498d  call rax
00007a3fbe1d498f  movaps xmm15, [rsp]
00007a3fbe1d4994  add rsp, 0x30
00007a3fbe1d4998  vmovaps xmm0, [rsp]
00007a3fbe1d499d  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d49a3  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d49a9  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d49af  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d49b5  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d49bb  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d49c1  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d49c7  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d49d0  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d49d9  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d49e2  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d49eb  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d49f4  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d49fd  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1d4a06  add rsp, 0xF0
00007a3fbe1d4a0d  pop r11
00007a3fbe1d4a0f  pop r10
00007a3fbe1d4a11  pop r9
00007a3fbe1d4a13  pop r8
00007a3fbe1d4a15  pop rsi
00007a3fbe1d4a16  pop rdi
00007a3fbe1d4a17  pop rdx
00007a3fbe1d4a18  pop rcx
00007a3fbe1d4a19  pop rax
00007a3fbe1d4a1a  add rsp, 0x08
00007a3fbe1d4a1e  jmp 0x00007A3FBE1D2B41
00007a3fbe1d4a23  call 0x00007A3FBDFFF430
00007a3fbe1d4a28  jmp 0x00007A3FBE1D2B4E
00007a3fbe1d4a2d  sub rsp, 0x08
00007a3fbe1d4a31  push rax
00007a3fbe1d4a32  push rcx
00007a3fbe1d4a33  push rdx
00007a3fbe1d4a34  push rdi
00007a3fbe1d4a35  push rsi
00007a3fbe1d4a36  push r8
00007a3fbe1d4a38  push r9
00007a3fbe1d4a3a  push r10
00007a3fbe1d4a3c  push r11
00007a3fbe1d4a3e  sub rsp, 0xF0
00007a3fbe1d4a45  vmovaps [rsp], xmm0
00007a3fbe1d4a4a  vmovaps [rsp+0x10], xmm1
00007a3fbe1d4a50  vmovaps [rsp+0x20], xmm3
00007a3fbe1d4a56  vmovaps [rsp+0x30], xmm4
00007a3fbe1d4a5c  vmovaps [rsp+0x40], xmm5
00007a3fbe1d4a62  vmovaps [rsp+0x50], xmm6
00007a3fbe1d4a68  vmovaps [rsp+0x60], xmm7
00007a3fbe1d4a6e  vmovaps [rsp+0x70], xmm8
00007a3fbe1d4a74  vmovaps [rsp+0x80], xmm9
00007a3fbe1d4a7d  vmovaps [rsp+0x90], xmm10
00007a3fbe1d4a86  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d4a8f  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d4a98  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d4aa1  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d4aaa  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d4ab3  sub rsp, 0x30
00007a3fbe1d4ab7  movaps [rsp], xmm2
00007a3fbe1d4abb  movaps [rsp+0x10], xmm1
00007a3fbe1d4ac0  movaps [rsp+0x20], xmm14
00007a3fbe1d4ac6  lea rdi, [rsp]
00007a3fbe1d4aca  mov esi, 0x00
00007a3fbe1d4acf  mov rax, 0x60D1084DB530
00007a3fbe1d4ad9  call rax
00007a3fbe1d4adb  movaps xmm2, [rsp]
00007a3fbe1d4adf  add rsp, 0x30
00007a3fbe1d4ae3  vmovaps xmm0, [rsp]
00007a3fbe1d4ae8  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d4aee  vmovaps xmm3, [rsp+0x20]
00007a3fbe1d4af4  vmovaps xmm4, [rsp+0x30]
00007a3fbe1d4afa  vmovaps xmm5, [rsp+0x40]
00007a3fbe1d4b00  vmovaps xmm6, [rsp+0x50]
00007a3fbe1d4b06  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d4b0c  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d4b12  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d4b1b  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d4b24  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d4b2d  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d4b36  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d4b3f  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d4b48  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d4b51  add rsp, 0xF0
00007a3fbe1d4b58  pop r11
00007a3fbe1d4b5a  pop r10
00007a3fbe1d4b5c  pop r9
00007a3fbe1d4b5e  pop r8
00007a3fbe1d4b60  pop rsi
00007a3fbe1d4b61  pop rdi
00007a3fbe1d4b62  pop rdx
00007a3fbe1d4b63  pop rcx
00007a3fbe1d4b64  pop rax
00007a3fbe1d4b65  add rsp, 0x08
00007a3fbe1d4b69  jmp 0x00007A3FBE1D2B8B
00007a3fbe1d4b6e  sub rsp, 0x08
00007a3fbe1d4b72  push rax
00007a3fbe1d4b73  push rcx
00007a3fbe1d4b74  push rdx
00007a3fbe1d4b75  push rdi
00007a3fbe1d4b76  push rsi
00007a3fbe1d4b77  push r8
00007a3fbe1d4b79  push r9
00007a3fbe1d4b7b  push r10
00007a3fbe1d4b7d  push r11
00007a3fbe1d4b7f  sub rsp, 0xF0
00007a3fbe1d4b86  vmovaps [rsp], xmm0
00007a3fbe1d4b8b  vmovaps [rsp+0x10], xmm1
00007a3fbe1d4b91  vmovaps [rsp+0x20], xmm2
00007a3fbe1d4b97  vmovaps [rsp+0x30], xmm3
00007a3fbe1d4b9d  vmovaps [rsp+0x40], xmm4
00007a3fbe1d4ba3  vmovaps [rsp+0x50], xmm5
00007a3fbe1d4ba9  vmovaps [rsp+0x60], xmm6
00007a3fbe1d4baf  vmovaps [rsp+0x70], xmm7
00007a3fbe1d4bb5  vmovaps [rsp+0x80], xmm8
00007a3fbe1d4bbe  vmovaps [rsp+0x90], xmm9
00007a3fbe1d4bc7  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d4bd0  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d4bd9  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d4be2  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d4beb  vmovaps [rsp+0xE0], xmm14
00007a3fbe1d4bf4  sub rsp, 0x30
00007a3fbe1d4bf8  movaps [rsp], xmm15
00007a3fbe1d4bfd  movaps [rsp+0x10], xmm14
00007a3fbe1d4c03  movaps [rsp+0x20], xmm1
00007a3fbe1d4c08  lea rdi, [rsp]
00007a3fbe1d4c0c  mov esi, 0x00
00007a3fbe1d4c11  mov rax, 0x60D1084DB530
00007a3fbe1d4c1b  call rax
00007a3fbe1d4c1d  movaps xmm15, [rsp]
00007a3fbe1d4c22  add rsp, 0x30
00007a3fbe1d4c26  vmovaps xmm0, [rsp]
00007a3fbe1d4c2b  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d4c31  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d4c37  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d4c3d  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d4c43  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d4c49  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d4c4f  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d4c55  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d4c5e  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d4c67  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d4c70  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d4c79  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d4c82  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d4c8b  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1d4c94  add rsp, 0xF0
00007a3fbe1d4c9b  pop r11
00007a3fbe1d4c9d  pop r10
00007a3fbe1d4c9f  pop r9
00007a3fbe1d4ca1  pop r8
00007a3fbe1d4ca3  pop rsi
00007a3fbe1d4ca4  pop rdi
00007a3fbe1d4ca5  pop rdx
00007a3fbe1d4ca6  pop rcx
00007a3fbe1d4ca7  pop rax
00007a3fbe1d4ca8  add rsp, 0x08
00007a3fbe1d4cac  jmp 0x00007A3FBE1D2C05
00007a3fbe1d4cb1  call 0x00007A3FBDFFF430
00007a3fbe1d4cb6  jmp 0x00007A3FBE1D2C12
00007a3fbe1d4cbb  sub rsp, 0x08
00007a3fbe1d4cbf  push rax
00007a3fbe1d4cc0  push rcx
00007a3fbe1d4cc1  push rdx
00007a3fbe1d4cc2  push rdi
00007a3fbe1d4cc3  push rsi
00007a3fbe1d4cc4  push r8
00007a3fbe1d4cc6  push r9
00007a3fbe1d4cc8  push r10
00007a3fbe1d4cca  push r11
00007a3fbe1d4ccc  sub rsp, 0xF0
00007a3fbe1d4cd3  vmovaps [rsp], xmm0
00007a3fbe1d4cd8  vmovaps [rsp+0x10], xmm1
00007a3fbe1d4cde  vmovaps [rsp+0x20], xmm2
00007a3fbe1d4ce4  vmovaps [rsp+0x30], xmm3
00007a3fbe1d4cea  vmovaps [rsp+0x40], xmm4
00007a3fbe1d4cf0  vmovaps [rsp+0x50], xmm5
00007a3fbe1d4cf6  vmovaps [rsp+0x60], xmm6
00007a3fbe1d4cfc  vmovaps [rsp+0x70], xmm7
00007a3fbe1d4d02  vmovaps [rsp+0x80], xmm8
00007a3fbe1d4d0b  vmovaps [rsp+0x90], xmm9
00007a3fbe1d4d14  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d4d1d  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d4d26  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d4d2f  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d4d38  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d4d41  sub rsp, 0x30
00007a3fbe1d4d45  movaps [rsp], xmm13
00007a3fbe1d4d4a  movaps [rsp+0x10], xmm1
00007a3fbe1d4d4f  movaps [rsp+0x20], xmm15
00007a3fbe1d4d55  lea rdi, [rsp]
00007a3fbe1d4d59  mov esi, 0x00
00007a3fbe1d4d5e  mov rax, 0x60D1084DB530
00007a3fbe1d4d68  call rax
00007a3fbe1d4d6a  movaps xmm13, [rsp]
00007a3fbe1d4d6f  add rsp, 0x30
00007a3fbe1d4d73  vmovaps xmm0, [rsp]
00007a3fbe1d4d78  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d4d7e  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d4d84  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d4d8a  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d4d90  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d4d96  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d4d9c  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d4da2  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d4dab  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d4db4  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d4dbd  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d4dc6  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d4dcf  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d4dd8  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d4de1  add rsp, 0xF0
00007a3fbe1d4de8  pop r11
00007a3fbe1d4dea  pop r10
00007a3fbe1d4dec  pop r9
00007a3fbe1d4dee  pop r8
00007a3fbe1d4df0  pop rsi
00007a3fbe1d4df1  pop rdi
00007a3fbe1d4df2  pop rdx
00007a3fbe1d4df3  pop rcx
00007a3fbe1d4df4  pop rax
00007a3fbe1d4df5  add rsp, 0x08
00007a3fbe1d4df9  jmp 0x00007A3FBE1D2CD6
00007a3fbe1d4dfe  sub rsp, 0x08
00007a3fbe1d4e02  push rax
00007a3fbe1d4e03  push rcx
00007a3fbe1d4e04  push rdx
00007a3fbe1d4e05  push rdi
00007a3fbe1d4e06  push rsi
00007a3fbe1d4e07  push r8
00007a3fbe1d4e09  push r9
00007a3fbe1d4e0b  push r10
00007a3fbe1d4e0d  push r11
00007a3fbe1d4e0f  sub rsp, 0xF0
00007a3fbe1d4e16  vmovaps [rsp], xmm0
00007a3fbe1d4e1b  vmovaps [rsp+0x10], xmm1
00007a3fbe1d4e21  vmovaps [rsp+0x20], xmm2
00007a3fbe1d4e27  vmovaps [rsp+0x30], xmm3
00007a3fbe1d4e2d  vmovaps [rsp+0x40], xmm4
00007a3fbe1d4e33  vmovaps [rsp+0x50], xmm5
00007a3fbe1d4e39  vmovaps [rsp+0x60], xmm6
00007a3fbe1d4e3f  vmovaps [rsp+0x70], xmm7
00007a3fbe1d4e45  vmovaps [rsp+0x80], xmm8
00007a3fbe1d4e4e  vmovaps [rsp+0x90], xmm9
00007a3fbe1d4e57  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d4e60  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d4e69  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d4e72  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d4e7b  vmovaps [rsp+0xE0], xmm14
00007a3fbe1d4e84  sub rsp, 0x30
00007a3fbe1d4e88  movaps [rsp], xmm15
00007a3fbe1d4e8d  movaps [rsp+0x10], xmm14
00007a3fbe1d4e93  movaps [rsp+0x20], xmm1
00007a3fbe1d4e98  lea rdi, [rsp]
00007a3fbe1d4e9c  mov esi, 0x00
00007a3fbe1d4ea1  mov rax, 0x60D1084DB530
00007a3fbe1d4eab  call rax
00007a3fbe1d4ead  movaps xmm15, [rsp]
00007a3fbe1d4eb2  add rsp, 0x30
00007a3fbe1d4eb6  vmovaps xmm0, [rsp]
00007a3fbe1d4ebb  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d4ec1  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d4ec7  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d4ecd  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d4ed3  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d4ed9  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d4edf  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d4ee5  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d4eee  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d4ef7  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d4f00  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d4f09  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d4f12  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d4f1b  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1d4f24  add rsp, 0xF0
00007a3fbe1d4f2b  pop r11
00007a3fbe1d4f2d  pop r10
00007a3fbe1d4f2f  pop r9
00007a3fbe1d4f31  pop r8
00007a3fbe1d4f33  pop rsi
00007a3fbe1d4f34  pop rdi
00007a3fbe1d4f35  pop rdx
00007a3fbe1d4f36  pop rcx
00007a3fbe1d4f37  pop rax
00007a3fbe1d4f38  add rsp, 0x08
00007a3fbe1d4f3c  jmp 0x00007A3FBE1D2D12
00007a3fbe1d4f41  call 0x00007A3FBDFFF430
00007a3fbe1d4f46  jmp 0x00007A3FBE1D2D1F
00007a3fbe1d4f4b  sub rsp, 0x08
00007a3fbe1d4f4f  push rax
00007a3fbe1d4f50  push rcx
00007a3fbe1d4f51  push rdx
00007a3fbe1d4f52  push rdi
00007a3fbe1d4f53  push rsi
00007a3fbe1d4f54  push r8
00007a3fbe1d4f56  push r9
00007a3fbe1d4f58  push r10
00007a3fbe1d4f5a  push r11
00007a3fbe1d4f5c  sub rsp, 0xF0
00007a3fbe1d4f63  vmovaps [rsp], xmm0
00007a3fbe1d4f68  vmovaps [rsp+0x10], xmm1
00007a3fbe1d4f6e  vmovaps [rsp+0x20], xmm2
00007a3fbe1d4f74  vmovaps [rsp+0x30], xmm3
00007a3fbe1d4f7a  vmovaps [rsp+0x40], xmm4
00007a3fbe1d4f80  vmovaps [rsp+0x50], xmm5
00007a3fbe1d4f86  vmovaps [rsp+0x60], xmm6
00007a3fbe1d4f8c  vmovaps [rsp+0x70], xmm7
00007a3fbe1d4f92  vmovaps [rsp+0x80], xmm8
00007a3fbe1d4f9b  vmovaps [rsp+0x90], xmm9
00007a3fbe1d4fa4  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d4fad  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d4fb6  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d4fbf  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d4fc8  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d4fd1  sub rsp, 0x30
00007a3fbe1d4fd5  movaps [rsp], xmm14
00007a3fbe1d4fda  movaps [rsp+0x10], xmm13
00007a3fbe1d4fe0  movaps [rsp+0x20], xmm2
00007a3fbe1d4fe5  lea rdi, [rsp]
00007a3fbe1d4fe9  mov esi, 0x00
00007a3fbe1d4fee  mov rax, 0x60D1084DB530
00007a3fbe1d4ff8  call rax
00007a3fbe1d4ffa  movaps xmm14, [rsp]
00007a3fbe1d4fff  add rsp, 0x30
00007a3fbe1d5003  vmovaps xmm0, [rsp]
00007a3fbe1d5008  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d500e  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d5014  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d501a  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d5020  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d5026  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d502c  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d5032  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d503b  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d5044  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d504d  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d5056  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d505f  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d5068  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d5071  add rsp, 0xF0
00007a3fbe1d5078  pop r11
00007a3fbe1d507a  pop r10
00007a3fbe1d507c  pop r9
00007a3fbe1d507e  pop r8
00007a3fbe1d5080  pop rsi
00007a3fbe1d5081  pop rdi
00007a3fbe1d5082  pop rdx
00007a3fbe1d5083  pop rcx
00007a3fbe1d5084  pop rax
00007a3fbe1d5085  add rsp, 0x08
00007a3fbe1d5089  jmp 0x00007A3FBE1D2D4B
00007a3fbe1d508e  sub rsp, 0x08
00007a3fbe1d5092  push rax
00007a3fbe1d5093  push rcx
00007a3fbe1d5094  push rdx
00007a3fbe1d5095  push rdi
00007a3fbe1d5096  push rsi
00007a3fbe1d5097  push r8
00007a3fbe1d5099  push r9
00007a3fbe1d509b  push r10
00007a3fbe1d509d  push r11
00007a3fbe1d509f  sub rsp, 0xF0
00007a3fbe1d50a6  vmovaps [rsp], xmm0
00007a3fbe1d50ab  vmovaps [rsp+0x10], xmm2
00007a3fbe1d50b1  vmovaps [rsp+0x20], xmm3
00007a3fbe1d50b7  vmovaps [rsp+0x30], xmm4
00007a3fbe1d50bd  vmovaps [rsp+0x40], xmm5
00007a3fbe1d50c3  vmovaps [rsp+0x50], xmm6
00007a3fbe1d50c9  vmovaps [rsp+0x60], xmm7
00007a3fbe1d50cf  vmovaps [rsp+0x70], xmm8
00007a3fbe1d50d5  vmovaps [rsp+0x80], xmm9
00007a3fbe1d50de  vmovaps [rsp+0x90], xmm10
00007a3fbe1d50e7  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d50f0  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d50f9  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d5102  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d510b  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d5114  sub rsp, 0x30
00007a3fbe1d5118  movaps [rsp], xmm1
00007a3fbe1d511c  movaps [rsp+0x10], xmm13
00007a3fbe1d5122  movaps [rsp+0x20], xmm2
00007a3fbe1d5127  lea rdi, [rsp]
00007a3fbe1d512b  mov esi, 0x00
00007a3fbe1d5130  mov rax, 0x60D1084DB530
00007a3fbe1d513a  call rax
00007a3fbe1d513c  movaps xmm1, [rsp]
00007a3fbe1d5140  add rsp, 0x30
00007a3fbe1d5144  vmovaps xmm0, [rsp]
00007a3fbe1d5149  vmovaps xmm2, [rsp+0x10]
00007a3fbe1d514f  vmovaps xmm3, [rsp+0x20]
00007a3fbe1d5155  vmovaps xmm4, [rsp+0x30]
00007a3fbe1d515b  vmovaps xmm5, [rsp+0x40]
00007a3fbe1d5161  vmovaps xmm6, [rsp+0x50]
00007a3fbe1d5167  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d516d  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d5173  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d517c  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d5185  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d518e  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d5197  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d51a0  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d51a9  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d51b2  add rsp, 0xF0
00007a3fbe1d51b9  pop r11
00007a3fbe1d51bb  pop r10
00007a3fbe1d51bd  pop r9
00007a3fbe1d51bf  pop r8
00007a3fbe1d51c1  pop rsi
00007a3fbe1d51c2  pop rdi
00007a3fbe1d51c3  pop rdx
00007a3fbe1d51c4  pop rcx
00007a3fbe1d51c5  pop rax
00007a3fbe1d51c6  add rsp, 0x08
00007a3fbe1d51ca  jmp 0x00007A3FBE1D2D79
00007a3fbe1d51cf  sub rsp, 0x08
00007a3fbe1d51d3  push rax
00007a3fbe1d51d4  push rcx
00007a3fbe1d51d5  push rdx
00007a3fbe1d51d6  push rdi
00007a3fbe1d51d7  push rsi
00007a3fbe1d51d8  push r8
00007a3fbe1d51da  push r9
00007a3fbe1d51dc  push r10
00007a3fbe1d51de  push r11
00007a3fbe1d51e0  sub rsp, 0xF0
00007a3fbe1d51e7  vmovaps [rsp], xmm0
00007a3fbe1d51ec  vmovaps [rsp+0x10], xmm1
00007a3fbe1d51f2  vmovaps [rsp+0x20], xmm3
00007a3fbe1d51f8  vmovaps [rsp+0x30], xmm4
00007a3fbe1d51fe  vmovaps [rsp+0x40], xmm5
00007a3fbe1d5204  vmovaps [rsp+0x50], xmm6
00007a3fbe1d520a  vmovaps [rsp+0x60], xmm7
00007a3fbe1d5210  vmovaps [rsp+0x70], xmm8
00007a3fbe1d5216  vmovaps [rsp+0x80], xmm9
00007a3fbe1d521f  vmovaps [rsp+0x90], xmm10
00007a3fbe1d5228  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d5231  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d523a  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d5243  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d524c  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d5255  sub rsp, 0x30
00007a3fbe1d5259  movaps [rsp], xmm2
00007a3fbe1d525d  movaps [rsp+0x10], xmm1
00007a3fbe1d5262  movaps [rsp+0x20], xmm13
00007a3fbe1d5268  lea rdi, [rsp]
00007a3fbe1d526c  mov esi, 0x00
00007a3fbe1d5271  mov rax, 0x60D1084DB530
00007a3fbe1d527b  call rax
00007a3fbe1d527d  movaps xmm2, [rsp]
00007a3fbe1d5281  add rsp, 0x30
00007a3fbe1d5285  vmovaps xmm0, [rsp]
00007a3fbe1d528a  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d5290  vmovaps xmm3, [rsp+0x20]
00007a3fbe1d5296  vmovaps xmm4, [rsp+0x30]
00007a3fbe1d529c  vmovaps xmm5, [rsp+0x40]
00007a3fbe1d52a2  vmovaps xmm6, [rsp+0x50]
00007a3fbe1d52a8  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d52ae  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d52b4  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d52bd  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d52c6  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d52cf  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d52d8  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d52e1  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d52ea  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d52f3  add rsp, 0xF0
00007a3fbe1d52fa  pop r11
00007a3fbe1d52fc  pop r10
00007a3fbe1d52fe  pop r9
00007a3fbe1d5300  pop r8
00007a3fbe1d5302  pop rsi
00007a3fbe1d5303  pop rdi
00007a3fbe1d5304  pop rdx
00007a3fbe1d5305  pop rcx
00007a3fbe1d5306  pop rax
00007a3fbe1d5307  add rsp, 0x08
00007a3fbe1d530b  jmp 0x00007A3FBE1D2DD2
00007a3fbe1d5310  call 0x00007A3FBDFFF430
00007a3fbe1d5315  jmp 0x00007A3FBE1D2DDF
00007a3fbe1d531a  sub rsp, 0x08
00007a3fbe1d531e  push rax
00007a3fbe1d531f  push rcx
00007a3fbe1d5320  push rdx
00007a3fbe1d5321  push rdi
00007a3fbe1d5322  push rsi
00007a3fbe1d5323  push r8
00007a3fbe1d5325  push r9
00007a3fbe1d5327  push r10
00007a3fbe1d5329  push r11
00007a3fbe1d532b  sub rsp, 0xF0
00007a3fbe1d5332  vmovaps [rsp], xmm0
00007a3fbe1d5337  vmovaps [rsp+0x10], xmm1
00007a3fbe1d533d  vmovaps [rsp+0x20], xmm2
00007a3fbe1d5343  vmovaps [rsp+0x30], xmm3
00007a3fbe1d5349  vmovaps [rsp+0x40], xmm4
00007a3fbe1d534f  vmovaps [rsp+0x50], xmm5
00007a3fbe1d5355  vmovaps [rsp+0x60], xmm6
00007a3fbe1d535b  vmovaps [rsp+0x70], xmm7
00007a3fbe1d5361  vmovaps [rsp+0x80], xmm8
00007a3fbe1d536a  vmovaps [rsp+0x90], xmm9
00007a3fbe1d5373  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d537c  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d5385  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d538e  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d5397  vmovaps [rsp+0xE0], xmm14
00007a3fbe1d53a0  sub rsp, 0x30
00007a3fbe1d53a4  movaps [rsp], xmm15
00007a3fbe1d53a9  movaps [rsp+0x10], xmm13
00007a3fbe1d53af  movaps [rsp+0x20], xmm1
00007a3fbe1d53b4  lea rdi, [rsp]
00007a3fbe1d53b8  mov esi, 0x00
00007a3fbe1d53bd  mov rax, 0x60D1084DB530
00007a3fbe1d53c7  call rax
00007a3fbe1d53c9  movaps xmm15, [rsp]
00007a3fbe1d53ce  add rsp, 0x30
00007a3fbe1d53d2  vmovaps xmm0, [rsp]
00007a3fbe1d53d7  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d53dd  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d53e3  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d53e9  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d53ef  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d53f5  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d53fb  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d5401  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d540a  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d5413  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d541c  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d5425  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d542e  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d5437  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1d5440  add rsp, 0xF0
00007a3fbe1d5447  pop r11
00007a3fbe1d5449  pop r10
00007a3fbe1d544b  pop r9
00007a3fbe1d544d  pop r8
00007a3fbe1d544f  pop rsi
00007a3fbe1d5450  pop rdi
00007a3fbe1d5451  pop rdx
00007a3fbe1d5452  pop rcx
00007a3fbe1d5453  pop rax
00007a3fbe1d5454  add rsp, 0x08
00007a3fbe1d5458  jmp 0x00007A3FBE1D2E1E
00007a3fbe1d545d  sub rsp, 0x08
00007a3fbe1d5461  push rax
00007a3fbe1d5462  push rcx
00007a3fbe1d5463  push rdx
00007a3fbe1d5464  push rdi
00007a3fbe1d5465  push rsi
00007a3fbe1d5466  push r8
00007a3fbe1d5468  push r9
00007a3fbe1d546a  push r10
00007a3fbe1d546c  push r11
00007a3fbe1d546e  sub rsp, 0xF0
00007a3fbe1d5475  vmovaps [rsp], xmm0
00007a3fbe1d547a  vmovaps [rsp+0x10], xmm1
00007a3fbe1d5480  vmovaps [rsp+0x20], xmm2
00007a3fbe1d5486  vmovaps [rsp+0x30], xmm3
00007a3fbe1d548c  vmovaps [rsp+0x40], xmm4
00007a3fbe1d5492  vmovaps [rsp+0x50], xmm5
00007a3fbe1d5498  vmovaps [rsp+0x60], xmm6
00007a3fbe1d549e  vmovaps [rsp+0x70], xmm7
00007a3fbe1d54a4  vmovaps [rsp+0x80], xmm8
00007a3fbe1d54ad  vmovaps [rsp+0x90], xmm9
00007a3fbe1d54b6  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d54bf  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d54c8  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d54d1  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d54da  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d54e3  sub rsp, 0x30
00007a3fbe1d54e7  movaps [rsp], xmm14
00007a3fbe1d54ec  movaps [rsp+0x10], xmm11
00007a3fbe1d54f2  movaps [rsp+0x20], xmm1
00007a3fbe1d54f7  lea rdi, [rsp]
00007a3fbe1d54fb  mov esi, 0x00
00007a3fbe1d5500  mov rax, 0x60D1084DB530
00007a3fbe1d550a  call rax
00007a3fbe1d550c  movaps xmm14, [rsp]
00007a3fbe1d5511  add rsp, 0x30
00007a3fbe1d5515  vmovaps xmm0, [rsp]
00007a3fbe1d551a  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d5520  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d5526  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d552c  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d5532  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d5538  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d553e  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d5544  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d554d  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d5556  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d555f  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d5568  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d5571  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d557a  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d5583  add rsp, 0xF0
00007a3fbe1d558a  pop r11
00007a3fbe1d558c  pop r10
00007a3fbe1d558e  pop r9
00007a3fbe1d5590  pop r8
00007a3fbe1d5592  pop rsi
00007a3fbe1d5593  pop rdi
00007a3fbe1d5594  pop rdx
00007a3fbe1d5595  pop rcx
00007a3fbe1d5596  pop rax
00007a3fbe1d5597  add rsp, 0x08
00007a3fbe1d559b  jmp 0x00007A3FBE1D2E48
00007a3fbe1d55a0  sub rsp, 0x08
00007a3fbe1d55a4  push rax
00007a3fbe1d55a5  push rcx
00007a3fbe1d55a6  push rdx
00007a3fbe1d55a7  push rdi
00007a3fbe1d55a8  push rsi
00007a3fbe1d55a9  push r8
00007a3fbe1d55ab  push r9
00007a3fbe1d55ad  push r10
00007a3fbe1d55af  push r11
00007a3fbe1d55b1  sub rsp, 0xF0
00007a3fbe1d55b8  vmovaps [rsp], xmm0
00007a3fbe1d55bd  vmovaps [rsp+0x10], xmm1
00007a3fbe1d55c3  vmovaps [rsp+0x20], xmm2
00007a3fbe1d55c9  vmovaps [rsp+0x30], xmm3
00007a3fbe1d55cf  vmovaps [rsp+0x40], xmm4
00007a3fbe1d55d5  vmovaps [rsp+0x50], xmm5
00007a3fbe1d55db  vmovaps [rsp+0x60], xmm6
00007a3fbe1d55e1  vmovaps [rsp+0x70], xmm7
00007a3fbe1d55e7  vmovaps [rsp+0x80], xmm8
00007a3fbe1d55f0  vmovaps [rsp+0x90], xmm9
00007a3fbe1d55f9  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d5602  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d560b  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d5614  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d561d  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d5626  sub rsp, 0x30
00007a3fbe1d562a  movaps [rsp], xmm13
00007a3fbe1d562f  movaps [rsp+0x10], xmm11
00007a3fbe1d5635  movaps [rsp+0x20], xmm1
00007a3fbe1d563a  lea rdi, [rsp]
00007a3fbe1d563e  mov esi, 0x00
00007a3fbe1d5643  mov rax, 0x60D1084DB530
00007a3fbe1d564d  call rax
00007a3fbe1d564f  movaps xmm13, [rsp]
00007a3fbe1d5654  add rsp, 0x30
00007a3fbe1d5658  vmovaps xmm0, [rsp]
00007a3fbe1d565d  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d5663  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d5669  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d566f  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d5675  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d567b  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d5681  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d5687  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d5690  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d5699  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d56a2  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d56ab  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d56b4  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d56bd  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d56c6  add rsp, 0xF0
00007a3fbe1d56cd  pop r11
00007a3fbe1d56cf  pop r10
00007a3fbe1d56d1  pop r9
00007a3fbe1d56d3  pop r8
00007a3fbe1d56d5  pop rsi
00007a3fbe1d56d6  pop rdi
00007a3fbe1d56d7  pop rdx
00007a3fbe1d56d8  pop rcx
00007a3fbe1d56d9  pop rax
00007a3fbe1d56da  add rsp, 0x08
00007a3fbe1d56de  jmp 0x00007A3FBE1D2E9D
00007a3fbe1d56e3  call 0x00007A3FBDFFF430
00007a3fbe1d56e8  jmp 0x00007A3FBE1D2EAA
00007a3fbe1d56ed  sub rsp, 0x08
00007a3fbe1d56f1  push rax
00007a3fbe1d56f2  push rcx
00007a3fbe1d56f3  push rdx
00007a3fbe1d56f4  push rdi
00007a3fbe1d56f5  push rsi
00007a3fbe1d56f6  push r8
00007a3fbe1d56f8  push r9
00007a3fbe1d56fa  push r10
00007a3fbe1d56fc  push r11
00007a3fbe1d56fe  sub rsp, 0xF0
00007a3fbe1d5705  vmovaps [rsp], xmm0
00007a3fbe1d570a  vmovaps [rsp+0x10], xmm1
00007a3fbe1d5710  vmovaps [rsp+0x20], xmm2
00007a3fbe1d5716  vmovaps [rsp+0x30], xmm3
00007a3fbe1d571c  vmovaps [rsp+0x40], xmm4
00007a3fbe1d5722  vmovaps [rsp+0x50], xmm5
00007a3fbe1d5728  vmovaps [rsp+0x60], xmm6
00007a3fbe1d572e  vmovaps [rsp+0x70], xmm7
00007a3fbe1d5734  vmovaps [rsp+0x80], xmm8
00007a3fbe1d573d  vmovaps [rsp+0x90], xmm9
00007a3fbe1d5746  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d574f  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d5758  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d5761  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d576a  vmovaps [rsp+0xE0], xmm14
00007a3fbe1d5773  sub rsp, 0x30
00007a3fbe1d5777  movaps [rsp], xmm15
00007a3fbe1d577c  movaps [rsp+0x10], xmm11
00007a3fbe1d5782  movaps [rsp+0x20], xmm1
00007a3fbe1d5787  lea rdi, [rsp]
00007a3fbe1d578b  mov esi, 0x00
00007a3fbe1d5790  mov rax, 0x60D1084DB530
00007a3fbe1d579a  call rax
00007a3fbe1d579c  movaps xmm15, [rsp]
00007a3fbe1d57a1  add rsp, 0x30
00007a3fbe1d57a5  vmovaps xmm0, [rsp]
00007a3fbe1d57aa  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d57b0  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d57b6  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d57bc  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d57c2  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d57c8  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d57ce  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d57d4  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d57dd  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d57e6  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d57ef  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d57f8  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d5801  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d580a  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1d5813  add rsp, 0xF0
00007a3fbe1d581a  pop r11
00007a3fbe1d581c  pop r10
00007a3fbe1d581e  pop r9
00007a3fbe1d5820  pop r8
00007a3fbe1d5822  pop rsi
00007a3fbe1d5823  pop rdi
00007a3fbe1d5824  pop rdx
00007a3fbe1d5825  pop rcx
00007a3fbe1d5826  pop rax
00007a3fbe1d5827  add rsp, 0x08
00007a3fbe1d582b  jmp 0x00007A3FBE1D2EE3
00007a3fbe1d5830  sub rsp, 0x08
00007a3fbe1d5834  push rax
00007a3fbe1d5835  push rcx
00007a3fbe1d5836  push rdx
00007a3fbe1d5837  push rdi
00007a3fbe1d5838  push rsi
00007a3fbe1d5839  push r8
00007a3fbe1d583b  push r9
00007a3fbe1d583d  push r10
00007a3fbe1d583f  push r11
00007a3fbe1d5841  sub rsp, 0xF0
00007a3fbe1d5848  vmovaps [rsp], xmm0
00007a3fbe1d584d  vmovaps [rsp+0x10], xmm1
00007a3fbe1d5853  vmovaps [rsp+0x20], xmm2
00007a3fbe1d5859  vmovaps [rsp+0x30], xmm3
00007a3fbe1d585f  vmovaps [rsp+0x40], xmm4
00007a3fbe1d5865  vmovaps [rsp+0x50], xmm5
00007a3fbe1d586b  vmovaps [rsp+0x60], xmm6
00007a3fbe1d5871  vmovaps [rsp+0x70], xmm7
00007a3fbe1d5877  vmovaps [rsp+0x80], xmm8
00007a3fbe1d5880  vmovaps [rsp+0x90], xmm9
00007a3fbe1d5889  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d5892  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d589b  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d58a4  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d58ad  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d58b6  sub rsp, 0x30
00007a3fbe1d58ba  movaps [rsp], xmm11
00007a3fbe1d58bf  movaps [rsp+0x10], xmm6
00007a3fbe1d58c4  movaps [rsp+0x20], xmm14
00007a3fbe1d58ca  lea rdi, [rsp]
00007a3fbe1d58ce  mov esi, 0x00
00007a3fbe1d58d3  mov rax, 0x60D1084DB530
00007a3fbe1d58dd  call rax
00007a3fbe1d58df  movaps xmm11, [rsp]
00007a3fbe1d58e4  add rsp, 0x30
00007a3fbe1d58e8  vmovaps xmm0, [rsp]
00007a3fbe1d58ed  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d58f3  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d58f9  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d58ff  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d5905  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d590b  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d5911  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d5917  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d5920  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d5929  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d5932  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d593b  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d5944  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d594d  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d5956  add rsp, 0xF0
00007a3fbe1d595d  pop r11
00007a3fbe1d595f  pop r10
00007a3fbe1d5961  pop r9
00007a3fbe1d5963  pop r8
00007a3fbe1d5965  pop rsi
00007a3fbe1d5966  pop rdi
00007a3fbe1d5967  pop rdx
00007a3fbe1d5968  pop rcx
00007a3fbe1d5969  pop rax
00007a3fbe1d596a  add rsp, 0x08
00007a3fbe1d596e  jmp 0x00007A3FBE1D2F5B
00007a3fbe1d5973  call 0x00007A3FBDFFF430
00007a3fbe1d5978  jmp 0x00007A3FBE1D2F65
00007a3fbe1d597d  sub rsp, 0x08
00007a3fbe1d5981  push rax
00007a3fbe1d5982  push rcx
00007a3fbe1d5983  push rdx
00007a3fbe1d5984  push rdi
00007a3fbe1d5985  push rsi
00007a3fbe1d5986  push r8
00007a3fbe1d5988  push r9
00007a3fbe1d598a  push r10
00007a3fbe1d598c  push r11
00007a3fbe1d598e  sub rsp, 0xF0
00007a3fbe1d5995  vmovaps [rsp], xmm0
00007a3fbe1d599a  vmovaps [rsp+0x10], xmm1
00007a3fbe1d59a0  vmovaps [rsp+0x20], xmm2
00007a3fbe1d59a6  vmovaps [rsp+0x30], xmm3
00007a3fbe1d59ac  vmovaps [rsp+0x40], xmm4
00007a3fbe1d59b2  vmovaps [rsp+0x50], xmm5
00007a3fbe1d59b8  vmovaps [rsp+0x60], xmm6
00007a3fbe1d59be  vmovaps [rsp+0x70], xmm7
00007a3fbe1d59c4  vmovaps [rsp+0x80], xmm8
00007a3fbe1d59cd  vmovaps [rsp+0x90], xmm9
00007a3fbe1d59d6  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d59df  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d59e8  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d59f1  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d59fa  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d5a03  sub rsp, 0x30
00007a3fbe1d5a07  movaps [rsp], xmm14
00007a3fbe1d5a0c  movaps [rsp+0x10], xmm6
00007a3fbe1d5a11  movaps [rsp+0x20], xmm2
00007a3fbe1d5a16  lea rdi, [rsp]
00007a3fbe1d5a1a  mov esi, 0x00
00007a3fbe1d5a1f  mov rax, 0x60D1084DB530
00007a3fbe1d5a29  call rax
00007a3fbe1d5a2b  movaps xmm14, [rsp]
00007a3fbe1d5a30  add rsp, 0x30
00007a3fbe1d5a34  vmovaps xmm0, [rsp]
00007a3fbe1d5a39  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d5a3f  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d5a45  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d5a4b  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d5a51  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d5a57  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d5a5d  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d5a63  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d5a6c  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d5a75  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d5a7e  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d5a87  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d5a90  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d5a99  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d5aa2  add rsp, 0xF0
00007a3fbe1d5aa9  pop r11
00007a3fbe1d5aab  pop r10
00007a3fbe1d5aad  pop r9
00007a3fbe1d5aaf  pop r8
00007a3fbe1d5ab1  pop rsi
00007a3fbe1d5ab2  pop rdi
00007a3fbe1d5ab3  pop rdx
00007a3fbe1d5ab4  pop rcx
00007a3fbe1d5ab5  pop rax
00007a3fbe1d5ab6  add rsp, 0x08
00007a3fbe1d5aba  jmp 0x00007A3FBE1D2F99
00007a3fbe1d5abf  sub rsp, 0x08
00007a3fbe1d5ac3  push rax
00007a3fbe1d5ac4  push rcx
00007a3fbe1d5ac5  push rdx
00007a3fbe1d5ac6  push rdi
00007a3fbe1d5ac7  push rsi
00007a3fbe1d5ac8  push r8
00007a3fbe1d5aca  push r9
00007a3fbe1d5acc  push r10
00007a3fbe1d5ace  push r11
00007a3fbe1d5ad0  sub rsp, 0xF0
00007a3fbe1d5ad7  vmovaps [rsp], xmm0
00007a3fbe1d5adc  vmovaps [rsp+0x10], xmm1
00007a3fbe1d5ae2  vmovaps [rsp+0x20], xmm2
00007a3fbe1d5ae8  vmovaps [rsp+0x30], xmm3
00007a3fbe1d5aee  vmovaps [rsp+0x40], xmm4
00007a3fbe1d5af4  vmovaps [rsp+0x50], xmm5
00007a3fbe1d5afa  vmovaps [rsp+0x60], xmm7
00007a3fbe1d5b00  vmovaps [rsp+0x70], xmm8
00007a3fbe1d5b06  vmovaps [rsp+0x80], xmm9
00007a3fbe1d5b0f  vmovaps [rsp+0x90], xmm10
00007a3fbe1d5b18  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d5b21  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d5b2a  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d5b33  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d5b3c  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d5b45  sub rsp, 0x30
00007a3fbe1d5b49  movaps [rsp], xmm6
00007a3fbe1d5b4d  movaps [rsp+0x10], xmm5
00007a3fbe1d5b52  movaps [rsp+0x20], xmm1
00007a3fbe1d5b57  lea rdi, [rsp]
00007a3fbe1d5b5b  mov esi, 0x00
00007a3fbe1d5b60  mov rax, 0x60D1084DB530
00007a3fbe1d5b6a  call rax
00007a3fbe1d5b6c  movaps xmm6, [rsp]
00007a3fbe1d5b70  add rsp, 0x30
00007a3fbe1d5b74  vmovaps xmm0, [rsp]
00007a3fbe1d5b79  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d5b7f  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d5b85  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d5b8b  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d5b91  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d5b97  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d5b9d  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d5ba3  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d5bac  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d5bb5  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d5bbe  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d5bc7  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d5bd0  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d5bd9  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d5be2  add rsp, 0xF0
00007a3fbe1d5be9  pop r11
00007a3fbe1d5beb  pop r10
00007a3fbe1d5bed  pop r9
00007a3fbe1d5bef  pop r8
00007a3fbe1d5bf1  pop rsi
00007a3fbe1d5bf2  pop rdi
00007a3fbe1d5bf3  pop rdx
00007a3fbe1d5bf4  pop rcx
00007a3fbe1d5bf5  pop rax
00007a3fbe1d5bf6  add rsp, 0x08
00007a3fbe1d5bfa  jmp 0x00007A3FBE1D2FBF
00007a3fbe1d5bff  sub rsp, 0x08
00007a3fbe1d5c03  push rax
00007a3fbe1d5c04  push rcx
00007a3fbe1d5c05  push rdx
00007a3fbe1d5c06  push rdi
00007a3fbe1d5c07  push rsi
00007a3fbe1d5c08  push r8
00007a3fbe1d5c0a  push r9
00007a3fbe1d5c0c  push r10
00007a3fbe1d5c0e  push r11
00007a3fbe1d5c10  sub rsp, 0xF0
00007a3fbe1d5c17  vmovaps [rsp], xmm0
00007a3fbe1d5c1c  vmovaps [rsp+0x10], xmm2
00007a3fbe1d5c22  vmovaps [rsp+0x20], xmm3
00007a3fbe1d5c28  vmovaps [rsp+0x30], xmm4
00007a3fbe1d5c2e  vmovaps [rsp+0x40], xmm5
00007a3fbe1d5c34  vmovaps [rsp+0x50], xmm6
00007a3fbe1d5c3a  vmovaps [rsp+0x60], xmm7
00007a3fbe1d5c40  vmovaps [rsp+0x70], xmm8
00007a3fbe1d5c46  vmovaps [rsp+0x80], xmm9
00007a3fbe1d5c4f  vmovaps [rsp+0x90], xmm10
00007a3fbe1d5c58  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d5c61  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d5c6a  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d5c73  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d5c7c  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d5c85  sub rsp, 0x30
00007a3fbe1d5c89  movaps [rsp], xmm1
00007a3fbe1d5c8d  movaps [rsp+0x10], xmm5
00007a3fbe1d5c92  movaps [rsp+0x20], xmm13
00007a3fbe1d5c98  lea rdi, [rsp]
00007a3fbe1d5c9c  mov esi, 0x00
00007a3fbe1d5ca1  mov rax, 0x60D1084DB530
00007a3fbe1d5cab  call rax
00007a3fbe1d5cad  movaps xmm1, [rsp]
00007a3fbe1d5cb1  add rsp, 0x30
00007a3fbe1d5cb5  vmovaps xmm0, [rsp]
00007a3fbe1d5cba  vmovaps xmm2, [rsp+0x10]
00007a3fbe1d5cc0  vmovaps xmm3, [rsp+0x20]
00007a3fbe1d5cc6  vmovaps xmm4, [rsp+0x30]
00007a3fbe1d5ccc  vmovaps xmm5, [rsp+0x40]
00007a3fbe1d5cd2  vmovaps xmm6, [rsp+0x50]
00007a3fbe1d5cd8  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d5cde  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d5ce4  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d5ced  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d5cf6  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d5cff  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d5d08  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d5d11  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d5d1a  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d5d23  add rsp, 0xF0
00007a3fbe1d5d2a  pop r11
00007a3fbe1d5d2c  pop r10
00007a3fbe1d5d2e  pop r9
00007a3fbe1d5d30  pop r8
00007a3fbe1d5d32  pop rsi
00007a3fbe1d5d33  pop rdi
00007a3fbe1d5d34  pop rdx
00007a3fbe1d5d35  pop rcx
00007a3fbe1d5d36  pop rax
00007a3fbe1d5d37  add rsp, 0x08
00007a3fbe1d5d3b  jmp 0x00007A3FBE1D2FDD
00007a3fbe1d5d40  sub rsp, 0x08
00007a3fbe1d5d44  push rax
00007a3fbe1d5d45  push rcx
00007a3fbe1d5d46  push rdx
00007a3fbe1d5d47  push rdi
00007a3fbe1d5d48  push rsi
00007a3fbe1d5d49  push r8
00007a3fbe1d5d4b  push r9
00007a3fbe1d5d4d  push r10
00007a3fbe1d5d4f  push r11
00007a3fbe1d5d51  sub rsp, 0xF0
00007a3fbe1d5d58  vmovaps [rsp], xmm0
00007a3fbe1d5d5d  vmovaps [rsp+0x10], xmm1
00007a3fbe1d5d63  vmovaps [rsp+0x20], xmm2
00007a3fbe1d5d69  vmovaps [rsp+0x30], xmm3
00007a3fbe1d5d6f  vmovaps [rsp+0x40], xmm4
00007a3fbe1d5d75  vmovaps [rsp+0x50], xmm6
00007a3fbe1d5d7b  vmovaps [rsp+0x60], xmm7
00007a3fbe1d5d81  vmovaps [rsp+0x70], xmm8
00007a3fbe1d5d87  vmovaps [rsp+0x80], xmm9
00007a3fbe1d5d90  vmovaps [rsp+0x90], xmm10
00007a3fbe1d5d99  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d5da2  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d5dab  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d5db4  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d5dbd  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d5dc6  sub rsp, 0x30
00007a3fbe1d5dca  movaps [rsp], xmm5
00007a3fbe1d5dce  movaps [rsp+0x10], xmm2
00007a3fbe1d5dd3  movaps [rsp+0x20], xmm13
00007a3fbe1d5dd9  lea rdi, [rsp]
00007a3fbe1d5ddd  mov esi, 0x00
00007a3fbe1d5de2  mov rax, 0x60D1084DB530
00007a3fbe1d5dec  call rax
00007a3fbe1d5dee  movaps xmm5, [rsp]
00007a3fbe1d5df2  add rsp, 0x30
00007a3fbe1d5df6  vmovaps xmm0, [rsp]
00007a3fbe1d5dfb  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d5e01  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d5e07  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d5e0d  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d5e13  vmovaps xmm6, [rsp+0x50]
00007a3fbe1d5e19  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d5e1f  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d5e25  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d5e2e  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d5e37  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d5e40  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d5e49  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d5e52  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d5e5b  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d5e64  add rsp, 0xF0
00007a3fbe1d5e6b  pop r11
00007a3fbe1d5e6d  pop r10
00007a3fbe1d5e6f  pop r9
00007a3fbe1d5e71  pop r8
00007a3fbe1d5e73  pop rsi
00007a3fbe1d5e74  pop rdi
00007a3fbe1d5e75  pop rdx
00007a3fbe1d5e76  pop rcx
00007a3fbe1d5e77  pop rax
00007a3fbe1d5e78  add rsp, 0x08
00007a3fbe1d5e7c  jmp 0x00007A3FBE1D3013
00007a3fbe1d5e81  sub rsp, 0x08
00007a3fbe1d5e85  push rax
00007a3fbe1d5e86  push rcx
00007a3fbe1d5e87  push rdx
00007a3fbe1d5e88  push rdi
00007a3fbe1d5e89  push rsi
00007a3fbe1d5e8a  push r8
00007a3fbe1d5e8c  push r9
00007a3fbe1d5e8e  push r10
00007a3fbe1d5e90  push r11
00007a3fbe1d5e92  sub rsp, 0xF0
00007a3fbe1d5e99  vmovaps [rsp], xmm0
00007a3fbe1d5e9e  vmovaps [rsp+0x10], xmm1
00007a3fbe1d5ea4  vmovaps [rsp+0x20], xmm2
00007a3fbe1d5eaa  vmovaps [rsp+0x30], xmm3
00007a3fbe1d5eb0  vmovaps [rsp+0x40], xmm4
00007a3fbe1d5eb6  vmovaps [rsp+0x50], xmm5
00007a3fbe1d5ebc  vmovaps [rsp+0x60], xmm6
00007a3fbe1d5ec2  vmovaps [rsp+0x70], xmm7
00007a3fbe1d5ec8  vmovaps [rsp+0x80], xmm8
00007a3fbe1d5ed1  vmovaps [rsp+0x90], xmm9
00007a3fbe1d5eda  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d5ee3  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d5eec  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d5ef5  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d5efe  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d5f07  sub rsp, 0x30
00007a3fbe1d5f0b  movaps [rsp], xmm13
00007a3fbe1d5f10  movaps [rsp+0x10], xmm10
00007a3fbe1d5f16  movaps [rsp+0x20], xmm1
00007a3fbe1d5f1b  lea rdi, [rsp]
00007a3fbe1d5f1f  mov esi, 0x00
00007a3fbe1d5f24  mov rax, 0x60D1084DB530
00007a3fbe1d5f2e  call rax
00007a3fbe1d5f30  movaps xmm13, [rsp]
00007a3fbe1d5f35  add rsp, 0x30
00007a3fbe1d5f39  vmovaps xmm0, [rsp]
00007a3fbe1d5f3e  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d5f44  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d5f4a  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d5f50  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d5f56  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d5f5c  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d5f62  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d5f68  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d5f71  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d5f7a  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d5f83  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d5f8c  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d5f95  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d5f9e  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d5fa7  add rsp, 0xF0
00007a3fbe1d5fae  pop r11
00007a3fbe1d5fb0  pop r10
00007a3fbe1d5fb2  pop r9
00007a3fbe1d5fb4  pop r8
00007a3fbe1d5fb6  pop rsi
00007a3fbe1d5fb7  pop rdi
00007a3fbe1d5fb8  pop rdx
00007a3fbe1d5fb9  pop rcx
00007a3fbe1d5fba  pop rax
00007a3fbe1d5fbb  add rsp, 0x08
00007a3fbe1d5fbf  jmp 0x00007A3FBE1D303C
00007a3fbe1d5fc4  sub rsp, 0x08
00007a3fbe1d5fc8  push rax
00007a3fbe1d5fc9  push rcx
00007a3fbe1d5fca  push rdx
00007a3fbe1d5fcb  push rdi
00007a3fbe1d5fcc  push rsi
00007a3fbe1d5fcd  push r8
00007a3fbe1d5fcf  push r9
00007a3fbe1d5fd1  push r10
00007a3fbe1d5fd3  push r11
00007a3fbe1d5fd5  sub rsp, 0xF0
00007a3fbe1d5fdc  vmovaps [rsp], xmm0
00007a3fbe1d5fe1  vmovaps [rsp+0x10], xmm2
00007a3fbe1d5fe7  vmovaps [rsp+0x20], xmm3
00007a3fbe1d5fed  vmovaps [rsp+0x30], xmm4
00007a3fbe1d5ff3  vmovaps [rsp+0x40], xmm5
00007a3fbe1d5ff9  vmovaps [rsp+0x50], xmm6
00007a3fbe1d5fff  vmovaps [rsp+0x60], xmm7
00007a3fbe1d6005  vmovaps [rsp+0x70], xmm8
00007a3fbe1d600b  vmovaps [rsp+0x80], xmm9
00007a3fbe1d6014  vmovaps [rsp+0x90], xmm10
00007a3fbe1d601d  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d6026  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d602f  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d6038  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d6041  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d604a  sub rsp, 0x30
00007a3fbe1d604e  movaps [rsp], xmm1
00007a3fbe1d6052  movaps [rsp+0x10], xmm15
00007a3fbe1d6058  movaps [rsp+0x20], xmm10
00007a3fbe1d605e  lea rdi, [rsp]
00007a3fbe1d6062  mov esi, 0x00
00007a3fbe1d6067  mov rax, 0x60D1084DB530
00007a3fbe1d6071  call rax
00007a3fbe1d6073  movaps xmm1, [rsp]
00007a3fbe1d6077  add rsp, 0x30
00007a3fbe1d607b  vmovaps xmm0, [rsp]
00007a3fbe1d6080  vmovaps xmm2, [rsp+0x10]
00007a3fbe1d6086  vmovaps xmm3, [rsp+0x20]
00007a3fbe1d608c  vmovaps xmm4, [rsp+0x30]
00007a3fbe1d6092  vmovaps xmm5, [rsp+0x40]
00007a3fbe1d6098  vmovaps xmm6, [rsp+0x50]
00007a3fbe1d609e  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d60a4  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d60aa  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d60b3  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d60bc  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d60c5  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d60ce  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d60d7  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d60e0  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d60e9  add rsp, 0xF0
00007a3fbe1d60f0  pop r11
00007a3fbe1d60f2  pop r10
00007a3fbe1d60f4  pop r9
00007a3fbe1d60f6  pop r8
00007a3fbe1d60f8  pop rsi
00007a3fbe1d60f9  pop rdi
00007a3fbe1d60fa  pop rdx
00007a3fbe1d60fb  pop rcx
00007a3fbe1d60fc  pop rax
00007a3fbe1d60fd  add rsp, 0x08
00007a3fbe1d6101  jmp 0x00007A3FBE1D305B
00007a3fbe1d6106  sub rsp, 0x08
00007a3fbe1d610a  push rax
00007a3fbe1d610b  push rcx
00007a3fbe1d610c  push rdx
00007a3fbe1d610d  push rdi
00007a3fbe1d610e  push rsi
00007a3fbe1d610f  push r8
00007a3fbe1d6111  push r9
00007a3fbe1d6113  push r10
00007a3fbe1d6115  push r11
00007a3fbe1d6117  sub rsp, 0xF0
00007a3fbe1d611e  vmovaps [rsp], xmm0
00007a3fbe1d6123  vmovaps [rsp+0x10], xmm1
00007a3fbe1d6129  vmovaps [rsp+0x20], xmm2
00007a3fbe1d612f  vmovaps [rsp+0x30], xmm3
00007a3fbe1d6135  vmovaps [rsp+0x40], xmm4
00007a3fbe1d613b  vmovaps [rsp+0x50], xmm5
00007a3fbe1d6141  vmovaps [rsp+0x60], xmm6
00007a3fbe1d6147  vmovaps [rsp+0x70], xmm7
00007a3fbe1d614d  vmovaps [rsp+0x80], xmm8
00007a3fbe1d6156  vmovaps [rsp+0x90], xmm9
00007a3fbe1d615f  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d6168  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d6171  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d617a  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d6183  vmovaps [rsp+0xE0], xmm14
00007a3fbe1d618c  sub rsp, 0x30
00007a3fbe1d6190  movaps [rsp], xmm15
00007a3fbe1d6195  movaps [rsp+0x10], xmm10
00007a3fbe1d619b  movaps [rsp+0x20], xmm11
00007a3fbe1d61a1  lea rdi, [rsp]
00007a3fbe1d61a5  mov esi, 0x00
00007a3fbe1d61aa  mov rax, 0x60D1084DB530
00007a3fbe1d61b4  call rax
00007a3fbe1d61b6  movaps xmm15, [rsp]
00007a3fbe1d61bb  add rsp, 0x30
00007a3fbe1d61bf  vmovaps xmm0, [rsp]
00007a3fbe1d61c4  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d61ca  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d61d0  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d61d6  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d61dc  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d61e2  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d61e8  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d61ee  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d61f7  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d6200  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d6209  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d6212  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d621b  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d6224  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1d622d  add rsp, 0xF0
00007a3fbe1d6234  pop r11
00007a3fbe1d6236  pop r10
00007a3fbe1d6238  pop r9
00007a3fbe1d623a  pop r8
00007a3fbe1d623c  pop rsi
00007a3fbe1d623d  pop rdi
00007a3fbe1d623e  pop rdx
00007a3fbe1d623f  pop rcx
00007a3fbe1d6240  pop rax
00007a3fbe1d6241  add rsp, 0x08
00007a3fbe1d6245  jmp 0x00007A3FBE1D307E
00007a3fbe1d624a  sub rsp, 0x08
00007a3fbe1d624e  push rax
00007a3fbe1d624f  push rcx
00007a3fbe1d6250  push rdx
00007a3fbe1d6251  push rdi
00007a3fbe1d6252  push rsi
00007a3fbe1d6253  push r8
00007a3fbe1d6255  push r9
00007a3fbe1d6257  push r10
00007a3fbe1d6259  push r11
00007a3fbe1d625b  sub rsp, 0xF0
00007a3fbe1d6262  vmovaps [rsp], xmm0
00007a3fbe1d6267  vmovaps [rsp+0x10], xmm1
00007a3fbe1d626d  vmovaps [rsp+0x20], xmm2
00007a3fbe1d6273  vmovaps [rsp+0x30], xmm3
00007a3fbe1d6279  vmovaps [rsp+0x40], xmm4
00007a3fbe1d627f  vmovaps [rsp+0x50], xmm5
00007a3fbe1d6285  vmovaps [rsp+0x60], xmm6
00007a3fbe1d628b  vmovaps [rsp+0x70], xmm7
00007a3fbe1d6291  vmovaps [rsp+0x80], xmm8
00007a3fbe1d629a  vmovaps [rsp+0x90], xmm9
00007a3fbe1d62a3  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d62ac  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d62b5  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d62be  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d62c7  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d62d0  sub rsp, 0x30
00007a3fbe1d62d4  movaps [rsp], xmm10
00007a3fbe1d62d9  movaps [rsp+0x10], xmm2
00007a3fbe1d62de  movaps [rsp+0x20], xmm11
00007a3fbe1d62e4  lea rdi, [rsp]
00007a3fbe1d62e8  mov esi, 0x00
00007a3fbe1d62ed  mov rax, 0x60D1084DB530
00007a3fbe1d62f7  call rax
00007a3fbe1d62f9  movaps xmm10, [rsp]
00007a3fbe1d62fe  add rsp, 0x30
00007a3fbe1d6302  vmovaps xmm0, [rsp]
00007a3fbe1d6307  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d630d  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d6313  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d6319  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d631f  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d6325  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d632b  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d6331  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d633a  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d6343  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d634c  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d6355  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d635e  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d6367  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d6370  add rsp, 0xF0
00007a3fbe1d6377  pop r11
00007a3fbe1d6379  pop r10
00007a3fbe1d637b  pop r9
00007a3fbe1d637d  pop r8
00007a3fbe1d637f  pop rsi
00007a3fbe1d6380  pop rdi
00007a3fbe1d6381  pop rdx
00007a3fbe1d6382  pop rcx
00007a3fbe1d6383  pop rax
00007a3fbe1d6384  add rsp, 0x08
00007a3fbe1d6388  jmp 0x00007A3FBE1D30B6
00007a3fbe1d638d  sub rsp, 0x08
00007a3fbe1d6391  push rax
00007a3fbe1d6392  push rcx
00007a3fbe1d6393  push rdx
00007a3fbe1d6394  push rdi
00007a3fbe1d6395  push rsi
00007a3fbe1d6396  push r8
00007a3fbe1d6398  push r9
00007a3fbe1d639a  push r10
00007a3fbe1d639c  push r11
00007a3fbe1d639e  sub rsp, 0xF0
00007a3fbe1d63a5  vmovaps [rsp], xmm0
00007a3fbe1d63aa  vmovaps [rsp+0x10], xmm1
00007a3fbe1d63b0  vmovaps [rsp+0x20], xmm2
00007a3fbe1d63b6  vmovaps [rsp+0x30], xmm3
00007a3fbe1d63bc  vmovaps [rsp+0x40], xmm4
00007a3fbe1d63c2  vmovaps [rsp+0x50], xmm5
00007a3fbe1d63c8  vmovaps [rsp+0x60], xmm6
00007a3fbe1d63ce  vmovaps [rsp+0x70], xmm7
00007a3fbe1d63d4  vmovaps [rsp+0x80], xmm8
00007a3fbe1d63dd  vmovaps [rsp+0x90], xmm9
00007a3fbe1d63e6  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d63ef  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d63f8  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d6401  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d640a  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d6413  sub rsp, 0x30
00007a3fbe1d6417  movaps [rsp], xmm11
00007a3fbe1d641c  movaps [rsp+0x10], xmm2
00007a3fbe1d6421  movaps [rsp+0x20], xmm1
00007a3fbe1d6426  lea rdi, [rsp]
00007a3fbe1d642a  mov esi, 0x00
00007a3fbe1d642f  mov rax, 0x60D1084DB530
00007a3fbe1d6439  call rax
00007a3fbe1d643b  movaps xmm11, [rsp]
00007a3fbe1d6440  add rsp, 0x30
00007a3fbe1d6444  vmovaps xmm0, [rsp]
00007a3fbe1d6449  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d644f  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d6455  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d645b  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d6461  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d6467  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d646d  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d6473  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d647c  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d6485  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d648e  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d6497  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d64a0  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d64a9  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d64b2  add rsp, 0xF0
00007a3fbe1d64b9  pop r11
00007a3fbe1d64bb  pop r10
00007a3fbe1d64bd  pop r9
00007a3fbe1d64bf  pop r8
00007a3fbe1d64c1  pop rsi
00007a3fbe1d64c2  pop rdi
00007a3fbe1d64c3  pop rdx
00007a3fbe1d64c4  pop rcx
00007a3fbe1d64c5  pop rax
00007a3fbe1d64c6  add rsp, 0x08
00007a3fbe1d64ca  jmp 0x00007A3FBE1D30F2
00007a3fbe1d64cf  sub rsp, 0x08
00007a3fbe1d64d3  push rax
00007a3fbe1d64d4  push rcx
00007a3fbe1d64d5  push rdx
00007a3fbe1d64d6  push rdi
00007a3fbe1d64d7  push rsi
00007a3fbe1d64d8  push r8
00007a3fbe1d64da  push r9
00007a3fbe1d64dc  push r10
00007a3fbe1d64de  push r11
00007a3fbe1d64e0  sub rsp, 0xF0
00007a3fbe1d64e7  vmovaps [rsp], xmm0
00007a3fbe1d64ec  vmovaps [rsp+0x10], xmm2
00007a3fbe1d64f2  vmovaps [rsp+0x20], xmm3
00007a3fbe1d64f8  vmovaps [rsp+0x30], xmm4
00007a3fbe1d64fe  vmovaps [rsp+0x40], xmm5
00007a3fbe1d6504  vmovaps [rsp+0x50], xmm6
00007a3fbe1d650a  vmovaps [rsp+0x60], xmm7
00007a3fbe1d6510  vmovaps [rsp+0x70], xmm8
00007a3fbe1d6516  vmovaps [rsp+0x80], xmm9
00007a3fbe1d651f  vmovaps [rsp+0x90], xmm10
00007a3fbe1d6528  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d6531  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d653a  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d6543  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d654c  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d6555  sub rsp, 0x30
00007a3fbe1d6559  movaps [rsp], xmm1
00007a3fbe1d655d  movaps [rsp+0x10], xmm14
00007a3fbe1d6563  movaps [rsp+0x20], xmm6
00007a3fbe1d6568  lea rdi, [rsp]
00007a3fbe1d656c  mov esi, 0x00
00007a3fbe1d6571  mov rax, 0x60D1084DB530
00007a3fbe1d657b  call rax
00007a3fbe1d657d  movaps xmm1, [rsp]
00007a3fbe1d6581  add rsp, 0x30
00007a3fbe1d6585  vmovaps xmm0, [rsp]
00007a3fbe1d658a  vmovaps xmm2, [rsp+0x10]
00007a3fbe1d6590  vmovaps xmm3, [rsp+0x20]
00007a3fbe1d6596  vmovaps xmm4, [rsp+0x30]
00007a3fbe1d659c  vmovaps xmm5, [rsp+0x40]
00007a3fbe1d65a2  vmovaps xmm6, [rsp+0x50]
00007a3fbe1d65a8  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d65ae  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d65b4  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d65bd  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d65c6  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d65cf  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d65d8  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d65e1  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d65ea  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d65f3  add rsp, 0xF0
00007a3fbe1d65fa  pop r11
00007a3fbe1d65fc  pop r10
00007a3fbe1d65fe  pop r9
00007a3fbe1d6600  pop r8
00007a3fbe1d6602  pop rsi
00007a3fbe1d6603  pop rdi
00007a3fbe1d6604  pop rdx
00007a3fbe1d6605  pop rcx
00007a3fbe1d6606  pop rax
00007a3fbe1d6607  add rsp, 0x08
00007a3fbe1d660b  jmp 0x00007A3FBE1D310B
00007a3fbe1d6610  sub rsp, 0x08
00007a3fbe1d6614  push rax
00007a3fbe1d6615  push rcx
00007a3fbe1d6616  push rdx
00007a3fbe1d6617  push rdi
00007a3fbe1d6618  push rsi
00007a3fbe1d6619  push r8
00007a3fbe1d661b  push r9
00007a3fbe1d661d  push r10
00007a3fbe1d661f  push r11
00007a3fbe1d6621  sub rsp, 0xF0
00007a3fbe1d6628  vmovaps [rsp], xmm0
00007a3fbe1d662d  vmovaps [rsp+0x10], xmm1
00007a3fbe1d6633  vmovaps [rsp+0x20], xmm2
00007a3fbe1d6639  vmovaps [rsp+0x30], xmm3
00007a3fbe1d663f  vmovaps [rsp+0x40], xmm4
00007a3fbe1d6645  vmovaps [rsp+0x50], xmm5
00007a3fbe1d664b  vmovaps [rsp+0x60], xmm6
00007a3fbe1d6651  vmovaps [rsp+0x70], xmm7
00007a3fbe1d6657  vmovaps [rsp+0x80], xmm8
00007a3fbe1d6660  vmovaps [rsp+0x90], xmm9
00007a3fbe1d6669  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d6672  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d667b  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d6684  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d668d  vmovaps [rsp+0xE0], xmm14
00007a3fbe1d6696  sub rsp, 0x30
00007a3fbe1d669a  movaps [rsp], xmm15
00007a3fbe1d669f  movaps [rsp+0x10], xmm14
00007a3fbe1d66a5  movaps [rsp+0x20], xmm5
00007a3fbe1d66aa  lea rdi, [rsp]
00007a3fbe1d66ae  mov esi, 0x00
00007a3fbe1d66b3  mov rax, 0x60D1084DB530
00007a3fbe1d66bd  call rax
00007a3fbe1d66bf  movaps xmm15, [rsp]
00007a3fbe1d66c4  add rsp, 0x30
00007a3fbe1d66c8  vmovaps xmm0, [rsp]
00007a3fbe1d66cd  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d66d3  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d66d9  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d66df  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d66e5  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d66eb  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d66f1  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d66f7  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d6700  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d6709  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d6712  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d671b  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d6724  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d672d  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1d6736  add rsp, 0xF0
00007a3fbe1d673d  pop r11
00007a3fbe1d673f  pop r10
00007a3fbe1d6741  pop r9
00007a3fbe1d6743  pop r8
00007a3fbe1d6745  pop rsi
00007a3fbe1d6746  pop rdi
00007a3fbe1d6747  pop rdx
00007a3fbe1d6748  pop rcx
00007a3fbe1d6749  pop rax
00007a3fbe1d674a  add rsp, 0x08
00007a3fbe1d674e  jmp 0x00007A3FBE1D312B
00007a3fbe1d6753  sub rsp, 0x08
00007a3fbe1d6757  push rax
00007a3fbe1d6758  push rcx
00007a3fbe1d6759  push rdx
00007a3fbe1d675a  push rdi
00007a3fbe1d675b  push rsi
00007a3fbe1d675c  push r8
00007a3fbe1d675e  push r9
00007a3fbe1d6760  push r10
00007a3fbe1d6762  push r11
00007a3fbe1d6764  sub rsp, 0xF0
00007a3fbe1d676b  vmovaps [rsp], xmm0
00007a3fbe1d6770  vmovaps [rsp+0x10], xmm1
00007a3fbe1d6776  vmovaps [rsp+0x20], xmm2
00007a3fbe1d677c  vmovaps [rsp+0x30], xmm3
00007a3fbe1d6782  vmovaps [rsp+0x40], xmm4
00007a3fbe1d6788  vmovaps [rsp+0x50], xmm5
00007a3fbe1d678e  vmovaps [rsp+0x60], xmm7
00007a3fbe1d6794  vmovaps [rsp+0x70], xmm8
00007a3fbe1d679a  vmovaps [rsp+0x80], xmm9
00007a3fbe1d67a3  vmovaps [rsp+0x90], xmm10
00007a3fbe1d67ac  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d67b5  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d67be  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d67c7  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d67d0  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d67d9  sub rsp, 0x30
00007a3fbe1d67dd  movaps [rsp], xmm6
00007a3fbe1d67e1  movaps [rsp+0x10], xmm9
00007a3fbe1d67e7  movaps [rsp+0x20], xmm14
00007a3fbe1d67ed  lea rdi, [rsp]
00007a3fbe1d67f1  mov esi, 0x00
00007a3fbe1d67f6  mov rax, 0x60D1084DB530
00007a3fbe1d6800  call rax
00007a3fbe1d6802  movaps xmm6, [rsp]
00007a3fbe1d6806  add rsp, 0x30
00007a3fbe1d680a  vmovaps xmm0, [rsp]
00007a3fbe1d680f  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d6815  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d681b  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d6821  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d6827  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d682d  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d6833  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d6839  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d6842  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d684b  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d6854  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d685d  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d6866  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d686f  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d6878  add rsp, 0xF0
00007a3fbe1d687f  pop r11
00007a3fbe1d6881  pop r10
00007a3fbe1d6883  pop r9
00007a3fbe1d6885  pop r8
00007a3fbe1d6887  pop rsi
00007a3fbe1d6888  pop rdi
00007a3fbe1d6889  pop rdx
00007a3fbe1d688a  pop rcx
00007a3fbe1d688b  pop rax
00007a3fbe1d688c  add rsp, 0x08
00007a3fbe1d6890  jmp 0x00007A3FBE1D3153
00007a3fbe1d6895  sub rsp, 0x08
00007a3fbe1d6899  push rax
00007a3fbe1d689a  push rcx
00007a3fbe1d689b  push rdx
00007a3fbe1d689c  push rdi
00007a3fbe1d689d  push rsi
00007a3fbe1d689e  push r8
00007a3fbe1d68a0  push r9
00007a3fbe1d68a2  push r10
00007a3fbe1d68a4  push r11
00007a3fbe1d68a6  sub rsp, 0xF0
00007a3fbe1d68ad  vmovaps [rsp], xmm0
00007a3fbe1d68b2  vmovaps [rsp+0x10], xmm1
00007a3fbe1d68b8  vmovaps [rsp+0x20], xmm2
00007a3fbe1d68be  vmovaps [rsp+0x30], xmm3
00007a3fbe1d68c4  vmovaps [rsp+0x40], xmm4
00007a3fbe1d68ca  vmovaps [rsp+0x50], xmm5
00007a3fbe1d68d0  vmovaps [rsp+0x60], xmm6
00007a3fbe1d68d6  vmovaps [rsp+0x70], xmm7
00007a3fbe1d68dc  vmovaps [rsp+0x80], xmm8
00007a3fbe1d68e5  vmovaps [rsp+0x90], xmm9
00007a3fbe1d68ee  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d68f7  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d6900  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d6909  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d6912  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d691b  sub rsp, 0x30
00007a3fbe1d691f  movaps [rsp], xmm14
00007a3fbe1d6924  movaps [rsp+0x10], xmm9
00007a3fbe1d692a  movaps [rsp+0x20], xmm13
00007a3fbe1d6930  lea rdi, [rsp]
00007a3fbe1d6934  mov esi, 0x00
00007a3fbe1d6939  mov rax, 0x60D1084DB530
00007a3fbe1d6943  call rax
00007a3fbe1d6945  movaps xmm14, [rsp]
00007a3fbe1d694a  add rsp, 0x30
00007a3fbe1d694e  vmovaps xmm0, [rsp]
00007a3fbe1d6953  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d6959  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d695f  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d6965  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d696b  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d6971  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d6977  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d697d  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d6986  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d698f  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d6998  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d69a1  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d69aa  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d69b3  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d69bc  add rsp, 0xF0
00007a3fbe1d69c3  pop r11
00007a3fbe1d69c5  pop r10
00007a3fbe1d69c7  pop r9
00007a3fbe1d69c9  pop r8
00007a3fbe1d69cb  pop rsi
00007a3fbe1d69cc  pop rdi
00007a3fbe1d69cd  pop rdx
00007a3fbe1d69ce  pop rcx
00007a3fbe1d69cf  pop rax
00007a3fbe1d69d0  add rsp, 0x08
00007a3fbe1d69d4  jmp 0x00007A3FBE1D3176
00007a3fbe1d69d9  sub rsp, 0x08
00007a3fbe1d69dd  push rax
00007a3fbe1d69de  push rcx
00007a3fbe1d69df  push rdx
00007a3fbe1d69e0  push rdi
00007a3fbe1d69e1  push rsi
00007a3fbe1d69e2  push r8
00007a3fbe1d69e4  push r9
00007a3fbe1d69e6  push r10
00007a3fbe1d69e8  push r11
00007a3fbe1d69ea  sub rsp, 0xF0
00007a3fbe1d69f1  vmovaps [rsp], xmm0
00007a3fbe1d69f6  vmovaps [rsp+0x10], xmm1
00007a3fbe1d69fc  vmovaps [rsp+0x20], xmm2
00007a3fbe1d6a02  vmovaps [rsp+0x30], xmm3
00007a3fbe1d6a08  vmovaps [rsp+0x40], xmm4
00007a3fbe1d6a0e  vmovaps [rsp+0x50], xmm5
00007a3fbe1d6a14  vmovaps [rsp+0x60], xmm6
00007a3fbe1d6a1a  vmovaps [rsp+0x70], xmm7
00007a3fbe1d6a20  vmovaps [rsp+0x80], xmm8
00007a3fbe1d6a29  vmovaps [rsp+0x90], xmm9
00007a3fbe1d6a32  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d6a3b  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d6a44  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d6a4d  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d6a56  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d6a5f  sub rsp, 0x30
00007a3fbe1d6a63  movaps [rsp], xmm13
00007a3fbe1d6a68  movaps [rsp+0x10], xmm9
00007a3fbe1d6a6e  movaps [rsp+0x20], xmm10
00007a3fbe1d6a74  lea rdi, [rsp]
00007a3fbe1d6a78  mov esi, 0x00
00007a3fbe1d6a7d  mov rax, 0x60D1084DB530
00007a3fbe1d6a87  call rax
00007a3fbe1d6a89  movaps xmm13, [rsp]
00007a3fbe1d6a8e  add rsp, 0x30
00007a3fbe1d6a92  vmovaps xmm0, [rsp]
00007a3fbe1d6a97  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d6a9d  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d6aa3  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d6aa9  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d6aaf  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d6ab5  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d6abb  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d6ac1  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d6aca  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d6ad3  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d6adc  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d6ae5  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d6aee  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d6af7  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d6b00  add rsp, 0xF0
00007a3fbe1d6b07  pop r11
00007a3fbe1d6b09  pop r10
00007a3fbe1d6b0b  pop r9
00007a3fbe1d6b0d  pop r8
00007a3fbe1d6b0f  pop rsi
00007a3fbe1d6b10  pop rdi
00007a3fbe1d6b11  pop rdx
00007a3fbe1d6b12  pop rcx
00007a3fbe1d6b13  pop rax
00007a3fbe1d6b14  add rsp, 0x08
00007a3fbe1d6b18  jmp 0x00007A3FBE1D3196
00007a3fbe1d6b1d  call 0x00007A3FBE00AFE0
00007a3fbe1d6b22  jmp 0x00007A3FBE1D31EB
00007a3fbe1d6b27  sub rsp, 0x08
00007a3fbe1d6b2b  push rax
00007a3fbe1d6b2c  push rcx
00007a3fbe1d6b2d  push rdx
00007a3fbe1d6b2e  push rdi
00007a3fbe1d6b2f  push rsi
00007a3fbe1d6b30  push r8
00007a3fbe1d6b32  push r9
00007a3fbe1d6b34  push r10
00007a3fbe1d6b36  push r11
00007a3fbe1d6b38  sub rsp, 0xF0
00007a3fbe1d6b3f  vmovaps [rsp], xmm0
00007a3fbe1d6b44  vmovaps [rsp+0x10], xmm1
00007a3fbe1d6b4a  vmovaps [rsp+0x20], xmm2
00007a3fbe1d6b50  vmovaps [rsp+0x30], xmm3
00007a3fbe1d6b56  vmovaps [rsp+0x40], xmm4
00007a3fbe1d6b5c  vmovaps [rsp+0x50], xmm5
00007a3fbe1d6b62  vmovaps [rsp+0x60], xmm6
00007a3fbe1d6b68  vmovaps [rsp+0x70], xmm7
00007a3fbe1d6b6e  vmovaps [rsp+0x80], xmm8
00007a3fbe1d6b77  vmovaps [rsp+0x90], xmm10
00007a3fbe1d6b80  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d6b89  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d6b92  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d6b9b  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d6ba4  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d6bad  sub rsp, 0x30
00007a3fbe1d6bb1  movaps [rsp], xmm9
00007a3fbe1d6bb6  movaps [rsp+0x10], xmm8
00007a3fbe1d6bbc  movaps [rsp+0x20], xmm10
00007a3fbe1d6bc2  lea rdi, [rsp]
00007a3fbe1d6bc6  mov esi, 0x00
00007a3fbe1d6bcb  mov rax, 0x60D1084DB530
00007a3fbe1d6bd5  call rax
00007a3fbe1d6bd7  movaps xmm9, [rsp]
00007a3fbe1d6bdc  add rsp, 0x30
00007a3fbe1d6be0  vmovaps xmm0, [rsp]
00007a3fbe1d6be5  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d6beb  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d6bf1  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d6bf7  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d6bfd  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d6c03  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d6c09  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d6c0f  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d6c18  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d6c21  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d6c2a  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d6c33  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d6c3c  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d6c45  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d6c4e  add rsp, 0xF0
00007a3fbe1d6c55  pop r11
00007a3fbe1d6c57  pop r10
00007a3fbe1d6c59  pop r9
00007a3fbe1d6c5b  pop r8
00007a3fbe1d6c5d  pop rsi
00007a3fbe1d6c5e  pop rdi
00007a3fbe1d6c5f  pop rdx
00007a3fbe1d6c60  pop rcx
00007a3fbe1d6c61  pop rax
00007a3fbe1d6c62  add rsp, 0x08
00007a3fbe1d6c66  jmp 0x00007A3FBE1D321C
00007a3fbe1d6c6b  sub rsp, 0x08
00007a3fbe1d6c6f  push rax
00007a3fbe1d6c70  push rcx
00007a3fbe1d6c71  push rdx
00007a3fbe1d6c72  push rdi
00007a3fbe1d6c73  push rsi
00007a3fbe1d6c74  push r8
00007a3fbe1d6c76  push r9
00007a3fbe1d6c78  push r10
00007a3fbe1d6c7a  push r11
00007a3fbe1d6c7c  sub rsp, 0xF0
00007a3fbe1d6c83  vmovaps [rsp], xmm0
00007a3fbe1d6c88  vmovaps [rsp+0x10], xmm1
00007a3fbe1d6c8e  vmovaps [rsp+0x20], xmm2
00007a3fbe1d6c94  vmovaps [rsp+0x30], xmm3
00007a3fbe1d6c9a  vmovaps [rsp+0x40], xmm4
00007a3fbe1d6ca0  vmovaps [rsp+0x50], xmm5
00007a3fbe1d6ca6  vmovaps [rsp+0x60], xmm6
00007a3fbe1d6cac  vmovaps [rsp+0x70], xmm7
00007a3fbe1d6cb2  vmovaps [rsp+0x80], xmm8
00007a3fbe1d6cbb  vmovaps [rsp+0x90], xmm9
00007a3fbe1d6cc4  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d6ccd  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d6cd6  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d6cdf  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d6ce8  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d6cf1  sub rsp, 0x30
00007a3fbe1d6cf5  movaps [rsp], xmm10
00007a3fbe1d6cfa  movaps [rsp+0x10], xmm1
00007a3fbe1d6cff  movaps [rsp+0x20], xmm11
00007a3fbe1d6d05  lea rdi, [rsp]
00007a3fbe1d6d09  mov esi, 0x00
00007a3fbe1d6d0e  mov rax, 0x60D1084DB530
00007a3fbe1d6d18  call rax
00007a3fbe1d6d1a  movaps xmm10, [rsp]
00007a3fbe1d6d1f  add rsp, 0x30
00007a3fbe1d6d23  vmovaps xmm0, [rsp]
00007a3fbe1d6d28  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d6d2e  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d6d34  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d6d3a  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d6d40  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d6d46  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d6d4c  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d6d52  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d6d5b  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d6d64  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d6d6d  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d6d76  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d6d7f  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d6d88  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d6d91  add rsp, 0xF0
00007a3fbe1d6d98  pop r11
00007a3fbe1d6d9a  pop r10
00007a3fbe1d6d9c  pop r9
00007a3fbe1d6d9e  pop r8
00007a3fbe1d6da0  pop rsi
00007a3fbe1d6da1  pop rdi
00007a3fbe1d6da2  pop rdx
00007a3fbe1d6da3  pop rcx
00007a3fbe1d6da4  pop rax
00007a3fbe1d6da5  add rsp, 0x08
00007a3fbe1d6da9  jmp 0x00007A3FBE1D3237
00007a3fbe1d6dae  sub rsp, 0x08
00007a3fbe1d6db2  push rax
00007a3fbe1d6db3  push rcx
00007a3fbe1d6db4  push rdx
00007a3fbe1d6db5  push rdi
00007a3fbe1d6db6  push rsi
00007a3fbe1d6db7  push r8
00007a3fbe1d6db9  push r9
00007a3fbe1d6dbb  push r10
00007a3fbe1d6dbd  push r11
00007a3fbe1d6dbf  sub rsp, 0xF0
00007a3fbe1d6dc6  vmovaps [rsp], xmm0
00007a3fbe1d6dcb  vmovaps [rsp+0x10], xmm2
00007a3fbe1d6dd1  vmovaps [rsp+0x20], xmm3
00007a3fbe1d6dd7  vmovaps [rsp+0x30], xmm4
00007a3fbe1d6ddd  vmovaps [rsp+0x40], xmm5
00007a3fbe1d6de3  vmovaps [rsp+0x50], xmm6
00007a3fbe1d6de9  vmovaps [rsp+0x60], xmm7
00007a3fbe1d6def  vmovaps [rsp+0x70], xmm8
00007a3fbe1d6df5  vmovaps [rsp+0x80], xmm9
00007a3fbe1d6dfe  vmovaps [rsp+0x90], xmm10
00007a3fbe1d6e07  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d6e10  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d6e19  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d6e22  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d6e2b  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d6e34  sub rsp, 0x30
00007a3fbe1d6e38  movaps [rsp], xmm1
00007a3fbe1d6e3c  movaps [rsp+0x10], xmm15
00007a3fbe1d6e42  movaps [rsp+0x20], xmm6
00007a3fbe1d6e47  lea rdi, [rsp]
00007a3fbe1d6e4b  mov esi, 0x00
00007a3fbe1d6e50  mov rax, 0x60D1084DB530
00007a3fbe1d6e5a  call rax
00007a3fbe1d6e5c  movaps xmm1, [rsp]
00007a3fbe1d6e60  add rsp, 0x30
00007a3fbe1d6e64  vmovaps xmm0, [rsp]
00007a3fbe1d6e69  vmovaps xmm2, [rsp+0x10]
00007a3fbe1d6e6f  vmovaps xmm3, [rsp+0x20]
00007a3fbe1d6e75  vmovaps xmm4, [rsp+0x30]
00007a3fbe1d6e7b  vmovaps xmm5, [rsp+0x40]
00007a3fbe1d6e81  vmovaps xmm6, [rsp+0x50]
00007a3fbe1d6e87  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d6e8d  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d6e93  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d6e9c  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d6ea5  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d6eae  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d6eb7  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d6ec0  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d6ec9  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d6ed2  add rsp, 0xF0
00007a3fbe1d6ed9  pop r11
00007a3fbe1d6edb  pop r10
00007a3fbe1d6edd  pop r9
00007a3fbe1d6edf  pop r8
00007a3fbe1d6ee1  pop rsi
00007a3fbe1d6ee2  pop rdi
00007a3fbe1d6ee3  pop rdx
00007a3fbe1d6ee4  pop rcx
00007a3fbe1d6ee5  pop rax
00007a3fbe1d6ee6  add rsp, 0x08
00007a3fbe1d6eea  jmp 0x00007A3FBE1D3250
00007a3fbe1d6eef  sub rsp, 0x08
00007a3fbe1d6ef3  push rax
00007a3fbe1d6ef4  push rcx
00007a3fbe1d6ef5  push rdx
00007a3fbe1d6ef6  push rdi
00007a3fbe1d6ef7  push rsi
00007a3fbe1d6ef8  push r8
00007a3fbe1d6efa  push r9
00007a3fbe1d6efc  push r10
00007a3fbe1d6efe  push r11
00007a3fbe1d6f00  sub rsp, 0xF0
00007a3fbe1d6f07  vmovaps [rsp], xmm0
00007a3fbe1d6f0c  vmovaps [rsp+0x10], xmm1
00007a3fbe1d6f12  vmovaps [rsp+0x20], xmm2
00007a3fbe1d6f18  vmovaps [rsp+0x30], xmm3
00007a3fbe1d6f1e  vmovaps [rsp+0x40], xmm4
00007a3fbe1d6f24  vmovaps [rsp+0x50], xmm5
00007a3fbe1d6f2a  vmovaps [rsp+0x60], xmm6
00007a3fbe1d6f30  vmovaps [rsp+0x70], xmm7
00007a3fbe1d6f36  vmovaps [rsp+0x80], xmm8
00007a3fbe1d6f3f  vmovaps [rsp+0x90], xmm9
00007a3fbe1d6f48  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d6f51  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d6f5a  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d6f63  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d6f6c  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d6f75  sub rsp, 0x30
00007a3fbe1d6f79  movaps [rsp], xmm11
00007a3fbe1d6f7e  movaps [rsp+0x10], xmm12
00007a3fbe1d6f84  movaps [rsp+0x20], xmm15
00007a3fbe1d6f8a  lea rdi, [rsp]
00007a3fbe1d6f8e  mov esi, 0x00
00007a3fbe1d6f93  mov rax, 0x60D1084DB530
00007a3fbe1d6f9d  call rax
00007a3fbe1d6f9f  movaps xmm11, [rsp]
00007a3fbe1d6fa4  add rsp, 0x30
00007a3fbe1d6fa8  vmovaps xmm0, [rsp]
00007a3fbe1d6fad  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d6fb3  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d6fb9  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d6fbf  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d6fc5  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d6fcb  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d6fd1  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d6fd7  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d6fe0  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d6fe9  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d6ff2  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d6ffb  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d7004  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d700d  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d7016  add rsp, 0xF0
00007a3fbe1d701d  pop r11
00007a3fbe1d701f  pop r10
00007a3fbe1d7021  pop r9
00007a3fbe1d7023  pop r8
00007a3fbe1d7025  pop rsi
00007a3fbe1d7026  pop rdi
00007a3fbe1d7027  pop rdx
00007a3fbe1d7028  pop rcx
00007a3fbe1d7029  pop rax
00007a3fbe1d702a  add rsp, 0x08
00007a3fbe1d702e  jmp 0x00007A3FBE1D327A
00007a3fbe1d7033  sub rsp, 0x08
00007a3fbe1d7037  push rax
00007a3fbe1d7038  push rcx
00007a3fbe1d7039  push rdx
00007a3fbe1d703a  push rdi
00007a3fbe1d703b  push rsi
00007a3fbe1d703c  push r8
00007a3fbe1d703e  push r9
00007a3fbe1d7040  push r10
00007a3fbe1d7042  push r11
00007a3fbe1d7044  sub rsp, 0xF0
00007a3fbe1d704b  vmovaps [rsp], xmm0
00007a3fbe1d7050  vmovaps [rsp+0x10], xmm1
00007a3fbe1d7056  vmovaps [rsp+0x20], xmm2
00007a3fbe1d705c  vmovaps [rsp+0x30], xmm3
00007a3fbe1d7062  vmovaps [rsp+0x40], xmm4
00007a3fbe1d7068  vmovaps [rsp+0x50], xmm5
00007a3fbe1d706e  vmovaps [rsp+0x60], xmm6
00007a3fbe1d7074  vmovaps [rsp+0x70], xmm7
00007a3fbe1d707a  vmovaps [rsp+0x80], xmm8
00007a3fbe1d7083  vmovaps [rsp+0x90], xmm9
00007a3fbe1d708c  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d7095  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d709e  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d70a7  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d70b0  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d70b9  sub rsp, 0x30
00007a3fbe1d70bd  movaps [rsp], xmm12
00007a3fbe1d70c2  movaps [rsp+0x10], xmm8
00007a3fbe1d70c8  movaps [rsp+0x20], xmm15
00007a3fbe1d70ce  lea rdi, [rsp]
00007a3fbe1d70d2  mov esi, 0x00
00007a3fbe1d70d7  mov rax, 0x60D1084DB530
00007a3fbe1d70e1  call rax
00007a3fbe1d70e3  movaps xmm12, [rsp]
00007a3fbe1d70e8  add rsp, 0x30
00007a3fbe1d70ec  vmovaps xmm0, [rsp]
00007a3fbe1d70f1  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d70f7  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d70fd  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d7103  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d7109  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d710f  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d7115  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d711b  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d7124  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d712d  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d7136  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d713f  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d7148  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d7151  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d715a  add rsp, 0xF0
00007a3fbe1d7161  pop r11
00007a3fbe1d7163  pop r10
00007a3fbe1d7165  pop r9
00007a3fbe1d7167  pop r8
00007a3fbe1d7169  pop rsi
00007a3fbe1d716a  pop rdi
00007a3fbe1d716b  pop rdx
00007a3fbe1d716c  pop rcx
00007a3fbe1d716d  pop rax
00007a3fbe1d716e  add rsp, 0x08
00007a3fbe1d7172  jmp 0x00007A3FBE1D32A9
00007a3fbe1d7177  sub rsp, 0x08
00007a3fbe1d717b  push rax
00007a3fbe1d717c  push rcx
00007a3fbe1d717d  push rdx
00007a3fbe1d717e  push rdi
00007a3fbe1d717f  push rsi
00007a3fbe1d7180  push r8
00007a3fbe1d7182  push r9
00007a3fbe1d7184  push r10
00007a3fbe1d7186  push r11
00007a3fbe1d7188  sub rsp, 0xF0
00007a3fbe1d718f  vmovaps [rsp], xmm0
00007a3fbe1d7194  vmovaps [rsp+0x10], xmm1
00007a3fbe1d719a  vmovaps [rsp+0x20], xmm2
00007a3fbe1d71a0  vmovaps [rsp+0x30], xmm3
00007a3fbe1d71a6  vmovaps [rsp+0x40], xmm4
00007a3fbe1d71ac  vmovaps [rsp+0x50], xmm5
00007a3fbe1d71b2  vmovaps [rsp+0x60], xmm6
00007a3fbe1d71b8  vmovaps [rsp+0x70], xmm7
00007a3fbe1d71be  vmovaps [rsp+0x80], xmm9
00007a3fbe1d71c7  vmovaps [rsp+0x90], xmm10
00007a3fbe1d71d0  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d71d9  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d71e2  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d71eb  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d71f4  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d71fd  sub rsp, 0x30
00007a3fbe1d7201  movaps [rsp], xmm8
00007a3fbe1d7206  movaps [rsp+0x10], xmm7
00007a3fbe1d720b  movaps [rsp+0x20], xmm15
00007a3fbe1d7211  lea rdi, [rsp]
00007a3fbe1d7215  mov esi, 0x00
00007a3fbe1d721a  mov rax, 0x60D1084DB530
00007a3fbe1d7224  call rax
00007a3fbe1d7226  movaps xmm8, [rsp]
00007a3fbe1d722b  add rsp, 0x30
00007a3fbe1d722f  vmovaps xmm0, [rsp]
00007a3fbe1d7234  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d723a  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d7240  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d7246  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d724c  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d7252  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d7258  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d725e  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d7267  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d7270  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d7279  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d7282  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d728b  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d7294  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d729d  add rsp, 0xF0
00007a3fbe1d72a4  pop r11
00007a3fbe1d72a6  pop r10
00007a3fbe1d72a8  pop r9
00007a3fbe1d72aa  pop r8
00007a3fbe1d72ac  pop rsi
00007a3fbe1d72ad  pop rdi
00007a3fbe1d72ae  pop rdx
00007a3fbe1d72af  pop rcx
00007a3fbe1d72b0  pop rax
00007a3fbe1d72b1  add rsp, 0x08
00007a3fbe1d72b5  jmp 0x00007A3FBE1D32CF
00007a3fbe1d72ba  sub rsp, 0x08
00007a3fbe1d72be  push rax
00007a3fbe1d72bf  push rcx
00007a3fbe1d72c0  push rdx
00007a3fbe1d72c1  push rdi
00007a3fbe1d72c2  push rsi
00007a3fbe1d72c3  push r8
00007a3fbe1d72c5  push r9
00007a3fbe1d72c7  push r10
00007a3fbe1d72c9  push r11
00007a3fbe1d72cb  sub rsp, 0xF0
00007a3fbe1d72d2  vmovaps [rsp], xmm0
00007a3fbe1d72d7  vmovaps [rsp+0x10], xmm1
00007a3fbe1d72dd  vmovaps [rsp+0x20], xmm2
00007a3fbe1d72e3  vmovaps [rsp+0x30], xmm3
00007a3fbe1d72e9  vmovaps [rsp+0x40], xmm4
00007a3fbe1d72ef  vmovaps [rsp+0x50], xmm5
00007a3fbe1d72f5  vmovaps [rsp+0x60], xmm6
00007a3fbe1d72fb  vmovaps [rsp+0x70], xmm7
00007a3fbe1d7301  vmovaps [rsp+0x80], xmm8
00007a3fbe1d730a  vmovaps [rsp+0x90], xmm9
00007a3fbe1d7313  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d731c  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d7325  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d732e  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d7337  vmovaps [rsp+0xE0], xmm14
00007a3fbe1d7340  sub rsp, 0x30
00007a3fbe1d7344  movaps [rsp], xmm15
00007a3fbe1d7349  movaps [rsp+0x10], xmm14
00007a3fbe1d734f  movaps [rsp+0x20], xmm9
00007a3fbe1d7355  lea rdi, [rsp]
00007a3fbe1d7359  mov esi, 0x00
00007a3fbe1d735e  mov rax, 0x60D1084DB530
00007a3fbe1d7368  call rax
00007a3fbe1d736a  movaps xmm15, [rsp]
00007a3fbe1d736f  add rsp, 0x30
00007a3fbe1d7373  vmovaps xmm0, [rsp]
00007a3fbe1d7378  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d737e  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d7384  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d738a  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d7390  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d7396  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d739c  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d73a2  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d73ab  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d73b4  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d73bd  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d73c6  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d73cf  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d73d8  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1d73e1  add rsp, 0xF0
00007a3fbe1d73e8  pop r11
00007a3fbe1d73ea  pop r10
00007a3fbe1d73ec  pop r9
00007a3fbe1d73ee  pop r8
00007a3fbe1d73f0  pop rsi
00007a3fbe1d73f1  pop rdi
00007a3fbe1d73f2  pop rdx
00007a3fbe1d73f3  pop rcx
00007a3fbe1d73f4  pop rax
00007a3fbe1d73f5  add rsp, 0x08
00007a3fbe1d73f9  jmp 0x00007A3FBE1D32E9
00007a3fbe1d73fe  sub rsp, 0x08
00007a3fbe1d7402  push rax
00007a3fbe1d7403  push rcx
00007a3fbe1d7404  push rdx
00007a3fbe1d7405  push rdi
00007a3fbe1d7406  push rsi
00007a3fbe1d7407  push r8
00007a3fbe1d7409  push r9
00007a3fbe1d740b  push r10
00007a3fbe1d740d  push r11
00007a3fbe1d740f  sub rsp, 0xF0
00007a3fbe1d7416  vmovaps [rsp], xmm0
00007a3fbe1d741b  vmovaps [rsp+0x10], xmm1
00007a3fbe1d7421  vmovaps [rsp+0x20], xmm2
00007a3fbe1d7427  vmovaps [rsp+0x30], xmm3
00007a3fbe1d742d  vmovaps [rsp+0x40], xmm4
00007a3fbe1d7433  vmovaps [rsp+0x50], xmm5
00007a3fbe1d7439  vmovaps [rsp+0x60], xmm6
00007a3fbe1d743f  vmovaps [rsp+0x70], xmm7
00007a3fbe1d7445  vmovaps [rsp+0x80], xmm8
00007a3fbe1d744e  vmovaps [rsp+0x90], xmm10
00007a3fbe1d7457  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d7460  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d7469  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d7472  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d747b  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d7484  sub rsp, 0x30
00007a3fbe1d7488  movaps [rsp], xmm9
00007a3fbe1d748d  movaps [rsp+0x10], xmm7
00007a3fbe1d7492  movaps [rsp+0x20], xmm14
00007a3fbe1d7498  lea rdi, [rsp]
00007a3fbe1d749c  mov esi, 0x00
00007a3fbe1d74a1  mov rax, 0x60D1084DB530
00007a3fbe1d74ab  call rax
00007a3fbe1d74ad  movaps xmm9, [rsp]
00007a3fbe1d74b2  add rsp, 0x30
00007a3fbe1d74b6  vmovaps xmm0, [rsp]
00007a3fbe1d74bb  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d74c1  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d74c7  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d74cd  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d74d3  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d74d9  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d74df  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d74e5  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d74ee  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d74f7  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d7500  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d7509  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d7512  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d751b  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d7524  add rsp, 0xF0
00007a3fbe1d752b  pop r11
00007a3fbe1d752d  pop r10
00007a3fbe1d752f  pop r9
00007a3fbe1d7531  pop r8
00007a3fbe1d7533  pop rsi
00007a3fbe1d7534  pop rdi
00007a3fbe1d7535  pop rdx
00007a3fbe1d7536  pop rcx
00007a3fbe1d7537  pop rax
00007a3fbe1d7538  add rsp, 0x08
00007a3fbe1d753c  jmp 0x00007A3FBE1D3318
00007a3fbe1d7541  sub rsp, 0x08
00007a3fbe1d7545  push rax
00007a3fbe1d7546  push rcx
00007a3fbe1d7547  push rdx
00007a3fbe1d7548  push rdi
00007a3fbe1d7549  push rsi
00007a3fbe1d754a  push r8
00007a3fbe1d754c  push r9
00007a3fbe1d754e  push r10
00007a3fbe1d7550  push r11
00007a3fbe1d7552  sub rsp, 0xF0
00007a3fbe1d7559  vmovaps [rsp], xmm0
00007a3fbe1d755e  vmovaps [rsp+0x10], xmm1
00007a3fbe1d7564  vmovaps [rsp+0x20], xmm2
00007a3fbe1d756a  vmovaps [rsp+0x30], xmm3
00007a3fbe1d7570  vmovaps [rsp+0x40], xmm4
00007a3fbe1d7576  vmovaps [rsp+0x50], xmm5
00007a3fbe1d757c  vmovaps [rsp+0x60], xmm6
00007a3fbe1d7582  vmovaps [rsp+0x70], xmm7
00007a3fbe1d7588  vmovaps [rsp+0x80], xmm8
00007a3fbe1d7591  vmovaps [rsp+0x90], xmm9
00007a3fbe1d759a  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d75a3  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d75ac  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d75b5  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d75be  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d75c7  sub rsp, 0x30
00007a3fbe1d75cb  movaps [rsp], xmm14
00007a3fbe1d75d0  movaps [rsp+0x10], xmm13
00007a3fbe1d75d6  movaps [rsp+0x20], xmm11
00007a3fbe1d75dc  lea rdi, [rsp]
00007a3fbe1d75e0  mov esi, 0x00
00007a3fbe1d75e5  mov rax, 0x60D1084DB530
00007a3fbe1d75ef  call rax
00007a3fbe1d75f1  movaps xmm14, [rsp]
00007a3fbe1d75f6  add rsp, 0x30
00007a3fbe1d75fa  vmovaps xmm0, [rsp]
00007a3fbe1d75ff  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d7605  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d760b  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d7611  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d7617  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d761d  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d7623  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d7629  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d7632  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d763b  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d7644  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d764d  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d7656  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d765f  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d7668  add rsp, 0xF0
00007a3fbe1d766f  pop r11
00007a3fbe1d7671  pop r10
00007a3fbe1d7673  pop r9
00007a3fbe1d7675  pop r8
00007a3fbe1d7677  pop rsi
00007a3fbe1d7678  pop rdi
00007a3fbe1d7679  pop rdx
00007a3fbe1d767a  pop rcx
00007a3fbe1d767b  pop rax
00007a3fbe1d767c  add rsp, 0x08
00007a3fbe1d7680  jmp 0x00007A3FBE1D3332
00007a3fbe1d7685  sub rsp, 0x08
00007a3fbe1d7689  push rax
00007a3fbe1d768a  push rcx
00007a3fbe1d768b  push rdx
00007a3fbe1d768c  push rdi
00007a3fbe1d768d  push rsi
00007a3fbe1d768e  push r8
00007a3fbe1d7690  push r9
00007a3fbe1d7692  push r10
00007a3fbe1d7694  push r11
00007a3fbe1d7696  sub rsp, 0xF0
00007a3fbe1d769d  vmovaps [rsp], xmm0
00007a3fbe1d76a2  vmovaps [rsp+0x10], xmm1
00007a3fbe1d76a8  vmovaps [rsp+0x20], xmm2
00007a3fbe1d76ae  vmovaps [rsp+0x30], xmm3
00007a3fbe1d76b4  vmovaps [rsp+0x40], xmm4
00007a3fbe1d76ba  vmovaps [rsp+0x50], xmm5
00007a3fbe1d76c0  vmovaps [rsp+0x60], xmm6
00007a3fbe1d76c6  vmovaps [rsp+0x70], xmm7
00007a3fbe1d76cc  vmovaps [rsp+0x80], xmm8
00007a3fbe1d76d5  vmovaps [rsp+0x90], xmm9
00007a3fbe1d76de  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d76e7  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d76f0  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d76f9  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d7702  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d770b  sub rsp, 0x30
00007a3fbe1d770f  movaps [rsp], xmm11
00007a3fbe1d7714  movaps [rsp+0x10], xmm7
00007a3fbe1d7719  movaps [rsp+0x20], xmm13
00007a3fbe1d771f  lea rdi, [rsp]
00007a3fbe1d7723  mov esi, 0x00
00007a3fbe1d7728  mov rax, 0x60D1084DB530
00007a3fbe1d7732  call rax
00007a3fbe1d7734  movaps xmm11, [rsp]
00007a3fbe1d7739  add rsp, 0x30
00007a3fbe1d773d  vmovaps xmm0, [rsp]
00007a3fbe1d7742  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d7748  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d774e  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d7754  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d775a  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d7760  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d7766  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d776c  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d7775  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d777e  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d7787  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d7790  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d7799  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d77a2  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d77ab  add rsp, 0xF0
00007a3fbe1d77b2  pop r11
00007a3fbe1d77b4  pop r10
00007a3fbe1d77b6  pop r9
00007a3fbe1d77b8  pop r8
00007a3fbe1d77ba  pop rsi
00007a3fbe1d77bb  pop rdi
00007a3fbe1d77bc  pop rdx
00007a3fbe1d77bd  pop rcx
00007a3fbe1d77be  pop rax
00007a3fbe1d77bf  add rsp, 0x08
00007a3fbe1d77c3  jmp 0x00007A3FBE1D335E
00007a3fbe1d77c8  sub rsp, 0x08
00007a3fbe1d77cc  push rax
00007a3fbe1d77cd  push rcx
00007a3fbe1d77ce  push rdx
00007a3fbe1d77cf  push rdi
00007a3fbe1d77d0  push rsi
00007a3fbe1d77d1  push r8
00007a3fbe1d77d3  push r9
00007a3fbe1d77d5  push r10
00007a3fbe1d77d7  push r11
00007a3fbe1d77d9  sub rsp, 0xF0
00007a3fbe1d77e0  vmovaps [rsp], xmm0
00007a3fbe1d77e5  vmovaps [rsp+0x10], xmm1
00007a3fbe1d77eb  vmovaps [rsp+0x20], xmm2
00007a3fbe1d77f1  vmovaps [rsp+0x30], xmm3
00007a3fbe1d77f7  vmovaps [rsp+0x40], xmm4
00007a3fbe1d77fd  vmovaps [rsp+0x50], xmm5
00007a3fbe1d7803  vmovaps [rsp+0x60], xmm6
00007a3fbe1d7809  vmovaps [rsp+0x70], xmm7
00007a3fbe1d780f  vmovaps [rsp+0x80], xmm8
00007a3fbe1d7818  vmovaps [rsp+0x90], xmm9
00007a3fbe1d7821  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d782a  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d7833  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d783c  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d7845  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d784e  sub rsp, 0x30
00007a3fbe1d7852  movaps [rsp], xmm13
00007a3fbe1d7857  movaps [rsp+0x10], xmm10
00007a3fbe1d785d  movaps [rsp+0x20], xmm12
00007a3fbe1d7863  lea rdi, [rsp]
00007a3fbe1d7867  mov esi, 0x00
00007a3fbe1d786c  mov rax, 0x60D1084DB530
00007a3fbe1d7876  call rax
00007a3fbe1d7878  movaps xmm13, [rsp]
00007a3fbe1d787d  add rsp, 0x30
00007a3fbe1d7881  vmovaps xmm0, [rsp]
00007a3fbe1d7886  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d788c  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d7892  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d7898  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d789e  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d78a4  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d78aa  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d78b0  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d78b9  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d78c2  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d78cb  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d78d4  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d78dd  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d78e6  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d78ef  add rsp, 0xF0
00007a3fbe1d78f6  pop r11
00007a3fbe1d78f8  pop r10
00007a3fbe1d78fa  pop r9
00007a3fbe1d78fc  pop r8
00007a3fbe1d78fe  pop rsi
00007a3fbe1d78ff  pop rdi
00007a3fbe1d7900  pop rdx
00007a3fbe1d7901  pop rcx
00007a3fbe1d7902  pop rax
00007a3fbe1d7903  add rsp, 0x08
00007a3fbe1d7907  jmp 0x00007A3FBE1D3378
00007a3fbe1d790c  sub rsp, 0x08
00007a3fbe1d7910  push rax
00007a3fbe1d7911  push rcx
00007a3fbe1d7912  push rdx
00007a3fbe1d7913  push rdi
00007a3fbe1d7914  push rsi
00007a3fbe1d7915  push r8
00007a3fbe1d7917  push r9
00007a3fbe1d7919  push r10
00007a3fbe1d791b  push r11
00007a3fbe1d791d  sub rsp, 0xF0
00007a3fbe1d7924  vmovaps [rsp], xmm0
00007a3fbe1d7929  vmovaps [rsp+0x10], xmm1
00007a3fbe1d792f  vmovaps [rsp+0x20], xmm2
00007a3fbe1d7935  vmovaps [rsp+0x30], xmm3
00007a3fbe1d793b  vmovaps [rsp+0x40], xmm4
00007a3fbe1d7941  vmovaps [rsp+0x50], xmm5
00007a3fbe1d7947  vmovaps [rsp+0x60], xmm6
00007a3fbe1d794d  vmovaps [rsp+0x70], xmm7
00007a3fbe1d7953  vmovaps [rsp+0x80], xmm8
00007a3fbe1d795c  vmovaps [rsp+0x90], xmm9
00007a3fbe1d7965  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d796e  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d7977  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d7980  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d7989  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d7992  sub rsp, 0x30
00007a3fbe1d7996  movaps [rsp], xmm10
00007a3fbe1d799b  movaps [rsp+0x10], xmm7
00007a3fbe1d79a0  movaps [rsp+0x20], xmm12
00007a3fbe1d79a6  lea rdi, [rsp]
00007a3fbe1d79aa  mov esi, 0x00
00007a3fbe1d79af  mov rax, 0x60D1084DB530
00007a3fbe1d79b9  call rax
00007a3fbe1d79bb  movaps xmm10, [rsp]
00007a3fbe1d79c0  add rsp, 0x30
00007a3fbe1d79c4  vmovaps xmm0, [rsp]
00007a3fbe1d79c9  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d79cf  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d79d5  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d79db  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d79e1  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d79e7  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d79ed  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d79f3  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d79fc  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d7a05  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d7a0e  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d7a17  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d7a20  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d7a29  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d7a32  add rsp, 0xF0
00007a3fbe1d7a39  pop r11
00007a3fbe1d7a3b  pop r10
00007a3fbe1d7a3d  pop r9
00007a3fbe1d7a3f  pop r8
00007a3fbe1d7a41  pop rsi
00007a3fbe1d7a42  pop rdi
00007a3fbe1d7a43  pop rdx
00007a3fbe1d7a44  pop rcx
00007a3fbe1d7a45  pop rax
00007a3fbe1d7a46  add rsp, 0x08
00007a3fbe1d7a4a  jmp 0x00007A3FBE1D33A4
00007a3fbe1d7a4f  sub rsp, 0x08
00007a3fbe1d7a53  push rax
00007a3fbe1d7a54  push rcx
00007a3fbe1d7a55  push rdx
00007a3fbe1d7a56  push rdi
00007a3fbe1d7a57  push rsi
00007a3fbe1d7a58  push r8
00007a3fbe1d7a5a  push r9
00007a3fbe1d7a5c  push r10
00007a3fbe1d7a5e  push r11
00007a3fbe1d7a60  sub rsp, 0xF0
00007a3fbe1d7a67  vmovaps [rsp], xmm0
00007a3fbe1d7a6c  vmovaps [rsp+0x10], xmm1
00007a3fbe1d7a72  vmovaps [rsp+0x20], xmm2
00007a3fbe1d7a78  vmovaps [rsp+0x30], xmm3
00007a3fbe1d7a7e  vmovaps [rsp+0x40], xmm4
00007a3fbe1d7a84  vmovaps [rsp+0x50], xmm5
00007a3fbe1d7a8a  vmovaps [rsp+0x60], xmm6
00007a3fbe1d7a90  vmovaps [rsp+0x70], xmm7
00007a3fbe1d7a96  vmovaps [rsp+0x80], xmm8
00007a3fbe1d7a9f  vmovaps [rsp+0x90], xmm9
00007a3fbe1d7aa8  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d7ab1  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d7aba  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d7ac3  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d7acc  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d7ad5  sub rsp, 0x30
00007a3fbe1d7ad9  movaps [rsp], xmm12
00007a3fbe1d7ade  movaps [rsp+0x10], xmm1
00007a3fbe1d7ae3  movaps [rsp+0x20], xmm8
00007a3fbe1d7ae9  lea rdi, [rsp]
00007a3fbe1d7aed  mov esi, 0x00
00007a3fbe1d7af2  mov rax, 0x60D1084DB530
00007a3fbe1d7afc  call rax
00007a3fbe1d7afe  movaps xmm12, [rsp]
00007a3fbe1d7b03  add rsp, 0x30
00007a3fbe1d7b07  vmovaps xmm0, [rsp]
00007a3fbe1d7b0c  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d7b12  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d7b18  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d7b1e  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d7b24  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d7b2a  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d7b30  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d7b36  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d7b3f  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d7b48  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d7b51  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d7b5a  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d7b63  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d7b6c  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d7b75  add rsp, 0xF0
00007a3fbe1d7b7c  pop r11
00007a3fbe1d7b7e  pop r10
00007a3fbe1d7b80  pop r9
00007a3fbe1d7b82  pop r8
00007a3fbe1d7b84  pop rsi
00007a3fbe1d7b85  pop rdi
00007a3fbe1d7b86  pop rdx
00007a3fbe1d7b87  pop rcx
00007a3fbe1d7b88  pop rax
00007a3fbe1d7b89  add rsp, 0x08
00007a3fbe1d7b8d  jmp 0x00007A3FBE1D33BE
00007a3fbe1d7b92  call 0x00007A3FBDFFF430
00007a3fbe1d7b97  jmp 0x00007A3FBE1D33C8
00007a3fbe1d7b9c  sub rsp, 0x08
00007a3fbe1d7ba0  push rax
00007a3fbe1d7ba1  push rcx
00007a3fbe1d7ba2  push rdx
00007a3fbe1d7ba3  push rdi
00007a3fbe1d7ba4  push rsi
00007a3fbe1d7ba5  push r8
00007a3fbe1d7ba7  push r9
00007a3fbe1d7ba9  push r10
00007a3fbe1d7bab  push r11
00007a3fbe1d7bad  sub rsp, 0xF0
00007a3fbe1d7bb4  vmovaps [rsp], xmm0
00007a3fbe1d7bb9  vmovaps [rsp+0x10], xmm1
00007a3fbe1d7bbf  vmovaps [rsp+0x20], xmm2
00007a3fbe1d7bc5  vmovaps [rsp+0x30], xmm3
00007a3fbe1d7bcb  vmovaps [rsp+0x40], xmm4
00007a3fbe1d7bd1  vmovaps [rsp+0x50], xmm5
00007a3fbe1d7bd7  vmovaps [rsp+0x60], xmm6
00007a3fbe1d7bdd  vmovaps [rsp+0x70], xmm7
00007a3fbe1d7be3  vmovaps [rsp+0x80], xmm9
00007a3fbe1d7bec  vmovaps [rsp+0x90], xmm10
00007a3fbe1d7bf5  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d7bfe  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d7c07  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d7c10  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d7c19  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d7c22  sub rsp, 0x30
00007a3fbe1d7c26  movaps [rsp], xmm8
00007a3fbe1d7c2b  movaps [rsp+0x10], xmm15
00007a3fbe1d7c31  movaps [rsp+0x20], xmm9
00007a3fbe1d7c37  lea rdi, [rsp]
00007a3fbe1d7c3b  mov esi, 0x00
00007a3fbe1d7c40  mov rax, 0x60D1084DB530
00007a3fbe1d7c4a  call rax
00007a3fbe1d7c4c  movaps xmm8, [rsp]
00007a3fbe1d7c51  add rsp, 0x30
00007a3fbe1d7c55  vmovaps xmm0, [rsp]
00007a3fbe1d7c5a  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d7c60  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d7c66  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d7c6c  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d7c72  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d7c78  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d7c7e  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d7c84  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d7c8d  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d7c96  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d7c9f  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d7ca8  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d7cb1  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d7cba  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d7cc3  add rsp, 0xF0
00007a3fbe1d7cca  pop r11
00007a3fbe1d7ccc  pop r10
00007a3fbe1d7cce  pop r9
00007a3fbe1d7cd0  pop r8
00007a3fbe1d7cd2  pop rsi
00007a3fbe1d7cd3  pop rdi
00007a3fbe1d7cd4  pop rdx
00007a3fbe1d7cd5  pop rcx
00007a3fbe1d7cd6  pop rax
00007a3fbe1d7cd7  add rsp, 0x08
00007a3fbe1d7cdb  jmp 0x00007A3FBE1D33EA
00007a3fbe1d7ce0  sub rsp, 0x08
00007a3fbe1d7ce4  push rax
00007a3fbe1d7ce5  push rcx
00007a3fbe1d7ce6  push rdx
00007a3fbe1d7ce7  push rdi
00007a3fbe1d7ce8  push rsi
00007a3fbe1d7ce9  push r8
00007a3fbe1d7ceb  push r9
00007a3fbe1d7ced  push r10
00007a3fbe1d7cef  push r11
00007a3fbe1d7cf1  sub rsp, 0xF0
00007a3fbe1d7cf8  vmovaps [rsp], xmm0
00007a3fbe1d7cfd  vmovaps [rsp+0x10], xmm1
00007a3fbe1d7d03  vmovaps [rsp+0x20], xmm2
00007a3fbe1d7d09  vmovaps [rsp+0x30], xmm3
00007a3fbe1d7d0f  vmovaps [rsp+0x40], xmm4
00007a3fbe1d7d15  vmovaps [rsp+0x50], xmm5
00007a3fbe1d7d1b  vmovaps [rsp+0x60], xmm6
00007a3fbe1d7d21  vmovaps [rsp+0x70], xmm7
00007a3fbe1d7d27  vmovaps [rsp+0x80], xmm8
00007a3fbe1d7d30  vmovaps [rsp+0x90], xmm10
00007a3fbe1d7d39  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d7d42  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d7d4b  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d7d54  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d7d5d  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d7d66  sub rsp, 0x30
00007a3fbe1d7d6a  movaps [rsp], xmm9
00007a3fbe1d7d6f  movaps [rsp+0x10], xmm1
00007a3fbe1d7d74  movaps [rsp+0x20], xmm15
00007a3fbe1d7d7a  lea rdi, [rsp]
00007a3fbe1d7d7e  mov esi, 0x00
00007a3fbe1d7d83  mov rax, 0x60D1084DB530
00007a3fbe1d7d8d  call rax
00007a3fbe1d7d8f  movaps xmm9, [rsp]
00007a3fbe1d7d94  add rsp, 0x30
00007a3fbe1d7d98  vmovaps xmm0, [rsp]
00007a3fbe1d7d9d  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d7da3  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d7da9  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d7daf  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d7db5  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d7dbb  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d7dc1  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d7dc7  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d7dd0  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d7dd9  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d7de2  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d7deb  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d7df4  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d7dfd  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d7e06  add rsp, 0xF0
00007a3fbe1d7e0d  pop r11
00007a3fbe1d7e0f  pop r10
00007a3fbe1d7e11  pop r9
00007a3fbe1d7e13  pop r8
00007a3fbe1d7e15  pop rsi
00007a3fbe1d7e16  pop rdi
00007a3fbe1d7e17  pop rdx
00007a3fbe1d7e18  pop rcx
00007a3fbe1d7e19  pop rax
00007a3fbe1d7e1a  add rsp, 0x08
00007a3fbe1d7e1e  jmp 0x00007A3FBE1D3418
00007a3fbe1d7e23  sub rsp, 0x08
00007a3fbe1d7e27  push rax
00007a3fbe1d7e28  push rcx
00007a3fbe1d7e29  push rdx
00007a3fbe1d7e2a  push rdi
00007a3fbe1d7e2b  push rsi
00007a3fbe1d7e2c  push r8
00007a3fbe1d7e2e  push r9
00007a3fbe1d7e30  push r10
00007a3fbe1d7e32  push r11
00007a3fbe1d7e34  sub rsp, 0xF0
00007a3fbe1d7e3b  vmovaps [rsp], xmm0
00007a3fbe1d7e40  vmovaps [rsp+0x10], xmm1
00007a3fbe1d7e46  vmovaps [rsp+0x20], xmm2
00007a3fbe1d7e4c  vmovaps [rsp+0x30], xmm3
00007a3fbe1d7e52  vmovaps [rsp+0x40], xmm4
00007a3fbe1d7e58  vmovaps [rsp+0x50], xmm5
00007a3fbe1d7e5e  vmovaps [rsp+0x60], xmm6
00007a3fbe1d7e64  vmovaps [rsp+0x70], xmm7
00007a3fbe1d7e6a  vmovaps [rsp+0x80], xmm8
00007a3fbe1d7e73  vmovaps [rsp+0x90], xmm9
00007a3fbe1d7e7c  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d7e85  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d7e8e  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d7e97  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d7ea0  vmovaps [rsp+0xE0], xmm14
00007a3fbe1d7ea9  sub rsp, 0x30
00007a3fbe1d7ead  movaps [rsp], xmm15
00007a3fbe1d7eb2  movaps [rsp+0x10], xmm4
00007a3fbe1d7eb7  movaps [rsp+0x20], xmm1
00007a3fbe1d7ebc  lea rdi, [rsp]
00007a3fbe1d7ec0  mov esi, 0x00
00007a3fbe1d7ec5  mov rax, 0x60D1084DB530
00007a3fbe1d7ecf  call rax
00007a3fbe1d7ed1  movaps xmm15, [rsp]
00007a3fbe1d7ed6  add rsp, 0x30
00007a3fbe1d7eda  vmovaps xmm0, [rsp]
00007a3fbe1d7edf  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d7ee5  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d7eeb  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d7ef1  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d7ef7  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d7efd  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d7f03  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d7f09  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d7f12  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d7f1b  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d7f24  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d7f2d  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d7f36  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d7f3f  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1d7f48  add rsp, 0xF0
00007a3fbe1d7f4f  pop r11
00007a3fbe1d7f51  pop r10
00007a3fbe1d7f53  pop r9
00007a3fbe1d7f55  pop r8
00007a3fbe1d7f57  pop rsi
00007a3fbe1d7f58  pop rdi
00007a3fbe1d7f59  pop rdx
00007a3fbe1d7f5a  pop rcx
00007a3fbe1d7f5b  pop rax
00007a3fbe1d7f5c  add rsp, 0x08
00007a3fbe1d7f60  jmp 0x00007A3FBE1D343E
00007a3fbe1d7f65  sub rsp, 0x08
00007a3fbe1d7f69  push rax
00007a3fbe1d7f6a  push rcx
00007a3fbe1d7f6b  push rdx
00007a3fbe1d7f6c  push rdi
00007a3fbe1d7f6d  push rsi
00007a3fbe1d7f6e  push r8
00007a3fbe1d7f70  push r9
00007a3fbe1d7f72  push r10
00007a3fbe1d7f74  push r11
00007a3fbe1d7f76  sub rsp, 0xF0
00007a3fbe1d7f7d  vmovaps [rsp], xmm0
00007a3fbe1d7f82  vmovaps [rsp+0x10], xmm2
00007a3fbe1d7f88  vmovaps [rsp+0x20], xmm3
00007a3fbe1d7f8e  vmovaps [rsp+0x30], xmm4
00007a3fbe1d7f94  vmovaps [rsp+0x40], xmm5
00007a3fbe1d7f9a  vmovaps [rsp+0x50], xmm6
00007a3fbe1d7fa0  vmovaps [rsp+0x60], xmm7
00007a3fbe1d7fa6  vmovaps [rsp+0x70], xmm8
00007a3fbe1d7fac  vmovaps [rsp+0x80], xmm9
00007a3fbe1d7fb5  vmovaps [rsp+0x90], xmm10
00007a3fbe1d7fbe  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d7fc7  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d7fd0  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d7fd9  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d7fe2  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d7feb  sub rsp, 0x30
00007a3fbe1d7fef  movaps [rsp], xmm1
00007a3fbe1d7ff3  movaps [rsp+0x10], xmm14
00007a3fbe1d7ff9  movaps [rsp+0x20], xmm11
00007a3fbe1d7fff  lea rdi, [rsp]
00007a3fbe1d8003  mov esi, 0x00
00007a3fbe1d8008  mov rax, 0x60D1084DB530
00007a3fbe1d8012  call rax
00007a3fbe1d8014  movaps xmm1, [rsp]
00007a3fbe1d8018  add rsp, 0x30
00007a3fbe1d801c  vmovaps xmm0, [rsp]
00007a3fbe1d8021  vmovaps xmm2, [rsp+0x10]
00007a3fbe1d8027  vmovaps xmm3, [rsp+0x20]
00007a3fbe1d802d  vmovaps xmm4, [rsp+0x30]
00007a3fbe1d8033  vmovaps xmm5, [rsp+0x40]
00007a3fbe1d8039  vmovaps xmm6, [rsp+0x50]
00007a3fbe1d803f  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d8045  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d804b  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d8054  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d805d  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d8066  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d806f  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d8078  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d8081  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d808a  add rsp, 0xF0
00007a3fbe1d8091  pop r11
00007a3fbe1d8093  pop r10
00007a3fbe1d8095  pop r9
00007a3fbe1d8097  pop r8
00007a3fbe1d8099  pop rsi
00007a3fbe1d809a  pop rdi
00007a3fbe1d809b  pop rdx
00007a3fbe1d809c  pop rcx
00007a3fbe1d809d  pop rax
00007a3fbe1d809e  add rsp, 0x08
00007a3fbe1d80a2  jmp 0x00007A3FBE1D345F
00007a3fbe1d80a7  call 0x00007A3FBE0E45A0
00007a3fbe1d80ac  jmp 0x00007A3FBE1D346D
00007a3fbe1d80b1  call 0x00007A3FBE009D70
00007a3fbe1d80b6  jmp 0x00007A3FBE1D3477
00007a3fbe1d80bb  sub rsp, 0x08
00007a3fbe1d80bf  push rax
00007a3fbe1d80c0  push rcx
00007a3fbe1d80c1  push rdx
00007a3fbe1d80c2  push rdi
00007a3fbe1d80c3  push rsi
00007a3fbe1d80c4  push r8
00007a3fbe1d80c6  push r9
00007a3fbe1d80c8  push r10
00007a3fbe1d80ca  push r11
00007a3fbe1d80cc  sub rsp, 0xF0
00007a3fbe1d80d3  vmovaps [rsp], xmm0
00007a3fbe1d80d8  vmovaps [rsp+0x10], xmm1
00007a3fbe1d80de  vmovaps [rsp+0x20], xmm2
00007a3fbe1d80e4  vmovaps [rsp+0x30], xmm3
00007a3fbe1d80ea  vmovaps [rsp+0x40], xmm4
00007a3fbe1d80f0  vmovaps [rsp+0x50], xmm5
00007a3fbe1d80f6  vmovaps [rsp+0x60], xmm6
00007a3fbe1d80fc  vmovaps [rsp+0x70], xmm8
00007a3fbe1d8102  vmovaps [rsp+0x80], xmm9
00007a3fbe1d810b  vmovaps [rsp+0x90], xmm10
00007a3fbe1d8114  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d811d  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d8126  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d812f  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d8138  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d8141  sub rsp, 0x30
00007a3fbe1d8145  movaps [rsp], xmm7
00007a3fbe1d8149  movaps [rsp+0x10], xmm13
00007a3fbe1d814f  movaps [rsp+0x20], xmm10
00007a3fbe1d8155  lea rdi, [rsp]
00007a3fbe1d8159  mov esi, 0x00
00007a3fbe1d815e  mov rax, 0x60D1084DB530
00007a3fbe1d8168  call rax
00007a3fbe1d816a  movaps xmm7, [rsp]
00007a3fbe1d816e  add rsp, 0x30
00007a3fbe1d8172  vmovaps xmm0, [rsp]
00007a3fbe1d8177  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d817d  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d8183  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d8189  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d818f  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d8195  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d819b  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d81a1  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d81aa  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d81b3  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d81bc  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d81c5  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d81ce  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d81d7  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d81e0  add rsp, 0xF0
00007a3fbe1d81e7  pop r11
00007a3fbe1d81e9  pop r10
00007a3fbe1d81eb  pop r9
00007a3fbe1d81ed  pop r8
00007a3fbe1d81ef  pop rsi
00007a3fbe1d81f0  pop rdi
00007a3fbe1d81f1  pop rdx
00007a3fbe1d81f2  pop rcx
00007a3fbe1d81f3  pop rax
00007a3fbe1d81f4  add rsp, 0x08
00007a3fbe1d81f8  jmp 0x00007A3FBE1D3498
00007a3fbe1d81fd  sub rsp, 0x08
00007a3fbe1d8201  push rax
00007a3fbe1d8202  push rcx
00007a3fbe1d8203  push rdx
00007a3fbe1d8204  push rdi
00007a3fbe1d8205  push rsi
00007a3fbe1d8206  push r8
00007a3fbe1d8208  push r9
00007a3fbe1d820a  push r10
00007a3fbe1d820c  push r11
00007a3fbe1d820e  sub rsp, 0xF0
00007a3fbe1d8215  vmovaps [rsp], xmm0
00007a3fbe1d821a  vmovaps [rsp+0x10], xmm1
00007a3fbe1d8220  vmovaps [rsp+0x20], xmm2
00007a3fbe1d8226  vmovaps [rsp+0x30], xmm3
00007a3fbe1d822c  vmovaps [rsp+0x40], xmm4
00007a3fbe1d8232  vmovaps [rsp+0x50], xmm5
00007a3fbe1d8238  vmovaps [rsp+0x60], xmm6
00007a3fbe1d823e  vmovaps [rsp+0x70], xmm7
00007a3fbe1d8244  vmovaps [rsp+0x80], xmm8
00007a3fbe1d824d  vmovaps [rsp+0x90], xmm9
00007a3fbe1d8256  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d825f  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d8268  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d8271  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d827a  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d8283  sub rsp, 0x30
00007a3fbe1d8287  movaps [rsp], xmm10
00007a3fbe1d828c  movaps [rsp+0x10], xmm11
00007a3fbe1d8292  movaps [rsp+0x20], xmm13
00007a3fbe1d8298  lea rdi, [rsp]
00007a3fbe1d829c  mov esi, 0x00
00007a3fbe1d82a1  mov rax, 0x60D1084DB530
00007a3fbe1d82ab  call rax
00007a3fbe1d82ad  movaps xmm10, [rsp]
00007a3fbe1d82b2  add rsp, 0x30
00007a3fbe1d82b6  vmovaps xmm0, [rsp]
00007a3fbe1d82bb  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d82c1  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d82c7  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d82cd  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d82d3  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d82d9  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d82df  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d82e5  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d82ee  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d82f7  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d8300  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d8309  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d8312  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d831b  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d8324  add rsp, 0xF0
00007a3fbe1d832b  pop r11
00007a3fbe1d832d  pop r10
00007a3fbe1d832f  pop r9
00007a3fbe1d8331  pop r8
00007a3fbe1d8333  pop rsi
00007a3fbe1d8334  pop rdi
00007a3fbe1d8335  pop rdx
00007a3fbe1d8336  pop rcx
00007a3fbe1d8337  pop rax
00007a3fbe1d8338  add rsp, 0x08
00007a3fbe1d833c  jmp 0x00007A3FBE1D34C6
00007a3fbe1d8341  sub rsp, 0x08
00007a3fbe1d8345  push rax
00007a3fbe1d8346  push rcx
00007a3fbe1d8347  push rdx
00007a3fbe1d8348  push rdi
00007a3fbe1d8349  push rsi
00007a3fbe1d834a  push r8
00007a3fbe1d834c  push r9
00007a3fbe1d834e  push r10
00007a3fbe1d8350  push r11
00007a3fbe1d8352  sub rsp, 0xF0
00007a3fbe1d8359  vmovaps [rsp], xmm0
00007a3fbe1d835e  vmovaps [rsp+0x10], xmm1
00007a3fbe1d8364  vmovaps [rsp+0x20], xmm2
00007a3fbe1d836a  vmovaps [rsp+0x30], xmm3
00007a3fbe1d8370  vmovaps [rsp+0x40], xmm4
00007a3fbe1d8376  vmovaps [rsp+0x50], xmm5
00007a3fbe1d837c  vmovaps [rsp+0x60], xmm6
00007a3fbe1d8382  vmovaps [rsp+0x70], xmm7
00007a3fbe1d8388  vmovaps [rsp+0x80], xmm8
00007a3fbe1d8391  vmovaps [rsp+0x90], xmm9
00007a3fbe1d839a  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d83a3  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d83ac  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d83b5  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d83be  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d83c7  sub rsp, 0x30
00007a3fbe1d83cb  movaps [rsp], xmm11
00007a3fbe1d83d0  movaps [rsp+0x10], xmm14
00007a3fbe1d83d6  movaps [rsp+0x20], xmm13
00007a3fbe1d83dc  lea rdi, [rsp]
00007a3fbe1d83e0  mov esi, 0x00
00007a3fbe1d83e5  mov rax, 0x60D1084DB530
00007a3fbe1d83ef  call rax
00007a3fbe1d83f1  movaps xmm11, [rsp]
00007a3fbe1d83f6  add rsp, 0x30
00007a3fbe1d83fa  vmovaps xmm0, [rsp]
00007a3fbe1d83ff  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d8405  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d840b  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d8411  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d8417  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d841d  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d8423  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d8429  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d8432  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d843b  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d8444  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d844d  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d8456  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d845f  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d8468  add rsp, 0xF0
00007a3fbe1d846f  pop r11
00007a3fbe1d8471  pop r10
00007a3fbe1d8473  pop r9
00007a3fbe1d8475  pop r8
00007a3fbe1d8477  pop rsi
00007a3fbe1d8478  pop rdi
00007a3fbe1d8479  pop rdx
00007a3fbe1d847a  pop rcx
00007a3fbe1d847b  pop rax
00007a3fbe1d847c  add rsp, 0x08
00007a3fbe1d8480  jmp 0x00007A3FBE1D34F4
00007a3fbe1d8485  sub rsp, 0x08
00007a3fbe1d8489  push rax
00007a3fbe1d848a  push rcx
00007a3fbe1d848b  push rdx
00007a3fbe1d848c  push rdi
00007a3fbe1d848d  push rsi
00007a3fbe1d848e  push r8
00007a3fbe1d8490  push r9
00007a3fbe1d8492  push r10
00007a3fbe1d8494  push r11
00007a3fbe1d8496  sub rsp, 0xF0
00007a3fbe1d849d  vmovaps [rsp], xmm0
00007a3fbe1d84a2  vmovaps [rsp+0x10], xmm1
00007a3fbe1d84a8  vmovaps [rsp+0x20], xmm2
00007a3fbe1d84ae  vmovaps [rsp+0x30], xmm3
00007a3fbe1d84b4  vmovaps [rsp+0x40], xmm4
00007a3fbe1d84ba  vmovaps [rsp+0x50], xmm5
00007a3fbe1d84c0  vmovaps [rsp+0x60], xmm6
00007a3fbe1d84c6  vmovaps [rsp+0x70], xmm7
00007a3fbe1d84cc  vmovaps [rsp+0x80], xmm8
00007a3fbe1d84d5  vmovaps [rsp+0x90], xmm9
00007a3fbe1d84de  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d84e7  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d84f0  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d84f9  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d8502  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d850b  sub rsp, 0x30
00007a3fbe1d850f  movaps [rsp], xmm14
00007a3fbe1d8514  movaps [rsp+0x10], xmm12
00007a3fbe1d851a  movaps [rsp+0x20], xmm9
00007a3fbe1d8520  lea rdi, [rsp]
00007a3fbe1d8524  mov esi, 0x00
00007a3fbe1d8529  mov rax, 0x60D1084DB530
00007a3fbe1d8533  call rax
00007a3fbe1d8535  movaps xmm14, [rsp]
00007a3fbe1d853a  add rsp, 0x30
00007a3fbe1d853e  vmovaps xmm0, [rsp]
00007a3fbe1d8543  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d8549  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d854f  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d8555  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d855b  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d8561  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d8567  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d856d  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d8576  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d857f  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d8588  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d8591  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d859a  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d85a3  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d85ac  add rsp, 0xF0
00007a3fbe1d85b3  pop r11
00007a3fbe1d85b5  pop r10
00007a3fbe1d85b7  pop r9
00007a3fbe1d85b9  pop r8
00007a3fbe1d85bb  pop rsi
00007a3fbe1d85bc  pop rdi
00007a3fbe1d85bd  pop rdx
00007a3fbe1d85be  pop rcx
00007a3fbe1d85bf  pop rax
00007a3fbe1d85c0  add rsp, 0x08
00007a3fbe1d85c4  jmp 0x00007A3FBE1D350F
00007a3fbe1d85c9  sub rsp, 0x08
00007a3fbe1d85cd  push rax
00007a3fbe1d85ce  push rcx
00007a3fbe1d85cf  push rdx
00007a3fbe1d85d0  push rdi
00007a3fbe1d85d1  push rsi
00007a3fbe1d85d2  push r8
00007a3fbe1d85d4  push r9
00007a3fbe1d85d6  push r10
00007a3fbe1d85d8  push r11
00007a3fbe1d85da  sub rsp, 0xF0
00007a3fbe1d85e1  vmovaps [rsp], xmm0
00007a3fbe1d85e6  vmovaps [rsp+0x10], xmm1
00007a3fbe1d85ec  vmovaps [rsp+0x20], xmm2
00007a3fbe1d85f2  vmovaps [rsp+0x30], xmm3
00007a3fbe1d85f8  vmovaps [rsp+0x40], xmm4
00007a3fbe1d85fe  vmovaps [rsp+0x50], xmm5
00007a3fbe1d8604  vmovaps [rsp+0x60], xmm6
00007a3fbe1d860a  vmovaps [rsp+0x70], xmm7
00007a3fbe1d8610  vmovaps [rsp+0x80], xmm8
00007a3fbe1d8619  vmovaps [rsp+0x90], xmm9
00007a3fbe1d8622  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d862b  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d8634  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d863d  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d8646  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d864f  sub rsp, 0x30
00007a3fbe1d8653  movaps [rsp], xmm13
00007a3fbe1d8658  movaps [rsp+0x10], xmm8
00007a3fbe1d865e  movaps [rsp+0x20], xmm15
00007a3fbe1d8664  lea rdi, [rsp]
00007a3fbe1d8668  mov esi, 0x00
00007a3fbe1d866d  mov rax, 0x60D1084DB530
00007a3fbe1d8677  call rax
00007a3fbe1d8679  movaps xmm13, [rsp]
00007a3fbe1d867e  add rsp, 0x30
00007a3fbe1d8682  vmovaps xmm0, [rsp]
00007a3fbe1d8687  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d868d  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d8693  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d8699  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d869f  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d86a5  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d86ab  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d86b1  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d86ba  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d86c3  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d86cc  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d86d5  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d86de  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d86e7  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d86f0  add rsp, 0xF0
00007a3fbe1d86f7  pop r11
00007a3fbe1d86f9  pop r10
00007a3fbe1d86fb  pop r9
00007a3fbe1d86fd  pop r8
00007a3fbe1d86ff  pop rsi
00007a3fbe1d8700  pop rdi
00007a3fbe1d8701  pop rdx
00007a3fbe1d8702  pop rcx
00007a3fbe1d8703  pop rax
00007a3fbe1d8704  add rsp, 0x08
00007a3fbe1d8708  jmp 0x00007A3FBE1D3532
00007a3fbe1d870d  sub rsp, 0x08
00007a3fbe1d8711  push rax
00007a3fbe1d8712  push rcx
00007a3fbe1d8713  push rdx
00007a3fbe1d8714  push rdi
00007a3fbe1d8715  push rsi
00007a3fbe1d8716  push r8
00007a3fbe1d8718  push r9
00007a3fbe1d871a  push r10
00007a3fbe1d871c  push r11
00007a3fbe1d871e  sub rsp, 0xF0
00007a3fbe1d8725  vmovaps [rsp], xmm0
00007a3fbe1d872a  vmovaps [rsp+0x10], xmm1
00007a3fbe1d8730  vmovaps [rsp+0x20], xmm2
00007a3fbe1d8736  vmovaps [rsp+0x30], xmm3
00007a3fbe1d873c  vmovaps [rsp+0x40], xmm4
00007a3fbe1d8742  vmovaps [rsp+0x50], xmm5
00007a3fbe1d8748  vmovaps [rsp+0x60], xmm6
00007a3fbe1d874e  vmovaps [rsp+0x70], xmm7
00007a3fbe1d8754  vmovaps [rsp+0x80], xmm8
00007a3fbe1d875d  vmovaps [rsp+0x90], xmm9
00007a3fbe1d8766  vmovaps [rsp+0xA0], xmm10
00007a3fbe1d876f  vmovaps [rsp+0xB0], xmm11
00007a3fbe1d8778  vmovaps [rsp+0xC0], xmm12
00007a3fbe1d8781  vmovaps [rsp+0xD0], xmm13
00007a3fbe1d878a  vmovaps [rsp+0xE0], xmm14
00007a3fbe1d8793  sub rsp, 0x30
00007a3fbe1d8797  movaps [rsp], xmm15
00007a3fbe1d879c  movaps [rsp+0x10], xmm1
00007a3fbe1d87a1  movaps [rsp+0x20], xmm10
00007a3fbe1d87a7  lea rdi, [rsp]
00007a3fbe1d87ab  mov esi, 0x00
00007a3fbe1d87b0  mov rax, 0x60D1084DB530
00007a3fbe1d87ba  call rax
00007a3fbe1d87bc  movaps xmm15, [rsp]
00007a3fbe1d87c1  add rsp, 0x30
00007a3fbe1d87c5  vmovaps xmm0, [rsp]
00007a3fbe1d87ca  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d87d0  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d87d6  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d87dc  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d87e2  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d87e8  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d87ee  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d87f4  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d87fd  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d8806  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1d880f  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1d8818  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1d8821  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1d882a  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1d8833  add rsp, 0xF0
00007a3fbe1d883a  pop r11
00007a3fbe1d883c  pop r10
00007a3fbe1d883e  pop r9
00007a3fbe1d8840  pop r8
00007a3fbe1d8842  pop rsi
00007a3fbe1d8843  pop rdi
00007a3fbe1d8844  pop rdx
00007a3fbe1d8845  pop rcx
00007a3fbe1d8846  pop rax
00007a3fbe1d8847  add rsp, 0x08
00007a3fbe1d884b  jmp 0x00007A3FBE1D3555
00007a3fbe1d8850  sub rsp, 0x08
00007a3fbe1d8854  push rax
00007a3fbe1d8855  push rcx
00007a3fbe1d8856  push rdx
00007a3fbe1d8857  push rdi
00007a3fbe1d8858  push rsi
00007a3fbe1d8859  push r8
00007a3fbe1d885b  push r9
00007a3fbe1d885d  push r10
00007a3fbe1d885f  push r11
00007a3fbe1d8861  sub rsp, 0xF0
00007a3fbe1d8868  vmovaps [rsp], xmm0
00007a3fbe1d886d  vmovaps [rsp+0x10], xmm2
00007a3fbe1d8873  vmovaps [rsp+0x20], xmm3
00007a3fbe1d8879  vmovaps [rsp+0x30], xmm4
00007a3fbe1d887f  vmovaps [rsp+0x40], xmm5
00007a3fbe1d8885  vmovaps [rsp+0x50], xmm6
00007a3fbe1d888b  vmovaps [rsp+0x60], xmm7
00007a3fbe1d8891  vmovaps [rsp+0x70], xmm8
00007a3fbe1d8897  vmovaps [rsp+0x80], xmm9
00007a3fbe1d88a0  vmovaps [rsp+0x90], xmm10
00007a3fbe1d88a9  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d88b2  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d88bb  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d88c4  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d88cd  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d88d6  sub rsp, 0x30
00007a3fbe1d88da  movaps [rsp], xmm1
00007a3fbe1d88de  movaps [rsp+0x10], xmm7
00007a3fbe1d88e3  movaps [rsp+0x20], xmm11
00007a3fbe1d88e9  lea rdi, [rsp]
00007a3fbe1d88ed  mov esi, 0x00
00007a3fbe1d88f2  mov rax, 0x60D1084DB530
00007a3fbe1d88fc  call rax
00007a3fbe1d88fe  movaps xmm1, [rsp]
00007a3fbe1d8902  add rsp, 0x30
00007a3fbe1d8906  vmovaps xmm0, [rsp]
00007a3fbe1d890b  vmovaps xmm2, [rsp+0x10]
00007a3fbe1d8911  vmovaps xmm3, [rsp+0x20]
00007a3fbe1d8917  vmovaps xmm4, [rsp+0x30]
00007a3fbe1d891d  vmovaps xmm5, [rsp+0x40]
00007a3fbe1d8923  vmovaps xmm6, [rsp+0x50]
00007a3fbe1d8929  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d892f  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d8935  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d893e  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d8947  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d8950  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d8959  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d8962  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d896b  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d8974  add rsp, 0xF0
00007a3fbe1d897b  pop r11
00007a3fbe1d897d  pop r10
00007a3fbe1d897f  pop r9
00007a3fbe1d8981  pop r8
00007a3fbe1d8983  pop rsi
00007a3fbe1d8984  pop rdi
00007a3fbe1d8985  pop rdx
00007a3fbe1d8986  pop rcx
00007a3fbe1d8987  pop rax
00007a3fbe1d8988  add rsp, 0x08
00007a3fbe1d898c  jmp 0x00007A3FBE1D3576
00007a3fbe1d8991  call 0x00007A3FBE00D600
00007a3fbe1d8996  jmp 0x00007A3FBE1D3589
00007a3fbe1d899b  call 0x00007A3FBE00C380
00007a3fbe1d89a0  jmp 0x00007A3FBE1D3594
00007a3fbe1d89a5  call 0x00007A3FBE00E880
00007a3fbe1d89aa  jmp 0x00007A3FBE1D359F
00007a3fbe1d89af  call 0x00007A3FBDFFF540
00007a3fbe1d89b4  jmp 0x00007A3FBE1D35AA
00007a3fbe1d89b9  int3
00007a3fbe1d89ba  nop [rax+rax*1], ax
00007a3fbe1d89c0  mov rax, [r15+0x40]
00007a3fbe1d89c4  mov r14, [r15+0x58]
00007a3fbe1d89c8  lea r12, [rax+r14*1]
00007a3fbe1d89cc  movaps xmm1, [r15+0x1D0]
00007a3fbe1d89d4  vmovaps [rsp+0x10], xmm1
00007a3fbe1d89da  vmovaps xmm15, [rsp+0x10]
00007a3fbe1d89e0  por xmm1, xmm15
00007a3fbe1d89e5  movaps xmm14, [r15+0x1A0]
00007a3fbe1d89ed  vmovaps [rsp+0x10], xmm14
00007a3fbe1d89f3  vmovaps xmm13, [rsp+0x10]
00007a3fbe1d89f9  por xmm14, xmm13
00007a3fbe1d89fe  lea rax, [r12+0x30]
00007a3fbe1d8a03  mov r11, [r13+rax*1]
00007a3fbe1d8a08  lea rax, [r12+0x38]
00007a3fbe1d8a0d  mov r10, [r13+rax*1]
00007a3fbe1d8a12  movq xmm13, r11
00007a3fbe1d8a17  movq xmm12, r10
00007a3fbe1d8a1c  movq xmm13, xmm13
00007a3fbe1d8a21  vmovaps [rsp+0x10], xmm13
00007a3fbe1d8a27  movq xmm13, xmm13
00007a3fbe1d8a2c  movaps [r15+0x130], xmm13
00007a3fbe1d8a34  movq xmm12, xmm12
00007a3fbe1d8a39  vmovaps [rsp+0x20], xmm12
00007a3fbe1d8a3f  movq xmm12, xmm12
00007a3fbe1d8a44  movaps [r15+0x280], xmm12
00007a3fbe1d8a4c  movaps xmm13, [r15+0x270]
00007a3fbe1d8a54  vmovaps [rsp+0x30], xmm13
00007a3fbe1d8a5a  vmovaps xmm12, [rsp+0x30]
00007a3fbe1d8a60  por xmm13, xmm12
00007a3fbe1d8a65  lea rax, [r12+0x20]
00007a3fbe1d8a6a  mov r11, [r13+rax*1]
00007a3fbe1d8a6f  lea rax, [r12+0x28]
00007a3fbe1d8a74  mov r10, [r13+rax*1]
00007a3fbe1d8a79  movq xmm12, r11
00007a3fbe1d8a7e  movq xmm11, r10
00007a3fbe1d8a83  movq xmm12, xmm12
00007a3fbe1d8a88  vmovaps [rsp+0x30], xmm12
00007a3fbe1d8a8e  movq xmm12, xmm12
00007a3fbe1d8a93  movaps [r15+0x150], xmm12
00007a3fbe1d8a9b  movq xmm11, xmm11
00007a3fbe1d8aa0  vmovaps [rsp+0x40], xmm11
00007a3fbe1d8aa6  movq xmm11, xmm11
00007a3fbe1d8aab  movaps [r15+0x140], xmm11
00007a3fbe1d8ab3  lea rax, [r12+0x10]
00007a3fbe1d8ab8  mov r11, [r13+rax*1]
00007a3fbe1d8abd  lea rax, [r12+0x18]
00007a3fbe1d8ac2  mov r10, [r13+rax*1]
00007a3fbe1d8ac7  movq xmm12, r11
00007a3fbe1d8acc  movq xmm11, r10
00007a3fbe1d8ad1  movq xmm12, xmm12
00007a3fbe1d8ad6  vmovaps [rsp+0x50], xmm12
00007a3fbe1d8adc  movq xmm12, xmm12
00007a3fbe1d8ae1  movaps [r15+0x170], xmm12
00007a3fbe1d8ae9  movq xmm11, xmm11
00007a3fbe1d8aee  vmovaps [rsp+0x60], xmm11
00007a3fbe1d8af4  movq xmm11, xmm11
00007a3fbe1d8af9  movaps [r15+0x160], xmm11
00007a3fbe1d8b01  mov rax, [r13+r12*1]
00007a3fbe1d8b06  vmovq xmm12, rax
00007a3fbe1d8b0b  vpbroadcastq xmm12, xmm12
00007a3fbe1d8b10  lea rax, [r12+0x08]
00007a3fbe1d8b15  mov r12, [r13+rax*1]
00007a3fbe1d8b1a  movq xmm11, r12
00007a3fbe1d8b1f  movaps [r15+0x230], xmm11
00007a3fbe1d8b27  mov rax, [r15+0xF8]
00007a3fbe1d8b2e  lea r12, [rax+0x50]
00007a3fbe1d8b32  movups xmm11, [r13+r12*1]
00007a3fbe1d8b38  lea r12, [rax+0x60]
00007a3fbe1d8b3c  movups xmm10, [r13+r12*1]
00007a3fbe1d8b42  lea r12, [rax+0x30]
00007a3fbe1d8b46  movups xmm9, [r13+r12*1]
00007a3fbe1d8b4c  mov r12, [r15+0x50]
00007a3fbe1d8b50  lea r11, [r12+r14*1]
00007a3fbe1d8b54  mov [r15+0x60], r11
00007a3fbe1d8b58  lea r12, [r14+0x40]
00007a3fbe1d8b5c  mov [r15+0x58], r12
00007a3fbe1d8b60  movaps xmm8, xmm12
00007a3fbe1d8b64  mulpd xmm8, xmm15
00007a3fbe1d8b69  vcmppd xmm7, xmm8, xmm8, 0x03
00007a3fbe1d8b6f  ptest xmm7, xmm7
00007a3fbe1d8b74  jnz 0x00007A3FBE1D9997
00007a3fbe1d8b7a  movq xmm15, qword ptr [r15+0x230]
00007a3fbe1d8b83  vmovaps [rsp+0x70], xmm15
00007a3fbe1d8b89  vpermilpd xmm15, xmm15, 0x00
00007a3fbe1d8b8f  movaps xmm7, xmm9
00007a3fbe1d8b93  mulpd xmm7, xmm15
00007a3fbe1d8b98  vcmppd xmm6, xmm7, xmm7, 0x03
00007a3fbe1d8b9d  ptest xmm6, xmm6
00007a3fbe1d8ba2  jnz 0x00007A3FBE1D9ADB
00007a3fbe1d8ba8  vxorps xmm15, xmm15, xmm15
00007a3fbe1d8bad  vpbroadcastq xmm15, xmm15
00007a3fbe1d8bb2  movaps xmm9, xmm12
00007a3fbe1d8bb6  mulpd xmm9, xmm10
00007a3fbe1d8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
00007a3fbe1d8bc1  ptest xmm6, xmm6
00007a3fbe1d8bc6  jnz 0x00007A3FBE1D9C1D
00007a3fbe1d8bcc  movaps xmm10, xmm12
00007a3fbe1d8bd0  mulpd xmm10, xmm11
00007a3fbe1d8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
00007a3fbe1d8bdb  ptest xmm6, xmm6
00007a3fbe1d8be0  jnz 0x00007A3FBE1D9D61
00007a3fbe1d8be6  movaps xmm11, [r15+0x1F0]
00007a3fbe1d8bee  movaps xmm6, xmm12
00007a3fbe1d8bf2  mulpd xmm6, xmm11
00007a3fbe1d8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
00007a3fbe1d8bfc  ptest xmm5, xmm5
00007a3fbe1d8c01  jnz 0x00007A3FBE1D9EA5
00007a3fbe1d8c07  movaps xmm12, [r15+0x2A0]
00007a3fbe1d8c0f  vmovaps [rsp+0x80], xmm12
00007a3fbe1d8c18  vmovaps xmm11, [rsp+0x80]
00007a3fbe1d8c21  por xmm12, xmm11
00007a3fbe1d8c26  movaps xmm11, [r15+0x250]
00007a3fbe1d8c2e  vmovaps [rsp+0x80], xmm11
00007a3fbe1d8c37  vmovaps xmm5, [rsp+0x80]
00007a3fbe1d8c40  por xmm11, xmm5
00007a3fbe1d8c45  vmovaps xmm4, [rsp+0x70]
00007a3fbe1d8c4b  vpermilpd xmm4, xmm4, 0x00
00007a3fbe1d8c51  movaps xmm3, xmm5
00007a3fbe1d8c54  mulpd xmm3, xmm4
00007a3fbe1d8c58  vcmppd xmm2, xmm3, xmm3, 0x03
00007a3fbe1d8c5d  ptest xmm2, xmm2
00007a3fbe1d8c62  jnz 0x00007A3FBE1D9FE7
00007a3fbe1d8c68  mov [rsp+0x80], rax
00007a3fbe1d8c70  xor eax, eax
00007a3fbe1d8c72  mov r14d, 0x200
00007a3fbe1d8c78  cmp r12, r14
00007a3fbe1d8c7b  cmc
00007a3fbe1d8c7c  lahf
00007a3fbe1d8c7d  seto al
00007a3fbe1d8c80  mov [r15+0x108], eax
00007a3fbe1d8c87  movaps xmm5, xmm8
00007a3fbe1d8c8b  addpd xmm5, xmm15
00007a3fbe1d8c90  vcmppd xmm4, xmm5, xmm5, 0x03
00007a3fbe1d8c95  ptest xmm4, xmm4
00007a3fbe1d8c9a  jnz 0x00007A3FBE1DA127
00007a3fbe1d8ca0  movaps xmm8, [r15+0x1B0]
00007a3fbe1d8ca8  movaps xmm4, xmm9
00007a3fbe1d8cac  addpd xmm4, xmm8
00007a3fbe1d8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
00007a3fbe1d8cb6  ptest xmm2, xmm2
00007a3fbe1d8cbb  jnz 0x00007A3FBE1DA269
00007a3fbe1d8cc1  movaps xmm9, xmm10
00007a3fbe1d8cc5  addpd xmm9, xmm8
00007a3fbe1d8cca  vcmppd xmm2, xmm9, xmm9, 0x03
00007a3fbe1d8cd0  ptest xmm2, xmm2
00007a3fbe1d8cd5  jnz 0x00007A3FBE1DA3AB
00007a3fbe1d8cdb  movaps xmm10, [r15+0x2F0]
00007a3fbe1d8ce3  vmovaps [rsp+0x90], xmm10
00007a3fbe1d8cec  vmovaps xmm8, [rsp+0x90]
00007a3fbe1d8cf5  por xmm10, xmm8
00007a3fbe1d8cfa  movaps xmm8, [r15+0x2E0]
00007a3fbe1d8d02  vmovaps [rsp+0x90], xmm8
00007a3fbe1d8d0b  vmovaps xmm2, [rsp+0x90]
00007a3fbe1d8d14  por xmm8, xmm2
00007a3fbe1d8d19  movaps xmm2, [r15+0x2D0]
00007a3fbe1d8d21  vmovaps [rsp+0x90], xmm2
00007a3fbe1d8d2a  vmovaps [rsp+0xA0], xmm1
00007a3fbe1d8d33  vmovaps xmm1, [rsp+0x90]
00007a3fbe1d8d3c  por xmm2, xmm1
00007a3fbe1d8d40  movaps xmm1, [r15+0x200]
00007a3fbe1d8d48  vmovaps [rsp+0x90], xmm1
00007a3fbe1d8d51  vmovaps [rsp+0xB0], xmm15
00007a3fbe1d8d5a  vmovaps xmm15, [rsp+0x90]
00007a3fbe1d8d63  por xmm1, xmm15
00007a3fbe1d8d68  movaps xmm15, [r15+0x1C0]
00007a3fbe1d8d70  vmovaps [rsp+0x90], xmm15
00007a3fbe1d8d79  vmovaps [rsp+0xC0], xmm1
00007a3fbe1d8d82  vmovaps xmm1, [rsp+0x90]
00007a3fbe1d8d8b  por xmm15, xmm1
00007a3fbe1d8d90  movaps xmm1, [r15+0x190]
00007a3fbe1d8d98  vmovaps [rsp+0x90], xmm1
00007a3fbe1d8da1  vmovaps [rsp+0xD0], xmm15
00007a3fbe1d8daa  vmovaps xmm15, [rsp+0x90]
00007a3fbe1d8db3  por xmm1, xmm15
00007a3fbe1d8db8  movaps xmm15, [r15+0x300]
00007a3fbe1d8dc0  vmovaps [rsp+0x90], xmm15
00007a3fbe1d8dc9  vmovaps [rsp+0xE0], xmm1
00007a3fbe1d8dd2  vmovaps xmm1, [rsp+0x90]
00007a3fbe1d8ddb  por xmm15, xmm1
00007a3fbe1d8de0  mov rax, [rsp+0x80]
00007a3fbe1d8de8  lea r14, [rax+0xA0]
00007a3fbe1d8def  movups xmm1, [r13+r14*1]
00007a3fbe1d8df5  lea r14, [rax+0xB0]
00007a3fbe1d8dfc  vmovaps [rsp+0x80], xmm1
00007a3fbe1d8e05  movups xmm1, [r13+r14*1]
00007a3fbe1d8e0b  vmovaps [rsp+0x90], xmm1
00007a3fbe1d8e14  vmovaps [rsp+0xF0], xmm15
00007a3fbe1d8e1d  vmovaps xmm15, [rsp+0xB0]
00007a3fbe1d8e26  vmovaps [rsp+0xB0], xmm14
00007a3fbe1d8e2f  movaps xmm1, xmm6
00007a3fbe1d8e32  addpd xmm1, xmm15
00007a3fbe1d8e37  vcmppd xmm14, xmm1, xmm1, 0x03
00007a3fbe1d8e3c  ptest xmm14, xmm14
00007a3fbe1d8e42  jnz 0x00007A3FBE1DA503
00007a3fbe1d8e48  lea r14, [rax+0xF0]
00007a3fbe1d8e4f  movups xmm15, [r13+r14*1]
00007a3fbe1d8e55  movaps xmm14, xmm4
00007a3fbe1d8e59  addpd xmm14, xmm3
00007a3fbe1d8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
00007a3fbe1d8e64  ptest xmm6, xmm6
00007a3fbe1d8e69  jnz 0x00007A3FBE1DA64E
00007a3fbe1d8e6f  movaps xmm6, xmm9
00007a3fbe1d8e73  addpd xmm6, xmm7
00007a3fbe1d8e77  vcmppd xmm4, xmm6, xmm6, 0x03
00007a3fbe1d8e7c  ptest xmm4, xmm4
00007a3fbe1d8e81  jnz 0x00007A3FBE1DA790
00007a3fbe1d8e87  vmovaps xmm9, [rsp+0x70]
00007a3fbe1d8e8d  vpermilpd xmm9, xmm9, 0x00
00007a3fbe1d8e93  vmovaps xmm4, [rsp+0x90]
00007a3fbe1d8e9c  movaps xmm7, xmm4
00007a3fbe1d8e9f  mulpd xmm7, xmm9
00007a3fbe1d8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
00007a3fbe1d8ea9  ptest xmm3, xmm3
00007a3fbe1d8eae  jnz 0x00007A3FBE1DA8D1
00007a3fbe1d8eb4  vmovaps xmm9, [rsp+0x50]
00007a3fbe1d8eba  vpermilpd xmm9, xmm9, 0x00
00007a3fbe1d8ec0  movaps xmm4, xmm15
00007a3fbe1d8ec4  mulpd xmm4, xmm9
00007a3fbe1d8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
00007a3fbe1d8ece  ptest xmm3, xmm3
00007a3fbe1d8ed3  jnz 0x00007A3FBE1DAA12
00007a3fbe1d8ed9  lea r14, [rax+0xE0]
00007a3fbe1d8ee0  movups xmm15, [r13+r14*1]
00007a3fbe1d8ee6  vmovaps xmm9, [rsp+0x70]
00007a3fbe1d8eec  vpermilpd xmm9, xmm9, 0x00
00007a3fbe1d8ef2  vmovaps [rsp+0x70], xmm1
00007a3fbe1d8ef8  vmovaps xmm1, [rsp+0x80]
00007a3fbe1d8f01  vmovaps [rsp+0x80], xmm15
00007a3fbe1d8f0a  movaps xmm3, xmm1
00007a3fbe1d8f0d  mulpd xmm3, xmm9
00007a3fbe1d8f12  vcmppd xmm15, xmm3, xmm3, 0x03
00007a3fbe1d8f17  ptest xmm15, xmm15
00007a3fbe1d8f1d  jnz 0x00007A3FBE1DAB5E
00007a3fbe1d8f23  vmovaps xmm1, [rsp+0xF0]
00007a3fbe1d8f2c  vmovaps xmm15, [rsp+0xF0]
00007a3fbe1d8f35  por xmm1, xmm15
00007a3fbe1d8f3a  movaps [r15+0x300], xmm1
00007a3fbe1d8f42  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d8f4b  vmovaps xmm9, [rsp+0xE0]
00007a3fbe1d8f54  por xmm15, xmm9
00007a3fbe1d8f59  movaps [r15+0x190], xmm15
00007a3fbe1d8f61  vmovaps xmm9, [rsp+0x50]
00007a3fbe1d8f67  vpermilpd xmm9, xmm9, 0x00
00007a3fbe1d8f6d  vmovaps [rsp+0x90], xmm1
00007a3fbe1d8f76  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d8f7f  vmovaps xmm15, [rsp+0x80]
00007a3fbe1d8f88  vmovaps [rsp+0x80], xmm14
00007a3fbe1d8f91  movaps xmm1, xmm15
00007a3fbe1d8f95  mulpd xmm1, xmm9
00007a3fbe1d8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
00007a3fbe1d8f9f  ptest xmm14, xmm14
00007a3fbe1d8fa5  jnz 0x00007A3FBE1DAC9F
00007a3fbe1d8fab  lea r14, [rax+0x90]
00007a3fbe1d8fb2  movups xmm15, [r13+r14*1]
00007a3fbe1d8fb8  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d8fc1  vmovaps xmm9, [rsp+0xD0]
00007a3fbe1d8fca  por xmm14, xmm9
00007a3fbe1d8fcf  movaps [r15+0x1C0], xmm14
00007a3fbe1d8fd7  vmovaps xmm9, [rsp+0xC0]
00007a3fbe1d8fe0  vmovaps [rsp+0xD0], xmm1
00007a3fbe1d8fe9  vmovaps xmm1, [rsp+0xC0]
00007a3fbe1d8ff2  por xmm9, xmm1
00007a3fbe1d8ff7  movaps [r15+0x200], xmm9
00007a3fbe1d8fff  vmovaps [rsp+0xC0], xmm2
00007a3fbe1d9008  vmovaps xmm1, [rsp+0xC0]
00007a3fbe1d9011  por xmm2, xmm1
00007a3fbe1d9015  movaps [r15+0x2D0], xmm2
00007a3fbe1d901d  vmovaps [rsp+0xC0], xmm8
00007a3fbe1d9026  vmovaps xmm1, [rsp+0xC0]
00007a3fbe1d902f  por xmm8, xmm1
00007a3fbe1d9034  movaps [r15+0x2E0], xmm8
00007a3fbe1d903c  vmovaps [rsp+0xC0], xmm15
00007a3fbe1d9045  movaps xmm1, xmm5
00007a3fbe1d9048  addpd xmm1, xmm7
00007a3fbe1d904c  vcmppd xmm15, xmm1, xmm1, 0x03
00007a3fbe1d9051  ptest xmm15, xmm15
00007a3fbe1d9057  jnz 0x00007A3FBE1DADEB
00007a3fbe1d905d  vmovaps xmm15, [rsp+0x50]
00007a3fbe1d9063  vpermilpd xmm15, xmm15, 0x00
00007a3fbe1d9069  vmovaps xmm5, [rsp+0xC0]
00007a3fbe1d9072  vmovaps [rsp+0xC0], xmm1
00007a3fbe1d907b  movaps xmm7, xmm5
00007a3fbe1d907e  mulpd xmm7, xmm15
00007a3fbe1d9083  vcmppd xmm1, xmm7, xmm7, 0x03
00007a3fbe1d9088  ptest xmm1, xmm1
00007a3fbe1d908d  jnz 0x00007A3FBE1DAF2B
00007a3fbe1d9093  lea r14, [rax+0x80]
00007a3fbe1d909a  movups xmm1, [r13+r14*1]
00007a3fbe1d90a0  vmovaps xmm5, [rsp+0x70]
00007a3fbe1d90a6  vmovaps [rsp+0x70], xmm1
00007a3fbe1d90ac  movaps xmm15, xmm5
00007a3fbe1d90b0  addpd xmm15, xmm3
00007a3fbe1d90b5  vcmppd xmm1, xmm15, xmm15, 0x03
00007a3fbe1d90bb  ptest xmm1, xmm1
00007a3fbe1d90c0  jnz 0x00007A3FBE1DB076
00007a3fbe1d90c6  vmovaps xmm5, [rsp+0x80]
00007a3fbe1d90cf  movaps xmm1, xmm5
00007a3fbe1d90d2  addpd xmm1, xmm4
00007a3fbe1d90d6  vcmppd xmm3, xmm1, xmm1, 0x03
00007a3fbe1d90db  ptest xmm3, xmm3
00007a3fbe1d90e0  jnz 0x00007A3FBE1DB1B8
00007a3fbe1d90e6  vmovaps [rsp+0x80], xmm10
00007a3fbe1d90ef  vmovaps xmm5, [rsp+0x80]
00007a3fbe1d90f8  por xmm10, xmm5
00007a3fbe1d90fd  movaps [r15+0x2F0], xmm10
00007a3fbe1d9105  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d910b  vpermilpd xmm5, xmm5, 0x00
00007a3fbe1d9111  vmovaps xmm3, [rsp+0x70]
00007a3fbe1d9117  vmovaps [rsp+0x50], xmm1
00007a3fbe1d911d  movaps xmm4, xmm3
00007a3fbe1d9120  mulpd xmm4, xmm5
00007a3fbe1d9124  vcmppd xmm1, xmm4, xmm4, 0x03
00007a3fbe1d9129  ptest xmm1, xmm1
00007a3fbe1d912e  jnz 0x00007A3FBE1DB2F8
00007a3fbe1d9134  lea r14, [rax+0xD0]
00007a3fbe1d913b  movups xmm1, [r13+r14*1]
00007a3fbe1d9141  vmovaps xmm3, [rsp+0xD0]
00007a3fbe1d914a  vmovaps [rsp+0x70], xmm1
00007a3fbe1d9150  movaps xmm5, xmm6
00007a3fbe1d9153  addpd xmm5, xmm3
00007a3fbe1d9157  vcmppd xmm1, xmm5, xmm5, 0x03
00007a3fbe1d915c  ptest xmm1, xmm1
00007a3fbe1d9161  jnz 0x00007A3FBE1DB442
00007a3fbe1d9167  vmovaps xmm1, [rsp+0x60]
00007a3fbe1d916d  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1d9173  movaps xmm6, xmm9
00007a3fbe1d9177  mulpd xmm6, xmm1
00007a3fbe1d917b  vcmppd xmm3, xmm6, xmm6, 0x03
00007a3fbe1d9180  ptest xmm3, xmm3
00007a3fbe1d9185  jnz 0x00007A3FBE1DB582
00007a3fbe1d918b  movaps [r15+0x260], xmm6
00007a3fbe1d9193  vxorps xmm1, xmm1, xmm1
00007a3fbe1d9197  vpbroadcastq xmm1, xmm1
00007a3fbe1d919c  movaps [r15+0x1B0], xmm1
00007a3fbe1d91a4  vmovaps xmm1, [rsp+0x60]
00007a3fbe1d91aa  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1d91b0  vmovaps xmm3, [rsp+0x70]
00007a3fbe1d91b6  vmovaps [rsp+0x70], xmm15
00007a3fbe1d91bc  movaps xmm9, xmm3
00007a3fbe1d91c0  mulpd xmm9, xmm1
00007a3fbe1d91c5  vcmppd xmm15, xmm9, xmm9, 0x03
00007a3fbe1d91cb  ptest xmm15, xmm15
00007a3fbe1d91d1  jnz 0x00007A3FBE1DB6C3
00007a3fbe1d91d7  lea r14, [rax+0xC0]
00007a3fbe1d91de  movups xmm1, [r13+r14*1]
00007a3fbe1d91e4  vmovaps xmm3, [rsp+0xC0]
00007a3fbe1d91ed  vmovaps [rsp+0x80], xmm1
00007a3fbe1d91f6  movaps xmm15, xmm3
00007a3fbe1d91fa  addpd xmm15, xmm7
00007a3fbe1d91ff  vcmppd xmm1, xmm15, xmm15, 0x03
00007a3fbe1d9205  ptest xmm1, xmm1
00007a3fbe1d920a  jnz 0x00007A3FBE1DB80F
00007a3fbe1d9210  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d9219  vmovaps xmm1, [rsp+0xC0]
00007a3fbe1d9222  por xmm13, xmm1
00007a3fbe1d9227  movaps [r15+0x270], xmm13
00007a3fbe1d922f  vmovaps xmm1, [rsp+0xB0]
00007a3fbe1d9238  vmovaps xmm7, [rsp+0xB0]
00007a3fbe1d9241  por xmm1, xmm7
00007a3fbe1d9245  movaps [r15+0x1A0], xmm1
00007a3fbe1d924d  vmovaps xmm1, [rsp+0x60]
00007a3fbe1d9253  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1d9259  vmovaps [rsp+0xB0], xmm1
00007a3fbe1d9262  vmovaps xmm1, [rsp+0x80]
00007a3fbe1d926b  vmovaps [rsp+0x80], xmm15
00007a3fbe1d9274  vmovaps xmm15, [rsp+0xB0]
00007a3fbe1d927d  vmovaps [rsp+0xB0], xmm14
00007a3fbe1d9286  movaps xmm3, xmm1
00007a3fbe1d9289  mulpd xmm3, xmm15
00007a3fbe1d928e  vcmppd xmm14, xmm3, xmm3, 0x03
00007a3fbe1d9293  ptest xmm14, xmm14
00007a3fbe1d9299  jnz 0x00007A3FBE1DB951
00007a3fbe1d929f  lea r14, [rax+0x20]
00007a3fbe1d92a3  movups xmm1, [r13+r14*1]
00007a3fbe1d92a9  movaps [r15+0x110], xmm1
00007a3fbe1d92b1  vmovaps xmm14, [rsp+0x70]
00007a3fbe1d92b7  vmovaps [rsp+0x70], xmm1
00007a3fbe1d92bd  movaps xmm15, xmm14
00007a3fbe1d92c1  addpd xmm15, xmm4
00007a3fbe1d92c6  vcmppd xmm1, xmm15, xmm15, 0x03
00007a3fbe1d92cc  ptest xmm1, xmm1
00007a3fbe1d92d1  jnz 0x00007A3FBE1DBA9C
00007a3fbe1d92d7  vmovaps xmm1, [rsp+0x60]
00007a3fbe1d92dd  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1d92e3  movaps xmm14, xmm2
00007a3fbe1d92e7  mulpd xmm14, xmm1
00007a3fbe1d92ec  vcmppd xmm4, xmm14, xmm14, 0x03
00007a3fbe1d92f2  ptest xmm4, xmm4
00007a3fbe1d92f7  jnz 0x00007A3FBE1DBBDF
00007a3fbe1d92fd  vmovaps xmm4, [rsp+0x50]
00007a3fbe1d9303  movaps xmm1, xmm4
00007a3fbe1d9306  addpd xmm1, xmm9
00007a3fbe1d930b  vcmppd xmm2, xmm1, xmm1, 0x03
00007a3fbe1d9310  ptest xmm2, xmm2
00007a3fbe1d9315  jnz 0x00007A3FBE1DBD21
00007a3fbe1d931b  vmovaps xmm9, [rsp+0x30]
00007a3fbe1d9321  vpermilpd xmm9, xmm9, 0x00
00007a3fbe1d9327  vmovaps xmm2, [rsp+0x70]
00007a3fbe1d932d  vmovaps [rsp+0x50], xmm1
00007a3fbe1d9333  movaps xmm4, xmm2
00007a3fbe1d9336  mulpd xmm4, xmm9
00007a3fbe1d933b  vcmppd xmm1, xmm4, xmm4, 0x03
00007a3fbe1d9340  ptest xmm1, xmm1
00007a3fbe1d9345  jnz 0x00007A3FBE1DBE62
00007a3fbe1d934b  vmovaps xmm1, [rsp+0x30]
00007a3fbe1d9351  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1d9357  vmovaps xmm2, [rsp+0x90]
00007a3fbe1d9360  vmovaps [rsp+0x60], xmm15
00007a3fbe1d9366  movaps xmm9, xmm2
00007a3fbe1d936a  mulpd xmm9, xmm1
00007a3fbe1d936f  vcmppd xmm15, xmm9, xmm9, 0x03
00007a3fbe1d9375  ptest xmm15, xmm15
00007a3fbe1d937b  jnz 0x00007A3FBE1DBFA3
00007a3fbe1d9381  vmovaps xmm15, [rsp+0x80]
00007a3fbe1d938a  movaps xmm1, xmm15
00007a3fbe1d938e  addpd xmm1, xmm6
00007a3fbe1d9392  vcmppd xmm2, xmm1, xmm1, 0x03
00007a3fbe1d9397  ptest xmm2, xmm2
00007a3fbe1d939c  jnz 0x00007A3FBE1DC0E5
00007a3fbe1d93a2  movaps xmm15, xmm5
00007a3fbe1d93a6  addpd xmm15, xmm3
00007a3fbe1d93ab  vcmppd xmm6, xmm15, xmm15, 0x03
00007a3fbe1d93b1  ptest xmm6, xmm6
00007a3fbe1d93b6  jnz 0x00007A3FBE1DC226
00007a3fbe1d93bc  vmovaps xmm6, [rsp+0x30]
00007a3fbe1d93c2  vpermilpd xmm6, xmm6, 0x00
00007a3fbe1d93c8  movaps xmm5, xmm8
00007a3fbe1d93cc  mulpd xmm5, xmm6
00007a3fbe1d93d0  vcmppd xmm3, xmm5, xmm5, 0x03
00007a3fbe1d93d5  ptest xmm3, xmm3
00007a3fbe1d93da  jnz 0x00007A3FBE1DC368
00007a3fbe1d93e0  vmovaps xmm8, [rsp+0x30]
00007a3fbe1d93e6  vpermilpd xmm8, xmm8, 0x00
00007a3fbe1d93ec  movaps xmm6, xmm10
00007a3fbe1d93f0  mulpd xmm6, xmm8
00007a3fbe1d93f5  vcmppd xmm3, xmm6, xmm6, 0x03
00007a3fbe1d93fa  ptest xmm3, xmm3
00007a3fbe1d93ff  jnz 0x00007A3FBE1DC4A9
00007a3fbe1d9405  vmovaps xmm8, [rsp+0x60]
00007a3fbe1d940b  movaps xmm10, xmm8
00007a3fbe1d940f  addpd xmm10, xmm14
00007a3fbe1d9414  vcmppd xmm3, xmm10, xmm10, 0x03
00007a3fbe1d941a  ptest xmm3, xmm3
00007a3fbe1d941f  jnz 0x00007A3FBE1DC5EB
00007a3fbe1d9425  vmovaps xmm8, [rsp+0x50]
00007a3fbe1d942b  movaps xmm14, xmm8
00007a3fbe1d942f  addpd xmm14, xmm4
00007a3fbe1d9434  vcmppd xmm3, xmm14, xmm14, 0x03
00007a3fbe1d943a  ptest xmm3, xmm3
00007a3fbe1d943f  jnz 0x00007A3FBE1DC72F
00007a3fbe1d9445  vmovaps xmm8, [rsp+0x40]
00007a3fbe1d944b  vpermilpd xmm8, xmm8, 0x00
00007a3fbe1d9451  movaps xmm4, xmm13
00007a3fbe1d9455  mulpd xmm4, xmm8
00007a3fbe1d945a  vcmppd xmm3, xmm4, xmm4, 0x03
00007a3fbe1d945f  ptest xmm3, xmm3
00007a3fbe1d9464  jnz 0x00007A3FBE1DC872
00007a3fbe1d946a  movaps xmm13, xmm15
00007a3fbe1d946e  addpd xmm13, xmm9
00007a3fbe1d9473  vcmppd xmm8, xmm13, xmm13, 0x03
00007a3fbe1d9479  ptest xmm8, xmm8
00007a3fbe1d947f  jnz 0x00007A3FBE1DC9B4
00007a3fbe1d9485  movaps xmm15, xmm1
00007a3fbe1d9489  addpd xmm15, xmm5
00007a3fbe1d948e  vcmppd xmm9, xmm15, xmm15, 0x03
00007a3fbe1d9494  ptest xmm9, xmm9
00007a3fbe1d949a  jnz 0x00007A3FBE1DCAF8
00007a3fbe1d94a0  vmovaps [rsp+0x30], xmm11
00007a3fbe1d94a6  vmovaps xmm1, [rsp+0x30]
00007a3fbe1d94ac  por xmm11, xmm1
00007a3fbe1d94b1  movaps [r15+0x250], xmm11
00007a3fbe1d94b9  vmovaps [rsp+0x30], xmm12
00007a3fbe1d94bf  vmovaps xmm1, [rsp+0x30]
00007a3fbe1d94c5  por xmm12, xmm1
00007a3fbe1d94ca  movaps [r15+0x2A0], xmm12
00007a3fbe1d94d2  vmovaps xmm1, [rsp+0xA0]
00007a3fbe1d94db  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d94e4  por xmm1, xmm11
00007a3fbe1d94e9  movaps [r15+0x1D0], xmm1
00007a3fbe1d94f1  lea r14, [rax+0x40]
00007a3fbe1d94f5  movups xmm1, [r13+r14*1]
00007a3fbe1d94fb  movaps [r15+0x2C0], xmm1
00007a3fbe1d9503  vmovaps xmm11, [rsp+0x40]
00007a3fbe1d9509  vpermilpd xmm11, xmm11, 0x00
00007a3fbe1d950f  vmovaps xmm8, [rsp+0xE0]
00007a3fbe1d9518  movaps xmm9, xmm8
00007a3fbe1d951c  mulpd xmm9, xmm11
00007a3fbe1d9521  vcmppd xmm5, xmm9, xmm9, 0x03
00007a3fbe1d9527  ptest xmm5, xmm5
00007a3fbe1d952c  jnz 0x00007A3FBE1DCC44
00007a3fbe1d9532  movaps xmm11, xmm10
00007a3fbe1d9536  addpd xmm11, xmm6
00007a3fbe1d953b  vcmppd xmm8, xmm11, xmm11, 0x03
00007a3fbe1d9541  ptest xmm8, xmm8
00007a3fbe1d9547  jnz 0x00007A3FBE1DCD88
00007a3fbe1d954d  movaps xmm10, xmm14
00007a3fbe1d9551  addpd xmm10, xmm4
00007a3fbe1d9556  vcmppd xmm8, xmm10, xmm10, 0x03
00007a3fbe1d955c  ptest xmm8, xmm8
00007a3fbe1d9562  jnz 0x00007A3FBE1DCECB
00007a3fbe1d9568  vmovaps xmm14, [rsp+0x40]
00007a3fbe1d956e  vpermilpd xmm14, xmm14, 0x00
00007a3fbe1d9574  movaps xmm8, xmm1
00007a3fbe1d9578  mulpd xmm8, xmm14
00007a3fbe1d957d  vcmppd xmm6, xmm8, xmm8, 0x03
00007a3fbe1d9583  ptest xmm6, xmm6
00007a3fbe1d9588  jnz 0x00007A3FBE1DD00E
00007a3fbe1d958e  movaps xmm1, [r15+0x2B0]
00007a3fbe1d9596  vmovaps xmm14, [rsp+0x40]
00007a3fbe1d959c  vpermilpd xmm14, xmm14, 0x00
00007a3fbe1d95a2  movaps xmm6, xmm1
00007a3fbe1d95a5  mulpd xmm6, xmm14
00007a3fbe1d95aa  vcmppd xmm5, xmm6, xmm6, 0x03
00007a3fbe1d95af  ptest xmm5, xmm5
00007a3fbe1d95b4  jnz 0x00007A3FBE1DD151
00007a3fbe1d95ba  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d95c0  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1d95c6  movaps xmm14, xmm12
00007a3fbe1d95ca  mulpd xmm14, xmm1
00007a3fbe1d95cf  vcmppd xmm5, xmm14, xmm14, 0x03
00007a3fbe1d95d5  ptest xmm5, xmm5
00007a3fbe1d95da  jnz 0x00007A3FBE1DD292
00007a3fbe1d95e0  movaps xmm1, xmm13
00007a3fbe1d95e4  addpd xmm1, xmm9
00007a3fbe1d95e9  vcmppd xmm12, xmm1, xmm1, 0x03
00007a3fbe1d95ee  ptest xmm12, xmm12
00007a3fbe1d95f4  jnz 0x00007A3FBE1DD3D5
00007a3fbe1d95fa  vmovaps xmm13, [rsp+0x10]
00007a3fbe1d9600  vpermilpd xmm13, xmm13, 0x00
00007a3fbe1d9606  movaps xmm12, xmm7
00007a3fbe1d960a  mulpd xmm12, xmm13
00007a3fbe1d960f  vcmppd xmm9, xmm12, xmm12, 0x03
00007a3fbe1d9615  ptest xmm9, xmm9
00007a3fbe1d961b  jnz 0x00007A3FBE1DD517
00007a3fbe1d9621  movaps xmm13, xmm15
00007a3fbe1d9625  addpd xmm13, xmm8
00007a3fbe1d962a  vcmppd xmm9, xmm13, xmm13, 0x03
00007a3fbe1d9630  ptest xmm9, xmm9
00007a3fbe1d9636  jnz 0x00007A3FBE1DD65A
00007a3fbe1d963c  movaps xmm15, [r15+0x290]
00007a3fbe1d9644  vmovaps xmm9, [rsp+0x10]
00007a3fbe1d964a  vpermilpd xmm9, xmm9, 0x00
00007a3fbe1d9650  movaps xmm8, xmm15
00007a3fbe1d9654  mulpd xmm8, xmm9
00007a3fbe1d9659  vcmppd xmm7, xmm8, xmm8, 0x03
00007a3fbe1d965f  ptest xmm7, xmm7
00007a3fbe1d9664  jnz 0x00007A3FBE1DD79E
00007a3fbe1d966a  movaps xmm15, xmm11
00007a3fbe1d966e  addpd xmm15, xmm6
00007a3fbe1d9673  vcmppd xmm9, xmm15, xmm15, 0x03
00007a3fbe1d9679  ptest xmm9, xmm9
00007a3fbe1d967f  jnz 0x00007A3FBE1DD8E2
00007a3fbe1d9685  movaps xmm11, [r15+0x1E0]
00007a3fbe1d968d  vmovaps xmm9, [rsp+0x10]
00007a3fbe1d9693  vpermilpd xmm9, xmm9, 0x00
00007a3fbe1d9699  movaps xmm7, xmm11
00007a3fbe1d969d  mulpd xmm7, xmm9
00007a3fbe1d96a2  vcmppd xmm6, xmm7, xmm7, 0x03
00007a3fbe1d96a7  ptest xmm6, xmm6
00007a3fbe1d96ac  jnz 0x00007A3FBE1DDA25
00007a3fbe1d96b2  movaps xmm11, xmm10
00007a3fbe1d96b6  addpd xmm11, xmm14
00007a3fbe1d96bb  vcmppd xmm9, xmm11, xmm11, 0x03
00007a3fbe1d96c1  ptest xmm9, xmm9
00007a3fbe1d96c7  jnz 0x00007A3FBE1DDB67
00007a3fbe1d96cd  lea r14, [rax+0x70]
00007a3fbe1d96d1  movups xmm14, [r13+r14*1]
00007a3fbe1d96d7  movaps [r15+0x240], xmm14
00007a3fbe1d96df  movaps xmm10, xmm1
00007a3fbe1d96e3  addpd xmm10, xmm12
00007a3fbe1d96e8  vcmppd xmm9, xmm10, xmm10, 0x03
00007a3fbe1d96ee  ptest xmm9, xmm9
00007a3fbe1d96f4  jnz 0x00007A3FBE1DDCB5
00007a3fbe1d96fa  movaps [r15+0x170], xmm10
00007a3fbe1d9702  vmovaps xmm1, [rsp+0x20]
00007a3fbe1d9708  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1d970e  movaps xmm12, xmm14
00007a3fbe1d9712  mulpd xmm12, xmm1
00007a3fbe1d9717  vcmppd xmm9, xmm12, xmm12, 0x03
00007a3fbe1d971d  ptest xmm9, xmm9
00007a3fbe1d9723  jnz 0x00007A3FBE1DDDF8
00007a3fbe1d9729  vmovaps xmm1, [rsp+0x20]
00007a3fbe1d972f  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1d9735  vmovaps xmm9, [rsp+0xB0]
00007a3fbe1d973e  movaps xmm14, xmm9
00007a3fbe1d9742  mulpd xmm14, xmm1
00007a3fbe1d9747  vcmppd xmm6, xmm14, xmm14, 0x03
00007a3fbe1d974d  ptest xmm6, xmm6
00007a3fbe1d9752  jnz 0x00007A3FBE1DDF3B
00007a3fbe1d9758  movaps [r15+0x180], xmm14
00007a3fbe1d9760  movaps xmm1, xmm13
00007a3fbe1d9764  addpd xmm1, xmm8
00007a3fbe1d9769  vcmppd xmm9, xmm1, xmm1, 0x03
00007a3fbe1d976e  ptest xmm9, xmm9
00007a3fbe1d9774  jnz 0x00007A3FBE1DE07E
00007a3fbe1d977a  movaps [r15+0x210], xmm1
00007a3fbe1d9782  movups xmm13, [r13+rax*1]
00007a3fbe1d9788  lea r14, [rax+0x10]
00007a3fbe1d978c  movups xmm9, [r13+r14*1]
00007a3fbe1d9792  movaps [r15+0x230], xmm9
00007a3fbe1d979a  movaps xmm8, xmm15
00007a3fbe1d979e  addpd xmm8, xmm7
00007a3fbe1d97a3  vcmppd xmm6, xmm8, xmm8, 0x03
00007a3fbe1d97a9  ptest xmm6, xmm6
00007a3fbe1d97ae  jnz 0x00007A3FBE1DE1D4
00007a3fbe1d97b4  movaps [r15+0x130], xmm8
00007a3fbe1d97bc  vmovaps xmm15, [rsp+0x20]
00007a3fbe1d97c2  vpermilpd xmm15, xmm15, 0x00
00007a3fbe1d97c8  movaps xmm7, xmm9
00007a3fbe1d97cc  mulpd xmm7, xmm15
00007a3fbe1d97d1  vcmppd xmm6, xmm7, xmm7, 0x03
00007a3fbe1d97d6  ptest xmm6, xmm6
00007a3fbe1d97db  jnz 0x00007A3FBE1DE317
00007a3fbe1d97e1  movaps [r15+0x220], xmm7
00007a3fbe1d97e9  vmovaps xmm15, [rsp+0x20]
00007a3fbe1d97ef  vpermilpd xmm15, xmm15, 0x00
00007a3fbe1d97f5  movaps xmm9, xmm13
00007a3fbe1d97f9  mulpd xmm9, xmm15
00007a3fbe1d97fe  vcmppd xmm6, xmm9, xmm9, 0x03
00007a3fbe1d9804  ptest xmm6, xmm6
00007a3fbe1d9809  jnz 0x00007A3FBE1DE459
00007a3fbe1d980f  movaps xmm15, xmm11
00007a3fbe1d9813  addpd xmm15, xmm12
00007a3fbe1d9818  vcmppd xmm13, xmm15, xmm15, 0x03
00007a3fbe1d981e  ptest xmm13, xmm13
00007a3fbe1d9824  jnz 0x00007A3FBE1DE59D
00007a3fbe1d982a  movaps [r15+0x140], xmm15
00007a3fbe1d9832  movaps xmm13, xmm10
00007a3fbe1d9836  addpd xmm13, xmm14
00007a3fbe1d983b  vcmppd xmm12, xmm13, xmm13, 0x03
00007a3fbe1d9841  ptest xmm12, xmm12
00007a3fbe1d9847  jnz 0x00007A3FBE1DE6E1
00007a3fbe1d984d  movaps [r15+0x150], xmm13
00007a3fbe1d9855  movaps xmm14, xmm1
00007a3fbe1d9859  addpd xmm14, xmm7
00007a3fbe1d985e  vcmppd xmm12, xmm14, xmm14, 0x03
00007a3fbe1d9864  ptest xmm12, xmm12
00007a3fbe1d986a  jnz 0x00007A3FBE1DE825
00007a3fbe1d9870  movaps [r15+0x160], xmm14
00007a3fbe1d9878  movaps xmm1, xmm8
00007a3fbe1d987c  addpd xmm1, xmm9
00007a3fbe1d9881  vcmppd xmm12, xmm1, xmm1, 0x03
00007a3fbe1d9886  ptest xmm12, xmm12
00007a3fbe1d988c  jnz 0x00007A3FBE1DE967
00007a3fbe1d9892  movaps [r15+0x120], xmm1
00007a3fbe1d989a  movups [r13+r11*1], xmm15
00007a3fbe1d98a0  lea rax, [r11+0x10]
00007a3fbe1d98a4  movups [r13+rax*1], xmm13
00007a3fbe1d98aa  lea rax, [r11+0x20]
00007a3fbe1d98ae  movups [r13+rax*1], xmm14
00007a3fbe1d98b4  lea rax, [r11+0x30]
00007a3fbe1d98b8  movups [r13+rax*1], xmm1
00007a3fbe1d98be  mov eax, [r15+0x108]
00007a3fbe1d98c5  sahf
00007a3fbe1d98c6  jnz 0x00007A3FBE1D98F8
00007a3fbe1d98c8  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d98d0  jz 0x00007A3FBE1DEAE0
00007a3fbe1d98d6  nop [rax+rax*1], ax
00007a3fbe1d98df  nop [rax+rax*1], eax
00007a3fbe1d98e7  mov eax, 0x4106D0
00007a3fbe1d98ec  mov [r15+0x100], rax
00007a3fbe1d98f3  jmp 0x00007A3FBDFFE110
00007a3fbe1d98f8  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1d9900  jz 0x00007A3FBE1D89C0
00007a3fbe1d9906  nop [rax+rax*1], ax
00007a3fbe1d990f  nop [rax+rax*1], eax
00007a3fbe1d9917  mov eax, 0x410504
00007a3fbe1d991c  mov [r15+0x100], rax
00007a3fbe1d9923  jmp 0x00007A3FBDFFE110
00007a3fbe1d9928  int3
00007a3fbe1d9929  call 0x00007A3FBE00A4B0
00007a3fbe1d992e  jmp 0x00007A3FBE1D8A08
00007a3fbe1d9933  call 0x00007A3FBE009240
00007a3fbe1d9938  jmp 0x00007A3FBE1D8A12
00007a3fbe1d993d  call 0x00007A3FBE00A4B0
00007a3fbe1d9942  jmp 0x00007A3FBE1D8A6F
00007a3fbe1d9947  call 0x00007A3FBE009240
00007a3fbe1d994c  jmp 0x00007A3FBE1D8A79
00007a3fbe1d9951  call 0x00007A3FBE00A4B0
00007a3fbe1d9956  jmp 0x00007A3FBE1D8ABD
00007a3fbe1d995b  call 0x00007A3FBE009240
00007a3fbe1d9960  jmp 0x00007A3FBE1D8AC7
00007a3fbe1d9965  call 0x00007A3FBE0B47C0
00007a3fbe1d996a  jmp 0x00007A3FBE1D8B06
00007a3fbe1d996f  call 0x00007A3FBE00B720
00007a3fbe1d9974  jmp 0x00007A3FBE1D8B1A
00007a3fbe1d9979  call 0x00007A3FBE0BFC30
00007a3fbe1d997e  jmp 0x00007A3FBE1D8B38
00007a3fbe1d9983  call 0x00007A3FBE0BE9C0
00007a3fbe1d9988  jmp 0x00007A3FBE1D8B42
00007a3fbe1d998d  call 0x00007A3FBE0BD750
00007a3fbe1d9992  jmp 0x00007A3FBE1D8B4C
00007a3fbe1d9997  sub rsp, 0x08
00007a3fbe1d999b  push rax
00007a3fbe1d999c  push rcx
00007a3fbe1d999d  push rdx
00007a3fbe1d999e  push rdi
00007a3fbe1d999f  push rsi
00007a3fbe1d99a0  push r8
00007a3fbe1d99a2  push r9
00007a3fbe1d99a4  push r10
00007a3fbe1d99a6  push r11
00007a3fbe1d99a8  sub rsp, 0xF0
00007a3fbe1d99af  vmovaps [rsp], xmm0
00007a3fbe1d99b4  vmovaps [rsp+0x10], xmm1
00007a3fbe1d99ba  vmovaps [rsp+0x20], xmm2
00007a3fbe1d99c0  vmovaps [rsp+0x30], xmm3
00007a3fbe1d99c6  vmovaps [rsp+0x40], xmm4
00007a3fbe1d99cc  vmovaps [rsp+0x50], xmm5
00007a3fbe1d99d2  vmovaps [rsp+0x60], xmm6
00007a3fbe1d99d8  vmovaps [rsp+0x70], xmm7
00007a3fbe1d99de  vmovaps [rsp+0x80], xmm9
00007a3fbe1d99e7  vmovaps [rsp+0x90], xmm10
00007a3fbe1d99f0  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d99f9  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d9a02  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d9a0b  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d9a14  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d9a1d  sub rsp, 0x30
00007a3fbe1d9a21  movaps [rsp], xmm8
00007a3fbe1d9a26  movaps [rsp+0x10], xmm12
00007a3fbe1d9a2c  movaps [rsp+0x20], xmm15
00007a3fbe1d9a32  lea rdi, [rsp]
00007a3fbe1d9a36  mov esi, 0x00
00007a3fbe1d9a3b  mov rax, 0x60D1084DB530
00007a3fbe1d9a45  call rax
00007a3fbe1d9a47  movaps xmm8, [rsp]
00007a3fbe1d9a4c  add rsp, 0x30
00007a3fbe1d9a50  vmovaps xmm0, [rsp]
00007a3fbe1d9a55  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d9a5b  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d9a61  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d9a67  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d9a6d  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d9a73  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d9a79  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d9a7f  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d9a88  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d9a91  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d9a9a  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d9aa3  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d9aac  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d9ab5  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d9abe  add rsp, 0xF0
00007a3fbe1d9ac5  pop r11
00007a3fbe1d9ac7  pop r10
00007a3fbe1d9ac9  pop r9
00007a3fbe1d9acb  pop r8
00007a3fbe1d9acd  pop rsi
00007a3fbe1d9ace  pop rdi
00007a3fbe1d9acf  pop rdx
00007a3fbe1d9ad0  pop rcx
00007a3fbe1d9ad1  pop rax
00007a3fbe1d9ad2  add rsp, 0x08
00007a3fbe1d9ad6  jmp 0x00007A3FBE1D8B7A
00007a3fbe1d9adb  sub rsp, 0x08
00007a3fbe1d9adf  push rax
00007a3fbe1d9ae0  push rcx
00007a3fbe1d9ae1  push rdx
00007a3fbe1d9ae2  push rdi
00007a3fbe1d9ae3  push rsi
00007a3fbe1d9ae4  push r8
00007a3fbe1d9ae6  push r9
00007a3fbe1d9ae8  push r10
00007a3fbe1d9aea  push r11
00007a3fbe1d9aec  sub rsp, 0xF0
00007a3fbe1d9af3  vmovaps [rsp], xmm0
00007a3fbe1d9af8  vmovaps [rsp+0x10], xmm1
00007a3fbe1d9afe  vmovaps [rsp+0x20], xmm2
00007a3fbe1d9b04  vmovaps [rsp+0x30], xmm3
00007a3fbe1d9b0a  vmovaps [rsp+0x40], xmm4
00007a3fbe1d9b10  vmovaps [rsp+0x50], xmm5
00007a3fbe1d9b16  vmovaps [rsp+0x60], xmm6
00007a3fbe1d9b1c  vmovaps [rsp+0x70], xmm8
00007a3fbe1d9b22  vmovaps [rsp+0x80], xmm9
00007a3fbe1d9b2b  vmovaps [rsp+0x90], xmm10
00007a3fbe1d9b34  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d9b3d  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d9b46  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d9b4f  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d9b58  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d9b61  sub rsp, 0x30
00007a3fbe1d9b65  movaps [rsp], xmm7
00007a3fbe1d9b69  movaps [rsp+0x10], xmm9
00007a3fbe1d9b6f  movaps [rsp+0x20], xmm15
00007a3fbe1d9b75  lea rdi, [rsp]
00007a3fbe1d9b79  mov esi, 0x00
00007a3fbe1d9b7e  mov rax, 0x60D1084DB530
00007a3fbe1d9b88  call rax
00007a3fbe1d9b8a  movaps xmm7, [rsp]
00007a3fbe1d9b8e  add rsp, 0x30
00007a3fbe1d9b92  vmovaps xmm0, [rsp]
00007a3fbe1d9b97  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d9b9d  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d9ba3  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d9ba9  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d9baf  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d9bb5  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d9bbb  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d9bc1  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d9bca  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d9bd3  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d9bdc  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d9be5  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d9bee  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d9bf7  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d9c00  add rsp, 0xF0
00007a3fbe1d9c07  pop r11
00007a3fbe1d9c09  pop r10
00007a3fbe1d9c0b  pop r9
00007a3fbe1d9c0d  pop r8
00007a3fbe1d9c0f  pop rsi
00007a3fbe1d9c10  pop rdi
00007a3fbe1d9c11  pop rdx
00007a3fbe1d9c12  pop rcx
00007a3fbe1d9c13  pop rax
00007a3fbe1d9c14  add rsp, 0x08
00007a3fbe1d9c18  jmp 0x00007A3FBE1D8BA8
00007a3fbe1d9c1d  sub rsp, 0x08
00007a3fbe1d9c21  push rax
00007a3fbe1d9c22  push rcx
00007a3fbe1d9c23  push rdx
00007a3fbe1d9c24  push rdi
00007a3fbe1d9c25  push rsi
00007a3fbe1d9c26  push r8
00007a3fbe1d9c28  push r9
00007a3fbe1d9c2a  push r10
00007a3fbe1d9c2c  push r11
00007a3fbe1d9c2e  sub rsp, 0xF0
00007a3fbe1d9c35  vmovaps [rsp], xmm0
00007a3fbe1d9c3a  vmovaps [rsp+0x10], xmm1
00007a3fbe1d9c40  vmovaps [rsp+0x20], xmm2
00007a3fbe1d9c46  vmovaps [rsp+0x30], xmm3
00007a3fbe1d9c4c  vmovaps [rsp+0x40], xmm4
00007a3fbe1d9c52  vmovaps [rsp+0x50], xmm5
00007a3fbe1d9c58  vmovaps [rsp+0x60], xmm6
00007a3fbe1d9c5e  vmovaps [rsp+0x70], xmm7
00007a3fbe1d9c64  vmovaps [rsp+0x80], xmm8
00007a3fbe1d9c6d  vmovaps [rsp+0x90], xmm10
00007a3fbe1d9c76  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d9c7f  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d9c88  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d9c91  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d9c9a  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d9ca3  sub rsp, 0x30
00007a3fbe1d9ca7  movaps [rsp], xmm9
00007a3fbe1d9cac  movaps [rsp+0x10], xmm12
00007a3fbe1d9cb2  movaps [rsp+0x20], xmm10
00007a3fbe1d9cb8  lea rdi, [rsp]
00007a3fbe1d9cbc  mov esi, 0x00
00007a3fbe1d9cc1  mov rax, 0x60D1084DB530
00007a3fbe1d9ccb  call rax
00007a3fbe1d9ccd  movaps xmm9, [rsp]
00007a3fbe1d9cd2  add rsp, 0x30
00007a3fbe1d9cd6  vmovaps xmm0, [rsp]
00007a3fbe1d9cdb  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d9ce1  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d9ce7  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d9ced  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d9cf3  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d9cf9  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d9cff  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d9d05  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d9d0e  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d9d17  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d9d20  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d9d29  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d9d32  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d9d3b  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d9d44  add rsp, 0xF0
00007a3fbe1d9d4b  pop r11
00007a3fbe1d9d4d  pop r10
00007a3fbe1d9d4f  pop r9
00007a3fbe1d9d51  pop r8
00007a3fbe1d9d53  pop rsi
00007a3fbe1d9d54  pop rdi
00007a3fbe1d9d55  pop rdx
00007a3fbe1d9d56  pop rcx
00007a3fbe1d9d57  pop rax
00007a3fbe1d9d58  add rsp, 0x08
00007a3fbe1d9d5c  jmp 0x00007A3FBE1D8BCC
00007a3fbe1d9d61  sub rsp, 0x08
00007a3fbe1d9d65  push rax
00007a3fbe1d9d66  push rcx
00007a3fbe1d9d67  push rdx
00007a3fbe1d9d68  push rdi
00007a3fbe1d9d69  push rsi
00007a3fbe1d9d6a  push r8
00007a3fbe1d9d6c  push r9
00007a3fbe1d9d6e  push r10
00007a3fbe1d9d70  push r11
00007a3fbe1d9d72  sub rsp, 0xF0
00007a3fbe1d9d79  vmovaps [rsp], xmm0
00007a3fbe1d9d7e  vmovaps [rsp+0x10], xmm1
00007a3fbe1d9d84  vmovaps [rsp+0x20], xmm2
00007a3fbe1d9d8a  vmovaps [rsp+0x30], xmm3
00007a3fbe1d9d90  vmovaps [rsp+0x40], xmm4
00007a3fbe1d9d96  vmovaps [rsp+0x50], xmm5
00007a3fbe1d9d9c  vmovaps [rsp+0x60], xmm6
00007a3fbe1d9da2  vmovaps [rsp+0x70], xmm7
00007a3fbe1d9da8  vmovaps [rsp+0x80], xmm8
00007a3fbe1d9db1  vmovaps [rsp+0x90], xmm9
00007a3fbe1d9dba  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d9dc3  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d9dcc  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d9dd5  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d9dde  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d9de7  sub rsp, 0x30
00007a3fbe1d9deb  movaps [rsp], xmm10
00007a3fbe1d9df0  movaps [rsp+0x10], xmm12
00007a3fbe1d9df6  movaps [rsp+0x20], xmm11
00007a3fbe1d9dfc  lea rdi, [rsp]
00007a3fbe1d9e00  mov esi, 0x00
00007a3fbe1d9e05  mov rax, 0x60D1084DB530
00007a3fbe1d9e0f  call rax
00007a3fbe1d9e11  movaps xmm10, [rsp]
00007a3fbe1d9e16  add rsp, 0x30
00007a3fbe1d9e1a  vmovaps xmm0, [rsp]
00007a3fbe1d9e1f  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d9e25  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d9e2b  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d9e31  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d9e37  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d9e3d  vmovaps xmm6, [rsp+0x60]
00007a3fbe1d9e43  vmovaps xmm7, [rsp+0x70]
00007a3fbe1d9e49  vmovaps xmm8, [rsp+0x80]
00007a3fbe1d9e52  vmovaps xmm9, [rsp+0x90]
00007a3fbe1d9e5b  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d9e64  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d9e6d  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d9e76  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d9e7f  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d9e88  add rsp, 0xF0
00007a3fbe1d9e8f  pop r11
00007a3fbe1d9e91  pop r10
00007a3fbe1d9e93  pop r9
00007a3fbe1d9e95  pop r8
00007a3fbe1d9e97  pop rsi
00007a3fbe1d9e98  pop rdi
00007a3fbe1d9e99  pop rdx
00007a3fbe1d9e9a  pop rcx
00007a3fbe1d9e9b  pop rax
00007a3fbe1d9e9c  add rsp, 0x08
00007a3fbe1d9ea0  jmp 0x00007A3FBE1D8BE6
00007a3fbe1d9ea5  sub rsp, 0x08
00007a3fbe1d9ea9  push rax
00007a3fbe1d9eaa  push rcx
00007a3fbe1d9eab  push rdx
00007a3fbe1d9eac  push rdi
00007a3fbe1d9ead  push rsi
00007a3fbe1d9eae  push r8
00007a3fbe1d9eb0  push r9
00007a3fbe1d9eb2  push r10
00007a3fbe1d9eb4  push r11
00007a3fbe1d9eb6  sub rsp, 0xF0
00007a3fbe1d9ebd  vmovaps [rsp], xmm0
00007a3fbe1d9ec2  vmovaps [rsp+0x10], xmm1
00007a3fbe1d9ec8  vmovaps [rsp+0x20], xmm2
00007a3fbe1d9ece  vmovaps [rsp+0x30], xmm3
00007a3fbe1d9ed4  vmovaps [rsp+0x40], xmm4
00007a3fbe1d9eda  vmovaps [rsp+0x50], xmm5
00007a3fbe1d9ee0  vmovaps [rsp+0x60], xmm7
00007a3fbe1d9ee6  vmovaps [rsp+0x70], xmm8
00007a3fbe1d9eec  vmovaps [rsp+0x80], xmm9
00007a3fbe1d9ef5  vmovaps [rsp+0x90], xmm10
00007a3fbe1d9efe  vmovaps [rsp+0xA0], xmm11
00007a3fbe1d9f07  vmovaps [rsp+0xB0], xmm12
00007a3fbe1d9f10  vmovaps [rsp+0xC0], xmm13
00007a3fbe1d9f19  vmovaps [rsp+0xD0], xmm14
00007a3fbe1d9f22  vmovaps [rsp+0xE0], xmm15
00007a3fbe1d9f2b  sub rsp, 0x30
00007a3fbe1d9f2f  movaps [rsp], xmm6
00007a3fbe1d9f33  movaps [rsp+0x10], xmm12
00007a3fbe1d9f39  movaps [rsp+0x20], xmm11
00007a3fbe1d9f3f  lea rdi, [rsp]
00007a3fbe1d9f43  mov esi, 0x00
00007a3fbe1d9f48  mov rax, 0x60D1084DB530
00007a3fbe1d9f52  call rax
00007a3fbe1d9f54  movaps xmm6, [rsp]
00007a3fbe1d9f58  add rsp, 0x30
00007a3fbe1d9f5c  vmovaps xmm0, [rsp]
00007a3fbe1d9f61  vmovaps xmm1, [rsp+0x10]
00007a3fbe1d9f67  vmovaps xmm2, [rsp+0x20]
00007a3fbe1d9f6d  vmovaps xmm3, [rsp+0x30]
00007a3fbe1d9f73  vmovaps xmm4, [rsp+0x40]
00007a3fbe1d9f79  vmovaps xmm5, [rsp+0x50]
00007a3fbe1d9f7f  vmovaps xmm7, [rsp+0x60]
00007a3fbe1d9f85  vmovaps xmm8, [rsp+0x70]
00007a3fbe1d9f8b  vmovaps xmm9, [rsp+0x80]
00007a3fbe1d9f94  vmovaps xmm10, [rsp+0x90]
00007a3fbe1d9f9d  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1d9fa6  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1d9faf  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1d9fb8  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1d9fc1  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1d9fca  add rsp, 0xF0
00007a3fbe1d9fd1  pop r11
00007a3fbe1d9fd3  pop r10
00007a3fbe1d9fd5  pop r9
00007a3fbe1d9fd7  pop r8
00007a3fbe1d9fd9  pop rsi
00007a3fbe1d9fda  pop rdi
00007a3fbe1d9fdb  pop rdx
00007a3fbe1d9fdc  pop rcx
00007a3fbe1d9fdd  pop rax
00007a3fbe1d9fde  add rsp, 0x08
00007a3fbe1d9fe2  jmp 0x00007A3FBE1D8C07
00007a3fbe1d9fe7  sub rsp, 0x08
00007a3fbe1d9feb  push rax
00007a3fbe1d9fec  push rcx
00007a3fbe1d9fed  push rdx
00007a3fbe1d9fee  push rdi
00007a3fbe1d9fef  push rsi
00007a3fbe1d9ff0  push r8
00007a3fbe1d9ff2  push r9
00007a3fbe1d9ff4  push r10
00007a3fbe1d9ff6  push r11
00007a3fbe1d9ff8  sub rsp, 0xF0
00007a3fbe1d9fff  vmovaps [rsp], xmm0
00007a3fbe1da004  vmovaps [rsp+0x10], xmm1
00007a3fbe1da00a  vmovaps [rsp+0x20], xmm2
00007a3fbe1da010  vmovaps [rsp+0x30], xmm4
00007a3fbe1da016  vmovaps [rsp+0x40], xmm5
00007a3fbe1da01c  vmovaps [rsp+0x50], xmm6
00007a3fbe1da022  vmovaps [rsp+0x60], xmm7
00007a3fbe1da028  vmovaps [rsp+0x70], xmm8
00007a3fbe1da02e  vmovaps [rsp+0x80], xmm9
00007a3fbe1da037  vmovaps [rsp+0x90], xmm10
00007a3fbe1da040  vmovaps [rsp+0xA0], xmm11
00007a3fbe1da049  vmovaps [rsp+0xB0], xmm12
00007a3fbe1da052  vmovaps [rsp+0xC0], xmm13
00007a3fbe1da05b  vmovaps [rsp+0xD0], xmm14
00007a3fbe1da064  vmovaps [rsp+0xE0], xmm15
00007a3fbe1da06d  sub rsp, 0x30
00007a3fbe1da071  movaps [rsp], xmm3
00007a3fbe1da075  movaps [rsp+0x10], xmm5
00007a3fbe1da07a  movaps [rsp+0x20], xmm4
00007a3fbe1da07f  lea rdi, [rsp]
00007a3fbe1da083  mov esi, 0x00
00007a3fbe1da088  mov rax, 0x60D1084DB530
00007a3fbe1da092  call rax
00007a3fbe1da094  movaps xmm3, [rsp]
00007a3fbe1da098  add rsp, 0x30
00007a3fbe1da09c  vmovaps xmm0, [rsp]
00007a3fbe1da0a1  vmovaps xmm1, [rsp+0x10]
00007a3fbe1da0a7  vmovaps xmm2, [rsp+0x20]
00007a3fbe1da0ad  vmovaps xmm4, [rsp+0x30]
00007a3fbe1da0b3  vmovaps xmm5, [rsp+0x40]
00007a3fbe1da0b9  vmovaps xmm6, [rsp+0x50]
00007a3fbe1da0bf  vmovaps xmm7, [rsp+0x60]
00007a3fbe1da0c5  vmovaps xmm8, [rsp+0x70]
00007a3fbe1da0cb  vmovaps xmm9, [rsp+0x80]
00007a3fbe1da0d4  vmovaps xmm10, [rsp+0x90]
00007a3fbe1da0dd  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1da0e6  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1da0ef  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1da0f8  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1da101  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1da10a  add rsp, 0xF0
00007a3fbe1da111  pop r11
00007a3fbe1da113  pop r10
00007a3fbe1da115  pop r9
00007a3fbe1da117  pop r8
00007a3fbe1da119  pop rsi
00007a3fbe1da11a  pop rdi
00007a3fbe1da11b  pop rdx
00007a3fbe1da11c  pop rcx
00007a3fbe1da11d  pop rax
00007a3fbe1da11e  add rsp, 0x08
00007a3fbe1da122  jmp 0x00007A3FBE1D8C68
00007a3fbe1da127  sub rsp, 0x08
00007a3fbe1da12b  push rax
00007a3fbe1da12c  push rcx
00007a3fbe1da12d  push rdx
00007a3fbe1da12e  push rdi
00007a3fbe1da12f  push rsi
00007a3fbe1da130  push r8
00007a3fbe1da132  push r9
00007a3fbe1da134  push r10
00007a3fbe1da136  push r11
00007a3fbe1da138  sub rsp, 0xF0
00007a3fbe1da13f  vmovaps [rsp], xmm0
00007a3fbe1da144  vmovaps [rsp+0x10], xmm1
00007a3fbe1da14a  vmovaps [rsp+0x20], xmm2
00007a3fbe1da150  vmovaps [rsp+0x30], xmm3
00007a3fbe1da156  vmovaps [rsp+0x40], xmm4
00007a3fbe1da15c  vmovaps [rsp+0x50], xmm6
00007a3fbe1da162  vmovaps [rsp+0x60], xmm7
00007a3fbe1da168  vmovaps [rsp+0x70], xmm8
00007a3fbe1da16e  vmovaps [rsp+0x80], xmm9
00007a3fbe1da177  vmovaps [rsp+0x90], xmm10
00007a3fbe1da180  vmovaps [rsp+0xA0], xmm11
00007a3fbe1da189  vmovaps [rsp+0xB0], xmm12
00007a3fbe1da192  vmovaps [rsp+0xC0], xmm13
00007a3fbe1da19b  vmovaps [rsp+0xD0], xmm14
00007a3fbe1da1a4  vmovaps [rsp+0xE0], xmm15
00007a3fbe1da1ad  sub rsp, 0x30
00007a3fbe1da1b1  movaps [rsp], xmm5
00007a3fbe1da1b5  movaps [rsp+0x10], xmm8
00007a3fbe1da1bb  movaps [rsp+0x20], xmm15
00007a3fbe1da1c1  lea rdi, [rsp]
00007a3fbe1da1c5  mov esi, 0x00
00007a3fbe1da1ca  mov rax, 0x60D1084DB530
00007a3fbe1da1d4  call rax
00007a3fbe1da1d6  movaps xmm5, [rsp]
00007a3fbe1da1da  add rsp, 0x30
00007a3fbe1da1de  vmovaps xmm0, [rsp]
00007a3fbe1da1e3  vmovaps xmm1, [rsp+0x10]
00007a3fbe1da1e9  vmovaps xmm2, [rsp+0x20]
00007a3fbe1da1ef  vmovaps xmm3, [rsp+0x30]
00007a3fbe1da1f5  vmovaps xmm4, [rsp+0x40]
00007a3fbe1da1fb  vmovaps xmm6, [rsp+0x50]
00007a3fbe1da201  vmovaps xmm7, [rsp+0x60]
00007a3fbe1da207  vmovaps xmm8, [rsp+0x70]
00007a3fbe1da20d  vmovaps xmm9, [rsp+0x80]
00007a3fbe1da216  vmovaps xmm10, [rsp+0x90]
00007a3fbe1da21f  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1da228  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1da231  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1da23a  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1da243  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1da24c  add rsp, 0xF0
00007a3fbe1da253  pop r11
00007a3fbe1da255  pop r10
00007a3fbe1da257  pop r9
00007a3fbe1da259  pop r8
00007a3fbe1da25b  pop rsi
00007a3fbe1da25c  pop rdi
00007a3fbe1da25d  pop rdx
00007a3fbe1da25e  pop rcx
00007a3fbe1da25f  pop rax
00007a3fbe1da260  add rsp, 0x08
00007a3fbe1da264  jmp 0x00007A3FBE1D8CA0
00007a3fbe1da269  sub rsp, 0x08
00007a3fbe1da26d  push rax
00007a3fbe1da26e  push rcx
00007a3fbe1da26f  push rdx
00007a3fbe1da270  push rdi
00007a3fbe1da271  push rsi
00007a3fbe1da272  push r8
00007a3fbe1da274  push r9
00007a3fbe1da276  push r10
00007a3fbe1da278  push r11
00007a3fbe1da27a  sub rsp, 0xF0
00007a3fbe1da281  vmovaps [rsp], xmm0
00007a3fbe1da286  vmovaps [rsp+0x10], xmm1
00007a3fbe1da28c  vmovaps [rsp+0x20], xmm2
00007a3fbe1da292  vmovaps [rsp+0x30], xmm3
00007a3fbe1da298  vmovaps [rsp+0x40], xmm5
00007a3fbe1da29e  vmovaps [rsp+0x50], xmm6
00007a3fbe1da2a4  vmovaps [rsp+0x60], xmm7
00007a3fbe1da2aa  vmovaps [rsp+0x70], xmm8
00007a3fbe1da2b0  vmovaps [rsp+0x80], xmm9
00007a3fbe1da2b9  vmovaps [rsp+0x90], xmm10
00007a3fbe1da2c2  vmovaps [rsp+0xA0], xmm11
00007a3fbe1da2cb  vmovaps [rsp+0xB0], xmm12
00007a3fbe1da2d4  vmovaps [rsp+0xC0], xmm13
00007a3fbe1da2dd  vmovaps [rsp+0xD0], xmm14
00007a3fbe1da2e6  vmovaps [rsp+0xE0], xmm15
00007a3fbe1da2ef  sub rsp, 0x30
00007a3fbe1da2f3  movaps [rsp], xmm4
00007a3fbe1da2f7  movaps [rsp+0x10], xmm9
00007a3fbe1da2fd  movaps [rsp+0x20], xmm8
00007a3fbe1da303  lea rdi, [rsp]
00007a3fbe1da307  mov esi, 0x00
00007a3fbe1da30c  mov rax, 0x60D1084DB530
00007a3fbe1da316  call rax
00007a3fbe1da318  movaps xmm4, [rsp]
00007a3fbe1da31c  add rsp, 0x30
00007a3fbe1da320  vmovaps xmm0, [rsp]
00007a3fbe1da325  vmovaps xmm1, [rsp+0x10]
00007a3fbe1da32b  vmovaps xmm2, [rsp+0x20]
00007a3fbe1da331  vmovaps xmm3, [rsp+0x30]
00007a3fbe1da337  vmovaps xmm5, [rsp+0x40]
00007a3fbe1da33d  vmovaps xmm6, [rsp+0x50]
00007a3fbe1da343  vmovaps xmm7, [rsp+0x60]
00007a3fbe1da349  vmovaps xmm8, [rsp+0x70]
00007a3fbe1da34f  vmovaps xmm9, [rsp+0x80]
00007a3fbe1da358  vmovaps xmm10, [rsp+0x90]
00007a3fbe1da361  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1da36a  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1da373  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1da37c  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1da385  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1da38e  add rsp, 0xF0
00007a3fbe1da395  pop r11
00007a3fbe1da397  pop r10
00007a3fbe1da399  pop r9
00007a3fbe1da39b  pop r8
00007a3fbe1da39d  pop rsi
00007a3fbe1da39e  pop rdi
00007a3fbe1da39f  pop rdx
00007a3fbe1da3a0  pop rcx
00007a3fbe1da3a1  pop rax
00007a3fbe1da3a2  add rsp, 0x08
00007a3fbe1da3a6  jmp 0x00007A3FBE1D8CC1
00007a3fbe1da3ab  sub rsp, 0x08
00007a3fbe1da3af  push rax
00007a3fbe1da3b0  push rcx
00007a3fbe1da3b1  push rdx
00007a3fbe1da3b2  push rdi
00007a3fbe1da3b3  push rsi
00007a3fbe1da3b4  push r8
00007a3fbe1da3b6  push r9
00007a3fbe1da3b8  push r10
00007a3fbe1da3ba  push r11
00007a3fbe1da3bc  sub rsp, 0xF0
00007a3fbe1da3c3  vmovaps [rsp], xmm0
00007a3fbe1da3c8  vmovaps [rsp+0x10], xmm1
00007a3fbe1da3ce  vmovaps [rsp+0x20], xmm2
00007a3fbe1da3d4  vmovaps [rsp+0x30], xmm3
00007a3fbe1da3da  vmovaps [rsp+0x40], xmm4
00007a3fbe1da3e0  vmovaps [rsp+0x50], xmm5
00007a3fbe1da3e6  vmovaps [rsp+0x60], xmm6
00007a3fbe1da3ec  vmovaps [rsp+0x70], xmm7
00007a3fbe1da3f2  vmovaps [rsp+0x80], xmm8
00007a3fbe1da3fb  vmovaps [rsp+0x90], xmm10
00007a3fbe1da404  vmovaps [rsp+0xA0], xmm11
00007a3fbe1da40d  vmovaps [rsp+0xB0], xmm12
00007a3fbe1da416  vmovaps [rsp+0xC0], xmm13
00007a3fbe1da41f  vmovaps [rsp+0xD0], xmm14
00007a3fbe1da428  vmovaps [rsp+0xE0], xmm15
00007a3fbe1da431  sub rsp, 0x30
00007a3fbe1da435  movaps [rsp], xmm9
00007a3fbe1da43a  movaps [rsp+0x10], xmm10
00007a3fbe1da440  movaps [rsp+0x20], xmm8
00007a3fbe1da446  lea rdi, [rsp]
00007a3fbe1da44a  mov esi, 0x00
00007a3fbe1da44f  mov rax, 0x60D1084DB530
00007a3fbe1da459  call rax
00007a3fbe1da45b  movaps xmm9, [rsp]
00007a3fbe1da460  add rsp, 0x30
00007a3fbe1da464  vmovaps xmm0, [rsp]
00007a3fbe1da469  vmovaps xmm1, [rsp+0x10]
00007a3fbe1da46f  vmovaps xmm2, [rsp+0x20]
00007a3fbe1da475  vmovaps xmm3, [rsp+0x30]
00007a3fbe1da47b  vmovaps xmm4, [rsp+0x40]
00007a3fbe1da481  vmovaps xmm5, [rsp+0x50]
00007a3fbe1da487  vmovaps xmm6, [rsp+0x60]
00007a3fbe1da48d  vmovaps xmm7, [rsp+0x70]
00007a3fbe1da493  vmovaps xmm8, [rsp+0x80]
00007a3fbe1da49c  vmovaps xmm10, [rsp+0x90]
00007a3fbe1da4a5  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1da4ae  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1da4b7  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1da4c0  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1da4c9  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1da4d2  add rsp, 0xF0
00007a3fbe1da4d9  pop r11
00007a3fbe1da4db  pop r10
00007a3fbe1da4dd  pop r9
00007a3fbe1da4df  pop r8
00007a3fbe1da4e1  pop rsi
00007a3fbe1da4e2  pop rdi
00007a3fbe1da4e3  pop rdx
00007a3fbe1da4e4  pop rcx
00007a3fbe1da4e5  pop rax
00007a3fbe1da4e6  add rsp, 0x08
00007a3fbe1da4ea  jmp 0x00007A3FBE1D8CDB
00007a3fbe1da4ef  call 0x00007A3FBE0D64F0
00007a3fbe1da4f4  jmp 0x00007A3FBE1D8DF5
00007a3fbe1da4f9  call 0x00007A3FBE0D64F0
00007a3fbe1da4fe  jmp 0x00007A3FBE1D8E0B
00007a3fbe1da503  sub rsp, 0x08
00007a3fbe1da507  push rax
00007a3fbe1da508  push rcx
00007a3fbe1da509  push rdx
00007a3fbe1da50a  push rdi
00007a3fbe1da50b  push rsi
00007a3fbe1da50c  push r8
00007a3fbe1da50e  push r9
00007a3fbe1da510  push r10
00007a3fbe1da512  push r11
00007a3fbe1da514  sub rsp, 0xF0
00007a3fbe1da51b  vmovaps [rsp], xmm0
00007a3fbe1da520  vmovaps [rsp+0x10], xmm2
00007a3fbe1da526  vmovaps [rsp+0x20], xmm3
00007a3fbe1da52c  vmovaps [rsp+0x30], xmm4
00007a3fbe1da532  vmovaps [rsp+0x40], xmm5
00007a3fbe1da538  vmovaps [rsp+0x50], xmm6
00007a3fbe1da53e  vmovaps [rsp+0x60], xmm7
00007a3fbe1da544  vmovaps [rsp+0x70], xmm8
00007a3fbe1da54a  vmovaps [rsp+0x80], xmm9
00007a3fbe1da553  vmovaps [rsp+0x90], xmm10
00007a3fbe1da55c  vmovaps [rsp+0xA0], xmm11
00007a3fbe1da565  vmovaps [rsp+0xB0], xmm12
00007a3fbe1da56e  vmovaps [rsp+0xC0], xmm13
00007a3fbe1da577  vmovaps [rsp+0xD0], xmm14
00007a3fbe1da580  vmovaps [rsp+0xE0], xmm15
00007a3fbe1da589  sub rsp, 0x30
00007a3fbe1da58d  movaps [rsp], xmm1
00007a3fbe1da591  movaps [rsp+0x10], xmm6
00007a3fbe1da596  movaps [rsp+0x20], xmm15
00007a3fbe1da59c  lea rdi, [rsp]
00007a3fbe1da5a0  mov esi, 0x00
00007a3fbe1da5a5  mov rax, 0x60D1084DB530
00007a3fbe1da5af  call rax
00007a3fbe1da5b1  movaps xmm1, [rsp]
00007a3fbe1da5b5  add rsp, 0x30
00007a3fbe1da5b9  vmovaps xmm0, [rsp]
00007a3fbe1da5be  vmovaps xmm2, [rsp+0x10]
00007a3fbe1da5c4  vmovaps xmm3, [rsp+0x20]
00007a3fbe1da5ca  vmovaps xmm4, [rsp+0x30]
00007a3fbe1da5d0  vmovaps xmm5, [rsp+0x40]
00007a3fbe1da5d6  vmovaps xmm6, [rsp+0x50]
00007a3fbe1da5dc  vmovaps xmm7, [rsp+0x60]
00007a3fbe1da5e2  vmovaps xmm8, [rsp+0x70]
00007a3fbe1da5e8  vmovaps xmm9, [rsp+0x80]
00007a3fbe1da5f1  vmovaps xmm10, [rsp+0x90]
00007a3fbe1da5fa  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1da603  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1da60c  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1da615  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1da61e  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1da627  add rsp, 0xF0
00007a3fbe1da62e  pop r11
00007a3fbe1da630  pop r10
00007a3fbe1da632  pop r9
00007a3fbe1da634  pop r8
00007a3fbe1da636  pop rsi
00007a3fbe1da637  pop rdi
00007a3fbe1da638  pop rdx
00007a3fbe1da639  pop rcx
00007a3fbe1da63a  pop rax
00007a3fbe1da63b  add rsp, 0x08
00007a3fbe1da63f  jmp 0x00007A3FBE1D8E48
00007a3fbe1da644  call 0x00007A3FBE0E5820
00007a3fbe1da649  jmp 0x00007A3FBE1D8E55
00007a3fbe1da64e  sub rsp, 0x08
00007a3fbe1da652  push rax
00007a3fbe1da653  push rcx
00007a3fbe1da654  push rdx
00007a3fbe1da655  push rdi
00007a3fbe1da656  push rsi
00007a3fbe1da657  push r8
00007a3fbe1da659  push r9
00007a3fbe1da65b  push r10
00007a3fbe1da65d  push r11
00007a3fbe1da65f  sub rsp, 0xF0
00007a3fbe1da666  vmovaps [rsp], xmm0
00007a3fbe1da66b  vmovaps [rsp+0x10], xmm1
00007a3fbe1da671  vmovaps [rsp+0x20], xmm2
00007a3fbe1da677  vmovaps [rsp+0x30], xmm3
00007a3fbe1da67d  vmovaps [rsp+0x40], xmm4
00007a3fbe1da683  vmovaps [rsp+0x50], xmm5
00007a3fbe1da689  vmovaps [rsp+0x60], xmm6
00007a3fbe1da68f  vmovaps [rsp+0x70], xmm7
00007a3fbe1da695  vmovaps [rsp+0x80], xmm8
00007a3fbe1da69e  vmovaps [rsp+0x90], xmm9
00007a3fbe1da6a7  vmovaps [rsp+0xA0], xmm10
00007a3fbe1da6b0  vmovaps [rsp+0xB0], xmm11
00007a3fbe1da6b9  vmovaps [rsp+0xC0], xmm12
00007a3fbe1da6c2  vmovaps [rsp+0xD0], xmm13
00007a3fbe1da6cb  vmovaps [rsp+0xE0], xmm15
00007a3fbe1da6d4  sub rsp, 0x30
00007a3fbe1da6d8  movaps [rsp], xmm14
00007a3fbe1da6dd  movaps [rsp+0x10], xmm4
00007a3fbe1da6e2  movaps [rsp+0x20], xmm3
00007a3fbe1da6e7  lea rdi, [rsp]
00007a3fbe1da6eb  mov esi, 0x00
00007a3fbe1da6f0  mov rax, 0x60D1084DB530
00007a3fbe1da6fa  call rax
00007a3fbe1da6fc  movaps xmm14, [rsp]
00007a3fbe1da701  add rsp, 0x30
00007a3fbe1da705  vmovaps xmm0, [rsp]
00007a3fbe1da70a  vmovaps xmm1, [rsp+0x10]
00007a3fbe1da710  vmovaps xmm2, [rsp+0x20]
00007a3fbe1da716  vmovaps xmm3, [rsp+0x30]
00007a3fbe1da71c  vmovaps xmm4, [rsp+0x40]
00007a3fbe1da722  vmovaps xmm5, [rsp+0x50]
00007a3fbe1da728  vmovaps xmm6, [rsp+0x60]
00007a3fbe1da72e  vmovaps xmm7, [rsp+0x70]
00007a3fbe1da734  vmovaps xmm8, [rsp+0x80]
00007a3fbe1da73d  vmovaps xmm9, [rsp+0x90]
00007a3fbe1da746  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1da74f  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1da758  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1da761  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1da76a  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1da773  add rsp, 0xF0
00007a3fbe1da77a  pop r11
00007a3fbe1da77c  pop r10
00007a3fbe1da77e  pop r9
00007a3fbe1da780  pop r8
00007a3fbe1da782  pop rsi
00007a3fbe1da783  pop rdi
00007a3fbe1da784  pop rdx
00007a3fbe1da785  pop rcx
00007a3fbe1da786  pop rax
00007a3fbe1da787  add rsp, 0x08
00007a3fbe1da78b  jmp 0x00007A3FBE1D8E6F
00007a3fbe1da790  sub rsp, 0x08
00007a3fbe1da794  push rax
00007a3fbe1da795  push rcx
00007a3fbe1da796  push rdx
00007a3fbe1da797  push rdi
00007a3fbe1da798  push rsi
00007a3fbe1da799  push r8
00007a3fbe1da79b  push r9
00007a3fbe1da79d  push r10
00007a3fbe1da79f  push r11
00007a3fbe1da7a1  sub rsp, 0xF0
00007a3fbe1da7a8  vmovaps [rsp], xmm0
00007a3fbe1da7ad  vmovaps [rsp+0x10], xmm1
00007a3fbe1da7b3  vmovaps [rsp+0x20], xmm2
00007a3fbe1da7b9  vmovaps [rsp+0x30], xmm3
00007a3fbe1da7bf  vmovaps [rsp+0x40], xmm4
00007a3fbe1da7c5  vmovaps [rsp+0x50], xmm5
00007a3fbe1da7cb  vmovaps [rsp+0x60], xmm7
00007a3fbe1da7d1  vmovaps [rsp+0x70], xmm8
00007a3fbe1da7d7  vmovaps [rsp+0x80], xmm9
00007a3fbe1da7e0  vmovaps [rsp+0x90], xmm10
00007a3fbe1da7e9  vmovaps [rsp+0xA0], xmm11
00007a3fbe1da7f2  vmovaps [rsp+0xB0], xmm12
00007a3fbe1da7fb  vmovaps [rsp+0xC0], xmm13
00007a3fbe1da804  vmovaps [rsp+0xD0], xmm14
00007a3fbe1da80d  vmovaps [rsp+0xE0], xmm15
00007a3fbe1da816  sub rsp, 0x30
00007a3fbe1da81a  movaps [rsp], xmm6
00007a3fbe1da81e  movaps [rsp+0x10], xmm9
00007a3fbe1da824  movaps [rsp+0x20], xmm7
00007a3fbe1da829  lea rdi, [rsp]
00007a3fbe1da82d  mov esi, 0x00
00007a3fbe1da832  mov rax, 0x60D1084DB530
00007a3fbe1da83c  call rax
00007a3fbe1da83e  movaps xmm6, [rsp]
00007a3fbe1da842  add rsp, 0x30
00007a3fbe1da846  vmovaps xmm0, [rsp]
00007a3fbe1da84b  vmovaps xmm1, [rsp+0x10]
00007a3fbe1da851  vmovaps xmm2, [rsp+0x20]
00007a3fbe1da857  vmovaps xmm3, [rsp+0x30]
00007a3fbe1da85d  vmovaps xmm4, [rsp+0x40]
00007a3fbe1da863  vmovaps xmm5, [rsp+0x50]
00007a3fbe1da869  vmovaps xmm7, [rsp+0x60]
00007a3fbe1da86f  vmovaps xmm8, [rsp+0x70]
00007a3fbe1da875  vmovaps xmm9, [rsp+0x80]
00007a3fbe1da87e  vmovaps xmm10, [rsp+0x90]
00007a3fbe1da887  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1da890  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1da899  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1da8a2  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1da8ab  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1da8b4  add rsp, 0xF0
00007a3fbe1da8bb  pop r11
00007a3fbe1da8bd  pop r10
00007a3fbe1da8bf  pop r9
00007a3fbe1da8c1  pop r8
00007a3fbe1da8c3  pop rsi
00007a3fbe1da8c4  pop rdi
00007a3fbe1da8c5  pop rdx
00007a3fbe1da8c6  pop rcx
00007a3fbe1da8c7  pop rax
00007a3fbe1da8c8  add rsp, 0x08
00007a3fbe1da8cc  jmp 0x00007A3FBE1D8E87
00007a3fbe1da8d1  sub rsp, 0x08
00007a3fbe1da8d5  push rax
00007a3fbe1da8d6  push rcx
00007a3fbe1da8d7  push rdx
00007a3fbe1da8d8  push rdi
00007a3fbe1da8d9  push rsi
00007a3fbe1da8da  push r8
00007a3fbe1da8dc  push r9
00007a3fbe1da8de  push r10
00007a3fbe1da8e0  push r11
00007a3fbe1da8e2  sub rsp, 0xF0
00007a3fbe1da8e9  vmovaps [rsp], xmm0
00007a3fbe1da8ee  vmovaps [rsp+0x10], xmm1
00007a3fbe1da8f4  vmovaps [rsp+0x20], xmm2
00007a3fbe1da8fa  vmovaps [rsp+0x30], xmm3
00007a3fbe1da900  vmovaps [rsp+0x40], xmm4
00007a3fbe1da906  vmovaps [rsp+0x50], xmm5
00007a3fbe1da90c  vmovaps [rsp+0x60], xmm6
00007a3fbe1da912  vmovaps [rsp+0x70], xmm8
00007a3fbe1da918  vmovaps [rsp+0x80], xmm9
00007a3fbe1da921  vmovaps [rsp+0x90], xmm10
00007a3fbe1da92a  vmovaps [rsp+0xA0], xmm11
00007a3fbe1da933  vmovaps [rsp+0xB0], xmm12
00007a3fbe1da93c  vmovaps [rsp+0xC0], xmm13
00007a3fbe1da945  vmovaps [rsp+0xD0], xmm14
00007a3fbe1da94e  vmovaps [rsp+0xE0], xmm15
00007a3fbe1da957  sub rsp, 0x30
00007a3fbe1da95b  movaps [rsp], xmm7
00007a3fbe1da95f  movaps [rsp+0x10], xmm4
00007a3fbe1da964  movaps [rsp+0x20], xmm9
00007a3fbe1da96a  lea rdi, [rsp]
00007a3fbe1da96e  mov esi, 0x00
00007a3fbe1da973  mov rax, 0x60D1084DB530
00007a3fbe1da97d  call rax
00007a3fbe1da97f  movaps xmm7, [rsp]
00007a3fbe1da983  add rsp, 0x30
00007a3fbe1da987  vmovaps xmm0, [rsp]
00007a3fbe1da98c  vmovaps xmm1, [rsp+0x10]
00007a3fbe1da992  vmovaps xmm2, [rsp+0x20]
00007a3fbe1da998  vmovaps xmm3, [rsp+0x30]
00007a3fbe1da99e  vmovaps xmm4, [rsp+0x40]
00007a3fbe1da9a4  vmovaps xmm5, [rsp+0x50]
00007a3fbe1da9aa  vmovaps xmm6, [rsp+0x60]
00007a3fbe1da9b0  vmovaps xmm8, [rsp+0x70]
00007a3fbe1da9b6  vmovaps xmm9, [rsp+0x80]
00007a3fbe1da9bf  vmovaps xmm10, [rsp+0x90]
00007a3fbe1da9c8  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1da9d1  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1da9da  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1da9e3  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1da9ec  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1da9f5  add rsp, 0xF0
00007a3fbe1da9fc  pop r11
00007a3fbe1da9fe  pop r10
00007a3fbe1daa00  pop r9
00007a3fbe1daa02  pop r8
00007a3fbe1daa04  pop rsi
00007a3fbe1daa05  pop rdi
00007a3fbe1daa06  pop rdx
00007a3fbe1daa07  pop rcx
00007a3fbe1daa08  pop rax
00007a3fbe1daa09  add rsp, 0x08
00007a3fbe1daa0d  jmp 0x00007A3FBE1D8EB4
00007a3fbe1daa12  sub rsp, 0x08
00007a3fbe1daa16  push rax
00007a3fbe1daa17  push rcx
00007a3fbe1daa18  push rdx
00007a3fbe1daa19  push rdi
00007a3fbe1daa1a  push rsi
00007a3fbe1daa1b  push r8
00007a3fbe1daa1d  push r9
00007a3fbe1daa1f  push r10
00007a3fbe1daa21  push r11
00007a3fbe1daa23  sub rsp, 0xF0
00007a3fbe1daa2a  vmovaps [rsp], xmm0
00007a3fbe1daa2f  vmovaps [rsp+0x10], xmm1
00007a3fbe1daa35  vmovaps [rsp+0x20], xmm2
00007a3fbe1daa3b  vmovaps [rsp+0x30], xmm3
00007a3fbe1daa41  vmovaps [rsp+0x40], xmm5
00007a3fbe1daa47  vmovaps [rsp+0x50], xmm6
00007a3fbe1daa4d  vmovaps [rsp+0x60], xmm7
00007a3fbe1daa53  vmovaps [rsp+0x70], xmm8
00007a3fbe1daa59  vmovaps [rsp+0x80], xmm9
00007a3fbe1daa62  vmovaps [rsp+0x90], xmm10
00007a3fbe1daa6b  vmovaps [rsp+0xA0], xmm11
00007a3fbe1daa74  vmovaps [rsp+0xB0], xmm12
00007a3fbe1daa7d  vmovaps [rsp+0xC0], xmm13
00007a3fbe1daa86  vmovaps [rsp+0xD0], xmm14
00007a3fbe1daa8f  vmovaps [rsp+0xE0], xmm15
00007a3fbe1daa98  sub rsp, 0x30
00007a3fbe1daa9c  movaps [rsp], xmm4
00007a3fbe1daaa0  movaps [rsp+0x10], xmm15
00007a3fbe1daaa6  movaps [rsp+0x20], xmm9
00007a3fbe1daaac  lea rdi, [rsp]
00007a3fbe1daab0  mov esi, 0x00
00007a3fbe1daab5  mov rax, 0x60D1084DB530
00007a3fbe1daabf  call rax
00007a3fbe1daac1  movaps xmm4, [rsp]
00007a3fbe1daac5  add rsp, 0x30
00007a3fbe1daac9  vmovaps xmm0, [rsp]
00007a3fbe1daace  vmovaps xmm1, [rsp+0x10]
00007a3fbe1daad4  vmovaps xmm2, [rsp+0x20]
00007a3fbe1daada  vmovaps xmm3, [rsp+0x30]
00007a3fbe1daae0  vmovaps xmm5, [rsp+0x40]
00007a3fbe1daae6  vmovaps xmm6, [rsp+0x50]
00007a3fbe1daaec  vmovaps xmm7, [rsp+0x60]
00007a3fbe1daaf2  vmovaps xmm8, [rsp+0x70]
00007a3fbe1daaf8  vmovaps xmm9, [rsp+0x80]
00007a3fbe1dab01  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dab0a  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dab13  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dab1c  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dab25  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dab2e  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dab37  add rsp, 0xF0
00007a3fbe1dab3e  pop r11
00007a3fbe1dab40  pop r10
00007a3fbe1dab42  pop r9
00007a3fbe1dab44  pop r8
00007a3fbe1dab46  pop rsi
00007a3fbe1dab47  pop rdi
00007a3fbe1dab48  pop rdx
00007a3fbe1dab49  pop rcx
00007a3fbe1dab4a  pop rax
00007a3fbe1dab4b  add rsp, 0x08
00007a3fbe1dab4f  jmp 0x00007A3FBE1D8ED9
00007a3fbe1dab54  call 0x00007A3FBE0E5820
00007a3fbe1dab59  jmp 0x00007A3FBE1D8EE6
00007a3fbe1dab5e  sub rsp, 0x08
00007a3fbe1dab62  push rax
00007a3fbe1dab63  push rcx
00007a3fbe1dab64  push rdx
00007a3fbe1dab65  push rdi
00007a3fbe1dab66  push rsi
00007a3fbe1dab67  push r8
00007a3fbe1dab69  push r9
00007a3fbe1dab6b  push r10
00007a3fbe1dab6d  push r11
00007a3fbe1dab6f  sub rsp, 0xF0
00007a3fbe1dab76  vmovaps [rsp], xmm0
00007a3fbe1dab7b  vmovaps [rsp+0x10], xmm1
00007a3fbe1dab81  vmovaps [rsp+0x20], xmm2
00007a3fbe1dab87  vmovaps [rsp+0x30], xmm4
00007a3fbe1dab8d  vmovaps [rsp+0x40], xmm5
00007a3fbe1dab93  vmovaps [rsp+0x50], xmm6
00007a3fbe1dab99  vmovaps [rsp+0x60], xmm7
00007a3fbe1dab9f  vmovaps [rsp+0x70], xmm8
00007a3fbe1daba5  vmovaps [rsp+0x80], xmm9
00007a3fbe1dabae  vmovaps [rsp+0x90], xmm10
00007a3fbe1dabb7  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dabc0  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dabc9  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dabd2  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dabdb  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dabe4  sub rsp, 0x30
00007a3fbe1dabe8  movaps [rsp], xmm3
00007a3fbe1dabec  movaps [rsp+0x10], xmm1
00007a3fbe1dabf1  movaps [rsp+0x20], xmm9
00007a3fbe1dabf7  lea rdi, [rsp]
00007a3fbe1dabfb  mov esi, 0x00
00007a3fbe1dac00  mov rax, 0x60D1084DB530
00007a3fbe1dac0a  call rax
00007a3fbe1dac0c  movaps xmm3, [rsp]
00007a3fbe1dac10  add rsp, 0x30
00007a3fbe1dac14  vmovaps xmm0, [rsp]
00007a3fbe1dac19  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dac1f  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dac25  vmovaps xmm4, [rsp+0x30]
00007a3fbe1dac2b  vmovaps xmm5, [rsp+0x40]
00007a3fbe1dac31  vmovaps xmm6, [rsp+0x50]
00007a3fbe1dac37  vmovaps xmm7, [rsp+0x60]
00007a3fbe1dac3d  vmovaps xmm8, [rsp+0x70]
00007a3fbe1dac43  vmovaps xmm9, [rsp+0x80]
00007a3fbe1dac4c  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dac55  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dac5e  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dac67  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dac70  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dac79  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dac82  add rsp, 0xF0
00007a3fbe1dac89  pop r11
00007a3fbe1dac8b  pop r10
00007a3fbe1dac8d  pop r9
00007a3fbe1dac8f  pop r8
00007a3fbe1dac91  pop rsi
00007a3fbe1dac92  pop rdi
00007a3fbe1dac93  pop rdx
00007a3fbe1dac94  pop rcx
00007a3fbe1dac95  pop rax
00007a3fbe1dac96  add rsp, 0x08
00007a3fbe1dac9a  jmp 0x00007A3FBE1D8F23
00007a3fbe1dac9f  sub rsp, 0x08
00007a3fbe1daca3  push rax
00007a3fbe1daca4  push rcx
00007a3fbe1daca5  push rdx
00007a3fbe1daca6  push rdi
00007a3fbe1daca7  push rsi
00007a3fbe1daca8  push r8
00007a3fbe1dacaa  push r9
00007a3fbe1dacac  push r10
00007a3fbe1dacae  push r11
00007a3fbe1dacb0  sub rsp, 0xF0
00007a3fbe1dacb7  vmovaps [rsp], xmm0
00007a3fbe1dacbc  vmovaps [rsp+0x10], xmm2
00007a3fbe1dacc2  vmovaps [rsp+0x20], xmm3
00007a3fbe1dacc8  vmovaps [rsp+0x30], xmm4
00007a3fbe1dacce  vmovaps [rsp+0x40], xmm5
00007a3fbe1dacd4  vmovaps [rsp+0x50], xmm6
00007a3fbe1dacda  vmovaps [rsp+0x60], xmm7
00007a3fbe1dace0  vmovaps [rsp+0x70], xmm8
00007a3fbe1dace6  vmovaps [rsp+0x80], xmm9
00007a3fbe1dacef  vmovaps [rsp+0x90], xmm10
00007a3fbe1dacf8  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dad01  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dad0a  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dad13  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dad1c  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dad25  sub rsp, 0x30
00007a3fbe1dad29  movaps [rsp], xmm1
00007a3fbe1dad2d  movaps [rsp+0x10], xmm15
00007a3fbe1dad33  movaps [rsp+0x20], xmm9
00007a3fbe1dad39  lea rdi, [rsp]
00007a3fbe1dad3d  mov esi, 0x00
00007a3fbe1dad42  mov rax, 0x60D1084DB530
00007a3fbe1dad4c  call rax
00007a3fbe1dad4e  movaps xmm1, [rsp]
00007a3fbe1dad52  add rsp, 0x30
00007a3fbe1dad56  vmovaps xmm0, [rsp]
00007a3fbe1dad5b  vmovaps xmm2, [rsp+0x10]
00007a3fbe1dad61  vmovaps xmm3, [rsp+0x20]
00007a3fbe1dad67  vmovaps xmm4, [rsp+0x30]
00007a3fbe1dad6d  vmovaps xmm5, [rsp+0x40]
00007a3fbe1dad73  vmovaps xmm6, [rsp+0x50]
00007a3fbe1dad79  vmovaps xmm7, [rsp+0x60]
00007a3fbe1dad7f  vmovaps xmm8, [rsp+0x70]
00007a3fbe1dad85  vmovaps xmm9, [rsp+0x80]
00007a3fbe1dad8e  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dad97  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dada0  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dada9  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dadb2  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dadbb  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dadc4  add rsp, 0xF0
00007a3fbe1dadcb  pop r11
00007a3fbe1dadcd  pop r10
00007a3fbe1dadcf  pop r9
00007a3fbe1dadd1  pop r8
00007a3fbe1dadd3  pop rsi
00007a3fbe1dadd4  pop rdi
00007a3fbe1dadd5  pop rdx
00007a3fbe1dadd6  pop rcx
00007a3fbe1dadd7  pop rax
00007a3fbe1dadd8  add rsp, 0x08
00007a3fbe1daddc  jmp 0x00007A3FBE1D8FAB
00007a3fbe1dade1  call 0x00007A3FBE0E5820
00007a3fbe1dade6  jmp 0x00007A3FBE1D8FB8
00007a3fbe1dadeb  sub rsp, 0x08
00007a3fbe1dadef  push rax
00007a3fbe1dadf0  push rcx
00007a3fbe1dadf1  push rdx
00007a3fbe1dadf2  push rdi
00007a3fbe1dadf3  push rsi
00007a3fbe1dadf4  push r8
00007a3fbe1dadf6  push r9
00007a3fbe1dadf8  push r10
00007a3fbe1dadfa  push r11
00007a3fbe1dadfc  sub rsp, 0xF0
00007a3fbe1dae03  vmovaps [rsp], xmm0
00007a3fbe1dae08  vmovaps [rsp+0x10], xmm2
00007a3fbe1dae0e  vmovaps [rsp+0x20], xmm3
00007a3fbe1dae14  vmovaps [rsp+0x30], xmm4
00007a3fbe1dae1a  vmovaps [rsp+0x40], xmm5
00007a3fbe1dae20  vmovaps [rsp+0x50], xmm6
00007a3fbe1dae26  vmovaps [rsp+0x60], xmm7
00007a3fbe1dae2c  vmovaps [rsp+0x70], xmm8
00007a3fbe1dae32  vmovaps [rsp+0x80], xmm9
00007a3fbe1dae3b  vmovaps [rsp+0x90], xmm10
00007a3fbe1dae44  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dae4d  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dae56  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dae5f  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dae68  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dae71  sub rsp, 0x30
00007a3fbe1dae75  movaps [rsp], xmm1
00007a3fbe1dae79  movaps [rsp+0x10], xmm5
00007a3fbe1dae7e  movaps [rsp+0x20], xmm7
00007a3fbe1dae83  lea rdi, [rsp]
00007a3fbe1dae87  mov esi, 0x00
00007a3fbe1dae8c  mov rax, 0x60D1084DB530
00007a3fbe1dae96  call rax
00007a3fbe1dae98  movaps xmm1, [rsp]
00007a3fbe1dae9c  add rsp, 0x30
00007a3fbe1daea0  vmovaps xmm0, [rsp]
00007a3fbe1daea5  vmovaps xmm2, [rsp+0x10]
00007a3fbe1daeab  vmovaps xmm3, [rsp+0x20]
00007a3fbe1daeb1  vmovaps xmm4, [rsp+0x30]
00007a3fbe1daeb7  vmovaps xmm5, [rsp+0x40]
00007a3fbe1daebd  vmovaps xmm6, [rsp+0x50]
00007a3fbe1daec3  vmovaps xmm7, [rsp+0x60]
00007a3fbe1daec9  vmovaps xmm8, [rsp+0x70]
00007a3fbe1daecf  vmovaps xmm9, [rsp+0x80]
00007a3fbe1daed8  vmovaps xmm10, [rsp+0x90]
00007a3fbe1daee1  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1daeea  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1daef3  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1daefc  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1daf05  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1daf0e  add rsp, 0xF0
00007a3fbe1daf15  pop r11
00007a3fbe1daf17  pop r10
00007a3fbe1daf19  pop r9
00007a3fbe1daf1b  pop r8
00007a3fbe1daf1d  pop rsi
00007a3fbe1daf1e  pop rdi
00007a3fbe1daf1f  pop rdx
00007a3fbe1daf20  pop rcx
00007a3fbe1daf21  pop rax
00007a3fbe1daf22  add rsp, 0x08
00007a3fbe1daf26  jmp 0x00007A3FBE1D905D
00007a3fbe1daf2b  sub rsp, 0x08
00007a3fbe1daf2f  push rax
00007a3fbe1daf30  push rcx
00007a3fbe1daf31  push rdx
00007a3fbe1daf32  push rdi
00007a3fbe1daf33  push rsi
00007a3fbe1daf34  push r8
00007a3fbe1daf36  push r9
00007a3fbe1daf38  push r10
00007a3fbe1daf3a  push r11
00007a3fbe1daf3c  sub rsp, 0xF0
00007a3fbe1daf43  vmovaps [rsp], xmm0
00007a3fbe1daf48  vmovaps [rsp+0x10], xmm1
00007a3fbe1daf4e  vmovaps [rsp+0x20], xmm2
00007a3fbe1daf54  vmovaps [rsp+0x30], xmm3
00007a3fbe1daf5a  vmovaps [rsp+0x40], xmm4
00007a3fbe1daf60  vmovaps [rsp+0x50], xmm5
00007a3fbe1daf66  vmovaps [rsp+0x60], xmm6
00007a3fbe1daf6c  vmovaps [rsp+0x70], xmm8
00007a3fbe1daf72  vmovaps [rsp+0x80], xmm9
00007a3fbe1daf7b  vmovaps [rsp+0x90], xmm10
00007a3fbe1daf84  vmovaps [rsp+0xA0], xmm11
00007a3fbe1daf8d  vmovaps [rsp+0xB0], xmm12
00007a3fbe1daf96  vmovaps [rsp+0xC0], xmm13
00007a3fbe1daf9f  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dafa8  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dafb1  sub rsp, 0x30
00007a3fbe1dafb5  movaps [rsp], xmm7
00007a3fbe1dafb9  movaps [rsp+0x10], xmm5
00007a3fbe1dafbe  movaps [rsp+0x20], xmm15
00007a3fbe1dafc4  lea rdi, [rsp]
00007a3fbe1dafc8  mov esi, 0x00
00007a3fbe1dafcd  mov rax, 0x60D1084DB530
00007a3fbe1dafd7  call rax
00007a3fbe1dafd9  movaps xmm7, [rsp]
00007a3fbe1dafdd  add rsp, 0x30
00007a3fbe1dafe1  vmovaps xmm0, [rsp]
00007a3fbe1dafe6  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dafec  vmovaps xmm2, [rsp+0x20]
00007a3fbe1daff2  vmovaps xmm3, [rsp+0x30]
00007a3fbe1daff8  vmovaps xmm4, [rsp+0x40]
00007a3fbe1daffe  vmovaps xmm5, [rsp+0x50]
00007a3fbe1db004  vmovaps xmm6, [rsp+0x60]
00007a3fbe1db00a  vmovaps xmm8, [rsp+0x70]
00007a3fbe1db010  vmovaps xmm9, [rsp+0x80]
00007a3fbe1db019  vmovaps xmm10, [rsp+0x90]
00007a3fbe1db022  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1db02b  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1db034  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1db03d  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1db046  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1db04f  add rsp, 0xF0
00007a3fbe1db056  pop r11
00007a3fbe1db058  pop r10
00007a3fbe1db05a  pop r9
00007a3fbe1db05c  pop r8
00007a3fbe1db05e  pop rsi
00007a3fbe1db05f  pop rdi
00007a3fbe1db060  pop rdx
00007a3fbe1db061  pop rcx
00007a3fbe1db062  pop rax
00007a3fbe1db063  add rsp, 0x08
00007a3fbe1db067  jmp 0x00007A3FBE1D9093
00007a3fbe1db06c  call 0x00007A3FBE0D64F0
00007a3fbe1db071  jmp 0x00007A3FBE1D90A0
00007a3fbe1db076  sub rsp, 0x08
00007a3fbe1db07a  push rax
00007a3fbe1db07b  push rcx
00007a3fbe1db07c  push rdx
00007a3fbe1db07d  push rdi
00007a3fbe1db07e  push rsi
00007a3fbe1db07f  push r8
00007a3fbe1db081  push r9
00007a3fbe1db083  push r10
00007a3fbe1db085  push r11
00007a3fbe1db087  sub rsp, 0xF0
00007a3fbe1db08e  vmovaps [rsp], xmm0
00007a3fbe1db093  vmovaps [rsp+0x10], xmm1
00007a3fbe1db099  vmovaps [rsp+0x20], xmm2
00007a3fbe1db09f  vmovaps [rsp+0x30], xmm3
00007a3fbe1db0a5  vmovaps [rsp+0x40], xmm4
00007a3fbe1db0ab  vmovaps [rsp+0x50], xmm5
00007a3fbe1db0b1  vmovaps [rsp+0x60], xmm6
00007a3fbe1db0b7  vmovaps [rsp+0x70], xmm7
00007a3fbe1db0bd  vmovaps [rsp+0x80], xmm8
00007a3fbe1db0c6  vmovaps [rsp+0x90], xmm9
00007a3fbe1db0cf  vmovaps [rsp+0xA0], xmm10
00007a3fbe1db0d8  vmovaps [rsp+0xB0], xmm11
00007a3fbe1db0e1  vmovaps [rsp+0xC0], xmm12
00007a3fbe1db0ea  vmovaps [rsp+0xD0], xmm13
00007a3fbe1db0f3  vmovaps [rsp+0xE0], xmm14
00007a3fbe1db0fc  sub rsp, 0x30
00007a3fbe1db100  movaps [rsp], xmm15
00007a3fbe1db105  movaps [rsp+0x10], xmm5
00007a3fbe1db10a  movaps [rsp+0x20], xmm3
00007a3fbe1db10f  lea rdi, [rsp]
00007a3fbe1db113  mov esi, 0x00
00007a3fbe1db118  mov rax, 0x60D1084DB530
00007a3fbe1db122  call rax
00007a3fbe1db124  movaps xmm15, [rsp]
00007a3fbe1db129  add rsp, 0x30
00007a3fbe1db12d  vmovaps xmm0, [rsp]
00007a3fbe1db132  vmovaps xmm1, [rsp+0x10]
00007a3fbe1db138  vmovaps xmm2, [rsp+0x20]
00007a3fbe1db13e  vmovaps xmm3, [rsp+0x30]
00007a3fbe1db144  vmovaps xmm4, [rsp+0x40]
00007a3fbe1db14a  vmovaps xmm5, [rsp+0x50]
00007a3fbe1db150  vmovaps xmm6, [rsp+0x60]
00007a3fbe1db156  vmovaps xmm7, [rsp+0x70]
00007a3fbe1db15c  vmovaps xmm8, [rsp+0x80]
00007a3fbe1db165  vmovaps xmm9, [rsp+0x90]
00007a3fbe1db16e  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1db177  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1db180  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1db189  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1db192  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1db19b  add rsp, 0xF0
00007a3fbe1db1a2  pop r11
00007a3fbe1db1a4  pop r10
00007a3fbe1db1a6  pop r9
00007a3fbe1db1a8  pop r8
00007a3fbe1db1aa  pop rsi
00007a3fbe1db1ab  pop rdi
00007a3fbe1db1ac  pop rdx
00007a3fbe1db1ad  pop rcx
00007a3fbe1db1ae  pop rax
00007a3fbe1db1af  add rsp, 0x08
00007a3fbe1db1b3  jmp 0x00007A3FBE1D90C6
00007a3fbe1db1b8  sub rsp, 0x08
00007a3fbe1db1bc  push rax
00007a3fbe1db1bd  push rcx
00007a3fbe1db1be  push rdx
00007a3fbe1db1bf  push rdi
00007a3fbe1db1c0  push rsi
00007a3fbe1db1c1  push r8
00007a3fbe1db1c3  push r9
00007a3fbe1db1c5  push r10
00007a3fbe1db1c7  push r11
00007a3fbe1db1c9  sub rsp, 0xF0
00007a3fbe1db1d0  vmovaps [rsp], xmm0
00007a3fbe1db1d5  vmovaps [rsp+0x10], xmm2
00007a3fbe1db1db  vmovaps [rsp+0x20], xmm3
00007a3fbe1db1e1  vmovaps [rsp+0x30], xmm4
00007a3fbe1db1e7  vmovaps [rsp+0x40], xmm5
00007a3fbe1db1ed  vmovaps [rsp+0x50], xmm6
00007a3fbe1db1f3  vmovaps [rsp+0x60], xmm7
00007a3fbe1db1f9  vmovaps [rsp+0x70], xmm8
00007a3fbe1db1ff  vmovaps [rsp+0x80], xmm9
00007a3fbe1db208  vmovaps [rsp+0x90], xmm10
00007a3fbe1db211  vmovaps [rsp+0xA0], xmm11
00007a3fbe1db21a  vmovaps [rsp+0xB0], xmm12
00007a3fbe1db223  vmovaps [rsp+0xC0], xmm13
00007a3fbe1db22c  vmovaps [rsp+0xD0], xmm14
00007a3fbe1db235  vmovaps [rsp+0xE0], xmm15
00007a3fbe1db23e  sub rsp, 0x30
00007a3fbe1db242  movaps [rsp], xmm1
00007a3fbe1db246  movaps [rsp+0x10], xmm5
00007a3fbe1db24b  movaps [rsp+0x20], xmm4
00007a3fbe1db250  lea rdi, [rsp]
00007a3fbe1db254  mov esi, 0x00
00007a3fbe1db259  mov rax, 0x60D1084DB530
00007a3fbe1db263  call rax
00007a3fbe1db265  movaps xmm1, [rsp]
00007a3fbe1db269  add rsp, 0x30
00007a3fbe1db26d  vmovaps xmm0, [rsp]
00007a3fbe1db272  vmovaps xmm2, [rsp+0x10]
00007a3fbe1db278  vmovaps xmm3, [rsp+0x20]
00007a3fbe1db27e  vmovaps xmm4, [rsp+0x30]
00007a3fbe1db284  vmovaps xmm5, [rsp+0x40]
00007a3fbe1db28a  vmovaps xmm6, [rsp+0x50]
00007a3fbe1db290  vmovaps xmm7, [rsp+0x60]
00007a3fbe1db296  vmovaps xmm8, [rsp+0x70]
00007a3fbe1db29c  vmovaps xmm9, [rsp+0x80]
00007a3fbe1db2a5  vmovaps xmm10, [rsp+0x90]
00007a3fbe1db2ae  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1db2b7  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1db2c0  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1db2c9  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1db2d2  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1db2db  add rsp, 0xF0
00007a3fbe1db2e2  pop r11
00007a3fbe1db2e4  pop r10
00007a3fbe1db2e6  pop r9
00007a3fbe1db2e8  pop r8
00007a3fbe1db2ea  pop rsi
00007a3fbe1db2eb  pop rdi
00007a3fbe1db2ec  pop rdx
00007a3fbe1db2ed  pop rcx
00007a3fbe1db2ee  pop rax
00007a3fbe1db2ef  add rsp, 0x08
00007a3fbe1db2f3  jmp 0x00007A3FBE1D90E6
00007a3fbe1db2f8  sub rsp, 0x08
00007a3fbe1db2fc  push rax
00007a3fbe1db2fd  push rcx
00007a3fbe1db2fe  push rdx
00007a3fbe1db2ff  push rdi
00007a3fbe1db300  push rsi
00007a3fbe1db301  push r8
00007a3fbe1db303  push r9
00007a3fbe1db305  push r10
00007a3fbe1db307  push r11
00007a3fbe1db309  sub rsp, 0xF0
00007a3fbe1db310  vmovaps [rsp], xmm0
00007a3fbe1db315  vmovaps [rsp+0x10], xmm1
00007a3fbe1db31b  vmovaps [rsp+0x20], xmm2
00007a3fbe1db321  vmovaps [rsp+0x30], xmm3
00007a3fbe1db327  vmovaps [rsp+0x40], xmm5
00007a3fbe1db32d  vmovaps [rsp+0x50], xmm6
00007a3fbe1db333  vmovaps [rsp+0x60], xmm7
00007a3fbe1db339  vmovaps [rsp+0x70], xmm8
00007a3fbe1db33f  vmovaps [rsp+0x80], xmm9
00007a3fbe1db348  vmovaps [rsp+0x90], xmm10
00007a3fbe1db351  vmovaps [rsp+0xA0], xmm11
00007a3fbe1db35a  vmovaps [rsp+0xB0], xmm12
00007a3fbe1db363  vmovaps [rsp+0xC0], xmm13
00007a3fbe1db36c  vmovaps [rsp+0xD0], xmm14
00007a3fbe1db375  vmovaps [rsp+0xE0], xmm15
00007a3fbe1db37e  sub rsp, 0x30
00007a3fbe1db382  movaps [rsp], xmm4
00007a3fbe1db386  movaps [rsp+0x10], xmm3
00007a3fbe1db38b  movaps [rsp+0x20], xmm5
00007a3fbe1db390  lea rdi, [rsp]
00007a3fbe1db394  mov esi, 0x00
00007a3fbe1db399  mov rax, 0x60D1084DB530
00007a3fbe1db3a3  call rax
00007a3fbe1db3a5  movaps xmm4, [rsp]
00007a3fbe1db3a9  add rsp, 0x30
00007a3fbe1db3ad  vmovaps xmm0, [rsp]
00007a3fbe1db3b2  vmovaps xmm1, [rsp+0x10]
00007a3fbe1db3b8  vmovaps xmm2, [rsp+0x20]
00007a3fbe1db3be  vmovaps xmm3, [rsp+0x30]
00007a3fbe1db3c4  vmovaps xmm5, [rsp+0x40]
00007a3fbe1db3ca  vmovaps xmm6, [rsp+0x50]
00007a3fbe1db3d0  vmovaps xmm7, [rsp+0x60]
00007a3fbe1db3d6  vmovaps xmm8, [rsp+0x70]
00007a3fbe1db3dc  vmovaps xmm9, [rsp+0x80]
00007a3fbe1db3e5  vmovaps xmm10, [rsp+0x90]
00007a3fbe1db3ee  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1db3f7  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1db400  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1db409  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1db412  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1db41b  add rsp, 0xF0
00007a3fbe1db422  pop r11
00007a3fbe1db424  pop r10
00007a3fbe1db426  pop r9
00007a3fbe1db428  pop r8
00007a3fbe1db42a  pop rsi
00007a3fbe1db42b  pop rdi
00007a3fbe1db42c  pop rdx
00007a3fbe1db42d  pop rcx
00007a3fbe1db42e  pop rax
00007a3fbe1db42f  add rsp, 0x08
00007a3fbe1db433  jmp 0x00007A3FBE1D9134
00007a3fbe1db438  call 0x00007A3FBE0D64F0
00007a3fbe1db43d  jmp 0x00007A3FBE1D9141
00007a3fbe1db442  sub rsp, 0x08
00007a3fbe1db446  push rax
00007a3fbe1db447  push rcx
00007a3fbe1db448  push rdx
00007a3fbe1db449  push rdi
00007a3fbe1db44a  push rsi
00007a3fbe1db44b  push r8
00007a3fbe1db44d  push r9
00007a3fbe1db44f  push r10
00007a3fbe1db451  push r11
00007a3fbe1db453  sub rsp, 0xF0
00007a3fbe1db45a  vmovaps [rsp], xmm0
00007a3fbe1db45f  vmovaps [rsp+0x10], xmm1
00007a3fbe1db465  vmovaps [rsp+0x20], xmm2
00007a3fbe1db46b  vmovaps [rsp+0x30], xmm3
00007a3fbe1db471  vmovaps [rsp+0x40], xmm4
00007a3fbe1db477  vmovaps [rsp+0x50], xmm6
00007a3fbe1db47d  vmovaps [rsp+0x60], xmm7
00007a3fbe1db483  vmovaps [rsp+0x70], xmm8
00007a3fbe1db489  vmovaps [rsp+0x80], xmm9
00007a3fbe1db492  vmovaps [rsp+0x90], xmm10
00007a3fbe1db49b  vmovaps [rsp+0xA0], xmm11
00007a3fbe1db4a4  vmovaps [rsp+0xB0], xmm12
00007a3fbe1db4ad  vmovaps [rsp+0xC0], xmm13
00007a3fbe1db4b6  vmovaps [rsp+0xD0], xmm14
00007a3fbe1db4bf  vmovaps [rsp+0xE0], xmm15
00007a3fbe1db4c8  sub rsp, 0x30
00007a3fbe1db4cc  movaps [rsp], xmm5
00007a3fbe1db4d0  movaps [rsp+0x10], xmm6
00007a3fbe1db4d5  movaps [rsp+0x20], xmm3
00007a3fbe1db4da  lea rdi, [rsp]
00007a3fbe1db4de  mov esi, 0x00
00007a3fbe1db4e3  mov rax, 0x60D1084DB530
00007a3fbe1db4ed  call rax
00007a3fbe1db4ef  movaps xmm5, [rsp]
00007a3fbe1db4f3  add rsp, 0x30
00007a3fbe1db4f7  vmovaps xmm0, [rsp]
00007a3fbe1db4fc  vmovaps xmm1, [rsp+0x10]
00007a3fbe1db502  vmovaps xmm2, [rsp+0x20]
00007a3fbe1db508  vmovaps xmm3, [rsp+0x30]
00007a3fbe1db50e  vmovaps xmm4, [rsp+0x40]
00007a3fbe1db514  vmovaps xmm6, [rsp+0x50]
00007a3fbe1db51a  vmovaps xmm7, [rsp+0x60]
00007a3fbe1db520  vmovaps xmm8, [rsp+0x70]
00007a3fbe1db526  vmovaps xmm9, [rsp+0x80]
00007a3fbe1db52f  vmovaps xmm10, [rsp+0x90]
00007a3fbe1db538  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1db541  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1db54a  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1db553  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1db55c  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1db565  add rsp, 0xF0
00007a3fbe1db56c  pop r11
00007a3fbe1db56e  pop r10
00007a3fbe1db570  pop r9
00007a3fbe1db572  pop r8
00007a3fbe1db574  pop rsi
00007a3fbe1db575  pop rdi
00007a3fbe1db576  pop rdx
00007a3fbe1db577  pop rcx
00007a3fbe1db578  pop rax
00007a3fbe1db579  add rsp, 0x08
00007a3fbe1db57d  jmp 0x00007A3FBE1D9167
00007a3fbe1db582  sub rsp, 0x08
00007a3fbe1db586  push rax
00007a3fbe1db587  push rcx
00007a3fbe1db588  push rdx
00007a3fbe1db589  push rdi
00007a3fbe1db58a  push rsi
00007a3fbe1db58b  push r8
00007a3fbe1db58d  push r9
00007a3fbe1db58f  push r10
00007a3fbe1db591  push r11
00007a3fbe1db593  sub rsp, 0xF0
00007a3fbe1db59a  vmovaps [rsp], xmm0
00007a3fbe1db59f  vmovaps [rsp+0x10], xmm1
00007a3fbe1db5a5  vmovaps [rsp+0x20], xmm2
00007a3fbe1db5ab  vmovaps [rsp+0x30], xmm3
00007a3fbe1db5b1  vmovaps [rsp+0x40], xmm4
00007a3fbe1db5b7  vmovaps [rsp+0x50], xmm5
00007a3fbe1db5bd  vmovaps [rsp+0x60], xmm7
00007a3fbe1db5c3  vmovaps [rsp+0x70], xmm8
00007a3fbe1db5c9  vmovaps [rsp+0x80], xmm9
00007a3fbe1db5d2  vmovaps [rsp+0x90], xmm10
00007a3fbe1db5db  vmovaps [rsp+0xA0], xmm11
00007a3fbe1db5e4  vmovaps [rsp+0xB0], xmm12
00007a3fbe1db5ed  vmovaps [rsp+0xC0], xmm13
00007a3fbe1db5f6  vmovaps [rsp+0xD0], xmm14
00007a3fbe1db5ff  vmovaps [rsp+0xE0], xmm15
00007a3fbe1db608  sub rsp, 0x30
00007a3fbe1db60c  movaps [rsp], xmm6
00007a3fbe1db610  movaps [rsp+0x10], xmm9
00007a3fbe1db616  movaps [rsp+0x20], xmm1
00007a3fbe1db61b  lea rdi, [rsp]
00007a3fbe1db61f  mov esi, 0x00
00007a3fbe1db624  mov rax, 0x60D1084DB530
00007a3fbe1db62e  call rax
00007a3fbe1db630  movaps xmm6, [rsp]
00007a3fbe1db634  add rsp, 0x30
00007a3fbe1db638  vmovaps xmm0, [rsp]
00007a3fbe1db63d  vmovaps xmm1, [rsp+0x10]
00007a3fbe1db643  vmovaps xmm2, [rsp+0x20]
00007a3fbe1db649  vmovaps xmm3, [rsp+0x30]
00007a3fbe1db64f  vmovaps xmm4, [rsp+0x40]
00007a3fbe1db655  vmovaps xmm5, [rsp+0x50]
00007a3fbe1db65b  vmovaps xmm7, [rsp+0x60]
00007a3fbe1db661  vmovaps xmm8, [rsp+0x70]
00007a3fbe1db667  vmovaps xmm9, [rsp+0x80]
00007a3fbe1db670  vmovaps xmm10, [rsp+0x90]
00007a3fbe1db679  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1db682  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1db68b  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1db694  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1db69d  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1db6a6  add rsp, 0xF0
00007a3fbe1db6ad  pop r11
00007a3fbe1db6af  pop r10
00007a3fbe1db6b1  pop r9
00007a3fbe1db6b3  pop r8
00007a3fbe1db6b5  pop rsi
00007a3fbe1db6b6  pop rdi
00007a3fbe1db6b7  pop rdx
00007a3fbe1db6b8  pop rcx
00007a3fbe1db6b9  pop rax
00007a3fbe1db6ba  add rsp, 0x08
00007a3fbe1db6be  jmp 0x00007A3FBE1D918B
00007a3fbe1db6c3  sub rsp, 0x08
00007a3fbe1db6c7  push rax
00007a3fbe1db6c8  push rcx
00007a3fbe1db6c9  push rdx
00007a3fbe1db6ca  push rdi
00007a3fbe1db6cb  push rsi
00007a3fbe1db6cc  push r8
00007a3fbe1db6ce  push r9
00007a3fbe1db6d0  push r10
00007a3fbe1db6d2  push r11
00007a3fbe1db6d4  sub rsp, 0xF0
00007a3fbe1db6db  vmovaps [rsp], xmm0
00007a3fbe1db6e0  vmovaps [rsp+0x10], xmm1
00007a3fbe1db6e6  vmovaps [rsp+0x20], xmm2
00007a3fbe1db6ec  vmovaps [rsp+0x30], xmm3
00007a3fbe1db6f2  vmovaps [rsp+0x40], xmm4
00007a3fbe1db6f8  vmovaps [rsp+0x50], xmm5
00007a3fbe1db6fe  vmovaps [rsp+0x60], xmm6
00007a3fbe1db704  vmovaps [rsp+0x70], xmm7
00007a3fbe1db70a  vmovaps [rsp+0x80], xmm8
00007a3fbe1db713  vmovaps [rsp+0x90], xmm10
00007a3fbe1db71c  vmovaps [rsp+0xA0], xmm11
00007a3fbe1db725  vmovaps [rsp+0xB0], xmm12
00007a3fbe1db72e  vmovaps [rsp+0xC0], xmm13
00007a3fbe1db737  vmovaps [rsp+0xD0], xmm14
00007a3fbe1db740  vmovaps [rsp+0xE0], xmm15
00007a3fbe1db749  sub rsp, 0x30
00007a3fbe1db74d  movaps [rsp], xmm9
00007a3fbe1db752  movaps [rsp+0x10], xmm3
00007a3fbe1db757  movaps [rsp+0x20], xmm1
00007a3fbe1db75c  lea rdi, [rsp]
00007a3fbe1db760  mov esi, 0x00
00007a3fbe1db765  mov rax, 0x60D1084DB530
00007a3fbe1db76f  call rax
00007a3fbe1db771  movaps xmm9, [rsp]
00007a3fbe1db776  add rsp, 0x30
00007a3fbe1db77a  vmovaps xmm0, [rsp]
00007a3fbe1db77f  vmovaps xmm1, [rsp+0x10]
00007a3fbe1db785  vmovaps xmm2, [rsp+0x20]
00007a3fbe1db78b  vmovaps xmm3, [rsp+0x30]
00007a3fbe1db791  vmovaps xmm4, [rsp+0x40]
00007a3fbe1db797  vmovaps xmm5, [rsp+0x50]
00007a3fbe1db79d  vmovaps xmm6, [rsp+0x60]
00007a3fbe1db7a3  vmovaps xmm7, [rsp+0x70]
00007a3fbe1db7a9  vmovaps xmm8, [rsp+0x80]
00007a3fbe1db7b2  vmovaps xmm10, [rsp+0x90]
00007a3fbe1db7bb  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1db7c4  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1db7cd  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1db7d6  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1db7df  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1db7e8  add rsp, 0xF0
00007a3fbe1db7ef  pop r11
00007a3fbe1db7f1  pop r10
00007a3fbe1db7f3  pop r9
00007a3fbe1db7f5  pop r8
00007a3fbe1db7f7  pop rsi
00007a3fbe1db7f8  pop rdi
00007a3fbe1db7f9  pop rdx
00007a3fbe1db7fa  pop rcx
00007a3fbe1db7fb  pop rax
00007a3fbe1db7fc  add rsp, 0x08
00007a3fbe1db800  jmp 0x00007A3FBE1D91D7
00007a3fbe1db805  call 0x00007A3FBE0D64F0
00007a3fbe1db80a  jmp 0x00007A3FBE1D91E4
00007a3fbe1db80f  sub rsp, 0x08
00007a3fbe1db813  push rax
00007a3fbe1db814  push rcx
00007a3fbe1db815  push rdx
00007a3fbe1db816  push rdi
00007a3fbe1db817  push rsi
00007a3fbe1db818  push r8
00007a3fbe1db81a  push r9
00007a3fbe1db81c  push r10
00007a3fbe1db81e  push r11
00007a3fbe1db820  sub rsp, 0xF0
00007a3fbe1db827  vmovaps [rsp], xmm0
00007a3fbe1db82c  vmovaps [rsp+0x10], xmm1
00007a3fbe1db832  vmovaps [rsp+0x20], xmm2
00007a3fbe1db838  vmovaps [rsp+0x30], xmm3
00007a3fbe1db83e  vmovaps [rsp+0x40], xmm4
00007a3fbe1db844  vmovaps [rsp+0x50], xmm5
00007a3fbe1db84a  vmovaps [rsp+0x60], xmm6
00007a3fbe1db850  vmovaps [rsp+0x70], xmm7
00007a3fbe1db856  vmovaps [rsp+0x80], xmm8
00007a3fbe1db85f  vmovaps [rsp+0x90], xmm9
00007a3fbe1db868  vmovaps [rsp+0xA0], xmm10
00007a3fbe1db871  vmovaps [rsp+0xB0], xmm11
00007a3fbe1db87a  vmovaps [rsp+0xC0], xmm12
00007a3fbe1db883  vmovaps [rsp+0xD0], xmm13
00007a3fbe1db88c  vmovaps [rsp+0xE0], xmm14
00007a3fbe1db895  sub rsp, 0x30
00007a3fbe1db899  movaps [rsp], xmm15
00007a3fbe1db89e  movaps [rsp+0x10], xmm3
00007a3fbe1db8a3  movaps [rsp+0x20], xmm7
00007a3fbe1db8a8  lea rdi, [rsp]
00007a3fbe1db8ac  mov esi, 0x00
00007a3fbe1db8b1  mov rax, 0x60D1084DB530
00007a3fbe1db8bb  call rax
00007a3fbe1db8bd  movaps xmm15, [rsp]
00007a3fbe1db8c2  add rsp, 0x30
00007a3fbe1db8c6  vmovaps xmm0, [rsp]
00007a3fbe1db8cb  vmovaps xmm1, [rsp+0x10]
00007a3fbe1db8d1  vmovaps xmm2, [rsp+0x20]
00007a3fbe1db8d7  vmovaps xmm3, [rsp+0x30]
00007a3fbe1db8dd  vmovaps xmm4, [rsp+0x40]
00007a3fbe1db8e3  vmovaps xmm5, [rsp+0x50]
00007a3fbe1db8e9  vmovaps xmm6, [rsp+0x60]
00007a3fbe1db8ef  vmovaps xmm7, [rsp+0x70]
00007a3fbe1db8f5  vmovaps xmm8, [rsp+0x80]
00007a3fbe1db8fe  vmovaps xmm9, [rsp+0x90]
00007a3fbe1db907  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1db910  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1db919  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1db922  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1db92b  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1db934  add rsp, 0xF0
00007a3fbe1db93b  pop r11
00007a3fbe1db93d  pop r10
00007a3fbe1db93f  pop r9
00007a3fbe1db941  pop r8
00007a3fbe1db943  pop rsi
00007a3fbe1db944  pop rdi
00007a3fbe1db945  pop rdx
00007a3fbe1db946  pop rcx
00007a3fbe1db947  pop rax
00007a3fbe1db948  add rsp, 0x08
00007a3fbe1db94c  jmp 0x00007A3FBE1D9210
00007a3fbe1db951  sub rsp, 0x08
00007a3fbe1db955  push rax
00007a3fbe1db956  push rcx
00007a3fbe1db957  push rdx
00007a3fbe1db958  push rdi
00007a3fbe1db959  push rsi
00007a3fbe1db95a  push r8
00007a3fbe1db95c  push r9
00007a3fbe1db95e  push r10
00007a3fbe1db960  push r11
00007a3fbe1db962  sub rsp, 0xF0
00007a3fbe1db969  vmovaps [rsp], xmm0
00007a3fbe1db96e  vmovaps [rsp+0x10], xmm1
00007a3fbe1db974  vmovaps [rsp+0x20], xmm2
00007a3fbe1db97a  vmovaps [rsp+0x30], xmm4
00007a3fbe1db980  vmovaps [rsp+0x40], xmm5
00007a3fbe1db986  vmovaps [rsp+0x50], xmm6
00007a3fbe1db98c  vmovaps [rsp+0x60], xmm7
00007a3fbe1db992  vmovaps [rsp+0x70], xmm8
00007a3fbe1db998  vmovaps [rsp+0x80], xmm9
00007a3fbe1db9a1  vmovaps [rsp+0x90], xmm10
00007a3fbe1db9aa  vmovaps [rsp+0xA0], xmm11
00007a3fbe1db9b3  vmovaps [rsp+0xB0], xmm12
00007a3fbe1db9bc  vmovaps [rsp+0xC0], xmm13
00007a3fbe1db9c5  vmovaps [rsp+0xD0], xmm14
00007a3fbe1db9ce  vmovaps [rsp+0xE0], xmm15
00007a3fbe1db9d7  sub rsp, 0x30
00007a3fbe1db9db  movaps [rsp], xmm3
00007a3fbe1db9df  movaps [rsp+0x10], xmm1
00007a3fbe1db9e4  movaps [rsp+0x20], xmm15
00007a3fbe1db9ea  lea rdi, [rsp]
00007a3fbe1db9ee  mov esi, 0x00
00007a3fbe1db9f3  mov rax, 0x60D1084DB530
00007a3fbe1db9fd  call rax
00007a3fbe1db9ff  movaps xmm3, [rsp]
00007a3fbe1dba03  add rsp, 0x30
00007a3fbe1dba07  vmovaps xmm0, [rsp]
00007a3fbe1dba0c  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dba12  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dba18  vmovaps xmm4, [rsp+0x30]
00007a3fbe1dba1e  vmovaps xmm5, [rsp+0x40]
00007a3fbe1dba24  vmovaps xmm6, [rsp+0x50]
00007a3fbe1dba2a  vmovaps xmm7, [rsp+0x60]
00007a3fbe1dba30  vmovaps xmm8, [rsp+0x70]
00007a3fbe1dba36  vmovaps xmm9, [rsp+0x80]
00007a3fbe1dba3f  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dba48  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dba51  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dba5a  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dba63  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dba6c  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dba75  add rsp, 0xF0
00007a3fbe1dba7c  pop r11
00007a3fbe1dba7e  pop r10
00007a3fbe1dba80  pop r9
00007a3fbe1dba82  pop r8
00007a3fbe1dba84  pop rsi
00007a3fbe1dba85  pop rdi
00007a3fbe1dba86  pop rdx
00007a3fbe1dba87  pop rcx
00007a3fbe1dba88  pop rax
00007a3fbe1dba89  add rsp, 0x08
00007a3fbe1dba8d  jmp 0x00007A3FBE1D929F
00007a3fbe1dba92  call 0x00007A3FBE0D64F0
00007a3fbe1dba97  jmp 0x00007A3FBE1D92A9
00007a3fbe1dba9c  sub rsp, 0x08
00007a3fbe1dbaa0  push rax
00007a3fbe1dbaa1  push rcx
00007a3fbe1dbaa2  push rdx
00007a3fbe1dbaa3  push rdi
00007a3fbe1dbaa4  push rsi
00007a3fbe1dbaa5  push r8
00007a3fbe1dbaa7  push r9
00007a3fbe1dbaa9  push r10
00007a3fbe1dbaab  push r11
00007a3fbe1dbaad  sub rsp, 0xF0
00007a3fbe1dbab4  vmovaps [rsp], xmm0
00007a3fbe1dbab9  vmovaps [rsp+0x10], xmm1
00007a3fbe1dbabf  vmovaps [rsp+0x20], xmm2
00007a3fbe1dbac5  vmovaps [rsp+0x30], xmm3
00007a3fbe1dbacb  vmovaps [rsp+0x40], xmm4
00007a3fbe1dbad1  vmovaps [rsp+0x50], xmm5
00007a3fbe1dbad7  vmovaps [rsp+0x60], xmm6
00007a3fbe1dbadd  vmovaps [rsp+0x70], xmm7
00007a3fbe1dbae3  vmovaps [rsp+0x80], xmm8
00007a3fbe1dbaec  vmovaps [rsp+0x90], xmm9
00007a3fbe1dbaf5  vmovaps [rsp+0xA0], xmm10
00007a3fbe1dbafe  vmovaps [rsp+0xB0], xmm11
00007a3fbe1dbb07  vmovaps [rsp+0xC0], xmm12
00007a3fbe1dbb10  vmovaps [rsp+0xD0], xmm13
00007a3fbe1dbb19  vmovaps [rsp+0xE0], xmm14
00007a3fbe1dbb22  sub rsp, 0x30
00007a3fbe1dbb26  movaps [rsp], xmm15
00007a3fbe1dbb2b  movaps [rsp+0x10], xmm14
00007a3fbe1dbb31  movaps [rsp+0x20], xmm4
00007a3fbe1dbb36  lea rdi, [rsp]
00007a3fbe1dbb3a  mov esi, 0x00
00007a3fbe1dbb3f  mov rax, 0x60D1084DB530
00007a3fbe1dbb49  call rax
00007a3fbe1dbb4b  movaps xmm15, [rsp]
00007a3fbe1dbb50  add rsp, 0x30
00007a3fbe1dbb54  vmovaps xmm0, [rsp]
00007a3fbe1dbb59  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dbb5f  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dbb65  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dbb6b  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dbb71  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dbb77  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dbb7d  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dbb83  vmovaps xmm8, [rsp+0x80]
00007a3fbe1dbb8c  vmovaps xmm9, [rsp+0x90]
00007a3fbe1dbb95  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1dbb9e  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1dbba7  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1dbbb0  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1dbbb9  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1dbbc2  add rsp, 0xF0
00007a3fbe1dbbc9  pop r11
00007a3fbe1dbbcb  pop r10
00007a3fbe1dbbcd  pop r9
00007a3fbe1dbbcf  pop r8
00007a3fbe1dbbd1  pop rsi
00007a3fbe1dbbd2  pop rdi
00007a3fbe1dbbd3  pop rdx
00007a3fbe1dbbd4  pop rcx
00007a3fbe1dbbd5  pop rax
00007a3fbe1dbbd6  add rsp, 0x08
00007a3fbe1dbbda  jmp 0x00007A3FBE1D92D7
00007a3fbe1dbbdf  sub rsp, 0x08
00007a3fbe1dbbe3  push rax
00007a3fbe1dbbe4  push rcx
00007a3fbe1dbbe5  push rdx
00007a3fbe1dbbe6  push rdi
00007a3fbe1dbbe7  push rsi
00007a3fbe1dbbe8  push r8
00007a3fbe1dbbea  push r9
00007a3fbe1dbbec  push r10
00007a3fbe1dbbee  push r11
00007a3fbe1dbbf0  sub rsp, 0xF0
00007a3fbe1dbbf7  vmovaps [rsp], xmm0
00007a3fbe1dbbfc  vmovaps [rsp+0x10], xmm1
00007a3fbe1dbc02  vmovaps [rsp+0x20], xmm2
00007a3fbe1dbc08  vmovaps [rsp+0x30], xmm3
00007a3fbe1dbc0e  vmovaps [rsp+0x40], xmm4
00007a3fbe1dbc14  vmovaps [rsp+0x50], xmm5
00007a3fbe1dbc1a  vmovaps [rsp+0x60], xmm6
00007a3fbe1dbc20  vmovaps [rsp+0x70], xmm7
00007a3fbe1dbc26  vmovaps [rsp+0x80], xmm8
00007a3fbe1dbc2f  vmovaps [rsp+0x90], xmm9
00007a3fbe1dbc38  vmovaps [rsp+0xA0], xmm10
00007a3fbe1dbc41  vmovaps [rsp+0xB0], xmm11
00007a3fbe1dbc4a  vmovaps [rsp+0xC0], xmm12
00007a3fbe1dbc53  vmovaps [rsp+0xD0], xmm13
00007a3fbe1dbc5c  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dbc65  sub rsp, 0x30
00007a3fbe1dbc69  movaps [rsp], xmm14
00007a3fbe1dbc6e  movaps [rsp+0x10], xmm2
00007a3fbe1dbc73  movaps [rsp+0x20], xmm1
00007a3fbe1dbc78  lea rdi, [rsp]
00007a3fbe1dbc7c  mov esi, 0x00
00007a3fbe1dbc81  mov rax, 0x60D1084DB530
00007a3fbe1dbc8b  call rax
00007a3fbe1dbc8d  movaps xmm14, [rsp]
00007a3fbe1dbc92  add rsp, 0x30
00007a3fbe1dbc96  vmovaps xmm0, [rsp]
00007a3fbe1dbc9b  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dbca1  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dbca7  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dbcad  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dbcb3  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dbcb9  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dbcbf  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dbcc5  vmovaps xmm8, [rsp+0x80]
00007a3fbe1dbcce  vmovaps xmm9, [rsp+0x90]
00007a3fbe1dbcd7  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1dbce0  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1dbce9  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1dbcf2  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1dbcfb  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dbd04  add rsp, 0xF0
00007a3fbe1dbd0b  pop r11
00007a3fbe1dbd0d  pop r10
00007a3fbe1dbd0f  pop r9
00007a3fbe1dbd11  pop r8
00007a3fbe1dbd13  pop rsi
00007a3fbe1dbd14  pop rdi
00007a3fbe1dbd15  pop rdx
00007a3fbe1dbd16  pop rcx
00007a3fbe1dbd17  pop rax
00007a3fbe1dbd18  add rsp, 0x08
00007a3fbe1dbd1c  jmp 0x00007A3FBE1D92FD
00007a3fbe1dbd21  sub rsp, 0x08
00007a3fbe1dbd25  push rax
00007a3fbe1dbd26  push rcx
00007a3fbe1dbd27  push rdx
00007a3fbe1dbd28  push rdi
00007a3fbe1dbd29  push rsi
00007a3fbe1dbd2a  push r8
00007a3fbe1dbd2c  push r9
00007a3fbe1dbd2e  push r10
00007a3fbe1dbd30  push r11
00007a3fbe1dbd32  sub rsp, 0xF0
00007a3fbe1dbd39  vmovaps [rsp], xmm0
00007a3fbe1dbd3e  vmovaps [rsp+0x10], xmm2
00007a3fbe1dbd44  vmovaps [rsp+0x20], xmm3
00007a3fbe1dbd4a  vmovaps [rsp+0x30], xmm4
00007a3fbe1dbd50  vmovaps [rsp+0x40], xmm5
00007a3fbe1dbd56  vmovaps [rsp+0x50], xmm6
00007a3fbe1dbd5c  vmovaps [rsp+0x60], xmm7
00007a3fbe1dbd62  vmovaps [rsp+0x70], xmm8
00007a3fbe1dbd68  vmovaps [rsp+0x80], xmm9
00007a3fbe1dbd71  vmovaps [rsp+0x90], xmm10
00007a3fbe1dbd7a  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dbd83  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dbd8c  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dbd95  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dbd9e  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dbda7  sub rsp, 0x30
00007a3fbe1dbdab  movaps [rsp], xmm1
00007a3fbe1dbdaf  movaps [rsp+0x10], xmm4
00007a3fbe1dbdb4  movaps [rsp+0x20], xmm9
00007a3fbe1dbdba  lea rdi, [rsp]
00007a3fbe1dbdbe  mov esi, 0x00
00007a3fbe1dbdc3  mov rax, 0x60D1084DB530
00007a3fbe1dbdcd  call rax
00007a3fbe1dbdcf  movaps xmm1, [rsp]
00007a3fbe1dbdd3  add rsp, 0x30
00007a3fbe1dbdd7  vmovaps xmm0, [rsp]
00007a3fbe1dbddc  vmovaps xmm2, [rsp+0x10]
00007a3fbe1dbde2  vmovaps xmm3, [rsp+0x20]
00007a3fbe1dbde8  vmovaps xmm4, [rsp+0x30]
00007a3fbe1dbdee  vmovaps xmm5, [rsp+0x40]
00007a3fbe1dbdf4  vmovaps xmm6, [rsp+0x50]
00007a3fbe1dbdfa  vmovaps xmm7, [rsp+0x60]
00007a3fbe1dbe00  vmovaps xmm8, [rsp+0x70]
00007a3fbe1dbe06  vmovaps xmm9, [rsp+0x80]
00007a3fbe1dbe0f  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dbe18  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dbe21  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dbe2a  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dbe33  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dbe3c  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dbe45  add rsp, 0xF0
00007a3fbe1dbe4c  pop r11
00007a3fbe1dbe4e  pop r10
00007a3fbe1dbe50  pop r9
00007a3fbe1dbe52  pop r8
00007a3fbe1dbe54  pop rsi
00007a3fbe1dbe55  pop rdi
00007a3fbe1dbe56  pop rdx
00007a3fbe1dbe57  pop rcx
00007a3fbe1dbe58  pop rax
00007a3fbe1dbe59  add rsp, 0x08
00007a3fbe1dbe5d  jmp 0x00007A3FBE1D931B
00007a3fbe1dbe62  sub rsp, 0x08
00007a3fbe1dbe66  push rax
00007a3fbe1dbe67  push rcx
00007a3fbe1dbe68  push rdx
00007a3fbe1dbe69  push rdi
00007a3fbe1dbe6a  push rsi
00007a3fbe1dbe6b  push r8
00007a3fbe1dbe6d  push r9
00007a3fbe1dbe6f  push r10
00007a3fbe1dbe71  push r11
00007a3fbe1dbe73  sub rsp, 0xF0
00007a3fbe1dbe7a  vmovaps [rsp], xmm0
00007a3fbe1dbe7f  vmovaps [rsp+0x10], xmm1
00007a3fbe1dbe85  vmovaps [rsp+0x20], xmm2
00007a3fbe1dbe8b  vmovaps [rsp+0x30], xmm3
00007a3fbe1dbe91  vmovaps [rsp+0x40], xmm5
00007a3fbe1dbe97  vmovaps [rsp+0x50], xmm6
00007a3fbe1dbe9d  vmovaps [rsp+0x60], xmm7
00007a3fbe1dbea3  vmovaps [rsp+0x70], xmm8
00007a3fbe1dbea9  vmovaps [rsp+0x80], xmm9
00007a3fbe1dbeb2  vmovaps [rsp+0x90], xmm10
00007a3fbe1dbebb  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dbec4  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dbecd  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dbed6  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dbedf  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dbee8  sub rsp, 0x30
00007a3fbe1dbeec  movaps [rsp], xmm4
00007a3fbe1dbef0  movaps [rsp+0x10], xmm2
00007a3fbe1dbef5  movaps [rsp+0x20], xmm9
00007a3fbe1dbefb  lea rdi, [rsp]
00007a3fbe1dbeff  mov esi, 0x00
00007a3fbe1dbf04  mov rax, 0x60D1084DB530
00007a3fbe1dbf0e  call rax
00007a3fbe1dbf10  movaps xmm4, [rsp]
00007a3fbe1dbf14  add rsp, 0x30
00007a3fbe1dbf18  vmovaps xmm0, [rsp]
00007a3fbe1dbf1d  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dbf23  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dbf29  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dbf2f  vmovaps xmm5, [rsp+0x40]
00007a3fbe1dbf35  vmovaps xmm6, [rsp+0x50]
00007a3fbe1dbf3b  vmovaps xmm7, [rsp+0x60]
00007a3fbe1dbf41  vmovaps xmm8, [rsp+0x70]
00007a3fbe1dbf47  vmovaps xmm9, [rsp+0x80]
00007a3fbe1dbf50  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dbf59  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dbf62  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dbf6b  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dbf74  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dbf7d  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dbf86  add rsp, 0xF0
00007a3fbe1dbf8d  pop r11
00007a3fbe1dbf8f  pop r10
00007a3fbe1dbf91  pop r9
00007a3fbe1dbf93  pop r8
00007a3fbe1dbf95  pop rsi
00007a3fbe1dbf96  pop rdi
00007a3fbe1dbf97  pop rdx
00007a3fbe1dbf98  pop rcx
00007a3fbe1dbf99  pop rax
00007a3fbe1dbf9a  add rsp, 0x08
00007a3fbe1dbf9e  jmp 0x00007A3FBE1D934B
00007a3fbe1dbfa3  sub rsp, 0x08
00007a3fbe1dbfa7  push rax
00007a3fbe1dbfa8  push rcx
00007a3fbe1dbfa9  push rdx
00007a3fbe1dbfaa  push rdi
00007a3fbe1dbfab  push rsi
00007a3fbe1dbfac  push r8
00007a3fbe1dbfae  push r9
00007a3fbe1dbfb0  push r10
00007a3fbe1dbfb2  push r11
00007a3fbe1dbfb4  sub rsp, 0xF0
00007a3fbe1dbfbb  vmovaps [rsp], xmm0
00007a3fbe1dbfc0  vmovaps [rsp+0x10], xmm1
00007a3fbe1dbfc6  vmovaps [rsp+0x20], xmm2
00007a3fbe1dbfcc  vmovaps [rsp+0x30], xmm3
00007a3fbe1dbfd2  vmovaps [rsp+0x40], xmm4
00007a3fbe1dbfd8  vmovaps [rsp+0x50], xmm5
00007a3fbe1dbfde  vmovaps [rsp+0x60], xmm6
00007a3fbe1dbfe4  vmovaps [rsp+0x70], xmm7
00007a3fbe1dbfea  vmovaps [rsp+0x80], xmm8
00007a3fbe1dbff3  vmovaps [rsp+0x90], xmm10
00007a3fbe1dbffc  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dc005  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dc00e  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dc017  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dc020  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dc029  sub rsp, 0x30
00007a3fbe1dc02d  movaps [rsp], xmm9
00007a3fbe1dc032  movaps [rsp+0x10], xmm2
00007a3fbe1dc037  movaps [rsp+0x20], xmm1
00007a3fbe1dc03c  lea rdi, [rsp]
00007a3fbe1dc040  mov esi, 0x00
00007a3fbe1dc045  mov rax, 0x60D1084DB530
00007a3fbe1dc04f  call rax
00007a3fbe1dc051  movaps xmm9, [rsp]
00007a3fbe1dc056  add rsp, 0x30
00007a3fbe1dc05a  vmovaps xmm0, [rsp]
00007a3fbe1dc05f  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dc065  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dc06b  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dc071  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dc077  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dc07d  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dc083  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dc089  vmovaps xmm8, [rsp+0x80]
00007a3fbe1dc092  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dc09b  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dc0a4  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dc0ad  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dc0b6  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dc0bf  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dc0c8  add rsp, 0xF0
00007a3fbe1dc0cf  pop r11
00007a3fbe1dc0d1  pop r10
00007a3fbe1dc0d3  pop r9
00007a3fbe1dc0d5  pop r8
00007a3fbe1dc0d7  pop rsi
00007a3fbe1dc0d8  pop rdi
00007a3fbe1dc0d9  pop rdx
00007a3fbe1dc0da  pop rcx
00007a3fbe1dc0db  pop rax
00007a3fbe1dc0dc  add rsp, 0x08
00007a3fbe1dc0e0  jmp 0x00007A3FBE1D9381
00007a3fbe1dc0e5  sub rsp, 0x08
00007a3fbe1dc0e9  push rax
00007a3fbe1dc0ea  push rcx
00007a3fbe1dc0eb  push rdx
00007a3fbe1dc0ec  push rdi
00007a3fbe1dc0ed  push rsi
00007a3fbe1dc0ee  push r8
00007a3fbe1dc0f0  push r9
00007a3fbe1dc0f2  push r10
00007a3fbe1dc0f4  push r11
00007a3fbe1dc0f6  sub rsp, 0xF0
00007a3fbe1dc0fd  vmovaps [rsp], xmm0
00007a3fbe1dc102  vmovaps [rsp+0x10], xmm2
00007a3fbe1dc108  vmovaps [rsp+0x20], xmm3
00007a3fbe1dc10e  vmovaps [rsp+0x30], xmm4
00007a3fbe1dc114  vmovaps [rsp+0x40], xmm5
00007a3fbe1dc11a  vmovaps [rsp+0x50], xmm6
00007a3fbe1dc120  vmovaps [rsp+0x60], xmm7
00007a3fbe1dc126  vmovaps [rsp+0x70], xmm8
00007a3fbe1dc12c  vmovaps [rsp+0x80], xmm9
00007a3fbe1dc135  vmovaps [rsp+0x90], xmm10
00007a3fbe1dc13e  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dc147  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dc150  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dc159  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dc162  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dc16b  sub rsp, 0x30
00007a3fbe1dc16f  movaps [rsp], xmm1
00007a3fbe1dc173  movaps [rsp+0x10], xmm15
00007a3fbe1dc179  movaps [rsp+0x20], xmm6
00007a3fbe1dc17e  lea rdi, [rsp]
00007a3fbe1dc182  mov esi, 0x00
00007a3fbe1dc187  mov rax, 0x60D1084DB530
00007a3fbe1dc191  call rax
00007a3fbe1dc193  movaps xmm1, [rsp]
00007a3fbe1dc197  add rsp, 0x30
00007a3fbe1dc19b  vmovaps xmm0, [rsp]
00007a3fbe1dc1a0  vmovaps xmm2, [rsp+0x10]
00007a3fbe1dc1a6  vmovaps xmm3, [rsp+0x20]
00007a3fbe1dc1ac  vmovaps xmm4, [rsp+0x30]
00007a3fbe1dc1b2  vmovaps xmm5, [rsp+0x40]
00007a3fbe1dc1b8  vmovaps xmm6, [rsp+0x50]
00007a3fbe1dc1be  vmovaps xmm7, [rsp+0x60]
00007a3fbe1dc1c4  vmovaps xmm8, [rsp+0x70]
00007a3fbe1dc1ca  vmovaps xmm9, [rsp+0x80]
00007a3fbe1dc1d3  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dc1dc  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dc1e5  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dc1ee  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dc1f7  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dc200  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dc209  add rsp, 0xF0
00007a3fbe1dc210  pop r11
00007a3fbe1dc212  pop r10
00007a3fbe1dc214  pop r9
00007a3fbe1dc216  pop r8
00007a3fbe1dc218  pop rsi
00007a3fbe1dc219  pop rdi
00007a3fbe1dc21a  pop rdx
00007a3fbe1dc21b  pop rcx
00007a3fbe1dc21c  pop rax
00007a3fbe1dc21d  add rsp, 0x08
00007a3fbe1dc221  jmp 0x00007A3FBE1D93A2
00007a3fbe1dc226  sub rsp, 0x08
00007a3fbe1dc22a  push rax
00007a3fbe1dc22b  push rcx
00007a3fbe1dc22c  push rdx
00007a3fbe1dc22d  push rdi
00007a3fbe1dc22e  push rsi
00007a3fbe1dc22f  push r8
00007a3fbe1dc231  push r9
00007a3fbe1dc233  push r10
00007a3fbe1dc235  push r11
00007a3fbe1dc237  sub rsp, 0xF0
00007a3fbe1dc23e  vmovaps [rsp], xmm0
00007a3fbe1dc243  vmovaps [rsp+0x10], xmm1
00007a3fbe1dc249  vmovaps [rsp+0x20], xmm2
00007a3fbe1dc24f  vmovaps [rsp+0x30], xmm3
00007a3fbe1dc255  vmovaps [rsp+0x40], xmm4
00007a3fbe1dc25b  vmovaps [rsp+0x50], xmm5
00007a3fbe1dc261  vmovaps [rsp+0x60], xmm6
00007a3fbe1dc267  vmovaps [rsp+0x70], xmm7
00007a3fbe1dc26d  vmovaps [rsp+0x80], xmm8
00007a3fbe1dc276  vmovaps [rsp+0x90], xmm9
00007a3fbe1dc27f  vmovaps [rsp+0xA0], xmm10
00007a3fbe1dc288  vmovaps [rsp+0xB0], xmm11
00007a3fbe1dc291  vmovaps [rsp+0xC0], xmm12
00007a3fbe1dc29a  vmovaps [rsp+0xD0], xmm13
00007a3fbe1dc2a3  vmovaps [rsp+0xE0], xmm14
00007a3fbe1dc2ac  sub rsp, 0x30
00007a3fbe1dc2b0  movaps [rsp], xmm15
00007a3fbe1dc2b5  movaps [rsp+0x10], xmm5
00007a3fbe1dc2ba  movaps [rsp+0x20], xmm3
00007a3fbe1dc2bf  lea rdi, [rsp]
00007a3fbe1dc2c3  mov esi, 0x00
00007a3fbe1dc2c8  mov rax, 0x60D1084DB530
00007a3fbe1dc2d2  call rax
00007a3fbe1dc2d4  movaps xmm15, [rsp]
00007a3fbe1dc2d9  add rsp, 0x30
00007a3fbe1dc2dd  vmovaps xmm0, [rsp]
00007a3fbe1dc2e2  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dc2e8  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dc2ee  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dc2f4  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dc2fa  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dc300  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dc306  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dc30c  vmovaps xmm8, [rsp+0x80]
00007a3fbe1dc315  vmovaps xmm9, [rsp+0x90]
00007a3fbe1dc31e  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1dc327  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1dc330  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1dc339  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1dc342  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1dc34b  add rsp, 0xF0
00007a3fbe1dc352  pop r11
00007a3fbe1dc354  pop r10
00007a3fbe1dc356  pop r9
00007a3fbe1dc358  pop r8
00007a3fbe1dc35a  pop rsi
00007a3fbe1dc35b  pop rdi
00007a3fbe1dc35c  pop rdx
00007a3fbe1dc35d  pop rcx
00007a3fbe1dc35e  pop rax
00007a3fbe1dc35f  add rsp, 0x08
00007a3fbe1dc363  jmp 0x00007A3FBE1D93BC
00007a3fbe1dc368  sub rsp, 0x08
00007a3fbe1dc36c  push rax
00007a3fbe1dc36d  push rcx
00007a3fbe1dc36e  push rdx
00007a3fbe1dc36f  push rdi
00007a3fbe1dc370  push rsi
00007a3fbe1dc371  push r8
00007a3fbe1dc373  push r9
00007a3fbe1dc375  push r10
00007a3fbe1dc377  push r11
00007a3fbe1dc379  sub rsp, 0xF0
00007a3fbe1dc380  vmovaps [rsp], xmm0
00007a3fbe1dc385  vmovaps [rsp+0x10], xmm1
00007a3fbe1dc38b  vmovaps [rsp+0x20], xmm2
00007a3fbe1dc391  vmovaps [rsp+0x30], xmm3
00007a3fbe1dc397  vmovaps [rsp+0x40], xmm4
00007a3fbe1dc39d  vmovaps [rsp+0x50], xmm6
00007a3fbe1dc3a3  vmovaps [rsp+0x60], xmm7
00007a3fbe1dc3a9  vmovaps [rsp+0x70], xmm8
00007a3fbe1dc3af  vmovaps [rsp+0x80], xmm9
00007a3fbe1dc3b8  vmovaps [rsp+0x90], xmm10
00007a3fbe1dc3c1  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dc3ca  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dc3d3  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dc3dc  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dc3e5  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dc3ee  sub rsp, 0x30
00007a3fbe1dc3f2  movaps [rsp], xmm5
00007a3fbe1dc3f6  movaps [rsp+0x10], xmm8
00007a3fbe1dc3fc  movaps [rsp+0x20], xmm6
00007a3fbe1dc401  lea rdi, [rsp]
00007a3fbe1dc405  mov esi, 0x00
00007a3fbe1dc40a  mov rax, 0x60D1084DB530
00007a3fbe1dc414  call rax
00007a3fbe1dc416  movaps xmm5, [rsp]
00007a3fbe1dc41a  add rsp, 0x30
00007a3fbe1dc41e  vmovaps xmm0, [rsp]
00007a3fbe1dc423  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dc429  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dc42f  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dc435  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dc43b  vmovaps xmm6, [rsp+0x50]
00007a3fbe1dc441  vmovaps xmm7, [rsp+0x60]
00007a3fbe1dc447  vmovaps xmm8, [rsp+0x70]
00007a3fbe1dc44d  vmovaps xmm9, [rsp+0x80]
00007a3fbe1dc456  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dc45f  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dc468  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dc471  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dc47a  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dc483  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dc48c  add rsp, 0xF0
00007a3fbe1dc493  pop r11
00007a3fbe1dc495  pop r10
00007a3fbe1dc497  pop r9
00007a3fbe1dc499  pop r8
00007a3fbe1dc49b  pop rsi
00007a3fbe1dc49c  pop rdi
00007a3fbe1dc49d  pop rdx
00007a3fbe1dc49e  pop rcx
00007a3fbe1dc49f  pop rax
00007a3fbe1dc4a0  add rsp, 0x08
00007a3fbe1dc4a4  jmp 0x00007A3FBE1D93E0
00007a3fbe1dc4a9  sub rsp, 0x08
00007a3fbe1dc4ad  push rax
00007a3fbe1dc4ae  push rcx
00007a3fbe1dc4af  push rdx
00007a3fbe1dc4b0  push rdi
00007a3fbe1dc4b1  push rsi
00007a3fbe1dc4b2  push r8
00007a3fbe1dc4b4  push r9
00007a3fbe1dc4b6  push r10
00007a3fbe1dc4b8  push r11
00007a3fbe1dc4ba  sub rsp, 0xF0
00007a3fbe1dc4c1  vmovaps [rsp], xmm0
00007a3fbe1dc4c6  vmovaps [rsp+0x10], xmm1
00007a3fbe1dc4cc  vmovaps [rsp+0x20], xmm2
00007a3fbe1dc4d2  vmovaps [rsp+0x30], xmm3
00007a3fbe1dc4d8  vmovaps [rsp+0x40], xmm4
00007a3fbe1dc4de  vmovaps [rsp+0x50], xmm5
00007a3fbe1dc4e4  vmovaps [rsp+0x60], xmm7
00007a3fbe1dc4ea  vmovaps [rsp+0x70], xmm8
00007a3fbe1dc4f0  vmovaps [rsp+0x80], xmm9
00007a3fbe1dc4f9  vmovaps [rsp+0x90], xmm10
00007a3fbe1dc502  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dc50b  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dc514  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dc51d  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dc526  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dc52f  sub rsp, 0x30
00007a3fbe1dc533  movaps [rsp], xmm6
00007a3fbe1dc537  movaps [rsp+0x10], xmm10
00007a3fbe1dc53d  movaps [rsp+0x20], xmm8
00007a3fbe1dc543  lea rdi, [rsp]
00007a3fbe1dc547  mov esi, 0x00
00007a3fbe1dc54c  mov rax, 0x60D1084DB530
00007a3fbe1dc556  call rax
00007a3fbe1dc558  movaps xmm6, [rsp]
00007a3fbe1dc55c  add rsp, 0x30
00007a3fbe1dc560  vmovaps xmm0, [rsp]
00007a3fbe1dc565  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dc56b  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dc571  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dc577  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dc57d  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dc583  vmovaps xmm7, [rsp+0x60]
00007a3fbe1dc589  vmovaps xmm8, [rsp+0x70]
00007a3fbe1dc58f  vmovaps xmm9, [rsp+0x80]
00007a3fbe1dc598  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dc5a1  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dc5aa  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dc5b3  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dc5bc  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dc5c5  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dc5ce  add rsp, 0xF0
00007a3fbe1dc5d5  pop r11
00007a3fbe1dc5d7  pop r10
00007a3fbe1dc5d9  pop r9
00007a3fbe1dc5db  pop r8
00007a3fbe1dc5dd  pop rsi
00007a3fbe1dc5de  pop rdi
00007a3fbe1dc5df  pop rdx
00007a3fbe1dc5e0  pop rcx
00007a3fbe1dc5e1  pop rax
00007a3fbe1dc5e2  add rsp, 0x08
00007a3fbe1dc5e6  jmp 0x00007A3FBE1D9405
00007a3fbe1dc5eb  sub rsp, 0x08
00007a3fbe1dc5ef  push rax
00007a3fbe1dc5f0  push rcx
00007a3fbe1dc5f1  push rdx
00007a3fbe1dc5f2  push rdi
00007a3fbe1dc5f3  push rsi
00007a3fbe1dc5f4  push r8
00007a3fbe1dc5f6  push r9
00007a3fbe1dc5f8  push r10
00007a3fbe1dc5fa  push r11
00007a3fbe1dc5fc  sub rsp, 0xF0
00007a3fbe1dc603  vmovaps [rsp], xmm0
00007a3fbe1dc608  vmovaps [rsp+0x10], xmm1
00007a3fbe1dc60e  vmovaps [rsp+0x20], xmm2
00007a3fbe1dc614  vmovaps [rsp+0x30], xmm3
00007a3fbe1dc61a  vmovaps [rsp+0x40], xmm4
00007a3fbe1dc620  vmovaps [rsp+0x50], xmm5
00007a3fbe1dc626  vmovaps [rsp+0x60], xmm6
00007a3fbe1dc62c  vmovaps [rsp+0x70], xmm7
00007a3fbe1dc632  vmovaps [rsp+0x80], xmm8
00007a3fbe1dc63b  vmovaps [rsp+0x90], xmm9
00007a3fbe1dc644  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dc64d  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dc656  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dc65f  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dc668  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dc671  sub rsp, 0x30
00007a3fbe1dc675  movaps [rsp], xmm10
00007a3fbe1dc67a  movaps [rsp+0x10], xmm8
00007a3fbe1dc680  movaps [rsp+0x20], xmm14
00007a3fbe1dc686  lea rdi, [rsp]
00007a3fbe1dc68a  mov esi, 0x00
00007a3fbe1dc68f  mov rax, 0x60D1084DB530
00007a3fbe1dc699  call rax
00007a3fbe1dc69b  movaps xmm10, [rsp]
00007a3fbe1dc6a0  add rsp, 0x30
00007a3fbe1dc6a4  vmovaps xmm0, [rsp]
00007a3fbe1dc6a9  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dc6af  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dc6b5  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dc6bb  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dc6c1  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dc6c7  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dc6cd  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dc6d3  vmovaps xmm8, [rsp+0x80]
00007a3fbe1dc6dc  vmovaps xmm9, [rsp+0x90]
00007a3fbe1dc6e5  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dc6ee  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dc6f7  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dc700  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dc709  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dc712  add rsp, 0xF0
00007a3fbe1dc719  pop r11
00007a3fbe1dc71b  pop r10
00007a3fbe1dc71d  pop r9
00007a3fbe1dc71f  pop r8
00007a3fbe1dc721  pop rsi
00007a3fbe1dc722  pop rdi
00007a3fbe1dc723  pop rdx
00007a3fbe1dc724  pop rcx
00007a3fbe1dc725  pop rax
00007a3fbe1dc726  add rsp, 0x08
00007a3fbe1dc72a  jmp 0x00007A3FBE1D9425
00007a3fbe1dc72f  sub rsp, 0x08
00007a3fbe1dc733  push rax
00007a3fbe1dc734  push rcx
00007a3fbe1dc735  push rdx
00007a3fbe1dc736  push rdi
00007a3fbe1dc737  push rsi
00007a3fbe1dc738  push r8
00007a3fbe1dc73a  push r9
00007a3fbe1dc73c  push r10
00007a3fbe1dc73e  push r11
00007a3fbe1dc740  sub rsp, 0xF0
00007a3fbe1dc747  vmovaps [rsp], xmm0
00007a3fbe1dc74c  vmovaps [rsp+0x10], xmm1
00007a3fbe1dc752  vmovaps [rsp+0x20], xmm2
00007a3fbe1dc758  vmovaps [rsp+0x30], xmm3
00007a3fbe1dc75e  vmovaps [rsp+0x40], xmm4
00007a3fbe1dc764  vmovaps [rsp+0x50], xmm5
00007a3fbe1dc76a  vmovaps [rsp+0x60], xmm6
00007a3fbe1dc770  vmovaps [rsp+0x70], xmm7
00007a3fbe1dc776  vmovaps [rsp+0x80], xmm8
00007a3fbe1dc77f  vmovaps [rsp+0x90], xmm9
00007a3fbe1dc788  vmovaps [rsp+0xA0], xmm10
00007a3fbe1dc791  vmovaps [rsp+0xB0], xmm11
00007a3fbe1dc79a  vmovaps [rsp+0xC0], xmm12
00007a3fbe1dc7a3  vmovaps [rsp+0xD0], xmm13
00007a3fbe1dc7ac  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dc7b5  sub rsp, 0x30
00007a3fbe1dc7b9  movaps [rsp], xmm14
00007a3fbe1dc7be  movaps [rsp+0x10], xmm8
00007a3fbe1dc7c4  movaps [rsp+0x20], xmm4
00007a3fbe1dc7c9  lea rdi, [rsp]
00007a3fbe1dc7cd  mov esi, 0x00
00007a3fbe1dc7d2  mov rax, 0x60D1084DB530
00007a3fbe1dc7dc  call rax
00007a3fbe1dc7de  movaps xmm14, [rsp]
00007a3fbe1dc7e3  add rsp, 0x30
00007a3fbe1dc7e7  vmovaps xmm0, [rsp]
00007a3fbe1dc7ec  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dc7f2  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dc7f8  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dc7fe  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dc804  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dc80a  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dc810  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dc816  vmovaps xmm8, [rsp+0x80]
00007a3fbe1dc81f  vmovaps xmm9, [rsp+0x90]
00007a3fbe1dc828  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1dc831  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1dc83a  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1dc843  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1dc84c  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dc855  add rsp, 0xF0
00007a3fbe1dc85c  pop r11
00007a3fbe1dc85e  pop r10
00007a3fbe1dc860  pop r9
00007a3fbe1dc862  pop r8
00007a3fbe1dc864  pop rsi
00007a3fbe1dc865  pop rdi
00007a3fbe1dc866  pop rdx
00007a3fbe1dc867  pop rcx
00007a3fbe1dc868  pop rax
00007a3fbe1dc869  add rsp, 0x08
00007a3fbe1dc86d  jmp 0x00007A3FBE1D9445
00007a3fbe1dc872  sub rsp, 0x08
00007a3fbe1dc876  push rax
00007a3fbe1dc877  push rcx
00007a3fbe1dc878  push rdx
00007a3fbe1dc879  push rdi
00007a3fbe1dc87a  push rsi
00007a3fbe1dc87b  push r8
00007a3fbe1dc87d  push r9
00007a3fbe1dc87f  push r10
00007a3fbe1dc881  push r11
00007a3fbe1dc883  sub rsp, 0xF0
00007a3fbe1dc88a  vmovaps [rsp], xmm0
00007a3fbe1dc88f  vmovaps [rsp+0x10], xmm1
00007a3fbe1dc895  vmovaps [rsp+0x20], xmm2
00007a3fbe1dc89b  vmovaps [rsp+0x30], xmm3
00007a3fbe1dc8a1  vmovaps [rsp+0x40], xmm5
00007a3fbe1dc8a7  vmovaps [rsp+0x50], xmm6
00007a3fbe1dc8ad  vmovaps [rsp+0x60], xmm7
00007a3fbe1dc8b3  vmovaps [rsp+0x70], xmm8
00007a3fbe1dc8b9  vmovaps [rsp+0x80], xmm9
00007a3fbe1dc8c2  vmovaps [rsp+0x90], xmm10
00007a3fbe1dc8cb  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dc8d4  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dc8dd  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dc8e6  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dc8ef  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dc8f8  sub rsp, 0x30
00007a3fbe1dc8fc  movaps [rsp], xmm4
00007a3fbe1dc900  movaps [rsp+0x10], xmm13
00007a3fbe1dc906  movaps [rsp+0x20], xmm8
00007a3fbe1dc90c  lea rdi, [rsp]
00007a3fbe1dc910  mov esi, 0x00
00007a3fbe1dc915  mov rax, 0x60D1084DB530
00007a3fbe1dc91f  call rax
00007a3fbe1dc921  movaps xmm4, [rsp]
00007a3fbe1dc925  add rsp, 0x30
00007a3fbe1dc929  vmovaps xmm0, [rsp]
00007a3fbe1dc92e  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dc934  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dc93a  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dc940  vmovaps xmm5, [rsp+0x40]
00007a3fbe1dc946  vmovaps xmm6, [rsp+0x50]
00007a3fbe1dc94c  vmovaps xmm7, [rsp+0x60]
00007a3fbe1dc952  vmovaps xmm8, [rsp+0x70]
00007a3fbe1dc958  vmovaps xmm9, [rsp+0x80]
00007a3fbe1dc961  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dc96a  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dc973  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dc97c  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dc985  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dc98e  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dc997  add rsp, 0xF0
00007a3fbe1dc99e  pop r11
00007a3fbe1dc9a0  pop r10
00007a3fbe1dc9a2  pop r9
00007a3fbe1dc9a4  pop r8
00007a3fbe1dc9a6  pop rsi
00007a3fbe1dc9a7  pop rdi
00007a3fbe1dc9a8  pop rdx
00007a3fbe1dc9a9  pop rcx
00007a3fbe1dc9aa  pop rax
00007a3fbe1dc9ab  add rsp, 0x08
00007a3fbe1dc9af  jmp 0x00007A3FBE1D946A
00007a3fbe1dc9b4  sub rsp, 0x08
00007a3fbe1dc9b8  push rax
00007a3fbe1dc9b9  push rcx
00007a3fbe1dc9ba  push rdx
00007a3fbe1dc9bb  push rdi
00007a3fbe1dc9bc  push rsi
00007a3fbe1dc9bd  push r8
00007a3fbe1dc9bf  push r9
00007a3fbe1dc9c1  push r10
00007a3fbe1dc9c3  push r11
00007a3fbe1dc9c5  sub rsp, 0xF0
00007a3fbe1dc9cc  vmovaps [rsp], xmm0
00007a3fbe1dc9d1  vmovaps [rsp+0x10], xmm1
00007a3fbe1dc9d7  vmovaps [rsp+0x20], xmm2
00007a3fbe1dc9dd  vmovaps [rsp+0x30], xmm3
00007a3fbe1dc9e3  vmovaps [rsp+0x40], xmm4
00007a3fbe1dc9e9  vmovaps [rsp+0x50], xmm5
00007a3fbe1dc9ef  vmovaps [rsp+0x60], xmm6
00007a3fbe1dc9f5  vmovaps [rsp+0x70], xmm7
00007a3fbe1dc9fb  vmovaps [rsp+0x80], xmm8
00007a3fbe1dca04  vmovaps [rsp+0x90], xmm9
00007a3fbe1dca0d  vmovaps [rsp+0xA0], xmm10
00007a3fbe1dca16  vmovaps [rsp+0xB0], xmm11
00007a3fbe1dca1f  vmovaps [rsp+0xC0], xmm12
00007a3fbe1dca28  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dca31  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dca3a  sub rsp, 0x30
00007a3fbe1dca3e  movaps [rsp], xmm13
00007a3fbe1dca43  movaps [rsp+0x10], xmm15
00007a3fbe1dca49  movaps [rsp+0x20], xmm9
00007a3fbe1dca4f  lea rdi, [rsp]
00007a3fbe1dca53  mov esi, 0x00
00007a3fbe1dca58  mov rax, 0x60D1084DB530
00007a3fbe1dca62  call rax
00007a3fbe1dca64  movaps xmm13, [rsp]
00007a3fbe1dca69  add rsp, 0x30
00007a3fbe1dca6d  vmovaps xmm0, [rsp]
00007a3fbe1dca72  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dca78  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dca7e  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dca84  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dca8a  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dca90  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dca96  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dca9c  vmovaps xmm8, [rsp+0x80]
00007a3fbe1dcaa5  vmovaps xmm9, [rsp+0x90]
00007a3fbe1dcaae  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1dcab7  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1dcac0  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1dcac9  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dcad2  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dcadb  add rsp, 0xF0
00007a3fbe1dcae2  pop r11
00007a3fbe1dcae4  pop r10
00007a3fbe1dcae6  pop r9
00007a3fbe1dcae8  pop r8
00007a3fbe1dcaea  pop rsi
00007a3fbe1dcaeb  pop rdi
00007a3fbe1dcaec  pop rdx
00007a3fbe1dcaed  pop rcx
00007a3fbe1dcaee  pop rax
00007a3fbe1dcaef  add rsp, 0x08
00007a3fbe1dcaf3  jmp 0x00007A3FBE1D9485
00007a3fbe1dcaf8  sub rsp, 0x08
00007a3fbe1dcafc  push rax
00007a3fbe1dcafd  push rcx
00007a3fbe1dcafe  push rdx
00007a3fbe1dcaff  push rdi
00007a3fbe1dcb00  push rsi
00007a3fbe1dcb01  push r8
00007a3fbe1dcb03  push r9
00007a3fbe1dcb05  push r10
00007a3fbe1dcb07  push r11
00007a3fbe1dcb09  sub rsp, 0xF0
00007a3fbe1dcb10  vmovaps [rsp], xmm0
00007a3fbe1dcb15  vmovaps [rsp+0x10], xmm1
00007a3fbe1dcb1b  vmovaps [rsp+0x20], xmm2
00007a3fbe1dcb21  vmovaps [rsp+0x30], xmm3
00007a3fbe1dcb27  vmovaps [rsp+0x40], xmm4
00007a3fbe1dcb2d  vmovaps [rsp+0x50], xmm5
00007a3fbe1dcb33  vmovaps [rsp+0x60], xmm6
00007a3fbe1dcb39  vmovaps [rsp+0x70], xmm7
00007a3fbe1dcb3f  vmovaps [rsp+0x80], xmm8
00007a3fbe1dcb48  vmovaps [rsp+0x90], xmm9
00007a3fbe1dcb51  vmovaps [rsp+0xA0], xmm10
00007a3fbe1dcb5a  vmovaps [rsp+0xB0], xmm11
00007a3fbe1dcb63  vmovaps [rsp+0xC0], xmm12
00007a3fbe1dcb6c  vmovaps [rsp+0xD0], xmm13
00007a3fbe1dcb75  vmovaps [rsp+0xE0], xmm14
00007a3fbe1dcb7e  sub rsp, 0x30
00007a3fbe1dcb82  movaps [rsp], xmm15
00007a3fbe1dcb87  movaps [rsp+0x10], xmm1
00007a3fbe1dcb8c  movaps [rsp+0x20], xmm5
00007a3fbe1dcb91  lea rdi, [rsp]
00007a3fbe1dcb95  mov esi, 0x00
00007a3fbe1dcb9a  mov rax, 0x60D1084DB530
00007a3fbe1dcba4  call rax
00007a3fbe1dcba6  movaps xmm15, [rsp]
00007a3fbe1dcbab  add rsp, 0x30
00007a3fbe1dcbaf  vmovaps xmm0, [rsp]
00007a3fbe1dcbb4  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dcbba  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dcbc0  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dcbc6  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dcbcc  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dcbd2  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dcbd8  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dcbde  vmovaps xmm8, [rsp+0x80]
00007a3fbe1dcbe7  vmovaps xmm9, [rsp+0x90]
00007a3fbe1dcbf0  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1dcbf9  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1dcc02  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1dcc0b  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1dcc14  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1dcc1d  add rsp, 0xF0
00007a3fbe1dcc24  pop r11
00007a3fbe1dcc26  pop r10
00007a3fbe1dcc28  pop r9
00007a3fbe1dcc2a  pop r8
00007a3fbe1dcc2c  pop rsi
00007a3fbe1dcc2d  pop rdi
00007a3fbe1dcc2e  pop rdx
00007a3fbe1dcc2f  pop rcx
00007a3fbe1dcc30  pop rax
00007a3fbe1dcc31  add rsp, 0x08
00007a3fbe1dcc35  jmp 0x00007A3FBE1D94A0
00007a3fbe1dcc3a  call 0x00007A3FBE0D64F0
00007a3fbe1dcc3f  jmp 0x00007A3FBE1D94FB
00007a3fbe1dcc44  sub rsp, 0x08
00007a3fbe1dcc48  push rax
00007a3fbe1dcc49  push rcx
00007a3fbe1dcc4a  push rdx
00007a3fbe1dcc4b  push rdi
00007a3fbe1dcc4c  push rsi
00007a3fbe1dcc4d  push r8
00007a3fbe1dcc4f  push r9
00007a3fbe1dcc51  push r10
00007a3fbe1dcc53  push r11
00007a3fbe1dcc55  sub rsp, 0xF0
00007a3fbe1dcc5c  vmovaps [rsp], xmm0
00007a3fbe1dcc61  vmovaps [rsp+0x10], xmm1
00007a3fbe1dcc67  vmovaps [rsp+0x20], xmm2
00007a3fbe1dcc6d  vmovaps [rsp+0x30], xmm3
00007a3fbe1dcc73  vmovaps [rsp+0x40], xmm4
00007a3fbe1dcc79  vmovaps [rsp+0x50], xmm5
00007a3fbe1dcc7f  vmovaps [rsp+0x60], xmm6
00007a3fbe1dcc85  vmovaps [rsp+0x70], xmm7
00007a3fbe1dcc8b  vmovaps [rsp+0x80], xmm8
00007a3fbe1dcc94  vmovaps [rsp+0x90], xmm10
00007a3fbe1dcc9d  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dcca6  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dccaf  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dccb8  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dccc1  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dccca  sub rsp, 0x30
00007a3fbe1dccce  movaps [rsp], xmm9
00007a3fbe1dccd3  movaps [rsp+0x10], xmm8
00007a3fbe1dccd9  movaps [rsp+0x20], xmm11
00007a3fbe1dccdf  lea rdi, [rsp]
00007a3fbe1dcce3  mov esi, 0x00
00007a3fbe1dcce8  mov rax, 0x60D1084DB530
00007a3fbe1dccf2  call rax
00007a3fbe1dccf4  movaps xmm9, [rsp]
00007a3fbe1dccf9  add rsp, 0x30
00007a3fbe1dccfd  vmovaps xmm0, [rsp]
00007a3fbe1dcd02  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dcd08  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dcd0e  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dcd14  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dcd1a  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dcd20  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dcd26  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dcd2c  vmovaps xmm8, [rsp+0x80]
00007a3fbe1dcd35  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dcd3e  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dcd47  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dcd50  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dcd59  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dcd62  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dcd6b  add rsp, 0xF0
00007a3fbe1dcd72  pop r11
00007a3fbe1dcd74  pop r10
00007a3fbe1dcd76  pop r9
00007a3fbe1dcd78  pop r8
00007a3fbe1dcd7a  pop rsi
00007a3fbe1dcd7b  pop rdi
00007a3fbe1dcd7c  pop rdx
00007a3fbe1dcd7d  pop rcx
00007a3fbe1dcd7e  pop rax
00007a3fbe1dcd7f  add rsp, 0x08
00007a3fbe1dcd83  jmp 0x00007A3FBE1D9532
00007a3fbe1dcd88  sub rsp, 0x08
00007a3fbe1dcd8c  push rax
00007a3fbe1dcd8d  push rcx
00007a3fbe1dcd8e  push rdx
00007a3fbe1dcd8f  push rdi
00007a3fbe1dcd90  push rsi
00007a3fbe1dcd91  push r8
00007a3fbe1dcd93  push r9
00007a3fbe1dcd95  push r10
00007a3fbe1dcd97  push r11
00007a3fbe1dcd99  sub rsp, 0xF0
00007a3fbe1dcda0  vmovaps [rsp], xmm0
00007a3fbe1dcda5  vmovaps [rsp+0x10], xmm1
00007a3fbe1dcdab  vmovaps [rsp+0x20], xmm2
00007a3fbe1dcdb1  vmovaps [rsp+0x30], xmm3
00007a3fbe1dcdb7  vmovaps [rsp+0x40], xmm4
00007a3fbe1dcdbd  vmovaps [rsp+0x50], xmm5
00007a3fbe1dcdc3  vmovaps [rsp+0x60], xmm6
00007a3fbe1dcdc9  vmovaps [rsp+0x70], xmm7
00007a3fbe1dcdcf  vmovaps [rsp+0x80], xmm8
00007a3fbe1dcdd8  vmovaps [rsp+0x90], xmm9
00007a3fbe1dcde1  vmovaps [rsp+0xA0], xmm10
00007a3fbe1dcdea  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dcdf3  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dcdfc  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dce05  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dce0e  sub rsp, 0x30
00007a3fbe1dce12  movaps [rsp], xmm11
00007a3fbe1dce17  movaps [rsp+0x10], xmm10
00007a3fbe1dce1d  movaps [rsp+0x20], xmm6
00007a3fbe1dce22  lea rdi, [rsp]
00007a3fbe1dce26  mov esi, 0x00
00007a3fbe1dce2b  mov rax, 0x60D1084DB530
00007a3fbe1dce35  call rax
00007a3fbe1dce37  movaps xmm11, [rsp]
00007a3fbe1dce3c  add rsp, 0x30
00007a3fbe1dce40  vmovaps xmm0, [rsp]
00007a3fbe1dce45  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dce4b  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dce51  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dce57  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dce5d  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dce63  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dce69  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dce6f  vmovaps xmm8, [rsp+0x80]
00007a3fbe1dce78  vmovaps xmm9, [rsp+0x90]
00007a3fbe1dce81  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1dce8a  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dce93  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dce9c  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dcea5  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dceae  add rsp, 0xF0
00007a3fbe1dceb5  pop r11
00007a3fbe1dceb7  pop r10
00007a3fbe1dceb9  pop r9
00007a3fbe1dcebb  pop r8
00007a3fbe1dcebd  pop rsi
00007a3fbe1dcebe  pop rdi
00007a3fbe1dcebf  pop rdx
00007a3fbe1dcec0  pop rcx
00007a3fbe1dcec1  pop rax
00007a3fbe1dcec2  add rsp, 0x08
00007a3fbe1dcec6  jmp 0x00007A3FBE1D954D
00007a3fbe1dcecb  sub rsp, 0x08
00007a3fbe1dcecf  push rax
00007a3fbe1dced0  push rcx
00007a3fbe1dced1  push rdx
00007a3fbe1dced2  push rdi
00007a3fbe1dced3  push rsi
00007a3fbe1dced4  push r8
00007a3fbe1dced6  push r9
00007a3fbe1dced8  push r10
00007a3fbe1dceda  push r11
00007a3fbe1dcedc  sub rsp, 0xF0
00007a3fbe1dcee3  vmovaps [rsp], xmm0
00007a3fbe1dcee8  vmovaps [rsp+0x10], xmm1
00007a3fbe1dceee  vmovaps [rsp+0x20], xmm2
00007a3fbe1dcef4  vmovaps [rsp+0x30], xmm3
00007a3fbe1dcefa  vmovaps [rsp+0x40], xmm4
00007a3fbe1dcf00  vmovaps [rsp+0x50], xmm5
00007a3fbe1dcf06  vmovaps [rsp+0x60], xmm6
00007a3fbe1dcf0c  vmovaps [rsp+0x70], xmm7
00007a3fbe1dcf12  vmovaps [rsp+0x80], xmm8
00007a3fbe1dcf1b  vmovaps [rsp+0x90], xmm9
00007a3fbe1dcf24  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dcf2d  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dcf36  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dcf3f  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dcf48  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dcf51  sub rsp, 0x30
00007a3fbe1dcf55  movaps [rsp], xmm10
00007a3fbe1dcf5a  movaps [rsp+0x10], xmm14
00007a3fbe1dcf60  movaps [rsp+0x20], xmm4
00007a3fbe1dcf65  lea rdi, [rsp]
00007a3fbe1dcf69  mov esi, 0x00
00007a3fbe1dcf6e  mov rax, 0x60D1084DB530
00007a3fbe1dcf78  call rax
00007a3fbe1dcf7a  movaps xmm10, [rsp]
00007a3fbe1dcf7f  add rsp, 0x30
00007a3fbe1dcf83  vmovaps xmm0, [rsp]
00007a3fbe1dcf88  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dcf8e  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dcf94  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dcf9a  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dcfa0  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dcfa6  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dcfac  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dcfb2  vmovaps xmm8, [rsp+0x80]
00007a3fbe1dcfbb  vmovaps xmm9, [rsp+0x90]
00007a3fbe1dcfc4  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dcfcd  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dcfd6  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dcfdf  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dcfe8  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dcff1  add rsp, 0xF0
00007a3fbe1dcff8  pop r11
00007a3fbe1dcffa  pop r10
00007a3fbe1dcffc  pop r9
00007a3fbe1dcffe  pop r8
00007a3fbe1dd000  pop rsi
00007a3fbe1dd001  pop rdi
00007a3fbe1dd002  pop rdx
00007a3fbe1dd003  pop rcx
00007a3fbe1dd004  pop rax
00007a3fbe1dd005  add rsp, 0x08
00007a3fbe1dd009  jmp 0x00007A3FBE1D9568
00007a3fbe1dd00e  sub rsp, 0x08
00007a3fbe1dd012  push rax
00007a3fbe1dd013  push rcx
00007a3fbe1dd014  push rdx
00007a3fbe1dd015  push rdi
00007a3fbe1dd016  push rsi
00007a3fbe1dd017  push r8
00007a3fbe1dd019  push r9
00007a3fbe1dd01b  push r10
00007a3fbe1dd01d  push r11
00007a3fbe1dd01f  sub rsp, 0xF0
00007a3fbe1dd026  vmovaps [rsp], xmm0
00007a3fbe1dd02b  vmovaps [rsp+0x10], xmm1
00007a3fbe1dd031  vmovaps [rsp+0x20], xmm2
00007a3fbe1dd037  vmovaps [rsp+0x30], xmm3
00007a3fbe1dd03d  vmovaps [rsp+0x40], xmm4
00007a3fbe1dd043  vmovaps [rsp+0x50], xmm5
00007a3fbe1dd049  vmovaps [rsp+0x60], xmm6
00007a3fbe1dd04f  vmovaps [rsp+0x70], xmm7
00007a3fbe1dd055  vmovaps [rsp+0x80], xmm9
00007a3fbe1dd05e  vmovaps [rsp+0x90], xmm10
00007a3fbe1dd067  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dd070  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dd079  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dd082  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dd08b  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dd094  sub rsp, 0x30
00007a3fbe1dd098  movaps [rsp], xmm8
00007a3fbe1dd09d  movaps [rsp+0x10], xmm1
00007a3fbe1dd0a2  movaps [rsp+0x20], xmm14
00007a3fbe1dd0a8  lea rdi, [rsp]
00007a3fbe1dd0ac  mov esi, 0x00
00007a3fbe1dd0b1  mov rax, 0x60D1084DB530
00007a3fbe1dd0bb  call rax
00007a3fbe1dd0bd  movaps xmm8, [rsp]
00007a3fbe1dd0c2  add rsp, 0x30
00007a3fbe1dd0c6  vmovaps xmm0, [rsp]
00007a3fbe1dd0cb  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dd0d1  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dd0d7  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dd0dd  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dd0e3  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dd0e9  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dd0ef  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dd0f5  vmovaps xmm9, [rsp+0x80]
00007a3fbe1dd0fe  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dd107  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dd110  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dd119  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dd122  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dd12b  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dd134  add rsp, 0xF0
00007a3fbe1dd13b  pop r11
00007a3fbe1dd13d  pop r10
00007a3fbe1dd13f  pop r9
00007a3fbe1dd141  pop r8
00007a3fbe1dd143  pop rsi
00007a3fbe1dd144  pop rdi
00007a3fbe1dd145  pop rdx
00007a3fbe1dd146  pop rcx
00007a3fbe1dd147  pop rax
00007a3fbe1dd148  add rsp, 0x08
00007a3fbe1dd14c  jmp 0x00007A3FBE1D958E
00007a3fbe1dd151  sub rsp, 0x08
00007a3fbe1dd155  push rax
00007a3fbe1dd156  push rcx
00007a3fbe1dd157  push rdx
00007a3fbe1dd158  push rdi
00007a3fbe1dd159  push rsi
00007a3fbe1dd15a  push r8
00007a3fbe1dd15c  push r9
00007a3fbe1dd15e  push r10
00007a3fbe1dd160  push r11
00007a3fbe1dd162  sub rsp, 0xF0
00007a3fbe1dd169  vmovaps [rsp], xmm0
00007a3fbe1dd16e  vmovaps [rsp+0x10], xmm1
00007a3fbe1dd174  vmovaps [rsp+0x20], xmm2
00007a3fbe1dd17a  vmovaps [rsp+0x30], xmm3
00007a3fbe1dd180  vmovaps [rsp+0x40], xmm4
00007a3fbe1dd186  vmovaps [rsp+0x50], xmm5
00007a3fbe1dd18c  vmovaps [rsp+0x60], xmm7
00007a3fbe1dd192  vmovaps [rsp+0x70], xmm8
00007a3fbe1dd198  vmovaps [rsp+0x80], xmm9
00007a3fbe1dd1a1  vmovaps [rsp+0x90], xmm10
00007a3fbe1dd1aa  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dd1b3  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dd1bc  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dd1c5  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dd1ce  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dd1d7  sub rsp, 0x30
00007a3fbe1dd1db  movaps [rsp], xmm6
00007a3fbe1dd1df  movaps [rsp+0x10], xmm1
00007a3fbe1dd1e4  movaps [rsp+0x20], xmm14
00007a3fbe1dd1ea  lea rdi, [rsp]
00007a3fbe1dd1ee  mov esi, 0x00
00007a3fbe1dd1f3  mov rax, 0x60D1084DB530
00007a3fbe1dd1fd  call rax
00007a3fbe1dd1ff  movaps xmm6, [rsp]
00007a3fbe1dd203  add rsp, 0x30
00007a3fbe1dd207  vmovaps xmm0, [rsp]
00007a3fbe1dd20c  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dd212  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dd218  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dd21e  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dd224  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dd22a  vmovaps xmm7, [rsp+0x60]
00007a3fbe1dd230  vmovaps xmm8, [rsp+0x70]
00007a3fbe1dd236  vmovaps xmm9, [rsp+0x80]
00007a3fbe1dd23f  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dd248  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dd251  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dd25a  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dd263  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dd26c  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dd275  add rsp, 0xF0
00007a3fbe1dd27c  pop r11
00007a3fbe1dd27e  pop r10
00007a3fbe1dd280  pop r9
00007a3fbe1dd282  pop r8
00007a3fbe1dd284  pop rsi
00007a3fbe1dd285  pop rdi
00007a3fbe1dd286  pop rdx
00007a3fbe1dd287  pop rcx
00007a3fbe1dd288  pop rax
00007a3fbe1dd289  add rsp, 0x08
00007a3fbe1dd28d  jmp 0x00007A3FBE1D95BA
00007a3fbe1dd292  sub rsp, 0x08
00007a3fbe1dd296  push rax
00007a3fbe1dd297  push rcx
00007a3fbe1dd298  push rdx
00007a3fbe1dd299  push rdi
00007a3fbe1dd29a  push rsi
00007a3fbe1dd29b  push r8
00007a3fbe1dd29d  push r9
00007a3fbe1dd29f  push r10
00007a3fbe1dd2a1  push r11
00007a3fbe1dd2a3  sub rsp, 0xF0
00007a3fbe1dd2aa  vmovaps [rsp], xmm0
00007a3fbe1dd2af  vmovaps [rsp+0x10], xmm1
00007a3fbe1dd2b5  vmovaps [rsp+0x20], xmm2
00007a3fbe1dd2bb  vmovaps [rsp+0x30], xmm3
00007a3fbe1dd2c1  vmovaps [rsp+0x40], xmm4
00007a3fbe1dd2c7  vmovaps [rsp+0x50], xmm5
00007a3fbe1dd2cd  vmovaps [rsp+0x60], xmm6
00007a3fbe1dd2d3  vmovaps [rsp+0x70], xmm7
00007a3fbe1dd2d9  vmovaps [rsp+0x80], xmm8
00007a3fbe1dd2e2  vmovaps [rsp+0x90], xmm9
00007a3fbe1dd2eb  vmovaps [rsp+0xA0], xmm10
00007a3fbe1dd2f4  vmovaps [rsp+0xB0], xmm11
00007a3fbe1dd2fd  vmovaps [rsp+0xC0], xmm12
00007a3fbe1dd306  vmovaps [rsp+0xD0], xmm13
00007a3fbe1dd30f  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dd318  sub rsp, 0x30
00007a3fbe1dd31c  movaps [rsp], xmm14
00007a3fbe1dd321  movaps [rsp+0x10], xmm12
00007a3fbe1dd327  movaps [rsp+0x20], xmm1
00007a3fbe1dd32c  lea rdi, [rsp]
00007a3fbe1dd330  mov esi, 0x00
00007a3fbe1dd335  mov rax, 0x60D1084DB530
00007a3fbe1dd33f  call rax
00007a3fbe1dd341  movaps xmm14, [rsp]
00007a3fbe1dd346  add rsp, 0x30
00007a3fbe1dd34a  vmovaps xmm0, [rsp]
00007a3fbe1dd34f  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dd355  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dd35b  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dd361  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dd367  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dd36d  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dd373  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dd379  vmovaps xmm8, [rsp+0x80]
00007a3fbe1dd382  vmovaps xmm9, [rsp+0x90]
00007a3fbe1dd38b  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1dd394  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1dd39d  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1dd3a6  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1dd3af  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dd3b8  add rsp, 0xF0
00007a3fbe1dd3bf  pop r11
00007a3fbe1dd3c1  pop r10
00007a3fbe1dd3c3  pop r9
00007a3fbe1dd3c5  pop r8
00007a3fbe1dd3c7  pop rsi
00007a3fbe1dd3c8  pop rdi
00007a3fbe1dd3c9  pop rdx
00007a3fbe1dd3ca  pop rcx
00007a3fbe1dd3cb  pop rax
00007a3fbe1dd3cc  add rsp, 0x08
00007a3fbe1dd3d0  jmp 0x00007A3FBE1D95E0
00007a3fbe1dd3d5  sub rsp, 0x08
00007a3fbe1dd3d9  push rax
00007a3fbe1dd3da  push rcx
00007a3fbe1dd3db  push rdx
00007a3fbe1dd3dc  push rdi
00007a3fbe1dd3dd  push rsi
00007a3fbe1dd3de  push r8
00007a3fbe1dd3e0  push r9
00007a3fbe1dd3e2  push r10
00007a3fbe1dd3e4  push r11
00007a3fbe1dd3e6  sub rsp, 0xF0
00007a3fbe1dd3ed  vmovaps [rsp], xmm0
00007a3fbe1dd3f2  vmovaps [rsp+0x10], xmm2
00007a3fbe1dd3f8  vmovaps [rsp+0x20], xmm3
00007a3fbe1dd3fe  vmovaps [rsp+0x30], xmm4
00007a3fbe1dd404  vmovaps [rsp+0x40], xmm5
00007a3fbe1dd40a  vmovaps [rsp+0x50], xmm6
00007a3fbe1dd410  vmovaps [rsp+0x60], xmm7
00007a3fbe1dd416  vmovaps [rsp+0x70], xmm8
00007a3fbe1dd41c  vmovaps [rsp+0x80], xmm9
00007a3fbe1dd425  vmovaps [rsp+0x90], xmm10
00007a3fbe1dd42e  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dd437  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dd440  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dd449  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dd452  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dd45b  sub rsp, 0x30
00007a3fbe1dd45f  movaps [rsp], xmm1
00007a3fbe1dd463  movaps [rsp+0x10], xmm13
00007a3fbe1dd469  movaps [rsp+0x20], xmm9
00007a3fbe1dd46f  lea rdi, [rsp]
00007a3fbe1dd473  mov esi, 0x00
00007a3fbe1dd478  mov rax, 0x60D1084DB530
00007a3fbe1dd482  call rax
00007a3fbe1dd484  movaps xmm1, [rsp]
00007a3fbe1dd488  add rsp, 0x30
00007a3fbe1dd48c  vmovaps xmm0, [rsp]
00007a3fbe1dd491  vmovaps xmm2, [rsp+0x10]
00007a3fbe1dd497  vmovaps xmm3, [rsp+0x20]
00007a3fbe1dd49d  vmovaps xmm4, [rsp+0x30]
00007a3fbe1dd4a3  vmovaps xmm5, [rsp+0x40]
00007a3fbe1dd4a9  vmovaps xmm6, [rsp+0x50]
00007a3fbe1dd4af  vmovaps xmm7, [rsp+0x60]
00007a3fbe1dd4b5  vmovaps xmm8, [rsp+0x70]
00007a3fbe1dd4bb  vmovaps xmm9, [rsp+0x80]
00007a3fbe1dd4c4  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dd4cd  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dd4d6  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dd4df  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dd4e8  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dd4f1  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dd4fa  add rsp, 0xF0
00007a3fbe1dd501  pop r11
00007a3fbe1dd503  pop r10
00007a3fbe1dd505  pop r9
00007a3fbe1dd507  pop r8
00007a3fbe1dd509  pop rsi
00007a3fbe1dd50a  pop rdi
00007a3fbe1dd50b  pop rdx
00007a3fbe1dd50c  pop rcx
00007a3fbe1dd50d  pop rax
00007a3fbe1dd50e  add rsp, 0x08
00007a3fbe1dd512  jmp 0x00007A3FBE1D95FA
00007a3fbe1dd517  sub rsp, 0x08
00007a3fbe1dd51b  push rax
00007a3fbe1dd51c  push rcx
00007a3fbe1dd51d  push rdx
00007a3fbe1dd51e  push rdi
00007a3fbe1dd51f  push rsi
00007a3fbe1dd520  push r8
00007a3fbe1dd522  push r9
00007a3fbe1dd524  push r10
00007a3fbe1dd526  push r11
00007a3fbe1dd528  sub rsp, 0xF0
00007a3fbe1dd52f  vmovaps [rsp], xmm0
00007a3fbe1dd534  vmovaps [rsp+0x10], xmm1
00007a3fbe1dd53a  vmovaps [rsp+0x20], xmm2
00007a3fbe1dd540  vmovaps [rsp+0x30], xmm3
00007a3fbe1dd546  vmovaps [rsp+0x40], xmm4
00007a3fbe1dd54c  vmovaps [rsp+0x50], xmm5
00007a3fbe1dd552  vmovaps [rsp+0x60], xmm6
00007a3fbe1dd558  vmovaps [rsp+0x70], xmm7
00007a3fbe1dd55e  vmovaps [rsp+0x80], xmm8
00007a3fbe1dd567  vmovaps [rsp+0x90], xmm9
00007a3fbe1dd570  vmovaps [rsp+0xA0], xmm10
00007a3fbe1dd579  vmovaps [rsp+0xB0], xmm11
00007a3fbe1dd582  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dd58b  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dd594  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dd59d  sub rsp, 0x30
00007a3fbe1dd5a1  movaps [rsp], xmm12
00007a3fbe1dd5a6  movaps [rsp+0x10], xmm7
00007a3fbe1dd5ab  movaps [rsp+0x20], xmm13
00007a3fbe1dd5b1  lea rdi, [rsp]
00007a3fbe1dd5b5  mov esi, 0x00
00007a3fbe1dd5ba  mov rax, 0x60D1084DB530
00007a3fbe1dd5c4  call rax
00007a3fbe1dd5c6  movaps xmm12, [rsp]
00007a3fbe1dd5cb  add rsp, 0x30
00007a3fbe1dd5cf  vmovaps xmm0, [rsp]
00007a3fbe1dd5d4  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dd5da  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dd5e0  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dd5e6  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dd5ec  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dd5f2  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dd5f8  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dd5fe  vmovaps xmm8, [rsp+0x80]
00007a3fbe1dd607  vmovaps xmm9, [rsp+0x90]
00007a3fbe1dd610  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1dd619  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1dd622  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dd62b  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dd634  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dd63d  add rsp, 0xF0
00007a3fbe1dd644  pop r11
00007a3fbe1dd646  pop r10
00007a3fbe1dd648  pop r9
00007a3fbe1dd64a  pop r8
00007a3fbe1dd64c  pop rsi
00007a3fbe1dd64d  pop rdi
00007a3fbe1dd64e  pop rdx
00007a3fbe1dd64f  pop rcx
00007a3fbe1dd650  pop rax
00007a3fbe1dd651  add rsp, 0x08
00007a3fbe1dd655  jmp 0x00007A3FBE1D9621
00007a3fbe1dd65a  sub rsp, 0x08
00007a3fbe1dd65e  push rax
00007a3fbe1dd65f  push rcx
00007a3fbe1dd660  push rdx
00007a3fbe1dd661  push rdi
00007a3fbe1dd662  push rsi
00007a3fbe1dd663  push r8
00007a3fbe1dd665  push r9
00007a3fbe1dd667  push r10
00007a3fbe1dd669  push r11
00007a3fbe1dd66b  sub rsp, 0xF0
00007a3fbe1dd672  vmovaps [rsp], xmm0
00007a3fbe1dd677  vmovaps [rsp+0x10], xmm1
00007a3fbe1dd67d  vmovaps [rsp+0x20], xmm2
00007a3fbe1dd683  vmovaps [rsp+0x30], xmm3
00007a3fbe1dd689  vmovaps [rsp+0x40], xmm4
00007a3fbe1dd68f  vmovaps [rsp+0x50], xmm5
00007a3fbe1dd695  vmovaps [rsp+0x60], xmm6
00007a3fbe1dd69b  vmovaps [rsp+0x70], xmm7
00007a3fbe1dd6a1  vmovaps [rsp+0x80], xmm8
00007a3fbe1dd6aa  vmovaps [rsp+0x90], xmm9
00007a3fbe1dd6b3  vmovaps [rsp+0xA0], xmm10
00007a3fbe1dd6bc  vmovaps [rsp+0xB0], xmm11
00007a3fbe1dd6c5  vmovaps [rsp+0xC0], xmm12
00007a3fbe1dd6ce  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dd6d7  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dd6e0  sub rsp, 0x30
00007a3fbe1dd6e4  movaps [rsp], xmm13
00007a3fbe1dd6e9  movaps [rsp+0x10], xmm15
00007a3fbe1dd6ef  movaps [rsp+0x20], xmm8
00007a3fbe1dd6f5  lea rdi, [rsp]
00007a3fbe1dd6f9  mov esi, 0x00
00007a3fbe1dd6fe  mov rax, 0x60D1084DB530
00007a3fbe1dd708  call rax
00007a3fbe1dd70a  movaps xmm13, [rsp]
00007a3fbe1dd70f  add rsp, 0x30
00007a3fbe1dd713  vmovaps xmm0, [rsp]
00007a3fbe1dd718  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dd71e  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dd724  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dd72a  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dd730  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dd736  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dd73c  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dd742  vmovaps xmm8, [rsp+0x80]
00007a3fbe1dd74b  vmovaps xmm9, [rsp+0x90]
00007a3fbe1dd754  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1dd75d  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1dd766  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1dd76f  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dd778  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dd781  add rsp, 0xF0
00007a3fbe1dd788  pop r11
00007a3fbe1dd78a  pop r10
00007a3fbe1dd78c  pop r9
00007a3fbe1dd78e  pop r8
00007a3fbe1dd790  pop rsi
00007a3fbe1dd791  pop rdi
00007a3fbe1dd792  pop rdx
00007a3fbe1dd793  pop rcx
00007a3fbe1dd794  pop rax
00007a3fbe1dd795  add rsp, 0x08
00007a3fbe1dd799  jmp 0x00007A3FBE1D963C
00007a3fbe1dd79e  sub rsp, 0x08
00007a3fbe1dd7a2  push rax
00007a3fbe1dd7a3  push rcx
00007a3fbe1dd7a4  push rdx
00007a3fbe1dd7a5  push rdi
00007a3fbe1dd7a6  push rsi
00007a3fbe1dd7a7  push r8
00007a3fbe1dd7a9  push r9
00007a3fbe1dd7ab  push r10
00007a3fbe1dd7ad  push r11
00007a3fbe1dd7af  sub rsp, 0xF0
00007a3fbe1dd7b6  vmovaps [rsp], xmm0
00007a3fbe1dd7bb  vmovaps [rsp+0x10], xmm1
00007a3fbe1dd7c1  vmovaps [rsp+0x20], xmm2
00007a3fbe1dd7c7  vmovaps [rsp+0x30], xmm3
00007a3fbe1dd7cd  vmovaps [rsp+0x40], xmm4
00007a3fbe1dd7d3  vmovaps [rsp+0x50], xmm5
00007a3fbe1dd7d9  vmovaps [rsp+0x60], xmm6
00007a3fbe1dd7df  vmovaps [rsp+0x70], xmm7
00007a3fbe1dd7e5  vmovaps [rsp+0x80], xmm9
00007a3fbe1dd7ee  vmovaps [rsp+0x90], xmm10
00007a3fbe1dd7f7  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dd800  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dd809  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dd812  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dd81b  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dd824  sub rsp, 0x30
00007a3fbe1dd828  movaps [rsp], xmm8
00007a3fbe1dd82d  movaps [rsp+0x10], xmm15
00007a3fbe1dd833  movaps [rsp+0x20], xmm9
00007a3fbe1dd839  lea rdi, [rsp]
00007a3fbe1dd83d  mov esi, 0x00
00007a3fbe1dd842  mov rax, 0x60D1084DB530
00007a3fbe1dd84c  call rax
00007a3fbe1dd84e  movaps xmm8, [rsp]
00007a3fbe1dd853  add rsp, 0x30
00007a3fbe1dd857  vmovaps xmm0, [rsp]
00007a3fbe1dd85c  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dd862  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dd868  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dd86e  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dd874  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dd87a  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dd880  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dd886  vmovaps xmm9, [rsp+0x80]
00007a3fbe1dd88f  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dd898  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dd8a1  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dd8aa  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dd8b3  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dd8bc  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dd8c5  add rsp, 0xF0
00007a3fbe1dd8cc  pop r11
00007a3fbe1dd8ce  pop r10
00007a3fbe1dd8d0  pop r9
00007a3fbe1dd8d2  pop r8
00007a3fbe1dd8d4  pop rsi
00007a3fbe1dd8d5  pop rdi
00007a3fbe1dd8d6  pop rdx
00007a3fbe1dd8d7  pop rcx
00007a3fbe1dd8d8  pop rax
00007a3fbe1dd8d9  add rsp, 0x08
00007a3fbe1dd8dd  jmp 0x00007A3FBE1D966A
00007a3fbe1dd8e2  sub rsp, 0x08
00007a3fbe1dd8e6  push rax
00007a3fbe1dd8e7  push rcx
00007a3fbe1dd8e8  push rdx
00007a3fbe1dd8e9  push rdi
00007a3fbe1dd8ea  push rsi
00007a3fbe1dd8eb  push r8
00007a3fbe1dd8ed  push r9
00007a3fbe1dd8ef  push r10
00007a3fbe1dd8f1  push r11
00007a3fbe1dd8f3  sub rsp, 0xF0
00007a3fbe1dd8fa  vmovaps [rsp], xmm0
00007a3fbe1dd8ff  vmovaps [rsp+0x10], xmm1
00007a3fbe1dd905  vmovaps [rsp+0x20], xmm2
00007a3fbe1dd90b  vmovaps [rsp+0x30], xmm3
00007a3fbe1dd911  vmovaps [rsp+0x40], xmm4
00007a3fbe1dd917  vmovaps [rsp+0x50], xmm5
00007a3fbe1dd91d  vmovaps [rsp+0x60], xmm6
00007a3fbe1dd923  vmovaps [rsp+0x70], xmm7
00007a3fbe1dd929  vmovaps [rsp+0x80], xmm8
00007a3fbe1dd932  vmovaps [rsp+0x90], xmm9
00007a3fbe1dd93b  vmovaps [rsp+0xA0], xmm10
00007a3fbe1dd944  vmovaps [rsp+0xB0], xmm11
00007a3fbe1dd94d  vmovaps [rsp+0xC0], xmm12
00007a3fbe1dd956  vmovaps [rsp+0xD0], xmm13
00007a3fbe1dd95f  vmovaps [rsp+0xE0], xmm14
00007a3fbe1dd968  sub rsp, 0x30
00007a3fbe1dd96c  movaps [rsp], xmm15
00007a3fbe1dd971  movaps [rsp+0x10], xmm11
00007a3fbe1dd977  movaps [rsp+0x20], xmm6
00007a3fbe1dd97c  lea rdi, [rsp]
00007a3fbe1dd980  mov esi, 0x00
00007a3fbe1dd985  mov rax, 0x60D1084DB530
00007a3fbe1dd98f  call rax
00007a3fbe1dd991  movaps xmm15, [rsp]
00007a3fbe1dd996  add rsp, 0x30
00007a3fbe1dd99a  vmovaps xmm0, [rsp]
00007a3fbe1dd99f  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dd9a5  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dd9ab  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dd9b1  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dd9b7  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dd9bd  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dd9c3  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dd9c9  vmovaps xmm8, [rsp+0x80]
00007a3fbe1dd9d2  vmovaps xmm9, [rsp+0x90]
00007a3fbe1dd9db  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1dd9e4  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1dd9ed  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1dd9f6  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1dd9ff  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1dda08  add rsp, 0xF0
00007a3fbe1dda0f  pop r11
00007a3fbe1dda11  pop r10
00007a3fbe1dda13  pop r9
00007a3fbe1dda15  pop r8
00007a3fbe1dda17  pop rsi
00007a3fbe1dda18  pop rdi
00007a3fbe1dda19  pop rdx
00007a3fbe1dda1a  pop rcx
00007a3fbe1dda1b  pop rax
00007a3fbe1dda1c  add rsp, 0x08
00007a3fbe1dda20  jmp 0x00007A3FBE1D9685
00007a3fbe1dda25  sub rsp, 0x08
00007a3fbe1dda29  push rax
00007a3fbe1dda2a  push rcx
00007a3fbe1dda2b  push rdx
00007a3fbe1dda2c  push rdi
00007a3fbe1dda2d  push rsi
00007a3fbe1dda2e  push r8
00007a3fbe1dda30  push r9
00007a3fbe1dda32  push r10
00007a3fbe1dda34  push r11
00007a3fbe1dda36  sub rsp, 0xF0
00007a3fbe1dda3d  vmovaps [rsp], xmm0
00007a3fbe1dda42  vmovaps [rsp+0x10], xmm1
00007a3fbe1dda48  vmovaps [rsp+0x20], xmm2
00007a3fbe1dda4e  vmovaps [rsp+0x30], xmm3
00007a3fbe1dda54  vmovaps [rsp+0x40], xmm4
00007a3fbe1dda5a  vmovaps [rsp+0x50], xmm5
00007a3fbe1dda60  vmovaps [rsp+0x60], xmm6
00007a3fbe1dda66  vmovaps [rsp+0x70], xmm8
00007a3fbe1dda6c  vmovaps [rsp+0x80], xmm9
00007a3fbe1dda75  vmovaps [rsp+0x90], xmm10
00007a3fbe1dda7e  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dda87  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dda90  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dda99  vmovaps [rsp+0xD0], xmm14
00007a3fbe1ddaa2  vmovaps [rsp+0xE0], xmm15
00007a3fbe1ddaab  sub rsp, 0x30
00007a3fbe1ddaaf  movaps [rsp], xmm7
00007a3fbe1ddab3  movaps [rsp+0x10], xmm11
00007a3fbe1ddab9  movaps [rsp+0x20], xmm9
00007a3fbe1ddabf  lea rdi, [rsp]
00007a3fbe1ddac3  mov esi, 0x00
00007a3fbe1ddac8  mov rax, 0x60D1084DB530
00007a3fbe1ddad2  call rax
00007a3fbe1ddad4  movaps xmm7, [rsp]
00007a3fbe1ddad8  add rsp, 0x30
00007a3fbe1ddadc  vmovaps xmm0, [rsp]
00007a3fbe1ddae1  vmovaps xmm1, [rsp+0x10]
00007a3fbe1ddae7  vmovaps xmm2, [rsp+0x20]
00007a3fbe1ddaed  vmovaps xmm3, [rsp+0x30]
00007a3fbe1ddaf3  vmovaps xmm4, [rsp+0x40]
00007a3fbe1ddaf9  vmovaps xmm5, [rsp+0x50]
00007a3fbe1ddaff  vmovaps xmm6, [rsp+0x60]
00007a3fbe1ddb05  vmovaps xmm8, [rsp+0x70]
00007a3fbe1ddb0b  vmovaps xmm9, [rsp+0x80]
00007a3fbe1ddb14  vmovaps xmm10, [rsp+0x90]
00007a3fbe1ddb1d  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1ddb26  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1ddb2f  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1ddb38  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1ddb41  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1ddb4a  add rsp, 0xF0
00007a3fbe1ddb51  pop r11
00007a3fbe1ddb53  pop r10
00007a3fbe1ddb55  pop r9
00007a3fbe1ddb57  pop r8
00007a3fbe1ddb59  pop rsi
00007a3fbe1ddb5a  pop rdi
00007a3fbe1ddb5b  pop rdx
00007a3fbe1ddb5c  pop rcx
00007a3fbe1ddb5d  pop rax
00007a3fbe1ddb5e  add rsp, 0x08
00007a3fbe1ddb62  jmp 0x00007A3FBE1D96B2
00007a3fbe1ddb67  sub rsp, 0x08
00007a3fbe1ddb6b  push rax
00007a3fbe1ddb6c  push rcx
00007a3fbe1ddb6d  push rdx
00007a3fbe1ddb6e  push rdi
00007a3fbe1ddb6f  push rsi
00007a3fbe1ddb70  push r8
00007a3fbe1ddb72  push r9
00007a3fbe1ddb74  push r10
00007a3fbe1ddb76  push r11
00007a3fbe1ddb78  sub rsp, 0xF0
00007a3fbe1ddb7f  vmovaps [rsp], xmm0
00007a3fbe1ddb84  vmovaps [rsp+0x10], xmm1
00007a3fbe1ddb8a  vmovaps [rsp+0x20], xmm2
00007a3fbe1ddb90  vmovaps [rsp+0x30], xmm3
00007a3fbe1ddb96  vmovaps [rsp+0x40], xmm4
00007a3fbe1ddb9c  vmovaps [rsp+0x50], xmm5
00007a3fbe1ddba2  vmovaps [rsp+0x60], xmm6
00007a3fbe1ddba8  vmovaps [rsp+0x70], xmm7
00007a3fbe1ddbae  vmovaps [rsp+0x80], xmm8
00007a3fbe1ddbb7  vmovaps [rsp+0x90], xmm9
00007a3fbe1ddbc0  vmovaps [rsp+0xA0], xmm10
00007a3fbe1ddbc9  vmovaps [rsp+0xB0], xmm12
00007a3fbe1ddbd2  vmovaps [rsp+0xC0], xmm13
00007a3fbe1ddbdb  vmovaps [rsp+0xD0], xmm14
00007a3fbe1ddbe4  vmovaps [rsp+0xE0], xmm15
00007a3fbe1ddbed  sub rsp, 0x30
00007a3fbe1ddbf1  movaps [rsp], xmm11
00007a3fbe1ddbf6  movaps [rsp+0x10], xmm10
00007a3fbe1ddbfc  movaps [rsp+0x20], xmm14
00007a3fbe1ddc02  lea rdi, [rsp]
00007a3fbe1ddc06  mov esi, 0x00
00007a3fbe1ddc0b  mov rax, 0x60D1084DB530
00007a3fbe1ddc15  call rax
00007a3fbe1ddc17  movaps xmm11, [rsp]
00007a3fbe1ddc1c  add rsp, 0x30
00007a3fbe1ddc20  vmovaps xmm0, [rsp]
00007a3fbe1ddc25  vmovaps xmm1, [rsp+0x10]
00007a3fbe1ddc2b  vmovaps xmm2, [rsp+0x20]
00007a3fbe1ddc31  vmovaps xmm3, [rsp+0x30]
00007a3fbe1ddc37  vmovaps xmm4, [rsp+0x40]
00007a3fbe1ddc3d  vmovaps xmm5, [rsp+0x50]
00007a3fbe1ddc43  vmovaps xmm6, [rsp+0x60]
00007a3fbe1ddc49  vmovaps xmm7, [rsp+0x70]
00007a3fbe1ddc4f  vmovaps xmm8, [rsp+0x80]
00007a3fbe1ddc58  vmovaps xmm9, [rsp+0x90]
00007a3fbe1ddc61  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1ddc6a  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1ddc73  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1ddc7c  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1ddc85  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1ddc8e  add rsp, 0xF0
00007a3fbe1ddc95  pop r11
00007a3fbe1ddc97  pop r10
00007a3fbe1ddc99  pop r9
00007a3fbe1ddc9b  pop r8
00007a3fbe1ddc9d  pop rsi
00007a3fbe1ddc9e  pop rdi
00007a3fbe1ddc9f  pop rdx
00007a3fbe1ddca0  pop rcx
00007a3fbe1ddca1  pop rax
00007a3fbe1ddca2  add rsp, 0x08
00007a3fbe1ddca6  jmp 0x00007A3FBE1D96CD
00007a3fbe1ddcab  call 0x00007A3FBE0E45A0
00007a3fbe1ddcb0  jmp 0x00007A3FBE1D96D7
00007a3fbe1ddcb5  sub rsp, 0x08
00007a3fbe1ddcb9  push rax
00007a3fbe1ddcba  push rcx
00007a3fbe1ddcbb  push rdx
00007a3fbe1ddcbc  push rdi
00007a3fbe1ddcbd  push rsi
00007a3fbe1ddcbe  push r8
00007a3fbe1ddcc0  push r9
00007a3fbe1ddcc2  push r10
00007a3fbe1ddcc4  push r11
00007a3fbe1ddcc6  sub rsp, 0xF0
00007a3fbe1ddccd  vmovaps [rsp], xmm0
00007a3fbe1ddcd2  vmovaps [rsp+0x10], xmm1
00007a3fbe1ddcd8  vmovaps [rsp+0x20], xmm2
00007a3fbe1ddcde  vmovaps [rsp+0x30], xmm3
00007a3fbe1ddce4  vmovaps [rsp+0x40], xmm4
00007a3fbe1ddcea  vmovaps [rsp+0x50], xmm5
00007a3fbe1ddcf0  vmovaps [rsp+0x60], xmm6
00007a3fbe1ddcf6  vmovaps [rsp+0x70], xmm7
00007a3fbe1ddcfc  vmovaps [rsp+0x80], xmm8
00007a3fbe1ddd05  vmovaps [rsp+0x90], xmm9
00007a3fbe1ddd0e  vmovaps [rsp+0xA0], xmm11
00007a3fbe1ddd17  vmovaps [rsp+0xB0], xmm12
00007a3fbe1ddd20  vmovaps [rsp+0xC0], xmm13
00007a3fbe1ddd29  vmovaps [rsp+0xD0], xmm14
00007a3fbe1ddd32  vmovaps [rsp+0xE0], xmm15
00007a3fbe1ddd3b  sub rsp, 0x30
00007a3fbe1ddd3f  movaps [rsp], xmm10
00007a3fbe1ddd44  movaps [rsp+0x10], xmm1
00007a3fbe1ddd49  movaps [rsp+0x20], xmm12
00007a3fbe1ddd4f  lea rdi, [rsp]
00007a3fbe1ddd53  mov esi, 0x00
00007a3fbe1ddd58  mov rax, 0x60D1084DB530
00007a3fbe1ddd62  call rax
00007a3fbe1ddd64  movaps xmm10, [rsp]
00007a3fbe1ddd69  add rsp, 0x30
00007a3fbe1ddd6d  vmovaps xmm0, [rsp]
00007a3fbe1ddd72  vmovaps xmm1, [rsp+0x10]
00007a3fbe1ddd78  vmovaps xmm2, [rsp+0x20]
00007a3fbe1ddd7e  vmovaps xmm3, [rsp+0x30]
00007a3fbe1ddd84  vmovaps xmm4, [rsp+0x40]
00007a3fbe1ddd8a  vmovaps xmm5, [rsp+0x50]
00007a3fbe1ddd90  vmovaps xmm6, [rsp+0x60]
00007a3fbe1ddd96  vmovaps xmm7, [rsp+0x70]
00007a3fbe1ddd9c  vmovaps xmm8, [rsp+0x80]
00007a3fbe1ddda5  vmovaps xmm9, [rsp+0x90]
00007a3fbe1dddae  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dddb7  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dddc0  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dddc9  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dddd2  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1ddddb  add rsp, 0xF0
00007a3fbe1ddde2  pop r11
00007a3fbe1ddde4  pop r10
00007a3fbe1ddde6  pop r9
00007a3fbe1ddde8  pop r8
00007a3fbe1dddea  pop rsi
00007a3fbe1dddeb  pop rdi
00007a3fbe1dddec  pop rdx
00007a3fbe1ddded  pop rcx
00007a3fbe1dddee  pop rax
00007a3fbe1dddef  add rsp, 0x08
00007a3fbe1dddf3  jmp 0x00007A3FBE1D96FA
00007a3fbe1dddf8  sub rsp, 0x08
00007a3fbe1dddfc  push rax
00007a3fbe1dddfd  push rcx
00007a3fbe1dddfe  push rdx
00007a3fbe1dddff  push rdi
00007a3fbe1dde00  push rsi
00007a3fbe1dde01  push r8
00007a3fbe1dde03  push r9
00007a3fbe1dde05  push r10
00007a3fbe1dde07  push r11
00007a3fbe1dde09  sub rsp, 0xF0
00007a3fbe1dde10  vmovaps [rsp], xmm0
00007a3fbe1dde15  vmovaps [rsp+0x10], xmm1
00007a3fbe1dde1b  vmovaps [rsp+0x20], xmm2
00007a3fbe1dde21  vmovaps [rsp+0x30], xmm3
00007a3fbe1dde27  vmovaps [rsp+0x40], xmm4
00007a3fbe1dde2d  vmovaps [rsp+0x50], xmm5
00007a3fbe1dde33  vmovaps [rsp+0x60], xmm6
00007a3fbe1dde39  vmovaps [rsp+0x70], xmm7
00007a3fbe1dde3f  vmovaps [rsp+0x80], xmm8
00007a3fbe1dde48  vmovaps [rsp+0x90], xmm9
00007a3fbe1dde51  vmovaps [rsp+0xA0], xmm10
00007a3fbe1dde5a  vmovaps [rsp+0xB0], xmm11
00007a3fbe1dde63  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dde6c  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dde75  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dde7e  sub rsp, 0x30
00007a3fbe1dde82  movaps [rsp], xmm12
00007a3fbe1dde87  movaps [rsp+0x10], xmm14
00007a3fbe1dde8d  movaps [rsp+0x20], xmm1
00007a3fbe1dde92  lea rdi, [rsp]
00007a3fbe1dde96  mov esi, 0x00
00007a3fbe1dde9b  mov rax, 0x60D1084DB530
00007a3fbe1ddea5  call rax
00007a3fbe1ddea7  movaps xmm12, [rsp]
00007a3fbe1ddeac  add rsp, 0x30
00007a3fbe1ddeb0  vmovaps xmm0, [rsp]
00007a3fbe1ddeb5  vmovaps xmm1, [rsp+0x10]
00007a3fbe1ddebb  vmovaps xmm2, [rsp+0x20]
00007a3fbe1ddec1  vmovaps xmm3, [rsp+0x30]
00007a3fbe1ddec7  vmovaps xmm4, [rsp+0x40]
00007a3fbe1ddecd  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dded3  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dded9  vmovaps xmm7, [rsp+0x70]
00007a3fbe1ddedf  vmovaps xmm8, [rsp+0x80]
00007a3fbe1ddee8  vmovaps xmm9, [rsp+0x90]
00007a3fbe1ddef1  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1ddefa  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1ddf03  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1ddf0c  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1ddf15  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1ddf1e  add rsp, 0xF0
00007a3fbe1ddf25  pop r11
00007a3fbe1ddf27  pop r10
00007a3fbe1ddf29  pop r9
00007a3fbe1ddf2b  pop r8
00007a3fbe1ddf2d  pop rsi
00007a3fbe1ddf2e  pop rdi
00007a3fbe1ddf2f  pop rdx
00007a3fbe1ddf30  pop rcx
00007a3fbe1ddf31  pop rax
00007a3fbe1ddf32  add rsp, 0x08
00007a3fbe1ddf36  jmp 0x00007A3FBE1D9729
00007a3fbe1ddf3b  sub rsp, 0x08
00007a3fbe1ddf3f  push rax
00007a3fbe1ddf40  push rcx
00007a3fbe1ddf41  push rdx
00007a3fbe1ddf42  push rdi
00007a3fbe1ddf43  push rsi
00007a3fbe1ddf44  push r8
00007a3fbe1ddf46  push r9
00007a3fbe1ddf48  push r10
00007a3fbe1ddf4a  push r11
00007a3fbe1ddf4c  sub rsp, 0xF0
00007a3fbe1ddf53  vmovaps [rsp], xmm0
00007a3fbe1ddf58  vmovaps [rsp+0x10], xmm1
00007a3fbe1ddf5e  vmovaps [rsp+0x20], xmm2
00007a3fbe1ddf64  vmovaps [rsp+0x30], xmm3
00007a3fbe1ddf6a  vmovaps [rsp+0x40], xmm4
00007a3fbe1ddf70  vmovaps [rsp+0x50], xmm5
00007a3fbe1ddf76  vmovaps [rsp+0x60], xmm6
00007a3fbe1ddf7c  vmovaps [rsp+0x70], xmm7
00007a3fbe1ddf82  vmovaps [rsp+0x80], xmm8
00007a3fbe1ddf8b  vmovaps [rsp+0x90], xmm9
00007a3fbe1ddf94  vmovaps [rsp+0xA0], xmm10
00007a3fbe1ddf9d  vmovaps [rsp+0xB0], xmm11
00007a3fbe1ddfa6  vmovaps [rsp+0xC0], xmm12
00007a3fbe1ddfaf  vmovaps [rsp+0xD0], xmm13
00007a3fbe1ddfb8  vmovaps [rsp+0xE0], xmm15
00007a3fbe1ddfc1  sub rsp, 0x30
00007a3fbe1ddfc5  movaps [rsp], xmm14
00007a3fbe1ddfca  movaps [rsp+0x10], xmm9
00007a3fbe1ddfd0  movaps [rsp+0x20], xmm1
00007a3fbe1ddfd5  lea rdi, [rsp]
00007a3fbe1ddfd9  mov esi, 0x00
00007a3fbe1ddfde  mov rax, 0x60D1084DB530
00007a3fbe1ddfe8  call rax
00007a3fbe1ddfea  movaps xmm14, [rsp]
00007a3fbe1ddfef  add rsp, 0x30
00007a3fbe1ddff3  vmovaps xmm0, [rsp]
00007a3fbe1ddff8  vmovaps xmm1, [rsp+0x10]
00007a3fbe1ddffe  vmovaps xmm2, [rsp+0x20]
00007a3fbe1de004  vmovaps xmm3, [rsp+0x30]
00007a3fbe1de00a  vmovaps xmm4, [rsp+0x40]
00007a3fbe1de010  vmovaps xmm5, [rsp+0x50]
00007a3fbe1de016  vmovaps xmm6, [rsp+0x60]
00007a3fbe1de01c  vmovaps xmm7, [rsp+0x70]
00007a3fbe1de022  vmovaps xmm8, [rsp+0x80]
00007a3fbe1de02b  vmovaps xmm9, [rsp+0x90]
00007a3fbe1de034  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1de03d  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1de046  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1de04f  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1de058  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1de061  add rsp, 0xF0
00007a3fbe1de068  pop r11
00007a3fbe1de06a  pop r10
00007a3fbe1de06c  pop r9
00007a3fbe1de06e  pop r8
00007a3fbe1de070  pop rsi
00007a3fbe1de071  pop rdi
00007a3fbe1de072  pop rdx
00007a3fbe1de073  pop rcx
00007a3fbe1de074  pop rax
00007a3fbe1de075  add rsp, 0x08
00007a3fbe1de079  jmp 0x00007A3FBE1D9758
00007a3fbe1de07e  sub rsp, 0x08
00007a3fbe1de082  push rax
00007a3fbe1de083  push rcx
00007a3fbe1de084  push rdx
00007a3fbe1de085  push rdi
00007a3fbe1de086  push rsi
00007a3fbe1de087  push r8
00007a3fbe1de089  push r9
00007a3fbe1de08b  push r10
00007a3fbe1de08d  push r11
00007a3fbe1de08f  sub rsp, 0xF0
00007a3fbe1de096  vmovaps [rsp], xmm0
00007a3fbe1de09b  vmovaps [rsp+0x10], xmm2
00007a3fbe1de0a1  vmovaps [rsp+0x20], xmm3
00007a3fbe1de0a7  vmovaps [rsp+0x30], xmm4
00007a3fbe1de0ad  vmovaps [rsp+0x40], xmm5
00007a3fbe1de0b3  vmovaps [rsp+0x50], xmm6
00007a3fbe1de0b9  vmovaps [rsp+0x60], xmm7
00007a3fbe1de0bf  vmovaps [rsp+0x70], xmm8
00007a3fbe1de0c5  vmovaps [rsp+0x80], xmm9
00007a3fbe1de0ce  vmovaps [rsp+0x90], xmm10
00007a3fbe1de0d7  vmovaps [rsp+0xA0], xmm11
00007a3fbe1de0e0  vmovaps [rsp+0xB0], xmm12
00007a3fbe1de0e9  vmovaps [rsp+0xC0], xmm13
00007a3fbe1de0f2  vmovaps [rsp+0xD0], xmm14
00007a3fbe1de0fb  vmovaps [rsp+0xE0], xmm15
00007a3fbe1de104  sub rsp, 0x30
00007a3fbe1de108  movaps [rsp], xmm1
00007a3fbe1de10c  movaps [rsp+0x10], xmm13
00007a3fbe1de112  movaps [rsp+0x20], xmm8
00007a3fbe1de118  lea rdi, [rsp]
00007a3fbe1de11c  mov esi, 0x00
00007a3fbe1de121  mov rax, 0x60D1084DB530
00007a3fbe1de12b  call rax
00007a3fbe1de12d  movaps xmm1, [rsp]
00007a3fbe1de131  add rsp, 0x30
00007a3fbe1de135  vmovaps xmm0, [rsp]
00007a3fbe1de13a  vmovaps xmm2, [rsp+0x10]
00007a3fbe1de140  vmovaps xmm3, [rsp+0x20]
00007a3fbe1de146  vmovaps xmm4, [rsp+0x30]
00007a3fbe1de14c  vmovaps xmm5, [rsp+0x40]
00007a3fbe1de152  vmovaps xmm6, [rsp+0x50]
00007a3fbe1de158  vmovaps xmm7, [rsp+0x60]
00007a3fbe1de15e  vmovaps xmm8, [rsp+0x70]
00007a3fbe1de164  vmovaps xmm9, [rsp+0x80]
00007a3fbe1de16d  vmovaps xmm10, [rsp+0x90]
00007a3fbe1de176  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1de17f  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1de188  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1de191  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1de19a  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1de1a3  add rsp, 0xF0
00007a3fbe1de1aa  pop r11
00007a3fbe1de1ac  pop r10
00007a3fbe1de1ae  pop r9
00007a3fbe1de1b0  pop r8
00007a3fbe1de1b2  pop rsi
00007a3fbe1de1b3  pop rdi
00007a3fbe1de1b4  pop rdx
00007a3fbe1de1b5  pop rcx
00007a3fbe1de1b6  pop rax
00007a3fbe1de1b7  add rsp, 0x08
00007a3fbe1de1bb  jmp 0x00007A3FBE1D977A
00007a3fbe1de1c0  call 0x00007A3FBE00C260
00007a3fbe1de1c5  jmp 0x00007A3FBE1D9788
00007a3fbe1de1ca  call 0x00007A3FBE0DE950
00007a3fbe1de1cf  jmp 0x00007A3FBE1D9792
00007a3fbe1de1d4  sub rsp, 0x08
00007a3fbe1de1d8  push rax
00007a3fbe1de1d9  push rcx
00007a3fbe1de1da  push rdx
00007a3fbe1de1db  push rdi
00007a3fbe1de1dc  push rsi
00007a3fbe1de1dd  push r8
00007a3fbe1de1df  push r9
00007a3fbe1de1e1  push r10
00007a3fbe1de1e3  push r11
00007a3fbe1de1e5  sub rsp, 0xF0
00007a3fbe1de1ec  vmovaps [rsp], xmm0
00007a3fbe1de1f1  vmovaps [rsp+0x10], xmm1
00007a3fbe1de1f7  vmovaps [rsp+0x20], xmm2
00007a3fbe1de1fd  vmovaps [rsp+0x30], xmm3
00007a3fbe1de203  vmovaps [rsp+0x40], xmm4
00007a3fbe1de209  vmovaps [rsp+0x50], xmm5
00007a3fbe1de20f  vmovaps [rsp+0x60], xmm6
00007a3fbe1de215  vmovaps [rsp+0x70], xmm7
00007a3fbe1de21b  vmovaps [rsp+0x80], xmm9
00007a3fbe1de224  vmovaps [rsp+0x90], xmm10
00007a3fbe1de22d  vmovaps [rsp+0xA0], xmm11
00007a3fbe1de236  vmovaps [rsp+0xB0], xmm12
00007a3fbe1de23f  vmovaps [rsp+0xC0], xmm13
00007a3fbe1de248  vmovaps [rsp+0xD0], xmm14
00007a3fbe1de251  vmovaps [rsp+0xE0], xmm15
00007a3fbe1de25a  sub rsp, 0x30
00007a3fbe1de25e  movaps [rsp], xmm8
00007a3fbe1de263  movaps [rsp+0x10], xmm15
00007a3fbe1de269  movaps [rsp+0x20], xmm7
00007a3fbe1de26e  lea rdi, [rsp]
00007a3fbe1de272  mov esi, 0x00
00007a3fbe1de277  mov rax, 0x60D1084DB530
00007a3fbe1de281  call rax
00007a3fbe1de283  movaps xmm8, [rsp]
00007a3fbe1de288  add rsp, 0x30
00007a3fbe1de28c  vmovaps xmm0, [rsp]
00007a3fbe1de291  vmovaps xmm1, [rsp+0x10]
00007a3fbe1de297  vmovaps xmm2, [rsp+0x20]
00007a3fbe1de29d  vmovaps xmm3, [rsp+0x30]
00007a3fbe1de2a3  vmovaps xmm4, [rsp+0x40]
00007a3fbe1de2a9  vmovaps xmm5, [rsp+0x50]
00007a3fbe1de2af  vmovaps xmm6, [rsp+0x60]
00007a3fbe1de2b5  vmovaps xmm7, [rsp+0x70]
00007a3fbe1de2bb  vmovaps xmm9, [rsp+0x80]
00007a3fbe1de2c4  vmovaps xmm10, [rsp+0x90]
00007a3fbe1de2cd  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1de2d6  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1de2df  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1de2e8  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1de2f1  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1de2fa  add rsp, 0xF0
00007a3fbe1de301  pop r11
00007a3fbe1de303  pop r10
00007a3fbe1de305  pop r9
00007a3fbe1de307  pop r8
00007a3fbe1de309  pop rsi
00007a3fbe1de30a  pop rdi
00007a3fbe1de30b  pop rdx
00007a3fbe1de30c  pop rcx
00007a3fbe1de30d  pop rax
00007a3fbe1de30e  add rsp, 0x08
00007a3fbe1de312  jmp 0x00007A3FBE1D97B4
00007a3fbe1de317  sub rsp, 0x08
00007a3fbe1de31b  push rax
00007a3fbe1de31c  push rcx
00007a3fbe1de31d  push rdx
00007a3fbe1de31e  push rdi
00007a3fbe1de31f  push rsi
00007a3fbe1de320  push r8
00007a3fbe1de322  push r9
00007a3fbe1de324  push r10
00007a3fbe1de326  push r11
00007a3fbe1de328  sub rsp, 0xF0
00007a3fbe1de32f  vmovaps [rsp], xmm0
00007a3fbe1de334  vmovaps [rsp+0x10], xmm1
00007a3fbe1de33a  vmovaps [rsp+0x20], xmm2
00007a3fbe1de340  vmovaps [rsp+0x30], xmm3
00007a3fbe1de346  vmovaps [rsp+0x40], xmm4
00007a3fbe1de34c  vmovaps [rsp+0x50], xmm5
00007a3fbe1de352  vmovaps [rsp+0x60], xmm6
00007a3fbe1de358  vmovaps [rsp+0x70], xmm8
00007a3fbe1de35e  vmovaps [rsp+0x80], xmm9
00007a3fbe1de367  vmovaps [rsp+0x90], xmm10
00007a3fbe1de370  vmovaps [rsp+0xA0], xmm11
00007a3fbe1de379  vmovaps [rsp+0xB0], xmm12
00007a3fbe1de382  vmovaps [rsp+0xC0], xmm13
00007a3fbe1de38b  vmovaps [rsp+0xD0], xmm14
00007a3fbe1de394  vmovaps [rsp+0xE0], xmm15
00007a3fbe1de39d  sub rsp, 0x30
00007a3fbe1de3a1  movaps [rsp], xmm7
00007a3fbe1de3a5  movaps [rsp+0x10], xmm9
00007a3fbe1de3ab  movaps [rsp+0x20], xmm15
00007a3fbe1de3b1  lea rdi, [rsp]
00007a3fbe1de3b5  mov esi, 0x00
00007a3fbe1de3ba  mov rax, 0x60D1084DB530
00007a3fbe1de3c4  call rax
00007a3fbe1de3c6  movaps xmm7, [rsp]
00007a3fbe1de3ca  add rsp, 0x30
00007a3fbe1de3ce  vmovaps xmm0, [rsp]
00007a3fbe1de3d3  vmovaps xmm1, [rsp+0x10]
00007a3fbe1de3d9  vmovaps xmm2, [rsp+0x20]
00007a3fbe1de3df  vmovaps xmm3, [rsp+0x30]
00007a3fbe1de3e5  vmovaps xmm4, [rsp+0x40]
00007a3fbe1de3eb  vmovaps xmm5, [rsp+0x50]
00007a3fbe1de3f1  vmovaps xmm6, [rsp+0x60]
00007a3fbe1de3f7  vmovaps xmm8, [rsp+0x70]
00007a3fbe1de3fd  vmovaps xmm9, [rsp+0x80]
00007a3fbe1de406  vmovaps xmm10, [rsp+0x90]
00007a3fbe1de40f  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1de418  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1de421  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1de42a  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1de433  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1de43c  add rsp, 0xF0
00007a3fbe1de443  pop r11
00007a3fbe1de445  pop r10
00007a3fbe1de447  pop r9
00007a3fbe1de449  pop r8
00007a3fbe1de44b  pop rsi
00007a3fbe1de44c  pop rdi
00007a3fbe1de44d  pop rdx
00007a3fbe1de44e  pop rcx
00007a3fbe1de44f  pop rax
00007a3fbe1de450  add rsp, 0x08
00007a3fbe1de454  jmp 0x00007A3FBE1D97E1
00007a3fbe1de459  sub rsp, 0x08
00007a3fbe1de45d  push rax
00007a3fbe1de45e  push rcx
00007a3fbe1de45f  push rdx
00007a3fbe1de460  push rdi
00007a3fbe1de461  push rsi
00007a3fbe1de462  push r8
00007a3fbe1de464  push r9
00007a3fbe1de466  push r10
00007a3fbe1de468  push r11
00007a3fbe1de46a  sub rsp, 0xF0
00007a3fbe1de471  vmovaps [rsp], xmm0
00007a3fbe1de476  vmovaps [rsp+0x10], xmm1
00007a3fbe1de47c  vmovaps [rsp+0x20], xmm2
00007a3fbe1de482  vmovaps [rsp+0x30], xmm3
00007a3fbe1de488  vmovaps [rsp+0x40], xmm4
00007a3fbe1de48e  vmovaps [rsp+0x50], xmm5
00007a3fbe1de494  vmovaps [rsp+0x60], xmm6
00007a3fbe1de49a  vmovaps [rsp+0x70], xmm7
00007a3fbe1de4a0  vmovaps [rsp+0x80], xmm8
00007a3fbe1de4a9  vmovaps [rsp+0x90], xmm10
00007a3fbe1de4b2  vmovaps [rsp+0xA0], xmm11
00007a3fbe1de4bb  vmovaps [rsp+0xB0], xmm12
00007a3fbe1de4c4  vmovaps [rsp+0xC0], xmm13
00007a3fbe1de4cd  vmovaps [rsp+0xD0], xmm14
00007a3fbe1de4d6  vmovaps [rsp+0xE0], xmm15
00007a3fbe1de4df  sub rsp, 0x30
00007a3fbe1de4e3  movaps [rsp], xmm9
00007a3fbe1de4e8  movaps [rsp+0x10], xmm13
00007a3fbe1de4ee  movaps [rsp+0x20], xmm15
00007a3fbe1de4f4  lea rdi, [rsp]
00007a3fbe1de4f8  mov esi, 0x00
00007a3fbe1de4fd  mov rax, 0x60D1084DB530
00007a3fbe1de507  call rax
00007a3fbe1de509  movaps xmm9, [rsp]
00007a3fbe1de50e  add rsp, 0x30
00007a3fbe1de512  vmovaps xmm0, [rsp]
00007a3fbe1de517  vmovaps xmm1, [rsp+0x10]
00007a3fbe1de51d  vmovaps xmm2, [rsp+0x20]
00007a3fbe1de523  vmovaps xmm3, [rsp+0x30]
00007a3fbe1de529  vmovaps xmm4, [rsp+0x40]
00007a3fbe1de52f  vmovaps xmm5, [rsp+0x50]
00007a3fbe1de535  vmovaps xmm6, [rsp+0x60]
00007a3fbe1de53b  vmovaps xmm7, [rsp+0x70]
00007a3fbe1de541  vmovaps xmm8, [rsp+0x80]
00007a3fbe1de54a  vmovaps xmm10, [rsp+0x90]
00007a3fbe1de553  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1de55c  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1de565  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1de56e  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1de577  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1de580  add rsp, 0xF0
00007a3fbe1de587  pop r11
00007a3fbe1de589  pop r10
00007a3fbe1de58b  pop r9
00007a3fbe1de58d  pop r8
00007a3fbe1de58f  pop rsi
00007a3fbe1de590  pop rdi
00007a3fbe1de591  pop rdx
00007a3fbe1de592  pop rcx
00007a3fbe1de593  pop rax
00007a3fbe1de594  add rsp, 0x08
00007a3fbe1de598  jmp 0x00007A3FBE1D980F
00007a3fbe1de59d  sub rsp, 0x08
00007a3fbe1de5a1  push rax
00007a3fbe1de5a2  push rcx
00007a3fbe1de5a3  push rdx
00007a3fbe1de5a4  push rdi
00007a3fbe1de5a5  push rsi
00007a3fbe1de5a6  push r8
00007a3fbe1de5a8  push r9
00007a3fbe1de5aa  push r10
00007a3fbe1de5ac  push r11
00007a3fbe1de5ae  sub rsp, 0xF0
00007a3fbe1de5b5  vmovaps [rsp], xmm0
00007a3fbe1de5ba  vmovaps [rsp+0x10], xmm1
00007a3fbe1de5c0  vmovaps [rsp+0x20], xmm2
00007a3fbe1de5c6  vmovaps [rsp+0x30], xmm3
00007a3fbe1de5cc  vmovaps [rsp+0x40], xmm4
00007a3fbe1de5d2  vmovaps [rsp+0x50], xmm5
00007a3fbe1de5d8  vmovaps [rsp+0x60], xmm6
00007a3fbe1de5de  vmovaps [rsp+0x70], xmm7
00007a3fbe1de5e4  vmovaps [rsp+0x80], xmm8
00007a3fbe1de5ed  vmovaps [rsp+0x90], xmm9
00007a3fbe1de5f6  vmovaps [rsp+0xA0], xmm10
00007a3fbe1de5ff  vmovaps [rsp+0xB0], xmm11
00007a3fbe1de608  vmovaps [rsp+0xC0], xmm12
00007a3fbe1de611  vmovaps [rsp+0xD0], xmm13
00007a3fbe1de61a  vmovaps [rsp+0xE0], xmm14
00007a3fbe1de623  sub rsp, 0x30
00007a3fbe1de627  movaps [rsp], xmm15
00007a3fbe1de62c  movaps [rsp+0x10], xmm11
00007a3fbe1de632  movaps [rsp+0x20], xmm12
00007a3fbe1de638  lea rdi, [rsp]
00007a3fbe1de63c  mov esi, 0x00
00007a3fbe1de641  mov rax, 0x60D1084DB530
00007a3fbe1de64b  call rax
00007a3fbe1de64d  movaps xmm15, [rsp]
00007a3fbe1de652  add rsp, 0x30
00007a3fbe1de656  vmovaps xmm0, [rsp]
00007a3fbe1de65b  vmovaps xmm1, [rsp+0x10]
00007a3fbe1de661  vmovaps xmm2, [rsp+0x20]
00007a3fbe1de667  vmovaps xmm3, [rsp+0x30]
00007a3fbe1de66d  vmovaps xmm4, [rsp+0x40]
00007a3fbe1de673  vmovaps xmm5, [rsp+0x50]
00007a3fbe1de679  vmovaps xmm6, [rsp+0x60]
00007a3fbe1de67f  vmovaps xmm7, [rsp+0x70]
00007a3fbe1de685  vmovaps xmm8, [rsp+0x80]
00007a3fbe1de68e  vmovaps xmm9, [rsp+0x90]
00007a3fbe1de697  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1de6a0  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1de6a9  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1de6b2  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1de6bb  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1de6c4  add rsp, 0xF0
00007a3fbe1de6cb  pop r11
00007a3fbe1de6cd  pop r10
00007a3fbe1de6cf  pop r9
00007a3fbe1de6d1  pop r8
00007a3fbe1de6d3  pop rsi
00007a3fbe1de6d4  pop rdi
00007a3fbe1de6d5  pop rdx
00007a3fbe1de6d6  pop rcx
00007a3fbe1de6d7  pop rax
00007a3fbe1de6d8  add rsp, 0x08
00007a3fbe1de6dc  jmp 0x00007A3FBE1D982A
00007a3fbe1de6e1  sub rsp, 0x08
00007a3fbe1de6e5  push rax
00007a3fbe1de6e6  push rcx
00007a3fbe1de6e7  push rdx
00007a3fbe1de6e8  push rdi
00007a3fbe1de6e9  push rsi
00007a3fbe1de6ea  push r8
00007a3fbe1de6ec  push r9
00007a3fbe1de6ee  push r10
00007a3fbe1de6f0  push r11
00007a3fbe1de6f2  sub rsp, 0xF0
00007a3fbe1de6f9  vmovaps [rsp], xmm0
00007a3fbe1de6fe  vmovaps [rsp+0x10], xmm1
00007a3fbe1de704  vmovaps [rsp+0x20], xmm2
00007a3fbe1de70a  vmovaps [rsp+0x30], xmm3
00007a3fbe1de710  vmovaps [rsp+0x40], xmm4
00007a3fbe1de716  vmovaps [rsp+0x50], xmm5
00007a3fbe1de71c  vmovaps [rsp+0x60], xmm6
00007a3fbe1de722  vmovaps [rsp+0x70], xmm7
00007a3fbe1de728  vmovaps [rsp+0x80], xmm8
00007a3fbe1de731  vmovaps [rsp+0x90], xmm9
00007a3fbe1de73a  vmovaps [rsp+0xA0], xmm10
00007a3fbe1de743  vmovaps [rsp+0xB0], xmm11
00007a3fbe1de74c  vmovaps [rsp+0xC0], xmm12
00007a3fbe1de755  vmovaps [rsp+0xD0], xmm14
00007a3fbe1de75e  vmovaps [rsp+0xE0], xmm15
00007a3fbe1de767  sub rsp, 0x30
00007a3fbe1de76b  movaps [rsp], xmm13
00007a3fbe1de770  movaps [rsp+0x10], xmm10
00007a3fbe1de776  movaps [rsp+0x20], xmm14
00007a3fbe1de77c  lea rdi, [rsp]
00007a3fbe1de780  mov esi, 0x00
00007a3fbe1de785  mov rax, 0x60D1084DB530
00007a3fbe1de78f  call rax
00007a3fbe1de791  movaps xmm13, [rsp]
00007a3fbe1de796  add rsp, 0x30
00007a3fbe1de79a  vmovaps xmm0, [rsp]
00007a3fbe1de79f  vmovaps xmm1, [rsp+0x10]
00007a3fbe1de7a5  vmovaps xmm2, [rsp+0x20]
00007a3fbe1de7ab  vmovaps xmm3, [rsp+0x30]
00007a3fbe1de7b1  vmovaps xmm4, [rsp+0x40]
00007a3fbe1de7b7  vmovaps xmm5, [rsp+0x50]
00007a3fbe1de7bd  vmovaps xmm6, [rsp+0x60]
00007a3fbe1de7c3  vmovaps xmm7, [rsp+0x70]
00007a3fbe1de7c9  vmovaps xmm8, [rsp+0x80]
00007a3fbe1de7d2  vmovaps xmm9, [rsp+0x90]
00007a3fbe1de7db  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1de7e4  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1de7ed  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1de7f6  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1de7ff  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1de808  add rsp, 0xF0
00007a3fbe1de80f  pop r11
00007a3fbe1de811  pop r10
00007a3fbe1de813  pop r9
00007a3fbe1de815  pop r8
00007a3fbe1de817  pop rsi
00007a3fbe1de818  pop rdi
00007a3fbe1de819  pop rdx
00007a3fbe1de81a  pop rcx
00007a3fbe1de81b  pop rax
00007a3fbe1de81c  add rsp, 0x08
00007a3fbe1de820  jmp 0x00007A3FBE1D984D
00007a3fbe1de825  sub rsp, 0x08
00007a3fbe1de829  push rax
00007a3fbe1de82a  push rcx
00007a3fbe1de82b  push rdx
00007a3fbe1de82c  push rdi
00007a3fbe1de82d  push rsi
00007a3fbe1de82e  push r8
00007a3fbe1de830  push r9
00007a3fbe1de832  push r10
00007a3fbe1de834  push r11
00007a3fbe1de836  sub rsp, 0xF0
00007a3fbe1de83d  vmovaps [rsp], xmm0
00007a3fbe1de842  vmovaps [rsp+0x10], xmm1
00007a3fbe1de848  vmovaps [rsp+0x20], xmm2
00007a3fbe1de84e  vmovaps [rsp+0x30], xmm3
00007a3fbe1de854  vmovaps [rsp+0x40], xmm4
00007a3fbe1de85a  vmovaps [rsp+0x50], xmm5
00007a3fbe1de860  vmovaps [rsp+0x60], xmm6
00007a3fbe1de866  vmovaps [rsp+0x70], xmm7
00007a3fbe1de86c  vmovaps [rsp+0x80], xmm8
00007a3fbe1de875  vmovaps [rsp+0x90], xmm9
00007a3fbe1de87e  vmovaps [rsp+0xA0], xmm10
00007a3fbe1de887  vmovaps [rsp+0xB0], xmm11
00007a3fbe1de890  vmovaps [rsp+0xC0], xmm12
00007a3fbe1de899  vmovaps [rsp+0xD0], xmm13
00007a3fbe1de8a2  vmovaps [rsp+0xE0], xmm15
00007a3fbe1de8ab  sub rsp, 0x30
00007a3fbe1de8af  movaps [rsp], xmm14
00007a3fbe1de8b4  movaps [rsp+0x10], xmm1
00007a3fbe1de8b9  movaps [rsp+0x20], xmm7
00007a3fbe1de8be  lea rdi, [rsp]
00007a3fbe1de8c2  mov esi, 0x00
00007a3fbe1de8c7  mov rax, 0x60D1084DB530
00007a3fbe1de8d1  call rax
00007a3fbe1de8d3  movaps xmm14, [rsp]
00007a3fbe1de8d8  add rsp, 0x30
00007a3fbe1de8dc  vmovaps xmm0, [rsp]
00007a3fbe1de8e1  vmovaps xmm1, [rsp+0x10]
00007a3fbe1de8e7  vmovaps xmm2, [rsp+0x20]
00007a3fbe1de8ed  vmovaps xmm3, [rsp+0x30]
00007a3fbe1de8f3  vmovaps xmm4, [rsp+0x40]
00007a3fbe1de8f9  vmovaps xmm5, [rsp+0x50]
00007a3fbe1de8ff  vmovaps xmm6, [rsp+0x60]
00007a3fbe1de905  vmovaps xmm7, [rsp+0x70]
00007a3fbe1de90b  vmovaps xmm8, [rsp+0x80]
00007a3fbe1de914  vmovaps xmm9, [rsp+0x90]
00007a3fbe1de91d  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1de926  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1de92f  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1de938  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1de941  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1de94a  add rsp, 0xF0
00007a3fbe1de951  pop r11
00007a3fbe1de953  pop r10
00007a3fbe1de955  pop r9
00007a3fbe1de957  pop r8
00007a3fbe1de959  pop rsi
00007a3fbe1de95a  pop rdi
00007a3fbe1de95b  pop rdx
00007a3fbe1de95c  pop rcx
00007a3fbe1de95d  pop rax
00007a3fbe1de95e  add rsp, 0x08
00007a3fbe1de962  jmp 0x00007A3FBE1D9870
00007a3fbe1de967  sub rsp, 0x08
00007a3fbe1de96b  push rax
00007a3fbe1de96c  push rcx
00007a3fbe1de96d  push rdx
00007a3fbe1de96e  push rdi
00007a3fbe1de96f  push rsi
00007a3fbe1de970  push r8
00007a3fbe1de972  push r9
00007a3fbe1de974  push r10
00007a3fbe1de976  push r11
00007a3fbe1de978  sub rsp, 0xF0
00007a3fbe1de97f  vmovaps [rsp], xmm0
00007a3fbe1de984  vmovaps [rsp+0x10], xmm2
00007a3fbe1de98a  vmovaps [rsp+0x20], xmm3
00007a3fbe1de990  vmovaps [rsp+0x30], xmm4
00007a3fbe1de996  vmovaps [rsp+0x40], xmm5
00007a3fbe1de99c  vmovaps [rsp+0x50], xmm6
00007a3fbe1de9a2  vmovaps [rsp+0x60], xmm7
00007a3fbe1de9a8  vmovaps [rsp+0x70], xmm8
00007a3fbe1de9ae  vmovaps [rsp+0x80], xmm9
00007a3fbe1de9b7  vmovaps [rsp+0x90], xmm10
00007a3fbe1de9c0  vmovaps [rsp+0xA0], xmm11
00007a3fbe1de9c9  vmovaps [rsp+0xB0], xmm12
00007a3fbe1de9d2  vmovaps [rsp+0xC0], xmm13
00007a3fbe1de9db  vmovaps [rsp+0xD0], xmm14
00007a3fbe1de9e4  vmovaps [rsp+0xE0], xmm15
00007a3fbe1de9ed  sub rsp, 0x30
00007a3fbe1de9f1  movaps [rsp], xmm1
00007a3fbe1de9f5  movaps [rsp+0x10], xmm8
00007a3fbe1de9fb  movaps [rsp+0x20], xmm9
00007a3fbe1dea01  lea rdi, [rsp]
00007a3fbe1dea05  mov esi, 0x00
00007a3fbe1dea0a  mov rax, 0x60D1084DB530
00007a3fbe1dea14  call rax
00007a3fbe1dea16  movaps xmm1, [rsp]
00007a3fbe1dea1a  add rsp, 0x30
00007a3fbe1dea1e  vmovaps xmm0, [rsp]
00007a3fbe1dea23  vmovaps xmm2, [rsp+0x10]
00007a3fbe1dea29  vmovaps xmm3, [rsp+0x20]
00007a3fbe1dea2f  vmovaps xmm4, [rsp+0x30]
00007a3fbe1dea35  vmovaps xmm5, [rsp+0x40]
00007a3fbe1dea3b  vmovaps xmm6, [rsp+0x50]
00007a3fbe1dea41  vmovaps xmm7, [rsp+0x60]
00007a3fbe1dea47  vmovaps xmm8, [rsp+0x70]
00007a3fbe1dea4d  vmovaps xmm9, [rsp+0x80]
00007a3fbe1dea56  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dea5f  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dea68  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dea71  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dea7a  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dea83  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dea8c  add rsp, 0xF0
00007a3fbe1dea93  pop r11
00007a3fbe1dea95  pop r10
00007a3fbe1dea97  pop r9
00007a3fbe1dea99  pop r8
00007a3fbe1dea9b  pop rsi
00007a3fbe1dea9c  pop rdi
00007a3fbe1dea9d  pop rdx
00007a3fbe1dea9e  pop rcx
00007a3fbe1dea9f  pop rax
00007a3fbe1deaa0  add rsp, 0x08
00007a3fbe1deaa4  jmp 0x00007A3FBE1D9892
00007a3fbe1deaa9  call 0x00007A3FBE0B3E40
00007a3fbe1deaae  jmp 0x00007A3FBE1D98A0
00007a3fbe1deab3  call 0x00007A3FBE00C380
00007a3fbe1deab8  jmp 0x00007A3FBE1D98AA
00007a3fbe1deabd  call 0x00007A3FBE00D600
00007a3fbe1deac2  jmp 0x00007A3FBE1D98B4
00007a3fbe1deac7  call 0x00007A3FBDFFF540
00007a3fbe1deacc  jmp 0x00007A3FBE1D98BE
00007a3fbe1dead1  int3
00007a3fbe1dead2  nop [rax+rax*1], ax
00007a3fbe1deadb  nop [rax+rax*1], eax
00007a3fbe1deae0  mov eax, [r15+0x48]
00007a3fbe1deae4  lea r14d, [eax+0x01]
00007a3fbe1deae9  mov [rsp+0x10], r14d
00007a3fbe1deaee  mov r14d, r14d
00007a3fbe1deaf1  mov [r15+0x48], r14
00007a3fbe1deaf5  xor eax, eax
00007a3fbe1deaf7  mov r14d, [rsp+0x10]
00007a3fbe1deafc  cmp r14d, 0x1F4
00007a3fbe1deb03  cmc
00007a3fbe1deb04  lahf
00007a3fbe1deb05  seto al
00007a3fbe1deb08  mov [r15+0x108], eax
00007a3fbe1deb0f  mov eax, [r15+0x108]
00007a3fbe1deb16  sahf
00007a3fbe1deb17  jnz 0x00007A3FBE1DEB49
00007a3fbe1deb19  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1deb21  jz 0x00007A3FBE1E4C90
00007a3fbe1deb27  nop [rax+rax*1], ax
00007a3fbe1deb30  nop [rax+rax*1], eax
00007a3fbe1deb38  mov eax, 0x4106DC
00007a3fbe1deb3d  mov [r15+0x100], rax
00007a3fbe1deb44  jmp 0x00007A3FBDFFE110
00007a3fbe1deb49  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1deb51  jz 0x00007A3FBE1DEB80
00007a3fbe1deb57  nop [rax+rax*1], ax
00007a3fbe1deb60  nop [rax+rax*1], eax
00007a3fbe1deb68  mov eax, 0x410500
00007a3fbe1deb6d  mov [r15+0x100], rax
00007a3fbe1deb74  jmp 0x00007A3FBDFFE110
00007a3fbe1deb79  int3
00007a3fbe1deb7a  int3
00007a3fbe1deb7b  nop [rax+rax*1], eax
00007a3fbe1deb80  mov rax, [r15+0x40]
00007a3fbe1deb84  movaps xmm1, [r15+0x1D0]
00007a3fbe1deb8c  vmovaps [rsp+0x10], xmm1
00007a3fbe1deb92  vmovaps xmm15, [rsp+0x10]
00007a3fbe1deb98  por xmm1, xmm15
00007a3fbe1deb9d  movaps xmm14, [r15+0x1A0]
00007a3fbe1deba5  vmovaps [rsp+0x10], xmm14
00007a3fbe1debab  vmovaps xmm13, [rsp+0x10]
00007a3fbe1debb1  por xmm14, xmm13
00007a3fbe1debb6  lea r14, [rax+0x30]
00007a3fbe1debba  mov r12, [r13+r14*1]
00007a3fbe1debbf  lea r14, [rax+0x38]
00007a3fbe1debc3  mov r11, [r13+r14*1]
00007a3fbe1debc8  movq xmm13, r12
00007a3fbe1debcd  movq xmm12, r11
00007a3fbe1debd2  movq xmm13, xmm13
00007a3fbe1debd7  vmovaps [rsp+0x10], xmm13
00007a3fbe1debdd  movq xmm13, xmm13
00007a3fbe1debe2  movaps [r15+0x130], xmm13
00007a3fbe1debea  movq xmm12, xmm12
00007a3fbe1debef  vmovaps [rsp+0x20], xmm12
00007a3fbe1debf5  movq xmm12, xmm12
00007a3fbe1debfa  movaps [r15+0x280], xmm12
00007a3fbe1dec02  movaps xmm13, [r15+0x270]
00007a3fbe1dec0a  vmovaps [rsp+0x30], xmm13
00007a3fbe1dec10  vmovaps xmm12, [rsp+0x30]
00007a3fbe1dec16  por xmm13, xmm12
00007a3fbe1dec1b  lea r14, [rax+0x20]
00007a3fbe1dec1f  mov r12, [r13+r14*1]
00007a3fbe1dec24  lea r14, [rax+0x28]
00007a3fbe1dec28  mov r11, [r13+r14*1]
00007a3fbe1dec2d  movq xmm12, r12
00007a3fbe1dec32  movq xmm11, r11
00007a3fbe1dec37  movq xmm12, xmm12
00007a3fbe1dec3c  vmovaps [rsp+0x30], xmm12
00007a3fbe1dec42  movq xmm12, xmm12
00007a3fbe1dec47  movaps [r15+0x150], xmm12
00007a3fbe1dec4f  movq xmm11, xmm11
00007a3fbe1dec54  vmovaps [rsp+0x40], xmm11
00007a3fbe1dec5a  movq xmm11, xmm11
00007a3fbe1dec5f  movaps [r15+0x140], xmm11
00007a3fbe1dec67  lea r14, [rax+0x10]
00007a3fbe1dec6b  mov r12, [r13+r14*1]
00007a3fbe1dec70  lea r14, [rax+0x18]
00007a3fbe1dec74  mov r11, [r13+r14*1]
00007a3fbe1dec79  movq xmm12, r12
00007a3fbe1dec7e  movq xmm11, r11
00007a3fbe1dec83  movq xmm12, xmm12
00007a3fbe1dec88  vmovaps [rsp+0x50], xmm12
00007a3fbe1dec8e  movq xmm12, xmm12
00007a3fbe1dec93  movaps [r15+0x170], xmm12
00007a3fbe1dec9b  movq xmm11, xmm11
00007a3fbe1deca0  vmovaps [rsp+0x60], xmm11
00007a3fbe1deca6  movq xmm11, xmm11
00007a3fbe1decab  movaps [r15+0x160], xmm11
00007a3fbe1decb3  mov r14, [r13+rax*1]
00007a3fbe1decb8  vmovq xmm12, r14
00007a3fbe1decbd  vpbroadcastq xmm12, xmm12
00007a3fbe1decc2  lea r14, [rax+0x08]
00007a3fbe1decc6  mov rax, [r13+r14*1]
00007a3fbe1deccb  movq xmm11, rax
00007a3fbe1decd0  movaps [r15+0x230], xmm11
00007a3fbe1decd8  mov rax, [r15+0xF8]
00007a3fbe1decdf  lea r14, [rax+0x50]
00007a3fbe1dece3  movups xmm11, [r13+r14*1]
00007a3fbe1dece9  lea r14, [rax+0x60]
00007a3fbe1deced  movups xmm10, [r13+r14*1]
00007a3fbe1decf3  lea r14, [rax+0x30]
00007a3fbe1decf7  movups xmm9, [r13+r14*1]
00007a3fbe1decfd  mov r14, [r15+0x50]
00007a3fbe1ded01  mov [r15+0x60], r14
00007a3fbe1ded05  mov qword ptr [r15+0x58], 0x40
00007a3fbe1ded0d  movaps xmm8, xmm12
00007a3fbe1ded11  mulpd xmm8, xmm15
00007a3fbe1ded16  vcmppd xmm7, xmm8, xmm8, 0x03
00007a3fbe1ded1c  ptest xmm7, xmm7
00007a3fbe1ded21  jnz 0x00007A3FBE1DFB4A
00007a3fbe1ded27  movq xmm15, qword ptr [r15+0x230]
00007a3fbe1ded30  vmovaps [rsp+0x70], xmm15
00007a3fbe1ded36  vpermilpd xmm15, xmm15, 0x00
00007a3fbe1ded3c  movaps xmm7, xmm9
00007a3fbe1ded40  mulpd xmm7, xmm15
00007a3fbe1ded45  vcmppd xmm6, xmm7, xmm7, 0x03
00007a3fbe1ded4a  ptest xmm6, xmm6
00007a3fbe1ded4f  jnz 0x00007A3FBE1DFC8E
00007a3fbe1ded55  vxorps xmm15, xmm15, xmm15
00007a3fbe1ded5a  vpbroadcastq xmm15, xmm15
00007a3fbe1ded5f  movaps xmm9, xmm12
00007a3fbe1ded63  mulpd xmm9, xmm10
00007a3fbe1ded68  vcmppd xmm6, xmm9, xmm9, 0x03
00007a3fbe1ded6e  ptest xmm6, xmm6
00007a3fbe1ded73  jnz 0x00007A3FBE1DFDD0
00007a3fbe1ded79  movaps xmm10, xmm12
00007a3fbe1ded7d  mulpd xmm10, xmm11
00007a3fbe1ded82  vcmppd xmm6, xmm10, xmm10, 0x03
00007a3fbe1ded88  ptest xmm6, xmm6
00007a3fbe1ded8d  jnz 0x00007A3FBE1DFF14
00007a3fbe1ded93  movaps xmm11, [r15+0x1F0]
00007a3fbe1ded9b  movaps xmm6, xmm12
00007a3fbe1ded9f  mulpd xmm6, xmm11
00007a3fbe1deda4  vcmppd xmm5, xmm6, xmm6, 0x03
00007a3fbe1deda9  ptest xmm5, xmm5
00007a3fbe1dedae  jnz 0x00007A3FBE1E0058
00007a3fbe1dedb4  movaps xmm12, [r15+0x2A0]
00007a3fbe1dedbc  vmovaps [rsp+0x80], xmm12
00007a3fbe1dedc5  vmovaps xmm11, [rsp+0x80]
00007a3fbe1dedce  por xmm12, xmm11
00007a3fbe1dedd3  movaps xmm11, [r15+0x250]
00007a3fbe1deddb  vmovaps [rsp+0x80], xmm11
00007a3fbe1dede4  vmovaps xmm5, [rsp+0x80]
00007a3fbe1deded  por xmm11, xmm5
00007a3fbe1dedf2  vmovaps xmm4, [rsp+0x70]
00007a3fbe1dedf8  vpermilpd xmm4, xmm4, 0x00
00007a3fbe1dedfe  movaps xmm3, xmm5
00007a3fbe1dee01  mulpd xmm3, xmm4
00007a3fbe1dee05  vcmppd xmm2, xmm3, xmm3, 0x03
00007a3fbe1dee0a  ptest xmm2, xmm2
00007a3fbe1dee0f  jnz 0x00007A3FBE1E019A
00007a3fbe1dee15  mov [rsp+0x80], rax
00007a3fbe1dee1d  xor eax, eax
00007a3fbe1dee1f  mov r12d, 0x40
00007a3fbe1dee25  mov r11d, 0x200
00007a3fbe1dee2b  cmp r12, r11
00007a3fbe1dee2e  cmc
00007a3fbe1dee2f  lahf
00007a3fbe1dee30  seto al
00007a3fbe1dee33  mov [r15+0x108], eax
00007a3fbe1dee3a  movaps xmm5, xmm8
00007a3fbe1dee3e  addpd xmm5, xmm15
00007a3fbe1dee43  vcmppd xmm4, xmm5, xmm5, 0x03
00007a3fbe1dee48  ptest xmm4, xmm4
00007a3fbe1dee4d  jnz 0x00007A3FBE1E02DA
00007a3fbe1dee53  movaps xmm8, [r15+0x1B0]
00007a3fbe1dee5b  movaps xmm4, xmm9
00007a3fbe1dee5f  addpd xmm4, xmm8
00007a3fbe1dee64  vcmppd xmm2, xmm4, xmm4, 0x03
00007a3fbe1dee69  ptest xmm2, xmm2
00007a3fbe1dee6e  jnz 0x00007A3FBE1E041C
00007a3fbe1dee74  movaps xmm9, xmm10
00007a3fbe1dee78  addpd xmm9, xmm8
00007a3fbe1dee7d  vcmppd xmm2, xmm9, xmm9, 0x03
00007a3fbe1dee83  ptest xmm2, xmm2
00007a3fbe1dee88  jnz 0x00007A3FBE1E055E
00007a3fbe1dee8e  movaps xmm10, [r15+0x2F0]
00007a3fbe1dee96  vmovaps [rsp+0x90], xmm10
00007a3fbe1dee9f  vmovaps xmm8, [rsp+0x90]
00007a3fbe1deea8  por xmm10, xmm8
00007a3fbe1deead  movaps xmm8, [r15+0x2E0]
00007a3fbe1deeb5  vmovaps [rsp+0x90], xmm8
00007a3fbe1deebe  vmovaps xmm2, [rsp+0x90]
00007a3fbe1deec7  por xmm8, xmm2
00007a3fbe1deecc  movaps xmm2, [r15+0x2D0]
00007a3fbe1deed4  vmovaps [rsp+0x90], xmm2
00007a3fbe1deedd  vmovaps [rsp+0xA0], xmm1
00007a3fbe1deee6  vmovaps xmm1, [rsp+0x90]
00007a3fbe1deeef  por xmm2, xmm1
00007a3fbe1deef3  movaps xmm1, [r15+0x200]
00007a3fbe1deefb  vmovaps [rsp+0x90], xmm1
00007a3fbe1def04  vmovaps [rsp+0xB0], xmm15
00007a3fbe1def0d  vmovaps xmm15, [rsp+0x90]
00007a3fbe1def16  por xmm1, xmm15
00007a3fbe1def1b  movaps xmm15, [r15+0x1C0]
00007a3fbe1def23  vmovaps [rsp+0x90], xmm15
00007a3fbe1def2c  vmovaps [rsp+0xC0], xmm1
00007a3fbe1def35  vmovaps xmm1, [rsp+0x90]
00007a3fbe1def3e  por xmm15, xmm1
00007a3fbe1def43  movaps xmm1, [r15+0x190]
00007a3fbe1def4b  vmovaps [rsp+0x90], xmm1
00007a3fbe1def54  vmovaps [rsp+0xD0], xmm15
00007a3fbe1def5d  vmovaps xmm15, [rsp+0x90]
00007a3fbe1def66  por xmm1, xmm15
00007a3fbe1def6b  movaps xmm15, [r15+0x300]
00007a3fbe1def73  vmovaps [rsp+0x90], xmm15
00007a3fbe1def7c  vmovaps [rsp+0xE0], xmm1
00007a3fbe1def85  vmovaps xmm1, [rsp+0x90]
00007a3fbe1def8e  por xmm15, xmm1
00007a3fbe1def93  mov rax, [rsp+0x80]
00007a3fbe1def9b  lea r12, [rax+0xA0]
00007a3fbe1defa2  movups xmm1, [r13+r12*1]
00007a3fbe1defa8  lea r12, [rax+0xB0]
00007a3fbe1defaf  vmovaps [rsp+0x80], xmm1
00007a3fbe1defb8  movups xmm1, [r13+r12*1]
00007a3fbe1defbe  vmovaps [rsp+0x90], xmm1
00007a3fbe1defc7  vmovaps [rsp+0xF0], xmm15
00007a3fbe1defd0  vmovaps xmm15, [rsp+0xB0]
00007a3fbe1defd9  vmovaps [rsp+0xB0], xmm14
00007a3fbe1defe2  movaps xmm1, xmm6
00007a3fbe1defe5  addpd xmm1, xmm15
00007a3fbe1defea  vcmppd xmm14, xmm1, xmm1, 0x03
00007a3fbe1defef  ptest xmm14, xmm14
00007a3fbe1deff5  jnz 0x00007A3FBE1E06B6
00007a3fbe1deffb  lea r12, [rax+0xF0]
00007a3fbe1df002  movups xmm15, [r13+r12*1]
00007a3fbe1df008  movaps xmm14, xmm4
00007a3fbe1df00c  addpd xmm14, xmm3
00007a3fbe1df011  vcmppd xmm6, xmm14, xmm14, 0x03
00007a3fbe1df017  ptest xmm6, xmm6
00007a3fbe1df01c  jnz 0x00007A3FBE1E0801
00007a3fbe1df022  movaps xmm6, xmm9
00007a3fbe1df026  addpd xmm6, xmm7
00007a3fbe1df02a  vcmppd xmm4, xmm6, xmm6, 0x03
00007a3fbe1df02f  ptest xmm4, xmm4
00007a3fbe1df034  jnz 0x00007A3FBE1E0943
00007a3fbe1df03a  vmovaps xmm9, [rsp+0x70]
00007a3fbe1df040  vpermilpd xmm9, xmm9, 0x00
00007a3fbe1df046  vmovaps xmm4, [rsp+0x90]
00007a3fbe1df04f  movaps xmm7, xmm4
00007a3fbe1df052  mulpd xmm7, xmm9
00007a3fbe1df057  vcmppd xmm3, xmm7, xmm7, 0x03
00007a3fbe1df05c  ptest xmm3, xmm3
00007a3fbe1df061  jnz 0x00007A3FBE1E0A84
00007a3fbe1df067  vmovaps xmm9, [rsp+0x50]
00007a3fbe1df06d  vpermilpd xmm9, xmm9, 0x00
00007a3fbe1df073  movaps xmm4, xmm15
00007a3fbe1df077  mulpd xmm4, xmm9
00007a3fbe1df07c  vcmppd xmm3, xmm4, xmm4, 0x03
00007a3fbe1df081  ptest xmm3, xmm3
00007a3fbe1df086  jnz 0x00007A3FBE1E0BC5
00007a3fbe1df08c  lea r12, [rax+0xE0]
00007a3fbe1df093  movups xmm15, [r13+r12*1]
00007a3fbe1df099  vmovaps xmm9, [rsp+0x70]
00007a3fbe1df09f  vpermilpd xmm9, xmm9, 0x00
00007a3fbe1df0a5  vmovaps [rsp+0x70], xmm1
00007a3fbe1df0ab  vmovaps xmm1, [rsp+0x80]
00007a3fbe1df0b4  vmovaps [rsp+0x80], xmm15
00007a3fbe1df0bd  movaps xmm3, xmm1
00007a3fbe1df0c0  mulpd xmm3, xmm9
00007a3fbe1df0c5  vcmppd xmm15, xmm3, xmm3, 0x03
00007a3fbe1df0ca  ptest xmm15, xmm15
00007a3fbe1df0d0  jnz 0x00007A3FBE1E0D11
00007a3fbe1df0d6  vmovaps xmm1, [rsp+0xF0]
00007a3fbe1df0df  vmovaps xmm15, [rsp+0xF0]
00007a3fbe1df0e8  por xmm1, xmm15
00007a3fbe1df0ed  movaps [r15+0x300], xmm1
00007a3fbe1df0f5  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1df0fe  vmovaps xmm9, [rsp+0xE0]
00007a3fbe1df107  por xmm15, xmm9
00007a3fbe1df10c  movaps [r15+0x190], xmm15
00007a3fbe1df114  vmovaps xmm9, [rsp+0x50]
00007a3fbe1df11a  vpermilpd xmm9, xmm9, 0x00
00007a3fbe1df120  vmovaps [rsp+0x90], xmm1
00007a3fbe1df129  vmovaps [rsp+0xE0], xmm15
00007a3fbe1df132  vmovaps xmm15, [rsp+0x80]
00007a3fbe1df13b  vmovaps [rsp+0x80], xmm14
00007a3fbe1df144  movaps xmm1, xmm15
00007a3fbe1df148  mulpd xmm1, xmm9
00007a3fbe1df14d  vcmppd xmm14, xmm1, xmm1, 0x03
00007a3fbe1df152  ptest xmm14, xmm14
00007a3fbe1df158  jnz 0x00007A3FBE1E0E52
00007a3fbe1df15e  lea r12, [rax+0x90]
00007a3fbe1df165  movups xmm15, [r13+r12*1]
00007a3fbe1df16b  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1df174  vmovaps xmm9, [rsp+0xD0]
00007a3fbe1df17d  por xmm14, xmm9
00007a3fbe1df182  movaps [r15+0x1C0], xmm14
00007a3fbe1df18a  vmovaps xmm9, [rsp+0xC0]
00007a3fbe1df193  vmovaps [rsp+0xD0], xmm1
00007a3fbe1df19c  vmovaps xmm1, [rsp+0xC0]
00007a3fbe1df1a5  por xmm9, xmm1
00007a3fbe1df1aa  movaps [r15+0x200], xmm9
00007a3fbe1df1b2  vmovaps [rsp+0xC0], xmm2
00007a3fbe1df1bb  vmovaps xmm1, [rsp+0xC0]
00007a3fbe1df1c4  por xmm2, xmm1
00007a3fbe1df1c8  movaps [r15+0x2D0], xmm2
00007a3fbe1df1d0  vmovaps [rsp+0xC0], xmm8
00007a3fbe1df1d9  vmovaps xmm1, [rsp+0xC0]
00007a3fbe1df1e2  por xmm8, xmm1
00007a3fbe1df1e7  movaps [r15+0x2E0], xmm8
00007a3fbe1df1ef  vmovaps [rsp+0xC0], xmm15
00007a3fbe1df1f8  movaps xmm1, xmm5
00007a3fbe1df1fb  addpd xmm1, xmm7
00007a3fbe1df1ff  vcmppd xmm15, xmm1, xmm1, 0x03
00007a3fbe1df204  ptest xmm15, xmm15
00007a3fbe1df20a  jnz 0x00007A3FBE1E0F9E
00007a3fbe1df210  vmovaps xmm15, [rsp+0x50]
00007a3fbe1df216  vpermilpd xmm15, xmm15, 0x00
00007a3fbe1df21c  vmovaps xmm5, [rsp+0xC0]
00007a3fbe1df225  vmovaps [rsp+0xC0], xmm1
00007a3fbe1df22e  movaps xmm7, xmm5
00007a3fbe1df231  mulpd xmm7, xmm15
00007a3fbe1df236  vcmppd xmm1, xmm7, xmm7, 0x03
00007a3fbe1df23b  ptest xmm1, xmm1
00007a3fbe1df240  jnz 0x00007A3FBE1E10DE
00007a3fbe1df246  lea r12, [rax+0x80]
00007a3fbe1df24d  movups xmm1, [r13+r12*1]
00007a3fbe1df253  vmovaps xmm5, [rsp+0x70]
00007a3fbe1df259  vmovaps [rsp+0x70], xmm1
00007a3fbe1df25f  movaps xmm15, xmm5
00007a3fbe1df263  addpd xmm15, xmm3
00007a3fbe1df268  vcmppd xmm1, xmm15, xmm15, 0x03
00007a3fbe1df26e  ptest xmm1, xmm1
00007a3fbe1df273  jnz 0x00007A3FBE1E1229
00007a3fbe1df279  vmovaps xmm5, [rsp+0x80]
00007a3fbe1df282  movaps xmm1, xmm5
00007a3fbe1df285  addpd xmm1, xmm4
00007a3fbe1df289  vcmppd xmm3, xmm1, xmm1, 0x03
00007a3fbe1df28e  ptest xmm3, xmm3
00007a3fbe1df293  jnz 0x00007A3FBE1E136B
00007a3fbe1df299  vmovaps [rsp+0x80], xmm10
00007a3fbe1df2a2  vmovaps xmm5, [rsp+0x80]
00007a3fbe1df2ab  por xmm10, xmm5
00007a3fbe1df2b0  movaps [r15+0x2F0], xmm10
00007a3fbe1df2b8  vmovaps xmm5, [rsp+0x50]
00007a3fbe1df2be  vpermilpd xmm5, xmm5, 0x00
00007a3fbe1df2c4  vmovaps xmm3, [rsp+0x70]
00007a3fbe1df2ca  vmovaps [rsp+0x50], xmm1
00007a3fbe1df2d0  movaps xmm4, xmm3
00007a3fbe1df2d3  mulpd xmm4, xmm5
00007a3fbe1df2d7  vcmppd xmm1, xmm4, xmm4, 0x03
00007a3fbe1df2dc  ptest xmm1, xmm1
00007a3fbe1df2e1  jnz 0x00007A3FBE1E14AB
00007a3fbe1df2e7  lea r12, [rax+0xD0]
00007a3fbe1df2ee  movups xmm1, [r13+r12*1]
00007a3fbe1df2f4  vmovaps xmm3, [rsp+0xD0]
00007a3fbe1df2fd  vmovaps [rsp+0x70], xmm1
00007a3fbe1df303  movaps xmm5, xmm6
00007a3fbe1df306  addpd xmm5, xmm3
00007a3fbe1df30a  vcmppd xmm1, xmm5, xmm5, 0x03
00007a3fbe1df30f  ptest xmm1, xmm1
00007a3fbe1df314  jnz 0x00007A3FBE1E15F5
00007a3fbe1df31a  vmovaps xmm1, [rsp+0x60]
00007a3fbe1df320  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1df326  movaps xmm6, xmm9
00007a3fbe1df32a  mulpd xmm6, xmm1
00007a3fbe1df32e  vcmppd xmm3, xmm6, xmm6, 0x03
00007a3fbe1df333  ptest xmm3, xmm3
00007a3fbe1df338  jnz 0x00007A3FBE1E1735
00007a3fbe1df33e  movaps [r15+0x260], xmm6
00007a3fbe1df346  vxorps xmm1, xmm1, xmm1
00007a3fbe1df34a  vpbroadcastq xmm1, xmm1
00007a3fbe1df34f  movaps [r15+0x1B0], xmm1
00007a3fbe1df357  vmovaps xmm1, [rsp+0x60]
00007a3fbe1df35d  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1df363  vmovaps xmm3, [rsp+0x70]
00007a3fbe1df369  vmovaps [rsp+0x70], xmm15
00007a3fbe1df36f  movaps xmm9, xmm3
00007a3fbe1df373  mulpd xmm9, xmm1
00007a3fbe1df378  vcmppd xmm15, xmm9, xmm9, 0x03
00007a3fbe1df37e  ptest xmm15, xmm15
00007a3fbe1df384  jnz 0x00007A3FBE1E1876
00007a3fbe1df38a  lea r12, [rax+0xC0]
00007a3fbe1df391  movups xmm1, [r13+r12*1]
00007a3fbe1df397  vmovaps xmm3, [rsp+0xC0]
00007a3fbe1df3a0  vmovaps [rsp+0x80], xmm1
00007a3fbe1df3a9  movaps xmm15, xmm3
00007a3fbe1df3ad  addpd xmm15, xmm7
00007a3fbe1df3b2  vcmppd xmm1, xmm15, xmm15, 0x03
00007a3fbe1df3b8  ptest xmm1, xmm1
00007a3fbe1df3bd  jnz 0x00007A3FBE1E19C2
00007a3fbe1df3c3  vmovaps [rsp+0xC0], xmm13
00007a3fbe1df3cc  vmovaps xmm1, [rsp+0xC0]
00007a3fbe1df3d5  por xmm13, xmm1
00007a3fbe1df3da  movaps [r15+0x270], xmm13
00007a3fbe1df3e2  vmovaps xmm1, [rsp+0xB0]
00007a3fbe1df3eb  vmovaps xmm7, [rsp+0xB0]
00007a3fbe1df3f4  por xmm1, xmm7
00007a3fbe1df3f8  movaps [r15+0x1A0], xmm1
00007a3fbe1df400  vmovaps xmm1, [rsp+0x60]
00007a3fbe1df406  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1df40c  vmovaps [rsp+0xB0], xmm1
00007a3fbe1df415  vmovaps xmm1, [rsp+0x80]
00007a3fbe1df41e  vmovaps [rsp+0x80], xmm15
00007a3fbe1df427  vmovaps xmm15, [rsp+0xB0]
00007a3fbe1df430  vmovaps [rsp+0xB0], xmm14
00007a3fbe1df439  movaps xmm3, xmm1
00007a3fbe1df43c  mulpd xmm3, xmm15
00007a3fbe1df441  vcmppd xmm14, xmm3, xmm3, 0x03
00007a3fbe1df446  ptest xmm14, xmm14
00007a3fbe1df44c  jnz 0x00007A3FBE1E1B04
00007a3fbe1df452  lea r12, [rax+0x20]
00007a3fbe1df456  movups xmm1, [r13+r12*1]
00007a3fbe1df45c  movaps [r15+0x110], xmm1
00007a3fbe1df464  vmovaps xmm14, [rsp+0x70]
00007a3fbe1df46a  vmovaps [rsp+0x70], xmm1
00007a3fbe1df470  movaps xmm15, xmm14
00007a3fbe1df474  addpd xmm15, xmm4
00007a3fbe1df479  vcmppd xmm1, xmm15, xmm15, 0x03
00007a3fbe1df47f  ptest xmm1, xmm1
00007a3fbe1df484  jnz 0x00007A3FBE1E1C4F
00007a3fbe1df48a  vmovaps xmm1, [rsp+0x60]
00007a3fbe1df490  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1df496  movaps xmm14, xmm2
00007a3fbe1df49a  mulpd xmm14, xmm1
00007a3fbe1df49f  vcmppd xmm4, xmm14, xmm14, 0x03
00007a3fbe1df4a5  ptest xmm4, xmm4
00007a3fbe1df4aa  jnz 0x00007A3FBE1E1D92
00007a3fbe1df4b0  vmovaps xmm4, [rsp+0x50]
00007a3fbe1df4b6  movaps xmm1, xmm4
00007a3fbe1df4b9  addpd xmm1, xmm9
00007a3fbe1df4be  vcmppd xmm2, xmm1, xmm1, 0x03
00007a3fbe1df4c3  ptest xmm2, xmm2
00007a3fbe1df4c8  jnz 0x00007A3FBE1E1ED4
00007a3fbe1df4ce  vmovaps xmm9, [rsp+0x30]
00007a3fbe1df4d4  vpermilpd xmm9, xmm9, 0x00
00007a3fbe1df4da  vmovaps xmm2, [rsp+0x70]
00007a3fbe1df4e0  vmovaps [rsp+0x50], xmm1
00007a3fbe1df4e6  movaps xmm4, xmm2
00007a3fbe1df4e9  mulpd xmm4, xmm9
00007a3fbe1df4ee  vcmppd xmm1, xmm4, xmm4, 0x03
00007a3fbe1df4f3  ptest xmm1, xmm1
00007a3fbe1df4f8  jnz 0x00007A3FBE1E2015
00007a3fbe1df4fe  vmovaps xmm1, [rsp+0x30]
00007a3fbe1df504  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1df50a  vmovaps xmm2, [rsp+0x90]
00007a3fbe1df513  vmovaps [rsp+0x60], xmm15
00007a3fbe1df519  movaps xmm9, xmm2
00007a3fbe1df51d  mulpd xmm9, xmm1
00007a3fbe1df522  vcmppd xmm15, xmm9, xmm9, 0x03
00007a3fbe1df528  ptest xmm15, xmm15
00007a3fbe1df52e  jnz 0x00007A3FBE1E2156
00007a3fbe1df534  vmovaps xmm15, [rsp+0x80]
00007a3fbe1df53d  movaps xmm1, xmm15
00007a3fbe1df541  addpd xmm1, xmm6
00007a3fbe1df545  vcmppd xmm2, xmm1, xmm1, 0x03
00007a3fbe1df54a  ptest xmm2, xmm2
00007a3fbe1df54f  jnz 0x00007A3FBE1E2298
00007a3fbe1df555  movaps xmm15, xmm5
00007a3fbe1df559  addpd xmm15, xmm3
00007a3fbe1df55e  vcmppd xmm6, xmm15, xmm15, 0x03
00007a3fbe1df564  ptest xmm6, xmm6
00007a3fbe1df569  jnz 0x00007A3FBE1E23D9
00007a3fbe1df56f  vmovaps xmm6, [rsp+0x30]
00007a3fbe1df575  vpermilpd xmm6, xmm6, 0x00
00007a3fbe1df57b  movaps xmm5, xmm8
00007a3fbe1df57f  mulpd xmm5, xmm6
00007a3fbe1df583  vcmppd xmm3, xmm5, xmm5, 0x03
00007a3fbe1df588  ptest xmm3, xmm3
00007a3fbe1df58d  jnz 0x00007A3FBE1E251B
00007a3fbe1df593  vmovaps xmm8, [rsp+0x30]
00007a3fbe1df599  vpermilpd xmm8, xmm8, 0x00
00007a3fbe1df59f  movaps xmm6, xmm10
00007a3fbe1df5a3  mulpd xmm6, xmm8
00007a3fbe1df5a8  vcmppd xmm3, xmm6, xmm6, 0x03
00007a3fbe1df5ad  ptest xmm3, xmm3
00007a3fbe1df5b2  jnz 0x00007A3FBE1E265C
00007a3fbe1df5b8  vmovaps xmm8, [rsp+0x60]
00007a3fbe1df5be  movaps xmm10, xmm8
00007a3fbe1df5c2  addpd xmm10, xmm14
00007a3fbe1df5c7  vcmppd xmm3, xmm10, xmm10, 0x03
00007a3fbe1df5cd  ptest xmm3, xmm3
00007a3fbe1df5d2  jnz 0x00007A3FBE1E279E
00007a3fbe1df5d8  vmovaps xmm8, [rsp+0x50]
00007a3fbe1df5de  movaps xmm14, xmm8
00007a3fbe1df5e2  addpd xmm14, xmm4
00007a3fbe1df5e7  vcmppd xmm3, xmm14, xmm14, 0x03
00007a3fbe1df5ed  ptest xmm3, xmm3
00007a3fbe1df5f2  jnz 0x00007A3FBE1E28E2
00007a3fbe1df5f8  vmovaps xmm8, [rsp+0x40]
00007a3fbe1df5fe  vpermilpd xmm8, xmm8, 0x00
00007a3fbe1df604  movaps xmm4, xmm13
00007a3fbe1df608  mulpd xmm4, xmm8
00007a3fbe1df60d  vcmppd xmm3, xmm4, xmm4, 0x03
00007a3fbe1df612  ptest xmm3, xmm3
00007a3fbe1df617  jnz 0x00007A3FBE1E2A25
00007a3fbe1df61d  movaps xmm13, xmm15
00007a3fbe1df621  addpd xmm13, xmm9
00007a3fbe1df626  vcmppd xmm8, xmm13, xmm13, 0x03
00007a3fbe1df62c  ptest xmm8, xmm8
00007a3fbe1df632  jnz 0x00007A3FBE1E2B67
00007a3fbe1df638  movaps xmm15, xmm1
00007a3fbe1df63c  addpd xmm15, xmm5
00007a3fbe1df641  vcmppd xmm9, xmm15, xmm15, 0x03
00007a3fbe1df647  ptest xmm9, xmm9
00007a3fbe1df64d  jnz 0x00007A3FBE1E2CAB
00007a3fbe1df653  vmovaps [rsp+0x30], xmm11
00007a3fbe1df659  vmovaps xmm1, [rsp+0x30]
00007a3fbe1df65f  por xmm11, xmm1
00007a3fbe1df664  movaps [r15+0x250], xmm11
00007a3fbe1df66c  vmovaps [rsp+0x30], xmm12
00007a3fbe1df672  vmovaps xmm1, [rsp+0x30]
00007a3fbe1df678  por xmm12, xmm1
00007a3fbe1df67d  movaps [r15+0x2A0], xmm12
00007a3fbe1df685  vmovaps xmm1, [rsp+0xA0]
00007a3fbe1df68e  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1df697  por xmm1, xmm11
00007a3fbe1df69c  movaps [r15+0x1D0], xmm1
00007a3fbe1df6a4  lea r12, [rax+0x40]
00007a3fbe1df6a8  movups xmm1, [r13+r12*1]
00007a3fbe1df6ae  movaps [r15+0x2C0], xmm1
00007a3fbe1df6b6  vmovaps xmm11, [rsp+0x40]
00007a3fbe1df6bc  vpermilpd xmm11, xmm11, 0x00
00007a3fbe1df6c2  vmovaps xmm8, [rsp+0xE0]
00007a3fbe1df6cb  movaps xmm9, xmm8
00007a3fbe1df6cf  mulpd xmm9, xmm11
00007a3fbe1df6d4  vcmppd xmm5, xmm9, xmm9, 0x03
00007a3fbe1df6da  ptest xmm5, xmm5
00007a3fbe1df6df  jnz 0x00007A3FBE1E2DF7
00007a3fbe1df6e5  movaps xmm11, xmm10
00007a3fbe1df6e9  addpd xmm11, xmm6
00007a3fbe1df6ee  vcmppd xmm8, xmm11, xmm11, 0x03
00007a3fbe1df6f4  ptest xmm8, xmm8
00007a3fbe1df6fa  jnz 0x00007A3FBE1E2F3B
00007a3fbe1df700  movaps xmm10, xmm14
00007a3fbe1df704  addpd xmm10, xmm4
00007a3fbe1df709  vcmppd xmm8, xmm10, xmm10, 0x03
00007a3fbe1df70f  ptest xmm8, xmm8
00007a3fbe1df715  jnz 0x00007A3FBE1E307E
00007a3fbe1df71b  vmovaps xmm14, [rsp+0x40]
00007a3fbe1df721  vpermilpd xmm14, xmm14, 0x00
00007a3fbe1df727  movaps xmm8, xmm1
00007a3fbe1df72b  mulpd xmm8, xmm14
00007a3fbe1df730  vcmppd xmm6, xmm8, xmm8, 0x03
00007a3fbe1df736  ptest xmm6, xmm6
00007a3fbe1df73b  jnz 0x00007A3FBE1E31C1
00007a3fbe1df741  movaps xmm1, [r15+0x2B0]
00007a3fbe1df749  vmovaps xmm14, [rsp+0x40]
00007a3fbe1df74f  vpermilpd xmm14, xmm14, 0x00
00007a3fbe1df755  movaps xmm6, xmm1
00007a3fbe1df758  mulpd xmm6, xmm14
00007a3fbe1df75d  vcmppd xmm5, xmm6, xmm6, 0x03
00007a3fbe1df762  ptest xmm5, xmm5
00007a3fbe1df767  jnz 0x00007A3FBE1E3304
00007a3fbe1df76d  vmovaps xmm1, [rsp+0x10]
00007a3fbe1df773  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1df779  movaps xmm14, xmm12
00007a3fbe1df77d  mulpd xmm14, xmm1
00007a3fbe1df782  vcmppd xmm5, xmm14, xmm14, 0x03
00007a3fbe1df788  ptest xmm5, xmm5
00007a3fbe1df78d  jnz 0x00007A3FBE1E3445
00007a3fbe1df793  movaps xmm1, xmm13
00007a3fbe1df797  addpd xmm1, xmm9
00007a3fbe1df79c  vcmppd xmm12, xmm1, xmm1, 0x03
00007a3fbe1df7a1  ptest xmm12, xmm12
00007a3fbe1df7a7  jnz 0x00007A3FBE1E3588
00007a3fbe1df7ad  vmovaps xmm13, [rsp+0x10]
00007a3fbe1df7b3  vpermilpd xmm13, xmm13, 0x00
00007a3fbe1df7b9  movaps xmm12, xmm7
00007a3fbe1df7bd  mulpd xmm12, xmm13
00007a3fbe1df7c2  vcmppd xmm9, xmm12, xmm12, 0x03
00007a3fbe1df7c8  ptest xmm9, xmm9
00007a3fbe1df7ce  jnz 0x00007A3FBE1E36CA
00007a3fbe1df7d4  movaps xmm13, xmm15
00007a3fbe1df7d8  addpd xmm13, xmm8
00007a3fbe1df7dd  vcmppd xmm9, xmm13, xmm13, 0x03
00007a3fbe1df7e3  ptest xmm9, xmm9
00007a3fbe1df7e9  jnz 0x00007A3FBE1E380D
00007a3fbe1df7ef  movaps xmm15, [r15+0x290]
00007a3fbe1df7f7  vmovaps xmm9, [rsp+0x10]
00007a3fbe1df7fd  vpermilpd xmm9, xmm9, 0x00
00007a3fbe1df803  movaps xmm8, xmm15
00007a3fbe1df807  mulpd xmm8, xmm9
00007a3fbe1df80c  vcmppd xmm7, xmm8, xmm8, 0x03
00007a3fbe1df812  ptest xmm7, xmm7
00007a3fbe1df817  jnz 0x00007A3FBE1E3951
00007a3fbe1df81d  movaps xmm15, xmm11
00007a3fbe1df821  addpd xmm15, xmm6
00007a3fbe1df826  vcmppd xmm9, xmm15, xmm15, 0x03
00007a3fbe1df82c  ptest xmm9, xmm9
00007a3fbe1df832  jnz 0x00007A3FBE1E3A95
00007a3fbe1df838  movaps xmm11, [r15+0x1E0]
00007a3fbe1df840  vmovaps xmm9, [rsp+0x10]
00007a3fbe1df846  vpermilpd xmm9, xmm9, 0x00
00007a3fbe1df84c  movaps xmm7, xmm11
00007a3fbe1df850  mulpd xmm7, xmm9
00007a3fbe1df855  vcmppd xmm6, xmm7, xmm7, 0x03
00007a3fbe1df85a  ptest xmm6, xmm6
00007a3fbe1df85f  jnz 0x00007A3FBE1E3BD8
00007a3fbe1df865  movaps xmm11, xmm10
00007a3fbe1df869  addpd xmm11, xmm14
00007a3fbe1df86e  vcmppd xmm9, xmm11, xmm11, 0x03
00007a3fbe1df874  ptest xmm9, xmm9
00007a3fbe1df87a  jnz 0x00007A3FBE1E3D1A
00007a3fbe1df880  lea r12, [rax+0x70]
00007a3fbe1df884  movups xmm14, [r13+r12*1]
00007a3fbe1df88a  movaps [r15+0x240], xmm14
00007a3fbe1df892  movaps xmm10, xmm1
00007a3fbe1df896  addpd xmm10, xmm12
00007a3fbe1df89b  vcmppd xmm9, xmm10, xmm10, 0x03
00007a3fbe1df8a1  ptest xmm9, xmm9
00007a3fbe1df8a7  jnz 0x00007A3FBE1E3E68
00007a3fbe1df8ad  movaps [r15+0x170], xmm10
00007a3fbe1df8b5  vmovaps xmm1, [rsp+0x20]
00007a3fbe1df8bb  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1df8c1  movaps xmm12, xmm14
00007a3fbe1df8c5  mulpd xmm12, xmm1
00007a3fbe1df8ca  vcmppd xmm9, xmm12, xmm12, 0x03
00007a3fbe1df8d0  ptest xmm9, xmm9
00007a3fbe1df8d6  jnz 0x00007A3FBE1E3FAB
00007a3fbe1df8dc  vmovaps xmm1, [rsp+0x20]
00007a3fbe1df8e2  vpermilpd xmm1, xmm1, 0x00
00007a3fbe1df8e8  vmovaps xmm9, [rsp+0xB0]
00007a3fbe1df8f1  movaps xmm14, xmm9
00007a3fbe1df8f5  mulpd xmm14, xmm1
00007a3fbe1df8fa  vcmppd xmm6, xmm14, xmm14, 0x03
00007a3fbe1df900  ptest xmm6, xmm6
00007a3fbe1df905  jnz 0x00007A3FBE1E40EE
00007a3fbe1df90b  movaps [r15+0x180], xmm14
00007a3fbe1df913  movaps xmm1, xmm13
00007a3fbe1df917  addpd xmm1, xmm8
00007a3fbe1df91c  vcmppd xmm9, xmm1, xmm1, 0x03
00007a3fbe1df921  ptest xmm9, xmm9
00007a3fbe1df927  jnz 0x00007A3FBE1E4231
00007a3fbe1df92d  movaps [r15+0x210], xmm1
00007a3fbe1df935  movups xmm13, [r13+rax*1]
00007a3fbe1df93b  lea r12, [rax+0x10]
00007a3fbe1df93f  movups xmm9, [r13+r12*1]
00007a3fbe1df945  movaps [r15+0x230], xmm9
00007a3fbe1df94d  movaps xmm8, xmm15
00007a3fbe1df951  addpd xmm8, xmm7
00007a3fbe1df956  vcmppd xmm6, xmm8, xmm8, 0x03
00007a3fbe1df95c  ptest xmm6, xmm6
00007a3fbe1df961  jnz 0x00007A3FBE1E4387
00007a3fbe1df967  movaps [r15+0x130], xmm8
00007a3fbe1df96f  vmovaps xmm15, [rsp+0x20]
00007a3fbe1df975  vpermilpd xmm15, xmm15, 0x00
00007a3fbe1df97b  movaps xmm7, xmm9
00007a3fbe1df97f  mulpd xmm7, xmm15
00007a3fbe1df984  vcmppd xmm6, xmm7, xmm7, 0x03
00007a3fbe1df989  ptest xmm6, xmm6
00007a3fbe1df98e  jnz 0x00007A3FBE1E44CA
00007a3fbe1df994  movaps [r15+0x220], xmm7
00007a3fbe1df99c  vmovaps xmm15, [rsp+0x20]
00007a3fbe1df9a2  vpermilpd xmm15, xmm15, 0x00
00007a3fbe1df9a8  movaps xmm9, xmm13
00007a3fbe1df9ac  mulpd xmm9, xmm15
00007a3fbe1df9b1  vcmppd xmm6, xmm9, xmm9, 0x03
00007a3fbe1df9b7  ptest xmm6, xmm6
00007a3fbe1df9bc  jnz 0x00007A3FBE1E460C
00007a3fbe1df9c2  movaps xmm15, xmm11
00007a3fbe1df9c6  addpd xmm15, xmm12
00007a3fbe1df9cb  vcmppd xmm13, xmm15, xmm15, 0x03
00007a3fbe1df9d1  ptest xmm13, xmm13
00007a3fbe1df9d7  jnz 0x00007A3FBE1E4750
00007a3fbe1df9dd  movaps [r15+0x140], xmm15
00007a3fbe1df9e5  movaps xmm13, xmm10
00007a3fbe1df9e9  addpd xmm13, xmm14
00007a3fbe1df9ee  vcmppd xmm12, xmm13, xmm13, 0x03
00007a3fbe1df9f4  ptest xmm12, xmm12
00007a3fbe1df9fa  jnz 0x00007A3FBE1E4894
00007a3fbe1dfa00  movaps [r15+0x150], xmm13
00007a3fbe1dfa08  movaps xmm14, xmm1
00007a3fbe1dfa0c  addpd xmm14, xmm7
00007a3fbe1dfa11  vcmppd xmm12, xmm14, xmm14, 0x03
00007a3fbe1dfa17  ptest xmm12, xmm12
00007a3fbe1dfa1d  jnz 0x00007A3FBE1E49D8
00007a3fbe1dfa23  movaps [r15+0x160], xmm14
00007a3fbe1dfa2b  movaps xmm1, xmm8
00007a3fbe1dfa2f  addpd xmm1, xmm9
00007a3fbe1dfa34  vcmppd xmm12, xmm1, xmm1, 0x03
00007a3fbe1dfa39  ptest xmm12, xmm12
00007a3fbe1dfa3f  jnz 0x00007A3FBE1E4B1A
00007a3fbe1dfa45  movaps [r15+0x120], xmm1
00007a3fbe1dfa4d  movups [r13+r14*1], xmm15
00007a3fbe1dfa53  lea rax, [r14+0x10]
00007a3fbe1dfa57  movups [r13+rax*1], xmm13
00007a3fbe1dfa5d  lea rax, [r14+0x20]
00007a3fbe1dfa61  movups [r13+rax*1], xmm14
00007a3fbe1dfa67  lea rax, [r14+0x30]
00007a3fbe1dfa6b  movups [r13+rax*1], xmm1
00007a3fbe1dfa71  mov eax, [r15+0x108]
00007a3fbe1dfa78  sahf
00007a3fbe1dfa79  jnz 0x00007A3FBE1DFAAB
00007a3fbe1dfa7b  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1dfa83  jz 0x00007A3FBE1DEAE0
00007a3fbe1dfa89  nop [rax+rax*1], ax
00007a3fbe1dfa92  nop [rax+rax*1], eax
00007a3fbe1dfa9a  mov eax, 0x4106D0
00007a3fbe1dfa9f  mov [r15+0x100], rax
00007a3fbe1dfaa6  jmp 0x00007A3FBDFFE110
00007a3fbe1dfaab  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1dfab3  jz 0x00007A3FBE1D89C0
00007a3fbe1dfab9  nop [rax+rax*1], ax
00007a3fbe1dfac2  nop [rax+rax*1], eax
00007a3fbe1dfaca  mov eax, 0x410504
00007a3fbe1dfacf  mov [r15+0x100], rax
00007a3fbe1dfad6  jmp 0x00007A3FBDFFE110
00007a3fbe1dfadb  int3
00007a3fbe1dfadc  call 0x00007A3FBE0E27E0
00007a3fbe1dfae1  jmp 0x00007A3FBE1DEBBF
00007a3fbe1dfae6  call 0x00007A3FBE0E1570
00007a3fbe1dfaeb  jmp 0x00007A3FBE1DEBC8
00007a3fbe1dfaf0  call 0x00007A3FBE0E27E0
00007a3fbe1dfaf5  jmp 0x00007A3FBE1DEC24
00007a3fbe1dfafa  call 0x00007A3FBE0E1570
00007a3fbe1dfaff  jmp 0x00007A3FBE1DEC2D
00007a3fbe1dfb04  call 0x00007A3FBE0E27E0
00007a3fbe1dfb09  jmp 0x00007A3FBE1DEC70
00007a3fbe1dfb0e  call 0x00007A3FBE0E1570
00007a3fbe1dfb13  jmp 0x00007A3FBE1DEC79
00007a3fbe1dfb18  call 0x00007A3FBE00DC20
00007a3fbe1dfb1d  jmp 0x00007A3FBE1DECB8
00007a3fbe1dfb22  call 0x00007A3FBE0D59C0
00007a3fbe1dfb27  jmp 0x00007A3FBE1DECCB
00007a3fbe1dfb2c  call 0x00007A3FBE0E0E30
00007a3fbe1dfb31  jmp 0x00007A3FBE1DECE9
00007a3fbe1dfb36  call 0x00007A3FBE0DFBC0
00007a3fbe1dfb3b  jmp 0x00007A3FBE1DECF3
00007a3fbe1dfb40  call 0x00007A3FBE0DE950
00007a3fbe1dfb45  jmp 0x00007A3FBE1DECFD
00007a3fbe1dfb4a  sub rsp, 0x08
00007a3fbe1dfb4e  push rax
00007a3fbe1dfb4f  push rcx
00007a3fbe1dfb50  push rdx
00007a3fbe1dfb51  push rdi
00007a3fbe1dfb52  push rsi
00007a3fbe1dfb53  push r8
00007a3fbe1dfb55  push r9
00007a3fbe1dfb57  push r10
00007a3fbe1dfb59  push r11
00007a3fbe1dfb5b  sub rsp, 0xF0
00007a3fbe1dfb62  vmovaps [rsp], xmm0
00007a3fbe1dfb67  vmovaps [rsp+0x10], xmm1
00007a3fbe1dfb6d  vmovaps [rsp+0x20], xmm2
00007a3fbe1dfb73  vmovaps [rsp+0x30], xmm3
00007a3fbe1dfb79  vmovaps [rsp+0x40], xmm4
00007a3fbe1dfb7f  vmovaps [rsp+0x50], xmm5
00007a3fbe1dfb85  vmovaps [rsp+0x60], xmm6
00007a3fbe1dfb8b  vmovaps [rsp+0x70], xmm7
00007a3fbe1dfb91  vmovaps [rsp+0x80], xmm9
00007a3fbe1dfb9a  vmovaps [rsp+0x90], xmm10
00007a3fbe1dfba3  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dfbac  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dfbb5  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dfbbe  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dfbc7  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dfbd0  sub rsp, 0x30
00007a3fbe1dfbd4  movaps [rsp], xmm8
00007a3fbe1dfbd9  movaps [rsp+0x10], xmm12
00007a3fbe1dfbdf  movaps [rsp+0x20], xmm15
00007a3fbe1dfbe5  lea rdi, [rsp]
00007a3fbe1dfbe9  mov esi, 0x00
00007a3fbe1dfbee  mov rax, 0x60D1084DB530
00007a3fbe1dfbf8  call rax
00007a3fbe1dfbfa  movaps xmm8, [rsp]
00007a3fbe1dfbff  add rsp, 0x30
00007a3fbe1dfc03  vmovaps xmm0, [rsp]
00007a3fbe1dfc08  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dfc0e  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dfc14  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dfc1a  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dfc20  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dfc26  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dfc2c  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dfc32  vmovaps xmm9, [rsp+0x80]
00007a3fbe1dfc3b  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dfc44  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dfc4d  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dfc56  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dfc5f  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dfc68  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dfc71  add rsp, 0xF0
00007a3fbe1dfc78  pop r11
00007a3fbe1dfc7a  pop r10
00007a3fbe1dfc7c  pop r9
00007a3fbe1dfc7e  pop r8
00007a3fbe1dfc80  pop rsi
00007a3fbe1dfc81  pop rdi
00007a3fbe1dfc82  pop rdx
00007a3fbe1dfc83  pop rcx
00007a3fbe1dfc84  pop rax
00007a3fbe1dfc85  add rsp, 0x08
00007a3fbe1dfc89  jmp 0x00007A3FBE1DED27
00007a3fbe1dfc8e  sub rsp, 0x08
00007a3fbe1dfc92  push rax
00007a3fbe1dfc93  push rcx
00007a3fbe1dfc94  push rdx
00007a3fbe1dfc95  push rdi
00007a3fbe1dfc96  push rsi
00007a3fbe1dfc97  push r8
00007a3fbe1dfc99  push r9
00007a3fbe1dfc9b  push r10
00007a3fbe1dfc9d  push r11
00007a3fbe1dfc9f  sub rsp, 0xF0
00007a3fbe1dfca6  vmovaps [rsp], xmm0
00007a3fbe1dfcab  vmovaps [rsp+0x10], xmm1
00007a3fbe1dfcb1  vmovaps [rsp+0x20], xmm2
00007a3fbe1dfcb7  vmovaps [rsp+0x30], xmm3
00007a3fbe1dfcbd  vmovaps [rsp+0x40], xmm4
00007a3fbe1dfcc3  vmovaps [rsp+0x50], xmm5
00007a3fbe1dfcc9  vmovaps [rsp+0x60], xmm6
00007a3fbe1dfccf  vmovaps [rsp+0x70], xmm8
00007a3fbe1dfcd5  vmovaps [rsp+0x80], xmm9
00007a3fbe1dfcde  vmovaps [rsp+0x90], xmm10
00007a3fbe1dfce7  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dfcf0  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dfcf9  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dfd02  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dfd0b  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dfd14  sub rsp, 0x30
00007a3fbe1dfd18  movaps [rsp], xmm7
00007a3fbe1dfd1c  movaps [rsp+0x10], xmm9
00007a3fbe1dfd22  movaps [rsp+0x20], xmm15
00007a3fbe1dfd28  lea rdi, [rsp]
00007a3fbe1dfd2c  mov esi, 0x00
00007a3fbe1dfd31  mov rax, 0x60D1084DB530
00007a3fbe1dfd3b  call rax
00007a3fbe1dfd3d  movaps xmm7, [rsp]
00007a3fbe1dfd41  add rsp, 0x30
00007a3fbe1dfd45  vmovaps xmm0, [rsp]
00007a3fbe1dfd4a  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dfd50  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dfd56  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dfd5c  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dfd62  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dfd68  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dfd6e  vmovaps xmm8, [rsp+0x70]
00007a3fbe1dfd74  vmovaps xmm9, [rsp+0x80]
00007a3fbe1dfd7d  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dfd86  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dfd8f  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dfd98  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dfda1  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dfdaa  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dfdb3  add rsp, 0xF0
00007a3fbe1dfdba  pop r11
00007a3fbe1dfdbc  pop r10
00007a3fbe1dfdbe  pop r9
00007a3fbe1dfdc0  pop r8
00007a3fbe1dfdc2  pop rsi
00007a3fbe1dfdc3  pop rdi
00007a3fbe1dfdc4  pop rdx
00007a3fbe1dfdc5  pop rcx
00007a3fbe1dfdc6  pop rax
00007a3fbe1dfdc7  add rsp, 0x08
00007a3fbe1dfdcb  jmp 0x00007A3FBE1DED55
00007a3fbe1dfdd0  sub rsp, 0x08
00007a3fbe1dfdd4  push rax
00007a3fbe1dfdd5  push rcx
00007a3fbe1dfdd6  push rdx
00007a3fbe1dfdd7  push rdi
00007a3fbe1dfdd8  push rsi
00007a3fbe1dfdd9  push r8
00007a3fbe1dfddb  push r9
00007a3fbe1dfddd  push r10
00007a3fbe1dfddf  push r11
00007a3fbe1dfde1  sub rsp, 0xF0
00007a3fbe1dfde8  vmovaps [rsp], xmm0
00007a3fbe1dfded  vmovaps [rsp+0x10], xmm1
00007a3fbe1dfdf3  vmovaps [rsp+0x20], xmm2
00007a3fbe1dfdf9  vmovaps [rsp+0x30], xmm3
00007a3fbe1dfdff  vmovaps [rsp+0x40], xmm4
00007a3fbe1dfe05  vmovaps [rsp+0x50], xmm5
00007a3fbe1dfe0b  vmovaps [rsp+0x60], xmm6
00007a3fbe1dfe11  vmovaps [rsp+0x70], xmm7
00007a3fbe1dfe17  vmovaps [rsp+0x80], xmm8
00007a3fbe1dfe20  vmovaps [rsp+0x90], xmm10
00007a3fbe1dfe29  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dfe32  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dfe3b  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dfe44  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dfe4d  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dfe56  sub rsp, 0x30
00007a3fbe1dfe5a  movaps [rsp], xmm9
00007a3fbe1dfe5f  movaps [rsp+0x10], xmm12
00007a3fbe1dfe65  movaps [rsp+0x20], xmm10
00007a3fbe1dfe6b  lea rdi, [rsp]
00007a3fbe1dfe6f  mov esi, 0x00
00007a3fbe1dfe74  mov rax, 0x60D1084DB530
00007a3fbe1dfe7e  call rax
00007a3fbe1dfe80  movaps xmm9, [rsp]
00007a3fbe1dfe85  add rsp, 0x30
00007a3fbe1dfe89  vmovaps xmm0, [rsp]
00007a3fbe1dfe8e  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dfe94  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dfe9a  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dfea0  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dfea6  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dfeac  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dfeb2  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dfeb8  vmovaps xmm8, [rsp+0x80]
00007a3fbe1dfec1  vmovaps xmm10, [rsp+0x90]
00007a3fbe1dfeca  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1dfed3  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1dfedc  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1dfee5  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1dfeee  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1dfef7  add rsp, 0xF0
00007a3fbe1dfefe  pop r11
00007a3fbe1dff00  pop r10
00007a3fbe1dff02  pop r9
00007a3fbe1dff04  pop r8
00007a3fbe1dff06  pop rsi
00007a3fbe1dff07  pop rdi
00007a3fbe1dff08  pop rdx
00007a3fbe1dff09  pop rcx
00007a3fbe1dff0a  pop rax
00007a3fbe1dff0b  add rsp, 0x08
00007a3fbe1dff0f  jmp 0x00007A3FBE1DED79
00007a3fbe1dff14  sub rsp, 0x08
00007a3fbe1dff18  push rax
00007a3fbe1dff19  push rcx
00007a3fbe1dff1a  push rdx
00007a3fbe1dff1b  push rdi
00007a3fbe1dff1c  push rsi
00007a3fbe1dff1d  push r8
00007a3fbe1dff1f  push r9
00007a3fbe1dff21  push r10
00007a3fbe1dff23  push r11
00007a3fbe1dff25  sub rsp, 0xF0
00007a3fbe1dff2c  vmovaps [rsp], xmm0
00007a3fbe1dff31  vmovaps [rsp+0x10], xmm1
00007a3fbe1dff37  vmovaps [rsp+0x20], xmm2
00007a3fbe1dff3d  vmovaps [rsp+0x30], xmm3
00007a3fbe1dff43  vmovaps [rsp+0x40], xmm4
00007a3fbe1dff49  vmovaps [rsp+0x50], xmm5
00007a3fbe1dff4f  vmovaps [rsp+0x60], xmm6
00007a3fbe1dff55  vmovaps [rsp+0x70], xmm7
00007a3fbe1dff5b  vmovaps [rsp+0x80], xmm8
00007a3fbe1dff64  vmovaps [rsp+0x90], xmm9
00007a3fbe1dff6d  vmovaps [rsp+0xA0], xmm11
00007a3fbe1dff76  vmovaps [rsp+0xB0], xmm12
00007a3fbe1dff7f  vmovaps [rsp+0xC0], xmm13
00007a3fbe1dff88  vmovaps [rsp+0xD0], xmm14
00007a3fbe1dff91  vmovaps [rsp+0xE0], xmm15
00007a3fbe1dff9a  sub rsp, 0x30
00007a3fbe1dff9e  movaps [rsp], xmm10
00007a3fbe1dffa3  movaps [rsp+0x10], xmm12
00007a3fbe1dffa9  movaps [rsp+0x20], xmm11
00007a3fbe1dffaf  lea rdi, [rsp]
00007a3fbe1dffb3  mov esi, 0x00
00007a3fbe1dffb8  mov rax, 0x60D1084DB530
00007a3fbe1dffc2  call rax
00007a3fbe1dffc4  movaps xmm10, [rsp]
00007a3fbe1dffc9  add rsp, 0x30
00007a3fbe1dffcd  vmovaps xmm0, [rsp]
00007a3fbe1dffd2  vmovaps xmm1, [rsp+0x10]
00007a3fbe1dffd8  vmovaps xmm2, [rsp+0x20]
00007a3fbe1dffde  vmovaps xmm3, [rsp+0x30]
00007a3fbe1dffe4  vmovaps xmm4, [rsp+0x40]
00007a3fbe1dffea  vmovaps xmm5, [rsp+0x50]
00007a3fbe1dfff0  vmovaps xmm6, [rsp+0x60]
00007a3fbe1dfff6  vmovaps xmm7, [rsp+0x70]
00007a3fbe1dfffc  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e0005  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e000e  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e0017  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e0020  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e0029  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e0032  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e003b  add rsp, 0xF0
00007a3fbe1e0042  pop r11
00007a3fbe1e0044  pop r10
00007a3fbe1e0046  pop r9
00007a3fbe1e0048  pop r8
00007a3fbe1e004a  pop rsi
00007a3fbe1e004b  pop rdi
00007a3fbe1e004c  pop rdx
00007a3fbe1e004d  pop rcx
00007a3fbe1e004e  pop rax
00007a3fbe1e004f  add rsp, 0x08
00007a3fbe1e0053  jmp 0x00007A3FBE1DED93
00007a3fbe1e0058  sub rsp, 0x08
00007a3fbe1e005c  push rax
00007a3fbe1e005d  push rcx
00007a3fbe1e005e  push rdx
00007a3fbe1e005f  push rdi
00007a3fbe1e0060  push rsi
00007a3fbe1e0061  push r8
00007a3fbe1e0063  push r9
00007a3fbe1e0065  push r10
00007a3fbe1e0067  push r11
00007a3fbe1e0069  sub rsp, 0xF0
00007a3fbe1e0070  vmovaps [rsp], xmm0
00007a3fbe1e0075  vmovaps [rsp+0x10], xmm1
00007a3fbe1e007b  vmovaps [rsp+0x20], xmm2
00007a3fbe1e0081  vmovaps [rsp+0x30], xmm3
00007a3fbe1e0087  vmovaps [rsp+0x40], xmm4
00007a3fbe1e008d  vmovaps [rsp+0x50], xmm5
00007a3fbe1e0093  vmovaps [rsp+0x60], xmm7
00007a3fbe1e0099  vmovaps [rsp+0x70], xmm8
00007a3fbe1e009f  vmovaps [rsp+0x80], xmm9
00007a3fbe1e00a8  vmovaps [rsp+0x90], xmm10
00007a3fbe1e00b1  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e00ba  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e00c3  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e00cc  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e00d5  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e00de  sub rsp, 0x30
00007a3fbe1e00e2  movaps [rsp], xmm6
00007a3fbe1e00e6  movaps [rsp+0x10], xmm12
00007a3fbe1e00ec  movaps [rsp+0x20], xmm11
00007a3fbe1e00f2  lea rdi, [rsp]
00007a3fbe1e00f6  mov esi, 0x00
00007a3fbe1e00fb  mov rax, 0x60D1084DB530
00007a3fbe1e0105  call rax
00007a3fbe1e0107  movaps xmm6, [rsp]
00007a3fbe1e010b  add rsp, 0x30
00007a3fbe1e010f  vmovaps xmm0, [rsp]
00007a3fbe1e0114  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e011a  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e0120  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e0126  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e012c  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e0132  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e0138  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e013e  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e0147  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e0150  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e0159  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e0162  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e016b  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e0174  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e017d  add rsp, 0xF0
00007a3fbe1e0184  pop r11
00007a3fbe1e0186  pop r10
00007a3fbe1e0188  pop r9
00007a3fbe1e018a  pop r8
00007a3fbe1e018c  pop rsi
00007a3fbe1e018d  pop rdi
00007a3fbe1e018e  pop rdx
00007a3fbe1e018f  pop rcx
00007a3fbe1e0190  pop rax
00007a3fbe1e0191  add rsp, 0x08
00007a3fbe1e0195  jmp 0x00007A3FBE1DEDB4
00007a3fbe1e019a  sub rsp, 0x08
00007a3fbe1e019e  push rax
00007a3fbe1e019f  push rcx
00007a3fbe1e01a0  push rdx
00007a3fbe1e01a1  push rdi
00007a3fbe1e01a2  push rsi
00007a3fbe1e01a3  push r8
00007a3fbe1e01a5  push r9
00007a3fbe1e01a7  push r10
00007a3fbe1e01a9  push r11
00007a3fbe1e01ab  sub rsp, 0xF0
00007a3fbe1e01b2  vmovaps [rsp], xmm0
00007a3fbe1e01b7  vmovaps [rsp+0x10], xmm1
00007a3fbe1e01bd  vmovaps [rsp+0x20], xmm2
00007a3fbe1e01c3  vmovaps [rsp+0x30], xmm4
00007a3fbe1e01c9  vmovaps [rsp+0x40], xmm5
00007a3fbe1e01cf  vmovaps [rsp+0x50], xmm6
00007a3fbe1e01d5  vmovaps [rsp+0x60], xmm7
00007a3fbe1e01db  vmovaps [rsp+0x70], xmm8
00007a3fbe1e01e1  vmovaps [rsp+0x80], xmm9
00007a3fbe1e01ea  vmovaps [rsp+0x90], xmm10
00007a3fbe1e01f3  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e01fc  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e0205  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e020e  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e0217  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e0220  sub rsp, 0x30
00007a3fbe1e0224  movaps [rsp], xmm3
00007a3fbe1e0228  movaps [rsp+0x10], xmm5
00007a3fbe1e022d  movaps [rsp+0x20], xmm4
00007a3fbe1e0232  lea rdi, [rsp]
00007a3fbe1e0236  mov esi, 0x00
00007a3fbe1e023b  mov rax, 0x60D1084DB530
00007a3fbe1e0245  call rax
00007a3fbe1e0247  movaps xmm3, [rsp]
00007a3fbe1e024b  add rsp, 0x30
00007a3fbe1e024f  vmovaps xmm0, [rsp]
00007a3fbe1e0254  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e025a  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e0260  vmovaps xmm4, [rsp+0x30]
00007a3fbe1e0266  vmovaps xmm5, [rsp+0x40]
00007a3fbe1e026c  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e0272  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e0278  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e027e  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e0287  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e0290  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e0299  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e02a2  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e02ab  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e02b4  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e02bd  add rsp, 0xF0
00007a3fbe1e02c4  pop r11
00007a3fbe1e02c6  pop r10
00007a3fbe1e02c8  pop r9
00007a3fbe1e02ca  pop r8
00007a3fbe1e02cc  pop rsi
00007a3fbe1e02cd  pop rdi
00007a3fbe1e02ce  pop rdx
00007a3fbe1e02cf  pop rcx
00007a3fbe1e02d0  pop rax
00007a3fbe1e02d1  add rsp, 0x08
00007a3fbe1e02d5  jmp 0x00007A3FBE1DEE15
00007a3fbe1e02da  sub rsp, 0x08
00007a3fbe1e02de  push rax
00007a3fbe1e02df  push rcx
00007a3fbe1e02e0  push rdx
00007a3fbe1e02e1  push rdi
00007a3fbe1e02e2  push rsi
00007a3fbe1e02e3  push r8
00007a3fbe1e02e5  push r9
00007a3fbe1e02e7  push r10
00007a3fbe1e02e9  push r11
00007a3fbe1e02eb  sub rsp, 0xF0
00007a3fbe1e02f2  vmovaps [rsp], xmm0
00007a3fbe1e02f7  vmovaps [rsp+0x10], xmm1
00007a3fbe1e02fd  vmovaps [rsp+0x20], xmm2
00007a3fbe1e0303  vmovaps [rsp+0x30], xmm3
00007a3fbe1e0309  vmovaps [rsp+0x40], xmm4
00007a3fbe1e030f  vmovaps [rsp+0x50], xmm6
00007a3fbe1e0315  vmovaps [rsp+0x60], xmm7
00007a3fbe1e031b  vmovaps [rsp+0x70], xmm8
00007a3fbe1e0321  vmovaps [rsp+0x80], xmm9
00007a3fbe1e032a  vmovaps [rsp+0x90], xmm10
00007a3fbe1e0333  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e033c  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e0345  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e034e  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e0357  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e0360  sub rsp, 0x30
00007a3fbe1e0364  movaps [rsp], xmm5
00007a3fbe1e0368  movaps [rsp+0x10], xmm8
00007a3fbe1e036e  movaps [rsp+0x20], xmm15
00007a3fbe1e0374  lea rdi, [rsp]
00007a3fbe1e0378  mov esi, 0x00
00007a3fbe1e037d  mov rax, 0x60D1084DB530
00007a3fbe1e0387  call rax
00007a3fbe1e0389  movaps xmm5, [rsp]
00007a3fbe1e038d  add rsp, 0x30
00007a3fbe1e0391  vmovaps xmm0, [rsp]
00007a3fbe1e0396  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e039c  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e03a2  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e03a8  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e03ae  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e03b4  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e03ba  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e03c0  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e03c9  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e03d2  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e03db  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e03e4  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e03ed  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e03f6  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e03ff  add rsp, 0xF0
00007a3fbe1e0406  pop r11
00007a3fbe1e0408  pop r10
00007a3fbe1e040a  pop r9
00007a3fbe1e040c  pop r8
00007a3fbe1e040e  pop rsi
00007a3fbe1e040f  pop rdi
00007a3fbe1e0410  pop rdx
00007a3fbe1e0411  pop rcx
00007a3fbe1e0412  pop rax
00007a3fbe1e0413  add rsp, 0x08
00007a3fbe1e0417  jmp 0x00007A3FBE1DEE53
00007a3fbe1e041c  sub rsp, 0x08
00007a3fbe1e0420  push rax
00007a3fbe1e0421  push rcx
00007a3fbe1e0422  push rdx
00007a3fbe1e0423  push rdi
00007a3fbe1e0424  push rsi
00007a3fbe1e0425  push r8
00007a3fbe1e0427  push r9
00007a3fbe1e0429  push r10
00007a3fbe1e042b  push r11
00007a3fbe1e042d  sub rsp, 0xF0
00007a3fbe1e0434  vmovaps [rsp], xmm0
00007a3fbe1e0439  vmovaps [rsp+0x10], xmm1
00007a3fbe1e043f  vmovaps [rsp+0x20], xmm2
00007a3fbe1e0445  vmovaps [rsp+0x30], xmm3
00007a3fbe1e044b  vmovaps [rsp+0x40], xmm5
00007a3fbe1e0451  vmovaps [rsp+0x50], xmm6
00007a3fbe1e0457  vmovaps [rsp+0x60], xmm7
00007a3fbe1e045d  vmovaps [rsp+0x70], xmm8
00007a3fbe1e0463  vmovaps [rsp+0x80], xmm9
00007a3fbe1e046c  vmovaps [rsp+0x90], xmm10
00007a3fbe1e0475  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e047e  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e0487  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e0490  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e0499  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e04a2  sub rsp, 0x30
00007a3fbe1e04a6  movaps [rsp], xmm4
00007a3fbe1e04aa  movaps [rsp+0x10], xmm9
00007a3fbe1e04b0  movaps [rsp+0x20], xmm8
00007a3fbe1e04b6  lea rdi, [rsp]
00007a3fbe1e04ba  mov esi, 0x00
00007a3fbe1e04bf  mov rax, 0x60D1084DB530
00007a3fbe1e04c9  call rax
00007a3fbe1e04cb  movaps xmm4, [rsp]
00007a3fbe1e04cf  add rsp, 0x30
00007a3fbe1e04d3  vmovaps xmm0, [rsp]
00007a3fbe1e04d8  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e04de  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e04e4  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e04ea  vmovaps xmm5, [rsp+0x40]
00007a3fbe1e04f0  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e04f6  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e04fc  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e0502  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e050b  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e0514  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e051d  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e0526  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e052f  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e0538  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e0541  add rsp, 0xF0
00007a3fbe1e0548  pop r11
00007a3fbe1e054a  pop r10
00007a3fbe1e054c  pop r9
00007a3fbe1e054e  pop r8
00007a3fbe1e0550  pop rsi
00007a3fbe1e0551  pop rdi
00007a3fbe1e0552  pop rdx
00007a3fbe1e0553  pop rcx
00007a3fbe1e0554  pop rax
00007a3fbe1e0555  add rsp, 0x08
00007a3fbe1e0559  jmp 0x00007A3FBE1DEE74
00007a3fbe1e055e  sub rsp, 0x08
00007a3fbe1e0562  push rax
00007a3fbe1e0563  push rcx
00007a3fbe1e0564  push rdx
00007a3fbe1e0565  push rdi
00007a3fbe1e0566  push rsi
00007a3fbe1e0567  push r8
00007a3fbe1e0569  push r9
00007a3fbe1e056b  push r10
00007a3fbe1e056d  push r11
00007a3fbe1e056f  sub rsp, 0xF0
00007a3fbe1e0576  vmovaps [rsp], xmm0
00007a3fbe1e057b  vmovaps [rsp+0x10], xmm1
00007a3fbe1e0581  vmovaps [rsp+0x20], xmm2
00007a3fbe1e0587  vmovaps [rsp+0x30], xmm3
00007a3fbe1e058d  vmovaps [rsp+0x40], xmm4
00007a3fbe1e0593  vmovaps [rsp+0x50], xmm5
00007a3fbe1e0599  vmovaps [rsp+0x60], xmm6
00007a3fbe1e059f  vmovaps [rsp+0x70], xmm7
00007a3fbe1e05a5  vmovaps [rsp+0x80], xmm8
00007a3fbe1e05ae  vmovaps [rsp+0x90], xmm10
00007a3fbe1e05b7  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e05c0  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e05c9  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e05d2  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e05db  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e05e4  sub rsp, 0x30
00007a3fbe1e05e8  movaps [rsp], xmm9
00007a3fbe1e05ed  movaps [rsp+0x10], xmm10
00007a3fbe1e05f3  movaps [rsp+0x20], xmm8
00007a3fbe1e05f9  lea rdi, [rsp]
00007a3fbe1e05fd  mov esi, 0x00
00007a3fbe1e0602  mov rax, 0x60D1084DB530
00007a3fbe1e060c  call rax
00007a3fbe1e060e  movaps xmm9, [rsp]
00007a3fbe1e0613  add rsp, 0x30
00007a3fbe1e0617  vmovaps xmm0, [rsp]
00007a3fbe1e061c  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e0622  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e0628  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e062e  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e0634  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e063a  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e0640  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e0646  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e064f  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e0658  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e0661  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e066a  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e0673  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e067c  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e0685  add rsp, 0xF0
00007a3fbe1e068c  pop r11
00007a3fbe1e068e  pop r10
00007a3fbe1e0690  pop r9
00007a3fbe1e0692  pop r8
00007a3fbe1e0694  pop rsi
00007a3fbe1e0695  pop rdi
00007a3fbe1e0696  pop rdx
00007a3fbe1e0697  pop rcx
00007a3fbe1e0698  pop rax
00007a3fbe1e0699  add rsp, 0x08
00007a3fbe1e069d  jmp 0x00007A3FBE1DEE8E
00007a3fbe1e06a2  call 0x00007A3FBE0B52F0
00007a3fbe1e06a7  jmp 0x00007A3FBE1DEFA8
00007a3fbe1e06ac  call 0x00007A3FBE0B52F0
00007a3fbe1e06b1  jmp 0x00007A3FBE1DEFBE
00007a3fbe1e06b6  sub rsp, 0x08
00007a3fbe1e06ba  push rax
00007a3fbe1e06bb  push rcx
00007a3fbe1e06bc  push rdx
00007a3fbe1e06bd  push rdi
00007a3fbe1e06be  push rsi
00007a3fbe1e06bf  push r8
00007a3fbe1e06c1  push r9
00007a3fbe1e06c3  push r10
00007a3fbe1e06c5  push r11
00007a3fbe1e06c7  sub rsp, 0xF0
00007a3fbe1e06ce  vmovaps [rsp], xmm0
00007a3fbe1e06d3  vmovaps [rsp+0x10], xmm2
00007a3fbe1e06d9  vmovaps [rsp+0x20], xmm3
00007a3fbe1e06df  vmovaps [rsp+0x30], xmm4
00007a3fbe1e06e5  vmovaps [rsp+0x40], xmm5
00007a3fbe1e06eb  vmovaps [rsp+0x50], xmm6
00007a3fbe1e06f1  vmovaps [rsp+0x60], xmm7
00007a3fbe1e06f7  vmovaps [rsp+0x70], xmm8
00007a3fbe1e06fd  vmovaps [rsp+0x80], xmm9
00007a3fbe1e0706  vmovaps [rsp+0x90], xmm10
00007a3fbe1e070f  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e0718  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e0721  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e072a  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e0733  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e073c  sub rsp, 0x30
00007a3fbe1e0740  movaps [rsp], xmm1
00007a3fbe1e0744  movaps [rsp+0x10], xmm6
00007a3fbe1e0749  movaps [rsp+0x20], xmm15
00007a3fbe1e074f  lea rdi, [rsp]
00007a3fbe1e0753  mov esi, 0x00
00007a3fbe1e0758  mov rax, 0x60D1084DB530
00007a3fbe1e0762  call rax
00007a3fbe1e0764  movaps xmm1, [rsp]
00007a3fbe1e0768  add rsp, 0x30
00007a3fbe1e076c  vmovaps xmm0, [rsp]
00007a3fbe1e0771  vmovaps xmm2, [rsp+0x10]
00007a3fbe1e0777  vmovaps xmm3, [rsp+0x20]
00007a3fbe1e077d  vmovaps xmm4, [rsp+0x30]
00007a3fbe1e0783  vmovaps xmm5, [rsp+0x40]
00007a3fbe1e0789  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e078f  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e0795  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e079b  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e07a4  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e07ad  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e07b6  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e07bf  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e07c8  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e07d1  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e07da  add rsp, 0xF0
00007a3fbe1e07e1  pop r11
00007a3fbe1e07e3  pop r10
00007a3fbe1e07e5  pop r9
00007a3fbe1e07e7  pop r8
00007a3fbe1e07e9  pop rsi
00007a3fbe1e07ea  pop rdi
00007a3fbe1e07eb  pop rdx
00007a3fbe1e07ec  pop rcx
00007a3fbe1e07ed  pop rax
00007a3fbe1e07ee  add rsp, 0x08
00007a3fbe1e07f2  jmp 0x00007A3FBE1DEFFB
00007a3fbe1e07f7  call 0x00007A3FBE0C4620
00007a3fbe1e07fc  jmp 0x00007A3FBE1DF008
00007a3fbe1e0801  sub rsp, 0x08
00007a3fbe1e0805  push rax
00007a3fbe1e0806  push rcx
00007a3fbe1e0807  push rdx
00007a3fbe1e0808  push rdi
00007a3fbe1e0809  push rsi
00007a3fbe1e080a  push r8
00007a3fbe1e080c  push r9
00007a3fbe1e080e  push r10
00007a3fbe1e0810  push r11
00007a3fbe1e0812  sub rsp, 0xF0
00007a3fbe1e0819  vmovaps [rsp], xmm0
00007a3fbe1e081e  vmovaps [rsp+0x10], xmm1
00007a3fbe1e0824  vmovaps [rsp+0x20], xmm2
00007a3fbe1e082a  vmovaps [rsp+0x30], xmm3
00007a3fbe1e0830  vmovaps [rsp+0x40], xmm4
00007a3fbe1e0836  vmovaps [rsp+0x50], xmm5
00007a3fbe1e083c  vmovaps [rsp+0x60], xmm6
00007a3fbe1e0842  vmovaps [rsp+0x70], xmm7
00007a3fbe1e0848  vmovaps [rsp+0x80], xmm8
00007a3fbe1e0851  vmovaps [rsp+0x90], xmm9
00007a3fbe1e085a  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e0863  vmovaps [rsp+0xB0], xmm11
00007a3fbe1e086c  vmovaps [rsp+0xC0], xmm12
00007a3fbe1e0875  vmovaps [rsp+0xD0], xmm13
00007a3fbe1e087e  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e0887  sub rsp, 0x30
00007a3fbe1e088b  movaps [rsp], xmm14
00007a3fbe1e0890  movaps [rsp+0x10], xmm4
00007a3fbe1e0895  movaps [rsp+0x20], xmm3
00007a3fbe1e089a  lea rdi, [rsp]
00007a3fbe1e089e  mov esi, 0x00
00007a3fbe1e08a3  mov rax, 0x60D1084DB530
00007a3fbe1e08ad  call rax
00007a3fbe1e08af  movaps xmm14, [rsp]
00007a3fbe1e08b4  add rsp, 0x30
00007a3fbe1e08b8  vmovaps xmm0, [rsp]
00007a3fbe1e08bd  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e08c3  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e08c9  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e08cf  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e08d5  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e08db  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e08e1  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e08e7  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e08f0  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e08f9  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e0902  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1e090b  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1e0914  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1e091d  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e0926  add rsp, 0xF0
00007a3fbe1e092d  pop r11
00007a3fbe1e092f  pop r10
00007a3fbe1e0931  pop r9
00007a3fbe1e0933  pop r8
00007a3fbe1e0935  pop rsi
00007a3fbe1e0936  pop rdi
00007a3fbe1e0937  pop rdx
00007a3fbe1e0938  pop rcx
00007a3fbe1e0939  pop rax
00007a3fbe1e093a  add rsp, 0x08
00007a3fbe1e093e  jmp 0x00007A3FBE1DF022
00007a3fbe1e0943  sub rsp, 0x08
00007a3fbe1e0947  push rax
00007a3fbe1e0948  push rcx
00007a3fbe1e0949  push rdx
00007a3fbe1e094a  push rdi
00007a3fbe1e094b  push rsi
00007a3fbe1e094c  push r8
00007a3fbe1e094e  push r9
00007a3fbe1e0950  push r10
00007a3fbe1e0952  push r11
00007a3fbe1e0954  sub rsp, 0xF0
00007a3fbe1e095b  vmovaps [rsp], xmm0
00007a3fbe1e0960  vmovaps [rsp+0x10], xmm1
00007a3fbe1e0966  vmovaps [rsp+0x20], xmm2
00007a3fbe1e096c  vmovaps [rsp+0x30], xmm3
00007a3fbe1e0972  vmovaps [rsp+0x40], xmm4
00007a3fbe1e0978  vmovaps [rsp+0x50], xmm5
00007a3fbe1e097e  vmovaps [rsp+0x60], xmm7
00007a3fbe1e0984  vmovaps [rsp+0x70], xmm8
00007a3fbe1e098a  vmovaps [rsp+0x80], xmm9
00007a3fbe1e0993  vmovaps [rsp+0x90], xmm10
00007a3fbe1e099c  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e09a5  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e09ae  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e09b7  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e09c0  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e09c9  sub rsp, 0x30
00007a3fbe1e09cd  movaps [rsp], xmm6
00007a3fbe1e09d1  movaps [rsp+0x10], xmm9
00007a3fbe1e09d7  movaps [rsp+0x20], xmm7
00007a3fbe1e09dc  lea rdi, [rsp]
00007a3fbe1e09e0  mov esi, 0x00
00007a3fbe1e09e5  mov rax, 0x60D1084DB530
00007a3fbe1e09ef  call rax
00007a3fbe1e09f1  movaps xmm6, [rsp]
00007a3fbe1e09f5  add rsp, 0x30
00007a3fbe1e09f9  vmovaps xmm0, [rsp]
00007a3fbe1e09fe  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e0a04  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e0a0a  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e0a10  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e0a16  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e0a1c  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e0a22  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e0a28  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e0a31  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e0a3a  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e0a43  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e0a4c  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e0a55  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e0a5e  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e0a67  add rsp, 0xF0
00007a3fbe1e0a6e  pop r11
00007a3fbe1e0a70  pop r10
00007a3fbe1e0a72  pop r9
00007a3fbe1e0a74  pop r8
00007a3fbe1e0a76  pop rsi
00007a3fbe1e0a77  pop rdi
00007a3fbe1e0a78  pop rdx
00007a3fbe1e0a79  pop rcx
00007a3fbe1e0a7a  pop rax
00007a3fbe1e0a7b  add rsp, 0x08
00007a3fbe1e0a7f  jmp 0x00007A3FBE1DF03A
00007a3fbe1e0a84  sub rsp, 0x08
00007a3fbe1e0a88  push rax
00007a3fbe1e0a89  push rcx
00007a3fbe1e0a8a  push rdx
00007a3fbe1e0a8b  push rdi
00007a3fbe1e0a8c  push rsi
00007a3fbe1e0a8d  push r8
00007a3fbe1e0a8f  push r9
00007a3fbe1e0a91  push r10
00007a3fbe1e0a93  push r11
00007a3fbe1e0a95  sub rsp, 0xF0
00007a3fbe1e0a9c  vmovaps [rsp], xmm0
00007a3fbe1e0aa1  vmovaps [rsp+0x10], xmm1
00007a3fbe1e0aa7  vmovaps [rsp+0x20], xmm2
00007a3fbe1e0aad  vmovaps [rsp+0x30], xmm3
00007a3fbe1e0ab3  vmovaps [rsp+0x40], xmm4
00007a3fbe1e0ab9  vmovaps [rsp+0x50], xmm5
00007a3fbe1e0abf  vmovaps [rsp+0x60], xmm6
00007a3fbe1e0ac5  vmovaps [rsp+0x70], xmm8
00007a3fbe1e0acb  vmovaps [rsp+0x80], xmm9
00007a3fbe1e0ad4  vmovaps [rsp+0x90], xmm10
00007a3fbe1e0add  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e0ae6  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e0aef  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e0af8  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e0b01  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e0b0a  sub rsp, 0x30
00007a3fbe1e0b0e  movaps [rsp], xmm7
00007a3fbe1e0b12  movaps [rsp+0x10], xmm4
00007a3fbe1e0b17  movaps [rsp+0x20], xmm9
00007a3fbe1e0b1d  lea rdi, [rsp]
00007a3fbe1e0b21  mov esi, 0x00
00007a3fbe1e0b26  mov rax, 0x60D1084DB530
00007a3fbe1e0b30  call rax
00007a3fbe1e0b32  movaps xmm7, [rsp]
00007a3fbe1e0b36  add rsp, 0x30
00007a3fbe1e0b3a  vmovaps xmm0, [rsp]
00007a3fbe1e0b3f  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e0b45  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e0b4b  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e0b51  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e0b57  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e0b5d  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e0b63  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e0b69  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e0b72  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e0b7b  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e0b84  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e0b8d  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e0b96  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e0b9f  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e0ba8  add rsp, 0xF0
00007a3fbe1e0baf  pop r11
00007a3fbe1e0bb1  pop r10
00007a3fbe1e0bb3  pop r9
00007a3fbe1e0bb5  pop r8
00007a3fbe1e0bb7  pop rsi
00007a3fbe1e0bb8  pop rdi
00007a3fbe1e0bb9  pop rdx
00007a3fbe1e0bba  pop rcx
00007a3fbe1e0bbb  pop rax
00007a3fbe1e0bbc  add rsp, 0x08
00007a3fbe1e0bc0  jmp 0x00007A3FBE1DF067
00007a3fbe1e0bc5  sub rsp, 0x08
00007a3fbe1e0bc9  push rax
00007a3fbe1e0bca  push rcx
00007a3fbe1e0bcb  push rdx
00007a3fbe1e0bcc  push rdi
00007a3fbe1e0bcd  push rsi
00007a3fbe1e0bce  push r8
00007a3fbe1e0bd0  push r9
00007a3fbe1e0bd2  push r10
00007a3fbe1e0bd4  push r11
00007a3fbe1e0bd6  sub rsp, 0xF0
00007a3fbe1e0bdd  vmovaps [rsp], xmm0
00007a3fbe1e0be2  vmovaps [rsp+0x10], xmm1
00007a3fbe1e0be8  vmovaps [rsp+0x20], xmm2
00007a3fbe1e0bee  vmovaps [rsp+0x30], xmm3
00007a3fbe1e0bf4  vmovaps [rsp+0x40], xmm5
00007a3fbe1e0bfa  vmovaps [rsp+0x50], xmm6
00007a3fbe1e0c00  vmovaps [rsp+0x60], xmm7
00007a3fbe1e0c06  vmovaps [rsp+0x70], xmm8
00007a3fbe1e0c0c  vmovaps [rsp+0x80], xmm9
00007a3fbe1e0c15  vmovaps [rsp+0x90], xmm10
00007a3fbe1e0c1e  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e0c27  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e0c30  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e0c39  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e0c42  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e0c4b  sub rsp, 0x30
00007a3fbe1e0c4f  movaps [rsp], xmm4
00007a3fbe1e0c53  movaps [rsp+0x10], xmm15
00007a3fbe1e0c59  movaps [rsp+0x20], xmm9
00007a3fbe1e0c5f  lea rdi, [rsp]
00007a3fbe1e0c63  mov esi, 0x00
00007a3fbe1e0c68  mov rax, 0x60D1084DB530
00007a3fbe1e0c72  call rax
00007a3fbe1e0c74  movaps xmm4, [rsp]
00007a3fbe1e0c78  add rsp, 0x30
00007a3fbe1e0c7c  vmovaps xmm0, [rsp]
00007a3fbe1e0c81  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e0c87  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e0c8d  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e0c93  vmovaps xmm5, [rsp+0x40]
00007a3fbe1e0c99  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e0c9f  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e0ca5  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e0cab  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e0cb4  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e0cbd  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e0cc6  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e0ccf  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e0cd8  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e0ce1  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e0cea  add rsp, 0xF0
00007a3fbe1e0cf1  pop r11
00007a3fbe1e0cf3  pop r10
00007a3fbe1e0cf5  pop r9
00007a3fbe1e0cf7  pop r8
00007a3fbe1e0cf9  pop rsi
00007a3fbe1e0cfa  pop rdi
00007a3fbe1e0cfb  pop rdx
00007a3fbe1e0cfc  pop rcx
00007a3fbe1e0cfd  pop rax
00007a3fbe1e0cfe  add rsp, 0x08
00007a3fbe1e0d02  jmp 0x00007A3FBE1DF08C
00007a3fbe1e0d07  call 0x00007A3FBE0C4620
00007a3fbe1e0d0c  jmp 0x00007A3FBE1DF099
00007a3fbe1e0d11  sub rsp, 0x08
00007a3fbe1e0d15  push rax
00007a3fbe1e0d16  push rcx
00007a3fbe1e0d17  push rdx
00007a3fbe1e0d18  push rdi
00007a3fbe1e0d19  push rsi
00007a3fbe1e0d1a  push r8
00007a3fbe1e0d1c  push r9
00007a3fbe1e0d1e  push r10
00007a3fbe1e0d20  push r11
00007a3fbe1e0d22  sub rsp, 0xF0
00007a3fbe1e0d29  vmovaps [rsp], xmm0
00007a3fbe1e0d2e  vmovaps [rsp+0x10], xmm1
00007a3fbe1e0d34  vmovaps [rsp+0x20], xmm2
00007a3fbe1e0d3a  vmovaps [rsp+0x30], xmm4
00007a3fbe1e0d40  vmovaps [rsp+0x40], xmm5
00007a3fbe1e0d46  vmovaps [rsp+0x50], xmm6
00007a3fbe1e0d4c  vmovaps [rsp+0x60], xmm7
00007a3fbe1e0d52  vmovaps [rsp+0x70], xmm8
00007a3fbe1e0d58  vmovaps [rsp+0x80], xmm9
00007a3fbe1e0d61  vmovaps [rsp+0x90], xmm10
00007a3fbe1e0d6a  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e0d73  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e0d7c  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e0d85  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e0d8e  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e0d97  sub rsp, 0x30
00007a3fbe1e0d9b  movaps [rsp], xmm3
00007a3fbe1e0d9f  movaps [rsp+0x10], xmm1
00007a3fbe1e0da4  movaps [rsp+0x20], xmm9
00007a3fbe1e0daa  lea rdi, [rsp]
00007a3fbe1e0dae  mov esi, 0x00
00007a3fbe1e0db3  mov rax, 0x60D1084DB530
00007a3fbe1e0dbd  call rax
00007a3fbe1e0dbf  movaps xmm3, [rsp]
00007a3fbe1e0dc3  add rsp, 0x30
00007a3fbe1e0dc7  vmovaps xmm0, [rsp]
00007a3fbe1e0dcc  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e0dd2  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e0dd8  vmovaps xmm4, [rsp+0x30]
00007a3fbe1e0dde  vmovaps xmm5, [rsp+0x40]
00007a3fbe1e0de4  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e0dea  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e0df0  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e0df6  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e0dff  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e0e08  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e0e11  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e0e1a  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e0e23  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e0e2c  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e0e35  add rsp, 0xF0
00007a3fbe1e0e3c  pop r11
00007a3fbe1e0e3e  pop r10
00007a3fbe1e0e40  pop r9
00007a3fbe1e0e42  pop r8
00007a3fbe1e0e44  pop rsi
00007a3fbe1e0e45  pop rdi
00007a3fbe1e0e46  pop rdx
00007a3fbe1e0e47  pop rcx
00007a3fbe1e0e48  pop rax
00007a3fbe1e0e49  add rsp, 0x08
00007a3fbe1e0e4d  jmp 0x00007A3FBE1DF0D6
00007a3fbe1e0e52  sub rsp, 0x08
00007a3fbe1e0e56  push rax
00007a3fbe1e0e57  push rcx
00007a3fbe1e0e58  push rdx
00007a3fbe1e0e59  push rdi
00007a3fbe1e0e5a  push rsi
00007a3fbe1e0e5b  push r8
00007a3fbe1e0e5d  push r9
00007a3fbe1e0e5f  push r10
00007a3fbe1e0e61  push r11
00007a3fbe1e0e63  sub rsp, 0xF0
00007a3fbe1e0e6a  vmovaps [rsp], xmm0
00007a3fbe1e0e6f  vmovaps [rsp+0x10], xmm2
00007a3fbe1e0e75  vmovaps [rsp+0x20], xmm3
00007a3fbe1e0e7b  vmovaps [rsp+0x30], xmm4
00007a3fbe1e0e81  vmovaps [rsp+0x40], xmm5
00007a3fbe1e0e87  vmovaps [rsp+0x50], xmm6
00007a3fbe1e0e8d  vmovaps [rsp+0x60], xmm7
00007a3fbe1e0e93  vmovaps [rsp+0x70], xmm8
00007a3fbe1e0e99  vmovaps [rsp+0x80], xmm9
00007a3fbe1e0ea2  vmovaps [rsp+0x90], xmm10
00007a3fbe1e0eab  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e0eb4  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e0ebd  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e0ec6  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e0ecf  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e0ed8  sub rsp, 0x30
00007a3fbe1e0edc  movaps [rsp], xmm1
00007a3fbe1e0ee0  movaps [rsp+0x10], xmm15
00007a3fbe1e0ee6  movaps [rsp+0x20], xmm9
00007a3fbe1e0eec  lea rdi, [rsp]
00007a3fbe1e0ef0  mov esi, 0x00
00007a3fbe1e0ef5  mov rax, 0x60D1084DB530
00007a3fbe1e0eff  call rax
00007a3fbe1e0f01  movaps xmm1, [rsp]
00007a3fbe1e0f05  add rsp, 0x30
00007a3fbe1e0f09  vmovaps xmm0, [rsp]
00007a3fbe1e0f0e  vmovaps xmm2, [rsp+0x10]
00007a3fbe1e0f14  vmovaps xmm3, [rsp+0x20]
00007a3fbe1e0f1a  vmovaps xmm4, [rsp+0x30]
00007a3fbe1e0f20  vmovaps xmm5, [rsp+0x40]
00007a3fbe1e0f26  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e0f2c  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e0f32  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e0f38  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e0f41  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e0f4a  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e0f53  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e0f5c  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e0f65  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e0f6e  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e0f77  add rsp, 0xF0
00007a3fbe1e0f7e  pop r11
00007a3fbe1e0f80  pop r10
00007a3fbe1e0f82  pop r9
00007a3fbe1e0f84  pop r8
00007a3fbe1e0f86  pop rsi
00007a3fbe1e0f87  pop rdi
00007a3fbe1e0f88  pop rdx
00007a3fbe1e0f89  pop rcx
00007a3fbe1e0f8a  pop rax
00007a3fbe1e0f8b  add rsp, 0x08
00007a3fbe1e0f8f  jmp 0x00007A3FBE1DF15E
00007a3fbe1e0f94  call 0x00007A3FBE0C4620
00007a3fbe1e0f99  jmp 0x00007A3FBE1DF16B
00007a3fbe1e0f9e  sub rsp, 0x08
00007a3fbe1e0fa2  push rax
00007a3fbe1e0fa3  push rcx
00007a3fbe1e0fa4  push rdx
00007a3fbe1e0fa5  push rdi
00007a3fbe1e0fa6  push rsi
00007a3fbe1e0fa7  push r8
00007a3fbe1e0fa9  push r9
00007a3fbe1e0fab  push r10
00007a3fbe1e0fad  push r11
00007a3fbe1e0faf  sub rsp, 0xF0
00007a3fbe1e0fb6  vmovaps [rsp], xmm0
00007a3fbe1e0fbb  vmovaps [rsp+0x10], xmm2
00007a3fbe1e0fc1  vmovaps [rsp+0x20], xmm3
00007a3fbe1e0fc7  vmovaps [rsp+0x30], xmm4
00007a3fbe1e0fcd  vmovaps [rsp+0x40], xmm5
00007a3fbe1e0fd3  vmovaps [rsp+0x50], xmm6
00007a3fbe1e0fd9  vmovaps [rsp+0x60], xmm7
00007a3fbe1e0fdf  vmovaps [rsp+0x70], xmm8
00007a3fbe1e0fe5  vmovaps [rsp+0x80], xmm9
00007a3fbe1e0fee  vmovaps [rsp+0x90], xmm10
00007a3fbe1e0ff7  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e1000  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e1009  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e1012  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e101b  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e1024  sub rsp, 0x30
00007a3fbe1e1028  movaps [rsp], xmm1
00007a3fbe1e102c  movaps [rsp+0x10], xmm5
00007a3fbe1e1031  movaps [rsp+0x20], xmm7
00007a3fbe1e1036  lea rdi, [rsp]
00007a3fbe1e103a  mov esi, 0x00
00007a3fbe1e103f  mov rax, 0x60D1084DB530
00007a3fbe1e1049  call rax
00007a3fbe1e104b  movaps xmm1, [rsp]
00007a3fbe1e104f  add rsp, 0x30
00007a3fbe1e1053  vmovaps xmm0, [rsp]
00007a3fbe1e1058  vmovaps xmm2, [rsp+0x10]
00007a3fbe1e105e  vmovaps xmm3, [rsp+0x20]
00007a3fbe1e1064  vmovaps xmm4, [rsp+0x30]
00007a3fbe1e106a  vmovaps xmm5, [rsp+0x40]
00007a3fbe1e1070  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e1076  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e107c  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e1082  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e108b  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e1094  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e109d  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e10a6  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e10af  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e10b8  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e10c1  add rsp, 0xF0
00007a3fbe1e10c8  pop r11
00007a3fbe1e10ca  pop r10
00007a3fbe1e10cc  pop r9
00007a3fbe1e10ce  pop r8
00007a3fbe1e10d0  pop rsi
00007a3fbe1e10d1  pop rdi
00007a3fbe1e10d2  pop rdx
00007a3fbe1e10d3  pop rcx
00007a3fbe1e10d4  pop rax
00007a3fbe1e10d5  add rsp, 0x08
00007a3fbe1e10d9  jmp 0x00007A3FBE1DF210
00007a3fbe1e10de  sub rsp, 0x08
00007a3fbe1e10e2  push rax
00007a3fbe1e10e3  push rcx
00007a3fbe1e10e4  push rdx
00007a3fbe1e10e5  push rdi
00007a3fbe1e10e6  push rsi
00007a3fbe1e10e7  push r8
00007a3fbe1e10e9  push r9
00007a3fbe1e10eb  push r10
00007a3fbe1e10ed  push r11
00007a3fbe1e10ef  sub rsp, 0xF0
00007a3fbe1e10f6  vmovaps [rsp], xmm0
00007a3fbe1e10fb  vmovaps [rsp+0x10], xmm1
00007a3fbe1e1101  vmovaps [rsp+0x20], xmm2
00007a3fbe1e1107  vmovaps [rsp+0x30], xmm3
00007a3fbe1e110d  vmovaps [rsp+0x40], xmm4
00007a3fbe1e1113  vmovaps [rsp+0x50], xmm5
00007a3fbe1e1119  vmovaps [rsp+0x60], xmm6
00007a3fbe1e111f  vmovaps [rsp+0x70], xmm8
00007a3fbe1e1125  vmovaps [rsp+0x80], xmm9
00007a3fbe1e112e  vmovaps [rsp+0x90], xmm10
00007a3fbe1e1137  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e1140  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e1149  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e1152  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e115b  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e1164  sub rsp, 0x30
00007a3fbe1e1168  movaps [rsp], xmm7
00007a3fbe1e116c  movaps [rsp+0x10], xmm5
00007a3fbe1e1171  movaps [rsp+0x20], xmm15
00007a3fbe1e1177  lea rdi, [rsp]
00007a3fbe1e117b  mov esi, 0x00
00007a3fbe1e1180  mov rax, 0x60D1084DB530
00007a3fbe1e118a  call rax
00007a3fbe1e118c  movaps xmm7, [rsp]
00007a3fbe1e1190  add rsp, 0x30
00007a3fbe1e1194  vmovaps xmm0, [rsp]
00007a3fbe1e1199  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e119f  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e11a5  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e11ab  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e11b1  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e11b7  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e11bd  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e11c3  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e11cc  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e11d5  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e11de  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e11e7  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e11f0  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e11f9  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e1202  add rsp, 0xF0
00007a3fbe1e1209  pop r11
00007a3fbe1e120b  pop r10
00007a3fbe1e120d  pop r9
00007a3fbe1e120f  pop r8
00007a3fbe1e1211  pop rsi
00007a3fbe1e1212  pop rdi
00007a3fbe1e1213  pop rdx
00007a3fbe1e1214  pop rcx
00007a3fbe1e1215  pop rax
00007a3fbe1e1216  add rsp, 0x08
00007a3fbe1e121a  jmp 0x00007A3FBE1DF246
00007a3fbe1e121f  call 0x00007A3FBE0B52F0
00007a3fbe1e1224  jmp 0x00007A3FBE1DF253
00007a3fbe1e1229  sub rsp, 0x08
00007a3fbe1e122d  push rax
00007a3fbe1e122e  push rcx
00007a3fbe1e122f  push rdx
00007a3fbe1e1230  push rdi
00007a3fbe1e1231  push rsi
00007a3fbe1e1232  push r8
00007a3fbe1e1234  push r9
00007a3fbe1e1236  push r10
00007a3fbe1e1238  push r11
00007a3fbe1e123a  sub rsp, 0xF0
00007a3fbe1e1241  vmovaps [rsp], xmm0
00007a3fbe1e1246  vmovaps [rsp+0x10], xmm1
00007a3fbe1e124c  vmovaps [rsp+0x20], xmm2
00007a3fbe1e1252  vmovaps [rsp+0x30], xmm3
00007a3fbe1e1258  vmovaps [rsp+0x40], xmm4
00007a3fbe1e125e  vmovaps [rsp+0x50], xmm5
00007a3fbe1e1264  vmovaps [rsp+0x60], xmm6
00007a3fbe1e126a  vmovaps [rsp+0x70], xmm7
00007a3fbe1e1270  vmovaps [rsp+0x80], xmm8
00007a3fbe1e1279  vmovaps [rsp+0x90], xmm9
00007a3fbe1e1282  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e128b  vmovaps [rsp+0xB0], xmm11
00007a3fbe1e1294  vmovaps [rsp+0xC0], xmm12
00007a3fbe1e129d  vmovaps [rsp+0xD0], xmm13
00007a3fbe1e12a6  vmovaps [rsp+0xE0], xmm14
00007a3fbe1e12af  sub rsp, 0x30
00007a3fbe1e12b3  movaps [rsp], xmm15
00007a3fbe1e12b8  movaps [rsp+0x10], xmm5
00007a3fbe1e12bd  movaps [rsp+0x20], xmm3
00007a3fbe1e12c2  lea rdi, [rsp]
00007a3fbe1e12c6  mov esi, 0x00
00007a3fbe1e12cb  mov rax, 0x60D1084DB530
00007a3fbe1e12d5  call rax
00007a3fbe1e12d7  movaps xmm15, [rsp]
00007a3fbe1e12dc  add rsp, 0x30
00007a3fbe1e12e0  vmovaps xmm0, [rsp]
00007a3fbe1e12e5  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e12eb  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e12f1  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e12f7  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e12fd  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e1303  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e1309  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e130f  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e1318  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e1321  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e132a  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1e1333  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1e133c  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1e1345  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1e134e  add rsp, 0xF0
00007a3fbe1e1355  pop r11
00007a3fbe1e1357  pop r10
00007a3fbe1e1359  pop r9
00007a3fbe1e135b  pop r8
00007a3fbe1e135d  pop rsi
00007a3fbe1e135e  pop rdi
00007a3fbe1e135f  pop rdx
00007a3fbe1e1360  pop rcx
00007a3fbe1e1361  pop rax
00007a3fbe1e1362  add rsp, 0x08
00007a3fbe1e1366  jmp 0x00007A3FBE1DF279
00007a3fbe1e136b  sub rsp, 0x08
00007a3fbe1e136f  push rax
00007a3fbe1e1370  push rcx
00007a3fbe1e1371  push rdx
00007a3fbe1e1372  push rdi
00007a3fbe1e1373  push rsi
00007a3fbe1e1374  push r8
00007a3fbe1e1376  push r9
00007a3fbe1e1378  push r10
00007a3fbe1e137a  push r11
00007a3fbe1e137c  sub rsp, 0xF0
00007a3fbe1e1383  vmovaps [rsp], xmm0
00007a3fbe1e1388  vmovaps [rsp+0x10], xmm2
00007a3fbe1e138e  vmovaps [rsp+0x20], xmm3
00007a3fbe1e1394  vmovaps [rsp+0x30], xmm4
00007a3fbe1e139a  vmovaps [rsp+0x40], xmm5
00007a3fbe1e13a0  vmovaps [rsp+0x50], xmm6
00007a3fbe1e13a6  vmovaps [rsp+0x60], xmm7
00007a3fbe1e13ac  vmovaps [rsp+0x70], xmm8
00007a3fbe1e13b2  vmovaps [rsp+0x80], xmm9
00007a3fbe1e13bb  vmovaps [rsp+0x90], xmm10
00007a3fbe1e13c4  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e13cd  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e13d6  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e13df  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e13e8  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e13f1  sub rsp, 0x30
00007a3fbe1e13f5  movaps [rsp], xmm1
00007a3fbe1e13f9  movaps [rsp+0x10], xmm5
00007a3fbe1e13fe  movaps [rsp+0x20], xmm4
00007a3fbe1e1403  lea rdi, [rsp]
00007a3fbe1e1407  mov esi, 0x00
00007a3fbe1e140c  mov rax, 0x60D1084DB530
00007a3fbe1e1416  call rax
00007a3fbe1e1418  movaps xmm1, [rsp]
00007a3fbe1e141c  add rsp, 0x30
00007a3fbe1e1420  vmovaps xmm0, [rsp]
00007a3fbe1e1425  vmovaps xmm2, [rsp+0x10]
00007a3fbe1e142b  vmovaps xmm3, [rsp+0x20]
00007a3fbe1e1431  vmovaps xmm4, [rsp+0x30]
00007a3fbe1e1437  vmovaps xmm5, [rsp+0x40]
00007a3fbe1e143d  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e1443  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e1449  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e144f  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e1458  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e1461  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e146a  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e1473  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e147c  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e1485  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e148e  add rsp, 0xF0
00007a3fbe1e1495  pop r11
00007a3fbe1e1497  pop r10
00007a3fbe1e1499  pop r9
00007a3fbe1e149b  pop r8
00007a3fbe1e149d  pop rsi
00007a3fbe1e149e  pop rdi
00007a3fbe1e149f  pop rdx
00007a3fbe1e14a0  pop rcx
00007a3fbe1e14a1  pop rax
00007a3fbe1e14a2  add rsp, 0x08
00007a3fbe1e14a6  jmp 0x00007A3FBE1DF299
00007a3fbe1e14ab  sub rsp, 0x08
00007a3fbe1e14af  push rax
00007a3fbe1e14b0  push rcx
00007a3fbe1e14b1  push rdx
00007a3fbe1e14b2  push rdi
00007a3fbe1e14b3  push rsi
00007a3fbe1e14b4  push r8
00007a3fbe1e14b6  push r9
00007a3fbe1e14b8  push r10
00007a3fbe1e14ba  push r11
00007a3fbe1e14bc  sub rsp, 0xF0
00007a3fbe1e14c3  vmovaps [rsp], xmm0
00007a3fbe1e14c8  vmovaps [rsp+0x10], xmm1
00007a3fbe1e14ce  vmovaps [rsp+0x20], xmm2
00007a3fbe1e14d4  vmovaps [rsp+0x30], xmm3
00007a3fbe1e14da  vmovaps [rsp+0x40], xmm5
00007a3fbe1e14e0  vmovaps [rsp+0x50], xmm6
00007a3fbe1e14e6  vmovaps [rsp+0x60], xmm7
00007a3fbe1e14ec  vmovaps [rsp+0x70], xmm8
00007a3fbe1e14f2  vmovaps [rsp+0x80], xmm9
00007a3fbe1e14fb  vmovaps [rsp+0x90], xmm10
00007a3fbe1e1504  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e150d  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e1516  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e151f  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e1528  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e1531  sub rsp, 0x30
00007a3fbe1e1535  movaps [rsp], xmm4
00007a3fbe1e1539  movaps [rsp+0x10], xmm3
00007a3fbe1e153e  movaps [rsp+0x20], xmm5
00007a3fbe1e1543  lea rdi, [rsp]
00007a3fbe1e1547  mov esi, 0x00
00007a3fbe1e154c  mov rax, 0x60D1084DB530
00007a3fbe1e1556  call rax
00007a3fbe1e1558  movaps xmm4, [rsp]
00007a3fbe1e155c  add rsp, 0x30
00007a3fbe1e1560  vmovaps xmm0, [rsp]
00007a3fbe1e1565  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e156b  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e1571  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e1577  vmovaps xmm5, [rsp+0x40]
00007a3fbe1e157d  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e1583  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e1589  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e158f  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e1598  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e15a1  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e15aa  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e15b3  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e15bc  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e15c5  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e15ce  add rsp, 0xF0
00007a3fbe1e15d5  pop r11
00007a3fbe1e15d7  pop r10
00007a3fbe1e15d9  pop r9
00007a3fbe1e15db  pop r8
00007a3fbe1e15dd  pop rsi
00007a3fbe1e15de  pop rdi
00007a3fbe1e15df  pop rdx
00007a3fbe1e15e0  pop rcx
00007a3fbe1e15e1  pop rax
00007a3fbe1e15e2  add rsp, 0x08
00007a3fbe1e15e6  jmp 0x00007A3FBE1DF2E7
00007a3fbe1e15eb  call 0x00007A3FBE0B52F0
00007a3fbe1e15f0  jmp 0x00007A3FBE1DF2F4
00007a3fbe1e15f5  sub rsp, 0x08
00007a3fbe1e15f9  push rax
00007a3fbe1e15fa  push rcx
00007a3fbe1e15fb  push rdx
00007a3fbe1e15fc  push rdi
00007a3fbe1e15fd  push rsi
00007a3fbe1e15fe  push r8
00007a3fbe1e1600  push r9
00007a3fbe1e1602  push r10
00007a3fbe1e1604  push r11
00007a3fbe1e1606  sub rsp, 0xF0
00007a3fbe1e160d  vmovaps [rsp], xmm0
00007a3fbe1e1612  vmovaps [rsp+0x10], xmm1
00007a3fbe1e1618  vmovaps [rsp+0x20], xmm2
00007a3fbe1e161e  vmovaps [rsp+0x30], xmm3
00007a3fbe1e1624  vmovaps [rsp+0x40], xmm4
00007a3fbe1e162a  vmovaps [rsp+0x50], xmm6
00007a3fbe1e1630  vmovaps [rsp+0x60], xmm7
00007a3fbe1e1636  vmovaps [rsp+0x70], xmm8
00007a3fbe1e163c  vmovaps [rsp+0x80], xmm9
00007a3fbe1e1645  vmovaps [rsp+0x90], xmm10
00007a3fbe1e164e  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e1657  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e1660  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e1669  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e1672  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e167b  sub rsp, 0x30
00007a3fbe1e167f  movaps [rsp], xmm5
00007a3fbe1e1683  movaps [rsp+0x10], xmm6
00007a3fbe1e1688  movaps [rsp+0x20], xmm3
00007a3fbe1e168d  lea rdi, [rsp]
00007a3fbe1e1691  mov esi, 0x00
00007a3fbe1e1696  mov rax, 0x60D1084DB530
00007a3fbe1e16a0  call rax
00007a3fbe1e16a2  movaps xmm5, [rsp]
00007a3fbe1e16a6  add rsp, 0x30
00007a3fbe1e16aa  vmovaps xmm0, [rsp]
00007a3fbe1e16af  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e16b5  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e16bb  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e16c1  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e16c7  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e16cd  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e16d3  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e16d9  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e16e2  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e16eb  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e16f4  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e16fd  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e1706  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e170f  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e1718  add rsp, 0xF0
00007a3fbe1e171f  pop r11
00007a3fbe1e1721  pop r10
00007a3fbe1e1723  pop r9
00007a3fbe1e1725  pop r8
00007a3fbe1e1727  pop rsi
00007a3fbe1e1728  pop rdi
00007a3fbe1e1729  pop rdx
00007a3fbe1e172a  pop rcx
00007a3fbe1e172b  pop rax
00007a3fbe1e172c  add rsp, 0x08
00007a3fbe1e1730  jmp 0x00007A3FBE1DF31A
00007a3fbe1e1735  sub rsp, 0x08
00007a3fbe1e1739  push rax
00007a3fbe1e173a  push rcx
00007a3fbe1e173b  push rdx
00007a3fbe1e173c  push rdi
00007a3fbe1e173d  push rsi
00007a3fbe1e173e  push r8
00007a3fbe1e1740  push r9
00007a3fbe1e1742  push r10
00007a3fbe1e1744  push r11
00007a3fbe1e1746  sub rsp, 0xF0
00007a3fbe1e174d  vmovaps [rsp], xmm0
00007a3fbe1e1752  vmovaps [rsp+0x10], xmm1
00007a3fbe1e1758  vmovaps [rsp+0x20], xmm2
00007a3fbe1e175e  vmovaps [rsp+0x30], xmm3
00007a3fbe1e1764  vmovaps [rsp+0x40], xmm4
00007a3fbe1e176a  vmovaps [rsp+0x50], xmm5
00007a3fbe1e1770  vmovaps [rsp+0x60], xmm7
00007a3fbe1e1776  vmovaps [rsp+0x70], xmm8
00007a3fbe1e177c  vmovaps [rsp+0x80], xmm9
00007a3fbe1e1785  vmovaps [rsp+0x90], xmm10
00007a3fbe1e178e  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e1797  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e17a0  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e17a9  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e17b2  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e17bb  sub rsp, 0x30
00007a3fbe1e17bf  movaps [rsp], xmm6
00007a3fbe1e17c3  movaps [rsp+0x10], xmm9
00007a3fbe1e17c9  movaps [rsp+0x20], xmm1
00007a3fbe1e17ce  lea rdi, [rsp]
00007a3fbe1e17d2  mov esi, 0x00
00007a3fbe1e17d7  mov rax, 0x60D1084DB530
00007a3fbe1e17e1  call rax
00007a3fbe1e17e3  movaps xmm6, [rsp]
00007a3fbe1e17e7  add rsp, 0x30
00007a3fbe1e17eb  vmovaps xmm0, [rsp]
00007a3fbe1e17f0  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e17f6  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e17fc  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e1802  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e1808  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e180e  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e1814  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e181a  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e1823  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e182c  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e1835  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e183e  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e1847  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e1850  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e1859  add rsp, 0xF0
00007a3fbe1e1860  pop r11
00007a3fbe1e1862  pop r10
00007a3fbe1e1864  pop r9
00007a3fbe1e1866  pop r8
00007a3fbe1e1868  pop rsi
00007a3fbe1e1869  pop rdi
00007a3fbe1e186a  pop rdx
00007a3fbe1e186b  pop rcx
00007a3fbe1e186c  pop rax
00007a3fbe1e186d  add rsp, 0x08
00007a3fbe1e1871  jmp 0x00007A3FBE1DF33E
00007a3fbe1e1876  sub rsp, 0x08
00007a3fbe1e187a  push rax
00007a3fbe1e187b  push rcx
00007a3fbe1e187c  push rdx
00007a3fbe1e187d  push rdi
00007a3fbe1e187e  push rsi
00007a3fbe1e187f  push r8
00007a3fbe1e1881  push r9
00007a3fbe1e1883  push r10
00007a3fbe1e1885  push r11
00007a3fbe1e1887  sub rsp, 0xF0
00007a3fbe1e188e  vmovaps [rsp], xmm0
00007a3fbe1e1893  vmovaps [rsp+0x10], xmm1
00007a3fbe1e1899  vmovaps [rsp+0x20], xmm2
00007a3fbe1e189f  vmovaps [rsp+0x30], xmm3
00007a3fbe1e18a5  vmovaps [rsp+0x40], xmm4
00007a3fbe1e18ab  vmovaps [rsp+0x50], xmm5
00007a3fbe1e18b1  vmovaps [rsp+0x60], xmm6
00007a3fbe1e18b7  vmovaps [rsp+0x70], xmm7
00007a3fbe1e18bd  vmovaps [rsp+0x80], xmm8
00007a3fbe1e18c6  vmovaps [rsp+0x90], xmm10
00007a3fbe1e18cf  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e18d8  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e18e1  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e18ea  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e18f3  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e18fc  sub rsp, 0x30
00007a3fbe1e1900  movaps [rsp], xmm9
00007a3fbe1e1905  movaps [rsp+0x10], xmm3
00007a3fbe1e190a  movaps [rsp+0x20], xmm1
00007a3fbe1e190f  lea rdi, [rsp]
00007a3fbe1e1913  mov esi, 0x00
00007a3fbe1e1918  mov rax, 0x60D1084DB530
00007a3fbe1e1922  call rax
00007a3fbe1e1924  movaps xmm9, [rsp]
00007a3fbe1e1929  add rsp, 0x30
00007a3fbe1e192d  vmovaps xmm0, [rsp]
00007a3fbe1e1932  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e1938  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e193e  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e1944  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e194a  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e1950  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e1956  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e195c  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e1965  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e196e  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e1977  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e1980  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e1989  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e1992  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e199b  add rsp, 0xF0
00007a3fbe1e19a2  pop r11
00007a3fbe1e19a4  pop r10
00007a3fbe1e19a6  pop r9
00007a3fbe1e19a8  pop r8
00007a3fbe1e19aa  pop rsi
00007a3fbe1e19ab  pop rdi
00007a3fbe1e19ac  pop rdx
00007a3fbe1e19ad  pop rcx
00007a3fbe1e19ae  pop rax
00007a3fbe1e19af  add rsp, 0x08
00007a3fbe1e19b3  jmp 0x00007A3FBE1DF38A
00007a3fbe1e19b8  call 0x00007A3FBE0B52F0
00007a3fbe1e19bd  jmp 0x00007A3FBE1DF397
00007a3fbe1e19c2  sub rsp, 0x08
00007a3fbe1e19c6  push rax
00007a3fbe1e19c7  push rcx
00007a3fbe1e19c8  push rdx
00007a3fbe1e19c9  push rdi
00007a3fbe1e19ca  push rsi
00007a3fbe1e19cb  push r8
00007a3fbe1e19cd  push r9
00007a3fbe1e19cf  push r10
00007a3fbe1e19d1  push r11
00007a3fbe1e19d3  sub rsp, 0xF0
00007a3fbe1e19da  vmovaps [rsp], xmm0
00007a3fbe1e19df  vmovaps [rsp+0x10], xmm1
00007a3fbe1e19e5  vmovaps [rsp+0x20], xmm2
00007a3fbe1e19eb  vmovaps [rsp+0x30], xmm3
00007a3fbe1e19f1  vmovaps [rsp+0x40], xmm4
00007a3fbe1e19f7  vmovaps [rsp+0x50], xmm5
00007a3fbe1e19fd  vmovaps [rsp+0x60], xmm6
00007a3fbe1e1a03  vmovaps [rsp+0x70], xmm7
00007a3fbe1e1a09  vmovaps [rsp+0x80], xmm8
00007a3fbe1e1a12  vmovaps [rsp+0x90], xmm9
00007a3fbe1e1a1b  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e1a24  vmovaps [rsp+0xB0], xmm11
00007a3fbe1e1a2d  vmovaps [rsp+0xC0], xmm12
00007a3fbe1e1a36  vmovaps [rsp+0xD0], xmm13
00007a3fbe1e1a3f  vmovaps [rsp+0xE0], xmm14
00007a3fbe1e1a48  sub rsp, 0x30
00007a3fbe1e1a4c  movaps [rsp], xmm15
00007a3fbe1e1a51  movaps [rsp+0x10], xmm3
00007a3fbe1e1a56  movaps [rsp+0x20], xmm7
00007a3fbe1e1a5b  lea rdi, [rsp]
00007a3fbe1e1a5f  mov esi, 0x00
00007a3fbe1e1a64  mov rax, 0x60D1084DB530
00007a3fbe1e1a6e  call rax
00007a3fbe1e1a70  movaps xmm15, [rsp]
00007a3fbe1e1a75  add rsp, 0x30
00007a3fbe1e1a79  vmovaps xmm0, [rsp]
00007a3fbe1e1a7e  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e1a84  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e1a8a  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e1a90  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e1a96  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e1a9c  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e1aa2  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e1aa8  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e1ab1  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e1aba  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e1ac3  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1e1acc  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1e1ad5  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1e1ade  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1e1ae7  add rsp, 0xF0
00007a3fbe1e1aee  pop r11
00007a3fbe1e1af0  pop r10
00007a3fbe1e1af2  pop r9
00007a3fbe1e1af4  pop r8
00007a3fbe1e1af6  pop rsi
00007a3fbe1e1af7  pop rdi
00007a3fbe1e1af8  pop rdx
00007a3fbe1e1af9  pop rcx
00007a3fbe1e1afa  pop rax
00007a3fbe1e1afb  add rsp, 0x08
00007a3fbe1e1aff  jmp 0x00007A3FBE1DF3C3
00007a3fbe1e1b04  sub rsp, 0x08
00007a3fbe1e1b08  push rax
00007a3fbe1e1b09  push rcx
00007a3fbe1e1b0a  push rdx
00007a3fbe1e1b0b  push rdi
00007a3fbe1e1b0c  push rsi
00007a3fbe1e1b0d  push r8
00007a3fbe1e1b0f  push r9
00007a3fbe1e1b11  push r10
00007a3fbe1e1b13  push r11
00007a3fbe1e1b15  sub rsp, 0xF0
00007a3fbe1e1b1c  vmovaps [rsp], xmm0
00007a3fbe1e1b21  vmovaps [rsp+0x10], xmm1
00007a3fbe1e1b27  vmovaps [rsp+0x20], xmm2
00007a3fbe1e1b2d  vmovaps [rsp+0x30], xmm4
00007a3fbe1e1b33  vmovaps [rsp+0x40], xmm5
00007a3fbe1e1b39  vmovaps [rsp+0x50], xmm6
00007a3fbe1e1b3f  vmovaps [rsp+0x60], xmm7
00007a3fbe1e1b45  vmovaps [rsp+0x70], xmm8
00007a3fbe1e1b4b  vmovaps [rsp+0x80], xmm9
00007a3fbe1e1b54  vmovaps [rsp+0x90], xmm10
00007a3fbe1e1b5d  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e1b66  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e1b6f  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e1b78  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e1b81  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e1b8a  sub rsp, 0x30
00007a3fbe1e1b8e  movaps [rsp], xmm3
00007a3fbe1e1b92  movaps [rsp+0x10], xmm1
00007a3fbe1e1b97  movaps [rsp+0x20], xmm15
00007a3fbe1e1b9d  lea rdi, [rsp]
00007a3fbe1e1ba1  mov esi, 0x00
00007a3fbe1e1ba6  mov rax, 0x60D1084DB530
00007a3fbe1e1bb0  call rax
00007a3fbe1e1bb2  movaps xmm3, [rsp]
00007a3fbe1e1bb6  add rsp, 0x30
00007a3fbe1e1bba  vmovaps xmm0, [rsp]
00007a3fbe1e1bbf  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e1bc5  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e1bcb  vmovaps xmm4, [rsp+0x30]
00007a3fbe1e1bd1  vmovaps xmm5, [rsp+0x40]
00007a3fbe1e1bd7  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e1bdd  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e1be3  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e1be9  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e1bf2  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e1bfb  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e1c04  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e1c0d  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e1c16  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e1c1f  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e1c28  add rsp, 0xF0
00007a3fbe1e1c2f  pop r11
00007a3fbe1e1c31  pop r10
00007a3fbe1e1c33  pop r9
00007a3fbe1e1c35  pop r8
00007a3fbe1e1c37  pop rsi
00007a3fbe1e1c38  pop rdi
00007a3fbe1e1c39  pop rdx
00007a3fbe1e1c3a  pop rcx
00007a3fbe1e1c3b  pop rax
00007a3fbe1e1c3c  add rsp, 0x08
00007a3fbe1e1c40  jmp 0x00007A3FBE1DF452
00007a3fbe1e1c45  call 0x00007A3FBE0B52F0
00007a3fbe1e1c4a  jmp 0x00007A3FBE1DF45C
00007a3fbe1e1c4f  sub rsp, 0x08
00007a3fbe1e1c53  push rax
00007a3fbe1e1c54  push rcx
00007a3fbe1e1c55  push rdx
00007a3fbe1e1c56  push rdi
00007a3fbe1e1c57  push rsi
00007a3fbe1e1c58  push r8
00007a3fbe1e1c5a  push r9
00007a3fbe1e1c5c  push r10
00007a3fbe1e1c5e  push r11
00007a3fbe1e1c60  sub rsp, 0xF0
00007a3fbe1e1c67  vmovaps [rsp], xmm0
00007a3fbe1e1c6c  vmovaps [rsp+0x10], xmm1
00007a3fbe1e1c72  vmovaps [rsp+0x20], xmm2
00007a3fbe1e1c78  vmovaps [rsp+0x30], xmm3
00007a3fbe1e1c7e  vmovaps [rsp+0x40], xmm4
00007a3fbe1e1c84  vmovaps [rsp+0x50], xmm5
00007a3fbe1e1c8a  vmovaps [rsp+0x60], xmm6
00007a3fbe1e1c90  vmovaps [rsp+0x70], xmm7
00007a3fbe1e1c96  vmovaps [rsp+0x80], xmm8
00007a3fbe1e1c9f  vmovaps [rsp+0x90], xmm9
00007a3fbe1e1ca8  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e1cb1  vmovaps [rsp+0xB0], xmm11
00007a3fbe1e1cba  vmovaps [rsp+0xC0], xmm12
00007a3fbe1e1cc3  vmovaps [rsp+0xD0], xmm13
00007a3fbe1e1ccc  vmovaps [rsp+0xE0], xmm14
00007a3fbe1e1cd5  sub rsp, 0x30
00007a3fbe1e1cd9  movaps [rsp], xmm15
00007a3fbe1e1cde  movaps [rsp+0x10], xmm14
00007a3fbe1e1ce4  movaps [rsp+0x20], xmm4
00007a3fbe1e1ce9  lea rdi, [rsp]
00007a3fbe1e1ced  mov esi, 0x00
00007a3fbe1e1cf2  mov rax, 0x60D1084DB530
00007a3fbe1e1cfc  call rax
00007a3fbe1e1cfe  movaps xmm15, [rsp]
00007a3fbe1e1d03  add rsp, 0x30
00007a3fbe1e1d07  vmovaps xmm0, [rsp]
00007a3fbe1e1d0c  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e1d12  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e1d18  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e1d1e  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e1d24  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e1d2a  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e1d30  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e1d36  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e1d3f  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e1d48  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e1d51  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1e1d5a  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1e1d63  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1e1d6c  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1e1d75  add rsp, 0xF0
00007a3fbe1e1d7c  pop r11
00007a3fbe1e1d7e  pop r10
00007a3fbe1e1d80  pop r9
00007a3fbe1e1d82  pop r8
00007a3fbe1e1d84  pop rsi
00007a3fbe1e1d85  pop rdi
00007a3fbe1e1d86  pop rdx
00007a3fbe1e1d87  pop rcx
00007a3fbe1e1d88  pop rax
00007a3fbe1e1d89  add rsp, 0x08
00007a3fbe1e1d8d  jmp 0x00007A3FBE1DF48A
00007a3fbe1e1d92  sub rsp, 0x08
00007a3fbe1e1d96  push rax
00007a3fbe1e1d97  push rcx
00007a3fbe1e1d98  push rdx
00007a3fbe1e1d99  push rdi
00007a3fbe1e1d9a  push rsi
00007a3fbe1e1d9b  push r8
00007a3fbe1e1d9d  push r9
00007a3fbe1e1d9f  push r10
00007a3fbe1e1da1  push r11
00007a3fbe1e1da3  sub rsp, 0xF0
00007a3fbe1e1daa  vmovaps [rsp], xmm0
00007a3fbe1e1daf  vmovaps [rsp+0x10], xmm1
00007a3fbe1e1db5  vmovaps [rsp+0x20], xmm2
00007a3fbe1e1dbb  vmovaps [rsp+0x30], xmm3
00007a3fbe1e1dc1  vmovaps [rsp+0x40], xmm4
00007a3fbe1e1dc7  vmovaps [rsp+0x50], xmm5
00007a3fbe1e1dcd  vmovaps [rsp+0x60], xmm6
00007a3fbe1e1dd3  vmovaps [rsp+0x70], xmm7
00007a3fbe1e1dd9  vmovaps [rsp+0x80], xmm8
00007a3fbe1e1de2  vmovaps [rsp+0x90], xmm9
00007a3fbe1e1deb  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e1df4  vmovaps [rsp+0xB0], xmm11
00007a3fbe1e1dfd  vmovaps [rsp+0xC0], xmm12
00007a3fbe1e1e06  vmovaps [rsp+0xD0], xmm13
00007a3fbe1e1e0f  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e1e18  sub rsp, 0x30
00007a3fbe1e1e1c  movaps [rsp], xmm14
00007a3fbe1e1e21  movaps [rsp+0x10], xmm2
00007a3fbe1e1e26  movaps [rsp+0x20], xmm1
00007a3fbe1e1e2b  lea rdi, [rsp]
00007a3fbe1e1e2f  mov esi, 0x00
00007a3fbe1e1e34  mov rax, 0x60D1084DB530
00007a3fbe1e1e3e  call rax
00007a3fbe1e1e40  movaps xmm14, [rsp]
00007a3fbe1e1e45  add rsp, 0x30
00007a3fbe1e1e49  vmovaps xmm0, [rsp]
00007a3fbe1e1e4e  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e1e54  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e1e5a  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e1e60  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e1e66  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e1e6c  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e1e72  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e1e78  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e1e81  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e1e8a  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e1e93  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1e1e9c  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1e1ea5  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1e1eae  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e1eb7  add rsp, 0xF0
00007a3fbe1e1ebe  pop r11
00007a3fbe1e1ec0  pop r10
00007a3fbe1e1ec2  pop r9
00007a3fbe1e1ec4  pop r8
00007a3fbe1e1ec6  pop rsi
00007a3fbe1e1ec7  pop rdi
00007a3fbe1e1ec8  pop rdx
00007a3fbe1e1ec9  pop rcx
00007a3fbe1e1eca  pop rax
00007a3fbe1e1ecb  add rsp, 0x08
00007a3fbe1e1ecf  jmp 0x00007A3FBE1DF4B0
00007a3fbe1e1ed4  sub rsp, 0x08
00007a3fbe1e1ed8  push rax
00007a3fbe1e1ed9  push rcx
00007a3fbe1e1eda  push rdx
00007a3fbe1e1edb  push rdi
00007a3fbe1e1edc  push rsi
00007a3fbe1e1edd  push r8
00007a3fbe1e1edf  push r9
00007a3fbe1e1ee1  push r10
00007a3fbe1e1ee3  push r11
00007a3fbe1e1ee5  sub rsp, 0xF0
00007a3fbe1e1eec  vmovaps [rsp], xmm0
00007a3fbe1e1ef1  vmovaps [rsp+0x10], xmm2
00007a3fbe1e1ef7  vmovaps [rsp+0x20], xmm3
00007a3fbe1e1efd  vmovaps [rsp+0x30], xmm4
00007a3fbe1e1f03  vmovaps [rsp+0x40], xmm5
00007a3fbe1e1f09  vmovaps [rsp+0x50], xmm6
00007a3fbe1e1f0f  vmovaps [rsp+0x60], xmm7
00007a3fbe1e1f15  vmovaps [rsp+0x70], xmm8
00007a3fbe1e1f1b  vmovaps [rsp+0x80], xmm9
00007a3fbe1e1f24  vmovaps [rsp+0x90], xmm10
00007a3fbe1e1f2d  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e1f36  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e1f3f  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e1f48  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e1f51  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e1f5a  sub rsp, 0x30
00007a3fbe1e1f5e  movaps [rsp], xmm1
00007a3fbe1e1f62  movaps [rsp+0x10], xmm4
00007a3fbe1e1f67  movaps [rsp+0x20], xmm9
00007a3fbe1e1f6d  lea rdi, [rsp]
00007a3fbe1e1f71  mov esi, 0x00
00007a3fbe1e1f76  mov rax, 0x60D1084DB530
00007a3fbe1e1f80  call rax
00007a3fbe1e1f82  movaps xmm1, [rsp]
00007a3fbe1e1f86  add rsp, 0x30
00007a3fbe1e1f8a  vmovaps xmm0, [rsp]
00007a3fbe1e1f8f  vmovaps xmm2, [rsp+0x10]
00007a3fbe1e1f95  vmovaps xmm3, [rsp+0x20]
00007a3fbe1e1f9b  vmovaps xmm4, [rsp+0x30]
00007a3fbe1e1fa1  vmovaps xmm5, [rsp+0x40]
00007a3fbe1e1fa7  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e1fad  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e1fb3  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e1fb9  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e1fc2  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e1fcb  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e1fd4  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e1fdd  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e1fe6  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e1fef  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e1ff8  add rsp, 0xF0
00007a3fbe1e1fff  pop r11
00007a3fbe1e2001  pop r10
00007a3fbe1e2003  pop r9
00007a3fbe1e2005  pop r8
00007a3fbe1e2007  pop rsi
00007a3fbe1e2008  pop rdi
00007a3fbe1e2009  pop rdx
00007a3fbe1e200a  pop rcx
00007a3fbe1e200b  pop rax
00007a3fbe1e200c  add rsp, 0x08
00007a3fbe1e2010  jmp 0x00007A3FBE1DF4CE
00007a3fbe1e2015  sub rsp, 0x08
00007a3fbe1e2019  push rax
00007a3fbe1e201a  push rcx
00007a3fbe1e201b  push rdx
00007a3fbe1e201c  push rdi
00007a3fbe1e201d  push rsi
00007a3fbe1e201e  push r8
00007a3fbe1e2020  push r9
00007a3fbe1e2022  push r10
00007a3fbe1e2024  push r11
00007a3fbe1e2026  sub rsp, 0xF0
00007a3fbe1e202d  vmovaps [rsp], xmm0
00007a3fbe1e2032  vmovaps [rsp+0x10], xmm1
00007a3fbe1e2038  vmovaps [rsp+0x20], xmm2
00007a3fbe1e203e  vmovaps [rsp+0x30], xmm3
00007a3fbe1e2044  vmovaps [rsp+0x40], xmm5
00007a3fbe1e204a  vmovaps [rsp+0x50], xmm6
00007a3fbe1e2050  vmovaps [rsp+0x60], xmm7
00007a3fbe1e2056  vmovaps [rsp+0x70], xmm8
00007a3fbe1e205c  vmovaps [rsp+0x80], xmm9
00007a3fbe1e2065  vmovaps [rsp+0x90], xmm10
00007a3fbe1e206e  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e2077  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e2080  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e2089  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e2092  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e209b  sub rsp, 0x30
00007a3fbe1e209f  movaps [rsp], xmm4
00007a3fbe1e20a3  movaps [rsp+0x10], xmm2
00007a3fbe1e20a8  movaps [rsp+0x20], xmm9
00007a3fbe1e20ae  lea rdi, [rsp]
00007a3fbe1e20b2  mov esi, 0x00
00007a3fbe1e20b7  mov rax, 0x60D1084DB530
00007a3fbe1e20c1  call rax
00007a3fbe1e20c3  movaps xmm4, [rsp]
00007a3fbe1e20c7  add rsp, 0x30
00007a3fbe1e20cb  vmovaps xmm0, [rsp]
00007a3fbe1e20d0  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e20d6  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e20dc  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e20e2  vmovaps xmm5, [rsp+0x40]
00007a3fbe1e20e8  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e20ee  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e20f4  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e20fa  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e2103  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e210c  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e2115  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e211e  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e2127  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e2130  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e2139  add rsp, 0xF0
00007a3fbe1e2140  pop r11
00007a3fbe1e2142  pop r10
00007a3fbe1e2144  pop r9
00007a3fbe1e2146  pop r8
00007a3fbe1e2148  pop rsi
00007a3fbe1e2149  pop rdi
00007a3fbe1e214a  pop rdx
00007a3fbe1e214b  pop rcx
00007a3fbe1e214c  pop rax
00007a3fbe1e214d  add rsp, 0x08
00007a3fbe1e2151  jmp 0x00007A3FBE1DF4FE
00007a3fbe1e2156  sub rsp, 0x08
00007a3fbe1e215a  push rax
00007a3fbe1e215b  push rcx
00007a3fbe1e215c  push rdx
00007a3fbe1e215d  push rdi
00007a3fbe1e215e  push rsi
00007a3fbe1e215f  push r8
00007a3fbe1e2161  push r9
00007a3fbe1e2163  push r10
00007a3fbe1e2165  push r11
00007a3fbe1e2167  sub rsp, 0xF0
00007a3fbe1e216e  vmovaps [rsp], xmm0
00007a3fbe1e2173  vmovaps [rsp+0x10], xmm1
00007a3fbe1e2179  vmovaps [rsp+0x20], xmm2
00007a3fbe1e217f  vmovaps [rsp+0x30], xmm3
00007a3fbe1e2185  vmovaps [rsp+0x40], xmm4
00007a3fbe1e218b  vmovaps [rsp+0x50], xmm5
00007a3fbe1e2191  vmovaps [rsp+0x60], xmm6
00007a3fbe1e2197  vmovaps [rsp+0x70], xmm7
00007a3fbe1e219d  vmovaps [rsp+0x80], xmm8
00007a3fbe1e21a6  vmovaps [rsp+0x90], xmm10
00007a3fbe1e21af  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e21b8  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e21c1  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e21ca  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e21d3  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e21dc  sub rsp, 0x30
00007a3fbe1e21e0  movaps [rsp], xmm9
00007a3fbe1e21e5  movaps [rsp+0x10], xmm2
00007a3fbe1e21ea  movaps [rsp+0x20], xmm1
00007a3fbe1e21ef  lea rdi, [rsp]
00007a3fbe1e21f3  mov esi, 0x00
00007a3fbe1e21f8  mov rax, 0x60D1084DB530
00007a3fbe1e2202  call rax
00007a3fbe1e2204  movaps xmm9, [rsp]
00007a3fbe1e2209  add rsp, 0x30
00007a3fbe1e220d  vmovaps xmm0, [rsp]
00007a3fbe1e2212  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e2218  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e221e  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e2224  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e222a  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e2230  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e2236  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e223c  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e2245  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e224e  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e2257  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e2260  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e2269  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e2272  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e227b  add rsp, 0xF0
00007a3fbe1e2282  pop r11
00007a3fbe1e2284  pop r10
00007a3fbe1e2286  pop r9
00007a3fbe1e2288  pop r8
00007a3fbe1e228a  pop rsi
00007a3fbe1e228b  pop rdi
00007a3fbe1e228c  pop rdx
00007a3fbe1e228d  pop rcx
00007a3fbe1e228e  pop rax
00007a3fbe1e228f  add rsp, 0x08
00007a3fbe1e2293  jmp 0x00007A3FBE1DF534
00007a3fbe1e2298  sub rsp, 0x08
00007a3fbe1e229c  push rax
00007a3fbe1e229d  push rcx
00007a3fbe1e229e  push rdx
00007a3fbe1e229f  push rdi
00007a3fbe1e22a0  push rsi
00007a3fbe1e22a1  push r8
00007a3fbe1e22a3  push r9
00007a3fbe1e22a5  push r10
00007a3fbe1e22a7  push r11
00007a3fbe1e22a9  sub rsp, 0xF0
00007a3fbe1e22b0  vmovaps [rsp], xmm0
00007a3fbe1e22b5  vmovaps [rsp+0x10], xmm2
00007a3fbe1e22bb  vmovaps [rsp+0x20], xmm3
00007a3fbe1e22c1  vmovaps [rsp+0x30], xmm4
00007a3fbe1e22c7  vmovaps [rsp+0x40], xmm5
00007a3fbe1e22cd  vmovaps [rsp+0x50], xmm6
00007a3fbe1e22d3  vmovaps [rsp+0x60], xmm7
00007a3fbe1e22d9  vmovaps [rsp+0x70], xmm8
00007a3fbe1e22df  vmovaps [rsp+0x80], xmm9
00007a3fbe1e22e8  vmovaps [rsp+0x90], xmm10
00007a3fbe1e22f1  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e22fa  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e2303  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e230c  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e2315  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e231e  sub rsp, 0x30
00007a3fbe1e2322  movaps [rsp], xmm1
00007a3fbe1e2326  movaps [rsp+0x10], xmm15
00007a3fbe1e232c  movaps [rsp+0x20], xmm6
00007a3fbe1e2331  lea rdi, [rsp]
00007a3fbe1e2335  mov esi, 0x00
00007a3fbe1e233a  mov rax, 0x60D1084DB530
00007a3fbe1e2344  call rax
00007a3fbe1e2346  movaps xmm1, [rsp]
00007a3fbe1e234a  add rsp, 0x30
00007a3fbe1e234e  vmovaps xmm0, [rsp]
00007a3fbe1e2353  vmovaps xmm2, [rsp+0x10]
00007a3fbe1e2359  vmovaps xmm3, [rsp+0x20]
00007a3fbe1e235f  vmovaps xmm4, [rsp+0x30]
00007a3fbe1e2365  vmovaps xmm5, [rsp+0x40]
00007a3fbe1e236b  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e2371  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e2377  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e237d  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e2386  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e238f  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e2398  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e23a1  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e23aa  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e23b3  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e23bc  add rsp, 0xF0
00007a3fbe1e23c3  pop r11
00007a3fbe1e23c5  pop r10
00007a3fbe1e23c7  pop r9
00007a3fbe1e23c9  pop r8
00007a3fbe1e23cb  pop rsi
00007a3fbe1e23cc  pop rdi
00007a3fbe1e23cd  pop rdx
00007a3fbe1e23ce  pop rcx
00007a3fbe1e23cf  pop rax
00007a3fbe1e23d0  add rsp, 0x08
00007a3fbe1e23d4  jmp 0x00007A3FBE1DF555
00007a3fbe1e23d9  sub rsp, 0x08
00007a3fbe1e23dd  push rax
00007a3fbe1e23de  push rcx
00007a3fbe1e23df  push rdx
00007a3fbe1e23e0  push rdi
00007a3fbe1e23e1  push rsi
00007a3fbe1e23e2  push r8
00007a3fbe1e23e4  push r9
00007a3fbe1e23e6  push r10
00007a3fbe1e23e8  push r11
00007a3fbe1e23ea  sub rsp, 0xF0
00007a3fbe1e23f1  vmovaps [rsp], xmm0
00007a3fbe1e23f6  vmovaps [rsp+0x10], xmm1
00007a3fbe1e23fc  vmovaps [rsp+0x20], xmm2
00007a3fbe1e2402  vmovaps [rsp+0x30], xmm3
00007a3fbe1e2408  vmovaps [rsp+0x40], xmm4
00007a3fbe1e240e  vmovaps [rsp+0x50], xmm5
00007a3fbe1e2414  vmovaps [rsp+0x60], xmm6
00007a3fbe1e241a  vmovaps [rsp+0x70], xmm7
00007a3fbe1e2420  vmovaps [rsp+0x80], xmm8
00007a3fbe1e2429  vmovaps [rsp+0x90], xmm9
00007a3fbe1e2432  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e243b  vmovaps [rsp+0xB0], xmm11
00007a3fbe1e2444  vmovaps [rsp+0xC0], xmm12
00007a3fbe1e244d  vmovaps [rsp+0xD0], xmm13
00007a3fbe1e2456  vmovaps [rsp+0xE0], xmm14
00007a3fbe1e245f  sub rsp, 0x30
00007a3fbe1e2463  movaps [rsp], xmm15
00007a3fbe1e2468  movaps [rsp+0x10], xmm5
00007a3fbe1e246d  movaps [rsp+0x20], xmm3
00007a3fbe1e2472  lea rdi, [rsp]
00007a3fbe1e2476  mov esi, 0x00
00007a3fbe1e247b  mov rax, 0x60D1084DB530
00007a3fbe1e2485  call rax
00007a3fbe1e2487  movaps xmm15, [rsp]
00007a3fbe1e248c  add rsp, 0x30
00007a3fbe1e2490  vmovaps xmm0, [rsp]
00007a3fbe1e2495  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e249b  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e24a1  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e24a7  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e24ad  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e24b3  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e24b9  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e24bf  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e24c8  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e24d1  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e24da  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1e24e3  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1e24ec  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1e24f5  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1e24fe  add rsp, 0xF0
00007a3fbe1e2505  pop r11
00007a3fbe1e2507  pop r10
00007a3fbe1e2509  pop r9
00007a3fbe1e250b  pop r8
00007a3fbe1e250d  pop rsi
00007a3fbe1e250e  pop rdi
00007a3fbe1e250f  pop rdx
00007a3fbe1e2510  pop rcx
00007a3fbe1e2511  pop rax
00007a3fbe1e2512  add rsp, 0x08
00007a3fbe1e2516  jmp 0x00007A3FBE1DF56F
00007a3fbe1e251b  sub rsp, 0x08
00007a3fbe1e251f  push rax
00007a3fbe1e2520  push rcx
00007a3fbe1e2521  push rdx
00007a3fbe1e2522  push rdi
00007a3fbe1e2523  push rsi
00007a3fbe1e2524  push r8
00007a3fbe1e2526  push r9
00007a3fbe1e2528  push r10
00007a3fbe1e252a  push r11
00007a3fbe1e252c  sub rsp, 0xF0
00007a3fbe1e2533  vmovaps [rsp], xmm0
00007a3fbe1e2538  vmovaps [rsp+0x10], xmm1
00007a3fbe1e253e  vmovaps [rsp+0x20], xmm2
00007a3fbe1e2544  vmovaps [rsp+0x30], xmm3
00007a3fbe1e254a  vmovaps [rsp+0x40], xmm4
00007a3fbe1e2550  vmovaps [rsp+0x50], xmm6
00007a3fbe1e2556  vmovaps [rsp+0x60], xmm7
00007a3fbe1e255c  vmovaps [rsp+0x70], xmm8
00007a3fbe1e2562  vmovaps [rsp+0x80], xmm9
00007a3fbe1e256b  vmovaps [rsp+0x90], xmm10
00007a3fbe1e2574  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e257d  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e2586  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e258f  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e2598  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e25a1  sub rsp, 0x30
00007a3fbe1e25a5  movaps [rsp], xmm5
00007a3fbe1e25a9  movaps [rsp+0x10], xmm8
00007a3fbe1e25af  movaps [rsp+0x20], xmm6
00007a3fbe1e25b4  lea rdi, [rsp]
00007a3fbe1e25b8  mov esi, 0x00
00007a3fbe1e25bd  mov rax, 0x60D1084DB530
00007a3fbe1e25c7  call rax
00007a3fbe1e25c9  movaps xmm5, [rsp]
00007a3fbe1e25cd  add rsp, 0x30
00007a3fbe1e25d1  vmovaps xmm0, [rsp]
00007a3fbe1e25d6  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e25dc  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e25e2  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e25e8  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e25ee  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e25f4  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e25fa  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e2600  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e2609  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e2612  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e261b  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e2624  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e262d  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e2636  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e263f  add rsp, 0xF0
00007a3fbe1e2646  pop r11
00007a3fbe1e2648  pop r10
00007a3fbe1e264a  pop r9
00007a3fbe1e264c  pop r8
00007a3fbe1e264e  pop rsi
00007a3fbe1e264f  pop rdi
00007a3fbe1e2650  pop rdx
00007a3fbe1e2651  pop rcx
00007a3fbe1e2652  pop rax
00007a3fbe1e2653  add rsp, 0x08
00007a3fbe1e2657  jmp 0x00007A3FBE1DF593
00007a3fbe1e265c  sub rsp, 0x08
00007a3fbe1e2660  push rax
00007a3fbe1e2661  push rcx
00007a3fbe1e2662  push rdx
00007a3fbe1e2663  push rdi
00007a3fbe1e2664  push rsi
00007a3fbe1e2665  push r8
00007a3fbe1e2667  push r9
00007a3fbe1e2669  push r10
00007a3fbe1e266b  push r11
00007a3fbe1e266d  sub rsp, 0xF0
00007a3fbe1e2674  vmovaps [rsp], xmm0
00007a3fbe1e2679  vmovaps [rsp+0x10], xmm1
00007a3fbe1e267f  vmovaps [rsp+0x20], xmm2
00007a3fbe1e2685  vmovaps [rsp+0x30], xmm3
00007a3fbe1e268b  vmovaps [rsp+0x40], xmm4
00007a3fbe1e2691  vmovaps [rsp+0x50], xmm5
00007a3fbe1e2697  vmovaps [rsp+0x60], xmm7
00007a3fbe1e269d  vmovaps [rsp+0x70], xmm8
00007a3fbe1e26a3  vmovaps [rsp+0x80], xmm9
00007a3fbe1e26ac  vmovaps [rsp+0x90], xmm10
00007a3fbe1e26b5  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e26be  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e26c7  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e26d0  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e26d9  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e26e2  sub rsp, 0x30
00007a3fbe1e26e6  movaps [rsp], xmm6
00007a3fbe1e26ea  movaps [rsp+0x10], xmm10
00007a3fbe1e26f0  movaps [rsp+0x20], xmm8
00007a3fbe1e26f6  lea rdi, [rsp]
00007a3fbe1e26fa  mov esi, 0x00
00007a3fbe1e26ff  mov rax, 0x60D1084DB530
00007a3fbe1e2709  call rax
00007a3fbe1e270b  movaps xmm6, [rsp]
00007a3fbe1e270f  add rsp, 0x30
00007a3fbe1e2713  vmovaps xmm0, [rsp]
00007a3fbe1e2718  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e271e  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e2724  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e272a  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e2730  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e2736  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e273c  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e2742  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e274b  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e2754  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e275d  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e2766  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e276f  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e2778  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e2781  add rsp, 0xF0
00007a3fbe1e2788  pop r11
00007a3fbe1e278a  pop r10
00007a3fbe1e278c  pop r9
00007a3fbe1e278e  pop r8
00007a3fbe1e2790  pop rsi
00007a3fbe1e2791  pop rdi
00007a3fbe1e2792  pop rdx
00007a3fbe1e2793  pop rcx
00007a3fbe1e2794  pop rax
00007a3fbe1e2795  add rsp, 0x08
00007a3fbe1e2799  jmp 0x00007A3FBE1DF5B8
00007a3fbe1e279e  sub rsp, 0x08
00007a3fbe1e27a2  push rax
00007a3fbe1e27a3  push rcx
00007a3fbe1e27a4  push rdx
00007a3fbe1e27a5  push rdi
00007a3fbe1e27a6  push rsi
00007a3fbe1e27a7  push r8
00007a3fbe1e27a9  push r9
00007a3fbe1e27ab  push r10
00007a3fbe1e27ad  push r11
00007a3fbe1e27af  sub rsp, 0xF0
00007a3fbe1e27b6  vmovaps [rsp], xmm0
00007a3fbe1e27bb  vmovaps [rsp+0x10], xmm1
00007a3fbe1e27c1  vmovaps [rsp+0x20], xmm2
00007a3fbe1e27c7  vmovaps [rsp+0x30], xmm3
00007a3fbe1e27cd  vmovaps [rsp+0x40], xmm4
00007a3fbe1e27d3  vmovaps [rsp+0x50], xmm5
00007a3fbe1e27d9  vmovaps [rsp+0x60], xmm6
00007a3fbe1e27df  vmovaps [rsp+0x70], xmm7
00007a3fbe1e27e5  vmovaps [rsp+0x80], xmm8
00007a3fbe1e27ee  vmovaps [rsp+0x90], xmm9
00007a3fbe1e27f7  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e2800  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e2809  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e2812  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e281b  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e2824  sub rsp, 0x30
00007a3fbe1e2828  movaps [rsp], xmm10
00007a3fbe1e282d  movaps [rsp+0x10], xmm8
00007a3fbe1e2833  movaps [rsp+0x20], xmm14
00007a3fbe1e2839  lea rdi, [rsp]
00007a3fbe1e283d  mov esi, 0x00
00007a3fbe1e2842  mov rax, 0x60D1084DB530
00007a3fbe1e284c  call rax
00007a3fbe1e284e  movaps xmm10, [rsp]
00007a3fbe1e2853  add rsp, 0x30
00007a3fbe1e2857  vmovaps xmm0, [rsp]
00007a3fbe1e285c  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e2862  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e2868  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e286e  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e2874  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e287a  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e2880  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e2886  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e288f  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e2898  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e28a1  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e28aa  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e28b3  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e28bc  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e28c5  add rsp, 0xF0
00007a3fbe1e28cc  pop r11
00007a3fbe1e28ce  pop r10
00007a3fbe1e28d0  pop r9
00007a3fbe1e28d2  pop r8
00007a3fbe1e28d4  pop rsi
00007a3fbe1e28d5  pop rdi
00007a3fbe1e28d6  pop rdx
00007a3fbe1e28d7  pop rcx
00007a3fbe1e28d8  pop rax
00007a3fbe1e28d9  add rsp, 0x08
00007a3fbe1e28dd  jmp 0x00007A3FBE1DF5D8
00007a3fbe1e28e2  sub rsp, 0x08
00007a3fbe1e28e6  push rax
00007a3fbe1e28e7  push rcx
00007a3fbe1e28e8  push rdx
00007a3fbe1e28e9  push rdi
00007a3fbe1e28ea  push rsi
00007a3fbe1e28eb  push r8
00007a3fbe1e28ed  push r9
00007a3fbe1e28ef  push r10
00007a3fbe1e28f1  push r11
00007a3fbe1e28f3  sub rsp, 0xF0
00007a3fbe1e28fa  vmovaps [rsp], xmm0
00007a3fbe1e28ff  vmovaps [rsp+0x10], xmm1
00007a3fbe1e2905  vmovaps [rsp+0x20], xmm2
00007a3fbe1e290b  vmovaps [rsp+0x30], xmm3
00007a3fbe1e2911  vmovaps [rsp+0x40], xmm4
00007a3fbe1e2917  vmovaps [rsp+0x50], xmm5
00007a3fbe1e291d  vmovaps [rsp+0x60], xmm6
00007a3fbe1e2923  vmovaps [rsp+0x70], xmm7
00007a3fbe1e2929  vmovaps [rsp+0x80], xmm8
00007a3fbe1e2932  vmovaps [rsp+0x90], xmm9
00007a3fbe1e293b  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e2944  vmovaps [rsp+0xB0], xmm11
00007a3fbe1e294d  vmovaps [rsp+0xC0], xmm12
00007a3fbe1e2956  vmovaps [rsp+0xD0], xmm13
00007a3fbe1e295f  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e2968  sub rsp, 0x30
00007a3fbe1e296c  movaps [rsp], xmm14
00007a3fbe1e2971  movaps [rsp+0x10], xmm8
00007a3fbe1e2977  movaps [rsp+0x20], xmm4
00007a3fbe1e297c  lea rdi, [rsp]
00007a3fbe1e2980  mov esi, 0x00
00007a3fbe1e2985  mov rax, 0x60D1084DB530
00007a3fbe1e298f  call rax
00007a3fbe1e2991  movaps xmm14, [rsp]
00007a3fbe1e2996  add rsp, 0x30
00007a3fbe1e299a  vmovaps xmm0, [rsp]
00007a3fbe1e299f  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e29a5  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e29ab  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e29b1  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e29b7  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e29bd  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e29c3  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e29c9  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e29d2  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e29db  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e29e4  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1e29ed  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1e29f6  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1e29ff  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e2a08  add rsp, 0xF0
00007a3fbe1e2a0f  pop r11
00007a3fbe1e2a11  pop r10
00007a3fbe1e2a13  pop r9
00007a3fbe1e2a15  pop r8
00007a3fbe1e2a17  pop rsi
00007a3fbe1e2a18  pop rdi
00007a3fbe1e2a19  pop rdx
00007a3fbe1e2a1a  pop rcx
00007a3fbe1e2a1b  pop rax
00007a3fbe1e2a1c  add rsp, 0x08
00007a3fbe1e2a20  jmp 0x00007A3FBE1DF5F8
00007a3fbe1e2a25  sub rsp, 0x08
00007a3fbe1e2a29  push rax
00007a3fbe1e2a2a  push rcx
00007a3fbe1e2a2b  push rdx
00007a3fbe1e2a2c  push rdi
00007a3fbe1e2a2d  push rsi
00007a3fbe1e2a2e  push r8
00007a3fbe1e2a30  push r9
00007a3fbe1e2a32  push r10
00007a3fbe1e2a34  push r11
00007a3fbe1e2a36  sub rsp, 0xF0
00007a3fbe1e2a3d  vmovaps [rsp], xmm0
00007a3fbe1e2a42  vmovaps [rsp+0x10], xmm1
00007a3fbe1e2a48  vmovaps [rsp+0x20], xmm2
00007a3fbe1e2a4e  vmovaps [rsp+0x30], xmm3
00007a3fbe1e2a54  vmovaps [rsp+0x40], xmm5
00007a3fbe1e2a5a  vmovaps [rsp+0x50], xmm6
00007a3fbe1e2a60  vmovaps [rsp+0x60], xmm7
00007a3fbe1e2a66  vmovaps [rsp+0x70], xmm8
00007a3fbe1e2a6c  vmovaps [rsp+0x80], xmm9
00007a3fbe1e2a75  vmovaps [rsp+0x90], xmm10
00007a3fbe1e2a7e  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e2a87  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e2a90  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e2a99  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e2aa2  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e2aab  sub rsp, 0x30
00007a3fbe1e2aaf  movaps [rsp], xmm4
00007a3fbe1e2ab3  movaps [rsp+0x10], xmm13
00007a3fbe1e2ab9  movaps [rsp+0x20], xmm8
00007a3fbe1e2abf  lea rdi, [rsp]
00007a3fbe1e2ac3  mov esi, 0x00
00007a3fbe1e2ac8  mov rax, 0x60D1084DB530
00007a3fbe1e2ad2  call rax
00007a3fbe1e2ad4  movaps xmm4, [rsp]
00007a3fbe1e2ad8  add rsp, 0x30
00007a3fbe1e2adc  vmovaps xmm0, [rsp]
00007a3fbe1e2ae1  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e2ae7  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e2aed  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e2af3  vmovaps xmm5, [rsp+0x40]
00007a3fbe1e2af9  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e2aff  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e2b05  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e2b0b  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e2b14  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e2b1d  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e2b26  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e2b2f  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e2b38  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e2b41  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e2b4a  add rsp, 0xF0
00007a3fbe1e2b51  pop r11
00007a3fbe1e2b53  pop r10
00007a3fbe1e2b55  pop r9
00007a3fbe1e2b57  pop r8
00007a3fbe1e2b59  pop rsi
00007a3fbe1e2b5a  pop rdi
00007a3fbe1e2b5b  pop rdx
00007a3fbe1e2b5c  pop rcx
00007a3fbe1e2b5d  pop rax
00007a3fbe1e2b5e  add rsp, 0x08
00007a3fbe1e2b62  jmp 0x00007A3FBE1DF61D
00007a3fbe1e2b67  sub rsp, 0x08
00007a3fbe1e2b6b  push rax
00007a3fbe1e2b6c  push rcx
00007a3fbe1e2b6d  push rdx
00007a3fbe1e2b6e  push rdi
00007a3fbe1e2b6f  push rsi
00007a3fbe1e2b70  push r8
00007a3fbe1e2b72  push r9
00007a3fbe1e2b74  push r10
00007a3fbe1e2b76  push r11
00007a3fbe1e2b78  sub rsp, 0xF0
00007a3fbe1e2b7f  vmovaps [rsp], xmm0
00007a3fbe1e2b84  vmovaps [rsp+0x10], xmm1
00007a3fbe1e2b8a  vmovaps [rsp+0x20], xmm2
00007a3fbe1e2b90  vmovaps [rsp+0x30], xmm3
00007a3fbe1e2b96  vmovaps [rsp+0x40], xmm4
00007a3fbe1e2b9c  vmovaps [rsp+0x50], xmm5
00007a3fbe1e2ba2  vmovaps [rsp+0x60], xmm6
00007a3fbe1e2ba8  vmovaps [rsp+0x70], xmm7
00007a3fbe1e2bae  vmovaps [rsp+0x80], xmm8
00007a3fbe1e2bb7  vmovaps [rsp+0x90], xmm9
00007a3fbe1e2bc0  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e2bc9  vmovaps [rsp+0xB0], xmm11
00007a3fbe1e2bd2  vmovaps [rsp+0xC0], xmm12
00007a3fbe1e2bdb  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e2be4  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e2bed  sub rsp, 0x30
00007a3fbe1e2bf1  movaps [rsp], xmm13
00007a3fbe1e2bf6  movaps [rsp+0x10], xmm15
00007a3fbe1e2bfc  movaps [rsp+0x20], xmm9
00007a3fbe1e2c02  lea rdi, [rsp]
00007a3fbe1e2c06  mov esi, 0x00
00007a3fbe1e2c0b  mov rax, 0x60D1084DB530
00007a3fbe1e2c15  call rax
00007a3fbe1e2c17  movaps xmm13, [rsp]
00007a3fbe1e2c1c  add rsp, 0x30
00007a3fbe1e2c20  vmovaps xmm0, [rsp]
00007a3fbe1e2c25  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e2c2b  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e2c31  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e2c37  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e2c3d  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e2c43  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e2c49  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e2c4f  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e2c58  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e2c61  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e2c6a  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1e2c73  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1e2c7c  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e2c85  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e2c8e  add rsp, 0xF0
00007a3fbe1e2c95  pop r11
00007a3fbe1e2c97  pop r10
00007a3fbe1e2c99  pop r9
00007a3fbe1e2c9b  pop r8
00007a3fbe1e2c9d  pop rsi
00007a3fbe1e2c9e  pop rdi
00007a3fbe1e2c9f  pop rdx
00007a3fbe1e2ca0  pop rcx
00007a3fbe1e2ca1  pop rax
00007a3fbe1e2ca2  add rsp, 0x08
00007a3fbe1e2ca6  jmp 0x00007A3FBE1DF638
00007a3fbe1e2cab  sub rsp, 0x08
00007a3fbe1e2caf  push rax
00007a3fbe1e2cb0  push rcx
00007a3fbe1e2cb1  push rdx
00007a3fbe1e2cb2  push rdi
00007a3fbe1e2cb3  push rsi
00007a3fbe1e2cb4  push r8
00007a3fbe1e2cb6  push r9
00007a3fbe1e2cb8  push r10
00007a3fbe1e2cba  push r11
00007a3fbe1e2cbc  sub rsp, 0xF0
00007a3fbe1e2cc3  vmovaps [rsp], xmm0
00007a3fbe1e2cc8  vmovaps [rsp+0x10], xmm1
00007a3fbe1e2cce  vmovaps [rsp+0x20], xmm2
00007a3fbe1e2cd4  vmovaps [rsp+0x30], xmm3
00007a3fbe1e2cda  vmovaps [rsp+0x40], xmm4
00007a3fbe1e2ce0  vmovaps [rsp+0x50], xmm5
00007a3fbe1e2ce6  vmovaps [rsp+0x60], xmm6
00007a3fbe1e2cec  vmovaps [rsp+0x70], xmm7
00007a3fbe1e2cf2  vmovaps [rsp+0x80], xmm8
00007a3fbe1e2cfb  vmovaps [rsp+0x90], xmm9
00007a3fbe1e2d04  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e2d0d  vmovaps [rsp+0xB0], xmm11
00007a3fbe1e2d16  vmovaps [rsp+0xC0], xmm12
00007a3fbe1e2d1f  vmovaps [rsp+0xD0], xmm13
00007a3fbe1e2d28  vmovaps [rsp+0xE0], xmm14
00007a3fbe1e2d31  sub rsp, 0x30
00007a3fbe1e2d35  movaps [rsp], xmm15
00007a3fbe1e2d3a  movaps [rsp+0x10], xmm1
00007a3fbe1e2d3f  movaps [rsp+0x20], xmm5
00007a3fbe1e2d44  lea rdi, [rsp]
00007a3fbe1e2d48  mov esi, 0x00
00007a3fbe1e2d4d  mov rax, 0x60D1084DB530
00007a3fbe1e2d57  call rax
00007a3fbe1e2d59  movaps xmm15, [rsp]
00007a3fbe1e2d5e  add rsp, 0x30
00007a3fbe1e2d62  vmovaps xmm0, [rsp]
00007a3fbe1e2d67  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e2d6d  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e2d73  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e2d79  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e2d7f  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e2d85  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e2d8b  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e2d91  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e2d9a  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e2da3  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e2dac  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1e2db5  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1e2dbe  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1e2dc7  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1e2dd0  add rsp, 0xF0
00007a3fbe1e2dd7  pop r11
00007a3fbe1e2dd9  pop r10
00007a3fbe1e2ddb  pop r9
00007a3fbe1e2ddd  pop r8
00007a3fbe1e2ddf  pop rsi
00007a3fbe1e2de0  pop rdi
00007a3fbe1e2de1  pop rdx
00007a3fbe1e2de2  pop rcx
00007a3fbe1e2de3  pop rax
00007a3fbe1e2de4  add rsp, 0x08
00007a3fbe1e2de8  jmp 0x00007A3FBE1DF653
00007a3fbe1e2ded  call 0x00007A3FBE0B52F0
00007a3fbe1e2df2  jmp 0x00007A3FBE1DF6AE
00007a3fbe1e2df7  sub rsp, 0x08
00007a3fbe1e2dfb  push rax
00007a3fbe1e2dfc  push rcx
00007a3fbe1e2dfd  push rdx
00007a3fbe1e2dfe  push rdi
00007a3fbe1e2dff  push rsi
00007a3fbe1e2e00  push r8
00007a3fbe1e2e02  push r9
00007a3fbe1e2e04  push r10
00007a3fbe1e2e06  push r11
00007a3fbe1e2e08  sub rsp, 0xF0
00007a3fbe1e2e0f  vmovaps [rsp], xmm0
00007a3fbe1e2e14  vmovaps [rsp+0x10], xmm1
00007a3fbe1e2e1a  vmovaps [rsp+0x20], xmm2
00007a3fbe1e2e20  vmovaps [rsp+0x30], xmm3
00007a3fbe1e2e26  vmovaps [rsp+0x40], xmm4
00007a3fbe1e2e2c  vmovaps [rsp+0x50], xmm5
00007a3fbe1e2e32  vmovaps [rsp+0x60], xmm6
00007a3fbe1e2e38  vmovaps [rsp+0x70], xmm7
00007a3fbe1e2e3e  vmovaps [rsp+0x80], xmm8
00007a3fbe1e2e47  vmovaps [rsp+0x90], xmm10
00007a3fbe1e2e50  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e2e59  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e2e62  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e2e6b  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e2e74  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e2e7d  sub rsp, 0x30
00007a3fbe1e2e81  movaps [rsp], xmm9
00007a3fbe1e2e86  movaps [rsp+0x10], xmm8
00007a3fbe1e2e8c  movaps [rsp+0x20], xmm11
00007a3fbe1e2e92  lea rdi, [rsp]
00007a3fbe1e2e96  mov esi, 0x00
00007a3fbe1e2e9b  mov rax, 0x60D1084DB530
00007a3fbe1e2ea5  call rax
00007a3fbe1e2ea7  movaps xmm9, [rsp]
00007a3fbe1e2eac  add rsp, 0x30
00007a3fbe1e2eb0  vmovaps xmm0, [rsp]
00007a3fbe1e2eb5  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e2ebb  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e2ec1  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e2ec7  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e2ecd  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e2ed3  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e2ed9  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e2edf  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e2ee8  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e2ef1  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e2efa  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e2f03  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e2f0c  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e2f15  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e2f1e  add rsp, 0xF0
00007a3fbe1e2f25  pop r11
00007a3fbe1e2f27  pop r10
00007a3fbe1e2f29  pop r9
00007a3fbe1e2f2b  pop r8
00007a3fbe1e2f2d  pop rsi
00007a3fbe1e2f2e  pop rdi
00007a3fbe1e2f2f  pop rdx
00007a3fbe1e2f30  pop rcx
00007a3fbe1e2f31  pop rax
00007a3fbe1e2f32  add rsp, 0x08
00007a3fbe1e2f36  jmp 0x00007A3FBE1DF6E5
00007a3fbe1e2f3b  sub rsp, 0x08
00007a3fbe1e2f3f  push rax
00007a3fbe1e2f40  push rcx
00007a3fbe1e2f41  push rdx
00007a3fbe1e2f42  push rdi
00007a3fbe1e2f43  push rsi
00007a3fbe1e2f44  push r8
00007a3fbe1e2f46  push r9
00007a3fbe1e2f48  push r10
00007a3fbe1e2f4a  push r11
00007a3fbe1e2f4c  sub rsp, 0xF0
00007a3fbe1e2f53  vmovaps [rsp], xmm0
00007a3fbe1e2f58  vmovaps [rsp+0x10], xmm1
00007a3fbe1e2f5e  vmovaps [rsp+0x20], xmm2
00007a3fbe1e2f64  vmovaps [rsp+0x30], xmm3
00007a3fbe1e2f6a  vmovaps [rsp+0x40], xmm4
00007a3fbe1e2f70  vmovaps [rsp+0x50], xmm5
00007a3fbe1e2f76  vmovaps [rsp+0x60], xmm6
00007a3fbe1e2f7c  vmovaps [rsp+0x70], xmm7
00007a3fbe1e2f82  vmovaps [rsp+0x80], xmm8
00007a3fbe1e2f8b  vmovaps [rsp+0x90], xmm9
00007a3fbe1e2f94  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e2f9d  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e2fa6  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e2faf  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e2fb8  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e2fc1  sub rsp, 0x30
00007a3fbe1e2fc5  movaps [rsp], xmm11
00007a3fbe1e2fca  movaps [rsp+0x10], xmm10
00007a3fbe1e2fd0  movaps [rsp+0x20], xmm6
00007a3fbe1e2fd5  lea rdi, [rsp]
00007a3fbe1e2fd9  mov esi, 0x00
00007a3fbe1e2fde  mov rax, 0x60D1084DB530
00007a3fbe1e2fe8  call rax
00007a3fbe1e2fea  movaps xmm11, [rsp]
00007a3fbe1e2fef  add rsp, 0x30
00007a3fbe1e2ff3  vmovaps xmm0, [rsp]
00007a3fbe1e2ff8  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e2ffe  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e3004  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e300a  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e3010  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e3016  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e301c  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e3022  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e302b  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e3034  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e303d  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e3046  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e304f  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e3058  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e3061  add rsp, 0xF0
00007a3fbe1e3068  pop r11
00007a3fbe1e306a  pop r10
00007a3fbe1e306c  pop r9
00007a3fbe1e306e  pop r8
00007a3fbe1e3070  pop rsi
00007a3fbe1e3071  pop rdi
00007a3fbe1e3072  pop rdx
00007a3fbe1e3073  pop rcx
00007a3fbe1e3074  pop rax
00007a3fbe1e3075  add rsp, 0x08
00007a3fbe1e3079  jmp 0x00007A3FBE1DF700
00007a3fbe1e307e  sub rsp, 0x08
00007a3fbe1e3082  push rax
00007a3fbe1e3083  push rcx
00007a3fbe1e3084  push rdx
00007a3fbe1e3085  push rdi
00007a3fbe1e3086  push rsi
00007a3fbe1e3087  push r8
00007a3fbe1e3089  push r9
00007a3fbe1e308b  push r10
00007a3fbe1e308d  push r11
00007a3fbe1e308f  sub rsp, 0xF0
00007a3fbe1e3096  vmovaps [rsp], xmm0
00007a3fbe1e309b  vmovaps [rsp+0x10], xmm1
00007a3fbe1e30a1  vmovaps [rsp+0x20], xmm2
00007a3fbe1e30a7  vmovaps [rsp+0x30], xmm3
00007a3fbe1e30ad  vmovaps [rsp+0x40], xmm4
00007a3fbe1e30b3  vmovaps [rsp+0x50], xmm5
00007a3fbe1e30b9  vmovaps [rsp+0x60], xmm6
00007a3fbe1e30bf  vmovaps [rsp+0x70], xmm7
00007a3fbe1e30c5  vmovaps [rsp+0x80], xmm8
00007a3fbe1e30ce  vmovaps [rsp+0x90], xmm9
00007a3fbe1e30d7  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e30e0  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e30e9  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e30f2  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e30fb  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e3104  sub rsp, 0x30
00007a3fbe1e3108  movaps [rsp], xmm10
00007a3fbe1e310d  movaps [rsp+0x10], xmm14
00007a3fbe1e3113  movaps [rsp+0x20], xmm4
00007a3fbe1e3118  lea rdi, [rsp]
00007a3fbe1e311c  mov esi, 0x00
00007a3fbe1e3121  mov rax, 0x60D1084DB530
00007a3fbe1e312b  call rax
00007a3fbe1e312d  movaps xmm10, [rsp]
00007a3fbe1e3132  add rsp, 0x30
00007a3fbe1e3136  vmovaps xmm0, [rsp]
00007a3fbe1e313b  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e3141  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e3147  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e314d  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e3153  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e3159  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e315f  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e3165  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e316e  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e3177  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e3180  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e3189  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e3192  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e319b  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e31a4  add rsp, 0xF0
00007a3fbe1e31ab  pop r11
00007a3fbe1e31ad  pop r10
00007a3fbe1e31af  pop r9
00007a3fbe1e31b1  pop r8
00007a3fbe1e31b3  pop rsi
00007a3fbe1e31b4  pop rdi
00007a3fbe1e31b5  pop rdx
00007a3fbe1e31b6  pop rcx
00007a3fbe1e31b7  pop rax
00007a3fbe1e31b8  add rsp, 0x08
00007a3fbe1e31bc  jmp 0x00007A3FBE1DF71B
00007a3fbe1e31c1  sub rsp, 0x08
00007a3fbe1e31c5  push rax
00007a3fbe1e31c6  push rcx
00007a3fbe1e31c7  push rdx
00007a3fbe1e31c8  push rdi
00007a3fbe1e31c9  push rsi
00007a3fbe1e31ca  push r8
00007a3fbe1e31cc  push r9
00007a3fbe1e31ce  push r10
00007a3fbe1e31d0  push r11
00007a3fbe1e31d2  sub rsp, 0xF0
00007a3fbe1e31d9  vmovaps [rsp], xmm0
00007a3fbe1e31de  vmovaps [rsp+0x10], xmm1
00007a3fbe1e31e4  vmovaps [rsp+0x20], xmm2
00007a3fbe1e31ea  vmovaps [rsp+0x30], xmm3
00007a3fbe1e31f0  vmovaps [rsp+0x40], xmm4
00007a3fbe1e31f6  vmovaps [rsp+0x50], xmm5
00007a3fbe1e31fc  vmovaps [rsp+0x60], xmm6
00007a3fbe1e3202  vmovaps [rsp+0x70], xmm7
00007a3fbe1e3208  vmovaps [rsp+0x80], xmm9
00007a3fbe1e3211  vmovaps [rsp+0x90], xmm10
00007a3fbe1e321a  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e3223  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e322c  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e3235  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e323e  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e3247  sub rsp, 0x30
00007a3fbe1e324b  movaps [rsp], xmm8
00007a3fbe1e3250  movaps [rsp+0x10], xmm1
00007a3fbe1e3255  movaps [rsp+0x20], xmm14
00007a3fbe1e325b  lea rdi, [rsp]
00007a3fbe1e325f  mov esi, 0x00
00007a3fbe1e3264  mov rax, 0x60D1084DB530
00007a3fbe1e326e  call rax
00007a3fbe1e3270  movaps xmm8, [rsp]
00007a3fbe1e3275  add rsp, 0x30
00007a3fbe1e3279  vmovaps xmm0, [rsp]
00007a3fbe1e327e  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e3284  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e328a  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e3290  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e3296  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e329c  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e32a2  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e32a8  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e32b1  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e32ba  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e32c3  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e32cc  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e32d5  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e32de  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e32e7  add rsp, 0xF0
00007a3fbe1e32ee  pop r11
00007a3fbe1e32f0  pop r10
00007a3fbe1e32f2  pop r9
00007a3fbe1e32f4  pop r8
00007a3fbe1e32f6  pop rsi
00007a3fbe1e32f7  pop rdi
00007a3fbe1e32f8  pop rdx
00007a3fbe1e32f9  pop rcx
00007a3fbe1e32fa  pop rax
00007a3fbe1e32fb  add rsp, 0x08
00007a3fbe1e32ff  jmp 0x00007A3FBE1DF741
00007a3fbe1e3304  sub rsp, 0x08
00007a3fbe1e3308  push rax
00007a3fbe1e3309  push rcx
00007a3fbe1e330a  push rdx
00007a3fbe1e330b  push rdi
00007a3fbe1e330c  push rsi
00007a3fbe1e330d  push r8
00007a3fbe1e330f  push r9
00007a3fbe1e3311  push r10
00007a3fbe1e3313  push r11
00007a3fbe1e3315  sub rsp, 0xF0
00007a3fbe1e331c  vmovaps [rsp], xmm0
00007a3fbe1e3321  vmovaps [rsp+0x10], xmm1
00007a3fbe1e3327  vmovaps [rsp+0x20], xmm2
00007a3fbe1e332d  vmovaps [rsp+0x30], xmm3
00007a3fbe1e3333  vmovaps [rsp+0x40], xmm4
00007a3fbe1e3339  vmovaps [rsp+0x50], xmm5
00007a3fbe1e333f  vmovaps [rsp+0x60], xmm7
00007a3fbe1e3345  vmovaps [rsp+0x70], xmm8
00007a3fbe1e334b  vmovaps [rsp+0x80], xmm9
00007a3fbe1e3354  vmovaps [rsp+0x90], xmm10
00007a3fbe1e335d  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e3366  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e336f  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e3378  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e3381  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e338a  sub rsp, 0x30
00007a3fbe1e338e  movaps [rsp], xmm6
00007a3fbe1e3392  movaps [rsp+0x10], xmm1
00007a3fbe1e3397  movaps [rsp+0x20], xmm14
00007a3fbe1e339d  lea rdi, [rsp]
00007a3fbe1e33a1  mov esi, 0x00
00007a3fbe1e33a6  mov rax, 0x60D1084DB530
00007a3fbe1e33b0  call rax
00007a3fbe1e33b2  movaps xmm6, [rsp]
00007a3fbe1e33b6  add rsp, 0x30
00007a3fbe1e33ba  vmovaps xmm0, [rsp]
00007a3fbe1e33bf  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e33c5  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e33cb  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e33d1  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e33d7  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e33dd  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e33e3  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e33e9  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e33f2  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e33fb  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e3404  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e340d  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e3416  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e341f  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e3428  add rsp, 0xF0
00007a3fbe1e342f  pop r11
00007a3fbe1e3431  pop r10
00007a3fbe1e3433  pop r9
00007a3fbe1e3435  pop r8
00007a3fbe1e3437  pop rsi
00007a3fbe1e3438  pop rdi
00007a3fbe1e3439  pop rdx
00007a3fbe1e343a  pop rcx
00007a3fbe1e343b  pop rax
00007a3fbe1e343c  add rsp, 0x08
00007a3fbe1e3440  jmp 0x00007A3FBE1DF76D
00007a3fbe1e3445  sub rsp, 0x08
00007a3fbe1e3449  push rax
00007a3fbe1e344a  push rcx
00007a3fbe1e344b  push rdx
00007a3fbe1e344c  push rdi
00007a3fbe1e344d  push rsi
00007a3fbe1e344e  push r8
00007a3fbe1e3450  push r9
00007a3fbe1e3452  push r10
00007a3fbe1e3454  push r11
00007a3fbe1e3456  sub rsp, 0xF0
00007a3fbe1e345d  vmovaps [rsp], xmm0
00007a3fbe1e3462  vmovaps [rsp+0x10], xmm1
00007a3fbe1e3468  vmovaps [rsp+0x20], xmm2
00007a3fbe1e346e  vmovaps [rsp+0x30], xmm3
00007a3fbe1e3474  vmovaps [rsp+0x40], xmm4
00007a3fbe1e347a  vmovaps [rsp+0x50], xmm5
00007a3fbe1e3480  vmovaps [rsp+0x60], xmm6
00007a3fbe1e3486  vmovaps [rsp+0x70], xmm7
00007a3fbe1e348c  vmovaps [rsp+0x80], xmm8
00007a3fbe1e3495  vmovaps [rsp+0x90], xmm9
00007a3fbe1e349e  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e34a7  vmovaps [rsp+0xB0], xmm11
00007a3fbe1e34b0  vmovaps [rsp+0xC0], xmm12
00007a3fbe1e34b9  vmovaps [rsp+0xD0], xmm13
00007a3fbe1e34c2  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e34cb  sub rsp, 0x30
00007a3fbe1e34cf  movaps [rsp], xmm14
00007a3fbe1e34d4  movaps [rsp+0x10], xmm12
00007a3fbe1e34da  movaps [rsp+0x20], xmm1
00007a3fbe1e34df  lea rdi, [rsp]
00007a3fbe1e34e3  mov esi, 0x00
00007a3fbe1e34e8  mov rax, 0x60D1084DB530
00007a3fbe1e34f2  call rax
00007a3fbe1e34f4  movaps xmm14, [rsp]
00007a3fbe1e34f9  add rsp, 0x30
00007a3fbe1e34fd  vmovaps xmm0, [rsp]
00007a3fbe1e3502  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e3508  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e350e  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e3514  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e351a  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e3520  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e3526  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e352c  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e3535  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e353e  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e3547  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1e3550  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1e3559  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1e3562  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e356b  add rsp, 0xF0
00007a3fbe1e3572  pop r11
00007a3fbe1e3574  pop r10
00007a3fbe1e3576  pop r9
00007a3fbe1e3578  pop r8
00007a3fbe1e357a  pop rsi
00007a3fbe1e357b  pop rdi
00007a3fbe1e357c  pop rdx
00007a3fbe1e357d  pop rcx
00007a3fbe1e357e  pop rax
00007a3fbe1e357f  add rsp, 0x08
00007a3fbe1e3583  jmp 0x00007A3FBE1DF793
00007a3fbe1e3588  sub rsp, 0x08
00007a3fbe1e358c  push rax
00007a3fbe1e358d  push rcx
00007a3fbe1e358e  push rdx
00007a3fbe1e358f  push rdi
00007a3fbe1e3590  push rsi
00007a3fbe1e3591  push r8
00007a3fbe1e3593  push r9
00007a3fbe1e3595  push r10
00007a3fbe1e3597  push r11
00007a3fbe1e3599  sub rsp, 0xF0
00007a3fbe1e35a0  vmovaps [rsp], xmm0
00007a3fbe1e35a5  vmovaps [rsp+0x10], xmm2
00007a3fbe1e35ab  vmovaps [rsp+0x20], xmm3
00007a3fbe1e35b1  vmovaps [rsp+0x30], xmm4
00007a3fbe1e35b7  vmovaps [rsp+0x40], xmm5
00007a3fbe1e35bd  vmovaps [rsp+0x50], xmm6
00007a3fbe1e35c3  vmovaps [rsp+0x60], xmm7
00007a3fbe1e35c9  vmovaps [rsp+0x70], xmm8
00007a3fbe1e35cf  vmovaps [rsp+0x80], xmm9
00007a3fbe1e35d8  vmovaps [rsp+0x90], xmm10
00007a3fbe1e35e1  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e35ea  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e35f3  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e35fc  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e3605  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e360e  sub rsp, 0x30
00007a3fbe1e3612  movaps [rsp], xmm1
00007a3fbe1e3616  movaps [rsp+0x10], xmm13
00007a3fbe1e361c  movaps [rsp+0x20], xmm9
00007a3fbe1e3622  lea rdi, [rsp]
00007a3fbe1e3626  mov esi, 0x00
00007a3fbe1e362b  mov rax, 0x60D1084DB530
00007a3fbe1e3635  call rax
00007a3fbe1e3637  movaps xmm1, [rsp]
00007a3fbe1e363b  add rsp, 0x30
00007a3fbe1e363f  vmovaps xmm0, [rsp]
00007a3fbe1e3644  vmovaps xmm2, [rsp+0x10]
00007a3fbe1e364a  vmovaps xmm3, [rsp+0x20]
00007a3fbe1e3650  vmovaps xmm4, [rsp+0x30]
00007a3fbe1e3656  vmovaps xmm5, [rsp+0x40]
00007a3fbe1e365c  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e3662  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e3668  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e366e  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e3677  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e3680  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e3689  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e3692  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e369b  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e36a4  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e36ad  add rsp, 0xF0
00007a3fbe1e36b4  pop r11
00007a3fbe1e36b6  pop r10
00007a3fbe1e36b8  pop r9
00007a3fbe1e36ba  pop r8
00007a3fbe1e36bc  pop rsi
00007a3fbe1e36bd  pop rdi
00007a3fbe1e36be  pop rdx
00007a3fbe1e36bf  pop rcx
00007a3fbe1e36c0  pop rax
00007a3fbe1e36c1  add rsp, 0x08
00007a3fbe1e36c5  jmp 0x00007A3FBE1DF7AD
00007a3fbe1e36ca  sub rsp, 0x08
00007a3fbe1e36ce  push rax
00007a3fbe1e36cf  push rcx
00007a3fbe1e36d0  push rdx
00007a3fbe1e36d1  push rdi
00007a3fbe1e36d2  push rsi
00007a3fbe1e36d3  push r8
00007a3fbe1e36d5  push r9
00007a3fbe1e36d7  push r10
00007a3fbe1e36d9  push r11
00007a3fbe1e36db  sub rsp, 0xF0
00007a3fbe1e36e2  vmovaps [rsp], xmm0
00007a3fbe1e36e7  vmovaps [rsp+0x10], xmm1
00007a3fbe1e36ed  vmovaps [rsp+0x20], xmm2
00007a3fbe1e36f3  vmovaps [rsp+0x30], xmm3
00007a3fbe1e36f9  vmovaps [rsp+0x40], xmm4
00007a3fbe1e36ff  vmovaps [rsp+0x50], xmm5
00007a3fbe1e3705  vmovaps [rsp+0x60], xmm6
00007a3fbe1e370b  vmovaps [rsp+0x70], xmm7
00007a3fbe1e3711  vmovaps [rsp+0x80], xmm8
00007a3fbe1e371a  vmovaps [rsp+0x90], xmm9
00007a3fbe1e3723  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e372c  vmovaps [rsp+0xB0], xmm11
00007a3fbe1e3735  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e373e  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e3747  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e3750  sub rsp, 0x30
00007a3fbe1e3754  movaps [rsp], xmm12
00007a3fbe1e3759  movaps [rsp+0x10], xmm7
00007a3fbe1e375e  movaps [rsp+0x20], xmm13
00007a3fbe1e3764  lea rdi, [rsp]
00007a3fbe1e3768  mov esi, 0x00
00007a3fbe1e376d  mov rax, 0x60D1084DB530
00007a3fbe1e3777  call rax
00007a3fbe1e3779  movaps xmm12, [rsp]
00007a3fbe1e377e  add rsp, 0x30
00007a3fbe1e3782  vmovaps xmm0, [rsp]
00007a3fbe1e3787  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e378d  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e3793  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e3799  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e379f  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e37a5  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e37ab  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e37b1  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e37ba  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e37c3  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e37cc  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1e37d5  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e37de  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e37e7  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e37f0  add rsp, 0xF0
00007a3fbe1e37f7  pop r11
00007a3fbe1e37f9  pop r10
00007a3fbe1e37fb  pop r9
00007a3fbe1e37fd  pop r8
00007a3fbe1e37ff  pop rsi
00007a3fbe1e3800  pop rdi
00007a3fbe1e3801  pop rdx
00007a3fbe1e3802  pop rcx
00007a3fbe1e3803  pop rax
00007a3fbe1e3804  add rsp, 0x08
00007a3fbe1e3808  jmp 0x00007A3FBE1DF7D4
00007a3fbe1e380d  sub rsp, 0x08
00007a3fbe1e3811  push rax
00007a3fbe1e3812  push rcx
00007a3fbe1e3813  push rdx
00007a3fbe1e3814  push rdi
00007a3fbe1e3815  push rsi
00007a3fbe1e3816  push r8
00007a3fbe1e3818  push r9
00007a3fbe1e381a  push r10
00007a3fbe1e381c  push r11
00007a3fbe1e381e  sub rsp, 0xF0
00007a3fbe1e3825  vmovaps [rsp], xmm0
00007a3fbe1e382a  vmovaps [rsp+0x10], xmm1
00007a3fbe1e3830  vmovaps [rsp+0x20], xmm2
00007a3fbe1e3836  vmovaps [rsp+0x30], xmm3
00007a3fbe1e383c  vmovaps [rsp+0x40], xmm4
00007a3fbe1e3842  vmovaps [rsp+0x50], xmm5
00007a3fbe1e3848  vmovaps [rsp+0x60], xmm6
00007a3fbe1e384e  vmovaps [rsp+0x70], xmm7
00007a3fbe1e3854  vmovaps [rsp+0x80], xmm8
00007a3fbe1e385d  vmovaps [rsp+0x90], xmm9
00007a3fbe1e3866  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e386f  vmovaps [rsp+0xB0], xmm11
00007a3fbe1e3878  vmovaps [rsp+0xC0], xmm12
00007a3fbe1e3881  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e388a  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e3893  sub rsp, 0x30
00007a3fbe1e3897  movaps [rsp], xmm13
00007a3fbe1e389c  movaps [rsp+0x10], xmm15
00007a3fbe1e38a2  movaps [rsp+0x20], xmm8
00007a3fbe1e38a8  lea rdi, [rsp]
00007a3fbe1e38ac  mov esi, 0x00
00007a3fbe1e38b1  mov rax, 0x60D1084DB530
00007a3fbe1e38bb  call rax
00007a3fbe1e38bd  movaps xmm13, [rsp]
00007a3fbe1e38c2  add rsp, 0x30
00007a3fbe1e38c6  vmovaps xmm0, [rsp]
00007a3fbe1e38cb  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e38d1  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e38d7  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e38dd  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e38e3  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e38e9  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e38ef  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e38f5  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e38fe  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e3907  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e3910  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1e3919  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1e3922  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e392b  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e3934  add rsp, 0xF0
00007a3fbe1e393b  pop r11
00007a3fbe1e393d  pop r10
00007a3fbe1e393f  pop r9
00007a3fbe1e3941  pop r8
00007a3fbe1e3943  pop rsi
00007a3fbe1e3944  pop rdi
00007a3fbe1e3945  pop rdx
00007a3fbe1e3946  pop rcx
00007a3fbe1e3947  pop rax
00007a3fbe1e3948  add rsp, 0x08
00007a3fbe1e394c  jmp 0x00007A3FBE1DF7EF
00007a3fbe1e3951  sub rsp, 0x08
00007a3fbe1e3955  push rax
00007a3fbe1e3956  push rcx
00007a3fbe1e3957  push rdx
00007a3fbe1e3958  push rdi
00007a3fbe1e3959  push rsi
00007a3fbe1e395a  push r8
00007a3fbe1e395c  push r9
00007a3fbe1e395e  push r10
00007a3fbe1e3960  push r11
00007a3fbe1e3962  sub rsp, 0xF0
00007a3fbe1e3969  vmovaps [rsp], xmm0
00007a3fbe1e396e  vmovaps [rsp+0x10], xmm1
00007a3fbe1e3974  vmovaps [rsp+0x20], xmm2
00007a3fbe1e397a  vmovaps [rsp+0x30], xmm3
00007a3fbe1e3980  vmovaps [rsp+0x40], xmm4
00007a3fbe1e3986  vmovaps [rsp+0x50], xmm5
00007a3fbe1e398c  vmovaps [rsp+0x60], xmm6
00007a3fbe1e3992  vmovaps [rsp+0x70], xmm7
00007a3fbe1e3998  vmovaps [rsp+0x80], xmm9
00007a3fbe1e39a1  vmovaps [rsp+0x90], xmm10
00007a3fbe1e39aa  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e39b3  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e39bc  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e39c5  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e39ce  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e39d7  sub rsp, 0x30
00007a3fbe1e39db  movaps [rsp], xmm8
00007a3fbe1e39e0  movaps [rsp+0x10], xmm15
00007a3fbe1e39e6  movaps [rsp+0x20], xmm9
00007a3fbe1e39ec  lea rdi, [rsp]
00007a3fbe1e39f0  mov esi, 0x00
00007a3fbe1e39f5  mov rax, 0x60D1084DB530
00007a3fbe1e39ff  call rax
00007a3fbe1e3a01  movaps xmm8, [rsp]
00007a3fbe1e3a06  add rsp, 0x30
00007a3fbe1e3a0a  vmovaps xmm0, [rsp]
00007a3fbe1e3a0f  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e3a15  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e3a1b  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e3a21  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e3a27  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e3a2d  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e3a33  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e3a39  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e3a42  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e3a4b  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e3a54  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e3a5d  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e3a66  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e3a6f  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e3a78  add rsp, 0xF0
00007a3fbe1e3a7f  pop r11
00007a3fbe1e3a81  pop r10
00007a3fbe1e3a83  pop r9
00007a3fbe1e3a85  pop r8
00007a3fbe1e3a87  pop rsi
00007a3fbe1e3a88  pop rdi
00007a3fbe1e3a89  pop rdx
00007a3fbe1e3a8a  pop rcx
00007a3fbe1e3a8b  pop rax
00007a3fbe1e3a8c  add rsp, 0x08
00007a3fbe1e3a90  jmp 0x00007A3FBE1DF81D
00007a3fbe1e3a95  sub rsp, 0x08
00007a3fbe1e3a99  push rax
00007a3fbe1e3a9a  push rcx
00007a3fbe1e3a9b  push rdx
00007a3fbe1e3a9c  push rdi
00007a3fbe1e3a9d  push rsi
00007a3fbe1e3a9e  push r8
00007a3fbe1e3aa0  push r9
00007a3fbe1e3aa2  push r10
00007a3fbe1e3aa4  push r11
00007a3fbe1e3aa6  sub rsp, 0xF0
00007a3fbe1e3aad  vmovaps [rsp], xmm0
00007a3fbe1e3ab2  vmovaps [rsp+0x10], xmm1
00007a3fbe1e3ab8  vmovaps [rsp+0x20], xmm2
00007a3fbe1e3abe  vmovaps [rsp+0x30], xmm3
00007a3fbe1e3ac4  vmovaps [rsp+0x40], xmm4
00007a3fbe1e3aca  vmovaps [rsp+0x50], xmm5
00007a3fbe1e3ad0  vmovaps [rsp+0x60], xmm6
00007a3fbe1e3ad6  vmovaps [rsp+0x70], xmm7
00007a3fbe1e3adc  vmovaps [rsp+0x80], xmm8
00007a3fbe1e3ae5  vmovaps [rsp+0x90], xmm9
00007a3fbe1e3aee  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e3af7  vmovaps [rsp+0xB0], xmm11
00007a3fbe1e3b00  vmovaps [rsp+0xC0], xmm12
00007a3fbe1e3b09  vmovaps [rsp+0xD0], xmm13
00007a3fbe1e3b12  vmovaps [rsp+0xE0], xmm14
00007a3fbe1e3b1b  sub rsp, 0x30
00007a3fbe1e3b1f  movaps [rsp], xmm15
00007a3fbe1e3b24  movaps [rsp+0x10], xmm11
00007a3fbe1e3b2a  movaps [rsp+0x20], xmm6
00007a3fbe1e3b2f  lea rdi, [rsp]
00007a3fbe1e3b33  mov esi, 0x00
00007a3fbe1e3b38  mov rax, 0x60D1084DB530
00007a3fbe1e3b42  call rax
00007a3fbe1e3b44  movaps xmm15, [rsp]
00007a3fbe1e3b49  add rsp, 0x30
00007a3fbe1e3b4d  vmovaps xmm0, [rsp]
00007a3fbe1e3b52  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e3b58  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e3b5e  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e3b64  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e3b6a  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e3b70  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e3b76  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e3b7c  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e3b85  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e3b8e  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e3b97  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1e3ba0  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1e3ba9  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1e3bb2  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1e3bbb  add rsp, 0xF0
00007a3fbe1e3bc2  pop r11
00007a3fbe1e3bc4  pop r10
00007a3fbe1e3bc6  pop r9
00007a3fbe1e3bc8  pop r8
00007a3fbe1e3bca  pop rsi
00007a3fbe1e3bcb  pop rdi
00007a3fbe1e3bcc  pop rdx
00007a3fbe1e3bcd  pop rcx
00007a3fbe1e3bce  pop rax
00007a3fbe1e3bcf  add rsp, 0x08
00007a3fbe1e3bd3  jmp 0x00007A3FBE1DF838
00007a3fbe1e3bd8  sub rsp, 0x08
00007a3fbe1e3bdc  push rax
00007a3fbe1e3bdd  push rcx
00007a3fbe1e3bde  push rdx
00007a3fbe1e3bdf  push rdi
00007a3fbe1e3be0  push rsi
00007a3fbe1e3be1  push r8
00007a3fbe1e3be3  push r9
00007a3fbe1e3be5  push r10
00007a3fbe1e3be7  push r11
00007a3fbe1e3be9  sub rsp, 0xF0
00007a3fbe1e3bf0  vmovaps [rsp], xmm0
00007a3fbe1e3bf5  vmovaps [rsp+0x10], xmm1
00007a3fbe1e3bfb  vmovaps [rsp+0x20], xmm2
00007a3fbe1e3c01  vmovaps [rsp+0x30], xmm3
00007a3fbe1e3c07  vmovaps [rsp+0x40], xmm4
00007a3fbe1e3c0d  vmovaps [rsp+0x50], xmm5
00007a3fbe1e3c13  vmovaps [rsp+0x60], xmm6
00007a3fbe1e3c19  vmovaps [rsp+0x70], xmm8
00007a3fbe1e3c1f  vmovaps [rsp+0x80], xmm9
00007a3fbe1e3c28  vmovaps [rsp+0x90], xmm10
00007a3fbe1e3c31  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e3c3a  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e3c43  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e3c4c  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e3c55  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e3c5e  sub rsp, 0x30
00007a3fbe1e3c62  movaps [rsp], xmm7
00007a3fbe1e3c66  movaps [rsp+0x10], xmm11
00007a3fbe1e3c6c  movaps [rsp+0x20], xmm9
00007a3fbe1e3c72  lea rdi, [rsp]
00007a3fbe1e3c76  mov esi, 0x00
00007a3fbe1e3c7b  mov rax, 0x60D1084DB530
00007a3fbe1e3c85  call rax
00007a3fbe1e3c87  movaps xmm7, [rsp]
00007a3fbe1e3c8b  add rsp, 0x30
00007a3fbe1e3c8f  vmovaps xmm0, [rsp]
00007a3fbe1e3c94  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e3c9a  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e3ca0  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e3ca6  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e3cac  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e3cb2  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e3cb8  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e3cbe  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e3cc7  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e3cd0  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e3cd9  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e3ce2  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e3ceb  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e3cf4  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e3cfd  add rsp, 0xF0
00007a3fbe1e3d04  pop r11
00007a3fbe1e3d06  pop r10
00007a3fbe1e3d08  pop r9
00007a3fbe1e3d0a  pop r8
00007a3fbe1e3d0c  pop rsi
00007a3fbe1e3d0d  pop rdi
00007a3fbe1e3d0e  pop rdx
00007a3fbe1e3d0f  pop rcx
00007a3fbe1e3d10  pop rax
00007a3fbe1e3d11  add rsp, 0x08
00007a3fbe1e3d15  jmp 0x00007A3FBE1DF865
00007a3fbe1e3d1a  sub rsp, 0x08
00007a3fbe1e3d1e  push rax
00007a3fbe1e3d1f  push rcx
00007a3fbe1e3d20  push rdx
00007a3fbe1e3d21  push rdi
00007a3fbe1e3d22  push rsi
00007a3fbe1e3d23  push r8
00007a3fbe1e3d25  push r9
00007a3fbe1e3d27  push r10
00007a3fbe1e3d29  push r11
00007a3fbe1e3d2b  sub rsp, 0xF0
00007a3fbe1e3d32  vmovaps [rsp], xmm0
00007a3fbe1e3d37  vmovaps [rsp+0x10], xmm1
00007a3fbe1e3d3d  vmovaps [rsp+0x20], xmm2
00007a3fbe1e3d43  vmovaps [rsp+0x30], xmm3
00007a3fbe1e3d49  vmovaps [rsp+0x40], xmm4
00007a3fbe1e3d4f  vmovaps [rsp+0x50], xmm5
00007a3fbe1e3d55  vmovaps [rsp+0x60], xmm6
00007a3fbe1e3d5b  vmovaps [rsp+0x70], xmm7
00007a3fbe1e3d61  vmovaps [rsp+0x80], xmm8
00007a3fbe1e3d6a  vmovaps [rsp+0x90], xmm9
00007a3fbe1e3d73  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e3d7c  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e3d85  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e3d8e  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e3d97  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e3da0  sub rsp, 0x30
00007a3fbe1e3da4  movaps [rsp], xmm11
00007a3fbe1e3da9  movaps [rsp+0x10], xmm10
00007a3fbe1e3daf  movaps [rsp+0x20], xmm14
00007a3fbe1e3db5  lea rdi, [rsp]
00007a3fbe1e3db9  mov esi, 0x00
00007a3fbe1e3dbe  mov rax, 0x60D1084DB530
00007a3fbe1e3dc8  call rax
00007a3fbe1e3dca  movaps xmm11, [rsp]
00007a3fbe1e3dcf  add rsp, 0x30
00007a3fbe1e3dd3  vmovaps xmm0, [rsp]
00007a3fbe1e3dd8  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e3dde  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e3de4  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e3dea  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e3df0  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e3df6  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e3dfc  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e3e02  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e3e0b  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e3e14  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e3e1d  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e3e26  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e3e2f  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e3e38  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e3e41  add rsp, 0xF0
00007a3fbe1e3e48  pop r11
00007a3fbe1e3e4a  pop r10
00007a3fbe1e3e4c  pop r9
00007a3fbe1e3e4e  pop r8
00007a3fbe1e3e50  pop rsi
00007a3fbe1e3e51  pop rdi
00007a3fbe1e3e52  pop rdx
00007a3fbe1e3e53  pop rcx
00007a3fbe1e3e54  pop rax
00007a3fbe1e3e55  add rsp, 0x08
00007a3fbe1e3e59  jmp 0x00007A3FBE1DF880
00007a3fbe1e3e5e  call 0x00007A3FBE0C33A0
00007a3fbe1e3e63  jmp 0x00007A3FBE1DF88A
00007a3fbe1e3e68  sub rsp, 0x08
00007a3fbe1e3e6c  push rax
00007a3fbe1e3e6d  push rcx
00007a3fbe1e3e6e  push rdx
00007a3fbe1e3e6f  push rdi
00007a3fbe1e3e70  push rsi
00007a3fbe1e3e71  push r8
00007a3fbe1e3e73  push r9
00007a3fbe1e3e75  push r10
00007a3fbe1e3e77  push r11
00007a3fbe1e3e79  sub rsp, 0xF0
00007a3fbe1e3e80  vmovaps [rsp], xmm0
00007a3fbe1e3e85  vmovaps [rsp+0x10], xmm1
00007a3fbe1e3e8b  vmovaps [rsp+0x20], xmm2
00007a3fbe1e3e91  vmovaps [rsp+0x30], xmm3
00007a3fbe1e3e97  vmovaps [rsp+0x40], xmm4
00007a3fbe1e3e9d  vmovaps [rsp+0x50], xmm5
00007a3fbe1e3ea3  vmovaps [rsp+0x60], xmm6
00007a3fbe1e3ea9  vmovaps [rsp+0x70], xmm7
00007a3fbe1e3eaf  vmovaps [rsp+0x80], xmm8
00007a3fbe1e3eb8  vmovaps [rsp+0x90], xmm9
00007a3fbe1e3ec1  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e3eca  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e3ed3  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e3edc  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e3ee5  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e3eee  sub rsp, 0x30
00007a3fbe1e3ef2  movaps [rsp], xmm10
00007a3fbe1e3ef7  movaps [rsp+0x10], xmm1
00007a3fbe1e3efc  movaps [rsp+0x20], xmm12
00007a3fbe1e3f02  lea rdi, [rsp]
00007a3fbe1e3f06  mov esi, 0x00
00007a3fbe1e3f0b  mov rax, 0x60D1084DB530
00007a3fbe1e3f15  call rax
00007a3fbe1e3f17  movaps xmm10, [rsp]
00007a3fbe1e3f1c  add rsp, 0x30
00007a3fbe1e3f20  vmovaps xmm0, [rsp]
00007a3fbe1e3f25  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e3f2b  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e3f31  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e3f37  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e3f3d  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e3f43  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e3f49  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e3f4f  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e3f58  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e3f61  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e3f6a  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e3f73  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e3f7c  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e3f85  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e3f8e  add rsp, 0xF0
00007a3fbe1e3f95  pop r11
00007a3fbe1e3f97  pop r10
00007a3fbe1e3f99  pop r9
00007a3fbe1e3f9b  pop r8
00007a3fbe1e3f9d  pop rsi
00007a3fbe1e3f9e  pop rdi
00007a3fbe1e3f9f  pop rdx
00007a3fbe1e3fa0  pop rcx
00007a3fbe1e3fa1  pop rax
00007a3fbe1e3fa2  add rsp, 0x08
00007a3fbe1e3fa6  jmp 0x00007A3FBE1DF8AD
00007a3fbe1e3fab  sub rsp, 0x08
00007a3fbe1e3faf  push rax
00007a3fbe1e3fb0  push rcx
00007a3fbe1e3fb1  push rdx
00007a3fbe1e3fb2  push rdi
00007a3fbe1e3fb3  push rsi
00007a3fbe1e3fb4  push r8
00007a3fbe1e3fb6  push r9
00007a3fbe1e3fb8  push r10
00007a3fbe1e3fba  push r11
00007a3fbe1e3fbc  sub rsp, 0xF0
00007a3fbe1e3fc3  vmovaps [rsp], xmm0
00007a3fbe1e3fc8  vmovaps [rsp+0x10], xmm1
00007a3fbe1e3fce  vmovaps [rsp+0x20], xmm2
00007a3fbe1e3fd4  vmovaps [rsp+0x30], xmm3
00007a3fbe1e3fda  vmovaps [rsp+0x40], xmm4
00007a3fbe1e3fe0  vmovaps [rsp+0x50], xmm5
00007a3fbe1e3fe6  vmovaps [rsp+0x60], xmm6
00007a3fbe1e3fec  vmovaps [rsp+0x70], xmm7
00007a3fbe1e3ff2  vmovaps [rsp+0x80], xmm8
00007a3fbe1e3ffb  vmovaps [rsp+0x90], xmm9
00007a3fbe1e4004  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e400d  vmovaps [rsp+0xB0], xmm11
00007a3fbe1e4016  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e401f  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e4028  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e4031  sub rsp, 0x30
00007a3fbe1e4035  movaps [rsp], xmm12
00007a3fbe1e403a  movaps [rsp+0x10], xmm14
00007a3fbe1e4040  movaps [rsp+0x20], xmm1
00007a3fbe1e4045  lea rdi, [rsp]
00007a3fbe1e4049  mov esi, 0x00
00007a3fbe1e404e  mov rax, 0x60D1084DB530
00007a3fbe1e4058  call rax
00007a3fbe1e405a  movaps xmm12, [rsp]
00007a3fbe1e405f  add rsp, 0x30
00007a3fbe1e4063  vmovaps xmm0, [rsp]
00007a3fbe1e4068  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e406e  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e4074  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e407a  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e4080  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e4086  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e408c  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e4092  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e409b  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e40a4  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e40ad  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1e40b6  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e40bf  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e40c8  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e40d1  add rsp, 0xF0
00007a3fbe1e40d8  pop r11
00007a3fbe1e40da  pop r10
00007a3fbe1e40dc  pop r9
00007a3fbe1e40de  pop r8
00007a3fbe1e40e0  pop rsi
00007a3fbe1e40e1  pop rdi
00007a3fbe1e40e2  pop rdx
00007a3fbe1e40e3  pop rcx
00007a3fbe1e40e4  pop rax
00007a3fbe1e40e5  add rsp, 0x08
00007a3fbe1e40e9  jmp 0x00007A3FBE1DF8DC
00007a3fbe1e40ee  sub rsp, 0x08
00007a3fbe1e40f2  push rax
00007a3fbe1e40f3  push rcx
00007a3fbe1e40f4  push rdx
00007a3fbe1e40f5  push rdi
00007a3fbe1e40f6  push rsi
00007a3fbe1e40f7  push r8
00007a3fbe1e40f9  push r9
00007a3fbe1e40fb  push r10
00007a3fbe1e40fd  push r11
00007a3fbe1e40ff  sub rsp, 0xF0
00007a3fbe1e4106  vmovaps [rsp], xmm0
00007a3fbe1e410b  vmovaps [rsp+0x10], xmm1
00007a3fbe1e4111  vmovaps [rsp+0x20], xmm2
00007a3fbe1e4117  vmovaps [rsp+0x30], xmm3
00007a3fbe1e411d  vmovaps [rsp+0x40], xmm4
00007a3fbe1e4123  vmovaps [rsp+0x50], xmm5
00007a3fbe1e4129  vmovaps [rsp+0x60], xmm6
00007a3fbe1e412f  vmovaps [rsp+0x70], xmm7
00007a3fbe1e4135  vmovaps [rsp+0x80], xmm8
00007a3fbe1e413e  vmovaps [rsp+0x90], xmm9
00007a3fbe1e4147  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e4150  vmovaps [rsp+0xB0], xmm11
00007a3fbe1e4159  vmovaps [rsp+0xC0], xmm12
00007a3fbe1e4162  vmovaps [rsp+0xD0], xmm13
00007a3fbe1e416b  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e4174  sub rsp, 0x30
00007a3fbe1e4178  movaps [rsp], xmm14
00007a3fbe1e417d  movaps [rsp+0x10], xmm9
00007a3fbe1e4183  movaps [rsp+0x20], xmm1
00007a3fbe1e4188  lea rdi, [rsp]
00007a3fbe1e418c  mov esi, 0x00
00007a3fbe1e4191  mov rax, 0x60D1084DB530
00007a3fbe1e419b  call rax
00007a3fbe1e419d  movaps xmm14, [rsp]
00007a3fbe1e41a2  add rsp, 0x30
00007a3fbe1e41a6  vmovaps xmm0, [rsp]
00007a3fbe1e41ab  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e41b1  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e41b7  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e41bd  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e41c3  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e41c9  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e41cf  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e41d5  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e41de  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e41e7  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e41f0  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1e41f9  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1e4202  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1e420b  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e4214  add rsp, 0xF0
00007a3fbe1e421b  pop r11
00007a3fbe1e421d  pop r10
00007a3fbe1e421f  pop r9
00007a3fbe1e4221  pop r8
00007a3fbe1e4223  pop rsi
00007a3fbe1e4224  pop rdi
00007a3fbe1e4225  pop rdx
00007a3fbe1e4226  pop rcx
00007a3fbe1e4227  pop rax
00007a3fbe1e4228  add rsp, 0x08
00007a3fbe1e422c  jmp 0x00007A3FBE1DF90B
00007a3fbe1e4231  sub rsp, 0x08
00007a3fbe1e4235  push rax
00007a3fbe1e4236  push rcx
00007a3fbe1e4237  push rdx
00007a3fbe1e4238  push rdi
00007a3fbe1e4239  push rsi
00007a3fbe1e423a  push r8
00007a3fbe1e423c  push r9
00007a3fbe1e423e  push r10
00007a3fbe1e4240  push r11
00007a3fbe1e4242  sub rsp, 0xF0
00007a3fbe1e4249  vmovaps [rsp], xmm0
00007a3fbe1e424e  vmovaps [rsp+0x10], xmm2
00007a3fbe1e4254  vmovaps [rsp+0x20], xmm3
00007a3fbe1e425a  vmovaps [rsp+0x30], xmm4
00007a3fbe1e4260  vmovaps [rsp+0x40], xmm5
00007a3fbe1e4266  vmovaps [rsp+0x50], xmm6
00007a3fbe1e426c  vmovaps [rsp+0x60], xmm7
00007a3fbe1e4272  vmovaps [rsp+0x70], xmm8
00007a3fbe1e4278  vmovaps [rsp+0x80], xmm9
00007a3fbe1e4281  vmovaps [rsp+0x90], xmm10
00007a3fbe1e428a  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e4293  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e429c  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e42a5  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e42ae  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e42b7  sub rsp, 0x30
00007a3fbe1e42bb  movaps [rsp], xmm1
00007a3fbe1e42bf  movaps [rsp+0x10], xmm13
00007a3fbe1e42c5  movaps [rsp+0x20], xmm8
00007a3fbe1e42cb  lea rdi, [rsp]
00007a3fbe1e42cf  mov esi, 0x00
00007a3fbe1e42d4  mov rax, 0x60D1084DB530
00007a3fbe1e42de  call rax
00007a3fbe1e42e0  movaps xmm1, [rsp]
00007a3fbe1e42e4  add rsp, 0x30
00007a3fbe1e42e8  vmovaps xmm0, [rsp]
00007a3fbe1e42ed  vmovaps xmm2, [rsp+0x10]
00007a3fbe1e42f3  vmovaps xmm3, [rsp+0x20]
00007a3fbe1e42f9  vmovaps xmm4, [rsp+0x30]
00007a3fbe1e42ff  vmovaps xmm5, [rsp+0x40]
00007a3fbe1e4305  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e430b  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e4311  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e4317  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e4320  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e4329  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e4332  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e433b  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e4344  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e434d  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e4356  add rsp, 0xF0
00007a3fbe1e435d  pop r11
00007a3fbe1e435f  pop r10
00007a3fbe1e4361  pop r9
00007a3fbe1e4363  pop r8
00007a3fbe1e4365  pop rsi
00007a3fbe1e4366  pop rdi
00007a3fbe1e4367  pop rdx
00007a3fbe1e4368  pop rcx
00007a3fbe1e4369  pop rax
00007a3fbe1e436a  add rsp, 0x08
00007a3fbe1e436e  jmp 0x00007A3FBE1DF92D
00007a3fbe1e4373  call 0x00007A3FBE00C260
00007a3fbe1e4378  jmp 0x00007A3FBE1DF93B
00007a3fbe1e437d  call 0x00007A3FBE0BD750
00007a3fbe1e4382  jmp 0x00007A3FBE1DF945
00007a3fbe1e4387  sub rsp, 0x08
00007a3fbe1e438b  push rax
00007a3fbe1e438c  push rcx
00007a3fbe1e438d  push rdx
00007a3fbe1e438e  push rdi
00007a3fbe1e438f  push rsi
00007a3fbe1e4390  push r8
00007a3fbe1e4392  push r9
00007a3fbe1e4394  push r10
00007a3fbe1e4396  push r11
00007a3fbe1e4398  sub rsp, 0xF0
00007a3fbe1e439f  vmovaps [rsp], xmm0
00007a3fbe1e43a4  vmovaps [rsp+0x10], xmm1
00007a3fbe1e43aa  vmovaps [rsp+0x20], xmm2
00007a3fbe1e43b0  vmovaps [rsp+0x30], xmm3
00007a3fbe1e43b6  vmovaps [rsp+0x40], xmm4
00007a3fbe1e43bc  vmovaps [rsp+0x50], xmm5
00007a3fbe1e43c2  vmovaps [rsp+0x60], xmm6
00007a3fbe1e43c8  vmovaps [rsp+0x70], xmm7
00007a3fbe1e43ce  vmovaps [rsp+0x80], xmm9
00007a3fbe1e43d7  vmovaps [rsp+0x90], xmm10
00007a3fbe1e43e0  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e43e9  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e43f2  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e43fb  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e4404  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e440d  sub rsp, 0x30
00007a3fbe1e4411  movaps [rsp], xmm8
00007a3fbe1e4416  movaps [rsp+0x10], xmm15
00007a3fbe1e441c  movaps [rsp+0x20], xmm7
00007a3fbe1e4421  lea rdi, [rsp]
00007a3fbe1e4425  mov esi, 0x00
00007a3fbe1e442a  mov rax, 0x60D1084DB530
00007a3fbe1e4434  call rax
00007a3fbe1e4436  movaps xmm8, [rsp]
00007a3fbe1e443b  add rsp, 0x30
00007a3fbe1e443f  vmovaps xmm0, [rsp]
00007a3fbe1e4444  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e444a  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e4450  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e4456  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e445c  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e4462  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e4468  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e446e  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e4477  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e4480  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e4489  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e4492  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e449b  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e44a4  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e44ad  add rsp, 0xF0
00007a3fbe1e44b4  pop r11
00007a3fbe1e44b6  pop r10
00007a3fbe1e44b8  pop r9
00007a3fbe1e44ba  pop r8
00007a3fbe1e44bc  pop rsi
00007a3fbe1e44bd  pop rdi
00007a3fbe1e44be  pop rdx
00007a3fbe1e44bf  pop rcx
00007a3fbe1e44c0  pop rax
00007a3fbe1e44c1  add rsp, 0x08
00007a3fbe1e44c5  jmp 0x00007A3FBE1DF967
00007a3fbe1e44ca  sub rsp, 0x08
00007a3fbe1e44ce  push rax
00007a3fbe1e44cf  push rcx
00007a3fbe1e44d0  push rdx
00007a3fbe1e44d1  push rdi
00007a3fbe1e44d2  push rsi
00007a3fbe1e44d3  push r8
00007a3fbe1e44d5  push r9
00007a3fbe1e44d7  push r10
00007a3fbe1e44d9  push r11
00007a3fbe1e44db  sub rsp, 0xF0
00007a3fbe1e44e2  vmovaps [rsp], xmm0
00007a3fbe1e44e7  vmovaps [rsp+0x10], xmm1
00007a3fbe1e44ed  vmovaps [rsp+0x20], xmm2
00007a3fbe1e44f3  vmovaps [rsp+0x30], xmm3
00007a3fbe1e44f9  vmovaps [rsp+0x40], xmm4
00007a3fbe1e44ff  vmovaps [rsp+0x50], xmm5
00007a3fbe1e4505  vmovaps [rsp+0x60], xmm6
00007a3fbe1e450b  vmovaps [rsp+0x70], xmm8
00007a3fbe1e4511  vmovaps [rsp+0x80], xmm9
00007a3fbe1e451a  vmovaps [rsp+0x90], xmm10
00007a3fbe1e4523  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e452c  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e4535  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e453e  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e4547  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e4550  sub rsp, 0x30
00007a3fbe1e4554  movaps [rsp], xmm7
00007a3fbe1e4558  movaps [rsp+0x10], xmm9
00007a3fbe1e455e  movaps [rsp+0x20], xmm15
00007a3fbe1e4564  lea rdi, [rsp]
00007a3fbe1e4568  mov esi, 0x00
00007a3fbe1e456d  mov rax, 0x60D1084DB530
00007a3fbe1e4577  call rax
00007a3fbe1e4579  movaps xmm7, [rsp]
00007a3fbe1e457d  add rsp, 0x30
00007a3fbe1e4581  vmovaps xmm0, [rsp]
00007a3fbe1e4586  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e458c  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e4592  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e4598  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e459e  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e45a4  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e45aa  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e45b0  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e45b9  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e45c2  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e45cb  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e45d4  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e45dd  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e45e6  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e45ef  add rsp, 0xF0
00007a3fbe1e45f6  pop r11
00007a3fbe1e45f8  pop r10
00007a3fbe1e45fa  pop r9
00007a3fbe1e45fc  pop r8
00007a3fbe1e45fe  pop rsi
00007a3fbe1e45ff  pop rdi
00007a3fbe1e4600  pop rdx
00007a3fbe1e4601  pop rcx
00007a3fbe1e4602  pop rax
00007a3fbe1e4603  add rsp, 0x08
00007a3fbe1e4607  jmp 0x00007A3FBE1DF994
00007a3fbe1e460c  sub rsp, 0x08
00007a3fbe1e4610  push rax
00007a3fbe1e4611  push rcx
00007a3fbe1e4612  push rdx
00007a3fbe1e4613  push rdi
00007a3fbe1e4614  push rsi
00007a3fbe1e4615  push r8
00007a3fbe1e4617  push r9
00007a3fbe1e4619  push r10
00007a3fbe1e461b  push r11
00007a3fbe1e461d  sub rsp, 0xF0
00007a3fbe1e4624  vmovaps [rsp], xmm0
00007a3fbe1e4629  vmovaps [rsp+0x10], xmm1
00007a3fbe1e462f  vmovaps [rsp+0x20], xmm2
00007a3fbe1e4635  vmovaps [rsp+0x30], xmm3
00007a3fbe1e463b  vmovaps [rsp+0x40], xmm4
00007a3fbe1e4641  vmovaps [rsp+0x50], xmm5
00007a3fbe1e4647  vmovaps [rsp+0x60], xmm6
00007a3fbe1e464d  vmovaps [rsp+0x70], xmm7
00007a3fbe1e4653  vmovaps [rsp+0x80], xmm8
00007a3fbe1e465c  vmovaps [rsp+0x90], xmm10
00007a3fbe1e4665  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e466e  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e4677  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e4680  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e4689  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e4692  sub rsp, 0x30
00007a3fbe1e4696  movaps [rsp], xmm9
00007a3fbe1e469b  movaps [rsp+0x10], xmm13
00007a3fbe1e46a1  movaps [rsp+0x20], xmm15
00007a3fbe1e46a7  lea rdi, [rsp]
00007a3fbe1e46ab  mov esi, 0x00
00007a3fbe1e46b0  mov rax, 0x60D1084DB530
00007a3fbe1e46ba  call rax
00007a3fbe1e46bc  movaps xmm9, [rsp]
00007a3fbe1e46c1  add rsp, 0x30
00007a3fbe1e46c5  vmovaps xmm0, [rsp]
00007a3fbe1e46ca  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e46d0  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e46d6  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e46dc  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e46e2  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e46e8  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e46ee  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e46f4  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e46fd  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e4706  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e470f  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e4718  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e4721  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e472a  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e4733  add rsp, 0xF0
00007a3fbe1e473a  pop r11
00007a3fbe1e473c  pop r10
00007a3fbe1e473e  pop r9
00007a3fbe1e4740  pop r8
00007a3fbe1e4742  pop rsi
00007a3fbe1e4743  pop rdi
00007a3fbe1e4744  pop rdx
00007a3fbe1e4745  pop rcx
00007a3fbe1e4746  pop rax
00007a3fbe1e4747  add rsp, 0x08
00007a3fbe1e474b  jmp 0x00007A3FBE1DF9C2
00007a3fbe1e4750  sub rsp, 0x08
00007a3fbe1e4754  push rax
00007a3fbe1e4755  push rcx
00007a3fbe1e4756  push rdx
00007a3fbe1e4757  push rdi
00007a3fbe1e4758  push rsi
00007a3fbe1e4759  push r8
00007a3fbe1e475b  push r9
00007a3fbe1e475d  push r10
00007a3fbe1e475f  push r11
00007a3fbe1e4761  sub rsp, 0xF0
00007a3fbe1e4768  vmovaps [rsp], xmm0
00007a3fbe1e476d  vmovaps [rsp+0x10], xmm1
00007a3fbe1e4773  vmovaps [rsp+0x20], xmm2
00007a3fbe1e4779  vmovaps [rsp+0x30], xmm3
00007a3fbe1e477f  vmovaps [rsp+0x40], xmm4
00007a3fbe1e4785  vmovaps [rsp+0x50], xmm5
00007a3fbe1e478b  vmovaps [rsp+0x60], xmm6
00007a3fbe1e4791  vmovaps [rsp+0x70], xmm7
00007a3fbe1e4797  vmovaps [rsp+0x80], xmm8
00007a3fbe1e47a0  vmovaps [rsp+0x90], xmm9
00007a3fbe1e47a9  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e47b2  vmovaps [rsp+0xB0], xmm11
00007a3fbe1e47bb  vmovaps [rsp+0xC0], xmm12
00007a3fbe1e47c4  vmovaps [rsp+0xD0], xmm13
00007a3fbe1e47cd  vmovaps [rsp+0xE0], xmm14
00007a3fbe1e47d6  sub rsp, 0x30
00007a3fbe1e47da  movaps [rsp], xmm15
00007a3fbe1e47df  movaps [rsp+0x10], xmm11
00007a3fbe1e47e5  movaps [rsp+0x20], xmm12
00007a3fbe1e47eb  lea rdi, [rsp]
00007a3fbe1e47ef  mov esi, 0x00
00007a3fbe1e47f4  mov rax, 0x60D1084DB530
00007a3fbe1e47fe  call rax
00007a3fbe1e4800  movaps xmm15, [rsp]
00007a3fbe1e4805  add rsp, 0x30
00007a3fbe1e4809  vmovaps xmm0, [rsp]
00007a3fbe1e480e  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e4814  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e481a  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e4820  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e4826  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e482c  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e4832  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e4838  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e4841  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e484a  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e4853  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1e485c  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1e4865  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1e486e  vmovaps xmm14, [rsp+0xE0]
00007a3fbe1e4877  add rsp, 0xF0
00007a3fbe1e487e  pop r11
00007a3fbe1e4880  pop r10
00007a3fbe1e4882  pop r9
00007a3fbe1e4884  pop r8
00007a3fbe1e4886  pop rsi
00007a3fbe1e4887  pop rdi
00007a3fbe1e4888  pop rdx
00007a3fbe1e4889  pop rcx
00007a3fbe1e488a  pop rax
00007a3fbe1e488b  add rsp, 0x08
00007a3fbe1e488f  jmp 0x00007A3FBE1DF9DD
00007a3fbe1e4894  sub rsp, 0x08
00007a3fbe1e4898  push rax
00007a3fbe1e4899  push rcx
00007a3fbe1e489a  push rdx
00007a3fbe1e489b  push rdi
00007a3fbe1e489c  push rsi
00007a3fbe1e489d  push r8
00007a3fbe1e489f  push r9
00007a3fbe1e48a1  push r10
00007a3fbe1e48a3  push r11
00007a3fbe1e48a5  sub rsp, 0xF0
00007a3fbe1e48ac  vmovaps [rsp], xmm0
00007a3fbe1e48b1  vmovaps [rsp+0x10], xmm1
00007a3fbe1e48b7  vmovaps [rsp+0x20], xmm2
00007a3fbe1e48bd  vmovaps [rsp+0x30], xmm3
00007a3fbe1e48c3  vmovaps [rsp+0x40], xmm4
00007a3fbe1e48c9  vmovaps [rsp+0x50], xmm5
00007a3fbe1e48cf  vmovaps [rsp+0x60], xmm6
00007a3fbe1e48d5  vmovaps [rsp+0x70], xmm7
00007a3fbe1e48db  vmovaps [rsp+0x80], xmm8
00007a3fbe1e48e4  vmovaps [rsp+0x90], xmm9
00007a3fbe1e48ed  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e48f6  vmovaps [rsp+0xB0], xmm11
00007a3fbe1e48ff  vmovaps [rsp+0xC0], xmm12
00007a3fbe1e4908  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e4911  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e491a  sub rsp, 0x30
00007a3fbe1e491e  movaps [rsp], xmm13
00007a3fbe1e4923  movaps [rsp+0x10], xmm10
00007a3fbe1e4929  movaps [rsp+0x20], xmm14
00007a3fbe1e492f  lea rdi, [rsp]
00007a3fbe1e4933  mov esi, 0x00
00007a3fbe1e4938  mov rax, 0x60D1084DB530
00007a3fbe1e4942  call rax
00007a3fbe1e4944  movaps xmm13, [rsp]
00007a3fbe1e4949  add rsp, 0x30
00007a3fbe1e494d  vmovaps xmm0, [rsp]
00007a3fbe1e4952  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e4958  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e495e  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e4964  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e496a  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e4970  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e4976  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e497c  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e4985  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e498e  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e4997  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1e49a0  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1e49a9  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e49b2  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e49bb  add rsp, 0xF0
00007a3fbe1e49c2  pop r11
00007a3fbe1e49c4  pop r10
00007a3fbe1e49c6  pop r9
00007a3fbe1e49c8  pop r8
00007a3fbe1e49ca  pop rsi
00007a3fbe1e49cb  pop rdi
00007a3fbe1e49cc  pop rdx
00007a3fbe1e49cd  pop rcx
00007a3fbe1e49ce  pop rax
00007a3fbe1e49cf  add rsp, 0x08
00007a3fbe1e49d3  jmp 0x00007A3FBE1DFA00
00007a3fbe1e49d8  sub rsp, 0x08
00007a3fbe1e49dc  push rax
00007a3fbe1e49dd  push rcx
00007a3fbe1e49de  push rdx
00007a3fbe1e49df  push rdi
00007a3fbe1e49e0  push rsi
00007a3fbe1e49e1  push r8
00007a3fbe1e49e3  push r9
00007a3fbe1e49e5  push r10
00007a3fbe1e49e7  push r11
00007a3fbe1e49e9  sub rsp, 0xF0
00007a3fbe1e49f0  vmovaps [rsp], xmm0
00007a3fbe1e49f5  vmovaps [rsp+0x10], xmm1
00007a3fbe1e49fb  vmovaps [rsp+0x20], xmm2
00007a3fbe1e4a01  vmovaps [rsp+0x30], xmm3
00007a3fbe1e4a07  vmovaps [rsp+0x40], xmm4
00007a3fbe1e4a0d  vmovaps [rsp+0x50], xmm5
00007a3fbe1e4a13  vmovaps [rsp+0x60], xmm6
00007a3fbe1e4a19  vmovaps [rsp+0x70], xmm7
00007a3fbe1e4a1f  vmovaps [rsp+0x80], xmm8
00007a3fbe1e4a28  vmovaps [rsp+0x90], xmm9
00007a3fbe1e4a31  vmovaps [rsp+0xA0], xmm10
00007a3fbe1e4a3a  vmovaps [rsp+0xB0], xmm11
00007a3fbe1e4a43  vmovaps [rsp+0xC0], xmm12
00007a3fbe1e4a4c  vmovaps [rsp+0xD0], xmm13
00007a3fbe1e4a55  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e4a5e  sub rsp, 0x30
00007a3fbe1e4a62  movaps [rsp], xmm14
00007a3fbe1e4a67  movaps [rsp+0x10], xmm1
00007a3fbe1e4a6c  movaps [rsp+0x20], xmm7
00007a3fbe1e4a71  lea rdi, [rsp]
00007a3fbe1e4a75  mov esi, 0x00
00007a3fbe1e4a7a  mov rax, 0x60D1084DB530
00007a3fbe1e4a84  call rax
00007a3fbe1e4a86  movaps xmm14, [rsp]
00007a3fbe1e4a8b  add rsp, 0x30
00007a3fbe1e4a8f  vmovaps xmm0, [rsp]
00007a3fbe1e4a94  vmovaps xmm1, [rsp+0x10]
00007a3fbe1e4a9a  vmovaps xmm2, [rsp+0x20]
00007a3fbe1e4aa0  vmovaps xmm3, [rsp+0x30]
00007a3fbe1e4aa6  vmovaps xmm4, [rsp+0x40]
00007a3fbe1e4aac  vmovaps xmm5, [rsp+0x50]
00007a3fbe1e4ab2  vmovaps xmm6, [rsp+0x60]
00007a3fbe1e4ab8  vmovaps xmm7, [rsp+0x70]
00007a3fbe1e4abe  vmovaps xmm8, [rsp+0x80]
00007a3fbe1e4ac7  vmovaps xmm9, [rsp+0x90]
00007a3fbe1e4ad0  vmovaps xmm10, [rsp+0xA0]
00007a3fbe1e4ad9  vmovaps xmm11, [rsp+0xB0]
00007a3fbe1e4ae2  vmovaps xmm12, [rsp+0xC0]
00007a3fbe1e4aeb  vmovaps xmm13, [rsp+0xD0]
00007a3fbe1e4af4  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e4afd  add rsp, 0xF0
00007a3fbe1e4b04  pop r11
00007a3fbe1e4b06  pop r10
00007a3fbe1e4b08  pop r9
00007a3fbe1e4b0a  pop r8
00007a3fbe1e4b0c  pop rsi
00007a3fbe1e4b0d  pop rdi
00007a3fbe1e4b0e  pop rdx
00007a3fbe1e4b0f  pop rcx
00007a3fbe1e4b10  pop rax
00007a3fbe1e4b11  add rsp, 0x08
00007a3fbe1e4b15  jmp 0x00007A3FBE1DFA23
00007a3fbe1e4b1a  sub rsp, 0x08
00007a3fbe1e4b1e  push rax
00007a3fbe1e4b1f  push rcx
00007a3fbe1e4b20  push rdx
00007a3fbe1e4b21  push rdi
00007a3fbe1e4b22  push rsi
00007a3fbe1e4b23  push r8
00007a3fbe1e4b25  push r9
00007a3fbe1e4b27  push r10
00007a3fbe1e4b29  push r11
00007a3fbe1e4b2b  sub rsp, 0xF0
00007a3fbe1e4b32  vmovaps [rsp], xmm0
00007a3fbe1e4b37  vmovaps [rsp+0x10], xmm2
00007a3fbe1e4b3d  vmovaps [rsp+0x20], xmm3
00007a3fbe1e4b43  vmovaps [rsp+0x30], xmm4
00007a3fbe1e4b49  vmovaps [rsp+0x40], xmm5
00007a3fbe1e4b4f  vmovaps [rsp+0x50], xmm6
00007a3fbe1e4b55  vmovaps [rsp+0x60], xmm7
00007a3fbe1e4b5b  vmovaps [rsp+0x70], xmm8
00007a3fbe1e4b61  vmovaps [rsp+0x80], xmm9
00007a3fbe1e4b6a  vmovaps [rsp+0x90], xmm10
00007a3fbe1e4b73  vmovaps [rsp+0xA0], xmm11
00007a3fbe1e4b7c  vmovaps [rsp+0xB0], xmm12
00007a3fbe1e4b85  vmovaps [rsp+0xC0], xmm13
00007a3fbe1e4b8e  vmovaps [rsp+0xD0], xmm14
00007a3fbe1e4b97  vmovaps [rsp+0xE0], xmm15
00007a3fbe1e4ba0  sub rsp, 0x30
00007a3fbe1e4ba4  movaps [rsp], xmm1
00007a3fbe1e4ba8  movaps [rsp+0x10], xmm8
00007a3fbe1e4bae  movaps [rsp+0x20], xmm9
00007a3fbe1e4bb4  lea rdi, [rsp]
00007a3fbe1e4bb8  mov esi, 0x00
00007a3fbe1e4bbd  mov rax, 0x60D1084DB530
00007a3fbe1e4bc7  call rax
00007a3fbe1e4bc9  movaps xmm1, [rsp]
00007a3fbe1e4bcd  add rsp, 0x30
00007a3fbe1e4bd1  vmovaps xmm0, [rsp]
00007a3fbe1e4bd6  vmovaps xmm2, [rsp+0x10]
00007a3fbe1e4bdc  vmovaps xmm3, [rsp+0x20]
00007a3fbe1e4be2  vmovaps xmm4, [rsp+0x30]
00007a3fbe1e4be8  vmovaps xmm5, [rsp+0x40]
00007a3fbe1e4bee  vmovaps xmm6, [rsp+0x50]
00007a3fbe1e4bf4  vmovaps xmm7, [rsp+0x60]
00007a3fbe1e4bfa  vmovaps xmm8, [rsp+0x70]
00007a3fbe1e4c00  vmovaps xmm9, [rsp+0x80]
00007a3fbe1e4c09  vmovaps xmm10, [rsp+0x90]
00007a3fbe1e4c12  vmovaps xmm11, [rsp+0xA0]
00007a3fbe1e4c1b  vmovaps xmm12, [rsp+0xB0]
00007a3fbe1e4c24  vmovaps xmm13, [rsp+0xC0]
00007a3fbe1e4c2d  vmovaps xmm14, [rsp+0xD0]
00007a3fbe1e4c36  vmovaps xmm15, [rsp+0xE0]
00007a3fbe1e4c3f  add rsp, 0xF0
00007a3fbe1e4c46  pop r11
00007a3fbe1e4c48  pop r10
00007a3fbe1e4c4a  pop r9
00007a3fbe1e4c4c  pop r8
00007a3fbe1e4c4e  pop rsi
00007a3fbe1e4c4f  pop rdi
00007a3fbe1e4c50  pop rdx
00007a3fbe1e4c51  pop rcx
00007a3fbe1e4c52  pop rax
00007a3fbe1e4c53  add rsp, 0x08
00007a3fbe1e4c57  jmp 0x00007A3FBE1DFA45
00007a3fbe1e4c5c  call 0x00007A3FBE0E5940
00007a3fbe1e4c61  jmp 0x00007A3FBE1DFA53
00007a3fbe1e4c66  call 0x00007A3FBE00C380
00007a3fbe1e4c6b  jmp 0x00007A3FBE1DFA5D
00007a3fbe1e4c70  call 0x00007A3FBE00D600
00007a3fbe1e4c75  jmp 0x00007A3FBE1DFA67
00007a3fbe1e4c7a  call 0x00007A3FBDFFF540
00007a3fbe1e4c7f  jmp 0x00007A3FBE1DFA71
00007a3fbe1e4c84  int3
00007a3fbe1e4c85  nop [rax+rax*1], ax
00007a3fbe1e4c8e  nop
00007a3fbe1e4c90  mov qword ptr [r15+0x40], 0x430000
00007a3fbe1e4c98  mov eax, 0x430CC0
00007a3fbe1e4c9d  mov r14, [r13+rax*1]
00007a3fbe1e4ca2  movq xmm1, r14
00007a3fbe1e4ca7  mov rax, [r15+0x50]
00007a3fbe1e4cab  movups xmm15, [r13+rax*1]
00007a3fbe1e4cb1  movaps [r15+0x120], xmm15
00007a3fbe1e4cb9  mov qword ptr [r15+0x48], 0x10
00007a3fbe1e4cc1  xor eax, eax
00007a3fbe1e4cc3  mov r14d, 0x10
00007a3fbe1e4cc9  mov r12d, 0x200
00007a3fbe1e4ccf  cmp r14, r12
00007a3fbe1e4cd2  cmc
00007a3fbe1e4cd3  lahf
00007a3fbe1e4cd4  seto al
00007a3fbe1e4cd7  mov [r15+0x108], eax
00007a3fbe1e4cde  pextrq rax, xmm15, 0x01
00007a3fbe1e4ce5  movq xmm14, rax
00007a3fbe1e4cea  movaps [r15+0x130], xmm14
00007a3fbe1e4cf2  movq rax, xmm1
00007a3fbe1e4cf7  movq r14, xmm15
00007a3fbe1e4cfc  vmovq xmm1, rax
00007a3fbe1e4d01  vmovq xmm15, r14
00007a3fbe1e4d06  movaps xmm13, xmm1
00007a3fbe1e4d0a  addsd xmm13, xmm15
00007a3fbe1e4d0f  ucomisd xmm13, xmm13
00007a3fbe1e4d14  jp 0x00007A3FBE1E4DD3
00007a3fbe1e4d1a  movq xmm13, xmm13
00007a3fbe1e4d1f  movq rax, xmm13
00007a3fbe1e4d24  movq r14, xmm14
00007a3fbe1e4d29  vmovq xmm1, rax
00007a3fbe1e4d2e  vmovq xmm15, r14
00007a3fbe1e4d33  movaps xmm14, xmm1
00007a3fbe1e4d37  addsd xmm14, xmm15
00007a3fbe1e4d3c  ucomisd xmm14, xmm14
00007a3fbe1e4d41  jp 0x00007A3FBE1E4E1B
00007a3fbe1e4d47  movq xmm14, xmm14
00007a3fbe1e4d4c  movaps [r15+0x110], xmm14
00007a3fbe1e4d54  mov eax, [r15+0x108]
00007a3fbe1e4d5b  sahf
00007a3fbe1e4d5c  jnz 0x00007A3FBE1E4D8E
00007a3fbe1e4d5e  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1e4d66  jz 0x00007A3FBE1E5030
00007a3fbe1e4d6c  nop [rax+rax*1], ax
00007a3fbe1e4d75  nop [rax+rax*1], eax
00007a3fbe1e4d7d  mov eax, 0x410704
00007a3fbe1e4d82  mov [r15+0x100], rax
00007a3fbe1e4d89  jmp 0x00007A3FBDFFE110
00007a3fbe1e4d8e  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1e4d96  jz 0x00007A3FBE1E4E70
00007a3fbe1e4d9c  nop [rax+rax*1], ax
00007a3fbe1e4da5  nop [rax+rax*1], eax
00007a3fbe1e4dad  mov eax, 0x4106E8
00007a3fbe1e4db2  mov [r15+0x100], rax
00007a3fbe1e4db9  jmp 0x00007A3FBDFFE110
00007a3fbe1e4dbe  int3
00007a3fbe1e4dbf  call 0x00007A3FBE00DC20
00007a3fbe1e4dc4  jmp 0x00007A3FBE1E4CA2
00007a3fbe1e4dc9  call 0x00007A3FBE00E760
00007a3fbe1e4dce  jmp 0x00007A3FBE1E4CB1
00007a3fbe1e4dd3  ucomisd xmm1, xmm15
00007a3fbe1e4dd8  jp 0x00007A3FBE1E4DE7
00007a3fbe1e4dda  movaps xmm13, [0x00007A3FBDDFE060]
00007a3fbe1e4de2  jmp 0x00007A3FBE1E4D1A
00007a3fbe1e4de7  vxorps xmm0, xmm1, xmm15
00007a3fbe1e4dec  pextrw eax, xmm0, 0x03
00007a3fbe1e4df1  and eax, 0x7FF8
00007a3fbe1e4df6  cmp eax, 0x08
00007a3fbe1e4df9  jnz 0x00007A3FBE1E4D1A
00007a3fbe1e4dff  movq rax, xmm15
00007a3fbe1e4e04  shl rax, 0x0D
00007a3fbe1e4e08  jbe 0x00007A3FBE1E4D1A
00007a3fbe1e4e0e  vorps xmm13, xmm15, [0x00007A3FBDDFE070]
00007a3fbe1e4e16  jmp 0x00007A3FBE1E4D1A
00007a3fbe1e4e1b  ucomisd xmm1, xmm15
00007a3fbe1e4e20  jp 0x00007A3FBE1E4E2F
00007a3fbe1e4e22  movaps xmm14, [0x00007A3FBDDFE060]
00007a3fbe1e4e2a  jmp 0x00007A3FBE1E4D47
00007a3fbe1e4e2f  vxorps xmm0, xmm1, xmm15
00007a3fbe1e4e34  pextrw eax, xmm0, 0x03
00007a3fbe1e4e39  and eax, 0x7FF8
00007a3fbe1e4e3e  cmp eax, 0x08
00007a3fbe1e4e41  jnz 0x00007A3FBE1E4D47
00007a3fbe1e4e47  movq rax, xmm15
00007a3fbe1e4e4c  shl rax, 0x0D
00007a3fbe1e4e50  jbe 0x00007A3FBE1E4D47
00007a3fbe1e4e56  vorps xmm14, xmm15, [0x00007A3FBDDFE070]
00007a3fbe1e4e5e  jmp 0x00007A3FBE1E4D47
00007a3fbe1e4e63  int3
00007a3fbe1e4e64  nop [rax+rax*1], ax
00007a3fbe1e4e6d  nop [rax], eax
00007a3fbe1e4e70  mov rax, [r15+0x48]
00007a3fbe1e4e74  mov r14, [r15+0x50]
00007a3fbe1e4e78  lea r12, [r14+rax*1]
00007a3fbe1e4e7c  movups xmm1, [r13+r12*1]
00007a3fbe1e4e82  movaps [r15+0x120], xmm1
00007a3fbe1e4e8a  lea r14, [rax+0x10]
00007a3fbe1e4e8e  mov [r15+0x48], r14
00007a3fbe1e4e92  xor eax, eax
00007a3fbe1e4e94  mov r12d, 0x200
00007a3fbe1e4e9a  cmp r14, r12
00007a3fbe1e4e9d  cmc
00007a3fbe1e4e9e  lahf
00007a3fbe1e4e9f  seto al
00007a3fbe1e4ea2  mov [r15+0x108], eax
00007a3fbe1e4ea9  pextrq rax, xmm1, 0x01
00007a3fbe1e4eb0  movq xmm15, rax
00007a3fbe1e4eb5  movaps [r15+0x130], xmm15
00007a3fbe1e4ebd  movaps xmm14, [r15+0x110]
00007a3fbe1e4ec5  movq rax, xmm14
00007a3fbe1e4eca  movq r14, xmm1
00007a3fbe1e4ecf  vmovq xmm1, rax
00007a3fbe1e4ed4  vmovq xmm14, r14
00007a3fbe1e4ed9  movaps xmm13, xmm1
00007a3fbe1e4edd  addsd xmm13, xmm14
00007a3fbe1e4ee2  ucomisd xmm13, xmm13
00007a3fbe1e4ee7  jp 0x00007A3FBE1E4F9C
00007a3fbe1e4eed  movq xmm13, xmm13
00007a3fbe1e4ef2  movq rax, xmm13
00007a3fbe1e4ef7  movq r14, xmm15
00007a3fbe1e4efc  vmovq xmm1, rax
00007a3fbe1e4f01  vmovq xmm15, r14
00007a3fbe1e4f06  movaps xmm14, xmm1
00007a3fbe1e4f0a  addsd xmm14, xmm15
00007a3fbe1e4f0f  ucomisd xmm14, xmm14
00007a3fbe1e4f14  jp 0x00007A3FBE1E4FE4
00007a3fbe1e4f1a  movq xmm14, xmm14
00007a3fbe1e4f1f  movaps [r15+0x110], xmm14
00007a3fbe1e4f27  mov eax, [r15+0x108]
00007a3fbe1e4f2e  sahf
00007a3fbe1e4f2f  jnz 0x00007A3FBE1E4F61
00007a3fbe1e4f31  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1e4f39  jz 0x00007A3FBE1E5030
00007a3fbe1e4f3f  nop [rax+rax*1], ax
00007a3fbe1e4f48  nop [rax+rax*1], eax
00007a3fbe1e4f50  mov eax, 0x410704
00007a3fbe1e4f55  mov [r15+0x100], rax
00007a3fbe1e4f5c  jmp 0x00007A3FBDFFE110
00007a3fbe1e4f61  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1e4f69  jz 0x00007A3FBE1E4E70
00007a3fbe1e4f6f  nop [rax+rax*1], ax
00007a3fbe1e4f78  nop [rax+rax*1], eax
00007a3fbe1e4f80  mov eax, 0x4106E8
00007a3fbe1e4f85  mov [r15+0x100], rax
00007a3fbe1e4f8c  jmp 0x00007A3FBDFFE110
00007a3fbe1e4f91  int3
00007a3fbe1e4f92  call 0x00007A3FBE0B52F0
00007a3fbe1e4f97  jmp 0x00007A3FBE1E4E82
00007a3fbe1e4f9c  ucomisd xmm1, xmm14
00007a3fbe1e4fa1  jp 0x00007A3FBE1E4FB0
00007a3fbe1e4fa3  movaps xmm13, [0x00007A3FBDDFE060]
00007a3fbe1e4fab  jmp 0x00007A3FBE1E4EED
00007a3fbe1e4fb0  vxorps xmm0, xmm1, xmm14
00007a3fbe1e4fb5  pextrw eax, xmm0, 0x03
00007a3fbe1e4fba  and eax, 0x7FF8
00007a3fbe1e4fbf  cmp eax, 0x08
00007a3fbe1e4fc2  jnz 0x00007A3FBE1E4EED
00007a3fbe1e4fc8  movq rax, xmm14
00007a3fbe1e4fcd  shl rax, 0x0D
00007a3fbe1e4fd1  jbe 0x00007A3FBE1E4EED
00007a3fbe1e4fd7  vorps xmm13, xmm14, [0x00007A3FBDDFE070]
00007a3fbe1e4fdf  jmp 0x00007A3FBE1E4EED
00007a3fbe1e4fe4  ucomisd xmm1, xmm15
00007a3fbe1e4fe9  jp 0x00007A3FBE1E4FF8
00007a3fbe1e4feb  movaps xmm14, [0x00007A3FBDDFE060]
00007a3fbe1e4ff3  jmp 0x00007A3FBE1E4F1A
00007a3fbe1e4ff8  vxorps xmm0, xmm1, xmm15
00007a3fbe1e4ffd  pextrw eax, xmm0, 0x03
00007a3fbe1e5002  and eax, 0x7FF8
00007a3fbe1e5007  cmp eax, 0x08
00007a3fbe1e500a  jnz 0x00007A3FBE1E4F1A
00007a3fbe1e5010  movq rax, xmm15
00007a3fbe1e5015  shl rax, 0x0D
00007a3fbe1e5019  jbe 0x00007A3FBE1E4F1A
00007a3fbe1e501f  vorps xmm14, xmm15, [0x00007A3FBDDFE070]
00007a3fbe1e5027  jmp 0x00007A3FBE1E4F1A
00007a3fbe1e502c  int3
00007a3fbe1e502d  nop [rax], eax
00007a3fbe1e5030  mov rax, [r15+0xF8]
00007a3fbe1e5037  lea r14, [rax+0x1D0]
00007a3fbe1e503e  mov r12, [r13+r14*1]
00007a3fbe1e5043  lea r14, [rax+0x1D8]
00007a3fbe1e504a  mov r11, [r13+r14*1]
00007a3fbe1e504f  mov [r15+0xA0], r12
00007a3fbe1e5056  mov [r15+0x98], r11
00007a3fbe1e505d  mov r14, [r15+0x40]
00007a3fbe1e5061  lea r12, [r14+0xCC0]
00007a3fbe1e5068  movaps xmm1, [r15+0x110]
00007a3fbe1e5070  movq r14, xmm1
00007a3fbe1e5075  mov [r13+r12*1], r14
00007a3fbe1e507a  lea r14, [rax+0x1C0]
00007a3fbe1e5081  mov r12, [r13+r14*1]
00007a3fbe1e5086  lea r14, [rax+0x1C8]
00007a3fbe1e508d  mov r11, [r13+r14*1]
00007a3fbe1e5092  mov [r15+0xE8], r12
00007a3fbe1e5099  mov [r15+0xF0], r11
00007a3fbe1e50a0  lea r14, [rax+0x1B0]
00007a3fbe1e50a7  mov r12, [r13+r14*1]
00007a3fbe1e50ac  lea r14, [rax+0x1B8]
00007a3fbe1e50b3  mov r10, [r13+r14*1]
00007a3fbe1e50b8  movq xmm1, r12
00007a3fbe1e50bd  movq xmm15, r10
00007a3fbe1e50c2  movq xmm1, xmm1
00007a3fbe1e50c6  movq xmm1, xmm1
00007a3fbe1e50ca  movaps [r15+0x1A0], xmm1
00007a3fbe1e50d2  movq xmm15, xmm15
00007a3fbe1e50d7  movq xmm15, xmm15
00007a3fbe1e50dc  movaps [r15+0x190], xmm15
00007a3fbe1e50e4  lea r14, [rax+0x1A0]
00007a3fbe1e50eb  mov r12, [r13+r14*1]
00007a3fbe1e50f0  lea r14, [rax+0x1A8]
00007a3fbe1e50f7  mov r10, [r13+r14*1]
00007a3fbe1e50fc  movq xmm1, r12
00007a3fbe1e5101  movq xmm15, r10
00007a3fbe1e5106  movq xmm1, xmm1
00007a3fbe1e510a  movq xmm1, xmm1
00007a3fbe1e510e  movaps [r15+0x1C0], xmm1
00007a3fbe1e5116  movq xmm15, xmm15
00007a3fbe1e511b  movq xmm15, xmm15
00007a3fbe1e5120  movaps [r15+0x1B0], xmm15
00007a3fbe1e5128  lea r14, [rax+0x190]
00007a3fbe1e512f  mov r12, [r13+r14*1]
00007a3fbe1e5134  lea r14, [rax+0x198]
00007a3fbe1e513b  mov r10, [r13+r14*1]
00007a3fbe1e5140  movq xmm1, r12
00007a3fbe1e5145  movq xmm15, r10
00007a3fbe1e514a  movq xmm1, xmm1
00007a3fbe1e514e  movq xmm1, xmm1
00007a3fbe1e5152  movaps [r15+0x1E0], xmm1
00007a3fbe1e515a  movq xmm15, xmm15
00007a3fbe1e515f  movq xmm15, xmm15
00007a3fbe1e5164  movaps [r15+0x1D0], xmm15
00007a3fbe1e516c  lea r14, [rax+0x180]
00007a3fbe1e5173  mov r12, [r13+r14*1]
00007a3fbe1e5178  lea r14, [rax+0x188]
00007a3fbe1e517f  mov r10, [r13+r14*1]
00007a3fbe1e5184  movq xmm1, r12
00007a3fbe1e5189  movq xmm15, r10
00007a3fbe1e518e  movq xmm1, xmm1
00007a3fbe1e5192  movq xmm1, xmm1
00007a3fbe1e5196  movaps [r15+0x200], xmm1
00007a3fbe1e519e  movq xmm15, xmm15
00007a3fbe1e51a3  movq xmm15, xmm15
00007a3fbe1e51a8  movaps [r15+0x1F0], xmm15
00007a3fbe1e51b0  lea r14, [rax+0x1E0]
00007a3fbe1e51b7  mov [r15+0xF8], r14
00007a3fbe1e51be  mov [r15+0x100], r11
00007a3fbe1e51c5  jmp 0x00007A3FBE1CE5C0
00007a3fbe1e51ca  int3
00007a3fbe1e51cb  call 0x00007A3FBE0E27E0
00007a3fbe1e51d0  jmp 0x00007A3FBE1E5043
00007a3fbe1e51d5  call 0x00007A3FBE0E1570
00007a3fbe1e51da  jmp 0x00007A3FBE1E504F
00007a3fbe1e51df  call 0x00007A3FBE0C3FE0
00007a3fbe1e51e4  jmp 0x00007A3FBE1E507A
00007a3fbe1e51e9  call 0x00007A3FBE0E27E0
00007a3fbe1e51ee  jmp 0x00007A3FBE1E5086
00007a3fbe1e51f3  call 0x00007A3FBE0E1570
00007a3fbe1e51f8  jmp 0x00007A3FBE1E5092
00007a3fbe1e51fd  call 0x00007A3FBE0E27E0
00007a3fbe1e5202  jmp 0x00007A3FBE1E50AC
00007a3fbe1e5207  call 0x00007A3FBE0E0300
00007a3fbe1e520c  jmp 0x00007A3FBE1E50B8
00007a3fbe1e5211  call 0x00007A3FBE0E27E0
00007a3fbe1e5216  jmp 0x00007A3FBE1E50F0
00007a3fbe1e521b  call 0x00007A3FBE0E0300
00007a3fbe1e5220  jmp 0x00007A3FBE1E50FC
00007a3fbe1e5225  call 0x00007A3FBE0E27E0
00007a3fbe1e522a  jmp 0x00007A3FBE1E5134
00007a3fbe1e522f  call 0x00007A3FBE0E0300
00007a3fbe1e5234  jmp 0x00007A3FBE1E5140
00007a3fbe1e5239  call 0x00007A3FBE0E27E0
00007a3fbe1e523e  jmp 0x00007A3FBE1E5178
00007a3fbe1e5243  call 0x00007A3FBE0E0300
00007a3fbe1e5248  jmp 0x00007A3FBE1E5184
00007a3fbe1e524d  int3
00007a3fbe1e524e  nop
00007a3fbe1e5250  mov qword ptr [r15+0x100], 0x04
00007a3fbe1e525b  mov esi, 0x00
00007a3fbe1e5260  mov edx, 0x09
00007a3fbe1e5265  mov rdi, 0x7FFF10F21910
00007a3fbe1e526f  mov rax, 0x60D10836E970
00007a3fbe1e5279  call rax
00007a3fbe1e527b  cmp dword ptr [r15+0x318], 0x00
00007a3fbe1e5283  jnz 0x00007A3FBDFFE110
00007a3fbe1e5289  jmp 0x00007A3FBDFFE0A0
00007a3fbe1e528e  int3
00007a3fbe1e528f  int3
