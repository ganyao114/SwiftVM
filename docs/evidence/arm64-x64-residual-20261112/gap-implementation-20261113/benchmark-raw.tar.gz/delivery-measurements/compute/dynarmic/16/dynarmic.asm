0000714ce89ce69b  nop [rax+rax*1], eax
0000714ce89ce6a0  mov rax, [r15+0xF8]
0000714ce89ce6a7  lea r14, [rax-0x1E0]
0000714ce89ce6ae  mov [r15+0xF8], r14
0000714ce89ce6b5  lea rax, [r14+0x1D0]
0000714ce89ce6bc  mov r12, [r15+0xA0]
0000714ce89ce6c3  mov r11, [r15+0x98]
0000714ce89ce6ca  mov [r13+rax*1], r12
0000714ce89ce6cf  lea rax, [r14+0x1D8]
0000714ce89ce6d6  mov [r13+rax*1], r11
0000714ce89ce6db  mov eax, 0x420AA0
0000714ce89ce6e0  movups xmm1, [r13+rax*1]
0000714ce89ce6e6  mov eax, 0x420A30
0000714ce89ce6eb  movups xmm15, [r13+rax*1]
0000714ce89ce6f1  mov eax, 0x420AC0
0000714ce89ce6f6  movups xmm14, [r13+rax*1]
0000714ce89ce6fc  mov eax, 0x420A60
0000714ce89ce701  movups xmm13, [r13+rax*1]
0000714ce89ce707  mov qword ptr [r15+0x98], 0x430CD0
0000714ce89ce712  mov eax, 0x420AD0
0000714ce89ce717  movups xmm12, [r13+rax*1]
0000714ce89ce71d  mov eax, 0x430CD0
0000714ce89ce722  movups [r13+rax*1], xmm1
0000714ce89ce728  mov eax, 0x430CE0
0000714ce89ce72d  movups [r13+rax*1], xmm15
0000714ce89ce733  mov eax, 0x430CF0
0000714ce89ce738  movups [r13+rax*1], xmm14
0000714ce89ce73e  mov eax, 0x430D00
0000714ce89ce743  movups [r13+rax*1], xmm13
0000714ce89ce749  mov eax, 0x420A20
0000714ce89ce74e  movups xmm14, [r13+rax*1]
0000714ce89ce754  mov eax, 0x420A10
0000714ce89ce759  movups xmm13, [r13+rax*1]
0000714ce89ce75f  mov eax, 0x430DD0
0000714ce89ce764  movups [r13+rax*1], xmm1
0000714ce89ce76a  mov eax, 0x430DE0
0000714ce89ce76f  movups [r13+rax*1], xmm15
0000714ce89ce775  mov eax, 0x430D10
0000714ce89ce77a  movups [r13+rax*1], xmm12
0000714ce89ce780  mov eax, 0x430D20
0000714ce89ce785  movups [r13+rax*1], xmm14
0000714ce89ce78b  mov eax, 0x420A00
0000714ce89ce790  movups xmm1, [r13+rax*1]
0000714ce89ce796  mov eax, 0x420A70
0000714ce89ce79b  movups xmm15, [r13+rax*1]
0000714ce89ce7a1  mov eax, 0x430D30
0000714ce89ce7a6  movups [r13+rax*1], xmm13
0000714ce89ce7ac  mov eax, 0x430D40
0000714ce89ce7b1  movups [r13+rax*1], xmm1
0000714ce89ce7b7  mov eax, 0x420A80
0000714ce89ce7bc  movups xmm1, [r13+rax*1]
0000714ce89ce7c2  mov eax, 0x420A50
0000714ce89ce7c7  movups xmm14, [r13+rax*1]
0000714ce89ce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
0000714ce89ce7d5  mov eax, 0x430D50
0000714ce89ce7da  movups [r13+rax*1], xmm15
0000714ce89ce7e0  mov eax, 0x430D60
0000714ce89ce7e5  movups [r13+rax*1], xmm1
0000714ce89ce7eb  mov eax, 0x420AF0
0000714ce89ce7f0  movups xmm1, [r13+rax*1]
0000714ce89ce7f6  mov eax, 0x420B00
0000714ce89ce7fb  movups xmm15, [r13+rax*1]
0000714ce89ce801  movaps [r15+0x150], xmm15
0000714ce89ce809  mov qword ptr [r15+0xA0], 0x3E8
0000714ce89ce814  mov eax, 0x430D70
0000714ce89ce819  movups [r13+rax*1], xmm14
0000714ce89ce81f  mov eax, 0x430D80
0000714ce89ce824  movups [r13+rax*1], xmm1
0000714ce89ce82a  mov eax, 0x420AE0
0000714ce89ce82f  movups xmm1, [r13+rax*1]
0000714ce89ce835  mov eax, 0x420A90
0000714ce89ce83a  movups xmm14, [r13+rax*1]
0000714ce89ce840  movaps [r15+0x140], xmm14
0000714ce89ce848  lea rax, [r14+0x180]
0000714ce89ce84f  movq xmm13, qword ptr [r15+0x200]
0000714ce89ce858  movq xmm12, qword ptr [r15+0x1F0]
0000714ce89ce861  movq r12, xmm13
0000714ce89ce866  movq r11, xmm12
0000714ce89ce86b  mov [r13+rax*1], r12
0000714ce89ce870  lea rax, [r14+0x188]
0000714ce89ce877  mov [r13+rax*1], r11
0000714ce89ce87c  mov eax, 0x430D90
0000714ce89ce881  movups [r13+rax*1], xmm15
0000714ce89ce887  mov eax, 0x430DA0
0000714ce89ce88c  movups [r13+rax*1], xmm1
0000714ce89ce892  mov eax, 0x420AB0
0000714ce89ce897  movups xmm1, [r13+rax*1]
0000714ce89ce89d  mov eax, 0x420B18
0000714ce89ce8a2  mov r12, [r13+rax*1]
0000714ce89ce8a7  movq xmm15, r12
0000714ce89ce8ac  mov qword ptr [r15+0x40], 0x420B20
0000714ce89ce8b4  mov eax, 0x430DB0
0000714ce89ce8b9  movups [r13+rax*1], xmm14
0000714ce89ce8bf  mov eax, 0x430DC0
0000714ce89ce8c4  movups [r13+rax*1], xmm1
0000714ce89ce8ca  mov eax, 0x420B80
0000714ce89ce8cf  movups xmm1, [r13+rax*1]
0000714ce89ce8d5  movq rax, xmm15
0000714ce89ce8da  mov r12d, 0x430DF0
0000714ce89ce8e0  mov [r13+r12*1], rax
0000714ce89ce8e5  mov eax, 0x420B60
0000714ce89ce8ea  movups xmm15, [r13+rax*1]
0000714ce89ce8f0  mov eax, 0x420B70
0000714ce89ce8f5  movups xmm14, [r13+rax*1]
0000714ce89ce8fb  lea rax, [r14+0x160]
0000714ce89ce902  movups [r13+rax*1], xmm1
0000714ce89ce908  lea rax, [r14+0x190]
0000714ce89ce90f  movq xmm1, qword ptr [r15+0x1E0]
0000714ce89ce918  movq xmm13, qword ptr [r15+0x1D0]
0000714ce89ce921  movq r12, xmm1
0000714ce89ce926  movq r11, xmm13
0000714ce89ce92b  mov [r13+rax*1], r12
0000714ce89ce930  lea rax, [r14+0x198]
0000714ce89ce937  mov [r13+rax*1], r11
0000714ce89ce93c  lea rax, [r14+0x140]
0000714ce89ce943  movups [r13+rax*1], xmm15
0000714ce89ce949  lea rax, [r14+0x150]
0000714ce89ce950  movups [r13+rax*1], xmm14
0000714ce89ce956  mov eax, 0x420B20
0000714ce89ce95b  movups xmm1, [r13+rax*1]
0000714ce89ce961  mov eax, 0x420B30
0000714ce89ce966  movups xmm15, [r13+rax*1]
0000714ce89ce96c  movaps [r15+0x120], xmm15
0000714ce89ce974  lea rax, [r14+0x1A0]
0000714ce89ce97b  movq xmm14, qword ptr [r15+0x1C0]
0000714ce89ce984  movq xmm13, qword ptr [r15+0x1B0]
0000714ce89ce98d  movq r12, xmm14
0000714ce89ce992  movq r11, xmm13
0000714ce89ce997  mov [r13+rax*1], r12
0000714ce89ce99c  lea rax, [r14+0x1A8]
0000714ce89ce9a3  mov [r13+rax*1], r11
0000714ce89ce9a8  lea rax, [r14+0x1B0]
0000714ce89ce9af  movq xmm14, qword ptr [r15+0x1A0]
0000714ce89ce9b8  movq xmm13, qword ptr [r15+0x190]
0000714ce89ce9c1  movq r12, xmm14
0000714ce89ce9c6  movq r11, xmm13
0000714ce89ce9cb  mov [r13+rax*1], r12
0000714ce89ce9d0  lea rax, [r14+0x1B8]
0000714ce89ce9d7  mov [r13+rax*1], r11
0000714ce89ce9dc  lea rax, [r14+0x100]
0000714ce89ce9e3  movups [r13+rax*1], xmm1
0000714ce89ce9e9  lea rax, [r14+0x110]
0000714ce89ce9f0  movups [r13+rax*1], xmm15
0000714ce89ce9f6  mov eax, 0x420B40
0000714ce89ce9fb  movups xmm1, [r13+rax*1]
0000714ce89cea01  mov eax, 0x420B50
0000714ce89cea06  movups xmm15, [r13+rax*1]
0000714ce89cea0c  movaps [r15+0x110], xmm1
0000714ce89cea14  movaps [r15+0x130], xmm15
0000714ce89cea1c  lea rax, [r14+0x1C0]
0000714ce89cea23  mov r12, [r15+0xE8]
0000714ce89cea2a  mov r11, [r15+0xF0]
0000714ce89cea31  mov [r13+rax*1], r12
0000714ce89cea36  lea rax, [r14+0x1C8]
0000714ce89cea3d  mov [r13+rax*1], r11
0000714ce89cea42  mov eax, 0x430DF8
0000714ce89cea47  mov r12d, 0x421DF8D3
0000714ce89cea4d  mov [r13+rax*1], r12d
0000714ce89cea52  lea rax, [r14+0x120]
0000714ce89cea59  movups [r13+rax*1], xmm1
0000714ce89cea5f  lea rax, [r14+0x130]
0000714ce89cea66  movups [r13+rax*1], xmm15
0000714ce89cea6c  lea rax, [r14+0x100]
0000714ce89cea73  mov [r15], rax
0000714ce89cea76  mov qword ptr [r15+0x08], 0x430CD0
0000714ce89cea7e  mov qword ptr [r15+0x10], 0x12C
0000714ce89cea86  mov qword ptr [r15+0xF0], 0x410284
0000714ce89cea91  mov r14d, [r15+0x320]
0000714ce89cea98  mov eax, 0x410284
0000714ce89cea9d  mov rcx, 0x714CE89D07C0
0000714ce89ceaa7  mov [r15+r14*8+0x328], rax
0000714ce89ceaaf  mov [r15+r14*8+0x368], rcx
0000714ce89ceab7  add r14d, 0x01
0000714ce89ceabb  and r14d, 0x07
0000714ce89ceabf  mov [r15+0x320], r14d
0000714ce89ceac6  cmp dword ptr [r15+0x318], 0x00
0000714ce89ceace  jz 0x0000714CE89CED70
0000714ce89cead4  nop [rax+rax*1], ax
0000714ce89ceadd  nop [rax+rax*1], eax
0000714ce89ceae5  mov eax, 0x410728
0000714ce89ceaea  mov [r15+0x100], rax
0000714ce89ceaf1  jmp 0x0000714CE87FE110
0000714ce89ceaf6  int3
0000714ce89ceaf7  call 0x0000714CE880BC20
0000714ce89ceafc  jmp 0x0000714CE89CE6CF
0000714ce89ceb01  call 0x0000714CE880A9A0
0000714ce89ceb06  jmp 0x0000714CE89CE6DB
0000714ce89ceb0b  call 0x0000714CE87FF430
0000714ce89ceb10  jmp 0x0000714CE89CE6E6
0000714ce89ceb15  call 0x0000714CE880E760
0000714ce89ceb1a  jmp 0x0000714CE89CE6F1
0000714ce89ceb1f  call 0x0000714CE880D4E0
0000714ce89ceb24  jmp 0x0000714CE89CE6FC
0000714ce89ceb29  call 0x0000714CE880C260
0000714ce89ceb2e  jmp 0x0000714CE89CE707
0000714ce89ceb33  call 0x0000714CE880AFE0
0000714ce89ceb38  jmp 0x0000714CE89CE71D
0000714ce89ceb3d  call 0x0000714CE87FF540
0000714ce89ceb42  jmp 0x0000714CE89CE728
0000714ce89ceb47  call 0x0000714CE880E880
0000714ce89ceb4c  jmp 0x0000714CE89CE733
0000714ce89ceb51  call 0x0000714CE880D600
0000714ce89ceb56  jmp 0x0000714CE89CE73E
0000714ce89ceb5b  call 0x0000714CE880C380
0000714ce89ceb60  jmp 0x0000714CE89CE749
0000714ce89ceb65  call 0x0000714CE880D4E0
0000714ce89ceb6a  jmp 0x0000714CE89CE754
0000714ce89ceb6f  call 0x0000714CE880C260
0000714ce89ceb74  jmp 0x0000714CE89CE75F
0000714ce89ceb79  call 0x0000714CE87FF540
0000714ce89ceb7e  jmp 0x0000714CE89CE76A
0000714ce89ceb83  call 0x0000714CE880E880
0000714ce89ceb88  jmp 0x0000714CE89CE775
0000714ce89ceb8d  call 0x0000714CE880B100
0000714ce89ceb92  jmp 0x0000714CE89CE780
0000714ce89ceb97  call 0x0000714CE880D600
0000714ce89ceb9c  jmp 0x0000714CE89CE78B
0000714ce89ceba1  call 0x0000714CE87FF430
0000714ce89ceba6  jmp 0x0000714CE89CE796
0000714ce89cebab  call 0x0000714CE880E760
0000714ce89cebb0  jmp 0x0000714CE89CE7A1
0000714ce89cebb5  call 0x0000714CE880C380
0000714ce89cebba  jmp 0x0000714CE89CE7AC
0000714ce89cebbf  call 0x0000714CE87FF540
0000714ce89cebc4  jmp 0x0000714CE89CE7B7
0000714ce89cebc9  call 0x0000714CE87FF430
0000714ce89cebce  jmp 0x0000714CE89CE7C2
0000714ce89cebd3  call 0x0000714CE880D4E0
0000714ce89cebd8  jmp 0x0000714CE89CE7CD
0000714ce89cebdd  call 0x0000714CE880E880
0000714ce89cebe2  jmp 0x0000714CE89CE7E0
0000714ce89cebe7  call 0x0000714CE87FF540
0000714ce89cebec  jmp 0x0000714CE89CE7EB
0000714ce89cebf1  call 0x0000714CE87FF430
0000714ce89cebf6  jmp 0x0000714CE89CE7F6
0000714ce89cebfb  call 0x0000714CE880E760
0000714ce89cec00  jmp 0x0000714CE89CE801
0000714ce89cec05  call 0x0000714CE880D600
0000714ce89cec0a  jmp 0x0000714CE89CE81F
0000714ce89cec0f  call 0x0000714CE87FF540
0000714ce89cec14  jmp 0x0000714CE89CE82A
0000714ce89cec19  call 0x0000714CE87FF430
0000714ce89cec1e  jmp 0x0000714CE89CE835
0000714ce89cec23  call 0x0000714CE880D4E0
0000714ce89cec28  jmp 0x0000714CE89CE840
0000714ce89cec2d  call 0x0000714CE880BC20
0000714ce89cec32  jmp 0x0000714CE89CE870
0000714ce89cec37  call 0x0000714CE880A9A0
0000714ce89cec3c  jmp 0x0000714CE89CE87C
0000714ce89cec41  call 0x0000714CE880E880
0000714ce89cec46  jmp 0x0000714CE89CE887
0000714ce89cec4b  call 0x0000714CE87FF540
0000714ce89cec50  jmp 0x0000714CE89CE892
0000714ce89cec55  call 0x0000714CE87FF430
0000714ce89cec5a  jmp 0x0000714CE89CE89D
0000714ce89cec5f  call 0x0000714CE880B720
0000714ce89cec64  jmp 0x0000714CE89CE8A7
0000714ce89cec69  call 0x0000714CE880D600
0000714ce89cec6e  jmp 0x0000714CE89CE8BF
0000714ce89cec73  call 0x0000714CE87FF540
0000714ce89cec78  jmp 0x0000714CE89CE8CA
0000714ce89cec7d  call 0x0000714CE87FF430
0000714ce89cec82  jmp 0x0000714CE89CE8D5
0000714ce89cec87  call 0x0000714CE88B4CB0
0000714ce89cec8c  jmp 0x0000714CE89CE8E5
0000714ce89cec91  call 0x0000714CE880E760
0000714ce89cec96  jmp 0x0000714CE89CE8F0
0000714ce89cec9b  call 0x0000714CE880D4E0
0000714ce89ceca0  jmp 0x0000714CE89CE8FB
0000714ce89ceca5  call 0x0000714CE87FF540
0000714ce89cecaa  jmp 0x0000714CE89CE908
0000714ce89cecaf  call 0x0000714CE880BC20
0000714ce89cecb4  jmp 0x0000714CE89CE930
0000714ce89cecb9  call 0x0000714CE880A9A0
0000714ce89cecbe  jmp 0x0000714CE89CE93C
0000714ce89cecc3  call 0x0000714CE880E880
0000714ce89cecc8  jmp 0x0000714CE89CE949
0000714ce89ceccd  call 0x0000714CE880D600
0000714ce89cecd2  jmp 0x0000714CE89CE956
0000714ce89cecd7  call 0x0000714CE87FF430
0000714ce89cecdc  jmp 0x0000714CE89CE961
0000714ce89cece1  call 0x0000714CE880E760
0000714ce89cece6  jmp 0x0000714CE89CE96C
0000714ce89ceceb  call 0x0000714CE880BC20
0000714ce89cecf0  jmp 0x0000714CE89CE99C
0000714ce89cecf5  call 0x0000714CE880A9A0
0000714ce89cecfa  jmp 0x0000714CE89CE9A8
0000714ce89cecff  call 0x0000714CE880BC20
0000714ce89ced04  jmp 0x0000714CE89CE9D0
0000714ce89ced09  call 0x0000714CE880A9A0
0000714ce89ced0e  jmp 0x0000714CE89CE9DC
0000714ce89ced13  call 0x0000714CE87FF540
0000714ce89ced18  jmp 0x0000714CE89CE9E9
0000714ce89ced1d  call 0x0000714CE880E880
0000714ce89ced22  jmp 0x0000714CE89CE9F6
0000714ce89ced27  call 0x0000714CE87FF430
0000714ce89ced2c  jmp 0x0000714CE89CEA01
0000714ce89ced31  call 0x0000714CE880E760
0000714ce89ced36  jmp 0x0000714CE89CEA0C
0000714ce89ced3b  call 0x0000714CE880BC20
0000714ce89ced40  jmp 0x0000714CE89CEA36
0000714ce89ced45  call 0x0000714CE880A9A0
0000714ce89ced4a  jmp 0x0000714CE89CEA42
0000714ce89ced4f  call 0x0000714CE880BAE0
0000714ce89ced54  jmp 0x0000714CE89CEA52
0000714ce89ced59  call 0x0000714CE87FF540
0000714ce89ced5e  jmp 0x0000714CE89CEA5F
0000714ce89ced63  call 0x0000714CE880E880
0000714ce89ced68  jmp 0x0000714CE89CEA6C
0000714ce89ced6d  int3
0000714ce89ced6e  nop
0000714ce89ced70  mov rax, [r15]
0000714ce89ced73  lea r14, [rax+0x20]
0000714ce89ced77  mov r12, [r13+r14*1]
0000714ce89ced7c  mov r14, [r15+0x10]
0000714ce89ced80  lea r11, [r12+r14*1]
0000714ce89ced84  mov [r15+0x40], r11
0000714ce89ced88  lea r12, [rax+0x20]
0000714ce89ced8c  mov [r13+r12*1], r11
0000714ce89ced91  test r14, r14
0000714ce89ced94  setz r14b
0000714ce89ced98  movzx r14, r14b
0000714ce89ced9c  mov [rsp+0x414], r14b
0000714ce89ceda4  cmp byte ptr [rsp+0x414], 0x00
0000714ce89cedac  jz 0x0000714CE89CEDDE
0000714ce89cedae  cmp dword ptr [r15+0x318], 0x00
0000714ce89cedb6  mov eax, 0x4109A0
0000714ce89cedbb  mov [r15+0x100], rax
0000714ce89cedc2  jz 0x0000714CE87FE0A0
0000714ce89cedc8  nop [rax+rax*1], eax
0000714ce89cedcd  mov eax, 0x4109A0
0000714ce89cedd2  mov [r15+0x100], rax
0000714ce89cedd9  jmp 0x0000714CE87FE110
0000714ce89cedde  cmp dword ptr [r15+0x318], 0x00
0000714ce89cede6  jz 0x0000714CE89CEE30
0000714ce89cedec  nop [rax+rax*1], ax
0000714ce89cedf5  nop [rax+rax*1], eax
0000714ce89cedfd  mov eax, 0x410738
0000714ce89cee02  mov [r15+0x100], rax
0000714ce89cee09  jmp 0x0000714CE87FE110
0000714ce89cee0e  int3
0000714ce89cee0f  call 0x0000714CE88E27E0
0000714ce89cee14  jmp 0x0000714CE89CED7C
0000714ce89cee19  call 0x0000714CE88C0860
0000714ce89cee1e  jmp 0x0000714CE89CED91
0000714ce89cee23  int3
0000714ce89cee24  nop [rax+rax*1], ax
0000714ce89cee2d  nop [rax], eax
0000714ce89cee30  mov rax, [r15+0xF8]
0000714ce89cee37  lea r14, [rax-0x150]
0000714ce89cee3e  mov [r15+0xF8], r14
0000714ce89cee45  mov rax, [r15]
0000714ce89cee48  lea r12, [rax+0x68]
0000714ce89cee4c  mov r11, [r13+r12*1]
0000714ce89cee51  mov [r15+0x88], r11
0000714ce89cee58  lea r12, [rax+0x28]
0000714ce89cee5c  mov [r15+0x40], r12
0000714ce89cee60  mov [r15+0x48], r14
0000714ce89cee64  mov qword ptr [r15+0x50], 0x420B90
0000714ce89cee6c  lea rax, [r14+0x100]
0000714ce89cee73  mov r12, [r15+0xE8]
0000714ce89cee7a  mov r11, [r15+0xD8]
0000714ce89cee81  mov [r13+rax*1], r12
0000714ce89cee86  lea rax, [r14+0x108]
0000714ce89cee8d  mov [r13+rax*1], r11
0000714ce89cee92  lea rax, [r14+0x110]
0000714ce89cee99  mov r12, [r15+0xD0]
0000714ce89ceea0  mov r11, [r15+0xC8]
0000714ce89ceea7  mov [r13+rax*1], r12
0000714ce89ceeac  lea rax, [r14+0x118]
0000714ce89ceeb3  mov [r13+rax*1], r11
0000714ce89ceeb8  lea rax, [r14+0x120]
0000714ce89ceebf  mov r12, [r15+0xC0]
0000714ce89ceec6  mov r11, [r15+0xB8]
0000714ce89ceecd  mov [r13+rax*1], r12
0000714ce89ceed2  lea rax, [r14+0x128]
0000714ce89ceed9  mov [r13+rax*1], r11
0000714ce89ceede  lea rax, [r14+0x130]
0000714ce89ceee5  mov r12, [r15+0xB0]
0000714ce89ceeec  mov r11, [r15+0xA8]
0000714ce89ceef3  mov [r13+rax*1], r12
0000714ce89ceef8  lea rax, [r14+0x138]
0000714ce89ceeff  mov [r13+rax*1], r11
0000714ce89cef04  lea rax, [r14+0x140]
0000714ce89cef0b  mov r12, [r15+0xA0]
0000714ce89cef12  mov r11, [r15+0x98]
0000714ce89cef19  mov [r13+rax*1], r12
0000714ce89cef1e  lea rax, [r14+0x148]
0000714ce89cef25  mov [r13+rax*1], r11
0000714ce89cef2a  cmp dword ptr [r15+0x318], 0x00
0000714ce89cef32  jz 0x0000714CE89CEFD0
0000714ce89cef38  nop [rax+rax*1], ax
0000714ce89cef41  nop [rax+rax*1], eax
0000714ce89cef49  mov eax, 0x410770
0000714ce89cef4e  mov [r15+0x100], rax
0000714ce89cef55  jmp 0x0000714CE87FE110
0000714ce89cef5a  int3
0000714ce89cef5b  call 0x0000714CE88C0370
0000714ce89cef60  jmp 0x0000714CE89CEE51
0000714ce89cef65  call 0x0000714CE880BC20
0000714ce89cef6a  jmp 0x0000714CE89CEE86
0000714ce89cef6f  call 0x0000714CE880A9A0
0000714ce89cef74  jmp 0x0000714CE89CEE92
0000714ce89cef79  call 0x0000714CE880BC20
0000714ce89cef7e  jmp 0x0000714CE89CEEAC
0000714ce89cef83  call 0x0000714CE880A9A0
0000714ce89cef88  jmp 0x0000714CE89CEEB8
0000714ce89cef8d  call 0x0000714CE880BC20
0000714ce89cef92  jmp 0x0000714CE89CEED2
0000714ce89cef97  call 0x0000714CE880A9A0
0000714ce89cef9c  jmp 0x0000714CE89CEEDE
0000714ce89cefa1  call 0x0000714CE880BC20
0000714ce89cefa6  jmp 0x0000714CE89CEEF8
0000714ce89cefab  call 0x0000714CE880A9A0
0000714ce89cefb0  jmp 0x0000714CE89CEF04
0000714ce89cefb5  call 0x0000714CE880BC20
0000714ce89cefba  jmp 0x0000714CE89CEF1E
0000714ce89cefbf  call 0x0000714CE880A9A0
0000714ce89cefc4  jmp 0x0000714CE89CEF2A
0000714ce89cefc9  int3
0000714ce89cefca  nop [rax+rax*1], ax
0000714ce89cefd0  mov rax, [r15+0x08]
0000714ce89cefd4  movzx r14d, byte ptr [r13+rax*1]
0000714ce89cefda  movzx r14d, r14b
0000714ce89cefde  mov [rsp+0x10], r14d
0000714ce89cefe3  mov r14d, r14d
0000714ce89cefe6  mov [r15+0x58], r14
0000714ce89cefea  lea r14, [rax+0x01]
0000714ce89cefee  mov [r15+0x08], r14
0000714ce89ceff2  mov rax, [r15+0x88]
0000714ce89ceff9  lea r14, [rax+0x01]
0000714ce89ceffd  mov r12, [r15]
0000714ce89cf000  lea r11, [r12+0x68]
0000714ce89cf005  mov [r13+r11*1], r14
0000714ce89cf00a  lea r14, [r12+rax*1]
0000714ce89cf00e  mov [r15+0x60], r14
0000714ce89cf012  lea rax, [r14+0x28]
0000714ce89cf016  mov r11d, [rsp+0x10]
0000714ce89cf01b  movzx r14d, r11b
0000714ce89cf01f  mov [r13+rax*1], r14b
0000714ce89cf024  lea rax, [r12+0x68]
0000714ce89cf029  mov r14, [r13+rax*1]
0000714ce89cf02e  mov [r15+0x88], r14
0000714ce89cf035  xor eax, eax
0000714ce89cf037  mov r12d, 0x40
0000714ce89cf03d  cmp r14, r12
0000714ce89cf040  cmc
0000714ce89cf041  lahf
0000714ce89cf042  seto al
0000714ce89cf045  mov [r15+0x108], eax
0000714ce89cf04c  mov eax, [r15+0x108]
0000714ce89cf053  sahf
0000714ce89cf054  jnz 0x0000714CE89CF086
0000714ce89cf056  cmp dword ptr [r15+0x318], 0x00
0000714ce89cf05e  jz 0x0000714CE89CF170
0000714ce89cf064  nop [rax+rax*1], ax
0000714ce89cf06d  nop [rax+rax*1], eax
0000714ce89cf075  mov eax, 0x410790
0000714ce89cf07a  mov [r15+0x100], rax
0000714ce89cf081  jmp 0x0000714CE87FE110
0000714ce89cf086  cmp dword ptr [r15+0x318], 0x00
0000714ce89cf08e  jz 0x0000714CE89CF0E0
0000714ce89cf094  nop [rax+rax*1], ax
0000714ce89cf09d  nop [rax+rax*1], eax
0000714ce89cf0a5  mov eax, 0x410768
0000714ce89cf0aa  mov [r15+0x100], rax
0000714ce89cf0b1  jmp 0x0000714CE87FE110
0000714ce89cf0b6  int3
0000714ce89cf0b7  call 0x0000714CE880D860
0000714ce89cf0bc  jmp 0x0000714CE89CEFDA
0000714ce89cf0c1  call 0x0000714CE88B36E0
0000714ce89cf0c6  jmp 0x0000714CE89CF00A
0000714ce89cf0cb  call 0x0000714CE880DD60
0000714ce89cf0d0  jmp 0x0000714CE89CF024
0000714ce89cf0d5  call 0x0000714CE880DC20
0000714ce89cf0da  jmp 0x0000714CE89CF02E
0000714ce89cf0df  int3
0000714ce89cf0e0  mov rax, [r15+0x10]
0000714ce89cf0e4  lea r14, [rax-0x01]
0000714ce89cf0e8  mov [r15+0x10], r14
0000714ce89cf0ec  test r14, r14
0000714ce89cf0ef  setz r14b
0000714ce89cf0f3  movzx r14, r14b
0000714ce89cf0f7  mov [rsp+0x414], r14b
0000714ce89cf0ff  cmp byte ptr [rsp+0x414], 0x00
0000714ce89cf107  jz 0x0000714CE89CF139
0000714ce89cf109  cmp dword ptr [r15+0x318], 0x00
0000714ce89cf111  jz 0x0000714CE89D0670
0000714ce89cf117  nop [rax+rax*1], ax
0000714ce89cf120  nop [rax+rax*1], eax
0000714ce89cf128  mov eax, 0x410988
0000714ce89cf12d  mov [r15+0x100], rax
0000714ce89cf134  jmp 0x0000714CE87FE110
0000714ce89cf139  cmp dword ptr [r15+0x318], 0x00
0000714ce89cf141  jz 0x0000714CE89CEFD0
0000714ce89cf147  nop [rax+rax*1], ax
0000714ce89cf150  nop [rax+rax*1], eax
0000714ce89cf158  mov eax, 0x410770
0000714ce89cf15d  mov [r15+0x100], rax
0000714ce89cf164  jmp 0x0000714CE87FE110
0000714ce89cf169  int3
0000714ce89cf16a  int3
0000714ce89cf16b  nop [rax+rax*1], eax
0000714ce89cf170  mov rax, [r15+0x40]
0000714ce89cf174  movzx r14d, byte ptr [r13+rax*1]
0000714ce89cf17a  movaps xmm1, [r15+0x110]
0000714ce89cf182  pinsrb xmm1, r14d, 0x00
0000714ce89cf189  lea r14, [rax+0x01]
0000714ce89cf18d  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf193  movaps xmm15, [r15+0x120]
0000714ce89cf19b  pinsrb xmm15, r12d, 0x00
0000714ce89cf1a2  lea r14, [rax+0x02]
0000714ce89cf1a6  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf1ac  movaps xmm14, [r15+0x130]
0000714ce89cf1b4  pinsrb xmm14, r12d, 0x00
0000714ce89cf1bb  lea r14, [rax+0x03]
0000714ce89cf1bf  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf1c5  movaps xmm13, [r15+0x140]
0000714ce89cf1cd  pinsrb xmm13, r12d, 0x00
0000714ce89cf1d4  lea r14, [rax+0x04]
0000714ce89cf1d8  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf1de  pinsrb xmm1, r12d, 0x01
0000714ce89cf1e5  lea r14, [rax+0x05]
0000714ce89cf1e9  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf1ef  pinsrb xmm15, r12d, 0x01
0000714ce89cf1f6  lea r14, [rax+0x06]
0000714ce89cf1fa  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf200  pinsrb xmm14, r12d, 0x01
0000714ce89cf207  lea r14, [rax+0x07]
0000714ce89cf20b  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf211  pinsrb xmm13, r12d, 0x01
0000714ce89cf218  lea r14, [rax+0x08]
0000714ce89cf21c  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf222  pinsrb xmm1, r12d, 0x02
0000714ce89cf229  lea r14, [rax+0x09]
0000714ce89cf22d  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf233  pinsrb xmm15, r12d, 0x02
0000714ce89cf23a  lea r14, [rax+0x0A]
0000714ce89cf23e  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf244  pinsrb xmm14, r12d, 0x02
0000714ce89cf24b  lea r14, [rax+0x0B]
0000714ce89cf24f  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf255  pinsrb xmm13, r12d, 0x02
0000714ce89cf25c  lea r14, [rax+0x0C]
0000714ce89cf260  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf266  pinsrb xmm1, r12d, 0x03
0000714ce89cf26d  lea r14, [rax+0x0D]
0000714ce89cf271  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf277  pinsrb xmm15, r12d, 0x03
0000714ce89cf27e  lea r14, [rax+0x0E]
0000714ce89cf282  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf288  pinsrb xmm14, r12d, 0x03
0000714ce89cf28f  lea r14, [rax+0x0F]
0000714ce89cf293  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf299  pinsrb xmm13, r12d, 0x03
0000714ce89cf2a0  lea r14, [rax+0x10]
0000714ce89cf2a4  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf2aa  pinsrb xmm1, r12d, 0x04
0000714ce89cf2b1  lea r14, [rax+0x11]
0000714ce89cf2b5  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf2bb  pinsrb xmm15, r12d, 0x04
0000714ce89cf2c2  lea r14, [rax+0x12]
0000714ce89cf2c6  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf2cc  pinsrb xmm14, r12d, 0x04
0000714ce89cf2d3  lea r14, [rax+0x13]
0000714ce89cf2d7  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf2dd  pinsrb xmm13, r12d, 0x04
0000714ce89cf2e4  lea r14, [rax+0x14]
0000714ce89cf2e8  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf2ee  pinsrb xmm1, r12d, 0x05
0000714ce89cf2f5  lea r14, [rax+0x15]
0000714ce89cf2f9  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf2ff  pinsrb xmm15, r12d, 0x05
0000714ce89cf306  lea r14, [rax+0x16]
0000714ce89cf30a  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf310  pinsrb xmm14, r12d, 0x05
0000714ce89cf317  lea r14, [rax+0x17]
0000714ce89cf31b  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf321  pinsrb xmm13, r12d, 0x05
0000714ce89cf328  lea r14, [rax+0x18]
0000714ce89cf32c  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf332  pinsrb xmm1, r12d, 0x06
0000714ce89cf339  lea r14, [rax+0x19]
0000714ce89cf33d  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf343  pinsrb xmm15, r12d, 0x06
0000714ce89cf34a  lea r14, [rax+0x1A]
0000714ce89cf34e  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf354  pinsrb xmm14, r12d, 0x06
0000714ce89cf35b  lea r14, [rax+0x1B]
0000714ce89cf35f  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf365  pinsrb xmm13, r12d, 0x06
0000714ce89cf36c  lea r14, [rax+0x1C]
0000714ce89cf370  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf376  pinsrb xmm1, r12d, 0x07
0000714ce89cf37d  lea r14, [rax+0x1D]
0000714ce89cf381  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf387  pinsrb xmm15, r12d, 0x07
0000714ce89cf38e  lea r14, [rax+0x1E]
0000714ce89cf392  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf398  pinsrb xmm14, r12d, 0x07
0000714ce89cf39f  lea r14, [rax+0x1F]
0000714ce89cf3a3  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf3a9  pinsrb xmm13, r12d, 0x07
0000714ce89cf3b0  lea r14, [rax+0x20]
0000714ce89cf3b4  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf3ba  pinsrb xmm1, r12d, 0x08
0000714ce89cf3c1  lea r14, [rax+0x21]
0000714ce89cf3c5  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf3cb  pinsrb xmm15, r12d, 0x08
0000714ce89cf3d2  lea r14, [rax+0x22]
0000714ce89cf3d6  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf3dc  pinsrb xmm14, r12d, 0x08
0000714ce89cf3e3  lea r14, [rax+0x23]
0000714ce89cf3e7  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf3ed  pinsrb xmm13, r12d, 0x08
0000714ce89cf3f4  lea r14, [rax+0x24]
0000714ce89cf3f8  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf3fe  pinsrb xmm1, r12d, 0x09
0000714ce89cf405  lea r14, [rax+0x25]
0000714ce89cf409  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf40f  pinsrb xmm15, r12d, 0x09
0000714ce89cf416  lea r14, [rax+0x26]
0000714ce89cf41a  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf420  pinsrb xmm14, r12d, 0x09
0000714ce89cf427  lea r14, [rax+0x27]
0000714ce89cf42b  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf431  pinsrb xmm13, r12d, 0x09
0000714ce89cf438  lea r14, [rax+0x28]
0000714ce89cf43c  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf442  pinsrb xmm1, r12d, 0x0A
0000714ce89cf449  lea r14, [rax+0x29]
0000714ce89cf44d  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf453  pinsrb xmm15, r12d, 0x0A
0000714ce89cf45a  lea r14, [rax+0x2A]
0000714ce89cf45e  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf464  pinsrb xmm14, r12d, 0x0A
0000714ce89cf46b  lea r14, [rax+0x2B]
0000714ce89cf46f  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf475  pinsrb xmm13, r12d, 0x0A
0000714ce89cf47c  lea r14, [rax+0x2C]
0000714ce89cf480  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf486  pinsrb xmm1, r12d, 0x0B
0000714ce89cf48d  lea r14, [rax+0x2D]
0000714ce89cf491  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf497  pinsrb xmm15, r12d, 0x0B
0000714ce89cf49e  lea r14, [rax+0x2E]
0000714ce89cf4a2  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf4a8  pinsrb xmm14, r12d, 0x0B
0000714ce89cf4af  lea r14, [rax+0x2F]
0000714ce89cf4b3  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf4b9  pinsrb xmm13, r12d, 0x0B
0000714ce89cf4c0  lea r14, [rax+0x30]
0000714ce89cf4c4  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf4ca  pinsrb xmm1, r12d, 0x0C
0000714ce89cf4d1  lea r14, [rax+0x31]
0000714ce89cf4d5  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf4db  pinsrb xmm15, r12d, 0x0C
0000714ce89cf4e2  lea r14, [rax+0x32]
0000714ce89cf4e6  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf4ec  pinsrb xmm14, r12d, 0x0C
0000714ce89cf4f3  lea r14, [rax+0x33]
0000714ce89cf4f7  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf4fd  pinsrb xmm13, r12d, 0x0C
0000714ce89cf504  lea r14, [rax+0x34]
0000714ce89cf508  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf50e  pinsrb xmm1, r12d, 0x0D
0000714ce89cf515  lea r14, [rax+0x35]
0000714ce89cf519  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf51f  pinsrb xmm15, r12d, 0x0D
0000714ce89cf526  lea r14, [rax+0x36]
0000714ce89cf52a  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf530  pinsrb xmm14, r12d, 0x0D
0000714ce89cf537  lea r14, [rax+0x37]
0000714ce89cf53b  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf541  pinsrb xmm13, r12d, 0x0D
0000714ce89cf548  lea r14, [rax+0x38]
0000714ce89cf54c  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf552  pinsrb xmm1, r12d, 0x0E
0000714ce89cf559  lea r14, [rax+0x39]
0000714ce89cf55d  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf563  pinsrb xmm15, r12d, 0x0E
0000714ce89cf56a  lea r14, [rax+0x3A]
0000714ce89cf56e  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf574  pinsrb xmm14, r12d, 0x0E
0000714ce89cf57b  lea r14, [rax+0x3B]
0000714ce89cf57f  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf585  pinsrb xmm13, r12d, 0x0E
0000714ce89cf58c  lea r14, [rax+0x3C]
0000714ce89cf590  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf596  pinsrb xmm1, r12d, 0x0F
0000714ce89cf59d  movaps [r15+0x110], xmm1
0000714ce89cf5a5  lea r14, [rax+0x3D]
0000714ce89cf5a9  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf5af  pinsrb xmm15, r12d, 0x0F
0000714ce89cf5b6  movaps [r15+0x120], xmm15
0000714ce89cf5be  lea r14, [rax+0x3E]
0000714ce89cf5c2  movzx r12d, byte ptr [r13+r14*1]
0000714ce89cf5c8  pinsrb xmm14, r12d, 0x0F
0000714ce89cf5cf  movaps [r15+0x130], xmm14
0000714ce89cf5d7  lea r14, [rax+0x3F]
0000714ce89cf5db  movzx eax, byte ptr [r13+r14*1]
0000714ce89cf5e1  pinsrb xmm13, eax, 0x0F
0000714ce89cf5e8  movaps [r15+0x140], xmm13
0000714ce89cf5f0  movq xmm1, qword ptr [r15+0x120]
0000714ce89cf5f9  pmovzxbw xmm1, xmm1
0000714ce89cf5fe  psllw xmm1, 0x00
0000714ce89cf603  movaps [r15+0x150], xmm1
0000714ce89cf60b  movq xmm1, qword ptr [r15+0x130]
0000714ce89cf614  pmovzxbw xmm1, xmm1
0000714ce89cf619  psllw xmm1, 0x00
0000714ce89cf61e  movaps [r15+0x160], xmm1
0000714ce89cf626  movq xmm1, qword ptr [r15+0x110]
0000714ce89cf62f  pmovzxbw xmm1, xmm1
0000714ce89cf634  psllw xmm1, 0x00
0000714ce89cf639  movaps [r15+0x170], xmm1
0000714ce89cf641  movaps xmm15, [r15+0x110]
0000714ce89cf649  pextrq rax, xmm15, 0x01
0000714ce89cf650  movq xmm15, rax
0000714ce89cf655  pmovzxbw xmm15, xmm15
0000714ce89cf65b  psllw xmm15, 0x00
0000714ce89cf661  movaps [r15+0x180], xmm15
0000714ce89cf669  movaps xmm14, [r15+0x120]
0000714ce89cf671  pextrq rax, xmm14, 0x01
0000714ce89cf678  movq xmm14, rax
0000714ce89cf67d  pmovzxbw xmm14, xmm14
0000714ce89cf683  psllw xmm14, 0x00
0000714ce89cf689  movaps [r15+0x210], xmm14
0000714ce89cf691  movaps xmm13, [r15+0x130]
0000714ce89cf699  pextrq rax, xmm13, 0x01
0000714ce89cf6a0  movq xmm13, rax
0000714ce89cf6a5  pmovzxbw xmm13, xmm13
0000714ce89cf6ab  psllw xmm13, 0x00
0000714ce89cf6b1  movaps [r15+0x220], xmm13
0000714ce89cf6b9  movq xmm12, qword ptr [r15+0x140]
0000714ce89cf6c2  pmovzxbw xmm12, xmm12
0000714ce89cf6c8  psllw xmm12, 0x00
0000714ce89cf6ce  movaps [r15+0x250], xmm12
0000714ce89cf6d6  movaps xmm12, [r15+0x140]
0000714ce89cf6de  pextrq rax, xmm12, 0x01
0000714ce89cf6e5  movq xmm12, rax
0000714ce89cf6ea  pmovzxbw xmm12, xmm12
0000714ce89cf6f0  psllw xmm12, 0x00
0000714ce89cf6f6  movaps [r15+0x110], xmm12
0000714ce89cf6fe  movq xmm11, qword ptr [r15+0x150]
0000714ce89cf707  pmovzxwd xmm11, xmm11
0000714ce89cf70d  pslld xmm11, 0x10
0000714ce89cf713  movq xmm10, qword ptr [r15+0x160]
0000714ce89cf71c  pmovzxwd xmm10, xmm10
0000714ce89cf722  pslld xmm10, 0x08
0000714ce89cf728  pextrq rax, xmm1, 0x01
0000714ce89cf72f  movq xmm1, rax
0000714ce89cf734  pmovzxwd xmm1, xmm1
0000714ce89cf739  pslld xmm1, 0x00
0000714ce89cf73e  movaps [r15+0x260], xmm1
0000714ce89cf746  pextrq rax, xmm15, 0x01
0000714ce89cf74d  movq xmm15, rax
0000714ce89cf752  pmovzxwd xmm15, xmm15
0000714ce89cf758  pslld xmm15, 0x00
0000714ce89cf75e  movaps [r15+0x270], xmm15
0000714ce89cf766  movq xmm9, qword ptr [r15+0x170]
0000714ce89cf76f  pmovzxwd xmm9, xmm9
0000714ce89cf775  pslld xmm9, 0x00
0000714ce89cf77b  pextrq rax, xmm14, 0x01
0000714ce89cf782  movq xmm14, rax
0000714ce89cf787  pmovzxwd xmm14, xmm14
0000714ce89cf78d  pslld xmm14, 0x10
0000714ce89cf793  movaps [r15+0x280], xmm14
0000714ce89cf79b  movq xmm8, qword ptr [r15+0x180]
0000714ce89cf7a4  pmovzxwd xmm8, xmm8
0000714ce89cf7aa  pslld xmm8, 0x00
0000714ce89cf7b0  movq xmm7, qword ptr [r15+0x210]
0000714ce89cf7b9  pmovzxwd xmm7, xmm7
0000714ce89cf7be  pslld xmm7, 0x10
0000714ce89cf7c3  movaps xmm6, [r15+0x150]
0000714ce89cf7cb  pextrq rax, xmm6, 0x01
0000714ce89cf7d2  movq xmm6, rax
0000714ce89cf7d7  pmovzxwd xmm6, xmm6
0000714ce89cf7dc  pslld xmm6, 0x10
0000714ce89cf7e1  por xmm11, xmm10
0000714ce89cf7e6  movaps [r15+0x230], xmm11
0000714ce89cf7ee  pextrq rax, xmm13, 0x01
0000714ce89cf7f5  movq xmm13, rax
0000714ce89cf7fa  pmovzxwd xmm13, xmm13
0000714ce89cf800  pslld xmm13, 0x08
0000714ce89cf806  movaps [r15+0x240], xmm13
0000714ce89cf80e  movq xmm10, qword ptr [r15+0x220]
0000714ce89cf817  pmovzxwd xmm10, xmm10
0000714ce89cf81d  pslld xmm10, 0x08
0000714ce89cf823  movaps xmm5, [r15+0x160]
0000714ce89cf82b  pextrq rax, xmm5, 0x01
0000714ce89cf832  movq xmm5, rax
0000714ce89cf837  pmovzxwd xmm5, xmm5
0000714ce89cf83c  pslld xmm5, 0x08
0000714ce89cf841  pslld xmm9, 0x18
0000714ce89cf847  pslld xmm15, 0x18
0000714ce89cf84d  pslld xmm8, 0x18
0000714ce89cf853  movq xmm4, qword ptr [r15+0x250]
0000714ce89cf85c  pmovzxwd xmm4, xmm4
0000714ce89cf861  pslld xmm4, 0x00
0000714ce89cf866  por xmm14, xmm13
0000714ce89cf86b  por xmm7, xmm10
0000714ce89cf870  movaps [r15+0x210], xmm7
0000714ce89cf878  pslld xmm1, 0x18
0000714ce89cf87d  movaps [r15+0x220], xmm1
0000714ce89cf885  por xmm6, xmm5
0000714ce89cf889  por xmm11, xmm9
0000714ce89cf88e  movaps [r15+0x160], xmm11
0000714ce89cf896  pextrq rax, xmm12, 0x01
0000714ce89cf89d  movq xmm13, rax
0000714ce89cf8a2  pmovzxwd xmm13, xmm13
0000714ce89cf8a8  pslld xmm13, 0x00
0000714ce89cf8ae  movaps [r15+0x170], xmm13
0000714ce89cf8b6  movq xmm12, qword ptr [r15+0x110]
0000714ce89cf8bf  pmovzxwd xmm12, xmm12
0000714ce89cf8c5  pslld xmm12, 0x00
0000714ce89cf8cb  por xmm14, xmm15
0000714ce89cf8d0  por xmm7, xmm8
0000714ce89cf8d5  movaps xmm15, [r15+0x250]
0000714ce89cf8dd  pextrq rax, xmm15, 0x01
0000714ce89cf8e4  movq xmm15, rax
0000714ce89cf8e9  pmovzxwd xmm15, xmm15
0000714ce89cf8ef  pslld xmm15, 0x00
0000714ce89cf8f5  movaps [r15+0x180], xmm15
0000714ce89cf8fd  por xmm6, xmm1
0000714ce89cf901  movaps [r15+0x150], xmm6
0000714ce89cf909  por xmm11, xmm4
0000714ce89cf90e  movaps [r15+0x140], xmm11
0000714ce89cf916  por xmm7, xmm12
0000714ce89cf91b  movaps [r15+0x110], xmm7
0000714ce89cf923  por xmm14, xmm13
0000714ce89cf928  movaps [r15+0x120], xmm14
0000714ce89cf930  por xmm6, xmm15
0000714ce89cf935  movaps [r15+0x130], xmm6
0000714ce89cf93d  mov rax, [r15+0xF8]
0000714ce89cf944  lea r14, [rax+0x20]
0000714ce89cf948  movups [r13+r14*1], xmm7
0000714ce89cf94e  lea r14, [rax+0x30]
0000714ce89cf952  movups [r13+r14*1], xmm14
0000714ce89cf958  movups [r13+rax*1], xmm11
0000714ce89cf95e  lea r14, [rax+0x10]
0000714ce89cf962  movups [r13+r14*1], xmm6
0000714ce89cf968  mov r14d, [r13+rax*1]
0000714ce89cf96d  mov rax, [r15+0x48]
0000714ce89cf971  mov [r15+0x68], rax
0000714ce89cf975  mov qword ptr [r15+0x58], 0x04
0000714ce89cf97d  lea r12, [rax+0x04]
0000714ce89cf981  mov r11d, [r13+r12*1]
0000714ce89cf986  mov [rsp+0x10], r11d
0000714ce89cf98b  mov r11d, r11d
0000714ce89cf98e  mov [r15+0x70], r11
0000714ce89cf992  lea r12, [rax+0x38]
0000714ce89cf996  mov r11d, [r13+r12*1]
0000714ce89cf99b  lea r12, [rax+0x24]
0000714ce89cf99f  mov r10d, [r13+r12*1]
0000714ce89cf9a4  mov [rsp+0x20], r10d
0000714ce89cf9a9  mov r10d, r10d
0000714ce89cf9ac  mov [r15+0x90], r10
0000714ce89cf9b3  mov [rsp+0x30], rax
0000714ce89cf9b8  xor eax, eax
0000714ce89cf9ba  mov r12d, 0x04
0000714ce89cf9c0  mov r10d, 0xC0
0000714ce89cf9c6  cmp r12, r10
0000714ce89cf9c9  cmc
0000714ce89cf9ca  lahf
0000714ce89cf9cb  seto al
0000714ce89cf9ce  mov [r15+0x108], eax
0000714ce89cf9d5  mov eax, [rsp+0x10]
0000714ce89cf9d9  mov r12d, [rsp+0x10]
0000714ce89cf9de  shrd eax, r12d, 0x07
0000714ce89cf9e3  mov [rsp+0x10], r11d
0000714ce89cf9e8  mov r10d, [rsp+0x10]
0000714ce89cf9ed  shrd r11d, r10d, 0x11
0000714ce89cf9f2  mov r9d, [rsp+0x20]
0000714ce89cf9f7  lea r8d, [r9d+r14d*1]
0000714ce89cf9fc  rorx r14d, r12d, 0x12
0000714ce89cfa02  xor eax, r14d
0000714ce89cfa05  rorx r14d, r10d, 0x13
0000714ce89cfa0b  xor r11d, r14d
0000714ce89cfa0e  mov [rsp+0x10], r11d
0000714ce89cfa13  mov r11d, r11d
0000714ce89cfa16  mov [r15+0x88], r11
0000714ce89cfa1d  mov [rsp+0x20], r12d
0000714ce89cfa22  shr r12d, 0x03
0000714ce89cfa26  xor eax, r12d
0000714ce89cfa29  mov [rsp+0x40], eax
0000714ce89cfa2d  mov eax, eax
0000714ce89cfa2f  mov [r15+0x80], rax
0000714ce89cfa36  shr r10d, 0x0A
0000714ce89cfa3a  mov eax, [rsp+0x10]
0000714ce89cfa3e  xor eax, r10d
0000714ce89cfa41  mov [rsp+0x10], eax
0000714ce89cfa45  mov eax, eax
0000714ce89cfa47  mov [r15+0x78], rax
0000714ce89cfa4b  mov eax, [rsp+0x40]
0000714ce89cfa4f  lea r14d, [r8d+eax*1]
0000714ce89cfa54  mov eax, [rsp+0x10]
0000714ce89cfa58  lea r12d, [r14d+eax*1]
0000714ce89cfa5d  mov rax, [rsp+0x30]
0000714ce89cfa62  lea r14, [rax+0x40]
0000714ce89cfa66  mov [r13+r14*1], r12d
0000714ce89cfa6b  mov eax, [rsp+0x20]
0000714ce89cfa6f  mov eax, eax
0000714ce89cfa71  mov [r15+0x60], rax
0000714ce89cfa75  mov eax, [r15+0x108]
0000714ce89cfa7c  sahf
0000714ce89cfa7d  jnz 0x0000714CE89CFAAF
0000714ce89cfa7f  cmp dword ptr [r15+0x318], 0x00
0000714ce89cfa87  jz 0x0000714CE89CFF70
0000714ce89cfa8d  nop [rax+rax*1], ax
0000714ce89cfa96  nop [rax+rax*1], eax
0000714ce89cfa9e  mov eax, 0x41088C
0000714ce89cfaa3  mov [r15+0x100], rax
0000714ce89cfaaa  jmp 0x0000714CE87FE110
0000714ce89cfaaf  cmp dword ptr [r15+0x318], 0x00
0000714ce89cfab7  jz 0x0000714CE89CFDC0
0000714ce89cfabd  nop [rax+rax*1], ax
0000714ce89cfac6  nop [rax+rax*1], eax
0000714ce89cface  mov eax, 0x410844
0000714ce89cfad3  mov [r15+0x100], rax
0000714ce89cfada  jmp 0x0000714CE87FE110
0000714ce89cfadf  int3
0000714ce89cfae0  call 0x0000714CE880D860
0000714ce89cfae5  jmp 0x0000714CE89CF17A
0000714ce89cfaea  call 0x0000714CE88E2420
0000714ce89cfaef  jmp 0x0000714CE89CF193
0000714ce89cfaf4  call 0x0000714CE88E2420
0000714ce89cfaf9  jmp 0x0000714CE89CF1AC
0000714ce89cfafe  call 0x0000714CE88E2420
0000714ce89cfb03  jmp 0x0000714CE89CF1C5
0000714ce89cfb08  call 0x0000714CE88E2420
0000714ce89cfb0d  jmp 0x0000714CE89CF1DE
0000714ce89cfb12  call 0x0000714CE88E2420
0000714ce89cfb17  jmp 0x0000714CE89CF1EF
0000714ce89cfb1c  call 0x0000714CE88E2420
0000714ce89cfb21  jmp 0x0000714CE89CF200
0000714ce89cfb26  call 0x0000714CE88E2420
0000714ce89cfb2b  jmp 0x0000714CE89CF211
0000714ce89cfb30  call 0x0000714CE88E2420
0000714ce89cfb35  jmp 0x0000714CE89CF222
0000714ce89cfb3a  call 0x0000714CE88E2420
0000714ce89cfb3f  jmp 0x0000714CE89CF233
0000714ce89cfb44  call 0x0000714CE88E2420
0000714ce89cfb49  jmp 0x0000714CE89CF244
0000714ce89cfb4e  call 0x0000714CE88E2420
0000714ce89cfb53  jmp 0x0000714CE89CF255
0000714ce89cfb58  call 0x0000714CE88E2420
0000714ce89cfb5d  jmp 0x0000714CE89CF266
0000714ce89cfb62  call 0x0000714CE88E2420
0000714ce89cfb67  jmp 0x0000714CE89CF277
0000714ce89cfb6c  call 0x0000714CE88E2420
0000714ce89cfb71  jmp 0x0000714CE89CF288
0000714ce89cfb76  call 0x0000714CE88E2420
0000714ce89cfb7b  jmp 0x0000714CE89CF299
0000714ce89cfb80  call 0x0000714CE88E2420
0000714ce89cfb85  jmp 0x0000714CE89CF2AA
0000714ce89cfb8a  call 0x0000714CE88E2420
0000714ce89cfb8f  jmp 0x0000714CE89CF2BB
0000714ce89cfb94  call 0x0000714CE88E2420
0000714ce89cfb99  jmp 0x0000714CE89CF2CC
0000714ce89cfb9e  call 0x0000714CE88E2420
0000714ce89cfba3  jmp 0x0000714CE89CF2DD
0000714ce89cfba8  call 0x0000714CE88E2420
0000714ce89cfbad  jmp 0x0000714CE89CF2EE
0000714ce89cfbb2  call 0x0000714CE88E2420
0000714ce89cfbb7  jmp 0x0000714CE89CF2FF
0000714ce89cfbbc  call 0x0000714CE88E2420
0000714ce89cfbc1  jmp 0x0000714CE89CF310
0000714ce89cfbc6  call 0x0000714CE88E2420
0000714ce89cfbcb  jmp 0x0000714CE89CF321
0000714ce89cfbd0  call 0x0000714CE88E2420
0000714ce89cfbd5  jmp 0x0000714CE89CF332
0000714ce89cfbda  call 0x0000714CE88E2420
0000714ce89cfbdf  jmp 0x0000714CE89CF343
0000714ce89cfbe4  call 0x0000714CE88E2420
0000714ce89cfbe9  jmp 0x0000714CE89CF354
0000714ce89cfbee  call 0x0000714CE88E2420
0000714ce89cfbf3  jmp 0x0000714CE89CF365
0000714ce89cfbf8  call 0x0000714CE88E2420
0000714ce89cfbfd  jmp 0x0000714CE89CF376
0000714ce89cfc02  call 0x0000714CE88E2420
0000714ce89cfc07  jmp 0x0000714CE89CF387
0000714ce89cfc0c  call 0x0000714CE88E2420
0000714ce89cfc11  jmp 0x0000714CE89CF398
0000714ce89cfc16  call 0x0000714CE88E2420
0000714ce89cfc1b  jmp 0x0000714CE89CF3A9
0000714ce89cfc20  call 0x0000714CE88E2420
0000714ce89cfc25  jmp 0x0000714CE89CF3BA
0000714ce89cfc2a  call 0x0000714CE88E2420
0000714ce89cfc2f  jmp 0x0000714CE89CF3CB
0000714ce89cfc34  call 0x0000714CE88E2420
0000714ce89cfc39  jmp 0x0000714CE89CF3DC
0000714ce89cfc3e  call 0x0000714CE88E2420
0000714ce89cfc43  jmp 0x0000714CE89CF3ED
0000714ce89cfc48  call 0x0000714CE88E2420
0000714ce89cfc4d  jmp 0x0000714CE89CF3FE
0000714ce89cfc52  call 0x0000714CE88E2420
0000714ce89cfc57  jmp 0x0000714CE89CF40F
0000714ce89cfc5c  call 0x0000714CE88E2420
0000714ce89cfc61  jmp 0x0000714CE89CF420
0000714ce89cfc66  call 0x0000714CE88E2420
0000714ce89cfc6b  jmp 0x0000714CE89CF431
0000714ce89cfc70  call 0x0000714CE88E2420
0000714ce89cfc75  jmp 0x0000714CE89CF442
0000714ce89cfc7a  call 0x0000714CE88E2420
0000714ce89cfc7f  jmp 0x0000714CE89CF453
0000714ce89cfc84  call 0x0000714CE88E2420
0000714ce89cfc89  jmp 0x0000714CE89CF464
0000714ce89cfc8e  call 0x0000714CE88E2420
0000714ce89cfc93  jmp 0x0000714CE89CF475
0000714ce89cfc98  call 0x0000714CE88E2420
0000714ce89cfc9d  jmp 0x0000714CE89CF486
0000714ce89cfca2  call 0x0000714CE88E2420
0000714ce89cfca7  jmp 0x0000714CE89CF497
0000714ce89cfcac  call 0x0000714CE88E2420
0000714ce89cfcb1  jmp 0x0000714CE89CF4A8
0000714ce89cfcb6  call 0x0000714CE88E2420
0000714ce89cfcbb  jmp 0x0000714CE89CF4B9
0000714ce89cfcc0  call 0x0000714CE88E2420
0000714ce89cfcc5  jmp 0x0000714CE89CF4CA
0000714ce89cfcca  call 0x0000714CE88E2420
0000714ce89cfccf  jmp 0x0000714CE89CF4DB
0000714ce89cfcd4  call 0x0000714CE88E2420
0000714ce89cfcd9  jmp 0x0000714CE89CF4EC
0000714ce89cfcde  call 0x0000714CE88E2420
0000714ce89cfce3  jmp 0x0000714CE89CF4FD
0000714ce89cfce8  call 0x0000714CE88E2420
0000714ce89cfced  jmp 0x0000714CE89CF50E
0000714ce89cfcf2  call 0x0000714CE88E2420
0000714ce89cfcf7  jmp 0x0000714CE89CF51F
0000714ce89cfcfc  call 0x0000714CE88E2420
0000714ce89cfd01  jmp 0x0000714CE89CF530
0000714ce89cfd06  call 0x0000714CE88E2420
0000714ce89cfd0b  jmp 0x0000714CE89CF541
0000714ce89cfd10  call 0x0000714CE88E2420
0000714ce89cfd15  jmp 0x0000714CE89CF552
0000714ce89cfd1a  call 0x0000714CE88E2420
0000714ce89cfd1f  jmp 0x0000714CE89CF563
0000714ce89cfd24  call 0x0000714CE88E2420
0000714ce89cfd29  jmp 0x0000714CE89CF574
0000714ce89cfd2e  call 0x0000714CE88E2420
0000714ce89cfd33  jmp 0x0000714CE89CF585
0000714ce89cfd38  call 0x0000714CE88E2420
0000714ce89cfd3d  jmp 0x0000714CE89CF596
0000714ce89cfd42  call 0x0000714CE88E2420
0000714ce89cfd47  jmp 0x0000714CE89CF5AF
0000714ce89cfd4c  call 0x0000714CE88E2420
0000714ce89cfd51  jmp 0x0000714CE89CF5C8
0000714ce89cfd56  call 0x0000714CE88D5610
0000714ce89cfd5b  jmp 0x0000714CE89CF5E1
0000714ce89cfd60  call 0x0000714CE88DC580
0000714ce89cfd65  jmp 0x0000714CE89CF94E
0000714ce89cfd6a  call 0x0000714CE88E46C0
0000714ce89cfd6f  jmp 0x0000714CE89CF958
0000714ce89cfd74  call 0x0000714CE8809E90
0000714ce89cfd79  jmp 0x0000714CE89CF95E
0000714ce89cfd7e  call 0x0000714CE88DB310
0000714ce89cfd83  jmp 0x0000714CE89CF968
0000714ce89cfd88  call 0x0000714CE880DAE0
0000714ce89cfd8d  jmp 0x0000714CE89CF96D
0000714ce89cfd92  call 0x0000714CE88C0230
0000714ce89cfd97  jmp 0x0000714CE89CF986
0000714ce89cfd9c  call 0x0000714CE88C0230
0000714ce89cfda1  jmp 0x0000714CE89CF99B
0000714ce89cfda6  call 0x0000714CE88BEFC0
0000714ce89cfdab  jmp 0x0000714CE89CF9A4
0000714ce89cfdb0  call 0x0000714CE88E2BA0
0000714ce89cfdb5  jmp 0x0000714CE89CFA6B
0000714ce89cfdba  int3
0000714ce89cfdbb  nop [rax+rax*1], eax
0000714ce89cfdc0  mov rax, [r15+0x48]
0000714ce89cfdc4  mov r14, [r15+0x58]
0000714ce89cfdc8  lea r12, [rax+r14*1]
0000714ce89cfdcc  mov [r15+0x68], r12
0000714ce89cfdd0  lea rax, [r14+0x04]
0000714ce89cfdd4  mov [r15+0x58], rax
0000714ce89cfdd8  lea r14, [r12+0x04]
0000714ce89cfddd  mov r11d, [r13+r14*1]
0000714ce89cfde2  mov [rsp+0x10], r11d
0000714ce89cfde7  mov r11d, r11d
0000714ce89cfdea  mov [r15+0x70], r11
0000714ce89cfdee  lea r14, [r12+0x38]
0000714ce89cfdf3  mov r11d, [r13+r14*1]
0000714ce89cfdf8  lea r14, [r12+0x24]
0000714ce89cfdfd  mov r10d, [r13+r14*1]
0000714ce89cfe02  mov [rsp+0x20], r10d
0000714ce89cfe07  mov r10d, r10d
0000714ce89cfe0a  mov [r15+0x90], r10
0000714ce89cfe11  mov [rsp+0x30], rax
0000714ce89cfe16  xor eax, eax
0000714ce89cfe18  mov r14, [rsp+0x30]
0000714ce89cfe1d  mov r10d, 0xC0
0000714ce89cfe23  cmp r14, r10
0000714ce89cfe26  cmc
0000714ce89cfe27  lahf
0000714ce89cfe28  seto al
0000714ce89cfe2b  mov [r15+0x108], eax
0000714ce89cfe32  mov eax, [rsp+0x10]
0000714ce89cfe36  mov r14d, [rsp+0x10]
0000714ce89cfe3b  shrd eax, r14d, 0x07
0000714ce89cfe40  mov [rsp+0x10], r11d
0000714ce89cfe45  mov r10d, [rsp+0x10]
0000714ce89cfe4a  shrd r11d, r10d, 0x11
0000714ce89cfe4f  mov r9d, [r15+0x60]
0000714ce89cfe53  mov r8d, [rsp+0x20]
0000714ce89cfe58  lea ebp, [r8d+r9d*1]
0000714ce89cfe5d  rorx r9d, r14d, 0x12
0000714ce89cfe63  xor eax, r9d
0000714ce89cfe66  rorx r9d, r10d, 0x13
0000714ce89cfe6c  xor r11d, r9d
0000714ce89cfe6f  mov [rsp+0x10], r11d
0000714ce89cfe74  mov r11d, r11d
0000714ce89cfe77  mov [r15+0x88], r11
0000714ce89cfe7e  mov [rsp+0x20], r14d
0000714ce89cfe83  shr r14d, 0x03
0000714ce89cfe87  xor eax, r14d
0000714ce89cfe8a  mov [rsp+0x30], eax
0000714ce89cfe8e  mov eax, eax
0000714ce89cfe90  mov [r15+0x80], rax
0000714ce89cfe97  shr r10d, 0x0A
0000714ce89cfe9b  mov eax, [rsp+0x10]
0000714ce89cfe9f  xor eax, r10d
0000714ce89cfea2  mov [rsp+0x10], eax
0000714ce89cfea6  mov eax, eax
0000714ce89cfea8  mov [r15+0x78], rax
0000714ce89cfeac  mov eax, [rsp+0x30]
0000714ce89cfeb0  lea r14d, [ebp+eax*1]
0000714ce89cfeb6  mov eax, [rsp+0x10]
0000714ce89cfeba  lea r11d, [r14d+eax*1]
0000714ce89cfebf  lea rax, [r12+0x40]
0000714ce89cfec4  mov [r13+rax*1], r11d
0000714ce89cfec9  mov eax, [rsp+0x20]
0000714ce89cfecd  mov eax, eax
0000714ce89cfecf  mov [r15+0x60], rax
0000714ce89cfed3  mov eax, [r15+0x108]
0000714ce89cfeda  sahf
0000714ce89cfedb  jnz 0x0000714CE89CFF0D
0000714ce89cfedd  cmp dword ptr [r15+0x318], 0x00
0000714ce89cfee5  jz 0x0000714CE89CFF70
0000714ce89cfeeb  nop [rax+rax*1], ax
0000714ce89cfef4  nop [rax+rax*1], eax
0000714ce89cfefc  mov eax, 0x41088C
0000714ce89cff01  mov [r15+0x100], rax
0000714ce89cff08  jmp 0x0000714CE87FE110
0000714ce89cff0d  cmp dword ptr [r15+0x318], 0x00
0000714ce89cff15  jz 0x0000714CE89CFDC0
0000714ce89cff1b  nop [rax+rax*1], ax
0000714ce89cff24  nop [rax+rax*1], eax
0000714ce89cff2c  mov eax, 0x410844
0000714ce89cff31  mov [r15+0x100], rax
0000714ce89cff38  jmp 0x0000714CE87FE110
0000714ce89cff3d  int3
0000714ce89cff3e  call 0x0000714CE88E1430
0000714ce89cff43  jmp 0x0000714CE89CFDE2
0000714ce89cff48  call 0x0000714CE88E1430
0000714ce89cff4d  jmp 0x0000714CE89CFDF8
0000714ce89cff52  call 0x0000714CE88E01C0
0000714ce89cff57  jmp 0x0000714CE89CFE02
0000714ce89cff5c  call 0x0000714CE880A860
0000714ce89cff61  jmp 0x0000714CE89CFEC9
0000714ce89cff66  int3
0000714ce89cff67  nop [rax+rax*1], ax
0000714ce89cff70  mov rax, [r15]
0000714ce89cff73  mov r14d, [r13+rax*1]
0000714ce89cff78  lea r12, [rax+0x04]
0000714ce89cff7c  mov r11d, [r13+r12*1]
0000714ce89cff81  mov [rsp+0x10], r14d
0000714ce89cff86  mov r14d, r14d
0000714ce89cff89  mov [r15+0x78], r14
0000714ce89cff8d  mov [rsp+0x20], r11d
0000714ce89cff92  mov r11d, r11d
0000714ce89cff95  mov [r15+0x80], r11
0000714ce89cff9c  lea r14, [rax+0x08]
0000714ce89cffa0  mov r12d, [r13+r14*1]
0000714ce89cffa5  lea r14, [rax+0x0C]
0000714ce89cffa9  mov r11d, [r13+r14*1]
0000714ce89cffae  mov [rsp+0x30], r12d
0000714ce89cffb3  mov r12d, r12d
0000714ce89cffb6  mov [r15+0x70], r12
0000714ce89cffba  mov [rsp+0x40], r11d
0000714ce89cffbf  mov r11d, r11d
0000714ce89cffc2  mov [r15+0x68], r11
0000714ce89cffc6  lea r14, [rax+0x18]
0000714ce89cffca  mov r12d, [r13+r14*1]
0000714ce89cffcf  lea r14, [rax+0x1C]
0000714ce89cffd3  mov r11d, [r13+r14*1]
0000714ce89cffd8  mov [rsp+0x50], r12d
0000714ce89cffdd  mov r12d, r12d
0000714ce89cffe0  mov [r15+0x58], r12
0000714ce89cffe4  mov [rsp+0x60], r11d
0000714ce89cffe9  mov r11d, r11d
0000714ce89cffec  mov [r15+0x60], r11
0000714ce89cfff0  lea r14, [rax+0x10]
0000714ce89cfff4  mov r12d, [r13+r14*1]
0000714ce89cfff9  lea r14, [rax+0x14]
0000714ce89cfffd  mov eax, [r13+r14*1]
0000714ce89d0002  mov [rsp+0x70], r12d
0000714ce89d0007  mov r12d, r12d
0000714ce89d000a  mov [r15+0x18], r12
0000714ce89d000e  mov [rsp+0x80], eax
0000714ce89d0015  mov eax, eax
0000714ce89d0017  mov [r15+0x90], rax
0000714ce89d001e  mov eax, [rsp+0x70]
0000714ce89d0022  mov eax, eax
0000714ce89d0024  mov [r15+0x30], rax
0000714ce89d0028  mov eax, [rsp+0x50]
0000714ce89d002c  mov eax, eax
0000714ce89d002e  mov [r15+0xA0], rax
0000714ce89d0035  mov eax, [rsp+0x30]
0000714ce89d0039  mov eax, eax
0000714ce89d003b  mov [r15+0x28], rax
0000714ce89d003f  mov eax, [rsp+0x20]
0000714ce89d0043  mov eax, eax
0000714ce89d0045  mov [r15+0x98], rax
0000714ce89d004c  mov eax, [rsp+0x10]
0000714ce89d0050  mov eax, eax
0000714ce89d0052  mov [r15+0x38], rax
0000714ce89d0056  mov eax, [rsp+0x70]
0000714ce89d005a  mov r14d, [rsp+0x70]
0000714ce89d005f  shrd eax, r14d, 0x06
0000714ce89d0064  mov [rsp+0x70], r14d
0000714ce89d0069  mov r12d, [rsp+0x80]
0000714ce89d0071  and r14d, r12d
0000714ce89d0074  mov r11d, [rsp+0x10]
0000714ce89d0079  mov r10d, [rsp+0x10]
0000714ce89d007e  shrd r11d, r10d, 0x02
0000714ce89d0083  mov [rsp+0x10], r12d
0000714ce89d0088  mov r12d, r12d
0000714ce89d008b  mov [r15+0x20], r12
0000714ce89d008f  mov r12, [r15+0x50]
0000714ce89d0093  mov r9d, [r13+r12*1]
0000714ce89d0098  mov r12d, [rsp+0x50]
0000714ce89d009d  mov r8d, [rsp+0x70]
0000714ce89d00a2  andn ebp, r8d, r12d
0000714ce89d00a7  mov edi, [rsp+0x60]
0000714ce89d00ab  lea esi, [r14d+edi*1]
0000714ce89d00b0  rorx r14d, r8d, 0x0B
0000714ce89d00b6  xor eax, r14d
0000714ce89d00b9  rorx r14d, r10d, 0x0D
0000714ce89d00bf  xor r11d, r14d
0000714ce89d00c2  lea edi, [esi+ebp*1]
0000714ce89d00c6  mov r14, [r15+0x48]
0000714ce89d00ca  mov ebp, [r13+r14*1]
0000714ce89d00cf  mov r14d, [rsp+0x30]
0000714ce89d00d4  mov esi, [rsp+0x20]
0000714ce89d00d8  and r14d, esi
0000714ce89d00db  mov [rsp+0x20], r14d
0000714ce89d00e0  mov r14d, r14d
0000714ce89d00e3  mov [r15+0xD8], r14
0000714ce89d00ea  lea r14d, [edi+r9d*1]
0000714ce89d00ef  mov r9d, [rsp+0x30]
0000714ce89d00f4  xor r9d, esi
0000714ce89d00f7  rorx edi, r8d, 0x19
0000714ce89d00fd  xor eax, edi
0000714ce89d00ff  and r9d, r10d
0000714ce89d0102  rorx edi, r10d, 0x16
0000714ce89d0108  xor r11d, edi
0000714ce89d010b  mov [rsp+0x30], r11d
0000714ce89d0110  mov r11d, r11d
0000714ce89d0113  mov [r15+0xD0], r11
0000714ce89d011a  lea r11d, [r14d+ebp*1]
0000714ce89d011f  mov r10d, [rsp+0x20]
0000714ce89d0124  xor r9d, r10d
0000714ce89d0127  lea r14d, [r11d+eax*1]
0000714ce89d012c  mov qword ptr [r15+0x88], 0x04
0000714ce89d0137  mov eax, [rsp+0x30]
0000714ce89d013b  lea r11d, [r9d+eax*1]
0000714ce89d0140  mov eax, [rsp+0x40]
0000714ce89d0144  lea r10d, [r14d+eax*1]
0000714ce89d0149  mov r10d, r10d
0000714ce89d014c  mov [r15+0xB8], r10
0000714ce89d0153  xor eax, eax
0000714ce89d0155  mov r10d, 0x04
0000714ce89d015b  mov r9d, 0x100
0000714ce89d0161  cmp r10, r9
0000714ce89d0164  cmc
0000714ce89d0165  lahf
0000714ce89d0166  seto al
0000714ce89d0169  mov [r15+0x108], eax
0000714ce89d0170  lea eax, [r11d+r14d*1]
0000714ce89d0175  mov eax, eax
0000714ce89d0177  mov [r15+0xA8], rax
0000714ce89d017e  mov r12d, r12d
0000714ce89d0181  mov [r15+0xB0], r12
0000714ce89d0188  mov eax, [rsp+0x10]
0000714ce89d018c  mov eax, eax
0000714ce89d018e  mov [r15+0xC0], rax
0000714ce89d0195  mov r8d, r8d
0000714ce89d0198  mov [r15+0xC8], r8
0000714ce89d019f  mov eax, [r15+0x108]
0000714ce89d01a6  sahf
0000714ce89d01a7  jnz 0x0000714CE89D01D9
0000714ce89d01a9  cmp dword ptr [r15+0x318], 0x00
0000714ce89d01b1  jz 0x0000714CE89D04A0
0000714ce89d01b7  nop [rax+rax*1], ax
0000714ce89d01c0  nop [rax+rax*1], eax
0000714ce89d01c8  mov eax, 0x41094C
0000714ce89d01cd  mov [r15+0x100], rax
0000714ce89d01d4  jmp 0x0000714CE87FE110
0000714ce89d01d9  cmp dword ptr [r15+0x318], 0x00
0000714ce89d01e1  jz 0x0000714CE89D0270
0000714ce89d01e7  nop [rax+rax*1], ax
0000714ce89d01f0  nop [rax+rax*1], eax
0000714ce89d01f8  mov eax, 0x4108C0
0000714ce89d01fd  mov [r15+0x100], rax
0000714ce89d0204  jmp 0x0000714CE87FE110
0000714ce89d0209  int3
0000714ce89d020a  call 0x0000714CE880DAE0
0000714ce89d020f  jmp 0x0000714CE89CFF78
0000714ce89d0214  call 0x0000714CE88C0230
0000714ce89d0219  jmp 0x0000714CE89CFF81
0000714ce89d021e  call 0x0000714CE88E26A0
0000714ce89d0223  jmp 0x0000714CE89CFFA5
0000714ce89d0228  call 0x0000714CE88E1430
0000714ce89d022d  jmp 0x0000714CE89CFFAE
0000714ce89d0232  call 0x0000714CE88E26A0
0000714ce89d0237  jmp 0x0000714CE89CFFCF
0000714ce89d023c  call 0x0000714CE88E1430
0000714ce89d0241  jmp 0x0000714CE89CFFD8
0000714ce89d0246  call 0x0000714CE88E26A0
0000714ce89d024b  jmp 0x0000714CE89CFFF9
0000714ce89d0250  call 0x0000714CE88D5890
0000714ce89d0255  jmp 0x0000714CE89D0002
0000714ce89d025a  call 0x0000714CE88BDD50
0000714ce89d025f  jmp 0x0000714CE89D0098
0000714ce89d0264  call 0x0000714CE88DA580
0000714ce89d0269  jmp 0x0000714CE89D00CF
0000714ce89d026e  int3
0000714ce89d026f  nop
0000714ce89d0270  mov eax, [r15+0xB8]
0000714ce89d0277  mov [rsp+0x10], eax
0000714ce89d027b  mov eax, eax
0000714ce89d027d  mov [r15+0x30], rax
0000714ce89d0281  mov eax, [r15+0xC0]
0000714ce89d0288  mov [rsp+0x20], eax
0000714ce89d028c  mov eax, eax
0000714ce89d028e  mov [r15+0xA0], rax
0000714ce89d0295  mov eax, [r15+0x28]
0000714ce89d0299  mov r14d, [r15+0x98]
0000714ce89d02a0  mov [rsp+0x30], r14d
0000714ce89d02a5  mov r14d, r14d
0000714ce89d02a8  mov [r15+0x28], r14
0000714ce89d02ac  mov r14d, [r15+0x38]
0000714ce89d02b0  mov [rsp+0x40], r14d
0000714ce89d02b5  mov r14d, r14d
0000714ce89d02b8  mov [r15+0x98], r14
0000714ce89d02bf  mov r14d, [r15+0xA8]
0000714ce89d02c6  mov [rsp+0x50], r14d
0000714ce89d02cb  mov r14d, r14d
0000714ce89d02ce  mov [r15+0x38], r14
0000714ce89d02d2  mov r14d, [rsp+0x10]
0000714ce89d02d7  mov r12d, [rsp+0x10]
0000714ce89d02dc  shrd r14d, r12d, 0x06
0000714ce89d02e1  mov r11d, [r15+0xC8]
0000714ce89d02e8  mov [rsp+0x10], r12d
0000714ce89d02ed  and r12d, r11d
0000714ce89d02f0  mov r10d, [rsp+0x50]
0000714ce89d02f5  mov r9d, [rsp+0x50]
0000714ce89d02fa  shrd r10d, r9d, 0x02
0000714ce89d02ff  mov [rsp+0x50], r11d
0000714ce89d0304  mov r11d, r11d
0000714ce89d0307  mov [r15+0x20], r11
0000714ce89d030b  mov r11, [r15+0x88]
0000714ce89d0312  mov r8, [r15+0x50]
0000714ce89d0316  lea rbp, [r8+r11*1]
0000714ce89d031a  mov r8d, [r13+rbp*1]
0000714ce89d031f  mov ebp, [rsp+0x20]
0000714ce89d0323  mov edi, [rsp+0x10]
0000714ce89d0327  andn esi, edi, ebp
0000714ce89d032c  mov edx, [r15+0xB0]
0000714ce89d0333  lea ecx, [r12d+edx*1]
0000714ce89d0338  rorx r12d, edi, 0x0B
0000714ce89d033e  xor r14d, r12d
0000714ce89d0341  rorx r12d, r9d, 0x0D
0000714ce89d0347  xor r10d, r12d
0000714ce89d034a  lea r12d, [ecx+esi*1]
0000714ce89d034f  mov rsi, [r15+0x48]
0000714ce89d0353  lea rdx, [rsi+r11*1]
0000714ce89d0357  mov esi, [r13+rdx*1]
0000714ce89d035c  mov edx, [rsp+0x30]
0000714ce89d0360  mov ecx, [rsp+0x40]
0000714ce89d0364  and edx, ecx
0000714ce89d0366  mov [rsp+0x10], edx
0000714ce89d036a  mov edx, edx
0000714ce89d036c  mov [r15+0xD8], rdx
0000714ce89d0373  lea edx, [r12d+r8d*1]
0000714ce89d0378  mov r12d, [rsp+0x30]
0000714ce89d037d  xor r12d, ecx
0000714ce89d0380  rorx r8d, edi, 0x19
0000714ce89d0386  xor r14d, r8d
0000714ce89d0389  and r12d, r9d
0000714ce89d038c  rorx r8d, r9d, 0x16
0000714ce89d0392  xor r10d, r8d
0000714ce89d0395  mov [rsp+0x20], r10d
0000714ce89d039a  mov r10d, r10d
0000714ce89d039d  mov [r15+0xD0], r10
0000714ce89d03a4  lea r10d, [edx+esi*1]
0000714ce89d03a9  mov r9d, [rsp+0x10]
0000714ce89d03ae  xor r12d, r9d
0000714ce89d03b1  lea r9d, [r10d+r14d*1]
0000714ce89d03b6  lea r14, [r11+0x04]
0000714ce89d03ba  mov [r15+0x88], r14
0000714ce89d03c1  mov r11d, [rsp+0x20]
0000714ce89d03c6  lea r10d, [r12d+r11d*1]
0000714ce89d03cb  lea r11d, [r9d+eax*1]
0000714ce89d03d0  mov r11d, r11d
0000714ce89d03d3  mov [r15+0xB8], r11
0000714ce89d03da  xor eax, eax
0000714ce89d03dc  mov r12d, 0x100
0000714ce89d03e2  cmp r14, r12
0000714ce89d03e5  cmc
0000714ce89d03e6  lahf
0000714ce89d03e7  seto al
0000714ce89d03ea  mov [r15+0x108], eax
0000714ce89d03f1  lea eax, [r10d+r9d*1]
0000714ce89d03f6  mov eax, eax
0000714ce89d03f8  mov [r15+0xA8], rax
0000714ce89d03ff  mov ebp, ebp
0000714ce89d0401  mov [r15+0xB0], rbp
0000714ce89d0408  mov eax, [rsp+0x50]
0000714ce89d040c  mov eax, eax
0000714ce89d040e  mov [r15+0xC0], rax
0000714ce89d0415  mov edi, edi
0000714ce89d0417  mov [r15+0xC8], rdi
0000714ce89d041e  mov eax, [r15+0x108]
0000714ce89d0425  sahf
0000714ce89d0426  jnz 0x0000714CE89D0458
0000714ce89d0428  cmp dword ptr [r15+0x318], 0x00
0000714ce89d0430  jz 0x0000714CE89D04A0
0000714ce89d0436  nop [rax+rax*1], ax
0000714ce89d043f  nop [rax+rax*1], eax
0000714ce89d0447  mov eax, 0x41094C
0000714ce89d044c  mov [r15+0x100], rax
0000714ce89d0453  jmp 0x0000714CE87FE110
0000714ce89d0458  cmp dword ptr [r15+0x318], 0x00
0000714ce89d0460  jz 0x0000714CE89D0270
0000714ce89d0466  nop [rax+rax*1], ax
0000714ce89d046f  nop [rax+rax*1], eax
0000714ce89d0477  mov eax, 0x4108C0
0000714ce89d047c  mov [r15+0x100], rax
0000714ce89d0483  jmp 0x0000714CE87FE110
0000714ce89d0488  int3
0000714ce89d0489  call 0x0000714CE8849010
0000714ce89d048e  jmp 0x0000714CE89D031F
0000714ce89d0493  call 0x0000714CE8825930
0000714ce89d0498  jmp 0x0000714CE89D035C
0000714ce89d049d  int3
0000714ce89d049e  nop
0000714ce89d04a0  mov eax, [r15+0x98]
0000714ce89d04a7  mov r14d, [r15+0x70]
0000714ce89d04ab  lea r12d, [eax+r14d*1]
0000714ce89d04b0  mov eax, [r15+0x28]
0000714ce89d04b4  mov r14d, [r15+0x68]
0000714ce89d04b8  lea r11d, [eax+r14d*1]
0000714ce89d04bd  mov qword ptr [r15+0x88], 0x00
0000714ce89d04c8  mov eax, [r15+0xA8]
0000714ce89d04cf  mov r14d, [r15+0x78]
0000714ce89d04d3  lea r10d, [eax+r14d*1]
0000714ce89d04d8  mov [rsp+0x10], r10d
0000714ce89d04dd  mov r10d, r10d
0000714ce89d04e0  mov [r15+0x78], r10
0000714ce89d04e4  mov eax, [r15+0x38]
0000714ce89d04e8  mov r14d, [r15+0x80]
0000714ce89d04ef  lea r10d, [eax+r14d*1]
0000714ce89d04f4  mov [rsp+0x20], r10d
0000714ce89d04f9  mov r10d, r10d
0000714ce89d04fc  mov [r15+0x80], r10
0000714ce89d0503  mov rax, [r15]
0000714ce89d0506  lea r14, [rax+0x08]
0000714ce89d050a  mov [r13+r14*1], r12d
0000714ce89d050f  lea r14, [rax+0x0C]
0000714ce89d0513  mov [r13+r14*1], r11d
0000714ce89d0518  mov r14d, [r15+0xB8]
0000714ce89d051f  mov r12d, [r15+0x18]
0000714ce89d0523  lea r11d, [r14d+r12d*1]
0000714ce89d0528  mov [rsp+0x30], r11d
0000714ce89d052d  mov r11d, r11d
0000714ce89d0530  mov [r15+0x68], r11
0000714ce89d0534  mov r14d, [r15+0x30]
0000714ce89d0538  mov r12d, [r15+0x90]
0000714ce89d053f  lea r11d, [r14d+r12d*1]
0000714ce89d0544  mov [rsp+0x40], r11d
0000714ce89d0549  mov r11d, r11d
0000714ce89d054c  mov [r15+0x70], r11
0000714ce89d0550  mov r14d, [r15+0x20]
0000714ce89d0554  mov r12d, [r15+0x58]
0000714ce89d0558  lea r11d, [r14d+r12d*1]
0000714ce89d055d  mov [rsp+0x50], r11d
0000714ce89d0562  mov r11d, r11d
0000714ce89d0565  mov [r15+0x58], r11
0000714ce89d0569  mov r14d, [r15+0xA0]
0000714ce89d0570  mov r12d, [r15+0x60]
0000714ce89d0574  lea r11d, [r14d+r12d*1]
0000714ce89d0579  mov [rsp+0x60], r11d
0000714ce89d057e  mov r11d, r11d
0000714ce89d0581  mov [r15+0x60], r11
0000714ce89d0585  mov r14d, [rsp+0x10]
0000714ce89d058a  mov [r13+rax*1], r14d
0000714ce89d058f  lea r14, [rax+0x04]
0000714ce89d0593  mov r12d, [rsp+0x20]
0000714ce89d0598  mov [r13+r14*1], r12d
0000714ce89d059d  lea r14, [rax+0x10]
0000714ce89d05a1  mov r12d, [rsp+0x30]
0000714ce89d05a6  mov [r13+r14*1], r12d
0000714ce89d05ab  lea r14, [rax+0x14]
0000714ce89d05af  mov r12d, [rsp+0x40]
0000714ce89d05b4  mov [r13+r14*1], r12d
0000714ce89d05b9  lea r14, [rax+0x18]
0000714ce89d05bd  mov r12d, [rsp+0x50]
0000714ce89d05c2  mov [r13+r14*1], r12d
0000714ce89d05c7  lea r14, [rax+0x1C]
0000714ce89d05cb  mov r12d, [rsp+0x60]
0000714ce89d05d0  mov [r13+r14*1], r12d
0000714ce89d05d5  lea r14, [rax+0x68]
0000714ce89d05d9  xor eax, eax
0000714ce89d05db  mov [r13+r14*1], rax
0000714ce89d05e0  cmp dword ptr [r15+0x318], 0x00
0000714ce89d05e8  jz 0x0000714CE89CF0E0
0000714ce89d05ee  nop [rax+rax*1], ax
0000714ce89d05f7  nop [rax+rax*1], eax
0000714ce89d05ff  mov eax, 0x410768
0000714ce89d0604  mov [r15+0x100], rax
0000714ce89d060b  jmp 0x0000714CE87FE110
0000714ce89d0610  int3
0000714ce89d0611  call 0x0000714CE88E2BA0
0000714ce89d0616  jmp 0x0000714CE89D050F
0000714ce89d061b  call 0x0000714CE88E1920
0000714ce89d0620  jmp 0x0000714CE89D0518
0000714ce89d0625  call 0x0000714CE880DFE0
0000714ce89d062a  jmp 0x0000714CE89D058F
0000714ce89d062f  call 0x0000714CE88E2BA0
0000714ce89d0634  jmp 0x0000714CE89D059D
0000714ce89d0639  call 0x0000714CE88E2BA0
0000714ce89d063e  jmp 0x0000714CE89D05AB
0000714ce89d0643  call 0x0000714CE88E2BA0
0000714ce89d0648  jmp 0x0000714CE89D05B9
0000714ce89d064d  call 0x0000714CE88E2BA0
0000714ce89d0652  jmp 0x0000714CE89D05C7
0000714ce89d0657  call 0x0000714CE88E2BA0
0000714ce89d065c  jmp 0x0000714CE89D05D5
0000714ce89d0661  call 0x0000714CE88D5EB0
0000714ce89d0666  jmp 0x0000714CE89D05E0
0000714ce89d066b  int3
0000714ce89d066c  nop [rax], eax
0000714ce89d0670  mov rax, [r15+0xF8]
0000714ce89d0677  lea r14, [rax+0x140]
0000714ce89d067e  mov r12, [r13+r14*1]
0000714ce89d0683  lea r14, [rax+0x148]
0000714ce89d068a  mov r11, [r13+r14*1]
0000714ce89d068f  mov [r15+0xA0], r12
0000714ce89d0696  mov [r15+0x98], r11
0000714ce89d069d  lea r14, [rax+0x130]
0000714ce89d06a4  mov r12, [r13+r14*1]
0000714ce89d06a9  lea r14, [rax+0x138]
0000714ce89d06b0  mov r11, [r13+r14*1]
0000714ce89d06b5  mov [r15+0xB0], r12
0000714ce89d06bc  mov [r15+0xA8], r11
0000714ce89d06c3  lea r14, [rax+0x120]
0000714ce89d06ca  mov r12, [r13+r14*1]
0000714ce89d06cf  lea r14, [rax+0x128]
0000714ce89d06d6  mov r11, [r13+r14*1]
0000714ce89d06db  mov [r15+0xC0], r12
0000714ce89d06e2  mov [r15+0xB8], r11
0000714ce89d06e9  lea r14, [rax+0x110]
0000714ce89d06f0  mov r12, [r13+r14*1]
0000714ce89d06f5  lea r14, [rax+0x118]
0000714ce89d06fc  mov r11, [r13+r14*1]
0000714ce89d0701  mov [r15+0xD0], r12
0000714ce89d0708  mov [r15+0xC8], r11
0000714ce89d070f  lea r14, [rax+0x100]
0000714ce89d0716  mov r12, [r13+r14*1]
0000714ce89d071b  lea r14, [rax+0x108]
0000714ce89d0722  mov r11, [r13+r14*1]
0000714ce89d0727  mov [r15+0xE8], r12
0000714ce89d072e  mov [r15+0xD8], r11
0000714ce89d0735  lea r14, [rax+0x150]
0000714ce89d073c  mov [r15+0xF8], r14
0000714ce89d0743  mov rax, [r15+0xF0]
0000714ce89d074a  mov [r15+0x100], rax
0000714ce89d0751  jmp 0x0000714CE89CE5C0
0000714ce89d0756  int3
0000714ce89d0757  call 0x0000714CE88E27E0
0000714ce89d075c  jmp 0x0000714CE89D0683
0000714ce89d0761  call 0x0000714CE88E1570
0000714ce89d0766  jmp 0x0000714CE89D068F
0000714ce89d076b  call 0x0000714CE88E27E0
0000714ce89d0770  jmp 0x0000714CE89D06A9
0000714ce89d0775  call 0x0000714CE88E1570
0000714ce89d077a  jmp 0x0000714CE89D06B5
0000714ce89d077f  call 0x0000714CE88E27E0
0000714ce89d0784  jmp 0x0000714CE89D06CF
0000714ce89d0789  call 0x0000714CE88E1570
0000714ce89d078e  jmp 0x0000714CE89D06DB
0000714ce89d0793  call 0x0000714CE88E27E0
0000714ce89d0798  jmp 0x0000714CE89D06F5
0000714ce89d079d  call 0x0000714CE88E1570
0000714ce89d07a2  jmp 0x0000714CE89D0701
0000714ce89d07a7  call 0x0000714CE88E27E0
0000714ce89d07ac  jmp 0x0000714CE89D071B
0000714ce89d07b1  call 0x0000714CE88E1570
0000714ce89d07b6  jmp 0x0000714CE89D0727
0000714ce89d07bb  int3
0000714ce89d07bc  nop [rax], eax
0000714ce89d07c0  mov eax, [r15+0xA0]
0000714ce89d07c7  mov [rsp+0x10], eax
0000714ce89d07cb  xor eax, eax
0000714ce89d07cd  mov r14d, [rsp+0x10]
0000714ce89d07d2  sub r14d, 0x01
0000714ce89d07d6  cmc
0000714ce89d07d7  lahf
0000714ce89d07d8  seto al
0000714ce89d07db  mov [r15+0x108], eax
0000714ce89d07e2  mov r14d, r14d
0000714ce89d07e5  mov [r15+0xA0], r14
0000714ce89d07ec  mov eax, [r15+0x108]
0000714ce89d07f3  sahf
0000714ce89d07f4  jnz 0x0000714CE89D0826
0000714ce89d07f6  cmp dword ptr [r15+0x318], 0x00
0000714ce89d07fe  jz 0x0000714CE89D0900
0000714ce89d0804  nop [rax+rax*1], ax
0000714ce89d080d  nop [rax+rax*1], eax
0000714ce89d0815  mov eax, 0x41028C
0000714ce89d081a  mov [r15+0x100], rax
0000714ce89d0821  jmp 0x0000714CE87FE110
0000714ce89d0826  cmp dword ptr [r15+0x318], 0x00
0000714ce89d082e  jz 0x0000714CE89D0860
0000714ce89d0834  nop [rax+rax*1], ax
0000714ce89d083d  nop [rax+rax*1], eax
0000714ce89d0845  mov eax, 0x410274
0000714ce89d084a  mov [r15+0x100], rax
0000714ce89d0851  jmp 0x0000714CE87FE110
0000714ce89d0856  int3
0000714ce89d0857  int3
0000714ce89d0858  nop [rax+rax*1], eax
0000714ce89d0860  mov rax, [r15+0xF8]
0000714ce89d0867  lea r14, [rax+0x100]
0000714ce89d086e  mov [r15], r14
0000714ce89d0871  mov rax, [r15+0x98]
0000714ce89d0878  mov [r15+0x08], rax
0000714ce89d087c  mov qword ptr [r15+0x10], 0x12C
0000714ce89d0884  mov qword ptr [r15+0xF0], 0x410284
0000714ce89d088f  mov r14d, [r15+0x320]
0000714ce89d0896  mov eax, 0x410284
0000714ce89d089b  mov rcx, 0x714CE89D07C0
0000714ce89d08a5  mov [r15+r14*8+0x328], rax
0000714ce89d08ad  mov [r15+r14*8+0x368], rcx
0000714ce89d08b5  add r14d, 0x01
0000714ce89d08b9  and r14d, 0x07
0000714ce89d08bd  mov [r15+0x320], r14d
0000714ce89d08c4  cmp dword ptr [r15+0x318], 0x00
0000714ce89d08cc  jz 0x0000714CE89CED70
0000714ce89d08d2  nop [rax+rax*1], ax
0000714ce89d08db  nop [rax+rax*1], eax
0000714ce89d08e3  mov eax, 0x410728
0000714ce89d08e8  mov [r15+0x100], rax
0000714ce89d08ef  jmp 0x0000714CE87FE110
0000714ce89d08f4  int3
0000714ce89d08f5  int3
0000714ce89d08f6  nop [rax+rax*1], ax
0000714ce89d08ff  nop
0000714ce89d0900  mov rax, [r15+0xF8]
0000714ce89d0907  lea r14, [rax+0x120]
0000714ce89d090e  mov r12, [r13+r14*1]
0000714ce89d0913  mov [r15+0x98], r12
0000714ce89d091a  mov qword ptr [r15+0x40], 0x80
0000714ce89d0922  lea r14, [rax+0x100]
0000714ce89d0929  mov [r15], r14
0000714ce89d092c  lea r14, [rax+0x17C]
0000714ce89d0933  mov [r15+0x08], r14
0000714ce89d0937  mov qword ptr [r15+0x10], 0x01
0000714ce89d093f  lea r14, [rax+0x17C]
0000714ce89d0946  mov eax, 0x80
0000714ce89d094b  mov [r13+r14*1], al
0000714ce89d0950  mov qword ptr [r15+0xF0], 0x4102A8
0000714ce89d095b  mov r14d, [r15+0x320]
0000714ce89d0962  mov eax, 0x4102A8
0000714ce89d0967  mov rcx, 0x714CE89D09E0
0000714ce89d0971  mov [r15+r14*8+0x328], rax
0000714ce89d0979  mov [r15+r14*8+0x368], rcx
0000714ce89d0981  add r14d, 0x01
0000714ce89d0985  and r14d, 0x07
0000714ce89d0989  mov [r15+0x320], r14d
0000714ce89d0990  cmp dword ptr [r15+0x318], 0x00
0000714ce89d0998  jz 0x0000714CE89CED70
0000714ce89d099e  nop [rax+rax*1], ax
0000714ce89d09a7  nop [rax+rax*1], eax
0000714ce89d09af  mov eax, 0x410728
0000714ce89d09b4  mov [r15+0x100], rax
0000714ce89d09bb  jmp 0x0000714CE87FE110
0000714ce89d09c0  int3
0000714ce89d09c1  call 0x0000714CE88E27E0
0000714ce89d09c6  jmp 0x0000714CE89D0913
0000714ce89d09cb  call 0x0000714CE88D5AF0
0000714ce89d09d0  jmp 0x0000714CE89D0950
0000714ce89d09d5  int3
0000714ce89d09d6  nop [rax+rax*1], ax
0000714ce89d09df  nop
0000714ce89d09e0  mov rax, [r15+0xF8]
0000714ce89d09e7  lea r14, [rax+0x168]
0000714ce89d09ee  mov r12, [r13+r14*1]
0000714ce89d09f3  mov [r15+0x40], r12
0000714ce89d09f7  lea r14, [rax+0x178]
0000714ce89d09fe  xor eax, eax
0000714ce89d0a00  mov [r13+r14*1], al
0000714ce89d0a05  xor eax, eax
0000714ce89d0a07  mov r14d, 0x38
0000714ce89d0a0d  cmp r12, r14
0000714ce89d0a10  cmc
0000714ce89d0a11  lahf
0000714ce89d0a12  seto al
0000714ce89d0a15  mov [r15+0x108], eax
0000714ce89d0a1c  mov eax, [r15+0x108]
0000714ce89d0a23  sahf
0000714ce89d0a24  jz 0x0000714CE89D0A56
0000714ce89d0a26  cmp dword ptr [r15+0x318], 0x00
0000714ce89d0a2e  jz 0x0000714CE89D0AA0
0000714ce89d0a34  nop [rax+rax*1], ax
0000714ce89d0a3d  nop [rax+rax*1], eax
0000714ce89d0a45  mov eax, 0x4102B8
0000714ce89d0a4a  mov [r15+0x100], rax
0000714ce89d0a51  jmp 0x0000714CE87FE110
0000714ce89d0a56  cmp dword ptr [r15+0x318], 0x00
0000714ce89d0a5e  jz 0x0000714CE89D0BF0
0000714ce89d0a64  nop [rax+rax*1], ax
0000714ce89d0a6d  nop [rax+rax*1], eax
0000714ce89d0a75  mov eax, 0x4102D4
0000714ce89d0a7a  mov [r15+0x100], rax
0000714ce89d0a81  jmp 0x0000714CE87FE110
0000714ce89d0a86  int3
0000714ce89d0a87  call 0x0000714CE88E27E0
0000714ce89d0a8c  jmp 0x0000714CE89D09F3
0000714ce89d0a91  call 0x0000714CE88D5AF0
0000714ce89d0a96  jmp 0x0000714CE89D0A05
0000714ce89d0a9b  int3
0000714ce89d0a9c  nop [rax], eax
0000714ce89d0aa0  mov rax, [r15+0xF8]
0000714ce89d0aa7  lea r14, [rax+0x100]
0000714ce89d0aae  mov [r15], r14
0000714ce89d0ab1  lea r14, [rax+0x178]
0000714ce89d0ab8  mov [r15+0x08], r14
0000714ce89d0abc  mov qword ptr [r15+0x10], 0x01
0000714ce89d0ac4  mov qword ptr [r15+0xF0], 0x4102C8
0000714ce89d0acf  mov r14d, [r15+0x320]
0000714ce89d0ad6  mov eax, 0x4102C8
0000714ce89d0adb  mov rcx, 0x714CE89D0B40
0000714ce89d0ae5  mov [r15+r14*8+0x328], rax
0000714ce89d0aed  mov [r15+r14*8+0x368], rcx
0000714ce89d0af5  add r14d, 0x01
0000714ce89d0af9  and r14d, 0x07
0000714ce89d0afd  mov [r15+0x320], r14d
0000714ce89d0b04  cmp dword ptr [r15+0x318], 0x00
0000714ce89d0b0c  jz 0x0000714CE89CED70
0000714ce89d0b12  nop [rax+rax*1], ax
0000714ce89d0b1b  nop [rax+rax*1], eax
0000714ce89d0b23  mov eax, 0x410728
0000714ce89d0b28  mov [r15+0x100], rax
0000714ce89d0b2f  jmp 0x0000714CE87FE110
0000714ce89d0b34  int3
0000714ce89d0b35  int3
0000714ce89d0b36  nop [rax+rax*1], ax
0000714ce89d0b3f  nop
0000714ce89d0b40  mov rax, [r15+0xF8]
0000714ce89d0b47  lea r14, [rax+0x168]
0000714ce89d0b4e  mov rax, [r13+r14*1]
0000714ce89d0b53  mov [r15+0x40], rax
0000714ce89d0b57  mov [rsp+0x10], rax
0000714ce89d0b5c  xor eax, eax
0000714ce89d0b5e  mov r14, [rsp+0x10]
0000714ce89d0b63  mov r12d, 0x38
0000714ce89d0b69  cmp r14, r12
0000714ce89d0b6c  cmc
0000714ce89d0b6d  lahf
0000714ce89d0b6e  seto al
0000714ce89d0b71  mov [r15+0x108], eax
0000714ce89d0b78  mov eax, [r15+0x108]
0000714ce89d0b7f  sahf
0000714ce89d0b80  jnz 0x0000714CE89D0BB2
0000714ce89d0b82  cmp dword ptr [r15+0x318], 0x00
0000714ce89d0b8a  jz 0x0000714CE89D0BF0
0000714ce89d0b90  nop [rax+rax*1], ax
0000714ce89d0b99  nop [rax+rax*1], eax
0000714ce89d0ba1  mov eax, 0x4102D4
0000714ce89d0ba6  mov [r15+0x100], rax
0000714ce89d0bad  jmp 0x0000714CE87FE110
0000714ce89d0bb2  cmp dword ptr [r15+0x318], 0x00
0000714ce89d0bba  jz 0x0000714CE89D0AA0
0000714ce89d0bc0  nop [rax+rax*1], ax
0000714ce89d0bc9  nop [rax+rax*1], eax
0000714ce89d0bd1  mov eax, 0x4102B8
0000714ce89d0bd6  mov [r15+0x100], rax
0000714ce89d0bdd  jmp 0x0000714CE87FE110
0000714ce89d0be2  int3
0000714ce89d0be3  call 0x0000714CE88D59C0
0000714ce89d0be8  jmp 0x0000714CE89D0B53
0000714ce89d0bed  int3
0000714ce89d0bee  nop
0000714ce89d0bf0  mov rax, [r15+0x98]
0000714ce89d0bf7  rorx r14, rax, 0x3D
0000714ce89d0bfd  and r14, 0xFFFFFFFFFFFFFFF8
0000714ce89d0c01  mov rax, [r15+0xF8]
0000714ce89d0c08  lea r12, [rax+0x100]
0000714ce89d0c0f  mov [r15], r12
0000714ce89d0c12  lea r12, [rax+0x170]
0000714ce89d0c19  mov [r15+0x08], r12
0000714ce89d0c1d  mov qword ptr [r15+0x10], 0x08
0000714ce89d0c25  bswap r14
0000714ce89d0c28  mov [r15+0x40], r14
0000714ce89d0c2c  lea r12, [rax+0x170]
0000714ce89d0c33  mov [r13+r12*1], r14
0000714ce89d0c38  mov qword ptr [r15+0xF0], 0x4102F0
0000714ce89d0c43  mov r14d, [r15+0x320]
0000714ce89d0c4a  mov eax, 0x4102F0
0000714ce89d0c4f  mov rcx, 0x714CE89D0CC0
0000714ce89d0c59  mov [r15+r14*8+0x328], rax
0000714ce89d0c61  mov [r15+r14*8+0x368], rcx
0000714ce89d0c69  add r14d, 0x01
0000714ce89d0c6d  and r14d, 0x07
0000714ce89d0c71  mov [r15+0x320], r14d
0000714ce89d0c78  cmp dword ptr [r15+0x318], 0x00
0000714ce89d0c80  jz 0x0000714CE89CED70
0000714ce89d0c86  nop [rax+rax*1], ax
0000714ce89d0c8f  nop [rax+rax*1], eax
0000714ce89d0c97  mov eax, 0x410728
0000714ce89d0c9c  mov [r15+0x100], rax
0000714ce89d0ca3  jmp 0x0000714CE87FE110
0000714ce89d0ca8  int3
0000714ce89d0ca9  call 0x0000714CE88C3FE0
0000714ce89d0cae  jmp 0x0000714CE89D0C38
0000714ce89d0cb3  int3
0000714ce89d0cb4  nop [rax+rax*1], ax
0000714ce89d0cbd  nop [rax], eax
0000714ce89d0cc0  mov rax, [r15+0xF8]
0000714ce89d0cc7  lea r14, [rax+0x100]
0000714ce89d0cce  mov r12d, [r13+r14*1]
0000714ce89d0cd3  lea r14, [rax+0x104]
0000714ce89d0cda  mov r11d, [r13+r14*1]
0000714ce89d0cdf  mov qword ptr [r15+0x48], 0x430C90
0000714ce89d0ce7  lea r14, [rax+0x108]
0000714ce89d0cee  mov r10d, [r13+r14*1]
0000714ce89d0cf3  lea r14, [rax+0x10C]
0000714ce89d0cfa  mov r9d, [r13+r14*1]
0000714ce89d0cff  bswap r12d
0000714ce89d0d02  bswap r11d
0000714ce89d0d05  mov qword ptr [r15+0xA0], 0x00
0000714ce89d0d10  mov r14d, 0x430C90
0000714ce89d0d16  mov [r13+r14*1], r12d
0000714ce89d0d1b  mov r14d, 0x430C94
0000714ce89d0d21  mov [r13+r14*1], r11d
0000714ce89d0d26  bswap r10d
0000714ce89d0d29  lea r14, [rax+0x110]
0000714ce89d0d30  mov r12d, [r13+r14*1]
0000714ce89d0d35  bswap r9d
0000714ce89d0d38  lea r14, [rax+0x114]
0000714ce89d0d3f  mov r11d, [r13+r14*1]
0000714ce89d0d44  mov qword ptr [r15+0x98], 0x430DFC
0000714ce89d0d4f  mov r14d, 0x430C98
0000714ce89d0d55  mov [r13+r14*1], r10d
0000714ce89d0d5a  mov r14d, 0x430C9C
0000714ce89d0d60  mov [r13+r14*1], r9d
0000714ce89d0d65  bswap r12d
0000714ce89d0d68  lea r14, [rax+0x118]
0000714ce89d0d6f  mov r10d, [r13+r14*1]
0000714ce89d0d74  bswap r11d
0000714ce89d0d77  mov [rsp+0x10], r11d
0000714ce89d0d7c  mov r11d, r11d
0000714ce89d0d7f  mov [r15+0x58], r11
0000714ce89d0d83  lea r14, [rax+0x11C]
0000714ce89d0d8a  mov eax, [r13+r14*1]
0000714ce89d0d8f  mov [rsp+0x20], eax
0000714ce89d0d93  mov eax, eax
0000714ce89d0d95  mov [r15+0x60], rax
0000714ce89d0d99  mov eax, 0x430CA0
0000714ce89d0d9e  mov [r13+rax*1], r12d
0000714ce89d0da3  mov eax, 0x430CA4
0000714ce89d0da8  mov r14d, [rsp+0x10]
0000714ce89d0dad  mov [r13+rax*1], r14d
0000714ce89d0db2  bswap r10d
0000714ce89d0db5  mov [rsp+0x10], r10d
0000714ce89d0dba  mov r10d, r10d
0000714ce89d0dbd  mov [r15+0x40], r10
0000714ce89d0dc1  mov eax, [rsp+0x20]
0000714ce89d0dc5  bswap eax
0000714ce89d0dc7  mov [rsp+0x20], eax
0000714ce89d0dcb  mov eax, eax
0000714ce89d0dcd  mov [r15+0x50], rax
0000714ce89d0dd1  mov eax, 0x430CA8
0000714ce89d0dd6  mov r14d, [rsp+0x10]
0000714ce89d0ddb  mov [r13+rax*1], r14d
0000714ce89d0de0  mov eax, 0x430CAC
0000714ce89d0de5  mov r14d, [rsp+0x20]
0000714ce89d0dea  mov [r13+rax*1], r14d
0000714ce89d0def  mov eax, [r15+0xA0]
0000714ce89d0df6  lea r14d, [eax+0x11]
0000714ce89d0dfb  mov r14d, r14d
0000714ce89d0dfe  mov [r15], r14
0000714ce89d0e01  mov qword ptr [r15+0xF0], 0x41035C
0000714ce89d0e0c  mov r14d, [r15+0x320]
0000714ce89d0e13  mov eax, 0x41035C
0000714ce89d0e18  mov rcx, 0x714CE89D0F90
0000714ce89d0e22  mov [r15+r14*8+0x328], rax
0000714ce89d0e2a  mov [r15+r14*8+0x368], rcx
0000714ce89d0e32  add r14d, 0x01
0000714ce89d0e36  and r14d, 0x07
0000714ce89d0e3a  mov [r15+0x320], r14d
0000714ce89d0e41  cmp dword ptr [r15+0x318], 0x00
0000714ce89d0e49  jz 0x0000714CE89D0F20
0000714ce89d0e4f  nop [rax+rax*1], ax
0000714ce89d0e58  nop [rax+rax*1], eax
0000714ce89d0e60  mov eax, 0x4109A4
0000714ce89d0e65  mov [r15+0x100], rax
0000714ce89d0e6c  jmp 0x0000714CE87FE110
0000714ce89d0e71  int3
0000714ce89d0e72  call 0x0000714CE88E26A0
0000714ce89d0e77  jmp 0x0000714CE89D0CD3
0000714ce89d0e7c  call 0x0000714CE88E1430
0000714ce89d0e81  jmp 0x0000714CE89D0CDF
0000714ce89d0e86  call 0x0000714CE88E01C0
0000714ce89d0e8b  jmp 0x0000714CE89D0CF3
0000714ce89d0e90  call 0x0000714CE88DEF50
0000714ce89d0e95  jmp 0x0000714CE89D0CFF
0000714ce89d0e9a  call 0x0000714CE88E2BA0
0000714ce89d0e9f  jmp 0x0000714CE89D0D1B
0000714ce89d0ea4  call 0x0000714CE88E1920
0000714ce89d0ea9  jmp 0x0000714CE89D0D26
0000714ce89d0eae  call 0x0000714CE88E26A0
0000714ce89d0eb3  jmp 0x0000714CE89D0D35
0000714ce89d0eb8  call 0x0000714CE88E1430
0000714ce89d0ebd  jmp 0x0000714CE89D0D44
0000714ce89d0ec2  call 0x0000714CE88E06B0
0000714ce89d0ec7  jmp 0x0000714CE89D0D5A
0000714ce89d0ecc  call 0x0000714CE88DF440
0000714ce89d0ed1  jmp 0x0000714CE89D0D65
0000714ce89d0ed6  call 0x0000714CE88E01C0
0000714ce89d0edb  jmp 0x0000714CE89D0D74
0000714ce89d0ee0  call 0x0000714CE88D5890
0000714ce89d0ee5  jmp 0x0000714CE89D0D8F
0000714ce89d0eea  call 0x0000714CE880BAE0
0000714ce89d0eef  jmp 0x0000714CE89D0DA3
0000714ce89d0ef4  call 0x0000714CE880DFE0
0000714ce89d0ef9  jmp 0x0000714CE89D0DB2
0000714ce89d0efe  call 0x0000714CE880DFE0
0000714ce89d0f03  jmp 0x0000714CE89D0DE0
0000714ce89d0f08  call 0x0000714CE880DFE0
0000714ce89d0f0d  jmp 0x0000714CE89D0DEF
0000714ce89d0f12  int3
0000714ce89d0f13  nop [rax+rax*1], ax
0000714ce89d0f1c  nop [rax], eax
0000714ce89d0f20  mov eax, [r15]
0000714ce89d0f23  mov [rsp+0x10], eax
0000714ce89d0f27  shr eax, 0x10
0000714ce89d0f2a  mov r14d, [rsp+0x10]
0000714ce89d0f2f  xor r14d, eax
0000714ce89d0f32  imul r14d, r14d, 0x7FEB352D
0000714ce89d0f39  mov eax, 0x846CA68B
0000714ce89d0f3e  mov eax, eax
0000714ce89d0f40  mov [r15+0x48], rax
0000714ce89d0f44  mov [rsp+0x10], r14d
0000714ce89d0f49  shr r14d, 0x0F
0000714ce89d0f4d  mov eax, [rsp+0x10]
0000714ce89d0f51  xor eax, r14d
0000714ce89d0f54  imul eax, eax, 0x846CA68B
0000714ce89d0f5a  mov [rsp+0x10], eax
0000714ce89d0f5e  mov eax, eax
0000714ce89d0f60  mov [r15+0x40], rax
0000714ce89d0f64  mov eax, [rsp+0x10]
0000714ce89d0f68  shr eax, 0x10
0000714ce89d0f6b  mov r14d, [rsp+0x10]
0000714ce89d0f70  xor r14d, eax
0000714ce89d0f73  mov r14d, r14d
0000714ce89d0f76  mov [r15], r14
0000714ce89d0f79  mov rax, [r15+0xF0]
0000714ce89d0f80  mov [r15+0x100], rax
0000714ce89d0f87  jmp 0x0000714CE89CE5C0
0000714ce89d0f8c  int3
0000714ce89d0f8d  int3
0000714ce89d0f8e  nop
0000714ce89d0f90  mov rax, [r15+0xA0]
0000714ce89d0f97  mov [rsp+0x10], rax
0000714ce89d0f9c  shl rax, 0x02
0000714ce89d0fa0  mov r14, [r15+0x98]
0000714ce89d0fa7  lea r12, [r14+rax*1]
0000714ce89d0fab  mov eax, [r15]
0000714ce89d0fae  mov [r13+r12*1], eax
0000714ce89d0fb3  mov rax, [rsp+0x10]
0000714ce89d0fb8  lea r14, [rax+0x01]
0000714ce89d0fbc  mov [r15+0xA0], r14
0000714ce89d0fc3  xor eax, eax
0000714ce89d0fc5  mov r12d, 0x400
0000714ce89d0fcb  cmp r14, r12
0000714ce89d0fce  cmc
0000714ce89d0fcf  lahf
0000714ce89d0fd0  seto al
0000714ce89d0fd3  mov [r15+0x108], eax
0000714ce89d0fda  mov eax, [r15+0x108]
0000714ce89d0fe1  sahf
0000714ce89d0fe2  jnz 0x0000714CE89D1014
0000714ce89d0fe4  cmp dword ptr [r15+0x318], 0x00
0000714ce89d0fec  jz 0x0000714CE89D10E0
0000714ce89d0ff2  nop [rax+rax*1], ax
0000714ce89d0ffb  nop [rax+rax*1], eax
0000714ce89d1003  mov eax, 0x41036C
0000714ce89d1008  mov [r15+0x100], rax
0000714ce89d100f  jmp 0x0000714CE87FE110
0000714ce89d1014  cmp dword ptr [r15+0x318], 0x00
0000714ce89d101c  jz 0x0000714CE89D1050
0000714ce89d1022  nop [rax+rax*1], ax
0000714ce89d102b  nop [rax+rax*1], eax
0000714ce89d1033  mov eax, 0x410354
0000714ce89d1038  mov [r15+0x100], rax
0000714ce89d103f  jmp 0x0000714CE87FE110
0000714ce89d1044  int3
0000714ce89d1045  call 0x0000714CE88B4B70
0000714ce89d104a  jmp 0x0000714CE89D0FB3
0000714ce89d104f  int3
0000714ce89d1050  mov eax, [r15+0xA0]
0000714ce89d1057  lea r14d, [eax+0x11]
0000714ce89d105c  mov r14d, r14d
0000714ce89d105f  mov [r15], r14
0000714ce89d1062  mov qword ptr [r15+0xF0], 0x41035C
0000714ce89d106d  mov r14d, [r15+0x320]
0000714ce89d1074  mov eax, 0x41035C
0000714ce89d1079  mov rcx, 0x714CE89D0F90
0000714ce89d1083  mov [r15+r14*8+0x328], rax
0000714ce89d108b  mov [r15+r14*8+0x368], rcx
0000714ce89d1093  add r14d, 0x01
0000714ce89d1097  and r14d, 0x07
0000714ce89d109b  mov [r15+0x320], r14d
0000714ce89d10a2  cmp dword ptr [r15+0x318], 0x00
0000714ce89d10aa  jz 0x0000714CE89D0F20
0000714ce89d10b0  nop [rax+rax*1], ax
0000714ce89d10b9  nop [rax+rax*1], eax
0000714ce89d10c1  mov eax, 0x4109A4
0000714ce89d10c6  mov [r15+0x100], rax
0000714ce89d10cd  jmp 0x0000714CE87FE110
0000714ce89d10d2  int3
0000714ce89d10d3  int3
0000714ce89d10d4  nop [rax+rax*1], ax
0000714ce89d10dd  nop [rax], eax
0000714ce89d10e0  mov qword ptr [r15+0x40], 0x01
0000714ce89d10e8  cmp dword ptr [r15+0x318], 0x00
0000714ce89d10f0  jz 0x0000714CE89D1120
0000714ce89d10f6  nop [rax+rax*1], ax
0000714ce89d10ff  nop [rax+rax*1], eax
0000714ce89d1107  mov eax, 0x410388
0000714ce89d110c  mov [r15+0x100], rax
0000714ce89d1113  jmp 0x0000714CE87FE110
0000714ce89d1118  int3
0000714ce89d1119  int3
0000714ce89d111a  nop [rax+rax*1], ax
0000714ce89d1120  mov rax, [r15+0x40]
0000714ce89d1124  mov [rsp+0x10], rax
0000714ce89d1129  shl rax, 0x02
0000714ce89d112d  mov r14, [r15+0x98]
0000714ce89d1134  lea r12, [r14+rax*1]
0000714ce89d1138  mov eax, [r13+r12*1]
0000714ce89d113d  mov [rsp+0x20], eax
0000714ce89d1141  mov eax, eax
0000714ce89d1143  mov [r15+0x48], rax
0000714ce89d1147  mov rax, [rsp+0x10]
0000714ce89d114c  mov [r15+0x50], rax
0000714ce89d1150  mov eax, [r15+0x50]
0000714ce89d1154  lea r12d, [eax-0x01]
0000714ce89d1159  mov r12d, r12d
0000714ce89d115c  mov [r15+0x58], r12
0000714ce89d1160  mov rax, [r15+0x58]
0000714ce89d1164  mov r12d, eax
0000714ce89d1167  mov r12d, r12d
0000714ce89d116a  shl r12, 0x02
0000714ce89d116e  lea rax, [r14+r12*1]
0000714ce89d1172  mov r14d, [r13+rax*1]
0000714ce89d1177  mov [rsp+0x10], r14d
0000714ce89d117c  mov r14d, r14d
0000714ce89d117f  mov [r15+0x60], r14
0000714ce89d1183  xor eax, eax
0000714ce89d1185  mov r14d, [rsp+0x10]
0000714ce89d118a  mov r12d, [rsp+0x20]
0000714ce89d118f  cmp r14d, r12d
0000714ce89d1192  cmc
0000714ce89d1193  lahf
0000714ce89d1194  seto al
0000714ce89d1197  mov [r15+0x108], eax
0000714ce89d119e  mov eax, [r15+0x108]
0000714ce89d11a5  sahf
0000714ce89d11a6  cmc
0000714ce89d11a7  jbe 0x0000714CE89D11D9
0000714ce89d11a9  cmp dword ptr [r15+0x318], 0x00
0000714ce89d11b1  jz 0x0000714CE89D1220
0000714ce89d11b7  nop [rax+rax*1], ax
0000714ce89d11c0  nop [rax+rax*1], eax
0000714ce89d11c8  mov eax, 0x4103A0
0000714ce89d11cd  mov [r15+0x100], rax
0000714ce89d11d4  jmp 0x0000714CE87FE110
0000714ce89d11d9  cmp dword ptr [r15+0x318], 0x00
0000714ce89d11e1  jz 0x0000714CE89D14C0
0000714ce89d11e7  nop [rax+rax*1], ax
0000714ce89d11f0  nop [rax+rax*1], eax
0000714ce89d11f8  mov eax, 0x410378
0000714ce89d11fd  mov [r15+0x100], rax
0000714ce89d1204  jmp 0x0000714CE87FE110
0000714ce89d1209  int3
0000714ce89d120a  call 0x0000714CE88B4690
0000714ce89d120f  jmp 0x0000714CE89D113D
0000714ce89d1214  call 0x0000714CE880DAE0
0000714ce89d1219  jmp 0x0000714CE89D1177
0000714ce89d121e  int3
0000714ce89d121f  nop
0000714ce89d1220  mov rax, [r15+0x50]
0000714ce89d1224  mov [rsp+0x10], rax
0000714ce89d1229  shl rax, 0x02
0000714ce89d122d  mov r14, [r15+0x98]
0000714ce89d1234  lea r12, [r14+rax*1]
0000714ce89d1238  mov eax, [r15+0x60]
0000714ce89d123c  mov [r13+r12*1], eax
0000714ce89d1241  mov rax, [rsp+0x10]
0000714ce89d1246  lea r14, [rax-0x01]
0000714ce89d124a  mov [r15+0x50], r14
0000714ce89d124e  mov rax, [r15+0x58]
0000714ce89d1252  test rax, rax
0000714ce89d1255  setz al
0000714ce89d1258  movzx rax, al
0000714ce89d125c  mov [rsp+0x414], al
0000714ce89d1263  cmp byte ptr [rsp+0x414], 0x00
0000714ce89d126b  jz 0x0000714CE89D129D
0000714ce89d126d  cmp dword ptr [r15+0x318], 0x00
0000714ce89d1275  jz 0x0000714CE89D12E0
0000714ce89d127b  nop [rax+rax*1], ax
0000714ce89d1284  nop [rax+rax*1], eax
0000714ce89d128c  mov eax, 0x4103AC
0000714ce89d1291  mov [r15+0x100], rax
0000714ce89d1298  jmp 0x0000714CE87FE110
0000714ce89d129d  cmp dword ptr [r15+0x318], 0x00
0000714ce89d12a5  jz 0x0000714CE89D13E0
0000714ce89d12ab  nop [rax+rax*1], ax
0000714ce89d12b4  nop [rax+rax*1], eax
0000714ce89d12bc  mov eax, 0x410390
0000714ce89d12c1  mov [r15+0x100], rax
0000714ce89d12c8  jmp 0x0000714CE87FE110
0000714ce89d12cd  int3
0000714ce89d12ce  call 0x0000714CE88B4B70
0000714ce89d12d3  jmp 0x0000714CE89D1241
0000714ce89d12d8  int3
0000714ce89d12d9  nop [rax], eax
0000714ce89d12e0  cmp dword ptr [r15+0x318], 0x00
0000714ce89d12e8  jz 0x0000714CE89D1320
0000714ce89d12ee  nop [rax+rax*1], ax
0000714ce89d12f7  nop [rax+rax*1], eax
0000714ce89d12ff  mov eax, 0x410374
0000714ce89d1304  mov [r15+0x100], rax
0000714ce89d130b  jmp 0x0000714CE87FE110
0000714ce89d1310  int3
0000714ce89d1311  int3
0000714ce89d1312  nop [rax+rax*1], ax
0000714ce89d131b  nop [rax+rax*1], eax
0000714ce89d1320  mov qword ptr [r15+0x50], 0x00
0000714ce89d1328  mov rax, [r15+0x40]
0000714ce89d132c  lea r14, [rax+0x01]
0000714ce89d1330  mov [r15+0x40], r14
0000714ce89d1334  mov rax, [r15+0x98]
0000714ce89d133b  mov r12d, [r15+0x48]
0000714ce89d133f  mov [r13+rax*1], r12d
0000714ce89d1344  xor eax, eax
0000714ce89d1346  mov r12d, 0x400
0000714ce89d134c  cmp r14, r12
0000714ce89d134f  cmc
0000714ce89d1350  lahf
0000714ce89d1351  seto al
0000714ce89d1354  mov [r15+0x108], eax
0000714ce89d135b  mov eax, [r15+0x108]
0000714ce89d1362  sahf
0000714ce89d1363  jz 0x0000714CE89D1395
0000714ce89d1365  cmp dword ptr [r15+0x318], 0x00
0000714ce89d136d  jz 0x0000714CE89D1120
0000714ce89d1373  nop [rax+rax*1], ax
0000714ce89d137c  nop [rax+rax*1], eax
0000714ce89d1384  mov eax, 0x410388
0000714ce89d1389  mov [r15+0x100], rax
0000714ce89d1390  jmp 0x0000714CE87FE110
0000714ce89d1395  cmp dword ptr [r15+0x318], 0x00
0000714ce89d139d  jz 0x0000714CE89D1580
0000714ce89d13a3  nop [rax+rax*1], ax
0000714ce89d13ac  nop [rax+rax*1], eax
0000714ce89d13b4  mov eax, 0x4103B0
0000714ce89d13b9  mov [r15+0x100], rax
0000714ce89d13c0  jmp 0x0000714CE87FE110
0000714ce89d13c5  int3
0000714ce89d13c6  call 0x0000714CE880BAE0
0000714ce89d13cb  jmp 0x0000714CE89D1344
0000714ce89d13d0  int3
0000714ce89d13d1  nop [rax+rax*1], ax
0000714ce89d13da  nop [rax+rax*1], ax
0000714ce89d13e0  mov eax, [r15+0x50]
0000714ce89d13e4  lea r14d, [eax-0x01]
0000714ce89d13e9  mov r14d, r14d
0000714ce89d13ec  mov [r15+0x58], r14
0000714ce89d13f0  mov rax, [r15+0x58]
0000714ce89d13f4  mov r14d, eax
0000714ce89d13f7  mov r14d, r14d
0000714ce89d13fa  shl r14, 0x02
0000714ce89d13fe  mov rax, [r15+0x98]
0000714ce89d1405  lea r12, [rax+r14*1]
0000714ce89d1409  mov eax, [r13+r12*1]
0000714ce89d140e  mov [rsp+0x10], eax
0000714ce89d1412  mov eax, eax
0000714ce89d1414  mov [r15+0x60], rax
0000714ce89d1418  mov eax, [r15+0x48]
0000714ce89d141c  mov [rsp+0x20], eax
0000714ce89d1420  xor eax, eax
0000714ce89d1422  mov r14d, [rsp+0x10]
0000714ce89d1427  mov r12d, [rsp+0x20]
0000714ce89d142c  cmp r14d, r12d
0000714ce89d142f  cmc
0000714ce89d1430  lahf
0000714ce89d1431  seto al
0000714ce89d1434  mov [r15+0x108], eax
0000714ce89d143b  mov eax, [r15+0x108]
0000714ce89d1442  sahf
0000714ce89d1443  cmc
0000714ce89d1444  jbe 0x0000714CE89D1476
0000714ce89d1446  cmp dword ptr [r15+0x318], 0x00
0000714ce89d144e  jz 0x0000714CE89D1220
0000714ce89d1454  nop [rax+rax*1], ax
0000714ce89d145d  nop [rax+rax*1], eax
0000714ce89d1465  mov eax, 0x4103A0
0000714ce89d146a  mov [r15+0x100], rax
0000714ce89d1471  jmp 0x0000714CE87FE110
0000714ce89d1476  cmp dword ptr [r15+0x318], 0x00
0000714ce89d147e  jz 0x0000714CE89D14C0
0000714ce89d1484  nop [rax+rax*1], ax
0000714ce89d148d  nop [rax+rax*1], eax
0000714ce89d1495  mov eax, 0x410378
0000714ce89d149a  mov [r15+0x100], rax
0000714ce89d14a1  jmp 0x0000714CE87FE110
0000714ce89d14a6  int3
0000714ce89d14a7  call 0x0000714CE88B4690
0000714ce89d14ac  jmp 0x0000714CE89D140E
0000714ce89d14b1  int3
0000714ce89d14b2  nop [rax+rax*1], ax
0000714ce89d14bb  nop [rax+rax*1], eax
0000714ce89d14c0  mov rax, [r15+0x40]
0000714ce89d14c4  lea r14, [rax+0x01]
0000714ce89d14c8  mov [r15+0x40], r14
0000714ce89d14cc  mov rax, [r15+0x50]
0000714ce89d14d0  mov r12d, eax
0000714ce89d14d3  mov r12d, r12d
0000714ce89d14d6  shl r12, 0x02
0000714ce89d14da  mov rax, [r15+0x98]
0000714ce89d14e1  lea r11, [rax+r12*1]
0000714ce89d14e5  mov eax, [r15+0x48]
0000714ce89d14e9  mov [r13+r11*1], eax
0000714ce89d14ee  xor eax, eax
0000714ce89d14f0  mov r12d, 0x400
0000714ce89d14f6  cmp r14, r12
0000714ce89d14f9  cmc
0000714ce89d14fa  lahf
0000714ce89d14fb  seto al
0000714ce89d14fe  mov [r15+0x108], eax
0000714ce89d1505  mov eax, [r15+0x108]
0000714ce89d150c  sahf
0000714ce89d150d  jz 0x0000714CE89D153F
0000714ce89d150f  cmp dword ptr [r15+0x318], 0x00
0000714ce89d1517  jz 0x0000714CE89D1120
0000714ce89d151d  nop [rax+rax*1], ax
0000714ce89d1526  nop [rax+rax*1], eax
0000714ce89d152e  mov eax, 0x410388
0000714ce89d1533  mov [r15+0x100], rax
0000714ce89d153a  jmp 0x0000714CE87FE110
0000714ce89d153f  cmp dword ptr [r15+0x318], 0x00
0000714ce89d1547  jz 0x0000714CE89D1580
0000714ce89d154d  nop [rax+rax*1], ax
0000714ce89d1556  nop [rax+rax*1], eax
0000714ce89d155e  mov eax, 0x4103B0
0000714ce89d1563  mov [r15+0x100], rax
0000714ce89d156a  jmp 0x0000714CE87FE110
0000714ce89d156f  int3
0000714ce89d1570  call 0x0000714CE88A4270
0000714ce89d1575  jmp 0x0000714CE89D14EE
0000714ce89d157a  int3
0000714ce89d157b  nop [rax+rax*1], eax
0000714ce89d1580  mov qword ptr [r15+0x40], 0x430000
0000714ce89d1588  mov eax, 0x430CB0
0000714ce89d158d  mov r14, [r13+rax*1]
0000714ce89d1592  mov rax, [r15+0x98]
0000714ce89d1599  mov r12d, [r13+rax*1]
0000714ce89d159e  lea r11, [rax+0x04]
0000714ce89d15a2  mov eax, [r13+r11*1]
0000714ce89d15a7  mov r12d, r12d
0000714ce89d15aa  mov [r15+0x68], r12
0000714ce89d15ae  mov eax, eax
0000714ce89d15b0  mov [r15+0x60], rax
0000714ce89d15b4  mov rax, [r15+0x68]
0000714ce89d15b8  mov [r15+0x68], rax
0000714ce89d15bc  mov qword ptr [r15+0x58], 0x02
0000714ce89d15c4  mov [rsp+0x10], rax
0000714ce89d15c9  xor eax, eax
0000714ce89d15cb  mov r12d, 0x02
0000714ce89d15d1  mov r11d, 0x400
0000714ce89d15d7  cmp r12, r11
0000714ce89d15da  cmc
0000714ce89d15db  lahf
0000714ce89d15dc  seto al
0000714ce89d15df  mov [r15+0x108], eax
0000714ce89d15e6  mov rax, [r15+0x60]
0000714ce89d15ea  mov r12d, 0x02
0000714ce89d15f0  imul rax, r12
0000714ce89d15f4  mov [r15+0x50], rax
0000714ce89d15f8  mov rax, [rsp+0x10]
0000714ce89d15fd  lea r12, [rax+r14*1]
0000714ce89d1601  mov [r15+0x48], r12
0000714ce89d1605  mov eax, [r15+0x108]
0000714ce89d160c  sahf
0000714ce89d160d  jnz 0x0000714CE89D163F
0000714ce89d160f  cmp dword ptr [r15+0x318], 0x00
0000714ce89d1617  jz 0x0000714CE89D17B0
0000714ce89d161d  nop [rax+rax*1], ax
0000714ce89d1626  nop [rax+rax*1], eax
0000714ce89d162e  mov eax, 0x4103E0
0000714ce89d1633  mov [r15+0x100], rax
0000714ce89d163a  jmp 0x0000714CE87FE110
0000714ce89d163f  cmp dword ptr [r15+0x318], 0x00
0000714ce89d1647  jz 0x0000714CE89D1690
0000714ce89d164d  nop [rax+rax*1], ax
0000714ce89d1656  nop [rax+rax*1], eax
0000714ce89d165e  mov eax, 0x4103C0
0000714ce89d1663  mov [r15+0x100], rax
0000714ce89d166a  jmp 0x0000714CE87FE110
0000714ce89d166f  int3
0000714ce89d1670  call 0x0000714CE880DC20
0000714ce89d1675  jmp 0x0000714CE89D1592
0000714ce89d167a  call 0x0000714CE880B5E0
0000714ce89d167f  jmp 0x0000714CE89D159E
0000714ce89d1684  call 0x0000714CE88A3D90
0000714ce89d1689  jmp 0x0000714CE89D15A7
0000714ce89d168e  int3
0000714ce89d168f  nop
0000714ce89d1690  mov rax, [r15+0x98]
0000714ce89d1697  mov r14, [r15+0x58]
0000714ce89d169b  mov [rsp+0x10], r14
0000714ce89d16a0  shl r14, 0x02
0000714ce89d16a4  lea r12, [rax+r14*1]
0000714ce89d16a8  mov eax, [r13+r12*1]
0000714ce89d16ad  lea r14, [r12+0x04]
0000714ce89d16b2  mov r12d, [r13+r14*1]
0000714ce89d16b7  mov eax, eax
0000714ce89d16b9  mov [r15+0x68], rax
0000714ce89d16bd  mov r12d, r12d
0000714ce89d16c0  mov [r15+0x60], r12
0000714ce89d16c4  mov rax, [r15+0x68]
0000714ce89d16c8  mov [rsp+0x20], rax
0000714ce89d16cd  mov r14, [rsp+0x10]
0000714ce89d16d2  imul rax, r14
0000714ce89d16d6  mov r12, [rsp+0x20]
0000714ce89d16db  lea r11, [r12+rax*1]
0000714ce89d16df  mov [r15+0x68], r11
0000714ce89d16e3  lea rax, [r14+0x02]
0000714ce89d16e7  mov [r15+0x58], rax
0000714ce89d16eb  mov [rsp+0x10], rax
0000714ce89d16f0  xor eax, eax
0000714ce89d16f2  mov r14, [rsp+0x10]
0000714ce89d16f7  mov r12d, 0x400
0000714ce89d16fd  cmp r14, r12
0000714ce89d1700  cmc
0000714ce89d1701  lahf
0000714ce89d1702  seto al
0000714ce89d1705  mov [r15+0x108], eax
0000714ce89d170c  mov rax, [r15+0x50]
0000714ce89d1710  mov r12, [r15+0x60]
0000714ce89d1714  imul r14, r12
0000714ce89d1718  lea r12, [rax+r14*1]
0000714ce89d171c  mov [r15+0x50], r12
0000714ce89d1720  mov rax, [r15+0x48]
0000714ce89d1724  lea r14, [r11+rax*1]
0000714ce89d1728  mov [r15+0x48], r14
0000714ce89d172c  mov eax, [r15+0x108]
0000714ce89d1733  sahf
0000714ce89d1734  jnz 0x0000714CE89D1766
0000714ce89d1736  cmp dword ptr [r15+0x318], 0x00
0000714ce89d173e  jz 0x0000714CE89D17B0
0000714ce89d1744  nop [rax+rax*1], ax
0000714ce89d174d  nop [rax+rax*1], eax
0000714ce89d1755  mov eax, 0x4103E0
0000714ce89d175a  mov [r15+0x100], rax
0000714ce89d1761  jmp 0x0000714CE87FE110
0000714ce89d1766  cmp dword ptr [r15+0x318], 0x00
0000714ce89d176e  jz 0x0000714CE89D1690
0000714ce89d1774  nop [rax+rax*1], ax
0000714ce89d177d  nop [rax+rax*1], eax
0000714ce89d1785  mov eax, 0x4103C0
0000714ce89d178a  mov [r15+0x100], rax
0000714ce89d1791  jmp 0x0000714CE87FE110
0000714ce89d1796  int3
0000714ce89d1797  call 0x0000714CE88B4690
0000714ce89d179c  jmp 0x0000714CE89D16AD
0000714ce89d17a1  call 0x0000714CE88E26A0
0000714ce89d17a6  jmp 0x0000714CE89D16B7
0000714ce89d17ab  int3
0000714ce89d17ac  nop [rax], eax
0000714ce89d17b0  mov qword ptr [r15+0x98], 0x00
0000714ce89d17bb  mov rax, [r15+0x50]
0000714ce89d17bf  mov r14, [r15+0x48]
0000714ce89d17c3  lea r12, [rax+r14*1]
0000714ce89d17c7  mov [r15+0x48], r12
0000714ce89d17cb  mov rax, [r15+0x40]
0000714ce89d17cf  lea r14, [rax+0xCB0]
0000714ce89d17d6  mov [r13+r14*1], r12
0000714ce89d17db  mov qword ptr [r15], 0x01
0000714ce89d17e2  mov qword ptr [r15+0xF0], 0x4103F8
0000714ce89d17ed  mov r14d, [r15+0x320]
0000714ce89d17f4  mov eax, 0x4103F8
0000714ce89d17f9  mov rcx, 0x714CE89D1860
0000714ce89d1803  mov [r15+r14*8+0x328], rax
0000714ce89d180b  mov [r15+r14*8+0x368], rcx
0000714ce89d1813  add r14d, 0x01
0000714ce89d1817  and r14d, 0x07
0000714ce89d181b  mov [r15+0x320], r14d
0000714ce89d1822  cmp dword ptr [r15+0x318], 0x00
0000714ce89d182a  jz 0x0000714CE89D0F20
0000714ce89d1830  nop [rax+rax*1], ax
0000714ce89d1839  nop [rax+rax*1], eax
0000714ce89d1841  mov eax, 0x4109A4
0000714ce89d1846  mov [r15+0x100], rax
0000714ce89d184d  jmp 0x0000714CE87FE110
0000714ce89d1852  int3
0000714ce89d1853  call 0x0000714CE88E2CE0
0000714ce89d1858  jmp 0x0000714CE89D17DB
0000714ce89d185d  int3
0000714ce89d185e  nop
0000714ce89d1860  mov eax, [r15+0x98]
0000714ce89d1867  lea r14d, [eax+0x01]
0000714ce89d186c  mov [rsp+0x10], r14d
0000714ce89d1871  mov r14d, r14d
0000714ce89d1874  mov [r15+0x98], r14
0000714ce89d187b  xor eax, eax
0000714ce89d187d  mov r14d, [rsp+0x10]
0000714ce89d1882  cmp r14d, 0x10000
0000714ce89d1889  cmc
0000714ce89d188a  lahf
0000714ce89d188b  seto al
0000714ce89d188e  mov [r15+0x108], eax
0000714ce89d1895  mov eax, [r15+0x108]
0000714ce89d189c  sahf
0000714ce89d189d  jnz 0x0000714CE89D18CF
0000714ce89d189f  cmp dword ptr [r15+0x318], 0x00
0000714ce89d18a7  jz 0x0000714CE89D19A0
0000714ce89d18ad  nop [rax+rax*1], ax
0000714ce89d18b6  nop [rax+rax*1], eax
0000714ce89d18be  mov eax, 0x410404
0000714ce89d18c3  mov [r15+0x100], rax
0000714ce89d18ca  jmp 0x0000714CE87FE110
0000714ce89d18cf  cmp dword ptr [r15+0x318], 0x00
0000714ce89d18d7  jz 0x0000714CE89D1910
0000714ce89d18dd  nop [rax+rax*1], ax
0000714ce89d18e6  nop [rax+rax*1], eax
0000714ce89d18ee  mov eax, 0x4103F0
0000714ce89d18f3  mov [r15+0x100], rax
0000714ce89d18fa  jmp 0x0000714CE87FE110
0000714ce89d18ff  int3
0000714ce89d1900  int3
0000714ce89d1901  nop [rax+rax*1], ax
0000714ce89d190a  nop [rax+rax*1], ax
0000714ce89d1910  mov eax, [r15]
0000714ce89d1913  mov r14d, [r15+0x98]
0000714ce89d191a  lea r12d, [eax+r14d*1]
0000714ce89d191f  mov r12d, r12d
0000714ce89d1922  mov [r15], r12
0000714ce89d1925  mov qword ptr [r15+0xF0], 0x4103F8
0000714ce89d1930  mov r14d, [r15+0x320]
0000714ce89d1937  mov eax, 0x4103F8
0000714ce89d193c  mov rcx, 0x714CE89D1860
0000714ce89d1946  mov [r15+r14*8+0x328], rax
0000714ce89d194e  mov [r15+r14*8+0x368], rcx
0000714ce89d1956  add r14d, 0x01
0000714ce89d195a  and r14d, 0x07
0000714ce89d195e  mov [r15+0x320], r14d
0000714ce89d1965  cmp dword ptr [r15+0x318], 0x00
0000714ce89d196d  jz 0x0000714CE89D0F20
0000714ce89d1973  nop [rax+rax*1], ax
0000714ce89d197c  nop [rax+rax*1], eax
0000714ce89d1984  mov eax, 0x4109A4
0000714ce89d1989  mov [r15+0x100], rax
0000714ce89d1990  jmp 0x0000714CE87FE110
0000714ce89d1995  int3
0000714ce89d1996  int3
0000714ce89d1997  nop [rax+rax*1], ax
0000714ce89d19a0  vmovaps xmm1, [0x0000714CE85FE010]
0000714ce89d19a8  movq xmm1, xmm1
0000714ce89d19ac  movaps [r15+0x110], xmm1
0000714ce89d19b4  mov eax, 0x420B10
0000714ce89d19b9  mov r14, [r13+rax*1]
0000714ce89d19be  movq xmm1, r14
0000714ce89d19c3  movaps [r15+0x120], xmm1
0000714ce89d19cb  vmovaps xmm1, [0x0000714CE85FE020]
0000714ce89d19d3  movq xmm1, xmm1
0000714ce89d19d7  movaps [r15+0x140], xmm1
0000714ce89d19df  vmovaps xmm1, [0x0000714CE85FE030]
0000714ce89d19e7  vpbroadcastq xmm1, xmm1
0000714ce89d19ec  movaps [r15+0x150], xmm1
0000714ce89d19f4  mov qword ptr [r15+0x40], 0x02
0000714ce89d19fc  vmovaps xmm15, [0x0000714CE85FE040]
0000714ce89d1a04  movq xmm15, xmm15
0000714ce89d1a09  movaps [r15+0x160], xmm15
0000714ce89d1a11  vmovaps xmm15, [0x0000714CE85FE050]
0000714ce89d1a19  vpbroadcastq xmm15, xmm15
0000714ce89d1a1e  movaps [r15+0x130], xmm15
0000714ce89d1a26  mov rax, [r15+0x40]
0000714ce89d1a2a  vmovq xmm14, rax
0000714ce89d1a2f  vpbroadcastq xmm14, xmm14
0000714ce89d1a34  movaps [r15+0x170], xmm14
0000714ce89d1a3c  mov eax, 0x420A40
0000714ce89d1a41  movups xmm13, [r13+rax*1]
0000714ce89d1a47  mov qword ptr [r15+0x40], 0x431E00
0000714ce89d1a4f  mov eax, [r15]
0000714ce89d1a52  mov r14d, 0x430CB8
0000714ce89d1a58  mov [r13+r14*1], eax
0000714ce89d1a5d  mov qword ptr [r15+0x50], 0x432000
0000714ce89d1a65  vpmovqd xmm12, xmm13
0000714ce89d1a6b  pxor xmm11, xmm11
0000714ce89d1a70  punpcklqdq xmm12, xmm11
0000714ce89d1a75  movaps [r15+0x210], xmm12
0000714ce89d1a7d  movq xmm12, qword ptr [r15+0x140]
0000714ce89d1a86  movq xmm11, qword ptr [r15+0x120]
0000714ce89d1a8f  psubd xmm12, xmm11
0000714ce89d1a94  movq xmm12, xmm12
0000714ce89d1a99  paddq xmm13, xmm14
0000714ce89d1a9e  movaps [r15+0x180], xmm13
0000714ce89d1aa6  movq xmm14, qword ptr [r15+0x160]
0000714ce89d1aaf  paddd xmm11, xmm14
0000714ce89d1ab4  movq xmm11, xmm11
0000714ce89d1ab9  movq xmm11, xmm11
0000714ce89d1abe  movaps [r15+0x120], xmm11
0000714ce89d1ac6  pmovzxdq xmm12, xmm12
0000714ce89d1acc  psllq xmm12, 0x00
0000714ce89d1ad2  movq xmm14, qword ptr [r15+0x210]
0000714ce89d1adb  movq xmm13, qword ptr [r15+0x110]
0000714ce89d1ae4  paddd xmm14, xmm13
0000714ce89d1ae9  movq xmm14, xmm14
0000714ce89d1aee  vcvtuqq2pd xmm12, xmm12
0000714ce89d1af4  pmovzxdq xmm14, xmm14
0000714ce89d1afa  psllq xmm14, 0x00
0000714ce89d1b00  vcvtuqq2pd xmm14, xmm14
0000714ce89d1b06  movaps xmm13, xmm12
0000714ce89d1b0a  mulpd xmm13, xmm1
0000714ce89d1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
0000714ce89d1b15  ptest xmm11, xmm11
0000714ce89d1b1b  jnz 0x0000714CE89D1C0F
0000714ce89d1b21  movaps [r15+0x220], xmm13
0000714ce89d1b29  mov eax, 0x432000
0000714ce89d1b2e  movups [r13+rax*1], xmm13
0000714ce89d1b34  movaps xmm1, xmm14
0000714ce89d1b38  mulpd xmm1, xmm15
0000714ce89d1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
0000714ce89d1b42  ptest xmm13, xmm13
0000714ce89d1b48  jnz 0x0000714CE89D1D5C
0000714ce89d1b4e  movaps [r15+0x210], xmm1
0000714ce89d1b56  mov eax, 0x431E00
0000714ce89d1b5b  movups [r13+rax*1], xmm1
0000714ce89d1b61  mov qword ptr [r15+0x48], 0x10
0000714ce89d1b69  xor eax, eax
0000714ce89d1b6b  mov r14d, 0x10
0000714ce89d1b71  mov r12d, 0x200
0000714ce89d1b77  cmp r14, r12
0000714ce89d1b7a  cmc
0000714ce89d1b7b  lahf
0000714ce89d1b7c  seto al
0000714ce89d1b7f  mov [r15+0x108], eax
0000714ce89d1b86  mov eax, [r15+0x108]
0000714ce89d1b8d  sahf
0000714ce89d1b8e  jnz 0x0000714CE89D1BC0
0000714ce89d1b90  cmp dword ptr [r15+0x318], 0x00
0000714ce89d1b98  jz 0x0000714CE89D2300
0000714ce89d1b9e  nop [rax+rax*1], ax
0000714ce89d1ba7  nop [rax+rax*1], eax
0000714ce89d1baf  mov eax, 0x410490
0000714ce89d1bb4  mov [r15+0x100], rax
0000714ce89d1bbb  jmp 0x0000714CE87FE110
0000714ce89d1bc0  cmp dword ptr [r15+0x318], 0x00
0000714ce89d1bc8  jz 0x0000714CE89D1EB0
0000714ce89d1bce  nop [rax+rax*1], ax
0000714ce89d1bd7  nop [rax+rax*1], eax
0000714ce89d1bdf  mov eax, 0x410450
0000714ce89d1be4  mov [r15+0x100], rax
0000714ce89d1beb  jmp 0x0000714CE87FE110
0000714ce89d1bf0  int3
0000714ce89d1bf1  call 0x0000714CE880DC20
0000714ce89d1bf6  jmp 0x0000714CE89D19BE
0000714ce89d1bfb  call 0x0000714CE880C260
0000714ce89d1c00  jmp 0x0000714CE89D1A47
0000714ce89d1c05  call 0x0000714CE88D5D70
0000714ce89d1c0a  jmp 0x0000714CE89D1A5D
0000714ce89d1c0f  sub rsp, 0x08
0000714ce89d1c13  push rax
0000714ce89d1c14  push rcx
0000714ce89d1c15  push rdx
0000714ce89d1c16  push rdi
0000714ce89d1c17  push rsi
0000714ce89d1c18  push r8
0000714ce89d1c1a  push r9
0000714ce89d1c1c  push r10
0000714ce89d1c1e  push r11
0000714ce89d1c20  sub rsp, 0xF0
0000714ce89d1c27  vmovaps [rsp], xmm0
0000714ce89d1c2c  vmovaps [rsp+0x10], xmm1
0000714ce89d1c32  vmovaps [rsp+0x20], xmm2
0000714ce89d1c38  vmovaps [rsp+0x30], xmm3
0000714ce89d1c3e  vmovaps [rsp+0x40], xmm4
0000714ce89d1c44  vmovaps [rsp+0x50], xmm5
0000714ce89d1c4a  vmovaps [rsp+0x60], xmm6
0000714ce89d1c50  vmovaps [rsp+0x70], xmm7
0000714ce89d1c56  vmovaps [rsp+0x80], xmm8
0000714ce89d1c5f  vmovaps [rsp+0x90], xmm9
0000714ce89d1c68  vmovaps [rsp+0xA0], xmm10
0000714ce89d1c71  vmovaps [rsp+0xB0], xmm11
0000714ce89d1c7a  vmovaps [rsp+0xC0], xmm12
0000714ce89d1c83  vmovaps [rsp+0xD0], xmm14
0000714ce89d1c8c  vmovaps [rsp+0xE0], xmm15
0000714ce89d1c95  sub rsp, 0x30
0000714ce89d1c99  movaps [rsp], xmm13
0000714ce89d1c9e  movaps [rsp+0x10], xmm12
0000714ce89d1ca4  movaps [rsp+0x20], xmm1
0000714ce89d1ca9  lea rdi, [rsp]
0000714ce89d1cad  mov esi, 0x00
0000714ce89d1cb2  mov rax, 0x57A55D340530
0000714ce89d1cbc  call rax
0000714ce89d1cbe  movaps xmm13, [rsp]
0000714ce89d1cc3  add rsp, 0x30
0000714ce89d1cc7  vmovaps xmm0, [rsp]
0000714ce89d1ccc  vmovaps xmm1, [rsp+0x10]
0000714ce89d1cd2  vmovaps xmm2, [rsp+0x20]
0000714ce89d1cd8  vmovaps xmm3, [rsp+0x30]
0000714ce89d1cde  vmovaps xmm4, [rsp+0x40]
0000714ce89d1ce4  vmovaps xmm5, [rsp+0x50]
0000714ce89d1cea  vmovaps xmm6, [rsp+0x60]
0000714ce89d1cf0  vmovaps xmm7, [rsp+0x70]
0000714ce89d1cf6  vmovaps xmm8, [rsp+0x80]
0000714ce89d1cff  vmovaps xmm9, [rsp+0x90]
0000714ce89d1d08  vmovaps xmm10, [rsp+0xA0]
0000714ce89d1d11  vmovaps xmm11, [rsp+0xB0]
0000714ce89d1d1a  vmovaps xmm12, [rsp+0xC0]
0000714ce89d1d23  vmovaps xmm14, [rsp+0xD0]
0000714ce89d1d2c  vmovaps xmm15, [rsp+0xE0]
0000714ce89d1d35  add rsp, 0xF0
0000714ce89d1d3c  pop r11
0000714ce89d1d3e  pop r10
0000714ce89d1d40  pop r9
0000714ce89d1d42  pop r8
0000714ce89d1d44  pop rsi
0000714ce89d1d45  pop rdi
0000714ce89d1d46  pop rdx
0000714ce89d1d47  pop rcx
0000714ce89d1d48  pop rax
0000714ce89d1d49  add rsp, 0x08
0000714ce89d1d4d  jmp 0x0000714CE89D1B21
0000714ce89d1d52  call 0x0000714CE880C380
0000714ce89d1d57  jmp 0x0000714CE89D1B34
0000714ce89d1d5c  sub rsp, 0x08
0000714ce89d1d60  push rax
0000714ce89d1d61  push rcx
0000714ce89d1d62  push rdx
0000714ce89d1d63  push rdi
0000714ce89d1d64  push rsi
0000714ce89d1d65  push r8
0000714ce89d1d67  push r9
0000714ce89d1d69  push r10
0000714ce89d1d6b  push r11
0000714ce89d1d6d  sub rsp, 0xF0
0000714ce89d1d74  vmovaps [rsp], xmm0
0000714ce89d1d79  vmovaps [rsp+0x10], xmm2
0000714ce89d1d7f  vmovaps [rsp+0x20], xmm3
0000714ce89d1d85  vmovaps [rsp+0x30], xmm4
0000714ce89d1d8b  vmovaps [rsp+0x40], xmm5
0000714ce89d1d91  vmovaps [rsp+0x50], xmm6
0000714ce89d1d97  vmovaps [rsp+0x60], xmm7
0000714ce89d1d9d  vmovaps [rsp+0x70], xmm8
0000714ce89d1da3  vmovaps [rsp+0x80], xmm9
0000714ce89d1dac  vmovaps [rsp+0x90], xmm10
0000714ce89d1db5  vmovaps [rsp+0xA0], xmm11
0000714ce89d1dbe  vmovaps [rsp+0xB0], xmm12
0000714ce89d1dc7  vmovaps [rsp+0xC0], xmm13
0000714ce89d1dd0  vmovaps [rsp+0xD0], xmm14
0000714ce89d1dd9  vmovaps [rsp+0xE0], xmm15
0000714ce89d1de2  sub rsp, 0x30
0000714ce89d1de6  movaps [rsp], xmm1
0000714ce89d1dea  movaps [rsp+0x10], xmm14
0000714ce89d1df0  movaps [rsp+0x20], xmm15
0000714ce89d1df6  lea rdi, [rsp]
0000714ce89d1dfa  mov esi, 0x00
0000714ce89d1dff  mov rax, 0x57A55D340530
0000714ce89d1e09  call rax
0000714ce89d1e0b  movaps xmm1, [rsp]
0000714ce89d1e0f  add rsp, 0x30
0000714ce89d1e13  vmovaps xmm0, [rsp]
0000714ce89d1e18  vmovaps xmm2, [rsp+0x10]
0000714ce89d1e1e  vmovaps xmm3, [rsp+0x20]
0000714ce89d1e24  vmovaps xmm4, [rsp+0x30]
0000714ce89d1e2a  vmovaps xmm5, [rsp+0x40]
0000714ce89d1e30  vmovaps xmm6, [rsp+0x50]
0000714ce89d1e36  vmovaps xmm7, [rsp+0x60]
0000714ce89d1e3c  vmovaps xmm8, [rsp+0x70]
0000714ce89d1e42  vmovaps xmm9, [rsp+0x80]
0000714ce89d1e4b  vmovaps xmm10, [rsp+0x90]
0000714ce89d1e54  vmovaps xmm11, [rsp+0xA0]
0000714ce89d1e5d  vmovaps xmm12, [rsp+0xB0]
0000714ce89d1e66  vmovaps xmm13, [rsp+0xC0]
0000714ce89d1e6f  vmovaps xmm14, [rsp+0xD0]
0000714ce89d1e78  vmovaps xmm15, [rsp+0xE0]
0000714ce89d1e81  add rsp, 0xF0
0000714ce89d1e88  pop r11
0000714ce89d1e8a  pop r10
0000714ce89d1e8c  pop r9
0000714ce89d1e8e  pop r8
0000714ce89d1e90  pop rsi
0000714ce89d1e91  pop rdi
0000714ce89d1e92  pop rdx
0000714ce89d1e93  pop rcx
0000714ce89d1e94  pop rax
0000714ce89d1e95  add rsp, 0x08
0000714ce89d1e99  jmp 0x0000714CE89D1B4E
0000714ce89d1e9e  call 0x0000714CE87FF540
0000714ce89d1ea3  jmp 0x0000714CE89D1B61
0000714ce89d1ea8  int3
0000714ce89d1ea9  nop [rax], eax
0000714ce89d1eb0  movaps xmm1, [r15+0x180]
0000714ce89d1eb8  vpmovqd xmm15, xmm1
0000714ce89d1ebe  pxor xmm14, xmm14
0000714ce89d1ec3  punpcklqdq xmm15, xmm14
0000714ce89d1ec8  movaps [r15+0x210], xmm15
0000714ce89d1ed0  movq xmm15, qword ptr [r15+0x140]
0000714ce89d1ed9  movq xmm14, qword ptr [r15+0x120]
0000714ce89d1ee2  psubd xmm15, xmm14
0000714ce89d1ee7  movq xmm15, xmm15
0000714ce89d1eec  movaps xmm13, [r15+0x170]
0000714ce89d1ef4  paddq xmm1, xmm13
0000714ce89d1ef9  movaps [r15+0x180], xmm1
0000714ce89d1f01  movq xmm1, qword ptr [r15+0x160]
0000714ce89d1f0a  paddd xmm14, xmm1
0000714ce89d1f0f  movq xmm14, xmm14
0000714ce89d1f14  movq xmm14, xmm14
0000714ce89d1f19  movaps [r15+0x120], xmm14
0000714ce89d1f21  pmovzxdq xmm15, xmm15
0000714ce89d1f27  psllq xmm15, 0x00
0000714ce89d1f2d  movq xmm1, qword ptr [r15+0x210]
0000714ce89d1f36  movq xmm14, qword ptr [r15+0x110]
0000714ce89d1f3f  paddd xmm1, xmm14
0000714ce89d1f44  movq xmm1, xmm1
0000714ce89d1f48  vcvtuqq2pd xmm15, xmm15
0000714ce89d1f4e  pmovzxdq xmm1, xmm1
0000714ce89d1f53  psllq xmm1, 0x00
0000714ce89d1f58  vcvtuqq2pd xmm1, xmm1
0000714ce89d1f5e  movaps xmm14, [r15+0x150]
0000714ce89d1f66  movaps xmm13, xmm15
0000714ce89d1f6a  mulpd xmm13, xmm14
0000714ce89d1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
0000714ce89d1f75  ptest xmm12, xmm12
0000714ce89d1f7b  jnz 0x0000714CE89D205E
0000714ce89d1f81  movaps [r15+0x220], xmm13
0000714ce89d1f89  mov rax, [r15+0x48]
0000714ce89d1f8d  mov r14, [r15+0x50]
0000714ce89d1f91  lea r12, [r14+rax*1]
0000714ce89d1f95  movups [r13+r12*1], xmm13
0000714ce89d1f9b  movaps xmm15, [r15+0x130]
0000714ce89d1fa3  movaps xmm14, xmm1
0000714ce89d1fa7  mulpd xmm14, xmm15
0000714ce89d1fac  vcmppd xmm13, xmm14, xmm14, 0x03
0000714ce89d1fb2  ptest xmm13, xmm13
0000714ce89d1fb8  jnz 0x0000714CE89D21AC
0000714ce89d1fbe  movaps [r15+0x210], xmm14
0000714ce89d1fc6  mov r14, [r15+0x40]
0000714ce89d1fca  lea r12, [r14+rax*1]
0000714ce89d1fce  movups [r13+r12*1], xmm14
0000714ce89d1fd4  lea r14, [rax+0x10]
0000714ce89d1fd8  mov [r15+0x48], r14
0000714ce89d1fdc  xor eax, eax
0000714ce89d1fde  mov r12d, 0x200
0000714ce89d1fe4  cmp r14, r12
0000714ce89d1fe7  cmc
0000714ce89d1fe8  lahf
0000714ce89d1fe9  seto al
0000714ce89d1fec  mov [r15+0x108], eax
0000714ce89d1ff3  mov eax, [r15+0x108]
0000714ce89d1ffa  sahf
0000714ce89d1ffb  jnz 0x0000714CE89D202D
0000714ce89d1ffd  cmp dword ptr [r15+0x318], 0x00
0000714ce89d2005  jz 0x0000714CE89D2300
0000714ce89d200b  nop [rax+rax*1], ax
0000714ce89d2014  nop [rax+rax*1], eax
0000714ce89d201c  mov eax, 0x410490
0000714ce89d2021  mov [r15+0x100], rax
0000714ce89d2028  jmp 0x0000714CE87FE110
0000714ce89d202d  cmp dword ptr [r15+0x318], 0x00
0000714ce89d2035  jz 0x0000714CE89D1EB0
0000714ce89d203b  nop [rax+rax*1], ax
0000714ce89d2044  nop [rax+rax*1], eax
0000714ce89d204c  mov eax, 0x410450
0000714ce89d2051  mov [r15+0x100], rax
0000714ce89d2058  jmp 0x0000714CE87FE110
0000714ce89d205d  int3
0000714ce89d205e  sub rsp, 0x08
0000714ce89d2062  push rax
0000714ce89d2063  push rcx
0000714ce89d2064  push rdx
0000714ce89d2065  push rdi
0000714ce89d2066  push rsi
0000714ce89d2067  push r8
0000714ce89d2069  push r9
0000714ce89d206b  push r10
0000714ce89d206d  push r11
0000714ce89d206f  sub rsp, 0xF0
0000714ce89d2076  vmovaps [rsp], xmm0
0000714ce89d207b  vmovaps [rsp+0x10], xmm1
0000714ce89d2081  vmovaps [rsp+0x20], xmm2
0000714ce89d2087  vmovaps [rsp+0x30], xmm3
0000714ce89d208d  vmovaps [rsp+0x40], xmm4
0000714ce89d2093  vmovaps [rsp+0x50], xmm5
0000714ce89d2099  vmovaps [rsp+0x60], xmm6
0000714ce89d209f  vmovaps [rsp+0x70], xmm7
0000714ce89d20a5  vmovaps [rsp+0x80], xmm8
0000714ce89d20ae  vmovaps [rsp+0x90], xmm9
0000714ce89d20b7  vmovaps [rsp+0xA0], xmm10
0000714ce89d20c0  vmovaps [rsp+0xB0], xmm11
0000714ce89d20c9  vmovaps [rsp+0xC0], xmm12
0000714ce89d20d2  vmovaps [rsp+0xD0], xmm14
0000714ce89d20db  vmovaps [rsp+0xE0], xmm15
0000714ce89d20e4  sub rsp, 0x30
0000714ce89d20e8  movaps [rsp], xmm13
0000714ce89d20ed  movaps [rsp+0x10], xmm15
0000714ce89d20f3  movaps [rsp+0x20], xmm14
0000714ce89d20f9  lea rdi, [rsp]
0000714ce89d20fd  mov esi, 0x00
0000714ce89d2102  mov rax, 0x57A55D340530
0000714ce89d210c  call rax
0000714ce89d210e  movaps xmm13, [rsp]
0000714ce89d2113  add rsp, 0x30
0000714ce89d2117  vmovaps xmm0, [rsp]
0000714ce89d211c  vmovaps xmm1, [rsp+0x10]
0000714ce89d2122  vmovaps xmm2, [rsp+0x20]
0000714ce89d2128  vmovaps xmm3, [rsp+0x30]
0000714ce89d212e  vmovaps xmm4, [rsp+0x40]
0000714ce89d2134  vmovaps xmm5, [rsp+0x50]
0000714ce89d213a  vmovaps xmm6, [rsp+0x60]
0000714ce89d2140  vmovaps xmm7, [rsp+0x70]
0000714ce89d2146  vmovaps xmm8, [rsp+0x80]
0000714ce89d214f  vmovaps xmm9, [rsp+0x90]
0000714ce89d2158  vmovaps xmm10, [rsp+0xA0]
0000714ce89d2161  vmovaps xmm11, [rsp+0xB0]
0000714ce89d216a  vmovaps xmm12, [rsp+0xC0]
0000714ce89d2173  vmovaps xmm14, [rsp+0xD0]
0000714ce89d217c  vmovaps xmm15, [rsp+0xE0]
0000714ce89d2185  add rsp, 0xF0
0000714ce89d218c  pop r11
0000714ce89d218e  pop r10
0000714ce89d2190  pop r9
0000714ce89d2192  pop r8
0000714ce89d2194  pop rsi
0000714ce89d2195  pop rdi
0000714ce89d2196  pop rdx
0000714ce89d2197  pop rcx
0000714ce89d2198  pop rax
0000714ce89d2199  add rsp, 0x08
0000714ce89d219d  jmp 0x0000714CE89D1F81
0000714ce89d21a2  call 0x0000714CE88C2240
0000714ce89d21a7  jmp 0x0000714CE89D1F9B
0000714ce89d21ac  sub rsp, 0x08
0000714ce89d21b0  push rax
0000714ce89d21b1  push rcx
0000714ce89d21b2  push rdx
0000714ce89d21b3  push rdi
0000714ce89d21b4  push rsi
0000714ce89d21b5  push r8
0000714ce89d21b7  push r9
0000714ce89d21b9  push r10
0000714ce89d21bb  push r11
0000714ce89d21bd  sub rsp, 0xF0
0000714ce89d21c4  vmovaps [rsp], xmm0
0000714ce89d21c9  vmovaps [rsp+0x10], xmm1
0000714ce89d21cf  vmovaps [rsp+0x20], xmm2
0000714ce89d21d5  vmovaps [rsp+0x30], xmm3
0000714ce89d21db  vmovaps [rsp+0x40], xmm4
0000714ce89d21e1  vmovaps [rsp+0x50], xmm5
0000714ce89d21e7  vmovaps [rsp+0x60], xmm6
0000714ce89d21ed  vmovaps [rsp+0x70], xmm7
0000714ce89d21f3  vmovaps [rsp+0x80], xmm8
0000714ce89d21fc  vmovaps [rsp+0x90], xmm9
0000714ce89d2205  vmovaps [rsp+0xA0], xmm10
0000714ce89d220e  vmovaps [rsp+0xB0], xmm11
0000714ce89d2217  vmovaps [rsp+0xC0], xmm12
0000714ce89d2220  vmovaps [rsp+0xD0], xmm13
0000714ce89d2229  vmovaps [rsp+0xE0], xmm15
0000714ce89d2232  sub rsp, 0x30
0000714ce89d2236  movaps [rsp], xmm14
0000714ce89d223b  movaps [rsp+0x10], xmm1
0000714ce89d2240  movaps [rsp+0x20], xmm15
0000714ce89d2246  lea rdi, [rsp]
0000714ce89d224a  mov esi, 0x00
0000714ce89d224f  mov rax, 0x57A55D340530
0000714ce89d2259  call rax
0000714ce89d225b  movaps xmm14, [rsp]
0000714ce89d2260  add rsp, 0x30
0000714ce89d2264  vmovaps xmm0, [rsp]
0000714ce89d2269  vmovaps xmm1, [rsp+0x10]
0000714ce89d226f  vmovaps xmm2, [rsp+0x20]
0000714ce89d2275  vmovaps xmm3, [rsp+0x30]
0000714ce89d227b  vmovaps xmm4, [rsp+0x40]
0000714ce89d2281  vmovaps xmm5, [rsp+0x50]
0000714ce89d2287  vmovaps xmm6, [rsp+0x60]
0000714ce89d228d  vmovaps xmm7, [rsp+0x70]
0000714ce89d2293  vmovaps xmm8, [rsp+0x80]
0000714ce89d229c  vmovaps xmm9, [rsp+0x90]
0000714ce89d22a5  vmovaps xmm10, [rsp+0xA0]
0000714ce89d22ae  vmovaps xmm11, [rsp+0xB0]
0000714ce89d22b7  vmovaps xmm12, [rsp+0xC0]
0000714ce89d22c0  vmovaps xmm13, [rsp+0xD0]
0000714ce89d22c9  vmovaps xmm15, [rsp+0xE0]
0000714ce89d22d2  add rsp, 0xF0
0000714ce89d22d9  pop r11
0000714ce89d22db  pop r10
0000714ce89d22dd  pop r9
0000714ce89d22df  pop r8
0000714ce89d22e1  pop rsi
0000714ce89d22e2  pop rdi
0000714ce89d22e3  pop rdx
0000714ce89d22e4  pop rcx
0000714ce89d22e5  pop rax
0000714ce89d22e6  add rsp, 0x08
0000714ce89d22ea  jmp 0x0000714CE89D1FBE
0000714ce89d22ef  call 0x0000714CE88C34C0
0000714ce89d22f4  jmp 0x0000714CE89D1FD4
0000714ce89d22f9  int3
0000714ce89d22fa  nop [rax+rax*1], ax
0000714ce89d2300  mov rax, [r15+0x50]
0000714ce89d2304  lea r14, [rax+0x80]
0000714ce89d230b  movups xmm1, [r13+r14*1]
0000714ce89d2311  lea r14, [rax+0x90]
0000714ce89d2318  movups xmm15, [r13+r14*1]
0000714ce89d231e  vxorps xmm14, xmm14, xmm14
0000714ce89d2323  vpbroadcastq xmm14, xmm14
0000714ce89d2328  lea r14, [rax+0x40]
0000714ce89d232c  movups xmm13, [r13+r14*1]
0000714ce89d2332  lea r14, [rax+0x50]
0000714ce89d2336  movups xmm12, [r13+r14*1]
0000714ce89d233c  mov qword ptr [r15+0x48], 0x00
0000714ce89d2344  movups xmm11, [r13+rax*1]
0000714ce89d234a  lea r14, [rax+0x10]
0000714ce89d234e  movups xmm10, [r13+r14*1]
0000714ce89d2354  mov r14, [r15+0xF8]
0000714ce89d235b  lea r12, [r14+0xE0]
0000714ce89d2362  movups [r13+r12*1], xmm15
0000714ce89d2368  lea r12, [r14+0xF0]
0000714ce89d236f  movups [r13+r12*1], xmm1
0000714ce89d2375  lea r12, [rax+0xC0]
0000714ce89d237c  movups xmm1, [r13+r12*1]
0000714ce89d2382  lea r12, [rax+0xD0]
0000714ce89d2389  movups xmm15, [r13+r12*1]
0000714ce89d238f  lea r12, [rax+0x140]
0000714ce89d2396  movups xmm9, [r13+r12*1]
0000714ce89d239c  lea r12, [rax+0x150]
0000714ce89d23a3  movups xmm8, [r13+r12*1]
0000714ce89d23a9  lea r12, [rax+0x180]
0000714ce89d23b0  movups xmm7, [r13+r12*1]
0000714ce89d23b6  lea r12, [rax+0x190]
0000714ce89d23bd  movups xmm6, [r13+r12*1]
0000714ce89d23c3  lea r12, [r14+0xC0]
0000714ce89d23ca  movups [r13+r12*1], xmm15
0000714ce89d23d0  lea r12, [r14+0xD0]
0000714ce89d23d7  movups [r13+r12*1], xmm1
0000714ce89d23dd  lea r12, [rax+0x100]
0000714ce89d23e4  movups xmm1, [r13+r12*1]
0000714ce89d23ea  lea r12, [rax+0x110]
0000714ce89d23f1  movups xmm15, [r13+r12*1]
0000714ce89d23f7  lea r12, [rax+0x1C0]
0000714ce89d23fe  movups xmm5, [r13+r12*1]
0000714ce89d2404  lea r12, [rax+0x1D0]
0000714ce89d240b  movups xmm4, [r13+r12*1]
0000714ce89d2411  lea r12, [rax+0x20]
0000714ce89d2415  movups xmm3, [r13+r12*1]
0000714ce89d241b  lea r12, [rax+0x30]
0000714ce89d241f  movups xmm2, [r13+r12*1]
0000714ce89d2425  movaps [r15+0x1F0], xmm2
0000714ce89d242d  lea r12, [r14+0x20]
0000714ce89d2431  movups [r13+r12*1], xmm1
0000714ce89d2437  lea r12, [r14+0x30]
0000714ce89d243b  movups [r13+r12*1], xmm12
0000714ce89d2441  lea r12, [rax+0x60]
0000714ce89d2445  movups xmm1, [r13+r12*1]
0000714ce89d244b  lea r12, [rax+0x70]
0000714ce89d244f  movups xmm12, [r13+r12*1]
0000714ce89d2455  lea r12, [r14+0x60]
0000714ce89d2459  movups [r13+r12*1], xmm11
0000714ce89d245f  lea r12, [r14+0x70]
0000714ce89d2463  movups [r13+r12*1], xmm5
0000714ce89d2469  lea r12, [rax+0xE0]
0000714ce89d2470  movups xmm11, [r13+r12*1]
0000714ce89d2476  lea r12, [rax+0xF0]
0000714ce89d247d  movups xmm5, [r13+r12*1]
0000714ce89d2483  lea r12, [rax+0x120]
0000714ce89d248a  vmovaps [rsp+0x10], xmm1
0000714ce89d2490  movups xmm1, [r13+r12*1]
0000714ce89d2496  lea r12, [rax+0x130]
0000714ce89d249d  vmovaps [rsp+0x20], xmm1
0000714ce89d24a3  movups xmm1, [r13+r12*1]
0000714ce89d24a9  lea r12, [r14+0xA0]
0000714ce89d24b0  movups [r13+r12*1], xmm12
0000714ce89d24b6  lea r12, [r14+0xB0]
0000714ce89d24bd  vmovaps xmm12, [rsp+0x10]
0000714ce89d24c3  movups [r13+r12*1], xmm12
0000714ce89d24c9  lea r12, [rax+0xA0]
0000714ce89d24d0  movups xmm12, [r13+r12*1]
0000714ce89d24d6  lea r12, [rax+0xB0]
0000714ce89d24dd  vmovaps [rsp+0x10], xmm1
0000714ce89d24e3  movups xmm1, [r13+r12*1]
0000714ce89d24e9  lea r12, [rax+0x160]
0000714ce89d24f0  vmovaps [rsp+0x30], xmm1
0000714ce89d24f6  movups xmm1, [r13+r12*1]
0000714ce89d24fc  lea r12, [rax+0x170]
0000714ce89d2503  vmovaps [rsp+0x40], xmm1
0000714ce89d2509  movups xmm1, [r13+r12*1]
0000714ce89d250f  movaps [r15+0x2B0], xmm1
0000714ce89d2517  lea r12, [rax+0x1A0]
0000714ce89d251e  vmovaps [rsp+0x50], xmm1
0000714ce89d2524  movups xmm1, [r13+r12*1]
0000714ce89d252a  lea r12, [rax+0x1B0]
0000714ce89d2531  vmovaps [rsp+0x60], xmm1
0000714ce89d2537  movups xmm1, [r13+r12*1]
0000714ce89d253d  vmovaps [rsp+0x70], xmm1
0000714ce89d2543  vmovaps xmm1, [rsp+0x60]
0000714ce89d2549  movaps [r15+0x290], xmm1
0000714ce89d2551  vmovaps [rsp+0x60], xmm1
0000714ce89d2557  vmovaps xmm1, [rsp+0x70]
0000714ce89d255d  movaps [r15+0x1E0], xmm1
0000714ce89d2565  lea r12, [r14+0x80]
0000714ce89d256c  vmovaps [rsp+0x70], xmm1
0000714ce89d2572  vmovaps xmm1, [rsp+0x30]
0000714ce89d2578  movups [r13+r12*1], xmm1
0000714ce89d257e  lea r12, [r14+0x90]
0000714ce89d2585  movups [r13+r12*1], xmm12
0000714ce89d258b  lea r12, [rax+0x1E0]
0000714ce89d2592  movups xmm1, [r13+r12*1]
0000714ce89d2598  lea r12, [rax+0x1F0]
0000714ce89d259f  movups xmm12, [r13+r12*1]
0000714ce89d25a5  mov qword ptr [r15+0x50], 0x432200
0000714ce89d25ad  lea rax, [r14+0x40]
0000714ce89d25b1  vmovaps [rsp+0x30], xmm1
0000714ce89d25b7  vmovaps xmm1, [rsp+0x40]
0000714ce89d25bd  movups [r13+rax*1], xmm1
0000714ce89d25c3  lea rax, [r14+0x50]
0000714ce89d25c7  movups [r13+rax*1], xmm10
0000714ce89d25cd  movups [r13+r14*1], xmm12
0000714ce89d25d3  lea rax, [r14+0x10]
0000714ce89d25d7  vmovaps xmm1, [rsp+0x30]
0000714ce89d25dd  movups [r13+rax*1], xmm1
0000714ce89d25e3  mov rax, [r15+0x40]
0000714ce89d25e7  vmovaps [rsp+0x30], xmm3
0000714ce89d25ed  vmovaps xmm1, [rsp+0x30]
0000714ce89d25f3  por xmm3, xmm1
0000714ce89d25f7  vmovaps [rsp+0x30], xmm6
0000714ce89d25fd  vmovaps xmm12, [rsp+0x30]
0000714ce89d2603  por xmm6, xmm12
0000714ce89d2608  lea r12, [rax+0x30]
0000714ce89d260c  mov r11, [r13+r12*1]
0000714ce89d2611  lea r12, [rax+0x38]
0000714ce89d2615  mov r10, [r13+r12*1]
0000714ce89d261a  movq xmm12, r11
0000714ce89d261f  movq xmm10, r10
0000714ce89d2624  movq xmm12, xmm12
0000714ce89d2629  vmovaps [rsp+0x30], xmm12
0000714ce89d262f  movq xmm12, xmm12
0000714ce89d2634  movaps [r15+0x130], xmm12
0000714ce89d263c  movq xmm10, xmm10
0000714ce89d2641  vmovaps [rsp+0x40], xmm10
0000714ce89d2647  movq xmm10, xmm10
0000714ce89d264c  movaps [r15+0x280], xmm10
0000714ce89d2654  vmovaps [rsp+0x80], xmm9
0000714ce89d265d  vmovaps xmm12, [rsp+0x80]
0000714ce89d2666  por xmm9, xmm12
0000714ce89d266b  lea r12, [rax+0x20]
0000714ce89d266f  mov r11, [r13+r12*1]
0000714ce89d2674  lea r12, [rax+0x28]
0000714ce89d2678  mov r10, [r13+r12*1]
0000714ce89d267d  movq xmm12, r11
0000714ce89d2682  movq xmm10, r10
0000714ce89d2687  movq xmm12, xmm12
0000714ce89d268c  vmovaps [rsp+0x80], xmm12
0000714ce89d2695  movq xmm12, xmm12
0000714ce89d269a  movaps [r15+0x150], xmm12
0000714ce89d26a2  movq xmm10, xmm10
0000714ce89d26a7  vmovaps [rsp+0x90], xmm10
0000714ce89d26b0  movq xmm10, xmm10
0000714ce89d26b5  movaps [r15+0x140], xmm10
0000714ce89d26bd  lea r12, [rax+0x10]
0000714ce89d26c1  mov r11, [r13+r12*1]
0000714ce89d26c6  lea r12, [rax+0x18]
0000714ce89d26ca  mov r10, [r13+r12*1]
0000714ce89d26cf  movq xmm12, r11
0000714ce89d26d4  movq xmm10, r10
0000714ce89d26d9  movq xmm12, xmm12
0000714ce89d26de  vmovaps [rsp+0xA0], xmm12
0000714ce89d26e7  movq xmm12, xmm12
0000714ce89d26ec  movaps [r15+0x170], xmm12
0000714ce89d26f4  movq xmm10, xmm10
0000714ce89d26f9  vmovaps [rsp+0xB0], xmm10
0000714ce89d2702  movq xmm10, xmm10
0000714ce89d2707  movaps [r15+0x160], xmm10
0000714ce89d270f  mov r12, [r13+rax*1]
0000714ce89d2714  vmovq xmm12, r12
0000714ce89d2719  vpbroadcastq xmm12, xmm12
0000714ce89d271e  lea r12, [rax+0x08]
0000714ce89d2722  mov rax, [r13+r12*1]
0000714ce89d2727  movq xmm10, rax
0000714ce89d272c  movaps [r15+0x230], xmm10
0000714ce89d2734  lea rax, [r14+0x50]
0000714ce89d2738  movups xmm10, [r13+rax*1]
0000714ce89d273e  lea rax, [r14+0x60]
0000714ce89d2742  vmovaps [rsp+0xC0], xmm1
0000714ce89d274b  movups xmm1, [r13+rax*1]
0000714ce89d2751  lea rax, [r14+0x30]
0000714ce89d2755  vmovaps [rsp+0xD0], xmm1
0000714ce89d275e  movups xmm1, [r13+rax*1]
0000714ce89d2764  mov qword ptr [r15+0x60], 0x432200
0000714ce89d276c  mov qword ptr [r15+0x58], 0x40
0000714ce89d2774  vmovaps [rsp+0xE0], xmm1
0000714ce89d277d  vmovaps [rsp+0xF0], xmm15
0000714ce89d2786  vmovaps xmm15, [rsp+0xC0]
0000714ce89d278f  vmovaps [rsp+0xC0], xmm14
0000714ce89d2798  movaps xmm1, xmm12
0000714ce89d279c  mulpd xmm1, xmm15
0000714ce89d27a1  vcmppd xmm14, xmm1, xmm1, 0x03
0000714ce89d27a6  ptest xmm14, xmm14
0000714ce89d27ac  jnz 0x0000714CE89D3863
0000714ce89d27b2  movq xmm15, qword ptr [r15+0x230]
0000714ce89d27bb  vmovaps [rsp+0x100], xmm15
0000714ce89d27c4  vpermilpd xmm15, xmm15, 0x00
0000714ce89d27ca  vmovaps [rsp+0x110], xmm1
0000714ce89d27d3  vmovaps xmm1, [rsp+0xE0]
0000714ce89d27dc  vmovaps [rsp+0xE0], xmm13
0000714ce89d27e5  movaps xmm14, xmm1
0000714ce89d27e9  mulpd xmm14, xmm15
0000714ce89d27ee  vcmppd xmm13, xmm14, xmm14, 0x03
0000714ce89d27f4  ptest xmm13, xmm13
0000714ce89d27fa  jnz 0x0000714CE89D39A5
0000714ce89d2800  vxorps xmm1, xmm1, xmm1
0000714ce89d2804  vpbroadcastq xmm1, xmm1
0000714ce89d2809  vmovaps xmm13, [rsp+0xD0]
0000714ce89d2812  vmovaps [rsp+0xD0], xmm1
0000714ce89d281b  movaps xmm15, xmm12
0000714ce89d281f  mulpd xmm15, xmm13
0000714ce89d2824  vcmppd xmm1, xmm15, xmm15, 0x03
0000714ce89d282a  ptest xmm1, xmm1
0000714ce89d282f  jnz 0x0000714CE89D3AE8
0000714ce89d2835  movaps xmm1, xmm12
0000714ce89d2839  mulpd xmm1, xmm10
0000714ce89d283e  vcmppd xmm13, xmm1, xmm1, 0x03
0000714ce89d2843  ptest xmm13, xmm13
0000714ce89d2849  jnz 0x0000714CE89D3C2C
0000714ce89d284f  movaps xmm13, xmm12
0000714ce89d2853  mulpd xmm13, xmm2
0000714ce89d2858  vcmppd xmm10, xmm13, xmm13, 0x03
0000714ce89d285e  ptest xmm10, xmm10
0000714ce89d2864  jnz 0x0000714CE89D3D6E
0000714ce89d286a  vmovaps [rsp+0x120], xmm7
0000714ce89d2873  vmovaps xmm12, [rsp+0x120]
0000714ce89d287c  por xmm7, xmm12
0000714ce89d2881  vmovaps xmm12, [rsp+0xE0]
0000714ce89d288a  vmovaps xmm10, [rsp+0xE0]
0000714ce89d2893  por xmm12, xmm10
0000714ce89d2898  vmovaps xmm2, [rsp+0x100]
0000714ce89d28a1  vpermilpd xmm2, xmm2, 0x00
0000714ce89d28a7  vmovaps [rsp+0xE0], xmm1
0000714ce89d28b0  vmovaps [rsp+0x120], xmm15
0000714ce89d28b9  movaps xmm1, xmm10
0000714ce89d28bd  mulpd xmm1, xmm2
0000714ce89d28c1  vcmppd xmm15, xmm1, xmm1, 0x03
0000714ce89d28c6  ptest xmm15, xmm15
0000714ce89d28cc  jnz 0x0000714CE89D3EB1
0000714ce89d28d2  xor eax, eax
0000714ce89d28d4  mov r12d, 0x40
0000714ce89d28da  mov r11d, 0x200
0000714ce89d28e0  cmp r12, r11
0000714ce89d28e3  cmc
0000714ce89d28e4  lahf
0000714ce89d28e5  seto al
0000714ce89d28e8  mov [r15+0x108], eax
0000714ce89d28ef  vmovaps xmm10, [rsp+0x110]
0000714ce89d28f8  vmovaps xmm2, [rsp+0xD0]
0000714ce89d2901  vmovaps [rsp+0xD0], xmm1
0000714ce89d290a  movaps xmm15, xmm10
0000714ce89d290e  addpd xmm15, xmm2
0000714ce89d2913  vcmppd xmm1, xmm15, xmm15, 0x03
0000714ce89d2919  ptest xmm1, xmm1
0000714ce89d291e  jnz 0x0000714CE89D3FF2
0000714ce89d2924  vmovaps xmm10, [rsp+0x120]
0000714ce89d292d  vmovaps [rsp+0x110], xmm15
0000714ce89d2936  vmovaps xmm15, [rsp+0xC0]
0000714ce89d293f  vmovaps [rsp+0xC0], xmm14
0000714ce89d2948  movaps xmm1, xmm10
0000714ce89d294c  addpd xmm1, xmm15
0000714ce89d2951  vcmppd xmm14, xmm1, xmm1, 0x03
0000714ce89d2956  ptest xmm14, xmm14
0000714ce89d295c  jnz 0x0000714CE89D4135
0000714ce89d2962  vmovaps xmm10, [rsp+0xE0]
0000714ce89d296b  vmovaps [rsp+0xE0], xmm1
0000714ce89d2974  movaps xmm14, xmm10
0000714ce89d2978  addpd xmm14, xmm15
0000714ce89d297d  vcmppd xmm1, xmm14, xmm14, 0x03
0000714ce89d2983  ptest xmm1, xmm1
0000714ce89d2988  jnz 0x0000714CE89D4277
0000714ce89d298e  vmovaps xmm1, [rsp+0x10]
0000714ce89d2994  vmovaps xmm15, [rsp+0x10]
0000714ce89d299a  por xmm1, xmm15
0000714ce89d299f  vmovaps xmm15, [rsp+0x20]
0000714ce89d29a5  vmovaps xmm10, [rsp+0x20]
0000714ce89d29ab  por xmm15, xmm10
0000714ce89d29b0  vmovaps [rsp+0x10], xmm5
0000714ce89d29b6  vmovaps xmm10, [rsp+0x10]
0000714ce89d29bc  por xmm5, xmm10
0000714ce89d29c1  vmovaps [rsp+0x10], xmm11
0000714ce89d29c7  vmovaps xmm10, [rsp+0x10]
0000714ce89d29cd  por xmm11, xmm10
0000714ce89d29d2  vmovaps [rsp+0x10], xmm4
0000714ce89d29d8  vmovaps xmm10, [rsp+0x10]
0000714ce89d29de  por xmm4, xmm10
0000714ce89d29e3  vmovaps [rsp+0x10], xmm8
0000714ce89d29e9  vmovaps xmm10, [rsp+0x10]
0000714ce89d29ef  por xmm8, xmm10
0000714ce89d29f4  vmovaps xmm10, [rsp+0xF0]
0000714ce89d29fd  vmovaps [rsp+0x10], xmm1
0000714ce89d2a03  vmovaps xmm1, [rsp+0xF0]
0000714ce89d2a0c  por xmm10, xmm1
0000714ce89d2a11  lea rax, [r14+0xA0]
0000714ce89d2a18  movups xmm1, [r13+rax*1]
0000714ce89d2a1e  lea rax, [r14+0xB0]
0000714ce89d2a25  vmovaps [rsp+0x20], xmm1
0000714ce89d2a2b  movups xmm1, [r13+rax*1]
0000714ce89d2a31  vmovaps [rsp+0xF0], xmm1
0000714ce89d2a3a  vmovaps [rsp+0x120], xmm15
0000714ce89d2a43  movaps xmm1, xmm13
0000714ce89d2a47  addpd xmm1, xmm2
0000714ce89d2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
0000714ce89d2a50  ptest xmm15, xmm15
0000714ce89d2a56  jnz 0x0000714CE89D43CF
0000714ce89d2a5c  lea rax, [r14+0xF0]
0000714ce89d2a63  movups xmm15, [r13+rax*1]
0000714ce89d2a69  vmovaps xmm2, [rsp+0xE0]
0000714ce89d2a72  vmovaps [rsp+0xE0], xmm1
0000714ce89d2a7b  vmovaps xmm1, [rsp+0xD0]
0000714ce89d2a84  vmovaps [rsp+0xD0], xmm15
0000714ce89d2a8d  movaps xmm13, xmm2
0000714ce89d2a91  addpd xmm13, xmm1
0000714ce89d2a96  vcmppd xmm15, xmm13, xmm13, 0x03
0000714ce89d2a9c  ptest xmm15, xmm15
0000714ce89d2aa2  jnz 0x0000714CE89D451A
0000714ce89d2aa8  vmovaps xmm15, [rsp+0xC0]
0000714ce89d2ab1  movaps xmm1, xmm14
0000714ce89d2ab5  addpd xmm1, xmm15
0000714ce89d2aba  vcmppd xmm2, xmm1, xmm1, 0x03
0000714ce89d2abf  ptest xmm2, xmm2
0000714ce89d2ac4  jnz 0x0000714CE89D465C
0000714ce89d2aca  vmovaps xmm15, [rsp+0x100]
0000714ce89d2ad3  vpermilpd xmm15, xmm15, 0x00
0000714ce89d2ad9  vmovaps xmm2, [rsp+0xF0]
0000714ce89d2ae2  vmovaps [rsp+0xC0], xmm1
0000714ce89d2aeb  movaps xmm14, xmm2
0000714ce89d2aef  mulpd xmm14, xmm15
0000714ce89d2af4  vcmppd xmm1, xmm14, xmm14, 0x03
0000714ce89d2afa  ptest xmm1, xmm1
0000714ce89d2aff  jnz 0x0000714CE89D479E
0000714ce89d2b05  vmovaps xmm1, [rsp+0xA0]
0000714ce89d2b0e  vpermilpd xmm1, xmm1, 0x00
0000714ce89d2b14  vmovaps xmm2, [rsp+0xD0]
0000714ce89d2b1d  vmovaps [rsp+0xD0], xmm14
0000714ce89d2b26  movaps xmm15, xmm2
0000714ce89d2b2a  mulpd xmm15, xmm1
0000714ce89d2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
0000714ce89d2b35  ptest xmm14, xmm14
0000714ce89d2b3b  jnz 0x0000714CE89D48E1
0000714ce89d2b41  lea rax, [r14+0xE0]
0000714ce89d2b48  movups xmm1, [r13+rax*1]
0000714ce89d2b4e  vmovaps xmm14, [rsp+0x100]
0000714ce89d2b57  vpermilpd xmm14, xmm14, 0x00
0000714ce89d2b5d  vmovaps [rsp+0xF0], xmm1
0000714ce89d2b66  vmovaps xmm1, [rsp+0x20]
0000714ce89d2b6c  vmovaps [rsp+0x20], xmm15
0000714ce89d2b72  movaps xmm2, xmm1
0000714ce89d2b75  mulpd xmm2, xmm14
0000714ce89d2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
0000714ce89d2b7f  ptest xmm15, xmm15
0000714ce89d2b85  jnz 0x0000714CE89D4A2D
0000714ce89d2b8b  vmovaps [rsp+0x100], xmm10
0000714ce89d2b94  vmovaps xmm1, [rsp+0x100]
0000714ce89d2b9d  por xmm10, xmm1
0000714ce89d2ba2  movaps [r15+0x300], xmm10
0000714ce89d2baa  vmovaps [rsp+0x100], xmm8
0000714ce89d2bb3  vmovaps xmm1, [rsp+0x100]
0000714ce89d2bbc  por xmm8, xmm1
0000714ce89d2bc1  movaps [r15+0x190], xmm8
0000714ce89d2bc9  vmovaps xmm1, [rsp+0xA0]
0000714ce89d2bd2  vpermilpd xmm1, xmm1, 0x00
0000714ce89d2bd8  vmovaps xmm14, [rsp+0xF0]
0000714ce89d2be1  vmovaps [rsp+0xF0], xmm13
0000714ce89d2bea  movaps xmm15, xmm14
0000714ce89d2bee  mulpd xmm15, xmm1
0000714ce89d2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
0000714ce89d2bf9  ptest xmm13, xmm13
0000714ce89d2bff  jnz 0x0000714CE89D4B6E
0000714ce89d2c05  lea rax, [r14+0x90]
0000714ce89d2c0c  movups xmm1, [r13+rax*1]
0000714ce89d2c12  vmovaps [rsp+0x100], xmm4
0000714ce89d2c1b  vmovaps xmm14, [rsp+0x100]
0000714ce89d2c24  por xmm4, xmm14
0000714ce89d2c29  movaps [r15+0x1C0], xmm4
0000714ce89d2c31  vmovaps [rsp+0x100], xmm11
0000714ce89d2c3a  vmovaps xmm14, [rsp+0x100]
0000714ce89d2c43  por xmm11, xmm14
0000714ce89d2c48  movaps [r15+0x200], xmm11
0000714ce89d2c50  vmovaps [rsp+0x100], xmm5
0000714ce89d2c59  vmovaps xmm14, [rsp+0x100]
0000714ce89d2c62  por xmm5, xmm14
0000714ce89d2c67  movaps [r15+0x2D0], xmm5
0000714ce89d2c6f  vmovaps xmm14, [rsp+0x120]
0000714ce89d2c78  vmovaps xmm13, [rsp+0x120]
0000714ce89d2c81  por xmm14, xmm13
0000714ce89d2c86  movaps [r15+0x2E0], xmm14
0000714ce89d2c8e  vmovaps [rsp+0x100], xmm1
0000714ce89d2c97  vmovaps xmm1, [rsp+0x110]
0000714ce89d2ca0  vmovaps [rsp+0x110], xmm15
0000714ce89d2ca9  vmovaps xmm15, [rsp+0xD0]
0000714ce89d2cb2  vmovaps [rsp+0xD0], xmm14
0000714ce89d2cbb  movaps xmm13, xmm1
0000714ce89d2cbf  addpd xmm13, xmm15
0000714ce89d2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
0000714ce89d2cca  ptest xmm14, xmm14
0000714ce89d2cd0  jnz 0x0000714CE89D4CBB
0000714ce89d2cd6  vmovaps xmm1, [rsp+0xA0]
0000714ce89d2cdf  vpermilpd xmm1, xmm1, 0x00
0000714ce89d2ce5  vmovaps xmm14, [rsp+0x100]
0000714ce89d2cee  vmovaps [rsp+0x100], xmm13
0000714ce89d2cf7  movaps xmm15, xmm14
0000714ce89d2cfb  mulpd xmm15, xmm1
0000714ce89d2d00  vcmppd xmm13, xmm15, xmm15, 0x03
0000714ce89d2d06  ptest xmm13, xmm13
0000714ce89d2d0c  jnz 0x0000714CE89D4DFE
0000714ce89d2d12  lea rax, [r14+0x80]
0000714ce89d2d19  movups xmm1, [r13+rax*1]
0000714ce89d2d1f  vmovaps xmm13, [rsp+0xE0]
0000714ce89d2d28  vmovaps [rsp+0xE0], xmm1
0000714ce89d2d31  movaps xmm14, xmm13
0000714ce89d2d35  addpd xmm14, xmm2
0000714ce89d2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
0000714ce89d2d40  ptest xmm1, xmm1
0000714ce89d2d45  jnz 0x0000714CE89D4F4B
0000714ce89d2d4b  vmovaps xmm13, [rsp+0xF0]
0000714ce89d2d54  vmovaps xmm2, [rsp+0x20]
0000714ce89d2d5a  vmovaps [rsp+0x20], xmm15
0000714ce89d2d60  movaps xmm1, xmm13
0000714ce89d2d64  addpd xmm1, xmm2
0000714ce89d2d68  vcmppd xmm15, xmm1, xmm1, 0x03
0000714ce89d2d6d  ptest xmm15, xmm15
0000714ce89d2d73  jnz 0x0000714CE89D508E
0000714ce89d2d79  vmovaps xmm15, [rsp+0x10]
0000714ce89d2d7f  vmovaps xmm13, [rsp+0x10]
0000714ce89d2d85  por xmm15, xmm13
0000714ce89d2d8a  movaps [r15+0x2F0], xmm15
0000714ce89d2d92  vmovaps xmm13, [rsp+0xA0]
0000714ce89d2d9b  vpermilpd xmm13, xmm13, 0x00
0000714ce89d2da1  vmovaps [rsp+0x10], xmm1
0000714ce89d2da7  vmovaps xmm1, [rsp+0xE0]
0000714ce89d2db0  vmovaps [rsp+0xA0], xmm15
0000714ce89d2db9  movaps xmm2, xmm1
0000714ce89d2dbc  mulpd xmm2, xmm13
0000714ce89d2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
0000714ce89d2dc6  ptest xmm15, xmm15
0000714ce89d2dcc  jnz 0x0000714CE89D51CF
0000714ce89d2dd2  lea rax, [r14+0xD0]
0000714ce89d2dd9  movups xmm1, [r13+rax*1]
0000714ce89d2ddf  vmovaps xmm13, [rsp+0xC0]
0000714ce89d2de8  vmovaps [rsp+0xC0], xmm1
0000714ce89d2df1  vmovaps xmm1, [rsp+0x110]
0000714ce89d2dfa  vmovaps [rsp+0xE0], xmm14
0000714ce89d2e03  movaps xmm15, xmm13
0000714ce89d2e07  addpd xmm15, xmm1
0000714ce89d2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
0000714ce89d2e12  ptest xmm14, xmm14
0000714ce89d2e18  jnz 0x0000714CE89D531A
0000714ce89d2e1e  vmovaps xmm1, [rsp+0xB0]
0000714ce89d2e27  vpermilpd xmm1, xmm1, 0x00
0000714ce89d2e2d  movaps xmm14, xmm11
0000714ce89d2e31  mulpd xmm14, xmm1
0000714ce89d2e36  vcmppd xmm13, xmm14, xmm14, 0x03
0000714ce89d2e3c  ptest xmm13, xmm13
0000714ce89d2e42  jnz 0x0000714CE89D545D
0000714ce89d2e48  movaps [r15+0x260], xmm14
0000714ce89d2e50  vxorps xmm1, xmm1, xmm1
0000714ce89d2e54  vpbroadcastq xmm1, xmm1
0000714ce89d2e59  movaps [r15+0x1B0], xmm1
0000714ce89d2e61  vmovaps xmm1, [rsp+0xB0]
0000714ce89d2e6a  vpermilpd xmm1, xmm1, 0x00
0000714ce89d2e70  vmovaps xmm11, [rsp+0xC0]
0000714ce89d2e79  vmovaps [rsp+0xC0], xmm15
0000714ce89d2e82  movaps xmm13, xmm11
0000714ce89d2e86  mulpd xmm13, xmm1
0000714ce89d2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
0000714ce89d2e91  ptest xmm15, xmm15
0000714ce89d2e97  jnz 0x0000714CE89D55A0
0000714ce89d2e9d  lea rax, [r14+0xC0]
0000714ce89d2ea4  movups xmm1, [r13+rax*1]
0000714ce89d2eaa  vmovaps xmm11, [rsp+0x100]
0000714ce89d2eb3  vmovaps [rsp+0xF0], xmm1
0000714ce89d2ebc  vmovaps xmm1, [rsp+0x20]
0000714ce89d2ec2  vmovaps [rsp+0x20], xmm14
0000714ce89d2ec8  movaps xmm15, xmm11
0000714ce89d2ecc  addpd xmm15, xmm1
0000714ce89d2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
0000714ce89d2ed7  ptest xmm14, xmm14
0000714ce89d2edd  jnz 0x0000714CE89D56ED
0000714ce89d2ee3  vmovaps [rsp+0x100], xmm9
0000714ce89d2eec  vmovaps xmm1, [rsp+0x100]
0000714ce89d2ef5  por xmm9, xmm1
0000714ce89d2efa  movaps [r15+0x270], xmm9
0000714ce89d2f02  vmovaps [rsp+0x100], xmm6
0000714ce89d2f0b  vmovaps xmm1, [rsp+0x100]
0000714ce89d2f14  por xmm6, xmm1
0000714ce89d2f18  movaps [r15+0x1A0], xmm6
0000714ce89d2f20  vmovaps xmm14, [rsp+0xB0]
0000714ce89d2f29  vpermilpd xmm14, xmm14, 0x00
0000714ce89d2f2f  vmovaps xmm6, [rsp+0xF0]
0000714ce89d2f38  vmovaps [rsp+0xF0], xmm1
0000714ce89d2f41  movaps xmm11, xmm6
0000714ce89d2f45  mulpd xmm11, xmm14
0000714ce89d2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
0000714ce89d2f50  ptest xmm1, xmm1
0000714ce89d2f55  jnz 0x0000714CE89D5830
0000714ce89d2f5b  lea rax, [r14+0x20]
0000714ce89d2f5f  movups xmm1, [r13+rax*1]
0000714ce89d2f65  movaps [r15+0x110], xmm1
0000714ce89d2f6d  vmovaps xmm6, [rsp+0xE0]
0000714ce89d2f76  vmovaps [rsp+0xE0], xmm1
0000714ce89d2f7f  movaps xmm14, xmm6
0000714ce89d2f83  addpd xmm14, xmm2
0000714ce89d2f88  vcmppd xmm1, xmm14, xmm14, 0x03
0000714ce89d2f8e  ptest xmm1, xmm1
0000714ce89d2f93  jnz 0x0000714CE89D597D
0000714ce89d2f99  vmovaps xmm1, [rsp+0xB0]
0000714ce89d2fa2  vpermilpd xmm1, xmm1, 0x00
0000714ce89d2fa8  movaps xmm6, xmm5
0000714ce89d2fab  mulpd xmm6, xmm1
0000714ce89d2faf  vcmppd xmm2, xmm6, xmm6, 0x03
0000714ce89d2fb4  ptest xmm2, xmm2
0000714ce89d2fb9  jnz 0x0000714CE89D5ABF
0000714ce89d2fbf  vmovaps xmm5, [rsp+0x10]
0000714ce89d2fc5  movaps xmm1, xmm5
0000714ce89d2fc8  addpd xmm1, xmm13
0000714ce89d2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
0000714ce89d2fd2  ptest xmm2, xmm2
0000714ce89d2fd7  jnz 0x0000714CE89D5BFF
0000714ce89d2fdd  vmovaps xmm13, [rsp+0x80]
0000714ce89d2fe6  vpermilpd xmm13, xmm13, 0x00
0000714ce89d2fec  vmovaps xmm2, [rsp+0xE0]
0000714ce89d2ff5  vmovaps [rsp+0x10], xmm1
0000714ce89d2ffb  movaps xmm5, xmm2
0000714ce89d2ffe  mulpd xmm5, xmm13
0000714ce89d3003  vcmppd xmm1, xmm5, xmm5, 0x03
0000714ce89d3008  ptest xmm1, xmm1
0000714ce89d300d  jnz 0x0000714CE89D5D40
0000714ce89d3013  vmovaps xmm1, [rsp+0x80]
0000714ce89d301c  vpermilpd xmm1, xmm1, 0x00
0000714ce89d3022  movaps xmm13, xmm10
0000714ce89d3026  mulpd xmm13, xmm1
0000714ce89d302b  vcmppd xmm2, xmm13, xmm13, 0x03
0000714ce89d3031  ptest xmm2, xmm2
0000714ce89d3036  jnz 0x0000714CE89D5E81
0000714ce89d303c  vmovaps xmm10, [rsp+0x20]
0000714ce89d3042  movaps xmm1, xmm15
0000714ce89d3046  addpd xmm1, xmm10
0000714ce89d304b  vcmppd xmm2, xmm1, xmm1, 0x03
0000714ce89d3050  ptest xmm2, xmm2
0000714ce89d3055  jnz 0x0000714CE89D5FC4
0000714ce89d305b  vmovaps xmm10, [rsp+0xC0]
0000714ce89d3064  movaps xmm15, xmm10
0000714ce89d3068  addpd xmm15, xmm11
0000714ce89d306d  vcmppd xmm2, xmm15, xmm15, 0x03
0000714ce89d3073  ptest xmm2, xmm2
0000714ce89d3078  jnz 0x0000714CE89D6106
0000714ce89d307e  vmovaps xmm11, [rsp+0x80]
0000714ce89d3087  vpermilpd xmm11, xmm11, 0x00
0000714ce89d308d  vmovaps xmm2, [rsp+0xD0]
0000714ce89d3096  vmovaps [rsp+0x20], xmm1
0000714ce89d309c  movaps xmm10, xmm2
0000714ce89d30a0  mulpd xmm10, xmm11
0000714ce89d30a5  vcmppd xmm1, xmm10, xmm10, 0x03
0000714ce89d30ab  ptest xmm1, xmm1
0000714ce89d30b0  jnz 0x0000714CE89D624A
0000714ce89d30b6  vmovaps xmm1, [rsp+0x80]
0000714ce89d30bf  vpermilpd xmm1, xmm1, 0x00
0000714ce89d30c5  vmovaps xmm2, [rsp+0xA0]
0000714ce89d30ce  vmovaps [rsp+0x80], xmm15
0000714ce89d30d7  movaps xmm11, xmm2
0000714ce89d30db  mulpd xmm11, xmm1
0000714ce89d30e0  vcmppd xmm15, xmm11, xmm11, 0x03
0000714ce89d30e6  ptest xmm15, xmm15
0000714ce89d30ec  jnz 0x0000714CE89D638D
0000714ce89d30f2  movaps xmm1, xmm14
0000714ce89d30f6  addpd xmm1, xmm6
0000714ce89d30fa  vcmppd xmm15, xmm1, xmm1, 0x03
0000714ce89d30ff  ptest xmm15, xmm15
0000714ce89d3105  jnz 0x0000714CE89D64CF
0000714ce89d310b  vmovaps xmm14, [rsp+0x10]
0000714ce89d3111  movaps xmm15, xmm14
0000714ce89d3115  addpd xmm15, xmm5
0000714ce89d311a  vcmppd xmm6, xmm15, xmm15, 0x03
0000714ce89d3120  ptest xmm6, xmm6
0000714ce89d3125  jnz 0x0000714CE89D6610
0000714ce89d312b  vmovaps xmm14, [rsp+0x90]
0000714ce89d3134  vpermilpd xmm14, xmm14, 0x00
0000714ce89d313a  movaps xmm6, xmm9
0000714ce89d313e  mulpd xmm6, xmm14
0000714ce89d3143  vcmppd xmm5, xmm6, xmm6, 0x03
0000714ce89d3148  ptest xmm5, xmm5
0000714ce89d314d  jnz 0x0000714CE89D6753
0000714ce89d3153  vmovaps xmm9, [rsp+0x80]
0000714ce89d315c  movaps xmm14, xmm9
0000714ce89d3160  addpd xmm14, xmm13
0000714ce89d3165  vcmppd xmm5, xmm14, xmm14, 0x03
0000714ce89d316b  ptest xmm5, xmm5
0000714ce89d3170  jnz 0x0000714CE89D6895
0000714ce89d3176  vmovaps xmm9, [rsp+0x20]
0000714ce89d317c  movaps xmm13, xmm9
0000714ce89d3180  addpd xmm13, xmm10
0000714ce89d3185  vcmppd xmm5, xmm13, xmm13, 0x03
0000714ce89d318b  ptest xmm5, xmm5
0000714ce89d3190  jnz 0x0000714CE89D69D9
0000714ce89d3196  vmovaps [rsp+0x10], xmm12
0000714ce89d319c  vmovaps xmm10, [rsp+0x10]
0000714ce89d31a2  por xmm12, xmm10
0000714ce89d31a7  movaps [r15+0x250], xmm12
0000714ce89d31af  vmovaps [rsp+0x10], xmm7
0000714ce89d31b5  vmovaps xmm12, [rsp+0x10]
0000714ce89d31bb  por xmm7, xmm12
0000714ce89d31c0  movaps [r15+0x2A0], xmm7
0000714ce89d31c8  vmovaps [rsp+0x10], xmm3
0000714ce89d31ce  vmovaps xmm12, [rsp+0x10]
0000714ce89d31d4  por xmm3, xmm12
0000714ce89d31d9  movaps [r15+0x1D0], xmm3
0000714ce89d31e1  lea rax, [r14+0x40]
0000714ce89d31e5  movups xmm12, [r13+rax*1]
0000714ce89d31eb  movaps [r15+0x2C0], xmm12
0000714ce89d31f3  vmovaps xmm10, [rsp+0x90]
0000714ce89d31fc  vpermilpd xmm10, xmm10, 0x00
0000714ce89d3202  movaps xmm9, xmm8
0000714ce89d3206  mulpd xmm9, xmm10
0000714ce89d320b  vcmppd xmm5, xmm9, xmm9, 0x03
0000714ce89d3211  ptest xmm5, xmm5
0000714ce89d3216  jnz 0x0000714CE89D6B27
0000714ce89d321c  movaps xmm10, xmm1
0000714ce89d3220  addpd xmm10, xmm11
0000714ce89d3225  vcmppd xmm8, xmm10, xmm10, 0x03
0000714ce89d322b  ptest xmm8, xmm8
0000714ce89d3231  jnz 0x0000714CE89D6C6B
0000714ce89d3237  movaps xmm1, xmm15
0000714ce89d323b  addpd xmm1, xmm6
0000714ce89d323f  vcmppd xmm11, xmm1, xmm1, 0x03
0000714ce89d3244  ptest xmm11, xmm11
0000714ce89d324a  jnz 0x0000714CE89D6DAE
0000714ce89d3250  vmovaps xmm15, [rsp+0x90]
0000714ce89d3259  vpermilpd xmm15, xmm15, 0x00
0000714ce89d325f  movaps xmm11, xmm12
0000714ce89d3263  mulpd xmm11, xmm15
0000714ce89d3268  vcmppd xmm8, xmm11, xmm11, 0x03
0000714ce89d326e  ptest xmm8, xmm8
0000714ce89d3274  jnz 0x0000714CE89D6EEF
0000714ce89d327a  vmovaps xmm15, [rsp+0x90]
0000714ce89d3283  vpermilpd xmm15, xmm15, 0x00
0000714ce89d3289  vmovaps xmm8, [rsp+0x50]
0000714ce89d328f  movaps xmm12, xmm8
0000714ce89d3293  mulpd xmm12, xmm15
0000714ce89d3298  vcmppd xmm6, xmm12, xmm12, 0x03
0000714ce89d329e  ptest xmm6, xmm6
0000714ce89d32a3  jnz 0x0000714CE89D7033
0000714ce89d32a9  vmovaps xmm15, [rsp+0x30]
0000714ce89d32af  vpermilpd xmm15, xmm15, 0x00
0000714ce89d32b5  movaps xmm8, xmm7
0000714ce89d32b9  mulpd xmm8, xmm15
0000714ce89d32be  vcmppd xmm6, xmm8, xmm8, 0x03
0000714ce89d32c4  ptest xmm6, xmm6
0000714ce89d32c9  jnz 0x0000714CE89D7177
0000714ce89d32cf  movaps xmm15, xmm14
0000714ce89d32d3  addpd xmm15, xmm9
0000714ce89d32d8  vcmppd xmm7, xmm15, xmm15, 0x03
0000714ce89d32de  ptest xmm7, xmm7
0000714ce89d32e3  jnz 0x0000714CE89D72BA
0000714ce89d32e9  vmovaps xmm14, [rsp+0x30]
0000714ce89d32ef  vpermilpd xmm14, xmm14, 0x00
0000714ce89d32f5  vmovaps xmm7, [rsp+0xF0]
0000714ce89d32fe  movaps xmm9, xmm7
0000714ce89d3302  mulpd xmm9, xmm14
0000714ce89d3307  vcmppd xmm6, xmm9, xmm9, 0x03
0000714ce89d330d  ptest xmm6, xmm6
0000714ce89d3312  jnz 0x0000714CE89D73FE
0000714ce89d3318  movaps xmm14, xmm13
0000714ce89d331c  addpd xmm14, xmm11
0000714ce89d3321  vcmppd xmm7, xmm14, xmm14, 0x03
0000714ce89d3327  ptest xmm7, xmm7
0000714ce89d332c  jnz 0x0000714CE89D7541
0000714ce89d3332  vmovaps xmm13, [rsp+0x30]
0000714ce89d3338  vpermilpd xmm13, xmm13, 0x00
0000714ce89d333e  vmovaps xmm7, [rsp+0x60]
0000714ce89d3344  movaps xmm11, xmm7
0000714ce89d3348  mulpd xmm11, xmm13
0000714ce89d334d  vcmppd xmm6, xmm11, xmm11, 0x03
0000714ce89d3353  ptest xmm6, xmm6
0000714ce89d3358  jnz 0x0000714CE89D7685
0000714ce89d335e  movaps xmm13, xmm10
0000714ce89d3362  addpd xmm13, xmm12
0000714ce89d3367  vcmppd xmm7, xmm13, xmm13, 0x03
0000714ce89d336d  ptest xmm7, xmm7
0000714ce89d3372  jnz 0x0000714CE89D77C8
0000714ce89d3378  vmovaps xmm12, [rsp+0x30]
0000714ce89d337e  vpermilpd xmm12, xmm12, 0x00
0000714ce89d3384  vmovaps xmm7, [rsp+0x70]
0000714ce89d338a  movaps xmm10, xmm7
0000714ce89d338e  mulpd xmm10, xmm12
0000714ce89d3393  vcmppd xmm6, xmm10, xmm10, 0x03
0000714ce89d3399  ptest xmm6, xmm6
0000714ce89d339e  jnz 0x0000714CE89D790C
0000714ce89d33a4  movaps xmm12, xmm1
0000714ce89d33a8  addpd xmm12, xmm8
0000714ce89d33ad  vcmppd xmm7, xmm12, xmm12, 0x03
0000714ce89d33b3  ptest xmm7, xmm7
0000714ce89d33b8  jnz 0x0000714CE89D7A4F
0000714ce89d33be  lea rax, [r14+0x70]
0000714ce89d33c2  movups xmm1, [r13+rax*1]
0000714ce89d33c8  movaps [r15+0x240], xmm1
0000714ce89d33d0  movaps xmm8, xmm15
0000714ce89d33d4  addpd xmm8, xmm9
0000714ce89d33d9  vcmppd xmm7, xmm8, xmm8, 0x03
0000714ce89d33df  ptest xmm7, xmm7
0000714ce89d33e4  jnz 0x0000714CE89D7B9C
0000714ce89d33ea  movaps [r15+0x170], xmm8
0000714ce89d33f2  vmovaps xmm15, [rsp+0x40]
0000714ce89d33f8  vpermilpd xmm15, xmm15, 0x00
0000714ce89d33fe  movaps xmm9, xmm1
0000714ce89d3402  mulpd xmm9, xmm15
0000714ce89d3407  vcmppd xmm7, xmm9, xmm9, 0x03
0000714ce89d340d  ptest xmm7, xmm7
0000714ce89d3412  jnz 0x0000714CE89D7CE0
0000714ce89d3418  vmovaps xmm1, [rsp+0x40]
0000714ce89d341e  vpermilpd xmm1, xmm1, 0x00
0000714ce89d3424  movaps xmm15, xmm4
0000714ce89d3428  mulpd xmm15, xmm1
0000714ce89d342d  vcmppd xmm7, xmm15, xmm15, 0x03
0000714ce89d3433  ptest xmm7, xmm7
0000714ce89d3438  jnz 0x0000714CE89D7E23
0000714ce89d343e  movaps [r15+0x180], xmm15
0000714ce89d3446  movaps xmm1, xmm14
0000714ce89d344a  addpd xmm1, xmm11
0000714ce89d344f  vcmppd xmm7, xmm1, xmm1, 0x03
0000714ce89d3454  ptest xmm7, xmm7
0000714ce89d3459  jnz 0x0000714CE89D7F65
0000714ce89d345f  movaps [r15+0x210], xmm1
0000714ce89d3467  movups xmm14, [r13+r14*1]
0000714ce89d346d  lea rax, [r14+0x10]
0000714ce89d3471  movups xmm11, [r13+rax*1]
0000714ce89d3477  movaps [r15+0x230], xmm11
0000714ce89d347f  movaps xmm7, xmm13
0000714ce89d3483  addpd xmm7, xmm10
0000714ce89d3488  vcmppd xmm6, xmm7, xmm7, 0x03
0000714ce89d348d  ptest xmm6, xmm6
0000714ce89d3492  jnz 0x0000714CE89D80BB
0000714ce89d3498  movaps [r15+0x130], xmm7
0000714ce89d34a0  vmovaps xmm13, [rsp+0x40]
0000714ce89d34a6  vpermilpd xmm13, xmm13, 0x00
0000714ce89d34ac  movaps xmm10, xmm11
0000714ce89d34b0  mulpd xmm10, xmm13
0000714ce89d34b5  vcmppd xmm6, xmm10, xmm10, 0x03
0000714ce89d34bb  ptest xmm6, xmm6
0000714ce89d34c0  jnz 0x0000714CE89D81FD
0000714ce89d34c6  movaps [r15+0x220], xmm10
0000714ce89d34ce  vmovaps xmm13, [rsp+0x40]
0000714ce89d34d4  vpermilpd xmm13, xmm13, 0x00
0000714ce89d34da  movaps xmm11, xmm14
0000714ce89d34de  mulpd xmm11, xmm13
0000714ce89d34e3  vcmppd xmm6, xmm11, xmm11, 0x03
0000714ce89d34e9  ptest xmm6, xmm6
0000714ce89d34ee  jnz 0x0000714CE89D8341
0000714ce89d34f4  movaps xmm14, xmm12
0000714ce89d34f8  addpd xmm14, xmm9
0000714ce89d34fd  vcmppd xmm13, xmm14, xmm14, 0x03
0000714ce89d3503  ptest xmm13, xmm13
0000714ce89d3509  jnz 0x0000714CE89D8485
0000714ce89d350f  movaps [r15+0x140], xmm14
0000714ce89d3517  movaps xmm13, xmm8
0000714ce89d351b  addpd xmm13, xmm15
0000714ce89d3520  vcmppd xmm12, xmm13, xmm13, 0x03
0000714ce89d3526  ptest xmm12, xmm12
0000714ce89d352c  jnz 0x0000714CE89D85C9
0000714ce89d3532  movaps [r15+0x150], xmm13
0000714ce89d353a  movaps xmm15, xmm1
0000714ce89d353e  addpd xmm15, xmm10
0000714ce89d3543  vcmppd xmm12, xmm15, xmm15, 0x03
0000714ce89d3549  ptest xmm12, xmm12
0000714ce89d354f  jnz 0x0000714CE89D870D
0000714ce89d3555  movaps [r15+0x160], xmm15
0000714ce89d355d  movaps xmm1, xmm7
0000714ce89d3560  addpd xmm1, xmm11
0000714ce89d3565  vcmppd xmm12, xmm1, xmm1, 0x03
0000714ce89d356a  ptest xmm12, xmm12
0000714ce89d3570  jnz 0x0000714CE89D8850
0000714ce89d3576  movaps [r15+0x120], xmm1
0000714ce89d357e  mov eax, 0x432200
0000714ce89d3583  movups [r13+rax*1], xmm14
0000714ce89d3589  mov eax, 0x432210
0000714ce89d358e  movups [r13+rax*1], xmm13
0000714ce89d3594  mov eax, 0x432220
0000714ce89d3599  movups [r13+rax*1], xmm15
0000714ce89d359f  mov eax, 0x432230
0000714ce89d35a4  movups [r13+rax*1], xmm1
0000714ce89d35aa  mov eax, [r15+0x108]
0000714ce89d35b1  sahf
0000714ce89d35b2  jnz 0x0000714CE89D35E4
0000714ce89d35b4  cmp dword ptr [r15+0x318], 0x00
0000714ce89d35bc  jz 0x0000714CE89DEAE0
0000714ce89d35c2  nop [rax+rax*1], ax
0000714ce89d35cb  nop [rax+rax*1], eax
0000714ce89d35d3  mov eax, 0x4106D0
0000714ce89d35d8  mov [r15+0x100], rax
0000714ce89d35df  jmp 0x0000714CE87FE110
0000714ce89d35e4  cmp dword ptr [r15+0x318], 0x00
0000714ce89d35ec  jz 0x0000714CE89D89C0
0000714ce89d35f2  nop [rax+rax*1], ax
0000714ce89d35fb  nop [rax+rax*1], eax
0000714ce89d3603  mov eax, 0x410504
0000714ce89d3608  mov [r15+0x100], rax
0000714ce89d360f  jmp 0x0000714CE87FE110
0000714ce89d3614  int3
0000714ce89d3615  call 0x0000714CE88D64F0
0000714ce89d361a  jmp 0x0000714CE89D2311
0000714ce89d361f  call 0x0000714CE88E5820
0000714ce89d3624  jmp 0x0000714CE89D231E
0000714ce89d3629  call 0x0000714CE88E3320
0000714ce89d362e  jmp 0x0000714CE89D2332
0000714ce89d3633  call 0x0000714CE88E20A0
0000714ce89d3638  jmp 0x0000714CE89D233C
0000714ce89d363d  call 0x0000714CE8809D70
0000714ce89d3642  jmp 0x0000714CE89D234A
0000714ce89d3647  call 0x0000714CE88DFBC0
0000714ce89d364c  jmp 0x0000714CE89D2354
0000714ce89d3651  call 0x0000714CE88C4740
0000714ce89d3656  jmp 0x0000714CE89D2368
0000714ce89d365b  call 0x0000714CE88B5400
0000714ce89d3660  jmp 0x0000714CE89D2375
0000714ce89d3665  call 0x0000714CE88B52F0
0000714ce89d366a  jmp 0x0000714CE89D2382
0000714ce89d366f  call 0x0000714CE88C4620
0000714ce89d3674  jmp 0x0000714CE89D238F
0000714ce89d3679  call 0x0000714CE88BD750
0000714ce89d367e  jmp 0x0000714CE89D239C
0000714ce89d3683  call 0x0000714CE88BC4E0
0000714ce89d3688  jmp 0x0000714CE89D23A9
0000714ce89d368d  call 0x0000714CE88BB270
0000714ce89d3692  jmp 0x0000714CE89D23B6
0000714ce89d3697  call 0x0000714CE88BA000
0000714ce89d369c  jmp 0x0000714CE89D23C3
0000714ce89d36a1  call 0x0000714CE88C4740
0000714ce89d36a6  jmp 0x0000714CE89D23D0
0000714ce89d36ab  call 0x0000714CE88B5400
0000714ce89d36b0  jmp 0x0000714CE89D23DD
0000714ce89d36b5  call 0x0000714CE88B52F0
0000714ce89d36ba  jmp 0x0000714CE89D23EA
0000714ce89d36bf  call 0x0000714CE88C4620
0000714ce89d36c4  jmp 0x0000714CE89D23F7
0000714ce89d36c9  call 0x0000714CE88B8D90
0000714ce89d36ce  jmp 0x0000714CE89D2404
0000714ce89d36d3  call 0x0000714CE88B8A20
0000714ce89d36d8  jmp 0x0000714CE89D2411
0000714ce89d36dd  call 0x0000714CE88B77B0
0000714ce89d36e2  jmp 0x0000714CE89D241B
0000714ce89d36e7  call 0x0000714CE88B6550
0000714ce89d36ec  jmp 0x0000714CE89D2425
0000714ce89d36f1  call 0x0000714CE88B5400
0000714ce89d36f6  jmp 0x0000714CE89D2437
0000714ce89d36fb  call 0x0000714CE88C0FC0
0000714ce89d3700  jmp 0x0000714CE89D2441
0000714ce89d3705  call 0x0000714CE88B52F0
0000714ce89d370a  jmp 0x0000714CE89D244B
0000714ce89d370f  call 0x0000714CE88C0EA0
0000714ce89d3714  jmp 0x0000714CE89D2455
0000714ce89d3719  call 0x0000714CE88BFD50
0000714ce89d371e  jmp 0x0000714CE89D245F
0000714ce89d3723  call 0x0000714CE88B8EA0
0000714ce89d3728  jmp 0x0000714CE89D2469
0000714ce89d372d  call 0x0000714CE88BFC30
0000714ce89d3732  jmp 0x0000714CE89D2476
0000714ce89d3737  call 0x0000714CE88B8D90
0000714ce89d373c  jmp 0x0000714CE89D2483
0000714ce89d3741  call 0x0000714CE88B52F0
0000714ce89d3746  jmp 0x0000714CE89D2496
0000714ce89d374b  call 0x0000714CE88B52F0
0000714ce89d3750  jmp 0x0000714CE89D24A9
0000714ce89d3755  call 0x0000714CE88C0FC0
0000714ce89d375a  jmp 0x0000714CE89D24B6
0000714ce89d375f  call 0x0000714CE88C0FC0
0000714ce89d3764  jmp 0x0000714CE89D24C9
0000714ce89d3769  call 0x0000714CE88C0EA0
0000714ce89d376e  jmp 0x0000714CE89D24D6
0000714ce89d3773  call 0x0000714CE88B52F0
0000714ce89d3778  jmp 0x0000714CE89D24E9
0000714ce89d377d  call 0x0000714CE88B52F0
0000714ce89d3782  jmp 0x0000714CE89D24FC
0000714ce89d3787  call 0x0000714CE88B52F0
0000714ce89d378c  jmp 0x0000714CE89D250F
0000714ce89d3791  call 0x0000714CE88B52F0
0000714ce89d3796  jmp 0x0000714CE89D252A
0000714ce89d379b  call 0x0000714CE88B52F0
0000714ce89d37a0  jmp 0x0000714CE89D253D
0000714ce89d37a5  call 0x0000714CE88B5400
0000714ce89d37aa  jmp 0x0000714CE89D257E
0000714ce89d37af  call 0x0000714CE88C0FC0
0000714ce89d37b4  jmp 0x0000714CE89D258B
0000714ce89d37b9  call 0x0000714CE88B52F0
0000714ce89d37be  jmp 0x0000714CE89D2598
0000714ce89d37c3  call 0x0000714CE88C0EA0
0000714ce89d37c8  jmp 0x0000714CE89D25A5
0000714ce89d37cd  call 0x0000714CE87FF540
0000714ce89d37d2  jmp 0x0000714CE89D25C3
0000714ce89d37d7  call 0x0000714CE8808C20
0000714ce89d37dc  jmp 0x0000714CE89D25CD
0000714ce89d37e1  call 0x0000714CE88E21C0
0000714ce89d37e6  jmp 0x0000714CE89D25D3
0000714ce89d37eb  call 0x0000714CE87FF540
0000714ce89d37f0  jmp 0x0000714CE89D25E3
0000714ce89d37f5  call 0x0000714CE88C0370
0000714ce89d37fa  jmp 0x0000714CE89D2611
0000714ce89d37ff  call 0x0000714CE88BF100
0000714ce89d3804  jmp 0x0000714CE89D261A
0000714ce89d3809  call 0x0000714CE88C0370
0000714ce89d380e  jmp 0x0000714CE89D2674
0000714ce89d3813  call 0x0000714CE88BF100
0000714ce89d3818  jmp 0x0000714CE89D267D
0000714ce89d381d  call 0x0000714CE88C0370
0000714ce89d3822  jmp 0x0000714CE89D26C6
0000714ce89d3827  call 0x0000714CE88BF100
0000714ce89d382c  jmp 0x0000714CE89D26CF
0000714ce89d3831  call 0x0000714CE880B720
0000714ce89d3836  jmp 0x0000714CE89D2714
0000714ce89d383b  call 0x0000714CE88B47C0
0000714ce89d3840  jmp 0x0000714CE89D2727
0000714ce89d3845  call 0x0000714CE8808B00
0000714ce89d384a  jmp 0x0000714CE89D273E
0000714ce89d384f  call 0x0000714CE87FF430
0000714ce89d3854  jmp 0x0000714CE89D2751
0000714ce89d3859  call 0x0000714CE87FF430
0000714ce89d385e  jmp 0x0000714CE89D2764
0000714ce89d3863  sub rsp, 0x08
0000714ce89d3867  push rax
0000714ce89d3868  push rcx
0000714ce89d3869  push rdx
0000714ce89d386a  push rdi
0000714ce89d386b  push rsi
0000714ce89d386c  push r8
0000714ce89d386e  push r9
0000714ce89d3870  push r10
0000714ce89d3872  push r11
0000714ce89d3874  sub rsp, 0xF0
0000714ce89d387b  vmovaps [rsp], xmm0
0000714ce89d3880  vmovaps [rsp+0x10], xmm2
0000714ce89d3886  vmovaps [rsp+0x20], xmm3
0000714ce89d388c  vmovaps [rsp+0x30], xmm4
0000714ce89d3892  vmovaps [rsp+0x40], xmm5
0000714ce89d3898  vmovaps [rsp+0x50], xmm6
0000714ce89d389e  vmovaps [rsp+0x60], xmm7
0000714ce89d38a4  vmovaps [rsp+0x70], xmm8
0000714ce89d38aa  vmovaps [rsp+0x80], xmm9
0000714ce89d38b3  vmovaps [rsp+0x90], xmm10
0000714ce89d38bc  vmovaps [rsp+0xA0], xmm11
0000714ce89d38c5  vmovaps [rsp+0xB0], xmm12
0000714ce89d38ce  vmovaps [rsp+0xC0], xmm13
0000714ce89d38d7  vmovaps [rsp+0xD0], xmm14
0000714ce89d38e0  vmovaps [rsp+0xE0], xmm15
0000714ce89d38e9  sub rsp, 0x30
0000714ce89d38ed  movaps [rsp], xmm1
0000714ce89d38f1  movaps [rsp+0x10], xmm12
0000714ce89d38f7  movaps [rsp+0x20], xmm15
0000714ce89d38fd  lea rdi, [rsp]
0000714ce89d3901  mov esi, 0x00
0000714ce89d3906  mov rax, 0x57A55D340530
0000714ce89d3910  call rax
0000714ce89d3912  movaps xmm1, [rsp]
0000714ce89d3916  add rsp, 0x30
0000714ce89d391a  vmovaps xmm0, [rsp]
0000714ce89d391f  vmovaps xmm2, [rsp+0x10]
0000714ce89d3925  vmovaps xmm3, [rsp+0x20]
0000714ce89d392b  vmovaps xmm4, [rsp+0x30]
0000714ce89d3931  vmovaps xmm5, [rsp+0x40]
0000714ce89d3937  vmovaps xmm6, [rsp+0x50]
0000714ce89d393d  vmovaps xmm7, [rsp+0x60]
0000714ce89d3943  vmovaps xmm8, [rsp+0x70]
0000714ce89d3949  vmovaps xmm9, [rsp+0x80]
0000714ce89d3952  vmovaps xmm10, [rsp+0x90]
0000714ce89d395b  vmovaps xmm11, [rsp+0xA0]
0000714ce89d3964  vmovaps xmm12, [rsp+0xB0]
0000714ce89d396d  vmovaps xmm13, [rsp+0xC0]
0000714ce89d3976  vmovaps xmm14, [rsp+0xD0]
0000714ce89d397f  vmovaps xmm15, [rsp+0xE0]
0000714ce89d3988  add rsp, 0xF0
0000714ce89d398f  pop r11
0000714ce89d3991  pop r10
0000714ce89d3993  pop r9
0000714ce89d3995  pop r8
0000714ce89d3997  pop rsi
0000714ce89d3998  pop rdi
0000714ce89d3999  pop rdx
0000714ce89d399a  pop rcx
0000714ce89d399b  pop rax
0000714ce89d399c  add rsp, 0x08
0000714ce89d39a0  jmp 0x0000714CE89D27B2
0000714ce89d39a5  sub rsp, 0x08
0000714ce89d39a9  push rax
0000714ce89d39aa  push rcx
0000714ce89d39ab  push rdx
0000714ce89d39ac  push rdi
0000714ce89d39ad  push rsi
0000714ce89d39ae  push r8
0000714ce89d39b0  push r9
0000714ce89d39b2  push r10
0000714ce89d39b4  push r11
0000714ce89d39b6  sub rsp, 0xF0
0000714ce89d39bd  vmovaps [rsp], xmm0
0000714ce89d39c2  vmovaps [rsp+0x10], xmm1
0000714ce89d39c8  vmovaps [rsp+0x20], xmm2
0000714ce89d39ce  vmovaps [rsp+0x30], xmm3
0000714ce89d39d4  vmovaps [rsp+0x40], xmm4
0000714ce89d39da  vmovaps [rsp+0x50], xmm5
0000714ce89d39e0  vmovaps [rsp+0x60], xmm6
0000714ce89d39e6  vmovaps [rsp+0x70], xmm7
0000714ce89d39ec  vmovaps [rsp+0x80], xmm8
0000714ce89d39f5  vmovaps [rsp+0x90], xmm9
0000714ce89d39fe  vmovaps [rsp+0xA0], xmm10
0000714ce89d3a07  vmovaps [rsp+0xB0], xmm11
0000714ce89d3a10  vmovaps [rsp+0xC0], xmm12
0000714ce89d3a19  vmovaps [rsp+0xD0], xmm13
0000714ce89d3a22  vmovaps [rsp+0xE0], xmm15
0000714ce89d3a2b  sub rsp, 0x30
0000714ce89d3a2f  movaps [rsp], xmm14
0000714ce89d3a34  movaps [rsp+0x10], xmm1
0000714ce89d3a39  movaps [rsp+0x20], xmm15
0000714ce89d3a3f  lea rdi, [rsp]
0000714ce89d3a43  mov esi, 0x00
0000714ce89d3a48  mov rax, 0x57A55D340530
0000714ce89d3a52  call rax
0000714ce89d3a54  movaps xmm14, [rsp]
0000714ce89d3a59  add rsp, 0x30
0000714ce89d3a5d  vmovaps xmm0, [rsp]
0000714ce89d3a62  vmovaps xmm1, [rsp+0x10]
0000714ce89d3a68  vmovaps xmm2, [rsp+0x20]
0000714ce89d3a6e  vmovaps xmm3, [rsp+0x30]
0000714ce89d3a74  vmovaps xmm4, [rsp+0x40]
0000714ce89d3a7a  vmovaps xmm5, [rsp+0x50]
0000714ce89d3a80  vmovaps xmm6, [rsp+0x60]
0000714ce89d3a86  vmovaps xmm7, [rsp+0x70]
0000714ce89d3a8c  vmovaps xmm8, [rsp+0x80]
0000714ce89d3a95  vmovaps xmm9, [rsp+0x90]
0000714ce89d3a9e  vmovaps xmm10, [rsp+0xA0]
0000714ce89d3aa7  vmovaps xmm11, [rsp+0xB0]
0000714ce89d3ab0  vmovaps xmm12, [rsp+0xC0]
0000714ce89d3ab9  vmovaps xmm13, [rsp+0xD0]
0000714ce89d3ac2  vmovaps xmm15, [rsp+0xE0]
0000714ce89d3acb  add rsp, 0xF0
0000714ce89d3ad2  pop r11
0000714ce89d3ad4  pop r10
0000714ce89d3ad6  pop r9
0000714ce89d3ad8  pop r8
0000714ce89d3ada  pop rsi
0000714ce89d3adb  pop rdi
0000714ce89d3adc  pop rdx
0000714ce89d3add  pop rcx
0000714ce89d3ade  pop rax
0000714ce89d3adf  add rsp, 0x08
0000714ce89d3ae3  jmp 0x0000714CE89D2800
0000714ce89d3ae8  sub rsp, 0x08
0000714ce89d3aec  push rax
0000714ce89d3aed  push rcx
0000714ce89d3aee  push rdx
0000714ce89d3aef  push rdi
0000714ce89d3af0  push rsi
0000714ce89d3af1  push r8
0000714ce89d3af3  push r9
0000714ce89d3af5  push r10
0000714ce89d3af7  push r11
0000714ce89d3af9  sub rsp, 0xF0
0000714ce89d3b00  vmovaps [rsp], xmm0
0000714ce89d3b05  vmovaps [rsp+0x10], xmm1
0000714ce89d3b0b  vmovaps [rsp+0x20], xmm2
0000714ce89d3b11  vmovaps [rsp+0x30], xmm3
0000714ce89d3b17  vmovaps [rsp+0x40], xmm4
0000714ce89d3b1d  vmovaps [rsp+0x50], xmm5
0000714ce89d3b23  vmovaps [rsp+0x60], xmm6
0000714ce89d3b29  vmovaps [rsp+0x70], xmm7
0000714ce89d3b2f  vmovaps [rsp+0x80], xmm8
0000714ce89d3b38  vmovaps [rsp+0x90], xmm9
0000714ce89d3b41  vmovaps [rsp+0xA0], xmm10
0000714ce89d3b4a  vmovaps [rsp+0xB0], xmm11
0000714ce89d3b53  vmovaps [rsp+0xC0], xmm12
0000714ce89d3b5c  vmovaps [rsp+0xD0], xmm13
0000714ce89d3b65  vmovaps [rsp+0xE0], xmm14
0000714ce89d3b6e  sub rsp, 0x30
0000714ce89d3b72  movaps [rsp], xmm15
0000714ce89d3b77  movaps [rsp+0x10], xmm12
0000714ce89d3b7d  movaps [rsp+0x20], xmm13
0000714ce89d3b83  lea rdi, [rsp]
0000714ce89d3b87  mov esi, 0x00
0000714ce89d3b8c  mov rax, 0x57A55D340530
0000714ce89d3b96  call rax
0000714ce89d3b98  movaps xmm15, [rsp]
0000714ce89d3b9d  add rsp, 0x30
0000714ce89d3ba1  vmovaps xmm0, [rsp]
0000714ce89d3ba6  vmovaps xmm1, [rsp+0x10]
0000714ce89d3bac  vmovaps xmm2, [rsp+0x20]
0000714ce89d3bb2  vmovaps xmm3, [rsp+0x30]
0000714ce89d3bb8  vmovaps xmm4, [rsp+0x40]
0000714ce89d3bbe  vmovaps xmm5, [rsp+0x50]
0000714ce89d3bc4  vmovaps xmm6, [rsp+0x60]
0000714ce89d3bca  vmovaps xmm7, [rsp+0x70]
0000714ce89d3bd0  vmovaps xmm8, [rsp+0x80]
0000714ce89d3bd9  vmovaps xmm9, [rsp+0x90]
0000714ce89d3be2  vmovaps xmm10, [rsp+0xA0]
0000714ce89d3beb  vmovaps xmm11, [rsp+0xB0]
0000714ce89d3bf4  vmovaps xmm12, [rsp+0xC0]
0000714ce89d3bfd  vmovaps xmm13, [rsp+0xD0]
0000714ce89d3c06  vmovaps xmm14, [rsp+0xE0]
0000714ce89d3c0f  add rsp, 0xF0
0000714ce89d3c16  pop r11
0000714ce89d3c18  pop r10
0000714ce89d3c1a  pop r9
0000714ce89d3c1c  pop r8
0000714ce89d3c1e  pop rsi
0000714ce89d3c1f  pop rdi
0000714ce89d3c20  pop rdx
0000714ce89d3c21  pop rcx
0000714ce89d3c22  pop rax
0000714ce89d3c23  add rsp, 0x08
0000714ce89d3c27  jmp 0x0000714CE89D2835
0000714ce89d3c2c  sub rsp, 0x08
0000714ce89d3c30  push rax
0000714ce89d3c31  push rcx
0000714ce89d3c32  push rdx
0000714ce89d3c33  push rdi
0000714ce89d3c34  push rsi
0000714ce89d3c35  push r8
0000714ce89d3c37  push r9
0000714ce89d3c39  push r10
0000714ce89d3c3b  push r11
0000714ce89d3c3d  sub rsp, 0xF0
0000714ce89d3c44  vmovaps [rsp], xmm0
0000714ce89d3c49  vmovaps [rsp+0x10], xmm2
0000714ce89d3c4f  vmovaps [rsp+0x20], xmm3
0000714ce89d3c55  vmovaps [rsp+0x30], xmm4
0000714ce89d3c5b  vmovaps [rsp+0x40], xmm5
0000714ce89d3c61  vmovaps [rsp+0x50], xmm6
0000714ce89d3c67  vmovaps [rsp+0x60], xmm7
0000714ce89d3c6d  vmovaps [rsp+0x70], xmm8
0000714ce89d3c73  vmovaps [rsp+0x80], xmm9
0000714ce89d3c7c  vmovaps [rsp+0x90], xmm10
0000714ce89d3c85  vmovaps [rsp+0xA0], xmm11
0000714ce89d3c8e  vmovaps [rsp+0xB0], xmm12
0000714ce89d3c97  vmovaps [rsp+0xC0], xmm13
0000714ce89d3ca0  vmovaps [rsp+0xD0], xmm14
0000714ce89d3ca9  vmovaps [rsp+0xE0], xmm15
0000714ce89d3cb2  sub rsp, 0x30
0000714ce89d3cb6  movaps [rsp], xmm1
0000714ce89d3cba  movaps [rsp+0x10], xmm12
0000714ce89d3cc0  movaps [rsp+0x20], xmm10
0000714ce89d3cc6  lea rdi, [rsp]
0000714ce89d3cca  mov esi, 0x00
0000714ce89d3ccf  mov rax, 0x57A55D340530
0000714ce89d3cd9  call rax
0000714ce89d3cdb  movaps xmm1, [rsp]
0000714ce89d3cdf  add rsp, 0x30
0000714ce89d3ce3  vmovaps xmm0, [rsp]
0000714ce89d3ce8  vmovaps xmm2, [rsp+0x10]
0000714ce89d3cee  vmovaps xmm3, [rsp+0x20]
0000714ce89d3cf4  vmovaps xmm4, [rsp+0x30]
0000714ce89d3cfa  vmovaps xmm5, [rsp+0x40]
0000714ce89d3d00  vmovaps xmm6, [rsp+0x50]
0000714ce89d3d06  vmovaps xmm7, [rsp+0x60]
0000714ce89d3d0c  vmovaps xmm8, [rsp+0x70]
0000714ce89d3d12  vmovaps xmm9, [rsp+0x80]
0000714ce89d3d1b  vmovaps xmm10, [rsp+0x90]
0000714ce89d3d24  vmovaps xmm11, [rsp+0xA0]
0000714ce89d3d2d  vmovaps xmm12, [rsp+0xB0]
0000714ce89d3d36  vmovaps xmm13, [rsp+0xC0]
0000714ce89d3d3f  vmovaps xmm14, [rsp+0xD0]
0000714ce89d3d48  vmovaps xmm15, [rsp+0xE0]
0000714ce89d3d51  add rsp, 0xF0
0000714ce89d3d58  pop r11
0000714ce89d3d5a  pop r10
0000714ce89d3d5c  pop r9
0000714ce89d3d5e  pop r8
0000714ce89d3d60  pop rsi
0000714ce89d3d61  pop rdi
0000714ce89d3d62  pop rdx
0000714ce89d3d63  pop rcx
0000714ce89d3d64  pop rax
0000714ce89d3d65  add rsp, 0x08
0000714ce89d3d69  jmp 0x0000714CE89D284F
0000714ce89d3d6e  sub rsp, 0x08
0000714ce89d3d72  push rax
0000714ce89d3d73  push rcx
0000714ce89d3d74  push rdx
0000714ce89d3d75  push rdi
0000714ce89d3d76  push rsi
0000714ce89d3d77  push r8
0000714ce89d3d79  push r9
0000714ce89d3d7b  push r10
0000714ce89d3d7d  push r11
0000714ce89d3d7f  sub rsp, 0xF0
0000714ce89d3d86  vmovaps [rsp], xmm0
0000714ce89d3d8b  vmovaps [rsp+0x10], xmm1
0000714ce89d3d91  vmovaps [rsp+0x20], xmm2
0000714ce89d3d97  vmovaps [rsp+0x30], xmm3
0000714ce89d3d9d  vmovaps [rsp+0x40], xmm4
0000714ce89d3da3  vmovaps [rsp+0x50], xmm5
0000714ce89d3da9  vmovaps [rsp+0x60], xmm6
0000714ce89d3daf  vmovaps [rsp+0x70], xmm7
0000714ce89d3db5  vmovaps [rsp+0x80], xmm8
0000714ce89d3dbe  vmovaps [rsp+0x90], xmm9
0000714ce89d3dc7  vmovaps [rsp+0xA0], xmm10
0000714ce89d3dd0  vmovaps [rsp+0xB0], xmm11
0000714ce89d3dd9  vmovaps [rsp+0xC0], xmm12
0000714ce89d3de2  vmovaps [rsp+0xD0], xmm14
0000714ce89d3deb  vmovaps [rsp+0xE0], xmm15
0000714ce89d3df4  sub rsp, 0x30
0000714ce89d3df8  movaps [rsp], xmm13
0000714ce89d3dfd  movaps [rsp+0x10], xmm12
0000714ce89d3e03  movaps [rsp+0x20], xmm2
0000714ce89d3e08  lea rdi, [rsp]
0000714ce89d3e0c  mov esi, 0x00
0000714ce89d3e11  mov rax, 0x57A55D340530
0000714ce89d3e1b  call rax
0000714ce89d3e1d  movaps xmm13, [rsp]
0000714ce89d3e22  add rsp, 0x30
0000714ce89d3e26  vmovaps xmm0, [rsp]
0000714ce89d3e2b  vmovaps xmm1, [rsp+0x10]
0000714ce89d3e31  vmovaps xmm2, [rsp+0x20]
0000714ce89d3e37  vmovaps xmm3, [rsp+0x30]
0000714ce89d3e3d  vmovaps xmm4, [rsp+0x40]
0000714ce89d3e43  vmovaps xmm5, [rsp+0x50]
0000714ce89d3e49  vmovaps xmm6, [rsp+0x60]
0000714ce89d3e4f  vmovaps xmm7, [rsp+0x70]
0000714ce89d3e55  vmovaps xmm8, [rsp+0x80]
0000714ce89d3e5e  vmovaps xmm9, [rsp+0x90]
0000714ce89d3e67  vmovaps xmm10, [rsp+0xA0]
0000714ce89d3e70  vmovaps xmm11, [rsp+0xB0]
0000714ce89d3e79  vmovaps xmm12, [rsp+0xC0]
0000714ce89d3e82  vmovaps xmm14, [rsp+0xD0]
0000714ce89d3e8b  vmovaps xmm15, [rsp+0xE0]
0000714ce89d3e94  add rsp, 0xF0
0000714ce89d3e9b  pop r11
0000714ce89d3e9d  pop r10
0000714ce89d3e9f  pop r9
0000714ce89d3ea1  pop r8
0000714ce89d3ea3  pop rsi
0000714ce89d3ea4  pop rdi
0000714ce89d3ea5  pop rdx
0000714ce89d3ea6  pop rcx
0000714ce89d3ea7  pop rax
0000714ce89d3ea8  add rsp, 0x08
0000714ce89d3eac  jmp 0x0000714CE89D286A
0000714ce89d3eb1  sub rsp, 0x08
0000714ce89d3eb5  push rax
0000714ce89d3eb6  push rcx
0000714ce89d3eb7  push rdx
0000714ce89d3eb8  push rdi
0000714ce89d3eb9  push rsi
0000714ce89d3eba  push r8
0000714ce89d3ebc  push r9
0000714ce89d3ebe  push r10
0000714ce89d3ec0  push r11
0000714ce89d3ec2  sub rsp, 0xF0
0000714ce89d3ec9  vmovaps [rsp], xmm0
0000714ce89d3ece  vmovaps [rsp+0x10], xmm2
0000714ce89d3ed4  vmovaps [rsp+0x20], xmm3
0000714ce89d3eda  vmovaps [rsp+0x30], xmm4
0000714ce89d3ee0  vmovaps [rsp+0x40], xmm5
0000714ce89d3ee6  vmovaps [rsp+0x50], xmm6
0000714ce89d3eec  vmovaps [rsp+0x60], xmm7
0000714ce89d3ef2  vmovaps [rsp+0x70], xmm8
0000714ce89d3ef8  vmovaps [rsp+0x80], xmm9
0000714ce89d3f01  vmovaps [rsp+0x90], xmm10
0000714ce89d3f0a  vmovaps [rsp+0xA0], xmm11
0000714ce89d3f13  vmovaps [rsp+0xB0], xmm12
0000714ce89d3f1c  vmovaps [rsp+0xC0], xmm13
0000714ce89d3f25  vmovaps [rsp+0xD0], xmm14
0000714ce89d3f2e  vmovaps [rsp+0xE0], xmm15
0000714ce89d3f37  sub rsp, 0x30
0000714ce89d3f3b  movaps [rsp], xmm1
0000714ce89d3f3f  movaps [rsp+0x10], xmm10
0000714ce89d3f45  movaps [rsp+0x20], xmm2
0000714ce89d3f4a  lea rdi, [rsp]
0000714ce89d3f4e  mov esi, 0x00
0000714ce89d3f53  mov rax, 0x57A55D340530
0000714ce89d3f5d  call rax
0000714ce89d3f5f  movaps xmm1, [rsp]
0000714ce89d3f63  add rsp, 0x30
0000714ce89d3f67  vmovaps xmm0, [rsp]
0000714ce89d3f6c  vmovaps xmm2, [rsp+0x10]
0000714ce89d3f72  vmovaps xmm3, [rsp+0x20]
0000714ce89d3f78  vmovaps xmm4, [rsp+0x30]
0000714ce89d3f7e  vmovaps xmm5, [rsp+0x40]
0000714ce89d3f84  vmovaps xmm6, [rsp+0x50]
0000714ce89d3f8a  vmovaps xmm7, [rsp+0x60]
0000714ce89d3f90  vmovaps xmm8, [rsp+0x70]
0000714ce89d3f96  vmovaps xmm9, [rsp+0x80]
0000714ce89d3f9f  vmovaps xmm10, [rsp+0x90]
0000714ce89d3fa8  vmovaps xmm11, [rsp+0xA0]
0000714ce89d3fb1  vmovaps xmm12, [rsp+0xB0]
0000714ce89d3fba  vmovaps xmm13, [rsp+0xC0]
0000714ce89d3fc3  vmovaps xmm14, [rsp+0xD0]
0000714ce89d3fcc  vmovaps xmm15, [rsp+0xE0]
0000714ce89d3fd5  add rsp, 0xF0
0000714ce89d3fdc  pop r11
0000714ce89d3fde  pop r10
0000714ce89d3fe0  pop r9
0000714ce89d3fe2  pop r8
0000714ce89d3fe4  pop rsi
0000714ce89d3fe5  pop rdi
0000714ce89d3fe6  pop rdx
0000714ce89d3fe7  pop rcx
0000714ce89d3fe8  pop rax
0000714ce89d3fe9  add rsp, 0x08
0000714ce89d3fed  jmp 0x0000714CE89D28D2
0000714ce89d3ff2  sub rsp, 0x08
0000714ce89d3ff6  push rax
0000714ce89d3ff7  push rcx
0000714ce89d3ff8  push rdx
0000714ce89d3ff9  push rdi
0000714ce89d3ffa  push rsi
0000714ce89d3ffb  push r8
0000714ce89d3ffd  push r9
0000714ce89d3fff  push r10
0000714ce89d4001  push r11
0000714ce89d4003  sub rsp, 0xF0
0000714ce89d400a  vmovaps [rsp], xmm0
0000714ce89d400f  vmovaps [rsp+0x10], xmm1
0000714ce89d4015  vmovaps [rsp+0x20], xmm2
0000714ce89d401b  vmovaps [rsp+0x30], xmm3
0000714ce89d4021  vmovaps [rsp+0x40], xmm4
0000714ce89d4027  vmovaps [rsp+0x50], xmm5
0000714ce89d402d  vmovaps [rsp+0x60], xmm6
0000714ce89d4033  vmovaps [rsp+0x70], xmm7
0000714ce89d4039  vmovaps [rsp+0x80], xmm8
0000714ce89d4042  vmovaps [rsp+0x90], xmm9
0000714ce89d404b  vmovaps [rsp+0xA0], xmm10
0000714ce89d4054  vmovaps [rsp+0xB0], xmm11
0000714ce89d405d  vmovaps [rsp+0xC0], xmm12
0000714ce89d4066  vmovaps [rsp+0xD0], xmm13
0000714ce89d406f  vmovaps [rsp+0xE0], xmm14
0000714ce89d4078  sub rsp, 0x30
0000714ce89d407c  movaps [rsp], xmm15
0000714ce89d4081  movaps [rsp+0x10], xmm10
0000714ce89d4087  movaps [rsp+0x20], xmm2
0000714ce89d408c  lea rdi, [rsp]
0000714ce89d4090  mov esi, 0x00
0000714ce89d4095  mov rax, 0x57A55D340530
0000714ce89d409f  call rax
0000714ce89d40a1  movaps xmm15, [rsp]
0000714ce89d40a6  add rsp, 0x30
0000714ce89d40aa  vmovaps xmm0, [rsp]
0000714ce89d40af  vmovaps xmm1, [rsp+0x10]
0000714ce89d40b5  vmovaps xmm2, [rsp+0x20]
0000714ce89d40bb  vmovaps xmm3, [rsp+0x30]
0000714ce89d40c1  vmovaps xmm4, [rsp+0x40]
0000714ce89d40c7  vmovaps xmm5, [rsp+0x50]
0000714ce89d40cd  vmovaps xmm6, [rsp+0x60]
0000714ce89d40d3  vmovaps xmm7, [rsp+0x70]
0000714ce89d40d9  vmovaps xmm8, [rsp+0x80]
0000714ce89d40e2  vmovaps xmm9, [rsp+0x90]
0000714ce89d40eb  vmovaps xmm10, [rsp+0xA0]
0000714ce89d40f4  vmovaps xmm11, [rsp+0xB0]
0000714ce89d40fd  vmovaps xmm12, [rsp+0xC0]
0000714ce89d4106  vmovaps xmm13, [rsp+0xD0]
0000714ce89d410f  vmovaps xmm14, [rsp+0xE0]
0000714ce89d4118  add rsp, 0xF0
0000714ce89d411f  pop r11
0000714ce89d4121  pop r10
0000714ce89d4123  pop r9
0000714ce89d4125  pop r8
0000714ce89d4127  pop rsi
0000714ce89d4128  pop rdi
0000714ce89d4129  pop rdx
0000714ce89d412a  pop rcx
0000714ce89d412b  pop rax
0000714ce89d412c  add rsp, 0x08
0000714ce89d4130  jmp 0x0000714CE89D2924
0000714ce89d4135  sub rsp, 0x08
0000714ce89d4139  push rax
0000714ce89d413a  push rcx
0000714ce89d413b  push rdx
0000714ce89d413c  push rdi
0000714ce89d413d  push rsi
0000714ce89d413e  push r8
0000714ce89d4140  push r9
0000714ce89d4142  push r10
0000714ce89d4144  push r11
0000714ce89d4146  sub rsp, 0xF0
0000714ce89d414d  vmovaps [rsp], xmm0
0000714ce89d4152  vmovaps [rsp+0x10], xmm2
0000714ce89d4158  vmovaps [rsp+0x20], xmm3
0000714ce89d415e  vmovaps [rsp+0x30], xmm4
0000714ce89d4164  vmovaps [rsp+0x40], xmm5
0000714ce89d416a  vmovaps [rsp+0x50], xmm6
0000714ce89d4170  vmovaps [rsp+0x60], xmm7
0000714ce89d4176  vmovaps [rsp+0x70], xmm8
0000714ce89d417c  vmovaps [rsp+0x80], xmm9
0000714ce89d4185  vmovaps [rsp+0x90], xmm10
0000714ce89d418e  vmovaps [rsp+0xA0], xmm11
0000714ce89d4197  vmovaps [rsp+0xB0], xmm12
0000714ce89d41a0  vmovaps [rsp+0xC0], xmm13
0000714ce89d41a9  vmovaps [rsp+0xD0], xmm14
0000714ce89d41b2  vmovaps [rsp+0xE0], xmm15
0000714ce89d41bb  sub rsp, 0x30
0000714ce89d41bf  movaps [rsp], xmm1
0000714ce89d41c3  movaps [rsp+0x10], xmm10
0000714ce89d41c9  movaps [rsp+0x20], xmm15
0000714ce89d41cf  lea rdi, [rsp]
0000714ce89d41d3  mov esi, 0x00
0000714ce89d41d8  mov rax, 0x57A55D340530
0000714ce89d41e2  call rax
0000714ce89d41e4  movaps xmm1, [rsp]
0000714ce89d41e8  add rsp, 0x30
0000714ce89d41ec  vmovaps xmm0, [rsp]
0000714ce89d41f1  vmovaps xmm2, [rsp+0x10]
0000714ce89d41f7  vmovaps xmm3, [rsp+0x20]
0000714ce89d41fd  vmovaps xmm4, [rsp+0x30]
0000714ce89d4203  vmovaps xmm5, [rsp+0x40]
0000714ce89d4209  vmovaps xmm6, [rsp+0x50]
0000714ce89d420f  vmovaps xmm7, [rsp+0x60]
0000714ce89d4215  vmovaps xmm8, [rsp+0x70]
0000714ce89d421b  vmovaps xmm9, [rsp+0x80]
0000714ce89d4224  vmovaps xmm10, [rsp+0x90]
0000714ce89d422d  vmovaps xmm11, [rsp+0xA0]
0000714ce89d4236  vmovaps xmm12, [rsp+0xB0]
0000714ce89d423f  vmovaps xmm13, [rsp+0xC0]
0000714ce89d4248  vmovaps xmm14, [rsp+0xD0]
0000714ce89d4251  vmovaps xmm15, [rsp+0xE0]
0000714ce89d425a  add rsp, 0xF0
0000714ce89d4261  pop r11
0000714ce89d4263  pop r10
0000714ce89d4265  pop r9
0000714ce89d4267  pop r8
0000714ce89d4269  pop rsi
0000714ce89d426a  pop rdi
0000714ce89d426b  pop rdx
0000714ce89d426c  pop rcx
0000714ce89d426d  pop rax
0000714ce89d426e  add rsp, 0x08
0000714ce89d4272  jmp 0x0000714CE89D2962
0000714ce89d4277  sub rsp, 0x08
0000714ce89d427b  push rax
0000714ce89d427c  push rcx
0000714ce89d427d  push rdx
0000714ce89d427e  push rdi
0000714ce89d427f  push rsi
0000714ce89d4280  push r8
0000714ce89d4282  push r9
0000714ce89d4284  push r10
0000714ce89d4286  push r11
0000714ce89d4288  sub rsp, 0xF0
0000714ce89d428f  vmovaps [rsp], xmm0
0000714ce89d4294  vmovaps [rsp+0x10], xmm1
0000714ce89d429a  vmovaps [rsp+0x20], xmm2
0000714ce89d42a0  vmovaps [rsp+0x30], xmm3
0000714ce89d42a6  vmovaps [rsp+0x40], xmm4
0000714ce89d42ac  vmovaps [rsp+0x50], xmm5
0000714ce89d42b2  vmovaps [rsp+0x60], xmm6
0000714ce89d42b8  vmovaps [rsp+0x70], xmm7
0000714ce89d42be  vmovaps [rsp+0x80], xmm8
0000714ce89d42c7  vmovaps [rsp+0x90], xmm9
0000714ce89d42d0  vmovaps [rsp+0xA0], xmm10
0000714ce89d42d9  vmovaps [rsp+0xB0], xmm11
0000714ce89d42e2  vmovaps [rsp+0xC0], xmm12
0000714ce89d42eb  vmovaps [rsp+0xD0], xmm13
0000714ce89d42f4  vmovaps [rsp+0xE0], xmm15
0000714ce89d42fd  sub rsp, 0x30
0000714ce89d4301  movaps [rsp], xmm14
0000714ce89d4306  movaps [rsp+0x10], xmm10
0000714ce89d430c  movaps [rsp+0x20], xmm15
0000714ce89d4312  lea rdi, [rsp]
0000714ce89d4316  mov esi, 0x00
0000714ce89d431b  mov rax, 0x57A55D340530
0000714ce89d4325  call rax
0000714ce89d4327  movaps xmm14, [rsp]
0000714ce89d432c  add rsp, 0x30
0000714ce89d4330  vmovaps xmm0, [rsp]
0000714ce89d4335  vmovaps xmm1, [rsp+0x10]
0000714ce89d433b  vmovaps xmm2, [rsp+0x20]
0000714ce89d4341  vmovaps xmm3, [rsp+0x30]
0000714ce89d4347  vmovaps xmm4, [rsp+0x40]
0000714ce89d434d  vmovaps xmm5, [rsp+0x50]
0000714ce89d4353  vmovaps xmm6, [rsp+0x60]
0000714ce89d4359  vmovaps xmm7, [rsp+0x70]
0000714ce89d435f  vmovaps xmm8, [rsp+0x80]
0000714ce89d4368  vmovaps xmm9, [rsp+0x90]
0000714ce89d4371  vmovaps xmm10, [rsp+0xA0]
0000714ce89d437a  vmovaps xmm11, [rsp+0xB0]
0000714ce89d4383  vmovaps xmm12, [rsp+0xC0]
0000714ce89d438c  vmovaps xmm13, [rsp+0xD0]
0000714ce89d4395  vmovaps xmm15, [rsp+0xE0]
0000714ce89d439e  add rsp, 0xF0
0000714ce89d43a5  pop r11
0000714ce89d43a7  pop r10
0000714ce89d43a9  pop r9
0000714ce89d43ab  pop r8
0000714ce89d43ad  pop rsi
0000714ce89d43ae  pop rdi
0000714ce89d43af  pop rdx
0000714ce89d43b0  pop rcx
0000714ce89d43b1  pop rax
0000714ce89d43b2  add rsp, 0x08
0000714ce89d43b6  jmp 0x0000714CE89D298E
0000714ce89d43bb  call 0x0000714CE87FF430
0000714ce89d43c0  jmp 0x0000714CE89D2A1E
0000714ce89d43c5  call 0x0000714CE87FF430
0000714ce89d43ca  jmp 0x0000714CE89D2A31
0000714ce89d43cf  sub rsp, 0x08
0000714ce89d43d3  push rax
0000714ce89d43d4  push rcx
0000714ce89d43d5  push rdx
0000714ce89d43d6  push rdi
0000714ce89d43d7  push rsi
0000714ce89d43d8  push r8
0000714ce89d43da  push r9
0000714ce89d43dc  push r10
0000714ce89d43de  push r11
0000714ce89d43e0  sub rsp, 0xF0
0000714ce89d43e7  vmovaps [rsp], xmm0
0000714ce89d43ec  vmovaps [rsp+0x10], xmm2
0000714ce89d43f2  vmovaps [rsp+0x20], xmm3
0000714ce89d43f8  vmovaps [rsp+0x30], xmm4
0000714ce89d43fe  vmovaps [rsp+0x40], xmm5
0000714ce89d4404  vmovaps [rsp+0x50], xmm6
0000714ce89d440a  vmovaps [rsp+0x60], xmm7
0000714ce89d4410  vmovaps [rsp+0x70], xmm8
0000714ce89d4416  vmovaps [rsp+0x80], xmm9
0000714ce89d441f  vmovaps [rsp+0x90], xmm10
0000714ce89d4428  vmovaps [rsp+0xA0], xmm11
0000714ce89d4431  vmovaps [rsp+0xB0], xmm12
0000714ce89d443a  vmovaps [rsp+0xC0], xmm13
0000714ce89d4443  vmovaps [rsp+0xD0], xmm14
0000714ce89d444c  vmovaps [rsp+0xE0], xmm15
0000714ce89d4455  sub rsp, 0x30
0000714ce89d4459  movaps [rsp], xmm1
0000714ce89d445d  movaps [rsp+0x10], xmm13
0000714ce89d4463  movaps [rsp+0x20], xmm2
0000714ce89d4468  lea rdi, [rsp]
0000714ce89d446c  mov esi, 0x00
0000714ce89d4471  mov rax, 0x57A55D340530
0000714ce89d447b  call rax
0000714ce89d447d  movaps xmm1, [rsp]
0000714ce89d4481  add rsp, 0x30
0000714ce89d4485  vmovaps xmm0, [rsp]
0000714ce89d448a  vmovaps xmm2, [rsp+0x10]
0000714ce89d4490  vmovaps xmm3, [rsp+0x20]
0000714ce89d4496  vmovaps xmm4, [rsp+0x30]
0000714ce89d449c  vmovaps xmm5, [rsp+0x40]
0000714ce89d44a2  vmovaps xmm6, [rsp+0x50]
0000714ce89d44a8  vmovaps xmm7, [rsp+0x60]
0000714ce89d44ae  vmovaps xmm8, [rsp+0x70]
0000714ce89d44b4  vmovaps xmm9, [rsp+0x80]
0000714ce89d44bd  vmovaps xmm10, [rsp+0x90]
0000714ce89d44c6  vmovaps xmm11, [rsp+0xA0]
0000714ce89d44cf  vmovaps xmm12, [rsp+0xB0]
0000714ce89d44d8  vmovaps xmm13, [rsp+0xC0]
0000714ce89d44e1  vmovaps xmm14, [rsp+0xD0]
0000714ce89d44ea  vmovaps xmm15, [rsp+0xE0]
0000714ce89d44f3  add rsp, 0xF0
0000714ce89d44fa  pop r11
0000714ce89d44fc  pop r10
0000714ce89d44fe  pop r9
0000714ce89d4500  pop r8
0000714ce89d4502  pop rsi
0000714ce89d4503  pop rdi
0000714ce89d4504  pop rdx
0000714ce89d4505  pop rcx
0000714ce89d4506  pop rax
0000714ce89d4507  add rsp, 0x08
0000714ce89d450b  jmp 0x0000714CE89D2A5C
0000714ce89d4510  call 0x0000714CE880E760
0000714ce89d4515  jmp 0x0000714CE89D2A69
0000714ce89d451a  sub rsp, 0x08
0000714ce89d451e  push rax
0000714ce89d451f  push rcx
0000714ce89d4520  push rdx
0000714ce89d4521  push rdi
0000714ce89d4522  push rsi
0000714ce89d4523  push r8
0000714ce89d4525  push r9
0000714ce89d4527  push r10
0000714ce89d4529  push r11
0000714ce89d452b  sub rsp, 0xF0
0000714ce89d4532  vmovaps [rsp], xmm0
0000714ce89d4537  vmovaps [rsp+0x10], xmm1
0000714ce89d453d  vmovaps [rsp+0x20], xmm2
0000714ce89d4543  vmovaps [rsp+0x30], xmm3
0000714ce89d4549  vmovaps [rsp+0x40], xmm4
0000714ce89d454f  vmovaps [rsp+0x50], xmm5
0000714ce89d4555  vmovaps [rsp+0x60], xmm6
0000714ce89d455b  vmovaps [rsp+0x70], xmm7
0000714ce89d4561  vmovaps [rsp+0x80], xmm8
0000714ce89d456a  vmovaps [rsp+0x90], xmm9
0000714ce89d4573  vmovaps [rsp+0xA0], xmm10
0000714ce89d457c  vmovaps [rsp+0xB0], xmm11
0000714ce89d4585  vmovaps [rsp+0xC0], xmm12
0000714ce89d458e  vmovaps [rsp+0xD0], xmm14
0000714ce89d4597  vmovaps [rsp+0xE0], xmm15
0000714ce89d45a0  sub rsp, 0x30
0000714ce89d45a4  movaps [rsp], xmm13
0000714ce89d45a9  movaps [rsp+0x10], xmm2
0000714ce89d45ae  movaps [rsp+0x20], xmm1
0000714ce89d45b3  lea rdi, [rsp]
0000714ce89d45b7  mov esi, 0x00
0000714ce89d45bc  mov rax, 0x57A55D340530
0000714ce89d45c6  call rax
0000714ce89d45c8  movaps xmm13, [rsp]
0000714ce89d45cd  add rsp, 0x30
0000714ce89d45d1  vmovaps xmm0, [rsp]
0000714ce89d45d6  vmovaps xmm1, [rsp+0x10]
0000714ce89d45dc  vmovaps xmm2, [rsp+0x20]
0000714ce89d45e2  vmovaps xmm3, [rsp+0x30]
0000714ce89d45e8  vmovaps xmm4, [rsp+0x40]
0000714ce89d45ee  vmovaps xmm5, [rsp+0x50]
0000714ce89d45f4  vmovaps xmm6, [rsp+0x60]
0000714ce89d45fa  vmovaps xmm7, [rsp+0x70]
0000714ce89d4600  vmovaps xmm8, [rsp+0x80]
0000714ce89d4609  vmovaps xmm9, [rsp+0x90]
0000714ce89d4612  vmovaps xmm10, [rsp+0xA0]
0000714ce89d461b  vmovaps xmm11, [rsp+0xB0]
0000714ce89d4624  vmovaps xmm12, [rsp+0xC0]
0000714ce89d462d  vmovaps xmm14, [rsp+0xD0]
0000714ce89d4636  vmovaps xmm15, [rsp+0xE0]
0000714ce89d463f  add rsp, 0xF0
0000714ce89d4646  pop r11
0000714ce89d4648  pop r10
0000714ce89d464a  pop r9
0000714ce89d464c  pop r8
0000714ce89d464e  pop rsi
0000714ce89d464f  pop rdi
0000714ce89d4650  pop rdx
0000714ce89d4651  pop rcx
0000714ce89d4652  pop rax
0000714ce89d4653  add rsp, 0x08
0000714ce89d4657  jmp 0x0000714CE89D2AA8
0000714ce89d465c  sub rsp, 0x08
0000714ce89d4660  push rax
0000714ce89d4661  push rcx
0000714ce89d4662  push rdx
0000714ce89d4663  push rdi
0000714ce89d4664  push rsi
0000714ce89d4665  push r8
0000714ce89d4667  push r9
0000714ce89d4669  push r10
0000714ce89d466b  push r11
0000714ce89d466d  sub rsp, 0xF0
0000714ce89d4674  vmovaps [rsp], xmm0
0000714ce89d4679  vmovaps [rsp+0x10], xmm2
0000714ce89d467f  vmovaps [rsp+0x20], xmm3
0000714ce89d4685  vmovaps [rsp+0x30], xmm4
0000714ce89d468b  vmovaps [rsp+0x40], xmm5
0000714ce89d4691  vmovaps [rsp+0x50], xmm6
0000714ce89d4697  vmovaps [rsp+0x60], xmm7
0000714ce89d469d  vmovaps [rsp+0x70], xmm8
0000714ce89d46a3  vmovaps [rsp+0x80], xmm9
0000714ce89d46ac  vmovaps [rsp+0x90], xmm10
0000714ce89d46b5  vmovaps [rsp+0xA0], xmm11
0000714ce89d46be  vmovaps [rsp+0xB0], xmm12
0000714ce89d46c7  vmovaps [rsp+0xC0], xmm13
0000714ce89d46d0  vmovaps [rsp+0xD0], xmm14
0000714ce89d46d9  vmovaps [rsp+0xE0], xmm15
0000714ce89d46e2  sub rsp, 0x30
0000714ce89d46e6  movaps [rsp], xmm1
0000714ce89d46ea  movaps [rsp+0x10], xmm14
0000714ce89d46f0  movaps [rsp+0x20], xmm15
0000714ce89d46f6  lea rdi, [rsp]
0000714ce89d46fa  mov esi, 0x00
0000714ce89d46ff  mov rax, 0x57A55D340530
0000714ce89d4709  call rax
0000714ce89d470b  movaps xmm1, [rsp]
0000714ce89d470f  add rsp, 0x30
0000714ce89d4713  vmovaps xmm0, [rsp]
0000714ce89d4718  vmovaps xmm2, [rsp+0x10]
0000714ce89d471e  vmovaps xmm3, [rsp+0x20]
0000714ce89d4724  vmovaps xmm4, [rsp+0x30]
0000714ce89d472a  vmovaps xmm5, [rsp+0x40]
0000714ce89d4730  vmovaps xmm6, [rsp+0x50]
0000714ce89d4736  vmovaps xmm7, [rsp+0x60]
0000714ce89d473c  vmovaps xmm8, [rsp+0x70]
0000714ce89d4742  vmovaps xmm9, [rsp+0x80]
0000714ce89d474b  vmovaps xmm10, [rsp+0x90]
0000714ce89d4754  vmovaps xmm11, [rsp+0xA0]
0000714ce89d475d  vmovaps xmm12, [rsp+0xB0]
0000714ce89d4766  vmovaps xmm13, [rsp+0xC0]
0000714ce89d476f  vmovaps xmm14, [rsp+0xD0]
0000714ce89d4778  vmovaps xmm15, [rsp+0xE0]
0000714ce89d4781  add rsp, 0xF0
0000714ce89d4788  pop r11
0000714ce89d478a  pop r10
0000714ce89d478c  pop r9
0000714ce89d478e  pop r8
0000714ce89d4790  pop rsi
0000714ce89d4791  pop rdi
0000714ce89d4792  pop rdx
0000714ce89d4793  pop rcx
0000714ce89d4794  pop rax
0000714ce89d4795  add rsp, 0x08
0000714ce89d4799  jmp 0x0000714CE89D2ACA
0000714ce89d479e  sub rsp, 0x08
0000714ce89d47a2  push rax
0000714ce89d47a3  push rcx
0000714ce89d47a4  push rdx
0000714ce89d47a5  push rdi
0000714ce89d47a6  push rsi
0000714ce89d47a7  push r8
0000714ce89d47a9  push r9
0000714ce89d47ab  push r10
0000714ce89d47ad  push r11
0000714ce89d47af  sub rsp, 0xF0
0000714ce89d47b6  vmovaps [rsp], xmm0
0000714ce89d47bb  vmovaps [rsp+0x10], xmm1
0000714ce89d47c1  vmovaps [rsp+0x20], xmm2
0000714ce89d47c7  vmovaps [rsp+0x30], xmm3
0000714ce89d47cd  vmovaps [rsp+0x40], xmm4
0000714ce89d47d3  vmovaps [rsp+0x50], xmm5
0000714ce89d47d9  vmovaps [rsp+0x60], xmm6
0000714ce89d47df  vmovaps [rsp+0x70], xmm7
0000714ce89d47e5  vmovaps [rsp+0x80], xmm8
0000714ce89d47ee  vmovaps [rsp+0x90], xmm9
0000714ce89d47f7  vmovaps [rsp+0xA0], xmm10
0000714ce89d4800  vmovaps [rsp+0xB0], xmm11
0000714ce89d4809  vmovaps [rsp+0xC0], xmm12
0000714ce89d4812  vmovaps [rsp+0xD0], xmm13
0000714ce89d481b  vmovaps [rsp+0xE0], xmm15
0000714ce89d4824  sub rsp, 0x30
0000714ce89d4828  movaps [rsp], xmm14
0000714ce89d482d  movaps [rsp+0x10], xmm2
0000714ce89d4832  movaps [rsp+0x20], xmm15
0000714ce89d4838  lea rdi, [rsp]
0000714ce89d483c  mov esi, 0x00
0000714ce89d4841  mov rax, 0x57A55D340530
0000714ce89d484b  call rax
0000714ce89d484d  movaps xmm14, [rsp]
0000714ce89d4852  add rsp, 0x30
0000714ce89d4856  vmovaps xmm0, [rsp]
0000714ce89d485b  vmovaps xmm1, [rsp+0x10]
0000714ce89d4861  vmovaps xmm2, [rsp+0x20]
0000714ce89d4867  vmovaps xmm3, [rsp+0x30]
0000714ce89d486d  vmovaps xmm4, [rsp+0x40]
0000714ce89d4873  vmovaps xmm5, [rsp+0x50]
0000714ce89d4879  vmovaps xmm6, [rsp+0x60]
0000714ce89d487f  vmovaps xmm7, [rsp+0x70]
0000714ce89d4885  vmovaps xmm8, [rsp+0x80]
0000714ce89d488e  vmovaps xmm9, [rsp+0x90]
0000714ce89d4897  vmovaps xmm10, [rsp+0xA0]
0000714ce89d48a0  vmovaps xmm11, [rsp+0xB0]
0000714ce89d48a9  vmovaps xmm12, [rsp+0xC0]
0000714ce89d48b2  vmovaps xmm13, [rsp+0xD0]
0000714ce89d48bb  vmovaps xmm15, [rsp+0xE0]
0000714ce89d48c4  add rsp, 0xF0
0000714ce89d48cb  pop r11
0000714ce89d48cd  pop r10
0000714ce89d48cf  pop r9
0000714ce89d48d1  pop r8
0000714ce89d48d3  pop rsi
0000714ce89d48d4  pop rdi
0000714ce89d48d5  pop rdx
0000714ce89d48d6  pop rcx
0000714ce89d48d7  pop rax
0000714ce89d48d8  add rsp, 0x08
0000714ce89d48dc  jmp 0x0000714CE89D2B05
0000714ce89d48e1  sub rsp, 0x08
0000714ce89d48e5  push rax
0000714ce89d48e6  push rcx
0000714ce89d48e7  push rdx
0000714ce89d48e8  push rdi
0000714ce89d48e9  push rsi
0000714ce89d48ea  push r8
0000714ce89d48ec  push r9
0000714ce89d48ee  push r10
0000714ce89d48f0  push r11
0000714ce89d48f2  sub rsp, 0xF0
0000714ce89d48f9  vmovaps [rsp], xmm0
0000714ce89d48fe  vmovaps [rsp+0x10], xmm1
0000714ce89d4904  vmovaps [rsp+0x20], xmm2
0000714ce89d490a  vmovaps [rsp+0x30], xmm3
0000714ce89d4910  vmovaps [rsp+0x40], xmm4
0000714ce89d4916  vmovaps [rsp+0x50], xmm5
0000714ce89d491c  vmovaps [rsp+0x60], xmm6
0000714ce89d4922  vmovaps [rsp+0x70], xmm7
0000714ce89d4928  vmovaps [rsp+0x80], xmm8
0000714ce89d4931  vmovaps [rsp+0x90], xmm9
0000714ce89d493a  vmovaps [rsp+0xA0], xmm10
0000714ce89d4943  vmovaps [rsp+0xB0], xmm11
0000714ce89d494c  vmovaps [rsp+0xC0], xmm12
0000714ce89d4955  vmovaps [rsp+0xD0], xmm13
0000714ce89d495e  vmovaps [rsp+0xE0], xmm14
0000714ce89d4967  sub rsp, 0x30
0000714ce89d496b  movaps [rsp], xmm15
0000714ce89d4970  movaps [rsp+0x10], xmm2
0000714ce89d4975  movaps [rsp+0x20], xmm1
0000714ce89d497a  lea rdi, [rsp]
0000714ce89d497e  mov esi, 0x00
0000714ce89d4983  mov rax, 0x57A55D340530
0000714ce89d498d  call rax
0000714ce89d498f  movaps xmm15, [rsp]
0000714ce89d4994  add rsp, 0x30
0000714ce89d4998  vmovaps xmm0, [rsp]
0000714ce89d499d  vmovaps xmm1, [rsp+0x10]
0000714ce89d49a3  vmovaps xmm2, [rsp+0x20]
0000714ce89d49a9  vmovaps xmm3, [rsp+0x30]
0000714ce89d49af  vmovaps xmm4, [rsp+0x40]
0000714ce89d49b5  vmovaps xmm5, [rsp+0x50]
0000714ce89d49bb  vmovaps xmm6, [rsp+0x60]
0000714ce89d49c1  vmovaps xmm7, [rsp+0x70]
0000714ce89d49c7  vmovaps xmm8, [rsp+0x80]
0000714ce89d49d0  vmovaps xmm9, [rsp+0x90]
0000714ce89d49d9  vmovaps xmm10, [rsp+0xA0]
0000714ce89d49e2  vmovaps xmm11, [rsp+0xB0]
0000714ce89d49eb  vmovaps xmm12, [rsp+0xC0]
0000714ce89d49f4  vmovaps xmm13, [rsp+0xD0]
0000714ce89d49fd  vmovaps xmm14, [rsp+0xE0]
0000714ce89d4a06  add rsp, 0xF0
0000714ce89d4a0d  pop r11
0000714ce89d4a0f  pop r10
0000714ce89d4a11  pop r9
0000714ce89d4a13  pop r8
0000714ce89d4a15  pop rsi
0000714ce89d4a16  pop rdi
0000714ce89d4a17  pop rdx
0000714ce89d4a18  pop rcx
0000714ce89d4a19  pop rax
0000714ce89d4a1a  add rsp, 0x08
0000714ce89d4a1e  jmp 0x0000714CE89D2B41
0000714ce89d4a23  call 0x0000714CE87FF430
0000714ce89d4a28  jmp 0x0000714CE89D2B4E
0000714ce89d4a2d  sub rsp, 0x08
0000714ce89d4a31  push rax
0000714ce89d4a32  push rcx
0000714ce89d4a33  push rdx
0000714ce89d4a34  push rdi
0000714ce89d4a35  push rsi
0000714ce89d4a36  push r8
0000714ce89d4a38  push r9
0000714ce89d4a3a  push r10
0000714ce89d4a3c  push r11
0000714ce89d4a3e  sub rsp, 0xF0
0000714ce89d4a45  vmovaps [rsp], xmm0
0000714ce89d4a4a  vmovaps [rsp+0x10], xmm1
0000714ce89d4a50  vmovaps [rsp+0x20], xmm3
0000714ce89d4a56  vmovaps [rsp+0x30], xmm4
0000714ce89d4a5c  vmovaps [rsp+0x40], xmm5
0000714ce89d4a62  vmovaps [rsp+0x50], xmm6
0000714ce89d4a68  vmovaps [rsp+0x60], xmm7
0000714ce89d4a6e  vmovaps [rsp+0x70], xmm8
0000714ce89d4a74  vmovaps [rsp+0x80], xmm9
0000714ce89d4a7d  vmovaps [rsp+0x90], xmm10
0000714ce89d4a86  vmovaps [rsp+0xA0], xmm11
0000714ce89d4a8f  vmovaps [rsp+0xB0], xmm12
0000714ce89d4a98  vmovaps [rsp+0xC0], xmm13
0000714ce89d4aa1  vmovaps [rsp+0xD0], xmm14
0000714ce89d4aaa  vmovaps [rsp+0xE0], xmm15
0000714ce89d4ab3  sub rsp, 0x30
0000714ce89d4ab7  movaps [rsp], xmm2
0000714ce89d4abb  movaps [rsp+0x10], xmm1
0000714ce89d4ac0  movaps [rsp+0x20], xmm14
0000714ce89d4ac6  lea rdi, [rsp]
0000714ce89d4aca  mov esi, 0x00
0000714ce89d4acf  mov rax, 0x57A55D340530
0000714ce89d4ad9  call rax
0000714ce89d4adb  movaps xmm2, [rsp]
0000714ce89d4adf  add rsp, 0x30
0000714ce89d4ae3  vmovaps xmm0, [rsp]
0000714ce89d4ae8  vmovaps xmm1, [rsp+0x10]
0000714ce89d4aee  vmovaps xmm3, [rsp+0x20]
0000714ce89d4af4  vmovaps xmm4, [rsp+0x30]
0000714ce89d4afa  vmovaps xmm5, [rsp+0x40]
0000714ce89d4b00  vmovaps xmm6, [rsp+0x50]
0000714ce89d4b06  vmovaps xmm7, [rsp+0x60]
0000714ce89d4b0c  vmovaps xmm8, [rsp+0x70]
0000714ce89d4b12  vmovaps xmm9, [rsp+0x80]
0000714ce89d4b1b  vmovaps xmm10, [rsp+0x90]
0000714ce89d4b24  vmovaps xmm11, [rsp+0xA0]
0000714ce89d4b2d  vmovaps xmm12, [rsp+0xB0]
0000714ce89d4b36  vmovaps xmm13, [rsp+0xC0]
0000714ce89d4b3f  vmovaps xmm14, [rsp+0xD0]
0000714ce89d4b48  vmovaps xmm15, [rsp+0xE0]
0000714ce89d4b51  add rsp, 0xF0
0000714ce89d4b58  pop r11
0000714ce89d4b5a  pop r10
0000714ce89d4b5c  pop r9
0000714ce89d4b5e  pop r8
0000714ce89d4b60  pop rsi
0000714ce89d4b61  pop rdi
0000714ce89d4b62  pop rdx
0000714ce89d4b63  pop rcx
0000714ce89d4b64  pop rax
0000714ce89d4b65  add rsp, 0x08
0000714ce89d4b69  jmp 0x0000714CE89D2B8B
0000714ce89d4b6e  sub rsp, 0x08
0000714ce89d4b72  push rax
0000714ce89d4b73  push rcx
0000714ce89d4b74  push rdx
0000714ce89d4b75  push rdi
0000714ce89d4b76  push rsi
0000714ce89d4b77  push r8
0000714ce89d4b79  push r9
0000714ce89d4b7b  push r10
0000714ce89d4b7d  push r11
0000714ce89d4b7f  sub rsp, 0xF0
0000714ce89d4b86  vmovaps [rsp], xmm0
0000714ce89d4b8b  vmovaps [rsp+0x10], xmm1
0000714ce89d4b91  vmovaps [rsp+0x20], xmm2
0000714ce89d4b97  vmovaps [rsp+0x30], xmm3
0000714ce89d4b9d  vmovaps [rsp+0x40], xmm4
0000714ce89d4ba3  vmovaps [rsp+0x50], xmm5
0000714ce89d4ba9  vmovaps [rsp+0x60], xmm6
0000714ce89d4baf  vmovaps [rsp+0x70], xmm7
0000714ce89d4bb5  vmovaps [rsp+0x80], xmm8
0000714ce89d4bbe  vmovaps [rsp+0x90], xmm9
0000714ce89d4bc7  vmovaps [rsp+0xA0], xmm10
0000714ce89d4bd0  vmovaps [rsp+0xB0], xmm11
0000714ce89d4bd9  vmovaps [rsp+0xC0], xmm12
0000714ce89d4be2  vmovaps [rsp+0xD0], xmm13
0000714ce89d4beb  vmovaps [rsp+0xE0], xmm14
0000714ce89d4bf4  sub rsp, 0x30
0000714ce89d4bf8  movaps [rsp], xmm15
0000714ce89d4bfd  movaps [rsp+0x10], xmm14
0000714ce89d4c03  movaps [rsp+0x20], xmm1
0000714ce89d4c08  lea rdi, [rsp]
0000714ce89d4c0c  mov esi, 0x00
0000714ce89d4c11  mov rax, 0x57A55D340530
0000714ce89d4c1b  call rax
0000714ce89d4c1d  movaps xmm15, [rsp]
0000714ce89d4c22  add rsp, 0x30
0000714ce89d4c26  vmovaps xmm0, [rsp]
0000714ce89d4c2b  vmovaps xmm1, [rsp+0x10]
0000714ce89d4c31  vmovaps xmm2, [rsp+0x20]
0000714ce89d4c37  vmovaps xmm3, [rsp+0x30]
0000714ce89d4c3d  vmovaps xmm4, [rsp+0x40]
0000714ce89d4c43  vmovaps xmm5, [rsp+0x50]
0000714ce89d4c49  vmovaps xmm6, [rsp+0x60]
0000714ce89d4c4f  vmovaps xmm7, [rsp+0x70]
0000714ce89d4c55  vmovaps xmm8, [rsp+0x80]
0000714ce89d4c5e  vmovaps xmm9, [rsp+0x90]
0000714ce89d4c67  vmovaps xmm10, [rsp+0xA0]
0000714ce89d4c70  vmovaps xmm11, [rsp+0xB0]
0000714ce89d4c79  vmovaps xmm12, [rsp+0xC0]
0000714ce89d4c82  vmovaps xmm13, [rsp+0xD0]
0000714ce89d4c8b  vmovaps xmm14, [rsp+0xE0]
0000714ce89d4c94  add rsp, 0xF0
0000714ce89d4c9b  pop r11
0000714ce89d4c9d  pop r10
0000714ce89d4c9f  pop r9
0000714ce89d4ca1  pop r8
0000714ce89d4ca3  pop rsi
0000714ce89d4ca4  pop rdi
0000714ce89d4ca5  pop rdx
0000714ce89d4ca6  pop rcx
0000714ce89d4ca7  pop rax
0000714ce89d4ca8  add rsp, 0x08
0000714ce89d4cac  jmp 0x0000714CE89D2C05
0000714ce89d4cb1  call 0x0000714CE87FF430
0000714ce89d4cb6  jmp 0x0000714CE89D2C12
0000714ce89d4cbb  sub rsp, 0x08
0000714ce89d4cbf  push rax
0000714ce89d4cc0  push rcx
0000714ce89d4cc1  push rdx
0000714ce89d4cc2  push rdi
0000714ce89d4cc3  push rsi
0000714ce89d4cc4  push r8
0000714ce89d4cc6  push r9
0000714ce89d4cc8  push r10
0000714ce89d4cca  push r11
0000714ce89d4ccc  sub rsp, 0xF0
0000714ce89d4cd3  vmovaps [rsp], xmm0
0000714ce89d4cd8  vmovaps [rsp+0x10], xmm1
0000714ce89d4cde  vmovaps [rsp+0x20], xmm2
0000714ce89d4ce4  vmovaps [rsp+0x30], xmm3
0000714ce89d4cea  vmovaps [rsp+0x40], xmm4
0000714ce89d4cf0  vmovaps [rsp+0x50], xmm5
0000714ce89d4cf6  vmovaps [rsp+0x60], xmm6
0000714ce89d4cfc  vmovaps [rsp+0x70], xmm7
0000714ce89d4d02  vmovaps [rsp+0x80], xmm8
0000714ce89d4d0b  vmovaps [rsp+0x90], xmm9
0000714ce89d4d14  vmovaps [rsp+0xA0], xmm10
0000714ce89d4d1d  vmovaps [rsp+0xB0], xmm11
0000714ce89d4d26  vmovaps [rsp+0xC0], xmm12
0000714ce89d4d2f  vmovaps [rsp+0xD0], xmm14
0000714ce89d4d38  vmovaps [rsp+0xE0], xmm15
0000714ce89d4d41  sub rsp, 0x30
0000714ce89d4d45  movaps [rsp], xmm13
0000714ce89d4d4a  movaps [rsp+0x10], xmm1
0000714ce89d4d4f  movaps [rsp+0x20], xmm15
0000714ce89d4d55  lea rdi, [rsp]
0000714ce89d4d59  mov esi, 0x00
0000714ce89d4d5e  mov rax, 0x57A55D340530
0000714ce89d4d68  call rax
0000714ce89d4d6a  movaps xmm13, [rsp]
0000714ce89d4d6f  add rsp, 0x30
0000714ce89d4d73  vmovaps xmm0, [rsp]
0000714ce89d4d78  vmovaps xmm1, [rsp+0x10]
0000714ce89d4d7e  vmovaps xmm2, [rsp+0x20]
0000714ce89d4d84  vmovaps xmm3, [rsp+0x30]
0000714ce89d4d8a  vmovaps xmm4, [rsp+0x40]
0000714ce89d4d90  vmovaps xmm5, [rsp+0x50]
0000714ce89d4d96  vmovaps xmm6, [rsp+0x60]
0000714ce89d4d9c  vmovaps xmm7, [rsp+0x70]
0000714ce89d4da2  vmovaps xmm8, [rsp+0x80]
0000714ce89d4dab  vmovaps xmm9, [rsp+0x90]
0000714ce89d4db4  vmovaps xmm10, [rsp+0xA0]
0000714ce89d4dbd  vmovaps xmm11, [rsp+0xB0]
0000714ce89d4dc6  vmovaps xmm12, [rsp+0xC0]
0000714ce89d4dcf  vmovaps xmm14, [rsp+0xD0]
0000714ce89d4dd8  vmovaps xmm15, [rsp+0xE0]
0000714ce89d4de1  add rsp, 0xF0
0000714ce89d4de8  pop r11
0000714ce89d4dea  pop r10
0000714ce89d4dec  pop r9
0000714ce89d4dee  pop r8
0000714ce89d4df0  pop rsi
0000714ce89d4df1  pop rdi
0000714ce89d4df2  pop rdx
0000714ce89d4df3  pop rcx
0000714ce89d4df4  pop rax
0000714ce89d4df5  add rsp, 0x08
0000714ce89d4df9  jmp 0x0000714CE89D2CD6
0000714ce89d4dfe  sub rsp, 0x08
0000714ce89d4e02  push rax
0000714ce89d4e03  push rcx
0000714ce89d4e04  push rdx
0000714ce89d4e05  push rdi
0000714ce89d4e06  push rsi
0000714ce89d4e07  push r8
0000714ce89d4e09  push r9
0000714ce89d4e0b  push r10
0000714ce89d4e0d  push r11
0000714ce89d4e0f  sub rsp, 0xF0
0000714ce89d4e16  vmovaps [rsp], xmm0
0000714ce89d4e1b  vmovaps [rsp+0x10], xmm1
0000714ce89d4e21  vmovaps [rsp+0x20], xmm2
0000714ce89d4e27  vmovaps [rsp+0x30], xmm3
0000714ce89d4e2d  vmovaps [rsp+0x40], xmm4
0000714ce89d4e33  vmovaps [rsp+0x50], xmm5
0000714ce89d4e39  vmovaps [rsp+0x60], xmm6
0000714ce89d4e3f  vmovaps [rsp+0x70], xmm7
0000714ce89d4e45  vmovaps [rsp+0x80], xmm8
0000714ce89d4e4e  vmovaps [rsp+0x90], xmm9
0000714ce89d4e57  vmovaps [rsp+0xA0], xmm10
0000714ce89d4e60  vmovaps [rsp+0xB0], xmm11
0000714ce89d4e69  vmovaps [rsp+0xC0], xmm12
0000714ce89d4e72  vmovaps [rsp+0xD0], xmm13
0000714ce89d4e7b  vmovaps [rsp+0xE0], xmm14
0000714ce89d4e84  sub rsp, 0x30
0000714ce89d4e88  movaps [rsp], xmm15
0000714ce89d4e8d  movaps [rsp+0x10], xmm14
0000714ce89d4e93  movaps [rsp+0x20], xmm1
0000714ce89d4e98  lea rdi, [rsp]
0000714ce89d4e9c  mov esi, 0x00
0000714ce89d4ea1  mov rax, 0x57A55D340530
0000714ce89d4eab  call rax
0000714ce89d4ead  movaps xmm15, [rsp]
0000714ce89d4eb2  add rsp, 0x30
0000714ce89d4eb6  vmovaps xmm0, [rsp]
0000714ce89d4ebb  vmovaps xmm1, [rsp+0x10]
0000714ce89d4ec1  vmovaps xmm2, [rsp+0x20]
0000714ce89d4ec7  vmovaps xmm3, [rsp+0x30]
0000714ce89d4ecd  vmovaps xmm4, [rsp+0x40]
0000714ce89d4ed3  vmovaps xmm5, [rsp+0x50]
0000714ce89d4ed9  vmovaps xmm6, [rsp+0x60]
0000714ce89d4edf  vmovaps xmm7, [rsp+0x70]
0000714ce89d4ee5  vmovaps xmm8, [rsp+0x80]
0000714ce89d4eee  vmovaps xmm9, [rsp+0x90]
0000714ce89d4ef7  vmovaps xmm10, [rsp+0xA0]
0000714ce89d4f00  vmovaps xmm11, [rsp+0xB0]
0000714ce89d4f09  vmovaps xmm12, [rsp+0xC0]
0000714ce89d4f12  vmovaps xmm13, [rsp+0xD0]
0000714ce89d4f1b  vmovaps xmm14, [rsp+0xE0]
0000714ce89d4f24  add rsp, 0xF0
0000714ce89d4f2b  pop r11
0000714ce89d4f2d  pop r10
0000714ce89d4f2f  pop r9
0000714ce89d4f31  pop r8
0000714ce89d4f33  pop rsi
0000714ce89d4f34  pop rdi
0000714ce89d4f35  pop rdx
0000714ce89d4f36  pop rcx
0000714ce89d4f37  pop rax
0000714ce89d4f38  add rsp, 0x08
0000714ce89d4f3c  jmp 0x0000714CE89D2D12
0000714ce89d4f41  call 0x0000714CE87FF430
0000714ce89d4f46  jmp 0x0000714CE89D2D1F
0000714ce89d4f4b  sub rsp, 0x08
0000714ce89d4f4f  push rax
0000714ce89d4f50  push rcx
0000714ce89d4f51  push rdx
0000714ce89d4f52  push rdi
0000714ce89d4f53  push rsi
0000714ce89d4f54  push r8
0000714ce89d4f56  push r9
0000714ce89d4f58  push r10
0000714ce89d4f5a  push r11
0000714ce89d4f5c  sub rsp, 0xF0
0000714ce89d4f63  vmovaps [rsp], xmm0
0000714ce89d4f68  vmovaps [rsp+0x10], xmm1
0000714ce89d4f6e  vmovaps [rsp+0x20], xmm2
0000714ce89d4f74  vmovaps [rsp+0x30], xmm3
0000714ce89d4f7a  vmovaps [rsp+0x40], xmm4
0000714ce89d4f80  vmovaps [rsp+0x50], xmm5
0000714ce89d4f86  vmovaps [rsp+0x60], xmm6
0000714ce89d4f8c  vmovaps [rsp+0x70], xmm7
0000714ce89d4f92  vmovaps [rsp+0x80], xmm8
0000714ce89d4f9b  vmovaps [rsp+0x90], xmm9
0000714ce89d4fa4  vmovaps [rsp+0xA0], xmm10
0000714ce89d4fad  vmovaps [rsp+0xB0], xmm11
0000714ce89d4fb6  vmovaps [rsp+0xC0], xmm12
0000714ce89d4fbf  vmovaps [rsp+0xD0], xmm13
0000714ce89d4fc8  vmovaps [rsp+0xE0], xmm15
0000714ce89d4fd1  sub rsp, 0x30
0000714ce89d4fd5  movaps [rsp], xmm14
0000714ce89d4fda  movaps [rsp+0x10], xmm13
0000714ce89d4fe0  movaps [rsp+0x20], xmm2
0000714ce89d4fe5  lea rdi, [rsp]
0000714ce89d4fe9  mov esi, 0x00
0000714ce89d4fee  mov rax, 0x57A55D340530
0000714ce89d4ff8  call rax
0000714ce89d4ffa  movaps xmm14, [rsp]
0000714ce89d4fff  add rsp, 0x30
0000714ce89d5003  vmovaps xmm0, [rsp]
0000714ce89d5008  vmovaps xmm1, [rsp+0x10]
0000714ce89d500e  vmovaps xmm2, [rsp+0x20]
0000714ce89d5014  vmovaps xmm3, [rsp+0x30]
0000714ce89d501a  vmovaps xmm4, [rsp+0x40]
0000714ce89d5020  vmovaps xmm5, [rsp+0x50]
0000714ce89d5026  vmovaps xmm6, [rsp+0x60]
0000714ce89d502c  vmovaps xmm7, [rsp+0x70]
0000714ce89d5032  vmovaps xmm8, [rsp+0x80]
0000714ce89d503b  vmovaps xmm9, [rsp+0x90]
0000714ce89d5044  vmovaps xmm10, [rsp+0xA0]
0000714ce89d504d  vmovaps xmm11, [rsp+0xB0]
0000714ce89d5056  vmovaps xmm12, [rsp+0xC0]
0000714ce89d505f  vmovaps xmm13, [rsp+0xD0]
0000714ce89d5068  vmovaps xmm15, [rsp+0xE0]
0000714ce89d5071  add rsp, 0xF0
0000714ce89d5078  pop r11
0000714ce89d507a  pop r10
0000714ce89d507c  pop r9
0000714ce89d507e  pop r8
0000714ce89d5080  pop rsi
0000714ce89d5081  pop rdi
0000714ce89d5082  pop rdx
0000714ce89d5083  pop rcx
0000714ce89d5084  pop rax
0000714ce89d5085  add rsp, 0x08
0000714ce89d5089  jmp 0x0000714CE89D2D4B
0000714ce89d508e  sub rsp, 0x08
0000714ce89d5092  push rax
0000714ce89d5093  push rcx
0000714ce89d5094  push rdx
0000714ce89d5095  push rdi
0000714ce89d5096  push rsi
0000714ce89d5097  push r8
0000714ce89d5099  push r9
0000714ce89d509b  push r10
0000714ce89d509d  push r11
0000714ce89d509f  sub rsp, 0xF0
0000714ce89d50a6  vmovaps [rsp], xmm0
0000714ce89d50ab  vmovaps [rsp+0x10], xmm2
0000714ce89d50b1  vmovaps [rsp+0x20], xmm3
0000714ce89d50b7  vmovaps [rsp+0x30], xmm4
0000714ce89d50bd  vmovaps [rsp+0x40], xmm5
0000714ce89d50c3  vmovaps [rsp+0x50], xmm6
0000714ce89d50c9  vmovaps [rsp+0x60], xmm7
0000714ce89d50cf  vmovaps [rsp+0x70], xmm8
0000714ce89d50d5  vmovaps [rsp+0x80], xmm9
0000714ce89d50de  vmovaps [rsp+0x90], xmm10
0000714ce89d50e7  vmovaps [rsp+0xA0], xmm11
0000714ce89d50f0  vmovaps [rsp+0xB0], xmm12
0000714ce89d50f9  vmovaps [rsp+0xC0], xmm13
0000714ce89d5102  vmovaps [rsp+0xD0], xmm14
0000714ce89d510b  vmovaps [rsp+0xE0], xmm15
0000714ce89d5114  sub rsp, 0x30
0000714ce89d5118  movaps [rsp], xmm1
0000714ce89d511c  movaps [rsp+0x10], xmm13
0000714ce89d5122  movaps [rsp+0x20], xmm2
0000714ce89d5127  lea rdi, [rsp]
0000714ce89d512b  mov esi, 0x00
0000714ce89d5130  mov rax, 0x57A55D340530
0000714ce89d513a  call rax
0000714ce89d513c  movaps xmm1, [rsp]
0000714ce89d5140  add rsp, 0x30
0000714ce89d5144  vmovaps xmm0, [rsp]
0000714ce89d5149  vmovaps xmm2, [rsp+0x10]
0000714ce89d514f  vmovaps xmm3, [rsp+0x20]
0000714ce89d5155  vmovaps xmm4, [rsp+0x30]
0000714ce89d515b  vmovaps xmm5, [rsp+0x40]
0000714ce89d5161  vmovaps xmm6, [rsp+0x50]
0000714ce89d5167  vmovaps xmm7, [rsp+0x60]
0000714ce89d516d  vmovaps xmm8, [rsp+0x70]
0000714ce89d5173  vmovaps xmm9, [rsp+0x80]
0000714ce89d517c  vmovaps xmm10, [rsp+0x90]
0000714ce89d5185  vmovaps xmm11, [rsp+0xA0]
0000714ce89d518e  vmovaps xmm12, [rsp+0xB0]
0000714ce89d5197  vmovaps xmm13, [rsp+0xC0]
0000714ce89d51a0  vmovaps xmm14, [rsp+0xD0]
0000714ce89d51a9  vmovaps xmm15, [rsp+0xE0]
0000714ce89d51b2  add rsp, 0xF0
0000714ce89d51b9  pop r11
0000714ce89d51bb  pop r10
0000714ce89d51bd  pop r9
0000714ce89d51bf  pop r8
0000714ce89d51c1  pop rsi
0000714ce89d51c2  pop rdi
0000714ce89d51c3  pop rdx
0000714ce89d51c4  pop rcx
0000714ce89d51c5  pop rax
0000714ce89d51c6  add rsp, 0x08
0000714ce89d51ca  jmp 0x0000714CE89D2D79
0000714ce89d51cf  sub rsp, 0x08
0000714ce89d51d3  push rax
0000714ce89d51d4  push rcx
0000714ce89d51d5  push rdx
0000714ce89d51d6  push rdi
0000714ce89d51d7  push rsi
0000714ce89d51d8  push r8
0000714ce89d51da  push r9
0000714ce89d51dc  push r10
0000714ce89d51de  push r11
0000714ce89d51e0  sub rsp, 0xF0
0000714ce89d51e7  vmovaps [rsp], xmm0
0000714ce89d51ec  vmovaps [rsp+0x10], xmm1
0000714ce89d51f2  vmovaps [rsp+0x20], xmm3
0000714ce89d51f8  vmovaps [rsp+0x30], xmm4
0000714ce89d51fe  vmovaps [rsp+0x40], xmm5
0000714ce89d5204  vmovaps [rsp+0x50], xmm6
0000714ce89d520a  vmovaps [rsp+0x60], xmm7
0000714ce89d5210  vmovaps [rsp+0x70], xmm8
0000714ce89d5216  vmovaps [rsp+0x80], xmm9
0000714ce89d521f  vmovaps [rsp+0x90], xmm10
0000714ce89d5228  vmovaps [rsp+0xA0], xmm11
0000714ce89d5231  vmovaps [rsp+0xB0], xmm12
0000714ce89d523a  vmovaps [rsp+0xC0], xmm13
0000714ce89d5243  vmovaps [rsp+0xD0], xmm14
0000714ce89d524c  vmovaps [rsp+0xE0], xmm15
0000714ce89d5255  sub rsp, 0x30
0000714ce89d5259  movaps [rsp], xmm2
0000714ce89d525d  movaps [rsp+0x10], xmm1
0000714ce89d5262  movaps [rsp+0x20], xmm13
0000714ce89d5268  lea rdi, [rsp]
0000714ce89d526c  mov esi, 0x00
0000714ce89d5271  mov rax, 0x57A55D340530
0000714ce89d527b  call rax
0000714ce89d527d  movaps xmm2, [rsp]
0000714ce89d5281  add rsp, 0x30
0000714ce89d5285  vmovaps xmm0, [rsp]
0000714ce89d528a  vmovaps xmm1, [rsp+0x10]
0000714ce89d5290  vmovaps xmm3, [rsp+0x20]
0000714ce89d5296  vmovaps xmm4, [rsp+0x30]
0000714ce89d529c  vmovaps xmm5, [rsp+0x40]
0000714ce89d52a2  vmovaps xmm6, [rsp+0x50]
0000714ce89d52a8  vmovaps xmm7, [rsp+0x60]
0000714ce89d52ae  vmovaps xmm8, [rsp+0x70]
0000714ce89d52b4  vmovaps xmm9, [rsp+0x80]
0000714ce89d52bd  vmovaps xmm10, [rsp+0x90]
0000714ce89d52c6  vmovaps xmm11, [rsp+0xA0]
0000714ce89d52cf  vmovaps xmm12, [rsp+0xB0]
0000714ce89d52d8  vmovaps xmm13, [rsp+0xC0]
0000714ce89d52e1  vmovaps xmm14, [rsp+0xD0]
0000714ce89d52ea  vmovaps xmm15, [rsp+0xE0]
0000714ce89d52f3  add rsp, 0xF0
0000714ce89d52fa  pop r11
0000714ce89d52fc  pop r10
0000714ce89d52fe  pop r9
0000714ce89d5300  pop r8
0000714ce89d5302  pop rsi
0000714ce89d5303  pop rdi
0000714ce89d5304  pop rdx
0000714ce89d5305  pop rcx
0000714ce89d5306  pop rax
0000714ce89d5307  add rsp, 0x08
0000714ce89d530b  jmp 0x0000714CE89D2DD2
0000714ce89d5310  call 0x0000714CE87FF430
0000714ce89d5315  jmp 0x0000714CE89D2DDF
0000714ce89d531a  sub rsp, 0x08
0000714ce89d531e  push rax
0000714ce89d531f  push rcx
0000714ce89d5320  push rdx
0000714ce89d5321  push rdi
0000714ce89d5322  push rsi
0000714ce89d5323  push r8
0000714ce89d5325  push r9
0000714ce89d5327  push r10
0000714ce89d5329  push r11
0000714ce89d532b  sub rsp, 0xF0
0000714ce89d5332  vmovaps [rsp], xmm0
0000714ce89d5337  vmovaps [rsp+0x10], xmm1
0000714ce89d533d  vmovaps [rsp+0x20], xmm2
0000714ce89d5343  vmovaps [rsp+0x30], xmm3
0000714ce89d5349  vmovaps [rsp+0x40], xmm4
0000714ce89d534f  vmovaps [rsp+0x50], xmm5
0000714ce89d5355  vmovaps [rsp+0x60], xmm6
0000714ce89d535b  vmovaps [rsp+0x70], xmm7
0000714ce89d5361  vmovaps [rsp+0x80], xmm8
0000714ce89d536a  vmovaps [rsp+0x90], xmm9
0000714ce89d5373  vmovaps [rsp+0xA0], xmm10
0000714ce89d537c  vmovaps [rsp+0xB0], xmm11
0000714ce89d5385  vmovaps [rsp+0xC0], xmm12
0000714ce89d538e  vmovaps [rsp+0xD0], xmm13
0000714ce89d5397  vmovaps [rsp+0xE0], xmm14
0000714ce89d53a0  sub rsp, 0x30
0000714ce89d53a4  movaps [rsp], xmm15
0000714ce89d53a9  movaps [rsp+0x10], xmm13
0000714ce89d53af  movaps [rsp+0x20], xmm1
0000714ce89d53b4  lea rdi, [rsp]
0000714ce89d53b8  mov esi, 0x00
0000714ce89d53bd  mov rax, 0x57A55D340530
0000714ce89d53c7  call rax
0000714ce89d53c9  movaps xmm15, [rsp]
0000714ce89d53ce  add rsp, 0x30
0000714ce89d53d2  vmovaps xmm0, [rsp]
0000714ce89d53d7  vmovaps xmm1, [rsp+0x10]
0000714ce89d53dd  vmovaps xmm2, [rsp+0x20]
0000714ce89d53e3  vmovaps xmm3, [rsp+0x30]
0000714ce89d53e9  vmovaps xmm4, [rsp+0x40]
0000714ce89d53ef  vmovaps xmm5, [rsp+0x50]
0000714ce89d53f5  vmovaps xmm6, [rsp+0x60]
0000714ce89d53fb  vmovaps xmm7, [rsp+0x70]
0000714ce89d5401  vmovaps xmm8, [rsp+0x80]
0000714ce89d540a  vmovaps xmm9, [rsp+0x90]
0000714ce89d5413  vmovaps xmm10, [rsp+0xA0]
0000714ce89d541c  vmovaps xmm11, [rsp+0xB0]
0000714ce89d5425  vmovaps xmm12, [rsp+0xC0]
0000714ce89d542e  vmovaps xmm13, [rsp+0xD0]
0000714ce89d5437  vmovaps xmm14, [rsp+0xE0]
0000714ce89d5440  add rsp, 0xF0
0000714ce89d5447  pop r11
0000714ce89d5449  pop r10
0000714ce89d544b  pop r9
0000714ce89d544d  pop r8
0000714ce89d544f  pop rsi
0000714ce89d5450  pop rdi
0000714ce89d5451  pop rdx
0000714ce89d5452  pop rcx
0000714ce89d5453  pop rax
0000714ce89d5454  add rsp, 0x08
0000714ce89d5458  jmp 0x0000714CE89D2E1E
0000714ce89d545d  sub rsp, 0x08
0000714ce89d5461  push rax
0000714ce89d5462  push rcx
0000714ce89d5463  push rdx
0000714ce89d5464  push rdi
0000714ce89d5465  push rsi
0000714ce89d5466  push r8
0000714ce89d5468  push r9
0000714ce89d546a  push r10
0000714ce89d546c  push r11
0000714ce89d546e  sub rsp, 0xF0
0000714ce89d5475  vmovaps [rsp], xmm0
0000714ce89d547a  vmovaps [rsp+0x10], xmm1
0000714ce89d5480  vmovaps [rsp+0x20], xmm2
0000714ce89d5486  vmovaps [rsp+0x30], xmm3
0000714ce89d548c  vmovaps [rsp+0x40], xmm4
0000714ce89d5492  vmovaps [rsp+0x50], xmm5
0000714ce89d5498  vmovaps [rsp+0x60], xmm6
0000714ce89d549e  vmovaps [rsp+0x70], xmm7
0000714ce89d54a4  vmovaps [rsp+0x80], xmm8
0000714ce89d54ad  vmovaps [rsp+0x90], xmm9
0000714ce89d54b6  vmovaps [rsp+0xA0], xmm10
0000714ce89d54bf  vmovaps [rsp+0xB0], xmm11
0000714ce89d54c8  vmovaps [rsp+0xC0], xmm12
0000714ce89d54d1  vmovaps [rsp+0xD0], xmm13
0000714ce89d54da  vmovaps [rsp+0xE0], xmm15
0000714ce89d54e3  sub rsp, 0x30
0000714ce89d54e7  movaps [rsp], xmm14
0000714ce89d54ec  movaps [rsp+0x10], xmm11
0000714ce89d54f2  movaps [rsp+0x20], xmm1
0000714ce89d54f7  lea rdi, [rsp]
0000714ce89d54fb  mov esi, 0x00
0000714ce89d5500  mov rax, 0x57A55D340530
0000714ce89d550a  call rax
0000714ce89d550c  movaps xmm14, [rsp]
0000714ce89d5511  add rsp, 0x30
0000714ce89d5515  vmovaps xmm0, [rsp]
0000714ce89d551a  vmovaps xmm1, [rsp+0x10]
0000714ce89d5520  vmovaps xmm2, [rsp+0x20]
0000714ce89d5526  vmovaps xmm3, [rsp+0x30]
0000714ce89d552c  vmovaps xmm4, [rsp+0x40]
0000714ce89d5532  vmovaps xmm5, [rsp+0x50]
0000714ce89d5538  vmovaps xmm6, [rsp+0x60]
0000714ce89d553e  vmovaps xmm7, [rsp+0x70]
0000714ce89d5544  vmovaps xmm8, [rsp+0x80]
0000714ce89d554d  vmovaps xmm9, [rsp+0x90]
0000714ce89d5556  vmovaps xmm10, [rsp+0xA0]
0000714ce89d555f  vmovaps xmm11, [rsp+0xB0]
0000714ce89d5568  vmovaps xmm12, [rsp+0xC0]
0000714ce89d5571  vmovaps xmm13, [rsp+0xD0]
0000714ce89d557a  vmovaps xmm15, [rsp+0xE0]
0000714ce89d5583  add rsp, 0xF0
0000714ce89d558a  pop r11
0000714ce89d558c  pop r10
0000714ce89d558e  pop r9
0000714ce89d5590  pop r8
0000714ce89d5592  pop rsi
0000714ce89d5593  pop rdi
0000714ce89d5594  pop rdx
0000714ce89d5595  pop rcx
0000714ce89d5596  pop rax
0000714ce89d5597  add rsp, 0x08
0000714ce89d559b  jmp 0x0000714CE89D2E48
0000714ce89d55a0  sub rsp, 0x08
0000714ce89d55a4  push rax
0000714ce89d55a5  push rcx
0000714ce89d55a6  push rdx
0000714ce89d55a7  push rdi
0000714ce89d55a8  push rsi
0000714ce89d55a9  push r8
0000714ce89d55ab  push r9
0000714ce89d55ad  push r10
0000714ce89d55af  push r11
0000714ce89d55b1  sub rsp, 0xF0
0000714ce89d55b8  vmovaps [rsp], xmm0
0000714ce89d55bd  vmovaps [rsp+0x10], xmm1
0000714ce89d55c3  vmovaps [rsp+0x20], xmm2
0000714ce89d55c9  vmovaps [rsp+0x30], xmm3
0000714ce89d55cf  vmovaps [rsp+0x40], xmm4
0000714ce89d55d5  vmovaps [rsp+0x50], xmm5
0000714ce89d55db  vmovaps [rsp+0x60], xmm6
0000714ce89d55e1  vmovaps [rsp+0x70], xmm7
0000714ce89d55e7  vmovaps [rsp+0x80], xmm8
0000714ce89d55f0  vmovaps [rsp+0x90], xmm9
0000714ce89d55f9  vmovaps [rsp+0xA0], xmm10
0000714ce89d5602  vmovaps [rsp+0xB0], xmm11
0000714ce89d560b  vmovaps [rsp+0xC0], xmm12
0000714ce89d5614  vmovaps [rsp+0xD0], xmm14
0000714ce89d561d  vmovaps [rsp+0xE0], xmm15
0000714ce89d5626  sub rsp, 0x30
0000714ce89d562a  movaps [rsp], xmm13
0000714ce89d562f  movaps [rsp+0x10], xmm11
0000714ce89d5635  movaps [rsp+0x20], xmm1
0000714ce89d563a  lea rdi, [rsp]
0000714ce89d563e  mov esi, 0x00
0000714ce89d5643  mov rax, 0x57A55D340530
0000714ce89d564d  call rax
0000714ce89d564f  movaps xmm13, [rsp]
0000714ce89d5654  add rsp, 0x30
0000714ce89d5658  vmovaps xmm0, [rsp]
0000714ce89d565d  vmovaps xmm1, [rsp+0x10]
0000714ce89d5663  vmovaps xmm2, [rsp+0x20]
0000714ce89d5669  vmovaps xmm3, [rsp+0x30]
0000714ce89d566f  vmovaps xmm4, [rsp+0x40]
0000714ce89d5675  vmovaps xmm5, [rsp+0x50]
0000714ce89d567b  vmovaps xmm6, [rsp+0x60]
0000714ce89d5681  vmovaps xmm7, [rsp+0x70]
0000714ce89d5687  vmovaps xmm8, [rsp+0x80]
0000714ce89d5690  vmovaps xmm9, [rsp+0x90]
0000714ce89d5699  vmovaps xmm10, [rsp+0xA0]
0000714ce89d56a2  vmovaps xmm11, [rsp+0xB0]
0000714ce89d56ab  vmovaps xmm12, [rsp+0xC0]
0000714ce89d56b4  vmovaps xmm14, [rsp+0xD0]
0000714ce89d56bd  vmovaps xmm15, [rsp+0xE0]
0000714ce89d56c6  add rsp, 0xF0
0000714ce89d56cd  pop r11
0000714ce89d56cf  pop r10
0000714ce89d56d1  pop r9
0000714ce89d56d3  pop r8
0000714ce89d56d5  pop rsi
0000714ce89d56d6  pop rdi
0000714ce89d56d7  pop rdx
0000714ce89d56d8  pop rcx
0000714ce89d56d9  pop rax
0000714ce89d56da  add rsp, 0x08
0000714ce89d56de  jmp 0x0000714CE89D2E9D
0000714ce89d56e3  call 0x0000714CE87FF430
0000714ce89d56e8  jmp 0x0000714CE89D2EAA
0000714ce89d56ed  sub rsp, 0x08
0000714ce89d56f1  push rax
0000714ce89d56f2  push rcx
0000714ce89d56f3  push rdx
0000714ce89d56f4  push rdi
0000714ce89d56f5  push rsi
0000714ce89d56f6  push r8
0000714ce89d56f8  push r9
0000714ce89d56fa  push r10
0000714ce89d56fc  push r11
0000714ce89d56fe  sub rsp, 0xF0
0000714ce89d5705  vmovaps [rsp], xmm0
0000714ce89d570a  vmovaps [rsp+0x10], xmm1
0000714ce89d5710  vmovaps [rsp+0x20], xmm2
0000714ce89d5716  vmovaps [rsp+0x30], xmm3
0000714ce89d571c  vmovaps [rsp+0x40], xmm4
0000714ce89d5722  vmovaps [rsp+0x50], xmm5
0000714ce89d5728  vmovaps [rsp+0x60], xmm6
0000714ce89d572e  vmovaps [rsp+0x70], xmm7
0000714ce89d5734  vmovaps [rsp+0x80], xmm8
0000714ce89d573d  vmovaps [rsp+0x90], xmm9
0000714ce89d5746  vmovaps [rsp+0xA0], xmm10
0000714ce89d574f  vmovaps [rsp+0xB0], xmm11
0000714ce89d5758  vmovaps [rsp+0xC0], xmm12
0000714ce89d5761  vmovaps [rsp+0xD0], xmm13
0000714ce89d576a  vmovaps [rsp+0xE0], xmm14
0000714ce89d5773  sub rsp, 0x30
0000714ce89d5777  movaps [rsp], xmm15
0000714ce89d577c  movaps [rsp+0x10], xmm11
0000714ce89d5782  movaps [rsp+0x20], xmm1
0000714ce89d5787  lea rdi, [rsp]
0000714ce89d578b  mov esi, 0x00
0000714ce89d5790  mov rax, 0x57A55D340530
0000714ce89d579a  call rax
0000714ce89d579c  movaps xmm15, [rsp]
0000714ce89d57a1  add rsp, 0x30
0000714ce89d57a5  vmovaps xmm0, [rsp]
0000714ce89d57aa  vmovaps xmm1, [rsp+0x10]
0000714ce89d57b0  vmovaps xmm2, [rsp+0x20]
0000714ce89d57b6  vmovaps xmm3, [rsp+0x30]
0000714ce89d57bc  vmovaps xmm4, [rsp+0x40]
0000714ce89d57c2  vmovaps xmm5, [rsp+0x50]
0000714ce89d57c8  vmovaps xmm6, [rsp+0x60]
0000714ce89d57ce  vmovaps xmm7, [rsp+0x70]
0000714ce89d57d4  vmovaps xmm8, [rsp+0x80]
0000714ce89d57dd  vmovaps xmm9, [rsp+0x90]
0000714ce89d57e6  vmovaps xmm10, [rsp+0xA0]
0000714ce89d57ef  vmovaps xmm11, [rsp+0xB0]
0000714ce89d57f8  vmovaps xmm12, [rsp+0xC0]
0000714ce89d5801  vmovaps xmm13, [rsp+0xD0]
0000714ce89d580a  vmovaps xmm14, [rsp+0xE0]
0000714ce89d5813  add rsp, 0xF0
0000714ce89d581a  pop r11
0000714ce89d581c  pop r10
0000714ce89d581e  pop r9
0000714ce89d5820  pop r8
0000714ce89d5822  pop rsi
0000714ce89d5823  pop rdi
0000714ce89d5824  pop rdx
0000714ce89d5825  pop rcx
0000714ce89d5826  pop rax
0000714ce89d5827  add rsp, 0x08
0000714ce89d582b  jmp 0x0000714CE89D2EE3
0000714ce89d5830  sub rsp, 0x08
0000714ce89d5834  push rax
0000714ce89d5835  push rcx
0000714ce89d5836  push rdx
0000714ce89d5837  push rdi
0000714ce89d5838  push rsi
0000714ce89d5839  push r8
0000714ce89d583b  push r9
0000714ce89d583d  push r10
0000714ce89d583f  push r11
0000714ce89d5841  sub rsp, 0xF0
0000714ce89d5848  vmovaps [rsp], xmm0
0000714ce89d584d  vmovaps [rsp+0x10], xmm1
0000714ce89d5853  vmovaps [rsp+0x20], xmm2
0000714ce89d5859  vmovaps [rsp+0x30], xmm3
0000714ce89d585f  vmovaps [rsp+0x40], xmm4
0000714ce89d5865  vmovaps [rsp+0x50], xmm5
0000714ce89d586b  vmovaps [rsp+0x60], xmm6
0000714ce89d5871  vmovaps [rsp+0x70], xmm7
0000714ce89d5877  vmovaps [rsp+0x80], xmm8
0000714ce89d5880  vmovaps [rsp+0x90], xmm9
0000714ce89d5889  vmovaps [rsp+0xA0], xmm10
0000714ce89d5892  vmovaps [rsp+0xB0], xmm12
0000714ce89d589b  vmovaps [rsp+0xC0], xmm13
0000714ce89d58a4  vmovaps [rsp+0xD0], xmm14
0000714ce89d58ad  vmovaps [rsp+0xE0], xmm15
0000714ce89d58b6  sub rsp, 0x30
0000714ce89d58ba  movaps [rsp], xmm11
0000714ce89d58bf  movaps [rsp+0x10], xmm6
0000714ce89d58c4  movaps [rsp+0x20], xmm14
0000714ce89d58ca  lea rdi, [rsp]
0000714ce89d58ce  mov esi, 0x00
0000714ce89d58d3  mov rax, 0x57A55D340530
0000714ce89d58dd  call rax
0000714ce89d58df  movaps xmm11, [rsp]
0000714ce89d58e4  add rsp, 0x30
0000714ce89d58e8  vmovaps xmm0, [rsp]
0000714ce89d58ed  vmovaps xmm1, [rsp+0x10]
0000714ce89d58f3  vmovaps xmm2, [rsp+0x20]
0000714ce89d58f9  vmovaps xmm3, [rsp+0x30]
0000714ce89d58ff  vmovaps xmm4, [rsp+0x40]
0000714ce89d5905  vmovaps xmm5, [rsp+0x50]
0000714ce89d590b  vmovaps xmm6, [rsp+0x60]
0000714ce89d5911  vmovaps xmm7, [rsp+0x70]
0000714ce89d5917  vmovaps xmm8, [rsp+0x80]
0000714ce89d5920  vmovaps xmm9, [rsp+0x90]
0000714ce89d5929  vmovaps xmm10, [rsp+0xA0]
0000714ce89d5932  vmovaps xmm12, [rsp+0xB0]
0000714ce89d593b  vmovaps xmm13, [rsp+0xC0]
0000714ce89d5944  vmovaps xmm14, [rsp+0xD0]
0000714ce89d594d  vmovaps xmm15, [rsp+0xE0]
0000714ce89d5956  add rsp, 0xF0
0000714ce89d595d  pop r11
0000714ce89d595f  pop r10
0000714ce89d5961  pop r9
0000714ce89d5963  pop r8
0000714ce89d5965  pop rsi
0000714ce89d5966  pop rdi
0000714ce89d5967  pop rdx
0000714ce89d5968  pop rcx
0000714ce89d5969  pop rax
0000714ce89d596a  add rsp, 0x08
0000714ce89d596e  jmp 0x0000714CE89D2F5B
0000714ce89d5973  call 0x0000714CE87FF430
0000714ce89d5978  jmp 0x0000714CE89D2F65
0000714ce89d597d  sub rsp, 0x08
0000714ce89d5981  push rax
0000714ce89d5982  push rcx
0000714ce89d5983  push rdx
0000714ce89d5984  push rdi
0000714ce89d5985  push rsi
0000714ce89d5986  push r8
0000714ce89d5988  push r9
0000714ce89d598a  push r10
0000714ce89d598c  push r11
0000714ce89d598e  sub rsp, 0xF0
0000714ce89d5995  vmovaps [rsp], xmm0
0000714ce89d599a  vmovaps [rsp+0x10], xmm1
0000714ce89d59a0  vmovaps [rsp+0x20], xmm2
0000714ce89d59a6  vmovaps [rsp+0x30], xmm3
0000714ce89d59ac  vmovaps [rsp+0x40], xmm4
0000714ce89d59b2  vmovaps [rsp+0x50], xmm5
0000714ce89d59b8  vmovaps [rsp+0x60], xmm6
0000714ce89d59be  vmovaps [rsp+0x70], xmm7
0000714ce89d59c4  vmovaps [rsp+0x80], xmm8
0000714ce89d59cd  vmovaps [rsp+0x90], xmm9
0000714ce89d59d6  vmovaps [rsp+0xA0], xmm10
0000714ce89d59df  vmovaps [rsp+0xB0], xmm11
0000714ce89d59e8  vmovaps [rsp+0xC0], xmm12
0000714ce89d59f1  vmovaps [rsp+0xD0], xmm13
0000714ce89d59fa  vmovaps [rsp+0xE0], xmm15
0000714ce89d5a03  sub rsp, 0x30
0000714ce89d5a07  movaps [rsp], xmm14
0000714ce89d5a0c  movaps [rsp+0x10], xmm6
0000714ce89d5a11  movaps [rsp+0x20], xmm2
0000714ce89d5a16  lea rdi, [rsp]
0000714ce89d5a1a  mov esi, 0x00
0000714ce89d5a1f  mov rax, 0x57A55D340530
0000714ce89d5a29  call rax
0000714ce89d5a2b  movaps xmm14, [rsp]
0000714ce89d5a30  add rsp, 0x30
0000714ce89d5a34  vmovaps xmm0, [rsp]
0000714ce89d5a39  vmovaps xmm1, [rsp+0x10]
0000714ce89d5a3f  vmovaps xmm2, [rsp+0x20]
0000714ce89d5a45  vmovaps xmm3, [rsp+0x30]
0000714ce89d5a4b  vmovaps xmm4, [rsp+0x40]
0000714ce89d5a51  vmovaps xmm5, [rsp+0x50]
0000714ce89d5a57  vmovaps xmm6, [rsp+0x60]
0000714ce89d5a5d  vmovaps xmm7, [rsp+0x70]
0000714ce89d5a63  vmovaps xmm8, [rsp+0x80]
0000714ce89d5a6c  vmovaps xmm9, [rsp+0x90]
0000714ce89d5a75  vmovaps xmm10, [rsp+0xA0]
0000714ce89d5a7e  vmovaps xmm11, [rsp+0xB0]
0000714ce89d5a87  vmovaps xmm12, [rsp+0xC0]
0000714ce89d5a90  vmovaps xmm13, [rsp+0xD0]
0000714ce89d5a99  vmovaps xmm15, [rsp+0xE0]
0000714ce89d5aa2  add rsp, 0xF0
0000714ce89d5aa9  pop r11
0000714ce89d5aab  pop r10
0000714ce89d5aad  pop r9
0000714ce89d5aaf  pop r8
0000714ce89d5ab1  pop rsi
0000714ce89d5ab2  pop rdi
0000714ce89d5ab3  pop rdx
0000714ce89d5ab4  pop rcx
0000714ce89d5ab5  pop rax
0000714ce89d5ab6  add rsp, 0x08
0000714ce89d5aba  jmp 0x0000714CE89D2F99
0000714ce89d5abf  sub rsp, 0x08
0000714ce89d5ac3  push rax
0000714ce89d5ac4  push rcx
0000714ce89d5ac5  push rdx
0000714ce89d5ac6  push rdi
0000714ce89d5ac7  push rsi
0000714ce89d5ac8  push r8
0000714ce89d5aca  push r9
0000714ce89d5acc  push r10
0000714ce89d5ace  push r11
0000714ce89d5ad0  sub rsp, 0xF0
0000714ce89d5ad7  vmovaps [rsp], xmm0
0000714ce89d5adc  vmovaps [rsp+0x10], xmm1
0000714ce89d5ae2  vmovaps [rsp+0x20], xmm2
0000714ce89d5ae8  vmovaps [rsp+0x30], xmm3
0000714ce89d5aee  vmovaps [rsp+0x40], xmm4
0000714ce89d5af4  vmovaps [rsp+0x50], xmm5
0000714ce89d5afa  vmovaps [rsp+0x60], xmm7
0000714ce89d5b00  vmovaps [rsp+0x70], xmm8
0000714ce89d5b06  vmovaps [rsp+0x80], xmm9
0000714ce89d5b0f  vmovaps [rsp+0x90], xmm10
0000714ce89d5b18  vmovaps [rsp+0xA0], xmm11
0000714ce89d5b21  vmovaps [rsp+0xB0], xmm12
0000714ce89d5b2a  vmovaps [rsp+0xC0], xmm13
0000714ce89d5b33  vmovaps [rsp+0xD0], xmm14
0000714ce89d5b3c  vmovaps [rsp+0xE0], xmm15
0000714ce89d5b45  sub rsp, 0x30
0000714ce89d5b49  movaps [rsp], xmm6
0000714ce89d5b4d  movaps [rsp+0x10], xmm5
0000714ce89d5b52  movaps [rsp+0x20], xmm1
0000714ce89d5b57  lea rdi, [rsp]
0000714ce89d5b5b  mov esi, 0x00
0000714ce89d5b60  mov rax, 0x57A55D340530
0000714ce89d5b6a  call rax
0000714ce89d5b6c  movaps xmm6, [rsp]
0000714ce89d5b70  add rsp, 0x30
0000714ce89d5b74  vmovaps xmm0, [rsp]
0000714ce89d5b79  vmovaps xmm1, [rsp+0x10]
0000714ce89d5b7f  vmovaps xmm2, [rsp+0x20]
0000714ce89d5b85  vmovaps xmm3, [rsp+0x30]
0000714ce89d5b8b  vmovaps xmm4, [rsp+0x40]
0000714ce89d5b91  vmovaps xmm5, [rsp+0x50]
0000714ce89d5b97  vmovaps xmm7, [rsp+0x60]
0000714ce89d5b9d  vmovaps xmm8, [rsp+0x70]
0000714ce89d5ba3  vmovaps xmm9, [rsp+0x80]
0000714ce89d5bac  vmovaps xmm10, [rsp+0x90]
0000714ce89d5bb5  vmovaps xmm11, [rsp+0xA0]
0000714ce89d5bbe  vmovaps xmm12, [rsp+0xB0]
0000714ce89d5bc7  vmovaps xmm13, [rsp+0xC0]
0000714ce89d5bd0  vmovaps xmm14, [rsp+0xD0]
0000714ce89d5bd9  vmovaps xmm15, [rsp+0xE0]
0000714ce89d5be2  add rsp, 0xF0
0000714ce89d5be9  pop r11
0000714ce89d5beb  pop r10
0000714ce89d5bed  pop r9
0000714ce89d5bef  pop r8
0000714ce89d5bf1  pop rsi
0000714ce89d5bf2  pop rdi
0000714ce89d5bf3  pop rdx
0000714ce89d5bf4  pop rcx
0000714ce89d5bf5  pop rax
0000714ce89d5bf6  add rsp, 0x08
0000714ce89d5bfa  jmp 0x0000714CE89D2FBF
0000714ce89d5bff  sub rsp, 0x08
0000714ce89d5c03  push rax
0000714ce89d5c04  push rcx
0000714ce89d5c05  push rdx
0000714ce89d5c06  push rdi
0000714ce89d5c07  push rsi
0000714ce89d5c08  push r8
0000714ce89d5c0a  push r9
0000714ce89d5c0c  push r10
0000714ce89d5c0e  push r11
0000714ce89d5c10  sub rsp, 0xF0
0000714ce89d5c17  vmovaps [rsp], xmm0
0000714ce89d5c1c  vmovaps [rsp+0x10], xmm2
0000714ce89d5c22  vmovaps [rsp+0x20], xmm3
0000714ce89d5c28  vmovaps [rsp+0x30], xmm4
0000714ce89d5c2e  vmovaps [rsp+0x40], xmm5
0000714ce89d5c34  vmovaps [rsp+0x50], xmm6
0000714ce89d5c3a  vmovaps [rsp+0x60], xmm7
0000714ce89d5c40  vmovaps [rsp+0x70], xmm8
0000714ce89d5c46  vmovaps [rsp+0x80], xmm9
0000714ce89d5c4f  vmovaps [rsp+0x90], xmm10
0000714ce89d5c58  vmovaps [rsp+0xA0], xmm11
0000714ce89d5c61  vmovaps [rsp+0xB0], xmm12
0000714ce89d5c6a  vmovaps [rsp+0xC0], xmm13
0000714ce89d5c73  vmovaps [rsp+0xD0], xmm14
0000714ce89d5c7c  vmovaps [rsp+0xE0], xmm15
0000714ce89d5c85  sub rsp, 0x30
0000714ce89d5c89  movaps [rsp], xmm1
0000714ce89d5c8d  movaps [rsp+0x10], xmm5
0000714ce89d5c92  movaps [rsp+0x20], xmm13
0000714ce89d5c98  lea rdi, [rsp]
0000714ce89d5c9c  mov esi, 0x00
0000714ce89d5ca1  mov rax, 0x57A55D340530
0000714ce89d5cab  call rax
0000714ce89d5cad  movaps xmm1, [rsp]
0000714ce89d5cb1  add rsp, 0x30
0000714ce89d5cb5  vmovaps xmm0, [rsp]
0000714ce89d5cba  vmovaps xmm2, [rsp+0x10]
0000714ce89d5cc0  vmovaps xmm3, [rsp+0x20]
0000714ce89d5cc6  vmovaps xmm4, [rsp+0x30]
0000714ce89d5ccc  vmovaps xmm5, [rsp+0x40]
0000714ce89d5cd2  vmovaps xmm6, [rsp+0x50]
0000714ce89d5cd8  vmovaps xmm7, [rsp+0x60]
0000714ce89d5cde  vmovaps xmm8, [rsp+0x70]
0000714ce89d5ce4  vmovaps xmm9, [rsp+0x80]
0000714ce89d5ced  vmovaps xmm10, [rsp+0x90]
0000714ce89d5cf6  vmovaps xmm11, [rsp+0xA0]
0000714ce89d5cff  vmovaps xmm12, [rsp+0xB0]
0000714ce89d5d08  vmovaps xmm13, [rsp+0xC0]
0000714ce89d5d11  vmovaps xmm14, [rsp+0xD0]
0000714ce89d5d1a  vmovaps xmm15, [rsp+0xE0]
0000714ce89d5d23  add rsp, 0xF0
0000714ce89d5d2a  pop r11
0000714ce89d5d2c  pop r10
0000714ce89d5d2e  pop r9
0000714ce89d5d30  pop r8
0000714ce89d5d32  pop rsi
0000714ce89d5d33  pop rdi
0000714ce89d5d34  pop rdx
0000714ce89d5d35  pop rcx
0000714ce89d5d36  pop rax
0000714ce89d5d37  add rsp, 0x08
0000714ce89d5d3b  jmp 0x0000714CE89D2FDD
0000714ce89d5d40  sub rsp, 0x08
0000714ce89d5d44  push rax
0000714ce89d5d45  push rcx
0000714ce89d5d46  push rdx
0000714ce89d5d47  push rdi
0000714ce89d5d48  push rsi
0000714ce89d5d49  push r8
0000714ce89d5d4b  push r9
0000714ce89d5d4d  push r10
0000714ce89d5d4f  push r11
0000714ce89d5d51  sub rsp, 0xF0
0000714ce89d5d58  vmovaps [rsp], xmm0
0000714ce89d5d5d  vmovaps [rsp+0x10], xmm1
0000714ce89d5d63  vmovaps [rsp+0x20], xmm2
0000714ce89d5d69  vmovaps [rsp+0x30], xmm3
0000714ce89d5d6f  vmovaps [rsp+0x40], xmm4
0000714ce89d5d75  vmovaps [rsp+0x50], xmm6
0000714ce89d5d7b  vmovaps [rsp+0x60], xmm7
0000714ce89d5d81  vmovaps [rsp+0x70], xmm8
0000714ce89d5d87  vmovaps [rsp+0x80], xmm9
0000714ce89d5d90  vmovaps [rsp+0x90], xmm10
0000714ce89d5d99  vmovaps [rsp+0xA0], xmm11
0000714ce89d5da2  vmovaps [rsp+0xB0], xmm12
0000714ce89d5dab  vmovaps [rsp+0xC0], xmm13
0000714ce89d5db4  vmovaps [rsp+0xD0], xmm14
0000714ce89d5dbd  vmovaps [rsp+0xE0], xmm15
0000714ce89d5dc6  sub rsp, 0x30
0000714ce89d5dca  movaps [rsp], xmm5
0000714ce89d5dce  movaps [rsp+0x10], xmm2
0000714ce89d5dd3  movaps [rsp+0x20], xmm13
0000714ce89d5dd9  lea rdi, [rsp]
0000714ce89d5ddd  mov esi, 0x00
0000714ce89d5de2  mov rax, 0x57A55D340530
0000714ce89d5dec  call rax
0000714ce89d5dee  movaps xmm5, [rsp]
0000714ce89d5df2  add rsp, 0x30
0000714ce89d5df6  vmovaps xmm0, [rsp]
0000714ce89d5dfb  vmovaps xmm1, [rsp+0x10]
0000714ce89d5e01  vmovaps xmm2, [rsp+0x20]
0000714ce89d5e07  vmovaps xmm3, [rsp+0x30]
0000714ce89d5e0d  vmovaps xmm4, [rsp+0x40]
0000714ce89d5e13  vmovaps xmm6, [rsp+0x50]
0000714ce89d5e19  vmovaps xmm7, [rsp+0x60]
0000714ce89d5e1f  vmovaps xmm8, [rsp+0x70]
0000714ce89d5e25  vmovaps xmm9, [rsp+0x80]
0000714ce89d5e2e  vmovaps xmm10, [rsp+0x90]
0000714ce89d5e37  vmovaps xmm11, [rsp+0xA0]
0000714ce89d5e40  vmovaps xmm12, [rsp+0xB0]
0000714ce89d5e49  vmovaps xmm13, [rsp+0xC0]
0000714ce89d5e52  vmovaps xmm14, [rsp+0xD0]
0000714ce89d5e5b  vmovaps xmm15, [rsp+0xE0]
0000714ce89d5e64  add rsp, 0xF0
0000714ce89d5e6b  pop r11
0000714ce89d5e6d  pop r10
0000714ce89d5e6f  pop r9
0000714ce89d5e71  pop r8
0000714ce89d5e73  pop rsi
0000714ce89d5e74  pop rdi
0000714ce89d5e75  pop rdx
0000714ce89d5e76  pop rcx
0000714ce89d5e77  pop rax
0000714ce89d5e78  add rsp, 0x08
0000714ce89d5e7c  jmp 0x0000714CE89D3013
0000714ce89d5e81  sub rsp, 0x08
0000714ce89d5e85  push rax
0000714ce89d5e86  push rcx
0000714ce89d5e87  push rdx
0000714ce89d5e88  push rdi
0000714ce89d5e89  push rsi
0000714ce89d5e8a  push r8
0000714ce89d5e8c  push r9
0000714ce89d5e8e  push r10
0000714ce89d5e90  push r11
0000714ce89d5e92  sub rsp, 0xF0
0000714ce89d5e99  vmovaps [rsp], xmm0
0000714ce89d5e9e  vmovaps [rsp+0x10], xmm1
0000714ce89d5ea4  vmovaps [rsp+0x20], xmm2
0000714ce89d5eaa  vmovaps [rsp+0x30], xmm3
0000714ce89d5eb0  vmovaps [rsp+0x40], xmm4
0000714ce89d5eb6  vmovaps [rsp+0x50], xmm5
0000714ce89d5ebc  vmovaps [rsp+0x60], xmm6
0000714ce89d5ec2  vmovaps [rsp+0x70], xmm7
0000714ce89d5ec8  vmovaps [rsp+0x80], xmm8
0000714ce89d5ed1  vmovaps [rsp+0x90], xmm9
0000714ce89d5eda  vmovaps [rsp+0xA0], xmm10
0000714ce89d5ee3  vmovaps [rsp+0xB0], xmm11
0000714ce89d5eec  vmovaps [rsp+0xC0], xmm12
0000714ce89d5ef5  vmovaps [rsp+0xD0], xmm14
0000714ce89d5efe  vmovaps [rsp+0xE0], xmm15
0000714ce89d5f07  sub rsp, 0x30
0000714ce89d5f0b  movaps [rsp], xmm13
0000714ce89d5f10  movaps [rsp+0x10], xmm10
0000714ce89d5f16  movaps [rsp+0x20], xmm1
0000714ce89d5f1b  lea rdi, [rsp]
0000714ce89d5f1f  mov esi, 0x00
0000714ce89d5f24  mov rax, 0x57A55D340530
0000714ce89d5f2e  call rax
0000714ce89d5f30  movaps xmm13, [rsp]
0000714ce89d5f35  add rsp, 0x30
0000714ce89d5f39  vmovaps xmm0, [rsp]
0000714ce89d5f3e  vmovaps xmm1, [rsp+0x10]
0000714ce89d5f44  vmovaps xmm2, [rsp+0x20]
0000714ce89d5f4a  vmovaps xmm3, [rsp+0x30]
0000714ce89d5f50  vmovaps xmm4, [rsp+0x40]
0000714ce89d5f56  vmovaps xmm5, [rsp+0x50]
0000714ce89d5f5c  vmovaps xmm6, [rsp+0x60]
0000714ce89d5f62  vmovaps xmm7, [rsp+0x70]
0000714ce89d5f68  vmovaps xmm8, [rsp+0x80]
0000714ce89d5f71  vmovaps xmm9, [rsp+0x90]
0000714ce89d5f7a  vmovaps xmm10, [rsp+0xA0]
0000714ce89d5f83  vmovaps xmm11, [rsp+0xB0]
0000714ce89d5f8c  vmovaps xmm12, [rsp+0xC0]
0000714ce89d5f95  vmovaps xmm14, [rsp+0xD0]
0000714ce89d5f9e  vmovaps xmm15, [rsp+0xE0]
0000714ce89d5fa7  add rsp, 0xF0
0000714ce89d5fae  pop r11
0000714ce89d5fb0  pop r10
0000714ce89d5fb2  pop r9
0000714ce89d5fb4  pop r8
0000714ce89d5fb6  pop rsi
0000714ce89d5fb7  pop rdi
0000714ce89d5fb8  pop rdx
0000714ce89d5fb9  pop rcx
0000714ce89d5fba  pop rax
0000714ce89d5fbb  add rsp, 0x08
0000714ce89d5fbf  jmp 0x0000714CE89D303C
0000714ce89d5fc4  sub rsp, 0x08
0000714ce89d5fc8  push rax
0000714ce89d5fc9  push rcx
0000714ce89d5fca  push rdx
0000714ce89d5fcb  push rdi
0000714ce89d5fcc  push rsi
0000714ce89d5fcd  push r8
0000714ce89d5fcf  push r9
0000714ce89d5fd1  push r10
0000714ce89d5fd3  push r11
0000714ce89d5fd5  sub rsp, 0xF0
0000714ce89d5fdc  vmovaps [rsp], xmm0
0000714ce89d5fe1  vmovaps [rsp+0x10], xmm2
0000714ce89d5fe7  vmovaps [rsp+0x20], xmm3
0000714ce89d5fed  vmovaps [rsp+0x30], xmm4
0000714ce89d5ff3  vmovaps [rsp+0x40], xmm5
0000714ce89d5ff9  vmovaps [rsp+0x50], xmm6
0000714ce89d5fff  vmovaps [rsp+0x60], xmm7
0000714ce89d6005  vmovaps [rsp+0x70], xmm8
0000714ce89d600b  vmovaps [rsp+0x80], xmm9
0000714ce89d6014  vmovaps [rsp+0x90], xmm10
0000714ce89d601d  vmovaps [rsp+0xA0], xmm11
0000714ce89d6026  vmovaps [rsp+0xB0], xmm12
0000714ce89d602f  vmovaps [rsp+0xC0], xmm13
0000714ce89d6038  vmovaps [rsp+0xD0], xmm14
0000714ce89d6041  vmovaps [rsp+0xE0], xmm15
0000714ce89d604a  sub rsp, 0x30
0000714ce89d604e  movaps [rsp], xmm1
0000714ce89d6052  movaps [rsp+0x10], xmm15
0000714ce89d6058  movaps [rsp+0x20], xmm10
0000714ce89d605e  lea rdi, [rsp]
0000714ce89d6062  mov esi, 0x00
0000714ce89d6067  mov rax, 0x57A55D340530
0000714ce89d6071  call rax
0000714ce89d6073  movaps xmm1, [rsp]
0000714ce89d6077  add rsp, 0x30
0000714ce89d607b  vmovaps xmm0, [rsp]
0000714ce89d6080  vmovaps xmm2, [rsp+0x10]
0000714ce89d6086  vmovaps xmm3, [rsp+0x20]
0000714ce89d608c  vmovaps xmm4, [rsp+0x30]
0000714ce89d6092  vmovaps xmm5, [rsp+0x40]
0000714ce89d6098  vmovaps xmm6, [rsp+0x50]
0000714ce89d609e  vmovaps xmm7, [rsp+0x60]
0000714ce89d60a4  vmovaps xmm8, [rsp+0x70]
0000714ce89d60aa  vmovaps xmm9, [rsp+0x80]
0000714ce89d60b3  vmovaps xmm10, [rsp+0x90]
0000714ce89d60bc  vmovaps xmm11, [rsp+0xA0]
0000714ce89d60c5  vmovaps xmm12, [rsp+0xB0]
0000714ce89d60ce  vmovaps xmm13, [rsp+0xC0]
0000714ce89d60d7  vmovaps xmm14, [rsp+0xD0]
0000714ce89d60e0  vmovaps xmm15, [rsp+0xE0]
0000714ce89d60e9  add rsp, 0xF0
0000714ce89d60f0  pop r11
0000714ce89d60f2  pop r10
0000714ce89d60f4  pop r9
0000714ce89d60f6  pop r8
0000714ce89d60f8  pop rsi
0000714ce89d60f9  pop rdi
0000714ce89d60fa  pop rdx
0000714ce89d60fb  pop rcx
0000714ce89d60fc  pop rax
0000714ce89d60fd  add rsp, 0x08
0000714ce89d6101  jmp 0x0000714CE89D305B
0000714ce89d6106  sub rsp, 0x08
0000714ce89d610a  push rax
0000714ce89d610b  push rcx
0000714ce89d610c  push rdx
0000714ce89d610d  push rdi
0000714ce89d610e  push rsi
0000714ce89d610f  push r8
0000714ce89d6111  push r9
0000714ce89d6113  push r10
0000714ce89d6115  push r11
0000714ce89d6117  sub rsp, 0xF0
0000714ce89d611e  vmovaps [rsp], xmm0
0000714ce89d6123  vmovaps [rsp+0x10], xmm1
0000714ce89d6129  vmovaps [rsp+0x20], xmm2
0000714ce89d612f  vmovaps [rsp+0x30], xmm3
0000714ce89d6135  vmovaps [rsp+0x40], xmm4
0000714ce89d613b  vmovaps [rsp+0x50], xmm5
0000714ce89d6141  vmovaps [rsp+0x60], xmm6
0000714ce89d6147  vmovaps [rsp+0x70], xmm7
0000714ce89d614d  vmovaps [rsp+0x80], xmm8
0000714ce89d6156  vmovaps [rsp+0x90], xmm9
0000714ce89d615f  vmovaps [rsp+0xA0], xmm10
0000714ce89d6168  vmovaps [rsp+0xB0], xmm11
0000714ce89d6171  vmovaps [rsp+0xC0], xmm12
0000714ce89d617a  vmovaps [rsp+0xD0], xmm13
0000714ce89d6183  vmovaps [rsp+0xE0], xmm14
0000714ce89d618c  sub rsp, 0x30
0000714ce89d6190  movaps [rsp], xmm15
0000714ce89d6195  movaps [rsp+0x10], xmm10
0000714ce89d619b  movaps [rsp+0x20], xmm11
0000714ce89d61a1  lea rdi, [rsp]
0000714ce89d61a5  mov esi, 0x00
0000714ce89d61aa  mov rax, 0x57A55D340530
0000714ce89d61b4  call rax
0000714ce89d61b6  movaps xmm15, [rsp]
0000714ce89d61bb  add rsp, 0x30
0000714ce89d61bf  vmovaps xmm0, [rsp]
0000714ce89d61c4  vmovaps xmm1, [rsp+0x10]
0000714ce89d61ca  vmovaps xmm2, [rsp+0x20]
0000714ce89d61d0  vmovaps xmm3, [rsp+0x30]
0000714ce89d61d6  vmovaps xmm4, [rsp+0x40]
0000714ce89d61dc  vmovaps xmm5, [rsp+0x50]
0000714ce89d61e2  vmovaps xmm6, [rsp+0x60]
0000714ce89d61e8  vmovaps xmm7, [rsp+0x70]
0000714ce89d61ee  vmovaps xmm8, [rsp+0x80]
0000714ce89d61f7  vmovaps xmm9, [rsp+0x90]
0000714ce89d6200  vmovaps xmm10, [rsp+0xA0]
0000714ce89d6209  vmovaps xmm11, [rsp+0xB0]
0000714ce89d6212  vmovaps xmm12, [rsp+0xC0]
0000714ce89d621b  vmovaps xmm13, [rsp+0xD0]
0000714ce89d6224  vmovaps xmm14, [rsp+0xE0]
0000714ce89d622d  add rsp, 0xF0
0000714ce89d6234  pop r11
0000714ce89d6236  pop r10
0000714ce89d6238  pop r9
0000714ce89d623a  pop r8
0000714ce89d623c  pop rsi
0000714ce89d623d  pop rdi
0000714ce89d623e  pop rdx
0000714ce89d623f  pop rcx
0000714ce89d6240  pop rax
0000714ce89d6241  add rsp, 0x08
0000714ce89d6245  jmp 0x0000714CE89D307E
0000714ce89d624a  sub rsp, 0x08
0000714ce89d624e  push rax
0000714ce89d624f  push rcx
0000714ce89d6250  push rdx
0000714ce89d6251  push rdi
0000714ce89d6252  push rsi
0000714ce89d6253  push r8
0000714ce89d6255  push r9
0000714ce89d6257  push r10
0000714ce89d6259  push r11
0000714ce89d625b  sub rsp, 0xF0
0000714ce89d6262  vmovaps [rsp], xmm0
0000714ce89d6267  vmovaps [rsp+0x10], xmm1
0000714ce89d626d  vmovaps [rsp+0x20], xmm2
0000714ce89d6273  vmovaps [rsp+0x30], xmm3
0000714ce89d6279  vmovaps [rsp+0x40], xmm4
0000714ce89d627f  vmovaps [rsp+0x50], xmm5
0000714ce89d6285  vmovaps [rsp+0x60], xmm6
0000714ce89d628b  vmovaps [rsp+0x70], xmm7
0000714ce89d6291  vmovaps [rsp+0x80], xmm8
0000714ce89d629a  vmovaps [rsp+0x90], xmm9
0000714ce89d62a3  vmovaps [rsp+0xA0], xmm11
0000714ce89d62ac  vmovaps [rsp+0xB0], xmm12
0000714ce89d62b5  vmovaps [rsp+0xC0], xmm13
0000714ce89d62be  vmovaps [rsp+0xD0], xmm14
0000714ce89d62c7  vmovaps [rsp+0xE0], xmm15
0000714ce89d62d0  sub rsp, 0x30
0000714ce89d62d4  movaps [rsp], xmm10
0000714ce89d62d9  movaps [rsp+0x10], xmm2
0000714ce89d62de  movaps [rsp+0x20], xmm11
0000714ce89d62e4  lea rdi, [rsp]
0000714ce89d62e8  mov esi, 0x00
0000714ce89d62ed  mov rax, 0x57A55D340530
0000714ce89d62f7  call rax
0000714ce89d62f9  movaps xmm10, [rsp]
0000714ce89d62fe  add rsp, 0x30
0000714ce89d6302  vmovaps xmm0, [rsp]
0000714ce89d6307  vmovaps xmm1, [rsp+0x10]
0000714ce89d630d  vmovaps xmm2, [rsp+0x20]
0000714ce89d6313  vmovaps xmm3, [rsp+0x30]
0000714ce89d6319  vmovaps xmm4, [rsp+0x40]
0000714ce89d631f  vmovaps xmm5, [rsp+0x50]
0000714ce89d6325  vmovaps xmm6, [rsp+0x60]
0000714ce89d632b  vmovaps xmm7, [rsp+0x70]
0000714ce89d6331  vmovaps xmm8, [rsp+0x80]
0000714ce89d633a  vmovaps xmm9, [rsp+0x90]
0000714ce89d6343  vmovaps xmm11, [rsp+0xA0]
0000714ce89d634c  vmovaps xmm12, [rsp+0xB0]
0000714ce89d6355  vmovaps xmm13, [rsp+0xC0]
0000714ce89d635e  vmovaps xmm14, [rsp+0xD0]
0000714ce89d6367  vmovaps xmm15, [rsp+0xE0]
0000714ce89d6370  add rsp, 0xF0
0000714ce89d6377  pop r11
0000714ce89d6379  pop r10
0000714ce89d637b  pop r9
0000714ce89d637d  pop r8
0000714ce89d637f  pop rsi
0000714ce89d6380  pop rdi
0000714ce89d6381  pop rdx
0000714ce89d6382  pop rcx
0000714ce89d6383  pop rax
0000714ce89d6384  add rsp, 0x08
0000714ce89d6388  jmp 0x0000714CE89D30B6
0000714ce89d638d  sub rsp, 0x08
0000714ce89d6391  push rax
0000714ce89d6392  push rcx
0000714ce89d6393  push rdx
0000714ce89d6394  push rdi
0000714ce89d6395  push rsi
0000714ce89d6396  push r8
0000714ce89d6398  push r9
0000714ce89d639a  push r10
0000714ce89d639c  push r11
0000714ce89d639e  sub rsp, 0xF0
0000714ce89d63a5  vmovaps [rsp], xmm0
0000714ce89d63aa  vmovaps [rsp+0x10], xmm1
0000714ce89d63b0  vmovaps [rsp+0x20], xmm2
0000714ce89d63b6  vmovaps [rsp+0x30], xmm3
0000714ce89d63bc  vmovaps [rsp+0x40], xmm4
0000714ce89d63c2  vmovaps [rsp+0x50], xmm5
0000714ce89d63c8  vmovaps [rsp+0x60], xmm6
0000714ce89d63ce  vmovaps [rsp+0x70], xmm7
0000714ce89d63d4  vmovaps [rsp+0x80], xmm8
0000714ce89d63dd  vmovaps [rsp+0x90], xmm9
0000714ce89d63e6  vmovaps [rsp+0xA0], xmm10
0000714ce89d63ef  vmovaps [rsp+0xB0], xmm12
0000714ce89d63f8  vmovaps [rsp+0xC0], xmm13
0000714ce89d6401  vmovaps [rsp+0xD0], xmm14
0000714ce89d640a  vmovaps [rsp+0xE0], xmm15
0000714ce89d6413  sub rsp, 0x30
0000714ce89d6417  movaps [rsp], xmm11
0000714ce89d641c  movaps [rsp+0x10], xmm2
0000714ce89d6421  movaps [rsp+0x20], xmm1
0000714ce89d6426  lea rdi, [rsp]
0000714ce89d642a  mov esi, 0x00
0000714ce89d642f  mov rax, 0x57A55D340530
0000714ce89d6439  call rax
0000714ce89d643b  movaps xmm11, [rsp]
0000714ce89d6440  add rsp, 0x30
0000714ce89d6444  vmovaps xmm0, [rsp]
0000714ce89d6449  vmovaps xmm1, [rsp+0x10]
0000714ce89d644f  vmovaps xmm2, [rsp+0x20]
0000714ce89d6455  vmovaps xmm3, [rsp+0x30]
0000714ce89d645b  vmovaps xmm4, [rsp+0x40]
0000714ce89d6461  vmovaps xmm5, [rsp+0x50]
0000714ce89d6467  vmovaps xmm6, [rsp+0x60]
0000714ce89d646d  vmovaps xmm7, [rsp+0x70]
0000714ce89d6473  vmovaps xmm8, [rsp+0x80]
0000714ce89d647c  vmovaps xmm9, [rsp+0x90]
0000714ce89d6485  vmovaps xmm10, [rsp+0xA0]
0000714ce89d648e  vmovaps xmm12, [rsp+0xB0]
0000714ce89d6497  vmovaps xmm13, [rsp+0xC0]
0000714ce89d64a0  vmovaps xmm14, [rsp+0xD0]
0000714ce89d64a9  vmovaps xmm15, [rsp+0xE0]
0000714ce89d64b2  add rsp, 0xF0
0000714ce89d64b9  pop r11
0000714ce89d64bb  pop r10
0000714ce89d64bd  pop r9
0000714ce89d64bf  pop r8
0000714ce89d64c1  pop rsi
0000714ce89d64c2  pop rdi
0000714ce89d64c3  pop rdx
0000714ce89d64c4  pop rcx
0000714ce89d64c5  pop rax
0000714ce89d64c6  add rsp, 0x08
0000714ce89d64ca  jmp 0x0000714CE89D30F2
0000714ce89d64cf  sub rsp, 0x08
0000714ce89d64d3  push rax
0000714ce89d64d4  push rcx
0000714ce89d64d5  push rdx
0000714ce89d64d6  push rdi
0000714ce89d64d7  push rsi
0000714ce89d64d8  push r8
0000714ce89d64da  push r9
0000714ce89d64dc  push r10
0000714ce89d64de  push r11
0000714ce89d64e0  sub rsp, 0xF0
0000714ce89d64e7  vmovaps [rsp], xmm0
0000714ce89d64ec  vmovaps [rsp+0x10], xmm2
0000714ce89d64f2  vmovaps [rsp+0x20], xmm3
0000714ce89d64f8  vmovaps [rsp+0x30], xmm4
0000714ce89d64fe  vmovaps [rsp+0x40], xmm5
0000714ce89d6504  vmovaps [rsp+0x50], xmm6
0000714ce89d650a  vmovaps [rsp+0x60], xmm7
0000714ce89d6510  vmovaps [rsp+0x70], xmm8
0000714ce89d6516  vmovaps [rsp+0x80], xmm9
0000714ce89d651f  vmovaps [rsp+0x90], xmm10
0000714ce89d6528  vmovaps [rsp+0xA0], xmm11
0000714ce89d6531  vmovaps [rsp+0xB0], xmm12
0000714ce89d653a  vmovaps [rsp+0xC0], xmm13
0000714ce89d6543  vmovaps [rsp+0xD0], xmm14
0000714ce89d654c  vmovaps [rsp+0xE0], xmm15
0000714ce89d6555  sub rsp, 0x30
0000714ce89d6559  movaps [rsp], xmm1
0000714ce89d655d  movaps [rsp+0x10], xmm14
0000714ce89d6563  movaps [rsp+0x20], xmm6
0000714ce89d6568  lea rdi, [rsp]
0000714ce89d656c  mov esi, 0x00
0000714ce89d6571  mov rax, 0x57A55D340530
0000714ce89d657b  call rax
0000714ce89d657d  movaps xmm1, [rsp]
0000714ce89d6581  add rsp, 0x30
0000714ce89d6585  vmovaps xmm0, [rsp]
0000714ce89d658a  vmovaps xmm2, [rsp+0x10]
0000714ce89d6590  vmovaps xmm3, [rsp+0x20]
0000714ce89d6596  vmovaps xmm4, [rsp+0x30]
0000714ce89d659c  vmovaps xmm5, [rsp+0x40]
0000714ce89d65a2  vmovaps xmm6, [rsp+0x50]
0000714ce89d65a8  vmovaps xmm7, [rsp+0x60]
0000714ce89d65ae  vmovaps xmm8, [rsp+0x70]
0000714ce89d65b4  vmovaps xmm9, [rsp+0x80]
0000714ce89d65bd  vmovaps xmm10, [rsp+0x90]
0000714ce89d65c6  vmovaps xmm11, [rsp+0xA0]
0000714ce89d65cf  vmovaps xmm12, [rsp+0xB0]
0000714ce89d65d8  vmovaps xmm13, [rsp+0xC0]
0000714ce89d65e1  vmovaps xmm14, [rsp+0xD0]
0000714ce89d65ea  vmovaps xmm15, [rsp+0xE0]
0000714ce89d65f3  add rsp, 0xF0
0000714ce89d65fa  pop r11
0000714ce89d65fc  pop r10
0000714ce89d65fe  pop r9
0000714ce89d6600  pop r8
0000714ce89d6602  pop rsi
0000714ce89d6603  pop rdi
0000714ce89d6604  pop rdx
0000714ce89d6605  pop rcx
0000714ce89d6606  pop rax
0000714ce89d6607  add rsp, 0x08
0000714ce89d660b  jmp 0x0000714CE89D310B
0000714ce89d6610  sub rsp, 0x08
0000714ce89d6614  push rax
0000714ce89d6615  push rcx
0000714ce89d6616  push rdx
0000714ce89d6617  push rdi
0000714ce89d6618  push rsi
0000714ce89d6619  push r8
0000714ce89d661b  push r9
0000714ce89d661d  push r10
0000714ce89d661f  push r11
0000714ce89d6621  sub rsp, 0xF0
0000714ce89d6628  vmovaps [rsp], xmm0
0000714ce89d662d  vmovaps [rsp+0x10], xmm1
0000714ce89d6633  vmovaps [rsp+0x20], xmm2
0000714ce89d6639  vmovaps [rsp+0x30], xmm3
0000714ce89d663f  vmovaps [rsp+0x40], xmm4
0000714ce89d6645  vmovaps [rsp+0x50], xmm5
0000714ce89d664b  vmovaps [rsp+0x60], xmm6
0000714ce89d6651  vmovaps [rsp+0x70], xmm7
0000714ce89d6657  vmovaps [rsp+0x80], xmm8
0000714ce89d6660  vmovaps [rsp+0x90], xmm9
0000714ce89d6669  vmovaps [rsp+0xA0], xmm10
0000714ce89d6672  vmovaps [rsp+0xB0], xmm11
0000714ce89d667b  vmovaps [rsp+0xC0], xmm12
0000714ce89d6684  vmovaps [rsp+0xD0], xmm13
0000714ce89d668d  vmovaps [rsp+0xE0], xmm14
0000714ce89d6696  sub rsp, 0x30
0000714ce89d669a  movaps [rsp], xmm15
0000714ce89d669f  movaps [rsp+0x10], xmm14
0000714ce89d66a5  movaps [rsp+0x20], xmm5
0000714ce89d66aa  lea rdi, [rsp]
0000714ce89d66ae  mov esi, 0x00
0000714ce89d66b3  mov rax, 0x57A55D340530
0000714ce89d66bd  call rax
0000714ce89d66bf  movaps xmm15, [rsp]
0000714ce89d66c4  add rsp, 0x30
0000714ce89d66c8  vmovaps xmm0, [rsp]
0000714ce89d66cd  vmovaps xmm1, [rsp+0x10]
0000714ce89d66d3  vmovaps xmm2, [rsp+0x20]
0000714ce89d66d9  vmovaps xmm3, [rsp+0x30]
0000714ce89d66df  vmovaps xmm4, [rsp+0x40]
0000714ce89d66e5  vmovaps xmm5, [rsp+0x50]
0000714ce89d66eb  vmovaps xmm6, [rsp+0x60]
0000714ce89d66f1  vmovaps xmm7, [rsp+0x70]
0000714ce89d66f7  vmovaps xmm8, [rsp+0x80]
0000714ce89d6700  vmovaps xmm9, [rsp+0x90]
0000714ce89d6709  vmovaps xmm10, [rsp+0xA0]
0000714ce89d6712  vmovaps xmm11, [rsp+0xB0]
0000714ce89d671b  vmovaps xmm12, [rsp+0xC0]
0000714ce89d6724  vmovaps xmm13, [rsp+0xD0]
0000714ce89d672d  vmovaps xmm14, [rsp+0xE0]
0000714ce89d6736  add rsp, 0xF0
0000714ce89d673d  pop r11
0000714ce89d673f  pop r10
0000714ce89d6741  pop r9
0000714ce89d6743  pop r8
0000714ce89d6745  pop rsi
0000714ce89d6746  pop rdi
0000714ce89d6747  pop rdx
0000714ce89d6748  pop rcx
0000714ce89d6749  pop rax
0000714ce89d674a  add rsp, 0x08
0000714ce89d674e  jmp 0x0000714CE89D312B
0000714ce89d6753  sub rsp, 0x08
0000714ce89d6757  push rax
0000714ce89d6758  push rcx
0000714ce89d6759  push rdx
0000714ce89d675a  push rdi
0000714ce89d675b  push rsi
0000714ce89d675c  push r8
0000714ce89d675e  push r9
0000714ce89d6760  push r10
0000714ce89d6762  push r11
0000714ce89d6764  sub rsp, 0xF0
0000714ce89d676b  vmovaps [rsp], xmm0
0000714ce89d6770  vmovaps [rsp+0x10], xmm1
0000714ce89d6776  vmovaps [rsp+0x20], xmm2
0000714ce89d677c  vmovaps [rsp+0x30], xmm3
0000714ce89d6782  vmovaps [rsp+0x40], xmm4
0000714ce89d6788  vmovaps [rsp+0x50], xmm5
0000714ce89d678e  vmovaps [rsp+0x60], xmm7
0000714ce89d6794  vmovaps [rsp+0x70], xmm8
0000714ce89d679a  vmovaps [rsp+0x80], xmm9
0000714ce89d67a3  vmovaps [rsp+0x90], xmm10
0000714ce89d67ac  vmovaps [rsp+0xA0], xmm11
0000714ce89d67b5  vmovaps [rsp+0xB0], xmm12
0000714ce89d67be  vmovaps [rsp+0xC0], xmm13
0000714ce89d67c7  vmovaps [rsp+0xD0], xmm14
0000714ce89d67d0  vmovaps [rsp+0xE0], xmm15
0000714ce89d67d9  sub rsp, 0x30
0000714ce89d67dd  movaps [rsp], xmm6
0000714ce89d67e1  movaps [rsp+0x10], xmm9
0000714ce89d67e7  movaps [rsp+0x20], xmm14
0000714ce89d67ed  lea rdi, [rsp]
0000714ce89d67f1  mov esi, 0x00
0000714ce89d67f6  mov rax, 0x57A55D340530
0000714ce89d6800  call rax
0000714ce89d6802  movaps xmm6, [rsp]
0000714ce89d6806  add rsp, 0x30
0000714ce89d680a  vmovaps xmm0, [rsp]
0000714ce89d680f  vmovaps xmm1, [rsp+0x10]
0000714ce89d6815  vmovaps xmm2, [rsp+0x20]
0000714ce89d681b  vmovaps xmm3, [rsp+0x30]
0000714ce89d6821  vmovaps xmm4, [rsp+0x40]
0000714ce89d6827  vmovaps xmm5, [rsp+0x50]
0000714ce89d682d  vmovaps xmm7, [rsp+0x60]
0000714ce89d6833  vmovaps xmm8, [rsp+0x70]
0000714ce89d6839  vmovaps xmm9, [rsp+0x80]
0000714ce89d6842  vmovaps xmm10, [rsp+0x90]
0000714ce89d684b  vmovaps xmm11, [rsp+0xA0]
0000714ce89d6854  vmovaps xmm12, [rsp+0xB0]
0000714ce89d685d  vmovaps xmm13, [rsp+0xC0]
0000714ce89d6866  vmovaps xmm14, [rsp+0xD0]
0000714ce89d686f  vmovaps xmm15, [rsp+0xE0]
0000714ce89d6878  add rsp, 0xF0
0000714ce89d687f  pop r11
0000714ce89d6881  pop r10
0000714ce89d6883  pop r9
0000714ce89d6885  pop r8
0000714ce89d6887  pop rsi
0000714ce89d6888  pop rdi
0000714ce89d6889  pop rdx
0000714ce89d688a  pop rcx
0000714ce89d688b  pop rax
0000714ce89d688c  add rsp, 0x08
0000714ce89d6890  jmp 0x0000714CE89D3153
0000714ce89d6895  sub rsp, 0x08
0000714ce89d6899  push rax
0000714ce89d689a  push rcx
0000714ce89d689b  push rdx
0000714ce89d689c  push rdi
0000714ce89d689d  push rsi
0000714ce89d689e  push r8
0000714ce89d68a0  push r9
0000714ce89d68a2  push r10
0000714ce89d68a4  push r11
0000714ce89d68a6  sub rsp, 0xF0
0000714ce89d68ad  vmovaps [rsp], xmm0
0000714ce89d68b2  vmovaps [rsp+0x10], xmm1
0000714ce89d68b8  vmovaps [rsp+0x20], xmm2
0000714ce89d68be  vmovaps [rsp+0x30], xmm3
0000714ce89d68c4  vmovaps [rsp+0x40], xmm4
0000714ce89d68ca  vmovaps [rsp+0x50], xmm5
0000714ce89d68d0  vmovaps [rsp+0x60], xmm6
0000714ce89d68d6  vmovaps [rsp+0x70], xmm7
0000714ce89d68dc  vmovaps [rsp+0x80], xmm8
0000714ce89d68e5  vmovaps [rsp+0x90], xmm9
0000714ce89d68ee  vmovaps [rsp+0xA0], xmm10
0000714ce89d68f7  vmovaps [rsp+0xB0], xmm11
0000714ce89d6900  vmovaps [rsp+0xC0], xmm12
0000714ce89d6909  vmovaps [rsp+0xD0], xmm13
0000714ce89d6912  vmovaps [rsp+0xE0], xmm15
0000714ce89d691b  sub rsp, 0x30
0000714ce89d691f  movaps [rsp], xmm14
0000714ce89d6924  movaps [rsp+0x10], xmm9
0000714ce89d692a  movaps [rsp+0x20], xmm13
0000714ce89d6930  lea rdi, [rsp]
0000714ce89d6934  mov esi, 0x00
0000714ce89d6939  mov rax, 0x57A55D340530
0000714ce89d6943  call rax
0000714ce89d6945  movaps xmm14, [rsp]
0000714ce89d694a  add rsp, 0x30
0000714ce89d694e  vmovaps xmm0, [rsp]
0000714ce89d6953  vmovaps xmm1, [rsp+0x10]
0000714ce89d6959  vmovaps xmm2, [rsp+0x20]
0000714ce89d695f  vmovaps xmm3, [rsp+0x30]
0000714ce89d6965  vmovaps xmm4, [rsp+0x40]
0000714ce89d696b  vmovaps xmm5, [rsp+0x50]
0000714ce89d6971  vmovaps xmm6, [rsp+0x60]
0000714ce89d6977  vmovaps xmm7, [rsp+0x70]
0000714ce89d697d  vmovaps xmm8, [rsp+0x80]
0000714ce89d6986  vmovaps xmm9, [rsp+0x90]
0000714ce89d698f  vmovaps xmm10, [rsp+0xA0]
0000714ce89d6998  vmovaps xmm11, [rsp+0xB0]
0000714ce89d69a1  vmovaps xmm12, [rsp+0xC0]
0000714ce89d69aa  vmovaps xmm13, [rsp+0xD0]
0000714ce89d69b3  vmovaps xmm15, [rsp+0xE0]
0000714ce89d69bc  add rsp, 0xF0
0000714ce89d69c3  pop r11
0000714ce89d69c5  pop r10
0000714ce89d69c7  pop r9
0000714ce89d69c9  pop r8
0000714ce89d69cb  pop rsi
0000714ce89d69cc  pop rdi
0000714ce89d69cd  pop rdx
0000714ce89d69ce  pop rcx
0000714ce89d69cf  pop rax
0000714ce89d69d0  add rsp, 0x08
0000714ce89d69d4  jmp 0x0000714CE89D3176
0000714ce89d69d9  sub rsp, 0x08
0000714ce89d69dd  push rax
0000714ce89d69de  push rcx
0000714ce89d69df  push rdx
0000714ce89d69e0  push rdi
0000714ce89d69e1  push rsi
0000714ce89d69e2  push r8
0000714ce89d69e4  push r9
0000714ce89d69e6  push r10
0000714ce89d69e8  push r11
0000714ce89d69ea  sub rsp, 0xF0
0000714ce89d69f1  vmovaps [rsp], xmm0
0000714ce89d69f6  vmovaps [rsp+0x10], xmm1
0000714ce89d69fc  vmovaps [rsp+0x20], xmm2
0000714ce89d6a02  vmovaps [rsp+0x30], xmm3
0000714ce89d6a08  vmovaps [rsp+0x40], xmm4
0000714ce89d6a0e  vmovaps [rsp+0x50], xmm5
0000714ce89d6a14  vmovaps [rsp+0x60], xmm6
0000714ce89d6a1a  vmovaps [rsp+0x70], xmm7
0000714ce89d6a20  vmovaps [rsp+0x80], xmm8
0000714ce89d6a29  vmovaps [rsp+0x90], xmm9
0000714ce89d6a32  vmovaps [rsp+0xA0], xmm10
0000714ce89d6a3b  vmovaps [rsp+0xB0], xmm11
0000714ce89d6a44  vmovaps [rsp+0xC0], xmm12
0000714ce89d6a4d  vmovaps [rsp+0xD0], xmm14
0000714ce89d6a56  vmovaps [rsp+0xE0], xmm15
0000714ce89d6a5f  sub rsp, 0x30
0000714ce89d6a63  movaps [rsp], xmm13
0000714ce89d6a68  movaps [rsp+0x10], xmm9
0000714ce89d6a6e  movaps [rsp+0x20], xmm10
0000714ce89d6a74  lea rdi, [rsp]
0000714ce89d6a78  mov esi, 0x00
0000714ce89d6a7d  mov rax, 0x57A55D340530
0000714ce89d6a87  call rax
0000714ce89d6a89  movaps xmm13, [rsp]
0000714ce89d6a8e  add rsp, 0x30
0000714ce89d6a92  vmovaps xmm0, [rsp]
0000714ce89d6a97  vmovaps xmm1, [rsp+0x10]
0000714ce89d6a9d  vmovaps xmm2, [rsp+0x20]
0000714ce89d6aa3  vmovaps xmm3, [rsp+0x30]
0000714ce89d6aa9  vmovaps xmm4, [rsp+0x40]
0000714ce89d6aaf  vmovaps xmm5, [rsp+0x50]
0000714ce89d6ab5  vmovaps xmm6, [rsp+0x60]
0000714ce89d6abb  vmovaps xmm7, [rsp+0x70]
0000714ce89d6ac1  vmovaps xmm8, [rsp+0x80]
0000714ce89d6aca  vmovaps xmm9, [rsp+0x90]
0000714ce89d6ad3  vmovaps xmm10, [rsp+0xA0]
0000714ce89d6adc  vmovaps xmm11, [rsp+0xB0]
0000714ce89d6ae5  vmovaps xmm12, [rsp+0xC0]
0000714ce89d6aee  vmovaps xmm14, [rsp+0xD0]
0000714ce89d6af7  vmovaps xmm15, [rsp+0xE0]
0000714ce89d6b00  add rsp, 0xF0
0000714ce89d6b07  pop r11
0000714ce89d6b09  pop r10
0000714ce89d6b0b  pop r9
0000714ce89d6b0d  pop r8
0000714ce89d6b0f  pop rsi
0000714ce89d6b10  pop rdi
0000714ce89d6b11  pop rdx
0000714ce89d6b12  pop rcx
0000714ce89d6b13  pop rax
0000714ce89d6b14  add rsp, 0x08
0000714ce89d6b18  jmp 0x0000714CE89D3196
0000714ce89d6b1d  call 0x0000714CE880AFE0
0000714ce89d6b22  jmp 0x0000714CE89D31EB
0000714ce89d6b27  sub rsp, 0x08
0000714ce89d6b2b  push rax
0000714ce89d6b2c  push rcx
0000714ce89d6b2d  push rdx
0000714ce89d6b2e  push rdi
0000714ce89d6b2f  push rsi
0000714ce89d6b30  push r8
0000714ce89d6b32  push r9
0000714ce89d6b34  push r10
0000714ce89d6b36  push r11
0000714ce89d6b38  sub rsp, 0xF0
0000714ce89d6b3f  vmovaps [rsp], xmm0
0000714ce89d6b44  vmovaps [rsp+0x10], xmm1
0000714ce89d6b4a  vmovaps [rsp+0x20], xmm2
0000714ce89d6b50  vmovaps [rsp+0x30], xmm3
0000714ce89d6b56  vmovaps [rsp+0x40], xmm4
0000714ce89d6b5c  vmovaps [rsp+0x50], xmm5
0000714ce89d6b62  vmovaps [rsp+0x60], xmm6
0000714ce89d6b68  vmovaps [rsp+0x70], xmm7
0000714ce89d6b6e  vmovaps [rsp+0x80], xmm8
0000714ce89d6b77  vmovaps [rsp+0x90], xmm10
0000714ce89d6b80  vmovaps [rsp+0xA0], xmm11
0000714ce89d6b89  vmovaps [rsp+0xB0], xmm12
0000714ce89d6b92  vmovaps [rsp+0xC0], xmm13
0000714ce89d6b9b  vmovaps [rsp+0xD0], xmm14
0000714ce89d6ba4  vmovaps [rsp+0xE0], xmm15
0000714ce89d6bad  sub rsp, 0x30
0000714ce89d6bb1  movaps [rsp], xmm9
0000714ce89d6bb6  movaps [rsp+0x10], xmm8
0000714ce89d6bbc  movaps [rsp+0x20], xmm10
0000714ce89d6bc2  lea rdi, [rsp]
0000714ce89d6bc6  mov esi, 0x00
0000714ce89d6bcb  mov rax, 0x57A55D340530
0000714ce89d6bd5  call rax
0000714ce89d6bd7  movaps xmm9, [rsp]
0000714ce89d6bdc  add rsp, 0x30
0000714ce89d6be0  vmovaps xmm0, [rsp]
0000714ce89d6be5  vmovaps xmm1, [rsp+0x10]
0000714ce89d6beb  vmovaps xmm2, [rsp+0x20]
0000714ce89d6bf1  vmovaps xmm3, [rsp+0x30]
0000714ce89d6bf7  vmovaps xmm4, [rsp+0x40]
0000714ce89d6bfd  vmovaps xmm5, [rsp+0x50]
0000714ce89d6c03  vmovaps xmm6, [rsp+0x60]
0000714ce89d6c09  vmovaps xmm7, [rsp+0x70]
0000714ce89d6c0f  vmovaps xmm8, [rsp+0x80]
0000714ce89d6c18  vmovaps xmm10, [rsp+0x90]
0000714ce89d6c21  vmovaps xmm11, [rsp+0xA0]
0000714ce89d6c2a  vmovaps xmm12, [rsp+0xB0]
0000714ce89d6c33  vmovaps xmm13, [rsp+0xC0]
0000714ce89d6c3c  vmovaps xmm14, [rsp+0xD0]
0000714ce89d6c45  vmovaps xmm15, [rsp+0xE0]
0000714ce89d6c4e  add rsp, 0xF0
0000714ce89d6c55  pop r11
0000714ce89d6c57  pop r10
0000714ce89d6c59  pop r9
0000714ce89d6c5b  pop r8
0000714ce89d6c5d  pop rsi
0000714ce89d6c5e  pop rdi
0000714ce89d6c5f  pop rdx
0000714ce89d6c60  pop rcx
0000714ce89d6c61  pop rax
0000714ce89d6c62  add rsp, 0x08
0000714ce89d6c66  jmp 0x0000714CE89D321C
0000714ce89d6c6b  sub rsp, 0x08
0000714ce89d6c6f  push rax
0000714ce89d6c70  push rcx
0000714ce89d6c71  push rdx
0000714ce89d6c72  push rdi
0000714ce89d6c73  push rsi
0000714ce89d6c74  push r8
0000714ce89d6c76  push r9
0000714ce89d6c78  push r10
0000714ce89d6c7a  push r11
0000714ce89d6c7c  sub rsp, 0xF0
0000714ce89d6c83  vmovaps [rsp], xmm0
0000714ce89d6c88  vmovaps [rsp+0x10], xmm1
0000714ce89d6c8e  vmovaps [rsp+0x20], xmm2
0000714ce89d6c94  vmovaps [rsp+0x30], xmm3
0000714ce89d6c9a  vmovaps [rsp+0x40], xmm4
0000714ce89d6ca0  vmovaps [rsp+0x50], xmm5
0000714ce89d6ca6  vmovaps [rsp+0x60], xmm6
0000714ce89d6cac  vmovaps [rsp+0x70], xmm7
0000714ce89d6cb2  vmovaps [rsp+0x80], xmm8
0000714ce89d6cbb  vmovaps [rsp+0x90], xmm9
0000714ce89d6cc4  vmovaps [rsp+0xA0], xmm11
0000714ce89d6ccd  vmovaps [rsp+0xB0], xmm12
0000714ce89d6cd6  vmovaps [rsp+0xC0], xmm13
0000714ce89d6cdf  vmovaps [rsp+0xD0], xmm14
0000714ce89d6ce8  vmovaps [rsp+0xE0], xmm15
0000714ce89d6cf1  sub rsp, 0x30
0000714ce89d6cf5  movaps [rsp], xmm10
0000714ce89d6cfa  movaps [rsp+0x10], xmm1
0000714ce89d6cff  movaps [rsp+0x20], xmm11
0000714ce89d6d05  lea rdi, [rsp]
0000714ce89d6d09  mov esi, 0x00
0000714ce89d6d0e  mov rax, 0x57A55D340530
0000714ce89d6d18  call rax
0000714ce89d6d1a  movaps xmm10, [rsp]
0000714ce89d6d1f  add rsp, 0x30
0000714ce89d6d23  vmovaps xmm0, [rsp]
0000714ce89d6d28  vmovaps xmm1, [rsp+0x10]
0000714ce89d6d2e  vmovaps xmm2, [rsp+0x20]
0000714ce89d6d34  vmovaps xmm3, [rsp+0x30]
0000714ce89d6d3a  vmovaps xmm4, [rsp+0x40]
0000714ce89d6d40  vmovaps xmm5, [rsp+0x50]
0000714ce89d6d46  vmovaps xmm6, [rsp+0x60]
0000714ce89d6d4c  vmovaps xmm7, [rsp+0x70]
0000714ce89d6d52  vmovaps xmm8, [rsp+0x80]
0000714ce89d6d5b  vmovaps xmm9, [rsp+0x90]
0000714ce89d6d64  vmovaps xmm11, [rsp+0xA0]
0000714ce89d6d6d  vmovaps xmm12, [rsp+0xB0]
0000714ce89d6d76  vmovaps xmm13, [rsp+0xC0]
0000714ce89d6d7f  vmovaps xmm14, [rsp+0xD0]
0000714ce89d6d88  vmovaps xmm15, [rsp+0xE0]
0000714ce89d6d91  add rsp, 0xF0
0000714ce89d6d98  pop r11
0000714ce89d6d9a  pop r10
0000714ce89d6d9c  pop r9
0000714ce89d6d9e  pop r8
0000714ce89d6da0  pop rsi
0000714ce89d6da1  pop rdi
0000714ce89d6da2  pop rdx
0000714ce89d6da3  pop rcx
0000714ce89d6da4  pop rax
0000714ce89d6da5  add rsp, 0x08
0000714ce89d6da9  jmp 0x0000714CE89D3237
0000714ce89d6dae  sub rsp, 0x08
0000714ce89d6db2  push rax
0000714ce89d6db3  push rcx
0000714ce89d6db4  push rdx
0000714ce89d6db5  push rdi
0000714ce89d6db6  push rsi
0000714ce89d6db7  push r8
0000714ce89d6db9  push r9
0000714ce89d6dbb  push r10
0000714ce89d6dbd  push r11
0000714ce89d6dbf  sub rsp, 0xF0
0000714ce89d6dc6  vmovaps [rsp], xmm0
0000714ce89d6dcb  vmovaps [rsp+0x10], xmm2
0000714ce89d6dd1  vmovaps [rsp+0x20], xmm3
0000714ce89d6dd7  vmovaps [rsp+0x30], xmm4
0000714ce89d6ddd  vmovaps [rsp+0x40], xmm5
0000714ce89d6de3  vmovaps [rsp+0x50], xmm6
0000714ce89d6de9  vmovaps [rsp+0x60], xmm7
0000714ce89d6def  vmovaps [rsp+0x70], xmm8
0000714ce89d6df5  vmovaps [rsp+0x80], xmm9
0000714ce89d6dfe  vmovaps [rsp+0x90], xmm10
0000714ce89d6e07  vmovaps [rsp+0xA0], xmm11
0000714ce89d6e10  vmovaps [rsp+0xB0], xmm12
0000714ce89d6e19  vmovaps [rsp+0xC0], xmm13
0000714ce89d6e22  vmovaps [rsp+0xD0], xmm14
0000714ce89d6e2b  vmovaps [rsp+0xE0], xmm15
0000714ce89d6e34  sub rsp, 0x30
0000714ce89d6e38  movaps [rsp], xmm1
0000714ce89d6e3c  movaps [rsp+0x10], xmm15
0000714ce89d6e42  movaps [rsp+0x20], xmm6
0000714ce89d6e47  lea rdi, [rsp]
0000714ce89d6e4b  mov esi, 0x00
0000714ce89d6e50  mov rax, 0x57A55D340530
0000714ce89d6e5a  call rax
0000714ce89d6e5c  movaps xmm1, [rsp]
0000714ce89d6e60  add rsp, 0x30
0000714ce89d6e64  vmovaps xmm0, [rsp]
0000714ce89d6e69  vmovaps xmm2, [rsp+0x10]
0000714ce89d6e6f  vmovaps xmm3, [rsp+0x20]
0000714ce89d6e75  vmovaps xmm4, [rsp+0x30]
0000714ce89d6e7b  vmovaps xmm5, [rsp+0x40]
0000714ce89d6e81  vmovaps xmm6, [rsp+0x50]
0000714ce89d6e87  vmovaps xmm7, [rsp+0x60]
0000714ce89d6e8d  vmovaps xmm8, [rsp+0x70]
0000714ce89d6e93  vmovaps xmm9, [rsp+0x80]
0000714ce89d6e9c  vmovaps xmm10, [rsp+0x90]
0000714ce89d6ea5  vmovaps xmm11, [rsp+0xA0]
0000714ce89d6eae  vmovaps xmm12, [rsp+0xB0]
0000714ce89d6eb7  vmovaps xmm13, [rsp+0xC0]
0000714ce89d6ec0  vmovaps xmm14, [rsp+0xD0]
0000714ce89d6ec9  vmovaps xmm15, [rsp+0xE0]
0000714ce89d6ed2  add rsp, 0xF0
0000714ce89d6ed9  pop r11
0000714ce89d6edb  pop r10
0000714ce89d6edd  pop r9
0000714ce89d6edf  pop r8
0000714ce89d6ee1  pop rsi
0000714ce89d6ee2  pop rdi
0000714ce89d6ee3  pop rdx
0000714ce89d6ee4  pop rcx
0000714ce89d6ee5  pop rax
0000714ce89d6ee6  add rsp, 0x08
0000714ce89d6eea  jmp 0x0000714CE89D3250
0000714ce89d6eef  sub rsp, 0x08
0000714ce89d6ef3  push rax
0000714ce89d6ef4  push rcx
0000714ce89d6ef5  push rdx
0000714ce89d6ef6  push rdi
0000714ce89d6ef7  push rsi
0000714ce89d6ef8  push r8
0000714ce89d6efa  push r9
0000714ce89d6efc  push r10
0000714ce89d6efe  push r11
0000714ce89d6f00  sub rsp, 0xF0
0000714ce89d6f07  vmovaps [rsp], xmm0
0000714ce89d6f0c  vmovaps [rsp+0x10], xmm1
0000714ce89d6f12  vmovaps [rsp+0x20], xmm2
0000714ce89d6f18  vmovaps [rsp+0x30], xmm3
0000714ce89d6f1e  vmovaps [rsp+0x40], xmm4
0000714ce89d6f24  vmovaps [rsp+0x50], xmm5
0000714ce89d6f2a  vmovaps [rsp+0x60], xmm6
0000714ce89d6f30  vmovaps [rsp+0x70], xmm7
0000714ce89d6f36  vmovaps [rsp+0x80], xmm8
0000714ce89d6f3f  vmovaps [rsp+0x90], xmm9
0000714ce89d6f48  vmovaps [rsp+0xA0], xmm10
0000714ce89d6f51  vmovaps [rsp+0xB0], xmm12
0000714ce89d6f5a  vmovaps [rsp+0xC0], xmm13
0000714ce89d6f63  vmovaps [rsp+0xD0], xmm14
0000714ce89d6f6c  vmovaps [rsp+0xE0], xmm15
0000714ce89d6f75  sub rsp, 0x30
0000714ce89d6f79  movaps [rsp], xmm11
0000714ce89d6f7e  movaps [rsp+0x10], xmm12
0000714ce89d6f84  movaps [rsp+0x20], xmm15
0000714ce89d6f8a  lea rdi, [rsp]
0000714ce89d6f8e  mov esi, 0x00
0000714ce89d6f93  mov rax, 0x57A55D340530
0000714ce89d6f9d  call rax
0000714ce89d6f9f  movaps xmm11, [rsp]
0000714ce89d6fa4  add rsp, 0x30
0000714ce89d6fa8  vmovaps xmm0, [rsp]
0000714ce89d6fad  vmovaps xmm1, [rsp+0x10]
0000714ce89d6fb3  vmovaps xmm2, [rsp+0x20]
0000714ce89d6fb9  vmovaps xmm3, [rsp+0x30]
0000714ce89d6fbf  vmovaps xmm4, [rsp+0x40]
0000714ce89d6fc5  vmovaps xmm5, [rsp+0x50]
0000714ce89d6fcb  vmovaps xmm6, [rsp+0x60]
0000714ce89d6fd1  vmovaps xmm7, [rsp+0x70]
0000714ce89d6fd7  vmovaps xmm8, [rsp+0x80]
0000714ce89d6fe0  vmovaps xmm9, [rsp+0x90]
0000714ce89d6fe9  vmovaps xmm10, [rsp+0xA0]
0000714ce89d6ff2  vmovaps xmm12, [rsp+0xB0]
0000714ce89d6ffb  vmovaps xmm13, [rsp+0xC0]
0000714ce89d7004  vmovaps xmm14, [rsp+0xD0]
0000714ce89d700d  vmovaps xmm15, [rsp+0xE0]
0000714ce89d7016  add rsp, 0xF0
0000714ce89d701d  pop r11
0000714ce89d701f  pop r10
0000714ce89d7021  pop r9
0000714ce89d7023  pop r8
0000714ce89d7025  pop rsi
0000714ce89d7026  pop rdi
0000714ce89d7027  pop rdx
0000714ce89d7028  pop rcx
0000714ce89d7029  pop rax
0000714ce89d702a  add rsp, 0x08
0000714ce89d702e  jmp 0x0000714CE89D327A
0000714ce89d7033  sub rsp, 0x08
0000714ce89d7037  push rax
0000714ce89d7038  push rcx
0000714ce89d7039  push rdx
0000714ce89d703a  push rdi
0000714ce89d703b  push rsi
0000714ce89d703c  push r8
0000714ce89d703e  push r9
0000714ce89d7040  push r10
0000714ce89d7042  push r11
0000714ce89d7044  sub rsp, 0xF0
0000714ce89d704b  vmovaps [rsp], xmm0
0000714ce89d7050  vmovaps [rsp+0x10], xmm1
0000714ce89d7056  vmovaps [rsp+0x20], xmm2
0000714ce89d705c  vmovaps [rsp+0x30], xmm3
0000714ce89d7062  vmovaps [rsp+0x40], xmm4
0000714ce89d7068  vmovaps [rsp+0x50], xmm5
0000714ce89d706e  vmovaps [rsp+0x60], xmm6
0000714ce89d7074  vmovaps [rsp+0x70], xmm7
0000714ce89d707a  vmovaps [rsp+0x80], xmm8
0000714ce89d7083  vmovaps [rsp+0x90], xmm9
0000714ce89d708c  vmovaps [rsp+0xA0], xmm10
0000714ce89d7095  vmovaps [rsp+0xB0], xmm11
0000714ce89d709e  vmovaps [rsp+0xC0], xmm13
0000714ce89d70a7  vmovaps [rsp+0xD0], xmm14
0000714ce89d70b0  vmovaps [rsp+0xE0], xmm15
0000714ce89d70b9  sub rsp, 0x30
0000714ce89d70bd  movaps [rsp], xmm12
0000714ce89d70c2  movaps [rsp+0x10], xmm8
0000714ce89d70c8  movaps [rsp+0x20], xmm15
0000714ce89d70ce  lea rdi, [rsp]
0000714ce89d70d2  mov esi, 0x00
0000714ce89d70d7  mov rax, 0x57A55D340530
0000714ce89d70e1  call rax
0000714ce89d70e3  movaps xmm12, [rsp]
0000714ce89d70e8  add rsp, 0x30
0000714ce89d70ec  vmovaps xmm0, [rsp]
0000714ce89d70f1  vmovaps xmm1, [rsp+0x10]
0000714ce89d70f7  vmovaps xmm2, [rsp+0x20]
0000714ce89d70fd  vmovaps xmm3, [rsp+0x30]
0000714ce89d7103  vmovaps xmm4, [rsp+0x40]
0000714ce89d7109  vmovaps xmm5, [rsp+0x50]
0000714ce89d710f  vmovaps xmm6, [rsp+0x60]
0000714ce89d7115  vmovaps xmm7, [rsp+0x70]
0000714ce89d711b  vmovaps xmm8, [rsp+0x80]
0000714ce89d7124  vmovaps xmm9, [rsp+0x90]
0000714ce89d712d  vmovaps xmm10, [rsp+0xA0]
0000714ce89d7136  vmovaps xmm11, [rsp+0xB0]
0000714ce89d713f  vmovaps xmm13, [rsp+0xC0]
0000714ce89d7148  vmovaps xmm14, [rsp+0xD0]
0000714ce89d7151  vmovaps xmm15, [rsp+0xE0]
0000714ce89d715a  add rsp, 0xF0
0000714ce89d7161  pop r11
0000714ce89d7163  pop r10
0000714ce89d7165  pop r9
0000714ce89d7167  pop r8
0000714ce89d7169  pop rsi
0000714ce89d716a  pop rdi
0000714ce89d716b  pop rdx
0000714ce89d716c  pop rcx
0000714ce89d716d  pop rax
0000714ce89d716e  add rsp, 0x08
0000714ce89d7172  jmp 0x0000714CE89D32A9
0000714ce89d7177  sub rsp, 0x08
0000714ce89d717b  push rax
0000714ce89d717c  push rcx
0000714ce89d717d  push rdx
0000714ce89d717e  push rdi
0000714ce89d717f  push rsi
0000714ce89d7180  push r8
0000714ce89d7182  push r9
0000714ce89d7184  push r10
0000714ce89d7186  push r11
0000714ce89d7188  sub rsp, 0xF0
0000714ce89d718f  vmovaps [rsp], xmm0
0000714ce89d7194  vmovaps [rsp+0x10], xmm1
0000714ce89d719a  vmovaps [rsp+0x20], xmm2
0000714ce89d71a0  vmovaps [rsp+0x30], xmm3
0000714ce89d71a6  vmovaps [rsp+0x40], xmm4
0000714ce89d71ac  vmovaps [rsp+0x50], xmm5
0000714ce89d71b2  vmovaps [rsp+0x60], xmm6
0000714ce89d71b8  vmovaps [rsp+0x70], xmm7
0000714ce89d71be  vmovaps [rsp+0x80], xmm9
0000714ce89d71c7  vmovaps [rsp+0x90], xmm10
0000714ce89d71d0  vmovaps [rsp+0xA0], xmm11
0000714ce89d71d9  vmovaps [rsp+0xB0], xmm12
0000714ce89d71e2  vmovaps [rsp+0xC0], xmm13
0000714ce89d71eb  vmovaps [rsp+0xD0], xmm14
0000714ce89d71f4  vmovaps [rsp+0xE0], xmm15
0000714ce89d71fd  sub rsp, 0x30
0000714ce89d7201  movaps [rsp], xmm8
0000714ce89d7206  movaps [rsp+0x10], xmm7
0000714ce89d720b  movaps [rsp+0x20], xmm15
0000714ce89d7211  lea rdi, [rsp]
0000714ce89d7215  mov esi, 0x00
0000714ce89d721a  mov rax, 0x57A55D340530
0000714ce89d7224  call rax
0000714ce89d7226  movaps xmm8, [rsp]
0000714ce89d722b  add rsp, 0x30
0000714ce89d722f  vmovaps xmm0, [rsp]
0000714ce89d7234  vmovaps xmm1, [rsp+0x10]
0000714ce89d723a  vmovaps xmm2, [rsp+0x20]
0000714ce89d7240  vmovaps xmm3, [rsp+0x30]
0000714ce89d7246  vmovaps xmm4, [rsp+0x40]
0000714ce89d724c  vmovaps xmm5, [rsp+0x50]
0000714ce89d7252  vmovaps xmm6, [rsp+0x60]
0000714ce89d7258  vmovaps xmm7, [rsp+0x70]
0000714ce89d725e  vmovaps xmm9, [rsp+0x80]
0000714ce89d7267  vmovaps xmm10, [rsp+0x90]
0000714ce89d7270  vmovaps xmm11, [rsp+0xA0]
0000714ce89d7279  vmovaps xmm12, [rsp+0xB0]
0000714ce89d7282  vmovaps xmm13, [rsp+0xC0]
0000714ce89d728b  vmovaps xmm14, [rsp+0xD0]
0000714ce89d7294  vmovaps xmm15, [rsp+0xE0]
0000714ce89d729d  add rsp, 0xF0
0000714ce89d72a4  pop r11
0000714ce89d72a6  pop r10
0000714ce89d72a8  pop r9
0000714ce89d72aa  pop r8
0000714ce89d72ac  pop rsi
0000714ce89d72ad  pop rdi
0000714ce89d72ae  pop rdx
0000714ce89d72af  pop rcx
0000714ce89d72b0  pop rax
0000714ce89d72b1  add rsp, 0x08
0000714ce89d72b5  jmp 0x0000714CE89D32CF
0000714ce89d72ba  sub rsp, 0x08
0000714ce89d72be  push rax
0000714ce89d72bf  push rcx
0000714ce89d72c0  push rdx
0000714ce89d72c1  push rdi
0000714ce89d72c2  push rsi
0000714ce89d72c3  push r8
0000714ce89d72c5  push r9
0000714ce89d72c7  push r10
0000714ce89d72c9  push r11
0000714ce89d72cb  sub rsp, 0xF0
0000714ce89d72d2  vmovaps [rsp], xmm0
0000714ce89d72d7  vmovaps [rsp+0x10], xmm1
0000714ce89d72dd  vmovaps [rsp+0x20], xmm2
0000714ce89d72e3  vmovaps [rsp+0x30], xmm3
0000714ce89d72e9  vmovaps [rsp+0x40], xmm4
0000714ce89d72ef  vmovaps [rsp+0x50], xmm5
0000714ce89d72f5  vmovaps [rsp+0x60], xmm6
0000714ce89d72fb  vmovaps [rsp+0x70], xmm7
0000714ce89d7301  vmovaps [rsp+0x80], xmm8
0000714ce89d730a  vmovaps [rsp+0x90], xmm9
0000714ce89d7313  vmovaps [rsp+0xA0], xmm10
0000714ce89d731c  vmovaps [rsp+0xB0], xmm11
0000714ce89d7325  vmovaps [rsp+0xC0], xmm12
0000714ce89d732e  vmovaps [rsp+0xD0], xmm13
0000714ce89d7337  vmovaps [rsp+0xE0], xmm14
0000714ce89d7340  sub rsp, 0x30
0000714ce89d7344  movaps [rsp], xmm15
0000714ce89d7349  movaps [rsp+0x10], xmm14
0000714ce89d734f  movaps [rsp+0x20], xmm9
0000714ce89d7355  lea rdi, [rsp]
0000714ce89d7359  mov esi, 0x00
0000714ce89d735e  mov rax, 0x57A55D340530
0000714ce89d7368  call rax
0000714ce89d736a  movaps xmm15, [rsp]
0000714ce89d736f  add rsp, 0x30
0000714ce89d7373  vmovaps xmm0, [rsp]
0000714ce89d7378  vmovaps xmm1, [rsp+0x10]
0000714ce89d737e  vmovaps xmm2, [rsp+0x20]
0000714ce89d7384  vmovaps xmm3, [rsp+0x30]
0000714ce89d738a  vmovaps xmm4, [rsp+0x40]
0000714ce89d7390  vmovaps xmm5, [rsp+0x50]
0000714ce89d7396  vmovaps xmm6, [rsp+0x60]
0000714ce89d739c  vmovaps xmm7, [rsp+0x70]
0000714ce89d73a2  vmovaps xmm8, [rsp+0x80]
0000714ce89d73ab  vmovaps xmm9, [rsp+0x90]
0000714ce89d73b4  vmovaps xmm10, [rsp+0xA0]
0000714ce89d73bd  vmovaps xmm11, [rsp+0xB0]
0000714ce89d73c6  vmovaps xmm12, [rsp+0xC0]
0000714ce89d73cf  vmovaps xmm13, [rsp+0xD0]
0000714ce89d73d8  vmovaps xmm14, [rsp+0xE0]
0000714ce89d73e1  add rsp, 0xF0
0000714ce89d73e8  pop r11
0000714ce89d73ea  pop r10
0000714ce89d73ec  pop r9
0000714ce89d73ee  pop r8
0000714ce89d73f0  pop rsi
0000714ce89d73f1  pop rdi
0000714ce89d73f2  pop rdx
0000714ce89d73f3  pop rcx
0000714ce89d73f4  pop rax
0000714ce89d73f5  add rsp, 0x08
0000714ce89d73f9  jmp 0x0000714CE89D32E9
0000714ce89d73fe  sub rsp, 0x08
0000714ce89d7402  push rax
0000714ce89d7403  push rcx
0000714ce89d7404  push rdx
0000714ce89d7405  push rdi
0000714ce89d7406  push rsi
0000714ce89d7407  push r8
0000714ce89d7409  push r9
0000714ce89d740b  push r10
0000714ce89d740d  push r11
0000714ce89d740f  sub rsp, 0xF0
0000714ce89d7416  vmovaps [rsp], xmm0
0000714ce89d741b  vmovaps [rsp+0x10], xmm1
0000714ce89d7421  vmovaps [rsp+0x20], xmm2
0000714ce89d7427  vmovaps [rsp+0x30], xmm3
0000714ce89d742d  vmovaps [rsp+0x40], xmm4
0000714ce89d7433  vmovaps [rsp+0x50], xmm5
0000714ce89d7439  vmovaps [rsp+0x60], xmm6
0000714ce89d743f  vmovaps [rsp+0x70], xmm7
0000714ce89d7445  vmovaps [rsp+0x80], xmm8
0000714ce89d744e  vmovaps [rsp+0x90], xmm10
0000714ce89d7457  vmovaps [rsp+0xA0], xmm11
0000714ce89d7460  vmovaps [rsp+0xB0], xmm12
0000714ce89d7469  vmovaps [rsp+0xC0], xmm13
0000714ce89d7472  vmovaps [rsp+0xD0], xmm14
0000714ce89d747b  vmovaps [rsp+0xE0], xmm15
0000714ce89d7484  sub rsp, 0x30
0000714ce89d7488  movaps [rsp], xmm9
0000714ce89d748d  movaps [rsp+0x10], xmm7
0000714ce89d7492  movaps [rsp+0x20], xmm14
0000714ce89d7498  lea rdi, [rsp]
0000714ce89d749c  mov esi, 0x00
0000714ce89d74a1  mov rax, 0x57A55D340530
0000714ce89d74ab  call rax
0000714ce89d74ad  movaps xmm9, [rsp]
0000714ce89d74b2  add rsp, 0x30
0000714ce89d74b6  vmovaps xmm0, [rsp]
0000714ce89d74bb  vmovaps xmm1, [rsp+0x10]
0000714ce89d74c1  vmovaps xmm2, [rsp+0x20]
0000714ce89d74c7  vmovaps xmm3, [rsp+0x30]
0000714ce89d74cd  vmovaps xmm4, [rsp+0x40]
0000714ce89d74d3  vmovaps xmm5, [rsp+0x50]
0000714ce89d74d9  vmovaps xmm6, [rsp+0x60]
0000714ce89d74df  vmovaps xmm7, [rsp+0x70]
0000714ce89d74e5  vmovaps xmm8, [rsp+0x80]
0000714ce89d74ee  vmovaps xmm10, [rsp+0x90]
0000714ce89d74f7  vmovaps xmm11, [rsp+0xA0]
0000714ce89d7500  vmovaps xmm12, [rsp+0xB0]
0000714ce89d7509  vmovaps xmm13, [rsp+0xC0]
0000714ce89d7512  vmovaps xmm14, [rsp+0xD0]
0000714ce89d751b  vmovaps xmm15, [rsp+0xE0]
0000714ce89d7524  add rsp, 0xF0
0000714ce89d752b  pop r11
0000714ce89d752d  pop r10
0000714ce89d752f  pop r9
0000714ce89d7531  pop r8
0000714ce89d7533  pop rsi
0000714ce89d7534  pop rdi
0000714ce89d7535  pop rdx
0000714ce89d7536  pop rcx
0000714ce89d7537  pop rax
0000714ce89d7538  add rsp, 0x08
0000714ce89d753c  jmp 0x0000714CE89D3318
0000714ce89d7541  sub rsp, 0x08
0000714ce89d7545  push rax
0000714ce89d7546  push rcx
0000714ce89d7547  push rdx
0000714ce89d7548  push rdi
0000714ce89d7549  push rsi
0000714ce89d754a  push r8
0000714ce89d754c  push r9
0000714ce89d754e  push r10
0000714ce89d7550  push r11
0000714ce89d7552  sub rsp, 0xF0
0000714ce89d7559  vmovaps [rsp], xmm0
0000714ce89d755e  vmovaps [rsp+0x10], xmm1
0000714ce89d7564  vmovaps [rsp+0x20], xmm2
0000714ce89d756a  vmovaps [rsp+0x30], xmm3
0000714ce89d7570  vmovaps [rsp+0x40], xmm4
0000714ce89d7576  vmovaps [rsp+0x50], xmm5
0000714ce89d757c  vmovaps [rsp+0x60], xmm6
0000714ce89d7582  vmovaps [rsp+0x70], xmm7
0000714ce89d7588  vmovaps [rsp+0x80], xmm8
0000714ce89d7591  vmovaps [rsp+0x90], xmm9
0000714ce89d759a  vmovaps [rsp+0xA0], xmm10
0000714ce89d75a3  vmovaps [rsp+0xB0], xmm11
0000714ce89d75ac  vmovaps [rsp+0xC0], xmm12
0000714ce89d75b5  vmovaps [rsp+0xD0], xmm13
0000714ce89d75be  vmovaps [rsp+0xE0], xmm15
0000714ce89d75c7  sub rsp, 0x30
0000714ce89d75cb  movaps [rsp], xmm14
0000714ce89d75d0  movaps [rsp+0x10], xmm13
0000714ce89d75d6  movaps [rsp+0x20], xmm11
0000714ce89d75dc  lea rdi, [rsp]
0000714ce89d75e0  mov esi, 0x00
0000714ce89d75e5  mov rax, 0x57A55D340530
0000714ce89d75ef  call rax
0000714ce89d75f1  movaps xmm14, [rsp]
0000714ce89d75f6  add rsp, 0x30
0000714ce89d75fa  vmovaps xmm0, [rsp]
0000714ce89d75ff  vmovaps xmm1, [rsp+0x10]
0000714ce89d7605  vmovaps xmm2, [rsp+0x20]
0000714ce89d760b  vmovaps xmm3, [rsp+0x30]
0000714ce89d7611  vmovaps xmm4, [rsp+0x40]
0000714ce89d7617  vmovaps xmm5, [rsp+0x50]
0000714ce89d761d  vmovaps xmm6, [rsp+0x60]
0000714ce89d7623  vmovaps xmm7, [rsp+0x70]
0000714ce89d7629  vmovaps xmm8, [rsp+0x80]
0000714ce89d7632  vmovaps xmm9, [rsp+0x90]
0000714ce89d763b  vmovaps xmm10, [rsp+0xA0]
0000714ce89d7644  vmovaps xmm11, [rsp+0xB0]
0000714ce89d764d  vmovaps xmm12, [rsp+0xC0]
0000714ce89d7656  vmovaps xmm13, [rsp+0xD0]
0000714ce89d765f  vmovaps xmm15, [rsp+0xE0]
0000714ce89d7668  add rsp, 0xF0
0000714ce89d766f  pop r11
0000714ce89d7671  pop r10
0000714ce89d7673  pop r9
0000714ce89d7675  pop r8
0000714ce89d7677  pop rsi
0000714ce89d7678  pop rdi
0000714ce89d7679  pop rdx
0000714ce89d767a  pop rcx
0000714ce89d767b  pop rax
0000714ce89d767c  add rsp, 0x08
0000714ce89d7680  jmp 0x0000714CE89D3332
0000714ce89d7685  sub rsp, 0x08
0000714ce89d7689  push rax
0000714ce89d768a  push rcx
0000714ce89d768b  push rdx
0000714ce89d768c  push rdi
0000714ce89d768d  push rsi
0000714ce89d768e  push r8
0000714ce89d7690  push r9
0000714ce89d7692  push r10
0000714ce89d7694  push r11
0000714ce89d7696  sub rsp, 0xF0
0000714ce89d769d  vmovaps [rsp], xmm0
0000714ce89d76a2  vmovaps [rsp+0x10], xmm1
0000714ce89d76a8  vmovaps [rsp+0x20], xmm2
0000714ce89d76ae  vmovaps [rsp+0x30], xmm3
0000714ce89d76b4  vmovaps [rsp+0x40], xmm4
0000714ce89d76ba  vmovaps [rsp+0x50], xmm5
0000714ce89d76c0  vmovaps [rsp+0x60], xmm6
0000714ce89d76c6  vmovaps [rsp+0x70], xmm7
0000714ce89d76cc  vmovaps [rsp+0x80], xmm8
0000714ce89d76d5  vmovaps [rsp+0x90], xmm9
0000714ce89d76de  vmovaps [rsp+0xA0], xmm10
0000714ce89d76e7  vmovaps [rsp+0xB0], xmm12
0000714ce89d76f0  vmovaps [rsp+0xC0], xmm13
0000714ce89d76f9  vmovaps [rsp+0xD0], xmm14
0000714ce89d7702  vmovaps [rsp+0xE0], xmm15
0000714ce89d770b  sub rsp, 0x30
0000714ce89d770f  movaps [rsp], xmm11
0000714ce89d7714  movaps [rsp+0x10], xmm7
0000714ce89d7719  movaps [rsp+0x20], xmm13
0000714ce89d771f  lea rdi, [rsp]
0000714ce89d7723  mov esi, 0x00
0000714ce89d7728  mov rax, 0x57A55D340530
0000714ce89d7732  call rax
0000714ce89d7734  movaps xmm11, [rsp]
0000714ce89d7739  add rsp, 0x30
0000714ce89d773d  vmovaps xmm0, [rsp]
0000714ce89d7742  vmovaps xmm1, [rsp+0x10]
0000714ce89d7748  vmovaps xmm2, [rsp+0x20]
0000714ce89d774e  vmovaps xmm3, [rsp+0x30]
0000714ce89d7754  vmovaps xmm4, [rsp+0x40]
0000714ce89d775a  vmovaps xmm5, [rsp+0x50]
0000714ce89d7760  vmovaps xmm6, [rsp+0x60]
0000714ce89d7766  vmovaps xmm7, [rsp+0x70]
0000714ce89d776c  vmovaps xmm8, [rsp+0x80]
0000714ce89d7775  vmovaps xmm9, [rsp+0x90]
0000714ce89d777e  vmovaps xmm10, [rsp+0xA0]
0000714ce89d7787  vmovaps xmm12, [rsp+0xB0]
0000714ce89d7790  vmovaps xmm13, [rsp+0xC0]
0000714ce89d7799  vmovaps xmm14, [rsp+0xD0]
0000714ce89d77a2  vmovaps xmm15, [rsp+0xE0]
0000714ce89d77ab  add rsp, 0xF0
0000714ce89d77b2  pop r11
0000714ce89d77b4  pop r10
0000714ce89d77b6  pop r9
0000714ce89d77b8  pop r8
0000714ce89d77ba  pop rsi
0000714ce89d77bb  pop rdi
0000714ce89d77bc  pop rdx
0000714ce89d77bd  pop rcx
0000714ce89d77be  pop rax
0000714ce89d77bf  add rsp, 0x08
0000714ce89d77c3  jmp 0x0000714CE89D335E
0000714ce89d77c8  sub rsp, 0x08
0000714ce89d77cc  push rax
0000714ce89d77cd  push rcx
0000714ce89d77ce  push rdx
0000714ce89d77cf  push rdi
0000714ce89d77d0  push rsi
0000714ce89d77d1  push r8
0000714ce89d77d3  push r9
0000714ce89d77d5  push r10
0000714ce89d77d7  push r11
0000714ce89d77d9  sub rsp, 0xF0
0000714ce89d77e0  vmovaps [rsp], xmm0
0000714ce89d77e5  vmovaps [rsp+0x10], xmm1
0000714ce89d77eb  vmovaps [rsp+0x20], xmm2
0000714ce89d77f1  vmovaps [rsp+0x30], xmm3
0000714ce89d77f7  vmovaps [rsp+0x40], xmm4
0000714ce89d77fd  vmovaps [rsp+0x50], xmm5
0000714ce89d7803  vmovaps [rsp+0x60], xmm6
0000714ce89d7809  vmovaps [rsp+0x70], xmm7
0000714ce89d780f  vmovaps [rsp+0x80], xmm8
0000714ce89d7818  vmovaps [rsp+0x90], xmm9
0000714ce89d7821  vmovaps [rsp+0xA0], xmm10
0000714ce89d782a  vmovaps [rsp+0xB0], xmm11
0000714ce89d7833  vmovaps [rsp+0xC0], xmm12
0000714ce89d783c  vmovaps [rsp+0xD0], xmm14
0000714ce89d7845  vmovaps [rsp+0xE0], xmm15
0000714ce89d784e  sub rsp, 0x30
0000714ce89d7852  movaps [rsp], xmm13
0000714ce89d7857  movaps [rsp+0x10], xmm10
0000714ce89d785d  movaps [rsp+0x20], xmm12
0000714ce89d7863  lea rdi, [rsp]
0000714ce89d7867  mov esi, 0x00
0000714ce89d786c  mov rax, 0x57A55D340530
0000714ce89d7876  call rax
0000714ce89d7878  movaps xmm13, [rsp]
0000714ce89d787d  add rsp, 0x30
0000714ce89d7881  vmovaps xmm0, [rsp]
0000714ce89d7886  vmovaps xmm1, [rsp+0x10]
0000714ce89d788c  vmovaps xmm2, [rsp+0x20]
0000714ce89d7892  vmovaps xmm3, [rsp+0x30]
0000714ce89d7898  vmovaps xmm4, [rsp+0x40]
0000714ce89d789e  vmovaps xmm5, [rsp+0x50]
0000714ce89d78a4  vmovaps xmm6, [rsp+0x60]
0000714ce89d78aa  vmovaps xmm7, [rsp+0x70]
0000714ce89d78b0  vmovaps xmm8, [rsp+0x80]
0000714ce89d78b9  vmovaps xmm9, [rsp+0x90]
0000714ce89d78c2  vmovaps xmm10, [rsp+0xA0]
0000714ce89d78cb  vmovaps xmm11, [rsp+0xB0]
0000714ce89d78d4  vmovaps xmm12, [rsp+0xC0]
0000714ce89d78dd  vmovaps xmm14, [rsp+0xD0]
0000714ce89d78e6  vmovaps xmm15, [rsp+0xE0]
0000714ce89d78ef  add rsp, 0xF0
0000714ce89d78f6  pop r11
0000714ce89d78f8  pop r10
0000714ce89d78fa  pop r9
0000714ce89d78fc  pop r8
0000714ce89d78fe  pop rsi
0000714ce89d78ff  pop rdi
0000714ce89d7900  pop rdx
0000714ce89d7901  pop rcx
0000714ce89d7902  pop rax
0000714ce89d7903  add rsp, 0x08
0000714ce89d7907  jmp 0x0000714CE89D3378
0000714ce89d790c  sub rsp, 0x08
0000714ce89d7910  push rax
0000714ce89d7911  push rcx
0000714ce89d7912  push rdx
0000714ce89d7913  push rdi
0000714ce89d7914  push rsi
0000714ce89d7915  push r8
0000714ce89d7917  push r9
0000714ce89d7919  push r10
0000714ce89d791b  push r11
0000714ce89d791d  sub rsp, 0xF0
0000714ce89d7924  vmovaps [rsp], xmm0
0000714ce89d7929  vmovaps [rsp+0x10], xmm1
0000714ce89d792f  vmovaps [rsp+0x20], xmm2
0000714ce89d7935  vmovaps [rsp+0x30], xmm3
0000714ce89d793b  vmovaps [rsp+0x40], xmm4
0000714ce89d7941  vmovaps [rsp+0x50], xmm5
0000714ce89d7947  vmovaps [rsp+0x60], xmm6
0000714ce89d794d  vmovaps [rsp+0x70], xmm7
0000714ce89d7953  vmovaps [rsp+0x80], xmm8
0000714ce89d795c  vmovaps [rsp+0x90], xmm9
0000714ce89d7965  vmovaps [rsp+0xA0], xmm11
0000714ce89d796e  vmovaps [rsp+0xB0], xmm12
0000714ce89d7977  vmovaps [rsp+0xC0], xmm13
0000714ce89d7980  vmovaps [rsp+0xD0], xmm14
0000714ce89d7989  vmovaps [rsp+0xE0], xmm15
0000714ce89d7992  sub rsp, 0x30
0000714ce89d7996  movaps [rsp], xmm10
0000714ce89d799b  movaps [rsp+0x10], xmm7
0000714ce89d79a0  movaps [rsp+0x20], xmm12
0000714ce89d79a6  lea rdi, [rsp]
0000714ce89d79aa  mov esi, 0x00
0000714ce89d79af  mov rax, 0x57A55D340530
0000714ce89d79b9  call rax
0000714ce89d79bb  movaps xmm10, [rsp]
0000714ce89d79c0  add rsp, 0x30
0000714ce89d79c4  vmovaps xmm0, [rsp]
0000714ce89d79c9  vmovaps xmm1, [rsp+0x10]
0000714ce89d79cf  vmovaps xmm2, [rsp+0x20]
0000714ce89d79d5  vmovaps xmm3, [rsp+0x30]
0000714ce89d79db  vmovaps xmm4, [rsp+0x40]
0000714ce89d79e1  vmovaps xmm5, [rsp+0x50]
0000714ce89d79e7  vmovaps xmm6, [rsp+0x60]
0000714ce89d79ed  vmovaps xmm7, [rsp+0x70]
0000714ce89d79f3  vmovaps xmm8, [rsp+0x80]
0000714ce89d79fc  vmovaps xmm9, [rsp+0x90]
0000714ce89d7a05  vmovaps xmm11, [rsp+0xA0]
0000714ce89d7a0e  vmovaps xmm12, [rsp+0xB0]
0000714ce89d7a17  vmovaps xmm13, [rsp+0xC0]
0000714ce89d7a20  vmovaps xmm14, [rsp+0xD0]
0000714ce89d7a29  vmovaps xmm15, [rsp+0xE0]
0000714ce89d7a32  add rsp, 0xF0
0000714ce89d7a39  pop r11
0000714ce89d7a3b  pop r10
0000714ce89d7a3d  pop r9
0000714ce89d7a3f  pop r8
0000714ce89d7a41  pop rsi
0000714ce89d7a42  pop rdi
0000714ce89d7a43  pop rdx
0000714ce89d7a44  pop rcx
0000714ce89d7a45  pop rax
0000714ce89d7a46  add rsp, 0x08
0000714ce89d7a4a  jmp 0x0000714CE89D33A4
0000714ce89d7a4f  sub rsp, 0x08
0000714ce89d7a53  push rax
0000714ce89d7a54  push rcx
0000714ce89d7a55  push rdx
0000714ce89d7a56  push rdi
0000714ce89d7a57  push rsi
0000714ce89d7a58  push r8
0000714ce89d7a5a  push r9
0000714ce89d7a5c  push r10
0000714ce89d7a5e  push r11
0000714ce89d7a60  sub rsp, 0xF0
0000714ce89d7a67  vmovaps [rsp], xmm0
0000714ce89d7a6c  vmovaps [rsp+0x10], xmm1
0000714ce89d7a72  vmovaps [rsp+0x20], xmm2
0000714ce89d7a78  vmovaps [rsp+0x30], xmm3
0000714ce89d7a7e  vmovaps [rsp+0x40], xmm4
0000714ce89d7a84  vmovaps [rsp+0x50], xmm5
0000714ce89d7a8a  vmovaps [rsp+0x60], xmm6
0000714ce89d7a90  vmovaps [rsp+0x70], xmm7
0000714ce89d7a96  vmovaps [rsp+0x80], xmm8
0000714ce89d7a9f  vmovaps [rsp+0x90], xmm9
0000714ce89d7aa8  vmovaps [rsp+0xA0], xmm10
0000714ce89d7ab1  vmovaps [rsp+0xB0], xmm11
0000714ce89d7aba  vmovaps [rsp+0xC0], xmm13
0000714ce89d7ac3  vmovaps [rsp+0xD0], xmm14
0000714ce89d7acc  vmovaps [rsp+0xE0], xmm15
0000714ce89d7ad5  sub rsp, 0x30
0000714ce89d7ad9  movaps [rsp], xmm12
0000714ce89d7ade  movaps [rsp+0x10], xmm1
0000714ce89d7ae3  movaps [rsp+0x20], xmm8
0000714ce89d7ae9  lea rdi, [rsp]
0000714ce89d7aed  mov esi, 0x00
0000714ce89d7af2  mov rax, 0x57A55D340530
0000714ce89d7afc  call rax
0000714ce89d7afe  movaps xmm12, [rsp]
0000714ce89d7b03  add rsp, 0x30
0000714ce89d7b07  vmovaps xmm0, [rsp]
0000714ce89d7b0c  vmovaps xmm1, [rsp+0x10]
0000714ce89d7b12  vmovaps xmm2, [rsp+0x20]
0000714ce89d7b18  vmovaps xmm3, [rsp+0x30]
0000714ce89d7b1e  vmovaps xmm4, [rsp+0x40]
0000714ce89d7b24  vmovaps xmm5, [rsp+0x50]
0000714ce89d7b2a  vmovaps xmm6, [rsp+0x60]
0000714ce89d7b30  vmovaps xmm7, [rsp+0x70]
0000714ce89d7b36  vmovaps xmm8, [rsp+0x80]
0000714ce89d7b3f  vmovaps xmm9, [rsp+0x90]
0000714ce89d7b48  vmovaps xmm10, [rsp+0xA0]
0000714ce89d7b51  vmovaps xmm11, [rsp+0xB0]
0000714ce89d7b5a  vmovaps xmm13, [rsp+0xC0]
0000714ce89d7b63  vmovaps xmm14, [rsp+0xD0]
0000714ce89d7b6c  vmovaps xmm15, [rsp+0xE0]
0000714ce89d7b75  add rsp, 0xF0
0000714ce89d7b7c  pop r11
0000714ce89d7b7e  pop r10
0000714ce89d7b80  pop r9
0000714ce89d7b82  pop r8
0000714ce89d7b84  pop rsi
0000714ce89d7b85  pop rdi
0000714ce89d7b86  pop rdx
0000714ce89d7b87  pop rcx
0000714ce89d7b88  pop rax
0000714ce89d7b89  add rsp, 0x08
0000714ce89d7b8d  jmp 0x0000714CE89D33BE
0000714ce89d7b92  call 0x0000714CE87FF430
0000714ce89d7b97  jmp 0x0000714CE89D33C8
0000714ce89d7b9c  sub rsp, 0x08
0000714ce89d7ba0  push rax
0000714ce89d7ba1  push rcx
0000714ce89d7ba2  push rdx
0000714ce89d7ba3  push rdi
0000714ce89d7ba4  push rsi
0000714ce89d7ba5  push r8
0000714ce89d7ba7  push r9
0000714ce89d7ba9  push r10
0000714ce89d7bab  push r11
0000714ce89d7bad  sub rsp, 0xF0
0000714ce89d7bb4  vmovaps [rsp], xmm0
0000714ce89d7bb9  vmovaps [rsp+0x10], xmm1
0000714ce89d7bbf  vmovaps [rsp+0x20], xmm2
0000714ce89d7bc5  vmovaps [rsp+0x30], xmm3
0000714ce89d7bcb  vmovaps [rsp+0x40], xmm4
0000714ce89d7bd1  vmovaps [rsp+0x50], xmm5
0000714ce89d7bd7  vmovaps [rsp+0x60], xmm6
0000714ce89d7bdd  vmovaps [rsp+0x70], xmm7
0000714ce89d7be3  vmovaps [rsp+0x80], xmm9
0000714ce89d7bec  vmovaps [rsp+0x90], xmm10
0000714ce89d7bf5  vmovaps [rsp+0xA0], xmm11
0000714ce89d7bfe  vmovaps [rsp+0xB0], xmm12
0000714ce89d7c07  vmovaps [rsp+0xC0], xmm13
0000714ce89d7c10  vmovaps [rsp+0xD0], xmm14
0000714ce89d7c19  vmovaps [rsp+0xE0], xmm15
0000714ce89d7c22  sub rsp, 0x30
0000714ce89d7c26  movaps [rsp], xmm8
0000714ce89d7c2b  movaps [rsp+0x10], xmm15
0000714ce89d7c31  movaps [rsp+0x20], xmm9
0000714ce89d7c37  lea rdi, [rsp]
0000714ce89d7c3b  mov esi, 0x00
0000714ce89d7c40  mov rax, 0x57A55D340530
0000714ce89d7c4a  call rax
0000714ce89d7c4c  movaps xmm8, [rsp]
0000714ce89d7c51  add rsp, 0x30
0000714ce89d7c55  vmovaps xmm0, [rsp]
0000714ce89d7c5a  vmovaps xmm1, [rsp+0x10]
0000714ce89d7c60  vmovaps xmm2, [rsp+0x20]
0000714ce89d7c66  vmovaps xmm3, [rsp+0x30]
0000714ce89d7c6c  vmovaps xmm4, [rsp+0x40]
0000714ce89d7c72  vmovaps xmm5, [rsp+0x50]
0000714ce89d7c78  vmovaps xmm6, [rsp+0x60]
0000714ce89d7c7e  vmovaps xmm7, [rsp+0x70]
0000714ce89d7c84  vmovaps xmm9, [rsp+0x80]
0000714ce89d7c8d  vmovaps xmm10, [rsp+0x90]
0000714ce89d7c96  vmovaps xmm11, [rsp+0xA0]
0000714ce89d7c9f  vmovaps xmm12, [rsp+0xB0]
0000714ce89d7ca8  vmovaps xmm13, [rsp+0xC0]
0000714ce89d7cb1  vmovaps xmm14, [rsp+0xD0]
0000714ce89d7cba  vmovaps xmm15, [rsp+0xE0]
0000714ce89d7cc3  add rsp, 0xF0
0000714ce89d7cca  pop r11
0000714ce89d7ccc  pop r10
0000714ce89d7cce  pop r9
0000714ce89d7cd0  pop r8
0000714ce89d7cd2  pop rsi
0000714ce89d7cd3  pop rdi
0000714ce89d7cd4  pop rdx
0000714ce89d7cd5  pop rcx
0000714ce89d7cd6  pop rax
0000714ce89d7cd7  add rsp, 0x08
0000714ce89d7cdb  jmp 0x0000714CE89D33EA
0000714ce89d7ce0  sub rsp, 0x08
0000714ce89d7ce4  push rax
0000714ce89d7ce5  push rcx
0000714ce89d7ce6  push rdx
0000714ce89d7ce7  push rdi
0000714ce89d7ce8  push rsi
0000714ce89d7ce9  push r8
0000714ce89d7ceb  push r9
0000714ce89d7ced  push r10
0000714ce89d7cef  push r11
0000714ce89d7cf1  sub rsp, 0xF0
0000714ce89d7cf8  vmovaps [rsp], xmm0
0000714ce89d7cfd  vmovaps [rsp+0x10], xmm1
0000714ce89d7d03  vmovaps [rsp+0x20], xmm2
0000714ce89d7d09  vmovaps [rsp+0x30], xmm3
0000714ce89d7d0f  vmovaps [rsp+0x40], xmm4
0000714ce89d7d15  vmovaps [rsp+0x50], xmm5
0000714ce89d7d1b  vmovaps [rsp+0x60], xmm6
0000714ce89d7d21  vmovaps [rsp+0x70], xmm7
0000714ce89d7d27  vmovaps [rsp+0x80], xmm8
0000714ce89d7d30  vmovaps [rsp+0x90], xmm10
0000714ce89d7d39  vmovaps [rsp+0xA0], xmm11
0000714ce89d7d42  vmovaps [rsp+0xB0], xmm12
0000714ce89d7d4b  vmovaps [rsp+0xC0], xmm13
0000714ce89d7d54  vmovaps [rsp+0xD0], xmm14
0000714ce89d7d5d  vmovaps [rsp+0xE0], xmm15
0000714ce89d7d66  sub rsp, 0x30
0000714ce89d7d6a  movaps [rsp], xmm9
0000714ce89d7d6f  movaps [rsp+0x10], xmm1
0000714ce89d7d74  movaps [rsp+0x20], xmm15
0000714ce89d7d7a  lea rdi, [rsp]
0000714ce89d7d7e  mov esi, 0x00
0000714ce89d7d83  mov rax, 0x57A55D340530
0000714ce89d7d8d  call rax
0000714ce89d7d8f  movaps xmm9, [rsp]
0000714ce89d7d94  add rsp, 0x30
0000714ce89d7d98  vmovaps xmm0, [rsp]
0000714ce89d7d9d  vmovaps xmm1, [rsp+0x10]
0000714ce89d7da3  vmovaps xmm2, [rsp+0x20]
0000714ce89d7da9  vmovaps xmm3, [rsp+0x30]
0000714ce89d7daf  vmovaps xmm4, [rsp+0x40]
0000714ce89d7db5  vmovaps xmm5, [rsp+0x50]
0000714ce89d7dbb  vmovaps xmm6, [rsp+0x60]
0000714ce89d7dc1  vmovaps xmm7, [rsp+0x70]
0000714ce89d7dc7  vmovaps xmm8, [rsp+0x80]
0000714ce89d7dd0  vmovaps xmm10, [rsp+0x90]
0000714ce89d7dd9  vmovaps xmm11, [rsp+0xA0]
0000714ce89d7de2  vmovaps xmm12, [rsp+0xB0]
0000714ce89d7deb  vmovaps xmm13, [rsp+0xC0]
0000714ce89d7df4  vmovaps xmm14, [rsp+0xD0]
0000714ce89d7dfd  vmovaps xmm15, [rsp+0xE0]
0000714ce89d7e06  add rsp, 0xF0
0000714ce89d7e0d  pop r11
0000714ce89d7e0f  pop r10
0000714ce89d7e11  pop r9
0000714ce89d7e13  pop r8
0000714ce89d7e15  pop rsi
0000714ce89d7e16  pop rdi
0000714ce89d7e17  pop rdx
0000714ce89d7e18  pop rcx
0000714ce89d7e19  pop rax
0000714ce89d7e1a  add rsp, 0x08
0000714ce89d7e1e  jmp 0x0000714CE89D3418
0000714ce89d7e23  sub rsp, 0x08
0000714ce89d7e27  push rax
0000714ce89d7e28  push rcx
0000714ce89d7e29  push rdx
0000714ce89d7e2a  push rdi
0000714ce89d7e2b  push rsi
0000714ce89d7e2c  push r8
0000714ce89d7e2e  push r9
0000714ce89d7e30  push r10
0000714ce89d7e32  push r11
0000714ce89d7e34  sub rsp, 0xF0
0000714ce89d7e3b  vmovaps [rsp], xmm0
0000714ce89d7e40  vmovaps [rsp+0x10], xmm1
0000714ce89d7e46  vmovaps [rsp+0x20], xmm2
0000714ce89d7e4c  vmovaps [rsp+0x30], xmm3
0000714ce89d7e52  vmovaps [rsp+0x40], xmm4
0000714ce89d7e58  vmovaps [rsp+0x50], xmm5
0000714ce89d7e5e  vmovaps [rsp+0x60], xmm6
0000714ce89d7e64  vmovaps [rsp+0x70], xmm7
0000714ce89d7e6a  vmovaps [rsp+0x80], xmm8
0000714ce89d7e73  vmovaps [rsp+0x90], xmm9
0000714ce89d7e7c  vmovaps [rsp+0xA0], xmm10
0000714ce89d7e85  vmovaps [rsp+0xB0], xmm11
0000714ce89d7e8e  vmovaps [rsp+0xC0], xmm12
0000714ce89d7e97  vmovaps [rsp+0xD0], xmm13
0000714ce89d7ea0  vmovaps [rsp+0xE0], xmm14
0000714ce89d7ea9  sub rsp, 0x30
0000714ce89d7ead  movaps [rsp], xmm15
0000714ce89d7eb2  movaps [rsp+0x10], xmm4
0000714ce89d7eb7  movaps [rsp+0x20], xmm1
0000714ce89d7ebc  lea rdi, [rsp]
0000714ce89d7ec0  mov esi, 0x00
0000714ce89d7ec5  mov rax, 0x57A55D340530
0000714ce89d7ecf  call rax
0000714ce89d7ed1  movaps xmm15, [rsp]
0000714ce89d7ed6  add rsp, 0x30
0000714ce89d7eda  vmovaps xmm0, [rsp]
0000714ce89d7edf  vmovaps xmm1, [rsp+0x10]
0000714ce89d7ee5  vmovaps xmm2, [rsp+0x20]
0000714ce89d7eeb  vmovaps xmm3, [rsp+0x30]
0000714ce89d7ef1  vmovaps xmm4, [rsp+0x40]
0000714ce89d7ef7  vmovaps xmm5, [rsp+0x50]
0000714ce89d7efd  vmovaps xmm6, [rsp+0x60]
0000714ce89d7f03  vmovaps xmm7, [rsp+0x70]
0000714ce89d7f09  vmovaps xmm8, [rsp+0x80]
0000714ce89d7f12  vmovaps xmm9, [rsp+0x90]
0000714ce89d7f1b  vmovaps xmm10, [rsp+0xA0]
0000714ce89d7f24  vmovaps xmm11, [rsp+0xB0]
0000714ce89d7f2d  vmovaps xmm12, [rsp+0xC0]
0000714ce89d7f36  vmovaps xmm13, [rsp+0xD0]
0000714ce89d7f3f  vmovaps xmm14, [rsp+0xE0]
0000714ce89d7f48  add rsp, 0xF0
0000714ce89d7f4f  pop r11
0000714ce89d7f51  pop r10
0000714ce89d7f53  pop r9
0000714ce89d7f55  pop r8
0000714ce89d7f57  pop rsi
0000714ce89d7f58  pop rdi
0000714ce89d7f59  pop rdx
0000714ce89d7f5a  pop rcx
0000714ce89d7f5b  pop rax
0000714ce89d7f5c  add rsp, 0x08
0000714ce89d7f60  jmp 0x0000714CE89D343E
0000714ce89d7f65  sub rsp, 0x08
0000714ce89d7f69  push rax
0000714ce89d7f6a  push rcx
0000714ce89d7f6b  push rdx
0000714ce89d7f6c  push rdi
0000714ce89d7f6d  push rsi
0000714ce89d7f6e  push r8
0000714ce89d7f70  push r9
0000714ce89d7f72  push r10
0000714ce89d7f74  push r11
0000714ce89d7f76  sub rsp, 0xF0
0000714ce89d7f7d  vmovaps [rsp], xmm0
0000714ce89d7f82  vmovaps [rsp+0x10], xmm2
0000714ce89d7f88  vmovaps [rsp+0x20], xmm3
0000714ce89d7f8e  vmovaps [rsp+0x30], xmm4
0000714ce89d7f94  vmovaps [rsp+0x40], xmm5
0000714ce89d7f9a  vmovaps [rsp+0x50], xmm6
0000714ce89d7fa0  vmovaps [rsp+0x60], xmm7
0000714ce89d7fa6  vmovaps [rsp+0x70], xmm8
0000714ce89d7fac  vmovaps [rsp+0x80], xmm9
0000714ce89d7fb5  vmovaps [rsp+0x90], xmm10
0000714ce89d7fbe  vmovaps [rsp+0xA0], xmm11
0000714ce89d7fc7  vmovaps [rsp+0xB0], xmm12
0000714ce89d7fd0  vmovaps [rsp+0xC0], xmm13
0000714ce89d7fd9  vmovaps [rsp+0xD0], xmm14
0000714ce89d7fe2  vmovaps [rsp+0xE0], xmm15
0000714ce89d7feb  sub rsp, 0x30
0000714ce89d7fef  movaps [rsp], xmm1
0000714ce89d7ff3  movaps [rsp+0x10], xmm14
0000714ce89d7ff9  movaps [rsp+0x20], xmm11
0000714ce89d7fff  lea rdi, [rsp]
0000714ce89d8003  mov esi, 0x00
0000714ce89d8008  mov rax, 0x57A55D340530
0000714ce89d8012  call rax
0000714ce89d8014  movaps xmm1, [rsp]
0000714ce89d8018  add rsp, 0x30
0000714ce89d801c  vmovaps xmm0, [rsp]
0000714ce89d8021  vmovaps xmm2, [rsp+0x10]
0000714ce89d8027  vmovaps xmm3, [rsp+0x20]
0000714ce89d802d  vmovaps xmm4, [rsp+0x30]
0000714ce89d8033  vmovaps xmm5, [rsp+0x40]
0000714ce89d8039  vmovaps xmm6, [rsp+0x50]
0000714ce89d803f  vmovaps xmm7, [rsp+0x60]
0000714ce89d8045  vmovaps xmm8, [rsp+0x70]
0000714ce89d804b  vmovaps xmm9, [rsp+0x80]
0000714ce89d8054  vmovaps xmm10, [rsp+0x90]
0000714ce89d805d  vmovaps xmm11, [rsp+0xA0]
0000714ce89d8066  vmovaps xmm12, [rsp+0xB0]
0000714ce89d806f  vmovaps xmm13, [rsp+0xC0]
0000714ce89d8078  vmovaps xmm14, [rsp+0xD0]
0000714ce89d8081  vmovaps xmm15, [rsp+0xE0]
0000714ce89d808a  add rsp, 0xF0
0000714ce89d8091  pop r11
0000714ce89d8093  pop r10
0000714ce89d8095  pop r9
0000714ce89d8097  pop r8
0000714ce89d8099  pop rsi
0000714ce89d809a  pop rdi
0000714ce89d809b  pop rdx
0000714ce89d809c  pop rcx
0000714ce89d809d  pop rax
0000714ce89d809e  add rsp, 0x08
0000714ce89d80a2  jmp 0x0000714CE89D345F
0000714ce89d80a7  call 0x0000714CE88E45A0
0000714ce89d80ac  jmp 0x0000714CE89D346D
0000714ce89d80b1  call 0x0000714CE8809D70
0000714ce89d80b6  jmp 0x0000714CE89D3477
0000714ce89d80bb  sub rsp, 0x08
0000714ce89d80bf  push rax
0000714ce89d80c0  push rcx
0000714ce89d80c1  push rdx
0000714ce89d80c2  push rdi
0000714ce89d80c3  push rsi
0000714ce89d80c4  push r8
0000714ce89d80c6  push r9
0000714ce89d80c8  push r10
0000714ce89d80ca  push r11
0000714ce89d80cc  sub rsp, 0xF0
0000714ce89d80d3  vmovaps [rsp], xmm0
0000714ce89d80d8  vmovaps [rsp+0x10], xmm1
0000714ce89d80de  vmovaps [rsp+0x20], xmm2
0000714ce89d80e4  vmovaps [rsp+0x30], xmm3
0000714ce89d80ea  vmovaps [rsp+0x40], xmm4
0000714ce89d80f0  vmovaps [rsp+0x50], xmm5
0000714ce89d80f6  vmovaps [rsp+0x60], xmm6
0000714ce89d80fc  vmovaps [rsp+0x70], xmm8
0000714ce89d8102  vmovaps [rsp+0x80], xmm9
0000714ce89d810b  vmovaps [rsp+0x90], xmm10
0000714ce89d8114  vmovaps [rsp+0xA0], xmm11
0000714ce89d811d  vmovaps [rsp+0xB0], xmm12
0000714ce89d8126  vmovaps [rsp+0xC0], xmm13
0000714ce89d812f  vmovaps [rsp+0xD0], xmm14
0000714ce89d8138  vmovaps [rsp+0xE0], xmm15
0000714ce89d8141  sub rsp, 0x30
0000714ce89d8145  movaps [rsp], xmm7
0000714ce89d8149  movaps [rsp+0x10], xmm13
0000714ce89d814f  movaps [rsp+0x20], xmm10
0000714ce89d8155  lea rdi, [rsp]
0000714ce89d8159  mov esi, 0x00
0000714ce89d815e  mov rax, 0x57A55D340530
0000714ce89d8168  call rax
0000714ce89d816a  movaps xmm7, [rsp]
0000714ce89d816e  add rsp, 0x30
0000714ce89d8172  vmovaps xmm0, [rsp]
0000714ce89d8177  vmovaps xmm1, [rsp+0x10]
0000714ce89d817d  vmovaps xmm2, [rsp+0x20]
0000714ce89d8183  vmovaps xmm3, [rsp+0x30]
0000714ce89d8189  vmovaps xmm4, [rsp+0x40]
0000714ce89d818f  vmovaps xmm5, [rsp+0x50]
0000714ce89d8195  vmovaps xmm6, [rsp+0x60]
0000714ce89d819b  vmovaps xmm8, [rsp+0x70]
0000714ce89d81a1  vmovaps xmm9, [rsp+0x80]
0000714ce89d81aa  vmovaps xmm10, [rsp+0x90]
0000714ce89d81b3  vmovaps xmm11, [rsp+0xA0]
0000714ce89d81bc  vmovaps xmm12, [rsp+0xB0]
0000714ce89d81c5  vmovaps xmm13, [rsp+0xC0]
0000714ce89d81ce  vmovaps xmm14, [rsp+0xD0]
0000714ce89d81d7  vmovaps xmm15, [rsp+0xE0]
0000714ce89d81e0  add rsp, 0xF0
0000714ce89d81e7  pop r11
0000714ce89d81e9  pop r10
0000714ce89d81eb  pop r9
0000714ce89d81ed  pop r8
0000714ce89d81ef  pop rsi
0000714ce89d81f0  pop rdi
0000714ce89d81f1  pop rdx
0000714ce89d81f2  pop rcx
0000714ce89d81f3  pop rax
0000714ce89d81f4  add rsp, 0x08
0000714ce89d81f8  jmp 0x0000714CE89D3498
0000714ce89d81fd  sub rsp, 0x08
0000714ce89d8201  push rax
0000714ce89d8202  push rcx
0000714ce89d8203  push rdx
0000714ce89d8204  push rdi
0000714ce89d8205  push rsi
0000714ce89d8206  push r8
0000714ce89d8208  push r9
0000714ce89d820a  push r10
0000714ce89d820c  push r11
0000714ce89d820e  sub rsp, 0xF0
0000714ce89d8215  vmovaps [rsp], xmm0
0000714ce89d821a  vmovaps [rsp+0x10], xmm1
0000714ce89d8220  vmovaps [rsp+0x20], xmm2
0000714ce89d8226  vmovaps [rsp+0x30], xmm3
0000714ce89d822c  vmovaps [rsp+0x40], xmm4
0000714ce89d8232  vmovaps [rsp+0x50], xmm5
0000714ce89d8238  vmovaps [rsp+0x60], xmm6
0000714ce89d823e  vmovaps [rsp+0x70], xmm7
0000714ce89d8244  vmovaps [rsp+0x80], xmm8
0000714ce89d824d  vmovaps [rsp+0x90], xmm9
0000714ce89d8256  vmovaps [rsp+0xA0], xmm11
0000714ce89d825f  vmovaps [rsp+0xB0], xmm12
0000714ce89d8268  vmovaps [rsp+0xC0], xmm13
0000714ce89d8271  vmovaps [rsp+0xD0], xmm14
0000714ce89d827a  vmovaps [rsp+0xE0], xmm15
0000714ce89d8283  sub rsp, 0x30
0000714ce89d8287  movaps [rsp], xmm10
0000714ce89d828c  movaps [rsp+0x10], xmm11
0000714ce89d8292  movaps [rsp+0x20], xmm13
0000714ce89d8298  lea rdi, [rsp]
0000714ce89d829c  mov esi, 0x00
0000714ce89d82a1  mov rax, 0x57A55D340530
0000714ce89d82ab  call rax
0000714ce89d82ad  movaps xmm10, [rsp]
0000714ce89d82b2  add rsp, 0x30
0000714ce89d82b6  vmovaps xmm0, [rsp]
0000714ce89d82bb  vmovaps xmm1, [rsp+0x10]
0000714ce89d82c1  vmovaps xmm2, [rsp+0x20]
0000714ce89d82c7  vmovaps xmm3, [rsp+0x30]
0000714ce89d82cd  vmovaps xmm4, [rsp+0x40]
0000714ce89d82d3  vmovaps xmm5, [rsp+0x50]
0000714ce89d82d9  vmovaps xmm6, [rsp+0x60]
0000714ce89d82df  vmovaps xmm7, [rsp+0x70]
0000714ce89d82e5  vmovaps xmm8, [rsp+0x80]
0000714ce89d82ee  vmovaps xmm9, [rsp+0x90]
0000714ce89d82f7  vmovaps xmm11, [rsp+0xA0]
0000714ce89d8300  vmovaps xmm12, [rsp+0xB0]
0000714ce89d8309  vmovaps xmm13, [rsp+0xC0]
0000714ce89d8312  vmovaps xmm14, [rsp+0xD0]
0000714ce89d831b  vmovaps xmm15, [rsp+0xE0]
0000714ce89d8324  add rsp, 0xF0
0000714ce89d832b  pop r11
0000714ce89d832d  pop r10
0000714ce89d832f  pop r9
0000714ce89d8331  pop r8
0000714ce89d8333  pop rsi
0000714ce89d8334  pop rdi
0000714ce89d8335  pop rdx
0000714ce89d8336  pop rcx
0000714ce89d8337  pop rax
0000714ce89d8338  add rsp, 0x08
0000714ce89d833c  jmp 0x0000714CE89D34C6
0000714ce89d8341  sub rsp, 0x08
0000714ce89d8345  push rax
0000714ce89d8346  push rcx
0000714ce89d8347  push rdx
0000714ce89d8348  push rdi
0000714ce89d8349  push rsi
0000714ce89d834a  push r8
0000714ce89d834c  push r9
0000714ce89d834e  push r10
0000714ce89d8350  push r11
0000714ce89d8352  sub rsp, 0xF0
0000714ce89d8359  vmovaps [rsp], xmm0
0000714ce89d835e  vmovaps [rsp+0x10], xmm1
0000714ce89d8364  vmovaps [rsp+0x20], xmm2
0000714ce89d836a  vmovaps [rsp+0x30], xmm3
0000714ce89d8370  vmovaps [rsp+0x40], xmm4
0000714ce89d8376  vmovaps [rsp+0x50], xmm5
0000714ce89d837c  vmovaps [rsp+0x60], xmm6
0000714ce89d8382  vmovaps [rsp+0x70], xmm7
0000714ce89d8388  vmovaps [rsp+0x80], xmm8
0000714ce89d8391  vmovaps [rsp+0x90], xmm9
0000714ce89d839a  vmovaps [rsp+0xA0], xmm10
0000714ce89d83a3  vmovaps [rsp+0xB0], xmm12
0000714ce89d83ac  vmovaps [rsp+0xC0], xmm13
0000714ce89d83b5  vmovaps [rsp+0xD0], xmm14
0000714ce89d83be  vmovaps [rsp+0xE0], xmm15
0000714ce89d83c7  sub rsp, 0x30
0000714ce89d83cb  movaps [rsp], xmm11
0000714ce89d83d0  movaps [rsp+0x10], xmm14
0000714ce89d83d6  movaps [rsp+0x20], xmm13
0000714ce89d83dc  lea rdi, [rsp]
0000714ce89d83e0  mov esi, 0x00
0000714ce89d83e5  mov rax, 0x57A55D340530
0000714ce89d83ef  call rax
0000714ce89d83f1  movaps xmm11, [rsp]
0000714ce89d83f6  add rsp, 0x30
0000714ce89d83fa  vmovaps xmm0, [rsp]
0000714ce89d83ff  vmovaps xmm1, [rsp+0x10]
0000714ce89d8405  vmovaps xmm2, [rsp+0x20]
0000714ce89d840b  vmovaps xmm3, [rsp+0x30]
0000714ce89d8411  vmovaps xmm4, [rsp+0x40]
0000714ce89d8417  vmovaps xmm5, [rsp+0x50]
0000714ce89d841d  vmovaps xmm6, [rsp+0x60]
0000714ce89d8423  vmovaps xmm7, [rsp+0x70]
0000714ce89d8429  vmovaps xmm8, [rsp+0x80]
0000714ce89d8432  vmovaps xmm9, [rsp+0x90]
0000714ce89d843b  vmovaps xmm10, [rsp+0xA0]
0000714ce89d8444  vmovaps xmm12, [rsp+0xB0]
0000714ce89d844d  vmovaps xmm13, [rsp+0xC0]
0000714ce89d8456  vmovaps xmm14, [rsp+0xD0]
0000714ce89d845f  vmovaps xmm15, [rsp+0xE0]
0000714ce89d8468  add rsp, 0xF0
0000714ce89d846f  pop r11
0000714ce89d8471  pop r10
0000714ce89d8473  pop r9
0000714ce89d8475  pop r8
0000714ce89d8477  pop rsi
0000714ce89d8478  pop rdi
0000714ce89d8479  pop rdx
0000714ce89d847a  pop rcx
0000714ce89d847b  pop rax
0000714ce89d847c  add rsp, 0x08
0000714ce89d8480  jmp 0x0000714CE89D34F4
0000714ce89d8485  sub rsp, 0x08
0000714ce89d8489  push rax
0000714ce89d848a  push rcx
0000714ce89d848b  push rdx
0000714ce89d848c  push rdi
0000714ce89d848d  push rsi
0000714ce89d848e  push r8
0000714ce89d8490  push r9
0000714ce89d8492  push r10
0000714ce89d8494  push r11
0000714ce89d8496  sub rsp, 0xF0
0000714ce89d849d  vmovaps [rsp], xmm0
0000714ce89d84a2  vmovaps [rsp+0x10], xmm1
0000714ce89d84a8  vmovaps [rsp+0x20], xmm2
0000714ce89d84ae  vmovaps [rsp+0x30], xmm3
0000714ce89d84b4  vmovaps [rsp+0x40], xmm4
0000714ce89d84ba  vmovaps [rsp+0x50], xmm5
0000714ce89d84c0  vmovaps [rsp+0x60], xmm6
0000714ce89d84c6  vmovaps [rsp+0x70], xmm7
0000714ce89d84cc  vmovaps [rsp+0x80], xmm8
0000714ce89d84d5  vmovaps [rsp+0x90], xmm9
0000714ce89d84de  vmovaps [rsp+0xA0], xmm10
0000714ce89d84e7  vmovaps [rsp+0xB0], xmm11
0000714ce89d84f0  vmovaps [rsp+0xC0], xmm12
0000714ce89d84f9  vmovaps [rsp+0xD0], xmm13
0000714ce89d8502  vmovaps [rsp+0xE0], xmm15
0000714ce89d850b  sub rsp, 0x30
0000714ce89d850f  movaps [rsp], xmm14
0000714ce89d8514  movaps [rsp+0x10], xmm12
0000714ce89d851a  movaps [rsp+0x20], xmm9
0000714ce89d8520  lea rdi, [rsp]
0000714ce89d8524  mov esi, 0x00
0000714ce89d8529  mov rax, 0x57A55D340530
0000714ce89d8533  call rax
0000714ce89d8535  movaps xmm14, [rsp]
0000714ce89d853a  add rsp, 0x30
0000714ce89d853e  vmovaps xmm0, [rsp]
0000714ce89d8543  vmovaps xmm1, [rsp+0x10]
0000714ce89d8549  vmovaps xmm2, [rsp+0x20]
0000714ce89d854f  vmovaps xmm3, [rsp+0x30]
0000714ce89d8555  vmovaps xmm4, [rsp+0x40]
0000714ce89d855b  vmovaps xmm5, [rsp+0x50]
0000714ce89d8561  vmovaps xmm6, [rsp+0x60]
0000714ce89d8567  vmovaps xmm7, [rsp+0x70]
0000714ce89d856d  vmovaps xmm8, [rsp+0x80]
0000714ce89d8576  vmovaps xmm9, [rsp+0x90]
0000714ce89d857f  vmovaps xmm10, [rsp+0xA0]
0000714ce89d8588  vmovaps xmm11, [rsp+0xB0]
0000714ce89d8591  vmovaps xmm12, [rsp+0xC0]
0000714ce89d859a  vmovaps xmm13, [rsp+0xD0]
0000714ce89d85a3  vmovaps xmm15, [rsp+0xE0]
0000714ce89d85ac  add rsp, 0xF0
0000714ce89d85b3  pop r11
0000714ce89d85b5  pop r10
0000714ce89d85b7  pop r9
0000714ce89d85b9  pop r8
0000714ce89d85bb  pop rsi
0000714ce89d85bc  pop rdi
0000714ce89d85bd  pop rdx
0000714ce89d85be  pop rcx
0000714ce89d85bf  pop rax
0000714ce89d85c0  add rsp, 0x08
0000714ce89d85c4  jmp 0x0000714CE89D350F
0000714ce89d85c9  sub rsp, 0x08
0000714ce89d85cd  push rax
0000714ce89d85ce  push rcx
0000714ce89d85cf  push rdx
0000714ce89d85d0  push rdi
0000714ce89d85d1  push rsi
0000714ce89d85d2  push r8
0000714ce89d85d4  push r9
0000714ce89d85d6  push r10
0000714ce89d85d8  push r11
0000714ce89d85da  sub rsp, 0xF0
0000714ce89d85e1  vmovaps [rsp], xmm0
0000714ce89d85e6  vmovaps [rsp+0x10], xmm1
0000714ce89d85ec  vmovaps [rsp+0x20], xmm2
0000714ce89d85f2  vmovaps [rsp+0x30], xmm3
0000714ce89d85f8  vmovaps [rsp+0x40], xmm4
0000714ce89d85fe  vmovaps [rsp+0x50], xmm5
0000714ce89d8604  vmovaps [rsp+0x60], xmm6
0000714ce89d860a  vmovaps [rsp+0x70], xmm7
0000714ce89d8610  vmovaps [rsp+0x80], xmm8
0000714ce89d8619  vmovaps [rsp+0x90], xmm9
0000714ce89d8622  vmovaps [rsp+0xA0], xmm10
0000714ce89d862b  vmovaps [rsp+0xB0], xmm11
0000714ce89d8634  vmovaps [rsp+0xC0], xmm12
0000714ce89d863d  vmovaps [rsp+0xD0], xmm14
0000714ce89d8646  vmovaps [rsp+0xE0], xmm15
0000714ce89d864f  sub rsp, 0x30
0000714ce89d8653  movaps [rsp], xmm13
0000714ce89d8658  movaps [rsp+0x10], xmm8
0000714ce89d865e  movaps [rsp+0x20], xmm15
0000714ce89d8664  lea rdi, [rsp]
0000714ce89d8668  mov esi, 0x00
0000714ce89d866d  mov rax, 0x57A55D340530
0000714ce89d8677  call rax
0000714ce89d8679  movaps xmm13, [rsp]
0000714ce89d867e  add rsp, 0x30
0000714ce89d8682  vmovaps xmm0, [rsp]
0000714ce89d8687  vmovaps xmm1, [rsp+0x10]
0000714ce89d868d  vmovaps xmm2, [rsp+0x20]
0000714ce89d8693  vmovaps xmm3, [rsp+0x30]
0000714ce89d8699  vmovaps xmm4, [rsp+0x40]
0000714ce89d869f  vmovaps xmm5, [rsp+0x50]
0000714ce89d86a5  vmovaps xmm6, [rsp+0x60]
0000714ce89d86ab  vmovaps xmm7, [rsp+0x70]
0000714ce89d86b1  vmovaps xmm8, [rsp+0x80]
0000714ce89d86ba  vmovaps xmm9, [rsp+0x90]
0000714ce89d86c3  vmovaps xmm10, [rsp+0xA0]
0000714ce89d86cc  vmovaps xmm11, [rsp+0xB0]
0000714ce89d86d5  vmovaps xmm12, [rsp+0xC0]
0000714ce89d86de  vmovaps xmm14, [rsp+0xD0]
0000714ce89d86e7  vmovaps xmm15, [rsp+0xE0]
0000714ce89d86f0  add rsp, 0xF0
0000714ce89d86f7  pop r11
0000714ce89d86f9  pop r10
0000714ce89d86fb  pop r9
0000714ce89d86fd  pop r8
0000714ce89d86ff  pop rsi
0000714ce89d8700  pop rdi
0000714ce89d8701  pop rdx
0000714ce89d8702  pop rcx
0000714ce89d8703  pop rax
0000714ce89d8704  add rsp, 0x08
0000714ce89d8708  jmp 0x0000714CE89D3532
0000714ce89d870d  sub rsp, 0x08
0000714ce89d8711  push rax
0000714ce89d8712  push rcx
0000714ce89d8713  push rdx
0000714ce89d8714  push rdi
0000714ce89d8715  push rsi
0000714ce89d8716  push r8
0000714ce89d8718  push r9
0000714ce89d871a  push r10
0000714ce89d871c  push r11
0000714ce89d871e  sub rsp, 0xF0
0000714ce89d8725  vmovaps [rsp], xmm0
0000714ce89d872a  vmovaps [rsp+0x10], xmm1
0000714ce89d8730  vmovaps [rsp+0x20], xmm2
0000714ce89d8736  vmovaps [rsp+0x30], xmm3
0000714ce89d873c  vmovaps [rsp+0x40], xmm4
0000714ce89d8742  vmovaps [rsp+0x50], xmm5
0000714ce89d8748  vmovaps [rsp+0x60], xmm6
0000714ce89d874e  vmovaps [rsp+0x70], xmm7
0000714ce89d8754  vmovaps [rsp+0x80], xmm8
0000714ce89d875d  vmovaps [rsp+0x90], xmm9
0000714ce89d8766  vmovaps [rsp+0xA0], xmm10
0000714ce89d876f  vmovaps [rsp+0xB0], xmm11
0000714ce89d8778  vmovaps [rsp+0xC0], xmm12
0000714ce89d8781  vmovaps [rsp+0xD0], xmm13
0000714ce89d878a  vmovaps [rsp+0xE0], xmm14
0000714ce89d8793  sub rsp, 0x30
0000714ce89d8797  movaps [rsp], xmm15
0000714ce89d879c  movaps [rsp+0x10], xmm1
0000714ce89d87a1  movaps [rsp+0x20], xmm10
0000714ce89d87a7  lea rdi, [rsp]
0000714ce89d87ab  mov esi, 0x00
0000714ce89d87b0  mov rax, 0x57A55D340530
0000714ce89d87ba  call rax
0000714ce89d87bc  movaps xmm15, [rsp]
0000714ce89d87c1  add rsp, 0x30
0000714ce89d87c5  vmovaps xmm0, [rsp]
0000714ce89d87ca  vmovaps xmm1, [rsp+0x10]
0000714ce89d87d0  vmovaps xmm2, [rsp+0x20]
0000714ce89d87d6  vmovaps xmm3, [rsp+0x30]
0000714ce89d87dc  vmovaps xmm4, [rsp+0x40]
0000714ce89d87e2  vmovaps xmm5, [rsp+0x50]
0000714ce89d87e8  vmovaps xmm6, [rsp+0x60]
0000714ce89d87ee  vmovaps xmm7, [rsp+0x70]
0000714ce89d87f4  vmovaps xmm8, [rsp+0x80]
0000714ce89d87fd  vmovaps xmm9, [rsp+0x90]
0000714ce89d8806  vmovaps xmm10, [rsp+0xA0]
0000714ce89d880f  vmovaps xmm11, [rsp+0xB0]
0000714ce89d8818  vmovaps xmm12, [rsp+0xC0]
0000714ce89d8821  vmovaps xmm13, [rsp+0xD0]
0000714ce89d882a  vmovaps xmm14, [rsp+0xE0]
0000714ce89d8833  add rsp, 0xF0
0000714ce89d883a  pop r11
0000714ce89d883c  pop r10
0000714ce89d883e  pop r9
0000714ce89d8840  pop r8
0000714ce89d8842  pop rsi
0000714ce89d8843  pop rdi
0000714ce89d8844  pop rdx
0000714ce89d8845  pop rcx
0000714ce89d8846  pop rax
0000714ce89d8847  add rsp, 0x08
0000714ce89d884b  jmp 0x0000714CE89D3555
0000714ce89d8850  sub rsp, 0x08
0000714ce89d8854  push rax
0000714ce89d8855  push rcx
0000714ce89d8856  push rdx
0000714ce89d8857  push rdi
0000714ce89d8858  push rsi
0000714ce89d8859  push r8
0000714ce89d885b  push r9
0000714ce89d885d  push r10
0000714ce89d885f  push r11
0000714ce89d8861  sub rsp, 0xF0
0000714ce89d8868  vmovaps [rsp], xmm0
0000714ce89d886d  vmovaps [rsp+0x10], xmm2
0000714ce89d8873  vmovaps [rsp+0x20], xmm3
0000714ce89d8879  vmovaps [rsp+0x30], xmm4
0000714ce89d887f  vmovaps [rsp+0x40], xmm5
0000714ce89d8885  vmovaps [rsp+0x50], xmm6
0000714ce89d888b  vmovaps [rsp+0x60], xmm7
0000714ce89d8891  vmovaps [rsp+0x70], xmm8
0000714ce89d8897  vmovaps [rsp+0x80], xmm9
0000714ce89d88a0  vmovaps [rsp+0x90], xmm10
0000714ce89d88a9  vmovaps [rsp+0xA0], xmm11
0000714ce89d88b2  vmovaps [rsp+0xB0], xmm12
0000714ce89d88bb  vmovaps [rsp+0xC0], xmm13
0000714ce89d88c4  vmovaps [rsp+0xD0], xmm14
0000714ce89d88cd  vmovaps [rsp+0xE0], xmm15
0000714ce89d88d6  sub rsp, 0x30
0000714ce89d88da  movaps [rsp], xmm1
0000714ce89d88de  movaps [rsp+0x10], xmm7
0000714ce89d88e3  movaps [rsp+0x20], xmm11
0000714ce89d88e9  lea rdi, [rsp]
0000714ce89d88ed  mov esi, 0x00
0000714ce89d88f2  mov rax, 0x57A55D340530
0000714ce89d88fc  call rax
0000714ce89d88fe  movaps xmm1, [rsp]
0000714ce89d8902  add rsp, 0x30
0000714ce89d8906  vmovaps xmm0, [rsp]
0000714ce89d890b  vmovaps xmm2, [rsp+0x10]
0000714ce89d8911  vmovaps xmm3, [rsp+0x20]
0000714ce89d8917  vmovaps xmm4, [rsp+0x30]
0000714ce89d891d  vmovaps xmm5, [rsp+0x40]
0000714ce89d8923  vmovaps xmm6, [rsp+0x50]
0000714ce89d8929  vmovaps xmm7, [rsp+0x60]
0000714ce89d892f  vmovaps xmm8, [rsp+0x70]
0000714ce89d8935  vmovaps xmm9, [rsp+0x80]
0000714ce89d893e  vmovaps xmm10, [rsp+0x90]
0000714ce89d8947  vmovaps xmm11, [rsp+0xA0]
0000714ce89d8950  vmovaps xmm12, [rsp+0xB0]
0000714ce89d8959  vmovaps xmm13, [rsp+0xC0]
0000714ce89d8962  vmovaps xmm14, [rsp+0xD0]
0000714ce89d896b  vmovaps xmm15, [rsp+0xE0]
0000714ce89d8974  add rsp, 0xF0
0000714ce89d897b  pop r11
0000714ce89d897d  pop r10
0000714ce89d897f  pop r9
0000714ce89d8981  pop r8
0000714ce89d8983  pop rsi
0000714ce89d8984  pop rdi
0000714ce89d8985  pop rdx
0000714ce89d8986  pop rcx
0000714ce89d8987  pop rax
0000714ce89d8988  add rsp, 0x08
0000714ce89d898c  jmp 0x0000714CE89D3576
0000714ce89d8991  call 0x0000714CE880D600
0000714ce89d8996  jmp 0x0000714CE89D3589
0000714ce89d899b  call 0x0000714CE880C380
0000714ce89d89a0  jmp 0x0000714CE89D3594
0000714ce89d89a5  call 0x0000714CE880E880
0000714ce89d89aa  jmp 0x0000714CE89D359F
0000714ce89d89af  call 0x0000714CE87FF540
0000714ce89d89b4  jmp 0x0000714CE89D35AA
0000714ce89d89b9  int3
0000714ce89d89ba  nop [rax+rax*1], ax
0000714ce89d89c0  mov rax, [r15+0x40]
0000714ce89d89c4  mov r14, [r15+0x58]
0000714ce89d89c8  lea r12, [rax+r14*1]
0000714ce89d89cc  movaps xmm1, [r15+0x1D0]
0000714ce89d89d4  vmovaps [rsp+0x10], xmm1
0000714ce89d89da  vmovaps xmm15, [rsp+0x10]
0000714ce89d89e0  por xmm1, xmm15
0000714ce89d89e5  movaps xmm14, [r15+0x1A0]
0000714ce89d89ed  vmovaps [rsp+0x10], xmm14
0000714ce89d89f3  vmovaps xmm13, [rsp+0x10]
0000714ce89d89f9  por xmm14, xmm13
0000714ce89d89fe  lea rax, [r12+0x30]
0000714ce89d8a03  mov r11, [r13+rax*1]
0000714ce89d8a08  lea rax, [r12+0x38]
0000714ce89d8a0d  mov r10, [r13+rax*1]
0000714ce89d8a12  movq xmm13, r11
0000714ce89d8a17  movq xmm12, r10
0000714ce89d8a1c  movq xmm13, xmm13
0000714ce89d8a21  vmovaps [rsp+0x10], xmm13
0000714ce89d8a27  movq xmm13, xmm13
0000714ce89d8a2c  movaps [r15+0x130], xmm13
0000714ce89d8a34  movq xmm12, xmm12
0000714ce89d8a39  vmovaps [rsp+0x20], xmm12
0000714ce89d8a3f  movq xmm12, xmm12
0000714ce89d8a44  movaps [r15+0x280], xmm12
0000714ce89d8a4c  movaps xmm13, [r15+0x270]
0000714ce89d8a54  vmovaps [rsp+0x30], xmm13
0000714ce89d8a5a  vmovaps xmm12, [rsp+0x30]
0000714ce89d8a60  por xmm13, xmm12
0000714ce89d8a65  lea rax, [r12+0x20]
0000714ce89d8a6a  mov r11, [r13+rax*1]
0000714ce89d8a6f  lea rax, [r12+0x28]
0000714ce89d8a74  mov r10, [r13+rax*1]
0000714ce89d8a79  movq xmm12, r11
0000714ce89d8a7e  movq xmm11, r10
0000714ce89d8a83  movq xmm12, xmm12
0000714ce89d8a88  vmovaps [rsp+0x30], xmm12
0000714ce89d8a8e  movq xmm12, xmm12
0000714ce89d8a93  movaps [r15+0x150], xmm12
0000714ce89d8a9b  movq xmm11, xmm11
0000714ce89d8aa0  vmovaps [rsp+0x40], xmm11
0000714ce89d8aa6  movq xmm11, xmm11
0000714ce89d8aab  movaps [r15+0x140], xmm11
0000714ce89d8ab3  lea rax, [r12+0x10]
0000714ce89d8ab8  mov r11, [r13+rax*1]
0000714ce89d8abd  lea rax, [r12+0x18]
0000714ce89d8ac2  mov r10, [r13+rax*1]
0000714ce89d8ac7  movq xmm12, r11
0000714ce89d8acc  movq xmm11, r10
0000714ce89d8ad1  movq xmm12, xmm12
0000714ce89d8ad6  vmovaps [rsp+0x50], xmm12
0000714ce89d8adc  movq xmm12, xmm12
0000714ce89d8ae1  movaps [r15+0x170], xmm12
0000714ce89d8ae9  movq xmm11, xmm11
0000714ce89d8aee  vmovaps [rsp+0x60], xmm11
0000714ce89d8af4  movq xmm11, xmm11
0000714ce89d8af9  movaps [r15+0x160], xmm11
0000714ce89d8b01  mov rax, [r13+r12*1]
0000714ce89d8b06  vmovq xmm12, rax
0000714ce89d8b0b  vpbroadcastq xmm12, xmm12
0000714ce89d8b10  lea rax, [r12+0x08]
0000714ce89d8b15  mov r12, [r13+rax*1]
0000714ce89d8b1a  movq xmm11, r12
0000714ce89d8b1f  movaps [r15+0x230], xmm11
0000714ce89d8b27  mov rax, [r15+0xF8]
0000714ce89d8b2e  lea r12, [rax+0x50]
0000714ce89d8b32  movups xmm11, [r13+r12*1]
0000714ce89d8b38  lea r12, [rax+0x60]
0000714ce89d8b3c  movups xmm10, [r13+r12*1]
0000714ce89d8b42  lea r12, [rax+0x30]
0000714ce89d8b46  movups xmm9, [r13+r12*1]
0000714ce89d8b4c  mov r12, [r15+0x50]
0000714ce89d8b50  lea r11, [r12+r14*1]
0000714ce89d8b54  mov [r15+0x60], r11
0000714ce89d8b58  lea r12, [r14+0x40]
0000714ce89d8b5c  mov [r15+0x58], r12
0000714ce89d8b60  movaps xmm8, xmm12
0000714ce89d8b64  mulpd xmm8, xmm15
0000714ce89d8b69  vcmppd xmm7, xmm8, xmm8, 0x03
0000714ce89d8b6f  ptest xmm7, xmm7
0000714ce89d8b74  jnz 0x0000714CE89D9997
0000714ce89d8b7a  movq xmm15, qword ptr [r15+0x230]
0000714ce89d8b83  vmovaps [rsp+0x70], xmm15
0000714ce89d8b89  vpermilpd xmm15, xmm15, 0x00
0000714ce89d8b8f  movaps xmm7, xmm9
0000714ce89d8b93  mulpd xmm7, xmm15
0000714ce89d8b98  vcmppd xmm6, xmm7, xmm7, 0x03
0000714ce89d8b9d  ptest xmm6, xmm6
0000714ce89d8ba2  jnz 0x0000714CE89D9ADB
0000714ce89d8ba8  vxorps xmm15, xmm15, xmm15
0000714ce89d8bad  vpbroadcastq xmm15, xmm15
0000714ce89d8bb2  movaps xmm9, xmm12
0000714ce89d8bb6  mulpd xmm9, xmm10
0000714ce89d8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
0000714ce89d8bc1  ptest xmm6, xmm6
0000714ce89d8bc6  jnz 0x0000714CE89D9C1D
0000714ce89d8bcc  movaps xmm10, xmm12
0000714ce89d8bd0  mulpd xmm10, xmm11
0000714ce89d8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
0000714ce89d8bdb  ptest xmm6, xmm6
0000714ce89d8be0  jnz 0x0000714CE89D9D61
0000714ce89d8be6  movaps xmm11, [r15+0x1F0]
0000714ce89d8bee  movaps xmm6, xmm12
0000714ce89d8bf2  mulpd xmm6, xmm11
0000714ce89d8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
0000714ce89d8bfc  ptest xmm5, xmm5
0000714ce89d8c01  jnz 0x0000714CE89D9EA5
0000714ce89d8c07  movaps xmm12, [r15+0x2A0]
0000714ce89d8c0f  vmovaps [rsp+0x80], xmm12
0000714ce89d8c18  vmovaps xmm11, [rsp+0x80]
0000714ce89d8c21  por xmm12, xmm11
0000714ce89d8c26  movaps xmm11, [r15+0x250]
0000714ce89d8c2e  vmovaps [rsp+0x80], xmm11
0000714ce89d8c37  vmovaps xmm5, [rsp+0x80]
0000714ce89d8c40  por xmm11, xmm5
0000714ce89d8c45  vmovaps xmm4, [rsp+0x70]
0000714ce89d8c4b  vpermilpd xmm4, xmm4, 0x00
0000714ce89d8c51  movaps xmm3, xmm5
0000714ce89d8c54  mulpd xmm3, xmm4
0000714ce89d8c58  vcmppd xmm2, xmm3, xmm3, 0x03
0000714ce89d8c5d  ptest xmm2, xmm2
0000714ce89d8c62  jnz 0x0000714CE89D9FE7
0000714ce89d8c68  mov [rsp+0x80], rax
0000714ce89d8c70  xor eax, eax
0000714ce89d8c72  mov r14d, 0x200
0000714ce89d8c78  cmp r12, r14
0000714ce89d8c7b  cmc
0000714ce89d8c7c  lahf
0000714ce89d8c7d  seto al
0000714ce89d8c80  mov [r15+0x108], eax
0000714ce89d8c87  movaps xmm5, xmm8
0000714ce89d8c8b  addpd xmm5, xmm15
0000714ce89d8c90  vcmppd xmm4, xmm5, xmm5, 0x03
0000714ce89d8c95  ptest xmm4, xmm4
0000714ce89d8c9a  jnz 0x0000714CE89DA127
0000714ce89d8ca0  movaps xmm8, [r15+0x1B0]
0000714ce89d8ca8  movaps xmm4, xmm9
0000714ce89d8cac  addpd xmm4, xmm8
0000714ce89d8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
0000714ce89d8cb6  ptest xmm2, xmm2
0000714ce89d8cbb  jnz 0x0000714CE89DA269
0000714ce89d8cc1  movaps xmm9, xmm10
0000714ce89d8cc5  addpd xmm9, xmm8
0000714ce89d8cca  vcmppd xmm2, xmm9, xmm9, 0x03
0000714ce89d8cd0  ptest xmm2, xmm2
0000714ce89d8cd5  jnz 0x0000714CE89DA3AB
0000714ce89d8cdb  movaps xmm10, [r15+0x2F0]
0000714ce89d8ce3  vmovaps [rsp+0x90], xmm10
0000714ce89d8cec  vmovaps xmm8, [rsp+0x90]
0000714ce89d8cf5  por xmm10, xmm8
0000714ce89d8cfa  movaps xmm8, [r15+0x2E0]
0000714ce89d8d02  vmovaps [rsp+0x90], xmm8
0000714ce89d8d0b  vmovaps xmm2, [rsp+0x90]
0000714ce89d8d14  por xmm8, xmm2
0000714ce89d8d19  movaps xmm2, [r15+0x2D0]
0000714ce89d8d21  vmovaps [rsp+0x90], xmm2
0000714ce89d8d2a  vmovaps [rsp+0xA0], xmm1
0000714ce89d8d33  vmovaps xmm1, [rsp+0x90]
0000714ce89d8d3c  por xmm2, xmm1
0000714ce89d8d40  movaps xmm1, [r15+0x200]
0000714ce89d8d48  vmovaps [rsp+0x90], xmm1
0000714ce89d8d51  vmovaps [rsp+0xB0], xmm15
0000714ce89d8d5a  vmovaps xmm15, [rsp+0x90]
0000714ce89d8d63  por xmm1, xmm15
0000714ce89d8d68  movaps xmm15, [r15+0x1C0]
0000714ce89d8d70  vmovaps [rsp+0x90], xmm15
0000714ce89d8d79  vmovaps [rsp+0xC0], xmm1
0000714ce89d8d82  vmovaps xmm1, [rsp+0x90]
0000714ce89d8d8b  por xmm15, xmm1
0000714ce89d8d90  movaps xmm1, [r15+0x190]
0000714ce89d8d98  vmovaps [rsp+0x90], xmm1
0000714ce89d8da1  vmovaps [rsp+0xD0], xmm15
0000714ce89d8daa  vmovaps xmm15, [rsp+0x90]
0000714ce89d8db3  por xmm1, xmm15
0000714ce89d8db8  movaps xmm15, [r15+0x300]
0000714ce89d8dc0  vmovaps [rsp+0x90], xmm15
0000714ce89d8dc9  vmovaps [rsp+0xE0], xmm1
0000714ce89d8dd2  vmovaps xmm1, [rsp+0x90]
0000714ce89d8ddb  por xmm15, xmm1
0000714ce89d8de0  mov rax, [rsp+0x80]
0000714ce89d8de8  lea r14, [rax+0xA0]
0000714ce89d8def  movups xmm1, [r13+r14*1]
0000714ce89d8df5  lea r14, [rax+0xB0]
0000714ce89d8dfc  vmovaps [rsp+0x80], xmm1
0000714ce89d8e05  movups xmm1, [r13+r14*1]
0000714ce89d8e0b  vmovaps [rsp+0x90], xmm1
0000714ce89d8e14  vmovaps [rsp+0xF0], xmm15
0000714ce89d8e1d  vmovaps xmm15, [rsp+0xB0]
0000714ce89d8e26  vmovaps [rsp+0xB0], xmm14
0000714ce89d8e2f  movaps xmm1, xmm6
0000714ce89d8e32  addpd xmm1, xmm15
0000714ce89d8e37  vcmppd xmm14, xmm1, xmm1, 0x03
0000714ce89d8e3c  ptest xmm14, xmm14
0000714ce89d8e42  jnz 0x0000714CE89DA503
0000714ce89d8e48  lea r14, [rax+0xF0]
0000714ce89d8e4f  movups xmm15, [r13+r14*1]
0000714ce89d8e55  movaps xmm14, xmm4
0000714ce89d8e59  addpd xmm14, xmm3
0000714ce89d8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
0000714ce89d8e64  ptest xmm6, xmm6
0000714ce89d8e69  jnz 0x0000714CE89DA64E
0000714ce89d8e6f  movaps xmm6, xmm9
0000714ce89d8e73  addpd xmm6, xmm7
0000714ce89d8e77  vcmppd xmm4, xmm6, xmm6, 0x03
0000714ce89d8e7c  ptest xmm4, xmm4
0000714ce89d8e81  jnz 0x0000714CE89DA790
0000714ce89d8e87  vmovaps xmm9, [rsp+0x70]
0000714ce89d8e8d  vpermilpd xmm9, xmm9, 0x00
0000714ce89d8e93  vmovaps xmm4, [rsp+0x90]
0000714ce89d8e9c  movaps xmm7, xmm4
0000714ce89d8e9f  mulpd xmm7, xmm9
0000714ce89d8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
0000714ce89d8ea9  ptest xmm3, xmm3
0000714ce89d8eae  jnz 0x0000714CE89DA8D1
0000714ce89d8eb4  vmovaps xmm9, [rsp+0x50]
0000714ce89d8eba  vpermilpd xmm9, xmm9, 0x00
0000714ce89d8ec0  movaps xmm4, xmm15
0000714ce89d8ec4  mulpd xmm4, xmm9
0000714ce89d8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
0000714ce89d8ece  ptest xmm3, xmm3
0000714ce89d8ed3  jnz 0x0000714CE89DAA12
0000714ce89d8ed9  lea r14, [rax+0xE0]
0000714ce89d8ee0  movups xmm15, [r13+r14*1]
0000714ce89d8ee6  vmovaps xmm9, [rsp+0x70]
0000714ce89d8eec  vpermilpd xmm9, xmm9, 0x00
0000714ce89d8ef2  vmovaps [rsp+0x70], xmm1
0000714ce89d8ef8  vmovaps xmm1, [rsp+0x80]
0000714ce89d8f01  vmovaps [rsp+0x80], xmm15
0000714ce89d8f0a  movaps xmm3, xmm1
0000714ce89d8f0d  mulpd xmm3, xmm9
0000714ce89d8f12  vcmppd xmm15, xmm3, xmm3, 0x03
0000714ce89d8f17  ptest xmm15, xmm15
0000714ce89d8f1d  jnz 0x0000714CE89DAB5E
0000714ce89d8f23  vmovaps xmm1, [rsp+0xF0]
0000714ce89d8f2c  vmovaps xmm15, [rsp+0xF0]
0000714ce89d8f35  por xmm1, xmm15
0000714ce89d8f3a  movaps [r15+0x300], xmm1
0000714ce89d8f42  vmovaps xmm15, [rsp+0xE0]
0000714ce89d8f4b  vmovaps xmm9, [rsp+0xE0]
0000714ce89d8f54  por xmm15, xmm9
0000714ce89d8f59  movaps [r15+0x190], xmm15
0000714ce89d8f61  vmovaps xmm9, [rsp+0x50]
0000714ce89d8f67  vpermilpd xmm9, xmm9, 0x00
0000714ce89d8f6d  vmovaps [rsp+0x90], xmm1
0000714ce89d8f76  vmovaps [rsp+0xE0], xmm15
0000714ce89d8f7f  vmovaps xmm15, [rsp+0x80]
0000714ce89d8f88  vmovaps [rsp+0x80], xmm14
0000714ce89d8f91  movaps xmm1, xmm15
0000714ce89d8f95  mulpd xmm1, xmm9
0000714ce89d8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
0000714ce89d8f9f  ptest xmm14, xmm14
0000714ce89d8fa5  jnz 0x0000714CE89DAC9F
0000714ce89d8fab  lea r14, [rax+0x90]
0000714ce89d8fb2  movups xmm15, [r13+r14*1]
0000714ce89d8fb8  vmovaps xmm14, [rsp+0xD0]
0000714ce89d8fc1  vmovaps xmm9, [rsp+0xD0]
0000714ce89d8fca  por xmm14, xmm9
0000714ce89d8fcf  movaps [r15+0x1C0], xmm14
0000714ce89d8fd7  vmovaps xmm9, [rsp+0xC0]
0000714ce89d8fe0  vmovaps [rsp+0xD0], xmm1
0000714ce89d8fe9  vmovaps xmm1, [rsp+0xC0]
0000714ce89d8ff2  por xmm9, xmm1
0000714ce89d8ff7  movaps [r15+0x200], xmm9
0000714ce89d8fff  vmovaps [rsp+0xC0], xmm2
0000714ce89d9008  vmovaps xmm1, [rsp+0xC0]
0000714ce89d9011  por xmm2, xmm1
0000714ce89d9015  movaps [r15+0x2D0], xmm2
0000714ce89d901d  vmovaps [rsp+0xC0], xmm8
0000714ce89d9026  vmovaps xmm1, [rsp+0xC0]
0000714ce89d902f  por xmm8, xmm1
0000714ce89d9034  movaps [r15+0x2E0], xmm8
0000714ce89d903c  vmovaps [rsp+0xC0], xmm15
0000714ce89d9045  movaps xmm1, xmm5
0000714ce89d9048  addpd xmm1, xmm7
0000714ce89d904c  vcmppd xmm15, xmm1, xmm1, 0x03
0000714ce89d9051  ptest xmm15, xmm15
0000714ce89d9057  jnz 0x0000714CE89DADEB
0000714ce89d905d  vmovaps xmm15, [rsp+0x50]
0000714ce89d9063  vpermilpd xmm15, xmm15, 0x00
0000714ce89d9069  vmovaps xmm5, [rsp+0xC0]
0000714ce89d9072  vmovaps [rsp+0xC0], xmm1
0000714ce89d907b  movaps xmm7, xmm5
0000714ce89d907e  mulpd xmm7, xmm15
0000714ce89d9083  vcmppd xmm1, xmm7, xmm7, 0x03
0000714ce89d9088  ptest xmm1, xmm1
0000714ce89d908d  jnz 0x0000714CE89DAF2B
0000714ce89d9093  lea r14, [rax+0x80]
0000714ce89d909a  movups xmm1, [r13+r14*1]
0000714ce89d90a0  vmovaps xmm5, [rsp+0x70]
0000714ce89d90a6  vmovaps [rsp+0x70], xmm1
0000714ce89d90ac  movaps xmm15, xmm5
0000714ce89d90b0  addpd xmm15, xmm3
0000714ce89d90b5  vcmppd xmm1, xmm15, xmm15, 0x03
0000714ce89d90bb  ptest xmm1, xmm1
0000714ce89d90c0  jnz 0x0000714CE89DB076
0000714ce89d90c6  vmovaps xmm5, [rsp+0x80]
0000714ce89d90cf  movaps xmm1, xmm5
0000714ce89d90d2  addpd xmm1, xmm4
0000714ce89d90d6  vcmppd xmm3, xmm1, xmm1, 0x03
0000714ce89d90db  ptest xmm3, xmm3
0000714ce89d90e0  jnz 0x0000714CE89DB1B8
0000714ce89d90e6  vmovaps [rsp+0x80], xmm10
0000714ce89d90ef  vmovaps xmm5, [rsp+0x80]
0000714ce89d90f8  por xmm10, xmm5
0000714ce89d90fd  movaps [r15+0x2F0], xmm10
0000714ce89d9105  vmovaps xmm5, [rsp+0x50]
0000714ce89d910b  vpermilpd xmm5, xmm5, 0x00
0000714ce89d9111  vmovaps xmm3, [rsp+0x70]
0000714ce89d9117  vmovaps [rsp+0x50], xmm1
0000714ce89d911d  movaps xmm4, xmm3
0000714ce89d9120  mulpd xmm4, xmm5
0000714ce89d9124  vcmppd xmm1, xmm4, xmm4, 0x03
0000714ce89d9129  ptest xmm1, xmm1
0000714ce89d912e  jnz 0x0000714CE89DB2F8
0000714ce89d9134  lea r14, [rax+0xD0]
0000714ce89d913b  movups xmm1, [r13+r14*1]
0000714ce89d9141  vmovaps xmm3, [rsp+0xD0]
0000714ce89d914a  vmovaps [rsp+0x70], xmm1
0000714ce89d9150  movaps xmm5, xmm6
0000714ce89d9153  addpd xmm5, xmm3
0000714ce89d9157  vcmppd xmm1, xmm5, xmm5, 0x03
0000714ce89d915c  ptest xmm1, xmm1
0000714ce89d9161  jnz 0x0000714CE89DB442
0000714ce89d9167  vmovaps xmm1, [rsp+0x60]
0000714ce89d916d  vpermilpd xmm1, xmm1, 0x00
0000714ce89d9173  movaps xmm6, xmm9
0000714ce89d9177  mulpd xmm6, xmm1
0000714ce89d917b  vcmppd xmm3, xmm6, xmm6, 0x03
0000714ce89d9180  ptest xmm3, xmm3
0000714ce89d9185  jnz 0x0000714CE89DB582
0000714ce89d918b  movaps [r15+0x260], xmm6
0000714ce89d9193  vxorps xmm1, xmm1, xmm1
0000714ce89d9197  vpbroadcastq xmm1, xmm1
0000714ce89d919c  movaps [r15+0x1B0], xmm1
0000714ce89d91a4  vmovaps xmm1, [rsp+0x60]
0000714ce89d91aa  vpermilpd xmm1, xmm1, 0x00
0000714ce89d91b0  vmovaps xmm3, [rsp+0x70]
0000714ce89d91b6  vmovaps [rsp+0x70], xmm15
0000714ce89d91bc  movaps xmm9, xmm3
0000714ce89d91c0  mulpd xmm9, xmm1
0000714ce89d91c5  vcmppd xmm15, xmm9, xmm9, 0x03
0000714ce89d91cb  ptest xmm15, xmm15
0000714ce89d91d1  jnz 0x0000714CE89DB6C3
0000714ce89d91d7  lea r14, [rax+0xC0]
0000714ce89d91de  movups xmm1, [r13+r14*1]
0000714ce89d91e4  vmovaps xmm3, [rsp+0xC0]
0000714ce89d91ed  vmovaps [rsp+0x80], xmm1
0000714ce89d91f6  movaps xmm15, xmm3
0000714ce89d91fa  addpd xmm15, xmm7
0000714ce89d91ff  vcmppd xmm1, xmm15, xmm15, 0x03
0000714ce89d9205  ptest xmm1, xmm1
0000714ce89d920a  jnz 0x0000714CE89DB80F
0000714ce89d9210  vmovaps [rsp+0xC0], xmm13
0000714ce89d9219  vmovaps xmm1, [rsp+0xC0]
0000714ce89d9222  por xmm13, xmm1
0000714ce89d9227  movaps [r15+0x270], xmm13
0000714ce89d922f  vmovaps xmm1, [rsp+0xB0]
0000714ce89d9238  vmovaps xmm7, [rsp+0xB0]
0000714ce89d9241  por xmm1, xmm7
0000714ce89d9245  movaps [r15+0x1A0], xmm1
0000714ce89d924d  vmovaps xmm1, [rsp+0x60]
0000714ce89d9253  vpermilpd xmm1, xmm1, 0x00
0000714ce89d9259  vmovaps [rsp+0xB0], xmm1
0000714ce89d9262  vmovaps xmm1, [rsp+0x80]
0000714ce89d926b  vmovaps [rsp+0x80], xmm15
0000714ce89d9274  vmovaps xmm15, [rsp+0xB0]
0000714ce89d927d  vmovaps [rsp+0xB0], xmm14
0000714ce89d9286  movaps xmm3, xmm1
0000714ce89d9289  mulpd xmm3, xmm15
0000714ce89d928e  vcmppd xmm14, xmm3, xmm3, 0x03
0000714ce89d9293  ptest xmm14, xmm14
0000714ce89d9299  jnz 0x0000714CE89DB951
0000714ce89d929f  lea r14, [rax+0x20]
0000714ce89d92a3  movups xmm1, [r13+r14*1]
0000714ce89d92a9  movaps [r15+0x110], xmm1
0000714ce89d92b1  vmovaps xmm14, [rsp+0x70]
0000714ce89d92b7  vmovaps [rsp+0x70], xmm1
0000714ce89d92bd  movaps xmm15, xmm14
0000714ce89d92c1  addpd xmm15, xmm4
0000714ce89d92c6  vcmppd xmm1, xmm15, xmm15, 0x03
0000714ce89d92cc  ptest xmm1, xmm1
0000714ce89d92d1  jnz 0x0000714CE89DBA9C
0000714ce89d92d7  vmovaps xmm1, [rsp+0x60]
0000714ce89d92dd  vpermilpd xmm1, xmm1, 0x00
0000714ce89d92e3  movaps xmm14, xmm2
0000714ce89d92e7  mulpd xmm14, xmm1
0000714ce89d92ec  vcmppd xmm4, xmm14, xmm14, 0x03
0000714ce89d92f2  ptest xmm4, xmm4
0000714ce89d92f7  jnz 0x0000714CE89DBBDF
0000714ce89d92fd  vmovaps xmm4, [rsp+0x50]
0000714ce89d9303  movaps xmm1, xmm4
0000714ce89d9306  addpd xmm1, xmm9
0000714ce89d930b  vcmppd xmm2, xmm1, xmm1, 0x03
0000714ce89d9310  ptest xmm2, xmm2
0000714ce89d9315  jnz 0x0000714CE89DBD21
0000714ce89d931b  vmovaps xmm9, [rsp+0x30]
0000714ce89d9321  vpermilpd xmm9, xmm9, 0x00
0000714ce89d9327  vmovaps xmm2, [rsp+0x70]
0000714ce89d932d  vmovaps [rsp+0x50], xmm1
0000714ce89d9333  movaps xmm4, xmm2
0000714ce89d9336  mulpd xmm4, xmm9
0000714ce89d933b  vcmppd xmm1, xmm4, xmm4, 0x03
0000714ce89d9340  ptest xmm1, xmm1
0000714ce89d9345  jnz 0x0000714CE89DBE62
0000714ce89d934b  vmovaps xmm1, [rsp+0x30]
0000714ce89d9351  vpermilpd xmm1, xmm1, 0x00
0000714ce89d9357  vmovaps xmm2, [rsp+0x90]
0000714ce89d9360  vmovaps [rsp+0x60], xmm15
0000714ce89d9366  movaps xmm9, xmm2
0000714ce89d936a  mulpd xmm9, xmm1
0000714ce89d936f  vcmppd xmm15, xmm9, xmm9, 0x03
0000714ce89d9375  ptest xmm15, xmm15
0000714ce89d937b  jnz 0x0000714CE89DBFA3
0000714ce89d9381  vmovaps xmm15, [rsp+0x80]
0000714ce89d938a  movaps xmm1, xmm15
0000714ce89d938e  addpd xmm1, xmm6
0000714ce89d9392  vcmppd xmm2, xmm1, xmm1, 0x03
0000714ce89d9397  ptest xmm2, xmm2
0000714ce89d939c  jnz 0x0000714CE89DC0E5
0000714ce89d93a2  movaps xmm15, xmm5
0000714ce89d93a6  addpd xmm15, xmm3
0000714ce89d93ab  vcmppd xmm6, xmm15, xmm15, 0x03
0000714ce89d93b1  ptest xmm6, xmm6
0000714ce89d93b6  jnz 0x0000714CE89DC226
0000714ce89d93bc  vmovaps xmm6, [rsp+0x30]
0000714ce89d93c2  vpermilpd xmm6, xmm6, 0x00
0000714ce89d93c8  movaps xmm5, xmm8
0000714ce89d93cc  mulpd xmm5, xmm6
0000714ce89d93d0  vcmppd xmm3, xmm5, xmm5, 0x03
0000714ce89d93d5  ptest xmm3, xmm3
0000714ce89d93da  jnz 0x0000714CE89DC368
0000714ce89d93e0  vmovaps xmm8, [rsp+0x30]
0000714ce89d93e6  vpermilpd xmm8, xmm8, 0x00
0000714ce89d93ec  movaps xmm6, xmm10
0000714ce89d93f0  mulpd xmm6, xmm8
0000714ce89d93f5  vcmppd xmm3, xmm6, xmm6, 0x03
0000714ce89d93fa  ptest xmm3, xmm3
0000714ce89d93ff  jnz 0x0000714CE89DC4A9
0000714ce89d9405  vmovaps xmm8, [rsp+0x60]
0000714ce89d940b  movaps xmm10, xmm8
0000714ce89d940f  addpd xmm10, xmm14
0000714ce89d9414  vcmppd xmm3, xmm10, xmm10, 0x03
0000714ce89d941a  ptest xmm3, xmm3
0000714ce89d941f  jnz 0x0000714CE89DC5EB
0000714ce89d9425  vmovaps xmm8, [rsp+0x50]
0000714ce89d942b  movaps xmm14, xmm8
0000714ce89d942f  addpd xmm14, xmm4
0000714ce89d9434  vcmppd xmm3, xmm14, xmm14, 0x03
0000714ce89d943a  ptest xmm3, xmm3
0000714ce89d943f  jnz 0x0000714CE89DC72F
0000714ce89d9445  vmovaps xmm8, [rsp+0x40]
0000714ce89d944b  vpermilpd xmm8, xmm8, 0x00
0000714ce89d9451  movaps xmm4, xmm13
0000714ce89d9455  mulpd xmm4, xmm8
0000714ce89d945a  vcmppd xmm3, xmm4, xmm4, 0x03
0000714ce89d945f  ptest xmm3, xmm3
0000714ce89d9464  jnz 0x0000714CE89DC872
0000714ce89d946a  movaps xmm13, xmm15
0000714ce89d946e  addpd xmm13, xmm9
0000714ce89d9473  vcmppd xmm8, xmm13, xmm13, 0x03
0000714ce89d9479  ptest xmm8, xmm8
0000714ce89d947f  jnz 0x0000714CE89DC9B4
0000714ce89d9485  movaps xmm15, xmm1
0000714ce89d9489  addpd xmm15, xmm5
0000714ce89d948e  vcmppd xmm9, xmm15, xmm15, 0x03
0000714ce89d9494  ptest xmm9, xmm9
0000714ce89d949a  jnz 0x0000714CE89DCAF8
0000714ce89d94a0  vmovaps [rsp+0x30], xmm11
0000714ce89d94a6  vmovaps xmm1, [rsp+0x30]
0000714ce89d94ac  por xmm11, xmm1
0000714ce89d94b1  movaps [r15+0x250], xmm11
0000714ce89d94b9  vmovaps [rsp+0x30], xmm12
0000714ce89d94bf  vmovaps xmm1, [rsp+0x30]
0000714ce89d94c5  por xmm12, xmm1
0000714ce89d94ca  movaps [r15+0x2A0], xmm12
0000714ce89d94d2  vmovaps xmm1, [rsp+0xA0]
0000714ce89d94db  vmovaps xmm11, [rsp+0xA0]
0000714ce89d94e4  por xmm1, xmm11
0000714ce89d94e9  movaps [r15+0x1D0], xmm1
0000714ce89d94f1  lea r14, [rax+0x40]
0000714ce89d94f5  movups xmm1, [r13+r14*1]
0000714ce89d94fb  movaps [r15+0x2C0], xmm1
0000714ce89d9503  vmovaps xmm11, [rsp+0x40]
0000714ce89d9509  vpermilpd xmm11, xmm11, 0x00
0000714ce89d950f  vmovaps xmm8, [rsp+0xE0]
0000714ce89d9518  movaps xmm9, xmm8
0000714ce89d951c  mulpd xmm9, xmm11
0000714ce89d9521  vcmppd xmm5, xmm9, xmm9, 0x03
0000714ce89d9527  ptest xmm5, xmm5
0000714ce89d952c  jnz 0x0000714CE89DCC44
0000714ce89d9532  movaps xmm11, xmm10
0000714ce89d9536  addpd xmm11, xmm6
0000714ce89d953b  vcmppd xmm8, xmm11, xmm11, 0x03
0000714ce89d9541  ptest xmm8, xmm8
0000714ce89d9547  jnz 0x0000714CE89DCD88
0000714ce89d954d  movaps xmm10, xmm14
0000714ce89d9551  addpd xmm10, xmm4
0000714ce89d9556  vcmppd xmm8, xmm10, xmm10, 0x03
0000714ce89d955c  ptest xmm8, xmm8
0000714ce89d9562  jnz 0x0000714CE89DCECB
0000714ce89d9568  vmovaps xmm14, [rsp+0x40]
0000714ce89d956e  vpermilpd xmm14, xmm14, 0x00
0000714ce89d9574  movaps xmm8, xmm1
0000714ce89d9578  mulpd xmm8, xmm14
0000714ce89d957d  vcmppd xmm6, xmm8, xmm8, 0x03
0000714ce89d9583  ptest xmm6, xmm6
0000714ce89d9588  jnz 0x0000714CE89DD00E
0000714ce89d958e  movaps xmm1, [r15+0x2B0]
0000714ce89d9596  vmovaps xmm14, [rsp+0x40]
0000714ce89d959c  vpermilpd xmm14, xmm14, 0x00
0000714ce89d95a2  movaps xmm6, xmm1
0000714ce89d95a5  mulpd xmm6, xmm14
0000714ce89d95aa  vcmppd xmm5, xmm6, xmm6, 0x03
0000714ce89d95af  ptest xmm5, xmm5
0000714ce89d95b4  jnz 0x0000714CE89DD151
0000714ce89d95ba  vmovaps xmm1, [rsp+0x10]
0000714ce89d95c0  vpermilpd xmm1, xmm1, 0x00
0000714ce89d95c6  movaps xmm14, xmm12
0000714ce89d95ca  mulpd xmm14, xmm1
0000714ce89d95cf  vcmppd xmm5, xmm14, xmm14, 0x03
0000714ce89d95d5  ptest xmm5, xmm5
0000714ce89d95da  jnz 0x0000714CE89DD292
0000714ce89d95e0  movaps xmm1, xmm13
0000714ce89d95e4  addpd xmm1, xmm9
0000714ce89d95e9  vcmppd xmm12, xmm1, xmm1, 0x03
0000714ce89d95ee  ptest xmm12, xmm12
0000714ce89d95f4  jnz 0x0000714CE89DD3D5
0000714ce89d95fa  vmovaps xmm13, [rsp+0x10]
0000714ce89d9600  vpermilpd xmm13, xmm13, 0x00
0000714ce89d9606  movaps xmm12, xmm7
0000714ce89d960a  mulpd xmm12, xmm13
0000714ce89d960f  vcmppd xmm9, xmm12, xmm12, 0x03
0000714ce89d9615  ptest xmm9, xmm9
0000714ce89d961b  jnz 0x0000714CE89DD517
0000714ce89d9621  movaps xmm13, xmm15
0000714ce89d9625  addpd xmm13, xmm8
0000714ce89d962a  vcmppd xmm9, xmm13, xmm13, 0x03
0000714ce89d9630  ptest xmm9, xmm9
0000714ce89d9636  jnz 0x0000714CE89DD65A
0000714ce89d963c  movaps xmm15, [r15+0x290]
0000714ce89d9644  vmovaps xmm9, [rsp+0x10]
0000714ce89d964a  vpermilpd xmm9, xmm9, 0x00
0000714ce89d9650  movaps xmm8, xmm15
0000714ce89d9654  mulpd xmm8, xmm9
0000714ce89d9659  vcmppd xmm7, xmm8, xmm8, 0x03
0000714ce89d965f  ptest xmm7, xmm7
0000714ce89d9664  jnz 0x0000714CE89DD79E
0000714ce89d966a  movaps xmm15, xmm11
0000714ce89d966e  addpd xmm15, xmm6
0000714ce89d9673  vcmppd xmm9, xmm15, xmm15, 0x03
0000714ce89d9679  ptest xmm9, xmm9
0000714ce89d967f  jnz 0x0000714CE89DD8E2
0000714ce89d9685  movaps xmm11, [r15+0x1E0]
0000714ce89d968d  vmovaps xmm9, [rsp+0x10]
0000714ce89d9693  vpermilpd xmm9, xmm9, 0x00
0000714ce89d9699  movaps xmm7, xmm11
0000714ce89d969d  mulpd xmm7, xmm9
0000714ce89d96a2  vcmppd xmm6, xmm7, xmm7, 0x03
0000714ce89d96a7  ptest xmm6, xmm6
0000714ce89d96ac  jnz 0x0000714CE89DDA25
0000714ce89d96b2  movaps xmm11, xmm10
0000714ce89d96b6  addpd xmm11, xmm14
0000714ce89d96bb  vcmppd xmm9, xmm11, xmm11, 0x03
0000714ce89d96c1  ptest xmm9, xmm9
0000714ce89d96c7  jnz 0x0000714CE89DDB67
0000714ce89d96cd  lea r14, [rax+0x70]
0000714ce89d96d1  movups xmm14, [r13+r14*1]
0000714ce89d96d7  movaps [r15+0x240], xmm14
0000714ce89d96df  movaps xmm10, xmm1
0000714ce89d96e3  addpd xmm10, xmm12
0000714ce89d96e8  vcmppd xmm9, xmm10, xmm10, 0x03
0000714ce89d96ee  ptest xmm9, xmm9
0000714ce89d96f4  jnz 0x0000714CE89DDCB5
0000714ce89d96fa  movaps [r15+0x170], xmm10
0000714ce89d9702  vmovaps xmm1, [rsp+0x20]
0000714ce89d9708  vpermilpd xmm1, xmm1, 0x00
0000714ce89d970e  movaps xmm12, xmm14
0000714ce89d9712  mulpd xmm12, xmm1
0000714ce89d9717  vcmppd xmm9, xmm12, xmm12, 0x03
0000714ce89d971d  ptest xmm9, xmm9
0000714ce89d9723  jnz 0x0000714CE89DDDF8
0000714ce89d9729  vmovaps xmm1, [rsp+0x20]
0000714ce89d972f  vpermilpd xmm1, xmm1, 0x00
0000714ce89d9735  vmovaps xmm9, [rsp+0xB0]
0000714ce89d973e  movaps xmm14, xmm9
0000714ce89d9742  mulpd xmm14, xmm1
0000714ce89d9747  vcmppd xmm6, xmm14, xmm14, 0x03
0000714ce89d974d  ptest xmm6, xmm6
0000714ce89d9752  jnz 0x0000714CE89DDF3B
0000714ce89d9758  movaps [r15+0x180], xmm14
0000714ce89d9760  movaps xmm1, xmm13
0000714ce89d9764  addpd xmm1, xmm8
0000714ce89d9769  vcmppd xmm9, xmm1, xmm1, 0x03
0000714ce89d976e  ptest xmm9, xmm9
0000714ce89d9774  jnz 0x0000714CE89DE07E
0000714ce89d977a  movaps [r15+0x210], xmm1
0000714ce89d9782  movups xmm13, [r13+rax*1]
0000714ce89d9788  lea r14, [rax+0x10]
0000714ce89d978c  movups xmm9, [r13+r14*1]
0000714ce89d9792  movaps [r15+0x230], xmm9
0000714ce89d979a  movaps xmm8, xmm15
0000714ce89d979e  addpd xmm8, xmm7
0000714ce89d97a3  vcmppd xmm6, xmm8, xmm8, 0x03
0000714ce89d97a9  ptest xmm6, xmm6
0000714ce89d97ae  jnz 0x0000714CE89DE1D4
0000714ce89d97b4  movaps [r15+0x130], xmm8
0000714ce89d97bc  vmovaps xmm15, [rsp+0x20]
0000714ce89d97c2  vpermilpd xmm15, xmm15, 0x00
0000714ce89d97c8  movaps xmm7, xmm9
0000714ce89d97cc  mulpd xmm7, xmm15
0000714ce89d97d1  vcmppd xmm6, xmm7, xmm7, 0x03
0000714ce89d97d6  ptest xmm6, xmm6
0000714ce89d97db  jnz 0x0000714CE89DE317
0000714ce89d97e1  movaps [r15+0x220], xmm7
0000714ce89d97e9  vmovaps xmm15, [rsp+0x20]
0000714ce89d97ef  vpermilpd xmm15, xmm15, 0x00
0000714ce89d97f5  movaps xmm9, xmm13
0000714ce89d97f9  mulpd xmm9, xmm15
0000714ce89d97fe  vcmppd xmm6, xmm9, xmm9, 0x03
0000714ce89d9804  ptest xmm6, xmm6
0000714ce89d9809  jnz 0x0000714CE89DE459
0000714ce89d980f  movaps xmm15, xmm11
0000714ce89d9813  addpd xmm15, xmm12
0000714ce89d9818  vcmppd xmm13, xmm15, xmm15, 0x03
0000714ce89d981e  ptest xmm13, xmm13
0000714ce89d9824  jnz 0x0000714CE89DE59D
0000714ce89d982a  movaps [r15+0x140], xmm15
0000714ce89d9832  movaps xmm13, xmm10
0000714ce89d9836  addpd xmm13, xmm14
0000714ce89d983b  vcmppd xmm12, xmm13, xmm13, 0x03
0000714ce89d9841  ptest xmm12, xmm12
0000714ce89d9847  jnz 0x0000714CE89DE6E1
0000714ce89d984d  movaps [r15+0x150], xmm13
0000714ce89d9855  movaps xmm14, xmm1
0000714ce89d9859  addpd xmm14, xmm7
0000714ce89d985e  vcmppd xmm12, xmm14, xmm14, 0x03
0000714ce89d9864  ptest xmm12, xmm12
0000714ce89d986a  jnz 0x0000714CE89DE825
0000714ce89d9870  movaps [r15+0x160], xmm14
0000714ce89d9878  movaps xmm1, xmm8
0000714ce89d987c  addpd xmm1, xmm9
0000714ce89d9881  vcmppd xmm12, xmm1, xmm1, 0x03
0000714ce89d9886  ptest xmm12, xmm12
0000714ce89d988c  jnz 0x0000714CE89DE967
0000714ce89d9892  movaps [r15+0x120], xmm1
0000714ce89d989a  movups [r13+r11*1], xmm15
0000714ce89d98a0  lea rax, [r11+0x10]
0000714ce89d98a4  movups [r13+rax*1], xmm13
0000714ce89d98aa  lea rax, [r11+0x20]
0000714ce89d98ae  movups [r13+rax*1], xmm14
0000714ce89d98b4  lea rax, [r11+0x30]
0000714ce89d98b8  movups [r13+rax*1], xmm1
0000714ce89d98be  mov eax, [r15+0x108]
0000714ce89d98c5  sahf
0000714ce89d98c6  jnz 0x0000714CE89D98F8
0000714ce89d98c8  cmp dword ptr [r15+0x318], 0x00
0000714ce89d98d0  jz 0x0000714CE89DEAE0
0000714ce89d98d6  nop [rax+rax*1], ax
0000714ce89d98df  nop [rax+rax*1], eax
0000714ce89d98e7  mov eax, 0x4106D0
0000714ce89d98ec  mov [r15+0x100], rax
0000714ce89d98f3  jmp 0x0000714CE87FE110
0000714ce89d98f8  cmp dword ptr [r15+0x318], 0x00
0000714ce89d9900  jz 0x0000714CE89D89C0
0000714ce89d9906  nop [rax+rax*1], ax
0000714ce89d990f  nop [rax+rax*1], eax
0000714ce89d9917  mov eax, 0x410504
0000714ce89d991c  mov [r15+0x100], rax
0000714ce89d9923  jmp 0x0000714CE87FE110
0000714ce89d9928  int3
0000714ce89d9929  call 0x0000714CE880A4B0
0000714ce89d992e  jmp 0x0000714CE89D8A08
0000714ce89d9933  call 0x0000714CE8809240
0000714ce89d9938  jmp 0x0000714CE89D8A12
0000714ce89d993d  call 0x0000714CE880A4B0
0000714ce89d9942  jmp 0x0000714CE89D8A6F
0000714ce89d9947  call 0x0000714CE8809240
0000714ce89d994c  jmp 0x0000714CE89D8A79
0000714ce89d9951  call 0x0000714CE880A4B0
0000714ce89d9956  jmp 0x0000714CE89D8ABD
0000714ce89d995b  call 0x0000714CE8809240
0000714ce89d9960  jmp 0x0000714CE89D8AC7
0000714ce89d9965  call 0x0000714CE88B47C0
0000714ce89d996a  jmp 0x0000714CE89D8B06
0000714ce89d996f  call 0x0000714CE880B720
0000714ce89d9974  jmp 0x0000714CE89D8B1A
0000714ce89d9979  call 0x0000714CE88BFC30
0000714ce89d997e  jmp 0x0000714CE89D8B38
0000714ce89d9983  call 0x0000714CE88BE9C0
0000714ce89d9988  jmp 0x0000714CE89D8B42
0000714ce89d998d  call 0x0000714CE88BD750
0000714ce89d9992  jmp 0x0000714CE89D8B4C
0000714ce89d9997  sub rsp, 0x08
0000714ce89d999b  push rax
0000714ce89d999c  push rcx
0000714ce89d999d  push rdx
0000714ce89d999e  push rdi
0000714ce89d999f  push rsi
0000714ce89d99a0  push r8
0000714ce89d99a2  push r9
0000714ce89d99a4  push r10
0000714ce89d99a6  push r11
0000714ce89d99a8  sub rsp, 0xF0
0000714ce89d99af  vmovaps [rsp], xmm0
0000714ce89d99b4  vmovaps [rsp+0x10], xmm1
0000714ce89d99ba  vmovaps [rsp+0x20], xmm2
0000714ce89d99c0  vmovaps [rsp+0x30], xmm3
0000714ce89d99c6  vmovaps [rsp+0x40], xmm4
0000714ce89d99cc  vmovaps [rsp+0x50], xmm5
0000714ce89d99d2  vmovaps [rsp+0x60], xmm6
0000714ce89d99d8  vmovaps [rsp+0x70], xmm7
0000714ce89d99de  vmovaps [rsp+0x80], xmm9
0000714ce89d99e7  vmovaps [rsp+0x90], xmm10
0000714ce89d99f0  vmovaps [rsp+0xA0], xmm11
0000714ce89d99f9  vmovaps [rsp+0xB0], xmm12
0000714ce89d9a02  vmovaps [rsp+0xC0], xmm13
0000714ce89d9a0b  vmovaps [rsp+0xD0], xmm14
0000714ce89d9a14  vmovaps [rsp+0xE0], xmm15
0000714ce89d9a1d  sub rsp, 0x30
0000714ce89d9a21  movaps [rsp], xmm8
0000714ce89d9a26  movaps [rsp+0x10], xmm12
0000714ce89d9a2c  movaps [rsp+0x20], xmm15
0000714ce89d9a32  lea rdi, [rsp]
0000714ce89d9a36  mov esi, 0x00
0000714ce89d9a3b  mov rax, 0x57A55D340530
0000714ce89d9a45  call rax
0000714ce89d9a47  movaps xmm8, [rsp]
0000714ce89d9a4c  add rsp, 0x30
0000714ce89d9a50  vmovaps xmm0, [rsp]
0000714ce89d9a55  vmovaps xmm1, [rsp+0x10]
0000714ce89d9a5b  vmovaps xmm2, [rsp+0x20]
0000714ce89d9a61  vmovaps xmm3, [rsp+0x30]
0000714ce89d9a67  vmovaps xmm4, [rsp+0x40]
0000714ce89d9a6d  vmovaps xmm5, [rsp+0x50]
0000714ce89d9a73  vmovaps xmm6, [rsp+0x60]
0000714ce89d9a79  vmovaps xmm7, [rsp+0x70]
0000714ce89d9a7f  vmovaps xmm9, [rsp+0x80]
0000714ce89d9a88  vmovaps xmm10, [rsp+0x90]
0000714ce89d9a91  vmovaps xmm11, [rsp+0xA0]
0000714ce89d9a9a  vmovaps xmm12, [rsp+0xB0]
0000714ce89d9aa3  vmovaps xmm13, [rsp+0xC0]
0000714ce89d9aac  vmovaps xmm14, [rsp+0xD0]
0000714ce89d9ab5  vmovaps xmm15, [rsp+0xE0]
0000714ce89d9abe  add rsp, 0xF0
0000714ce89d9ac5  pop r11
0000714ce89d9ac7  pop r10
0000714ce89d9ac9  pop r9
0000714ce89d9acb  pop r8
0000714ce89d9acd  pop rsi
0000714ce89d9ace  pop rdi
0000714ce89d9acf  pop rdx
0000714ce89d9ad0  pop rcx
0000714ce89d9ad1  pop rax
0000714ce89d9ad2  add rsp, 0x08
0000714ce89d9ad6  jmp 0x0000714CE89D8B7A
0000714ce89d9adb  sub rsp, 0x08
0000714ce89d9adf  push rax
0000714ce89d9ae0  push rcx
0000714ce89d9ae1  push rdx
0000714ce89d9ae2  push rdi
0000714ce89d9ae3  push rsi
0000714ce89d9ae4  push r8
0000714ce89d9ae6  push r9
0000714ce89d9ae8  push r10
0000714ce89d9aea  push r11
0000714ce89d9aec  sub rsp, 0xF0
0000714ce89d9af3  vmovaps [rsp], xmm0
0000714ce89d9af8  vmovaps [rsp+0x10], xmm1
0000714ce89d9afe  vmovaps [rsp+0x20], xmm2
0000714ce89d9b04  vmovaps [rsp+0x30], xmm3
0000714ce89d9b0a  vmovaps [rsp+0x40], xmm4
0000714ce89d9b10  vmovaps [rsp+0x50], xmm5
0000714ce89d9b16  vmovaps [rsp+0x60], xmm6
0000714ce89d9b1c  vmovaps [rsp+0x70], xmm8
0000714ce89d9b22  vmovaps [rsp+0x80], xmm9
0000714ce89d9b2b  vmovaps [rsp+0x90], xmm10
0000714ce89d9b34  vmovaps [rsp+0xA0], xmm11
0000714ce89d9b3d  vmovaps [rsp+0xB0], xmm12
0000714ce89d9b46  vmovaps [rsp+0xC0], xmm13
0000714ce89d9b4f  vmovaps [rsp+0xD0], xmm14
0000714ce89d9b58  vmovaps [rsp+0xE0], xmm15
0000714ce89d9b61  sub rsp, 0x30
0000714ce89d9b65  movaps [rsp], xmm7
0000714ce89d9b69  movaps [rsp+0x10], xmm9
0000714ce89d9b6f  movaps [rsp+0x20], xmm15
0000714ce89d9b75  lea rdi, [rsp]
0000714ce89d9b79  mov esi, 0x00
0000714ce89d9b7e  mov rax, 0x57A55D340530
0000714ce89d9b88  call rax
0000714ce89d9b8a  movaps xmm7, [rsp]
0000714ce89d9b8e  add rsp, 0x30
0000714ce89d9b92  vmovaps xmm0, [rsp]
0000714ce89d9b97  vmovaps xmm1, [rsp+0x10]
0000714ce89d9b9d  vmovaps xmm2, [rsp+0x20]
0000714ce89d9ba3  vmovaps xmm3, [rsp+0x30]
0000714ce89d9ba9  vmovaps xmm4, [rsp+0x40]
0000714ce89d9baf  vmovaps xmm5, [rsp+0x50]
0000714ce89d9bb5  vmovaps xmm6, [rsp+0x60]
0000714ce89d9bbb  vmovaps xmm8, [rsp+0x70]
0000714ce89d9bc1  vmovaps xmm9, [rsp+0x80]
0000714ce89d9bca  vmovaps xmm10, [rsp+0x90]
0000714ce89d9bd3  vmovaps xmm11, [rsp+0xA0]
0000714ce89d9bdc  vmovaps xmm12, [rsp+0xB0]
0000714ce89d9be5  vmovaps xmm13, [rsp+0xC0]
0000714ce89d9bee  vmovaps xmm14, [rsp+0xD0]
0000714ce89d9bf7  vmovaps xmm15, [rsp+0xE0]
0000714ce89d9c00  add rsp, 0xF0
0000714ce89d9c07  pop r11
0000714ce89d9c09  pop r10
0000714ce89d9c0b  pop r9
0000714ce89d9c0d  pop r8
0000714ce89d9c0f  pop rsi
0000714ce89d9c10  pop rdi
0000714ce89d9c11  pop rdx
0000714ce89d9c12  pop rcx
0000714ce89d9c13  pop rax
0000714ce89d9c14  add rsp, 0x08
0000714ce89d9c18  jmp 0x0000714CE89D8BA8
0000714ce89d9c1d  sub rsp, 0x08
0000714ce89d9c21  push rax
0000714ce89d9c22  push rcx
0000714ce89d9c23  push rdx
0000714ce89d9c24  push rdi
0000714ce89d9c25  push rsi
0000714ce89d9c26  push r8
0000714ce89d9c28  push r9
0000714ce89d9c2a  push r10
0000714ce89d9c2c  push r11
0000714ce89d9c2e  sub rsp, 0xF0
0000714ce89d9c35  vmovaps [rsp], xmm0
0000714ce89d9c3a  vmovaps [rsp+0x10], xmm1
0000714ce89d9c40  vmovaps [rsp+0x20], xmm2
0000714ce89d9c46  vmovaps [rsp+0x30], xmm3
0000714ce89d9c4c  vmovaps [rsp+0x40], xmm4
0000714ce89d9c52  vmovaps [rsp+0x50], xmm5
0000714ce89d9c58  vmovaps [rsp+0x60], xmm6
0000714ce89d9c5e  vmovaps [rsp+0x70], xmm7
0000714ce89d9c64  vmovaps [rsp+0x80], xmm8
0000714ce89d9c6d  vmovaps [rsp+0x90], xmm10
0000714ce89d9c76  vmovaps [rsp+0xA0], xmm11
0000714ce89d9c7f  vmovaps [rsp+0xB0], xmm12
0000714ce89d9c88  vmovaps [rsp+0xC0], xmm13
0000714ce89d9c91  vmovaps [rsp+0xD0], xmm14
0000714ce89d9c9a  vmovaps [rsp+0xE0], xmm15
0000714ce89d9ca3  sub rsp, 0x30
0000714ce89d9ca7  movaps [rsp], xmm9
0000714ce89d9cac  movaps [rsp+0x10], xmm12
0000714ce89d9cb2  movaps [rsp+0x20], xmm10
0000714ce89d9cb8  lea rdi, [rsp]
0000714ce89d9cbc  mov esi, 0x00
0000714ce89d9cc1  mov rax, 0x57A55D340530
0000714ce89d9ccb  call rax
0000714ce89d9ccd  movaps xmm9, [rsp]
0000714ce89d9cd2  add rsp, 0x30
0000714ce89d9cd6  vmovaps xmm0, [rsp]
0000714ce89d9cdb  vmovaps xmm1, [rsp+0x10]
0000714ce89d9ce1  vmovaps xmm2, [rsp+0x20]
0000714ce89d9ce7  vmovaps xmm3, [rsp+0x30]
0000714ce89d9ced  vmovaps xmm4, [rsp+0x40]
0000714ce89d9cf3  vmovaps xmm5, [rsp+0x50]
0000714ce89d9cf9  vmovaps xmm6, [rsp+0x60]
0000714ce89d9cff  vmovaps xmm7, [rsp+0x70]
0000714ce89d9d05  vmovaps xmm8, [rsp+0x80]
0000714ce89d9d0e  vmovaps xmm10, [rsp+0x90]
0000714ce89d9d17  vmovaps xmm11, [rsp+0xA0]
0000714ce89d9d20  vmovaps xmm12, [rsp+0xB0]
0000714ce89d9d29  vmovaps xmm13, [rsp+0xC0]
0000714ce89d9d32  vmovaps xmm14, [rsp+0xD0]
0000714ce89d9d3b  vmovaps xmm15, [rsp+0xE0]
0000714ce89d9d44  add rsp, 0xF0
0000714ce89d9d4b  pop r11
0000714ce89d9d4d  pop r10
0000714ce89d9d4f  pop r9
0000714ce89d9d51  pop r8
0000714ce89d9d53  pop rsi
0000714ce89d9d54  pop rdi
0000714ce89d9d55  pop rdx
0000714ce89d9d56  pop rcx
0000714ce89d9d57  pop rax
0000714ce89d9d58  add rsp, 0x08
0000714ce89d9d5c  jmp 0x0000714CE89D8BCC
0000714ce89d9d61  sub rsp, 0x08
0000714ce89d9d65  push rax
0000714ce89d9d66  push rcx
0000714ce89d9d67  push rdx
0000714ce89d9d68  push rdi
0000714ce89d9d69  push rsi
0000714ce89d9d6a  push r8
0000714ce89d9d6c  push r9
0000714ce89d9d6e  push r10
0000714ce89d9d70  push r11
0000714ce89d9d72  sub rsp, 0xF0
0000714ce89d9d79  vmovaps [rsp], xmm0
0000714ce89d9d7e  vmovaps [rsp+0x10], xmm1
0000714ce89d9d84  vmovaps [rsp+0x20], xmm2
0000714ce89d9d8a  vmovaps [rsp+0x30], xmm3
0000714ce89d9d90  vmovaps [rsp+0x40], xmm4
0000714ce89d9d96  vmovaps [rsp+0x50], xmm5
0000714ce89d9d9c  vmovaps [rsp+0x60], xmm6
0000714ce89d9da2  vmovaps [rsp+0x70], xmm7
0000714ce89d9da8  vmovaps [rsp+0x80], xmm8
0000714ce89d9db1  vmovaps [rsp+0x90], xmm9
0000714ce89d9dba  vmovaps [rsp+0xA0], xmm11
0000714ce89d9dc3  vmovaps [rsp+0xB0], xmm12
0000714ce89d9dcc  vmovaps [rsp+0xC0], xmm13
0000714ce89d9dd5  vmovaps [rsp+0xD0], xmm14
0000714ce89d9dde  vmovaps [rsp+0xE0], xmm15
0000714ce89d9de7  sub rsp, 0x30
0000714ce89d9deb  movaps [rsp], xmm10
0000714ce89d9df0  movaps [rsp+0x10], xmm12
0000714ce89d9df6  movaps [rsp+0x20], xmm11
0000714ce89d9dfc  lea rdi, [rsp]
0000714ce89d9e00  mov esi, 0x00
0000714ce89d9e05  mov rax, 0x57A55D340530
0000714ce89d9e0f  call rax
0000714ce89d9e11  movaps xmm10, [rsp]
0000714ce89d9e16  add rsp, 0x30
0000714ce89d9e1a  vmovaps xmm0, [rsp]
0000714ce89d9e1f  vmovaps xmm1, [rsp+0x10]
0000714ce89d9e25  vmovaps xmm2, [rsp+0x20]
0000714ce89d9e2b  vmovaps xmm3, [rsp+0x30]
0000714ce89d9e31  vmovaps xmm4, [rsp+0x40]
0000714ce89d9e37  vmovaps xmm5, [rsp+0x50]
0000714ce89d9e3d  vmovaps xmm6, [rsp+0x60]
0000714ce89d9e43  vmovaps xmm7, [rsp+0x70]
0000714ce89d9e49  vmovaps xmm8, [rsp+0x80]
0000714ce89d9e52  vmovaps xmm9, [rsp+0x90]
0000714ce89d9e5b  vmovaps xmm11, [rsp+0xA0]
0000714ce89d9e64  vmovaps xmm12, [rsp+0xB0]
0000714ce89d9e6d  vmovaps xmm13, [rsp+0xC0]
0000714ce89d9e76  vmovaps xmm14, [rsp+0xD0]
0000714ce89d9e7f  vmovaps xmm15, [rsp+0xE0]
0000714ce89d9e88  add rsp, 0xF0
0000714ce89d9e8f  pop r11
0000714ce89d9e91  pop r10
0000714ce89d9e93  pop r9
0000714ce89d9e95  pop r8
0000714ce89d9e97  pop rsi
0000714ce89d9e98  pop rdi
0000714ce89d9e99  pop rdx
0000714ce89d9e9a  pop rcx
0000714ce89d9e9b  pop rax
0000714ce89d9e9c  add rsp, 0x08
0000714ce89d9ea0  jmp 0x0000714CE89D8BE6
0000714ce89d9ea5  sub rsp, 0x08
0000714ce89d9ea9  push rax
0000714ce89d9eaa  push rcx
0000714ce89d9eab  push rdx
0000714ce89d9eac  push rdi
0000714ce89d9ead  push rsi
0000714ce89d9eae  push r8
0000714ce89d9eb0  push r9
0000714ce89d9eb2  push r10
0000714ce89d9eb4  push r11
0000714ce89d9eb6  sub rsp, 0xF0
0000714ce89d9ebd  vmovaps [rsp], xmm0
0000714ce89d9ec2  vmovaps [rsp+0x10], xmm1
0000714ce89d9ec8  vmovaps [rsp+0x20], xmm2
0000714ce89d9ece  vmovaps [rsp+0x30], xmm3
0000714ce89d9ed4  vmovaps [rsp+0x40], xmm4
0000714ce89d9eda  vmovaps [rsp+0x50], xmm5
0000714ce89d9ee0  vmovaps [rsp+0x60], xmm7
0000714ce89d9ee6  vmovaps [rsp+0x70], xmm8
0000714ce89d9eec  vmovaps [rsp+0x80], xmm9
0000714ce89d9ef5  vmovaps [rsp+0x90], xmm10
0000714ce89d9efe  vmovaps [rsp+0xA0], xmm11
0000714ce89d9f07  vmovaps [rsp+0xB0], xmm12
0000714ce89d9f10  vmovaps [rsp+0xC0], xmm13
0000714ce89d9f19  vmovaps [rsp+0xD0], xmm14
0000714ce89d9f22  vmovaps [rsp+0xE0], xmm15
0000714ce89d9f2b  sub rsp, 0x30
0000714ce89d9f2f  movaps [rsp], xmm6
0000714ce89d9f33  movaps [rsp+0x10], xmm12
0000714ce89d9f39  movaps [rsp+0x20], xmm11
0000714ce89d9f3f  lea rdi, [rsp]
0000714ce89d9f43  mov esi, 0x00
0000714ce89d9f48  mov rax, 0x57A55D340530
0000714ce89d9f52  call rax
0000714ce89d9f54  movaps xmm6, [rsp]
0000714ce89d9f58  add rsp, 0x30
0000714ce89d9f5c  vmovaps xmm0, [rsp]
0000714ce89d9f61  vmovaps xmm1, [rsp+0x10]
0000714ce89d9f67  vmovaps xmm2, [rsp+0x20]
0000714ce89d9f6d  vmovaps xmm3, [rsp+0x30]
0000714ce89d9f73  vmovaps xmm4, [rsp+0x40]
0000714ce89d9f79  vmovaps xmm5, [rsp+0x50]
0000714ce89d9f7f  vmovaps xmm7, [rsp+0x60]
0000714ce89d9f85  vmovaps xmm8, [rsp+0x70]
0000714ce89d9f8b  vmovaps xmm9, [rsp+0x80]
0000714ce89d9f94  vmovaps xmm10, [rsp+0x90]
0000714ce89d9f9d  vmovaps xmm11, [rsp+0xA0]
0000714ce89d9fa6  vmovaps xmm12, [rsp+0xB0]
0000714ce89d9faf  vmovaps xmm13, [rsp+0xC0]
0000714ce89d9fb8  vmovaps xmm14, [rsp+0xD0]
0000714ce89d9fc1  vmovaps xmm15, [rsp+0xE0]
0000714ce89d9fca  add rsp, 0xF0
0000714ce89d9fd1  pop r11
0000714ce89d9fd3  pop r10
0000714ce89d9fd5  pop r9
0000714ce89d9fd7  pop r8
0000714ce89d9fd9  pop rsi
0000714ce89d9fda  pop rdi
0000714ce89d9fdb  pop rdx
0000714ce89d9fdc  pop rcx
0000714ce89d9fdd  pop rax
0000714ce89d9fde  add rsp, 0x08
0000714ce89d9fe2  jmp 0x0000714CE89D8C07
0000714ce89d9fe7  sub rsp, 0x08
0000714ce89d9feb  push rax
0000714ce89d9fec  push rcx
0000714ce89d9fed  push rdx
0000714ce89d9fee  push rdi
0000714ce89d9fef  push rsi
0000714ce89d9ff0  push r8
0000714ce89d9ff2  push r9
0000714ce89d9ff4  push r10
0000714ce89d9ff6  push r11
0000714ce89d9ff8  sub rsp, 0xF0
0000714ce89d9fff  vmovaps [rsp], xmm0
0000714ce89da004  vmovaps [rsp+0x10], xmm1
0000714ce89da00a  vmovaps [rsp+0x20], xmm2
0000714ce89da010  vmovaps [rsp+0x30], xmm4
0000714ce89da016  vmovaps [rsp+0x40], xmm5
0000714ce89da01c  vmovaps [rsp+0x50], xmm6
0000714ce89da022  vmovaps [rsp+0x60], xmm7
0000714ce89da028  vmovaps [rsp+0x70], xmm8
0000714ce89da02e  vmovaps [rsp+0x80], xmm9
0000714ce89da037  vmovaps [rsp+0x90], xmm10
0000714ce89da040  vmovaps [rsp+0xA0], xmm11
0000714ce89da049  vmovaps [rsp+0xB0], xmm12
0000714ce89da052  vmovaps [rsp+0xC0], xmm13
0000714ce89da05b  vmovaps [rsp+0xD0], xmm14
0000714ce89da064  vmovaps [rsp+0xE0], xmm15
0000714ce89da06d  sub rsp, 0x30
0000714ce89da071  movaps [rsp], xmm3
0000714ce89da075  movaps [rsp+0x10], xmm5
0000714ce89da07a  movaps [rsp+0x20], xmm4
0000714ce89da07f  lea rdi, [rsp]
0000714ce89da083  mov esi, 0x00
0000714ce89da088  mov rax, 0x57A55D340530
0000714ce89da092  call rax
0000714ce89da094  movaps xmm3, [rsp]
0000714ce89da098  add rsp, 0x30
0000714ce89da09c  vmovaps xmm0, [rsp]
0000714ce89da0a1  vmovaps xmm1, [rsp+0x10]
0000714ce89da0a7  vmovaps xmm2, [rsp+0x20]
0000714ce89da0ad  vmovaps xmm4, [rsp+0x30]
0000714ce89da0b3  vmovaps xmm5, [rsp+0x40]
0000714ce89da0b9  vmovaps xmm6, [rsp+0x50]
0000714ce89da0bf  vmovaps xmm7, [rsp+0x60]
0000714ce89da0c5  vmovaps xmm8, [rsp+0x70]
0000714ce89da0cb  vmovaps xmm9, [rsp+0x80]
0000714ce89da0d4  vmovaps xmm10, [rsp+0x90]
0000714ce89da0dd  vmovaps xmm11, [rsp+0xA0]
0000714ce89da0e6  vmovaps xmm12, [rsp+0xB0]
0000714ce89da0ef  vmovaps xmm13, [rsp+0xC0]
0000714ce89da0f8  vmovaps xmm14, [rsp+0xD0]
0000714ce89da101  vmovaps xmm15, [rsp+0xE0]
0000714ce89da10a  add rsp, 0xF0
0000714ce89da111  pop r11
0000714ce89da113  pop r10
0000714ce89da115  pop r9
0000714ce89da117  pop r8
0000714ce89da119  pop rsi
0000714ce89da11a  pop rdi
0000714ce89da11b  pop rdx
0000714ce89da11c  pop rcx
0000714ce89da11d  pop rax
0000714ce89da11e  add rsp, 0x08
0000714ce89da122  jmp 0x0000714CE89D8C68
0000714ce89da127  sub rsp, 0x08
0000714ce89da12b  push rax
0000714ce89da12c  push rcx
0000714ce89da12d  push rdx
0000714ce89da12e  push rdi
0000714ce89da12f  push rsi
0000714ce89da130  push r8
0000714ce89da132  push r9
0000714ce89da134  push r10
0000714ce89da136  push r11
0000714ce89da138  sub rsp, 0xF0
0000714ce89da13f  vmovaps [rsp], xmm0
0000714ce89da144  vmovaps [rsp+0x10], xmm1
0000714ce89da14a  vmovaps [rsp+0x20], xmm2
0000714ce89da150  vmovaps [rsp+0x30], xmm3
0000714ce89da156  vmovaps [rsp+0x40], xmm4
0000714ce89da15c  vmovaps [rsp+0x50], xmm6
0000714ce89da162  vmovaps [rsp+0x60], xmm7
0000714ce89da168  vmovaps [rsp+0x70], xmm8
0000714ce89da16e  vmovaps [rsp+0x80], xmm9
0000714ce89da177  vmovaps [rsp+0x90], xmm10
0000714ce89da180  vmovaps [rsp+0xA0], xmm11
0000714ce89da189  vmovaps [rsp+0xB0], xmm12
0000714ce89da192  vmovaps [rsp+0xC0], xmm13
0000714ce89da19b  vmovaps [rsp+0xD0], xmm14
0000714ce89da1a4  vmovaps [rsp+0xE0], xmm15
0000714ce89da1ad  sub rsp, 0x30
0000714ce89da1b1  movaps [rsp], xmm5
0000714ce89da1b5  movaps [rsp+0x10], xmm8
0000714ce89da1bb  movaps [rsp+0x20], xmm15
0000714ce89da1c1  lea rdi, [rsp]
0000714ce89da1c5  mov esi, 0x00
0000714ce89da1ca  mov rax, 0x57A55D340530
0000714ce89da1d4  call rax
0000714ce89da1d6  movaps xmm5, [rsp]
0000714ce89da1da  add rsp, 0x30
0000714ce89da1de  vmovaps xmm0, [rsp]
0000714ce89da1e3  vmovaps xmm1, [rsp+0x10]
0000714ce89da1e9  vmovaps xmm2, [rsp+0x20]
0000714ce89da1ef  vmovaps xmm3, [rsp+0x30]
0000714ce89da1f5  vmovaps xmm4, [rsp+0x40]
0000714ce89da1fb  vmovaps xmm6, [rsp+0x50]
0000714ce89da201  vmovaps xmm7, [rsp+0x60]
0000714ce89da207  vmovaps xmm8, [rsp+0x70]
0000714ce89da20d  vmovaps xmm9, [rsp+0x80]
0000714ce89da216  vmovaps xmm10, [rsp+0x90]
0000714ce89da21f  vmovaps xmm11, [rsp+0xA0]
0000714ce89da228  vmovaps xmm12, [rsp+0xB0]
0000714ce89da231  vmovaps xmm13, [rsp+0xC0]
0000714ce89da23a  vmovaps xmm14, [rsp+0xD0]
0000714ce89da243  vmovaps xmm15, [rsp+0xE0]
0000714ce89da24c  add rsp, 0xF0
0000714ce89da253  pop r11
0000714ce89da255  pop r10
0000714ce89da257  pop r9
0000714ce89da259  pop r8
0000714ce89da25b  pop rsi
0000714ce89da25c  pop rdi
0000714ce89da25d  pop rdx
0000714ce89da25e  pop rcx
0000714ce89da25f  pop rax
0000714ce89da260  add rsp, 0x08
0000714ce89da264  jmp 0x0000714CE89D8CA0
0000714ce89da269  sub rsp, 0x08
0000714ce89da26d  push rax
0000714ce89da26e  push rcx
0000714ce89da26f  push rdx
0000714ce89da270  push rdi
0000714ce89da271  push rsi
0000714ce89da272  push r8
0000714ce89da274  push r9
0000714ce89da276  push r10
0000714ce89da278  push r11
0000714ce89da27a  sub rsp, 0xF0
0000714ce89da281  vmovaps [rsp], xmm0
0000714ce89da286  vmovaps [rsp+0x10], xmm1
0000714ce89da28c  vmovaps [rsp+0x20], xmm2
0000714ce89da292  vmovaps [rsp+0x30], xmm3
0000714ce89da298  vmovaps [rsp+0x40], xmm5
0000714ce89da29e  vmovaps [rsp+0x50], xmm6
0000714ce89da2a4  vmovaps [rsp+0x60], xmm7
0000714ce89da2aa  vmovaps [rsp+0x70], xmm8
0000714ce89da2b0  vmovaps [rsp+0x80], xmm9
0000714ce89da2b9  vmovaps [rsp+0x90], xmm10
0000714ce89da2c2  vmovaps [rsp+0xA0], xmm11
0000714ce89da2cb  vmovaps [rsp+0xB0], xmm12
0000714ce89da2d4  vmovaps [rsp+0xC0], xmm13
0000714ce89da2dd  vmovaps [rsp+0xD0], xmm14
0000714ce89da2e6  vmovaps [rsp+0xE0], xmm15
0000714ce89da2ef  sub rsp, 0x30
0000714ce89da2f3  movaps [rsp], xmm4
0000714ce89da2f7  movaps [rsp+0x10], xmm9
0000714ce89da2fd  movaps [rsp+0x20], xmm8
0000714ce89da303  lea rdi, [rsp]
0000714ce89da307  mov esi, 0x00
0000714ce89da30c  mov rax, 0x57A55D340530
0000714ce89da316  call rax
0000714ce89da318  movaps xmm4, [rsp]
0000714ce89da31c  add rsp, 0x30
0000714ce89da320  vmovaps xmm0, [rsp]
0000714ce89da325  vmovaps xmm1, [rsp+0x10]
0000714ce89da32b  vmovaps xmm2, [rsp+0x20]
0000714ce89da331  vmovaps xmm3, [rsp+0x30]
0000714ce89da337  vmovaps xmm5, [rsp+0x40]
0000714ce89da33d  vmovaps xmm6, [rsp+0x50]
0000714ce89da343  vmovaps xmm7, [rsp+0x60]
0000714ce89da349  vmovaps xmm8, [rsp+0x70]
0000714ce89da34f  vmovaps xmm9, [rsp+0x80]
0000714ce89da358  vmovaps xmm10, [rsp+0x90]
0000714ce89da361  vmovaps xmm11, [rsp+0xA0]
0000714ce89da36a  vmovaps xmm12, [rsp+0xB0]
0000714ce89da373  vmovaps xmm13, [rsp+0xC0]
0000714ce89da37c  vmovaps xmm14, [rsp+0xD0]
0000714ce89da385  vmovaps xmm15, [rsp+0xE0]
0000714ce89da38e  add rsp, 0xF0
0000714ce89da395  pop r11
0000714ce89da397  pop r10
0000714ce89da399  pop r9
0000714ce89da39b  pop r8
0000714ce89da39d  pop rsi
0000714ce89da39e  pop rdi
0000714ce89da39f  pop rdx
0000714ce89da3a0  pop rcx
0000714ce89da3a1  pop rax
0000714ce89da3a2  add rsp, 0x08
0000714ce89da3a6  jmp 0x0000714CE89D8CC1
0000714ce89da3ab  sub rsp, 0x08
0000714ce89da3af  push rax
0000714ce89da3b0  push rcx
0000714ce89da3b1  push rdx
0000714ce89da3b2  push rdi
0000714ce89da3b3  push rsi
0000714ce89da3b4  push r8
0000714ce89da3b6  push r9
0000714ce89da3b8  push r10
0000714ce89da3ba  push r11
0000714ce89da3bc  sub rsp, 0xF0
0000714ce89da3c3  vmovaps [rsp], xmm0
0000714ce89da3c8  vmovaps [rsp+0x10], xmm1
0000714ce89da3ce  vmovaps [rsp+0x20], xmm2
0000714ce89da3d4  vmovaps [rsp+0x30], xmm3
0000714ce89da3da  vmovaps [rsp+0x40], xmm4
0000714ce89da3e0  vmovaps [rsp+0x50], xmm5
0000714ce89da3e6  vmovaps [rsp+0x60], xmm6
0000714ce89da3ec  vmovaps [rsp+0x70], xmm7
0000714ce89da3f2  vmovaps [rsp+0x80], xmm8
0000714ce89da3fb  vmovaps [rsp+0x90], xmm10
0000714ce89da404  vmovaps [rsp+0xA0], xmm11
0000714ce89da40d  vmovaps [rsp+0xB0], xmm12
0000714ce89da416  vmovaps [rsp+0xC0], xmm13
0000714ce89da41f  vmovaps [rsp+0xD0], xmm14
0000714ce89da428  vmovaps [rsp+0xE0], xmm15
0000714ce89da431  sub rsp, 0x30
0000714ce89da435  movaps [rsp], xmm9
0000714ce89da43a  movaps [rsp+0x10], xmm10
0000714ce89da440  movaps [rsp+0x20], xmm8
0000714ce89da446  lea rdi, [rsp]
0000714ce89da44a  mov esi, 0x00
0000714ce89da44f  mov rax, 0x57A55D340530
0000714ce89da459  call rax
0000714ce89da45b  movaps xmm9, [rsp]
0000714ce89da460  add rsp, 0x30
0000714ce89da464  vmovaps xmm0, [rsp]
0000714ce89da469  vmovaps xmm1, [rsp+0x10]
0000714ce89da46f  vmovaps xmm2, [rsp+0x20]
0000714ce89da475  vmovaps xmm3, [rsp+0x30]
0000714ce89da47b  vmovaps xmm4, [rsp+0x40]
0000714ce89da481  vmovaps xmm5, [rsp+0x50]
0000714ce89da487  vmovaps xmm6, [rsp+0x60]
0000714ce89da48d  vmovaps xmm7, [rsp+0x70]
0000714ce89da493  vmovaps xmm8, [rsp+0x80]
0000714ce89da49c  vmovaps xmm10, [rsp+0x90]
0000714ce89da4a5  vmovaps xmm11, [rsp+0xA0]
0000714ce89da4ae  vmovaps xmm12, [rsp+0xB0]
0000714ce89da4b7  vmovaps xmm13, [rsp+0xC0]
0000714ce89da4c0  vmovaps xmm14, [rsp+0xD0]
0000714ce89da4c9  vmovaps xmm15, [rsp+0xE0]
0000714ce89da4d2  add rsp, 0xF0
0000714ce89da4d9  pop r11
0000714ce89da4db  pop r10
0000714ce89da4dd  pop r9
0000714ce89da4df  pop r8
0000714ce89da4e1  pop rsi
0000714ce89da4e2  pop rdi
0000714ce89da4e3  pop rdx
0000714ce89da4e4  pop rcx
0000714ce89da4e5  pop rax
0000714ce89da4e6  add rsp, 0x08
0000714ce89da4ea  jmp 0x0000714CE89D8CDB
0000714ce89da4ef  call 0x0000714CE88D64F0
0000714ce89da4f4  jmp 0x0000714CE89D8DF5
0000714ce89da4f9  call 0x0000714CE88D64F0
0000714ce89da4fe  jmp 0x0000714CE89D8E0B
0000714ce89da503  sub rsp, 0x08
0000714ce89da507  push rax
0000714ce89da508  push rcx
0000714ce89da509  push rdx
0000714ce89da50a  push rdi
0000714ce89da50b  push rsi
0000714ce89da50c  push r8
0000714ce89da50e  push r9
0000714ce89da510  push r10
0000714ce89da512  push r11
0000714ce89da514  sub rsp, 0xF0
0000714ce89da51b  vmovaps [rsp], xmm0
0000714ce89da520  vmovaps [rsp+0x10], xmm2
0000714ce89da526  vmovaps [rsp+0x20], xmm3
0000714ce89da52c  vmovaps [rsp+0x30], xmm4
0000714ce89da532  vmovaps [rsp+0x40], xmm5
0000714ce89da538  vmovaps [rsp+0x50], xmm6
0000714ce89da53e  vmovaps [rsp+0x60], xmm7
0000714ce89da544  vmovaps [rsp+0x70], xmm8
0000714ce89da54a  vmovaps [rsp+0x80], xmm9
0000714ce89da553  vmovaps [rsp+0x90], xmm10
0000714ce89da55c  vmovaps [rsp+0xA0], xmm11
0000714ce89da565  vmovaps [rsp+0xB0], xmm12
0000714ce89da56e  vmovaps [rsp+0xC0], xmm13
0000714ce89da577  vmovaps [rsp+0xD0], xmm14
0000714ce89da580  vmovaps [rsp+0xE0], xmm15
0000714ce89da589  sub rsp, 0x30
0000714ce89da58d  movaps [rsp], xmm1
0000714ce89da591  movaps [rsp+0x10], xmm6
0000714ce89da596  movaps [rsp+0x20], xmm15
0000714ce89da59c  lea rdi, [rsp]
0000714ce89da5a0  mov esi, 0x00
0000714ce89da5a5  mov rax, 0x57A55D340530
0000714ce89da5af  call rax
0000714ce89da5b1  movaps xmm1, [rsp]
0000714ce89da5b5  add rsp, 0x30
0000714ce89da5b9  vmovaps xmm0, [rsp]
0000714ce89da5be  vmovaps xmm2, [rsp+0x10]
0000714ce89da5c4  vmovaps xmm3, [rsp+0x20]
0000714ce89da5ca  vmovaps xmm4, [rsp+0x30]
0000714ce89da5d0  vmovaps xmm5, [rsp+0x40]
0000714ce89da5d6  vmovaps xmm6, [rsp+0x50]
0000714ce89da5dc  vmovaps xmm7, [rsp+0x60]
0000714ce89da5e2  vmovaps xmm8, [rsp+0x70]
0000714ce89da5e8  vmovaps xmm9, [rsp+0x80]
0000714ce89da5f1  vmovaps xmm10, [rsp+0x90]
0000714ce89da5fa  vmovaps xmm11, [rsp+0xA0]
0000714ce89da603  vmovaps xmm12, [rsp+0xB0]
0000714ce89da60c  vmovaps xmm13, [rsp+0xC0]
0000714ce89da615  vmovaps xmm14, [rsp+0xD0]
0000714ce89da61e  vmovaps xmm15, [rsp+0xE0]
0000714ce89da627  add rsp, 0xF0
0000714ce89da62e  pop r11
0000714ce89da630  pop r10
0000714ce89da632  pop r9
0000714ce89da634  pop r8
0000714ce89da636  pop rsi
0000714ce89da637  pop rdi
0000714ce89da638  pop rdx
0000714ce89da639  pop rcx
0000714ce89da63a  pop rax
0000714ce89da63b  add rsp, 0x08
0000714ce89da63f  jmp 0x0000714CE89D8E48
0000714ce89da644  call 0x0000714CE88E5820
0000714ce89da649  jmp 0x0000714CE89D8E55
0000714ce89da64e  sub rsp, 0x08
0000714ce89da652  push rax
0000714ce89da653  push rcx
0000714ce89da654  push rdx
0000714ce89da655  push rdi
0000714ce89da656  push rsi
0000714ce89da657  push r8
0000714ce89da659  push r9
0000714ce89da65b  push r10
0000714ce89da65d  push r11
0000714ce89da65f  sub rsp, 0xF0
0000714ce89da666  vmovaps [rsp], xmm0
0000714ce89da66b  vmovaps [rsp+0x10], xmm1
0000714ce89da671  vmovaps [rsp+0x20], xmm2
0000714ce89da677  vmovaps [rsp+0x30], xmm3
0000714ce89da67d  vmovaps [rsp+0x40], xmm4
0000714ce89da683  vmovaps [rsp+0x50], xmm5
0000714ce89da689  vmovaps [rsp+0x60], xmm6
0000714ce89da68f  vmovaps [rsp+0x70], xmm7
0000714ce89da695  vmovaps [rsp+0x80], xmm8
0000714ce89da69e  vmovaps [rsp+0x90], xmm9
0000714ce89da6a7  vmovaps [rsp+0xA0], xmm10
0000714ce89da6b0  vmovaps [rsp+0xB0], xmm11
0000714ce89da6b9  vmovaps [rsp+0xC0], xmm12
0000714ce89da6c2  vmovaps [rsp+0xD0], xmm13
0000714ce89da6cb  vmovaps [rsp+0xE0], xmm15
0000714ce89da6d4  sub rsp, 0x30
0000714ce89da6d8  movaps [rsp], xmm14
0000714ce89da6dd  movaps [rsp+0x10], xmm4
0000714ce89da6e2  movaps [rsp+0x20], xmm3
0000714ce89da6e7  lea rdi, [rsp]
0000714ce89da6eb  mov esi, 0x00
0000714ce89da6f0  mov rax, 0x57A55D340530
0000714ce89da6fa  call rax
0000714ce89da6fc  movaps xmm14, [rsp]
0000714ce89da701  add rsp, 0x30
0000714ce89da705  vmovaps xmm0, [rsp]
0000714ce89da70a  vmovaps xmm1, [rsp+0x10]
0000714ce89da710  vmovaps xmm2, [rsp+0x20]
0000714ce89da716  vmovaps xmm3, [rsp+0x30]
0000714ce89da71c  vmovaps xmm4, [rsp+0x40]
0000714ce89da722  vmovaps xmm5, [rsp+0x50]
0000714ce89da728  vmovaps xmm6, [rsp+0x60]
0000714ce89da72e  vmovaps xmm7, [rsp+0x70]
0000714ce89da734  vmovaps xmm8, [rsp+0x80]
0000714ce89da73d  vmovaps xmm9, [rsp+0x90]
0000714ce89da746  vmovaps xmm10, [rsp+0xA0]
0000714ce89da74f  vmovaps xmm11, [rsp+0xB0]
0000714ce89da758  vmovaps xmm12, [rsp+0xC0]
0000714ce89da761  vmovaps xmm13, [rsp+0xD0]
0000714ce89da76a  vmovaps xmm15, [rsp+0xE0]
0000714ce89da773  add rsp, 0xF0
0000714ce89da77a  pop r11
0000714ce89da77c  pop r10
0000714ce89da77e  pop r9
0000714ce89da780  pop r8
0000714ce89da782  pop rsi
0000714ce89da783  pop rdi
0000714ce89da784  pop rdx
0000714ce89da785  pop rcx
0000714ce89da786  pop rax
0000714ce89da787  add rsp, 0x08
0000714ce89da78b  jmp 0x0000714CE89D8E6F
0000714ce89da790  sub rsp, 0x08
0000714ce89da794  push rax
0000714ce89da795  push rcx
0000714ce89da796  push rdx
0000714ce89da797  push rdi
0000714ce89da798  push rsi
0000714ce89da799  push r8
0000714ce89da79b  push r9
0000714ce89da79d  push r10
0000714ce89da79f  push r11
0000714ce89da7a1  sub rsp, 0xF0
0000714ce89da7a8  vmovaps [rsp], xmm0
0000714ce89da7ad  vmovaps [rsp+0x10], xmm1
0000714ce89da7b3  vmovaps [rsp+0x20], xmm2
0000714ce89da7b9  vmovaps [rsp+0x30], xmm3
0000714ce89da7bf  vmovaps [rsp+0x40], xmm4
0000714ce89da7c5  vmovaps [rsp+0x50], xmm5
0000714ce89da7cb  vmovaps [rsp+0x60], xmm7
0000714ce89da7d1  vmovaps [rsp+0x70], xmm8
0000714ce89da7d7  vmovaps [rsp+0x80], xmm9
0000714ce89da7e0  vmovaps [rsp+0x90], xmm10
0000714ce89da7e9  vmovaps [rsp+0xA0], xmm11
0000714ce89da7f2  vmovaps [rsp+0xB0], xmm12
0000714ce89da7fb  vmovaps [rsp+0xC0], xmm13
0000714ce89da804  vmovaps [rsp+0xD0], xmm14
0000714ce89da80d  vmovaps [rsp+0xE0], xmm15
0000714ce89da816  sub rsp, 0x30
0000714ce89da81a  movaps [rsp], xmm6
0000714ce89da81e  movaps [rsp+0x10], xmm9
0000714ce89da824  movaps [rsp+0x20], xmm7
0000714ce89da829  lea rdi, [rsp]
0000714ce89da82d  mov esi, 0x00
0000714ce89da832  mov rax, 0x57A55D340530
0000714ce89da83c  call rax
0000714ce89da83e  movaps xmm6, [rsp]
0000714ce89da842  add rsp, 0x30
0000714ce89da846  vmovaps xmm0, [rsp]
0000714ce89da84b  vmovaps xmm1, [rsp+0x10]
0000714ce89da851  vmovaps xmm2, [rsp+0x20]
0000714ce89da857  vmovaps xmm3, [rsp+0x30]
0000714ce89da85d  vmovaps xmm4, [rsp+0x40]
0000714ce89da863  vmovaps xmm5, [rsp+0x50]
0000714ce89da869  vmovaps xmm7, [rsp+0x60]
0000714ce89da86f  vmovaps xmm8, [rsp+0x70]
0000714ce89da875  vmovaps xmm9, [rsp+0x80]
0000714ce89da87e  vmovaps xmm10, [rsp+0x90]
0000714ce89da887  vmovaps xmm11, [rsp+0xA0]
0000714ce89da890  vmovaps xmm12, [rsp+0xB0]
0000714ce89da899  vmovaps xmm13, [rsp+0xC0]
0000714ce89da8a2  vmovaps xmm14, [rsp+0xD0]
0000714ce89da8ab  vmovaps xmm15, [rsp+0xE0]
0000714ce89da8b4  add rsp, 0xF0
0000714ce89da8bb  pop r11
0000714ce89da8bd  pop r10
0000714ce89da8bf  pop r9
0000714ce89da8c1  pop r8
0000714ce89da8c3  pop rsi
0000714ce89da8c4  pop rdi
0000714ce89da8c5  pop rdx
0000714ce89da8c6  pop rcx
0000714ce89da8c7  pop rax
0000714ce89da8c8  add rsp, 0x08
0000714ce89da8cc  jmp 0x0000714CE89D8E87
0000714ce89da8d1  sub rsp, 0x08
0000714ce89da8d5  push rax
0000714ce89da8d6  push rcx
0000714ce89da8d7  push rdx
0000714ce89da8d8  push rdi
0000714ce89da8d9  push rsi
0000714ce89da8da  push r8
0000714ce89da8dc  push r9
0000714ce89da8de  push r10
0000714ce89da8e0  push r11
0000714ce89da8e2  sub rsp, 0xF0
0000714ce89da8e9  vmovaps [rsp], xmm0
0000714ce89da8ee  vmovaps [rsp+0x10], xmm1
0000714ce89da8f4  vmovaps [rsp+0x20], xmm2
0000714ce89da8fa  vmovaps [rsp+0x30], xmm3
0000714ce89da900  vmovaps [rsp+0x40], xmm4
0000714ce89da906  vmovaps [rsp+0x50], xmm5
0000714ce89da90c  vmovaps [rsp+0x60], xmm6
0000714ce89da912  vmovaps [rsp+0x70], xmm8
0000714ce89da918  vmovaps [rsp+0x80], xmm9
0000714ce89da921  vmovaps [rsp+0x90], xmm10
0000714ce89da92a  vmovaps [rsp+0xA0], xmm11
0000714ce89da933  vmovaps [rsp+0xB0], xmm12
0000714ce89da93c  vmovaps [rsp+0xC0], xmm13
0000714ce89da945  vmovaps [rsp+0xD0], xmm14
0000714ce89da94e  vmovaps [rsp+0xE0], xmm15
0000714ce89da957  sub rsp, 0x30
0000714ce89da95b  movaps [rsp], xmm7
0000714ce89da95f  movaps [rsp+0x10], xmm4
0000714ce89da964  movaps [rsp+0x20], xmm9
0000714ce89da96a  lea rdi, [rsp]
0000714ce89da96e  mov esi, 0x00
0000714ce89da973  mov rax, 0x57A55D340530
0000714ce89da97d  call rax
0000714ce89da97f  movaps xmm7, [rsp]
0000714ce89da983  add rsp, 0x30
0000714ce89da987  vmovaps xmm0, [rsp]
0000714ce89da98c  vmovaps xmm1, [rsp+0x10]
0000714ce89da992  vmovaps xmm2, [rsp+0x20]
0000714ce89da998  vmovaps xmm3, [rsp+0x30]
0000714ce89da99e  vmovaps xmm4, [rsp+0x40]
0000714ce89da9a4  vmovaps xmm5, [rsp+0x50]
0000714ce89da9aa  vmovaps xmm6, [rsp+0x60]
0000714ce89da9b0  vmovaps xmm8, [rsp+0x70]
0000714ce89da9b6  vmovaps xmm9, [rsp+0x80]
0000714ce89da9bf  vmovaps xmm10, [rsp+0x90]
0000714ce89da9c8  vmovaps xmm11, [rsp+0xA0]
0000714ce89da9d1  vmovaps xmm12, [rsp+0xB0]
0000714ce89da9da  vmovaps xmm13, [rsp+0xC0]
0000714ce89da9e3  vmovaps xmm14, [rsp+0xD0]
0000714ce89da9ec  vmovaps xmm15, [rsp+0xE0]
0000714ce89da9f5  add rsp, 0xF0
0000714ce89da9fc  pop r11
0000714ce89da9fe  pop r10
0000714ce89daa00  pop r9
0000714ce89daa02  pop r8
0000714ce89daa04  pop rsi
0000714ce89daa05  pop rdi
0000714ce89daa06  pop rdx
0000714ce89daa07  pop rcx
0000714ce89daa08  pop rax
0000714ce89daa09  add rsp, 0x08
0000714ce89daa0d  jmp 0x0000714CE89D8EB4
0000714ce89daa12  sub rsp, 0x08
0000714ce89daa16  push rax
0000714ce89daa17  push rcx
0000714ce89daa18  push rdx
0000714ce89daa19  push rdi
0000714ce89daa1a  push rsi
0000714ce89daa1b  push r8
0000714ce89daa1d  push r9
0000714ce89daa1f  push r10
0000714ce89daa21  push r11
0000714ce89daa23  sub rsp, 0xF0
0000714ce89daa2a  vmovaps [rsp], xmm0
0000714ce89daa2f  vmovaps [rsp+0x10], xmm1
0000714ce89daa35  vmovaps [rsp+0x20], xmm2
0000714ce89daa3b  vmovaps [rsp+0x30], xmm3
0000714ce89daa41  vmovaps [rsp+0x40], xmm5
0000714ce89daa47  vmovaps [rsp+0x50], xmm6
0000714ce89daa4d  vmovaps [rsp+0x60], xmm7
0000714ce89daa53  vmovaps [rsp+0x70], xmm8
0000714ce89daa59  vmovaps [rsp+0x80], xmm9
0000714ce89daa62  vmovaps [rsp+0x90], xmm10
0000714ce89daa6b  vmovaps [rsp+0xA0], xmm11
0000714ce89daa74  vmovaps [rsp+0xB0], xmm12
0000714ce89daa7d  vmovaps [rsp+0xC0], xmm13
0000714ce89daa86  vmovaps [rsp+0xD0], xmm14
0000714ce89daa8f  vmovaps [rsp+0xE0], xmm15
0000714ce89daa98  sub rsp, 0x30
0000714ce89daa9c  movaps [rsp], xmm4
0000714ce89daaa0  movaps [rsp+0x10], xmm15
0000714ce89daaa6  movaps [rsp+0x20], xmm9
0000714ce89daaac  lea rdi, [rsp]
0000714ce89daab0  mov esi, 0x00
0000714ce89daab5  mov rax, 0x57A55D340530
0000714ce89daabf  call rax
0000714ce89daac1  movaps xmm4, [rsp]
0000714ce89daac5  add rsp, 0x30
0000714ce89daac9  vmovaps xmm0, [rsp]
0000714ce89daace  vmovaps xmm1, [rsp+0x10]
0000714ce89daad4  vmovaps xmm2, [rsp+0x20]
0000714ce89daada  vmovaps xmm3, [rsp+0x30]
0000714ce89daae0  vmovaps xmm5, [rsp+0x40]
0000714ce89daae6  vmovaps xmm6, [rsp+0x50]
0000714ce89daaec  vmovaps xmm7, [rsp+0x60]
0000714ce89daaf2  vmovaps xmm8, [rsp+0x70]
0000714ce89daaf8  vmovaps xmm9, [rsp+0x80]
0000714ce89dab01  vmovaps xmm10, [rsp+0x90]
0000714ce89dab0a  vmovaps xmm11, [rsp+0xA0]
0000714ce89dab13  vmovaps xmm12, [rsp+0xB0]
0000714ce89dab1c  vmovaps xmm13, [rsp+0xC0]
0000714ce89dab25  vmovaps xmm14, [rsp+0xD0]
0000714ce89dab2e  vmovaps xmm15, [rsp+0xE0]
0000714ce89dab37  add rsp, 0xF0
0000714ce89dab3e  pop r11
0000714ce89dab40  pop r10
0000714ce89dab42  pop r9
0000714ce89dab44  pop r8
0000714ce89dab46  pop rsi
0000714ce89dab47  pop rdi
0000714ce89dab48  pop rdx
0000714ce89dab49  pop rcx
0000714ce89dab4a  pop rax
0000714ce89dab4b  add rsp, 0x08
0000714ce89dab4f  jmp 0x0000714CE89D8ED9
0000714ce89dab54  call 0x0000714CE88E5820
0000714ce89dab59  jmp 0x0000714CE89D8EE6
0000714ce89dab5e  sub rsp, 0x08
0000714ce89dab62  push rax
0000714ce89dab63  push rcx
0000714ce89dab64  push rdx
0000714ce89dab65  push rdi
0000714ce89dab66  push rsi
0000714ce89dab67  push r8
0000714ce89dab69  push r9
0000714ce89dab6b  push r10
0000714ce89dab6d  push r11
0000714ce89dab6f  sub rsp, 0xF0
0000714ce89dab76  vmovaps [rsp], xmm0
0000714ce89dab7b  vmovaps [rsp+0x10], xmm1
0000714ce89dab81  vmovaps [rsp+0x20], xmm2
0000714ce89dab87  vmovaps [rsp+0x30], xmm4
0000714ce89dab8d  vmovaps [rsp+0x40], xmm5
0000714ce89dab93  vmovaps [rsp+0x50], xmm6
0000714ce89dab99  vmovaps [rsp+0x60], xmm7
0000714ce89dab9f  vmovaps [rsp+0x70], xmm8
0000714ce89daba5  vmovaps [rsp+0x80], xmm9
0000714ce89dabae  vmovaps [rsp+0x90], xmm10
0000714ce89dabb7  vmovaps [rsp+0xA0], xmm11
0000714ce89dabc0  vmovaps [rsp+0xB0], xmm12
0000714ce89dabc9  vmovaps [rsp+0xC0], xmm13
0000714ce89dabd2  vmovaps [rsp+0xD0], xmm14
0000714ce89dabdb  vmovaps [rsp+0xE0], xmm15
0000714ce89dabe4  sub rsp, 0x30
0000714ce89dabe8  movaps [rsp], xmm3
0000714ce89dabec  movaps [rsp+0x10], xmm1
0000714ce89dabf1  movaps [rsp+0x20], xmm9
0000714ce89dabf7  lea rdi, [rsp]
0000714ce89dabfb  mov esi, 0x00
0000714ce89dac00  mov rax, 0x57A55D340530
0000714ce89dac0a  call rax
0000714ce89dac0c  movaps xmm3, [rsp]
0000714ce89dac10  add rsp, 0x30
0000714ce89dac14  vmovaps xmm0, [rsp]
0000714ce89dac19  vmovaps xmm1, [rsp+0x10]
0000714ce89dac1f  vmovaps xmm2, [rsp+0x20]
0000714ce89dac25  vmovaps xmm4, [rsp+0x30]
0000714ce89dac2b  vmovaps xmm5, [rsp+0x40]
0000714ce89dac31  vmovaps xmm6, [rsp+0x50]
0000714ce89dac37  vmovaps xmm7, [rsp+0x60]
0000714ce89dac3d  vmovaps xmm8, [rsp+0x70]
0000714ce89dac43  vmovaps xmm9, [rsp+0x80]
0000714ce89dac4c  vmovaps xmm10, [rsp+0x90]
0000714ce89dac55  vmovaps xmm11, [rsp+0xA0]
0000714ce89dac5e  vmovaps xmm12, [rsp+0xB0]
0000714ce89dac67  vmovaps xmm13, [rsp+0xC0]
0000714ce89dac70  vmovaps xmm14, [rsp+0xD0]
0000714ce89dac79  vmovaps xmm15, [rsp+0xE0]
0000714ce89dac82  add rsp, 0xF0
0000714ce89dac89  pop r11
0000714ce89dac8b  pop r10
0000714ce89dac8d  pop r9
0000714ce89dac8f  pop r8
0000714ce89dac91  pop rsi
0000714ce89dac92  pop rdi
0000714ce89dac93  pop rdx
0000714ce89dac94  pop rcx
0000714ce89dac95  pop rax
0000714ce89dac96  add rsp, 0x08
0000714ce89dac9a  jmp 0x0000714CE89D8F23
0000714ce89dac9f  sub rsp, 0x08
0000714ce89daca3  push rax
0000714ce89daca4  push rcx
0000714ce89daca5  push rdx
0000714ce89daca6  push rdi
0000714ce89daca7  push rsi
0000714ce89daca8  push r8
0000714ce89dacaa  push r9
0000714ce89dacac  push r10
0000714ce89dacae  push r11
0000714ce89dacb0  sub rsp, 0xF0
0000714ce89dacb7  vmovaps [rsp], xmm0
0000714ce89dacbc  vmovaps [rsp+0x10], xmm2
0000714ce89dacc2  vmovaps [rsp+0x20], xmm3
0000714ce89dacc8  vmovaps [rsp+0x30], xmm4
0000714ce89dacce  vmovaps [rsp+0x40], xmm5
0000714ce89dacd4  vmovaps [rsp+0x50], xmm6
0000714ce89dacda  vmovaps [rsp+0x60], xmm7
0000714ce89dace0  vmovaps [rsp+0x70], xmm8
0000714ce89dace6  vmovaps [rsp+0x80], xmm9
0000714ce89dacef  vmovaps [rsp+0x90], xmm10
0000714ce89dacf8  vmovaps [rsp+0xA0], xmm11
0000714ce89dad01  vmovaps [rsp+0xB0], xmm12
0000714ce89dad0a  vmovaps [rsp+0xC0], xmm13
0000714ce89dad13  vmovaps [rsp+0xD0], xmm14
0000714ce89dad1c  vmovaps [rsp+0xE0], xmm15
0000714ce89dad25  sub rsp, 0x30
0000714ce89dad29  movaps [rsp], xmm1
0000714ce89dad2d  movaps [rsp+0x10], xmm15
0000714ce89dad33  movaps [rsp+0x20], xmm9
0000714ce89dad39  lea rdi, [rsp]
0000714ce89dad3d  mov esi, 0x00
0000714ce89dad42  mov rax, 0x57A55D340530
0000714ce89dad4c  call rax
0000714ce89dad4e  movaps xmm1, [rsp]
0000714ce89dad52  add rsp, 0x30
0000714ce89dad56  vmovaps xmm0, [rsp]
0000714ce89dad5b  vmovaps xmm2, [rsp+0x10]
0000714ce89dad61  vmovaps xmm3, [rsp+0x20]
0000714ce89dad67  vmovaps xmm4, [rsp+0x30]
0000714ce89dad6d  vmovaps xmm5, [rsp+0x40]
0000714ce89dad73  vmovaps xmm6, [rsp+0x50]
0000714ce89dad79  vmovaps xmm7, [rsp+0x60]
0000714ce89dad7f  vmovaps xmm8, [rsp+0x70]
0000714ce89dad85  vmovaps xmm9, [rsp+0x80]
0000714ce89dad8e  vmovaps xmm10, [rsp+0x90]
0000714ce89dad97  vmovaps xmm11, [rsp+0xA0]
0000714ce89dada0  vmovaps xmm12, [rsp+0xB0]
0000714ce89dada9  vmovaps xmm13, [rsp+0xC0]
0000714ce89dadb2  vmovaps xmm14, [rsp+0xD0]
0000714ce89dadbb  vmovaps xmm15, [rsp+0xE0]
0000714ce89dadc4  add rsp, 0xF0
0000714ce89dadcb  pop r11
0000714ce89dadcd  pop r10
0000714ce89dadcf  pop r9
0000714ce89dadd1  pop r8
0000714ce89dadd3  pop rsi
0000714ce89dadd4  pop rdi
0000714ce89dadd5  pop rdx
0000714ce89dadd6  pop rcx
0000714ce89dadd7  pop rax
0000714ce89dadd8  add rsp, 0x08
0000714ce89daddc  jmp 0x0000714CE89D8FAB
0000714ce89dade1  call 0x0000714CE88E5820
0000714ce89dade6  jmp 0x0000714CE89D8FB8
0000714ce89dadeb  sub rsp, 0x08
0000714ce89dadef  push rax
0000714ce89dadf0  push rcx
0000714ce89dadf1  push rdx
0000714ce89dadf2  push rdi
0000714ce89dadf3  push rsi
0000714ce89dadf4  push r8
0000714ce89dadf6  push r9
0000714ce89dadf8  push r10
0000714ce89dadfa  push r11
0000714ce89dadfc  sub rsp, 0xF0
0000714ce89dae03  vmovaps [rsp], xmm0
0000714ce89dae08  vmovaps [rsp+0x10], xmm2
0000714ce89dae0e  vmovaps [rsp+0x20], xmm3
0000714ce89dae14  vmovaps [rsp+0x30], xmm4
0000714ce89dae1a  vmovaps [rsp+0x40], xmm5
0000714ce89dae20  vmovaps [rsp+0x50], xmm6
0000714ce89dae26  vmovaps [rsp+0x60], xmm7
0000714ce89dae2c  vmovaps [rsp+0x70], xmm8
0000714ce89dae32  vmovaps [rsp+0x80], xmm9
0000714ce89dae3b  vmovaps [rsp+0x90], xmm10
0000714ce89dae44  vmovaps [rsp+0xA0], xmm11
0000714ce89dae4d  vmovaps [rsp+0xB0], xmm12
0000714ce89dae56  vmovaps [rsp+0xC0], xmm13
0000714ce89dae5f  vmovaps [rsp+0xD0], xmm14
0000714ce89dae68  vmovaps [rsp+0xE0], xmm15
0000714ce89dae71  sub rsp, 0x30
0000714ce89dae75  movaps [rsp], xmm1
0000714ce89dae79  movaps [rsp+0x10], xmm5
0000714ce89dae7e  movaps [rsp+0x20], xmm7
0000714ce89dae83  lea rdi, [rsp]
0000714ce89dae87  mov esi, 0x00
0000714ce89dae8c  mov rax, 0x57A55D340530
0000714ce89dae96  call rax
0000714ce89dae98  movaps xmm1, [rsp]
0000714ce89dae9c  add rsp, 0x30
0000714ce89daea0  vmovaps xmm0, [rsp]
0000714ce89daea5  vmovaps xmm2, [rsp+0x10]
0000714ce89daeab  vmovaps xmm3, [rsp+0x20]
0000714ce89daeb1  vmovaps xmm4, [rsp+0x30]
0000714ce89daeb7  vmovaps xmm5, [rsp+0x40]
0000714ce89daebd  vmovaps xmm6, [rsp+0x50]
0000714ce89daec3  vmovaps xmm7, [rsp+0x60]
0000714ce89daec9  vmovaps xmm8, [rsp+0x70]
0000714ce89daecf  vmovaps xmm9, [rsp+0x80]
0000714ce89daed8  vmovaps xmm10, [rsp+0x90]
0000714ce89daee1  vmovaps xmm11, [rsp+0xA0]
0000714ce89daeea  vmovaps xmm12, [rsp+0xB0]
0000714ce89daef3  vmovaps xmm13, [rsp+0xC0]
0000714ce89daefc  vmovaps xmm14, [rsp+0xD0]
0000714ce89daf05  vmovaps xmm15, [rsp+0xE0]
0000714ce89daf0e  add rsp, 0xF0
0000714ce89daf15  pop r11
0000714ce89daf17  pop r10
0000714ce89daf19  pop r9
0000714ce89daf1b  pop r8
0000714ce89daf1d  pop rsi
0000714ce89daf1e  pop rdi
0000714ce89daf1f  pop rdx
0000714ce89daf20  pop rcx
0000714ce89daf21  pop rax
0000714ce89daf22  add rsp, 0x08
0000714ce89daf26  jmp 0x0000714CE89D905D
0000714ce89daf2b  sub rsp, 0x08
0000714ce89daf2f  push rax
0000714ce89daf30  push rcx
0000714ce89daf31  push rdx
0000714ce89daf32  push rdi
0000714ce89daf33  push rsi
0000714ce89daf34  push r8
0000714ce89daf36  push r9
0000714ce89daf38  push r10
0000714ce89daf3a  push r11
0000714ce89daf3c  sub rsp, 0xF0
0000714ce89daf43  vmovaps [rsp], xmm0
0000714ce89daf48  vmovaps [rsp+0x10], xmm1
0000714ce89daf4e  vmovaps [rsp+0x20], xmm2
0000714ce89daf54  vmovaps [rsp+0x30], xmm3
0000714ce89daf5a  vmovaps [rsp+0x40], xmm4
0000714ce89daf60  vmovaps [rsp+0x50], xmm5
0000714ce89daf66  vmovaps [rsp+0x60], xmm6
0000714ce89daf6c  vmovaps [rsp+0x70], xmm8
0000714ce89daf72  vmovaps [rsp+0x80], xmm9
0000714ce89daf7b  vmovaps [rsp+0x90], xmm10
0000714ce89daf84  vmovaps [rsp+0xA0], xmm11
0000714ce89daf8d  vmovaps [rsp+0xB0], xmm12
0000714ce89daf96  vmovaps [rsp+0xC0], xmm13
0000714ce89daf9f  vmovaps [rsp+0xD0], xmm14
0000714ce89dafa8  vmovaps [rsp+0xE0], xmm15
0000714ce89dafb1  sub rsp, 0x30
0000714ce89dafb5  movaps [rsp], xmm7
0000714ce89dafb9  movaps [rsp+0x10], xmm5
0000714ce89dafbe  movaps [rsp+0x20], xmm15
0000714ce89dafc4  lea rdi, [rsp]
0000714ce89dafc8  mov esi, 0x00
0000714ce89dafcd  mov rax, 0x57A55D340530
0000714ce89dafd7  call rax
0000714ce89dafd9  movaps xmm7, [rsp]
0000714ce89dafdd  add rsp, 0x30
0000714ce89dafe1  vmovaps xmm0, [rsp]
0000714ce89dafe6  vmovaps xmm1, [rsp+0x10]
0000714ce89dafec  vmovaps xmm2, [rsp+0x20]
0000714ce89daff2  vmovaps xmm3, [rsp+0x30]
0000714ce89daff8  vmovaps xmm4, [rsp+0x40]
0000714ce89daffe  vmovaps xmm5, [rsp+0x50]
0000714ce89db004  vmovaps xmm6, [rsp+0x60]
0000714ce89db00a  vmovaps xmm8, [rsp+0x70]
0000714ce89db010  vmovaps xmm9, [rsp+0x80]
0000714ce89db019  vmovaps xmm10, [rsp+0x90]
0000714ce89db022  vmovaps xmm11, [rsp+0xA0]
0000714ce89db02b  vmovaps xmm12, [rsp+0xB0]
0000714ce89db034  vmovaps xmm13, [rsp+0xC0]
0000714ce89db03d  vmovaps xmm14, [rsp+0xD0]
0000714ce89db046  vmovaps xmm15, [rsp+0xE0]
0000714ce89db04f  add rsp, 0xF0
0000714ce89db056  pop r11
0000714ce89db058  pop r10
0000714ce89db05a  pop r9
0000714ce89db05c  pop r8
0000714ce89db05e  pop rsi
0000714ce89db05f  pop rdi
0000714ce89db060  pop rdx
0000714ce89db061  pop rcx
0000714ce89db062  pop rax
0000714ce89db063  add rsp, 0x08
0000714ce89db067  jmp 0x0000714CE89D9093
0000714ce89db06c  call 0x0000714CE88D64F0
0000714ce89db071  jmp 0x0000714CE89D90A0
0000714ce89db076  sub rsp, 0x08
0000714ce89db07a  push rax
0000714ce89db07b  push rcx
0000714ce89db07c  push rdx
0000714ce89db07d  push rdi
0000714ce89db07e  push rsi
0000714ce89db07f  push r8
0000714ce89db081  push r9
0000714ce89db083  push r10
0000714ce89db085  push r11
0000714ce89db087  sub rsp, 0xF0
0000714ce89db08e  vmovaps [rsp], xmm0
0000714ce89db093  vmovaps [rsp+0x10], xmm1
0000714ce89db099  vmovaps [rsp+0x20], xmm2
0000714ce89db09f  vmovaps [rsp+0x30], xmm3
0000714ce89db0a5  vmovaps [rsp+0x40], xmm4
0000714ce89db0ab  vmovaps [rsp+0x50], xmm5
0000714ce89db0b1  vmovaps [rsp+0x60], xmm6
0000714ce89db0b7  vmovaps [rsp+0x70], xmm7
0000714ce89db0bd  vmovaps [rsp+0x80], xmm8
0000714ce89db0c6  vmovaps [rsp+0x90], xmm9
0000714ce89db0cf  vmovaps [rsp+0xA0], xmm10
0000714ce89db0d8  vmovaps [rsp+0xB0], xmm11
0000714ce89db0e1  vmovaps [rsp+0xC0], xmm12
0000714ce89db0ea  vmovaps [rsp+0xD0], xmm13
0000714ce89db0f3  vmovaps [rsp+0xE0], xmm14
0000714ce89db0fc  sub rsp, 0x30
0000714ce89db100  movaps [rsp], xmm15
0000714ce89db105  movaps [rsp+0x10], xmm5
0000714ce89db10a  movaps [rsp+0x20], xmm3
0000714ce89db10f  lea rdi, [rsp]
0000714ce89db113  mov esi, 0x00
0000714ce89db118  mov rax, 0x57A55D340530
0000714ce89db122  call rax
0000714ce89db124  movaps xmm15, [rsp]
0000714ce89db129  add rsp, 0x30
0000714ce89db12d  vmovaps xmm0, [rsp]
0000714ce89db132  vmovaps xmm1, [rsp+0x10]
0000714ce89db138  vmovaps xmm2, [rsp+0x20]
0000714ce89db13e  vmovaps xmm3, [rsp+0x30]
0000714ce89db144  vmovaps xmm4, [rsp+0x40]
0000714ce89db14a  vmovaps xmm5, [rsp+0x50]
0000714ce89db150  vmovaps xmm6, [rsp+0x60]
0000714ce89db156  vmovaps xmm7, [rsp+0x70]
0000714ce89db15c  vmovaps xmm8, [rsp+0x80]
0000714ce89db165  vmovaps xmm9, [rsp+0x90]
0000714ce89db16e  vmovaps xmm10, [rsp+0xA0]
0000714ce89db177  vmovaps xmm11, [rsp+0xB0]
0000714ce89db180  vmovaps xmm12, [rsp+0xC0]
0000714ce89db189  vmovaps xmm13, [rsp+0xD0]
0000714ce89db192  vmovaps xmm14, [rsp+0xE0]
0000714ce89db19b  add rsp, 0xF0
0000714ce89db1a2  pop r11
0000714ce89db1a4  pop r10
0000714ce89db1a6  pop r9
0000714ce89db1a8  pop r8
0000714ce89db1aa  pop rsi
0000714ce89db1ab  pop rdi
0000714ce89db1ac  pop rdx
0000714ce89db1ad  pop rcx
0000714ce89db1ae  pop rax
0000714ce89db1af  add rsp, 0x08
0000714ce89db1b3  jmp 0x0000714CE89D90C6
0000714ce89db1b8  sub rsp, 0x08
0000714ce89db1bc  push rax
0000714ce89db1bd  push rcx
0000714ce89db1be  push rdx
0000714ce89db1bf  push rdi
0000714ce89db1c0  push rsi
0000714ce89db1c1  push r8
0000714ce89db1c3  push r9
0000714ce89db1c5  push r10
0000714ce89db1c7  push r11
0000714ce89db1c9  sub rsp, 0xF0
0000714ce89db1d0  vmovaps [rsp], xmm0
0000714ce89db1d5  vmovaps [rsp+0x10], xmm2
0000714ce89db1db  vmovaps [rsp+0x20], xmm3
0000714ce89db1e1  vmovaps [rsp+0x30], xmm4
0000714ce89db1e7  vmovaps [rsp+0x40], xmm5
0000714ce89db1ed  vmovaps [rsp+0x50], xmm6
0000714ce89db1f3  vmovaps [rsp+0x60], xmm7
0000714ce89db1f9  vmovaps [rsp+0x70], xmm8
0000714ce89db1ff  vmovaps [rsp+0x80], xmm9
0000714ce89db208  vmovaps [rsp+0x90], xmm10
0000714ce89db211  vmovaps [rsp+0xA0], xmm11
0000714ce89db21a  vmovaps [rsp+0xB0], xmm12
0000714ce89db223  vmovaps [rsp+0xC0], xmm13
0000714ce89db22c  vmovaps [rsp+0xD0], xmm14
0000714ce89db235  vmovaps [rsp+0xE0], xmm15
0000714ce89db23e  sub rsp, 0x30
0000714ce89db242  movaps [rsp], xmm1
0000714ce89db246  movaps [rsp+0x10], xmm5
0000714ce89db24b  movaps [rsp+0x20], xmm4
0000714ce89db250  lea rdi, [rsp]
0000714ce89db254  mov esi, 0x00
0000714ce89db259  mov rax, 0x57A55D340530
0000714ce89db263  call rax
0000714ce89db265  movaps xmm1, [rsp]
0000714ce89db269  add rsp, 0x30
0000714ce89db26d  vmovaps xmm0, [rsp]
0000714ce89db272  vmovaps xmm2, [rsp+0x10]
0000714ce89db278  vmovaps xmm3, [rsp+0x20]
0000714ce89db27e  vmovaps xmm4, [rsp+0x30]
0000714ce89db284  vmovaps xmm5, [rsp+0x40]
0000714ce89db28a  vmovaps xmm6, [rsp+0x50]
0000714ce89db290  vmovaps xmm7, [rsp+0x60]
0000714ce89db296  vmovaps xmm8, [rsp+0x70]
0000714ce89db29c  vmovaps xmm9, [rsp+0x80]
0000714ce89db2a5  vmovaps xmm10, [rsp+0x90]
0000714ce89db2ae  vmovaps xmm11, [rsp+0xA0]
0000714ce89db2b7  vmovaps xmm12, [rsp+0xB0]
0000714ce89db2c0  vmovaps xmm13, [rsp+0xC0]
0000714ce89db2c9  vmovaps xmm14, [rsp+0xD0]
0000714ce89db2d2  vmovaps xmm15, [rsp+0xE0]
0000714ce89db2db  add rsp, 0xF0
0000714ce89db2e2  pop r11
0000714ce89db2e4  pop r10
0000714ce89db2e6  pop r9
0000714ce89db2e8  pop r8
0000714ce89db2ea  pop rsi
0000714ce89db2eb  pop rdi
0000714ce89db2ec  pop rdx
0000714ce89db2ed  pop rcx
0000714ce89db2ee  pop rax
0000714ce89db2ef  add rsp, 0x08
0000714ce89db2f3  jmp 0x0000714CE89D90E6
0000714ce89db2f8  sub rsp, 0x08
0000714ce89db2fc  push rax
0000714ce89db2fd  push rcx
0000714ce89db2fe  push rdx
0000714ce89db2ff  push rdi
0000714ce89db300  push rsi
0000714ce89db301  push r8
0000714ce89db303  push r9
0000714ce89db305  push r10
0000714ce89db307  push r11
0000714ce89db309  sub rsp, 0xF0
0000714ce89db310  vmovaps [rsp], xmm0
0000714ce89db315  vmovaps [rsp+0x10], xmm1
0000714ce89db31b  vmovaps [rsp+0x20], xmm2
0000714ce89db321  vmovaps [rsp+0x30], xmm3
0000714ce89db327  vmovaps [rsp+0x40], xmm5
0000714ce89db32d  vmovaps [rsp+0x50], xmm6
0000714ce89db333  vmovaps [rsp+0x60], xmm7
0000714ce89db339  vmovaps [rsp+0x70], xmm8
0000714ce89db33f  vmovaps [rsp+0x80], xmm9
0000714ce89db348  vmovaps [rsp+0x90], xmm10
0000714ce89db351  vmovaps [rsp+0xA0], xmm11
0000714ce89db35a  vmovaps [rsp+0xB0], xmm12
0000714ce89db363  vmovaps [rsp+0xC0], xmm13
0000714ce89db36c  vmovaps [rsp+0xD0], xmm14
0000714ce89db375  vmovaps [rsp+0xE0], xmm15
0000714ce89db37e  sub rsp, 0x30
0000714ce89db382  movaps [rsp], xmm4
0000714ce89db386  movaps [rsp+0x10], xmm3
0000714ce89db38b  movaps [rsp+0x20], xmm5
0000714ce89db390  lea rdi, [rsp]
0000714ce89db394  mov esi, 0x00
0000714ce89db399  mov rax, 0x57A55D340530
0000714ce89db3a3  call rax
0000714ce89db3a5  movaps xmm4, [rsp]
0000714ce89db3a9  add rsp, 0x30
0000714ce89db3ad  vmovaps xmm0, [rsp]
0000714ce89db3b2  vmovaps xmm1, [rsp+0x10]
0000714ce89db3b8  vmovaps xmm2, [rsp+0x20]
0000714ce89db3be  vmovaps xmm3, [rsp+0x30]
0000714ce89db3c4  vmovaps xmm5, [rsp+0x40]
0000714ce89db3ca  vmovaps xmm6, [rsp+0x50]
0000714ce89db3d0  vmovaps xmm7, [rsp+0x60]
0000714ce89db3d6  vmovaps xmm8, [rsp+0x70]
0000714ce89db3dc  vmovaps xmm9, [rsp+0x80]
0000714ce89db3e5  vmovaps xmm10, [rsp+0x90]
0000714ce89db3ee  vmovaps xmm11, [rsp+0xA0]
0000714ce89db3f7  vmovaps xmm12, [rsp+0xB0]
0000714ce89db400  vmovaps xmm13, [rsp+0xC0]
0000714ce89db409  vmovaps xmm14, [rsp+0xD0]
0000714ce89db412  vmovaps xmm15, [rsp+0xE0]
0000714ce89db41b  add rsp, 0xF0
0000714ce89db422  pop r11
0000714ce89db424  pop r10
0000714ce89db426  pop r9
0000714ce89db428  pop r8
0000714ce89db42a  pop rsi
0000714ce89db42b  pop rdi
0000714ce89db42c  pop rdx
0000714ce89db42d  pop rcx
0000714ce89db42e  pop rax
0000714ce89db42f  add rsp, 0x08
0000714ce89db433  jmp 0x0000714CE89D9134
0000714ce89db438  call 0x0000714CE88D64F0
0000714ce89db43d  jmp 0x0000714CE89D9141
0000714ce89db442  sub rsp, 0x08
0000714ce89db446  push rax
0000714ce89db447  push rcx
0000714ce89db448  push rdx
0000714ce89db449  push rdi
0000714ce89db44a  push rsi
0000714ce89db44b  push r8
0000714ce89db44d  push r9
0000714ce89db44f  push r10
0000714ce89db451  push r11
0000714ce89db453  sub rsp, 0xF0
0000714ce89db45a  vmovaps [rsp], xmm0
0000714ce89db45f  vmovaps [rsp+0x10], xmm1
0000714ce89db465  vmovaps [rsp+0x20], xmm2
0000714ce89db46b  vmovaps [rsp+0x30], xmm3
0000714ce89db471  vmovaps [rsp+0x40], xmm4
0000714ce89db477  vmovaps [rsp+0x50], xmm6
0000714ce89db47d  vmovaps [rsp+0x60], xmm7
0000714ce89db483  vmovaps [rsp+0x70], xmm8
0000714ce89db489  vmovaps [rsp+0x80], xmm9
0000714ce89db492  vmovaps [rsp+0x90], xmm10
0000714ce89db49b  vmovaps [rsp+0xA0], xmm11
0000714ce89db4a4  vmovaps [rsp+0xB0], xmm12
0000714ce89db4ad  vmovaps [rsp+0xC0], xmm13
0000714ce89db4b6  vmovaps [rsp+0xD0], xmm14
0000714ce89db4bf  vmovaps [rsp+0xE0], xmm15
0000714ce89db4c8  sub rsp, 0x30
0000714ce89db4cc  movaps [rsp], xmm5
0000714ce89db4d0  movaps [rsp+0x10], xmm6
0000714ce89db4d5  movaps [rsp+0x20], xmm3
0000714ce89db4da  lea rdi, [rsp]
0000714ce89db4de  mov esi, 0x00
0000714ce89db4e3  mov rax, 0x57A55D340530
0000714ce89db4ed  call rax
0000714ce89db4ef  movaps xmm5, [rsp]
0000714ce89db4f3  add rsp, 0x30
0000714ce89db4f7  vmovaps xmm0, [rsp]
0000714ce89db4fc  vmovaps xmm1, [rsp+0x10]
0000714ce89db502  vmovaps xmm2, [rsp+0x20]
0000714ce89db508  vmovaps xmm3, [rsp+0x30]
0000714ce89db50e  vmovaps xmm4, [rsp+0x40]
0000714ce89db514  vmovaps xmm6, [rsp+0x50]
0000714ce89db51a  vmovaps xmm7, [rsp+0x60]
0000714ce89db520  vmovaps xmm8, [rsp+0x70]
0000714ce89db526  vmovaps xmm9, [rsp+0x80]
0000714ce89db52f  vmovaps xmm10, [rsp+0x90]
0000714ce89db538  vmovaps xmm11, [rsp+0xA0]
0000714ce89db541  vmovaps xmm12, [rsp+0xB0]
0000714ce89db54a  vmovaps xmm13, [rsp+0xC0]
0000714ce89db553  vmovaps xmm14, [rsp+0xD0]
0000714ce89db55c  vmovaps xmm15, [rsp+0xE0]
0000714ce89db565  add rsp, 0xF0
0000714ce89db56c  pop r11
0000714ce89db56e  pop r10
0000714ce89db570  pop r9
0000714ce89db572  pop r8
0000714ce89db574  pop rsi
0000714ce89db575  pop rdi
0000714ce89db576  pop rdx
0000714ce89db577  pop rcx
0000714ce89db578  pop rax
0000714ce89db579  add rsp, 0x08
0000714ce89db57d  jmp 0x0000714CE89D9167
0000714ce89db582  sub rsp, 0x08
0000714ce89db586  push rax
0000714ce89db587  push rcx
0000714ce89db588  push rdx
0000714ce89db589  push rdi
0000714ce89db58a  push rsi
0000714ce89db58b  push r8
0000714ce89db58d  push r9
0000714ce89db58f  push r10
0000714ce89db591  push r11
0000714ce89db593  sub rsp, 0xF0
0000714ce89db59a  vmovaps [rsp], xmm0
0000714ce89db59f  vmovaps [rsp+0x10], xmm1
0000714ce89db5a5  vmovaps [rsp+0x20], xmm2
0000714ce89db5ab  vmovaps [rsp+0x30], xmm3
0000714ce89db5b1  vmovaps [rsp+0x40], xmm4
0000714ce89db5b7  vmovaps [rsp+0x50], xmm5
0000714ce89db5bd  vmovaps [rsp+0x60], xmm7
0000714ce89db5c3  vmovaps [rsp+0x70], xmm8
0000714ce89db5c9  vmovaps [rsp+0x80], xmm9
0000714ce89db5d2  vmovaps [rsp+0x90], xmm10
0000714ce89db5db  vmovaps [rsp+0xA0], xmm11
0000714ce89db5e4  vmovaps [rsp+0xB0], xmm12
0000714ce89db5ed  vmovaps [rsp+0xC0], xmm13
0000714ce89db5f6  vmovaps [rsp+0xD0], xmm14
0000714ce89db5ff  vmovaps [rsp+0xE0], xmm15
0000714ce89db608  sub rsp, 0x30
0000714ce89db60c  movaps [rsp], xmm6
0000714ce89db610  movaps [rsp+0x10], xmm9
0000714ce89db616  movaps [rsp+0x20], xmm1
0000714ce89db61b  lea rdi, [rsp]
0000714ce89db61f  mov esi, 0x00
0000714ce89db624  mov rax, 0x57A55D340530
0000714ce89db62e  call rax
0000714ce89db630  movaps xmm6, [rsp]
0000714ce89db634  add rsp, 0x30
0000714ce89db638  vmovaps xmm0, [rsp]
0000714ce89db63d  vmovaps xmm1, [rsp+0x10]
0000714ce89db643  vmovaps xmm2, [rsp+0x20]
0000714ce89db649  vmovaps xmm3, [rsp+0x30]
0000714ce89db64f  vmovaps xmm4, [rsp+0x40]
0000714ce89db655  vmovaps xmm5, [rsp+0x50]
0000714ce89db65b  vmovaps xmm7, [rsp+0x60]
0000714ce89db661  vmovaps xmm8, [rsp+0x70]
0000714ce89db667  vmovaps xmm9, [rsp+0x80]
0000714ce89db670  vmovaps xmm10, [rsp+0x90]
0000714ce89db679  vmovaps xmm11, [rsp+0xA0]
0000714ce89db682  vmovaps xmm12, [rsp+0xB0]
0000714ce89db68b  vmovaps xmm13, [rsp+0xC0]
0000714ce89db694  vmovaps xmm14, [rsp+0xD0]
0000714ce89db69d  vmovaps xmm15, [rsp+0xE0]
0000714ce89db6a6  add rsp, 0xF0
0000714ce89db6ad  pop r11
0000714ce89db6af  pop r10
0000714ce89db6b1  pop r9
0000714ce89db6b3  pop r8
0000714ce89db6b5  pop rsi
0000714ce89db6b6  pop rdi
0000714ce89db6b7  pop rdx
0000714ce89db6b8  pop rcx
0000714ce89db6b9  pop rax
0000714ce89db6ba  add rsp, 0x08
0000714ce89db6be  jmp 0x0000714CE89D918B
0000714ce89db6c3  sub rsp, 0x08
0000714ce89db6c7  push rax
0000714ce89db6c8  push rcx
0000714ce89db6c9  push rdx
0000714ce89db6ca  push rdi
0000714ce89db6cb  push rsi
0000714ce89db6cc  push r8
0000714ce89db6ce  push r9
0000714ce89db6d0  push r10
0000714ce89db6d2  push r11
0000714ce89db6d4  sub rsp, 0xF0
0000714ce89db6db  vmovaps [rsp], xmm0
0000714ce89db6e0  vmovaps [rsp+0x10], xmm1
0000714ce89db6e6  vmovaps [rsp+0x20], xmm2
0000714ce89db6ec  vmovaps [rsp+0x30], xmm3
0000714ce89db6f2  vmovaps [rsp+0x40], xmm4
0000714ce89db6f8  vmovaps [rsp+0x50], xmm5
0000714ce89db6fe  vmovaps [rsp+0x60], xmm6
0000714ce89db704  vmovaps [rsp+0x70], xmm7
0000714ce89db70a  vmovaps [rsp+0x80], xmm8
0000714ce89db713  vmovaps [rsp+0x90], xmm10
0000714ce89db71c  vmovaps [rsp+0xA0], xmm11
0000714ce89db725  vmovaps [rsp+0xB0], xmm12
0000714ce89db72e  vmovaps [rsp+0xC0], xmm13
0000714ce89db737  vmovaps [rsp+0xD0], xmm14
0000714ce89db740  vmovaps [rsp+0xE0], xmm15
0000714ce89db749  sub rsp, 0x30
0000714ce89db74d  movaps [rsp], xmm9
0000714ce89db752  movaps [rsp+0x10], xmm3
0000714ce89db757  movaps [rsp+0x20], xmm1
0000714ce89db75c  lea rdi, [rsp]
0000714ce89db760  mov esi, 0x00
0000714ce89db765  mov rax, 0x57A55D340530
0000714ce89db76f  call rax
0000714ce89db771  movaps xmm9, [rsp]
0000714ce89db776  add rsp, 0x30
0000714ce89db77a  vmovaps xmm0, [rsp]
0000714ce89db77f  vmovaps xmm1, [rsp+0x10]
0000714ce89db785  vmovaps xmm2, [rsp+0x20]
0000714ce89db78b  vmovaps xmm3, [rsp+0x30]
0000714ce89db791  vmovaps xmm4, [rsp+0x40]
0000714ce89db797  vmovaps xmm5, [rsp+0x50]
0000714ce89db79d  vmovaps xmm6, [rsp+0x60]
0000714ce89db7a3  vmovaps xmm7, [rsp+0x70]
0000714ce89db7a9  vmovaps xmm8, [rsp+0x80]
0000714ce89db7b2  vmovaps xmm10, [rsp+0x90]
0000714ce89db7bb  vmovaps xmm11, [rsp+0xA0]
0000714ce89db7c4  vmovaps xmm12, [rsp+0xB0]
0000714ce89db7cd  vmovaps xmm13, [rsp+0xC0]
0000714ce89db7d6  vmovaps xmm14, [rsp+0xD0]
0000714ce89db7df  vmovaps xmm15, [rsp+0xE0]
0000714ce89db7e8  add rsp, 0xF0
0000714ce89db7ef  pop r11
0000714ce89db7f1  pop r10
0000714ce89db7f3  pop r9
0000714ce89db7f5  pop r8
0000714ce89db7f7  pop rsi
0000714ce89db7f8  pop rdi
0000714ce89db7f9  pop rdx
0000714ce89db7fa  pop rcx
0000714ce89db7fb  pop rax
0000714ce89db7fc  add rsp, 0x08
0000714ce89db800  jmp 0x0000714CE89D91D7
0000714ce89db805  call 0x0000714CE88D64F0
0000714ce89db80a  jmp 0x0000714CE89D91E4
0000714ce89db80f  sub rsp, 0x08
0000714ce89db813  push rax
0000714ce89db814  push rcx
0000714ce89db815  push rdx
0000714ce89db816  push rdi
0000714ce89db817  push rsi
0000714ce89db818  push r8
0000714ce89db81a  push r9
0000714ce89db81c  push r10
0000714ce89db81e  push r11
0000714ce89db820  sub rsp, 0xF0
0000714ce89db827  vmovaps [rsp], xmm0
0000714ce89db82c  vmovaps [rsp+0x10], xmm1
0000714ce89db832  vmovaps [rsp+0x20], xmm2
0000714ce89db838  vmovaps [rsp+0x30], xmm3
0000714ce89db83e  vmovaps [rsp+0x40], xmm4
0000714ce89db844  vmovaps [rsp+0x50], xmm5
0000714ce89db84a  vmovaps [rsp+0x60], xmm6
0000714ce89db850  vmovaps [rsp+0x70], xmm7
0000714ce89db856  vmovaps [rsp+0x80], xmm8
0000714ce89db85f  vmovaps [rsp+0x90], xmm9
0000714ce89db868  vmovaps [rsp+0xA0], xmm10
0000714ce89db871  vmovaps [rsp+0xB0], xmm11
0000714ce89db87a  vmovaps [rsp+0xC0], xmm12
0000714ce89db883  vmovaps [rsp+0xD0], xmm13
0000714ce89db88c  vmovaps [rsp+0xE0], xmm14
0000714ce89db895  sub rsp, 0x30
0000714ce89db899  movaps [rsp], xmm15
0000714ce89db89e  movaps [rsp+0x10], xmm3
0000714ce89db8a3  movaps [rsp+0x20], xmm7
0000714ce89db8a8  lea rdi, [rsp]
0000714ce89db8ac  mov esi, 0x00
0000714ce89db8b1  mov rax, 0x57A55D340530
0000714ce89db8bb  call rax
0000714ce89db8bd  movaps xmm15, [rsp]
0000714ce89db8c2  add rsp, 0x30
0000714ce89db8c6  vmovaps xmm0, [rsp]
0000714ce89db8cb  vmovaps xmm1, [rsp+0x10]
0000714ce89db8d1  vmovaps xmm2, [rsp+0x20]
0000714ce89db8d7  vmovaps xmm3, [rsp+0x30]
0000714ce89db8dd  vmovaps xmm4, [rsp+0x40]
0000714ce89db8e3  vmovaps xmm5, [rsp+0x50]
0000714ce89db8e9  vmovaps xmm6, [rsp+0x60]
0000714ce89db8ef  vmovaps xmm7, [rsp+0x70]
0000714ce89db8f5  vmovaps xmm8, [rsp+0x80]
0000714ce89db8fe  vmovaps xmm9, [rsp+0x90]
0000714ce89db907  vmovaps xmm10, [rsp+0xA0]
0000714ce89db910  vmovaps xmm11, [rsp+0xB0]
0000714ce89db919  vmovaps xmm12, [rsp+0xC0]
0000714ce89db922  vmovaps xmm13, [rsp+0xD0]
0000714ce89db92b  vmovaps xmm14, [rsp+0xE0]
0000714ce89db934  add rsp, 0xF0
0000714ce89db93b  pop r11
0000714ce89db93d  pop r10
0000714ce89db93f  pop r9
0000714ce89db941  pop r8
0000714ce89db943  pop rsi
0000714ce89db944  pop rdi
0000714ce89db945  pop rdx
0000714ce89db946  pop rcx
0000714ce89db947  pop rax
0000714ce89db948  add rsp, 0x08
0000714ce89db94c  jmp 0x0000714CE89D9210
0000714ce89db951  sub rsp, 0x08
0000714ce89db955  push rax
0000714ce89db956  push rcx
0000714ce89db957  push rdx
0000714ce89db958  push rdi
0000714ce89db959  push rsi
0000714ce89db95a  push r8
0000714ce89db95c  push r9
0000714ce89db95e  push r10
0000714ce89db960  push r11
0000714ce89db962  sub rsp, 0xF0
0000714ce89db969  vmovaps [rsp], xmm0
0000714ce89db96e  vmovaps [rsp+0x10], xmm1
0000714ce89db974  vmovaps [rsp+0x20], xmm2
0000714ce89db97a  vmovaps [rsp+0x30], xmm4
0000714ce89db980  vmovaps [rsp+0x40], xmm5
0000714ce89db986  vmovaps [rsp+0x50], xmm6
0000714ce89db98c  vmovaps [rsp+0x60], xmm7
0000714ce89db992  vmovaps [rsp+0x70], xmm8
0000714ce89db998  vmovaps [rsp+0x80], xmm9
0000714ce89db9a1  vmovaps [rsp+0x90], xmm10
0000714ce89db9aa  vmovaps [rsp+0xA0], xmm11
0000714ce89db9b3  vmovaps [rsp+0xB0], xmm12
0000714ce89db9bc  vmovaps [rsp+0xC0], xmm13
0000714ce89db9c5  vmovaps [rsp+0xD0], xmm14
0000714ce89db9ce  vmovaps [rsp+0xE0], xmm15
0000714ce89db9d7  sub rsp, 0x30
0000714ce89db9db  movaps [rsp], xmm3
0000714ce89db9df  movaps [rsp+0x10], xmm1
0000714ce89db9e4  movaps [rsp+0x20], xmm15
0000714ce89db9ea  lea rdi, [rsp]
0000714ce89db9ee  mov esi, 0x00
0000714ce89db9f3  mov rax, 0x57A55D340530
0000714ce89db9fd  call rax
0000714ce89db9ff  movaps xmm3, [rsp]
0000714ce89dba03  add rsp, 0x30
0000714ce89dba07  vmovaps xmm0, [rsp]
0000714ce89dba0c  vmovaps xmm1, [rsp+0x10]
0000714ce89dba12  vmovaps xmm2, [rsp+0x20]
0000714ce89dba18  vmovaps xmm4, [rsp+0x30]
0000714ce89dba1e  vmovaps xmm5, [rsp+0x40]
0000714ce89dba24  vmovaps xmm6, [rsp+0x50]
0000714ce89dba2a  vmovaps xmm7, [rsp+0x60]
0000714ce89dba30  vmovaps xmm8, [rsp+0x70]
0000714ce89dba36  vmovaps xmm9, [rsp+0x80]
0000714ce89dba3f  vmovaps xmm10, [rsp+0x90]
0000714ce89dba48  vmovaps xmm11, [rsp+0xA0]
0000714ce89dba51  vmovaps xmm12, [rsp+0xB0]
0000714ce89dba5a  vmovaps xmm13, [rsp+0xC0]
0000714ce89dba63  vmovaps xmm14, [rsp+0xD0]
0000714ce89dba6c  vmovaps xmm15, [rsp+0xE0]
0000714ce89dba75  add rsp, 0xF0
0000714ce89dba7c  pop r11
0000714ce89dba7e  pop r10
0000714ce89dba80  pop r9
0000714ce89dba82  pop r8
0000714ce89dba84  pop rsi
0000714ce89dba85  pop rdi
0000714ce89dba86  pop rdx
0000714ce89dba87  pop rcx
0000714ce89dba88  pop rax
0000714ce89dba89  add rsp, 0x08
0000714ce89dba8d  jmp 0x0000714CE89D929F
0000714ce89dba92  call 0x0000714CE88D64F0
0000714ce89dba97  jmp 0x0000714CE89D92A9
0000714ce89dba9c  sub rsp, 0x08
0000714ce89dbaa0  push rax
0000714ce89dbaa1  push rcx
0000714ce89dbaa2  push rdx
0000714ce89dbaa3  push rdi
0000714ce89dbaa4  push rsi
0000714ce89dbaa5  push r8
0000714ce89dbaa7  push r9
0000714ce89dbaa9  push r10
0000714ce89dbaab  push r11
0000714ce89dbaad  sub rsp, 0xF0
0000714ce89dbab4  vmovaps [rsp], xmm0
0000714ce89dbab9  vmovaps [rsp+0x10], xmm1
0000714ce89dbabf  vmovaps [rsp+0x20], xmm2
0000714ce89dbac5  vmovaps [rsp+0x30], xmm3
0000714ce89dbacb  vmovaps [rsp+0x40], xmm4
0000714ce89dbad1  vmovaps [rsp+0x50], xmm5
0000714ce89dbad7  vmovaps [rsp+0x60], xmm6
0000714ce89dbadd  vmovaps [rsp+0x70], xmm7
0000714ce89dbae3  vmovaps [rsp+0x80], xmm8
0000714ce89dbaec  vmovaps [rsp+0x90], xmm9
0000714ce89dbaf5  vmovaps [rsp+0xA0], xmm10
0000714ce89dbafe  vmovaps [rsp+0xB0], xmm11
0000714ce89dbb07  vmovaps [rsp+0xC0], xmm12
0000714ce89dbb10  vmovaps [rsp+0xD0], xmm13
0000714ce89dbb19  vmovaps [rsp+0xE0], xmm14
0000714ce89dbb22  sub rsp, 0x30
0000714ce89dbb26  movaps [rsp], xmm15
0000714ce89dbb2b  movaps [rsp+0x10], xmm14
0000714ce89dbb31  movaps [rsp+0x20], xmm4
0000714ce89dbb36  lea rdi, [rsp]
0000714ce89dbb3a  mov esi, 0x00
0000714ce89dbb3f  mov rax, 0x57A55D340530
0000714ce89dbb49  call rax
0000714ce89dbb4b  movaps xmm15, [rsp]
0000714ce89dbb50  add rsp, 0x30
0000714ce89dbb54  vmovaps xmm0, [rsp]
0000714ce89dbb59  vmovaps xmm1, [rsp+0x10]
0000714ce89dbb5f  vmovaps xmm2, [rsp+0x20]
0000714ce89dbb65  vmovaps xmm3, [rsp+0x30]
0000714ce89dbb6b  vmovaps xmm4, [rsp+0x40]
0000714ce89dbb71  vmovaps xmm5, [rsp+0x50]
0000714ce89dbb77  vmovaps xmm6, [rsp+0x60]
0000714ce89dbb7d  vmovaps xmm7, [rsp+0x70]
0000714ce89dbb83  vmovaps xmm8, [rsp+0x80]
0000714ce89dbb8c  vmovaps xmm9, [rsp+0x90]
0000714ce89dbb95  vmovaps xmm10, [rsp+0xA0]
0000714ce89dbb9e  vmovaps xmm11, [rsp+0xB0]
0000714ce89dbba7  vmovaps xmm12, [rsp+0xC0]
0000714ce89dbbb0  vmovaps xmm13, [rsp+0xD0]
0000714ce89dbbb9  vmovaps xmm14, [rsp+0xE0]
0000714ce89dbbc2  add rsp, 0xF0
0000714ce89dbbc9  pop r11
0000714ce89dbbcb  pop r10
0000714ce89dbbcd  pop r9
0000714ce89dbbcf  pop r8
0000714ce89dbbd1  pop rsi
0000714ce89dbbd2  pop rdi
0000714ce89dbbd3  pop rdx
0000714ce89dbbd4  pop rcx
0000714ce89dbbd5  pop rax
0000714ce89dbbd6  add rsp, 0x08
0000714ce89dbbda  jmp 0x0000714CE89D92D7
0000714ce89dbbdf  sub rsp, 0x08
0000714ce89dbbe3  push rax
0000714ce89dbbe4  push rcx
0000714ce89dbbe5  push rdx
0000714ce89dbbe6  push rdi
0000714ce89dbbe7  push rsi
0000714ce89dbbe8  push r8
0000714ce89dbbea  push r9
0000714ce89dbbec  push r10
0000714ce89dbbee  push r11
0000714ce89dbbf0  sub rsp, 0xF0
0000714ce89dbbf7  vmovaps [rsp], xmm0
0000714ce89dbbfc  vmovaps [rsp+0x10], xmm1
0000714ce89dbc02  vmovaps [rsp+0x20], xmm2
0000714ce89dbc08  vmovaps [rsp+0x30], xmm3
0000714ce89dbc0e  vmovaps [rsp+0x40], xmm4
0000714ce89dbc14  vmovaps [rsp+0x50], xmm5
0000714ce89dbc1a  vmovaps [rsp+0x60], xmm6
0000714ce89dbc20  vmovaps [rsp+0x70], xmm7
0000714ce89dbc26  vmovaps [rsp+0x80], xmm8
0000714ce89dbc2f  vmovaps [rsp+0x90], xmm9
0000714ce89dbc38  vmovaps [rsp+0xA0], xmm10
0000714ce89dbc41  vmovaps [rsp+0xB0], xmm11
0000714ce89dbc4a  vmovaps [rsp+0xC0], xmm12
0000714ce89dbc53  vmovaps [rsp+0xD0], xmm13
0000714ce89dbc5c  vmovaps [rsp+0xE0], xmm15
0000714ce89dbc65  sub rsp, 0x30
0000714ce89dbc69  movaps [rsp], xmm14
0000714ce89dbc6e  movaps [rsp+0x10], xmm2
0000714ce89dbc73  movaps [rsp+0x20], xmm1
0000714ce89dbc78  lea rdi, [rsp]
0000714ce89dbc7c  mov esi, 0x00
0000714ce89dbc81  mov rax, 0x57A55D340530
0000714ce89dbc8b  call rax
0000714ce89dbc8d  movaps xmm14, [rsp]
0000714ce89dbc92  add rsp, 0x30
0000714ce89dbc96  vmovaps xmm0, [rsp]
0000714ce89dbc9b  vmovaps xmm1, [rsp+0x10]
0000714ce89dbca1  vmovaps xmm2, [rsp+0x20]
0000714ce89dbca7  vmovaps xmm3, [rsp+0x30]
0000714ce89dbcad  vmovaps xmm4, [rsp+0x40]
0000714ce89dbcb3  vmovaps xmm5, [rsp+0x50]
0000714ce89dbcb9  vmovaps xmm6, [rsp+0x60]
0000714ce89dbcbf  vmovaps xmm7, [rsp+0x70]
0000714ce89dbcc5  vmovaps xmm8, [rsp+0x80]
0000714ce89dbcce  vmovaps xmm9, [rsp+0x90]
0000714ce89dbcd7  vmovaps xmm10, [rsp+0xA0]
0000714ce89dbce0  vmovaps xmm11, [rsp+0xB0]
0000714ce89dbce9  vmovaps xmm12, [rsp+0xC0]
0000714ce89dbcf2  vmovaps xmm13, [rsp+0xD0]
0000714ce89dbcfb  vmovaps xmm15, [rsp+0xE0]
0000714ce89dbd04  add rsp, 0xF0
0000714ce89dbd0b  pop r11
0000714ce89dbd0d  pop r10
0000714ce89dbd0f  pop r9
0000714ce89dbd11  pop r8
0000714ce89dbd13  pop rsi
0000714ce89dbd14  pop rdi
0000714ce89dbd15  pop rdx
0000714ce89dbd16  pop rcx
0000714ce89dbd17  pop rax
0000714ce89dbd18  add rsp, 0x08
0000714ce89dbd1c  jmp 0x0000714CE89D92FD
0000714ce89dbd21  sub rsp, 0x08
0000714ce89dbd25  push rax
0000714ce89dbd26  push rcx
0000714ce89dbd27  push rdx
0000714ce89dbd28  push rdi
0000714ce89dbd29  push rsi
0000714ce89dbd2a  push r8
0000714ce89dbd2c  push r9
0000714ce89dbd2e  push r10
0000714ce89dbd30  push r11
0000714ce89dbd32  sub rsp, 0xF0
0000714ce89dbd39  vmovaps [rsp], xmm0
0000714ce89dbd3e  vmovaps [rsp+0x10], xmm2
0000714ce89dbd44  vmovaps [rsp+0x20], xmm3
0000714ce89dbd4a  vmovaps [rsp+0x30], xmm4
0000714ce89dbd50  vmovaps [rsp+0x40], xmm5
0000714ce89dbd56  vmovaps [rsp+0x50], xmm6
0000714ce89dbd5c  vmovaps [rsp+0x60], xmm7
0000714ce89dbd62  vmovaps [rsp+0x70], xmm8
0000714ce89dbd68  vmovaps [rsp+0x80], xmm9
0000714ce89dbd71  vmovaps [rsp+0x90], xmm10
0000714ce89dbd7a  vmovaps [rsp+0xA0], xmm11
0000714ce89dbd83  vmovaps [rsp+0xB0], xmm12
0000714ce89dbd8c  vmovaps [rsp+0xC0], xmm13
0000714ce89dbd95  vmovaps [rsp+0xD0], xmm14
0000714ce89dbd9e  vmovaps [rsp+0xE0], xmm15
0000714ce89dbda7  sub rsp, 0x30
0000714ce89dbdab  movaps [rsp], xmm1
0000714ce89dbdaf  movaps [rsp+0x10], xmm4
0000714ce89dbdb4  movaps [rsp+0x20], xmm9
0000714ce89dbdba  lea rdi, [rsp]
0000714ce89dbdbe  mov esi, 0x00
0000714ce89dbdc3  mov rax, 0x57A55D340530
0000714ce89dbdcd  call rax
0000714ce89dbdcf  movaps xmm1, [rsp]
0000714ce89dbdd3  add rsp, 0x30
0000714ce89dbdd7  vmovaps xmm0, [rsp]
0000714ce89dbddc  vmovaps xmm2, [rsp+0x10]
0000714ce89dbde2  vmovaps xmm3, [rsp+0x20]
0000714ce89dbde8  vmovaps xmm4, [rsp+0x30]
0000714ce89dbdee  vmovaps xmm5, [rsp+0x40]
0000714ce89dbdf4  vmovaps xmm6, [rsp+0x50]
0000714ce89dbdfa  vmovaps xmm7, [rsp+0x60]
0000714ce89dbe00  vmovaps xmm8, [rsp+0x70]
0000714ce89dbe06  vmovaps xmm9, [rsp+0x80]
0000714ce89dbe0f  vmovaps xmm10, [rsp+0x90]
0000714ce89dbe18  vmovaps xmm11, [rsp+0xA0]
0000714ce89dbe21  vmovaps xmm12, [rsp+0xB0]
0000714ce89dbe2a  vmovaps xmm13, [rsp+0xC0]
0000714ce89dbe33  vmovaps xmm14, [rsp+0xD0]
0000714ce89dbe3c  vmovaps xmm15, [rsp+0xE0]
0000714ce89dbe45  add rsp, 0xF0
0000714ce89dbe4c  pop r11
0000714ce89dbe4e  pop r10
0000714ce89dbe50  pop r9
0000714ce89dbe52  pop r8
0000714ce89dbe54  pop rsi
0000714ce89dbe55  pop rdi
0000714ce89dbe56  pop rdx
0000714ce89dbe57  pop rcx
0000714ce89dbe58  pop rax
0000714ce89dbe59  add rsp, 0x08
0000714ce89dbe5d  jmp 0x0000714CE89D931B
0000714ce89dbe62  sub rsp, 0x08
0000714ce89dbe66  push rax
0000714ce89dbe67  push rcx
0000714ce89dbe68  push rdx
0000714ce89dbe69  push rdi
0000714ce89dbe6a  push rsi
0000714ce89dbe6b  push r8
0000714ce89dbe6d  push r9
0000714ce89dbe6f  push r10
0000714ce89dbe71  push r11
0000714ce89dbe73  sub rsp, 0xF0
0000714ce89dbe7a  vmovaps [rsp], xmm0
0000714ce89dbe7f  vmovaps [rsp+0x10], xmm1
0000714ce89dbe85  vmovaps [rsp+0x20], xmm2
0000714ce89dbe8b  vmovaps [rsp+0x30], xmm3
0000714ce89dbe91  vmovaps [rsp+0x40], xmm5
0000714ce89dbe97  vmovaps [rsp+0x50], xmm6
0000714ce89dbe9d  vmovaps [rsp+0x60], xmm7
0000714ce89dbea3  vmovaps [rsp+0x70], xmm8
0000714ce89dbea9  vmovaps [rsp+0x80], xmm9
0000714ce89dbeb2  vmovaps [rsp+0x90], xmm10
0000714ce89dbebb  vmovaps [rsp+0xA0], xmm11
0000714ce89dbec4  vmovaps [rsp+0xB0], xmm12
0000714ce89dbecd  vmovaps [rsp+0xC0], xmm13
0000714ce89dbed6  vmovaps [rsp+0xD0], xmm14
0000714ce89dbedf  vmovaps [rsp+0xE0], xmm15
0000714ce89dbee8  sub rsp, 0x30
0000714ce89dbeec  movaps [rsp], xmm4
0000714ce89dbef0  movaps [rsp+0x10], xmm2
0000714ce89dbef5  movaps [rsp+0x20], xmm9
0000714ce89dbefb  lea rdi, [rsp]
0000714ce89dbeff  mov esi, 0x00
0000714ce89dbf04  mov rax, 0x57A55D340530
0000714ce89dbf0e  call rax
0000714ce89dbf10  movaps xmm4, [rsp]
0000714ce89dbf14  add rsp, 0x30
0000714ce89dbf18  vmovaps xmm0, [rsp]
0000714ce89dbf1d  vmovaps xmm1, [rsp+0x10]
0000714ce89dbf23  vmovaps xmm2, [rsp+0x20]
0000714ce89dbf29  vmovaps xmm3, [rsp+0x30]
0000714ce89dbf2f  vmovaps xmm5, [rsp+0x40]
0000714ce89dbf35  vmovaps xmm6, [rsp+0x50]
0000714ce89dbf3b  vmovaps xmm7, [rsp+0x60]
0000714ce89dbf41  vmovaps xmm8, [rsp+0x70]
0000714ce89dbf47  vmovaps xmm9, [rsp+0x80]
0000714ce89dbf50  vmovaps xmm10, [rsp+0x90]
0000714ce89dbf59  vmovaps xmm11, [rsp+0xA0]
0000714ce89dbf62  vmovaps xmm12, [rsp+0xB0]
0000714ce89dbf6b  vmovaps xmm13, [rsp+0xC0]
0000714ce89dbf74  vmovaps xmm14, [rsp+0xD0]
0000714ce89dbf7d  vmovaps xmm15, [rsp+0xE0]
0000714ce89dbf86  add rsp, 0xF0
0000714ce89dbf8d  pop r11
0000714ce89dbf8f  pop r10
0000714ce89dbf91  pop r9
0000714ce89dbf93  pop r8
0000714ce89dbf95  pop rsi
0000714ce89dbf96  pop rdi
0000714ce89dbf97  pop rdx
0000714ce89dbf98  pop rcx
0000714ce89dbf99  pop rax
0000714ce89dbf9a  add rsp, 0x08
0000714ce89dbf9e  jmp 0x0000714CE89D934B
0000714ce89dbfa3  sub rsp, 0x08
0000714ce89dbfa7  push rax
0000714ce89dbfa8  push rcx
0000714ce89dbfa9  push rdx
0000714ce89dbfaa  push rdi
0000714ce89dbfab  push rsi
0000714ce89dbfac  push r8
0000714ce89dbfae  push r9
0000714ce89dbfb0  push r10
0000714ce89dbfb2  push r11
0000714ce89dbfb4  sub rsp, 0xF0
0000714ce89dbfbb  vmovaps [rsp], xmm0
0000714ce89dbfc0  vmovaps [rsp+0x10], xmm1
0000714ce89dbfc6  vmovaps [rsp+0x20], xmm2
0000714ce89dbfcc  vmovaps [rsp+0x30], xmm3
0000714ce89dbfd2  vmovaps [rsp+0x40], xmm4
0000714ce89dbfd8  vmovaps [rsp+0x50], xmm5
0000714ce89dbfde  vmovaps [rsp+0x60], xmm6
0000714ce89dbfe4  vmovaps [rsp+0x70], xmm7
0000714ce89dbfea  vmovaps [rsp+0x80], xmm8
0000714ce89dbff3  vmovaps [rsp+0x90], xmm10
0000714ce89dbffc  vmovaps [rsp+0xA0], xmm11
0000714ce89dc005  vmovaps [rsp+0xB0], xmm12
0000714ce89dc00e  vmovaps [rsp+0xC0], xmm13
0000714ce89dc017  vmovaps [rsp+0xD0], xmm14
0000714ce89dc020  vmovaps [rsp+0xE0], xmm15
0000714ce89dc029  sub rsp, 0x30
0000714ce89dc02d  movaps [rsp], xmm9
0000714ce89dc032  movaps [rsp+0x10], xmm2
0000714ce89dc037  movaps [rsp+0x20], xmm1
0000714ce89dc03c  lea rdi, [rsp]
0000714ce89dc040  mov esi, 0x00
0000714ce89dc045  mov rax, 0x57A55D340530
0000714ce89dc04f  call rax
0000714ce89dc051  movaps xmm9, [rsp]
0000714ce89dc056  add rsp, 0x30
0000714ce89dc05a  vmovaps xmm0, [rsp]
0000714ce89dc05f  vmovaps xmm1, [rsp+0x10]
0000714ce89dc065  vmovaps xmm2, [rsp+0x20]
0000714ce89dc06b  vmovaps xmm3, [rsp+0x30]
0000714ce89dc071  vmovaps xmm4, [rsp+0x40]
0000714ce89dc077  vmovaps xmm5, [rsp+0x50]
0000714ce89dc07d  vmovaps xmm6, [rsp+0x60]
0000714ce89dc083  vmovaps xmm7, [rsp+0x70]
0000714ce89dc089  vmovaps xmm8, [rsp+0x80]
0000714ce89dc092  vmovaps xmm10, [rsp+0x90]
0000714ce89dc09b  vmovaps xmm11, [rsp+0xA0]
0000714ce89dc0a4  vmovaps xmm12, [rsp+0xB0]
0000714ce89dc0ad  vmovaps xmm13, [rsp+0xC0]
0000714ce89dc0b6  vmovaps xmm14, [rsp+0xD0]
0000714ce89dc0bf  vmovaps xmm15, [rsp+0xE0]
0000714ce89dc0c8  add rsp, 0xF0
0000714ce89dc0cf  pop r11
0000714ce89dc0d1  pop r10
0000714ce89dc0d3  pop r9
0000714ce89dc0d5  pop r8
0000714ce89dc0d7  pop rsi
0000714ce89dc0d8  pop rdi
0000714ce89dc0d9  pop rdx
0000714ce89dc0da  pop rcx
0000714ce89dc0db  pop rax
0000714ce89dc0dc  add rsp, 0x08
0000714ce89dc0e0  jmp 0x0000714CE89D9381
0000714ce89dc0e5  sub rsp, 0x08
0000714ce89dc0e9  push rax
0000714ce89dc0ea  push rcx
0000714ce89dc0eb  push rdx
0000714ce89dc0ec  push rdi
0000714ce89dc0ed  push rsi
0000714ce89dc0ee  push r8
0000714ce89dc0f0  push r9
0000714ce89dc0f2  push r10
0000714ce89dc0f4  push r11
0000714ce89dc0f6  sub rsp, 0xF0
0000714ce89dc0fd  vmovaps [rsp], xmm0
0000714ce89dc102  vmovaps [rsp+0x10], xmm2
0000714ce89dc108  vmovaps [rsp+0x20], xmm3
0000714ce89dc10e  vmovaps [rsp+0x30], xmm4
0000714ce89dc114  vmovaps [rsp+0x40], xmm5
0000714ce89dc11a  vmovaps [rsp+0x50], xmm6
0000714ce89dc120  vmovaps [rsp+0x60], xmm7
0000714ce89dc126  vmovaps [rsp+0x70], xmm8
0000714ce89dc12c  vmovaps [rsp+0x80], xmm9
0000714ce89dc135  vmovaps [rsp+0x90], xmm10
0000714ce89dc13e  vmovaps [rsp+0xA0], xmm11
0000714ce89dc147  vmovaps [rsp+0xB0], xmm12
0000714ce89dc150  vmovaps [rsp+0xC0], xmm13
0000714ce89dc159  vmovaps [rsp+0xD0], xmm14
0000714ce89dc162  vmovaps [rsp+0xE0], xmm15
0000714ce89dc16b  sub rsp, 0x30
0000714ce89dc16f  movaps [rsp], xmm1
0000714ce89dc173  movaps [rsp+0x10], xmm15
0000714ce89dc179  movaps [rsp+0x20], xmm6
0000714ce89dc17e  lea rdi, [rsp]
0000714ce89dc182  mov esi, 0x00
0000714ce89dc187  mov rax, 0x57A55D340530
0000714ce89dc191  call rax
0000714ce89dc193  movaps xmm1, [rsp]
0000714ce89dc197  add rsp, 0x30
0000714ce89dc19b  vmovaps xmm0, [rsp]
0000714ce89dc1a0  vmovaps xmm2, [rsp+0x10]
0000714ce89dc1a6  vmovaps xmm3, [rsp+0x20]
0000714ce89dc1ac  vmovaps xmm4, [rsp+0x30]
0000714ce89dc1b2  vmovaps xmm5, [rsp+0x40]
0000714ce89dc1b8  vmovaps xmm6, [rsp+0x50]
0000714ce89dc1be  vmovaps xmm7, [rsp+0x60]
0000714ce89dc1c4  vmovaps xmm8, [rsp+0x70]
0000714ce89dc1ca  vmovaps xmm9, [rsp+0x80]
0000714ce89dc1d3  vmovaps xmm10, [rsp+0x90]
0000714ce89dc1dc  vmovaps xmm11, [rsp+0xA0]
0000714ce89dc1e5  vmovaps xmm12, [rsp+0xB0]
0000714ce89dc1ee  vmovaps xmm13, [rsp+0xC0]
0000714ce89dc1f7  vmovaps xmm14, [rsp+0xD0]
0000714ce89dc200  vmovaps xmm15, [rsp+0xE0]
0000714ce89dc209  add rsp, 0xF0
0000714ce89dc210  pop r11
0000714ce89dc212  pop r10
0000714ce89dc214  pop r9
0000714ce89dc216  pop r8
0000714ce89dc218  pop rsi
0000714ce89dc219  pop rdi
0000714ce89dc21a  pop rdx
0000714ce89dc21b  pop rcx
0000714ce89dc21c  pop rax
0000714ce89dc21d  add rsp, 0x08
0000714ce89dc221  jmp 0x0000714CE89D93A2
0000714ce89dc226  sub rsp, 0x08
0000714ce89dc22a  push rax
0000714ce89dc22b  push rcx
0000714ce89dc22c  push rdx
0000714ce89dc22d  push rdi
0000714ce89dc22e  push rsi
0000714ce89dc22f  push r8
0000714ce89dc231  push r9
0000714ce89dc233  push r10
0000714ce89dc235  push r11
0000714ce89dc237  sub rsp, 0xF0
0000714ce89dc23e  vmovaps [rsp], xmm0
0000714ce89dc243  vmovaps [rsp+0x10], xmm1
0000714ce89dc249  vmovaps [rsp+0x20], xmm2
0000714ce89dc24f  vmovaps [rsp+0x30], xmm3
0000714ce89dc255  vmovaps [rsp+0x40], xmm4
0000714ce89dc25b  vmovaps [rsp+0x50], xmm5
0000714ce89dc261  vmovaps [rsp+0x60], xmm6
0000714ce89dc267  vmovaps [rsp+0x70], xmm7
0000714ce89dc26d  vmovaps [rsp+0x80], xmm8
0000714ce89dc276  vmovaps [rsp+0x90], xmm9
0000714ce89dc27f  vmovaps [rsp+0xA0], xmm10
0000714ce89dc288  vmovaps [rsp+0xB0], xmm11
0000714ce89dc291  vmovaps [rsp+0xC0], xmm12
0000714ce89dc29a  vmovaps [rsp+0xD0], xmm13
0000714ce89dc2a3  vmovaps [rsp+0xE0], xmm14
0000714ce89dc2ac  sub rsp, 0x30
0000714ce89dc2b0  movaps [rsp], xmm15
0000714ce89dc2b5  movaps [rsp+0x10], xmm5
0000714ce89dc2ba  movaps [rsp+0x20], xmm3
0000714ce89dc2bf  lea rdi, [rsp]
0000714ce89dc2c3  mov esi, 0x00
0000714ce89dc2c8  mov rax, 0x57A55D340530
0000714ce89dc2d2  call rax
0000714ce89dc2d4  movaps xmm15, [rsp]
0000714ce89dc2d9  add rsp, 0x30
0000714ce89dc2dd  vmovaps xmm0, [rsp]
0000714ce89dc2e2  vmovaps xmm1, [rsp+0x10]
0000714ce89dc2e8  vmovaps xmm2, [rsp+0x20]
0000714ce89dc2ee  vmovaps xmm3, [rsp+0x30]
0000714ce89dc2f4  vmovaps xmm4, [rsp+0x40]
0000714ce89dc2fa  vmovaps xmm5, [rsp+0x50]
0000714ce89dc300  vmovaps xmm6, [rsp+0x60]
0000714ce89dc306  vmovaps xmm7, [rsp+0x70]
0000714ce89dc30c  vmovaps xmm8, [rsp+0x80]
0000714ce89dc315  vmovaps xmm9, [rsp+0x90]
0000714ce89dc31e  vmovaps xmm10, [rsp+0xA0]
0000714ce89dc327  vmovaps xmm11, [rsp+0xB0]
0000714ce89dc330  vmovaps xmm12, [rsp+0xC0]
0000714ce89dc339  vmovaps xmm13, [rsp+0xD0]
0000714ce89dc342  vmovaps xmm14, [rsp+0xE0]
0000714ce89dc34b  add rsp, 0xF0
0000714ce89dc352  pop r11
0000714ce89dc354  pop r10
0000714ce89dc356  pop r9
0000714ce89dc358  pop r8
0000714ce89dc35a  pop rsi
0000714ce89dc35b  pop rdi
0000714ce89dc35c  pop rdx
0000714ce89dc35d  pop rcx
0000714ce89dc35e  pop rax
0000714ce89dc35f  add rsp, 0x08
0000714ce89dc363  jmp 0x0000714CE89D93BC
0000714ce89dc368  sub rsp, 0x08
0000714ce89dc36c  push rax
0000714ce89dc36d  push rcx
0000714ce89dc36e  push rdx
0000714ce89dc36f  push rdi
0000714ce89dc370  push rsi
0000714ce89dc371  push r8
0000714ce89dc373  push r9
0000714ce89dc375  push r10
0000714ce89dc377  push r11
0000714ce89dc379  sub rsp, 0xF0
0000714ce89dc380  vmovaps [rsp], xmm0
0000714ce89dc385  vmovaps [rsp+0x10], xmm1
0000714ce89dc38b  vmovaps [rsp+0x20], xmm2
0000714ce89dc391  vmovaps [rsp+0x30], xmm3
0000714ce89dc397  vmovaps [rsp+0x40], xmm4
0000714ce89dc39d  vmovaps [rsp+0x50], xmm6
0000714ce89dc3a3  vmovaps [rsp+0x60], xmm7
0000714ce89dc3a9  vmovaps [rsp+0x70], xmm8
0000714ce89dc3af  vmovaps [rsp+0x80], xmm9
0000714ce89dc3b8  vmovaps [rsp+0x90], xmm10
0000714ce89dc3c1  vmovaps [rsp+0xA0], xmm11
0000714ce89dc3ca  vmovaps [rsp+0xB0], xmm12
0000714ce89dc3d3  vmovaps [rsp+0xC0], xmm13
0000714ce89dc3dc  vmovaps [rsp+0xD0], xmm14
0000714ce89dc3e5  vmovaps [rsp+0xE0], xmm15
0000714ce89dc3ee  sub rsp, 0x30
0000714ce89dc3f2  movaps [rsp], xmm5
0000714ce89dc3f6  movaps [rsp+0x10], xmm8
0000714ce89dc3fc  movaps [rsp+0x20], xmm6
0000714ce89dc401  lea rdi, [rsp]
0000714ce89dc405  mov esi, 0x00
0000714ce89dc40a  mov rax, 0x57A55D340530
0000714ce89dc414  call rax
0000714ce89dc416  movaps xmm5, [rsp]
0000714ce89dc41a  add rsp, 0x30
0000714ce89dc41e  vmovaps xmm0, [rsp]
0000714ce89dc423  vmovaps xmm1, [rsp+0x10]
0000714ce89dc429  vmovaps xmm2, [rsp+0x20]
0000714ce89dc42f  vmovaps xmm3, [rsp+0x30]
0000714ce89dc435  vmovaps xmm4, [rsp+0x40]
0000714ce89dc43b  vmovaps xmm6, [rsp+0x50]
0000714ce89dc441  vmovaps xmm7, [rsp+0x60]
0000714ce89dc447  vmovaps xmm8, [rsp+0x70]
0000714ce89dc44d  vmovaps xmm9, [rsp+0x80]
0000714ce89dc456  vmovaps xmm10, [rsp+0x90]
0000714ce89dc45f  vmovaps xmm11, [rsp+0xA0]
0000714ce89dc468  vmovaps xmm12, [rsp+0xB0]
0000714ce89dc471  vmovaps xmm13, [rsp+0xC0]
0000714ce89dc47a  vmovaps xmm14, [rsp+0xD0]
0000714ce89dc483  vmovaps xmm15, [rsp+0xE0]
0000714ce89dc48c  add rsp, 0xF0
0000714ce89dc493  pop r11
0000714ce89dc495  pop r10
0000714ce89dc497  pop r9
0000714ce89dc499  pop r8
0000714ce89dc49b  pop rsi
0000714ce89dc49c  pop rdi
0000714ce89dc49d  pop rdx
0000714ce89dc49e  pop rcx
0000714ce89dc49f  pop rax
0000714ce89dc4a0  add rsp, 0x08
0000714ce89dc4a4  jmp 0x0000714CE89D93E0
0000714ce89dc4a9  sub rsp, 0x08
0000714ce89dc4ad  push rax
0000714ce89dc4ae  push rcx
0000714ce89dc4af  push rdx
0000714ce89dc4b0  push rdi
0000714ce89dc4b1  push rsi
0000714ce89dc4b2  push r8
0000714ce89dc4b4  push r9
0000714ce89dc4b6  push r10
0000714ce89dc4b8  push r11
0000714ce89dc4ba  sub rsp, 0xF0
0000714ce89dc4c1  vmovaps [rsp], xmm0
0000714ce89dc4c6  vmovaps [rsp+0x10], xmm1
0000714ce89dc4cc  vmovaps [rsp+0x20], xmm2
0000714ce89dc4d2  vmovaps [rsp+0x30], xmm3
0000714ce89dc4d8  vmovaps [rsp+0x40], xmm4
0000714ce89dc4de  vmovaps [rsp+0x50], xmm5
0000714ce89dc4e4  vmovaps [rsp+0x60], xmm7
0000714ce89dc4ea  vmovaps [rsp+0x70], xmm8
0000714ce89dc4f0  vmovaps [rsp+0x80], xmm9
0000714ce89dc4f9  vmovaps [rsp+0x90], xmm10
0000714ce89dc502  vmovaps [rsp+0xA0], xmm11
0000714ce89dc50b  vmovaps [rsp+0xB0], xmm12
0000714ce89dc514  vmovaps [rsp+0xC0], xmm13
0000714ce89dc51d  vmovaps [rsp+0xD0], xmm14
0000714ce89dc526  vmovaps [rsp+0xE0], xmm15
0000714ce89dc52f  sub rsp, 0x30
0000714ce89dc533  movaps [rsp], xmm6
0000714ce89dc537  movaps [rsp+0x10], xmm10
0000714ce89dc53d  movaps [rsp+0x20], xmm8
0000714ce89dc543  lea rdi, [rsp]
0000714ce89dc547  mov esi, 0x00
0000714ce89dc54c  mov rax, 0x57A55D340530
0000714ce89dc556  call rax
0000714ce89dc558  movaps xmm6, [rsp]
0000714ce89dc55c  add rsp, 0x30
0000714ce89dc560  vmovaps xmm0, [rsp]
0000714ce89dc565  vmovaps xmm1, [rsp+0x10]
0000714ce89dc56b  vmovaps xmm2, [rsp+0x20]
0000714ce89dc571  vmovaps xmm3, [rsp+0x30]
0000714ce89dc577  vmovaps xmm4, [rsp+0x40]
0000714ce89dc57d  vmovaps xmm5, [rsp+0x50]
0000714ce89dc583  vmovaps xmm7, [rsp+0x60]
0000714ce89dc589  vmovaps xmm8, [rsp+0x70]
0000714ce89dc58f  vmovaps xmm9, [rsp+0x80]
0000714ce89dc598  vmovaps xmm10, [rsp+0x90]
0000714ce89dc5a1  vmovaps xmm11, [rsp+0xA0]
0000714ce89dc5aa  vmovaps xmm12, [rsp+0xB0]
0000714ce89dc5b3  vmovaps xmm13, [rsp+0xC0]
0000714ce89dc5bc  vmovaps xmm14, [rsp+0xD0]
0000714ce89dc5c5  vmovaps xmm15, [rsp+0xE0]
0000714ce89dc5ce  add rsp, 0xF0
0000714ce89dc5d5  pop r11
0000714ce89dc5d7  pop r10
0000714ce89dc5d9  pop r9
0000714ce89dc5db  pop r8
0000714ce89dc5dd  pop rsi
0000714ce89dc5de  pop rdi
0000714ce89dc5df  pop rdx
0000714ce89dc5e0  pop rcx
0000714ce89dc5e1  pop rax
0000714ce89dc5e2  add rsp, 0x08
0000714ce89dc5e6  jmp 0x0000714CE89D9405
0000714ce89dc5eb  sub rsp, 0x08
0000714ce89dc5ef  push rax
0000714ce89dc5f0  push rcx
0000714ce89dc5f1  push rdx
0000714ce89dc5f2  push rdi
0000714ce89dc5f3  push rsi
0000714ce89dc5f4  push r8
0000714ce89dc5f6  push r9
0000714ce89dc5f8  push r10
0000714ce89dc5fa  push r11
0000714ce89dc5fc  sub rsp, 0xF0
0000714ce89dc603  vmovaps [rsp], xmm0
0000714ce89dc608  vmovaps [rsp+0x10], xmm1
0000714ce89dc60e  vmovaps [rsp+0x20], xmm2
0000714ce89dc614  vmovaps [rsp+0x30], xmm3
0000714ce89dc61a  vmovaps [rsp+0x40], xmm4
0000714ce89dc620  vmovaps [rsp+0x50], xmm5
0000714ce89dc626  vmovaps [rsp+0x60], xmm6
0000714ce89dc62c  vmovaps [rsp+0x70], xmm7
0000714ce89dc632  vmovaps [rsp+0x80], xmm8
0000714ce89dc63b  vmovaps [rsp+0x90], xmm9
0000714ce89dc644  vmovaps [rsp+0xA0], xmm11
0000714ce89dc64d  vmovaps [rsp+0xB0], xmm12
0000714ce89dc656  vmovaps [rsp+0xC0], xmm13
0000714ce89dc65f  vmovaps [rsp+0xD0], xmm14
0000714ce89dc668  vmovaps [rsp+0xE0], xmm15
0000714ce89dc671  sub rsp, 0x30
0000714ce89dc675  movaps [rsp], xmm10
0000714ce89dc67a  movaps [rsp+0x10], xmm8
0000714ce89dc680  movaps [rsp+0x20], xmm14
0000714ce89dc686  lea rdi, [rsp]
0000714ce89dc68a  mov esi, 0x00
0000714ce89dc68f  mov rax, 0x57A55D340530
0000714ce89dc699  call rax
0000714ce89dc69b  movaps xmm10, [rsp]
0000714ce89dc6a0  add rsp, 0x30
0000714ce89dc6a4  vmovaps xmm0, [rsp]
0000714ce89dc6a9  vmovaps xmm1, [rsp+0x10]
0000714ce89dc6af  vmovaps xmm2, [rsp+0x20]
0000714ce89dc6b5  vmovaps xmm3, [rsp+0x30]
0000714ce89dc6bb  vmovaps xmm4, [rsp+0x40]
0000714ce89dc6c1  vmovaps xmm5, [rsp+0x50]
0000714ce89dc6c7  vmovaps xmm6, [rsp+0x60]
0000714ce89dc6cd  vmovaps xmm7, [rsp+0x70]
0000714ce89dc6d3  vmovaps xmm8, [rsp+0x80]
0000714ce89dc6dc  vmovaps xmm9, [rsp+0x90]
0000714ce89dc6e5  vmovaps xmm11, [rsp+0xA0]
0000714ce89dc6ee  vmovaps xmm12, [rsp+0xB0]
0000714ce89dc6f7  vmovaps xmm13, [rsp+0xC0]
0000714ce89dc700  vmovaps xmm14, [rsp+0xD0]
0000714ce89dc709  vmovaps xmm15, [rsp+0xE0]
0000714ce89dc712  add rsp, 0xF0
0000714ce89dc719  pop r11
0000714ce89dc71b  pop r10
0000714ce89dc71d  pop r9
0000714ce89dc71f  pop r8
0000714ce89dc721  pop rsi
0000714ce89dc722  pop rdi
0000714ce89dc723  pop rdx
0000714ce89dc724  pop rcx
0000714ce89dc725  pop rax
0000714ce89dc726  add rsp, 0x08
0000714ce89dc72a  jmp 0x0000714CE89D9425
0000714ce89dc72f  sub rsp, 0x08
0000714ce89dc733  push rax
0000714ce89dc734  push rcx
0000714ce89dc735  push rdx
0000714ce89dc736  push rdi
0000714ce89dc737  push rsi
0000714ce89dc738  push r8
0000714ce89dc73a  push r9
0000714ce89dc73c  push r10
0000714ce89dc73e  push r11
0000714ce89dc740  sub rsp, 0xF0
0000714ce89dc747  vmovaps [rsp], xmm0
0000714ce89dc74c  vmovaps [rsp+0x10], xmm1
0000714ce89dc752  vmovaps [rsp+0x20], xmm2
0000714ce89dc758  vmovaps [rsp+0x30], xmm3
0000714ce89dc75e  vmovaps [rsp+0x40], xmm4
0000714ce89dc764  vmovaps [rsp+0x50], xmm5
0000714ce89dc76a  vmovaps [rsp+0x60], xmm6
0000714ce89dc770  vmovaps [rsp+0x70], xmm7
0000714ce89dc776  vmovaps [rsp+0x80], xmm8
0000714ce89dc77f  vmovaps [rsp+0x90], xmm9
0000714ce89dc788  vmovaps [rsp+0xA0], xmm10
0000714ce89dc791  vmovaps [rsp+0xB0], xmm11
0000714ce89dc79a  vmovaps [rsp+0xC0], xmm12
0000714ce89dc7a3  vmovaps [rsp+0xD0], xmm13
0000714ce89dc7ac  vmovaps [rsp+0xE0], xmm15
0000714ce89dc7b5  sub rsp, 0x30
0000714ce89dc7b9  movaps [rsp], xmm14
0000714ce89dc7be  movaps [rsp+0x10], xmm8
0000714ce89dc7c4  movaps [rsp+0x20], xmm4
0000714ce89dc7c9  lea rdi, [rsp]
0000714ce89dc7cd  mov esi, 0x00
0000714ce89dc7d2  mov rax, 0x57A55D340530
0000714ce89dc7dc  call rax
0000714ce89dc7de  movaps xmm14, [rsp]
0000714ce89dc7e3  add rsp, 0x30
0000714ce89dc7e7  vmovaps xmm0, [rsp]
0000714ce89dc7ec  vmovaps xmm1, [rsp+0x10]
0000714ce89dc7f2  vmovaps xmm2, [rsp+0x20]
0000714ce89dc7f8  vmovaps xmm3, [rsp+0x30]
0000714ce89dc7fe  vmovaps xmm4, [rsp+0x40]
0000714ce89dc804  vmovaps xmm5, [rsp+0x50]
0000714ce89dc80a  vmovaps xmm6, [rsp+0x60]
0000714ce89dc810  vmovaps xmm7, [rsp+0x70]
0000714ce89dc816  vmovaps xmm8, [rsp+0x80]
0000714ce89dc81f  vmovaps xmm9, [rsp+0x90]
0000714ce89dc828  vmovaps xmm10, [rsp+0xA0]
0000714ce89dc831  vmovaps xmm11, [rsp+0xB0]
0000714ce89dc83a  vmovaps xmm12, [rsp+0xC0]
0000714ce89dc843  vmovaps xmm13, [rsp+0xD0]
0000714ce89dc84c  vmovaps xmm15, [rsp+0xE0]
0000714ce89dc855  add rsp, 0xF0
0000714ce89dc85c  pop r11
0000714ce89dc85e  pop r10
0000714ce89dc860  pop r9
0000714ce89dc862  pop r8
0000714ce89dc864  pop rsi
0000714ce89dc865  pop rdi
0000714ce89dc866  pop rdx
0000714ce89dc867  pop rcx
0000714ce89dc868  pop rax
0000714ce89dc869  add rsp, 0x08
0000714ce89dc86d  jmp 0x0000714CE89D9445
0000714ce89dc872  sub rsp, 0x08
0000714ce89dc876  push rax
0000714ce89dc877  push rcx
0000714ce89dc878  push rdx
0000714ce89dc879  push rdi
0000714ce89dc87a  push rsi
0000714ce89dc87b  push r8
0000714ce89dc87d  push r9
0000714ce89dc87f  push r10
0000714ce89dc881  push r11
0000714ce89dc883  sub rsp, 0xF0
0000714ce89dc88a  vmovaps [rsp], xmm0
0000714ce89dc88f  vmovaps [rsp+0x10], xmm1
0000714ce89dc895  vmovaps [rsp+0x20], xmm2
0000714ce89dc89b  vmovaps [rsp+0x30], xmm3
0000714ce89dc8a1  vmovaps [rsp+0x40], xmm5
0000714ce89dc8a7  vmovaps [rsp+0x50], xmm6
0000714ce89dc8ad  vmovaps [rsp+0x60], xmm7
0000714ce89dc8b3  vmovaps [rsp+0x70], xmm8
0000714ce89dc8b9  vmovaps [rsp+0x80], xmm9
0000714ce89dc8c2  vmovaps [rsp+0x90], xmm10
0000714ce89dc8cb  vmovaps [rsp+0xA0], xmm11
0000714ce89dc8d4  vmovaps [rsp+0xB0], xmm12
0000714ce89dc8dd  vmovaps [rsp+0xC0], xmm13
0000714ce89dc8e6  vmovaps [rsp+0xD0], xmm14
0000714ce89dc8ef  vmovaps [rsp+0xE0], xmm15
0000714ce89dc8f8  sub rsp, 0x30
0000714ce89dc8fc  movaps [rsp], xmm4
0000714ce89dc900  movaps [rsp+0x10], xmm13
0000714ce89dc906  movaps [rsp+0x20], xmm8
0000714ce89dc90c  lea rdi, [rsp]
0000714ce89dc910  mov esi, 0x00
0000714ce89dc915  mov rax, 0x57A55D340530
0000714ce89dc91f  call rax
0000714ce89dc921  movaps xmm4, [rsp]
0000714ce89dc925  add rsp, 0x30
0000714ce89dc929  vmovaps xmm0, [rsp]
0000714ce89dc92e  vmovaps xmm1, [rsp+0x10]
0000714ce89dc934  vmovaps xmm2, [rsp+0x20]
0000714ce89dc93a  vmovaps xmm3, [rsp+0x30]
0000714ce89dc940  vmovaps xmm5, [rsp+0x40]
0000714ce89dc946  vmovaps xmm6, [rsp+0x50]
0000714ce89dc94c  vmovaps xmm7, [rsp+0x60]
0000714ce89dc952  vmovaps xmm8, [rsp+0x70]
0000714ce89dc958  vmovaps xmm9, [rsp+0x80]
0000714ce89dc961  vmovaps xmm10, [rsp+0x90]
0000714ce89dc96a  vmovaps xmm11, [rsp+0xA0]
0000714ce89dc973  vmovaps xmm12, [rsp+0xB0]
0000714ce89dc97c  vmovaps xmm13, [rsp+0xC0]
0000714ce89dc985  vmovaps xmm14, [rsp+0xD0]
0000714ce89dc98e  vmovaps xmm15, [rsp+0xE0]
0000714ce89dc997  add rsp, 0xF0
0000714ce89dc99e  pop r11
0000714ce89dc9a0  pop r10
0000714ce89dc9a2  pop r9
0000714ce89dc9a4  pop r8
0000714ce89dc9a6  pop rsi
0000714ce89dc9a7  pop rdi
0000714ce89dc9a8  pop rdx
0000714ce89dc9a9  pop rcx
0000714ce89dc9aa  pop rax
0000714ce89dc9ab  add rsp, 0x08
0000714ce89dc9af  jmp 0x0000714CE89D946A
0000714ce89dc9b4  sub rsp, 0x08
0000714ce89dc9b8  push rax
0000714ce89dc9b9  push rcx
0000714ce89dc9ba  push rdx
0000714ce89dc9bb  push rdi
0000714ce89dc9bc  push rsi
0000714ce89dc9bd  push r8
0000714ce89dc9bf  push r9
0000714ce89dc9c1  push r10
0000714ce89dc9c3  push r11
0000714ce89dc9c5  sub rsp, 0xF0
0000714ce89dc9cc  vmovaps [rsp], xmm0
0000714ce89dc9d1  vmovaps [rsp+0x10], xmm1
0000714ce89dc9d7  vmovaps [rsp+0x20], xmm2
0000714ce89dc9dd  vmovaps [rsp+0x30], xmm3
0000714ce89dc9e3  vmovaps [rsp+0x40], xmm4
0000714ce89dc9e9  vmovaps [rsp+0x50], xmm5
0000714ce89dc9ef  vmovaps [rsp+0x60], xmm6
0000714ce89dc9f5  vmovaps [rsp+0x70], xmm7
0000714ce89dc9fb  vmovaps [rsp+0x80], xmm8
0000714ce89dca04  vmovaps [rsp+0x90], xmm9
0000714ce89dca0d  vmovaps [rsp+0xA0], xmm10
0000714ce89dca16  vmovaps [rsp+0xB0], xmm11
0000714ce89dca1f  vmovaps [rsp+0xC0], xmm12
0000714ce89dca28  vmovaps [rsp+0xD0], xmm14
0000714ce89dca31  vmovaps [rsp+0xE0], xmm15
0000714ce89dca3a  sub rsp, 0x30
0000714ce89dca3e  movaps [rsp], xmm13
0000714ce89dca43  movaps [rsp+0x10], xmm15
0000714ce89dca49  movaps [rsp+0x20], xmm9
0000714ce89dca4f  lea rdi, [rsp]
0000714ce89dca53  mov esi, 0x00
0000714ce89dca58  mov rax, 0x57A55D340530
0000714ce89dca62  call rax
0000714ce89dca64  movaps xmm13, [rsp]
0000714ce89dca69  add rsp, 0x30
0000714ce89dca6d  vmovaps xmm0, [rsp]
0000714ce89dca72  vmovaps xmm1, [rsp+0x10]
0000714ce89dca78  vmovaps xmm2, [rsp+0x20]
0000714ce89dca7e  vmovaps xmm3, [rsp+0x30]
0000714ce89dca84  vmovaps xmm4, [rsp+0x40]
0000714ce89dca8a  vmovaps xmm5, [rsp+0x50]
0000714ce89dca90  vmovaps xmm6, [rsp+0x60]
0000714ce89dca96  vmovaps xmm7, [rsp+0x70]
0000714ce89dca9c  vmovaps xmm8, [rsp+0x80]
0000714ce89dcaa5  vmovaps xmm9, [rsp+0x90]
0000714ce89dcaae  vmovaps xmm10, [rsp+0xA0]
0000714ce89dcab7  vmovaps xmm11, [rsp+0xB0]
0000714ce89dcac0  vmovaps xmm12, [rsp+0xC0]
0000714ce89dcac9  vmovaps xmm14, [rsp+0xD0]
0000714ce89dcad2  vmovaps xmm15, [rsp+0xE0]
0000714ce89dcadb  add rsp, 0xF0
0000714ce89dcae2  pop r11
0000714ce89dcae4  pop r10
0000714ce89dcae6  pop r9
0000714ce89dcae8  pop r8
0000714ce89dcaea  pop rsi
0000714ce89dcaeb  pop rdi
0000714ce89dcaec  pop rdx
0000714ce89dcaed  pop rcx
0000714ce89dcaee  pop rax
0000714ce89dcaef  add rsp, 0x08
0000714ce89dcaf3  jmp 0x0000714CE89D9485
0000714ce89dcaf8  sub rsp, 0x08
0000714ce89dcafc  push rax
0000714ce89dcafd  push rcx
0000714ce89dcafe  push rdx
0000714ce89dcaff  push rdi
0000714ce89dcb00  push rsi
0000714ce89dcb01  push r8
0000714ce89dcb03  push r9
0000714ce89dcb05  push r10
0000714ce89dcb07  push r11
0000714ce89dcb09  sub rsp, 0xF0
0000714ce89dcb10  vmovaps [rsp], xmm0
0000714ce89dcb15  vmovaps [rsp+0x10], xmm1
0000714ce89dcb1b  vmovaps [rsp+0x20], xmm2
0000714ce89dcb21  vmovaps [rsp+0x30], xmm3
0000714ce89dcb27  vmovaps [rsp+0x40], xmm4
0000714ce89dcb2d  vmovaps [rsp+0x50], xmm5
0000714ce89dcb33  vmovaps [rsp+0x60], xmm6
0000714ce89dcb39  vmovaps [rsp+0x70], xmm7
0000714ce89dcb3f  vmovaps [rsp+0x80], xmm8
0000714ce89dcb48  vmovaps [rsp+0x90], xmm9
0000714ce89dcb51  vmovaps [rsp+0xA0], xmm10
0000714ce89dcb5a  vmovaps [rsp+0xB0], xmm11
0000714ce89dcb63  vmovaps [rsp+0xC0], xmm12
0000714ce89dcb6c  vmovaps [rsp+0xD0], xmm13
0000714ce89dcb75  vmovaps [rsp+0xE0], xmm14
0000714ce89dcb7e  sub rsp, 0x30
0000714ce89dcb82  movaps [rsp], xmm15
0000714ce89dcb87  movaps [rsp+0x10], xmm1
0000714ce89dcb8c  movaps [rsp+0x20], xmm5
0000714ce89dcb91  lea rdi, [rsp]
0000714ce89dcb95  mov esi, 0x00
0000714ce89dcb9a  mov rax, 0x57A55D340530
0000714ce89dcba4  call rax
0000714ce89dcba6  movaps xmm15, [rsp]
0000714ce89dcbab  add rsp, 0x30
0000714ce89dcbaf  vmovaps xmm0, [rsp]
0000714ce89dcbb4  vmovaps xmm1, [rsp+0x10]
0000714ce89dcbba  vmovaps xmm2, [rsp+0x20]
0000714ce89dcbc0  vmovaps xmm3, [rsp+0x30]
0000714ce89dcbc6  vmovaps xmm4, [rsp+0x40]
0000714ce89dcbcc  vmovaps xmm5, [rsp+0x50]
0000714ce89dcbd2  vmovaps xmm6, [rsp+0x60]
0000714ce89dcbd8  vmovaps xmm7, [rsp+0x70]
0000714ce89dcbde  vmovaps xmm8, [rsp+0x80]
0000714ce89dcbe7  vmovaps xmm9, [rsp+0x90]
0000714ce89dcbf0  vmovaps xmm10, [rsp+0xA0]
0000714ce89dcbf9  vmovaps xmm11, [rsp+0xB0]
0000714ce89dcc02  vmovaps xmm12, [rsp+0xC0]
0000714ce89dcc0b  vmovaps xmm13, [rsp+0xD0]
0000714ce89dcc14  vmovaps xmm14, [rsp+0xE0]
0000714ce89dcc1d  add rsp, 0xF0
0000714ce89dcc24  pop r11
0000714ce89dcc26  pop r10
0000714ce89dcc28  pop r9
0000714ce89dcc2a  pop r8
0000714ce89dcc2c  pop rsi
0000714ce89dcc2d  pop rdi
0000714ce89dcc2e  pop rdx
0000714ce89dcc2f  pop rcx
0000714ce89dcc30  pop rax
0000714ce89dcc31  add rsp, 0x08
0000714ce89dcc35  jmp 0x0000714CE89D94A0
0000714ce89dcc3a  call 0x0000714CE88D64F0
0000714ce89dcc3f  jmp 0x0000714CE89D94FB
0000714ce89dcc44  sub rsp, 0x08
0000714ce89dcc48  push rax
0000714ce89dcc49  push rcx
0000714ce89dcc4a  push rdx
0000714ce89dcc4b  push rdi
0000714ce89dcc4c  push rsi
0000714ce89dcc4d  push r8
0000714ce89dcc4f  push r9
0000714ce89dcc51  push r10
0000714ce89dcc53  push r11
0000714ce89dcc55  sub rsp, 0xF0
0000714ce89dcc5c  vmovaps [rsp], xmm0
0000714ce89dcc61  vmovaps [rsp+0x10], xmm1
0000714ce89dcc67  vmovaps [rsp+0x20], xmm2
0000714ce89dcc6d  vmovaps [rsp+0x30], xmm3
0000714ce89dcc73  vmovaps [rsp+0x40], xmm4
0000714ce89dcc79  vmovaps [rsp+0x50], xmm5
0000714ce89dcc7f  vmovaps [rsp+0x60], xmm6
0000714ce89dcc85  vmovaps [rsp+0x70], xmm7
0000714ce89dcc8b  vmovaps [rsp+0x80], xmm8
0000714ce89dcc94  vmovaps [rsp+0x90], xmm10
0000714ce89dcc9d  vmovaps [rsp+0xA0], xmm11
0000714ce89dcca6  vmovaps [rsp+0xB0], xmm12
0000714ce89dccaf  vmovaps [rsp+0xC0], xmm13
0000714ce89dccb8  vmovaps [rsp+0xD0], xmm14
0000714ce89dccc1  vmovaps [rsp+0xE0], xmm15
0000714ce89dccca  sub rsp, 0x30
0000714ce89dccce  movaps [rsp], xmm9
0000714ce89dccd3  movaps [rsp+0x10], xmm8
0000714ce89dccd9  movaps [rsp+0x20], xmm11
0000714ce89dccdf  lea rdi, [rsp]
0000714ce89dcce3  mov esi, 0x00
0000714ce89dcce8  mov rax, 0x57A55D340530
0000714ce89dccf2  call rax
0000714ce89dccf4  movaps xmm9, [rsp]
0000714ce89dccf9  add rsp, 0x30
0000714ce89dccfd  vmovaps xmm0, [rsp]
0000714ce89dcd02  vmovaps xmm1, [rsp+0x10]
0000714ce89dcd08  vmovaps xmm2, [rsp+0x20]
0000714ce89dcd0e  vmovaps xmm3, [rsp+0x30]
0000714ce89dcd14  vmovaps xmm4, [rsp+0x40]
0000714ce89dcd1a  vmovaps xmm5, [rsp+0x50]
0000714ce89dcd20  vmovaps xmm6, [rsp+0x60]
0000714ce89dcd26  vmovaps xmm7, [rsp+0x70]
0000714ce89dcd2c  vmovaps xmm8, [rsp+0x80]
0000714ce89dcd35  vmovaps xmm10, [rsp+0x90]
0000714ce89dcd3e  vmovaps xmm11, [rsp+0xA0]
0000714ce89dcd47  vmovaps xmm12, [rsp+0xB0]
0000714ce89dcd50  vmovaps xmm13, [rsp+0xC0]
0000714ce89dcd59  vmovaps xmm14, [rsp+0xD0]
0000714ce89dcd62  vmovaps xmm15, [rsp+0xE0]
0000714ce89dcd6b  add rsp, 0xF0
0000714ce89dcd72  pop r11
0000714ce89dcd74  pop r10
0000714ce89dcd76  pop r9
0000714ce89dcd78  pop r8
0000714ce89dcd7a  pop rsi
0000714ce89dcd7b  pop rdi
0000714ce89dcd7c  pop rdx
0000714ce89dcd7d  pop rcx
0000714ce89dcd7e  pop rax
0000714ce89dcd7f  add rsp, 0x08
0000714ce89dcd83  jmp 0x0000714CE89D9532
0000714ce89dcd88  sub rsp, 0x08
0000714ce89dcd8c  push rax
0000714ce89dcd8d  push rcx
0000714ce89dcd8e  push rdx
0000714ce89dcd8f  push rdi
0000714ce89dcd90  push rsi
0000714ce89dcd91  push r8
0000714ce89dcd93  push r9
0000714ce89dcd95  push r10
0000714ce89dcd97  push r11
0000714ce89dcd99  sub rsp, 0xF0
0000714ce89dcda0  vmovaps [rsp], xmm0
0000714ce89dcda5  vmovaps [rsp+0x10], xmm1
0000714ce89dcdab  vmovaps [rsp+0x20], xmm2
0000714ce89dcdb1  vmovaps [rsp+0x30], xmm3
0000714ce89dcdb7  vmovaps [rsp+0x40], xmm4
0000714ce89dcdbd  vmovaps [rsp+0x50], xmm5
0000714ce89dcdc3  vmovaps [rsp+0x60], xmm6
0000714ce89dcdc9  vmovaps [rsp+0x70], xmm7
0000714ce89dcdcf  vmovaps [rsp+0x80], xmm8
0000714ce89dcdd8  vmovaps [rsp+0x90], xmm9
0000714ce89dcde1  vmovaps [rsp+0xA0], xmm10
0000714ce89dcdea  vmovaps [rsp+0xB0], xmm12
0000714ce89dcdf3  vmovaps [rsp+0xC0], xmm13
0000714ce89dcdfc  vmovaps [rsp+0xD0], xmm14
0000714ce89dce05  vmovaps [rsp+0xE0], xmm15
0000714ce89dce0e  sub rsp, 0x30
0000714ce89dce12  movaps [rsp], xmm11
0000714ce89dce17  movaps [rsp+0x10], xmm10
0000714ce89dce1d  movaps [rsp+0x20], xmm6
0000714ce89dce22  lea rdi, [rsp]
0000714ce89dce26  mov esi, 0x00
0000714ce89dce2b  mov rax, 0x57A55D340530
0000714ce89dce35  call rax
0000714ce89dce37  movaps xmm11, [rsp]
0000714ce89dce3c  add rsp, 0x30
0000714ce89dce40  vmovaps xmm0, [rsp]
0000714ce89dce45  vmovaps xmm1, [rsp+0x10]
0000714ce89dce4b  vmovaps xmm2, [rsp+0x20]
0000714ce89dce51  vmovaps xmm3, [rsp+0x30]
0000714ce89dce57  vmovaps xmm4, [rsp+0x40]
0000714ce89dce5d  vmovaps xmm5, [rsp+0x50]
0000714ce89dce63  vmovaps xmm6, [rsp+0x60]
0000714ce89dce69  vmovaps xmm7, [rsp+0x70]
0000714ce89dce6f  vmovaps xmm8, [rsp+0x80]
0000714ce89dce78  vmovaps xmm9, [rsp+0x90]
0000714ce89dce81  vmovaps xmm10, [rsp+0xA0]
0000714ce89dce8a  vmovaps xmm12, [rsp+0xB0]
0000714ce89dce93  vmovaps xmm13, [rsp+0xC0]
0000714ce89dce9c  vmovaps xmm14, [rsp+0xD0]
0000714ce89dcea5  vmovaps xmm15, [rsp+0xE0]
0000714ce89dceae  add rsp, 0xF0
0000714ce89dceb5  pop r11
0000714ce89dceb7  pop r10
0000714ce89dceb9  pop r9
0000714ce89dcebb  pop r8
0000714ce89dcebd  pop rsi
0000714ce89dcebe  pop rdi
0000714ce89dcebf  pop rdx
0000714ce89dcec0  pop rcx
0000714ce89dcec1  pop rax
0000714ce89dcec2  add rsp, 0x08
0000714ce89dcec6  jmp 0x0000714CE89D954D
0000714ce89dcecb  sub rsp, 0x08
0000714ce89dcecf  push rax
0000714ce89dced0  push rcx
0000714ce89dced1  push rdx
0000714ce89dced2  push rdi
0000714ce89dced3  push rsi
0000714ce89dced4  push r8
0000714ce89dced6  push r9
0000714ce89dced8  push r10
0000714ce89dceda  push r11
0000714ce89dcedc  sub rsp, 0xF0
0000714ce89dcee3  vmovaps [rsp], xmm0
0000714ce89dcee8  vmovaps [rsp+0x10], xmm1
0000714ce89dceee  vmovaps [rsp+0x20], xmm2
0000714ce89dcef4  vmovaps [rsp+0x30], xmm3
0000714ce89dcefa  vmovaps [rsp+0x40], xmm4
0000714ce89dcf00  vmovaps [rsp+0x50], xmm5
0000714ce89dcf06  vmovaps [rsp+0x60], xmm6
0000714ce89dcf0c  vmovaps [rsp+0x70], xmm7
0000714ce89dcf12  vmovaps [rsp+0x80], xmm8
0000714ce89dcf1b  vmovaps [rsp+0x90], xmm9
0000714ce89dcf24  vmovaps [rsp+0xA0], xmm11
0000714ce89dcf2d  vmovaps [rsp+0xB0], xmm12
0000714ce89dcf36  vmovaps [rsp+0xC0], xmm13
0000714ce89dcf3f  vmovaps [rsp+0xD0], xmm14
0000714ce89dcf48  vmovaps [rsp+0xE0], xmm15
0000714ce89dcf51  sub rsp, 0x30
0000714ce89dcf55  movaps [rsp], xmm10
0000714ce89dcf5a  movaps [rsp+0x10], xmm14
0000714ce89dcf60  movaps [rsp+0x20], xmm4
0000714ce89dcf65  lea rdi, [rsp]
0000714ce89dcf69  mov esi, 0x00
0000714ce89dcf6e  mov rax, 0x57A55D340530
0000714ce89dcf78  call rax
0000714ce89dcf7a  movaps xmm10, [rsp]
0000714ce89dcf7f  add rsp, 0x30
0000714ce89dcf83  vmovaps xmm0, [rsp]
0000714ce89dcf88  vmovaps xmm1, [rsp+0x10]
0000714ce89dcf8e  vmovaps xmm2, [rsp+0x20]
0000714ce89dcf94  vmovaps xmm3, [rsp+0x30]
0000714ce89dcf9a  vmovaps xmm4, [rsp+0x40]
0000714ce89dcfa0  vmovaps xmm5, [rsp+0x50]
0000714ce89dcfa6  vmovaps xmm6, [rsp+0x60]
0000714ce89dcfac  vmovaps xmm7, [rsp+0x70]
0000714ce89dcfb2  vmovaps xmm8, [rsp+0x80]
0000714ce89dcfbb  vmovaps xmm9, [rsp+0x90]
0000714ce89dcfc4  vmovaps xmm11, [rsp+0xA0]
0000714ce89dcfcd  vmovaps xmm12, [rsp+0xB0]
0000714ce89dcfd6  vmovaps xmm13, [rsp+0xC0]
0000714ce89dcfdf  vmovaps xmm14, [rsp+0xD0]
0000714ce89dcfe8  vmovaps xmm15, [rsp+0xE0]
0000714ce89dcff1  add rsp, 0xF0
0000714ce89dcff8  pop r11
0000714ce89dcffa  pop r10
0000714ce89dcffc  pop r9
0000714ce89dcffe  pop r8
0000714ce89dd000  pop rsi
0000714ce89dd001  pop rdi
0000714ce89dd002  pop rdx
0000714ce89dd003  pop rcx
0000714ce89dd004  pop rax
0000714ce89dd005  add rsp, 0x08
0000714ce89dd009  jmp 0x0000714CE89D9568
0000714ce89dd00e  sub rsp, 0x08
0000714ce89dd012  push rax
0000714ce89dd013  push rcx
0000714ce89dd014  push rdx
0000714ce89dd015  push rdi
0000714ce89dd016  push rsi
0000714ce89dd017  push r8
0000714ce89dd019  push r9
0000714ce89dd01b  push r10
0000714ce89dd01d  push r11
0000714ce89dd01f  sub rsp, 0xF0
0000714ce89dd026  vmovaps [rsp], xmm0
0000714ce89dd02b  vmovaps [rsp+0x10], xmm1
0000714ce89dd031  vmovaps [rsp+0x20], xmm2
0000714ce89dd037  vmovaps [rsp+0x30], xmm3
0000714ce89dd03d  vmovaps [rsp+0x40], xmm4
0000714ce89dd043  vmovaps [rsp+0x50], xmm5
0000714ce89dd049  vmovaps [rsp+0x60], xmm6
0000714ce89dd04f  vmovaps [rsp+0x70], xmm7
0000714ce89dd055  vmovaps [rsp+0x80], xmm9
0000714ce89dd05e  vmovaps [rsp+0x90], xmm10
0000714ce89dd067  vmovaps [rsp+0xA0], xmm11
0000714ce89dd070  vmovaps [rsp+0xB0], xmm12
0000714ce89dd079  vmovaps [rsp+0xC0], xmm13
0000714ce89dd082  vmovaps [rsp+0xD0], xmm14
0000714ce89dd08b  vmovaps [rsp+0xE0], xmm15
0000714ce89dd094  sub rsp, 0x30
0000714ce89dd098  movaps [rsp], xmm8
0000714ce89dd09d  movaps [rsp+0x10], xmm1
0000714ce89dd0a2  movaps [rsp+0x20], xmm14
0000714ce89dd0a8  lea rdi, [rsp]
0000714ce89dd0ac  mov esi, 0x00
0000714ce89dd0b1  mov rax, 0x57A55D340530
0000714ce89dd0bb  call rax
0000714ce89dd0bd  movaps xmm8, [rsp]
0000714ce89dd0c2  add rsp, 0x30
0000714ce89dd0c6  vmovaps xmm0, [rsp]
0000714ce89dd0cb  vmovaps xmm1, [rsp+0x10]
0000714ce89dd0d1  vmovaps xmm2, [rsp+0x20]
0000714ce89dd0d7  vmovaps xmm3, [rsp+0x30]
0000714ce89dd0dd  vmovaps xmm4, [rsp+0x40]
0000714ce89dd0e3  vmovaps xmm5, [rsp+0x50]
0000714ce89dd0e9  vmovaps xmm6, [rsp+0x60]
0000714ce89dd0ef  vmovaps xmm7, [rsp+0x70]
0000714ce89dd0f5  vmovaps xmm9, [rsp+0x80]
0000714ce89dd0fe  vmovaps xmm10, [rsp+0x90]
0000714ce89dd107  vmovaps xmm11, [rsp+0xA0]
0000714ce89dd110  vmovaps xmm12, [rsp+0xB0]
0000714ce89dd119  vmovaps xmm13, [rsp+0xC0]
0000714ce89dd122  vmovaps xmm14, [rsp+0xD0]
0000714ce89dd12b  vmovaps xmm15, [rsp+0xE0]
0000714ce89dd134  add rsp, 0xF0
0000714ce89dd13b  pop r11
0000714ce89dd13d  pop r10
0000714ce89dd13f  pop r9
0000714ce89dd141  pop r8
0000714ce89dd143  pop rsi
0000714ce89dd144  pop rdi
0000714ce89dd145  pop rdx
0000714ce89dd146  pop rcx
0000714ce89dd147  pop rax
0000714ce89dd148  add rsp, 0x08
0000714ce89dd14c  jmp 0x0000714CE89D958E
0000714ce89dd151  sub rsp, 0x08
0000714ce89dd155  push rax
0000714ce89dd156  push rcx
0000714ce89dd157  push rdx
0000714ce89dd158  push rdi
0000714ce89dd159  push rsi
0000714ce89dd15a  push r8
0000714ce89dd15c  push r9
0000714ce89dd15e  push r10
0000714ce89dd160  push r11
0000714ce89dd162  sub rsp, 0xF0
0000714ce89dd169  vmovaps [rsp], xmm0
0000714ce89dd16e  vmovaps [rsp+0x10], xmm1
0000714ce89dd174  vmovaps [rsp+0x20], xmm2
0000714ce89dd17a  vmovaps [rsp+0x30], xmm3
0000714ce89dd180  vmovaps [rsp+0x40], xmm4
0000714ce89dd186  vmovaps [rsp+0x50], xmm5
0000714ce89dd18c  vmovaps [rsp+0x60], xmm7
0000714ce89dd192  vmovaps [rsp+0x70], xmm8
0000714ce89dd198  vmovaps [rsp+0x80], xmm9
0000714ce89dd1a1  vmovaps [rsp+0x90], xmm10
0000714ce89dd1aa  vmovaps [rsp+0xA0], xmm11
0000714ce89dd1b3  vmovaps [rsp+0xB0], xmm12
0000714ce89dd1bc  vmovaps [rsp+0xC0], xmm13
0000714ce89dd1c5  vmovaps [rsp+0xD0], xmm14
0000714ce89dd1ce  vmovaps [rsp+0xE0], xmm15
0000714ce89dd1d7  sub rsp, 0x30
0000714ce89dd1db  movaps [rsp], xmm6
0000714ce89dd1df  movaps [rsp+0x10], xmm1
0000714ce89dd1e4  movaps [rsp+0x20], xmm14
0000714ce89dd1ea  lea rdi, [rsp]
0000714ce89dd1ee  mov esi, 0x00
0000714ce89dd1f3  mov rax, 0x57A55D340530
0000714ce89dd1fd  call rax
0000714ce89dd1ff  movaps xmm6, [rsp]
0000714ce89dd203  add rsp, 0x30
0000714ce89dd207  vmovaps xmm0, [rsp]
0000714ce89dd20c  vmovaps xmm1, [rsp+0x10]
0000714ce89dd212  vmovaps xmm2, [rsp+0x20]
0000714ce89dd218  vmovaps xmm3, [rsp+0x30]
0000714ce89dd21e  vmovaps xmm4, [rsp+0x40]
0000714ce89dd224  vmovaps xmm5, [rsp+0x50]
0000714ce89dd22a  vmovaps xmm7, [rsp+0x60]
0000714ce89dd230  vmovaps xmm8, [rsp+0x70]
0000714ce89dd236  vmovaps xmm9, [rsp+0x80]
0000714ce89dd23f  vmovaps xmm10, [rsp+0x90]
0000714ce89dd248  vmovaps xmm11, [rsp+0xA0]
0000714ce89dd251  vmovaps xmm12, [rsp+0xB0]
0000714ce89dd25a  vmovaps xmm13, [rsp+0xC0]
0000714ce89dd263  vmovaps xmm14, [rsp+0xD0]
0000714ce89dd26c  vmovaps xmm15, [rsp+0xE0]
0000714ce89dd275  add rsp, 0xF0
0000714ce89dd27c  pop r11
0000714ce89dd27e  pop r10
0000714ce89dd280  pop r9
0000714ce89dd282  pop r8
0000714ce89dd284  pop rsi
0000714ce89dd285  pop rdi
0000714ce89dd286  pop rdx
0000714ce89dd287  pop rcx
0000714ce89dd288  pop rax
0000714ce89dd289  add rsp, 0x08
0000714ce89dd28d  jmp 0x0000714CE89D95BA
0000714ce89dd292  sub rsp, 0x08
0000714ce89dd296  push rax
0000714ce89dd297  push rcx
0000714ce89dd298  push rdx
0000714ce89dd299  push rdi
0000714ce89dd29a  push rsi
0000714ce89dd29b  push r8
0000714ce89dd29d  push r9
0000714ce89dd29f  push r10
0000714ce89dd2a1  push r11
0000714ce89dd2a3  sub rsp, 0xF0
0000714ce89dd2aa  vmovaps [rsp], xmm0
0000714ce89dd2af  vmovaps [rsp+0x10], xmm1
0000714ce89dd2b5  vmovaps [rsp+0x20], xmm2
0000714ce89dd2bb  vmovaps [rsp+0x30], xmm3
0000714ce89dd2c1  vmovaps [rsp+0x40], xmm4
0000714ce89dd2c7  vmovaps [rsp+0x50], xmm5
0000714ce89dd2cd  vmovaps [rsp+0x60], xmm6
0000714ce89dd2d3  vmovaps [rsp+0x70], xmm7
0000714ce89dd2d9  vmovaps [rsp+0x80], xmm8
0000714ce89dd2e2  vmovaps [rsp+0x90], xmm9
0000714ce89dd2eb  vmovaps [rsp+0xA0], xmm10
0000714ce89dd2f4  vmovaps [rsp+0xB0], xmm11
0000714ce89dd2fd  vmovaps [rsp+0xC0], xmm12
0000714ce89dd306  vmovaps [rsp+0xD0], xmm13
0000714ce89dd30f  vmovaps [rsp+0xE0], xmm15
0000714ce89dd318  sub rsp, 0x30
0000714ce89dd31c  movaps [rsp], xmm14
0000714ce89dd321  movaps [rsp+0x10], xmm12
0000714ce89dd327  movaps [rsp+0x20], xmm1
0000714ce89dd32c  lea rdi, [rsp]
0000714ce89dd330  mov esi, 0x00
0000714ce89dd335  mov rax, 0x57A55D340530
0000714ce89dd33f  call rax
0000714ce89dd341  movaps xmm14, [rsp]
0000714ce89dd346  add rsp, 0x30
0000714ce89dd34a  vmovaps xmm0, [rsp]
0000714ce89dd34f  vmovaps xmm1, [rsp+0x10]
0000714ce89dd355  vmovaps xmm2, [rsp+0x20]
0000714ce89dd35b  vmovaps xmm3, [rsp+0x30]
0000714ce89dd361  vmovaps xmm4, [rsp+0x40]
0000714ce89dd367  vmovaps xmm5, [rsp+0x50]
0000714ce89dd36d  vmovaps xmm6, [rsp+0x60]
0000714ce89dd373  vmovaps xmm7, [rsp+0x70]
0000714ce89dd379  vmovaps xmm8, [rsp+0x80]
0000714ce89dd382  vmovaps xmm9, [rsp+0x90]
0000714ce89dd38b  vmovaps xmm10, [rsp+0xA0]
0000714ce89dd394  vmovaps xmm11, [rsp+0xB0]
0000714ce89dd39d  vmovaps xmm12, [rsp+0xC0]
0000714ce89dd3a6  vmovaps xmm13, [rsp+0xD0]
0000714ce89dd3af  vmovaps xmm15, [rsp+0xE0]
0000714ce89dd3b8  add rsp, 0xF0
0000714ce89dd3bf  pop r11
0000714ce89dd3c1  pop r10
0000714ce89dd3c3  pop r9
0000714ce89dd3c5  pop r8
0000714ce89dd3c7  pop rsi
0000714ce89dd3c8  pop rdi
0000714ce89dd3c9  pop rdx
0000714ce89dd3ca  pop rcx
0000714ce89dd3cb  pop rax
0000714ce89dd3cc  add rsp, 0x08
0000714ce89dd3d0  jmp 0x0000714CE89D95E0
0000714ce89dd3d5  sub rsp, 0x08
0000714ce89dd3d9  push rax
0000714ce89dd3da  push rcx
0000714ce89dd3db  push rdx
0000714ce89dd3dc  push rdi
0000714ce89dd3dd  push rsi
0000714ce89dd3de  push r8
0000714ce89dd3e0  push r9
0000714ce89dd3e2  push r10
0000714ce89dd3e4  push r11
0000714ce89dd3e6  sub rsp, 0xF0
0000714ce89dd3ed  vmovaps [rsp], xmm0
0000714ce89dd3f2  vmovaps [rsp+0x10], xmm2
0000714ce89dd3f8  vmovaps [rsp+0x20], xmm3
0000714ce89dd3fe  vmovaps [rsp+0x30], xmm4
0000714ce89dd404  vmovaps [rsp+0x40], xmm5
0000714ce89dd40a  vmovaps [rsp+0x50], xmm6
0000714ce89dd410  vmovaps [rsp+0x60], xmm7
0000714ce89dd416  vmovaps [rsp+0x70], xmm8
0000714ce89dd41c  vmovaps [rsp+0x80], xmm9
0000714ce89dd425  vmovaps [rsp+0x90], xmm10
0000714ce89dd42e  vmovaps [rsp+0xA0], xmm11
0000714ce89dd437  vmovaps [rsp+0xB0], xmm12
0000714ce89dd440  vmovaps [rsp+0xC0], xmm13
0000714ce89dd449  vmovaps [rsp+0xD0], xmm14
0000714ce89dd452  vmovaps [rsp+0xE0], xmm15
0000714ce89dd45b  sub rsp, 0x30
0000714ce89dd45f  movaps [rsp], xmm1
0000714ce89dd463  movaps [rsp+0x10], xmm13
0000714ce89dd469  movaps [rsp+0x20], xmm9
0000714ce89dd46f  lea rdi, [rsp]
0000714ce89dd473  mov esi, 0x00
0000714ce89dd478  mov rax, 0x57A55D340530
0000714ce89dd482  call rax
0000714ce89dd484  movaps xmm1, [rsp]
0000714ce89dd488  add rsp, 0x30
0000714ce89dd48c  vmovaps xmm0, [rsp]
0000714ce89dd491  vmovaps xmm2, [rsp+0x10]
0000714ce89dd497  vmovaps xmm3, [rsp+0x20]
0000714ce89dd49d  vmovaps xmm4, [rsp+0x30]
0000714ce89dd4a3  vmovaps xmm5, [rsp+0x40]
0000714ce89dd4a9  vmovaps xmm6, [rsp+0x50]
0000714ce89dd4af  vmovaps xmm7, [rsp+0x60]
0000714ce89dd4b5  vmovaps xmm8, [rsp+0x70]
0000714ce89dd4bb  vmovaps xmm9, [rsp+0x80]
0000714ce89dd4c4  vmovaps xmm10, [rsp+0x90]
0000714ce89dd4cd  vmovaps xmm11, [rsp+0xA0]
0000714ce89dd4d6  vmovaps xmm12, [rsp+0xB0]
0000714ce89dd4df  vmovaps xmm13, [rsp+0xC0]
0000714ce89dd4e8  vmovaps xmm14, [rsp+0xD0]
0000714ce89dd4f1  vmovaps xmm15, [rsp+0xE0]
0000714ce89dd4fa  add rsp, 0xF0
0000714ce89dd501  pop r11
0000714ce89dd503  pop r10
0000714ce89dd505  pop r9
0000714ce89dd507  pop r8
0000714ce89dd509  pop rsi
0000714ce89dd50a  pop rdi
0000714ce89dd50b  pop rdx
0000714ce89dd50c  pop rcx
0000714ce89dd50d  pop rax
0000714ce89dd50e  add rsp, 0x08
0000714ce89dd512  jmp 0x0000714CE89D95FA
0000714ce89dd517  sub rsp, 0x08
0000714ce89dd51b  push rax
0000714ce89dd51c  push rcx
0000714ce89dd51d  push rdx
0000714ce89dd51e  push rdi
0000714ce89dd51f  push rsi
0000714ce89dd520  push r8
0000714ce89dd522  push r9
0000714ce89dd524  push r10
0000714ce89dd526  push r11
0000714ce89dd528  sub rsp, 0xF0
0000714ce89dd52f  vmovaps [rsp], xmm0
0000714ce89dd534  vmovaps [rsp+0x10], xmm1
0000714ce89dd53a  vmovaps [rsp+0x20], xmm2
0000714ce89dd540  vmovaps [rsp+0x30], xmm3
0000714ce89dd546  vmovaps [rsp+0x40], xmm4
0000714ce89dd54c  vmovaps [rsp+0x50], xmm5
0000714ce89dd552  vmovaps [rsp+0x60], xmm6
0000714ce89dd558  vmovaps [rsp+0x70], xmm7
0000714ce89dd55e  vmovaps [rsp+0x80], xmm8
0000714ce89dd567  vmovaps [rsp+0x90], xmm9
0000714ce89dd570  vmovaps [rsp+0xA0], xmm10
0000714ce89dd579  vmovaps [rsp+0xB0], xmm11
0000714ce89dd582  vmovaps [rsp+0xC0], xmm13
0000714ce89dd58b  vmovaps [rsp+0xD0], xmm14
0000714ce89dd594  vmovaps [rsp+0xE0], xmm15
0000714ce89dd59d  sub rsp, 0x30
0000714ce89dd5a1  movaps [rsp], xmm12
0000714ce89dd5a6  movaps [rsp+0x10], xmm7
0000714ce89dd5ab  movaps [rsp+0x20], xmm13
0000714ce89dd5b1  lea rdi, [rsp]
0000714ce89dd5b5  mov esi, 0x00
0000714ce89dd5ba  mov rax, 0x57A55D340530
0000714ce89dd5c4  call rax
0000714ce89dd5c6  movaps xmm12, [rsp]
0000714ce89dd5cb  add rsp, 0x30
0000714ce89dd5cf  vmovaps xmm0, [rsp]
0000714ce89dd5d4  vmovaps xmm1, [rsp+0x10]
0000714ce89dd5da  vmovaps xmm2, [rsp+0x20]
0000714ce89dd5e0  vmovaps xmm3, [rsp+0x30]
0000714ce89dd5e6  vmovaps xmm4, [rsp+0x40]
0000714ce89dd5ec  vmovaps xmm5, [rsp+0x50]
0000714ce89dd5f2  vmovaps xmm6, [rsp+0x60]
0000714ce89dd5f8  vmovaps xmm7, [rsp+0x70]
0000714ce89dd5fe  vmovaps xmm8, [rsp+0x80]
0000714ce89dd607  vmovaps xmm9, [rsp+0x90]
0000714ce89dd610  vmovaps xmm10, [rsp+0xA0]
0000714ce89dd619  vmovaps xmm11, [rsp+0xB0]
0000714ce89dd622  vmovaps xmm13, [rsp+0xC0]
0000714ce89dd62b  vmovaps xmm14, [rsp+0xD0]
0000714ce89dd634  vmovaps xmm15, [rsp+0xE0]
0000714ce89dd63d  add rsp, 0xF0
0000714ce89dd644  pop r11
0000714ce89dd646  pop r10
0000714ce89dd648  pop r9
0000714ce89dd64a  pop r8
0000714ce89dd64c  pop rsi
0000714ce89dd64d  pop rdi
0000714ce89dd64e  pop rdx
0000714ce89dd64f  pop rcx
0000714ce89dd650  pop rax
0000714ce89dd651  add rsp, 0x08
0000714ce89dd655  jmp 0x0000714CE89D9621
0000714ce89dd65a  sub rsp, 0x08
0000714ce89dd65e  push rax
0000714ce89dd65f  push rcx
0000714ce89dd660  push rdx
0000714ce89dd661  push rdi
0000714ce89dd662  push rsi
0000714ce89dd663  push r8
0000714ce89dd665  push r9
0000714ce89dd667  push r10
0000714ce89dd669  push r11
0000714ce89dd66b  sub rsp, 0xF0
0000714ce89dd672  vmovaps [rsp], xmm0
0000714ce89dd677  vmovaps [rsp+0x10], xmm1
0000714ce89dd67d  vmovaps [rsp+0x20], xmm2
0000714ce89dd683  vmovaps [rsp+0x30], xmm3
0000714ce89dd689  vmovaps [rsp+0x40], xmm4
0000714ce89dd68f  vmovaps [rsp+0x50], xmm5
0000714ce89dd695  vmovaps [rsp+0x60], xmm6
0000714ce89dd69b  vmovaps [rsp+0x70], xmm7
0000714ce89dd6a1  vmovaps [rsp+0x80], xmm8
0000714ce89dd6aa  vmovaps [rsp+0x90], xmm9
0000714ce89dd6b3  vmovaps [rsp+0xA0], xmm10
0000714ce89dd6bc  vmovaps [rsp+0xB0], xmm11
0000714ce89dd6c5  vmovaps [rsp+0xC0], xmm12
0000714ce89dd6ce  vmovaps [rsp+0xD0], xmm14
0000714ce89dd6d7  vmovaps [rsp+0xE0], xmm15
0000714ce89dd6e0  sub rsp, 0x30
0000714ce89dd6e4  movaps [rsp], xmm13
0000714ce89dd6e9  movaps [rsp+0x10], xmm15
0000714ce89dd6ef  movaps [rsp+0x20], xmm8
0000714ce89dd6f5  lea rdi, [rsp]
0000714ce89dd6f9  mov esi, 0x00
0000714ce89dd6fe  mov rax, 0x57A55D340530
0000714ce89dd708  call rax
0000714ce89dd70a  movaps xmm13, [rsp]
0000714ce89dd70f  add rsp, 0x30
0000714ce89dd713  vmovaps xmm0, [rsp]
0000714ce89dd718  vmovaps xmm1, [rsp+0x10]
0000714ce89dd71e  vmovaps xmm2, [rsp+0x20]
0000714ce89dd724  vmovaps xmm3, [rsp+0x30]
0000714ce89dd72a  vmovaps xmm4, [rsp+0x40]
0000714ce89dd730  vmovaps xmm5, [rsp+0x50]
0000714ce89dd736  vmovaps xmm6, [rsp+0x60]
0000714ce89dd73c  vmovaps xmm7, [rsp+0x70]
0000714ce89dd742  vmovaps xmm8, [rsp+0x80]
0000714ce89dd74b  vmovaps xmm9, [rsp+0x90]
0000714ce89dd754  vmovaps xmm10, [rsp+0xA0]
0000714ce89dd75d  vmovaps xmm11, [rsp+0xB0]
0000714ce89dd766  vmovaps xmm12, [rsp+0xC0]
0000714ce89dd76f  vmovaps xmm14, [rsp+0xD0]
0000714ce89dd778  vmovaps xmm15, [rsp+0xE0]
0000714ce89dd781  add rsp, 0xF0
0000714ce89dd788  pop r11
0000714ce89dd78a  pop r10
0000714ce89dd78c  pop r9
0000714ce89dd78e  pop r8
0000714ce89dd790  pop rsi
0000714ce89dd791  pop rdi
0000714ce89dd792  pop rdx
0000714ce89dd793  pop rcx
0000714ce89dd794  pop rax
0000714ce89dd795  add rsp, 0x08
0000714ce89dd799  jmp 0x0000714CE89D963C
0000714ce89dd79e  sub rsp, 0x08
0000714ce89dd7a2  push rax
0000714ce89dd7a3  push rcx
0000714ce89dd7a4  push rdx
0000714ce89dd7a5  push rdi
0000714ce89dd7a6  push rsi
0000714ce89dd7a7  push r8
0000714ce89dd7a9  push r9
0000714ce89dd7ab  push r10
0000714ce89dd7ad  push r11
0000714ce89dd7af  sub rsp, 0xF0
0000714ce89dd7b6  vmovaps [rsp], xmm0
0000714ce89dd7bb  vmovaps [rsp+0x10], xmm1
0000714ce89dd7c1  vmovaps [rsp+0x20], xmm2
0000714ce89dd7c7  vmovaps [rsp+0x30], xmm3
0000714ce89dd7cd  vmovaps [rsp+0x40], xmm4
0000714ce89dd7d3  vmovaps [rsp+0x50], xmm5
0000714ce89dd7d9  vmovaps [rsp+0x60], xmm6
0000714ce89dd7df  vmovaps [rsp+0x70], xmm7
0000714ce89dd7e5  vmovaps [rsp+0x80], xmm9
0000714ce89dd7ee  vmovaps [rsp+0x90], xmm10
0000714ce89dd7f7  vmovaps [rsp+0xA0], xmm11
0000714ce89dd800  vmovaps [rsp+0xB0], xmm12
0000714ce89dd809  vmovaps [rsp+0xC0], xmm13
0000714ce89dd812  vmovaps [rsp+0xD0], xmm14
0000714ce89dd81b  vmovaps [rsp+0xE0], xmm15
0000714ce89dd824  sub rsp, 0x30
0000714ce89dd828  movaps [rsp], xmm8
0000714ce89dd82d  movaps [rsp+0x10], xmm15
0000714ce89dd833  movaps [rsp+0x20], xmm9
0000714ce89dd839  lea rdi, [rsp]
0000714ce89dd83d  mov esi, 0x00
0000714ce89dd842  mov rax, 0x57A55D340530
0000714ce89dd84c  call rax
0000714ce89dd84e  movaps xmm8, [rsp]
0000714ce89dd853  add rsp, 0x30
0000714ce89dd857  vmovaps xmm0, [rsp]
0000714ce89dd85c  vmovaps xmm1, [rsp+0x10]
0000714ce89dd862  vmovaps xmm2, [rsp+0x20]
0000714ce89dd868  vmovaps xmm3, [rsp+0x30]
0000714ce89dd86e  vmovaps xmm4, [rsp+0x40]
0000714ce89dd874  vmovaps xmm5, [rsp+0x50]
0000714ce89dd87a  vmovaps xmm6, [rsp+0x60]
0000714ce89dd880  vmovaps xmm7, [rsp+0x70]
0000714ce89dd886  vmovaps xmm9, [rsp+0x80]
0000714ce89dd88f  vmovaps xmm10, [rsp+0x90]
0000714ce89dd898  vmovaps xmm11, [rsp+0xA0]
0000714ce89dd8a1  vmovaps xmm12, [rsp+0xB0]
0000714ce89dd8aa  vmovaps xmm13, [rsp+0xC0]
0000714ce89dd8b3  vmovaps xmm14, [rsp+0xD0]
0000714ce89dd8bc  vmovaps xmm15, [rsp+0xE0]
0000714ce89dd8c5  add rsp, 0xF0
0000714ce89dd8cc  pop r11
0000714ce89dd8ce  pop r10
0000714ce89dd8d0  pop r9
0000714ce89dd8d2  pop r8
0000714ce89dd8d4  pop rsi
0000714ce89dd8d5  pop rdi
0000714ce89dd8d6  pop rdx
0000714ce89dd8d7  pop rcx
0000714ce89dd8d8  pop rax
0000714ce89dd8d9  add rsp, 0x08
0000714ce89dd8dd  jmp 0x0000714CE89D966A
0000714ce89dd8e2  sub rsp, 0x08
0000714ce89dd8e6  push rax
0000714ce89dd8e7  push rcx
0000714ce89dd8e8  push rdx
0000714ce89dd8e9  push rdi
0000714ce89dd8ea  push rsi
0000714ce89dd8eb  push r8
0000714ce89dd8ed  push r9
0000714ce89dd8ef  push r10
0000714ce89dd8f1  push r11
0000714ce89dd8f3  sub rsp, 0xF0
0000714ce89dd8fa  vmovaps [rsp], xmm0
0000714ce89dd8ff  vmovaps [rsp+0x10], xmm1
0000714ce89dd905  vmovaps [rsp+0x20], xmm2
0000714ce89dd90b  vmovaps [rsp+0x30], xmm3
0000714ce89dd911  vmovaps [rsp+0x40], xmm4
0000714ce89dd917  vmovaps [rsp+0x50], xmm5
0000714ce89dd91d  vmovaps [rsp+0x60], xmm6
0000714ce89dd923  vmovaps [rsp+0x70], xmm7
0000714ce89dd929  vmovaps [rsp+0x80], xmm8
0000714ce89dd932  vmovaps [rsp+0x90], xmm9
0000714ce89dd93b  vmovaps [rsp+0xA0], xmm10
0000714ce89dd944  vmovaps [rsp+0xB0], xmm11
0000714ce89dd94d  vmovaps [rsp+0xC0], xmm12
0000714ce89dd956  vmovaps [rsp+0xD0], xmm13
0000714ce89dd95f  vmovaps [rsp+0xE0], xmm14
0000714ce89dd968  sub rsp, 0x30
0000714ce89dd96c  movaps [rsp], xmm15
0000714ce89dd971  movaps [rsp+0x10], xmm11
0000714ce89dd977  movaps [rsp+0x20], xmm6
0000714ce89dd97c  lea rdi, [rsp]
0000714ce89dd980  mov esi, 0x00
0000714ce89dd985  mov rax, 0x57A55D340530
0000714ce89dd98f  call rax
0000714ce89dd991  movaps xmm15, [rsp]
0000714ce89dd996  add rsp, 0x30
0000714ce89dd99a  vmovaps xmm0, [rsp]
0000714ce89dd99f  vmovaps xmm1, [rsp+0x10]
0000714ce89dd9a5  vmovaps xmm2, [rsp+0x20]
0000714ce89dd9ab  vmovaps xmm3, [rsp+0x30]
0000714ce89dd9b1  vmovaps xmm4, [rsp+0x40]
0000714ce89dd9b7  vmovaps xmm5, [rsp+0x50]
0000714ce89dd9bd  vmovaps xmm6, [rsp+0x60]
0000714ce89dd9c3  vmovaps xmm7, [rsp+0x70]
0000714ce89dd9c9  vmovaps xmm8, [rsp+0x80]
0000714ce89dd9d2  vmovaps xmm9, [rsp+0x90]
0000714ce89dd9db  vmovaps xmm10, [rsp+0xA0]
0000714ce89dd9e4  vmovaps xmm11, [rsp+0xB0]
0000714ce89dd9ed  vmovaps xmm12, [rsp+0xC0]
0000714ce89dd9f6  vmovaps xmm13, [rsp+0xD0]
0000714ce89dd9ff  vmovaps xmm14, [rsp+0xE0]
0000714ce89dda08  add rsp, 0xF0
0000714ce89dda0f  pop r11
0000714ce89dda11  pop r10
0000714ce89dda13  pop r9
0000714ce89dda15  pop r8
0000714ce89dda17  pop rsi
0000714ce89dda18  pop rdi
0000714ce89dda19  pop rdx
0000714ce89dda1a  pop rcx
0000714ce89dda1b  pop rax
0000714ce89dda1c  add rsp, 0x08
0000714ce89dda20  jmp 0x0000714CE89D9685
0000714ce89dda25  sub rsp, 0x08
0000714ce89dda29  push rax
0000714ce89dda2a  push rcx
0000714ce89dda2b  push rdx
0000714ce89dda2c  push rdi
0000714ce89dda2d  push rsi
0000714ce89dda2e  push r8
0000714ce89dda30  push r9
0000714ce89dda32  push r10
0000714ce89dda34  push r11
0000714ce89dda36  sub rsp, 0xF0
0000714ce89dda3d  vmovaps [rsp], xmm0
0000714ce89dda42  vmovaps [rsp+0x10], xmm1
0000714ce89dda48  vmovaps [rsp+0x20], xmm2
0000714ce89dda4e  vmovaps [rsp+0x30], xmm3
0000714ce89dda54  vmovaps [rsp+0x40], xmm4
0000714ce89dda5a  vmovaps [rsp+0x50], xmm5
0000714ce89dda60  vmovaps [rsp+0x60], xmm6
0000714ce89dda66  vmovaps [rsp+0x70], xmm8
0000714ce89dda6c  vmovaps [rsp+0x80], xmm9
0000714ce89dda75  vmovaps [rsp+0x90], xmm10
0000714ce89dda7e  vmovaps [rsp+0xA0], xmm11
0000714ce89dda87  vmovaps [rsp+0xB0], xmm12
0000714ce89dda90  vmovaps [rsp+0xC0], xmm13
0000714ce89dda99  vmovaps [rsp+0xD0], xmm14
0000714ce89ddaa2  vmovaps [rsp+0xE0], xmm15
0000714ce89ddaab  sub rsp, 0x30
0000714ce89ddaaf  movaps [rsp], xmm7
0000714ce89ddab3  movaps [rsp+0x10], xmm11
0000714ce89ddab9  movaps [rsp+0x20], xmm9
0000714ce89ddabf  lea rdi, [rsp]
0000714ce89ddac3  mov esi, 0x00
0000714ce89ddac8  mov rax, 0x57A55D340530
0000714ce89ddad2  call rax
0000714ce89ddad4  movaps xmm7, [rsp]
0000714ce89ddad8  add rsp, 0x30
0000714ce89ddadc  vmovaps xmm0, [rsp]
0000714ce89ddae1  vmovaps xmm1, [rsp+0x10]
0000714ce89ddae7  vmovaps xmm2, [rsp+0x20]
0000714ce89ddaed  vmovaps xmm3, [rsp+0x30]
0000714ce89ddaf3  vmovaps xmm4, [rsp+0x40]
0000714ce89ddaf9  vmovaps xmm5, [rsp+0x50]
0000714ce89ddaff  vmovaps xmm6, [rsp+0x60]
0000714ce89ddb05  vmovaps xmm8, [rsp+0x70]
0000714ce89ddb0b  vmovaps xmm9, [rsp+0x80]
0000714ce89ddb14  vmovaps xmm10, [rsp+0x90]
0000714ce89ddb1d  vmovaps xmm11, [rsp+0xA0]
0000714ce89ddb26  vmovaps xmm12, [rsp+0xB0]
0000714ce89ddb2f  vmovaps xmm13, [rsp+0xC0]
0000714ce89ddb38  vmovaps xmm14, [rsp+0xD0]
0000714ce89ddb41  vmovaps xmm15, [rsp+0xE0]
0000714ce89ddb4a  add rsp, 0xF0
0000714ce89ddb51  pop r11
0000714ce89ddb53  pop r10
0000714ce89ddb55  pop r9
0000714ce89ddb57  pop r8
0000714ce89ddb59  pop rsi
0000714ce89ddb5a  pop rdi
0000714ce89ddb5b  pop rdx
0000714ce89ddb5c  pop rcx
0000714ce89ddb5d  pop rax
0000714ce89ddb5e  add rsp, 0x08
0000714ce89ddb62  jmp 0x0000714CE89D96B2
0000714ce89ddb67  sub rsp, 0x08
0000714ce89ddb6b  push rax
0000714ce89ddb6c  push rcx
0000714ce89ddb6d  push rdx
0000714ce89ddb6e  push rdi
0000714ce89ddb6f  push rsi
0000714ce89ddb70  push r8
0000714ce89ddb72  push r9
0000714ce89ddb74  push r10
0000714ce89ddb76  push r11
0000714ce89ddb78  sub rsp, 0xF0
0000714ce89ddb7f  vmovaps [rsp], xmm0
0000714ce89ddb84  vmovaps [rsp+0x10], xmm1
0000714ce89ddb8a  vmovaps [rsp+0x20], xmm2
0000714ce89ddb90  vmovaps [rsp+0x30], xmm3
0000714ce89ddb96  vmovaps [rsp+0x40], xmm4
0000714ce89ddb9c  vmovaps [rsp+0x50], xmm5
0000714ce89ddba2  vmovaps [rsp+0x60], xmm6
0000714ce89ddba8  vmovaps [rsp+0x70], xmm7
0000714ce89ddbae  vmovaps [rsp+0x80], xmm8
0000714ce89ddbb7  vmovaps [rsp+0x90], xmm9
0000714ce89ddbc0  vmovaps [rsp+0xA0], xmm10
0000714ce89ddbc9  vmovaps [rsp+0xB0], xmm12
0000714ce89ddbd2  vmovaps [rsp+0xC0], xmm13
0000714ce89ddbdb  vmovaps [rsp+0xD0], xmm14
0000714ce89ddbe4  vmovaps [rsp+0xE0], xmm15
0000714ce89ddbed  sub rsp, 0x30
0000714ce89ddbf1  movaps [rsp], xmm11
0000714ce89ddbf6  movaps [rsp+0x10], xmm10
0000714ce89ddbfc  movaps [rsp+0x20], xmm14
0000714ce89ddc02  lea rdi, [rsp]
0000714ce89ddc06  mov esi, 0x00
0000714ce89ddc0b  mov rax, 0x57A55D340530
0000714ce89ddc15  call rax
0000714ce89ddc17  movaps xmm11, [rsp]
0000714ce89ddc1c  add rsp, 0x30
0000714ce89ddc20  vmovaps xmm0, [rsp]
0000714ce89ddc25  vmovaps xmm1, [rsp+0x10]
0000714ce89ddc2b  vmovaps xmm2, [rsp+0x20]
0000714ce89ddc31  vmovaps xmm3, [rsp+0x30]
0000714ce89ddc37  vmovaps xmm4, [rsp+0x40]
0000714ce89ddc3d  vmovaps xmm5, [rsp+0x50]
0000714ce89ddc43  vmovaps xmm6, [rsp+0x60]
0000714ce89ddc49  vmovaps xmm7, [rsp+0x70]
0000714ce89ddc4f  vmovaps xmm8, [rsp+0x80]
0000714ce89ddc58  vmovaps xmm9, [rsp+0x90]
0000714ce89ddc61  vmovaps xmm10, [rsp+0xA0]
0000714ce89ddc6a  vmovaps xmm12, [rsp+0xB0]
0000714ce89ddc73  vmovaps xmm13, [rsp+0xC0]
0000714ce89ddc7c  vmovaps xmm14, [rsp+0xD0]
0000714ce89ddc85  vmovaps xmm15, [rsp+0xE0]
0000714ce89ddc8e  add rsp, 0xF0
0000714ce89ddc95  pop r11
0000714ce89ddc97  pop r10
0000714ce89ddc99  pop r9
0000714ce89ddc9b  pop r8
0000714ce89ddc9d  pop rsi
0000714ce89ddc9e  pop rdi
0000714ce89ddc9f  pop rdx
0000714ce89ddca0  pop rcx
0000714ce89ddca1  pop rax
0000714ce89ddca2  add rsp, 0x08
0000714ce89ddca6  jmp 0x0000714CE89D96CD
0000714ce89ddcab  call 0x0000714CE88E45A0
0000714ce89ddcb0  jmp 0x0000714CE89D96D7
0000714ce89ddcb5  sub rsp, 0x08
0000714ce89ddcb9  push rax
0000714ce89ddcba  push rcx
0000714ce89ddcbb  push rdx
0000714ce89ddcbc  push rdi
0000714ce89ddcbd  push rsi
0000714ce89ddcbe  push r8
0000714ce89ddcc0  push r9
0000714ce89ddcc2  push r10
0000714ce89ddcc4  push r11
0000714ce89ddcc6  sub rsp, 0xF0
0000714ce89ddccd  vmovaps [rsp], xmm0
0000714ce89ddcd2  vmovaps [rsp+0x10], xmm1
0000714ce89ddcd8  vmovaps [rsp+0x20], xmm2
0000714ce89ddcde  vmovaps [rsp+0x30], xmm3
0000714ce89ddce4  vmovaps [rsp+0x40], xmm4
0000714ce89ddcea  vmovaps [rsp+0x50], xmm5
0000714ce89ddcf0  vmovaps [rsp+0x60], xmm6
0000714ce89ddcf6  vmovaps [rsp+0x70], xmm7
0000714ce89ddcfc  vmovaps [rsp+0x80], xmm8
0000714ce89ddd05  vmovaps [rsp+0x90], xmm9
0000714ce89ddd0e  vmovaps [rsp+0xA0], xmm11
0000714ce89ddd17  vmovaps [rsp+0xB0], xmm12
0000714ce89ddd20  vmovaps [rsp+0xC0], xmm13
0000714ce89ddd29  vmovaps [rsp+0xD0], xmm14
0000714ce89ddd32  vmovaps [rsp+0xE0], xmm15
0000714ce89ddd3b  sub rsp, 0x30
0000714ce89ddd3f  movaps [rsp], xmm10
0000714ce89ddd44  movaps [rsp+0x10], xmm1
0000714ce89ddd49  movaps [rsp+0x20], xmm12
0000714ce89ddd4f  lea rdi, [rsp]
0000714ce89ddd53  mov esi, 0x00
0000714ce89ddd58  mov rax, 0x57A55D340530
0000714ce89ddd62  call rax
0000714ce89ddd64  movaps xmm10, [rsp]
0000714ce89ddd69  add rsp, 0x30
0000714ce89ddd6d  vmovaps xmm0, [rsp]
0000714ce89ddd72  vmovaps xmm1, [rsp+0x10]
0000714ce89ddd78  vmovaps xmm2, [rsp+0x20]
0000714ce89ddd7e  vmovaps xmm3, [rsp+0x30]
0000714ce89ddd84  vmovaps xmm4, [rsp+0x40]
0000714ce89ddd8a  vmovaps xmm5, [rsp+0x50]
0000714ce89ddd90  vmovaps xmm6, [rsp+0x60]
0000714ce89ddd96  vmovaps xmm7, [rsp+0x70]
0000714ce89ddd9c  vmovaps xmm8, [rsp+0x80]
0000714ce89ddda5  vmovaps xmm9, [rsp+0x90]
0000714ce89dddae  vmovaps xmm11, [rsp+0xA0]
0000714ce89dddb7  vmovaps xmm12, [rsp+0xB0]
0000714ce89dddc0  vmovaps xmm13, [rsp+0xC0]
0000714ce89dddc9  vmovaps xmm14, [rsp+0xD0]
0000714ce89dddd2  vmovaps xmm15, [rsp+0xE0]
0000714ce89ddddb  add rsp, 0xF0
0000714ce89ddde2  pop r11
0000714ce89ddde4  pop r10
0000714ce89ddde6  pop r9
0000714ce89ddde8  pop r8
0000714ce89dddea  pop rsi
0000714ce89dddeb  pop rdi
0000714ce89dddec  pop rdx
0000714ce89ddded  pop rcx
0000714ce89dddee  pop rax
0000714ce89dddef  add rsp, 0x08
0000714ce89dddf3  jmp 0x0000714CE89D96FA
0000714ce89dddf8  sub rsp, 0x08
0000714ce89dddfc  push rax
0000714ce89dddfd  push rcx
0000714ce89dddfe  push rdx
0000714ce89dddff  push rdi
0000714ce89dde00  push rsi
0000714ce89dde01  push r8
0000714ce89dde03  push r9
0000714ce89dde05  push r10
0000714ce89dde07  push r11
0000714ce89dde09  sub rsp, 0xF0
0000714ce89dde10  vmovaps [rsp], xmm0
0000714ce89dde15  vmovaps [rsp+0x10], xmm1
0000714ce89dde1b  vmovaps [rsp+0x20], xmm2
0000714ce89dde21  vmovaps [rsp+0x30], xmm3
0000714ce89dde27  vmovaps [rsp+0x40], xmm4
0000714ce89dde2d  vmovaps [rsp+0x50], xmm5
0000714ce89dde33  vmovaps [rsp+0x60], xmm6
0000714ce89dde39  vmovaps [rsp+0x70], xmm7
0000714ce89dde3f  vmovaps [rsp+0x80], xmm8
0000714ce89dde48  vmovaps [rsp+0x90], xmm9
0000714ce89dde51  vmovaps [rsp+0xA0], xmm10
0000714ce89dde5a  vmovaps [rsp+0xB0], xmm11
0000714ce89dde63  vmovaps [rsp+0xC0], xmm13
0000714ce89dde6c  vmovaps [rsp+0xD0], xmm14
0000714ce89dde75  vmovaps [rsp+0xE0], xmm15
0000714ce89dde7e  sub rsp, 0x30
0000714ce89dde82  movaps [rsp], xmm12
0000714ce89dde87  movaps [rsp+0x10], xmm14
0000714ce89dde8d  movaps [rsp+0x20], xmm1
0000714ce89dde92  lea rdi, [rsp]
0000714ce89dde96  mov esi, 0x00
0000714ce89dde9b  mov rax, 0x57A55D340530
0000714ce89ddea5  call rax
0000714ce89ddea7  movaps xmm12, [rsp]
0000714ce89ddeac  add rsp, 0x30
0000714ce89ddeb0  vmovaps xmm0, [rsp]
0000714ce89ddeb5  vmovaps xmm1, [rsp+0x10]
0000714ce89ddebb  vmovaps xmm2, [rsp+0x20]
0000714ce89ddec1  vmovaps xmm3, [rsp+0x30]
0000714ce89ddec7  vmovaps xmm4, [rsp+0x40]
0000714ce89ddecd  vmovaps xmm5, [rsp+0x50]
0000714ce89dded3  vmovaps xmm6, [rsp+0x60]
0000714ce89dded9  vmovaps xmm7, [rsp+0x70]
0000714ce89ddedf  vmovaps xmm8, [rsp+0x80]
0000714ce89ddee8  vmovaps xmm9, [rsp+0x90]
0000714ce89ddef1  vmovaps xmm10, [rsp+0xA0]
0000714ce89ddefa  vmovaps xmm11, [rsp+0xB0]
0000714ce89ddf03  vmovaps xmm13, [rsp+0xC0]
0000714ce89ddf0c  vmovaps xmm14, [rsp+0xD0]
0000714ce89ddf15  vmovaps xmm15, [rsp+0xE0]
0000714ce89ddf1e  add rsp, 0xF0
0000714ce89ddf25  pop r11
0000714ce89ddf27  pop r10
0000714ce89ddf29  pop r9
0000714ce89ddf2b  pop r8
0000714ce89ddf2d  pop rsi
0000714ce89ddf2e  pop rdi
0000714ce89ddf2f  pop rdx
0000714ce89ddf30  pop rcx
0000714ce89ddf31  pop rax
0000714ce89ddf32  add rsp, 0x08
0000714ce89ddf36  jmp 0x0000714CE89D9729
0000714ce89ddf3b  sub rsp, 0x08
0000714ce89ddf3f  push rax
0000714ce89ddf40  push rcx
0000714ce89ddf41  push rdx
0000714ce89ddf42  push rdi
0000714ce89ddf43  push rsi
0000714ce89ddf44  push r8
0000714ce89ddf46  push r9
0000714ce89ddf48  push r10
0000714ce89ddf4a  push r11
0000714ce89ddf4c  sub rsp, 0xF0
0000714ce89ddf53  vmovaps [rsp], xmm0
0000714ce89ddf58  vmovaps [rsp+0x10], xmm1
0000714ce89ddf5e  vmovaps [rsp+0x20], xmm2
0000714ce89ddf64  vmovaps [rsp+0x30], xmm3
0000714ce89ddf6a  vmovaps [rsp+0x40], xmm4
0000714ce89ddf70  vmovaps [rsp+0x50], xmm5
0000714ce89ddf76  vmovaps [rsp+0x60], xmm6
0000714ce89ddf7c  vmovaps [rsp+0x70], xmm7
0000714ce89ddf82  vmovaps [rsp+0x80], xmm8
0000714ce89ddf8b  vmovaps [rsp+0x90], xmm9
0000714ce89ddf94  vmovaps [rsp+0xA0], xmm10
0000714ce89ddf9d  vmovaps [rsp+0xB0], xmm11
0000714ce89ddfa6  vmovaps [rsp+0xC0], xmm12
0000714ce89ddfaf  vmovaps [rsp+0xD0], xmm13
0000714ce89ddfb8  vmovaps [rsp+0xE0], xmm15
0000714ce89ddfc1  sub rsp, 0x30
0000714ce89ddfc5  movaps [rsp], xmm14
0000714ce89ddfca  movaps [rsp+0x10], xmm9
0000714ce89ddfd0  movaps [rsp+0x20], xmm1
0000714ce89ddfd5  lea rdi, [rsp]
0000714ce89ddfd9  mov esi, 0x00
0000714ce89ddfde  mov rax, 0x57A55D340530
0000714ce89ddfe8  call rax
0000714ce89ddfea  movaps xmm14, [rsp]
0000714ce89ddfef  add rsp, 0x30
0000714ce89ddff3  vmovaps xmm0, [rsp]
0000714ce89ddff8  vmovaps xmm1, [rsp+0x10]
0000714ce89ddffe  vmovaps xmm2, [rsp+0x20]
0000714ce89de004  vmovaps xmm3, [rsp+0x30]
0000714ce89de00a  vmovaps xmm4, [rsp+0x40]
0000714ce89de010  vmovaps xmm5, [rsp+0x50]
0000714ce89de016  vmovaps xmm6, [rsp+0x60]
0000714ce89de01c  vmovaps xmm7, [rsp+0x70]
0000714ce89de022  vmovaps xmm8, [rsp+0x80]
0000714ce89de02b  vmovaps xmm9, [rsp+0x90]
0000714ce89de034  vmovaps xmm10, [rsp+0xA0]
0000714ce89de03d  vmovaps xmm11, [rsp+0xB0]
0000714ce89de046  vmovaps xmm12, [rsp+0xC0]
0000714ce89de04f  vmovaps xmm13, [rsp+0xD0]
0000714ce89de058  vmovaps xmm15, [rsp+0xE0]
0000714ce89de061  add rsp, 0xF0
0000714ce89de068  pop r11
0000714ce89de06a  pop r10
0000714ce89de06c  pop r9
0000714ce89de06e  pop r8
0000714ce89de070  pop rsi
0000714ce89de071  pop rdi
0000714ce89de072  pop rdx
0000714ce89de073  pop rcx
0000714ce89de074  pop rax
0000714ce89de075  add rsp, 0x08
0000714ce89de079  jmp 0x0000714CE89D9758
0000714ce89de07e  sub rsp, 0x08
0000714ce89de082  push rax
0000714ce89de083  push rcx
0000714ce89de084  push rdx
0000714ce89de085  push rdi
0000714ce89de086  push rsi
0000714ce89de087  push r8
0000714ce89de089  push r9
0000714ce89de08b  push r10
0000714ce89de08d  push r11
0000714ce89de08f  sub rsp, 0xF0
0000714ce89de096  vmovaps [rsp], xmm0
0000714ce89de09b  vmovaps [rsp+0x10], xmm2
0000714ce89de0a1  vmovaps [rsp+0x20], xmm3
0000714ce89de0a7  vmovaps [rsp+0x30], xmm4
0000714ce89de0ad  vmovaps [rsp+0x40], xmm5
0000714ce89de0b3  vmovaps [rsp+0x50], xmm6
0000714ce89de0b9  vmovaps [rsp+0x60], xmm7
0000714ce89de0bf  vmovaps [rsp+0x70], xmm8
0000714ce89de0c5  vmovaps [rsp+0x80], xmm9
0000714ce89de0ce  vmovaps [rsp+0x90], xmm10
0000714ce89de0d7  vmovaps [rsp+0xA0], xmm11
0000714ce89de0e0  vmovaps [rsp+0xB0], xmm12
0000714ce89de0e9  vmovaps [rsp+0xC0], xmm13
0000714ce89de0f2  vmovaps [rsp+0xD0], xmm14
0000714ce89de0fb  vmovaps [rsp+0xE0], xmm15
0000714ce89de104  sub rsp, 0x30
0000714ce89de108  movaps [rsp], xmm1
0000714ce89de10c  movaps [rsp+0x10], xmm13
0000714ce89de112  movaps [rsp+0x20], xmm8
0000714ce89de118  lea rdi, [rsp]
0000714ce89de11c  mov esi, 0x00
0000714ce89de121  mov rax, 0x57A55D340530
0000714ce89de12b  call rax
0000714ce89de12d  movaps xmm1, [rsp]
0000714ce89de131  add rsp, 0x30
0000714ce89de135  vmovaps xmm0, [rsp]
0000714ce89de13a  vmovaps xmm2, [rsp+0x10]
0000714ce89de140  vmovaps xmm3, [rsp+0x20]
0000714ce89de146  vmovaps xmm4, [rsp+0x30]
0000714ce89de14c  vmovaps xmm5, [rsp+0x40]
0000714ce89de152  vmovaps xmm6, [rsp+0x50]
0000714ce89de158  vmovaps xmm7, [rsp+0x60]
0000714ce89de15e  vmovaps xmm8, [rsp+0x70]
0000714ce89de164  vmovaps xmm9, [rsp+0x80]
0000714ce89de16d  vmovaps xmm10, [rsp+0x90]
0000714ce89de176  vmovaps xmm11, [rsp+0xA0]
0000714ce89de17f  vmovaps xmm12, [rsp+0xB0]
0000714ce89de188  vmovaps xmm13, [rsp+0xC0]
0000714ce89de191  vmovaps xmm14, [rsp+0xD0]
0000714ce89de19a  vmovaps xmm15, [rsp+0xE0]
0000714ce89de1a3  add rsp, 0xF0
0000714ce89de1aa  pop r11
0000714ce89de1ac  pop r10
0000714ce89de1ae  pop r9
0000714ce89de1b0  pop r8
0000714ce89de1b2  pop rsi
0000714ce89de1b3  pop rdi
0000714ce89de1b4  pop rdx
0000714ce89de1b5  pop rcx
0000714ce89de1b6  pop rax
0000714ce89de1b7  add rsp, 0x08
0000714ce89de1bb  jmp 0x0000714CE89D977A
0000714ce89de1c0  call 0x0000714CE880C260
0000714ce89de1c5  jmp 0x0000714CE89D9788
0000714ce89de1ca  call 0x0000714CE88DE950
0000714ce89de1cf  jmp 0x0000714CE89D9792
0000714ce89de1d4  sub rsp, 0x08
0000714ce89de1d8  push rax
0000714ce89de1d9  push rcx
0000714ce89de1da  push rdx
0000714ce89de1db  push rdi
0000714ce89de1dc  push rsi
0000714ce89de1dd  push r8
0000714ce89de1df  push r9
0000714ce89de1e1  push r10
0000714ce89de1e3  push r11
0000714ce89de1e5  sub rsp, 0xF0
0000714ce89de1ec  vmovaps [rsp], xmm0
0000714ce89de1f1  vmovaps [rsp+0x10], xmm1
0000714ce89de1f7  vmovaps [rsp+0x20], xmm2
0000714ce89de1fd  vmovaps [rsp+0x30], xmm3
0000714ce89de203  vmovaps [rsp+0x40], xmm4
0000714ce89de209  vmovaps [rsp+0x50], xmm5
0000714ce89de20f  vmovaps [rsp+0x60], xmm6
0000714ce89de215  vmovaps [rsp+0x70], xmm7
0000714ce89de21b  vmovaps [rsp+0x80], xmm9
0000714ce89de224  vmovaps [rsp+0x90], xmm10
0000714ce89de22d  vmovaps [rsp+0xA0], xmm11
0000714ce89de236  vmovaps [rsp+0xB0], xmm12
0000714ce89de23f  vmovaps [rsp+0xC0], xmm13
0000714ce89de248  vmovaps [rsp+0xD0], xmm14
0000714ce89de251  vmovaps [rsp+0xE0], xmm15
0000714ce89de25a  sub rsp, 0x30
0000714ce89de25e  movaps [rsp], xmm8
0000714ce89de263  movaps [rsp+0x10], xmm15
0000714ce89de269  movaps [rsp+0x20], xmm7
0000714ce89de26e  lea rdi, [rsp]
0000714ce89de272  mov esi, 0x00
0000714ce89de277  mov rax, 0x57A55D340530
0000714ce89de281  call rax
0000714ce89de283  movaps xmm8, [rsp]
0000714ce89de288  add rsp, 0x30
0000714ce89de28c  vmovaps xmm0, [rsp]
0000714ce89de291  vmovaps xmm1, [rsp+0x10]
0000714ce89de297  vmovaps xmm2, [rsp+0x20]
0000714ce89de29d  vmovaps xmm3, [rsp+0x30]
0000714ce89de2a3  vmovaps xmm4, [rsp+0x40]
0000714ce89de2a9  vmovaps xmm5, [rsp+0x50]
0000714ce89de2af  vmovaps xmm6, [rsp+0x60]
0000714ce89de2b5  vmovaps xmm7, [rsp+0x70]
0000714ce89de2bb  vmovaps xmm9, [rsp+0x80]
0000714ce89de2c4  vmovaps xmm10, [rsp+0x90]
0000714ce89de2cd  vmovaps xmm11, [rsp+0xA0]
0000714ce89de2d6  vmovaps xmm12, [rsp+0xB0]
0000714ce89de2df  vmovaps xmm13, [rsp+0xC0]
0000714ce89de2e8  vmovaps xmm14, [rsp+0xD0]
0000714ce89de2f1  vmovaps xmm15, [rsp+0xE0]
0000714ce89de2fa  add rsp, 0xF0
0000714ce89de301  pop r11
0000714ce89de303  pop r10
0000714ce89de305  pop r9
0000714ce89de307  pop r8
0000714ce89de309  pop rsi
0000714ce89de30a  pop rdi
0000714ce89de30b  pop rdx
0000714ce89de30c  pop rcx
0000714ce89de30d  pop rax
0000714ce89de30e  add rsp, 0x08
0000714ce89de312  jmp 0x0000714CE89D97B4
0000714ce89de317  sub rsp, 0x08
0000714ce89de31b  push rax
0000714ce89de31c  push rcx
0000714ce89de31d  push rdx
0000714ce89de31e  push rdi
0000714ce89de31f  push rsi
0000714ce89de320  push r8
0000714ce89de322  push r9
0000714ce89de324  push r10
0000714ce89de326  push r11
0000714ce89de328  sub rsp, 0xF0
0000714ce89de32f  vmovaps [rsp], xmm0
0000714ce89de334  vmovaps [rsp+0x10], xmm1
0000714ce89de33a  vmovaps [rsp+0x20], xmm2
0000714ce89de340  vmovaps [rsp+0x30], xmm3
0000714ce89de346  vmovaps [rsp+0x40], xmm4
0000714ce89de34c  vmovaps [rsp+0x50], xmm5
0000714ce89de352  vmovaps [rsp+0x60], xmm6
0000714ce89de358  vmovaps [rsp+0x70], xmm8
0000714ce89de35e  vmovaps [rsp+0x80], xmm9
0000714ce89de367  vmovaps [rsp+0x90], xmm10
0000714ce89de370  vmovaps [rsp+0xA0], xmm11
0000714ce89de379  vmovaps [rsp+0xB0], xmm12
0000714ce89de382  vmovaps [rsp+0xC0], xmm13
0000714ce89de38b  vmovaps [rsp+0xD0], xmm14
0000714ce89de394  vmovaps [rsp+0xE0], xmm15
0000714ce89de39d  sub rsp, 0x30
0000714ce89de3a1  movaps [rsp], xmm7
0000714ce89de3a5  movaps [rsp+0x10], xmm9
0000714ce89de3ab  movaps [rsp+0x20], xmm15
0000714ce89de3b1  lea rdi, [rsp]
0000714ce89de3b5  mov esi, 0x00
0000714ce89de3ba  mov rax, 0x57A55D340530
0000714ce89de3c4  call rax
0000714ce89de3c6  movaps xmm7, [rsp]
0000714ce89de3ca  add rsp, 0x30
0000714ce89de3ce  vmovaps xmm0, [rsp]
0000714ce89de3d3  vmovaps xmm1, [rsp+0x10]
0000714ce89de3d9  vmovaps xmm2, [rsp+0x20]
0000714ce89de3df  vmovaps xmm3, [rsp+0x30]
0000714ce89de3e5  vmovaps xmm4, [rsp+0x40]
0000714ce89de3eb  vmovaps xmm5, [rsp+0x50]
0000714ce89de3f1  vmovaps xmm6, [rsp+0x60]
0000714ce89de3f7  vmovaps xmm8, [rsp+0x70]
0000714ce89de3fd  vmovaps xmm9, [rsp+0x80]
0000714ce89de406  vmovaps xmm10, [rsp+0x90]
0000714ce89de40f  vmovaps xmm11, [rsp+0xA0]
0000714ce89de418  vmovaps xmm12, [rsp+0xB0]
0000714ce89de421  vmovaps xmm13, [rsp+0xC0]
0000714ce89de42a  vmovaps xmm14, [rsp+0xD0]
0000714ce89de433  vmovaps xmm15, [rsp+0xE0]
0000714ce89de43c  add rsp, 0xF0
0000714ce89de443  pop r11
0000714ce89de445  pop r10
0000714ce89de447  pop r9
0000714ce89de449  pop r8
0000714ce89de44b  pop rsi
0000714ce89de44c  pop rdi
0000714ce89de44d  pop rdx
0000714ce89de44e  pop rcx
0000714ce89de44f  pop rax
0000714ce89de450  add rsp, 0x08
0000714ce89de454  jmp 0x0000714CE89D97E1
0000714ce89de459  sub rsp, 0x08
0000714ce89de45d  push rax
0000714ce89de45e  push rcx
0000714ce89de45f  push rdx
0000714ce89de460  push rdi
0000714ce89de461  push rsi
0000714ce89de462  push r8
0000714ce89de464  push r9
0000714ce89de466  push r10
0000714ce89de468  push r11
0000714ce89de46a  sub rsp, 0xF0
0000714ce89de471  vmovaps [rsp], xmm0
0000714ce89de476  vmovaps [rsp+0x10], xmm1
0000714ce89de47c  vmovaps [rsp+0x20], xmm2
0000714ce89de482  vmovaps [rsp+0x30], xmm3
0000714ce89de488  vmovaps [rsp+0x40], xmm4
0000714ce89de48e  vmovaps [rsp+0x50], xmm5
0000714ce89de494  vmovaps [rsp+0x60], xmm6
0000714ce89de49a  vmovaps [rsp+0x70], xmm7
0000714ce89de4a0  vmovaps [rsp+0x80], xmm8
0000714ce89de4a9  vmovaps [rsp+0x90], xmm10
0000714ce89de4b2  vmovaps [rsp+0xA0], xmm11
0000714ce89de4bb  vmovaps [rsp+0xB0], xmm12
0000714ce89de4c4  vmovaps [rsp+0xC0], xmm13
0000714ce89de4cd  vmovaps [rsp+0xD0], xmm14
0000714ce89de4d6  vmovaps [rsp+0xE0], xmm15
0000714ce89de4df  sub rsp, 0x30
0000714ce89de4e3  movaps [rsp], xmm9
0000714ce89de4e8  movaps [rsp+0x10], xmm13
0000714ce89de4ee  movaps [rsp+0x20], xmm15
0000714ce89de4f4  lea rdi, [rsp]
0000714ce89de4f8  mov esi, 0x00
0000714ce89de4fd  mov rax, 0x57A55D340530
0000714ce89de507  call rax
0000714ce89de509  movaps xmm9, [rsp]
0000714ce89de50e  add rsp, 0x30
0000714ce89de512  vmovaps xmm0, [rsp]
0000714ce89de517  vmovaps xmm1, [rsp+0x10]
0000714ce89de51d  vmovaps xmm2, [rsp+0x20]
0000714ce89de523  vmovaps xmm3, [rsp+0x30]
0000714ce89de529  vmovaps xmm4, [rsp+0x40]
0000714ce89de52f  vmovaps xmm5, [rsp+0x50]
0000714ce89de535  vmovaps xmm6, [rsp+0x60]
0000714ce89de53b  vmovaps xmm7, [rsp+0x70]
0000714ce89de541  vmovaps xmm8, [rsp+0x80]
0000714ce89de54a  vmovaps xmm10, [rsp+0x90]
0000714ce89de553  vmovaps xmm11, [rsp+0xA0]
0000714ce89de55c  vmovaps xmm12, [rsp+0xB0]
0000714ce89de565  vmovaps xmm13, [rsp+0xC0]
0000714ce89de56e  vmovaps xmm14, [rsp+0xD0]
0000714ce89de577  vmovaps xmm15, [rsp+0xE0]
0000714ce89de580  add rsp, 0xF0
0000714ce89de587  pop r11
0000714ce89de589  pop r10
0000714ce89de58b  pop r9
0000714ce89de58d  pop r8
0000714ce89de58f  pop rsi
0000714ce89de590  pop rdi
0000714ce89de591  pop rdx
0000714ce89de592  pop rcx
0000714ce89de593  pop rax
0000714ce89de594  add rsp, 0x08
0000714ce89de598  jmp 0x0000714CE89D980F
0000714ce89de59d  sub rsp, 0x08
0000714ce89de5a1  push rax
0000714ce89de5a2  push rcx
0000714ce89de5a3  push rdx
0000714ce89de5a4  push rdi
0000714ce89de5a5  push rsi
0000714ce89de5a6  push r8
0000714ce89de5a8  push r9
0000714ce89de5aa  push r10
0000714ce89de5ac  push r11
0000714ce89de5ae  sub rsp, 0xF0
0000714ce89de5b5  vmovaps [rsp], xmm0
0000714ce89de5ba  vmovaps [rsp+0x10], xmm1
0000714ce89de5c0  vmovaps [rsp+0x20], xmm2
0000714ce89de5c6  vmovaps [rsp+0x30], xmm3
0000714ce89de5cc  vmovaps [rsp+0x40], xmm4
0000714ce89de5d2  vmovaps [rsp+0x50], xmm5
0000714ce89de5d8  vmovaps [rsp+0x60], xmm6
0000714ce89de5de  vmovaps [rsp+0x70], xmm7
0000714ce89de5e4  vmovaps [rsp+0x80], xmm8
0000714ce89de5ed  vmovaps [rsp+0x90], xmm9
0000714ce89de5f6  vmovaps [rsp+0xA0], xmm10
0000714ce89de5ff  vmovaps [rsp+0xB0], xmm11
0000714ce89de608  vmovaps [rsp+0xC0], xmm12
0000714ce89de611  vmovaps [rsp+0xD0], xmm13
0000714ce89de61a  vmovaps [rsp+0xE0], xmm14
0000714ce89de623  sub rsp, 0x30
0000714ce89de627  movaps [rsp], xmm15
0000714ce89de62c  movaps [rsp+0x10], xmm11
0000714ce89de632  movaps [rsp+0x20], xmm12
0000714ce89de638  lea rdi, [rsp]
0000714ce89de63c  mov esi, 0x00
0000714ce89de641  mov rax, 0x57A55D340530
0000714ce89de64b  call rax
0000714ce89de64d  movaps xmm15, [rsp]
0000714ce89de652  add rsp, 0x30
0000714ce89de656  vmovaps xmm0, [rsp]
0000714ce89de65b  vmovaps xmm1, [rsp+0x10]
0000714ce89de661  vmovaps xmm2, [rsp+0x20]
0000714ce89de667  vmovaps xmm3, [rsp+0x30]
0000714ce89de66d  vmovaps xmm4, [rsp+0x40]
0000714ce89de673  vmovaps xmm5, [rsp+0x50]
0000714ce89de679  vmovaps xmm6, [rsp+0x60]
0000714ce89de67f  vmovaps xmm7, [rsp+0x70]
0000714ce89de685  vmovaps xmm8, [rsp+0x80]
0000714ce89de68e  vmovaps xmm9, [rsp+0x90]
0000714ce89de697  vmovaps xmm10, [rsp+0xA0]
0000714ce89de6a0  vmovaps xmm11, [rsp+0xB0]
0000714ce89de6a9  vmovaps xmm12, [rsp+0xC0]
0000714ce89de6b2  vmovaps xmm13, [rsp+0xD0]
0000714ce89de6bb  vmovaps xmm14, [rsp+0xE0]
0000714ce89de6c4  add rsp, 0xF0
0000714ce89de6cb  pop r11
0000714ce89de6cd  pop r10
0000714ce89de6cf  pop r9
0000714ce89de6d1  pop r8
0000714ce89de6d3  pop rsi
0000714ce89de6d4  pop rdi
0000714ce89de6d5  pop rdx
0000714ce89de6d6  pop rcx
0000714ce89de6d7  pop rax
0000714ce89de6d8  add rsp, 0x08
0000714ce89de6dc  jmp 0x0000714CE89D982A
0000714ce89de6e1  sub rsp, 0x08
0000714ce89de6e5  push rax
0000714ce89de6e6  push rcx
0000714ce89de6e7  push rdx
0000714ce89de6e8  push rdi
0000714ce89de6e9  push rsi
0000714ce89de6ea  push r8
0000714ce89de6ec  push r9
0000714ce89de6ee  push r10
0000714ce89de6f0  push r11
0000714ce89de6f2  sub rsp, 0xF0
0000714ce89de6f9  vmovaps [rsp], xmm0
0000714ce89de6fe  vmovaps [rsp+0x10], xmm1
0000714ce89de704  vmovaps [rsp+0x20], xmm2
0000714ce89de70a  vmovaps [rsp+0x30], xmm3
0000714ce89de710  vmovaps [rsp+0x40], xmm4
0000714ce89de716  vmovaps [rsp+0x50], xmm5
0000714ce89de71c  vmovaps [rsp+0x60], xmm6
0000714ce89de722  vmovaps [rsp+0x70], xmm7
0000714ce89de728  vmovaps [rsp+0x80], xmm8
0000714ce89de731  vmovaps [rsp+0x90], xmm9
0000714ce89de73a  vmovaps [rsp+0xA0], xmm10
0000714ce89de743  vmovaps [rsp+0xB0], xmm11
0000714ce89de74c  vmovaps [rsp+0xC0], xmm12
0000714ce89de755  vmovaps [rsp+0xD0], xmm14
0000714ce89de75e  vmovaps [rsp+0xE0], xmm15
0000714ce89de767  sub rsp, 0x30
0000714ce89de76b  movaps [rsp], xmm13
0000714ce89de770  movaps [rsp+0x10], xmm10
0000714ce89de776  movaps [rsp+0x20], xmm14
0000714ce89de77c  lea rdi, [rsp]
0000714ce89de780  mov esi, 0x00
0000714ce89de785  mov rax, 0x57A55D340530
0000714ce89de78f  call rax
0000714ce89de791  movaps xmm13, [rsp]
0000714ce89de796  add rsp, 0x30
0000714ce89de79a  vmovaps xmm0, [rsp]
0000714ce89de79f  vmovaps xmm1, [rsp+0x10]
0000714ce89de7a5  vmovaps xmm2, [rsp+0x20]
0000714ce89de7ab  vmovaps xmm3, [rsp+0x30]
0000714ce89de7b1  vmovaps xmm4, [rsp+0x40]
0000714ce89de7b7  vmovaps xmm5, [rsp+0x50]
0000714ce89de7bd  vmovaps xmm6, [rsp+0x60]
0000714ce89de7c3  vmovaps xmm7, [rsp+0x70]
0000714ce89de7c9  vmovaps xmm8, [rsp+0x80]
0000714ce89de7d2  vmovaps xmm9, [rsp+0x90]
0000714ce89de7db  vmovaps xmm10, [rsp+0xA0]
0000714ce89de7e4  vmovaps xmm11, [rsp+0xB0]
0000714ce89de7ed  vmovaps xmm12, [rsp+0xC0]
0000714ce89de7f6  vmovaps xmm14, [rsp+0xD0]
0000714ce89de7ff  vmovaps xmm15, [rsp+0xE0]
0000714ce89de808  add rsp, 0xF0
0000714ce89de80f  pop r11
0000714ce89de811  pop r10
0000714ce89de813  pop r9
0000714ce89de815  pop r8
0000714ce89de817  pop rsi
0000714ce89de818  pop rdi
0000714ce89de819  pop rdx
0000714ce89de81a  pop rcx
0000714ce89de81b  pop rax
0000714ce89de81c  add rsp, 0x08
0000714ce89de820  jmp 0x0000714CE89D984D
0000714ce89de825  sub rsp, 0x08
0000714ce89de829  push rax
0000714ce89de82a  push rcx
0000714ce89de82b  push rdx
0000714ce89de82c  push rdi
0000714ce89de82d  push rsi
0000714ce89de82e  push r8
0000714ce89de830  push r9
0000714ce89de832  push r10
0000714ce89de834  push r11
0000714ce89de836  sub rsp, 0xF0
0000714ce89de83d  vmovaps [rsp], xmm0
0000714ce89de842  vmovaps [rsp+0x10], xmm1
0000714ce89de848  vmovaps [rsp+0x20], xmm2
0000714ce89de84e  vmovaps [rsp+0x30], xmm3
0000714ce89de854  vmovaps [rsp+0x40], xmm4
0000714ce89de85a  vmovaps [rsp+0x50], xmm5
0000714ce89de860  vmovaps [rsp+0x60], xmm6
0000714ce89de866  vmovaps [rsp+0x70], xmm7
0000714ce89de86c  vmovaps [rsp+0x80], xmm8
0000714ce89de875  vmovaps [rsp+0x90], xmm9
0000714ce89de87e  vmovaps [rsp+0xA0], xmm10
0000714ce89de887  vmovaps [rsp+0xB0], xmm11
0000714ce89de890  vmovaps [rsp+0xC0], xmm12
0000714ce89de899  vmovaps [rsp+0xD0], xmm13
0000714ce89de8a2  vmovaps [rsp+0xE0], xmm15
0000714ce89de8ab  sub rsp, 0x30
0000714ce89de8af  movaps [rsp], xmm14
0000714ce89de8b4  movaps [rsp+0x10], xmm1
0000714ce89de8b9  movaps [rsp+0x20], xmm7
0000714ce89de8be  lea rdi, [rsp]
0000714ce89de8c2  mov esi, 0x00
0000714ce89de8c7  mov rax, 0x57A55D340530
0000714ce89de8d1  call rax
0000714ce89de8d3  movaps xmm14, [rsp]
0000714ce89de8d8  add rsp, 0x30
0000714ce89de8dc  vmovaps xmm0, [rsp]
0000714ce89de8e1  vmovaps xmm1, [rsp+0x10]
0000714ce89de8e7  vmovaps xmm2, [rsp+0x20]
0000714ce89de8ed  vmovaps xmm3, [rsp+0x30]
0000714ce89de8f3  vmovaps xmm4, [rsp+0x40]
0000714ce89de8f9  vmovaps xmm5, [rsp+0x50]
0000714ce89de8ff  vmovaps xmm6, [rsp+0x60]
0000714ce89de905  vmovaps xmm7, [rsp+0x70]
0000714ce89de90b  vmovaps xmm8, [rsp+0x80]
0000714ce89de914  vmovaps xmm9, [rsp+0x90]
0000714ce89de91d  vmovaps xmm10, [rsp+0xA0]
0000714ce89de926  vmovaps xmm11, [rsp+0xB0]
0000714ce89de92f  vmovaps xmm12, [rsp+0xC0]
0000714ce89de938  vmovaps xmm13, [rsp+0xD0]
0000714ce89de941  vmovaps xmm15, [rsp+0xE0]
0000714ce89de94a  add rsp, 0xF0
0000714ce89de951  pop r11
0000714ce89de953  pop r10
0000714ce89de955  pop r9
0000714ce89de957  pop r8
0000714ce89de959  pop rsi
0000714ce89de95a  pop rdi
0000714ce89de95b  pop rdx
0000714ce89de95c  pop rcx
0000714ce89de95d  pop rax
0000714ce89de95e  add rsp, 0x08
0000714ce89de962  jmp 0x0000714CE89D9870
0000714ce89de967  sub rsp, 0x08
0000714ce89de96b  push rax
0000714ce89de96c  push rcx
0000714ce89de96d  push rdx
0000714ce89de96e  push rdi
0000714ce89de96f  push rsi
0000714ce89de970  push r8
0000714ce89de972  push r9
0000714ce89de974  push r10
0000714ce89de976  push r11
0000714ce89de978  sub rsp, 0xF0
0000714ce89de97f  vmovaps [rsp], xmm0
0000714ce89de984  vmovaps [rsp+0x10], xmm2
0000714ce89de98a  vmovaps [rsp+0x20], xmm3
0000714ce89de990  vmovaps [rsp+0x30], xmm4
0000714ce89de996  vmovaps [rsp+0x40], xmm5
0000714ce89de99c  vmovaps [rsp+0x50], xmm6
0000714ce89de9a2  vmovaps [rsp+0x60], xmm7
0000714ce89de9a8  vmovaps [rsp+0x70], xmm8
0000714ce89de9ae  vmovaps [rsp+0x80], xmm9
0000714ce89de9b7  vmovaps [rsp+0x90], xmm10
0000714ce89de9c0  vmovaps [rsp+0xA0], xmm11
0000714ce89de9c9  vmovaps [rsp+0xB0], xmm12
0000714ce89de9d2  vmovaps [rsp+0xC0], xmm13
0000714ce89de9db  vmovaps [rsp+0xD0], xmm14
0000714ce89de9e4  vmovaps [rsp+0xE0], xmm15
0000714ce89de9ed  sub rsp, 0x30
0000714ce89de9f1  movaps [rsp], xmm1
0000714ce89de9f5  movaps [rsp+0x10], xmm8
0000714ce89de9fb  movaps [rsp+0x20], xmm9
0000714ce89dea01  lea rdi, [rsp]
0000714ce89dea05  mov esi, 0x00
0000714ce89dea0a  mov rax, 0x57A55D340530
0000714ce89dea14  call rax
0000714ce89dea16  movaps xmm1, [rsp]
0000714ce89dea1a  add rsp, 0x30
0000714ce89dea1e  vmovaps xmm0, [rsp]
0000714ce89dea23  vmovaps xmm2, [rsp+0x10]
0000714ce89dea29  vmovaps xmm3, [rsp+0x20]
0000714ce89dea2f  vmovaps xmm4, [rsp+0x30]
0000714ce89dea35  vmovaps xmm5, [rsp+0x40]
0000714ce89dea3b  vmovaps xmm6, [rsp+0x50]
0000714ce89dea41  vmovaps xmm7, [rsp+0x60]
0000714ce89dea47  vmovaps xmm8, [rsp+0x70]
0000714ce89dea4d  vmovaps xmm9, [rsp+0x80]
0000714ce89dea56  vmovaps xmm10, [rsp+0x90]
0000714ce89dea5f  vmovaps xmm11, [rsp+0xA0]
0000714ce89dea68  vmovaps xmm12, [rsp+0xB0]
0000714ce89dea71  vmovaps xmm13, [rsp+0xC0]
0000714ce89dea7a  vmovaps xmm14, [rsp+0xD0]
0000714ce89dea83  vmovaps xmm15, [rsp+0xE0]
0000714ce89dea8c  add rsp, 0xF0
0000714ce89dea93  pop r11
0000714ce89dea95  pop r10
0000714ce89dea97  pop r9
0000714ce89dea99  pop r8
0000714ce89dea9b  pop rsi
0000714ce89dea9c  pop rdi
0000714ce89dea9d  pop rdx
0000714ce89dea9e  pop rcx
0000714ce89dea9f  pop rax
0000714ce89deaa0  add rsp, 0x08
0000714ce89deaa4  jmp 0x0000714CE89D9892
0000714ce89deaa9  call 0x0000714CE88B3E40
0000714ce89deaae  jmp 0x0000714CE89D98A0
0000714ce89deab3  call 0x0000714CE880C380
0000714ce89deab8  jmp 0x0000714CE89D98AA
0000714ce89deabd  call 0x0000714CE880D600
0000714ce89deac2  jmp 0x0000714CE89D98B4
0000714ce89deac7  call 0x0000714CE87FF540
0000714ce89deacc  jmp 0x0000714CE89D98BE
0000714ce89dead1  int3
0000714ce89dead2  nop [rax+rax*1], ax
0000714ce89deadb  nop [rax+rax*1], eax
0000714ce89deae0  mov eax, [r15+0x48]
0000714ce89deae4  lea r14d, [eax+0x01]
0000714ce89deae9  mov [rsp+0x10], r14d
0000714ce89deaee  mov r14d, r14d
0000714ce89deaf1  mov [r15+0x48], r14
0000714ce89deaf5  xor eax, eax
0000714ce89deaf7  mov r14d, [rsp+0x10]
0000714ce89deafc  cmp r14d, 0x1F4
0000714ce89deb03  cmc
0000714ce89deb04  lahf
0000714ce89deb05  seto al
0000714ce89deb08  mov [r15+0x108], eax
0000714ce89deb0f  mov eax, [r15+0x108]
0000714ce89deb16  sahf
0000714ce89deb17  jnz 0x0000714CE89DEB49
0000714ce89deb19  cmp dword ptr [r15+0x318], 0x00
0000714ce89deb21  jz 0x0000714CE89E4C90
0000714ce89deb27  nop [rax+rax*1], ax
0000714ce89deb30  nop [rax+rax*1], eax
0000714ce89deb38  mov eax, 0x4106DC
0000714ce89deb3d  mov [r15+0x100], rax
0000714ce89deb44  jmp 0x0000714CE87FE110
0000714ce89deb49  cmp dword ptr [r15+0x318], 0x00
0000714ce89deb51  jz 0x0000714CE89DEB80
0000714ce89deb57  nop [rax+rax*1], ax
0000714ce89deb60  nop [rax+rax*1], eax
0000714ce89deb68  mov eax, 0x410500
0000714ce89deb6d  mov [r15+0x100], rax
0000714ce89deb74  jmp 0x0000714CE87FE110
0000714ce89deb79  int3
0000714ce89deb7a  int3
0000714ce89deb7b  nop [rax+rax*1], eax
0000714ce89deb80  mov rax, [r15+0x40]
0000714ce89deb84  movaps xmm1, [r15+0x1D0]
0000714ce89deb8c  vmovaps [rsp+0x10], xmm1
0000714ce89deb92  vmovaps xmm15, [rsp+0x10]
0000714ce89deb98  por xmm1, xmm15
0000714ce89deb9d  movaps xmm14, [r15+0x1A0]
0000714ce89deba5  vmovaps [rsp+0x10], xmm14
0000714ce89debab  vmovaps xmm13, [rsp+0x10]
0000714ce89debb1  por xmm14, xmm13
0000714ce89debb6  lea r14, [rax+0x30]
0000714ce89debba  mov r12, [r13+r14*1]
0000714ce89debbf  lea r14, [rax+0x38]
0000714ce89debc3  mov r11, [r13+r14*1]
0000714ce89debc8  movq xmm13, r12
0000714ce89debcd  movq xmm12, r11
0000714ce89debd2  movq xmm13, xmm13
0000714ce89debd7  vmovaps [rsp+0x10], xmm13
0000714ce89debdd  movq xmm13, xmm13
0000714ce89debe2  movaps [r15+0x130], xmm13
0000714ce89debea  movq xmm12, xmm12
0000714ce89debef  vmovaps [rsp+0x20], xmm12
0000714ce89debf5  movq xmm12, xmm12
0000714ce89debfa  movaps [r15+0x280], xmm12
0000714ce89dec02  movaps xmm13, [r15+0x270]
0000714ce89dec0a  vmovaps [rsp+0x30], xmm13
0000714ce89dec10  vmovaps xmm12, [rsp+0x30]
0000714ce89dec16  por xmm13, xmm12
0000714ce89dec1b  lea r14, [rax+0x20]
0000714ce89dec1f  mov r12, [r13+r14*1]
0000714ce89dec24  lea r14, [rax+0x28]
0000714ce89dec28  mov r11, [r13+r14*1]
0000714ce89dec2d  movq xmm12, r12
0000714ce89dec32  movq xmm11, r11
0000714ce89dec37  movq xmm12, xmm12
0000714ce89dec3c  vmovaps [rsp+0x30], xmm12
0000714ce89dec42  movq xmm12, xmm12
0000714ce89dec47  movaps [r15+0x150], xmm12
0000714ce89dec4f  movq xmm11, xmm11
0000714ce89dec54  vmovaps [rsp+0x40], xmm11
0000714ce89dec5a  movq xmm11, xmm11
0000714ce89dec5f  movaps [r15+0x140], xmm11
0000714ce89dec67  lea r14, [rax+0x10]
0000714ce89dec6b  mov r12, [r13+r14*1]
0000714ce89dec70  lea r14, [rax+0x18]
0000714ce89dec74  mov r11, [r13+r14*1]
0000714ce89dec79  movq xmm12, r12
0000714ce89dec7e  movq xmm11, r11
0000714ce89dec83  movq xmm12, xmm12
0000714ce89dec88  vmovaps [rsp+0x50], xmm12
0000714ce89dec8e  movq xmm12, xmm12
0000714ce89dec93  movaps [r15+0x170], xmm12
0000714ce89dec9b  movq xmm11, xmm11
0000714ce89deca0  vmovaps [rsp+0x60], xmm11
0000714ce89deca6  movq xmm11, xmm11
0000714ce89decab  movaps [r15+0x160], xmm11
0000714ce89decb3  mov r14, [r13+rax*1]
0000714ce89decb8  vmovq xmm12, r14
0000714ce89decbd  vpbroadcastq xmm12, xmm12
0000714ce89decc2  lea r14, [rax+0x08]
0000714ce89decc6  mov rax, [r13+r14*1]
0000714ce89deccb  movq xmm11, rax
0000714ce89decd0  movaps [r15+0x230], xmm11
0000714ce89decd8  mov rax, [r15+0xF8]
0000714ce89decdf  lea r14, [rax+0x50]
0000714ce89dece3  movups xmm11, [r13+r14*1]
0000714ce89dece9  lea r14, [rax+0x60]
0000714ce89deced  movups xmm10, [r13+r14*1]
0000714ce89decf3  lea r14, [rax+0x30]
0000714ce89decf7  movups xmm9, [r13+r14*1]
0000714ce89decfd  mov r14, [r15+0x50]
0000714ce89ded01  mov [r15+0x60], r14
0000714ce89ded05  mov qword ptr [r15+0x58], 0x40
0000714ce89ded0d  movaps xmm8, xmm12
0000714ce89ded11  mulpd xmm8, xmm15
0000714ce89ded16  vcmppd xmm7, xmm8, xmm8, 0x03
0000714ce89ded1c  ptest xmm7, xmm7
0000714ce89ded21  jnz 0x0000714CE89DFB4A
0000714ce89ded27  movq xmm15, qword ptr [r15+0x230]
0000714ce89ded30  vmovaps [rsp+0x70], xmm15
0000714ce89ded36  vpermilpd xmm15, xmm15, 0x00
0000714ce89ded3c  movaps xmm7, xmm9
0000714ce89ded40  mulpd xmm7, xmm15
0000714ce89ded45  vcmppd xmm6, xmm7, xmm7, 0x03
0000714ce89ded4a  ptest xmm6, xmm6
0000714ce89ded4f  jnz 0x0000714CE89DFC8E
0000714ce89ded55  vxorps xmm15, xmm15, xmm15
0000714ce89ded5a  vpbroadcastq xmm15, xmm15
0000714ce89ded5f  movaps xmm9, xmm12
0000714ce89ded63  mulpd xmm9, xmm10
0000714ce89ded68  vcmppd xmm6, xmm9, xmm9, 0x03
0000714ce89ded6e  ptest xmm6, xmm6
0000714ce89ded73  jnz 0x0000714CE89DFDD0
0000714ce89ded79  movaps xmm10, xmm12
0000714ce89ded7d  mulpd xmm10, xmm11
0000714ce89ded82  vcmppd xmm6, xmm10, xmm10, 0x03
0000714ce89ded88  ptest xmm6, xmm6
0000714ce89ded8d  jnz 0x0000714CE89DFF14
0000714ce89ded93  movaps xmm11, [r15+0x1F0]
0000714ce89ded9b  movaps xmm6, xmm12
0000714ce89ded9f  mulpd xmm6, xmm11
0000714ce89deda4  vcmppd xmm5, xmm6, xmm6, 0x03
0000714ce89deda9  ptest xmm5, xmm5
0000714ce89dedae  jnz 0x0000714CE89E0058
0000714ce89dedb4  movaps xmm12, [r15+0x2A0]
0000714ce89dedbc  vmovaps [rsp+0x80], xmm12
0000714ce89dedc5  vmovaps xmm11, [rsp+0x80]
0000714ce89dedce  por xmm12, xmm11
0000714ce89dedd3  movaps xmm11, [r15+0x250]
0000714ce89deddb  vmovaps [rsp+0x80], xmm11
0000714ce89dede4  vmovaps xmm5, [rsp+0x80]
0000714ce89deded  por xmm11, xmm5
0000714ce89dedf2  vmovaps xmm4, [rsp+0x70]
0000714ce89dedf8  vpermilpd xmm4, xmm4, 0x00
0000714ce89dedfe  movaps xmm3, xmm5
0000714ce89dee01  mulpd xmm3, xmm4
0000714ce89dee05  vcmppd xmm2, xmm3, xmm3, 0x03
0000714ce89dee0a  ptest xmm2, xmm2
0000714ce89dee0f  jnz 0x0000714CE89E019A
0000714ce89dee15  mov [rsp+0x80], rax
0000714ce89dee1d  xor eax, eax
0000714ce89dee1f  mov r12d, 0x40
0000714ce89dee25  mov r11d, 0x200
0000714ce89dee2b  cmp r12, r11
0000714ce89dee2e  cmc
0000714ce89dee2f  lahf
0000714ce89dee30  seto al
0000714ce89dee33  mov [r15+0x108], eax
0000714ce89dee3a  movaps xmm5, xmm8
0000714ce89dee3e  addpd xmm5, xmm15
0000714ce89dee43  vcmppd xmm4, xmm5, xmm5, 0x03
0000714ce89dee48  ptest xmm4, xmm4
0000714ce89dee4d  jnz 0x0000714CE89E02DA
0000714ce89dee53  movaps xmm8, [r15+0x1B0]
0000714ce89dee5b  movaps xmm4, xmm9
0000714ce89dee5f  addpd xmm4, xmm8
0000714ce89dee64  vcmppd xmm2, xmm4, xmm4, 0x03
0000714ce89dee69  ptest xmm2, xmm2
0000714ce89dee6e  jnz 0x0000714CE89E041C
0000714ce89dee74  movaps xmm9, xmm10
0000714ce89dee78  addpd xmm9, xmm8
0000714ce89dee7d  vcmppd xmm2, xmm9, xmm9, 0x03
0000714ce89dee83  ptest xmm2, xmm2
0000714ce89dee88  jnz 0x0000714CE89E055E
0000714ce89dee8e  movaps xmm10, [r15+0x2F0]
0000714ce89dee96  vmovaps [rsp+0x90], xmm10
0000714ce89dee9f  vmovaps xmm8, [rsp+0x90]
0000714ce89deea8  por xmm10, xmm8
0000714ce89deead  movaps xmm8, [r15+0x2E0]
0000714ce89deeb5  vmovaps [rsp+0x90], xmm8
0000714ce89deebe  vmovaps xmm2, [rsp+0x90]
0000714ce89deec7  por xmm8, xmm2
0000714ce89deecc  movaps xmm2, [r15+0x2D0]
0000714ce89deed4  vmovaps [rsp+0x90], xmm2
0000714ce89deedd  vmovaps [rsp+0xA0], xmm1
0000714ce89deee6  vmovaps xmm1, [rsp+0x90]
0000714ce89deeef  por xmm2, xmm1
0000714ce89deef3  movaps xmm1, [r15+0x200]
0000714ce89deefb  vmovaps [rsp+0x90], xmm1
0000714ce89def04  vmovaps [rsp+0xB0], xmm15
0000714ce89def0d  vmovaps xmm15, [rsp+0x90]
0000714ce89def16  por xmm1, xmm15
0000714ce89def1b  movaps xmm15, [r15+0x1C0]
0000714ce89def23  vmovaps [rsp+0x90], xmm15
0000714ce89def2c  vmovaps [rsp+0xC0], xmm1
0000714ce89def35  vmovaps xmm1, [rsp+0x90]
0000714ce89def3e  por xmm15, xmm1
0000714ce89def43  movaps xmm1, [r15+0x190]
0000714ce89def4b  vmovaps [rsp+0x90], xmm1
0000714ce89def54  vmovaps [rsp+0xD0], xmm15
0000714ce89def5d  vmovaps xmm15, [rsp+0x90]
0000714ce89def66  por xmm1, xmm15
0000714ce89def6b  movaps xmm15, [r15+0x300]
0000714ce89def73  vmovaps [rsp+0x90], xmm15
0000714ce89def7c  vmovaps [rsp+0xE0], xmm1
0000714ce89def85  vmovaps xmm1, [rsp+0x90]
0000714ce89def8e  por xmm15, xmm1
0000714ce89def93  mov rax, [rsp+0x80]
0000714ce89def9b  lea r12, [rax+0xA0]
0000714ce89defa2  movups xmm1, [r13+r12*1]
0000714ce89defa8  lea r12, [rax+0xB0]
0000714ce89defaf  vmovaps [rsp+0x80], xmm1
0000714ce89defb8  movups xmm1, [r13+r12*1]
0000714ce89defbe  vmovaps [rsp+0x90], xmm1
0000714ce89defc7  vmovaps [rsp+0xF0], xmm15
0000714ce89defd0  vmovaps xmm15, [rsp+0xB0]
0000714ce89defd9  vmovaps [rsp+0xB0], xmm14
0000714ce89defe2  movaps xmm1, xmm6
0000714ce89defe5  addpd xmm1, xmm15
0000714ce89defea  vcmppd xmm14, xmm1, xmm1, 0x03
0000714ce89defef  ptest xmm14, xmm14
0000714ce89deff5  jnz 0x0000714CE89E06B6
0000714ce89deffb  lea r12, [rax+0xF0]
0000714ce89df002  movups xmm15, [r13+r12*1]
0000714ce89df008  movaps xmm14, xmm4
0000714ce89df00c  addpd xmm14, xmm3
0000714ce89df011  vcmppd xmm6, xmm14, xmm14, 0x03
0000714ce89df017  ptest xmm6, xmm6
0000714ce89df01c  jnz 0x0000714CE89E0801
0000714ce89df022  movaps xmm6, xmm9
0000714ce89df026  addpd xmm6, xmm7
0000714ce89df02a  vcmppd xmm4, xmm6, xmm6, 0x03
0000714ce89df02f  ptest xmm4, xmm4
0000714ce89df034  jnz 0x0000714CE89E0943
0000714ce89df03a  vmovaps xmm9, [rsp+0x70]
0000714ce89df040  vpermilpd xmm9, xmm9, 0x00
0000714ce89df046  vmovaps xmm4, [rsp+0x90]
0000714ce89df04f  movaps xmm7, xmm4
0000714ce89df052  mulpd xmm7, xmm9
0000714ce89df057  vcmppd xmm3, xmm7, xmm7, 0x03
0000714ce89df05c  ptest xmm3, xmm3
0000714ce89df061  jnz 0x0000714CE89E0A84
0000714ce89df067  vmovaps xmm9, [rsp+0x50]
0000714ce89df06d  vpermilpd xmm9, xmm9, 0x00
0000714ce89df073  movaps xmm4, xmm15
0000714ce89df077  mulpd xmm4, xmm9
0000714ce89df07c  vcmppd xmm3, xmm4, xmm4, 0x03
0000714ce89df081  ptest xmm3, xmm3
0000714ce89df086  jnz 0x0000714CE89E0BC5
0000714ce89df08c  lea r12, [rax+0xE0]
0000714ce89df093  movups xmm15, [r13+r12*1]
0000714ce89df099  vmovaps xmm9, [rsp+0x70]
0000714ce89df09f  vpermilpd xmm9, xmm9, 0x00
0000714ce89df0a5  vmovaps [rsp+0x70], xmm1
0000714ce89df0ab  vmovaps xmm1, [rsp+0x80]
0000714ce89df0b4  vmovaps [rsp+0x80], xmm15
0000714ce89df0bd  movaps xmm3, xmm1
0000714ce89df0c0  mulpd xmm3, xmm9
0000714ce89df0c5  vcmppd xmm15, xmm3, xmm3, 0x03
0000714ce89df0ca  ptest xmm15, xmm15
0000714ce89df0d0  jnz 0x0000714CE89E0D11
0000714ce89df0d6  vmovaps xmm1, [rsp+0xF0]
0000714ce89df0df  vmovaps xmm15, [rsp+0xF0]
0000714ce89df0e8  por xmm1, xmm15
0000714ce89df0ed  movaps [r15+0x300], xmm1
0000714ce89df0f5  vmovaps xmm15, [rsp+0xE0]
0000714ce89df0fe  vmovaps xmm9, [rsp+0xE0]
0000714ce89df107  por xmm15, xmm9
0000714ce89df10c  movaps [r15+0x190], xmm15
0000714ce89df114  vmovaps xmm9, [rsp+0x50]
0000714ce89df11a  vpermilpd xmm9, xmm9, 0x00
0000714ce89df120  vmovaps [rsp+0x90], xmm1
0000714ce89df129  vmovaps [rsp+0xE0], xmm15
0000714ce89df132  vmovaps xmm15, [rsp+0x80]
0000714ce89df13b  vmovaps [rsp+0x80], xmm14
0000714ce89df144  movaps xmm1, xmm15
0000714ce89df148  mulpd xmm1, xmm9
0000714ce89df14d  vcmppd xmm14, xmm1, xmm1, 0x03
0000714ce89df152  ptest xmm14, xmm14
0000714ce89df158  jnz 0x0000714CE89E0E52
0000714ce89df15e  lea r12, [rax+0x90]
0000714ce89df165  movups xmm15, [r13+r12*1]
0000714ce89df16b  vmovaps xmm14, [rsp+0xD0]
0000714ce89df174  vmovaps xmm9, [rsp+0xD0]
0000714ce89df17d  por xmm14, xmm9
0000714ce89df182  movaps [r15+0x1C0], xmm14
0000714ce89df18a  vmovaps xmm9, [rsp+0xC0]
0000714ce89df193  vmovaps [rsp+0xD0], xmm1
0000714ce89df19c  vmovaps xmm1, [rsp+0xC0]
0000714ce89df1a5  por xmm9, xmm1
0000714ce89df1aa  movaps [r15+0x200], xmm9
0000714ce89df1b2  vmovaps [rsp+0xC0], xmm2
0000714ce89df1bb  vmovaps xmm1, [rsp+0xC0]
0000714ce89df1c4  por xmm2, xmm1
0000714ce89df1c8  movaps [r15+0x2D0], xmm2
0000714ce89df1d0  vmovaps [rsp+0xC0], xmm8
0000714ce89df1d9  vmovaps xmm1, [rsp+0xC0]
0000714ce89df1e2  por xmm8, xmm1
0000714ce89df1e7  movaps [r15+0x2E0], xmm8
0000714ce89df1ef  vmovaps [rsp+0xC0], xmm15
0000714ce89df1f8  movaps xmm1, xmm5
0000714ce89df1fb  addpd xmm1, xmm7
0000714ce89df1ff  vcmppd xmm15, xmm1, xmm1, 0x03
0000714ce89df204  ptest xmm15, xmm15
0000714ce89df20a  jnz 0x0000714CE89E0F9E
0000714ce89df210  vmovaps xmm15, [rsp+0x50]
0000714ce89df216  vpermilpd xmm15, xmm15, 0x00
0000714ce89df21c  vmovaps xmm5, [rsp+0xC0]
0000714ce89df225  vmovaps [rsp+0xC0], xmm1
0000714ce89df22e  movaps xmm7, xmm5
0000714ce89df231  mulpd xmm7, xmm15
0000714ce89df236  vcmppd xmm1, xmm7, xmm7, 0x03
0000714ce89df23b  ptest xmm1, xmm1
0000714ce89df240  jnz 0x0000714CE89E10DE
0000714ce89df246  lea r12, [rax+0x80]
0000714ce89df24d  movups xmm1, [r13+r12*1]
0000714ce89df253  vmovaps xmm5, [rsp+0x70]
0000714ce89df259  vmovaps [rsp+0x70], xmm1
0000714ce89df25f  movaps xmm15, xmm5
0000714ce89df263  addpd xmm15, xmm3
0000714ce89df268  vcmppd xmm1, xmm15, xmm15, 0x03
0000714ce89df26e  ptest xmm1, xmm1
0000714ce89df273  jnz 0x0000714CE89E1229
0000714ce89df279  vmovaps xmm5, [rsp+0x80]
0000714ce89df282  movaps xmm1, xmm5
0000714ce89df285  addpd xmm1, xmm4
0000714ce89df289  vcmppd xmm3, xmm1, xmm1, 0x03
0000714ce89df28e  ptest xmm3, xmm3
0000714ce89df293  jnz 0x0000714CE89E136B
0000714ce89df299  vmovaps [rsp+0x80], xmm10
0000714ce89df2a2  vmovaps xmm5, [rsp+0x80]
0000714ce89df2ab  por xmm10, xmm5
0000714ce89df2b0  movaps [r15+0x2F0], xmm10
0000714ce89df2b8  vmovaps xmm5, [rsp+0x50]
0000714ce89df2be  vpermilpd xmm5, xmm5, 0x00
0000714ce89df2c4  vmovaps xmm3, [rsp+0x70]
0000714ce89df2ca  vmovaps [rsp+0x50], xmm1
0000714ce89df2d0  movaps xmm4, xmm3
0000714ce89df2d3  mulpd xmm4, xmm5
0000714ce89df2d7  vcmppd xmm1, xmm4, xmm4, 0x03
0000714ce89df2dc  ptest xmm1, xmm1
0000714ce89df2e1  jnz 0x0000714CE89E14AB
0000714ce89df2e7  lea r12, [rax+0xD0]
0000714ce89df2ee  movups xmm1, [r13+r12*1]
0000714ce89df2f4  vmovaps xmm3, [rsp+0xD0]
0000714ce89df2fd  vmovaps [rsp+0x70], xmm1
0000714ce89df303  movaps xmm5, xmm6
0000714ce89df306  addpd xmm5, xmm3
0000714ce89df30a  vcmppd xmm1, xmm5, xmm5, 0x03
0000714ce89df30f  ptest xmm1, xmm1
0000714ce89df314  jnz 0x0000714CE89E15F5
0000714ce89df31a  vmovaps xmm1, [rsp+0x60]
0000714ce89df320  vpermilpd xmm1, xmm1, 0x00
0000714ce89df326  movaps xmm6, xmm9
0000714ce89df32a  mulpd xmm6, xmm1
0000714ce89df32e  vcmppd xmm3, xmm6, xmm6, 0x03
0000714ce89df333  ptest xmm3, xmm3
0000714ce89df338  jnz 0x0000714CE89E1735
0000714ce89df33e  movaps [r15+0x260], xmm6
0000714ce89df346  vxorps xmm1, xmm1, xmm1
0000714ce89df34a  vpbroadcastq xmm1, xmm1
0000714ce89df34f  movaps [r15+0x1B0], xmm1
0000714ce89df357  vmovaps xmm1, [rsp+0x60]
0000714ce89df35d  vpermilpd xmm1, xmm1, 0x00
0000714ce89df363  vmovaps xmm3, [rsp+0x70]
0000714ce89df369  vmovaps [rsp+0x70], xmm15
0000714ce89df36f  movaps xmm9, xmm3
0000714ce89df373  mulpd xmm9, xmm1
0000714ce89df378  vcmppd xmm15, xmm9, xmm9, 0x03
0000714ce89df37e  ptest xmm15, xmm15
0000714ce89df384  jnz 0x0000714CE89E1876
0000714ce89df38a  lea r12, [rax+0xC0]
0000714ce89df391  movups xmm1, [r13+r12*1]
0000714ce89df397  vmovaps xmm3, [rsp+0xC0]
0000714ce89df3a0  vmovaps [rsp+0x80], xmm1
0000714ce89df3a9  movaps xmm15, xmm3
0000714ce89df3ad  addpd xmm15, xmm7
0000714ce89df3b2  vcmppd xmm1, xmm15, xmm15, 0x03
0000714ce89df3b8  ptest xmm1, xmm1
0000714ce89df3bd  jnz 0x0000714CE89E19C2
0000714ce89df3c3  vmovaps [rsp+0xC0], xmm13
0000714ce89df3cc  vmovaps xmm1, [rsp+0xC0]
0000714ce89df3d5  por xmm13, xmm1
0000714ce89df3da  movaps [r15+0x270], xmm13
0000714ce89df3e2  vmovaps xmm1, [rsp+0xB0]
0000714ce89df3eb  vmovaps xmm7, [rsp+0xB0]
0000714ce89df3f4  por xmm1, xmm7
0000714ce89df3f8  movaps [r15+0x1A0], xmm1
0000714ce89df400  vmovaps xmm1, [rsp+0x60]
0000714ce89df406  vpermilpd xmm1, xmm1, 0x00
0000714ce89df40c  vmovaps [rsp+0xB0], xmm1
0000714ce89df415  vmovaps xmm1, [rsp+0x80]
0000714ce89df41e  vmovaps [rsp+0x80], xmm15
0000714ce89df427  vmovaps xmm15, [rsp+0xB0]
0000714ce89df430  vmovaps [rsp+0xB0], xmm14
0000714ce89df439  movaps xmm3, xmm1
0000714ce89df43c  mulpd xmm3, xmm15
0000714ce89df441  vcmppd xmm14, xmm3, xmm3, 0x03
0000714ce89df446  ptest xmm14, xmm14
0000714ce89df44c  jnz 0x0000714CE89E1B04
0000714ce89df452  lea r12, [rax+0x20]
0000714ce89df456  movups xmm1, [r13+r12*1]
0000714ce89df45c  movaps [r15+0x110], xmm1
0000714ce89df464  vmovaps xmm14, [rsp+0x70]
0000714ce89df46a  vmovaps [rsp+0x70], xmm1
0000714ce89df470  movaps xmm15, xmm14
0000714ce89df474  addpd xmm15, xmm4
0000714ce89df479  vcmppd xmm1, xmm15, xmm15, 0x03
0000714ce89df47f  ptest xmm1, xmm1
0000714ce89df484  jnz 0x0000714CE89E1C4F
0000714ce89df48a  vmovaps xmm1, [rsp+0x60]
0000714ce89df490  vpermilpd xmm1, xmm1, 0x00
0000714ce89df496  movaps xmm14, xmm2
0000714ce89df49a  mulpd xmm14, xmm1
0000714ce89df49f  vcmppd xmm4, xmm14, xmm14, 0x03
0000714ce89df4a5  ptest xmm4, xmm4
0000714ce89df4aa  jnz 0x0000714CE89E1D92
0000714ce89df4b0  vmovaps xmm4, [rsp+0x50]
0000714ce89df4b6  movaps xmm1, xmm4
0000714ce89df4b9  addpd xmm1, xmm9
0000714ce89df4be  vcmppd xmm2, xmm1, xmm1, 0x03
0000714ce89df4c3  ptest xmm2, xmm2
0000714ce89df4c8  jnz 0x0000714CE89E1ED4
0000714ce89df4ce  vmovaps xmm9, [rsp+0x30]
0000714ce89df4d4  vpermilpd xmm9, xmm9, 0x00
0000714ce89df4da  vmovaps xmm2, [rsp+0x70]
0000714ce89df4e0  vmovaps [rsp+0x50], xmm1
0000714ce89df4e6  movaps xmm4, xmm2
0000714ce89df4e9  mulpd xmm4, xmm9
0000714ce89df4ee  vcmppd xmm1, xmm4, xmm4, 0x03
0000714ce89df4f3  ptest xmm1, xmm1
0000714ce89df4f8  jnz 0x0000714CE89E2015
0000714ce89df4fe  vmovaps xmm1, [rsp+0x30]
0000714ce89df504  vpermilpd xmm1, xmm1, 0x00
0000714ce89df50a  vmovaps xmm2, [rsp+0x90]
0000714ce89df513  vmovaps [rsp+0x60], xmm15
0000714ce89df519  movaps xmm9, xmm2
0000714ce89df51d  mulpd xmm9, xmm1
0000714ce89df522  vcmppd xmm15, xmm9, xmm9, 0x03
0000714ce89df528  ptest xmm15, xmm15
0000714ce89df52e  jnz 0x0000714CE89E2156
0000714ce89df534  vmovaps xmm15, [rsp+0x80]
0000714ce89df53d  movaps xmm1, xmm15
0000714ce89df541  addpd xmm1, xmm6
0000714ce89df545  vcmppd xmm2, xmm1, xmm1, 0x03
0000714ce89df54a  ptest xmm2, xmm2
0000714ce89df54f  jnz 0x0000714CE89E2298
0000714ce89df555  movaps xmm15, xmm5
0000714ce89df559  addpd xmm15, xmm3
0000714ce89df55e  vcmppd xmm6, xmm15, xmm15, 0x03
0000714ce89df564  ptest xmm6, xmm6
0000714ce89df569  jnz 0x0000714CE89E23D9
0000714ce89df56f  vmovaps xmm6, [rsp+0x30]
0000714ce89df575  vpermilpd xmm6, xmm6, 0x00
0000714ce89df57b  movaps xmm5, xmm8
0000714ce89df57f  mulpd xmm5, xmm6
0000714ce89df583  vcmppd xmm3, xmm5, xmm5, 0x03
0000714ce89df588  ptest xmm3, xmm3
0000714ce89df58d  jnz 0x0000714CE89E251B
0000714ce89df593  vmovaps xmm8, [rsp+0x30]
0000714ce89df599  vpermilpd xmm8, xmm8, 0x00
0000714ce89df59f  movaps xmm6, xmm10
0000714ce89df5a3  mulpd xmm6, xmm8
0000714ce89df5a8  vcmppd xmm3, xmm6, xmm6, 0x03
0000714ce89df5ad  ptest xmm3, xmm3
0000714ce89df5b2  jnz 0x0000714CE89E265C
0000714ce89df5b8  vmovaps xmm8, [rsp+0x60]
0000714ce89df5be  movaps xmm10, xmm8
0000714ce89df5c2  addpd xmm10, xmm14
0000714ce89df5c7  vcmppd xmm3, xmm10, xmm10, 0x03
0000714ce89df5cd  ptest xmm3, xmm3
0000714ce89df5d2  jnz 0x0000714CE89E279E
0000714ce89df5d8  vmovaps xmm8, [rsp+0x50]
0000714ce89df5de  movaps xmm14, xmm8
0000714ce89df5e2  addpd xmm14, xmm4
0000714ce89df5e7  vcmppd xmm3, xmm14, xmm14, 0x03
0000714ce89df5ed  ptest xmm3, xmm3
0000714ce89df5f2  jnz 0x0000714CE89E28E2
0000714ce89df5f8  vmovaps xmm8, [rsp+0x40]
0000714ce89df5fe  vpermilpd xmm8, xmm8, 0x00
0000714ce89df604  movaps xmm4, xmm13
0000714ce89df608  mulpd xmm4, xmm8
0000714ce89df60d  vcmppd xmm3, xmm4, xmm4, 0x03
0000714ce89df612  ptest xmm3, xmm3
0000714ce89df617  jnz 0x0000714CE89E2A25
0000714ce89df61d  movaps xmm13, xmm15
0000714ce89df621  addpd xmm13, xmm9
0000714ce89df626  vcmppd xmm8, xmm13, xmm13, 0x03
0000714ce89df62c  ptest xmm8, xmm8
0000714ce89df632  jnz 0x0000714CE89E2B67
0000714ce89df638  movaps xmm15, xmm1
0000714ce89df63c  addpd xmm15, xmm5
0000714ce89df641  vcmppd xmm9, xmm15, xmm15, 0x03
0000714ce89df647  ptest xmm9, xmm9
0000714ce89df64d  jnz 0x0000714CE89E2CAB
0000714ce89df653  vmovaps [rsp+0x30], xmm11
0000714ce89df659  vmovaps xmm1, [rsp+0x30]
0000714ce89df65f  por xmm11, xmm1
0000714ce89df664  movaps [r15+0x250], xmm11
0000714ce89df66c  vmovaps [rsp+0x30], xmm12
0000714ce89df672  vmovaps xmm1, [rsp+0x30]
0000714ce89df678  por xmm12, xmm1
0000714ce89df67d  movaps [r15+0x2A0], xmm12
0000714ce89df685  vmovaps xmm1, [rsp+0xA0]
0000714ce89df68e  vmovaps xmm11, [rsp+0xA0]
0000714ce89df697  por xmm1, xmm11
0000714ce89df69c  movaps [r15+0x1D0], xmm1
0000714ce89df6a4  lea r12, [rax+0x40]
0000714ce89df6a8  movups xmm1, [r13+r12*1]
0000714ce89df6ae  movaps [r15+0x2C0], xmm1
0000714ce89df6b6  vmovaps xmm11, [rsp+0x40]
0000714ce89df6bc  vpermilpd xmm11, xmm11, 0x00
0000714ce89df6c2  vmovaps xmm8, [rsp+0xE0]
0000714ce89df6cb  movaps xmm9, xmm8
0000714ce89df6cf  mulpd xmm9, xmm11
0000714ce89df6d4  vcmppd xmm5, xmm9, xmm9, 0x03
0000714ce89df6da  ptest xmm5, xmm5
0000714ce89df6df  jnz 0x0000714CE89E2DF7
0000714ce89df6e5  movaps xmm11, xmm10
0000714ce89df6e9  addpd xmm11, xmm6
0000714ce89df6ee  vcmppd xmm8, xmm11, xmm11, 0x03
0000714ce89df6f4  ptest xmm8, xmm8
0000714ce89df6fa  jnz 0x0000714CE89E2F3B
0000714ce89df700  movaps xmm10, xmm14
0000714ce89df704  addpd xmm10, xmm4
0000714ce89df709  vcmppd xmm8, xmm10, xmm10, 0x03
0000714ce89df70f  ptest xmm8, xmm8
0000714ce89df715  jnz 0x0000714CE89E307E
0000714ce89df71b  vmovaps xmm14, [rsp+0x40]
0000714ce89df721  vpermilpd xmm14, xmm14, 0x00
0000714ce89df727  movaps xmm8, xmm1
0000714ce89df72b  mulpd xmm8, xmm14
0000714ce89df730  vcmppd xmm6, xmm8, xmm8, 0x03
0000714ce89df736  ptest xmm6, xmm6
0000714ce89df73b  jnz 0x0000714CE89E31C1
0000714ce89df741  movaps xmm1, [r15+0x2B0]
0000714ce89df749  vmovaps xmm14, [rsp+0x40]
0000714ce89df74f  vpermilpd xmm14, xmm14, 0x00
0000714ce89df755  movaps xmm6, xmm1
0000714ce89df758  mulpd xmm6, xmm14
0000714ce89df75d  vcmppd xmm5, xmm6, xmm6, 0x03
0000714ce89df762  ptest xmm5, xmm5
0000714ce89df767  jnz 0x0000714CE89E3304
0000714ce89df76d  vmovaps xmm1, [rsp+0x10]
0000714ce89df773  vpermilpd xmm1, xmm1, 0x00
0000714ce89df779  movaps xmm14, xmm12
0000714ce89df77d  mulpd xmm14, xmm1
0000714ce89df782  vcmppd xmm5, xmm14, xmm14, 0x03
0000714ce89df788  ptest xmm5, xmm5
0000714ce89df78d  jnz 0x0000714CE89E3445
0000714ce89df793  movaps xmm1, xmm13
0000714ce89df797  addpd xmm1, xmm9
0000714ce89df79c  vcmppd xmm12, xmm1, xmm1, 0x03
0000714ce89df7a1  ptest xmm12, xmm12
0000714ce89df7a7  jnz 0x0000714CE89E3588
0000714ce89df7ad  vmovaps xmm13, [rsp+0x10]
0000714ce89df7b3  vpermilpd xmm13, xmm13, 0x00
0000714ce89df7b9  movaps xmm12, xmm7
0000714ce89df7bd  mulpd xmm12, xmm13
0000714ce89df7c2  vcmppd xmm9, xmm12, xmm12, 0x03
0000714ce89df7c8  ptest xmm9, xmm9
0000714ce89df7ce  jnz 0x0000714CE89E36CA
0000714ce89df7d4  movaps xmm13, xmm15
0000714ce89df7d8  addpd xmm13, xmm8
0000714ce89df7dd  vcmppd xmm9, xmm13, xmm13, 0x03
0000714ce89df7e3  ptest xmm9, xmm9
0000714ce89df7e9  jnz 0x0000714CE89E380D
0000714ce89df7ef  movaps xmm15, [r15+0x290]
0000714ce89df7f7  vmovaps xmm9, [rsp+0x10]
0000714ce89df7fd  vpermilpd xmm9, xmm9, 0x00
0000714ce89df803  movaps xmm8, xmm15
0000714ce89df807  mulpd xmm8, xmm9
0000714ce89df80c  vcmppd xmm7, xmm8, xmm8, 0x03
0000714ce89df812  ptest xmm7, xmm7
0000714ce89df817  jnz 0x0000714CE89E3951
0000714ce89df81d  movaps xmm15, xmm11
0000714ce89df821  addpd xmm15, xmm6
0000714ce89df826  vcmppd xmm9, xmm15, xmm15, 0x03
0000714ce89df82c  ptest xmm9, xmm9
0000714ce89df832  jnz 0x0000714CE89E3A95
0000714ce89df838  movaps xmm11, [r15+0x1E0]
0000714ce89df840  vmovaps xmm9, [rsp+0x10]
0000714ce89df846  vpermilpd xmm9, xmm9, 0x00
0000714ce89df84c  movaps xmm7, xmm11
0000714ce89df850  mulpd xmm7, xmm9
0000714ce89df855  vcmppd xmm6, xmm7, xmm7, 0x03
0000714ce89df85a  ptest xmm6, xmm6
0000714ce89df85f  jnz 0x0000714CE89E3BD8
0000714ce89df865  movaps xmm11, xmm10
0000714ce89df869  addpd xmm11, xmm14
0000714ce89df86e  vcmppd xmm9, xmm11, xmm11, 0x03
0000714ce89df874  ptest xmm9, xmm9
0000714ce89df87a  jnz 0x0000714CE89E3D1A
0000714ce89df880  lea r12, [rax+0x70]
0000714ce89df884  movups xmm14, [r13+r12*1]
0000714ce89df88a  movaps [r15+0x240], xmm14
0000714ce89df892  movaps xmm10, xmm1
0000714ce89df896  addpd xmm10, xmm12
0000714ce89df89b  vcmppd xmm9, xmm10, xmm10, 0x03
0000714ce89df8a1  ptest xmm9, xmm9
0000714ce89df8a7  jnz 0x0000714CE89E3E68
0000714ce89df8ad  movaps [r15+0x170], xmm10
0000714ce89df8b5  vmovaps xmm1, [rsp+0x20]
0000714ce89df8bb  vpermilpd xmm1, xmm1, 0x00
0000714ce89df8c1  movaps xmm12, xmm14
0000714ce89df8c5  mulpd xmm12, xmm1
0000714ce89df8ca  vcmppd xmm9, xmm12, xmm12, 0x03
0000714ce89df8d0  ptest xmm9, xmm9
0000714ce89df8d6  jnz 0x0000714CE89E3FAB
0000714ce89df8dc  vmovaps xmm1, [rsp+0x20]
0000714ce89df8e2  vpermilpd xmm1, xmm1, 0x00
0000714ce89df8e8  vmovaps xmm9, [rsp+0xB0]
0000714ce89df8f1  movaps xmm14, xmm9
0000714ce89df8f5  mulpd xmm14, xmm1
0000714ce89df8fa  vcmppd xmm6, xmm14, xmm14, 0x03
0000714ce89df900  ptest xmm6, xmm6
0000714ce89df905  jnz 0x0000714CE89E40EE
0000714ce89df90b  movaps [r15+0x180], xmm14
0000714ce89df913  movaps xmm1, xmm13
0000714ce89df917  addpd xmm1, xmm8
0000714ce89df91c  vcmppd xmm9, xmm1, xmm1, 0x03
0000714ce89df921  ptest xmm9, xmm9
0000714ce89df927  jnz 0x0000714CE89E4231
0000714ce89df92d  movaps [r15+0x210], xmm1
0000714ce89df935  movups xmm13, [r13+rax*1]
0000714ce89df93b  lea r12, [rax+0x10]
0000714ce89df93f  movups xmm9, [r13+r12*1]
0000714ce89df945  movaps [r15+0x230], xmm9
0000714ce89df94d  movaps xmm8, xmm15
0000714ce89df951  addpd xmm8, xmm7
0000714ce89df956  vcmppd xmm6, xmm8, xmm8, 0x03
0000714ce89df95c  ptest xmm6, xmm6
0000714ce89df961  jnz 0x0000714CE89E4387
0000714ce89df967  movaps [r15+0x130], xmm8
0000714ce89df96f  vmovaps xmm15, [rsp+0x20]
0000714ce89df975  vpermilpd xmm15, xmm15, 0x00
0000714ce89df97b  movaps xmm7, xmm9
0000714ce89df97f  mulpd xmm7, xmm15
0000714ce89df984  vcmppd xmm6, xmm7, xmm7, 0x03
0000714ce89df989  ptest xmm6, xmm6
0000714ce89df98e  jnz 0x0000714CE89E44CA
0000714ce89df994  movaps [r15+0x220], xmm7
0000714ce89df99c  vmovaps xmm15, [rsp+0x20]
0000714ce89df9a2  vpermilpd xmm15, xmm15, 0x00
0000714ce89df9a8  movaps xmm9, xmm13
0000714ce89df9ac  mulpd xmm9, xmm15
0000714ce89df9b1  vcmppd xmm6, xmm9, xmm9, 0x03
0000714ce89df9b7  ptest xmm6, xmm6
0000714ce89df9bc  jnz 0x0000714CE89E460C
0000714ce89df9c2  movaps xmm15, xmm11
0000714ce89df9c6  addpd xmm15, xmm12
0000714ce89df9cb  vcmppd xmm13, xmm15, xmm15, 0x03
0000714ce89df9d1  ptest xmm13, xmm13
0000714ce89df9d7  jnz 0x0000714CE89E4750
0000714ce89df9dd  movaps [r15+0x140], xmm15
0000714ce89df9e5  movaps xmm13, xmm10
0000714ce89df9e9  addpd xmm13, xmm14
0000714ce89df9ee  vcmppd xmm12, xmm13, xmm13, 0x03
0000714ce89df9f4  ptest xmm12, xmm12
0000714ce89df9fa  jnz 0x0000714CE89E4894
0000714ce89dfa00  movaps [r15+0x150], xmm13
0000714ce89dfa08  movaps xmm14, xmm1
0000714ce89dfa0c  addpd xmm14, xmm7
0000714ce89dfa11  vcmppd xmm12, xmm14, xmm14, 0x03
0000714ce89dfa17  ptest xmm12, xmm12
0000714ce89dfa1d  jnz 0x0000714CE89E49D8
0000714ce89dfa23  movaps [r15+0x160], xmm14
0000714ce89dfa2b  movaps xmm1, xmm8
0000714ce89dfa2f  addpd xmm1, xmm9
0000714ce89dfa34  vcmppd xmm12, xmm1, xmm1, 0x03
0000714ce89dfa39  ptest xmm12, xmm12
0000714ce89dfa3f  jnz 0x0000714CE89E4B1A
0000714ce89dfa45  movaps [r15+0x120], xmm1
0000714ce89dfa4d  movups [r13+r14*1], xmm15
0000714ce89dfa53  lea rax, [r14+0x10]
0000714ce89dfa57  movups [r13+rax*1], xmm13
0000714ce89dfa5d  lea rax, [r14+0x20]
0000714ce89dfa61  movups [r13+rax*1], xmm14
0000714ce89dfa67  lea rax, [r14+0x30]
0000714ce89dfa6b  movups [r13+rax*1], xmm1
0000714ce89dfa71  mov eax, [r15+0x108]
0000714ce89dfa78  sahf
0000714ce89dfa79  jnz 0x0000714CE89DFAAB
0000714ce89dfa7b  cmp dword ptr [r15+0x318], 0x00
0000714ce89dfa83  jz 0x0000714CE89DEAE0
0000714ce89dfa89  nop [rax+rax*1], ax
0000714ce89dfa92  nop [rax+rax*1], eax
0000714ce89dfa9a  mov eax, 0x4106D0
0000714ce89dfa9f  mov [r15+0x100], rax
0000714ce89dfaa6  jmp 0x0000714CE87FE110
0000714ce89dfaab  cmp dword ptr [r15+0x318], 0x00
0000714ce89dfab3  jz 0x0000714CE89D89C0
0000714ce89dfab9  nop [rax+rax*1], ax
0000714ce89dfac2  nop [rax+rax*1], eax
0000714ce89dfaca  mov eax, 0x410504
0000714ce89dfacf  mov [r15+0x100], rax
0000714ce89dfad6  jmp 0x0000714CE87FE110
0000714ce89dfadb  int3
0000714ce89dfadc  call 0x0000714CE88E27E0
0000714ce89dfae1  jmp 0x0000714CE89DEBBF
0000714ce89dfae6  call 0x0000714CE88E1570
0000714ce89dfaeb  jmp 0x0000714CE89DEBC8
0000714ce89dfaf0  call 0x0000714CE88E27E0
0000714ce89dfaf5  jmp 0x0000714CE89DEC24
0000714ce89dfafa  call 0x0000714CE88E1570
0000714ce89dfaff  jmp 0x0000714CE89DEC2D
0000714ce89dfb04  call 0x0000714CE88E27E0
0000714ce89dfb09  jmp 0x0000714CE89DEC70
0000714ce89dfb0e  call 0x0000714CE88E1570
0000714ce89dfb13  jmp 0x0000714CE89DEC79
0000714ce89dfb18  call 0x0000714CE880DC20
0000714ce89dfb1d  jmp 0x0000714CE89DECB8
0000714ce89dfb22  call 0x0000714CE88D59C0
0000714ce89dfb27  jmp 0x0000714CE89DECCB
0000714ce89dfb2c  call 0x0000714CE88E0E30
0000714ce89dfb31  jmp 0x0000714CE89DECE9
0000714ce89dfb36  call 0x0000714CE88DFBC0
0000714ce89dfb3b  jmp 0x0000714CE89DECF3
0000714ce89dfb40  call 0x0000714CE88DE950
0000714ce89dfb45  jmp 0x0000714CE89DECFD
0000714ce89dfb4a  sub rsp, 0x08
0000714ce89dfb4e  push rax
0000714ce89dfb4f  push rcx
0000714ce89dfb50  push rdx
0000714ce89dfb51  push rdi
0000714ce89dfb52  push rsi
0000714ce89dfb53  push r8
0000714ce89dfb55  push r9
0000714ce89dfb57  push r10
0000714ce89dfb59  push r11
0000714ce89dfb5b  sub rsp, 0xF0
0000714ce89dfb62  vmovaps [rsp], xmm0
0000714ce89dfb67  vmovaps [rsp+0x10], xmm1
0000714ce89dfb6d  vmovaps [rsp+0x20], xmm2
0000714ce89dfb73  vmovaps [rsp+0x30], xmm3
0000714ce89dfb79  vmovaps [rsp+0x40], xmm4
0000714ce89dfb7f  vmovaps [rsp+0x50], xmm5
0000714ce89dfb85  vmovaps [rsp+0x60], xmm6
0000714ce89dfb8b  vmovaps [rsp+0x70], xmm7
0000714ce89dfb91  vmovaps [rsp+0x80], xmm9
0000714ce89dfb9a  vmovaps [rsp+0x90], xmm10
0000714ce89dfba3  vmovaps [rsp+0xA0], xmm11
0000714ce89dfbac  vmovaps [rsp+0xB0], xmm12
0000714ce89dfbb5  vmovaps [rsp+0xC0], xmm13
0000714ce89dfbbe  vmovaps [rsp+0xD0], xmm14
0000714ce89dfbc7  vmovaps [rsp+0xE0], xmm15
0000714ce89dfbd0  sub rsp, 0x30
0000714ce89dfbd4  movaps [rsp], xmm8
0000714ce89dfbd9  movaps [rsp+0x10], xmm12
0000714ce89dfbdf  movaps [rsp+0x20], xmm15
0000714ce89dfbe5  lea rdi, [rsp]
0000714ce89dfbe9  mov esi, 0x00
0000714ce89dfbee  mov rax, 0x57A55D340530
0000714ce89dfbf8  call rax
0000714ce89dfbfa  movaps xmm8, [rsp]
0000714ce89dfbff  add rsp, 0x30
0000714ce89dfc03  vmovaps xmm0, [rsp]
0000714ce89dfc08  vmovaps xmm1, [rsp+0x10]
0000714ce89dfc0e  vmovaps xmm2, [rsp+0x20]
0000714ce89dfc14  vmovaps xmm3, [rsp+0x30]
0000714ce89dfc1a  vmovaps xmm4, [rsp+0x40]
0000714ce89dfc20  vmovaps xmm5, [rsp+0x50]
0000714ce89dfc26  vmovaps xmm6, [rsp+0x60]
0000714ce89dfc2c  vmovaps xmm7, [rsp+0x70]
0000714ce89dfc32  vmovaps xmm9, [rsp+0x80]
0000714ce89dfc3b  vmovaps xmm10, [rsp+0x90]
0000714ce89dfc44  vmovaps xmm11, [rsp+0xA0]
0000714ce89dfc4d  vmovaps xmm12, [rsp+0xB0]
0000714ce89dfc56  vmovaps xmm13, [rsp+0xC0]
0000714ce89dfc5f  vmovaps xmm14, [rsp+0xD0]
0000714ce89dfc68  vmovaps xmm15, [rsp+0xE0]
0000714ce89dfc71  add rsp, 0xF0
0000714ce89dfc78  pop r11
0000714ce89dfc7a  pop r10
0000714ce89dfc7c  pop r9
0000714ce89dfc7e  pop r8
0000714ce89dfc80  pop rsi
0000714ce89dfc81  pop rdi
0000714ce89dfc82  pop rdx
0000714ce89dfc83  pop rcx
0000714ce89dfc84  pop rax
0000714ce89dfc85  add rsp, 0x08
0000714ce89dfc89  jmp 0x0000714CE89DED27
0000714ce89dfc8e  sub rsp, 0x08
0000714ce89dfc92  push rax
0000714ce89dfc93  push rcx
0000714ce89dfc94  push rdx
0000714ce89dfc95  push rdi
0000714ce89dfc96  push rsi
0000714ce89dfc97  push r8
0000714ce89dfc99  push r9
0000714ce89dfc9b  push r10
0000714ce89dfc9d  push r11
0000714ce89dfc9f  sub rsp, 0xF0
0000714ce89dfca6  vmovaps [rsp], xmm0
0000714ce89dfcab  vmovaps [rsp+0x10], xmm1
0000714ce89dfcb1  vmovaps [rsp+0x20], xmm2
0000714ce89dfcb7  vmovaps [rsp+0x30], xmm3
0000714ce89dfcbd  vmovaps [rsp+0x40], xmm4
0000714ce89dfcc3  vmovaps [rsp+0x50], xmm5
0000714ce89dfcc9  vmovaps [rsp+0x60], xmm6
0000714ce89dfccf  vmovaps [rsp+0x70], xmm8
0000714ce89dfcd5  vmovaps [rsp+0x80], xmm9
0000714ce89dfcde  vmovaps [rsp+0x90], xmm10
0000714ce89dfce7  vmovaps [rsp+0xA0], xmm11
0000714ce89dfcf0  vmovaps [rsp+0xB0], xmm12
0000714ce89dfcf9  vmovaps [rsp+0xC0], xmm13
0000714ce89dfd02  vmovaps [rsp+0xD0], xmm14
0000714ce89dfd0b  vmovaps [rsp+0xE0], xmm15
0000714ce89dfd14  sub rsp, 0x30
0000714ce89dfd18  movaps [rsp], xmm7
0000714ce89dfd1c  movaps [rsp+0x10], xmm9
0000714ce89dfd22  movaps [rsp+0x20], xmm15
0000714ce89dfd28  lea rdi, [rsp]
0000714ce89dfd2c  mov esi, 0x00
0000714ce89dfd31  mov rax, 0x57A55D340530
0000714ce89dfd3b  call rax
0000714ce89dfd3d  movaps xmm7, [rsp]
0000714ce89dfd41  add rsp, 0x30
0000714ce89dfd45  vmovaps xmm0, [rsp]
0000714ce89dfd4a  vmovaps xmm1, [rsp+0x10]
0000714ce89dfd50  vmovaps xmm2, [rsp+0x20]
0000714ce89dfd56  vmovaps xmm3, [rsp+0x30]
0000714ce89dfd5c  vmovaps xmm4, [rsp+0x40]
0000714ce89dfd62  vmovaps xmm5, [rsp+0x50]
0000714ce89dfd68  vmovaps xmm6, [rsp+0x60]
0000714ce89dfd6e  vmovaps xmm8, [rsp+0x70]
0000714ce89dfd74  vmovaps xmm9, [rsp+0x80]
0000714ce89dfd7d  vmovaps xmm10, [rsp+0x90]
0000714ce89dfd86  vmovaps xmm11, [rsp+0xA0]
0000714ce89dfd8f  vmovaps xmm12, [rsp+0xB0]
0000714ce89dfd98  vmovaps xmm13, [rsp+0xC0]
0000714ce89dfda1  vmovaps xmm14, [rsp+0xD0]
0000714ce89dfdaa  vmovaps xmm15, [rsp+0xE0]
0000714ce89dfdb3  add rsp, 0xF0
0000714ce89dfdba  pop r11
0000714ce89dfdbc  pop r10
0000714ce89dfdbe  pop r9
0000714ce89dfdc0  pop r8
0000714ce89dfdc2  pop rsi
0000714ce89dfdc3  pop rdi
0000714ce89dfdc4  pop rdx
0000714ce89dfdc5  pop rcx
0000714ce89dfdc6  pop rax
0000714ce89dfdc7  add rsp, 0x08
0000714ce89dfdcb  jmp 0x0000714CE89DED55
0000714ce89dfdd0  sub rsp, 0x08
0000714ce89dfdd4  push rax
0000714ce89dfdd5  push rcx
0000714ce89dfdd6  push rdx
0000714ce89dfdd7  push rdi
0000714ce89dfdd8  push rsi
0000714ce89dfdd9  push r8
0000714ce89dfddb  push r9
0000714ce89dfddd  push r10
0000714ce89dfddf  push r11
0000714ce89dfde1  sub rsp, 0xF0
0000714ce89dfde8  vmovaps [rsp], xmm0
0000714ce89dfded  vmovaps [rsp+0x10], xmm1
0000714ce89dfdf3  vmovaps [rsp+0x20], xmm2
0000714ce89dfdf9  vmovaps [rsp+0x30], xmm3
0000714ce89dfdff  vmovaps [rsp+0x40], xmm4
0000714ce89dfe05  vmovaps [rsp+0x50], xmm5
0000714ce89dfe0b  vmovaps [rsp+0x60], xmm6
0000714ce89dfe11  vmovaps [rsp+0x70], xmm7
0000714ce89dfe17  vmovaps [rsp+0x80], xmm8
0000714ce89dfe20  vmovaps [rsp+0x90], xmm10
0000714ce89dfe29  vmovaps [rsp+0xA0], xmm11
0000714ce89dfe32  vmovaps [rsp+0xB0], xmm12
0000714ce89dfe3b  vmovaps [rsp+0xC0], xmm13
0000714ce89dfe44  vmovaps [rsp+0xD0], xmm14
0000714ce89dfe4d  vmovaps [rsp+0xE0], xmm15
0000714ce89dfe56  sub rsp, 0x30
0000714ce89dfe5a  movaps [rsp], xmm9
0000714ce89dfe5f  movaps [rsp+0x10], xmm12
0000714ce89dfe65  movaps [rsp+0x20], xmm10
0000714ce89dfe6b  lea rdi, [rsp]
0000714ce89dfe6f  mov esi, 0x00
0000714ce89dfe74  mov rax, 0x57A55D340530
0000714ce89dfe7e  call rax
0000714ce89dfe80  movaps xmm9, [rsp]
0000714ce89dfe85  add rsp, 0x30
0000714ce89dfe89  vmovaps xmm0, [rsp]
0000714ce89dfe8e  vmovaps xmm1, [rsp+0x10]
0000714ce89dfe94  vmovaps xmm2, [rsp+0x20]
0000714ce89dfe9a  vmovaps xmm3, [rsp+0x30]
0000714ce89dfea0  vmovaps xmm4, [rsp+0x40]
0000714ce89dfea6  vmovaps xmm5, [rsp+0x50]
0000714ce89dfeac  vmovaps xmm6, [rsp+0x60]
0000714ce89dfeb2  vmovaps xmm7, [rsp+0x70]
0000714ce89dfeb8  vmovaps xmm8, [rsp+0x80]
0000714ce89dfec1  vmovaps xmm10, [rsp+0x90]
0000714ce89dfeca  vmovaps xmm11, [rsp+0xA0]
0000714ce89dfed3  vmovaps xmm12, [rsp+0xB0]
0000714ce89dfedc  vmovaps xmm13, [rsp+0xC0]
0000714ce89dfee5  vmovaps xmm14, [rsp+0xD0]
0000714ce89dfeee  vmovaps xmm15, [rsp+0xE0]
0000714ce89dfef7  add rsp, 0xF0
0000714ce89dfefe  pop r11
0000714ce89dff00  pop r10
0000714ce89dff02  pop r9
0000714ce89dff04  pop r8
0000714ce89dff06  pop rsi
0000714ce89dff07  pop rdi
0000714ce89dff08  pop rdx
0000714ce89dff09  pop rcx
0000714ce89dff0a  pop rax
0000714ce89dff0b  add rsp, 0x08
0000714ce89dff0f  jmp 0x0000714CE89DED79
0000714ce89dff14  sub rsp, 0x08
0000714ce89dff18  push rax
0000714ce89dff19  push rcx
0000714ce89dff1a  push rdx
0000714ce89dff1b  push rdi
0000714ce89dff1c  push rsi
0000714ce89dff1d  push r8
0000714ce89dff1f  push r9
0000714ce89dff21  push r10
0000714ce89dff23  push r11
0000714ce89dff25  sub rsp, 0xF0
0000714ce89dff2c  vmovaps [rsp], xmm0
0000714ce89dff31  vmovaps [rsp+0x10], xmm1
0000714ce89dff37  vmovaps [rsp+0x20], xmm2
0000714ce89dff3d  vmovaps [rsp+0x30], xmm3
0000714ce89dff43  vmovaps [rsp+0x40], xmm4
0000714ce89dff49  vmovaps [rsp+0x50], xmm5
0000714ce89dff4f  vmovaps [rsp+0x60], xmm6
0000714ce89dff55  vmovaps [rsp+0x70], xmm7
0000714ce89dff5b  vmovaps [rsp+0x80], xmm8
0000714ce89dff64  vmovaps [rsp+0x90], xmm9
0000714ce89dff6d  vmovaps [rsp+0xA0], xmm11
0000714ce89dff76  vmovaps [rsp+0xB0], xmm12
0000714ce89dff7f  vmovaps [rsp+0xC0], xmm13
0000714ce89dff88  vmovaps [rsp+0xD0], xmm14
0000714ce89dff91  vmovaps [rsp+0xE0], xmm15
0000714ce89dff9a  sub rsp, 0x30
0000714ce89dff9e  movaps [rsp], xmm10
0000714ce89dffa3  movaps [rsp+0x10], xmm12
0000714ce89dffa9  movaps [rsp+0x20], xmm11
0000714ce89dffaf  lea rdi, [rsp]
0000714ce89dffb3  mov esi, 0x00
0000714ce89dffb8  mov rax, 0x57A55D340530
0000714ce89dffc2  call rax
0000714ce89dffc4  movaps xmm10, [rsp]
0000714ce89dffc9  add rsp, 0x30
0000714ce89dffcd  vmovaps xmm0, [rsp]
0000714ce89dffd2  vmovaps xmm1, [rsp+0x10]
0000714ce89dffd8  vmovaps xmm2, [rsp+0x20]
0000714ce89dffde  vmovaps xmm3, [rsp+0x30]
0000714ce89dffe4  vmovaps xmm4, [rsp+0x40]
0000714ce89dffea  vmovaps xmm5, [rsp+0x50]
0000714ce89dfff0  vmovaps xmm6, [rsp+0x60]
0000714ce89dfff6  vmovaps xmm7, [rsp+0x70]
0000714ce89dfffc  vmovaps xmm8, [rsp+0x80]
0000714ce89e0005  vmovaps xmm9, [rsp+0x90]
0000714ce89e000e  vmovaps xmm11, [rsp+0xA0]
0000714ce89e0017  vmovaps xmm12, [rsp+0xB0]
0000714ce89e0020  vmovaps xmm13, [rsp+0xC0]
0000714ce89e0029  vmovaps xmm14, [rsp+0xD0]
0000714ce89e0032  vmovaps xmm15, [rsp+0xE0]
0000714ce89e003b  add rsp, 0xF0
0000714ce89e0042  pop r11
0000714ce89e0044  pop r10
0000714ce89e0046  pop r9
0000714ce89e0048  pop r8
0000714ce89e004a  pop rsi
0000714ce89e004b  pop rdi
0000714ce89e004c  pop rdx
0000714ce89e004d  pop rcx
0000714ce89e004e  pop rax
0000714ce89e004f  add rsp, 0x08
0000714ce89e0053  jmp 0x0000714CE89DED93
0000714ce89e0058  sub rsp, 0x08
0000714ce89e005c  push rax
0000714ce89e005d  push rcx
0000714ce89e005e  push rdx
0000714ce89e005f  push rdi
0000714ce89e0060  push rsi
0000714ce89e0061  push r8
0000714ce89e0063  push r9
0000714ce89e0065  push r10
0000714ce89e0067  push r11
0000714ce89e0069  sub rsp, 0xF0
0000714ce89e0070  vmovaps [rsp], xmm0
0000714ce89e0075  vmovaps [rsp+0x10], xmm1
0000714ce89e007b  vmovaps [rsp+0x20], xmm2
0000714ce89e0081  vmovaps [rsp+0x30], xmm3
0000714ce89e0087  vmovaps [rsp+0x40], xmm4
0000714ce89e008d  vmovaps [rsp+0x50], xmm5
0000714ce89e0093  vmovaps [rsp+0x60], xmm7
0000714ce89e0099  vmovaps [rsp+0x70], xmm8
0000714ce89e009f  vmovaps [rsp+0x80], xmm9
0000714ce89e00a8  vmovaps [rsp+0x90], xmm10
0000714ce89e00b1  vmovaps [rsp+0xA0], xmm11
0000714ce89e00ba  vmovaps [rsp+0xB0], xmm12
0000714ce89e00c3  vmovaps [rsp+0xC0], xmm13
0000714ce89e00cc  vmovaps [rsp+0xD0], xmm14
0000714ce89e00d5  vmovaps [rsp+0xE0], xmm15
0000714ce89e00de  sub rsp, 0x30
0000714ce89e00e2  movaps [rsp], xmm6
0000714ce89e00e6  movaps [rsp+0x10], xmm12
0000714ce89e00ec  movaps [rsp+0x20], xmm11
0000714ce89e00f2  lea rdi, [rsp]
0000714ce89e00f6  mov esi, 0x00
0000714ce89e00fb  mov rax, 0x57A55D340530
0000714ce89e0105  call rax
0000714ce89e0107  movaps xmm6, [rsp]
0000714ce89e010b  add rsp, 0x30
0000714ce89e010f  vmovaps xmm0, [rsp]
0000714ce89e0114  vmovaps xmm1, [rsp+0x10]
0000714ce89e011a  vmovaps xmm2, [rsp+0x20]
0000714ce89e0120  vmovaps xmm3, [rsp+0x30]
0000714ce89e0126  vmovaps xmm4, [rsp+0x40]
0000714ce89e012c  vmovaps xmm5, [rsp+0x50]
0000714ce89e0132  vmovaps xmm7, [rsp+0x60]
0000714ce89e0138  vmovaps xmm8, [rsp+0x70]
0000714ce89e013e  vmovaps xmm9, [rsp+0x80]
0000714ce89e0147  vmovaps xmm10, [rsp+0x90]
0000714ce89e0150  vmovaps xmm11, [rsp+0xA0]
0000714ce89e0159  vmovaps xmm12, [rsp+0xB0]
0000714ce89e0162  vmovaps xmm13, [rsp+0xC0]
0000714ce89e016b  vmovaps xmm14, [rsp+0xD0]
0000714ce89e0174  vmovaps xmm15, [rsp+0xE0]
0000714ce89e017d  add rsp, 0xF0
0000714ce89e0184  pop r11
0000714ce89e0186  pop r10
0000714ce89e0188  pop r9
0000714ce89e018a  pop r8
0000714ce89e018c  pop rsi
0000714ce89e018d  pop rdi
0000714ce89e018e  pop rdx
0000714ce89e018f  pop rcx
0000714ce89e0190  pop rax
0000714ce89e0191  add rsp, 0x08
0000714ce89e0195  jmp 0x0000714CE89DEDB4
0000714ce89e019a  sub rsp, 0x08
0000714ce89e019e  push rax
0000714ce89e019f  push rcx
0000714ce89e01a0  push rdx
0000714ce89e01a1  push rdi
0000714ce89e01a2  push rsi
0000714ce89e01a3  push r8
0000714ce89e01a5  push r9
0000714ce89e01a7  push r10
0000714ce89e01a9  push r11
0000714ce89e01ab  sub rsp, 0xF0
0000714ce89e01b2  vmovaps [rsp], xmm0
0000714ce89e01b7  vmovaps [rsp+0x10], xmm1
0000714ce89e01bd  vmovaps [rsp+0x20], xmm2
0000714ce89e01c3  vmovaps [rsp+0x30], xmm4
0000714ce89e01c9  vmovaps [rsp+0x40], xmm5
0000714ce89e01cf  vmovaps [rsp+0x50], xmm6
0000714ce89e01d5  vmovaps [rsp+0x60], xmm7
0000714ce89e01db  vmovaps [rsp+0x70], xmm8
0000714ce89e01e1  vmovaps [rsp+0x80], xmm9
0000714ce89e01ea  vmovaps [rsp+0x90], xmm10
0000714ce89e01f3  vmovaps [rsp+0xA0], xmm11
0000714ce89e01fc  vmovaps [rsp+0xB0], xmm12
0000714ce89e0205  vmovaps [rsp+0xC0], xmm13
0000714ce89e020e  vmovaps [rsp+0xD0], xmm14
0000714ce89e0217  vmovaps [rsp+0xE0], xmm15
0000714ce89e0220  sub rsp, 0x30
0000714ce89e0224  movaps [rsp], xmm3
0000714ce89e0228  movaps [rsp+0x10], xmm5
0000714ce89e022d  movaps [rsp+0x20], xmm4
0000714ce89e0232  lea rdi, [rsp]
0000714ce89e0236  mov esi, 0x00
0000714ce89e023b  mov rax, 0x57A55D340530
0000714ce89e0245  call rax
0000714ce89e0247  movaps xmm3, [rsp]
0000714ce89e024b  add rsp, 0x30
0000714ce89e024f  vmovaps xmm0, [rsp]
0000714ce89e0254  vmovaps xmm1, [rsp+0x10]
0000714ce89e025a  vmovaps xmm2, [rsp+0x20]
0000714ce89e0260  vmovaps xmm4, [rsp+0x30]
0000714ce89e0266  vmovaps xmm5, [rsp+0x40]
0000714ce89e026c  vmovaps xmm6, [rsp+0x50]
0000714ce89e0272  vmovaps xmm7, [rsp+0x60]
0000714ce89e0278  vmovaps xmm8, [rsp+0x70]
0000714ce89e027e  vmovaps xmm9, [rsp+0x80]
0000714ce89e0287  vmovaps xmm10, [rsp+0x90]
0000714ce89e0290  vmovaps xmm11, [rsp+0xA0]
0000714ce89e0299  vmovaps xmm12, [rsp+0xB0]
0000714ce89e02a2  vmovaps xmm13, [rsp+0xC0]
0000714ce89e02ab  vmovaps xmm14, [rsp+0xD0]
0000714ce89e02b4  vmovaps xmm15, [rsp+0xE0]
0000714ce89e02bd  add rsp, 0xF0
0000714ce89e02c4  pop r11
0000714ce89e02c6  pop r10
0000714ce89e02c8  pop r9
0000714ce89e02ca  pop r8
0000714ce89e02cc  pop rsi
0000714ce89e02cd  pop rdi
0000714ce89e02ce  pop rdx
0000714ce89e02cf  pop rcx
0000714ce89e02d0  pop rax
0000714ce89e02d1  add rsp, 0x08
0000714ce89e02d5  jmp 0x0000714CE89DEE15
0000714ce89e02da  sub rsp, 0x08
0000714ce89e02de  push rax
0000714ce89e02df  push rcx
0000714ce89e02e0  push rdx
0000714ce89e02e1  push rdi
0000714ce89e02e2  push rsi
0000714ce89e02e3  push r8
0000714ce89e02e5  push r9
0000714ce89e02e7  push r10
0000714ce89e02e9  push r11
0000714ce89e02eb  sub rsp, 0xF0
0000714ce89e02f2  vmovaps [rsp], xmm0
0000714ce89e02f7  vmovaps [rsp+0x10], xmm1
0000714ce89e02fd  vmovaps [rsp+0x20], xmm2
0000714ce89e0303  vmovaps [rsp+0x30], xmm3
0000714ce89e0309  vmovaps [rsp+0x40], xmm4
0000714ce89e030f  vmovaps [rsp+0x50], xmm6
0000714ce89e0315  vmovaps [rsp+0x60], xmm7
0000714ce89e031b  vmovaps [rsp+0x70], xmm8
0000714ce89e0321  vmovaps [rsp+0x80], xmm9
0000714ce89e032a  vmovaps [rsp+0x90], xmm10
0000714ce89e0333  vmovaps [rsp+0xA0], xmm11
0000714ce89e033c  vmovaps [rsp+0xB0], xmm12
0000714ce89e0345  vmovaps [rsp+0xC0], xmm13
0000714ce89e034e  vmovaps [rsp+0xD0], xmm14
0000714ce89e0357  vmovaps [rsp+0xE0], xmm15
0000714ce89e0360  sub rsp, 0x30
0000714ce89e0364  movaps [rsp], xmm5
0000714ce89e0368  movaps [rsp+0x10], xmm8
0000714ce89e036e  movaps [rsp+0x20], xmm15
0000714ce89e0374  lea rdi, [rsp]
0000714ce89e0378  mov esi, 0x00
0000714ce89e037d  mov rax, 0x57A55D340530
0000714ce89e0387  call rax
0000714ce89e0389  movaps xmm5, [rsp]
0000714ce89e038d  add rsp, 0x30
0000714ce89e0391  vmovaps xmm0, [rsp]
0000714ce89e0396  vmovaps xmm1, [rsp+0x10]
0000714ce89e039c  vmovaps xmm2, [rsp+0x20]
0000714ce89e03a2  vmovaps xmm3, [rsp+0x30]
0000714ce89e03a8  vmovaps xmm4, [rsp+0x40]
0000714ce89e03ae  vmovaps xmm6, [rsp+0x50]
0000714ce89e03b4  vmovaps xmm7, [rsp+0x60]
0000714ce89e03ba  vmovaps xmm8, [rsp+0x70]
0000714ce89e03c0  vmovaps xmm9, [rsp+0x80]
0000714ce89e03c9  vmovaps xmm10, [rsp+0x90]
0000714ce89e03d2  vmovaps xmm11, [rsp+0xA0]
0000714ce89e03db  vmovaps xmm12, [rsp+0xB0]
0000714ce89e03e4  vmovaps xmm13, [rsp+0xC0]
0000714ce89e03ed  vmovaps xmm14, [rsp+0xD0]
0000714ce89e03f6  vmovaps xmm15, [rsp+0xE0]
0000714ce89e03ff  add rsp, 0xF0
0000714ce89e0406  pop r11
0000714ce89e0408  pop r10
0000714ce89e040a  pop r9
0000714ce89e040c  pop r8
0000714ce89e040e  pop rsi
0000714ce89e040f  pop rdi
0000714ce89e0410  pop rdx
0000714ce89e0411  pop rcx
0000714ce89e0412  pop rax
0000714ce89e0413  add rsp, 0x08
0000714ce89e0417  jmp 0x0000714CE89DEE53
0000714ce89e041c  sub rsp, 0x08
0000714ce89e0420  push rax
0000714ce89e0421  push rcx
0000714ce89e0422  push rdx
0000714ce89e0423  push rdi
0000714ce89e0424  push rsi
0000714ce89e0425  push r8
0000714ce89e0427  push r9
0000714ce89e0429  push r10
0000714ce89e042b  push r11
0000714ce89e042d  sub rsp, 0xF0
0000714ce89e0434  vmovaps [rsp], xmm0
0000714ce89e0439  vmovaps [rsp+0x10], xmm1
0000714ce89e043f  vmovaps [rsp+0x20], xmm2
0000714ce89e0445  vmovaps [rsp+0x30], xmm3
0000714ce89e044b  vmovaps [rsp+0x40], xmm5
0000714ce89e0451  vmovaps [rsp+0x50], xmm6
0000714ce89e0457  vmovaps [rsp+0x60], xmm7
0000714ce89e045d  vmovaps [rsp+0x70], xmm8
0000714ce89e0463  vmovaps [rsp+0x80], xmm9
0000714ce89e046c  vmovaps [rsp+0x90], xmm10
0000714ce89e0475  vmovaps [rsp+0xA0], xmm11
0000714ce89e047e  vmovaps [rsp+0xB0], xmm12
0000714ce89e0487  vmovaps [rsp+0xC0], xmm13
0000714ce89e0490  vmovaps [rsp+0xD0], xmm14
0000714ce89e0499  vmovaps [rsp+0xE0], xmm15
0000714ce89e04a2  sub rsp, 0x30
0000714ce89e04a6  movaps [rsp], xmm4
0000714ce89e04aa  movaps [rsp+0x10], xmm9
0000714ce89e04b0  movaps [rsp+0x20], xmm8
0000714ce89e04b6  lea rdi, [rsp]
0000714ce89e04ba  mov esi, 0x00
0000714ce89e04bf  mov rax, 0x57A55D340530
0000714ce89e04c9  call rax
0000714ce89e04cb  movaps xmm4, [rsp]
0000714ce89e04cf  add rsp, 0x30
0000714ce89e04d3  vmovaps xmm0, [rsp]
0000714ce89e04d8  vmovaps xmm1, [rsp+0x10]
0000714ce89e04de  vmovaps xmm2, [rsp+0x20]
0000714ce89e04e4  vmovaps xmm3, [rsp+0x30]
0000714ce89e04ea  vmovaps xmm5, [rsp+0x40]
0000714ce89e04f0  vmovaps xmm6, [rsp+0x50]
0000714ce89e04f6  vmovaps xmm7, [rsp+0x60]
0000714ce89e04fc  vmovaps xmm8, [rsp+0x70]
0000714ce89e0502  vmovaps xmm9, [rsp+0x80]
0000714ce89e050b  vmovaps xmm10, [rsp+0x90]
0000714ce89e0514  vmovaps xmm11, [rsp+0xA0]
0000714ce89e051d  vmovaps xmm12, [rsp+0xB0]
0000714ce89e0526  vmovaps xmm13, [rsp+0xC0]
0000714ce89e052f  vmovaps xmm14, [rsp+0xD0]
0000714ce89e0538  vmovaps xmm15, [rsp+0xE0]
0000714ce89e0541  add rsp, 0xF0
0000714ce89e0548  pop r11
0000714ce89e054a  pop r10
0000714ce89e054c  pop r9
0000714ce89e054e  pop r8
0000714ce89e0550  pop rsi
0000714ce89e0551  pop rdi
0000714ce89e0552  pop rdx
0000714ce89e0553  pop rcx
0000714ce89e0554  pop rax
0000714ce89e0555  add rsp, 0x08
0000714ce89e0559  jmp 0x0000714CE89DEE74
0000714ce89e055e  sub rsp, 0x08
0000714ce89e0562  push rax
0000714ce89e0563  push rcx
0000714ce89e0564  push rdx
0000714ce89e0565  push rdi
0000714ce89e0566  push rsi
0000714ce89e0567  push r8
0000714ce89e0569  push r9
0000714ce89e056b  push r10
0000714ce89e056d  push r11
0000714ce89e056f  sub rsp, 0xF0
0000714ce89e0576  vmovaps [rsp], xmm0
0000714ce89e057b  vmovaps [rsp+0x10], xmm1
0000714ce89e0581  vmovaps [rsp+0x20], xmm2
0000714ce89e0587  vmovaps [rsp+0x30], xmm3
0000714ce89e058d  vmovaps [rsp+0x40], xmm4
0000714ce89e0593  vmovaps [rsp+0x50], xmm5
0000714ce89e0599  vmovaps [rsp+0x60], xmm6
0000714ce89e059f  vmovaps [rsp+0x70], xmm7
0000714ce89e05a5  vmovaps [rsp+0x80], xmm8
0000714ce89e05ae  vmovaps [rsp+0x90], xmm10
0000714ce89e05b7  vmovaps [rsp+0xA0], xmm11
0000714ce89e05c0  vmovaps [rsp+0xB0], xmm12
0000714ce89e05c9  vmovaps [rsp+0xC0], xmm13
0000714ce89e05d2  vmovaps [rsp+0xD0], xmm14
0000714ce89e05db  vmovaps [rsp+0xE0], xmm15
0000714ce89e05e4  sub rsp, 0x30
0000714ce89e05e8  movaps [rsp], xmm9
0000714ce89e05ed  movaps [rsp+0x10], xmm10
0000714ce89e05f3  movaps [rsp+0x20], xmm8
0000714ce89e05f9  lea rdi, [rsp]
0000714ce89e05fd  mov esi, 0x00
0000714ce89e0602  mov rax, 0x57A55D340530
0000714ce89e060c  call rax
0000714ce89e060e  movaps xmm9, [rsp]
0000714ce89e0613  add rsp, 0x30
0000714ce89e0617  vmovaps xmm0, [rsp]
0000714ce89e061c  vmovaps xmm1, [rsp+0x10]
0000714ce89e0622  vmovaps xmm2, [rsp+0x20]
0000714ce89e0628  vmovaps xmm3, [rsp+0x30]
0000714ce89e062e  vmovaps xmm4, [rsp+0x40]
0000714ce89e0634  vmovaps xmm5, [rsp+0x50]
0000714ce89e063a  vmovaps xmm6, [rsp+0x60]
0000714ce89e0640  vmovaps xmm7, [rsp+0x70]
0000714ce89e0646  vmovaps xmm8, [rsp+0x80]
0000714ce89e064f  vmovaps xmm10, [rsp+0x90]
0000714ce89e0658  vmovaps xmm11, [rsp+0xA0]
0000714ce89e0661  vmovaps xmm12, [rsp+0xB0]
0000714ce89e066a  vmovaps xmm13, [rsp+0xC0]
0000714ce89e0673  vmovaps xmm14, [rsp+0xD0]
0000714ce89e067c  vmovaps xmm15, [rsp+0xE0]
0000714ce89e0685  add rsp, 0xF0
0000714ce89e068c  pop r11
0000714ce89e068e  pop r10
0000714ce89e0690  pop r9
0000714ce89e0692  pop r8
0000714ce89e0694  pop rsi
0000714ce89e0695  pop rdi
0000714ce89e0696  pop rdx
0000714ce89e0697  pop rcx
0000714ce89e0698  pop rax
0000714ce89e0699  add rsp, 0x08
0000714ce89e069d  jmp 0x0000714CE89DEE8E
0000714ce89e06a2  call 0x0000714CE88B52F0
0000714ce89e06a7  jmp 0x0000714CE89DEFA8
0000714ce89e06ac  call 0x0000714CE88B52F0
0000714ce89e06b1  jmp 0x0000714CE89DEFBE
0000714ce89e06b6  sub rsp, 0x08
0000714ce89e06ba  push rax
0000714ce89e06bb  push rcx
0000714ce89e06bc  push rdx
0000714ce89e06bd  push rdi
0000714ce89e06be  push rsi
0000714ce89e06bf  push r8
0000714ce89e06c1  push r9
0000714ce89e06c3  push r10
0000714ce89e06c5  push r11
0000714ce89e06c7  sub rsp, 0xF0
0000714ce89e06ce  vmovaps [rsp], xmm0
0000714ce89e06d3  vmovaps [rsp+0x10], xmm2
0000714ce89e06d9  vmovaps [rsp+0x20], xmm3
0000714ce89e06df  vmovaps [rsp+0x30], xmm4
0000714ce89e06e5  vmovaps [rsp+0x40], xmm5
0000714ce89e06eb  vmovaps [rsp+0x50], xmm6
0000714ce89e06f1  vmovaps [rsp+0x60], xmm7
0000714ce89e06f7  vmovaps [rsp+0x70], xmm8
0000714ce89e06fd  vmovaps [rsp+0x80], xmm9
0000714ce89e0706  vmovaps [rsp+0x90], xmm10
0000714ce89e070f  vmovaps [rsp+0xA0], xmm11
0000714ce89e0718  vmovaps [rsp+0xB0], xmm12
0000714ce89e0721  vmovaps [rsp+0xC0], xmm13
0000714ce89e072a  vmovaps [rsp+0xD0], xmm14
0000714ce89e0733  vmovaps [rsp+0xE0], xmm15
0000714ce89e073c  sub rsp, 0x30
0000714ce89e0740  movaps [rsp], xmm1
0000714ce89e0744  movaps [rsp+0x10], xmm6
0000714ce89e0749  movaps [rsp+0x20], xmm15
0000714ce89e074f  lea rdi, [rsp]
0000714ce89e0753  mov esi, 0x00
0000714ce89e0758  mov rax, 0x57A55D340530
0000714ce89e0762  call rax
0000714ce89e0764  movaps xmm1, [rsp]
0000714ce89e0768  add rsp, 0x30
0000714ce89e076c  vmovaps xmm0, [rsp]
0000714ce89e0771  vmovaps xmm2, [rsp+0x10]
0000714ce89e0777  vmovaps xmm3, [rsp+0x20]
0000714ce89e077d  vmovaps xmm4, [rsp+0x30]
0000714ce89e0783  vmovaps xmm5, [rsp+0x40]
0000714ce89e0789  vmovaps xmm6, [rsp+0x50]
0000714ce89e078f  vmovaps xmm7, [rsp+0x60]
0000714ce89e0795  vmovaps xmm8, [rsp+0x70]
0000714ce89e079b  vmovaps xmm9, [rsp+0x80]
0000714ce89e07a4  vmovaps xmm10, [rsp+0x90]
0000714ce89e07ad  vmovaps xmm11, [rsp+0xA0]
0000714ce89e07b6  vmovaps xmm12, [rsp+0xB0]
0000714ce89e07bf  vmovaps xmm13, [rsp+0xC0]
0000714ce89e07c8  vmovaps xmm14, [rsp+0xD0]
0000714ce89e07d1  vmovaps xmm15, [rsp+0xE0]
0000714ce89e07da  add rsp, 0xF0
0000714ce89e07e1  pop r11
0000714ce89e07e3  pop r10
0000714ce89e07e5  pop r9
0000714ce89e07e7  pop r8
0000714ce89e07e9  pop rsi
0000714ce89e07ea  pop rdi
0000714ce89e07eb  pop rdx
0000714ce89e07ec  pop rcx
0000714ce89e07ed  pop rax
0000714ce89e07ee  add rsp, 0x08
0000714ce89e07f2  jmp 0x0000714CE89DEFFB
0000714ce89e07f7  call 0x0000714CE88C4620
0000714ce89e07fc  jmp 0x0000714CE89DF008
0000714ce89e0801  sub rsp, 0x08
0000714ce89e0805  push rax
0000714ce89e0806  push rcx
0000714ce89e0807  push rdx
0000714ce89e0808  push rdi
0000714ce89e0809  push rsi
0000714ce89e080a  push r8
0000714ce89e080c  push r9
0000714ce89e080e  push r10
0000714ce89e0810  push r11
0000714ce89e0812  sub rsp, 0xF0
0000714ce89e0819  vmovaps [rsp], xmm0
0000714ce89e081e  vmovaps [rsp+0x10], xmm1
0000714ce89e0824  vmovaps [rsp+0x20], xmm2
0000714ce89e082a  vmovaps [rsp+0x30], xmm3
0000714ce89e0830  vmovaps [rsp+0x40], xmm4
0000714ce89e0836  vmovaps [rsp+0x50], xmm5
0000714ce89e083c  vmovaps [rsp+0x60], xmm6
0000714ce89e0842  vmovaps [rsp+0x70], xmm7
0000714ce89e0848  vmovaps [rsp+0x80], xmm8
0000714ce89e0851  vmovaps [rsp+0x90], xmm9
0000714ce89e085a  vmovaps [rsp+0xA0], xmm10
0000714ce89e0863  vmovaps [rsp+0xB0], xmm11
0000714ce89e086c  vmovaps [rsp+0xC0], xmm12
0000714ce89e0875  vmovaps [rsp+0xD0], xmm13
0000714ce89e087e  vmovaps [rsp+0xE0], xmm15
0000714ce89e0887  sub rsp, 0x30
0000714ce89e088b  movaps [rsp], xmm14
0000714ce89e0890  movaps [rsp+0x10], xmm4
0000714ce89e0895  movaps [rsp+0x20], xmm3
0000714ce89e089a  lea rdi, [rsp]
0000714ce89e089e  mov esi, 0x00
0000714ce89e08a3  mov rax, 0x57A55D340530
0000714ce89e08ad  call rax
0000714ce89e08af  movaps xmm14, [rsp]
0000714ce89e08b4  add rsp, 0x30
0000714ce89e08b8  vmovaps xmm0, [rsp]
0000714ce89e08bd  vmovaps xmm1, [rsp+0x10]
0000714ce89e08c3  vmovaps xmm2, [rsp+0x20]
0000714ce89e08c9  vmovaps xmm3, [rsp+0x30]
0000714ce89e08cf  vmovaps xmm4, [rsp+0x40]
0000714ce89e08d5  vmovaps xmm5, [rsp+0x50]
0000714ce89e08db  vmovaps xmm6, [rsp+0x60]
0000714ce89e08e1  vmovaps xmm7, [rsp+0x70]
0000714ce89e08e7  vmovaps xmm8, [rsp+0x80]
0000714ce89e08f0  vmovaps xmm9, [rsp+0x90]
0000714ce89e08f9  vmovaps xmm10, [rsp+0xA0]
0000714ce89e0902  vmovaps xmm11, [rsp+0xB0]
0000714ce89e090b  vmovaps xmm12, [rsp+0xC0]
0000714ce89e0914  vmovaps xmm13, [rsp+0xD0]
0000714ce89e091d  vmovaps xmm15, [rsp+0xE0]
0000714ce89e0926  add rsp, 0xF0
0000714ce89e092d  pop r11
0000714ce89e092f  pop r10
0000714ce89e0931  pop r9
0000714ce89e0933  pop r8
0000714ce89e0935  pop rsi
0000714ce89e0936  pop rdi
0000714ce89e0937  pop rdx
0000714ce89e0938  pop rcx
0000714ce89e0939  pop rax
0000714ce89e093a  add rsp, 0x08
0000714ce89e093e  jmp 0x0000714CE89DF022
0000714ce89e0943  sub rsp, 0x08
0000714ce89e0947  push rax
0000714ce89e0948  push rcx
0000714ce89e0949  push rdx
0000714ce89e094a  push rdi
0000714ce89e094b  push rsi
0000714ce89e094c  push r8
0000714ce89e094e  push r9
0000714ce89e0950  push r10
0000714ce89e0952  push r11
0000714ce89e0954  sub rsp, 0xF0
0000714ce89e095b  vmovaps [rsp], xmm0
0000714ce89e0960  vmovaps [rsp+0x10], xmm1
0000714ce89e0966  vmovaps [rsp+0x20], xmm2
0000714ce89e096c  vmovaps [rsp+0x30], xmm3
0000714ce89e0972  vmovaps [rsp+0x40], xmm4
0000714ce89e0978  vmovaps [rsp+0x50], xmm5
0000714ce89e097e  vmovaps [rsp+0x60], xmm7
0000714ce89e0984  vmovaps [rsp+0x70], xmm8
0000714ce89e098a  vmovaps [rsp+0x80], xmm9
0000714ce89e0993  vmovaps [rsp+0x90], xmm10
0000714ce89e099c  vmovaps [rsp+0xA0], xmm11
0000714ce89e09a5  vmovaps [rsp+0xB0], xmm12
0000714ce89e09ae  vmovaps [rsp+0xC0], xmm13
0000714ce89e09b7  vmovaps [rsp+0xD0], xmm14
0000714ce89e09c0  vmovaps [rsp+0xE0], xmm15
0000714ce89e09c9  sub rsp, 0x30
0000714ce89e09cd  movaps [rsp], xmm6
0000714ce89e09d1  movaps [rsp+0x10], xmm9
0000714ce89e09d7  movaps [rsp+0x20], xmm7
0000714ce89e09dc  lea rdi, [rsp]
0000714ce89e09e0  mov esi, 0x00
0000714ce89e09e5  mov rax, 0x57A55D340530
0000714ce89e09ef  call rax
0000714ce89e09f1  movaps xmm6, [rsp]
0000714ce89e09f5  add rsp, 0x30
0000714ce89e09f9  vmovaps xmm0, [rsp]
0000714ce89e09fe  vmovaps xmm1, [rsp+0x10]
0000714ce89e0a04  vmovaps xmm2, [rsp+0x20]
0000714ce89e0a0a  vmovaps xmm3, [rsp+0x30]
0000714ce89e0a10  vmovaps xmm4, [rsp+0x40]
0000714ce89e0a16  vmovaps xmm5, [rsp+0x50]
0000714ce89e0a1c  vmovaps xmm7, [rsp+0x60]
0000714ce89e0a22  vmovaps xmm8, [rsp+0x70]
0000714ce89e0a28  vmovaps xmm9, [rsp+0x80]
0000714ce89e0a31  vmovaps xmm10, [rsp+0x90]
0000714ce89e0a3a  vmovaps xmm11, [rsp+0xA0]
0000714ce89e0a43  vmovaps xmm12, [rsp+0xB0]
0000714ce89e0a4c  vmovaps xmm13, [rsp+0xC0]
0000714ce89e0a55  vmovaps xmm14, [rsp+0xD0]
0000714ce89e0a5e  vmovaps xmm15, [rsp+0xE0]
0000714ce89e0a67  add rsp, 0xF0
0000714ce89e0a6e  pop r11
0000714ce89e0a70  pop r10
0000714ce89e0a72  pop r9
0000714ce89e0a74  pop r8
0000714ce89e0a76  pop rsi
0000714ce89e0a77  pop rdi
0000714ce89e0a78  pop rdx
0000714ce89e0a79  pop rcx
0000714ce89e0a7a  pop rax
0000714ce89e0a7b  add rsp, 0x08
0000714ce89e0a7f  jmp 0x0000714CE89DF03A
0000714ce89e0a84  sub rsp, 0x08
0000714ce89e0a88  push rax
0000714ce89e0a89  push rcx
0000714ce89e0a8a  push rdx
0000714ce89e0a8b  push rdi
0000714ce89e0a8c  push rsi
0000714ce89e0a8d  push r8
0000714ce89e0a8f  push r9
0000714ce89e0a91  push r10
0000714ce89e0a93  push r11
0000714ce89e0a95  sub rsp, 0xF0
0000714ce89e0a9c  vmovaps [rsp], xmm0
0000714ce89e0aa1  vmovaps [rsp+0x10], xmm1
0000714ce89e0aa7  vmovaps [rsp+0x20], xmm2
0000714ce89e0aad  vmovaps [rsp+0x30], xmm3
0000714ce89e0ab3  vmovaps [rsp+0x40], xmm4
0000714ce89e0ab9  vmovaps [rsp+0x50], xmm5
0000714ce89e0abf  vmovaps [rsp+0x60], xmm6
0000714ce89e0ac5  vmovaps [rsp+0x70], xmm8
0000714ce89e0acb  vmovaps [rsp+0x80], xmm9
0000714ce89e0ad4  vmovaps [rsp+0x90], xmm10
0000714ce89e0add  vmovaps [rsp+0xA0], xmm11
0000714ce89e0ae6  vmovaps [rsp+0xB0], xmm12
0000714ce89e0aef  vmovaps [rsp+0xC0], xmm13
0000714ce89e0af8  vmovaps [rsp+0xD0], xmm14
0000714ce89e0b01  vmovaps [rsp+0xE0], xmm15
0000714ce89e0b0a  sub rsp, 0x30
0000714ce89e0b0e  movaps [rsp], xmm7
0000714ce89e0b12  movaps [rsp+0x10], xmm4
0000714ce89e0b17  movaps [rsp+0x20], xmm9
0000714ce89e0b1d  lea rdi, [rsp]
0000714ce89e0b21  mov esi, 0x00
0000714ce89e0b26  mov rax, 0x57A55D340530
0000714ce89e0b30  call rax
0000714ce89e0b32  movaps xmm7, [rsp]
0000714ce89e0b36  add rsp, 0x30
0000714ce89e0b3a  vmovaps xmm0, [rsp]
0000714ce89e0b3f  vmovaps xmm1, [rsp+0x10]
0000714ce89e0b45  vmovaps xmm2, [rsp+0x20]
0000714ce89e0b4b  vmovaps xmm3, [rsp+0x30]
0000714ce89e0b51  vmovaps xmm4, [rsp+0x40]
0000714ce89e0b57  vmovaps xmm5, [rsp+0x50]
0000714ce89e0b5d  vmovaps xmm6, [rsp+0x60]
0000714ce89e0b63  vmovaps xmm8, [rsp+0x70]
0000714ce89e0b69  vmovaps xmm9, [rsp+0x80]
0000714ce89e0b72  vmovaps xmm10, [rsp+0x90]
0000714ce89e0b7b  vmovaps xmm11, [rsp+0xA0]
0000714ce89e0b84  vmovaps xmm12, [rsp+0xB0]
0000714ce89e0b8d  vmovaps xmm13, [rsp+0xC0]
0000714ce89e0b96  vmovaps xmm14, [rsp+0xD0]
0000714ce89e0b9f  vmovaps xmm15, [rsp+0xE0]
0000714ce89e0ba8  add rsp, 0xF0
0000714ce89e0baf  pop r11
0000714ce89e0bb1  pop r10
0000714ce89e0bb3  pop r9
0000714ce89e0bb5  pop r8
0000714ce89e0bb7  pop rsi
0000714ce89e0bb8  pop rdi
0000714ce89e0bb9  pop rdx
0000714ce89e0bba  pop rcx
0000714ce89e0bbb  pop rax
0000714ce89e0bbc  add rsp, 0x08
0000714ce89e0bc0  jmp 0x0000714CE89DF067
0000714ce89e0bc5  sub rsp, 0x08
0000714ce89e0bc9  push rax
0000714ce89e0bca  push rcx
0000714ce89e0bcb  push rdx
0000714ce89e0bcc  push rdi
0000714ce89e0bcd  push rsi
0000714ce89e0bce  push r8
0000714ce89e0bd0  push r9
0000714ce89e0bd2  push r10
0000714ce89e0bd4  push r11
0000714ce89e0bd6  sub rsp, 0xF0
0000714ce89e0bdd  vmovaps [rsp], xmm0
0000714ce89e0be2  vmovaps [rsp+0x10], xmm1
0000714ce89e0be8  vmovaps [rsp+0x20], xmm2
0000714ce89e0bee  vmovaps [rsp+0x30], xmm3
0000714ce89e0bf4  vmovaps [rsp+0x40], xmm5
0000714ce89e0bfa  vmovaps [rsp+0x50], xmm6
0000714ce89e0c00  vmovaps [rsp+0x60], xmm7
0000714ce89e0c06  vmovaps [rsp+0x70], xmm8
0000714ce89e0c0c  vmovaps [rsp+0x80], xmm9
0000714ce89e0c15  vmovaps [rsp+0x90], xmm10
0000714ce89e0c1e  vmovaps [rsp+0xA0], xmm11
0000714ce89e0c27  vmovaps [rsp+0xB0], xmm12
0000714ce89e0c30  vmovaps [rsp+0xC0], xmm13
0000714ce89e0c39  vmovaps [rsp+0xD0], xmm14
0000714ce89e0c42  vmovaps [rsp+0xE0], xmm15
0000714ce89e0c4b  sub rsp, 0x30
0000714ce89e0c4f  movaps [rsp], xmm4
0000714ce89e0c53  movaps [rsp+0x10], xmm15
0000714ce89e0c59  movaps [rsp+0x20], xmm9
0000714ce89e0c5f  lea rdi, [rsp]
0000714ce89e0c63  mov esi, 0x00
0000714ce89e0c68  mov rax, 0x57A55D340530
0000714ce89e0c72  call rax
0000714ce89e0c74  movaps xmm4, [rsp]
0000714ce89e0c78  add rsp, 0x30
0000714ce89e0c7c  vmovaps xmm0, [rsp]
0000714ce89e0c81  vmovaps xmm1, [rsp+0x10]
0000714ce89e0c87  vmovaps xmm2, [rsp+0x20]
0000714ce89e0c8d  vmovaps xmm3, [rsp+0x30]
0000714ce89e0c93  vmovaps xmm5, [rsp+0x40]
0000714ce89e0c99  vmovaps xmm6, [rsp+0x50]
0000714ce89e0c9f  vmovaps xmm7, [rsp+0x60]
0000714ce89e0ca5  vmovaps xmm8, [rsp+0x70]
0000714ce89e0cab  vmovaps xmm9, [rsp+0x80]
0000714ce89e0cb4  vmovaps xmm10, [rsp+0x90]
0000714ce89e0cbd  vmovaps xmm11, [rsp+0xA0]
0000714ce89e0cc6  vmovaps xmm12, [rsp+0xB0]
0000714ce89e0ccf  vmovaps xmm13, [rsp+0xC0]
0000714ce89e0cd8  vmovaps xmm14, [rsp+0xD0]
0000714ce89e0ce1  vmovaps xmm15, [rsp+0xE0]
0000714ce89e0cea  add rsp, 0xF0
0000714ce89e0cf1  pop r11
0000714ce89e0cf3  pop r10
0000714ce89e0cf5  pop r9
0000714ce89e0cf7  pop r8
0000714ce89e0cf9  pop rsi
0000714ce89e0cfa  pop rdi
0000714ce89e0cfb  pop rdx
0000714ce89e0cfc  pop rcx
0000714ce89e0cfd  pop rax
0000714ce89e0cfe  add rsp, 0x08
0000714ce89e0d02  jmp 0x0000714CE89DF08C
0000714ce89e0d07  call 0x0000714CE88C4620
0000714ce89e0d0c  jmp 0x0000714CE89DF099
0000714ce89e0d11  sub rsp, 0x08
0000714ce89e0d15  push rax
0000714ce89e0d16  push rcx
0000714ce89e0d17  push rdx
0000714ce89e0d18  push rdi
0000714ce89e0d19  push rsi
0000714ce89e0d1a  push r8
0000714ce89e0d1c  push r9
0000714ce89e0d1e  push r10
0000714ce89e0d20  push r11
0000714ce89e0d22  sub rsp, 0xF0
0000714ce89e0d29  vmovaps [rsp], xmm0
0000714ce89e0d2e  vmovaps [rsp+0x10], xmm1
0000714ce89e0d34  vmovaps [rsp+0x20], xmm2
0000714ce89e0d3a  vmovaps [rsp+0x30], xmm4
0000714ce89e0d40  vmovaps [rsp+0x40], xmm5
0000714ce89e0d46  vmovaps [rsp+0x50], xmm6
0000714ce89e0d4c  vmovaps [rsp+0x60], xmm7
0000714ce89e0d52  vmovaps [rsp+0x70], xmm8
0000714ce89e0d58  vmovaps [rsp+0x80], xmm9
0000714ce89e0d61  vmovaps [rsp+0x90], xmm10
0000714ce89e0d6a  vmovaps [rsp+0xA0], xmm11
0000714ce89e0d73  vmovaps [rsp+0xB0], xmm12
0000714ce89e0d7c  vmovaps [rsp+0xC0], xmm13
0000714ce89e0d85  vmovaps [rsp+0xD0], xmm14
0000714ce89e0d8e  vmovaps [rsp+0xE0], xmm15
0000714ce89e0d97  sub rsp, 0x30
0000714ce89e0d9b  movaps [rsp], xmm3
0000714ce89e0d9f  movaps [rsp+0x10], xmm1
0000714ce89e0da4  movaps [rsp+0x20], xmm9
0000714ce89e0daa  lea rdi, [rsp]
0000714ce89e0dae  mov esi, 0x00
0000714ce89e0db3  mov rax, 0x57A55D340530
0000714ce89e0dbd  call rax
0000714ce89e0dbf  movaps xmm3, [rsp]
0000714ce89e0dc3  add rsp, 0x30
0000714ce89e0dc7  vmovaps xmm0, [rsp]
0000714ce89e0dcc  vmovaps xmm1, [rsp+0x10]
0000714ce89e0dd2  vmovaps xmm2, [rsp+0x20]
0000714ce89e0dd8  vmovaps xmm4, [rsp+0x30]
0000714ce89e0dde  vmovaps xmm5, [rsp+0x40]
0000714ce89e0de4  vmovaps xmm6, [rsp+0x50]
0000714ce89e0dea  vmovaps xmm7, [rsp+0x60]
0000714ce89e0df0  vmovaps xmm8, [rsp+0x70]
0000714ce89e0df6  vmovaps xmm9, [rsp+0x80]
0000714ce89e0dff  vmovaps xmm10, [rsp+0x90]
0000714ce89e0e08  vmovaps xmm11, [rsp+0xA0]
0000714ce89e0e11  vmovaps xmm12, [rsp+0xB0]
0000714ce89e0e1a  vmovaps xmm13, [rsp+0xC0]
0000714ce89e0e23  vmovaps xmm14, [rsp+0xD0]
0000714ce89e0e2c  vmovaps xmm15, [rsp+0xE0]
0000714ce89e0e35  add rsp, 0xF0
0000714ce89e0e3c  pop r11
0000714ce89e0e3e  pop r10
0000714ce89e0e40  pop r9
0000714ce89e0e42  pop r8
0000714ce89e0e44  pop rsi
0000714ce89e0e45  pop rdi
0000714ce89e0e46  pop rdx
0000714ce89e0e47  pop rcx
0000714ce89e0e48  pop rax
0000714ce89e0e49  add rsp, 0x08
0000714ce89e0e4d  jmp 0x0000714CE89DF0D6
0000714ce89e0e52  sub rsp, 0x08
0000714ce89e0e56  push rax
0000714ce89e0e57  push rcx
0000714ce89e0e58  push rdx
0000714ce89e0e59  push rdi
0000714ce89e0e5a  push rsi
0000714ce89e0e5b  push r8
0000714ce89e0e5d  push r9
0000714ce89e0e5f  push r10
0000714ce89e0e61  push r11
0000714ce89e0e63  sub rsp, 0xF0
0000714ce89e0e6a  vmovaps [rsp], xmm0
0000714ce89e0e6f  vmovaps [rsp+0x10], xmm2
0000714ce89e0e75  vmovaps [rsp+0x20], xmm3
0000714ce89e0e7b  vmovaps [rsp+0x30], xmm4
0000714ce89e0e81  vmovaps [rsp+0x40], xmm5
0000714ce89e0e87  vmovaps [rsp+0x50], xmm6
0000714ce89e0e8d  vmovaps [rsp+0x60], xmm7
0000714ce89e0e93  vmovaps [rsp+0x70], xmm8
0000714ce89e0e99  vmovaps [rsp+0x80], xmm9
0000714ce89e0ea2  vmovaps [rsp+0x90], xmm10
0000714ce89e0eab  vmovaps [rsp+0xA0], xmm11
0000714ce89e0eb4  vmovaps [rsp+0xB0], xmm12
0000714ce89e0ebd  vmovaps [rsp+0xC0], xmm13
0000714ce89e0ec6  vmovaps [rsp+0xD0], xmm14
0000714ce89e0ecf  vmovaps [rsp+0xE0], xmm15
0000714ce89e0ed8  sub rsp, 0x30
0000714ce89e0edc  movaps [rsp], xmm1
0000714ce89e0ee0  movaps [rsp+0x10], xmm15
0000714ce89e0ee6  movaps [rsp+0x20], xmm9
0000714ce89e0eec  lea rdi, [rsp]
0000714ce89e0ef0  mov esi, 0x00
0000714ce89e0ef5  mov rax, 0x57A55D340530
0000714ce89e0eff  call rax
0000714ce89e0f01  movaps xmm1, [rsp]
0000714ce89e0f05  add rsp, 0x30
0000714ce89e0f09  vmovaps xmm0, [rsp]
0000714ce89e0f0e  vmovaps xmm2, [rsp+0x10]
0000714ce89e0f14  vmovaps xmm3, [rsp+0x20]
0000714ce89e0f1a  vmovaps xmm4, [rsp+0x30]
0000714ce89e0f20  vmovaps xmm5, [rsp+0x40]
0000714ce89e0f26  vmovaps xmm6, [rsp+0x50]
0000714ce89e0f2c  vmovaps xmm7, [rsp+0x60]
0000714ce89e0f32  vmovaps xmm8, [rsp+0x70]
0000714ce89e0f38  vmovaps xmm9, [rsp+0x80]
0000714ce89e0f41  vmovaps xmm10, [rsp+0x90]
0000714ce89e0f4a  vmovaps xmm11, [rsp+0xA0]
0000714ce89e0f53  vmovaps xmm12, [rsp+0xB0]
0000714ce89e0f5c  vmovaps xmm13, [rsp+0xC0]
0000714ce89e0f65  vmovaps xmm14, [rsp+0xD0]
0000714ce89e0f6e  vmovaps xmm15, [rsp+0xE0]
0000714ce89e0f77  add rsp, 0xF0
0000714ce89e0f7e  pop r11
0000714ce89e0f80  pop r10
0000714ce89e0f82  pop r9
0000714ce89e0f84  pop r8
0000714ce89e0f86  pop rsi
0000714ce89e0f87  pop rdi
0000714ce89e0f88  pop rdx
0000714ce89e0f89  pop rcx
0000714ce89e0f8a  pop rax
0000714ce89e0f8b  add rsp, 0x08
0000714ce89e0f8f  jmp 0x0000714CE89DF15E
0000714ce89e0f94  call 0x0000714CE88C4620
0000714ce89e0f99  jmp 0x0000714CE89DF16B
0000714ce89e0f9e  sub rsp, 0x08
0000714ce89e0fa2  push rax
0000714ce89e0fa3  push rcx
0000714ce89e0fa4  push rdx
0000714ce89e0fa5  push rdi
0000714ce89e0fa6  push rsi
0000714ce89e0fa7  push r8
0000714ce89e0fa9  push r9
0000714ce89e0fab  push r10
0000714ce89e0fad  push r11
0000714ce89e0faf  sub rsp, 0xF0
0000714ce89e0fb6  vmovaps [rsp], xmm0
0000714ce89e0fbb  vmovaps [rsp+0x10], xmm2
0000714ce89e0fc1  vmovaps [rsp+0x20], xmm3
0000714ce89e0fc7  vmovaps [rsp+0x30], xmm4
0000714ce89e0fcd  vmovaps [rsp+0x40], xmm5
0000714ce89e0fd3  vmovaps [rsp+0x50], xmm6
0000714ce89e0fd9  vmovaps [rsp+0x60], xmm7
0000714ce89e0fdf  vmovaps [rsp+0x70], xmm8
0000714ce89e0fe5  vmovaps [rsp+0x80], xmm9
0000714ce89e0fee  vmovaps [rsp+0x90], xmm10
0000714ce89e0ff7  vmovaps [rsp+0xA0], xmm11
0000714ce89e1000  vmovaps [rsp+0xB0], xmm12
0000714ce89e1009  vmovaps [rsp+0xC0], xmm13
0000714ce89e1012  vmovaps [rsp+0xD0], xmm14
0000714ce89e101b  vmovaps [rsp+0xE0], xmm15
0000714ce89e1024  sub rsp, 0x30
0000714ce89e1028  movaps [rsp], xmm1
0000714ce89e102c  movaps [rsp+0x10], xmm5
0000714ce89e1031  movaps [rsp+0x20], xmm7
0000714ce89e1036  lea rdi, [rsp]
0000714ce89e103a  mov esi, 0x00
0000714ce89e103f  mov rax, 0x57A55D340530
0000714ce89e1049  call rax
0000714ce89e104b  movaps xmm1, [rsp]
0000714ce89e104f  add rsp, 0x30
0000714ce89e1053  vmovaps xmm0, [rsp]
0000714ce89e1058  vmovaps xmm2, [rsp+0x10]
0000714ce89e105e  vmovaps xmm3, [rsp+0x20]
0000714ce89e1064  vmovaps xmm4, [rsp+0x30]
0000714ce89e106a  vmovaps xmm5, [rsp+0x40]
0000714ce89e1070  vmovaps xmm6, [rsp+0x50]
0000714ce89e1076  vmovaps xmm7, [rsp+0x60]
0000714ce89e107c  vmovaps xmm8, [rsp+0x70]
0000714ce89e1082  vmovaps xmm9, [rsp+0x80]
0000714ce89e108b  vmovaps xmm10, [rsp+0x90]
0000714ce89e1094  vmovaps xmm11, [rsp+0xA0]
0000714ce89e109d  vmovaps xmm12, [rsp+0xB0]
0000714ce89e10a6  vmovaps xmm13, [rsp+0xC0]
0000714ce89e10af  vmovaps xmm14, [rsp+0xD0]
0000714ce89e10b8  vmovaps xmm15, [rsp+0xE0]
0000714ce89e10c1  add rsp, 0xF0
0000714ce89e10c8  pop r11
0000714ce89e10ca  pop r10
0000714ce89e10cc  pop r9
0000714ce89e10ce  pop r8
0000714ce89e10d0  pop rsi
0000714ce89e10d1  pop rdi
0000714ce89e10d2  pop rdx
0000714ce89e10d3  pop rcx
0000714ce89e10d4  pop rax
0000714ce89e10d5  add rsp, 0x08
0000714ce89e10d9  jmp 0x0000714CE89DF210
0000714ce89e10de  sub rsp, 0x08
0000714ce89e10e2  push rax
0000714ce89e10e3  push rcx
0000714ce89e10e4  push rdx
0000714ce89e10e5  push rdi
0000714ce89e10e6  push rsi
0000714ce89e10e7  push r8
0000714ce89e10e9  push r9
0000714ce89e10eb  push r10
0000714ce89e10ed  push r11
0000714ce89e10ef  sub rsp, 0xF0
0000714ce89e10f6  vmovaps [rsp], xmm0
0000714ce89e10fb  vmovaps [rsp+0x10], xmm1
0000714ce89e1101  vmovaps [rsp+0x20], xmm2
0000714ce89e1107  vmovaps [rsp+0x30], xmm3
0000714ce89e110d  vmovaps [rsp+0x40], xmm4
0000714ce89e1113  vmovaps [rsp+0x50], xmm5
0000714ce89e1119  vmovaps [rsp+0x60], xmm6
0000714ce89e111f  vmovaps [rsp+0x70], xmm8
0000714ce89e1125  vmovaps [rsp+0x80], xmm9
0000714ce89e112e  vmovaps [rsp+0x90], xmm10
0000714ce89e1137  vmovaps [rsp+0xA0], xmm11
0000714ce89e1140  vmovaps [rsp+0xB0], xmm12
0000714ce89e1149  vmovaps [rsp+0xC0], xmm13
0000714ce89e1152  vmovaps [rsp+0xD0], xmm14
0000714ce89e115b  vmovaps [rsp+0xE0], xmm15
0000714ce89e1164  sub rsp, 0x30
0000714ce89e1168  movaps [rsp], xmm7
0000714ce89e116c  movaps [rsp+0x10], xmm5
0000714ce89e1171  movaps [rsp+0x20], xmm15
0000714ce89e1177  lea rdi, [rsp]
0000714ce89e117b  mov esi, 0x00
0000714ce89e1180  mov rax, 0x57A55D340530
0000714ce89e118a  call rax
0000714ce89e118c  movaps xmm7, [rsp]
0000714ce89e1190  add rsp, 0x30
0000714ce89e1194  vmovaps xmm0, [rsp]
0000714ce89e1199  vmovaps xmm1, [rsp+0x10]
0000714ce89e119f  vmovaps xmm2, [rsp+0x20]
0000714ce89e11a5  vmovaps xmm3, [rsp+0x30]
0000714ce89e11ab  vmovaps xmm4, [rsp+0x40]
0000714ce89e11b1  vmovaps xmm5, [rsp+0x50]
0000714ce89e11b7  vmovaps xmm6, [rsp+0x60]
0000714ce89e11bd  vmovaps xmm8, [rsp+0x70]
0000714ce89e11c3  vmovaps xmm9, [rsp+0x80]
0000714ce89e11cc  vmovaps xmm10, [rsp+0x90]
0000714ce89e11d5  vmovaps xmm11, [rsp+0xA0]
0000714ce89e11de  vmovaps xmm12, [rsp+0xB0]
0000714ce89e11e7  vmovaps xmm13, [rsp+0xC0]
0000714ce89e11f0  vmovaps xmm14, [rsp+0xD0]
0000714ce89e11f9  vmovaps xmm15, [rsp+0xE0]
0000714ce89e1202  add rsp, 0xF0
0000714ce89e1209  pop r11
0000714ce89e120b  pop r10
0000714ce89e120d  pop r9
0000714ce89e120f  pop r8
0000714ce89e1211  pop rsi
0000714ce89e1212  pop rdi
0000714ce89e1213  pop rdx
0000714ce89e1214  pop rcx
0000714ce89e1215  pop rax
0000714ce89e1216  add rsp, 0x08
0000714ce89e121a  jmp 0x0000714CE89DF246
0000714ce89e121f  call 0x0000714CE88B52F0
0000714ce89e1224  jmp 0x0000714CE89DF253
0000714ce89e1229  sub rsp, 0x08
0000714ce89e122d  push rax
0000714ce89e122e  push rcx
0000714ce89e122f  push rdx
0000714ce89e1230  push rdi
0000714ce89e1231  push rsi
0000714ce89e1232  push r8
0000714ce89e1234  push r9
0000714ce89e1236  push r10
0000714ce89e1238  push r11
0000714ce89e123a  sub rsp, 0xF0
0000714ce89e1241  vmovaps [rsp], xmm0
0000714ce89e1246  vmovaps [rsp+0x10], xmm1
0000714ce89e124c  vmovaps [rsp+0x20], xmm2
0000714ce89e1252  vmovaps [rsp+0x30], xmm3
0000714ce89e1258  vmovaps [rsp+0x40], xmm4
0000714ce89e125e  vmovaps [rsp+0x50], xmm5
0000714ce89e1264  vmovaps [rsp+0x60], xmm6
0000714ce89e126a  vmovaps [rsp+0x70], xmm7
0000714ce89e1270  vmovaps [rsp+0x80], xmm8
0000714ce89e1279  vmovaps [rsp+0x90], xmm9
0000714ce89e1282  vmovaps [rsp+0xA0], xmm10
0000714ce89e128b  vmovaps [rsp+0xB0], xmm11
0000714ce89e1294  vmovaps [rsp+0xC0], xmm12
0000714ce89e129d  vmovaps [rsp+0xD0], xmm13
0000714ce89e12a6  vmovaps [rsp+0xE0], xmm14
0000714ce89e12af  sub rsp, 0x30
0000714ce89e12b3  movaps [rsp], xmm15
0000714ce89e12b8  movaps [rsp+0x10], xmm5
0000714ce89e12bd  movaps [rsp+0x20], xmm3
0000714ce89e12c2  lea rdi, [rsp]
0000714ce89e12c6  mov esi, 0x00
0000714ce89e12cb  mov rax, 0x57A55D340530
0000714ce89e12d5  call rax
0000714ce89e12d7  movaps xmm15, [rsp]
0000714ce89e12dc  add rsp, 0x30
0000714ce89e12e0  vmovaps xmm0, [rsp]
0000714ce89e12e5  vmovaps xmm1, [rsp+0x10]
0000714ce89e12eb  vmovaps xmm2, [rsp+0x20]
0000714ce89e12f1  vmovaps xmm3, [rsp+0x30]
0000714ce89e12f7  vmovaps xmm4, [rsp+0x40]
0000714ce89e12fd  vmovaps xmm5, [rsp+0x50]
0000714ce89e1303  vmovaps xmm6, [rsp+0x60]
0000714ce89e1309  vmovaps xmm7, [rsp+0x70]
0000714ce89e130f  vmovaps xmm8, [rsp+0x80]
0000714ce89e1318  vmovaps xmm9, [rsp+0x90]
0000714ce89e1321  vmovaps xmm10, [rsp+0xA0]
0000714ce89e132a  vmovaps xmm11, [rsp+0xB0]
0000714ce89e1333  vmovaps xmm12, [rsp+0xC0]
0000714ce89e133c  vmovaps xmm13, [rsp+0xD0]
0000714ce89e1345  vmovaps xmm14, [rsp+0xE0]
0000714ce89e134e  add rsp, 0xF0
0000714ce89e1355  pop r11
0000714ce89e1357  pop r10
0000714ce89e1359  pop r9
0000714ce89e135b  pop r8
0000714ce89e135d  pop rsi
0000714ce89e135e  pop rdi
0000714ce89e135f  pop rdx
0000714ce89e1360  pop rcx
0000714ce89e1361  pop rax
0000714ce89e1362  add rsp, 0x08
0000714ce89e1366  jmp 0x0000714CE89DF279
0000714ce89e136b  sub rsp, 0x08
0000714ce89e136f  push rax
0000714ce89e1370  push rcx
0000714ce89e1371  push rdx
0000714ce89e1372  push rdi
0000714ce89e1373  push rsi
0000714ce89e1374  push r8
0000714ce89e1376  push r9
0000714ce89e1378  push r10
0000714ce89e137a  push r11
0000714ce89e137c  sub rsp, 0xF0
0000714ce89e1383  vmovaps [rsp], xmm0
0000714ce89e1388  vmovaps [rsp+0x10], xmm2
0000714ce89e138e  vmovaps [rsp+0x20], xmm3
0000714ce89e1394  vmovaps [rsp+0x30], xmm4
0000714ce89e139a  vmovaps [rsp+0x40], xmm5
0000714ce89e13a0  vmovaps [rsp+0x50], xmm6
0000714ce89e13a6  vmovaps [rsp+0x60], xmm7
0000714ce89e13ac  vmovaps [rsp+0x70], xmm8
0000714ce89e13b2  vmovaps [rsp+0x80], xmm9
0000714ce89e13bb  vmovaps [rsp+0x90], xmm10
0000714ce89e13c4  vmovaps [rsp+0xA0], xmm11
0000714ce89e13cd  vmovaps [rsp+0xB0], xmm12
0000714ce89e13d6  vmovaps [rsp+0xC0], xmm13
0000714ce89e13df  vmovaps [rsp+0xD0], xmm14
0000714ce89e13e8  vmovaps [rsp+0xE0], xmm15
0000714ce89e13f1  sub rsp, 0x30
0000714ce89e13f5  movaps [rsp], xmm1
0000714ce89e13f9  movaps [rsp+0x10], xmm5
0000714ce89e13fe  movaps [rsp+0x20], xmm4
0000714ce89e1403  lea rdi, [rsp]
0000714ce89e1407  mov esi, 0x00
0000714ce89e140c  mov rax, 0x57A55D340530
0000714ce89e1416  call rax
0000714ce89e1418  movaps xmm1, [rsp]
0000714ce89e141c  add rsp, 0x30
0000714ce89e1420  vmovaps xmm0, [rsp]
0000714ce89e1425  vmovaps xmm2, [rsp+0x10]
0000714ce89e142b  vmovaps xmm3, [rsp+0x20]
0000714ce89e1431  vmovaps xmm4, [rsp+0x30]
0000714ce89e1437  vmovaps xmm5, [rsp+0x40]
0000714ce89e143d  vmovaps xmm6, [rsp+0x50]
0000714ce89e1443  vmovaps xmm7, [rsp+0x60]
0000714ce89e1449  vmovaps xmm8, [rsp+0x70]
0000714ce89e144f  vmovaps xmm9, [rsp+0x80]
0000714ce89e1458  vmovaps xmm10, [rsp+0x90]
0000714ce89e1461  vmovaps xmm11, [rsp+0xA0]
0000714ce89e146a  vmovaps xmm12, [rsp+0xB0]
0000714ce89e1473  vmovaps xmm13, [rsp+0xC0]
0000714ce89e147c  vmovaps xmm14, [rsp+0xD0]
0000714ce89e1485  vmovaps xmm15, [rsp+0xE0]
0000714ce89e148e  add rsp, 0xF0
0000714ce89e1495  pop r11
0000714ce89e1497  pop r10
0000714ce89e1499  pop r9
0000714ce89e149b  pop r8
0000714ce89e149d  pop rsi
0000714ce89e149e  pop rdi
0000714ce89e149f  pop rdx
0000714ce89e14a0  pop rcx
0000714ce89e14a1  pop rax
0000714ce89e14a2  add rsp, 0x08
0000714ce89e14a6  jmp 0x0000714CE89DF299
0000714ce89e14ab  sub rsp, 0x08
0000714ce89e14af  push rax
0000714ce89e14b0  push rcx
0000714ce89e14b1  push rdx
0000714ce89e14b2  push rdi
0000714ce89e14b3  push rsi
0000714ce89e14b4  push r8
0000714ce89e14b6  push r9
0000714ce89e14b8  push r10
0000714ce89e14ba  push r11
0000714ce89e14bc  sub rsp, 0xF0
0000714ce89e14c3  vmovaps [rsp], xmm0
0000714ce89e14c8  vmovaps [rsp+0x10], xmm1
0000714ce89e14ce  vmovaps [rsp+0x20], xmm2
0000714ce89e14d4  vmovaps [rsp+0x30], xmm3
0000714ce89e14da  vmovaps [rsp+0x40], xmm5
0000714ce89e14e0  vmovaps [rsp+0x50], xmm6
0000714ce89e14e6  vmovaps [rsp+0x60], xmm7
0000714ce89e14ec  vmovaps [rsp+0x70], xmm8
0000714ce89e14f2  vmovaps [rsp+0x80], xmm9
0000714ce89e14fb  vmovaps [rsp+0x90], xmm10
0000714ce89e1504  vmovaps [rsp+0xA0], xmm11
0000714ce89e150d  vmovaps [rsp+0xB0], xmm12
0000714ce89e1516  vmovaps [rsp+0xC0], xmm13
0000714ce89e151f  vmovaps [rsp+0xD0], xmm14
0000714ce89e1528  vmovaps [rsp+0xE0], xmm15
0000714ce89e1531  sub rsp, 0x30
0000714ce89e1535  movaps [rsp], xmm4
0000714ce89e1539  movaps [rsp+0x10], xmm3
0000714ce89e153e  movaps [rsp+0x20], xmm5
0000714ce89e1543  lea rdi, [rsp]
0000714ce89e1547  mov esi, 0x00
0000714ce89e154c  mov rax, 0x57A55D340530
0000714ce89e1556  call rax
0000714ce89e1558  movaps xmm4, [rsp]
0000714ce89e155c  add rsp, 0x30
0000714ce89e1560  vmovaps xmm0, [rsp]
0000714ce89e1565  vmovaps xmm1, [rsp+0x10]
0000714ce89e156b  vmovaps xmm2, [rsp+0x20]
0000714ce89e1571  vmovaps xmm3, [rsp+0x30]
0000714ce89e1577  vmovaps xmm5, [rsp+0x40]
0000714ce89e157d  vmovaps xmm6, [rsp+0x50]
0000714ce89e1583  vmovaps xmm7, [rsp+0x60]
0000714ce89e1589  vmovaps xmm8, [rsp+0x70]
0000714ce89e158f  vmovaps xmm9, [rsp+0x80]
0000714ce89e1598  vmovaps xmm10, [rsp+0x90]
0000714ce89e15a1  vmovaps xmm11, [rsp+0xA0]
0000714ce89e15aa  vmovaps xmm12, [rsp+0xB0]
0000714ce89e15b3  vmovaps xmm13, [rsp+0xC0]
0000714ce89e15bc  vmovaps xmm14, [rsp+0xD0]
0000714ce89e15c5  vmovaps xmm15, [rsp+0xE0]
0000714ce89e15ce  add rsp, 0xF0
0000714ce89e15d5  pop r11
0000714ce89e15d7  pop r10
0000714ce89e15d9  pop r9
0000714ce89e15db  pop r8
0000714ce89e15dd  pop rsi
0000714ce89e15de  pop rdi
0000714ce89e15df  pop rdx
0000714ce89e15e0  pop rcx
0000714ce89e15e1  pop rax
0000714ce89e15e2  add rsp, 0x08
0000714ce89e15e6  jmp 0x0000714CE89DF2E7
0000714ce89e15eb  call 0x0000714CE88B52F0
0000714ce89e15f0  jmp 0x0000714CE89DF2F4
0000714ce89e15f5  sub rsp, 0x08
0000714ce89e15f9  push rax
0000714ce89e15fa  push rcx
0000714ce89e15fb  push rdx
0000714ce89e15fc  push rdi
0000714ce89e15fd  push rsi
0000714ce89e15fe  push r8
0000714ce89e1600  push r9
0000714ce89e1602  push r10
0000714ce89e1604  push r11
0000714ce89e1606  sub rsp, 0xF0
0000714ce89e160d  vmovaps [rsp], xmm0
0000714ce89e1612  vmovaps [rsp+0x10], xmm1
0000714ce89e1618  vmovaps [rsp+0x20], xmm2
0000714ce89e161e  vmovaps [rsp+0x30], xmm3
0000714ce89e1624  vmovaps [rsp+0x40], xmm4
0000714ce89e162a  vmovaps [rsp+0x50], xmm6
0000714ce89e1630  vmovaps [rsp+0x60], xmm7
0000714ce89e1636  vmovaps [rsp+0x70], xmm8
0000714ce89e163c  vmovaps [rsp+0x80], xmm9
0000714ce89e1645  vmovaps [rsp+0x90], xmm10
0000714ce89e164e  vmovaps [rsp+0xA0], xmm11
0000714ce89e1657  vmovaps [rsp+0xB0], xmm12
0000714ce89e1660  vmovaps [rsp+0xC0], xmm13
0000714ce89e1669  vmovaps [rsp+0xD0], xmm14
0000714ce89e1672  vmovaps [rsp+0xE0], xmm15
0000714ce89e167b  sub rsp, 0x30
0000714ce89e167f  movaps [rsp], xmm5
0000714ce89e1683  movaps [rsp+0x10], xmm6
0000714ce89e1688  movaps [rsp+0x20], xmm3
0000714ce89e168d  lea rdi, [rsp]
0000714ce89e1691  mov esi, 0x00
0000714ce89e1696  mov rax, 0x57A55D340530
0000714ce89e16a0  call rax
0000714ce89e16a2  movaps xmm5, [rsp]
0000714ce89e16a6  add rsp, 0x30
0000714ce89e16aa  vmovaps xmm0, [rsp]
0000714ce89e16af  vmovaps xmm1, [rsp+0x10]
0000714ce89e16b5  vmovaps xmm2, [rsp+0x20]
0000714ce89e16bb  vmovaps xmm3, [rsp+0x30]
0000714ce89e16c1  vmovaps xmm4, [rsp+0x40]
0000714ce89e16c7  vmovaps xmm6, [rsp+0x50]
0000714ce89e16cd  vmovaps xmm7, [rsp+0x60]
0000714ce89e16d3  vmovaps xmm8, [rsp+0x70]
0000714ce89e16d9  vmovaps xmm9, [rsp+0x80]
0000714ce89e16e2  vmovaps xmm10, [rsp+0x90]
0000714ce89e16eb  vmovaps xmm11, [rsp+0xA0]
0000714ce89e16f4  vmovaps xmm12, [rsp+0xB0]
0000714ce89e16fd  vmovaps xmm13, [rsp+0xC0]
0000714ce89e1706  vmovaps xmm14, [rsp+0xD0]
0000714ce89e170f  vmovaps xmm15, [rsp+0xE0]
0000714ce89e1718  add rsp, 0xF0
0000714ce89e171f  pop r11
0000714ce89e1721  pop r10
0000714ce89e1723  pop r9
0000714ce89e1725  pop r8
0000714ce89e1727  pop rsi
0000714ce89e1728  pop rdi
0000714ce89e1729  pop rdx
0000714ce89e172a  pop rcx
0000714ce89e172b  pop rax
0000714ce89e172c  add rsp, 0x08
0000714ce89e1730  jmp 0x0000714CE89DF31A
0000714ce89e1735  sub rsp, 0x08
0000714ce89e1739  push rax
0000714ce89e173a  push rcx
0000714ce89e173b  push rdx
0000714ce89e173c  push rdi
0000714ce89e173d  push rsi
0000714ce89e173e  push r8
0000714ce89e1740  push r9
0000714ce89e1742  push r10
0000714ce89e1744  push r11
0000714ce89e1746  sub rsp, 0xF0
0000714ce89e174d  vmovaps [rsp], xmm0
0000714ce89e1752  vmovaps [rsp+0x10], xmm1
0000714ce89e1758  vmovaps [rsp+0x20], xmm2
0000714ce89e175e  vmovaps [rsp+0x30], xmm3
0000714ce89e1764  vmovaps [rsp+0x40], xmm4
0000714ce89e176a  vmovaps [rsp+0x50], xmm5
0000714ce89e1770  vmovaps [rsp+0x60], xmm7
0000714ce89e1776  vmovaps [rsp+0x70], xmm8
0000714ce89e177c  vmovaps [rsp+0x80], xmm9
0000714ce89e1785  vmovaps [rsp+0x90], xmm10
0000714ce89e178e  vmovaps [rsp+0xA0], xmm11
0000714ce89e1797  vmovaps [rsp+0xB0], xmm12
0000714ce89e17a0  vmovaps [rsp+0xC0], xmm13
0000714ce89e17a9  vmovaps [rsp+0xD0], xmm14
0000714ce89e17b2  vmovaps [rsp+0xE0], xmm15
0000714ce89e17bb  sub rsp, 0x30
0000714ce89e17bf  movaps [rsp], xmm6
0000714ce89e17c3  movaps [rsp+0x10], xmm9
0000714ce89e17c9  movaps [rsp+0x20], xmm1
0000714ce89e17ce  lea rdi, [rsp]
0000714ce89e17d2  mov esi, 0x00
0000714ce89e17d7  mov rax, 0x57A55D340530
0000714ce89e17e1  call rax
0000714ce89e17e3  movaps xmm6, [rsp]
0000714ce89e17e7  add rsp, 0x30
0000714ce89e17eb  vmovaps xmm0, [rsp]
0000714ce89e17f0  vmovaps xmm1, [rsp+0x10]
0000714ce89e17f6  vmovaps xmm2, [rsp+0x20]
0000714ce89e17fc  vmovaps xmm3, [rsp+0x30]
0000714ce89e1802  vmovaps xmm4, [rsp+0x40]
0000714ce89e1808  vmovaps xmm5, [rsp+0x50]
0000714ce89e180e  vmovaps xmm7, [rsp+0x60]
0000714ce89e1814  vmovaps xmm8, [rsp+0x70]
0000714ce89e181a  vmovaps xmm9, [rsp+0x80]
0000714ce89e1823  vmovaps xmm10, [rsp+0x90]
0000714ce89e182c  vmovaps xmm11, [rsp+0xA0]
0000714ce89e1835  vmovaps xmm12, [rsp+0xB0]
0000714ce89e183e  vmovaps xmm13, [rsp+0xC0]
0000714ce89e1847  vmovaps xmm14, [rsp+0xD0]
0000714ce89e1850  vmovaps xmm15, [rsp+0xE0]
0000714ce89e1859  add rsp, 0xF0
0000714ce89e1860  pop r11
0000714ce89e1862  pop r10
0000714ce89e1864  pop r9
0000714ce89e1866  pop r8
0000714ce89e1868  pop rsi
0000714ce89e1869  pop rdi
0000714ce89e186a  pop rdx
0000714ce89e186b  pop rcx
0000714ce89e186c  pop rax
0000714ce89e186d  add rsp, 0x08
0000714ce89e1871  jmp 0x0000714CE89DF33E
0000714ce89e1876  sub rsp, 0x08
0000714ce89e187a  push rax
0000714ce89e187b  push rcx
0000714ce89e187c  push rdx
0000714ce89e187d  push rdi
0000714ce89e187e  push rsi
0000714ce89e187f  push r8
0000714ce89e1881  push r9
0000714ce89e1883  push r10
0000714ce89e1885  push r11
0000714ce89e1887  sub rsp, 0xF0
0000714ce89e188e  vmovaps [rsp], xmm0
0000714ce89e1893  vmovaps [rsp+0x10], xmm1
0000714ce89e1899  vmovaps [rsp+0x20], xmm2
0000714ce89e189f  vmovaps [rsp+0x30], xmm3
0000714ce89e18a5  vmovaps [rsp+0x40], xmm4
0000714ce89e18ab  vmovaps [rsp+0x50], xmm5
0000714ce89e18b1  vmovaps [rsp+0x60], xmm6
0000714ce89e18b7  vmovaps [rsp+0x70], xmm7
0000714ce89e18bd  vmovaps [rsp+0x80], xmm8
0000714ce89e18c6  vmovaps [rsp+0x90], xmm10
0000714ce89e18cf  vmovaps [rsp+0xA0], xmm11
0000714ce89e18d8  vmovaps [rsp+0xB0], xmm12
0000714ce89e18e1  vmovaps [rsp+0xC0], xmm13
0000714ce89e18ea  vmovaps [rsp+0xD0], xmm14
0000714ce89e18f3  vmovaps [rsp+0xE0], xmm15
0000714ce89e18fc  sub rsp, 0x30
0000714ce89e1900  movaps [rsp], xmm9
0000714ce89e1905  movaps [rsp+0x10], xmm3
0000714ce89e190a  movaps [rsp+0x20], xmm1
0000714ce89e190f  lea rdi, [rsp]
0000714ce89e1913  mov esi, 0x00
0000714ce89e1918  mov rax, 0x57A55D340530
0000714ce89e1922  call rax
0000714ce89e1924  movaps xmm9, [rsp]
0000714ce89e1929  add rsp, 0x30
0000714ce89e192d  vmovaps xmm0, [rsp]
0000714ce89e1932  vmovaps xmm1, [rsp+0x10]
0000714ce89e1938  vmovaps xmm2, [rsp+0x20]
0000714ce89e193e  vmovaps xmm3, [rsp+0x30]
0000714ce89e1944  vmovaps xmm4, [rsp+0x40]
0000714ce89e194a  vmovaps xmm5, [rsp+0x50]
0000714ce89e1950  vmovaps xmm6, [rsp+0x60]
0000714ce89e1956  vmovaps xmm7, [rsp+0x70]
0000714ce89e195c  vmovaps xmm8, [rsp+0x80]
0000714ce89e1965  vmovaps xmm10, [rsp+0x90]
0000714ce89e196e  vmovaps xmm11, [rsp+0xA0]
0000714ce89e1977  vmovaps xmm12, [rsp+0xB0]
0000714ce89e1980  vmovaps xmm13, [rsp+0xC0]
0000714ce89e1989  vmovaps xmm14, [rsp+0xD0]
0000714ce89e1992  vmovaps xmm15, [rsp+0xE0]
0000714ce89e199b  add rsp, 0xF0
0000714ce89e19a2  pop r11
0000714ce89e19a4  pop r10
0000714ce89e19a6  pop r9
0000714ce89e19a8  pop r8
0000714ce89e19aa  pop rsi
0000714ce89e19ab  pop rdi
0000714ce89e19ac  pop rdx
0000714ce89e19ad  pop rcx
0000714ce89e19ae  pop rax
0000714ce89e19af  add rsp, 0x08
0000714ce89e19b3  jmp 0x0000714CE89DF38A
0000714ce89e19b8  call 0x0000714CE88B52F0
0000714ce89e19bd  jmp 0x0000714CE89DF397
0000714ce89e19c2  sub rsp, 0x08
0000714ce89e19c6  push rax
0000714ce89e19c7  push rcx
0000714ce89e19c8  push rdx
0000714ce89e19c9  push rdi
0000714ce89e19ca  push rsi
0000714ce89e19cb  push r8
0000714ce89e19cd  push r9
0000714ce89e19cf  push r10
0000714ce89e19d1  push r11
0000714ce89e19d3  sub rsp, 0xF0
0000714ce89e19da  vmovaps [rsp], xmm0
0000714ce89e19df  vmovaps [rsp+0x10], xmm1
0000714ce89e19e5  vmovaps [rsp+0x20], xmm2
0000714ce89e19eb  vmovaps [rsp+0x30], xmm3
0000714ce89e19f1  vmovaps [rsp+0x40], xmm4
0000714ce89e19f7  vmovaps [rsp+0x50], xmm5
0000714ce89e19fd  vmovaps [rsp+0x60], xmm6
0000714ce89e1a03  vmovaps [rsp+0x70], xmm7
0000714ce89e1a09  vmovaps [rsp+0x80], xmm8
0000714ce89e1a12  vmovaps [rsp+0x90], xmm9
0000714ce89e1a1b  vmovaps [rsp+0xA0], xmm10
0000714ce89e1a24  vmovaps [rsp+0xB0], xmm11
0000714ce89e1a2d  vmovaps [rsp+0xC0], xmm12
0000714ce89e1a36  vmovaps [rsp+0xD0], xmm13
0000714ce89e1a3f  vmovaps [rsp+0xE0], xmm14
0000714ce89e1a48  sub rsp, 0x30
0000714ce89e1a4c  movaps [rsp], xmm15
0000714ce89e1a51  movaps [rsp+0x10], xmm3
0000714ce89e1a56  movaps [rsp+0x20], xmm7
0000714ce89e1a5b  lea rdi, [rsp]
0000714ce89e1a5f  mov esi, 0x00
0000714ce89e1a64  mov rax, 0x57A55D340530
0000714ce89e1a6e  call rax
0000714ce89e1a70  movaps xmm15, [rsp]
0000714ce89e1a75  add rsp, 0x30
0000714ce89e1a79  vmovaps xmm0, [rsp]
0000714ce89e1a7e  vmovaps xmm1, [rsp+0x10]
0000714ce89e1a84  vmovaps xmm2, [rsp+0x20]
0000714ce89e1a8a  vmovaps xmm3, [rsp+0x30]
0000714ce89e1a90  vmovaps xmm4, [rsp+0x40]
0000714ce89e1a96  vmovaps xmm5, [rsp+0x50]
0000714ce89e1a9c  vmovaps xmm6, [rsp+0x60]
0000714ce89e1aa2  vmovaps xmm7, [rsp+0x70]
0000714ce89e1aa8  vmovaps xmm8, [rsp+0x80]
0000714ce89e1ab1  vmovaps xmm9, [rsp+0x90]
0000714ce89e1aba  vmovaps xmm10, [rsp+0xA0]
0000714ce89e1ac3  vmovaps xmm11, [rsp+0xB0]
0000714ce89e1acc  vmovaps xmm12, [rsp+0xC0]
0000714ce89e1ad5  vmovaps xmm13, [rsp+0xD0]
0000714ce89e1ade  vmovaps xmm14, [rsp+0xE0]
0000714ce89e1ae7  add rsp, 0xF0
0000714ce89e1aee  pop r11
0000714ce89e1af0  pop r10
0000714ce89e1af2  pop r9
0000714ce89e1af4  pop r8
0000714ce89e1af6  pop rsi
0000714ce89e1af7  pop rdi
0000714ce89e1af8  pop rdx
0000714ce89e1af9  pop rcx
0000714ce89e1afa  pop rax
0000714ce89e1afb  add rsp, 0x08
0000714ce89e1aff  jmp 0x0000714CE89DF3C3
0000714ce89e1b04  sub rsp, 0x08
0000714ce89e1b08  push rax
0000714ce89e1b09  push rcx
0000714ce89e1b0a  push rdx
0000714ce89e1b0b  push rdi
0000714ce89e1b0c  push rsi
0000714ce89e1b0d  push r8
0000714ce89e1b0f  push r9
0000714ce89e1b11  push r10
0000714ce89e1b13  push r11
0000714ce89e1b15  sub rsp, 0xF0
0000714ce89e1b1c  vmovaps [rsp], xmm0
0000714ce89e1b21  vmovaps [rsp+0x10], xmm1
0000714ce89e1b27  vmovaps [rsp+0x20], xmm2
0000714ce89e1b2d  vmovaps [rsp+0x30], xmm4
0000714ce89e1b33  vmovaps [rsp+0x40], xmm5
0000714ce89e1b39  vmovaps [rsp+0x50], xmm6
0000714ce89e1b3f  vmovaps [rsp+0x60], xmm7
0000714ce89e1b45  vmovaps [rsp+0x70], xmm8
0000714ce89e1b4b  vmovaps [rsp+0x80], xmm9
0000714ce89e1b54  vmovaps [rsp+0x90], xmm10
0000714ce89e1b5d  vmovaps [rsp+0xA0], xmm11
0000714ce89e1b66  vmovaps [rsp+0xB0], xmm12
0000714ce89e1b6f  vmovaps [rsp+0xC0], xmm13
0000714ce89e1b78  vmovaps [rsp+0xD0], xmm14
0000714ce89e1b81  vmovaps [rsp+0xE0], xmm15
0000714ce89e1b8a  sub rsp, 0x30
0000714ce89e1b8e  movaps [rsp], xmm3
0000714ce89e1b92  movaps [rsp+0x10], xmm1
0000714ce89e1b97  movaps [rsp+0x20], xmm15
0000714ce89e1b9d  lea rdi, [rsp]
0000714ce89e1ba1  mov esi, 0x00
0000714ce89e1ba6  mov rax, 0x57A55D340530
0000714ce89e1bb0  call rax
0000714ce89e1bb2  movaps xmm3, [rsp]
0000714ce89e1bb6  add rsp, 0x30
0000714ce89e1bba  vmovaps xmm0, [rsp]
0000714ce89e1bbf  vmovaps xmm1, [rsp+0x10]
0000714ce89e1bc5  vmovaps xmm2, [rsp+0x20]
0000714ce89e1bcb  vmovaps xmm4, [rsp+0x30]
0000714ce89e1bd1  vmovaps xmm5, [rsp+0x40]
0000714ce89e1bd7  vmovaps xmm6, [rsp+0x50]
0000714ce89e1bdd  vmovaps xmm7, [rsp+0x60]
0000714ce89e1be3  vmovaps xmm8, [rsp+0x70]
0000714ce89e1be9  vmovaps xmm9, [rsp+0x80]
0000714ce89e1bf2  vmovaps xmm10, [rsp+0x90]
0000714ce89e1bfb  vmovaps xmm11, [rsp+0xA0]
0000714ce89e1c04  vmovaps xmm12, [rsp+0xB0]
0000714ce89e1c0d  vmovaps xmm13, [rsp+0xC0]
0000714ce89e1c16  vmovaps xmm14, [rsp+0xD0]
0000714ce89e1c1f  vmovaps xmm15, [rsp+0xE0]
0000714ce89e1c28  add rsp, 0xF0
0000714ce89e1c2f  pop r11
0000714ce89e1c31  pop r10
0000714ce89e1c33  pop r9
0000714ce89e1c35  pop r8
0000714ce89e1c37  pop rsi
0000714ce89e1c38  pop rdi
0000714ce89e1c39  pop rdx
0000714ce89e1c3a  pop rcx
0000714ce89e1c3b  pop rax
0000714ce89e1c3c  add rsp, 0x08
0000714ce89e1c40  jmp 0x0000714CE89DF452
0000714ce89e1c45  call 0x0000714CE88B52F0
0000714ce89e1c4a  jmp 0x0000714CE89DF45C
0000714ce89e1c4f  sub rsp, 0x08
0000714ce89e1c53  push rax
0000714ce89e1c54  push rcx
0000714ce89e1c55  push rdx
0000714ce89e1c56  push rdi
0000714ce89e1c57  push rsi
0000714ce89e1c58  push r8
0000714ce89e1c5a  push r9
0000714ce89e1c5c  push r10
0000714ce89e1c5e  push r11
0000714ce89e1c60  sub rsp, 0xF0
0000714ce89e1c67  vmovaps [rsp], xmm0
0000714ce89e1c6c  vmovaps [rsp+0x10], xmm1
0000714ce89e1c72  vmovaps [rsp+0x20], xmm2
0000714ce89e1c78  vmovaps [rsp+0x30], xmm3
0000714ce89e1c7e  vmovaps [rsp+0x40], xmm4
0000714ce89e1c84  vmovaps [rsp+0x50], xmm5
0000714ce89e1c8a  vmovaps [rsp+0x60], xmm6
0000714ce89e1c90  vmovaps [rsp+0x70], xmm7
0000714ce89e1c96  vmovaps [rsp+0x80], xmm8
0000714ce89e1c9f  vmovaps [rsp+0x90], xmm9
0000714ce89e1ca8  vmovaps [rsp+0xA0], xmm10
0000714ce89e1cb1  vmovaps [rsp+0xB0], xmm11
0000714ce89e1cba  vmovaps [rsp+0xC0], xmm12
0000714ce89e1cc3  vmovaps [rsp+0xD0], xmm13
0000714ce89e1ccc  vmovaps [rsp+0xE0], xmm14
0000714ce89e1cd5  sub rsp, 0x30
0000714ce89e1cd9  movaps [rsp], xmm15
0000714ce89e1cde  movaps [rsp+0x10], xmm14
0000714ce89e1ce4  movaps [rsp+0x20], xmm4
0000714ce89e1ce9  lea rdi, [rsp]
0000714ce89e1ced  mov esi, 0x00
0000714ce89e1cf2  mov rax, 0x57A55D340530
0000714ce89e1cfc  call rax
0000714ce89e1cfe  movaps xmm15, [rsp]
0000714ce89e1d03  add rsp, 0x30
0000714ce89e1d07  vmovaps xmm0, [rsp]
0000714ce89e1d0c  vmovaps xmm1, [rsp+0x10]
0000714ce89e1d12  vmovaps xmm2, [rsp+0x20]
0000714ce89e1d18  vmovaps xmm3, [rsp+0x30]
0000714ce89e1d1e  vmovaps xmm4, [rsp+0x40]
0000714ce89e1d24  vmovaps xmm5, [rsp+0x50]
0000714ce89e1d2a  vmovaps xmm6, [rsp+0x60]
0000714ce89e1d30  vmovaps xmm7, [rsp+0x70]
0000714ce89e1d36  vmovaps xmm8, [rsp+0x80]
0000714ce89e1d3f  vmovaps xmm9, [rsp+0x90]
0000714ce89e1d48  vmovaps xmm10, [rsp+0xA0]
0000714ce89e1d51  vmovaps xmm11, [rsp+0xB0]
0000714ce89e1d5a  vmovaps xmm12, [rsp+0xC0]
0000714ce89e1d63  vmovaps xmm13, [rsp+0xD0]
0000714ce89e1d6c  vmovaps xmm14, [rsp+0xE0]
0000714ce89e1d75  add rsp, 0xF0
0000714ce89e1d7c  pop r11
0000714ce89e1d7e  pop r10
0000714ce89e1d80  pop r9
0000714ce89e1d82  pop r8
0000714ce89e1d84  pop rsi
0000714ce89e1d85  pop rdi
0000714ce89e1d86  pop rdx
0000714ce89e1d87  pop rcx
0000714ce89e1d88  pop rax
0000714ce89e1d89  add rsp, 0x08
0000714ce89e1d8d  jmp 0x0000714CE89DF48A
0000714ce89e1d92  sub rsp, 0x08
0000714ce89e1d96  push rax
0000714ce89e1d97  push rcx
0000714ce89e1d98  push rdx
0000714ce89e1d99  push rdi
0000714ce89e1d9a  push rsi
0000714ce89e1d9b  push r8
0000714ce89e1d9d  push r9
0000714ce89e1d9f  push r10
0000714ce89e1da1  push r11
0000714ce89e1da3  sub rsp, 0xF0
0000714ce89e1daa  vmovaps [rsp], xmm0
0000714ce89e1daf  vmovaps [rsp+0x10], xmm1
0000714ce89e1db5  vmovaps [rsp+0x20], xmm2
0000714ce89e1dbb  vmovaps [rsp+0x30], xmm3
0000714ce89e1dc1  vmovaps [rsp+0x40], xmm4
0000714ce89e1dc7  vmovaps [rsp+0x50], xmm5
0000714ce89e1dcd  vmovaps [rsp+0x60], xmm6
0000714ce89e1dd3  vmovaps [rsp+0x70], xmm7
0000714ce89e1dd9  vmovaps [rsp+0x80], xmm8
0000714ce89e1de2  vmovaps [rsp+0x90], xmm9
0000714ce89e1deb  vmovaps [rsp+0xA0], xmm10
0000714ce89e1df4  vmovaps [rsp+0xB0], xmm11
0000714ce89e1dfd  vmovaps [rsp+0xC0], xmm12
0000714ce89e1e06  vmovaps [rsp+0xD0], xmm13
0000714ce89e1e0f  vmovaps [rsp+0xE0], xmm15
0000714ce89e1e18  sub rsp, 0x30
0000714ce89e1e1c  movaps [rsp], xmm14
0000714ce89e1e21  movaps [rsp+0x10], xmm2
0000714ce89e1e26  movaps [rsp+0x20], xmm1
0000714ce89e1e2b  lea rdi, [rsp]
0000714ce89e1e2f  mov esi, 0x00
0000714ce89e1e34  mov rax, 0x57A55D340530
0000714ce89e1e3e  call rax
0000714ce89e1e40  movaps xmm14, [rsp]
0000714ce89e1e45  add rsp, 0x30
0000714ce89e1e49  vmovaps xmm0, [rsp]
0000714ce89e1e4e  vmovaps xmm1, [rsp+0x10]
0000714ce89e1e54  vmovaps xmm2, [rsp+0x20]
0000714ce89e1e5a  vmovaps xmm3, [rsp+0x30]
0000714ce89e1e60  vmovaps xmm4, [rsp+0x40]
0000714ce89e1e66  vmovaps xmm5, [rsp+0x50]
0000714ce89e1e6c  vmovaps xmm6, [rsp+0x60]
0000714ce89e1e72  vmovaps xmm7, [rsp+0x70]
0000714ce89e1e78  vmovaps xmm8, [rsp+0x80]
0000714ce89e1e81  vmovaps xmm9, [rsp+0x90]
0000714ce89e1e8a  vmovaps xmm10, [rsp+0xA0]
0000714ce89e1e93  vmovaps xmm11, [rsp+0xB0]
0000714ce89e1e9c  vmovaps xmm12, [rsp+0xC0]
0000714ce89e1ea5  vmovaps xmm13, [rsp+0xD0]
0000714ce89e1eae  vmovaps xmm15, [rsp+0xE0]
0000714ce89e1eb7  add rsp, 0xF0
0000714ce89e1ebe  pop r11
0000714ce89e1ec0  pop r10
0000714ce89e1ec2  pop r9
0000714ce89e1ec4  pop r8
0000714ce89e1ec6  pop rsi
0000714ce89e1ec7  pop rdi
0000714ce89e1ec8  pop rdx
0000714ce89e1ec9  pop rcx
0000714ce89e1eca  pop rax
0000714ce89e1ecb  add rsp, 0x08
0000714ce89e1ecf  jmp 0x0000714CE89DF4B0
0000714ce89e1ed4  sub rsp, 0x08
0000714ce89e1ed8  push rax
0000714ce89e1ed9  push rcx
0000714ce89e1eda  push rdx
0000714ce89e1edb  push rdi
0000714ce89e1edc  push rsi
0000714ce89e1edd  push r8
0000714ce89e1edf  push r9
0000714ce89e1ee1  push r10
0000714ce89e1ee3  push r11
0000714ce89e1ee5  sub rsp, 0xF0
0000714ce89e1eec  vmovaps [rsp], xmm0
0000714ce89e1ef1  vmovaps [rsp+0x10], xmm2
0000714ce89e1ef7  vmovaps [rsp+0x20], xmm3
0000714ce89e1efd  vmovaps [rsp+0x30], xmm4
0000714ce89e1f03  vmovaps [rsp+0x40], xmm5
0000714ce89e1f09  vmovaps [rsp+0x50], xmm6
0000714ce89e1f0f  vmovaps [rsp+0x60], xmm7
0000714ce89e1f15  vmovaps [rsp+0x70], xmm8
0000714ce89e1f1b  vmovaps [rsp+0x80], xmm9
0000714ce89e1f24  vmovaps [rsp+0x90], xmm10
0000714ce89e1f2d  vmovaps [rsp+0xA0], xmm11
0000714ce89e1f36  vmovaps [rsp+0xB0], xmm12
0000714ce89e1f3f  vmovaps [rsp+0xC0], xmm13
0000714ce89e1f48  vmovaps [rsp+0xD0], xmm14
0000714ce89e1f51  vmovaps [rsp+0xE0], xmm15
0000714ce89e1f5a  sub rsp, 0x30
0000714ce89e1f5e  movaps [rsp], xmm1
0000714ce89e1f62  movaps [rsp+0x10], xmm4
0000714ce89e1f67  movaps [rsp+0x20], xmm9
0000714ce89e1f6d  lea rdi, [rsp]
0000714ce89e1f71  mov esi, 0x00
0000714ce89e1f76  mov rax, 0x57A55D340530
0000714ce89e1f80  call rax
0000714ce89e1f82  movaps xmm1, [rsp]
0000714ce89e1f86  add rsp, 0x30
0000714ce89e1f8a  vmovaps xmm0, [rsp]
0000714ce89e1f8f  vmovaps xmm2, [rsp+0x10]
0000714ce89e1f95  vmovaps xmm3, [rsp+0x20]
0000714ce89e1f9b  vmovaps xmm4, [rsp+0x30]
0000714ce89e1fa1  vmovaps xmm5, [rsp+0x40]
0000714ce89e1fa7  vmovaps xmm6, [rsp+0x50]
0000714ce89e1fad  vmovaps xmm7, [rsp+0x60]
0000714ce89e1fb3  vmovaps xmm8, [rsp+0x70]
0000714ce89e1fb9  vmovaps xmm9, [rsp+0x80]
0000714ce89e1fc2  vmovaps xmm10, [rsp+0x90]
0000714ce89e1fcb  vmovaps xmm11, [rsp+0xA0]
0000714ce89e1fd4  vmovaps xmm12, [rsp+0xB0]
0000714ce89e1fdd  vmovaps xmm13, [rsp+0xC0]
0000714ce89e1fe6  vmovaps xmm14, [rsp+0xD0]
0000714ce89e1fef  vmovaps xmm15, [rsp+0xE0]
0000714ce89e1ff8  add rsp, 0xF0
0000714ce89e1fff  pop r11
0000714ce89e2001  pop r10
0000714ce89e2003  pop r9
0000714ce89e2005  pop r8
0000714ce89e2007  pop rsi
0000714ce89e2008  pop rdi
0000714ce89e2009  pop rdx
0000714ce89e200a  pop rcx
0000714ce89e200b  pop rax
0000714ce89e200c  add rsp, 0x08
0000714ce89e2010  jmp 0x0000714CE89DF4CE
0000714ce89e2015  sub rsp, 0x08
0000714ce89e2019  push rax
0000714ce89e201a  push rcx
0000714ce89e201b  push rdx
0000714ce89e201c  push rdi
0000714ce89e201d  push rsi
0000714ce89e201e  push r8
0000714ce89e2020  push r9
0000714ce89e2022  push r10
0000714ce89e2024  push r11
0000714ce89e2026  sub rsp, 0xF0
0000714ce89e202d  vmovaps [rsp], xmm0
0000714ce89e2032  vmovaps [rsp+0x10], xmm1
0000714ce89e2038  vmovaps [rsp+0x20], xmm2
0000714ce89e203e  vmovaps [rsp+0x30], xmm3
0000714ce89e2044  vmovaps [rsp+0x40], xmm5
0000714ce89e204a  vmovaps [rsp+0x50], xmm6
0000714ce89e2050  vmovaps [rsp+0x60], xmm7
0000714ce89e2056  vmovaps [rsp+0x70], xmm8
0000714ce89e205c  vmovaps [rsp+0x80], xmm9
0000714ce89e2065  vmovaps [rsp+0x90], xmm10
0000714ce89e206e  vmovaps [rsp+0xA0], xmm11
0000714ce89e2077  vmovaps [rsp+0xB0], xmm12
0000714ce89e2080  vmovaps [rsp+0xC0], xmm13
0000714ce89e2089  vmovaps [rsp+0xD0], xmm14
0000714ce89e2092  vmovaps [rsp+0xE0], xmm15
0000714ce89e209b  sub rsp, 0x30
0000714ce89e209f  movaps [rsp], xmm4
0000714ce89e20a3  movaps [rsp+0x10], xmm2
0000714ce89e20a8  movaps [rsp+0x20], xmm9
0000714ce89e20ae  lea rdi, [rsp]
0000714ce89e20b2  mov esi, 0x00
0000714ce89e20b7  mov rax, 0x57A55D340530
0000714ce89e20c1  call rax
0000714ce89e20c3  movaps xmm4, [rsp]
0000714ce89e20c7  add rsp, 0x30
0000714ce89e20cb  vmovaps xmm0, [rsp]
0000714ce89e20d0  vmovaps xmm1, [rsp+0x10]
0000714ce89e20d6  vmovaps xmm2, [rsp+0x20]
0000714ce89e20dc  vmovaps xmm3, [rsp+0x30]
0000714ce89e20e2  vmovaps xmm5, [rsp+0x40]
0000714ce89e20e8  vmovaps xmm6, [rsp+0x50]
0000714ce89e20ee  vmovaps xmm7, [rsp+0x60]
0000714ce89e20f4  vmovaps xmm8, [rsp+0x70]
0000714ce89e20fa  vmovaps xmm9, [rsp+0x80]
0000714ce89e2103  vmovaps xmm10, [rsp+0x90]
0000714ce89e210c  vmovaps xmm11, [rsp+0xA0]
0000714ce89e2115  vmovaps xmm12, [rsp+0xB0]
0000714ce89e211e  vmovaps xmm13, [rsp+0xC0]
0000714ce89e2127  vmovaps xmm14, [rsp+0xD0]
0000714ce89e2130  vmovaps xmm15, [rsp+0xE0]
0000714ce89e2139  add rsp, 0xF0
0000714ce89e2140  pop r11
0000714ce89e2142  pop r10
0000714ce89e2144  pop r9
0000714ce89e2146  pop r8
0000714ce89e2148  pop rsi
0000714ce89e2149  pop rdi
0000714ce89e214a  pop rdx
0000714ce89e214b  pop rcx
0000714ce89e214c  pop rax
0000714ce89e214d  add rsp, 0x08
0000714ce89e2151  jmp 0x0000714CE89DF4FE
0000714ce89e2156  sub rsp, 0x08
0000714ce89e215a  push rax
0000714ce89e215b  push rcx
0000714ce89e215c  push rdx
0000714ce89e215d  push rdi
0000714ce89e215e  push rsi
0000714ce89e215f  push r8
0000714ce89e2161  push r9
0000714ce89e2163  push r10
0000714ce89e2165  push r11
0000714ce89e2167  sub rsp, 0xF0
0000714ce89e216e  vmovaps [rsp], xmm0
0000714ce89e2173  vmovaps [rsp+0x10], xmm1
0000714ce89e2179  vmovaps [rsp+0x20], xmm2
0000714ce89e217f  vmovaps [rsp+0x30], xmm3
0000714ce89e2185  vmovaps [rsp+0x40], xmm4
0000714ce89e218b  vmovaps [rsp+0x50], xmm5
0000714ce89e2191  vmovaps [rsp+0x60], xmm6
0000714ce89e2197  vmovaps [rsp+0x70], xmm7
0000714ce89e219d  vmovaps [rsp+0x80], xmm8
0000714ce89e21a6  vmovaps [rsp+0x90], xmm10
0000714ce89e21af  vmovaps [rsp+0xA0], xmm11
0000714ce89e21b8  vmovaps [rsp+0xB0], xmm12
0000714ce89e21c1  vmovaps [rsp+0xC0], xmm13
0000714ce89e21ca  vmovaps [rsp+0xD0], xmm14
0000714ce89e21d3  vmovaps [rsp+0xE0], xmm15
0000714ce89e21dc  sub rsp, 0x30
0000714ce89e21e0  movaps [rsp], xmm9
0000714ce89e21e5  movaps [rsp+0x10], xmm2
0000714ce89e21ea  movaps [rsp+0x20], xmm1
0000714ce89e21ef  lea rdi, [rsp]
0000714ce89e21f3  mov esi, 0x00
0000714ce89e21f8  mov rax, 0x57A55D340530
0000714ce89e2202  call rax
0000714ce89e2204  movaps xmm9, [rsp]
0000714ce89e2209  add rsp, 0x30
0000714ce89e220d  vmovaps xmm0, [rsp]
0000714ce89e2212  vmovaps xmm1, [rsp+0x10]
0000714ce89e2218  vmovaps xmm2, [rsp+0x20]
0000714ce89e221e  vmovaps xmm3, [rsp+0x30]
0000714ce89e2224  vmovaps xmm4, [rsp+0x40]
0000714ce89e222a  vmovaps xmm5, [rsp+0x50]
0000714ce89e2230  vmovaps xmm6, [rsp+0x60]
0000714ce89e2236  vmovaps xmm7, [rsp+0x70]
0000714ce89e223c  vmovaps xmm8, [rsp+0x80]
0000714ce89e2245  vmovaps xmm10, [rsp+0x90]
0000714ce89e224e  vmovaps xmm11, [rsp+0xA0]
0000714ce89e2257  vmovaps xmm12, [rsp+0xB0]
0000714ce89e2260  vmovaps xmm13, [rsp+0xC0]
0000714ce89e2269  vmovaps xmm14, [rsp+0xD0]
0000714ce89e2272  vmovaps xmm15, [rsp+0xE0]
0000714ce89e227b  add rsp, 0xF0
0000714ce89e2282  pop r11
0000714ce89e2284  pop r10
0000714ce89e2286  pop r9
0000714ce89e2288  pop r8
0000714ce89e228a  pop rsi
0000714ce89e228b  pop rdi
0000714ce89e228c  pop rdx
0000714ce89e228d  pop rcx
0000714ce89e228e  pop rax
0000714ce89e228f  add rsp, 0x08
0000714ce89e2293  jmp 0x0000714CE89DF534
0000714ce89e2298  sub rsp, 0x08
0000714ce89e229c  push rax
0000714ce89e229d  push rcx
0000714ce89e229e  push rdx
0000714ce89e229f  push rdi
0000714ce89e22a0  push rsi
0000714ce89e22a1  push r8
0000714ce89e22a3  push r9
0000714ce89e22a5  push r10
0000714ce89e22a7  push r11
0000714ce89e22a9  sub rsp, 0xF0
0000714ce89e22b0  vmovaps [rsp], xmm0
0000714ce89e22b5  vmovaps [rsp+0x10], xmm2
0000714ce89e22bb  vmovaps [rsp+0x20], xmm3
0000714ce89e22c1  vmovaps [rsp+0x30], xmm4
0000714ce89e22c7  vmovaps [rsp+0x40], xmm5
0000714ce89e22cd  vmovaps [rsp+0x50], xmm6
0000714ce89e22d3  vmovaps [rsp+0x60], xmm7
0000714ce89e22d9  vmovaps [rsp+0x70], xmm8
0000714ce89e22df  vmovaps [rsp+0x80], xmm9
0000714ce89e22e8  vmovaps [rsp+0x90], xmm10
0000714ce89e22f1  vmovaps [rsp+0xA0], xmm11
0000714ce89e22fa  vmovaps [rsp+0xB0], xmm12
0000714ce89e2303  vmovaps [rsp+0xC0], xmm13
0000714ce89e230c  vmovaps [rsp+0xD0], xmm14
0000714ce89e2315  vmovaps [rsp+0xE0], xmm15
0000714ce89e231e  sub rsp, 0x30
0000714ce89e2322  movaps [rsp], xmm1
0000714ce89e2326  movaps [rsp+0x10], xmm15
0000714ce89e232c  movaps [rsp+0x20], xmm6
0000714ce89e2331  lea rdi, [rsp]
0000714ce89e2335  mov esi, 0x00
0000714ce89e233a  mov rax, 0x57A55D340530
0000714ce89e2344  call rax
0000714ce89e2346  movaps xmm1, [rsp]
0000714ce89e234a  add rsp, 0x30
0000714ce89e234e  vmovaps xmm0, [rsp]
0000714ce89e2353  vmovaps xmm2, [rsp+0x10]
0000714ce89e2359  vmovaps xmm3, [rsp+0x20]
0000714ce89e235f  vmovaps xmm4, [rsp+0x30]
0000714ce89e2365  vmovaps xmm5, [rsp+0x40]
0000714ce89e236b  vmovaps xmm6, [rsp+0x50]
0000714ce89e2371  vmovaps xmm7, [rsp+0x60]
0000714ce89e2377  vmovaps xmm8, [rsp+0x70]
0000714ce89e237d  vmovaps xmm9, [rsp+0x80]
0000714ce89e2386  vmovaps xmm10, [rsp+0x90]
0000714ce89e238f  vmovaps xmm11, [rsp+0xA0]
0000714ce89e2398  vmovaps xmm12, [rsp+0xB0]
0000714ce89e23a1  vmovaps xmm13, [rsp+0xC0]
0000714ce89e23aa  vmovaps xmm14, [rsp+0xD0]
0000714ce89e23b3  vmovaps xmm15, [rsp+0xE0]
0000714ce89e23bc  add rsp, 0xF0
0000714ce89e23c3  pop r11
0000714ce89e23c5  pop r10
0000714ce89e23c7  pop r9
0000714ce89e23c9  pop r8
0000714ce89e23cb  pop rsi
0000714ce89e23cc  pop rdi
0000714ce89e23cd  pop rdx
0000714ce89e23ce  pop rcx
0000714ce89e23cf  pop rax
0000714ce89e23d0  add rsp, 0x08
0000714ce89e23d4  jmp 0x0000714CE89DF555
0000714ce89e23d9  sub rsp, 0x08
0000714ce89e23dd  push rax
0000714ce89e23de  push rcx
0000714ce89e23df  push rdx
0000714ce89e23e0  push rdi
0000714ce89e23e1  push rsi
0000714ce89e23e2  push r8
0000714ce89e23e4  push r9
0000714ce89e23e6  push r10
0000714ce89e23e8  push r11
0000714ce89e23ea  sub rsp, 0xF0
0000714ce89e23f1  vmovaps [rsp], xmm0
0000714ce89e23f6  vmovaps [rsp+0x10], xmm1
0000714ce89e23fc  vmovaps [rsp+0x20], xmm2
0000714ce89e2402  vmovaps [rsp+0x30], xmm3
0000714ce89e2408  vmovaps [rsp+0x40], xmm4
0000714ce89e240e  vmovaps [rsp+0x50], xmm5
0000714ce89e2414  vmovaps [rsp+0x60], xmm6
0000714ce89e241a  vmovaps [rsp+0x70], xmm7
0000714ce89e2420  vmovaps [rsp+0x80], xmm8
0000714ce89e2429  vmovaps [rsp+0x90], xmm9
0000714ce89e2432  vmovaps [rsp+0xA0], xmm10
0000714ce89e243b  vmovaps [rsp+0xB0], xmm11
0000714ce89e2444  vmovaps [rsp+0xC0], xmm12
0000714ce89e244d  vmovaps [rsp+0xD0], xmm13
0000714ce89e2456  vmovaps [rsp+0xE0], xmm14
0000714ce89e245f  sub rsp, 0x30
0000714ce89e2463  movaps [rsp], xmm15
0000714ce89e2468  movaps [rsp+0x10], xmm5
0000714ce89e246d  movaps [rsp+0x20], xmm3
0000714ce89e2472  lea rdi, [rsp]
0000714ce89e2476  mov esi, 0x00
0000714ce89e247b  mov rax, 0x57A55D340530
0000714ce89e2485  call rax
0000714ce89e2487  movaps xmm15, [rsp]
0000714ce89e248c  add rsp, 0x30
0000714ce89e2490  vmovaps xmm0, [rsp]
0000714ce89e2495  vmovaps xmm1, [rsp+0x10]
0000714ce89e249b  vmovaps xmm2, [rsp+0x20]
0000714ce89e24a1  vmovaps xmm3, [rsp+0x30]
0000714ce89e24a7  vmovaps xmm4, [rsp+0x40]
0000714ce89e24ad  vmovaps xmm5, [rsp+0x50]
0000714ce89e24b3  vmovaps xmm6, [rsp+0x60]
0000714ce89e24b9  vmovaps xmm7, [rsp+0x70]
0000714ce89e24bf  vmovaps xmm8, [rsp+0x80]
0000714ce89e24c8  vmovaps xmm9, [rsp+0x90]
0000714ce89e24d1  vmovaps xmm10, [rsp+0xA0]
0000714ce89e24da  vmovaps xmm11, [rsp+0xB0]
0000714ce89e24e3  vmovaps xmm12, [rsp+0xC0]
0000714ce89e24ec  vmovaps xmm13, [rsp+0xD0]
0000714ce89e24f5  vmovaps xmm14, [rsp+0xE0]
0000714ce89e24fe  add rsp, 0xF0
0000714ce89e2505  pop r11
0000714ce89e2507  pop r10
0000714ce89e2509  pop r9
0000714ce89e250b  pop r8
0000714ce89e250d  pop rsi
0000714ce89e250e  pop rdi
0000714ce89e250f  pop rdx
0000714ce89e2510  pop rcx
0000714ce89e2511  pop rax
0000714ce89e2512  add rsp, 0x08
0000714ce89e2516  jmp 0x0000714CE89DF56F
0000714ce89e251b  sub rsp, 0x08
0000714ce89e251f  push rax
0000714ce89e2520  push rcx
0000714ce89e2521  push rdx
0000714ce89e2522  push rdi
0000714ce89e2523  push rsi
0000714ce89e2524  push r8
0000714ce89e2526  push r9
0000714ce89e2528  push r10
0000714ce89e252a  push r11
0000714ce89e252c  sub rsp, 0xF0
0000714ce89e2533  vmovaps [rsp], xmm0
0000714ce89e2538  vmovaps [rsp+0x10], xmm1
0000714ce89e253e  vmovaps [rsp+0x20], xmm2
0000714ce89e2544  vmovaps [rsp+0x30], xmm3
0000714ce89e254a  vmovaps [rsp+0x40], xmm4
0000714ce89e2550  vmovaps [rsp+0x50], xmm6
0000714ce89e2556  vmovaps [rsp+0x60], xmm7
0000714ce89e255c  vmovaps [rsp+0x70], xmm8
0000714ce89e2562  vmovaps [rsp+0x80], xmm9
0000714ce89e256b  vmovaps [rsp+0x90], xmm10
0000714ce89e2574  vmovaps [rsp+0xA0], xmm11
0000714ce89e257d  vmovaps [rsp+0xB0], xmm12
0000714ce89e2586  vmovaps [rsp+0xC0], xmm13
0000714ce89e258f  vmovaps [rsp+0xD0], xmm14
0000714ce89e2598  vmovaps [rsp+0xE0], xmm15
0000714ce89e25a1  sub rsp, 0x30
0000714ce89e25a5  movaps [rsp], xmm5
0000714ce89e25a9  movaps [rsp+0x10], xmm8
0000714ce89e25af  movaps [rsp+0x20], xmm6
0000714ce89e25b4  lea rdi, [rsp]
0000714ce89e25b8  mov esi, 0x00
0000714ce89e25bd  mov rax, 0x57A55D340530
0000714ce89e25c7  call rax
0000714ce89e25c9  movaps xmm5, [rsp]
0000714ce89e25cd  add rsp, 0x30
0000714ce89e25d1  vmovaps xmm0, [rsp]
0000714ce89e25d6  vmovaps xmm1, [rsp+0x10]
0000714ce89e25dc  vmovaps xmm2, [rsp+0x20]
0000714ce89e25e2  vmovaps xmm3, [rsp+0x30]
0000714ce89e25e8  vmovaps xmm4, [rsp+0x40]
0000714ce89e25ee  vmovaps xmm6, [rsp+0x50]
0000714ce89e25f4  vmovaps xmm7, [rsp+0x60]
0000714ce89e25fa  vmovaps xmm8, [rsp+0x70]
0000714ce89e2600  vmovaps xmm9, [rsp+0x80]
0000714ce89e2609  vmovaps xmm10, [rsp+0x90]
0000714ce89e2612  vmovaps xmm11, [rsp+0xA0]
0000714ce89e261b  vmovaps xmm12, [rsp+0xB0]
0000714ce89e2624  vmovaps xmm13, [rsp+0xC0]
0000714ce89e262d  vmovaps xmm14, [rsp+0xD0]
0000714ce89e2636  vmovaps xmm15, [rsp+0xE0]
0000714ce89e263f  add rsp, 0xF0
0000714ce89e2646  pop r11
0000714ce89e2648  pop r10
0000714ce89e264a  pop r9
0000714ce89e264c  pop r8
0000714ce89e264e  pop rsi
0000714ce89e264f  pop rdi
0000714ce89e2650  pop rdx
0000714ce89e2651  pop rcx
0000714ce89e2652  pop rax
0000714ce89e2653  add rsp, 0x08
0000714ce89e2657  jmp 0x0000714CE89DF593
0000714ce89e265c  sub rsp, 0x08
0000714ce89e2660  push rax
0000714ce89e2661  push rcx
0000714ce89e2662  push rdx
0000714ce89e2663  push rdi
0000714ce89e2664  push rsi
0000714ce89e2665  push r8
0000714ce89e2667  push r9
0000714ce89e2669  push r10
0000714ce89e266b  push r11
0000714ce89e266d  sub rsp, 0xF0
0000714ce89e2674  vmovaps [rsp], xmm0
0000714ce89e2679  vmovaps [rsp+0x10], xmm1
0000714ce89e267f  vmovaps [rsp+0x20], xmm2
0000714ce89e2685  vmovaps [rsp+0x30], xmm3
0000714ce89e268b  vmovaps [rsp+0x40], xmm4
0000714ce89e2691  vmovaps [rsp+0x50], xmm5
0000714ce89e2697  vmovaps [rsp+0x60], xmm7
0000714ce89e269d  vmovaps [rsp+0x70], xmm8
0000714ce89e26a3  vmovaps [rsp+0x80], xmm9
0000714ce89e26ac  vmovaps [rsp+0x90], xmm10
0000714ce89e26b5  vmovaps [rsp+0xA0], xmm11
0000714ce89e26be  vmovaps [rsp+0xB0], xmm12
0000714ce89e26c7  vmovaps [rsp+0xC0], xmm13
0000714ce89e26d0  vmovaps [rsp+0xD0], xmm14
0000714ce89e26d9  vmovaps [rsp+0xE0], xmm15
0000714ce89e26e2  sub rsp, 0x30
0000714ce89e26e6  movaps [rsp], xmm6
0000714ce89e26ea  movaps [rsp+0x10], xmm10
0000714ce89e26f0  movaps [rsp+0x20], xmm8
0000714ce89e26f6  lea rdi, [rsp]
0000714ce89e26fa  mov esi, 0x00
0000714ce89e26ff  mov rax, 0x57A55D340530
0000714ce89e2709  call rax
0000714ce89e270b  movaps xmm6, [rsp]
0000714ce89e270f  add rsp, 0x30
0000714ce89e2713  vmovaps xmm0, [rsp]
0000714ce89e2718  vmovaps xmm1, [rsp+0x10]
0000714ce89e271e  vmovaps xmm2, [rsp+0x20]
0000714ce89e2724  vmovaps xmm3, [rsp+0x30]
0000714ce89e272a  vmovaps xmm4, [rsp+0x40]
0000714ce89e2730  vmovaps xmm5, [rsp+0x50]
0000714ce89e2736  vmovaps xmm7, [rsp+0x60]
0000714ce89e273c  vmovaps xmm8, [rsp+0x70]
0000714ce89e2742  vmovaps xmm9, [rsp+0x80]
0000714ce89e274b  vmovaps xmm10, [rsp+0x90]
0000714ce89e2754  vmovaps xmm11, [rsp+0xA0]
0000714ce89e275d  vmovaps xmm12, [rsp+0xB0]
0000714ce89e2766  vmovaps xmm13, [rsp+0xC0]
0000714ce89e276f  vmovaps xmm14, [rsp+0xD0]
0000714ce89e2778  vmovaps xmm15, [rsp+0xE0]
0000714ce89e2781  add rsp, 0xF0
0000714ce89e2788  pop r11
0000714ce89e278a  pop r10
0000714ce89e278c  pop r9
0000714ce89e278e  pop r8
0000714ce89e2790  pop rsi
0000714ce89e2791  pop rdi
0000714ce89e2792  pop rdx
0000714ce89e2793  pop rcx
0000714ce89e2794  pop rax
0000714ce89e2795  add rsp, 0x08
0000714ce89e2799  jmp 0x0000714CE89DF5B8
0000714ce89e279e  sub rsp, 0x08
0000714ce89e27a2  push rax
0000714ce89e27a3  push rcx
0000714ce89e27a4  push rdx
0000714ce89e27a5  push rdi
0000714ce89e27a6  push rsi
0000714ce89e27a7  push r8
0000714ce89e27a9  push r9
0000714ce89e27ab  push r10
0000714ce89e27ad  push r11
0000714ce89e27af  sub rsp, 0xF0
0000714ce89e27b6  vmovaps [rsp], xmm0
0000714ce89e27bb  vmovaps [rsp+0x10], xmm1
0000714ce89e27c1  vmovaps [rsp+0x20], xmm2
0000714ce89e27c7  vmovaps [rsp+0x30], xmm3
0000714ce89e27cd  vmovaps [rsp+0x40], xmm4
0000714ce89e27d3  vmovaps [rsp+0x50], xmm5
0000714ce89e27d9  vmovaps [rsp+0x60], xmm6
0000714ce89e27df  vmovaps [rsp+0x70], xmm7
0000714ce89e27e5  vmovaps [rsp+0x80], xmm8
0000714ce89e27ee  vmovaps [rsp+0x90], xmm9
0000714ce89e27f7  vmovaps [rsp+0xA0], xmm11
0000714ce89e2800  vmovaps [rsp+0xB0], xmm12
0000714ce89e2809  vmovaps [rsp+0xC0], xmm13
0000714ce89e2812  vmovaps [rsp+0xD0], xmm14
0000714ce89e281b  vmovaps [rsp+0xE0], xmm15
0000714ce89e2824  sub rsp, 0x30
0000714ce89e2828  movaps [rsp], xmm10
0000714ce89e282d  movaps [rsp+0x10], xmm8
0000714ce89e2833  movaps [rsp+0x20], xmm14
0000714ce89e2839  lea rdi, [rsp]
0000714ce89e283d  mov esi, 0x00
0000714ce89e2842  mov rax, 0x57A55D340530
0000714ce89e284c  call rax
0000714ce89e284e  movaps xmm10, [rsp]
0000714ce89e2853  add rsp, 0x30
0000714ce89e2857  vmovaps xmm0, [rsp]
0000714ce89e285c  vmovaps xmm1, [rsp+0x10]
0000714ce89e2862  vmovaps xmm2, [rsp+0x20]
0000714ce89e2868  vmovaps xmm3, [rsp+0x30]
0000714ce89e286e  vmovaps xmm4, [rsp+0x40]
0000714ce89e2874  vmovaps xmm5, [rsp+0x50]
0000714ce89e287a  vmovaps xmm6, [rsp+0x60]
0000714ce89e2880  vmovaps xmm7, [rsp+0x70]
0000714ce89e2886  vmovaps xmm8, [rsp+0x80]
0000714ce89e288f  vmovaps xmm9, [rsp+0x90]
0000714ce89e2898  vmovaps xmm11, [rsp+0xA0]
0000714ce89e28a1  vmovaps xmm12, [rsp+0xB0]
0000714ce89e28aa  vmovaps xmm13, [rsp+0xC0]
0000714ce89e28b3  vmovaps xmm14, [rsp+0xD0]
0000714ce89e28bc  vmovaps xmm15, [rsp+0xE0]
0000714ce89e28c5  add rsp, 0xF0
0000714ce89e28cc  pop r11
0000714ce89e28ce  pop r10
0000714ce89e28d0  pop r9
0000714ce89e28d2  pop r8
0000714ce89e28d4  pop rsi
0000714ce89e28d5  pop rdi
0000714ce89e28d6  pop rdx
0000714ce89e28d7  pop rcx
0000714ce89e28d8  pop rax
0000714ce89e28d9  add rsp, 0x08
0000714ce89e28dd  jmp 0x0000714CE89DF5D8
0000714ce89e28e2  sub rsp, 0x08
0000714ce89e28e6  push rax
0000714ce89e28e7  push rcx
0000714ce89e28e8  push rdx
0000714ce89e28e9  push rdi
0000714ce89e28ea  push rsi
0000714ce89e28eb  push r8
0000714ce89e28ed  push r9
0000714ce89e28ef  push r10
0000714ce89e28f1  push r11
0000714ce89e28f3  sub rsp, 0xF0
0000714ce89e28fa  vmovaps [rsp], xmm0
0000714ce89e28ff  vmovaps [rsp+0x10], xmm1
0000714ce89e2905  vmovaps [rsp+0x20], xmm2
0000714ce89e290b  vmovaps [rsp+0x30], xmm3
0000714ce89e2911  vmovaps [rsp+0x40], xmm4
0000714ce89e2917  vmovaps [rsp+0x50], xmm5
0000714ce89e291d  vmovaps [rsp+0x60], xmm6
0000714ce89e2923  vmovaps [rsp+0x70], xmm7
0000714ce89e2929  vmovaps [rsp+0x80], xmm8
0000714ce89e2932  vmovaps [rsp+0x90], xmm9
0000714ce89e293b  vmovaps [rsp+0xA0], xmm10
0000714ce89e2944  vmovaps [rsp+0xB0], xmm11
0000714ce89e294d  vmovaps [rsp+0xC0], xmm12
0000714ce89e2956  vmovaps [rsp+0xD0], xmm13
0000714ce89e295f  vmovaps [rsp+0xE0], xmm15
0000714ce89e2968  sub rsp, 0x30
0000714ce89e296c  movaps [rsp], xmm14
0000714ce89e2971  movaps [rsp+0x10], xmm8
0000714ce89e2977  movaps [rsp+0x20], xmm4
0000714ce89e297c  lea rdi, [rsp]
0000714ce89e2980  mov esi, 0x00
0000714ce89e2985  mov rax, 0x57A55D340530
0000714ce89e298f  call rax
0000714ce89e2991  movaps xmm14, [rsp]
0000714ce89e2996  add rsp, 0x30
0000714ce89e299a  vmovaps xmm0, [rsp]
0000714ce89e299f  vmovaps xmm1, [rsp+0x10]
0000714ce89e29a5  vmovaps xmm2, [rsp+0x20]
0000714ce89e29ab  vmovaps xmm3, [rsp+0x30]
0000714ce89e29b1  vmovaps xmm4, [rsp+0x40]
0000714ce89e29b7  vmovaps xmm5, [rsp+0x50]
0000714ce89e29bd  vmovaps xmm6, [rsp+0x60]
0000714ce89e29c3  vmovaps xmm7, [rsp+0x70]
0000714ce89e29c9  vmovaps xmm8, [rsp+0x80]
0000714ce89e29d2  vmovaps xmm9, [rsp+0x90]
0000714ce89e29db  vmovaps xmm10, [rsp+0xA0]
0000714ce89e29e4  vmovaps xmm11, [rsp+0xB0]
0000714ce89e29ed  vmovaps xmm12, [rsp+0xC0]
0000714ce89e29f6  vmovaps xmm13, [rsp+0xD0]
0000714ce89e29ff  vmovaps xmm15, [rsp+0xE0]
0000714ce89e2a08  add rsp, 0xF0
0000714ce89e2a0f  pop r11
0000714ce89e2a11  pop r10
0000714ce89e2a13  pop r9
0000714ce89e2a15  pop r8
0000714ce89e2a17  pop rsi
0000714ce89e2a18  pop rdi
0000714ce89e2a19  pop rdx
0000714ce89e2a1a  pop rcx
0000714ce89e2a1b  pop rax
0000714ce89e2a1c  add rsp, 0x08
0000714ce89e2a20  jmp 0x0000714CE89DF5F8
0000714ce89e2a25  sub rsp, 0x08
0000714ce89e2a29  push rax
0000714ce89e2a2a  push rcx
0000714ce89e2a2b  push rdx
0000714ce89e2a2c  push rdi
0000714ce89e2a2d  push rsi
0000714ce89e2a2e  push r8
0000714ce89e2a30  push r9
0000714ce89e2a32  push r10
0000714ce89e2a34  push r11
0000714ce89e2a36  sub rsp, 0xF0
0000714ce89e2a3d  vmovaps [rsp], xmm0
0000714ce89e2a42  vmovaps [rsp+0x10], xmm1
0000714ce89e2a48  vmovaps [rsp+0x20], xmm2
0000714ce89e2a4e  vmovaps [rsp+0x30], xmm3
0000714ce89e2a54  vmovaps [rsp+0x40], xmm5
0000714ce89e2a5a  vmovaps [rsp+0x50], xmm6
0000714ce89e2a60  vmovaps [rsp+0x60], xmm7
0000714ce89e2a66  vmovaps [rsp+0x70], xmm8
0000714ce89e2a6c  vmovaps [rsp+0x80], xmm9
0000714ce89e2a75  vmovaps [rsp+0x90], xmm10
0000714ce89e2a7e  vmovaps [rsp+0xA0], xmm11
0000714ce89e2a87  vmovaps [rsp+0xB0], xmm12
0000714ce89e2a90  vmovaps [rsp+0xC0], xmm13
0000714ce89e2a99  vmovaps [rsp+0xD0], xmm14
0000714ce89e2aa2  vmovaps [rsp+0xE0], xmm15
0000714ce89e2aab  sub rsp, 0x30
0000714ce89e2aaf  movaps [rsp], xmm4
0000714ce89e2ab3  movaps [rsp+0x10], xmm13
0000714ce89e2ab9  movaps [rsp+0x20], xmm8
0000714ce89e2abf  lea rdi, [rsp]
0000714ce89e2ac3  mov esi, 0x00
0000714ce89e2ac8  mov rax, 0x57A55D340530
0000714ce89e2ad2  call rax
0000714ce89e2ad4  movaps xmm4, [rsp]
0000714ce89e2ad8  add rsp, 0x30
0000714ce89e2adc  vmovaps xmm0, [rsp]
0000714ce89e2ae1  vmovaps xmm1, [rsp+0x10]
0000714ce89e2ae7  vmovaps xmm2, [rsp+0x20]
0000714ce89e2aed  vmovaps xmm3, [rsp+0x30]
0000714ce89e2af3  vmovaps xmm5, [rsp+0x40]
0000714ce89e2af9  vmovaps xmm6, [rsp+0x50]
0000714ce89e2aff  vmovaps xmm7, [rsp+0x60]
0000714ce89e2b05  vmovaps xmm8, [rsp+0x70]
0000714ce89e2b0b  vmovaps xmm9, [rsp+0x80]
0000714ce89e2b14  vmovaps xmm10, [rsp+0x90]
0000714ce89e2b1d  vmovaps xmm11, [rsp+0xA0]
0000714ce89e2b26  vmovaps xmm12, [rsp+0xB0]
0000714ce89e2b2f  vmovaps xmm13, [rsp+0xC0]
0000714ce89e2b38  vmovaps xmm14, [rsp+0xD0]
0000714ce89e2b41  vmovaps xmm15, [rsp+0xE0]
0000714ce89e2b4a  add rsp, 0xF0
0000714ce89e2b51  pop r11
0000714ce89e2b53  pop r10
0000714ce89e2b55  pop r9
0000714ce89e2b57  pop r8
0000714ce89e2b59  pop rsi
0000714ce89e2b5a  pop rdi
0000714ce89e2b5b  pop rdx
0000714ce89e2b5c  pop rcx
0000714ce89e2b5d  pop rax
0000714ce89e2b5e  add rsp, 0x08
0000714ce89e2b62  jmp 0x0000714CE89DF61D
0000714ce89e2b67  sub rsp, 0x08
0000714ce89e2b6b  push rax
0000714ce89e2b6c  push rcx
0000714ce89e2b6d  push rdx
0000714ce89e2b6e  push rdi
0000714ce89e2b6f  push rsi
0000714ce89e2b70  push r8
0000714ce89e2b72  push r9
0000714ce89e2b74  push r10
0000714ce89e2b76  push r11
0000714ce89e2b78  sub rsp, 0xF0
0000714ce89e2b7f  vmovaps [rsp], xmm0
0000714ce89e2b84  vmovaps [rsp+0x10], xmm1
0000714ce89e2b8a  vmovaps [rsp+0x20], xmm2
0000714ce89e2b90  vmovaps [rsp+0x30], xmm3
0000714ce89e2b96  vmovaps [rsp+0x40], xmm4
0000714ce89e2b9c  vmovaps [rsp+0x50], xmm5
0000714ce89e2ba2  vmovaps [rsp+0x60], xmm6
0000714ce89e2ba8  vmovaps [rsp+0x70], xmm7
0000714ce89e2bae  vmovaps [rsp+0x80], xmm8
0000714ce89e2bb7  vmovaps [rsp+0x90], xmm9
0000714ce89e2bc0  vmovaps [rsp+0xA0], xmm10
0000714ce89e2bc9  vmovaps [rsp+0xB0], xmm11
0000714ce89e2bd2  vmovaps [rsp+0xC0], xmm12
0000714ce89e2bdb  vmovaps [rsp+0xD0], xmm14
0000714ce89e2be4  vmovaps [rsp+0xE0], xmm15
0000714ce89e2bed  sub rsp, 0x30
0000714ce89e2bf1  movaps [rsp], xmm13
0000714ce89e2bf6  movaps [rsp+0x10], xmm15
0000714ce89e2bfc  movaps [rsp+0x20], xmm9
0000714ce89e2c02  lea rdi, [rsp]
0000714ce89e2c06  mov esi, 0x00
0000714ce89e2c0b  mov rax, 0x57A55D340530
0000714ce89e2c15  call rax
0000714ce89e2c17  movaps xmm13, [rsp]
0000714ce89e2c1c  add rsp, 0x30
0000714ce89e2c20  vmovaps xmm0, [rsp]
0000714ce89e2c25  vmovaps xmm1, [rsp+0x10]
0000714ce89e2c2b  vmovaps xmm2, [rsp+0x20]
0000714ce89e2c31  vmovaps xmm3, [rsp+0x30]
0000714ce89e2c37  vmovaps xmm4, [rsp+0x40]
0000714ce89e2c3d  vmovaps xmm5, [rsp+0x50]
0000714ce89e2c43  vmovaps xmm6, [rsp+0x60]
0000714ce89e2c49  vmovaps xmm7, [rsp+0x70]
0000714ce89e2c4f  vmovaps xmm8, [rsp+0x80]
0000714ce89e2c58  vmovaps xmm9, [rsp+0x90]
0000714ce89e2c61  vmovaps xmm10, [rsp+0xA0]
0000714ce89e2c6a  vmovaps xmm11, [rsp+0xB0]
0000714ce89e2c73  vmovaps xmm12, [rsp+0xC0]
0000714ce89e2c7c  vmovaps xmm14, [rsp+0xD0]
0000714ce89e2c85  vmovaps xmm15, [rsp+0xE0]
0000714ce89e2c8e  add rsp, 0xF0
0000714ce89e2c95  pop r11
0000714ce89e2c97  pop r10
0000714ce89e2c99  pop r9
0000714ce89e2c9b  pop r8
0000714ce89e2c9d  pop rsi
0000714ce89e2c9e  pop rdi
0000714ce89e2c9f  pop rdx
0000714ce89e2ca0  pop rcx
0000714ce89e2ca1  pop rax
0000714ce89e2ca2  add rsp, 0x08
0000714ce89e2ca6  jmp 0x0000714CE89DF638
0000714ce89e2cab  sub rsp, 0x08
0000714ce89e2caf  push rax
0000714ce89e2cb0  push rcx
0000714ce89e2cb1  push rdx
0000714ce89e2cb2  push rdi
0000714ce89e2cb3  push rsi
0000714ce89e2cb4  push r8
0000714ce89e2cb6  push r9
0000714ce89e2cb8  push r10
0000714ce89e2cba  push r11
0000714ce89e2cbc  sub rsp, 0xF0
0000714ce89e2cc3  vmovaps [rsp], xmm0
0000714ce89e2cc8  vmovaps [rsp+0x10], xmm1
0000714ce89e2cce  vmovaps [rsp+0x20], xmm2
0000714ce89e2cd4  vmovaps [rsp+0x30], xmm3
0000714ce89e2cda  vmovaps [rsp+0x40], xmm4
0000714ce89e2ce0  vmovaps [rsp+0x50], xmm5
0000714ce89e2ce6  vmovaps [rsp+0x60], xmm6
0000714ce89e2cec  vmovaps [rsp+0x70], xmm7
0000714ce89e2cf2  vmovaps [rsp+0x80], xmm8
0000714ce89e2cfb  vmovaps [rsp+0x90], xmm9
0000714ce89e2d04  vmovaps [rsp+0xA0], xmm10
0000714ce89e2d0d  vmovaps [rsp+0xB0], xmm11
0000714ce89e2d16  vmovaps [rsp+0xC0], xmm12
0000714ce89e2d1f  vmovaps [rsp+0xD0], xmm13
0000714ce89e2d28  vmovaps [rsp+0xE0], xmm14
0000714ce89e2d31  sub rsp, 0x30
0000714ce89e2d35  movaps [rsp], xmm15
0000714ce89e2d3a  movaps [rsp+0x10], xmm1
0000714ce89e2d3f  movaps [rsp+0x20], xmm5
0000714ce89e2d44  lea rdi, [rsp]
0000714ce89e2d48  mov esi, 0x00
0000714ce89e2d4d  mov rax, 0x57A55D340530
0000714ce89e2d57  call rax
0000714ce89e2d59  movaps xmm15, [rsp]
0000714ce89e2d5e  add rsp, 0x30
0000714ce89e2d62  vmovaps xmm0, [rsp]
0000714ce89e2d67  vmovaps xmm1, [rsp+0x10]
0000714ce89e2d6d  vmovaps xmm2, [rsp+0x20]
0000714ce89e2d73  vmovaps xmm3, [rsp+0x30]
0000714ce89e2d79  vmovaps xmm4, [rsp+0x40]
0000714ce89e2d7f  vmovaps xmm5, [rsp+0x50]
0000714ce89e2d85  vmovaps xmm6, [rsp+0x60]
0000714ce89e2d8b  vmovaps xmm7, [rsp+0x70]
0000714ce89e2d91  vmovaps xmm8, [rsp+0x80]
0000714ce89e2d9a  vmovaps xmm9, [rsp+0x90]
0000714ce89e2da3  vmovaps xmm10, [rsp+0xA0]
0000714ce89e2dac  vmovaps xmm11, [rsp+0xB0]
0000714ce89e2db5  vmovaps xmm12, [rsp+0xC0]
0000714ce89e2dbe  vmovaps xmm13, [rsp+0xD0]
0000714ce89e2dc7  vmovaps xmm14, [rsp+0xE0]
0000714ce89e2dd0  add rsp, 0xF0
0000714ce89e2dd7  pop r11
0000714ce89e2dd9  pop r10
0000714ce89e2ddb  pop r9
0000714ce89e2ddd  pop r8
0000714ce89e2ddf  pop rsi
0000714ce89e2de0  pop rdi
0000714ce89e2de1  pop rdx
0000714ce89e2de2  pop rcx
0000714ce89e2de3  pop rax
0000714ce89e2de4  add rsp, 0x08
0000714ce89e2de8  jmp 0x0000714CE89DF653
0000714ce89e2ded  call 0x0000714CE88B52F0
0000714ce89e2df2  jmp 0x0000714CE89DF6AE
0000714ce89e2df7  sub rsp, 0x08
0000714ce89e2dfb  push rax
0000714ce89e2dfc  push rcx
0000714ce89e2dfd  push rdx
0000714ce89e2dfe  push rdi
0000714ce89e2dff  push rsi
0000714ce89e2e00  push r8
0000714ce89e2e02  push r9
0000714ce89e2e04  push r10
0000714ce89e2e06  push r11
0000714ce89e2e08  sub rsp, 0xF0
0000714ce89e2e0f  vmovaps [rsp], xmm0
0000714ce89e2e14  vmovaps [rsp+0x10], xmm1
0000714ce89e2e1a  vmovaps [rsp+0x20], xmm2
0000714ce89e2e20  vmovaps [rsp+0x30], xmm3
0000714ce89e2e26  vmovaps [rsp+0x40], xmm4
0000714ce89e2e2c  vmovaps [rsp+0x50], xmm5
0000714ce89e2e32  vmovaps [rsp+0x60], xmm6
0000714ce89e2e38  vmovaps [rsp+0x70], xmm7
0000714ce89e2e3e  vmovaps [rsp+0x80], xmm8
0000714ce89e2e47  vmovaps [rsp+0x90], xmm10
0000714ce89e2e50  vmovaps [rsp+0xA0], xmm11
0000714ce89e2e59  vmovaps [rsp+0xB0], xmm12
0000714ce89e2e62  vmovaps [rsp+0xC0], xmm13
0000714ce89e2e6b  vmovaps [rsp+0xD0], xmm14
0000714ce89e2e74  vmovaps [rsp+0xE0], xmm15
0000714ce89e2e7d  sub rsp, 0x30
0000714ce89e2e81  movaps [rsp], xmm9
0000714ce89e2e86  movaps [rsp+0x10], xmm8
0000714ce89e2e8c  movaps [rsp+0x20], xmm11
0000714ce89e2e92  lea rdi, [rsp]
0000714ce89e2e96  mov esi, 0x00
0000714ce89e2e9b  mov rax, 0x57A55D340530
0000714ce89e2ea5  call rax
0000714ce89e2ea7  movaps xmm9, [rsp]
0000714ce89e2eac  add rsp, 0x30
0000714ce89e2eb0  vmovaps xmm0, [rsp]
0000714ce89e2eb5  vmovaps xmm1, [rsp+0x10]
0000714ce89e2ebb  vmovaps xmm2, [rsp+0x20]
0000714ce89e2ec1  vmovaps xmm3, [rsp+0x30]
0000714ce89e2ec7  vmovaps xmm4, [rsp+0x40]
0000714ce89e2ecd  vmovaps xmm5, [rsp+0x50]
0000714ce89e2ed3  vmovaps xmm6, [rsp+0x60]
0000714ce89e2ed9  vmovaps xmm7, [rsp+0x70]
0000714ce89e2edf  vmovaps xmm8, [rsp+0x80]
0000714ce89e2ee8  vmovaps xmm10, [rsp+0x90]
0000714ce89e2ef1  vmovaps xmm11, [rsp+0xA0]
0000714ce89e2efa  vmovaps xmm12, [rsp+0xB0]
0000714ce89e2f03  vmovaps xmm13, [rsp+0xC0]
0000714ce89e2f0c  vmovaps xmm14, [rsp+0xD0]
0000714ce89e2f15  vmovaps xmm15, [rsp+0xE0]
0000714ce89e2f1e  add rsp, 0xF0
0000714ce89e2f25  pop r11
0000714ce89e2f27  pop r10
0000714ce89e2f29  pop r9
0000714ce89e2f2b  pop r8
0000714ce89e2f2d  pop rsi
0000714ce89e2f2e  pop rdi
0000714ce89e2f2f  pop rdx
0000714ce89e2f30  pop rcx
0000714ce89e2f31  pop rax
0000714ce89e2f32  add rsp, 0x08
0000714ce89e2f36  jmp 0x0000714CE89DF6E5
0000714ce89e2f3b  sub rsp, 0x08
0000714ce89e2f3f  push rax
0000714ce89e2f40  push rcx
0000714ce89e2f41  push rdx
0000714ce89e2f42  push rdi
0000714ce89e2f43  push rsi
0000714ce89e2f44  push r8
0000714ce89e2f46  push r9
0000714ce89e2f48  push r10
0000714ce89e2f4a  push r11
0000714ce89e2f4c  sub rsp, 0xF0
0000714ce89e2f53  vmovaps [rsp], xmm0
0000714ce89e2f58  vmovaps [rsp+0x10], xmm1
0000714ce89e2f5e  vmovaps [rsp+0x20], xmm2
0000714ce89e2f64  vmovaps [rsp+0x30], xmm3
0000714ce89e2f6a  vmovaps [rsp+0x40], xmm4
0000714ce89e2f70  vmovaps [rsp+0x50], xmm5
0000714ce89e2f76  vmovaps [rsp+0x60], xmm6
0000714ce89e2f7c  vmovaps [rsp+0x70], xmm7
0000714ce89e2f82  vmovaps [rsp+0x80], xmm8
0000714ce89e2f8b  vmovaps [rsp+0x90], xmm9
0000714ce89e2f94  vmovaps [rsp+0xA0], xmm10
0000714ce89e2f9d  vmovaps [rsp+0xB0], xmm12
0000714ce89e2fa6  vmovaps [rsp+0xC0], xmm13
0000714ce89e2faf  vmovaps [rsp+0xD0], xmm14
0000714ce89e2fb8  vmovaps [rsp+0xE0], xmm15
0000714ce89e2fc1  sub rsp, 0x30
0000714ce89e2fc5  movaps [rsp], xmm11
0000714ce89e2fca  movaps [rsp+0x10], xmm10
0000714ce89e2fd0  movaps [rsp+0x20], xmm6
0000714ce89e2fd5  lea rdi, [rsp]
0000714ce89e2fd9  mov esi, 0x00
0000714ce89e2fde  mov rax, 0x57A55D340530
0000714ce89e2fe8  call rax
0000714ce89e2fea  movaps xmm11, [rsp]
0000714ce89e2fef  add rsp, 0x30
0000714ce89e2ff3  vmovaps xmm0, [rsp]
0000714ce89e2ff8  vmovaps xmm1, [rsp+0x10]
0000714ce89e2ffe  vmovaps xmm2, [rsp+0x20]
0000714ce89e3004  vmovaps xmm3, [rsp+0x30]
0000714ce89e300a  vmovaps xmm4, [rsp+0x40]
0000714ce89e3010  vmovaps xmm5, [rsp+0x50]
0000714ce89e3016  vmovaps xmm6, [rsp+0x60]
0000714ce89e301c  vmovaps xmm7, [rsp+0x70]
0000714ce89e3022  vmovaps xmm8, [rsp+0x80]
0000714ce89e302b  vmovaps xmm9, [rsp+0x90]
0000714ce89e3034  vmovaps xmm10, [rsp+0xA0]
0000714ce89e303d  vmovaps xmm12, [rsp+0xB0]
0000714ce89e3046  vmovaps xmm13, [rsp+0xC0]
0000714ce89e304f  vmovaps xmm14, [rsp+0xD0]
0000714ce89e3058  vmovaps xmm15, [rsp+0xE0]
0000714ce89e3061  add rsp, 0xF0
0000714ce89e3068  pop r11
0000714ce89e306a  pop r10
0000714ce89e306c  pop r9
0000714ce89e306e  pop r8
0000714ce89e3070  pop rsi
0000714ce89e3071  pop rdi
0000714ce89e3072  pop rdx
0000714ce89e3073  pop rcx
0000714ce89e3074  pop rax
0000714ce89e3075  add rsp, 0x08
0000714ce89e3079  jmp 0x0000714CE89DF700
0000714ce89e307e  sub rsp, 0x08
0000714ce89e3082  push rax
0000714ce89e3083  push rcx
0000714ce89e3084  push rdx
0000714ce89e3085  push rdi
0000714ce89e3086  push rsi
0000714ce89e3087  push r8
0000714ce89e3089  push r9
0000714ce89e308b  push r10
0000714ce89e308d  push r11
0000714ce89e308f  sub rsp, 0xF0
0000714ce89e3096  vmovaps [rsp], xmm0
0000714ce89e309b  vmovaps [rsp+0x10], xmm1
0000714ce89e30a1  vmovaps [rsp+0x20], xmm2
0000714ce89e30a7  vmovaps [rsp+0x30], xmm3
0000714ce89e30ad  vmovaps [rsp+0x40], xmm4
0000714ce89e30b3  vmovaps [rsp+0x50], xmm5
0000714ce89e30b9  vmovaps [rsp+0x60], xmm6
0000714ce89e30bf  vmovaps [rsp+0x70], xmm7
0000714ce89e30c5  vmovaps [rsp+0x80], xmm8
0000714ce89e30ce  vmovaps [rsp+0x90], xmm9
0000714ce89e30d7  vmovaps [rsp+0xA0], xmm11
0000714ce89e30e0  vmovaps [rsp+0xB0], xmm12
0000714ce89e30e9  vmovaps [rsp+0xC0], xmm13
0000714ce89e30f2  vmovaps [rsp+0xD0], xmm14
0000714ce89e30fb  vmovaps [rsp+0xE0], xmm15
0000714ce89e3104  sub rsp, 0x30
0000714ce89e3108  movaps [rsp], xmm10
0000714ce89e310d  movaps [rsp+0x10], xmm14
0000714ce89e3113  movaps [rsp+0x20], xmm4
0000714ce89e3118  lea rdi, [rsp]
0000714ce89e311c  mov esi, 0x00
0000714ce89e3121  mov rax, 0x57A55D340530
0000714ce89e312b  call rax
0000714ce89e312d  movaps xmm10, [rsp]
0000714ce89e3132  add rsp, 0x30
0000714ce89e3136  vmovaps xmm0, [rsp]
0000714ce89e313b  vmovaps xmm1, [rsp+0x10]
0000714ce89e3141  vmovaps xmm2, [rsp+0x20]
0000714ce89e3147  vmovaps xmm3, [rsp+0x30]
0000714ce89e314d  vmovaps xmm4, [rsp+0x40]
0000714ce89e3153  vmovaps xmm5, [rsp+0x50]
0000714ce89e3159  vmovaps xmm6, [rsp+0x60]
0000714ce89e315f  vmovaps xmm7, [rsp+0x70]
0000714ce89e3165  vmovaps xmm8, [rsp+0x80]
0000714ce89e316e  vmovaps xmm9, [rsp+0x90]
0000714ce89e3177  vmovaps xmm11, [rsp+0xA0]
0000714ce89e3180  vmovaps xmm12, [rsp+0xB0]
0000714ce89e3189  vmovaps xmm13, [rsp+0xC0]
0000714ce89e3192  vmovaps xmm14, [rsp+0xD0]
0000714ce89e319b  vmovaps xmm15, [rsp+0xE0]
0000714ce89e31a4  add rsp, 0xF0
0000714ce89e31ab  pop r11
0000714ce89e31ad  pop r10
0000714ce89e31af  pop r9
0000714ce89e31b1  pop r8
0000714ce89e31b3  pop rsi
0000714ce89e31b4  pop rdi
0000714ce89e31b5  pop rdx
0000714ce89e31b6  pop rcx
0000714ce89e31b7  pop rax
0000714ce89e31b8  add rsp, 0x08
0000714ce89e31bc  jmp 0x0000714CE89DF71B
0000714ce89e31c1  sub rsp, 0x08
0000714ce89e31c5  push rax
0000714ce89e31c6  push rcx
0000714ce89e31c7  push rdx
0000714ce89e31c8  push rdi
0000714ce89e31c9  push rsi
0000714ce89e31ca  push r8
0000714ce89e31cc  push r9
0000714ce89e31ce  push r10
0000714ce89e31d0  push r11
0000714ce89e31d2  sub rsp, 0xF0
0000714ce89e31d9  vmovaps [rsp], xmm0
0000714ce89e31de  vmovaps [rsp+0x10], xmm1
0000714ce89e31e4  vmovaps [rsp+0x20], xmm2
0000714ce89e31ea  vmovaps [rsp+0x30], xmm3
0000714ce89e31f0  vmovaps [rsp+0x40], xmm4
0000714ce89e31f6  vmovaps [rsp+0x50], xmm5
0000714ce89e31fc  vmovaps [rsp+0x60], xmm6
0000714ce89e3202  vmovaps [rsp+0x70], xmm7
0000714ce89e3208  vmovaps [rsp+0x80], xmm9
0000714ce89e3211  vmovaps [rsp+0x90], xmm10
0000714ce89e321a  vmovaps [rsp+0xA0], xmm11
0000714ce89e3223  vmovaps [rsp+0xB0], xmm12
0000714ce89e322c  vmovaps [rsp+0xC0], xmm13
0000714ce89e3235  vmovaps [rsp+0xD0], xmm14
0000714ce89e323e  vmovaps [rsp+0xE0], xmm15
0000714ce89e3247  sub rsp, 0x30
0000714ce89e324b  movaps [rsp], xmm8
0000714ce89e3250  movaps [rsp+0x10], xmm1
0000714ce89e3255  movaps [rsp+0x20], xmm14
0000714ce89e325b  lea rdi, [rsp]
0000714ce89e325f  mov esi, 0x00
0000714ce89e3264  mov rax, 0x57A55D340530
0000714ce89e326e  call rax
0000714ce89e3270  movaps xmm8, [rsp]
0000714ce89e3275  add rsp, 0x30
0000714ce89e3279  vmovaps xmm0, [rsp]
0000714ce89e327e  vmovaps xmm1, [rsp+0x10]
0000714ce89e3284  vmovaps xmm2, [rsp+0x20]
0000714ce89e328a  vmovaps xmm3, [rsp+0x30]
0000714ce89e3290  vmovaps xmm4, [rsp+0x40]
0000714ce89e3296  vmovaps xmm5, [rsp+0x50]
0000714ce89e329c  vmovaps xmm6, [rsp+0x60]
0000714ce89e32a2  vmovaps xmm7, [rsp+0x70]
0000714ce89e32a8  vmovaps xmm9, [rsp+0x80]
0000714ce89e32b1  vmovaps xmm10, [rsp+0x90]
0000714ce89e32ba  vmovaps xmm11, [rsp+0xA0]
0000714ce89e32c3  vmovaps xmm12, [rsp+0xB0]
0000714ce89e32cc  vmovaps xmm13, [rsp+0xC0]
0000714ce89e32d5  vmovaps xmm14, [rsp+0xD0]
0000714ce89e32de  vmovaps xmm15, [rsp+0xE0]
0000714ce89e32e7  add rsp, 0xF0
0000714ce89e32ee  pop r11
0000714ce89e32f0  pop r10
0000714ce89e32f2  pop r9
0000714ce89e32f4  pop r8
0000714ce89e32f6  pop rsi
0000714ce89e32f7  pop rdi
0000714ce89e32f8  pop rdx
0000714ce89e32f9  pop rcx
0000714ce89e32fa  pop rax
0000714ce89e32fb  add rsp, 0x08
0000714ce89e32ff  jmp 0x0000714CE89DF741
0000714ce89e3304  sub rsp, 0x08
0000714ce89e3308  push rax
0000714ce89e3309  push rcx
0000714ce89e330a  push rdx
0000714ce89e330b  push rdi
0000714ce89e330c  push rsi
0000714ce89e330d  push r8
0000714ce89e330f  push r9
0000714ce89e3311  push r10
0000714ce89e3313  push r11
0000714ce89e3315  sub rsp, 0xF0
0000714ce89e331c  vmovaps [rsp], xmm0
0000714ce89e3321  vmovaps [rsp+0x10], xmm1
0000714ce89e3327  vmovaps [rsp+0x20], xmm2
0000714ce89e332d  vmovaps [rsp+0x30], xmm3
0000714ce89e3333  vmovaps [rsp+0x40], xmm4
0000714ce89e3339  vmovaps [rsp+0x50], xmm5
0000714ce89e333f  vmovaps [rsp+0x60], xmm7
0000714ce89e3345  vmovaps [rsp+0x70], xmm8
0000714ce89e334b  vmovaps [rsp+0x80], xmm9
0000714ce89e3354  vmovaps [rsp+0x90], xmm10
0000714ce89e335d  vmovaps [rsp+0xA0], xmm11
0000714ce89e3366  vmovaps [rsp+0xB0], xmm12
0000714ce89e336f  vmovaps [rsp+0xC0], xmm13
0000714ce89e3378  vmovaps [rsp+0xD0], xmm14
0000714ce89e3381  vmovaps [rsp+0xE0], xmm15
0000714ce89e338a  sub rsp, 0x30
0000714ce89e338e  movaps [rsp], xmm6
0000714ce89e3392  movaps [rsp+0x10], xmm1
0000714ce89e3397  movaps [rsp+0x20], xmm14
0000714ce89e339d  lea rdi, [rsp]
0000714ce89e33a1  mov esi, 0x00
0000714ce89e33a6  mov rax, 0x57A55D340530
0000714ce89e33b0  call rax
0000714ce89e33b2  movaps xmm6, [rsp]
0000714ce89e33b6  add rsp, 0x30
0000714ce89e33ba  vmovaps xmm0, [rsp]
0000714ce89e33bf  vmovaps xmm1, [rsp+0x10]
0000714ce89e33c5  vmovaps xmm2, [rsp+0x20]
0000714ce89e33cb  vmovaps xmm3, [rsp+0x30]
0000714ce89e33d1  vmovaps xmm4, [rsp+0x40]
0000714ce89e33d7  vmovaps xmm5, [rsp+0x50]
0000714ce89e33dd  vmovaps xmm7, [rsp+0x60]
0000714ce89e33e3  vmovaps xmm8, [rsp+0x70]
0000714ce89e33e9  vmovaps xmm9, [rsp+0x80]
0000714ce89e33f2  vmovaps xmm10, [rsp+0x90]
0000714ce89e33fb  vmovaps xmm11, [rsp+0xA0]
0000714ce89e3404  vmovaps xmm12, [rsp+0xB0]
0000714ce89e340d  vmovaps xmm13, [rsp+0xC0]
0000714ce89e3416  vmovaps xmm14, [rsp+0xD0]
0000714ce89e341f  vmovaps xmm15, [rsp+0xE0]
0000714ce89e3428  add rsp, 0xF0
0000714ce89e342f  pop r11
0000714ce89e3431  pop r10
0000714ce89e3433  pop r9
0000714ce89e3435  pop r8
0000714ce89e3437  pop rsi
0000714ce89e3438  pop rdi
0000714ce89e3439  pop rdx
0000714ce89e343a  pop rcx
0000714ce89e343b  pop rax
0000714ce89e343c  add rsp, 0x08
0000714ce89e3440  jmp 0x0000714CE89DF76D
0000714ce89e3445  sub rsp, 0x08
0000714ce89e3449  push rax
0000714ce89e344a  push rcx
0000714ce89e344b  push rdx
0000714ce89e344c  push rdi
0000714ce89e344d  push rsi
0000714ce89e344e  push r8
0000714ce89e3450  push r9
0000714ce89e3452  push r10
0000714ce89e3454  push r11
0000714ce89e3456  sub rsp, 0xF0
0000714ce89e345d  vmovaps [rsp], xmm0
0000714ce89e3462  vmovaps [rsp+0x10], xmm1
0000714ce89e3468  vmovaps [rsp+0x20], xmm2
0000714ce89e346e  vmovaps [rsp+0x30], xmm3
0000714ce89e3474  vmovaps [rsp+0x40], xmm4
0000714ce89e347a  vmovaps [rsp+0x50], xmm5
0000714ce89e3480  vmovaps [rsp+0x60], xmm6
0000714ce89e3486  vmovaps [rsp+0x70], xmm7
0000714ce89e348c  vmovaps [rsp+0x80], xmm8
0000714ce89e3495  vmovaps [rsp+0x90], xmm9
0000714ce89e349e  vmovaps [rsp+0xA0], xmm10
0000714ce89e34a7  vmovaps [rsp+0xB0], xmm11
0000714ce89e34b0  vmovaps [rsp+0xC0], xmm12
0000714ce89e34b9  vmovaps [rsp+0xD0], xmm13
0000714ce89e34c2  vmovaps [rsp+0xE0], xmm15
0000714ce89e34cb  sub rsp, 0x30
0000714ce89e34cf  movaps [rsp], xmm14
0000714ce89e34d4  movaps [rsp+0x10], xmm12
0000714ce89e34da  movaps [rsp+0x20], xmm1
0000714ce89e34df  lea rdi, [rsp]
0000714ce89e34e3  mov esi, 0x00
0000714ce89e34e8  mov rax, 0x57A55D340530
0000714ce89e34f2  call rax
0000714ce89e34f4  movaps xmm14, [rsp]
0000714ce89e34f9  add rsp, 0x30
0000714ce89e34fd  vmovaps xmm0, [rsp]
0000714ce89e3502  vmovaps xmm1, [rsp+0x10]
0000714ce89e3508  vmovaps xmm2, [rsp+0x20]
0000714ce89e350e  vmovaps xmm3, [rsp+0x30]
0000714ce89e3514  vmovaps xmm4, [rsp+0x40]
0000714ce89e351a  vmovaps xmm5, [rsp+0x50]
0000714ce89e3520  vmovaps xmm6, [rsp+0x60]
0000714ce89e3526  vmovaps xmm7, [rsp+0x70]
0000714ce89e352c  vmovaps xmm8, [rsp+0x80]
0000714ce89e3535  vmovaps xmm9, [rsp+0x90]
0000714ce89e353e  vmovaps xmm10, [rsp+0xA0]
0000714ce89e3547  vmovaps xmm11, [rsp+0xB0]
0000714ce89e3550  vmovaps xmm12, [rsp+0xC0]
0000714ce89e3559  vmovaps xmm13, [rsp+0xD0]
0000714ce89e3562  vmovaps xmm15, [rsp+0xE0]
0000714ce89e356b  add rsp, 0xF0
0000714ce89e3572  pop r11
0000714ce89e3574  pop r10
0000714ce89e3576  pop r9
0000714ce89e3578  pop r8
0000714ce89e357a  pop rsi
0000714ce89e357b  pop rdi
0000714ce89e357c  pop rdx
0000714ce89e357d  pop rcx
0000714ce89e357e  pop rax
0000714ce89e357f  add rsp, 0x08
0000714ce89e3583  jmp 0x0000714CE89DF793
0000714ce89e3588  sub rsp, 0x08
0000714ce89e358c  push rax
0000714ce89e358d  push rcx
0000714ce89e358e  push rdx
0000714ce89e358f  push rdi
0000714ce89e3590  push rsi
0000714ce89e3591  push r8
0000714ce89e3593  push r9
0000714ce89e3595  push r10
0000714ce89e3597  push r11
0000714ce89e3599  sub rsp, 0xF0
0000714ce89e35a0  vmovaps [rsp], xmm0
0000714ce89e35a5  vmovaps [rsp+0x10], xmm2
0000714ce89e35ab  vmovaps [rsp+0x20], xmm3
0000714ce89e35b1  vmovaps [rsp+0x30], xmm4
0000714ce89e35b7  vmovaps [rsp+0x40], xmm5
0000714ce89e35bd  vmovaps [rsp+0x50], xmm6
0000714ce89e35c3  vmovaps [rsp+0x60], xmm7
0000714ce89e35c9  vmovaps [rsp+0x70], xmm8
0000714ce89e35cf  vmovaps [rsp+0x80], xmm9
0000714ce89e35d8  vmovaps [rsp+0x90], xmm10
0000714ce89e35e1  vmovaps [rsp+0xA0], xmm11
0000714ce89e35ea  vmovaps [rsp+0xB0], xmm12
0000714ce89e35f3  vmovaps [rsp+0xC0], xmm13
0000714ce89e35fc  vmovaps [rsp+0xD0], xmm14
0000714ce89e3605  vmovaps [rsp+0xE0], xmm15
0000714ce89e360e  sub rsp, 0x30
0000714ce89e3612  movaps [rsp], xmm1
0000714ce89e3616  movaps [rsp+0x10], xmm13
0000714ce89e361c  movaps [rsp+0x20], xmm9
0000714ce89e3622  lea rdi, [rsp]
0000714ce89e3626  mov esi, 0x00
0000714ce89e362b  mov rax, 0x57A55D340530
0000714ce89e3635  call rax
0000714ce89e3637  movaps xmm1, [rsp]
0000714ce89e363b  add rsp, 0x30
0000714ce89e363f  vmovaps xmm0, [rsp]
0000714ce89e3644  vmovaps xmm2, [rsp+0x10]
0000714ce89e364a  vmovaps xmm3, [rsp+0x20]
0000714ce89e3650  vmovaps xmm4, [rsp+0x30]
0000714ce89e3656  vmovaps xmm5, [rsp+0x40]
0000714ce89e365c  vmovaps xmm6, [rsp+0x50]
0000714ce89e3662  vmovaps xmm7, [rsp+0x60]
0000714ce89e3668  vmovaps xmm8, [rsp+0x70]
0000714ce89e366e  vmovaps xmm9, [rsp+0x80]
0000714ce89e3677  vmovaps xmm10, [rsp+0x90]
0000714ce89e3680  vmovaps xmm11, [rsp+0xA0]
0000714ce89e3689  vmovaps xmm12, [rsp+0xB0]
0000714ce89e3692  vmovaps xmm13, [rsp+0xC0]
0000714ce89e369b  vmovaps xmm14, [rsp+0xD0]
0000714ce89e36a4  vmovaps xmm15, [rsp+0xE0]
0000714ce89e36ad  add rsp, 0xF0
0000714ce89e36b4  pop r11
0000714ce89e36b6  pop r10
0000714ce89e36b8  pop r9
0000714ce89e36ba  pop r8
0000714ce89e36bc  pop rsi
0000714ce89e36bd  pop rdi
0000714ce89e36be  pop rdx
0000714ce89e36bf  pop rcx
0000714ce89e36c0  pop rax
0000714ce89e36c1  add rsp, 0x08
0000714ce89e36c5  jmp 0x0000714CE89DF7AD
0000714ce89e36ca  sub rsp, 0x08
0000714ce89e36ce  push rax
0000714ce89e36cf  push rcx
0000714ce89e36d0  push rdx
0000714ce89e36d1  push rdi
0000714ce89e36d2  push rsi
0000714ce89e36d3  push r8
0000714ce89e36d5  push r9
0000714ce89e36d7  push r10
0000714ce89e36d9  push r11
0000714ce89e36db  sub rsp, 0xF0
0000714ce89e36e2  vmovaps [rsp], xmm0
0000714ce89e36e7  vmovaps [rsp+0x10], xmm1
0000714ce89e36ed  vmovaps [rsp+0x20], xmm2
0000714ce89e36f3  vmovaps [rsp+0x30], xmm3
0000714ce89e36f9  vmovaps [rsp+0x40], xmm4
0000714ce89e36ff  vmovaps [rsp+0x50], xmm5
0000714ce89e3705  vmovaps [rsp+0x60], xmm6
0000714ce89e370b  vmovaps [rsp+0x70], xmm7
0000714ce89e3711  vmovaps [rsp+0x80], xmm8
0000714ce89e371a  vmovaps [rsp+0x90], xmm9
0000714ce89e3723  vmovaps [rsp+0xA0], xmm10
0000714ce89e372c  vmovaps [rsp+0xB0], xmm11
0000714ce89e3735  vmovaps [rsp+0xC0], xmm13
0000714ce89e373e  vmovaps [rsp+0xD0], xmm14
0000714ce89e3747  vmovaps [rsp+0xE0], xmm15
0000714ce89e3750  sub rsp, 0x30
0000714ce89e3754  movaps [rsp], xmm12
0000714ce89e3759  movaps [rsp+0x10], xmm7
0000714ce89e375e  movaps [rsp+0x20], xmm13
0000714ce89e3764  lea rdi, [rsp]
0000714ce89e3768  mov esi, 0x00
0000714ce89e376d  mov rax, 0x57A55D340530
0000714ce89e3777  call rax
0000714ce89e3779  movaps xmm12, [rsp]
0000714ce89e377e  add rsp, 0x30
0000714ce89e3782  vmovaps xmm0, [rsp]
0000714ce89e3787  vmovaps xmm1, [rsp+0x10]
0000714ce89e378d  vmovaps xmm2, [rsp+0x20]
0000714ce89e3793  vmovaps xmm3, [rsp+0x30]
0000714ce89e3799  vmovaps xmm4, [rsp+0x40]
0000714ce89e379f  vmovaps xmm5, [rsp+0x50]
0000714ce89e37a5  vmovaps xmm6, [rsp+0x60]
0000714ce89e37ab  vmovaps xmm7, [rsp+0x70]
0000714ce89e37b1  vmovaps xmm8, [rsp+0x80]
0000714ce89e37ba  vmovaps xmm9, [rsp+0x90]
0000714ce89e37c3  vmovaps xmm10, [rsp+0xA0]
0000714ce89e37cc  vmovaps xmm11, [rsp+0xB0]
0000714ce89e37d5  vmovaps xmm13, [rsp+0xC0]
0000714ce89e37de  vmovaps xmm14, [rsp+0xD0]
0000714ce89e37e7  vmovaps xmm15, [rsp+0xE0]
0000714ce89e37f0  add rsp, 0xF0
0000714ce89e37f7  pop r11
0000714ce89e37f9  pop r10
0000714ce89e37fb  pop r9
0000714ce89e37fd  pop r8
0000714ce89e37ff  pop rsi
0000714ce89e3800  pop rdi
0000714ce89e3801  pop rdx
0000714ce89e3802  pop rcx
0000714ce89e3803  pop rax
0000714ce89e3804  add rsp, 0x08
0000714ce89e3808  jmp 0x0000714CE89DF7D4
0000714ce89e380d  sub rsp, 0x08
0000714ce89e3811  push rax
0000714ce89e3812  push rcx
0000714ce89e3813  push rdx
0000714ce89e3814  push rdi
0000714ce89e3815  push rsi
0000714ce89e3816  push r8
0000714ce89e3818  push r9
0000714ce89e381a  push r10
0000714ce89e381c  push r11
0000714ce89e381e  sub rsp, 0xF0
0000714ce89e3825  vmovaps [rsp], xmm0
0000714ce89e382a  vmovaps [rsp+0x10], xmm1
0000714ce89e3830  vmovaps [rsp+0x20], xmm2
0000714ce89e3836  vmovaps [rsp+0x30], xmm3
0000714ce89e383c  vmovaps [rsp+0x40], xmm4
0000714ce89e3842  vmovaps [rsp+0x50], xmm5
0000714ce89e3848  vmovaps [rsp+0x60], xmm6
0000714ce89e384e  vmovaps [rsp+0x70], xmm7
0000714ce89e3854  vmovaps [rsp+0x80], xmm8
0000714ce89e385d  vmovaps [rsp+0x90], xmm9
0000714ce89e3866  vmovaps [rsp+0xA0], xmm10
0000714ce89e386f  vmovaps [rsp+0xB0], xmm11
0000714ce89e3878  vmovaps [rsp+0xC0], xmm12
0000714ce89e3881  vmovaps [rsp+0xD0], xmm14
0000714ce89e388a  vmovaps [rsp+0xE0], xmm15
0000714ce89e3893  sub rsp, 0x30
0000714ce89e3897  movaps [rsp], xmm13
0000714ce89e389c  movaps [rsp+0x10], xmm15
0000714ce89e38a2  movaps [rsp+0x20], xmm8
0000714ce89e38a8  lea rdi, [rsp]
0000714ce89e38ac  mov esi, 0x00
0000714ce89e38b1  mov rax, 0x57A55D340530
0000714ce89e38bb  call rax
0000714ce89e38bd  movaps xmm13, [rsp]
0000714ce89e38c2  add rsp, 0x30
0000714ce89e38c6  vmovaps xmm0, [rsp]
0000714ce89e38cb  vmovaps xmm1, [rsp+0x10]
0000714ce89e38d1  vmovaps xmm2, [rsp+0x20]
0000714ce89e38d7  vmovaps xmm3, [rsp+0x30]
0000714ce89e38dd  vmovaps xmm4, [rsp+0x40]
0000714ce89e38e3  vmovaps xmm5, [rsp+0x50]
0000714ce89e38e9  vmovaps xmm6, [rsp+0x60]
0000714ce89e38ef  vmovaps xmm7, [rsp+0x70]
0000714ce89e38f5  vmovaps xmm8, [rsp+0x80]
0000714ce89e38fe  vmovaps xmm9, [rsp+0x90]
0000714ce89e3907  vmovaps xmm10, [rsp+0xA0]
0000714ce89e3910  vmovaps xmm11, [rsp+0xB0]
0000714ce89e3919  vmovaps xmm12, [rsp+0xC0]
0000714ce89e3922  vmovaps xmm14, [rsp+0xD0]
0000714ce89e392b  vmovaps xmm15, [rsp+0xE0]
0000714ce89e3934  add rsp, 0xF0
0000714ce89e393b  pop r11
0000714ce89e393d  pop r10
0000714ce89e393f  pop r9
0000714ce89e3941  pop r8
0000714ce89e3943  pop rsi
0000714ce89e3944  pop rdi
0000714ce89e3945  pop rdx
0000714ce89e3946  pop rcx
0000714ce89e3947  pop rax
0000714ce89e3948  add rsp, 0x08
0000714ce89e394c  jmp 0x0000714CE89DF7EF
0000714ce89e3951  sub rsp, 0x08
0000714ce89e3955  push rax
0000714ce89e3956  push rcx
0000714ce89e3957  push rdx
0000714ce89e3958  push rdi
0000714ce89e3959  push rsi
0000714ce89e395a  push r8
0000714ce89e395c  push r9
0000714ce89e395e  push r10
0000714ce89e3960  push r11
0000714ce89e3962  sub rsp, 0xF0
0000714ce89e3969  vmovaps [rsp], xmm0
0000714ce89e396e  vmovaps [rsp+0x10], xmm1
0000714ce89e3974  vmovaps [rsp+0x20], xmm2
0000714ce89e397a  vmovaps [rsp+0x30], xmm3
0000714ce89e3980  vmovaps [rsp+0x40], xmm4
0000714ce89e3986  vmovaps [rsp+0x50], xmm5
0000714ce89e398c  vmovaps [rsp+0x60], xmm6
0000714ce89e3992  vmovaps [rsp+0x70], xmm7
0000714ce89e3998  vmovaps [rsp+0x80], xmm9
0000714ce89e39a1  vmovaps [rsp+0x90], xmm10
0000714ce89e39aa  vmovaps [rsp+0xA0], xmm11
0000714ce89e39b3  vmovaps [rsp+0xB0], xmm12
0000714ce89e39bc  vmovaps [rsp+0xC0], xmm13
0000714ce89e39c5  vmovaps [rsp+0xD0], xmm14
0000714ce89e39ce  vmovaps [rsp+0xE0], xmm15
0000714ce89e39d7  sub rsp, 0x30
0000714ce89e39db  movaps [rsp], xmm8
0000714ce89e39e0  movaps [rsp+0x10], xmm15
0000714ce89e39e6  movaps [rsp+0x20], xmm9
0000714ce89e39ec  lea rdi, [rsp]
0000714ce89e39f0  mov esi, 0x00
0000714ce89e39f5  mov rax, 0x57A55D340530
0000714ce89e39ff  call rax
0000714ce89e3a01  movaps xmm8, [rsp]
0000714ce89e3a06  add rsp, 0x30
0000714ce89e3a0a  vmovaps xmm0, [rsp]
0000714ce89e3a0f  vmovaps xmm1, [rsp+0x10]
0000714ce89e3a15  vmovaps xmm2, [rsp+0x20]
0000714ce89e3a1b  vmovaps xmm3, [rsp+0x30]
0000714ce89e3a21  vmovaps xmm4, [rsp+0x40]
0000714ce89e3a27  vmovaps xmm5, [rsp+0x50]
0000714ce89e3a2d  vmovaps xmm6, [rsp+0x60]
0000714ce89e3a33  vmovaps xmm7, [rsp+0x70]
0000714ce89e3a39  vmovaps xmm9, [rsp+0x80]
0000714ce89e3a42  vmovaps xmm10, [rsp+0x90]
0000714ce89e3a4b  vmovaps xmm11, [rsp+0xA0]
0000714ce89e3a54  vmovaps xmm12, [rsp+0xB0]
0000714ce89e3a5d  vmovaps xmm13, [rsp+0xC0]
0000714ce89e3a66  vmovaps xmm14, [rsp+0xD0]
0000714ce89e3a6f  vmovaps xmm15, [rsp+0xE0]
0000714ce89e3a78  add rsp, 0xF0
0000714ce89e3a7f  pop r11
0000714ce89e3a81  pop r10
0000714ce89e3a83  pop r9
0000714ce89e3a85  pop r8
0000714ce89e3a87  pop rsi
0000714ce89e3a88  pop rdi
0000714ce89e3a89  pop rdx
0000714ce89e3a8a  pop rcx
0000714ce89e3a8b  pop rax
0000714ce89e3a8c  add rsp, 0x08
0000714ce89e3a90  jmp 0x0000714CE89DF81D
0000714ce89e3a95  sub rsp, 0x08
0000714ce89e3a99  push rax
0000714ce89e3a9a  push rcx
0000714ce89e3a9b  push rdx
0000714ce89e3a9c  push rdi
0000714ce89e3a9d  push rsi
0000714ce89e3a9e  push r8
0000714ce89e3aa0  push r9
0000714ce89e3aa2  push r10
0000714ce89e3aa4  push r11
0000714ce89e3aa6  sub rsp, 0xF0
0000714ce89e3aad  vmovaps [rsp], xmm0
0000714ce89e3ab2  vmovaps [rsp+0x10], xmm1
0000714ce89e3ab8  vmovaps [rsp+0x20], xmm2
0000714ce89e3abe  vmovaps [rsp+0x30], xmm3
0000714ce89e3ac4  vmovaps [rsp+0x40], xmm4
0000714ce89e3aca  vmovaps [rsp+0x50], xmm5
0000714ce89e3ad0  vmovaps [rsp+0x60], xmm6
0000714ce89e3ad6  vmovaps [rsp+0x70], xmm7
0000714ce89e3adc  vmovaps [rsp+0x80], xmm8
0000714ce89e3ae5  vmovaps [rsp+0x90], xmm9
0000714ce89e3aee  vmovaps [rsp+0xA0], xmm10
0000714ce89e3af7  vmovaps [rsp+0xB0], xmm11
0000714ce89e3b00  vmovaps [rsp+0xC0], xmm12
0000714ce89e3b09  vmovaps [rsp+0xD0], xmm13
0000714ce89e3b12  vmovaps [rsp+0xE0], xmm14
0000714ce89e3b1b  sub rsp, 0x30
0000714ce89e3b1f  movaps [rsp], xmm15
0000714ce89e3b24  movaps [rsp+0x10], xmm11
0000714ce89e3b2a  movaps [rsp+0x20], xmm6
0000714ce89e3b2f  lea rdi, [rsp]
0000714ce89e3b33  mov esi, 0x00
0000714ce89e3b38  mov rax, 0x57A55D340530
0000714ce89e3b42  call rax
0000714ce89e3b44  movaps xmm15, [rsp]
0000714ce89e3b49  add rsp, 0x30
0000714ce89e3b4d  vmovaps xmm0, [rsp]
0000714ce89e3b52  vmovaps xmm1, [rsp+0x10]
0000714ce89e3b58  vmovaps xmm2, [rsp+0x20]
0000714ce89e3b5e  vmovaps xmm3, [rsp+0x30]
0000714ce89e3b64  vmovaps xmm4, [rsp+0x40]
0000714ce89e3b6a  vmovaps xmm5, [rsp+0x50]
0000714ce89e3b70  vmovaps xmm6, [rsp+0x60]
0000714ce89e3b76  vmovaps xmm7, [rsp+0x70]
0000714ce89e3b7c  vmovaps xmm8, [rsp+0x80]
0000714ce89e3b85  vmovaps xmm9, [rsp+0x90]
0000714ce89e3b8e  vmovaps xmm10, [rsp+0xA0]
0000714ce89e3b97  vmovaps xmm11, [rsp+0xB0]
0000714ce89e3ba0  vmovaps xmm12, [rsp+0xC0]
0000714ce89e3ba9  vmovaps xmm13, [rsp+0xD0]
0000714ce89e3bb2  vmovaps xmm14, [rsp+0xE0]
0000714ce89e3bbb  add rsp, 0xF0
0000714ce89e3bc2  pop r11
0000714ce89e3bc4  pop r10
0000714ce89e3bc6  pop r9
0000714ce89e3bc8  pop r8
0000714ce89e3bca  pop rsi
0000714ce89e3bcb  pop rdi
0000714ce89e3bcc  pop rdx
0000714ce89e3bcd  pop rcx
0000714ce89e3bce  pop rax
0000714ce89e3bcf  add rsp, 0x08
0000714ce89e3bd3  jmp 0x0000714CE89DF838
0000714ce89e3bd8  sub rsp, 0x08
0000714ce89e3bdc  push rax
0000714ce89e3bdd  push rcx
0000714ce89e3bde  push rdx
0000714ce89e3bdf  push rdi
0000714ce89e3be0  push rsi
0000714ce89e3be1  push r8
0000714ce89e3be3  push r9
0000714ce89e3be5  push r10
0000714ce89e3be7  push r11
0000714ce89e3be9  sub rsp, 0xF0
0000714ce89e3bf0  vmovaps [rsp], xmm0
0000714ce89e3bf5  vmovaps [rsp+0x10], xmm1
0000714ce89e3bfb  vmovaps [rsp+0x20], xmm2
0000714ce89e3c01  vmovaps [rsp+0x30], xmm3
0000714ce89e3c07  vmovaps [rsp+0x40], xmm4
0000714ce89e3c0d  vmovaps [rsp+0x50], xmm5
0000714ce89e3c13  vmovaps [rsp+0x60], xmm6
0000714ce89e3c19  vmovaps [rsp+0x70], xmm8
0000714ce89e3c1f  vmovaps [rsp+0x80], xmm9
0000714ce89e3c28  vmovaps [rsp+0x90], xmm10
0000714ce89e3c31  vmovaps [rsp+0xA0], xmm11
0000714ce89e3c3a  vmovaps [rsp+0xB0], xmm12
0000714ce89e3c43  vmovaps [rsp+0xC0], xmm13
0000714ce89e3c4c  vmovaps [rsp+0xD0], xmm14
0000714ce89e3c55  vmovaps [rsp+0xE0], xmm15
0000714ce89e3c5e  sub rsp, 0x30
0000714ce89e3c62  movaps [rsp], xmm7
0000714ce89e3c66  movaps [rsp+0x10], xmm11
0000714ce89e3c6c  movaps [rsp+0x20], xmm9
0000714ce89e3c72  lea rdi, [rsp]
0000714ce89e3c76  mov esi, 0x00
0000714ce89e3c7b  mov rax, 0x57A55D340530
0000714ce89e3c85  call rax
0000714ce89e3c87  movaps xmm7, [rsp]
0000714ce89e3c8b  add rsp, 0x30
0000714ce89e3c8f  vmovaps xmm0, [rsp]
0000714ce89e3c94  vmovaps xmm1, [rsp+0x10]
0000714ce89e3c9a  vmovaps xmm2, [rsp+0x20]
0000714ce89e3ca0  vmovaps xmm3, [rsp+0x30]
0000714ce89e3ca6  vmovaps xmm4, [rsp+0x40]
0000714ce89e3cac  vmovaps xmm5, [rsp+0x50]
0000714ce89e3cb2  vmovaps xmm6, [rsp+0x60]
0000714ce89e3cb8  vmovaps xmm8, [rsp+0x70]
0000714ce89e3cbe  vmovaps xmm9, [rsp+0x80]
0000714ce89e3cc7  vmovaps xmm10, [rsp+0x90]
0000714ce89e3cd0  vmovaps xmm11, [rsp+0xA0]
0000714ce89e3cd9  vmovaps xmm12, [rsp+0xB0]
0000714ce89e3ce2  vmovaps xmm13, [rsp+0xC0]
0000714ce89e3ceb  vmovaps xmm14, [rsp+0xD0]
0000714ce89e3cf4  vmovaps xmm15, [rsp+0xE0]
0000714ce89e3cfd  add rsp, 0xF0
0000714ce89e3d04  pop r11
0000714ce89e3d06  pop r10
0000714ce89e3d08  pop r9
0000714ce89e3d0a  pop r8
0000714ce89e3d0c  pop rsi
0000714ce89e3d0d  pop rdi
0000714ce89e3d0e  pop rdx
0000714ce89e3d0f  pop rcx
0000714ce89e3d10  pop rax
0000714ce89e3d11  add rsp, 0x08
0000714ce89e3d15  jmp 0x0000714CE89DF865
0000714ce89e3d1a  sub rsp, 0x08
0000714ce89e3d1e  push rax
0000714ce89e3d1f  push rcx
0000714ce89e3d20  push rdx
0000714ce89e3d21  push rdi
0000714ce89e3d22  push rsi
0000714ce89e3d23  push r8
0000714ce89e3d25  push r9
0000714ce89e3d27  push r10
0000714ce89e3d29  push r11
0000714ce89e3d2b  sub rsp, 0xF0
0000714ce89e3d32  vmovaps [rsp], xmm0
0000714ce89e3d37  vmovaps [rsp+0x10], xmm1
0000714ce89e3d3d  vmovaps [rsp+0x20], xmm2
0000714ce89e3d43  vmovaps [rsp+0x30], xmm3
0000714ce89e3d49  vmovaps [rsp+0x40], xmm4
0000714ce89e3d4f  vmovaps [rsp+0x50], xmm5
0000714ce89e3d55  vmovaps [rsp+0x60], xmm6
0000714ce89e3d5b  vmovaps [rsp+0x70], xmm7
0000714ce89e3d61  vmovaps [rsp+0x80], xmm8
0000714ce89e3d6a  vmovaps [rsp+0x90], xmm9
0000714ce89e3d73  vmovaps [rsp+0xA0], xmm10
0000714ce89e3d7c  vmovaps [rsp+0xB0], xmm12
0000714ce89e3d85  vmovaps [rsp+0xC0], xmm13
0000714ce89e3d8e  vmovaps [rsp+0xD0], xmm14
0000714ce89e3d97  vmovaps [rsp+0xE0], xmm15
0000714ce89e3da0  sub rsp, 0x30
0000714ce89e3da4  movaps [rsp], xmm11
0000714ce89e3da9  movaps [rsp+0x10], xmm10
0000714ce89e3daf  movaps [rsp+0x20], xmm14
0000714ce89e3db5  lea rdi, [rsp]
0000714ce89e3db9  mov esi, 0x00
0000714ce89e3dbe  mov rax, 0x57A55D340530
0000714ce89e3dc8  call rax
0000714ce89e3dca  movaps xmm11, [rsp]
0000714ce89e3dcf  add rsp, 0x30
0000714ce89e3dd3  vmovaps xmm0, [rsp]
0000714ce89e3dd8  vmovaps xmm1, [rsp+0x10]
0000714ce89e3dde  vmovaps xmm2, [rsp+0x20]
0000714ce89e3de4  vmovaps xmm3, [rsp+0x30]
0000714ce89e3dea  vmovaps xmm4, [rsp+0x40]
0000714ce89e3df0  vmovaps xmm5, [rsp+0x50]
0000714ce89e3df6  vmovaps xmm6, [rsp+0x60]
0000714ce89e3dfc  vmovaps xmm7, [rsp+0x70]
0000714ce89e3e02  vmovaps xmm8, [rsp+0x80]
0000714ce89e3e0b  vmovaps xmm9, [rsp+0x90]
0000714ce89e3e14  vmovaps xmm10, [rsp+0xA0]
0000714ce89e3e1d  vmovaps xmm12, [rsp+0xB0]
0000714ce89e3e26  vmovaps xmm13, [rsp+0xC0]
0000714ce89e3e2f  vmovaps xmm14, [rsp+0xD0]
0000714ce89e3e38  vmovaps xmm15, [rsp+0xE0]
0000714ce89e3e41  add rsp, 0xF0
0000714ce89e3e48  pop r11
0000714ce89e3e4a  pop r10
0000714ce89e3e4c  pop r9
0000714ce89e3e4e  pop r8
0000714ce89e3e50  pop rsi
0000714ce89e3e51  pop rdi
0000714ce89e3e52  pop rdx
0000714ce89e3e53  pop rcx
0000714ce89e3e54  pop rax
0000714ce89e3e55  add rsp, 0x08
0000714ce89e3e59  jmp 0x0000714CE89DF880
0000714ce89e3e5e  call 0x0000714CE88C33A0
0000714ce89e3e63  jmp 0x0000714CE89DF88A
0000714ce89e3e68  sub rsp, 0x08
0000714ce89e3e6c  push rax
0000714ce89e3e6d  push rcx
0000714ce89e3e6e  push rdx
0000714ce89e3e6f  push rdi
0000714ce89e3e70  push rsi
0000714ce89e3e71  push r8
0000714ce89e3e73  push r9
0000714ce89e3e75  push r10
0000714ce89e3e77  push r11
0000714ce89e3e79  sub rsp, 0xF0
0000714ce89e3e80  vmovaps [rsp], xmm0
0000714ce89e3e85  vmovaps [rsp+0x10], xmm1
0000714ce89e3e8b  vmovaps [rsp+0x20], xmm2
0000714ce89e3e91  vmovaps [rsp+0x30], xmm3
0000714ce89e3e97  vmovaps [rsp+0x40], xmm4
0000714ce89e3e9d  vmovaps [rsp+0x50], xmm5
0000714ce89e3ea3  vmovaps [rsp+0x60], xmm6
0000714ce89e3ea9  vmovaps [rsp+0x70], xmm7
0000714ce89e3eaf  vmovaps [rsp+0x80], xmm8
0000714ce89e3eb8  vmovaps [rsp+0x90], xmm9
0000714ce89e3ec1  vmovaps [rsp+0xA0], xmm11
0000714ce89e3eca  vmovaps [rsp+0xB0], xmm12
0000714ce89e3ed3  vmovaps [rsp+0xC0], xmm13
0000714ce89e3edc  vmovaps [rsp+0xD0], xmm14
0000714ce89e3ee5  vmovaps [rsp+0xE0], xmm15
0000714ce89e3eee  sub rsp, 0x30
0000714ce89e3ef2  movaps [rsp], xmm10
0000714ce89e3ef7  movaps [rsp+0x10], xmm1
0000714ce89e3efc  movaps [rsp+0x20], xmm12
0000714ce89e3f02  lea rdi, [rsp]
0000714ce89e3f06  mov esi, 0x00
0000714ce89e3f0b  mov rax, 0x57A55D340530
0000714ce89e3f15  call rax
0000714ce89e3f17  movaps xmm10, [rsp]
0000714ce89e3f1c  add rsp, 0x30
0000714ce89e3f20  vmovaps xmm0, [rsp]
0000714ce89e3f25  vmovaps xmm1, [rsp+0x10]
0000714ce89e3f2b  vmovaps xmm2, [rsp+0x20]
0000714ce89e3f31  vmovaps xmm3, [rsp+0x30]
0000714ce89e3f37  vmovaps xmm4, [rsp+0x40]
0000714ce89e3f3d  vmovaps xmm5, [rsp+0x50]
0000714ce89e3f43  vmovaps xmm6, [rsp+0x60]
0000714ce89e3f49  vmovaps xmm7, [rsp+0x70]
0000714ce89e3f4f  vmovaps xmm8, [rsp+0x80]
0000714ce89e3f58  vmovaps xmm9, [rsp+0x90]
0000714ce89e3f61  vmovaps xmm11, [rsp+0xA0]
0000714ce89e3f6a  vmovaps xmm12, [rsp+0xB0]
0000714ce89e3f73  vmovaps xmm13, [rsp+0xC0]
0000714ce89e3f7c  vmovaps xmm14, [rsp+0xD0]
0000714ce89e3f85  vmovaps xmm15, [rsp+0xE0]
0000714ce89e3f8e  add rsp, 0xF0
0000714ce89e3f95  pop r11
0000714ce89e3f97  pop r10
0000714ce89e3f99  pop r9
0000714ce89e3f9b  pop r8
0000714ce89e3f9d  pop rsi
0000714ce89e3f9e  pop rdi
0000714ce89e3f9f  pop rdx
0000714ce89e3fa0  pop rcx
0000714ce89e3fa1  pop rax
0000714ce89e3fa2  add rsp, 0x08
0000714ce89e3fa6  jmp 0x0000714CE89DF8AD
0000714ce89e3fab  sub rsp, 0x08
0000714ce89e3faf  push rax
0000714ce89e3fb0  push rcx
0000714ce89e3fb1  push rdx
0000714ce89e3fb2  push rdi
0000714ce89e3fb3  push rsi
0000714ce89e3fb4  push r8
0000714ce89e3fb6  push r9
0000714ce89e3fb8  push r10
0000714ce89e3fba  push r11
0000714ce89e3fbc  sub rsp, 0xF0
0000714ce89e3fc3  vmovaps [rsp], xmm0
0000714ce89e3fc8  vmovaps [rsp+0x10], xmm1
0000714ce89e3fce  vmovaps [rsp+0x20], xmm2
0000714ce89e3fd4  vmovaps [rsp+0x30], xmm3
0000714ce89e3fda  vmovaps [rsp+0x40], xmm4
0000714ce89e3fe0  vmovaps [rsp+0x50], xmm5
0000714ce89e3fe6  vmovaps [rsp+0x60], xmm6
0000714ce89e3fec  vmovaps [rsp+0x70], xmm7
0000714ce89e3ff2  vmovaps [rsp+0x80], xmm8
0000714ce89e3ffb  vmovaps [rsp+0x90], xmm9
0000714ce89e4004  vmovaps [rsp+0xA0], xmm10
0000714ce89e400d  vmovaps [rsp+0xB0], xmm11
0000714ce89e4016  vmovaps [rsp+0xC0], xmm13
0000714ce89e401f  vmovaps [rsp+0xD0], xmm14
0000714ce89e4028  vmovaps [rsp+0xE0], xmm15
0000714ce89e4031  sub rsp, 0x30
0000714ce89e4035  movaps [rsp], xmm12
0000714ce89e403a  movaps [rsp+0x10], xmm14
0000714ce89e4040  movaps [rsp+0x20], xmm1
0000714ce89e4045  lea rdi, [rsp]
0000714ce89e4049  mov esi, 0x00
0000714ce89e404e  mov rax, 0x57A55D340530
0000714ce89e4058  call rax
0000714ce89e405a  movaps xmm12, [rsp]
0000714ce89e405f  add rsp, 0x30
0000714ce89e4063  vmovaps xmm0, [rsp]
0000714ce89e4068  vmovaps xmm1, [rsp+0x10]
0000714ce89e406e  vmovaps xmm2, [rsp+0x20]
0000714ce89e4074  vmovaps xmm3, [rsp+0x30]
0000714ce89e407a  vmovaps xmm4, [rsp+0x40]
0000714ce89e4080  vmovaps xmm5, [rsp+0x50]
0000714ce89e4086  vmovaps xmm6, [rsp+0x60]
0000714ce89e408c  vmovaps xmm7, [rsp+0x70]
0000714ce89e4092  vmovaps xmm8, [rsp+0x80]
0000714ce89e409b  vmovaps xmm9, [rsp+0x90]
0000714ce89e40a4  vmovaps xmm10, [rsp+0xA0]
0000714ce89e40ad  vmovaps xmm11, [rsp+0xB0]
0000714ce89e40b6  vmovaps xmm13, [rsp+0xC0]
0000714ce89e40bf  vmovaps xmm14, [rsp+0xD0]
0000714ce89e40c8  vmovaps xmm15, [rsp+0xE0]
0000714ce89e40d1  add rsp, 0xF0
0000714ce89e40d8  pop r11
0000714ce89e40da  pop r10
0000714ce89e40dc  pop r9
0000714ce89e40de  pop r8
0000714ce89e40e0  pop rsi
0000714ce89e40e1  pop rdi
0000714ce89e40e2  pop rdx
0000714ce89e40e3  pop rcx
0000714ce89e40e4  pop rax
0000714ce89e40e5  add rsp, 0x08
0000714ce89e40e9  jmp 0x0000714CE89DF8DC
0000714ce89e40ee  sub rsp, 0x08
0000714ce89e40f2  push rax
0000714ce89e40f3  push rcx
0000714ce89e40f4  push rdx
0000714ce89e40f5  push rdi
0000714ce89e40f6  push rsi
0000714ce89e40f7  push r8
0000714ce89e40f9  push r9
0000714ce89e40fb  push r10
0000714ce89e40fd  push r11
0000714ce89e40ff  sub rsp, 0xF0
0000714ce89e4106  vmovaps [rsp], xmm0
0000714ce89e410b  vmovaps [rsp+0x10], xmm1
0000714ce89e4111  vmovaps [rsp+0x20], xmm2
0000714ce89e4117  vmovaps [rsp+0x30], xmm3
0000714ce89e411d  vmovaps [rsp+0x40], xmm4
0000714ce89e4123  vmovaps [rsp+0x50], xmm5
0000714ce89e4129  vmovaps [rsp+0x60], xmm6
0000714ce89e412f  vmovaps [rsp+0x70], xmm7
0000714ce89e4135  vmovaps [rsp+0x80], xmm8
0000714ce89e413e  vmovaps [rsp+0x90], xmm9
0000714ce89e4147  vmovaps [rsp+0xA0], xmm10
0000714ce89e4150  vmovaps [rsp+0xB0], xmm11
0000714ce89e4159  vmovaps [rsp+0xC0], xmm12
0000714ce89e4162  vmovaps [rsp+0xD0], xmm13
0000714ce89e416b  vmovaps [rsp+0xE0], xmm15
0000714ce89e4174  sub rsp, 0x30
0000714ce89e4178  movaps [rsp], xmm14
0000714ce89e417d  movaps [rsp+0x10], xmm9
0000714ce89e4183  movaps [rsp+0x20], xmm1
0000714ce89e4188  lea rdi, [rsp]
0000714ce89e418c  mov esi, 0x00
0000714ce89e4191  mov rax, 0x57A55D340530
0000714ce89e419b  call rax
0000714ce89e419d  movaps xmm14, [rsp]
0000714ce89e41a2  add rsp, 0x30
0000714ce89e41a6  vmovaps xmm0, [rsp]
0000714ce89e41ab  vmovaps xmm1, [rsp+0x10]
0000714ce89e41b1  vmovaps xmm2, [rsp+0x20]
0000714ce89e41b7  vmovaps xmm3, [rsp+0x30]
0000714ce89e41bd  vmovaps xmm4, [rsp+0x40]
0000714ce89e41c3  vmovaps xmm5, [rsp+0x50]
0000714ce89e41c9  vmovaps xmm6, [rsp+0x60]
0000714ce89e41cf  vmovaps xmm7, [rsp+0x70]
0000714ce89e41d5  vmovaps xmm8, [rsp+0x80]
0000714ce89e41de  vmovaps xmm9, [rsp+0x90]
0000714ce89e41e7  vmovaps xmm10, [rsp+0xA0]
0000714ce89e41f0  vmovaps xmm11, [rsp+0xB0]
0000714ce89e41f9  vmovaps xmm12, [rsp+0xC0]
0000714ce89e4202  vmovaps xmm13, [rsp+0xD0]
0000714ce89e420b  vmovaps xmm15, [rsp+0xE0]
0000714ce89e4214  add rsp, 0xF0
0000714ce89e421b  pop r11
0000714ce89e421d  pop r10
0000714ce89e421f  pop r9
0000714ce89e4221  pop r8
0000714ce89e4223  pop rsi
0000714ce89e4224  pop rdi
0000714ce89e4225  pop rdx
0000714ce89e4226  pop rcx
0000714ce89e4227  pop rax
0000714ce89e4228  add rsp, 0x08
0000714ce89e422c  jmp 0x0000714CE89DF90B
0000714ce89e4231  sub rsp, 0x08
0000714ce89e4235  push rax
0000714ce89e4236  push rcx
0000714ce89e4237  push rdx
0000714ce89e4238  push rdi
0000714ce89e4239  push rsi
0000714ce89e423a  push r8
0000714ce89e423c  push r9
0000714ce89e423e  push r10
0000714ce89e4240  push r11
0000714ce89e4242  sub rsp, 0xF0
0000714ce89e4249  vmovaps [rsp], xmm0
0000714ce89e424e  vmovaps [rsp+0x10], xmm2
0000714ce89e4254  vmovaps [rsp+0x20], xmm3
0000714ce89e425a  vmovaps [rsp+0x30], xmm4
0000714ce89e4260  vmovaps [rsp+0x40], xmm5
0000714ce89e4266  vmovaps [rsp+0x50], xmm6
0000714ce89e426c  vmovaps [rsp+0x60], xmm7
0000714ce89e4272  vmovaps [rsp+0x70], xmm8
0000714ce89e4278  vmovaps [rsp+0x80], xmm9
0000714ce89e4281  vmovaps [rsp+0x90], xmm10
0000714ce89e428a  vmovaps [rsp+0xA0], xmm11
0000714ce89e4293  vmovaps [rsp+0xB0], xmm12
0000714ce89e429c  vmovaps [rsp+0xC0], xmm13
0000714ce89e42a5  vmovaps [rsp+0xD0], xmm14
0000714ce89e42ae  vmovaps [rsp+0xE0], xmm15
0000714ce89e42b7  sub rsp, 0x30
0000714ce89e42bb  movaps [rsp], xmm1
0000714ce89e42bf  movaps [rsp+0x10], xmm13
0000714ce89e42c5  movaps [rsp+0x20], xmm8
0000714ce89e42cb  lea rdi, [rsp]
0000714ce89e42cf  mov esi, 0x00
0000714ce89e42d4  mov rax, 0x57A55D340530
0000714ce89e42de  call rax
0000714ce89e42e0  movaps xmm1, [rsp]
0000714ce89e42e4  add rsp, 0x30
0000714ce89e42e8  vmovaps xmm0, [rsp]
0000714ce89e42ed  vmovaps xmm2, [rsp+0x10]
0000714ce89e42f3  vmovaps xmm3, [rsp+0x20]
0000714ce89e42f9  vmovaps xmm4, [rsp+0x30]
0000714ce89e42ff  vmovaps xmm5, [rsp+0x40]
0000714ce89e4305  vmovaps xmm6, [rsp+0x50]
0000714ce89e430b  vmovaps xmm7, [rsp+0x60]
0000714ce89e4311  vmovaps xmm8, [rsp+0x70]
0000714ce89e4317  vmovaps xmm9, [rsp+0x80]
0000714ce89e4320  vmovaps xmm10, [rsp+0x90]
0000714ce89e4329  vmovaps xmm11, [rsp+0xA0]
0000714ce89e4332  vmovaps xmm12, [rsp+0xB0]
0000714ce89e433b  vmovaps xmm13, [rsp+0xC0]
0000714ce89e4344  vmovaps xmm14, [rsp+0xD0]
0000714ce89e434d  vmovaps xmm15, [rsp+0xE0]
0000714ce89e4356  add rsp, 0xF0
0000714ce89e435d  pop r11
0000714ce89e435f  pop r10
0000714ce89e4361  pop r9
0000714ce89e4363  pop r8
0000714ce89e4365  pop rsi
0000714ce89e4366  pop rdi
0000714ce89e4367  pop rdx
0000714ce89e4368  pop rcx
0000714ce89e4369  pop rax
0000714ce89e436a  add rsp, 0x08
0000714ce89e436e  jmp 0x0000714CE89DF92D
0000714ce89e4373  call 0x0000714CE880C260
0000714ce89e4378  jmp 0x0000714CE89DF93B
0000714ce89e437d  call 0x0000714CE88BD750
0000714ce89e4382  jmp 0x0000714CE89DF945
0000714ce89e4387  sub rsp, 0x08
0000714ce89e438b  push rax
0000714ce89e438c  push rcx
0000714ce89e438d  push rdx
0000714ce89e438e  push rdi
0000714ce89e438f  push rsi
0000714ce89e4390  push r8
0000714ce89e4392  push r9
0000714ce89e4394  push r10
0000714ce89e4396  push r11
0000714ce89e4398  sub rsp, 0xF0
0000714ce89e439f  vmovaps [rsp], xmm0
0000714ce89e43a4  vmovaps [rsp+0x10], xmm1
0000714ce89e43aa  vmovaps [rsp+0x20], xmm2
0000714ce89e43b0  vmovaps [rsp+0x30], xmm3
0000714ce89e43b6  vmovaps [rsp+0x40], xmm4
0000714ce89e43bc  vmovaps [rsp+0x50], xmm5
0000714ce89e43c2  vmovaps [rsp+0x60], xmm6
0000714ce89e43c8  vmovaps [rsp+0x70], xmm7
0000714ce89e43ce  vmovaps [rsp+0x80], xmm9
0000714ce89e43d7  vmovaps [rsp+0x90], xmm10
0000714ce89e43e0  vmovaps [rsp+0xA0], xmm11
0000714ce89e43e9  vmovaps [rsp+0xB0], xmm12
0000714ce89e43f2  vmovaps [rsp+0xC0], xmm13
0000714ce89e43fb  vmovaps [rsp+0xD0], xmm14
0000714ce89e4404  vmovaps [rsp+0xE0], xmm15
0000714ce89e440d  sub rsp, 0x30
0000714ce89e4411  movaps [rsp], xmm8
0000714ce89e4416  movaps [rsp+0x10], xmm15
0000714ce89e441c  movaps [rsp+0x20], xmm7
0000714ce89e4421  lea rdi, [rsp]
0000714ce89e4425  mov esi, 0x00
0000714ce89e442a  mov rax, 0x57A55D340530
0000714ce89e4434  call rax
0000714ce89e4436  movaps xmm8, [rsp]
0000714ce89e443b  add rsp, 0x30
0000714ce89e443f  vmovaps xmm0, [rsp]
0000714ce89e4444  vmovaps xmm1, [rsp+0x10]
0000714ce89e444a  vmovaps xmm2, [rsp+0x20]
0000714ce89e4450  vmovaps xmm3, [rsp+0x30]
0000714ce89e4456  vmovaps xmm4, [rsp+0x40]
0000714ce89e445c  vmovaps xmm5, [rsp+0x50]
0000714ce89e4462  vmovaps xmm6, [rsp+0x60]
0000714ce89e4468  vmovaps xmm7, [rsp+0x70]
0000714ce89e446e  vmovaps xmm9, [rsp+0x80]
0000714ce89e4477  vmovaps xmm10, [rsp+0x90]
0000714ce89e4480  vmovaps xmm11, [rsp+0xA0]
0000714ce89e4489  vmovaps xmm12, [rsp+0xB0]
0000714ce89e4492  vmovaps xmm13, [rsp+0xC0]
0000714ce89e449b  vmovaps xmm14, [rsp+0xD0]
0000714ce89e44a4  vmovaps xmm15, [rsp+0xE0]
0000714ce89e44ad  add rsp, 0xF0
0000714ce89e44b4  pop r11
0000714ce89e44b6  pop r10
0000714ce89e44b8  pop r9
0000714ce89e44ba  pop r8
0000714ce89e44bc  pop rsi
0000714ce89e44bd  pop rdi
0000714ce89e44be  pop rdx
0000714ce89e44bf  pop rcx
0000714ce89e44c0  pop rax
0000714ce89e44c1  add rsp, 0x08
0000714ce89e44c5  jmp 0x0000714CE89DF967
0000714ce89e44ca  sub rsp, 0x08
0000714ce89e44ce  push rax
0000714ce89e44cf  push rcx
0000714ce89e44d0  push rdx
0000714ce89e44d1  push rdi
0000714ce89e44d2  push rsi
0000714ce89e44d3  push r8
0000714ce89e44d5  push r9
0000714ce89e44d7  push r10
0000714ce89e44d9  push r11
0000714ce89e44db  sub rsp, 0xF0
0000714ce89e44e2  vmovaps [rsp], xmm0
0000714ce89e44e7  vmovaps [rsp+0x10], xmm1
0000714ce89e44ed  vmovaps [rsp+0x20], xmm2
0000714ce89e44f3  vmovaps [rsp+0x30], xmm3
0000714ce89e44f9  vmovaps [rsp+0x40], xmm4
0000714ce89e44ff  vmovaps [rsp+0x50], xmm5
0000714ce89e4505  vmovaps [rsp+0x60], xmm6
0000714ce89e450b  vmovaps [rsp+0x70], xmm8
0000714ce89e4511  vmovaps [rsp+0x80], xmm9
0000714ce89e451a  vmovaps [rsp+0x90], xmm10
0000714ce89e4523  vmovaps [rsp+0xA0], xmm11
0000714ce89e452c  vmovaps [rsp+0xB0], xmm12
0000714ce89e4535  vmovaps [rsp+0xC0], xmm13
0000714ce89e453e  vmovaps [rsp+0xD0], xmm14
0000714ce89e4547  vmovaps [rsp+0xE0], xmm15
0000714ce89e4550  sub rsp, 0x30
0000714ce89e4554  movaps [rsp], xmm7
0000714ce89e4558  movaps [rsp+0x10], xmm9
0000714ce89e455e  movaps [rsp+0x20], xmm15
0000714ce89e4564  lea rdi, [rsp]
0000714ce89e4568  mov esi, 0x00
0000714ce89e456d  mov rax, 0x57A55D340530
0000714ce89e4577  call rax
0000714ce89e4579  movaps xmm7, [rsp]
0000714ce89e457d  add rsp, 0x30
0000714ce89e4581  vmovaps xmm0, [rsp]
0000714ce89e4586  vmovaps xmm1, [rsp+0x10]
0000714ce89e458c  vmovaps xmm2, [rsp+0x20]
0000714ce89e4592  vmovaps xmm3, [rsp+0x30]
0000714ce89e4598  vmovaps xmm4, [rsp+0x40]
0000714ce89e459e  vmovaps xmm5, [rsp+0x50]
0000714ce89e45a4  vmovaps xmm6, [rsp+0x60]
0000714ce89e45aa  vmovaps xmm8, [rsp+0x70]
0000714ce89e45b0  vmovaps xmm9, [rsp+0x80]
0000714ce89e45b9  vmovaps xmm10, [rsp+0x90]
0000714ce89e45c2  vmovaps xmm11, [rsp+0xA0]
0000714ce89e45cb  vmovaps xmm12, [rsp+0xB0]
0000714ce89e45d4  vmovaps xmm13, [rsp+0xC0]
0000714ce89e45dd  vmovaps xmm14, [rsp+0xD0]
0000714ce89e45e6  vmovaps xmm15, [rsp+0xE0]
0000714ce89e45ef  add rsp, 0xF0
0000714ce89e45f6  pop r11
0000714ce89e45f8  pop r10
0000714ce89e45fa  pop r9
0000714ce89e45fc  pop r8
0000714ce89e45fe  pop rsi
0000714ce89e45ff  pop rdi
0000714ce89e4600  pop rdx
0000714ce89e4601  pop rcx
0000714ce89e4602  pop rax
0000714ce89e4603  add rsp, 0x08
0000714ce89e4607  jmp 0x0000714CE89DF994
0000714ce89e460c  sub rsp, 0x08
0000714ce89e4610  push rax
0000714ce89e4611  push rcx
0000714ce89e4612  push rdx
0000714ce89e4613  push rdi
0000714ce89e4614  push rsi
0000714ce89e4615  push r8
0000714ce89e4617  push r9
0000714ce89e4619  push r10
0000714ce89e461b  push r11
0000714ce89e461d  sub rsp, 0xF0
0000714ce89e4624  vmovaps [rsp], xmm0
0000714ce89e4629  vmovaps [rsp+0x10], xmm1
0000714ce89e462f  vmovaps [rsp+0x20], xmm2
0000714ce89e4635  vmovaps [rsp+0x30], xmm3
0000714ce89e463b  vmovaps [rsp+0x40], xmm4
0000714ce89e4641  vmovaps [rsp+0x50], xmm5
0000714ce89e4647  vmovaps [rsp+0x60], xmm6
0000714ce89e464d  vmovaps [rsp+0x70], xmm7
0000714ce89e4653  vmovaps [rsp+0x80], xmm8
0000714ce89e465c  vmovaps [rsp+0x90], xmm10
0000714ce89e4665  vmovaps [rsp+0xA0], xmm11
0000714ce89e466e  vmovaps [rsp+0xB0], xmm12
0000714ce89e4677  vmovaps [rsp+0xC0], xmm13
0000714ce89e4680  vmovaps [rsp+0xD0], xmm14
0000714ce89e4689  vmovaps [rsp+0xE0], xmm15
0000714ce89e4692  sub rsp, 0x30
0000714ce89e4696  movaps [rsp], xmm9
0000714ce89e469b  movaps [rsp+0x10], xmm13
0000714ce89e46a1  movaps [rsp+0x20], xmm15
0000714ce89e46a7  lea rdi, [rsp]
0000714ce89e46ab  mov esi, 0x00
0000714ce89e46b0  mov rax, 0x57A55D340530
0000714ce89e46ba  call rax
0000714ce89e46bc  movaps xmm9, [rsp]
0000714ce89e46c1  add rsp, 0x30
0000714ce89e46c5  vmovaps xmm0, [rsp]
0000714ce89e46ca  vmovaps xmm1, [rsp+0x10]
0000714ce89e46d0  vmovaps xmm2, [rsp+0x20]
0000714ce89e46d6  vmovaps xmm3, [rsp+0x30]
0000714ce89e46dc  vmovaps xmm4, [rsp+0x40]
0000714ce89e46e2  vmovaps xmm5, [rsp+0x50]
0000714ce89e46e8  vmovaps xmm6, [rsp+0x60]
0000714ce89e46ee  vmovaps xmm7, [rsp+0x70]
0000714ce89e46f4  vmovaps xmm8, [rsp+0x80]
0000714ce89e46fd  vmovaps xmm10, [rsp+0x90]
0000714ce89e4706  vmovaps xmm11, [rsp+0xA0]
0000714ce89e470f  vmovaps xmm12, [rsp+0xB0]
0000714ce89e4718  vmovaps xmm13, [rsp+0xC0]
0000714ce89e4721  vmovaps xmm14, [rsp+0xD0]
0000714ce89e472a  vmovaps xmm15, [rsp+0xE0]
0000714ce89e4733  add rsp, 0xF0
0000714ce89e473a  pop r11
0000714ce89e473c  pop r10
0000714ce89e473e  pop r9
0000714ce89e4740  pop r8
0000714ce89e4742  pop rsi
0000714ce89e4743  pop rdi
0000714ce89e4744  pop rdx
0000714ce89e4745  pop rcx
0000714ce89e4746  pop rax
0000714ce89e4747  add rsp, 0x08
0000714ce89e474b  jmp 0x0000714CE89DF9C2
0000714ce89e4750  sub rsp, 0x08
0000714ce89e4754  push rax
0000714ce89e4755  push rcx
0000714ce89e4756  push rdx
0000714ce89e4757  push rdi
0000714ce89e4758  push rsi
0000714ce89e4759  push r8
0000714ce89e475b  push r9
0000714ce89e475d  push r10
0000714ce89e475f  push r11
0000714ce89e4761  sub rsp, 0xF0
0000714ce89e4768  vmovaps [rsp], xmm0
0000714ce89e476d  vmovaps [rsp+0x10], xmm1
0000714ce89e4773  vmovaps [rsp+0x20], xmm2
0000714ce89e4779  vmovaps [rsp+0x30], xmm3
0000714ce89e477f  vmovaps [rsp+0x40], xmm4
0000714ce89e4785  vmovaps [rsp+0x50], xmm5
0000714ce89e478b  vmovaps [rsp+0x60], xmm6
0000714ce89e4791  vmovaps [rsp+0x70], xmm7
0000714ce89e4797  vmovaps [rsp+0x80], xmm8
0000714ce89e47a0  vmovaps [rsp+0x90], xmm9
0000714ce89e47a9  vmovaps [rsp+0xA0], xmm10
0000714ce89e47b2  vmovaps [rsp+0xB0], xmm11
0000714ce89e47bb  vmovaps [rsp+0xC0], xmm12
0000714ce89e47c4  vmovaps [rsp+0xD0], xmm13
0000714ce89e47cd  vmovaps [rsp+0xE0], xmm14
0000714ce89e47d6  sub rsp, 0x30
0000714ce89e47da  movaps [rsp], xmm15
0000714ce89e47df  movaps [rsp+0x10], xmm11
0000714ce89e47e5  movaps [rsp+0x20], xmm12
0000714ce89e47eb  lea rdi, [rsp]
0000714ce89e47ef  mov esi, 0x00
0000714ce89e47f4  mov rax, 0x57A55D340530
0000714ce89e47fe  call rax
0000714ce89e4800  movaps xmm15, [rsp]
0000714ce89e4805  add rsp, 0x30
0000714ce89e4809  vmovaps xmm0, [rsp]
0000714ce89e480e  vmovaps xmm1, [rsp+0x10]
0000714ce89e4814  vmovaps xmm2, [rsp+0x20]
0000714ce89e481a  vmovaps xmm3, [rsp+0x30]
0000714ce89e4820  vmovaps xmm4, [rsp+0x40]
0000714ce89e4826  vmovaps xmm5, [rsp+0x50]
0000714ce89e482c  vmovaps xmm6, [rsp+0x60]
0000714ce89e4832  vmovaps xmm7, [rsp+0x70]
0000714ce89e4838  vmovaps xmm8, [rsp+0x80]
0000714ce89e4841  vmovaps xmm9, [rsp+0x90]
0000714ce89e484a  vmovaps xmm10, [rsp+0xA0]
0000714ce89e4853  vmovaps xmm11, [rsp+0xB0]
0000714ce89e485c  vmovaps xmm12, [rsp+0xC0]
0000714ce89e4865  vmovaps xmm13, [rsp+0xD0]
0000714ce89e486e  vmovaps xmm14, [rsp+0xE0]
0000714ce89e4877  add rsp, 0xF0
0000714ce89e487e  pop r11
0000714ce89e4880  pop r10
0000714ce89e4882  pop r9
0000714ce89e4884  pop r8
0000714ce89e4886  pop rsi
0000714ce89e4887  pop rdi
0000714ce89e4888  pop rdx
0000714ce89e4889  pop rcx
0000714ce89e488a  pop rax
0000714ce89e488b  add rsp, 0x08
0000714ce89e488f  jmp 0x0000714CE89DF9DD
0000714ce89e4894  sub rsp, 0x08
0000714ce89e4898  push rax
0000714ce89e4899  push rcx
0000714ce89e489a  push rdx
0000714ce89e489b  push rdi
0000714ce89e489c  push rsi
0000714ce89e489d  push r8
0000714ce89e489f  push r9
0000714ce89e48a1  push r10
0000714ce89e48a3  push r11
0000714ce89e48a5  sub rsp, 0xF0
0000714ce89e48ac  vmovaps [rsp], xmm0
0000714ce89e48b1  vmovaps [rsp+0x10], xmm1
0000714ce89e48b7  vmovaps [rsp+0x20], xmm2
0000714ce89e48bd  vmovaps [rsp+0x30], xmm3
0000714ce89e48c3  vmovaps [rsp+0x40], xmm4
0000714ce89e48c9  vmovaps [rsp+0x50], xmm5
0000714ce89e48cf  vmovaps [rsp+0x60], xmm6
0000714ce89e48d5  vmovaps [rsp+0x70], xmm7
0000714ce89e48db  vmovaps [rsp+0x80], xmm8
0000714ce89e48e4  vmovaps [rsp+0x90], xmm9
0000714ce89e48ed  vmovaps [rsp+0xA0], xmm10
0000714ce89e48f6  vmovaps [rsp+0xB0], xmm11
0000714ce89e48ff  vmovaps [rsp+0xC0], xmm12
0000714ce89e4908  vmovaps [rsp+0xD0], xmm14
0000714ce89e4911  vmovaps [rsp+0xE0], xmm15
0000714ce89e491a  sub rsp, 0x30
0000714ce89e491e  movaps [rsp], xmm13
0000714ce89e4923  movaps [rsp+0x10], xmm10
0000714ce89e4929  movaps [rsp+0x20], xmm14
0000714ce89e492f  lea rdi, [rsp]
0000714ce89e4933  mov esi, 0x00
0000714ce89e4938  mov rax, 0x57A55D340530
0000714ce89e4942  call rax
0000714ce89e4944  movaps xmm13, [rsp]
0000714ce89e4949  add rsp, 0x30
0000714ce89e494d  vmovaps xmm0, [rsp]
0000714ce89e4952  vmovaps xmm1, [rsp+0x10]
0000714ce89e4958  vmovaps xmm2, [rsp+0x20]
0000714ce89e495e  vmovaps xmm3, [rsp+0x30]
0000714ce89e4964  vmovaps xmm4, [rsp+0x40]
0000714ce89e496a  vmovaps xmm5, [rsp+0x50]
0000714ce89e4970  vmovaps xmm6, [rsp+0x60]
0000714ce89e4976  vmovaps xmm7, [rsp+0x70]
0000714ce89e497c  vmovaps xmm8, [rsp+0x80]
0000714ce89e4985  vmovaps xmm9, [rsp+0x90]
0000714ce89e498e  vmovaps xmm10, [rsp+0xA0]
0000714ce89e4997  vmovaps xmm11, [rsp+0xB0]
0000714ce89e49a0  vmovaps xmm12, [rsp+0xC0]
0000714ce89e49a9  vmovaps xmm14, [rsp+0xD0]
0000714ce89e49b2  vmovaps xmm15, [rsp+0xE0]
0000714ce89e49bb  add rsp, 0xF0
0000714ce89e49c2  pop r11
0000714ce89e49c4  pop r10
0000714ce89e49c6  pop r9
0000714ce89e49c8  pop r8
0000714ce89e49ca  pop rsi
0000714ce89e49cb  pop rdi
0000714ce89e49cc  pop rdx
0000714ce89e49cd  pop rcx
0000714ce89e49ce  pop rax
0000714ce89e49cf  add rsp, 0x08
0000714ce89e49d3  jmp 0x0000714CE89DFA00
0000714ce89e49d8  sub rsp, 0x08
0000714ce89e49dc  push rax
0000714ce89e49dd  push rcx
0000714ce89e49de  push rdx
0000714ce89e49df  push rdi
0000714ce89e49e0  push rsi
0000714ce89e49e1  push r8
0000714ce89e49e3  push r9
0000714ce89e49e5  push r10
0000714ce89e49e7  push r11
0000714ce89e49e9  sub rsp, 0xF0
0000714ce89e49f0  vmovaps [rsp], xmm0
0000714ce89e49f5  vmovaps [rsp+0x10], xmm1
0000714ce89e49fb  vmovaps [rsp+0x20], xmm2
0000714ce89e4a01  vmovaps [rsp+0x30], xmm3
0000714ce89e4a07  vmovaps [rsp+0x40], xmm4
0000714ce89e4a0d  vmovaps [rsp+0x50], xmm5
0000714ce89e4a13  vmovaps [rsp+0x60], xmm6
0000714ce89e4a19  vmovaps [rsp+0x70], xmm7
0000714ce89e4a1f  vmovaps [rsp+0x80], xmm8
0000714ce89e4a28  vmovaps [rsp+0x90], xmm9
0000714ce89e4a31  vmovaps [rsp+0xA0], xmm10
0000714ce89e4a3a  vmovaps [rsp+0xB0], xmm11
0000714ce89e4a43  vmovaps [rsp+0xC0], xmm12
0000714ce89e4a4c  vmovaps [rsp+0xD0], xmm13
0000714ce89e4a55  vmovaps [rsp+0xE0], xmm15
0000714ce89e4a5e  sub rsp, 0x30
0000714ce89e4a62  movaps [rsp], xmm14
0000714ce89e4a67  movaps [rsp+0x10], xmm1
0000714ce89e4a6c  movaps [rsp+0x20], xmm7
0000714ce89e4a71  lea rdi, [rsp]
0000714ce89e4a75  mov esi, 0x00
0000714ce89e4a7a  mov rax, 0x57A55D340530
0000714ce89e4a84  call rax
0000714ce89e4a86  movaps xmm14, [rsp]
0000714ce89e4a8b  add rsp, 0x30
0000714ce89e4a8f  vmovaps xmm0, [rsp]
0000714ce89e4a94  vmovaps xmm1, [rsp+0x10]
0000714ce89e4a9a  vmovaps xmm2, [rsp+0x20]
0000714ce89e4aa0  vmovaps xmm3, [rsp+0x30]
0000714ce89e4aa6  vmovaps xmm4, [rsp+0x40]
0000714ce89e4aac  vmovaps xmm5, [rsp+0x50]
0000714ce89e4ab2  vmovaps xmm6, [rsp+0x60]
0000714ce89e4ab8  vmovaps xmm7, [rsp+0x70]
0000714ce89e4abe  vmovaps xmm8, [rsp+0x80]
0000714ce89e4ac7  vmovaps xmm9, [rsp+0x90]
0000714ce89e4ad0  vmovaps xmm10, [rsp+0xA0]
0000714ce89e4ad9  vmovaps xmm11, [rsp+0xB0]
0000714ce89e4ae2  vmovaps xmm12, [rsp+0xC0]
0000714ce89e4aeb  vmovaps xmm13, [rsp+0xD0]
0000714ce89e4af4  vmovaps xmm15, [rsp+0xE0]
0000714ce89e4afd  add rsp, 0xF0
0000714ce89e4b04  pop r11
0000714ce89e4b06  pop r10
0000714ce89e4b08  pop r9
0000714ce89e4b0a  pop r8
0000714ce89e4b0c  pop rsi
0000714ce89e4b0d  pop rdi
0000714ce89e4b0e  pop rdx
0000714ce89e4b0f  pop rcx
0000714ce89e4b10  pop rax
0000714ce89e4b11  add rsp, 0x08
0000714ce89e4b15  jmp 0x0000714CE89DFA23
0000714ce89e4b1a  sub rsp, 0x08
0000714ce89e4b1e  push rax
0000714ce89e4b1f  push rcx
0000714ce89e4b20  push rdx
0000714ce89e4b21  push rdi
0000714ce89e4b22  push rsi
0000714ce89e4b23  push r8
0000714ce89e4b25  push r9
0000714ce89e4b27  push r10
0000714ce89e4b29  push r11
0000714ce89e4b2b  sub rsp, 0xF0
0000714ce89e4b32  vmovaps [rsp], xmm0
0000714ce89e4b37  vmovaps [rsp+0x10], xmm2
0000714ce89e4b3d  vmovaps [rsp+0x20], xmm3
0000714ce89e4b43  vmovaps [rsp+0x30], xmm4
0000714ce89e4b49  vmovaps [rsp+0x40], xmm5
0000714ce89e4b4f  vmovaps [rsp+0x50], xmm6
0000714ce89e4b55  vmovaps [rsp+0x60], xmm7
0000714ce89e4b5b  vmovaps [rsp+0x70], xmm8
0000714ce89e4b61  vmovaps [rsp+0x80], xmm9
0000714ce89e4b6a  vmovaps [rsp+0x90], xmm10
0000714ce89e4b73  vmovaps [rsp+0xA0], xmm11
0000714ce89e4b7c  vmovaps [rsp+0xB0], xmm12
0000714ce89e4b85  vmovaps [rsp+0xC0], xmm13
0000714ce89e4b8e  vmovaps [rsp+0xD0], xmm14
0000714ce89e4b97  vmovaps [rsp+0xE0], xmm15
0000714ce89e4ba0  sub rsp, 0x30
0000714ce89e4ba4  movaps [rsp], xmm1
0000714ce89e4ba8  movaps [rsp+0x10], xmm8
0000714ce89e4bae  movaps [rsp+0x20], xmm9
0000714ce89e4bb4  lea rdi, [rsp]
0000714ce89e4bb8  mov esi, 0x00
0000714ce89e4bbd  mov rax, 0x57A55D340530
0000714ce89e4bc7  call rax
0000714ce89e4bc9  movaps xmm1, [rsp]
0000714ce89e4bcd  add rsp, 0x30
0000714ce89e4bd1  vmovaps xmm0, [rsp]
0000714ce89e4bd6  vmovaps xmm2, [rsp+0x10]
0000714ce89e4bdc  vmovaps xmm3, [rsp+0x20]
0000714ce89e4be2  vmovaps xmm4, [rsp+0x30]
0000714ce89e4be8  vmovaps xmm5, [rsp+0x40]
0000714ce89e4bee  vmovaps xmm6, [rsp+0x50]
0000714ce89e4bf4  vmovaps xmm7, [rsp+0x60]
0000714ce89e4bfa  vmovaps xmm8, [rsp+0x70]
0000714ce89e4c00  vmovaps xmm9, [rsp+0x80]
0000714ce89e4c09  vmovaps xmm10, [rsp+0x90]
0000714ce89e4c12  vmovaps xmm11, [rsp+0xA0]
0000714ce89e4c1b  vmovaps xmm12, [rsp+0xB0]
0000714ce89e4c24  vmovaps xmm13, [rsp+0xC0]
0000714ce89e4c2d  vmovaps xmm14, [rsp+0xD0]
0000714ce89e4c36  vmovaps xmm15, [rsp+0xE0]
0000714ce89e4c3f  add rsp, 0xF0
0000714ce89e4c46  pop r11
0000714ce89e4c48  pop r10
0000714ce89e4c4a  pop r9
0000714ce89e4c4c  pop r8
0000714ce89e4c4e  pop rsi
0000714ce89e4c4f  pop rdi
0000714ce89e4c50  pop rdx
0000714ce89e4c51  pop rcx
0000714ce89e4c52  pop rax
0000714ce89e4c53  add rsp, 0x08
0000714ce89e4c57  jmp 0x0000714CE89DFA45
0000714ce89e4c5c  call 0x0000714CE88E5940
0000714ce89e4c61  jmp 0x0000714CE89DFA53
0000714ce89e4c66  call 0x0000714CE880C380
0000714ce89e4c6b  jmp 0x0000714CE89DFA5D
0000714ce89e4c70  call 0x0000714CE880D600
0000714ce89e4c75  jmp 0x0000714CE89DFA67
0000714ce89e4c7a  call 0x0000714CE87FF540
0000714ce89e4c7f  jmp 0x0000714CE89DFA71
0000714ce89e4c84  int3
0000714ce89e4c85  nop [rax+rax*1], ax
0000714ce89e4c8e  nop
0000714ce89e4c90  mov qword ptr [r15+0x40], 0x430000
0000714ce89e4c98  mov eax, 0x430CC0
0000714ce89e4c9d  mov r14, [r13+rax*1]
0000714ce89e4ca2  movq xmm1, r14
0000714ce89e4ca7  mov rax, [r15+0x50]
0000714ce89e4cab  movups xmm15, [r13+rax*1]
0000714ce89e4cb1  movaps [r15+0x120], xmm15
0000714ce89e4cb9  mov qword ptr [r15+0x48], 0x10
0000714ce89e4cc1  xor eax, eax
0000714ce89e4cc3  mov r14d, 0x10
0000714ce89e4cc9  mov r12d, 0x200
0000714ce89e4ccf  cmp r14, r12
0000714ce89e4cd2  cmc
0000714ce89e4cd3  lahf
0000714ce89e4cd4  seto al
0000714ce89e4cd7  mov [r15+0x108], eax
0000714ce89e4cde  pextrq rax, xmm15, 0x01
0000714ce89e4ce5  movq xmm14, rax
0000714ce89e4cea  movaps [r15+0x130], xmm14
0000714ce89e4cf2  movq rax, xmm1
0000714ce89e4cf7  movq r14, xmm15
0000714ce89e4cfc  vmovq xmm1, rax
0000714ce89e4d01  vmovq xmm15, r14
0000714ce89e4d06  movaps xmm13, xmm1
0000714ce89e4d0a  addsd xmm13, xmm15
0000714ce89e4d0f  ucomisd xmm13, xmm13
0000714ce89e4d14  jp 0x0000714CE89E4DD3
0000714ce89e4d1a  movq xmm13, xmm13
0000714ce89e4d1f  movq rax, xmm13
0000714ce89e4d24  movq r14, xmm14
0000714ce89e4d29  vmovq xmm1, rax
0000714ce89e4d2e  vmovq xmm15, r14
0000714ce89e4d33  movaps xmm14, xmm1
0000714ce89e4d37  addsd xmm14, xmm15
0000714ce89e4d3c  ucomisd xmm14, xmm14
0000714ce89e4d41  jp 0x0000714CE89E4E1B
0000714ce89e4d47  movq xmm14, xmm14
0000714ce89e4d4c  movaps [r15+0x110], xmm14
0000714ce89e4d54  mov eax, [r15+0x108]
0000714ce89e4d5b  sahf
0000714ce89e4d5c  jnz 0x0000714CE89E4D8E
0000714ce89e4d5e  cmp dword ptr [r15+0x318], 0x00
0000714ce89e4d66  jz 0x0000714CE89E5030
0000714ce89e4d6c  nop [rax+rax*1], ax
0000714ce89e4d75  nop [rax+rax*1], eax
0000714ce89e4d7d  mov eax, 0x410704
0000714ce89e4d82  mov [r15+0x100], rax
0000714ce89e4d89  jmp 0x0000714CE87FE110
0000714ce89e4d8e  cmp dword ptr [r15+0x318], 0x00
0000714ce89e4d96  jz 0x0000714CE89E4E70
0000714ce89e4d9c  nop [rax+rax*1], ax
0000714ce89e4da5  nop [rax+rax*1], eax
0000714ce89e4dad  mov eax, 0x4106E8
0000714ce89e4db2  mov [r15+0x100], rax
0000714ce89e4db9  jmp 0x0000714CE87FE110
0000714ce89e4dbe  int3
0000714ce89e4dbf  call 0x0000714CE880DC20
0000714ce89e4dc4  jmp 0x0000714CE89E4CA2
0000714ce89e4dc9  call 0x0000714CE880E760
0000714ce89e4dce  jmp 0x0000714CE89E4CB1
0000714ce89e4dd3  ucomisd xmm1, xmm15
0000714ce89e4dd8  jp 0x0000714CE89E4DE7
0000714ce89e4dda  movaps xmm13, [0x0000714CE85FE060]
0000714ce89e4de2  jmp 0x0000714CE89E4D1A
0000714ce89e4de7  vxorps xmm0, xmm1, xmm15
0000714ce89e4dec  pextrw eax, xmm0, 0x03
0000714ce89e4df1  and eax, 0x7FF8
0000714ce89e4df6  cmp eax, 0x08
0000714ce89e4df9  jnz 0x0000714CE89E4D1A
0000714ce89e4dff  movq rax, xmm15
0000714ce89e4e04  shl rax, 0x0D
0000714ce89e4e08  jbe 0x0000714CE89E4D1A
0000714ce89e4e0e  vorps xmm13, xmm15, [0x0000714CE85FE070]
0000714ce89e4e16  jmp 0x0000714CE89E4D1A
0000714ce89e4e1b  ucomisd xmm1, xmm15
0000714ce89e4e20  jp 0x0000714CE89E4E2F
0000714ce89e4e22  movaps xmm14, [0x0000714CE85FE060]
0000714ce89e4e2a  jmp 0x0000714CE89E4D47
0000714ce89e4e2f  vxorps xmm0, xmm1, xmm15
0000714ce89e4e34  pextrw eax, xmm0, 0x03
0000714ce89e4e39  and eax, 0x7FF8
0000714ce89e4e3e  cmp eax, 0x08
0000714ce89e4e41  jnz 0x0000714CE89E4D47
0000714ce89e4e47  movq rax, xmm15
0000714ce89e4e4c  shl rax, 0x0D
0000714ce89e4e50  jbe 0x0000714CE89E4D47
0000714ce89e4e56  vorps xmm14, xmm15, [0x0000714CE85FE070]
0000714ce89e4e5e  jmp 0x0000714CE89E4D47
0000714ce89e4e63  int3
0000714ce89e4e64  nop [rax+rax*1], ax
0000714ce89e4e6d  nop [rax], eax
0000714ce89e4e70  mov rax, [r15+0x48]
0000714ce89e4e74  mov r14, [r15+0x50]
0000714ce89e4e78  lea r12, [r14+rax*1]
0000714ce89e4e7c  movups xmm1, [r13+r12*1]
0000714ce89e4e82  movaps [r15+0x120], xmm1
0000714ce89e4e8a  lea r14, [rax+0x10]
0000714ce89e4e8e  mov [r15+0x48], r14
0000714ce89e4e92  xor eax, eax
0000714ce89e4e94  mov r12d, 0x200
0000714ce89e4e9a  cmp r14, r12
0000714ce89e4e9d  cmc
0000714ce89e4e9e  lahf
0000714ce89e4e9f  seto al
0000714ce89e4ea2  mov [r15+0x108], eax
0000714ce89e4ea9  pextrq rax, xmm1, 0x01
0000714ce89e4eb0  movq xmm15, rax
0000714ce89e4eb5  movaps [r15+0x130], xmm15
0000714ce89e4ebd  movaps xmm14, [r15+0x110]
0000714ce89e4ec5  movq rax, xmm14
0000714ce89e4eca  movq r14, xmm1
0000714ce89e4ecf  vmovq xmm1, rax
0000714ce89e4ed4  vmovq xmm14, r14
0000714ce89e4ed9  movaps xmm13, xmm1
0000714ce89e4edd  addsd xmm13, xmm14
0000714ce89e4ee2  ucomisd xmm13, xmm13
0000714ce89e4ee7  jp 0x0000714CE89E4F9C
0000714ce89e4eed  movq xmm13, xmm13
0000714ce89e4ef2  movq rax, xmm13
0000714ce89e4ef7  movq r14, xmm15
0000714ce89e4efc  vmovq xmm1, rax
0000714ce89e4f01  vmovq xmm15, r14
0000714ce89e4f06  movaps xmm14, xmm1
0000714ce89e4f0a  addsd xmm14, xmm15
0000714ce89e4f0f  ucomisd xmm14, xmm14
0000714ce89e4f14  jp 0x0000714CE89E4FE4
0000714ce89e4f1a  movq xmm14, xmm14
0000714ce89e4f1f  movaps [r15+0x110], xmm14
0000714ce89e4f27  mov eax, [r15+0x108]
0000714ce89e4f2e  sahf
0000714ce89e4f2f  jnz 0x0000714CE89E4F61
0000714ce89e4f31  cmp dword ptr [r15+0x318], 0x00
0000714ce89e4f39  jz 0x0000714CE89E5030
0000714ce89e4f3f  nop [rax+rax*1], ax
0000714ce89e4f48  nop [rax+rax*1], eax
0000714ce89e4f50  mov eax, 0x410704
0000714ce89e4f55  mov [r15+0x100], rax
0000714ce89e4f5c  jmp 0x0000714CE87FE110
0000714ce89e4f61  cmp dword ptr [r15+0x318], 0x00
0000714ce89e4f69  jz 0x0000714CE89E4E70
0000714ce89e4f6f  nop [rax+rax*1], ax
0000714ce89e4f78  nop [rax+rax*1], eax
0000714ce89e4f80  mov eax, 0x4106E8
0000714ce89e4f85  mov [r15+0x100], rax
0000714ce89e4f8c  jmp 0x0000714CE87FE110
0000714ce89e4f91  int3
0000714ce89e4f92  call 0x0000714CE88B52F0
0000714ce89e4f97  jmp 0x0000714CE89E4E82
0000714ce89e4f9c  ucomisd xmm1, xmm14
0000714ce89e4fa1  jp 0x0000714CE89E4FB0
0000714ce89e4fa3  movaps xmm13, [0x0000714CE85FE060]
0000714ce89e4fab  jmp 0x0000714CE89E4EED
0000714ce89e4fb0  vxorps xmm0, xmm1, xmm14
0000714ce89e4fb5  pextrw eax, xmm0, 0x03
0000714ce89e4fba  and eax, 0x7FF8
0000714ce89e4fbf  cmp eax, 0x08
0000714ce89e4fc2  jnz 0x0000714CE89E4EED
0000714ce89e4fc8  movq rax, xmm14
0000714ce89e4fcd  shl rax, 0x0D
0000714ce89e4fd1  jbe 0x0000714CE89E4EED
0000714ce89e4fd7  vorps xmm13, xmm14, [0x0000714CE85FE070]
0000714ce89e4fdf  jmp 0x0000714CE89E4EED
0000714ce89e4fe4  ucomisd xmm1, xmm15
0000714ce89e4fe9  jp 0x0000714CE89E4FF8
0000714ce89e4feb  movaps xmm14, [0x0000714CE85FE060]
0000714ce89e4ff3  jmp 0x0000714CE89E4F1A
0000714ce89e4ff8  vxorps xmm0, xmm1, xmm15
0000714ce89e4ffd  pextrw eax, xmm0, 0x03
0000714ce89e5002  and eax, 0x7FF8
0000714ce89e5007  cmp eax, 0x08
0000714ce89e500a  jnz 0x0000714CE89E4F1A
0000714ce89e5010  movq rax, xmm15
0000714ce89e5015  shl rax, 0x0D
0000714ce89e5019  jbe 0x0000714CE89E4F1A
0000714ce89e501f  vorps xmm14, xmm15, [0x0000714CE85FE070]
0000714ce89e5027  jmp 0x0000714CE89E4F1A
0000714ce89e502c  int3
0000714ce89e502d  nop [rax], eax
0000714ce89e5030  mov rax, [r15+0xF8]
0000714ce89e5037  lea r14, [rax+0x1D0]
0000714ce89e503e  mov r12, [r13+r14*1]
0000714ce89e5043  lea r14, [rax+0x1D8]
0000714ce89e504a  mov r11, [r13+r14*1]
0000714ce89e504f  mov [r15+0xA0], r12
0000714ce89e5056  mov [r15+0x98], r11
0000714ce89e505d  mov r14, [r15+0x40]
0000714ce89e5061  lea r12, [r14+0xCC0]
0000714ce89e5068  movaps xmm1, [r15+0x110]
0000714ce89e5070  movq r14, xmm1
0000714ce89e5075  mov [r13+r12*1], r14
0000714ce89e507a  lea r14, [rax+0x1C0]
0000714ce89e5081  mov r12, [r13+r14*1]
0000714ce89e5086  lea r14, [rax+0x1C8]
0000714ce89e508d  mov r11, [r13+r14*1]
0000714ce89e5092  mov [r15+0xE8], r12
0000714ce89e5099  mov [r15+0xF0], r11
0000714ce89e50a0  lea r14, [rax+0x1B0]
0000714ce89e50a7  mov r12, [r13+r14*1]
0000714ce89e50ac  lea r14, [rax+0x1B8]
0000714ce89e50b3  mov r10, [r13+r14*1]
0000714ce89e50b8  movq xmm1, r12
0000714ce89e50bd  movq xmm15, r10
0000714ce89e50c2  movq xmm1, xmm1
0000714ce89e50c6  movq xmm1, xmm1
0000714ce89e50ca  movaps [r15+0x1A0], xmm1
0000714ce89e50d2  movq xmm15, xmm15
0000714ce89e50d7  movq xmm15, xmm15
0000714ce89e50dc  movaps [r15+0x190], xmm15
0000714ce89e50e4  lea r14, [rax+0x1A0]
0000714ce89e50eb  mov r12, [r13+r14*1]
0000714ce89e50f0  lea r14, [rax+0x1A8]
0000714ce89e50f7  mov r10, [r13+r14*1]
0000714ce89e50fc  movq xmm1, r12
0000714ce89e5101  movq xmm15, r10
0000714ce89e5106  movq xmm1, xmm1
0000714ce89e510a  movq xmm1, xmm1
0000714ce89e510e  movaps [r15+0x1C0], xmm1
0000714ce89e5116  movq xmm15, xmm15
0000714ce89e511b  movq xmm15, xmm15
0000714ce89e5120  movaps [r15+0x1B0], xmm15
0000714ce89e5128  lea r14, [rax+0x190]
0000714ce89e512f  mov r12, [r13+r14*1]
0000714ce89e5134  lea r14, [rax+0x198]
0000714ce89e513b  mov r10, [r13+r14*1]
0000714ce89e5140  movq xmm1, r12
0000714ce89e5145  movq xmm15, r10
0000714ce89e514a  movq xmm1, xmm1
0000714ce89e514e  movq xmm1, xmm1
0000714ce89e5152  movaps [r15+0x1E0], xmm1
0000714ce89e515a  movq xmm15, xmm15
0000714ce89e515f  movq xmm15, xmm15
0000714ce89e5164  movaps [r15+0x1D0], xmm15
0000714ce89e516c  lea r14, [rax+0x180]
0000714ce89e5173  mov r12, [r13+r14*1]
0000714ce89e5178  lea r14, [rax+0x188]
0000714ce89e517f  mov r10, [r13+r14*1]
0000714ce89e5184  movq xmm1, r12
0000714ce89e5189  movq xmm15, r10
0000714ce89e518e  movq xmm1, xmm1
0000714ce89e5192  movq xmm1, xmm1
0000714ce89e5196  movaps [r15+0x200], xmm1
0000714ce89e519e  movq xmm15, xmm15
0000714ce89e51a3  movq xmm15, xmm15
0000714ce89e51a8  movaps [r15+0x1F0], xmm15
0000714ce89e51b0  lea r14, [rax+0x1E0]
0000714ce89e51b7  mov [r15+0xF8], r14
0000714ce89e51be  mov [r15+0x100], r11
0000714ce89e51c5  jmp 0x0000714CE89CE5C0
0000714ce89e51ca  int3
0000714ce89e51cb  call 0x0000714CE88E27E0
0000714ce89e51d0  jmp 0x0000714CE89E5043
0000714ce89e51d5  call 0x0000714CE88E1570
0000714ce89e51da  jmp 0x0000714CE89E504F
0000714ce89e51df  call 0x0000714CE88C3FE0
0000714ce89e51e4  jmp 0x0000714CE89E507A
0000714ce89e51e9  call 0x0000714CE88E27E0
0000714ce89e51ee  jmp 0x0000714CE89E5086
0000714ce89e51f3  call 0x0000714CE88E1570
0000714ce89e51f8  jmp 0x0000714CE89E5092
0000714ce89e51fd  call 0x0000714CE88E27E0
0000714ce89e5202  jmp 0x0000714CE89E50AC
0000714ce89e5207  call 0x0000714CE88E0300
0000714ce89e520c  jmp 0x0000714CE89E50B8
0000714ce89e5211  call 0x0000714CE88E27E0
0000714ce89e5216  jmp 0x0000714CE89E50F0
0000714ce89e521b  call 0x0000714CE88E0300
0000714ce89e5220  jmp 0x0000714CE89E50FC
0000714ce89e5225  call 0x0000714CE88E27E0
0000714ce89e522a  jmp 0x0000714CE89E5134
0000714ce89e522f  call 0x0000714CE88E0300
0000714ce89e5234  jmp 0x0000714CE89E5140
0000714ce89e5239  call 0x0000714CE88E27E0
0000714ce89e523e  jmp 0x0000714CE89E5178
0000714ce89e5243  call 0x0000714CE88E0300
0000714ce89e5248  jmp 0x0000714CE89E5184
0000714ce89e524d  int3
0000714ce89e524e  nop
0000714ce89e5250  mov qword ptr [r15+0x100], 0x04
0000714ce89e525b  mov esi, 0x00
0000714ce89e5260  mov edx, 0x09
0000714ce89e5265  mov rdi, 0x7FFF67B9AA40
0000714ce89e526f  mov rax, 0x57A55D1D3970
0000714ce89e5279  call rax
0000714ce89e527b  cmp dword ptr [r15+0x318], 0x00
0000714ce89e5283  jnz 0x0000714CE87FE110
0000714ce89e5289  jmp 0x0000714CE87FE0A0
0000714ce89e528e  int3
0000714ce89e528f  int3
