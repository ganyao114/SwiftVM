000079035ddce69b  nop [rax+rax*1], eax
000079035ddce6a0  mov rax, [r15+0xF8]
000079035ddce6a7  lea r14, [rax-0x1E0]
000079035ddce6ae  mov [r15+0xF8], r14
000079035ddce6b5  lea rax, [r14+0x1D0]
000079035ddce6bc  mov r12, [r15+0xA0]
000079035ddce6c3  mov r11, [r15+0x98]
000079035ddce6ca  mov [r13+rax*1], r12
000079035ddce6cf  lea rax, [r14+0x1D8]
000079035ddce6d6  mov [r13+rax*1], r11
000079035ddce6db  mov eax, 0x420AA0
000079035ddce6e0  movups xmm1, [r13+rax*1]
000079035ddce6e6  mov eax, 0x420A30
000079035ddce6eb  movups xmm15, [r13+rax*1]
000079035ddce6f1  mov eax, 0x420AC0
000079035ddce6f6  movups xmm14, [r13+rax*1]
000079035ddce6fc  mov eax, 0x420A60
000079035ddce701  movups xmm13, [r13+rax*1]
000079035ddce707  mov qword ptr [r15+0x98], 0x430CD0
000079035ddce712  mov eax, 0x420AD0
000079035ddce717  movups xmm12, [r13+rax*1]
000079035ddce71d  mov eax, 0x430CD0
000079035ddce722  movups [r13+rax*1], xmm1
000079035ddce728  mov eax, 0x430CE0
000079035ddce72d  movups [r13+rax*1], xmm15
000079035ddce733  mov eax, 0x430CF0
000079035ddce738  movups [r13+rax*1], xmm14
000079035ddce73e  mov eax, 0x430D00
000079035ddce743  movups [r13+rax*1], xmm13
000079035ddce749  mov eax, 0x420A20
000079035ddce74e  movups xmm14, [r13+rax*1]
000079035ddce754  mov eax, 0x420A10
000079035ddce759  movups xmm13, [r13+rax*1]
000079035ddce75f  mov eax, 0x430DD0
000079035ddce764  movups [r13+rax*1], xmm1
000079035ddce76a  mov eax, 0x430DE0
000079035ddce76f  movups [r13+rax*1], xmm15
000079035ddce775  mov eax, 0x430D10
000079035ddce77a  movups [r13+rax*1], xmm12
000079035ddce780  mov eax, 0x430D20
000079035ddce785  movups [r13+rax*1], xmm14
000079035ddce78b  mov eax, 0x420A00
000079035ddce790  movups xmm1, [r13+rax*1]
000079035ddce796  mov eax, 0x420A70
000079035ddce79b  movups xmm15, [r13+rax*1]
000079035ddce7a1  mov eax, 0x430D30
000079035ddce7a6  movups [r13+rax*1], xmm13
000079035ddce7ac  mov eax, 0x430D40
000079035ddce7b1  movups [r13+rax*1], xmm1
000079035ddce7b7  mov eax, 0x420A80
000079035ddce7bc  movups xmm1, [r13+rax*1]
000079035ddce7c2  mov eax, 0x420A50
000079035ddce7c7  movups xmm14, [r13+rax*1]
000079035ddce7cd  mov qword ptr [r15+0x48], 0x421DF8D3
000079035ddce7d5  mov eax, 0x430D50
000079035ddce7da  movups [r13+rax*1], xmm15
000079035ddce7e0  mov eax, 0x430D60
000079035ddce7e5  movups [r13+rax*1], xmm1
000079035ddce7eb  mov eax, 0x420AF0
000079035ddce7f0  movups xmm1, [r13+rax*1]
000079035ddce7f6  mov eax, 0x420B00
000079035ddce7fb  movups xmm15, [r13+rax*1]
000079035ddce801  movaps [r15+0x150], xmm15
000079035ddce809  mov qword ptr [r15+0xA0], 0x3E8
000079035ddce814  mov eax, 0x430D70
000079035ddce819  movups [r13+rax*1], xmm14
000079035ddce81f  mov eax, 0x430D80
000079035ddce824  movups [r13+rax*1], xmm1
000079035ddce82a  mov eax, 0x420AE0
000079035ddce82f  movups xmm1, [r13+rax*1]
000079035ddce835  mov eax, 0x420A90
000079035ddce83a  movups xmm14, [r13+rax*1]
000079035ddce840  movaps [r15+0x140], xmm14
000079035ddce848  lea rax, [r14+0x180]
000079035ddce84f  movq xmm13, qword ptr [r15+0x200]
000079035ddce858  movq xmm12, qword ptr [r15+0x1F0]
000079035ddce861  movq r12, xmm13
000079035ddce866  movq r11, xmm12
000079035ddce86b  mov [r13+rax*1], r12
000079035ddce870  lea rax, [r14+0x188]
000079035ddce877  mov [r13+rax*1], r11
000079035ddce87c  mov eax, 0x430D90
000079035ddce881  movups [r13+rax*1], xmm15
000079035ddce887  mov eax, 0x430DA0
000079035ddce88c  movups [r13+rax*1], xmm1
000079035ddce892  mov eax, 0x420AB0
000079035ddce897  movups xmm1, [r13+rax*1]
000079035ddce89d  mov eax, 0x420B18
000079035ddce8a2  mov r12, [r13+rax*1]
000079035ddce8a7  movq xmm15, r12
000079035ddce8ac  mov qword ptr [r15+0x40], 0x420B20
000079035ddce8b4  mov eax, 0x430DB0
000079035ddce8b9  movups [r13+rax*1], xmm14
000079035ddce8bf  mov eax, 0x430DC0
000079035ddce8c4  movups [r13+rax*1], xmm1
000079035ddce8ca  mov eax, 0x420B80
000079035ddce8cf  movups xmm1, [r13+rax*1]
000079035ddce8d5  movq rax, xmm15
000079035ddce8da  mov r12d, 0x430DF0
000079035ddce8e0  mov [r13+r12*1], rax
000079035ddce8e5  mov eax, 0x420B60
000079035ddce8ea  movups xmm15, [r13+rax*1]
000079035ddce8f0  mov eax, 0x420B70
000079035ddce8f5  movups xmm14, [r13+rax*1]
000079035ddce8fb  lea rax, [r14+0x160]
000079035ddce902  movups [r13+rax*1], xmm1
000079035ddce908  lea rax, [r14+0x190]
000079035ddce90f  movq xmm1, qword ptr [r15+0x1E0]
000079035ddce918  movq xmm13, qword ptr [r15+0x1D0]
000079035ddce921  movq r12, xmm1
000079035ddce926  movq r11, xmm13
000079035ddce92b  mov [r13+rax*1], r12
000079035ddce930  lea rax, [r14+0x198]
000079035ddce937  mov [r13+rax*1], r11
000079035ddce93c  lea rax, [r14+0x140]
000079035ddce943  movups [r13+rax*1], xmm15
000079035ddce949  lea rax, [r14+0x150]
000079035ddce950  movups [r13+rax*1], xmm14
000079035ddce956  mov eax, 0x420B20
000079035ddce95b  movups xmm1, [r13+rax*1]
000079035ddce961  mov eax, 0x420B30
000079035ddce966  movups xmm15, [r13+rax*1]
000079035ddce96c  movaps [r15+0x120], xmm15
000079035ddce974  lea rax, [r14+0x1A0]
000079035ddce97b  movq xmm14, qword ptr [r15+0x1C0]
000079035ddce984  movq xmm13, qword ptr [r15+0x1B0]
000079035ddce98d  movq r12, xmm14
000079035ddce992  movq r11, xmm13
000079035ddce997  mov [r13+rax*1], r12
000079035ddce99c  lea rax, [r14+0x1A8]
000079035ddce9a3  mov [r13+rax*1], r11
000079035ddce9a8  lea rax, [r14+0x1B0]
000079035ddce9af  movq xmm14, qword ptr [r15+0x1A0]
000079035ddce9b8  movq xmm13, qword ptr [r15+0x190]
000079035ddce9c1  movq r12, xmm14
000079035ddce9c6  movq r11, xmm13
000079035ddce9cb  mov [r13+rax*1], r12
000079035ddce9d0  lea rax, [r14+0x1B8]
000079035ddce9d7  mov [r13+rax*1], r11
000079035ddce9dc  lea rax, [r14+0x100]
000079035ddce9e3  movups [r13+rax*1], xmm1
000079035ddce9e9  lea rax, [r14+0x110]
000079035ddce9f0  movups [r13+rax*1], xmm15
000079035ddce9f6  mov eax, 0x420B40
000079035ddce9fb  movups xmm1, [r13+rax*1]
000079035ddcea01  mov eax, 0x420B50
000079035ddcea06  movups xmm15, [r13+rax*1]
000079035ddcea0c  movaps [r15+0x110], xmm1
000079035ddcea14  movaps [r15+0x130], xmm15
000079035ddcea1c  lea rax, [r14+0x1C0]
000079035ddcea23  mov r12, [r15+0xE8]
000079035ddcea2a  mov r11, [r15+0xF0]
000079035ddcea31  mov [r13+rax*1], r12
000079035ddcea36  lea rax, [r14+0x1C8]
000079035ddcea3d  mov [r13+rax*1], r11
000079035ddcea42  mov eax, 0x430DF8
000079035ddcea47  mov r12d, 0x421DF8D3
000079035ddcea4d  mov [r13+rax*1], r12d
000079035ddcea52  lea rax, [r14+0x120]
000079035ddcea59  movups [r13+rax*1], xmm1
000079035ddcea5f  lea rax, [r14+0x130]
000079035ddcea66  movups [r13+rax*1], xmm15
000079035ddcea6c  lea rax, [r14+0x100]
000079035ddcea73  mov [r15], rax
000079035ddcea76  mov qword ptr [r15+0x08], 0x430CD0
000079035ddcea7e  mov qword ptr [r15+0x10], 0x12C
000079035ddcea86  mov qword ptr [r15+0xF0], 0x410284
000079035ddcea91  mov r14d, [r15+0x320]
000079035ddcea98  mov eax, 0x410284
000079035ddcea9d  mov rcx, 0x79035DDD07C0
000079035ddceaa7  mov [r15+r14*8+0x328], rax
000079035ddceaaf  mov [r15+r14*8+0x368], rcx
000079035ddceab7  add r14d, 0x01
000079035ddceabb  and r14d, 0x07
000079035ddceabf  mov [r15+0x320], r14d
000079035ddceac6  cmp dword ptr [r15+0x318], 0x00
000079035ddceace  jz 0x000079035DDCED70
000079035ddcead4  nop [rax+rax*1], ax
000079035ddceadd  nop [rax+rax*1], eax
000079035ddceae5  mov eax, 0x410728
000079035ddceaea  mov [r15+0x100], rax
000079035ddceaf1  jmp 0x000079035DBFE110
000079035ddceaf6  int3
000079035ddceaf7  call 0x000079035DC0BC20
000079035ddceafc  jmp 0x000079035DDCE6CF
000079035ddceb01  call 0x000079035DC0A9A0
000079035ddceb06  jmp 0x000079035DDCE6DB
000079035ddceb0b  call 0x000079035DBFF430
000079035ddceb10  jmp 0x000079035DDCE6E6
000079035ddceb15  call 0x000079035DC0E760
000079035ddceb1a  jmp 0x000079035DDCE6F1
000079035ddceb1f  call 0x000079035DC0D4E0
000079035ddceb24  jmp 0x000079035DDCE6FC
000079035ddceb29  call 0x000079035DC0C260
000079035ddceb2e  jmp 0x000079035DDCE707
000079035ddceb33  call 0x000079035DC0AFE0
000079035ddceb38  jmp 0x000079035DDCE71D
000079035ddceb3d  call 0x000079035DBFF540
000079035ddceb42  jmp 0x000079035DDCE728
000079035ddceb47  call 0x000079035DC0E880
000079035ddceb4c  jmp 0x000079035DDCE733
000079035ddceb51  call 0x000079035DC0D600
000079035ddceb56  jmp 0x000079035DDCE73E
000079035ddceb5b  call 0x000079035DC0C380
000079035ddceb60  jmp 0x000079035DDCE749
000079035ddceb65  call 0x000079035DC0D4E0
000079035ddceb6a  jmp 0x000079035DDCE754
000079035ddceb6f  call 0x000079035DC0C260
000079035ddceb74  jmp 0x000079035DDCE75F
000079035ddceb79  call 0x000079035DBFF540
000079035ddceb7e  jmp 0x000079035DDCE76A
000079035ddceb83  call 0x000079035DC0E880
000079035ddceb88  jmp 0x000079035DDCE775
000079035ddceb8d  call 0x000079035DC0B100
000079035ddceb92  jmp 0x000079035DDCE780
000079035ddceb97  call 0x000079035DC0D600
000079035ddceb9c  jmp 0x000079035DDCE78B
000079035ddceba1  call 0x000079035DBFF430
000079035ddceba6  jmp 0x000079035DDCE796
000079035ddcebab  call 0x000079035DC0E760
000079035ddcebb0  jmp 0x000079035DDCE7A1
000079035ddcebb5  call 0x000079035DC0C380
000079035ddcebba  jmp 0x000079035DDCE7AC
000079035ddcebbf  call 0x000079035DBFF540
000079035ddcebc4  jmp 0x000079035DDCE7B7
000079035ddcebc9  call 0x000079035DBFF430
000079035ddcebce  jmp 0x000079035DDCE7C2
000079035ddcebd3  call 0x000079035DC0D4E0
000079035ddcebd8  jmp 0x000079035DDCE7CD
000079035ddcebdd  call 0x000079035DC0E880
000079035ddcebe2  jmp 0x000079035DDCE7E0
000079035ddcebe7  call 0x000079035DBFF540
000079035ddcebec  jmp 0x000079035DDCE7EB
000079035ddcebf1  call 0x000079035DBFF430
000079035ddcebf6  jmp 0x000079035DDCE7F6
000079035ddcebfb  call 0x000079035DC0E760
000079035ddcec00  jmp 0x000079035DDCE801
000079035ddcec05  call 0x000079035DC0D600
000079035ddcec0a  jmp 0x000079035DDCE81F
000079035ddcec0f  call 0x000079035DBFF540
000079035ddcec14  jmp 0x000079035DDCE82A
000079035ddcec19  call 0x000079035DBFF430
000079035ddcec1e  jmp 0x000079035DDCE835
000079035ddcec23  call 0x000079035DC0D4E0
000079035ddcec28  jmp 0x000079035DDCE840
000079035ddcec2d  call 0x000079035DC0BC20
000079035ddcec32  jmp 0x000079035DDCE870
000079035ddcec37  call 0x000079035DC0A9A0
000079035ddcec3c  jmp 0x000079035DDCE87C
000079035ddcec41  call 0x000079035DC0E880
000079035ddcec46  jmp 0x000079035DDCE887
000079035ddcec4b  call 0x000079035DBFF540
000079035ddcec50  jmp 0x000079035DDCE892
000079035ddcec55  call 0x000079035DBFF430
000079035ddcec5a  jmp 0x000079035DDCE89D
000079035ddcec5f  call 0x000079035DC0B720
000079035ddcec64  jmp 0x000079035DDCE8A7
000079035ddcec69  call 0x000079035DC0D600
000079035ddcec6e  jmp 0x000079035DDCE8BF
000079035ddcec73  call 0x000079035DBFF540
000079035ddcec78  jmp 0x000079035DDCE8CA
000079035ddcec7d  call 0x000079035DBFF430
000079035ddcec82  jmp 0x000079035DDCE8D5
000079035ddcec87  call 0x000079035DCB4CB0
000079035ddcec8c  jmp 0x000079035DDCE8E5
000079035ddcec91  call 0x000079035DC0E760
000079035ddcec96  jmp 0x000079035DDCE8F0
000079035ddcec9b  call 0x000079035DC0D4E0
000079035ddceca0  jmp 0x000079035DDCE8FB
000079035ddceca5  call 0x000079035DBFF540
000079035ddcecaa  jmp 0x000079035DDCE908
000079035ddcecaf  call 0x000079035DC0BC20
000079035ddcecb4  jmp 0x000079035DDCE930
000079035ddcecb9  call 0x000079035DC0A9A0
000079035ddcecbe  jmp 0x000079035DDCE93C
000079035ddcecc3  call 0x000079035DC0E880
000079035ddcecc8  jmp 0x000079035DDCE949
000079035ddceccd  call 0x000079035DC0D600
000079035ddcecd2  jmp 0x000079035DDCE956
000079035ddcecd7  call 0x000079035DBFF430
000079035ddcecdc  jmp 0x000079035DDCE961
000079035ddcece1  call 0x000079035DC0E760
000079035ddcece6  jmp 0x000079035DDCE96C
000079035ddceceb  call 0x000079035DC0BC20
000079035ddcecf0  jmp 0x000079035DDCE99C
000079035ddcecf5  call 0x000079035DC0A9A0
000079035ddcecfa  jmp 0x000079035DDCE9A8
000079035ddcecff  call 0x000079035DC0BC20
000079035ddced04  jmp 0x000079035DDCE9D0
000079035ddced09  call 0x000079035DC0A9A0
000079035ddced0e  jmp 0x000079035DDCE9DC
000079035ddced13  call 0x000079035DBFF540
000079035ddced18  jmp 0x000079035DDCE9E9
000079035ddced1d  call 0x000079035DC0E880
000079035ddced22  jmp 0x000079035DDCE9F6
000079035ddced27  call 0x000079035DBFF430
000079035ddced2c  jmp 0x000079035DDCEA01
000079035ddced31  call 0x000079035DC0E760
000079035ddced36  jmp 0x000079035DDCEA0C
000079035ddced3b  call 0x000079035DC0BC20
000079035ddced40  jmp 0x000079035DDCEA36
000079035ddced45  call 0x000079035DC0A9A0
000079035ddced4a  jmp 0x000079035DDCEA42
000079035ddced4f  call 0x000079035DC0BAE0
000079035ddced54  jmp 0x000079035DDCEA52
000079035ddced59  call 0x000079035DBFF540
000079035ddced5e  jmp 0x000079035DDCEA5F
000079035ddced63  call 0x000079035DC0E880
000079035ddced68  jmp 0x000079035DDCEA6C
000079035ddced6d  int3
000079035ddced6e  nop
000079035ddced70  mov rax, [r15]
000079035ddced73  lea r14, [rax+0x20]
000079035ddced77  mov r12, [r13+r14*1]
000079035ddced7c  mov r14, [r15+0x10]
000079035ddced80  lea r11, [r12+r14*1]
000079035ddced84  mov [r15+0x40], r11
000079035ddced88  lea r12, [rax+0x20]
000079035ddced8c  mov [r13+r12*1], r11
000079035ddced91  test r14, r14
000079035ddced94  setz r14b
000079035ddced98  movzx r14, r14b
000079035ddced9c  mov [rsp+0x414], r14b
000079035ddceda4  cmp byte ptr [rsp+0x414], 0x00
000079035ddcedac  jz 0x000079035DDCEDDE
000079035ddcedae  cmp dword ptr [r15+0x318], 0x00
000079035ddcedb6  mov eax, 0x4109A0
000079035ddcedbb  mov [r15+0x100], rax
000079035ddcedc2  jz 0x000079035DBFE0A0
000079035ddcedc8  nop [rax+rax*1], eax
000079035ddcedcd  mov eax, 0x4109A0
000079035ddcedd2  mov [r15+0x100], rax
000079035ddcedd9  jmp 0x000079035DBFE110
000079035ddcedde  cmp dword ptr [r15+0x318], 0x00
000079035ddcede6  jz 0x000079035DDCEE30
000079035ddcedec  nop [rax+rax*1], ax
000079035ddcedf5  nop [rax+rax*1], eax
000079035ddcedfd  mov eax, 0x410738
000079035ddcee02  mov [r15+0x100], rax
000079035ddcee09  jmp 0x000079035DBFE110
000079035ddcee0e  int3
000079035ddcee0f  call 0x000079035DCE27E0
000079035ddcee14  jmp 0x000079035DDCED7C
000079035ddcee19  call 0x000079035DCC0860
000079035ddcee1e  jmp 0x000079035DDCED91
000079035ddcee23  int3
000079035ddcee24  nop [rax+rax*1], ax
000079035ddcee2d  nop [rax], eax
000079035ddcee30  mov rax, [r15+0xF8]
000079035ddcee37  lea r14, [rax-0x150]
000079035ddcee3e  mov [r15+0xF8], r14
000079035ddcee45  mov rax, [r15]
000079035ddcee48  lea r12, [rax+0x68]
000079035ddcee4c  mov r11, [r13+r12*1]
000079035ddcee51  mov [r15+0x88], r11
000079035ddcee58  lea r12, [rax+0x28]
000079035ddcee5c  mov [r15+0x40], r12
000079035ddcee60  mov [r15+0x48], r14
000079035ddcee64  mov qword ptr [r15+0x50], 0x420B90
000079035ddcee6c  lea rax, [r14+0x100]
000079035ddcee73  mov r12, [r15+0xE8]
000079035ddcee7a  mov r11, [r15+0xD8]
000079035ddcee81  mov [r13+rax*1], r12
000079035ddcee86  lea rax, [r14+0x108]
000079035ddcee8d  mov [r13+rax*1], r11
000079035ddcee92  lea rax, [r14+0x110]
000079035ddcee99  mov r12, [r15+0xD0]
000079035ddceea0  mov r11, [r15+0xC8]
000079035ddceea7  mov [r13+rax*1], r12
000079035ddceeac  lea rax, [r14+0x118]
000079035ddceeb3  mov [r13+rax*1], r11
000079035ddceeb8  lea rax, [r14+0x120]
000079035ddceebf  mov r12, [r15+0xC0]
000079035ddceec6  mov r11, [r15+0xB8]
000079035ddceecd  mov [r13+rax*1], r12
000079035ddceed2  lea rax, [r14+0x128]
000079035ddceed9  mov [r13+rax*1], r11
000079035ddceede  lea rax, [r14+0x130]
000079035ddceee5  mov r12, [r15+0xB0]
000079035ddceeec  mov r11, [r15+0xA8]
000079035ddceef3  mov [r13+rax*1], r12
000079035ddceef8  lea rax, [r14+0x138]
000079035ddceeff  mov [r13+rax*1], r11
000079035ddcef04  lea rax, [r14+0x140]
000079035ddcef0b  mov r12, [r15+0xA0]
000079035ddcef12  mov r11, [r15+0x98]
000079035ddcef19  mov [r13+rax*1], r12
000079035ddcef1e  lea rax, [r14+0x148]
000079035ddcef25  mov [r13+rax*1], r11
000079035ddcef2a  cmp dword ptr [r15+0x318], 0x00
000079035ddcef32  jz 0x000079035DDCEFD0
000079035ddcef38  nop [rax+rax*1], ax
000079035ddcef41  nop [rax+rax*1], eax
000079035ddcef49  mov eax, 0x410770
000079035ddcef4e  mov [r15+0x100], rax
000079035ddcef55  jmp 0x000079035DBFE110
000079035ddcef5a  int3
000079035ddcef5b  call 0x000079035DCC0370
000079035ddcef60  jmp 0x000079035DDCEE51
000079035ddcef65  call 0x000079035DC0BC20
000079035ddcef6a  jmp 0x000079035DDCEE86
000079035ddcef6f  call 0x000079035DC0A9A0
000079035ddcef74  jmp 0x000079035DDCEE92
000079035ddcef79  call 0x000079035DC0BC20
000079035ddcef7e  jmp 0x000079035DDCEEAC
000079035ddcef83  call 0x000079035DC0A9A0
000079035ddcef88  jmp 0x000079035DDCEEB8
000079035ddcef8d  call 0x000079035DC0BC20
000079035ddcef92  jmp 0x000079035DDCEED2
000079035ddcef97  call 0x000079035DC0A9A0
000079035ddcef9c  jmp 0x000079035DDCEEDE
000079035ddcefa1  call 0x000079035DC0BC20
000079035ddcefa6  jmp 0x000079035DDCEEF8
000079035ddcefab  call 0x000079035DC0A9A0
000079035ddcefb0  jmp 0x000079035DDCEF04
000079035ddcefb5  call 0x000079035DC0BC20
000079035ddcefba  jmp 0x000079035DDCEF1E
000079035ddcefbf  call 0x000079035DC0A9A0
000079035ddcefc4  jmp 0x000079035DDCEF2A
000079035ddcefc9  int3
000079035ddcefca  nop [rax+rax*1], ax
000079035ddcefd0  mov rax, [r15+0x08]
000079035ddcefd4  movzx r14d, byte ptr [r13+rax*1]
000079035ddcefda  movzx r14d, r14b
000079035ddcefde  mov [rsp+0x10], r14d
000079035ddcefe3  mov r14d, r14d
000079035ddcefe6  mov [r15+0x58], r14
000079035ddcefea  lea r14, [rax+0x01]
000079035ddcefee  mov [r15+0x08], r14
000079035ddceff2  mov rax, [r15+0x88]
000079035ddceff9  lea r14, [rax+0x01]
000079035ddceffd  mov r12, [r15]
000079035ddcf000  lea r11, [r12+0x68]
000079035ddcf005  mov [r13+r11*1], r14
000079035ddcf00a  lea r14, [r12+rax*1]
000079035ddcf00e  mov [r15+0x60], r14
000079035ddcf012  lea rax, [r14+0x28]
000079035ddcf016  mov r11d, [rsp+0x10]
000079035ddcf01b  movzx r14d, r11b
000079035ddcf01f  mov [r13+rax*1], r14b
000079035ddcf024  lea rax, [r12+0x68]
000079035ddcf029  mov r14, [r13+rax*1]
000079035ddcf02e  mov [r15+0x88], r14
000079035ddcf035  xor eax, eax
000079035ddcf037  mov r12d, 0x40
000079035ddcf03d  cmp r14, r12
000079035ddcf040  cmc
000079035ddcf041  lahf
000079035ddcf042  seto al
000079035ddcf045  mov [r15+0x108], eax
000079035ddcf04c  mov eax, [r15+0x108]
000079035ddcf053  sahf
000079035ddcf054  jnz 0x000079035DDCF086
000079035ddcf056  cmp dword ptr [r15+0x318], 0x00
000079035ddcf05e  jz 0x000079035DDCF170
000079035ddcf064  nop [rax+rax*1], ax
000079035ddcf06d  nop [rax+rax*1], eax
000079035ddcf075  mov eax, 0x410790
000079035ddcf07a  mov [r15+0x100], rax
000079035ddcf081  jmp 0x000079035DBFE110
000079035ddcf086  cmp dword ptr [r15+0x318], 0x00
000079035ddcf08e  jz 0x000079035DDCF0E0
000079035ddcf094  nop [rax+rax*1], ax
000079035ddcf09d  nop [rax+rax*1], eax
000079035ddcf0a5  mov eax, 0x410768
000079035ddcf0aa  mov [r15+0x100], rax
000079035ddcf0b1  jmp 0x000079035DBFE110
000079035ddcf0b6  int3
000079035ddcf0b7  call 0x000079035DC0D860
000079035ddcf0bc  jmp 0x000079035DDCEFDA
000079035ddcf0c1  call 0x000079035DCB36E0
000079035ddcf0c6  jmp 0x000079035DDCF00A
000079035ddcf0cb  call 0x000079035DC0DD60
000079035ddcf0d0  jmp 0x000079035DDCF024
000079035ddcf0d5  call 0x000079035DC0DC20
000079035ddcf0da  jmp 0x000079035DDCF02E
000079035ddcf0df  int3
000079035ddcf0e0  mov rax, [r15+0x10]
000079035ddcf0e4  lea r14, [rax-0x01]
000079035ddcf0e8  mov [r15+0x10], r14
000079035ddcf0ec  test r14, r14
000079035ddcf0ef  setz r14b
000079035ddcf0f3  movzx r14, r14b
000079035ddcf0f7  mov [rsp+0x414], r14b
000079035ddcf0ff  cmp byte ptr [rsp+0x414], 0x00
000079035ddcf107  jz 0x000079035DDCF139
000079035ddcf109  cmp dword ptr [r15+0x318], 0x00
000079035ddcf111  jz 0x000079035DDD0670
000079035ddcf117  nop [rax+rax*1], ax
000079035ddcf120  nop [rax+rax*1], eax
000079035ddcf128  mov eax, 0x410988
000079035ddcf12d  mov [r15+0x100], rax
000079035ddcf134  jmp 0x000079035DBFE110
000079035ddcf139  cmp dword ptr [r15+0x318], 0x00
000079035ddcf141  jz 0x000079035DDCEFD0
000079035ddcf147  nop [rax+rax*1], ax
000079035ddcf150  nop [rax+rax*1], eax
000079035ddcf158  mov eax, 0x410770
000079035ddcf15d  mov [r15+0x100], rax
000079035ddcf164  jmp 0x000079035DBFE110
000079035ddcf169  int3
000079035ddcf16a  int3
000079035ddcf16b  nop [rax+rax*1], eax
000079035ddcf170  mov rax, [r15+0x40]
000079035ddcf174  movzx r14d, byte ptr [r13+rax*1]
000079035ddcf17a  movaps xmm1, [r15+0x110]
000079035ddcf182  pinsrb xmm1, r14d, 0x00
000079035ddcf189  lea r14, [rax+0x01]
000079035ddcf18d  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf193  movaps xmm15, [r15+0x120]
000079035ddcf19b  pinsrb xmm15, r12d, 0x00
000079035ddcf1a2  lea r14, [rax+0x02]
000079035ddcf1a6  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf1ac  movaps xmm14, [r15+0x130]
000079035ddcf1b4  pinsrb xmm14, r12d, 0x00
000079035ddcf1bb  lea r14, [rax+0x03]
000079035ddcf1bf  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf1c5  movaps xmm13, [r15+0x140]
000079035ddcf1cd  pinsrb xmm13, r12d, 0x00
000079035ddcf1d4  lea r14, [rax+0x04]
000079035ddcf1d8  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf1de  pinsrb xmm1, r12d, 0x01
000079035ddcf1e5  lea r14, [rax+0x05]
000079035ddcf1e9  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf1ef  pinsrb xmm15, r12d, 0x01
000079035ddcf1f6  lea r14, [rax+0x06]
000079035ddcf1fa  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf200  pinsrb xmm14, r12d, 0x01
000079035ddcf207  lea r14, [rax+0x07]
000079035ddcf20b  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf211  pinsrb xmm13, r12d, 0x01
000079035ddcf218  lea r14, [rax+0x08]
000079035ddcf21c  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf222  pinsrb xmm1, r12d, 0x02
000079035ddcf229  lea r14, [rax+0x09]
000079035ddcf22d  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf233  pinsrb xmm15, r12d, 0x02
000079035ddcf23a  lea r14, [rax+0x0A]
000079035ddcf23e  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf244  pinsrb xmm14, r12d, 0x02
000079035ddcf24b  lea r14, [rax+0x0B]
000079035ddcf24f  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf255  pinsrb xmm13, r12d, 0x02
000079035ddcf25c  lea r14, [rax+0x0C]
000079035ddcf260  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf266  pinsrb xmm1, r12d, 0x03
000079035ddcf26d  lea r14, [rax+0x0D]
000079035ddcf271  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf277  pinsrb xmm15, r12d, 0x03
000079035ddcf27e  lea r14, [rax+0x0E]
000079035ddcf282  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf288  pinsrb xmm14, r12d, 0x03
000079035ddcf28f  lea r14, [rax+0x0F]
000079035ddcf293  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf299  pinsrb xmm13, r12d, 0x03
000079035ddcf2a0  lea r14, [rax+0x10]
000079035ddcf2a4  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf2aa  pinsrb xmm1, r12d, 0x04
000079035ddcf2b1  lea r14, [rax+0x11]
000079035ddcf2b5  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf2bb  pinsrb xmm15, r12d, 0x04
000079035ddcf2c2  lea r14, [rax+0x12]
000079035ddcf2c6  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf2cc  pinsrb xmm14, r12d, 0x04
000079035ddcf2d3  lea r14, [rax+0x13]
000079035ddcf2d7  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf2dd  pinsrb xmm13, r12d, 0x04
000079035ddcf2e4  lea r14, [rax+0x14]
000079035ddcf2e8  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf2ee  pinsrb xmm1, r12d, 0x05
000079035ddcf2f5  lea r14, [rax+0x15]
000079035ddcf2f9  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf2ff  pinsrb xmm15, r12d, 0x05
000079035ddcf306  lea r14, [rax+0x16]
000079035ddcf30a  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf310  pinsrb xmm14, r12d, 0x05
000079035ddcf317  lea r14, [rax+0x17]
000079035ddcf31b  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf321  pinsrb xmm13, r12d, 0x05
000079035ddcf328  lea r14, [rax+0x18]
000079035ddcf32c  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf332  pinsrb xmm1, r12d, 0x06
000079035ddcf339  lea r14, [rax+0x19]
000079035ddcf33d  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf343  pinsrb xmm15, r12d, 0x06
000079035ddcf34a  lea r14, [rax+0x1A]
000079035ddcf34e  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf354  pinsrb xmm14, r12d, 0x06
000079035ddcf35b  lea r14, [rax+0x1B]
000079035ddcf35f  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf365  pinsrb xmm13, r12d, 0x06
000079035ddcf36c  lea r14, [rax+0x1C]
000079035ddcf370  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf376  pinsrb xmm1, r12d, 0x07
000079035ddcf37d  lea r14, [rax+0x1D]
000079035ddcf381  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf387  pinsrb xmm15, r12d, 0x07
000079035ddcf38e  lea r14, [rax+0x1E]
000079035ddcf392  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf398  pinsrb xmm14, r12d, 0x07
000079035ddcf39f  lea r14, [rax+0x1F]
000079035ddcf3a3  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf3a9  pinsrb xmm13, r12d, 0x07
000079035ddcf3b0  lea r14, [rax+0x20]
000079035ddcf3b4  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf3ba  pinsrb xmm1, r12d, 0x08
000079035ddcf3c1  lea r14, [rax+0x21]
000079035ddcf3c5  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf3cb  pinsrb xmm15, r12d, 0x08
000079035ddcf3d2  lea r14, [rax+0x22]
000079035ddcf3d6  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf3dc  pinsrb xmm14, r12d, 0x08
000079035ddcf3e3  lea r14, [rax+0x23]
000079035ddcf3e7  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf3ed  pinsrb xmm13, r12d, 0x08
000079035ddcf3f4  lea r14, [rax+0x24]
000079035ddcf3f8  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf3fe  pinsrb xmm1, r12d, 0x09
000079035ddcf405  lea r14, [rax+0x25]
000079035ddcf409  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf40f  pinsrb xmm15, r12d, 0x09
000079035ddcf416  lea r14, [rax+0x26]
000079035ddcf41a  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf420  pinsrb xmm14, r12d, 0x09
000079035ddcf427  lea r14, [rax+0x27]
000079035ddcf42b  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf431  pinsrb xmm13, r12d, 0x09
000079035ddcf438  lea r14, [rax+0x28]
000079035ddcf43c  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf442  pinsrb xmm1, r12d, 0x0A
000079035ddcf449  lea r14, [rax+0x29]
000079035ddcf44d  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf453  pinsrb xmm15, r12d, 0x0A
000079035ddcf45a  lea r14, [rax+0x2A]
000079035ddcf45e  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf464  pinsrb xmm14, r12d, 0x0A
000079035ddcf46b  lea r14, [rax+0x2B]
000079035ddcf46f  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf475  pinsrb xmm13, r12d, 0x0A
000079035ddcf47c  lea r14, [rax+0x2C]
000079035ddcf480  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf486  pinsrb xmm1, r12d, 0x0B
000079035ddcf48d  lea r14, [rax+0x2D]
000079035ddcf491  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf497  pinsrb xmm15, r12d, 0x0B
000079035ddcf49e  lea r14, [rax+0x2E]
000079035ddcf4a2  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf4a8  pinsrb xmm14, r12d, 0x0B
000079035ddcf4af  lea r14, [rax+0x2F]
000079035ddcf4b3  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf4b9  pinsrb xmm13, r12d, 0x0B
000079035ddcf4c0  lea r14, [rax+0x30]
000079035ddcf4c4  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf4ca  pinsrb xmm1, r12d, 0x0C
000079035ddcf4d1  lea r14, [rax+0x31]
000079035ddcf4d5  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf4db  pinsrb xmm15, r12d, 0x0C
000079035ddcf4e2  lea r14, [rax+0x32]
000079035ddcf4e6  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf4ec  pinsrb xmm14, r12d, 0x0C
000079035ddcf4f3  lea r14, [rax+0x33]
000079035ddcf4f7  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf4fd  pinsrb xmm13, r12d, 0x0C
000079035ddcf504  lea r14, [rax+0x34]
000079035ddcf508  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf50e  pinsrb xmm1, r12d, 0x0D
000079035ddcf515  lea r14, [rax+0x35]
000079035ddcf519  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf51f  pinsrb xmm15, r12d, 0x0D
000079035ddcf526  lea r14, [rax+0x36]
000079035ddcf52a  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf530  pinsrb xmm14, r12d, 0x0D
000079035ddcf537  lea r14, [rax+0x37]
000079035ddcf53b  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf541  pinsrb xmm13, r12d, 0x0D
000079035ddcf548  lea r14, [rax+0x38]
000079035ddcf54c  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf552  pinsrb xmm1, r12d, 0x0E
000079035ddcf559  lea r14, [rax+0x39]
000079035ddcf55d  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf563  pinsrb xmm15, r12d, 0x0E
000079035ddcf56a  lea r14, [rax+0x3A]
000079035ddcf56e  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf574  pinsrb xmm14, r12d, 0x0E
000079035ddcf57b  lea r14, [rax+0x3B]
000079035ddcf57f  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf585  pinsrb xmm13, r12d, 0x0E
000079035ddcf58c  lea r14, [rax+0x3C]
000079035ddcf590  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf596  pinsrb xmm1, r12d, 0x0F
000079035ddcf59d  movaps [r15+0x110], xmm1
000079035ddcf5a5  lea r14, [rax+0x3D]
000079035ddcf5a9  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf5af  pinsrb xmm15, r12d, 0x0F
000079035ddcf5b6  movaps [r15+0x120], xmm15
000079035ddcf5be  lea r14, [rax+0x3E]
000079035ddcf5c2  movzx r12d, byte ptr [r13+r14*1]
000079035ddcf5c8  pinsrb xmm14, r12d, 0x0F
000079035ddcf5cf  movaps [r15+0x130], xmm14
000079035ddcf5d7  lea r14, [rax+0x3F]
000079035ddcf5db  movzx eax, byte ptr [r13+r14*1]
000079035ddcf5e1  pinsrb xmm13, eax, 0x0F
000079035ddcf5e8  movaps [r15+0x140], xmm13
000079035ddcf5f0  movq xmm1, qword ptr [r15+0x120]
000079035ddcf5f9  pmovzxbw xmm1, xmm1
000079035ddcf5fe  psllw xmm1, 0x00
000079035ddcf603  movaps [r15+0x150], xmm1
000079035ddcf60b  movq xmm1, qword ptr [r15+0x130]
000079035ddcf614  pmovzxbw xmm1, xmm1
000079035ddcf619  psllw xmm1, 0x00
000079035ddcf61e  movaps [r15+0x160], xmm1
000079035ddcf626  movq xmm1, qword ptr [r15+0x110]
000079035ddcf62f  pmovzxbw xmm1, xmm1
000079035ddcf634  psllw xmm1, 0x00
000079035ddcf639  movaps [r15+0x170], xmm1
000079035ddcf641  movaps xmm15, [r15+0x110]
000079035ddcf649  pextrq rax, xmm15, 0x01
000079035ddcf650  movq xmm15, rax
000079035ddcf655  pmovzxbw xmm15, xmm15
000079035ddcf65b  psllw xmm15, 0x00
000079035ddcf661  movaps [r15+0x180], xmm15
000079035ddcf669  movaps xmm14, [r15+0x120]
000079035ddcf671  pextrq rax, xmm14, 0x01
000079035ddcf678  movq xmm14, rax
000079035ddcf67d  pmovzxbw xmm14, xmm14
000079035ddcf683  psllw xmm14, 0x00
000079035ddcf689  movaps [r15+0x210], xmm14
000079035ddcf691  movaps xmm13, [r15+0x130]
000079035ddcf699  pextrq rax, xmm13, 0x01
000079035ddcf6a0  movq xmm13, rax
000079035ddcf6a5  pmovzxbw xmm13, xmm13
000079035ddcf6ab  psllw xmm13, 0x00
000079035ddcf6b1  movaps [r15+0x220], xmm13
000079035ddcf6b9  movq xmm12, qword ptr [r15+0x140]
000079035ddcf6c2  pmovzxbw xmm12, xmm12
000079035ddcf6c8  psllw xmm12, 0x00
000079035ddcf6ce  movaps [r15+0x250], xmm12
000079035ddcf6d6  movaps xmm12, [r15+0x140]
000079035ddcf6de  pextrq rax, xmm12, 0x01
000079035ddcf6e5  movq xmm12, rax
000079035ddcf6ea  pmovzxbw xmm12, xmm12
000079035ddcf6f0  psllw xmm12, 0x00
000079035ddcf6f6  movaps [r15+0x110], xmm12
000079035ddcf6fe  movq xmm11, qword ptr [r15+0x150]
000079035ddcf707  pmovzxwd xmm11, xmm11
000079035ddcf70d  pslld xmm11, 0x10
000079035ddcf713  movq xmm10, qword ptr [r15+0x160]
000079035ddcf71c  pmovzxwd xmm10, xmm10
000079035ddcf722  pslld xmm10, 0x08
000079035ddcf728  pextrq rax, xmm1, 0x01
000079035ddcf72f  movq xmm1, rax
000079035ddcf734  pmovzxwd xmm1, xmm1
000079035ddcf739  pslld xmm1, 0x00
000079035ddcf73e  movaps [r15+0x260], xmm1
000079035ddcf746  pextrq rax, xmm15, 0x01
000079035ddcf74d  movq xmm15, rax
000079035ddcf752  pmovzxwd xmm15, xmm15
000079035ddcf758  pslld xmm15, 0x00
000079035ddcf75e  movaps [r15+0x270], xmm15
000079035ddcf766  movq xmm9, qword ptr [r15+0x170]
000079035ddcf76f  pmovzxwd xmm9, xmm9
000079035ddcf775  pslld xmm9, 0x00
000079035ddcf77b  pextrq rax, xmm14, 0x01
000079035ddcf782  movq xmm14, rax
000079035ddcf787  pmovzxwd xmm14, xmm14
000079035ddcf78d  pslld xmm14, 0x10
000079035ddcf793  movaps [r15+0x280], xmm14
000079035ddcf79b  movq xmm8, qword ptr [r15+0x180]
000079035ddcf7a4  pmovzxwd xmm8, xmm8
000079035ddcf7aa  pslld xmm8, 0x00
000079035ddcf7b0  movq xmm7, qword ptr [r15+0x210]
000079035ddcf7b9  pmovzxwd xmm7, xmm7
000079035ddcf7be  pslld xmm7, 0x10
000079035ddcf7c3  movaps xmm6, [r15+0x150]
000079035ddcf7cb  pextrq rax, xmm6, 0x01
000079035ddcf7d2  movq xmm6, rax
000079035ddcf7d7  pmovzxwd xmm6, xmm6
000079035ddcf7dc  pslld xmm6, 0x10
000079035ddcf7e1  por xmm11, xmm10
000079035ddcf7e6  movaps [r15+0x230], xmm11
000079035ddcf7ee  pextrq rax, xmm13, 0x01
000079035ddcf7f5  movq xmm13, rax
000079035ddcf7fa  pmovzxwd xmm13, xmm13
000079035ddcf800  pslld xmm13, 0x08
000079035ddcf806  movaps [r15+0x240], xmm13
000079035ddcf80e  movq xmm10, qword ptr [r15+0x220]
000079035ddcf817  pmovzxwd xmm10, xmm10
000079035ddcf81d  pslld xmm10, 0x08
000079035ddcf823  movaps xmm5, [r15+0x160]
000079035ddcf82b  pextrq rax, xmm5, 0x01
000079035ddcf832  movq xmm5, rax
000079035ddcf837  pmovzxwd xmm5, xmm5
000079035ddcf83c  pslld xmm5, 0x08
000079035ddcf841  pslld xmm9, 0x18
000079035ddcf847  pslld xmm15, 0x18
000079035ddcf84d  pslld xmm8, 0x18
000079035ddcf853  movq xmm4, qword ptr [r15+0x250]
000079035ddcf85c  pmovzxwd xmm4, xmm4
000079035ddcf861  pslld xmm4, 0x00
000079035ddcf866  por xmm14, xmm13
000079035ddcf86b  por xmm7, xmm10
000079035ddcf870  movaps [r15+0x210], xmm7
000079035ddcf878  pslld xmm1, 0x18
000079035ddcf87d  movaps [r15+0x220], xmm1
000079035ddcf885  por xmm6, xmm5
000079035ddcf889  por xmm11, xmm9
000079035ddcf88e  movaps [r15+0x160], xmm11
000079035ddcf896  pextrq rax, xmm12, 0x01
000079035ddcf89d  movq xmm13, rax
000079035ddcf8a2  pmovzxwd xmm13, xmm13
000079035ddcf8a8  pslld xmm13, 0x00
000079035ddcf8ae  movaps [r15+0x170], xmm13
000079035ddcf8b6  movq xmm12, qword ptr [r15+0x110]
000079035ddcf8bf  pmovzxwd xmm12, xmm12
000079035ddcf8c5  pslld xmm12, 0x00
000079035ddcf8cb  por xmm14, xmm15
000079035ddcf8d0  por xmm7, xmm8
000079035ddcf8d5  movaps xmm15, [r15+0x250]
000079035ddcf8dd  pextrq rax, xmm15, 0x01
000079035ddcf8e4  movq xmm15, rax
000079035ddcf8e9  pmovzxwd xmm15, xmm15
000079035ddcf8ef  pslld xmm15, 0x00
000079035ddcf8f5  movaps [r15+0x180], xmm15
000079035ddcf8fd  por xmm6, xmm1
000079035ddcf901  movaps [r15+0x150], xmm6
000079035ddcf909  por xmm11, xmm4
000079035ddcf90e  movaps [r15+0x140], xmm11
000079035ddcf916  por xmm7, xmm12
000079035ddcf91b  movaps [r15+0x110], xmm7
000079035ddcf923  por xmm14, xmm13
000079035ddcf928  movaps [r15+0x120], xmm14
000079035ddcf930  por xmm6, xmm15
000079035ddcf935  movaps [r15+0x130], xmm6
000079035ddcf93d  mov rax, [r15+0xF8]
000079035ddcf944  lea r14, [rax+0x20]
000079035ddcf948  movups [r13+r14*1], xmm7
000079035ddcf94e  lea r14, [rax+0x30]
000079035ddcf952  movups [r13+r14*1], xmm14
000079035ddcf958  movups [r13+rax*1], xmm11
000079035ddcf95e  lea r14, [rax+0x10]
000079035ddcf962  movups [r13+r14*1], xmm6
000079035ddcf968  mov r14d, [r13+rax*1]
000079035ddcf96d  mov rax, [r15+0x48]
000079035ddcf971  mov [r15+0x68], rax
000079035ddcf975  mov qword ptr [r15+0x58], 0x04
000079035ddcf97d  lea r12, [rax+0x04]
000079035ddcf981  mov r11d, [r13+r12*1]
000079035ddcf986  mov [rsp+0x10], r11d
000079035ddcf98b  mov r11d, r11d
000079035ddcf98e  mov [r15+0x70], r11
000079035ddcf992  lea r12, [rax+0x38]
000079035ddcf996  mov r11d, [r13+r12*1]
000079035ddcf99b  lea r12, [rax+0x24]
000079035ddcf99f  mov r10d, [r13+r12*1]
000079035ddcf9a4  mov [rsp+0x20], r10d
000079035ddcf9a9  mov r10d, r10d
000079035ddcf9ac  mov [r15+0x90], r10
000079035ddcf9b3  mov [rsp+0x30], rax
000079035ddcf9b8  xor eax, eax
000079035ddcf9ba  mov r12d, 0x04
000079035ddcf9c0  mov r10d, 0xC0
000079035ddcf9c6  cmp r12, r10
000079035ddcf9c9  cmc
000079035ddcf9ca  lahf
000079035ddcf9cb  seto al
000079035ddcf9ce  mov [r15+0x108], eax
000079035ddcf9d5  mov eax, [rsp+0x10]
000079035ddcf9d9  mov r12d, [rsp+0x10]
000079035ddcf9de  shrd eax, r12d, 0x07
000079035ddcf9e3  mov [rsp+0x10], r11d
000079035ddcf9e8  mov r10d, [rsp+0x10]
000079035ddcf9ed  shrd r11d, r10d, 0x11
000079035ddcf9f2  mov r9d, [rsp+0x20]
000079035ddcf9f7  lea r8d, [r9d+r14d*1]
000079035ddcf9fc  rorx r14d, r12d, 0x12
000079035ddcfa02  xor eax, r14d
000079035ddcfa05  rorx r14d, r10d, 0x13
000079035ddcfa0b  xor r11d, r14d
000079035ddcfa0e  mov [rsp+0x10], r11d
000079035ddcfa13  mov r11d, r11d
000079035ddcfa16  mov [r15+0x88], r11
000079035ddcfa1d  mov [rsp+0x20], r12d
000079035ddcfa22  shr r12d, 0x03
000079035ddcfa26  xor eax, r12d
000079035ddcfa29  mov [rsp+0x40], eax
000079035ddcfa2d  mov eax, eax
000079035ddcfa2f  mov [r15+0x80], rax
000079035ddcfa36  shr r10d, 0x0A
000079035ddcfa3a  mov eax, [rsp+0x10]
000079035ddcfa3e  xor eax, r10d
000079035ddcfa41  mov [rsp+0x10], eax
000079035ddcfa45  mov eax, eax
000079035ddcfa47  mov [r15+0x78], rax
000079035ddcfa4b  mov eax, [rsp+0x40]
000079035ddcfa4f  lea r14d, [r8d+eax*1]
000079035ddcfa54  mov eax, [rsp+0x10]
000079035ddcfa58  lea r12d, [r14d+eax*1]
000079035ddcfa5d  mov rax, [rsp+0x30]
000079035ddcfa62  lea r14, [rax+0x40]
000079035ddcfa66  mov [r13+r14*1], r12d
000079035ddcfa6b  mov eax, [rsp+0x20]
000079035ddcfa6f  mov eax, eax
000079035ddcfa71  mov [r15+0x60], rax
000079035ddcfa75  mov eax, [r15+0x108]
000079035ddcfa7c  sahf
000079035ddcfa7d  jnz 0x000079035DDCFAAF
000079035ddcfa7f  cmp dword ptr [r15+0x318], 0x00
000079035ddcfa87  jz 0x000079035DDCFF70
000079035ddcfa8d  nop [rax+rax*1], ax
000079035ddcfa96  nop [rax+rax*1], eax
000079035ddcfa9e  mov eax, 0x41088C
000079035ddcfaa3  mov [r15+0x100], rax
000079035ddcfaaa  jmp 0x000079035DBFE110
000079035ddcfaaf  cmp dword ptr [r15+0x318], 0x00
000079035ddcfab7  jz 0x000079035DDCFDC0
000079035ddcfabd  nop [rax+rax*1], ax
000079035ddcfac6  nop [rax+rax*1], eax
000079035ddcface  mov eax, 0x410844
000079035ddcfad3  mov [r15+0x100], rax
000079035ddcfada  jmp 0x000079035DBFE110
000079035ddcfadf  int3
000079035ddcfae0  call 0x000079035DC0D860
000079035ddcfae5  jmp 0x000079035DDCF17A
000079035ddcfaea  call 0x000079035DCE2420
000079035ddcfaef  jmp 0x000079035DDCF193
000079035ddcfaf4  call 0x000079035DCE2420
000079035ddcfaf9  jmp 0x000079035DDCF1AC
000079035ddcfafe  call 0x000079035DCE2420
000079035ddcfb03  jmp 0x000079035DDCF1C5
000079035ddcfb08  call 0x000079035DCE2420
000079035ddcfb0d  jmp 0x000079035DDCF1DE
000079035ddcfb12  call 0x000079035DCE2420
000079035ddcfb17  jmp 0x000079035DDCF1EF
000079035ddcfb1c  call 0x000079035DCE2420
000079035ddcfb21  jmp 0x000079035DDCF200
000079035ddcfb26  call 0x000079035DCE2420
000079035ddcfb2b  jmp 0x000079035DDCF211
000079035ddcfb30  call 0x000079035DCE2420
000079035ddcfb35  jmp 0x000079035DDCF222
000079035ddcfb3a  call 0x000079035DCE2420
000079035ddcfb3f  jmp 0x000079035DDCF233
000079035ddcfb44  call 0x000079035DCE2420
000079035ddcfb49  jmp 0x000079035DDCF244
000079035ddcfb4e  call 0x000079035DCE2420
000079035ddcfb53  jmp 0x000079035DDCF255
000079035ddcfb58  call 0x000079035DCE2420
000079035ddcfb5d  jmp 0x000079035DDCF266
000079035ddcfb62  call 0x000079035DCE2420
000079035ddcfb67  jmp 0x000079035DDCF277
000079035ddcfb6c  call 0x000079035DCE2420
000079035ddcfb71  jmp 0x000079035DDCF288
000079035ddcfb76  call 0x000079035DCE2420
000079035ddcfb7b  jmp 0x000079035DDCF299
000079035ddcfb80  call 0x000079035DCE2420
000079035ddcfb85  jmp 0x000079035DDCF2AA
000079035ddcfb8a  call 0x000079035DCE2420
000079035ddcfb8f  jmp 0x000079035DDCF2BB
000079035ddcfb94  call 0x000079035DCE2420
000079035ddcfb99  jmp 0x000079035DDCF2CC
000079035ddcfb9e  call 0x000079035DCE2420
000079035ddcfba3  jmp 0x000079035DDCF2DD
000079035ddcfba8  call 0x000079035DCE2420
000079035ddcfbad  jmp 0x000079035DDCF2EE
000079035ddcfbb2  call 0x000079035DCE2420
000079035ddcfbb7  jmp 0x000079035DDCF2FF
000079035ddcfbbc  call 0x000079035DCE2420
000079035ddcfbc1  jmp 0x000079035DDCF310
000079035ddcfbc6  call 0x000079035DCE2420
000079035ddcfbcb  jmp 0x000079035DDCF321
000079035ddcfbd0  call 0x000079035DCE2420
000079035ddcfbd5  jmp 0x000079035DDCF332
000079035ddcfbda  call 0x000079035DCE2420
000079035ddcfbdf  jmp 0x000079035DDCF343
000079035ddcfbe4  call 0x000079035DCE2420
000079035ddcfbe9  jmp 0x000079035DDCF354
000079035ddcfbee  call 0x000079035DCE2420
000079035ddcfbf3  jmp 0x000079035DDCF365
000079035ddcfbf8  call 0x000079035DCE2420
000079035ddcfbfd  jmp 0x000079035DDCF376
000079035ddcfc02  call 0x000079035DCE2420
000079035ddcfc07  jmp 0x000079035DDCF387
000079035ddcfc0c  call 0x000079035DCE2420
000079035ddcfc11  jmp 0x000079035DDCF398
000079035ddcfc16  call 0x000079035DCE2420
000079035ddcfc1b  jmp 0x000079035DDCF3A9
000079035ddcfc20  call 0x000079035DCE2420
000079035ddcfc25  jmp 0x000079035DDCF3BA
000079035ddcfc2a  call 0x000079035DCE2420
000079035ddcfc2f  jmp 0x000079035DDCF3CB
000079035ddcfc34  call 0x000079035DCE2420
000079035ddcfc39  jmp 0x000079035DDCF3DC
000079035ddcfc3e  call 0x000079035DCE2420
000079035ddcfc43  jmp 0x000079035DDCF3ED
000079035ddcfc48  call 0x000079035DCE2420
000079035ddcfc4d  jmp 0x000079035DDCF3FE
000079035ddcfc52  call 0x000079035DCE2420
000079035ddcfc57  jmp 0x000079035DDCF40F
000079035ddcfc5c  call 0x000079035DCE2420
000079035ddcfc61  jmp 0x000079035DDCF420
000079035ddcfc66  call 0x000079035DCE2420
000079035ddcfc6b  jmp 0x000079035DDCF431
000079035ddcfc70  call 0x000079035DCE2420
000079035ddcfc75  jmp 0x000079035DDCF442
000079035ddcfc7a  call 0x000079035DCE2420
000079035ddcfc7f  jmp 0x000079035DDCF453
000079035ddcfc84  call 0x000079035DCE2420
000079035ddcfc89  jmp 0x000079035DDCF464
000079035ddcfc8e  call 0x000079035DCE2420
000079035ddcfc93  jmp 0x000079035DDCF475
000079035ddcfc98  call 0x000079035DCE2420
000079035ddcfc9d  jmp 0x000079035DDCF486
000079035ddcfca2  call 0x000079035DCE2420
000079035ddcfca7  jmp 0x000079035DDCF497
000079035ddcfcac  call 0x000079035DCE2420
000079035ddcfcb1  jmp 0x000079035DDCF4A8
000079035ddcfcb6  call 0x000079035DCE2420
000079035ddcfcbb  jmp 0x000079035DDCF4B9
000079035ddcfcc0  call 0x000079035DCE2420
000079035ddcfcc5  jmp 0x000079035DDCF4CA
000079035ddcfcca  call 0x000079035DCE2420
000079035ddcfccf  jmp 0x000079035DDCF4DB
000079035ddcfcd4  call 0x000079035DCE2420
000079035ddcfcd9  jmp 0x000079035DDCF4EC
000079035ddcfcde  call 0x000079035DCE2420
000079035ddcfce3  jmp 0x000079035DDCF4FD
000079035ddcfce8  call 0x000079035DCE2420
000079035ddcfced  jmp 0x000079035DDCF50E
000079035ddcfcf2  call 0x000079035DCE2420
000079035ddcfcf7  jmp 0x000079035DDCF51F
000079035ddcfcfc  call 0x000079035DCE2420
000079035ddcfd01  jmp 0x000079035DDCF530
000079035ddcfd06  call 0x000079035DCE2420
000079035ddcfd0b  jmp 0x000079035DDCF541
000079035ddcfd10  call 0x000079035DCE2420
000079035ddcfd15  jmp 0x000079035DDCF552
000079035ddcfd1a  call 0x000079035DCE2420
000079035ddcfd1f  jmp 0x000079035DDCF563
000079035ddcfd24  call 0x000079035DCE2420
000079035ddcfd29  jmp 0x000079035DDCF574
000079035ddcfd2e  call 0x000079035DCE2420
000079035ddcfd33  jmp 0x000079035DDCF585
000079035ddcfd38  call 0x000079035DCE2420
000079035ddcfd3d  jmp 0x000079035DDCF596
000079035ddcfd42  call 0x000079035DCE2420
000079035ddcfd47  jmp 0x000079035DDCF5AF
000079035ddcfd4c  call 0x000079035DCE2420
000079035ddcfd51  jmp 0x000079035DDCF5C8
000079035ddcfd56  call 0x000079035DCD5610
000079035ddcfd5b  jmp 0x000079035DDCF5E1
000079035ddcfd60  call 0x000079035DCDC580
000079035ddcfd65  jmp 0x000079035DDCF94E
000079035ddcfd6a  call 0x000079035DCE46C0
000079035ddcfd6f  jmp 0x000079035DDCF958
000079035ddcfd74  call 0x000079035DC09E90
000079035ddcfd79  jmp 0x000079035DDCF95E
000079035ddcfd7e  call 0x000079035DCDB310
000079035ddcfd83  jmp 0x000079035DDCF968
000079035ddcfd88  call 0x000079035DC0DAE0
000079035ddcfd8d  jmp 0x000079035DDCF96D
000079035ddcfd92  call 0x000079035DCC0230
000079035ddcfd97  jmp 0x000079035DDCF986
000079035ddcfd9c  call 0x000079035DCC0230
000079035ddcfda1  jmp 0x000079035DDCF99B
000079035ddcfda6  call 0x000079035DCBEFC0
000079035ddcfdab  jmp 0x000079035DDCF9A4
000079035ddcfdb0  call 0x000079035DCE2BA0
000079035ddcfdb5  jmp 0x000079035DDCFA6B
000079035ddcfdba  int3
000079035ddcfdbb  nop [rax+rax*1], eax
000079035ddcfdc0  mov rax, [r15+0x48]
000079035ddcfdc4  mov r14, [r15+0x58]
000079035ddcfdc8  lea r12, [rax+r14*1]
000079035ddcfdcc  mov [r15+0x68], r12
000079035ddcfdd0  lea rax, [r14+0x04]
000079035ddcfdd4  mov [r15+0x58], rax
000079035ddcfdd8  lea r14, [r12+0x04]
000079035ddcfddd  mov r11d, [r13+r14*1]
000079035ddcfde2  mov [rsp+0x10], r11d
000079035ddcfde7  mov r11d, r11d
000079035ddcfdea  mov [r15+0x70], r11
000079035ddcfdee  lea r14, [r12+0x38]
000079035ddcfdf3  mov r11d, [r13+r14*1]
000079035ddcfdf8  lea r14, [r12+0x24]
000079035ddcfdfd  mov r10d, [r13+r14*1]
000079035ddcfe02  mov [rsp+0x20], r10d
000079035ddcfe07  mov r10d, r10d
000079035ddcfe0a  mov [r15+0x90], r10
000079035ddcfe11  mov [rsp+0x30], rax
000079035ddcfe16  xor eax, eax
000079035ddcfe18  mov r14, [rsp+0x30]
000079035ddcfe1d  mov r10d, 0xC0
000079035ddcfe23  cmp r14, r10
000079035ddcfe26  cmc
000079035ddcfe27  lahf
000079035ddcfe28  seto al
000079035ddcfe2b  mov [r15+0x108], eax
000079035ddcfe32  mov eax, [rsp+0x10]
000079035ddcfe36  mov r14d, [rsp+0x10]
000079035ddcfe3b  shrd eax, r14d, 0x07
000079035ddcfe40  mov [rsp+0x10], r11d
000079035ddcfe45  mov r10d, [rsp+0x10]
000079035ddcfe4a  shrd r11d, r10d, 0x11
000079035ddcfe4f  mov r9d, [r15+0x60]
000079035ddcfe53  mov r8d, [rsp+0x20]
000079035ddcfe58  lea ebp, [r8d+r9d*1]
000079035ddcfe5d  rorx r9d, r14d, 0x12
000079035ddcfe63  xor eax, r9d
000079035ddcfe66  rorx r9d, r10d, 0x13
000079035ddcfe6c  xor r11d, r9d
000079035ddcfe6f  mov [rsp+0x10], r11d
000079035ddcfe74  mov r11d, r11d
000079035ddcfe77  mov [r15+0x88], r11
000079035ddcfe7e  mov [rsp+0x20], r14d
000079035ddcfe83  shr r14d, 0x03
000079035ddcfe87  xor eax, r14d
000079035ddcfe8a  mov [rsp+0x30], eax
000079035ddcfe8e  mov eax, eax
000079035ddcfe90  mov [r15+0x80], rax
000079035ddcfe97  shr r10d, 0x0A
000079035ddcfe9b  mov eax, [rsp+0x10]
000079035ddcfe9f  xor eax, r10d
000079035ddcfea2  mov [rsp+0x10], eax
000079035ddcfea6  mov eax, eax
000079035ddcfea8  mov [r15+0x78], rax
000079035ddcfeac  mov eax, [rsp+0x30]
000079035ddcfeb0  lea r14d, [ebp+eax*1]
000079035ddcfeb6  mov eax, [rsp+0x10]
000079035ddcfeba  lea r11d, [r14d+eax*1]
000079035ddcfebf  lea rax, [r12+0x40]
000079035ddcfec4  mov [r13+rax*1], r11d
000079035ddcfec9  mov eax, [rsp+0x20]
000079035ddcfecd  mov eax, eax
000079035ddcfecf  mov [r15+0x60], rax
000079035ddcfed3  mov eax, [r15+0x108]
000079035ddcfeda  sahf
000079035ddcfedb  jnz 0x000079035DDCFF0D
000079035ddcfedd  cmp dword ptr [r15+0x318], 0x00
000079035ddcfee5  jz 0x000079035DDCFF70
000079035ddcfeeb  nop [rax+rax*1], ax
000079035ddcfef4  nop [rax+rax*1], eax
000079035ddcfefc  mov eax, 0x41088C
000079035ddcff01  mov [r15+0x100], rax
000079035ddcff08  jmp 0x000079035DBFE110
000079035ddcff0d  cmp dword ptr [r15+0x318], 0x00
000079035ddcff15  jz 0x000079035DDCFDC0
000079035ddcff1b  nop [rax+rax*1], ax
000079035ddcff24  nop [rax+rax*1], eax
000079035ddcff2c  mov eax, 0x410844
000079035ddcff31  mov [r15+0x100], rax
000079035ddcff38  jmp 0x000079035DBFE110
000079035ddcff3d  int3
000079035ddcff3e  call 0x000079035DCE1430
000079035ddcff43  jmp 0x000079035DDCFDE2
000079035ddcff48  call 0x000079035DCE1430
000079035ddcff4d  jmp 0x000079035DDCFDF8
000079035ddcff52  call 0x000079035DCE01C0
000079035ddcff57  jmp 0x000079035DDCFE02
000079035ddcff5c  call 0x000079035DC0A860
000079035ddcff61  jmp 0x000079035DDCFEC9
000079035ddcff66  int3
000079035ddcff67  nop [rax+rax*1], ax
000079035ddcff70  mov rax, [r15]
000079035ddcff73  mov r14d, [r13+rax*1]
000079035ddcff78  lea r12, [rax+0x04]
000079035ddcff7c  mov r11d, [r13+r12*1]
000079035ddcff81  mov [rsp+0x10], r14d
000079035ddcff86  mov r14d, r14d
000079035ddcff89  mov [r15+0x78], r14
000079035ddcff8d  mov [rsp+0x20], r11d
000079035ddcff92  mov r11d, r11d
000079035ddcff95  mov [r15+0x80], r11
000079035ddcff9c  lea r14, [rax+0x08]
000079035ddcffa0  mov r12d, [r13+r14*1]
000079035ddcffa5  lea r14, [rax+0x0C]
000079035ddcffa9  mov r11d, [r13+r14*1]
000079035ddcffae  mov [rsp+0x30], r12d
000079035ddcffb3  mov r12d, r12d
000079035ddcffb6  mov [r15+0x70], r12
000079035ddcffba  mov [rsp+0x40], r11d
000079035ddcffbf  mov r11d, r11d
000079035ddcffc2  mov [r15+0x68], r11
000079035ddcffc6  lea r14, [rax+0x18]
000079035ddcffca  mov r12d, [r13+r14*1]
000079035ddcffcf  lea r14, [rax+0x1C]
000079035ddcffd3  mov r11d, [r13+r14*1]
000079035ddcffd8  mov [rsp+0x50], r12d
000079035ddcffdd  mov r12d, r12d
000079035ddcffe0  mov [r15+0x58], r12
000079035ddcffe4  mov [rsp+0x60], r11d
000079035ddcffe9  mov r11d, r11d
000079035ddcffec  mov [r15+0x60], r11
000079035ddcfff0  lea r14, [rax+0x10]
000079035ddcfff4  mov r12d, [r13+r14*1]
000079035ddcfff9  lea r14, [rax+0x14]
000079035ddcfffd  mov eax, [r13+r14*1]
000079035ddd0002  mov [rsp+0x70], r12d
000079035ddd0007  mov r12d, r12d
000079035ddd000a  mov [r15+0x18], r12
000079035ddd000e  mov [rsp+0x80], eax
000079035ddd0015  mov eax, eax
000079035ddd0017  mov [r15+0x90], rax
000079035ddd001e  mov eax, [rsp+0x70]
000079035ddd0022  mov eax, eax
000079035ddd0024  mov [r15+0x30], rax
000079035ddd0028  mov eax, [rsp+0x50]
000079035ddd002c  mov eax, eax
000079035ddd002e  mov [r15+0xA0], rax
000079035ddd0035  mov eax, [rsp+0x30]
000079035ddd0039  mov eax, eax
000079035ddd003b  mov [r15+0x28], rax
000079035ddd003f  mov eax, [rsp+0x20]
000079035ddd0043  mov eax, eax
000079035ddd0045  mov [r15+0x98], rax
000079035ddd004c  mov eax, [rsp+0x10]
000079035ddd0050  mov eax, eax
000079035ddd0052  mov [r15+0x38], rax
000079035ddd0056  mov eax, [rsp+0x70]
000079035ddd005a  mov r14d, [rsp+0x70]
000079035ddd005f  shrd eax, r14d, 0x06
000079035ddd0064  mov [rsp+0x70], r14d
000079035ddd0069  mov r12d, [rsp+0x80]
000079035ddd0071  and r14d, r12d
000079035ddd0074  mov r11d, [rsp+0x10]
000079035ddd0079  mov r10d, [rsp+0x10]
000079035ddd007e  shrd r11d, r10d, 0x02
000079035ddd0083  mov [rsp+0x10], r12d
000079035ddd0088  mov r12d, r12d
000079035ddd008b  mov [r15+0x20], r12
000079035ddd008f  mov r12, [r15+0x50]
000079035ddd0093  mov r9d, [r13+r12*1]
000079035ddd0098  mov r12d, [rsp+0x50]
000079035ddd009d  mov r8d, [rsp+0x70]
000079035ddd00a2  andn ebp, r8d, r12d
000079035ddd00a7  mov edi, [rsp+0x60]
000079035ddd00ab  lea esi, [r14d+edi*1]
000079035ddd00b0  rorx r14d, r8d, 0x0B
000079035ddd00b6  xor eax, r14d
000079035ddd00b9  rorx r14d, r10d, 0x0D
000079035ddd00bf  xor r11d, r14d
000079035ddd00c2  lea edi, [esi+ebp*1]
000079035ddd00c6  mov r14, [r15+0x48]
000079035ddd00ca  mov ebp, [r13+r14*1]
000079035ddd00cf  mov r14d, [rsp+0x30]
000079035ddd00d4  mov esi, [rsp+0x20]
000079035ddd00d8  and r14d, esi
000079035ddd00db  mov [rsp+0x20], r14d
000079035ddd00e0  mov r14d, r14d
000079035ddd00e3  mov [r15+0xD8], r14
000079035ddd00ea  lea r14d, [edi+r9d*1]
000079035ddd00ef  mov r9d, [rsp+0x30]
000079035ddd00f4  xor r9d, esi
000079035ddd00f7  rorx edi, r8d, 0x19
000079035ddd00fd  xor eax, edi
000079035ddd00ff  and r9d, r10d
000079035ddd0102  rorx edi, r10d, 0x16
000079035ddd0108  xor r11d, edi
000079035ddd010b  mov [rsp+0x30], r11d
000079035ddd0110  mov r11d, r11d
000079035ddd0113  mov [r15+0xD0], r11
000079035ddd011a  lea r11d, [r14d+ebp*1]
000079035ddd011f  mov r10d, [rsp+0x20]
000079035ddd0124  xor r9d, r10d
000079035ddd0127  lea r14d, [r11d+eax*1]
000079035ddd012c  mov qword ptr [r15+0x88], 0x04
000079035ddd0137  mov eax, [rsp+0x30]
000079035ddd013b  lea r11d, [r9d+eax*1]
000079035ddd0140  mov eax, [rsp+0x40]
000079035ddd0144  lea r10d, [r14d+eax*1]
000079035ddd0149  mov r10d, r10d
000079035ddd014c  mov [r15+0xB8], r10
000079035ddd0153  xor eax, eax
000079035ddd0155  mov r10d, 0x04
000079035ddd015b  mov r9d, 0x100
000079035ddd0161  cmp r10, r9
000079035ddd0164  cmc
000079035ddd0165  lahf
000079035ddd0166  seto al
000079035ddd0169  mov [r15+0x108], eax
000079035ddd0170  lea eax, [r11d+r14d*1]
000079035ddd0175  mov eax, eax
000079035ddd0177  mov [r15+0xA8], rax
000079035ddd017e  mov r12d, r12d
000079035ddd0181  mov [r15+0xB0], r12
000079035ddd0188  mov eax, [rsp+0x10]
000079035ddd018c  mov eax, eax
000079035ddd018e  mov [r15+0xC0], rax
000079035ddd0195  mov r8d, r8d
000079035ddd0198  mov [r15+0xC8], r8
000079035ddd019f  mov eax, [r15+0x108]
000079035ddd01a6  sahf
000079035ddd01a7  jnz 0x000079035DDD01D9
000079035ddd01a9  cmp dword ptr [r15+0x318], 0x00
000079035ddd01b1  jz 0x000079035DDD04A0
000079035ddd01b7  nop [rax+rax*1], ax
000079035ddd01c0  nop [rax+rax*1], eax
000079035ddd01c8  mov eax, 0x41094C
000079035ddd01cd  mov [r15+0x100], rax
000079035ddd01d4  jmp 0x000079035DBFE110
000079035ddd01d9  cmp dword ptr [r15+0x318], 0x00
000079035ddd01e1  jz 0x000079035DDD0270
000079035ddd01e7  nop [rax+rax*1], ax
000079035ddd01f0  nop [rax+rax*1], eax
000079035ddd01f8  mov eax, 0x4108C0
000079035ddd01fd  mov [r15+0x100], rax
000079035ddd0204  jmp 0x000079035DBFE110
000079035ddd0209  int3
000079035ddd020a  call 0x000079035DC0DAE0
000079035ddd020f  jmp 0x000079035DDCFF78
000079035ddd0214  call 0x000079035DCC0230
000079035ddd0219  jmp 0x000079035DDCFF81
000079035ddd021e  call 0x000079035DCE26A0
000079035ddd0223  jmp 0x000079035DDCFFA5
000079035ddd0228  call 0x000079035DCE1430
000079035ddd022d  jmp 0x000079035DDCFFAE
000079035ddd0232  call 0x000079035DCE26A0
000079035ddd0237  jmp 0x000079035DDCFFCF
000079035ddd023c  call 0x000079035DCE1430
000079035ddd0241  jmp 0x000079035DDCFFD8
000079035ddd0246  call 0x000079035DCE26A0
000079035ddd024b  jmp 0x000079035DDCFFF9
000079035ddd0250  call 0x000079035DCD5890
000079035ddd0255  jmp 0x000079035DDD0002
000079035ddd025a  call 0x000079035DCBDD50
000079035ddd025f  jmp 0x000079035DDD0098
000079035ddd0264  call 0x000079035DCDA580
000079035ddd0269  jmp 0x000079035DDD00CF
000079035ddd026e  int3
000079035ddd026f  nop
000079035ddd0270  mov eax, [r15+0xB8]
000079035ddd0277  mov [rsp+0x10], eax
000079035ddd027b  mov eax, eax
000079035ddd027d  mov [r15+0x30], rax
000079035ddd0281  mov eax, [r15+0xC0]
000079035ddd0288  mov [rsp+0x20], eax
000079035ddd028c  mov eax, eax
000079035ddd028e  mov [r15+0xA0], rax
000079035ddd0295  mov eax, [r15+0x28]
000079035ddd0299  mov r14d, [r15+0x98]
000079035ddd02a0  mov [rsp+0x30], r14d
000079035ddd02a5  mov r14d, r14d
000079035ddd02a8  mov [r15+0x28], r14
000079035ddd02ac  mov r14d, [r15+0x38]
000079035ddd02b0  mov [rsp+0x40], r14d
000079035ddd02b5  mov r14d, r14d
000079035ddd02b8  mov [r15+0x98], r14
000079035ddd02bf  mov r14d, [r15+0xA8]
000079035ddd02c6  mov [rsp+0x50], r14d
000079035ddd02cb  mov r14d, r14d
000079035ddd02ce  mov [r15+0x38], r14
000079035ddd02d2  mov r14d, [rsp+0x10]
000079035ddd02d7  mov r12d, [rsp+0x10]
000079035ddd02dc  shrd r14d, r12d, 0x06
000079035ddd02e1  mov r11d, [r15+0xC8]
000079035ddd02e8  mov [rsp+0x10], r12d
000079035ddd02ed  and r12d, r11d
000079035ddd02f0  mov r10d, [rsp+0x50]
000079035ddd02f5  mov r9d, [rsp+0x50]
000079035ddd02fa  shrd r10d, r9d, 0x02
000079035ddd02ff  mov [rsp+0x50], r11d
000079035ddd0304  mov r11d, r11d
000079035ddd0307  mov [r15+0x20], r11
000079035ddd030b  mov r11, [r15+0x88]
000079035ddd0312  mov r8, [r15+0x50]
000079035ddd0316  lea rbp, [r8+r11*1]
000079035ddd031a  mov r8d, [r13+rbp*1]
000079035ddd031f  mov ebp, [rsp+0x20]
000079035ddd0323  mov edi, [rsp+0x10]
000079035ddd0327  andn esi, edi, ebp
000079035ddd032c  mov edx, [r15+0xB0]
000079035ddd0333  lea ecx, [r12d+edx*1]
000079035ddd0338  rorx r12d, edi, 0x0B
000079035ddd033e  xor r14d, r12d
000079035ddd0341  rorx r12d, r9d, 0x0D
000079035ddd0347  xor r10d, r12d
000079035ddd034a  lea r12d, [ecx+esi*1]
000079035ddd034f  mov rsi, [r15+0x48]
000079035ddd0353  lea rdx, [rsi+r11*1]
000079035ddd0357  mov esi, [r13+rdx*1]
000079035ddd035c  mov edx, [rsp+0x30]
000079035ddd0360  mov ecx, [rsp+0x40]
000079035ddd0364  and edx, ecx
000079035ddd0366  mov [rsp+0x10], edx
000079035ddd036a  mov edx, edx
000079035ddd036c  mov [r15+0xD8], rdx
000079035ddd0373  lea edx, [r12d+r8d*1]
000079035ddd0378  mov r12d, [rsp+0x30]
000079035ddd037d  xor r12d, ecx
000079035ddd0380  rorx r8d, edi, 0x19
000079035ddd0386  xor r14d, r8d
000079035ddd0389  and r12d, r9d
000079035ddd038c  rorx r8d, r9d, 0x16
000079035ddd0392  xor r10d, r8d
000079035ddd0395  mov [rsp+0x20], r10d
000079035ddd039a  mov r10d, r10d
000079035ddd039d  mov [r15+0xD0], r10
000079035ddd03a4  lea r10d, [edx+esi*1]
000079035ddd03a9  mov r9d, [rsp+0x10]
000079035ddd03ae  xor r12d, r9d
000079035ddd03b1  lea r9d, [r10d+r14d*1]
000079035ddd03b6  lea r14, [r11+0x04]
000079035ddd03ba  mov [r15+0x88], r14
000079035ddd03c1  mov r11d, [rsp+0x20]
000079035ddd03c6  lea r10d, [r12d+r11d*1]
000079035ddd03cb  lea r11d, [r9d+eax*1]
000079035ddd03d0  mov r11d, r11d
000079035ddd03d3  mov [r15+0xB8], r11
000079035ddd03da  xor eax, eax
000079035ddd03dc  mov r12d, 0x100
000079035ddd03e2  cmp r14, r12
000079035ddd03e5  cmc
000079035ddd03e6  lahf
000079035ddd03e7  seto al
000079035ddd03ea  mov [r15+0x108], eax
000079035ddd03f1  lea eax, [r10d+r9d*1]
000079035ddd03f6  mov eax, eax
000079035ddd03f8  mov [r15+0xA8], rax
000079035ddd03ff  mov ebp, ebp
000079035ddd0401  mov [r15+0xB0], rbp
000079035ddd0408  mov eax, [rsp+0x50]
000079035ddd040c  mov eax, eax
000079035ddd040e  mov [r15+0xC0], rax
000079035ddd0415  mov edi, edi
000079035ddd0417  mov [r15+0xC8], rdi
000079035ddd041e  mov eax, [r15+0x108]
000079035ddd0425  sahf
000079035ddd0426  jnz 0x000079035DDD0458
000079035ddd0428  cmp dword ptr [r15+0x318], 0x00
000079035ddd0430  jz 0x000079035DDD04A0
000079035ddd0436  nop [rax+rax*1], ax
000079035ddd043f  nop [rax+rax*1], eax
000079035ddd0447  mov eax, 0x41094C
000079035ddd044c  mov [r15+0x100], rax
000079035ddd0453  jmp 0x000079035DBFE110
000079035ddd0458  cmp dword ptr [r15+0x318], 0x00
000079035ddd0460  jz 0x000079035DDD0270
000079035ddd0466  nop [rax+rax*1], ax
000079035ddd046f  nop [rax+rax*1], eax
000079035ddd0477  mov eax, 0x4108C0
000079035ddd047c  mov [r15+0x100], rax
000079035ddd0483  jmp 0x000079035DBFE110
000079035ddd0488  int3
000079035ddd0489  call 0x000079035DC49010
000079035ddd048e  jmp 0x000079035DDD031F
000079035ddd0493  call 0x000079035DC25930
000079035ddd0498  jmp 0x000079035DDD035C
000079035ddd049d  int3
000079035ddd049e  nop
000079035ddd04a0  mov eax, [r15+0x98]
000079035ddd04a7  mov r14d, [r15+0x70]
000079035ddd04ab  lea r12d, [eax+r14d*1]
000079035ddd04b0  mov eax, [r15+0x28]
000079035ddd04b4  mov r14d, [r15+0x68]
000079035ddd04b8  lea r11d, [eax+r14d*1]
000079035ddd04bd  mov qword ptr [r15+0x88], 0x00
000079035ddd04c8  mov eax, [r15+0xA8]
000079035ddd04cf  mov r14d, [r15+0x78]
000079035ddd04d3  lea r10d, [eax+r14d*1]
000079035ddd04d8  mov [rsp+0x10], r10d
000079035ddd04dd  mov r10d, r10d
000079035ddd04e0  mov [r15+0x78], r10
000079035ddd04e4  mov eax, [r15+0x38]
000079035ddd04e8  mov r14d, [r15+0x80]
000079035ddd04ef  lea r10d, [eax+r14d*1]
000079035ddd04f4  mov [rsp+0x20], r10d
000079035ddd04f9  mov r10d, r10d
000079035ddd04fc  mov [r15+0x80], r10
000079035ddd0503  mov rax, [r15]
000079035ddd0506  lea r14, [rax+0x08]
000079035ddd050a  mov [r13+r14*1], r12d
000079035ddd050f  lea r14, [rax+0x0C]
000079035ddd0513  mov [r13+r14*1], r11d
000079035ddd0518  mov r14d, [r15+0xB8]
000079035ddd051f  mov r12d, [r15+0x18]
000079035ddd0523  lea r11d, [r14d+r12d*1]
000079035ddd0528  mov [rsp+0x30], r11d
000079035ddd052d  mov r11d, r11d
000079035ddd0530  mov [r15+0x68], r11
000079035ddd0534  mov r14d, [r15+0x30]
000079035ddd0538  mov r12d, [r15+0x90]
000079035ddd053f  lea r11d, [r14d+r12d*1]
000079035ddd0544  mov [rsp+0x40], r11d
000079035ddd0549  mov r11d, r11d
000079035ddd054c  mov [r15+0x70], r11
000079035ddd0550  mov r14d, [r15+0x20]
000079035ddd0554  mov r12d, [r15+0x58]
000079035ddd0558  lea r11d, [r14d+r12d*1]
000079035ddd055d  mov [rsp+0x50], r11d
000079035ddd0562  mov r11d, r11d
000079035ddd0565  mov [r15+0x58], r11
000079035ddd0569  mov r14d, [r15+0xA0]
000079035ddd0570  mov r12d, [r15+0x60]
000079035ddd0574  lea r11d, [r14d+r12d*1]
000079035ddd0579  mov [rsp+0x60], r11d
000079035ddd057e  mov r11d, r11d
000079035ddd0581  mov [r15+0x60], r11
000079035ddd0585  mov r14d, [rsp+0x10]
000079035ddd058a  mov [r13+rax*1], r14d
000079035ddd058f  lea r14, [rax+0x04]
000079035ddd0593  mov r12d, [rsp+0x20]
000079035ddd0598  mov [r13+r14*1], r12d
000079035ddd059d  lea r14, [rax+0x10]
000079035ddd05a1  mov r12d, [rsp+0x30]
000079035ddd05a6  mov [r13+r14*1], r12d
000079035ddd05ab  lea r14, [rax+0x14]
000079035ddd05af  mov r12d, [rsp+0x40]
000079035ddd05b4  mov [r13+r14*1], r12d
000079035ddd05b9  lea r14, [rax+0x18]
000079035ddd05bd  mov r12d, [rsp+0x50]
000079035ddd05c2  mov [r13+r14*1], r12d
000079035ddd05c7  lea r14, [rax+0x1C]
000079035ddd05cb  mov r12d, [rsp+0x60]
000079035ddd05d0  mov [r13+r14*1], r12d
000079035ddd05d5  lea r14, [rax+0x68]
000079035ddd05d9  xor eax, eax
000079035ddd05db  mov [r13+r14*1], rax
000079035ddd05e0  cmp dword ptr [r15+0x318], 0x00
000079035ddd05e8  jz 0x000079035DDCF0E0
000079035ddd05ee  nop [rax+rax*1], ax
000079035ddd05f7  nop [rax+rax*1], eax
000079035ddd05ff  mov eax, 0x410768
000079035ddd0604  mov [r15+0x100], rax
000079035ddd060b  jmp 0x000079035DBFE110
000079035ddd0610  int3
000079035ddd0611  call 0x000079035DCE2BA0
000079035ddd0616  jmp 0x000079035DDD050F
000079035ddd061b  call 0x000079035DCE1920
000079035ddd0620  jmp 0x000079035DDD0518
000079035ddd0625  call 0x000079035DC0DFE0
000079035ddd062a  jmp 0x000079035DDD058F
000079035ddd062f  call 0x000079035DCE2BA0
000079035ddd0634  jmp 0x000079035DDD059D
000079035ddd0639  call 0x000079035DCE2BA0
000079035ddd063e  jmp 0x000079035DDD05AB
000079035ddd0643  call 0x000079035DCE2BA0
000079035ddd0648  jmp 0x000079035DDD05B9
000079035ddd064d  call 0x000079035DCE2BA0
000079035ddd0652  jmp 0x000079035DDD05C7
000079035ddd0657  call 0x000079035DCE2BA0
000079035ddd065c  jmp 0x000079035DDD05D5
000079035ddd0661  call 0x000079035DCD5EB0
000079035ddd0666  jmp 0x000079035DDD05E0
000079035ddd066b  int3
000079035ddd066c  nop [rax], eax
000079035ddd0670  mov rax, [r15+0xF8]
000079035ddd0677  lea r14, [rax+0x140]
000079035ddd067e  mov r12, [r13+r14*1]
000079035ddd0683  lea r14, [rax+0x148]
000079035ddd068a  mov r11, [r13+r14*1]
000079035ddd068f  mov [r15+0xA0], r12
000079035ddd0696  mov [r15+0x98], r11
000079035ddd069d  lea r14, [rax+0x130]
000079035ddd06a4  mov r12, [r13+r14*1]
000079035ddd06a9  lea r14, [rax+0x138]
000079035ddd06b0  mov r11, [r13+r14*1]
000079035ddd06b5  mov [r15+0xB0], r12
000079035ddd06bc  mov [r15+0xA8], r11
000079035ddd06c3  lea r14, [rax+0x120]
000079035ddd06ca  mov r12, [r13+r14*1]
000079035ddd06cf  lea r14, [rax+0x128]
000079035ddd06d6  mov r11, [r13+r14*1]
000079035ddd06db  mov [r15+0xC0], r12
000079035ddd06e2  mov [r15+0xB8], r11
000079035ddd06e9  lea r14, [rax+0x110]
000079035ddd06f0  mov r12, [r13+r14*1]
000079035ddd06f5  lea r14, [rax+0x118]
000079035ddd06fc  mov r11, [r13+r14*1]
000079035ddd0701  mov [r15+0xD0], r12
000079035ddd0708  mov [r15+0xC8], r11
000079035ddd070f  lea r14, [rax+0x100]
000079035ddd0716  mov r12, [r13+r14*1]
000079035ddd071b  lea r14, [rax+0x108]
000079035ddd0722  mov r11, [r13+r14*1]
000079035ddd0727  mov [r15+0xE8], r12
000079035ddd072e  mov [r15+0xD8], r11
000079035ddd0735  lea r14, [rax+0x150]
000079035ddd073c  mov [r15+0xF8], r14
000079035ddd0743  mov rax, [r15+0xF0]
000079035ddd074a  mov [r15+0x100], rax
000079035ddd0751  jmp 0x000079035DDCE5C0
000079035ddd0756  int3
000079035ddd0757  call 0x000079035DCE27E0
000079035ddd075c  jmp 0x000079035DDD0683
000079035ddd0761  call 0x000079035DCE1570
000079035ddd0766  jmp 0x000079035DDD068F
000079035ddd076b  call 0x000079035DCE27E0
000079035ddd0770  jmp 0x000079035DDD06A9
000079035ddd0775  call 0x000079035DCE1570
000079035ddd077a  jmp 0x000079035DDD06B5
000079035ddd077f  call 0x000079035DCE27E0
000079035ddd0784  jmp 0x000079035DDD06CF
000079035ddd0789  call 0x000079035DCE1570
000079035ddd078e  jmp 0x000079035DDD06DB
000079035ddd0793  call 0x000079035DCE27E0
000079035ddd0798  jmp 0x000079035DDD06F5
000079035ddd079d  call 0x000079035DCE1570
000079035ddd07a2  jmp 0x000079035DDD0701
000079035ddd07a7  call 0x000079035DCE27E0
000079035ddd07ac  jmp 0x000079035DDD071B
000079035ddd07b1  call 0x000079035DCE1570
000079035ddd07b6  jmp 0x000079035DDD0727
000079035ddd07bb  int3
000079035ddd07bc  nop [rax], eax
000079035ddd07c0  mov eax, [r15+0xA0]
000079035ddd07c7  mov [rsp+0x10], eax
000079035ddd07cb  xor eax, eax
000079035ddd07cd  mov r14d, [rsp+0x10]
000079035ddd07d2  sub r14d, 0x01
000079035ddd07d6  cmc
000079035ddd07d7  lahf
000079035ddd07d8  seto al
000079035ddd07db  mov [r15+0x108], eax
000079035ddd07e2  mov r14d, r14d
000079035ddd07e5  mov [r15+0xA0], r14
000079035ddd07ec  mov eax, [r15+0x108]
000079035ddd07f3  sahf
000079035ddd07f4  jnz 0x000079035DDD0826
000079035ddd07f6  cmp dword ptr [r15+0x318], 0x00
000079035ddd07fe  jz 0x000079035DDD0900
000079035ddd0804  nop [rax+rax*1], ax
000079035ddd080d  nop [rax+rax*1], eax
000079035ddd0815  mov eax, 0x41028C
000079035ddd081a  mov [r15+0x100], rax
000079035ddd0821  jmp 0x000079035DBFE110
000079035ddd0826  cmp dword ptr [r15+0x318], 0x00
000079035ddd082e  jz 0x000079035DDD0860
000079035ddd0834  nop [rax+rax*1], ax
000079035ddd083d  nop [rax+rax*1], eax
000079035ddd0845  mov eax, 0x410274
000079035ddd084a  mov [r15+0x100], rax
000079035ddd0851  jmp 0x000079035DBFE110
000079035ddd0856  int3
000079035ddd0857  int3
000079035ddd0858  nop [rax+rax*1], eax
000079035ddd0860  mov rax, [r15+0xF8]
000079035ddd0867  lea r14, [rax+0x100]
000079035ddd086e  mov [r15], r14
000079035ddd0871  mov rax, [r15+0x98]
000079035ddd0878  mov [r15+0x08], rax
000079035ddd087c  mov qword ptr [r15+0x10], 0x12C
000079035ddd0884  mov qword ptr [r15+0xF0], 0x410284
000079035ddd088f  mov r14d, [r15+0x320]
000079035ddd0896  mov eax, 0x410284
000079035ddd089b  mov rcx, 0x79035DDD07C0
000079035ddd08a5  mov [r15+r14*8+0x328], rax
000079035ddd08ad  mov [r15+r14*8+0x368], rcx
000079035ddd08b5  add r14d, 0x01
000079035ddd08b9  and r14d, 0x07
000079035ddd08bd  mov [r15+0x320], r14d
000079035ddd08c4  cmp dword ptr [r15+0x318], 0x00
000079035ddd08cc  jz 0x000079035DDCED70
000079035ddd08d2  nop [rax+rax*1], ax
000079035ddd08db  nop [rax+rax*1], eax
000079035ddd08e3  mov eax, 0x410728
000079035ddd08e8  mov [r15+0x100], rax
000079035ddd08ef  jmp 0x000079035DBFE110
000079035ddd08f4  int3
000079035ddd08f5  int3
000079035ddd08f6  nop [rax+rax*1], ax
000079035ddd08ff  nop
000079035ddd0900  mov rax, [r15+0xF8]
000079035ddd0907  lea r14, [rax+0x120]
000079035ddd090e  mov r12, [r13+r14*1]
000079035ddd0913  mov [r15+0x98], r12
000079035ddd091a  mov qword ptr [r15+0x40], 0x80
000079035ddd0922  lea r14, [rax+0x100]
000079035ddd0929  mov [r15], r14
000079035ddd092c  lea r14, [rax+0x17C]
000079035ddd0933  mov [r15+0x08], r14
000079035ddd0937  mov qword ptr [r15+0x10], 0x01
000079035ddd093f  lea r14, [rax+0x17C]
000079035ddd0946  mov eax, 0x80
000079035ddd094b  mov [r13+r14*1], al
000079035ddd0950  mov qword ptr [r15+0xF0], 0x4102A8
000079035ddd095b  mov r14d, [r15+0x320]
000079035ddd0962  mov eax, 0x4102A8
000079035ddd0967  mov rcx, 0x79035DDD09E0
000079035ddd0971  mov [r15+r14*8+0x328], rax
000079035ddd0979  mov [r15+r14*8+0x368], rcx
000079035ddd0981  add r14d, 0x01
000079035ddd0985  and r14d, 0x07
000079035ddd0989  mov [r15+0x320], r14d
000079035ddd0990  cmp dword ptr [r15+0x318], 0x00
000079035ddd0998  jz 0x000079035DDCED70
000079035ddd099e  nop [rax+rax*1], ax
000079035ddd09a7  nop [rax+rax*1], eax
000079035ddd09af  mov eax, 0x410728
000079035ddd09b4  mov [r15+0x100], rax
000079035ddd09bb  jmp 0x000079035DBFE110
000079035ddd09c0  int3
000079035ddd09c1  call 0x000079035DCE27E0
000079035ddd09c6  jmp 0x000079035DDD0913
000079035ddd09cb  call 0x000079035DCD5AF0
000079035ddd09d0  jmp 0x000079035DDD0950
000079035ddd09d5  int3
000079035ddd09d6  nop [rax+rax*1], ax
000079035ddd09df  nop
000079035ddd09e0  mov rax, [r15+0xF8]
000079035ddd09e7  lea r14, [rax+0x168]
000079035ddd09ee  mov r12, [r13+r14*1]
000079035ddd09f3  mov [r15+0x40], r12
000079035ddd09f7  lea r14, [rax+0x178]
000079035ddd09fe  xor eax, eax
000079035ddd0a00  mov [r13+r14*1], al
000079035ddd0a05  xor eax, eax
000079035ddd0a07  mov r14d, 0x38
000079035ddd0a0d  cmp r12, r14
000079035ddd0a10  cmc
000079035ddd0a11  lahf
000079035ddd0a12  seto al
000079035ddd0a15  mov [r15+0x108], eax
000079035ddd0a1c  mov eax, [r15+0x108]
000079035ddd0a23  sahf
000079035ddd0a24  jz 0x000079035DDD0A56
000079035ddd0a26  cmp dword ptr [r15+0x318], 0x00
000079035ddd0a2e  jz 0x000079035DDD0AA0
000079035ddd0a34  nop [rax+rax*1], ax
000079035ddd0a3d  nop [rax+rax*1], eax
000079035ddd0a45  mov eax, 0x4102B8
000079035ddd0a4a  mov [r15+0x100], rax
000079035ddd0a51  jmp 0x000079035DBFE110
000079035ddd0a56  cmp dword ptr [r15+0x318], 0x00
000079035ddd0a5e  jz 0x000079035DDD0BF0
000079035ddd0a64  nop [rax+rax*1], ax
000079035ddd0a6d  nop [rax+rax*1], eax
000079035ddd0a75  mov eax, 0x4102D4
000079035ddd0a7a  mov [r15+0x100], rax
000079035ddd0a81  jmp 0x000079035DBFE110
000079035ddd0a86  int3
000079035ddd0a87  call 0x000079035DCE27E0
000079035ddd0a8c  jmp 0x000079035DDD09F3
000079035ddd0a91  call 0x000079035DCD5AF0
000079035ddd0a96  jmp 0x000079035DDD0A05
000079035ddd0a9b  int3
000079035ddd0a9c  nop [rax], eax
000079035ddd0aa0  mov rax, [r15+0xF8]
000079035ddd0aa7  lea r14, [rax+0x100]
000079035ddd0aae  mov [r15], r14
000079035ddd0ab1  lea r14, [rax+0x178]
000079035ddd0ab8  mov [r15+0x08], r14
000079035ddd0abc  mov qword ptr [r15+0x10], 0x01
000079035ddd0ac4  mov qword ptr [r15+0xF0], 0x4102C8
000079035ddd0acf  mov r14d, [r15+0x320]
000079035ddd0ad6  mov eax, 0x4102C8
000079035ddd0adb  mov rcx, 0x79035DDD0B40
000079035ddd0ae5  mov [r15+r14*8+0x328], rax
000079035ddd0aed  mov [r15+r14*8+0x368], rcx
000079035ddd0af5  add r14d, 0x01
000079035ddd0af9  and r14d, 0x07
000079035ddd0afd  mov [r15+0x320], r14d
000079035ddd0b04  cmp dword ptr [r15+0x318], 0x00
000079035ddd0b0c  jz 0x000079035DDCED70
000079035ddd0b12  nop [rax+rax*1], ax
000079035ddd0b1b  nop [rax+rax*1], eax
000079035ddd0b23  mov eax, 0x410728
000079035ddd0b28  mov [r15+0x100], rax
000079035ddd0b2f  jmp 0x000079035DBFE110
000079035ddd0b34  int3
000079035ddd0b35  int3
000079035ddd0b36  nop [rax+rax*1], ax
000079035ddd0b3f  nop
000079035ddd0b40  mov rax, [r15+0xF8]
000079035ddd0b47  lea r14, [rax+0x168]
000079035ddd0b4e  mov rax, [r13+r14*1]
000079035ddd0b53  mov [r15+0x40], rax
000079035ddd0b57  mov [rsp+0x10], rax
000079035ddd0b5c  xor eax, eax
000079035ddd0b5e  mov r14, [rsp+0x10]
000079035ddd0b63  mov r12d, 0x38
000079035ddd0b69  cmp r14, r12
000079035ddd0b6c  cmc
000079035ddd0b6d  lahf
000079035ddd0b6e  seto al
000079035ddd0b71  mov [r15+0x108], eax
000079035ddd0b78  mov eax, [r15+0x108]
000079035ddd0b7f  sahf
000079035ddd0b80  jnz 0x000079035DDD0BB2
000079035ddd0b82  cmp dword ptr [r15+0x318], 0x00
000079035ddd0b8a  jz 0x000079035DDD0BF0
000079035ddd0b90  nop [rax+rax*1], ax
000079035ddd0b99  nop [rax+rax*1], eax
000079035ddd0ba1  mov eax, 0x4102D4
000079035ddd0ba6  mov [r15+0x100], rax
000079035ddd0bad  jmp 0x000079035DBFE110
000079035ddd0bb2  cmp dword ptr [r15+0x318], 0x00
000079035ddd0bba  jz 0x000079035DDD0AA0
000079035ddd0bc0  nop [rax+rax*1], ax
000079035ddd0bc9  nop [rax+rax*1], eax
000079035ddd0bd1  mov eax, 0x4102B8
000079035ddd0bd6  mov [r15+0x100], rax
000079035ddd0bdd  jmp 0x000079035DBFE110
000079035ddd0be2  int3
000079035ddd0be3  call 0x000079035DCD59C0
000079035ddd0be8  jmp 0x000079035DDD0B53
000079035ddd0bed  int3
000079035ddd0bee  nop
000079035ddd0bf0  mov rax, [r15+0x98]
000079035ddd0bf7  rorx r14, rax, 0x3D
000079035ddd0bfd  and r14, 0xFFFFFFFFFFFFFFF8
000079035ddd0c01  mov rax, [r15+0xF8]
000079035ddd0c08  lea r12, [rax+0x100]
000079035ddd0c0f  mov [r15], r12
000079035ddd0c12  lea r12, [rax+0x170]
000079035ddd0c19  mov [r15+0x08], r12
000079035ddd0c1d  mov qword ptr [r15+0x10], 0x08
000079035ddd0c25  bswap r14
000079035ddd0c28  mov [r15+0x40], r14
000079035ddd0c2c  lea r12, [rax+0x170]
000079035ddd0c33  mov [r13+r12*1], r14
000079035ddd0c38  mov qword ptr [r15+0xF0], 0x4102F0
000079035ddd0c43  mov r14d, [r15+0x320]
000079035ddd0c4a  mov eax, 0x4102F0
000079035ddd0c4f  mov rcx, 0x79035DDD0CC0
000079035ddd0c59  mov [r15+r14*8+0x328], rax
000079035ddd0c61  mov [r15+r14*8+0x368], rcx
000079035ddd0c69  add r14d, 0x01
000079035ddd0c6d  and r14d, 0x07
000079035ddd0c71  mov [r15+0x320], r14d
000079035ddd0c78  cmp dword ptr [r15+0x318], 0x00
000079035ddd0c80  jz 0x000079035DDCED70
000079035ddd0c86  nop [rax+rax*1], ax
000079035ddd0c8f  nop [rax+rax*1], eax
000079035ddd0c97  mov eax, 0x410728
000079035ddd0c9c  mov [r15+0x100], rax
000079035ddd0ca3  jmp 0x000079035DBFE110
000079035ddd0ca8  int3
000079035ddd0ca9  call 0x000079035DCC3FE0
000079035ddd0cae  jmp 0x000079035DDD0C38
000079035ddd0cb3  int3
000079035ddd0cb4  nop [rax+rax*1], ax
000079035ddd0cbd  nop [rax], eax
000079035ddd0cc0  mov rax, [r15+0xF8]
000079035ddd0cc7  lea r14, [rax+0x100]
000079035ddd0cce  mov r12d, [r13+r14*1]
000079035ddd0cd3  lea r14, [rax+0x104]
000079035ddd0cda  mov r11d, [r13+r14*1]
000079035ddd0cdf  mov qword ptr [r15+0x48], 0x430C90
000079035ddd0ce7  lea r14, [rax+0x108]
000079035ddd0cee  mov r10d, [r13+r14*1]
000079035ddd0cf3  lea r14, [rax+0x10C]
000079035ddd0cfa  mov r9d, [r13+r14*1]
000079035ddd0cff  bswap r12d
000079035ddd0d02  bswap r11d
000079035ddd0d05  mov qword ptr [r15+0xA0], 0x00
000079035ddd0d10  mov r14d, 0x430C90
000079035ddd0d16  mov [r13+r14*1], r12d
000079035ddd0d1b  mov r14d, 0x430C94
000079035ddd0d21  mov [r13+r14*1], r11d
000079035ddd0d26  bswap r10d
000079035ddd0d29  lea r14, [rax+0x110]
000079035ddd0d30  mov r12d, [r13+r14*1]
000079035ddd0d35  bswap r9d
000079035ddd0d38  lea r14, [rax+0x114]
000079035ddd0d3f  mov r11d, [r13+r14*1]
000079035ddd0d44  mov qword ptr [r15+0x98], 0x430DFC
000079035ddd0d4f  mov r14d, 0x430C98
000079035ddd0d55  mov [r13+r14*1], r10d
000079035ddd0d5a  mov r14d, 0x430C9C
000079035ddd0d60  mov [r13+r14*1], r9d
000079035ddd0d65  bswap r12d
000079035ddd0d68  lea r14, [rax+0x118]
000079035ddd0d6f  mov r10d, [r13+r14*1]
000079035ddd0d74  bswap r11d
000079035ddd0d77  mov [rsp+0x10], r11d
000079035ddd0d7c  mov r11d, r11d
000079035ddd0d7f  mov [r15+0x58], r11
000079035ddd0d83  lea r14, [rax+0x11C]
000079035ddd0d8a  mov eax, [r13+r14*1]
000079035ddd0d8f  mov [rsp+0x20], eax
000079035ddd0d93  mov eax, eax
000079035ddd0d95  mov [r15+0x60], rax
000079035ddd0d99  mov eax, 0x430CA0
000079035ddd0d9e  mov [r13+rax*1], r12d
000079035ddd0da3  mov eax, 0x430CA4
000079035ddd0da8  mov r14d, [rsp+0x10]
000079035ddd0dad  mov [r13+rax*1], r14d
000079035ddd0db2  bswap r10d
000079035ddd0db5  mov [rsp+0x10], r10d
000079035ddd0dba  mov r10d, r10d
000079035ddd0dbd  mov [r15+0x40], r10
000079035ddd0dc1  mov eax, [rsp+0x20]
000079035ddd0dc5  bswap eax
000079035ddd0dc7  mov [rsp+0x20], eax
000079035ddd0dcb  mov eax, eax
000079035ddd0dcd  mov [r15+0x50], rax
000079035ddd0dd1  mov eax, 0x430CA8
000079035ddd0dd6  mov r14d, [rsp+0x10]
000079035ddd0ddb  mov [r13+rax*1], r14d
000079035ddd0de0  mov eax, 0x430CAC
000079035ddd0de5  mov r14d, [rsp+0x20]
000079035ddd0dea  mov [r13+rax*1], r14d
000079035ddd0def  mov eax, [r15+0xA0]
000079035ddd0df6  lea r14d, [eax+0x11]
000079035ddd0dfb  mov r14d, r14d
000079035ddd0dfe  mov [r15], r14
000079035ddd0e01  mov qword ptr [r15+0xF0], 0x41035C
000079035ddd0e0c  mov r14d, [r15+0x320]
000079035ddd0e13  mov eax, 0x41035C
000079035ddd0e18  mov rcx, 0x79035DDD0F90
000079035ddd0e22  mov [r15+r14*8+0x328], rax
000079035ddd0e2a  mov [r15+r14*8+0x368], rcx
000079035ddd0e32  add r14d, 0x01
000079035ddd0e36  and r14d, 0x07
000079035ddd0e3a  mov [r15+0x320], r14d
000079035ddd0e41  cmp dword ptr [r15+0x318], 0x00
000079035ddd0e49  jz 0x000079035DDD0F20
000079035ddd0e4f  nop [rax+rax*1], ax
000079035ddd0e58  nop [rax+rax*1], eax
000079035ddd0e60  mov eax, 0x4109A4
000079035ddd0e65  mov [r15+0x100], rax
000079035ddd0e6c  jmp 0x000079035DBFE110
000079035ddd0e71  int3
000079035ddd0e72  call 0x000079035DCE26A0
000079035ddd0e77  jmp 0x000079035DDD0CD3
000079035ddd0e7c  call 0x000079035DCE1430
000079035ddd0e81  jmp 0x000079035DDD0CDF
000079035ddd0e86  call 0x000079035DCE01C0
000079035ddd0e8b  jmp 0x000079035DDD0CF3
000079035ddd0e90  call 0x000079035DCDEF50
000079035ddd0e95  jmp 0x000079035DDD0CFF
000079035ddd0e9a  call 0x000079035DCE2BA0
000079035ddd0e9f  jmp 0x000079035DDD0D1B
000079035ddd0ea4  call 0x000079035DCE1920
000079035ddd0ea9  jmp 0x000079035DDD0D26
000079035ddd0eae  call 0x000079035DCE26A0
000079035ddd0eb3  jmp 0x000079035DDD0D35
000079035ddd0eb8  call 0x000079035DCE1430
000079035ddd0ebd  jmp 0x000079035DDD0D44
000079035ddd0ec2  call 0x000079035DCE06B0
000079035ddd0ec7  jmp 0x000079035DDD0D5A
000079035ddd0ecc  call 0x000079035DCDF440
000079035ddd0ed1  jmp 0x000079035DDD0D65
000079035ddd0ed6  call 0x000079035DCE01C0
000079035ddd0edb  jmp 0x000079035DDD0D74
000079035ddd0ee0  call 0x000079035DCD5890
000079035ddd0ee5  jmp 0x000079035DDD0D8F
000079035ddd0eea  call 0x000079035DC0BAE0
000079035ddd0eef  jmp 0x000079035DDD0DA3
000079035ddd0ef4  call 0x000079035DC0DFE0
000079035ddd0ef9  jmp 0x000079035DDD0DB2
000079035ddd0efe  call 0x000079035DC0DFE0
000079035ddd0f03  jmp 0x000079035DDD0DE0
000079035ddd0f08  call 0x000079035DC0DFE0
000079035ddd0f0d  jmp 0x000079035DDD0DEF
000079035ddd0f12  int3
000079035ddd0f13  nop [rax+rax*1], ax
000079035ddd0f1c  nop [rax], eax
000079035ddd0f20  mov eax, [r15]
000079035ddd0f23  mov [rsp+0x10], eax
000079035ddd0f27  shr eax, 0x10
000079035ddd0f2a  mov r14d, [rsp+0x10]
000079035ddd0f2f  xor r14d, eax
000079035ddd0f32  imul r14d, r14d, 0x7FEB352D
000079035ddd0f39  mov eax, 0x846CA68B
000079035ddd0f3e  mov eax, eax
000079035ddd0f40  mov [r15+0x48], rax
000079035ddd0f44  mov [rsp+0x10], r14d
000079035ddd0f49  shr r14d, 0x0F
000079035ddd0f4d  mov eax, [rsp+0x10]
000079035ddd0f51  xor eax, r14d
000079035ddd0f54  imul eax, eax, 0x846CA68B
000079035ddd0f5a  mov [rsp+0x10], eax
000079035ddd0f5e  mov eax, eax
000079035ddd0f60  mov [r15+0x40], rax
000079035ddd0f64  mov eax, [rsp+0x10]
000079035ddd0f68  shr eax, 0x10
000079035ddd0f6b  mov r14d, [rsp+0x10]
000079035ddd0f70  xor r14d, eax
000079035ddd0f73  mov r14d, r14d
000079035ddd0f76  mov [r15], r14
000079035ddd0f79  mov rax, [r15+0xF0]
000079035ddd0f80  mov [r15+0x100], rax
000079035ddd0f87  jmp 0x000079035DDCE5C0
000079035ddd0f8c  int3
000079035ddd0f8d  int3
000079035ddd0f8e  nop
000079035ddd0f90  mov rax, [r15+0xA0]
000079035ddd0f97  mov [rsp+0x10], rax
000079035ddd0f9c  shl rax, 0x02
000079035ddd0fa0  mov r14, [r15+0x98]
000079035ddd0fa7  lea r12, [r14+rax*1]
000079035ddd0fab  mov eax, [r15]
000079035ddd0fae  mov [r13+r12*1], eax
000079035ddd0fb3  mov rax, [rsp+0x10]
000079035ddd0fb8  lea r14, [rax+0x01]
000079035ddd0fbc  mov [r15+0xA0], r14
000079035ddd0fc3  xor eax, eax
000079035ddd0fc5  mov r12d, 0x400
000079035ddd0fcb  cmp r14, r12
000079035ddd0fce  cmc
000079035ddd0fcf  lahf
000079035ddd0fd0  seto al
000079035ddd0fd3  mov [r15+0x108], eax
000079035ddd0fda  mov eax, [r15+0x108]
000079035ddd0fe1  sahf
000079035ddd0fe2  jnz 0x000079035DDD1014
000079035ddd0fe4  cmp dword ptr [r15+0x318], 0x00
000079035ddd0fec  jz 0x000079035DDD10E0
000079035ddd0ff2  nop [rax+rax*1], ax
000079035ddd0ffb  nop [rax+rax*1], eax
000079035ddd1003  mov eax, 0x41036C
000079035ddd1008  mov [r15+0x100], rax
000079035ddd100f  jmp 0x000079035DBFE110
000079035ddd1014  cmp dword ptr [r15+0x318], 0x00
000079035ddd101c  jz 0x000079035DDD1050
000079035ddd1022  nop [rax+rax*1], ax
000079035ddd102b  nop [rax+rax*1], eax
000079035ddd1033  mov eax, 0x410354
000079035ddd1038  mov [r15+0x100], rax
000079035ddd103f  jmp 0x000079035DBFE110
000079035ddd1044  int3
000079035ddd1045  call 0x000079035DCB4B70
000079035ddd104a  jmp 0x000079035DDD0FB3
000079035ddd104f  int3
000079035ddd1050  mov eax, [r15+0xA0]
000079035ddd1057  lea r14d, [eax+0x11]
000079035ddd105c  mov r14d, r14d
000079035ddd105f  mov [r15], r14
000079035ddd1062  mov qword ptr [r15+0xF0], 0x41035C
000079035ddd106d  mov r14d, [r15+0x320]
000079035ddd1074  mov eax, 0x41035C
000079035ddd1079  mov rcx, 0x79035DDD0F90
000079035ddd1083  mov [r15+r14*8+0x328], rax
000079035ddd108b  mov [r15+r14*8+0x368], rcx
000079035ddd1093  add r14d, 0x01
000079035ddd1097  and r14d, 0x07
000079035ddd109b  mov [r15+0x320], r14d
000079035ddd10a2  cmp dword ptr [r15+0x318], 0x00
000079035ddd10aa  jz 0x000079035DDD0F20
000079035ddd10b0  nop [rax+rax*1], ax
000079035ddd10b9  nop [rax+rax*1], eax
000079035ddd10c1  mov eax, 0x4109A4
000079035ddd10c6  mov [r15+0x100], rax
000079035ddd10cd  jmp 0x000079035DBFE110
000079035ddd10d2  int3
000079035ddd10d3  int3
000079035ddd10d4  nop [rax+rax*1], ax
000079035ddd10dd  nop [rax], eax
000079035ddd10e0  mov qword ptr [r15+0x40], 0x01
000079035ddd10e8  cmp dword ptr [r15+0x318], 0x00
000079035ddd10f0  jz 0x000079035DDD1120
000079035ddd10f6  nop [rax+rax*1], ax
000079035ddd10ff  nop [rax+rax*1], eax
000079035ddd1107  mov eax, 0x410388
000079035ddd110c  mov [r15+0x100], rax
000079035ddd1113  jmp 0x000079035DBFE110
000079035ddd1118  int3
000079035ddd1119  int3
000079035ddd111a  nop [rax+rax*1], ax
000079035ddd1120  mov rax, [r15+0x40]
000079035ddd1124  mov [rsp+0x10], rax
000079035ddd1129  shl rax, 0x02
000079035ddd112d  mov r14, [r15+0x98]
000079035ddd1134  lea r12, [r14+rax*1]
000079035ddd1138  mov eax, [r13+r12*1]
000079035ddd113d  mov [rsp+0x20], eax
000079035ddd1141  mov eax, eax
000079035ddd1143  mov [r15+0x48], rax
000079035ddd1147  mov rax, [rsp+0x10]
000079035ddd114c  mov [r15+0x50], rax
000079035ddd1150  mov eax, [r15+0x50]
000079035ddd1154  lea r12d, [eax-0x01]
000079035ddd1159  mov r12d, r12d
000079035ddd115c  mov [r15+0x58], r12
000079035ddd1160  mov rax, [r15+0x58]
000079035ddd1164  mov r12d, eax
000079035ddd1167  mov r12d, r12d
000079035ddd116a  shl r12, 0x02
000079035ddd116e  lea rax, [r14+r12*1]
000079035ddd1172  mov r14d, [r13+rax*1]
000079035ddd1177  mov [rsp+0x10], r14d
000079035ddd117c  mov r14d, r14d
000079035ddd117f  mov [r15+0x60], r14
000079035ddd1183  xor eax, eax
000079035ddd1185  mov r14d, [rsp+0x10]
000079035ddd118a  mov r12d, [rsp+0x20]
000079035ddd118f  cmp r14d, r12d
000079035ddd1192  cmc
000079035ddd1193  lahf
000079035ddd1194  seto al
000079035ddd1197  mov [r15+0x108], eax
000079035ddd119e  mov eax, [r15+0x108]
000079035ddd11a5  sahf
000079035ddd11a6  cmc
000079035ddd11a7  jbe 0x000079035DDD11D9
000079035ddd11a9  cmp dword ptr [r15+0x318], 0x00
000079035ddd11b1  jz 0x000079035DDD1220
000079035ddd11b7  nop [rax+rax*1], ax
000079035ddd11c0  nop [rax+rax*1], eax
000079035ddd11c8  mov eax, 0x4103A0
000079035ddd11cd  mov [r15+0x100], rax
000079035ddd11d4  jmp 0x000079035DBFE110
000079035ddd11d9  cmp dword ptr [r15+0x318], 0x00
000079035ddd11e1  jz 0x000079035DDD14C0
000079035ddd11e7  nop [rax+rax*1], ax
000079035ddd11f0  nop [rax+rax*1], eax
000079035ddd11f8  mov eax, 0x410378
000079035ddd11fd  mov [r15+0x100], rax
000079035ddd1204  jmp 0x000079035DBFE110
000079035ddd1209  int3
000079035ddd120a  call 0x000079035DCB4690
000079035ddd120f  jmp 0x000079035DDD113D
000079035ddd1214  call 0x000079035DC0DAE0
000079035ddd1219  jmp 0x000079035DDD1177
000079035ddd121e  int3
000079035ddd121f  nop
000079035ddd1220  mov rax, [r15+0x50]
000079035ddd1224  mov [rsp+0x10], rax
000079035ddd1229  shl rax, 0x02
000079035ddd122d  mov r14, [r15+0x98]
000079035ddd1234  lea r12, [r14+rax*1]
000079035ddd1238  mov eax, [r15+0x60]
000079035ddd123c  mov [r13+r12*1], eax
000079035ddd1241  mov rax, [rsp+0x10]
000079035ddd1246  lea r14, [rax-0x01]
000079035ddd124a  mov [r15+0x50], r14
000079035ddd124e  mov rax, [r15+0x58]
000079035ddd1252  test rax, rax
000079035ddd1255  setz al
000079035ddd1258  movzx rax, al
000079035ddd125c  mov [rsp+0x414], al
000079035ddd1263  cmp byte ptr [rsp+0x414], 0x00
000079035ddd126b  jz 0x000079035DDD129D
000079035ddd126d  cmp dword ptr [r15+0x318], 0x00
000079035ddd1275  jz 0x000079035DDD12E0
000079035ddd127b  nop [rax+rax*1], ax
000079035ddd1284  nop [rax+rax*1], eax
000079035ddd128c  mov eax, 0x4103AC
000079035ddd1291  mov [r15+0x100], rax
000079035ddd1298  jmp 0x000079035DBFE110
000079035ddd129d  cmp dword ptr [r15+0x318], 0x00
000079035ddd12a5  jz 0x000079035DDD13E0
000079035ddd12ab  nop [rax+rax*1], ax
000079035ddd12b4  nop [rax+rax*1], eax
000079035ddd12bc  mov eax, 0x410390
000079035ddd12c1  mov [r15+0x100], rax
000079035ddd12c8  jmp 0x000079035DBFE110
000079035ddd12cd  int3
000079035ddd12ce  call 0x000079035DCB4B70
000079035ddd12d3  jmp 0x000079035DDD1241
000079035ddd12d8  int3
000079035ddd12d9  nop [rax], eax
000079035ddd12e0  cmp dword ptr [r15+0x318], 0x00
000079035ddd12e8  jz 0x000079035DDD1320
000079035ddd12ee  nop [rax+rax*1], ax
000079035ddd12f7  nop [rax+rax*1], eax
000079035ddd12ff  mov eax, 0x410374
000079035ddd1304  mov [r15+0x100], rax
000079035ddd130b  jmp 0x000079035DBFE110
000079035ddd1310  int3
000079035ddd1311  int3
000079035ddd1312  nop [rax+rax*1], ax
000079035ddd131b  nop [rax+rax*1], eax
000079035ddd1320  mov qword ptr [r15+0x50], 0x00
000079035ddd1328  mov rax, [r15+0x40]
000079035ddd132c  lea r14, [rax+0x01]
000079035ddd1330  mov [r15+0x40], r14
000079035ddd1334  mov rax, [r15+0x98]
000079035ddd133b  mov r12d, [r15+0x48]
000079035ddd133f  mov [r13+rax*1], r12d
000079035ddd1344  xor eax, eax
000079035ddd1346  mov r12d, 0x400
000079035ddd134c  cmp r14, r12
000079035ddd134f  cmc
000079035ddd1350  lahf
000079035ddd1351  seto al
000079035ddd1354  mov [r15+0x108], eax
000079035ddd135b  mov eax, [r15+0x108]
000079035ddd1362  sahf
000079035ddd1363  jz 0x000079035DDD1395
000079035ddd1365  cmp dword ptr [r15+0x318], 0x00
000079035ddd136d  jz 0x000079035DDD1120
000079035ddd1373  nop [rax+rax*1], ax
000079035ddd137c  nop [rax+rax*1], eax
000079035ddd1384  mov eax, 0x410388
000079035ddd1389  mov [r15+0x100], rax
000079035ddd1390  jmp 0x000079035DBFE110
000079035ddd1395  cmp dword ptr [r15+0x318], 0x00
000079035ddd139d  jz 0x000079035DDD1580
000079035ddd13a3  nop [rax+rax*1], ax
000079035ddd13ac  nop [rax+rax*1], eax
000079035ddd13b4  mov eax, 0x4103B0
000079035ddd13b9  mov [r15+0x100], rax
000079035ddd13c0  jmp 0x000079035DBFE110
000079035ddd13c5  int3
000079035ddd13c6  call 0x000079035DC0BAE0
000079035ddd13cb  jmp 0x000079035DDD1344
000079035ddd13d0  int3
000079035ddd13d1  nop [rax+rax*1], ax
000079035ddd13da  nop [rax+rax*1], ax
000079035ddd13e0  mov eax, [r15+0x50]
000079035ddd13e4  lea r14d, [eax-0x01]
000079035ddd13e9  mov r14d, r14d
000079035ddd13ec  mov [r15+0x58], r14
000079035ddd13f0  mov rax, [r15+0x58]
000079035ddd13f4  mov r14d, eax
000079035ddd13f7  mov r14d, r14d
000079035ddd13fa  shl r14, 0x02
000079035ddd13fe  mov rax, [r15+0x98]
000079035ddd1405  lea r12, [rax+r14*1]
000079035ddd1409  mov eax, [r13+r12*1]
000079035ddd140e  mov [rsp+0x10], eax
000079035ddd1412  mov eax, eax
000079035ddd1414  mov [r15+0x60], rax
000079035ddd1418  mov eax, [r15+0x48]
000079035ddd141c  mov [rsp+0x20], eax
000079035ddd1420  xor eax, eax
000079035ddd1422  mov r14d, [rsp+0x10]
000079035ddd1427  mov r12d, [rsp+0x20]
000079035ddd142c  cmp r14d, r12d
000079035ddd142f  cmc
000079035ddd1430  lahf
000079035ddd1431  seto al
000079035ddd1434  mov [r15+0x108], eax
000079035ddd143b  mov eax, [r15+0x108]
000079035ddd1442  sahf
000079035ddd1443  cmc
000079035ddd1444  jbe 0x000079035DDD1476
000079035ddd1446  cmp dword ptr [r15+0x318], 0x00
000079035ddd144e  jz 0x000079035DDD1220
000079035ddd1454  nop [rax+rax*1], ax
000079035ddd145d  nop [rax+rax*1], eax
000079035ddd1465  mov eax, 0x4103A0
000079035ddd146a  mov [r15+0x100], rax
000079035ddd1471  jmp 0x000079035DBFE110
000079035ddd1476  cmp dword ptr [r15+0x318], 0x00
000079035ddd147e  jz 0x000079035DDD14C0
000079035ddd1484  nop [rax+rax*1], ax
000079035ddd148d  nop [rax+rax*1], eax
000079035ddd1495  mov eax, 0x410378
000079035ddd149a  mov [r15+0x100], rax
000079035ddd14a1  jmp 0x000079035DBFE110
000079035ddd14a6  int3
000079035ddd14a7  call 0x000079035DCB4690
000079035ddd14ac  jmp 0x000079035DDD140E
000079035ddd14b1  int3
000079035ddd14b2  nop [rax+rax*1], ax
000079035ddd14bb  nop [rax+rax*1], eax
000079035ddd14c0  mov rax, [r15+0x40]
000079035ddd14c4  lea r14, [rax+0x01]
000079035ddd14c8  mov [r15+0x40], r14
000079035ddd14cc  mov rax, [r15+0x50]
000079035ddd14d0  mov r12d, eax
000079035ddd14d3  mov r12d, r12d
000079035ddd14d6  shl r12, 0x02
000079035ddd14da  mov rax, [r15+0x98]
000079035ddd14e1  lea r11, [rax+r12*1]
000079035ddd14e5  mov eax, [r15+0x48]
000079035ddd14e9  mov [r13+r11*1], eax
000079035ddd14ee  xor eax, eax
000079035ddd14f0  mov r12d, 0x400
000079035ddd14f6  cmp r14, r12
000079035ddd14f9  cmc
000079035ddd14fa  lahf
000079035ddd14fb  seto al
000079035ddd14fe  mov [r15+0x108], eax
000079035ddd1505  mov eax, [r15+0x108]
000079035ddd150c  sahf
000079035ddd150d  jz 0x000079035DDD153F
000079035ddd150f  cmp dword ptr [r15+0x318], 0x00
000079035ddd1517  jz 0x000079035DDD1120
000079035ddd151d  nop [rax+rax*1], ax
000079035ddd1526  nop [rax+rax*1], eax
000079035ddd152e  mov eax, 0x410388
000079035ddd1533  mov [r15+0x100], rax
000079035ddd153a  jmp 0x000079035DBFE110
000079035ddd153f  cmp dword ptr [r15+0x318], 0x00
000079035ddd1547  jz 0x000079035DDD1580
000079035ddd154d  nop [rax+rax*1], ax
000079035ddd1556  nop [rax+rax*1], eax
000079035ddd155e  mov eax, 0x4103B0
000079035ddd1563  mov [r15+0x100], rax
000079035ddd156a  jmp 0x000079035DBFE110
000079035ddd156f  int3
000079035ddd1570  call 0x000079035DCA4270
000079035ddd1575  jmp 0x000079035DDD14EE
000079035ddd157a  int3
000079035ddd157b  nop [rax+rax*1], eax
000079035ddd1580  mov qword ptr [r15+0x40], 0x430000
000079035ddd1588  mov eax, 0x430CB0
000079035ddd158d  mov r14, [r13+rax*1]
000079035ddd1592  mov rax, [r15+0x98]
000079035ddd1599  mov r12d, [r13+rax*1]
000079035ddd159e  lea r11, [rax+0x04]
000079035ddd15a2  mov eax, [r13+r11*1]
000079035ddd15a7  mov r12d, r12d
000079035ddd15aa  mov [r15+0x68], r12
000079035ddd15ae  mov eax, eax
000079035ddd15b0  mov [r15+0x60], rax
000079035ddd15b4  mov rax, [r15+0x68]
000079035ddd15b8  mov [r15+0x68], rax
000079035ddd15bc  mov qword ptr [r15+0x58], 0x02
000079035ddd15c4  mov [rsp+0x10], rax
000079035ddd15c9  xor eax, eax
000079035ddd15cb  mov r12d, 0x02
000079035ddd15d1  mov r11d, 0x400
000079035ddd15d7  cmp r12, r11
000079035ddd15da  cmc
000079035ddd15db  lahf
000079035ddd15dc  seto al
000079035ddd15df  mov [r15+0x108], eax
000079035ddd15e6  mov rax, [r15+0x60]
000079035ddd15ea  mov r12d, 0x02
000079035ddd15f0  imul rax, r12
000079035ddd15f4  mov [r15+0x50], rax
000079035ddd15f8  mov rax, [rsp+0x10]
000079035ddd15fd  lea r12, [rax+r14*1]
000079035ddd1601  mov [r15+0x48], r12
000079035ddd1605  mov eax, [r15+0x108]
000079035ddd160c  sahf
000079035ddd160d  jnz 0x000079035DDD163F
000079035ddd160f  cmp dword ptr [r15+0x318], 0x00
000079035ddd1617  jz 0x000079035DDD17B0
000079035ddd161d  nop [rax+rax*1], ax
000079035ddd1626  nop [rax+rax*1], eax
000079035ddd162e  mov eax, 0x4103E0
000079035ddd1633  mov [r15+0x100], rax
000079035ddd163a  jmp 0x000079035DBFE110
000079035ddd163f  cmp dword ptr [r15+0x318], 0x00
000079035ddd1647  jz 0x000079035DDD1690
000079035ddd164d  nop [rax+rax*1], ax
000079035ddd1656  nop [rax+rax*1], eax
000079035ddd165e  mov eax, 0x4103C0
000079035ddd1663  mov [r15+0x100], rax
000079035ddd166a  jmp 0x000079035DBFE110
000079035ddd166f  int3
000079035ddd1670  call 0x000079035DC0DC20
000079035ddd1675  jmp 0x000079035DDD1592
000079035ddd167a  call 0x000079035DC0B5E0
000079035ddd167f  jmp 0x000079035DDD159E
000079035ddd1684  call 0x000079035DCA3D90
000079035ddd1689  jmp 0x000079035DDD15A7
000079035ddd168e  int3
000079035ddd168f  nop
000079035ddd1690  mov rax, [r15+0x98]
000079035ddd1697  mov r14, [r15+0x58]
000079035ddd169b  mov [rsp+0x10], r14
000079035ddd16a0  shl r14, 0x02
000079035ddd16a4  lea r12, [rax+r14*1]
000079035ddd16a8  mov eax, [r13+r12*1]
000079035ddd16ad  lea r14, [r12+0x04]
000079035ddd16b2  mov r12d, [r13+r14*1]
000079035ddd16b7  mov eax, eax
000079035ddd16b9  mov [r15+0x68], rax
000079035ddd16bd  mov r12d, r12d
000079035ddd16c0  mov [r15+0x60], r12
000079035ddd16c4  mov rax, [r15+0x68]
000079035ddd16c8  mov [rsp+0x20], rax
000079035ddd16cd  mov r14, [rsp+0x10]
000079035ddd16d2  imul rax, r14
000079035ddd16d6  mov r12, [rsp+0x20]
000079035ddd16db  lea r11, [r12+rax*1]
000079035ddd16df  mov [r15+0x68], r11
000079035ddd16e3  lea rax, [r14+0x02]
000079035ddd16e7  mov [r15+0x58], rax
000079035ddd16eb  mov [rsp+0x10], rax
000079035ddd16f0  xor eax, eax
000079035ddd16f2  mov r14, [rsp+0x10]
000079035ddd16f7  mov r12d, 0x400
000079035ddd16fd  cmp r14, r12
000079035ddd1700  cmc
000079035ddd1701  lahf
000079035ddd1702  seto al
000079035ddd1705  mov [r15+0x108], eax
000079035ddd170c  mov rax, [r15+0x50]
000079035ddd1710  mov r12, [r15+0x60]
000079035ddd1714  imul r14, r12
000079035ddd1718  lea r12, [rax+r14*1]
000079035ddd171c  mov [r15+0x50], r12
000079035ddd1720  mov rax, [r15+0x48]
000079035ddd1724  lea r14, [r11+rax*1]
000079035ddd1728  mov [r15+0x48], r14
000079035ddd172c  mov eax, [r15+0x108]
000079035ddd1733  sahf
000079035ddd1734  jnz 0x000079035DDD1766
000079035ddd1736  cmp dword ptr [r15+0x318], 0x00
000079035ddd173e  jz 0x000079035DDD17B0
000079035ddd1744  nop [rax+rax*1], ax
000079035ddd174d  nop [rax+rax*1], eax
000079035ddd1755  mov eax, 0x4103E0
000079035ddd175a  mov [r15+0x100], rax
000079035ddd1761  jmp 0x000079035DBFE110
000079035ddd1766  cmp dword ptr [r15+0x318], 0x00
000079035ddd176e  jz 0x000079035DDD1690
000079035ddd1774  nop [rax+rax*1], ax
000079035ddd177d  nop [rax+rax*1], eax
000079035ddd1785  mov eax, 0x4103C0
000079035ddd178a  mov [r15+0x100], rax
000079035ddd1791  jmp 0x000079035DBFE110
000079035ddd1796  int3
000079035ddd1797  call 0x000079035DCB4690
000079035ddd179c  jmp 0x000079035DDD16AD
000079035ddd17a1  call 0x000079035DCE26A0
000079035ddd17a6  jmp 0x000079035DDD16B7
000079035ddd17ab  int3
000079035ddd17ac  nop [rax], eax
000079035ddd17b0  mov qword ptr [r15+0x98], 0x00
000079035ddd17bb  mov rax, [r15+0x50]
000079035ddd17bf  mov r14, [r15+0x48]
000079035ddd17c3  lea r12, [rax+r14*1]
000079035ddd17c7  mov [r15+0x48], r12
000079035ddd17cb  mov rax, [r15+0x40]
000079035ddd17cf  lea r14, [rax+0xCB0]
000079035ddd17d6  mov [r13+r14*1], r12
000079035ddd17db  mov qword ptr [r15], 0x01
000079035ddd17e2  mov qword ptr [r15+0xF0], 0x4103F8
000079035ddd17ed  mov r14d, [r15+0x320]
000079035ddd17f4  mov eax, 0x4103F8
000079035ddd17f9  mov rcx, 0x79035DDD1860
000079035ddd1803  mov [r15+r14*8+0x328], rax
000079035ddd180b  mov [r15+r14*8+0x368], rcx
000079035ddd1813  add r14d, 0x01
000079035ddd1817  and r14d, 0x07
000079035ddd181b  mov [r15+0x320], r14d
000079035ddd1822  cmp dword ptr [r15+0x318], 0x00
000079035ddd182a  jz 0x000079035DDD0F20
000079035ddd1830  nop [rax+rax*1], ax
000079035ddd1839  nop [rax+rax*1], eax
000079035ddd1841  mov eax, 0x4109A4
000079035ddd1846  mov [r15+0x100], rax
000079035ddd184d  jmp 0x000079035DBFE110
000079035ddd1852  int3
000079035ddd1853  call 0x000079035DCE2CE0
000079035ddd1858  jmp 0x000079035DDD17DB
000079035ddd185d  int3
000079035ddd185e  nop
000079035ddd1860  mov eax, [r15+0x98]
000079035ddd1867  lea r14d, [eax+0x01]
000079035ddd186c  mov [rsp+0x10], r14d
000079035ddd1871  mov r14d, r14d
000079035ddd1874  mov [r15+0x98], r14
000079035ddd187b  xor eax, eax
000079035ddd187d  mov r14d, [rsp+0x10]
000079035ddd1882  cmp r14d, 0x10000
000079035ddd1889  cmc
000079035ddd188a  lahf
000079035ddd188b  seto al
000079035ddd188e  mov [r15+0x108], eax
000079035ddd1895  mov eax, [r15+0x108]
000079035ddd189c  sahf
000079035ddd189d  jnz 0x000079035DDD18CF
000079035ddd189f  cmp dword ptr [r15+0x318], 0x00
000079035ddd18a7  jz 0x000079035DDD19A0
000079035ddd18ad  nop [rax+rax*1], ax
000079035ddd18b6  nop [rax+rax*1], eax
000079035ddd18be  mov eax, 0x410404
000079035ddd18c3  mov [r15+0x100], rax
000079035ddd18ca  jmp 0x000079035DBFE110
000079035ddd18cf  cmp dword ptr [r15+0x318], 0x00
000079035ddd18d7  jz 0x000079035DDD1910
000079035ddd18dd  nop [rax+rax*1], ax
000079035ddd18e6  nop [rax+rax*1], eax
000079035ddd18ee  mov eax, 0x4103F0
000079035ddd18f3  mov [r15+0x100], rax
000079035ddd18fa  jmp 0x000079035DBFE110
000079035ddd18ff  int3
000079035ddd1900  int3
000079035ddd1901  nop [rax+rax*1], ax
000079035ddd190a  nop [rax+rax*1], ax
000079035ddd1910  mov eax, [r15]
000079035ddd1913  mov r14d, [r15+0x98]
000079035ddd191a  lea r12d, [eax+r14d*1]
000079035ddd191f  mov r12d, r12d
000079035ddd1922  mov [r15], r12
000079035ddd1925  mov qword ptr [r15+0xF0], 0x4103F8
000079035ddd1930  mov r14d, [r15+0x320]
000079035ddd1937  mov eax, 0x4103F8
000079035ddd193c  mov rcx, 0x79035DDD1860
000079035ddd1946  mov [r15+r14*8+0x328], rax
000079035ddd194e  mov [r15+r14*8+0x368], rcx
000079035ddd1956  add r14d, 0x01
000079035ddd195a  and r14d, 0x07
000079035ddd195e  mov [r15+0x320], r14d
000079035ddd1965  cmp dword ptr [r15+0x318], 0x00
000079035ddd196d  jz 0x000079035DDD0F20
000079035ddd1973  nop [rax+rax*1], ax
000079035ddd197c  nop [rax+rax*1], eax
000079035ddd1984  mov eax, 0x4109A4
000079035ddd1989  mov [r15+0x100], rax
000079035ddd1990  jmp 0x000079035DBFE110
000079035ddd1995  int3
000079035ddd1996  int3
000079035ddd1997  nop [rax+rax*1], ax
000079035ddd19a0  vmovaps xmm1, [0x000079035D9FE010]
000079035ddd19a8  movq xmm1, xmm1
000079035ddd19ac  movaps [r15+0x110], xmm1
000079035ddd19b4  mov eax, 0x420B10
000079035ddd19b9  mov r14, [r13+rax*1]
000079035ddd19be  movq xmm1, r14
000079035ddd19c3  movaps [r15+0x120], xmm1
000079035ddd19cb  vmovaps xmm1, [0x000079035D9FE020]
000079035ddd19d3  movq xmm1, xmm1
000079035ddd19d7  movaps [r15+0x140], xmm1
000079035ddd19df  vmovaps xmm1, [0x000079035D9FE030]
000079035ddd19e7  vpbroadcastq xmm1, xmm1
000079035ddd19ec  movaps [r15+0x150], xmm1
000079035ddd19f4  mov qword ptr [r15+0x40], 0x02
000079035ddd19fc  vmovaps xmm15, [0x000079035D9FE040]
000079035ddd1a04  movq xmm15, xmm15
000079035ddd1a09  movaps [r15+0x160], xmm15
000079035ddd1a11  vmovaps xmm15, [0x000079035D9FE050]
000079035ddd1a19  vpbroadcastq xmm15, xmm15
000079035ddd1a1e  movaps [r15+0x130], xmm15
000079035ddd1a26  mov rax, [r15+0x40]
000079035ddd1a2a  vmovq xmm14, rax
000079035ddd1a2f  vpbroadcastq xmm14, xmm14
000079035ddd1a34  movaps [r15+0x170], xmm14
000079035ddd1a3c  mov eax, 0x420A40
000079035ddd1a41  movups xmm13, [r13+rax*1]
000079035ddd1a47  mov qword ptr [r15+0x40], 0x431E00
000079035ddd1a4f  mov eax, [r15]
000079035ddd1a52  mov r14d, 0x430CB8
000079035ddd1a58  mov [r13+r14*1], eax
000079035ddd1a5d  mov qword ptr [r15+0x50], 0x432000
000079035ddd1a65  vpmovqd xmm12, xmm13
000079035ddd1a6b  pxor xmm11, xmm11
000079035ddd1a70  punpcklqdq xmm12, xmm11
000079035ddd1a75  movaps [r15+0x210], xmm12
000079035ddd1a7d  movq xmm12, qword ptr [r15+0x140]
000079035ddd1a86  movq xmm11, qword ptr [r15+0x120]
000079035ddd1a8f  psubd xmm12, xmm11
000079035ddd1a94  movq xmm12, xmm12
000079035ddd1a99  paddq xmm13, xmm14
000079035ddd1a9e  movaps [r15+0x180], xmm13
000079035ddd1aa6  movq xmm14, qword ptr [r15+0x160]
000079035ddd1aaf  paddd xmm11, xmm14
000079035ddd1ab4  movq xmm11, xmm11
000079035ddd1ab9  movq xmm11, xmm11
000079035ddd1abe  movaps [r15+0x120], xmm11
000079035ddd1ac6  pmovzxdq xmm12, xmm12
000079035ddd1acc  psllq xmm12, 0x00
000079035ddd1ad2  movq xmm14, qword ptr [r15+0x210]
000079035ddd1adb  movq xmm13, qword ptr [r15+0x110]
000079035ddd1ae4  paddd xmm14, xmm13
000079035ddd1ae9  movq xmm14, xmm14
000079035ddd1aee  vcvtuqq2pd xmm12, xmm12
000079035ddd1af4  pmovzxdq xmm14, xmm14
000079035ddd1afa  psllq xmm14, 0x00
000079035ddd1b00  vcvtuqq2pd xmm14, xmm14
000079035ddd1b06  movaps xmm13, xmm12
000079035ddd1b0a  mulpd xmm13, xmm1
000079035ddd1b0f  vcmppd xmm11, xmm13, xmm13, 0x03
000079035ddd1b15  ptest xmm11, xmm11
000079035ddd1b1b  jnz 0x000079035DDD1C0F
000079035ddd1b21  movaps [r15+0x220], xmm13
000079035ddd1b29  mov eax, 0x432000
000079035ddd1b2e  movups [r13+rax*1], xmm13
000079035ddd1b34  movaps xmm1, xmm14
000079035ddd1b38  mulpd xmm1, xmm15
000079035ddd1b3d  vcmppd xmm13, xmm1, xmm1, 0x03
000079035ddd1b42  ptest xmm13, xmm13
000079035ddd1b48  jnz 0x000079035DDD1D5C
000079035ddd1b4e  movaps [r15+0x210], xmm1
000079035ddd1b56  mov eax, 0x431E00
000079035ddd1b5b  movups [r13+rax*1], xmm1
000079035ddd1b61  mov qword ptr [r15+0x48], 0x10
000079035ddd1b69  xor eax, eax
000079035ddd1b6b  mov r14d, 0x10
000079035ddd1b71  mov r12d, 0x200
000079035ddd1b77  cmp r14, r12
000079035ddd1b7a  cmc
000079035ddd1b7b  lahf
000079035ddd1b7c  seto al
000079035ddd1b7f  mov [r15+0x108], eax
000079035ddd1b86  mov eax, [r15+0x108]
000079035ddd1b8d  sahf
000079035ddd1b8e  jnz 0x000079035DDD1BC0
000079035ddd1b90  cmp dword ptr [r15+0x318], 0x00
000079035ddd1b98  jz 0x000079035DDD2300
000079035ddd1b9e  nop [rax+rax*1], ax
000079035ddd1ba7  nop [rax+rax*1], eax
000079035ddd1baf  mov eax, 0x410490
000079035ddd1bb4  mov [r15+0x100], rax
000079035ddd1bbb  jmp 0x000079035DBFE110
000079035ddd1bc0  cmp dword ptr [r15+0x318], 0x00
000079035ddd1bc8  jz 0x000079035DDD1EB0
000079035ddd1bce  nop [rax+rax*1], ax
000079035ddd1bd7  nop [rax+rax*1], eax
000079035ddd1bdf  mov eax, 0x410450
000079035ddd1be4  mov [r15+0x100], rax
000079035ddd1beb  jmp 0x000079035DBFE110
000079035ddd1bf0  int3
000079035ddd1bf1  call 0x000079035DC0DC20
000079035ddd1bf6  jmp 0x000079035DDD19BE
000079035ddd1bfb  call 0x000079035DC0C260
000079035ddd1c00  jmp 0x000079035DDD1A47
000079035ddd1c05  call 0x000079035DCD5D70
000079035ddd1c0a  jmp 0x000079035DDD1A5D
000079035ddd1c0f  sub rsp, 0x08
000079035ddd1c13  push rax
000079035ddd1c14  push rcx
000079035ddd1c15  push rdx
000079035ddd1c16  push rdi
000079035ddd1c17  push rsi
000079035ddd1c18  push r8
000079035ddd1c1a  push r9
000079035ddd1c1c  push r10
000079035ddd1c1e  push r11
000079035ddd1c20  sub rsp, 0xF0
000079035ddd1c27  vmovaps [rsp], xmm0
000079035ddd1c2c  vmovaps [rsp+0x10], xmm1
000079035ddd1c32  vmovaps [rsp+0x20], xmm2
000079035ddd1c38  vmovaps [rsp+0x30], xmm3
000079035ddd1c3e  vmovaps [rsp+0x40], xmm4
000079035ddd1c44  vmovaps [rsp+0x50], xmm5
000079035ddd1c4a  vmovaps [rsp+0x60], xmm6
000079035ddd1c50  vmovaps [rsp+0x70], xmm7
000079035ddd1c56  vmovaps [rsp+0x80], xmm8
000079035ddd1c5f  vmovaps [rsp+0x90], xmm9
000079035ddd1c68  vmovaps [rsp+0xA0], xmm10
000079035ddd1c71  vmovaps [rsp+0xB0], xmm11
000079035ddd1c7a  vmovaps [rsp+0xC0], xmm12
000079035ddd1c83  vmovaps [rsp+0xD0], xmm14
000079035ddd1c8c  vmovaps [rsp+0xE0], xmm15
000079035ddd1c95  sub rsp, 0x30
000079035ddd1c99  movaps [rsp], xmm13
000079035ddd1c9e  movaps [rsp+0x10], xmm12
000079035ddd1ca4  movaps [rsp+0x20], xmm1
000079035ddd1ca9  lea rdi, [rsp]
000079035ddd1cad  mov esi, 0x00
000079035ddd1cb2  mov rax, 0x64ACAA8B0530
000079035ddd1cbc  call rax
000079035ddd1cbe  movaps xmm13, [rsp]
000079035ddd1cc3  add rsp, 0x30
000079035ddd1cc7  vmovaps xmm0, [rsp]
000079035ddd1ccc  vmovaps xmm1, [rsp+0x10]
000079035ddd1cd2  vmovaps xmm2, [rsp+0x20]
000079035ddd1cd8  vmovaps xmm3, [rsp+0x30]
000079035ddd1cde  vmovaps xmm4, [rsp+0x40]
000079035ddd1ce4  vmovaps xmm5, [rsp+0x50]
000079035ddd1cea  vmovaps xmm6, [rsp+0x60]
000079035ddd1cf0  vmovaps xmm7, [rsp+0x70]
000079035ddd1cf6  vmovaps xmm8, [rsp+0x80]
000079035ddd1cff  vmovaps xmm9, [rsp+0x90]
000079035ddd1d08  vmovaps xmm10, [rsp+0xA0]
000079035ddd1d11  vmovaps xmm11, [rsp+0xB0]
000079035ddd1d1a  vmovaps xmm12, [rsp+0xC0]
000079035ddd1d23  vmovaps xmm14, [rsp+0xD0]
000079035ddd1d2c  vmovaps xmm15, [rsp+0xE0]
000079035ddd1d35  add rsp, 0xF0
000079035ddd1d3c  pop r11
000079035ddd1d3e  pop r10
000079035ddd1d40  pop r9
000079035ddd1d42  pop r8
000079035ddd1d44  pop rsi
000079035ddd1d45  pop rdi
000079035ddd1d46  pop rdx
000079035ddd1d47  pop rcx
000079035ddd1d48  pop rax
000079035ddd1d49  add rsp, 0x08
000079035ddd1d4d  jmp 0x000079035DDD1B21
000079035ddd1d52  call 0x000079035DC0C380
000079035ddd1d57  jmp 0x000079035DDD1B34
000079035ddd1d5c  sub rsp, 0x08
000079035ddd1d60  push rax
000079035ddd1d61  push rcx
000079035ddd1d62  push rdx
000079035ddd1d63  push rdi
000079035ddd1d64  push rsi
000079035ddd1d65  push r8
000079035ddd1d67  push r9
000079035ddd1d69  push r10
000079035ddd1d6b  push r11
000079035ddd1d6d  sub rsp, 0xF0
000079035ddd1d74  vmovaps [rsp], xmm0
000079035ddd1d79  vmovaps [rsp+0x10], xmm2
000079035ddd1d7f  vmovaps [rsp+0x20], xmm3
000079035ddd1d85  vmovaps [rsp+0x30], xmm4
000079035ddd1d8b  vmovaps [rsp+0x40], xmm5
000079035ddd1d91  vmovaps [rsp+0x50], xmm6
000079035ddd1d97  vmovaps [rsp+0x60], xmm7
000079035ddd1d9d  vmovaps [rsp+0x70], xmm8
000079035ddd1da3  vmovaps [rsp+0x80], xmm9
000079035ddd1dac  vmovaps [rsp+0x90], xmm10
000079035ddd1db5  vmovaps [rsp+0xA0], xmm11
000079035ddd1dbe  vmovaps [rsp+0xB0], xmm12
000079035ddd1dc7  vmovaps [rsp+0xC0], xmm13
000079035ddd1dd0  vmovaps [rsp+0xD0], xmm14
000079035ddd1dd9  vmovaps [rsp+0xE0], xmm15
000079035ddd1de2  sub rsp, 0x30
000079035ddd1de6  movaps [rsp], xmm1
000079035ddd1dea  movaps [rsp+0x10], xmm14
000079035ddd1df0  movaps [rsp+0x20], xmm15
000079035ddd1df6  lea rdi, [rsp]
000079035ddd1dfa  mov esi, 0x00
000079035ddd1dff  mov rax, 0x64ACAA8B0530
000079035ddd1e09  call rax
000079035ddd1e0b  movaps xmm1, [rsp]
000079035ddd1e0f  add rsp, 0x30
000079035ddd1e13  vmovaps xmm0, [rsp]
000079035ddd1e18  vmovaps xmm2, [rsp+0x10]
000079035ddd1e1e  vmovaps xmm3, [rsp+0x20]
000079035ddd1e24  vmovaps xmm4, [rsp+0x30]
000079035ddd1e2a  vmovaps xmm5, [rsp+0x40]
000079035ddd1e30  vmovaps xmm6, [rsp+0x50]
000079035ddd1e36  vmovaps xmm7, [rsp+0x60]
000079035ddd1e3c  vmovaps xmm8, [rsp+0x70]
000079035ddd1e42  vmovaps xmm9, [rsp+0x80]
000079035ddd1e4b  vmovaps xmm10, [rsp+0x90]
000079035ddd1e54  vmovaps xmm11, [rsp+0xA0]
000079035ddd1e5d  vmovaps xmm12, [rsp+0xB0]
000079035ddd1e66  vmovaps xmm13, [rsp+0xC0]
000079035ddd1e6f  vmovaps xmm14, [rsp+0xD0]
000079035ddd1e78  vmovaps xmm15, [rsp+0xE0]
000079035ddd1e81  add rsp, 0xF0
000079035ddd1e88  pop r11
000079035ddd1e8a  pop r10
000079035ddd1e8c  pop r9
000079035ddd1e8e  pop r8
000079035ddd1e90  pop rsi
000079035ddd1e91  pop rdi
000079035ddd1e92  pop rdx
000079035ddd1e93  pop rcx
000079035ddd1e94  pop rax
000079035ddd1e95  add rsp, 0x08
000079035ddd1e99  jmp 0x000079035DDD1B4E
000079035ddd1e9e  call 0x000079035DBFF540
000079035ddd1ea3  jmp 0x000079035DDD1B61
000079035ddd1ea8  int3
000079035ddd1ea9  nop [rax], eax
000079035ddd1eb0  movaps xmm1, [r15+0x180]
000079035ddd1eb8  vpmovqd xmm15, xmm1
000079035ddd1ebe  pxor xmm14, xmm14
000079035ddd1ec3  punpcklqdq xmm15, xmm14
000079035ddd1ec8  movaps [r15+0x210], xmm15
000079035ddd1ed0  movq xmm15, qword ptr [r15+0x140]
000079035ddd1ed9  movq xmm14, qword ptr [r15+0x120]
000079035ddd1ee2  psubd xmm15, xmm14
000079035ddd1ee7  movq xmm15, xmm15
000079035ddd1eec  movaps xmm13, [r15+0x170]
000079035ddd1ef4  paddq xmm1, xmm13
000079035ddd1ef9  movaps [r15+0x180], xmm1
000079035ddd1f01  movq xmm1, qword ptr [r15+0x160]
000079035ddd1f0a  paddd xmm14, xmm1
000079035ddd1f0f  movq xmm14, xmm14
000079035ddd1f14  movq xmm14, xmm14
000079035ddd1f19  movaps [r15+0x120], xmm14
000079035ddd1f21  pmovzxdq xmm15, xmm15
000079035ddd1f27  psllq xmm15, 0x00
000079035ddd1f2d  movq xmm1, qword ptr [r15+0x210]
000079035ddd1f36  movq xmm14, qword ptr [r15+0x110]
000079035ddd1f3f  paddd xmm1, xmm14
000079035ddd1f44  movq xmm1, xmm1
000079035ddd1f48  vcvtuqq2pd xmm15, xmm15
000079035ddd1f4e  pmovzxdq xmm1, xmm1
000079035ddd1f53  psllq xmm1, 0x00
000079035ddd1f58  vcvtuqq2pd xmm1, xmm1
000079035ddd1f5e  movaps xmm14, [r15+0x150]
000079035ddd1f66  movaps xmm13, xmm15
000079035ddd1f6a  mulpd xmm13, xmm14
000079035ddd1f6f  vcmppd xmm12, xmm13, xmm13, 0x03
000079035ddd1f75  ptest xmm12, xmm12
000079035ddd1f7b  jnz 0x000079035DDD205E
000079035ddd1f81  movaps [r15+0x220], xmm13
000079035ddd1f89  mov rax, [r15+0x48]
000079035ddd1f8d  mov r14, [r15+0x50]
000079035ddd1f91  lea r12, [r14+rax*1]
000079035ddd1f95  movups [r13+r12*1], xmm13
000079035ddd1f9b  movaps xmm15, [r15+0x130]
000079035ddd1fa3  movaps xmm14, xmm1
000079035ddd1fa7  mulpd xmm14, xmm15
000079035ddd1fac  vcmppd xmm13, xmm14, xmm14, 0x03
000079035ddd1fb2  ptest xmm13, xmm13
000079035ddd1fb8  jnz 0x000079035DDD21AC
000079035ddd1fbe  movaps [r15+0x210], xmm14
000079035ddd1fc6  mov r14, [r15+0x40]
000079035ddd1fca  lea r12, [r14+rax*1]
000079035ddd1fce  movups [r13+r12*1], xmm14
000079035ddd1fd4  lea r14, [rax+0x10]
000079035ddd1fd8  mov [r15+0x48], r14
000079035ddd1fdc  xor eax, eax
000079035ddd1fde  mov r12d, 0x200
000079035ddd1fe4  cmp r14, r12
000079035ddd1fe7  cmc
000079035ddd1fe8  lahf
000079035ddd1fe9  seto al
000079035ddd1fec  mov [r15+0x108], eax
000079035ddd1ff3  mov eax, [r15+0x108]
000079035ddd1ffa  sahf
000079035ddd1ffb  jnz 0x000079035DDD202D
000079035ddd1ffd  cmp dword ptr [r15+0x318], 0x00
000079035ddd2005  jz 0x000079035DDD2300
000079035ddd200b  nop [rax+rax*1], ax
000079035ddd2014  nop [rax+rax*1], eax
000079035ddd201c  mov eax, 0x410490
000079035ddd2021  mov [r15+0x100], rax
000079035ddd2028  jmp 0x000079035DBFE110
000079035ddd202d  cmp dword ptr [r15+0x318], 0x00
000079035ddd2035  jz 0x000079035DDD1EB0
000079035ddd203b  nop [rax+rax*1], ax
000079035ddd2044  nop [rax+rax*1], eax
000079035ddd204c  mov eax, 0x410450
000079035ddd2051  mov [r15+0x100], rax
000079035ddd2058  jmp 0x000079035DBFE110
000079035ddd205d  int3
000079035ddd205e  sub rsp, 0x08
000079035ddd2062  push rax
000079035ddd2063  push rcx
000079035ddd2064  push rdx
000079035ddd2065  push rdi
000079035ddd2066  push rsi
000079035ddd2067  push r8
000079035ddd2069  push r9
000079035ddd206b  push r10
000079035ddd206d  push r11
000079035ddd206f  sub rsp, 0xF0
000079035ddd2076  vmovaps [rsp], xmm0
000079035ddd207b  vmovaps [rsp+0x10], xmm1
000079035ddd2081  vmovaps [rsp+0x20], xmm2
000079035ddd2087  vmovaps [rsp+0x30], xmm3
000079035ddd208d  vmovaps [rsp+0x40], xmm4
000079035ddd2093  vmovaps [rsp+0x50], xmm5
000079035ddd2099  vmovaps [rsp+0x60], xmm6
000079035ddd209f  vmovaps [rsp+0x70], xmm7
000079035ddd20a5  vmovaps [rsp+0x80], xmm8
000079035ddd20ae  vmovaps [rsp+0x90], xmm9
000079035ddd20b7  vmovaps [rsp+0xA0], xmm10
000079035ddd20c0  vmovaps [rsp+0xB0], xmm11
000079035ddd20c9  vmovaps [rsp+0xC0], xmm12
000079035ddd20d2  vmovaps [rsp+0xD0], xmm14
000079035ddd20db  vmovaps [rsp+0xE0], xmm15
000079035ddd20e4  sub rsp, 0x30
000079035ddd20e8  movaps [rsp], xmm13
000079035ddd20ed  movaps [rsp+0x10], xmm15
000079035ddd20f3  movaps [rsp+0x20], xmm14
000079035ddd20f9  lea rdi, [rsp]
000079035ddd20fd  mov esi, 0x00
000079035ddd2102  mov rax, 0x64ACAA8B0530
000079035ddd210c  call rax
000079035ddd210e  movaps xmm13, [rsp]
000079035ddd2113  add rsp, 0x30
000079035ddd2117  vmovaps xmm0, [rsp]
000079035ddd211c  vmovaps xmm1, [rsp+0x10]
000079035ddd2122  vmovaps xmm2, [rsp+0x20]
000079035ddd2128  vmovaps xmm3, [rsp+0x30]
000079035ddd212e  vmovaps xmm4, [rsp+0x40]
000079035ddd2134  vmovaps xmm5, [rsp+0x50]
000079035ddd213a  vmovaps xmm6, [rsp+0x60]
000079035ddd2140  vmovaps xmm7, [rsp+0x70]
000079035ddd2146  vmovaps xmm8, [rsp+0x80]
000079035ddd214f  vmovaps xmm9, [rsp+0x90]
000079035ddd2158  vmovaps xmm10, [rsp+0xA0]
000079035ddd2161  vmovaps xmm11, [rsp+0xB0]
000079035ddd216a  vmovaps xmm12, [rsp+0xC0]
000079035ddd2173  vmovaps xmm14, [rsp+0xD0]
000079035ddd217c  vmovaps xmm15, [rsp+0xE0]
000079035ddd2185  add rsp, 0xF0
000079035ddd218c  pop r11
000079035ddd218e  pop r10
000079035ddd2190  pop r9
000079035ddd2192  pop r8
000079035ddd2194  pop rsi
000079035ddd2195  pop rdi
000079035ddd2196  pop rdx
000079035ddd2197  pop rcx
000079035ddd2198  pop rax
000079035ddd2199  add rsp, 0x08
000079035ddd219d  jmp 0x000079035DDD1F81
000079035ddd21a2  call 0x000079035DCC2240
000079035ddd21a7  jmp 0x000079035DDD1F9B
000079035ddd21ac  sub rsp, 0x08
000079035ddd21b0  push rax
000079035ddd21b1  push rcx
000079035ddd21b2  push rdx
000079035ddd21b3  push rdi
000079035ddd21b4  push rsi
000079035ddd21b5  push r8
000079035ddd21b7  push r9
000079035ddd21b9  push r10
000079035ddd21bb  push r11
000079035ddd21bd  sub rsp, 0xF0
000079035ddd21c4  vmovaps [rsp], xmm0
000079035ddd21c9  vmovaps [rsp+0x10], xmm1
000079035ddd21cf  vmovaps [rsp+0x20], xmm2
000079035ddd21d5  vmovaps [rsp+0x30], xmm3
000079035ddd21db  vmovaps [rsp+0x40], xmm4
000079035ddd21e1  vmovaps [rsp+0x50], xmm5
000079035ddd21e7  vmovaps [rsp+0x60], xmm6
000079035ddd21ed  vmovaps [rsp+0x70], xmm7
000079035ddd21f3  vmovaps [rsp+0x80], xmm8
000079035ddd21fc  vmovaps [rsp+0x90], xmm9
000079035ddd2205  vmovaps [rsp+0xA0], xmm10
000079035ddd220e  vmovaps [rsp+0xB0], xmm11
000079035ddd2217  vmovaps [rsp+0xC0], xmm12
000079035ddd2220  vmovaps [rsp+0xD0], xmm13
000079035ddd2229  vmovaps [rsp+0xE0], xmm15
000079035ddd2232  sub rsp, 0x30
000079035ddd2236  movaps [rsp], xmm14
000079035ddd223b  movaps [rsp+0x10], xmm1
000079035ddd2240  movaps [rsp+0x20], xmm15
000079035ddd2246  lea rdi, [rsp]
000079035ddd224a  mov esi, 0x00
000079035ddd224f  mov rax, 0x64ACAA8B0530
000079035ddd2259  call rax
000079035ddd225b  movaps xmm14, [rsp]
000079035ddd2260  add rsp, 0x30
000079035ddd2264  vmovaps xmm0, [rsp]
000079035ddd2269  vmovaps xmm1, [rsp+0x10]
000079035ddd226f  vmovaps xmm2, [rsp+0x20]
000079035ddd2275  vmovaps xmm3, [rsp+0x30]
000079035ddd227b  vmovaps xmm4, [rsp+0x40]
000079035ddd2281  vmovaps xmm5, [rsp+0x50]
000079035ddd2287  vmovaps xmm6, [rsp+0x60]
000079035ddd228d  vmovaps xmm7, [rsp+0x70]
000079035ddd2293  vmovaps xmm8, [rsp+0x80]
000079035ddd229c  vmovaps xmm9, [rsp+0x90]
000079035ddd22a5  vmovaps xmm10, [rsp+0xA0]
000079035ddd22ae  vmovaps xmm11, [rsp+0xB0]
000079035ddd22b7  vmovaps xmm12, [rsp+0xC0]
000079035ddd22c0  vmovaps xmm13, [rsp+0xD0]
000079035ddd22c9  vmovaps xmm15, [rsp+0xE0]
000079035ddd22d2  add rsp, 0xF0
000079035ddd22d9  pop r11
000079035ddd22db  pop r10
000079035ddd22dd  pop r9
000079035ddd22df  pop r8
000079035ddd22e1  pop rsi
000079035ddd22e2  pop rdi
000079035ddd22e3  pop rdx
000079035ddd22e4  pop rcx
000079035ddd22e5  pop rax
000079035ddd22e6  add rsp, 0x08
000079035ddd22ea  jmp 0x000079035DDD1FBE
000079035ddd22ef  call 0x000079035DCC34C0
000079035ddd22f4  jmp 0x000079035DDD1FD4
000079035ddd22f9  int3
000079035ddd22fa  nop [rax+rax*1], ax
000079035ddd2300  mov rax, [r15+0x50]
000079035ddd2304  lea r14, [rax+0x80]
000079035ddd230b  movups xmm1, [r13+r14*1]
000079035ddd2311  lea r14, [rax+0x90]
000079035ddd2318  movups xmm15, [r13+r14*1]
000079035ddd231e  vxorps xmm14, xmm14, xmm14
000079035ddd2323  vpbroadcastq xmm14, xmm14
000079035ddd2328  lea r14, [rax+0x40]
000079035ddd232c  movups xmm13, [r13+r14*1]
000079035ddd2332  lea r14, [rax+0x50]
000079035ddd2336  movups xmm12, [r13+r14*1]
000079035ddd233c  mov qword ptr [r15+0x48], 0x00
000079035ddd2344  movups xmm11, [r13+rax*1]
000079035ddd234a  lea r14, [rax+0x10]
000079035ddd234e  movups xmm10, [r13+r14*1]
000079035ddd2354  mov r14, [r15+0xF8]
000079035ddd235b  lea r12, [r14+0xE0]
000079035ddd2362  movups [r13+r12*1], xmm15
000079035ddd2368  lea r12, [r14+0xF0]
000079035ddd236f  movups [r13+r12*1], xmm1
000079035ddd2375  lea r12, [rax+0xC0]
000079035ddd237c  movups xmm1, [r13+r12*1]
000079035ddd2382  lea r12, [rax+0xD0]
000079035ddd2389  movups xmm15, [r13+r12*1]
000079035ddd238f  lea r12, [rax+0x140]
000079035ddd2396  movups xmm9, [r13+r12*1]
000079035ddd239c  lea r12, [rax+0x150]
000079035ddd23a3  movups xmm8, [r13+r12*1]
000079035ddd23a9  lea r12, [rax+0x180]
000079035ddd23b0  movups xmm7, [r13+r12*1]
000079035ddd23b6  lea r12, [rax+0x190]
000079035ddd23bd  movups xmm6, [r13+r12*1]
000079035ddd23c3  lea r12, [r14+0xC0]
000079035ddd23ca  movups [r13+r12*1], xmm15
000079035ddd23d0  lea r12, [r14+0xD0]
000079035ddd23d7  movups [r13+r12*1], xmm1
000079035ddd23dd  lea r12, [rax+0x100]
000079035ddd23e4  movups xmm1, [r13+r12*1]
000079035ddd23ea  lea r12, [rax+0x110]
000079035ddd23f1  movups xmm15, [r13+r12*1]
000079035ddd23f7  lea r12, [rax+0x1C0]
000079035ddd23fe  movups xmm5, [r13+r12*1]
000079035ddd2404  lea r12, [rax+0x1D0]
000079035ddd240b  movups xmm4, [r13+r12*1]
000079035ddd2411  lea r12, [rax+0x20]
000079035ddd2415  movups xmm3, [r13+r12*1]
000079035ddd241b  lea r12, [rax+0x30]
000079035ddd241f  movups xmm2, [r13+r12*1]
000079035ddd2425  movaps [r15+0x1F0], xmm2
000079035ddd242d  lea r12, [r14+0x20]
000079035ddd2431  movups [r13+r12*1], xmm1
000079035ddd2437  lea r12, [r14+0x30]
000079035ddd243b  movups [r13+r12*1], xmm12
000079035ddd2441  lea r12, [rax+0x60]
000079035ddd2445  movups xmm1, [r13+r12*1]
000079035ddd244b  lea r12, [rax+0x70]
000079035ddd244f  movups xmm12, [r13+r12*1]
000079035ddd2455  lea r12, [r14+0x60]
000079035ddd2459  movups [r13+r12*1], xmm11
000079035ddd245f  lea r12, [r14+0x70]
000079035ddd2463  movups [r13+r12*1], xmm5
000079035ddd2469  lea r12, [rax+0xE0]
000079035ddd2470  movups xmm11, [r13+r12*1]
000079035ddd2476  lea r12, [rax+0xF0]
000079035ddd247d  movups xmm5, [r13+r12*1]
000079035ddd2483  lea r12, [rax+0x120]
000079035ddd248a  vmovaps [rsp+0x10], xmm1
000079035ddd2490  movups xmm1, [r13+r12*1]
000079035ddd2496  lea r12, [rax+0x130]
000079035ddd249d  vmovaps [rsp+0x20], xmm1
000079035ddd24a3  movups xmm1, [r13+r12*1]
000079035ddd24a9  lea r12, [r14+0xA0]
000079035ddd24b0  movups [r13+r12*1], xmm12
000079035ddd24b6  lea r12, [r14+0xB0]
000079035ddd24bd  vmovaps xmm12, [rsp+0x10]
000079035ddd24c3  movups [r13+r12*1], xmm12
000079035ddd24c9  lea r12, [rax+0xA0]
000079035ddd24d0  movups xmm12, [r13+r12*1]
000079035ddd24d6  lea r12, [rax+0xB0]
000079035ddd24dd  vmovaps [rsp+0x10], xmm1
000079035ddd24e3  movups xmm1, [r13+r12*1]
000079035ddd24e9  lea r12, [rax+0x160]
000079035ddd24f0  vmovaps [rsp+0x30], xmm1
000079035ddd24f6  movups xmm1, [r13+r12*1]
000079035ddd24fc  lea r12, [rax+0x170]
000079035ddd2503  vmovaps [rsp+0x40], xmm1
000079035ddd2509  movups xmm1, [r13+r12*1]
000079035ddd250f  movaps [r15+0x2B0], xmm1
000079035ddd2517  lea r12, [rax+0x1A0]
000079035ddd251e  vmovaps [rsp+0x50], xmm1
000079035ddd2524  movups xmm1, [r13+r12*1]
000079035ddd252a  lea r12, [rax+0x1B0]
000079035ddd2531  vmovaps [rsp+0x60], xmm1
000079035ddd2537  movups xmm1, [r13+r12*1]
000079035ddd253d  vmovaps [rsp+0x70], xmm1
000079035ddd2543  vmovaps xmm1, [rsp+0x60]
000079035ddd2549  movaps [r15+0x290], xmm1
000079035ddd2551  vmovaps [rsp+0x60], xmm1
000079035ddd2557  vmovaps xmm1, [rsp+0x70]
000079035ddd255d  movaps [r15+0x1E0], xmm1
000079035ddd2565  lea r12, [r14+0x80]
000079035ddd256c  vmovaps [rsp+0x70], xmm1
000079035ddd2572  vmovaps xmm1, [rsp+0x30]
000079035ddd2578  movups [r13+r12*1], xmm1
000079035ddd257e  lea r12, [r14+0x90]
000079035ddd2585  movups [r13+r12*1], xmm12
000079035ddd258b  lea r12, [rax+0x1E0]
000079035ddd2592  movups xmm1, [r13+r12*1]
000079035ddd2598  lea r12, [rax+0x1F0]
000079035ddd259f  movups xmm12, [r13+r12*1]
000079035ddd25a5  mov qword ptr [r15+0x50], 0x432200
000079035ddd25ad  lea rax, [r14+0x40]
000079035ddd25b1  vmovaps [rsp+0x30], xmm1
000079035ddd25b7  vmovaps xmm1, [rsp+0x40]
000079035ddd25bd  movups [r13+rax*1], xmm1
000079035ddd25c3  lea rax, [r14+0x50]
000079035ddd25c7  movups [r13+rax*1], xmm10
000079035ddd25cd  movups [r13+r14*1], xmm12
000079035ddd25d3  lea rax, [r14+0x10]
000079035ddd25d7  vmovaps xmm1, [rsp+0x30]
000079035ddd25dd  movups [r13+rax*1], xmm1
000079035ddd25e3  mov rax, [r15+0x40]
000079035ddd25e7  vmovaps [rsp+0x30], xmm3
000079035ddd25ed  vmovaps xmm1, [rsp+0x30]
000079035ddd25f3  por xmm3, xmm1
000079035ddd25f7  vmovaps [rsp+0x30], xmm6
000079035ddd25fd  vmovaps xmm12, [rsp+0x30]
000079035ddd2603  por xmm6, xmm12
000079035ddd2608  lea r12, [rax+0x30]
000079035ddd260c  mov r11, [r13+r12*1]
000079035ddd2611  lea r12, [rax+0x38]
000079035ddd2615  mov r10, [r13+r12*1]
000079035ddd261a  movq xmm12, r11
000079035ddd261f  movq xmm10, r10
000079035ddd2624  movq xmm12, xmm12
000079035ddd2629  vmovaps [rsp+0x30], xmm12
000079035ddd262f  movq xmm12, xmm12
000079035ddd2634  movaps [r15+0x130], xmm12
000079035ddd263c  movq xmm10, xmm10
000079035ddd2641  vmovaps [rsp+0x40], xmm10
000079035ddd2647  movq xmm10, xmm10
000079035ddd264c  movaps [r15+0x280], xmm10
000079035ddd2654  vmovaps [rsp+0x80], xmm9
000079035ddd265d  vmovaps xmm12, [rsp+0x80]
000079035ddd2666  por xmm9, xmm12
000079035ddd266b  lea r12, [rax+0x20]
000079035ddd266f  mov r11, [r13+r12*1]
000079035ddd2674  lea r12, [rax+0x28]
000079035ddd2678  mov r10, [r13+r12*1]
000079035ddd267d  movq xmm12, r11
000079035ddd2682  movq xmm10, r10
000079035ddd2687  movq xmm12, xmm12
000079035ddd268c  vmovaps [rsp+0x80], xmm12
000079035ddd2695  movq xmm12, xmm12
000079035ddd269a  movaps [r15+0x150], xmm12
000079035ddd26a2  movq xmm10, xmm10
000079035ddd26a7  vmovaps [rsp+0x90], xmm10
000079035ddd26b0  movq xmm10, xmm10
000079035ddd26b5  movaps [r15+0x140], xmm10
000079035ddd26bd  lea r12, [rax+0x10]
000079035ddd26c1  mov r11, [r13+r12*1]
000079035ddd26c6  lea r12, [rax+0x18]
000079035ddd26ca  mov r10, [r13+r12*1]
000079035ddd26cf  movq xmm12, r11
000079035ddd26d4  movq xmm10, r10
000079035ddd26d9  movq xmm12, xmm12
000079035ddd26de  vmovaps [rsp+0xA0], xmm12
000079035ddd26e7  movq xmm12, xmm12
000079035ddd26ec  movaps [r15+0x170], xmm12
000079035ddd26f4  movq xmm10, xmm10
000079035ddd26f9  vmovaps [rsp+0xB0], xmm10
000079035ddd2702  movq xmm10, xmm10
000079035ddd2707  movaps [r15+0x160], xmm10
000079035ddd270f  mov r12, [r13+rax*1]
000079035ddd2714  vmovq xmm12, r12
000079035ddd2719  vpbroadcastq xmm12, xmm12
000079035ddd271e  lea r12, [rax+0x08]
000079035ddd2722  mov rax, [r13+r12*1]
000079035ddd2727  movq xmm10, rax
000079035ddd272c  movaps [r15+0x230], xmm10
000079035ddd2734  lea rax, [r14+0x50]
000079035ddd2738  movups xmm10, [r13+rax*1]
000079035ddd273e  lea rax, [r14+0x60]
000079035ddd2742  vmovaps [rsp+0xC0], xmm1
000079035ddd274b  movups xmm1, [r13+rax*1]
000079035ddd2751  lea rax, [r14+0x30]
000079035ddd2755  vmovaps [rsp+0xD0], xmm1
000079035ddd275e  movups xmm1, [r13+rax*1]
000079035ddd2764  mov qword ptr [r15+0x60], 0x432200
000079035ddd276c  mov qword ptr [r15+0x58], 0x40
000079035ddd2774  vmovaps [rsp+0xE0], xmm1
000079035ddd277d  vmovaps [rsp+0xF0], xmm15
000079035ddd2786  vmovaps xmm15, [rsp+0xC0]
000079035ddd278f  vmovaps [rsp+0xC0], xmm14
000079035ddd2798  movaps xmm1, xmm12
000079035ddd279c  mulpd xmm1, xmm15
000079035ddd27a1  vcmppd xmm14, xmm1, xmm1, 0x03
000079035ddd27a6  ptest xmm14, xmm14
000079035ddd27ac  jnz 0x000079035DDD3863
000079035ddd27b2  movq xmm15, qword ptr [r15+0x230]
000079035ddd27bb  vmovaps [rsp+0x100], xmm15
000079035ddd27c4  vpermilpd xmm15, xmm15, 0x00
000079035ddd27ca  vmovaps [rsp+0x110], xmm1
000079035ddd27d3  vmovaps xmm1, [rsp+0xE0]
000079035ddd27dc  vmovaps [rsp+0xE0], xmm13
000079035ddd27e5  movaps xmm14, xmm1
000079035ddd27e9  mulpd xmm14, xmm15
000079035ddd27ee  vcmppd xmm13, xmm14, xmm14, 0x03
000079035ddd27f4  ptest xmm13, xmm13
000079035ddd27fa  jnz 0x000079035DDD39A5
000079035ddd2800  vxorps xmm1, xmm1, xmm1
000079035ddd2804  vpbroadcastq xmm1, xmm1
000079035ddd2809  vmovaps xmm13, [rsp+0xD0]
000079035ddd2812  vmovaps [rsp+0xD0], xmm1
000079035ddd281b  movaps xmm15, xmm12
000079035ddd281f  mulpd xmm15, xmm13
000079035ddd2824  vcmppd xmm1, xmm15, xmm15, 0x03
000079035ddd282a  ptest xmm1, xmm1
000079035ddd282f  jnz 0x000079035DDD3AE8
000079035ddd2835  movaps xmm1, xmm12
000079035ddd2839  mulpd xmm1, xmm10
000079035ddd283e  vcmppd xmm13, xmm1, xmm1, 0x03
000079035ddd2843  ptest xmm13, xmm13
000079035ddd2849  jnz 0x000079035DDD3C2C
000079035ddd284f  movaps xmm13, xmm12
000079035ddd2853  mulpd xmm13, xmm2
000079035ddd2858  vcmppd xmm10, xmm13, xmm13, 0x03
000079035ddd285e  ptest xmm10, xmm10
000079035ddd2864  jnz 0x000079035DDD3D6E
000079035ddd286a  vmovaps [rsp+0x120], xmm7
000079035ddd2873  vmovaps xmm12, [rsp+0x120]
000079035ddd287c  por xmm7, xmm12
000079035ddd2881  vmovaps xmm12, [rsp+0xE0]
000079035ddd288a  vmovaps xmm10, [rsp+0xE0]
000079035ddd2893  por xmm12, xmm10
000079035ddd2898  vmovaps xmm2, [rsp+0x100]
000079035ddd28a1  vpermilpd xmm2, xmm2, 0x00
000079035ddd28a7  vmovaps [rsp+0xE0], xmm1
000079035ddd28b0  vmovaps [rsp+0x120], xmm15
000079035ddd28b9  movaps xmm1, xmm10
000079035ddd28bd  mulpd xmm1, xmm2
000079035ddd28c1  vcmppd xmm15, xmm1, xmm1, 0x03
000079035ddd28c6  ptest xmm15, xmm15
000079035ddd28cc  jnz 0x000079035DDD3EB1
000079035ddd28d2  xor eax, eax
000079035ddd28d4  mov r12d, 0x40
000079035ddd28da  mov r11d, 0x200
000079035ddd28e0  cmp r12, r11
000079035ddd28e3  cmc
000079035ddd28e4  lahf
000079035ddd28e5  seto al
000079035ddd28e8  mov [r15+0x108], eax
000079035ddd28ef  vmovaps xmm10, [rsp+0x110]
000079035ddd28f8  vmovaps xmm2, [rsp+0xD0]
000079035ddd2901  vmovaps [rsp+0xD0], xmm1
000079035ddd290a  movaps xmm15, xmm10
000079035ddd290e  addpd xmm15, xmm2
000079035ddd2913  vcmppd xmm1, xmm15, xmm15, 0x03
000079035ddd2919  ptest xmm1, xmm1
000079035ddd291e  jnz 0x000079035DDD3FF2
000079035ddd2924  vmovaps xmm10, [rsp+0x120]
000079035ddd292d  vmovaps [rsp+0x110], xmm15
000079035ddd2936  vmovaps xmm15, [rsp+0xC0]
000079035ddd293f  vmovaps [rsp+0xC0], xmm14
000079035ddd2948  movaps xmm1, xmm10
000079035ddd294c  addpd xmm1, xmm15
000079035ddd2951  vcmppd xmm14, xmm1, xmm1, 0x03
000079035ddd2956  ptest xmm14, xmm14
000079035ddd295c  jnz 0x000079035DDD4135
000079035ddd2962  vmovaps xmm10, [rsp+0xE0]
000079035ddd296b  vmovaps [rsp+0xE0], xmm1
000079035ddd2974  movaps xmm14, xmm10
000079035ddd2978  addpd xmm14, xmm15
000079035ddd297d  vcmppd xmm1, xmm14, xmm14, 0x03
000079035ddd2983  ptest xmm1, xmm1
000079035ddd2988  jnz 0x000079035DDD4277
000079035ddd298e  vmovaps xmm1, [rsp+0x10]
000079035ddd2994  vmovaps xmm15, [rsp+0x10]
000079035ddd299a  por xmm1, xmm15
000079035ddd299f  vmovaps xmm15, [rsp+0x20]
000079035ddd29a5  vmovaps xmm10, [rsp+0x20]
000079035ddd29ab  por xmm15, xmm10
000079035ddd29b0  vmovaps [rsp+0x10], xmm5
000079035ddd29b6  vmovaps xmm10, [rsp+0x10]
000079035ddd29bc  por xmm5, xmm10
000079035ddd29c1  vmovaps [rsp+0x10], xmm11
000079035ddd29c7  vmovaps xmm10, [rsp+0x10]
000079035ddd29cd  por xmm11, xmm10
000079035ddd29d2  vmovaps [rsp+0x10], xmm4
000079035ddd29d8  vmovaps xmm10, [rsp+0x10]
000079035ddd29de  por xmm4, xmm10
000079035ddd29e3  vmovaps [rsp+0x10], xmm8
000079035ddd29e9  vmovaps xmm10, [rsp+0x10]
000079035ddd29ef  por xmm8, xmm10
000079035ddd29f4  vmovaps xmm10, [rsp+0xF0]
000079035ddd29fd  vmovaps [rsp+0x10], xmm1
000079035ddd2a03  vmovaps xmm1, [rsp+0xF0]
000079035ddd2a0c  por xmm10, xmm1
000079035ddd2a11  lea rax, [r14+0xA0]
000079035ddd2a18  movups xmm1, [r13+rax*1]
000079035ddd2a1e  lea rax, [r14+0xB0]
000079035ddd2a25  vmovaps [rsp+0x20], xmm1
000079035ddd2a2b  movups xmm1, [r13+rax*1]
000079035ddd2a31  vmovaps [rsp+0xF0], xmm1
000079035ddd2a3a  vmovaps [rsp+0x120], xmm15
000079035ddd2a43  movaps xmm1, xmm13
000079035ddd2a47  addpd xmm1, xmm2
000079035ddd2a4b  vcmppd xmm15, xmm1, xmm1, 0x03
000079035ddd2a50  ptest xmm15, xmm15
000079035ddd2a56  jnz 0x000079035DDD43CF
000079035ddd2a5c  lea rax, [r14+0xF0]
000079035ddd2a63  movups xmm15, [r13+rax*1]
000079035ddd2a69  vmovaps xmm2, [rsp+0xE0]
000079035ddd2a72  vmovaps [rsp+0xE0], xmm1
000079035ddd2a7b  vmovaps xmm1, [rsp+0xD0]
000079035ddd2a84  vmovaps [rsp+0xD0], xmm15
000079035ddd2a8d  movaps xmm13, xmm2
000079035ddd2a91  addpd xmm13, xmm1
000079035ddd2a96  vcmppd xmm15, xmm13, xmm13, 0x03
000079035ddd2a9c  ptest xmm15, xmm15
000079035ddd2aa2  jnz 0x000079035DDD451A
000079035ddd2aa8  vmovaps xmm15, [rsp+0xC0]
000079035ddd2ab1  movaps xmm1, xmm14
000079035ddd2ab5  addpd xmm1, xmm15
000079035ddd2aba  vcmppd xmm2, xmm1, xmm1, 0x03
000079035ddd2abf  ptest xmm2, xmm2
000079035ddd2ac4  jnz 0x000079035DDD465C
000079035ddd2aca  vmovaps xmm15, [rsp+0x100]
000079035ddd2ad3  vpermilpd xmm15, xmm15, 0x00
000079035ddd2ad9  vmovaps xmm2, [rsp+0xF0]
000079035ddd2ae2  vmovaps [rsp+0xC0], xmm1
000079035ddd2aeb  movaps xmm14, xmm2
000079035ddd2aef  mulpd xmm14, xmm15
000079035ddd2af4  vcmppd xmm1, xmm14, xmm14, 0x03
000079035ddd2afa  ptest xmm1, xmm1
000079035ddd2aff  jnz 0x000079035DDD479E
000079035ddd2b05  vmovaps xmm1, [rsp+0xA0]
000079035ddd2b0e  vpermilpd xmm1, xmm1, 0x00
000079035ddd2b14  vmovaps xmm2, [rsp+0xD0]
000079035ddd2b1d  vmovaps [rsp+0xD0], xmm14
000079035ddd2b26  movaps xmm15, xmm2
000079035ddd2b2a  mulpd xmm15, xmm1
000079035ddd2b2f  vcmppd xmm14, xmm15, xmm15, 0x03
000079035ddd2b35  ptest xmm14, xmm14
000079035ddd2b3b  jnz 0x000079035DDD48E1
000079035ddd2b41  lea rax, [r14+0xE0]
000079035ddd2b48  movups xmm1, [r13+rax*1]
000079035ddd2b4e  vmovaps xmm14, [rsp+0x100]
000079035ddd2b57  vpermilpd xmm14, xmm14, 0x00
000079035ddd2b5d  vmovaps [rsp+0xF0], xmm1
000079035ddd2b66  vmovaps xmm1, [rsp+0x20]
000079035ddd2b6c  vmovaps [rsp+0x20], xmm15
000079035ddd2b72  movaps xmm2, xmm1
000079035ddd2b75  mulpd xmm2, xmm14
000079035ddd2b7a  vcmppd xmm15, xmm2, xmm2, 0x03
000079035ddd2b7f  ptest xmm15, xmm15
000079035ddd2b85  jnz 0x000079035DDD4A2D
000079035ddd2b8b  vmovaps [rsp+0x100], xmm10
000079035ddd2b94  vmovaps xmm1, [rsp+0x100]
000079035ddd2b9d  por xmm10, xmm1
000079035ddd2ba2  movaps [r15+0x300], xmm10
000079035ddd2baa  vmovaps [rsp+0x100], xmm8
000079035ddd2bb3  vmovaps xmm1, [rsp+0x100]
000079035ddd2bbc  por xmm8, xmm1
000079035ddd2bc1  movaps [r15+0x190], xmm8
000079035ddd2bc9  vmovaps xmm1, [rsp+0xA0]
000079035ddd2bd2  vpermilpd xmm1, xmm1, 0x00
000079035ddd2bd8  vmovaps xmm14, [rsp+0xF0]
000079035ddd2be1  vmovaps [rsp+0xF0], xmm13
000079035ddd2bea  movaps xmm15, xmm14
000079035ddd2bee  mulpd xmm15, xmm1
000079035ddd2bf3  vcmppd xmm13, xmm15, xmm15, 0x03
000079035ddd2bf9  ptest xmm13, xmm13
000079035ddd2bff  jnz 0x000079035DDD4B6E
000079035ddd2c05  lea rax, [r14+0x90]
000079035ddd2c0c  movups xmm1, [r13+rax*1]
000079035ddd2c12  vmovaps [rsp+0x100], xmm4
000079035ddd2c1b  vmovaps xmm14, [rsp+0x100]
000079035ddd2c24  por xmm4, xmm14
000079035ddd2c29  movaps [r15+0x1C0], xmm4
000079035ddd2c31  vmovaps [rsp+0x100], xmm11
000079035ddd2c3a  vmovaps xmm14, [rsp+0x100]
000079035ddd2c43  por xmm11, xmm14
000079035ddd2c48  movaps [r15+0x200], xmm11
000079035ddd2c50  vmovaps [rsp+0x100], xmm5
000079035ddd2c59  vmovaps xmm14, [rsp+0x100]
000079035ddd2c62  por xmm5, xmm14
000079035ddd2c67  movaps [r15+0x2D0], xmm5
000079035ddd2c6f  vmovaps xmm14, [rsp+0x120]
000079035ddd2c78  vmovaps xmm13, [rsp+0x120]
000079035ddd2c81  por xmm14, xmm13
000079035ddd2c86  movaps [r15+0x2E0], xmm14
000079035ddd2c8e  vmovaps [rsp+0x100], xmm1
000079035ddd2c97  vmovaps xmm1, [rsp+0x110]
000079035ddd2ca0  vmovaps [rsp+0x110], xmm15
000079035ddd2ca9  vmovaps xmm15, [rsp+0xD0]
000079035ddd2cb2  vmovaps [rsp+0xD0], xmm14
000079035ddd2cbb  movaps xmm13, xmm1
000079035ddd2cbf  addpd xmm13, xmm15
000079035ddd2cc4  vcmppd xmm14, xmm13, xmm13, 0x03
000079035ddd2cca  ptest xmm14, xmm14
000079035ddd2cd0  jnz 0x000079035DDD4CBB
000079035ddd2cd6  vmovaps xmm1, [rsp+0xA0]
000079035ddd2cdf  vpermilpd xmm1, xmm1, 0x00
000079035ddd2ce5  vmovaps xmm14, [rsp+0x100]
000079035ddd2cee  vmovaps [rsp+0x100], xmm13
000079035ddd2cf7  movaps xmm15, xmm14
000079035ddd2cfb  mulpd xmm15, xmm1
000079035ddd2d00  vcmppd xmm13, xmm15, xmm15, 0x03
000079035ddd2d06  ptest xmm13, xmm13
000079035ddd2d0c  jnz 0x000079035DDD4DFE
000079035ddd2d12  lea rax, [r14+0x80]
000079035ddd2d19  movups xmm1, [r13+rax*1]
000079035ddd2d1f  vmovaps xmm13, [rsp+0xE0]
000079035ddd2d28  vmovaps [rsp+0xE0], xmm1
000079035ddd2d31  movaps xmm14, xmm13
000079035ddd2d35  addpd xmm14, xmm2
000079035ddd2d3a  vcmppd xmm1, xmm14, xmm14, 0x03
000079035ddd2d40  ptest xmm1, xmm1
000079035ddd2d45  jnz 0x000079035DDD4F4B
000079035ddd2d4b  vmovaps xmm13, [rsp+0xF0]
000079035ddd2d54  vmovaps xmm2, [rsp+0x20]
000079035ddd2d5a  vmovaps [rsp+0x20], xmm15
000079035ddd2d60  movaps xmm1, xmm13
000079035ddd2d64  addpd xmm1, xmm2
000079035ddd2d68  vcmppd xmm15, xmm1, xmm1, 0x03
000079035ddd2d6d  ptest xmm15, xmm15
000079035ddd2d73  jnz 0x000079035DDD508E
000079035ddd2d79  vmovaps xmm15, [rsp+0x10]
000079035ddd2d7f  vmovaps xmm13, [rsp+0x10]
000079035ddd2d85  por xmm15, xmm13
000079035ddd2d8a  movaps [r15+0x2F0], xmm15
000079035ddd2d92  vmovaps xmm13, [rsp+0xA0]
000079035ddd2d9b  vpermilpd xmm13, xmm13, 0x00
000079035ddd2da1  vmovaps [rsp+0x10], xmm1
000079035ddd2da7  vmovaps xmm1, [rsp+0xE0]
000079035ddd2db0  vmovaps [rsp+0xA0], xmm15
000079035ddd2db9  movaps xmm2, xmm1
000079035ddd2dbc  mulpd xmm2, xmm13
000079035ddd2dc1  vcmppd xmm15, xmm2, xmm2, 0x03
000079035ddd2dc6  ptest xmm15, xmm15
000079035ddd2dcc  jnz 0x000079035DDD51CF
000079035ddd2dd2  lea rax, [r14+0xD0]
000079035ddd2dd9  movups xmm1, [r13+rax*1]
000079035ddd2ddf  vmovaps xmm13, [rsp+0xC0]
000079035ddd2de8  vmovaps [rsp+0xC0], xmm1
000079035ddd2df1  vmovaps xmm1, [rsp+0x110]
000079035ddd2dfa  vmovaps [rsp+0xE0], xmm14
000079035ddd2e03  movaps xmm15, xmm13
000079035ddd2e07  addpd xmm15, xmm1
000079035ddd2e0c  vcmppd xmm14, xmm15, xmm15, 0x03
000079035ddd2e12  ptest xmm14, xmm14
000079035ddd2e18  jnz 0x000079035DDD531A
000079035ddd2e1e  vmovaps xmm1, [rsp+0xB0]
000079035ddd2e27  vpermilpd xmm1, xmm1, 0x00
000079035ddd2e2d  movaps xmm14, xmm11
000079035ddd2e31  mulpd xmm14, xmm1
000079035ddd2e36  vcmppd xmm13, xmm14, xmm14, 0x03
000079035ddd2e3c  ptest xmm13, xmm13
000079035ddd2e42  jnz 0x000079035DDD545D
000079035ddd2e48  movaps [r15+0x260], xmm14
000079035ddd2e50  vxorps xmm1, xmm1, xmm1
000079035ddd2e54  vpbroadcastq xmm1, xmm1
000079035ddd2e59  movaps [r15+0x1B0], xmm1
000079035ddd2e61  vmovaps xmm1, [rsp+0xB0]
000079035ddd2e6a  vpermilpd xmm1, xmm1, 0x00
000079035ddd2e70  vmovaps xmm11, [rsp+0xC0]
000079035ddd2e79  vmovaps [rsp+0xC0], xmm15
000079035ddd2e82  movaps xmm13, xmm11
000079035ddd2e86  mulpd xmm13, xmm1
000079035ddd2e8b  vcmppd xmm15, xmm13, xmm13, 0x03
000079035ddd2e91  ptest xmm15, xmm15
000079035ddd2e97  jnz 0x000079035DDD55A0
000079035ddd2e9d  lea rax, [r14+0xC0]
000079035ddd2ea4  movups xmm1, [r13+rax*1]
000079035ddd2eaa  vmovaps xmm11, [rsp+0x100]
000079035ddd2eb3  vmovaps [rsp+0xF0], xmm1
000079035ddd2ebc  vmovaps xmm1, [rsp+0x20]
000079035ddd2ec2  vmovaps [rsp+0x20], xmm14
000079035ddd2ec8  movaps xmm15, xmm11
000079035ddd2ecc  addpd xmm15, xmm1
000079035ddd2ed1  vcmppd xmm14, xmm15, xmm15, 0x03
000079035ddd2ed7  ptest xmm14, xmm14
000079035ddd2edd  jnz 0x000079035DDD56ED
000079035ddd2ee3  vmovaps [rsp+0x100], xmm9
000079035ddd2eec  vmovaps xmm1, [rsp+0x100]
000079035ddd2ef5  por xmm9, xmm1
000079035ddd2efa  movaps [r15+0x270], xmm9
000079035ddd2f02  vmovaps [rsp+0x100], xmm6
000079035ddd2f0b  vmovaps xmm1, [rsp+0x100]
000079035ddd2f14  por xmm6, xmm1
000079035ddd2f18  movaps [r15+0x1A0], xmm6
000079035ddd2f20  vmovaps xmm14, [rsp+0xB0]
000079035ddd2f29  vpermilpd xmm14, xmm14, 0x00
000079035ddd2f2f  vmovaps xmm6, [rsp+0xF0]
000079035ddd2f38  vmovaps [rsp+0xF0], xmm1
000079035ddd2f41  movaps xmm11, xmm6
000079035ddd2f45  mulpd xmm11, xmm14
000079035ddd2f4a  vcmppd xmm1, xmm11, xmm11, 0x03
000079035ddd2f50  ptest xmm1, xmm1
000079035ddd2f55  jnz 0x000079035DDD5830
000079035ddd2f5b  lea rax, [r14+0x20]
000079035ddd2f5f  movups xmm1, [r13+rax*1]
000079035ddd2f65  movaps [r15+0x110], xmm1
000079035ddd2f6d  vmovaps xmm6, [rsp+0xE0]
000079035ddd2f76  vmovaps [rsp+0xE0], xmm1
000079035ddd2f7f  movaps xmm14, xmm6
000079035ddd2f83  addpd xmm14, xmm2
000079035ddd2f88  vcmppd xmm1, xmm14, xmm14, 0x03
000079035ddd2f8e  ptest xmm1, xmm1
000079035ddd2f93  jnz 0x000079035DDD597D
000079035ddd2f99  vmovaps xmm1, [rsp+0xB0]
000079035ddd2fa2  vpermilpd xmm1, xmm1, 0x00
000079035ddd2fa8  movaps xmm6, xmm5
000079035ddd2fab  mulpd xmm6, xmm1
000079035ddd2faf  vcmppd xmm2, xmm6, xmm6, 0x03
000079035ddd2fb4  ptest xmm2, xmm2
000079035ddd2fb9  jnz 0x000079035DDD5ABF
000079035ddd2fbf  vmovaps xmm5, [rsp+0x10]
000079035ddd2fc5  movaps xmm1, xmm5
000079035ddd2fc8  addpd xmm1, xmm13
000079035ddd2fcd  vcmppd xmm2, xmm1, xmm1, 0x03
000079035ddd2fd2  ptest xmm2, xmm2
000079035ddd2fd7  jnz 0x000079035DDD5BFF
000079035ddd2fdd  vmovaps xmm13, [rsp+0x80]
000079035ddd2fe6  vpermilpd xmm13, xmm13, 0x00
000079035ddd2fec  vmovaps xmm2, [rsp+0xE0]
000079035ddd2ff5  vmovaps [rsp+0x10], xmm1
000079035ddd2ffb  movaps xmm5, xmm2
000079035ddd2ffe  mulpd xmm5, xmm13
000079035ddd3003  vcmppd xmm1, xmm5, xmm5, 0x03
000079035ddd3008  ptest xmm1, xmm1
000079035ddd300d  jnz 0x000079035DDD5D40
000079035ddd3013  vmovaps xmm1, [rsp+0x80]
000079035ddd301c  vpermilpd xmm1, xmm1, 0x00
000079035ddd3022  movaps xmm13, xmm10
000079035ddd3026  mulpd xmm13, xmm1
000079035ddd302b  vcmppd xmm2, xmm13, xmm13, 0x03
000079035ddd3031  ptest xmm2, xmm2
000079035ddd3036  jnz 0x000079035DDD5E81
000079035ddd303c  vmovaps xmm10, [rsp+0x20]
000079035ddd3042  movaps xmm1, xmm15
000079035ddd3046  addpd xmm1, xmm10
000079035ddd304b  vcmppd xmm2, xmm1, xmm1, 0x03
000079035ddd3050  ptest xmm2, xmm2
000079035ddd3055  jnz 0x000079035DDD5FC4
000079035ddd305b  vmovaps xmm10, [rsp+0xC0]
000079035ddd3064  movaps xmm15, xmm10
000079035ddd3068  addpd xmm15, xmm11
000079035ddd306d  vcmppd xmm2, xmm15, xmm15, 0x03
000079035ddd3073  ptest xmm2, xmm2
000079035ddd3078  jnz 0x000079035DDD6106
000079035ddd307e  vmovaps xmm11, [rsp+0x80]
000079035ddd3087  vpermilpd xmm11, xmm11, 0x00
000079035ddd308d  vmovaps xmm2, [rsp+0xD0]
000079035ddd3096  vmovaps [rsp+0x20], xmm1
000079035ddd309c  movaps xmm10, xmm2
000079035ddd30a0  mulpd xmm10, xmm11
000079035ddd30a5  vcmppd xmm1, xmm10, xmm10, 0x03
000079035ddd30ab  ptest xmm1, xmm1
000079035ddd30b0  jnz 0x000079035DDD624A
000079035ddd30b6  vmovaps xmm1, [rsp+0x80]
000079035ddd30bf  vpermilpd xmm1, xmm1, 0x00
000079035ddd30c5  vmovaps xmm2, [rsp+0xA0]
000079035ddd30ce  vmovaps [rsp+0x80], xmm15
000079035ddd30d7  movaps xmm11, xmm2
000079035ddd30db  mulpd xmm11, xmm1
000079035ddd30e0  vcmppd xmm15, xmm11, xmm11, 0x03
000079035ddd30e6  ptest xmm15, xmm15
000079035ddd30ec  jnz 0x000079035DDD638D
000079035ddd30f2  movaps xmm1, xmm14
000079035ddd30f6  addpd xmm1, xmm6
000079035ddd30fa  vcmppd xmm15, xmm1, xmm1, 0x03
000079035ddd30ff  ptest xmm15, xmm15
000079035ddd3105  jnz 0x000079035DDD64CF
000079035ddd310b  vmovaps xmm14, [rsp+0x10]
000079035ddd3111  movaps xmm15, xmm14
000079035ddd3115  addpd xmm15, xmm5
000079035ddd311a  vcmppd xmm6, xmm15, xmm15, 0x03
000079035ddd3120  ptest xmm6, xmm6
000079035ddd3125  jnz 0x000079035DDD6610
000079035ddd312b  vmovaps xmm14, [rsp+0x90]
000079035ddd3134  vpermilpd xmm14, xmm14, 0x00
000079035ddd313a  movaps xmm6, xmm9
000079035ddd313e  mulpd xmm6, xmm14
000079035ddd3143  vcmppd xmm5, xmm6, xmm6, 0x03
000079035ddd3148  ptest xmm5, xmm5
000079035ddd314d  jnz 0x000079035DDD6753
000079035ddd3153  vmovaps xmm9, [rsp+0x80]
000079035ddd315c  movaps xmm14, xmm9
000079035ddd3160  addpd xmm14, xmm13
000079035ddd3165  vcmppd xmm5, xmm14, xmm14, 0x03
000079035ddd316b  ptest xmm5, xmm5
000079035ddd3170  jnz 0x000079035DDD6895
000079035ddd3176  vmovaps xmm9, [rsp+0x20]
000079035ddd317c  movaps xmm13, xmm9
000079035ddd3180  addpd xmm13, xmm10
000079035ddd3185  vcmppd xmm5, xmm13, xmm13, 0x03
000079035ddd318b  ptest xmm5, xmm5
000079035ddd3190  jnz 0x000079035DDD69D9
000079035ddd3196  vmovaps [rsp+0x10], xmm12
000079035ddd319c  vmovaps xmm10, [rsp+0x10]
000079035ddd31a2  por xmm12, xmm10
000079035ddd31a7  movaps [r15+0x250], xmm12
000079035ddd31af  vmovaps [rsp+0x10], xmm7
000079035ddd31b5  vmovaps xmm12, [rsp+0x10]
000079035ddd31bb  por xmm7, xmm12
000079035ddd31c0  movaps [r15+0x2A0], xmm7
000079035ddd31c8  vmovaps [rsp+0x10], xmm3
000079035ddd31ce  vmovaps xmm12, [rsp+0x10]
000079035ddd31d4  por xmm3, xmm12
000079035ddd31d9  movaps [r15+0x1D0], xmm3
000079035ddd31e1  lea rax, [r14+0x40]
000079035ddd31e5  movups xmm12, [r13+rax*1]
000079035ddd31eb  movaps [r15+0x2C0], xmm12
000079035ddd31f3  vmovaps xmm10, [rsp+0x90]
000079035ddd31fc  vpermilpd xmm10, xmm10, 0x00
000079035ddd3202  movaps xmm9, xmm8
000079035ddd3206  mulpd xmm9, xmm10
000079035ddd320b  vcmppd xmm5, xmm9, xmm9, 0x03
000079035ddd3211  ptest xmm5, xmm5
000079035ddd3216  jnz 0x000079035DDD6B27
000079035ddd321c  movaps xmm10, xmm1
000079035ddd3220  addpd xmm10, xmm11
000079035ddd3225  vcmppd xmm8, xmm10, xmm10, 0x03
000079035ddd322b  ptest xmm8, xmm8
000079035ddd3231  jnz 0x000079035DDD6C6B
000079035ddd3237  movaps xmm1, xmm15
000079035ddd323b  addpd xmm1, xmm6
000079035ddd323f  vcmppd xmm11, xmm1, xmm1, 0x03
000079035ddd3244  ptest xmm11, xmm11
000079035ddd324a  jnz 0x000079035DDD6DAE
000079035ddd3250  vmovaps xmm15, [rsp+0x90]
000079035ddd3259  vpermilpd xmm15, xmm15, 0x00
000079035ddd325f  movaps xmm11, xmm12
000079035ddd3263  mulpd xmm11, xmm15
000079035ddd3268  vcmppd xmm8, xmm11, xmm11, 0x03
000079035ddd326e  ptest xmm8, xmm8
000079035ddd3274  jnz 0x000079035DDD6EEF
000079035ddd327a  vmovaps xmm15, [rsp+0x90]
000079035ddd3283  vpermilpd xmm15, xmm15, 0x00
000079035ddd3289  vmovaps xmm8, [rsp+0x50]
000079035ddd328f  movaps xmm12, xmm8
000079035ddd3293  mulpd xmm12, xmm15
000079035ddd3298  vcmppd xmm6, xmm12, xmm12, 0x03
000079035ddd329e  ptest xmm6, xmm6
000079035ddd32a3  jnz 0x000079035DDD7033
000079035ddd32a9  vmovaps xmm15, [rsp+0x30]
000079035ddd32af  vpermilpd xmm15, xmm15, 0x00
000079035ddd32b5  movaps xmm8, xmm7
000079035ddd32b9  mulpd xmm8, xmm15
000079035ddd32be  vcmppd xmm6, xmm8, xmm8, 0x03
000079035ddd32c4  ptest xmm6, xmm6
000079035ddd32c9  jnz 0x000079035DDD7177
000079035ddd32cf  movaps xmm15, xmm14
000079035ddd32d3  addpd xmm15, xmm9
000079035ddd32d8  vcmppd xmm7, xmm15, xmm15, 0x03
000079035ddd32de  ptest xmm7, xmm7
000079035ddd32e3  jnz 0x000079035DDD72BA
000079035ddd32e9  vmovaps xmm14, [rsp+0x30]
000079035ddd32ef  vpermilpd xmm14, xmm14, 0x00
000079035ddd32f5  vmovaps xmm7, [rsp+0xF0]
000079035ddd32fe  movaps xmm9, xmm7
000079035ddd3302  mulpd xmm9, xmm14
000079035ddd3307  vcmppd xmm6, xmm9, xmm9, 0x03
000079035ddd330d  ptest xmm6, xmm6
000079035ddd3312  jnz 0x000079035DDD73FE
000079035ddd3318  movaps xmm14, xmm13
000079035ddd331c  addpd xmm14, xmm11
000079035ddd3321  vcmppd xmm7, xmm14, xmm14, 0x03
000079035ddd3327  ptest xmm7, xmm7
000079035ddd332c  jnz 0x000079035DDD7541
000079035ddd3332  vmovaps xmm13, [rsp+0x30]
000079035ddd3338  vpermilpd xmm13, xmm13, 0x00
000079035ddd333e  vmovaps xmm7, [rsp+0x60]
000079035ddd3344  movaps xmm11, xmm7
000079035ddd3348  mulpd xmm11, xmm13
000079035ddd334d  vcmppd xmm6, xmm11, xmm11, 0x03
000079035ddd3353  ptest xmm6, xmm6
000079035ddd3358  jnz 0x000079035DDD7685
000079035ddd335e  movaps xmm13, xmm10
000079035ddd3362  addpd xmm13, xmm12
000079035ddd3367  vcmppd xmm7, xmm13, xmm13, 0x03
000079035ddd336d  ptest xmm7, xmm7
000079035ddd3372  jnz 0x000079035DDD77C8
000079035ddd3378  vmovaps xmm12, [rsp+0x30]
000079035ddd337e  vpermilpd xmm12, xmm12, 0x00
000079035ddd3384  vmovaps xmm7, [rsp+0x70]
000079035ddd338a  movaps xmm10, xmm7
000079035ddd338e  mulpd xmm10, xmm12
000079035ddd3393  vcmppd xmm6, xmm10, xmm10, 0x03
000079035ddd3399  ptest xmm6, xmm6
000079035ddd339e  jnz 0x000079035DDD790C
000079035ddd33a4  movaps xmm12, xmm1
000079035ddd33a8  addpd xmm12, xmm8
000079035ddd33ad  vcmppd xmm7, xmm12, xmm12, 0x03
000079035ddd33b3  ptest xmm7, xmm7
000079035ddd33b8  jnz 0x000079035DDD7A4F
000079035ddd33be  lea rax, [r14+0x70]
000079035ddd33c2  movups xmm1, [r13+rax*1]
000079035ddd33c8  movaps [r15+0x240], xmm1
000079035ddd33d0  movaps xmm8, xmm15
000079035ddd33d4  addpd xmm8, xmm9
000079035ddd33d9  vcmppd xmm7, xmm8, xmm8, 0x03
000079035ddd33df  ptest xmm7, xmm7
000079035ddd33e4  jnz 0x000079035DDD7B9C
000079035ddd33ea  movaps [r15+0x170], xmm8
000079035ddd33f2  vmovaps xmm15, [rsp+0x40]
000079035ddd33f8  vpermilpd xmm15, xmm15, 0x00
000079035ddd33fe  movaps xmm9, xmm1
000079035ddd3402  mulpd xmm9, xmm15
000079035ddd3407  vcmppd xmm7, xmm9, xmm9, 0x03
000079035ddd340d  ptest xmm7, xmm7
000079035ddd3412  jnz 0x000079035DDD7CE0
000079035ddd3418  vmovaps xmm1, [rsp+0x40]
000079035ddd341e  vpermilpd xmm1, xmm1, 0x00
000079035ddd3424  movaps xmm15, xmm4
000079035ddd3428  mulpd xmm15, xmm1
000079035ddd342d  vcmppd xmm7, xmm15, xmm15, 0x03
000079035ddd3433  ptest xmm7, xmm7
000079035ddd3438  jnz 0x000079035DDD7E23
000079035ddd343e  movaps [r15+0x180], xmm15
000079035ddd3446  movaps xmm1, xmm14
000079035ddd344a  addpd xmm1, xmm11
000079035ddd344f  vcmppd xmm7, xmm1, xmm1, 0x03
000079035ddd3454  ptest xmm7, xmm7
000079035ddd3459  jnz 0x000079035DDD7F65
000079035ddd345f  movaps [r15+0x210], xmm1
000079035ddd3467  movups xmm14, [r13+r14*1]
000079035ddd346d  lea rax, [r14+0x10]
000079035ddd3471  movups xmm11, [r13+rax*1]
000079035ddd3477  movaps [r15+0x230], xmm11
000079035ddd347f  movaps xmm7, xmm13
000079035ddd3483  addpd xmm7, xmm10
000079035ddd3488  vcmppd xmm6, xmm7, xmm7, 0x03
000079035ddd348d  ptest xmm6, xmm6
000079035ddd3492  jnz 0x000079035DDD80BB
000079035ddd3498  movaps [r15+0x130], xmm7
000079035ddd34a0  vmovaps xmm13, [rsp+0x40]
000079035ddd34a6  vpermilpd xmm13, xmm13, 0x00
000079035ddd34ac  movaps xmm10, xmm11
000079035ddd34b0  mulpd xmm10, xmm13
000079035ddd34b5  vcmppd xmm6, xmm10, xmm10, 0x03
000079035ddd34bb  ptest xmm6, xmm6
000079035ddd34c0  jnz 0x000079035DDD81FD
000079035ddd34c6  movaps [r15+0x220], xmm10
000079035ddd34ce  vmovaps xmm13, [rsp+0x40]
000079035ddd34d4  vpermilpd xmm13, xmm13, 0x00
000079035ddd34da  movaps xmm11, xmm14
000079035ddd34de  mulpd xmm11, xmm13
000079035ddd34e3  vcmppd xmm6, xmm11, xmm11, 0x03
000079035ddd34e9  ptest xmm6, xmm6
000079035ddd34ee  jnz 0x000079035DDD8341
000079035ddd34f4  movaps xmm14, xmm12
000079035ddd34f8  addpd xmm14, xmm9
000079035ddd34fd  vcmppd xmm13, xmm14, xmm14, 0x03
000079035ddd3503  ptest xmm13, xmm13
000079035ddd3509  jnz 0x000079035DDD8485
000079035ddd350f  movaps [r15+0x140], xmm14
000079035ddd3517  movaps xmm13, xmm8
000079035ddd351b  addpd xmm13, xmm15
000079035ddd3520  vcmppd xmm12, xmm13, xmm13, 0x03
000079035ddd3526  ptest xmm12, xmm12
000079035ddd352c  jnz 0x000079035DDD85C9
000079035ddd3532  movaps [r15+0x150], xmm13
000079035ddd353a  movaps xmm15, xmm1
000079035ddd353e  addpd xmm15, xmm10
000079035ddd3543  vcmppd xmm12, xmm15, xmm15, 0x03
000079035ddd3549  ptest xmm12, xmm12
000079035ddd354f  jnz 0x000079035DDD870D
000079035ddd3555  movaps [r15+0x160], xmm15
000079035ddd355d  movaps xmm1, xmm7
000079035ddd3560  addpd xmm1, xmm11
000079035ddd3565  vcmppd xmm12, xmm1, xmm1, 0x03
000079035ddd356a  ptest xmm12, xmm12
000079035ddd3570  jnz 0x000079035DDD8850
000079035ddd3576  movaps [r15+0x120], xmm1
000079035ddd357e  mov eax, 0x432200
000079035ddd3583  movups [r13+rax*1], xmm14
000079035ddd3589  mov eax, 0x432210
000079035ddd358e  movups [r13+rax*1], xmm13
000079035ddd3594  mov eax, 0x432220
000079035ddd3599  movups [r13+rax*1], xmm15
000079035ddd359f  mov eax, 0x432230
000079035ddd35a4  movups [r13+rax*1], xmm1
000079035ddd35aa  mov eax, [r15+0x108]
000079035ddd35b1  sahf
000079035ddd35b2  jnz 0x000079035DDD35E4
000079035ddd35b4  cmp dword ptr [r15+0x318], 0x00
000079035ddd35bc  jz 0x000079035DDDEAE0
000079035ddd35c2  nop [rax+rax*1], ax
000079035ddd35cb  nop [rax+rax*1], eax
000079035ddd35d3  mov eax, 0x4106D0
000079035ddd35d8  mov [r15+0x100], rax
000079035ddd35df  jmp 0x000079035DBFE110
000079035ddd35e4  cmp dword ptr [r15+0x318], 0x00
000079035ddd35ec  jz 0x000079035DDD89C0
000079035ddd35f2  nop [rax+rax*1], ax
000079035ddd35fb  nop [rax+rax*1], eax
000079035ddd3603  mov eax, 0x410504
000079035ddd3608  mov [r15+0x100], rax
000079035ddd360f  jmp 0x000079035DBFE110
000079035ddd3614  int3
000079035ddd3615  call 0x000079035DCD64F0
000079035ddd361a  jmp 0x000079035DDD2311
000079035ddd361f  call 0x000079035DCE5820
000079035ddd3624  jmp 0x000079035DDD231E
000079035ddd3629  call 0x000079035DCE3320
000079035ddd362e  jmp 0x000079035DDD2332
000079035ddd3633  call 0x000079035DCE20A0
000079035ddd3638  jmp 0x000079035DDD233C
000079035ddd363d  call 0x000079035DC09D70
000079035ddd3642  jmp 0x000079035DDD234A
000079035ddd3647  call 0x000079035DCDFBC0
000079035ddd364c  jmp 0x000079035DDD2354
000079035ddd3651  call 0x000079035DCC4740
000079035ddd3656  jmp 0x000079035DDD2368
000079035ddd365b  call 0x000079035DCB5400
000079035ddd3660  jmp 0x000079035DDD2375
000079035ddd3665  call 0x000079035DCB52F0
000079035ddd366a  jmp 0x000079035DDD2382
000079035ddd366f  call 0x000079035DCC4620
000079035ddd3674  jmp 0x000079035DDD238F
000079035ddd3679  call 0x000079035DCBD750
000079035ddd367e  jmp 0x000079035DDD239C
000079035ddd3683  call 0x000079035DCBC4E0
000079035ddd3688  jmp 0x000079035DDD23A9
000079035ddd368d  call 0x000079035DCBB270
000079035ddd3692  jmp 0x000079035DDD23B6
000079035ddd3697  call 0x000079035DCBA000
000079035ddd369c  jmp 0x000079035DDD23C3
000079035ddd36a1  call 0x000079035DCC4740
000079035ddd36a6  jmp 0x000079035DDD23D0
000079035ddd36ab  call 0x000079035DCB5400
000079035ddd36b0  jmp 0x000079035DDD23DD
000079035ddd36b5  call 0x000079035DCB52F0
000079035ddd36ba  jmp 0x000079035DDD23EA
000079035ddd36bf  call 0x000079035DCC4620
000079035ddd36c4  jmp 0x000079035DDD23F7
000079035ddd36c9  call 0x000079035DCB8D90
000079035ddd36ce  jmp 0x000079035DDD2404
000079035ddd36d3  call 0x000079035DCB8A20
000079035ddd36d8  jmp 0x000079035DDD2411
000079035ddd36dd  call 0x000079035DCB77B0
000079035ddd36e2  jmp 0x000079035DDD241B
000079035ddd36e7  call 0x000079035DCB6550
000079035ddd36ec  jmp 0x000079035DDD2425
000079035ddd36f1  call 0x000079035DCB5400
000079035ddd36f6  jmp 0x000079035DDD2437
000079035ddd36fb  call 0x000079035DCC0FC0
000079035ddd3700  jmp 0x000079035DDD2441
000079035ddd3705  call 0x000079035DCB52F0
000079035ddd370a  jmp 0x000079035DDD244B
000079035ddd370f  call 0x000079035DCC0EA0
000079035ddd3714  jmp 0x000079035DDD2455
000079035ddd3719  call 0x000079035DCBFD50
000079035ddd371e  jmp 0x000079035DDD245F
000079035ddd3723  call 0x000079035DCB8EA0
000079035ddd3728  jmp 0x000079035DDD2469
000079035ddd372d  call 0x000079035DCBFC30
000079035ddd3732  jmp 0x000079035DDD2476
000079035ddd3737  call 0x000079035DCB8D90
000079035ddd373c  jmp 0x000079035DDD2483
000079035ddd3741  call 0x000079035DCB52F0
000079035ddd3746  jmp 0x000079035DDD2496
000079035ddd374b  call 0x000079035DCB52F0
000079035ddd3750  jmp 0x000079035DDD24A9
000079035ddd3755  call 0x000079035DCC0FC0
000079035ddd375a  jmp 0x000079035DDD24B6
000079035ddd375f  call 0x000079035DCC0FC0
000079035ddd3764  jmp 0x000079035DDD24C9
000079035ddd3769  call 0x000079035DCC0EA0
000079035ddd376e  jmp 0x000079035DDD24D6
000079035ddd3773  call 0x000079035DCB52F0
000079035ddd3778  jmp 0x000079035DDD24E9
000079035ddd377d  call 0x000079035DCB52F0
000079035ddd3782  jmp 0x000079035DDD24FC
000079035ddd3787  call 0x000079035DCB52F0
000079035ddd378c  jmp 0x000079035DDD250F
000079035ddd3791  call 0x000079035DCB52F0
000079035ddd3796  jmp 0x000079035DDD252A
000079035ddd379b  call 0x000079035DCB52F0
000079035ddd37a0  jmp 0x000079035DDD253D
000079035ddd37a5  call 0x000079035DCB5400
000079035ddd37aa  jmp 0x000079035DDD257E
000079035ddd37af  call 0x000079035DCC0FC0
000079035ddd37b4  jmp 0x000079035DDD258B
000079035ddd37b9  call 0x000079035DCB52F0
000079035ddd37be  jmp 0x000079035DDD2598
000079035ddd37c3  call 0x000079035DCC0EA0
000079035ddd37c8  jmp 0x000079035DDD25A5
000079035ddd37cd  call 0x000079035DBFF540
000079035ddd37d2  jmp 0x000079035DDD25C3
000079035ddd37d7  call 0x000079035DC08C20
000079035ddd37dc  jmp 0x000079035DDD25CD
000079035ddd37e1  call 0x000079035DCE21C0
000079035ddd37e6  jmp 0x000079035DDD25D3
000079035ddd37eb  call 0x000079035DBFF540
000079035ddd37f0  jmp 0x000079035DDD25E3
000079035ddd37f5  call 0x000079035DCC0370
000079035ddd37fa  jmp 0x000079035DDD2611
000079035ddd37ff  call 0x000079035DCBF100
000079035ddd3804  jmp 0x000079035DDD261A
000079035ddd3809  call 0x000079035DCC0370
000079035ddd380e  jmp 0x000079035DDD2674
000079035ddd3813  call 0x000079035DCBF100
000079035ddd3818  jmp 0x000079035DDD267D
000079035ddd381d  call 0x000079035DCC0370
000079035ddd3822  jmp 0x000079035DDD26C6
000079035ddd3827  call 0x000079035DCBF100
000079035ddd382c  jmp 0x000079035DDD26CF
000079035ddd3831  call 0x000079035DC0B720
000079035ddd3836  jmp 0x000079035DDD2714
000079035ddd383b  call 0x000079035DCB47C0
000079035ddd3840  jmp 0x000079035DDD2727
000079035ddd3845  call 0x000079035DC08B00
000079035ddd384a  jmp 0x000079035DDD273E
000079035ddd384f  call 0x000079035DBFF430
000079035ddd3854  jmp 0x000079035DDD2751
000079035ddd3859  call 0x000079035DBFF430
000079035ddd385e  jmp 0x000079035DDD2764
000079035ddd3863  sub rsp, 0x08
000079035ddd3867  push rax
000079035ddd3868  push rcx
000079035ddd3869  push rdx
000079035ddd386a  push rdi
000079035ddd386b  push rsi
000079035ddd386c  push r8
000079035ddd386e  push r9
000079035ddd3870  push r10
000079035ddd3872  push r11
000079035ddd3874  sub rsp, 0xF0
000079035ddd387b  vmovaps [rsp], xmm0
000079035ddd3880  vmovaps [rsp+0x10], xmm2
000079035ddd3886  vmovaps [rsp+0x20], xmm3
000079035ddd388c  vmovaps [rsp+0x30], xmm4
000079035ddd3892  vmovaps [rsp+0x40], xmm5
000079035ddd3898  vmovaps [rsp+0x50], xmm6
000079035ddd389e  vmovaps [rsp+0x60], xmm7
000079035ddd38a4  vmovaps [rsp+0x70], xmm8
000079035ddd38aa  vmovaps [rsp+0x80], xmm9
000079035ddd38b3  vmovaps [rsp+0x90], xmm10
000079035ddd38bc  vmovaps [rsp+0xA0], xmm11
000079035ddd38c5  vmovaps [rsp+0xB0], xmm12
000079035ddd38ce  vmovaps [rsp+0xC0], xmm13
000079035ddd38d7  vmovaps [rsp+0xD0], xmm14
000079035ddd38e0  vmovaps [rsp+0xE0], xmm15
000079035ddd38e9  sub rsp, 0x30
000079035ddd38ed  movaps [rsp], xmm1
000079035ddd38f1  movaps [rsp+0x10], xmm12
000079035ddd38f7  movaps [rsp+0x20], xmm15
000079035ddd38fd  lea rdi, [rsp]
000079035ddd3901  mov esi, 0x00
000079035ddd3906  mov rax, 0x64ACAA8B0530
000079035ddd3910  call rax
000079035ddd3912  movaps xmm1, [rsp]
000079035ddd3916  add rsp, 0x30
000079035ddd391a  vmovaps xmm0, [rsp]
000079035ddd391f  vmovaps xmm2, [rsp+0x10]
000079035ddd3925  vmovaps xmm3, [rsp+0x20]
000079035ddd392b  vmovaps xmm4, [rsp+0x30]
000079035ddd3931  vmovaps xmm5, [rsp+0x40]
000079035ddd3937  vmovaps xmm6, [rsp+0x50]
000079035ddd393d  vmovaps xmm7, [rsp+0x60]
000079035ddd3943  vmovaps xmm8, [rsp+0x70]
000079035ddd3949  vmovaps xmm9, [rsp+0x80]
000079035ddd3952  vmovaps xmm10, [rsp+0x90]
000079035ddd395b  vmovaps xmm11, [rsp+0xA0]
000079035ddd3964  vmovaps xmm12, [rsp+0xB0]
000079035ddd396d  vmovaps xmm13, [rsp+0xC0]
000079035ddd3976  vmovaps xmm14, [rsp+0xD0]
000079035ddd397f  vmovaps xmm15, [rsp+0xE0]
000079035ddd3988  add rsp, 0xF0
000079035ddd398f  pop r11
000079035ddd3991  pop r10
000079035ddd3993  pop r9
000079035ddd3995  pop r8
000079035ddd3997  pop rsi
000079035ddd3998  pop rdi
000079035ddd3999  pop rdx
000079035ddd399a  pop rcx
000079035ddd399b  pop rax
000079035ddd399c  add rsp, 0x08
000079035ddd39a0  jmp 0x000079035DDD27B2
000079035ddd39a5  sub rsp, 0x08
000079035ddd39a9  push rax
000079035ddd39aa  push rcx
000079035ddd39ab  push rdx
000079035ddd39ac  push rdi
000079035ddd39ad  push rsi
000079035ddd39ae  push r8
000079035ddd39b0  push r9
000079035ddd39b2  push r10
000079035ddd39b4  push r11
000079035ddd39b6  sub rsp, 0xF0
000079035ddd39bd  vmovaps [rsp], xmm0
000079035ddd39c2  vmovaps [rsp+0x10], xmm1
000079035ddd39c8  vmovaps [rsp+0x20], xmm2
000079035ddd39ce  vmovaps [rsp+0x30], xmm3
000079035ddd39d4  vmovaps [rsp+0x40], xmm4
000079035ddd39da  vmovaps [rsp+0x50], xmm5
000079035ddd39e0  vmovaps [rsp+0x60], xmm6
000079035ddd39e6  vmovaps [rsp+0x70], xmm7
000079035ddd39ec  vmovaps [rsp+0x80], xmm8
000079035ddd39f5  vmovaps [rsp+0x90], xmm9
000079035ddd39fe  vmovaps [rsp+0xA0], xmm10
000079035ddd3a07  vmovaps [rsp+0xB0], xmm11
000079035ddd3a10  vmovaps [rsp+0xC0], xmm12
000079035ddd3a19  vmovaps [rsp+0xD0], xmm13
000079035ddd3a22  vmovaps [rsp+0xE0], xmm15
000079035ddd3a2b  sub rsp, 0x30
000079035ddd3a2f  movaps [rsp], xmm14
000079035ddd3a34  movaps [rsp+0x10], xmm1
000079035ddd3a39  movaps [rsp+0x20], xmm15
000079035ddd3a3f  lea rdi, [rsp]
000079035ddd3a43  mov esi, 0x00
000079035ddd3a48  mov rax, 0x64ACAA8B0530
000079035ddd3a52  call rax
000079035ddd3a54  movaps xmm14, [rsp]
000079035ddd3a59  add rsp, 0x30
000079035ddd3a5d  vmovaps xmm0, [rsp]
000079035ddd3a62  vmovaps xmm1, [rsp+0x10]
000079035ddd3a68  vmovaps xmm2, [rsp+0x20]
000079035ddd3a6e  vmovaps xmm3, [rsp+0x30]
000079035ddd3a74  vmovaps xmm4, [rsp+0x40]
000079035ddd3a7a  vmovaps xmm5, [rsp+0x50]
000079035ddd3a80  vmovaps xmm6, [rsp+0x60]
000079035ddd3a86  vmovaps xmm7, [rsp+0x70]
000079035ddd3a8c  vmovaps xmm8, [rsp+0x80]
000079035ddd3a95  vmovaps xmm9, [rsp+0x90]
000079035ddd3a9e  vmovaps xmm10, [rsp+0xA0]
000079035ddd3aa7  vmovaps xmm11, [rsp+0xB0]
000079035ddd3ab0  vmovaps xmm12, [rsp+0xC0]
000079035ddd3ab9  vmovaps xmm13, [rsp+0xD0]
000079035ddd3ac2  vmovaps xmm15, [rsp+0xE0]
000079035ddd3acb  add rsp, 0xF0
000079035ddd3ad2  pop r11
000079035ddd3ad4  pop r10
000079035ddd3ad6  pop r9
000079035ddd3ad8  pop r8
000079035ddd3ada  pop rsi
000079035ddd3adb  pop rdi
000079035ddd3adc  pop rdx
000079035ddd3add  pop rcx
000079035ddd3ade  pop rax
000079035ddd3adf  add rsp, 0x08
000079035ddd3ae3  jmp 0x000079035DDD2800
000079035ddd3ae8  sub rsp, 0x08
000079035ddd3aec  push rax
000079035ddd3aed  push rcx
000079035ddd3aee  push rdx
000079035ddd3aef  push rdi
000079035ddd3af0  push rsi
000079035ddd3af1  push r8
000079035ddd3af3  push r9
000079035ddd3af5  push r10
000079035ddd3af7  push r11
000079035ddd3af9  sub rsp, 0xF0
000079035ddd3b00  vmovaps [rsp], xmm0
000079035ddd3b05  vmovaps [rsp+0x10], xmm1
000079035ddd3b0b  vmovaps [rsp+0x20], xmm2
000079035ddd3b11  vmovaps [rsp+0x30], xmm3
000079035ddd3b17  vmovaps [rsp+0x40], xmm4
000079035ddd3b1d  vmovaps [rsp+0x50], xmm5
000079035ddd3b23  vmovaps [rsp+0x60], xmm6
000079035ddd3b29  vmovaps [rsp+0x70], xmm7
000079035ddd3b2f  vmovaps [rsp+0x80], xmm8
000079035ddd3b38  vmovaps [rsp+0x90], xmm9
000079035ddd3b41  vmovaps [rsp+0xA0], xmm10
000079035ddd3b4a  vmovaps [rsp+0xB0], xmm11
000079035ddd3b53  vmovaps [rsp+0xC0], xmm12
000079035ddd3b5c  vmovaps [rsp+0xD0], xmm13
000079035ddd3b65  vmovaps [rsp+0xE0], xmm14
000079035ddd3b6e  sub rsp, 0x30
000079035ddd3b72  movaps [rsp], xmm15
000079035ddd3b77  movaps [rsp+0x10], xmm12
000079035ddd3b7d  movaps [rsp+0x20], xmm13
000079035ddd3b83  lea rdi, [rsp]
000079035ddd3b87  mov esi, 0x00
000079035ddd3b8c  mov rax, 0x64ACAA8B0530
000079035ddd3b96  call rax
000079035ddd3b98  movaps xmm15, [rsp]
000079035ddd3b9d  add rsp, 0x30
000079035ddd3ba1  vmovaps xmm0, [rsp]
000079035ddd3ba6  vmovaps xmm1, [rsp+0x10]
000079035ddd3bac  vmovaps xmm2, [rsp+0x20]
000079035ddd3bb2  vmovaps xmm3, [rsp+0x30]
000079035ddd3bb8  vmovaps xmm4, [rsp+0x40]
000079035ddd3bbe  vmovaps xmm5, [rsp+0x50]
000079035ddd3bc4  vmovaps xmm6, [rsp+0x60]
000079035ddd3bca  vmovaps xmm7, [rsp+0x70]
000079035ddd3bd0  vmovaps xmm8, [rsp+0x80]
000079035ddd3bd9  vmovaps xmm9, [rsp+0x90]
000079035ddd3be2  vmovaps xmm10, [rsp+0xA0]
000079035ddd3beb  vmovaps xmm11, [rsp+0xB0]
000079035ddd3bf4  vmovaps xmm12, [rsp+0xC0]
000079035ddd3bfd  vmovaps xmm13, [rsp+0xD0]
000079035ddd3c06  vmovaps xmm14, [rsp+0xE0]
000079035ddd3c0f  add rsp, 0xF0
000079035ddd3c16  pop r11
000079035ddd3c18  pop r10
000079035ddd3c1a  pop r9
000079035ddd3c1c  pop r8
000079035ddd3c1e  pop rsi
000079035ddd3c1f  pop rdi
000079035ddd3c20  pop rdx
000079035ddd3c21  pop rcx
000079035ddd3c22  pop rax
000079035ddd3c23  add rsp, 0x08
000079035ddd3c27  jmp 0x000079035DDD2835
000079035ddd3c2c  sub rsp, 0x08
000079035ddd3c30  push rax
000079035ddd3c31  push rcx
000079035ddd3c32  push rdx
000079035ddd3c33  push rdi
000079035ddd3c34  push rsi
000079035ddd3c35  push r8
000079035ddd3c37  push r9
000079035ddd3c39  push r10
000079035ddd3c3b  push r11
000079035ddd3c3d  sub rsp, 0xF0
000079035ddd3c44  vmovaps [rsp], xmm0
000079035ddd3c49  vmovaps [rsp+0x10], xmm2
000079035ddd3c4f  vmovaps [rsp+0x20], xmm3
000079035ddd3c55  vmovaps [rsp+0x30], xmm4
000079035ddd3c5b  vmovaps [rsp+0x40], xmm5
000079035ddd3c61  vmovaps [rsp+0x50], xmm6
000079035ddd3c67  vmovaps [rsp+0x60], xmm7
000079035ddd3c6d  vmovaps [rsp+0x70], xmm8
000079035ddd3c73  vmovaps [rsp+0x80], xmm9
000079035ddd3c7c  vmovaps [rsp+0x90], xmm10
000079035ddd3c85  vmovaps [rsp+0xA0], xmm11
000079035ddd3c8e  vmovaps [rsp+0xB0], xmm12
000079035ddd3c97  vmovaps [rsp+0xC0], xmm13
000079035ddd3ca0  vmovaps [rsp+0xD0], xmm14
000079035ddd3ca9  vmovaps [rsp+0xE0], xmm15
000079035ddd3cb2  sub rsp, 0x30
000079035ddd3cb6  movaps [rsp], xmm1
000079035ddd3cba  movaps [rsp+0x10], xmm12
000079035ddd3cc0  movaps [rsp+0x20], xmm10
000079035ddd3cc6  lea rdi, [rsp]
000079035ddd3cca  mov esi, 0x00
000079035ddd3ccf  mov rax, 0x64ACAA8B0530
000079035ddd3cd9  call rax
000079035ddd3cdb  movaps xmm1, [rsp]
000079035ddd3cdf  add rsp, 0x30
000079035ddd3ce3  vmovaps xmm0, [rsp]
000079035ddd3ce8  vmovaps xmm2, [rsp+0x10]
000079035ddd3cee  vmovaps xmm3, [rsp+0x20]
000079035ddd3cf4  vmovaps xmm4, [rsp+0x30]
000079035ddd3cfa  vmovaps xmm5, [rsp+0x40]
000079035ddd3d00  vmovaps xmm6, [rsp+0x50]
000079035ddd3d06  vmovaps xmm7, [rsp+0x60]
000079035ddd3d0c  vmovaps xmm8, [rsp+0x70]
000079035ddd3d12  vmovaps xmm9, [rsp+0x80]
000079035ddd3d1b  vmovaps xmm10, [rsp+0x90]
000079035ddd3d24  vmovaps xmm11, [rsp+0xA0]
000079035ddd3d2d  vmovaps xmm12, [rsp+0xB0]
000079035ddd3d36  vmovaps xmm13, [rsp+0xC0]
000079035ddd3d3f  vmovaps xmm14, [rsp+0xD0]
000079035ddd3d48  vmovaps xmm15, [rsp+0xE0]
000079035ddd3d51  add rsp, 0xF0
000079035ddd3d58  pop r11
000079035ddd3d5a  pop r10
000079035ddd3d5c  pop r9
000079035ddd3d5e  pop r8
000079035ddd3d60  pop rsi
000079035ddd3d61  pop rdi
000079035ddd3d62  pop rdx
000079035ddd3d63  pop rcx
000079035ddd3d64  pop rax
000079035ddd3d65  add rsp, 0x08
000079035ddd3d69  jmp 0x000079035DDD284F
000079035ddd3d6e  sub rsp, 0x08
000079035ddd3d72  push rax
000079035ddd3d73  push rcx
000079035ddd3d74  push rdx
000079035ddd3d75  push rdi
000079035ddd3d76  push rsi
000079035ddd3d77  push r8
000079035ddd3d79  push r9
000079035ddd3d7b  push r10
000079035ddd3d7d  push r11
000079035ddd3d7f  sub rsp, 0xF0
000079035ddd3d86  vmovaps [rsp], xmm0
000079035ddd3d8b  vmovaps [rsp+0x10], xmm1
000079035ddd3d91  vmovaps [rsp+0x20], xmm2
000079035ddd3d97  vmovaps [rsp+0x30], xmm3
000079035ddd3d9d  vmovaps [rsp+0x40], xmm4
000079035ddd3da3  vmovaps [rsp+0x50], xmm5
000079035ddd3da9  vmovaps [rsp+0x60], xmm6
000079035ddd3daf  vmovaps [rsp+0x70], xmm7
000079035ddd3db5  vmovaps [rsp+0x80], xmm8
000079035ddd3dbe  vmovaps [rsp+0x90], xmm9
000079035ddd3dc7  vmovaps [rsp+0xA0], xmm10
000079035ddd3dd0  vmovaps [rsp+0xB0], xmm11
000079035ddd3dd9  vmovaps [rsp+0xC0], xmm12
000079035ddd3de2  vmovaps [rsp+0xD0], xmm14
000079035ddd3deb  vmovaps [rsp+0xE0], xmm15
000079035ddd3df4  sub rsp, 0x30
000079035ddd3df8  movaps [rsp], xmm13
000079035ddd3dfd  movaps [rsp+0x10], xmm12
000079035ddd3e03  movaps [rsp+0x20], xmm2
000079035ddd3e08  lea rdi, [rsp]
000079035ddd3e0c  mov esi, 0x00
000079035ddd3e11  mov rax, 0x64ACAA8B0530
000079035ddd3e1b  call rax
000079035ddd3e1d  movaps xmm13, [rsp]
000079035ddd3e22  add rsp, 0x30
000079035ddd3e26  vmovaps xmm0, [rsp]
000079035ddd3e2b  vmovaps xmm1, [rsp+0x10]
000079035ddd3e31  vmovaps xmm2, [rsp+0x20]
000079035ddd3e37  vmovaps xmm3, [rsp+0x30]
000079035ddd3e3d  vmovaps xmm4, [rsp+0x40]
000079035ddd3e43  vmovaps xmm5, [rsp+0x50]
000079035ddd3e49  vmovaps xmm6, [rsp+0x60]
000079035ddd3e4f  vmovaps xmm7, [rsp+0x70]
000079035ddd3e55  vmovaps xmm8, [rsp+0x80]
000079035ddd3e5e  vmovaps xmm9, [rsp+0x90]
000079035ddd3e67  vmovaps xmm10, [rsp+0xA0]
000079035ddd3e70  vmovaps xmm11, [rsp+0xB0]
000079035ddd3e79  vmovaps xmm12, [rsp+0xC0]
000079035ddd3e82  vmovaps xmm14, [rsp+0xD0]
000079035ddd3e8b  vmovaps xmm15, [rsp+0xE0]
000079035ddd3e94  add rsp, 0xF0
000079035ddd3e9b  pop r11
000079035ddd3e9d  pop r10
000079035ddd3e9f  pop r9
000079035ddd3ea1  pop r8
000079035ddd3ea3  pop rsi
000079035ddd3ea4  pop rdi
000079035ddd3ea5  pop rdx
000079035ddd3ea6  pop rcx
000079035ddd3ea7  pop rax
000079035ddd3ea8  add rsp, 0x08
000079035ddd3eac  jmp 0x000079035DDD286A
000079035ddd3eb1  sub rsp, 0x08
000079035ddd3eb5  push rax
000079035ddd3eb6  push rcx
000079035ddd3eb7  push rdx
000079035ddd3eb8  push rdi
000079035ddd3eb9  push rsi
000079035ddd3eba  push r8
000079035ddd3ebc  push r9
000079035ddd3ebe  push r10
000079035ddd3ec0  push r11
000079035ddd3ec2  sub rsp, 0xF0
000079035ddd3ec9  vmovaps [rsp], xmm0
000079035ddd3ece  vmovaps [rsp+0x10], xmm2
000079035ddd3ed4  vmovaps [rsp+0x20], xmm3
000079035ddd3eda  vmovaps [rsp+0x30], xmm4
000079035ddd3ee0  vmovaps [rsp+0x40], xmm5
000079035ddd3ee6  vmovaps [rsp+0x50], xmm6
000079035ddd3eec  vmovaps [rsp+0x60], xmm7
000079035ddd3ef2  vmovaps [rsp+0x70], xmm8
000079035ddd3ef8  vmovaps [rsp+0x80], xmm9
000079035ddd3f01  vmovaps [rsp+0x90], xmm10
000079035ddd3f0a  vmovaps [rsp+0xA0], xmm11
000079035ddd3f13  vmovaps [rsp+0xB0], xmm12
000079035ddd3f1c  vmovaps [rsp+0xC0], xmm13
000079035ddd3f25  vmovaps [rsp+0xD0], xmm14
000079035ddd3f2e  vmovaps [rsp+0xE0], xmm15
000079035ddd3f37  sub rsp, 0x30
000079035ddd3f3b  movaps [rsp], xmm1
000079035ddd3f3f  movaps [rsp+0x10], xmm10
000079035ddd3f45  movaps [rsp+0x20], xmm2
000079035ddd3f4a  lea rdi, [rsp]
000079035ddd3f4e  mov esi, 0x00
000079035ddd3f53  mov rax, 0x64ACAA8B0530
000079035ddd3f5d  call rax
000079035ddd3f5f  movaps xmm1, [rsp]
000079035ddd3f63  add rsp, 0x30
000079035ddd3f67  vmovaps xmm0, [rsp]
000079035ddd3f6c  vmovaps xmm2, [rsp+0x10]
000079035ddd3f72  vmovaps xmm3, [rsp+0x20]
000079035ddd3f78  vmovaps xmm4, [rsp+0x30]
000079035ddd3f7e  vmovaps xmm5, [rsp+0x40]
000079035ddd3f84  vmovaps xmm6, [rsp+0x50]
000079035ddd3f8a  vmovaps xmm7, [rsp+0x60]
000079035ddd3f90  vmovaps xmm8, [rsp+0x70]
000079035ddd3f96  vmovaps xmm9, [rsp+0x80]
000079035ddd3f9f  vmovaps xmm10, [rsp+0x90]
000079035ddd3fa8  vmovaps xmm11, [rsp+0xA0]
000079035ddd3fb1  vmovaps xmm12, [rsp+0xB0]
000079035ddd3fba  vmovaps xmm13, [rsp+0xC0]
000079035ddd3fc3  vmovaps xmm14, [rsp+0xD0]
000079035ddd3fcc  vmovaps xmm15, [rsp+0xE0]
000079035ddd3fd5  add rsp, 0xF0
000079035ddd3fdc  pop r11
000079035ddd3fde  pop r10
000079035ddd3fe0  pop r9
000079035ddd3fe2  pop r8
000079035ddd3fe4  pop rsi
000079035ddd3fe5  pop rdi
000079035ddd3fe6  pop rdx
000079035ddd3fe7  pop rcx
000079035ddd3fe8  pop rax
000079035ddd3fe9  add rsp, 0x08
000079035ddd3fed  jmp 0x000079035DDD28D2
000079035ddd3ff2  sub rsp, 0x08
000079035ddd3ff6  push rax
000079035ddd3ff7  push rcx
000079035ddd3ff8  push rdx
000079035ddd3ff9  push rdi
000079035ddd3ffa  push rsi
000079035ddd3ffb  push r8
000079035ddd3ffd  push r9
000079035ddd3fff  push r10
000079035ddd4001  push r11
000079035ddd4003  sub rsp, 0xF0
000079035ddd400a  vmovaps [rsp], xmm0
000079035ddd400f  vmovaps [rsp+0x10], xmm1
000079035ddd4015  vmovaps [rsp+0x20], xmm2
000079035ddd401b  vmovaps [rsp+0x30], xmm3
000079035ddd4021  vmovaps [rsp+0x40], xmm4
000079035ddd4027  vmovaps [rsp+0x50], xmm5
000079035ddd402d  vmovaps [rsp+0x60], xmm6
000079035ddd4033  vmovaps [rsp+0x70], xmm7
000079035ddd4039  vmovaps [rsp+0x80], xmm8
000079035ddd4042  vmovaps [rsp+0x90], xmm9
000079035ddd404b  vmovaps [rsp+0xA0], xmm10
000079035ddd4054  vmovaps [rsp+0xB0], xmm11
000079035ddd405d  vmovaps [rsp+0xC0], xmm12
000079035ddd4066  vmovaps [rsp+0xD0], xmm13
000079035ddd406f  vmovaps [rsp+0xE0], xmm14
000079035ddd4078  sub rsp, 0x30
000079035ddd407c  movaps [rsp], xmm15
000079035ddd4081  movaps [rsp+0x10], xmm10
000079035ddd4087  movaps [rsp+0x20], xmm2
000079035ddd408c  lea rdi, [rsp]
000079035ddd4090  mov esi, 0x00
000079035ddd4095  mov rax, 0x64ACAA8B0530
000079035ddd409f  call rax
000079035ddd40a1  movaps xmm15, [rsp]
000079035ddd40a6  add rsp, 0x30
000079035ddd40aa  vmovaps xmm0, [rsp]
000079035ddd40af  vmovaps xmm1, [rsp+0x10]
000079035ddd40b5  vmovaps xmm2, [rsp+0x20]
000079035ddd40bb  vmovaps xmm3, [rsp+0x30]
000079035ddd40c1  vmovaps xmm4, [rsp+0x40]
000079035ddd40c7  vmovaps xmm5, [rsp+0x50]
000079035ddd40cd  vmovaps xmm6, [rsp+0x60]
000079035ddd40d3  vmovaps xmm7, [rsp+0x70]
000079035ddd40d9  vmovaps xmm8, [rsp+0x80]
000079035ddd40e2  vmovaps xmm9, [rsp+0x90]
000079035ddd40eb  vmovaps xmm10, [rsp+0xA0]
000079035ddd40f4  vmovaps xmm11, [rsp+0xB0]
000079035ddd40fd  vmovaps xmm12, [rsp+0xC0]
000079035ddd4106  vmovaps xmm13, [rsp+0xD0]
000079035ddd410f  vmovaps xmm14, [rsp+0xE0]
000079035ddd4118  add rsp, 0xF0
000079035ddd411f  pop r11
000079035ddd4121  pop r10
000079035ddd4123  pop r9
000079035ddd4125  pop r8
000079035ddd4127  pop rsi
000079035ddd4128  pop rdi
000079035ddd4129  pop rdx
000079035ddd412a  pop rcx
000079035ddd412b  pop rax
000079035ddd412c  add rsp, 0x08
000079035ddd4130  jmp 0x000079035DDD2924
000079035ddd4135  sub rsp, 0x08
000079035ddd4139  push rax
000079035ddd413a  push rcx
000079035ddd413b  push rdx
000079035ddd413c  push rdi
000079035ddd413d  push rsi
000079035ddd413e  push r8
000079035ddd4140  push r9
000079035ddd4142  push r10
000079035ddd4144  push r11
000079035ddd4146  sub rsp, 0xF0
000079035ddd414d  vmovaps [rsp], xmm0
000079035ddd4152  vmovaps [rsp+0x10], xmm2
000079035ddd4158  vmovaps [rsp+0x20], xmm3
000079035ddd415e  vmovaps [rsp+0x30], xmm4
000079035ddd4164  vmovaps [rsp+0x40], xmm5
000079035ddd416a  vmovaps [rsp+0x50], xmm6
000079035ddd4170  vmovaps [rsp+0x60], xmm7
000079035ddd4176  vmovaps [rsp+0x70], xmm8
000079035ddd417c  vmovaps [rsp+0x80], xmm9
000079035ddd4185  vmovaps [rsp+0x90], xmm10
000079035ddd418e  vmovaps [rsp+0xA0], xmm11
000079035ddd4197  vmovaps [rsp+0xB0], xmm12
000079035ddd41a0  vmovaps [rsp+0xC0], xmm13
000079035ddd41a9  vmovaps [rsp+0xD0], xmm14
000079035ddd41b2  vmovaps [rsp+0xE0], xmm15
000079035ddd41bb  sub rsp, 0x30
000079035ddd41bf  movaps [rsp], xmm1
000079035ddd41c3  movaps [rsp+0x10], xmm10
000079035ddd41c9  movaps [rsp+0x20], xmm15
000079035ddd41cf  lea rdi, [rsp]
000079035ddd41d3  mov esi, 0x00
000079035ddd41d8  mov rax, 0x64ACAA8B0530
000079035ddd41e2  call rax
000079035ddd41e4  movaps xmm1, [rsp]
000079035ddd41e8  add rsp, 0x30
000079035ddd41ec  vmovaps xmm0, [rsp]
000079035ddd41f1  vmovaps xmm2, [rsp+0x10]
000079035ddd41f7  vmovaps xmm3, [rsp+0x20]
000079035ddd41fd  vmovaps xmm4, [rsp+0x30]
000079035ddd4203  vmovaps xmm5, [rsp+0x40]
000079035ddd4209  vmovaps xmm6, [rsp+0x50]
000079035ddd420f  vmovaps xmm7, [rsp+0x60]
000079035ddd4215  vmovaps xmm8, [rsp+0x70]
000079035ddd421b  vmovaps xmm9, [rsp+0x80]
000079035ddd4224  vmovaps xmm10, [rsp+0x90]
000079035ddd422d  vmovaps xmm11, [rsp+0xA0]
000079035ddd4236  vmovaps xmm12, [rsp+0xB0]
000079035ddd423f  vmovaps xmm13, [rsp+0xC0]
000079035ddd4248  vmovaps xmm14, [rsp+0xD0]
000079035ddd4251  vmovaps xmm15, [rsp+0xE0]
000079035ddd425a  add rsp, 0xF0
000079035ddd4261  pop r11
000079035ddd4263  pop r10
000079035ddd4265  pop r9
000079035ddd4267  pop r8
000079035ddd4269  pop rsi
000079035ddd426a  pop rdi
000079035ddd426b  pop rdx
000079035ddd426c  pop rcx
000079035ddd426d  pop rax
000079035ddd426e  add rsp, 0x08
000079035ddd4272  jmp 0x000079035DDD2962
000079035ddd4277  sub rsp, 0x08
000079035ddd427b  push rax
000079035ddd427c  push rcx
000079035ddd427d  push rdx
000079035ddd427e  push rdi
000079035ddd427f  push rsi
000079035ddd4280  push r8
000079035ddd4282  push r9
000079035ddd4284  push r10
000079035ddd4286  push r11
000079035ddd4288  sub rsp, 0xF0
000079035ddd428f  vmovaps [rsp], xmm0
000079035ddd4294  vmovaps [rsp+0x10], xmm1
000079035ddd429a  vmovaps [rsp+0x20], xmm2
000079035ddd42a0  vmovaps [rsp+0x30], xmm3
000079035ddd42a6  vmovaps [rsp+0x40], xmm4
000079035ddd42ac  vmovaps [rsp+0x50], xmm5
000079035ddd42b2  vmovaps [rsp+0x60], xmm6
000079035ddd42b8  vmovaps [rsp+0x70], xmm7
000079035ddd42be  vmovaps [rsp+0x80], xmm8
000079035ddd42c7  vmovaps [rsp+0x90], xmm9
000079035ddd42d0  vmovaps [rsp+0xA0], xmm10
000079035ddd42d9  vmovaps [rsp+0xB0], xmm11
000079035ddd42e2  vmovaps [rsp+0xC0], xmm12
000079035ddd42eb  vmovaps [rsp+0xD0], xmm13
000079035ddd42f4  vmovaps [rsp+0xE0], xmm15
000079035ddd42fd  sub rsp, 0x30
000079035ddd4301  movaps [rsp], xmm14
000079035ddd4306  movaps [rsp+0x10], xmm10
000079035ddd430c  movaps [rsp+0x20], xmm15
000079035ddd4312  lea rdi, [rsp]
000079035ddd4316  mov esi, 0x00
000079035ddd431b  mov rax, 0x64ACAA8B0530
000079035ddd4325  call rax
000079035ddd4327  movaps xmm14, [rsp]
000079035ddd432c  add rsp, 0x30
000079035ddd4330  vmovaps xmm0, [rsp]
000079035ddd4335  vmovaps xmm1, [rsp+0x10]
000079035ddd433b  vmovaps xmm2, [rsp+0x20]
000079035ddd4341  vmovaps xmm3, [rsp+0x30]
000079035ddd4347  vmovaps xmm4, [rsp+0x40]
000079035ddd434d  vmovaps xmm5, [rsp+0x50]
000079035ddd4353  vmovaps xmm6, [rsp+0x60]
000079035ddd4359  vmovaps xmm7, [rsp+0x70]
000079035ddd435f  vmovaps xmm8, [rsp+0x80]
000079035ddd4368  vmovaps xmm9, [rsp+0x90]
000079035ddd4371  vmovaps xmm10, [rsp+0xA0]
000079035ddd437a  vmovaps xmm11, [rsp+0xB0]
000079035ddd4383  vmovaps xmm12, [rsp+0xC0]
000079035ddd438c  vmovaps xmm13, [rsp+0xD0]
000079035ddd4395  vmovaps xmm15, [rsp+0xE0]
000079035ddd439e  add rsp, 0xF0
000079035ddd43a5  pop r11
000079035ddd43a7  pop r10
000079035ddd43a9  pop r9
000079035ddd43ab  pop r8
000079035ddd43ad  pop rsi
000079035ddd43ae  pop rdi
000079035ddd43af  pop rdx
000079035ddd43b0  pop rcx
000079035ddd43b1  pop rax
000079035ddd43b2  add rsp, 0x08
000079035ddd43b6  jmp 0x000079035DDD298E
000079035ddd43bb  call 0x000079035DBFF430
000079035ddd43c0  jmp 0x000079035DDD2A1E
000079035ddd43c5  call 0x000079035DBFF430
000079035ddd43ca  jmp 0x000079035DDD2A31
000079035ddd43cf  sub rsp, 0x08
000079035ddd43d3  push rax
000079035ddd43d4  push rcx
000079035ddd43d5  push rdx
000079035ddd43d6  push rdi
000079035ddd43d7  push rsi
000079035ddd43d8  push r8
000079035ddd43da  push r9
000079035ddd43dc  push r10
000079035ddd43de  push r11
000079035ddd43e0  sub rsp, 0xF0
000079035ddd43e7  vmovaps [rsp], xmm0
000079035ddd43ec  vmovaps [rsp+0x10], xmm2
000079035ddd43f2  vmovaps [rsp+0x20], xmm3
000079035ddd43f8  vmovaps [rsp+0x30], xmm4
000079035ddd43fe  vmovaps [rsp+0x40], xmm5
000079035ddd4404  vmovaps [rsp+0x50], xmm6
000079035ddd440a  vmovaps [rsp+0x60], xmm7
000079035ddd4410  vmovaps [rsp+0x70], xmm8
000079035ddd4416  vmovaps [rsp+0x80], xmm9
000079035ddd441f  vmovaps [rsp+0x90], xmm10
000079035ddd4428  vmovaps [rsp+0xA0], xmm11
000079035ddd4431  vmovaps [rsp+0xB0], xmm12
000079035ddd443a  vmovaps [rsp+0xC0], xmm13
000079035ddd4443  vmovaps [rsp+0xD0], xmm14
000079035ddd444c  vmovaps [rsp+0xE0], xmm15
000079035ddd4455  sub rsp, 0x30
000079035ddd4459  movaps [rsp], xmm1
000079035ddd445d  movaps [rsp+0x10], xmm13
000079035ddd4463  movaps [rsp+0x20], xmm2
000079035ddd4468  lea rdi, [rsp]
000079035ddd446c  mov esi, 0x00
000079035ddd4471  mov rax, 0x64ACAA8B0530
000079035ddd447b  call rax
000079035ddd447d  movaps xmm1, [rsp]
000079035ddd4481  add rsp, 0x30
000079035ddd4485  vmovaps xmm0, [rsp]
000079035ddd448a  vmovaps xmm2, [rsp+0x10]
000079035ddd4490  vmovaps xmm3, [rsp+0x20]
000079035ddd4496  vmovaps xmm4, [rsp+0x30]
000079035ddd449c  vmovaps xmm5, [rsp+0x40]
000079035ddd44a2  vmovaps xmm6, [rsp+0x50]
000079035ddd44a8  vmovaps xmm7, [rsp+0x60]
000079035ddd44ae  vmovaps xmm8, [rsp+0x70]
000079035ddd44b4  vmovaps xmm9, [rsp+0x80]
000079035ddd44bd  vmovaps xmm10, [rsp+0x90]
000079035ddd44c6  vmovaps xmm11, [rsp+0xA0]
000079035ddd44cf  vmovaps xmm12, [rsp+0xB0]
000079035ddd44d8  vmovaps xmm13, [rsp+0xC0]
000079035ddd44e1  vmovaps xmm14, [rsp+0xD0]
000079035ddd44ea  vmovaps xmm15, [rsp+0xE0]
000079035ddd44f3  add rsp, 0xF0
000079035ddd44fa  pop r11
000079035ddd44fc  pop r10
000079035ddd44fe  pop r9
000079035ddd4500  pop r8
000079035ddd4502  pop rsi
000079035ddd4503  pop rdi
000079035ddd4504  pop rdx
000079035ddd4505  pop rcx
000079035ddd4506  pop rax
000079035ddd4507  add rsp, 0x08
000079035ddd450b  jmp 0x000079035DDD2A5C
000079035ddd4510  call 0x000079035DC0E760
000079035ddd4515  jmp 0x000079035DDD2A69
000079035ddd451a  sub rsp, 0x08
000079035ddd451e  push rax
000079035ddd451f  push rcx
000079035ddd4520  push rdx
000079035ddd4521  push rdi
000079035ddd4522  push rsi
000079035ddd4523  push r8
000079035ddd4525  push r9
000079035ddd4527  push r10
000079035ddd4529  push r11
000079035ddd452b  sub rsp, 0xF0
000079035ddd4532  vmovaps [rsp], xmm0
000079035ddd4537  vmovaps [rsp+0x10], xmm1
000079035ddd453d  vmovaps [rsp+0x20], xmm2
000079035ddd4543  vmovaps [rsp+0x30], xmm3
000079035ddd4549  vmovaps [rsp+0x40], xmm4
000079035ddd454f  vmovaps [rsp+0x50], xmm5
000079035ddd4555  vmovaps [rsp+0x60], xmm6
000079035ddd455b  vmovaps [rsp+0x70], xmm7
000079035ddd4561  vmovaps [rsp+0x80], xmm8
000079035ddd456a  vmovaps [rsp+0x90], xmm9
000079035ddd4573  vmovaps [rsp+0xA0], xmm10
000079035ddd457c  vmovaps [rsp+0xB0], xmm11
000079035ddd4585  vmovaps [rsp+0xC0], xmm12
000079035ddd458e  vmovaps [rsp+0xD0], xmm14
000079035ddd4597  vmovaps [rsp+0xE0], xmm15
000079035ddd45a0  sub rsp, 0x30
000079035ddd45a4  movaps [rsp], xmm13
000079035ddd45a9  movaps [rsp+0x10], xmm2
000079035ddd45ae  movaps [rsp+0x20], xmm1
000079035ddd45b3  lea rdi, [rsp]
000079035ddd45b7  mov esi, 0x00
000079035ddd45bc  mov rax, 0x64ACAA8B0530
000079035ddd45c6  call rax
000079035ddd45c8  movaps xmm13, [rsp]
000079035ddd45cd  add rsp, 0x30
000079035ddd45d1  vmovaps xmm0, [rsp]
000079035ddd45d6  vmovaps xmm1, [rsp+0x10]
000079035ddd45dc  vmovaps xmm2, [rsp+0x20]
000079035ddd45e2  vmovaps xmm3, [rsp+0x30]
000079035ddd45e8  vmovaps xmm4, [rsp+0x40]
000079035ddd45ee  vmovaps xmm5, [rsp+0x50]
000079035ddd45f4  vmovaps xmm6, [rsp+0x60]
000079035ddd45fa  vmovaps xmm7, [rsp+0x70]
000079035ddd4600  vmovaps xmm8, [rsp+0x80]
000079035ddd4609  vmovaps xmm9, [rsp+0x90]
000079035ddd4612  vmovaps xmm10, [rsp+0xA0]
000079035ddd461b  vmovaps xmm11, [rsp+0xB0]
000079035ddd4624  vmovaps xmm12, [rsp+0xC0]
000079035ddd462d  vmovaps xmm14, [rsp+0xD0]
000079035ddd4636  vmovaps xmm15, [rsp+0xE0]
000079035ddd463f  add rsp, 0xF0
000079035ddd4646  pop r11
000079035ddd4648  pop r10
000079035ddd464a  pop r9
000079035ddd464c  pop r8
000079035ddd464e  pop rsi
000079035ddd464f  pop rdi
000079035ddd4650  pop rdx
000079035ddd4651  pop rcx
000079035ddd4652  pop rax
000079035ddd4653  add rsp, 0x08
000079035ddd4657  jmp 0x000079035DDD2AA8
000079035ddd465c  sub rsp, 0x08
000079035ddd4660  push rax
000079035ddd4661  push rcx
000079035ddd4662  push rdx
000079035ddd4663  push rdi
000079035ddd4664  push rsi
000079035ddd4665  push r8
000079035ddd4667  push r9
000079035ddd4669  push r10
000079035ddd466b  push r11
000079035ddd466d  sub rsp, 0xF0
000079035ddd4674  vmovaps [rsp], xmm0
000079035ddd4679  vmovaps [rsp+0x10], xmm2
000079035ddd467f  vmovaps [rsp+0x20], xmm3
000079035ddd4685  vmovaps [rsp+0x30], xmm4
000079035ddd468b  vmovaps [rsp+0x40], xmm5
000079035ddd4691  vmovaps [rsp+0x50], xmm6
000079035ddd4697  vmovaps [rsp+0x60], xmm7
000079035ddd469d  vmovaps [rsp+0x70], xmm8
000079035ddd46a3  vmovaps [rsp+0x80], xmm9
000079035ddd46ac  vmovaps [rsp+0x90], xmm10
000079035ddd46b5  vmovaps [rsp+0xA0], xmm11
000079035ddd46be  vmovaps [rsp+0xB0], xmm12
000079035ddd46c7  vmovaps [rsp+0xC0], xmm13
000079035ddd46d0  vmovaps [rsp+0xD0], xmm14
000079035ddd46d9  vmovaps [rsp+0xE0], xmm15
000079035ddd46e2  sub rsp, 0x30
000079035ddd46e6  movaps [rsp], xmm1
000079035ddd46ea  movaps [rsp+0x10], xmm14
000079035ddd46f0  movaps [rsp+0x20], xmm15
000079035ddd46f6  lea rdi, [rsp]
000079035ddd46fa  mov esi, 0x00
000079035ddd46ff  mov rax, 0x64ACAA8B0530
000079035ddd4709  call rax
000079035ddd470b  movaps xmm1, [rsp]
000079035ddd470f  add rsp, 0x30
000079035ddd4713  vmovaps xmm0, [rsp]
000079035ddd4718  vmovaps xmm2, [rsp+0x10]
000079035ddd471e  vmovaps xmm3, [rsp+0x20]
000079035ddd4724  vmovaps xmm4, [rsp+0x30]
000079035ddd472a  vmovaps xmm5, [rsp+0x40]
000079035ddd4730  vmovaps xmm6, [rsp+0x50]
000079035ddd4736  vmovaps xmm7, [rsp+0x60]
000079035ddd473c  vmovaps xmm8, [rsp+0x70]
000079035ddd4742  vmovaps xmm9, [rsp+0x80]
000079035ddd474b  vmovaps xmm10, [rsp+0x90]
000079035ddd4754  vmovaps xmm11, [rsp+0xA0]
000079035ddd475d  vmovaps xmm12, [rsp+0xB0]
000079035ddd4766  vmovaps xmm13, [rsp+0xC0]
000079035ddd476f  vmovaps xmm14, [rsp+0xD0]
000079035ddd4778  vmovaps xmm15, [rsp+0xE0]
000079035ddd4781  add rsp, 0xF0
000079035ddd4788  pop r11
000079035ddd478a  pop r10
000079035ddd478c  pop r9
000079035ddd478e  pop r8
000079035ddd4790  pop rsi
000079035ddd4791  pop rdi
000079035ddd4792  pop rdx
000079035ddd4793  pop rcx
000079035ddd4794  pop rax
000079035ddd4795  add rsp, 0x08
000079035ddd4799  jmp 0x000079035DDD2ACA
000079035ddd479e  sub rsp, 0x08
000079035ddd47a2  push rax
000079035ddd47a3  push rcx
000079035ddd47a4  push rdx
000079035ddd47a5  push rdi
000079035ddd47a6  push rsi
000079035ddd47a7  push r8
000079035ddd47a9  push r9
000079035ddd47ab  push r10
000079035ddd47ad  push r11
000079035ddd47af  sub rsp, 0xF0
000079035ddd47b6  vmovaps [rsp], xmm0
000079035ddd47bb  vmovaps [rsp+0x10], xmm1
000079035ddd47c1  vmovaps [rsp+0x20], xmm2
000079035ddd47c7  vmovaps [rsp+0x30], xmm3
000079035ddd47cd  vmovaps [rsp+0x40], xmm4
000079035ddd47d3  vmovaps [rsp+0x50], xmm5
000079035ddd47d9  vmovaps [rsp+0x60], xmm6
000079035ddd47df  vmovaps [rsp+0x70], xmm7
000079035ddd47e5  vmovaps [rsp+0x80], xmm8
000079035ddd47ee  vmovaps [rsp+0x90], xmm9
000079035ddd47f7  vmovaps [rsp+0xA0], xmm10
000079035ddd4800  vmovaps [rsp+0xB0], xmm11
000079035ddd4809  vmovaps [rsp+0xC0], xmm12
000079035ddd4812  vmovaps [rsp+0xD0], xmm13
000079035ddd481b  vmovaps [rsp+0xE0], xmm15
000079035ddd4824  sub rsp, 0x30
000079035ddd4828  movaps [rsp], xmm14
000079035ddd482d  movaps [rsp+0x10], xmm2
000079035ddd4832  movaps [rsp+0x20], xmm15
000079035ddd4838  lea rdi, [rsp]
000079035ddd483c  mov esi, 0x00
000079035ddd4841  mov rax, 0x64ACAA8B0530
000079035ddd484b  call rax
000079035ddd484d  movaps xmm14, [rsp]
000079035ddd4852  add rsp, 0x30
000079035ddd4856  vmovaps xmm0, [rsp]
000079035ddd485b  vmovaps xmm1, [rsp+0x10]
000079035ddd4861  vmovaps xmm2, [rsp+0x20]
000079035ddd4867  vmovaps xmm3, [rsp+0x30]
000079035ddd486d  vmovaps xmm4, [rsp+0x40]
000079035ddd4873  vmovaps xmm5, [rsp+0x50]
000079035ddd4879  vmovaps xmm6, [rsp+0x60]
000079035ddd487f  vmovaps xmm7, [rsp+0x70]
000079035ddd4885  vmovaps xmm8, [rsp+0x80]
000079035ddd488e  vmovaps xmm9, [rsp+0x90]
000079035ddd4897  vmovaps xmm10, [rsp+0xA0]
000079035ddd48a0  vmovaps xmm11, [rsp+0xB0]
000079035ddd48a9  vmovaps xmm12, [rsp+0xC0]
000079035ddd48b2  vmovaps xmm13, [rsp+0xD0]
000079035ddd48bb  vmovaps xmm15, [rsp+0xE0]
000079035ddd48c4  add rsp, 0xF0
000079035ddd48cb  pop r11
000079035ddd48cd  pop r10
000079035ddd48cf  pop r9
000079035ddd48d1  pop r8
000079035ddd48d3  pop rsi
000079035ddd48d4  pop rdi
000079035ddd48d5  pop rdx
000079035ddd48d6  pop rcx
000079035ddd48d7  pop rax
000079035ddd48d8  add rsp, 0x08
000079035ddd48dc  jmp 0x000079035DDD2B05
000079035ddd48e1  sub rsp, 0x08
000079035ddd48e5  push rax
000079035ddd48e6  push rcx
000079035ddd48e7  push rdx
000079035ddd48e8  push rdi
000079035ddd48e9  push rsi
000079035ddd48ea  push r8
000079035ddd48ec  push r9
000079035ddd48ee  push r10
000079035ddd48f0  push r11
000079035ddd48f2  sub rsp, 0xF0
000079035ddd48f9  vmovaps [rsp], xmm0
000079035ddd48fe  vmovaps [rsp+0x10], xmm1
000079035ddd4904  vmovaps [rsp+0x20], xmm2
000079035ddd490a  vmovaps [rsp+0x30], xmm3
000079035ddd4910  vmovaps [rsp+0x40], xmm4
000079035ddd4916  vmovaps [rsp+0x50], xmm5
000079035ddd491c  vmovaps [rsp+0x60], xmm6
000079035ddd4922  vmovaps [rsp+0x70], xmm7
000079035ddd4928  vmovaps [rsp+0x80], xmm8
000079035ddd4931  vmovaps [rsp+0x90], xmm9
000079035ddd493a  vmovaps [rsp+0xA0], xmm10
000079035ddd4943  vmovaps [rsp+0xB0], xmm11
000079035ddd494c  vmovaps [rsp+0xC0], xmm12
000079035ddd4955  vmovaps [rsp+0xD0], xmm13
000079035ddd495e  vmovaps [rsp+0xE0], xmm14
000079035ddd4967  sub rsp, 0x30
000079035ddd496b  movaps [rsp], xmm15
000079035ddd4970  movaps [rsp+0x10], xmm2
000079035ddd4975  movaps [rsp+0x20], xmm1
000079035ddd497a  lea rdi, [rsp]
000079035ddd497e  mov esi, 0x00
000079035ddd4983  mov rax, 0x64ACAA8B0530
000079035ddd498d  call rax
000079035ddd498f  movaps xmm15, [rsp]
000079035ddd4994  add rsp, 0x30
000079035ddd4998  vmovaps xmm0, [rsp]
000079035ddd499d  vmovaps xmm1, [rsp+0x10]
000079035ddd49a3  vmovaps xmm2, [rsp+0x20]
000079035ddd49a9  vmovaps xmm3, [rsp+0x30]
000079035ddd49af  vmovaps xmm4, [rsp+0x40]
000079035ddd49b5  vmovaps xmm5, [rsp+0x50]
000079035ddd49bb  vmovaps xmm6, [rsp+0x60]
000079035ddd49c1  vmovaps xmm7, [rsp+0x70]
000079035ddd49c7  vmovaps xmm8, [rsp+0x80]
000079035ddd49d0  vmovaps xmm9, [rsp+0x90]
000079035ddd49d9  vmovaps xmm10, [rsp+0xA0]
000079035ddd49e2  vmovaps xmm11, [rsp+0xB0]
000079035ddd49eb  vmovaps xmm12, [rsp+0xC0]
000079035ddd49f4  vmovaps xmm13, [rsp+0xD0]
000079035ddd49fd  vmovaps xmm14, [rsp+0xE0]
000079035ddd4a06  add rsp, 0xF0
000079035ddd4a0d  pop r11
000079035ddd4a0f  pop r10
000079035ddd4a11  pop r9
000079035ddd4a13  pop r8
000079035ddd4a15  pop rsi
000079035ddd4a16  pop rdi
000079035ddd4a17  pop rdx
000079035ddd4a18  pop rcx
000079035ddd4a19  pop rax
000079035ddd4a1a  add rsp, 0x08
000079035ddd4a1e  jmp 0x000079035DDD2B41
000079035ddd4a23  call 0x000079035DBFF430
000079035ddd4a28  jmp 0x000079035DDD2B4E
000079035ddd4a2d  sub rsp, 0x08
000079035ddd4a31  push rax
000079035ddd4a32  push rcx
000079035ddd4a33  push rdx
000079035ddd4a34  push rdi
000079035ddd4a35  push rsi
000079035ddd4a36  push r8
000079035ddd4a38  push r9
000079035ddd4a3a  push r10
000079035ddd4a3c  push r11
000079035ddd4a3e  sub rsp, 0xF0
000079035ddd4a45  vmovaps [rsp], xmm0
000079035ddd4a4a  vmovaps [rsp+0x10], xmm1
000079035ddd4a50  vmovaps [rsp+0x20], xmm3
000079035ddd4a56  vmovaps [rsp+0x30], xmm4
000079035ddd4a5c  vmovaps [rsp+0x40], xmm5
000079035ddd4a62  vmovaps [rsp+0x50], xmm6
000079035ddd4a68  vmovaps [rsp+0x60], xmm7
000079035ddd4a6e  vmovaps [rsp+0x70], xmm8
000079035ddd4a74  vmovaps [rsp+0x80], xmm9
000079035ddd4a7d  vmovaps [rsp+0x90], xmm10
000079035ddd4a86  vmovaps [rsp+0xA0], xmm11
000079035ddd4a8f  vmovaps [rsp+0xB0], xmm12
000079035ddd4a98  vmovaps [rsp+0xC0], xmm13
000079035ddd4aa1  vmovaps [rsp+0xD0], xmm14
000079035ddd4aaa  vmovaps [rsp+0xE0], xmm15
000079035ddd4ab3  sub rsp, 0x30
000079035ddd4ab7  movaps [rsp], xmm2
000079035ddd4abb  movaps [rsp+0x10], xmm1
000079035ddd4ac0  movaps [rsp+0x20], xmm14
000079035ddd4ac6  lea rdi, [rsp]
000079035ddd4aca  mov esi, 0x00
000079035ddd4acf  mov rax, 0x64ACAA8B0530
000079035ddd4ad9  call rax
000079035ddd4adb  movaps xmm2, [rsp]
000079035ddd4adf  add rsp, 0x30
000079035ddd4ae3  vmovaps xmm0, [rsp]
000079035ddd4ae8  vmovaps xmm1, [rsp+0x10]
000079035ddd4aee  vmovaps xmm3, [rsp+0x20]
000079035ddd4af4  vmovaps xmm4, [rsp+0x30]
000079035ddd4afa  vmovaps xmm5, [rsp+0x40]
000079035ddd4b00  vmovaps xmm6, [rsp+0x50]
000079035ddd4b06  vmovaps xmm7, [rsp+0x60]
000079035ddd4b0c  vmovaps xmm8, [rsp+0x70]
000079035ddd4b12  vmovaps xmm9, [rsp+0x80]
000079035ddd4b1b  vmovaps xmm10, [rsp+0x90]
000079035ddd4b24  vmovaps xmm11, [rsp+0xA0]
000079035ddd4b2d  vmovaps xmm12, [rsp+0xB0]
000079035ddd4b36  vmovaps xmm13, [rsp+0xC0]
000079035ddd4b3f  vmovaps xmm14, [rsp+0xD0]
000079035ddd4b48  vmovaps xmm15, [rsp+0xE0]
000079035ddd4b51  add rsp, 0xF0
000079035ddd4b58  pop r11
000079035ddd4b5a  pop r10
000079035ddd4b5c  pop r9
000079035ddd4b5e  pop r8
000079035ddd4b60  pop rsi
000079035ddd4b61  pop rdi
000079035ddd4b62  pop rdx
000079035ddd4b63  pop rcx
000079035ddd4b64  pop rax
000079035ddd4b65  add rsp, 0x08
000079035ddd4b69  jmp 0x000079035DDD2B8B
000079035ddd4b6e  sub rsp, 0x08
000079035ddd4b72  push rax
000079035ddd4b73  push rcx
000079035ddd4b74  push rdx
000079035ddd4b75  push rdi
000079035ddd4b76  push rsi
000079035ddd4b77  push r8
000079035ddd4b79  push r9
000079035ddd4b7b  push r10
000079035ddd4b7d  push r11
000079035ddd4b7f  sub rsp, 0xF0
000079035ddd4b86  vmovaps [rsp], xmm0
000079035ddd4b8b  vmovaps [rsp+0x10], xmm1
000079035ddd4b91  vmovaps [rsp+0x20], xmm2
000079035ddd4b97  vmovaps [rsp+0x30], xmm3
000079035ddd4b9d  vmovaps [rsp+0x40], xmm4
000079035ddd4ba3  vmovaps [rsp+0x50], xmm5
000079035ddd4ba9  vmovaps [rsp+0x60], xmm6
000079035ddd4baf  vmovaps [rsp+0x70], xmm7
000079035ddd4bb5  vmovaps [rsp+0x80], xmm8
000079035ddd4bbe  vmovaps [rsp+0x90], xmm9
000079035ddd4bc7  vmovaps [rsp+0xA0], xmm10
000079035ddd4bd0  vmovaps [rsp+0xB0], xmm11
000079035ddd4bd9  vmovaps [rsp+0xC0], xmm12
000079035ddd4be2  vmovaps [rsp+0xD0], xmm13
000079035ddd4beb  vmovaps [rsp+0xE0], xmm14
000079035ddd4bf4  sub rsp, 0x30
000079035ddd4bf8  movaps [rsp], xmm15
000079035ddd4bfd  movaps [rsp+0x10], xmm14
000079035ddd4c03  movaps [rsp+0x20], xmm1
000079035ddd4c08  lea rdi, [rsp]
000079035ddd4c0c  mov esi, 0x00
000079035ddd4c11  mov rax, 0x64ACAA8B0530
000079035ddd4c1b  call rax
000079035ddd4c1d  movaps xmm15, [rsp]
000079035ddd4c22  add rsp, 0x30
000079035ddd4c26  vmovaps xmm0, [rsp]
000079035ddd4c2b  vmovaps xmm1, [rsp+0x10]
000079035ddd4c31  vmovaps xmm2, [rsp+0x20]
000079035ddd4c37  vmovaps xmm3, [rsp+0x30]
000079035ddd4c3d  vmovaps xmm4, [rsp+0x40]
000079035ddd4c43  vmovaps xmm5, [rsp+0x50]
000079035ddd4c49  vmovaps xmm6, [rsp+0x60]
000079035ddd4c4f  vmovaps xmm7, [rsp+0x70]
000079035ddd4c55  vmovaps xmm8, [rsp+0x80]
000079035ddd4c5e  vmovaps xmm9, [rsp+0x90]
000079035ddd4c67  vmovaps xmm10, [rsp+0xA0]
000079035ddd4c70  vmovaps xmm11, [rsp+0xB0]
000079035ddd4c79  vmovaps xmm12, [rsp+0xC0]
000079035ddd4c82  vmovaps xmm13, [rsp+0xD0]
000079035ddd4c8b  vmovaps xmm14, [rsp+0xE0]
000079035ddd4c94  add rsp, 0xF0
000079035ddd4c9b  pop r11
000079035ddd4c9d  pop r10
000079035ddd4c9f  pop r9
000079035ddd4ca1  pop r8
000079035ddd4ca3  pop rsi
000079035ddd4ca4  pop rdi
000079035ddd4ca5  pop rdx
000079035ddd4ca6  pop rcx
000079035ddd4ca7  pop rax
000079035ddd4ca8  add rsp, 0x08
000079035ddd4cac  jmp 0x000079035DDD2C05
000079035ddd4cb1  call 0x000079035DBFF430
000079035ddd4cb6  jmp 0x000079035DDD2C12
000079035ddd4cbb  sub rsp, 0x08
000079035ddd4cbf  push rax
000079035ddd4cc0  push rcx
000079035ddd4cc1  push rdx
000079035ddd4cc2  push rdi
000079035ddd4cc3  push rsi
000079035ddd4cc4  push r8
000079035ddd4cc6  push r9
000079035ddd4cc8  push r10
000079035ddd4cca  push r11
000079035ddd4ccc  sub rsp, 0xF0
000079035ddd4cd3  vmovaps [rsp], xmm0
000079035ddd4cd8  vmovaps [rsp+0x10], xmm1
000079035ddd4cde  vmovaps [rsp+0x20], xmm2
000079035ddd4ce4  vmovaps [rsp+0x30], xmm3
000079035ddd4cea  vmovaps [rsp+0x40], xmm4
000079035ddd4cf0  vmovaps [rsp+0x50], xmm5
000079035ddd4cf6  vmovaps [rsp+0x60], xmm6
000079035ddd4cfc  vmovaps [rsp+0x70], xmm7
000079035ddd4d02  vmovaps [rsp+0x80], xmm8
000079035ddd4d0b  vmovaps [rsp+0x90], xmm9
000079035ddd4d14  vmovaps [rsp+0xA0], xmm10
000079035ddd4d1d  vmovaps [rsp+0xB0], xmm11
000079035ddd4d26  vmovaps [rsp+0xC0], xmm12
000079035ddd4d2f  vmovaps [rsp+0xD0], xmm14
000079035ddd4d38  vmovaps [rsp+0xE0], xmm15
000079035ddd4d41  sub rsp, 0x30
000079035ddd4d45  movaps [rsp], xmm13
000079035ddd4d4a  movaps [rsp+0x10], xmm1
000079035ddd4d4f  movaps [rsp+0x20], xmm15
000079035ddd4d55  lea rdi, [rsp]
000079035ddd4d59  mov esi, 0x00
000079035ddd4d5e  mov rax, 0x64ACAA8B0530
000079035ddd4d68  call rax
000079035ddd4d6a  movaps xmm13, [rsp]
000079035ddd4d6f  add rsp, 0x30
000079035ddd4d73  vmovaps xmm0, [rsp]
000079035ddd4d78  vmovaps xmm1, [rsp+0x10]
000079035ddd4d7e  vmovaps xmm2, [rsp+0x20]
000079035ddd4d84  vmovaps xmm3, [rsp+0x30]
000079035ddd4d8a  vmovaps xmm4, [rsp+0x40]
000079035ddd4d90  vmovaps xmm5, [rsp+0x50]
000079035ddd4d96  vmovaps xmm6, [rsp+0x60]
000079035ddd4d9c  vmovaps xmm7, [rsp+0x70]
000079035ddd4da2  vmovaps xmm8, [rsp+0x80]
000079035ddd4dab  vmovaps xmm9, [rsp+0x90]
000079035ddd4db4  vmovaps xmm10, [rsp+0xA0]
000079035ddd4dbd  vmovaps xmm11, [rsp+0xB0]
000079035ddd4dc6  vmovaps xmm12, [rsp+0xC0]
000079035ddd4dcf  vmovaps xmm14, [rsp+0xD0]
000079035ddd4dd8  vmovaps xmm15, [rsp+0xE0]
000079035ddd4de1  add rsp, 0xF0
000079035ddd4de8  pop r11
000079035ddd4dea  pop r10
000079035ddd4dec  pop r9
000079035ddd4dee  pop r8
000079035ddd4df0  pop rsi
000079035ddd4df1  pop rdi
000079035ddd4df2  pop rdx
000079035ddd4df3  pop rcx
000079035ddd4df4  pop rax
000079035ddd4df5  add rsp, 0x08
000079035ddd4df9  jmp 0x000079035DDD2CD6
000079035ddd4dfe  sub rsp, 0x08
000079035ddd4e02  push rax
000079035ddd4e03  push rcx
000079035ddd4e04  push rdx
000079035ddd4e05  push rdi
000079035ddd4e06  push rsi
000079035ddd4e07  push r8
000079035ddd4e09  push r9
000079035ddd4e0b  push r10
000079035ddd4e0d  push r11
000079035ddd4e0f  sub rsp, 0xF0
000079035ddd4e16  vmovaps [rsp], xmm0
000079035ddd4e1b  vmovaps [rsp+0x10], xmm1
000079035ddd4e21  vmovaps [rsp+0x20], xmm2
000079035ddd4e27  vmovaps [rsp+0x30], xmm3
000079035ddd4e2d  vmovaps [rsp+0x40], xmm4
000079035ddd4e33  vmovaps [rsp+0x50], xmm5
000079035ddd4e39  vmovaps [rsp+0x60], xmm6
000079035ddd4e3f  vmovaps [rsp+0x70], xmm7
000079035ddd4e45  vmovaps [rsp+0x80], xmm8
000079035ddd4e4e  vmovaps [rsp+0x90], xmm9
000079035ddd4e57  vmovaps [rsp+0xA0], xmm10
000079035ddd4e60  vmovaps [rsp+0xB0], xmm11
000079035ddd4e69  vmovaps [rsp+0xC0], xmm12
000079035ddd4e72  vmovaps [rsp+0xD0], xmm13
000079035ddd4e7b  vmovaps [rsp+0xE0], xmm14
000079035ddd4e84  sub rsp, 0x30
000079035ddd4e88  movaps [rsp], xmm15
000079035ddd4e8d  movaps [rsp+0x10], xmm14
000079035ddd4e93  movaps [rsp+0x20], xmm1
000079035ddd4e98  lea rdi, [rsp]
000079035ddd4e9c  mov esi, 0x00
000079035ddd4ea1  mov rax, 0x64ACAA8B0530
000079035ddd4eab  call rax
000079035ddd4ead  movaps xmm15, [rsp]
000079035ddd4eb2  add rsp, 0x30
000079035ddd4eb6  vmovaps xmm0, [rsp]
000079035ddd4ebb  vmovaps xmm1, [rsp+0x10]
000079035ddd4ec1  vmovaps xmm2, [rsp+0x20]
000079035ddd4ec7  vmovaps xmm3, [rsp+0x30]
000079035ddd4ecd  vmovaps xmm4, [rsp+0x40]
000079035ddd4ed3  vmovaps xmm5, [rsp+0x50]
000079035ddd4ed9  vmovaps xmm6, [rsp+0x60]
000079035ddd4edf  vmovaps xmm7, [rsp+0x70]
000079035ddd4ee5  vmovaps xmm8, [rsp+0x80]
000079035ddd4eee  vmovaps xmm9, [rsp+0x90]
000079035ddd4ef7  vmovaps xmm10, [rsp+0xA0]
000079035ddd4f00  vmovaps xmm11, [rsp+0xB0]
000079035ddd4f09  vmovaps xmm12, [rsp+0xC0]
000079035ddd4f12  vmovaps xmm13, [rsp+0xD0]
000079035ddd4f1b  vmovaps xmm14, [rsp+0xE0]
000079035ddd4f24  add rsp, 0xF0
000079035ddd4f2b  pop r11
000079035ddd4f2d  pop r10
000079035ddd4f2f  pop r9
000079035ddd4f31  pop r8
000079035ddd4f33  pop rsi
000079035ddd4f34  pop rdi
000079035ddd4f35  pop rdx
000079035ddd4f36  pop rcx
000079035ddd4f37  pop rax
000079035ddd4f38  add rsp, 0x08
000079035ddd4f3c  jmp 0x000079035DDD2D12
000079035ddd4f41  call 0x000079035DBFF430
000079035ddd4f46  jmp 0x000079035DDD2D1F
000079035ddd4f4b  sub rsp, 0x08
000079035ddd4f4f  push rax
000079035ddd4f50  push rcx
000079035ddd4f51  push rdx
000079035ddd4f52  push rdi
000079035ddd4f53  push rsi
000079035ddd4f54  push r8
000079035ddd4f56  push r9
000079035ddd4f58  push r10
000079035ddd4f5a  push r11
000079035ddd4f5c  sub rsp, 0xF0
000079035ddd4f63  vmovaps [rsp], xmm0
000079035ddd4f68  vmovaps [rsp+0x10], xmm1
000079035ddd4f6e  vmovaps [rsp+0x20], xmm2
000079035ddd4f74  vmovaps [rsp+0x30], xmm3
000079035ddd4f7a  vmovaps [rsp+0x40], xmm4
000079035ddd4f80  vmovaps [rsp+0x50], xmm5
000079035ddd4f86  vmovaps [rsp+0x60], xmm6
000079035ddd4f8c  vmovaps [rsp+0x70], xmm7
000079035ddd4f92  vmovaps [rsp+0x80], xmm8
000079035ddd4f9b  vmovaps [rsp+0x90], xmm9
000079035ddd4fa4  vmovaps [rsp+0xA0], xmm10
000079035ddd4fad  vmovaps [rsp+0xB0], xmm11
000079035ddd4fb6  vmovaps [rsp+0xC0], xmm12
000079035ddd4fbf  vmovaps [rsp+0xD0], xmm13
000079035ddd4fc8  vmovaps [rsp+0xE0], xmm15
000079035ddd4fd1  sub rsp, 0x30
000079035ddd4fd5  movaps [rsp], xmm14
000079035ddd4fda  movaps [rsp+0x10], xmm13
000079035ddd4fe0  movaps [rsp+0x20], xmm2
000079035ddd4fe5  lea rdi, [rsp]
000079035ddd4fe9  mov esi, 0x00
000079035ddd4fee  mov rax, 0x64ACAA8B0530
000079035ddd4ff8  call rax
000079035ddd4ffa  movaps xmm14, [rsp]
000079035ddd4fff  add rsp, 0x30
000079035ddd5003  vmovaps xmm0, [rsp]
000079035ddd5008  vmovaps xmm1, [rsp+0x10]
000079035ddd500e  vmovaps xmm2, [rsp+0x20]
000079035ddd5014  vmovaps xmm3, [rsp+0x30]
000079035ddd501a  vmovaps xmm4, [rsp+0x40]
000079035ddd5020  vmovaps xmm5, [rsp+0x50]
000079035ddd5026  vmovaps xmm6, [rsp+0x60]
000079035ddd502c  vmovaps xmm7, [rsp+0x70]
000079035ddd5032  vmovaps xmm8, [rsp+0x80]
000079035ddd503b  vmovaps xmm9, [rsp+0x90]
000079035ddd5044  vmovaps xmm10, [rsp+0xA0]
000079035ddd504d  vmovaps xmm11, [rsp+0xB0]
000079035ddd5056  vmovaps xmm12, [rsp+0xC0]
000079035ddd505f  vmovaps xmm13, [rsp+0xD0]
000079035ddd5068  vmovaps xmm15, [rsp+0xE0]
000079035ddd5071  add rsp, 0xF0
000079035ddd5078  pop r11
000079035ddd507a  pop r10
000079035ddd507c  pop r9
000079035ddd507e  pop r8
000079035ddd5080  pop rsi
000079035ddd5081  pop rdi
000079035ddd5082  pop rdx
000079035ddd5083  pop rcx
000079035ddd5084  pop rax
000079035ddd5085  add rsp, 0x08
000079035ddd5089  jmp 0x000079035DDD2D4B
000079035ddd508e  sub rsp, 0x08
000079035ddd5092  push rax
000079035ddd5093  push rcx
000079035ddd5094  push rdx
000079035ddd5095  push rdi
000079035ddd5096  push rsi
000079035ddd5097  push r8
000079035ddd5099  push r9
000079035ddd509b  push r10
000079035ddd509d  push r11
000079035ddd509f  sub rsp, 0xF0
000079035ddd50a6  vmovaps [rsp], xmm0
000079035ddd50ab  vmovaps [rsp+0x10], xmm2
000079035ddd50b1  vmovaps [rsp+0x20], xmm3
000079035ddd50b7  vmovaps [rsp+0x30], xmm4
000079035ddd50bd  vmovaps [rsp+0x40], xmm5
000079035ddd50c3  vmovaps [rsp+0x50], xmm6
000079035ddd50c9  vmovaps [rsp+0x60], xmm7
000079035ddd50cf  vmovaps [rsp+0x70], xmm8
000079035ddd50d5  vmovaps [rsp+0x80], xmm9
000079035ddd50de  vmovaps [rsp+0x90], xmm10
000079035ddd50e7  vmovaps [rsp+0xA0], xmm11
000079035ddd50f0  vmovaps [rsp+0xB0], xmm12
000079035ddd50f9  vmovaps [rsp+0xC0], xmm13
000079035ddd5102  vmovaps [rsp+0xD0], xmm14
000079035ddd510b  vmovaps [rsp+0xE0], xmm15
000079035ddd5114  sub rsp, 0x30
000079035ddd5118  movaps [rsp], xmm1
000079035ddd511c  movaps [rsp+0x10], xmm13
000079035ddd5122  movaps [rsp+0x20], xmm2
000079035ddd5127  lea rdi, [rsp]
000079035ddd512b  mov esi, 0x00
000079035ddd5130  mov rax, 0x64ACAA8B0530
000079035ddd513a  call rax
000079035ddd513c  movaps xmm1, [rsp]
000079035ddd5140  add rsp, 0x30
000079035ddd5144  vmovaps xmm0, [rsp]
000079035ddd5149  vmovaps xmm2, [rsp+0x10]
000079035ddd514f  vmovaps xmm3, [rsp+0x20]
000079035ddd5155  vmovaps xmm4, [rsp+0x30]
000079035ddd515b  vmovaps xmm5, [rsp+0x40]
000079035ddd5161  vmovaps xmm6, [rsp+0x50]
000079035ddd5167  vmovaps xmm7, [rsp+0x60]
000079035ddd516d  vmovaps xmm8, [rsp+0x70]
000079035ddd5173  vmovaps xmm9, [rsp+0x80]
000079035ddd517c  vmovaps xmm10, [rsp+0x90]
000079035ddd5185  vmovaps xmm11, [rsp+0xA0]
000079035ddd518e  vmovaps xmm12, [rsp+0xB0]
000079035ddd5197  vmovaps xmm13, [rsp+0xC0]
000079035ddd51a0  vmovaps xmm14, [rsp+0xD0]
000079035ddd51a9  vmovaps xmm15, [rsp+0xE0]
000079035ddd51b2  add rsp, 0xF0
000079035ddd51b9  pop r11
000079035ddd51bb  pop r10
000079035ddd51bd  pop r9
000079035ddd51bf  pop r8
000079035ddd51c1  pop rsi
000079035ddd51c2  pop rdi
000079035ddd51c3  pop rdx
000079035ddd51c4  pop rcx
000079035ddd51c5  pop rax
000079035ddd51c6  add rsp, 0x08
000079035ddd51ca  jmp 0x000079035DDD2D79
000079035ddd51cf  sub rsp, 0x08
000079035ddd51d3  push rax
000079035ddd51d4  push rcx
000079035ddd51d5  push rdx
000079035ddd51d6  push rdi
000079035ddd51d7  push rsi
000079035ddd51d8  push r8
000079035ddd51da  push r9
000079035ddd51dc  push r10
000079035ddd51de  push r11
000079035ddd51e0  sub rsp, 0xF0
000079035ddd51e7  vmovaps [rsp], xmm0
000079035ddd51ec  vmovaps [rsp+0x10], xmm1
000079035ddd51f2  vmovaps [rsp+0x20], xmm3
000079035ddd51f8  vmovaps [rsp+0x30], xmm4
000079035ddd51fe  vmovaps [rsp+0x40], xmm5
000079035ddd5204  vmovaps [rsp+0x50], xmm6
000079035ddd520a  vmovaps [rsp+0x60], xmm7
000079035ddd5210  vmovaps [rsp+0x70], xmm8
000079035ddd5216  vmovaps [rsp+0x80], xmm9
000079035ddd521f  vmovaps [rsp+0x90], xmm10
000079035ddd5228  vmovaps [rsp+0xA0], xmm11
000079035ddd5231  vmovaps [rsp+0xB0], xmm12
000079035ddd523a  vmovaps [rsp+0xC0], xmm13
000079035ddd5243  vmovaps [rsp+0xD0], xmm14
000079035ddd524c  vmovaps [rsp+0xE0], xmm15
000079035ddd5255  sub rsp, 0x30
000079035ddd5259  movaps [rsp], xmm2
000079035ddd525d  movaps [rsp+0x10], xmm1
000079035ddd5262  movaps [rsp+0x20], xmm13
000079035ddd5268  lea rdi, [rsp]
000079035ddd526c  mov esi, 0x00
000079035ddd5271  mov rax, 0x64ACAA8B0530
000079035ddd527b  call rax
000079035ddd527d  movaps xmm2, [rsp]
000079035ddd5281  add rsp, 0x30
000079035ddd5285  vmovaps xmm0, [rsp]
000079035ddd528a  vmovaps xmm1, [rsp+0x10]
000079035ddd5290  vmovaps xmm3, [rsp+0x20]
000079035ddd5296  vmovaps xmm4, [rsp+0x30]
000079035ddd529c  vmovaps xmm5, [rsp+0x40]
000079035ddd52a2  vmovaps xmm6, [rsp+0x50]
000079035ddd52a8  vmovaps xmm7, [rsp+0x60]
000079035ddd52ae  vmovaps xmm8, [rsp+0x70]
000079035ddd52b4  vmovaps xmm9, [rsp+0x80]
000079035ddd52bd  vmovaps xmm10, [rsp+0x90]
000079035ddd52c6  vmovaps xmm11, [rsp+0xA0]
000079035ddd52cf  vmovaps xmm12, [rsp+0xB0]
000079035ddd52d8  vmovaps xmm13, [rsp+0xC0]
000079035ddd52e1  vmovaps xmm14, [rsp+0xD0]
000079035ddd52ea  vmovaps xmm15, [rsp+0xE0]
000079035ddd52f3  add rsp, 0xF0
000079035ddd52fa  pop r11
000079035ddd52fc  pop r10
000079035ddd52fe  pop r9
000079035ddd5300  pop r8
000079035ddd5302  pop rsi
000079035ddd5303  pop rdi
000079035ddd5304  pop rdx
000079035ddd5305  pop rcx
000079035ddd5306  pop rax
000079035ddd5307  add rsp, 0x08
000079035ddd530b  jmp 0x000079035DDD2DD2
000079035ddd5310  call 0x000079035DBFF430
000079035ddd5315  jmp 0x000079035DDD2DDF
000079035ddd531a  sub rsp, 0x08
000079035ddd531e  push rax
000079035ddd531f  push rcx
000079035ddd5320  push rdx
000079035ddd5321  push rdi
000079035ddd5322  push rsi
000079035ddd5323  push r8
000079035ddd5325  push r9
000079035ddd5327  push r10
000079035ddd5329  push r11
000079035ddd532b  sub rsp, 0xF0
000079035ddd5332  vmovaps [rsp], xmm0
000079035ddd5337  vmovaps [rsp+0x10], xmm1
000079035ddd533d  vmovaps [rsp+0x20], xmm2
000079035ddd5343  vmovaps [rsp+0x30], xmm3
000079035ddd5349  vmovaps [rsp+0x40], xmm4
000079035ddd534f  vmovaps [rsp+0x50], xmm5
000079035ddd5355  vmovaps [rsp+0x60], xmm6
000079035ddd535b  vmovaps [rsp+0x70], xmm7
000079035ddd5361  vmovaps [rsp+0x80], xmm8
000079035ddd536a  vmovaps [rsp+0x90], xmm9
000079035ddd5373  vmovaps [rsp+0xA0], xmm10
000079035ddd537c  vmovaps [rsp+0xB0], xmm11
000079035ddd5385  vmovaps [rsp+0xC0], xmm12
000079035ddd538e  vmovaps [rsp+0xD0], xmm13
000079035ddd5397  vmovaps [rsp+0xE0], xmm14
000079035ddd53a0  sub rsp, 0x30
000079035ddd53a4  movaps [rsp], xmm15
000079035ddd53a9  movaps [rsp+0x10], xmm13
000079035ddd53af  movaps [rsp+0x20], xmm1
000079035ddd53b4  lea rdi, [rsp]
000079035ddd53b8  mov esi, 0x00
000079035ddd53bd  mov rax, 0x64ACAA8B0530
000079035ddd53c7  call rax
000079035ddd53c9  movaps xmm15, [rsp]
000079035ddd53ce  add rsp, 0x30
000079035ddd53d2  vmovaps xmm0, [rsp]
000079035ddd53d7  vmovaps xmm1, [rsp+0x10]
000079035ddd53dd  vmovaps xmm2, [rsp+0x20]
000079035ddd53e3  vmovaps xmm3, [rsp+0x30]
000079035ddd53e9  vmovaps xmm4, [rsp+0x40]
000079035ddd53ef  vmovaps xmm5, [rsp+0x50]
000079035ddd53f5  vmovaps xmm6, [rsp+0x60]
000079035ddd53fb  vmovaps xmm7, [rsp+0x70]
000079035ddd5401  vmovaps xmm8, [rsp+0x80]
000079035ddd540a  vmovaps xmm9, [rsp+0x90]
000079035ddd5413  vmovaps xmm10, [rsp+0xA0]
000079035ddd541c  vmovaps xmm11, [rsp+0xB0]
000079035ddd5425  vmovaps xmm12, [rsp+0xC0]
000079035ddd542e  vmovaps xmm13, [rsp+0xD0]
000079035ddd5437  vmovaps xmm14, [rsp+0xE0]
000079035ddd5440  add rsp, 0xF0
000079035ddd5447  pop r11
000079035ddd5449  pop r10
000079035ddd544b  pop r9
000079035ddd544d  pop r8
000079035ddd544f  pop rsi
000079035ddd5450  pop rdi
000079035ddd5451  pop rdx
000079035ddd5452  pop rcx
000079035ddd5453  pop rax
000079035ddd5454  add rsp, 0x08
000079035ddd5458  jmp 0x000079035DDD2E1E
000079035ddd545d  sub rsp, 0x08
000079035ddd5461  push rax
000079035ddd5462  push rcx
000079035ddd5463  push rdx
000079035ddd5464  push rdi
000079035ddd5465  push rsi
000079035ddd5466  push r8
000079035ddd5468  push r9
000079035ddd546a  push r10
000079035ddd546c  push r11
000079035ddd546e  sub rsp, 0xF0
000079035ddd5475  vmovaps [rsp], xmm0
000079035ddd547a  vmovaps [rsp+0x10], xmm1
000079035ddd5480  vmovaps [rsp+0x20], xmm2
000079035ddd5486  vmovaps [rsp+0x30], xmm3
000079035ddd548c  vmovaps [rsp+0x40], xmm4
000079035ddd5492  vmovaps [rsp+0x50], xmm5
000079035ddd5498  vmovaps [rsp+0x60], xmm6
000079035ddd549e  vmovaps [rsp+0x70], xmm7
000079035ddd54a4  vmovaps [rsp+0x80], xmm8
000079035ddd54ad  vmovaps [rsp+0x90], xmm9
000079035ddd54b6  vmovaps [rsp+0xA0], xmm10
000079035ddd54bf  vmovaps [rsp+0xB0], xmm11
000079035ddd54c8  vmovaps [rsp+0xC0], xmm12
000079035ddd54d1  vmovaps [rsp+0xD0], xmm13
000079035ddd54da  vmovaps [rsp+0xE0], xmm15
000079035ddd54e3  sub rsp, 0x30
000079035ddd54e7  movaps [rsp], xmm14
000079035ddd54ec  movaps [rsp+0x10], xmm11
000079035ddd54f2  movaps [rsp+0x20], xmm1
000079035ddd54f7  lea rdi, [rsp]
000079035ddd54fb  mov esi, 0x00
000079035ddd5500  mov rax, 0x64ACAA8B0530
000079035ddd550a  call rax
000079035ddd550c  movaps xmm14, [rsp]
000079035ddd5511  add rsp, 0x30
000079035ddd5515  vmovaps xmm0, [rsp]
000079035ddd551a  vmovaps xmm1, [rsp+0x10]
000079035ddd5520  vmovaps xmm2, [rsp+0x20]
000079035ddd5526  vmovaps xmm3, [rsp+0x30]
000079035ddd552c  vmovaps xmm4, [rsp+0x40]
000079035ddd5532  vmovaps xmm5, [rsp+0x50]
000079035ddd5538  vmovaps xmm6, [rsp+0x60]
000079035ddd553e  vmovaps xmm7, [rsp+0x70]
000079035ddd5544  vmovaps xmm8, [rsp+0x80]
000079035ddd554d  vmovaps xmm9, [rsp+0x90]
000079035ddd5556  vmovaps xmm10, [rsp+0xA0]
000079035ddd555f  vmovaps xmm11, [rsp+0xB0]
000079035ddd5568  vmovaps xmm12, [rsp+0xC0]
000079035ddd5571  vmovaps xmm13, [rsp+0xD0]
000079035ddd557a  vmovaps xmm15, [rsp+0xE0]
000079035ddd5583  add rsp, 0xF0
000079035ddd558a  pop r11
000079035ddd558c  pop r10
000079035ddd558e  pop r9
000079035ddd5590  pop r8
000079035ddd5592  pop rsi
000079035ddd5593  pop rdi
000079035ddd5594  pop rdx
000079035ddd5595  pop rcx
000079035ddd5596  pop rax
000079035ddd5597  add rsp, 0x08
000079035ddd559b  jmp 0x000079035DDD2E48
000079035ddd55a0  sub rsp, 0x08
000079035ddd55a4  push rax
000079035ddd55a5  push rcx
000079035ddd55a6  push rdx
000079035ddd55a7  push rdi
000079035ddd55a8  push rsi
000079035ddd55a9  push r8
000079035ddd55ab  push r9
000079035ddd55ad  push r10
000079035ddd55af  push r11
000079035ddd55b1  sub rsp, 0xF0
000079035ddd55b8  vmovaps [rsp], xmm0
000079035ddd55bd  vmovaps [rsp+0x10], xmm1
000079035ddd55c3  vmovaps [rsp+0x20], xmm2
000079035ddd55c9  vmovaps [rsp+0x30], xmm3
000079035ddd55cf  vmovaps [rsp+0x40], xmm4
000079035ddd55d5  vmovaps [rsp+0x50], xmm5
000079035ddd55db  vmovaps [rsp+0x60], xmm6
000079035ddd55e1  vmovaps [rsp+0x70], xmm7
000079035ddd55e7  vmovaps [rsp+0x80], xmm8
000079035ddd55f0  vmovaps [rsp+0x90], xmm9
000079035ddd55f9  vmovaps [rsp+0xA0], xmm10
000079035ddd5602  vmovaps [rsp+0xB0], xmm11
000079035ddd560b  vmovaps [rsp+0xC0], xmm12
000079035ddd5614  vmovaps [rsp+0xD0], xmm14
000079035ddd561d  vmovaps [rsp+0xE0], xmm15
000079035ddd5626  sub rsp, 0x30
000079035ddd562a  movaps [rsp], xmm13
000079035ddd562f  movaps [rsp+0x10], xmm11
000079035ddd5635  movaps [rsp+0x20], xmm1
000079035ddd563a  lea rdi, [rsp]
000079035ddd563e  mov esi, 0x00
000079035ddd5643  mov rax, 0x64ACAA8B0530
000079035ddd564d  call rax
000079035ddd564f  movaps xmm13, [rsp]
000079035ddd5654  add rsp, 0x30
000079035ddd5658  vmovaps xmm0, [rsp]
000079035ddd565d  vmovaps xmm1, [rsp+0x10]
000079035ddd5663  vmovaps xmm2, [rsp+0x20]
000079035ddd5669  vmovaps xmm3, [rsp+0x30]
000079035ddd566f  vmovaps xmm4, [rsp+0x40]
000079035ddd5675  vmovaps xmm5, [rsp+0x50]
000079035ddd567b  vmovaps xmm6, [rsp+0x60]
000079035ddd5681  vmovaps xmm7, [rsp+0x70]
000079035ddd5687  vmovaps xmm8, [rsp+0x80]
000079035ddd5690  vmovaps xmm9, [rsp+0x90]
000079035ddd5699  vmovaps xmm10, [rsp+0xA0]
000079035ddd56a2  vmovaps xmm11, [rsp+0xB0]
000079035ddd56ab  vmovaps xmm12, [rsp+0xC0]
000079035ddd56b4  vmovaps xmm14, [rsp+0xD0]
000079035ddd56bd  vmovaps xmm15, [rsp+0xE0]
000079035ddd56c6  add rsp, 0xF0
000079035ddd56cd  pop r11
000079035ddd56cf  pop r10
000079035ddd56d1  pop r9
000079035ddd56d3  pop r8
000079035ddd56d5  pop rsi
000079035ddd56d6  pop rdi
000079035ddd56d7  pop rdx
000079035ddd56d8  pop rcx
000079035ddd56d9  pop rax
000079035ddd56da  add rsp, 0x08
000079035ddd56de  jmp 0x000079035DDD2E9D
000079035ddd56e3  call 0x000079035DBFF430
000079035ddd56e8  jmp 0x000079035DDD2EAA
000079035ddd56ed  sub rsp, 0x08
000079035ddd56f1  push rax
000079035ddd56f2  push rcx
000079035ddd56f3  push rdx
000079035ddd56f4  push rdi
000079035ddd56f5  push rsi
000079035ddd56f6  push r8
000079035ddd56f8  push r9
000079035ddd56fa  push r10
000079035ddd56fc  push r11
000079035ddd56fe  sub rsp, 0xF0
000079035ddd5705  vmovaps [rsp], xmm0
000079035ddd570a  vmovaps [rsp+0x10], xmm1
000079035ddd5710  vmovaps [rsp+0x20], xmm2
000079035ddd5716  vmovaps [rsp+0x30], xmm3
000079035ddd571c  vmovaps [rsp+0x40], xmm4
000079035ddd5722  vmovaps [rsp+0x50], xmm5
000079035ddd5728  vmovaps [rsp+0x60], xmm6
000079035ddd572e  vmovaps [rsp+0x70], xmm7
000079035ddd5734  vmovaps [rsp+0x80], xmm8
000079035ddd573d  vmovaps [rsp+0x90], xmm9
000079035ddd5746  vmovaps [rsp+0xA0], xmm10
000079035ddd574f  vmovaps [rsp+0xB0], xmm11
000079035ddd5758  vmovaps [rsp+0xC0], xmm12
000079035ddd5761  vmovaps [rsp+0xD0], xmm13
000079035ddd576a  vmovaps [rsp+0xE0], xmm14
000079035ddd5773  sub rsp, 0x30
000079035ddd5777  movaps [rsp], xmm15
000079035ddd577c  movaps [rsp+0x10], xmm11
000079035ddd5782  movaps [rsp+0x20], xmm1
000079035ddd5787  lea rdi, [rsp]
000079035ddd578b  mov esi, 0x00
000079035ddd5790  mov rax, 0x64ACAA8B0530
000079035ddd579a  call rax
000079035ddd579c  movaps xmm15, [rsp]
000079035ddd57a1  add rsp, 0x30
000079035ddd57a5  vmovaps xmm0, [rsp]
000079035ddd57aa  vmovaps xmm1, [rsp+0x10]
000079035ddd57b0  vmovaps xmm2, [rsp+0x20]
000079035ddd57b6  vmovaps xmm3, [rsp+0x30]
000079035ddd57bc  vmovaps xmm4, [rsp+0x40]
000079035ddd57c2  vmovaps xmm5, [rsp+0x50]
000079035ddd57c8  vmovaps xmm6, [rsp+0x60]
000079035ddd57ce  vmovaps xmm7, [rsp+0x70]
000079035ddd57d4  vmovaps xmm8, [rsp+0x80]
000079035ddd57dd  vmovaps xmm9, [rsp+0x90]
000079035ddd57e6  vmovaps xmm10, [rsp+0xA0]
000079035ddd57ef  vmovaps xmm11, [rsp+0xB0]
000079035ddd57f8  vmovaps xmm12, [rsp+0xC0]
000079035ddd5801  vmovaps xmm13, [rsp+0xD0]
000079035ddd580a  vmovaps xmm14, [rsp+0xE0]
000079035ddd5813  add rsp, 0xF0
000079035ddd581a  pop r11
000079035ddd581c  pop r10
000079035ddd581e  pop r9
000079035ddd5820  pop r8
000079035ddd5822  pop rsi
000079035ddd5823  pop rdi
000079035ddd5824  pop rdx
000079035ddd5825  pop rcx
000079035ddd5826  pop rax
000079035ddd5827  add rsp, 0x08
000079035ddd582b  jmp 0x000079035DDD2EE3
000079035ddd5830  sub rsp, 0x08
000079035ddd5834  push rax
000079035ddd5835  push rcx
000079035ddd5836  push rdx
000079035ddd5837  push rdi
000079035ddd5838  push rsi
000079035ddd5839  push r8
000079035ddd583b  push r9
000079035ddd583d  push r10
000079035ddd583f  push r11
000079035ddd5841  sub rsp, 0xF0
000079035ddd5848  vmovaps [rsp], xmm0
000079035ddd584d  vmovaps [rsp+0x10], xmm1
000079035ddd5853  vmovaps [rsp+0x20], xmm2
000079035ddd5859  vmovaps [rsp+0x30], xmm3
000079035ddd585f  vmovaps [rsp+0x40], xmm4
000079035ddd5865  vmovaps [rsp+0x50], xmm5
000079035ddd586b  vmovaps [rsp+0x60], xmm6
000079035ddd5871  vmovaps [rsp+0x70], xmm7
000079035ddd5877  vmovaps [rsp+0x80], xmm8
000079035ddd5880  vmovaps [rsp+0x90], xmm9
000079035ddd5889  vmovaps [rsp+0xA0], xmm10
000079035ddd5892  vmovaps [rsp+0xB0], xmm12
000079035ddd589b  vmovaps [rsp+0xC0], xmm13
000079035ddd58a4  vmovaps [rsp+0xD0], xmm14
000079035ddd58ad  vmovaps [rsp+0xE0], xmm15
000079035ddd58b6  sub rsp, 0x30
000079035ddd58ba  movaps [rsp], xmm11
000079035ddd58bf  movaps [rsp+0x10], xmm6
000079035ddd58c4  movaps [rsp+0x20], xmm14
000079035ddd58ca  lea rdi, [rsp]
000079035ddd58ce  mov esi, 0x00
000079035ddd58d3  mov rax, 0x64ACAA8B0530
000079035ddd58dd  call rax
000079035ddd58df  movaps xmm11, [rsp]
000079035ddd58e4  add rsp, 0x30
000079035ddd58e8  vmovaps xmm0, [rsp]
000079035ddd58ed  vmovaps xmm1, [rsp+0x10]
000079035ddd58f3  vmovaps xmm2, [rsp+0x20]
000079035ddd58f9  vmovaps xmm3, [rsp+0x30]
000079035ddd58ff  vmovaps xmm4, [rsp+0x40]
000079035ddd5905  vmovaps xmm5, [rsp+0x50]
000079035ddd590b  vmovaps xmm6, [rsp+0x60]
000079035ddd5911  vmovaps xmm7, [rsp+0x70]
000079035ddd5917  vmovaps xmm8, [rsp+0x80]
000079035ddd5920  vmovaps xmm9, [rsp+0x90]
000079035ddd5929  vmovaps xmm10, [rsp+0xA0]
000079035ddd5932  vmovaps xmm12, [rsp+0xB0]
000079035ddd593b  vmovaps xmm13, [rsp+0xC0]
000079035ddd5944  vmovaps xmm14, [rsp+0xD0]
000079035ddd594d  vmovaps xmm15, [rsp+0xE0]
000079035ddd5956  add rsp, 0xF0
000079035ddd595d  pop r11
000079035ddd595f  pop r10
000079035ddd5961  pop r9
000079035ddd5963  pop r8
000079035ddd5965  pop rsi
000079035ddd5966  pop rdi
000079035ddd5967  pop rdx
000079035ddd5968  pop rcx
000079035ddd5969  pop rax
000079035ddd596a  add rsp, 0x08
000079035ddd596e  jmp 0x000079035DDD2F5B
000079035ddd5973  call 0x000079035DBFF430
000079035ddd5978  jmp 0x000079035DDD2F65
000079035ddd597d  sub rsp, 0x08
000079035ddd5981  push rax
000079035ddd5982  push rcx
000079035ddd5983  push rdx
000079035ddd5984  push rdi
000079035ddd5985  push rsi
000079035ddd5986  push r8
000079035ddd5988  push r9
000079035ddd598a  push r10
000079035ddd598c  push r11
000079035ddd598e  sub rsp, 0xF0
000079035ddd5995  vmovaps [rsp], xmm0
000079035ddd599a  vmovaps [rsp+0x10], xmm1
000079035ddd59a0  vmovaps [rsp+0x20], xmm2
000079035ddd59a6  vmovaps [rsp+0x30], xmm3
000079035ddd59ac  vmovaps [rsp+0x40], xmm4
000079035ddd59b2  vmovaps [rsp+0x50], xmm5
000079035ddd59b8  vmovaps [rsp+0x60], xmm6
000079035ddd59be  vmovaps [rsp+0x70], xmm7
000079035ddd59c4  vmovaps [rsp+0x80], xmm8
000079035ddd59cd  vmovaps [rsp+0x90], xmm9
000079035ddd59d6  vmovaps [rsp+0xA0], xmm10
000079035ddd59df  vmovaps [rsp+0xB0], xmm11
000079035ddd59e8  vmovaps [rsp+0xC0], xmm12
000079035ddd59f1  vmovaps [rsp+0xD0], xmm13
000079035ddd59fa  vmovaps [rsp+0xE0], xmm15
000079035ddd5a03  sub rsp, 0x30
000079035ddd5a07  movaps [rsp], xmm14
000079035ddd5a0c  movaps [rsp+0x10], xmm6
000079035ddd5a11  movaps [rsp+0x20], xmm2
000079035ddd5a16  lea rdi, [rsp]
000079035ddd5a1a  mov esi, 0x00
000079035ddd5a1f  mov rax, 0x64ACAA8B0530
000079035ddd5a29  call rax
000079035ddd5a2b  movaps xmm14, [rsp]
000079035ddd5a30  add rsp, 0x30
000079035ddd5a34  vmovaps xmm0, [rsp]
000079035ddd5a39  vmovaps xmm1, [rsp+0x10]
000079035ddd5a3f  vmovaps xmm2, [rsp+0x20]
000079035ddd5a45  vmovaps xmm3, [rsp+0x30]
000079035ddd5a4b  vmovaps xmm4, [rsp+0x40]
000079035ddd5a51  vmovaps xmm5, [rsp+0x50]
000079035ddd5a57  vmovaps xmm6, [rsp+0x60]
000079035ddd5a5d  vmovaps xmm7, [rsp+0x70]
000079035ddd5a63  vmovaps xmm8, [rsp+0x80]
000079035ddd5a6c  vmovaps xmm9, [rsp+0x90]
000079035ddd5a75  vmovaps xmm10, [rsp+0xA0]
000079035ddd5a7e  vmovaps xmm11, [rsp+0xB0]
000079035ddd5a87  vmovaps xmm12, [rsp+0xC0]
000079035ddd5a90  vmovaps xmm13, [rsp+0xD0]
000079035ddd5a99  vmovaps xmm15, [rsp+0xE0]
000079035ddd5aa2  add rsp, 0xF0
000079035ddd5aa9  pop r11
000079035ddd5aab  pop r10
000079035ddd5aad  pop r9
000079035ddd5aaf  pop r8
000079035ddd5ab1  pop rsi
000079035ddd5ab2  pop rdi
000079035ddd5ab3  pop rdx
000079035ddd5ab4  pop rcx
000079035ddd5ab5  pop rax
000079035ddd5ab6  add rsp, 0x08
000079035ddd5aba  jmp 0x000079035DDD2F99
000079035ddd5abf  sub rsp, 0x08
000079035ddd5ac3  push rax
000079035ddd5ac4  push rcx
000079035ddd5ac5  push rdx
000079035ddd5ac6  push rdi
000079035ddd5ac7  push rsi
000079035ddd5ac8  push r8
000079035ddd5aca  push r9
000079035ddd5acc  push r10
000079035ddd5ace  push r11
000079035ddd5ad0  sub rsp, 0xF0
000079035ddd5ad7  vmovaps [rsp], xmm0
000079035ddd5adc  vmovaps [rsp+0x10], xmm1
000079035ddd5ae2  vmovaps [rsp+0x20], xmm2
000079035ddd5ae8  vmovaps [rsp+0x30], xmm3
000079035ddd5aee  vmovaps [rsp+0x40], xmm4
000079035ddd5af4  vmovaps [rsp+0x50], xmm5
000079035ddd5afa  vmovaps [rsp+0x60], xmm7
000079035ddd5b00  vmovaps [rsp+0x70], xmm8
000079035ddd5b06  vmovaps [rsp+0x80], xmm9
000079035ddd5b0f  vmovaps [rsp+0x90], xmm10
000079035ddd5b18  vmovaps [rsp+0xA0], xmm11
000079035ddd5b21  vmovaps [rsp+0xB0], xmm12
000079035ddd5b2a  vmovaps [rsp+0xC0], xmm13
000079035ddd5b33  vmovaps [rsp+0xD0], xmm14
000079035ddd5b3c  vmovaps [rsp+0xE0], xmm15
000079035ddd5b45  sub rsp, 0x30
000079035ddd5b49  movaps [rsp], xmm6
000079035ddd5b4d  movaps [rsp+0x10], xmm5
000079035ddd5b52  movaps [rsp+0x20], xmm1
000079035ddd5b57  lea rdi, [rsp]
000079035ddd5b5b  mov esi, 0x00
000079035ddd5b60  mov rax, 0x64ACAA8B0530
000079035ddd5b6a  call rax
000079035ddd5b6c  movaps xmm6, [rsp]
000079035ddd5b70  add rsp, 0x30
000079035ddd5b74  vmovaps xmm0, [rsp]
000079035ddd5b79  vmovaps xmm1, [rsp+0x10]
000079035ddd5b7f  vmovaps xmm2, [rsp+0x20]
000079035ddd5b85  vmovaps xmm3, [rsp+0x30]
000079035ddd5b8b  vmovaps xmm4, [rsp+0x40]
000079035ddd5b91  vmovaps xmm5, [rsp+0x50]
000079035ddd5b97  vmovaps xmm7, [rsp+0x60]
000079035ddd5b9d  vmovaps xmm8, [rsp+0x70]
000079035ddd5ba3  vmovaps xmm9, [rsp+0x80]
000079035ddd5bac  vmovaps xmm10, [rsp+0x90]
000079035ddd5bb5  vmovaps xmm11, [rsp+0xA0]
000079035ddd5bbe  vmovaps xmm12, [rsp+0xB0]
000079035ddd5bc7  vmovaps xmm13, [rsp+0xC0]
000079035ddd5bd0  vmovaps xmm14, [rsp+0xD0]
000079035ddd5bd9  vmovaps xmm15, [rsp+0xE0]
000079035ddd5be2  add rsp, 0xF0
000079035ddd5be9  pop r11
000079035ddd5beb  pop r10
000079035ddd5bed  pop r9
000079035ddd5bef  pop r8
000079035ddd5bf1  pop rsi
000079035ddd5bf2  pop rdi
000079035ddd5bf3  pop rdx
000079035ddd5bf4  pop rcx
000079035ddd5bf5  pop rax
000079035ddd5bf6  add rsp, 0x08
000079035ddd5bfa  jmp 0x000079035DDD2FBF
000079035ddd5bff  sub rsp, 0x08
000079035ddd5c03  push rax
000079035ddd5c04  push rcx
000079035ddd5c05  push rdx
000079035ddd5c06  push rdi
000079035ddd5c07  push rsi
000079035ddd5c08  push r8
000079035ddd5c0a  push r9
000079035ddd5c0c  push r10
000079035ddd5c0e  push r11
000079035ddd5c10  sub rsp, 0xF0
000079035ddd5c17  vmovaps [rsp], xmm0
000079035ddd5c1c  vmovaps [rsp+0x10], xmm2
000079035ddd5c22  vmovaps [rsp+0x20], xmm3
000079035ddd5c28  vmovaps [rsp+0x30], xmm4
000079035ddd5c2e  vmovaps [rsp+0x40], xmm5
000079035ddd5c34  vmovaps [rsp+0x50], xmm6
000079035ddd5c3a  vmovaps [rsp+0x60], xmm7
000079035ddd5c40  vmovaps [rsp+0x70], xmm8
000079035ddd5c46  vmovaps [rsp+0x80], xmm9
000079035ddd5c4f  vmovaps [rsp+0x90], xmm10
000079035ddd5c58  vmovaps [rsp+0xA0], xmm11
000079035ddd5c61  vmovaps [rsp+0xB0], xmm12
000079035ddd5c6a  vmovaps [rsp+0xC0], xmm13
000079035ddd5c73  vmovaps [rsp+0xD0], xmm14
000079035ddd5c7c  vmovaps [rsp+0xE0], xmm15
000079035ddd5c85  sub rsp, 0x30
000079035ddd5c89  movaps [rsp], xmm1
000079035ddd5c8d  movaps [rsp+0x10], xmm5
000079035ddd5c92  movaps [rsp+0x20], xmm13
000079035ddd5c98  lea rdi, [rsp]
000079035ddd5c9c  mov esi, 0x00
000079035ddd5ca1  mov rax, 0x64ACAA8B0530
000079035ddd5cab  call rax
000079035ddd5cad  movaps xmm1, [rsp]
000079035ddd5cb1  add rsp, 0x30
000079035ddd5cb5  vmovaps xmm0, [rsp]
000079035ddd5cba  vmovaps xmm2, [rsp+0x10]
000079035ddd5cc0  vmovaps xmm3, [rsp+0x20]
000079035ddd5cc6  vmovaps xmm4, [rsp+0x30]
000079035ddd5ccc  vmovaps xmm5, [rsp+0x40]
000079035ddd5cd2  vmovaps xmm6, [rsp+0x50]
000079035ddd5cd8  vmovaps xmm7, [rsp+0x60]
000079035ddd5cde  vmovaps xmm8, [rsp+0x70]
000079035ddd5ce4  vmovaps xmm9, [rsp+0x80]
000079035ddd5ced  vmovaps xmm10, [rsp+0x90]
000079035ddd5cf6  vmovaps xmm11, [rsp+0xA0]
000079035ddd5cff  vmovaps xmm12, [rsp+0xB0]
000079035ddd5d08  vmovaps xmm13, [rsp+0xC0]
000079035ddd5d11  vmovaps xmm14, [rsp+0xD0]
000079035ddd5d1a  vmovaps xmm15, [rsp+0xE0]
000079035ddd5d23  add rsp, 0xF0
000079035ddd5d2a  pop r11
000079035ddd5d2c  pop r10
000079035ddd5d2e  pop r9
000079035ddd5d30  pop r8
000079035ddd5d32  pop rsi
000079035ddd5d33  pop rdi
000079035ddd5d34  pop rdx
000079035ddd5d35  pop rcx
000079035ddd5d36  pop rax
000079035ddd5d37  add rsp, 0x08
000079035ddd5d3b  jmp 0x000079035DDD2FDD
000079035ddd5d40  sub rsp, 0x08
000079035ddd5d44  push rax
000079035ddd5d45  push rcx
000079035ddd5d46  push rdx
000079035ddd5d47  push rdi
000079035ddd5d48  push rsi
000079035ddd5d49  push r8
000079035ddd5d4b  push r9
000079035ddd5d4d  push r10
000079035ddd5d4f  push r11
000079035ddd5d51  sub rsp, 0xF0
000079035ddd5d58  vmovaps [rsp], xmm0
000079035ddd5d5d  vmovaps [rsp+0x10], xmm1
000079035ddd5d63  vmovaps [rsp+0x20], xmm2
000079035ddd5d69  vmovaps [rsp+0x30], xmm3
000079035ddd5d6f  vmovaps [rsp+0x40], xmm4
000079035ddd5d75  vmovaps [rsp+0x50], xmm6
000079035ddd5d7b  vmovaps [rsp+0x60], xmm7
000079035ddd5d81  vmovaps [rsp+0x70], xmm8
000079035ddd5d87  vmovaps [rsp+0x80], xmm9
000079035ddd5d90  vmovaps [rsp+0x90], xmm10
000079035ddd5d99  vmovaps [rsp+0xA0], xmm11
000079035ddd5da2  vmovaps [rsp+0xB0], xmm12
000079035ddd5dab  vmovaps [rsp+0xC0], xmm13
000079035ddd5db4  vmovaps [rsp+0xD0], xmm14
000079035ddd5dbd  vmovaps [rsp+0xE0], xmm15
000079035ddd5dc6  sub rsp, 0x30
000079035ddd5dca  movaps [rsp], xmm5
000079035ddd5dce  movaps [rsp+0x10], xmm2
000079035ddd5dd3  movaps [rsp+0x20], xmm13
000079035ddd5dd9  lea rdi, [rsp]
000079035ddd5ddd  mov esi, 0x00
000079035ddd5de2  mov rax, 0x64ACAA8B0530
000079035ddd5dec  call rax
000079035ddd5dee  movaps xmm5, [rsp]
000079035ddd5df2  add rsp, 0x30
000079035ddd5df6  vmovaps xmm0, [rsp]
000079035ddd5dfb  vmovaps xmm1, [rsp+0x10]
000079035ddd5e01  vmovaps xmm2, [rsp+0x20]
000079035ddd5e07  vmovaps xmm3, [rsp+0x30]
000079035ddd5e0d  vmovaps xmm4, [rsp+0x40]
000079035ddd5e13  vmovaps xmm6, [rsp+0x50]
000079035ddd5e19  vmovaps xmm7, [rsp+0x60]
000079035ddd5e1f  vmovaps xmm8, [rsp+0x70]
000079035ddd5e25  vmovaps xmm9, [rsp+0x80]
000079035ddd5e2e  vmovaps xmm10, [rsp+0x90]
000079035ddd5e37  vmovaps xmm11, [rsp+0xA0]
000079035ddd5e40  vmovaps xmm12, [rsp+0xB0]
000079035ddd5e49  vmovaps xmm13, [rsp+0xC0]
000079035ddd5e52  vmovaps xmm14, [rsp+0xD0]
000079035ddd5e5b  vmovaps xmm15, [rsp+0xE0]
000079035ddd5e64  add rsp, 0xF0
000079035ddd5e6b  pop r11
000079035ddd5e6d  pop r10
000079035ddd5e6f  pop r9
000079035ddd5e71  pop r8
000079035ddd5e73  pop rsi
000079035ddd5e74  pop rdi
000079035ddd5e75  pop rdx
000079035ddd5e76  pop rcx
000079035ddd5e77  pop rax
000079035ddd5e78  add rsp, 0x08
000079035ddd5e7c  jmp 0x000079035DDD3013
000079035ddd5e81  sub rsp, 0x08
000079035ddd5e85  push rax
000079035ddd5e86  push rcx
000079035ddd5e87  push rdx
000079035ddd5e88  push rdi
000079035ddd5e89  push rsi
000079035ddd5e8a  push r8
000079035ddd5e8c  push r9
000079035ddd5e8e  push r10
000079035ddd5e90  push r11
000079035ddd5e92  sub rsp, 0xF0
000079035ddd5e99  vmovaps [rsp], xmm0
000079035ddd5e9e  vmovaps [rsp+0x10], xmm1
000079035ddd5ea4  vmovaps [rsp+0x20], xmm2
000079035ddd5eaa  vmovaps [rsp+0x30], xmm3
000079035ddd5eb0  vmovaps [rsp+0x40], xmm4
000079035ddd5eb6  vmovaps [rsp+0x50], xmm5
000079035ddd5ebc  vmovaps [rsp+0x60], xmm6
000079035ddd5ec2  vmovaps [rsp+0x70], xmm7
000079035ddd5ec8  vmovaps [rsp+0x80], xmm8
000079035ddd5ed1  vmovaps [rsp+0x90], xmm9
000079035ddd5eda  vmovaps [rsp+0xA0], xmm10
000079035ddd5ee3  vmovaps [rsp+0xB0], xmm11
000079035ddd5eec  vmovaps [rsp+0xC0], xmm12
000079035ddd5ef5  vmovaps [rsp+0xD0], xmm14
000079035ddd5efe  vmovaps [rsp+0xE0], xmm15
000079035ddd5f07  sub rsp, 0x30
000079035ddd5f0b  movaps [rsp], xmm13
000079035ddd5f10  movaps [rsp+0x10], xmm10
000079035ddd5f16  movaps [rsp+0x20], xmm1
000079035ddd5f1b  lea rdi, [rsp]
000079035ddd5f1f  mov esi, 0x00
000079035ddd5f24  mov rax, 0x64ACAA8B0530
000079035ddd5f2e  call rax
000079035ddd5f30  movaps xmm13, [rsp]
000079035ddd5f35  add rsp, 0x30
000079035ddd5f39  vmovaps xmm0, [rsp]
000079035ddd5f3e  vmovaps xmm1, [rsp+0x10]
000079035ddd5f44  vmovaps xmm2, [rsp+0x20]
000079035ddd5f4a  vmovaps xmm3, [rsp+0x30]
000079035ddd5f50  vmovaps xmm4, [rsp+0x40]
000079035ddd5f56  vmovaps xmm5, [rsp+0x50]
000079035ddd5f5c  vmovaps xmm6, [rsp+0x60]
000079035ddd5f62  vmovaps xmm7, [rsp+0x70]
000079035ddd5f68  vmovaps xmm8, [rsp+0x80]
000079035ddd5f71  vmovaps xmm9, [rsp+0x90]
000079035ddd5f7a  vmovaps xmm10, [rsp+0xA0]
000079035ddd5f83  vmovaps xmm11, [rsp+0xB0]
000079035ddd5f8c  vmovaps xmm12, [rsp+0xC0]
000079035ddd5f95  vmovaps xmm14, [rsp+0xD0]
000079035ddd5f9e  vmovaps xmm15, [rsp+0xE0]
000079035ddd5fa7  add rsp, 0xF0
000079035ddd5fae  pop r11
000079035ddd5fb0  pop r10
000079035ddd5fb2  pop r9
000079035ddd5fb4  pop r8
000079035ddd5fb6  pop rsi
000079035ddd5fb7  pop rdi
000079035ddd5fb8  pop rdx
000079035ddd5fb9  pop rcx
000079035ddd5fba  pop rax
000079035ddd5fbb  add rsp, 0x08
000079035ddd5fbf  jmp 0x000079035DDD303C
000079035ddd5fc4  sub rsp, 0x08
000079035ddd5fc8  push rax
000079035ddd5fc9  push rcx
000079035ddd5fca  push rdx
000079035ddd5fcb  push rdi
000079035ddd5fcc  push rsi
000079035ddd5fcd  push r8
000079035ddd5fcf  push r9
000079035ddd5fd1  push r10
000079035ddd5fd3  push r11
000079035ddd5fd5  sub rsp, 0xF0
000079035ddd5fdc  vmovaps [rsp], xmm0
000079035ddd5fe1  vmovaps [rsp+0x10], xmm2
000079035ddd5fe7  vmovaps [rsp+0x20], xmm3
000079035ddd5fed  vmovaps [rsp+0x30], xmm4
000079035ddd5ff3  vmovaps [rsp+0x40], xmm5
000079035ddd5ff9  vmovaps [rsp+0x50], xmm6
000079035ddd5fff  vmovaps [rsp+0x60], xmm7
000079035ddd6005  vmovaps [rsp+0x70], xmm8
000079035ddd600b  vmovaps [rsp+0x80], xmm9
000079035ddd6014  vmovaps [rsp+0x90], xmm10
000079035ddd601d  vmovaps [rsp+0xA0], xmm11
000079035ddd6026  vmovaps [rsp+0xB0], xmm12
000079035ddd602f  vmovaps [rsp+0xC0], xmm13
000079035ddd6038  vmovaps [rsp+0xD0], xmm14
000079035ddd6041  vmovaps [rsp+0xE0], xmm15
000079035ddd604a  sub rsp, 0x30
000079035ddd604e  movaps [rsp], xmm1
000079035ddd6052  movaps [rsp+0x10], xmm15
000079035ddd6058  movaps [rsp+0x20], xmm10
000079035ddd605e  lea rdi, [rsp]
000079035ddd6062  mov esi, 0x00
000079035ddd6067  mov rax, 0x64ACAA8B0530
000079035ddd6071  call rax
000079035ddd6073  movaps xmm1, [rsp]
000079035ddd6077  add rsp, 0x30
000079035ddd607b  vmovaps xmm0, [rsp]
000079035ddd6080  vmovaps xmm2, [rsp+0x10]
000079035ddd6086  vmovaps xmm3, [rsp+0x20]
000079035ddd608c  vmovaps xmm4, [rsp+0x30]
000079035ddd6092  vmovaps xmm5, [rsp+0x40]
000079035ddd6098  vmovaps xmm6, [rsp+0x50]
000079035ddd609e  vmovaps xmm7, [rsp+0x60]
000079035ddd60a4  vmovaps xmm8, [rsp+0x70]
000079035ddd60aa  vmovaps xmm9, [rsp+0x80]
000079035ddd60b3  vmovaps xmm10, [rsp+0x90]
000079035ddd60bc  vmovaps xmm11, [rsp+0xA0]
000079035ddd60c5  vmovaps xmm12, [rsp+0xB0]
000079035ddd60ce  vmovaps xmm13, [rsp+0xC0]
000079035ddd60d7  vmovaps xmm14, [rsp+0xD0]
000079035ddd60e0  vmovaps xmm15, [rsp+0xE0]
000079035ddd60e9  add rsp, 0xF0
000079035ddd60f0  pop r11
000079035ddd60f2  pop r10
000079035ddd60f4  pop r9
000079035ddd60f6  pop r8
000079035ddd60f8  pop rsi
000079035ddd60f9  pop rdi
000079035ddd60fa  pop rdx
000079035ddd60fb  pop rcx
000079035ddd60fc  pop rax
000079035ddd60fd  add rsp, 0x08
000079035ddd6101  jmp 0x000079035DDD305B
000079035ddd6106  sub rsp, 0x08
000079035ddd610a  push rax
000079035ddd610b  push rcx
000079035ddd610c  push rdx
000079035ddd610d  push rdi
000079035ddd610e  push rsi
000079035ddd610f  push r8
000079035ddd6111  push r9
000079035ddd6113  push r10
000079035ddd6115  push r11
000079035ddd6117  sub rsp, 0xF0
000079035ddd611e  vmovaps [rsp], xmm0
000079035ddd6123  vmovaps [rsp+0x10], xmm1
000079035ddd6129  vmovaps [rsp+0x20], xmm2
000079035ddd612f  vmovaps [rsp+0x30], xmm3
000079035ddd6135  vmovaps [rsp+0x40], xmm4
000079035ddd613b  vmovaps [rsp+0x50], xmm5
000079035ddd6141  vmovaps [rsp+0x60], xmm6
000079035ddd6147  vmovaps [rsp+0x70], xmm7
000079035ddd614d  vmovaps [rsp+0x80], xmm8
000079035ddd6156  vmovaps [rsp+0x90], xmm9
000079035ddd615f  vmovaps [rsp+0xA0], xmm10
000079035ddd6168  vmovaps [rsp+0xB0], xmm11
000079035ddd6171  vmovaps [rsp+0xC0], xmm12
000079035ddd617a  vmovaps [rsp+0xD0], xmm13
000079035ddd6183  vmovaps [rsp+0xE0], xmm14
000079035ddd618c  sub rsp, 0x30
000079035ddd6190  movaps [rsp], xmm15
000079035ddd6195  movaps [rsp+0x10], xmm10
000079035ddd619b  movaps [rsp+0x20], xmm11
000079035ddd61a1  lea rdi, [rsp]
000079035ddd61a5  mov esi, 0x00
000079035ddd61aa  mov rax, 0x64ACAA8B0530
000079035ddd61b4  call rax
000079035ddd61b6  movaps xmm15, [rsp]
000079035ddd61bb  add rsp, 0x30
000079035ddd61bf  vmovaps xmm0, [rsp]
000079035ddd61c4  vmovaps xmm1, [rsp+0x10]
000079035ddd61ca  vmovaps xmm2, [rsp+0x20]
000079035ddd61d0  vmovaps xmm3, [rsp+0x30]
000079035ddd61d6  vmovaps xmm4, [rsp+0x40]
000079035ddd61dc  vmovaps xmm5, [rsp+0x50]
000079035ddd61e2  vmovaps xmm6, [rsp+0x60]
000079035ddd61e8  vmovaps xmm7, [rsp+0x70]
000079035ddd61ee  vmovaps xmm8, [rsp+0x80]
000079035ddd61f7  vmovaps xmm9, [rsp+0x90]
000079035ddd6200  vmovaps xmm10, [rsp+0xA0]
000079035ddd6209  vmovaps xmm11, [rsp+0xB0]
000079035ddd6212  vmovaps xmm12, [rsp+0xC0]
000079035ddd621b  vmovaps xmm13, [rsp+0xD0]
000079035ddd6224  vmovaps xmm14, [rsp+0xE0]
000079035ddd622d  add rsp, 0xF0
000079035ddd6234  pop r11
000079035ddd6236  pop r10
000079035ddd6238  pop r9
000079035ddd623a  pop r8
000079035ddd623c  pop rsi
000079035ddd623d  pop rdi
000079035ddd623e  pop rdx
000079035ddd623f  pop rcx
000079035ddd6240  pop rax
000079035ddd6241  add rsp, 0x08
000079035ddd6245  jmp 0x000079035DDD307E
000079035ddd624a  sub rsp, 0x08
000079035ddd624e  push rax
000079035ddd624f  push rcx
000079035ddd6250  push rdx
000079035ddd6251  push rdi
000079035ddd6252  push rsi
000079035ddd6253  push r8
000079035ddd6255  push r9
000079035ddd6257  push r10
000079035ddd6259  push r11
000079035ddd625b  sub rsp, 0xF0
000079035ddd6262  vmovaps [rsp], xmm0
000079035ddd6267  vmovaps [rsp+0x10], xmm1
000079035ddd626d  vmovaps [rsp+0x20], xmm2
000079035ddd6273  vmovaps [rsp+0x30], xmm3
000079035ddd6279  vmovaps [rsp+0x40], xmm4
000079035ddd627f  vmovaps [rsp+0x50], xmm5
000079035ddd6285  vmovaps [rsp+0x60], xmm6
000079035ddd628b  vmovaps [rsp+0x70], xmm7
000079035ddd6291  vmovaps [rsp+0x80], xmm8
000079035ddd629a  vmovaps [rsp+0x90], xmm9
000079035ddd62a3  vmovaps [rsp+0xA0], xmm11
000079035ddd62ac  vmovaps [rsp+0xB0], xmm12
000079035ddd62b5  vmovaps [rsp+0xC0], xmm13
000079035ddd62be  vmovaps [rsp+0xD0], xmm14
000079035ddd62c7  vmovaps [rsp+0xE0], xmm15
000079035ddd62d0  sub rsp, 0x30
000079035ddd62d4  movaps [rsp], xmm10
000079035ddd62d9  movaps [rsp+0x10], xmm2
000079035ddd62de  movaps [rsp+0x20], xmm11
000079035ddd62e4  lea rdi, [rsp]
000079035ddd62e8  mov esi, 0x00
000079035ddd62ed  mov rax, 0x64ACAA8B0530
000079035ddd62f7  call rax
000079035ddd62f9  movaps xmm10, [rsp]
000079035ddd62fe  add rsp, 0x30
000079035ddd6302  vmovaps xmm0, [rsp]
000079035ddd6307  vmovaps xmm1, [rsp+0x10]
000079035ddd630d  vmovaps xmm2, [rsp+0x20]
000079035ddd6313  vmovaps xmm3, [rsp+0x30]
000079035ddd6319  vmovaps xmm4, [rsp+0x40]
000079035ddd631f  vmovaps xmm5, [rsp+0x50]
000079035ddd6325  vmovaps xmm6, [rsp+0x60]
000079035ddd632b  vmovaps xmm7, [rsp+0x70]
000079035ddd6331  vmovaps xmm8, [rsp+0x80]
000079035ddd633a  vmovaps xmm9, [rsp+0x90]
000079035ddd6343  vmovaps xmm11, [rsp+0xA0]
000079035ddd634c  vmovaps xmm12, [rsp+0xB0]
000079035ddd6355  vmovaps xmm13, [rsp+0xC0]
000079035ddd635e  vmovaps xmm14, [rsp+0xD0]
000079035ddd6367  vmovaps xmm15, [rsp+0xE0]
000079035ddd6370  add rsp, 0xF0
000079035ddd6377  pop r11
000079035ddd6379  pop r10
000079035ddd637b  pop r9
000079035ddd637d  pop r8
000079035ddd637f  pop rsi
000079035ddd6380  pop rdi
000079035ddd6381  pop rdx
000079035ddd6382  pop rcx
000079035ddd6383  pop rax
000079035ddd6384  add rsp, 0x08
000079035ddd6388  jmp 0x000079035DDD30B6
000079035ddd638d  sub rsp, 0x08
000079035ddd6391  push rax
000079035ddd6392  push rcx
000079035ddd6393  push rdx
000079035ddd6394  push rdi
000079035ddd6395  push rsi
000079035ddd6396  push r8
000079035ddd6398  push r9
000079035ddd639a  push r10
000079035ddd639c  push r11
000079035ddd639e  sub rsp, 0xF0
000079035ddd63a5  vmovaps [rsp], xmm0
000079035ddd63aa  vmovaps [rsp+0x10], xmm1
000079035ddd63b0  vmovaps [rsp+0x20], xmm2
000079035ddd63b6  vmovaps [rsp+0x30], xmm3
000079035ddd63bc  vmovaps [rsp+0x40], xmm4
000079035ddd63c2  vmovaps [rsp+0x50], xmm5
000079035ddd63c8  vmovaps [rsp+0x60], xmm6
000079035ddd63ce  vmovaps [rsp+0x70], xmm7
000079035ddd63d4  vmovaps [rsp+0x80], xmm8
000079035ddd63dd  vmovaps [rsp+0x90], xmm9
000079035ddd63e6  vmovaps [rsp+0xA0], xmm10
000079035ddd63ef  vmovaps [rsp+0xB0], xmm12
000079035ddd63f8  vmovaps [rsp+0xC0], xmm13
000079035ddd6401  vmovaps [rsp+0xD0], xmm14
000079035ddd640a  vmovaps [rsp+0xE0], xmm15
000079035ddd6413  sub rsp, 0x30
000079035ddd6417  movaps [rsp], xmm11
000079035ddd641c  movaps [rsp+0x10], xmm2
000079035ddd6421  movaps [rsp+0x20], xmm1
000079035ddd6426  lea rdi, [rsp]
000079035ddd642a  mov esi, 0x00
000079035ddd642f  mov rax, 0x64ACAA8B0530
000079035ddd6439  call rax
000079035ddd643b  movaps xmm11, [rsp]
000079035ddd6440  add rsp, 0x30
000079035ddd6444  vmovaps xmm0, [rsp]
000079035ddd6449  vmovaps xmm1, [rsp+0x10]
000079035ddd644f  vmovaps xmm2, [rsp+0x20]
000079035ddd6455  vmovaps xmm3, [rsp+0x30]
000079035ddd645b  vmovaps xmm4, [rsp+0x40]
000079035ddd6461  vmovaps xmm5, [rsp+0x50]
000079035ddd6467  vmovaps xmm6, [rsp+0x60]
000079035ddd646d  vmovaps xmm7, [rsp+0x70]
000079035ddd6473  vmovaps xmm8, [rsp+0x80]
000079035ddd647c  vmovaps xmm9, [rsp+0x90]
000079035ddd6485  vmovaps xmm10, [rsp+0xA0]
000079035ddd648e  vmovaps xmm12, [rsp+0xB0]
000079035ddd6497  vmovaps xmm13, [rsp+0xC0]
000079035ddd64a0  vmovaps xmm14, [rsp+0xD0]
000079035ddd64a9  vmovaps xmm15, [rsp+0xE0]
000079035ddd64b2  add rsp, 0xF0
000079035ddd64b9  pop r11
000079035ddd64bb  pop r10
000079035ddd64bd  pop r9
000079035ddd64bf  pop r8
000079035ddd64c1  pop rsi
000079035ddd64c2  pop rdi
000079035ddd64c3  pop rdx
000079035ddd64c4  pop rcx
000079035ddd64c5  pop rax
000079035ddd64c6  add rsp, 0x08
000079035ddd64ca  jmp 0x000079035DDD30F2
000079035ddd64cf  sub rsp, 0x08
000079035ddd64d3  push rax
000079035ddd64d4  push rcx
000079035ddd64d5  push rdx
000079035ddd64d6  push rdi
000079035ddd64d7  push rsi
000079035ddd64d8  push r8
000079035ddd64da  push r9
000079035ddd64dc  push r10
000079035ddd64de  push r11
000079035ddd64e0  sub rsp, 0xF0
000079035ddd64e7  vmovaps [rsp], xmm0
000079035ddd64ec  vmovaps [rsp+0x10], xmm2
000079035ddd64f2  vmovaps [rsp+0x20], xmm3
000079035ddd64f8  vmovaps [rsp+0x30], xmm4
000079035ddd64fe  vmovaps [rsp+0x40], xmm5
000079035ddd6504  vmovaps [rsp+0x50], xmm6
000079035ddd650a  vmovaps [rsp+0x60], xmm7
000079035ddd6510  vmovaps [rsp+0x70], xmm8
000079035ddd6516  vmovaps [rsp+0x80], xmm9
000079035ddd651f  vmovaps [rsp+0x90], xmm10
000079035ddd6528  vmovaps [rsp+0xA0], xmm11
000079035ddd6531  vmovaps [rsp+0xB0], xmm12
000079035ddd653a  vmovaps [rsp+0xC0], xmm13
000079035ddd6543  vmovaps [rsp+0xD0], xmm14
000079035ddd654c  vmovaps [rsp+0xE0], xmm15
000079035ddd6555  sub rsp, 0x30
000079035ddd6559  movaps [rsp], xmm1
000079035ddd655d  movaps [rsp+0x10], xmm14
000079035ddd6563  movaps [rsp+0x20], xmm6
000079035ddd6568  lea rdi, [rsp]
000079035ddd656c  mov esi, 0x00
000079035ddd6571  mov rax, 0x64ACAA8B0530
000079035ddd657b  call rax
000079035ddd657d  movaps xmm1, [rsp]
000079035ddd6581  add rsp, 0x30
000079035ddd6585  vmovaps xmm0, [rsp]
000079035ddd658a  vmovaps xmm2, [rsp+0x10]
000079035ddd6590  vmovaps xmm3, [rsp+0x20]
000079035ddd6596  vmovaps xmm4, [rsp+0x30]
000079035ddd659c  vmovaps xmm5, [rsp+0x40]
000079035ddd65a2  vmovaps xmm6, [rsp+0x50]
000079035ddd65a8  vmovaps xmm7, [rsp+0x60]
000079035ddd65ae  vmovaps xmm8, [rsp+0x70]
000079035ddd65b4  vmovaps xmm9, [rsp+0x80]
000079035ddd65bd  vmovaps xmm10, [rsp+0x90]
000079035ddd65c6  vmovaps xmm11, [rsp+0xA0]
000079035ddd65cf  vmovaps xmm12, [rsp+0xB0]
000079035ddd65d8  vmovaps xmm13, [rsp+0xC0]
000079035ddd65e1  vmovaps xmm14, [rsp+0xD0]
000079035ddd65ea  vmovaps xmm15, [rsp+0xE0]
000079035ddd65f3  add rsp, 0xF0
000079035ddd65fa  pop r11
000079035ddd65fc  pop r10
000079035ddd65fe  pop r9
000079035ddd6600  pop r8
000079035ddd6602  pop rsi
000079035ddd6603  pop rdi
000079035ddd6604  pop rdx
000079035ddd6605  pop rcx
000079035ddd6606  pop rax
000079035ddd6607  add rsp, 0x08
000079035ddd660b  jmp 0x000079035DDD310B
000079035ddd6610  sub rsp, 0x08
000079035ddd6614  push rax
000079035ddd6615  push rcx
000079035ddd6616  push rdx
000079035ddd6617  push rdi
000079035ddd6618  push rsi
000079035ddd6619  push r8
000079035ddd661b  push r9
000079035ddd661d  push r10
000079035ddd661f  push r11
000079035ddd6621  sub rsp, 0xF0
000079035ddd6628  vmovaps [rsp], xmm0
000079035ddd662d  vmovaps [rsp+0x10], xmm1
000079035ddd6633  vmovaps [rsp+0x20], xmm2
000079035ddd6639  vmovaps [rsp+0x30], xmm3
000079035ddd663f  vmovaps [rsp+0x40], xmm4
000079035ddd6645  vmovaps [rsp+0x50], xmm5
000079035ddd664b  vmovaps [rsp+0x60], xmm6
000079035ddd6651  vmovaps [rsp+0x70], xmm7
000079035ddd6657  vmovaps [rsp+0x80], xmm8
000079035ddd6660  vmovaps [rsp+0x90], xmm9
000079035ddd6669  vmovaps [rsp+0xA0], xmm10
000079035ddd6672  vmovaps [rsp+0xB0], xmm11
000079035ddd667b  vmovaps [rsp+0xC0], xmm12
000079035ddd6684  vmovaps [rsp+0xD0], xmm13
000079035ddd668d  vmovaps [rsp+0xE0], xmm14
000079035ddd6696  sub rsp, 0x30
000079035ddd669a  movaps [rsp], xmm15
000079035ddd669f  movaps [rsp+0x10], xmm14
000079035ddd66a5  movaps [rsp+0x20], xmm5
000079035ddd66aa  lea rdi, [rsp]
000079035ddd66ae  mov esi, 0x00
000079035ddd66b3  mov rax, 0x64ACAA8B0530
000079035ddd66bd  call rax
000079035ddd66bf  movaps xmm15, [rsp]
000079035ddd66c4  add rsp, 0x30
000079035ddd66c8  vmovaps xmm0, [rsp]
000079035ddd66cd  vmovaps xmm1, [rsp+0x10]
000079035ddd66d3  vmovaps xmm2, [rsp+0x20]
000079035ddd66d9  vmovaps xmm3, [rsp+0x30]
000079035ddd66df  vmovaps xmm4, [rsp+0x40]
000079035ddd66e5  vmovaps xmm5, [rsp+0x50]
000079035ddd66eb  vmovaps xmm6, [rsp+0x60]
000079035ddd66f1  vmovaps xmm7, [rsp+0x70]
000079035ddd66f7  vmovaps xmm8, [rsp+0x80]
000079035ddd6700  vmovaps xmm9, [rsp+0x90]
000079035ddd6709  vmovaps xmm10, [rsp+0xA0]
000079035ddd6712  vmovaps xmm11, [rsp+0xB0]
000079035ddd671b  vmovaps xmm12, [rsp+0xC0]
000079035ddd6724  vmovaps xmm13, [rsp+0xD0]
000079035ddd672d  vmovaps xmm14, [rsp+0xE0]
000079035ddd6736  add rsp, 0xF0
000079035ddd673d  pop r11
000079035ddd673f  pop r10
000079035ddd6741  pop r9
000079035ddd6743  pop r8
000079035ddd6745  pop rsi
000079035ddd6746  pop rdi
000079035ddd6747  pop rdx
000079035ddd6748  pop rcx
000079035ddd6749  pop rax
000079035ddd674a  add rsp, 0x08
000079035ddd674e  jmp 0x000079035DDD312B
000079035ddd6753  sub rsp, 0x08
000079035ddd6757  push rax
000079035ddd6758  push rcx
000079035ddd6759  push rdx
000079035ddd675a  push rdi
000079035ddd675b  push rsi
000079035ddd675c  push r8
000079035ddd675e  push r9
000079035ddd6760  push r10
000079035ddd6762  push r11
000079035ddd6764  sub rsp, 0xF0
000079035ddd676b  vmovaps [rsp], xmm0
000079035ddd6770  vmovaps [rsp+0x10], xmm1
000079035ddd6776  vmovaps [rsp+0x20], xmm2
000079035ddd677c  vmovaps [rsp+0x30], xmm3
000079035ddd6782  vmovaps [rsp+0x40], xmm4
000079035ddd6788  vmovaps [rsp+0x50], xmm5
000079035ddd678e  vmovaps [rsp+0x60], xmm7
000079035ddd6794  vmovaps [rsp+0x70], xmm8
000079035ddd679a  vmovaps [rsp+0x80], xmm9
000079035ddd67a3  vmovaps [rsp+0x90], xmm10
000079035ddd67ac  vmovaps [rsp+0xA0], xmm11
000079035ddd67b5  vmovaps [rsp+0xB0], xmm12
000079035ddd67be  vmovaps [rsp+0xC0], xmm13
000079035ddd67c7  vmovaps [rsp+0xD0], xmm14
000079035ddd67d0  vmovaps [rsp+0xE0], xmm15
000079035ddd67d9  sub rsp, 0x30
000079035ddd67dd  movaps [rsp], xmm6
000079035ddd67e1  movaps [rsp+0x10], xmm9
000079035ddd67e7  movaps [rsp+0x20], xmm14
000079035ddd67ed  lea rdi, [rsp]
000079035ddd67f1  mov esi, 0x00
000079035ddd67f6  mov rax, 0x64ACAA8B0530
000079035ddd6800  call rax
000079035ddd6802  movaps xmm6, [rsp]
000079035ddd6806  add rsp, 0x30
000079035ddd680a  vmovaps xmm0, [rsp]
000079035ddd680f  vmovaps xmm1, [rsp+0x10]
000079035ddd6815  vmovaps xmm2, [rsp+0x20]
000079035ddd681b  vmovaps xmm3, [rsp+0x30]
000079035ddd6821  vmovaps xmm4, [rsp+0x40]
000079035ddd6827  vmovaps xmm5, [rsp+0x50]
000079035ddd682d  vmovaps xmm7, [rsp+0x60]
000079035ddd6833  vmovaps xmm8, [rsp+0x70]
000079035ddd6839  vmovaps xmm9, [rsp+0x80]
000079035ddd6842  vmovaps xmm10, [rsp+0x90]
000079035ddd684b  vmovaps xmm11, [rsp+0xA0]
000079035ddd6854  vmovaps xmm12, [rsp+0xB0]
000079035ddd685d  vmovaps xmm13, [rsp+0xC0]
000079035ddd6866  vmovaps xmm14, [rsp+0xD0]
000079035ddd686f  vmovaps xmm15, [rsp+0xE0]
000079035ddd6878  add rsp, 0xF0
000079035ddd687f  pop r11
000079035ddd6881  pop r10
000079035ddd6883  pop r9
000079035ddd6885  pop r8
000079035ddd6887  pop rsi
000079035ddd6888  pop rdi
000079035ddd6889  pop rdx
000079035ddd688a  pop rcx
000079035ddd688b  pop rax
000079035ddd688c  add rsp, 0x08
000079035ddd6890  jmp 0x000079035DDD3153
000079035ddd6895  sub rsp, 0x08
000079035ddd6899  push rax
000079035ddd689a  push rcx
000079035ddd689b  push rdx
000079035ddd689c  push rdi
000079035ddd689d  push rsi
000079035ddd689e  push r8
000079035ddd68a0  push r9
000079035ddd68a2  push r10
000079035ddd68a4  push r11
000079035ddd68a6  sub rsp, 0xF0
000079035ddd68ad  vmovaps [rsp], xmm0
000079035ddd68b2  vmovaps [rsp+0x10], xmm1
000079035ddd68b8  vmovaps [rsp+0x20], xmm2
000079035ddd68be  vmovaps [rsp+0x30], xmm3
000079035ddd68c4  vmovaps [rsp+0x40], xmm4
000079035ddd68ca  vmovaps [rsp+0x50], xmm5
000079035ddd68d0  vmovaps [rsp+0x60], xmm6
000079035ddd68d6  vmovaps [rsp+0x70], xmm7
000079035ddd68dc  vmovaps [rsp+0x80], xmm8
000079035ddd68e5  vmovaps [rsp+0x90], xmm9
000079035ddd68ee  vmovaps [rsp+0xA0], xmm10
000079035ddd68f7  vmovaps [rsp+0xB0], xmm11
000079035ddd6900  vmovaps [rsp+0xC0], xmm12
000079035ddd6909  vmovaps [rsp+0xD0], xmm13
000079035ddd6912  vmovaps [rsp+0xE0], xmm15
000079035ddd691b  sub rsp, 0x30
000079035ddd691f  movaps [rsp], xmm14
000079035ddd6924  movaps [rsp+0x10], xmm9
000079035ddd692a  movaps [rsp+0x20], xmm13
000079035ddd6930  lea rdi, [rsp]
000079035ddd6934  mov esi, 0x00
000079035ddd6939  mov rax, 0x64ACAA8B0530
000079035ddd6943  call rax
000079035ddd6945  movaps xmm14, [rsp]
000079035ddd694a  add rsp, 0x30
000079035ddd694e  vmovaps xmm0, [rsp]
000079035ddd6953  vmovaps xmm1, [rsp+0x10]
000079035ddd6959  vmovaps xmm2, [rsp+0x20]
000079035ddd695f  vmovaps xmm3, [rsp+0x30]
000079035ddd6965  vmovaps xmm4, [rsp+0x40]
000079035ddd696b  vmovaps xmm5, [rsp+0x50]
000079035ddd6971  vmovaps xmm6, [rsp+0x60]
000079035ddd6977  vmovaps xmm7, [rsp+0x70]
000079035ddd697d  vmovaps xmm8, [rsp+0x80]
000079035ddd6986  vmovaps xmm9, [rsp+0x90]
000079035ddd698f  vmovaps xmm10, [rsp+0xA0]
000079035ddd6998  vmovaps xmm11, [rsp+0xB0]
000079035ddd69a1  vmovaps xmm12, [rsp+0xC0]
000079035ddd69aa  vmovaps xmm13, [rsp+0xD0]
000079035ddd69b3  vmovaps xmm15, [rsp+0xE0]
000079035ddd69bc  add rsp, 0xF0
000079035ddd69c3  pop r11
000079035ddd69c5  pop r10
000079035ddd69c7  pop r9
000079035ddd69c9  pop r8
000079035ddd69cb  pop rsi
000079035ddd69cc  pop rdi
000079035ddd69cd  pop rdx
000079035ddd69ce  pop rcx
000079035ddd69cf  pop rax
000079035ddd69d0  add rsp, 0x08
000079035ddd69d4  jmp 0x000079035DDD3176
000079035ddd69d9  sub rsp, 0x08
000079035ddd69dd  push rax
000079035ddd69de  push rcx
000079035ddd69df  push rdx
000079035ddd69e0  push rdi
000079035ddd69e1  push rsi
000079035ddd69e2  push r8
000079035ddd69e4  push r9
000079035ddd69e6  push r10
000079035ddd69e8  push r11
000079035ddd69ea  sub rsp, 0xF0
000079035ddd69f1  vmovaps [rsp], xmm0
000079035ddd69f6  vmovaps [rsp+0x10], xmm1
000079035ddd69fc  vmovaps [rsp+0x20], xmm2
000079035ddd6a02  vmovaps [rsp+0x30], xmm3
000079035ddd6a08  vmovaps [rsp+0x40], xmm4
000079035ddd6a0e  vmovaps [rsp+0x50], xmm5
000079035ddd6a14  vmovaps [rsp+0x60], xmm6
000079035ddd6a1a  vmovaps [rsp+0x70], xmm7
000079035ddd6a20  vmovaps [rsp+0x80], xmm8
000079035ddd6a29  vmovaps [rsp+0x90], xmm9
000079035ddd6a32  vmovaps [rsp+0xA0], xmm10
000079035ddd6a3b  vmovaps [rsp+0xB0], xmm11
000079035ddd6a44  vmovaps [rsp+0xC0], xmm12
000079035ddd6a4d  vmovaps [rsp+0xD0], xmm14
000079035ddd6a56  vmovaps [rsp+0xE0], xmm15
000079035ddd6a5f  sub rsp, 0x30
000079035ddd6a63  movaps [rsp], xmm13
000079035ddd6a68  movaps [rsp+0x10], xmm9
000079035ddd6a6e  movaps [rsp+0x20], xmm10
000079035ddd6a74  lea rdi, [rsp]
000079035ddd6a78  mov esi, 0x00
000079035ddd6a7d  mov rax, 0x64ACAA8B0530
000079035ddd6a87  call rax
000079035ddd6a89  movaps xmm13, [rsp]
000079035ddd6a8e  add rsp, 0x30
000079035ddd6a92  vmovaps xmm0, [rsp]
000079035ddd6a97  vmovaps xmm1, [rsp+0x10]
000079035ddd6a9d  vmovaps xmm2, [rsp+0x20]
000079035ddd6aa3  vmovaps xmm3, [rsp+0x30]
000079035ddd6aa9  vmovaps xmm4, [rsp+0x40]
000079035ddd6aaf  vmovaps xmm5, [rsp+0x50]
000079035ddd6ab5  vmovaps xmm6, [rsp+0x60]
000079035ddd6abb  vmovaps xmm7, [rsp+0x70]
000079035ddd6ac1  vmovaps xmm8, [rsp+0x80]
000079035ddd6aca  vmovaps xmm9, [rsp+0x90]
000079035ddd6ad3  vmovaps xmm10, [rsp+0xA0]
000079035ddd6adc  vmovaps xmm11, [rsp+0xB0]
000079035ddd6ae5  vmovaps xmm12, [rsp+0xC0]
000079035ddd6aee  vmovaps xmm14, [rsp+0xD0]
000079035ddd6af7  vmovaps xmm15, [rsp+0xE0]
000079035ddd6b00  add rsp, 0xF0
000079035ddd6b07  pop r11
000079035ddd6b09  pop r10
000079035ddd6b0b  pop r9
000079035ddd6b0d  pop r8
000079035ddd6b0f  pop rsi
000079035ddd6b10  pop rdi
000079035ddd6b11  pop rdx
000079035ddd6b12  pop rcx
000079035ddd6b13  pop rax
000079035ddd6b14  add rsp, 0x08
000079035ddd6b18  jmp 0x000079035DDD3196
000079035ddd6b1d  call 0x000079035DC0AFE0
000079035ddd6b22  jmp 0x000079035DDD31EB
000079035ddd6b27  sub rsp, 0x08
000079035ddd6b2b  push rax
000079035ddd6b2c  push rcx
000079035ddd6b2d  push rdx
000079035ddd6b2e  push rdi
000079035ddd6b2f  push rsi
000079035ddd6b30  push r8
000079035ddd6b32  push r9
000079035ddd6b34  push r10
000079035ddd6b36  push r11
000079035ddd6b38  sub rsp, 0xF0
000079035ddd6b3f  vmovaps [rsp], xmm0
000079035ddd6b44  vmovaps [rsp+0x10], xmm1
000079035ddd6b4a  vmovaps [rsp+0x20], xmm2
000079035ddd6b50  vmovaps [rsp+0x30], xmm3
000079035ddd6b56  vmovaps [rsp+0x40], xmm4
000079035ddd6b5c  vmovaps [rsp+0x50], xmm5
000079035ddd6b62  vmovaps [rsp+0x60], xmm6
000079035ddd6b68  vmovaps [rsp+0x70], xmm7
000079035ddd6b6e  vmovaps [rsp+0x80], xmm8
000079035ddd6b77  vmovaps [rsp+0x90], xmm10
000079035ddd6b80  vmovaps [rsp+0xA0], xmm11
000079035ddd6b89  vmovaps [rsp+0xB0], xmm12
000079035ddd6b92  vmovaps [rsp+0xC0], xmm13
000079035ddd6b9b  vmovaps [rsp+0xD0], xmm14
000079035ddd6ba4  vmovaps [rsp+0xE0], xmm15
000079035ddd6bad  sub rsp, 0x30
000079035ddd6bb1  movaps [rsp], xmm9
000079035ddd6bb6  movaps [rsp+0x10], xmm8
000079035ddd6bbc  movaps [rsp+0x20], xmm10
000079035ddd6bc2  lea rdi, [rsp]
000079035ddd6bc6  mov esi, 0x00
000079035ddd6bcb  mov rax, 0x64ACAA8B0530
000079035ddd6bd5  call rax
000079035ddd6bd7  movaps xmm9, [rsp]
000079035ddd6bdc  add rsp, 0x30
000079035ddd6be0  vmovaps xmm0, [rsp]
000079035ddd6be5  vmovaps xmm1, [rsp+0x10]
000079035ddd6beb  vmovaps xmm2, [rsp+0x20]
000079035ddd6bf1  vmovaps xmm3, [rsp+0x30]
000079035ddd6bf7  vmovaps xmm4, [rsp+0x40]
000079035ddd6bfd  vmovaps xmm5, [rsp+0x50]
000079035ddd6c03  vmovaps xmm6, [rsp+0x60]
000079035ddd6c09  vmovaps xmm7, [rsp+0x70]
000079035ddd6c0f  vmovaps xmm8, [rsp+0x80]
000079035ddd6c18  vmovaps xmm10, [rsp+0x90]
000079035ddd6c21  vmovaps xmm11, [rsp+0xA0]
000079035ddd6c2a  vmovaps xmm12, [rsp+0xB0]
000079035ddd6c33  vmovaps xmm13, [rsp+0xC0]
000079035ddd6c3c  vmovaps xmm14, [rsp+0xD0]
000079035ddd6c45  vmovaps xmm15, [rsp+0xE0]
000079035ddd6c4e  add rsp, 0xF0
000079035ddd6c55  pop r11
000079035ddd6c57  pop r10
000079035ddd6c59  pop r9
000079035ddd6c5b  pop r8
000079035ddd6c5d  pop rsi
000079035ddd6c5e  pop rdi
000079035ddd6c5f  pop rdx
000079035ddd6c60  pop rcx
000079035ddd6c61  pop rax
000079035ddd6c62  add rsp, 0x08
000079035ddd6c66  jmp 0x000079035DDD321C
000079035ddd6c6b  sub rsp, 0x08
000079035ddd6c6f  push rax
000079035ddd6c70  push rcx
000079035ddd6c71  push rdx
000079035ddd6c72  push rdi
000079035ddd6c73  push rsi
000079035ddd6c74  push r8
000079035ddd6c76  push r9
000079035ddd6c78  push r10
000079035ddd6c7a  push r11
000079035ddd6c7c  sub rsp, 0xF0
000079035ddd6c83  vmovaps [rsp], xmm0
000079035ddd6c88  vmovaps [rsp+0x10], xmm1
000079035ddd6c8e  vmovaps [rsp+0x20], xmm2
000079035ddd6c94  vmovaps [rsp+0x30], xmm3
000079035ddd6c9a  vmovaps [rsp+0x40], xmm4
000079035ddd6ca0  vmovaps [rsp+0x50], xmm5
000079035ddd6ca6  vmovaps [rsp+0x60], xmm6
000079035ddd6cac  vmovaps [rsp+0x70], xmm7
000079035ddd6cb2  vmovaps [rsp+0x80], xmm8
000079035ddd6cbb  vmovaps [rsp+0x90], xmm9
000079035ddd6cc4  vmovaps [rsp+0xA0], xmm11
000079035ddd6ccd  vmovaps [rsp+0xB0], xmm12
000079035ddd6cd6  vmovaps [rsp+0xC0], xmm13
000079035ddd6cdf  vmovaps [rsp+0xD0], xmm14
000079035ddd6ce8  vmovaps [rsp+0xE0], xmm15
000079035ddd6cf1  sub rsp, 0x30
000079035ddd6cf5  movaps [rsp], xmm10
000079035ddd6cfa  movaps [rsp+0x10], xmm1
000079035ddd6cff  movaps [rsp+0x20], xmm11
000079035ddd6d05  lea rdi, [rsp]
000079035ddd6d09  mov esi, 0x00
000079035ddd6d0e  mov rax, 0x64ACAA8B0530
000079035ddd6d18  call rax
000079035ddd6d1a  movaps xmm10, [rsp]
000079035ddd6d1f  add rsp, 0x30
000079035ddd6d23  vmovaps xmm0, [rsp]
000079035ddd6d28  vmovaps xmm1, [rsp+0x10]
000079035ddd6d2e  vmovaps xmm2, [rsp+0x20]
000079035ddd6d34  vmovaps xmm3, [rsp+0x30]
000079035ddd6d3a  vmovaps xmm4, [rsp+0x40]
000079035ddd6d40  vmovaps xmm5, [rsp+0x50]
000079035ddd6d46  vmovaps xmm6, [rsp+0x60]
000079035ddd6d4c  vmovaps xmm7, [rsp+0x70]
000079035ddd6d52  vmovaps xmm8, [rsp+0x80]
000079035ddd6d5b  vmovaps xmm9, [rsp+0x90]
000079035ddd6d64  vmovaps xmm11, [rsp+0xA0]
000079035ddd6d6d  vmovaps xmm12, [rsp+0xB0]
000079035ddd6d76  vmovaps xmm13, [rsp+0xC0]
000079035ddd6d7f  vmovaps xmm14, [rsp+0xD0]
000079035ddd6d88  vmovaps xmm15, [rsp+0xE0]
000079035ddd6d91  add rsp, 0xF0
000079035ddd6d98  pop r11
000079035ddd6d9a  pop r10
000079035ddd6d9c  pop r9
000079035ddd6d9e  pop r8
000079035ddd6da0  pop rsi
000079035ddd6da1  pop rdi
000079035ddd6da2  pop rdx
000079035ddd6da3  pop rcx
000079035ddd6da4  pop rax
000079035ddd6da5  add rsp, 0x08
000079035ddd6da9  jmp 0x000079035DDD3237
000079035ddd6dae  sub rsp, 0x08
000079035ddd6db2  push rax
000079035ddd6db3  push rcx
000079035ddd6db4  push rdx
000079035ddd6db5  push rdi
000079035ddd6db6  push rsi
000079035ddd6db7  push r8
000079035ddd6db9  push r9
000079035ddd6dbb  push r10
000079035ddd6dbd  push r11
000079035ddd6dbf  sub rsp, 0xF0
000079035ddd6dc6  vmovaps [rsp], xmm0
000079035ddd6dcb  vmovaps [rsp+0x10], xmm2
000079035ddd6dd1  vmovaps [rsp+0x20], xmm3
000079035ddd6dd7  vmovaps [rsp+0x30], xmm4
000079035ddd6ddd  vmovaps [rsp+0x40], xmm5
000079035ddd6de3  vmovaps [rsp+0x50], xmm6
000079035ddd6de9  vmovaps [rsp+0x60], xmm7
000079035ddd6def  vmovaps [rsp+0x70], xmm8
000079035ddd6df5  vmovaps [rsp+0x80], xmm9
000079035ddd6dfe  vmovaps [rsp+0x90], xmm10
000079035ddd6e07  vmovaps [rsp+0xA0], xmm11
000079035ddd6e10  vmovaps [rsp+0xB0], xmm12
000079035ddd6e19  vmovaps [rsp+0xC0], xmm13
000079035ddd6e22  vmovaps [rsp+0xD0], xmm14
000079035ddd6e2b  vmovaps [rsp+0xE0], xmm15
000079035ddd6e34  sub rsp, 0x30
000079035ddd6e38  movaps [rsp], xmm1
000079035ddd6e3c  movaps [rsp+0x10], xmm15
000079035ddd6e42  movaps [rsp+0x20], xmm6
000079035ddd6e47  lea rdi, [rsp]
000079035ddd6e4b  mov esi, 0x00
000079035ddd6e50  mov rax, 0x64ACAA8B0530
000079035ddd6e5a  call rax
000079035ddd6e5c  movaps xmm1, [rsp]
000079035ddd6e60  add rsp, 0x30
000079035ddd6e64  vmovaps xmm0, [rsp]
000079035ddd6e69  vmovaps xmm2, [rsp+0x10]
000079035ddd6e6f  vmovaps xmm3, [rsp+0x20]
000079035ddd6e75  vmovaps xmm4, [rsp+0x30]
000079035ddd6e7b  vmovaps xmm5, [rsp+0x40]
000079035ddd6e81  vmovaps xmm6, [rsp+0x50]
000079035ddd6e87  vmovaps xmm7, [rsp+0x60]
000079035ddd6e8d  vmovaps xmm8, [rsp+0x70]
000079035ddd6e93  vmovaps xmm9, [rsp+0x80]
000079035ddd6e9c  vmovaps xmm10, [rsp+0x90]
000079035ddd6ea5  vmovaps xmm11, [rsp+0xA0]
000079035ddd6eae  vmovaps xmm12, [rsp+0xB0]
000079035ddd6eb7  vmovaps xmm13, [rsp+0xC0]
000079035ddd6ec0  vmovaps xmm14, [rsp+0xD0]
000079035ddd6ec9  vmovaps xmm15, [rsp+0xE0]
000079035ddd6ed2  add rsp, 0xF0
000079035ddd6ed9  pop r11
000079035ddd6edb  pop r10
000079035ddd6edd  pop r9
000079035ddd6edf  pop r8
000079035ddd6ee1  pop rsi
000079035ddd6ee2  pop rdi
000079035ddd6ee3  pop rdx
000079035ddd6ee4  pop rcx
000079035ddd6ee5  pop rax
000079035ddd6ee6  add rsp, 0x08
000079035ddd6eea  jmp 0x000079035DDD3250
000079035ddd6eef  sub rsp, 0x08
000079035ddd6ef3  push rax
000079035ddd6ef4  push rcx
000079035ddd6ef5  push rdx
000079035ddd6ef6  push rdi
000079035ddd6ef7  push rsi
000079035ddd6ef8  push r8
000079035ddd6efa  push r9
000079035ddd6efc  push r10
000079035ddd6efe  push r11
000079035ddd6f00  sub rsp, 0xF0
000079035ddd6f07  vmovaps [rsp], xmm0
000079035ddd6f0c  vmovaps [rsp+0x10], xmm1
000079035ddd6f12  vmovaps [rsp+0x20], xmm2
000079035ddd6f18  vmovaps [rsp+0x30], xmm3
000079035ddd6f1e  vmovaps [rsp+0x40], xmm4
000079035ddd6f24  vmovaps [rsp+0x50], xmm5
000079035ddd6f2a  vmovaps [rsp+0x60], xmm6
000079035ddd6f30  vmovaps [rsp+0x70], xmm7
000079035ddd6f36  vmovaps [rsp+0x80], xmm8
000079035ddd6f3f  vmovaps [rsp+0x90], xmm9
000079035ddd6f48  vmovaps [rsp+0xA0], xmm10
000079035ddd6f51  vmovaps [rsp+0xB0], xmm12
000079035ddd6f5a  vmovaps [rsp+0xC0], xmm13
000079035ddd6f63  vmovaps [rsp+0xD0], xmm14
000079035ddd6f6c  vmovaps [rsp+0xE0], xmm15
000079035ddd6f75  sub rsp, 0x30
000079035ddd6f79  movaps [rsp], xmm11
000079035ddd6f7e  movaps [rsp+0x10], xmm12
000079035ddd6f84  movaps [rsp+0x20], xmm15
000079035ddd6f8a  lea rdi, [rsp]
000079035ddd6f8e  mov esi, 0x00
000079035ddd6f93  mov rax, 0x64ACAA8B0530
000079035ddd6f9d  call rax
000079035ddd6f9f  movaps xmm11, [rsp]
000079035ddd6fa4  add rsp, 0x30
000079035ddd6fa8  vmovaps xmm0, [rsp]
000079035ddd6fad  vmovaps xmm1, [rsp+0x10]
000079035ddd6fb3  vmovaps xmm2, [rsp+0x20]
000079035ddd6fb9  vmovaps xmm3, [rsp+0x30]
000079035ddd6fbf  vmovaps xmm4, [rsp+0x40]
000079035ddd6fc5  vmovaps xmm5, [rsp+0x50]
000079035ddd6fcb  vmovaps xmm6, [rsp+0x60]
000079035ddd6fd1  vmovaps xmm7, [rsp+0x70]
000079035ddd6fd7  vmovaps xmm8, [rsp+0x80]
000079035ddd6fe0  vmovaps xmm9, [rsp+0x90]
000079035ddd6fe9  vmovaps xmm10, [rsp+0xA0]
000079035ddd6ff2  vmovaps xmm12, [rsp+0xB0]
000079035ddd6ffb  vmovaps xmm13, [rsp+0xC0]
000079035ddd7004  vmovaps xmm14, [rsp+0xD0]
000079035ddd700d  vmovaps xmm15, [rsp+0xE0]
000079035ddd7016  add rsp, 0xF0
000079035ddd701d  pop r11
000079035ddd701f  pop r10
000079035ddd7021  pop r9
000079035ddd7023  pop r8
000079035ddd7025  pop rsi
000079035ddd7026  pop rdi
000079035ddd7027  pop rdx
000079035ddd7028  pop rcx
000079035ddd7029  pop rax
000079035ddd702a  add rsp, 0x08
000079035ddd702e  jmp 0x000079035DDD327A
000079035ddd7033  sub rsp, 0x08
000079035ddd7037  push rax
000079035ddd7038  push rcx
000079035ddd7039  push rdx
000079035ddd703a  push rdi
000079035ddd703b  push rsi
000079035ddd703c  push r8
000079035ddd703e  push r9
000079035ddd7040  push r10
000079035ddd7042  push r11
000079035ddd7044  sub rsp, 0xF0
000079035ddd704b  vmovaps [rsp], xmm0
000079035ddd7050  vmovaps [rsp+0x10], xmm1
000079035ddd7056  vmovaps [rsp+0x20], xmm2
000079035ddd705c  vmovaps [rsp+0x30], xmm3
000079035ddd7062  vmovaps [rsp+0x40], xmm4
000079035ddd7068  vmovaps [rsp+0x50], xmm5
000079035ddd706e  vmovaps [rsp+0x60], xmm6
000079035ddd7074  vmovaps [rsp+0x70], xmm7
000079035ddd707a  vmovaps [rsp+0x80], xmm8
000079035ddd7083  vmovaps [rsp+0x90], xmm9
000079035ddd708c  vmovaps [rsp+0xA0], xmm10
000079035ddd7095  vmovaps [rsp+0xB0], xmm11
000079035ddd709e  vmovaps [rsp+0xC0], xmm13
000079035ddd70a7  vmovaps [rsp+0xD0], xmm14
000079035ddd70b0  vmovaps [rsp+0xE0], xmm15
000079035ddd70b9  sub rsp, 0x30
000079035ddd70bd  movaps [rsp], xmm12
000079035ddd70c2  movaps [rsp+0x10], xmm8
000079035ddd70c8  movaps [rsp+0x20], xmm15
000079035ddd70ce  lea rdi, [rsp]
000079035ddd70d2  mov esi, 0x00
000079035ddd70d7  mov rax, 0x64ACAA8B0530
000079035ddd70e1  call rax
000079035ddd70e3  movaps xmm12, [rsp]
000079035ddd70e8  add rsp, 0x30
000079035ddd70ec  vmovaps xmm0, [rsp]
000079035ddd70f1  vmovaps xmm1, [rsp+0x10]
000079035ddd70f7  vmovaps xmm2, [rsp+0x20]
000079035ddd70fd  vmovaps xmm3, [rsp+0x30]
000079035ddd7103  vmovaps xmm4, [rsp+0x40]
000079035ddd7109  vmovaps xmm5, [rsp+0x50]
000079035ddd710f  vmovaps xmm6, [rsp+0x60]
000079035ddd7115  vmovaps xmm7, [rsp+0x70]
000079035ddd711b  vmovaps xmm8, [rsp+0x80]
000079035ddd7124  vmovaps xmm9, [rsp+0x90]
000079035ddd712d  vmovaps xmm10, [rsp+0xA0]
000079035ddd7136  vmovaps xmm11, [rsp+0xB0]
000079035ddd713f  vmovaps xmm13, [rsp+0xC0]
000079035ddd7148  vmovaps xmm14, [rsp+0xD0]
000079035ddd7151  vmovaps xmm15, [rsp+0xE0]
000079035ddd715a  add rsp, 0xF0
000079035ddd7161  pop r11
000079035ddd7163  pop r10
000079035ddd7165  pop r9
000079035ddd7167  pop r8
000079035ddd7169  pop rsi
000079035ddd716a  pop rdi
000079035ddd716b  pop rdx
000079035ddd716c  pop rcx
000079035ddd716d  pop rax
000079035ddd716e  add rsp, 0x08
000079035ddd7172  jmp 0x000079035DDD32A9
000079035ddd7177  sub rsp, 0x08
000079035ddd717b  push rax
000079035ddd717c  push rcx
000079035ddd717d  push rdx
000079035ddd717e  push rdi
000079035ddd717f  push rsi
000079035ddd7180  push r8
000079035ddd7182  push r9
000079035ddd7184  push r10
000079035ddd7186  push r11
000079035ddd7188  sub rsp, 0xF0
000079035ddd718f  vmovaps [rsp], xmm0
000079035ddd7194  vmovaps [rsp+0x10], xmm1
000079035ddd719a  vmovaps [rsp+0x20], xmm2
000079035ddd71a0  vmovaps [rsp+0x30], xmm3
000079035ddd71a6  vmovaps [rsp+0x40], xmm4
000079035ddd71ac  vmovaps [rsp+0x50], xmm5
000079035ddd71b2  vmovaps [rsp+0x60], xmm6
000079035ddd71b8  vmovaps [rsp+0x70], xmm7
000079035ddd71be  vmovaps [rsp+0x80], xmm9
000079035ddd71c7  vmovaps [rsp+0x90], xmm10
000079035ddd71d0  vmovaps [rsp+0xA0], xmm11
000079035ddd71d9  vmovaps [rsp+0xB0], xmm12
000079035ddd71e2  vmovaps [rsp+0xC0], xmm13
000079035ddd71eb  vmovaps [rsp+0xD0], xmm14
000079035ddd71f4  vmovaps [rsp+0xE0], xmm15
000079035ddd71fd  sub rsp, 0x30
000079035ddd7201  movaps [rsp], xmm8
000079035ddd7206  movaps [rsp+0x10], xmm7
000079035ddd720b  movaps [rsp+0x20], xmm15
000079035ddd7211  lea rdi, [rsp]
000079035ddd7215  mov esi, 0x00
000079035ddd721a  mov rax, 0x64ACAA8B0530
000079035ddd7224  call rax
000079035ddd7226  movaps xmm8, [rsp]
000079035ddd722b  add rsp, 0x30
000079035ddd722f  vmovaps xmm0, [rsp]
000079035ddd7234  vmovaps xmm1, [rsp+0x10]
000079035ddd723a  vmovaps xmm2, [rsp+0x20]
000079035ddd7240  vmovaps xmm3, [rsp+0x30]
000079035ddd7246  vmovaps xmm4, [rsp+0x40]
000079035ddd724c  vmovaps xmm5, [rsp+0x50]
000079035ddd7252  vmovaps xmm6, [rsp+0x60]
000079035ddd7258  vmovaps xmm7, [rsp+0x70]
000079035ddd725e  vmovaps xmm9, [rsp+0x80]
000079035ddd7267  vmovaps xmm10, [rsp+0x90]
000079035ddd7270  vmovaps xmm11, [rsp+0xA0]
000079035ddd7279  vmovaps xmm12, [rsp+0xB0]
000079035ddd7282  vmovaps xmm13, [rsp+0xC0]
000079035ddd728b  vmovaps xmm14, [rsp+0xD0]
000079035ddd7294  vmovaps xmm15, [rsp+0xE0]
000079035ddd729d  add rsp, 0xF0
000079035ddd72a4  pop r11
000079035ddd72a6  pop r10
000079035ddd72a8  pop r9
000079035ddd72aa  pop r8
000079035ddd72ac  pop rsi
000079035ddd72ad  pop rdi
000079035ddd72ae  pop rdx
000079035ddd72af  pop rcx
000079035ddd72b0  pop rax
000079035ddd72b1  add rsp, 0x08
000079035ddd72b5  jmp 0x000079035DDD32CF
000079035ddd72ba  sub rsp, 0x08
000079035ddd72be  push rax
000079035ddd72bf  push rcx
000079035ddd72c0  push rdx
000079035ddd72c1  push rdi
000079035ddd72c2  push rsi
000079035ddd72c3  push r8
000079035ddd72c5  push r9
000079035ddd72c7  push r10
000079035ddd72c9  push r11
000079035ddd72cb  sub rsp, 0xF0
000079035ddd72d2  vmovaps [rsp], xmm0
000079035ddd72d7  vmovaps [rsp+0x10], xmm1
000079035ddd72dd  vmovaps [rsp+0x20], xmm2
000079035ddd72e3  vmovaps [rsp+0x30], xmm3
000079035ddd72e9  vmovaps [rsp+0x40], xmm4
000079035ddd72ef  vmovaps [rsp+0x50], xmm5
000079035ddd72f5  vmovaps [rsp+0x60], xmm6
000079035ddd72fb  vmovaps [rsp+0x70], xmm7
000079035ddd7301  vmovaps [rsp+0x80], xmm8
000079035ddd730a  vmovaps [rsp+0x90], xmm9
000079035ddd7313  vmovaps [rsp+0xA0], xmm10
000079035ddd731c  vmovaps [rsp+0xB0], xmm11
000079035ddd7325  vmovaps [rsp+0xC0], xmm12
000079035ddd732e  vmovaps [rsp+0xD0], xmm13
000079035ddd7337  vmovaps [rsp+0xE0], xmm14
000079035ddd7340  sub rsp, 0x30
000079035ddd7344  movaps [rsp], xmm15
000079035ddd7349  movaps [rsp+0x10], xmm14
000079035ddd734f  movaps [rsp+0x20], xmm9
000079035ddd7355  lea rdi, [rsp]
000079035ddd7359  mov esi, 0x00
000079035ddd735e  mov rax, 0x64ACAA8B0530
000079035ddd7368  call rax
000079035ddd736a  movaps xmm15, [rsp]
000079035ddd736f  add rsp, 0x30
000079035ddd7373  vmovaps xmm0, [rsp]
000079035ddd7378  vmovaps xmm1, [rsp+0x10]
000079035ddd737e  vmovaps xmm2, [rsp+0x20]
000079035ddd7384  vmovaps xmm3, [rsp+0x30]
000079035ddd738a  vmovaps xmm4, [rsp+0x40]
000079035ddd7390  vmovaps xmm5, [rsp+0x50]
000079035ddd7396  vmovaps xmm6, [rsp+0x60]
000079035ddd739c  vmovaps xmm7, [rsp+0x70]
000079035ddd73a2  vmovaps xmm8, [rsp+0x80]
000079035ddd73ab  vmovaps xmm9, [rsp+0x90]
000079035ddd73b4  vmovaps xmm10, [rsp+0xA0]
000079035ddd73bd  vmovaps xmm11, [rsp+0xB0]
000079035ddd73c6  vmovaps xmm12, [rsp+0xC0]
000079035ddd73cf  vmovaps xmm13, [rsp+0xD0]
000079035ddd73d8  vmovaps xmm14, [rsp+0xE0]
000079035ddd73e1  add rsp, 0xF0
000079035ddd73e8  pop r11
000079035ddd73ea  pop r10
000079035ddd73ec  pop r9
000079035ddd73ee  pop r8
000079035ddd73f0  pop rsi
000079035ddd73f1  pop rdi
000079035ddd73f2  pop rdx
000079035ddd73f3  pop rcx
000079035ddd73f4  pop rax
000079035ddd73f5  add rsp, 0x08
000079035ddd73f9  jmp 0x000079035DDD32E9
000079035ddd73fe  sub rsp, 0x08
000079035ddd7402  push rax
000079035ddd7403  push rcx
000079035ddd7404  push rdx
000079035ddd7405  push rdi
000079035ddd7406  push rsi
000079035ddd7407  push r8
000079035ddd7409  push r9
000079035ddd740b  push r10
000079035ddd740d  push r11
000079035ddd740f  sub rsp, 0xF0
000079035ddd7416  vmovaps [rsp], xmm0
000079035ddd741b  vmovaps [rsp+0x10], xmm1
000079035ddd7421  vmovaps [rsp+0x20], xmm2
000079035ddd7427  vmovaps [rsp+0x30], xmm3
000079035ddd742d  vmovaps [rsp+0x40], xmm4
000079035ddd7433  vmovaps [rsp+0x50], xmm5
000079035ddd7439  vmovaps [rsp+0x60], xmm6
000079035ddd743f  vmovaps [rsp+0x70], xmm7
000079035ddd7445  vmovaps [rsp+0x80], xmm8
000079035ddd744e  vmovaps [rsp+0x90], xmm10
000079035ddd7457  vmovaps [rsp+0xA0], xmm11
000079035ddd7460  vmovaps [rsp+0xB0], xmm12
000079035ddd7469  vmovaps [rsp+0xC0], xmm13
000079035ddd7472  vmovaps [rsp+0xD0], xmm14
000079035ddd747b  vmovaps [rsp+0xE0], xmm15
000079035ddd7484  sub rsp, 0x30
000079035ddd7488  movaps [rsp], xmm9
000079035ddd748d  movaps [rsp+0x10], xmm7
000079035ddd7492  movaps [rsp+0x20], xmm14
000079035ddd7498  lea rdi, [rsp]
000079035ddd749c  mov esi, 0x00
000079035ddd74a1  mov rax, 0x64ACAA8B0530
000079035ddd74ab  call rax
000079035ddd74ad  movaps xmm9, [rsp]
000079035ddd74b2  add rsp, 0x30
000079035ddd74b6  vmovaps xmm0, [rsp]
000079035ddd74bb  vmovaps xmm1, [rsp+0x10]
000079035ddd74c1  vmovaps xmm2, [rsp+0x20]
000079035ddd74c7  vmovaps xmm3, [rsp+0x30]
000079035ddd74cd  vmovaps xmm4, [rsp+0x40]
000079035ddd74d3  vmovaps xmm5, [rsp+0x50]
000079035ddd74d9  vmovaps xmm6, [rsp+0x60]
000079035ddd74df  vmovaps xmm7, [rsp+0x70]
000079035ddd74e5  vmovaps xmm8, [rsp+0x80]
000079035ddd74ee  vmovaps xmm10, [rsp+0x90]
000079035ddd74f7  vmovaps xmm11, [rsp+0xA0]
000079035ddd7500  vmovaps xmm12, [rsp+0xB0]
000079035ddd7509  vmovaps xmm13, [rsp+0xC0]
000079035ddd7512  vmovaps xmm14, [rsp+0xD0]
000079035ddd751b  vmovaps xmm15, [rsp+0xE0]
000079035ddd7524  add rsp, 0xF0
000079035ddd752b  pop r11
000079035ddd752d  pop r10
000079035ddd752f  pop r9
000079035ddd7531  pop r8
000079035ddd7533  pop rsi
000079035ddd7534  pop rdi
000079035ddd7535  pop rdx
000079035ddd7536  pop rcx
000079035ddd7537  pop rax
000079035ddd7538  add rsp, 0x08
000079035ddd753c  jmp 0x000079035DDD3318
000079035ddd7541  sub rsp, 0x08
000079035ddd7545  push rax
000079035ddd7546  push rcx
000079035ddd7547  push rdx
000079035ddd7548  push rdi
000079035ddd7549  push rsi
000079035ddd754a  push r8
000079035ddd754c  push r9
000079035ddd754e  push r10
000079035ddd7550  push r11
000079035ddd7552  sub rsp, 0xF0
000079035ddd7559  vmovaps [rsp], xmm0
000079035ddd755e  vmovaps [rsp+0x10], xmm1
000079035ddd7564  vmovaps [rsp+0x20], xmm2
000079035ddd756a  vmovaps [rsp+0x30], xmm3
000079035ddd7570  vmovaps [rsp+0x40], xmm4
000079035ddd7576  vmovaps [rsp+0x50], xmm5
000079035ddd757c  vmovaps [rsp+0x60], xmm6
000079035ddd7582  vmovaps [rsp+0x70], xmm7
000079035ddd7588  vmovaps [rsp+0x80], xmm8
000079035ddd7591  vmovaps [rsp+0x90], xmm9
000079035ddd759a  vmovaps [rsp+0xA0], xmm10
000079035ddd75a3  vmovaps [rsp+0xB0], xmm11
000079035ddd75ac  vmovaps [rsp+0xC0], xmm12
000079035ddd75b5  vmovaps [rsp+0xD0], xmm13
000079035ddd75be  vmovaps [rsp+0xE0], xmm15
000079035ddd75c7  sub rsp, 0x30
000079035ddd75cb  movaps [rsp], xmm14
000079035ddd75d0  movaps [rsp+0x10], xmm13
000079035ddd75d6  movaps [rsp+0x20], xmm11
000079035ddd75dc  lea rdi, [rsp]
000079035ddd75e0  mov esi, 0x00
000079035ddd75e5  mov rax, 0x64ACAA8B0530
000079035ddd75ef  call rax
000079035ddd75f1  movaps xmm14, [rsp]
000079035ddd75f6  add rsp, 0x30
000079035ddd75fa  vmovaps xmm0, [rsp]
000079035ddd75ff  vmovaps xmm1, [rsp+0x10]
000079035ddd7605  vmovaps xmm2, [rsp+0x20]
000079035ddd760b  vmovaps xmm3, [rsp+0x30]
000079035ddd7611  vmovaps xmm4, [rsp+0x40]
000079035ddd7617  vmovaps xmm5, [rsp+0x50]
000079035ddd761d  vmovaps xmm6, [rsp+0x60]
000079035ddd7623  vmovaps xmm7, [rsp+0x70]
000079035ddd7629  vmovaps xmm8, [rsp+0x80]
000079035ddd7632  vmovaps xmm9, [rsp+0x90]
000079035ddd763b  vmovaps xmm10, [rsp+0xA0]
000079035ddd7644  vmovaps xmm11, [rsp+0xB0]
000079035ddd764d  vmovaps xmm12, [rsp+0xC0]
000079035ddd7656  vmovaps xmm13, [rsp+0xD0]
000079035ddd765f  vmovaps xmm15, [rsp+0xE0]
000079035ddd7668  add rsp, 0xF0
000079035ddd766f  pop r11
000079035ddd7671  pop r10
000079035ddd7673  pop r9
000079035ddd7675  pop r8
000079035ddd7677  pop rsi
000079035ddd7678  pop rdi
000079035ddd7679  pop rdx
000079035ddd767a  pop rcx
000079035ddd767b  pop rax
000079035ddd767c  add rsp, 0x08
000079035ddd7680  jmp 0x000079035DDD3332
000079035ddd7685  sub rsp, 0x08
000079035ddd7689  push rax
000079035ddd768a  push rcx
000079035ddd768b  push rdx
000079035ddd768c  push rdi
000079035ddd768d  push rsi
000079035ddd768e  push r8
000079035ddd7690  push r9
000079035ddd7692  push r10
000079035ddd7694  push r11
000079035ddd7696  sub rsp, 0xF0
000079035ddd769d  vmovaps [rsp], xmm0
000079035ddd76a2  vmovaps [rsp+0x10], xmm1
000079035ddd76a8  vmovaps [rsp+0x20], xmm2
000079035ddd76ae  vmovaps [rsp+0x30], xmm3
000079035ddd76b4  vmovaps [rsp+0x40], xmm4
000079035ddd76ba  vmovaps [rsp+0x50], xmm5
000079035ddd76c0  vmovaps [rsp+0x60], xmm6
000079035ddd76c6  vmovaps [rsp+0x70], xmm7
000079035ddd76cc  vmovaps [rsp+0x80], xmm8
000079035ddd76d5  vmovaps [rsp+0x90], xmm9
000079035ddd76de  vmovaps [rsp+0xA0], xmm10
000079035ddd76e7  vmovaps [rsp+0xB0], xmm12
000079035ddd76f0  vmovaps [rsp+0xC0], xmm13
000079035ddd76f9  vmovaps [rsp+0xD0], xmm14
000079035ddd7702  vmovaps [rsp+0xE0], xmm15
000079035ddd770b  sub rsp, 0x30
000079035ddd770f  movaps [rsp], xmm11
000079035ddd7714  movaps [rsp+0x10], xmm7
000079035ddd7719  movaps [rsp+0x20], xmm13
000079035ddd771f  lea rdi, [rsp]
000079035ddd7723  mov esi, 0x00
000079035ddd7728  mov rax, 0x64ACAA8B0530
000079035ddd7732  call rax
000079035ddd7734  movaps xmm11, [rsp]
000079035ddd7739  add rsp, 0x30
000079035ddd773d  vmovaps xmm0, [rsp]
000079035ddd7742  vmovaps xmm1, [rsp+0x10]
000079035ddd7748  vmovaps xmm2, [rsp+0x20]
000079035ddd774e  vmovaps xmm3, [rsp+0x30]
000079035ddd7754  vmovaps xmm4, [rsp+0x40]
000079035ddd775a  vmovaps xmm5, [rsp+0x50]
000079035ddd7760  vmovaps xmm6, [rsp+0x60]
000079035ddd7766  vmovaps xmm7, [rsp+0x70]
000079035ddd776c  vmovaps xmm8, [rsp+0x80]
000079035ddd7775  vmovaps xmm9, [rsp+0x90]
000079035ddd777e  vmovaps xmm10, [rsp+0xA0]
000079035ddd7787  vmovaps xmm12, [rsp+0xB0]
000079035ddd7790  vmovaps xmm13, [rsp+0xC0]
000079035ddd7799  vmovaps xmm14, [rsp+0xD0]
000079035ddd77a2  vmovaps xmm15, [rsp+0xE0]
000079035ddd77ab  add rsp, 0xF0
000079035ddd77b2  pop r11
000079035ddd77b4  pop r10
000079035ddd77b6  pop r9
000079035ddd77b8  pop r8
000079035ddd77ba  pop rsi
000079035ddd77bb  pop rdi
000079035ddd77bc  pop rdx
000079035ddd77bd  pop rcx
000079035ddd77be  pop rax
000079035ddd77bf  add rsp, 0x08
000079035ddd77c3  jmp 0x000079035DDD335E
000079035ddd77c8  sub rsp, 0x08
000079035ddd77cc  push rax
000079035ddd77cd  push rcx
000079035ddd77ce  push rdx
000079035ddd77cf  push rdi
000079035ddd77d0  push rsi
000079035ddd77d1  push r8
000079035ddd77d3  push r9
000079035ddd77d5  push r10
000079035ddd77d7  push r11
000079035ddd77d9  sub rsp, 0xF0
000079035ddd77e0  vmovaps [rsp], xmm0
000079035ddd77e5  vmovaps [rsp+0x10], xmm1
000079035ddd77eb  vmovaps [rsp+0x20], xmm2
000079035ddd77f1  vmovaps [rsp+0x30], xmm3
000079035ddd77f7  vmovaps [rsp+0x40], xmm4
000079035ddd77fd  vmovaps [rsp+0x50], xmm5
000079035ddd7803  vmovaps [rsp+0x60], xmm6
000079035ddd7809  vmovaps [rsp+0x70], xmm7
000079035ddd780f  vmovaps [rsp+0x80], xmm8
000079035ddd7818  vmovaps [rsp+0x90], xmm9
000079035ddd7821  vmovaps [rsp+0xA0], xmm10
000079035ddd782a  vmovaps [rsp+0xB0], xmm11
000079035ddd7833  vmovaps [rsp+0xC0], xmm12
000079035ddd783c  vmovaps [rsp+0xD0], xmm14
000079035ddd7845  vmovaps [rsp+0xE0], xmm15
000079035ddd784e  sub rsp, 0x30
000079035ddd7852  movaps [rsp], xmm13
000079035ddd7857  movaps [rsp+0x10], xmm10
000079035ddd785d  movaps [rsp+0x20], xmm12
000079035ddd7863  lea rdi, [rsp]
000079035ddd7867  mov esi, 0x00
000079035ddd786c  mov rax, 0x64ACAA8B0530
000079035ddd7876  call rax
000079035ddd7878  movaps xmm13, [rsp]
000079035ddd787d  add rsp, 0x30
000079035ddd7881  vmovaps xmm0, [rsp]
000079035ddd7886  vmovaps xmm1, [rsp+0x10]
000079035ddd788c  vmovaps xmm2, [rsp+0x20]
000079035ddd7892  vmovaps xmm3, [rsp+0x30]
000079035ddd7898  vmovaps xmm4, [rsp+0x40]
000079035ddd789e  vmovaps xmm5, [rsp+0x50]
000079035ddd78a4  vmovaps xmm6, [rsp+0x60]
000079035ddd78aa  vmovaps xmm7, [rsp+0x70]
000079035ddd78b0  vmovaps xmm8, [rsp+0x80]
000079035ddd78b9  vmovaps xmm9, [rsp+0x90]
000079035ddd78c2  vmovaps xmm10, [rsp+0xA0]
000079035ddd78cb  vmovaps xmm11, [rsp+0xB0]
000079035ddd78d4  vmovaps xmm12, [rsp+0xC0]
000079035ddd78dd  vmovaps xmm14, [rsp+0xD0]
000079035ddd78e6  vmovaps xmm15, [rsp+0xE0]
000079035ddd78ef  add rsp, 0xF0
000079035ddd78f6  pop r11
000079035ddd78f8  pop r10
000079035ddd78fa  pop r9
000079035ddd78fc  pop r8
000079035ddd78fe  pop rsi
000079035ddd78ff  pop rdi
000079035ddd7900  pop rdx
000079035ddd7901  pop rcx
000079035ddd7902  pop rax
000079035ddd7903  add rsp, 0x08
000079035ddd7907  jmp 0x000079035DDD3378
000079035ddd790c  sub rsp, 0x08
000079035ddd7910  push rax
000079035ddd7911  push rcx
000079035ddd7912  push rdx
000079035ddd7913  push rdi
000079035ddd7914  push rsi
000079035ddd7915  push r8
000079035ddd7917  push r9
000079035ddd7919  push r10
000079035ddd791b  push r11
000079035ddd791d  sub rsp, 0xF0
000079035ddd7924  vmovaps [rsp], xmm0
000079035ddd7929  vmovaps [rsp+0x10], xmm1
000079035ddd792f  vmovaps [rsp+0x20], xmm2
000079035ddd7935  vmovaps [rsp+0x30], xmm3
000079035ddd793b  vmovaps [rsp+0x40], xmm4
000079035ddd7941  vmovaps [rsp+0x50], xmm5
000079035ddd7947  vmovaps [rsp+0x60], xmm6
000079035ddd794d  vmovaps [rsp+0x70], xmm7
000079035ddd7953  vmovaps [rsp+0x80], xmm8
000079035ddd795c  vmovaps [rsp+0x90], xmm9
000079035ddd7965  vmovaps [rsp+0xA0], xmm11
000079035ddd796e  vmovaps [rsp+0xB0], xmm12
000079035ddd7977  vmovaps [rsp+0xC0], xmm13
000079035ddd7980  vmovaps [rsp+0xD0], xmm14
000079035ddd7989  vmovaps [rsp+0xE0], xmm15
000079035ddd7992  sub rsp, 0x30
000079035ddd7996  movaps [rsp], xmm10
000079035ddd799b  movaps [rsp+0x10], xmm7
000079035ddd79a0  movaps [rsp+0x20], xmm12
000079035ddd79a6  lea rdi, [rsp]
000079035ddd79aa  mov esi, 0x00
000079035ddd79af  mov rax, 0x64ACAA8B0530
000079035ddd79b9  call rax
000079035ddd79bb  movaps xmm10, [rsp]
000079035ddd79c0  add rsp, 0x30
000079035ddd79c4  vmovaps xmm0, [rsp]
000079035ddd79c9  vmovaps xmm1, [rsp+0x10]
000079035ddd79cf  vmovaps xmm2, [rsp+0x20]
000079035ddd79d5  vmovaps xmm3, [rsp+0x30]
000079035ddd79db  vmovaps xmm4, [rsp+0x40]
000079035ddd79e1  vmovaps xmm5, [rsp+0x50]
000079035ddd79e7  vmovaps xmm6, [rsp+0x60]
000079035ddd79ed  vmovaps xmm7, [rsp+0x70]
000079035ddd79f3  vmovaps xmm8, [rsp+0x80]
000079035ddd79fc  vmovaps xmm9, [rsp+0x90]
000079035ddd7a05  vmovaps xmm11, [rsp+0xA0]
000079035ddd7a0e  vmovaps xmm12, [rsp+0xB0]
000079035ddd7a17  vmovaps xmm13, [rsp+0xC0]
000079035ddd7a20  vmovaps xmm14, [rsp+0xD0]
000079035ddd7a29  vmovaps xmm15, [rsp+0xE0]
000079035ddd7a32  add rsp, 0xF0
000079035ddd7a39  pop r11
000079035ddd7a3b  pop r10
000079035ddd7a3d  pop r9
000079035ddd7a3f  pop r8
000079035ddd7a41  pop rsi
000079035ddd7a42  pop rdi
000079035ddd7a43  pop rdx
000079035ddd7a44  pop rcx
000079035ddd7a45  pop rax
000079035ddd7a46  add rsp, 0x08
000079035ddd7a4a  jmp 0x000079035DDD33A4
000079035ddd7a4f  sub rsp, 0x08
000079035ddd7a53  push rax
000079035ddd7a54  push rcx
000079035ddd7a55  push rdx
000079035ddd7a56  push rdi
000079035ddd7a57  push rsi
000079035ddd7a58  push r8
000079035ddd7a5a  push r9
000079035ddd7a5c  push r10
000079035ddd7a5e  push r11
000079035ddd7a60  sub rsp, 0xF0
000079035ddd7a67  vmovaps [rsp], xmm0
000079035ddd7a6c  vmovaps [rsp+0x10], xmm1
000079035ddd7a72  vmovaps [rsp+0x20], xmm2
000079035ddd7a78  vmovaps [rsp+0x30], xmm3
000079035ddd7a7e  vmovaps [rsp+0x40], xmm4
000079035ddd7a84  vmovaps [rsp+0x50], xmm5
000079035ddd7a8a  vmovaps [rsp+0x60], xmm6
000079035ddd7a90  vmovaps [rsp+0x70], xmm7
000079035ddd7a96  vmovaps [rsp+0x80], xmm8
000079035ddd7a9f  vmovaps [rsp+0x90], xmm9
000079035ddd7aa8  vmovaps [rsp+0xA0], xmm10
000079035ddd7ab1  vmovaps [rsp+0xB0], xmm11
000079035ddd7aba  vmovaps [rsp+0xC0], xmm13
000079035ddd7ac3  vmovaps [rsp+0xD0], xmm14
000079035ddd7acc  vmovaps [rsp+0xE0], xmm15
000079035ddd7ad5  sub rsp, 0x30
000079035ddd7ad9  movaps [rsp], xmm12
000079035ddd7ade  movaps [rsp+0x10], xmm1
000079035ddd7ae3  movaps [rsp+0x20], xmm8
000079035ddd7ae9  lea rdi, [rsp]
000079035ddd7aed  mov esi, 0x00
000079035ddd7af2  mov rax, 0x64ACAA8B0530
000079035ddd7afc  call rax
000079035ddd7afe  movaps xmm12, [rsp]
000079035ddd7b03  add rsp, 0x30
000079035ddd7b07  vmovaps xmm0, [rsp]
000079035ddd7b0c  vmovaps xmm1, [rsp+0x10]
000079035ddd7b12  vmovaps xmm2, [rsp+0x20]
000079035ddd7b18  vmovaps xmm3, [rsp+0x30]
000079035ddd7b1e  vmovaps xmm4, [rsp+0x40]
000079035ddd7b24  vmovaps xmm5, [rsp+0x50]
000079035ddd7b2a  vmovaps xmm6, [rsp+0x60]
000079035ddd7b30  vmovaps xmm7, [rsp+0x70]
000079035ddd7b36  vmovaps xmm8, [rsp+0x80]
000079035ddd7b3f  vmovaps xmm9, [rsp+0x90]
000079035ddd7b48  vmovaps xmm10, [rsp+0xA0]
000079035ddd7b51  vmovaps xmm11, [rsp+0xB0]
000079035ddd7b5a  vmovaps xmm13, [rsp+0xC0]
000079035ddd7b63  vmovaps xmm14, [rsp+0xD0]
000079035ddd7b6c  vmovaps xmm15, [rsp+0xE0]
000079035ddd7b75  add rsp, 0xF0
000079035ddd7b7c  pop r11
000079035ddd7b7e  pop r10
000079035ddd7b80  pop r9
000079035ddd7b82  pop r8
000079035ddd7b84  pop rsi
000079035ddd7b85  pop rdi
000079035ddd7b86  pop rdx
000079035ddd7b87  pop rcx
000079035ddd7b88  pop rax
000079035ddd7b89  add rsp, 0x08
000079035ddd7b8d  jmp 0x000079035DDD33BE
000079035ddd7b92  call 0x000079035DBFF430
000079035ddd7b97  jmp 0x000079035DDD33C8
000079035ddd7b9c  sub rsp, 0x08
000079035ddd7ba0  push rax
000079035ddd7ba1  push rcx
000079035ddd7ba2  push rdx
000079035ddd7ba3  push rdi
000079035ddd7ba4  push rsi
000079035ddd7ba5  push r8
000079035ddd7ba7  push r9
000079035ddd7ba9  push r10
000079035ddd7bab  push r11
000079035ddd7bad  sub rsp, 0xF0
000079035ddd7bb4  vmovaps [rsp], xmm0
000079035ddd7bb9  vmovaps [rsp+0x10], xmm1
000079035ddd7bbf  vmovaps [rsp+0x20], xmm2
000079035ddd7bc5  vmovaps [rsp+0x30], xmm3
000079035ddd7bcb  vmovaps [rsp+0x40], xmm4
000079035ddd7bd1  vmovaps [rsp+0x50], xmm5
000079035ddd7bd7  vmovaps [rsp+0x60], xmm6
000079035ddd7bdd  vmovaps [rsp+0x70], xmm7
000079035ddd7be3  vmovaps [rsp+0x80], xmm9
000079035ddd7bec  vmovaps [rsp+0x90], xmm10
000079035ddd7bf5  vmovaps [rsp+0xA0], xmm11
000079035ddd7bfe  vmovaps [rsp+0xB0], xmm12
000079035ddd7c07  vmovaps [rsp+0xC0], xmm13
000079035ddd7c10  vmovaps [rsp+0xD0], xmm14
000079035ddd7c19  vmovaps [rsp+0xE0], xmm15
000079035ddd7c22  sub rsp, 0x30
000079035ddd7c26  movaps [rsp], xmm8
000079035ddd7c2b  movaps [rsp+0x10], xmm15
000079035ddd7c31  movaps [rsp+0x20], xmm9
000079035ddd7c37  lea rdi, [rsp]
000079035ddd7c3b  mov esi, 0x00
000079035ddd7c40  mov rax, 0x64ACAA8B0530
000079035ddd7c4a  call rax
000079035ddd7c4c  movaps xmm8, [rsp]
000079035ddd7c51  add rsp, 0x30
000079035ddd7c55  vmovaps xmm0, [rsp]
000079035ddd7c5a  vmovaps xmm1, [rsp+0x10]
000079035ddd7c60  vmovaps xmm2, [rsp+0x20]
000079035ddd7c66  vmovaps xmm3, [rsp+0x30]
000079035ddd7c6c  vmovaps xmm4, [rsp+0x40]
000079035ddd7c72  vmovaps xmm5, [rsp+0x50]
000079035ddd7c78  vmovaps xmm6, [rsp+0x60]
000079035ddd7c7e  vmovaps xmm7, [rsp+0x70]
000079035ddd7c84  vmovaps xmm9, [rsp+0x80]
000079035ddd7c8d  vmovaps xmm10, [rsp+0x90]
000079035ddd7c96  vmovaps xmm11, [rsp+0xA0]
000079035ddd7c9f  vmovaps xmm12, [rsp+0xB0]
000079035ddd7ca8  vmovaps xmm13, [rsp+0xC0]
000079035ddd7cb1  vmovaps xmm14, [rsp+0xD0]
000079035ddd7cba  vmovaps xmm15, [rsp+0xE0]
000079035ddd7cc3  add rsp, 0xF0
000079035ddd7cca  pop r11
000079035ddd7ccc  pop r10
000079035ddd7cce  pop r9
000079035ddd7cd0  pop r8
000079035ddd7cd2  pop rsi
000079035ddd7cd3  pop rdi
000079035ddd7cd4  pop rdx
000079035ddd7cd5  pop rcx
000079035ddd7cd6  pop rax
000079035ddd7cd7  add rsp, 0x08
000079035ddd7cdb  jmp 0x000079035DDD33EA
000079035ddd7ce0  sub rsp, 0x08
000079035ddd7ce4  push rax
000079035ddd7ce5  push rcx
000079035ddd7ce6  push rdx
000079035ddd7ce7  push rdi
000079035ddd7ce8  push rsi
000079035ddd7ce9  push r8
000079035ddd7ceb  push r9
000079035ddd7ced  push r10
000079035ddd7cef  push r11
000079035ddd7cf1  sub rsp, 0xF0
000079035ddd7cf8  vmovaps [rsp], xmm0
000079035ddd7cfd  vmovaps [rsp+0x10], xmm1
000079035ddd7d03  vmovaps [rsp+0x20], xmm2
000079035ddd7d09  vmovaps [rsp+0x30], xmm3
000079035ddd7d0f  vmovaps [rsp+0x40], xmm4
000079035ddd7d15  vmovaps [rsp+0x50], xmm5
000079035ddd7d1b  vmovaps [rsp+0x60], xmm6
000079035ddd7d21  vmovaps [rsp+0x70], xmm7
000079035ddd7d27  vmovaps [rsp+0x80], xmm8
000079035ddd7d30  vmovaps [rsp+0x90], xmm10
000079035ddd7d39  vmovaps [rsp+0xA0], xmm11
000079035ddd7d42  vmovaps [rsp+0xB0], xmm12
000079035ddd7d4b  vmovaps [rsp+0xC0], xmm13
000079035ddd7d54  vmovaps [rsp+0xD0], xmm14
000079035ddd7d5d  vmovaps [rsp+0xE0], xmm15
000079035ddd7d66  sub rsp, 0x30
000079035ddd7d6a  movaps [rsp], xmm9
000079035ddd7d6f  movaps [rsp+0x10], xmm1
000079035ddd7d74  movaps [rsp+0x20], xmm15
000079035ddd7d7a  lea rdi, [rsp]
000079035ddd7d7e  mov esi, 0x00
000079035ddd7d83  mov rax, 0x64ACAA8B0530
000079035ddd7d8d  call rax
000079035ddd7d8f  movaps xmm9, [rsp]
000079035ddd7d94  add rsp, 0x30
000079035ddd7d98  vmovaps xmm0, [rsp]
000079035ddd7d9d  vmovaps xmm1, [rsp+0x10]
000079035ddd7da3  vmovaps xmm2, [rsp+0x20]
000079035ddd7da9  vmovaps xmm3, [rsp+0x30]
000079035ddd7daf  vmovaps xmm4, [rsp+0x40]
000079035ddd7db5  vmovaps xmm5, [rsp+0x50]
000079035ddd7dbb  vmovaps xmm6, [rsp+0x60]
000079035ddd7dc1  vmovaps xmm7, [rsp+0x70]
000079035ddd7dc7  vmovaps xmm8, [rsp+0x80]
000079035ddd7dd0  vmovaps xmm10, [rsp+0x90]
000079035ddd7dd9  vmovaps xmm11, [rsp+0xA0]
000079035ddd7de2  vmovaps xmm12, [rsp+0xB0]
000079035ddd7deb  vmovaps xmm13, [rsp+0xC0]
000079035ddd7df4  vmovaps xmm14, [rsp+0xD0]
000079035ddd7dfd  vmovaps xmm15, [rsp+0xE0]
000079035ddd7e06  add rsp, 0xF0
000079035ddd7e0d  pop r11
000079035ddd7e0f  pop r10
000079035ddd7e11  pop r9
000079035ddd7e13  pop r8
000079035ddd7e15  pop rsi
000079035ddd7e16  pop rdi
000079035ddd7e17  pop rdx
000079035ddd7e18  pop rcx
000079035ddd7e19  pop rax
000079035ddd7e1a  add rsp, 0x08
000079035ddd7e1e  jmp 0x000079035DDD3418
000079035ddd7e23  sub rsp, 0x08
000079035ddd7e27  push rax
000079035ddd7e28  push rcx
000079035ddd7e29  push rdx
000079035ddd7e2a  push rdi
000079035ddd7e2b  push rsi
000079035ddd7e2c  push r8
000079035ddd7e2e  push r9
000079035ddd7e30  push r10
000079035ddd7e32  push r11
000079035ddd7e34  sub rsp, 0xF0
000079035ddd7e3b  vmovaps [rsp], xmm0
000079035ddd7e40  vmovaps [rsp+0x10], xmm1
000079035ddd7e46  vmovaps [rsp+0x20], xmm2
000079035ddd7e4c  vmovaps [rsp+0x30], xmm3
000079035ddd7e52  vmovaps [rsp+0x40], xmm4
000079035ddd7e58  vmovaps [rsp+0x50], xmm5
000079035ddd7e5e  vmovaps [rsp+0x60], xmm6
000079035ddd7e64  vmovaps [rsp+0x70], xmm7
000079035ddd7e6a  vmovaps [rsp+0x80], xmm8
000079035ddd7e73  vmovaps [rsp+0x90], xmm9
000079035ddd7e7c  vmovaps [rsp+0xA0], xmm10
000079035ddd7e85  vmovaps [rsp+0xB0], xmm11
000079035ddd7e8e  vmovaps [rsp+0xC0], xmm12
000079035ddd7e97  vmovaps [rsp+0xD0], xmm13
000079035ddd7ea0  vmovaps [rsp+0xE0], xmm14
000079035ddd7ea9  sub rsp, 0x30
000079035ddd7ead  movaps [rsp], xmm15
000079035ddd7eb2  movaps [rsp+0x10], xmm4
000079035ddd7eb7  movaps [rsp+0x20], xmm1
000079035ddd7ebc  lea rdi, [rsp]
000079035ddd7ec0  mov esi, 0x00
000079035ddd7ec5  mov rax, 0x64ACAA8B0530
000079035ddd7ecf  call rax
000079035ddd7ed1  movaps xmm15, [rsp]
000079035ddd7ed6  add rsp, 0x30
000079035ddd7eda  vmovaps xmm0, [rsp]
000079035ddd7edf  vmovaps xmm1, [rsp+0x10]
000079035ddd7ee5  vmovaps xmm2, [rsp+0x20]
000079035ddd7eeb  vmovaps xmm3, [rsp+0x30]
000079035ddd7ef1  vmovaps xmm4, [rsp+0x40]
000079035ddd7ef7  vmovaps xmm5, [rsp+0x50]
000079035ddd7efd  vmovaps xmm6, [rsp+0x60]
000079035ddd7f03  vmovaps xmm7, [rsp+0x70]
000079035ddd7f09  vmovaps xmm8, [rsp+0x80]
000079035ddd7f12  vmovaps xmm9, [rsp+0x90]
000079035ddd7f1b  vmovaps xmm10, [rsp+0xA0]
000079035ddd7f24  vmovaps xmm11, [rsp+0xB0]
000079035ddd7f2d  vmovaps xmm12, [rsp+0xC0]
000079035ddd7f36  vmovaps xmm13, [rsp+0xD0]
000079035ddd7f3f  vmovaps xmm14, [rsp+0xE0]
000079035ddd7f48  add rsp, 0xF0
000079035ddd7f4f  pop r11
000079035ddd7f51  pop r10
000079035ddd7f53  pop r9
000079035ddd7f55  pop r8
000079035ddd7f57  pop rsi
000079035ddd7f58  pop rdi
000079035ddd7f59  pop rdx
000079035ddd7f5a  pop rcx
000079035ddd7f5b  pop rax
000079035ddd7f5c  add rsp, 0x08
000079035ddd7f60  jmp 0x000079035DDD343E
000079035ddd7f65  sub rsp, 0x08
000079035ddd7f69  push rax
000079035ddd7f6a  push rcx
000079035ddd7f6b  push rdx
000079035ddd7f6c  push rdi
000079035ddd7f6d  push rsi
000079035ddd7f6e  push r8
000079035ddd7f70  push r9
000079035ddd7f72  push r10
000079035ddd7f74  push r11
000079035ddd7f76  sub rsp, 0xF0
000079035ddd7f7d  vmovaps [rsp], xmm0
000079035ddd7f82  vmovaps [rsp+0x10], xmm2
000079035ddd7f88  vmovaps [rsp+0x20], xmm3
000079035ddd7f8e  vmovaps [rsp+0x30], xmm4
000079035ddd7f94  vmovaps [rsp+0x40], xmm5
000079035ddd7f9a  vmovaps [rsp+0x50], xmm6
000079035ddd7fa0  vmovaps [rsp+0x60], xmm7
000079035ddd7fa6  vmovaps [rsp+0x70], xmm8
000079035ddd7fac  vmovaps [rsp+0x80], xmm9
000079035ddd7fb5  vmovaps [rsp+0x90], xmm10
000079035ddd7fbe  vmovaps [rsp+0xA0], xmm11
000079035ddd7fc7  vmovaps [rsp+0xB0], xmm12
000079035ddd7fd0  vmovaps [rsp+0xC0], xmm13
000079035ddd7fd9  vmovaps [rsp+0xD0], xmm14
000079035ddd7fe2  vmovaps [rsp+0xE0], xmm15
000079035ddd7feb  sub rsp, 0x30
000079035ddd7fef  movaps [rsp], xmm1
000079035ddd7ff3  movaps [rsp+0x10], xmm14
000079035ddd7ff9  movaps [rsp+0x20], xmm11
000079035ddd7fff  lea rdi, [rsp]
000079035ddd8003  mov esi, 0x00
000079035ddd8008  mov rax, 0x64ACAA8B0530
000079035ddd8012  call rax
000079035ddd8014  movaps xmm1, [rsp]
000079035ddd8018  add rsp, 0x30
000079035ddd801c  vmovaps xmm0, [rsp]
000079035ddd8021  vmovaps xmm2, [rsp+0x10]
000079035ddd8027  vmovaps xmm3, [rsp+0x20]
000079035ddd802d  vmovaps xmm4, [rsp+0x30]
000079035ddd8033  vmovaps xmm5, [rsp+0x40]
000079035ddd8039  vmovaps xmm6, [rsp+0x50]
000079035ddd803f  vmovaps xmm7, [rsp+0x60]
000079035ddd8045  vmovaps xmm8, [rsp+0x70]
000079035ddd804b  vmovaps xmm9, [rsp+0x80]
000079035ddd8054  vmovaps xmm10, [rsp+0x90]
000079035ddd805d  vmovaps xmm11, [rsp+0xA0]
000079035ddd8066  vmovaps xmm12, [rsp+0xB0]
000079035ddd806f  vmovaps xmm13, [rsp+0xC0]
000079035ddd8078  vmovaps xmm14, [rsp+0xD0]
000079035ddd8081  vmovaps xmm15, [rsp+0xE0]
000079035ddd808a  add rsp, 0xF0
000079035ddd8091  pop r11
000079035ddd8093  pop r10
000079035ddd8095  pop r9
000079035ddd8097  pop r8
000079035ddd8099  pop rsi
000079035ddd809a  pop rdi
000079035ddd809b  pop rdx
000079035ddd809c  pop rcx
000079035ddd809d  pop rax
000079035ddd809e  add rsp, 0x08
000079035ddd80a2  jmp 0x000079035DDD345F
000079035ddd80a7  call 0x000079035DCE45A0
000079035ddd80ac  jmp 0x000079035DDD346D
000079035ddd80b1  call 0x000079035DC09D70
000079035ddd80b6  jmp 0x000079035DDD3477
000079035ddd80bb  sub rsp, 0x08
000079035ddd80bf  push rax
000079035ddd80c0  push rcx
000079035ddd80c1  push rdx
000079035ddd80c2  push rdi
000079035ddd80c3  push rsi
000079035ddd80c4  push r8
000079035ddd80c6  push r9
000079035ddd80c8  push r10
000079035ddd80ca  push r11
000079035ddd80cc  sub rsp, 0xF0
000079035ddd80d3  vmovaps [rsp], xmm0
000079035ddd80d8  vmovaps [rsp+0x10], xmm1
000079035ddd80de  vmovaps [rsp+0x20], xmm2
000079035ddd80e4  vmovaps [rsp+0x30], xmm3
000079035ddd80ea  vmovaps [rsp+0x40], xmm4
000079035ddd80f0  vmovaps [rsp+0x50], xmm5
000079035ddd80f6  vmovaps [rsp+0x60], xmm6
000079035ddd80fc  vmovaps [rsp+0x70], xmm8
000079035ddd8102  vmovaps [rsp+0x80], xmm9
000079035ddd810b  vmovaps [rsp+0x90], xmm10
000079035ddd8114  vmovaps [rsp+0xA0], xmm11
000079035ddd811d  vmovaps [rsp+0xB0], xmm12
000079035ddd8126  vmovaps [rsp+0xC0], xmm13
000079035ddd812f  vmovaps [rsp+0xD0], xmm14
000079035ddd8138  vmovaps [rsp+0xE0], xmm15
000079035ddd8141  sub rsp, 0x30
000079035ddd8145  movaps [rsp], xmm7
000079035ddd8149  movaps [rsp+0x10], xmm13
000079035ddd814f  movaps [rsp+0x20], xmm10
000079035ddd8155  lea rdi, [rsp]
000079035ddd8159  mov esi, 0x00
000079035ddd815e  mov rax, 0x64ACAA8B0530
000079035ddd8168  call rax
000079035ddd816a  movaps xmm7, [rsp]
000079035ddd816e  add rsp, 0x30
000079035ddd8172  vmovaps xmm0, [rsp]
000079035ddd8177  vmovaps xmm1, [rsp+0x10]
000079035ddd817d  vmovaps xmm2, [rsp+0x20]
000079035ddd8183  vmovaps xmm3, [rsp+0x30]
000079035ddd8189  vmovaps xmm4, [rsp+0x40]
000079035ddd818f  vmovaps xmm5, [rsp+0x50]
000079035ddd8195  vmovaps xmm6, [rsp+0x60]
000079035ddd819b  vmovaps xmm8, [rsp+0x70]
000079035ddd81a1  vmovaps xmm9, [rsp+0x80]
000079035ddd81aa  vmovaps xmm10, [rsp+0x90]
000079035ddd81b3  vmovaps xmm11, [rsp+0xA0]
000079035ddd81bc  vmovaps xmm12, [rsp+0xB0]
000079035ddd81c5  vmovaps xmm13, [rsp+0xC0]
000079035ddd81ce  vmovaps xmm14, [rsp+0xD0]
000079035ddd81d7  vmovaps xmm15, [rsp+0xE0]
000079035ddd81e0  add rsp, 0xF0
000079035ddd81e7  pop r11
000079035ddd81e9  pop r10
000079035ddd81eb  pop r9
000079035ddd81ed  pop r8
000079035ddd81ef  pop rsi
000079035ddd81f0  pop rdi
000079035ddd81f1  pop rdx
000079035ddd81f2  pop rcx
000079035ddd81f3  pop rax
000079035ddd81f4  add rsp, 0x08
000079035ddd81f8  jmp 0x000079035DDD3498
000079035ddd81fd  sub rsp, 0x08
000079035ddd8201  push rax
000079035ddd8202  push rcx
000079035ddd8203  push rdx
000079035ddd8204  push rdi
000079035ddd8205  push rsi
000079035ddd8206  push r8
000079035ddd8208  push r9
000079035ddd820a  push r10
000079035ddd820c  push r11
000079035ddd820e  sub rsp, 0xF0
000079035ddd8215  vmovaps [rsp], xmm0
000079035ddd821a  vmovaps [rsp+0x10], xmm1
000079035ddd8220  vmovaps [rsp+0x20], xmm2
000079035ddd8226  vmovaps [rsp+0x30], xmm3
000079035ddd822c  vmovaps [rsp+0x40], xmm4
000079035ddd8232  vmovaps [rsp+0x50], xmm5
000079035ddd8238  vmovaps [rsp+0x60], xmm6
000079035ddd823e  vmovaps [rsp+0x70], xmm7
000079035ddd8244  vmovaps [rsp+0x80], xmm8
000079035ddd824d  vmovaps [rsp+0x90], xmm9
000079035ddd8256  vmovaps [rsp+0xA0], xmm11
000079035ddd825f  vmovaps [rsp+0xB0], xmm12
000079035ddd8268  vmovaps [rsp+0xC0], xmm13
000079035ddd8271  vmovaps [rsp+0xD0], xmm14
000079035ddd827a  vmovaps [rsp+0xE0], xmm15
000079035ddd8283  sub rsp, 0x30
000079035ddd8287  movaps [rsp], xmm10
000079035ddd828c  movaps [rsp+0x10], xmm11
000079035ddd8292  movaps [rsp+0x20], xmm13
000079035ddd8298  lea rdi, [rsp]
000079035ddd829c  mov esi, 0x00
000079035ddd82a1  mov rax, 0x64ACAA8B0530
000079035ddd82ab  call rax
000079035ddd82ad  movaps xmm10, [rsp]
000079035ddd82b2  add rsp, 0x30
000079035ddd82b6  vmovaps xmm0, [rsp]
000079035ddd82bb  vmovaps xmm1, [rsp+0x10]
000079035ddd82c1  vmovaps xmm2, [rsp+0x20]
000079035ddd82c7  vmovaps xmm3, [rsp+0x30]
000079035ddd82cd  vmovaps xmm4, [rsp+0x40]
000079035ddd82d3  vmovaps xmm5, [rsp+0x50]
000079035ddd82d9  vmovaps xmm6, [rsp+0x60]
000079035ddd82df  vmovaps xmm7, [rsp+0x70]
000079035ddd82e5  vmovaps xmm8, [rsp+0x80]
000079035ddd82ee  vmovaps xmm9, [rsp+0x90]
000079035ddd82f7  vmovaps xmm11, [rsp+0xA0]
000079035ddd8300  vmovaps xmm12, [rsp+0xB0]
000079035ddd8309  vmovaps xmm13, [rsp+0xC0]
000079035ddd8312  vmovaps xmm14, [rsp+0xD0]
000079035ddd831b  vmovaps xmm15, [rsp+0xE0]
000079035ddd8324  add rsp, 0xF0
000079035ddd832b  pop r11
000079035ddd832d  pop r10
000079035ddd832f  pop r9
000079035ddd8331  pop r8
000079035ddd8333  pop rsi
000079035ddd8334  pop rdi
000079035ddd8335  pop rdx
000079035ddd8336  pop rcx
000079035ddd8337  pop rax
000079035ddd8338  add rsp, 0x08
000079035ddd833c  jmp 0x000079035DDD34C6
000079035ddd8341  sub rsp, 0x08
000079035ddd8345  push rax
000079035ddd8346  push rcx
000079035ddd8347  push rdx
000079035ddd8348  push rdi
000079035ddd8349  push rsi
000079035ddd834a  push r8
000079035ddd834c  push r9
000079035ddd834e  push r10
000079035ddd8350  push r11
000079035ddd8352  sub rsp, 0xF0
000079035ddd8359  vmovaps [rsp], xmm0
000079035ddd835e  vmovaps [rsp+0x10], xmm1
000079035ddd8364  vmovaps [rsp+0x20], xmm2
000079035ddd836a  vmovaps [rsp+0x30], xmm3
000079035ddd8370  vmovaps [rsp+0x40], xmm4
000079035ddd8376  vmovaps [rsp+0x50], xmm5
000079035ddd837c  vmovaps [rsp+0x60], xmm6
000079035ddd8382  vmovaps [rsp+0x70], xmm7
000079035ddd8388  vmovaps [rsp+0x80], xmm8
000079035ddd8391  vmovaps [rsp+0x90], xmm9
000079035ddd839a  vmovaps [rsp+0xA0], xmm10
000079035ddd83a3  vmovaps [rsp+0xB0], xmm12
000079035ddd83ac  vmovaps [rsp+0xC0], xmm13
000079035ddd83b5  vmovaps [rsp+0xD0], xmm14
000079035ddd83be  vmovaps [rsp+0xE0], xmm15
000079035ddd83c7  sub rsp, 0x30
000079035ddd83cb  movaps [rsp], xmm11
000079035ddd83d0  movaps [rsp+0x10], xmm14
000079035ddd83d6  movaps [rsp+0x20], xmm13
000079035ddd83dc  lea rdi, [rsp]
000079035ddd83e0  mov esi, 0x00
000079035ddd83e5  mov rax, 0x64ACAA8B0530
000079035ddd83ef  call rax
000079035ddd83f1  movaps xmm11, [rsp]
000079035ddd83f6  add rsp, 0x30
000079035ddd83fa  vmovaps xmm0, [rsp]
000079035ddd83ff  vmovaps xmm1, [rsp+0x10]
000079035ddd8405  vmovaps xmm2, [rsp+0x20]
000079035ddd840b  vmovaps xmm3, [rsp+0x30]
000079035ddd8411  vmovaps xmm4, [rsp+0x40]
000079035ddd8417  vmovaps xmm5, [rsp+0x50]
000079035ddd841d  vmovaps xmm6, [rsp+0x60]
000079035ddd8423  vmovaps xmm7, [rsp+0x70]
000079035ddd8429  vmovaps xmm8, [rsp+0x80]
000079035ddd8432  vmovaps xmm9, [rsp+0x90]
000079035ddd843b  vmovaps xmm10, [rsp+0xA0]
000079035ddd8444  vmovaps xmm12, [rsp+0xB0]
000079035ddd844d  vmovaps xmm13, [rsp+0xC0]
000079035ddd8456  vmovaps xmm14, [rsp+0xD0]
000079035ddd845f  vmovaps xmm15, [rsp+0xE0]
000079035ddd8468  add rsp, 0xF0
000079035ddd846f  pop r11
000079035ddd8471  pop r10
000079035ddd8473  pop r9
000079035ddd8475  pop r8
000079035ddd8477  pop rsi
000079035ddd8478  pop rdi
000079035ddd8479  pop rdx
000079035ddd847a  pop rcx
000079035ddd847b  pop rax
000079035ddd847c  add rsp, 0x08
000079035ddd8480  jmp 0x000079035DDD34F4
000079035ddd8485  sub rsp, 0x08
000079035ddd8489  push rax
000079035ddd848a  push rcx
000079035ddd848b  push rdx
000079035ddd848c  push rdi
000079035ddd848d  push rsi
000079035ddd848e  push r8
000079035ddd8490  push r9
000079035ddd8492  push r10
000079035ddd8494  push r11
000079035ddd8496  sub rsp, 0xF0
000079035ddd849d  vmovaps [rsp], xmm0
000079035ddd84a2  vmovaps [rsp+0x10], xmm1
000079035ddd84a8  vmovaps [rsp+0x20], xmm2
000079035ddd84ae  vmovaps [rsp+0x30], xmm3
000079035ddd84b4  vmovaps [rsp+0x40], xmm4
000079035ddd84ba  vmovaps [rsp+0x50], xmm5
000079035ddd84c0  vmovaps [rsp+0x60], xmm6
000079035ddd84c6  vmovaps [rsp+0x70], xmm7
000079035ddd84cc  vmovaps [rsp+0x80], xmm8
000079035ddd84d5  vmovaps [rsp+0x90], xmm9
000079035ddd84de  vmovaps [rsp+0xA0], xmm10
000079035ddd84e7  vmovaps [rsp+0xB0], xmm11
000079035ddd84f0  vmovaps [rsp+0xC0], xmm12
000079035ddd84f9  vmovaps [rsp+0xD0], xmm13
000079035ddd8502  vmovaps [rsp+0xE0], xmm15
000079035ddd850b  sub rsp, 0x30
000079035ddd850f  movaps [rsp], xmm14
000079035ddd8514  movaps [rsp+0x10], xmm12
000079035ddd851a  movaps [rsp+0x20], xmm9
000079035ddd8520  lea rdi, [rsp]
000079035ddd8524  mov esi, 0x00
000079035ddd8529  mov rax, 0x64ACAA8B0530
000079035ddd8533  call rax
000079035ddd8535  movaps xmm14, [rsp]
000079035ddd853a  add rsp, 0x30
000079035ddd853e  vmovaps xmm0, [rsp]
000079035ddd8543  vmovaps xmm1, [rsp+0x10]
000079035ddd8549  vmovaps xmm2, [rsp+0x20]
000079035ddd854f  vmovaps xmm3, [rsp+0x30]
000079035ddd8555  vmovaps xmm4, [rsp+0x40]
000079035ddd855b  vmovaps xmm5, [rsp+0x50]
000079035ddd8561  vmovaps xmm6, [rsp+0x60]
000079035ddd8567  vmovaps xmm7, [rsp+0x70]
000079035ddd856d  vmovaps xmm8, [rsp+0x80]
000079035ddd8576  vmovaps xmm9, [rsp+0x90]
000079035ddd857f  vmovaps xmm10, [rsp+0xA0]
000079035ddd8588  vmovaps xmm11, [rsp+0xB0]
000079035ddd8591  vmovaps xmm12, [rsp+0xC0]
000079035ddd859a  vmovaps xmm13, [rsp+0xD0]
000079035ddd85a3  vmovaps xmm15, [rsp+0xE0]
000079035ddd85ac  add rsp, 0xF0
000079035ddd85b3  pop r11
000079035ddd85b5  pop r10
000079035ddd85b7  pop r9
000079035ddd85b9  pop r8
000079035ddd85bb  pop rsi
000079035ddd85bc  pop rdi
000079035ddd85bd  pop rdx
000079035ddd85be  pop rcx
000079035ddd85bf  pop rax
000079035ddd85c0  add rsp, 0x08
000079035ddd85c4  jmp 0x000079035DDD350F
000079035ddd85c9  sub rsp, 0x08
000079035ddd85cd  push rax
000079035ddd85ce  push rcx
000079035ddd85cf  push rdx
000079035ddd85d0  push rdi
000079035ddd85d1  push rsi
000079035ddd85d2  push r8
000079035ddd85d4  push r9
000079035ddd85d6  push r10
000079035ddd85d8  push r11
000079035ddd85da  sub rsp, 0xF0
000079035ddd85e1  vmovaps [rsp], xmm0
000079035ddd85e6  vmovaps [rsp+0x10], xmm1
000079035ddd85ec  vmovaps [rsp+0x20], xmm2
000079035ddd85f2  vmovaps [rsp+0x30], xmm3
000079035ddd85f8  vmovaps [rsp+0x40], xmm4
000079035ddd85fe  vmovaps [rsp+0x50], xmm5
000079035ddd8604  vmovaps [rsp+0x60], xmm6
000079035ddd860a  vmovaps [rsp+0x70], xmm7
000079035ddd8610  vmovaps [rsp+0x80], xmm8
000079035ddd8619  vmovaps [rsp+0x90], xmm9
000079035ddd8622  vmovaps [rsp+0xA0], xmm10
000079035ddd862b  vmovaps [rsp+0xB0], xmm11
000079035ddd8634  vmovaps [rsp+0xC0], xmm12
000079035ddd863d  vmovaps [rsp+0xD0], xmm14
000079035ddd8646  vmovaps [rsp+0xE0], xmm15
000079035ddd864f  sub rsp, 0x30
000079035ddd8653  movaps [rsp], xmm13
000079035ddd8658  movaps [rsp+0x10], xmm8
000079035ddd865e  movaps [rsp+0x20], xmm15
000079035ddd8664  lea rdi, [rsp]
000079035ddd8668  mov esi, 0x00
000079035ddd866d  mov rax, 0x64ACAA8B0530
000079035ddd8677  call rax
000079035ddd8679  movaps xmm13, [rsp]
000079035ddd867e  add rsp, 0x30
000079035ddd8682  vmovaps xmm0, [rsp]
000079035ddd8687  vmovaps xmm1, [rsp+0x10]
000079035ddd868d  vmovaps xmm2, [rsp+0x20]
000079035ddd8693  vmovaps xmm3, [rsp+0x30]
000079035ddd8699  vmovaps xmm4, [rsp+0x40]
000079035ddd869f  vmovaps xmm5, [rsp+0x50]
000079035ddd86a5  vmovaps xmm6, [rsp+0x60]
000079035ddd86ab  vmovaps xmm7, [rsp+0x70]
000079035ddd86b1  vmovaps xmm8, [rsp+0x80]
000079035ddd86ba  vmovaps xmm9, [rsp+0x90]
000079035ddd86c3  vmovaps xmm10, [rsp+0xA0]
000079035ddd86cc  vmovaps xmm11, [rsp+0xB0]
000079035ddd86d5  vmovaps xmm12, [rsp+0xC0]
000079035ddd86de  vmovaps xmm14, [rsp+0xD0]
000079035ddd86e7  vmovaps xmm15, [rsp+0xE0]
000079035ddd86f0  add rsp, 0xF0
000079035ddd86f7  pop r11
000079035ddd86f9  pop r10
000079035ddd86fb  pop r9
000079035ddd86fd  pop r8
000079035ddd86ff  pop rsi
000079035ddd8700  pop rdi
000079035ddd8701  pop rdx
000079035ddd8702  pop rcx
000079035ddd8703  pop rax
000079035ddd8704  add rsp, 0x08
000079035ddd8708  jmp 0x000079035DDD3532
000079035ddd870d  sub rsp, 0x08
000079035ddd8711  push rax
000079035ddd8712  push rcx
000079035ddd8713  push rdx
000079035ddd8714  push rdi
000079035ddd8715  push rsi
000079035ddd8716  push r8
000079035ddd8718  push r9
000079035ddd871a  push r10
000079035ddd871c  push r11
000079035ddd871e  sub rsp, 0xF0
000079035ddd8725  vmovaps [rsp], xmm0
000079035ddd872a  vmovaps [rsp+0x10], xmm1
000079035ddd8730  vmovaps [rsp+0x20], xmm2
000079035ddd8736  vmovaps [rsp+0x30], xmm3
000079035ddd873c  vmovaps [rsp+0x40], xmm4
000079035ddd8742  vmovaps [rsp+0x50], xmm5
000079035ddd8748  vmovaps [rsp+0x60], xmm6
000079035ddd874e  vmovaps [rsp+0x70], xmm7
000079035ddd8754  vmovaps [rsp+0x80], xmm8
000079035ddd875d  vmovaps [rsp+0x90], xmm9
000079035ddd8766  vmovaps [rsp+0xA0], xmm10
000079035ddd876f  vmovaps [rsp+0xB0], xmm11
000079035ddd8778  vmovaps [rsp+0xC0], xmm12
000079035ddd8781  vmovaps [rsp+0xD0], xmm13
000079035ddd878a  vmovaps [rsp+0xE0], xmm14
000079035ddd8793  sub rsp, 0x30
000079035ddd8797  movaps [rsp], xmm15
000079035ddd879c  movaps [rsp+0x10], xmm1
000079035ddd87a1  movaps [rsp+0x20], xmm10
000079035ddd87a7  lea rdi, [rsp]
000079035ddd87ab  mov esi, 0x00
000079035ddd87b0  mov rax, 0x64ACAA8B0530
000079035ddd87ba  call rax
000079035ddd87bc  movaps xmm15, [rsp]
000079035ddd87c1  add rsp, 0x30
000079035ddd87c5  vmovaps xmm0, [rsp]
000079035ddd87ca  vmovaps xmm1, [rsp+0x10]
000079035ddd87d0  vmovaps xmm2, [rsp+0x20]
000079035ddd87d6  vmovaps xmm3, [rsp+0x30]
000079035ddd87dc  vmovaps xmm4, [rsp+0x40]
000079035ddd87e2  vmovaps xmm5, [rsp+0x50]
000079035ddd87e8  vmovaps xmm6, [rsp+0x60]
000079035ddd87ee  vmovaps xmm7, [rsp+0x70]
000079035ddd87f4  vmovaps xmm8, [rsp+0x80]
000079035ddd87fd  vmovaps xmm9, [rsp+0x90]
000079035ddd8806  vmovaps xmm10, [rsp+0xA0]
000079035ddd880f  vmovaps xmm11, [rsp+0xB0]
000079035ddd8818  vmovaps xmm12, [rsp+0xC0]
000079035ddd8821  vmovaps xmm13, [rsp+0xD0]
000079035ddd882a  vmovaps xmm14, [rsp+0xE0]
000079035ddd8833  add rsp, 0xF0
000079035ddd883a  pop r11
000079035ddd883c  pop r10
000079035ddd883e  pop r9
000079035ddd8840  pop r8
000079035ddd8842  pop rsi
000079035ddd8843  pop rdi
000079035ddd8844  pop rdx
000079035ddd8845  pop rcx
000079035ddd8846  pop rax
000079035ddd8847  add rsp, 0x08
000079035ddd884b  jmp 0x000079035DDD3555
000079035ddd8850  sub rsp, 0x08
000079035ddd8854  push rax
000079035ddd8855  push rcx
000079035ddd8856  push rdx
000079035ddd8857  push rdi
000079035ddd8858  push rsi
000079035ddd8859  push r8
000079035ddd885b  push r9
000079035ddd885d  push r10
000079035ddd885f  push r11
000079035ddd8861  sub rsp, 0xF0
000079035ddd8868  vmovaps [rsp], xmm0
000079035ddd886d  vmovaps [rsp+0x10], xmm2
000079035ddd8873  vmovaps [rsp+0x20], xmm3
000079035ddd8879  vmovaps [rsp+0x30], xmm4
000079035ddd887f  vmovaps [rsp+0x40], xmm5
000079035ddd8885  vmovaps [rsp+0x50], xmm6
000079035ddd888b  vmovaps [rsp+0x60], xmm7
000079035ddd8891  vmovaps [rsp+0x70], xmm8
000079035ddd8897  vmovaps [rsp+0x80], xmm9
000079035ddd88a0  vmovaps [rsp+0x90], xmm10
000079035ddd88a9  vmovaps [rsp+0xA0], xmm11
000079035ddd88b2  vmovaps [rsp+0xB0], xmm12
000079035ddd88bb  vmovaps [rsp+0xC0], xmm13
000079035ddd88c4  vmovaps [rsp+0xD0], xmm14
000079035ddd88cd  vmovaps [rsp+0xE0], xmm15
000079035ddd88d6  sub rsp, 0x30
000079035ddd88da  movaps [rsp], xmm1
000079035ddd88de  movaps [rsp+0x10], xmm7
000079035ddd88e3  movaps [rsp+0x20], xmm11
000079035ddd88e9  lea rdi, [rsp]
000079035ddd88ed  mov esi, 0x00
000079035ddd88f2  mov rax, 0x64ACAA8B0530
000079035ddd88fc  call rax
000079035ddd88fe  movaps xmm1, [rsp]
000079035ddd8902  add rsp, 0x30
000079035ddd8906  vmovaps xmm0, [rsp]
000079035ddd890b  vmovaps xmm2, [rsp+0x10]
000079035ddd8911  vmovaps xmm3, [rsp+0x20]
000079035ddd8917  vmovaps xmm4, [rsp+0x30]
000079035ddd891d  vmovaps xmm5, [rsp+0x40]
000079035ddd8923  vmovaps xmm6, [rsp+0x50]
000079035ddd8929  vmovaps xmm7, [rsp+0x60]
000079035ddd892f  vmovaps xmm8, [rsp+0x70]
000079035ddd8935  vmovaps xmm9, [rsp+0x80]
000079035ddd893e  vmovaps xmm10, [rsp+0x90]
000079035ddd8947  vmovaps xmm11, [rsp+0xA0]
000079035ddd8950  vmovaps xmm12, [rsp+0xB0]
000079035ddd8959  vmovaps xmm13, [rsp+0xC0]
000079035ddd8962  vmovaps xmm14, [rsp+0xD0]
000079035ddd896b  vmovaps xmm15, [rsp+0xE0]
000079035ddd8974  add rsp, 0xF0
000079035ddd897b  pop r11
000079035ddd897d  pop r10
000079035ddd897f  pop r9
000079035ddd8981  pop r8
000079035ddd8983  pop rsi
000079035ddd8984  pop rdi
000079035ddd8985  pop rdx
000079035ddd8986  pop rcx
000079035ddd8987  pop rax
000079035ddd8988  add rsp, 0x08
000079035ddd898c  jmp 0x000079035DDD3576
000079035ddd8991  call 0x000079035DC0D600
000079035ddd8996  jmp 0x000079035DDD3589
000079035ddd899b  call 0x000079035DC0C380
000079035ddd89a0  jmp 0x000079035DDD3594
000079035ddd89a5  call 0x000079035DC0E880
000079035ddd89aa  jmp 0x000079035DDD359F
000079035ddd89af  call 0x000079035DBFF540
000079035ddd89b4  jmp 0x000079035DDD35AA
000079035ddd89b9  int3
000079035ddd89ba  nop [rax+rax*1], ax
000079035ddd89c0  mov rax, [r15+0x40]
000079035ddd89c4  mov r14, [r15+0x58]
000079035ddd89c8  lea r12, [rax+r14*1]
000079035ddd89cc  movaps xmm1, [r15+0x1D0]
000079035ddd89d4  vmovaps [rsp+0x10], xmm1
000079035ddd89da  vmovaps xmm15, [rsp+0x10]
000079035ddd89e0  por xmm1, xmm15
000079035ddd89e5  movaps xmm14, [r15+0x1A0]
000079035ddd89ed  vmovaps [rsp+0x10], xmm14
000079035ddd89f3  vmovaps xmm13, [rsp+0x10]
000079035ddd89f9  por xmm14, xmm13
000079035ddd89fe  lea rax, [r12+0x30]
000079035ddd8a03  mov r11, [r13+rax*1]
000079035ddd8a08  lea rax, [r12+0x38]
000079035ddd8a0d  mov r10, [r13+rax*1]
000079035ddd8a12  movq xmm13, r11
000079035ddd8a17  movq xmm12, r10
000079035ddd8a1c  movq xmm13, xmm13
000079035ddd8a21  vmovaps [rsp+0x10], xmm13
000079035ddd8a27  movq xmm13, xmm13
000079035ddd8a2c  movaps [r15+0x130], xmm13
000079035ddd8a34  movq xmm12, xmm12
000079035ddd8a39  vmovaps [rsp+0x20], xmm12
000079035ddd8a3f  movq xmm12, xmm12
000079035ddd8a44  movaps [r15+0x280], xmm12
000079035ddd8a4c  movaps xmm13, [r15+0x270]
000079035ddd8a54  vmovaps [rsp+0x30], xmm13
000079035ddd8a5a  vmovaps xmm12, [rsp+0x30]
000079035ddd8a60  por xmm13, xmm12
000079035ddd8a65  lea rax, [r12+0x20]
000079035ddd8a6a  mov r11, [r13+rax*1]
000079035ddd8a6f  lea rax, [r12+0x28]
000079035ddd8a74  mov r10, [r13+rax*1]
000079035ddd8a79  movq xmm12, r11
000079035ddd8a7e  movq xmm11, r10
000079035ddd8a83  movq xmm12, xmm12
000079035ddd8a88  vmovaps [rsp+0x30], xmm12
000079035ddd8a8e  movq xmm12, xmm12
000079035ddd8a93  movaps [r15+0x150], xmm12
000079035ddd8a9b  movq xmm11, xmm11
000079035ddd8aa0  vmovaps [rsp+0x40], xmm11
000079035ddd8aa6  movq xmm11, xmm11
000079035ddd8aab  movaps [r15+0x140], xmm11
000079035ddd8ab3  lea rax, [r12+0x10]
000079035ddd8ab8  mov r11, [r13+rax*1]
000079035ddd8abd  lea rax, [r12+0x18]
000079035ddd8ac2  mov r10, [r13+rax*1]
000079035ddd8ac7  movq xmm12, r11
000079035ddd8acc  movq xmm11, r10
000079035ddd8ad1  movq xmm12, xmm12
000079035ddd8ad6  vmovaps [rsp+0x50], xmm12
000079035ddd8adc  movq xmm12, xmm12
000079035ddd8ae1  movaps [r15+0x170], xmm12
000079035ddd8ae9  movq xmm11, xmm11
000079035ddd8aee  vmovaps [rsp+0x60], xmm11
000079035ddd8af4  movq xmm11, xmm11
000079035ddd8af9  movaps [r15+0x160], xmm11
000079035ddd8b01  mov rax, [r13+r12*1]
000079035ddd8b06  vmovq xmm12, rax
000079035ddd8b0b  vpbroadcastq xmm12, xmm12
000079035ddd8b10  lea rax, [r12+0x08]
000079035ddd8b15  mov r12, [r13+rax*1]
000079035ddd8b1a  movq xmm11, r12
000079035ddd8b1f  movaps [r15+0x230], xmm11
000079035ddd8b27  mov rax, [r15+0xF8]
000079035ddd8b2e  lea r12, [rax+0x50]
000079035ddd8b32  movups xmm11, [r13+r12*1]
000079035ddd8b38  lea r12, [rax+0x60]
000079035ddd8b3c  movups xmm10, [r13+r12*1]
000079035ddd8b42  lea r12, [rax+0x30]
000079035ddd8b46  movups xmm9, [r13+r12*1]
000079035ddd8b4c  mov r12, [r15+0x50]
000079035ddd8b50  lea r11, [r12+r14*1]
000079035ddd8b54  mov [r15+0x60], r11
000079035ddd8b58  lea r12, [r14+0x40]
000079035ddd8b5c  mov [r15+0x58], r12
000079035ddd8b60  movaps xmm8, xmm12
000079035ddd8b64  mulpd xmm8, xmm15
000079035ddd8b69  vcmppd xmm7, xmm8, xmm8, 0x03
000079035ddd8b6f  ptest xmm7, xmm7
000079035ddd8b74  jnz 0x000079035DDD9997
000079035ddd8b7a  movq xmm15, qword ptr [r15+0x230]
000079035ddd8b83  vmovaps [rsp+0x70], xmm15
000079035ddd8b89  vpermilpd xmm15, xmm15, 0x00
000079035ddd8b8f  movaps xmm7, xmm9
000079035ddd8b93  mulpd xmm7, xmm15
000079035ddd8b98  vcmppd xmm6, xmm7, xmm7, 0x03
000079035ddd8b9d  ptest xmm6, xmm6
000079035ddd8ba2  jnz 0x000079035DDD9ADB
000079035ddd8ba8  vxorps xmm15, xmm15, xmm15
000079035ddd8bad  vpbroadcastq xmm15, xmm15
000079035ddd8bb2  movaps xmm9, xmm12
000079035ddd8bb6  mulpd xmm9, xmm10
000079035ddd8bbb  vcmppd xmm6, xmm9, xmm9, 0x03
000079035ddd8bc1  ptest xmm6, xmm6
000079035ddd8bc6  jnz 0x000079035DDD9C1D
000079035ddd8bcc  movaps xmm10, xmm12
000079035ddd8bd0  mulpd xmm10, xmm11
000079035ddd8bd5  vcmppd xmm6, xmm10, xmm10, 0x03
000079035ddd8bdb  ptest xmm6, xmm6
000079035ddd8be0  jnz 0x000079035DDD9D61
000079035ddd8be6  movaps xmm11, [r15+0x1F0]
000079035ddd8bee  movaps xmm6, xmm12
000079035ddd8bf2  mulpd xmm6, xmm11
000079035ddd8bf7  vcmppd xmm5, xmm6, xmm6, 0x03
000079035ddd8bfc  ptest xmm5, xmm5
000079035ddd8c01  jnz 0x000079035DDD9EA5
000079035ddd8c07  movaps xmm12, [r15+0x2A0]
000079035ddd8c0f  vmovaps [rsp+0x80], xmm12
000079035ddd8c18  vmovaps xmm11, [rsp+0x80]
000079035ddd8c21  por xmm12, xmm11
000079035ddd8c26  movaps xmm11, [r15+0x250]
000079035ddd8c2e  vmovaps [rsp+0x80], xmm11
000079035ddd8c37  vmovaps xmm5, [rsp+0x80]
000079035ddd8c40  por xmm11, xmm5
000079035ddd8c45  vmovaps xmm4, [rsp+0x70]
000079035ddd8c4b  vpermilpd xmm4, xmm4, 0x00
000079035ddd8c51  movaps xmm3, xmm5
000079035ddd8c54  mulpd xmm3, xmm4
000079035ddd8c58  vcmppd xmm2, xmm3, xmm3, 0x03
000079035ddd8c5d  ptest xmm2, xmm2
000079035ddd8c62  jnz 0x000079035DDD9FE7
000079035ddd8c68  mov [rsp+0x80], rax
000079035ddd8c70  xor eax, eax
000079035ddd8c72  mov r14d, 0x200
000079035ddd8c78  cmp r12, r14
000079035ddd8c7b  cmc
000079035ddd8c7c  lahf
000079035ddd8c7d  seto al
000079035ddd8c80  mov [r15+0x108], eax
000079035ddd8c87  movaps xmm5, xmm8
000079035ddd8c8b  addpd xmm5, xmm15
000079035ddd8c90  vcmppd xmm4, xmm5, xmm5, 0x03
000079035ddd8c95  ptest xmm4, xmm4
000079035ddd8c9a  jnz 0x000079035DDDA127
000079035ddd8ca0  movaps xmm8, [r15+0x1B0]
000079035ddd8ca8  movaps xmm4, xmm9
000079035ddd8cac  addpd xmm4, xmm8
000079035ddd8cb1  vcmppd xmm2, xmm4, xmm4, 0x03
000079035ddd8cb6  ptest xmm2, xmm2
000079035ddd8cbb  jnz 0x000079035DDDA269
000079035ddd8cc1  movaps xmm9, xmm10
000079035ddd8cc5  addpd xmm9, xmm8
000079035ddd8cca  vcmppd xmm2, xmm9, xmm9, 0x03
000079035ddd8cd0  ptest xmm2, xmm2
000079035ddd8cd5  jnz 0x000079035DDDA3AB
000079035ddd8cdb  movaps xmm10, [r15+0x2F0]
000079035ddd8ce3  vmovaps [rsp+0x90], xmm10
000079035ddd8cec  vmovaps xmm8, [rsp+0x90]
000079035ddd8cf5  por xmm10, xmm8
000079035ddd8cfa  movaps xmm8, [r15+0x2E0]
000079035ddd8d02  vmovaps [rsp+0x90], xmm8
000079035ddd8d0b  vmovaps xmm2, [rsp+0x90]
000079035ddd8d14  por xmm8, xmm2
000079035ddd8d19  movaps xmm2, [r15+0x2D0]
000079035ddd8d21  vmovaps [rsp+0x90], xmm2
000079035ddd8d2a  vmovaps [rsp+0xA0], xmm1
000079035ddd8d33  vmovaps xmm1, [rsp+0x90]
000079035ddd8d3c  por xmm2, xmm1
000079035ddd8d40  movaps xmm1, [r15+0x200]
000079035ddd8d48  vmovaps [rsp+0x90], xmm1
000079035ddd8d51  vmovaps [rsp+0xB0], xmm15
000079035ddd8d5a  vmovaps xmm15, [rsp+0x90]
000079035ddd8d63  por xmm1, xmm15
000079035ddd8d68  movaps xmm15, [r15+0x1C0]
000079035ddd8d70  vmovaps [rsp+0x90], xmm15
000079035ddd8d79  vmovaps [rsp+0xC0], xmm1
000079035ddd8d82  vmovaps xmm1, [rsp+0x90]
000079035ddd8d8b  por xmm15, xmm1
000079035ddd8d90  movaps xmm1, [r15+0x190]
000079035ddd8d98  vmovaps [rsp+0x90], xmm1
000079035ddd8da1  vmovaps [rsp+0xD0], xmm15
000079035ddd8daa  vmovaps xmm15, [rsp+0x90]
000079035ddd8db3  por xmm1, xmm15
000079035ddd8db8  movaps xmm15, [r15+0x300]
000079035ddd8dc0  vmovaps [rsp+0x90], xmm15
000079035ddd8dc9  vmovaps [rsp+0xE0], xmm1
000079035ddd8dd2  vmovaps xmm1, [rsp+0x90]
000079035ddd8ddb  por xmm15, xmm1
000079035ddd8de0  mov rax, [rsp+0x80]
000079035ddd8de8  lea r14, [rax+0xA0]
000079035ddd8def  movups xmm1, [r13+r14*1]
000079035ddd8df5  lea r14, [rax+0xB0]
000079035ddd8dfc  vmovaps [rsp+0x80], xmm1
000079035ddd8e05  movups xmm1, [r13+r14*1]
000079035ddd8e0b  vmovaps [rsp+0x90], xmm1
000079035ddd8e14  vmovaps [rsp+0xF0], xmm15
000079035ddd8e1d  vmovaps xmm15, [rsp+0xB0]
000079035ddd8e26  vmovaps [rsp+0xB0], xmm14
000079035ddd8e2f  movaps xmm1, xmm6
000079035ddd8e32  addpd xmm1, xmm15
000079035ddd8e37  vcmppd xmm14, xmm1, xmm1, 0x03
000079035ddd8e3c  ptest xmm14, xmm14
000079035ddd8e42  jnz 0x000079035DDDA503
000079035ddd8e48  lea r14, [rax+0xF0]
000079035ddd8e4f  movups xmm15, [r13+r14*1]
000079035ddd8e55  movaps xmm14, xmm4
000079035ddd8e59  addpd xmm14, xmm3
000079035ddd8e5e  vcmppd xmm6, xmm14, xmm14, 0x03
000079035ddd8e64  ptest xmm6, xmm6
000079035ddd8e69  jnz 0x000079035DDDA64E
000079035ddd8e6f  movaps xmm6, xmm9
000079035ddd8e73  addpd xmm6, xmm7
000079035ddd8e77  vcmppd xmm4, xmm6, xmm6, 0x03
000079035ddd8e7c  ptest xmm4, xmm4
000079035ddd8e81  jnz 0x000079035DDDA790
000079035ddd8e87  vmovaps xmm9, [rsp+0x70]
000079035ddd8e8d  vpermilpd xmm9, xmm9, 0x00
000079035ddd8e93  vmovaps xmm4, [rsp+0x90]
000079035ddd8e9c  movaps xmm7, xmm4
000079035ddd8e9f  mulpd xmm7, xmm9
000079035ddd8ea4  vcmppd xmm3, xmm7, xmm7, 0x03
000079035ddd8ea9  ptest xmm3, xmm3
000079035ddd8eae  jnz 0x000079035DDDA8D1
000079035ddd8eb4  vmovaps xmm9, [rsp+0x50]
000079035ddd8eba  vpermilpd xmm9, xmm9, 0x00
000079035ddd8ec0  movaps xmm4, xmm15
000079035ddd8ec4  mulpd xmm4, xmm9
000079035ddd8ec9  vcmppd xmm3, xmm4, xmm4, 0x03
000079035ddd8ece  ptest xmm3, xmm3
000079035ddd8ed3  jnz 0x000079035DDDAA12
000079035ddd8ed9  lea r14, [rax+0xE0]
000079035ddd8ee0  movups xmm15, [r13+r14*1]
000079035ddd8ee6  vmovaps xmm9, [rsp+0x70]
000079035ddd8eec  vpermilpd xmm9, xmm9, 0x00
000079035ddd8ef2  vmovaps [rsp+0x70], xmm1
000079035ddd8ef8  vmovaps xmm1, [rsp+0x80]
000079035ddd8f01  vmovaps [rsp+0x80], xmm15
000079035ddd8f0a  movaps xmm3, xmm1
000079035ddd8f0d  mulpd xmm3, xmm9
000079035ddd8f12  vcmppd xmm15, xmm3, xmm3, 0x03
000079035ddd8f17  ptest xmm15, xmm15
000079035ddd8f1d  jnz 0x000079035DDDAB5E
000079035ddd8f23  vmovaps xmm1, [rsp+0xF0]
000079035ddd8f2c  vmovaps xmm15, [rsp+0xF0]
000079035ddd8f35  por xmm1, xmm15
000079035ddd8f3a  movaps [r15+0x300], xmm1
000079035ddd8f42  vmovaps xmm15, [rsp+0xE0]
000079035ddd8f4b  vmovaps xmm9, [rsp+0xE0]
000079035ddd8f54  por xmm15, xmm9
000079035ddd8f59  movaps [r15+0x190], xmm15
000079035ddd8f61  vmovaps xmm9, [rsp+0x50]
000079035ddd8f67  vpermilpd xmm9, xmm9, 0x00
000079035ddd8f6d  vmovaps [rsp+0x90], xmm1
000079035ddd8f76  vmovaps [rsp+0xE0], xmm15
000079035ddd8f7f  vmovaps xmm15, [rsp+0x80]
000079035ddd8f88  vmovaps [rsp+0x80], xmm14
000079035ddd8f91  movaps xmm1, xmm15
000079035ddd8f95  mulpd xmm1, xmm9
000079035ddd8f9a  vcmppd xmm14, xmm1, xmm1, 0x03
000079035ddd8f9f  ptest xmm14, xmm14
000079035ddd8fa5  jnz 0x000079035DDDAC9F
000079035ddd8fab  lea r14, [rax+0x90]
000079035ddd8fb2  movups xmm15, [r13+r14*1]
000079035ddd8fb8  vmovaps xmm14, [rsp+0xD0]
000079035ddd8fc1  vmovaps xmm9, [rsp+0xD0]
000079035ddd8fca  por xmm14, xmm9
000079035ddd8fcf  movaps [r15+0x1C0], xmm14
000079035ddd8fd7  vmovaps xmm9, [rsp+0xC0]
000079035ddd8fe0  vmovaps [rsp+0xD0], xmm1
000079035ddd8fe9  vmovaps xmm1, [rsp+0xC0]
000079035ddd8ff2  por xmm9, xmm1
000079035ddd8ff7  movaps [r15+0x200], xmm9
000079035ddd8fff  vmovaps [rsp+0xC0], xmm2
000079035ddd9008  vmovaps xmm1, [rsp+0xC0]
000079035ddd9011  por xmm2, xmm1
000079035ddd9015  movaps [r15+0x2D0], xmm2
000079035ddd901d  vmovaps [rsp+0xC0], xmm8
000079035ddd9026  vmovaps xmm1, [rsp+0xC0]
000079035ddd902f  por xmm8, xmm1
000079035ddd9034  movaps [r15+0x2E0], xmm8
000079035ddd903c  vmovaps [rsp+0xC0], xmm15
000079035ddd9045  movaps xmm1, xmm5
000079035ddd9048  addpd xmm1, xmm7
000079035ddd904c  vcmppd xmm15, xmm1, xmm1, 0x03
000079035ddd9051  ptest xmm15, xmm15
000079035ddd9057  jnz 0x000079035DDDADEB
000079035ddd905d  vmovaps xmm15, [rsp+0x50]
000079035ddd9063  vpermilpd xmm15, xmm15, 0x00
000079035ddd9069  vmovaps xmm5, [rsp+0xC0]
000079035ddd9072  vmovaps [rsp+0xC0], xmm1
000079035ddd907b  movaps xmm7, xmm5
000079035ddd907e  mulpd xmm7, xmm15
000079035ddd9083  vcmppd xmm1, xmm7, xmm7, 0x03
000079035ddd9088  ptest xmm1, xmm1
000079035ddd908d  jnz 0x000079035DDDAF2B
000079035ddd9093  lea r14, [rax+0x80]
000079035ddd909a  movups xmm1, [r13+r14*1]
000079035ddd90a0  vmovaps xmm5, [rsp+0x70]
000079035ddd90a6  vmovaps [rsp+0x70], xmm1
000079035ddd90ac  movaps xmm15, xmm5
000079035ddd90b0  addpd xmm15, xmm3
000079035ddd90b5  vcmppd xmm1, xmm15, xmm15, 0x03
000079035ddd90bb  ptest xmm1, xmm1
000079035ddd90c0  jnz 0x000079035DDDB076
000079035ddd90c6  vmovaps xmm5, [rsp+0x80]
000079035ddd90cf  movaps xmm1, xmm5
000079035ddd90d2  addpd xmm1, xmm4
000079035ddd90d6  vcmppd xmm3, xmm1, xmm1, 0x03
000079035ddd90db  ptest xmm3, xmm3
000079035ddd90e0  jnz 0x000079035DDDB1B8
000079035ddd90e6  vmovaps [rsp+0x80], xmm10
000079035ddd90ef  vmovaps xmm5, [rsp+0x80]
000079035ddd90f8  por xmm10, xmm5
000079035ddd90fd  movaps [r15+0x2F0], xmm10
000079035ddd9105  vmovaps xmm5, [rsp+0x50]
000079035ddd910b  vpermilpd xmm5, xmm5, 0x00
000079035ddd9111  vmovaps xmm3, [rsp+0x70]
000079035ddd9117  vmovaps [rsp+0x50], xmm1
000079035ddd911d  movaps xmm4, xmm3
000079035ddd9120  mulpd xmm4, xmm5
000079035ddd9124  vcmppd xmm1, xmm4, xmm4, 0x03
000079035ddd9129  ptest xmm1, xmm1
000079035ddd912e  jnz 0x000079035DDDB2F8
000079035ddd9134  lea r14, [rax+0xD0]
000079035ddd913b  movups xmm1, [r13+r14*1]
000079035ddd9141  vmovaps xmm3, [rsp+0xD0]
000079035ddd914a  vmovaps [rsp+0x70], xmm1
000079035ddd9150  movaps xmm5, xmm6
000079035ddd9153  addpd xmm5, xmm3
000079035ddd9157  vcmppd xmm1, xmm5, xmm5, 0x03
000079035ddd915c  ptest xmm1, xmm1
000079035ddd9161  jnz 0x000079035DDDB442
000079035ddd9167  vmovaps xmm1, [rsp+0x60]
000079035ddd916d  vpermilpd xmm1, xmm1, 0x00
000079035ddd9173  movaps xmm6, xmm9
000079035ddd9177  mulpd xmm6, xmm1
000079035ddd917b  vcmppd xmm3, xmm6, xmm6, 0x03
000079035ddd9180  ptest xmm3, xmm3
000079035ddd9185  jnz 0x000079035DDDB582
000079035ddd918b  movaps [r15+0x260], xmm6
000079035ddd9193  vxorps xmm1, xmm1, xmm1
000079035ddd9197  vpbroadcastq xmm1, xmm1
000079035ddd919c  movaps [r15+0x1B0], xmm1
000079035ddd91a4  vmovaps xmm1, [rsp+0x60]
000079035ddd91aa  vpermilpd xmm1, xmm1, 0x00
000079035ddd91b0  vmovaps xmm3, [rsp+0x70]
000079035ddd91b6  vmovaps [rsp+0x70], xmm15
000079035ddd91bc  movaps xmm9, xmm3
000079035ddd91c0  mulpd xmm9, xmm1
000079035ddd91c5  vcmppd xmm15, xmm9, xmm9, 0x03
000079035ddd91cb  ptest xmm15, xmm15
000079035ddd91d1  jnz 0x000079035DDDB6C3
000079035ddd91d7  lea r14, [rax+0xC0]
000079035ddd91de  movups xmm1, [r13+r14*1]
000079035ddd91e4  vmovaps xmm3, [rsp+0xC0]
000079035ddd91ed  vmovaps [rsp+0x80], xmm1
000079035ddd91f6  movaps xmm15, xmm3
000079035ddd91fa  addpd xmm15, xmm7
000079035ddd91ff  vcmppd xmm1, xmm15, xmm15, 0x03
000079035ddd9205  ptest xmm1, xmm1
000079035ddd920a  jnz 0x000079035DDDB80F
000079035ddd9210  vmovaps [rsp+0xC0], xmm13
000079035ddd9219  vmovaps xmm1, [rsp+0xC0]
000079035ddd9222  por xmm13, xmm1
000079035ddd9227  movaps [r15+0x270], xmm13
000079035ddd922f  vmovaps xmm1, [rsp+0xB0]
000079035ddd9238  vmovaps xmm7, [rsp+0xB0]
000079035ddd9241  por xmm1, xmm7
000079035ddd9245  movaps [r15+0x1A0], xmm1
000079035ddd924d  vmovaps xmm1, [rsp+0x60]
000079035ddd9253  vpermilpd xmm1, xmm1, 0x00
000079035ddd9259  vmovaps [rsp+0xB0], xmm1
000079035ddd9262  vmovaps xmm1, [rsp+0x80]
000079035ddd926b  vmovaps [rsp+0x80], xmm15
000079035ddd9274  vmovaps xmm15, [rsp+0xB0]
000079035ddd927d  vmovaps [rsp+0xB0], xmm14
000079035ddd9286  movaps xmm3, xmm1
000079035ddd9289  mulpd xmm3, xmm15
000079035ddd928e  vcmppd xmm14, xmm3, xmm3, 0x03
000079035ddd9293  ptest xmm14, xmm14
000079035ddd9299  jnz 0x000079035DDDB951
000079035ddd929f  lea r14, [rax+0x20]
000079035ddd92a3  movups xmm1, [r13+r14*1]
000079035ddd92a9  movaps [r15+0x110], xmm1
000079035ddd92b1  vmovaps xmm14, [rsp+0x70]
000079035ddd92b7  vmovaps [rsp+0x70], xmm1
000079035ddd92bd  movaps xmm15, xmm14
000079035ddd92c1  addpd xmm15, xmm4
000079035ddd92c6  vcmppd xmm1, xmm15, xmm15, 0x03
000079035ddd92cc  ptest xmm1, xmm1
000079035ddd92d1  jnz 0x000079035DDDBA9C
000079035ddd92d7  vmovaps xmm1, [rsp+0x60]
000079035ddd92dd  vpermilpd xmm1, xmm1, 0x00
000079035ddd92e3  movaps xmm14, xmm2
000079035ddd92e7  mulpd xmm14, xmm1
000079035ddd92ec  vcmppd xmm4, xmm14, xmm14, 0x03
000079035ddd92f2  ptest xmm4, xmm4
000079035ddd92f7  jnz 0x000079035DDDBBDF
000079035ddd92fd  vmovaps xmm4, [rsp+0x50]
000079035ddd9303  movaps xmm1, xmm4
000079035ddd9306  addpd xmm1, xmm9
000079035ddd930b  vcmppd xmm2, xmm1, xmm1, 0x03
000079035ddd9310  ptest xmm2, xmm2
000079035ddd9315  jnz 0x000079035DDDBD21
000079035ddd931b  vmovaps xmm9, [rsp+0x30]
000079035ddd9321  vpermilpd xmm9, xmm9, 0x00
000079035ddd9327  vmovaps xmm2, [rsp+0x70]
000079035ddd932d  vmovaps [rsp+0x50], xmm1
000079035ddd9333  movaps xmm4, xmm2
000079035ddd9336  mulpd xmm4, xmm9
000079035ddd933b  vcmppd xmm1, xmm4, xmm4, 0x03
000079035ddd9340  ptest xmm1, xmm1
000079035ddd9345  jnz 0x000079035DDDBE62
000079035ddd934b  vmovaps xmm1, [rsp+0x30]
000079035ddd9351  vpermilpd xmm1, xmm1, 0x00
000079035ddd9357  vmovaps xmm2, [rsp+0x90]
000079035ddd9360  vmovaps [rsp+0x60], xmm15
000079035ddd9366  movaps xmm9, xmm2
000079035ddd936a  mulpd xmm9, xmm1
000079035ddd936f  vcmppd xmm15, xmm9, xmm9, 0x03
000079035ddd9375  ptest xmm15, xmm15
000079035ddd937b  jnz 0x000079035DDDBFA3
000079035ddd9381  vmovaps xmm15, [rsp+0x80]
000079035ddd938a  movaps xmm1, xmm15
000079035ddd938e  addpd xmm1, xmm6
000079035ddd9392  vcmppd xmm2, xmm1, xmm1, 0x03
000079035ddd9397  ptest xmm2, xmm2
000079035ddd939c  jnz 0x000079035DDDC0E5
000079035ddd93a2  movaps xmm15, xmm5
000079035ddd93a6  addpd xmm15, xmm3
000079035ddd93ab  vcmppd xmm6, xmm15, xmm15, 0x03
000079035ddd93b1  ptest xmm6, xmm6
000079035ddd93b6  jnz 0x000079035DDDC226
000079035ddd93bc  vmovaps xmm6, [rsp+0x30]
000079035ddd93c2  vpermilpd xmm6, xmm6, 0x00
000079035ddd93c8  movaps xmm5, xmm8
000079035ddd93cc  mulpd xmm5, xmm6
000079035ddd93d0  vcmppd xmm3, xmm5, xmm5, 0x03
000079035ddd93d5  ptest xmm3, xmm3
000079035ddd93da  jnz 0x000079035DDDC368
000079035ddd93e0  vmovaps xmm8, [rsp+0x30]
000079035ddd93e6  vpermilpd xmm8, xmm8, 0x00
000079035ddd93ec  movaps xmm6, xmm10
000079035ddd93f0  mulpd xmm6, xmm8
000079035ddd93f5  vcmppd xmm3, xmm6, xmm6, 0x03
000079035ddd93fa  ptest xmm3, xmm3
000079035ddd93ff  jnz 0x000079035DDDC4A9
000079035ddd9405  vmovaps xmm8, [rsp+0x60]
000079035ddd940b  movaps xmm10, xmm8
000079035ddd940f  addpd xmm10, xmm14
000079035ddd9414  vcmppd xmm3, xmm10, xmm10, 0x03
000079035ddd941a  ptest xmm3, xmm3
000079035ddd941f  jnz 0x000079035DDDC5EB
000079035ddd9425  vmovaps xmm8, [rsp+0x50]
000079035ddd942b  movaps xmm14, xmm8
000079035ddd942f  addpd xmm14, xmm4
000079035ddd9434  vcmppd xmm3, xmm14, xmm14, 0x03
000079035ddd943a  ptest xmm3, xmm3
000079035ddd943f  jnz 0x000079035DDDC72F
000079035ddd9445  vmovaps xmm8, [rsp+0x40]
000079035ddd944b  vpermilpd xmm8, xmm8, 0x00
000079035ddd9451  movaps xmm4, xmm13
000079035ddd9455  mulpd xmm4, xmm8
000079035ddd945a  vcmppd xmm3, xmm4, xmm4, 0x03
000079035ddd945f  ptest xmm3, xmm3
000079035ddd9464  jnz 0x000079035DDDC872
000079035ddd946a  movaps xmm13, xmm15
000079035ddd946e  addpd xmm13, xmm9
000079035ddd9473  vcmppd xmm8, xmm13, xmm13, 0x03
000079035ddd9479  ptest xmm8, xmm8
000079035ddd947f  jnz 0x000079035DDDC9B4
000079035ddd9485  movaps xmm15, xmm1
000079035ddd9489  addpd xmm15, xmm5
000079035ddd948e  vcmppd xmm9, xmm15, xmm15, 0x03
000079035ddd9494  ptest xmm9, xmm9
000079035ddd949a  jnz 0x000079035DDDCAF8
000079035ddd94a0  vmovaps [rsp+0x30], xmm11
000079035ddd94a6  vmovaps xmm1, [rsp+0x30]
000079035ddd94ac  por xmm11, xmm1
000079035ddd94b1  movaps [r15+0x250], xmm11
000079035ddd94b9  vmovaps [rsp+0x30], xmm12
000079035ddd94bf  vmovaps xmm1, [rsp+0x30]
000079035ddd94c5  por xmm12, xmm1
000079035ddd94ca  movaps [r15+0x2A0], xmm12
000079035ddd94d2  vmovaps xmm1, [rsp+0xA0]
000079035ddd94db  vmovaps xmm11, [rsp+0xA0]
000079035ddd94e4  por xmm1, xmm11
000079035ddd94e9  movaps [r15+0x1D0], xmm1
000079035ddd94f1  lea r14, [rax+0x40]
000079035ddd94f5  movups xmm1, [r13+r14*1]
000079035ddd94fb  movaps [r15+0x2C0], xmm1
000079035ddd9503  vmovaps xmm11, [rsp+0x40]
000079035ddd9509  vpermilpd xmm11, xmm11, 0x00
000079035ddd950f  vmovaps xmm8, [rsp+0xE0]
000079035ddd9518  movaps xmm9, xmm8
000079035ddd951c  mulpd xmm9, xmm11
000079035ddd9521  vcmppd xmm5, xmm9, xmm9, 0x03
000079035ddd9527  ptest xmm5, xmm5
000079035ddd952c  jnz 0x000079035DDDCC44
000079035ddd9532  movaps xmm11, xmm10
000079035ddd9536  addpd xmm11, xmm6
000079035ddd953b  vcmppd xmm8, xmm11, xmm11, 0x03
000079035ddd9541  ptest xmm8, xmm8
000079035ddd9547  jnz 0x000079035DDDCD88
000079035ddd954d  movaps xmm10, xmm14
000079035ddd9551  addpd xmm10, xmm4
000079035ddd9556  vcmppd xmm8, xmm10, xmm10, 0x03
000079035ddd955c  ptest xmm8, xmm8
000079035ddd9562  jnz 0x000079035DDDCECB
000079035ddd9568  vmovaps xmm14, [rsp+0x40]
000079035ddd956e  vpermilpd xmm14, xmm14, 0x00
000079035ddd9574  movaps xmm8, xmm1
000079035ddd9578  mulpd xmm8, xmm14
000079035ddd957d  vcmppd xmm6, xmm8, xmm8, 0x03
000079035ddd9583  ptest xmm6, xmm6
000079035ddd9588  jnz 0x000079035DDDD00E
000079035ddd958e  movaps xmm1, [r15+0x2B0]
000079035ddd9596  vmovaps xmm14, [rsp+0x40]
000079035ddd959c  vpermilpd xmm14, xmm14, 0x00
000079035ddd95a2  movaps xmm6, xmm1
000079035ddd95a5  mulpd xmm6, xmm14
000079035ddd95aa  vcmppd xmm5, xmm6, xmm6, 0x03
000079035ddd95af  ptest xmm5, xmm5
000079035ddd95b4  jnz 0x000079035DDDD151
000079035ddd95ba  vmovaps xmm1, [rsp+0x10]
000079035ddd95c0  vpermilpd xmm1, xmm1, 0x00
000079035ddd95c6  movaps xmm14, xmm12
000079035ddd95ca  mulpd xmm14, xmm1
000079035ddd95cf  vcmppd xmm5, xmm14, xmm14, 0x03
000079035ddd95d5  ptest xmm5, xmm5
000079035ddd95da  jnz 0x000079035DDDD292
000079035ddd95e0  movaps xmm1, xmm13
000079035ddd95e4  addpd xmm1, xmm9
000079035ddd95e9  vcmppd xmm12, xmm1, xmm1, 0x03
000079035ddd95ee  ptest xmm12, xmm12
000079035ddd95f4  jnz 0x000079035DDDD3D5
000079035ddd95fa  vmovaps xmm13, [rsp+0x10]
000079035ddd9600  vpermilpd xmm13, xmm13, 0x00
000079035ddd9606  movaps xmm12, xmm7
000079035ddd960a  mulpd xmm12, xmm13
000079035ddd960f  vcmppd xmm9, xmm12, xmm12, 0x03
000079035ddd9615  ptest xmm9, xmm9
000079035ddd961b  jnz 0x000079035DDDD517
000079035ddd9621  movaps xmm13, xmm15
000079035ddd9625  addpd xmm13, xmm8
000079035ddd962a  vcmppd xmm9, xmm13, xmm13, 0x03
000079035ddd9630  ptest xmm9, xmm9
000079035ddd9636  jnz 0x000079035DDDD65A
000079035ddd963c  movaps xmm15, [r15+0x290]
000079035ddd9644  vmovaps xmm9, [rsp+0x10]
000079035ddd964a  vpermilpd xmm9, xmm9, 0x00
000079035ddd9650  movaps xmm8, xmm15
000079035ddd9654  mulpd xmm8, xmm9
000079035ddd9659  vcmppd xmm7, xmm8, xmm8, 0x03
000079035ddd965f  ptest xmm7, xmm7
000079035ddd9664  jnz 0x000079035DDDD79E
000079035ddd966a  movaps xmm15, xmm11
000079035ddd966e  addpd xmm15, xmm6
000079035ddd9673  vcmppd xmm9, xmm15, xmm15, 0x03
000079035ddd9679  ptest xmm9, xmm9
000079035ddd967f  jnz 0x000079035DDDD8E2
000079035ddd9685  movaps xmm11, [r15+0x1E0]
000079035ddd968d  vmovaps xmm9, [rsp+0x10]
000079035ddd9693  vpermilpd xmm9, xmm9, 0x00
000079035ddd9699  movaps xmm7, xmm11
000079035ddd969d  mulpd xmm7, xmm9
000079035ddd96a2  vcmppd xmm6, xmm7, xmm7, 0x03
000079035ddd96a7  ptest xmm6, xmm6
000079035ddd96ac  jnz 0x000079035DDDDA25
000079035ddd96b2  movaps xmm11, xmm10
000079035ddd96b6  addpd xmm11, xmm14
000079035ddd96bb  vcmppd xmm9, xmm11, xmm11, 0x03
000079035ddd96c1  ptest xmm9, xmm9
000079035ddd96c7  jnz 0x000079035DDDDB67
000079035ddd96cd  lea r14, [rax+0x70]
000079035ddd96d1  movups xmm14, [r13+r14*1]
000079035ddd96d7  movaps [r15+0x240], xmm14
000079035ddd96df  movaps xmm10, xmm1
000079035ddd96e3  addpd xmm10, xmm12
000079035ddd96e8  vcmppd xmm9, xmm10, xmm10, 0x03
000079035ddd96ee  ptest xmm9, xmm9
000079035ddd96f4  jnz 0x000079035DDDDCB5
000079035ddd96fa  movaps [r15+0x170], xmm10
000079035ddd9702  vmovaps xmm1, [rsp+0x20]
000079035ddd9708  vpermilpd xmm1, xmm1, 0x00
000079035ddd970e  movaps xmm12, xmm14
000079035ddd9712  mulpd xmm12, xmm1
000079035ddd9717  vcmppd xmm9, xmm12, xmm12, 0x03
000079035ddd971d  ptest xmm9, xmm9
000079035ddd9723  jnz 0x000079035DDDDDF8
000079035ddd9729  vmovaps xmm1, [rsp+0x20]
000079035ddd972f  vpermilpd xmm1, xmm1, 0x00
000079035ddd9735  vmovaps xmm9, [rsp+0xB0]
000079035ddd973e  movaps xmm14, xmm9
000079035ddd9742  mulpd xmm14, xmm1
000079035ddd9747  vcmppd xmm6, xmm14, xmm14, 0x03
000079035ddd974d  ptest xmm6, xmm6
000079035ddd9752  jnz 0x000079035DDDDF3B
000079035ddd9758  movaps [r15+0x180], xmm14
000079035ddd9760  movaps xmm1, xmm13
000079035ddd9764  addpd xmm1, xmm8
000079035ddd9769  vcmppd xmm9, xmm1, xmm1, 0x03
000079035ddd976e  ptest xmm9, xmm9
000079035ddd9774  jnz 0x000079035DDDE07E
000079035ddd977a  movaps [r15+0x210], xmm1
000079035ddd9782  movups xmm13, [r13+rax*1]
000079035ddd9788  lea r14, [rax+0x10]
000079035ddd978c  movups xmm9, [r13+r14*1]
000079035ddd9792  movaps [r15+0x230], xmm9
000079035ddd979a  movaps xmm8, xmm15
000079035ddd979e  addpd xmm8, xmm7
000079035ddd97a3  vcmppd xmm6, xmm8, xmm8, 0x03
000079035ddd97a9  ptest xmm6, xmm6
000079035ddd97ae  jnz 0x000079035DDDE1D4
000079035ddd97b4  movaps [r15+0x130], xmm8
000079035ddd97bc  vmovaps xmm15, [rsp+0x20]
000079035ddd97c2  vpermilpd xmm15, xmm15, 0x00
000079035ddd97c8  movaps xmm7, xmm9
000079035ddd97cc  mulpd xmm7, xmm15
000079035ddd97d1  vcmppd xmm6, xmm7, xmm7, 0x03
000079035ddd97d6  ptest xmm6, xmm6
000079035ddd97db  jnz 0x000079035DDDE317
000079035ddd97e1  movaps [r15+0x220], xmm7
000079035ddd97e9  vmovaps xmm15, [rsp+0x20]
000079035ddd97ef  vpermilpd xmm15, xmm15, 0x00
000079035ddd97f5  movaps xmm9, xmm13
000079035ddd97f9  mulpd xmm9, xmm15
000079035ddd97fe  vcmppd xmm6, xmm9, xmm9, 0x03
000079035ddd9804  ptest xmm6, xmm6
000079035ddd9809  jnz 0x000079035DDDE459
000079035ddd980f  movaps xmm15, xmm11
000079035ddd9813  addpd xmm15, xmm12
000079035ddd9818  vcmppd xmm13, xmm15, xmm15, 0x03
000079035ddd981e  ptest xmm13, xmm13
000079035ddd9824  jnz 0x000079035DDDE59D
000079035ddd982a  movaps [r15+0x140], xmm15
000079035ddd9832  movaps xmm13, xmm10
000079035ddd9836  addpd xmm13, xmm14
000079035ddd983b  vcmppd xmm12, xmm13, xmm13, 0x03
000079035ddd9841  ptest xmm12, xmm12
000079035ddd9847  jnz 0x000079035DDDE6E1
000079035ddd984d  movaps [r15+0x150], xmm13
000079035ddd9855  movaps xmm14, xmm1
000079035ddd9859  addpd xmm14, xmm7
000079035ddd985e  vcmppd xmm12, xmm14, xmm14, 0x03
000079035ddd9864  ptest xmm12, xmm12
000079035ddd986a  jnz 0x000079035DDDE825
000079035ddd9870  movaps [r15+0x160], xmm14
000079035ddd9878  movaps xmm1, xmm8
000079035ddd987c  addpd xmm1, xmm9
000079035ddd9881  vcmppd xmm12, xmm1, xmm1, 0x03
000079035ddd9886  ptest xmm12, xmm12
000079035ddd988c  jnz 0x000079035DDDE967
000079035ddd9892  movaps [r15+0x120], xmm1
000079035ddd989a  movups [r13+r11*1], xmm15
000079035ddd98a0  lea rax, [r11+0x10]
000079035ddd98a4  movups [r13+rax*1], xmm13
000079035ddd98aa  lea rax, [r11+0x20]
000079035ddd98ae  movups [r13+rax*1], xmm14
000079035ddd98b4  lea rax, [r11+0x30]
000079035ddd98b8  movups [r13+rax*1], xmm1
000079035ddd98be  mov eax, [r15+0x108]
000079035ddd98c5  sahf
000079035ddd98c6  jnz 0x000079035DDD98F8
000079035ddd98c8  cmp dword ptr [r15+0x318], 0x00
000079035ddd98d0  jz 0x000079035DDDEAE0
000079035ddd98d6  nop [rax+rax*1], ax
000079035ddd98df  nop [rax+rax*1], eax
000079035ddd98e7  mov eax, 0x4106D0
000079035ddd98ec  mov [r15+0x100], rax
000079035ddd98f3  jmp 0x000079035DBFE110
000079035ddd98f8  cmp dword ptr [r15+0x318], 0x00
000079035ddd9900  jz 0x000079035DDD89C0
000079035ddd9906  nop [rax+rax*1], ax
000079035ddd990f  nop [rax+rax*1], eax
000079035ddd9917  mov eax, 0x410504
000079035ddd991c  mov [r15+0x100], rax
000079035ddd9923  jmp 0x000079035DBFE110
000079035ddd9928  int3
000079035ddd9929  call 0x000079035DC0A4B0
000079035ddd992e  jmp 0x000079035DDD8A08
000079035ddd9933  call 0x000079035DC09240
000079035ddd9938  jmp 0x000079035DDD8A12
000079035ddd993d  call 0x000079035DC0A4B0
000079035ddd9942  jmp 0x000079035DDD8A6F
000079035ddd9947  call 0x000079035DC09240
000079035ddd994c  jmp 0x000079035DDD8A79
000079035ddd9951  call 0x000079035DC0A4B0
000079035ddd9956  jmp 0x000079035DDD8ABD
000079035ddd995b  call 0x000079035DC09240
000079035ddd9960  jmp 0x000079035DDD8AC7
000079035ddd9965  call 0x000079035DCB47C0
000079035ddd996a  jmp 0x000079035DDD8B06
000079035ddd996f  call 0x000079035DC0B720
000079035ddd9974  jmp 0x000079035DDD8B1A
000079035ddd9979  call 0x000079035DCBFC30
000079035ddd997e  jmp 0x000079035DDD8B38
000079035ddd9983  call 0x000079035DCBE9C0
000079035ddd9988  jmp 0x000079035DDD8B42
000079035ddd998d  call 0x000079035DCBD750
000079035ddd9992  jmp 0x000079035DDD8B4C
000079035ddd9997  sub rsp, 0x08
000079035ddd999b  push rax
000079035ddd999c  push rcx
000079035ddd999d  push rdx
000079035ddd999e  push rdi
000079035ddd999f  push rsi
000079035ddd99a0  push r8
000079035ddd99a2  push r9
000079035ddd99a4  push r10
000079035ddd99a6  push r11
000079035ddd99a8  sub rsp, 0xF0
000079035ddd99af  vmovaps [rsp], xmm0
000079035ddd99b4  vmovaps [rsp+0x10], xmm1
000079035ddd99ba  vmovaps [rsp+0x20], xmm2
000079035ddd99c0  vmovaps [rsp+0x30], xmm3
000079035ddd99c6  vmovaps [rsp+0x40], xmm4
000079035ddd99cc  vmovaps [rsp+0x50], xmm5
000079035ddd99d2  vmovaps [rsp+0x60], xmm6
000079035ddd99d8  vmovaps [rsp+0x70], xmm7
000079035ddd99de  vmovaps [rsp+0x80], xmm9
000079035ddd99e7  vmovaps [rsp+0x90], xmm10
000079035ddd99f0  vmovaps [rsp+0xA0], xmm11
000079035ddd99f9  vmovaps [rsp+0xB0], xmm12
000079035ddd9a02  vmovaps [rsp+0xC0], xmm13
000079035ddd9a0b  vmovaps [rsp+0xD0], xmm14
000079035ddd9a14  vmovaps [rsp+0xE0], xmm15
000079035ddd9a1d  sub rsp, 0x30
000079035ddd9a21  movaps [rsp], xmm8
000079035ddd9a26  movaps [rsp+0x10], xmm12
000079035ddd9a2c  movaps [rsp+0x20], xmm15
000079035ddd9a32  lea rdi, [rsp]
000079035ddd9a36  mov esi, 0x00
000079035ddd9a3b  mov rax, 0x64ACAA8B0530
000079035ddd9a45  call rax
000079035ddd9a47  movaps xmm8, [rsp]
000079035ddd9a4c  add rsp, 0x30
000079035ddd9a50  vmovaps xmm0, [rsp]
000079035ddd9a55  vmovaps xmm1, [rsp+0x10]
000079035ddd9a5b  vmovaps xmm2, [rsp+0x20]
000079035ddd9a61  vmovaps xmm3, [rsp+0x30]
000079035ddd9a67  vmovaps xmm4, [rsp+0x40]
000079035ddd9a6d  vmovaps xmm5, [rsp+0x50]
000079035ddd9a73  vmovaps xmm6, [rsp+0x60]
000079035ddd9a79  vmovaps xmm7, [rsp+0x70]
000079035ddd9a7f  vmovaps xmm9, [rsp+0x80]
000079035ddd9a88  vmovaps xmm10, [rsp+0x90]
000079035ddd9a91  vmovaps xmm11, [rsp+0xA0]
000079035ddd9a9a  vmovaps xmm12, [rsp+0xB0]
000079035ddd9aa3  vmovaps xmm13, [rsp+0xC0]
000079035ddd9aac  vmovaps xmm14, [rsp+0xD0]
000079035ddd9ab5  vmovaps xmm15, [rsp+0xE0]
000079035ddd9abe  add rsp, 0xF0
000079035ddd9ac5  pop r11
000079035ddd9ac7  pop r10
000079035ddd9ac9  pop r9
000079035ddd9acb  pop r8
000079035ddd9acd  pop rsi
000079035ddd9ace  pop rdi
000079035ddd9acf  pop rdx
000079035ddd9ad0  pop rcx
000079035ddd9ad1  pop rax
000079035ddd9ad2  add rsp, 0x08
000079035ddd9ad6  jmp 0x000079035DDD8B7A
000079035ddd9adb  sub rsp, 0x08
000079035ddd9adf  push rax
000079035ddd9ae0  push rcx
000079035ddd9ae1  push rdx
000079035ddd9ae2  push rdi
000079035ddd9ae3  push rsi
000079035ddd9ae4  push r8
000079035ddd9ae6  push r9
000079035ddd9ae8  push r10
000079035ddd9aea  push r11
000079035ddd9aec  sub rsp, 0xF0
000079035ddd9af3  vmovaps [rsp], xmm0
000079035ddd9af8  vmovaps [rsp+0x10], xmm1
000079035ddd9afe  vmovaps [rsp+0x20], xmm2
000079035ddd9b04  vmovaps [rsp+0x30], xmm3
000079035ddd9b0a  vmovaps [rsp+0x40], xmm4
000079035ddd9b10  vmovaps [rsp+0x50], xmm5
000079035ddd9b16  vmovaps [rsp+0x60], xmm6
000079035ddd9b1c  vmovaps [rsp+0x70], xmm8
000079035ddd9b22  vmovaps [rsp+0x80], xmm9
000079035ddd9b2b  vmovaps [rsp+0x90], xmm10
000079035ddd9b34  vmovaps [rsp+0xA0], xmm11
000079035ddd9b3d  vmovaps [rsp+0xB0], xmm12
000079035ddd9b46  vmovaps [rsp+0xC0], xmm13
000079035ddd9b4f  vmovaps [rsp+0xD0], xmm14
000079035ddd9b58  vmovaps [rsp+0xE0], xmm15
000079035ddd9b61  sub rsp, 0x30
000079035ddd9b65  movaps [rsp], xmm7
000079035ddd9b69  movaps [rsp+0x10], xmm9
000079035ddd9b6f  movaps [rsp+0x20], xmm15
000079035ddd9b75  lea rdi, [rsp]
000079035ddd9b79  mov esi, 0x00
000079035ddd9b7e  mov rax, 0x64ACAA8B0530
000079035ddd9b88  call rax
000079035ddd9b8a  movaps xmm7, [rsp]
000079035ddd9b8e  add rsp, 0x30
000079035ddd9b92  vmovaps xmm0, [rsp]
000079035ddd9b97  vmovaps xmm1, [rsp+0x10]
000079035ddd9b9d  vmovaps xmm2, [rsp+0x20]
000079035ddd9ba3  vmovaps xmm3, [rsp+0x30]
000079035ddd9ba9  vmovaps xmm4, [rsp+0x40]
000079035ddd9baf  vmovaps xmm5, [rsp+0x50]
000079035ddd9bb5  vmovaps xmm6, [rsp+0x60]
000079035ddd9bbb  vmovaps xmm8, [rsp+0x70]
000079035ddd9bc1  vmovaps xmm9, [rsp+0x80]
000079035ddd9bca  vmovaps xmm10, [rsp+0x90]
000079035ddd9bd3  vmovaps xmm11, [rsp+0xA0]
000079035ddd9bdc  vmovaps xmm12, [rsp+0xB0]
000079035ddd9be5  vmovaps xmm13, [rsp+0xC0]
000079035ddd9bee  vmovaps xmm14, [rsp+0xD0]
000079035ddd9bf7  vmovaps xmm15, [rsp+0xE0]
000079035ddd9c00  add rsp, 0xF0
000079035ddd9c07  pop r11
000079035ddd9c09  pop r10
000079035ddd9c0b  pop r9
000079035ddd9c0d  pop r8
000079035ddd9c0f  pop rsi
000079035ddd9c10  pop rdi
000079035ddd9c11  pop rdx
000079035ddd9c12  pop rcx
000079035ddd9c13  pop rax
000079035ddd9c14  add rsp, 0x08
000079035ddd9c18  jmp 0x000079035DDD8BA8
000079035ddd9c1d  sub rsp, 0x08
000079035ddd9c21  push rax
000079035ddd9c22  push rcx
000079035ddd9c23  push rdx
000079035ddd9c24  push rdi
000079035ddd9c25  push rsi
000079035ddd9c26  push r8
000079035ddd9c28  push r9
000079035ddd9c2a  push r10
000079035ddd9c2c  push r11
000079035ddd9c2e  sub rsp, 0xF0
000079035ddd9c35  vmovaps [rsp], xmm0
000079035ddd9c3a  vmovaps [rsp+0x10], xmm1
000079035ddd9c40  vmovaps [rsp+0x20], xmm2
000079035ddd9c46  vmovaps [rsp+0x30], xmm3
000079035ddd9c4c  vmovaps [rsp+0x40], xmm4
000079035ddd9c52  vmovaps [rsp+0x50], xmm5
000079035ddd9c58  vmovaps [rsp+0x60], xmm6
000079035ddd9c5e  vmovaps [rsp+0x70], xmm7
000079035ddd9c64  vmovaps [rsp+0x80], xmm8
000079035ddd9c6d  vmovaps [rsp+0x90], xmm10
000079035ddd9c76  vmovaps [rsp+0xA0], xmm11
000079035ddd9c7f  vmovaps [rsp+0xB0], xmm12
000079035ddd9c88  vmovaps [rsp+0xC0], xmm13
000079035ddd9c91  vmovaps [rsp+0xD0], xmm14
000079035ddd9c9a  vmovaps [rsp+0xE0], xmm15
000079035ddd9ca3  sub rsp, 0x30
000079035ddd9ca7  movaps [rsp], xmm9
000079035ddd9cac  movaps [rsp+0x10], xmm12
000079035ddd9cb2  movaps [rsp+0x20], xmm10
000079035ddd9cb8  lea rdi, [rsp]
000079035ddd9cbc  mov esi, 0x00
000079035ddd9cc1  mov rax, 0x64ACAA8B0530
000079035ddd9ccb  call rax
000079035ddd9ccd  movaps xmm9, [rsp]
000079035ddd9cd2  add rsp, 0x30
000079035ddd9cd6  vmovaps xmm0, [rsp]
000079035ddd9cdb  vmovaps xmm1, [rsp+0x10]
000079035ddd9ce1  vmovaps xmm2, [rsp+0x20]
000079035ddd9ce7  vmovaps xmm3, [rsp+0x30]
000079035ddd9ced  vmovaps xmm4, [rsp+0x40]
000079035ddd9cf3  vmovaps xmm5, [rsp+0x50]
000079035ddd9cf9  vmovaps xmm6, [rsp+0x60]
000079035ddd9cff  vmovaps xmm7, [rsp+0x70]
000079035ddd9d05  vmovaps xmm8, [rsp+0x80]
000079035ddd9d0e  vmovaps xmm10, [rsp+0x90]
000079035ddd9d17  vmovaps xmm11, [rsp+0xA0]
000079035ddd9d20  vmovaps xmm12, [rsp+0xB0]
000079035ddd9d29  vmovaps xmm13, [rsp+0xC0]
000079035ddd9d32  vmovaps xmm14, [rsp+0xD0]
000079035ddd9d3b  vmovaps xmm15, [rsp+0xE0]
000079035ddd9d44  add rsp, 0xF0
000079035ddd9d4b  pop r11
000079035ddd9d4d  pop r10
000079035ddd9d4f  pop r9
000079035ddd9d51  pop r8
000079035ddd9d53  pop rsi
000079035ddd9d54  pop rdi
000079035ddd9d55  pop rdx
000079035ddd9d56  pop rcx
000079035ddd9d57  pop rax
000079035ddd9d58  add rsp, 0x08
000079035ddd9d5c  jmp 0x000079035DDD8BCC
000079035ddd9d61  sub rsp, 0x08
000079035ddd9d65  push rax
000079035ddd9d66  push rcx
000079035ddd9d67  push rdx
000079035ddd9d68  push rdi
000079035ddd9d69  push rsi
000079035ddd9d6a  push r8
000079035ddd9d6c  push r9
000079035ddd9d6e  push r10
000079035ddd9d70  push r11
000079035ddd9d72  sub rsp, 0xF0
000079035ddd9d79  vmovaps [rsp], xmm0
000079035ddd9d7e  vmovaps [rsp+0x10], xmm1
000079035ddd9d84  vmovaps [rsp+0x20], xmm2
000079035ddd9d8a  vmovaps [rsp+0x30], xmm3
000079035ddd9d90  vmovaps [rsp+0x40], xmm4
000079035ddd9d96  vmovaps [rsp+0x50], xmm5
000079035ddd9d9c  vmovaps [rsp+0x60], xmm6
000079035ddd9da2  vmovaps [rsp+0x70], xmm7
000079035ddd9da8  vmovaps [rsp+0x80], xmm8
000079035ddd9db1  vmovaps [rsp+0x90], xmm9
000079035ddd9dba  vmovaps [rsp+0xA0], xmm11
000079035ddd9dc3  vmovaps [rsp+0xB0], xmm12
000079035ddd9dcc  vmovaps [rsp+0xC0], xmm13
000079035ddd9dd5  vmovaps [rsp+0xD0], xmm14
000079035ddd9dde  vmovaps [rsp+0xE0], xmm15
000079035ddd9de7  sub rsp, 0x30
000079035ddd9deb  movaps [rsp], xmm10
000079035ddd9df0  movaps [rsp+0x10], xmm12
000079035ddd9df6  movaps [rsp+0x20], xmm11
000079035ddd9dfc  lea rdi, [rsp]
000079035ddd9e00  mov esi, 0x00
000079035ddd9e05  mov rax, 0x64ACAA8B0530
000079035ddd9e0f  call rax
000079035ddd9e11  movaps xmm10, [rsp]
000079035ddd9e16  add rsp, 0x30
000079035ddd9e1a  vmovaps xmm0, [rsp]
000079035ddd9e1f  vmovaps xmm1, [rsp+0x10]
000079035ddd9e25  vmovaps xmm2, [rsp+0x20]
000079035ddd9e2b  vmovaps xmm3, [rsp+0x30]
000079035ddd9e31  vmovaps xmm4, [rsp+0x40]
000079035ddd9e37  vmovaps xmm5, [rsp+0x50]
000079035ddd9e3d  vmovaps xmm6, [rsp+0x60]
000079035ddd9e43  vmovaps xmm7, [rsp+0x70]
000079035ddd9e49  vmovaps xmm8, [rsp+0x80]
000079035ddd9e52  vmovaps xmm9, [rsp+0x90]
000079035ddd9e5b  vmovaps xmm11, [rsp+0xA0]
000079035ddd9e64  vmovaps xmm12, [rsp+0xB0]
000079035ddd9e6d  vmovaps xmm13, [rsp+0xC0]
000079035ddd9e76  vmovaps xmm14, [rsp+0xD0]
000079035ddd9e7f  vmovaps xmm15, [rsp+0xE0]
000079035ddd9e88  add rsp, 0xF0
000079035ddd9e8f  pop r11
000079035ddd9e91  pop r10
000079035ddd9e93  pop r9
000079035ddd9e95  pop r8
000079035ddd9e97  pop rsi
000079035ddd9e98  pop rdi
000079035ddd9e99  pop rdx
000079035ddd9e9a  pop rcx
000079035ddd9e9b  pop rax
000079035ddd9e9c  add rsp, 0x08
000079035ddd9ea0  jmp 0x000079035DDD8BE6
000079035ddd9ea5  sub rsp, 0x08
000079035ddd9ea9  push rax
000079035ddd9eaa  push rcx
000079035ddd9eab  push rdx
000079035ddd9eac  push rdi
000079035ddd9ead  push rsi
000079035ddd9eae  push r8
000079035ddd9eb0  push r9
000079035ddd9eb2  push r10
000079035ddd9eb4  push r11
000079035ddd9eb6  sub rsp, 0xF0
000079035ddd9ebd  vmovaps [rsp], xmm0
000079035ddd9ec2  vmovaps [rsp+0x10], xmm1
000079035ddd9ec8  vmovaps [rsp+0x20], xmm2
000079035ddd9ece  vmovaps [rsp+0x30], xmm3
000079035ddd9ed4  vmovaps [rsp+0x40], xmm4
000079035ddd9eda  vmovaps [rsp+0x50], xmm5
000079035ddd9ee0  vmovaps [rsp+0x60], xmm7
000079035ddd9ee6  vmovaps [rsp+0x70], xmm8
000079035ddd9eec  vmovaps [rsp+0x80], xmm9
000079035ddd9ef5  vmovaps [rsp+0x90], xmm10
000079035ddd9efe  vmovaps [rsp+0xA0], xmm11
000079035ddd9f07  vmovaps [rsp+0xB0], xmm12
000079035ddd9f10  vmovaps [rsp+0xC0], xmm13
000079035ddd9f19  vmovaps [rsp+0xD0], xmm14
000079035ddd9f22  vmovaps [rsp+0xE0], xmm15
000079035ddd9f2b  sub rsp, 0x30
000079035ddd9f2f  movaps [rsp], xmm6
000079035ddd9f33  movaps [rsp+0x10], xmm12
000079035ddd9f39  movaps [rsp+0x20], xmm11
000079035ddd9f3f  lea rdi, [rsp]
000079035ddd9f43  mov esi, 0x00
000079035ddd9f48  mov rax, 0x64ACAA8B0530
000079035ddd9f52  call rax
000079035ddd9f54  movaps xmm6, [rsp]
000079035ddd9f58  add rsp, 0x30
000079035ddd9f5c  vmovaps xmm0, [rsp]
000079035ddd9f61  vmovaps xmm1, [rsp+0x10]
000079035ddd9f67  vmovaps xmm2, [rsp+0x20]
000079035ddd9f6d  vmovaps xmm3, [rsp+0x30]
000079035ddd9f73  vmovaps xmm4, [rsp+0x40]
000079035ddd9f79  vmovaps xmm5, [rsp+0x50]
000079035ddd9f7f  vmovaps xmm7, [rsp+0x60]
000079035ddd9f85  vmovaps xmm8, [rsp+0x70]
000079035ddd9f8b  vmovaps xmm9, [rsp+0x80]
000079035ddd9f94  vmovaps xmm10, [rsp+0x90]
000079035ddd9f9d  vmovaps xmm11, [rsp+0xA0]
000079035ddd9fa6  vmovaps xmm12, [rsp+0xB0]
000079035ddd9faf  vmovaps xmm13, [rsp+0xC0]
000079035ddd9fb8  vmovaps xmm14, [rsp+0xD0]
000079035ddd9fc1  vmovaps xmm15, [rsp+0xE0]
000079035ddd9fca  add rsp, 0xF0
000079035ddd9fd1  pop r11
000079035ddd9fd3  pop r10
000079035ddd9fd5  pop r9
000079035ddd9fd7  pop r8
000079035ddd9fd9  pop rsi
000079035ddd9fda  pop rdi
000079035ddd9fdb  pop rdx
000079035ddd9fdc  pop rcx
000079035ddd9fdd  pop rax
000079035ddd9fde  add rsp, 0x08
000079035ddd9fe2  jmp 0x000079035DDD8C07
000079035ddd9fe7  sub rsp, 0x08
000079035ddd9feb  push rax
000079035ddd9fec  push rcx
000079035ddd9fed  push rdx
000079035ddd9fee  push rdi
000079035ddd9fef  push rsi
000079035ddd9ff0  push r8
000079035ddd9ff2  push r9
000079035ddd9ff4  push r10
000079035ddd9ff6  push r11
000079035ddd9ff8  sub rsp, 0xF0
000079035ddd9fff  vmovaps [rsp], xmm0
000079035ddda004  vmovaps [rsp+0x10], xmm1
000079035ddda00a  vmovaps [rsp+0x20], xmm2
000079035ddda010  vmovaps [rsp+0x30], xmm4
000079035ddda016  vmovaps [rsp+0x40], xmm5
000079035ddda01c  vmovaps [rsp+0x50], xmm6
000079035ddda022  vmovaps [rsp+0x60], xmm7
000079035ddda028  vmovaps [rsp+0x70], xmm8
000079035ddda02e  vmovaps [rsp+0x80], xmm9
000079035ddda037  vmovaps [rsp+0x90], xmm10
000079035ddda040  vmovaps [rsp+0xA0], xmm11
000079035ddda049  vmovaps [rsp+0xB0], xmm12
000079035ddda052  vmovaps [rsp+0xC0], xmm13
000079035ddda05b  vmovaps [rsp+0xD0], xmm14
000079035ddda064  vmovaps [rsp+0xE0], xmm15
000079035ddda06d  sub rsp, 0x30
000079035ddda071  movaps [rsp], xmm3
000079035ddda075  movaps [rsp+0x10], xmm5
000079035ddda07a  movaps [rsp+0x20], xmm4
000079035ddda07f  lea rdi, [rsp]
000079035ddda083  mov esi, 0x00
000079035ddda088  mov rax, 0x64ACAA8B0530
000079035ddda092  call rax
000079035ddda094  movaps xmm3, [rsp]
000079035ddda098  add rsp, 0x30
000079035ddda09c  vmovaps xmm0, [rsp]
000079035ddda0a1  vmovaps xmm1, [rsp+0x10]
000079035ddda0a7  vmovaps xmm2, [rsp+0x20]
000079035ddda0ad  vmovaps xmm4, [rsp+0x30]
000079035ddda0b3  vmovaps xmm5, [rsp+0x40]
000079035ddda0b9  vmovaps xmm6, [rsp+0x50]
000079035ddda0bf  vmovaps xmm7, [rsp+0x60]
000079035ddda0c5  vmovaps xmm8, [rsp+0x70]
000079035ddda0cb  vmovaps xmm9, [rsp+0x80]
000079035ddda0d4  vmovaps xmm10, [rsp+0x90]
000079035ddda0dd  vmovaps xmm11, [rsp+0xA0]
000079035ddda0e6  vmovaps xmm12, [rsp+0xB0]
000079035ddda0ef  vmovaps xmm13, [rsp+0xC0]
000079035ddda0f8  vmovaps xmm14, [rsp+0xD0]
000079035ddda101  vmovaps xmm15, [rsp+0xE0]
000079035ddda10a  add rsp, 0xF0
000079035ddda111  pop r11
000079035ddda113  pop r10
000079035ddda115  pop r9
000079035ddda117  pop r8
000079035ddda119  pop rsi
000079035ddda11a  pop rdi
000079035ddda11b  pop rdx
000079035ddda11c  pop rcx
000079035ddda11d  pop rax
000079035ddda11e  add rsp, 0x08
000079035ddda122  jmp 0x000079035DDD8C68
000079035ddda127  sub rsp, 0x08
000079035ddda12b  push rax
000079035ddda12c  push rcx
000079035ddda12d  push rdx
000079035ddda12e  push rdi
000079035ddda12f  push rsi
000079035ddda130  push r8
000079035ddda132  push r9
000079035ddda134  push r10
000079035ddda136  push r11
000079035ddda138  sub rsp, 0xF0
000079035ddda13f  vmovaps [rsp], xmm0
000079035ddda144  vmovaps [rsp+0x10], xmm1
000079035ddda14a  vmovaps [rsp+0x20], xmm2
000079035ddda150  vmovaps [rsp+0x30], xmm3
000079035ddda156  vmovaps [rsp+0x40], xmm4
000079035ddda15c  vmovaps [rsp+0x50], xmm6
000079035ddda162  vmovaps [rsp+0x60], xmm7
000079035ddda168  vmovaps [rsp+0x70], xmm8
000079035ddda16e  vmovaps [rsp+0x80], xmm9
000079035ddda177  vmovaps [rsp+0x90], xmm10
000079035ddda180  vmovaps [rsp+0xA0], xmm11
000079035ddda189  vmovaps [rsp+0xB0], xmm12
000079035ddda192  vmovaps [rsp+0xC0], xmm13
000079035ddda19b  vmovaps [rsp+0xD0], xmm14
000079035ddda1a4  vmovaps [rsp+0xE0], xmm15
000079035ddda1ad  sub rsp, 0x30
000079035ddda1b1  movaps [rsp], xmm5
000079035ddda1b5  movaps [rsp+0x10], xmm8
000079035ddda1bb  movaps [rsp+0x20], xmm15
000079035ddda1c1  lea rdi, [rsp]
000079035ddda1c5  mov esi, 0x00
000079035ddda1ca  mov rax, 0x64ACAA8B0530
000079035ddda1d4  call rax
000079035ddda1d6  movaps xmm5, [rsp]
000079035ddda1da  add rsp, 0x30
000079035ddda1de  vmovaps xmm0, [rsp]
000079035ddda1e3  vmovaps xmm1, [rsp+0x10]
000079035ddda1e9  vmovaps xmm2, [rsp+0x20]
000079035ddda1ef  vmovaps xmm3, [rsp+0x30]
000079035ddda1f5  vmovaps xmm4, [rsp+0x40]
000079035ddda1fb  vmovaps xmm6, [rsp+0x50]
000079035ddda201  vmovaps xmm7, [rsp+0x60]
000079035ddda207  vmovaps xmm8, [rsp+0x70]
000079035ddda20d  vmovaps xmm9, [rsp+0x80]
000079035ddda216  vmovaps xmm10, [rsp+0x90]
000079035ddda21f  vmovaps xmm11, [rsp+0xA0]
000079035ddda228  vmovaps xmm12, [rsp+0xB0]
000079035ddda231  vmovaps xmm13, [rsp+0xC0]
000079035ddda23a  vmovaps xmm14, [rsp+0xD0]
000079035ddda243  vmovaps xmm15, [rsp+0xE0]
000079035ddda24c  add rsp, 0xF0
000079035ddda253  pop r11
000079035ddda255  pop r10
000079035ddda257  pop r9
000079035ddda259  pop r8
000079035ddda25b  pop rsi
000079035ddda25c  pop rdi
000079035ddda25d  pop rdx
000079035ddda25e  pop rcx
000079035ddda25f  pop rax
000079035ddda260  add rsp, 0x08
000079035ddda264  jmp 0x000079035DDD8CA0
000079035ddda269  sub rsp, 0x08
000079035ddda26d  push rax
000079035ddda26e  push rcx
000079035ddda26f  push rdx
000079035ddda270  push rdi
000079035ddda271  push rsi
000079035ddda272  push r8
000079035ddda274  push r9
000079035ddda276  push r10
000079035ddda278  push r11
000079035ddda27a  sub rsp, 0xF0
000079035ddda281  vmovaps [rsp], xmm0
000079035ddda286  vmovaps [rsp+0x10], xmm1
000079035ddda28c  vmovaps [rsp+0x20], xmm2
000079035ddda292  vmovaps [rsp+0x30], xmm3
000079035ddda298  vmovaps [rsp+0x40], xmm5
000079035ddda29e  vmovaps [rsp+0x50], xmm6
000079035ddda2a4  vmovaps [rsp+0x60], xmm7
000079035ddda2aa  vmovaps [rsp+0x70], xmm8
000079035ddda2b0  vmovaps [rsp+0x80], xmm9
000079035ddda2b9  vmovaps [rsp+0x90], xmm10
000079035ddda2c2  vmovaps [rsp+0xA0], xmm11
000079035ddda2cb  vmovaps [rsp+0xB0], xmm12
000079035ddda2d4  vmovaps [rsp+0xC0], xmm13
000079035ddda2dd  vmovaps [rsp+0xD0], xmm14
000079035ddda2e6  vmovaps [rsp+0xE0], xmm15
000079035ddda2ef  sub rsp, 0x30
000079035ddda2f3  movaps [rsp], xmm4
000079035ddda2f7  movaps [rsp+0x10], xmm9
000079035ddda2fd  movaps [rsp+0x20], xmm8
000079035ddda303  lea rdi, [rsp]
000079035ddda307  mov esi, 0x00
000079035ddda30c  mov rax, 0x64ACAA8B0530
000079035ddda316  call rax
000079035ddda318  movaps xmm4, [rsp]
000079035ddda31c  add rsp, 0x30
000079035ddda320  vmovaps xmm0, [rsp]
000079035ddda325  vmovaps xmm1, [rsp+0x10]
000079035ddda32b  vmovaps xmm2, [rsp+0x20]
000079035ddda331  vmovaps xmm3, [rsp+0x30]
000079035ddda337  vmovaps xmm5, [rsp+0x40]
000079035ddda33d  vmovaps xmm6, [rsp+0x50]
000079035ddda343  vmovaps xmm7, [rsp+0x60]
000079035ddda349  vmovaps xmm8, [rsp+0x70]
000079035ddda34f  vmovaps xmm9, [rsp+0x80]
000079035ddda358  vmovaps xmm10, [rsp+0x90]
000079035ddda361  vmovaps xmm11, [rsp+0xA0]
000079035ddda36a  vmovaps xmm12, [rsp+0xB0]
000079035ddda373  vmovaps xmm13, [rsp+0xC0]
000079035ddda37c  vmovaps xmm14, [rsp+0xD0]
000079035ddda385  vmovaps xmm15, [rsp+0xE0]
000079035ddda38e  add rsp, 0xF0
000079035ddda395  pop r11
000079035ddda397  pop r10
000079035ddda399  pop r9
000079035ddda39b  pop r8
000079035ddda39d  pop rsi
000079035ddda39e  pop rdi
000079035ddda39f  pop rdx
000079035ddda3a0  pop rcx
000079035ddda3a1  pop rax
000079035ddda3a2  add rsp, 0x08
000079035ddda3a6  jmp 0x000079035DDD8CC1
000079035ddda3ab  sub rsp, 0x08
000079035ddda3af  push rax
000079035ddda3b0  push rcx
000079035ddda3b1  push rdx
000079035ddda3b2  push rdi
000079035ddda3b3  push rsi
000079035ddda3b4  push r8
000079035ddda3b6  push r9
000079035ddda3b8  push r10
000079035ddda3ba  push r11
000079035ddda3bc  sub rsp, 0xF0
000079035ddda3c3  vmovaps [rsp], xmm0
000079035ddda3c8  vmovaps [rsp+0x10], xmm1
000079035ddda3ce  vmovaps [rsp+0x20], xmm2
000079035ddda3d4  vmovaps [rsp+0x30], xmm3
000079035ddda3da  vmovaps [rsp+0x40], xmm4
000079035ddda3e0  vmovaps [rsp+0x50], xmm5
000079035ddda3e6  vmovaps [rsp+0x60], xmm6
000079035ddda3ec  vmovaps [rsp+0x70], xmm7
000079035ddda3f2  vmovaps [rsp+0x80], xmm8
000079035ddda3fb  vmovaps [rsp+0x90], xmm10
000079035ddda404  vmovaps [rsp+0xA0], xmm11
000079035ddda40d  vmovaps [rsp+0xB0], xmm12
000079035ddda416  vmovaps [rsp+0xC0], xmm13
000079035ddda41f  vmovaps [rsp+0xD0], xmm14
000079035ddda428  vmovaps [rsp+0xE0], xmm15
000079035ddda431  sub rsp, 0x30
000079035ddda435  movaps [rsp], xmm9
000079035ddda43a  movaps [rsp+0x10], xmm10
000079035ddda440  movaps [rsp+0x20], xmm8
000079035ddda446  lea rdi, [rsp]
000079035ddda44a  mov esi, 0x00
000079035ddda44f  mov rax, 0x64ACAA8B0530
000079035ddda459  call rax
000079035ddda45b  movaps xmm9, [rsp]
000079035ddda460  add rsp, 0x30
000079035ddda464  vmovaps xmm0, [rsp]
000079035ddda469  vmovaps xmm1, [rsp+0x10]
000079035ddda46f  vmovaps xmm2, [rsp+0x20]
000079035ddda475  vmovaps xmm3, [rsp+0x30]
000079035ddda47b  vmovaps xmm4, [rsp+0x40]
000079035ddda481  vmovaps xmm5, [rsp+0x50]
000079035ddda487  vmovaps xmm6, [rsp+0x60]
000079035ddda48d  vmovaps xmm7, [rsp+0x70]
000079035ddda493  vmovaps xmm8, [rsp+0x80]
000079035ddda49c  vmovaps xmm10, [rsp+0x90]
000079035ddda4a5  vmovaps xmm11, [rsp+0xA0]
000079035ddda4ae  vmovaps xmm12, [rsp+0xB0]
000079035ddda4b7  vmovaps xmm13, [rsp+0xC0]
000079035ddda4c0  vmovaps xmm14, [rsp+0xD0]
000079035ddda4c9  vmovaps xmm15, [rsp+0xE0]
000079035ddda4d2  add rsp, 0xF0
000079035ddda4d9  pop r11
000079035ddda4db  pop r10
000079035ddda4dd  pop r9
000079035ddda4df  pop r8
000079035ddda4e1  pop rsi
000079035ddda4e2  pop rdi
000079035ddda4e3  pop rdx
000079035ddda4e4  pop rcx
000079035ddda4e5  pop rax
000079035ddda4e6  add rsp, 0x08
000079035ddda4ea  jmp 0x000079035DDD8CDB
000079035ddda4ef  call 0x000079035DCD64F0
000079035ddda4f4  jmp 0x000079035DDD8DF5
000079035ddda4f9  call 0x000079035DCD64F0
000079035ddda4fe  jmp 0x000079035DDD8E0B
000079035ddda503  sub rsp, 0x08
000079035ddda507  push rax
000079035ddda508  push rcx
000079035ddda509  push rdx
000079035ddda50a  push rdi
000079035ddda50b  push rsi
000079035ddda50c  push r8
000079035ddda50e  push r9
000079035ddda510  push r10
000079035ddda512  push r11
000079035ddda514  sub rsp, 0xF0
000079035ddda51b  vmovaps [rsp], xmm0
000079035ddda520  vmovaps [rsp+0x10], xmm2
000079035ddda526  vmovaps [rsp+0x20], xmm3
000079035ddda52c  vmovaps [rsp+0x30], xmm4
000079035ddda532  vmovaps [rsp+0x40], xmm5
000079035ddda538  vmovaps [rsp+0x50], xmm6
000079035ddda53e  vmovaps [rsp+0x60], xmm7
000079035ddda544  vmovaps [rsp+0x70], xmm8
000079035ddda54a  vmovaps [rsp+0x80], xmm9
000079035ddda553  vmovaps [rsp+0x90], xmm10
000079035ddda55c  vmovaps [rsp+0xA0], xmm11
000079035ddda565  vmovaps [rsp+0xB0], xmm12
000079035ddda56e  vmovaps [rsp+0xC0], xmm13
000079035ddda577  vmovaps [rsp+0xD0], xmm14
000079035ddda580  vmovaps [rsp+0xE0], xmm15
000079035ddda589  sub rsp, 0x30
000079035ddda58d  movaps [rsp], xmm1
000079035ddda591  movaps [rsp+0x10], xmm6
000079035ddda596  movaps [rsp+0x20], xmm15
000079035ddda59c  lea rdi, [rsp]
000079035ddda5a0  mov esi, 0x00
000079035ddda5a5  mov rax, 0x64ACAA8B0530
000079035ddda5af  call rax
000079035ddda5b1  movaps xmm1, [rsp]
000079035ddda5b5  add rsp, 0x30
000079035ddda5b9  vmovaps xmm0, [rsp]
000079035ddda5be  vmovaps xmm2, [rsp+0x10]
000079035ddda5c4  vmovaps xmm3, [rsp+0x20]
000079035ddda5ca  vmovaps xmm4, [rsp+0x30]
000079035ddda5d0  vmovaps xmm5, [rsp+0x40]
000079035ddda5d6  vmovaps xmm6, [rsp+0x50]
000079035ddda5dc  vmovaps xmm7, [rsp+0x60]
000079035ddda5e2  vmovaps xmm8, [rsp+0x70]
000079035ddda5e8  vmovaps xmm9, [rsp+0x80]
000079035ddda5f1  vmovaps xmm10, [rsp+0x90]
000079035ddda5fa  vmovaps xmm11, [rsp+0xA0]
000079035ddda603  vmovaps xmm12, [rsp+0xB0]
000079035ddda60c  vmovaps xmm13, [rsp+0xC0]
000079035ddda615  vmovaps xmm14, [rsp+0xD0]
000079035ddda61e  vmovaps xmm15, [rsp+0xE0]
000079035ddda627  add rsp, 0xF0
000079035ddda62e  pop r11
000079035ddda630  pop r10
000079035ddda632  pop r9
000079035ddda634  pop r8
000079035ddda636  pop rsi
000079035ddda637  pop rdi
000079035ddda638  pop rdx
000079035ddda639  pop rcx
000079035ddda63a  pop rax
000079035ddda63b  add rsp, 0x08
000079035ddda63f  jmp 0x000079035DDD8E48
000079035ddda644  call 0x000079035DCE5820
000079035ddda649  jmp 0x000079035DDD8E55
000079035ddda64e  sub rsp, 0x08
000079035ddda652  push rax
000079035ddda653  push rcx
000079035ddda654  push rdx
000079035ddda655  push rdi
000079035ddda656  push rsi
000079035ddda657  push r8
000079035ddda659  push r9
000079035ddda65b  push r10
000079035ddda65d  push r11
000079035ddda65f  sub rsp, 0xF0
000079035ddda666  vmovaps [rsp], xmm0
000079035ddda66b  vmovaps [rsp+0x10], xmm1
000079035ddda671  vmovaps [rsp+0x20], xmm2
000079035ddda677  vmovaps [rsp+0x30], xmm3
000079035ddda67d  vmovaps [rsp+0x40], xmm4
000079035ddda683  vmovaps [rsp+0x50], xmm5
000079035ddda689  vmovaps [rsp+0x60], xmm6
000079035ddda68f  vmovaps [rsp+0x70], xmm7
000079035ddda695  vmovaps [rsp+0x80], xmm8
000079035ddda69e  vmovaps [rsp+0x90], xmm9
000079035ddda6a7  vmovaps [rsp+0xA0], xmm10
000079035ddda6b0  vmovaps [rsp+0xB0], xmm11
000079035ddda6b9  vmovaps [rsp+0xC0], xmm12
000079035ddda6c2  vmovaps [rsp+0xD0], xmm13
000079035ddda6cb  vmovaps [rsp+0xE0], xmm15
000079035ddda6d4  sub rsp, 0x30
000079035ddda6d8  movaps [rsp], xmm14
000079035ddda6dd  movaps [rsp+0x10], xmm4
000079035ddda6e2  movaps [rsp+0x20], xmm3
000079035ddda6e7  lea rdi, [rsp]
000079035ddda6eb  mov esi, 0x00
000079035ddda6f0  mov rax, 0x64ACAA8B0530
000079035ddda6fa  call rax
000079035ddda6fc  movaps xmm14, [rsp]
000079035ddda701  add rsp, 0x30
000079035ddda705  vmovaps xmm0, [rsp]
000079035ddda70a  vmovaps xmm1, [rsp+0x10]
000079035ddda710  vmovaps xmm2, [rsp+0x20]
000079035ddda716  vmovaps xmm3, [rsp+0x30]
000079035ddda71c  vmovaps xmm4, [rsp+0x40]
000079035ddda722  vmovaps xmm5, [rsp+0x50]
000079035ddda728  vmovaps xmm6, [rsp+0x60]
000079035ddda72e  vmovaps xmm7, [rsp+0x70]
000079035ddda734  vmovaps xmm8, [rsp+0x80]
000079035ddda73d  vmovaps xmm9, [rsp+0x90]
000079035ddda746  vmovaps xmm10, [rsp+0xA0]
000079035ddda74f  vmovaps xmm11, [rsp+0xB0]
000079035ddda758  vmovaps xmm12, [rsp+0xC0]
000079035ddda761  vmovaps xmm13, [rsp+0xD0]
000079035ddda76a  vmovaps xmm15, [rsp+0xE0]
000079035ddda773  add rsp, 0xF0
000079035ddda77a  pop r11
000079035ddda77c  pop r10
000079035ddda77e  pop r9
000079035ddda780  pop r8
000079035ddda782  pop rsi
000079035ddda783  pop rdi
000079035ddda784  pop rdx
000079035ddda785  pop rcx
000079035ddda786  pop rax
000079035ddda787  add rsp, 0x08
000079035ddda78b  jmp 0x000079035DDD8E6F
000079035ddda790  sub rsp, 0x08
000079035ddda794  push rax
000079035ddda795  push rcx
000079035ddda796  push rdx
000079035ddda797  push rdi
000079035ddda798  push rsi
000079035ddda799  push r8
000079035ddda79b  push r9
000079035ddda79d  push r10
000079035ddda79f  push r11
000079035ddda7a1  sub rsp, 0xF0
000079035ddda7a8  vmovaps [rsp], xmm0
000079035ddda7ad  vmovaps [rsp+0x10], xmm1
000079035ddda7b3  vmovaps [rsp+0x20], xmm2
000079035ddda7b9  vmovaps [rsp+0x30], xmm3
000079035ddda7bf  vmovaps [rsp+0x40], xmm4
000079035ddda7c5  vmovaps [rsp+0x50], xmm5
000079035ddda7cb  vmovaps [rsp+0x60], xmm7
000079035ddda7d1  vmovaps [rsp+0x70], xmm8
000079035ddda7d7  vmovaps [rsp+0x80], xmm9
000079035ddda7e0  vmovaps [rsp+0x90], xmm10
000079035ddda7e9  vmovaps [rsp+0xA0], xmm11
000079035ddda7f2  vmovaps [rsp+0xB0], xmm12
000079035ddda7fb  vmovaps [rsp+0xC0], xmm13
000079035ddda804  vmovaps [rsp+0xD0], xmm14
000079035ddda80d  vmovaps [rsp+0xE0], xmm15
000079035ddda816  sub rsp, 0x30
000079035ddda81a  movaps [rsp], xmm6
000079035ddda81e  movaps [rsp+0x10], xmm9
000079035ddda824  movaps [rsp+0x20], xmm7
000079035ddda829  lea rdi, [rsp]
000079035ddda82d  mov esi, 0x00
000079035ddda832  mov rax, 0x64ACAA8B0530
000079035ddda83c  call rax
000079035ddda83e  movaps xmm6, [rsp]
000079035ddda842  add rsp, 0x30
000079035ddda846  vmovaps xmm0, [rsp]
000079035ddda84b  vmovaps xmm1, [rsp+0x10]
000079035ddda851  vmovaps xmm2, [rsp+0x20]
000079035ddda857  vmovaps xmm3, [rsp+0x30]
000079035ddda85d  vmovaps xmm4, [rsp+0x40]
000079035ddda863  vmovaps xmm5, [rsp+0x50]
000079035ddda869  vmovaps xmm7, [rsp+0x60]
000079035ddda86f  vmovaps xmm8, [rsp+0x70]
000079035ddda875  vmovaps xmm9, [rsp+0x80]
000079035ddda87e  vmovaps xmm10, [rsp+0x90]
000079035ddda887  vmovaps xmm11, [rsp+0xA0]
000079035ddda890  vmovaps xmm12, [rsp+0xB0]
000079035ddda899  vmovaps xmm13, [rsp+0xC0]
000079035ddda8a2  vmovaps xmm14, [rsp+0xD0]
000079035ddda8ab  vmovaps xmm15, [rsp+0xE0]
000079035ddda8b4  add rsp, 0xF0
000079035ddda8bb  pop r11
000079035ddda8bd  pop r10
000079035ddda8bf  pop r9
000079035ddda8c1  pop r8
000079035ddda8c3  pop rsi
000079035ddda8c4  pop rdi
000079035ddda8c5  pop rdx
000079035ddda8c6  pop rcx
000079035ddda8c7  pop rax
000079035ddda8c8  add rsp, 0x08
000079035ddda8cc  jmp 0x000079035DDD8E87
000079035ddda8d1  sub rsp, 0x08
000079035ddda8d5  push rax
000079035ddda8d6  push rcx
000079035ddda8d7  push rdx
000079035ddda8d8  push rdi
000079035ddda8d9  push rsi
000079035ddda8da  push r8
000079035ddda8dc  push r9
000079035ddda8de  push r10
000079035ddda8e0  push r11
000079035ddda8e2  sub rsp, 0xF0
000079035ddda8e9  vmovaps [rsp], xmm0
000079035ddda8ee  vmovaps [rsp+0x10], xmm1
000079035ddda8f4  vmovaps [rsp+0x20], xmm2
000079035ddda8fa  vmovaps [rsp+0x30], xmm3
000079035ddda900  vmovaps [rsp+0x40], xmm4
000079035ddda906  vmovaps [rsp+0x50], xmm5
000079035ddda90c  vmovaps [rsp+0x60], xmm6
000079035ddda912  vmovaps [rsp+0x70], xmm8
000079035ddda918  vmovaps [rsp+0x80], xmm9
000079035ddda921  vmovaps [rsp+0x90], xmm10
000079035ddda92a  vmovaps [rsp+0xA0], xmm11
000079035ddda933  vmovaps [rsp+0xB0], xmm12
000079035ddda93c  vmovaps [rsp+0xC0], xmm13
000079035ddda945  vmovaps [rsp+0xD0], xmm14
000079035ddda94e  vmovaps [rsp+0xE0], xmm15
000079035ddda957  sub rsp, 0x30
000079035ddda95b  movaps [rsp], xmm7
000079035ddda95f  movaps [rsp+0x10], xmm4
000079035ddda964  movaps [rsp+0x20], xmm9
000079035ddda96a  lea rdi, [rsp]
000079035ddda96e  mov esi, 0x00
000079035ddda973  mov rax, 0x64ACAA8B0530
000079035ddda97d  call rax
000079035ddda97f  movaps xmm7, [rsp]
000079035ddda983  add rsp, 0x30
000079035ddda987  vmovaps xmm0, [rsp]
000079035ddda98c  vmovaps xmm1, [rsp+0x10]
000079035ddda992  vmovaps xmm2, [rsp+0x20]
000079035ddda998  vmovaps xmm3, [rsp+0x30]
000079035ddda99e  vmovaps xmm4, [rsp+0x40]
000079035ddda9a4  vmovaps xmm5, [rsp+0x50]
000079035ddda9aa  vmovaps xmm6, [rsp+0x60]
000079035ddda9b0  vmovaps xmm8, [rsp+0x70]
000079035ddda9b6  vmovaps xmm9, [rsp+0x80]
000079035ddda9bf  vmovaps xmm10, [rsp+0x90]
000079035ddda9c8  vmovaps xmm11, [rsp+0xA0]
000079035ddda9d1  vmovaps xmm12, [rsp+0xB0]
000079035ddda9da  vmovaps xmm13, [rsp+0xC0]
000079035ddda9e3  vmovaps xmm14, [rsp+0xD0]
000079035ddda9ec  vmovaps xmm15, [rsp+0xE0]
000079035ddda9f5  add rsp, 0xF0
000079035ddda9fc  pop r11
000079035ddda9fe  pop r10
000079035dddaa00  pop r9
000079035dddaa02  pop r8
000079035dddaa04  pop rsi
000079035dddaa05  pop rdi
000079035dddaa06  pop rdx
000079035dddaa07  pop rcx
000079035dddaa08  pop rax
000079035dddaa09  add rsp, 0x08
000079035dddaa0d  jmp 0x000079035DDD8EB4
000079035dddaa12  sub rsp, 0x08
000079035dddaa16  push rax
000079035dddaa17  push rcx
000079035dddaa18  push rdx
000079035dddaa19  push rdi
000079035dddaa1a  push rsi
000079035dddaa1b  push r8
000079035dddaa1d  push r9
000079035dddaa1f  push r10
000079035dddaa21  push r11
000079035dddaa23  sub rsp, 0xF0
000079035dddaa2a  vmovaps [rsp], xmm0
000079035dddaa2f  vmovaps [rsp+0x10], xmm1
000079035dddaa35  vmovaps [rsp+0x20], xmm2
000079035dddaa3b  vmovaps [rsp+0x30], xmm3
000079035dddaa41  vmovaps [rsp+0x40], xmm5
000079035dddaa47  vmovaps [rsp+0x50], xmm6
000079035dddaa4d  vmovaps [rsp+0x60], xmm7
000079035dddaa53  vmovaps [rsp+0x70], xmm8
000079035dddaa59  vmovaps [rsp+0x80], xmm9
000079035dddaa62  vmovaps [rsp+0x90], xmm10
000079035dddaa6b  vmovaps [rsp+0xA0], xmm11
000079035dddaa74  vmovaps [rsp+0xB0], xmm12
000079035dddaa7d  vmovaps [rsp+0xC0], xmm13
000079035dddaa86  vmovaps [rsp+0xD0], xmm14
000079035dddaa8f  vmovaps [rsp+0xE0], xmm15
000079035dddaa98  sub rsp, 0x30
000079035dddaa9c  movaps [rsp], xmm4
000079035dddaaa0  movaps [rsp+0x10], xmm15
000079035dddaaa6  movaps [rsp+0x20], xmm9
000079035dddaaac  lea rdi, [rsp]
000079035dddaab0  mov esi, 0x00
000079035dddaab5  mov rax, 0x64ACAA8B0530
000079035dddaabf  call rax
000079035dddaac1  movaps xmm4, [rsp]
000079035dddaac5  add rsp, 0x30
000079035dddaac9  vmovaps xmm0, [rsp]
000079035dddaace  vmovaps xmm1, [rsp+0x10]
000079035dddaad4  vmovaps xmm2, [rsp+0x20]
000079035dddaada  vmovaps xmm3, [rsp+0x30]
000079035dddaae0  vmovaps xmm5, [rsp+0x40]
000079035dddaae6  vmovaps xmm6, [rsp+0x50]
000079035dddaaec  vmovaps xmm7, [rsp+0x60]
000079035dddaaf2  vmovaps xmm8, [rsp+0x70]
000079035dddaaf8  vmovaps xmm9, [rsp+0x80]
000079035dddab01  vmovaps xmm10, [rsp+0x90]
000079035dddab0a  vmovaps xmm11, [rsp+0xA0]
000079035dddab13  vmovaps xmm12, [rsp+0xB0]
000079035dddab1c  vmovaps xmm13, [rsp+0xC0]
000079035dddab25  vmovaps xmm14, [rsp+0xD0]
000079035dddab2e  vmovaps xmm15, [rsp+0xE0]
000079035dddab37  add rsp, 0xF0
000079035dddab3e  pop r11
000079035dddab40  pop r10
000079035dddab42  pop r9
000079035dddab44  pop r8
000079035dddab46  pop rsi
000079035dddab47  pop rdi
000079035dddab48  pop rdx
000079035dddab49  pop rcx
000079035dddab4a  pop rax
000079035dddab4b  add rsp, 0x08
000079035dddab4f  jmp 0x000079035DDD8ED9
000079035dddab54  call 0x000079035DCE5820
000079035dddab59  jmp 0x000079035DDD8EE6
000079035dddab5e  sub rsp, 0x08
000079035dddab62  push rax
000079035dddab63  push rcx
000079035dddab64  push rdx
000079035dddab65  push rdi
000079035dddab66  push rsi
000079035dddab67  push r8
000079035dddab69  push r9
000079035dddab6b  push r10
000079035dddab6d  push r11
000079035dddab6f  sub rsp, 0xF0
000079035dddab76  vmovaps [rsp], xmm0
000079035dddab7b  vmovaps [rsp+0x10], xmm1
000079035dddab81  vmovaps [rsp+0x20], xmm2
000079035dddab87  vmovaps [rsp+0x30], xmm4
000079035dddab8d  vmovaps [rsp+0x40], xmm5
000079035dddab93  vmovaps [rsp+0x50], xmm6
000079035dddab99  vmovaps [rsp+0x60], xmm7
000079035dddab9f  vmovaps [rsp+0x70], xmm8
000079035dddaba5  vmovaps [rsp+0x80], xmm9
000079035dddabae  vmovaps [rsp+0x90], xmm10
000079035dddabb7  vmovaps [rsp+0xA0], xmm11
000079035dddabc0  vmovaps [rsp+0xB0], xmm12
000079035dddabc9  vmovaps [rsp+0xC0], xmm13
000079035dddabd2  vmovaps [rsp+0xD0], xmm14
000079035dddabdb  vmovaps [rsp+0xE0], xmm15
000079035dddabe4  sub rsp, 0x30
000079035dddabe8  movaps [rsp], xmm3
000079035dddabec  movaps [rsp+0x10], xmm1
000079035dddabf1  movaps [rsp+0x20], xmm9
000079035dddabf7  lea rdi, [rsp]
000079035dddabfb  mov esi, 0x00
000079035dddac00  mov rax, 0x64ACAA8B0530
000079035dddac0a  call rax
000079035dddac0c  movaps xmm3, [rsp]
000079035dddac10  add rsp, 0x30
000079035dddac14  vmovaps xmm0, [rsp]
000079035dddac19  vmovaps xmm1, [rsp+0x10]
000079035dddac1f  vmovaps xmm2, [rsp+0x20]
000079035dddac25  vmovaps xmm4, [rsp+0x30]
000079035dddac2b  vmovaps xmm5, [rsp+0x40]
000079035dddac31  vmovaps xmm6, [rsp+0x50]
000079035dddac37  vmovaps xmm7, [rsp+0x60]
000079035dddac3d  vmovaps xmm8, [rsp+0x70]
000079035dddac43  vmovaps xmm9, [rsp+0x80]
000079035dddac4c  vmovaps xmm10, [rsp+0x90]
000079035dddac55  vmovaps xmm11, [rsp+0xA0]
000079035dddac5e  vmovaps xmm12, [rsp+0xB0]
000079035dddac67  vmovaps xmm13, [rsp+0xC0]
000079035dddac70  vmovaps xmm14, [rsp+0xD0]
000079035dddac79  vmovaps xmm15, [rsp+0xE0]
000079035dddac82  add rsp, 0xF0
000079035dddac89  pop r11
000079035dddac8b  pop r10
000079035dddac8d  pop r9
000079035dddac8f  pop r8
000079035dddac91  pop rsi
000079035dddac92  pop rdi
000079035dddac93  pop rdx
000079035dddac94  pop rcx
000079035dddac95  pop rax
000079035dddac96  add rsp, 0x08
000079035dddac9a  jmp 0x000079035DDD8F23
000079035dddac9f  sub rsp, 0x08
000079035dddaca3  push rax
000079035dddaca4  push rcx
000079035dddaca5  push rdx
000079035dddaca6  push rdi
000079035dddaca7  push rsi
000079035dddaca8  push r8
000079035dddacaa  push r9
000079035dddacac  push r10
000079035dddacae  push r11
000079035dddacb0  sub rsp, 0xF0
000079035dddacb7  vmovaps [rsp], xmm0
000079035dddacbc  vmovaps [rsp+0x10], xmm2
000079035dddacc2  vmovaps [rsp+0x20], xmm3
000079035dddacc8  vmovaps [rsp+0x30], xmm4
000079035dddacce  vmovaps [rsp+0x40], xmm5
000079035dddacd4  vmovaps [rsp+0x50], xmm6
000079035dddacda  vmovaps [rsp+0x60], xmm7
000079035dddace0  vmovaps [rsp+0x70], xmm8
000079035dddace6  vmovaps [rsp+0x80], xmm9
000079035dddacef  vmovaps [rsp+0x90], xmm10
000079035dddacf8  vmovaps [rsp+0xA0], xmm11
000079035dddad01  vmovaps [rsp+0xB0], xmm12
000079035dddad0a  vmovaps [rsp+0xC0], xmm13
000079035dddad13  vmovaps [rsp+0xD0], xmm14
000079035dddad1c  vmovaps [rsp+0xE0], xmm15
000079035dddad25  sub rsp, 0x30
000079035dddad29  movaps [rsp], xmm1
000079035dddad2d  movaps [rsp+0x10], xmm15
000079035dddad33  movaps [rsp+0x20], xmm9
000079035dddad39  lea rdi, [rsp]
000079035dddad3d  mov esi, 0x00
000079035dddad42  mov rax, 0x64ACAA8B0530
000079035dddad4c  call rax
000079035dddad4e  movaps xmm1, [rsp]
000079035dddad52  add rsp, 0x30
000079035dddad56  vmovaps xmm0, [rsp]
000079035dddad5b  vmovaps xmm2, [rsp+0x10]
000079035dddad61  vmovaps xmm3, [rsp+0x20]
000079035dddad67  vmovaps xmm4, [rsp+0x30]
000079035dddad6d  vmovaps xmm5, [rsp+0x40]
000079035dddad73  vmovaps xmm6, [rsp+0x50]
000079035dddad79  vmovaps xmm7, [rsp+0x60]
000079035dddad7f  vmovaps xmm8, [rsp+0x70]
000079035dddad85  vmovaps xmm9, [rsp+0x80]
000079035dddad8e  vmovaps xmm10, [rsp+0x90]
000079035dddad97  vmovaps xmm11, [rsp+0xA0]
000079035dddada0  vmovaps xmm12, [rsp+0xB0]
000079035dddada9  vmovaps xmm13, [rsp+0xC0]
000079035dddadb2  vmovaps xmm14, [rsp+0xD0]
000079035dddadbb  vmovaps xmm15, [rsp+0xE0]
000079035dddadc4  add rsp, 0xF0
000079035dddadcb  pop r11
000079035dddadcd  pop r10
000079035dddadcf  pop r9
000079035dddadd1  pop r8
000079035dddadd3  pop rsi
000079035dddadd4  pop rdi
000079035dddadd5  pop rdx
000079035dddadd6  pop rcx
000079035dddadd7  pop rax
000079035dddadd8  add rsp, 0x08
000079035dddaddc  jmp 0x000079035DDD8FAB
000079035dddade1  call 0x000079035DCE5820
000079035dddade6  jmp 0x000079035DDD8FB8
000079035dddadeb  sub rsp, 0x08
000079035dddadef  push rax
000079035dddadf0  push rcx
000079035dddadf1  push rdx
000079035dddadf2  push rdi
000079035dddadf3  push rsi
000079035dddadf4  push r8
000079035dddadf6  push r9
000079035dddadf8  push r10
000079035dddadfa  push r11
000079035dddadfc  sub rsp, 0xF0
000079035dddae03  vmovaps [rsp], xmm0
000079035dddae08  vmovaps [rsp+0x10], xmm2
000079035dddae0e  vmovaps [rsp+0x20], xmm3
000079035dddae14  vmovaps [rsp+0x30], xmm4
000079035dddae1a  vmovaps [rsp+0x40], xmm5
000079035dddae20  vmovaps [rsp+0x50], xmm6
000079035dddae26  vmovaps [rsp+0x60], xmm7
000079035dddae2c  vmovaps [rsp+0x70], xmm8
000079035dddae32  vmovaps [rsp+0x80], xmm9
000079035dddae3b  vmovaps [rsp+0x90], xmm10
000079035dddae44  vmovaps [rsp+0xA0], xmm11
000079035dddae4d  vmovaps [rsp+0xB0], xmm12
000079035dddae56  vmovaps [rsp+0xC0], xmm13
000079035dddae5f  vmovaps [rsp+0xD0], xmm14
000079035dddae68  vmovaps [rsp+0xE0], xmm15
000079035dddae71  sub rsp, 0x30
000079035dddae75  movaps [rsp], xmm1
000079035dddae79  movaps [rsp+0x10], xmm5
000079035dddae7e  movaps [rsp+0x20], xmm7
000079035dddae83  lea rdi, [rsp]
000079035dddae87  mov esi, 0x00
000079035dddae8c  mov rax, 0x64ACAA8B0530
000079035dddae96  call rax
000079035dddae98  movaps xmm1, [rsp]
000079035dddae9c  add rsp, 0x30
000079035dddaea0  vmovaps xmm0, [rsp]
000079035dddaea5  vmovaps xmm2, [rsp+0x10]
000079035dddaeab  vmovaps xmm3, [rsp+0x20]
000079035dddaeb1  vmovaps xmm4, [rsp+0x30]
000079035dddaeb7  vmovaps xmm5, [rsp+0x40]
000079035dddaebd  vmovaps xmm6, [rsp+0x50]
000079035dddaec3  vmovaps xmm7, [rsp+0x60]
000079035dddaec9  vmovaps xmm8, [rsp+0x70]
000079035dddaecf  vmovaps xmm9, [rsp+0x80]
000079035dddaed8  vmovaps xmm10, [rsp+0x90]
000079035dddaee1  vmovaps xmm11, [rsp+0xA0]
000079035dddaeea  vmovaps xmm12, [rsp+0xB0]
000079035dddaef3  vmovaps xmm13, [rsp+0xC0]
000079035dddaefc  vmovaps xmm14, [rsp+0xD0]
000079035dddaf05  vmovaps xmm15, [rsp+0xE0]
000079035dddaf0e  add rsp, 0xF0
000079035dddaf15  pop r11
000079035dddaf17  pop r10
000079035dddaf19  pop r9
000079035dddaf1b  pop r8
000079035dddaf1d  pop rsi
000079035dddaf1e  pop rdi
000079035dddaf1f  pop rdx
000079035dddaf20  pop rcx
000079035dddaf21  pop rax
000079035dddaf22  add rsp, 0x08
000079035dddaf26  jmp 0x000079035DDD905D
000079035dddaf2b  sub rsp, 0x08
000079035dddaf2f  push rax
000079035dddaf30  push rcx
000079035dddaf31  push rdx
000079035dddaf32  push rdi
000079035dddaf33  push rsi
000079035dddaf34  push r8
000079035dddaf36  push r9
000079035dddaf38  push r10
000079035dddaf3a  push r11
000079035dddaf3c  sub rsp, 0xF0
000079035dddaf43  vmovaps [rsp], xmm0
000079035dddaf48  vmovaps [rsp+0x10], xmm1
000079035dddaf4e  vmovaps [rsp+0x20], xmm2
000079035dddaf54  vmovaps [rsp+0x30], xmm3
000079035dddaf5a  vmovaps [rsp+0x40], xmm4
000079035dddaf60  vmovaps [rsp+0x50], xmm5
000079035dddaf66  vmovaps [rsp+0x60], xmm6
000079035dddaf6c  vmovaps [rsp+0x70], xmm8
000079035dddaf72  vmovaps [rsp+0x80], xmm9
000079035dddaf7b  vmovaps [rsp+0x90], xmm10
000079035dddaf84  vmovaps [rsp+0xA0], xmm11
000079035dddaf8d  vmovaps [rsp+0xB0], xmm12
000079035dddaf96  vmovaps [rsp+0xC0], xmm13
000079035dddaf9f  vmovaps [rsp+0xD0], xmm14
000079035dddafa8  vmovaps [rsp+0xE0], xmm15
000079035dddafb1  sub rsp, 0x30
000079035dddafb5  movaps [rsp], xmm7
000079035dddafb9  movaps [rsp+0x10], xmm5
000079035dddafbe  movaps [rsp+0x20], xmm15
000079035dddafc4  lea rdi, [rsp]
000079035dddafc8  mov esi, 0x00
000079035dddafcd  mov rax, 0x64ACAA8B0530
000079035dddafd7  call rax
000079035dddafd9  movaps xmm7, [rsp]
000079035dddafdd  add rsp, 0x30
000079035dddafe1  vmovaps xmm0, [rsp]
000079035dddafe6  vmovaps xmm1, [rsp+0x10]
000079035dddafec  vmovaps xmm2, [rsp+0x20]
000079035dddaff2  vmovaps xmm3, [rsp+0x30]
000079035dddaff8  vmovaps xmm4, [rsp+0x40]
000079035dddaffe  vmovaps xmm5, [rsp+0x50]
000079035dddb004  vmovaps xmm6, [rsp+0x60]
000079035dddb00a  vmovaps xmm8, [rsp+0x70]
000079035dddb010  vmovaps xmm9, [rsp+0x80]
000079035dddb019  vmovaps xmm10, [rsp+0x90]
000079035dddb022  vmovaps xmm11, [rsp+0xA0]
000079035dddb02b  vmovaps xmm12, [rsp+0xB0]
000079035dddb034  vmovaps xmm13, [rsp+0xC0]
000079035dddb03d  vmovaps xmm14, [rsp+0xD0]
000079035dddb046  vmovaps xmm15, [rsp+0xE0]
000079035dddb04f  add rsp, 0xF0
000079035dddb056  pop r11
000079035dddb058  pop r10
000079035dddb05a  pop r9
000079035dddb05c  pop r8
000079035dddb05e  pop rsi
000079035dddb05f  pop rdi
000079035dddb060  pop rdx
000079035dddb061  pop rcx
000079035dddb062  pop rax
000079035dddb063  add rsp, 0x08
000079035dddb067  jmp 0x000079035DDD9093
000079035dddb06c  call 0x000079035DCD64F0
000079035dddb071  jmp 0x000079035DDD90A0
000079035dddb076  sub rsp, 0x08
000079035dddb07a  push rax
000079035dddb07b  push rcx
000079035dddb07c  push rdx
000079035dddb07d  push rdi
000079035dddb07e  push rsi
000079035dddb07f  push r8
000079035dddb081  push r9
000079035dddb083  push r10
000079035dddb085  push r11
000079035dddb087  sub rsp, 0xF0
000079035dddb08e  vmovaps [rsp], xmm0
000079035dddb093  vmovaps [rsp+0x10], xmm1
000079035dddb099  vmovaps [rsp+0x20], xmm2
000079035dddb09f  vmovaps [rsp+0x30], xmm3
000079035dddb0a5  vmovaps [rsp+0x40], xmm4
000079035dddb0ab  vmovaps [rsp+0x50], xmm5
000079035dddb0b1  vmovaps [rsp+0x60], xmm6
000079035dddb0b7  vmovaps [rsp+0x70], xmm7
000079035dddb0bd  vmovaps [rsp+0x80], xmm8
000079035dddb0c6  vmovaps [rsp+0x90], xmm9
000079035dddb0cf  vmovaps [rsp+0xA0], xmm10
000079035dddb0d8  vmovaps [rsp+0xB0], xmm11
000079035dddb0e1  vmovaps [rsp+0xC0], xmm12
000079035dddb0ea  vmovaps [rsp+0xD0], xmm13
000079035dddb0f3  vmovaps [rsp+0xE0], xmm14
000079035dddb0fc  sub rsp, 0x30
000079035dddb100  movaps [rsp], xmm15
000079035dddb105  movaps [rsp+0x10], xmm5
000079035dddb10a  movaps [rsp+0x20], xmm3
000079035dddb10f  lea rdi, [rsp]
000079035dddb113  mov esi, 0x00
000079035dddb118  mov rax, 0x64ACAA8B0530
000079035dddb122  call rax
000079035dddb124  movaps xmm15, [rsp]
000079035dddb129  add rsp, 0x30
000079035dddb12d  vmovaps xmm0, [rsp]
000079035dddb132  vmovaps xmm1, [rsp+0x10]
000079035dddb138  vmovaps xmm2, [rsp+0x20]
000079035dddb13e  vmovaps xmm3, [rsp+0x30]
000079035dddb144  vmovaps xmm4, [rsp+0x40]
000079035dddb14a  vmovaps xmm5, [rsp+0x50]
000079035dddb150  vmovaps xmm6, [rsp+0x60]
000079035dddb156  vmovaps xmm7, [rsp+0x70]
000079035dddb15c  vmovaps xmm8, [rsp+0x80]
000079035dddb165  vmovaps xmm9, [rsp+0x90]
000079035dddb16e  vmovaps xmm10, [rsp+0xA0]
000079035dddb177  vmovaps xmm11, [rsp+0xB0]
000079035dddb180  vmovaps xmm12, [rsp+0xC0]
000079035dddb189  vmovaps xmm13, [rsp+0xD0]
000079035dddb192  vmovaps xmm14, [rsp+0xE0]
000079035dddb19b  add rsp, 0xF0
000079035dddb1a2  pop r11
000079035dddb1a4  pop r10
000079035dddb1a6  pop r9
000079035dddb1a8  pop r8
000079035dddb1aa  pop rsi
000079035dddb1ab  pop rdi
000079035dddb1ac  pop rdx
000079035dddb1ad  pop rcx
000079035dddb1ae  pop rax
000079035dddb1af  add rsp, 0x08
000079035dddb1b3  jmp 0x000079035DDD90C6
000079035dddb1b8  sub rsp, 0x08
000079035dddb1bc  push rax
000079035dddb1bd  push rcx
000079035dddb1be  push rdx
000079035dddb1bf  push rdi
000079035dddb1c0  push rsi
000079035dddb1c1  push r8
000079035dddb1c3  push r9
000079035dddb1c5  push r10
000079035dddb1c7  push r11
000079035dddb1c9  sub rsp, 0xF0
000079035dddb1d0  vmovaps [rsp], xmm0
000079035dddb1d5  vmovaps [rsp+0x10], xmm2
000079035dddb1db  vmovaps [rsp+0x20], xmm3
000079035dddb1e1  vmovaps [rsp+0x30], xmm4
000079035dddb1e7  vmovaps [rsp+0x40], xmm5
000079035dddb1ed  vmovaps [rsp+0x50], xmm6
000079035dddb1f3  vmovaps [rsp+0x60], xmm7
000079035dddb1f9  vmovaps [rsp+0x70], xmm8
000079035dddb1ff  vmovaps [rsp+0x80], xmm9
000079035dddb208  vmovaps [rsp+0x90], xmm10
000079035dddb211  vmovaps [rsp+0xA0], xmm11
000079035dddb21a  vmovaps [rsp+0xB0], xmm12
000079035dddb223  vmovaps [rsp+0xC0], xmm13
000079035dddb22c  vmovaps [rsp+0xD0], xmm14
000079035dddb235  vmovaps [rsp+0xE0], xmm15
000079035dddb23e  sub rsp, 0x30
000079035dddb242  movaps [rsp], xmm1
000079035dddb246  movaps [rsp+0x10], xmm5
000079035dddb24b  movaps [rsp+0x20], xmm4
000079035dddb250  lea rdi, [rsp]
000079035dddb254  mov esi, 0x00
000079035dddb259  mov rax, 0x64ACAA8B0530
000079035dddb263  call rax
000079035dddb265  movaps xmm1, [rsp]
000079035dddb269  add rsp, 0x30
000079035dddb26d  vmovaps xmm0, [rsp]
000079035dddb272  vmovaps xmm2, [rsp+0x10]
000079035dddb278  vmovaps xmm3, [rsp+0x20]
000079035dddb27e  vmovaps xmm4, [rsp+0x30]
000079035dddb284  vmovaps xmm5, [rsp+0x40]
000079035dddb28a  vmovaps xmm6, [rsp+0x50]
000079035dddb290  vmovaps xmm7, [rsp+0x60]
000079035dddb296  vmovaps xmm8, [rsp+0x70]
000079035dddb29c  vmovaps xmm9, [rsp+0x80]
000079035dddb2a5  vmovaps xmm10, [rsp+0x90]
000079035dddb2ae  vmovaps xmm11, [rsp+0xA0]
000079035dddb2b7  vmovaps xmm12, [rsp+0xB0]
000079035dddb2c0  vmovaps xmm13, [rsp+0xC0]
000079035dddb2c9  vmovaps xmm14, [rsp+0xD0]
000079035dddb2d2  vmovaps xmm15, [rsp+0xE0]
000079035dddb2db  add rsp, 0xF0
000079035dddb2e2  pop r11
000079035dddb2e4  pop r10
000079035dddb2e6  pop r9
000079035dddb2e8  pop r8
000079035dddb2ea  pop rsi
000079035dddb2eb  pop rdi
000079035dddb2ec  pop rdx
000079035dddb2ed  pop rcx
000079035dddb2ee  pop rax
000079035dddb2ef  add rsp, 0x08
000079035dddb2f3  jmp 0x000079035DDD90E6
000079035dddb2f8  sub rsp, 0x08
000079035dddb2fc  push rax
000079035dddb2fd  push rcx
000079035dddb2fe  push rdx
000079035dddb2ff  push rdi
000079035dddb300  push rsi
000079035dddb301  push r8
000079035dddb303  push r9
000079035dddb305  push r10
000079035dddb307  push r11
000079035dddb309  sub rsp, 0xF0
000079035dddb310  vmovaps [rsp], xmm0
000079035dddb315  vmovaps [rsp+0x10], xmm1
000079035dddb31b  vmovaps [rsp+0x20], xmm2
000079035dddb321  vmovaps [rsp+0x30], xmm3
000079035dddb327  vmovaps [rsp+0x40], xmm5
000079035dddb32d  vmovaps [rsp+0x50], xmm6
000079035dddb333  vmovaps [rsp+0x60], xmm7
000079035dddb339  vmovaps [rsp+0x70], xmm8
000079035dddb33f  vmovaps [rsp+0x80], xmm9
000079035dddb348  vmovaps [rsp+0x90], xmm10
000079035dddb351  vmovaps [rsp+0xA0], xmm11
000079035dddb35a  vmovaps [rsp+0xB0], xmm12
000079035dddb363  vmovaps [rsp+0xC0], xmm13
000079035dddb36c  vmovaps [rsp+0xD0], xmm14
000079035dddb375  vmovaps [rsp+0xE0], xmm15
000079035dddb37e  sub rsp, 0x30
000079035dddb382  movaps [rsp], xmm4
000079035dddb386  movaps [rsp+0x10], xmm3
000079035dddb38b  movaps [rsp+0x20], xmm5
000079035dddb390  lea rdi, [rsp]
000079035dddb394  mov esi, 0x00
000079035dddb399  mov rax, 0x64ACAA8B0530
000079035dddb3a3  call rax
000079035dddb3a5  movaps xmm4, [rsp]
000079035dddb3a9  add rsp, 0x30
000079035dddb3ad  vmovaps xmm0, [rsp]
000079035dddb3b2  vmovaps xmm1, [rsp+0x10]
000079035dddb3b8  vmovaps xmm2, [rsp+0x20]
000079035dddb3be  vmovaps xmm3, [rsp+0x30]
000079035dddb3c4  vmovaps xmm5, [rsp+0x40]
000079035dddb3ca  vmovaps xmm6, [rsp+0x50]
000079035dddb3d0  vmovaps xmm7, [rsp+0x60]
000079035dddb3d6  vmovaps xmm8, [rsp+0x70]
000079035dddb3dc  vmovaps xmm9, [rsp+0x80]
000079035dddb3e5  vmovaps xmm10, [rsp+0x90]
000079035dddb3ee  vmovaps xmm11, [rsp+0xA0]
000079035dddb3f7  vmovaps xmm12, [rsp+0xB0]
000079035dddb400  vmovaps xmm13, [rsp+0xC0]
000079035dddb409  vmovaps xmm14, [rsp+0xD0]
000079035dddb412  vmovaps xmm15, [rsp+0xE0]
000079035dddb41b  add rsp, 0xF0
000079035dddb422  pop r11
000079035dddb424  pop r10
000079035dddb426  pop r9
000079035dddb428  pop r8
000079035dddb42a  pop rsi
000079035dddb42b  pop rdi
000079035dddb42c  pop rdx
000079035dddb42d  pop rcx
000079035dddb42e  pop rax
000079035dddb42f  add rsp, 0x08
000079035dddb433  jmp 0x000079035DDD9134
000079035dddb438  call 0x000079035DCD64F0
000079035dddb43d  jmp 0x000079035DDD9141
000079035dddb442  sub rsp, 0x08
000079035dddb446  push rax
000079035dddb447  push rcx
000079035dddb448  push rdx
000079035dddb449  push rdi
000079035dddb44a  push rsi
000079035dddb44b  push r8
000079035dddb44d  push r9
000079035dddb44f  push r10
000079035dddb451  push r11
000079035dddb453  sub rsp, 0xF0
000079035dddb45a  vmovaps [rsp], xmm0
000079035dddb45f  vmovaps [rsp+0x10], xmm1
000079035dddb465  vmovaps [rsp+0x20], xmm2
000079035dddb46b  vmovaps [rsp+0x30], xmm3
000079035dddb471  vmovaps [rsp+0x40], xmm4
000079035dddb477  vmovaps [rsp+0x50], xmm6
000079035dddb47d  vmovaps [rsp+0x60], xmm7
000079035dddb483  vmovaps [rsp+0x70], xmm8
000079035dddb489  vmovaps [rsp+0x80], xmm9
000079035dddb492  vmovaps [rsp+0x90], xmm10
000079035dddb49b  vmovaps [rsp+0xA0], xmm11
000079035dddb4a4  vmovaps [rsp+0xB0], xmm12
000079035dddb4ad  vmovaps [rsp+0xC0], xmm13
000079035dddb4b6  vmovaps [rsp+0xD0], xmm14
000079035dddb4bf  vmovaps [rsp+0xE0], xmm15
000079035dddb4c8  sub rsp, 0x30
000079035dddb4cc  movaps [rsp], xmm5
000079035dddb4d0  movaps [rsp+0x10], xmm6
000079035dddb4d5  movaps [rsp+0x20], xmm3
000079035dddb4da  lea rdi, [rsp]
000079035dddb4de  mov esi, 0x00
000079035dddb4e3  mov rax, 0x64ACAA8B0530
000079035dddb4ed  call rax
000079035dddb4ef  movaps xmm5, [rsp]
000079035dddb4f3  add rsp, 0x30
000079035dddb4f7  vmovaps xmm0, [rsp]
000079035dddb4fc  vmovaps xmm1, [rsp+0x10]
000079035dddb502  vmovaps xmm2, [rsp+0x20]
000079035dddb508  vmovaps xmm3, [rsp+0x30]
000079035dddb50e  vmovaps xmm4, [rsp+0x40]
000079035dddb514  vmovaps xmm6, [rsp+0x50]
000079035dddb51a  vmovaps xmm7, [rsp+0x60]
000079035dddb520  vmovaps xmm8, [rsp+0x70]
000079035dddb526  vmovaps xmm9, [rsp+0x80]
000079035dddb52f  vmovaps xmm10, [rsp+0x90]
000079035dddb538  vmovaps xmm11, [rsp+0xA0]
000079035dddb541  vmovaps xmm12, [rsp+0xB0]
000079035dddb54a  vmovaps xmm13, [rsp+0xC0]
000079035dddb553  vmovaps xmm14, [rsp+0xD0]
000079035dddb55c  vmovaps xmm15, [rsp+0xE0]
000079035dddb565  add rsp, 0xF0
000079035dddb56c  pop r11
000079035dddb56e  pop r10
000079035dddb570  pop r9
000079035dddb572  pop r8
000079035dddb574  pop rsi
000079035dddb575  pop rdi
000079035dddb576  pop rdx
000079035dddb577  pop rcx
000079035dddb578  pop rax
000079035dddb579  add rsp, 0x08
000079035dddb57d  jmp 0x000079035DDD9167
000079035dddb582  sub rsp, 0x08
000079035dddb586  push rax
000079035dddb587  push rcx
000079035dddb588  push rdx
000079035dddb589  push rdi
000079035dddb58a  push rsi
000079035dddb58b  push r8
000079035dddb58d  push r9
000079035dddb58f  push r10
000079035dddb591  push r11
000079035dddb593  sub rsp, 0xF0
000079035dddb59a  vmovaps [rsp], xmm0
000079035dddb59f  vmovaps [rsp+0x10], xmm1
000079035dddb5a5  vmovaps [rsp+0x20], xmm2
000079035dddb5ab  vmovaps [rsp+0x30], xmm3
000079035dddb5b1  vmovaps [rsp+0x40], xmm4
000079035dddb5b7  vmovaps [rsp+0x50], xmm5
000079035dddb5bd  vmovaps [rsp+0x60], xmm7
000079035dddb5c3  vmovaps [rsp+0x70], xmm8
000079035dddb5c9  vmovaps [rsp+0x80], xmm9
000079035dddb5d2  vmovaps [rsp+0x90], xmm10
000079035dddb5db  vmovaps [rsp+0xA0], xmm11
000079035dddb5e4  vmovaps [rsp+0xB0], xmm12
000079035dddb5ed  vmovaps [rsp+0xC0], xmm13
000079035dddb5f6  vmovaps [rsp+0xD0], xmm14
000079035dddb5ff  vmovaps [rsp+0xE0], xmm15
000079035dddb608  sub rsp, 0x30
000079035dddb60c  movaps [rsp], xmm6
000079035dddb610  movaps [rsp+0x10], xmm9
000079035dddb616  movaps [rsp+0x20], xmm1
000079035dddb61b  lea rdi, [rsp]
000079035dddb61f  mov esi, 0x00
000079035dddb624  mov rax, 0x64ACAA8B0530
000079035dddb62e  call rax
000079035dddb630  movaps xmm6, [rsp]
000079035dddb634  add rsp, 0x30
000079035dddb638  vmovaps xmm0, [rsp]
000079035dddb63d  vmovaps xmm1, [rsp+0x10]
000079035dddb643  vmovaps xmm2, [rsp+0x20]
000079035dddb649  vmovaps xmm3, [rsp+0x30]
000079035dddb64f  vmovaps xmm4, [rsp+0x40]
000079035dddb655  vmovaps xmm5, [rsp+0x50]
000079035dddb65b  vmovaps xmm7, [rsp+0x60]
000079035dddb661  vmovaps xmm8, [rsp+0x70]
000079035dddb667  vmovaps xmm9, [rsp+0x80]
000079035dddb670  vmovaps xmm10, [rsp+0x90]
000079035dddb679  vmovaps xmm11, [rsp+0xA0]
000079035dddb682  vmovaps xmm12, [rsp+0xB0]
000079035dddb68b  vmovaps xmm13, [rsp+0xC0]
000079035dddb694  vmovaps xmm14, [rsp+0xD0]
000079035dddb69d  vmovaps xmm15, [rsp+0xE0]
000079035dddb6a6  add rsp, 0xF0
000079035dddb6ad  pop r11
000079035dddb6af  pop r10
000079035dddb6b1  pop r9
000079035dddb6b3  pop r8
000079035dddb6b5  pop rsi
000079035dddb6b6  pop rdi
000079035dddb6b7  pop rdx
000079035dddb6b8  pop rcx
000079035dddb6b9  pop rax
000079035dddb6ba  add rsp, 0x08
000079035dddb6be  jmp 0x000079035DDD918B
000079035dddb6c3  sub rsp, 0x08
000079035dddb6c7  push rax
000079035dddb6c8  push rcx
000079035dddb6c9  push rdx
000079035dddb6ca  push rdi
000079035dddb6cb  push rsi
000079035dddb6cc  push r8
000079035dddb6ce  push r9
000079035dddb6d0  push r10
000079035dddb6d2  push r11
000079035dddb6d4  sub rsp, 0xF0
000079035dddb6db  vmovaps [rsp], xmm0
000079035dddb6e0  vmovaps [rsp+0x10], xmm1
000079035dddb6e6  vmovaps [rsp+0x20], xmm2
000079035dddb6ec  vmovaps [rsp+0x30], xmm3
000079035dddb6f2  vmovaps [rsp+0x40], xmm4
000079035dddb6f8  vmovaps [rsp+0x50], xmm5
000079035dddb6fe  vmovaps [rsp+0x60], xmm6
000079035dddb704  vmovaps [rsp+0x70], xmm7
000079035dddb70a  vmovaps [rsp+0x80], xmm8
000079035dddb713  vmovaps [rsp+0x90], xmm10
000079035dddb71c  vmovaps [rsp+0xA0], xmm11
000079035dddb725  vmovaps [rsp+0xB0], xmm12
000079035dddb72e  vmovaps [rsp+0xC0], xmm13
000079035dddb737  vmovaps [rsp+0xD0], xmm14
000079035dddb740  vmovaps [rsp+0xE0], xmm15
000079035dddb749  sub rsp, 0x30
000079035dddb74d  movaps [rsp], xmm9
000079035dddb752  movaps [rsp+0x10], xmm3
000079035dddb757  movaps [rsp+0x20], xmm1
000079035dddb75c  lea rdi, [rsp]
000079035dddb760  mov esi, 0x00
000079035dddb765  mov rax, 0x64ACAA8B0530
000079035dddb76f  call rax
000079035dddb771  movaps xmm9, [rsp]
000079035dddb776  add rsp, 0x30
000079035dddb77a  vmovaps xmm0, [rsp]
000079035dddb77f  vmovaps xmm1, [rsp+0x10]
000079035dddb785  vmovaps xmm2, [rsp+0x20]
000079035dddb78b  vmovaps xmm3, [rsp+0x30]
000079035dddb791  vmovaps xmm4, [rsp+0x40]
000079035dddb797  vmovaps xmm5, [rsp+0x50]
000079035dddb79d  vmovaps xmm6, [rsp+0x60]
000079035dddb7a3  vmovaps xmm7, [rsp+0x70]
000079035dddb7a9  vmovaps xmm8, [rsp+0x80]
000079035dddb7b2  vmovaps xmm10, [rsp+0x90]
000079035dddb7bb  vmovaps xmm11, [rsp+0xA0]
000079035dddb7c4  vmovaps xmm12, [rsp+0xB0]
000079035dddb7cd  vmovaps xmm13, [rsp+0xC0]
000079035dddb7d6  vmovaps xmm14, [rsp+0xD0]
000079035dddb7df  vmovaps xmm15, [rsp+0xE0]
000079035dddb7e8  add rsp, 0xF0
000079035dddb7ef  pop r11
000079035dddb7f1  pop r10
000079035dddb7f3  pop r9
000079035dddb7f5  pop r8
000079035dddb7f7  pop rsi
000079035dddb7f8  pop rdi
000079035dddb7f9  pop rdx
000079035dddb7fa  pop rcx
000079035dddb7fb  pop rax
000079035dddb7fc  add rsp, 0x08
000079035dddb800  jmp 0x000079035DDD91D7
000079035dddb805  call 0x000079035DCD64F0
000079035dddb80a  jmp 0x000079035DDD91E4
000079035dddb80f  sub rsp, 0x08
000079035dddb813  push rax
000079035dddb814  push rcx
000079035dddb815  push rdx
000079035dddb816  push rdi
000079035dddb817  push rsi
000079035dddb818  push r8
000079035dddb81a  push r9
000079035dddb81c  push r10
000079035dddb81e  push r11
000079035dddb820  sub rsp, 0xF0
000079035dddb827  vmovaps [rsp], xmm0
000079035dddb82c  vmovaps [rsp+0x10], xmm1
000079035dddb832  vmovaps [rsp+0x20], xmm2
000079035dddb838  vmovaps [rsp+0x30], xmm3
000079035dddb83e  vmovaps [rsp+0x40], xmm4
000079035dddb844  vmovaps [rsp+0x50], xmm5
000079035dddb84a  vmovaps [rsp+0x60], xmm6
000079035dddb850  vmovaps [rsp+0x70], xmm7
000079035dddb856  vmovaps [rsp+0x80], xmm8
000079035dddb85f  vmovaps [rsp+0x90], xmm9
000079035dddb868  vmovaps [rsp+0xA0], xmm10
000079035dddb871  vmovaps [rsp+0xB0], xmm11
000079035dddb87a  vmovaps [rsp+0xC0], xmm12
000079035dddb883  vmovaps [rsp+0xD0], xmm13
000079035dddb88c  vmovaps [rsp+0xE0], xmm14
000079035dddb895  sub rsp, 0x30
000079035dddb899  movaps [rsp], xmm15
000079035dddb89e  movaps [rsp+0x10], xmm3
000079035dddb8a3  movaps [rsp+0x20], xmm7
000079035dddb8a8  lea rdi, [rsp]
000079035dddb8ac  mov esi, 0x00
000079035dddb8b1  mov rax, 0x64ACAA8B0530
000079035dddb8bb  call rax
000079035dddb8bd  movaps xmm15, [rsp]
000079035dddb8c2  add rsp, 0x30
000079035dddb8c6  vmovaps xmm0, [rsp]
000079035dddb8cb  vmovaps xmm1, [rsp+0x10]
000079035dddb8d1  vmovaps xmm2, [rsp+0x20]
000079035dddb8d7  vmovaps xmm3, [rsp+0x30]
000079035dddb8dd  vmovaps xmm4, [rsp+0x40]
000079035dddb8e3  vmovaps xmm5, [rsp+0x50]
000079035dddb8e9  vmovaps xmm6, [rsp+0x60]
000079035dddb8ef  vmovaps xmm7, [rsp+0x70]
000079035dddb8f5  vmovaps xmm8, [rsp+0x80]
000079035dddb8fe  vmovaps xmm9, [rsp+0x90]
000079035dddb907  vmovaps xmm10, [rsp+0xA0]
000079035dddb910  vmovaps xmm11, [rsp+0xB0]
000079035dddb919  vmovaps xmm12, [rsp+0xC0]
000079035dddb922  vmovaps xmm13, [rsp+0xD0]
000079035dddb92b  vmovaps xmm14, [rsp+0xE0]
000079035dddb934  add rsp, 0xF0
000079035dddb93b  pop r11
000079035dddb93d  pop r10
000079035dddb93f  pop r9
000079035dddb941  pop r8
000079035dddb943  pop rsi
000079035dddb944  pop rdi
000079035dddb945  pop rdx
000079035dddb946  pop rcx
000079035dddb947  pop rax
000079035dddb948  add rsp, 0x08
000079035dddb94c  jmp 0x000079035DDD9210
000079035dddb951  sub rsp, 0x08
000079035dddb955  push rax
000079035dddb956  push rcx
000079035dddb957  push rdx
000079035dddb958  push rdi
000079035dddb959  push rsi
000079035dddb95a  push r8
000079035dddb95c  push r9
000079035dddb95e  push r10
000079035dddb960  push r11
000079035dddb962  sub rsp, 0xF0
000079035dddb969  vmovaps [rsp], xmm0
000079035dddb96e  vmovaps [rsp+0x10], xmm1
000079035dddb974  vmovaps [rsp+0x20], xmm2
000079035dddb97a  vmovaps [rsp+0x30], xmm4
000079035dddb980  vmovaps [rsp+0x40], xmm5
000079035dddb986  vmovaps [rsp+0x50], xmm6
000079035dddb98c  vmovaps [rsp+0x60], xmm7
000079035dddb992  vmovaps [rsp+0x70], xmm8
000079035dddb998  vmovaps [rsp+0x80], xmm9
000079035dddb9a1  vmovaps [rsp+0x90], xmm10
000079035dddb9aa  vmovaps [rsp+0xA0], xmm11
000079035dddb9b3  vmovaps [rsp+0xB0], xmm12
000079035dddb9bc  vmovaps [rsp+0xC0], xmm13
000079035dddb9c5  vmovaps [rsp+0xD0], xmm14
000079035dddb9ce  vmovaps [rsp+0xE0], xmm15
000079035dddb9d7  sub rsp, 0x30
000079035dddb9db  movaps [rsp], xmm3
000079035dddb9df  movaps [rsp+0x10], xmm1
000079035dddb9e4  movaps [rsp+0x20], xmm15
000079035dddb9ea  lea rdi, [rsp]
000079035dddb9ee  mov esi, 0x00
000079035dddb9f3  mov rax, 0x64ACAA8B0530
000079035dddb9fd  call rax
000079035dddb9ff  movaps xmm3, [rsp]
000079035dddba03  add rsp, 0x30
000079035dddba07  vmovaps xmm0, [rsp]
000079035dddba0c  vmovaps xmm1, [rsp+0x10]
000079035dddba12  vmovaps xmm2, [rsp+0x20]
000079035dddba18  vmovaps xmm4, [rsp+0x30]
000079035dddba1e  vmovaps xmm5, [rsp+0x40]
000079035dddba24  vmovaps xmm6, [rsp+0x50]
000079035dddba2a  vmovaps xmm7, [rsp+0x60]
000079035dddba30  vmovaps xmm8, [rsp+0x70]
000079035dddba36  vmovaps xmm9, [rsp+0x80]
000079035dddba3f  vmovaps xmm10, [rsp+0x90]
000079035dddba48  vmovaps xmm11, [rsp+0xA0]
000079035dddba51  vmovaps xmm12, [rsp+0xB0]
000079035dddba5a  vmovaps xmm13, [rsp+0xC0]
000079035dddba63  vmovaps xmm14, [rsp+0xD0]
000079035dddba6c  vmovaps xmm15, [rsp+0xE0]
000079035dddba75  add rsp, 0xF0
000079035dddba7c  pop r11
000079035dddba7e  pop r10
000079035dddba80  pop r9
000079035dddba82  pop r8
000079035dddba84  pop rsi
000079035dddba85  pop rdi
000079035dddba86  pop rdx
000079035dddba87  pop rcx
000079035dddba88  pop rax
000079035dddba89  add rsp, 0x08
000079035dddba8d  jmp 0x000079035DDD929F
000079035dddba92  call 0x000079035DCD64F0
000079035dddba97  jmp 0x000079035DDD92A9
000079035dddba9c  sub rsp, 0x08
000079035dddbaa0  push rax
000079035dddbaa1  push rcx
000079035dddbaa2  push rdx
000079035dddbaa3  push rdi
000079035dddbaa4  push rsi
000079035dddbaa5  push r8
000079035dddbaa7  push r9
000079035dddbaa9  push r10
000079035dddbaab  push r11
000079035dddbaad  sub rsp, 0xF0
000079035dddbab4  vmovaps [rsp], xmm0
000079035dddbab9  vmovaps [rsp+0x10], xmm1
000079035dddbabf  vmovaps [rsp+0x20], xmm2
000079035dddbac5  vmovaps [rsp+0x30], xmm3
000079035dddbacb  vmovaps [rsp+0x40], xmm4
000079035dddbad1  vmovaps [rsp+0x50], xmm5
000079035dddbad7  vmovaps [rsp+0x60], xmm6
000079035dddbadd  vmovaps [rsp+0x70], xmm7
000079035dddbae3  vmovaps [rsp+0x80], xmm8
000079035dddbaec  vmovaps [rsp+0x90], xmm9
000079035dddbaf5  vmovaps [rsp+0xA0], xmm10
000079035dddbafe  vmovaps [rsp+0xB0], xmm11
000079035dddbb07  vmovaps [rsp+0xC0], xmm12
000079035dddbb10  vmovaps [rsp+0xD0], xmm13
000079035dddbb19  vmovaps [rsp+0xE0], xmm14
000079035dddbb22  sub rsp, 0x30
000079035dddbb26  movaps [rsp], xmm15
000079035dddbb2b  movaps [rsp+0x10], xmm14
000079035dddbb31  movaps [rsp+0x20], xmm4
000079035dddbb36  lea rdi, [rsp]
000079035dddbb3a  mov esi, 0x00
000079035dddbb3f  mov rax, 0x64ACAA8B0530
000079035dddbb49  call rax
000079035dddbb4b  movaps xmm15, [rsp]
000079035dddbb50  add rsp, 0x30
000079035dddbb54  vmovaps xmm0, [rsp]
000079035dddbb59  vmovaps xmm1, [rsp+0x10]
000079035dddbb5f  vmovaps xmm2, [rsp+0x20]
000079035dddbb65  vmovaps xmm3, [rsp+0x30]
000079035dddbb6b  vmovaps xmm4, [rsp+0x40]
000079035dddbb71  vmovaps xmm5, [rsp+0x50]
000079035dddbb77  vmovaps xmm6, [rsp+0x60]
000079035dddbb7d  vmovaps xmm7, [rsp+0x70]
000079035dddbb83  vmovaps xmm8, [rsp+0x80]
000079035dddbb8c  vmovaps xmm9, [rsp+0x90]
000079035dddbb95  vmovaps xmm10, [rsp+0xA0]
000079035dddbb9e  vmovaps xmm11, [rsp+0xB0]
000079035dddbba7  vmovaps xmm12, [rsp+0xC0]
000079035dddbbb0  vmovaps xmm13, [rsp+0xD0]
000079035dddbbb9  vmovaps xmm14, [rsp+0xE0]
000079035dddbbc2  add rsp, 0xF0
000079035dddbbc9  pop r11
000079035dddbbcb  pop r10
000079035dddbbcd  pop r9
000079035dddbbcf  pop r8
000079035dddbbd1  pop rsi
000079035dddbbd2  pop rdi
000079035dddbbd3  pop rdx
000079035dddbbd4  pop rcx
000079035dddbbd5  pop rax
000079035dddbbd6  add rsp, 0x08
000079035dddbbda  jmp 0x000079035DDD92D7
000079035dddbbdf  sub rsp, 0x08
000079035dddbbe3  push rax
000079035dddbbe4  push rcx
000079035dddbbe5  push rdx
000079035dddbbe6  push rdi
000079035dddbbe7  push rsi
000079035dddbbe8  push r8
000079035dddbbea  push r9
000079035dddbbec  push r10
000079035dddbbee  push r11
000079035dddbbf0  sub rsp, 0xF0
000079035dddbbf7  vmovaps [rsp], xmm0
000079035dddbbfc  vmovaps [rsp+0x10], xmm1
000079035dddbc02  vmovaps [rsp+0x20], xmm2
000079035dddbc08  vmovaps [rsp+0x30], xmm3
000079035dddbc0e  vmovaps [rsp+0x40], xmm4
000079035dddbc14  vmovaps [rsp+0x50], xmm5
000079035dddbc1a  vmovaps [rsp+0x60], xmm6
000079035dddbc20  vmovaps [rsp+0x70], xmm7
000079035dddbc26  vmovaps [rsp+0x80], xmm8
000079035dddbc2f  vmovaps [rsp+0x90], xmm9
000079035dddbc38  vmovaps [rsp+0xA0], xmm10
000079035dddbc41  vmovaps [rsp+0xB0], xmm11
000079035dddbc4a  vmovaps [rsp+0xC0], xmm12
000079035dddbc53  vmovaps [rsp+0xD0], xmm13
000079035dddbc5c  vmovaps [rsp+0xE0], xmm15
000079035dddbc65  sub rsp, 0x30
000079035dddbc69  movaps [rsp], xmm14
000079035dddbc6e  movaps [rsp+0x10], xmm2
000079035dddbc73  movaps [rsp+0x20], xmm1
000079035dddbc78  lea rdi, [rsp]
000079035dddbc7c  mov esi, 0x00
000079035dddbc81  mov rax, 0x64ACAA8B0530
000079035dddbc8b  call rax
000079035dddbc8d  movaps xmm14, [rsp]
000079035dddbc92  add rsp, 0x30
000079035dddbc96  vmovaps xmm0, [rsp]
000079035dddbc9b  vmovaps xmm1, [rsp+0x10]
000079035dddbca1  vmovaps xmm2, [rsp+0x20]
000079035dddbca7  vmovaps xmm3, [rsp+0x30]
000079035dddbcad  vmovaps xmm4, [rsp+0x40]
000079035dddbcb3  vmovaps xmm5, [rsp+0x50]
000079035dddbcb9  vmovaps xmm6, [rsp+0x60]
000079035dddbcbf  vmovaps xmm7, [rsp+0x70]
000079035dddbcc5  vmovaps xmm8, [rsp+0x80]
000079035dddbcce  vmovaps xmm9, [rsp+0x90]
000079035dddbcd7  vmovaps xmm10, [rsp+0xA0]
000079035dddbce0  vmovaps xmm11, [rsp+0xB0]
000079035dddbce9  vmovaps xmm12, [rsp+0xC0]
000079035dddbcf2  vmovaps xmm13, [rsp+0xD0]
000079035dddbcfb  vmovaps xmm15, [rsp+0xE0]
000079035dddbd04  add rsp, 0xF0
000079035dddbd0b  pop r11
000079035dddbd0d  pop r10
000079035dddbd0f  pop r9
000079035dddbd11  pop r8
000079035dddbd13  pop rsi
000079035dddbd14  pop rdi
000079035dddbd15  pop rdx
000079035dddbd16  pop rcx
000079035dddbd17  pop rax
000079035dddbd18  add rsp, 0x08
000079035dddbd1c  jmp 0x000079035DDD92FD
000079035dddbd21  sub rsp, 0x08
000079035dddbd25  push rax
000079035dddbd26  push rcx
000079035dddbd27  push rdx
000079035dddbd28  push rdi
000079035dddbd29  push rsi
000079035dddbd2a  push r8
000079035dddbd2c  push r9
000079035dddbd2e  push r10
000079035dddbd30  push r11
000079035dddbd32  sub rsp, 0xF0
000079035dddbd39  vmovaps [rsp], xmm0
000079035dddbd3e  vmovaps [rsp+0x10], xmm2
000079035dddbd44  vmovaps [rsp+0x20], xmm3
000079035dddbd4a  vmovaps [rsp+0x30], xmm4
000079035dddbd50  vmovaps [rsp+0x40], xmm5
000079035dddbd56  vmovaps [rsp+0x50], xmm6
000079035dddbd5c  vmovaps [rsp+0x60], xmm7
000079035dddbd62  vmovaps [rsp+0x70], xmm8
000079035dddbd68  vmovaps [rsp+0x80], xmm9
000079035dddbd71  vmovaps [rsp+0x90], xmm10
000079035dddbd7a  vmovaps [rsp+0xA0], xmm11
000079035dddbd83  vmovaps [rsp+0xB0], xmm12
000079035dddbd8c  vmovaps [rsp+0xC0], xmm13
000079035dddbd95  vmovaps [rsp+0xD0], xmm14
000079035dddbd9e  vmovaps [rsp+0xE0], xmm15
000079035dddbda7  sub rsp, 0x30
000079035dddbdab  movaps [rsp], xmm1
000079035dddbdaf  movaps [rsp+0x10], xmm4
000079035dddbdb4  movaps [rsp+0x20], xmm9
000079035dddbdba  lea rdi, [rsp]
000079035dddbdbe  mov esi, 0x00
000079035dddbdc3  mov rax, 0x64ACAA8B0530
000079035dddbdcd  call rax
000079035dddbdcf  movaps xmm1, [rsp]
000079035dddbdd3  add rsp, 0x30
000079035dddbdd7  vmovaps xmm0, [rsp]
000079035dddbddc  vmovaps xmm2, [rsp+0x10]
000079035dddbde2  vmovaps xmm3, [rsp+0x20]
000079035dddbde8  vmovaps xmm4, [rsp+0x30]
000079035dddbdee  vmovaps xmm5, [rsp+0x40]
000079035dddbdf4  vmovaps xmm6, [rsp+0x50]
000079035dddbdfa  vmovaps xmm7, [rsp+0x60]
000079035dddbe00  vmovaps xmm8, [rsp+0x70]
000079035dddbe06  vmovaps xmm9, [rsp+0x80]
000079035dddbe0f  vmovaps xmm10, [rsp+0x90]
000079035dddbe18  vmovaps xmm11, [rsp+0xA0]
000079035dddbe21  vmovaps xmm12, [rsp+0xB0]
000079035dddbe2a  vmovaps xmm13, [rsp+0xC0]
000079035dddbe33  vmovaps xmm14, [rsp+0xD0]
000079035dddbe3c  vmovaps xmm15, [rsp+0xE0]
000079035dddbe45  add rsp, 0xF0
000079035dddbe4c  pop r11
000079035dddbe4e  pop r10
000079035dddbe50  pop r9
000079035dddbe52  pop r8
000079035dddbe54  pop rsi
000079035dddbe55  pop rdi
000079035dddbe56  pop rdx
000079035dddbe57  pop rcx
000079035dddbe58  pop rax
000079035dddbe59  add rsp, 0x08
000079035dddbe5d  jmp 0x000079035DDD931B
000079035dddbe62  sub rsp, 0x08
000079035dddbe66  push rax
000079035dddbe67  push rcx
000079035dddbe68  push rdx
000079035dddbe69  push rdi
000079035dddbe6a  push rsi
000079035dddbe6b  push r8
000079035dddbe6d  push r9
000079035dddbe6f  push r10
000079035dddbe71  push r11
000079035dddbe73  sub rsp, 0xF0
000079035dddbe7a  vmovaps [rsp], xmm0
000079035dddbe7f  vmovaps [rsp+0x10], xmm1
000079035dddbe85  vmovaps [rsp+0x20], xmm2
000079035dddbe8b  vmovaps [rsp+0x30], xmm3
000079035dddbe91  vmovaps [rsp+0x40], xmm5
000079035dddbe97  vmovaps [rsp+0x50], xmm6
000079035dddbe9d  vmovaps [rsp+0x60], xmm7
000079035dddbea3  vmovaps [rsp+0x70], xmm8
000079035dddbea9  vmovaps [rsp+0x80], xmm9
000079035dddbeb2  vmovaps [rsp+0x90], xmm10
000079035dddbebb  vmovaps [rsp+0xA0], xmm11
000079035dddbec4  vmovaps [rsp+0xB0], xmm12
000079035dddbecd  vmovaps [rsp+0xC0], xmm13
000079035dddbed6  vmovaps [rsp+0xD0], xmm14
000079035dddbedf  vmovaps [rsp+0xE0], xmm15
000079035dddbee8  sub rsp, 0x30
000079035dddbeec  movaps [rsp], xmm4
000079035dddbef0  movaps [rsp+0x10], xmm2
000079035dddbef5  movaps [rsp+0x20], xmm9
000079035dddbefb  lea rdi, [rsp]
000079035dddbeff  mov esi, 0x00
000079035dddbf04  mov rax, 0x64ACAA8B0530
000079035dddbf0e  call rax
000079035dddbf10  movaps xmm4, [rsp]
000079035dddbf14  add rsp, 0x30
000079035dddbf18  vmovaps xmm0, [rsp]
000079035dddbf1d  vmovaps xmm1, [rsp+0x10]
000079035dddbf23  vmovaps xmm2, [rsp+0x20]
000079035dddbf29  vmovaps xmm3, [rsp+0x30]
000079035dddbf2f  vmovaps xmm5, [rsp+0x40]
000079035dddbf35  vmovaps xmm6, [rsp+0x50]
000079035dddbf3b  vmovaps xmm7, [rsp+0x60]
000079035dddbf41  vmovaps xmm8, [rsp+0x70]
000079035dddbf47  vmovaps xmm9, [rsp+0x80]
000079035dddbf50  vmovaps xmm10, [rsp+0x90]
000079035dddbf59  vmovaps xmm11, [rsp+0xA0]
000079035dddbf62  vmovaps xmm12, [rsp+0xB0]
000079035dddbf6b  vmovaps xmm13, [rsp+0xC0]
000079035dddbf74  vmovaps xmm14, [rsp+0xD0]
000079035dddbf7d  vmovaps xmm15, [rsp+0xE0]
000079035dddbf86  add rsp, 0xF0
000079035dddbf8d  pop r11
000079035dddbf8f  pop r10
000079035dddbf91  pop r9
000079035dddbf93  pop r8
000079035dddbf95  pop rsi
000079035dddbf96  pop rdi
000079035dddbf97  pop rdx
000079035dddbf98  pop rcx
000079035dddbf99  pop rax
000079035dddbf9a  add rsp, 0x08
000079035dddbf9e  jmp 0x000079035DDD934B
000079035dddbfa3  sub rsp, 0x08
000079035dddbfa7  push rax
000079035dddbfa8  push rcx
000079035dddbfa9  push rdx
000079035dddbfaa  push rdi
000079035dddbfab  push rsi
000079035dddbfac  push r8
000079035dddbfae  push r9
000079035dddbfb0  push r10
000079035dddbfb2  push r11
000079035dddbfb4  sub rsp, 0xF0
000079035dddbfbb  vmovaps [rsp], xmm0
000079035dddbfc0  vmovaps [rsp+0x10], xmm1
000079035dddbfc6  vmovaps [rsp+0x20], xmm2
000079035dddbfcc  vmovaps [rsp+0x30], xmm3
000079035dddbfd2  vmovaps [rsp+0x40], xmm4
000079035dddbfd8  vmovaps [rsp+0x50], xmm5
000079035dddbfde  vmovaps [rsp+0x60], xmm6
000079035dddbfe4  vmovaps [rsp+0x70], xmm7
000079035dddbfea  vmovaps [rsp+0x80], xmm8
000079035dddbff3  vmovaps [rsp+0x90], xmm10
000079035dddbffc  vmovaps [rsp+0xA0], xmm11
000079035dddc005  vmovaps [rsp+0xB0], xmm12
000079035dddc00e  vmovaps [rsp+0xC0], xmm13
000079035dddc017  vmovaps [rsp+0xD0], xmm14
000079035dddc020  vmovaps [rsp+0xE0], xmm15
000079035dddc029  sub rsp, 0x30
000079035dddc02d  movaps [rsp], xmm9
000079035dddc032  movaps [rsp+0x10], xmm2
000079035dddc037  movaps [rsp+0x20], xmm1
000079035dddc03c  lea rdi, [rsp]
000079035dddc040  mov esi, 0x00
000079035dddc045  mov rax, 0x64ACAA8B0530
000079035dddc04f  call rax
000079035dddc051  movaps xmm9, [rsp]
000079035dddc056  add rsp, 0x30
000079035dddc05a  vmovaps xmm0, [rsp]
000079035dddc05f  vmovaps xmm1, [rsp+0x10]
000079035dddc065  vmovaps xmm2, [rsp+0x20]
000079035dddc06b  vmovaps xmm3, [rsp+0x30]
000079035dddc071  vmovaps xmm4, [rsp+0x40]
000079035dddc077  vmovaps xmm5, [rsp+0x50]
000079035dddc07d  vmovaps xmm6, [rsp+0x60]
000079035dddc083  vmovaps xmm7, [rsp+0x70]
000079035dddc089  vmovaps xmm8, [rsp+0x80]
000079035dddc092  vmovaps xmm10, [rsp+0x90]
000079035dddc09b  vmovaps xmm11, [rsp+0xA0]
000079035dddc0a4  vmovaps xmm12, [rsp+0xB0]
000079035dddc0ad  vmovaps xmm13, [rsp+0xC0]
000079035dddc0b6  vmovaps xmm14, [rsp+0xD0]
000079035dddc0bf  vmovaps xmm15, [rsp+0xE0]
000079035dddc0c8  add rsp, 0xF0
000079035dddc0cf  pop r11
000079035dddc0d1  pop r10
000079035dddc0d3  pop r9
000079035dddc0d5  pop r8
000079035dddc0d7  pop rsi
000079035dddc0d8  pop rdi
000079035dddc0d9  pop rdx
000079035dddc0da  pop rcx
000079035dddc0db  pop rax
000079035dddc0dc  add rsp, 0x08
000079035dddc0e0  jmp 0x000079035DDD9381
000079035dddc0e5  sub rsp, 0x08
000079035dddc0e9  push rax
000079035dddc0ea  push rcx
000079035dddc0eb  push rdx
000079035dddc0ec  push rdi
000079035dddc0ed  push rsi
000079035dddc0ee  push r8
000079035dddc0f0  push r9
000079035dddc0f2  push r10
000079035dddc0f4  push r11
000079035dddc0f6  sub rsp, 0xF0
000079035dddc0fd  vmovaps [rsp], xmm0
000079035dddc102  vmovaps [rsp+0x10], xmm2
000079035dddc108  vmovaps [rsp+0x20], xmm3
000079035dddc10e  vmovaps [rsp+0x30], xmm4
000079035dddc114  vmovaps [rsp+0x40], xmm5
000079035dddc11a  vmovaps [rsp+0x50], xmm6
000079035dddc120  vmovaps [rsp+0x60], xmm7
000079035dddc126  vmovaps [rsp+0x70], xmm8
000079035dddc12c  vmovaps [rsp+0x80], xmm9
000079035dddc135  vmovaps [rsp+0x90], xmm10
000079035dddc13e  vmovaps [rsp+0xA0], xmm11
000079035dddc147  vmovaps [rsp+0xB0], xmm12
000079035dddc150  vmovaps [rsp+0xC0], xmm13
000079035dddc159  vmovaps [rsp+0xD0], xmm14
000079035dddc162  vmovaps [rsp+0xE0], xmm15
000079035dddc16b  sub rsp, 0x30
000079035dddc16f  movaps [rsp], xmm1
000079035dddc173  movaps [rsp+0x10], xmm15
000079035dddc179  movaps [rsp+0x20], xmm6
000079035dddc17e  lea rdi, [rsp]
000079035dddc182  mov esi, 0x00
000079035dddc187  mov rax, 0x64ACAA8B0530
000079035dddc191  call rax
000079035dddc193  movaps xmm1, [rsp]
000079035dddc197  add rsp, 0x30
000079035dddc19b  vmovaps xmm0, [rsp]
000079035dddc1a0  vmovaps xmm2, [rsp+0x10]
000079035dddc1a6  vmovaps xmm3, [rsp+0x20]
000079035dddc1ac  vmovaps xmm4, [rsp+0x30]
000079035dddc1b2  vmovaps xmm5, [rsp+0x40]
000079035dddc1b8  vmovaps xmm6, [rsp+0x50]
000079035dddc1be  vmovaps xmm7, [rsp+0x60]
000079035dddc1c4  vmovaps xmm8, [rsp+0x70]
000079035dddc1ca  vmovaps xmm9, [rsp+0x80]
000079035dddc1d3  vmovaps xmm10, [rsp+0x90]
000079035dddc1dc  vmovaps xmm11, [rsp+0xA0]
000079035dddc1e5  vmovaps xmm12, [rsp+0xB0]
000079035dddc1ee  vmovaps xmm13, [rsp+0xC0]
000079035dddc1f7  vmovaps xmm14, [rsp+0xD0]
000079035dddc200  vmovaps xmm15, [rsp+0xE0]
000079035dddc209  add rsp, 0xF0
000079035dddc210  pop r11
000079035dddc212  pop r10
000079035dddc214  pop r9
000079035dddc216  pop r8
000079035dddc218  pop rsi
000079035dddc219  pop rdi
000079035dddc21a  pop rdx
000079035dddc21b  pop rcx
000079035dddc21c  pop rax
000079035dddc21d  add rsp, 0x08
000079035dddc221  jmp 0x000079035DDD93A2
000079035dddc226  sub rsp, 0x08
000079035dddc22a  push rax
000079035dddc22b  push rcx
000079035dddc22c  push rdx
000079035dddc22d  push rdi
000079035dddc22e  push rsi
000079035dddc22f  push r8
000079035dddc231  push r9
000079035dddc233  push r10
000079035dddc235  push r11
000079035dddc237  sub rsp, 0xF0
000079035dddc23e  vmovaps [rsp], xmm0
000079035dddc243  vmovaps [rsp+0x10], xmm1
000079035dddc249  vmovaps [rsp+0x20], xmm2
000079035dddc24f  vmovaps [rsp+0x30], xmm3
000079035dddc255  vmovaps [rsp+0x40], xmm4
000079035dddc25b  vmovaps [rsp+0x50], xmm5
000079035dddc261  vmovaps [rsp+0x60], xmm6
000079035dddc267  vmovaps [rsp+0x70], xmm7
000079035dddc26d  vmovaps [rsp+0x80], xmm8
000079035dddc276  vmovaps [rsp+0x90], xmm9
000079035dddc27f  vmovaps [rsp+0xA0], xmm10
000079035dddc288  vmovaps [rsp+0xB0], xmm11
000079035dddc291  vmovaps [rsp+0xC0], xmm12
000079035dddc29a  vmovaps [rsp+0xD0], xmm13
000079035dddc2a3  vmovaps [rsp+0xE0], xmm14
000079035dddc2ac  sub rsp, 0x30
000079035dddc2b0  movaps [rsp], xmm15
000079035dddc2b5  movaps [rsp+0x10], xmm5
000079035dddc2ba  movaps [rsp+0x20], xmm3
000079035dddc2bf  lea rdi, [rsp]
000079035dddc2c3  mov esi, 0x00
000079035dddc2c8  mov rax, 0x64ACAA8B0530
000079035dddc2d2  call rax
000079035dddc2d4  movaps xmm15, [rsp]
000079035dddc2d9  add rsp, 0x30
000079035dddc2dd  vmovaps xmm0, [rsp]
000079035dddc2e2  vmovaps xmm1, [rsp+0x10]
000079035dddc2e8  vmovaps xmm2, [rsp+0x20]
000079035dddc2ee  vmovaps xmm3, [rsp+0x30]
000079035dddc2f4  vmovaps xmm4, [rsp+0x40]
000079035dddc2fa  vmovaps xmm5, [rsp+0x50]
000079035dddc300  vmovaps xmm6, [rsp+0x60]
000079035dddc306  vmovaps xmm7, [rsp+0x70]
000079035dddc30c  vmovaps xmm8, [rsp+0x80]
000079035dddc315  vmovaps xmm9, [rsp+0x90]
000079035dddc31e  vmovaps xmm10, [rsp+0xA0]
000079035dddc327  vmovaps xmm11, [rsp+0xB0]
000079035dddc330  vmovaps xmm12, [rsp+0xC0]
000079035dddc339  vmovaps xmm13, [rsp+0xD0]
000079035dddc342  vmovaps xmm14, [rsp+0xE0]
000079035dddc34b  add rsp, 0xF0
000079035dddc352  pop r11
000079035dddc354  pop r10
000079035dddc356  pop r9
000079035dddc358  pop r8
000079035dddc35a  pop rsi
000079035dddc35b  pop rdi
000079035dddc35c  pop rdx
000079035dddc35d  pop rcx
000079035dddc35e  pop rax
000079035dddc35f  add rsp, 0x08
000079035dddc363  jmp 0x000079035DDD93BC
000079035dddc368  sub rsp, 0x08
000079035dddc36c  push rax
000079035dddc36d  push rcx
000079035dddc36e  push rdx
000079035dddc36f  push rdi
000079035dddc370  push rsi
000079035dddc371  push r8
000079035dddc373  push r9
000079035dddc375  push r10
000079035dddc377  push r11
000079035dddc379  sub rsp, 0xF0
000079035dddc380  vmovaps [rsp], xmm0
000079035dddc385  vmovaps [rsp+0x10], xmm1
000079035dddc38b  vmovaps [rsp+0x20], xmm2
000079035dddc391  vmovaps [rsp+0x30], xmm3
000079035dddc397  vmovaps [rsp+0x40], xmm4
000079035dddc39d  vmovaps [rsp+0x50], xmm6
000079035dddc3a3  vmovaps [rsp+0x60], xmm7
000079035dddc3a9  vmovaps [rsp+0x70], xmm8
000079035dddc3af  vmovaps [rsp+0x80], xmm9
000079035dddc3b8  vmovaps [rsp+0x90], xmm10
000079035dddc3c1  vmovaps [rsp+0xA0], xmm11
000079035dddc3ca  vmovaps [rsp+0xB0], xmm12
000079035dddc3d3  vmovaps [rsp+0xC0], xmm13
000079035dddc3dc  vmovaps [rsp+0xD0], xmm14
000079035dddc3e5  vmovaps [rsp+0xE0], xmm15
000079035dddc3ee  sub rsp, 0x30
000079035dddc3f2  movaps [rsp], xmm5
000079035dddc3f6  movaps [rsp+0x10], xmm8
000079035dddc3fc  movaps [rsp+0x20], xmm6
000079035dddc401  lea rdi, [rsp]
000079035dddc405  mov esi, 0x00
000079035dddc40a  mov rax, 0x64ACAA8B0530
000079035dddc414  call rax
000079035dddc416  movaps xmm5, [rsp]
000079035dddc41a  add rsp, 0x30
000079035dddc41e  vmovaps xmm0, [rsp]
000079035dddc423  vmovaps xmm1, [rsp+0x10]
000079035dddc429  vmovaps xmm2, [rsp+0x20]
000079035dddc42f  vmovaps xmm3, [rsp+0x30]
000079035dddc435  vmovaps xmm4, [rsp+0x40]
000079035dddc43b  vmovaps xmm6, [rsp+0x50]
000079035dddc441  vmovaps xmm7, [rsp+0x60]
000079035dddc447  vmovaps xmm8, [rsp+0x70]
000079035dddc44d  vmovaps xmm9, [rsp+0x80]
000079035dddc456  vmovaps xmm10, [rsp+0x90]
000079035dddc45f  vmovaps xmm11, [rsp+0xA0]
000079035dddc468  vmovaps xmm12, [rsp+0xB0]
000079035dddc471  vmovaps xmm13, [rsp+0xC0]
000079035dddc47a  vmovaps xmm14, [rsp+0xD0]
000079035dddc483  vmovaps xmm15, [rsp+0xE0]
000079035dddc48c  add rsp, 0xF0
000079035dddc493  pop r11
000079035dddc495  pop r10
000079035dddc497  pop r9
000079035dddc499  pop r8
000079035dddc49b  pop rsi
000079035dddc49c  pop rdi
000079035dddc49d  pop rdx
000079035dddc49e  pop rcx
000079035dddc49f  pop rax
000079035dddc4a0  add rsp, 0x08
000079035dddc4a4  jmp 0x000079035DDD93E0
000079035dddc4a9  sub rsp, 0x08
000079035dddc4ad  push rax
000079035dddc4ae  push rcx
000079035dddc4af  push rdx
000079035dddc4b0  push rdi
000079035dddc4b1  push rsi
000079035dddc4b2  push r8
000079035dddc4b4  push r9
000079035dddc4b6  push r10
000079035dddc4b8  push r11
000079035dddc4ba  sub rsp, 0xF0
000079035dddc4c1  vmovaps [rsp], xmm0
000079035dddc4c6  vmovaps [rsp+0x10], xmm1
000079035dddc4cc  vmovaps [rsp+0x20], xmm2
000079035dddc4d2  vmovaps [rsp+0x30], xmm3
000079035dddc4d8  vmovaps [rsp+0x40], xmm4
000079035dddc4de  vmovaps [rsp+0x50], xmm5
000079035dddc4e4  vmovaps [rsp+0x60], xmm7
000079035dddc4ea  vmovaps [rsp+0x70], xmm8
000079035dddc4f0  vmovaps [rsp+0x80], xmm9
000079035dddc4f9  vmovaps [rsp+0x90], xmm10
000079035dddc502  vmovaps [rsp+0xA0], xmm11
000079035dddc50b  vmovaps [rsp+0xB0], xmm12
000079035dddc514  vmovaps [rsp+0xC0], xmm13
000079035dddc51d  vmovaps [rsp+0xD0], xmm14
000079035dddc526  vmovaps [rsp+0xE0], xmm15
000079035dddc52f  sub rsp, 0x30
000079035dddc533  movaps [rsp], xmm6
000079035dddc537  movaps [rsp+0x10], xmm10
000079035dddc53d  movaps [rsp+0x20], xmm8
000079035dddc543  lea rdi, [rsp]
000079035dddc547  mov esi, 0x00
000079035dddc54c  mov rax, 0x64ACAA8B0530
000079035dddc556  call rax
000079035dddc558  movaps xmm6, [rsp]
000079035dddc55c  add rsp, 0x30
000079035dddc560  vmovaps xmm0, [rsp]
000079035dddc565  vmovaps xmm1, [rsp+0x10]
000079035dddc56b  vmovaps xmm2, [rsp+0x20]
000079035dddc571  vmovaps xmm3, [rsp+0x30]
000079035dddc577  vmovaps xmm4, [rsp+0x40]
000079035dddc57d  vmovaps xmm5, [rsp+0x50]
000079035dddc583  vmovaps xmm7, [rsp+0x60]
000079035dddc589  vmovaps xmm8, [rsp+0x70]
000079035dddc58f  vmovaps xmm9, [rsp+0x80]
000079035dddc598  vmovaps xmm10, [rsp+0x90]
000079035dddc5a1  vmovaps xmm11, [rsp+0xA0]
000079035dddc5aa  vmovaps xmm12, [rsp+0xB0]
000079035dddc5b3  vmovaps xmm13, [rsp+0xC0]
000079035dddc5bc  vmovaps xmm14, [rsp+0xD0]
000079035dddc5c5  vmovaps xmm15, [rsp+0xE0]
000079035dddc5ce  add rsp, 0xF0
000079035dddc5d5  pop r11
000079035dddc5d7  pop r10
000079035dddc5d9  pop r9
000079035dddc5db  pop r8
000079035dddc5dd  pop rsi
000079035dddc5de  pop rdi
000079035dddc5df  pop rdx
000079035dddc5e0  pop rcx
000079035dddc5e1  pop rax
000079035dddc5e2  add rsp, 0x08
000079035dddc5e6  jmp 0x000079035DDD9405
000079035dddc5eb  sub rsp, 0x08
000079035dddc5ef  push rax
000079035dddc5f0  push rcx
000079035dddc5f1  push rdx
000079035dddc5f2  push rdi
000079035dddc5f3  push rsi
000079035dddc5f4  push r8
000079035dddc5f6  push r9
000079035dddc5f8  push r10
000079035dddc5fa  push r11
000079035dddc5fc  sub rsp, 0xF0
000079035dddc603  vmovaps [rsp], xmm0
000079035dddc608  vmovaps [rsp+0x10], xmm1
000079035dddc60e  vmovaps [rsp+0x20], xmm2
000079035dddc614  vmovaps [rsp+0x30], xmm3
000079035dddc61a  vmovaps [rsp+0x40], xmm4
000079035dddc620  vmovaps [rsp+0x50], xmm5
000079035dddc626  vmovaps [rsp+0x60], xmm6
000079035dddc62c  vmovaps [rsp+0x70], xmm7
000079035dddc632  vmovaps [rsp+0x80], xmm8
000079035dddc63b  vmovaps [rsp+0x90], xmm9
000079035dddc644  vmovaps [rsp+0xA0], xmm11
000079035dddc64d  vmovaps [rsp+0xB0], xmm12
000079035dddc656  vmovaps [rsp+0xC0], xmm13
000079035dddc65f  vmovaps [rsp+0xD0], xmm14
000079035dddc668  vmovaps [rsp+0xE0], xmm15
000079035dddc671  sub rsp, 0x30
000079035dddc675  movaps [rsp], xmm10
000079035dddc67a  movaps [rsp+0x10], xmm8
000079035dddc680  movaps [rsp+0x20], xmm14
000079035dddc686  lea rdi, [rsp]
000079035dddc68a  mov esi, 0x00
000079035dddc68f  mov rax, 0x64ACAA8B0530
000079035dddc699  call rax
000079035dddc69b  movaps xmm10, [rsp]
000079035dddc6a0  add rsp, 0x30
000079035dddc6a4  vmovaps xmm0, [rsp]
000079035dddc6a9  vmovaps xmm1, [rsp+0x10]
000079035dddc6af  vmovaps xmm2, [rsp+0x20]
000079035dddc6b5  vmovaps xmm3, [rsp+0x30]
000079035dddc6bb  vmovaps xmm4, [rsp+0x40]
000079035dddc6c1  vmovaps xmm5, [rsp+0x50]
000079035dddc6c7  vmovaps xmm6, [rsp+0x60]
000079035dddc6cd  vmovaps xmm7, [rsp+0x70]
000079035dddc6d3  vmovaps xmm8, [rsp+0x80]
000079035dddc6dc  vmovaps xmm9, [rsp+0x90]
000079035dddc6e5  vmovaps xmm11, [rsp+0xA0]
000079035dddc6ee  vmovaps xmm12, [rsp+0xB0]
000079035dddc6f7  vmovaps xmm13, [rsp+0xC0]
000079035dddc700  vmovaps xmm14, [rsp+0xD0]
000079035dddc709  vmovaps xmm15, [rsp+0xE0]
000079035dddc712  add rsp, 0xF0
000079035dddc719  pop r11
000079035dddc71b  pop r10
000079035dddc71d  pop r9
000079035dddc71f  pop r8
000079035dddc721  pop rsi
000079035dddc722  pop rdi
000079035dddc723  pop rdx
000079035dddc724  pop rcx
000079035dddc725  pop rax
000079035dddc726  add rsp, 0x08
000079035dddc72a  jmp 0x000079035DDD9425
000079035dddc72f  sub rsp, 0x08
000079035dddc733  push rax
000079035dddc734  push rcx
000079035dddc735  push rdx
000079035dddc736  push rdi
000079035dddc737  push rsi
000079035dddc738  push r8
000079035dddc73a  push r9
000079035dddc73c  push r10
000079035dddc73e  push r11
000079035dddc740  sub rsp, 0xF0
000079035dddc747  vmovaps [rsp], xmm0
000079035dddc74c  vmovaps [rsp+0x10], xmm1
000079035dddc752  vmovaps [rsp+0x20], xmm2
000079035dddc758  vmovaps [rsp+0x30], xmm3
000079035dddc75e  vmovaps [rsp+0x40], xmm4
000079035dddc764  vmovaps [rsp+0x50], xmm5
000079035dddc76a  vmovaps [rsp+0x60], xmm6
000079035dddc770  vmovaps [rsp+0x70], xmm7
000079035dddc776  vmovaps [rsp+0x80], xmm8
000079035dddc77f  vmovaps [rsp+0x90], xmm9
000079035dddc788  vmovaps [rsp+0xA0], xmm10
000079035dddc791  vmovaps [rsp+0xB0], xmm11
000079035dddc79a  vmovaps [rsp+0xC0], xmm12
000079035dddc7a3  vmovaps [rsp+0xD0], xmm13
000079035dddc7ac  vmovaps [rsp+0xE0], xmm15
000079035dddc7b5  sub rsp, 0x30
000079035dddc7b9  movaps [rsp], xmm14
000079035dddc7be  movaps [rsp+0x10], xmm8
000079035dddc7c4  movaps [rsp+0x20], xmm4
000079035dddc7c9  lea rdi, [rsp]
000079035dddc7cd  mov esi, 0x00
000079035dddc7d2  mov rax, 0x64ACAA8B0530
000079035dddc7dc  call rax
000079035dddc7de  movaps xmm14, [rsp]
000079035dddc7e3  add rsp, 0x30
000079035dddc7e7  vmovaps xmm0, [rsp]
000079035dddc7ec  vmovaps xmm1, [rsp+0x10]
000079035dddc7f2  vmovaps xmm2, [rsp+0x20]
000079035dddc7f8  vmovaps xmm3, [rsp+0x30]
000079035dddc7fe  vmovaps xmm4, [rsp+0x40]
000079035dddc804  vmovaps xmm5, [rsp+0x50]
000079035dddc80a  vmovaps xmm6, [rsp+0x60]
000079035dddc810  vmovaps xmm7, [rsp+0x70]
000079035dddc816  vmovaps xmm8, [rsp+0x80]
000079035dddc81f  vmovaps xmm9, [rsp+0x90]
000079035dddc828  vmovaps xmm10, [rsp+0xA0]
000079035dddc831  vmovaps xmm11, [rsp+0xB0]
000079035dddc83a  vmovaps xmm12, [rsp+0xC0]
000079035dddc843  vmovaps xmm13, [rsp+0xD0]
000079035dddc84c  vmovaps xmm15, [rsp+0xE0]
000079035dddc855  add rsp, 0xF0
000079035dddc85c  pop r11
000079035dddc85e  pop r10
000079035dddc860  pop r9
000079035dddc862  pop r8
000079035dddc864  pop rsi
000079035dddc865  pop rdi
000079035dddc866  pop rdx
000079035dddc867  pop rcx
000079035dddc868  pop rax
000079035dddc869  add rsp, 0x08
000079035dddc86d  jmp 0x000079035DDD9445
000079035dddc872  sub rsp, 0x08
000079035dddc876  push rax
000079035dddc877  push rcx
000079035dddc878  push rdx
000079035dddc879  push rdi
000079035dddc87a  push rsi
000079035dddc87b  push r8
000079035dddc87d  push r9
000079035dddc87f  push r10
000079035dddc881  push r11
000079035dddc883  sub rsp, 0xF0
000079035dddc88a  vmovaps [rsp], xmm0
000079035dddc88f  vmovaps [rsp+0x10], xmm1
000079035dddc895  vmovaps [rsp+0x20], xmm2
000079035dddc89b  vmovaps [rsp+0x30], xmm3
000079035dddc8a1  vmovaps [rsp+0x40], xmm5
000079035dddc8a7  vmovaps [rsp+0x50], xmm6
000079035dddc8ad  vmovaps [rsp+0x60], xmm7
000079035dddc8b3  vmovaps [rsp+0x70], xmm8
000079035dddc8b9  vmovaps [rsp+0x80], xmm9
000079035dddc8c2  vmovaps [rsp+0x90], xmm10
000079035dddc8cb  vmovaps [rsp+0xA0], xmm11
000079035dddc8d4  vmovaps [rsp+0xB0], xmm12
000079035dddc8dd  vmovaps [rsp+0xC0], xmm13
000079035dddc8e6  vmovaps [rsp+0xD0], xmm14
000079035dddc8ef  vmovaps [rsp+0xE0], xmm15
000079035dddc8f8  sub rsp, 0x30
000079035dddc8fc  movaps [rsp], xmm4
000079035dddc900  movaps [rsp+0x10], xmm13
000079035dddc906  movaps [rsp+0x20], xmm8
000079035dddc90c  lea rdi, [rsp]
000079035dddc910  mov esi, 0x00
000079035dddc915  mov rax, 0x64ACAA8B0530
000079035dddc91f  call rax
000079035dddc921  movaps xmm4, [rsp]
000079035dddc925  add rsp, 0x30
000079035dddc929  vmovaps xmm0, [rsp]
000079035dddc92e  vmovaps xmm1, [rsp+0x10]
000079035dddc934  vmovaps xmm2, [rsp+0x20]
000079035dddc93a  vmovaps xmm3, [rsp+0x30]
000079035dddc940  vmovaps xmm5, [rsp+0x40]
000079035dddc946  vmovaps xmm6, [rsp+0x50]
000079035dddc94c  vmovaps xmm7, [rsp+0x60]
000079035dddc952  vmovaps xmm8, [rsp+0x70]
000079035dddc958  vmovaps xmm9, [rsp+0x80]
000079035dddc961  vmovaps xmm10, [rsp+0x90]
000079035dddc96a  vmovaps xmm11, [rsp+0xA0]
000079035dddc973  vmovaps xmm12, [rsp+0xB0]
000079035dddc97c  vmovaps xmm13, [rsp+0xC0]
000079035dddc985  vmovaps xmm14, [rsp+0xD0]
000079035dddc98e  vmovaps xmm15, [rsp+0xE0]
000079035dddc997  add rsp, 0xF0
000079035dddc99e  pop r11
000079035dddc9a0  pop r10
000079035dddc9a2  pop r9
000079035dddc9a4  pop r8
000079035dddc9a6  pop rsi
000079035dddc9a7  pop rdi
000079035dddc9a8  pop rdx
000079035dddc9a9  pop rcx
000079035dddc9aa  pop rax
000079035dddc9ab  add rsp, 0x08
000079035dddc9af  jmp 0x000079035DDD946A
000079035dddc9b4  sub rsp, 0x08
000079035dddc9b8  push rax
000079035dddc9b9  push rcx
000079035dddc9ba  push rdx
000079035dddc9bb  push rdi
000079035dddc9bc  push rsi
000079035dddc9bd  push r8
000079035dddc9bf  push r9
000079035dddc9c1  push r10
000079035dddc9c3  push r11
000079035dddc9c5  sub rsp, 0xF0
000079035dddc9cc  vmovaps [rsp], xmm0
000079035dddc9d1  vmovaps [rsp+0x10], xmm1
000079035dddc9d7  vmovaps [rsp+0x20], xmm2
000079035dddc9dd  vmovaps [rsp+0x30], xmm3
000079035dddc9e3  vmovaps [rsp+0x40], xmm4
000079035dddc9e9  vmovaps [rsp+0x50], xmm5
000079035dddc9ef  vmovaps [rsp+0x60], xmm6
000079035dddc9f5  vmovaps [rsp+0x70], xmm7
000079035dddc9fb  vmovaps [rsp+0x80], xmm8
000079035dddca04  vmovaps [rsp+0x90], xmm9
000079035dddca0d  vmovaps [rsp+0xA0], xmm10
000079035dddca16  vmovaps [rsp+0xB0], xmm11
000079035dddca1f  vmovaps [rsp+0xC0], xmm12
000079035dddca28  vmovaps [rsp+0xD0], xmm14
000079035dddca31  vmovaps [rsp+0xE0], xmm15
000079035dddca3a  sub rsp, 0x30
000079035dddca3e  movaps [rsp], xmm13
000079035dddca43  movaps [rsp+0x10], xmm15
000079035dddca49  movaps [rsp+0x20], xmm9
000079035dddca4f  lea rdi, [rsp]
000079035dddca53  mov esi, 0x00
000079035dddca58  mov rax, 0x64ACAA8B0530
000079035dddca62  call rax
000079035dddca64  movaps xmm13, [rsp]
000079035dddca69  add rsp, 0x30
000079035dddca6d  vmovaps xmm0, [rsp]
000079035dddca72  vmovaps xmm1, [rsp+0x10]
000079035dddca78  vmovaps xmm2, [rsp+0x20]
000079035dddca7e  vmovaps xmm3, [rsp+0x30]
000079035dddca84  vmovaps xmm4, [rsp+0x40]
000079035dddca8a  vmovaps xmm5, [rsp+0x50]
000079035dddca90  vmovaps xmm6, [rsp+0x60]
000079035dddca96  vmovaps xmm7, [rsp+0x70]
000079035dddca9c  vmovaps xmm8, [rsp+0x80]
000079035dddcaa5  vmovaps xmm9, [rsp+0x90]
000079035dddcaae  vmovaps xmm10, [rsp+0xA0]
000079035dddcab7  vmovaps xmm11, [rsp+0xB0]
000079035dddcac0  vmovaps xmm12, [rsp+0xC0]
000079035dddcac9  vmovaps xmm14, [rsp+0xD0]
000079035dddcad2  vmovaps xmm15, [rsp+0xE0]
000079035dddcadb  add rsp, 0xF0
000079035dddcae2  pop r11
000079035dddcae4  pop r10
000079035dddcae6  pop r9
000079035dddcae8  pop r8
000079035dddcaea  pop rsi
000079035dddcaeb  pop rdi
000079035dddcaec  pop rdx
000079035dddcaed  pop rcx
000079035dddcaee  pop rax
000079035dddcaef  add rsp, 0x08
000079035dddcaf3  jmp 0x000079035DDD9485
000079035dddcaf8  sub rsp, 0x08
000079035dddcafc  push rax
000079035dddcafd  push rcx
000079035dddcafe  push rdx
000079035dddcaff  push rdi
000079035dddcb00  push rsi
000079035dddcb01  push r8
000079035dddcb03  push r9
000079035dddcb05  push r10
000079035dddcb07  push r11
000079035dddcb09  sub rsp, 0xF0
000079035dddcb10  vmovaps [rsp], xmm0
000079035dddcb15  vmovaps [rsp+0x10], xmm1
000079035dddcb1b  vmovaps [rsp+0x20], xmm2
000079035dddcb21  vmovaps [rsp+0x30], xmm3
000079035dddcb27  vmovaps [rsp+0x40], xmm4
000079035dddcb2d  vmovaps [rsp+0x50], xmm5
000079035dddcb33  vmovaps [rsp+0x60], xmm6
000079035dddcb39  vmovaps [rsp+0x70], xmm7
000079035dddcb3f  vmovaps [rsp+0x80], xmm8
000079035dddcb48  vmovaps [rsp+0x90], xmm9
000079035dddcb51  vmovaps [rsp+0xA0], xmm10
000079035dddcb5a  vmovaps [rsp+0xB0], xmm11
000079035dddcb63  vmovaps [rsp+0xC0], xmm12
000079035dddcb6c  vmovaps [rsp+0xD0], xmm13
000079035dddcb75  vmovaps [rsp+0xE0], xmm14
000079035dddcb7e  sub rsp, 0x30
000079035dddcb82  movaps [rsp], xmm15
000079035dddcb87  movaps [rsp+0x10], xmm1
000079035dddcb8c  movaps [rsp+0x20], xmm5
000079035dddcb91  lea rdi, [rsp]
000079035dddcb95  mov esi, 0x00
000079035dddcb9a  mov rax, 0x64ACAA8B0530
000079035dddcba4  call rax
000079035dddcba6  movaps xmm15, [rsp]
000079035dddcbab  add rsp, 0x30
000079035dddcbaf  vmovaps xmm0, [rsp]
000079035dddcbb4  vmovaps xmm1, [rsp+0x10]
000079035dddcbba  vmovaps xmm2, [rsp+0x20]
000079035dddcbc0  vmovaps xmm3, [rsp+0x30]
000079035dddcbc6  vmovaps xmm4, [rsp+0x40]
000079035dddcbcc  vmovaps xmm5, [rsp+0x50]
000079035dddcbd2  vmovaps xmm6, [rsp+0x60]
000079035dddcbd8  vmovaps xmm7, [rsp+0x70]
000079035dddcbde  vmovaps xmm8, [rsp+0x80]
000079035dddcbe7  vmovaps xmm9, [rsp+0x90]
000079035dddcbf0  vmovaps xmm10, [rsp+0xA0]
000079035dddcbf9  vmovaps xmm11, [rsp+0xB0]
000079035dddcc02  vmovaps xmm12, [rsp+0xC0]
000079035dddcc0b  vmovaps xmm13, [rsp+0xD0]
000079035dddcc14  vmovaps xmm14, [rsp+0xE0]
000079035dddcc1d  add rsp, 0xF0
000079035dddcc24  pop r11
000079035dddcc26  pop r10
000079035dddcc28  pop r9
000079035dddcc2a  pop r8
000079035dddcc2c  pop rsi
000079035dddcc2d  pop rdi
000079035dddcc2e  pop rdx
000079035dddcc2f  pop rcx
000079035dddcc30  pop rax
000079035dddcc31  add rsp, 0x08
000079035dddcc35  jmp 0x000079035DDD94A0
000079035dddcc3a  call 0x000079035DCD64F0
000079035dddcc3f  jmp 0x000079035DDD94FB
000079035dddcc44  sub rsp, 0x08
000079035dddcc48  push rax
000079035dddcc49  push rcx
000079035dddcc4a  push rdx
000079035dddcc4b  push rdi
000079035dddcc4c  push rsi
000079035dddcc4d  push r8
000079035dddcc4f  push r9
000079035dddcc51  push r10
000079035dddcc53  push r11
000079035dddcc55  sub rsp, 0xF0
000079035dddcc5c  vmovaps [rsp], xmm0
000079035dddcc61  vmovaps [rsp+0x10], xmm1
000079035dddcc67  vmovaps [rsp+0x20], xmm2
000079035dddcc6d  vmovaps [rsp+0x30], xmm3
000079035dddcc73  vmovaps [rsp+0x40], xmm4
000079035dddcc79  vmovaps [rsp+0x50], xmm5
000079035dddcc7f  vmovaps [rsp+0x60], xmm6
000079035dddcc85  vmovaps [rsp+0x70], xmm7
000079035dddcc8b  vmovaps [rsp+0x80], xmm8
000079035dddcc94  vmovaps [rsp+0x90], xmm10
000079035dddcc9d  vmovaps [rsp+0xA0], xmm11
000079035dddcca6  vmovaps [rsp+0xB0], xmm12
000079035dddccaf  vmovaps [rsp+0xC0], xmm13
000079035dddccb8  vmovaps [rsp+0xD0], xmm14
000079035dddccc1  vmovaps [rsp+0xE0], xmm15
000079035dddccca  sub rsp, 0x30
000079035dddccce  movaps [rsp], xmm9
000079035dddccd3  movaps [rsp+0x10], xmm8
000079035dddccd9  movaps [rsp+0x20], xmm11
000079035dddccdf  lea rdi, [rsp]
000079035dddcce3  mov esi, 0x00
000079035dddcce8  mov rax, 0x64ACAA8B0530
000079035dddccf2  call rax
000079035dddccf4  movaps xmm9, [rsp]
000079035dddccf9  add rsp, 0x30
000079035dddccfd  vmovaps xmm0, [rsp]
000079035dddcd02  vmovaps xmm1, [rsp+0x10]
000079035dddcd08  vmovaps xmm2, [rsp+0x20]
000079035dddcd0e  vmovaps xmm3, [rsp+0x30]
000079035dddcd14  vmovaps xmm4, [rsp+0x40]
000079035dddcd1a  vmovaps xmm5, [rsp+0x50]
000079035dddcd20  vmovaps xmm6, [rsp+0x60]
000079035dddcd26  vmovaps xmm7, [rsp+0x70]
000079035dddcd2c  vmovaps xmm8, [rsp+0x80]
000079035dddcd35  vmovaps xmm10, [rsp+0x90]
000079035dddcd3e  vmovaps xmm11, [rsp+0xA0]
000079035dddcd47  vmovaps xmm12, [rsp+0xB0]
000079035dddcd50  vmovaps xmm13, [rsp+0xC0]
000079035dddcd59  vmovaps xmm14, [rsp+0xD0]
000079035dddcd62  vmovaps xmm15, [rsp+0xE0]
000079035dddcd6b  add rsp, 0xF0
000079035dddcd72  pop r11
000079035dddcd74  pop r10
000079035dddcd76  pop r9
000079035dddcd78  pop r8
000079035dddcd7a  pop rsi
000079035dddcd7b  pop rdi
000079035dddcd7c  pop rdx
000079035dddcd7d  pop rcx
000079035dddcd7e  pop rax
000079035dddcd7f  add rsp, 0x08
000079035dddcd83  jmp 0x000079035DDD9532
000079035dddcd88  sub rsp, 0x08
000079035dddcd8c  push rax
000079035dddcd8d  push rcx
000079035dddcd8e  push rdx
000079035dddcd8f  push rdi
000079035dddcd90  push rsi
000079035dddcd91  push r8
000079035dddcd93  push r9
000079035dddcd95  push r10
000079035dddcd97  push r11
000079035dddcd99  sub rsp, 0xF0
000079035dddcda0  vmovaps [rsp], xmm0
000079035dddcda5  vmovaps [rsp+0x10], xmm1
000079035dddcdab  vmovaps [rsp+0x20], xmm2
000079035dddcdb1  vmovaps [rsp+0x30], xmm3
000079035dddcdb7  vmovaps [rsp+0x40], xmm4
000079035dddcdbd  vmovaps [rsp+0x50], xmm5
000079035dddcdc3  vmovaps [rsp+0x60], xmm6
000079035dddcdc9  vmovaps [rsp+0x70], xmm7
000079035dddcdcf  vmovaps [rsp+0x80], xmm8
000079035dddcdd8  vmovaps [rsp+0x90], xmm9
000079035dddcde1  vmovaps [rsp+0xA0], xmm10
000079035dddcdea  vmovaps [rsp+0xB0], xmm12
000079035dddcdf3  vmovaps [rsp+0xC0], xmm13
000079035dddcdfc  vmovaps [rsp+0xD0], xmm14
000079035dddce05  vmovaps [rsp+0xE0], xmm15
000079035dddce0e  sub rsp, 0x30
000079035dddce12  movaps [rsp], xmm11
000079035dddce17  movaps [rsp+0x10], xmm10
000079035dddce1d  movaps [rsp+0x20], xmm6
000079035dddce22  lea rdi, [rsp]
000079035dddce26  mov esi, 0x00
000079035dddce2b  mov rax, 0x64ACAA8B0530
000079035dddce35  call rax
000079035dddce37  movaps xmm11, [rsp]
000079035dddce3c  add rsp, 0x30
000079035dddce40  vmovaps xmm0, [rsp]
000079035dddce45  vmovaps xmm1, [rsp+0x10]
000079035dddce4b  vmovaps xmm2, [rsp+0x20]
000079035dddce51  vmovaps xmm3, [rsp+0x30]
000079035dddce57  vmovaps xmm4, [rsp+0x40]
000079035dddce5d  vmovaps xmm5, [rsp+0x50]
000079035dddce63  vmovaps xmm6, [rsp+0x60]
000079035dddce69  vmovaps xmm7, [rsp+0x70]
000079035dddce6f  vmovaps xmm8, [rsp+0x80]
000079035dddce78  vmovaps xmm9, [rsp+0x90]
000079035dddce81  vmovaps xmm10, [rsp+0xA0]
000079035dddce8a  vmovaps xmm12, [rsp+0xB0]
000079035dddce93  vmovaps xmm13, [rsp+0xC0]
000079035dddce9c  vmovaps xmm14, [rsp+0xD0]
000079035dddcea5  vmovaps xmm15, [rsp+0xE0]
000079035dddceae  add rsp, 0xF0
000079035dddceb5  pop r11
000079035dddceb7  pop r10
000079035dddceb9  pop r9
000079035dddcebb  pop r8
000079035dddcebd  pop rsi
000079035dddcebe  pop rdi
000079035dddcebf  pop rdx
000079035dddcec0  pop rcx
000079035dddcec1  pop rax
000079035dddcec2  add rsp, 0x08
000079035dddcec6  jmp 0x000079035DDD954D
000079035dddcecb  sub rsp, 0x08
000079035dddcecf  push rax
000079035dddced0  push rcx
000079035dddced1  push rdx
000079035dddced2  push rdi
000079035dddced3  push rsi
000079035dddced4  push r8
000079035dddced6  push r9
000079035dddced8  push r10
000079035dddceda  push r11
000079035dddcedc  sub rsp, 0xF0
000079035dddcee3  vmovaps [rsp], xmm0
000079035dddcee8  vmovaps [rsp+0x10], xmm1
000079035dddceee  vmovaps [rsp+0x20], xmm2
000079035dddcef4  vmovaps [rsp+0x30], xmm3
000079035dddcefa  vmovaps [rsp+0x40], xmm4
000079035dddcf00  vmovaps [rsp+0x50], xmm5
000079035dddcf06  vmovaps [rsp+0x60], xmm6
000079035dddcf0c  vmovaps [rsp+0x70], xmm7
000079035dddcf12  vmovaps [rsp+0x80], xmm8
000079035dddcf1b  vmovaps [rsp+0x90], xmm9
000079035dddcf24  vmovaps [rsp+0xA0], xmm11
000079035dddcf2d  vmovaps [rsp+0xB0], xmm12
000079035dddcf36  vmovaps [rsp+0xC0], xmm13
000079035dddcf3f  vmovaps [rsp+0xD0], xmm14
000079035dddcf48  vmovaps [rsp+0xE0], xmm15
000079035dddcf51  sub rsp, 0x30
000079035dddcf55  movaps [rsp], xmm10
000079035dddcf5a  movaps [rsp+0x10], xmm14
000079035dddcf60  movaps [rsp+0x20], xmm4
000079035dddcf65  lea rdi, [rsp]
000079035dddcf69  mov esi, 0x00
000079035dddcf6e  mov rax, 0x64ACAA8B0530
000079035dddcf78  call rax
000079035dddcf7a  movaps xmm10, [rsp]
000079035dddcf7f  add rsp, 0x30
000079035dddcf83  vmovaps xmm0, [rsp]
000079035dddcf88  vmovaps xmm1, [rsp+0x10]
000079035dddcf8e  vmovaps xmm2, [rsp+0x20]
000079035dddcf94  vmovaps xmm3, [rsp+0x30]
000079035dddcf9a  vmovaps xmm4, [rsp+0x40]
000079035dddcfa0  vmovaps xmm5, [rsp+0x50]
000079035dddcfa6  vmovaps xmm6, [rsp+0x60]
000079035dddcfac  vmovaps xmm7, [rsp+0x70]
000079035dddcfb2  vmovaps xmm8, [rsp+0x80]
000079035dddcfbb  vmovaps xmm9, [rsp+0x90]
000079035dddcfc4  vmovaps xmm11, [rsp+0xA0]
000079035dddcfcd  vmovaps xmm12, [rsp+0xB0]
000079035dddcfd6  vmovaps xmm13, [rsp+0xC0]
000079035dddcfdf  vmovaps xmm14, [rsp+0xD0]
000079035dddcfe8  vmovaps xmm15, [rsp+0xE0]
000079035dddcff1  add rsp, 0xF0
000079035dddcff8  pop r11
000079035dddcffa  pop r10
000079035dddcffc  pop r9
000079035dddcffe  pop r8
000079035dddd000  pop rsi
000079035dddd001  pop rdi
000079035dddd002  pop rdx
000079035dddd003  pop rcx
000079035dddd004  pop rax
000079035dddd005  add rsp, 0x08
000079035dddd009  jmp 0x000079035DDD9568
000079035dddd00e  sub rsp, 0x08
000079035dddd012  push rax
000079035dddd013  push rcx
000079035dddd014  push rdx
000079035dddd015  push rdi
000079035dddd016  push rsi
000079035dddd017  push r8
000079035dddd019  push r9
000079035dddd01b  push r10
000079035dddd01d  push r11
000079035dddd01f  sub rsp, 0xF0
000079035dddd026  vmovaps [rsp], xmm0
000079035dddd02b  vmovaps [rsp+0x10], xmm1
000079035dddd031  vmovaps [rsp+0x20], xmm2
000079035dddd037  vmovaps [rsp+0x30], xmm3
000079035dddd03d  vmovaps [rsp+0x40], xmm4
000079035dddd043  vmovaps [rsp+0x50], xmm5
000079035dddd049  vmovaps [rsp+0x60], xmm6
000079035dddd04f  vmovaps [rsp+0x70], xmm7
000079035dddd055  vmovaps [rsp+0x80], xmm9
000079035dddd05e  vmovaps [rsp+0x90], xmm10
000079035dddd067  vmovaps [rsp+0xA0], xmm11
000079035dddd070  vmovaps [rsp+0xB0], xmm12
000079035dddd079  vmovaps [rsp+0xC0], xmm13
000079035dddd082  vmovaps [rsp+0xD0], xmm14
000079035dddd08b  vmovaps [rsp+0xE0], xmm15
000079035dddd094  sub rsp, 0x30
000079035dddd098  movaps [rsp], xmm8
000079035dddd09d  movaps [rsp+0x10], xmm1
000079035dddd0a2  movaps [rsp+0x20], xmm14
000079035dddd0a8  lea rdi, [rsp]
000079035dddd0ac  mov esi, 0x00
000079035dddd0b1  mov rax, 0x64ACAA8B0530
000079035dddd0bb  call rax
000079035dddd0bd  movaps xmm8, [rsp]
000079035dddd0c2  add rsp, 0x30
000079035dddd0c6  vmovaps xmm0, [rsp]
000079035dddd0cb  vmovaps xmm1, [rsp+0x10]
000079035dddd0d1  vmovaps xmm2, [rsp+0x20]
000079035dddd0d7  vmovaps xmm3, [rsp+0x30]
000079035dddd0dd  vmovaps xmm4, [rsp+0x40]
000079035dddd0e3  vmovaps xmm5, [rsp+0x50]
000079035dddd0e9  vmovaps xmm6, [rsp+0x60]
000079035dddd0ef  vmovaps xmm7, [rsp+0x70]
000079035dddd0f5  vmovaps xmm9, [rsp+0x80]
000079035dddd0fe  vmovaps xmm10, [rsp+0x90]
000079035dddd107  vmovaps xmm11, [rsp+0xA0]
000079035dddd110  vmovaps xmm12, [rsp+0xB0]
000079035dddd119  vmovaps xmm13, [rsp+0xC0]
000079035dddd122  vmovaps xmm14, [rsp+0xD0]
000079035dddd12b  vmovaps xmm15, [rsp+0xE0]
000079035dddd134  add rsp, 0xF0
000079035dddd13b  pop r11
000079035dddd13d  pop r10
000079035dddd13f  pop r9
000079035dddd141  pop r8
000079035dddd143  pop rsi
000079035dddd144  pop rdi
000079035dddd145  pop rdx
000079035dddd146  pop rcx
000079035dddd147  pop rax
000079035dddd148  add rsp, 0x08
000079035dddd14c  jmp 0x000079035DDD958E
000079035dddd151  sub rsp, 0x08
000079035dddd155  push rax
000079035dddd156  push rcx
000079035dddd157  push rdx
000079035dddd158  push rdi
000079035dddd159  push rsi
000079035dddd15a  push r8
000079035dddd15c  push r9
000079035dddd15e  push r10
000079035dddd160  push r11
000079035dddd162  sub rsp, 0xF0
000079035dddd169  vmovaps [rsp], xmm0
000079035dddd16e  vmovaps [rsp+0x10], xmm1
000079035dddd174  vmovaps [rsp+0x20], xmm2
000079035dddd17a  vmovaps [rsp+0x30], xmm3
000079035dddd180  vmovaps [rsp+0x40], xmm4
000079035dddd186  vmovaps [rsp+0x50], xmm5
000079035dddd18c  vmovaps [rsp+0x60], xmm7
000079035dddd192  vmovaps [rsp+0x70], xmm8
000079035dddd198  vmovaps [rsp+0x80], xmm9
000079035dddd1a1  vmovaps [rsp+0x90], xmm10
000079035dddd1aa  vmovaps [rsp+0xA0], xmm11
000079035dddd1b3  vmovaps [rsp+0xB0], xmm12
000079035dddd1bc  vmovaps [rsp+0xC0], xmm13
000079035dddd1c5  vmovaps [rsp+0xD0], xmm14
000079035dddd1ce  vmovaps [rsp+0xE0], xmm15
000079035dddd1d7  sub rsp, 0x30
000079035dddd1db  movaps [rsp], xmm6
000079035dddd1df  movaps [rsp+0x10], xmm1
000079035dddd1e4  movaps [rsp+0x20], xmm14
000079035dddd1ea  lea rdi, [rsp]
000079035dddd1ee  mov esi, 0x00
000079035dddd1f3  mov rax, 0x64ACAA8B0530
000079035dddd1fd  call rax
000079035dddd1ff  movaps xmm6, [rsp]
000079035dddd203  add rsp, 0x30
000079035dddd207  vmovaps xmm0, [rsp]
000079035dddd20c  vmovaps xmm1, [rsp+0x10]
000079035dddd212  vmovaps xmm2, [rsp+0x20]
000079035dddd218  vmovaps xmm3, [rsp+0x30]
000079035dddd21e  vmovaps xmm4, [rsp+0x40]
000079035dddd224  vmovaps xmm5, [rsp+0x50]
000079035dddd22a  vmovaps xmm7, [rsp+0x60]
000079035dddd230  vmovaps xmm8, [rsp+0x70]
000079035dddd236  vmovaps xmm9, [rsp+0x80]
000079035dddd23f  vmovaps xmm10, [rsp+0x90]
000079035dddd248  vmovaps xmm11, [rsp+0xA0]
000079035dddd251  vmovaps xmm12, [rsp+0xB0]
000079035dddd25a  vmovaps xmm13, [rsp+0xC0]
000079035dddd263  vmovaps xmm14, [rsp+0xD0]
000079035dddd26c  vmovaps xmm15, [rsp+0xE0]
000079035dddd275  add rsp, 0xF0
000079035dddd27c  pop r11
000079035dddd27e  pop r10
000079035dddd280  pop r9
000079035dddd282  pop r8
000079035dddd284  pop rsi
000079035dddd285  pop rdi
000079035dddd286  pop rdx
000079035dddd287  pop rcx
000079035dddd288  pop rax
000079035dddd289  add rsp, 0x08
000079035dddd28d  jmp 0x000079035DDD95BA
000079035dddd292  sub rsp, 0x08
000079035dddd296  push rax
000079035dddd297  push rcx
000079035dddd298  push rdx
000079035dddd299  push rdi
000079035dddd29a  push rsi
000079035dddd29b  push r8
000079035dddd29d  push r9
000079035dddd29f  push r10
000079035dddd2a1  push r11
000079035dddd2a3  sub rsp, 0xF0
000079035dddd2aa  vmovaps [rsp], xmm0
000079035dddd2af  vmovaps [rsp+0x10], xmm1
000079035dddd2b5  vmovaps [rsp+0x20], xmm2
000079035dddd2bb  vmovaps [rsp+0x30], xmm3
000079035dddd2c1  vmovaps [rsp+0x40], xmm4
000079035dddd2c7  vmovaps [rsp+0x50], xmm5
000079035dddd2cd  vmovaps [rsp+0x60], xmm6
000079035dddd2d3  vmovaps [rsp+0x70], xmm7
000079035dddd2d9  vmovaps [rsp+0x80], xmm8
000079035dddd2e2  vmovaps [rsp+0x90], xmm9
000079035dddd2eb  vmovaps [rsp+0xA0], xmm10
000079035dddd2f4  vmovaps [rsp+0xB0], xmm11
000079035dddd2fd  vmovaps [rsp+0xC0], xmm12
000079035dddd306  vmovaps [rsp+0xD0], xmm13
000079035dddd30f  vmovaps [rsp+0xE0], xmm15
000079035dddd318  sub rsp, 0x30
000079035dddd31c  movaps [rsp], xmm14
000079035dddd321  movaps [rsp+0x10], xmm12
000079035dddd327  movaps [rsp+0x20], xmm1
000079035dddd32c  lea rdi, [rsp]
000079035dddd330  mov esi, 0x00
000079035dddd335  mov rax, 0x64ACAA8B0530
000079035dddd33f  call rax
000079035dddd341  movaps xmm14, [rsp]
000079035dddd346  add rsp, 0x30
000079035dddd34a  vmovaps xmm0, [rsp]
000079035dddd34f  vmovaps xmm1, [rsp+0x10]
000079035dddd355  vmovaps xmm2, [rsp+0x20]
000079035dddd35b  vmovaps xmm3, [rsp+0x30]
000079035dddd361  vmovaps xmm4, [rsp+0x40]
000079035dddd367  vmovaps xmm5, [rsp+0x50]
000079035dddd36d  vmovaps xmm6, [rsp+0x60]
000079035dddd373  vmovaps xmm7, [rsp+0x70]
000079035dddd379  vmovaps xmm8, [rsp+0x80]
000079035dddd382  vmovaps xmm9, [rsp+0x90]
000079035dddd38b  vmovaps xmm10, [rsp+0xA0]
000079035dddd394  vmovaps xmm11, [rsp+0xB0]
000079035dddd39d  vmovaps xmm12, [rsp+0xC0]
000079035dddd3a6  vmovaps xmm13, [rsp+0xD0]
000079035dddd3af  vmovaps xmm15, [rsp+0xE0]
000079035dddd3b8  add rsp, 0xF0
000079035dddd3bf  pop r11
000079035dddd3c1  pop r10
000079035dddd3c3  pop r9
000079035dddd3c5  pop r8
000079035dddd3c7  pop rsi
000079035dddd3c8  pop rdi
000079035dddd3c9  pop rdx
000079035dddd3ca  pop rcx
000079035dddd3cb  pop rax
000079035dddd3cc  add rsp, 0x08
000079035dddd3d0  jmp 0x000079035DDD95E0
000079035dddd3d5  sub rsp, 0x08
000079035dddd3d9  push rax
000079035dddd3da  push rcx
000079035dddd3db  push rdx
000079035dddd3dc  push rdi
000079035dddd3dd  push rsi
000079035dddd3de  push r8
000079035dddd3e0  push r9
000079035dddd3e2  push r10
000079035dddd3e4  push r11
000079035dddd3e6  sub rsp, 0xF0
000079035dddd3ed  vmovaps [rsp], xmm0
000079035dddd3f2  vmovaps [rsp+0x10], xmm2
000079035dddd3f8  vmovaps [rsp+0x20], xmm3
000079035dddd3fe  vmovaps [rsp+0x30], xmm4
000079035dddd404  vmovaps [rsp+0x40], xmm5
000079035dddd40a  vmovaps [rsp+0x50], xmm6
000079035dddd410  vmovaps [rsp+0x60], xmm7
000079035dddd416  vmovaps [rsp+0x70], xmm8
000079035dddd41c  vmovaps [rsp+0x80], xmm9
000079035dddd425  vmovaps [rsp+0x90], xmm10
000079035dddd42e  vmovaps [rsp+0xA0], xmm11
000079035dddd437  vmovaps [rsp+0xB0], xmm12
000079035dddd440  vmovaps [rsp+0xC0], xmm13
000079035dddd449  vmovaps [rsp+0xD0], xmm14
000079035dddd452  vmovaps [rsp+0xE0], xmm15
000079035dddd45b  sub rsp, 0x30
000079035dddd45f  movaps [rsp], xmm1
000079035dddd463  movaps [rsp+0x10], xmm13
000079035dddd469  movaps [rsp+0x20], xmm9
000079035dddd46f  lea rdi, [rsp]
000079035dddd473  mov esi, 0x00
000079035dddd478  mov rax, 0x64ACAA8B0530
000079035dddd482  call rax
000079035dddd484  movaps xmm1, [rsp]
000079035dddd488  add rsp, 0x30
000079035dddd48c  vmovaps xmm0, [rsp]
000079035dddd491  vmovaps xmm2, [rsp+0x10]
000079035dddd497  vmovaps xmm3, [rsp+0x20]
000079035dddd49d  vmovaps xmm4, [rsp+0x30]
000079035dddd4a3  vmovaps xmm5, [rsp+0x40]
000079035dddd4a9  vmovaps xmm6, [rsp+0x50]
000079035dddd4af  vmovaps xmm7, [rsp+0x60]
000079035dddd4b5  vmovaps xmm8, [rsp+0x70]
000079035dddd4bb  vmovaps xmm9, [rsp+0x80]
000079035dddd4c4  vmovaps xmm10, [rsp+0x90]
000079035dddd4cd  vmovaps xmm11, [rsp+0xA0]
000079035dddd4d6  vmovaps xmm12, [rsp+0xB0]
000079035dddd4df  vmovaps xmm13, [rsp+0xC0]
000079035dddd4e8  vmovaps xmm14, [rsp+0xD0]
000079035dddd4f1  vmovaps xmm15, [rsp+0xE0]
000079035dddd4fa  add rsp, 0xF0
000079035dddd501  pop r11
000079035dddd503  pop r10
000079035dddd505  pop r9
000079035dddd507  pop r8
000079035dddd509  pop rsi
000079035dddd50a  pop rdi
000079035dddd50b  pop rdx
000079035dddd50c  pop rcx
000079035dddd50d  pop rax
000079035dddd50e  add rsp, 0x08
000079035dddd512  jmp 0x000079035DDD95FA
000079035dddd517  sub rsp, 0x08
000079035dddd51b  push rax
000079035dddd51c  push rcx
000079035dddd51d  push rdx
000079035dddd51e  push rdi
000079035dddd51f  push rsi
000079035dddd520  push r8
000079035dddd522  push r9
000079035dddd524  push r10
000079035dddd526  push r11
000079035dddd528  sub rsp, 0xF0
000079035dddd52f  vmovaps [rsp], xmm0
000079035dddd534  vmovaps [rsp+0x10], xmm1
000079035dddd53a  vmovaps [rsp+0x20], xmm2
000079035dddd540  vmovaps [rsp+0x30], xmm3
000079035dddd546  vmovaps [rsp+0x40], xmm4
000079035dddd54c  vmovaps [rsp+0x50], xmm5
000079035dddd552  vmovaps [rsp+0x60], xmm6
000079035dddd558  vmovaps [rsp+0x70], xmm7
000079035dddd55e  vmovaps [rsp+0x80], xmm8
000079035dddd567  vmovaps [rsp+0x90], xmm9
000079035dddd570  vmovaps [rsp+0xA0], xmm10
000079035dddd579  vmovaps [rsp+0xB0], xmm11
000079035dddd582  vmovaps [rsp+0xC0], xmm13
000079035dddd58b  vmovaps [rsp+0xD0], xmm14
000079035dddd594  vmovaps [rsp+0xE0], xmm15
000079035dddd59d  sub rsp, 0x30
000079035dddd5a1  movaps [rsp], xmm12
000079035dddd5a6  movaps [rsp+0x10], xmm7
000079035dddd5ab  movaps [rsp+0x20], xmm13
000079035dddd5b1  lea rdi, [rsp]
000079035dddd5b5  mov esi, 0x00
000079035dddd5ba  mov rax, 0x64ACAA8B0530
000079035dddd5c4  call rax
000079035dddd5c6  movaps xmm12, [rsp]
000079035dddd5cb  add rsp, 0x30
000079035dddd5cf  vmovaps xmm0, [rsp]
000079035dddd5d4  vmovaps xmm1, [rsp+0x10]
000079035dddd5da  vmovaps xmm2, [rsp+0x20]
000079035dddd5e0  vmovaps xmm3, [rsp+0x30]
000079035dddd5e6  vmovaps xmm4, [rsp+0x40]
000079035dddd5ec  vmovaps xmm5, [rsp+0x50]
000079035dddd5f2  vmovaps xmm6, [rsp+0x60]
000079035dddd5f8  vmovaps xmm7, [rsp+0x70]
000079035dddd5fe  vmovaps xmm8, [rsp+0x80]
000079035dddd607  vmovaps xmm9, [rsp+0x90]
000079035dddd610  vmovaps xmm10, [rsp+0xA0]
000079035dddd619  vmovaps xmm11, [rsp+0xB0]
000079035dddd622  vmovaps xmm13, [rsp+0xC0]
000079035dddd62b  vmovaps xmm14, [rsp+0xD0]
000079035dddd634  vmovaps xmm15, [rsp+0xE0]
000079035dddd63d  add rsp, 0xF0
000079035dddd644  pop r11
000079035dddd646  pop r10
000079035dddd648  pop r9
000079035dddd64a  pop r8
000079035dddd64c  pop rsi
000079035dddd64d  pop rdi
000079035dddd64e  pop rdx
000079035dddd64f  pop rcx
000079035dddd650  pop rax
000079035dddd651  add rsp, 0x08
000079035dddd655  jmp 0x000079035DDD9621
000079035dddd65a  sub rsp, 0x08
000079035dddd65e  push rax
000079035dddd65f  push rcx
000079035dddd660  push rdx
000079035dddd661  push rdi
000079035dddd662  push rsi
000079035dddd663  push r8
000079035dddd665  push r9
000079035dddd667  push r10
000079035dddd669  push r11
000079035dddd66b  sub rsp, 0xF0
000079035dddd672  vmovaps [rsp], xmm0
000079035dddd677  vmovaps [rsp+0x10], xmm1
000079035dddd67d  vmovaps [rsp+0x20], xmm2
000079035dddd683  vmovaps [rsp+0x30], xmm3
000079035dddd689  vmovaps [rsp+0x40], xmm4
000079035dddd68f  vmovaps [rsp+0x50], xmm5
000079035dddd695  vmovaps [rsp+0x60], xmm6
000079035dddd69b  vmovaps [rsp+0x70], xmm7
000079035dddd6a1  vmovaps [rsp+0x80], xmm8
000079035dddd6aa  vmovaps [rsp+0x90], xmm9
000079035dddd6b3  vmovaps [rsp+0xA0], xmm10
000079035dddd6bc  vmovaps [rsp+0xB0], xmm11
000079035dddd6c5  vmovaps [rsp+0xC0], xmm12
000079035dddd6ce  vmovaps [rsp+0xD0], xmm14
000079035dddd6d7  vmovaps [rsp+0xE0], xmm15
000079035dddd6e0  sub rsp, 0x30
000079035dddd6e4  movaps [rsp], xmm13
000079035dddd6e9  movaps [rsp+0x10], xmm15
000079035dddd6ef  movaps [rsp+0x20], xmm8
000079035dddd6f5  lea rdi, [rsp]
000079035dddd6f9  mov esi, 0x00
000079035dddd6fe  mov rax, 0x64ACAA8B0530
000079035dddd708  call rax
000079035dddd70a  movaps xmm13, [rsp]
000079035dddd70f  add rsp, 0x30
000079035dddd713  vmovaps xmm0, [rsp]
000079035dddd718  vmovaps xmm1, [rsp+0x10]
000079035dddd71e  vmovaps xmm2, [rsp+0x20]
000079035dddd724  vmovaps xmm3, [rsp+0x30]
000079035dddd72a  vmovaps xmm4, [rsp+0x40]
000079035dddd730  vmovaps xmm5, [rsp+0x50]
000079035dddd736  vmovaps xmm6, [rsp+0x60]
000079035dddd73c  vmovaps xmm7, [rsp+0x70]
000079035dddd742  vmovaps xmm8, [rsp+0x80]
000079035dddd74b  vmovaps xmm9, [rsp+0x90]
000079035dddd754  vmovaps xmm10, [rsp+0xA0]
000079035dddd75d  vmovaps xmm11, [rsp+0xB0]
000079035dddd766  vmovaps xmm12, [rsp+0xC0]
000079035dddd76f  vmovaps xmm14, [rsp+0xD0]
000079035dddd778  vmovaps xmm15, [rsp+0xE0]
000079035dddd781  add rsp, 0xF0
000079035dddd788  pop r11
000079035dddd78a  pop r10
000079035dddd78c  pop r9
000079035dddd78e  pop r8
000079035dddd790  pop rsi
000079035dddd791  pop rdi
000079035dddd792  pop rdx
000079035dddd793  pop rcx
000079035dddd794  pop rax
000079035dddd795  add rsp, 0x08
000079035dddd799  jmp 0x000079035DDD963C
000079035dddd79e  sub rsp, 0x08
000079035dddd7a2  push rax
000079035dddd7a3  push rcx
000079035dddd7a4  push rdx
000079035dddd7a5  push rdi
000079035dddd7a6  push rsi
000079035dddd7a7  push r8
000079035dddd7a9  push r9
000079035dddd7ab  push r10
000079035dddd7ad  push r11
000079035dddd7af  sub rsp, 0xF0
000079035dddd7b6  vmovaps [rsp], xmm0
000079035dddd7bb  vmovaps [rsp+0x10], xmm1
000079035dddd7c1  vmovaps [rsp+0x20], xmm2
000079035dddd7c7  vmovaps [rsp+0x30], xmm3
000079035dddd7cd  vmovaps [rsp+0x40], xmm4
000079035dddd7d3  vmovaps [rsp+0x50], xmm5
000079035dddd7d9  vmovaps [rsp+0x60], xmm6
000079035dddd7df  vmovaps [rsp+0x70], xmm7
000079035dddd7e5  vmovaps [rsp+0x80], xmm9
000079035dddd7ee  vmovaps [rsp+0x90], xmm10
000079035dddd7f7  vmovaps [rsp+0xA0], xmm11
000079035dddd800  vmovaps [rsp+0xB0], xmm12
000079035dddd809  vmovaps [rsp+0xC0], xmm13
000079035dddd812  vmovaps [rsp+0xD0], xmm14
000079035dddd81b  vmovaps [rsp+0xE0], xmm15
000079035dddd824  sub rsp, 0x30
000079035dddd828  movaps [rsp], xmm8
000079035dddd82d  movaps [rsp+0x10], xmm15
000079035dddd833  movaps [rsp+0x20], xmm9
000079035dddd839  lea rdi, [rsp]
000079035dddd83d  mov esi, 0x00
000079035dddd842  mov rax, 0x64ACAA8B0530
000079035dddd84c  call rax
000079035dddd84e  movaps xmm8, [rsp]
000079035dddd853  add rsp, 0x30
000079035dddd857  vmovaps xmm0, [rsp]
000079035dddd85c  vmovaps xmm1, [rsp+0x10]
000079035dddd862  vmovaps xmm2, [rsp+0x20]
000079035dddd868  vmovaps xmm3, [rsp+0x30]
000079035dddd86e  vmovaps xmm4, [rsp+0x40]
000079035dddd874  vmovaps xmm5, [rsp+0x50]
000079035dddd87a  vmovaps xmm6, [rsp+0x60]
000079035dddd880  vmovaps xmm7, [rsp+0x70]
000079035dddd886  vmovaps xmm9, [rsp+0x80]
000079035dddd88f  vmovaps xmm10, [rsp+0x90]
000079035dddd898  vmovaps xmm11, [rsp+0xA0]
000079035dddd8a1  vmovaps xmm12, [rsp+0xB0]
000079035dddd8aa  vmovaps xmm13, [rsp+0xC0]
000079035dddd8b3  vmovaps xmm14, [rsp+0xD0]
000079035dddd8bc  vmovaps xmm15, [rsp+0xE0]
000079035dddd8c5  add rsp, 0xF0
000079035dddd8cc  pop r11
000079035dddd8ce  pop r10
000079035dddd8d0  pop r9
000079035dddd8d2  pop r8
000079035dddd8d4  pop rsi
000079035dddd8d5  pop rdi
000079035dddd8d6  pop rdx
000079035dddd8d7  pop rcx
000079035dddd8d8  pop rax
000079035dddd8d9  add rsp, 0x08
000079035dddd8dd  jmp 0x000079035DDD966A
000079035dddd8e2  sub rsp, 0x08
000079035dddd8e6  push rax
000079035dddd8e7  push rcx
000079035dddd8e8  push rdx
000079035dddd8e9  push rdi
000079035dddd8ea  push rsi
000079035dddd8eb  push r8
000079035dddd8ed  push r9
000079035dddd8ef  push r10
000079035dddd8f1  push r11
000079035dddd8f3  sub rsp, 0xF0
000079035dddd8fa  vmovaps [rsp], xmm0
000079035dddd8ff  vmovaps [rsp+0x10], xmm1
000079035dddd905  vmovaps [rsp+0x20], xmm2
000079035dddd90b  vmovaps [rsp+0x30], xmm3
000079035dddd911  vmovaps [rsp+0x40], xmm4
000079035dddd917  vmovaps [rsp+0x50], xmm5
000079035dddd91d  vmovaps [rsp+0x60], xmm6
000079035dddd923  vmovaps [rsp+0x70], xmm7
000079035dddd929  vmovaps [rsp+0x80], xmm8
000079035dddd932  vmovaps [rsp+0x90], xmm9
000079035dddd93b  vmovaps [rsp+0xA0], xmm10
000079035dddd944  vmovaps [rsp+0xB0], xmm11
000079035dddd94d  vmovaps [rsp+0xC0], xmm12
000079035dddd956  vmovaps [rsp+0xD0], xmm13
000079035dddd95f  vmovaps [rsp+0xE0], xmm14
000079035dddd968  sub rsp, 0x30
000079035dddd96c  movaps [rsp], xmm15
000079035dddd971  movaps [rsp+0x10], xmm11
000079035dddd977  movaps [rsp+0x20], xmm6
000079035dddd97c  lea rdi, [rsp]
000079035dddd980  mov esi, 0x00
000079035dddd985  mov rax, 0x64ACAA8B0530
000079035dddd98f  call rax
000079035dddd991  movaps xmm15, [rsp]
000079035dddd996  add rsp, 0x30
000079035dddd99a  vmovaps xmm0, [rsp]
000079035dddd99f  vmovaps xmm1, [rsp+0x10]
000079035dddd9a5  vmovaps xmm2, [rsp+0x20]
000079035dddd9ab  vmovaps xmm3, [rsp+0x30]
000079035dddd9b1  vmovaps xmm4, [rsp+0x40]
000079035dddd9b7  vmovaps xmm5, [rsp+0x50]
000079035dddd9bd  vmovaps xmm6, [rsp+0x60]
000079035dddd9c3  vmovaps xmm7, [rsp+0x70]
000079035dddd9c9  vmovaps xmm8, [rsp+0x80]
000079035dddd9d2  vmovaps xmm9, [rsp+0x90]
000079035dddd9db  vmovaps xmm10, [rsp+0xA0]
000079035dddd9e4  vmovaps xmm11, [rsp+0xB0]
000079035dddd9ed  vmovaps xmm12, [rsp+0xC0]
000079035dddd9f6  vmovaps xmm13, [rsp+0xD0]
000079035dddd9ff  vmovaps xmm14, [rsp+0xE0]
000079035dddda08  add rsp, 0xF0
000079035dddda0f  pop r11
000079035dddda11  pop r10
000079035dddda13  pop r9
000079035dddda15  pop r8
000079035dddda17  pop rsi
000079035dddda18  pop rdi
000079035dddda19  pop rdx
000079035dddda1a  pop rcx
000079035dddda1b  pop rax
000079035dddda1c  add rsp, 0x08
000079035dddda20  jmp 0x000079035DDD9685
000079035dddda25  sub rsp, 0x08
000079035dddda29  push rax
000079035dddda2a  push rcx
000079035dddda2b  push rdx
000079035dddda2c  push rdi
000079035dddda2d  push rsi
000079035dddda2e  push r8
000079035dddda30  push r9
000079035dddda32  push r10
000079035dddda34  push r11
000079035dddda36  sub rsp, 0xF0
000079035dddda3d  vmovaps [rsp], xmm0
000079035dddda42  vmovaps [rsp+0x10], xmm1
000079035dddda48  vmovaps [rsp+0x20], xmm2
000079035dddda4e  vmovaps [rsp+0x30], xmm3
000079035dddda54  vmovaps [rsp+0x40], xmm4
000079035dddda5a  vmovaps [rsp+0x50], xmm5
000079035dddda60  vmovaps [rsp+0x60], xmm6
000079035dddda66  vmovaps [rsp+0x70], xmm8
000079035dddda6c  vmovaps [rsp+0x80], xmm9
000079035dddda75  vmovaps [rsp+0x90], xmm10
000079035dddda7e  vmovaps [rsp+0xA0], xmm11
000079035dddda87  vmovaps [rsp+0xB0], xmm12
000079035dddda90  vmovaps [rsp+0xC0], xmm13
000079035dddda99  vmovaps [rsp+0xD0], xmm14
000079035ddddaa2  vmovaps [rsp+0xE0], xmm15
000079035ddddaab  sub rsp, 0x30
000079035ddddaaf  movaps [rsp], xmm7
000079035ddddab3  movaps [rsp+0x10], xmm11
000079035ddddab9  movaps [rsp+0x20], xmm9
000079035ddddabf  lea rdi, [rsp]
000079035ddddac3  mov esi, 0x00
000079035ddddac8  mov rax, 0x64ACAA8B0530
000079035ddddad2  call rax
000079035ddddad4  movaps xmm7, [rsp]
000079035ddddad8  add rsp, 0x30
000079035ddddadc  vmovaps xmm0, [rsp]
000079035ddddae1  vmovaps xmm1, [rsp+0x10]
000079035ddddae7  vmovaps xmm2, [rsp+0x20]
000079035ddddaed  vmovaps xmm3, [rsp+0x30]
000079035ddddaf3  vmovaps xmm4, [rsp+0x40]
000079035ddddaf9  vmovaps xmm5, [rsp+0x50]
000079035ddddaff  vmovaps xmm6, [rsp+0x60]
000079035ddddb05  vmovaps xmm8, [rsp+0x70]
000079035ddddb0b  vmovaps xmm9, [rsp+0x80]
000079035ddddb14  vmovaps xmm10, [rsp+0x90]
000079035ddddb1d  vmovaps xmm11, [rsp+0xA0]
000079035ddddb26  vmovaps xmm12, [rsp+0xB0]
000079035ddddb2f  vmovaps xmm13, [rsp+0xC0]
000079035ddddb38  vmovaps xmm14, [rsp+0xD0]
000079035ddddb41  vmovaps xmm15, [rsp+0xE0]
000079035ddddb4a  add rsp, 0xF0
000079035ddddb51  pop r11
000079035ddddb53  pop r10
000079035ddddb55  pop r9
000079035ddddb57  pop r8
000079035ddddb59  pop rsi
000079035ddddb5a  pop rdi
000079035ddddb5b  pop rdx
000079035ddddb5c  pop rcx
000079035ddddb5d  pop rax
000079035ddddb5e  add rsp, 0x08
000079035ddddb62  jmp 0x000079035DDD96B2
000079035ddddb67  sub rsp, 0x08
000079035ddddb6b  push rax
000079035ddddb6c  push rcx
000079035ddddb6d  push rdx
000079035ddddb6e  push rdi
000079035ddddb6f  push rsi
000079035ddddb70  push r8
000079035ddddb72  push r9
000079035ddddb74  push r10
000079035ddddb76  push r11
000079035ddddb78  sub rsp, 0xF0
000079035ddddb7f  vmovaps [rsp], xmm0
000079035ddddb84  vmovaps [rsp+0x10], xmm1
000079035ddddb8a  vmovaps [rsp+0x20], xmm2
000079035ddddb90  vmovaps [rsp+0x30], xmm3
000079035ddddb96  vmovaps [rsp+0x40], xmm4
000079035ddddb9c  vmovaps [rsp+0x50], xmm5
000079035ddddba2  vmovaps [rsp+0x60], xmm6
000079035ddddba8  vmovaps [rsp+0x70], xmm7
000079035ddddbae  vmovaps [rsp+0x80], xmm8
000079035ddddbb7  vmovaps [rsp+0x90], xmm9
000079035ddddbc0  vmovaps [rsp+0xA0], xmm10
000079035ddddbc9  vmovaps [rsp+0xB0], xmm12
000079035ddddbd2  vmovaps [rsp+0xC0], xmm13
000079035ddddbdb  vmovaps [rsp+0xD0], xmm14
000079035ddddbe4  vmovaps [rsp+0xE0], xmm15
000079035ddddbed  sub rsp, 0x30
000079035ddddbf1  movaps [rsp], xmm11
000079035ddddbf6  movaps [rsp+0x10], xmm10
000079035ddddbfc  movaps [rsp+0x20], xmm14
000079035ddddc02  lea rdi, [rsp]
000079035ddddc06  mov esi, 0x00
000079035ddddc0b  mov rax, 0x64ACAA8B0530
000079035ddddc15  call rax
000079035ddddc17  movaps xmm11, [rsp]
000079035ddddc1c  add rsp, 0x30
000079035ddddc20  vmovaps xmm0, [rsp]
000079035ddddc25  vmovaps xmm1, [rsp+0x10]
000079035ddddc2b  vmovaps xmm2, [rsp+0x20]
000079035ddddc31  vmovaps xmm3, [rsp+0x30]
000079035ddddc37  vmovaps xmm4, [rsp+0x40]
000079035ddddc3d  vmovaps xmm5, [rsp+0x50]
000079035ddddc43  vmovaps xmm6, [rsp+0x60]
000079035ddddc49  vmovaps xmm7, [rsp+0x70]
000079035ddddc4f  vmovaps xmm8, [rsp+0x80]
000079035ddddc58  vmovaps xmm9, [rsp+0x90]
000079035ddddc61  vmovaps xmm10, [rsp+0xA0]
000079035ddddc6a  vmovaps xmm12, [rsp+0xB0]
000079035ddddc73  vmovaps xmm13, [rsp+0xC0]
000079035ddddc7c  vmovaps xmm14, [rsp+0xD0]
000079035ddddc85  vmovaps xmm15, [rsp+0xE0]
000079035ddddc8e  add rsp, 0xF0
000079035ddddc95  pop r11
000079035ddddc97  pop r10
000079035ddddc99  pop r9
000079035ddddc9b  pop r8
000079035ddddc9d  pop rsi
000079035ddddc9e  pop rdi
000079035ddddc9f  pop rdx
000079035ddddca0  pop rcx
000079035ddddca1  pop rax
000079035ddddca2  add rsp, 0x08
000079035ddddca6  jmp 0x000079035DDD96CD
000079035ddddcab  call 0x000079035DCE45A0
000079035ddddcb0  jmp 0x000079035DDD96D7
000079035ddddcb5  sub rsp, 0x08
000079035ddddcb9  push rax
000079035ddddcba  push rcx
000079035ddddcbb  push rdx
000079035ddddcbc  push rdi
000079035ddddcbd  push rsi
000079035ddddcbe  push r8
000079035ddddcc0  push r9
000079035ddddcc2  push r10
000079035ddddcc4  push r11
000079035ddddcc6  sub rsp, 0xF0
000079035ddddccd  vmovaps [rsp], xmm0
000079035ddddcd2  vmovaps [rsp+0x10], xmm1
000079035ddddcd8  vmovaps [rsp+0x20], xmm2
000079035ddddcde  vmovaps [rsp+0x30], xmm3
000079035ddddce4  vmovaps [rsp+0x40], xmm4
000079035ddddcea  vmovaps [rsp+0x50], xmm5
000079035ddddcf0  vmovaps [rsp+0x60], xmm6
000079035ddddcf6  vmovaps [rsp+0x70], xmm7
000079035ddddcfc  vmovaps [rsp+0x80], xmm8
000079035ddddd05  vmovaps [rsp+0x90], xmm9
000079035ddddd0e  vmovaps [rsp+0xA0], xmm11
000079035ddddd17  vmovaps [rsp+0xB0], xmm12
000079035ddddd20  vmovaps [rsp+0xC0], xmm13
000079035ddddd29  vmovaps [rsp+0xD0], xmm14
000079035ddddd32  vmovaps [rsp+0xE0], xmm15
000079035ddddd3b  sub rsp, 0x30
000079035ddddd3f  movaps [rsp], xmm10
000079035ddddd44  movaps [rsp+0x10], xmm1
000079035ddddd49  movaps [rsp+0x20], xmm12
000079035ddddd4f  lea rdi, [rsp]
000079035ddddd53  mov esi, 0x00
000079035ddddd58  mov rax, 0x64ACAA8B0530
000079035ddddd62  call rax
000079035ddddd64  movaps xmm10, [rsp]
000079035ddddd69  add rsp, 0x30
000079035ddddd6d  vmovaps xmm0, [rsp]
000079035ddddd72  vmovaps xmm1, [rsp+0x10]
000079035ddddd78  vmovaps xmm2, [rsp+0x20]
000079035ddddd7e  vmovaps xmm3, [rsp+0x30]
000079035ddddd84  vmovaps xmm4, [rsp+0x40]
000079035ddddd8a  vmovaps xmm5, [rsp+0x50]
000079035ddddd90  vmovaps xmm6, [rsp+0x60]
000079035ddddd96  vmovaps xmm7, [rsp+0x70]
000079035ddddd9c  vmovaps xmm8, [rsp+0x80]
000079035ddddda5  vmovaps xmm9, [rsp+0x90]
000079035dddddae  vmovaps xmm11, [rsp+0xA0]
000079035dddddb7  vmovaps xmm12, [rsp+0xB0]
000079035dddddc0  vmovaps xmm13, [rsp+0xC0]
000079035dddddc9  vmovaps xmm14, [rsp+0xD0]
000079035dddddd2  vmovaps xmm15, [rsp+0xE0]
000079035ddddddb  add rsp, 0xF0
000079035ddddde2  pop r11
000079035ddddde4  pop r10
000079035ddddde6  pop r9
000079035ddddde8  pop r8
000079035dddddea  pop rsi
000079035dddddeb  pop rdi
000079035dddddec  pop rdx
000079035ddddded  pop rcx
000079035dddddee  pop rax
000079035dddddef  add rsp, 0x08
000079035dddddf3  jmp 0x000079035DDD96FA
000079035dddddf8  sub rsp, 0x08
000079035dddddfc  push rax
000079035dddddfd  push rcx
000079035dddddfe  push rdx
000079035dddddff  push rdi
000079035dddde00  push rsi
000079035dddde01  push r8
000079035dddde03  push r9
000079035dddde05  push r10
000079035dddde07  push r11
000079035dddde09  sub rsp, 0xF0
000079035dddde10  vmovaps [rsp], xmm0
000079035dddde15  vmovaps [rsp+0x10], xmm1
000079035dddde1b  vmovaps [rsp+0x20], xmm2
000079035dddde21  vmovaps [rsp+0x30], xmm3
000079035dddde27  vmovaps [rsp+0x40], xmm4
000079035dddde2d  vmovaps [rsp+0x50], xmm5
000079035dddde33  vmovaps [rsp+0x60], xmm6
000079035dddde39  vmovaps [rsp+0x70], xmm7
000079035dddde3f  vmovaps [rsp+0x80], xmm8
000079035dddde48  vmovaps [rsp+0x90], xmm9
000079035dddde51  vmovaps [rsp+0xA0], xmm10
000079035dddde5a  vmovaps [rsp+0xB0], xmm11
000079035dddde63  vmovaps [rsp+0xC0], xmm13
000079035dddde6c  vmovaps [rsp+0xD0], xmm14
000079035dddde75  vmovaps [rsp+0xE0], xmm15
000079035dddde7e  sub rsp, 0x30
000079035dddde82  movaps [rsp], xmm12
000079035dddde87  movaps [rsp+0x10], xmm14
000079035dddde8d  movaps [rsp+0x20], xmm1
000079035dddde92  lea rdi, [rsp]
000079035dddde96  mov esi, 0x00
000079035dddde9b  mov rax, 0x64ACAA8B0530
000079035ddddea5  call rax
000079035ddddea7  movaps xmm12, [rsp]
000079035ddddeac  add rsp, 0x30
000079035ddddeb0  vmovaps xmm0, [rsp]
000079035ddddeb5  vmovaps xmm1, [rsp+0x10]
000079035ddddebb  vmovaps xmm2, [rsp+0x20]
000079035ddddec1  vmovaps xmm3, [rsp+0x30]
000079035ddddec7  vmovaps xmm4, [rsp+0x40]
000079035ddddecd  vmovaps xmm5, [rsp+0x50]
000079035dddded3  vmovaps xmm6, [rsp+0x60]
000079035dddded9  vmovaps xmm7, [rsp+0x70]
000079035ddddedf  vmovaps xmm8, [rsp+0x80]
000079035ddddee8  vmovaps xmm9, [rsp+0x90]
000079035ddddef1  vmovaps xmm10, [rsp+0xA0]
000079035ddddefa  vmovaps xmm11, [rsp+0xB0]
000079035ddddf03  vmovaps xmm13, [rsp+0xC0]
000079035ddddf0c  vmovaps xmm14, [rsp+0xD0]
000079035ddddf15  vmovaps xmm15, [rsp+0xE0]
000079035ddddf1e  add rsp, 0xF0
000079035ddddf25  pop r11
000079035ddddf27  pop r10
000079035ddddf29  pop r9
000079035ddddf2b  pop r8
000079035ddddf2d  pop rsi
000079035ddddf2e  pop rdi
000079035ddddf2f  pop rdx
000079035ddddf30  pop rcx
000079035ddddf31  pop rax
000079035ddddf32  add rsp, 0x08
000079035ddddf36  jmp 0x000079035DDD9729
000079035ddddf3b  sub rsp, 0x08
000079035ddddf3f  push rax
000079035ddddf40  push rcx
000079035ddddf41  push rdx
000079035ddddf42  push rdi
000079035ddddf43  push rsi
000079035ddddf44  push r8
000079035ddddf46  push r9
000079035ddddf48  push r10
000079035ddddf4a  push r11
000079035ddddf4c  sub rsp, 0xF0
000079035ddddf53  vmovaps [rsp], xmm0
000079035ddddf58  vmovaps [rsp+0x10], xmm1
000079035ddddf5e  vmovaps [rsp+0x20], xmm2
000079035ddddf64  vmovaps [rsp+0x30], xmm3
000079035ddddf6a  vmovaps [rsp+0x40], xmm4
000079035ddddf70  vmovaps [rsp+0x50], xmm5
000079035ddddf76  vmovaps [rsp+0x60], xmm6
000079035ddddf7c  vmovaps [rsp+0x70], xmm7
000079035ddddf82  vmovaps [rsp+0x80], xmm8
000079035ddddf8b  vmovaps [rsp+0x90], xmm9
000079035ddddf94  vmovaps [rsp+0xA0], xmm10
000079035ddddf9d  vmovaps [rsp+0xB0], xmm11
000079035ddddfa6  vmovaps [rsp+0xC0], xmm12
000079035ddddfaf  vmovaps [rsp+0xD0], xmm13
000079035ddddfb8  vmovaps [rsp+0xE0], xmm15
000079035ddddfc1  sub rsp, 0x30
000079035ddddfc5  movaps [rsp], xmm14
000079035ddddfca  movaps [rsp+0x10], xmm9
000079035ddddfd0  movaps [rsp+0x20], xmm1
000079035ddddfd5  lea rdi, [rsp]
000079035ddddfd9  mov esi, 0x00
000079035ddddfde  mov rax, 0x64ACAA8B0530
000079035ddddfe8  call rax
000079035ddddfea  movaps xmm14, [rsp]
000079035ddddfef  add rsp, 0x30
000079035ddddff3  vmovaps xmm0, [rsp]
000079035ddddff8  vmovaps xmm1, [rsp+0x10]
000079035ddddffe  vmovaps xmm2, [rsp+0x20]
000079035ddde004  vmovaps xmm3, [rsp+0x30]
000079035ddde00a  vmovaps xmm4, [rsp+0x40]
000079035ddde010  vmovaps xmm5, [rsp+0x50]
000079035ddde016  vmovaps xmm6, [rsp+0x60]
000079035ddde01c  vmovaps xmm7, [rsp+0x70]
000079035ddde022  vmovaps xmm8, [rsp+0x80]
000079035ddde02b  vmovaps xmm9, [rsp+0x90]
000079035ddde034  vmovaps xmm10, [rsp+0xA0]
000079035ddde03d  vmovaps xmm11, [rsp+0xB0]
000079035ddde046  vmovaps xmm12, [rsp+0xC0]
000079035ddde04f  vmovaps xmm13, [rsp+0xD0]
000079035ddde058  vmovaps xmm15, [rsp+0xE0]
000079035ddde061  add rsp, 0xF0
000079035ddde068  pop r11
000079035ddde06a  pop r10
000079035ddde06c  pop r9
000079035ddde06e  pop r8
000079035ddde070  pop rsi
000079035ddde071  pop rdi
000079035ddde072  pop rdx
000079035ddde073  pop rcx
000079035ddde074  pop rax
000079035ddde075  add rsp, 0x08
000079035ddde079  jmp 0x000079035DDD9758
000079035ddde07e  sub rsp, 0x08
000079035ddde082  push rax
000079035ddde083  push rcx
000079035ddde084  push rdx
000079035ddde085  push rdi
000079035ddde086  push rsi
000079035ddde087  push r8
000079035ddde089  push r9
000079035ddde08b  push r10
000079035ddde08d  push r11
000079035ddde08f  sub rsp, 0xF0
000079035ddde096  vmovaps [rsp], xmm0
000079035ddde09b  vmovaps [rsp+0x10], xmm2
000079035ddde0a1  vmovaps [rsp+0x20], xmm3
000079035ddde0a7  vmovaps [rsp+0x30], xmm4
000079035ddde0ad  vmovaps [rsp+0x40], xmm5
000079035ddde0b3  vmovaps [rsp+0x50], xmm6
000079035ddde0b9  vmovaps [rsp+0x60], xmm7
000079035ddde0bf  vmovaps [rsp+0x70], xmm8
000079035ddde0c5  vmovaps [rsp+0x80], xmm9
000079035ddde0ce  vmovaps [rsp+0x90], xmm10
000079035ddde0d7  vmovaps [rsp+0xA0], xmm11
000079035ddde0e0  vmovaps [rsp+0xB0], xmm12
000079035ddde0e9  vmovaps [rsp+0xC0], xmm13
000079035ddde0f2  vmovaps [rsp+0xD0], xmm14
000079035ddde0fb  vmovaps [rsp+0xE0], xmm15
000079035ddde104  sub rsp, 0x30
000079035ddde108  movaps [rsp], xmm1
000079035ddde10c  movaps [rsp+0x10], xmm13
000079035ddde112  movaps [rsp+0x20], xmm8
000079035ddde118  lea rdi, [rsp]
000079035ddde11c  mov esi, 0x00
000079035ddde121  mov rax, 0x64ACAA8B0530
000079035ddde12b  call rax
000079035ddde12d  movaps xmm1, [rsp]
000079035ddde131  add rsp, 0x30
000079035ddde135  vmovaps xmm0, [rsp]
000079035ddde13a  vmovaps xmm2, [rsp+0x10]
000079035ddde140  vmovaps xmm3, [rsp+0x20]
000079035ddde146  vmovaps xmm4, [rsp+0x30]
000079035ddde14c  vmovaps xmm5, [rsp+0x40]
000079035ddde152  vmovaps xmm6, [rsp+0x50]
000079035ddde158  vmovaps xmm7, [rsp+0x60]
000079035ddde15e  vmovaps xmm8, [rsp+0x70]
000079035ddde164  vmovaps xmm9, [rsp+0x80]
000079035ddde16d  vmovaps xmm10, [rsp+0x90]
000079035ddde176  vmovaps xmm11, [rsp+0xA0]
000079035ddde17f  vmovaps xmm12, [rsp+0xB0]
000079035ddde188  vmovaps xmm13, [rsp+0xC0]
000079035ddde191  vmovaps xmm14, [rsp+0xD0]
000079035ddde19a  vmovaps xmm15, [rsp+0xE0]
000079035ddde1a3  add rsp, 0xF0
000079035ddde1aa  pop r11
000079035ddde1ac  pop r10
000079035ddde1ae  pop r9
000079035ddde1b0  pop r8
000079035ddde1b2  pop rsi
000079035ddde1b3  pop rdi
000079035ddde1b4  pop rdx
000079035ddde1b5  pop rcx
000079035ddde1b6  pop rax
000079035ddde1b7  add rsp, 0x08
000079035ddde1bb  jmp 0x000079035DDD977A
000079035ddde1c0  call 0x000079035DC0C260
000079035ddde1c5  jmp 0x000079035DDD9788
000079035ddde1ca  call 0x000079035DCDE950
000079035ddde1cf  jmp 0x000079035DDD9792
000079035ddde1d4  sub rsp, 0x08
000079035ddde1d8  push rax
000079035ddde1d9  push rcx
000079035ddde1da  push rdx
000079035ddde1db  push rdi
000079035ddde1dc  push rsi
000079035ddde1dd  push r8
000079035ddde1df  push r9
000079035ddde1e1  push r10
000079035ddde1e3  push r11
000079035ddde1e5  sub rsp, 0xF0
000079035ddde1ec  vmovaps [rsp], xmm0
000079035ddde1f1  vmovaps [rsp+0x10], xmm1
000079035ddde1f7  vmovaps [rsp+0x20], xmm2
000079035ddde1fd  vmovaps [rsp+0x30], xmm3
000079035ddde203  vmovaps [rsp+0x40], xmm4
000079035ddde209  vmovaps [rsp+0x50], xmm5
000079035ddde20f  vmovaps [rsp+0x60], xmm6
000079035ddde215  vmovaps [rsp+0x70], xmm7
000079035ddde21b  vmovaps [rsp+0x80], xmm9
000079035ddde224  vmovaps [rsp+0x90], xmm10
000079035ddde22d  vmovaps [rsp+0xA0], xmm11
000079035ddde236  vmovaps [rsp+0xB0], xmm12
000079035ddde23f  vmovaps [rsp+0xC0], xmm13
000079035ddde248  vmovaps [rsp+0xD0], xmm14
000079035ddde251  vmovaps [rsp+0xE0], xmm15
000079035ddde25a  sub rsp, 0x30
000079035ddde25e  movaps [rsp], xmm8
000079035ddde263  movaps [rsp+0x10], xmm15
000079035ddde269  movaps [rsp+0x20], xmm7
000079035ddde26e  lea rdi, [rsp]
000079035ddde272  mov esi, 0x00
000079035ddde277  mov rax, 0x64ACAA8B0530
000079035ddde281  call rax
000079035ddde283  movaps xmm8, [rsp]
000079035ddde288  add rsp, 0x30
000079035ddde28c  vmovaps xmm0, [rsp]
000079035ddde291  vmovaps xmm1, [rsp+0x10]
000079035ddde297  vmovaps xmm2, [rsp+0x20]
000079035ddde29d  vmovaps xmm3, [rsp+0x30]
000079035ddde2a3  vmovaps xmm4, [rsp+0x40]
000079035ddde2a9  vmovaps xmm5, [rsp+0x50]
000079035ddde2af  vmovaps xmm6, [rsp+0x60]
000079035ddde2b5  vmovaps xmm7, [rsp+0x70]
000079035ddde2bb  vmovaps xmm9, [rsp+0x80]
000079035ddde2c4  vmovaps xmm10, [rsp+0x90]
000079035ddde2cd  vmovaps xmm11, [rsp+0xA0]
000079035ddde2d6  vmovaps xmm12, [rsp+0xB0]
000079035ddde2df  vmovaps xmm13, [rsp+0xC0]
000079035ddde2e8  vmovaps xmm14, [rsp+0xD0]
000079035ddde2f1  vmovaps xmm15, [rsp+0xE0]
000079035ddde2fa  add rsp, 0xF0
000079035ddde301  pop r11
000079035ddde303  pop r10
000079035ddde305  pop r9
000079035ddde307  pop r8
000079035ddde309  pop rsi
000079035ddde30a  pop rdi
000079035ddde30b  pop rdx
000079035ddde30c  pop rcx
000079035ddde30d  pop rax
000079035ddde30e  add rsp, 0x08
000079035ddde312  jmp 0x000079035DDD97B4
000079035ddde317  sub rsp, 0x08
000079035ddde31b  push rax
000079035ddde31c  push rcx
000079035ddde31d  push rdx
000079035ddde31e  push rdi
000079035ddde31f  push rsi
000079035ddde320  push r8
000079035ddde322  push r9
000079035ddde324  push r10
000079035ddde326  push r11
000079035ddde328  sub rsp, 0xF0
000079035ddde32f  vmovaps [rsp], xmm0
000079035ddde334  vmovaps [rsp+0x10], xmm1
000079035ddde33a  vmovaps [rsp+0x20], xmm2
000079035ddde340  vmovaps [rsp+0x30], xmm3
000079035ddde346  vmovaps [rsp+0x40], xmm4
000079035ddde34c  vmovaps [rsp+0x50], xmm5
000079035ddde352  vmovaps [rsp+0x60], xmm6
000079035ddde358  vmovaps [rsp+0x70], xmm8
000079035ddde35e  vmovaps [rsp+0x80], xmm9
000079035ddde367  vmovaps [rsp+0x90], xmm10
000079035ddde370  vmovaps [rsp+0xA0], xmm11
000079035ddde379  vmovaps [rsp+0xB0], xmm12
000079035ddde382  vmovaps [rsp+0xC0], xmm13
000079035ddde38b  vmovaps [rsp+0xD0], xmm14
000079035ddde394  vmovaps [rsp+0xE0], xmm15
000079035ddde39d  sub rsp, 0x30
000079035ddde3a1  movaps [rsp], xmm7
000079035ddde3a5  movaps [rsp+0x10], xmm9
000079035ddde3ab  movaps [rsp+0x20], xmm15
000079035ddde3b1  lea rdi, [rsp]
000079035ddde3b5  mov esi, 0x00
000079035ddde3ba  mov rax, 0x64ACAA8B0530
000079035ddde3c4  call rax
000079035ddde3c6  movaps xmm7, [rsp]
000079035ddde3ca  add rsp, 0x30
000079035ddde3ce  vmovaps xmm0, [rsp]
000079035ddde3d3  vmovaps xmm1, [rsp+0x10]
000079035ddde3d9  vmovaps xmm2, [rsp+0x20]
000079035ddde3df  vmovaps xmm3, [rsp+0x30]
000079035ddde3e5  vmovaps xmm4, [rsp+0x40]
000079035ddde3eb  vmovaps xmm5, [rsp+0x50]
000079035ddde3f1  vmovaps xmm6, [rsp+0x60]
000079035ddde3f7  vmovaps xmm8, [rsp+0x70]
000079035ddde3fd  vmovaps xmm9, [rsp+0x80]
000079035ddde406  vmovaps xmm10, [rsp+0x90]
000079035ddde40f  vmovaps xmm11, [rsp+0xA0]
000079035ddde418  vmovaps xmm12, [rsp+0xB0]
000079035ddde421  vmovaps xmm13, [rsp+0xC0]
000079035ddde42a  vmovaps xmm14, [rsp+0xD0]
000079035ddde433  vmovaps xmm15, [rsp+0xE0]
000079035ddde43c  add rsp, 0xF0
000079035ddde443  pop r11
000079035ddde445  pop r10
000079035ddde447  pop r9
000079035ddde449  pop r8
000079035ddde44b  pop rsi
000079035ddde44c  pop rdi
000079035ddde44d  pop rdx
000079035ddde44e  pop rcx
000079035ddde44f  pop rax
000079035ddde450  add rsp, 0x08
000079035ddde454  jmp 0x000079035DDD97E1
000079035ddde459  sub rsp, 0x08
000079035ddde45d  push rax
000079035ddde45e  push rcx
000079035ddde45f  push rdx
000079035ddde460  push rdi
000079035ddde461  push rsi
000079035ddde462  push r8
000079035ddde464  push r9
000079035ddde466  push r10
000079035ddde468  push r11
000079035ddde46a  sub rsp, 0xF0
000079035ddde471  vmovaps [rsp], xmm0
000079035ddde476  vmovaps [rsp+0x10], xmm1
000079035ddde47c  vmovaps [rsp+0x20], xmm2
000079035ddde482  vmovaps [rsp+0x30], xmm3
000079035ddde488  vmovaps [rsp+0x40], xmm4
000079035ddde48e  vmovaps [rsp+0x50], xmm5
000079035ddde494  vmovaps [rsp+0x60], xmm6
000079035ddde49a  vmovaps [rsp+0x70], xmm7
000079035ddde4a0  vmovaps [rsp+0x80], xmm8
000079035ddde4a9  vmovaps [rsp+0x90], xmm10
000079035ddde4b2  vmovaps [rsp+0xA0], xmm11
000079035ddde4bb  vmovaps [rsp+0xB0], xmm12
000079035ddde4c4  vmovaps [rsp+0xC0], xmm13
000079035ddde4cd  vmovaps [rsp+0xD0], xmm14
000079035ddde4d6  vmovaps [rsp+0xE0], xmm15
000079035ddde4df  sub rsp, 0x30
000079035ddde4e3  movaps [rsp], xmm9
000079035ddde4e8  movaps [rsp+0x10], xmm13
000079035ddde4ee  movaps [rsp+0x20], xmm15
000079035ddde4f4  lea rdi, [rsp]
000079035ddde4f8  mov esi, 0x00
000079035ddde4fd  mov rax, 0x64ACAA8B0530
000079035ddde507  call rax
000079035ddde509  movaps xmm9, [rsp]
000079035ddde50e  add rsp, 0x30
000079035ddde512  vmovaps xmm0, [rsp]
000079035ddde517  vmovaps xmm1, [rsp+0x10]
000079035ddde51d  vmovaps xmm2, [rsp+0x20]
000079035ddde523  vmovaps xmm3, [rsp+0x30]
000079035ddde529  vmovaps xmm4, [rsp+0x40]
000079035ddde52f  vmovaps xmm5, [rsp+0x50]
000079035ddde535  vmovaps xmm6, [rsp+0x60]
000079035ddde53b  vmovaps xmm7, [rsp+0x70]
000079035ddde541  vmovaps xmm8, [rsp+0x80]
000079035ddde54a  vmovaps xmm10, [rsp+0x90]
000079035ddde553  vmovaps xmm11, [rsp+0xA0]
000079035ddde55c  vmovaps xmm12, [rsp+0xB0]
000079035ddde565  vmovaps xmm13, [rsp+0xC0]
000079035ddde56e  vmovaps xmm14, [rsp+0xD0]
000079035ddde577  vmovaps xmm15, [rsp+0xE0]
000079035ddde580  add rsp, 0xF0
000079035ddde587  pop r11
000079035ddde589  pop r10
000079035ddde58b  pop r9
000079035ddde58d  pop r8
000079035ddde58f  pop rsi
000079035ddde590  pop rdi
000079035ddde591  pop rdx
000079035ddde592  pop rcx
000079035ddde593  pop rax
000079035ddde594  add rsp, 0x08
000079035ddde598  jmp 0x000079035DDD980F
000079035ddde59d  sub rsp, 0x08
000079035ddde5a1  push rax
000079035ddde5a2  push rcx
000079035ddde5a3  push rdx
000079035ddde5a4  push rdi
000079035ddde5a5  push rsi
000079035ddde5a6  push r8
000079035ddde5a8  push r9
000079035ddde5aa  push r10
000079035ddde5ac  push r11
000079035ddde5ae  sub rsp, 0xF0
000079035ddde5b5  vmovaps [rsp], xmm0
000079035ddde5ba  vmovaps [rsp+0x10], xmm1
000079035ddde5c0  vmovaps [rsp+0x20], xmm2
000079035ddde5c6  vmovaps [rsp+0x30], xmm3
000079035ddde5cc  vmovaps [rsp+0x40], xmm4
000079035ddde5d2  vmovaps [rsp+0x50], xmm5
000079035ddde5d8  vmovaps [rsp+0x60], xmm6
000079035ddde5de  vmovaps [rsp+0x70], xmm7
000079035ddde5e4  vmovaps [rsp+0x80], xmm8
000079035ddde5ed  vmovaps [rsp+0x90], xmm9
000079035ddde5f6  vmovaps [rsp+0xA0], xmm10
000079035ddde5ff  vmovaps [rsp+0xB0], xmm11
000079035ddde608  vmovaps [rsp+0xC0], xmm12
000079035ddde611  vmovaps [rsp+0xD0], xmm13
000079035ddde61a  vmovaps [rsp+0xE0], xmm14
000079035ddde623  sub rsp, 0x30
000079035ddde627  movaps [rsp], xmm15
000079035ddde62c  movaps [rsp+0x10], xmm11
000079035ddde632  movaps [rsp+0x20], xmm12
000079035ddde638  lea rdi, [rsp]
000079035ddde63c  mov esi, 0x00
000079035ddde641  mov rax, 0x64ACAA8B0530
000079035ddde64b  call rax
000079035ddde64d  movaps xmm15, [rsp]
000079035ddde652  add rsp, 0x30
000079035ddde656  vmovaps xmm0, [rsp]
000079035ddde65b  vmovaps xmm1, [rsp+0x10]
000079035ddde661  vmovaps xmm2, [rsp+0x20]
000079035ddde667  vmovaps xmm3, [rsp+0x30]
000079035ddde66d  vmovaps xmm4, [rsp+0x40]
000079035ddde673  vmovaps xmm5, [rsp+0x50]
000079035ddde679  vmovaps xmm6, [rsp+0x60]
000079035ddde67f  vmovaps xmm7, [rsp+0x70]
000079035ddde685  vmovaps xmm8, [rsp+0x80]
000079035ddde68e  vmovaps xmm9, [rsp+0x90]
000079035ddde697  vmovaps xmm10, [rsp+0xA0]
000079035ddde6a0  vmovaps xmm11, [rsp+0xB0]
000079035ddde6a9  vmovaps xmm12, [rsp+0xC0]
000079035ddde6b2  vmovaps xmm13, [rsp+0xD0]
000079035ddde6bb  vmovaps xmm14, [rsp+0xE0]
000079035ddde6c4  add rsp, 0xF0
000079035ddde6cb  pop r11
000079035ddde6cd  pop r10
000079035ddde6cf  pop r9
000079035ddde6d1  pop r8
000079035ddde6d3  pop rsi
000079035ddde6d4  pop rdi
000079035ddde6d5  pop rdx
000079035ddde6d6  pop rcx
000079035ddde6d7  pop rax
000079035ddde6d8  add rsp, 0x08
000079035ddde6dc  jmp 0x000079035DDD982A
000079035ddde6e1  sub rsp, 0x08
000079035ddde6e5  push rax
000079035ddde6e6  push rcx
000079035ddde6e7  push rdx
000079035ddde6e8  push rdi
000079035ddde6e9  push rsi
000079035ddde6ea  push r8
000079035ddde6ec  push r9
000079035ddde6ee  push r10
000079035ddde6f0  push r11
000079035ddde6f2  sub rsp, 0xF0
000079035ddde6f9  vmovaps [rsp], xmm0
000079035ddde6fe  vmovaps [rsp+0x10], xmm1
000079035ddde704  vmovaps [rsp+0x20], xmm2
000079035ddde70a  vmovaps [rsp+0x30], xmm3
000079035ddde710  vmovaps [rsp+0x40], xmm4
000079035ddde716  vmovaps [rsp+0x50], xmm5
000079035ddde71c  vmovaps [rsp+0x60], xmm6
000079035ddde722  vmovaps [rsp+0x70], xmm7
000079035ddde728  vmovaps [rsp+0x80], xmm8
000079035ddde731  vmovaps [rsp+0x90], xmm9
000079035ddde73a  vmovaps [rsp+0xA0], xmm10
000079035ddde743  vmovaps [rsp+0xB0], xmm11
000079035ddde74c  vmovaps [rsp+0xC0], xmm12
000079035ddde755  vmovaps [rsp+0xD0], xmm14
000079035ddde75e  vmovaps [rsp+0xE0], xmm15
000079035ddde767  sub rsp, 0x30
000079035ddde76b  movaps [rsp], xmm13
000079035ddde770  movaps [rsp+0x10], xmm10
000079035ddde776  movaps [rsp+0x20], xmm14
000079035ddde77c  lea rdi, [rsp]
000079035ddde780  mov esi, 0x00
000079035ddde785  mov rax, 0x64ACAA8B0530
000079035ddde78f  call rax
000079035ddde791  movaps xmm13, [rsp]
000079035ddde796  add rsp, 0x30
000079035ddde79a  vmovaps xmm0, [rsp]
000079035ddde79f  vmovaps xmm1, [rsp+0x10]
000079035ddde7a5  vmovaps xmm2, [rsp+0x20]
000079035ddde7ab  vmovaps xmm3, [rsp+0x30]
000079035ddde7b1  vmovaps xmm4, [rsp+0x40]
000079035ddde7b7  vmovaps xmm5, [rsp+0x50]
000079035ddde7bd  vmovaps xmm6, [rsp+0x60]
000079035ddde7c3  vmovaps xmm7, [rsp+0x70]
000079035ddde7c9  vmovaps xmm8, [rsp+0x80]
000079035ddde7d2  vmovaps xmm9, [rsp+0x90]
000079035ddde7db  vmovaps xmm10, [rsp+0xA0]
000079035ddde7e4  vmovaps xmm11, [rsp+0xB0]
000079035ddde7ed  vmovaps xmm12, [rsp+0xC0]
000079035ddde7f6  vmovaps xmm14, [rsp+0xD0]
000079035ddde7ff  vmovaps xmm15, [rsp+0xE0]
000079035ddde808  add rsp, 0xF0
000079035ddde80f  pop r11
000079035ddde811  pop r10
000079035ddde813  pop r9
000079035ddde815  pop r8
000079035ddde817  pop rsi
000079035ddde818  pop rdi
000079035ddde819  pop rdx
000079035ddde81a  pop rcx
000079035ddde81b  pop rax
000079035ddde81c  add rsp, 0x08
000079035ddde820  jmp 0x000079035DDD984D
000079035ddde825  sub rsp, 0x08
000079035ddde829  push rax
000079035ddde82a  push rcx
000079035ddde82b  push rdx
000079035ddde82c  push rdi
000079035ddde82d  push rsi
000079035ddde82e  push r8
000079035ddde830  push r9
000079035ddde832  push r10
000079035ddde834  push r11
000079035ddde836  sub rsp, 0xF0
000079035ddde83d  vmovaps [rsp], xmm0
000079035ddde842  vmovaps [rsp+0x10], xmm1
000079035ddde848  vmovaps [rsp+0x20], xmm2
000079035ddde84e  vmovaps [rsp+0x30], xmm3
000079035ddde854  vmovaps [rsp+0x40], xmm4
000079035ddde85a  vmovaps [rsp+0x50], xmm5
000079035ddde860  vmovaps [rsp+0x60], xmm6
000079035ddde866  vmovaps [rsp+0x70], xmm7
000079035ddde86c  vmovaps [rsp+0x80], xmm8
000079035ddde875  vmovaps [rsp+0x90], xmm9
000079035ddde87e  vmovaps [rsp+0xA0], xmm10
000079035ddde887  vmovaps [rsp+0xB0], xmm11
000079035ddde890  vmovaps [rsp+0xC0], xmm12
000079035ddde899  vmovaps [rsp+0xD0], xmm13
000079035ddde8a2  vmovaps [rsp+0xE0], xmm15
000079035ddde8ab  sub rsp, 0x30
000079035ddde8af  movaps [rsp], xmm14
000079035ddde8b4  movaps [rsp+0x10], xmm1
000079035ddde8b9  movaps [rsp+0x20], xmm7
000079035ddde8be  lea rdi, [rsp]
000079035ddde8c2  mov esi, 0x00
000079035ddde8c7  mov rax, 0x64ACAA8B0530
000079035ddde8d1  call rax
000079035ddde8d3  movaps xmm14, [rsp]
000079035ddde8d8  add rsp, 0x30
000079035ddde8dc  vmovaps xmm0, [rsp]
000079035ddde8e1  vmovaps xmm1, [rsp+0x10]
000079035ddde8e7  vmovaps xmm2, [rsp+0x20]
000079035ddde8ed  vmovaps xmm3, [rsp+0x30]
000079035ddde8f3  vmovaps xmm4, [rsp+0x40]
000079035ddde8f9  vmovaps xmm5, [rsp+0x50]
000079035ddde8ff  vmovaps xmm6, [rsp+0x60]
000079035ddde905  vmovaps xmm7, [rsp+0x70]
000079035ddde90b  vmovaps xmm8, [rsp+0x80]
000079035ddde914  vmovaps xmm9, [rsp+0x90]
000079035ddde91d  vmovaps xmm10, [rsp+0xA0]
000079035ddde926  vmovaps xmm11, [rsp+0xB0]
000079035ddde92f  vmovaps xmm12, [rsp+0xC0]
000079035ddde938  vmovaps xmm13, [rsp+0xD0]
000079035ddde941  vmovaps xmm15, [rsp+0xE0]
000079035ddde94a  add rsp, 0xF0
000079035ddde951  pop r11
000079035ddde953  pop r10
000079035ddde955  pop r9
000079035ddde957  pop r8
000079035ddde959  pop rsi
000079035ddde95a  pop rdi
000079035ddde95b  pop rdx
000079035ddde95c  pop rcx
000079035ddde95d  pop rax
000079035ddde95e  add rsp, 0x08
000079035ddde962  jmp 0x000079035DDD9870
000079035ddde967  sub rsp, 0x08
000079035ddde96b  push rax
000079035ddde96c  push rcx
000079035ddde96d  push rdx
000079035ddde96e  push rdi
000079035ddde96f  push rsi
000079035ddde970  push r8
000079035ddde972  push r9
000079035ddde974  push r10
000079035ddde976  push r11
000079035ddde978  sub rsp, 0xF0
000079035ddde97f  vmovaps [rsp], xmm0
000079035ddde984  vmovaps [rsp+0x10], xmm2
000079035ddde98a  vmovaps [rsp+0x20], xmm3
000079035ddde990  vmovaps [rsp+0x30], xmm4
000079035ddde996  vmovaps [rsp+0x40], xmm5
000079035ddde99c  vmovaps [rsp+0x50], xmm6
000079035ddde9a2  vmovaps [rsp+0x60], xmm7
000079035ddde9a8  vmovaps [rsp+0x70], xmm8
000079035ddde9ae  vmovaps [rsp+0x80], xmm9
000079035ddde9b7  vmovaps [rsp+0x90], xmm10
000079035ddde9c0  vmovaps [rsp+0xA0], xmm11
000079035ddde9c9  vmovaps [rsp+0xB0], xmm12
000079035ddde9d2  vmovaps [rsp+0xC0], xmm13
000079035ddde9db  vmovaps [rsp+0xD0], xmm14
000079035ddde9e4  vmovaps [rsp+0xE0], xmm15
000079035ddde9ed  sub rsp, 0x30
000079035ddde9f1  movaps [rsp], xmm1
000079035ddde9f5  movaps [rsp+0x10], xmm8
000079035ddde9fb  movaps [rsp+0x20], xmm9
000079035dddea01  lea rdi, [rsp]
000079035dddea05  mov esi, 0x00
000079035dddea0a  mov rax, 0x64ACAA8B0530
000079035dddea14  call rax
000079035dddea16  movaps xmm1, [rsp]
000079035dddea1a  add rsp, 0x30
000079035dddea1e  vmovaps xmm0, [rsp]
000079035dddea23  vmovaps xmm2, [rsp+0x10]
000079035dddea29  vmovaps xmm3, [rsp+0x20]
000079035dddea2f  vmovaps xmm4, [rsp+0x30]
000079035dddea35  vmovaps xmm5, [rsp+0x40]
000079035dddea3b  vmovaps xmm6, [rsp+0x50]
000079035dddea41  vmovaps xmm7, [rsp+0x60]
000079035dddea47  vmovaps xmm8, [rsp+0x70]
000079035dddea4d  vmovaps xmm9, [rsp+0x80]
000079035dddea56  vmovaps xmm10, [rsp+0x90]
000079035dddea5f  vmovaps xmm11, [rsp+0xA0]
000079035dddea68  vmovaps xmm12, [rsp+0xB0]
000079035dddea71  vmovaps xmm13, [rsp+0xC0]
000079035dddea7a  vmovaps xmm14, [rsp+0xD0]
000079035dddea83  vmovaps xmm15, [rsp+0xE0]
000079035dddea8c  add rsp, 0xF0
000079035dddea93  pop r11
000079035dddea95  pop r10
000079035dddea97  pop r9
000079035dddea99  pop r8
000079035dddea9b  pop rsi
000079035dddea9c  pop rdi
000079035dddea9d  pop rdx
000079035dddea9e  pop rcx
000079035dddea9f  pop rax
000079035dddeaa0  add rsp, 0x08
000079035dddeaa4  jmp 0x000079035DDD9892
000079035dddeaa9  call 0x000079035DCB3E40
000079035dddeaae  jmp 0x000079035DDD98A0
000079035dddeab3  call 0x000079035DC0C380
000079035dddeab8  jmp 0x000079035DDD98AA
000079035dddeabd  call 0x000079035DC0D600
000079035dddeac2  jmp 0x000079035DDD98B4
000079035dddeac7  call 0x000079035DBFF540
000079035dddeacc  jmp 0x000079035DDD98BE
000079035dddead1  int3
000079035dddead2  nop [rax+rax*1], ax
000079035dddeadb  nop [rax+rax*1], eax
000079035dddeae0  mov eax, [r15+0x48]
000079035dddeae4  lea r14d, [eax+0x01]
000079035dddeae9  mov [rsp+0x10], r14d
000079035dddeaee  mov r14d, r14d
000079035dddeaf1  mov [r15+0x48], r14
000079035dddeaf5  xor eax, eax
000079035dddeaf7  mov r14d, [rsp+0x10]
000079035dddeafc  cmp r14d, 0x1F4
000079035dddeb03  cmc
000079035dddeb04  lahf
000079035dddeb05  seto al
000079035dddeb08  mov [r15+0x108], eax
000079035dddeb0f  mov eax, [r15+0x108]
000079035dddeb16  sahf
000079035dddeb17  jnz 0x000079035DDDEB49
000079035dddeb19  cmp dword ptr [r15+0x318], 0x00
000079035dddeb21  jz 0x000079035DDE4C90
000079035dddeb27  nop [rax+rax*1], ax
000079035dddeb30  nop [rax+rax*1], eax
000079035dddeb38  mov eax, 0x4106DC
000079035dddeb3d  mov [r15+0x100], rax
000079035dddeb44  jmp 0x000079035DBFE110
000079035dddeb49  cmp dword ptr [r15+0x318], 0x00
000079035dddeb51  jz 0x000079035DDDEB80
000079035dddeb57  nop [rax+rax*1], ax
000079035dddeb60  nop [rax+rax*1], eax
000079035dddeb68  mov eax, 0x410500
000079035dddeb6d  mov [r15+0x100], rax
000079035dddeb74  jmp 0x000079035DBFE110
000079035dddeb79  int3
000079035dddeb7a  int3
000079035dddeb7b  nop [rax+rax*1], eax
000079035dddeb80  mov rax, [r15+0x40]
000079035dddeb84  movaps xmm1, [r15+0x1D0]
000079035dddeb8c  vmovaps [rsp+0x10], xmm1
000079035dddeb92  vmovaps xmm15, [rsp+0x10]
000079035dddeb98  por xmm1, xmm15
000079035dddeb9d  movaps xmm14, [r15+0x1A0]
000079035dddeba5  vmovaps [rsp+0x10], xmm14
000079035dddebab  vmovaps xmm13, [rsp+0x10]
000079035dddebb1  por xmm14, xmm13
000079035dddebb6  lea r14, [rax+0x30]
000079035dddebba  mov r12, [r13+r14*1]
000079035dddebbf  lea r14, [rax+0x38]
000079035dddebc3  mov r11, [r13+r14*1]
000079035dddebc8  movq xmm13, r12
000079035dddebcd  movq xmm12, r11
000079035dddebd2  movq xmm13, xmm13
000079035dddebd7  vmovaps [rsp+0x10], xmm13
000079035dddebdd  movq xmm13, xmm13
000079035dddebe2  movaps [r15+0x130], xmm13
000079035dddebea  movq xmm12, xmm12
000079035dddebef  vmovaps [rsp+0x20], xmm12
000079035dddebf5  movq xmm12, xmm12
000079035dddebfa  movaps [r15+0x280], xmm12
000079035dddec02  movaps xmm13, [r15+0x270]
000079035dddec0a  vmovaps [rsp+0x30], xmm13
000079035dddec10  vmovaps xmm12, [rsp+0x30]
000079035dddec16  por xmm13, xmm12
000079035dddec1b  lea r14, [rax+0x20]
000079035dddec1f  mov r12, [r13+r14*1]
000079035dddec24  lea r14, [rax+0x28]
000079035dddec28  mov r11, [r13+r14*1]
000079035dddec2d  movq xmm12, r12
000079035dddec32  movq xmm11, r11
000079035dddec37  movq xmm12, xmm12
000079035dddec3c  vmovaps [rsp+0x30], xmm12
000079035dddec42  movq xmm12, xmm12
000079035dddec47  movaps [r15+0x150], xmm12
000079035dddec4f  movq xmm11, xmm11
000079035dddec54  vmovaps [rsp+0x40], xmm11
000079035dddec5a  movq xmm11, xmm11
000079035dddec5f  movaps [r15+0x140], xmm11
000079035dddec67  lea r14, [rax+0x10]
000079035dddec6b  mov r12, [r13+r14*1]
000079035dddec70  lea r14, [rax+0x18]
000079035dddec74  mov r11, [r13+r14*1]
000079035dddec79  movq xmm12, r12
000079035dddec7e  movq xmm11, r11
000079035dddec83  movq xmm12, xmm12
000079035dddec88  vmovaps [rsp+0x50], xmm12
000079035dddec8e  movq xmm12, xmm12
000079035dddec93  movaps [r15+0x170], xmm12
000079035dddec9b  movq xmm11, xmm11
000079035dddeca0  vmovaps [rsp+0x60], xmm11
000079035dddeca6  movq xmm11, xmm11
000079035dddecab  movaps [r15+0x160], xmm11
000079035dddecb3  mov r14, [r13+rax*1]
000079035dddecb8  vmovq xmm12, r14
000079035dddecbd  vpbroadcastq xmm12, xmm12
000079035dddecc2  lea r14, [rax+0x08]
000079035dddecc6  mov rax, [r13+r14*1]
000079035dddeccb  movq xmm11, rax
000079035dddecd0  movaps [r15+0x230], xmm11
000079035dddecd8  mov rax, [r15+0xF8]
000079035dddecdf  lea r14, [rax+0x50]
000079035dddece3  movups xmm11, [r13+r14*1]
000079035dddece9  lea r14, [rax+0x60]
000079035dddeced  movups xmm10, [r13+r14*1]
000079035dddecf3  lea r14, [rax+0x30]
000079035dddecf7  movups xmm9, [r13+r14*1]
000079035dddecfd  mov r14, [r15+0x50]
000079035ddded01  mov [r15+0x60], r14
000079035ddded05  mov qword ptr [r15+0x58], 0x40
000079035ddded0d  movaps xmm8, xmm12
000079035ddded11  mulpd xmm8, xmm15
000079035ddded16  vcmppd xmm7, xmm8, xmm8, 0x03
000079035ddded1c  ptest xmm7, xmm7
000079035ddded21  jnz 0x000079035DDDFB4A
000079035ddded27  movq xmm15, qword ptr [r15+0x230]
000079035ddded30  vmovaps [rsp+0x70], xmm15
000079035ddded36  vpermilpd xmm15, xmm15, 0x00
000079035ddded3c  movaps xmm7, xmm9
000079035ddded40  mulpd xmm7, xmm15
000079035ddded45  vcmppd xmm6, xmm7, xmm7, 0x03
000079035ddded4a  ptest xmm6, xmm6
000079035ddded4f  jnz 0x000079035DDDFC8E
000079035ddded55  vxorps xmm15, xmm15, xmm15
000079035ddded5a  vpbroadcastq xmm15, xmm15
000079035ddded5f  movaps xmm9, xmm12
000079035ddded63  mulpd xmm9, xmm10
000079035ddded68  vcmppd xmm6, xmm9, xmm9, 0x03
000079035ddded6e  ptest xmm6, xmm6
000079035ddded73  jnz 0x000079035DDDFDD0
000079035ddded79  movaps xmm10, xmm12
000079035ddded7d  mulpd xmm10, xmm11
000079035ddded82  vcmppd xmm6, xmm10, xmm10, 0x03
000079035ddded88  ptest xmm6, xmm6
000079035ddded8d  jnz 0x000079035DDDFF14
000079035ddded93  movaps xmm11, [r15+0x1F0]
000079035ddded9b  movaps xmm6, xmm12
000079035ddded9f  mulpd xmm6, xmm11
000079035dddeda4  vcmppd xmm5, xmm6, xmm6, 0x03
000079035dddeda9  ptest xmm5, xmm5
000079035dddedae  jnz 0x000079035DDE0058
000079035dddedb4  movaps xmm12, [r15+0x2A0]
000079035dddedbc  vmovaps [rsp+0x80], xmm12
000079035dddedc5  vmovaps xmm11, [rsp+0x80]
000079035dddedce  por xmm12, xmm11
000079035dddedd3  movaps xmm11, [r15+0x250]
000079035dddeddb  vmovaps [rsp+0x80], xmm11
000079035dddede4  vmovaps xmm5, [rsp+0x80]
000079035dddeded  por xmm11, xmm5
000079035dddedf2  vmovaps xmm4, [rsp+0x70]
000079035dddedf8  vpermilpd xmm4, xmm4, 0x00
000079035dddedfe  movaps xmm3, xmm5
000079035dddee01  mulpd xmm3, xmm4
000079035dddee05  vcmppd xmm2, xmm3, xmm3, 0x03
000079035dddee0a  ptest xmm2, xmm2
000079035dddee0f  jnz 0x000079035DDE019A
000079035dddee15  mov [rsp+0x80], rax
000079035dddee1d  xor eax, eax
000079035dddee1f  mov r12d, 0x40
000079035dddee25  mov r11d, 0x200
000079035dddee2b  cmp r12, r11
000079035dddee2e  cmc
000079035dddee2f  lahf
000079035dddee30  seto al
000079035dddee33  mov [r15+0x108], eax
000079035dddee3a  movaps xmm5, xmm8
000079035dddee3e  addpd xmm5, xmm15
000079035dddee43  vcmppd xmm4, xmm5, xmm5, 0x03
000079035dddee48  ptest xmm4, xmm4
000079035dddee4d  jnz 0x000079035DDE02DA
000079035dddee53  movaps xmm8, [r15+0x1B0]
000079035dddee5b  movaps xmm4, xmm9
000079035dddee5f  addpd xmm4, xmm8
000079035dddee64  vcmppd xmm2, xmm4, xmm4, 0x03
000079035dddee69  ptest xmm2, xmm2
000079035dddee6e  jnz 0x000079035DDE041C
000079035dddee74  movaps xmm9, xmm10
000079035dddee78  addpd xmm9, xmm8
000079035dddee7d  vcmppd xmm2, xmm9, xmm9, 0x03
000079035dddee83  ptest xmm2, xmm2
000079035dddee88  jnz 0x000079035DDE055E
000079035dddee8e  movaps xmm10, [r15+0x2F0]
000079035dddee96  vmovaps [rsp+0x90], xmm10
000079035dddee9f  vmovaps xmm8, [rsp+0x90]
000079035dddeea8  por xmm10, xmm8
000079035dddeead  movaps xmm8, [r15+0x2E0]
000079035dddeeb5  vmovaps [rsp+0x90], xmm8
000079035dddeebe  vmovaps xmm2, [rsp+0x90]
000079035dddeec7  por xmm8, xmm2
000079035dddeecc  movaps xmm2, [r15+0x2D0]
000079035dddeed4  vmovaps [rsp+0x90], xmm2
000079035dddeedd  vmovaps [rsp+0xA0], xmm1
000079035dddeee6  vmovaps xmm1, [rsp+0x90]
000079035dddeeef  por xmm2, xmm1
000079035dddeef3  movaps xmm1, [r15+0x200]
000079035dddeefb  vmovaps [rsp+0x90], xmm1
000079035dddef04  vmovaps [rsp+0xB0], xmm15
000079035dddef0d  vmovaps xmm15, [rsp+0x90]
000079035dddef16  por xmm1, xmm15
000079035dddef1b  movaps xmm15, [r15+0x1C0]
000079035dddef23  vmovaps [rsp+0x90], xmm15
000079035dddef2c  vmovaps [rsp+0xC0], xmm1
000079035dddef35  vmovaps xmm1, [rsp+0x90]
000079035dddef3e  por xmm15, xmm1
000079035dddef43  movaps xmm1, [r15+0x190]
000079035dddef4b  vmovaps [rsp+0x90], xmm1
000079035dddef54  vmovaps [rsp+0xD0], xmm15
000079035dddef5d  vmovaps xmm15, [rsp+0x90]
000079035dddef66  por xmm1, xmm15
000079035dddef6b  movaps xmm15, [r15+0x300]
000079035dddef73  vmovaps [rsp+0x90], xmm15
000079035dddef7c  vmovaps [rsp+0xE0], xmm1
000079035dddef85  vmovaps xmm1, [rsp+0x90]
000079035dddef8e  por xmm15, xmm1
000079035dddef93  mov rax, [rsp+0x80]
000079035dddef9b  lea r12, [rax+0xA0]
000079035dddefa2  movups xmm1, [r13+r12*1]
000079035dddefa8  lea r12, [rax+0xB0]
000079035dddefaf  vmovaps [rsp+0x80], xmm1
000079035dddefb8  movups xmm1, [r13+r12*1]
000079035dddefbe  vmovaps [rsp+0x90], xmm1
000079035dddefc7  vmovaps [rsp+0xF0], xmm15
000079035dddefd0  vmovaps xmm15, [rsp+0xB0]
000079035dddefd9  vmovaps [rsp+0xB0], xmm14
000079035dddefe2  movaps xmm1, xmm6
000079035dddefe5  addpd xmm1, xmm15
000079035dddefea  vcmppd xmm14, xmm1, xmm1, 0x03
000079035dddefef  ptest xmm14, xmm14
000079035dddeff5  jnz 0x000079035DDE06B6
000079035dddeffb  lea r12, [rax+0xF0]
000079035dddf002  movups xmm15, [r13+r12*1]
000079035dddf008  movaps xmm14, xmm4
000079035dddf00c  addpd xmm14, xmm3
000079035dddf011  vcmppd xmm6, xmm14, xmm14, 0x03
000079035dddf017  ptest xmm6, xmm6
000079035dddf01c  jnz 0x000079035DDE0801
000079035dddf022  movaps xmm6, xmm9
000079035dddf026  addpd xmm6, xmm7
000079035dddf02a  vcmppd xmm4, xmm6, xmm6, 0x03
000079035dddf02f  ptest xmm4, xmm4
000079035dddf034  jnz 0x000079035DDE0943
000079035dddf03a  vmovaps xmm9, [rsp+0x70]
000079035dddf040  vpermilpd xmm9, xmm9, 0x00
000079035dddf046  vmovaps xmm4, [rsp+0x90]
000079035dddf04f  movaps xmm7, xmm4
000079035dddf052  mulpd xmm7, xmm9
000079035dddf057  vcmppd xmm3, xmm7, xmm7, 0x03
000079035dddf05c  ptest xmm3, xmm3
000079035dddf061  jnz 0x000079035DDE0A84
000079035dddf067  vmovaps xmm9, [rsp+0x50]
000079035dddf06d  vpermilpd xmm9, xmm9, 0x00
000079035dddf073  movaps xmm4, xmm15
000079035dddf077  mulpd xmm4, xmm9
000079035dddf07c  vcmppd xmm3, xmm4, xmm4, 0x03
000079035dddf081  ptest xmm3, xmm3
000079035dddf086  jnz 0x000079035DDE0BC5
000079035dddf08c  lea r12, [rax+0xE0]
000079035dddf093  movups xmm15, [r13+r12*1]
000079035dddf099  vmovaps xmm9, [rsp+0x70]
000079035dddf09f  vpermilpd xmm9, xmm9, 0x00
000079035dddf0a5  vmovaps [rsp+0x70], xmm1
000079035dddf0ab  vmovaps xmm1, [rsp+0x80]
000079035dddf0b4  vmovaps [rsp+0x80], xmm15
000079035dddf0bd  movaps xmm3, xmm1
000079035dddf0c0  mulpd xmm3, xmm9
000079035dddf0c5  vcmppd xmm15, xmm3, xmm3, 0x03
000079035dddf0ca  ptest xmm15, xmm15
000079035dddf0d0  jnz 0x000079035DDE0D11
000079035dddf0d6  vmovaps xmm1, [rsp+0xF0]
000079035dddf0df  vmovaps xmm15, [rsp+0xF0]
000079035dddf0e8  por xmm1, xmm15
000079035dddf0ed  movaps [r15+0x300], xmm1
000079035dddf0f5  vmovaps xmm15, [rsp+0xE0]
000079035dddf0fe  vmovaps xmm9, [rsp+0xE0]
000079035dddf107  por xmm15, xmm9
000079035dddf10c  movaps [r15+0x190], xmm15
000079035dddf114  vmovaps xmm9, [rsp+0x50]
000079035dddf11a  vpermilpd xmm9, xmm9, 0x00
000079035dddf120  vmovaps [rsp+0x90], xmm1
000079035dddf129  vmovaps [rsp+0xE0], xmm15
000079035dddf132  vmovaps xmm15, [rsp+0x80]
000079035dddf13b  vmovaps [rsp+0x80], xmm14
000079035dddf144  movaps xmm1, xmm15
000079035dddf148  mulpd xmm1, xmm9
000079035dddf14d  vcmppd xmm14, xmm1, xmm1, 0x03
000079035dddf152  ptest xmm14, xmm14
000079035dddf158  jnz 0x000079035DDE0E52
000079035dddf15e  lea r12, [rax+0x90]
000079035dddf165  movups xmm15, [r13+r12*1]
000079035dddf16b  vmovaps xmm14, [rsp+0xD0]
000079035dddf174  vmovaps xmm9, [rsp+0xD0]
000079035dddf17d  por xmm14, xmm9
000079035dddf182  movaps [r15+0x1C0], xmm14
000079035dddf18a  vmovaps xmm9, [rsp+0xC0]
000079035dddf193  vmovaps [rsp+0xD0], xmm1
000079035dddf19c  vmovaps xmm1, [rsp+0xC0]
000079035dddf1a5  por xmm9, xmm1
000079035dddf1aa  movaps [r15+0x200], xmm9
000079035dddf1b2  vmovaps [rsp+0xC0], xmm2
000079035dddf1bb  vmovaps xmm1, [rsp+0xC0]
000079035dddf1c4  por xmm2, xmm1
000079035dddf1c8  movaps [r15+0x2D0], xmm2
000079035dddf1d0  vmovaps [rsp+0xC0], xmm8
000079035dddf1d9  vmovaps xmm1, [rsp+0xC0]
000079035dddf1e2  por xmm8, xmm1
000079035dddf1e7  movaps [r15+0x2E0], xmm8
000079035dddf1ef  vmovaps [rsp+0xC0], xmm15
000079035dddf1f8  movaps xmm1, xmm5
000079035dddf1fb  addpd xmm1, xmm7
000079035dddf1ff  vcmppd xmm15, xmm1, xmm1, 0x03
000079035dddf204  ptest xmm15, xmm15
000079035dddf20a  jnz 0x000079035DDE0F9E
000079035dddf210  vmovaps xmm15, [rsp+0x50]
000079035dddf216  vpermilpd xmm15, xmm15, 0x00
000079035dddf21c  vmovaps xmm5, [rsp+0xC0]
000079035dddf225  vmovaps [rsp+0xC0], xmm1
000079035dddf22e  movaps xmm7, xmm5
000079035dddf231  mulpd xmm7, xmm15
000079035dddf236  vcmppd xmm1, xmm7, xmm7, 0x03
000079035dddf23b  ptest xmm1, xmm1
000079035dddf240  jnz 0x000079035DDE10DE
000079035dddf246  lea r12, [rax+0x80]
000079035dddf24d  movups xmm1, [r13+r12*1]
000079035dddf253  vmovaps xmm5, [rsp+0x70]
000079035dddf259  vmovaps [rsp+0x70], xmm1
000079035dddf25f  movaps xmm15, xmm5
000079035dddf263  addpd xmm15, xmm3
000079035dddf268  vcmppd xmm1, xmm15, xmm15, 0x03
000079035dddf26e  ptest xmm1, xmm1
000079035dddf273  jnz 0x000079035DDE1229
000079035dddf279  vmovaps xmm5, [rsp+0x80]
000079035dddf282  movaps xmm1, xmm5
000079035dddf285  addpd xmm1, xmm4
000079035dddf289  vcmppd xmm3, xmm1, xmm1, 0x03
000079035dddf28e  ptest xmm3, xmm3
000079035dddf293  jnz 0x000079035DDE136B
000079035dddf299  vmovaps [rsp+0x80], xmm10
000079035dddf2a2  vmovaps xmm5, [rsp+0x80]
000079035dddf2ab  por xmm10, xmm5
000079035dddf2b0  movaps [r15+0x2F0], xmm10
000079035dddf2b8  vmovaps xmm5, [rsp+0x50]
000079035dddf2be  vpermilpd xmm5, xmm5, 0x00
000079035dddf2c4  vmovaps xmm3, [rsp+0x70]
000079035dddf2ca  vmovaps [rsp+0x50], xmm1
000079035dddf2d0  movaps xmm4, xmm3
000079035dddf2d3  mulpd xmm4, xmm5
000079035dddf2d7  vcmppd xmm1, xmm4, xmm4, 0x03
000079035dddf2dc  ptest xmm1, xmm1
000079035dddf2e1  jnz 0x000079035DDE14AB
000079035dddf2e7  lea r12, [rax+0xD0]
000079035dddf2ee  movups xmm1, [r13+r12*1]
000079035dddf2f4  vmovaps xmm3, [rsp+0xD0]
000079035dddf2fd  vmovaps [rsp+0x70], xmm1
000079035dddf303  movaps xmm5, xmm6
000079035dddf306  addpd xmm5, xmm3
000079035dddf30a  vcmppd xmm1, xmm5, xmm5, 0x03
000079035dddf30f  ptest xmm1, xmm1
000079035dddf314  jnz 0x000079035DDE15F5
000079035dddf31a  vmovaps xmm1, [rsp+0x60]
000079035dddf320  vpermilpd xmm1, xmm1, 0x00
000079035dddf326  movaps xmm6, xmm9
000079035dddf32a  mulpd xmm6, xmm1
000079035dddf32e  vcmppd xmm3, xmm6, xmm6, 0x03
000079035dddf333  ptest xmm3, xmm3
000079035dddf338  jnz 0x000079035DDE1735
000079035dddf33e  movaps [r15+0x260], xmm6
000079035dddf346  vxorps xmm1, xmm1, xmm1
000079035dddf34a  vpbroadcastq xmm1, xmm1
000079035dddf34f  movaps [r15+0x1B0], xmm1
000079035dddf357  vmovaps xmm1, [rsp+0x60]
000079035dddf35d  vpermilpd xmm1, xmm1, 0x00
000079035dddf363  vmovaps xmm3, [rsp+0x70]
000079035dddf369  vmovaps [rsp+0x70], xmm15
000079035dddf36f  movaps xmm9, xmm3
000079035dddf373  mulpd xmm9, xmm1
000079035dddf378  vcmppd xmm15, xmm9, xmm9, 0x03
000079035dddf37e  ptest xmm15, xmm15
000079035dddf384  jnz 0x000079035DDE1876
000079035dddf38a  lea r12, [rax+0xC0]
000079035dddf391  movups xmm1, [r13+r12*1]
000079035dddf397  vmovaps xmm3, [rsp+0xC0]
000079035dddf3a0  vmovaps [rsp+0x80], xmm1
000079035dddf3a9  movaps xmm15, xmm3
000079035dddf3ad  addpd xmm15, xmm7
000079035dddf3b2  vcmppd xmm1, xmm15, xmm15, 0x03
000079035dddf3b8  ptest xmm1, xmm1
000079035dddf3bd  jnz 0x000079035DDE19C2
000079035dddf3c3  vmovaps [rsp+0xC0], xmm13
000079035dddf3cc  vmovaps xmm1, [rsp+0xC0]
000079035dddf3d5  por xmm13, xmm1
000079035dddf3da  movaps [r15+0x270], xmm13
000079035dddf3e2  vmovaps xmm1, [rsp+0xB0]
000079035dddf3eb  vmovaps xmm7, [rsp+0xB0]
000079035dddf3f4  por xmm1, xmm7
000079035dddf3f8  movaps [r15+0x1A0], xmm1
000079035dddf400  vmovaps xmm1, [rsp+0x60]
000079035dddf406  vpermilpd xmm1, xmm1, 0x00
000079035dddf40c  vmovaps [rsp+0xB0], xmm1
000079035dddf415  vmovaps xmm1, [rsp+0x80]
000079035dddf41e  vmovaps [rsp+0x80], xmm15
000079035dddf427  vmovaps xmm15, [rsp+0xB0]
000079035dddf430  vmovaps [rsp+0xB0], xmm14
000079035dddf439  movaps xmm3, xmm1
000079035dddf43c  mulpd xmm3, xmm15
000079035dddf441  vcmppd xmm14, xmm3, xmm3, 0x03
000079035dddf446  ptest xmm14, xmm14
000079035dddf44c  jnz 0x000079035DDE1B04
000079035dddf452  lea r12, [rax+0x20]
000079035dddf456  movups xmm1, [r13+r12*1]
000079035dddf45c  movaps [r15+0x110], xmm1
000079035dddf464  vmovaps xmm14, [rsp+0x70]
000079035dddf46a  vmovaps [rsp+0x70], xmm1
000079035dddf470  movaps xmm15, xmm14
000079035dddf474  addpd xmm15, xmm4
000079035dddf479  vcmppd xmm1, xmm15, xmm15, 0x03
000079035dddf47f  ptest xmm1, xmm1
000079035dddf484  jnz 0x000079035DDE1C4F
000079035dddf48a  vmovaps xmm1, [rsp+0x60]
000079035dddf490  vpermilpd xmm1, xmm1, 0x00
000079035dddf496  movaps xmm14, xmm2
000079035dddf49a  mulpd xmm14, xmm1
000079035dddf49f  vcmppd xmm4, xmm14, xmm14, 0x03
000079035dddf4a5  ptest xmm4, xmm4
000079035dddf4aa  jnz 0x000079035DDE1D92
000079035dddf4b0  vmovaps xmm4, [rsp+0x50]
000079035dddf4b6  movaps xmm1, xmm4
000079035dddf4b9  addpd xmm1, xmm9
000079035dddf4be  vcmppd xmm2, xmm1, xmm1, 0x03
000079035dddf4c3  ptest xmm2, xmm2
000079035dddf4c8  jnz 0x000079035DDE1ED4
000079035dddf4ce  vmovaps xmm9, [rsp+0x30]
000079035dddf4d4  vpermilpd xmm9, xmm9, 0x00
000079035dddf4da  vmovaps xmm2, [rsp+0x70]
000079035dddf4e0  vmovaps [rsp+0x50], xmm1
000079035dddf4e6  movaps xmm4, xmm2
000079035dddf4e9  mulpd xmm4, xmm9
000079035dddf4ee  vcmppd xmm1, xmm4, xmm4, 0x03
000079035dddf4f3  ptest xmm1, xmm1
000079035dddf4f8  jnz 0x000079035DDE2015
000079035dddf4fe  vmovaps xmm1, [rsp+0x30]
000079035dddf504  vpermilpd xmm1, xmm1, 0x00
000079035dddf50a  vmovaps xmm2, [rsp+0x90]
000079035dddf513  vmovaps [rsp+0x60], xmm15
000079035dddf519  movaps xmm9, xmm2
000079035dddf51d  mulpd xmm9, xmm1
000079035dddf522  vcmppd xmm15, xmm9, xmm9, 0x03
000079035dddf528  ptest xmm15, xmm15
000079035dddf52e  jnz 0x000079035DDE2156
000079035dddf534  vmovaps xmm15, [rsp+0x80]
000079035dddf53d  movaps xmm1, xmm15
000079035dddf541  addpd xmm1, xmm6
000079035dddf545  vcmppd xmm2, xmm1, xmm1, 0x03
000079035dddf54a  ptest xmm2, xmm2
000079035dddf54f  jnz 0x000079035DDE2298
000079035dddf555  movaps xmm15, xmm5
000079035dddf559  addpd xmm15, xmm3
000079035dddf55e  vcmppd xmm6, xmm15, xmm15, 0x03
000079035dddf564  ptest xmm6, xmm6
000079035dddf569  jnz 0x000079035DDE23D9
000079035dddf56f  vmovaps xmm6, [rsp+0x30]
000079035dddf575  vpermilpd xmm6, xmm6, 0x00
000079035dddf57b  movaps xmm5, xmm8
000079035dddf57f  mulpd xmm5, xmm6
000079035dddf583  vcmppd xmm3, xmm5, xmm5, 0x03
000079035dddf588  ptest xmm3, xmm3
000079035dddf58d  jnz 0x000079035DDE251B
000079035dddf593  vmovaps xmm8, [rsp+0x30]
000079035dddf599  vpermilpd xmm8, xmm8, 0x00
000079035dddf59f  movaps xmm6, xmm10
000079035dddf5a3  mulpd xmm6, xmm8
000079035dddf5a8  vcmppd xmm3, xmm6, xmm6, 0x03
000079035dddf5ad  ptest xmm3, xmm3
000079035dddf5b2  jnz 0x000079035DDE265C
000079035dddf5b8  vmovaps xmm8, [rsp+0x60]
000079035dddf5be  movaps xmm10, xmm8
000079035dddf5c2  addpd xmm10, xmm14
000079035dddf5c7  vcmppd xmm3, xmm10, xmm10, 0x03
000079035dddf5cd  ptest xmm3, xmm3
000079035dddf5d2  jnz 0x000079035DDE279E
000079035dddf5d8  vmovaps xmm8, [rsp+0x50]
000079035dddf5de  movaps xmm14, xmm8
000079035dddf5e2  addpd xmm14, xmm4
000079035dddf5e7  vcmppd xmm3, xmm14, xmm14, 0x03
000079035dddf5ed  ptest xmm3, xmm3
000079035dddf5f2  jnz 0x000079035DDE28E2
000079035dddf5f8  vmovaps xmm8, [rsp+0x40]
000079035dddf5fe  vpermilpd xmm8, xmm8, 0x00
000079035dddf604  movaps xmm4, xmm13
000079035dddf608  mulpd xmm4, xmm8
000079035dddf60d  vcmppd xmm3, xmm4, xmm4, 0x03
000079035dddf612  ptest xmm3, xmm3
000079035dddf617  jnz 0x000079035DDE2A25
000079035dddf61d  movaps xmm13, xmm15
000079035dddf621  addpd xmm13, xmm9
000079035dddf626  vcmppd xmm8, xmm13, xmm13, 0x03
000079035dddf62c  ptest xmm8, xmm8
000079035dddf632  jnz 0x000079035DDE2B67
000079035dddf638  movaps xmm15, xmm1
000079035dddf63c  addpd xmm15, xmm5
000079035dddf641  vcmppd xmm9, xmm15, xmm15, 0x03
000079035dddf647  ptest xmm9, xmm9
000079035dddf64d  jnz 0x000079035DDE2CAB
000079035dddf653  vmovaps [rsp+0x30], xmm11
000079035dddf659  vmovaps xmm1, [rsp+0x30]
000079035dddf65f  por xmm11, xmm1
000079035dddf664  movaps [r15+0x250], xmm11
000079035dddf66c  vmovaps [rsp+0x30], xmm12
000079035dddf672  vmovaps xmm1, [rsp+0x30]
000079035dddf678  por xmm12, xmm1
000079035dddf67d  movaps [r15+0x2A0], xmm12
000079035dddf685  vmovaps xmm1, [rsp+0xA0]
000079035dddf68e  vmovaps xmm11, [rsp+0xA0]
000079035dddf697  por xmm1, xmm11
000079035dddf69c  movaps [r15+0x1D0], xmm1
000079035dddf6a4  lea r12, [rax+0x40]
000079035dddf6a8  movups xmm1, [r13+r12*1]
000079035dddf6ae  movaps [r15+0x2C0], xmm1
000079035dddf6b6  vmovaps xmm11, [rsp+0x40]
000079035dddf6bc  vpermilpd xmm11, xmm11, 0x00
000079035dddf6c2  vmovaps xmm8, [rsp+0xE0]
000079035dddf6cb  movaps xmm9, xmm8
000079035dddf6cf  mulpd xmm9, xmm11
000079035dddf6d4  vcmppd xmm5, xmm9, xmm9, 0x03
000079035dddf6da  ptest xmm5, xmm5
000079035dddf6df  jnz 0x000079035DDE2DF7
000079035dddf6e5  movaps xmm11, xmm10
000079035dddf6e9  addpd xmm11, xmm6
000079035dddf6ee  vcmppd xmm8, xmm11, xmm11, 0x03
000079035dddf6f4  ptest xmm8, xmm8
000079035dddf6fa  jnz 0x000079035DDE2F3B
000079035dddf700  movaps xmm10, xmm14
000079035dddf704  addpd xmm10, xmm4
000079035dddf709  vcmppd xmm8, xmm10, xmm10, 0x03
000079035dddf70f  ptest xmm8, xmm8
000079035dddf715  jnz 0x000079035DDE307E
000079035dddf71b  vmovaps xmm14, [rsp+0x40]
000079035dddf721  vpermilpd xmm14, xmm14, 0x00
000079035dddf727  movaps xmm8, xmm1
000079035dddf72b  mulpd xmm8, xmm14
000079035dddf730  vcmppd xmm6, xmm8, xmm8, 0x03
000079035dddf736  ptest xmm6, xmm6
000079035dddf73b  jnz 0x000079035DDE31C1
000079035dddf741  movaps xmm1, [r15+0x2B0]
000079035dddf749  vmovaps xmm14, [rsp+0x40]
000079035dddf74f  vpermilpd xmm14, xmm14, 0x00
000079035dddf755  movaps xmm6, xmm1
000079035dddf758  mulpd xmm6, xmm14
000079035dddf75d  vcmppd xmm5, xmm6, xmm6, 0x03
000079035dddf762  ptest xmm5, xmm5
000079035dddf767  jnz 0x000079035DDE3304
000079035dddf76d  vmovaps xmm1, [rsp+0x10]
000079035dddf773  vpermilpd xmm1, xmm1, 0x00
000079035dddf779  movaps xmm14, xmm12
000079035dddf77d  mulpd xmm14, xmm1
000079035dddf782  vcmppd xmm5, xmm14, xmm14, 0x03
000079035dddf788  ptest xmm5, xmm5
000079035dddf78d  jnz 0x000079035DDE3445
000079035dddf793  movaps xmm1, xmm13
000079035dddf797  addpd xmm1, xmm9
000079035dddf79c  vcmppd xmm12, xmm1, xmm1, 0x03
000079035dddf7a1  ptest xmm12, xmm12
000079035dddf7a7  jnz 0x000079035DDE3588
000079035dddf7ad  vmovaps xmm13, [rsp+0x10]
000079035dddf7b3  vpermilpd xmm13, xmm13, 0x00
000079035dddf7b9  movaps xmm12, xmm7
000079035dddf7bd  mulpd xmm12, xmm13
000079035dddf7c2  vcmppd xmm9, xmm12, xmm12, 0x03
000079035dddf7c8  ptest xmm9, xmm9
000079035dddf7ce  jnz 0x000079035DDE36CA
000079035dddf7d4  movaps xmm13, xmm15
000079035dddf7d8  addpd xmm13, xmm8
000079035dddf7dd  vcmppd xmm9, xmm13, xmm13, 0x03
000079035dddf7e3  ptest xmm9, xmm9
000079035dddf7e9  jnz 0x000079035DDE380D
000079035dddf7ef  movaps xmm15, [r15+0x290]
000079035dddf7f7  vmovaps xmm9, [rsp+0x10]
000079035dddf7fd  vpermilpd xmm9, xmm9, 0x00
000079035dddf803  movaps xmm8, xmm15
000079035dddf807  mulpd xmm8, xmm9
000079035dddf80c  vcmppd xmm7, xmm8, xmm8, 0x03
000079035dddf812  ptest xmm7, xmm7
000079035dddf817  jnz 0x000079035DDE3951
000079035dddf81d  movaps xmm15, xmm11
000079035dddf821  addpd xmm15, xmm6
000079035dddf826  vcmppd xmm9, xmm15, xmm15, 0x03
000079035dddf82c  ptest xmm9, xmm9
000079035dddf832  jnz 0x000079035DDE3A95
000079035dddf838  movaps xmm11, [r15+0x1E0]
000079035dddf840  vmovaps xmm9, [rsp+0x10]
000079035dddf846  vpermilpd xmm9, xmm9, 0x00
000079035dddf84c  movaps xmm7, xmm11
000079035dddf850  mulpd xmm7, xmm9
000079035dddf855  vcmppd xmm6, xmm7, xmm7, 0x03
000079035dddf85a  ptest xmm6, xmm6
000079035dddf85f  jnz 0x000079035DDE3BD8
000079035dddf865  movaps xmm11, xmm10
000079035dddf869  addpd xmm11, xmm14
000079035dddf86e  vcmppd xmm9, xmm11, xmm11, 0x03
000079035dddf874  ptest xmm9, xmm9
000079035dddf87a  jnz 0x000079035DDE3D1A
000079035dddf880  lea r12, [rax+0x70]
000079035dddf884  movups xmm14, [r13+r12*1]
000079035dddf88a  movaps [r15+0x240], xmm14
000079035dddf892  movaps xmm10, xmm1
000079035dddf896  addpd xmm10, xmm12
000079035dddf89b  vcmppd xmm9, xmm10, xmm10, 0x03
000079035dddf8a1  ptest xmm9, xmm9
000079035dddf8a7  jnz 0x000079035DDE3E68
000079035dddf8ad  movaps [r15+0x170], xmm10
000079035dddf8b5  vmovaps xmm1, [rsp+0x20]
000079035dddf8bb  vpermilpd xmm1, xmm1, 0x00
000079035dddf8c1  movaps xmm12, xmm14
000079035dddf8c5  mulpd xmm12, xmm1
000079035dddf8ca  vcmppd xmm9, xmm12, xmm12, 0x03
000079035dddf8d0  ptest xmm9, xmm9
000079035dddf8d6  jnz 0x000079035DDE3FAB
000079035dddf8dc  vmovaps xmm1, [rsp+0x20]
000079035dddf8e2  vpermilpd xmm1, xmm1, 0x00
000079035dddf8e8  vmovaps xmm9, [rsp+0xB0]
000079035dddf8f1  movaps xmm14, xmm9
000079035dddf8f5  mulpd xmm14, xmm1
000079035dddf8fa  vcmppd xmm6, xmm14, xmm14, 0x03
000079035dddf900  ptest xmm6, xmm6
000079035dddf905  jnz 0x000079035DDE40EE
000079035dddf90b  movaps [r15+0x180], xmm14
000079035dddf913  movaps xmm1, xmm13
000079035dddf917  addpd xmm1, xmm8
000079035dddf91c  vcmppd xmm9, xmm1, xmm1, 0x03
000079035dddf921  ptest xmm9, xmm9
000079035dddf927  jnz 0x000079035DDE4231
000079035dddf92d  movaps [r15+0x210], xmm1
000079035dddf935  movups xmm13, [r13+rax*1]
000079035dddf93b  lea r12, [rax+0x10]
000079035dddf93f  movups xmm9, [r13+r12*1]
000079035dddf945  movaps [r15+0x230], xmm9
000079035dddf94d  movaps xmm8, xmm15
000079035dddf951  addpd xmm8, xmm7
000079035dddf956  vcmppd xmm6, xmm8, xmm8, 0x03
000079035dddf95c  ptest xmm6, xmm6
000079035dddf961  jnz 0x000079035DDE4387
000079035dddf967  movaps [r15+0x130], xmm8
000079035dddf96f  vmovaps xmm15, [rsp+0x20]
000079035dddf975  vpermilpd xmm15, xmm15, 0x00
000079035dddf97b  movaps xmm7, xmm9
000079035dddf97f  mulpd xmm7, xmm15
000079035dddf984  vcmppd xmm6, xmm7, xmm7, 0x03
000079035dddf989  ptest xmm6, xmm6
000079035dddf98e  jnz 0x000079035DDE44CA
000079035dddf994  movaps [r15+0x220], xmm7
000079035dddf99c  vmovaps xmm15, [rsp+0x20]
000079035dddf9a2  vpermilpd xmm15, xmm15, 0x00
000079035dddf9a8  movaps xmm9, xmm13
000079035dddf9ac  mulpd xmm9, xmm15
000079035dddf9b1  vcmppd xmm6, xmm9, xmm9, 0x03
000079035dddf9b7  ptest xmm6, xmm6
000079035dddf9bc  jnz 0x000079035DDE460C
000079035dddf9c2  movaps xmm15, xmm11
000079035dddf9c6  addpd xmm15, xmm12
000079035dddf9cb  vcmppd xmm13, xmm15, xmm15, 0x03
000079035dddf9d1  ptest xmm13, xmm13
000079035dddf9d7  jnz 0x000079035DDE4750
000079035dddf9dd  movaps [r15+0x140], xmm15
000079035dddf9e5  movaps xmm13, xmm10
000079035dddf9e9  addpd xmm13, xmm14
000079035dddf9ee  vcmppd xmm12, xmm13, xmm13, 0x03
000079035dddf9f4  ptest xmm12, xmm12
000079035dddf9fa  jnz 0x000079035DDE4894
000079035dddfa00  movaps [r15+0x150], xmm13
000079035dddfa08  movaps xmm14, xmm1
000079035dddfa0c  addpd xmm14, xmm7
000079035dddfa11  vcmppd xmm12, xmm14, xmm14, 0x03
000079035dddfa17  ptest xmm12, xmm12
000079035dddfa1d  jnz 0x000079035DDE49D8
000079035dddfa23  movaps [r15+0x160], xmm14
000079035dddfa2b  movaps xmm1, xmm8
000079035dddfa2f  addpd xmm1, xmm9
000079035dddfa34  vcmppd xmm12, xmm1, xmm1, 0x03
000079035dddfa39  ptest xmm12, xmm12
000079035dddfa3f  jnz 0x000079035DDE4B1A
000079035dddfa45  movaps [r15+0x120], xmm1
000079035dddfa4d  movups [r13+r14*1], xmm15
000079035dddfa53  lea rax, [r14+0x10]
000079035dddfa57  movups [r13+rax*1], xmm13
000079035dddfa5d  lea rax, [r14+0x20]
000079035dddfa61  movups [r13+rax*1], xmm14
000079035dddfa67  lea rax, [r14+0x30]
000079035dddfa6b  movups [r13+rax*1], xmm1
000079035dddfa71  mov eax, [r15+0x108]
000079035dddfa78  sahf
000079035dddfa79  jnz 0x000079035DDDFAAB
000079035dddfa7b  cmp dword ptr [r15+0x318], 0x00
000079035dddfa83  jz 0x000079035DDDEAE0
000079035dddfa89  nop [rax+rax*1], ax
000079035dddfa92  nop [rax+rax*1], eax
000079035dddfa9a  mov eax, 0x4106D0
000079035dddfa9f  mov [r15+0x100], rax
000079035dddfaa6  jmp 0x000079035DBFE110
000079035dddfaab  cmp dword ptr [r15+0x318], 0x00
000079035dddfab3  jz 0x000079035DDD89C0
000079035dddfab9  nop [rax+rax*1], ax
000079035dddfac2  nop [rax+rax*1], eax
000079035dddfaca  mov eax, 0x410504
000079035dddfacf  mov [r15+0x100], rax
000079035dddfad6  jmp 0x000079035DBFE110
000079035dddfadb  int3
000079035dddfadc  call 0x000079035DCE27E0
000079035dddfae1  jmp 0x000079035DDDEBBF
000079035dddfae6  call 0x000079035DCE1570
000079035dddfaeb  jmp 0x000079035DDDEBC8
000079035dddfaf0  call 0x000079035DCE27E0
000079035dddfaf5  jmp 0x000079035DDDEC24
000079035dddfafa  call 0x000079035DCE1570
000079035dddfaff  jmp 0x000079035DDDEC2D
000079035dddfb04  call 0x000079035DCE27E0
000079035dddfb09  jmp 0x000079035DDDEC70
000079035dddfb0e  call 0x000079035DCE1570
000079035dddfb13  jmp 0x000079035DDDEC79
000079035dddfb18  call 0x000079035DC0DC20
000079035dddfb1d  jmp 0x000079035DDDECB8
000079035dddfb22  call 0x000079035DCD59C0
000079035dddfb27  jmp 0x000079035DDDECCB
000079035dddfb2c  call 0x000079035DCE0E30
000079035dddfb31  jmp 0x000079035DDDECE9
000079035dddfb36  call 0x000079035DCDFBC0
000079035dddfb3b  jmp 0x000079035DDDECF3
000079035dddfb40  call 0x000079035DCDE950
000079035dddfb45  jmp 0x000079035DDDECFD
000079035dddfb4a  sub rsp, 0x08
000079035dddfb4e  push rax
000079035dddfb4f  push rcx
000079035dddfb50  push rdx
000079035dddfb51  push rdi
000079035dddfb52  push rsi
000079035dddfb53  push r8
000079035dddfb55  push r9
000079035dddfb57  push r10
000079035dddfb59  push r11
000079035dddfb5b  sub rsp, 0xF0
000079035dddfb62  vmovaps [rsp], xmm0
000079035dddfb67  vmovaps [rsp+0x10], xmm1
000079035dddfb6d  vmovaps [rsp+0x20], xmm2
000079035dddfb73  vmovaps [rsp+0x30], xmm3
000079035dddfb79  vmovaps [rsp+0x40], xmm4
000079035dddfb7f  vmovaps [rsp+0x50], xmm5
000079035dddfb85  vmovaps [rsp+0x60], xmm6
000079035dddfb8b  vmovaps [rsp+0x70], xmm7
000079035dddfb91  vmovaps [rsp+0x80], xmm9
000079035dddfb9a  vmovaps [rsp+0x90], xmm10
000079035dddfba3  vmovaps [rsp+0xA0], xmm11
000079035dddfbac  vmovaps [rsp+0xB0], xmm12
000079035dddfbb5  vmovaps [rsp+0xC0], xmm13
000079035dddfbbe  vmovaps [rsp+0xD0], xmm14
000079035dddfbc7  vmovaps [rsp+0xE0], xmm15
000079035dddfbd0  sub rsp, 0x30
000079035dddfbd4  movaps [rsp], xmm8
000079035dddfbd9  movaps [rsp+0x10], xmm12
000079035dddfbdf  movaps [rsp+0x20], xmm15
000079035dddfbe5  lea rdi, [rsp]
000079035dddfbe9  mov esi, 0x00
000079035dddfbee  mov rax, 0x64ACAA8B0530
000079035dddfbf8  call rax
000079035dddfbfa  movaps xmm8, [rsp]
000079035dddfbff  add rsp, 0x30
000079035dddfc03  vmovaps xmm0, [rsp]
000079035dddfc08  vmovaps xmm1, [rsp+0x10]
000079035dddfc0e  vmovaps xmm2, [rsp+0x20]
000079035dddfc14  vmovaps xmm3, [rsp+0x30]
000079035dddfc1a  vmovaps xmm4, [rsp+0x40]
000079035dddfc20  vmovaps xmm5, [rsp+0x50]
000079035dddfc26  vmovaps xmm6, [rsp+0x60]
000079035dddfc2c  vmovaps xmm7, [rsp+0x70]
000079035dddfc32  vmovaps xmm9, [rsp+0x80]
000079035dddfc3b  vmovaps xmm10, [rsp+0x90]
000079035dddfc44  vmovaps xmm11, [rsp+0xA0]
000079035dddfc4d  vmovaps xmm12, [rsp+0xB0]
000079035dddfc56  vmovaps xmm13, [rsp+0xC0]
000079035dddfc5f  vmovaps xmm14, [rsp+0xD0]
000079035dddfc68  vmovaps xmm15, [rsp+0xE0]
000079035dddfc71  add rsp, 0xF0
000079035dddfc78  pop r11
000079035dddfc7a  pop r10
000079035dddfc7c  pop r9
000079035dddfc7e  pop r8
000079035dddfc80  pop rsi
000079035dddfc81  pop rdi
000079035dddfc82  pop rdx
000079035dddfc83  pop rcx
000079035dddfc84  pop rax
000079035dddfc85  add rsp, 0x08
000079035dddfc89  jmp 0x000079035DDDED27
000079035dddfc8e  sub rsp, 0x08
000079035dddfc92  push rax
000079035dddfc93  push rcx
000079035dddfc94  push rdx
000079035dddfc95  push rdi
000079035dddfc96  push rsi
000079035dddfc97  push r8
000079035dddfc99  push r9
000079035dddfc9b  push r10
000079035dddfc9d  push r11
000079035dddfc9f  sub rsp, 0xF0
000079035dddfca6  vmovaps [rsp], xmm0
000079035dddfcab  vmovaps [rsp+0x10], xmm1
000079035dddfcb1  vmovaps [rsp+0x20], xmm2
000079035dddfcb7  vmovaps [rsp+0x30], xmm3
000079035dddfcbd  vmovaps [rsp+0x40], xmm4
000079035dddfcc3  vmovaps [rsp+0x50], xmm5
000079035dddfcc9  vmovaps [rsp+0x60], xmm6
000079035dddfccf  vmovaps [rsp+0x70], xmm8
000079035dddfcd5  vmovaps [rsp+0x80], xmm9
000079035dddfcde  vmovaps [rsp+0x90], xmm10
000079035dddfce7  vmovaps [rsp+0xA0], xmm11
000079035dddfcf0  vmovaps [rsp+0xB0], xmm12
000079035dddfcf9  vmovaps [rsp+0xC0], xmm13
000079035dddfd02  vmovaps [rsp+0xD0], xmm14
000079035dddfd0b  vmovaps [rsp+0xE0], xmm15
000079035dddfd14  sub rsp, 0x30
000079035dddfd18  movaps [rsp], xmm7
000079035dddfd1c  movaps [rsp+0x10], xmm9
000079035dddfd22  movaps [rsp+0x20], xmm15
000079035dddfd28  lea rdi, [rsp]
000079035dddfd2c  mov esi, 0x00
000079035dddfd31  mov rax, 0x64ACAA8B0530
000079035dddfd3b  call rax
000079035dddfd3d  movaps xmm7, [rsp]
000079035dddfd41  add rsp, 0x30
000079035dddfd45  vmovaps xmm0, [rsp]
000079035dddfd4a  vmovaps xmm1, [rsp+0x10]
000079035dddfd50  vmovaps xmm2, [rsp+0x20]
000079035dddfd56  vmovaps xmm3, [rsp+0x30]
000079035dddfd5c  vmovaps xmm4, [rsp+0x40]
000079035dddfd62  vmovaps xmm5, [rsp+0x50]
000079035dddfd68  vmovaps xmm6, [rsp+0x60]
000079035dddfd6e  vmovaps xmm8, [rsp+0x70]
000079035dddfd74  vmovaps xmm9, [rsp+0x80]
000079035dddfd7d  vmovaps xmm10, [rsp+0x90]
000079035dddfd86  vmovaps xmm11, [rsp+0xA0]
000079035dddfd8f  vmovaps xmm12, [rsp+0xB0]
000079035dddfd98  vmovaps xmm13, [rsp+0xC0]
000079035dddfda1  vmovaps xmm14, [rsp+0xD0]
000079035dddfdaa  vmovaps xmm15, [rsp+0xE0]
000079035dddfdb3  add rsp, 0xF0
000079035dddfdba  pop r11
000079035dddfdbc  pop r10
000079035dddfdbe  pop r9
000079035dddfdc0  pop r8
000079035dddfdc2  pop rsi
000079035dddfdc3  pop rdi
000079035dddfdc4  pop rdx
000079035dddfdc5  pop rcx
000079035dddfdc6  pop rax
000079035dddfdc7  add rsp, 0x08
000079035dddfdcb  jmp 0x000079035DDDED55
000079035dddfdd0  sub rsp, 0x08
000079035dddfdd4  push rax
000079035dddfdd5  push rcx
000079035dddfdd6  push rdx
000079035dddfdd7  push rdi
000079035dddfdd8  push rsi
000079035dddfdd9  push r8
000079035dddfddb  push r9
000079035dddfddd  push r10
000079035dddfddf  push r11
000079035dddfde1  sub rsp, 0xF0
000079035dddfde8  vmovaps [rsp], xmm0
000079035dddfded  vmovaps [rsp+0x10], xmm1
000079035dddfdf3  vmovaps [rsp+0x20], xmm2
000079035dddfdf9  vmovaps [rsp+0x30], xmm3
000079035dddfdff  vmovaps [rsp+0x40], xmm4
000079035dddfe05  vmovaps [rsp+0x50], xmm5
000079035dddfe0b  vmovaps [rsp+0x60], xmm6
000079035dddfe11  vmovaps [rsp+0x70], xmm7
000079035dddfe17  vmovaps [rsp+0x80], xmm8
000079035dddfe20  vmovaps [rsp+0x90], xmm10
000079035dddfe29  vmovaps [rsp+0xA0], xmm11
000079035dddfe32  vmovaps [rsp+0xB0], xmm12
000079035dddfe3b  vmovaps [rsp+0xC0], xmm13
000079035dddfe44  vmovaps [rsp+0xD0], xmm14
000079035dddfe4d  vmovaps [rsp+0xE0], xmm15
000079035dddfe56  sub rsp, 0x30
000079035dddfe5a  movaps [rsp], xmm9
000079035dddfe5f  movaps [rsp+0x10], xmm12
000079035dddfe65  movaps [rsp+0x20], xmm10
000079035dddfe6b  lea rdi, [rsp]
000079035dddfe6f  mov esi, 0x00
000079035dddfe74  mov rax, 0x64ACAA8B0530
000079035dddfe7e  call rax
000079035dddfe80  movaps xmm9, [rsp]
000079035dddfe85  add rsp, 0x30
000079035dddfe89  vmovaps xmm0, [rsp]
000079035dddfe8e  vmovaps xmm1, [rsp+0x10]
000079035dddfe94  vmovaps xmm2, [rsp+0x20]
000079035dddfe9a  vmovaps xmm3, [rsp+0x30]
000079035dddfea0  vmovaps xmm4, [rsp+0x40]
000079035dddfea6  vmovaps xmm5, [rsp+0x50]
000079035dddfeac  vmovaps xmm6, [rsp+0x60]
000079035dddfeb2  vmovaps xmm7, [rsp+0x70]
000079035dddfeb8  vmovaps xmm8, [rsp+0x80]
000079035dddfec1  vmovaps xmm10, [rsp+0x90]
000079035dddfeca  vmovaps xmm11, [rsp+0xA0]
000079035dddfed3  vmovaps xmm12, [rsp+0xB0]
000079035dddfedc  vmovaps xmm13, [rsp+0xC0]
000079035dddfee5  vmovaps xmm14, [rsp+0xD0]
000079035dddfeee  vmovaps xmm15, [rsp+0xE0]
000079035dddfef7  add rsp, 0xF0
000079035dddfefe  pop r11
000079035dddff00  pop r10
000079035dddff02  pop r9
000079035dddff04  pop r8
000079035dddff06  pop rsi
000079035dddff07  pop rdi
000079035dddff08  pop rdx
000079035dddff09  pop rcx
000079035dddff0a  pop rax
000079035dddff0b  add rsp, 0x08
000079035dddff0f  jmp 0x000079035DDDED79
000079035dddff14  sub rsp, 0x08
000079035dddff18  push rax
000079035dddff19  push rcx
000079035dddff1a  push rdx
000079035dddff1b  push rdi
000079035dddff1c  push rsi
000079035dddff1d  push r8
000079035dddff1f  push r9
000079035dddff21  push r10
000079035dddff23  push r11
000079035dddff25  sub rsp, 0xF0
000079035dddff2c  vmovaps [rsp], xmm0
000079035dddff31  vmovaps [rsp+0x10], xmm1
000079035dddff37  vmovaps [rsp+0x20], xmm2
000079035dddff3d  vmovaps [rsp+0x30], xmm3
000079035dddff43  vmovaps [rsp+0x40], xmm4
000079035dddff49  vmovaps [rsp+0x50], xmm5
000079035dddff4f  vmovaps [rsp+0x60], xmm6
000079035dddff55  vmovaps [rsp+0x70], xmm7
000079035dddff5b  vmovaps [rsp+0x80], xmm8
000079035dddff64  vmovaps [rsp+0x90], xmm9
000079035dddff6d  vmovaps [rsp+0xA0], xmm11
000079035dddff76  vmovaps [rsp+0xB0], xmm12
000079035dddff7f  vmovaps [rsp+0xC0], xmm13
000079035dddff88  vmovaps [rsp+0xD0], xmm14
000079035dddff91  vmovaps [rsp+0xE0], xmm15
000079035dddff9a  sub rsp, 0x30
000079035dddff9e  movaps [rsp], xmm10
000079035dddffa3  movaps [rsp+0x10], xmm12
000079035dddffa9  movaps [rsp+0x20], xmm11
000079035dddffaf  lea rdi, [rsp]
000079035dddffb3  mov esi, 0x00
000079035dddffb8  mov rax, 0x64ACAA8B0530
000079035dddffc2  call rax
000079035dddffc4  movaps xmm10, [rsp]
000079035dddffc9  add rsp, 0x30
000079035dddffcd  vmovaps xmm0, [rsp]
000079035dddffd2  vmovaps xmm1, [rsp+0x10]
000079035dddffd8  vmovaps xmm2, [rsp+0x20]
000079035dddffde  vmovaps xmm3, [rsp+0x30]
000079035dddffe4  vmovaps xmm4, [rsp+0x40]
000079035dddffea  vmovaps xmm5, [rsp+0x50]
000079035dddfff0  vmovaps xmm6, [rsp+0x60]
000079035dddfff6  vmovaps xmm7, [rsp+0x70]
000079035dddfffc  vmovaps xmm8, [rsp+0x80]
000079035dde0005  vmovaps xmm9, [rsp+0x90]
000079035dde000e  vmovaps xmm11, [rsp+0xA0]
000079035dde0017  vmovaps xmm12, [rsp+0xB0]
000079035dde0020  vmovaps xmm13, [rsp+0xC0]
000079035dde0029  vmovaps xmm14, [rsp+0xD0]
000079035dde0032  vmovaps xmm15, [rsp+0xE0]
000079035dde003b  add rsp, 0xF0
000079035dde0042  pop r11
000079035dde0044  pop r10
000079035dde0046  pop r9
000079035dde0048  pop r8
000079035dde004a  pop rsi
000079035dde004b  pop rdi
000079035dde004c  pop rdx
000079035dde004d  pop rcx
000079035dde004e  pop rax
000079035dde004f  add rsp, 0x08
000079035dde0053  jmp 0x000079035DDDED93
000079035dde0058  sub rsp, 0x08
000079035dde005c  push rax
000079035dde005d  push rcx
000079035dde005e  push rdx
000079035dde005f  push rdi
000079035dde0060  push rsi
000079035dde0061  push r8
000079035dde0063  push r9
000079035dde0065  push r10
000079035dde0067  push r11
000079035dde0069  sub rsp, 0xF0
000079035dde0070  vmovaps [rsp], xmm0
000079035dde0075  vmovaps [rsp+0x10], xmm1
000079035dde007b  vmovaps [rsp+0x20], xmm2
000079035dde0081  vmovaps [rsp+0x30], xmm3
000079035dde0087  vmovaps [rsp+0x40], xmm4
000079035dde008d  vmovaps [rsp+0x50], xmm5
000079035dde0093  vmovaps [rsp+0x60], xmm7
000079035dde0099  vmovaps [rsp+0x70], xmm8
000079035dde009f  vmovaps [rsp+0x80], xmm9
000079035dde00a8  vmovaps [rsp+0x90], xmm10
000079035dde00b1  vmovaps [rsp+0xA0], xmm11
000079035dde00ba  vmovaps [rsp+0xB0], xmm12
000079035dde00c3  vmovaps [rsp+0xC0], xmm13
000079035dde00cc  vmovaps [rsp+0xD0], xmm14
000079035dde00d5  vmovaps [rsp+0xE0], xmm15
000079035dde00de  sub rsp, 0x30
000079035dde00e2  movaps [rsp], xmm6
000079035dde00e6  movaps [rsp+0x10], xmm12
000079035dde00ec  movaps [rsp+0x20], xmm11
000079035dde00f2  lea rdi, [rsp]
000079035dde00f6  mov esi, 0x00
000079035dde00fb  mov rax, 0x64ACAA8B0530
000079035dde0105  call rax
000079035dde0107  movaps xmm6, [rsp]
000079035dde010b  add rsp, 0x30
000079035dde010f  vmovaps xmm0, [rsp]
000079035dde0114  vmovaps xmm1, [rsp+0x10]
000079035dde011a  vmovaps xmm2, [rsp+0x20]
000079035dde0120  vmovaps xmm3, [rsp+0x30]
000079035dde0126  vmovaps xmm4, [rsp+0x40]
000079035dde012c  vmovaps xmm5, [rsp+0x50]
000079035dde0132  vmovaps xmm7, [rsp+0x60]
000079035dde0138  vmovaps xmm8, [rsp+0x70]
000079035dde013e  vmovaps xmm9, [rsp+0x80]
000079035dde0147  vmovaps xmm10, [rsp+0x90]
000079035dde0150  vmovaps xmm11, [rsp+0xA0]
000079035dde0159  vmovaps xmm12, [rsp+0xB0]
000079035dde0162  vmovaps xmm13, [rsp+0xC0]
000079035dde016b  vmovaps xmm14, [rsp+0xD0]
000079035dde0174  vmovaps xmm15, [rsp+0xE0]
000079035dde017d  add rsp, 0xF0
000079035dde0184  pop r11
000079035dde0186  pop r10
000079035dde0188  pop r9
000079035dde018a  pop r8
000079035dde018c  pop rsi
000079035dde018d  pop rdi
000079035dde018e  pop rdx
000079035dde018f  pop rcx
000079035dde0190  pop rax
000079035dde0191  add rsp, 0x08
000079035dde0195  jmp 0x000079035DDDEDB4
000079035dde019a  sub rsp, 0x08
000079035dde019e  push rax
000079035dde019f  push rcx
000079035dde01a0  push rdx
000079035dde01a1  push rdi
000079035dde01a2  push rsi
000079035dde01a3  push r8
000079035dde01a5  push r9
000079035dde01a7  push r10
000079035dde01a9  push r11
000079035dde01ab  sub rsp, 0xF0
000079035dde01b2  vmovaps [rsp], xmm0
000079035dde01b7  vmovaps [rsp+0x10], xmm1
000079035dde01bd  vmovaps [rsp+0x20], xmm2
000079035dde01c3  vmovaps [rsp+0x30], xmm4
000079035dde01c9  vmovaps [rsp+0x40], xmm5
000079035dde01cf  vmovaps [rsp+0x50], xmm6
000079035dde01d5  vmovaps [rsp+0x60], xmm7
000079035dde01db  vmovaps [rsp+0x70], xmm8
000079035dde01e1  vmovaps [rsp+0x80], xmm9
000079035dde01ea  vmovaps [rsp+0x90], xmm10
000079035dde01f3  vmovaps [rsp+0xA0], xmm11
000079035dde01fc  vmovaps [rsp+0xB0], xmm12
000079035dde0205  vmovaps [rsp+0xC0], xmm13
000079035dde020e  vmovaps [rsp+0xD0], xmm14
000079035dde0217  vmovaps [rsp+0xE0], xmm15
000079035dde0220  sub rsp, 0x30
000079035dde0224  movaps [rsp], xmm3
000079035dde0228  movaps [rsp+0x10], xmm5
000079035dde022d  movaps [rsp+0x20], xmm4
000079035dde0232  lea rdi, [rsp]
000079035dde0236  mov esi, 0x00
000079035dde023b  mov rax, 0x64ACAA8B0530
000079035dde0245  call rax
000079035dde0247  movaps xmm3, [rsp]
000079035dde024b  add rsp, 0x30
000079035dde024f  vmovaps xmm0, [rsp]
000079035dde0254  vmovaps xmm1, [rsp+0x10]
000079035dde025a  vmovaps xmm2, [rsp+0x20]
000079035dde0260  vmovaps xmm4, [rsp+0x30]
000079035dde0266  vmovaps xmm5, [rsp+0x40]
000079035dde026c  vmovaps xmm6, [rsp+0x50]
000079035dde0272  vmovaps xmm7, [rsp+0x60]
000079035dde0278  vmovaps xmm8, [rsp+0x70]
000079035dde027e  vmovaps xmm9, [rsp+0x80]
000079035dde0287  vmovaps xmm10, [rsp+0x90]
000079035dde0290  vmovaps xmm11, [rsp+0xA0]
000079035dde0299  vmovaps xmm12, [rsp+0xB0]
000079035dde02a2  vmovaps xmm13, [rsp+0xC0]
000079035dde02ab  vmovaps xmm14, [rsp+0xD0]
000079035dde02b4  vmovaps xmm15, [rsp+0xE0]
000079035dde02bd  add rsp, 0xF0
000079035dde02c4  pop r11
000079035dde02c6  pop r10
000079035dde02c8  pop r9
000079035dde02ca  pop r8
000079035dde02cc  pop rsi
000079035dde02cd  pop rdi
000079035dde02ce  pop rdx
000079035dde02cf  pop rcx
000079035dde02d0  pop rax
000079035dde02d1  add rsp, 0x08
000079035dde02d5  jmp 0x000079035DDDEE15
000079035dde02da  sub rsp, 0x08
000079035dde02de  push rax
000079035dde02df  push rcx
000079035dde02e0  push rdx
000079035dde02e1  push rdi
000079035dde02e2  push rsi
000079035dde02e3  push r8
000079035dde02e5  push r9
000079035dde02e7  push r10
000079035dde02e9  push r11
000079035dde02eb  sub rsp, 0xF0
000079035dde02f2  vmovaps [rsp], xmm0
000079035dde02f7  vmovaps [rsp+0x10], xmm1
000079035dde02fd  vmovaps [rsp+0x20], xmm2
000079035dde0303  vmovaps [rsp+0x30], xmm3
000079035dde0309  vmovaps [rsp+0x40], xmm4
000079035dde030f  vmovaps [rsp+0x50], xmm6
000079035dde0315  vmovaps [rsp+0x60], xmm7
000079035dde031b  vmovaps [rsp+0x70], xmm8
000079035dde0321  vmovaps [rsp+0x80], xmm9
000079035dde032a  vmovaps [rsp+0x90], xmm10
000079035dde0333  vmovaps [rsp+0xA0], xmm11
000079035dde033c  vmovaps [rsp+0xB0], xmm12
000079035dde0345  vmovaps [rsp+0xC0], xmm13
000079035dde034e  vmovaps [rsp+0xD0], xmm14
000079035dde0357  vmovaps [rsp+0xE0], xmm15
000079035dde0360  sub rsp, 0x30
000079035dde0364  movaps [rsp], xmm5
000079035dde0368  movaps [rsp+0x10], xmm8
000079035dde036e  movaps [rsp+0x20], xmm15
000079035dde0374  lea rdi, [rsp]
000079035dde0378  mov esi, 0x00
000079035dde037d  mov rax, 0x64ACAA8B0530
000079035dde0387  call rax
000079035dde0389  movaps xmm5, [rsp]
000079035dde038d  add rsp, 0x30
000079035dde0391  vmovaps xmm0, [rsp]
000079035dde0396  vmovaps xmm1, [rsp+0x10]
000079035dde039c  vmovaps xmm2, [rsp+0x20]
000079035dde03a2  vmovaps xmm3, [rsp+0x30]
000079035dde03a8  vmovaps xmm4, [rsp+0x40]
000079035dde03ae  vmovaps xmm6, [rsp+0x50]
000079035dde03b4  vmovaps xmm7, [rsp+0x60]
000079035dde03ba  vmovaps xmm8, [rsp+0x70]
000079035dde03c0  vmovaps xmm9, [rsp+0x80]
000079035dde03c9  vmovaps xmm10, [rsp+0x90]
000079035dde03d2  vmovaps xmm11, [rsp+0xA0]
000079035dde03db  vmovaps xmm12, [rsp+0xB0]
000079035dde03e4  vmovaps xmm13, [rsp+0xC0]
000079035dde03ed  vmovaps xmm14, [rsp+0xD0]
000079035dde03f6  vmovaps xmm15, [rsp+0xE0]
000079035dde03ff  add rsp, 0xF0
000079035dde0406  pop r11
000079035dde0408  pop r10
000079035dde040a  pop r9
000079035dde040c  pop r8
000079035dde040e  pop rsi
000079035dde040f  pop rdi
000079035dde0410  pop rdx
000079035dde0411  pop rcx
000079035dde0412  pop rax
000079035dde0413  add rsp, 0x08
000079035dde0417  jmp 0x000079035DDDEE53
000079035dde041c  sub rsp, 0x08
000079035dde0420  push rax
000079035dde0421  push rcx
000079035dde0422  push rdx
000079035dde0423  push rdi
000079035dde0424  push rsi
000079035dde0425  push r8
000079035dde0427  push r9
000079035dde0429  push r10
000079035dde042b  push r11
000079035dde042d  sub rsp, 0xF0
000079035dde0434  vmovaps [rsp], xmm0
000079035dde0439  vmovaps [rsp+0x10], xmm1
000079035dde043f  vmovaps [rsp+0x20], xmm2
000079035dde0445  vmovaps [rsp+0x30], xmm3
000079035dde044b  vmovaps [rsp+0x40], xmm5
000079035dde0451  vmovaps [rsp+0x50], xmm6
000079035dde0457  vmovaps [rsp+0x60], xmm7
000079035dde045d  vmovaps [rsp+0x70], xmm8
000079035dde0463  vmovaps [rsp+0x80], xmm9
000079035dde046c  vmovaps [rsp+0x90], xmm10
000079035dde0475  vmovaps [rsp+0xA0], xmm11
000079035dde047e  vmovaps [rsp+0xB0], xmm12
000079035dde0487  vmovaps [rsp+0xC0], xmm13
000079035dde0490  vmovaps [rsp+0xD0], xmm14
000079035dde0499  vmovaps [rsp+0xE0], xmm15
000079035dde04a2  sub rsp, 0x30
000079035dde04a6  movaps [rsp], xmm4
000079035dde04aa  movaps [rsp+0x10], xmm9
000079035dde04b0  movaps [rsp+0x20], xmm8
000079035dde04b6  lea rdi, [rsp]
000079035dde04ba  mov esi, 0x00
000079035dde04bf  mov rax, 0x64ACAA8B0530
000079035dde04c9  call rax
000079035dde04cb  movaps xmm4, [rsp]
000079035dde04cf  add rsp, 0x30
000079035dde04d3  vmovaps xmm0, [rsp]
000079035dde04d8  vmovaps xmm1, [rsp+0x10]
000079035dde04de  vmovaps xmm2, [rsp+0x20]
000079035dde04e4  vmovaps xmm3, [rsp+0x30]
000079035dde04ea  vmovaps xmm5, [rsp+0x40]
000079035dde04f0  vmovaps xmm6, [rsp+0x50]
000079035dde04f6  vmovaps xmm7, [rsp+0x60]
000079035dde04fc  vmovaps xmm8, [rsp+0x70]
000079035dde0502  vmovaps xmm9, [rsp+0x80]
000079035dde050b  vmovaps xmm10, [rsp+0x90]
000079035dde0514  vmovaps xmm11, [rsp+0xA0]
000079035dde051d  vmovaps xmm12, [rsp+0xB0]
000079035dde0526  vmovaps xmm13, [rsp+0xC0]
000079035dde052f  vmovaps xmm14, [rsp+0xD0]
000079035dde0538  vmovaps xmm15, [rsp+0xE0]
000079035dde0541  add rsp, 0xF0
000079035dde0548  pop r11
000079035dde054a  pop r10
000079035dde054c  pop r9
000079035dde054e  pop r8
000079035dde0550  pop rsi
000079035dde0551  pop rdi
000079035dde0552  pop rdx
000079035dde0553  pop rcx
000079035dde0554  pop rax
000079035dde0555  add rsp, 0x08
000079035dde0559  jmp 0x000079035DDDEE74
000079035dde055e  sub rsp, 0x08
000079035dde0562  push rax
000079035dde0563  push rcx
000079035dde0564  push rdx
000079035dde0565  push rdi
000079035dde0566  push rsi
000079035dde0567  push r8
000079035dde0569  push r9
000079035dde056b  push r10
000079035dde056d  push r11
000079035dde056f  sub rsp, 0xF0
000079035dde0576  vmovaps [rsp], xmm0
000079035dde057b  vmovaps [rsp+0x10], xmm1
000079035dde0581  vmovaps [rsp+0x20], xmm2
000079035dde0587  vmovaps [rsp+0x30], xmm3
000079035dde058d  vmovaps [rsp+0x40], xmm4
000079035dde0593  vmovaps [rsp+0x50], xmm5
000079035dde0599  vmovaps [rsp+0x60], xmm6
000079035dde059f  vmovaps [rsp+0x70], xmm7
000079035dde05a5  vmovaps [rsp+0x80], xmm8
000079035dde05ae  vmovaps [rsp+0x90], xmm10
000079035dde05b7  vmovaps [rsp+0xA0], xmm11
000079035dde05c0  vmovaps [rsp+0xB0], xmm12
000079035dde05c9  vmovaps [rsp+0xC0], xmm13
000079035dde05d2  vmovaps [rsp+0xD0], xmm14
000079035dde05db  vmovaps [rsp+0xE0], xmm15
000079035dde05e4  sub rsp, 0x30
000079035dde05e8  movaps [rsp], xmm9
000079035dde05ed  movaps [rsp+0x10], xmm10
000079035dde05f3  movaps [rsp+0x20], xmm8
000079035dde05f9  lea rdi, [rsp]
000079035dde05fd  mov esi, 0x00
000079035dde0602  mov rax, 0x64ACAA8B0530
000079035dde060c  call rax
000079035dde060e  movaps xmm9, [rsp]
000079035dde0613  add rsp, 0x30
000079035dde0617  vmovaps xmm0, [rsp]
000079035dde061c  vmovaps xmm1, [rsp+0x10]
000079035dde0622  vmovaps xmm2, [rsp+0x20]
000079035dde0628  vmovaps xmm3, [rsp+0x30]
000079035dde062e  vmovaps xmm4, [rsp+0x40]
000079035dde0634  vmovaps xmm5, [rsp+0x50]
000079035dde063a  vmovaps xmm6, [rsp+0x60]
000079035dde0640  vmovaps xmm7, [rsp+0x70]
000079035dde0646  vmovaps xmm8, [rsp+0x80]
000079035dde064f  vmovaps xmm10, [rsp+0x90]
000079035dde0658  vmovaps xmm11, [rsp+0xA0]
000079035dde0661  vmovaps xmm12, [rsp+0xB0]
000079035dde066a  vmovaps xmm13, [rsp+0xC0]
000079035dde0673  vmovaps xmm14, [rsp+0xD0]
000079035dde067c  vmovaps xmm15, [rsp+0xE0]
000079035dde0685  add rsp, 0xF0
000079035dde068c  pop r11
000079035dde068e  pop r10
000079035dde0690  pop r9
000079035dde0692  pop r8
000079035dde0694  pop rsi
000079035dde0695  pop rdi
000079035dde0696  pop rdx
000079035dde0697  pop rcx
000079035dde0698  pop rax
000079035dde0699  add rsp, 0x08
000079035dde069d  jmp 0x000079035DDDEE8E
000079035dde06a2  call 0x000079035DCB52F0
000079035dde06a7  jmp 0x000079035DDDEFA8
000079035dde06ac  call 0x000079035DCB52F0
000079035dde06b1  jmp 0x000079035DDDEFBE
000079035dde06b6  sub rsp, 0x08
000079035dde06ba  push rax
000079035dde06bb  push rcx
000079035dde06bc  push rdx
000079035dde06bd  push rdi
000079035dde06be  push rsi
000079035dde06bf  push r8
000079035dde06c1  push r9
000079035dde06c3  push r10
000079035dde06c5  push r11
000079035dde06c7  sub rsp, 0xF0
000079035dde06ce  vmovaps [rsp], xmm0
000079035dde06d3  vmovaps [rsp+0x10], xmm2
000079035dde06d9  vmovaps [rsp+0x20], xmm3
000079035dde06df  vmovaps [rsp+0x30], xmm4
000079035dde06e5  vmovaps [rsp+0x40], xmm5
000079035dde06eb  vmovaps [rsp+0x50], xmm6
000079035dde06f1  vmovaps [rsp+0x60], xmm7
000079035dde06f7  vmovaps [rsp+0x70], xmm8
000079035dde06fd  vmovaps [rsp+0x80], xmm9
000079035dde0706  vmovaps [rsp+0x90], xmm10
000079035dde070f  vmovaps [rsp+0xA0], xmm11
000079035dde0718  vmovaps [rsp+0xB0], xmm12
000079035dde0721  vmovaps [rsp+0xC0], xmm13
000079035dde072a  vmovaps [rsp+0xD0], xmm14
000079035dde0733  vmovaps [rsp+0xE0], xmm15
000079035dde073c  sub rsp, 0x30
000079035dde0740  movaps [rsp], xmm1
000079035dde0744  movaps [rsp+0x10], xmm6
000079035dde0749  movaps [rsp+0x20], xmm15
000079035dde074f  lea rdi, [rsp]
000079035dde0753  mov esi, 0x00
000079035dde0758  mov rax, 0x64ACAA8B0530
000079035dde0762  call rax
000079035dde0764  movaps xmm1, [rsp]
000079035dde0768  add rsp, 0x30
000079035dde076c  vmovaps xmm0, [rsp]
000079035dde0771  vmovaps xmm2, [rsp+0x10]
000079035dde0777  vmovaps xmm3, [rsp+0x20]
000079035dde077d  vmovaps xmm4, [rsp+0x30]
000079035dde0783  vmovaps xmm5, [rsp+0x40]
000079035dde0789  vmovaps xmm6, [rsp+0x50]
000079035dde078f  vmovaps xmm7, [rsp+0x60]
000079035dde0795  vmovaps xmm8, [rsp+0x70]
000079035dde079b  vmovaps xmm9, [rsp+0x80]
000079035dde07a4  vmovaps xmm10, [rsp+0x90]
000079035dde07ad  vmovaps xmm11, [rsp+0xA0]
000079035dde07b6  vmovaps xmm12, [rsp+0xB0]
000079035dde07bf  vmovaps xmm13, [rsp+0xC0]
000079035dde07c8  vmovaps xmm14, [rsp+0xD0]
000079035dde07d1  vmovaps xmm15, [rsp+0xE0]
000079035dde07da  add rsp, 0xF0
000079035dde07e1  pop r11
000079035dde07e3  pop r10
000079035dde07e5  pop r9
000079035dde07e7  pop r8
000079035dde07e9  pop rsi
000079035dde07ea  pop rdi
000079035dde07eb  pop rdx
000079035dde07ec  pop rcx
000079035dde07ed  pop rax
000079035dde07ee  add rsp, 0x08
000079035dde07f2  jmp 0x000079035DDDEFFB
000079035dde07f7  call 0x000079035DCC4620
000079035dde07fc  jmp 0x000079035DDDF008
000079035dde0801  sub rsp, 0x08
000079035dde0805  push rax
000079035dde0806  push rcx
000079035dde0807  push rdx
000079035dde0808  push rdi
000079035dde0809  push rsi
000079035dde080a  push r8
000079035dde080c  push r9
000079035dde080e  push r10
000079035dde0810  push r11
000079035dde0812  sub rsp, 0xF0
000079035dde0819  vmovaps [rsp], xmm0
000079035dde081e  vmovaps [rsp+0x10], xmm1
000079035dde0824  vmovaps [rsp+0x20], xmm2
000079035dde082a  vmovaps [rsp+0x30], xmm3
000079035dde0830  vmovaps [rsp+0x40], xmm4
000079035dde0836  vmovaps [rsp+0x50], xmm5
000079035dde083c  vmovaps [rsp+0x60], xmm6
000079035dde0842  vmovaps [rsp+0x70], xmm7
000079035dde0848  vmovaps [rsp+0x80], xmm8
000079035dde0851  vmovaps [rsp+0x90], xmm9
000079035dde085a  vmovaps [rsp+0xA0], xmm10
000079035dde0863  vmovaps [rsp+0xB0], xmm11
000079035dde086c  vmovaps [rsp+0xC0], xmm12
000079035dde0875  vmovaps [rsp+0xD0], xmm13
000079035dde087e  vmovaps [rsp+0xE0], xmm15
000079035dde0887  sub rsp, 0x30
000079035dde088b  movaps [rsp], xmm14
000079035dde0890  movaps [rsp+0x10], xmm4
000079035dde0895  movaps [rsp+0x20], xmm3
000079035dde089a  lea rdi, [rsp]
000079035dde089e  mov esi, 0x00
000079035dde08a3  mov rax, 0x64ACAA8B0530
000079035dde08ad  call rax
000079035dde08af  movaps xmm14, [rsp]
000079035dde08b4  add rsp, 0x30
000079035dde08b8  vmovaps xmm0, [rsp]
000079035dde08bd  vmovaps xmm1, [rsp+0x10]
000079035dde08c3  vmovaps xmm2, [rsp+0x20]
000079035dde08c9  vmovaps xmm3, [rsp+0x30]
000079035dde08cf  vmovaps xmm4, [rsp+0x40]
000079035dde08d5  vmovaps xmm5, [rsp+0x50]
000079035dde08db  vmovaps xmm6, [rsp+0x60]
000079035dde08e1  vmovaps xmm7, [rsp+0x70]
000079035dde08e7  vmovaps xmm8, [rsp+0x80]
000079035dde08f0  vmovaps xmm9, [rsp+0x90]
000079035dde08f9  vmovaps xmm10, [rsp+0xA0]
000079035dde0902  vmovaps xmm11, [rsp+0xB0]
000079035dde090b  vmovaps xmm12, [rsp+0xC0]
000079035dde0914  vmovaps xmm13, [rsp+0xD0]
000079035dde091d  vmovaps xmm15, [rsp+0xE0]
000079035dde0926  add rsp, 0xF0
000079035dde092d  pop r11
000079035dde092f  pop r10
000079035dde0931  pop r9
000079035dde0933  pop r8
000079035dde0935  pop rsi
000079035dde0936  pop rdi
000079035dde0937  pop rdx
000079035dde0938  pop rcx
000079035dde0939  pop rax
000079035dde093a  add rsp, 0x08
000079035dde093e  jmp 0x000079035DDDF022
000079035dde0943  sub rsp, 0x08
000079035dde0947  push rax
000079035dde0948  push rcx
000079035dde0949  push rdx
000079035dde094a  push rdi
000079035dde094b  push rsi
000079035dde094c  push r8
000079035dde094e  push r9
000079035dde0950  push r10
000079035dde0952  push r11
000079035dde0954  sub rsp, 0xF0
000079035dde095b  vmovaps [rsp], xmm0
000079035dde0960  vmovaps [rsp+0x10], xmm1
000079035dde0966  vmovaps [rsp+0x20], xmm2
000079035dde096c  vmovaps [rsp+0x30], xmm3
000079035dde0972  vmovaps [rsp+0x40], xmm4
000079035dde0978  vmovaps [rsp+0x50], xmm5
000079035dde097e  vmovaps [rsp+0x60], xmm7
000079035dde0984  vmovaps [rsp+0x70], xmm8
000079035dde098a  vmovaps [rsp+0x80], xmm9
000079035dde0993  vmovaps [rsp+0x90], xmm10
000079035dde099c  vmovaps [rsp+0xA0], xmm11
000079035dde09a5  vmovaps [rsp+0xB0], xmm12
000079035dde09ae  vmovaps [rsp+0xC0], xmm13
000079035dde09b7  vmovaps [rsp+0xD0], xmm14
000079035dde09c0  vmovaps [rsp+0xE0], xmm15
000079035dde09c9  sub rsp, 0x30
000079035dde09cd  movaps [rsp], xmm6
000079035dde09d1  movaps [rsp+0x10], xmm9
000079035dde09d7  movaps [rsp+0x20], xmm7
000079035dde09dc  lea rdi, [rsp]
000079035dde09e0  mov esi, 0x00
000079035dde09e5  mov rax, 0x64ACAA8B0530
000079035dde09ef  call rax
000079035dde09f1  movaps xmm6, [rsp]
000079035dde09f5  add rsp, 0x30
000079035dde09f9  vmovaps xmm0, [rsp]
000079035dde09fe  vmovaps xmm1, [rsp+0x10]
000079035dde0a04  vmovaps xmm2, [rsp+0x20]
000079035dde0a0a  vmovaps xmm3, [rsp+0x30]
000079035dde0a10  vmovaps xmm4, [rsp+0x40]
000079035dde0a16  vmovaps xmm5, [rsp+0x50]
000079035dde0a1c  vmovaps xmm7, [rsp+0x60]
000079035dde0a22  vmovaps xmm8, [rsp+0x70]
000079035dde0a28  vmovaps xmm9, [rsp+0x80]
000079035dde0a31  vmovaps xmm10, [rsp+0x90]
000079035dde0a3a  vmovaps xmm11, [rsp+0xA0]
000079035dde0a43  vmovaps xmm12, [rsp+0xB0]
000079035dde0a4c  vmovaps xmm13, [rsp+0xC0]
000079035dde0a55  vmovaps xmm14, [rsp+0xD0]
000079035dde0a5e  vmovaps xmm15, [rsp+0xE0]
000079035dde0a67  add rsp, 0xF0
000079035dde0a6e  pop r11
000079035dde0a70  pop r10
000079035dde0a72  pop r9
000079035dde0a74  pop r8
000079035dde0a76  pop rsi
000079035dde0a77  pop rdi
000079035dde0a78  pop rdx
000079035dde0a79  pop rcx
000079035dde0a7a  pop rax
000079035dde0a7b  add rsp, 0x08
000079035dde0a7f  jmp 0x000079035DDDF03A
000079035dde0a84  sub rsp, 0x08
000079035dde0a88  push rax
000079035dde0a89  push rcx
000079035dde0a8a  push rdx
000079035dde0a8b  push rdi
000079035dde0a8c  push rsi
000079035dde0a8d  push r8
000079035dde0a8f  push r9
000079035dde0a91  push r10
000079035dde0a93  push r11
000079035dde0a95  sub rsp, 0xF0
000079035dde0a9c  vmovaps [rsp], xmm0
000079035dde0aa1  vmovaps [rsp+0x10], xmm1
000079035dde0aa7  vmovaps [rsp+0x20], xmm2
000079035dde0aad  vmovaps [rsp+0x30], xmm3
000079035dde0ab3  vmovaps [rsp+0x40], xmm4
000079035dde0ab9  vmovaps [rsp+0x50], xmm5
000079035dde0abf  vmovaps [rsp+0x60], xmm6
000079035dde0ac5  vmovaps [rsp+0x70], xmm8
000079035dde0acb  vmovaps [rsp+0x80], xmm9
000079035dde0ad4  vmovaps [rsp+0x90], xmm10
000079035dde0add  vmovaps [rsp+0xA0], xmm11
000079035dde0ae6  vmovaps [rsp+0xB0], xmm12
000079035dde0aef  vmovaps [rsp+0xC0], xmm13
000079035dde0af8  vmovaps [rsp+0xD0], xmm14
000079035dde0b01  vmovaps [rsp+0xE0], xmm15
000079035dde0b0a  sub rsp, 0x30
000079035dde0b0e  movaps [rsp], xmm7
000079035dde0b12  movaps [rsp+0x10], xmm4
000079035dde0b17  movaps [rsp+0x20], xmm9
000079035dde0b1d  lea rdi, [rsp]
000079035dde0b21  mov esi, 0x00
000079035dde0b26  mov rax, 0x64ACAA8B0530
000079035dde0b30  call rax
000079035dde0b32  movaps xmm7, [rsp]
000079035dde0b36  add rsp, 0x30
000079035dde0b3a  vmovaps xmm0, [rsp]
000079035dde0b3f  vmovaps xmm1, [rsp+0x10]
000079035dde0b45  vmovaps xmm2, [rsp+0x20]
000079035dde0b4b  vmovaps xmm3, [rsp+0x30]
000079035dde0b51  vmovaps xmm4, [rsp+0x40]
000079035dde0b57  vmovaps xmm5, [rsp+0x50]
000079035dde0b5d  vmovaps xmm6, [rsp+0x60]
000079035dde0b63  vmovaps xmm8, [rsp+0x70]
000079035dde0b69  vmovaps xmm9, [rsp+0x80]
000079035dde0b72  vmovaps xmm10, [rsp+0x90]
000079035dde0b7b  vmovaps xmm11, [rsp+0xA0]
000079035dde0b84  vmovaps xmm12, [rsp+0xB0]
000079035dde0b8d  vmovaps xmm13, [rsp+0xC0]
000079035dde0b96  vmovaps xmm14, [rsp+0xD0]
000079035dde0b9f  vmovaps xmm15, [rsp+0xE0]
000079035dde0ba8  add rsp, 0xF0
000079035dde0baf  pop r11
000079035dde0bb1  pop r10
000079035dde0bb3  pop r9
000079035dde0bb5  pop r8
000079035dde0bb7  pop rsi
000079035dde0bb8  pop rdi
000079035dde0bb9  pop rdx
000079035dde0bba  pop rcx
000079035dde0bbb  pop rax
000079035dde0bbc  add rsp, 0x08
000079035dde0bc0  jmp 0x000079035DDDF067
000079035dde0bc5  sub rsp, 0x08
000079035dde0bc9  push rax
000079035dde0bca  push rcx
000079035dde0bcb  push rdx
000079035dde0bcc  push rdi
000079035dde0bcd  push rsi
000079035dde0bce  push r8
000079035dde0bd0  push r9
000079035dde0bd2  push r10
000079035dde0bd4  push r11
000079035dde0bd6  sub rsp, 0xF0
000079035dde0bdd  vmovaps [rsp], xmm0
000079035dde0be2  vmovaps [rsp+0x10], xmm1
000079035dde0be8  vmovaps [rsp+0x20], xmm2
000079035dde0bee  vmovaps [rsp+0x30], xmm3
000079035dde0bf4  vmovaps [rsp+0x40], xmm5
000079035dde0bfa  vmovaps [rsp+0x50], xmm6
000079035dde0c00  vmovaps [rsp+0x60], xmm7
000079035dde0c06  vmovaps [rsp+0x70], xmm8
000079035dde0c0c  vmovaps [rsp+0x80], xmm9
000079035dde0c15  vmovaps [rsp+0x90], xmm10
000079035dde0c1e  vmovaps [rsp+0xA0], xmm11
000079035dde0c27  vmovaps [rsp+0xB0], xmm12
000079035dde0c30  vmovaps [rsp+0xC0], xmm13
000079035dde0c39  vmovaps [rsp+0xD0], xmm14
000079035dde0c42  vmovaps [rsp+0xE0], xmm15
000079035dde0c4b  sub rsp, 0x30
000079035dde0c4f  movaps [rsp], xmm4
000079035dde0c53  movaps [rsp+0x10], xmm15
000079035dde0c59  movaps [rsp+0x20], xmm9
000079035dde0c5f  lea rdi, [rsp]
000079035dde0c63  mov esi, 0x00
000079035dde0c68  mov rax, 0x64ACAA8B0530
000079035dde0c72  call rax
000079035dde0c74  movaps xmm4, [rsp]
000079035dde0c78  add rsp, 0x30
000079035dde0c7c  vmovaps xmm0, [rsp]
000079035dde0c81  vmovaps xmm1, [rsp+0x10]
000079035dde0c87  vmovaps xmm2, [rsp+0x20]
000079035dde0c8d  vmovaps xmm3, [rsp+0x30]
000079035dde0c93  vmovaps xmm5, [rsp+0x40]
000079035dde0c99  vmovaps xmm6, [rsp+0x50]
000079035dde0c9f  vmovaps xmm7, [rsp+0x60]
000079035dde0ca5  vmovaps xmm8, [rsp+0x70]
000079035dde0cab  vmovaps xmm9, [rsp+0x80]
000079035dde0cb4  vmovaps xmm10, [rsp+0x90]
000079035dde0cbd  vmovaps xmm11, [rsp+0xA0]
000079035dde0cc6  vmovaps xmm12, [rsp+0xB0]
000079035dde0ccf  vmovaps xmm13, [rsp+0xC0]
000079035dde0cd8  vmovaps xmm14, [rsp+0xD0]
000079035dde0ce1  vmovaps xmm15, [rsp+0xE0]
000079035dde0cea  add rsp, 0xF0
000079035dde0cf1  pop r11
000079035dde0cf3  pop r10
000079035dde0cf5  pop r9
000079035dde0cf7  pop r8
000079035dde0cf9  pop rsi
000079035dde0cfa  pop rdi
000079035dde0cfb  pop rdx
000079035dde0cfc  pop rcx
000079035dde0cfd  pop rax
000079035dde0cfe  add rsp, 0x08
000079035dde0d02  jmp 0x000079035DDDF08C
000079035dde0d07  call 0x000079035DCC4620
000079035dde0d0c  jmp 0x000079035DDDF099
000079035dde0d11  sub rsp, 0x08
000079035dde0d15  push rax
000079035dde0d16  push rcx
000079035dde0d17  push rdx
000079035dde0d18  push rdi
000079035dde0d19  push rsi
000079035dde0d1a  push r8
000079035dde0d1c  push r9
000079035dde0d1e  push r10
000079035dde0d20  push r11
000079035dde0d22  sub rsp, 0xF0
000079035dde0d29  vmovaps [rsp], xmm0
000079035dde0d2e  vmovaps [rsp+0x10], xmm1
000079035dde0d34  vmovaps [rsp+0x20], xmm2
000079035dde0d3a  vmovaps [rsp+0x30], xmm4
000079035dde0d40  vmovaps [rsp+0x40], xmm5
000079035dde0d46  vmovaps [rsp+0x50], xmm6
000079035dde0d4c  vmovaps [rsp+0x60], xmm7
000079035dde0d52  vmovaps [rsp+0x70], xmm8
000079035dde0d58  vmovaps [rsp+0x80], xmm9
000079035dde0d61  vmovaps [rsp+0x90], xmm10
000079035dde0d6a  vmovaps [rsp+0xA0], xmm11
000079035dde0d73  vmovaps [rsp+0xB0], xmm12
000079035dde0d7c  vmovaps [rsp+0xC0], xmm13
000079035dde0d85  vmovaps [rsp+0xD0], xmm14
000079035dde0d8e  vmovaps [rsp+0xE0], xmm15
000079035dde0d97  sub rsp, 0x30
000079035dde0d9b  movaps [rsp], xmm3
000079035dde0d9f  movaps [rsp+0x10], xmm1
000079035dde0da4  movaps [rsp+0x20], xmm9
000079035dde0daa  lea rdi, [rsp]
000079035dde0dae  mov esi, 0x00
000079035dde0db3  mov rax, 0x64ACAA8B0530
000079035dde0dbd  call rax
000079035dde0dbf  movaps xmm3, [rsp]
000079035dde0dc3  add rsp, 0x30
000079035dde0dc7  vmovaps xmm0, [rsp]
000079035dde0dcc  vmovaps xmm1, [rsp+0x10]
000079035dde0dd2  vmovaps xmm2, [rsp+0x20]
000079035dde0dd8  vmovaps xmm4, [rsp+0x30]
000079035dde0dde  vmovaps xmm5, [rsp+0x40]
000079035dde0de4  vmovaps xmm6, [rsp+0x50]
000079035dde0dea  vmovaps xmm7, [rsp+0x60]
000079035dde0df0  vmovaps xmm8, [rsp+0x70]
000079035dde0df6  vmovaps xmm9, [rsp+0x80]
000079035dde0dff  vmovaps xmm10, [rsp+0x90]
000079035dde0e08  vmovaps xmm11, [rsp+0xA0]
000079035dde0e11  vmovaps xmm12, [rsp+0xB0]
000079035dde0e1a  vmovaps xmm13, [rsp+0xC0]
000079035dde0e23  vmovaps xmm14, [rsp+0xD0]
000079035dde0e2c  vmovaps xmm15, [rsp+0xE0]
000079035dde0e35  add rsp, 0xF0
000079035dde0e3c  pop r11
000079035dde0e3e  pop r10
000079035dde0e40  pop r9
000079035dde0e42  pop r8
000079035dde0e44  pop rsi
000079035dde0e45  pop rdi
000079035dde0e46  pop rdx
000079035dde0e47  pop rcx
000079035dde0e48  pop rax
000079035dde0e49  add rsp, 0x08
000079035dde0e4d  jmp 0x000079035DDDF0D6
000079035dde0e52  sub rsp, 0x08
000079035dde0e56  push rax
000079035dde0e57  push rcx
000079035dde0e58  push rdx
000079035dde0e59  push rdi
000079035dde0e5a  push rsi
000079035dde0e5b  push r8
000079035dde0e5d  push r9
000079035dde0e5f  push r10
000079035dde0e61  push r11
000079035dde0e63  sub rsp, 0xF0
000079035dde0e6a  vmovaps [rsp], xmm0
000079035dde0e6f  vmovaps [rsp+0x10], xmm2
000079035dde0e75  vmovaps [rsp+0x20], xmm3
000079035dde0e7b  vmovaps [rsp+0x30], xmm4
000079035dde0e81  vmovaps [rsp+0x40], xmm5
000079035dde0e87  vmovaps [rsp+0x50], xmm6
000079035dde0e8d  vmovaps [rsp+0x60], xmm7
000079035dde0e93  vmovaps [rsp+0x70], xmm8
000079035dde0e99  vmovaps [rsp+0x80], xmm9
000079035dde0ea2  vmovaps [rsp+0x90], xmm10
000079035dde0eab  vmovaps [rsp+0xA0], xmm11
000079035dde0eb4  vmovaps [rsp+0xB0], xmm12
000079035dde0ebd  vmovaps [rsp+0xC0], xmm13
000079035dde0ec6  vmovaps [rsp+0xD0], xmm14
000079035dde0ecf  vmovaps [rsp+0xE0], xmm15
000079035dde0ed8  sub rsp, 0x30
000079035dde0edc  movaps [rsp], xmm1
000079035dde0ee0  movaps [rsp+0x10], xmm15
000079035dde0ee6  movaps [rsp+0x20], xmm9
000079035dde0eec  lea rdi, [rsp]
000079035dde0ef0  mov esi, 0x00
000079035dde0ef5  mov rax, 0x64ACAA8B0530
000079035dde0eff  call rax
000079035dde0f01  movaps xmm1, [rsp]
000079035dde0f05  add rsp, 0x30
000079035dde0f09  vmovaps xmm0, [rsp]
000079035dde0f0e  vmovaps xmm2, [rsp+0x10]
000079035dde0f14  vmovaps xmm3, [rsp+0x20]
000079035dde0f1a  vmovaps xmm4, [rsp+0x30]
000079035dde0f20  vmovaps xmm5, [rsp+0x40]
000079035dde0f26  vmovaps xmm6, [rsp+0x50]
000079035dde0f2c  vmovaps xmm7, [rsp+0x60]
000079035dde0f32  vmovaps xmm8, [rsp+0x70]
000079035dde0f38  vmovaps xmm9, [rsp+0x80]
000079035dde0f41  vmovaps xmm10, [rsp+0x90]
000079035dde0f4a  vmovaps xmm11, [rsp+0xA0]
000079035dde0f53  vmovaps xmm12, [rsp+0xB0]
000079035dde0f5c  vmovaps xmm13, [rsp+0xC0]
000079035dde0f65  vmovaps xmm14, [rsp+0xD0]
000079035dde0f6e  vmovaps xmm15, [rsp+0xE0]
000079035dde0f77  add rsp, 0xF0
000079035dde0f7e  pop r11
000079035dde0f80  pop r10
000079035dde0f82  pop r9
000079035dde0f84  pop r8
000079035dde0f86  pop rsi
000079035dde0f87  pop rdi
000079035dde0f88  pop rdx
000079035dde0f89  pop rcx
000079035dde0f8a  pop rax
000079035dde0f8b  add rsp, 0x08
000079035dde0f8f  jmp 0x000079035DDDF15E
000079035dde0f94  call 0x000079035DCC4620
000079035dde0f99  jmp 0x000079035DDDF16B
000079035dde0f9e  sub rsp, 0x08
000079035dde0fa2  push rax
000079035dde0fa3  push rcx
000079035dde0fa4  push rdx
000079035dde0fa5  push rdi
000079035dde0fa6  push rsi
000079035dde0fa7  push r8
000079035dde0fa9  push r9
000079035dde0fab  push r10
000079035dde0fad  push r11
000079035dde0faf  sub rsp, 0xF0
000079035dde0fb6  vmovaps [rsp], xmm0
000079035dde0fbb  vmovaps [rsp+0x10], xmm2
000079035dde0fc1  vmovaps [rsp+0x20], xmm3
000079035dde0fc7  vmovaps [rsp+0x30], xmm4
000079035dde0fcd  vmovaps [rsp+0x40], xmm5
000079035dde0fd3  vmovaps [rsp+0x50], xmm6
000079035dde0fd9  vmovaps [rsp+0x60], xmm7
000079035dde0fdf  vmovaps [rsp+0x70], xmm8
000079035dde0fe5  vmovaps [rsp+0x80], xmm9
000079035dde0fee  vmovaps [rsp+0x90], xmm10
000079035dde0ff7  vmovaps [rsp+0xA0], xmm11
000079035dde1000  vmovaps [rsp+0xB0], xmm12
000079035dde1009  vmovaps [rsp+0xC0], xmm13
000079035dde1012  vmovaps [rsp+0xD0], xmm14
000079035dde101b  vmovaps [rsp+0xE0], xmm15
000079035dde1024  sub rsp, 0x30
000079035dde1028  movaps [rsp], xmm1
000079035dde102c  movaps [rsp+0x10], xmm5
000079035dde1031  movaps [rsp+0x20], xmm7
000079035dde1036  lea rdi, [rsp]
000079035dde103a  mov esi, 0x00
000079035dde103f  mov rax, 0x64ACAA8B0530
000079035dde1049  call rax
000079035dde104b  movaps xmm1, [rsp]
000079035dde104f  add rsp, 0x30
000079035dde1053  vmovaps xmm0, [rsp]
000079035dde1058  vmovaps xmm2, [rsp+0x10]
000079035dde105e  vmovaps xmm3, [rsp+0x20]
000079035dde1064  vmovaps xmm4, [rsp+0x30]
000079035dde106a  vmovaps xmm5, [rsp+0x40]
000079035dde1070  vmovaps xmm6, [rsp+0x50]
000079035dde1076  vmovaps xmm7, [rsp+0x60]
000079035dde107c  vmovaps xmm8, [rsp+0x70]
000079035dde1082  vmovaps xmm9, [rsp+0x80]
000079035dde108b  vmovaps xmm10, [rsp+0x90]
000079035dde1094  vmovaps xmm11, [rsp+0xA0]
000079035dde109d  vmovaps xmm12, [rsp+0xB0]
000079035dde10a6  vmovaps xmm13, [rsp+0xC0]
000079035dde10af  vmovaps xmm14, [rsp+0xD0]
000079035dde10b8  vmovaps xmm15, [rsp+0xE0]
000079035dde10c1  add rsp, 0xF0
000079035dde10c8  pop r11
000079035dde10ca  pop r10
000079035dde10cc  pop r9
000079035dde10ce  pop r8
000079035dde10d0  pop rsi
000079035dde10d1  pop rdi
000079035dde10d2  pop rdx
000079035dde10d3  pop rcx
000079035dde10d4  pop rax
000079035dde10d5  add rsp, 0x08
000079035dde10d9  jmp 0x000079035DDDF210
000079035dde10de  sub rsp, 0x08
000079035dde10e2  push rax
000079035dde10e3  push rcx
000079035dde10e4  push rdx
000079035dde10e5  push rdi
000079035dde10e6  push rsi
000079035dde10e7  push r8
000079035dde10e9  push r9
000079035dde10eb  push r10
000079035dde10ed  push r11
000079035dde10ef  sub rsp, 0xF0
000079035dde10f6  vmovaps [rsp], xmm0
000079035dde10fb  vmovaps [rsp+0x10], xmm1
000079035dde1101  vmovaps [rsp+0x20], xmm2
000079035dde1107  vmovaps [rsp+0x30], xmm3
000079035dde110d  vmovaps [rsp+0x40], xmm4
000079035dde1113  vmovaps [rsp+0x50], xmm5
000079035dde1119  vmovaps [rsp+0x60], xmm6
000079035dde111f  vmovaps [rsp+0x70], xmm8
000079035dde1125  vmovaps [rsp+0x80], xmm9
000079035dde112e  vmovaps [rsp+0x90], xmm10
000079035dde1137  vmovaps [rsp+0xA0], xmm11
000079035dde1140  vmovaps [rsp+0xB0], xmm12
000079035dde1149  vmovaps [rsp+0xC0], xmm13
000079035dde1152  vmovaps [rsp+0xD0], xmm14
000079035dde115b  vmovaps [rsp+0xE0], xmm15
000079035dde1164  sub rsp, 0x30
000079035dde1168  movaps [rsp], xmm7
000079035dde116c  movaps [rsp+0x10], xmm5
000079035dde1171  movaps [rsp+0x20], xmm15
000079035dde1177  lea rdi, [rsp]
000079035dde117b  mov esi, 0x00
000079035dde1180  mov rax, 0x64ACAA8B0530
000079035dde118a  call rax
000079035dde118c  movaps xmm7, [rsp]
000079035dde1190  add rsp, 0x30
000079035dde1194  vmovaps xmm0, [rsp]
000079035dde1199  vmovaps xmm1, [rsp+0x10]
000079035dde119f  vmovaps xmm2, [rsp+0x20]
000079035dde11a5  vmovaps xmm3, [rsp+0x30]
000079035dde11ab  vmovaps xmm4, [rsp+0x40]
000079035dde11b1  vmovaps xmm5, [rsp+0x50]
000079035dde11b7  vmovaps xmm6, [rsp+0x60]
000079035dde11bd  vmovaps xmm8, [rsp+0x70]
000079035dde11c3  vmovaps xmm9, [rsp+0x80]
000079035dde11cc  vmovaps xmm10, [rsp+0x90]
000079035dde11d5  vmovaps xmm11, [rsp+0xA0]
000079035dde11de  vmovaps xmm12, [rsp+0xB0]
000079035dde11e7  vmovaps xmm13, [rsp+0xC0]
000079035dde11f0  vmovaps xmm14, [rsp+0xD0]
000079035dde11f9  vmovaps xmm15, [rsp+0xE0]
000079035dde1202  add rsp, 0xF0
000079035dde1209  pop r11
000079035dde120b  pop r10
000079035dde120d  pop r9
000079035dde120f  pop r8
000079035dde1211  pop rsi
000079035dde1212  pop rdi
000079035dde1213  pop rdx
000079035dde1214  pop rcx
000079035dde1215  pop rax
000079035dde1216  add rsp, 0x08
000079035dde121a  jmp 0x000079035DDDF246
000079035dde121f  call 0x000079035DCB52F0
000079035dde1224  jmp 0x000079035DDDF253
000079035dde1229  sub rsp, 0x08
000079035dde122d  push rax
000079035dde122e  push rcx
000079035dde122f  push rdx
000079035dde1230  push rdi
000079035dde1231  push rsi
000079035dde1232  push r8
000079035dde1234  push r9
000079035dde1236  push r10
000079035dde1238  push r11
000079035dde123a  sub rsp, 0xF0
000079035dde1241  vmovaps [rsp], xmm0
000079035dde1246  vmovaps [rsp+0x10], xmm1
000079035dde124c  vmovaps [rsp+0x20], xmm2
000079035dde1252  vmovaps [rsp+0x30], xmm3
000079035dde1258  vmovaps [rsp+0x40], xmm4
000079035dde125e  vmovaps [rsp+0x50], xmm5
000079035dde1264  vmovaps [rsp+0x60], xmm6
000079035dde126a  vmovaps [rsp+0x70], xmm7
000079035dde1270  vmovaps [rsp+0x80], xmm8
000079035dde1279  vmovaps [rsp+0x90], xmm9
000079035dde1282  vmovaps [rsp+0xA0], xmm10
000079035dde128b  vmovaps [rsp+0xB0], xmm11
000079035dde1294  vmovaps [rsp+0xC0], xmm12
000079035dde129d  vmovaps [rsp+0xD0], xmm13
000079035dde12a6  vmovaps [rsp+0xE0], xmm14
000079035dde12af  sub rsp, 0x30
000079035dde12b3  movaps [rsp], xmm15
000079035dde12b8  movaps [rsp+0x10], xmm5
000079035dde12bd  movaps [rsp+0x20], xmm3
000079035dde12c2  lea rdi, [rsp]
000079035dde12c6  mov esi, 0x00
000079035dde12cb  mov rax, 0x64ACAA8B0530
000079035dde12d5  call rax
000079035dde12d7  movaps xmm15, [rsp]
000079035dde12dc  add rsp, 0x30
000079035dde12e0  vmovaps xmm0, [rsp]
000079035dde12e5  vmovaps xmm1, [rsp+0x10]
000079035dde12eb  vmovaps xmm2, [rsp+0x20]
000079035dde12f1  vmovaps xmm3, [rsp+0x30]
000079035dde12f7  vmovaps xmm4, [rsp+0x40]
000079035dde12fd  vmovaps xmm5, [rsp+0x50]
000079035dde1303  vmovaps xmm6, [rsp+0x60]
000079035dde1309  vmovaps xmm7, [rsp+0x70]
000079035dde130f  vmovaps xmm8, [rsp+0x80]
000079035dde1318  vmovaps xmm9, [rsp+0x90]
000079035dde1321  vmovaps xmm10, [rsp+0xA0]
000079035dde132a  vmovaps xmm11, [rsp+0xB0]
000079035dde1333  vmovaps xmm12, [rsp+0xC0]
000079035dde133c  vmovaps xmm13, [rsp+0xD0]
000079035dde1345  vmovaps xmm14, [rsp+0xE0]
000079035dde134e  add rsp, 0xF0
000079035dde1355  pop r11
000079035dde1357  pop r10
000079035dde1359  pop r9
000079035dde135b  pop r8
000079035dde135d  pop rsi
000079035dde135e  pop rdi
000079035dde135f  pop rdx
000079035dde1360  pop rcx
000079035dde1361  pop rax
000079035dde1362  add rsp, 0x08
000079035dde1366  jmp 0x000079035DDDF279
000079035dde136b  sub rsp, 0x08
000079035dde136f  push rax
000079035dde1370  push rcx
000079035dde1371  push rdx
000079035dde1372  push rdi
000079035dde1373  push rsi
000079035dde1374  push r8
000079035dde1376  push r9
000079035dde1378  push r10
000079035dde137a  push r11
000079035dde137c  sub rsp, 0xF0
000079035dde1383  vmovaps [rsp], xmm0
000079035dde1388  vmovaps [rsp+0x10], xmm2
000079035dde138e  vmovaps [rsp+0x20], xmm3
000079035dde1394  vmovaps [rsp+0x30], xmm4
000079035dde139a  vmovaps [rsp+0x40], xmm5
000079035dde13a0  vmovaps [rsp+0x50], xmm6
000079035dde13a6  vmovaps [rsp+0x60], xmm7
000079035dde13ac  vmovaps [rsp+0x70], xmm8
000079035dde13b2  vmovaps [rsp+0x80], xmm9
000079035dde13bb  vmovaps [rsp+0x90], xmm10
000079035dde13c4  vmovaps [rsp+0xA0], xmm11
000079035dde13cd  vmovaps [rsp+0xB0], xmm12
000079035dde13d6  vmovaps [rsp+0xC0], xmm13
000079035dde13df  vmovaps [rsp+0xD0], xmm14
000079035dde13e8  vmovaps [rsp+0xE0], xmm15
000079035dde13f1  sub rsp, 0x30
000079035dde13f5  movaps [rsp], xmm1
000079035dde13f9  movaps [rsp+0x10], xmm5
000079035dde13fe  movaps [rsp+0x20], xmm4
000079035dde1403  lea rdi, [rsp]
000079035dde1407  mov esi, 0x00
000079035dde140c  mov rax, 0x64ACAA8B0530
000079035dde1416  call rax
000079035dde1418  movaps xmm1, [rsp]
000079035dde141c  add rsp, 0x30
000079035dde1420  vmovaps xmm0, [rsp]
000079035dde1425  vmovaps xmm2, [rsp+0x10]
000079035dde142b  vmovaps xmm3, [rsp+0x20]
000079035dde1431  vmovaps xmm4, [rsp+0x30]
000079035dde1437  vmovaps xmm5, [rsp+0x40]
000079035dde143d  vmovaps xmm6, [rsp+0x50]
000079035dde1443  vmovaps xmm7, [rsp+0x60]
000079035dde1449  vmovaps xmm8, [rsp+0x70]
000079035dde144f  vmovaps xmm9, [rsp+0x80]
000079035dde1458  vmovaps xmm10, [rsp+0x90]
000079035dde1461  vmovaps xmm11, [rsp+0xA0]
000079035dde146a  vmovaps xmm12, [rsp+0xB0]
000079035dde1473  vmovaps xmm13, [rsp+0xC0]
000079035dde147c  vmovaps xmm14, [rsp+0xD0]
000079035dde1485  vmovaps xmm15, [rsp+0xE0]
000079035dde148e  add rsp, 0xF0
000079035dde1495  pop r11
000079035dde1497  pop r10
000079035dde1499  pop r9
000079035dde149b  pop r8
000079035dde149d  pop rsi
000079035dde149e  pop rdi
000079035dde149f  pop rdx
000079035dde14a0  pop rcx
000079035dde14a1  pop rax
000079035dde14a2  add rsp, 0x08
000079035dde14a6  jmp 0x000079035DDDF299
000079035dde14ab  sub rsp, 0x08
000079035dde14af  push rax
000079035dde14b0  push rcx
000079035dde14b1  push rdx
000079035dde14b2  push rdi
000079035dde14b3  push rsi
000079035dde14b4  push r8
000079035dde14b6  push r9
000079035dde14b8  push r10
000079035dde14ba  push r11
000079035dde14bc  sub rsp, 0xF0
000079035dde14c3  vmovaps [rsp], xmm0
000079035dde14c8  vmovaps [rsp+0x10], xmm1
000079035dde14ce  vmovaps [rsp+0x20], xmm2
000079035dde14d4  vmovaps [rsp+0x30], xmm3
000079035dde14da  vmovaps [rsp+0x40], xmm5
000079035dde14e0  vmovaps [rsp+0x50], xmm6
000079035dde14e6  vmovaps [rsp+0x60], xmm7
000079035dde14ec  vmovaps [rsp+0x70], xmm8
000079035dde14f2  vmovaps [rsp+0x80], xmm9
000079035dde14fb  vmovaps [rsp+0x90], xmm10
000079035dde1504  vmovaps [rsp+0xA0], xmm11
000079035dde150d  vmovaps [rsp+0xB0], xmm12
000079035dde1516  vmovaps [rsp+0xC0], xmm13
000079035dde151f  vmovaps [rsp+0xD0], xmm14
000079035dde1528  vmovaps [rsp+0xE0], xmm15
000079035dde1531  sub rsp, 0x30
000079035dde1535  movaps [rsp], xmm4
000079035dde1539  movaps [rsp+0x10], xmm3
000079035dde153e  movaps [rsp+0x20], xmm5
000079035dde1543  lea rdi, [rsp]
000079035dde1547  mov esi, 0x00
000079035dde154c  mov rax, 0x64ACAA8B0530
000079035dde1556  call rax
000079035dde1558  movaps xmm4, [rsp]
000079035dde155c  add rsp, 0x30
000079035dde1560  vmovaps xmm0, [rsp]
000079035dde1565  vmovaps xmm1, [rsp+0x10]
000079035dde156b  vmovaps xmm2, [rsp+0x20]
000079035dde1571  vmovaps xmm3, [rsp+0x30]
000079035dde1577  vmovaps xmm5, [rsp+0x40]
000079035dde157d  vmovaps xmm6, [rsp+0x50]
000079035dde1583  vmovaps xmm7, [rsp+0x60]
000079035dde1589  vmovaps xmm8, [rsp+0x70]
000079035dde158f  vmovaps xmm9, [rsp+0x80]
000079035dde1598  vmovaps xmm10, [rsp+0x90]
000079035dde15a1  vmovaps xmm11, [rsp+0xA0]
000079035dde15aa  vmovaps xmm12, [rsp+0xB0]
000079035dde15b3  vmovaps xmm13, [rsp+0xC0]
000079035dde15bc  vmovaps xmm14, [rsp+0xD0]
000079035dde15c5  vmovaps xmm15, [rsp+0xE0]
000079035dde15ce  add rsp, 0xF0
000079035dde15d5  pop r11
000079035dde15d7  pop r10
000079035dde15d9  pop r9
000079035dde15db  pop r8
000079035dde15dd  pop rsi
000079035dde15de  pop rdi
000079035dde15df  pop rdx
000079035dde15e0  pop rcx
000079035dde15e1  pop rax
000079035dde15e2  add rsp, 0x08
000079035dde15e6  jmp 0x000079035DDDF2E7
000079035dde15eb  call 0x000079035DCB52F0
000079035dde15f0  jmp 0x000079035DDDF2F4
000079035dde15f5  sub rsp, 0x08
000079035dde15f9  push rax
000079035dde15fa  push rcx
000079035dde15fb  push rdx
000079035dde15fc  push rdi
000079035dde15fd  push rsi
000079035dde15fe  push r8
000079035dde1600  push r9
000079035dde1602  push r10
000079035dde1604  push r11
000079035dde1606  sub rsp, 0xF0
000079035dde160d  vmovaps [rsp], xmm0
000079035dde1612  vmovaps [rsp+0x10], xmm1
000079035dde1618  vmovaps [rsp+0x20], xmm2
000079035dde161e  vmovaps [rsp+0x30], xmm3
000079035dde1624  vmovaps [rsp+0x40], xmm4
000079035dde162a  vmovaps [rsp+0x50], xmm6
000079035dde1630  vmovaps [rsp+0x60], xmm7
000079035dde1636  vmovaps [rsp+0x70], xmm8
000079035dde163c  vmovaps [rsp+0x80], xmm9
000079035dde1645  vmovaps [rsp+0x90], xmm10
000079035dde164e  vmovaps [rsp+0xA0], xmm11
000079035dde1657  vmovaps [rsp+0xB0], xmm12
000079035dde1660  vmovaps [rsp+0xC0], xmm13
000079035dde1669  vmovaps [rsp+0xD0], xmm14
000079035dde1672  vmovaps [rsp+0xE0], xmm15
000079035dde167b  sub rsp, 0x30
000079035dde167f  movaps [rsp], xmm5
000079035dde1683  movaps [rsp+0x10], xmm6
000079035dde1688  movaps [rsp+0x20], xmm3
000079035dde168d  lea rdi, [rsp]
000079035dde1691  mov esi, 0x00
000079035dde1696  mov rax, 0x64ACAA8B0530
000079035dde16a0  call rax
000079035dde16a2  movaps xmm5, [rsp]
000079035dde16a6  add rsp, 0x30
000079035dde16aa  vmovaps xmm0, [rsp]
000079035dde16af  vmovaps xmm1, [rsp+0x10]
000079035dde16b5  vmovaps xmm2, [rsp+0x20]
000079035dde16bb  vmovaps xmm3, [rsp+0x30]
000079035dde16c1  vmovaps xmm4, [rsp+0x40]
000079035dde16c7  vmovaps xmm6, [rsp+0x50]
000079035dde16cd  vmovaps xmm7, [rsp+0x60]
000079035dde16d3  vmovaps xmm8, [rsp+0x70]
000079035dde16d9  vmovaps xmm9, [rsp+0x80]
000079035dde16e2  vmovaps xmm10, [rsp+0x90]
000079035dde16eb  vmovaps xmm11, [rsp+0xA0]
000079035dde16f4  vmovaps xmm12, [rsp+0xB0]
000079035dde16fd  vmovaps xmm13, [rsp+0xC0]
000079035dde1706  vmovaps xmm14, [rsp+0xD0]
000079035dde170f  vmovaps xmm15, [rsp+0xE0]
000079035dde1718  add rsp, 0xF0
000079035dde171f  pop r11
000079035dde1721  pop r10
000079035dde1723  pop r9
000079035dde1725  pop r8
000079035dde1727  pop rsi
000079035dde1728  pop rdi
000079035dde1729  pop rdx
000079035dde172a  pop rcx
000079035dde172b  pop rax
000079035dde172c  add rsp, 0x08
000079035dde1730  jmp 0x000079035DDDF31A
000079035dde1735  sub rsp, 0x08
000079035dde1739  push rax
000079035dde173a  push rcx
000079035dde173b  push rdx
000079035dde173c  push rdi
000079035dde173d  push rsi
000079035dde173e  push r8
000079035dde1740  push r9
000079035dde1742  push r10
000079035dde1744  push r11
000079035dde1746  sub rsp, 0xF0
000079035dde174d  vmovaps [rsp], xmm0
000079035dde1752  vmovaps [rsp+0x10], xmm1
000079035dde1758  vmovaps [rsp+0x20], xmm2
000079035dde175e  vmovaps [rsp+0x30], xmm3
000079035dde1764  vmovaps [rsp+0x40], xmm4
000079035dde176a  vmovaps [rsp+0x50], xmm5
000079035dde1770  vmovaps [rsp+0x60], xmm7
000079035dde1776  vmovaps [rsp+0x70], xmm8
000079035dde177c  vmovaps [rsp+0x80], xmm9
000079035dde1785  vmovaps [rsp+0x90], xmm10
000079035dde178e  vmovaps [rsp+0xA0], xmm11
000079035dde1797  vmovaps [rsp+0xB0], xmm12
000079035dde17a0  vmovaps [rsp+0xC0], xmm13
000079035dde17a9  vmovaps [rsp+0xD0], xmm14
000079035dde17b2  vmovaps [rsp+0xE0], xmm15
000079035dde17bb  sub rsp, 0x30
000079035dde17bf  movaps [rsp], xmm6
000079035dde17c3  movaps [rsp+0x10], xmm9
000079035dde17c9  movaps [rsp+0x20], xmm1
000079035dde17ce  lea rdi, [rsp]
000079035dde17d2  mov esi, 0x00
000079035dde17d7  mov rax, 0x64ACAA8B0530
000079035dde17e1  call rax
000079035dde17e3  movaps xmm6, [rsp]
000079035dde17e7  add rsp, 0x30
000079035dde17eb  vmovaps xmm0, [rsp]
000079035dde17f0  vmovaps xmm1, [rsp+0x10]
000079035dde17f6  vmovaps xmm2, [rsp+0x20]
000079035dde17fc  vmovaps xmm3, [rsp+0x30]
000079035dde1802  vmovaps xmm4, [rsp+0x40]
000079035dde1808  vmovaps xmm5, [rsp+0x50]
000079035dde180e  vmovaps xmm7, [rsp+0x60]
000079035dde1814  vmovaps xmm8, [rsp+0x70]
000079035dde181a  vmovaps xmm9, [rsp+0x80]
000079035dde1823  vmovaps xmm10, [rsp+0x90]
000079035dde182c  vmovaps xmm11, [rsp+0xA0]
000079035dde1835  vmovaps xmm12, [rsp+0xB0]
000079035dde183e  vmovaps xmm13, [rsp+0xC0]
000079035dde1847  vmovaps xmm14, [rsp+0xD0]
000079035dde1850  vmovaps xmm15, [rsp+0xE0]
000079035dde1859  add rsp, 0xF0
000079035dde1860  pop r11
000079035dde1862  pop r10
000079035dde1864  pop r9
000079035dde1866  pop r8
000079035dde1868  pop rsi
000079035dde1869  pop rdi
000079035dde186a  pop rdx
000079035dde186b  pop rcx
000079035dde186c  pop rax
000079035dde186d  add rsp, 0x08
000079035dde1871  jmp 0x000079035DDDF33E
000079035dde1876  sub rsp, 0x08
000079035dde187a  push rax
000079035dde187b  push rcx
000079035dde187c  push rdx
000079035dde187d  push rdi
000079035dde187e  push rsi
000079035dde187f  push r8
000079035dde1881  push r9
000079035dde1883  push r10
000079035dde1885  push r11
000079035dde1887  sub rsp, 0xF0
000079035dde188e  vmovaps [rsp], xmm0
000079035dde1893  vmovaps [rsp+0x10], xmm1
000079035dde1899  vmovaps [rsp+0x20], xmm2
000079035dde189f  vmovaps [rsp+0x30], xmm3
000079035dde18a5  vmovaps [rsp+0x40], xmm4
000079035dde18ab  vmovaps [rsp+0x50], xmm5
000079035dde18b1  vmovaps [rsp+0x60], xmm6
000079035dde18b7  vmovaps [rsp+0x70], xmm7
000079035dde18bd  vmovaps [rsp+0x80], xmm8
000079035dde18c6  vmovaps [rsp+0x90], xmm10
000079035dde18cf  vmovaps [rsp+0xA0], xmm11
000079035dde18d8  vmovaps [rsp+0xB0], xmm12
000079035dde18e1  vmovaps [rsp+0xC0], xmm13
000079035dde18ea  vmovaps [rsp+0xD0], xmm14
000079035dde18f3  vmovaps [rsp+0xE0], xmm15
000079035dde18fc  sub rsp, 0x30
000079035dde1900  movaps [rsp], xmm9
000079035dde1905  movaps [rsp+0x10], xmm3
000079035dde190a  movaps [rsp+0x20], xmm1
000079035dde190f  lea rdi, [rsp]
000079035dde1913  mov esi, 0x00
000079035dde1918  mov rax, 0x64ACAA8B0530
000079035dde1922  call rax
000079035dde1924  movaps xmm9, [rsp]
000079035dde1929  add rsp, 0x30
000079035dde192d  vmovaps xmm0, [rsp]
000079035dde1932  vmovaps xmm1, [rsp+0x10]
000079035dde1938  vmovaps xmm2, [rsp+0x20]
000079035dde193e  vmovaps xmm3, [rsp+0x30]
000079035dde1944  vmovaps xmm4, [rsp+0x40]
000079035dde194a  vmovaps xmm5, [rsp+0x50]
000079035dde1950  vmovaps xmm6, [rsp+0x60]
000079035dde1956  vmovaps xmm7, [rsp+0x70]
000079035dde195c  vmovaps xmm8, [rsp+0x80]
000079035dde1965  vmovaps xmm10, [rsp+0x90]
000079035dde196e  vmovaps xmm11, [rsp+0xA0]
000079035dde1977  vmovaps xmm12, [rsp+0xB0]
000079035dde1980  vmovaps xmm13, [rsp+0xC0]
000079035dde1989  vmovaps xmm14, [rsp+0xD0]
000079035dde1992  vmovaps xmm15, [rsp+0xE0]
000079035dde199b  add rsp, 0xF0
000079035dde19a2  pop r11
000079035dde19a4  pop r10
000079035dde19a6  pop r9
000079035dde19a8  pop r8
000079035dde19aa  pop rsi
000079035dde19ab  pop rdi
000079035dde19ac  pop rdx
000079035dde19ad  pop rcx
000079035dde19ae  pop rax
000079035dde19af  add rsp, 0x08
000079035dde19b3  jmp 0x000079035DDDF38A
000079035dde19b8  call 0x000079035DCB52F0
000079035dde19bd  jmp 0x000079035DDDF397
000079035dde19c2  sub rsp, 0x08
000079035dde19c6  push rax
000079035dde19c7  push rcx
000079035dde19c8  push rdx
000079035dde19c9  push rdi
000079035dde19ca  push rsi
000079035dde19cb  push r8
000079035dde19cd  push r9
000079035dde19cf  push r10
000079035dde19d1  push r11
000079035dde19d3  sub rsp, 0xF0
000079035dde19da  vmovaps [rsp], xmm0
000079035dde19df  vmovaps [rsp+0x10], xmm1
000079035dde19e5  vmovaps [rsp+0x20], xmm2
000079035dde19eb  vmovaps [rsp+0x30], xmm3
000079035dde19f1  vmovaps [rsp+0x40], xmm4
000079035dde19f7  vmovaps [rsp+0x50], xmm5
000079035dde19fd  vmovaps [rsp+0x60], xmm6
000079035dde1a03  vmovaps [rsp+0x70], xmm7
000079035dde1a09  vmovaps [rsp+0x80], xmm8
000079035dde1a12  vmovaps [rsp+0x90], xmm9
000079035dde1a1b  vmovaps [rsp+0xA0], xmm10
000079035dde1a24  vmovaps [rsp+0xB0], xmm11
000079035dde1a2d  vmovaps [rsp+0xC0], xmm12
000079035dde1a36  vmovaps [rsp+0xD0], xmm13
000079035dde1a3f  vmovaps [rsp+0xE0], xmm14
000079035dde1a48  sub rsp, 0x30
000079035dde1a4c  movaps [rsp], xmm15
000079035dde1a51  movaps [rsp+0x10], xmm3
000079035dde1a56  movaps [rsp+0x20], xmm7
000079035dde1a5b  lea rdi, [rsp]
000079035dde1a5f  mov esi, 0x00
000079035dde1a64  mov rax, 0x64ACAA8B0530
000079035dde1a6e  call rax
000079035dde1a70  movaps xmm15, [rsp]
000079035dde1a75  add rsp, 0x30
000079035dde1a79  vmovaps xmm0, [rsp]
000079035dde1a7e  vmovaps xmm1, [rsp+0x10]
000079035dde1a84  vmovaps xmm2, [rsp+0x20]
000079035dde1a8a  vmovaps xmm3, [rsp+0x30]
000079035dde1a90  vmovaps xmm4, [rsp+0x40]
000079035dde1a96  vmovaps xmm5, [rsp+0x50]
000079035dde1a9c  vmovaps xmm6, [rsp+0x60]
000079035dde1aa2  vmovaps xmm7, [rsp+0x70]
000079035dde1aa8  vmovaps xmm8, [rsp+0x80]
000079035dde1ab1  vmovaps xmm9, [rsp+0x90]
000079035dde1aba  vmovaps xmm10, [rsp+0xA0]
000079035dde1ac3  vmovaps xmm11, [rsp+0xB0]
000079035dde1acc  vmovaps xmm12, [rsp+0xC0]
000079035dde1ad5  vmovaps xmm13, [rsp+0xD0]
000079035dde1ade  vmovaps xmm14, [rsp+0xE0]
000079035dde1ae7  add rsp, 0xF0
000079035dde1aee  pop r11
000079035dde1af0  pop r10
000079035dde1af2  pop r9
000079035dde1af4  pop r8
000079035dde1af6  pop rsi
000079035dde1af7  pop rdi
000079035dde1af8  pop rdx
000079035dde1af9  pop rcx
000079035dde1afa  pop rax
000079035dde1afb  add rsp, 0x08
000079035dde1aff  jmp 0x000079035DDDF3C3
000079035dde1b04  sub rsp, 0x08
000079035dde1b08  push rax
000079035dde1b09  push rcx
000079035dde1b0a  push rdx
000079035dde1b0b  push rdi
000079035dde1b0c  push rsi
000079035dde1b0d  push r8
000079035dde1b0f  push r9
000079035dde1b11  push r10
000079035dde1b13  push r11
000079035dde1b15  sub rsp, 0xF0
000079035dde1b1c  vmovaps [rsp], xmm0
000079035dde1b21  vmovaps [rsp+0x10], xmm1
000079035dde1b27  vmovaps [rsp+0x20], xmm2
000079035dde1b2d  vmovaps [rsp+0x30], xmm4
000079035dde1b33  vmovaps [rsp+0x40], xmm5
000079035dde1b39  vmovaps [rsp+0x50], xmm6
000079035dde1b3f  vmovaps [rsp+0x60], xmm7
000079035dde1b45  vmovaps [rsp+0x70], xmm8
000079035dde1b4b  vmovaps [rsp+0x80], xmm9
000079035dde1b54  vmovaps [rsp+0x90], xmm10
000079035dde1b5d  vmovaps [rsp+0xA0], xmm11
000079035dde1b66  vmovaps [rsp+0xB0], xmm12
000079035dde1b6f  vmovaps [rsp+0xC0], xmm13
000079035dde1b78  vmovaps [rsp+0xD0], xmm14
000079035dde1b81  vmovaps [rsp+0xE0], xmm15
000079035dde1b8a  sub rsp, 0x30
000079035dde1b8e  movaps [rsp], xmm3
000079035dde1b92  movaps [rsp+0x10], xmm1
000079035dde1b97  movaps [rsp+0x20], xmm15
000079035dde1b9d  lea rdi, [rsp]
000079035dde1ba1  mov esi, 0x00
000079035dde1ba6  mov rax, 0x64ACAA8B0530
000079035dde1bb0  call rax
000079035dde1bb2  movaps xmm3, [rsp]
000079035dde1bb6  add rsp, 0x30
000079035dde1bba  vmovaps xmm0, [rsp]
000079035dde1bbf  vmovaps xmm1, [rsp+0x10]
000079035dde1bc5  vmovaps xmm2, [rsp+0x20]
000079035dde1bcb  vmovaps xmm4, [rsp+0x30]
000079035dde1bd1  vmovaps xmm5, [rsp+0x40]
000079035dde1bd7  vmovaps xmm6, [rsp+0x50]
000079035dde1bdd  vmovaps xmm7, [rsp+0x60]
000079035dde1be3  vmovaps xmm8, [rsp+0x70]
000079035dde1be9  vmovaps xmm9, [rsp+0x80]
000079035dde1bf2  vmovaps xmm10, [rsp+0x90]
000079035dde1bfb  vmovaps xmm11, [rsp+0xA0]
000079035dde1c04  vmovaps xmm12, [rsp+0xB0]
000079035dde1c0d  vmovaps xmm13, [rsp+0xC0]
000079035dde1c16  vmovaps xmm14, [rsp+0xD0]
000079035dde1c1f  vmovaps xmm15, [rsp+0xE0]
000079035dde1c28  add rsp, 0xF0
000079035dde1c2f  pop r11
000079035dde1c31  pop r10
000079035dde1c33  pop r9
000079035dde1c35  pop r8
000079035dde1c37  pop rsi
000079035dde1c38  pop rdi
000079035dde1c39  pop rdx
000079035dde1c3a  pop rcx
000079035dde1c3b  pop rax
000079035dde1c3c  add rsp, 0x08
000079035dde1c40  jmp 0x000079035DDDF452
000079035dde1c45  call 0x000079035DCB52F0
000079035dde1c4a  jmp 0x000079035DDDF45C
000079035dde1c4f  sub rsp, 0x08
000079035dde1c53  push rax
000079035dde1c54  push rcx
000079035dde1c55  push rdx
000079035dde1c56  push rdi
000079035dde1c57  push rsi
000079035dde1c58  push r8
000079035dde1c5a  push r9
000079035dde1c5c  push r10
000079035dde1c5e  push r11
000079035dde1c60  sub rsp, 0xF0
000079035dde1c67  vmovaps [rsp], xmm0
000079035dde1c6c  vmovaps [rsp+0x10], xmm1
000079035dde1c72  vmovaps [rsp+0x20], xmm2
000079035dde1c78  vmovaps [rsp+0x30], xmm3
000079035dde1c7e  vmovaps [rsp+0x40], xmm4
000079035dde1c84  vmovaps [rsp+0x50], xmm5
000079035dde1c8a  vmovaps [rsp+0x60], xmm6
000079035dde1c90  vmovaps [rsp+0x70], xmm7
000079035dde1c96  vmovaps [rsp+0x80], xmm8
000079035dde1c9f  vmovaps [rsp+0x90], xmm9
000079035dde1ca8  vmovaps [rsp+0xA0], xmm10
000079035dde1cb1  vmovaps [rsp+0xB0], xmm11
000079035dde1cba  vmovaps [rsp+0xC0], xmm12
000079035dde1cc3  vmovaps [rsp+0xD0], xmm13
000079035dde1ccc  vmovaps [rsp+0xE0], xmm14
000079035dde1cd5  sub rsp, 0x30
000079035dde1cd9  movaps [rsp], xmm15
000079035dde1cde  movaps [rsp+0x10], xmm14
000079035dde1ce4  movaps [rsp+0x20], xmm4
000079035dde1ce9  lea rdi, [rsp]
000079035dde1ced  mov esi, 0x00
000079035dde1cf2  mov rax, 0x64ACAA8B0530
000079035dde1cfc  call rax
000079035dde1cfe  movaps xmm15, [rsp]
000079035dde1d03  add rsp, 0x30
000079035dde1d07  vmovaps xmm0, [rsp]
000079035dde1d0c  vmovaps xmm1, [rsp+0x10]
000079035dde1d12  vmovaps xmm2, [rsp+0x20]
000079035dde1d18  vmovaps xmm3, [rsp+0x30]
000079035dde1d1e  vmovaps xmm4, [rsp+0x40]
000079035dde1d24  vmovaps xmm5, [rsp+0x50]
000079035dde1d2a  vmovaps xmm6, [rsp+0x60]
000079035dde1d30  vmovaps xmm7, [rsp+0x70]
000079035dde1d36  vmovaps xmm8, [rsp+0x80]
000079035dde1d3f  vmovaps xmm9, [rsp+0x90]
000079035dde1d48  vmovaps xmm10, [rsp+0xA0]
000079035dde1d51  vmovaps xmm11, [rsp+0xB0]
000079035dde1d5a  vmovaps xmm12, [rsp+0xC0]
000079035dde1d63  vmovaps xmm13, [rsp+0xD0]
000079035dde1d6c  vmovaps xmm14, [rsp+0xE0]
000079035dde1d75  add rsp, 0xF0
000079035dde1d7c  pop r11
000079035dde1d7e  pop r10
000079035dde1d80  pop r9
000079035dde1d82  pop r8
000079035dde1d84  pop rsi
000079035dde1d85  pop rdi
000079035dde1d86  pop rdx
000079035dde1d87  pop rcx
000079035dde1d88  pop rax
000079035dde1d89  add rsp, 0x08
000079035dde1d8d  jmp 0x000079035DDDF48A
000079035dde1d92  sub rsp, 0x08
000079035dde1d96  push rax
000079035dde1d97  push rcx
000079035dde1d98  push rdx
000079035dde1d99  push rdi
000079035dde1d9a  push rsi
000079035dde1d9b  push r8
000079035dde1d9d  push r9
000079035dde1d9f  push r10
000079035dde1da1  push r11
000079035dde1da3  sub rsp, 0xF0
000079035dde1daa  vmovaps [rsp], xmm0
000079035dde1daf  vmovaps [rsp+0x10], xmm1
000079035dde1db5  vmovaps [rsp+0x20], xmm2
000079035dde1dbb  vmovaps [rsp+0x30], xmm3
000079035dde1dc1  vmovaps [rsp+0x40], xmm4
000079035dde1dc7  vmovaps [rsp+0x50], xmm5
000079035dde1dcd  vmovaps [rsp+0x60], xmm6
000079035dde1dd3  vmovaps [rsp+0x70], xmm7
000079035dde1dd9  vmovaps [rsp+0x80], xmm8
000079035dde1de2  vmovaps [rsp+0x90], xmm9
000079035dde1deb  vmovaps [rsp+0xA0], xmm10
000079035dde1df4  vmovaps [rsp+0xB0], xmm11
000079035dde1dfd  vmovaps [rsp+0xC0], xmm12
000079035dde1e06  vmovaps [rsp+0xD0], xmm13
000079035dde1e0f  vmovaps [rsp+0xE0], xmm15
000079035dde1e18  sub rsp, 0x30
000079035dde1e1c  movaps [rsp], xmm14
000079035dde1e21  movaps [rsp+0x10], xmm2
000079035dde1e26  movaps [rsp+0x20], xmm1
000079035dde1e2b  lea rdi, [rsp]
000079035dde1e2f  mov esi, 0x00
000079035dde1e34  mov rax, 0x64ACAA8B0530
000079035dde1e3e  call rax
000079035dde1e40  movaps xmm14, [rsp]
000079035dde1e45  add rsp, 0x30
000079035dde1e49  vmovaps xmm0, [rsp]
000079035dde1e4e  vmovaps xmm1, [rsp+0x10]
000079035dde1e54  vmovaps xmm2, [rsp+0x20]
000079035dde1e5a  vmovaps xmm3, [rsp+0x30]
000079035dde1e60  vmovaps xmm4, [rsp+0x40]
000079035dde1e66  vmovaps xmm5, [rsp+0x50]
000079035dde1e6c  vmovaps xmm6, [rsp+0x60]
000079035dde1e72  vmovaps xmm7, [rsp+0x70]
000079035dde1e78  vmovaps xmm8, [rsp+0x80]
000079035dde1e81  vmovaps xmm9, [rsp+0x90]
000079035dde1e8a  vmovaps xmm10, [rsp+0xA0]
000079035dde1e93  vmovaps xmm11, [rsp+0xB0]
000079035dde1e9c  vmovaps xmm12, [rsp+0xC0]
000079035dde1ea5  vmovaps xmm13, [rsp+0xD0]
000079035dde1eae  vmovaps xmm15, [rsp+0xE0]
000079035dde1eb7  add rsp, 0xF0
000079035dde1ebe  pop r11
000079035dde1ec0  pop r10
000079035dde1ec2  pop r9
000079035dde1ec4  pop r8
000079035dde1ec6  pop rsi
000079035dde1ec7  pop rdi
000079035dde1ec8  pop rdx
000079035dde1ec9  pop rcx
000079035dde1eca  pop rax
000079035dde1ecb  add rsp, 0x08
000079035dde1ecf  jmp 0x000079035DDDF4B0
000079035dde1ed4  sub rsp, 0x08
000079035dde1ed8  push rax
000079035dde1ed9  push rcx
000079035dde1eda  push rdx
000079035dde1edb  push rdi
000079035dde1edc  push rsi
000079035dde1edd  push r8
000079035dde1edf  push r9
000079035dde1ee1  push r10
000079035dde1ee3  push r11
000079035dde1ee5  sub rsp, 0xF0
000079035dde1eec  vmovaps [rsp], xmm0
000079035dde1ef1  vmovaps [rsp+0x10], xmm2
000079035dde1ef7  vmovaps [rsp+0x20], xmm3
000079035dde1efd  vmovaps [rsp+0x30], xmm4
000079035dde1f03  vmovaps [rsp+0x40], xmm5
000079035dde1f09  vmovaps [rsp+0x50], xmm6
000079035dde1f0f  vmovaps [rsp+0x60], xmm7
000079035dde1f15  vmovaps [rsp+0x70], xmm8
000079035dde1f1b  vmovaps [rsp+0x80], xmm9
000079035dde1f24  vmovaps [rsp+0x90], xmm10
000079035dde1f2d  vmovaps [rsp+0xA0], xmm11
000079035dde1f36  vmovaps [rsp+0xB0], xmm12
000079035dde1f3f  vmovaps [rsp+0xC0], xmm13
000079035dde1f48  vmovaps [rsp+0xD0], xmm14
000079035dde1f51  vmovaps [rsp+0xE0], xmm15
000079035dde1f5a  sub rsp, 0x30
000079035dde1f5e  movaps [rsp], xmm1
000079035dde1f62  movaps [rsp+0x10], xmm4
000079035dde1f67  movaps [rsp+0x20], xmm9
000079035dde1f6d  lea rdi, [rsp]
000079035dde1f71  mov esi, 0x00
000079035dde1f76  mov rax, 0x64ACAA8B0530
000079035dde1f80  call rax
000079035dde1f82  movaps xmm1, [rsp]
000079035dde1f86  add rsp, 0x30
000079035dde1f8a  vmovaps xmm0, [rsp]
000079035dde1f8f  vmovaps xmm2, [rsp+0x10]
000079035dde1f95  vmovaps xmm3, [rsp+0x20]
000079035dde1f9b  vmovaps xmm4, [rsp+0x30]
000079035dde1fa1  vmovaps xmm5, [rsp+0x40]
000079035dde1fa7  vmovaps xmm6, [rsp+0x50]
000079035dde1fad  vmovaps xmm7, [rsp+0x60]
000079035dde1fb3  vmovaps xmm8, [rsp+0x70]
000079035dde1fb9  vmovaps xmm9, [rsp+0x80]
000079035dde1fc2  vmovaps xmm10, [rsp+0x90]
000079035dde1fcb  vmovaps xmm11, [rsp+0xA0]
000079035dde1fd4  vmovaps xmm12, [rsp+0xB0]
000079035dde1fdd  vmovaps xmm13, [rsp+0xC0]
000079035dde1fe6  vmovaps xmm14, [rsp+0xD0]
000079035dde1fef  vmovaps xmm15, [rsp+0xE0]
000079035dde1ff8  add rsp, 0xF0
000079035dde1fff  pop r11
000079035dde2001  pop r10
000079035dde2003  pop r9
000079035dde2005  pop r8
000079035dde2007  pop rsi
000079035dde2008  pop rdi
000079035dde2009  pop rdx
000079035dde200a  pop rcx
000079035dde200b  pop rax
000079035dde200c  add rsp, 0x08
000079035dde2010  jmp 0x000079035DDDF4CE
000079035dde2015  sub rsp, 0x08
000079035dde2019  push rax
000079035dde201a  push rcx
000079035dde201b  push rdx
000079035dde201c  push rdi
000079035dde201d  push rsi
000079035dde201e  push r8
000079035dde2020  push r9
000079035dde2022  push r10
000079035dde2024  push r11
000079035dde2026  sub rsp, 0xF0
000079035dde202d  vmovaps [rsp], xmm0
000079035dde2032  vmovaps [rsp+0x10], xmm1
000079035dde2038  vmovaps [rsp+0x20], xmm2
000079035dde203e  vmovaps [rsp+0x30], xmm3
000079035dde2044  vmovaps [rsp+0x40], xmm5
000079035dde204a  vmovaps [rsp+0x50], xmm6
000079035dde2050  vmovaps [rsp+0x60], xmm7
000079035dde2056  vmovaps [rsp+0x70], xmm8
000079035dde205c  vmovaps [rsp+0x80], xmm9
000079035dde2065  vmovaps [rsp+0x90], xmm10
000079035dde206e  vmovaps [rsp+0xA0], xmm11
000079035dde2077  vmovaps [rsp+0xB0], xmm12
000079035dde2080  vmovaps [rsp+0xC0], xmm13
000079035dde2089  vmovaps [rsp+0xD0], xmm14
000079035dde2092  vmovaps [rsp+0xE0], xmm15
000079035dde209b  sub rsp, 0x30
000079035dde209f  movaps [rsp], xmm4
000079035dde20a3  movaps [rsp+0x10], xmm2
000079035dde20a8  movaps [rsp+0x20], xmm9
000079035dde20ae  lea rdi, [rsp]
000079035dde20b2  mov esi, 0x00
000079035dde20b7  mov rax, 0x64ACAA8B0530
000079035dde20c1  call rax
000079035dde20c3  movaps xmm4, [rsp]
000079035dde20c7  add rsp, 0x30
000079035dde20cb  vmovaps xmm0, [rsp]
000079035dde20d0  vmovaps xmm1, [rsp+0x10]
000079035dde20d6  vmovaps xmm2, [rsp+0x20]
000079035dde20dc  vmovaps xmm3, [rsp+0x30]
000079035dde20e2  vmovaps xmm5, [rsp+0x40]
000079035dde20e8  vmovaps xmm6, [rsp+0x50]
000079035dde20ee  vmovaps xmm7, [rsp+0x60]
000079035dde20f4  vmovaps xmm8, [rsp+0x70]
000079035dde20fa  vmovaps xmm9, [rsp+0x80]
000079035dde2103  vmovaps xmm10, [rsp+0x90]
000079035dde210c  vmovaps xmm11, [rsp+0xA0]
000079035dde2115  vmovaps xmm12, [rsp+0xB0]
000079035dde211e  vmovaps xmm13, [rsp+0xC0]
000079035dde2127  vmovaps xmm14, [rsp+0xD0]
000079035dde2130  vmovaps xmm15, [rsp+0xE0]
000079035dde2139  add rsp, 0xF0
000079035dde2140  pop r11
000079035dde2142  pop r10
000079035dde2144  pop r9
000079035dde2146  pop r8
000079035dde2148  pop rsi
000079035dde2149  pop rdi
000079035dde214a  pop rdx
000079035dde214b  pop rcx
000079035dde214c  pop rax
000079035dde214d  add rsp, 0x08
000079035dde2151  jmp 0x000079035DDDF4FE
000079035dde2156  sub rsp, 0x08
000079035dde215a  push rax
000079035dde215b  push rcx
000079035dde215c  push rdx
000079035dde215d  push rdi
000079035dde215e  push rsi
000079035dde215f  push r8
000079035dde2161  push r9
000079035dde2163  push r10
000079035dde2165  push r11
000079035dde2167  sub rsp, 0xF0
000079035dde216e  vmovaps [rsp], xmm0
000079035dde2173  vmovaps [rsp+0x10], xmm1
000079035dde2179  vmovaps [rsp+0x20], xmm2
000079035dde217f  vmovaps [rsp+0x30], xmm3
000079035dde2185  vmovaps [rsp+0x40], xmm4
000079035dde218b  vmovaps [rsp+0x50], xmm5
000079035dde2191  vmovaps [rsp+0x60], xmm6
000079035dde2197  vmovaps [rsp+0x70], xmm7
000079035dde219d  vmovaps [rsp+0x80], xmm8
000079035dde21a6  vmovaps [rsp+0x90], xmm10
000079035dde21af  vmovaps [rsp+0xA0], xmm11
000079035dde21b8  vmovaps [rsp+0xB0], xmm12
000079035dde21c1  vmovaps [rsp+0xC0], xmm13
000079035dde21ca  vmovaps [rsp+0xD0], xmm14
000079035dde21d3  vmovaps [rsp+0xE0], xmm15
000079035dde21dc  sub rsp, 0x30
000079035dde21e0  movaps [rsp], xmm9
000079035dde21e5  movaps [rsp+0x10], xmm2
000079035dde21ea  movaps [rsp+0x20], xmm1
000079035dde21ef  lea rdi, [rsp]
000079035dde21f3  mov esi, 0x00
000079035dde21f8  mov rax, 0x64ACAA8B0530
000079035dde2202  call rax
000079035dde2204  movaps xmm9, [rsp]
000079035dde2209  add rsp, 0x30
000079035dde220d  vmovaps xmm0, [rsp]
000079035dde2212  vmovaps xmm1, [rsp+0x10]
000079035dde2218  vmovaps xmm2, [rsp+0x20]
000079035dde221e  vmovaps xmm3, [rsp+0x30]
000079035dde2224  vmovaps xmm4, [rsp+0x40]
000079035dde222a  vmovaps xmm5, [rsp+0x50]
000079035dde2230  vmovaps xmm6, [rsp+0x60]
000079035dde2236  vmovaps xmm7, [rsp+0x70]
000079035dde223c  vmovaps xmm8, [rsp+0x80]
000079035dde2245  vmovaps xmm10, [rsp+0x90]
000079035dde224e  vmovaps xmm11, [rsp+0xA0]
000079035dde2257  vmovaps xmm12, [rsp+0xB0]
000079035dde2260  vmovaps xmm13, [rsp+0xC0]
000079035dde2269  vmovaps xmm14, [rsp+0xD0]
000079035dde2272  vmovaps xmm15, [rsp+0xE0]
000079035dde227b  add rsp, 0xF0
000079035dde2282  pop r11
000079035dde2284  pop r10
000079035dde2286  pop r9
000079035dde2288  pop r8
000079035dde228a  pop rsi
000079035dde228b  pop rdi
000079035dde228c  pop rdx
000079035dde228d  pop rcx
000079035dde228e  pop rax
000079035dde228f  add rsp, 0x08
000079035dde2293  jmp 0x000079035DDDF534
000079035dde2298  sub rsp, 0x08
000079035dde229c  push rax
000079035dde229d  push rcx
000079035dde229e  push rdx
000079035dde229f  push rdi
000079035dde22a0  push rsi
000079035dde22a1  push r8
000079035dde22a3  push r9
000079035dde22a5  push r10
000079035dde22a7  push r11
000079035dde22a9  sub rsp, 0xF0
000079035dde22b0  vmovaps [rsp], xmm0
000079035dde22b5  vmovaps [rsp+0x10], xmm2
000079035dde22bb  vmovaps [rsp+0x20], xmm3
000079035dde22c1  vmovaps [rsp+0x30], xmm4
000079035dde22c7  vmovaps [rsp+0x40], xmm5
000079035dde22cd  vmovaps [rsp+0x50], xmm6
000079035dde22d3  vmovaps [rsp+0x60], xmm7
000079035dde22d9  vmovaps [rsp+0x70], xmm8
000079035dde22df  vmovaps [rsp+0x80], xmm9
000079035dde22e8  vmovaps [rsp+0x90], xmm10
000079035dde22f1  vmovaps [rsp+0xA0], xmm11
000079035dde22fa  vmovaps [rsp+0xB0], xmm12
000079035dde2303  vmovaps [rsp+0xC0], xmm13
000079035dde230c  vmovaps [rsp+0xD0], xmm14
000079035dde2315  vmovaps [rsp+0xE0], xmm15
000079035dde231e  sub rsp, 0x30
000079035dde2322  movaps [rsp], xmm1
000079035dde2326  movaps [rsp+0x10], xmm15
000079035dde232c  movaps [rsp+0x20], xmm6
000079035dde2331  lea rdi, [rsp]
000079035dde2335  mov esi, 0x00
000079035dde233a  mov rax, 0x64ACAA8B0530
000079035dde2344  call rax
000079035dde2346  movaps xmm1, [rsp]
000079035dde234a  add rsp, 0x30
000079035dde234e  vmovaps xmm0, [rsp]
000079035dde2353  vmovaps xmm2, [rsp+0x10]
000079035dde2359  vmovaps xmm3, [rsp+0x20]
000079035dde235f  vmovaps xmm4, [rsp+0x30]
000079035dde2365  vmovaps xmm5, [rsp+0x40]
000079035dde236b  vmovaps xmm6, [rsp+0x50]
000079035dde2371  vmovaps xmm7, [rsp+0x60]
000079035dde2377  vmovaps xmm8, [rsp+0x70]
000079035dde237d  vmovaps xmm9, [rsp+0x80]
000079035dde2386  vmovaps xmm10, [rsp+0x90]
000079035dde238f  vmovaps xmm11, [rsp+0xA0]
000079035dde2398  vmovaps xmm12, [rsp+0xB0]
000079035dde23a1  vmovaps xmm13, [rsp+0xC0]
000079035dde23aa  vmovaps xmm14, [rsp+0xD0]
000079035dde23b3  vmovaps xmm15, [rsp+0xE0]
000079035dde23bc  add rsp, 0xF0
000079035dde23c3  pop r11
000079035dde23c5  pop r10
000079035dde23c7  pop r9
000079035dde23c9  pop r8
000079035dde23cb  pop rsi
000079035dde23cc  pop rdi
000079035dde23cd  pop rdx
000079035dde23ce  pop rcx
000079035dde23cf  pop rax
000079035dde23d0  add rsp, 0x08
000079035dde23d4  jmp 0x000079035DDDF555
000079035dde23d9  sub rsp, 0x08
000079035dde23dd  push rax
000079035dde23de  push rcx
000079035dde23df  push rdx
000079035dde23e0  push rdi
000079035dde23e1  push rsi
000079035dde23e2  push r8
000079035dde23e4  push r9
000079035dde23e6  push r10
000079035dde23e8  push r11
000079035dde23ea  sub rsp, 0xF0
000079035dde23f1  vmovaps [rsp], xmm0
000079035dde23f6  vmovaps [rsp+0x10], xmm1
000079035dde23fc  vmovaps [rsp+0x20], xmm2
000079035dde2402  vmovaps [rsp+0x30], xmm3
000079035dde2408  vmovaps [rsp+0x40], xmm4
000079035dde240e  vmovaps [rsp+0x50], xmm5
000079035dde2414  vmovaps [rsp+0x60], xmm6
000079035dde241a  vmovaps [rsp+0x70], xmm7
000079035dde2420  vmovaps [rsp+0x80], xmm8
000079035dde2429  vmovaps [rsp+0x90], xmm9
000079035dde2432  vmovaps [rsp+0xA0], xmm10
000079035dde243b  vmovaps [rsp+0xB0], xmm11
000079035dde2444  vmovaps [rsp+0xC0], xmm12
000079035dde244d  vmovaps [rsp+0xD0], xmm13
000079035dde2456  vmovaps [rsp+0xE0], xmm14
000079035dde245f  sub rsp, 0x30
000079035dde2463  movaps [rsp], xmm15
000079035dde2468  movaps [rsp+0x10], xmm5
000079035dde246d  movaps [rsp+0x20], xmm3
000079035dde2472  lea rdi, [rsp]
000079035dde2476  mov esi, 0x00
000079035dde247b  mov rax, 0x64ACAA8B0530
000079035dde2485  call rax
000079035dde2487  movaps xmm15, [rsp]
000079035dde248c  add rsp, 0x30
000079035dde2490  vmovaps xmm0, [rsp]
000079035dde2495  vmovaps xmm1, [rsp+0x10]
000079035dde249b  vmovaps xmm2, [rsp+0x20]
000079035dde24a1  vmovaps xmm3, [rsp+0x30]
000079035dde24a7  vmovaps xmm4, [rsp+0x40]
000079035dde24ad  vmovaps xmm5, [rsp+0x50]
000079035dde24b3  vmovaps xmm6, [rsp+0x60]
000079035dde24b9  vmovaps xmm7, [rsp+0x70]
000079035dde24bf  vmovaps xmm8, [rsp+0x80]
000079035dde24c8  vmovaps xmm9, [rsp+0x90]
000079035dde24d1  vmovaps xmm10, [rsp+0xA0]
000079035dde24da  vmovaps xmm11, [rsp+0xB0]
000079035dde24e3  vmovaps xmm12, [rsp+0xC0]
000079035dde24ec  vmovaps xmm13, [rsp+0xD0]
000079035dde24f5  vmovaps xmm14, [rsp+0xE0]
000079035dde24fe  add rsp, 0xF0
000079035dde2505  pop r11
000079035dde2507  pop r10
000079035dde2509  pop r9
000079035dde250b  pop r8
000079035dde250d  pop rsi
000079035dde250e  pop rdi
000079035dde250f  pop rdx
000079035dde2510  pop rcx
000079035dde2511  pop rax
000079035dde2512  add rsp, 0x08
000079035dde2516  jmp 0x000079035DDDF56F
000079035dde251b  sub rsp, 0x08
000079035dde251f  push rax
000079035dde2520  push rcx
000079035dde2521  push rdx
000079035dde2522  push rdi
000079035dde2523  push rsi
000079035dde2524  push r8
000079035dde2526  push r9
000079035dde2528  push r10
000079035dde252a  push r11
000079035dde252c  sub rsp, 0xF0
000079035dde2533  vmovaps [rsp], xmm0
000079035dde2538  vmovaps [rsp+0x10], xmm1
000079035dde253e  vmovaps [rsp+0x20], xmm2
000079035dde2544  vmovaps [rsp+0x30], xmm3
000079035dde254a  vmovaps [rsp+0x40], xmm4
000079035dde2550  vmovaps [rsp+0x50], xmm6
000079035dde2556  vmovaps [rsp+0x60], xmm7
000079035dde255c  vmovaps [rsp+0x70], xmm8
000079035dde2562  vmovaps [rsp+0x80], xmm9
000079035dde256b  vmovaps [rsp+0x90], xmm10
000079035dde2574  vmovaps [rsp+0xA0], xmm11
000079035dde257d  vmovaps [rsp+0xB0], xmm12
000079035dde2586  vmovaps [rsp+0xC0], xmm13
000079035dde258f  vmovaps [rsp+0xD0], xmm14
000079035dde2598  vmovaps [rsp+0xE0], xmm15
000079035dde25a1  sub rsp, 0x30
000079035dde25a5  movaps [rsp], xmm5
000079035dde25a9  movaps [rsp+0x10], xmm8
000079035dde25af  movaps [rsp+0x20], xmm6
000079035dde25b4  lea rdi, [rsp]
000079035dde25b8  mov esi, 0x00
000079035dde25bd  mov rax, 0x64ACAA8B0530
000079035dde25c7  call rax
000079035dde25c9  movaps xmm5, [rsp]
000079035dde25cd  add rsp, 0x30
000079035dde25d1  vmovaps xmm0, [rsp]
000079035dde25d6  vmovaps xmm1, [rsp+0x10]
000079035dde25dc  vmovaps xmm2, [rsp+0x20]
000079035dde25e2  vmovaps xmm3, [rsp+0x30]
000079035dde25e8  vmovaps xmm4, [rsp+0x40]
000079035dde25ee  vmovaps xmm6, [rsp+0x50]
000079035dde25f4  vmovaps xmm7, [rsp+0x60]
000079035dde25fa  vmovaps xmm8, [rsp+0x70]
000079035dde2600  vmovaps xmm9, [rsp+0x80]
000079035dde2609  vmovaps xmm10, [rsp+0x90]
000079035dde2612  vmovaps xmm11, [rsp+0xA0]
000079035dde261b  vmovaps xmm12, [rsp+0xB0]
000079035dde2624  vmovaps xmm13, [rsp+0xC0]
000079035dde262d  vmovaps xmm14, [rsp+0xD0]
000079035dde2636  vmovaps xmm15, [rsp+0xE0]
000079035dde263f  add rsp, 0xF0
000079035dde2646  pop r11
000079035dde2648  pop r10
000079035dde264a  pop r9
000079035dde264c  pop r8
000079035dde264e  pop rsi
000079035dde264f  pop rdi
000079035dde2650  pop rdx
000079035dde2651  pop rcx
000079035dde2652  pop rax
000079035dde2653  add rsp, 0x08
000079035dde2657  jmp 0x000079035DDDF593
000079035dde265c  sub rsp, 0x08
000079035dde2660  push rax
000079035dde2661  push rcx
000079035dde2662  push rdx
000079035dde2663  push rdi
000079035dde2664  push rsi
000079035dde2665  push r8
000079035dde2667  push r9
000079035dde2669  push r10
000079035dde266b  push r11
000079035dde266d  sub rsp, 0xF0
000079035dde2674  vmovaps [rsp], xmm0
000079035dde2679  vmovaps [rsp+0x10], xmm1
000079035dde267f  vmovaps [rsp+0x20], xmm2
000079035dde2685  vmovaps [rsp+0x30], xmm3
000079035dde268b  vmovaps [rsp+0x40], xmm4
000079035dde2691  vmovaps [rsp+0x50], xmm5
000079035dde2697  vmovaps [rsp+0x60], xmm7
000079035dde269d  vmovaps [rsp+0x70], xmm8
000079035dde26a3  vmovaps [rsp+0x80], xmm9
000079035dde26ac  vmovaps [rsp+0x90], xmm10
000079035dde26b5  vmovaps [rsp+0xA0], xmm11
000079035dde26be  vmovaps [rsp+0xB0], xmm12
000079035dde26c7  vmovaps [rsp+0xC0], xmm13
000079035dde26d0  vmovaps [rsp+0xD0], xmm14
000079035dde26d9  vmovaps [rsp+0xE0], xmm15
000079035dde26e2  sub rsp, 0x30
000079035dde26e6  movaps [rsp], xmm6
000079035dde26ea  movaps [rsp+0x10], xmm10
000079035dde26f0  movaps [rsp+0x20], xmm8
000079035dde26f6  lea rdi, [rsp]
000079035dde26fa  mov esi, 0x00
000079035dde26ff  mov rax, 0x64ACAA8B0530
000079035dde2709  call rax
000079035dde270b  movaps xmm6, [rsp]
000079035dde270f  add rsp, 0x30
000079035dde2713  vmovaps xmm0, [rsp]
000079035dde2718  vmovaps xmm1, [rsp+0x10]
000079035dde271e  vmovaps xmm2, [rsp+0x20]
000079035dde2724  vmovaps xmm3, [rsp+0x30]
000079035dde272a  vmovaps xmm4, [rsp+0x40]
000079035dde2730  vmovaps xmm5, [rsp+0x50]
000079035dde2736  vmovaps xmm7, [rsp+0x60]
000079035dde273c  vmovaps xmm8, [rsp+0x70]
000079035dde2742  vmovaps xmm9, [rsp+0x80]
000079035dde274b  vmovaps xmm10, [rsp+0x90]
000079035dde2754  vmovaps xmm11, [rsp+0xA0]
000079035dde275d  vmovaps xmm12, [rsp+0xB0]
000079035dde2766  vmovaps xmm13, [rsp+0xC0]
000079035dde276f  vmovaps xmm14, [rsp+0xD0]
000079035dde2778  vmovaps xmm15, [rsp+0xE0]
000079035dde2781  add rsp, 0xF0
000079035dde2788  pop r11
000079035dde278a  pop r10
000079035dde278c  pop r9
000079035dde278e  pop r8
000079035dde2790  pop rsi
000079035dde2791  pop rdi
000079035dde2792  pop rdx
000079035dde2793  pop rcx
000079035dde2794  pop rax
000079035dde2795  add rsp, 0x08
000079035dde2799  jmp 0x000079035DDDF5B8
000079035dde279e  sub rsp, 0x08
000079035dde27a2  push rax
000079035dde27a3  push rcx
000079035dde27a4  push rdx
000079035dde27a5  push rdi
000079035dde27a6  push rsi
000079035dde27a7  push r8
000079035dde27a9  push r9
000079035dde27ab  push r10
000079035dde27ad  push r11
000079035dde27af  sub rsp, 0xF0
000079035dde27b6  vmovaps [rsp], xmm0
000079035dde27bb  vmovaps [rsp+0x10], xmm1
000079035dde27c1  vmovaps [rsp+0x20], xmm2
000079035dde27c7  vmovaps [rsp+0x30], xmm3
000079035dde27cd  vmovaps [rsp+0x40], xmm4
000079035dde27d3  vmovaps [rsp+0x50], xmm5
000079035dde27d9  vmovaps [rsp+0x60], xmm6
000079035dde27df  vmovaps [rsp+0x70], xmm7
000079035dde27e5  vmovaps [rsp+0x80], xmm8
000079035dde27ee  vmovaps [rsp+0x90], xmm9
000079035dde27f7  vmovaps [rsp+0xA0], xmm11
000079035dde2800  vmovaps [rsp+0xB0], xmm12
000079035dde2809  vmovaps [rsp+0xC0], xmm13
000079035dde2812  vmovaps [rsp+0xD0], xmm14
000079035dde281b  vmovaps [rsp+0xE0], xmm15
000079035dde2824  sub rsp, 0x30
000079035dde2828  movaps [rsp], xmm10
000079035dde282d  movaps [rsp+0x10], xmm8
000079035dde2833  movaps [rsp+0x20], xmm14
000079035dde2839  lea rdi, [rsp]
000079035dde283d  mov esi, 0x00
000079035dde2842  mov rax, 0x64ACAA8B0530
000079035dde284c  call rax
000079035dde284e  movaps xmm10, [rsp]
000079035dde2853  add rsp, 0x30
000079035dde2857  vmovaps xmm0, [rsp]
000079035dde285c  vmovaps xmm1, [rsp+0x10]
000079035dde2862  vmovaps xmm2, [rsp+0x20]
000079035dde2868  vmovaps xmm3, [rsp+0x30]
000079035dde286e  vmovaps xmm4, [rsp+0x40]
000079035dde2874  vmovaps xmm5, [rsp+0x50]
000079035dde287a  vmovaps xmm6, [rsp+0x60]
000079035dde2880  vmovaps xmm7, [rsp+0x70]
000079035dde2886  vmovaps xmm8, [rsp+0x80]
000079035dde288f  vmovaps xmm9, [rsp+0x90]
000079035dde2898  vmovaps xmm11, [rsp+0xA0]
000079035dde28a1  vmovaps xmm12, [rsp+0xB0]
000079035dde28aa  vmovaps xmm13, [rsp+0xC0]
000079035dde28b3  vmovaps xmm14, [rsp+0xD0]
000079035dde28bc  vmovaps xmm15, [rsp+0xE0]
000079035dde28c5  add rsp, 0xF0
000079035dde28cc  pop r11
000079035dde28ce  pop r10
000079035dde28d0  pop r9
000079035dde28d2  pop r8
000079035dde28d4  pop rsi
000079035dde28d5  pop rdi
000079035dde28d6  pop rdx
000079035dde28d7  pop rcx
000079035dde28d8  pop rax
000079035dde28d9  add rsp, 0x08
000079035dde28dd  jmp 0x000079035DDDF5D8
000079035dde28e2  sub rsp, 0x08
000079035dde28e6  push rax
000079035dde28e7  push rcx
000079035dde28e8  push rdx
000079035dde28e9  push rdi
000079035dde28ea  push rsi
000079035dde28eb  push r8
000079035dde28ed  push r9
000079035dde28ef  push r10
000079035dde28f1  push r11
000079035dde28f3  sub rsp, 0xF0
000079035dde28fa  vmovaps [rsp], xmm0
000079035dde28ff  vmovaps [rsp+0x10], xmm1
000079035dde2905  vmovaps [rsp+0x20], xmm2
000079035dde290b  vmovaps [rsp+0x30], xmm3
000079035dde2911  vmovaps [rsp+0x40], xmm4
000079035dde2917  vmovaps [rsp+0x50], xmm5
000079035dde291d  vmovaps [rsp+0x60], xmm6
000079035dde2923  vmovaps [rsp+0x70], xmm7
000079035dde2929  vmovaps [rsp+0x80], xmm8
000079035dde2932  vmovaps [rsp+0x90], xmm9
000079035dde293b  vmovaps [rsp+0xA0], xmm10
000079035dde2944  vmovaps [rsp+0xB0], xmm11
000079035dde294d  vmovaps [rsp+0xC0], xmm12
000079035dde2956  vmovaps [rsp+0xD0], xmm13
000079035dde295f  vmovaps [rsp+0xE0], xmm15
000079035dde2968  sub rsp, 0x30
000079035dde296c  movaps [rsp], xmm14
000079035dde2971  movaps [rsp+0x10], xmm8
000079035dde2977  movaps [rsp+0x20], xmm4
000079035dde297c  lea rdi, [rsp]
000079035dde2980  mov esi, 0x00
000079035dde2985  mov rax, 0x64ACAA8B0530
000079035dde298f  call rax
000079035dde2991  movaps xmm14, [rsp]
000079035dde2996  add rsp, 0x30
000079035dde299a  vmovaps xmm0, [rsp]
000079035dde299f  vmovaps xmm1, [rsp+0x10]
000079035dde29a5  vmovaps xmm2, [rsp+0x20]
000079035dde29ab  vmovaps xmm3, [rsp+0x30]
000079035dde29b1  vmovaps xmm4, [rsp+0x40]
000079035dde29b7  vmovaps xmm5, [rsp+0x50]
000079035dde29bd  vmovaps xmm6, [rsp+0x60]
000079035dde29c3  vmovaps xmm7, [rsp+0x70]
000079035dde29c9  vmovaps xmm8, [rsp+0x80]
000079035dde29d2  vmovaps xmm9, [rsp+0x90]
000079035dde29db  vmovaps xmm10, [rsp+0xA0]
000079035dde29e4  vmovaps xmm11, [rsp+0xB0]
000079035dde29ed  vmovaps xmm12, [rsp+0xC0]
000079035dde29f6  vmovaps xmm13, [rsp+0xD0]
000079035dde29ff  vmovaps xmm15, [rsp+0xE0]
000079035dde2a08  add rsp, 0xF0
000079035dde2a0f  pop r11
000079035dde2a11  pop r10
000079035dde2a13  pop r9
000079035dde2a15  pop r8
000079035dde2a17  pop rsi
000079035dde2a18  pop rdi
000079035dde2a19  pop rdx
000079035dde2a1a  pop rcx
000079035dde2a1b  pop rax
000079035dde2a1c  add rsp, 0x08
000079035dde2a20  jmp 0x000079035DDDF5F8
000079035dde2a25  sub rsp, 0x08
000079035dde2a29  push rax
000079035dde2a2a  push rcx
000079035dde2a2b  push rdx
000079035dde2a2c  push rdi
000079035dde2a2d  push rsi
000079035dde2a2e  push r8
000079035dde2a30  push r9
000079035dde2a32  push r10
000079035dde2a34  push r11
000079035dde2a36  sub rsp, 0xF0
000079035dde2a3d  vmovaps [rsp], xmm0
000079035dde2a42  vmovaps [rsp+0x10], xmm1
000079035dde2a48  vmovaps [rsp+0x20], xmm2
000079035dde2a4e  vmovaps [rsp+0x30], xmm3
000079035dde2a54  vmovaps [rsp+0x40], xmm5
000079035dde2a5a  vmovaps [rsp+0x50], xmm6
000079035dde2a60  vmovaps [rsp+0x60], xmm7
000079035dde2a66  vmovaps [rsp+0x70], xmm8
000079035dde2a6c  vmovaps [rsp+0x80], xmm9
000079035dde2a75  vmovaps [rsp+0x90], xmm10
000079035dde2a7e  vmovaps [rsp+0xA0], xmm11
000079035dde2a87  vmovaps [rsp+0xB0], xmm12
000079035dde2a90  vmovaps [rsp+0xC0], xmm13
000079035dde2a99  vmovaps [rsp+0xD0], xmm14
000079035dde2aa2  vmovaps [rsp+0xE0], xmm15
000079035dde2aab  sub rsp, 0x30
000079035dde2aaf  movaps [rsp], xmm4
000079035dde2ab3  movaps [rsp+0x10], xmm13
000079035dde2ab9  movaps [rsp+0x20], xmm8
000079035dde2abf  lea rdi, [rsp]
000079035dde2ac3  mov esi, 0x00
000079035dde2ac8  mov rax, 0x64ACAA8B0530
000079035dde2ad2  call rax
000079035dde2ad4  movaps xmm4, [rsp]
000079035dde2ad8  add rsp, 0x30
000079035dde2adc  vmovaps xmm0, [rsp]
000079035dde2ae1  vmovaps xmm1, [rsp+0x10]
000079035dde2ae7  vmovaps xmm2, [rsp+0x20]
000079035dde2aed  vmovaps xmm3, [rsp+0x30]
000079035dde2af3  vmovaps xmm5, [rsp+0x40]
000079035dde2af9  vmovaps xmm6, [rsp+0x50]
000079035dde2aff  vmovaps xmm7, [rsp+0x60]
000079035dde2b05  vmovaps xmm8, [rsp+0x70]
000079035dde2b0b  vmovaps xmm9, [rsp+0x80]
000079035dde2b14  vmovaps xmm10, [rsp+0x90]
000079035dde2b1d  vmovaps xmm11, [rsp+0xA0]
000079035dde2b26  vmovaps xmm12, [rsp+0xB0]
000079035dde2b2f  vmovaps xmm13, [rsp+0xC0]
000079035dde2b38  vmovaps xmm14, [rsp+0xD0]
000079035dde2b41  vmovaps xmm15, [rsp+0xE0]
000079035dde2b4a  add rsp, 0xF0
000079035dde2b51  pop r11
000079035dde2b53  pop r10
000079035dde2b55  pop r9
000079035dde2b57  pop r8
000079035dde2b59  pop rsi
000079035dde2b5a  pop rdi
000079035dde2b5b  pop rdx
000079035dde2b5c  pop rcx
000079035dde2b5d  pop rax
000079035dde2b5e  add rsp, 0x08
000079035dde2b62  jmp 0x000079035DDDF61D
000079035dde2b67  sub rsp, 0x08
000079035dde2b6b  push rax
000079035dde2b6c  push rcx
000079035dde2b6d  push rdx
000079035dde2b6e  push rdi
000079035dde2b6f  push rsi
000079035dde2b70  push r8
000079035dde2b72  push r9
000079035dde2b74  push r10
000079035dde2b76  push r11
000079035dde2b78  sub rsp, 0xF0
000079035dde2b7f  vmovaps [rsp], xmm0
000079035dde2b84  vmovaps [rsp+0x10], xmm1
000079035dde2b8a  vmovaps [rsp+0x20], xmm2
000079035dde2b90  vmovaps [rsp+0x30], xmm3
000079035dde2b96  vmovaps [rsp+0x40], xmm4
000079035dde2b9c  vmovaps [rsp+0x50], xmm5
000079035dde2ba2  vmovaps [rsp+0x60], xmm6
000079035dde2ba8  vmovaps [rsp+0x70], xmm7
000079035dde2bae  vmovaps [rsp+0x80], xmm8
000079035dde2bb7  vmovaps [rsp+0x90], xmm9
000079035dde2bc0  vmovaps [rsp+0xA0], xmm10
000079035dde2bc9  vmovaps [rsp+0xB0], xmm11
000079035dde2bd2  vmovaps [rsp+0xC0], xmm12
000079035dde2bdb  vmovaps [rsp+0xD0], xmm14
000079035dde2be4  vmovaps [rsp+0xE0], xmm15
000079035dde2bed  sub rsp, 0x30
000079035dde2bf1  movaps [rsp], xmm13
000079035dde2bf6  movaps [rsp+0x10], xmm15
000079035dde2bfc  movaps [rsp+0x20], xmm9
000079035dde2c02  lea rdi, [rsp]
000079035dde2c06  mov esi, 0x00
000079035dde2c0b  mov rax, 0x64ACAA8B0530
000079035dde2c15  call rax
000079035dde2c17  movaps xmm13, [rsp]
000079035dde2c1c  add rsp, 0x30
000079035dde2c20  vmovaps xmm0, [rsp]
000079035dde2c25  vmovaps xmm1, [rsp+0x10]
000079035dde2c2b  vmovaps xmm2, [rsp+0x20]
000079035dde2c31  vmovaps xmm3, [rsp+0x30]
000079035dde2c37  vmovaps xmm4, [rsp+0x40]
000079035dde2c3d  vmovaps xmm5, [rsp+0x50]
000079035dde2c43  vmovaps xmm6, [rsp+0x60]
000079035dde2c49  vmovaps xmm7, [rsp+0x70]
000079035dde2c4f  vmovaps xmm8, [rsp+0x80]
000079035dde2c58  vmovaps xmm9, [rsp+0x90]
000079035dde2c61  vmovaps xmm10, [rsp+0xA0]
000079035dde2c6a  vmovaps xmm11, [rsp+0xB0]
000079035dde2c73  vmovaps xmm12, [rsp+0xC0]
000079035dde2c7c  vmovaps xmm14, [rsp+0xD0]
000079035dde2c85  vmovaps xmm15, [rsp+0xE0]
000079035dde2c8e  add rsp, 0xF0
000079035dde2c95  pop r11
000079035dde2c97  pop r10
000079035dde2c99  pop r9
000079035dde2c9b  pop r8
000079035dde2c9d  pop rsi
000079035dde2c9e  pop rdi
000079035dde2c9f  pop rdx
000079035dde2ca0  pop rcx
000079035dde2ca1  pop rax
000079035dde2ca2  add rsp, 0x08
000079035dde2ca6  jmp 0x000079035DDDF638
000079035dde2cab  sub rsp, 0x08
000079035dde2caf  push rax
000079035dde2cb0  push rcx
000079035dde2cb1  push rdx
000079035dde2cb2  push rdi
000079035dde2cb3  push rsi
000079035dde2cb4  push r8
000079035dde2cb6  push r9
000079035dde2cb8  push r10
000079035dde2cba  push r11
000079035dde2cbc  sub rsp, 0xF0
000079035dde2cc3  vmovaps [rsp], xmm0
000079035dde2cc8  vmovaps [rsp+0x10], xmm1
000079035dde2cce  vmovaps [rsp+0x20], xmm2
000079035dde2cd4  vmovaps [rsp+0x30], xmm3
000079035dde2cda  vmovaps [rsp+0x40], xmm4
000079035dde2ce0  vmovaps [rsp+0x50], xmm5
000079035dde2ce6  vmovaps [rsp+0x60], xmm6
000079035dde2cec  vmovaps [rsp+0x70], xmm7
000079035dde2cf2  vmovaps [rsp+0x80], xmm8
000079035dde2cfb  vmovaps [rsp+0x90], xmm9
000079035dde2d04  vmovaps [rsp+0xA0], xmm10
000079035dde2d0d  vmovaps [rsp+0xB0], xmm11
000079035dde2d16  vmovaps [rsp+0xC0], xmm12
000079035dde2d1f  vmovaps [rsp+0xD0], xmm13
000079035dde2d28  vmovaps [rsp+0xE0], xmm14
000079035dde2d31  sub rsp, 0x30
000079035dde2d35  movaps [rsp], xmm15
000079035dde2d3a  movaps [rsp+0x10], xmm1
000079035dde2d3f  movaps [rsp+0x20], xmm5
000079035dde2d44  lea rdi, [rsp]
000079035dde2d48  mov esi, 0x00
000079035dde2d4d  mov rax, 0x64ACAA8B0530
000079035dde2d57  call rax
000079035dde2d59  movaps xmm15, [rsp]
000079035dde2d5e  add rsp, 0x30
000079035dde2d62  vmovaps xmm0, [rsp]
000079035dde2d67  vmovaps xmm1, [rsp+0x10]
000079035dde2d6d  vmovaps xmm2, [rsp+0x20]
000079035dde2d73  vmovaps xmm3, [rsp+0x30]
000079035dde2d79  vmovaps xmm4, [rsp+0x40]
000079035dde2d7f  vmovaps xmm5, [rsp+0x50]
000079035dde2d85  vmovaps xmm6, [rsp+0x60]
000079035dde2d8b  vmovaps xmm7, [rsp+0x70]
000079035dde2d91  vmovaps xmm8, [rsp+0x80]
000079035dde2d9a  vmovaps xmm9, [rsp+0x90]
000079035dde2da3  vmovaps xmm10, [rsp+0xA0]
000079035dde2dac  vmovaps xmm11, [rsp+0xB0]
000079035dde2db5  vmovaps xmm12, [rsp+0xC0]
000079035dde2dbe  vmovaps xmm13, [rsp+0xD0]
000079035dde2dc7  vmovaps xmm14, [rsp+0xE0]
000079035dde2dd0  add rsp, 0xF0
000079035dde2dd7  pop r11
000079035dde2dd9  pop r10
000079035dde2ddb  pop r9
000079035dde2ddd  pop r8
000079035dde2ddf  pop rsi
000079035dde2de0  pop rdi
000079035dde2de1  pop rdx
000079035dde2de2  pop rcx
000079035dde2de3  pop rax
000079035dde2de4  add rsp, 0x08
000079035dde2de8  jmp 0x000079035DDDF653
000079035dde2ded  call 0x000079035DCB52F0
000079035dde2df2  jmp 0x000079035DDDF6AE
000079035dde2df7  sub rsp, 0x08
000079035dde2dfb  push rax
000079035dde2dfc  push rcx
000079035dde2dfd  push rdx
000079035dde2dfe  push rdi
000079035dde2dff  push rsi
000079035dde2e00  push r8
000079035dde2e02  push r9
000079035dde2e04  push r10
000079035dde2e06  push r11
000079035dde2e08  sub rsp, 0xF0
000079035dde2e0f  vmovaps [rsp], xmm0
000079035dde2e14  vmovaps [rsp+0x10], xmm1
000079035dde2e1a  vmovaps [rsp+0x20], xmm2
000079035dde2e20  vmovaps [rsp+0x30], xmm3
000079035dde2e26  vmovaps [rsp+0x40], xmm4
000079035dde2e2c  vmovaps [rsp+0x50], xmm5
000079035dde2e32  vmovaps [rsp+0x60], xmm6
000079035dde2e38  vmovaps [rsp+0x70], xmm7
000079035dde2e3e  vmovaps [rsp+0x80], xmm8
000079035dde2e47  vmovaps [rsp+0x90], xmm10
000079035dde2e50  vmovaps [rsp+0xA0], xmm11
000079035dde2e59  vmovaps [rsp+0xB0], xmm12
000079035dde2e62  vmovaps [rsp+0xC0], xmm13
000079035dde2e6b  vmovaps [rsp+0xD0], xmm14
000079035dde2e74  vmovaps [rsp+0xE0], xmm15
000079035dde2e7d  sub rsp, 0x30
000079035dde2e81  movaps [rsp], xmm9
000079035dde2e86  movaps [rsp+0x10], xmm8
000079035dde2e8c  movaps [rsp+0x20], xmm11
000079035dde2e92  lea rdi, [rsp]
000079035dde2e96  mov esi, 0x00
000079035dde2e9b  mov rax, 0x64ACAA8B0530
000079035dde2ea5  call rax
000079035dde2ea7  movaps xmm9, [rsp]
000079035dde2eac  add rsp, 0x30
000079035dde2eb0  vmovaps xmm0, [rsp]
000079035dde2eb5  vmovaps xmm1, [rsp+0x10]
000079035dde2ebb  vmovaps xmm2, [rsp+0x20]
000079035dde2ec1  vmovaps xmm3, [rsp+0x30]
000079035dde2ec7  vmovaps xmm4, [rsp+0x40]
000079035dde2ecd  vmovaps xmm5, [rsp+0x50]
000079035dde2ed3  vmovaps xmm6, [rsp+0x60]
000079035dde2ed9  vmovaps xmm7, [rsp+0x70]
000079035dde2edf  vmovaps xmm8, [rsp+0x80]
000079035dde2ee8  vmovaps xmm10, [rsp+0x90]
000079035dde2ef1  vmovaps xmm11, [rsp+0xA0]
000079035dde2efa  vmovaps xmm12, [rsp+0xB0]
000079035dde2f03  vmovaps xmm13, [rsp+0xC0]
000079035dde2f0c  vmovaps xmm14, [rsp+0xD0]
000079035dde2f15  vmovaps xmm15, [rsp+0xE0]
000079035dde2f1e  add rsp, 0xF0
000079035dde2f25  pop r11
000079035dde2f27  pop r10
000079035dde2f29  pop r9
000079035dde2f2b  pop r8
000079035dde2f2d  pop rsi
000079035dde2f2e  pop rdi
000079035dde2f2f  pop rdx
000079035dde2f30  pop rcx
000079035dde2f31  pop rax
000079035dde2f32  add rsp, 0x08
000079035dde2f36  jmp 0x000079035DDDF6E5
000079035dde2f3b  sub rsp, 0x08
000079035dde2f3f  push rax
000079035dde2f40  push rcx
000079035dde2f41  push rdx
000079035dde2f42  push rdi
000079035dde2f43  push rsi
000079035dde2f44  push r8
000079035dde2f46  push r9
000079035dde2f48  push r10
000079035dde2f4a  push r11
000079035dde2f4c  sub rsp, 0xF0
000079035dde2f53  vmovaps [rsp], xmm0
000079035dde2f58  vmovaps [rsp+0x10], xmm1
000079035dde2f5e  vmovaps [rsp+0x20], xmm2
000079035dde2f64  vmovaps [rsp+0x30], xmm3
000079035dde2f6a  vmovaps [rsp+0x40], xmm4
000079035dde2f70  vmovaps [rsp+0x50], xmm5
000079035dde2f76  vmovaps [rsp+0x60], xmm6
000079035dde2f7c  vmovaps [rsp+0x70], xmm7
000079035dde2f82  vmovaps [rsp+0x80], xmm8
000079035dde2f8b  vmovaps [rsp+0x90], xmm9
000079035dde2f94  vmovaps [rsp+0xA0], xmm10
000079035dde2f9d  vmovaps [rsp+0xB0], xmm12
000079035dde2fa6  vmovaps [rsp+0xC0], xmm13
000079035dde2faf  vmovaps [rsp+0xD0], xmm14
000079035dde2fb8  vmovaps [rsp+0xE0], xmm15
000079035dde2fc1  sub rsp, 0x30
000079035dde2fc5  movaps [rsp], xmm11
000079035dde2fca  movaps [rsp+0x10], xmm10
000079035dde2fd0  movaps [rsp+0x20], xmm6
000079035dde2fd5  lea rdi, [rsp]
000079035dde2fd9  mov esi, 0x00
000079035dde2fde  mov rax, 0x64ACAA8B0530
000079035dde2fe8  call rax
000079035dde2fea  movaps xmm11, [rsp]
000079035dde2fef  add rsp, 0x30
000079035dde2ff3  vmovaps xmm0, [rsp]
000079035dde2ff8  vmovaps xmm1, [rsp+0x10]
000079035dde2ffe  vmovaps xmm2, [rsp+0x20]
000079035dde3004  vmovaps xmm3, [rsp+0x30]
000079035dde300a  vmovaps xmm4, [rsp+0x40]
000079035dde3010  vmovaps xmm5, [rsp+0x50]
000079035dde3016  vmovaps xmm6, [rsp+0x60]
000079035dde301c  vmovaps xmm7, [rsp+0x70]
000079035dde3022  vmovaps xmm8, [rsp+0x80]
000079035dde302b  vmovaps xmm9, [rsp+0x90]
000079035dde3034  vmovaps xmm10, [rsp+0xA0]
000079035dde303d  vmovaps xmm12, [rsp+0xB0]
000079035dde3046  vmovaps xmm13, [rsp+0xC0]
000079035dde304f  vmovaps xmm14, [rsp+0xD0]
000079035dde3058  vmovaps xmm15, [rsp+0xE0]
000079035dde3061  add rsp, 0xF0
000079035dde3068  pop r11
000079035dde306a  pop r10
000079035dde306c  pop r9
000079035dde306e  pop r8
000079035dde3070  pop rsi
000079035dde3071  pop rdi
000079035dde3072  pop rdx
000079035dde3073  pop rcx
000079035dde3074  pop rax
000079035dde3075  add rsp, 0x08
000079035dde3079  jmp 0x000079035DDDF700
000079035dde307e  sub rsp, 0x08
000079035dde3082  push rax
000079035dde3083  push rcx
000079035dde3084  push rdx
000079035dde3085  push rdi
000079035dde3086  push rsi
000079035dde3087  push r8
000079035dde3089  push r9
000079035dde308b  push r10
000079035dde308d  push r11
000079035dde308f  sub rsp, 0xF0
000079035dde3096  vmovaps [rsp], xmm0
000079035dde309b  vmovaps [rsp+0x10], xmm1
000079035dde30a1  vmovaps [rsp+0x20], xmm2
000079035dde30a7  vmovaps [rsp+0x30], xmm3
000079035dde30ad  vmovaps [rsp+0x40], xmm4
000079035dde30b3  vmovaps [rsp+0x50], xmm5
000079035dde30b9  vmovaps [rsp+0x60], xmm6
000079035dde30bf  vmovaps [rsp+0x70], xmm7
000079035dde30c5  vmovaps [rsp+0x80], xmm8
000079035dde30ce  vmovaps [rsp+0x90], xmm9
000079035dde30d7  vmovaps [rsp+0xA0], xmm11
000079035dde30e0  vmovaps [rsp+0xB0], xmm12
000079035dde30e9  vmovaps [rsp+0xC0], xmm13
000079035dde30f2  vmovaps [rsp+0xD0], xmm14
000079035dde30fb  vmovaps [rsp+0xE0], xmm15
000079035dde3104  sub rsp, 0x30
000079035dde3108  movaps [rsp], xmm10
000079035dde310d  movaps [rsp+0x10], xmm14
000079035dde3113  movaps [rsp+0x20], xmm4
000079035dde3118  lea rdi, [rsp]
000079035dde311c  mov esi, 0x00
000079035dde3121  mov rax, 0x64ACAA8B0530
000079035dde312b  call rax
000079035dde312d  movaps xmm10, [rsp]
000079035dde3132  add rsp, 0x30
000079035dde3136  vmovaps xmm0, [rsp]
000079035dde313b  vmovaps xmm1, [rsp+0x10]
000079035dde3141  vmovaps xmm2, [rsp+0x20]
000079035dde3147  vmovaps xmm3, [rsp+0x30]
000079035dde314d  vmovaps xmm4, [rsp+0x40]
000079035dde3153  vmovaps xmm5, [rsp+0x50]
000079035dde3159  vmovaps xmm6, [rsp+0x60]
000079035dde315f  vmovaps xmm7, [rsp+0x70]
000079035dde3165  vmovaps xmm8, [rsp+0x80]
000079035dde316e  vmovaps xmm9, [rsp+0x90]
000079035dde3177  vmovaps xmm11, [rsp+0xA0]
000079035dde3180  vmovaps xmm12, [rsp+0xB0]
000079035dde3189  vmovaps xmm13, [rsp+0xC0]
000079035dde3192  vmovaps xmm14, [rsp+0xD0]
000079035dde319b  vmovaps xmm15, [rsp+0xE0]
000079035dde31a4  add rsp, 0xF0
000079035dde31ab  pop r11
000079035dde31ad  pop r10
000079035dde31af  pop r9
000079035dde31b1  pop r8
000079035dde31b3  pop rsi
000079035dde31b4  pop rdi
000079035dde31b5  pop rdx
000079035dde31b6  pop rcx
000079035dde31b7  pop rax
000079035dde31b8  add rsp, 0x08
000079035dde31bc  jmp 0x000079035DDDF71B
000079035dde31c1  sub rsp, 0x08
000079035dde31c5  push rax
000079035dde31c6  push rcx
000079035dde31c7  push rdx
000079035dde31c8  push rdi
000079035dde31c9  push rsi
000079035dde31ca  push r8
000079035dde31cc  push r9
000079035dde31ce  push r10
000079035dde31d0  push r11
000079035dde31d2  sub rsp, 0xF0
000079035dde31d9  vmovaps [rsp], xmm0
000079035dde31de  vmovaps [rsp+0x10], xmm1
000079035dde31e4  vmovaps [rsp+0x20], xmm2
000079035dde31ea  vmovaps [rsp+0x30], xmm3
000079035dde31f0  vmovaps [rsp+0x40], xmm4
000079035dde31f6  vmovaps [rsp+0x50], xmm5
000079035dde31fc  vmovaps [rsp+0x60], xmm6
000079035dde3202  vmovaps [rsp+0x70], xmm7
000079035dde3208  vmovaps [rsp+0x80], xmm9
000079035dde3211  vmovaps [rsp+0x90], xmm10
000079035dde321a  vmovaps [rsp+0xA0], xmm11
000079035dde3223  vmovaps [rsp+0xB0], xmm12
000079035dde322c  vmovaps [rsp+0xC0], xmm13
000079035dde3235  vmovaps [rsp+0xD0], xmm14
000079035dde323e  vmovaps [rsp+0xE0], xmm15
000079035dde3247  sub rsp, 0x30
000079035dde324b  movaps [rsp], xmm8
000079035dde3250  movaps [rsp+0x10], xmm1
000079035dde3255  movaps [rsp+0x20], xmm14
000079035dde325b  lea rdi, [rsp]
000079035dde325f  mov esi, 0x00
000079035dde3264  mov rax, 0x64ACAA8B0530
000079035dde326e  call rax
000079035dde3270  movaps xmm8, [rsp]
000079035dde3275  add rsp, 0x30
000079035dde3279  vmovaps xmm0, [rsp]
000079035dde327e  vmovaps xmm1, [rsp+0x10]
000079035dde3284  vmovaps xmm2, [rsp+0x20]
000079035dde328a  vmovaps xmm3, [rsp+0x30]
000079035dde3290  vmovaps xmm4, [rsp+0x40]
000079035dde3296  vmovaps xmm5, [rsp+0x50]
000079035dde329c  vmovaps xmm6, [rsp+0x60]
000079035dde32a2  vmovaps xmm7, [rsp+0x70]
000079035dde32a8  vmovaps xmm9, [rsp+0x80]
000079035dde32b1  vmovaps xmm10, [rsp+0x90]
000079035dde32ba  vmovaps xmm11, [rsp+0xA0]
000079035dde32c3  vmovaps xmm12, [rsp+0xB0]
000079035dde32cc  vmovaps xmm13, [rsp+0xC0]
000079035dde32d5  vmovaps xmm14, [rsp+0xD0]
000079035dde32de  vmovaps xmm15, [rsp+0xE0]
000079035dde32e7  add rsp, 0xF0
000079035dde32ee  pop r11
000079035dde32f0  pop r10
000079035dde32f2  pop r9
000079035dde32f4  pop r8
000079035dde32f6  pop rsi
000079035dde32f7  pop rdi
000079035dde32f8  pop rdx
000079035dde32f9  pop rcx
000079035dde32fa  pop rax
000079035dde32fb  add rsp, 0x08
000079035dde32ff  jmp 0x000079035DDDF741
000079035dde3304  sub rsp, 0x08
000079035dde3308  push rax
000079035dde3309  push rcx
000079035dde330a  push rdx
000079035dde330b  push rdi
000079035dde330c  push rsi
000079035dde330d  push r8
000079035dde330f  push r9
000079035dde3311  push r10
000079035dde3313  push r11
000079035dde3315  sub rsp, 0xF0
000079035dde331c  vmovaps [rsp], xmm0
000079035dde3321  vmovaps [rsp+0x10], xmm1
000079035dde3327  vmovaps [rsp+0x20], xmm2
000079035dde332d  vmovaps [rsp+0x30], xmm3
000079035dde3333  vmovaps [rsp+0x40], xmm4
000079035dde3339  vmovaps [rsp+0x50], xmm5
000079035dde333f  vmovaps [rsp+0x60], xmm7
000079035dde3345  vmovaps [rsp+0x70], xmm8
000079035dde334b  vmovaps [rsp+0x80], xmm9
000079035dde3354  vmovaps [rsp+0x90], xmm10
000079035dde335d  vmovaps [rsp+0xA0], xmm11
000079035dde3366  vmovaps [rsp+0xB0], xmm12
000079035dde336f  vmovaps [rsp+0xC0], xmm13
000079035dde3378  vmovaps [rsp+0xD0], xmm14
000079035dde3381  vmovaps [rsp+0xE0], xmm15
000079035dde338a  sub rsp, 0x30
000079035dde338e  movaps [rsp], xmm6
000079035dde3392  movaps [rsp+0x10], xmm1
000079035dde3397  movaps [rsp+0x20], xmm14
000079035dde339d  lea rdi, [rsp]
000079035dde33a1  mov esi, 0x00
000079035dde33a6  mov rax, 0x64ACAA8B0530
000079035dde33b0  call rax
000079035dde33b2  movaps xmm6, [rsp]
000079035dde33b6  add rsp, 0x30
000079035dde33ba  vmovaps xmm0, [rsp]
000079035dde33bf  vmovaps xmm1, [rsp+0x10]
000079035dde33c5  vmovaps xmm2, [rsp+0x20]
000079035dde33cb  vmovaps xmm3, [rsp+0x30]
000079035dde33d1  vmovaps xmm4, [rsp+0x40]
000079035dde33d7  vmovaps xmm5, [rsp+0x50]
000079035dde33dd  vmovaps xmm7, [rsp+0x60]
000079035dde33e3  vmovaps xmm8, [rsp+0x70]
000079035dde33e9  vmovaps xmm9, [rsp+0x80]
000079035dde33f2  vmovaps xmm10, [rsp+0x90]
000079035dde33fb  vmovaps xmm11, [rsp+0xA0]
000079035dde3404  vmovaps xmm12, [rsp+0xB0]
000079035dde340d  vmovaps xmm13, [rsp+0xC0]
000079035dde3416  vmovaps xmm14, [rsp+0xD0]
000079035dde341f  vmovaps xmm15, [rsp+0xE0]
000079035dde3428  add rsp, 0xF0
000079035dde342f  pop r11
000079035dde3431  pop r10
000079035dde3433  pop r9
000079035dde3435  pop r8
000079035dde3437  pop rsi
000079035dde3438  pop rdi
000079035dde3439  pop rdx
000079035dde343a  pop rcx
000079035dde343b  pop rax
000079035dde343c  add rsp, 0x08
000079035dde3440  jmp 0x000079035DDDF76D
000079035dde3445  sub rsp, 0x08
000079035dde3449  push rax
000079035dde344a  push rcx
000079035dde344b  push rdx
000079035dde344c  push rdi
000079035dde344d  push rsi
000079035dde344e  push r8
000079035dde3450  push r9
000079035dde3452  push r10
000079035dde3454  push r11
000079035dde3456  sub rsp, 0xF0
000079035dde345d  vmovaps [rsp], xmm0
000079035dde3462  vmovaps [rsp+0x10], xmm1
000079035dde3468  vmovaps [rsp+0x20], xmm2
000079035dde346e  vmovaps [rsp+0x30], xmm3
000079035dde3474  vmovaps [rsp+0x40], xmm4
000079035dde347a  vmovaps [rsp+0x50], xmm5
000079035dde3480  vmovaps [rsp+0x60], xmm6
000079035dde3486  vmovaps [rsp+0x70], xmm7
000079035dde348c  vmovaps [rsp+0x80], xmm8
000079035dde3495  vmovaps [rsp+0x90], xmm9
000079035dde349e  vmovaps [rsp+0xA0], xmm10
000079035dde34a7  vmovaps [rsp+0xB0], xmm11
000079035dde34b0  vmovaps [rsp+0xC0], xmm12
000079035dde34b9  vmovaps [rsp+0xD0], xmm13
000079035dde34c2  vmovaps [rsp+0xE0], xmm15
000079035dde34cb  sub rsp, 0x30
000079035dde34cf  movaps [rsp], xmm14
000079035dde34d4  movaps [rsp+0x10], xmm12
000079035dde34da  movaps [rsp+0x20], xmm1
000079035dde34df  lea rdi, [rsp]
000079035dde34e3  mov esi, 0x00
000079035dde34e8  mov rax, 0x64ACAA8B0530
000079035dde34f2  call rax
000079035dde34f4  movaps xmm14, [rsp]
000079035dde34f9  add rsp, 0x30
000079035dde34fd  vmovaps xmm0, [rsp]
000079035dde3502  vmovaps xmm1, [rsp+0x10]
000079035dde3508  vmovaps xmm2, [rsp+0x20]
000079035dde350e  vmovaps xmm3, [rsp+0x30]
000079035dde3514  vmovaps xmm4, [rsp+0x40]
000079035dde351a  vmovaps xmm5, [rsp+0x50]
000079035dde3520  vmovaps xmm6, [rsp+0x60]
000079035dde3526  vmovaps xmm7, [rsp+0x70]
000079035dde352c  vmovaps xmm8, [rsp+0x80]
000079035dde3535  vmovaps xmm9, [rsp+0x90]
000079035dde353e  vmovaps xmm10, [rsp+0xA0]
000079035dde3547  vmovaps xmm11, [rsp+0xB0]
000079035dde3550  vmovaps xmm12, [rsp+0xC0]
000079035dde3559  vmovaps xmm13, [rsp+0xD0]
000079035dde3562  vmovaps xmm15, [rsp+0xE0]
000079035dde356b  add rsp, 0xF0
000079035dde3572  pop r11
000079035dde3574  pop r10
000079035dde3576  pop r9
000079035dde3578  pop r8
000079035dde357a  pop rsi
000079035dde357b  pop rdi
000079035dde357c  pop rdx
000079035dde357d  pop rcx
000079035dde357e  pop rax
000079035dde357f  add rsp, 0x08
000079035dde3583  jmp 0x000079035DDDF793
000079035dde3588  sub rsp, 0x08
000079035dde358c  push rax
000079035dde358d  push rcx
000079035dde358e  push rdx
000079035dde358f  push rdi
000079035dde3590  push rsi
000079035dde3591  push r8
000079035dde3593  push r9
000079035dde3595  push r10
000079035dde3597  push r11
000079035dde3599  sub rsp, 0xF0
000079035dde35a0  vmovaps [rsp], xmm0
000079035dde35a5  vmovaps [rsp+0x10], xmm2
000079035dde35ab  vmovaps [rsp+0x20], xmm3
000079035dde35b1  vmovaps [rsp+0x30], xmm4
000079035dde35b7  vmovaps [rsp+0x40], xmm5
000079035dde35bd  vmovaps [rsp+0x50], xmm6
000079035dde35c3  vmovaps [rsp+0x60], xmm7
000079035dde35c9  vmovaps [rsp+0x70], xmm8
000079035dde35cf  vmovaps [rsp+0x80], xmm9
000079035dde35d8  vmovaps [rsp+0x90], xmm10
000079035dde35e1  vmovaps [rsp+0xA0], xmm11
000079035dde35ea  vmovaps [rsp+0xB0], xmm12
000079035dde35f3  vmovaps [rsp+0xC0], xmm13
000079035dde35fc  vmovaps [rsp+0xD0], xmm14
000079035dde3605  vmovaps [rsp+0xE0], xmm15
000079035dde360e  sub rsp, 0x30
000079035dde3612  movaps [rsp], xmm1
000079035dde3616  movaps [rsp+0x10], xmm13
000079035dde361c  movaps [rsp+0x20], xmm9
000079035dde3622  lea rdi, [rsp]
000079035dde3626  mov esi, 0x00
000079035dde362b  mov rax, 0x64ACAA8B0530
000079035dde3635  call rax
000079035dde3637  movaps xmm1, [rsp]
000079035dde363b  add rsp, 0x30
000079035dde363f  vmovaps xmm0, [rsp]
000079035dde3644  vmovaps xmm2, [rsp+0x10]
000079035dde364a  vmovaps xmm3, [rsp+0x20]
000079035dde3650  vmovaps xmm4, [rsp+0x30]
000079035dde3656  vmovaps xmm5, [rsp+0x40]
000079035dde365c  vmovaps xmm6, [rsp+0x50]
000079035dde3662  vmovaps xmm7, [rsp+0x60]
000079035dde3668  vmovaps xmm8, [rsp+0x70]
000079035dde366e  vmovaps xmm9, [rsp+0x80]
000079035dde3677  vmovaps xmm10, [rsp+0x90]
000079035dde3680  vmovaps xmm11, [rsp+0xA0]
000079035dde3689  vmovaps xmm12, [rsp+0xB0]
000079035dde3692  vmovaps xmm13, [rsp+0xC0]
000079035dde369b  vmovaps xmm14, [rsp+0xD0]
000079035dde36a4  vmovaps xmm15, [rsp+0xE0]
000079035dde36ad  add rsp, 0xF0
000079035dde36b4  pop r11
000079035dde36b6  pop r10
000079035dde36b8  pop r9
000079035dde36ba  pop r8
000079035dde36bc  pop rsi
000079035dde36bd  pop rdi
000079035dde36be  pop rdx
000079035dde36bf  pop rcx
000079035dde36c0  pop rax
000079035dde36c1  add rsp, 0x08
000079035dde36c5  jmp 0x000079035DDDF7AD
000079035dde36ca  sub rsp, 0x08
000079035dde36ce  push rax
000079035dde36cf  push rcx
000079035dde36d0  push rdx
000079035dde36d1  push rdi
000079035dde36d2  push rsi
000079035dde36d3  push r8
000079035dde36d5  push r9
000079035dde36d7  push r10
000079035dde36d9  push r11
000079035dde36db  sub rsp, 0xF0
000079035dde36e2  vmovaps [rsp], xmm0
000079035dde36e7  vmovaps [rsp+0x10], xmm1
000079035dde36ed  vmovaps [rsp+0x20], xmm2
000079035dde36f3  vmovaps [rsp+0x30], xmm3
000079035dde36f9  vmovaps [rsp+0x40], xmm4
000079035dde36ff  vmovaps [rsp+0x50], xmm5
000079035dde3705  vmovaps [rsp+0x60], xmm6
000079035dde370b  vmovaps [rsp+0x70], xmm7
000079035dde3711  vmovaps [rsp+0x80], xmm8
000079035dde371a  vmovaps [rsp+0x90], xmm9
000079035dde3723  vmovaps [rsp+0xA0], xmm10
000079035dde372c  vmovaps [rsp+0xB0], xmm11
000079035dde3735  vmovaps [rsp+0xC0], xmm13
000079035dde373e  vmovaps [rsp+0xD0], xmm14
000079035dde3747  vmovaps [rsp+0xE0], xmm15
000079035dde3750  sub rsp, 0x30
000079035dde3754  movaps [rsp], xmm12
000079035dde3759  movaps [rsp+0x10], xmm7
000079035dde375e  movaps [rsp+0x20], xmm13
000079035dde3764  lea rdi, [rsp]
000079035dde3768  mov esi, 0x00
000079035dde376d  mov rax, 0x64ACAA8B0530
000079035dde3777  call rax
000079035dde3779  movaps xmm12, [rsp]
000079035dde377e  add rsp, 0x30
000079035dde3782  vmovaps xmm0, [rsp]
000079035dde3787  vmovaps xmm1, [rsp+0x10]
000079035dde378d  vmovaps xmm2, [rsp+0x20]
000079035dde3793  vmovaps xmm3, [rsp+0x30]
000079035dde3799  vmovaps xmm4, [rsp+0x40]
000079035dde379f  vmovaps xmm5, [rsp+0x50]
000079035dde37a5  vmovaps xmm6, [rsp+0x60]
000079035dde37ab  vmovaps xmm7, [rsp+0x70]
000079035dde37b1  vmovaps xmm8, [rsp+0x80]
000079035dde37ba  vmovaps xmm9, [rsp+0x90]
000079035dde37c3  vmovaps xmm10, [rsp+0xA0]
000079035dde37cc  vmovaps xmm11, [rsp+0xB0]
000079035dde37d5  vmovaps xmm13, [rsp+0xC0]
000079035dde37de  vmovaps xmm14, [rsp+0xD0]
000079035dde37e7  vmovaps xmm15, [rsp+0xE0]
000079035dde37f0  add rsp, 0xF0
000079035dde37f7  pop r11
000079035dde37f9  pop r10
000079035dde37fb  pop r9
000079035dde37fd  pop r8
000079035dde37ff  pop rsi
000079035dde3800  pop rdi
000079035dde3801  pop rdx
000079035dde3802  pop rcx
000079035dde3803  pop rax
000079035dde3804  add rsp, 0x08
000079035dde3808  jmp 0x000079035DDDF7D4
000079035dde380d  sub rsp, 0x08
000079035dde3811  push rax
000079035dde3812  push rcx
000079035dde3813  push rdx
000079035dde3814  push rdi
000079035dde3815  push rsi
000079035dde3816  push r8
000079035dde3818  push r9
000079035dde381a  push r10
000079035dde381c  push r11
000079035dde381e  sub rsp, 0xF0
000079035dde3825  vmovaps [rsp], xmm0
000079035dde382a  vmovaps [rsp+0x10], xmm1
000079035dde3830  vmovaps [rsp+0x20], xmm2
000079035dde3836  vmovaps [rsp+0x30], xmm3
000079035dde383c  vmovaps [rsp+0x40], xmm4
000079035dde3842  vmovaps [rsp+0x50], xmm5
000079035dde3848  vmovaps [rsp+0x60], xmm6
000079035dde384e  vmovaps [rsp+0x70], xmm7
000079035dde3854  vmovaps [rsp+0x80], xmm8
000079035dde385d  vmovaps [rsp+0x90], xmm9
000079035dde3866  vmovaps [rsp+0xA0], xmm10
000079035dde386f  vmovaps [rsp+0xB0], xmm11
000079035dde3878  vmovaps [rsp+0xC0], xmm12
000079035dde3881  vmovaps [rsp+0xD0], xmm14
000079035dde388a  vmovaps [rsp+0xE0], xmm15
000079035dde3893  sub rsp, 0x30
000079035dde3897  movaps [rsp], xmm13
000079035dde389c  movaps [rsp+0x10], xmm15
000079035dde38a2  movaps [rsp+0x20], xmm8
000079035dde38a8  lea rdi, [rsp]
000079035dde38ac  mov esi, 0x00
000079035dde38b1  mov rax, 0x64ACAA8B0530
000079035dde38bb  call rax
000079035dde38bd  movaps xmm13, [rsp]
000079035dde38c2  add rsp, 0x30
000079035dde38c6  vmovaps xmm0, [rsp]
000079035dde38cb  vmovaps xmm1, [rsp+0x10]
000079035dde38d1  vmovaps xmm2, [rsp+0x20]
000079035dde38d7  vmovaps xmm3, [rsp+0x30]
000079035dde38dd  vmovaps xmm4, [rsp+0x40]
000079035dde38e3  vmovaps xmm5, [rsp+0x50]
000079035dde38e9  vmovaps xmm6, [rsp+0x60]
000079035dde38ef  vmovaps xmm7, [rsp+0x70]
000079035dde38f5  vmovaps xmm8, [rsp+0x80]
000079035dde38fe  vmovaps xmm9, [rsp+0x90]
000079035dde3907  vmovaps xmm10, [rsp+0xA0]
000079035dde3910  vmovaps xmm11, [rsp+0xB0]
000079035dde3919  vmovaps xmm12, [rsp+0xC0]
000079035dde3922  vmovaps xmm14, [rsp+0xD0]
000079035dde392b  vmovaps xmm15, [rsp+0xE0]
000079035dde3934  add rsp, 0xF0
000079035dde393b  pop r11
000079035dde393d  pop r10
000079035dde393f  pop r9
000079035dde3941  pop r8
000079035dde3943  pop rsi
000079035dde3944  pop rdi
000079035dde3945  pop rdx
000079035dde3946  pop rcx
000079035dde3947  pop rax
000079035dde3948  add rsp, 0x08
000079035dde394c  jmp 0x000079035DDDF7EF
000079035dde3951  sub rsp, 0x08
000079035dde3955  push rax
000079035dde3956  push rcx
000079035dde3957  push rdx
000079035dde3958  push rdi
000079035dde3959  push rsi
000079035dde395a  push r8
000079035dde395c  push r9
000079035dde395e  push r10
000079035dde3960  push r11
000079035dde3962  sub rsp, 0xF0
000079035dde3969  vmovaps [rsp], xmm0
000079035dde396e  vmovaps [rsp+0x10], xmm1
000079035dde3974  vmovaps [rsp+0x20], xmm2
000079035dde397a  vmovaps [rsp+0x30], xmm3
000079035dde3980  vmovaps [rsp+0x40], xmm4
000079035dde3986  vmovaps [rsp+0x50], xmm5
000079035dde398c  vmovaps [rsp+0x60], xmm6
000079035dde3992  vmovaps [rsp+0x70], xmm7
000079035dde3998  vmovaps [rsp+0x80], xmm9
000079035dde39a1  vmovaps [rsp+0x90], xmm10
000079035dde39aa  vmovaps [rsp+0xA0], xmm11
000079035dde39b3  vmovaps [rsp+0xB0], xmm12
000079035dde39bc  vmovaps [rsp+0xC0], xmm13
000079035dde39c5  vmovaps [rsp+0xD0], xmm14
000079035dde39ce  vmovaps [rsp+0xE0], xmm15
000079035dde39d7  sub rsp, 0x30
000079035dde39db  movaps [rsp], xmm8
000079035dde39e0  movaps [rsp+0x10], xmm15
000079035dde39e6  movaps [rsp+0x20], xmm9
000079035dde39ec  lea rdi, [rsp]
000079035dde39f0  mov esi, 0x00
000079035dde39f5  mov rax, 0x64ACAA8B0530
000079035dde39ff  call rax
000079035dde3a01  movaps xmm8, [rsp]
000079035dde3a06  add rsp, 0x30
000079035dde3a0a  vmovaps xmm0, [rsp]
000079035dde3a0f  vmovaps xmm1, [rsp+0x10]
000079035dde3a15  vmovaps xmm2, [rsp+0x20]
000079035dde3a1b  vmovaps xmm3, [rsp+0x30]
000079035dde3a21  vmovaps xmm4, [rsp+0x40]
000079035dde3a27  vmovaps xmm5, [rsp+0x50]
000079035dde3a2d  vmovaps xmm6, [rsp+0x60]
000079035dde3a33  vmovaps xmm7, [rsp+0x70]
000079035dde3a39  vmovaps xmm9, [rsp+0x80]
000079035dde3a42  vmovaps xmm10, [rsp+0x90]
000079035dde3a4b  vmovaps xmm11, [rsp+0xA0]
000079035dde3a54  vmovaps xmm12, [rsp+0xB0]
000079035dde3a5d  vmovaps xmm13, [rsp+0xC0]
000079035dde3a66  vmovaps xmm14, [rsp+0xD0]
000079035dde3a6f  vmovaps xmm15, [rsp+0xE0]
000079035dde3a78  add rsp, 0xF0
000079035dde3a7f  pop r11
000079035dde3a81  pop r10
000079035dde3a83  pop r9
000079035dde3a85  pop r8
000079035dde3a87  pop rsi
000079035dde3a88  pop rdi
000079035dde3a89  pop rdx
000079035dde3a8a  pop rcx
000079035dde3a8b  pop rax
000079035dde3a8c  add rsp, 0x08
000079035dde3a90  jmp 0x000079035DDDF81D
000079035dde3a95  sub rsp, 0x08
000079035dde3a99  push rax
000079035dde3a9a  push rcx
000079035dde3a9b  push rdx
000079035dde3a9c  push rdi
000079035dde3a9d  push rsi
000079035dde3a9e  push r8
000079035dde3aa0  push r9
000079035dde3aa2  push r10
000079035dde3aa4  push r11
000079035dde3aa6  sub rsp, 0xF0
000079035dde3aad  vmovaps [rsp], xmm0
000079035dde3ab2  vmovaps [rsp+0x10], xmm1
000079035dde3ab8  vmovaps [rsp+0x20], xmm2
000079035dde3abe  vmovaps [rsp+0x30], xmm3
000079035dde3ac4  vmovaps [rsp+0x40], xmm4
000079035dde3aca  vmovaps [rsp+0x50], xmm5
000079035dde3ad0  vmovaps [rsp+0x60], xmm6
000079035dde3ad6  vmovaps [rsp+0x70], xmm7
000079035dde3adc  vmovaps [rsp+0x80], xmm8
000079035dde3ae5  vmovaps [rsp+0x90], xmm9
000079035dde3aee  vmovaps [rsp+0xA0], xmm10
000079035dde3af7  vmovaps [rsp+0xB0], xmm11
000079035dde3b00  vmovaps [rsp+0xC0], xmm12
000079035dde3b09  vmovaps [rsp+0xD0], xmm13
000079035dde3b12  vmovaps [rsp+0xE0], xmm14
000079035dde3b1b  sub rsp, 0x30
000079035dde3b1f  movaps [rsp], xmm15
000079035dde3b24  movaps [rsp+0x10], xmm11
000079035dde3b2a  movaps [rsp+0x20], xmm6
000079035dde3b2f  lea rdi, [rsp]
000079035dde3b33  mov esi, 0x00
000079035dde3b38  mov rax, 0x64ACAA8B0530
000079035dde3b42  call rax
000079035dde3b44  movaps xmm15, [rsp]
000079035dde3b49  add rsp, 0x30
000079035dde3b4d  vmovaps xmm0, [rsp]
000079035dde3b52  vmovaps xmm1, [rsp+0x10]
000079035dde3b58  vmovaps xmm2, [rsp+0x20]
000079035dde3b5e  vmovaps xmm3, [rsp+0x30]
000079035dde3b64  vmovaps xmm4, [rsp+0x40]
000079035dde3b6a  vmovaps xmm5, [rsp+0x50]
000079035dde3b70  vmovaps xmm6, [rsp+0x60]
000079035dde3b76  vmovaps xmm7, [rsp+0x70]
000079035dde3b7c  vmovaps xmm8, [rsp+0x80]
000079035dde3b85  vmovaps xmm9, [rsp+0x90]
000079035dde3b8e  vmovaps xmm10, [rsp+0xA0]
000079035dde3b97  vmovaps xmm11, [rsp+0xB0]
000079035dde3ba0  vmovaps xmm12, [rsp+0xC0]
000079035dde3ba9  vmovaps xmm13, [rsp+0xD0]
000079035dde3bb2  vmovaps xmm14, [rsp+0xE0]
000079035dde3bbb  add rsp, 0xF0
000079035dde3bc2  pop r11
000079035dde3bc4  pop r10
000079035dde3bc6  pop r9
000079035dde3bc8  pop r8
000079035dde3bca  pop rsi
000079035dde3bcb  pop rdi
000079035dde3bcc  pop rdx
000079035dde3bcd  pop rcx
000079035dde3bce  pop rax
000079035dde3bcf  add rsp, 0x08
000079035dde3bd3  jmp 0x000079035DDDF838
000079035dde3bd8  sub rsp, 0x08
000079035dde3bdc  push rax
000079035dde3bdd  push rcx
000079035dde3bde  push rdx
000079035dde3bdf  push rdi
000079035dde3be0  push rsi
000079035dde3be1  push r8
000079035dde3be3  push r9
000079035dde3be5  push r10
000079035dde3be7  push r11
000079035dde3be9  sub rsp, 0xF0
000079035dde3bf0  vmovaps [rsp], xmm0
000079035dde3bf5  vmovaps [rsp+0x10], xmm1
000079035dde3bfb  vmovaps [rsp+0x20], xmm2
000079035dde3c01  vmovaps [rsp+0x30], xmm3
000079035dde3c07  vmovaps [rsp+0x40], xmm4
000079035dde3c0d  vmovaps [rsp+0x50], xmm5
000079035dde3c13  vmovaps [rsp+0x60], xmm6
000079035dde3c19  vmovaps [rsp+0x70], xmm8
000079035dde3c1f  vmovaps [rsp+0x80], xmm9
000079035dde3c28  vmovaps [rsp+0x90], xmm10
000079035dde3c31  vmovaps [rsp+0xA0], xmm11
000079035dde3c3a  vmovaps [rsp+0xB0], xmm12
000079035dde3c43  vmovaps [rsp+0xC0], xmm13
000079035dde3c4c  vmovaps [rsp+0xD0], xmm14
000079035dde3c55  vmovaps [rsp+0xE0], xmm15
000079035dde3c5e  sub rsp, 0x30
000079035dde3c62  movaps [rsp], xmm7
000079035dde3c66  movaps [rsp+0x10], xmm11
000079035dde3c6c  movaps [rsp+0x20], xmm9
000079035dde3c72  lea rdi, [rsp]
000079035dde3c76  mov esi, 0x00
000079035dde3c7b  mov rax, 0x64ACAA8B0530
000079035dde3c85  call rax
000079035dde3c87  movaps xmm7, [rsp]
000079035dde3c8b  add rsp, 0x30
000079035dde3c8f  vmovaps xmm0, [rsp]
000079035dde3c94  vmovaps xmm1, [rsp+0x10]
000079035dde3c9a  vmovaps xmm2, [rsp+0x20]
000079035dde3ca0  vmovaps xmm3, [rsp+0x30]
000079035dde3ca6  vmovaps xmm4, [rsp+0x40]
000079035dde3cac  vmovaps xmm5, [rsp+0x50]
000079035dde3cb2  vmovaps xmm6, [rsp+0x60]
000079035dde3cb8  vmovaps xmm8, [rsp+0x70]
000079035dde3cbe  vmovaps xmm9, [rsp+0x80]
000079035dde3cc7  vmovaps xmm10, [rsp+0x90]
000079035dde3cd0  vmovaps xmm11, [rsp+0xA0]
000079035dde3cd9  vmovaps xmm12, [rsp+0xB0]
000079035dde3ce2  vmovaps xmm13, [rsp+0xC0]
000079035dde3ceb  vmovaps xmm14, [rsp+0xD0]
000079035dde3cf4  vmovaps xmm15, [rsp+0xE0]
000079035dde3cfd  add rsp, 0xF0
000079035dde3d04  pop r11
000079035dde3d06  pop r10
000079035dde3d08  pop r9
000079035dde3d0a  pop r8
000079035dde3d0c  pop rsi
000079035dde3d0d  pop rdi
000079035dde3d0e  pop rdx
000079035dde3d0f  pop rcx
000079035dde3d10  pop rax
000079035dde3d11  add rsp, 0x08
000079035dde3d15  jmp 0x000079035DDDF865
000079035dde3d1a  sub rsp, 0x08
000079035dde3d1e  push rax
000079035dde3d1f  push rcx
000079035dde3d20  push rdx
000079035dde3d21  push rdi
000079035dde3d22  push rsi
000079035dde3d23  push r8
000079035dde3d25  push r9
000079035dde3d27  push r10
000079035dde3d29  push r11
000079035dde3d2b  sub rsp, 0xF0
000079035dde3d32  vmovaps [rsp], xmm0
000079035dde3d37  vmovaps [rsp+0x10], xmm1
000079035dde3d3d  vmovaps [rsp+0x20], xmm2
000079035dde3d43  vmovaps [rsp+0x30], xmm3
000079035dde3d49  vmovaps [rsp+0x40], xmm4
000079035dde3d4f  vmovaps [rsp+0x50], xmm5
000079035dde3d55  vmovaps [rsp+0x60], xmm6
000079035dde3d5b  vmovaps [rsp+0x70], xmm7
000079035dde3d61  vmovaps [rsp+0x80], xmm8
000079035dde3d6a  vmovaps [rsp+0x90], xmm9
000079035dde3d73  vmovaps [rsp+0xA0], xmm10
000079035dde3d7c  vmovaps [rsp+0xB0], xmm12
000079035dde3d85  vmovaps [rsp+0xC0], xmm13
000079035dde3d8e  vmovaps [rsp+0xD0], xmm14
000079035dde3d97  vmovaps [rsp+0xE0], xmm15
000079035dde3da0  sub rsp, 0x30
000079035dde3da4  movaps [rsp], xmm11
000079035dde3da9  movaps [rsp+0x10], xmm10
000079035dde3daf  movaps [rsp+0x20], xmm14
000079035dde3db5  lea rdi, [rsp]
000079035dde3db9  mov esi, 0x00
000079035dde3dbe  mov rax, 0x64ACAA8B0530
000079035dde3dc8  call rax
000079035dde3dca  movaps xmm11, [rsp]
000079035dde3dcf  add rsp, 0x30
000079035dde3dd3  vmovaps xmm0, [rsp]
000079035dde3dd8  vmovaps xmm1, [rsp+0x10]
000079035dde3dde  vmovaps xmm2, [rsp+0x20]
000079035dde3de4  vmovaps xmm3, [rsp+0x30]
000079035dde3dea  vmovaps xmm4, [rsp+0x40]
000079035dde3df0  vmovaps xmm5, [rsp+0x50]
000079035dde3df6  vmovaps xmm6, [rsp+0x60]
000079035dde3dfc  vmovaps xmm7, [rsp+0x70]
000079035dde3e02  vmovaps xmm8, [rsp+0x80]
000079035dde3e0b  vmovaps xmm9, [rsp+0x90]
000079035dde3e14  vmovaps xmm10, [rsp+0xA0]
000079035dde3e1d  vmovaps xmm12, [rsp+0xB0]
000079035dde3e26  vmovaps xmm13, [rsp+0xC0]
000079035dde3e2f  vmovaps xmm14, [rsp+0xD0]
000079035dde3e38  vmovaps xmm15, [rsp+0xE0]
000079035dde3e41  add rsp, 0xF0
000079035dde3e48  pop r11
000079035dde3e4a  pop r10
000079035dde3e4c  pop r9
000079035dde3e4e  pop r8
000079035dde3e50  pop rsi
000079035dde3e51  pop rdi
000079035dde3e52  pop rdx
000079035dde3e53  pop rcx
000079035dde3e54  pop rax
000079035dde3e55  add rsp, 0x08
000079035dde3e59  jmp 0x000079035DDDF880
000079035dde3e5e  call 0x000079035DCC33A0
000079035dde3e63  jmp 0x000079035DDDF88A
000079035dde3e68  sub rsp, 0x08
000079035dde3e6c  push rax
000079035dde3e6d  push rcx
000079035dde3e6e  push rdx
000079035dde3e6f  push rdi
000079035dde3e70  push rsi
000079035dde3e71  push r8
000079035dde3e73  push r9
000079035dde3e75  push r10
000079035dde3e77  push r11
000079035dde3e79  sub rsp, 0xF0
000079035dde3e80  vmovaps [rsp], xmm0
000079035dde3e85  vmovaps [rsp+0x10], xmm1
000079035dde3e8b  vmovaps [rsp+0x20], xmm2
000079035dde3e91  vmovaps [rsp+0x30], xmm3
000079035dde3e97  vmovaps [rsp+0x40], xmm4
000079035dde3e9d  vmovaps [rsp+0x50], xmm5
000079035dde3ea3  vmovaps [rsp+0x60], xmm6
000079035dde3ea9  vmovaps [rsp+0x70], xmm7
000079035dde3eaf  vmovaps [rsp+0x80], xmm8
000079035dde3eb8  vmovaps [rsp+0x90], xmm9
000079035dde3ec1  vmovaps [rsp+0xA0], xmm11
000079035dde3eca  vmovaps [rsp+0xB0], xmm12
000079035dde3ed3  vmovaps [rsp+0xC0], xmm13
000079035dde3edc  vmovaps [rsp+0xD0], xmm14
000079035dde3ee5  vmovaps [rsp+0xE0], xmm15
000079035dde3eee  sub rsp, 0x30
000079035dde3ef2  movaps [rsp], xmm10
000079035dde3ef7  movaps [rsp+0x10], xmm1
000079035dde3efc  movaps [rsp+0x20], xmm12
000079035dde3f02  lea rdi, [rsp]
000079035dde3f06  mov esi, 0x00
000079035dde3f0b  mov rax, 0x64ACAA8B0530
000079035dde3f15  call rax
000079035dde3f17  movaps xmm10, [rsp]
000079035dde3f1c  add rsp, 0x30
000079035dde3f20  vmovaps xmm0, [rsp]
000079035dde3f25  vmovaps xmm1, [rsp+0x10]
000079035dde3f2b  vmovaps xmm2, [rsp+0x20]
000079035dde3f31  vmovaps xmm3, [rsp+0x30]
000079035dde3f37  vmovaps xmm4, [rsp+0x40]
000079035dde3f3d  vmovaps xmm5, [rsp+0x50]
000079035dde3f43  vmovaps xmm6, [rsp+0x60]
000079035dde3f49  vmovaps xmm7, [rsp+0x70]
000079035dde3f4f  vmovaps xmm8, [rsp+0x80]
000079035dde3f58  vmovaps xmm9, [rsp+0x90]
000079035dde3f61  vmovaps xmm11, [rsp+0xA0]
000079035dde3f6a  vmovaps xmm12, [rsp+0xB0]
000079035dde3f73  vmovaps xmm13, [rsp+0xC0]
000079035dde3f7c  vmovaps xmm14, [rsp+0xD0]
000079035dde3f85  vmovaps xmm15, [rsp+0xE0]
000079035dde3f8e  add rsp, 0xF0
000079035dde3f95  pop r11
000079035dde3f97  pop r10
000079035dde3f99  pop r9
000079035dde3f9b  pop r8
000079035dde3f9d  pop rsi
000079035dde3f9e  pop rdi
000079035dde3f9f  pop rdx
000079035dde3fa0  pop rcx
000079035dde3fa1  pop rax
000079035dde3fa2  add rsp, 0x08
000079035dde3fa6  jmp 0x000079035DDDF8AD
000079035dde3fab  sub rsp, 0x08
000079035dde3faf  push rax
000079035dde3fb0  push rcx
000079035dde3fb1  push rdx
000079035dde3fb2  push rdi
000079035dde3fb3  push rsi
000079035dde3fb4  push r8
000079035dde3fb6  push r9
000079035dde3fb8  push r10
000079035dde3fba  push r11
000079035dde3fbc  sub rsp, 0xF0
000079035dde3fc3  vmovaps [rsp], xmm0
000079035dde3fc8  vmovaps [rsp+0x10], xmm1
000079035dde3fce  vmovaps [rsp+0x20], xmm2
000079035dde3fd4  vmovaps [rsp+0x30], xmm3
000079035dde3fda  vmovaps [rsp+0x40], xmm4
000079035dde3fe0  vmovaps [rsp+0x50], xmm5
000079035dde3fe6  vmovaps [rsp+0x60], xmm6
000079035dde3fec  vmovaps [rsp+0x70], xmm7
000079035dde3ff2  vmovaps [rsp+0x80], xmm8
000079035dde3ffb  vmovaps [rsp+0x90], xmm9
000079035dde4004  vmovaps [rsp+0xA0], xmm10
000079035dde400d  vmovaps [rsp+0xB0], xmm11
000079035dde4016  vmovaps [rsp+0xC0], xmm13
000079035dde401f  vmovaps [rsp+0xD0], xmm14
000079035dde4028  vmovaps [rsp+0xE0], xmm15
000079035dde4031  sub rsp, 0x30
000079035dde4035  movaps [rsp], xmm12
000079035dde403a  movaps [rsp+0x10], xmm14
000079035dde4040  movaps [rsp+0x20], xmm1
000079035dde4045  lea rdi, [rsp]
000079035dde4049  mov esi, 0x00
000079035dde404e  mov rax, 0x64ACAA8B0530
000079035dde4058  call rax
000079035dde405a  movaps xmm12, [rsp]
000079035dde405f  add rsp, 0x30
000079035dde4063  vmovaps xmm0, [rsp]
000079035dde4068  vmovaps xmm1, [rsp+0x10]
000079035dde406e  vmovaps xmm2, [rsp+0x20]
000079035dde4074  vmovaps xmm3, [rsp+0x30]
000079035dde407a  vmovaps xmm4, [rsp+0x40]
000079035dde4080  vmovaps xmm5, [rsp+0x50]
000079035dde4086  vmovaps xmm6, [rsp+0x60]
000079035dde408c  vmovaps xmm7, [rsp+0x70]
000079035dde4092  vmovaps xmm8, [rsp+0x80]
000079035dde409b  vmovaps xmm9, [rsp+0x90]
000079035dde40a4  vmovaps xmm10, [rsp+0xA0]
000079035dde40ad  vmovaps xmm11, [rsp+0xB0]
000079035dde40b6  vmovaps xmm13, [rsp+0xC0]
000079035dde40bf  vmovaps xmm14, [rsp+0xD0]
000079035dde40c8  vmovaps xmm15, [rsp+0xE0]
000079035dde40d1  add rsp, 0xF0
000079035dde40d8  pop r11
000079035dde40da  pop r10
000079035dde40dc  pop r9
000079035dde40de  pop r8
000079035dde40e0  pop rsi
000079035dde40e1  pop rdi
000079035dde40e2  pop rdx
000079035dde40e3  pop rcx
000079035dde40e4  pop rax
000079035dde40e5  add rsp, 0x08
000079035dde40e9  jmp 0x000079035DDDF8DC
000079035dde40ee  sub rsp, 0x08
000079035dde40f2  push rax
000079035dde40f3  push rcx
000079035dde40f4  push rdx
000079035dde40f5  push rdi
000079035dde40f6  push rsi
000079035dde40f7  push r8
000079035dde40f9  push r9
000079035dde40fb  push r10
000079035dde40fd  push r11
000079035dde40ff  sub rsp, 0xF0
000079035dde4106  vmovaps [rsp], xmm0
000079035dde410b  vmovaps [rsp+0x10], xmm1
000079035dde4111  vmovaps [rsp+0x20], xmm2
000079035dde4117  vmovaps [rsp+0x30], xmm3
000079035dde411d  vmovaps [rsp+0x40], xmm4
000079035dde4123  vmovaps [rsp+0x50], xmm5
000079035dde4129  vmovaps [rsp+0x60], xmm6
000079035dde412f  vmovaps [rsp+0x70], xmm7
000079035dde4135  vmovaps [rsp+0x80], xmm8
000079035dde413e  vmovaps [rsp+0x90], xmm9
000079035dde4147  vmovaps [rsp+0xA0], xmm10
000079035dde4150  vmovaps [rsp+0xB0], xmm11
000079035dde4159  vmovaps [rsp+0xC0], xmm12
000079035dde4162  vmovaps [rsp+0xD0], xmm13
000079035dde416b  vmovaps [rsp+0xE0], xmm15
000079035dde4174  sub rsp, 0x30
000079035dde4178  movaps [rsp], xmm14
000079035dde417d  movaps [rsp+0x10], xmm9
000079035dde4183  movaps [rsp+0x20], xmm1
000079035dde4188  lea rdi, [rsp]
000079035dde418c  mov esi, 0x00
000079035dde4191  mov rax, 0x64ACAA8B0530
000079035dde419b  call rax
000079035dde419d  movaps xmm14, [rsp]
000079035dde41a2  add rsp, 0x30
000079035dde41a6  vmovaps xmm0, [rsp]
000079035dde41ab  vmovaps xmm1, [rsp+0x10]
000079035dde41b1  vmovaps xmm2, [rsp+0x20]
000079035dde41b7  vmovaps xmm3, [rsp+0x30]
000079035dde41bd  vmovaps xmm4, [rsp+0x40]
000079035dde41c3  vmovaps xmm5, [rsp+0x50]
000079035dde41c9  vmovaps xmm6, [rsp+0x60]
000079035dde41cf  vmovaps xmm7, [rsp+0x70]
000079035dde41d5  vmovaps xmm8, [rsp+0x80]
000079035dde41de  vmovaps xmm9, [rsp+0x90]
000079035dde41e7  vmovaps xmm10, [rsp+0xA0]
000079035dde41f0  vmovaps xmm11, [rsp+0xB0]
000079035dde41f9  vmovaps xmm12, [rsp+0xC0]
000079035dde4202  vmovaps xmm13, [rsp+0xD0]
000079035dde420b  vmovaps xmm15, [rsp+0xE0]
000079035dde4214  add rsp, 0xF0
000079035dde421b  pop r11
000079035dde421d  pop r10
000079035dde421f  pop r9
000079035dde4221  pop r8
000079035dde4223  pop rsi
000079035dde4224  pop rdi
000079035dde4225  pop rdx
000079035dde4226  pop rcx
000079035dde4227  pop rax
000079035dde4228  add rsp, 0x08
000079035dde422c  jmp 0x000079035DDDF90B
000079035dde4231  sub rsp, 0x08
000079035dde4235  push rax
000079035dde4236  push rcx
000079035dde4237  push rdx
000079035dde4238  push rdi
000079035dde4239  push rsi
000079035dde423a  push r8
000079035dde423c  push r9
000079035dde423e  push r10
000079035dde4240  push r11
000079035dde4242  sub rsp, 0xF0
000079035dde4249  vmovaps [rsp], xmm0
000079035dde424e  vmovaps [rsp+0x10], xmm2
000079035dde4254  vmovaps [rsp+0x20], xmm3
000079035dde425a  vmovaps [rsp+0x30], xmm4
000079035dde4260  vmovaps [rsp+0x40], xmm5
000079035dde4266  vmovaps [rsp+0x50], xmm6
000079035dde426c  vmovaps [rsp+0x60], xmm7
000079035dde4272  vmovaps [rsp+0x70], xmm8
000079035dde4278  vmovaps [rsp+0x80], xmm9
000079035dde4281  vmovaps [rsp+0x90], xmm10
000079035dde428a  vmovaps [rsp+0xA0], xmm11
000079035dde4293  vmovaps [rsp+0xB0], xmm12
000079035dde429c  vmovaps [rsp+0xC0], xmm13
000079035dde42a5  vmovaps [rsp+0xD0], xmm14
000079035dde42ae  vmovaps [rsp+0xE0], xmm15
000079035dde42b7  sub rsp, 0x30
000079035dde42bb  movaps [rsp], xmm1
000079035dde42bf  movaps [rsp+0x10], xmm13
000079035dde42c5  movaps [rsp+0x20], xmm8
000079035dde42cb  lea rdi, [rsp]
000079035dde42cf  mov esi, 0x00
000079035dde42d4  mov rax, 0x64ACAA8B0530
000079035dde42de  call rax
000079035dde42e0  movaps xmm1, [rsp]
000079035dde42e4  add rsp, 0x30
000079035dde42e8  vmovaps xmm0, [rsp]
000079035dde42ed  vmovaps xmm2, [rsp+0x10]
000079035dde42f3  vmovaps xmm3, [rsp+0x20]
000079035dde42f9  vmovaps xmm4, [rsp+0x30]
000079035dde42ff  vmovaps xmm5, [rsp+0x40]
000079035dde4305  vmovaps xmm6, [rsp+0x50]
000079035dde430b  vmovaps xmm7, [rsp+0x60]
000079035dde4311  vmovaps xmm8, [rsp+0x70]
000079035dde4317  vmovaps xmm9, [rsp+0x80]
000079035dde4320  vmovaps xmm10, [rsp+0x90]
000079035dde4329  vmovaps xmm11, [rsp+0xA0]
000079035dde4332  vmovaps xmm12, [rsp+0xB0]
000079035dde433b  vmovaps xmm13, [rsp+0xC0]
000079035dde4344  vmovaps xmm14, [rsp+0xD0]
000079035dde434d  vmovaps xmm15, [rsp+0xE0]
000079035dde4356  add rsp, 0xF0
000079035dde435d  pop r11
000079035dde435f  pop r10
000079035dde4361  pop r9
000079035dde4363  pop r8
000079035dde4365  pop rsi
000079035dde4366  pop rdi
000079035dde4367  pop rdx
000079035dde4368  pop rcx
000079035dde4369  pop rax
000079035dde436a  add rsp, 0x08
000079035dde436e  jmp 0x000079035DDDF92D
000079035dde4373  call 0x000079035DC0C260
000079035dde4378  jmp 0x000079035DDDF93B
000079035dde437d  call 0x000079035DCBD750
000079035dde4382  jmp 0x000079035DDDF945
000079035dde4387  sub rsp, 0x08
000079035dde438b  push rax
000079035dde438c  push rcx
000079035dde438d  push rdx
000079035dde438e  push rdi
000079035dde438f  push rsi
000079035dde4390  push r8
000079035dde4392  push r9
000079035dde4394  push r10
000079035dde4396  push r11
000079035dde4398  sub rsp, 0xF0
000079035dde439f  vmovaps [rsp], xmm0
000079035dde43a4  vmovaps [rsp+0x10], xmm1
000079035dde43aa  vmovaps [rsp+0x20], xmm2
000079035dde43b0  vmovaps [rsp+0x30], xmm3
000079035dde43b6  vmovaps [rsp+0x40], xmm4
000079035dde43bc  vmovaps [rsp+0x50], xmm5
000079035dde43c2  vmovaps [rsp+0x60], xmm6
000079035dde43c8  vmovaps [rsp+0x70], xmm7
000079035dde43ce  vmovaps [rsp+0x80], xmm9
000079035dde43d7  vmovaps [rsp+0x90], xmm10
000079035dde43e0  vmovaps [rsp+0xA0], xmm11
000079035dde43e9  vmovaps [rsp+0xB0], xmm12
000079035dde43f2  vmovaps [rsp+0xC0], xmm13
000079035dde43fb  vmovaps [rsp+0xD0], xmm14
000079035dde4404  vmovaps [rsp+0xE0], xmm15
000079035dde440d  sub rsp, 0x30
000079035dde4411  movaps [rsp], xmm8
000079035dde4416  movaps [rsp+0x10], xmm15
000079035dde441c  movaps [rsp+0x20], xmm7
000079035dde4421  lea rdi, [rsp]
000079035dde4425  mov esi, 0x00
000079035dde442a  mov rax, 0x64ACAA8B0530
000079035dde4434  call rax
000079035dde4436  movaps xmm8, [rsp]
000079035dde443b  add rsp, 0x30
000079035dde443f  vmovaps xmm0, [rsp]
000079035dde4444  vmovaps xmm1, [rsp+0x10]
000079035dde444a  vmovaps xmm2, [rsp+0x20]
000079035dde4450  vmovaps xmm3, [rsp+0x30]
000079035dde4456  vmovaps xmm4, [rsp+0x40]
000079035dde445c  vmovaps xmm5, [rsp+0x50]
000079035dde4462  vmovaps xmm6, [rsp+0x60]
000079035dde4468  vmovaps xmm7, [rsp+0x70]
000079035dde446e  vmovaps xmm9, [rsp+0x80]
000079035dde4477  vmovaps xmm10, [rsp+0x90]
000079035dde4480  vmovaps xmm11, [rsp+0xA0]
000079035dde4489  vmovaps xmm12, [rsp+0xB0]
000079035dde4492  vmovaps xmm13, [rsp+0xC0]
000079035dde449b  vmovaps xmm14, [rsp+0xD0]
000079035dde44a4  vmovaps xmm15, [rsp+0xE0]
000079035dde44ad  add rsp, 0xF0
000079035dde44b4  pop r11
000079035dde44b6  pop r10
000079035dde44b8  pop r9
000079035dde44ba  pop r8
000079035dde44bc  pop rsi
000079035dde44bd  pop rdi
000079035dde44be  pop rdx
000079035dde44bf  pop rcx
000079035dde44c0  pop rax
000079035dde44c1  add rsp, 0x08
000079035dde44c5  jmp 0x000079035DDDF967
000079035dde44ca  sub rsp, 0x08
000079035dde44ce  push rax
000079035dde44cf  push rcx
000079035dde44d0  push rdx
000079035dde44d1  push rdi
000079035dde44d2  push rsi
000079035dde44d3  push r8
000079035dde44d5  push r9
000079035dde44d7  push r10
000079035dde44d9  push r11
000079035dde44db  sub rsp, 0xF0
000079035dde44e2  vmovaps [rsp], xmm0
000079035dde44e7  vmovaps [rsp+0x10], xmm1
000079035dde44ed  vmovaps [rsp+0x20], xmm2
000079035dde44f3  vmovaps [rsp+0x30], xmm3
000079035dde44f9  vmovaps [rsp+0x40], xmm4
000079035dde44ff  vmovaps [rsp+0x50], xmm5
000079035dde4505  vmovaps [rsp+0x60], xmm6
000079035dde450b  vmovaps [rsp+0x70], xmm8
000079035dde4511  vmovaps [rsp+0x80], xmm9
000079035dde451a  vmovaps [rsp+0x90], xmm10
000079035dde4523  vmovaps [rsp+0xA0], xmm11
000079035dde452c  vmovaps [rsp+0xB0], xmm12
000079035dde4535  vmovaps [rsp+0xC0], xmm13
000079035dde453e  vmovaps [rsp+0xD0], xmm14
000079035dde4547  vmovaps [rsp+0xE0], xmm15
000079035dde4550  sub rsp, 0x30
000079035dde4554  movaps [rsp], xmm7
000079035dde4558  movaps [rsp+0x10], xmm9
000079035dde455e  movaps [rsp+0x20], xmm15
000079035dde4564  lea rdi, [rsp]
000079035dde4568  mov esi, 0x00
000079035dde456d  mov rax, 0x64ACAA8B0530
000079035dde4577  call rax
000079035dde4579  movaps xmm7, [rsp]
000079035dde457d  add rsp, 0x30
000079035dde4581  vmovaps xmm0, [rsp]
000079035dde4586  vmovaps xmm1, [rsp+0x10]
000079035dde458c  vmovaps xmm2, [rsp+0x20]
000079035dde4592  vmovaps xmm3, [rsp+0x30]
000079035dde4598  vmovaps xmm4, [rsp+0x40]
000079035dde459e  vmovaps xmm5, [rsp+0x50]
000079035dde45a4  vmovaps xmm6, [rsp+0x60]
000079035dde45aa  vmovaps xmm8, [rsp+0x70]
000079035dde45b0  vmovaps xmm9, [rsp+0x80]
000079035dde45b9  vmovaps xmm10, [rsp+0x90]
000079035dde45c2  vmovaps xmm11, [rsp+0xA0]
000079035dde45cb  vmovaps xmm12, [rsp+0xB0]
000079035dde45d4  vmovaps xmm13, [rsp+0xC0]
000079035dde45dd  vmovaps xmm14, [rsp+0xD0]
000079035dde45e6  vmovaps xmm15, [rsp+0xE0]
000079035dde45ef  add rsp, 0xF0
000079035dde45f6  pop r11
000079035dde45f8  pop r10
000079035dde45fa  pop r9
000079035dde45fc  pop r8
000079035dde45fe  pop rsi
000079035dde45ff  pop rdi
000079035dde4600  pop rdx
000079035dde4601  pop rcx
000079035dde4602  pop rax
000079035dde4603  add rsp, 0x08
000079035dde4607  jmp 0x000079035DDDF994
000079035dde460c  sub rsp, 0x08
000079035dde4610  push rax
000079035dde4611  push rcx
000079035dde4612  push rdx
000079035dde4613  push rdi
000079035dde4614  push rsi
000079035dde4615  push r8
000079035dde4617  push r9
000079035dde4619  push r10
000079035dde461b  push r11
000079035dde461d  sub rsp, 0xF0
000079035dde4624  vmovaps [rsp], xmm0
000079035dde4629  vmovaps [rsp+0x10], xmm1
000079035dde462f  vmovaps [rsp+0x20], xmm2
000079035dde4635  vmovaps [rsp+0x30], xmm3
000079035dde463b  vmovaps [rsp+0x40], xmm4
000079035dde4641  vmovaps [rsp+0x50], xmm5
000079035dde4647  vmovaps [rsp+0x60], xmm6
000079035dde464d  vmovaps [rsp+0x70], xmm7
000079035dde4653  vmovaps [rsp+0x80], xmm8
000079035dde465c  vmovaps [rsp+0x90], xmm10
000079035dde4665  vmovaps [rsp+0xA0], xmm11
000079035dde466e  vmovaps [rsp+0xB0], xmm12
000079035dde4677  vmovaps [rsp+0xC0], xmm13
000079035dde4680  vmovaps [rsp+0xD0], xmm14
000079035dde4689  vmovaps [rsp+0xE0], xmm15
000079035dde4692  sub rsp, 0x30
000079035dde4696  movaps [rsp], xmm9
000079035dde469b  movaps [rsp+0x10], xmm13
000079035dde46a1  movaps [rsp+0x20], xmm15
000079035dde46a7  lea rdi, [rsp]
000079035dde46ab  mov esi, 0x00
000079035dde46b0  mov rax, 0x64ACAA8B0530
000079035dde46ba  call rax
000079035dde46bc  movaps xmm9, [rsp]
000079035dde46c1  add rsp, 0x30
000079035dde46c5  vmovaps xmm0, [rsp]
000079035dde46ca  vmovaps xmm1, [rsp+0x10]
000079035dde46d0  vmovaps xmm2, [rsp+0x20]
000079035dde46d6  vmovaps xmm3, [rsp+0x30]
000079035dde46dc  vmovaps xmm4, [rsp+0x40]
000079035dde46e2  vmovaps xmm5, [rsp+0x50]
000079035dde46e8  vmovaps xmm6, [rsp+0x60]
000079035dde46ee  vmovaps xmm7, [rsp+0x70]
000079035dde46f4  vmovaps xmm8, [rsp+0x80]
000079035dde46fd  vmovaps xmm10, [rsp+0x90]
000079035dde4706  vmovaps xmm11, [rsp+0xA0]
000079035dde470f  vmovaps xmm12, [rsp+0xB0]
000079035dde4718  vmovaps xmm13, [rsp+0xC0]
000079035dde4721  vmovaps xmm14, [rsp+0xD0]
000079035dde472a  vmovaps xmm15, [rsp+0xE0]
000079035dde4733  add rsp, 0xF0
000079035dde473a  pop r11
000079035dde473c  pop r10
000079035dde473e  pop r9
000079035dde4740  pop r8
000079035dde4742  pop rsi
000079035dde4743  pop rdi
000079035dde4744  pop rdx
000079035dde4745  pop rcx
000079035dde4746  pop rax
000079035dde4747  add rsp, 0x08
000079035dde474b  jmp 0x000079035DDDF9C2
000079035dde4750  sub rsp, 0x08
000079035dde4754  push rax
000079035dde4755  push rcx
000079035dde4756  push rdx
000079035dde4757  push rdi
000079035dde4758  push rsi
000079035dde4759  push r8
000079035dde475b  push r9
000079035dde475d  push r10
000079035dde475f  push r11
000079035dde4761  sub rsp, 0xF0
000079035dde4768  vmovaps [rsp], xmm0
000079035dde476d  vmovaps [rsp+0x10], xmm1
000079035dde4773  vmovaps [rsp+0x20], xmm2
000079035dde4779  vmovaps [rsp+0x30], xmm3
000079035dde477f  vmovaps [rsp+0x40], xmm4
000079035dde4785  vmovaps [rsp+0x50], xmm5
000079035dde478b  vmovaps [rsp+0x60], xmm6
000079035dde4791  vmovaps [rsp+0x70], xmm7
000079035dde4797  vmovaps [rsp+0x80], xmm8
000079035dde47a0  vmovaps [rsp+0x90], xmm9
000079035dde47a9  vmovaps [rsp+0xA0], xmm10
000079035dde47b2  vmovaps [rsp+0xB0], xmm11
000079035dde47bb  vmovaps [rsp+0xC0], xmm12
000079035dde47c4  vmovaps [rsp+0xD0], xmm13
000079035dde47cd  vmovaps [rsp+0xE0], xmm14
000079035dde47d6  sub rsp, 0x30
000079035dde47da  movaps [rsp], xmm15
000079035dde47df  movaps [rsp+0x10], xmm11
000079035dde47e5  movaps [rsp+0x20], xmm12
000079035dde47eb  lea rdi, [rsp]
000079035dde47ef  mov esi, 0x00
000079035dde47f4  mov rax, 0x64ACAA8B0530
000079035dde47fe  call rax
000079035dde4800  movaps xmm15, [rsp]
000079035dde4805  add rsp, 0x30
000079035dde4809  vmovaps xmm0, [rsp]
000079035dde480e  vmovaps xmm1, [rsp+0x10]
000079035dde4814  vmovaps xmm2, [rsp+0x20]
000079035dde481a  vmovaps xmm3, [rsp+0x30]
000079035dde4820  vmovaps xmm4, [rsp+0x40]
000079035dde4826  vmovaps xmm5, [rsp+0x50]
000079035dde482c  vmovaps xmm6, [rsp+0x60]
000079035dde4832  vmovaps xmm7, [rsp+0x70]
000079035dde4838  vmovaps xmm8, [rsp+0x80]
000079035dde4841  vmovaps xmm9, [rsp+0x90]
000079035dde484a  vmovaps xmm10, [rsp+0xA0]
000079035dde4853  vmovaps xmm11, [rsp+0xB0]
000079035dde485c  vmovaps xmm12, [rsp+0xC0]
000079035dde4865  vmovaps xmm13, [rsp+0xD0]
000079035dde486e  vmovaps xmm14, [rsp+0xE0]
000079035dde4877  add rsp, 0xF0
000079035dde487e  pop r11
000079035dde4880  pop r10
000079035dde4882  pop r9
000079035dde4884  pop r8
000079035dde4886  pop rsi
000079035dde4887  pop rdi
000079035dde4888  pop rdx
000079035dde4889  pop rcx
000079035dde488a  pop rax
000079035dde488b  add rsp, 0x08
000079035dde488f  jmp 0x000079035DDDF9DD
000079035dde4894  sub rsp, 0x08
000079035dde4898  push rax
000079035dde4899  push rcx
000079035dde489a  push rdx
000079035dde489b  push rdi
000079035dde489c  push rsi
000079035dde489d  push r8
000079035dde489f  push r9
000079035dde48a1  push r10
000079035dde48a3  push r11
000079035dde48a5  sub rsp, 0xF0
000079035dde48ac  vmovaps [rsp], xmm0
000079035dde48b1  vmovaps [rsp+0x10], xmm1
000079035dde48b7  vmovaps [rsp+0x20], xmm2
000079035dde48bd  vmovaps [rsp+0x30], xmm3
000079035dde48c3  vmovaps [rsp+0x40], xmm4
000079035dde48c9  vmovaps [rsp+0x50], xmm5
000079035dde48cf  vmovaps [rsp+0x60], xmm6
000079035dde48d5  vmovaps [rsp+0x70], xmm7
000079035dde48db  vmovaps [rsp+0x80], xmm8
000079035dde48e4  vmovaps [rsp+0x90], xmm9
000079035dde48ed  vmovaps [rsp+0xA0], xmm10
000079035dde48f6  vmovaps [rsp+0xB0], xmm11
000079035dde48ff  vmovaps [rsp+0xC0], xmm12
000079035dde4908  vmovaps [rsp+0xD0], xmm14
000079035dde4911  vmovaps [rsp+0xE0], xmm15
000079035dde491a  sub rsp, 0x30
000079035dde491e  movaps [rsp], xmm13
000079035dde4923  movaps [rsp+0x10], xmm10
000079035dde4929  movaps [rsp+0x20], xmm14
000079035dde492f  lea rdi, [rsp]
000079035dde4933  mov esi, 0x00
000079035dde4938  mov rax, 0x64ACAA8B0530
000079035dde4942  call rax
000079035dde4944  movaps xmm13, [rsp]
000079035dde4949  add rsp, 0x30
000079035dde494d  vmovaps xmm0, [rsp]
000079035dde4952  vmovaps xmm1, [rsp+0x10]
000079035dde4958  vmovaps xmm2, [rsp+0x20]
000079035dde495e  vmovaps xmm3, [rsp+0x30]
000079035dde4964  vmovaps xmm4, [rsp+0x40]
000079035dde496a  vmovaps xmm5, [rsp+0x50]
000079035dde4970  vmovaps xmm6, [rsp+0x60]
000079035dde4976  vmovaps xmm7, [rsp+0x70]
000079035dde497c  vmovaps xmm8, [rsp+0x80]
000079035dde4985  vmovaps xmm9, [rsp+0x90]
000079035dde498e  vmovaps xmm10, [rsp+0xA0]
000079035dde4997  vmovaps xmm11, [rsp+0xB0]
000079035dde49a0  vmovaps xmm12, [rsp+0xC0]
000079035dde49a9  vmovaps xmm14, [rsp+0xD0]
000079035dde49b2  vmovaps xmm15, [rsp+0xE0]
000079035dde49bb  add rsp, 0xF0
000079035dde49c2  pop r11
000079035dde49c4  pop r10
000079035dde49c6  pop r9
000079035dde49c8  pop r8
000079035dde49ca  pop rsi
000079035dde49cb  pop rdi
000079035dde49cc  pop rdx
000079035dde49cd  pop rcx
000079035dde49ce  pop rax
000079035dde49cf  add rsp, 0x08
000079035dde49d3  jmp 0x000079035DDDFA00
000079035dde49d8  sub rsp, 0x08
000079035dde49dc  push rax
000079035dde49dd  push rcx
000079035dde49de  push rdx
000079035dde49df  push rdi
000079035dde49e0  push rsi
000079035dde49e1  push r8
000079035dde49e3  push r9
000079035dde49e5  push r10
000079035dde49e7  push r11
000079035dde49e9  sub rsp, 0xF0
000079035dde49f0  vmovaps [rsp], xmm0
000079035dde49f5  vmovaps [rsp+0x10], xmm1
000079035dde49fb  vmovaps [rsp+0x20], xmm2
000079035dde4a01  vmovaps [rsp+0x30], xmm3
000079035dde4a07  vmovaps [rsp+0x40], xmm4
000079035dde4a0d  vmovaps [rsp+0x50], xmm5
000079035dde4a13  vmovaps [rsp+0x60], xmm6
000079035dde4a19  vmovaps [rsp+0x70], xmm7
000079035dde4a1f  vmovaps [rsp+0x80], xmm8
000079035dde4a28  vmovaps [rsp+0x90], xmm9
000079035dde4a31  vmovaps [rsp+0xA0], xmm10
000079035dde4a3a  vmovaps [rsp+0xB0], xmm11
000079035dde4a43  vmovaps [rsp+0xC0], xmm12
000079035dde4a4c  vmovaps [rsp+0xD0], xmm13
000079035dde4a55  vmovaps [rsp+0xE0], xmm15
000079035dde4a5e  sub rsp, 0x30
000079035dde4a62  movaps [rsp], xmm14
000079035dde4a67  movaps [rsp+0x10], xmm1
000079035dde4a6c  movaps [rsp+0x20], xmm7
000079035dde4a71  lea rdi, [rsp]
000079035dde4a75  mov esi, 0x00
000079035dde4a7a  mov rax, 0x64ACAA8B0530
000079035dde4a84  call rax
000079035dde4a86  movaps xmm14, [rsp]
000079035dde4a8b  add rsp, 0x30
000079035dde4a8f  vmovaps xmm0, [rsp]
000079035dde4a94  vmovaps xmm1, [rsp+0x10]
000079035dde4a9a  vmovaps xmm2, [rsp+0x20]
000079035dde4aa0  vmovaps xmm3, [rsp+0x30]
000079035dde4aa6  vmovaps xmm4, [rsp+0x40]
000079035dde4aac  vmovaps xmm5, [rsp+0x50]
000079035dde4ab2  vmovaps xmm6, [rsp+0x60]
000079035dde4ab8  vmovaps xmm7, [rsp+0x70]
000079035dde4abe  vmovaps xmm8, [rsp+0x80]
000079035dde4ac7  vmovaps xmm9, [rsp+0x90]
000079035dde4ad0  vmovaps xmm10, [rsp+0xA0]
000079035dde4ad9  vmovaps xmm11, [rsp+0xB0]
000079035dde4ae2  vmovaps xmm12, [rsp+0xC0]
000079035dde4aeb  vmovaps xmm13, [rsp+0xD0]
000079035dde4af4  vmovaps xmm15, [rsp+0xE0]
000079035dde4afd  add rsp, 0xF0
000079035dde4b04  pop r11
000079035dde4b06  pop r10
000079035dde4b08  pop r9
000079035dde4b0a  pop r8
000079035dde4b0c  pop rsi
000079035dde4b0d  pop rdi
000079035dde4b0e  pop rdx
000079035dde4b0f  pop rcx
000079035dde4b10  pop rax
000079035dde4b11  add rsp, 0x08
000079035dde4b15  jmp 0x000079035DDDFA23
000079035dde4b1a  sub rsp, 0x08
000079035dde4b1e  push rax
000079035dde4b1f  push rcx
000079035dde4b20  push rdx
000079035dde4b21  push rdi
000079035dde4b22  push rsi
000079035dde4b23  push r8
000079035dde4b25  push r9
000079035dde4b27  push r10
000079035dde4b29  push r11
000079035dde4b2b  sub rsp, 0xF0
000079035dde4b32  vmovaps [rsp], xmm0
000079035dde4b37  vmovaps [rsp+0x10], xmm2
000079035dde4b3d  vmovaps [rsp+0x20], xmm3
000079035dde4b43  vmovaps [rsp+0x30], xmm4
000079035dde4b49  vmovaps [rsp+0x40], xmm5
000079035dde4b4f  vmovaps [rsp+0x50], xmm6
000079035dde4b55  vmovaps [rsp+0x60], xmm7
000079035dde4b5b  vmovaps [rsp+0x70], xmm8
000079035dde4b61  vmovaps [rsp+0x80], xmm9
000079035dde4b6a  vmovaps [rsp+0x90], xmm10
000079035dde4b73  vmovaps [rsp+0xA0], xmm11
000079035dde4b7c  vmovaps [rsp+0xB0], xmm12
000079035dde4b85  vmovaps [rsp+0xC0], xmm13
000079035dde4b8e  vmovaps [rsp+0xD0], xmm14
000079035dde4b97  vmovaps [rsp+0xE0], xmm15
000079035dde4ba0  sub rsp, 0x30
000079035dde4ba4  movaps [rsp], xmm1
000079035dde4ba8  movaps [rsp+0x10], xmm8
000079035dde4bae  movaps [rsp+0x20], xmm9
000079035dde4bb4  lea rdi, [rsp]
000079035dde4bb8  mov esi, 0x00
000079035dde4bbd  mov rax, 0x64ACAA8B0530
000079035dde4bc7  call rax
000079035dde4bc9  movaps xmm1, [rsp]
000079035dde4bcd  add rsp, 0x30
000079035dde4bd1  vmovaps xmm0, [rsp]
000079035dde4bd6  vmovaps xmm2, [rsp+0x10]
000079035dde4bdc  vmovaps xmm3, [rsp+0x20]
000079035dde4be2  vmovaps xmm4, [rsp+0x30]
000079035dde4be8  vmovaps xmm5, [rsp+0x40]
000079035dde4bee  vmovaps xmm6, [rsp+0x50]
000079035dde4bf4  vmovaps xmm7, [rsp+0x60]
000079035dde4bfa  vmovaps xmm8, [rsp+0x70]
000079035dde4c00  vmovaps xmm9, [rsp+0x80]
000079035dde4c09  vmovaps xmm10, [rsp+0x90]
000079035dde4c12  vmovaps xmm11, [rsp+0xA0]
000079035dde4c1b  vmovaps xmm12, [rsp+0xB0]
000079035dde4c24  vmovaps xmm13, [rsp+0xC0]
000079035dde4c2d  vmovaps xmm14, [rsp+0xD0]
000079035dde4c36  vmovaps xmm15, [rsp+0xE0]
000079035dde4c3f  add rsp, 0xF0
000079035dde4c46  pop r11
000079035dde4c48  pop r10
000079035dde4c4a  pop r9
000079035dde4c4c  pop r8
000079035dde4c4e  pop rsi
000079035dde4c4f  pop rdi
000079035dde4c50  pop rdx
000079035dde4c51  pop rcx
000079035dde4c52  pop rax
000079035dde4c53  add rsp, 0x08
000079035dde4c57  jmp 0x000079035DDDFA45
000079035dde4c5c  call 0x000079035DCE5940
000079035dde4c61  jmp 0x000079035DDDFA53
000079035dde4c66  call 0x000079035DC0C380
000079035dde4c6b  jmp 0x000079035DDDFA5D
000079035dde4c70  call 0x000079035DC0D600
000079035dde4c75  jmp 0x000079035DDDFA67
000079035dde4c7a  call 0x000079035DBFF540
000079035dde4c7f  jmp 0x000079035DDDFA71
000079035dde4c84  int3
000079035dde4c85  nop [rax+rax*1], ax
000079035dde4c8e  nop
000079035dde4c90  mov qword ptr [r15+0x40], 0x430000
000079035dde4c98  mov eax, 0x430CC0
000079035dde4c9d  mov r14, [r13+rax*1]
000079035dde4ca2  movq xmm1, r14
000079035dde4ca7  mov rax, [r15+0x50]
000079035dde4cab  movups xmm15, [r13+rax*1]
000079035dde4cb1  movaps [r15+0x120], xmm15
000079035dde4cb9  mov qword ptr [r15+0x48], 0x10
000079035dde4cc1  xor eax, eax
000079035dde4cc3  mov r14d, 0x10
000079035dde4cc9  mov r12d, 0x200
000079035dde4ccf  cmp r14, r12
000079035dde4cd2  cmc
000079035dde4cd3  lahf
000079035dde4cd4  seto al
000079035dde4cd7  mov [r15+0x108], eax
000079035dde4cde  pextrq rax, xmm15, 0x01
000079035dde4ce5  movq xmm14, rax
000079035dde4cea  movaps [r15+0x130], xmm14
000079035dde4cf2  movq rax, xmm1
000079035dde4cf7  movq r14, xmm15
000079035dde4cfc  vmovq xmm1, rax
000079035dde4d01  vmovq xmm15, r14
000079035dde4d06  movaps xmm13, xmm1
000079035dde4d0a  addsd xmm13, xmm15
000079035dde4d0f  ucomisd xmm13, xmm13
000079035dde4d14  jp 0x000079035DDE4DD3
000079035dde4d1a  movq xmm13, xmm13
000079035dde4d1f  movq rax, xmm13
000079035dde4d24  movq r14, xmm14
000079035dde4d29  vmovq xmm1, rax
000079035dde4d2e  vmovq xmm15, r14
000079035dde4d33  movaps xmm14, xmm1
000079035dde4d37  addsd xmm14, xmm15
000079035dde4d3c  ucomisd xmm14, xmm14
000079035dde4d41  jp 0x000079035DDE4E1B
000079035dde4d47  movq xmm14, xmm14
000079035dde4d4c  movaps [r15+0x110], xmm14
000079035dde4d54  mov eax, [r15+0x108]
000079035dde4d5b  sahf
000079035dde4d5c  jnz 0x000079035DDE4D8E
000079035dde4d5e  cmp dword ptr [r15+0x318], 0x00
000079035dde4d66  jz 0x000079035DDE5030
000079035dde4d6c  nop [rax+rax*1], ax
000079035dde4d75  nop [rax+rax*1], eax
000079035dde4d7d  mov eax, 0x410704
000079035dde4d82  mov [r15+0x100], rax
000079035dde4d89  jmp 0x000079035DBFE110
000079035dde4d8e  cmp dword ptr [r15+0x318], 0x00
000079035dde4d96  jz 0x000079035DDE4E70
000079035dde4d9c  nop [rax+rax*1], ax
000079035dde4da5  nop [rax+rax*1], eax
000079035dde4dad  mov eax, 0x4106E8
000079035dde4db2  mov [r15+0x100], rax
000079035dde4db9  jmp 0x000079035DBFE110
000079035dde4dbe  int3
000079035dde4dbf  call 0x000079035DC0DC20
000079035dde4dc4  jmp 0x000079035DDE4CA2
000079035dde4dc9  call 0x000079035DC0E760
000079035dde4dce  jmp 0x000079035DDE4CB1
000079035dde4dd3  ucomisd xmm1, xmm15
000079035dde4dd8  jp 0x000079035DDE4DE7
000079035dde4dda  movaps xmm13, [0x000079035D9FE060]
000079035dde4de2  jmp 0x000079035DDE4D1A
000079035dde4de7  vxorps xmm0, xmm1, xmm15
000079035dde4dec  pextrw eax, xmm0, 0x03
000079035dde4df1  and eax, 0x7FF8
000079035dde4df6  cmp eax, 0x08
000079035dde4df9  jnz 0x000079035DDE4D1A
000079035dde4dff  movq rax, xmm15
000079035dde4e04  shl rax, 0x0D
000079035dde4e08  jbe 0x000079035DDE4D1A
000079035dde4e0e  vorps xmm13, xmm15, [0x000079035D9FE070]
000079035dde4e16  jmp 0x000079035DDE4D1A
000079035dde4e1b  ucomisd xmm1, xmm15
000079035dde4e20  jp 0x000079035DDE4E2F
000079035dde4e22  movaps xmm14, [0x000079035D9FE060]
000079035dde4e2a  jmp 0x000079035DDE4D47
000079035dde4e2f  vxorps xmm0, xmm1, xmm15
000079035dde4e34  pextrw eax, xmm0, 0x03
000079035dde4e39  and eax, 0x7FF8
000079035dde4e3e  cmp eax, 0x08
000079035dde4e41  jnz 0x000079035DDE4D47
000079035dde4e47  movq rax, xmm15
000079035dde4e4c  shl rax, 0x0D
000079035dde4e50  jbe 0x000079035DDE4D47
000079035dde4e56  vorps xmm14, xmm15, [0x000079035D9FE070]
000079035dde4e5e  jmp 0x000079035DDE4D47
000079035dde4e63  int3
000079035dde4e64  nop [rax+rax*1], ax
000079035dde4e6d  nop [rax], eax
000079035dde4e70  mov rax, [r15+0x48]
000079035dde4e74  mov r14, [r15+0x50]
000079035dde4e78  lea r12, [r14+rax*1]
000079035dde4e7c  movups xmm1, [r13+r12*1]
000079035dde4e82  movaps [r15+0x120], xmm1
000079035dde4e8a  lea r14, [rax+0x10]
000079035dde4e8e  mov [r15+0x48], r14
000079035dde4e92  xor eax, eax
000079035dde4e94  mov r12d, 0x200
000079035dde4e9a  cmp r14, r12
000079035dde4e9d  cmc
000079035dde4e9e  lahf
000079035dde4e9f  seto al
000079035dde4ea2  mov [r15+0x108], eax
000079035dde4ea9  pextrq rax, xmm1, 0x01
000079035dde4eb0  movq xmm15, rax
000079035dde4eb5  movaps [r15+0x130], xmm15
000079035dde4ebd  movaps xmm14, [r15+0x110]
000079035dde4ec5  movq rax, xmm14
000079035dde4eca  movq r14, xmm1
000079035dde4ecf  vmovq xmm1, rax
000079035dde4ed4  vmovq xmm14, r14
000079035dde4ed9  movaps xmm13, xmm1
000079035dde4edd  addsd xmm13, xmm14
000079035dde4ee2  ucomisd xmm13, xmm13
000079035dde4ee7  jp 0x000079035DDE4F9C
000079035dde4eed  movq xmm13, xmm13
000079035dde4ef2  movq rax, xmm13
000079035dde4ef7  movq r14, xmm15
000079035dde4efc  vmovq xmm1, rax
000079035dde4f01  vmovq xmm15, r14
000079035dde4f06  movaps xmm14, xmm1
000079035dde4f0a  addsd xmm14, xmm15
000079035dde4f0f  ucomisd xmm14, xmm14
000079035dde4f14  jp 0x000079035DDE4FE4
000079035dde4f1a  movq xmm14, xmm14
000079035dde4f1f  movaps [r15+0x110], xmm14
000079035dde4f27  mov eax, [r15+0x108]
000079035dde4f2e  sahf
000079035dde4f2f  jnz 0x000079035DDE4F61
000079035dde4f31  cmp dword ptr [r15+0x318], 0x00
000079035dde4f39  jz 0x000079035DDE5030
000079035dde4f3f  nop [rax+rax*1], ax
000079035dde4f48  nop [rax+rax*1], eax
000079035dde4f50  mov eax, 0x410704
000079035dde4f55  mov [r15+0x100], rax
000079035dde4f5c  jmp 0x000079035DBFE110
000079035dde4f61  cmp dword ptr [r15+0x318], 0x00
000079035dde4f69  jz 0x000079035DDE4E70
000079035dde4f6f  nop [rax+rax*1], ax
000079035dde4f78  nop [rax+rax*1], eax
000079035dde4f80  mov eax, 0x4106E8
000079035dde4f85  mov [r15+0x100], rax
000079035dde4f8c  jmp 0x000079035DBFE110
000079035dde4f91  int3
000079035dde4f92  call 0x000079035DCB52F0
000079035dde4f97  jmp 0x000079035DDE4E82
000079035dde4f9c  ucomisd xmm1, xmm14
000079035dde4fa1  jp 0x000079035DDE4FB0
000079035dde4fa3  movaps xmm13, [0x000079035D9FE060]
000079035dde4fab  jmp 0x000079035DDE4EED
000079035dde4fb0  vxorps xmm0, xmm1, xmm14
000079035dde4fb5  pextrw eax, xmm0, 0x03
000079035dde4fba  and eax, 0x7FF8
000079035dde4fbf  cmp eax, 0x08
000079035dde4fc2  jnz 0x000079035DDE4EED
000079035dde4fc8  movq rax, xmm14
000079035dde4fcd  shl rax, 0x0D
000079035dde4fd1  jbe 0x000079035DDE4EED
000079035dde4fd7  vorps xmm13, xmm14, [0x000079035D9FE070]
000079035dde4fdf  jmp 0x000079035DDE4EED
000079035dde4fe4  ucomisd xmm1, xmm15
000079035dde4fe9  jp 0x000079035DDE4FF8
000079035dde4feb  movaps xmm14, [0x000079035D9FE060]
000079035dde4ff3  jmp 0x000079035DDE4F1A
000079035dde4ff8  vxorps xmm0, xmm1, xmm15
000079035dde4ffd  pextrw eax, xmm0, 0x03
000079035dde5002  and eax, 0x7FF8
000079035dde5007  cmp eax, 0x08
000079035dde500a  jnz 0x000079035DDE4F1A
000079035dde5010  movq rax, xmm15
000079035dde5015  shl rax, 0x0D
000079035dde5019  jbe 0x000079035DDE4F1A
000079035dde501f  vorps xmm14, xmm15, [0x000079035D9FE070]
000079035dde5027  jmp 0x000079035DDE4F1A
000079035dde502c  int3
000079035dde502d  nop [rax], eax
000079035dde5030  mov rax, [r15+0xF8]
000079035dde5037  lea r14, [rax+0x1D0]
000079035dde503e  mov r12, [r13+r14*1]
000079035dde5043  lea r14, [rax+0x1D8]
000079035dde504a  mov r11, [r13+r14*1]
000079035dde504f  mov [r15+0xA0], r12
000079035dde5056  mov [r15+0x98], r11
000079035dde505d  mov r14, [r15+0x40]
000079035dde5061  lea r12, [r14+0xCC0]
000079035dde5068  movaps xmm1, [r15+0x110]
000079035dde5070  movq r14, xmm1
000079035dde5075  mov [r13+r12*1], r14
000079035dde507a  lea r14, [rax+0x1C0]
000079035dde5081  mov r12, [r13+r14*1]
000079035dde5086  lea r14, [rax+0x1C8]
000079035dde508d  mov r11, [r13+r14*1]
000079035dde5092  mov [r15+0xE8], r12
000079035dde5099  mov [r15+0xF0], r11
000079035dde50a0  lea r14, [rax+0x1B0]
000079035dde50a7  mov r12, [r13+r14*1]
000079035dde50ac  lea r14, [rax+0x1B8]
000079035dde50b3  mov r10, [r13+r14*1]
000079035dde50b8  movq xmm1, r12
000079035dde50bd  movq xmm15, r10
000079035dde50c2  movq xmm1, xmm1
000079035dde50c6  movq xmm1, xmm1
000079035dde50ca  movaps [r15+0x1A0], xmm1
000079035dde50d2  movq xmm15, xmm15
000079035dde50d7  movq xmm15, xmm15
000079035dde50dc  movaps [r15+0x190], xmm15
000079035dde50e4  lea r14, [rax+0x1A0]
000079035dde50eb  mov r12, [r13+r14*1]
000079035dde50f0  lea r14, [rax+0x1A8]
000079035dde50f7  mov r10, [r13+r14*1]
000079035dde50fc  movq xmm1, r12
000079035dde5101  movq xmm15, r10
000079035dde5106  movq xmm1, xmm1
000079035dde510a  movq xmm1, xmm1
000079035dde510e  movaps [r15+0x1C0], xmm1
000079035dde5116  movq xmm15, xmm15
000079035dde511b  movq xmm15, xmm15
000079035dde5120  movaps [r15+0x1B0], xmm15
000079035dde5128  lea r14, [rax+0x190]
000079035dde512f  mov r12, [r13+r14*1]
000079035dde5134  lea r14, [rax+0x198]
000079035dde513b  mov r10, [r13+r14*1]
000079035dde5140  movq xmm1, r12
000079035dde5145  movq xmm15, r10
000079035dde514a  movq xmm1, xmm1
000079035dde514e  movq xmm1, xmm1
000079035dde5152  movaps [r15+0x1E0], xmm1
000079035dde515a  movq xmm15, xmm15
000079035dde515f  movq xmm15, xmm15
000079035dde5164  movaps [r15+0x1D0], xmm15
000079035dde516c  lea r14, [rax+0x180]
000079035dde5173  mov r12, [r13+r14*1]
000079035dde5178  lea r14, [rax+0x188]
000079035dde517f  mov r10, [r13+r14*1]
000079035dde5184  movq xmm1, r12
000079035dde5189  movq xmm15, r10
000079035dde518e  movq xmm1, xmm1
000079035dde5192  movq xmm1, xmm1
000079035dde5196  movaps [r15+0x200], xmm1
000079035dde519e  movq xmm15, xmm15
000079035dde51a3  movq xmm15, xmm15
000079035dde51a8  movaps [r15+0x1F0], xmm15
000079035dde51b0  lea r14, [rax+0x1E0]
000079035dde51b7  mov [r15+0xF8], r14
000079035dde51be  mov [r15+0x100], r11
000079035dde51c5  jmp 0x000079035DDCE5C0
000079035dde51ca  int3
000079035dde51cb  call 0x000079035DCE27E0
000079035dde51d0  jmp 0x000079035DDE5043
000079035dde51d5  call 0x000079035DCE1570
000079035dde51da  jmp 0x000079035DDE504F
000079035dde51df  call 0x000079035DCC3FE0
000079035dde51e4  jmp 0x000079035DDE507A
000079035dde51e9  call 0x000079035DCE27E0
000079035dde51ee  jmp 0x000079035DDE5086
000079035dde51f3  call 0x000079035DCE1570
000079035dde51f8  jmp 0x000079035DDE5092
000079035dde51fd  call 0x000079035DCE27E0
000079035dde5202  jmp 0x000079035DDE50AC
000079035dde5207  call 0x000079035DCE0300
000079035dde520c  jmp 0x000079035DDE50B8
000079035dde5211  call 0x000079035DCE27E0
000079035dde5216  jmp 0x000079035DDE50F0
000079035dde521b  call 0x000079035DCE0300
000079035dde5220  jmp 0x000079035DDE50FC
000079035dde5225  call 0x000079035DCE27E0
000079035dde522a  jmp 0x000079035DDE5134
000079035dde522f  call 0x000079035DCE0300
000079035dde5234  jmp 0x000079035DDE5140
000079035dde5239  call 0x000079035DCE27E0
000079035dde523e  jmp 0x000079035DDE5178
000079035dde5243  call 0x000079035DCE0300
000079035dde5248  jmp 0x000079035DDE5184
000079035dde524d  int3
000079035dde524e  nop
000079035dde5250  mov qword ptr [r15+0x100], 0x04
000079035dde525b  mov esi, 0x00
000079035dde5260  mov edx, 0x09
000079035dde5265  mov rdi, 0x7FFEB265EB30
000079035dde526f  mov rax, 0x64ACAA743970
000079035dde5279  call rax
000079035dde527b  cmp dword ptr [r15+0x318], 0x00
000079035dde5283  jnz 0x000079035DBFE110
000079035dde5289  jmp 0x000079035DBFE0A0
000079035dde528e  int3
000079035dde528f  int3
